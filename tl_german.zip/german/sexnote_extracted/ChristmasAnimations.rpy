# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/ChristmasAnimations.rpy
translate german strings:

    # say L6 shiHin
    old "Ok [pla], just make sure to enjoy it."
    new "Ok [pla], mach einfach sicher, dass du es genießt."

    # say L8 shiBel
    old "Yes, like that, do you like the taste of his dick?"
    new "Ja, genau so, magst du den Geschmack seines Schwanzes?"

    # say L10 shiHin
    old "Hahaha, that’s right. Enjoy it, put it all in your mouth."
    new "Hahaha, genau so. Genieße es, steck es dir ganz in den Mund."

    # say L14 shiBel
    old "It’s so big, it can’t even fit it in her mouth."
    new "Es ist so groß, sie kann es gar nicht ganz in den Mund bekommen."

    # say L15 shiHin
    old "Is it feeling good [pla]?"
    new "Fühlt es sich gut an [pla]?"

    # say L16 pla
    old "Y- yes, it feels really good."
    new "Y- ja, es fühlt sich echt gut an."

    # say L19 shiBil
    old "It's so fucking huge..."
    new "Es ist so verdammt groß..."

    # say L20 shiBil
    old "And it’s throbbing in my mouth."
    new "Und es pocht in meinem Mund."

    # say L21 shiBil
    old "I think he’s getting close."
    new "Ich glaube, er kommt gleich."

    # say L22 shiBel
    old "That’s right, keep pushing that cock in your mouth!"
    new "Das ist richtig, fick den Schwanz weiter in deinem Mund!"

    # say L47 shiHin
    old "Are you cummin [pla]?"
    new "Kommst du [pla]?"

    # say L48 pla
    old "Ughh... Y- yes..."
    new "Ughh... J- ja..."

    # say L49 shiBel
    old "Then do it! Cum! Fill her mouth!"
    new "Dann mach es! Komm! Füll ihren Mund!"

    # say L55 shiHin
    old "That looked great!"
    new "Das sah toll aus!"

    # say L56 shiBel
    old "It really did."
    new "Es war wirklich so."

    # say L57 shiBel
    old "You see Mildret? We knew you would enjoy it."
    new "Siehst du Mildret? Wir wussten, dass dir das gefallen würde."

    # say L58 shiBil
    old "It was... good."
    new "Es war... gut."

    # say L59 shiBil
    old "These bodies are certainly incredible."
    new "Diese Körper sind wirklich unglaublich."

    # say L60 shiBil
    old "And the taste... I feel I could get used to it."
    new "Und der Geschmack... Ich glaube, ich könnte mich daran gewöhnen."

    # say L61 shiHin
    old "Hahaha, it’s good to see you’re enjoying the ritual."
    new "Hahaha, es ist gut zu sehen, dass dir das Ritual gefällt."

    # say L62 shiBel
    old "What about if we get ready to enjoy that cock inside us?"
    new "Was ist, wenn wir uns bereit machen, um diesen Schwanz in uns zu genießen?"

    # say L63 shiHin
    old "That's a good idea..."
    new "Das ist eine gute Idee..."

    # say L64 shiBil
    old "All right."
    new "Okay."

    # say L73 shiBel
    old "How is the ritual going Linett?"
    new "Wie läuft das Ritual, Linett?"

    # say L74 lin
    old "It’s good, I was able to stabilize a breaching point."
    new "Es läuft gut, ich konnte einen Durchbruch stabilisieren."

    # say L75 lin
    old "But to open it I’m going to need an even bigger magic discharge."
    new "Aber um es zu öffnen, brauche ich eine noch größere magische Entladung."

    # say L76 shiHin
    old "Oh, don’t worry, that’s what’s coming just now. Or maybe I meant cumming..."
    new "Oh, mach dir keine Sorgen, das kommt gleich. Oder meinte ich kommen..."

    # say L77 shiBel
    old "This is where we really enjoy it."
    new "Hier wird es richtig gut."

    # say L78 shiHin
    old "Let’s do it then."
    new "Dann lass uns loslegen."

    # say L79 milBil
    old "This is still new for me [pla]. So remember to be gentle."
    new "Das ist noch neu für mich [pla]. Also denk dran, vorsichtig zu sein."

    # say L80 pla
    old "Sure."
    new "Klar."

    # say L93 milBil
    old "Mmm, this sensation. It’s so strong."
    new "Mmm, dieses Gefühl. Es ist so intensiv."

    # say L94 milBil
    old "And so big, incredible."
    new "Und so groß, unglaublich."

    # say L95 gomHin
    old "Move a little faster [pla]."
    new "Beweg dich ein bisschen schneller [pla]."

    # say L99 milBil
    old "Oh! It feels so hot!"
    new "Oh! Das fühlt sich so heiß an!"

    # say L100 devBel
    old "Yes, enjoy it Mildret. Do you like his cock inside you?"
    new "Ja, genieße es Mildret. Magst du seinen Schwanz in dir?"

    # say L101 milBil
    old "I do, I really like it!"
    new "Ich tu's, ich mag es wirklich!"

    # say L105 milBil
    old "Ahh! Ahh! This is amazing!"
    new "Ahh! Ahh! Das ist unglaublich!"

    # say L106 milBil
    old "It feels so good!"
    new "Das fühlt sich so gut an!"

    # say L107 milBil
    old "Do it some more, keep going!"
    new "Mach weiter, hör nicht auf!"

    # say L130 milBil
    old "This feeling, I think I’m cumming!"
    new "Dieses Gefühl, ich glaube, ich komme!"

    # say L131 gomHin
    old "You hear that [pla]? Make her Cum!"
    new "Hast du das gehört [pla]? Mach sie kommen!"

    # say L132 pla
    old "Ahh! Y- yes!"
    new "Ahh! J- ja!"

    # say L138 devBel
    old "So, did you like it?"
    new "Hat dir das gefallen?"

    # say L139 gomHin
    old "It was very good."
    new "Es war sehr gut."

    # say L140 devBel
    old "I’m glad you enjoyed it, but it’s my turn now."
    new "Ich freue mich, dass es dir gefallen hat, aber jetzt bin ich dran."

    # say L141 devBel
    old "I actually wonder how it’s going to be with this small body."
    new "Ich frage mich, wie es mit diesem kleinen Körper sein wird."

    # say L142 devBel
    old "I hope it’s going to be as good as last time."
    new "Ich hoffe, es wird genauso gut wie letztes Mal."

    # say L143 gomHin
    old "Only one way to find out..."
    new "Nur ein Weg, das herauszufinden..."

    # say L161 devBel
    old "Ohh! Ahh! It’s so big!"
    new "Ohh! Ahh! Es ist so groß!"

    # say L162 devBel
    old "It fills me up, completely."
    new "Es füllt mich aus, komplett."

    # say L163 devBel
    old "Uhhh it hurts, but still feels so good!"
    new "Uhhh, es tut weh, aber fühlt sich trotzdem so gut an!"

    # say L167 devBel
    old "Yes, yes, just like that."
    new "Ja, ja, genau so."

    # say L168 devBel
    old "I love how your cock feels."
    new "Ich liebe, wie sich dein Schwanz anfühlt."

    # say L169 devBel
    old "Ohhh yeah, with this little body feels even better!."
    new "Ohhh ja, mit diesem kleinen Körper fühlt es sich noch besser an!"

    # say L173 gomHin
    old "Do you like how he pounds your pussy Devonne?"
    new "Magst du, wie er deine Pussy fickt, Devonne?"

    # say L174 devBel
    old "Ah, Ah, YES!"
    new "Ah, Ah, JA!"

    # say L175 devBel
    old "I love it! I love it!"
    new "Ich liebe es! Ich liebe es!"

    # say L176 devBel
    old "I want to keep doing it in this body forever!"
    new "Ich will ewig in diesem Körper weitermachen!"

    # say L199 devBel
    old "I’m cummin! I can feel it!"
    new "Ich komme! Ich spür's!"

    # say L200 pla
    old "M- me too!"
    new "M- ich auch!"

    # say L201 devBel
    old "Do it! Cum in me!"
    new "Mach es! Komm in mir!"

    # say L207 devBel
    old "That was sooo good."
    new "Das war soo gut."

    # say L208 devBel
    old "I think I could get addicted to it."
    new "Ich denke, ich könnte süchtig danach werden."

    # say L209 devBel
    old "And I think it felt even better because of how small this body is."
    new "Und ich glaube, es hat sich noch besser angefühlt, weil mein Körper so klein ist."

    # say L210 gomHin
    old "Hmm, now you’ve made me crave it even more!"
    new "Hmm, jetzt hast du mich noch mehr danach verlangen lassen!"

    # say L211 gomHin
    old "Come on [pla] let’s finish the ritual."
    new "Komm schon [pla], lass uns das Ritual beenden."

    # say L212 gomHin
    old "You’ve done a lot [pla]."
    new "Du hast schon viel geschafft [pla]."

    # say L213 gomHin
    old "So you must be tired, but don’t falter now."
    new "Du musst müde sein, aber lass jetzt nicht nach."

    # say L214 pla
    old "S- sure."
    new "Klar."

    # say L231 gomHin
    old "Oh yes! That’s just what I wanted."
    new "Oh ja! Das ist genau das, was ich wollte."

    # say L232 devBel
    old "That’s right [pla]. Fill her all the way up."
    new "Das ist richtig [pla]. Fülle sie ganz aus."

    # say L233 devBel
    old "And go a little faster."
    new "Und mach es ein bisschen schneller."

    # say L237 gomHin
    old "Ah, Ah, your cock, it’s reaching so deep!"
    new "Ah, Ah, dein Schwanz, er erreicht so tief!"

    # say L238 gomHin
    old "And it feels so hot as you penetrate me!"
    new "Und es fühlt sich so heiß an, wie du mich durchdringst!"

    # say L239 gomHin
    old "I can feel it throbbing in me. I love how it feels!"
    new "Ich spüre es pulsieren in mir. Ich liebe das Gefühl!"

    # say L243 gomHin
    old "Ohh! Ohh! YES!"
    new "Ohh! Ohh! JA!"

    # say L244 gomHin
    old "This is great!"
    new "Das ist toll!"

    # say L245 gomHin
    old "I feel the magic pushing in!"
    new "Ich spüre die Magie in mir aufsteigen!"

    # say L268 gomHin
    old "I’m about to cum!"
    new "Ich komme gleich!"

    # say L269 pla
    old "M- me too"
    new "M-Mir auch"

    # say L270 pla
    old "I can’t hold it anymore!"
    new "Ich halte es nicht mehr aus!"

    # say L271 gomHin
    old "Let it go!"
    new "Lass es raus!"

    # say L272 gomHin
    old "Shoot your magic in my pussy!"
    new "Lass deinen Zauber in meiner Pussy explodieren!"


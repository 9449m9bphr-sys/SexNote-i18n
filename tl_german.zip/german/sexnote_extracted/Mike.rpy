# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mike.rpy
translate german strings:

    # say L32 whi
    old "Mmm, hi, [pla]. Long time, no see! My, how you've grown!"
    new "Mmm, hallo, [pla]. Lange nicht gesehen! Meine Güte, wie Sie gewachsen sind!"

    # say L34 pla
    old "(Gulp) Hello, Mrs. White. Thank you."
    new "Hallo, Mrs. White. Danke."

    # say L37 whi
    old "I guess you came over to see Mike? What are you two planning on doing?"
    new "Ich denke, Sie sind gekommen, um Mike zu sehen? Was haben Sie beide vor?"

    # say L39 pla
    old "Uhh... We... Nothing... Hehe."
    new "Uhh... Wir... Nichts... Hehe."

    # say L44 mik
    old "Finally! You decided to come! Don't bother us, Mom. We gotta work on that dumb school project."
    new "Endlich! Du hast dich entschieden zu kommen! Lass uns in Ruhe, Mom. Wir müssen an diesem blöden Schulleprojekt arbeiten."

    # say L46 whi
    old "Ok. If you guys need anything, I'll be here."
    new "Okay. Wenn ihr etwas braucht, ich bin hier."

    # say L52 pla
    old "Alright, man. What's this great thing you just had to show me? "
    new "Okay, Mann. Was ist dieser tolle Sach, die du mir unbedingt zeigen musst?"

    # say L54 mik
    old "Well, you came just in time. Every day... at this minute... it begins."
    new "Na, du kommst gerade recht. Jeden Tag... in dieser Minute... fängt es an."

    # say L56 pla
    old "What begins?"
    new "Was beginnt?"

    # say L58 mik
    old "You'll see... Just wait."
    new "Du wirst schon sehen... Warte einfach ab."

    # say L61 pla
    old "The hell you doing, Mike?"
    new "Was soll das, Mike?"

    # say L62 mik
    old "Let me enjoy for a sec. It'll be your turn in a bit."
    new "Lass mich noch einen Moment genießen. Bald ist deine Reihe."

    # say L67 mik
    old "Ok, here. Take this and peep what's out the front window? "
    new "Okay, hier. Nimm das und schau mal, was vor dem Fenster los ist?"

    # say L74 pla
    old "Oh shit!"
    new "Oh Scheiße!"

    # say L75 mik
    old "She's hot, isn't she?"
    new "Sie ist heiß, oder?"

    # say L77 pla
    old "Damn. I think... I think, I've seen her before"
    new "Verdammt. Ich glaube... ich glaube, ich habe sie schon mal gesehen."

    # say L78 mik
    old "Wait... Do you really know  that lady?"
    new "Warte... Kennst du die Frau wirklich?"

    # say L84 pla
    old " I think so but I'm not sure... I'd have to get a closer look."
    new "Ich glaube schon, aber ich bin mir nicht sicher... Ich müsste sie mir genauer ansehen."

    # say L87 mik
    old "Well ... I know something for sure... she is sexy as fuck! "
    new "Na ja... ich bin mir sicher, dass sie verdammt sexy ist!"

    # say L89 pla
    old "(she really is...)"
    new "(sie ist wirklich...)"

    # say L93 mik
    old "Haha. I knew you would like it."
    new "Haha. Ich wusste, dass dir das gefallen würde."

    # say L101 mik
    old "What? Is she getting naked? Give me those binoculars!"
    new "Was? Zieht sie sich aus? Gib mir die Ferngläser!"

    # say L107 pla
    old "(Hmm... What am I going to do now? Can't let Mike see me like this.)"
    new "Hmm... Was mache ich jetzt? Lass Mike das auf keinen Fall sehen."

    # say L109 pla
    old "(The only solution is to go to the bathroom and try to masturbate.)"
    new "(Die einzige Lösung ist, ins Badezimmer zu gehen und es zu versuchen.)"

    # say L111 pla
    old "Hmm... I need to use your bathroom, man. You keep watching her..."
    new "Hmm... Ich muss mal aufs Klo, Alter. Du schaust weiter zu ihr..."

    # say L112 mik
    old "Ok. Suit yourself."
    new "Okay. Machen Sie es sich selbst."

    # say L117 pla
    old " Whoops. I'm sorry, ma'am. I thought there was no one-"
    new "Ups. Entschuldigung, Ma’am. Ich dachte, da wäre niemand-"

    # say L118 whi
    old "Ohh, are you [pla]? Don't worry. Go on and use the toilet. I trust that you won't peep, right? "
    new "Ohh, sind Sie [pla]? Machen Sie sich keine Sorgen. Gehen Sie ruhig und benutzen Sie die Toilette. Ich vertraue darauf, dass Sie nicht spionieren, oder?"

    # say L120 pla
    old "No. Of course not, Mrs. White..."
    new "Nein. Natürlich nicht, Mrs. White..."

    # say L121 whi
    old "Haha! I am just kidding. Do what you need to do, kid. I'll continue taking a shower, deal?"
    new "Haha! Ich mache nur Spaß. Mach, was du machen musst, Junge. Ich werde weiter duschen, okay?"

    # say L122 pla
    old "Ok... (Hmm I have no option) "
    new "Okay... (Hmm, ich habe keine Wahl)"

    # say L129 whi
    old "(What is that noise? ...What is he doing?)"
    new "Was ist das für ein Geräusch?...Was macht er da?"

    # say L133 whi
    old "(My word... He is hung!)"
    new "Mein Gott... Er ist ja gut bestückt!"

    # say L139 whi
    old "(Mmm... I should just take my shower. I don't want him to see me peeping.)"
    new "Mmm... Ich sollte einfach meine Dusche nehmen. Ich will ja nicht, dass er mich beim Spionieren sieht."

    # say L143 pla
    old "Well, I managed to solve it, but I don't know for how long..."
    new "Na ja, ich habe es geschafft, aber wie lange das halten wird, weiß ich nicht."

    # say L145 pla
    old "I better say goodbye to Mike and go home."
    new "Ich sollte Mike noch schnell Tschüss sagen und dann nach Hause gehen."

    # say L156 pla
    old " Hey, Mike. I have to jet."
    new "Hey, Mike. Ich muss los."

    # say L157 mik
    old "Oh, ok.  If you want to check her out again, come tomorrow."
    new "Oh, okay. Wenn du sie wiedersehen willst, komm morgen."

    # say L159 pla
    old "W-What?!"
    new "W-Was?!"

    # say L160 mik
    old "Yeah. If you want to see my neighbor again, come tomorrow..."
    new "Klar. Wenn du meine Nachbarin noch mal sehen willst, komm morgen..."

    # say L162 pla
    old " Ohh, right. (Whew.) The neighbor... Ok. See you later, dude."
    new "Ohh, stimmt. (Phew.) Die Nachbarin... Okay. Bis später, Mann."

    # say L182 mik
    old "Hey dude, you wanna see her again?"
    new "Hey Mann, willst du sie wiedersehen?"

    # say L185 pla
    old "Yeah, man. I want to check if I really know her."
    new "Klar, Mann. Ich will sehen, ob ich sie wirklich kenne."

    # say L187 mik
    old "Really? Ok, yeah, sure... Ok, it's your turn then..."
    new "Wirklich? Okay, klar... Okay, dann bist du dran..."

    # say L194 mik
    old "Remember, if she starts to undress you have to tell me..."
    new "Erinnerst du dich, wenn sie anfängt, sich auszuziehen, musst du es mir sagen..."

    # say L195 pla
    old "Alright..."
    new "Okay..."

    # say L197 pla
    old "(Hmm, really? Another hardon?) Mike, I need to use the bathroom. You wanna keep watching?"
    new "(Hmm, echt? Noch eine Erektion?) Mike, ich muss aufs Klo. Willst du weiter gucken?"

    # say L198 mik
    old "Of course!... She's so hot."
    new "Natürlich!... Sie ist so heiß."

    # say L212 mik
    old "You back, dude?... Check out this other position she's practicing..."
    new "Bist du wieder da, Alter?... Schau dir diese andere Position an, die sie übt..."

    # say L215 pla
    old "Really? Let me see. (Maybe now I can see her face and know if I can if i can recognize her.)"
    new "Wirklich? Lass mich sehen. (Vielleicht kann ich jetzt ihr Gesicht sehen und sie erkennen.)"

    # say L217 mik
    old "Yeah, sure... Here you go."
    new "Klar, sicher... Hier, bitte."

    # say L227 pla
    old "(Hmm, really? An erection again?) Mike, I need to use your bathroom. You can have the binoculars back, bud."
    new "Hmm, wirklich? Wieder eine Erektion? Mike, ich muss auf die Toilette. Du kannst das Fernglas zurückhaben, Kumpel."

    # say L228 mik
    old "Sweet!"
    new "Cool!"

    # say L241 mik
    old "[pla]! Come look, man! It's gotten sexier than ever!"
    new "[pla]! Komm gucken, Mann! Es ist noch geiler geworden!"

    # say L244 pla
    old "What the fuck..."
    new "Was zum Teufel..."

    # say L251 mik
    old "She makes me so fuckin' hard. I really wanna fuck her..."
    new "Sie macht mich so geil. Ich will sie echt ficken..."

    # say L253 pla
    old "(Aaaand, of course, another erection...) Yeah, Mike... this is awesome... You can keep watching..."
    new "(Aaaand, natürlich, noch eine Erektion...) Ja, Mike... das ist super... Du kannst weiter zusehen..."

    # say L258 mik
    old "Perfect! Ohh man. Tonight, I'm going to jerk off just thinking about her... "
    new "Perfekt! Oh Mann. Heute Nacht werde ich nur an sie denken, wenn ich es mir besorge..."

    # say L259 pla
    old "...(This guy...)"
    new "(Dieser Typ...)"

    # say L261 pla
    old "Mike, I need to use your bathroom, man..."
    new "Mike, ich muss mal dein Badezimmer benutzen, Alter..."

    # say L262 mik
    old "Nice... take your time. My turn to enjoy the view."
    new "Nett... nimm dir Zeit. Meine Reihe, den Anblick zu genießen."

    # say L275 mik
    old "Hey [pla], you wanna see her again?"
    new "Hey [pla], willst du sie noch mal sehen?"

    # say L278 pla
    old "Well... Yes..."
    new "Na klar... Ja..."

    # say L280 mik
    old "Ok, it's your turn then..."
    new "Okay, dann bist du dran..."

    # menu L305 
    old "Continue"
    new "Fortsetzen"

    # say L312 pla
    old "(Aaaand, here it is, another erection...) Mike... I need to use your bathroom.... You can keep watching..."
    new "Mike... Ich muss mal aufs Klo... Du kannst weiter gucken..."

    # say L313 mik
    old "Ok, man. It's my turn again..."
    new "Ok, Mann. Ist wieder meine Runde..."

    # menu L326 
    old "Blowjob"
    new "Blasen"

    # say L342 whi
    old "Hi [pla]. If you're looking for Mike, he's in his room."
    new "Hallo [pla]. Wenn Sie nach Mike suchen, der ist in seinem Zimmer."

    # say L344 pla
    old "Ok, thank you, Mrs. White."
    new "Ok, danke, Mrs. White."

    # say L353 whi
    old "Hey big boy... Don't you want to go to the bathroom again?"
    new "Hey großer Junge... Willst du nicht wieder ins Bad gehen?"

    # say L355 pla
    old "...I...Umm... What... do you mean?"
    new "Ich... Äh... Was meinst du damit?"

    # say L357 whi
    old "I mean don't leave me waiting. I will be in there if you want to go at it again..."
    new "Ich meine, lass mich nicht warten. Ich bin drin, wenn du wieder willst..."

    # say L367 whi
    old "Hey, handsome... Are you looking for some help?"
    new "Hey, gutaussehender Mann... Suchst du vielleicht ein bisschen Hilfe?"

    # say L369 pla
    old "Wh... Huh?... Nah, I was... Looking for Mike..."
    new "Wh... Huh?... Nein, ich war... auf der Suche nach Mike..."

    # say L371 whi
    old "Ok, honey. Mmm, I will be in the bathroom waiting for you..."
    new "Okay, Schatz. Mmm, ich werde im Bad auf dich warten..."

    # say L403 pla
    old "...Yeah, I'm looking for Mike, I... I will go to his bedroom, excuse me."
    new "Ja, ich suche Mike, ich... ich gehe in sein Schlafzimmer, entschuldigen Sie mich."

    # say L437 pla
    old "(Daaaamn!).... I'm sorry, ma'am. I'm leaving right now."
    new "(Daaaamn!).... Entschuldigung, Ma'am. Ich gehe sofort."

    # say L439 whi
    old "Ohh. I'm sorry. Silly me, I forgot to close the curtains... Haha! But don't you worry. I know what you're going to do and maybe I can give you some... inspiration..."
    new "Ohh. Entschuldigung. Toller ich, ich habe vergessen, die Vorhänge zu schließen... Haha! Aber machen Sie sich keine Sorgen. Ich weiß, was Sie vorhaben, und vielleicht kann ich Ihnen ein bisschen... Inspiration geben..."

    # say L441 pla
    old "I... don't know... what you're talking about. (Gulp)"
    new "Ich... hab' keine Ahnung... wovon du redest. (Schluck)"

    # say L443 whi
    old "Ohh, come on... you're about to burst in those shorts of yours... Just let it out. Mmm, I wanna see it..."
    new "Ohh, kommen Sie schon... Sie platzen ja gleich in diesen Shorts von Ihnen... Lassen Sie es einfach raus. Mmm, ich will es sehen..."

    # say L449 whi
    old "That's right... Stroke that big cock for mommy..."
    new "Das ist richtig... Reib diesen großen Schwanz für Mama..."

    # say L455 whi
    old "Nice... Mmm, what a good load, [pla]..."
    new "Nett... Mmm, was für eine gute Ladung, [pla]..."

    # say L456 pla
    old "...That was intense..."
    new "Das war intensiv..."

    # say L457 whi
    old "Thank you, honey... I hope we have a bathroom rondevu again."
    new "Danke, Schatz... Ich hoffe, wir haben wieder ein Badezimmer-Rendezvous."

    # say L459 pla
    old "I... I... have to go, Mrs. White."
    new "Ich... ich... muss gehen, Mrs. White."

    # say L463 pla
    old "Whoa... That was crazy..."
    new "Wow... Das war verrückt..."

    # say L465 pla
    old "I better go home."
    new "Ich sollte besser nach Hause gehen."

    # say L478 pla
    old "(Oh shit... Again).... I'm sorry, I'm leaving right now."
    new "Oh Scheiße... Wieder... Es tut mir leid, ich geh jetzt sofort."

    # say L480 whi
    old "Mmm, I knew you would come... I was waiting for you, [pla]."
    new "Mmm, ich wusste, dass du kommen würdest... Ich habe auf dich gewartet, [pla]."

    # say L484 whi
    old "Ohh, come on... Just let it out. I wanna see it again..."
    new "Ohh, kommen Sie schon... Lassen Sie es einfach raus. Ich will es wieder sehen..."

    # say L498 whi
    old "Thank you, honey... I hope we have a bathroom rendezvous again."
    new "Danke, Schatz... Ich hoffe, wir haben wieder ein Badezimmer-Rendezvous."

    # say L519 whi
    old "Hey handsome, I was waiting for you."
    new "Hey Schatz, ich habe auf dich gewartet."

    # say L523 whi
    old "Come on, don't be shy. Take that monster out and get to jerking..."
    new "Komm schon, sei nicht schüchtern. Hol das Monster raus und fang an zu wichsen..."

    # say L531 whi
    old "Would you mind if I give you a hand?"
    new "Würden Sie etwas dagegen haben, wenn ich Ihnen helfe?"

    # say L532 pla
    old "(Is this really happening?) W- What?"
    new "W- Was?"

    # say L544 whi
    old "You can come whenever you want and, I'll give you a hand, my pleasure, okay?"
    new "Sie können jederzeit kommen und ich werde Ihnen helfen, das ist mir ein Vergnügen, okay?"

    # say L546 pla
    old "Yes, ma'am."
    new "Ja, Ma'am."

    # say L547 whi
    old "Get out before Mike suspects anything..."
    new "Gehen Sie, bevor Mike etwas ahnt..."

    # say L549 pla
    old "Ok, Mrs. White... "
    new "Okay, Mrs. White..."

    # say L552 whi
    old "Hmm, what a big load..."
    new "Hmm, das war aber eine Menge..."

    # say L555 pla
    old "Wow... She jerked me off..."
    new "Wow... Sie hat mich abgezogen..."

    # say L556 pla
    old "I should take my ass home."
    new "Ich sollte meinen Arsch nach Hause bringen."

    # say L581 whi
    old "Come on, Take off your pants. I have a little surprise for you..."
    new "Kommen Sie, ziehen Sie Ihre Hose aus. Ich habe eine kleine Überraschung für Sie..."

    # say L599 whi
    old "I will be waiting for you handsome..."
    new "Ich werde auf Sie warten, mein Schöner..."

    # say L607 whi
    old "Hmm, that tasted so good!"
    new "Hmm, das hat so gut geschmeckt!"

    # say L610 pla
    old "Wow... W- what just happened?"
    new "Wow... W- was ist da gerade passiert?"


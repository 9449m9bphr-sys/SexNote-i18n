# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Church.rpy
translate german strings:

    # say L44 pla
    old "She is praying, I shouldn't bother her."
    new "Sie betet, ich sollte sie nicht stören."

    # say L58 jon
    old "Oh, hi young man, are you the one who accompanied Lydia a few days ago?"
    new "Oh, hallo junger Mann, sind Sie derjenige, der Lydia vor ein paar Tagen begleitet hat?"

    # say L60 pla
    old "Yes Mrs. Jones, my name is [pla], nice to meet you."
    new "Ja, Frau Jones, mein Name ist [pla], schön Sie kennenzulernen."

    # say L62 jon
    old "Excellent [pla], I think it's very good that you visit the church."
    new "Exzellent [pla], ich denke, es ist sehr gut, dass Sie die Kirche besuchen."

    # say L64 jon
    old "Many young people should be like you."
    new "Viele junge Leute sollten dir gleichen."

    # say L66 pla
    old "Oh no, I just-"
    new "Oh nein, ich hab nur-"

    # say L68 jon
    old "Today all young people think about is sex, parties and devil things."
    new "Heutzutage denken alle jungen Leute nur an Sex, Partys und Teufelszeug."

    # say L70 jon
    old "Did you know that sister Grace is organizing the church choir?"
    new "Wussten Sie, dass Schwester Grace den Kirchenchor organisiert?"

    # say L72 jon
    old "If you want I could introduce you, so you could continue on your way to the Lord."
    new "Wenn Sie möchten, könnte ich Sie ihr vorstellen, damit Sie auf dem Weg zu Gott weitergehen können."

    # say L74 pla
    old "Well, actually-"
    new "Na ja, eigentlich-"

    # say L76 jon
    old "Perfect! I'll talk to sister Grace, she'll be very happy."
    new "Perfekt! Ich werde mit Schwester Grace sprechen, sie wird sich sehr freuen."

    # say L78 pla
    old "Ok ..."
    new "Ok..."

    # say L90 jon
    old "Oh, hi [pla], how are you doing."
    new "Oh, hallo [pla], wie geht es Ihnen?"

    # say L91 pla
    old "Hi, Mrs. Jones, I'm great thanks, what about you?"
    new "Hallo, Mrs. Jones, ich bin super, danke. Und du?"

    # say L92 jon
    old "I'm fine, waiting for the next mass."
    new "Ich bin gut, warte auf die nächste Messe."

    # say L93 jon
    old "Do you need something hun?"
    new "Brauchen Sie etwas, Schatz?"

    # say L117 jon
    old "Honey?"
    new "Liebling?"

    # menu L119 
    old "Not now."
    new "Nicht jetzt."

    # say L122 pla
    old "Oh no, don't worry, I just wanted to say hi."
    new "Oh nein, mach dir keine Sorgen, ich wollte nur Hallo sagen."

    # say L123 jon
    old "Alright, thank you hun, see you later."
    new "Alles gut, danke, bis später."

    # say L124 pla
    old "Bye, Mrs. Jones."
    new "Tschüss, Mrs. Jones."

    # say L181 pla
    old "(Wow!)"
    new "Wow!"

    # say L182 pla
    old "(Sister Grace is really attractive...)"
    new "Sister Grace ist wirklich attraktiv..."

    # say L183 pla
    old "(Should I use the Agamoto eye?)"
    new "Soll ich das Agamoto-Auge benutzen?"

    # menu L185 
    old "Yes"
    new "Ja"

    # say L188 pla
    old "(Oh my...)"
    new "Oh Mann..."

    # menu L190 
    old "No"
    new "Nein"

    # say L193 pla
    old "(I better get back to work.)"
    new "Ich sollte besser wieder an die Arbeit gehen."

    # say L203 pla
    old "(Mrs. Jones's skirt went up quite a bit...)"
    new "Mrs. Jones' Rocker ging ziemlich weit hoch..."

    # say L221 gra
    old "Wow! I knew you would have been fast but I didn't expect that much."
    new "Wow! Ich wusste, dass Sie schnell sind, aber das ist wirklich beeindruckend."

    # say L222 pla
    old "Haha, thanks Sister Grace... I like to do things as fast as possible."
    new "Haha, danke Schwester Grace... Ich mag es, Dinge so schnell wie möglich zu machen."

    # say L223 jon
    old "I wonder if you're that good at everything... Great job!"
    new "Ich frage mich, ob Sie in allem so gut sind... Großartige Arbeit!"

    # say L224 jon
    old "Anyway, it's already very late, and I think we should all rest now, see you again tomorrow."
    new "Na ja, es ist schon sehr spät, und ich denke, wir sollten alle jetzt schlafen gehen. Bis morgen."

    # say L225 gra
    old "Thank you, so much for your help Mrs. Jones and [pla]."
    new "Vielen Dank für Ihre Hilfe, Mrs. Jones und [pla]."

    # say L226 pla
    old "Alright, see you tomorrow."
    new "Okay, bis morgen."

    # say L240 gra
    old "Oh, it's too late and we can't finish cleaning."
    new "Oh, es ist zu spät und wir können das Aufräumen nicht mehr beenden."

    # say L241 jon
    old "Well, today was a bit harder than usual..."
    new "Nun, heute war etwas härter als sonst..."

    # say L242 pla
    old "Don't worry, I can stay and finish the cleaning."
    new "Mach dir keine Sorgen, ich bleibe und mache den Rest."

    # say L243 jon
    old "Oh no! It's fine, we'll finish tomorrow..."
    new "Oh nein! Es ist in Ordnung, wir werden es morgen zu Ende bringen..."

    # say L244 gra
    old "It's fine, just hurry a little more next time and we will make it."
    new "Es ist in Ordnung, beeilen Sie sich beim nächsten Mal ein bisschen mehr und wir schaffen es."

    # say L245 pla
    old "I guess the next time will be better."
    new "Ich denke, das nächste Mal wird besser."

    # say L246 jon
    old "Sure, it will!, anyway see you again tomorrow."
    new "Natürlich, es wird besser werden, auf jeden Fall bis morgen dann."


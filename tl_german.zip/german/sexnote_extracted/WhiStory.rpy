# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/WhiStory.rpy
translate german strings:

    # say L9 rub
    old "What the fuck? I just can't believe it!"
    new "Was zum Teufel? Ich kann es einfach nicht glauben!"

    # say L10 oli
    old "Ruby please! Just listen to me."
    new "Ruby, bitte! Hör mir doch zu."

    # say L11 rub
    old "Listen, to what?"
    new "Wofür soll ich dir zuhören?"

    # say L18 rub
    old "What explanation could you possibly have to go around making friends with that loser?!"
    new "Was für eine Erklärung könntest du haben, um mit diesem Versager befreundet zu werden?!"

    # say L19 oli
    old "You don't understand, I need his help, my grades have been low."
    new "Du verstehst das nicht, ich brauche seine Hilfe, meine Noten sind schlecht."

    # say L20 oli
    old "So, he's going to help me study for my tests. If he doesn't I'll fail my classes."
    new "Also, er wird mir bei den Tests helfen. Wenn nicht, falle ich durch."

    # say L21 rub
    old "And? Who cares?! You can't just hang out with that disgusting nerd!"
    new "Und? Wer kümmert sich darum?! Du kannst doch nicht einfach Zeit mit diesem widerlichen Nerd verbringen!"

    # say L22 rub
    old "Listen, you better find another way other than spending time with that loser."
    new "Hör zu, du musst dir besser was anderes überlegen, als Zeit mit diesem Versager zu verbringen."

    # say L23 oli
    old "B- b- but..."
    new "B- b- aber..."

    # say L27 rub
    old "Ugh, look at that, now the fucking nerds are even eavesdropping our conversations."
    new "Ugh, sieh dir das an, jetzt lauschen uns sogar die verdammten Nerds."

    # say L33 oli
    old "But Ruby! Wait!"
    new "Aber Ruby! Warte!"

    # say L48 pla
    old "Oh hey Mike, what's up?"
    new "Oh hey Mike, was ist los?"

    # say L49 mik
    old "Hmph..."
    new "Hmpf..."

    # say L62 bel
    old "Hmm, that was weird."
    new "Hmm, das war seltsam."

    # say L63 pla
    old "Yeah, it was. What's up with him, is he angry about something?"
    new "Ja, war es. Was ist mit ihm los, ist er sauer auf was?"

    # say L65 bel
    old "Well, now that you mention it. He's been acting odd recently."
    new "Na ja, jetzt wo du es erwähnst. Er verhält sich lately schon komisch."

    # say L66 bel
    old "I don't really know why though."
    new "Ich hab echt keine Ahnung, warum."

    # say L68 pla
    old "Hmm, I see. I guess I'll have to speak with him."
    new "Hmm, ich verstehe. Ich denke, ich werde mit ihm reden."

    # say L69 bel
    old "I think so. He'll probably tell you what's his deal."
    new "Ich denke schon. Er wird dir wahrscheinlich sagen, was los ist."

    # say L70 pla
    old "Yeah, well, see you later then."
    new "Dann sehen wir uns später."

    # say L90 whi
    old "Oh hi [pla]!"
    new "Oh hallo [pla]!"

    # say L91 whi
    old "Uhh, what a nice surprise...It's so good to see you, how are you?"
    new "Uhh, was für eine nette Überraschung... Es freut mich sehr, Sie zu sehen, wie geht es Ihnen?"

    # say L92 pla
    old "Hi Mrs. White, nice to see you."
    new "Hallo Mrs. White, schön dich zu sehen."

    # say L93 pla
    old "Hey, I came looking for Mike, is he around? I wanted to talk to him."
    new "Hey, ich bin auf der Suche nach Mike, ist er da? Ich wollte mit ihm reden."

    # say L94 whi
    old "Hmm, well, he is here, but... I don't think he wants to see you."
    new "Hmm, na ja, er ist hier, aber... ich glaube nicht, dass er Sie sehen will."

    # say L95 pla
    old "Really, why?"
    new "Wirklich, warum?"

    # say L96 whi
    old "Well, he's been a little... Uhh, unwell these past few days, so he doesn't really want to talk to anybody."
    new "Nun, er war in den letzten Tagen etwas... Äh, unwohl, deshalb möchte er im Moment mit niemandem sprechen."

    # say L98 pla
    old "Unwell? Is he ok?"
    new "Unwohl? Geht es ihm gut?"

    # say L100 whi
    old "He's fine, but... Uhh, not really in a good mood."
    new "Er geht es gut, aber... Uhh, er ist im Moment nicht besonders gut gelaunt."

    # say L101 pla
    old "Hmm, is there something I can help with?"
    new "Hmm, gibt es etwas, bei dem ich helfen kann?"

    # say L103 whi
    old "Listen, he asked me not to tell anybody about this. But since you're one of his best friends I'll let you know."
    new "Hören Sie, er bat mich, niemandem davon zu erzählen. Aber da Sie einer seiner besten Freunde sind, werde ich es Ihnen sagen."

    # say L105 whi
    old "The thing is, his birthday was a couple of days ago... and nobody seemed to remember."
    new "Das Problem ist, sein Geburtstag war vor ein paar Tagen... und niemand schien sich daran zu erinnern."

    # say L106 pla
    old "Ohhh, damn! I totally forgot about it. Shit!"
    new "Ohhh, verdammt! Ich hab's total vergessen. Scheiße!"

    # say L107 whi
    old "Yes well, not one of his friends gave him a call, or even said happy birthday to him."
    new "Nun ja, keiner seiner Freunde hat ihn angerufen oder ihm überhaupt zum Geburtstag gratuliert."

    # say L108 pla
    old "Damn it, of course, he's angry."
    new "Verdammt, klar, er ist sauer."

    # say L109 whi
    old "The reason I tell you this is because Mike is always talking about you, he says you're his best friend."
    new "Der Grund, warum ich Ihnen das sage, ist, weil Mike ständig von Ihnen spricht, er sagt, Sie sind sein bester Freund."

    # say L112 whi
    old "He admires you a lot, you know..."
    new "Er schätzt Sie sehr, wissen Sie..."

    # say L113 pla
    old "D- do you think he'll talk to me if I try?"
    new "D- denkst du, er wird mit mir reden, wenn ich es versuche?"

    # say L114 whi
    old "Hmm, I don't really know... But I guess you can try. I actually think it would be good for him."
    new "Hmm, ich weiß es nicht so genau... Aber ich denke, Sie können es versuchen. Eigentlich glaube ich, dass es ihm guttun würde."

    # say L115 whi
    old "He's been really depressed lately. So, it would be good if you could help him out with that."
    new "Er ist lately wirklich sehr niedergeschlagen. Es wäre gut, wenn Sie ihm dabei helfen könnten."

    # say L117 pla
    old "Sure, sure, don't worry, I'll do my best to fix this."
    new "Klar, klar, machen Sie sich keine Sorgen, ich werde mein Bestes tun, um das zu regeln."

    # say L118 whi
    old "Ok,  then he's in his room. Good luck."
    new "Okay, dann ist er in seinem Zimmer. Viel Glück."

    # say L133 mik
    old "Ugh, did my mom let you in?"
    new "Ugh, hat meine Mom dich reingelassen?"

    # say L134 pla
    old "Hey man, listen, I'm really sorry. I've been dealing with some stuff, so, I forgot about your birthday."
    new "Hey Mann, hör zu, es tut mir echt leid. Ich hab gerade einiges zu tun gehabt, deshalb hab ich deinen Geburtstag vergessen."

    # say L135 pla
    old "But I totally care about it, really."
    new "Aber ich leg echt Wert drauf, ehrlich."

    # say L136 mik
    old "Oh yeah, you care?"
    new "Oh ja, dir ist es wichtig?"

    # say L137 mik
    old "That's funny, you seem to care a lot more about the girls' birthdays..."
    new "Das ist lustig, du scheinst dich viel mehr um die Geburtstage der Mädchen zu kümmern..."

    # say L138 mik
    old "But I guess it's no surprise since I'm always the one who's left out..."
    new "Aber ich schätze, das ist nicht überraschend, da ich immer derjenige bin, der links liegen bleibt..."

    # say L139 pla
    old "Aww, come on dude, you know it's not like that."
    new "Ach komm schon, Mann, du weißt doch, dass es nicht so ist."

    # say L140 pla
    old "It's just that recently I've been kinda busy."
    new "Es ist nur so, dass ich lately ziemlich beschäftigt war."

    # say L141 mik
    old "Yeah, yeah, yeah, you're always busy. I get it, you're Mr. important."
    new "Ja, ja, ja, du bist immer beschäftigt. Klar, du bist der Wichtige."

    # say L142 pla
    old "Hey Mike, come on man, listen to me."
    new "Hey Mike, komm schon Mann, hör mir zu."

    # say L143 mik
    old "No! You listen. It's just unbelievable man, like, wow."
    new "Nein! Du hörst zu. Das ist echt unglaublich, Mann, wow."

    # say L144 mik
    old "You know, I've always been there for you when you needed it!"
    new "Du weißt, ich war immer für dich da, wenn du mich gebraucht hast!"

    # say L146 pla
    old "I know dude, I'm sorry."
    new "Ich weiß, Kumpel, tut mir leid."

    # say L148 mik
    old "You know what? It's ok, it's not like it's the first time anyway. So I'm used to it. I really don't have any friends."
    new "Weißt du was? Ist okay, ist ja nicht das erste Mal. Ich bin dran gewöhnt. Ich hab eh keine Freunde."

    # say L149 pla
    old "Hey don't say that, you know very well I'm your friend."
    new "Hey, sag das nicht, du weißt doch, dass ich dein Freund bin."

    # say L150 pla
    old "And what do you mean it's not the first time, it was just this year that I forgot your birthday."
    new "Und was meinst du mit nicht das erste Mal? Es war doch erst dieses Jahr, dass ich deinen Geburtstag vergessen habe."

    # say L151 mik
    old "Oh shut up! I'm not talking about my birthday. Remember Halloween?"
    new "Oh halt die Klappe! Ich rede nicht von meinem Geburtstag. Erinnerst du dich an Halloween?"

    # say L152 mik
    old "When we were playing that game you guys made fun of me. And had me leave with that stupid challenge."
    new "Als wir dieses Spiel gespielt haben, habt ihr mich ausgelacht. Und dann musste ich wegen dieser blöden Herausforderung gehen."

    # say L153 mik
    old "Of course, you didn't want me there."
    new "Natürlich wolltest du mich da nicht haben."

    # say L156 pla
    old "Listen dude..."
    new "Hör zu, Alter..."

    # say L157 mik
    old "Shut up! Keep your excuses to yourself."
    new "Halt die Klappe! Behalt deine Ausreden für dich."

    # say L158 mik
    old "And get the hell out of here. I'm busy."
    new "Und verpiss dich hier. Ich hab zu tun."

    # say L159 pla
    old "Mike, please, calm down."
    new "Mike, bitte, beruhige dich."

    # say L160 pla
    old "Thinking about it, I can see your point, you're absolutely right."
    new "Mike, ich kann deinen Standpunkt verstehen, du hast absolut recht."

    # say L161 pla
    old "I've been a really shitty friend."
    new "Ich war echt ein beschissener Freund."

    # say L162 pla
    old "So... I'm really sorry bud, and I hope you can forgive me."
    new "Also... Es tut mir echt leid, Kumpel, und ich hoffe, du kannst mir verzeihen."

    # say L163 mik
    old "Pfff! Get out of here!"
    new "Pfff! Verschwinde!"

    # say L164 mik
    old "Do you really think you can get out of this with a simple apology?"
    new "Glaubst du wirklich, du kommst damit durch, nur weil du dich entschuldigst?"

    # say L165 pla
    old "Hmm... You're right... And I think I can do something to show you I'm your friend."
    new "Hmm... Du hast recht... Und ich denke, ich kann etwas tun, um dir zu zeigen, dass ich dein Freund bin."

    # say L166 pla
    old "And this is kinda risky, so I know you'll believe me once you see it."
    new "Und das ist ziemlich riskant, deshalb weiß ich, dass du mir glaubst, wenn du es siehst."

    # say L169 pla
    old "Come with me for a second."
    new "Komm mit mir einen Moment."

    # say L170 mik
    old "Where?"
    new "Wo?"

    # say L171 pla
    old "I have to show you something."
    new "Ich muss dir was zeigen."

    # say L172 pla
    old "Just shut up and come with me."
    new "Halt einfach die Klappe und komm mit mir."

    # say L173 pla
    old "If afterwards you're still mad at me I'll leave you alone."
    new "Wenn danach du immer noch sauer auf mich bist, lass ich dich in Ruhe."

    # say L174 pla
    old "But this is worth it."
    new "Aber das ist es wert."

    # say L176 mik
    old "Hmm, ok, let's go."
    new "Hmm, okay, lass uns gehen."

    # say L192 mik
    old "What's this? Where are you taking me?"
    new "Was ist das? Wohin bringst du mich?"

    # say L193 pla
    old "It's ok dude. Just trust me, you'll like this."
    new "Alles gut, Mann. Vertrau mir einfach, dir wird das gefallen."

    # say L218 mik
    old "What the fuck? This is my neighbor's house. What are we doing here?"
    new "Was zur Hölle? Das ist das Haus meiner Nachbarin. Was machen wir hier?"

    # say L219 pla
    old "Chill out dude. It's ok, I know her."
    new "Beruhige dich, Mann. Alles gut, ich kenne sie."

    # say L220 pla
    old "Just as I thought, If she's not here, that means she'll be probably with a customer upstairs."
    new "Genau wie ich dachte, wenn sie nicht hier ist, bedeutet das, dass sie wahrscheinlich oben bei einem Kunden ist."

    # say L223 pla
    old "I think I can show you something worthwhile. Just hush and follow me."
    new "Ich denke, ich kann dir was Interessantes zeigen. Sei still und folge mir."

    # say L247 pla
    old "Great, they're in there."
    new "Super, die sind da drin."

    # say L248 mik
    old "They? What's happening?"
    new "Sie? Was passiert hier?"

    # say L249 pla
    old "Listen man, this is something I'm doing only this one time."
    new "Hör zu, Mann, das mache ich nur dieses eine Mal."

    # say L250 pla
    old "Take it as my birthday gift to you."
    new "Nimm es als mein Geburtstagsgeschenk für dich."

    # say L251 pla
    old "Now come here and take a peek."
    new "Komm her und sieh es dir an."

    # say L260 mik
    old "Dude! Wow!"
    new "Kerl! Wow!"

    # say L261 mik
    old "I would never have been able to see this through my telescope!"
    new "Ich hätte das nie durch mein Teleskop sehen können!"

    # say L262 mik
    old "How did you know she does this kind of stuff?"
    new "Wie hast du gewusst, dass sie so was macht?"

    # say L263 pla
    old "Just shut up and enjoy it."
    new "Halt die Klappe und genieße es."

    # say L264 mik
    old "I will man, you're the best."
    new "Klar, Mann, du bist der Beste."

    # say L274 mik
    old "Dude, that was the best birthday present ever!"
    new "Dude, das war das beste Geburtstagsgeschenk aller Zeiten!"

    # say L275 pla
    old "Well, I'm glad you liked it."
    new "Na klar, freut mich, dass es dir gefallen hat."

    # say L276 pla
    old "I just wanted to say sorry again for being such a lousy friend."
    new "Ich wollte mich einfach nochmal entschuldigen, dass ich so ein schlechter Freund war."

    # say L277 pla
    old "And listen, man, I know you think you're all alone, but that's not true."
    new "Und hör zu, Mann, ich weiß, du denkst, du bist ganz allein, aber das stimmt nicht."

    # say L278 pla
    old "I really do think of you as my best friend, and I'm sure the girls... Uhh, they find you as a good classmate..."
    new "Ich denke echt, dass du mein bester Freund bist, und ich bin mir sicher, die Mädels... Äh, sie finden dich auch als einen guten Klassenkameraden..."

    # say L279 pla
    old "It's just that lately we all have been dealing with some stuff."
    new "Es ist nur so, dass wir alle in letzter Zeit mit ein paar Dingen zu tun haben."

    # say L280 pla
    old "But I want you to know that I would never take you for granted."
    new "Aber ich will, dass du weißt, dass ich dich nie als selbstverständlich betrachte."

    # say L282 mik
    old "It's ok man, I was angry, but you've more than made up for it with that awesome gift."
    new "Ist schon gut, Mann, ich war sauer, aber du hast das mehr als wettgemacht mit diesem tollen Geschenk."

    # say L283 mik
    old "It was so fucking rad."
    new "Das war so verdammt krass."

    # say L284 pla
    old "Well I'm happy we're ok now. But I kinda have to leave."
    new "Dann bin ich froh, dass wir uns wieder vertragen. Aber ich muss jetzt los."

    # say L285 pla
    old "I have to do a couple of things, but I'll swing by later."
    new "Ich muss noch ein paar Dinge erledigen, aber ich komme später vorbei."

    # say L286 mik
    old "Wait, Dude!"
    new "Warte, Kumpel!"

    # say L288 mik
    old "Before you leave, there's something I have to ask you."
    new "Bevor du gehst, gibt es was, das ich dich fragen muss."

    # say L289 pla
    old "Hmm, sure, tell me."
    new "Hmm, klar, sag's mir."

    # say L290 mik
    old "Hmm, the thing is... I don't really know how to say this..."
    new "Hmm, die Sache ist... ich weiß echt nicht, wie ich das sagen soll..."

    # say L291 mik
    old "I'm gonna need you to help me study for a subject..."
    new "Ich brauch deine Hilfe, um für ein Fach zu lernen..."

    # say L292 pla
    old "What? Haha! But you've never wanted to study with us before."
    new "Was? Haha! Aber du hast noch nie mit uns lernen wollen."

    # say L293 pla
    old "Why now all of a sudden?"
    new "Warum jetzt plötzlich?"

    # say L295 mik
    old "It's because it's super lame."
    new "Weil es total langweilig ist."

    # say L296 mik
    old "But you see, this time is not really for me."
    new "Aber siehst du, dieses Mal geht es nicht wirklich um mich."

    # say L297 mik
    old "I told Olivia I would help her with her studies, so I kinda have to learn the subject."
    new "Ich hab Olivia versprochen, ihr bei den Studien zu helfen, also muss ich mich jetzt echt mit dem Stoff auseinandersetzen."

    # say L298 pla
    old "Oh, really? Hahahahahaha!"
    new "Oh, wirklich? Hahahahahaha!"

    # say L299 mik
    old "Dude! Don't laugh, this is important, ok?"
    new "Kumpel! Lach nicht, das ist wichtig, okay?"

    # say L300 pla
    old "Heh, s- sure, sorry."
    new "Heh, s-sicher, tut mir leid."

    # say L302 mik
    old "Well anyway, the point is that I'm gonna need your help to learn the subjects."
    new "Na ja, egal, der Punkt ist, dass ich deine Hilfe brauche, um die Fächer zu lernen."

    # say L303 mik
    old "'Cause you'll help me out, right? I mean, we're friends..."
    new "Denn du wirst mir helfen, oder? Ich meine, wir sind Freunde..."

    # say L304 pla
    old "*Sigh*"
    new "Na klar, wenn du es wirklich brauchst, helfe ich dir. Aber Mann, ist sie nicht immer total gemein zu uns?"

    # say L305 pla
    old "I mean, sure, if you really need it I'll help you out."
    new "Klar, wenn du es wirklich brauchst, helfe ich dir."

    # say L306 pla
    old "But dude, isn't she always super mean to us?"
    new "Aber Mann, ist sie nicht immer total gemein zu uns?"

    # say L307 pla
    old "You've heard the way she and Ruby talk to us."
    new "Du hast gehört, wie sie und Ruby mit uns reden."

    # say L308 pla
    old "Like... You know?"
    new "Wie... Du weißt schon?"

    # say L309 mik
    old "I know, I know. But the thing is..."
    new "Ich weiß, ich weiß. Aber das Ding ist..."

    # say L310 mik
    old "I actually like that, a lot if I can be honest."
    new "Ich mag das echt, total ehrlich."

    # say L311 pla
    old "What? Are you for real right now?"
    new "Was? Ernsthaft jetzt?"

    # say L312 pla
    old "What could you possibly like about that?"
    new "Was könnte dir daran gefallen?"

    # say L313 mik
    old "To be honest, I don't know why, but I love it when girls are mean to me. It's so hot!"
    new "Ehrlich gesagt, ich weiß auch nicht warum, aber ich finde es total geil, wenn Mädchen gemein zu mir sind. Es ist so heiß!"

    # say L314 mik
    old "Mmm, even the other day when they were insulting us in the hallway."
    new "Mmm, sogar neulich, als sie uns im Flur beschimpft haben."

    # say L315 mik
    old "Uhh man, I almost got a hard-on!"
    new "Uhh Mann, ich bin fast hart geworden!"

    # say L317 pla
    old "Ok, I get it, you're a freak. But it's fine I guess."
    new "Ok, ich kapiere, du bist ein Freak. Aber egal, ist ja gut."

    # say L318 pla
    old "Ok man, I guess I can help you, I'm not sure what you need exactly though."
    new "Ok Mann, ich denke ich kann dir helfen, bin mir aber nicht sicher, was du genau brauchst."

    # say L319 mik
    old "Well, I have to give her classes on those subjects. So, something that will help me with that."
    new "Na ja, ich muss ihr Kurse zu diesen Themen geben. Also, etwas, das mir dabei hilft."

    # say L320 pla
    old "Hmm, I think I know what we can do."
    new "Hmm, ich glaube, ich weiß, was wir machen können."

    # say L321 pla
    old "How about I give you the classes, and you just repeat them to Olivia?"
    new "Was hältst du davon, wenn ich dir die Kurse gebe und du sie dann an Olivia weitergibst?"

    # say L323 mik
    old "Ohh, that sounds perfect."
    new "Ohh, das klingt perfekt."

    # say L324 pla
    old "But, you're gonna have to pay a lot of attention to everything I tell you."
    new "Aber du musst mir gut zuhören, alles was ich dir sage."

    # say L325 pla
    old "After all it won't be useful if she asks you a question and you can't answer ir properly."
    new "Denn es bringt nichts, wenn sie dich was fragt und du die Antwort nicht parat hast."

    # say L326 mik
    old "Sure, sure, sure. No problem man, I'm sure I'll learn it all."
    new "Klar, klar, klar. Kein Problem, Mann, ich bin sicher, ich lerne das alles."

    # say L328 pla
    old "Well, with that sorted out, I'll go home. And we can meet after class to study."
    new "Na gut, dann geh ich jetzt nach Hause. Und wir treffen uns nach der Schule zum Lernen."

    # say L330 mik
    old "No problem. Thank you so much dude! You're the best."
    new "Kein Problem. Danke dir so viel! Du bist der Beste."

    # say L332 pla
    old "Yeah, yeah, but don't be so quick to thank me. We don't know if this will work."
    new "Klar, klar, aber sei nicht so schnell dankbar. Wir wissen noch nicht, ob das klappt."

    # say L333 mik
    old "I'll do my best, I promise!"
    new "Ich werde mein Bestes geben, das verspreche ich!"

    # say L334 pla
    old "Alright, see you later."
    new "Okay, dann bis später."

    # say L360 whi
    old "Hi [pla]! How are you? It's so nice to see you."
    new "Hi [pla]! Wie geht es Ihnen? Es ist so schön, Sie zu sehen."

    # say L361 pla
    old "Hi Mrs. White, nice seeing you too."
    new "Hallo Mrs. White, schön, Sie auch zu sehen."

    # say L362 whi
    old "Let me tell you something. I don't know what you said to Mike."
    new "Lassen Sie mich etwas sagen. Ich weiß nicht, was Sie zu Mike gesagt haben."

    # say L363 whi
    old "But since you two talked, he's been in a much better mood. Thank you so much for that."
    new "Aber seit Sie miteinander gesprochen haben, ist er in einer viel besseren Stimmung. Vielen Dank dafür."

    # say L364 pla
    old "No problem, I'm happy we got to sort things out."
    new "Kein Problem, ich freue mich, dass wir das geklärt haben."

    # say L365 whi
    old "You did a great job."
    new "Sie haben eine großartige Arbeit geleistet."

    # say L366 whi
    old "So good that I've been thinking maybe I should give you a small reward."
    new "So gut, dass ich darüber nachgedacht habe, dir vielleicht eine kleine Belohnung zu geben."

    # say L367 pla
    old "Oh, I appreciate it, but you really don't have to."
    new "Oh, danke, aber das musst du wirklich nicht."

    # say L368 pla
    old "I was just trying to be a good friend, and help him out."
    new "Ich wollte einfach nur ein guter Freund sein und ihm helfen."

    # say L369 pla
    old "Also, I don't want it to be of any trouble."
    new "Also, ich will nicht, dass es dir zur Last fällt."

    # say L370 whi
    old "Oh, but it's no trouble sweety, you've been very good to Mike."
    new "Oh, aber das ist doch keine Mühe, Schatz, du warst sehr gut zu Mike."

    # say L371 whi
    old "And I believe that deserves a good reward."
    new "Und ich glaube, das verdient eine gute Belohnung."

    # say L372 pla
    old "Uhh, I'm very thankful Mrs. White, but I think I'm ok."
    new "Uhh, ich bin sehr dankbar, Mrs. White, aber ich denke, ich bin okay."

    # say L373 pla
    old "And... uh, I kinda have to go study with Mike now, so..."
    new "Und... ähm, ich muss jetzt eigentlich mit Mike lernen, also..."

    # say L374 whi
    old "Hmm, yeah, that's right, you two have to study. Go ahead."
    new "Hmm, ja, das stimmt, Sie beide müssen lernen. Gehen Sie ruhig."

    # say L375 whi
    old "In the meantime I'll think of something."
    new "In der Zwischenzeit werde ich mir etwas überlegen."

    # say L376 whi
    old "And I'm sure you'll love it."
    new "Und ich bin sicher, Sie werden es lieben."

    # say L377 whi
    old "I see you later sweety."
    new "Bis später, Schatz."

    # say L378 pla
    old "See you later Mrs. White."
    new "Bis später, Mrs. White."

    # say L388 mik
    old "[pla] dude! Hi!"
    new "[pla] Kumpel! Hallo!"

    # say L389 mik
    old "Did you come to study?"
    new "Bist du gekommen, um zu lernen?"

    # say L390 pla
    old "Yeah dude, I figured you'd want to start as soon as possible."
    new "Klar, Mann, ich dachte, du willst so schnell wie möglich anfangen."

    # say L391 mik
    old "For sure, my first session with Olivia's coming soon."
    new "Klar, mein erstes Treffen mit Olivia steht bald an."

    # say L392 mik
    old "And I don't know shit about the subject."
    new "Und ich hab keine Ahnung von dem Thema."

    # say L393 pla
    old "Don't you say..."
    new "Sag bloß..."

    # say L394 pla
    old "But that's why I'm here, so let's get to it."
    new "Aber deshalb bin ich hier, also lass uns anfangen."

    # say L396 mik
    old "Let's do it dude..."
    new "Lass es uns machen, Kumpel..."

    # say L410 whi
    old "Oh, [pla]! Did you and Mike finish already? How did it go?"
    new "Oh, [pla]! Haben Sie und Mike schon fertig? Wie war es?"

    # say L411 pla
    old "That's right Mrs. White, we actually progressed quite a bit."
    new "Das stimmt, Mrs. White, wir sind tatsächlich ziemlich weit gekommen."

    # say L412 pla
    old "Mike has been putting in quite some effort to study, so he caught the lesson really quick."
    new "Mike hat sich echt ins Zeug gelegt, um den Stoff zu kapieren, deshalb hat er die Lektion ziemlich schnell draufgehabt."

    # say L414 whi
    old "But wait, leaving so soon?"
    new "Aber warten Sie, schon gehen?"

    # say L415 pla
    old "Well, yeah, since we're done, and it's getting kinda late."
    new "Na ja, ja, da wir fertig sind und es schon ziemlich spät wird."

    # say L416 pla
    old "I thought it would be better to go home."
    new "Ich dachte, es wäre besser, nach Hause zu gehen."

    # say L418 whi
    old "Oh no, no, no. I just finished making dinner. Stay and have dinner with us."
    new "Oh nein, nein, nein. Ich habe gerade das Abendessen fertig gemacht. Bleiben Sie und essen Sie mit uns."

    # say L420 pla
    old "Hmm, I don't know Mrs. White, I'm very thankful, but I don't want it to be of any trouble."
    new "Hmm, ich weiß nicht, Mrs. White, ich bin sehr dankbar, aber ich will niemandem zur Last fallen."

    # say L421 whi
    old "Don't be silly"
    new "Seien Sie nicht albern"

    # say L422 whi
    old "It's only an extra plate, besides you must be tired from studying with Mike."
    new "Es ist nur ein zusätzlicher Teller, außerdem müssen Sie sicher müde von dem Lernen mit Mike sein."

    # say L423 whi
    old "And you've been so good, not only did you talk to Mike when he was angry."
    new "Und Sie waren so gut, nicht nur haben Sie mit Mike geredet, als er wütend war."

    # say L424 whi
    old "You're also helping him study."
    new "Sie helfen ihm auch beim Lernen."

    # say L425 whi
    old "The least I can do is invite you to have some dinner with us."
    new "Das Mindeste, was ich tun kann, ist dich einzuladen, mit uns zu Abend zu essen."

    # say L426 whi
    old "I can't just let you leave like that."
    new "Ich kann Sie nicht einfach so gehen lassen."

    # say L433 mik
    old "Hey, mom, I'm hungry. It's dinner ready?"
    new "Hey, Mama, ich hab Hunger. Ist das Essen fertig?"

    # say L435 mik
    old "Oh [pla], you're still here?"
    new "Oh [pla], du bist noch da?"

    # say L436 whi
    old "Dinner's ready honey, I was just telling your friend that he should stay for it."
    new "Das Abendessen ist fertig, Schatz, ich habe deinem Freund gerade gesagt, dass er bleiben soll."

    # say L437 mik
    old "For sure dude! You should totally stay."
    new "Klar, Mann! Du solltest echt bleiben."

    # say L438 mik
    old "My mom makes the best pot roast you'll ever try, trust me you'll like it."
    new "Meine Mum macht das beste Rindfleisch, das du je probieren wirst, vertrau mir, du wirst es lieben."

    # say L439 whi
    old "Oh he's gonna love it."
    new "Oh, er wird es lieben."

    # say L441 pla
    old "All right, if you insist, I can't say no..."
    new "Na gut, wenn Sie darauf bestehen, kann ich nicht nein sagen..."

    # say L442 pla
    old "Thanks a lot Mrs. White, I really appreciate it."
    new "Vielen Dank, Mrs. White, ich schätze es sehr."

    # say L443 mik
    old "Let's go then!"
    new "Dann lass uns gehen!"

    # say L457 whi
    old "So tell me, how are your studies going? And your grades?"
    new "Erzählen Sie mir, wie läuft es mit Ihren Studien? Und Ihre Noten?"

    # say L458 whi
    old "I hope everything's going well with your exams."
    new "Ich hoffe, es läuft gut mit Ihren Prüfungen."

    # say L459 mik
    old "Well, Belle and I are doing well on our end of term project."
    new "Na, Belle und ich machen uns gut bei unserem Semesterprojekt."

    # say L460 mik
    old "She's really smart, and has helped me a lot with that."
    new "Sie ist wirklich klug und hat mir dabei sehr geholfen."

    # say L464 mik
    old "Oh right [pla], you did yours with Hin, right?"
    new "Oh stimmt [pla], du hast deins mit Hin gemacht, oder?"

    # say L465 mik
    old "How did that go?"
    new "Wie war das?"

    # say L467 pla
    old "Uhh... W- well, it went really... well."
    new "Uhh... W- wohlgemerkt, es ist wirklich gut gelaufen."

    # say L468 pla
    old "Really well actually, Hin is a very good student, so we flew through it."
    new "Eigentlich ganz gut, Hin ist eine sehr gute Schülerin, da sind wir ziemlich schnell durchgekommen."

    # say L470 mik
    old "Uh, that makes sense, of course she would do a good job."
    new "Das ergibt Sinn, natürlich würde sie gute Arbeit leisten."

    # say L471 mik
    old "Specially since she's so into you."
    new "Vor allem, weil sie total auf dich steht."

    # say L474 mik
    old "Please dude, don't play fool, she's sooo got a thing for you."
    new "Komm schon, spiel nicht den Unwissenden, sie hat total was für dich übrig."

    # say L475 pla
    old "I don't know what you're talking about, we're just friends..."
    new "Ich hab keine Ahnung, wovon du redest, wir sind einfach nur Freunde..."

    # say L476 whi
    old "Hinn is Jade's daugther, right? She's such a nice, smart girl."
    new "Hinn ist Jades Tochter, richtig? Sie ist so ein nettes, kluges Mädchen."

    # say L477 whi
    old "Are you two dating?"
    new "Sind Sie beide ein Paar?"

    # say L479 pla
    old "No, we're not. Mike's just messing with me."
    new "Nein, wir sind das nicht. Mike spinnt einfach."

    # say L480 mik
    old "Come on, she totally likes you..."
    new "Komm schon, sie mag dich total..."

    # say L483 pla
    old "She's just a good friend. That's all there is to it."
    new "Sie ist einfach eine gute Freundin. Das ist alles."

    # say L485 whi
    old "Hmm, I see [pla] is a total succes with girls, isn't he?"
    new "Hmm, ich sehe, [pla] hat ja wirklich Erfolg bei den Mädchen, oder?"

    # say L486 mik
    old "Only Hin."
    new "Nur Hinn."

    # say L487 mik
    old "I don't know what she see's in you dude."
    new "Ich hab echt keine Ahnung, was sie an dir findet, Alter."

    # say L489 whi
    old "Oh, but he's a total heartthrob."
    new "Oh, aber er ist ein richtiger Herzensbrecher."

    # say L490 whi
    old "Hin's very bright for liking you [pla]."
    new "Hin ist sehr klug, dass sie Sie mag [pla]."

    # say L491 pla
    old "Uhhh, yeah... yeah she's really smart, but just a good friend."
    new "Uhhh, ja... ja, sie ist wirklich klug, aber nur eine gute Freundin."

    # say L493 whi
    old "I see, that's very good."
    new "Ich sehe, das ist sehr gut."

    # say L494 whi
    old "By the way what are your projects about?"
    new "Ach ja, worum geht es denn in Ihren Projekten?"

    # say L495 mik
    old "Ugh, some online content creation thing Belle said we should do."
    new "Ugh, irgendeine Online-Inhaltskreation, von der Belle gesagt hat, dass wir das machen sollen."

    # say L496 mik
    old "It's a research project."
    new "Es ist ein Forschungsprojekt."

    # say L497 mik
    old "She's very into those subjects."
    new "Sie ist sehr in diese Themen vertieft."

    # say L498 whi
    old "And you [pla]? What are you and your friend Hin doing?"
    new "Und Sie [pla]? Was machen Sie und Ihr Freund Hinn so?"

    # say L499 pla
    old "We... Uhh, we have a psychology project."
    new "Wir... Äh, wir haben ein Psychologieprojekt."

    # say L500 pla
    old "About personal development and self confidence and stuff."
    new "Über persönliche Entwicklung und Selbstbewusstsein und so."

    # say L502 whi
    old "Oh, I see, interesting."
    new "Oh, ich verstehe, interessant."

    # say L509 whi
    old "It sounds like a very, very HARD subject."
    new "Das klingt nach einem sehr, sehr SCHWIERIGEN Thema."

    # say L510 pla
    old "I- it kind of is..."
    new "I- es ist schon so..."

    # say L529 whi
    old "I imagine you must be working very very... hard."
    new "Ich stelle mir vor, Sie müssen sehr, sehr... hart arbeiten."

    # say L531 mik
    old "Yes, we really are."
    new "Ja, wir arbeiten wirklich sehr hart."

    # say L544 pla
    old "The food was delicious Mrs. White, thanks a lot."
    new "Dieahrung war köstlich, Mrs. White, vielen Dank."

    # say L545 pla
    old "But it's getting kinda late. So, if you'll excuse me I should go home."
    new "Aber es wird langsam spät. Wenn Sie mich also entschuldigen, ich sollte nach Hause gehen."

    # say L546 pla
    old "But I'll be back soon to keep studying, Mike."
    new "Aber ich komme bald wieder, um weiterzulernen, Mike."

    # say L547 whi
    old "That's ok sweety, I'm glad to hear you liked dinner."
    new "Das ist in Ordnung, Schatz, ich freue mich, dass dir das Abendessen geschmeckt hat."

    # say L548 whi
    old "And I'm also glad you had a good time."
    new "Und ich freue mich auch, dass du es gut hattest."

    # say L549 pla
    old "Yes, it was... very good. You've got marvelous hands Mrs. White... For the kitchen of course..."
    new "Ja, es war... sehr gut. Sie haben wunderbare Hände, Mrs. White... Im Küchenbereich natürlich..."

    # say L550 whi
    old "You should stay for dinner more often.."
    new "Sie sollten öfter zum Abendessen bleiben."

    # say L551 whi
    old "So, you don't have to worry about coming here, and spending all the time you want."
    new "Sie müssen sich also keine Sorgen machen, hierherzukommen und so viel Zeit zu verbringen, wie Sie wollen."

    # say L552 pla
    old "Thanks a lot Mrs. White, that's very kind of you."
    new "Vielen Dank, Mrs. White, das ist sehr nett von Ihnen."

    # say L553 whi
    old "I'm always happy to have some extra company here. And you know you're more than welcome."
    new "Ich freue mich immer, wenn ich hier etwas Gesellschaft habe. Und Sie wissen, dass Sie jederzeit willkommen sind."

    # say L554 pla
    old "Uhh, sure, thank you."
    new "Uhh, klar, danke."

    # say L555 pla
    old "I think I should go now."
    new "Ich denke, ich sollte jetzt gehen."

    # say L557 whi
    old "Get home safe. See you later sweetie."
    new "Passen Sie auf dem Heimweg auf. Bis später, Schatz."

    # say L559 mik
    old "Later dude."
    new "Bis später, Alter."

    # say L560 pla
    old "Ok, bye..."
    new "Okay, tschüss..."

    # say L577 mik
    old "[pla] dude! Hi! What's up?"
    new "[pla] Kumpel! Hallo! Was gibt’s?"

    # say L578 mik
    old "Did you come to help me study?"
    new "Bist du gekommen, um mir beim Lernen zu helfen?"

    # say L579 pla
    old "Yeah dude, that's right."
    new "Klar, Alter, stimmt genau."

    # say L580 mik
    old "Oh thank god, my next session with Olivia's coming soon."
    new "Oh danke Gott, mein nächstes Treffen mit Olivia steht bald an."

    # say L581 mik
    old "And I was getting worried, because I'm not ready for her class."
    new "Und ich hab mir schon Sorgen gemacht, weil ich noch nicht für ihren Kurs bereit bin."

    # say L582 pla
    old "Well that's why I'm here. Are you ready to start?"
    new "Dann bin ich ja gerade rechtzeitig gekommen. Bist du bereit, anzufangen?"

    # say L583 mik
    old "Yeah I'm ready, let's do this!"
    new "Ja, ich bin bereit, lass es uns machen!"

    # say L594 pla
    old "Wow! Dude! You got it right! I didn't know you were so good at this!"
    new "Wow! Alter! Du hast es drauf! Ich wusste gar nicht, dass du so gut darin bist!"

    # say L595 pla
    old "I mean, if you studied like that more often you'd have straight A's."
    new "Ich meine, wenn du so oft studierst, hättest du nur Einsen."

    # say L596 mik
    old "Hehe, thanks man, I've tried to pay attention to what you've taught me."
    new "Hehe, danke Mann, ich hab versucht, auf das zu achten, was du mir gezeigt hast."

    # say L597 mik
    old "So that I can teach it to Olivia."
    new "Damit ich es Olivia beibringen kann."

    # say L598 pla
    old "Well I'm sure it's gonna go great if you keep going like that."
    new "Na klar, ich bin sicher, es wird super laufen, wenn du so weitermachst."

    # say L599 pla
    old "So, listen dude, it's getting kinda late, so, I should go home."
    new "Hör mal, es wird langsam spät, ich sollte nach Hause gehen."

    # say L600 pla
    old "But I'll be back before your next session with Olivia."
    new "Aber ich bin wieder da, bevor du dein nächstes Treffen mit Olivia hast."

    # say L602 mik
    old "Sure man, thanks a lot. See you later."
    new "Klar, danke Mann. Bis später."

    # say L652 mik
    old "Damn, I'm sorry dude. I suck at this so much."
    new "Verdammt, ich bin echt schlecht darin."

    # say L653 mik
    old "I think I'm just wasting your time."
    new "Ich denke, ich verschwende nur deine Zeit."

    # say L654 pla
    old "Nah, it's ok, this isn't an easy topic anyway."
    new "Nah, ist okay, das ist kein leichtes Thema."

    # say L655 pla
    old "We still got some time before you have to teach Olivia. So let's just relax."
    new "Wir haben noch Zeit, bevor du Olivia unterrichten musst. Lass uns einfach entspannen."

    # say L656 mik
    old "I can't relax dude! I told Olivia I was gonna teach her and I'm not ready."
    new "Ich kann mich nicht entspannen, Mann! Ich hab Olivia versprochen, sie zu unterrichten, und ich bin noch nicht bereit."

    # say L657 pla
    old "I know, man, I know."
    new "Ich weiß, Mann, ich weiß."

    # say L658 pla
    old "I'm sure you'll get it before the day."
    new "Ich bin sicher, du kriegst das noch hin bevor der Tag anfängt."

    # say L659 mik
    old "Hmm... You're probably right [pla], sorry I got a little anxious."
    new "Hmm... Du hast wahrscheinlich recht [pla], sorry, ich bin ein bisschen nervös geworden."

    # say L660 mik
    old "Let's just try again, I'm sure I'll do better this time."
    new "Lass uns einfach noch mal versuchen, ich bin sicher, ich werde es dieses Mal besser machen."

    # say L662 pla
    old "Nah, I don't think we should keep going today"
    new "Nein, ich glaube, wir sollten heute nicht weitermachen."

    # say L663 pla
    old "We're already tired, and just forcing this won't help."
    new "Wir sind schon müde, und es bringt nichts, wenn wir uns jetzt quälen."

    # say L664 pla
    old "Besides, it's kinda late, so I think I better go home for now."
    new "Außerdem ist es schon ziemlich spät, also denke ich, ich sollte jetzt besser nach Hause gehen."

    # say L665 pla
    old "And we can pick it up another time."
    new "Und wir können es ein anderes Mal weitermachen."

    # say L667 mik
    old "Sure, you're probably right."
    new "Klar, Sie haben wahrscheinlich recht."

    # say L686 whi
    old "Hello [pla] I'm so glad to see you."
    new "Hallo [pla], ich freue mich so, Sie zu sehen."

    # say L687 pla
    old "Hi Mrs. White, how are you?"
    new "Hallo Mrs. White, wie geht es Ihnen?"

    # say L688 whi
    old "I'm fine sweetie, and you?"
    new "Ich bin gut, Liebling, und Sie?"

    # say L690 whi
    old "Let me guess, you came to see Mike, right?"
    new "Lass mich raten, du bist gekommen, um Mike zu sehen, richtig?"

    # say L691 pla
    old "That's right, we'd planned another study session for today."
    new "Das stimmt, wir hatten heute wieder eine Lernsession geplant."

    # say L692 whi
    old "Well sweetie, I'm sorry to tell you he isn't here."
    new "Nun, Liebes, es tut mir leid, aber er ist nicht hier."

    # say L693 whi
    old "I don't know if he forgot to tell you, but he said he was meeting a girl to study."
    new "Ich weiß nicht, ob er es Ihnen gesagt hat, aber er wollte sich mit einem Mädchen treffen, um zu lernen."

    # say L694 pla
    old "Oh right! Damn, I totally forgot about that."
    new "Oh richtig! Verdammt, ich hab's total vergessen."

    # say L695 pla
    old "He did say something about it."
    new "Er hat was davon gesagt."

    # say L696 pla
    old "Well, I guess I'm gonna have to come back later. Please tell him I came by."
    new "Dann muss ich wohl später noch mal kommen. Sag ihm bitte, dass ich vorbeigeschaut habe."

    # say L702 whi
    old "But, wait [pla]!"
    new "Aber, warten Sie [pla]!"

    # say L706 pla
    old "Y- yes?"
    new "Y- ja?"

    # say L707 whi
    old "Sweetie it would be a shame if you left just after getting here."
    new "Schätzchen, es wäre schade, wenn du gerade erst angekommen wärst und schon wieder gehen würdest."

    # say L708 whi
    old "Why don't you stay for a little while?"
    new "Warum bleiben Sie nicht noch ein bisschen?"

    # say L709 whi
    old "You can make me some company."
    new "Sie können mir Gesellschaft leisten."

    # say L711 whi
    old "I actually was about to move around the furniture in my room."
    new "Ich wollte eigentlich das Mobiliar in meinem Zimmer umstellen."

    # say L712 whi
    old "I could use your help and I thought maybe a big and strong guy like you could help me out."
    new "Ich könnte Ihre Hilfe gebrauchen und ich dachte, vielleicht kann mir ein großer und starker Mann wie Sie helfen."

    # say L713 pla
    old "Heh, sure, I can help you out."
    new "Heh, klar, ich helfe dir."

    # say L715 whi
    old "Come on up, I'll show you what I need."
    new "Kommen Sie rein, ich zeige Ihnen, was ich brauche."

    # say L726 pla
    old "Ok, Mrs. White, what do you want me to help you with?"
    new "Okay, Mrs. White, was soll ich Ihnen helfen?"

    # say L734 whi
    old "You see... I figured, since we're alone."
    new "Sie sehen... ich dachte, da wir alleine sind."

    # say L735 whi
    old "Why don't we have a little bit of fun?"
    new "Warum machen wir nicht ein bisschen Spaß?"

    # say L736 pla
    old "B- But, Mrs. White, what happens if Mike catches us?"
    new "Aber, Mrs. White, was passiert, wenn Mike uns erwischt?"

    # say L737 whi
    old "You worry too much."
    new "Sie machen sich zu viele Sorgen."

    # say L738 whi
    old "He won't be home for a while, besides, this is my room. So he won't come in without knocking first."
    new "Er wird noch eine Weile nicht zu Hause sein, undßerdem ist das mein Zimmer. Also wird er nicht herein kommen, ohne vorher anzuklopfen."

    # say L739 whi
    old "We have time and privacy."
    new "Wir haben Zeit und Privatsphäre."

    # say L740 whi
    old "So don't worry and let's just enjoy."
    new "Also machen Sie sich keine Sorgen und lassen Sie uns einfach genießen."

    # say L741 pla
    old "I mean, I- I understand what you're saying, but I think it's too risky."
    new "Ich meine, ich- ich verstehe, was du sagst, aber ich finde es zu riskant."

    # say L742 whi
    old "Oh please, don't act like you don't want it."
    new "Oh bitte, tun Sie nicht so, als wollten Sie es nicht."

    # say L743 whi
    old "I know you're turned on right now, so come here."
    new "Ich weiß, dass du gerade erregt bist, also komm her."

    # say L745 whi
    old "You know, I know you enjoyed dinner last time."
    new "Sie wissen, ich weiß, dass Ihnen das letzte Mal beim Dinner gefallen hat."

    # say L746 whi
    old "But I'm still not satisfied."
    new "Aber ich bin immer noch nicht zufrieden."

    # say L747 whi
    old "I want to taste something a little better."
    new "Ich will etwas Besseres kosten."

    # say L754 whi
    old "Mmm, look at that big cock of yours."
    new "Mmm, schauen Sie sich diesen großen Schwanz von Ihnen an."

    # say L755 whi
    old "I told you I knew you were getting turned on and very, very hard by the looks of it...."
    new "Ich habe Ihnen doch gesagt, dass ich sehe, wie erregt und sehr, sehr hart Sie sind."

    # say L757 whi
    old "I've been wanting to taste this big dick since last dinner."
    new "Ich habe schon beim letzten Dinner davon geträumt, diesen großen Schwanz zu schmecken."

    # say L767 mik
    old "Dude, you were here?"
    new "Dude, du warst hier?"

    # say L768 whi
    old "Yes, he came looking for you, but you weren't home, so I asked him to stay."
    new "Ja, er hat nach Ihnen gesucht, aber Sie waren nicht zu Hause, deshalb habe ich ihn gebeten zu bleiben."

    # say L770 mik
    old "Stay? What for?"
    new "Bleiben? Wofür?"

    # say L771 pla
    old "Uhhh... W- well... you know..."
    new "Uhhh... W-was... Sie wissen schon..."

    # say L772 whi
    old "Well, if you remember, there were some stuff in my room that I wanted to move to the attic."
    new "Nun, wenn Sie sich erinnern, gab es ein paar Dinge in meinem Zimmer, die ich in den Dachboden bringen wollte."

    # say L773 whi
    old "And I've been telling you for a while to help me, but you haven't done anything."
    new "Und ich habe Ihnen schon seit einiger Zeit gesagt, dass Sie mir dabei helfen sollen, aber Sie haben bisher nichts getan."

    # say L774 whi
    old "So you're friend here was kind enough to help me. You could learn one or two things from him, you know young man?"
    new "So Ihr Freund hier war so freundlich, mir zu helfen. Da könntest du wirklich ein paar Dinge lernen, junger Mann."

    # say L775 mik
    old "Hmm, yeah, uh, I forgot about that stuff."
    new "Hmm, ja, ähm, ich hab das vergessen."

    # say L778 pla
    old "... No problem."
    new "Kein Problem."

    # say L779 whi
    old "Well, I have to clean up some things, and start making dinner. So I'll leave you two alone."
    new "Nun, ich muss noch ein paar Dinge aufräumen und mit dem Abendessen beginnen. Ich lasse euch zwei also allein."

    # say L780 whi
    old "Thanks again for your help [pla]."
    new "Danke nochmal für Ihre Hilfe [pla]."

    # say L781 pla
    old "Sure Mrs. White."
    new "Natürlich, Mrs. White."

    # say L788 mik
    old "Sorry you had to see that dude."
    new "Tut mir leid, dass du das sehen musstest, Kumpel."

    # say L789 mik
    old "My mom is very annoying, sometimes she won't stop nagging me."
    new "Meine Mutter ist echt nervig, manchmal hört sie einfach nicht auf, mich zu nerven."

    # say L790 pla
    old "Don't worry about it... My mom's the same."
    new "Mach dir nichts draus... Meine Mum ist genauso."

    # say L791 mik
    old "Well anyway, come to my room, I have to tell you something."
    new "Na ja, komm in mein Zimmer, ich muss dir was erzählen."

    # say L800 mik
    old "Dudeee! Things went so well with Olivia!"
    new "Kumpel! Alles hat super geklappt mit Olivia!"

    # say L802 mik
    old "Yeah! She said I helped her a lot and that I'm a very good tutor."
    new "Ja! Sie hat gesagt, ich hätte ihr echt geholfen und dass ich ein sehr guter Tutor bin."

    # say L803 mik
    old "And it's all thanks to you dude. Thank you!"
    new "Und das hab ich alles dir zu verdanken. Danke!"

    # say L804 pla
    old "You're welcome man, I'm glad to be able to help."
    new "Gern geschehen, Mann, ich freue mich, helfen zu können."

    # say L805 pla
    old "So you're gonna keep seeing her?"
    new "Dann wirst du sie also weitersehen?"

    # say L806 mik
    old "Yeah, but she says she's going to come here next time."
    new "Klar, aber sie sagt, dass sie sich das nächste Mal hier blicken lassen will."

    # say L807 mik
    old "Because she says she's embarrassed to be seen with me, so it's better to come here instead."
    new "Weil sie sagt, sie schämt sich, mit mir gesehen zu werden, also ist es besser, hierherzukommen."

    # say L808 pla
    old "Whoa! What?! That's awful!"
    new "Wow! Was?! Das ist schrecklich!"

    # say L809 pla
    old "And you're ok with that?"
    new "Und du bist damit okay?"

    # say L811 mik
    old "Sure, why wouldn't I be? That means she wants to spend time with me. right?"
    new "Klar, warum nicht? Das bedeutet doch, dass sie Zeit mit mir verbringen will, oder?"

    # say L814 pla
    old "I mean, that's one way to put it..."
    new "Ich meine, das ist eine Möglichkeit, es zu sehen..."

    # say L815 mik
    old "Come on man, she's gonna be here... in my room!"
    new "Komm schon, Mann, sie wird hier sein... in meinem Zimmer!"

    # say L816 mik
    old "That's an opportunity to get closer with her!"
    new "Das ist die Gelegenheit, sich ihr näher zu kommen!"

    # say L817 mik
    old "And I don't really care what people think, you know? So what the hell."
    new "Und mir ist es egal, was die Leute denken, weißt du? Was soll's."

    # say L818 pla
    old "Well... as long as you're happy."
    new "Na ja... solange du glücklich bist."

    # say L819 pla
    old "And you're positive about it. So, sure."
    new "Und du bist dir sicher. Also, klar."

    # say L822 pla
    old "Listen man, I came to help you study, but it's kinda late."
    new "Hör mal, ich bin hier, um dir beim Lernen zu helfen, aber es ist ziemlich spät geworden."

    # say L823 pla
    old "So, what do you say if we leave it for next time."
    new "Dann sagen wir doch, dass wir es für nächstes Mal verschieben."

    # say L824 pla
    old "Besides, you must be tired from studying with Olivia."
    new "Außerdem bist du bestimmt müde vom Lernen mit Olivia."

    # say L825 mik
    old "Sure dude, to be honest I was afraid you were gonna say we had to study."
    new "Klar, ehrlich gesagt hatte ich Angst, du würdest sagen, wir müssten lernen."

    # say L826 mik
    old "So I'm ok with doing it another time."
    new "Dann machen wir es auch ein anderes Mal."

    # say L827 pla
    old "Cool, see you later then."
    new "Cool, dann sehen wir uns später."

    # say L829 mik
    old "Later bro."
    new "Später, Kumpel."

    # say L848 whi
    old "Oh [pla] wait!"
    new "Oh [pla] warten Sie!"

    # say L849 pla
    old "Yes Mrs. White?"
    new "Ja, Mrs. White?"

    # say L850 whi
    old "It's very late, so I figured you were gonna stay for dinner."
    new "Es ist sehr spät, deshalb dachte ich, Sie bleiben zum Abendessen."

    # say L851 whi
    old "The food is served already, so you can't say no."
    new "Das Essen ist schon serviert, da können Sie nicht nein sagen."

    # say L853 pla
    old "Oh, all right, thank you."
    new "Oh, gut, danke."

    # say L869 whi
    old "Do you like today's dinner?"
    new "Gefällt Ihnen das Abendessen heute?"

    # say L871 pla
    old "Yeah, it's very good Mrs. White, thanks a lot."
    new "Ja, es ist sehr gut, Mrs. White, vielen Dank."

    # say L872 mik
    old "He's right mom, it's really good."
    new "Stimmt, Mom, es ist wirklich lecker."

    # say L874 mik
    old "Excuse me, let me go to the bathroom real quick."
    new "Entschuldigt mich, ich muss schnell aufs Klo."

    # say L888 pla
    old "Woah! What are you doing Mrs. White?"
    new "Woah! Was machen Sie da, Mrs. White?"

    # say L889 pla
    old "We're in the middle of dinner! Mike could come back at any second!"
    new "Wir sind mitten beim Essen! Mike könnte jeden Moment zurückkommen!"

    # say L890 whi
    old "Oh relax, Mike always takes his time in the bathroom."
    new "Oh relax, Mike braucht immer seine Zeit im Bad."

    # say L891 whi
    old "I don't know exactly what he does there, but he'll be there for a while."
    new "Ich weiß nicht genau, was er da macht, aber er wird eine Weile brauchen."

    # say L892 pla
    old "Still, we're in the dining room..."
    new "Trotzdem, wir sind im Esszimmer..."

    # say L893 whi
    old "So? Nobody will see us, just enjoy it."
    new "Na und? Niemand wird uns sehen, genieße es einfach."

    # say L909 pla
    old "Uhh, Mrs. White you have some... Uhh... In your face..."
    new "Uhh, Mrs. White, da ist was... Uhh... Im Gesicht..."

    # say L915 whi
    old "It's ok honey, [pla] and I had a chance to have a very nice conversation."
    new "Es ist okay Schatz, [pla] und ich hatten die Gelegenheit, ein sehr nettes Gespräch zu führen."

    # say L917 whi
    old "Right, [pla]?"
    new "Stimmt, [pla]?"

    # say L918 mik
    old "Mom, why do you have so much mayo all over your face?"
    new "Mom, warum hast du so viel Mayo im Gesicht?"

    # say L919 whi
    old "Oh! Heh silly me. I just love the taste of it!"
    new "Oh! Hehe, wie dumm von mir. Ich liebe einfach den Geschmack!"

    # say L926 mik
    old "I know mom, we all know you really like mayo"
    new "Ich weiß, Mama, wir alle wissen, dass du Mayo liebst."

    # say L927 whi
    old "Yeah, mayo. Of course..."
    new "Ja, Mayonnaise. Natürlicherweise..."

    # say L937 pla
    old "Once again, it was all very good Mrs. White."
    new "Einmal mehr, es war alles sehr gut, Mrs. White."

    # say L938 pla
    old "Thanks a lot!"
    new "Danke schön!"

    # say L939 whi
    old "My pleasure sweety, it was good seeing you again."
    new "Mein Vergnügen, Schatz, es war schön, dich wiederzusehen."

    # say L940 whi
    old "And as you could see, I also think everything was delicious..."
    new "Und wie Sie sehen konnten, fand ich alles auch sehr lecker..."

    # say L941 pla
    old "...Sure."
    new "...Sicher."

    # say L942 pla
    old "Mike, I think I'll head home dude, I'll come back another time to keep studying."
    new "Mike, ich glaube, ich geh dann mal nach Hause, komme ein anderes Mal wieder, um weiter zu lernen."

    # say L943 mik
    old "Sure dude, have a good night."
    new "Klar, Mann, gute Nacht."

    # say L944 whi
    old "And remember to come back soon... You're always welcome."
    new "Und denken Sie daran, bald wiederzukommen... Sie sind hier immer willkommen."

    # say L945 pla
    old "Uuuh... thank you."
    new "Uuuh... danke."

    # say L963 pla
    old "Hi Mrs. White, is Mike around?"
    new "Hallo Mrs. White, ist Mike da?"

    # say L964 whi
    old "Hi [pla] is good to see you sweetie."
    new "Hi [pla] ist schön, Sie zu sehen, Schatz."

    # say L965 whi
    old "Well, Mike is in the house. But I don't think he can see you right now."
    new "Nun, Mike ist im Haus. Aber ich glaube nicht, dass er dich jetzt sehen kann."

    # say L966 pla
    old "What? Why not?"
    new "Was? Warum nicht?"

    # say L967 whi
    old "Well, he's got some company."
    new "Nun, er hat Gesellschaft."

    # say L968 whi
    old "A girl came to see him, and they locked themselves in his room."
    new "Eine Frau ist zu ihm gekommen, und sie haben sich in seinem Zimmer eingeschlossen."

    # say L969 whi
    old "He told me that I shouldn't bother him or even knock on the door."
    new "Er hat mir gesagt, ich soll ihn nicht stören oder überhaupt an die Tür klopfen."

    # say L970 pla
    old "Ohh, that's right, he told me Olivia was gonna come today, I don't know how I forgot about it."
    new "Ohh, stimmt, er hat mir gesagt, dass Olivia heute kommt, keine Ahnung, wie ich das vergessen konnte."

    # say L971 pla
    old "Ok, then I guess I'll come later, see you Mrs. White."
    new "Okay, dann komme ich später, bis bald Mrs. White."

    # say L972 whi
    old "Wait a minute!"
    new "Warten Sie einen Moment!"

    # say L973 pla
    old "Uhh... yes?"
    new "Uhh... ja?"

    # say L974 whi
    old "How are you leaving after you just arrived? Don't be silly."
    new "Warten Sie mal, wie können Sie schon wieder gehen, nachdem Sie gerade erst angekommen sind? Machen Sie doch keinen Unsinn."

    # say L975 whi
    old "You're going to help me move some other boxes in my room."
    new "Sie werden mir helfen, einige andere Kisten in meinem Zimmer zu bewegen."

    # say L976 pla
    old "What? What are you talking about? Mike's here!"
    new "Was? Wovon redest du? Mike ist hier!"

    # say L977 whi
    old "So? They just went up to his room a couple of minutes ago."
    new "So? Sie sind doch gerade erst in sein Zimmer gegangen."

    # say L978 whi
    old "How long do you think the study session will last?"
    new "Wie lange denken Sie, wird die Lernsession dauern?"

    # say L979 pla
    old "Well... It should take a while, because the subject is a little long."
    new "Na ja... Es sollte eine Weile dauern, weil das Thema ein bisschen länger ist."

    # say L981 whi
    old "See? Nothing's going to happen."
    new "Sie sehen? Da passiert nichts."

    # say L982 whi
    old "Besides, if they finish early, all I have to do is tell him I'm in my room and don't want him to go in."
    new "Außerdem, wenn sie früher fertig sind, muss ich ihm nur sagen, dass ich in meinem Zimmer bin und nicht will, dass er reinkommt."

    # say L983 pla
    old "Still, I don't think we..."
    new "Trotzdem, ich glaube nicht, dass wir..."

    # say L984 whi
    old "Enough talking, you worry too much. Just come with me to the room."
    new "Genug geredet, Sie machen sich zu viele Sorgen. Kommen Sie einfach mit ins Zimmer."

    # say L985 whi
    old "I know you'll love it."
    new "Ich weiß, dass Sie es lieben werden."

    # say L997 pla
    old "(Oh man, I just fucked my best friend's mom... I can't believe I'm doing this to Mike.)"
    new "Oh Mann, ich hab gerade die Mutter meines besten Freundes gevögelt... Ich kann nicht glauben, dass ich Mike das antue."

    # say L998 pla
    old "(Jeez, honestly... I'm ok with helping Mike, but damn, this is getting dangerous.)"
    new "Ehrlich, ich bin okay damit, Mike zu helfen, aber verdammt, das wird gefährlich."

    # say L999 pla
    old "(I mean, I just can't even imagine what would happen if Mike caught us one day)"
    new "Ich meine, ich kann mir gar nicht vorstellen, was passieren würde, wenn Mike uns eines Tages erwischen würde."

    # say L1006 oli
    old "Ah! W- What are you doing here?"
    new "Ah! W- Was machst du hier?"

    # say L1009 pla
    old "Uhh... Well, this is my friend's house."
    new "Uhh... Also, das ist das Haus meines Freundes."

    # say L1010 pla
    old "So, I came to see him."
    new "Dann bin ich hier, um ihn zu sehen."

    # say L1011 pla
    old "And you? Did you come to study with him, right? "
    new "Und du? Bist du hier, um mit ihm zu lernen, oder?"

    # say L1013 oli
    old "I... uhh..."
    new "Ich... äh..."

    # say L1014 oli
    old "What do you care? I can come and go wherever I want."
    new "Was geht dich das an? Ich kann kommen und gehen, wo ich will."

    # say L1015 oli
    old "And I'm leaving now!"
    new "Und ich gehe jetzt!"

    # say L1026 oli
    old "By the way! You better not tell anybody about me being here!"
    new "Übrigens! Du besser erzählst niemandem, dass ich hier war!"

    # say L1027 oli
    old "Or you'll hear about me, you got that fucking nerd?"
    new "Oder du wirst von mir hören, kapiert Arschloch?"

    # say L1028 pla
    old "Sure, sure whatever you say."
    new "Klar, klar, wie du willst."

    # say L1044 mik
    old "Oh [pla], what's up man? I didn't know you were here."
    new "Oh [pla], was ist los, Mann? Ich wusste gar nicht, dass du hier bist."

    # say L1045 pla
    old "Uh, yeah, I came to see you."
    new "Klar, ich bin hier, um dich zu sehen."

    # say L1046 pla
    old "I forgot that you were going to see Olivia today."
    new "Ich hab total vergessen, dass du heute bei Olivia warst."

    # say L1047 pla
    old "By the way, how did it go?"
    new "Übrigens, wie war’s?"

    # say L1049 mik
    old "Aww man! It was awesome!"
    new "Ach Mann! Es war toll!"

    # say L1050 mik
    old "She said I'm being very helpful."
    new "Sie hat gesagt, ich bin sehr hilfreich."

    # say L1051 mik
    old "I'm telling you [pla], I'm winning her over."
    new "Ich sag dir [pla], ich gewinne sie für mich."

    # say L1053 mik
    old "But anyway, we can keep talking about it while we have dinner."
    new "Aber egal, wir können weiter darüber reden, während wir zu Abend essen."

    # say L1054 pla
    old "Uh what? Dinner? I- I don't think I can."
    new "Was? Abendessen? I- Ich glaube, das geht nicht."

    # say L1055 mik
    old "Come on, you know it's no trouble. My mom will be happy to have you here."
    new "Komm schon, du weißt, dass es kein Problem ist. Meine Mom wird sich freuen, dich hier zu haben."

    # say L1056 pla
    old "I'm sure she will. But I promised my mother I would have dinner at our house tonight."
    new "Ich bin sicher, sie wird sich freuen. Aber ich habe meiner Mutter versprochen, heute Abend zu Hause zu essen."

    # say L1057 pla
    old "I've been eating out too much, so I can't miss it tonight."
    new "Ich esse schon zu oft auswärts, da kann ich heute Abend nicht fehlen."

    # say L1059 mik
    old "Uhh, all right, next time then."
    new "Uhh, okay, dann beim nächsten Mal."

    # say L1060 mik
    old "See you later then bud."
    new "Bis später dann, Kumpel."

    # say L1061 pla
    old "Sure man, see you."
    new "Klar, Mann, bis später."

    # say L1079 whi
    old "Hi [pla] are you two done studying today?"
    new "Hi [pla] sind Sie beide heute mit dem Lernen fertig?"

    # say L1080 pla
    old "Yes Mrs. White, we just finished."
    new "Ja, Frau White, wir sind gerade fertig geworden."

    # say L1081 pla
    old "So I figured I should go."
    new "Dann dachte ich, ich sollte jetzt gehen."

    # say L1082 whi
    old "Oh don't be silly!"
    new "Oh, seien Sie nicht albern!"

    # say L1083 whi
    old "I already finished the dinner."
    new "Ich habe das Abendessen schon fertig."

    # say L1084 whi
    old "And you know I want you to stay."
    new "Und Sie wissen, dass ich möchte, dass Sie bleiben."

    # say L1086 pla
    old "L- Listen Mrs. White, I already told my mom I was going to have dinner with her and sh..."
    new "L-Lassen Sie mich erklären, Mrs. White, ich habe meiner Mutter schon gesagt, dass ich mit ihr zu Abend essen würde und..."

    # say L1087 whi
    old "I'm sure your mother will understand that I invited you."
    new "Ich bin sicher, Ihre Mutter wird verstehen, dass ich Sie eingeladen habe."

    # say L1088 whi
    old "Come on. Let's have dinner."
    new "Kommen Sie. Lassen Sie uns zu Abend essen."

    # say L1103 mik
    old "This is really good mom."
    new "Das ist wirklich gut, Mom."

    # say L1104 mik
    old "I don't know what's happened, but you've been making some awesome food these days."
    new "Ich weiß nicht, was passiert ist, aber du kochst in letzter Zeit echt toll."

    # say L1105 whi
    old "I don't know what you mean by that, my food is always delicious."
    new "Ich weiß nicht, was Sie damit meinen, mein Essen ist immer lecker."

    # say L1106 whi
    old "You're going to make your friend think that my cooking is usually bad."
    new "Sie werden Ihrem Freund noch einbilden, dass meine Kochkünste normalerweise schlecht sind."

    # say L1107 mik
    old "What? Of course not."
    new "Was? Natürlich nicht."

    # say L1108 mik
    old "All I'm saying is the meals are extra special these days."
    new "Ich sage ja nur, dass die Mahlzeiten in letzter Zeit besonders gut sind."

    # say L1110 whi
    old "Well, I have to put in some effort, we've been having an extra special guest..."
    new "Nun, ich muss schon ein bisschen mehr Aufwand betreiben, seit wir einen besonders wichtigen Gast haben..."

    # say L1111 mik
    old "Ha! My mom likes you dude."
    new "Ha! Meine Mutter mag dich, Alter."

    # say L1112 pla
    old "(You have no idea...)"
    new "Sie haben keine Ahnung..."

    # say L1113 whi
    old "I'm just being nice to your friend."
    new "Ich bin einfach nur freundlich zu Ihrem Freund."

    # say L1114 whi
    old "Are you enjoying it too [pla]?"
    new "Gefällt es Ihnen auch [pla]?"

    # say L1117 pla
    old "I like it a lot. It's delicious, thank you."
    new "Mir gefällt es sehr. Es ist köstlich, danke."

    # say L1119 mik
    old "By the way [pla], Belle told me to ask you about th..."
    new "Übrigens [pla], Belle hat mich gebeten, Sie nach dem zu fragen..."

    # say L1123 mik
    old "Hold it right there, I'm gonna take this call."
    new "Warte mal, ich nehme diesen Anruf an."

    # say L1130 pla
    old "Oh come on..."
    new "Oh komm schon..."

    # say L1139 pla
    old "W- What are you doing Mrs. White?"
    new "W- Was machen Sie da, Mrs. White?"

    # say L1140 whi
    old "What? This is just like last time."
    new "Was? Das ist doch genau wie beim letzten Mal."

    # say L1141 whi
    old "You know he'll take a while."
    new "Sie wissen doch, dass er eine Weile braucht."

    # say L1142 whi
    old "So, we can have a little bit of fun."
    new "Dann können wir uns ja ein bisschen amüsieren."

    # say L1143 pla
    old "No, no, no. This isn't like last time. He only left to pick up a call."
    new "Nein, nein, nein. Das ist nicht wie letztes Mal. Er ist nur gegangen, um einen Anruf entgegenzunehmen."

    # say L1144 pla
    old "Which means it won't be long."
    new "Das bedeutet, es dauert nicht lange."

    # say L1145 pla
    old "Mrs. White please stop!"
    new "Mrs. White, bitte hör auf!"

    # say L1146 whi
    old "Well, I could stop."
    new "Nun, ich könnte aufhören."

    # say L1147 whi
    old "But this hard dick tells me you want me to do it anyway."
    new "Aber dieser harte Schwanz sagt mir, dass du es trotzdem willst."

    # say L1149 whi
    old "Just relax, it won't take long."
    new "Beruhigen Sie sich, es dauert nicht lange."

    # say L1171 mik
    old "Where did my mom go?"
    new "Wo ist meine Mom hin?"

    # say L1172 pla
    old "Uhhh... S- she went to the... bathroom. Yeah, she said she needed to go."
    new "Uhhh... S- sie ist... ins... Badezimmer gegangen. Ja, sie sagte, sie müsste da hin."

    # say L1173 mik
    old "But I came from there, and I didn't see her enter."
    new "Aber ich kam von dort und hab sie nicht reingehen sehen."

    # say L1176 pla
    old "She... must be using the one in her bedroom."
    new "Sie... muss das im Schlafzimmer benutzen."

    # say L1177 pla
    old "I think she went upstairs."
    new "Ich denke, sie ist nach oben gegangen."

    # say L1180 mik
    old "Yeah you're right."
    new "Ja, du hast recht."

    # say L1197 pla
    old "(Damn, I can't believe she actually gave me a blowjob and made me cum with Mike here!)"
    new "Verdammt, ich kann nicht glauben, dass sie mir wirklich einen geblasen hat und mich kommen ließ, während Mike hier war!"

    # say L1198 pla
    old "(I need to think about something or Mike will really catch us.)"
    new "(Ich muss an was anderes denken, sonst merkt Mike wirklich, was hier los ist.)"

    # say L1199 pla
    old "You know what Mike? I think I could really use a headache pill."
    new "Weißt du was, Mike? Ich glaube, ich könnte wirklich eine Kopfschmerztablette gebrauchen."

    # say L1200 pla
    old "If you have anything here that I could take it would be good."
    new "Wenn Sie hier etwas haben, das ich nehmen kann, wäre das gut."

    # say L1201 mik
    old "Hmm, let me check the cabinet in the bathroom."
    new "Hmm, ich schaue mal im Badezimmer im Schrank nach."

    # say L1209 whi
    old "A headache? That was a good idea."
    new "Ein Kopfschmerz? Das war eine gute Idee."

    # say L1210 pla
    old "Why are you so chirpy? I told you he was going to come back!"
    new "Warum bist du so fröhlich? Ich hab dir doch gesagt, dass er zurückkommen würde!"

    # say L1211 whi
    old "Awww, my baby boy was scary, don't worry sweetie."
    new "Ach, mein kleiner Schatz war furchterregend, mach dir keine Sorgen, Liebling."

    # say L1212 whi
    old "Next time I see you I'll give you something in return for this."
    new "Das nächste Mal gebe ich dir etwas im Gegenzug dafür."

    # say L1213 pla
    old "Hmph, this isn't about that."
    new "Hmpf, das geht hier nicht um so was."

    # say L1218 mik
    old "Sorry dude, we don't have anything like that."
    new "Tut mir leid, Kumpel, wir haben so was nicht."

    # say L1219 mik
    old "Mom, you're back."
    new "Mom, du bist zurück."

    # say L1221 mik
    old "I thought you had gone to sleep."
    new "Ich dachte, du bist schon eingeschlafen."

    # say L1223 whi
    old "Oh no, it's just that I had to go to the bathroom. But I came back to finish my dinner."
    new "Oh nein, ich musste nur auf die Toilette. Aber ich bin zurückgekommen, um mein Abendessen zu beenden."

    # say L1224 whi
    old "By the way, you should finish yours too, before it gets cold."
    new "Ach ja, Sie sollten auch Ihr Abendessen beenden, bevor es kalt wird."

    # say L1225 mik
    old "I know, I know, I was just getting a pill for [pla], where do we keep then?"
    new "Ich weiß, ich war gerade eine Pille für [pla] holen, wo haben wir die aufbewahrt?"

    # say L1227 pla
    old "You know what, dude?"
    new "Du weißt ja, Alter,"

    # say L1228 pla
    old "I don't think I'll need it, the headache is gone."
    new "Ich glaube, ich werde es nicht brauchen, der Kopfschmerz ist weg."

    # say L1230 whi
    old "Yeah, all you needed was to relax and release everything as Mike said."
    new "Ja, alles, was Sie gebraucht haben, war ein bisschen Entspannung und alles loszulassen, wie Mike gesagt hat."

    # say L1232 mik
    old "Yeah, that's what I sai-... Wait how do you know-"
    new "Ja, das hab ich gesagt... Moment, wie weißt du das-"

    # say L1233 whi
    old "Oh, honey, I'm really hungry and the food is gonna get cold. Why don't we finish this delicious dinner?"
    new "Oh, Schatz, ich habe richtig Hunger und das Essen wird kalt. Warum essen wir nicht dieses leckere Abendessen?"

    # say L1234 pla
    old "Yeah, dude, just enjoy the dinner."
    new "Ja, Kumpel, genieß einfach das Abendessen."

    # say L1242 pla
    old "As always Mrs. White, your food is always the best."
    new "Wie immer, Mrs. White, Ihr Essen ist immer das Beste."

    # say L1244 whi
    old "It's very good that you always enjoy... Everything I give you sweety."
    new "Es freut mich sehr, dass dir immer alles schmeckt, was ich dir gebe, Schatz."

    # say L1245 whi
    old "It always makes me want to give you some more..."
    new "Das macht mich immer dazu, dir noch mehr zu geben..."

    # say L1246 pla
    old "Uh... yeah, thank you."
    new "Äh... ja, danke."

    # say L1247 pla
    old "Well, it's very late, so I shold go now."
    new "Na ja, es ist sehr spät, ich sollte jetzt gehen."

    # say L1248 mik
    old "Sure man, no problem. Thanks for today."
    new "Klar, Mann, kein Problem. Danke für heute."

    # say L1267 pla
    old "Hi Mrs.White, how are you?"
    new "Hi Mrs. White, wie geht es Ihnen?"

    # say L1268 whi
    old "Hi sweetie, I'm very well, thank you."
    new "Hi Liebling, ich bin sehr gut, danke."

    # say L1269 whi
    old "Let me guess, you came to study with Mike again."
    new "Lass mich raten, du bist wieder gekommen, um mit Mike zu lernen."

    # say L1270 pla
    old "Yeah, is he here?"
    new "Klar, ist er hier?"

    # say L1271 whi
    old "I'm sorry, but he isn't, he went out with that girl Olivia."
    new "Tut mir leid, aber das ist er nicht, er ist mit Olivia ausgegangen."

    # say L1273 pla
    old "Hmm... I see."
    new "Hmm... Ich verstehe."

    # say L1274 pla
    old "I suppose I should come later then, right?"
    new "Dann sollte ich wohl später wiederkommen, oder?"

    # say L1275 whi
    old "Oh, why do you ask that when you already know the answer?"
    new "Oh, warum fragst du das, wenn du die Antwort doch schon kennst?"

    # say L1276 whi
    old "No my sweet boy, you're not going anywhere."
    new "Nein mein süßer Junge, du gehst nirgendwohin."

    # say L1277 whi
    old "We're going to finish what we started the other night at dinner."
    new "Wir werden das beenden, was wir beim Abendessen in der anderen Nacht angefangen haben."

    # say L1279 whi
    old "Come here sweetie, I want you right now."
    new "Komm her, Schatz, ich will dich jetzt."

    # say L1280 pla
    old "What? Here?"
    new "Was? Hier?"

    # say L1281 whi
    old "Sure! Why not? We're alone and Mike will take his time."
    new "Natürlich! Warum nicht? Wir sind allein und Mike wird seine Zeit brauchen."

    # say L1282 pla
    old "B- but... I- I mean, he could come back early... or he could"
    new "Aber... ich meine, er könnte früher zurückkommen... oder er könnte"

    # say L1284 whi
    old "That's enough, Mike doesn't even suspect a thing and you're always worrying."
    new "Das reicht jetzt, Mike ahnt überhaupt nichts und Sie machen sich immer so viele Sorgen."

    # say L1285 whi
    old "So stop thinking so much and just get naked."
    new "Hören Sie auf, so viel zu denken, und ziehen Sie sich einfach aus."

    # say L1286 whi
    old "I want that big cock now!"
    new "Ich will diesen großen Schwanz jetzt!"

    # say L1295 whi
    old "Ah yes! Look at how hard you already are."
    new "Ah ja! Schauen Sie sich an, wie hart Sie schon sind."

    # say L1296 whi
    old "That big long dick."
    new "Dieser große lange Schwanz."

    # say L1297 whi
    old "I want you to put in me."
    new "Ich will, dass Sie es in mich tun."

    # say L1298 whi
    old "I can't wait!"
    new "Ich freue mich schon so darauf!"

    # say L1313 pla
    old "Hi Mrs. White. It's good seeing you again."
    new "Hallo Mrs. White. Es freut mich, Sie wiederzusehen."

    # say L1314 whi
    old "Hi sweety, are you here to see Mike?"
    new "Hallo Schatz, bist du hier, um Mike zu sehen?"

    # say L1316 whi
    old "Well, I'm sorry to tell you that he's not available."
    new "Nun, es tut mir leid, Ihnen sagen zu müssen, dass er nicht verfügbar ist."

    # say L1317 whi
    old "That girl Olivia came a while ago, and he was very clear that they shouldn't be interrupted."
    new "Das Mädchen Olivia war schon eine Weile hier, und er hat sehr deutlich gemacht, dass sie nicht gestört werden dürfen."

    # say L1320 whi
    old "But don't be sad, because you know what that means."
    new "Aber traurig sein Sie nicht, denn Sie wissen ja, was das bedeutet."

    # say L1321 whi
    old "It means you and I get to have some fun."
    new "Das bedeutet, dass wir beide ein bisschen Spaß haben können."

    # say L1322 pla
    old "What?! Are you kidding me?!!"
    new "Was?! Spinnst du?!"

    # say L1323 pla
    old "After what happened last time. You still want to do it?!"
    new "Nach dem, was letztes Mal passiert ist. Willst du das wirklich nochmal machen?!"

    # say L1324 whi
    old "Aww, my baby boy is worried."
    new "Ach, mein kleiner Schatz macht sich Sorgen."

    # say L1325 whi
    old "Don't worry, this time we'll do it in my bedroom, so what happened last time won't happen again."
    new "Machen Sie sich keine Sorgen, diesmal machen wir es in meinem Schlafzimmer, damit das, was letztes Mal passiert ist, nicht wieder vorkommt."

    # say L1326 pla
    old "Hmm, but what happens if they finish before us and they hear us?"
    new "Hmm, aber was passiert, wenn sie vor uns fertig werden und uns hören?"

    # say L1327 pla
    old "I mean... How long have they been up there?"
    new "Ich meine... Wie lange sind sie schon da oben?"

    # say L1328 whi
    old "Hmm, to be honest I didn't really look at the clock."
    new "Hmm, ehrlich gesagt habe ich nicht wirklich auf die Uhr geschaut."

    # say L1329 pla
    old "I don't think we should do anything without knowing how long they'll be there."
    new "Ich denke, wir sollten nichts tun, ohne zu wissen, wie lange sie da oben bleiben."

    # say L1331 whi
    old "You're thinking too much, just relax a little."
    new "Sie denken zu viel, entspannen Sie sich einfach ein bisschen."

    # say L1332 pla
    old "I can't, after what happened last time, we need to be sure... And I have an idea."
    new "Ich kann nicht, nach dem, was letztes Mal passiert ist, müssen wir sicher sein... Und ich habe eine Idee."

    # say L1333 pla
    old "Let me go upstairs and check on them first."
    new "Lass mich erst mal nach oben gehen und nach ihnen sehen."

    # say L1334 whi
    old "Hmm, ok. Do that and let me know."
    new "Hmm, okay. Machen Sie das und lassen Sie es mich wissen."

    # say L1346 pla
    old "Damn, I didn't think Mike and Olivia were really going to do anything."
    new "Verdammt, ich dachte echt, Mike und Olivia würden nichts machen."

    # say L1347 pla
    old "Well, I guess all that work really paid off. I'm happy for him."
    new "Na ja, scheint so, als hätte sich die ganze Arbeit gelohnt. Ich freue mich für ihn."

    # say L1356 whi
    old "So? What topic are they on?"
    new "So? Welches Thema haben sie denn?"

    # say L1357 pla
    old "Hmm, let's just say they'll be busy for a while."
    new "Hmm, lass uns einfach sagen, sie werden eine Weile beschäftigt sein."

    # say L1358 pla
    old "So, I think we'll be fine."
    new "Dann denke ich, wir sind gut."

    # say L1360 whi
    old "Really? Perfect! Let's go to my room then!"
    new "Wirklich? Perfekt! Dann gehen wir in mein Zimmer!"

    # say L1385 pla
    old "Fuck! She saw us, I have to go after her!"
    new "Scheiße! Sie hat uns gesehen, ich muss ihr hinterhergehen!"

    # say L1397 pla
    old "Olivia! Wait!"
    new "Olivia! Warte!"

    # say L1400 oli
    old "Dude! What the fuck!"
    new "Mann! Was zur Hölle!"

    # say L1401 oli
    old "You're fucking your friend's mother?! What the fuck is wrong with you."
    new "Du vögelst die Mutter deines Freundes?! Was zum Teufel stimmt nicht mit dir."

    # say L1403 pla
    old "It's not what you think! We're just..."
    new "Es ist nicht so, wie du denkst! Wir sind nur..."

    # say L1404 oli
    old "You're just what? I saw you dude!"
    new "Du warst was? Ich hab dich gesehen, Mann!"

    # say L1405 oli
    old "I saw your big coc-... your penis hanging out, and jizz everywhere."
    new "Ich hab gesehen, wie dein großer Schwanz rausgehangen hat und überall Sperma war."

    # say L1406 pla
    old "Ok, listen, I was doing that, but please you can't tell Mike."
    new "Okay, hör zu, ich hab das gemacht, aber bitte sag es Mike nicht."

    # say L1407 pla
    old "Please! I'm begging you! He'll never forgive me!"
    new "Bitte! Ich flehe dich an! Er wird mir das nie verzeihen!"

    # say L1408 oli
    old "Well, maybe you should've thought about that before fucking his mom."
    new "Na, vielleicht hättest du dran denken sollen, bevor du seine Mom gevögelt hast."

    # say L1409 pla
    old "Oh, come on! You wouldn't get anything by telling him that!"
    new "Oh, komm schon! Du würdest nichts gewinnen, indem du ihm das sagst!"

    # say L1410 oli
    old "Perhaps I would, who knows?"
    new "Vielleicht schon, wer weiß?"

    # say L1411 oli
    old "I guess you would be willing to do anything in exchange for me not telling him anything, right?"
    new "Ich schätze, du wärst bereit, alles zu tun, damit ich ihm nichts sage, oder?"

    # say L1413 oli
    old "Right?!!!!"
    new "Stimmt's?!!!!"

    # say L1414 pla
    old "I would, I would, I'd do anything, just please don't tell Mike."
    new "Ich würde, ich würde alles tun, bitte sag es Mike bloß nicht."

    # say L1417 oli
    old "Listen, I'm leaving now, I can't waste my time on you."
    new "Hör zu, ich geh jetzt, ich kann meine Zeit nicht mit dir verschwenden."

    # say L1418 oli
    old "I'm not going to tell him anything... For now."
    new "Ich werde ihm nichts sagen... fürs Erste."

    # say L1419 oli
    old "We'll see if that changes later."
    new "Wir werden sehen, ob sich das später ändert."

    # say L1425 pla
    old "Oh, gosh, I'm fucked.."
    new "Oh, verdammt, ich bin geliefert."

    # say L1426 pla
    old "(Damn it! She just saw me fucking my best friends mom!)"
    new "Verdammt! Sie hat mich gerade dabei erwischt, wie ich mit der Mutter meines besten Freundes gevögelt habe!"

    # say L1427 pla
    old "(I have to do something...)"
    new "(I muss was tun...)"

    # say L1428 pla
    old "(I have to try and convince her someway not to tell Mike.)"
    new "Ich muss versuchen, sie irgendwie davon abzuhalten, Mike was zu sagen."

    # say L1435 mik
    old "Hey man, what's up?"
    new "Hey Mann, was ist los?"

    # say L1437 mik
    old "Did you run into Olivia again?"
    new "Hast du Olivia wieder getroffen?"

    # say L1438 pla
    old "Uhh, yeah... Sorry dude."
    new "Uhh, ja... Tut mir leid, Kumpel."

    # say L1439 mik
    old "It's ok dude."
    new "Ist schon gut, Alter."

    # say L1440 mik
    old "I already talked to her about it."
    new "Ich hab schon mit ihr drüber geredet."

    # say L1441 mik
    old "I told her that you've been helping me. So don't worry, we're fine."
    new "Ich hab ihr gesagt, dass du mir hilfst. Also mach dir keine Sorgen, wir sind gut."

    # say L1442 pla
    old "I see... well, that's very cool dude."
    new "Ich seh's... na ja, das ist echt cool, Alter."

    # say L1443 mik
    old "Yeah... I guess it is."
    new "Ja... schätze schon."

    # say L1444 pla
    old "Hey man, listen, today is a little late, so how about we study another time?"
    new "Hey Mann, hör mal, heute ist es ein bisschen spät, wie wär's, wenn wir das nächste Mal lernen?"

    # say L1446 mik
    old "Actually, we don't have to do that for now."
    new "Eigentlich müssen wir das jetzt nicht machen."

    # say L1447 pla
    old "Really? Why?"
    new "Wirklich? Warum?"

    # say L1448 mik
    old "Olivia's going on a trip."
    new "Olivia fährt auf eine Reise."

    # say L1449 mik
    old "She's going to be out of time for a while."
    new "Sie wird eine Weile weg sein."

    # say L1451 mik
    old "So I don't think you don't have to worry for now."
    new "Dann denke ich, du musst dir fürs Erste keine Sorgen machen."

    # say L1453 pla
    old "That's a relief, I gues..."
    new "Das ist eine Erleichterung, schätze ich."

    # say L1455 pla
    old "I- I mean... I see... Um, sorry dude. That sucks."
    new "I- Ich meine... Ich sehe... Ähm, sorry Mann. Das ist echt blöd."

    # say L1457 mik
    old "Are you kidding me? Dude, it has been awesome spending time with her."
    new "Spinnst du? Mann, es war toll, Zeit mit ihr zu verbringen."

    # say L1458 mik
    old "And I know for a fact that she likes me."
    new "Und ich weiß genau, dass sie mich mag."

    # say L1459 mik
    old "So, I'm sure I'll see her again when this is over."
    new "Dann bin ich sicher, dass ich sie wiedersehe, wenn das hier vorbei ist."

    # say L1460 pla
    old "So am I..."
    new "So bin ich..."

    # say L1468 whi
    old "[pla]! Did you talk to her? What did she say?"
    new "[pla]! Haben Sie mit ihr gesprochen? Was hat sie gesagt?"

    # say L1469 pla
    old "Yeah, I did Mrs. White, and I know you're worried about that."
    new "Ja, ich habe mit Mrs. White gesprochen, und ich weiß, dass du dir deswegen Sorgen machst."

    # say L1470 pla
    old "But she said she wasn't going to tell anything to him."
    new "Aber sie hat gesagt, dass sie ihm nichts erzählen wird."

    # say L1471 pla
    old "At least for now..."
    new "Zumindest für jetzt..."

    # say L1472 whi
    old "I don't know, what if she tells him? He's going to kill me!"
    new "Ich weiß nicht, was passiert, wenn sie es ihm sagt. Er wird mich umbringen!"

    # say L1473 pla
    old "Hey, it's ok, let me handle it. Ok?"
    new "Hey, mach dir keine Sorgen, lass mich das regeln. Okay?"

    # say L1475 whi
    old "Ok, I trust you."
    new "Ok, ich vertraue Ihnen."

    # say L1477 pla
    old "Listen, it's very late already, and my mom wants me to eat with her."
    new "Hör zu, es ist schon sehr spät, und meine Mutter will, dass ich mit ihr esse."

    # say L1478 pla
    old "So I'll be on my way home, and I'll see you later."
    new "Dann gehe ich jetzt nach Hause und sehe dich später."

    # say L1479 pla
    old "Just try not to worry too much and just let me handle this. Ok?"
    new "Versuch einfach, dich nicht zu sehr aufzuregen und lass mich das regeln. Ok?"

    # say L1481 whi
    old "Ok, ok, I'll try not to think about it."
    new "Okay, okay, ich werde versuchen, nicht daran zu denken."

    # say L1482 whi
    old "Bye. I'll see you later baby boy."
    new "Tschüss. Ich sehe dich später, mein Schatz."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/briAnimations.rpy
translate german strings:

    # say L6 bri
    old "Holy shit! You really have a big cock!"
    new "Heilige Scheiße! Du hast wirklich einen großen Schwanz!"

    # say L7 bri
    old "That makes it even better to share my power with you!"
    new "Das macht es noch besser, meine Kraft mit dir zu teilen!"

    # say L11 bri
    old "Do you feel how your body receive my magical power within you?"
    new "Spürst du, wie dein Körper meine magische Kraft in sich aufnimmt?"

    # say L12 pla
    old "Ah?... Yes, yes... That's what I'm feeling..."
    new "Ah?... Ja, ja... Das spüre ich..."

    # say L16 bri
    old "Let's do it faster so you get more power!"
    new "Lass uns schneller machen, damit du mehr Kraft bekommst!"

    # say L45 bri
    old "Do you feel it? Do you feel all the power within me?"
    new "Spürst du es? Spürst du all die Kraft in mir?"

    # say L46 pla
    old "Yes, yes... I actually think I'm going to..."
    new "Ja, ja... Ich glaube, ich werde..."

    # say L51 bri
    old "Well that is enough for now..."
    new "Dann reicht es fürs Erste..."

    # say L52 bri
    old "Now you have more magic power."
    new "Jetzt hast du mehr magische Kraft."

    # say L59 bri
    old "If you need more just let me collect some magic power for a couple of days..."
    new "Wenn du mehr brauchst, lass mich einfach ein paar Tage lang etwas Magie sammeln..."

    # say L61 bri
    old "Or you could share more with me for me to give you back just for fun."
    new "Oder du könntest mehr mit mir teilen, damit ich es dir einfach so zurückgeben kann."

    # say L63 pla
    old "Actually that's a good idea, I'll keep that in mind..."
    new "Tatsächlich, das ist eine gute Idee, ich werd dran denken..."

    # say L65 pla
    old "Great..."
    new "Super..."

    # say L86 bri
    old "Uhh, it's definitely huge!"
    new "Uhh, es ist definitiv riesig!"

    # say L87 bri
    old "You'll be definitely be one of the best Sexnote owners..."
    new "Du wirst definitiv einer der besten Sexnote-Besitzer sein..."

    # say L91 bri
    old "Ohh yeah, just like that! Oh gosh it feels amazing!"
    new "Ohh ja, genau so! Oh Gott, das fühlt sich unglaublich an!"

    # say L92 bri
    old "Mmm, are you enjoying the magic transfer?"
    new "Mmm, genießt du die Magieübertragung?"

    # say L96 bri
    old "I want more! Give me all you have!"
    new "Ich will mehr! Gib mir alles, was du hast!"

    # say L98 bri
    old "Oh yeah, don't stop, don't stop! Get all my power!"
    new "Oh ja, hör nicht auf, hör nicht auf! Hol dir all meine Kraft!"

    # say L122 pla
    old "I- I cumming!"
    new "Ich- ich komme!"

    # say L125 bri
    old "Phew! That was AWESOME!"
    new "Puh! Das war WUNDERBAR!"

    # say L126 bri
    old "I really missed this."
    new "Ich hab das echt vermisst."

    # say L169 pla
    old "Oh fuck... I'm going to..."
    new "Oh Scheiße... Ich werde..."

    # say L176 bri
    old "I love to do this..."
    new "Ich liebe es, das zu tun..."

    # say L177 pla
    old "Did you get good magic power?"
    new "Hast du genug Magie bekommen?"

    # say L178 bri
    old "Yes, but you can always give me more if you want..."
    new "Ja, aber du kannst mir immer mehr geben, wenn du willst..."

    # say L179 pla
    old "Not now, I Need to use it to improve my skills first."
    new "Nicht jetzt, ich muss es erst nutzen, um meine Fähigkeiten zu verbessern."

    # say L180 bri
    old "You are right..."
    new "Du hast recht..."

    # say L184 bri
    old "By the way, I could help you too when you get an boner."
    new "Übrigens, ich könnte dir auch helfen, wenn du einen Ständer kriegst."

    # say L186 pla
    old "Now that you mention it, I have a question... If I ever get to do something like this with a woman... Will I lose magical power?"
    new "Jetzt, wo du es erwähnst, hab ich eine Frage... Wenn ich mal so was mit einer Frau mache... Verliere ich dann magische Kraft?"

    # say L188 bri
    old "To do what, have some sexual activity?"
    new "Was genau meinst du, eine sexuelle Aktivität?"

    # say L190 pla
    old "Ehh... Well, yes..."
    new "Ehh... Ja, genau..."

    # say L192 bri
    old "Don't worry! In fact, you should do it. "
    new "Keine Sorge! Tatsächlich solltest du es tun."

    # say L194 pla
    old "What do you mean?"
    new "Was meinst du?"

    # say L196 bri
    old "Humans have a very particular phenomenon, when they have some high sexual excitation they generate magical power..."
    new "Menschen haben ein sehr spezielles Phänomen, wenn sie starke sexuelle Erregung verspüren, erzeugen sie magische Energie..."

    # say L198 bri
    old "That magic power usually disappear quickly because there is nobody enabled to store that energy..."
    new "Diese magische Energie verschwindet normalerweise schnell, weil niemand da ist, der sie aufnehmen kann..."

    # say L200 bri
    old "But you can, so, any kind of sexual activity will help you generate magical power and the more intense or higher sexual excitation the more magical power you will receive..."
    new "Aber du kannst es, also wird jede Art von sexueller Aktivität dir helfen, magische Energie zu generieren. Je intensiver oder höher die sexuelle Erregung, desto mehr magische Kraft bekommst du..."

    # say L202 bri
    old "That is why within your objectives as a chosen, you must have a lot of sex, only then can you restore the magical world and regenerate the sources of magical power..."
    new "Deshalb musst du als Auserwählter viel Sex haben, nur dann kannst du die magische Welt wiederherstellen und die Quellen der magischen Energie regenerieren..."

    # say L204 pla
    old "What the Fuck? You didn't tell me that..."
    new "Was zum Teufel? Das hast du mir nicht gesagt..."

    # say L206 bri
    old "I'm telling you right now... It's that there are many things and I don't remember them all..."
    new "Ich sag's dir jetzt... Es gibt viele Dinge, und ich erinnere mich nicht an alles..."

    # say L208 pla
    old "So I have to have a lot of sex to receive magical power?"
    new "Dann muss ich viel Sex haben, um magische Kraft zu bekommen?"

    # say L210 bri
    old "Actually, You must seek to reach the maximum of sexual arousal, so you must experiment a lot to see what is the most exciting for you..."
    new "Tatsächlich, du musst das Maximum der sexuellen Erregung erreichen, also musst du viel experimentieren, um herauszufinden, was dich am meisten aufgeilt."

    # say L212 pla
    old "Hmmm... Ok, I'll see how to do something about it"
    new "Hmmm... Okay, ich seh mal, was ich machen kann."

    # say L234 pla
    old "It was great..."
    new "Es war toll..."

    # say L235 bri
    old "Yes, it was really fun... I want to do it again."
    new "Ja, es war wirklich toll... Ich will es wieder tun."

    # say L236 pla
    old "Maybe later when I get more Magic Power..."
    new "Vielleicht später, wenn ich mehr Magie habe..."

    # say L255 bri
    old "There you go [pla]."
    new "Da hast du es [pla]."

    # say L256 bri
    old "Let yourself enjoy this."
    new "Lass dich darauf ein."

    # say L257 bri
    old "It's very important that you relax."
    new "Es ist sehr wichtig, dass du dich entspannst."

    # say L261 bri
    old "Are you liking this [pla]?"
    new "Magst du das [pla]?"

    # say L263 bri
    old "Good! That's the most important part!"
    new "Gut! Das ist der wichtigste Teil!"

    # say L268 bri
    old "I've always thought this [pla]! But as a human, your cock is very impressive!"
    new "Ich hab das schon immer gedacht [pla]! Aber als Mensch ist dein Schwanz echt beeindruckend!"

    # say L269 bri
    old "It's incredible that is rock hard!"
    new "Das ist unglaublich, dass es so hart ist!"

    # say L292 pla
    old "I- I feel like I'm about to cum Brixxida!"
    new "Ich- Ich glaube, ich komme gleich, Brixxida!"

    # say L293 bri
    old "Yeah! That's good! Do it!"
    new "Ja! Das ist gut! Mach es!"

    # say L294 bri
    old "Cum! I want you to shoot everything into the portal!"
    new "Komm! Ich will, dass du alles in das Portal spritzt!"

    # say L300 bri
    old "That's perfect [pla]!"
    new "Das ist perfekt [pla]!"

    # say L301 bri
    old "Look at that! I can already tell that the portal is starting to charge!"
    new "Schau dir das an! Ich kann schon sehen, dass das Portal sich auflädt!"


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/whiAnimations.rpy
translate german strings:

    # say L6 whi
    old "Give me that big cock..."
    new "Geben Sie mir diesen großen Schwanz..."

    # say L8 whi
    old "Oh my, you've definitely grown a lot! "
    new "Oh mein, Sie sind definitiv gewachsen!"

    # say L12 whi
    old "Uhh, it feels so warm and hard."
    new "Uhh, es fühlt sich so warm und hart an."

    # say L14 pla
    old "Y- yes it feels nice too."
    new "Y- ja, es fühlt sich auch gut an."

    # say L18 whi
    old "What about if you cum for mommy?"
    new "Was wäre, wenn du für Mommy kommst?"

    # say L43 whi
    old "Mrs. W- white I- I-"
    new "Mrs. W- white I- I- kann nicht..."

    # say L44 whi
    old "Ohh, yeah baby..."
    new "Ohh, ja Baby..."

    # say L45 whi
    old "Give it to mommy!"
    new "Geben Sie es der Mama!"

    # say L53 whi
    old "I have to say, [pla], you have a wonderful cock."
    new "Ich muss sagen, [pla], Sie haben einen wunderbaren Schwanz."

    # say L54 pla
    old "Uhh... T-thanks..."
    new "Uhh... D-danke..."

    # say L64 pla
    old "Wow! Mrs. White, w- what are you doing?"
    new "Wow! Mrs. White, w- was machst du da?"

    # say L65 whi
    old "Just enjoy it baby... Mommy is gonna blow your mind..."
    new "Genieße es, Schatz... Mama wird dir den Verstand rauben..."

    # say L66 pla
    old "(Holly shit!)"
    new "Verdammt!"

    # say L70 whi
    old "Oh God, you got a huge cock..."
    new "Oh Gott, Sie haben einen riesigen Schwanz..."

    # say L71 whi
    old "It hardly fits in my mouth."
    new "Es passt kaum in meinen Mund."

    # say L76 whi
    old "Do you want to cum in my mouth?"
    new "Möchten Sie in meinem Mund kommen?"

    # say L78 whi
    old "I wanna taste it!"
    new "Ich will es kosten!"

    # say L101 whi
    old "Oh yeah, cum for mommy!"
    new "Oh ja, spritz für Mama!"

    # say L102 whi
    old "Give me all that cum baby."
    new "Geben Sie mir alles, Baby."

    # say L121 whi
    old "By the way, you haven't said anything about the food. Are you liking it?"
    new "Übrigens, Sie haben noch gar nichts zu dem Essen gesagt. Gefällt es Ihnen?"

    # say L122 pla
    old "Oh... yes ma'am, I- I like it... a lot."
    new "Oh... ja, ich... ich mag es... sehr."

    # say L123 whi
    old "It makes me so happy to hear you say that."
    new "Das macht mich so glücklich, das zu hören."

    # say L124 whi
    old "I made everything with my... hands, after all."
    new "Ich habe alles mit meinen... Händen gemacht."

    # say L125 mik
    old "Yes, It's really good mom, thank you."
    new "Ja, es ist wirklich gut, Mama, danke."

    # say L130 whi
    old "I see you're enjoying it a lot, right [pla]?"
    new "Ich sehe, dass es Ihnen sehr schmeckt, stimmt's [pla]?"

    # say L131 pla
    old "Mmm... Y- yes ma'am, I- I like it a lot!"
    new "Mmm... J- ja, ich mag es sehr!"

    # say L132 whi
    old "Well, have as much as you like."
    new "Nun, nehmen Sie sich so viel, wie Sie mögen."

    # say L133 whi
    old "You can ask me for more whenever you want to."
    new "Sie können mich jederzeit um mehr bitten."

    # say L134 mik
    old "Yeah, I think I would like to repeat."
    new "Ja, ich denke, ich würde das gerne wiederholen."

    # say L155 whi
    old "Look at that [pla], you're almost done!"
    new "Schauen Sie sich das an, [pla], Sie sind fast fertig!"

    # say L156 whi
    old "Would you finish for me?"
    new "Würden Sie das für mich beenden?"

    # say L157 pla
    old "Mmm... Yes Mrs. White..."
    new "Mmm... Ja, Mrs. White..."

    # say L164 whi
    old "Well, it looks like you're done, did you enjoy it [pla]?"
    new "Nun, es sieht so aus, als wären Sie fertig, haben Sie es genossen [pla]?"

    # say L165 pla
    old "Y- yes Mrs. White, it was very pleasing."
    new "Y- ja Mrs. White, es war sehr angenehm."

    # say L166 mik
    old "What? But he hasn't finished his food... Why do you say he is done?"
    new "Was? Aber er hat sein Essen noch nicht aufgegessen... Warum sagen Sie, dass er fertig ist?"

    # say L167 whi
    old "Trust me honey, [pla] is completely satisfied."
    new "Vertrau mir, Schatz, [pla] ist vollkommen zufrieden."

    # say L168 whi
    old "Anyway, Mike, please take the dishes to the kitchen."
    new "Na los, Mike, bringen Sie doch bitte die Teller in die Küche."

    # say L169 mik
    old "Hmm, sure."
    new "Hmm, klar."

    # say L182 whi
    old "Mmm, yes, this big dick."
    new "Mmm, ja, dieser große Schwanz."

    # say L183 whi
    old "It tastes so good in my mouth."
    new "Es schmeckt so gut in meinem Mund."

    # say L185 whi
    old "Just relax and enjoy it, like I'm enjoying it."
    new "Lassen Sie sich einfach gehen und genießen Sie es, wie ich es genieße."

    # say L189 whi
    old "God! I swear it's getting even bigger!"
    new "Oh Gott! Ich schwöre, es wird noch größer!"

    # say L190 whi
    old "This is just what I wanted!"
    new "Das ist genau das, was ich wollte!"

    # say L191 whi
    old "Are you enjoying it [pla]?!"
    new "Genießen Sie es [pla]?!"

    # say L192 pla
    old "Y- Yes ma'am!"
    new "J-Ja, Ma'am!"

    # say L196 whi
    old "Yes! Shove that dick down my throat!!"
    new "Ja! Stoß deinen Schwanz in meinen Mund!"

    # say L197 whi
    old "Push it!"
    new "Stoßen Sie zu!"

    # say L198 whi
    old "Yes, fuck my mouth like that..."
    new "Ja, ficken Sie meinen Mund so..."

    # say L199 whi
    old "Don't come yet! I want it a little longer!"
    new "Noch nicht kommen! Ich will es noch ein bisschen länger!"

    # say L222 pla
    old "M- Mrs. White! I can't hold it anymore!"
    new "M- Mrs. White! Ich kann es nicht mehr zurückhalten!"

    # say L223 whi
    old "Mmmm! It's ok, you can cum!"
    new "Mmmm! Es ist in Ordnung, du darfst kommen!"

    # say L224 whi
    old "Cum for mommy!"
    new "Komm für Mama!"

    # say L225 whi
    old "Give me all your load!"
    new "Geben Sie mir alles!"

    # say L230 whi
    old "Mmm, I love your cum."
    new "Mmm, ich liebe deinen Saft."

    # say L231 whi
    old "It's like a very nice, hot, sweet treat!"
    new "Es ist wie ein sehr nettes, heißes, süßes Leckeres!"

    # say L232 pla
    old "Mrs. White, I- I think we should get dressed."
    new "Mrs. White, ich- ich glaube, wir sollten uns jetzt anziehen."

    # say L233 whi
    old "Oh no, what are you talking about?"
    new "Oh nein, wovon reden Sie?"

    # say L234 whi
    old "We're only getting started, that was just the beginning."
    new "Wir sind doch gerade erst angekommen, das war erst der Anfang."

    # say L235 whi
    old "Now it's time for the main course."
    new "Jetzt kommt der Hauptgang."

    # say L239 whi
    old "Oh fuck! He arrived already!"
    new "Oh Scheiße! Er ist schon da!"

    # say L240 pla
    old "Shit! He's gonna catch us! We better get dressed quickly."
    new "Scheiße! Er kriegt uns noch! Wir sollten uns schnell anziehen."

    # say L242 whi
    old "I'm in here honey!"
    new "Ich bin hier drin, Liebling!"

    # say L243 whi
    old "Just give me a second!"
    new "Einen Moment bitte!"

    # say L244 whi
    old "Hmm, this is annoying, he has to come back just when things are getting good!"
    new "Hmm, das ist ärgerlich, er muss gerade jetzt zurückkommen, wenn es spannend wird!"

    # say L245 pla
    old "We should just hurry up."
    new "Wir sollten uns beeilen."

    # say L257 whi
    old "Mmm, look how hard it is."
    new "Mmm, gucken Sie, wie hart es schon ist."

    # say L258 whi
    old "And you were pretending to be nervous."
    new "Und Sie haben so getan, als wären Sie nervös."

    # say L260 whi
    old "Just relax, I'll make you cum before you know it."
    new "Entspannen Sie sich, ich werde Sie kommen lassen, bevor Sie es wissen."

    # say L264 pla
    old "M- Mrs. White... Mmm, Mike could come back a- any minute."
    new "M- Mrs. White... Mmm, Mike könnte jeden Moment zurückkommen."

    # say L265 whi
    old "You're right, this is so naugthy!"
    new "Sie haben recht, das ist ja so frech!"

    # say L266 whi
    old "I love this adrenaline rush."
    new "Ich liebe diesen Adrenalinschub."

    # say L270 whi
    old "Mmm, yes, like that."
    new "Mmm, ja, genau so."

    # say L271 whi
    old "Just enjoy it, I'll keep going."
    new "Genießen Sie es einfach, ich mache weiter."

    # say L272 whi
    old "I love how your cock twitches in my mouth."
    new "Ich liebe es, wie dein Schwanz in meinem Mund zuckt."

    # say L295 whi
    old "I can feel you getting close!"
    new "Ich spüre, wie du gleich kommst!"

    # say L296 whi
    old "Do it, cum in my mouth!"
    new "Machen Sie, spritzen Sie in meinen Mund!"

    # say L297 whi
    old "I'll swallow it all!"
    new "Ich schlucke alles!"

    # say L304 whi
    old "Oh, I loved that!"
    new "Oh, das habe ich geliebt!"

    # say L305 whi
    old "You were so excited, and you got soo hard!"
    new "Sie waren so aufgeregt, und Sie sind so hart geworden!"

    # say L306 whi
    old "I think I'll do this again... "
    new "Ich denke, ich werde das nochmal machen..."

    # say L307 pla
    old "M- mrs. White, I think you should clean up before Mike comes back."
    new "M- Mrs. White, ich denke, du solltest dich vorher saubermachen, bevor Mike zurückkommt."

    # say L308 whi
    old "Sure, sure, it will be just a second."
    new "Natürlich, natürlich, es dauert nur einen Moment."

    # say L317 whi
    old "Ah Yes! This big dick is just what I needed today."
    new "Ah ja! Dieser große Schwanz ist genau das, was ich heute gebraucht habe."

    # say L318 whi
    old "I'll never get tired of the smell of your cock."
    new "Ich werde mich nie am Geruch deines Schwanzes sattsehen."

    # say L319 whi
    old "It's making me so wet!"
    new "Es macht mich so nass!"

    # say L323 whi
    old "Mmm, yes, like that, enjoy it!"
    new "Mmm, ja, wie das, genieße es!"

    # say L324 whi
    old "Are you liking it you sweet boy?"
    new "Gefällt es Ihnen, mein süßer Junge?"

    # say L326 pla
    old "I-I am!."
    new "Ich-Ich bin!"

    # say L330 whi
    old "Mmmm! Slrrp! This taste is the best!"
    new "Mmmm! Schlürf! Dieser Geschmack ist der beste!"

    # say L331 whi
    old "Your dick feels so hot inside my mouth!"
    new "Ihr Schwanz fühlt sich so heiß in meinem Mund an!"

    # say L332 whi
    old "Do you like it [pla]?! Tell me!"
    new "Gefällt es Ihnen [pla]?! Sagen Sie es mir!"

    # say L333 pla
    old "Yes ma'am! I do!"
    new "Ja, Ma'am! Das tue ich!"

    # say L356 whi
    old "Your dick! Is twitching!"
    new "Ihr Schwanz! Zuckt!"

    # say L357 whi
    old "I want you to cum! Do it!"
    new "Ich will, dass du kommst! Mach es!"

    # say L358 pla
    old "I- I'm about to...!"
    new "Ich- Ich bin gleich soweit...!"

    # say L359 whi
    old "Yes! Give me your cum!"
    new "Ja! Geben Sie mir Ihren Saft!"

    # say L364 whi
    old "Oh yes! It's always so good to have your dick in my mouth."
    new "Oh ja! Es ist immer so gut, deinen Schwanz in meinem Mund zu haben."

    # say L365 whi
    old "I'll never get tired of it."
    new "Ich werde mich daran nie langweilen."

    # say L366 pla
    old "Listen, Mrs. White, I think I just heard someone move outside."
    new "Hören Sie, Mrs. White, ich glaube, ich habe gerade jemanden draußen gehört."

    # say L367 pla
    old "We should hurry up and..."
    new "Wir sollten uns beeilen und..."

    # say L368 whi
    old "What are you talking about?"
    new "Wovon reden Sie?"

    # say L369 whi
    old "We're not done yet."
    new "Wir sind noch nicht fertig."

    # say L370 whi
    old "And last time we were interrupted when Mike got home."
    new "Und beim letzten Mal wurden wir unterbrochen, als Mike nach Hause kam."

    # say L371 whi
    old "So, you're not going anywhere. There's something else that I want right now!"
    new "So, Sie gehen nirgendwo hin. Da ist noch etwas, das ich jetzt will!"

    # say L387 whi
    old "Oh! Yes! That's it!"
    new "Oh! Ja! Genau das!"

    # say L388 whi
    old "I've been wanting for you to be inside me for a while!"
    new "Ich wünsche mir schon seit einer Weile, dass Sie in mir sind!"

    # say L389 whi
    old "Yes! Like that, move a little faster."
    new "Ja! So, bewegen Sie sich ein bisschen schneller."

    # say L393 whi
    old "Oh boy, oh my sweet boy, yes, keep fucking me."
    new "Oh Junge, oh mein süßer Junge, ja, fick mich weiter."

    # say L394 whi
    old "Oh yeah! Oh do you like how my pussy feels?"
    new "Oh ja! Oh, gefällt dir mein Pussy so?"

    # say L395 pla
    old "Uhh yes, it feels amazing!"
    new "Uhh ja, es fühlt sich unglaublich an!"

    # say L399 whi
    old "Ah! I love your dick!"
    new "Ah! Ich liebe deinen Schwanz!"

    # say L400 whi
    old "Do you like that baby? Do you like how I fuck you?"
    new "Magst du das, Schatz? Magst du, wie ich dich ficke?"

    # say L401 pla
    old "I- I think I'm about to finish!"
    new "Ich- Ich glaube, ich komme gleich!"

    # say L402 whi
    old "Not yet, keep going baby boy!"
    new "Noch nicht, mach weiter, mein Junge!"

    # say L425 pla
    old "M- Mrs. White, I can't hold it anymore!"
    new "M- Mrs. White, ich kann es nicht mehr zurückhalten!"

    # say L426 whi
    old "It's ok, cum inside."
    new "Es ist in Ordnung, komm in mir."

    # say L427 whi
    old "Fill me up sweety!"
    new "Füllen Sie mich aus, Schatz!"

    # say L433 whi
    old "Wow, that was great!"
    new "Wow, das war toll!"

    # say L434 whi
    old "I'd been wanting to fuck you so bad."
    new "Ich hatte solche Sehnsucht danach, Sie zu ficken."

    # say L435 whi
    old "And you were even better than I imagined you would be."
    new "Und Sie waren sogar noch besser, als ich es mir vorgestellt hatte."

    # say L436 whi
    old "Did you like it too baby boy?"
    new "Hat es dir auch gefallen, mein Junge?"

    # say L437 pla
    old "Uh, yes, I really did."
    new "Uh, ja, ich hab's wirklich genossen."

    # say L438 pla
    old "Listen Mrs. White I think it's better if I get dressed and leave."
    new "Hören Sie, Mrs. White, ich denke, es ist besser, wenn ich mich anziehe und gehe."

    # say L439 pla
    old "I've been here for a while and I don't want Mike to catch us."
    new "Ich bin schon eine Weile hier und will nicht, dass Mike uns erwischt."

    # say L440 whi
    old "Yeah, I think so too. It would be better."
    new "Ja, ich denke auch. Es wäre besser."

    # say L441 whi
    old "I'll see you and that big cock later."
    new "Ich sehe Sie und diesen großen Schwanz später."

    # say L454 mik
    old "By the way, let me get back to what I was telling you before."
    new "Übrigens, lass mich da weitermachen, wo ich vorhin aufgehört habe."

    # say L455 mik
    old "It was about Belle."
    new "Es ging um Belle."

    # say L456 mik
    old "She wanted me to ask you if you could let us see the project you did with Hinn."
    new "Sie wollte, dass ich dich frage, ob wir uns das Projekt ansehen dürfen, das du mit Hinn gemacht hast."

    # say L457 mik
    old "It's for reference, we're very late with it, and she says that since it is my fault that we're late, I should ask you."
    new "Es ist für die Referenz, wir sind schon sehr spät dran, und sie sagt, da es meine Schuld ist, dass wir zu spät kommen, sollte ich dich fragen."

    # say L459 mik
    old "Woah, are you ok dude? You look kinda tense."
    new "Woah, geht's dir gut, Kumpel? Du siehst irgendwie angespannt aus."

    # say L460 pla
    old "Yeah... it's just... the sauce. I think it had something spicy in it."
    new "Ja... es ist nur... die Soße. Ich glaube, da war was scharf drin."

    # say L461 mik
    old "Yeah, I think my mom put some chili in it, but it's very good anyway."
    new "Ja, ich glaube, meine Mum hat da ein bisschen Chilli reingetan, aber es ist trotzdem sehr lecker."

    # say L462 pla
    old "I- it is. Yeah she is really good..."
    new "I- ist es. Ja, sie ist wirklich gut..."

    # say L463 pla
    old "Uhhh... You need the project? Sure."
    new "Uhhh... Brauchst du das Projekt? Klar."

    # say L464 pla
    old "I- I have it on my... Mmmm... computer, I'll email it to you."
    new "I- Ich hab's auf meinem... Mmmm... Computer, ich schick's dir per E-Mail."

    # say L465 mik
    old "Really? Thanks man you are the best."
    new "Wirklich? Danke Mann, du bist der Beste."

    # say L484 mik
    old "Oh, I forgot, Olivia told me she saw you the other day when she was leaving."
    new "Oh, ich hab's vergessen, Olivia hat mir erzählt, dass sie dich neulich gesehen hat, als sie gegangen ist."

    # say L486 pla
    old "Oh yeah, I- I think we... crossed over... Ahh... on the way out."
    new "Oh ja, ich glaube wir... sind uns... auf dem Weg raus begegnet."

    # say L487 mik
    old "Hmm... Yeah, that's what she told me. But dude, she was super angry about running into you."
    new "Hmm... Ja, das hat sie mir auch gesagt. Aber Mann, sie war total sauer, dass sie dir über den Weg gelaufen ist."

    # say L488 mik
    old "Please, don't tell anyone dude, or she won't talk to me anymore. Please?"
    new "Bitte, erzähl es niemandem, Mann, sonst redet sie nicht mehr mit mir. Bitte?"

    # say L489 pla
    old "S- Sure... no problem!"
    new "Klar... kein Problem!"

    # say L491 mik
    old "Thank you, you are a really good friend."
    new "Danke, du bist echt ein guter Freund."

    # say L510 mik
    old "Dude, you sure you are ok?"
    new "Kumpel, bist du dir sicher, dass es dir gut geht?"

    # say L511 pla
    old "Mmm... Y- yeah... Ugh, sure... N- no problem."
    new "Mmm... J- ja... Ugh, klar... N- nein, kein Problem."

    # say L512 mik
    old "You should drink some water."
    new "Du solltest was Wasser trinken."

    # say L514 pla
    old "Hmm, I'm definitely not the only one who will drink something."
    new "Hmm, ich bin definitiv nicht der Einzige, der was trinken wird."

    # say L516 pla
    old "Oh... Never mind, it's just the spice talking here."
    new "Oh... Lass es, das sind nur die Gewürze, die da reden."

    # say L554 mik
    old "Dude, I'm starting to get worried. You look like you're about to burts. Here, let me hand you..."
    new "Kumpel, ich mache mir echt Sorgen. Du siehst aus, als würdest du gleich platzen. Hier, lass mich dir..."

    # say L555 pla
    old "N- no... i- it's ok, I'm just feeling a little bad."
    new "N-nein... i-ich bin okay, ich fühle mich nur ein bisschen schlecht."

    # say L556 pla
    old "Just give me a minute."
    new "Gib mir einfach eine Minute."

    # say L557 mik
    old "Are you sure? I think you should relax and release everything."
    new "Bist du sicher? Ich denke, du solltest dich entspannen und alles loslassen."

    # say L558 pla
    old "Ughh... That's exactly what I'm going to do..."
    new "Ughh... Das werde ich auch tun."

    # say L578 whi
    old "Mmmm! It's so big, so thick and long!"
    new "Mmmm! Es ist so groß, so dick und lang!"

    # say L579 whi
    old "I was waiting for this, baby boy!"
    new "Ich habe darauf gewartet, Baby boy!"

    # say L580 whi
    old "That's it, fill me up!"
    new "Das ist es, füll mich aus!"

    # say L585 whi
    old "I love how hot your cock is in my pussy!"
    new "Ich liebe, wie heiß dein Schwanz in meiner Pussy ist!"

    # say L586 whi
    old "I can feel it filling me up!"
    new "Ich spüre, wie es mich ausfüllt!"

    # say L587 whi
    old "It's so big and hot!"
    new "Es ist so groß und heiß!"

    # say L591 whi
    old "Oh god! This dick! I love it!"
    new "Oh Gott! Dieser Schwanz! Ich liebe ihn!"

    # say L592 whi
    old "MMMM! AAAAH! Yes! Yes!"
    new "MMMM! AAAAH! Ja! Ja!"

    # say L593 whi
    old "I love your cock sweetie!"
    new "Ich liebe deinen Schwanz, Schatz!"

    # say L594 whi
    old "I love to feel your cock inside me my baby boy!"
    new "Ich liebe es, deinen Schwanz in mir zu spüren, mein Baby-Boy!"

    # say L617 pla
    old "I-I'm about to finish Mrs. White!"
    new "Ich komme gleich, Mrs. White!"

    # say L618 whi
    old "YES! YES! ME TOO!"
    new "JA! JA! MIR AUCH!"

    # say L619 whi
    old "Do it! Cum in my pussy!"
    new "Machen Sie es! Kommen Sie in meine Pussy!"

    # say L620 whi
    old "Do it my sweet baby!"
    new "Machen Sie es, mein süßer Schatz!"

    # say L624 whi
    old "Phew, that was amazing!"
    new "Puh, das war unglaublich!"

    # say L625 pla
    old "Ohh yeah."
    new "Ohh ja."

    # say L640 whi
    old "H- Hi son, I- I'm ok."
    new "H- Hallo Sohn, i- ich bin in Ordnung."

    # say L641 whi
    old "I wasn't expecting you to come home so quickly."
    new "Ich habe dich nicht so schnell zu Hause erwartet."

    # say L643 mik
    old "Yeah, me either. But Olivia said she had to take care of some personal things."
    new "Ja, ich auch nicht. Aber Olivia sagte, sie müsste sich um einige persönliche Dinge kümmern."

    # say L644 mik
    old "So, I had to come early."
    new "Dann musste ich eben früher kommen."

    # say L645 whi
    old "Oh, I see, well..."
    new "Oh, ich verstehe, na ja..."

    # say L646 whi
    old "Since you have some free time, why don't you go up to your room and play some video games?"
    new "Da Sie etwas freie Zeit haben, warum gehen Sie nicht in Ihr Zimmer und spielen ein paar Videospiele?"

    # say L647 whi
    old "Or just relax, you've been studying a lot these days, you deserve a break."
    new "Oder einfach nur entspannen, Sie haben in letzter Zeit viel gelernt, Sie verdienen eine Pause."

    # say L648 mik
    old "Sure, but first I'm going to grab a snack from the kitchen."
    new "Klar, aber erst hole ich mir was zu essen aus der Küche."

    # say L654 whi
    old "Wait!"
    new "Warten Sie!"

    # say L655 mik
    old "What? What happens?"
    new "Was? Was ist los?"

    # say L656 whi
    old "Ehhh... Just, I know you're tired."
    new "Ehhh... Nur, ich weiß, dass Sie müde sind."

    # say L657 whi
    old "So, why don't you just go up and I'll prepare and bring you some snacks?"
    new "Na, warum gehen Sie nicht einfach nach oben und ich bereite Ihnen ein paar Snacks zu?"

    # say L658 mik
    old "Wow, really?"
    new "Wow, echt?"

    # say L659 whi
    old "Yeah sure, just go up and I'll be there in a bit."
    new "Natürlich, gehen Sie ruhig hoch und ich komme gleich nach."

    # say L660 mik
    old "Ok, thanks mom!"
    new "Ok, danke Mom!"

    # say L666 whi
    old "Phew, that was really close"
    new "Puh, das war wirklich knapp"

    # say L667 pla
    old "I knew he was going to catch us!"
    new "Ich wusste, dass er uns erwischen würde!"

    # say L668 pla
    old "We should have gone to your room!"
    new "Wir hätten in dein Zimmer gehen sollen!"

    # say L669 whi
    old "Calm down, he didn't see anything."
    new "Beruhigen Sie sich, er hat nichts gesehen."

    # say L670 whi
    old "But we don't have time to talk about that."
    new "Aber wir haben jetzt keine Zeit, darüber zu sprechen."

    # say L675 mik
    old "Mom! Do you think you could bring me a soda with the snacks?"
    new "Mom! Könnten Sie mir bitte eine Cola mit den Snacks bringen?"

    # say L677 whi
    old "Now, quickly, leave!"
    new "Jetzt, schnell, geh!"

    # say L678 pla
    old "Ok, ok, I'm going!"
    new "Okay, okay, ich geh ja schon!"

    # say L692 whi
    old "Ah! Ah! Ah! That's it sweety, fuck me just like that."
    new "Ah! Ah! Ah! Das ist es, Liebling, fick mich genau so."

    # say L693 whi
    old "I- I can feel your entire dick! It's so long and thick!"
    new "Ich- Ich kann Ihren ganzen Schwanz spüren! Er ist so lang und dick!"

    # say L694 whi
    old "Yes! This is just what I wanted!"
    new "Ja! Das ist genau das, was ich wollte!"

    # say L698 whi
    old "Ah! It's so good!"
    new "Ah! Das ist so gut!"

    # say L699 whi
    old "Mmm I love your big cock!"
    new "Mmm, ich liebe Ihren großen Schwanz!"

    # say L700 whi
    old "Ohh yeah, just like that baby!"
    new "Ohh ja, genau so, Baby!"

    # say L704 whi
    old "Fuck! YES! YES! FUCK ME MORE!"
    new "Fick! JA! JA! FICK MICH Mehr!"

    # say L705 whi
    old "Fuck me, fuck your mommy!"
    new "Ficken Sie mich, ficken Sie Ihre Mommy!"

    # say L706 whi
    old "Keep pounding me!"
    new "Ficken Sie mich weiter!"

    # say L729 whi
    old "I- I can feel you tensing up!"
    new "Ich spüre, wie Sie sich anspannen!"

    # say L730 whi
    old "Do it! CUM! CUM INSIDE ME!"
    new "Machen Sie es! KOMMEN SIE! KOMMEN SIE IN MIR!"

    # say L731 pla
    old "Y-yes!"
    new "J-ja!"

    # say L732 whi
    old "Ahhh! This is the best cock I've ever had!"
    new "Ahhh! Das ist der beste Schwanz, den ich je hatte!"

    # say L738 whi
    old "That was very good sweety!"
    new "Das war sehr gut, Schatz!"

    # say L739 whi
    old "You keep doing it better and better. You just keep making me want that cock even more every time..."
    new "Sie machen es immer besser und besser. Sie lassen mich jedes Mal noch mehr nach diesem Schwanz verlangen..."

    # say L740 pla
    old "I'm glad you liked it Mrs. White."
    new "Ich freue mich, dass es dir gefallen hat, Mrs. White."

    # say L741 whi
    old "I didn't just like it, I loved it!"
    new "Ich habe es nicht nur gemocht, ich habe es geliebt!"

    # say L742 whi
    old "And I hope you know we'll be doing it again very soon."
    new "Und ich hoffe, Sie wissen, dass wir es bald wieder tun werden."


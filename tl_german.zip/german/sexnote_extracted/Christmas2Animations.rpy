# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/Christmas2Animations.rpy
translate german strings:

    # say L6 lyd
    old "God! Your cock's always so tasty!"
    new "Mann! Dein Schwanz schmeckt immer so gut!"

    # say L7 lyd
    old "Screw Christmas cookies, this is the treat I wanted!"
    new "Vergiss die Weihnachtskekse, das ist der Genuss, den ich wollte!"

    # say L8 lyd
    old "I bet this is the best way you've ever woken up!"
    new "Ich wette, das ist der beste Weg, wie du je aufgewacht bist!"

    # say L12 lyd
    old "Oh yes! I love the way it feels in my mouth!"
    new "Oh ja! Ich liebe das Gefühl in meinem Mund!"

    # say L13 lyd
    old "Do you like to stuff your dick in my mouth in the morning [pla]?"
    new "Magst du es, morgens deinen Schwanz in meinem Mund zu haben [pla]?"

    # say L15 lyd
    old "Do you?!"
    new "Machst du das?"

    # say L16 pla
    old "Y- yes!"
    new "Y- ja!"

    # say L20 lyd
    old "Oh! I love this!"
    new "Oh! Das liebe ich!"

    # say L21 lyd
    old "Mmf! The taste!"
    new "Mmf! Der Geschmack!"

    # menu L39 
    old "Keep going"
    new "Weitermachen"

    # say L44 pla
    old "Lydia! I- I think I'm about to cum!"
    new "Lydia! Ich glaube, ich komme gleich!"

    # say L45 lyd
    old "Yes! Do it! Stuff my mouth with your hot cum!"
    new "Ja! Mach es! Füll meinen Mund mit deinem heißen Sperma!"

    # say L52 lyd
    old "Merry Christmas to me!"
    new "Frohe Weihnachten für mich!"

    # say L53 lyd
    old "That was wonderful [pla]!"
    new "Das war wunderbar [pla]!"

    # say L54 pla
    old "What the hell are you talking about?!"
    new "Was zum Teufel redest du da?!"

    # say L55 pla
    old "You shouldn't just come into my room and do something like that!"
    new "Du solltest nicht einfach in mein Zimmer kommen und so etwas tun!"

    # say L56 pla
    old "What if somebody sees you?!"
    new "Was, wenn jemand dich sieht?!"

    # say L57 lyd
    old "Oh! Relax! You're worrying too much."
    new "Oh! Beruhige dich! Du machst dir zu viele Sorgen."

    # say L58 lyd
    old "Nobody saw anything."
    new "Niemand hat was gesehen."

    # say L59 lyd
    old "And I know you loved it."
    new "Und ich weiß, dass du es geliebt hast."

    # say L60 pla
    old "Hmm, well..."
    new "Hmm, na ja..."

    # say L61 pla
    old "Whatever."
    new "Was auch immer."

    # say L73 sis
    old "Mmm! Oh my god! Your dick!"
    new "Mmm! Oh mein Gott! Dein Schwanz!"

    # say L74 sis
    old "It's great! I can feel its heat!"
    new "Es ist großartig! Ich kann seine Hitze spüren!"

    # say L75 sis
    old "And also, it's sooo long!"
    new "Und es ist auch sooo lang!"

    # say L79 sis
    old "What do you think [pla]? Don't you think this fabric's soft?"
    new "Was denkst du [pla]? Findest du nicht auch, dass der Stoff so weich ist?"

    # say L80 pla
    old "It- it is... really soft!"
    new "Es- es ist... wirklich weich!"

    # say L81 sis
    old "I know, right?"
    new "Ich weiß, oder?"

    # say L82 sis
    old "It's really good quality!"
    new "Es ist wirklich hochwertig!"

    # say L86 sis
    old "Ah! Ah! I love this!"
    new "Ah! Ah! Ich liebe das!"

    # say L87 sis
    old "I can feel your dick rubbing my clit!"
    new "Ich spüre deinen Schwanz, der meine Klitoris reibt!"

    # say L88 sis
    old "And with this fabric, it feels so good!"
    new "Und mit diesem Stoff fühlt es sich so gut an!"

    # say L111 pla
    old "[sis]! I- I'm about to cum!"
    new "[sis]! I- Ich komme gleich!"

    # say L112 sis
    old "Do it, shoot it all out!"
    new "Mach es, lass es alles raus!"

    # say L113 sis
    old "Don't worry about the costume!"
    new "Mach dir um den Kostüm keine Sorgen!"

    # say L114 sis
    old "This fabric is anti-fluid!"
    new "Dieses Material ist flüssigkeitsabweisend!"

    # say L115 sis
    old "Shoot it all out!"
    new "Lass es raus!"

    # say L123 sis
    old "Oh my god! Look at all that thick load coming of your dick."
    new "Oh mein Gott! Schau dir all den dicken Saft an, der aus deinem Schwanz spritzt."

    # say L124 pla
    old "... Right."
    new "... Stimmt."

    # say L125 sis
    old "I just loved the way your dick rubbed againts my clit!"
    new "Ich hab's geliebt, wie dein Schwanz an meiner Klit gerieben hat!"

    # say L126 sis
    old "It turned me on so much!"
    new "Es hat mich total angemacht!"

    # say L127 sis
    old "Ok, I think these new outfits are ready to be posted!"
    new "Ok, ich denke, diese neuen Outfits sind bereit, gepostet zu werden!"

    # say L139 mo2
    old "Oh yes! This lube is perfect!"
    new "Oh ja! Dieses Gleitgel ist perfekt!"

    # say L140 mo1
    old "Just look at how your dick slides between our tits!"
    new "Schau mal, wie dein Schwanz zwischen unseren Titten gleitet!"

    # say L141 lyd
    old "And it feels so hot!"
    new "Und es fühlt sich so heiß an!"

    # say L145 mo1
    old "Do you like how that feels [pla]?"
    new "Magst du das Gefühl [pla]?"

    # say L146 pla
    old "I- I do! It's great!"
    new "Ich- Ich mag es! Es ist toll!"

    # say L147 mo1
    old "That's great baby! I love that you love it!"
    new "Das ist toll, Schatz! Ich freue mich, dass es dir gefällt!"

    # say L148 mo2
    old "Do it faster [pla]! Use that lube!"
    new "Schneller [pla]! Nutz das Gleitgel!"

    # say L152 lyd
    old "Oh! Yes! I love the way your cock bounces between our tits!"
    new "Oh! Ja! Ich liebe, wie dein Schwanz zwischen unseren Titten hüpft!"

    # say L153 mo1
    old "My god [mo2]! This lube is fantastic!"
    new "Mein Gott [mo2]! Diese Gleitgel ist fantastisch!"

    # say L154 mo2
    old "It feels great!"
    new "Es fühlt sich toll an!"

    # say L155 mo2
    old "How much do you like this [pla]?"
    new "Wie sehr magst du das [pla]?"

    # say L156 mo2
    old "Tell us!"
    new "Erzählen Sie uns!"

    # say L157 pla
    old "I- I love it!"
    new "Ich- Ich liebe es!"

    # say L181 pla
    old "I- I'm about to cum!"
    new "Ich- Ich komme gleich!"

    # say L182 pla
    old "I can't hold it in anymore!"
    new "Ich halte es nicht mehr aus!"

    # say L183 mo1
    old "Do it honey!"
    new "Mach es, Schatz!"

    # say L184 lyd
    old "Yes! Do it [pla]! Cum for us!"
    new "Ja! Mach es [pla]! Komme für uns!"

    # say L185 mo2
    old "Make it a white Christmas for us [pla]!"
    new "Mach es zu einem weißen Weihnachten für uns [pla]!"

    # say L194 mo1
    old "Oh that's just great! I love the way your cum tastes [pla]!"
    new "Oh das ist ja toll! Ich liebe den Geschmack deines Spermas [pla]!"

    # say L195 mo2
    old "It's so thick and warm."
    new "Es ist so dick und warm."

    # say L206 sis
    old "Uhgn! Oh my God [pla]!"
    new "Uhgn! Oh mein Gott [pla]!"

    # say L207 sis
    old "How are you this big!"
    new "Wie bist du nur so groß!"

    # say L208 sis
    old "It feels even bigger than the way it looks!"
    new "Es fühlt sich noch größer an, als es aussieht!"

    # say L212 sis
    old "God! I love the way your dick feels me up!"
    new "Scheiße! Ich liebe, wie dein Schwanz mich fickt!"

    # say L213 sis
    old "It's so hot!"
    new "Es ist so heiß!"

    # say L215 sis
    old "Keep going [pla]! Don't stop!"
    new "Weiter so [pla]! Hör nicht auf!"

    # say L219 sis
    old "Oh my God! Oh my God!"
    new "Oh mein Gott! Oh mein Gott!"

    # say L220 sis
    old "Y- You're so hot [pla]!"
    new "Y- Du bist so heiß [pla]!"

    # say L221 sis
    old "This is the best Christmas gift ever!"
    new "Das ist das beste Weihnachtsgeschenk aller Zeiten!"

    # say L222 sis
    old "Oh my God! I love the way you fuck me!"
    new "Oh mein Gott! Ich liebe es, wie du mich fickst!"

    # say L245 pla
    old "[sis] I- I think I'm about to cum! I can't hold it back anymore!"
    new "[sis] Ich- Ich glaube, ich komme gleich! Ich kann es nicht mehr zurückhalten!"

    # say L246 sis
    old "Y- Yes! D- D- Do it!"
    new "Y- Ja! M- Mach es!"

    # say L247 mo2
    old "Yes! Do it! Cum inside your [sisrel]! You little pervert!"
    new "Ja! Mach es! Spritz in deiner [sisrel] ab! Du kleiner Perversling!"

    # say L254 sis
    old "Oh wow! That was so good!"
    new "Oh wow! Das war so gut!"

    # say L255 sis
    old "Honestly [pla], your cock must be magical!"
    new "Ehrlich [pla], dein Schwanz muss magisch sein!"

    # say L256 sis
    old "Because it's insane how crazy good it is!"
    new "Weil es total verrückt gut ist!"

    # say L258 sis
    old "Well, that was the best Christmas gift I think I could've asked for."
    new "Na, das war das beste Weihnachtsgeschenk, das ich mir hätte wünschen können."

    # say L259 sis
    old "Even though I was such a naughty girl all year."
    new "Auch wenn ich das ganze Jahr so ein böses Mädchen war."

    # say L274 mo2
    old "I bet you've been waiting to fuck me!"
    new "Ich wette, du hast schon darauf gewartet, mich zu ficken!"

    # say L275 mo2
    old "Well, you finally get your gift!"
    new "Na, dann kriegst du endlich dein Geschenk!"

    # say L276 mo2
    old "My pussy's been aching for a hard big cock!"
    new "Meine Pussy hat sich nach einem harten, großen Schwanz gesehnt!"

    # say L285 mo2
    old "Mmm! Oh yeah!"
    new "Mmm! Oh ja!"

    # say L286 mo2
    old "That's just the thing I wanted for Christmas!"
    new "Das ist genau das, was ich zu Weihnachten wollte!"

    # say L287 mo2
    old "So big!"
    new "So groß!"

    # say L288 mo2
    old "The girth is just amazing!"
    new "Der Umfang ist einfach unglaublich!"

    # say L292 mo2
    old "I bet you like this, don't you?"
    new "Ich wette, Ihnen gefällt das, oder?"

    # say L293 mo2
    old "You like fucking me like an animal?"
    new "Sie gefällt es, mich wie ein Tier zu ficken?"

    # say L294 mo2
    old "Tell me!"
    new "Sagen Sie es mir!"

    # say L295 pla
    old "I- I do! I like it a lot!"
    new "Ich- Ich tu's! Mir gefällt es sehr!"

    # say L296 mo2
    old "Oh- OH! You little bastard!"
    new "Oh- OH! Du kleiner Bastard!"

    # say L300 mo2
    old "You little pathetic slave! The only good thing about you is that long cock!"
    new "Du kleiner erbärmlicher Sklave! Das Einzige, was an dir gut ist, ist dieser lange Schwanz!"

    # say L301 mo2
    old "You hear me? You're worthless without it!"
    new "Hast du mich gehört? Du bist nichts ohne das!"

    # say L302 mo2
    old "Your cock and balls are only good for this!"
    new "Ihr Schwanz und Ihre Eier sind nur gut dafür!"

    # say L303 mo2
    old "Keep going! Keep fucking me! You worthless slave!"
    new "Weiter so! Fick mich weiter! Du nutzloser Sklave!"

    # say L326 mo2
    old "I- AH! I can feel your cock twitching!"
    new "Ich- AH! Ich spüre, wie dein Schwanz zuckt!"

    # say L327 mo2
    old "Are you about to cum, you little pervert?!"
    new "Bist du kurz davor zu kommen, du kleiner Perversling?!"

    # say L328 pla
    old "I- ugh! I am!"
    new "I- ugh! Ich bin dabei!"

    # say L329 mo2
    old "Do it! Fill me with your worthless cum!"
    new "Mach es! Füll mich mit deinem wertlosen Sperma!"

    # say L337 mo1
    old "Wow [mo2], baby, that looked fantastic!"
    new "Wow [mo2], Baby, das sah fantastisch aus!"

    # say L338 mo2
    old "I guess it was good."
    new "Ich schätze, es war gut."

    # say L353 mo2
    old "I bet you're happy you get to fuck your [mo1rel] on Christmas day, you little pervert."
    new "Ich wette, Sie freuen sich, dass Sie Ihr [mo1rel] an Weihnachten ficken dürfen, Sie kleiner Perversling."

    # say L354 pla
    old "Y-yeah, sure."
    new "Y-ja, klar."

    # say L363 mo1
    old "Oh my god, honey!"
    new "Oh mein Gott, Schatz!"

    # say L364 mo1
    old "Y- Your dick, is so big!"
    new "Oh mein Gott, dein Schwanz ist so groß!"

    # say L365 mo1
    old "It's so hot! So thick!"
    new "Es ist so heiß! So dick!"

    # say L369 mo1
    old "Oh my god I love it!"
    new "Oh mein Gott, ich liebe es!"

    # say L370 mo1
    old "I love to feel you filling me up!"
    new "Ich liebe es, dich in mir zu spüren!"

    # say L371 mo1
    old "D- Do you like it too [pla]?"
    new "D- Magst du es auch [pla]?"

    # say L372 pla
    old "I do! I like it!"
    new "Ich auch! Mir gefällt es!"

    # say L373 mo1
    old "Oh then keep going, honey!"
    new "Oh dann mach weiter, Schatz!"

    # say L377 mo1
    old "Oh yes! Yes! YES!"
    new "Oh ja! Ja! JA!"

    # say L378 mo1
    old "This is what I wanted!"
    new "Das ist genau das, was ich wollte!"

    # say L379 mo2
    old "I bet this makes a very merry Christmas for you, doesn't it [mo1]?"
    new "Ich wette, das macht dir ein sehr fröhliches Weihnachten, oder [mo1]?"

    # say L380 mo1
    old "It does! this is the best Christmas ever!"
    new "Das ist es! Das ist der beste Weihnachten aller Zeiten!"

    # say L403 mo1
    old "I- I think I'm coming!"
    new "I- Ich glaube, ich komme!"

    # say L404 mo1
    old "Come with me [pla]!"
    new "Kommen Sie mit mir [pla]!"

    # say L405 mo1
    old "L- Let's do it together!"
    new "L- Lass uns zusammen kommen!"

    # say L406 pla
    old "Y- Yes!"
    new "Y- Ja!"

    # say L414 mo1
    old "Oh baby. That was the best Christmas gift ever!"
    new "Oh Baby. Das war das beste Weihnachtsgeschenk überhaupt!"

    # say L415 mo1
    old "It's amazing, I'm so satisfied!"
    new "Es ist unglaublich, ich bin so zufrieden!"

    # say L416 lyd
    old "Isn't he just a wonderful young man?"
    new "Ist er nicht einfach ein wunderbarer junger Mann?"

    # say L417 mo1
    old "Your dick is so addicting!"
    new "Dein Schwanz ist so süchtig machend!"

    # say L432 lyd
    old "Well, I've been wanting to fuck you since the morning sweety!"
    new "Na, ich hab schon seit dem Morgen darauf gewartet, dich zu ficken, Schatz!"

    # say L433 lyd
    old "I couldn't keep waiting!"
    new "Ich konnte nicht mehr warten!"

    # say L442 lyd
    old "Oh! Uh! My God! It already feels amazing!"
    new "Oh! Äh! Mein Gott! Das fühlt sich schon unglaublich an!"

    # say L443 lyd
    old "I- Mmm! I can't believe how big and hard you are!"
    new "Ich- Mmm! Ich kann nicht glauben, wie groß und hart du bist!"

    # say L444 lyd
    old "I- It's so amazing!"
    new "Es ist unglaublich!"

    # say L445 mo1
    old "It's incredible how much it fills you up, right?"
    new "Es ist unglaublich, wie sehr es dich ausfüllt, oder?"

    # say L446 lyd
    old "It is!"
    new "Es ist!"

    # say L450 lyd
    old "I- I love your cock!"
    new "I- Ich liebe deinen Schwanz!"

    # say L451 mo2
    old "It seems you weren't a naughty girl this year Lydia."
    new "Es scheint, dass du dieses Jahr kein böses Mädchen warst, Lydia."

    # say L452 mo2
    old "Because look at the gift Santa brought you!"
    new "Weil schau dir das Geschenk an, das Santa dir gebracht hat!"

    # say L453 lyd
    old "Y- Yes! I love it!"
    new "Y- Ja! Ich liebe es!"

    # say L457 lyd
    old "YES! YES! YES!"
    new "JA! JA! JA!"

    # say L458 lyd
    old "Keep going [pla]! Oh yes!"
    new "Weiter so [pla]! Oh ja!"

    # say L459 lyd
    old "Oh! Ah! My God! I love it!"
    new "Oh! Ah! Mein Gott! Das ist unglaublich!"

    # say L460 mo2
    old "That's it [pla]! Fuck her brains out!"
    new "Das ist es [pla]! Fick sie bis sie es nicht mehr aushält!"

    # say L483 lyd
    old "I feel you're close to cum!"
    new "Ich spüre, dass du gleich kommst!"

    # say L484 lyd
    old "I want you to do it!"
    new "Ich will, dass du es tust!"

    # say L485 lyd
    old "Fill me up with your hot cum!"
    new "Füll mich mit deinem heißen Saft!"

    # say L495 lyd
    old "God! That was so good [pla]!"
    new "Oh Gott! Das war so gut [pla]!"

    # say L496 lyd
    old "Your dick is so hot!"
    new "Deine Schwanz ist so heiß!"

    # say L497 lyd
    old "You know, I think it would be easy to get addicted to it."
    new "Du weißt, ich glaube, es wäre leicht, davon süchtig zu werden."

    # say L498 pla
    old "I- I see."
    new "Ich- Ich sehe."


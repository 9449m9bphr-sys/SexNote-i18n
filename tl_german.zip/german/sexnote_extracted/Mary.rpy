# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mary.rpy
translate german strings:

    # say L40 mar
    old "Oh [pla]! To what do I owe your visit? Are you coming to get a checkup?"
    new "Oh [pla]! Was verschafft mir die Ehre deines Besuchs? Bist du hier, um eine Untersuchung zu machen?"

    # say L45 pla
    old "Well... Yes... You told me that."
    new "Na ja... Ja... Das hast du mir gesagt."

    # say L47 mar
    old "Don't worry, boy. I'm here to take care of your health. As many times as you need... Come on, get on the table."
    new "Keine Sorge, Junge. Ich bin hier, um mich um deine Gesundheit zu kümmern. So oft du es brauchst... Komm schon, leg dich auf den Tisch."

    # say L60 pla
    old "Oh, no, I was just leaving. I'm sorry ..."
    new "Oh nein, ich wollte gerade gehen. Tut mir leid..."

    # say L62 mar
    old "Okay, if you need a checkup again, you know where to find me..."
    new "Okay, wenn Sie wieder eine Untersuchung brauchen, wissen Sie, wo Sie mich finden..."

    # say L64 pla
    old "Ok, thank you..."
    new "Ok, danke..."

    # say L117 mo1
    old "Hello, Nurse Mary. Good morning."
    new "Guten Morgen, Schwester Mary."

    # say L120 mar
    old "Good morning! How are you today?"
    new "Guten Morgen! Wie geht es Ihnen heute?"

    # say L122 mo1
    old "Very well, thank you..."
    new "Sehr gut, danke..."

    # say L124 mar
    old "And what about you, boy?"
    new "Und wie geht es Ihnen, junger Mann?"

    # say L126 pla
    old "I'm fine, too. Thank you..."
    new "Mir geht es auch gut. Danke..."

    # say L128 mar
    old "He's very quiet, huhm?"
    new "Er ist sehr ruhig, hmm?"

    # say L130 mo1
    old "He's a bit shy..."
    new "Er ist ein bisschen schüchtern..."

    # say L133 mar
    old "Haha... Well, let's get to the matter at hand... First, take off your clothes."
    new "Haha... Na gut, dann kommen wir mal zur Sache... Erst einmal zieh dich aus."

    # say L139 mar
    old "Ok... Ok... I really don't feel much... I think I'm going to need a second opinion..."
    new "Ok... Ok... Ich fühle mich wirklich nicht wohl... Ich denke, ich brauche eine zweite Meinung..."

    # say L140 mo1
    old "Another practitioner?"
    new "Eine andere Praktikerin?"

    # say L141 mar
    old "Oh, no. That's not necessary... You! Boy. Come here..."
    new "Oh nein. Das ist nicht nötig... Du! Junge. Komm her..."

    # say L143 pla
    old "...I... But I..."
    new "...Ich... Aber ich..."

    # say L144 mar
    old "Come on, come here... This is for the health of your [mo1rel]."
    new "Komm schon, komm her... Das ist für die Gesundheit deiner [mo1rel]."

    # say L146 pla
    old "In that case..."
    new "In dem Fall..."

    # say L147 mar
    old "I know very well that you saw the massage I was giving her... Because you did not take your eyes off of her..."
    new "Ich weiß genau, dass du den Massage gesehen hast, die ich ihr gegeben habe... Denn du konntest die Augen nicht von ihr lassen..."

    # say L149 pla
    old "I... I... Wasn't-"
    new "Ich... Ich... War nicht-"

    # say L150 mar
    old "The idea is to do the same thing I'm doing, but you do it this time, alright?"
    new "Die Idee ist, das Gleiche zu tun, was ich mache, aber du machst es dieses Mal, okay?"

    # say L152 pla
    old "Oh, ok, I will try..."
    new "Oh, ok, ich werde es versuchen..."

    # say L153 mo1
    old "But, nurse, is it okay that-"
    new "Aber, Schwester, ist es in Ordnung, dass-"

    # say L154 mar
    old "Don't worry, I know what I'm doing, ok?"
    new "Machen Sie sich keine Sorgen, ich weiß, was ich tue, ok?"

    # say L155 mo1
    old "Yes, Nurse Mary..."
    new "Ja, Schwester Mary..."

    # say L162 mar
    old "Let's see... put your hands here, cover her breasts well..."
    new "Lass mal sehen... leg deine Hände hier hin, bedecke ihre Brüste gut..."

    # say L163 mar
    old "Very well..."
    new "Sehr gut..."

    # say L164 mar
    old "Now... Start massaging them gently..."
    new "Jetzt... Massiere sie sanft..."

    # say L165 pla
    old "(Oh shit!)... Uhh... But..."
    new "(Och ne!)... Äh... Aber..."

    # say L166 mar
    old "You already have your hands on, just move them a little, kid..."
    new "Du hast deine Hände schon drauf, beweg sie einfach ein bisschen, Kleiner..."

    # say L170 mar
    old "How do they feel, huh?"
    new "Wie fühlen sie sich, hm?"

    # say L171 pla
    old "Hmm... Very soft... Warm..."
    new "Hmm... Sehr weich... Warm..."

    # say L172 mar
    old "Very well... Now, rub a little harder, focus on sensing if you feel anything strange..."
    new "Sehr gut... Jetzt massiere etwas fester, konzentriere dich darauf, ob du etwas Seltsames spürst..."

    # say L176 pla
    old "Well... I really don't feel anything..."
    new "Na ja... Ich spüre wirklich nichts Besonderes."

    # say L177 mar
    old "Well, I think I feel better with that second opinion... However, come for the last appointment on Thursday, do you think that's okay?"
    new "Nun, ich denke, mir geht es mit der zweiten Meinung besser... Aber kommen Sie zur letzten Sitzung am Donnerstag, finden Sie das in Ordnung?"

    # say L178 mo1
    old "It's fine with me, Nurse Mary."
    new "Mir ist es recht, Schwester Mary."

    # say L180 mar
    old "...But young man, you can now take your hands off those tits."
    new "Aber junger Mann, Sie können jetzt Ihre Hände von diesen Titten nehmen."

    # say L187 pla
    old "Sorry... I didn't-"
    new "Entschuldigung... Ich hab nicht-"

    # say L189 mar
    old "Hahaha, I'm just kidding... I think we have a future doctor standing here..."
    new "Ha ha ha, ich mache nur Spaß... Ich denke, wir haben hier einen zukünftigen Arzt stehen..."

    # say L191 mo1
    old "Haha. Yes, [pla] is a very good boy..."
    new "Haha. Ja, [pla] ist ein sehr guter Junge..."

    # say L193 mar
    old "Well, until the next appointment, it was nice to see you!"
    new "Na, bis zum nächsten Termin, war schön, dich zu sehen!"

    # say L195 mo1
    old "You too, Nurse Mary."
    new "Auch Ihnen, Schwester Mary."

    # say L197 mar
    old "See you later, boy..."
    new "Bis später, Junge..."

    # say L199 pla
    old "See... you... too."
    new "Bis später, Mary."

    # say L211 mo1
    old "Hello, Nurse Mary! Good morning."
    new "Hallo, Schwester Mary! Guten Morgen."

    # say L214 mar
    old "Oh, hi, How are you today?"
    new "Oh, hallo, wie geht es Ihnen heute?"

    # say L216 mo1
    old "Very well, thank you."
    new "Sehr gut, danke."

    # say L223 mar
    old "Well, let's take the final exam, and if we still can't identify it, I already have a solution planned. So let's start... now, take off your clothes."
    new "Na dann, lass uns die Abschlussprüfung machen, und wenn wir es immer noch nicht identifizieren können, habe ich schon eine Lösung parat. Also los... zieh dich jetzt aus."

    # say L228 mar
    old "Hmm... Very well... I think we will definitely need another method..."
    new "Hmm... Sehr gut... Ich denke, wir werden definitiv eine andere Methode brauchen..."

    # say L229 mo1
    old "Are you going to need the help of [pla] again?"
    new "Werde ich die Hilfe von [pla] wieder in Anspruch nehmen müssen?"

    # say L230 mar
    old "Maybe later... For now, I'm going to need you to take off your bra."
    new "Vielleicht später... Im Moment muss ich dich bitten, deinen BH auszuziehen."

    # say L233 pla
    old "Uh, well... I think I'm gonna go on and head out..."
    new "Na ja... Ich denke, ich geh dann mal..."

    # say L234 mar
    old "Come on... You have already grabbed her tits, what is the problem to see them now without a bra? You have to be more professional, [pla]..."
    new "Komm schon... Du hast ihre Titten schon angefasst, was ist das Problem, sie jetzt ohne BH zu sehen? Du musst professioneller sein, [pla]..."

    # say L237 mar
    old "Well, what are you waiting for, take off your bra..."
    new "Na, worauf wartest du noch, zieh deinen BH aus..."

    # say L238 mo1
    old "Yes, Nurse..."
    new "Ja, Schwester..."

    # say L241 mar
    old "That's what I'm talking about... much better..."
    new "Das ist es, was ich meine... viel besser..."

    # say L242 mar
    old "Now I can feel every detail better..."
    new "Jetzt kann ich jedes Detail besser spüren..."

    # say L243 mar
    old "Hmm... I'm going to do it harder..."
    new "Hmm... Ich mache es härter..."

    # say L246 mar
    old "Well, I really don't feel anything... But I wouldn't want to get carried away. So it's your turn give me your impression, [pla]."
    new "Na ja, ich spüre eigentlich gar nichts... Aber ich will auch nicht übertreiben. Also, [pla], gib mir dein Feedback."

    # say L249 mo1
    old "Mary, do you really think it is-"
    new "Mary, denkst du wirklich, dass es-"

    # say L250 mar
    old "You guys are so dramatic. Haha. It's just the human body. You have done this before with a bra."
    new "Ihr seid alle so dramatisch. Haha. Es ist doch nur der menschliche Körper. Du hast das schon mal mit einem BH gemacht."

    # say L251 mar
    old "There is no big difference now. You do not have to sexualize everything, you know."
    new "Da ist jetzt nicht viel Unterschied. Ihr müsst nicht alles sexualisieren, wisst ihr."

    # say L252 mo1
    old "Ok, ok, Nurse Mary. If you insist..."
    new "Ok, ok, Schwester Mary. Wenn du darauf bestehst..."

    # say L253 mar
    old "Let's see now. Do the massages again..."
    new "Lass uns mal sehen. Mach die Massagen nochmal..."

    # say L260 mar
    old "That's it, nice... your hands cover her breasts well..."
    new "Das ist es, gut... deine Hände bedecken ihre Brüste gut..."

    # say L263 mar
    old "Start massaging them gently..."
    new "Fang an, sie sanft zu massieren..."

    # say L264 mar
    old "Very well... You can feel them better, right?"
    new "Sehr gut... Du kannst sie besser spüren, oder?"

    # say L265 pla
    old "...Y-Yes ... (Fuck, I'm getting hard)"
    new "...J-Ja... (Scheiße, ich werde hart)"

    # say L266 mar
    old "Very well... Rub a little harder, focus on seeing if you feel anything strange..."
    new "Sehr gut... Reibe ein bisschen fester, konzentriere dich darauf, ob du etwas Seltsames spürst..."

    # say L269 pla
    old "Yes, ma'am..."
    new "Ja, Ma'am..."

    # say L270 pla
    old "Well... I don't really feel anything strange..."
    new "Na ja... Ich spüre nichts Seltsames."

    # say L271 mar
    old "Well, I think that's definite. My final medical verdict is that these babies are in perfect condition... Make sure you take care of them, please."
    new "Nun, ich denke das ist definitiv. Mein endgültiges medizinisches Urteil lautet, dass diese Babys in perfektem Zustand sind... Achten Sie bitte darauf, sich gut um sie zu kümmern."

    # say L272 mo1
    old "You bet, Nurse Mary..."
    new "Natürlich, Schwester Mary..."

    # say L273 mar
    old "Hey... [pla]... thanks for your commitment, but we're done here..."
    new "Hey... [pla]... danke für Ihr Engagement, aber wir sind hier fertig..."

    # say L274 pla
    old "Oh, right, sure... Sorry again..."
    new "Oh, stimmt, klar... Tut mir wieder leid..."

    # say L284 mar
    old "Well, I think that's it..."
    new "Na ja, denke ich mal..."

    # say L286 mar
    old "Wait a second... What do you have there?"
    new "Warte mal... Was hast du da?"

    # say L288 pla
    old "(Oh god no...)"
    new "Oh Gott nein..."

    # say L291 mar
    old "Oh boy, is that all yours?"
    new "Oh Mann, das ist alles deins?"

    # say L293 mar
    old "Hmm... I think this is abnormal... Has a doctor checked you out yet?"
    new "Hmm... Ich glaube, das ist unnormal... Hat dich schon ein Arzt untersucht?"

    # say L295 pla
    old "...Well, umm, no."
    new "...Na ja, äh, nein."

    # say L297 mar
    old "Well, it's time to do it, [pla]..."
    new "Dann ist es höchste Zeit, [pla]..."

    # say L300 mar
    old "Take off all your clothes, young man. I'm going to do a full-body exam..."
    new "Zieh dich aus, junger Mann. Ich werde eine vollständige Körpervorsicht durchführen..."

    # say L302 pla
    old "Now? But... I-"
    new "Jetzt? Aber... ich-"

    # say L304 mar
    old "But nothing! You don't see that this could be a health problem?... It is always best to examine it to make sure there is no issues."
    new "Aber nichts! Sehen Sie denn nicht, dass das ein Gesundheitsproblem sein könnte?... Es ist immer am besten, das zu untersuchen, um sicherzustellen, dass es keine Probleme gibt."

    # say L307 mo1
    old "I  will go out then, Mary..."
    new "Dann werde ich mal rausgehen, Mary..."

    # say L310 mar
    old "Really? He got to see your goods and now you are shy to see his?... Again, it's just a medical procedure. There's no need to freak out about it."
    new "Wirklich? Er durfte deine Schätze sehen und jetzt bist du zu schüchtern, um seine zu sehen?... Immerhin ist es nur eine medizinische Untersuchung. Da muss man sich doch nicht aufregen."

    # say L312 mo1
    old "Ok, nurse..."
    new "Ok, Schwester..."

    # say L319 mar
    old "Well... I see your whole body is normal, except your penis."
    new "Na ja... Ich sehe, dass dein ganzer Körper normal ist, außer deinem Penis."

    # say L321 mar
    old "I mean, for your age, it is normal to have hard erections. But I think you have a lot of tension built, much more than normal actually."
    new "Ich meine, für Ihr Alter ist es normal, starke Erektionen zu haben. Aber ich denke, Sie haben eine Menge Anspannung, viel mehr als normal eigentlich."

    # say L323 mar
    old "Also, your size is not at all common... So I need to relax it in order to evaluate it better..."
    new "Also, deine Größe ist überhaupt nicht normal... Deshalb muss ich es entspannen, um es besser beurteilen zu können..."

    # say L324 pla
    old "...Wha-what do you mean?"
    new "Was meinst du damit?"

    # say L326 mar
    old "It means I'm going to massage it until it is in a relaxed, flaccid state..."
    new "Das bedeutet, ich werde es massieren, bis es in einem entspannten, schlaffen Zustand ist..."

    # say L337 mar
    old "Let's see... I'm going to massage it like this..."
    new "Lass mal sehen... Ich massiere es so..."

    # say L338 mar
    old "How does it feel, boy?"
    new "Wie fühlt es sich an, Junge?"

    # say L339 pla
    old "... It feels... really good."
    new "... Es fühlt sich... echt gut an."

    # say L356 mar
    old "Let's do it a little faster..."
    new "Lass uns ein bisschen schneller werden..."

    # say L365 pla
    old "Nurse... I'm going to..."
    new "Krankenschwester... ich komme..."

    # say L367 mar
    old "That's it... Let it out, [pla]. Relax your body."
    new "Das ist es... Lass es raus, [pla]. Entspann dich."

    # say L369 mar
    old "Wow, that was quite the show... Well, I don't see anything that can affect your overall health..."
    new "Wow, das war ja quite der Auftritt... Na ja, ich sehe nichts, was sich auf deinen Gesundheitszustand auswirken könnte..."

    # say L376 mar
    old "However, I am prescribing that you do these massages anytime you feel tension..."
    new "Allerdings verschreibe ich Ihnen, diese Massagen immer dann durchzuführen, wenn Sie Spannung spüren..."

    # say L378 pla
    old "...Ok, Nurse Mary..."
    new "...Okay, Schwester Mary..."

    # say L381 mo1
    old "Thank you very much, Mary, for helping us both..."
    new "Vielen Dank, Mary, für die Hilfe für uns beide..."

    # say L383 mar
    old "It's a pleasure, Sue. Well, that's it. If you need me again you know where to find me..."
    new "Es war mir ein Vergnügen, Sue. Na ja, das wär's dann. Wenn Sie mich wieder brauchen, wissen Sie ja, wo Sie mich finden..."

    # say L385 mo1
    old "Okay, see you later,Mary..."
    new "Okay, bis später, Mary..."

    # say L387 pla
    old "See you later..."
    new "Bis später..."

    # say L389 mar
    old "You can bet it."
    new "Sie können darauf wetten."

    # say L407 mar
    old "Well, I see you're still in perfect health... That was all for now..."
    new "Na, ich sehe, du bist noch immer kerngesund... Das war's dann für heute..."

    # say L413 mar
    old "If you need a checkup again, you know where to find me..."
    new "Wenn du wieder eine Untersuchung brauchst, weißt du ja, wo du mich findest..."

    # say L415 pla
    old "Ok, thanks..."
    new "Ok, danke..."


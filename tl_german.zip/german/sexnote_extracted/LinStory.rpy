# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/LinStory.rpy
translate german strings:

    # say L6 jon
    old "What was that?!"
    new "Was war das?!"

    # say L7 gra
    old "I have no idea... I'm as surprised as you're right now."
    new "Ich habe keine Ahnung... Ich bin genauso überrascht wie du gerade."

    # say L8 jon
    old "I've been here for many years and it's the first time I hear such strange noise."
    new "Ich bin schon seit vielen Jahren hier und so ein seltsames Geräusch habe ich noch nie gehört."

    # say L15 jon
    old "God! Something strange is happening here... It's not normal for the lights to turn off and on by themselves all the time."
    new "Gott! Irgendetwas Seltsames passiert hier... Es ist nicht normal, dass die Lichter ständig von allein an- und ausgehen."

    # say L16 gra
    old "I know... But... What could it be?"
    new "Ich weiß... Aber... Was könnte es sein?"

    # say L19 jon
    old "A ghost! An evil presence, what else could it be?!"
    new "Ein Geist! Eine böse Präsenz, was sonst könnte es sein?!"

    # say L22 gra
    old "What!? Do you really think so?"
    new "Was!? Meinst du das ernst?"

    # say L23 jon
    old "Of course! I'm not joking... So why do you think this youth is so rotten and lost? It's the devil's work!"
    new "Natürlich! Ich mache keinen Scherz... Und warum denkst du, dass dieser Jugendliche so verdorben und verloren ist? Das ist das Werk des Teufels!"

    # say L24 gra
    old "Yes Mrs. Jones, you're right, must be that. I don't think it's an electricity issue."
    new "Ja, Mrs. Jones, Sie haben recht, es muss daran liegen. Ich glaube nicht, dass es ein Stromproblem ist."

    # say L26 gra
    old "We gotta do something! Fuck... Jesus Christ!"
    new "Wir müssen was tun! Scheiße... Jesus Christus!"

    # say L28 jon
    old "Sister Grace! Watch your mouth, please!"
    new "Schwester Grace! Achten Sie auf Ihre Worte, bitte!"

    # say L30 gra
    old "Sorry Mrs. Jones, but this situation gets on my nerves, it's a ghost or a devil. We must perform an exorcism!."
    new "Entschuldigung, Mrs. Jones, aber die Situation bringt mich auf die Palme. Es ist ein Geist oder der Teufel selbst. Wir müssen einen Exorzismus durchführen!"

    # say L31 jon
    old "We need the pries-"
    new "Wir brauchen den Priester-"

    # say L32 pla
    old "(I should use the Agamoto's eye and check if I can see something...)"
    new "(Ich sollte das Auge des Agamotos benutzen und nachsehen, ob ich etwas erkennen kann...)"

    # say L39 pla
    old "(Oh no! It's not a ghost... It's a shinigami!)"
    new "Oh nein! Es ist kein Geist... Es ist ein Shinigami!"

    # say L40 pla
    old "(But... What happened to her!? Seems she is trapped or...)"
    new "Aber... Was ist mit ihr passiert!? Sieht so aus, als wäre sie gefangen oder so was..."

    # say L41 pla
    old "(She looks like she's in pain... And why does she fly like that??!)"
    new "Sie sieht aus, als hätte sie Schmerzen... Und warum fliegt sie so komisch?!"

    # say L42 pla
    old "(I gotta talk to this shinigami... This has something to do with the magic...)"
    new "Ich muss mit diesem Shinigami reden... Das hat etwas mit der Magie zu tun..."

    # say L45 pla
    old "Hello, Oh! Sorry... I didn't want to interrupt..."
    new "Hallo, Oh! Entschuldigung... Ich wollte nicht stören..."

    # say L50 jon
    old "Oh! Hello [pla] don't worry, we were discussing something important but it's fine..."
    new "Oh! Hallo [pla] machen Sie sich keine Sorgen, wir haben über etwas Wichtiges gesprochen, aber es ist in Ordnung..."

    # say L51 jon
    old "Let me introduce you to our Sister Grace, she is the nun of the church."
    new "Lassen Sie mich Ihnen unsere Schwester Grace vorstellen, sie ist die Nonne der Kirche."

    # say L52 pla
    old "Hi, nice to meet you."
    new "Hallo, schön dich kennenzulernen."

    # say L53 gra
    old "Hi [pla], nice to meet you to."
    new "Hallo [pla], freut mich, Sie kennenzulernen."

    # say L54 pla
    old "I was just passing by to say hell-"
    new "Ich war gerade auf dem Weg, um Hallo zu sagen -"

    # say L55 jon
    old "Hun, something terrible is happening here... We might have the presence of a ghost in the church! Can you believe it?"
    new "Hun, etwas Schreckliches passiert hier... Wir könnten das Auftreten eines Geistes in der Kirche haben! Können Sie das glauben?"

    # say L56 gra
    old "Or a devil... Gosh darn I-!"
    new "Oder ein Teufel... Herrje, ich-!"

    # say L58 jon
    old "Sister Grace, please!"
    new "Schwester Grace, bitte!"

    # say L60 pla
    old "Wait! Why do you think is a ghost?"
    new "Warte! Warum denkst du, es ist ein Geist?"

    # say L62 jon
    old "There are strange noises, the lights turn off and on by themselves... And I'm a very spiritual person, if I'm telling you this is because it is what it is..."
    new "Es gibt seltsame Geräusche, die Lichter gehen von selbst an und aus... Und ich bin eine sehr spirituelle Person, wenn ich Ihnen das sage, dann ist es eben so..."

    # say L63 pla
    old "I- I believe you... But what are you gonna do?"
    new "Ich- Ich glaube dir... Aber was willst du tun?"

    # say L64 gra
    old "An exorcism!"
    new "Eine Exorzismus!"

    # say L66 pla
    old "An exorcism?"
    new "Eine Exorzismus?"

    # say L67 pla
    old "(I have to talk to the girls... They should know what's happening.)"
    new "Ich muss mit den Mädels reden... Sie sollten wissen, was los ist."

    # say L68 jon
    old "Hun, we don't want to scare you..."
    new "Hun, wir wollen dich nicht erschrecken..."

    # say L69 pla
    old "No, I'm not... I gotta go now, I- I have some... Homework to do but I will pass by to see what happens."
    new "Nein, ich bin nicht... Ich muss jetzt los, ich hab noch... Hausaufgaben zu machen, aber ich schau später vorbei, um zu sehen, was los ist."

    # say L70 pla
    old "Perhaps I could help out... Dunno... It's very strange what's happening here."
    new "Vielleicht könnte ich helfen... Keine Ahnung... Es ist sehr seltsam, was hier passiert."

    # say L71 jon
    old "Alright, please take care of yourself."
    new "Alles Gute, passen Sie auf sich auf."

    # say L73 pla
    old "You too Mrs. Jones... Goodbye..."
    new "Auch Sie, Mrs. Jones... Auf Wiedersehen..."

    # say L75 gra
    old "Bye [pla], may God take care of your soul."
    new "Auf Wiedersehen [pla], möge Gott sich deiner Seele annehmen."

    # say L80 pla
    old "(What's happening here, this is weird, I gotta talk to the shinigamis.)"
    new "Was geht hier vor, das ist seltsam, ich muss mit den Shinigamis reden."

    # say L95 pla
    old "(Alright, I'm here... Fortunately there is no one here, I should use the Agamoto's eye and talk with them before someone comes.)"
    new "Okay, ich bin hier... Gott sei Dank ist niemand hier, ich sollte das Auge von Agamoto benutzen und mit ihnen reden, bevor jemand kommt."

    # say L112 pla
    old "Hey girls, I gotta tell you something!"
    new "Hey Mädels, ich muss euch was erzählen!"

    # say L128 mil
    old "Well, hello... We're actually fine and you?"
    new "Na hallo... Wir sind eigentlich gut und du?"

    # say L129 pla
    old "Opss! Sorry... Hi hi..."
    new "Opss! Tut mir leid... Hallo hallo..."

    # say L130 pla
    old "This is something important... I found a new Shinigami at the church..."
    new "Das ist wichtig... Ich habe eine neue Shinigami in der Kirche gefunden..."

    # say L131 pla
    old "I don't know what's happening but she's not fine for sure, she was flying around, looking drowsy..."
    new "Ich hab keine Ahnung, was los ist, aber sie ist definitiv nicht in Ordnung. Sie flog rum und sah total benommen aus..."

    # say L132 gom
    old "A new shinigami? And what do you mean by drowsy?"
    new "Eine neue Shinigami? Und was meinst du mit schlaftrunken?"

    # say L133 pla
    old "Hmm, like very weak... Dunno! Do you guys have any idea of what's happening there?"
    new "Hmm, total schwach... Keine Ahnung! Habt ihr eine Idee, was da los ist?"

    # say L135 mil
    old "What? What was she doing in there?"
    new "Was? Was hat sie da drin gemacht?"

    # say L136 pla
    old "Well, she was flying but it seemed she was stuck in there..."
    new "Na ja, sie flog, aber es sah so aus, als wäre sie da drin stecken geblieben..."

    # say L138 mil
    old "Hmm, alright... I may know what's happening."
    new "Hmm, okay... Ich glaube, ich weiß, was los ist."

    # say L139 mil
    old "If what you said is happening, it might be that the shinigami is in trouble with her energy."
    new "Wenn das passiert, wovon du redest, könnte es sein, dass der Shinigami mit ihrer Energie Schwierigkeiten hat."

    # say L140 mil
    old "I mean, there is no much energy around and she must be stuck in there. When there is not enough energy, we suffer the consequences."
    new "Ich meine, da ist nicht viel Energie drum herum und sie steckt wahrscheinlich fest. Wenn es nicht genug Energie gibt, leiden wir die Folgen."

    # say L141 mil
    old "Most likely she has just a couple of..."
    new "Wahrscheinlich hat sie nur noch ein paar..."

    # say L143 pla
    old "A couple of? Of what?"
    new "Ein paar? Von was?"

    # say L144 mil
    old "A couple of days left..."
    new "Ein paar Tage bleiben ihr noch..."

    # say L145 gom
    old "This is so sad... We all will die..."
    new "Das ist so traurig... Wir werden alle sterben..."

    # say L146 dev
    old "All this is bullshit..."
    new "Das ist alles Quatsch..."

    # say L147 mil
    old "Girls! Wait a sec... We can still do something, we have [pla] on our side, he's gonna help us."
    new "Mädchen! Wartet mal... Wir können noch was tun, wir haben [pla] auf unserer Seite, der wird uns helfen."

    # say L148 gom
    old "But... But how? There is no more magic power around us... Tell me how?"
    new "Aber... Aber wie? Es gibt keine Magie mehr um uns herum... Sag mir, wie wir es machen können."

    # say L151 pla
    old "There has to be a way, just tell me what to do and I'll do it, we can't let her die."
    new "Da muss doch eine Möglichkeit sein, sag mir einfach was ich tun soll und ich mach es, wir können sie nicht sterben lassen."

    # say L153 mil
    old "[pla] just go and check how is her... Try to share some of your magic power with her."
    new "[pla] geh und schau, wie es ihr geht... Versuch, ihr etwas von deiner Magie zu geben."

    # say L155 pla
    old "Sure, I'll... I'm so sorry all this is happening but don't worry, I'll help..."
    new "Klar, ich werd's... Es tut mir so leid, dass das alles passiert, aber mach dir keine Sorgen, ich helfe..."

    # say L156 pla
    old " It's better if I go now... See you!"
    new "Es ist besser, wenn ich jetzt gehe... Bis dann!"

    # say L159 dev
    old "Good luck... And see you."
    new "Viel Glück... Und bis dann."

    # say L160 mil
    old "[pla] take care and don't forget we count on you."
    new "[pla] passen Sie auf sich auf und vergessen Sie nicht, dass wir auf Sie zählen."

    # say L161 pla
    old "I know... I'll do my best!"
    new "Ich weiß... Ich werde mein Bestes tun!"

    # say L181 mor
    old "Alright, we are going to start the exorcism."
    new "Also gut, wir werden jetzt mit dem Exorzismus beginnen."

    # say L188 mor
    old "Lord, please protect our church, protect us from these evil presences that surround us."
    new "Herr, bitte schütze unsere Kirche, schütze uns vor diesen bösen Präsenzen, die uns umgeben."

    # say L194 mor
    old "Our Father, who art in Heaven, hallowed be Thy name, Thy kingdom come..."
    new "Unser Vater im Himmel, geheiligt werde dein Name, dein Reich komme..."

    # say L195 mor
    old "Thy will be done, on earth as it is in Heaven. Give us this day our daily bread, and forgive us ou-"
    new "Dein Wille geschehe, auf Erden wie im Himmel. Unser täglich Brot gib uns heute und vergib uns un-"

    # say L197 pla
    old "(There she is... Is the shinigami... She'll die if I don't do something!)"
    new "Da ist sie... Die Shinigami... Sie wird sterben, wenn ich nichts tue!"

    # say L198 pla
    old "Huh,  w- what's happening? "
    new "Häh, w-was passiert hier?"

    # say L203 jon
    old "[pla]! Hi hun, is the ghost... The demon presence... It's taking over the church."
    new "[pla]! Hallo Schatz, das Gespenst... Die Dämonenpräsenz... Sie übernimmt die Kirche."

    # say L204 gra
    old "Hi [pla], Mrs. Jones is right, the situation is getting worse."
    new "Hallo [pla], Mrs. Jones hat recht, die Situation wird immer schlimmer."

    # say L207 pla
    old "What? Why do you think is a demon?"
    new "Was? Warum denkst du, es ist ein Dämon?"

    # say L208 gra
    old "Because it is! What else could it be if not a demon, a ghost!?"
    new "Weil es einer ist! Was sollte es sonst sein, wenn nicht ein Dämon, ein Geist!?"

    # say L209 jon
    old "It is hun... We know that, just look at the lights, everything is a mess here because of that."
    new "Es ist hun... Wir wissen das, man muss nur die Lichter sehen, alles ist hier durcheinander wegen dem."

    # say L210 pla
    old "(If I don't do something quickly, she will probably die.)"
    new "Wenn ich nichts schnell tue, wird sie wahrscheinlich sterben."

    # say L211 pla
    old "Ehmm... I'm sorry to contradict you but the presence we have right now in this church is not malignant at all, I'm sure of that."
    new "Ehm... Entschuldigung, aber die Präsenz, die wir hier in der Kirche spüren, ist überhaupt nicht bösartig, da bin ich mir sicher."

    # say L212 gra
    old "What? What are you saying? If you're so sure, prove it!"
    new "Was? Was sagen Sie da? Wenn Sie sich so sicher sind, beweisen Sie es!"

    # say L213 pla
    old "W- Well... I can do it! Take a look at the lights."
    new "W- Wohl... Ich kann es! Schau dir die Lichter an."

    # say L214 pla
    old "I'll tell the spirit to move to the right and the lights on that side will start to fade, if this happens you'll see that this spirit has good intentions."
    new "Ich sage dem Geist, dass er sich nach rechts bewegen soll, und die Lichter auf der Seite werden dann verblassen. Wenn das passiert, siehst du, dass dieser Geist gute Absichten hat."

    # say L215 gra
    old "Hmm, let's see."
    new "Hmm, lassen Sie uns mal sehen."

    # say L217 pla
    old "Spirit! Listen to me... We know we can help you as you can help us as well, please move to the right side and let us know by using the lights..."
    new "Geist! Hör mir zu... Wir wissen, dass wir dir helfen können und du uns auch, bitte bewege dich nach rechts und zeig es uns mit den Lichtern..."

    # say L224 gra
    old "My God! He did it! The lights were fading..."
    new "Mein Gott! Er hat es getan! Die Lichter verblassten..."

    # say L225 pla
    old "Spirit! Thanks! We saw it, you may now come back to your place."
    new "Spirit! Danke! Wir haben es gesehen, du kannst jetzt zu deinem Platz zurückkehren."

    # say L230 jon
    old "[pla]! You were right... But how, how did you know it!?"
    new "[pla]! Sie hatten recht... Aber wie, wie haben Sie das gewusst!?"

    # say L232 pla
    old "I simply knew it, I can feel the creature's energy and I know it's good... There is nothing bad within it."
    new "Ich habe es einfach gewusst, ich kann die Energie des Wesens spüren und weiß, dass es gut ist... Da ist nichts Böses in ihm."

    # say L233 jon
    old "I'm surprised..."
    new "Ich bin überrascht..."

    # say L234 mor
    old "Son, we see you're right, this spirit actually listens to you and does accordingly but what does it want? What can we do?"
    new "Sohn, wir sehen, dass du recht hast, dieser Geist hört tatsächlich auf dich und handelt danach, aber was will er? Was können wir tun?"

    # say L235 pla
    old "Well, I thin-"
    new "Nun, ich denke-"

    # say L246 bil
    old "What's the fuss about? Granma what's happening here?"
    new "Was ist denn los? Oma, was passiert hier?"

    # say L251 jon
    old "Hi darling! It's a ghost-"
    new "Hi Liebling! Es ist ein Geist-"

    # say L252 bil
    old "Oh really! Shut up, please! You're talking nonsense."
    new "Oh wirklich! Halt die Klappe, bitte! Du redest Unsinn."

    # say L253 gra
    old "It's true! There is an evil presence here..."
    new "Es stimmt! Hier ist eine böse Präsenz..."

    # say L255 bil
    old "Sister Grace I wasn't talking to you, please don't be rude... I can't deal with nosy people."
    new "Schwester Grace, ich hab nicht mit dir gesprochen, sei bitte nicht unhöflich... Ich kann es nicht ausstehen, wenn sich Leute einmischen."

    # say L283 jon
    old "What's happening Billie? BILLIE!?"
    new "Was ist los, Billie? BILLIE!?"

    # say L291 jon
    old "Nooo! Billie, wake up!! What's happening!? Someone help me, please!"
    new "Nooo! Billie, wach auf!! Was passiert hier!? Jemand hilf mir, bitte!"

    # say L292 gra
    old "Oh God, please help us."
    new "Oh Gott, bitte hilf uns."

    # say L293 mor
    old "Calm down everybody...!"
    new "Beruhigt euch alle...!"

    # say L295 mor
    old "I believe in God, the Father Almighty, Creator of Heaven and earth; and in Jesus Christ, His only Son, Our Lord..."
    new "Ich glaube an Gott, den allmächtigen Vater, Schöpfer des Himmels und der Erde; und an Jesus Christus, seinen einzigen Sohn, unseren Herrn..."

    # say L298 gra
    old "Father Morgan?"
    new "Vater Morgan?"

    # say L299 mor
    old "It's important to keep praying for Billie."
    new "Es ist wichtig, für Billie zu beten."

    # say L300 mor
    old "Let's pra-"
    new "Lass uns beten-"

    # say L301 gra
    old "Noo! Father Morgan, take her to the hospital with Mrs. Jones, I'll take care of the church..."
    new "Neein! Father Morgan, bringen Sie sie mit Mrs. Jones ins Krankenhaus, ich kümmere mich um die Kirche..."

    # say L303 jon
    old "Yes, let's go now... She has to be checked by a doctor."
    new "Ja, lass uns jetzt gehen... Sie muss von einem Arzt untersucht werden."

    # say L309 mor
    old "Sister Grace, please take care of the church, call me if anything... Ok?"
    new "Sister Grace, bitte kümmere dich um die Kirche, ruf mich an, wenn etwas ist... Ok?"

    # say L322 pla
    old "Wow that was... Weird..."
    new "Wow das war... seltsam..."

    # say L323 gra
    old "I hope Mrs. Jones's granddaughter is fine."
    new "Ich hoffe, Mrs. Jones' Enkelin geht es gut."

    # say L324 pla
    old "Yeah, me too."
    new "Ja, mir auch."

    # say L325 gra
    old "Wait a minute, the lights are not flashing! The ghost is gone!"
    new "Warten Sie, die Lichter blinken nicht mehr! Der Geist ist verschwunden!"

    # say L326 pla
    old "W- what? (Oh shit, what happened with the shinigami?)"
    new "W-was? (Oh Scheiße, was ist mit dem Shinigami passiert?)"

    # say L327 pla
    old "You are right... I can't see anything either"
    new "Du hast recht... Ich sehe auch nichts mehr."

    # say L328 pla
    old "(Oh no... It means she... d- died.)"
    new "Oh nein... Das bedeutet, sie... s- starb."

    # say L329 gra
    old "And it was because of you! Thank you for your help."
    new "Und das war wegen Ihnen! Danke für Ihre Hilfe."

    # say L330 pla
    old "Yeah... It was because of me... (It was my fault...)"
    new "Ja... Es war meine Schuld..."

    # say L331 gra
    old "I'm really impressed, don't know which kind of spiritual connection you have."
    new "Ich bin echt beeindruckt, keine Ahnung, welche Art von spiritueller Verbindung Sie haben."

    # say L332 gra
    old "It was as if you were communicating with something higher... Something that we cannot see, something beyond our comprehension, perhaps divine."
    new "Es war, als würden Sie mit etwas Höherem kommunizieren... Etwas, das wir nicht sehen können, etwas jenseits unserer Vorstellungskraft, vielleicht göttlich."

    # say L333 pla
    old "Hmm yeah... Something like that"
    new "Hmm ja... So ähnlich"

    # say L334 pla
    old "(Argh! I didn't save her... I'm completely useless...) "
    new "Argh! Ich hab sie nicht gerettet... Ich bin vollkommen nutzlos..."

    # say L335 gra
    old "You're definitely closer to the divine spirit than even Father Morgan..."
    new "Sie sind definitiv näher am göttlichen Geist als sogar Father Morgan..."

    # say L336 pla
    old "I better go home, goodbye Sister Grace."
    new "Ich geh besser nach Hause, tschüss Schwester Grace."

    # say L343 gra
    old "Wait [pla]!..."
    new "Warten [pla]!"

    # say L364 mo1
    old "Good morning darling, someone is looking for you..."
    new "Guten Morgen Liebling, jemand sucht dich..."

    # say L365 pla
    old "Looking for me?... Who's that?"
    new "Wen suchst du?... Wer ist das?"

    # say L366 mo1
    old "Two women... An old lady and a nun, where do you know them from?"
    new "Zwei Frauen... Eine alte Dame und eine Nonne, woher kennst du sie?"

    # say L367 pla
    old "Ahh ok! Hmm... They're from the church, you know I have been there quite a few times..."
    new "Ahh ok! Hmm... Sie kommen aus der Kirche, du weißt ja, ich war da schon ziemlich oft..."

    # say L368 mo1
    old "I see... Well, they're waiting, go to see what they need, honey."
    new "Ich sehe... Na ja, sie warten, geh mal sehen, was sie brauchen, Schatz."

    # say L369 pla
    old "Sure! Thanks [mo1]."
    new "Klar! Danke [mo1]."

    # say L376 jon
    old "Hi dear, I'm so sorry to bother you but you're the only one who can help us..."
    new "Hallo Liebste, es tut mir so leid, Sie zu stören, aber Sie sind die Einzige, die uns helfen kann..."

    # say L377 pla
    old "Hi Mrs. Jones... Hmm, me? Why? What happened?"
    new "Hallo Mrs. Jones... Hmm, ich? Warum? Was ist passiert?"

    # say L378 gra
    old "Hi [pla], well... As I told you in the church, you were a great help and we think you could do something for Billie."
    new "Hallo [pla], na ja... Wie ich Ihnen in der Kirche schon sagte, waren Sie eine große Hilfe und wir denken, Sie könnten etwas für Billie tun."

    # say L381 jon
    old "I'm so worried for my granddaughter, I'm afraid I'll lose her... Please help me!"
    new "Ich mache mir solche Sorgen um meine Enkelin, ich habe Angst, sie zu verlieren... Bitte helfen Sie mir!"

    # say L382 pla
    old "I'm so sorry to hear she's not ok... But I don't know how could I help... I'm not a doctor."
    new "Es tut mir leid zu hören, dass es ihr nicht gut geht... Aber ich weiß nicht, wie ich helfen könnte... Ich bin kein Arzt."

    # say L383 gra
    old "Well, we think this case is more related on a spiritual level, and you showed divine talents, so we hope that you could help us."
    new "Nun, wir denken, dass dieser Fall eher auf einer spirituellen Ebene liegt, und da Sie göttliche Talente gezeigt haben, hoffen wir, dass Sie uns helfen können."

    # say L384 pla
    old "And what about the Father Morgan?"
    new "Und was ist mit Father Morgan?"

    # say L385 jon
    old "He already tried but didn't work and well... You're our only hope."
    new "Er hat es schon versucht, aber es hat nicht funktioniert und na ja... Sie sind unsere letzte Hoffnung."

    # say L386 pla
    old "Alright, I'll try to help, but I'm not sure if I can-"
    new "Okay, ich werde es versuchen, aber ich bin mir nicht sicher, ob ich kann-"

    # say L387 gra
    old "Thank you! We knew we can count on you."
    new "Danke! Wir wussten, dass wir uns auf Sie verlassen können."

    # say L388 jon
    old "Come with us, we have no time to lose. "
    new "Kommen Sie mit uns, wir haben keine Zeit zu verlieren."

    # say L401 jon
    old "[pla] look at her... She's suffering, please do something!"
    new "[pla] schauen Sie sich an... Sie leidet, bitte tun Sie etwas!"

    # say L402 pla
    old "Hmm let's see..."
    new "Hmm, lass uns mal sehen..."

    # say L407 pla
    old "(What? The shinigami isn't dead? What's happening here!)"
    new "Was? Die Shinigami ist nicht tot? Was passiert hier!"

    # say L410 jon
    old "Oh my God! She is crying black tears..."
    new "Oh mein Gott! Sie weint schwarze Tränen..."

    # say L412 gra
    old "Is there any way to help her [pla]?"
    new "Gibt es irgendeine Möglichkeit, ihr zu helfen [pla]?"

    # say L413 pla
    old "(What the fuck is this?)"
    new "Was zur Hölle ist das?"

    # say L414 gra
    old "[pla], are you fine? Are you in shock?"
    new "[pla], geht es Ihnen gut? Sind Sie schockiert?"

    # say L416 pla
    old "(I don't understand what's happening here. I have to talk with the shinigamis.)"
    new "Ich verstehe nicht, was hier los ist. Ich muss mit den Shinigamis reden."

    # say L417 pla
    old "Hmm... W- Well..."
    new "Hmm... W- Warte mal..."

    # say L418 pla
    old "Hmm... I'll need to see her at night, right now I can't do anything but I'll come back later."
    new "Hmm... Ich werde sie nachts sehen müssen, im Moment kann ich nichts tun, aber ich komme später wieder."

    # say L419 pla
    old "I need to... Prepare myself, if we do everything in the proper way, Billie will be fine soon."
    new "Ich muss mich vorbereiten, wenn wir alles richtig machen, wird es Billie bald gut gehen."

    # say L420 jon
    old "I have no words to thank you for everything you have done for us, her life is on your hands [pla]."
    new "Ich habe keine Worte, um Ihnen für alles zu danken, was Sie für uns getan haben, ihr Leben liegt in Ihren Händen [pla]."

    # say L421 pla
    old "(My God! I really gotta do something for her and the shinigami.)"
    new "Mein Gott! Ich muss wirklich was für sie und den Shinigami tun."

    # say L422 pla
    old "Don't worry Mrs. Jones, she'll be fine. I better go now but I'll see you later."
    new "Keine Sorge, Mrs. Jones, es wird ihr gut gehen. Ich muss jetzt los, aber wir sehen uns später."

    # say L423 pla
    old "See you later as well Sister Grace."
    new "Bis später auch, Schwester Grace."

    # say L425 gra
    old "Thanks! We'll be waiting for you."
    new "Danke! Wir werden auf Sie warten."

    # say L426 jon
    old "Take care hun and thanks again."
    new "Passen Sie auf sich auf und danke nochmal."

    # say L449 pla
    old "I saw the shinigami! Apparently she's inside Billie's body. I saw her!"
    new "Ich hab die Shinigami gesehen! Anscheinend steckt sie in Billies Körper. Ich hab sie gesehen!"

    # say L467 mil
    old "I'm surprised with your manners... Hi [pla]!"
    new "Ich bin überrascht von Ihren Manieren... Hallo [pla]!"

    # say L468 pla
    old "Hi hi! I know but this is important, I didn't expect to see her there..."
    new "Hi hi! Ich weiß, aber das ist wichtig, ich hab sie da nicht erwartet..."

    # say L469 mil
    old "Wait a sec! Who's Billie? What are you talking about?"
    new "Warte mal! Wer ist Billie? Wovon redest du?"

    # say L470 pla
    old "Alright! Billie is a girl from the church and it seems the shinigami is inside of her, I have no idea how,.. You tell me!"
    new "Okay! Billie ist ein Mädchen von der Kirche und es scheint, dass der Shinigami in ihr steckt, ich habe keine Ahnung, wie das passiert ist,... Erklär du es mir!"

    # say L472 mil
    old "[pla], this is actually delicate, that shinigami is trapped in Billie's body, that happens when there is a lack of energy in the shinigami's body..."
    new "[pla], das ist tatsächlich heikel, der Shinigami ist in Billies Körper gefangen, das passiert, wenn der Shinigami an Energiemangel leidet..."

    # say L475 mil
    old "That shinigami is having serious problems and getting into a human's body was the only option she had..."
    new "Das Shinigami hat ernsthafte Probleme und in den Körper eines Menschen zu kommen war ihre einzige Option..."

    # say L476 gom
    old "She's struggling right now and the only way to get out of Billie's body is through an energy transfer since the body where she's now doesn't have any energy."
    new "Sie kämpft gerade und der einzige Weg, aus Billies Körper rauszukommen, ist durch eine Energieübertragung, da der Körper, in dem sie jetzt steckt, keine Energie hat."

    # say L477 pla
    old "What? I thought she did possess her body... This makes more sense, that's why she's still there."
    new "Was? Ich dachte, sie hat ihren Körper besessen... Das ergibt mehr Sinn, deshalb ist sie noch da."

    # say L478 mil
    old "Yes, she can't get out by herself. Billie's body doesn't have enough energy and as I'm telling you.. The only way to help them is through a powerful load of energy."
    new "Ja, sie kann nicht von selbst rauskommen. Billies Körper hat nicht genug Energie und wie ich dir sage... Die einzige Möglichkeit, ihnen zu helfen, ist durch eine starke Energieladung."

    # say L479 gom
    old "Are you willing to do that for them?"
    new "Bist du bereit, das für sie zu tun?"

    # say L481 pla
    old "Yes, of course... I don't want anybody to die. How can I perform that energy transfer?"
    new "Ja, klar... Ich will nicht, dass jemand stirbt. Wie kann ich diese Energieübertragung durchführen?"

    # say L483 dev
    old "Come on! You already know how..."
    new "Komm schon! Das weißt du doch längst..."

    # say L484 pla
    old "Well, the only way to get energy I know is through s- sex-... A- are you saying that I have to have sex with Billie?"
    new "Na ja, der einzige Weg, um Energie zu bekommen, den ich kenne, ist durch s- Sex... S- soll das heißen, dass ich mit Billie schlafen muss?"

    # say L485 mil
    old "You just said it... Yeah, it's the only way. Once the shinigami gets your energy, she'll be able to get out of Billie's body. There is no other way."
    new "Du hast es gerade selbst gesagt... Ja, es ist der einzige Weg. Sobald die Shinigami deine Energie bekommt, kann sie Bills Körper verlassen. Es gibt keine andere Möglichkeit."

    # say L486 mil
    old "You're a young, strong and virile man. You're the only one able to help her."
    new "Du bist jung, stark und voller Vitalität. Du bist der Einzige, der ihr helfen kann."

    # say L487 pla
    old "I get it, I'll do whatever it takes to help her."
    new "Ich kapiere, ich werde alles tun, was nötig ist, um ihr zu helfen."

    # say L488 mil
    old "Get ready for it! You'll have to last much longer since it will not be easy but we know you can do it."
    new "Bereite dich darauf vor! Du musst viel länger durchhalten, denn es wird nicht einfach, aber wir wissen, dass du es kannst."

    # say L490 pla
    old "I'll do my best for her to come and come out... See you girls."
    new "Ich werde mein Bestes tun, damit sie kommt und rauskommt... Bis dann, Mädels."

    # say L492 mil
    old "See you [pla], we're counting on you."
    new "Bis später [pla], wir zählen auf dich."

    # say L494 gom
    old "Please take care, [pla]"
    new "Passen Sie auf, [pla]"

    # say L514 pla
    old "Hello Mrs. Jones, Sister Grace..."
    new "Hallo Mrs. Jones, Schwester Grace..."

    # say L515 jon
    old "Hi dear, we're so glad you're here... Let's start now. Tell us how to help you."
    new "Hallo liebe, wir freuen uns so, dass Sie hier sind... Lassen Sie uns gleich beginnen. Erzählen Sie uns, wie wir Ihnen helfen können."

    # say L516 gra
    old "Dear [pla], we are at your service, just tell us how we help you."
    new "Liebe [pla], wir sind Ihnen zu Diensten, sagen Sie uns einfach, wie wir Ihnen helfen können."

    # say L517 jon
    old "We trust you and the gifts that the Lord has given you, please help my Billie."
    new "Wir vertrauen Ihnen und den Gaben, die der Herr Ihnen gegeben hat, bitte helfen Sie meinem Billie."

    # say L518 pla
    old "(They can't be here... I gotta say something for them to go out...)"
    new "Ich muss was sagen, damit sie rausgehen..."

    # say L519 jon
    old "Tell us! Tell us hun!"
    new "Erzählen Sie uns! Erzählen Sie uns, Liebes!"

    # say L523 jon
    old "Are you ok? What's happening? Why don't we start now?"
    new "Geht es Ihnen gut? Was passiert hier? Warum fangen wir nicht jetzt an?"

    # say L524 pla
    old "Yes, n- no. I- I mean, I'll start now but you can't be here, this is an important ritual that I must do alone."
    new "Ja, n-nein. Ich meine, ich fange jetzt an, aber ihr dürft nicht hier sein. Das ist ein wichtiges Ritual, das ich allein durchführen muss."

    # say L525 gra
    old "Alone? Why? We could assist you with our presence and prayers."
    new "Alone? Warum? Wir könnten Ihnen mit unserer Anwesenheit und Gebeten helfen."

    # say L526 pla
    old "Hmm... Because, it's how it should be, could be dangerous for you."
    new "Hmm... Weil es so vorgeschrieben ist, könnte für dich gefährlich sein."

    # say L527 pla
    old "I don't think you're prepared to see what I'll do..."
    new "Ich glaube nicht, dass du bereit bist, das zu sehen, was ich tun werde..."

    # say L528 pla
    old "Billie? Billie, do you hear me?"
    new "Billie? Billie, hörst du mich?"

    # say L530 lin
    old "Gulp... is tha-?"
    new "Gulp... ist da-?"

    # say L531 jon
    old "My Godness! Billie spoke! Let's get out of here. He knows what he's doing."
    new "Mein Gott! Billie hat gesprochen! Lassen Sie uns hier rausgehen. Er weiß, was er tut."

    # say L532 pla
    old "Please leave me alone with her, we can't waste more time."
    new "Lass mich allein mit ihr, wir können keine Zeit mehr verschwenden."

    # say L533 lin
    old "I- I n- need h- help."
    new "I- I b- brauche H- Hilfe."

    # say L534 gra
    old "Call us if you need anything, [pla]."
    new "Rufen Sie uns an, wenn Sie etwas brauchen, [pla]."

    # say L548 pla
    old "Alright, how I'm gonna do this?"
    new "Okay, wie mache ich das jetzt?"

    # say L551 lin
    old "Y- You're here! P- please help me to get out of her, I- I'm trapped."
    new "Y- Du bist hier! P- Bitte hilf mir rauszukommen, ich bin eingesperrt."

    # say L552 pla
    old "I know... You know the only way is through an energy transfer process, right?"
    new "Ich weiß... Du weißt doch, dass der einzige Weg durch einen Energieübertragungsprozess geht, oder?"

    # say L553 lin
    old "Y- Yes, please hurry up! I- I'll die if we don't do it."
    new "Y- Ja, bitte beeil dich! I- Ich sterbe, wenn wir es nicht tun."

    # say L554 pla
    old "We'll need to have s- sex, well... You know it's how it's called."
    new "Wir müssen s- Sex haben, also... Du weißt schon, so nennt man das."

    # say L556 lin
    old "Shoot! C- Can you simply do it!? I already know what you're saying. I need you to do it now!"
    new "Schieß los! K- Kannst du es einfach tun!? Ich weiß schon, was du sagst. Ich brauche dich jetzt!"

    # say L557 pla
    old "No! No, I was just saying..."
    new "Nein! Nein, ich hab's doch nur gesagt..."

    # say L558 pla
    old "But I shouldn't have sex with this girl, I don't even know her."
    new "Aber ich sollte nicht mit diesem Mädchen schlafen, ich kenne sie doch gar nicht."

    # say L564 lin
    old "W- what you are going to do is share a magical power with me the shinigami... Don't overthink it. "
    new "W- was du tun wirst, ist eine magische Kraft mit mir, der Shinigami, teilen... Mach dir keine Gedanken drum."

    # say L565 lin
    old "I need you to free me now... Do it..."
    new "Ich brauche, dass du mich jetzt befreist... Tu es..."

    # say L595 jon
    old "My God! What's going on here? What did you do to Billie?"
    new "Mein Gott! Was geht hier vor? Was haben Sie Billie angetan?"

    # say L597 pla
    old "(Oh no! Now what?!)"
    new "Oh nein! Was jetzt?!"

    # say L599 jon
    old "[pla]? Is this part of the ritual you had planned to perform? I don't understand..."
    new "[pla]? Ist das Teil des Rituals, das Sie durchführen wollten? Ich verstehe das nicht..."

    # say L600 pla
    old "(Damn it! What should I say?)"
    new "Verdammt! Was soll ich sagen?"

    # say L605 bil
    old "Grandma? Sister Grace? Where am I?... What happened?"
    new "Oma? Schwester Grace? Wo bin ich?... Was ist passiert?"

    # say L606 bil
    old "Someone tell me what happened to me? Why am I naked and sweating?"
    new "Kann mir jemand sagen, was mit mir passiert ist? Warum bin ich nackt und schwitze?"

    # say L607 gra
    old "Well! She looks much better now..."
    new "Na! Sie sieht jetzt viel besser aus..."

    # say L610 jon
    old "My God, thanks! She's back!"
    new "Mein Gott, danke! Sie ist zurück!"

    # say L611 bil
    old "Huhh, what is going on?"
    new "Huhh, was ist hier los?"

    # say L612 gra
    old "We know you must be feeling so confused about everything..."
    new "Wir wissen, dass du total verwirrt sein musst, Jane..."

    # say L613 gra
    old "Your body was possessed by a spirit, but [pla] helped us perform a ritual and now you're back, you're fine now... "
    new "Dein Körper wurde von einem Geist besessen, aber [pla] hat uns geholfen, einen Ritual durchzuführen und jetzt bist du wieder da, es geht dir gut..."

    # say L614 bil
    old "What? My body... Possessed? What the fuck?"
    new "Was? Mein Körper... Besessen? Was zum Teufel?"

    # say L615 gra
    old "Yes, it happened while we all were at the church, we don't know why but what matters now is that you're fine."
    new "Ja, es passierte, während wir alle in der Kirche waren, wir wissen nicht warum, aber wichtig ist jetzt, dass es dir gut geht."

    # say L618 gra
    old "I guess that what [pla] did was part of the ritual..."
    new "Ich denke, das, was [pla] getan hat, war Teil des Rituals..."

    # say L620 pla
    old "It was part of the ritual... It was the only way to help her out."
    new "Es war Teil des Rituals... Es war der einzige Weg, ihr zu helfen."

    # say L621 gra
    old "She seems to be totally fine now, I don't feel the spirit's presence anymore."
    new "Sie scheint jetzt völlig in Ordnung zu sein, ich spüre die Präsenz des Geistes nicht mehr."

    # say L622 pla
    old "She's fine now, I've cleaned her body from the spirit's presence... Now she's fine and healthy."
    new "Sie ist jetzt in Ordnung, ich habe ihren Körper von der Präsenz des Geistes gereinigt... Jetzt ist sie gesund und munter."

    # say L624 jon
    old "Don't worry my love, you're fine now. You just need to rest..."
    new "Keine Sorge, meine Liebe, Sie sind jetzt in Ordnung. Sie müssen sich nur ausruhen..."

    # say L627 bil
    old "Huhh could you please let me go? I'm not breathing..."
    new "Huhh könnten Sie mich bitte loslassen? Ich kann nicht atmen..."

    # say L633 gra
    old "Ohh, sorry... It's just that we're so happy you're fine..."
    new "Ohh, entschuldige... Es ist nur, wir sind so froh, dass es dir gut geht..."

    # say L634 gra
    old "Thanks [pla], you have been such a great help."
    new "Danke [pla], Sie haben uns wirklich sehr geholfen."

    # say L637 jon
    old "Yeah, thanks hun, I'm so grateful with you, you're a saint. Definitely God is inside of you..."
    new "Ja, danke Schatz, ich bin dir so dankbar, du bist ein Engel. Bestimmt ist Gott in dir..."

    # say L638 pla
    old "Don't worry, I just did what... God told me to do... I'll be here to help."
    new "Mach dir keine Sorgen, ich habe nur getan, was... Gott mir gesagt hat... Ich werde hier sein, um zu helfen."

    # say L639 pla
    old "I should be going now... It's been a very demanding ritual and I need to get some rest."
    new "Ich sollte jetzt gehen... Es war ein sehr anstrengendes Ritual und ich brauche etwas Ruhe."

    # say L641 jon
    old "Sure hun! Take care and thanks again!"
    new "Natürlich, passen Sie auf sich auf und vielen Dank nochmal!"

    # say L642 pla
    old "Mmm... Thanks, see you Mrs. Jones... Bye Sister Grace."
    new "Mmm... Danke, bis bald Mrs. Jones... Tschüss Schwester Grace."

    # say L643 gra
    old "Bye dear [pla]"
    new "Tschüss Liebes [pla]"

    # say L655 bil
    old "What was that naked guy doing here?"
    new "Was hat der nackte Mann hier gemacht?"

    # say L672 pla
    old "How are you feeling? Are you ok?"
    new "Wie fühlst du dich? Alles okay?"

    # say L674 pla
    old "You know what... There are more shinigamis like you, we can help you."
    new "Du weißt ja... Es gibt noch mehr Shinigami wie dich, wir können dir helfen."

    # say L675 lin
    old "Who are you? Why are you helping me?"
    new "Wer bist du? Warum hilfst du mir?"

    # say L676 pla
    old "Oh yes, sorry! I'm [pla], as I just told you... I know others like you."
    new "Oh ja, entschuldige! Ich bin [pla], wie ich dir gerade gesagt habe... Ich kenne andere wie dich."

    # say L677 lin
    old "I see... Nice to meet you [pla], I'm Linett and well..."
    new "Ich sehe... Schön, dich kennenzulernen [pla], ich bin Linett und na ja..."

    # say L678 lin
    old "I feel better now but still weak, I don't have enough energy yet."
    new "Ich fühle mich jetzt besser, aber immer noch schwach, ich habe noch nicht genug Energie."

    # say L680 pla
    old "Do you think we should continue with the energy transfer?"
    new "Meinst du, wir sollten mit der Energieübertragung weitermachen?"

    # say L682 lin
    old "Hmm, we definitely have to continue the energy transfer, everything you shared with me was just to get out of that girl's body."
    new "Hmm, wir müssen definitiv mit der Energietransfer fortsetzen, alles, was du mir gegeben hast, war nur, um aus dem Körper dieses Mädchens rauszukommen."

    # say L683 pla
    old "Hmm ok, no problem, let's do it."
    new "Hmm okay, kein Problem, machen wir."

    # say L684 lin
    old "Great! It's better if I suck you cock first, that will give me initial energy so that later you continue with the whole transfer."
    new "Super! Es ist besser, wenn ich zuerst deinen Schwanz lutsche, das gibt mir die anfängliche Energie, damit du später mit dem ganzen Transfer weitermachen kannst."

    # say L685 lin
    old "Are you fine with that?"
    new "Bist du damit einverstanden?"

    # say L686 pla
    old "Yeah, I already told you I'm here to help and if I have to do that... I won't let you down."
    new "Klar, ich hab dir doch schon gesagt, dass ich hier bin, um zu helfen und wenn ich das machen muss... ich lass dich nicht im Stich."

    # say L690 lin
    old "That's the attitude we need... One more thing, could you please turn on the lights, I prefer to watch what I'm doing..."
    new "Das ist die Einstellung, die wir brauchen... Noch was, könntest du bitte das Licht anmachen? Ich mag es, zu sehen, was ich mache..."

    # say L691 pla
    old "Ehmm... Sure."
    new "Ehmm... Klar."

    # say L704 pla
    old "So how are you now?"
    new "Und wie geht's dir jetzt?"

    # say L705 lin
    old "Totally fine... You really did excellent!"
    new "Total okay... Du hast echt super gemacht!"

    # say L706 pla
    old "I'm glad you're fine now but... Are you gonna tell me what were you doing at the church? What was happening there?"
    new "Ich bin froh, dass es dir gut geht, aber... Wirst du mir sagen, was du in der Kirche gemacht hast? Was ist dort passiert?"

    # say L707 lin
    old "Yes, sure! Well... Hmm."
    new "Ja, klar! Also... Hmm."

    # say L708 lin
    old "I was trying to do a small ritual to achieve a reception of energy, for this it was required to deliver a lot of energy and I thought that with me it would have been enough, but it wasn't."
    new "Ich habe versucht, ein kleines Ritual durchzuführen, um Energie aufzunehmen. Dafür war eine Menge Energie nötig und ich dachte, dass es mit mir reichen würde, aber das war nicht der Fall."

    # say L710 lin
    old "I tried to condense the magic power but since I didn't have enough energy, I got weak and got trapped in the church and later, in Billie's body."
    new "Ich habe versucht, die magische Energie zu verdichten, aber da ich nicht genug Kraft hatte, wurde ich schwach und gefangen in der Kirche und später in Billies Körper."

    # say L711 lin
    old "We have to restore the power generator through a magic ritual and we only have one chance."
    new "Wir müssen den Kraftgenerator durch ein magisches Ritual wiederherstellen und wir haben nur eine Chance."

    # say L712 pla
    old "So we gotta find the way to do it, tell me what to do and I'll do it... Now it's my responsibility as well."
    new "Dann müssen wir den Weg finden, sag mir was ich tun soll und ich mach es... Jetzt ist es auch meine Verantwortung."

    # say L714 lin
    old "Are you sure? Are you sure you wanna help? You'll have to do lots of things."
    new "Bist du dir sicher? Bist du dir sicher, dass du helfen willst? Du musst viele Dinge tun."

    # say L715 pla
    old "Well, I've done some already and I'm willing to do more."
    new "Na ja, ich hab schon einiges getan und bin bereit, noch mehr zu tun."

    # say L716 lin
    old "Ok... Well, the church is a special point and has an unique vibration that allows us to collect more energy."
    new "Okay... Also, die Kirche ist ein besonderer Ort und hat eine einzigartige Vibration, die es uns ermöglicht, mehr Energie zu sammeln."

    # say L717 lin
    old "[pla], you gotta have sex with humans, so you will collect more energy and it should be done soon... We don't have much time."
    new "[pla], du musst mit Menschen schlafen, damit du mehr Energie sammeln kannst und das sollte bald geschehen... Wir haben nicht viel Zeit."

    # say L718 pla
    old "What? Why do I need to have sex with humans? I mean, I get that it's the way to transfer energy but... Why not with the shinigamis?"
    new "Was? Warum muss ich mit Menschen schlafen? Ich meine, ich verstehe, dass es der Weg ist, Energie zu übertragen, aber... Warum nicht mit den Shinigamis?"

    # say L719 lin
    old "It's dangerous, the shinigamis could get trapped... And you already know it's not easy to get out of a human's body. It's too risky at this point."
    new "Es ist gefährlich, die Shinigami könnten gefangen werden... Und du weißt ja, es ist nicht einfach, aus einem menschlichen Körper rauszukommen. Das ist zu riskant im Moment."

    # say L720 lin
    old "And on the other hand, we need people with a great concentration of power. You gotta look for at least two people who have this. Otherwise..."
    new "Und auf der anderen Seite brauchen wir Menschen mit einer großen Konzentration an Macht. Du musst mindestens zwei finden, die das haben. Sonst..."

    # say L721 lin
    old "It won't work..."
    new "Dann wird es nicht funktionieren..."

    # say L722 pla
    old "Hmm... Ok, I get it..."
    new "Hmm... Ok, ich verstehe..."

    # say L723 pla
    old "(Actually I could try it with... The nun and Mrs. Jones would be perfect for that.)"
    new "Eigentlich könnte ich es mit... Die Nonne und Mrs. Jones wären dafür perfekt."

    # say L724 lin
    old "Are you already thinking on someone?"
    new "Denkst du schon an jemanden?"

    # say L726 pla
    old "Yeah, I do know two women... But It won't be easy... Sister Grace and Mrs. Jones, are part of the church's community and they liked me."
    new "Ja, ich kenne zwei Frauen... Aber es wird nicht einfach... Sister Grace und Mrs. Jones sind Teil der Gemeinde und sie mochten mich."

    # say L727 pla
    old "I'm not sure but I could definitely try..."
    new "Ich bin mir nicht sicher, aber ich könnte es definitiv versuchen..."

    # say L729 lin
    old "That's great! Do it... We have to try because it's our last chance, otherwise we'll have to wait until next year."
    new "Das ist toll! Mach es... Wir müssen es versuchen, weil es unsere letzte Chance ist, sonst müssen wir bis nächstes Jahr warten."

    # say L730 lin
    old "The energy that will emerge in the church will only increase in this period of the year, that's why it's so important."
    new "Die Energie, die in der Kirche entstehen wird, steigert sich in diesem Zeitraum des Jahres, deshalb ist es so wichtig."

    # say L732 lin
    old "Now you know what we've to do... I'll get some rest and you should as well, you'll be very busy the next few days."
    new "Jetzt weißt du, was wir tun müssen... Ich werde mich ausruhen und du solltest das auch tun, du wirst die nächsten Tage sehr beschäftigt sein."

    # say L733 pla
    old "I can imagine... Ahh... I forgot to tell you, nice to meet you."
    new "Ich kann mir vorstellen... Ahh... Ich hab vergessen, mich vorzustellen, nett dich kennenzulernen."

    # say L734 lin
    old "After all we've done you say that... Haha, good night [pla]"
    new "Nach allem, was wir gemacht haben, sagst du das... Haha, gute Nacht [pla]"

    # say L735 pla
    old "Good night, Linett."
    new "Gute Nacht, Linett."

    # menu L759 
    old "Ritual"
    new "Rituale"

    # say L761 lin
    old "[pla] how's it going? Are you ready for the ritual?"
    new "[pla] wie läuft's? Bist du bereit für das Ritual?"

    # say L762 pla
    old "I'm... I'm still preparing myself for it..."
    new "Ich bin... Ich bereite mich noch darauf vor..."

    # say L763 lin
    old "Great! If you need anything, just let me know..."
    new "Super! Wenn du was brauchst, sag Bescheid..."

    # say L764 pla
    old "Thanks, I'll... Now I should go..."
    new "Danke, ich werd's... Jetzt sollte ich gehen..."

    # say L765 lin
    old "Alright, see you!"
    new "Okay, bis dann!"

    # menu L767 
    old "Share your magic power"
    new "Deine magische Kraft teilen"

    # say L769 lin
    old "Hey [pla], how are you?"
    new "Hey [pla], wie geht's dir?"

    # say L770 pla
    old "I'm totally fine, I was wondering if you need me to share some magic power with you?"
    new "Ich bin total fit, ich hab mich gefragt, ob du vielleicht meine magische Kraft gebrauchen kannst?"

    # say L771 lin
    old "You're such a kind man! Yes, I need some power... Please give it to me!"
    new "Du bist so ein guter Mann! Ja, ich brauche etwas Kraft... Gib sie mir bitte!"

    # menu L780 
    old "Ask for magic power"
    new "Magie teilen anfragen"

    # say L782 pla
    old "Hey, how are you?"
    new "Hey, wie geht's dir?"

    # say L783 lin
    old "Hey [pla], I'm fine... What can I do for you?"
    new "Hey [pla], mir geht's gut... Was kann ich für dich tun?"

    # say L784 pla
    old "I need some magic power... Could you please share some with me?"
    new "Ich brauche ein bisschen magische Kraft... Könntest du mir etwas davon geben?"

    # say L785 lin
    old "I can always share my power with you..."
    new "Ich kann dir immer meine Kraft geben..."

    # say L806 lin
    old "It was good as usual, I'm feeling much more energetic now."
    new "Es war wie immer gut, ich fühle mich jetzt viel energiegeladener."

    # say L807 pla
    old "I'm glad I can always help!"
    new "Ich freue mich, dass ich immer helfen kann!"

    # say L809 lin
    old "See you [pla]"
    new "Bis dann [pla]"

    # say L820 pla
    old "Thanks Linett, that was very energizing!"
    new "Danke Linett, das war sehr aufmunternd!"

    # say L821 lin
    old "It was... I'm here whenever you need me"
    new "Es war... Ich bin immer für dich da, wenn du mich brauchst."

    # say L822 pla
    old "Great! See you!"
    new "Super! Bis dann!"

    # say L836 lin
    old "Hey [pla]! Long time no see. How are you?"
    new "Hey [pla]! Lange nicht gesehen. Wie geht’s dir?"

    # say L837 pla
    old "Woah! Linett! You scared me!"
    new "Woah! Linett! Du hast mich erschreckt!"

    # say L838 pla
    old "What are you doing here?"
    new "Was machst du hier?"

    # say L839 lin
    old "I have to talk with you. It's important."
    new "Ich muss mit dir reden. Es ist wichtig."

    # say L840 lin
    old "So, I was waiting here for you to wake up."
    new "Dann habe ich also auf dich gewartet, bis du wach wirst."

    # say L842 pla
    old "Yeah well. That's a bit weird."
    new "Ja klar. Das ist schon ein bisschen seltsam."

    # say L843 pla
    old "But anyway, what did you wanna tell me?"
    new "Aber egal, was wolltest du mir sagen?"

    # say L845 lin
    old "It's about the ritual we did in the church, do you remember?"
    new "Es geht um das Ritual, das wir in der Kirche gemacht haben, erinnerst du dich?"

    # say L846 pla
    old "Yeah I do, what about it?"
    new "Klar, was ist damit?"

    # say L847 lin
    old "Well, it's been a while since we tried it, and I think we should give it another go."
    new "Na ja, es ist schon eine Weile her, dass wir es versucht haben, und ich denke, wir sollten es noch mal probieren."

    # say L848 lin
    old "After all, we still need those portals to generate magic again. And we're nearing the time of year to do it."
    new "Immerhin müssen wir die Portale wieder zum Erzeugen von Magie benutzen. Und wir nähern uns der Jahreszeit dafür."

    # say L850 pla
    old "But it didn't work last time, right?"
    new "Aber es hat letztes Mal nicht funktioniert, oder?"

    # say L851 lin
    old "It didn't."
    new "Es hat nicht."

    # say L852 lin
    old "And to be honest. I don't really know why..."
    new "Und ehrlich gesagt. Ich hab echt keine Ahnung, warum..."

    # say L853 lin
    old "I've been thinking about it, but I can't come up with a full explanation."
    new "Ich hab drüber nachgedacht, aber ich komm einfach nicht drauf, warum."

    # say L855 pla
    old "And you still want to try again? I mean... If we don't know what went wrong last time."
    new "Und du willst es trotzdem noch mal versuchen? Ich meine... Wenn wir nicht wissen, was letztes Mal schiefgelaufen ist."

    # say L856 pla
    old "How do we know this time it's going to work?"
    new "Wie wissen wir, dass es dieses Mal klappt?"

    # say L858 lin
    old "About that, I said I didn't know but I do have some ideas as to what could make it work this time."
    new "Dazu hab ich gesagt, dass ich es nicht weiß, aber ich habe ein paar Ideen, was wir anders machen könnten, damit es dieses Mal klappt."

    # say L859 lin
    old "An important part of what went wrong, is that we couldn't direct the magic power the way we needed it to go."
    new "Ein wichtiger Teil davon, was schiefgelaufen ist, war, dass wir die magische Energie nicht so lenken konnten, wie es nötig war."

    # say L861 pla
    old "Direct? What do you mean?"
    new "Direktion? Was meinst du damit?"

    # say L862 lin
    old "Well, as you can see when you use the agamoto's eye."
    new "Na ja, wie du sehen kannst, wenn du das Auge des Agamotos benutzt."

    # say L863 lin
    old "Magic power is, in essence, a series of particles that human bodies are able to absorb."
    new "Magische Energie ist im Grunde eine Reihe von Partikeln, die menschliche Körper aufnehmen können."

    # say L864 lin
    old "However, human bodies are not designed to use and direct these particles into a specific point."
    new "Allerdings sind menschliche Körper nicht darauf ausgelegt, diese Partikel an einen bestimmten Punkt zu lenken und zu nutzen."

    # say L865 lin
    old "So we weren't able to condense the magic in the place we needed to."
    new "Dann konnten wir die Magie also nicht an dem Ort kondensieren, den wir brauchten."

    # say L867 pla
    old "But we did in the church, you said that was where it had to be."
    new "Aber in der Kirche, du hast gesagt, da muss es sein."

    # say L868 lin
    old "Yeah sure, but it couldn't be the whole church, it has to be a specific point where the breach can occur."
    new "Klar, aber es kann nicht die ganze Kirche sein, es muss ein bestimmter Punkt sein, an dem der Riss entstehen kann."

    # say L869 pla
    old "Hmm, ok. So what do we have to do this time to make it happen?"
    new "Hmm, okay. Und was müssen wir diesmal tun, damit es klappt?"

    # say L871 lin
    old "To be honest, I'm not sure yet. I have to figure it out soon."
    new "Ehrlich gesagt, bin ich mir noch nicht sicher. Muss ich bald rauskriegen."

    # say L873 lin
    old "However, it is true that the magic power is running out."
    new "Allerdings stimmt es, dass die magische Kraft sich aus dem Staub macht."

    # say L874 lin
    old "That means we definitely have to do it again soon. And it has to be in the church."
    new "Das bedeutet, wir müssen es definitiv bald wieder tun. Und es muss in der Kirche sein."

    # say L876 lin
    old "So, while I figure it all out, you talk to the church people again, so we have access to it."
    new "Dann kläre ich das Ganze, während du dich wieder mit den Kirchenleuten triffst, damit wir Zugang haben."

    # say L877 pla
    old "Oh, damn, do we have to do it again with them?"
    new "Oh, verdammt, müssen wir das wirklich noch mal mit denen machen?"

    # say L878 lin
    old "Not necessarily... Let me solve this first."
    new "Nicht unbedingt... Lass mich das erst lösen."

    # say L879 lin
    old "For now just try and make sure we can use the church again when the moment comes, ok?"
    new "Versuch einfach sicherzustellen, dass wir die Kirche wieder benutzen können, wenn der Moment kommt, okay?"

    # say L881 pla
    old "Sure, no problem, I'll handle it."
    new "Klar, kein Problem, ich kümmere mich drum."

    # say L883 lin
    old "Fine, then I'll keep in touch in case we need something else."
    new "Gut, dann halte ich Kontakt, falls wir noch etwas brauchen."

    # say L902 gra
    old "Oh my! What a wonderful surprise! Hello [pla]!"
    new "Oh mein Gott! Was für eine wunderbare Überraschung! Hallo [pla]!"

    # say L903 pla
    old "Hello Sister Grace, nice seeing you again."
    new "Hallo Schwester Grace, schön dich wiederzusehen."

    # say L904 gra
    old "And what do I owe this nice surprise?"
    new "Und was verdanke ich diesem schönen Überraschungsbesuch?"

    # say L905 pla
    old "I just wanted to say hello. And see if you need help with anything."
    new "Ich wollte dich nur begrüßen. Und schauen, ob du Hilfe brauchst."

    # say L906 pla
    old "You know, with decorating and stuff. I have some free time, so I figured I could help you."
    new "Du weißt schon, mit dem Dekorieren und so. Ich habe ein bisschen freie Zeit, dachte mir, ich könnte dir helfen."

    # say L908 gra
    old "Oh lord! You're sent again from the heavens, this is perfect."
    new "Oh Herr! Sie sind wieder vom Himmel gesandt, das ist perfekt."

    # say L909 gra
    old "Just today we were going to start with the Christmas decorations. So you came at the right moment."
    new "Gerade heute wollten wir mit den Weihnachtsdekorationen beginnen. Also kommen Sie genau richtig."

    # say L910 pla
    old "Oh really? That's perfect, I can help with whatever you need."
    new "Oh wirklich? Das ist perfekt, ich kann dir bei allem helfen, was du brauchst."

    # say L911 gra
    old "Come with me, I'll show you."
    new "Kommen Sie mit mir, ich zeige es Ihnen."

    # say L918 jon
    old "[pla]! what a nice surprise!"
    new "[pla]! Was für eine nette Überraschung!"

    # say L919 pla
    old "Hi Mrs. Jones."
    new "Hallo Mrs. Jones."

    # say L920 jon
    old "Hello darling, it's good to see you. And may I ask what brings you here?"
    new "Hallo Liebling, schön dich zu sehen. Darf ich fragen, was führt dich hierher?"

    # say L921 pla
    old "I just came to see if I could help with the Christmas decorations."
    new "Ich bin einfach gekommen, um zu sehen, ob ich bei den Weihnachtsdekorationen helfen kann."

    # say L922 jon
    old "Oh! Well, that's very nice of you. And you came just in time, we were about to start."
    new "Oh! Das ist sehr nett von Ihnen. Und Sie sind gerade rechtzeitig gekommen, wir wollten gerade anfangen."

    # say L923 gra
    old "I was telling him just that, the Lord knew we needed his help and sent him to us."
    new "Ich habe ihm gerade gesagt, der Herr wusste, dass wir seine Hilfe brauchen, und hat ihn zu uns gesandt."

    # say L924 jon
    old "Well darling, let's not waste time, come with us, we'll show you what we need."
    new "Na Liebes, lassen wir uns nicht Zeit, komm mit uns, wir zeigen dir, was wir brauchen."

    # say L926 gra
    old "We need your help with putting up the decorations for Christmas."
    new "Wir brauchen deine Hilfe, um die Weihnachtsdekoration aufzuhängen."

    # say L927 jon
    old "The decorations have to be put on the benches and up in the ceiling."
    new "Die Dekorationen müssen auf die Bänke und an die Decke gehängt werden."

    # say L928 jon
    old "It has to be ready before Christmas eve for the members of the congregation to enjoy."
    new "Es muss vor dem Heiligabend fertig sein, damit die Gemeindemitglieder es genießen können."

    # say L929 pla
    old "Sure thing, no problem."
    new "Klar, kein Problem."

    # narrator L936 
    old "Click all the marked spaces in time to decorate the church."
    new "Klicke alle markierten Stellen rechtzeitig an, um die Kirche zu dekorieren."

    # say L952 pla
    old "Good morning Mrs. Jones, Sister Grace."
    new "Guten Morgen Mrs. Jones, Schwester Grace."

    # say L953 gra
    old "Hello [pla], what a blessing from the lord seeing you today."
    new "Guten Morgen [pla], was für eine Gnade des Herrn, Sie heute zu sehen."

    # say L954 jon
    old "Hello darling, how are you?"
    new "Hallo Liebling, wie geht es Ihnen?"

    # say L955 pla
    old "I'm fine thank you, I came to help you with the decorations again."
    new "Mir geht's gut, danke. Ich bin hier, um dir wieder bei den Dekorationen zu helfen."

    # say L956 gra
    old "Oh thank you so much, you're of such great help."
    new "Oh vielen Dank, Sie sind eine große Hilfe."

    # say L957 jon
    old "Sister Grace is right, it's nice that you came back today. Thank you darling."
    new "Schwester Grace hat recht, es ist schön, dass du heute wieder gekommen bist. Danke Schatz."

    # say L958 pla
    old "It's no problem."
    new "Das ist kein Problem."

    # say L959 pla
    old "I'll get to it then."
    new "Dann mach ich mich mal daran."

    # say L978 jon
    old "Oh darling! You're such a good worker."
    new "Oh Darling! Sie sind ein so guter Arbeiter."

    # say L979 gra
    old "I'm sure if you keep going at this pace you'll have it ready in no time."
    new "Ich bin sicher, wenn Sie so weitermachen, haben Sie es in null Komma nichts fertig."

    # say L981 jon
    old "Having you do all this work really helps us a lot."
    new "Dass du all das für uns tust, hilft uns wirklich sehr."

    # say L982 gra
    old "I agree, the Lord graced us with this great help of yours."
    new "Ich stimme zu, der Herr hat uns mit deiner großartigen Hilfe gesegnet."

    # say L983 jon
    old "Now, I'm sure you have some other things to do. So we won't keep you here anymore."
    new "Nun, ich bin sicher, Sie haben noch andere Dinge zu tun. Deshalb werden wir Sie nicht länger hier festhalten."

    # say L984 jon
    old "But make sure to come back soon."
    new "Aber sorgen Sie dafür, bald wiederzukommen."

    # say L986 pla
    old "Sure, I'll be back soon and keep helping you."
    new "Klar, ich komme bald wieder und helfe dir weiter."

    # say L1023 jon
    old "Well... You didn't really do much today."
    new "Nun... Sie haben heute nicht wirklich viel getan."

    # say L1024 jon
    old "But it's ok, it's a delicate thing to do. I'm sure you'll get the hang of it soon."
    new "Aber es ist okay, es ist eine zarte Sache. Ich bin sicher, Sie werden es bald draufhaben."

    # say L1025 gra
    old "That's right, the lord will illuminate you and you'll get better at it. Don't worry."
    new "Das stimmt, der Herr wird dich erleuchten und du wirst besser darin werden. Mach dir keine Sorgen."

    # say L1026 pla
    old "Yeah... Sure."
    new "Klar... Sicher."

    # say L1027 pla
    old "I have a couple of things to do, so I think I'll get going, but I'll come back again and keep working."
    new "Ich hab noch ein paar Sachen zu erledigen, aber ich komm wieder und mach weiter."

    # say L1028 jon
    old "We know you will, don't worry."
    new "Wir wissen, dass Sie das tun werden, machen Sie sich keine Sorgen."

    # say L1042 lin
    old "Hey [pla]. I figured out what the problem was."
    new "Hey [pla]. Ich habe rausgefunden, was das Problem war."

    # say L1043 pla
    old "Huh? Problem? Good morning by the way."
    new "Huh? Problem? Guten Morgen übrigens."

    # say L1044 lin
    old "Yeah, the problem we had with the ritual last time, I figured out what it was."
    new "Ja, das Problem mit dem Ritual letztes Mal, ich hab rausgefunden, was es war."

    # say L1045 pla
    old "Oh right, right. I remember."
    new "Oh ja, stimmt. Ich erinnere mich."

    # say L1046 pla
    old "So? What was it?"
    new "Und? Was war es?"

    # say L1048 lin
    old "Well, I figured out that the problem last time, was that we did it with human bodies that couldn't retain as much magic power."
    new "Na ja, ich habe herausgefunden, dass das Problem letztes Mal darin lag, dass wir es mit menschlichen Körpern gemacht haben, die nicht so viel magische Energie speichern können."

    # say L1049 lin
    old "Well, two of them couldn't."
    new "Na ja, zwei von ihnen konnten es nicht."

    # say L1050 pla
    old "What? What does that mean?"
    new "Was? Was bedeutet das?"

    # say L1051 lin
    old "Unlike us, you humans get old as time passes."
    new "Im Gegensatz zu uns altern ihr Menschen mit der Zeit."

    # say L1052 lin
    old "This means that the older you get, the less magic power you're able to retain."
    new "Das bedeutet, je älter du wirst, desto weniger magische Kraft kannst du aufrechterhalten."

    # say L1053 lin
    old "I believe that's the mistake we made last time."
    new "Ich glaube, das war der Fehler, den wir letztes Mal gemacht haben."

    # say L1054 lin
    old "So this time it has to be done with young people. They should be able to retain the amount of magic we need."
    new "Dann müssen wir es dieses Mal mit jungen Leuten machen. Die sollten die nötige Magie halten können."

    # say L1056 pla
    old "Three young girls... I mean, damn, that would be a bit difficult."
    new "Drei junge Mädchen... ich meine, verdammt, das wäre ein bisschen schwierig."

    # say L1057 pla
    old "Hmm... I suppose Billie would help again... and my only friends are Belle and Hinn..."
    new "Hmm... Ich denke, Billie würde wieder helfen... und meine einzigen Freunde sind Belle und Hinn..."

    # say L1058 pla
    old "What should I say? {i}\"Hey, do you want to be in an orgy at the church?\"{/i} "
    new "Was soll ich sagen? {i}\"Hey, willst du bei einer Orgie in der Kirche mitmachen?\"{/i}"

    # say L1059 lin
    old "Well, you should definetly find a way... And I'm also working on the ritual..."
    new "Na, du solltest definitiv einen Weg finden... Und ich arbeite auch an dem Ritual..."

    # say L1060 lin
    old "Directing the magic power to a specific point isn't as easy as I thought."
    new "Die magische Energie auf einen bestimmten Punkt zu lenken ist nicht so einfach, wie ich dachte."

    # say L1061 lin
    old "I still have to run some more tests."
    new "Ich muss noch ein paar Tests durchführen."

    # say L1062 lin
    old "So you have time to figure it out."
    new "Dann hast du also Zeit, es herauszufinden."

    # say L1064 pla
    old "Ok, ok, I'll think about it."
    new "Ok, ok, ich denk drüber nach."

    # say L1066 lin
    old "Ok, then keep working on the church, I'll contact you as soon as I know exactly what we need."
    new "Ok, dann mach weiter an der Kirche, ich kontaktiere dich, sobald ich weiß, was wir genau brauchen."

    # say L1067 pla
    old "Ok, see you later then."
    new "Ok, dann bis später."

    # say L1084 pla
    old "Oh, hi [sis], how are you doing?"
    new "Oh, hallo [sis], wie geht es dir?"

    # say L1092 pla
    old "Oh, hi [sis], what are you doing up so late?"
    new "Oh, hallo [sis], was machst du denn so spät noch wach?"

    # say L1094 linSis
    old "I did it [pla]! It worked!"
    new "Ich hab's geschafft [pla]! Es hat funktioniert!"

    # say L1095 pla
    old "Huh? What do you mean it worked?"
    new "Was meinst du damit, dass es funktioniert hat?"

    # say L1096 pla
    old "Did you sell something expensive online?"
    new "Hast du was Teures online verkauft?"

    # say L1098 linSis
    old "No, no, no, it's me Linett. Listen, use agamoto's eye."
    new "Nein, nein, nein, ich bin's Linett. Hör zu, benutz das Auge von Agamoto."

    # say L1100 linSis
    old "Just do it, use the agamoto's eye."
    new "Mach es, benutz das Auge des Agamoto."

    # say L1107 pla
    old "Wow! But, what the fuck? You're Linett? But... Why do you look like my [sisrel]?"
    new "Wow! Aber, was zur Hölle? Du bist Linett? Aber... Warum siehst du aus wie meine [sisrel]?"

    # say L1108 lin
    old "Yeah! Remember that I said I still had to test something? I managed to do again what I did with your friend last time!"
    new "Ja! Erinnerst du dich, dass ich gesagt habe, ich müsste noch was ausprobieren? Ich bin es wieder geschafft, wie beim letzten Mal mit deinem Freund!"

    # say L1109 pla
    old "Wait what? What the fuck? You went into my [sisrel]'s body?"
    new "Warte, was? Was zum Teufel? Du bist in den Körper meiner [sisrel] gegangen?"

    # say L1110 lin
    old "Yes! Yes! I did it. I managed to get insider her!"
    new "Ja! Ja! Ich hab's geschafft. Ich bin in sie reingekommen!"

    # say L1111 pla
    old "Woah! That's insane. But wait, come with me for a moment, we can't keep talking here."
    new "Wow! Das ist verrückt. Aber warte, komm mit mir einen Moment, wir können hier nicht weiterreden."

    # say L1117 pla
    old "Now, what the fuck are you doing in [sis]'s body?"
    new "Was zur Hölle machst du in [sis]s Körper?"

    # say L1118 linSis
    old "Well, I figured out that doing this would be necessary for the ritual, so I decided to try to do it again."
    new "Na ja, ich habe herausgefunden, dass es für den Ritual notwendig ist, also habe ich beschlossen, es noch einmal zu versuchen."

    # say L1119 linSis
    old "To see if I could do it better this time."
    new "Um zu sehen, ob ich es dieses Mal besser hinbekomme."

    # say L1120 pla
    old "What do you mean to do it better?"
    new "Was meinst du damit, es besser machen?"

    # say L1121 linSis
    old "Well, we don't usually get involved with humans."
    new "Na ja, wir mischen uns normalerweise nicht mit Menschen ein."

    # say L1122 linSis
    old "So, doing something like getting inside a person is a bit weird."
    new "Also, so etwas wie in jemanden hineinzukommen ist schon ziemlich seltsam."

    # say L1123 linSis
    old "I did it last time because, I was looking trying to survive by taking your friend as my host."
    new "Ich hab's das letzte Mal getan, weil ich versucht habe, zu überleben, indem ich deinen Freund als Wirt genommen habe."

    # say L1124 linSis
    old "So, I was almost dead that time..."
    new "So, ich war damals fast tot..."

    # say L1125 pla
    old "Ok... But why did you do it again?"
    new "Okay... Aber warum hast du es noch mal gemacht?"

    # say L1127 linSis
    old "Well, I thought that if I did it at will, and at full strength, maybe it would be different."
    new "Na ja, ich dachte, wenn ich es bewusst und mit voller Kraft mache, könnte es anders sein."

    # say L1128 linSis
    old "That I could do it with a lot more control."
    new "Dass ich es viel besser kontrollieren könnte."

    # say L1129 linSis
    old "And it worked! See how well I can control her?! There's not even a little bit of interference."
    new "Und es hat funktioniert! Schau, wie gut ich sie kontrollieren kann! Da ist nicht mal ein bisschen Interferenz."

    # say L1130 pla
    old "Yeah, yeah, congrats. But you have to get out of [sis]‘s body."
    new "Ja, ja, gratuliere. Aber du musst aus [sis]s Körper raus."

    # say L1131 pla
    old "And you have to do it now!"
    new "Und du musst es jetzt tun!"

    # say L1132 linSis
    old "Well, you see... We may have a little of a problem there."
    new "Na ja, du siehst... Da könnte ein kleines Problem auftauchen."

    # say L1133 pla
    old "What do you mean a problem?"
    new "Was meinst du mit Problem?"

    # say L1134 linSis
    old "Remember what you did last time to get me out of your friend's body?"
    new "Erinnerst du dich noch, was du letztes Mal gemacht hast, um mich aus deinem Freund rauszuholen?"

    # say L1136 pla
    old "Hmm, not really...  Why?"
    new "Hmm, nein... Warum?"

    # say L1137 linSis
    old "The thing is that to be able to get out of your [sisrel] ‘s body I'm going to need a recharge of magical power."
    new "Das Problem ist, dass ich um aus deinem [sisrel] Körper rauszukommen, eine Aufladung meiner magischen Kräfte brauche."

    # say L1138 linSis
    old "That's the only way to undo my ‘possession'."
    new "Das ist der einzige Weg, um die Besessenheit rückgängig zu machen."

    # say L1139 pla
    old "Oh fuck, so I have to have sex with you in [sis] ‘s body?"
    new "Oh Scheiße, also muss ich mit dir in [sis]’ Körper ficken?"

    # say L1140 linSis
    old "Yes, that's right. You got it. Come on, let's do it."
    new "Ja, genau. Du hast es kapiert. Komm schon, lass es uns tun."

    # say L1141 pla
    old "W- wait a minute. What about [sis]? Won't she know about it? Isn't she going to feel anything?"
    new "W-warte mal. Was ist mit [sis]? Wird sie davon erfahren? Wird sie überhaupt was spüren?"

    # say L1142 linSis
    old "No, she won't feel or remember anything."
    new "Nein, sie wird nichts spüren oder sich daran erinnern."

    # say L1143 pla
    old "How do you know?"
    new "Wie weißt du das?"

    # say L1145 linSis
    old "Well, I did it with a different spell, one that grants me total control of this body."
    new "Nun, ich habe es mit einem anderen Zauber getan, der mir die vollständige Kontrolle über diesen Körper gibt."

    # say L1146 linSis
    old "The host is unconscious. And she will be until I leave the body."
    new "Der Wirt ist bewusstlos. Und sie wird es bleiben, bis ich den Körper verlasse."

    # say L1147 linSis
    old "Besides, this time I'm at full magic power, so I have no trouble controlling her completely."
    new "Außerdem bin ich dieses Mal mit voller magischer Kraft, deshalb habe ich keine Probleme, sie komplett zu kontrollieren."

    # say L1148 pla
    old "I still don't get why you had to do this. I mean, what is all of this for?"
    new "Ich verstehe immer noch nicht, warum du das tun musst. Ich meine, wofür ist das alles?"

    # say L1149 linSis
    old "This is for the ritual I mean, with all the control this method gives to me, I'll have no trouble directing the magic power."
    new "Das ist für den Ritual, meine ich. Mit der Kontrolle, die mir diese Methode gibt, werde ich keine Schwierigkeiten haben, die magische Kraft zu lenken."

    # say L1150 pla
    old "Ohhh... I get it."
    new "Ohhh... Ich verstehe."

    # say L1151 linSis
    old "Now, give me the magic power I need to get out of this body."
    new "Jetzt gib mir die magische Kraft, die ich brauche, um diesen Körper zu verlassen."

    # say L1165 pla
    old "Are you sure [sis] won't feel it?"
    new "Bist du sicher, dass [sis] es nicht spüren wird?"

    # say L1166 pla
    old "What if she wakes up during it?"
    new "Was ist, wenn sie währenddessen aufwacht?"

    # say L1167 linSis
    old "That's not possible, even after I get out, it's going to take a while before she wakes up."
    new "Das ist nicht möglich, selbst wenn ich raus bin, dauert es noch eine Weile, bis sie aufwacht."

    # say L1168 pla
    old "Hmmm, ok."
    new "Hmmm, okay."

    # say L1169 linSis
    old "Your cock is impressive, this size and thickness."
    new "Dein Schwanz ist beeindruckend, diese Größe und Dicke."

    # say L1170 linSis
    old "No wonder you never have trouble supplying me with magic."
    new "Kein Wunder, dass du mir nie Probleme damit machst, mich mit Magie zu versorgen."

    # say L1171 pla
    old "We have to do this quick. Someone could hear us."
    new "Wir müssen uns beeilen. Jemand könnte uns hören."

    # say L1172 linSis
    old "Oh, relax, remember you have to cum for me to come out of you [sisrel]‘s body."
    new "Oh, entspann dich, du musst für mich kommen, damit ich aus dir rauskomme [sisrel]’s Körper."

    # say L1173 linSis
    old "And you won't if you're not enjoying it."
    new "Und das wirst du nicht, wenn du es nicht genießt."

    # say L1174 pla
    old "Ok, ok, I'll do it."
    new "Okay, okay, ich mach's."

    # say L1184 lin
    old "I might do it again just to experience that."
    new "Ich mach's vielleicht noch mal, nur um das zu erleben."

    # say L1185 pla
    old "Haha, very funny."
    new "Haha, sehr witzig."

    # say L1186 pla
    old "We should go to my bedroom."
    new "Wir sollten in mein Schlafzimmer gehen."

    # say L1187 pla
    old "But first help me clean her and put her in bed."
    new "Aber erst hilf mir, sie zu reinigen und ins Bett zu legen."

    # say L1188 pla
    old "She's not gonna wake up if we move her. Right?"
    new "Sie wird nicht aufwachen, wenn wir sie bewegen. Stimmt's?"

    # say L1189 lin
    old "No, she's passed out."
    new "Nein, sie ist bewusstlos."

    # say L1190 lin
    old "And won't wake up for a while, so it's ok."
    new "Und wird auch nicht bald wach, also ist alles in Ordnung."

    # say L1196 lin
    old "This is perfect, now we can finally do the whole ritual succesfully!"
    new "Das ist perfekt, jetzt können wir endlich den ganzen Ritual erfolgreich durchführen!"

    # say L1197 pla
    old "That's good and all, but that experiment was a little too much."
    new "Das ist gut und alles, aber dieses Experiment war ein bisschen zu viel."

    # say L1198 lin
    old "Well, it worked and that's all that matters."
    new "Na ja, es hat funktioniert und das zählt am Ende."

    # say L1199 lin
    old "What's most important right now is that there's another problem to solve."
    new "Das Wichtigste im Moment ist, dass es ein weiteres Problem zu lösen gibt."

    # say L1200 pla
    old "What another one? What else do we need?"
    new "Was noch eins? Was müssen wir sonst noch?"

    # say L1201 lin
    old "Well, we need the actual people."
    new "Na ja, wir brauchen die echten Menschen."

    # say L1202 lin
    old "Remember, I did this experiment because we need to control the magic in humans?"
    new "Erinnerst du dich, ich hab dieses Experiment gemacht, weil wir die Magie in Menschen kontrollieren müssen?"

    # say L1204 pla
    old "Oh, you're right, I forgot."
    new "Oh, stimmt, ich hab's vergessen."

    # say L1205 lin
    old "The problem is that we need three people, and I can't get inside all three of them."
    new "Das Problem ist, wir brauchen drei Leute, und ich kann nicht in alle drei rein."

    # say L1206 pla
    old "Oh, actually, I hadn't told you, but I know three other shinigamis."
    new "Oh, eigentlich hatte ich dir noch nicht gesagt, aber ich kenne drei andere Shinigamis."

    # say L1207 pla
    old "Maybe we could explain the situation to them, and ask for their help."
    new "Vielleicht könnten wir ihnen die Situation erklären und um ihre Hilfe bitten."

    # say L1208 lin
    old "Hmm... It could be, but I would need to train them to do it."
    new "Hmm... Das könnte sein, aber ich müsste sie dazu ausbilden."

    # say L1209 pla
    old "I think it will be fine if we talk to them."
    new "Ich denke, es wird gut sein, wenn wir mit ihnen reden."

    # say L1210 lin
    old "Ok, so let's go, where are they?"
    new "Okay, dann lass uns gehen, wo sind sie?"

    # say L1212 pla
    old "Woah, you wanna go now?"
    new "Woah, willst du jetzt gleich los?"

    # say L1213 pla
    old "Listen, it's pretty late and I haven't slept at all."
    new "Hör mal, es ist ziemlich spät und ich habe überhaupt nicht geschlafen."

    # say L1214 pla
    old "What about if we go tomorrow morning?"
    new "Was ist, wenn wir morgen früh gehen?"

    # say L1216 lin
    old "Hmm, ok, I'll come here tomorrow morning then."
    new "Hmm, okay, dann komme ich morgen früh hierher."

    # say L1217 pla
    old "Ok, see you tomorrow."
    new "Ok, bis morgen dann."

    # say L1233 lin
    old "Hey, are you ready to go talk with the other shinigamies?"
    new "Hey, bist du bereit, mit den anderen Shinigami zu reden?"

    # say L1234 pla
    old "What? Now? I just woke up!"
    new "Was? Jetzt? Ich bin gerade erst aufgewacht!"

    # say L1235 lin
    old "What!? Remember I have to teach them how to do the spell. It's not as simple as when you use magic."
    new "Was!? Erinnerst du dich noch, dass ich ihnen zeigen muss, wie der Zauber funktioniert. Das ist nicht so einfach wie wenn du Magie benutzt."

    # say L1236 lin
    old "It takes time to learn a spell, and we don't even know if they're going to say yes."
    new "Es dauert, ein Zauber zu lernen, und wir wissen noch nicht mal, ob sie überhaupt Ja sagen."

    # say L1237 lin
    old "So we have to go now!"
    new "Dann müssen wir jetzt los!"

    # say L1238 pla
    old "Ok, ok, I get it."
    new "Okay, okay, ich hab's kapiert."

    # say L1239 pla
    old "Let's go then."
    new "Dann lass uns gehen."

    # say L1262 pla
    old "Hey girls."
    new "Hey Mädels."

    # say L1263 mil
    old "Hello."
    new "Hallo."

    # say L1264 dev
    old "Oh! [pla] is here! Hiiii, it's been a while since I've seen you!"
    new "Oh! [pla] ist hier! Hiiii, es ist ja schon eine Weile her, dass ich dich gesehen habe!"

    # say L1265 gom
    old "Hello, how have you been?"
    new "Hallo, wie geht's dir?"

    # say L1266 pla
    old "Fine, fine, thank you."
    new "Alles gut, danke."

    # say L1267 pla
    old "Hey, remember that a while ago, I told you about a shinigami that was inside one of my friends?"
    new "Hey, erinnerst du dich noch daran, dass ich dir vor einiger Zeit von einem Shinigami erzählt habe, der in einem meiner Freunde war?"

    # say L1268 pla
    old "And I asked you for advice about what to do?"
    new "Und ich hab dich gefragt, was ich da machen soll?"

    # say L1270 mil
    old "Indeed, we remember, what about it?"
    new "Natürlich, worum geht's?"

    # say L1271 pla
    old "Well, I wanted to introduce her to you, so I brought her with me."
    new "Na ja, ich wollte sie dir vorstellen, deshalb habe ich sie mitgebracht."

    # say L1280 pla
    old "Everyone, this is Linett."
    new "Alle, das ist Linett."

    # say L1281 lin
    old "Hello, nice meeting you."
    new "Hallo, nett, euch kennenzulernen."

    # say L1284 gom
    old "Umm... eh, hi."
    new "Äh... hallo."

    # say L1285 lin
    old "I understand your surprise, I didn't expect to see other shinigamis in this town."
    new "Ich verstehe deine Überraschung, ich habe auch nicht erwartet, andere Shinigami in dieser Stadt zu sehen."

    # say L1286 lin
    old "But I have to talk to you about something important."
    new "Aber ich muss mit dir über etwas Wichtiges sprechen."

    # say L1287 pla
    old "I think you should listen to her, it's about the magic power."
    new "Ich denke, du solltest ihr zuhören, es geht um die magische Kraft."

    # say L1290 mil
    old "The magic power? What about it?"
    new "Die magische Kraft? Was ist damit?"

    # say L1291 dev
    old "I don't know about you. But if [pla] says it's ok, I'll listen."
    new "Ich weiß nicht. Aber wenn [pla] sagt, dass es okay ist, werde ich zuhören."

    # say L1292 gom
    old "Hmm, this could be important."
    new "Hmm, das könnte wichtig sein."

    # say L1293 lin
    old "Some time ago I discovered that in this town's church used to be a place with a strong connection with the magic world."
    new "Vor einiger Zeit habe ich entdeckt, dass in dieser Stadt eine Kirche war, die eine starke Verbindung zur magischen Welt hatte."

    # say L1294 mil
    old "So? What does it matter now that the magic world doesn't exist?"
    new "Und? Was soll das jetzt noch bedeuten, wenn die magische Welt nicht mehr existiert?"

    # say L1295 lin
    old "Well... That connection remains even if the magic world is gone."
    new "Na ja... Die Verbindung besteht weiterhin, auch wenn die magische Welt verschwunden ist."

    # say L1296 dev
    old "Oh! Really?"
    new "Oh! Wirklich?"

    # say L1297 gom
    old "And what does it mean?"
    new "Und was bedeutet das?"

    # say L1298 lin
    old "It means that is a perfect place to set a magic power generating point."
    new "Das bedeutet, dass es der perfekte Ort ist, um einen Magiegenerierungspunkt zu errichten."

    # say L1299 gom
    old "Wow, really? That's amazing."
    new "Wow, echt? Das ist ja toll."

    # say L1302 lin
    old "That's right, and me, along with [pla], did a ritual to trying to create that magic point."
    new "Das stimmt, und [pla] und ich haben einen Ritual durchgeführt, um diesen magischen Punkt zu erschaffen."

    # say L1303 lin
    old "But it went wrong. However, I believe I've solved the issue and I would like to try again."
    new "Aber es ist schiefgelaufen. Allerdings glaube ich, das Problem gelöst zu haben und möchte es noch einmal versuchen."

    # say L1305 pla
    old "Actually, that's why we came here today. We need your help with the ritual."
    new "Tatsächlich, deshalb sind wir heute hier. Wir brauchen deine Hilfe bei dem Ritual."

    # say L1306 mil
    old "Our help? We don't even know you... or your intentions..."
    new "Unsere Hilfe? Wir kennen dich doch gar nicht... oder deine Absichten..."

    # say L1307 gom
    old "She's right, this is the first time any of us has heard anything like this."
    new "Du hast recht, das ist das erste Mal, dass einer von uns so etwas hört."

    # say L1308 lin
    old "I know it sounds strange, this is actually new for me too."
    new "Ich weiß, das klingt seltsam, aber das ist für mich auch neu."

    # say L1309 lin
    old "But we need to try it because the magic power is running out."
    new "Aber wir müssen es versuchen, weil die magische Kraft schwächer wird."

    # say L1310 lin
    old "And if we don't do anything we're just going to die. I gain nothing by lying to you."
    new "Und wenn wir nichts tun, sterben wir einfach. Ich habe nichts davon, dir zu lügen."

    # say L1312 dev
    old "Ok and what do you propose we do?"
    new "Okay und was schlägst du vor, dass wir tun?"

    # say L1313 lin
    old "For starters, we're going to need three young humans. [pla] will handle that."
    new "Zum Anfang werden wir drei junge Menschen brauchen. [pla] kümmert sich darum."

    # say L1314 lin
    old "The idea is that we use them in a ritual in which we will create a breach point, and pour magic into it to force it to open."
    new "Die Idee ist, dass wir sie in einem Ritual verwenden, bei dem wir einen Durchbruchspunkt schaffen und Magie hineingießen, um ihn zu öffnen."

    # say L1316 gom
    old "I see, I get the idea."
    new "Ich verstehe, die Idee ist klar."

    # say L1317 gom
    old "But I see some difficulties with the plan."
    new "Aber ich sehe ein paar Schwierigkeiten mit dem Plan."

    # say L1319 mil
    old "For starters, humans can't control magic. And even if they could, how would we make them do that?"
    new "Zum einen können Menschen Magie nicht kontrollieren. Und selbst wenn sie es könnten, wie sollen wir sie dazu bringen?"

    # say L1321 lin
    old "Well, the idea is that we're going to get inside them, and control the magic from within."
    new "Na ja, die Idee ist, dass wir in sie hineingehen und von innen die Magie kontrollieren."

    # say L1325 dev
    old "What? We're going to be trapped!"
    new "Was? Wir werden gefangen sein!"

    # say L1326 mil
    old "That's right, it's pretty weird to think doing that on purpose, is really dangerous."
    new "Stimmt, es ist ziemlich seltsam und gefährlich, absichtlich so was zu machen."

    # say L1327 mil
    old "Isn't this just a trap to imprison us in human bodies?"
    new "Ist das etwa eine Falle, um uns in menschliche Körper einzusperren?"

    # say L1328 lin
    old "What!? What would I get from that?"
    new "Was!? Was hätte ich davon?"

    # say L1329 pla
    old "A- actually, we discovered that there is a way to do it safely."
    new "A- eigentlich haben wir herausgefunden, dass es einen sicheren Weg gibt."

    # say L1330 lin
    old "Exactly, I've been running some tests, and found a way in which it can be done."
    new "Genau, ich habe einige Tests durchgeführt und einen Weg gefunden, wie es sicher gemacht werden kann."

    # say L1331 lin
    old "I've created a spell with which we can get inside a human body and control it at will."
    new "Ich hab einen Zauber kreiert, mit dem wir in einen menschlichen Körper eindringen und ihn nach Belieben steuern können."

    # say L1332 lin
    old "And we can do it without being on the verge of death."
    new "Und wir können es tun, ohne am Rande des Todes zu stehen."

    # say L1333 gom
    old "I had never heard of something like that, are you sure about what you're saying?"
    new "Ich hab noch nie von so was gehört, bist du dir sicher, was du da sagst?"

    # say L1334 pla
    old "She's telling the truth, I helped her."
    new "Sie sagt die Wahrheit, ich habe ihr geholfen."

    # say L1335 lin
    old "If you'll let me show, I can teach you how to do it."
    new "Wenn du mich lässt, zeige ich es dir und kann dich beibringen, wie man das macht."

    # say L1337 mil
    old "I can't believe you're actually considering listening to this!"
    new "Ich kann nicht glauben, dass du dir das tatsächlich anhören willst!"

    # say L1338 dev
    old "I don't really trust you. But I do [pla], if he says it's ok maybe we should listen."
    new "Ich vertraue dir nicht wirklich. Aber ich tu [pla], wenn er sagt, dass es okay ist, sollten wir vielleicht zuhören."

    # say L1339 gom
    old "Ok, we'll hear what you have to say, but if you don't convince us, we won't follow you."
    new "Okay, wir hören dir zu, aber wenn du uns nicht überzeugst, folgen wir dir nicht."

    # say L1340 lin
    old "Ok, I know after listening you will understand."
    new "Okay, ich weiß, nachdem ihr zuhört, werdet ihr es verstehen."

    # say L1341 lin
    old "But wait, before I start. Don't have to keep working in the church? Let me this to me and you keep working on the church."
    new "Aber warte, bevor ich anfange. Muss ich nicht weiter in der Kirche arbeiten? Lass mich das machen und ihr könnt weiter an der Kirche arbeiten."

    # say L1342 lin
    old "We are running out of time and need that place ready for the ritual."
    new "Wir haben nicht mehr viel Zeit und brauchen den Ort für das Ritual bereit."

    # say L1344 pla
    old "Oh right."
    new "Oh richtig."

    # say L1345 pla
    old "Ok, ok I'll keep working on the church, while you explain everything to them. See you later guys."
    new "Okay, okay, ich mach weiter in der Kirche, während du ihnen alles erklären kannst. Bis später, Leute."

    # say L1347 lin
    old "Great, we'll talk later at home."
    new "Super, dann reden wir später zu Hause."

    # say L1348 dev
    old "See you [pla]!"
    new "Bis später [pla]!"

    # say L1364 lin
    old "Hey there [pla]!"
    new "Hey [pla]!"

    # say L1365 pla
    old "Oh, hey, did you manage to convince them?"
    new "Oh, hey, hast du es geschafft, sie zu überzeugen?"

    # say L1366 lin
    old "Yeah, I did, they didn't believe me at first."
    new "Ja, hab ich. Zuerst haben sie mir nicht geglaubt."

    # say L1367 lin
    old "Especially that Mildret one. She was a lot of trouble."
    new "Vor allem Mildret. Die war echt schwierig."

    # say L1368 lin
    old "But once I showed them the spell they understood."
    new "Aber sobald ich ihnen den Zauber gezeigt habe, haben sie verstanden."

    # say L1370 pla
    old "You showed them? But how did you get out of the host?"
    new "Du hast es ihnen gezeigt? Aber wie bist du aus dem Wirt rausgekommen?"

    # say L1372 lin
    old "I didn't perform it. I only told them how it was done."
    new "Ich hab es nicht durchgeführt. Ich hab ihnen nur erklärt, wie es funktioniert."

    # say L1373 lin
    old "All shinigami know and understand magic, so they knew I was telling them the truth."
    new "Alle Shinigami kennen und verstehen Magie, deshalb wussten sie, dass ich die Wahrheit sage."

    # say L1375 pla
    old "Oh, I see, nice."
    new "Oh, ich verstehe, cool."

    # say L1376 pla
    old "Everything's fine now, right? I mean, now you all know the spell."
    new "Alles klar jetzt, oder? Ich meine, jetzt kennt ihr alle den Spruch."

    # say L1377 pla
    old "And I'm taking care of the church, so we're almost ready."
    new "Und ich kümmere mich um die Kirche, also sind wir fast bereit."

    # say L1378 lin
    old "Hmm, not really. It sounds ok, but it's a very complicated spell. And I merely explained it to them...."
    new "Hmm, nicht wirklich. Klar klingt es gut, aber es ist ein sehr komplizierter Zauber. Und ich habe ihn ihnen nur erklärt...."

    # say L1379 lin
    old "If we want to make sure that everything goes perfect the day of the ritual, they're going to need practice."
    new "Wenn wir sicherstellen wollen, dass alles perfekt am Tag des Rituals läuft, brauchen sie Übung."

    # say L1381 pla
    old "Ok, so, what do you need me to do now?"
    new "Okay, und was soll ich jetzt machen?"

    # say L1382 lin
    old "For now it would be really good if you can decide on the three humans we're using for the ritual."
    new "Für den Anfang wäre es echt gut, wenn du dich entscheidest, welche drei Menschen wir für das Ritual nehmen."

    # say L1383 lin
    old "You said you had some people in mind."
    new "Du hast gesagt, du hättest schon ein paar Leute im Sinn."

    # say L1385 pla
    old "Y- yeah I did. But I- I don't know..."
    new "Y- ja, hab ich. Aber ich- ich weiß nicht..."

    # say L1387 lin
    old "I already told you there's no need to worry."
    new "Ich hab dir doch schon gesagt, dass du dir keine Sorgen machen musst."

    # say L1388 lin
    old "Remember, they'll be unconscious during the ritual and after."
    new "Erinnere dich, sie werden während des Rituals und danach bewusstlos sein."

    # say L1389 lin
    old "And all the time we'll be controlling them."
    new "Und die ganze Zeit werden wir sie kontrollieren."

    # say L1390 lin
    old "So, you shouldn't be this worried."
    new "Dann musst du dir ja keine Sorgen machen."

    # say L1391 pla
    old "Hmm ok, if that's how it is. Then, I guess I know who could work..."
    new "Hmm okay, wenn das so ist. Dann hab ich da jemanden im Kopf..."

    # say L1392 lin
    old "Great, then tomorrow morning we'll go see the shinigamis again and would be perfect to test the spell with one of them."
    new "Super, dann morgen früh gehen wir wieder zu den Shinigami und es wäre perfekt, den Spruch mit einem von ihnen zu testen."

    # say L1393 lin
    old "So that they can practice before the ritual."
    new "Damit sie vor dem Ritual üben können."

    # say L1394 pla
    old "You mean with a human?"
    new "Meinst du mit einem Menschen?"

    # say L1396 lin
    old "Yes [pla], we have to test the spell before the ritual with the girls."
    new "Ja [pla], wir müssen den Zauber vor dem Ritual mit den Mädchen testen."

    # say L1397 lin
    old "We need to be sure everything is going to work."
    new "Wir müssen sicher sein, dass alles funktioniert."

    # say L1398 pla
    old "Hmm... I guess you are right..."
    new "Hmm... Ich schätze, du hast recht."

    # say L1399 lin
    old "All right, everything is done, you better go to sleep because we have a lot to do tomorrow."
    new "Alles klar, alles erledigt, du solltest jetzt schlafen gehen, wir haben morgen viel zu tun."

    # say L1400 pla
    old "Ok, I'll see you tomorrow."
    new "Okay, dann sehen wir uns morgen."

    # say L1417 lin
    old "Hey [pla], are you ready to go?"
    new "Hey [pla], bist du bereit loszugehen?"

    # say L1418 pla
    old "Oh, good morning, yeah sure, let's go."
    new "Oh, guten Morgen, klar, lass uns gehen."

    # say L1433 pla
    old "Hey girls, good morning."
    new "Hey Mädels, guten Morgen."

    # say L1434 mil
    old "Hello again."
    new "Hallo nochmal."

    # say L1435 gom
    old "Hi, how are you today?"
    new "Hi, wie geht's dir heute?"

    # say L1436 dev
    old "Hiii, good seeing you again."
    new "Hiii, schön dich wiederzusehen."

    # say L1437 lin
    old "Listen, [pla] and I talked last night about the humans that are taking part in the ritual."
    new "Hör zu, [pla] und ich haben gestern Abend über die Menschen gesprochen, die am Ritual teilnehmen."

    # say L1438 lin
    old "And he's told me that he already has three people in mind for it."
    new "Und er hat mir gesagt, dass er schon drei Leute im Auge hat."

    # say L1439 lin
    old "So we'll go and find them for you to practice the spell before the ritual."
    new "Dann suchen wir sie für dich, damit du den Zauber vor dem Ritual üben kannst."

    # say L1440 lin
    old "Just to make sure that you can handle the spell and control the host body."
    new "Damit du die Kontrolle über den Wirtskörper behalten kannst."

    # say L1442 dev
    old "What? Now?... B- but I'm not ready... What if I can't get out?"
    new "Was? Jetzt?... A-aber ich bin nicht bereit... Was, wenn ich nicht rauskomme?"

    # say L1443 lin
    old "Don't worry Devonne, We may practice more with you."
    new "Mach dir keine Sorgen, Devonne, wir können noch mehr üben."

    # say L1444 lin
    old "Actually, I was thinking of starting with Gomory, I think she is ready."
    new "Eigentlich dachte ich daran, mit Gomory zu beginnen, ich glaube, sie ist bereit."

    # say L1445 mil
    old "Ok, it sounds fine."
    new "Ok, klingt gut."

    # say L1446 gom
    old "Yeah, it would be good to try it now."
    new "Ja, es wäre gut, es jetzt zu versuchen."

    # say L1447 lin
    old "[pla], Gomory seemed to be the one that had a better grasp of the spell yesterday."
    new "[pla], Gomory schien gestern besser den Dreh rauszuhaben."

    # say L1448 lin
    old "So you and her go find her host, while I keep working with Mildret and Devonne."
    new "Dann gehst du mit ihr zu ihrem Wirt, während ich weiter mit Mildret und Devonne arbeite."

    # say L1449 pla
    old "Ok, so what's the idea? What should we do?"
    new "Ok, und was ist der Plan? Was sollen wir machen?"

    # say L1450 lin
    old "You just have to take her to where her host is."
    new "Du musst sie nur zu ihrem Wirt bringen."

    # say L1451 lin
    old "And see that everything goes well while she performs the spell."
    new "Und sicherstellen, dass alles gut läuft, während sie den Zauber wirkt."

    # say L1452 lin
    old "As long as you're with her there shouldn't be a problem."
    new "Solange du bei ihr bist, sollte alles gut gehen."

    # say L1453 pla
    old "Hmph, I see..."
    new "Hmpf, ich verstehe..."

    # say L1454 pla
    old "Ok, I get it. Then let's go to where she is. Come with me Gomory."
    new "Okay, ich hab's kapiert. Dann lass uns zu ihr gehen. Komm mit mir, Gomory."

    # say L1463 gom
    old "Who is going to be my host?"
    new "Wer wird mein Gastgeber sein?"

    # say L1464 pla
    old "She's a friend of mine, her name is Belle, I think we should try with her first."
    new "Sie ist eine Freundin von mir, ihr Name ist Belle, ich denke, wir sollten es zuerst mit ihr versuchen."

    # say L1478 pla
    old "Ok, we found her. What do you need to get in her body?"
    new "Okay, wir haben sie gefunden. Was brauchst du, um in ihren Körper zu kommen?"

    # say L1479 gom
    old "Not much really, all we need is for her to be relaxed for a moment, and I'll canalize the spell."
    new "Nicht viel, wir brauchen nur, dass sie sich für einen Moment entspannt, und ich kanalisiere den Zauber."

    # say L1480 pla
    old "Hmm, ok, so it should be fine if we're just talking, right?"
    new "Hmm, ok, dann sollte es reichen, wenn wir einfach reden, oder?"

    # say L1481 gom
    old "That's right, it doesn't take more than a few seconds."
    new "Das stimmt, es dauert nicht länger als ein paar Sekunden."

    # say L1482 pla
    old "Ok, I think I got it. I'll go there and talk to her for a moment, you wait here for a minute."
    new "Ok, ich glaube, ich hab's kapiert. Ich geh da hin und rede kurz mit ihr, du wartest hier eine Minute."

    # say L1483 pla
    old "Then you come close. And the person that you see me talking to it's who you do the spell on, ok?"
    new "Dann kommst du näher. Und die Person, mit der ich rede, ist die, auf die du den Zauber wirfst, okay?"

    # say L1485 gom
    old "That's very simple, sounds good, let's do it."
    new "Das ist sehr einfach, klingt gut, machen wir es so."

    # say L1486 pla
    old "Ok, I'll there then."
    new "Okay, ich bin dann da."

    # say L1502 bel
    old "Oh! [pla] Hi!"
    new "Oh! [pla] Hallo!"

    # say L1504 pla
    old "I'm ok. Hey listen, I wanted to talk to you about something Miss Mia said in class."
    new "Ich bin okay. Hör mal, ich wollte mit dir über was reden, das Miss Mia im Unterricht gesagt hat."

    # say L1505 bel
    old "Sure, tell me. What is it?"
    new "Klar, erzähl mir. Was ist los?"

    # say L1515 rub
    old "HA! Who do we have here? Piglet and the loser."
    new "HA! Wen haben wir denn da? Ferkel und den Verlierer."

    # say L1516 rub
    old "What happened to your ears Piglet? Afraid they were talking too much attention from that flat nose?"
    new "Was ist mit deinen Ohren passiert, Ferkel? Hattest Angst, sie lenken zu viel Aufmerksamkeit von dieser flachen Nase ab?"

    # say L1517 bel
    old "Oh for God's sake!"
    new "Oh Gott nochmal!"

    # say L1518 bel
    old "Listen, dumbass, I'm not in the mood for your shit today! So fuck off!"
    new "Hör zu, Idiot, ich hab heute echt keine Lust auf deinen Scheiß! Also verpiss dich!"

    # say L1524 rub
    old "And what crawled up her that she's this angry?"
    new "Und was ist ihr denn so den Arsch aufgerissen, dass sie so wütend ist?"

    # say L1526 rub
    old "Honestly, you can't say anything to people because they get their panties in a bunch."
    new "Ehrlich, man kann den Leuten heutzutage gar nichts mehr sagen, weil sie sofort die Nerven verlieren."

    # say L1527 pla
    old "What are you talking about? You just insulted her!"
    new "Wovon redest du? Du hast sie gerade beleidigt!"

    # say L1528 pla
    old "Don't you ever get tired of talking like that to people?"
    new "Wirst du nie müde, so mit Leuten zu reden?"

    # say L1529 rub
    old "What, who do you think you're talking to?"
    new "Was, mit wem redest du überhaupt?"

    # say L1530 rub
    old "Listen loser, I don't care what you have to say, so why don't you get lost?"
    new "Hör zu, Verlierer, mir ist es egal, was du zu sagen hast, also verschwinde doch einfach."

    # say L1531 pla
    old "Yeah, whatever, who would want to deal with you?"
    new "Ja, genau, wer würde sich schon mit dir abgeben wollen?"

    # say L1538 pla
    old "Oh no!"
    new "Oh nein!"

    # say L1539 rub
    old "Yeah! You shouldn't have messed with me you little brat!"
    new "Ja! Du hättest mich nicht provozieren sollen, du kleiner Rotz!"

    # say L1540 pla
    old "Wait! Wait! Stop!"
    new "Warte! Warte! Stopp!"

    # say L1541 rub
    old "Stop? After you insulted me? You better be ready for what you have coming your way!"
    new "Stopp? Nachdem du mich beleidigt hast? Du solltest besser bereit sein für das, was auf dich zukommt!"

    # say L1542 pla
    old "No, no, no, no, it's not her, it's not her."
    new "Nein, nein, nein, nein, es ist nicht sie, es ist nicht sie."

    # say L1543 rub
    old "W- What??"
    new "W- Was??"

    # say L1550 pla
    old "Ooh shit!"
    new "Ooh Scheiße!"

    # say L1551 pla
    old "Damn, what do I do now? This wasn't supposed to happen!"
    new "Verdammt, was mache ich jetzt? Das sollte doch nicht passieren!"

    # say L1553 gomRub
    old "Hey, I did it! It worked! Linett is a genius!"
    new "Hey, ich hab's geschafft! Es hat funktioniert! Linett ist ein Genie!"

    # say L1554 pla
    old "Devonne? Is that you?"
    new "Devonne? Bist du das?"

    # say L1555 gomRub
    old "It is! It worked! We did it [pla]!"
    new "Es ist! Es hat funktioniert! Wir haben es geschafft [pla]!"

    # say L1556 pla
    old "No, we didn't! You got the wrong person!"
    new "Nein, haben wir nicht! Du hast die Falsche erwischt!"

    # say L1557 pla
    old "It was supposed to be the other girl I was talking with!"
    new "Es sollte die andere Frau sein, mit der ich gesprochen habe!"

    # say L1558 gomRub
    old "Well, you should have said something, I did what you told me to."
    new "Na ja, du hättest was sagen sollen, ich hab getan, was du mir gesagt hast."

    # say L1559 gomRub
    old "I waited for a minute and get into the person I saw you talking with."
    new "Ich habe eine Minute gewartet und bin in die Person eingestiegen, mit der ich dich reden sah."

    # say L1561 pla
    old "Well, the point is you're in the wrong body. You're gonna have to get out of there."
    new "Na ja, der Punkt ist, du bist im falschen Körper. Du musst da rauskommen."

    # say L1562 gomRub
    old "Ok, but you know what's the only possible one way."
    new "Okay, aber du weißt, dass es nur einen möglichen Weg gibt."

    # say L1563 pla
    old "Ohhh right... Oh my God... I have to do it with Ruby... Fuck!"
    new "Ohhh stimmt... Oh Gott... Ich muss es mit Ruby machen... Scheiße!"

    # say L1564 gomRub
    old "Well, it could be just a blowjob... it works too..."
    new "Na ja, es könnte auch einfach ein Blowjob sein... das funktioniert auch."

    # say L1565 pla
    old "I know, I know. Look, we can't do that here. So let's go somewhere else before anyone notices us speaking."
    new "Ich weiß, ich weiß. Schau, wir können das hier nicht machen. Lass uns woanders hingehen, bevor uns jemand bemerkt."

    # say L1574 oli
    old "Hey Ruby, so here this is where you've been. Hey listen, I've been thinking about our..."
    new "Hey Ruby, das ist also hier, wo du die ganze Zeit warst. Hör zu, ich hab über uns nachgedacht..."

    # say L1576 oli
    old "And what do we have here? If it is the captain of the nerd club."
    new "Und was haben wir hier? Wenn es nicht der Captain des Nerd-Clubs ist."

    # say L1577 oli
    old "What are you doing here nerd? Looking for better company than your loser friends"
    new "Was machst du hier, Nerd? Suchst du bessere Gesellschaft als deine Verliererfreunde?"

    # say L1579 pla
    old "Yeah, sure... That's right, I'm trying to become friends with Ruby. Right, Ruby?"
    new "Klar, sicher... Stimmt, ich versuche, mit Ruby befreundet zu werden. Stimmt's, Ruby?"

    # say L1586 gomRub
    old "Ohh... Yeah, that's right, he and I are very good friends heh."
    new "Ohh... Ja, genau, wir sind sehr gute Freunde, hehe."

    # say L1587 pla
    old "(Oh my God...)"
    new "Oh mein Gott..."

    # say L1588 oli
    old "W- what? What are you saying ruby?"
    new "W-was? Was redest du da, Ruby?"

    # say L1589 oli
    old "Do you feel ok? Did this nerd do anything to you?"
    new "Geht es dir gut? Hat dieser Nerd dir was getan?"

    # say L1590 pla
    old "Hey, I haven't done anything."
    new "Hey, ich hab nichts gemacht."

    # say L1591 pla
    old "We're just talking about homework... S- she wants me to do her homework..."
    new "Wir reden nur über Hausaufgaben... S- sie will, dass ich ihre Hausaufgaben mache..."

    # say L1592 oli
    old "Is that true Ruby?"
    new "Ist das wahr, Ruby?"

    # say L1594 gomRub
    old "Uhh, yes, yes! It's true, he's helping me with... Something."
    new "Uhh, ja, ja! Es stimmt, er hilft mir bei... Etwas."

    # say L1595 pla
    old "Anyway, I think we need to go look for some books. You know, for that homework... We better leave."
    new "Jedenfalls, ich glaube, wir müssen uns auf die Suche nach ein paar Büchern machen. Du weißt schon, für die Hausaufgaben... Wir sollten besser gehen."

    # say L1596 gomRub
    old "Yeah! I think we need to leave."
    new "Ja! Ich denke, wir müssen gehen."

    # say L1601 gomRub
    old "Goodbye human friend! It was good to talk to you, I'll see you later."
    new "Tschüss, menschlicher Freund! Es war schön, mit dir zu reden, bis später."

    # say L1622 pla
    old "Ok, I think we'll be safe here. It's almost class time, nobody's going to come."
    new "Okay, ich denke, wir sind hier sicher. Es ist fast Unterrichtszeit, da kommt niemand mehr."

    # say L1623 gomRub
    old "It's incredible, I have soo much control, I didn't know this was possible."
    new "Das ist unglaublich, ich habe so viel Kontrolle, ich wusste nicht, dass das möglich ist."

    # say L1624 pla
    old "So, you're feeling ok?"
    new "Alles klar, du fühlst dich gut?"

    # say L1625 gomRub
    old "That's right! I feel in complete control, it's almost as if this was my real body."
    new "Stimmt! Ich fühle mich vollkommen im Griff, als wäre das mein echter Körper."

    # say L1626 pla
    old "Ok, that's good. At least you didn't start twitching in the middle of the hallway, that would have given us up."
    new "Okay, das ist gut. Wenigstens hast du nicht mitten im Flur angefangen zu zucken, das hätte uns verraten."

    # say L1627 pla
    old "Which, by the way, you almost did when Olivia got there. Thank God she's not very smart."
    new "Das hättest du fast getan, als Olivia da war. Gott sei Dank ist sie nicht besonders schlau."

    # say L1628 gomRub
    old "Oh yes, who was that girl? She was friendly!"
    new "Oh ja, wer war dieses Mädchen? Sie war freundlich!"

    # say L1629 pla
    old "Hmm, that's the last thing I would call her. She's the best friend of Ruby, the... Uhhh, owner of this body."
    new "Hmm, das Letzte, was ich sie nennen würde. Sie ist die beste Freundin von Ruby, der... Uhhh, Besitzerin dieses Körpers."

    # say L1631 gomRub
    old "So that could have been a lot closer..."
    new "Dann hätten wir viel näher dran sein können..."

    # say L1632 pla
    old "Well, this is the problem with using the wrong body."
    new "Das ist das Problem, wenn man den falschen Körper benutzt."

    # say L1633 pla
    old "But anyway, can you leave that body before someone else notices how weird you're acting?"
    new "Aber egal, kannst du dieses Körper verlassen, bevor jemand merkt, wie seltsam du dich benimmst?"

    # say L1635 gomRub
    old "I want to get out, but I'm going to need your help."
    new "Ich will raus, aber ich brauche deine Hilfe."

    # say L1637 pla
    old "Yeah, right, I remember..."
    new "Klar, ich erinnere mich..."

    # say L1638 pla
    old "We need to do this quick."
    new "Wir müssen das schnell machen."

    # say L1647 gomRub
    old "Ok, I've been waiting for this since I took over this body"
    new "Ok, ich habe schon darauf gewartet, seit ich diesen Körper übernommen habe."

    # say L1649 gomRub
    old "Well, I knew we had to do this for me to leave my host's body."
    new "Na ja, ich wusste, dass wir das machen müssen, damit ich den Körper meines Wirts verlassen kann."

    # say L1650 gomRub
    old "And I've been wanting to taste this cock for a while."
    new "Und ich hab schon lange darauf gewartet, diesen Schwanz zu schmecken."

    # say L1651 pla
    old "Uh... yeah, sure, remember we can't take much time."
    new "Klar, aber wir sollten uns beeilen, okay?"

    # say L1652 gomRub
    old "I know, I know, this will be quick."
    new "Ich weiß, ich weiß, das wird schnell gehen."

    # say L1662 pla
    old "Are you ok? Did everything work?"
    new "Alles klar? Hat alles funktioniert?"

    # say L1663 gom
    old "Oh yeah, I'm perfect, and she didn't feel anything."
    new "Oh ja, ich bin perfekt, und sie hat gar nichts gespürt."

    # say L1664 pla
    old "Oh shit! That's right, if we don't clean her up, she's gonna wake up and realize what happened."
    new "Oh Scheiße! Du hast Recht, wenn wir sie nicht sauber machen, wacht sie auf und merkt, was passiert ist."

    # say L1665 pla
    old "Come, help me clean her up, bring her to the toilet and get out of here."
    new "Komm, hilf mir sie zu reinigen, bring sie aufs Klo und lass uns hier verschwinden."

    # say L1677 pla
    old "Ok, now let's go. We have to tell the others about how this went."
    new "Ok, jetzt los. Wir müssen den anderen erzählen, wie es gelaufen ist."

    # say L1695 rub
    old "Ugh, what happened?"
    new "Ugh, was ist passiert?"

    # say L1696 rub
    old "I can't remember anything. Why am I in the school bathroom?"
    new "Ich kann mich an nichts erinnern. Warum bin ich im Schulbadezimmer?"

    # say L1697 rub
    old "Ugh, did I fall asleep in the toilet?"
    new "Ugh, bin ich im Toilettenraum eingeschlafen?"

    # say L1698 rub
    old "And what is this taste in my mouth?"
    new "Und was ist dieser Geschmack in meinem Mund?"

    # say L1699 rub
    old "It's like a salty smoothie. Ughh, disgusting."
    new "Es schmeckt wie ein salziger Smoothie. Ughh, ekelig."

    # say L1700 rub
    old "And what is that smell? It smells like... dick?"
    new "Und was ist das für ein Geruch? Riecht nach... Schwanz?"

    # say L1701 rub
    old "I bet some loser was jerking off in the women's bathroom!"
    new "Ich wette, irgendein Versager hat im Damenwaschraum abgespritzt!"

    # say L1702 rub
    old "Pathetic, I bet it was one of those losers that hangs out with Piglet."
    new "Pf, ich wette, es war einer von diesen Losern, die mit Würstchen abhängen."

    # say L1703 rub
    old "I'll give them a piece of my mind next time I see them."
    new "Ich werde ihnen meine Meinung sagen, wenn ich sie das nächste Mal sehe."

    # say L1737 lin
    old "Hey guys, how did it go?"
    new "Hey Leute, wie war's?"

    # say L1738 pla
    old "Terrible! Gomory got in the wrong body, so we don't know if it's going to work with Belle."
    new "Schrecklich! Gomory ist im falschen Körper gelandet, also wissen wir nicht, ob es bei Belle funktionieren wird."

    # say L1739 lin
    old "What? What happened?"
    new "Was? Was ist passiert?"

    # say L1740 gom
    old "There was a confusion when I was about to perform the spell, and I accidentally jumped in the wrong person."
    new "Es gab eine Verwechslung, als ich den Zauber wirken wollte, und ich bin versehentlich in die Falsche gesprungen."

    # say L1741 gom
    old "So I ended up controlling her instead."
    new "Dann habe ich sie stattdessen kontrolliert."

    # say L1742 dev
    old "But did it work? I mean controling that body?"
    new "Aber hat es funktioniert? Ich meine, die Kontrolle über den Körper?"

    # say L1743 gom
    old "It did! Perfectly! I had no trouble getting inside her. And once I did I had total control over her body."
    new "Es hat funktioniert! Perfekt! Ich hatte keine Probleme, in sie zu kommen. Und sobald ich drin war, hatte ich vollste Kontrolle über ihren Körper."

    # say L1744 lin
    old "That's great! So we know you can do it too!"
    new "Das ist toll! Dann können wir ja auch damit rechnen, dass es bei dir klappt!"

    # say L1745 pla
    old "Yeah well, we almost got caught though."
    new "Ja, aber wir sind fast erwischt worden."

    # say L1746 lin
    old "Oh, I think you're making too much fuzz."
    new "Oh, ich denke, du machst zu viel daraus."

    # say L1747 lin
    old "What's important is that it can be replicated."
    new "Wichtig ist, dass es reproduzierbar ist."

    # say L1748 pla
    old "Hmm I think so..."
    new "Hmm, ich denke schon..."

    # say L1749 lin
    old "Ok, we can say that was a success."
    new "Ok, dann können wir das als Erfolg verbuchen."

    # say L1750 lin
    old "All right, then, we should keep training the spell with Devonne and Mildret, so they get ready for her practice."
    new "Okay, dann sollten wir weiter mit Devonne und Mildret üben, damit sie sich auf ihre Praxis vorbereiten können."

    # say L1751 lin
    old "You can go and keep working on the church meanwhile [pla]."
    new "Du kannst in der Zwischenzeit weiter an der Kirche arbeiten [pla]."

    # say L1753 pla
    old "Alright, I'll keep working there."
    new "Okay, ich werde da weitermachen."

    # say L1754 lin
    old "Perfect, go do that, and I'll meet you whenever they are ready."
    new "Perfekt, mach das und ich treffe dich, wann immer sie bereit sind."

    # say L1756 pla
    old "Bye girls, good luck with the training."
    new "Tschüss Mädels, viel Glück bei der Trainingseinheit."

    # say L1757 dev
    old "Thank you, see you later."
    new "Danke, bis später."

    # say L1773 lin
    old "Hey [pla], good morning. Ready for the next practice with the shinigamis?"
    new "Hey [pla], guten Morgen. Bereit für die nächste Übung mit den Shinigami?"

    # say L1774 pla
    old "Hey Linet, yeah sure, I was thinking about what went wrong with Devonne."
    new "Hey Linet, klar, ich hab überlegt, was bei Devonne schiefgelaufen ist."

    # say L1775 pla
    old "This time I have an idea to ensure it's done with the right person."
    new "Dieses Mal hab ich eine Idee, um sicherzustellen, dass es mit der Richtigen klappt."

    # say L1776 lin
    old "Sure, whatever you need. Let's go."
    new "Klar, was immer du brauchst. Lass uns gehen."

    # say L1804 gom
    old "Hi, good morning."
    new "Hi, guten Morgen."

    # say L1805 lin
    old "Ok, given the advances she made yesterday, I think Gomory is the one that should go with you today."
    new "Okay, nachdem sie gestern so vorwitzig war, denke ich, Gomory sollte heute mit dir gehen."

    # say L1806 lin
    old "I still have a couple of things to train with Mildret, but you two go ahead and practice."
    new "Ich hab noch ein paar Dinge mit Mildret zu üben, aber ihr zwei könnt schon mal loslegen und üben."

    # say L1807 lin
    old "And this time please try and do it in the right body [pla]. We don't want to call attention to ourselves."
    new "Und diesmal bitte im richtigen Körper [pla]. Wir wollen ja nicht auffallen."

    # say L1808 pla
    old "Yeah, sure, I'll be more careful."
    new "Klar, ich passe besser auf."

    # say L1809 pla
    old "Are you ready Devonne?"
    new "Bist du bereit, Devonne?"

    # say L1810 dev
    old "I am."
    new "Ich bin bereit."

    # say L1811 pla
    old "Ok, then let's go."
    new "Okay, dann lass uns gehen."

    # say L1826 pla
    old "Ok, so, are you sure you're clear on the process?"
    new "Okay, bist du dir sicher, dass du den Prozess verstehst?"

    # say L1827 dev
    old "I am, I know it completely."
    new "Ich bin mir sicher, ich kenne es komplett."

    # say L1828 pla
    old "Ok then, come on, let's find Billie."
    new "Okay dann, komm, lass uns Billie finden."

    # say L1842 pla
    old "Ok, we found her."
    new "Ok, wir haben sie gefunden."

    # say L1843 pla
    old "Listen, to avoid confusion like what happened with Gomory."
    new "Hör zu, um Verwirrung wie bei Gomory zu vermeiden."

    # say L1844 pla
    old "I'll go and talk to her, and convince her to go with me to the classroom."
    new "Ich geh und rede mit ihr und überzeuge sie, mit mir ins Klassenzimmer zu kommen."

    # say L1845 pla
    old "You wait here and when you see me going inside, you can go and get inside the body the girl who is with me at that moment."
    new "Warte hier und wenn du mich reingehen siehst, kannst du dann in den Körper des Mädchens schlüpfen, das gerade bei mir ist."

    # say L1846 pla
    old "Is everything clear?"
    new "Alles klar?"

    # say L1847 dev
    old "Yes, don't worry, that's very simple actually."
    new "Ja, mach dir keine Sorgen, das ist eigentlich ganz einfach."

    # say L1848 pla
    old "Ok, glad to hear that, let's do it then."
    new "Ok, das freut mich zu hören, dann machen wir es doch."

    # say L1859 pla
    old "Hey Billie, how are you?"
    new "Hey Billie, wie geht's dir?"

    # say L1860 bil
    old "Hey [pla], what's up?"
    new "Hey [pla], was ist los?"

    # say L1861 pla
    old "Not much, I just wanted to ask you something."
    new "Nicht viel, ich wollte dich nur was fragen."

    # say L1862 bil
    old "Oh yeah? What is it?"
    new "Oh ja? Was ist es?"

    # say L1873 mia
    old "Honestly, you're such a bad student already and you still take the luxury of skipping classes."
    new "Ehrlich gesagt, Sie sind schon so ein schlechter Schüler und nehmen sich noch die Freiheit, Unterricht zu schwänzen."

    # say L1874 pla
    old "Uh, Miss Mia, I- I can explain..."
    new "Uh, Miss Mia, ich- ich kann das erklären..."

    # say L1876 mia
    old "I don't need you to explain anything!"
    new "Ich brauche keine Erklärungen von Ihnen!"

    # say L1877 mia
    old "A bad student is a bad student. That's it, but not only do you skip classes."
    new "Ein schlechter Schüler ist ein schlechter Schüler. Das ist es, aber Sie schwänzen nicht nur die Kurse."

    # say L1878 mia
    old "You're also here being a bad influence for Billie."
    new "Sie sind auch hier, um ein schlechtes Vorbild für Billie zu sein."

    # say L1879 mia
    old "I won't let you do that."
    new "Ich werde das nicht zulassen."

    # say L1880 mia
    old "Come with me to the classroom!"
    new "Kommen Sie mit mir ins Klassenzimmer!"

    # say L1881 pla
    old "W- Wha-?"
    new "W- Was?"

    # say L1882 pla
    old "B- but, I'm talking with Billie."
    new "B- aber, ich rede gerade mit Billie."

    # say L1885 pla
    old "I- it's important..."
    new "Es ist wichtig..."

    # say L1886 mia
    old "Please, what could someone like you to tell her that's important."
    new "Bitte, was könnte jemand wie Sie ihr denn Wichtiges zu sagen haben."

    # say L1887 mia
    old "Now, don't make me repeat myself again, GO TO THE CLASSROOM NOW!"
    new "Jetzt machen Sie mich nicht noch einmal wiederholen, Gehen Sie sofort ins Klassenzimmer!"

    # say L1894 bil
    old "Don't worry, we can talk later [pla]."
    new "Keine Sorge, wir können später reden [pla]."

    # say L1895 pla
    old "{alpha=0.8}{i}*Sigh*{/i}{/alpha} Oh fuck..."
    new "{alpha=0.8}{i}*Seufz*{/i}{/alpha} Oh Scheiße..."

    # say L1914 mia
    old "Listen, I don't want you contaminating the minds of other students with your bad behaviour."
    new "Hören Sie, ich will nicht, dass Sie mit Ihrem schlechten Benehmen die Köpfe der anderen Schüler vergiften."

    # say L1915 mia
    old "Especially someone that just arrived at the school like Miss Billie."
    new "Besonders jemand, der gerade erst an die Schule gekommen ist wie Miss Billie."

    # say L1916 mia
    old "So you better stay away from here."
    new "Dann bleib besser von hier fern."

    # say L1923 pla
    old "No no no! Wait!"
    new "Nein nein nein! Warte!"

    # say L1924 mia
    old "What did you just say to me?"
    new "Was haben Sie mir gerade gesagt?"

    # say L1926 mia
    old "Does that mean you're going to ignore what I told you?"
    new "Das bedeutet also, dass Sie das, was ich Ihnen gesagt habe, ignorieren werden?"

    # say L1928 pla
    old "No! she is not the girl!"
    new "Nein! Sie ist nicht das Mädchen!"

    # say L1929 mia
    old "DON'T THINK YOU CAN JUST DO WHAT YOU WANT!"
    new "DENKEN SIE NICHT, DASS SIE EINFACH TUN KÖNNEN, WAS SIE WOLLEN!"

    # say L1935 pla
    old "Oh fuck!"
    new "Oh Scheiße!"

    # say L1937 devMia
    old "Wow! That was a lot easier than I thought it would be!"
    new "Wow! Das war viel einfacher, als ich dachte!"

    # say L1938 devMia
    old "The sensations... are so weird! I feel... Heavy."
    new "Die Empfindungen... sind so seltsam! Ich fühle mich... schwer."

    # say L1939 devMia
    old "But not in a bad way. You know?"
    new "Aber nicht auf eine schlechte Art. Verstehst du?"

    # say L1942 pla
    old "Yeah ok, cool."
    new "Klar, cool."

    # say L1943 pla
    old "But listen, this wasn't supposed to happen."
    new "Aber hör zu, das sollte nicht passieren."

    # say L1945 devMia
    old "It wasn't?"
    new "War es nicht?"

    # say L1946 pla
    old "No, not at all. This is not the person that's going to be your host for the ritual."
    new "Nein, überhaupt nicht. Das ist nicht die Person, die dein Gastgeber für den Ritual sein soll."

    # say L1947 devMia
    old "Well, I did what you told me to. You're not very good at doing these plans you know?"
    new "Na toll, ich hab getan, was du gesagt hast. Du bist echt nicht gut darin, diese Pläne zu machen, weißt du?"

    # say L1949 pla
    old "God, why does this keep happening to me?!"
    new "Verdammt, warum passiert mir das immer wieder?!"

    # say L1950 pla
    old "Anyway, you have to get out of that body."
    new "Jedenfalls, du musst aus diesem Körper rauskommen."

    # say L1951 devMia
    old "I'll do it gladly."
    new "Ich mache das gerne."

    # say L1952 devMia
    old "But, I would need your help..."
    new "Aber ich bräuchte deine Hilfe..."

    # say L1953 pla
    old "Yeah, yeah I know..."
    new "Ja, ja, ich weiß..."

    # say L1959 devMia
    old "Linett said that receiving magic feels a lot different in a human body."
    new "Linett hat gesagt, dass das Empfangen von Magie sich in einem menschlichen Körper ganz anders anfühlt."

    # say L1960 devMia
    old "Let's see if it's true."
    new "Lass es uns ausprobieren."

    # say L1961 pla
    old "Sure, but we better be quick."
    new "Klar, aber wir sollten uns beeilen."

    # say L1962 devMia
    old "Yeah, yeah."
    new "Ja, ja."

    # say L1963 devMia
    old "Doing it with a human body, so exciting!"
    new "Das ist ja aufregend, mit einem menschlichen Körper zu ficken."

    # say L1964 devMia
    old "And i bet it's even going to be better with that big cock of yours."
    new "Und ich wette, es wird noch besser mit deinem großen Schwanz."

    # say L1965 devMia
    old "Now... let's try this."
    new "Jetzt... lass uns das ausprobieren."

    # say L1980 pla
    old "Now let's get out of here."
    new "Jetzt lass uns hier verschwinden."

    # say L1981 pla
    old "We need to report back to Linett and the others."
    new "Wir müssen Linett und den anderen Bericht erstatten."

    # say L1982 dev
    old "Sure, right behind you."
    new "Natürlich, ich folge Ihnen."

    # say L1999 mia
    old "Why was I on the floor?"
    new "Warum war ich auf dem Boden?"

    # say L2000 mia
    old "All I can remember is that I was talking and everything went black."
    new "Alles, woran ich mich erinnern kann, ist, dass ich geredet habe und dann alles schwarz wurde."

    # say L2001 mia
    old "Ugh! Who was I talking with?"
    new "Ugh! Mit wem habe ich gesprochen?"

    # say L2032 lin
    old "Hey guys! How did it go?"
    new "Hey Leute! Wie war’s?"

    # say L2033 lin
    old "Did you manage to do it right this time?"
    new "Habt ihr es dieses Mal richtig hinbekommen?"

    # say L2034 pla
    old "Hmm, not exactly."
    new "Hmm, nicht wirklich."

    # say L2035 lin
    old "What do you mean, the spell didn't work?"
    new "Was meinst du, der Zauber hat nicht funktioniert?"

    # say L2036 dev
    old "Oh, not that, it worked perfectly."
    new "Oh, nicht das, es hat perfekt funktioniert."

    # say L2037 pla
    old "It's just that she didn't go into the right body."
    new "Es ist nur, dass sie in den falschen Körper gekommen ist."

    # say L2038 lin
    old "Oh, again? You know [pla] you should really work on your plans."
    new "Oh, wieder mal? Du weißt [pla] du solltest echt an deinen Plänen arbeiten."

    # say L2039 lin
    old "We don't want you to ruin it on the big day."
    new "Wir wollen nicht, dass du es am großen Tag versaust."

    # say L2040 pla
    old "Yeah, sure."
    new "Klar, sicher."

    # say L2042 lin
    old "But other than that, how did it go? How did you feel?"
    new "Aber abgesehen davon, wie war es? Wie hast du dich gefühlt?"

    # say L2044 dev
    old "It was amazing! You had told me it worked, but this was unexpected."
    new "Es war unglaublich! Du hattest mir gesagt, dass es funktioniert, aber das war unerwartet."

    # say L2045 dev
    old "Human bodies feel so different!"
    new "Menschliche Körper fühlen sich so anders!"

    # say L2046 lin
    old "Well, if everything goes well, you'll have a chance soon."
    new "Na, wenn alles gut geht, hast du bald die Gelegenheit."

    # say L2047 lin
    old "As for you [pla], I still have some things to work out with Mildret, why don't you keep working on the church?"
    new "Was dich angeht [pla], ich muss noch ein paar Dinge mit Mildret klären, warum arbeitest du nicht weiter an der Kirche?"

    # say L2048 lin
    old "And I'll contact you when it's time for the next practice."
    new "Und ich melde mich, wenn es Zeit für die nächste Probe ist."

    # say L2050 pla
    old "Sure, then I'll see you later."
    new "Klar, dann sehen wir uns später."

    # say L2066 lin
    old "Hey [pla], today's the last practice day. I hope you're ready."
    new "Hey [pla], heute ist der letzte Tag für die Übung. Ich hoffe, du bist bereit."

    # say L2067 pla
    old "Good morning Linett; yeah sure, I'm ready to do this."
    new "Guten Morgen Linett, ja klar, ich bin bereit dafür."

    # say L2068 lin
    old "Ok, let's go see the girls then..."
    new "Okay, dann lass uns zu den Mädels gehen..."

    # say L2096 dev
    old "Hii, we're fine, how are you?"
    new "Hii, wir sind gut, wie geht's dir?"

    # say L2097 pla
    old "I'm ok, thanks."
    new "Ich bin okay, danke."

    # say L2098 lin
    old "Today is the last practice day."
    new "Heute ist der letzte Übungstag."

    # say L2099 lin
    old "[pla] I've been working with Mildret on perfecting the spell, and she finally learned it."
    new "[pla] Ich habe mit Mildret an dem Zauber gearbeitet, und sie hat ihn endlich gelernt."

    # say L2100 lin
    old "So take her with you to where her host is and try it."
    new "Dann nimm sie mit zu ihrem Wirt und probier es aus."

    # say L2102 pla
    old "Sure, no problem, are you ready Mildret?"
    new "Klar, kein Problem, bist du bereit, Mildret?"

    # say L2104 lin
    old "Great, do ahead and let me know how everything goes."
    new "Super, mach voran und lass mich wissen, wie es läuft."

    # say L2117 pla
    old "Ok, so the last two previous attempts have failed because of confusion and bad timing."
    new "Okay, die letzten beiden Versuche sind gescheitert, weil es zu Verwirrung und schlechter Timing kam."

    # say L2118 pla
    old "So this time, I brought a picture with me."
    new "Dann hab ich dieses Mal ein Bild mitgebracht."

    # say L2122 pla
    old "This is the person that you're gonna get inside."
    new "Das ist die Person, in die du reinkommst."

    # say L2123 pla
    old "Make sure you memorize her face, so this time won't happen as before."
    new "Stell dir ihr Gesicht gut ein, damit es dieses Mal nicht wie beim letzten Mal läuft."

    # say L2128 mil
    old "Ok, I'll make sure to remember this face, where can we find her?"
    new "Okay, ich werd's mir merken, wo finden wir sie?"

    # say L2129 pla
    old "She should be at her house, let's go."
    new "Sie sollte bei ihr zu Hause sein, lass uns gehen."

    # say L2141 jad
    old "Oh, hello [pla]. It's been quite a while, how are you?"
    new "Oh, hallo [pla]. Es ist ja schon eine Weile her, wie geht es dir?"

    # say L2142 pla
    old "I'm fine Mrs. Jade, thank you."
    new "Ich bin gut, Frau Jade, danke."

    # say L2143 jad
    old "Are you here looking for Hinn?"
    new "Suchst du Hinn?"

    # say L2144 pla
    old "I am, I have to talk to her about our school project."
    new "Ja, ich muss mit ihr über unser Schulprojekt reden."

    # say L2145 jad
    old "Oh, but you see, she's not in at the moment."
    new "Oh, aber du siehst, sie ist im Moment nicht da."

    # say L2146 jad
    old "I think she went out with your friend Belle."
    new "Ich glaube, sie ist mit deiner Freundin Belle ausgegangen."

    # say L2147 jad
    old "If you want to, you can come back later when she arrives."
    new "Wenn du willst, kannst du später noch mal vorbeikommen, wenn sie da ist."

    # say L2148 pla
    old "I guess I'll have to..."
    new "Ich schätze, ich muss..."

    # say L2162 pla
    old "Nooo, not again! Damn it!"
    new "Nooo, nicht schon wieder! Scheiße!"

    # say L2163 milJad
    old "It worked! I can't believe Linett was right."
    new "Es hat funktioniert! Ich kann es nicht glauben, dass Linett recht hatte."

    # say L2164 pla
    old "Hmph, yeah fine, that's very good and all. But you're in the wrong body!"
    new "Hmpf, ja toll, das ist alles sehr gut und schön. Aber du bist im falschen Körper!"

    # say L2165 milJad
    old "But I got in the body you told me to, I even had the picture and all."
    new "Aber ich bin in den Körper gekommen, den du mir gesagt hast, ich hatte sogar das Bild dabei."

    # say L2166 pla
    old "Well, that's not her. The body you got into it's her mother."
    new "Na, das ist nicht sie. Der Körper, in den du gefahren bist, ist ihre Mutter."

    # say L2167 milJad
    old "Well that's not my fault, they look identical!"
    new "Das ist ja nicht meine Schuld, die sehen sich identisch!"

    # say L2168 milJad
    old "I mean, all you humans are very similar to begin with, how was I supposed to know which is which?"
    new "Ich meine, ihr Menschen seid sowieso alle sehr ähnlich, wie sollte ich da wissen, welche von euch welche ist?"

    # say L2169 pla
    old "I can't believe this is happening again."
    new "Ich kann es nicht fassen, dass das wieder passiert."

    # say L2170 pla
    old "Well anyway, let's get you out of that body quickly, I don't know when Hinn could come back home."
    new "Na ja, lass uns schnell aus diesem Körper rauskommen, ich weiß nicht, wann Hinn wieder nach Hause kommen könnte."

    # say L2172 milJad
    old "Sure, we already tested that I can do the spell, and it works how intended, let's not delay this any longer."
    new "Klar, wir haben den Zauber schon getestet, und er funktioniert wie gewollt, lass uns das nicht weiter hinauszögern."

    # say L2177 pla
    old "Uhh, A- Are you ok?"
    new "Uhh, Bist du in Ordnung?"

    # say L2178 pla
    old "You seem a little weird."
    new "Du wirkst ein bisschen komisch."

    # say L2179 milJad
    old "Me? Weird? Don't be foolish."
    new "Ich? Seltsam? Sei nicht albern."

    # say L2180 milJad
    old "We do this often, why would I be weird about receiving magic in a human body?"
    new "Wir machen das oft, warum sollte ich seltsam sein, wenn ich Magie in einem menschlichen Körper empfange?"

    # say L2182 pla
    old "Eh, well... I didn't say anything about that."
    new "Eh, na ja... Ich hab ja nichts dazu gesagt."

    # say L2183 pla
    old "But sure."
    new "Aber klar."

    # say L2184 milJad
    old "You're talking too much."
    new "Du redest zu viel."

    # say L2185 milJad
    old "Remember we can't waste any time on this."
    new "Erinnere dich, wir dürfen keine Zeit verschwenden."

    # say L2186 milJad
    old "Or the daughter of this body could come back and see us."
    new "Oder die Tochter dieses Körpers könnte zurückkommen und uns sehen."

    # say L2187 pla
    old "You're right."
    new "Du hast recht."

    # say L2200 pla
    old "Ok, we are done here, let's go."
    new "Okay, wir sind hier fertig, lass uns gehen."

    # say L2218 jad
    old "How did I fall asleep?"
    new "Wie bin ich eingeschlafen?"

    # say L2219 jad
    old "I can't even remember what I was doing..."
    new "Ich kann mich nicht mal mehr daran erinnern, was ich gemacht habe..."

    # say L2220 jad
    old "All I remember is I was talking to someone and then nothing."
    new "Alles, woran ich mich erinnere, ist, dass ich mit jemandem geredet habe und dann nichts mehr."

    # say L2221 jad
    old "Who was I talking to?"
    new "Wen habe ich da noch mal geredet?"

    # say L2254 lin
    old "Well? How did it go? Did you manage to do it?"
    new "Na? Wie war's? Hast du es geschafft?"

    # say L2255 pla
    old "You could say that..."
    new "Könnte man sagen..."

    # say L2256 pla
    old "But... you see, something happened."
    new "Aber... du siehst, es ist was passiert."

    # say L2257 pla
    old "And Mildret ended up in the wrong body again."
    new "Und Mildret landete wieder im falschen Körper."

    # say L2259 lin
    old "Amazing, you officially suck at this."
    new "Unglaublich, du bist echt schlecht darin."

    # say L2260 pla
    old "Hey! Those were accidents, it wasn't my fault."
    new "Hey! Das waren doch alles Unfälle, das war nicht meine Schuld."

    # say L2262 lin
    old "It's ok, your ineptitude hasn't cost us anything."
    new "Es ist okay, deine Unfähigkeit hat uns nichts gekostet."

    # say L2263 lin
    old "But enough about you [pla]."
    new "Aber genug von dir [pla]."

    # say L2264 lin
    old "I want to know how you felt, Mildret. What did you think of the spell?"
    new "Ich will wissen, wie du dich gefühlt hast, Mildret. Was hast du von dem Zauber gehalten?"

    # say L2265 lin
    old "Was it too difficult?"
    new "War es zu schwierig?"

    # say L2266 mil
    old "No, no, no, the opposite actually, it was very easy."
    new "Nein, nein, nein, im Gegenteil, es war sehr einfach."

    # say L2267 mil
    old "I must say I'm amazed at how good your spell is. The connection to the body is complete."
    new "Ich muss sagen, ich bin überrascht, wie gut dein Zauber ist. Die Verbindung zum Körper ist perfekt."

    # say L2269 dev
    old "Oh, it feels delicious, doesn't it?"
    new "Oh, es fühlt sich köstlich an, oder?"

    # say L2270 mil
    old "Hmph, I wouldn't say that."
    new "Hmph, ich würde das nicht so sagen."

    # say L2271 mil
    old "But it is true that the sensory experience is... Interesting."
    new "Aber es stimmt, dass die sensorische Erfahrung... interessant ist."

    # say L2272 lin
    old "Well, what's important is that now all of you have gotten to test the spell and see that it works."
    new "Na ja, wichtig ist, dass ihr jetzt alle den Zauber ausprobieren und sehen konntet, dass er funktioniert."

    # say L2273 lin
    old "That will make things easier to handle the day of the ritual."
    new "Das wird die Sache am Tag des Rituals einfacher machen."

    # say L2274 lin
    old "That makes me feel sure that there won't be any problem the day of the ritual."
    new "Das macht mich sicher, dass am Tag des Rituals alles glattgehen wird."

    # say L2275 lin
    old "But we're not done. Now that you know how to control bodies, we have to work on directing magic power."
    new "Aber wir sind noch nicht fertig. Jetzt, wo du weißt, wie man Körper kontrolliert, müssen wir uns auf die Lenkung von magischer Energie konzentrieren."

    # say L2276 pla
    old "Hey, does that mean that my work here is done?"
    new "Hey, bedeutet das, dass meine Arbeit hier erledigt ist?"

    # say L2277 lin
    old "It is, now we need you to focus on securing both the church and making sure the hosts are ready for the day of the ritual."
    new "Das ist es, jetzt musst du dich darauf konzentrieren, sowohl die Kirche zu sichern als auch sicherzustellen, dass die Wirtskörper für den Tag des Rituals bereit sind."

    # say L2278 lin
    old "Make sure everything's in place for that day."
    new "Stellen Sie sicher, dass alles für diesen Tag bereit ist."

    # say L2279 pla
    old "Sure, no problem, I'll go then."
    new "Klar, kein Problem, ich mach das dann."

    # say L2302 jon
    old "Oh darling! I knew you'd do it."
    new "Oh Darling! Das wusste ich von Ihnen."

    # say L2303 gra
    old "Just look at how beautiful the church looks! What a miracle!"
    new "Schauen Sie sich an, wie schön die Kirche aussieht! Was für ein Wunder!"

    # say L2304 pla
    old "Thank you, I'm glad you like it."
    new "Danke, ich freue mich, dass es dir gefällt."

    # say L2305 jon
    old "Oh darling, we don't like it, we love it!"
    new "Oh Darling, wir mögen es nicht, wir lieben es!"

    # say L2306 jon
    old "Who knows how much time it would've taken Sister Grace and I to finish it by ourselves."
    new "Wer weiß, wie viel Zeit es Schwester Grace und mir genommen hätte, es allein zu beenden."

    # say L2307 gra
    old "That's right. You made it possible for this to be ready."
    new "Das stimmt. Du hast es möglich gemacht, dass wir das hier fertigkriegen."

    # say L2308 jon
    old "Well darling, I'm sure you must be very busy."
    new "Na Liebling, ich bin sicher, Sie müssen sehr beschäftigt sein."

    # say L2309 jon
    old "And I'm sure you don't want to spend even one more hour of your time here."
    new "Und ich bin sicher, Sie wollen nicht noch eine Minute mehr Ihrer Zeit hier verbringen."

    # say L2311 pla
    old "Actually, I wanted to ask you something."
    new "Eigentlich wollte ich dich etwas fragen."

    # say L2313 gra
    old "What would you like to know?"
    new "Was möchten Sie denn wissen?"

    # say L2314 pla
    old "Well, the thing is that I'm doing this... Hmm, religious thing with a couple of my friends from school."
    new "Na ja, die Sache ist die, dass ich so eine Art... hmm, religiöse Sache mit ein paar Freunden von der Schule mache."

    # say L2315 pla
    old "And I would like to know if I can use the church one of these days to have a little ritual."
    new "Und ich würde gern wissen, ob ich die Kirche an einem der Tage benutzen kann, um ein kleines Ritual abzuhalten."

    # say L2318 pla
    old "Nothing bad."
    new "Nichts Schlimmes."

    # say L2319 pla
    old "Just something like what happened last time, you know, to bring them to the lord."
    new "Einfach so wie letztes Mal, du weißt schon, um sie dem Herrn näherzubringen."

    # say L2321 gra
    old "Oh my god! That sounds wonderful!"
    new "Oh mein Gott! Das klingt wunderbar!"

    # say L2322 jon
    old "I agree. It's so inspiring to see young people acting in such a way, looking for a connection with the lord. Simply great!"
    new "Ich stimme zu. Es ist so inspirierend, junge Menschen so handeln zu sehen, die eine Verbindung zum Herrn suchen. Einfach großartig!"

    # say L2323 gra
    old "Say [pla], could we participate? Just like last time? I would like you to bring me closer to heaven again!"
    new "[pla], könnten wir teilnehmen? Genauso wie letztes Mal? Ich würde gerne, dass du mich wieder dem Himmel näherbringst!"

    # say L2324 pla
    old "Uhh, I think not."
    new "Uhh, ich denke nicht."

    # say L2325 pla
    old "You see, you've already been blessed, the idea is to bring in new people, to receive the blessing."
    new "Du siehst, du wurdest schon gesegnet, die Idee ist es, neue Menschen einzubringen, um die Segnung zu empfangen."

    # say L2327 gra
    old "Oh, really? I must say that's a little disappointing."
    new "Oh, wirklich? Das muss ich enttäuscht zur Kenntnis nehmen."

    # say L2329 jon
    old "No, no, sister, what [pla] says it's true."
    new "Nein, nein, Schwester, was [pla] sagt, ist wahr."

    # say L2330 jon
    old "We must allow for other people to receive such a special blessing and be brought over to the community."
    new "Wir müssen anderen die Möglichkeit geben, diesen besonderen Segen zu empfangen und in die Gemeinschaft aufgenommen zu werden."

    # say L2331 pla
    old "It's great that you understand."
    new "Es ist toll, dass du das verstehst."

    # say L2332 pla
    old "So, I think we'll need the church for some days, so that the ritual can be properly done."
    new "Dann brauchen wir die Kirche für ein paar Tage, damit das Ritual ordnungsgemäß durchgeführt werden kann."

    # say L2333 pla
    old "I would love it if nobody came here, just so that we're not interrupted."
    new "Ich würde es lieben, wenn niemand hierherkommt, nur damit wir nicht gestört werden."

    # say L2335 jon
    old "Oh sure, no problem. We'll see to that, right Sister Grace?"
    new "Oh sicher, kein Problem. Wir werden uns darum kümmern, nicht wahr, Sister Grace?"

    # say L2336 gra
    old "There will be no issue."
    new "Es wird kein Problem geben."

    # say L2337 gra
    old "We trust you completely, so we'll do as you ask us."
    new "Wir vertrauen Ihnen vollständig, wir werden tun, was Sie von uns verlangen."

    # say L2338 pla
    old "Thank you very much! You're of great help."
    new "Vielen Dank! Du bist eine große Hilfe."

    # say L2339 jon
    old "Not at all darling, you're the one who is of great help, bringing people over to the community. What a good young man."
    new "Aber natürlich, Liebling, Sie sind es, der uns sehr hilft, indem Sie neue Menschen in die Gemeinschaft bringen. Was für ein guter junger Mann."

    # say L2340 gra
    old "It's true, you are a true blessing from the lord."
    new "Es stimmt, Sie sind ein wahrer Segen des Herrn."

    # say L2341 pla
    old "Thank you, very much for saying that."
    new "Danke, sehr schön gesagt."

    # say L2342 pla
    old "I think I better get going then."
    new "Dann denke ich, ich sollte besser aufbrechen."

    # say L2343 jon
    old "Good night [pla], and thanks again for all your help."
    new "Gute Nacht [pla], und vielen Dank für Ihre Hilfe."

    # say L2344 gra
    old "Yes, thank you so much, God bless you."
    new "Ja, vielen Dank, Gott segne Sie."

    # say L2363 pla
    old "Oh, hi, what's up?"
    new "Oh, hallo, was ist los?"

    # say L2364 lin
    old "Nothing much, I just wanted to let you know that I talked to the girls."
    new "Nicht viel, ich wollte dir nur sagen, dass ich mit den Mädchen gesprochen habe."

    # say L2365 lin
    old "And I'm very happy with the results of the training, they're now ready to do the ritual."
    new "Und ich bin sehr zufrieden mit den Ergebnissen der Ausbildung, sie sind jetzt bereit, das Ritual durchzuführen."

    # say L2367 lin
    old "It is, that's why I wanted to ask you, how are things going with the church?"
    new "Das ist der Grund, warum ich dich fragen wollte, wie läuft es mit der Kirche?"

    # say L2368 pla
    old "It's great, I asked them to let me use it, and they said it was ok, so we're all set."
    new "Es ist super, ich habe sie gefragt, ob ich es benutzen darf, und sie haben gesagt, dass es in Ordnung ist, also sind wir bereit."

    # say L2369 lin
    old "Fantastic, and how are things going with the three humans we need? Did you convince them already?"
    new "Fantastisch, und wie läuft es mit den drei Menschen, die wir brauchen? Hast du sie schon überzeugt?"

    # say L2371 pla
    old "Uhh, not really, but I think I can convince them of it pretty soon."
    new "Uhh, nein, aber ich denke, ich kann sie ziemlich bald überzeugen."

    # say L2372 lin
    old "Please do it and remember, they won't notice the ritual at all, so you don't need to worry."
    new "Bitte mach das und denk dran, sie werden den Ritual überhaupt nicht bemerken, da musst du dir keine Sorgen machen."

    # say L2373 pla
    old "Ok, I'll keep that in mind. And will talk to them as soon as I can."
    new "Okay, ich werd's mir merken. Und rede mit ihnen, sobald ich kann."

    # say L2375 lin
    old "I'll leave it in your hands then."
    new "Dann lass ich es in deinen Händen."

    # say L2384 pla
    old "Hmm, the day for the ritual is coming. I better hurry up and talk to the girls soon."
    new "Hmm, der Tag für das Ritual rückt näher. Ich sollte mich beeilen und bald mit den Mädels reden."

    # say L2400 bel
    old "Hi [pla]! It's good to see you."
    new "Hi [pla]! Es ist schön, dich zu sehen."

    # say L2401 bel
    old "Hey, listen, I'm glad we can talk. I wanted to tell you something."
    new "Hey, hör mal, ich bin froh, dass wir uns unterhalten können. Ich wollte dir was sagen."

    # say L2402 pla
    old "Sure, is everything ok?"
    new "Klar, ist alles in Ordnung?"

    # say L2403 bel
    old "Yeah, yeah, everything's fine, it's nothing bad."
    new "Ja, ja, alles gut, es ist nichts Schlimmes."

    # say L2405 pla
    old "Oh, ok, what is it then?"
    new "Oh, okay, was ist es dann?"

    # say L2407 bel
    old "Well, it's about what happened the other day with that dumbass bimbo."
    new "Na ja, es geht um das, was der andere Tag mit dieser blöden Bimbo passiert ist."

    # say L2408 bel
    old "She made me angry and I took off and left you alone with her. So I wanted to say sorry."
    new "Sie hat mich wütend gemacht und ich bin abgehauen und habe dich mit ihr allein gelassen. Deshalb wollte ich mich entschuldigen."

    # say L2410 pla
    old "That's all? Don't worry about it. I understand how irritating her comments can be."
    new "Das ist alles? Mach dir keine Sorgen. Ich verstehe, wie nervig ihre Kommentare sein können."

    # say L2411 bel
    old "They really are and she just makes me so mad."
    new "Sie sind es wirklich und sie bringt mich einfach so auf die Palme."

    # say L2412 bel
    old "I hope nothing bad happened with her when I left."
    new "Ich hoffe, es ist nichts Schlimmes passiert, nachdem ich gegangen bin."

    # say L2413 pla
    old "Bad? Haha, no, of course not, what could happen between us? Nothing happened at all."
    new "Schlecht? Haha, nein, natürlich nicht, was könnte zwischen uns passieren? Gar nichts ist passiert."

    # say L2414 bel
    old "Hmm, Okay..."
    new "Hmm, okay..."

    # say L2415 pla
    old "Well anyway, leaving that aside, there's something that I wanted to talk to you about."
    new "Na ja, lass uns das Thema wechseln, da ist was, worüber ich mit dir reden wollte."

    # say L2419 pla
    old "Well, these past few days I've been helping decorate the church, for the holidays and stuff."
    new "Na ja, in den letzten Tagen habe ich geholfen, die Kirche zu dekorieren, für die Feiertage und so."

    # say L2420 pla
    old "And the church actually looks really cool."
    new "Und die Kirche sieht echt cool aus."

    # say L2421 pla
    old "And it came to me that since we have some free time, why don't we have a little christmas celebration?"
    new "Und mir ist eingefallen, dass wir ja etwas freie Zeit haben, warum feiern wir nicht ein bisschen Weihnachten?"

    # say L2422 pla
    old "I thought it could be really cool if we played truth or dare like last time."
    new "Ich dachte, es könnte echt cool sein, wenn wir wieder Wahrheit oder Pflicht spielen wie letztes Mal."

    # say L2423 pla
    old "With me, Billie and Hinn by the way."
    new "Mit mir, Billie und Hinn übrigens."

    # say L2424 pla
    old "Not Mike, I know he can be a little annoying."
    new "Nicht Mike, ich weiß, dass er manchmal ein bisschen nervig sein kann."

    # say L2425 bel
    old "Hmm, that sounds like fun. And I do like that Mike won't be there..."
    new "Hmm, das klingt spaßig. Und ich freue mich, dass Mike nicht dabei sein wird..."

    # say L2426 pla
    old "Oh, by the way, I think it would be cool if we dressed up for christmas."
    new "Oh, übrigens, ich finde es cool, wenn wir uns für Weihnachten verkleiden."

    # say L2428 bel
    old "That's actually nice."
    new "Das ist eigentlich nett."

    # say L2429 bel
    old "Sure, why not? Count me in."
    new "Klar, warum nicht? Zähl mich mit rein."

    # say L2430 pla
    old "That's great Belle! So, how about we tomorrow night on the beach? Same spot as last time."
    new "Das ist toll Belle! Wie wär's dann morgen Abend am Strand? Am selben Fleck wie letztes Mal."

    # say L2431 pla
    old "And from there we can go to the church."
    new "Und von dort können wir zur Kirche gehen."

    # say L2451 pla
    old "Hey Billie, how are you doing?"
    new "Hey Billie, wie geht's dir?"

    # say L2452 bil
    old "Hey dude, what's up?"
    new "Hey Mann, was ist los?"

    # say L2453 pla
    old "Hey, I wanted to talk to you about something."
    new "Hey, ich wollte mit dir über was sprechen."

    # say L2454 bil
    old "Sure, is it the same thing you wanted to say to me when Miss Mia dragged you away the other day?"
    new "Klar, ist es das gleiche, was du mir sagen wolltest, als Miss Mia dich neulich mitgeschleift hat?"

    # say L2455 pla
    old "Oh, yeah, actually it is. But thanks for reminding me that Miss Mia hates me."
    new "Oh, ja, tatsächlich. Aber danke, dass du mich daran erinnerst, dass Miss Mia mich hasst."

    # say L2456 bil
    old "Hahahaha, dude, she really does. I don't know what you did to get on her bad side. But she has it in for you."
    new "Hahahaha, Kumpel, sie hasst dich wirklich. Keine Ahnung, was du gemacht hast, um sie gegen dich aufzubringen. Aber sie hat es faustdick hinter den Ohren für dich."

    # say L2457 pla
    old "She does, she really does."
    new "Sie tut es, sie tut es wirklich."

    # say L2458 pla
    old "But anyway, that's not what I wanted to say."
    new "Aber egal, das ist nicht, was ich sagen wollte."

    # say L2459 pla
    old "Listen, I've been thinking, and that game of truth or dare was actually pretty fun."
    new "Hör zu, ich hab nachgedacht, und dieses Wahrheit-oder-Durstspiel war eigentlich ziemlich lustig."

    # say L2460 pla
    old "So I thought that since we're gonna have some free time soon. Maybe we could go for another round."
    new "Dann dachte ich, da wir bald etwas freie Zeit haben. Vielleicht könnten wir noch eine Runde spielen."

    # say L2461 bil
    old "Oh, I wasn't expecting you to say that."
    new "Oh, das habe ich nicht erwartet."

    # say L2462 bil
    old "I mean, sure, it could be fun, but I don't know."
    new "Ich meine, klar, es könnte Spaß machen, aber ich weiß nicht."

    # say L2463 bil
    old "Sounds a little boring now."
    new "Klingt jetzt ein bisschen langweilig."

    # say L2465 pla
    old "Oh, come on. Let's do it. Besides, I've been helping your grandma decorate the church."
    new "Oh, komm schon. Lass uns machen. Außerdem, ich hab deiner Oma bei der Kirche geholfen, die zu dekorieren."

    # say L2467 bil
    old "Yeah, she mentioned it."
    new "Klar, sie hat davon erzählt."

    # say L2468 pla
    old "Yeah and it actually looks great, so it came to my mind that we could have a little celebration there."
    new "Und es sieht echt toll aus, deshalb dachte ich, wir könnten da ein kleines Fest feiern."

    # say L2469 pla
    old "And we can even wear holiday outfits."
    new "Und wir können sogar Feiertagsoutfits tragen."

    # say L2471 bil
    old "When you say that we celebrate there."
    new "Wenn du sagst, dass wir da feiern."

    # say L2472 bil
    old "I hope that doesn't means my grandma and the nun will be there. Right?"
    new "Ich hoffe, das bedeutet nicht, dass meine Oma und die Nonne auch da sind. Oder?"

    # say L2473 pla
    old "No, not at all."
    new "Nein, überhaupt nicht."

    # say L2474 pla
    old "I talked to them and I got them to lend me the place for the night. So it will just be us."
    new "Ich hab mit ihnen gesprochen und sie haben mir den Ort für den Abend geliehen. Also wird es nur uns geben."

    # say L2476 bil
    old "Even with that, it doesn't sound like the coolest thing."
    new "Auch dann klingt es nicht gerade nach der tollsten Sache."

    # say L2477 pla
    old "It will be cool. And you kind of owe for what happened last time."
    new "Es wird cool. Und du schuldest mir noch was für das letzte Mal."

    # say L2478 pla
    old "Remember whose idea it was that I climbed that roof?"
    new "Erinnerst du dich noch, wessen Idee es war, dass ich aufs Dach geklettert bin?"

    # say L2479 bil
    old "Ugh, dude, come on! Don't bring that up now, lame."
    new "Ugh, Mann, komm schon! Lass das jetzt, lame."

    # say L2481 bil
    old "But it's true, I do owe you. And what the hell, it could be fun."
    new "Aber es stimmt, ich bin dir was schuldig. Und was soll's, könnte ja spaßig werden."

    # say L2482 bil
    old "But no Mike, ok? He's annoying."
    new "Aber nein Mike, ok? Er ist nervig."

    # say L2483 pla
    old "Thanks Billie! I'm sure we'll have a great time. Ok, so tomorrow night at the beach? We can go from there."
    new "Danke Billie! Ich bin sicher, wir werden einen tollen Abend haben. Also, morgen Abend am Strand? Von da aus können wir weitersehen."

    # say L2484 bil
    old "Yeah, whatever."
    new "Klar, wie du willst."

    # say L2486 pla
    old "Alright, see you tomorrow then."
    new "Okay, dann bis morgen."

    # say L2513 hin
    old "[pla] Hi! How are you?"
    new "[pla] Hallo! Wie geht’s dir?"

    # say L2515 hin
    old "I'm glad. My mother told me you came home the other day looking for me. I'm sorry we couldn't talk."
    new "Ich bin froh. Meine Mutter hat mir erzählt, dass du neulich nach Hause gekommen bist und mich gesucht hast. Es tut mir leid, dass wir nicht reden konnten."

    # say L2516 pla
    old "Don't worry, it happens."
    new "Mach dir keine Sorgen, das passiert."

    # say L2517 hin
    old "Yeah, by the way, my mom wanted me to ask you if you remember anything strange happening."
    new "Ja, übrigens, meine Mutter wollte mich bitten, dich zu fragen, ob du dich an etwas Seltsames erinnerst."

    # say L2518 pla
    old "Strange? Heh, Me? N- no, no, why?"
    new "Komisch? Heh, ich? N-nein, nein, warum?"

    # say L2519 hin
    old "Well, she says that she remembers talking to you, but then she just woke up, apparently she fell asleep without knowing."
    new "Na ja, sie sagt, dass sie sich daran erinnert, mit dir gesprochen zu haben, aber dann ist sie plötzlich aufgewacht. Scheint, dass sie ohne es zu merken eingeschlafen ist."

    # say L2520 hin
    old "So she wanted me to ask you if you know anything about that."
    new "Dann wollte sie, dass ich dich frage, ob du was darüber weißt."

    # say L2521 pla
    old "Hmm, not really, after she told me you weren't there I just left."
    new "Hmm, nein, nachdem sie mir gesagt hat, dass du nicht da warst, bin ich einfach gegangen."

    # say L2522 pla
    old "Maybe she was tired and doesn't remember falling asleep."
    new "Vielleicht war sie müde und erinnert sich nicht daran, eingeschlafen zu sein."

    # say L2523 hin
    old "Yeah, that's what I told her."
    new "Ja, das hab ich ihr gesagt."

    # say L2524 hin
    old "But anyway, what did you want to talk to me about?"
    new "Aber egal, worüber wolltest du mit mir sprechen?"

    # say L2526 pla
    old "Oh right, I forgot."
    new "Oh stimmt, ich hab's vergessen."

    # say L2527 pla
    old "Well, you see. I've been thinking that maybe we could get together with Billie and Belle."
    new "Na ja, du siehst. Ich hab darüber nachgedacht, dass wir uns vielleicht mit Billie und Belle treffen könnten."

    # say L2528 pla
    old "And play another round of truth or dare with them. It was very fun last time and maybe it would be good to do it again."
    new "Und noch ein Runde Wahrheit oder Pflicht mit ihnen spielen. Es war letztes Mal so lustig und vielleicht wäre es gut, es wieder zu machen."

    # say L2529 pla
    old "Especially since we have some free time coming up."
    new "Besonders weil wir bald etwas freie Zeit haben."

    # say L2532 hin
    old "I don't know [pla]. I mean, it is fun. But you know how nervous I get in those kind situations."
    new "Ich weiß nicht [pla]. Ich meine, es ist spaßig. Aber du weißt ja, wie nervös ich in solchen Situationen werde."

    # say L2533 pla
    old "I know, I know. But that's in part why I propose it, I think it could be very helpful with your anxiety."
    new "Ich weiß, ich weiß. Aber genau deshalb schlage ich es vor, ich denke, es könnte dir sehr helfen, mit deiner Angst umzugehen."

    # say L2534 pla
    old "I mean, you can practice a bit and of course stay with me and your friends in a safe place."
    new "Ich meine, du kannst ein bisschen üben und natürlich bei mir und deinen Freunden in einem sicheren Ort bleiben."

    # say L2536 hin
    old "You know what? You might be right. And I think I could also use the experience to deal with my anxiety."
    new "Du hast recht. Und ich denke, ich könnte die Erfahrung auch nutzen, um mit meiner Angst besser klarzukommen."

    # say L2537 hin
    old "I- I'll do it."
    new "Ich- Ich mach's."

    # say L2539 pla
    old "That's cool Hinn. I'm sure we'll have a good time."
    new "Das ist cool, Hinn. Ich bin sicher, wir werden einen schönen Abend haben."

    # say L2540 pla
    old "Oh, and I was thinking, maybe we could take the chance and dress up christmas themed, what do you think?."
    new "Oh, und ich dachte, wir könnten die Gelegenheit nutzen und uns thematisch für Weihnachten kleiden, was meinst du?"

    # say L2541 pla
    old "You know, because it's the holidays."
    new "Weil es ja die Feiertage sind."

    # say L2542 hin
    old "That sounds great! Count me in."
    new "Das klingt toll! Zähl mich mit ein."

    # say L2543 pla
    old "I was thinking that we could meet at the beach tomorrow night."
    new "Ich dachte, wir könnten uns morgen Abend am Strand treffen."

    # say L2544 hin
    old "That sounds ok."
    new "Das klingt gut."

    # say L2545 pla
    old "See you later then."
    new "Bis später dann."

    # say L2546 hin
    old "Sure, goodbye."
    new "Klar, tschüss."

    # say L2569 pla
    old "Hi, you were waiting for me?"
    new "Hi, du wartest auf mich?"

    # say L2570 lin
    old "I was, I wanted to tell the other three shinigami are ready for the ritual."
    new "Ich war es, ich wollte dir sagen, dass die anderen drei Shinigami bereit für das Ritual sind."

    # say L2571 pla
    old "I already spoke with my friends, they all said yes."
    new "Ich hab' schon mit meinen Freunden gesprochen, die sagen alle zu."

    # say L2572 lin
    old "That's perfect! Ok, so we're all set now."
    new "Das ist perfekt! Okay, dann sind wir jetzt alle bereit."

    # say L2573 lin
    old "Get ready, we'll have a lot of work to do tomorrow. Be sure you get enough rest."
    new "Bereite dich vor, morgen haben wir viel zu tun. Stell sicher, dass du genug Schlaf kriegst."

    # say L2574 pla
    old "I'll make sure to get enough rest."
    new "Ich werde genug Schlaf kriegen."

    # say L2575 lin
    old "Ok then, I'll see you tomorrow."
    new "Ok dann, bis morgen."

    # say L2593 pla
    old "Hey Linett, good morning."
    new "Hey Linett, guten Morgen."

    # say L2594 lin
    old "Are you ready for today?"
    new "Bist du bereit für heute?"

    # say L2595 pla
    old "Yeah sure, I'm ready."
    new "Klar, ich bin bereit."

    # say L2596 lin
    old "Ok then, so let's go talk to the others."
    new "Okay, dann lass uns zu den anderen gehen."

    # say L2629 lin
    old "Good morning, I hope you're all ready for the ritual today."
    new "Guten Morgen, ich hoffe, ihr seid alle bereit für das Ritual heute."

    # say L2630 gom
    old "Hello, yes, we are. We've been practicing so we're confident it's going to go well."
    new "Hallo, ja, wir sind bereit. Wir haben geübt, also sind wir zuversichtlich, dass alles gut laufen wird."

    # say L2631 mil
    old "Hello, I agree."
    new "Hallo, ich stimme zu."

    # say L2632 dev
    old "Sure, we feel like we won't have any issues. Good morning [pla]."
    new "Klar, wir denken, dass wir keine Probleme haben werden. Guten Morgen [pla]."

    # say L2634 lin
    old "Ok, it's good to hear you're confident. So, before we leave for the church, we should go over the plan."
    new "Ok, es ist gut zu hören, dass du dir sicher bist. Also, bevor wir zur Kirche aufbrechen, sollten wir den Plan durchgehen."

    # say L2635 lin
    old "[pla] has been working to have the place ready for us to use. So that won't be an issue."
    new "[pla] hat sich bemüht, den Ort für uns bereitzustellen. Das wird also kein Problem sein."

    # say L2636 dev
    old "That's great."
    new "Das ist toll."

    # say L2637 lin
    old "It is. The idea is that we'll go to the church and wait there."
    new "Das ist so. Die Idee ist, dass wir zur Kirche gehen und dort warten."

    # say L2638 lin
    old "In the meantime [pla] will meet with the people that will be our hosts somewhere else and bring them over."
    new "In der Zwischenzeit wird [pla] sich mit den Leuten treffen, die unsere Gastgeber sein werden, und sie dann zu uns bringen."

    # say L2639 lin
    old "When they get to the church they'll come and you'll get inside them."
    new "Wenn sie zur Kirche kommen, werden sie reinkommen und du wirst in ihnen sein."

    # say L2640 gom
    old "How will we know who's getting inside who?"
    new "Wie werden wir wissen, wer in wen reinkommt?"

    # say L2641 pla
    old "I was thinking about that, but honestly it doesn't really makes much of a difference."
    new "Ich hab drüber nachgedacht, aber ehrlich gesagt macht das nicht viel Unterschied."

    # say L2642 lin
    old "It would if you had run the practice with your actual hosts. But since you didn't, you can just get inside anybody."
    new "Es wäre anders, wenn du die Probe mit deinen tatsächlichen Wirtskörpern durchgeführt hättest. Da du das aber nicht getan hast, kannst du in jeden rein."

    # say L2644 mil
    old "Ok, It sounds fairly easy."
    new "Ok, klingt ziemlich einfach."

    # say L2645 lin
    old "It will be, after you get them we can start the ritual."
    new "Es wird, sobald du sie hast, können wir das Ritual beginnen."

    # say L2646 lin
    old "So while you channel magic power, I'll handle the union of all three sources into the breach point."
    new "Dann leite ich die Magie, während du die Vereinigung der drei Quellen mit dem Bruchpunkt vornimmst."

    # say L2647 lin
    old "If everything goes well, we should be able to create a magic generator point."
    new "Wenn alles gut geht, sollten wir in der Lage sein, einen Magiegeneratoren-Punkt zu schaffen."

    # say L2650 lin
    old "So, we better get to it. [pla] go ahead, and we'll meet back at the church."
    new "Dann lassen wir uns mal an die Arbeit machen. [pla] geh schon mal vor, wir treffen uns dann in der Kirche."

    # say L2651 pla
    old "Ok, see you then."
    new "Ok, bis dann."

    # narrator L2654 
    old "Several hours later..."
    new "Einige Stunden später..."

    # say L2669 pla
    old "Hey girls! Wow... You look stunning!"
    new "Hey Mädels! Wow... Ihr seht fantastisch aus!"

    # say L2670 hin
    old "Y- You think so?"
    new "Y- Du findest?"

    # say L2671 pla
    old "I do. For starters, you look great as a reindeer."
    new "Ich tu's. Zum Anfang, siehst du toll aus als Rentier."

    # say L2672 pla
    old "And you Belle, that santa claus outfit really fits you. You look amazing."
    new "Und du Belle, das Santa-Claus-Outfit steht dir wirklich gut. Du siehst fantastisch aus."

    # say L2673 pla
    old "And Billie, green really is your colour, I think it goes really well with your hair."
    new "Und Billie, Grün steht dir wirklich gut, ich denke, es passt perfekt zu deinen Haaren."

    # say L2674 bil
    old "Well and where is this coming from?"
    new "Woher kommt das plötzlich?"

    # say L2675 bil
    old "It's odd to hear you being so flattering."
    new "Das ist seltsam, dich so schmeichelhaft zu hören."

    # say L2677 bel
    old "But he's right, we look great. Hahaha."
    new "Aber er hat recht, wir sehen toll aus. Hahaha."

    # say L2679 bil
    old "And what about you? What happended with your outfit?"
    new "Und was ist mit dir? Was ist mit deinem Outfit passiert?"

    # say L2680 pla
    old "Oh crap! I completely forgot… I was a bit busy with all the preparations"
    new "Oh Mist! Ich hab’s total vergessen… Ich war ja so mit den Vorbereitungen beschäftigt."

    # say L2682 bel
    old "That's not fair..."
    new "Das ist nicht fair..."

    # say L2683 bil
    old "Yeah, yeah whatever..."
    new "Ja, ja, egal..."

    # say L2684 bil
    old "Ok dude, let's start this!"
    new "Ok, lass uns anfangen!"

    # say L2697 bel
    old "Wow! [pla] look at this place! It's amazing!"
    new "Wow! [pla] schau dir diesen Ort an! Es ist unglaublich!"

    # say L2698 hin
    old "They're right, it looks very beautiful [pla]."
    new "Du hast recht, es sieht wirklich wunderschön aus [pla]."

    # say L2699 pla
    old "Well thank you, I'm glad you girls like it."
    new "Danke, ich freue mich, dass es euch gefällt."

    # say L2700 bil
    old "Ok, we should start playing, don't we."
    new "Ok, wir sollten anfangen, oder?"

    # say L2719 pla
    old "Yeah, it's time! Let's start."
    new "Ja, es ist Zeit! Lasst uns anfangen."

    # say L2737 milBil
    old "That sensation, it's so strong."
    new "Diese Empfindung, sie ist so stark."

    # say L2738 pla
    old "Did it work?"
    new "Hat es funktioniert?"

    # say L2740 gomHin
    old "It did, the spell went well."
    new "Es hat funktioniert, der Zauber war gut."

    # say L2755 lin
    old "Great, that was very good."
    new "Super, das war sehr gut."

    # say L2756 devBel
    old "Well, I wouldn't say it went that well. I mean, look at me! This body is so small."
    new "Na ja, ich würde sagen, es ist nicht so gut gelaufen. Ich meine, schau mich an! Mein Körper ist so klein."

    # say L2757 devBel
    old "I don't have any more curves! This isn't fair!"
    new "Ich habe keine Kurven mehr! Das ist total unfair!"

    # say L2758 gomHin
    old "I actually gained size. This girl has way more curves than I do."
    new "Ich habe tatsächlich zugenommen. Dieses Mädchen hat viel mehr Kurven als ich."

    # say L2759 gomHin
    old "I think that the one that came up the better in that sense was Mildret."
    new "Ich denke, die, die da besser rausgekommen ist, war Mildret."

    # say L2760 gomHin
    old "Your host has some real curves, it's amazing!"
    new "Deine Gastgeberin hat echt Kurven, das ist unglaublich!"

    # say L2761 milBil
    old "I suppose you could say that. She is really big."
    new "Ich denke, man könnte das sagen. Sie ist wirklich groß."

    # say L2762 milBil
    old "I must say I'm surprised she can move around with these things. Specially since humans can't fly."
    new "Ich muss sagen, ich bin überrascht, dass sie sich damit überhaupt bewegen kann. Vor allem, da Menschen ja nicht fliegen können."

    # say L2763 gomHin
    old "They can't fly, but they have some sensory capabilities that are unique to them."
    new "Sie können zwar nicht fliegen, aber sie haben sensorische Fähigkeiten, die einzigartig für sie sind."

    # say L2764 gomHin
    old "They have access to sensations that we don't."
    new "Sie haben Zugang zu Empfindungen, die wir nicht haben."

    # say L2765 devBel
    old "Oh, you don't have to tell me that. I've had it in my mind since before we made the spell."
    new "Oh, das musst du mir nicht sagen. Ich hab es schon in meinem Kopf, bevor wir den Zauber gewirkt haben."

    # say L2766 lin
    old "I know what you mean, but please remember that's not the reason why we're doing this."
    new "Ich weiß, was du meinst, aber bitte denk dran, dass das nicht der Grund ist, warum wir das machen."

    # say L2767 gomHin
    old "I know, I know... But still, you can't deny that it's a very interesting experience."
    new "Ich weiß, ich weiß... Aber trotzdem kannst du nicht leugnen, dass es eine sehr interessante Erfahrung ist."

    # say L2768 gomHin
    old "I mean, even Mildret's waiting for it. Right?"
    new "Ich meine, sogar Mildret freut sich drauf. Oder?"

    # say L2770 milBil
    old "Hmph, the only thing I'm waiting for is the magic we'll get once the ritual is over. Nothing else."
    new "Hmpf, ich warte nur auf die Magie, die wir bekommen, sobald das Ritual vorbei ist. Alles andere interessiert mich nicht."

    # say L2772 devBel
    old "Ha! Yeah right. I know you enjoyed your practice the other day."
    new "Ha! Ja klar. Ich weiß, dass dir das Training letztes Mal gefallen hat."

    # say L2773 milBil
    old "Oh, shut up!"
    new "Oh, halt die Klappe!"

    # say L2774 lin
    old "Enough of that, remember we're doing a ritual. And it's better if we begin."
    new "Lass das, wir machen ein Ritual. Und es ist besser, wenn wir anfangen."

    # say L2775 lin
    old "[pla] are you ready?"
    new "[pla] bist du bereit?"

    # say L2776 pla
    old "I am, what do I have to do? How is the process?"
    new "Ich bin bereit, was muss ich tun? Wie läuft der Prozess ab?"

    # say L2777 lin
    old "You just have to supply them with magic power so that they can  leave your friends bodies."
    new "Du musst ihnen nur magische Energie geben, damit sie die Körper deiner Freunde verlassen können."

    # say L2778 lin
    old "The amount of magic that's actually needed to break the possession is really small."
    new "Die Menge an Magie, die tatsächlich nötig ist, um den Besitz zu brechen, ist wirklich klein."

    # say L2780 pla
    old "I'm not sure I follow."
    new "Ich bin mir nicht sicher, ob ich das verstehe."

    # say L2781 gomHin
    old "What she means is that in the process of pushing us out of these bodies."
    new "Was sie meint, ist, dass im Prozess des Herausdrängens aus diesen Körpern."

    # say L2782 gomHin
    old "There's going to be an excess of magic that's being produced."
    new "Es wird einen Überschuss an Magie geben, der entsteht."

    # say L2784 lin
    old "And that extra magic is the one I'll take and divert to the point where I'll open a breach."
    new "Und dieses zusätzliche Magie werde ich ablenken, um den Bruch zu öffnen."

    # say L2785 lin
    old "That will transform into the magic generation point."
    new "Das wird sich in den Magiegenerierungspunkt verwandeln."

    # say L2787 gomHin
    old "Well, if you do then we better not delay this any longer."
    new "Dann sollten wir besser keine Zeit mehr verlieren."

    # say L2788 lin
    old "She's right. We better get started."
    new "Sie hat recht. Wir sollten besser anfangen."

    # say L2796 shiBel
    old "Alright, now it's time to you to give us that big cock!"
    new "Okay, jetzt ist es an dir, uns deinen großen Schwanz zu zeigen!"

    # say L2797 shiHin
    old "My god, this cock of yours, I’ve always thought it’s very big for a human."
    new "Mein Gott, dieser Schwanz von dir, ich habe immer gedacht, er ist sehr groß für einen Menschen."

    # say L2798 shiHin
    old "But seeing it with human eyes... It’s something else."
    new "Aber es mit menschlichen Augen zu sehen... Das ist etwas anderes."

    # say L2799 shiBel
    old "It’s true, I never thought I’d care about the size and girth."
    new "Stimmt, ich hätte nie gedacht, dass mich die Größe und der Umfang interessieren würden."

    # say L2800 shiBel
    old "But with this body..."
    new "Aber mit diesem Körper..."

    # say L2801 shiBel
    old "And I never noticed it before, but it has an amazing smell too."
    new "Und ich habe es vorher nie bemerkt, aber es hat auch einen unglaublichen Geruch."

    # say L2802 shiBil
    old "I must admit that it is quite... Enticing."
    new "Ich muss zugeben, dass es ziemlich... Verlockend ist."

    # say L2803 shiBel
    old "Mmm! I bet you can’t wait either [pla]."
    new "Mmm! Ich wette, du kannst es auch kaum abwarten [pla]."

    # say L2805 shiHin
    old "Oh, don’t worry, we’ll make sure you enjoy the process."
    new "Oh, mach dir keine Sorgen, wir werden sicherstellen, dass du den Vorgang genießt."

    # say L2826 gom
    old "It really was, I could feel the magic flowing through me, incredible!"
    new "Es war wirklich so, ich konnte die Magie durch mich hindurchfließen spüren, unglaublich!"

    # say L2827 lin
    old "That's because there was a lot of magic in the room."
    new "Das liegt daran, dass im Raum eine Menge Magie war."

    # say L2828 lin
    old "Enough to make the breach and create the portal."
    new "Genug, um die Lücke zu schaffen und das Portal zu öffnen."

    # say L2829 mil
    old "Does that mean that it worked?"
    new "Das bedeutet also, dass es funktioniert hat?"

    # say L2830 lin
    old "Well, we did everything right. And I made sure to siphon the magic to where we needed it."
    new "Na ja, wir haben alles richtig gemacht. Und ich habe darauf geachtet, die Magie dorthin zu leiten, wo wir sie brauchten."

    # say L2831 lin
    old "But the portal takes some time to form."
    new "Aber das Portal braucht etwas Zeit, um sich zu bilden."

    # say L2832 lin
    old "So, we won't know for a while."
    new "Dann werden wir noch eine Weile nichts wissen."

    # say L2833 mil
    old "Then, there's a chance we may have failed."
    new "Dann besteht die Möglichkeit, dass wir gescheitert sind."

    # say L2834 gom
    old "Well, if it did all we have to do is repeat the ritual."
    new "Dann müssen wir das Ritual einfach wiederholen."

    # say L2835 dev
    old "That's not a problem, if anything happens it would be a good idea."
    new "Das ist kein Problem, wenn was passiert, wäre es eine gute Idee."

    # say L2836 lin
    old "I'm glad you're positive about it."
    new "Ich bin froh, dass du das so siehst."

    # say L2837 lin
    old "For now let's just wait and see."
    new "Lass uns einfach abwarten."

    # say L2838 pla
    old "Girls, I'm sorry to interrupt, but maybe you could help me clean up my friends."
    new "Mädels, tut mir leid, dass ich euch unterbreche, aber könntet ihr mir vielleicht helfen, meine Freunde zu säubern?"

    # say L2839 pla
    old "We have to make it look as if they were sleeping."
    new "Wir müssen es so aussehen lassen, als würden sie schlafen."

    # say L2841 dev
    old "Sure, let's do that."
    new "Klar, machen wir das."

    # say L2858 mil
    old "Done, now your friends are clean."
    new "Fertig, jetzt sind deine Freunde sauber."

    # say L2859 pla
    old "Thank you for your help girls."
    new "Danke für eure Hilfe, Mädels."

    # say L2860 lin
    old "Listen, [pla] since the ritual is done, we have nothing else to do here tonight."
    new "Hört mal, [pla] da das Ritual abgeschlossen ist, haben wir hier heute Abend nichts mehr zu tun."

    # say L2861 lin
    old "We'll leave and pay attention to see if we feel any changes in the magic concentration in the air."
    new "Wir werden gehen und darauf achten, ob wir Veränderungen in der magischen Konzentration in der Luft spüren."

    # say L2862 lin
    old "You make sure there's no problem here."
    new "Du machst sicher, dass hier alles in Ordnung ist."

    # say L2863 pla
    old "Alright, I'm gonna wait for my friends to wake up."
    new "Okay, ich warte, bis meine Freunde aufwachen."

    # say L2864 lin
    old "Hmm, given all the power that went through them, they won't wake up until the morning."
    new "Hmm, bei der ganzen Energie, die durch sie geflossen ist, werden sie bis morgen nicht aufwachen."

    # say L2865 pla
    old "Ohh man... Really?"
    new "Oh Mann... Wirklich?"

    # say L2866 lin
    old "Yeap, I guess so."
    new "Klar, ich denke schon."

    # say L2867 pla
    old "Well, I have no option... Otherwise, it would be really weird for them to wake up without me around."
    new "Na gut, ich hab keine Wahl... Sonst wäre es echt seltsam für sie aufzuwachen und mich nicht hier zu haben."

    # say L2868 mil
    old "Yeah, you are right."
    new "Stimmt, du hast recht."

    # say L2869 lin
    old "Alright, that's all, it's time for us to leave. Let's go."
    new "Okay, dann ist es so weit, Zeit für uns zu gehen. Lass uns los."

    # say L2871 mil
    old "Thanks for... Everything."
    new "Danke für... alles."

    # say L2872 gom
    old "Good bye [pla]."
    new "Tschüss [pla]."

    # say L3005 bel
    old "[pla]? What happened?"
    new "[pla]? Was ist passiert?"

    # say L3006 hin
    old "I can't remember anything."
    new "Ich kann mich an nichts erinnern."

    # say L3007 bil
    old "What the hell? We fell asleep?"
    new "Was zur Hölle? Sind wir eingeschlafen?"

    # say L3008 pla
    old "I think we just fell asleep after playing."
    new "Ich glaube, wir sind einfach eingeschlafen, nachdem wir gespielt haben."

    # say L3009 pla
    old "I also just woke up."
    new "Ich bin auch gerade erst aufgewacht."

    # say L3010 bil
    old "We just fell asleep?"
    new "Wir sind eingeschlafen?"

    # say L3012 pla
    old "Uhh yeah, you know, it was pretty late."
    new "Uhh ja, weißt du, es war ziemlich spät."

    # say L3013 bel
    old "Hmm, I guess that makes sense. "
    new "Hmm, das ergibt Sinn."

    # say L3014 pla
    old "Hey, I think it's better if we just go home, it's already morning, and someone may come."
    new "Hey, ich denke, es ist besser, wenn wir einfach nach Hause gehen. Es ist schon morgens und jemand könnte kommen."

    # say L3016 hin
    old "You're right, we shouldn't worry our parents."
    new "Du hast recht, wir sollten unsere Eltern nicht beunruhigen."

    # say L3017 bel
    old "That's true, see you later then."
    new "Das stimmt, bis später dann."

    # say L3019 bil
    old "I still don't get why I can't remember anything, but anyway, I guess I'll go home, later."
    new "Ich verstehe immer noch nicht, warum ich mich an nichts erinnern kann, aber egal, ich denke, ich geh dann mal nach Hause, bis später."

    # say L3020 hin
    old "I think I'll also be on my way, bye [pla]."
    new "Ich denke, ich gehe auch, tschüss [pla]."

    # say L3021 pla
    old "Bye girls."
    new "Tschüss, Mädels."

    # say L3027 lin
    old "Oh, you're finnally here."
    new "Oh, du bist endlich da."

    # say L3029 lin
    old "Good morning, I'm glad you are fine. I just wanted to thank you for everything you did."
    new "Guten Morgen, ich bin froh, dass es dir gut geht. Ich wollte mich nur bei dir für alles bedanken, was du getan hast."

    # say L3030 pla
    old "Oh, you don't have to thank me, I'm a Sexnote owner, that's my mission."
    new "Oh, du musst mir nicht danken, ich bin ein Sexnote-Besitzer, das ist meine Mission."

    # say L3031 lin
    old "That's right, however you have done a lot you didn't have to."
    new "Das stimmt, aber du hast viel getan, was du nicht hättest tun müssen."

    # say L3032 lin
    old "And everything was for us, to save and protect us."
    new "Und alles war für uns, um uns zu retten und zu schützen."

    # say L3034 lin
    old "All right. Now we just have to wait to see if everything worked..."
    new "Alles klar. Jetzt müssen wir nur noch abwarten, ob alles funktioniert hat..."

    # say L3035 pla
    old "How much would it takes?"
    new "Wie lange wird es dauern?"

    # say L3036 lin
    old "To be honest I don't know... It's the first time someone tries to create a magic generation point."
    new "Ehrlich gesagt, ich hab keine Ahnung... Es ist das erste Mal, dass jemand versucht, einen magischen Generierungspunkt zu schaffen."

    # say L3037 lin
    old "It could take, hours, days, weeks or months, the only thing we can do now is wait.."
    new "Es könnte Stunden, Tage, Wochen oder Monate dauern, das Einzige, was wir jetzt tun können, ist warten."

    # say L3039 pla
    old "Oh, man... I was expecting a faster result."
    new "Oh Mann... Ich hatte gehofft, dass es schneller geht."

    # say L3040 lin
    old "Actually, I'm pretty sure, that is everthing worked, we could notice a change in the whole area, and it won't take long for sure."
    new "Eigentlich bin ich ziemlich sicher, dass wenn alles funktioniert hat, wir eine Veränderung im ganzen Gebiet bemerken werden und es dauert sicher nicht lange."

    # say L3042 lin
    old "Yeah, don't worry, this time we did it right. And all of this thanks to you."
    new "Klar, mach dir keine Sorgen, diesmal haben wir es richtig gemacht. Und das alles dank dir."

    # say L3043 pla
    old "I'm glad to had helped."
    new "Ich bin froh, dass ich helfen konnte."

    # say L3044 lin
    old "All right, I think you should rest. I can see you pretty tired."
    new "Okay, ich denke, du solltest dich ausruhen. Ich sehe, dass du ziemlich müde bist."

    # say L3045 pla
    old "You're right, I did slept well last night... Thank you and see you later."
    new "Du hast recht, ich hab gut geschlafen letzte Nacht... Danke und bis später."


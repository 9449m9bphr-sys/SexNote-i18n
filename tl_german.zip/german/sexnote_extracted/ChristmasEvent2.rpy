# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/ChristmasEvent2.rpy
translate german strings:

    # say L7 pla
    old "Hmm, what is this?"
    new "Hmm, was ist das?"

    # say L8 pla
    old "What's this feeling?"
    new "Was ist das für ein Gefühl?"

    # say L9 pla
    old "I- I have a hard-on?!"
    new "I- Ich habe eine Erektion?!"

    # say L22 pla
    old "Lydia?! W- what are you doing?"
    new "Lydia?! W- was machst du da?"

    # say L28 lyd
    old "Good morning hon! Great, you finally wake up!"
    new "Guten Morgen Schatz! Toll, du bist endlich wach!"

    # say L29 pla
    old "W- what's happenning? What's this?!"
    new "W- was passiert hier? Was ist das?!"

    # say L30 pla
    old "And what is that you're wearing?!"
    new "Und was hast du da an?!"

    # say L34 lyd
    old "Do you like it? It's my Mrs. Claus outfit for the day!"
    new "Magst du es? Es ist mein Outfit als Mrs. Claus für den Tag!"

    # say L35 lyd
    old "You know, to get in the spirit of Christmas."
    new "Du weißt schon, um in den Weihnachtsstimmung zu kommen."

    # say L36 pla
    old "Whatever! What are you doing in my room, and giving me a blowjob?!"
    new "Was auch immer! Was machst du in meinem Zimmer und bläst mir?!"

    # say L37 lyd
    old "Well, I came to spend Christmas with you guys."
    new "Na ja, ich bin gekommen, um Weihnachten mit euch zu verbringen."

    # say L38 lyd
    old "But when I arrived I saw that you were still sleeping."
    new "Aber als ich ankam, habe ich gesehen, dass du noch geschlafen hast."

    # say L42 lyd
    old "Then I decided to wake you up in a special way!"
    new "Dann habe ich beschlossen, dich auf eine besondere Art und Weise zu wecken!"

    # say L43 lyd
    old "I guess you can say it is my early Christmas present to you!"
    new "Du kannst es dir als mein frühes Weihnachtsgeschenk vorstellen!"

    # say L44 pla
    old "What are you talking about?!"
    new "Wovon redest du?!"

    # say L45 pla
    old "Do you know what my [mo1rel]'s going to do if she sees what you're doing?!"
    new "Weißt du, was meine [mo1rel] machen wird, wenn sie sieht, was du da machst?!"

    # say L46 pla
    old "What's gotten into you all of a sudden?"
    new "Was ist plötzlich in dich gefahren?"

    # say L50 lyd
    old "Oh, don't say that."
    new "Oh, sag das nicht."

    # say L51 lyd
    old "Nothing got into me."
    new "Mir ist nichts passiert."

    # say L55 lyd
    old "I just wanted to start Christmas the right way."
    new "Ich wollte nur den richtigen Start ins Weihnachtsfest haben."

    # say L59 lyd
    old "I bet you can help me with that."
    new "Ich wette, du kannst mir dabei helfen."

    # say L63 lyd
    old "After all, you have something I want in me..."
    new "Schließlich hast du etwas, das ich in mir will..."

    # say L64 pla
    old "W- what? You must be kidding me!"
    new "W-was? Du musst mich auf den Arm nehmen!"

    # say L68 lyd
    old "Don't be so shy baby"
    new "Sei nicht so schüchtern, Schatz"

    # say L69 lyd
    old "After all, it's not like you haven't done it before."
    new "Schließlich hast du es doch schon mal gemacht."

    # say L73 lyd
    old "Besides, I can see very clearly that you want it."
    new "Außerdem, ich sehe sehr deutlich, dass du es willst."

    # say L74 pla
    old "T- that's just because you woke me up that way!"
    new "D- das ist nur, weil du mich so geweckt hast!"

    # say L75 pla
    old "It- it will go down in a minute."
    new "Es- es wird sich in einer Minute beruhigen."

    # say L79 lyd
    old "Oh, but I can't let that happen!"
    new "Oh, aber das kann ich nicht zulassen!"

    # say L80 lyd
    old "I haven't had any breakfast yet, and I think I want some of your eggnog!"
    new "Ich hab' noch nichts gefrühstückt und ich denke, ich will ein bisschen von deinem Eggnog!"

    # say L87 lyd
    old "My god, I love the taste and smell of your dick!"
    new "Mein Gott, ich liebe den Geschmack und den Geruch deines Schwanzes!"

    # say L88 lyd
    old "I'm already so wet!"
    new "Ich bin schon so nass!"

    # say L89 lyd
    old "What a shame we don't have much time."
    new "Schade, dass wir nicht viel Zeit haben."

    # say L90 lyd
    old "Otherwise I'd like to do something else..."
    new "Sonst würde ich gerne noch was anderes machen..."

    # say L99 lyd
    old "Well, that was a great way to start the day, right [pla]?"
    new "Na, das war doch eine tolle Art, den Tag zu beginnen, oder [pla]?"

    # say L101 lyd
    old "I'll go say good morning to the rest of the family."
    new "Ich geh mal den Rest der Familie guten Morgen sagen."

    # say L102 lyd
    old "So, you can get dressed in peace."
    new "Dann kannst du dich in Ruhe anziehen."

    # say L103 pla
    old "Uhh... sure."
    new "Uhh... klar."

    # say L113 pla
    old "W- what? What was that? What's happening?"
    new "W-was? Was war das? Was passiert hier?"

    # say L114 sis
    old "I was asking you if you had a minute, I have something to show you..."
    new "Ich hab dich gefragt, ob du einen Moment hast, ich hab was zu zeigen..."

    # say L116 sis
    old "Excuse me?"
    new "Entschuldigung?"

    # say L117 pla
    old "Uhh, nevermind... Uhh, what do you want to show me?"
    new "Uhh, egal... Uhh, was willst du mir zeigen?"

    # say L119 sis
    old "Hmm, come to my bedroom with me."
    new "Hmm, komm mit mir in mein Schlafzimmer."

    # say L120 pla
    old "Uh, sure."
    new "Uh, klar."

    # say L137 sis
    old "So, I wanted to show you the new Christmas clothes that just arrived."
    new "Dann wollte ich dir die neuen Weihnachtspullis zeigen, die gerade angekommen sind."

    # say L138 sis
    old "They're for the shop."
    new "Sie sind für den Shop."

    # say L141 pla
    old "That's great [sis]."
    new "Das ist toll [sis]."

    # say L142 sis
    old "Do you want to see them?"
    new "Willst du sie sehen?"

    # say L145 sis
    old "Great! Just wait here."
    new "Super! Warte hier mal."

    # say L157 sis
    old "Ok, this is the first one, what do you think?"
    new "Ok, das ist der erste, was denkst du?"

    # say L158 pla
    old "I think it's great, very festive, it suits you."
    new "Ich finde es toll, sehr festlich, es steht dir."

    # say L159 pla
    old "I'm sure it's going to sell great."
    new "Ich bin sicher, dass es super verkauft wird."

    # say L160 sis
    old "That's just what I thought."
    new "Das dachte ich mir auch."

    # say L161 sis
    old "Let me show you the other one."
    new "Lass mich dir den anderen zeigen."

    # say L177 sis
    old "So, what about this one?"
    new "Was hältst du von diesem?"

    # say L178 sis
    old "This one is my favorite."
    new "Dieses ist mein Lieblingsstück."

    # say L180 pla
    old "I- I mean, it looks great on you."
    new "I- Ich meine, es sieht toll an dir aus."

    # say L181 pla
    old "I'm not sure this counts as an outfit per se."
    new "Ich bin mir nicht sicher, ob man das als Outfit bezeichnen kann."

    # say L185 pla
    old "But maybe it will sell well as lingerie."
    new "Aber vielleicht wird es als Dessous gut verkaufen."

    # say L186 pla
    old "This one could also be good for the ladies that want to surprise their husbands and boyfriends."
    new "Dieses könnte auch gut für die Damen sein, die ihre Männer und Freunde überraschen wollen."

    # say L187 sis
    old "Yeah, and it's very comfortable too."
    new "Ja, und es ist auch sehr bequem."

    # say L188 sis
    old "The fabric's very soft."
    new "Das Material ist sehr weich."

    # say L201 pla
    old "Uhhh... What are we doing [sis]?"
    new "Uhhh... Was machen wir hier [sis]?"

    # say L202 sis
    old "Oh well, I just want you to feel the fabric."
    new "Oh, ich will doch nur, dass du das Material spürst."

    # say L203 sis
    old "What do you think? Isn't it soft?"
    new "Was denkst du? Ist es nicht weich?"

    # say L204 pla
    old "I- I guess it is, yeah..."
    new "I- Ich schätze, es ist das, ja..."

    # say L206 sis
    old "But how much do you like it?"
    new "Aber wie sehr magst du es?"

    # say L207 sis
    old "Let me see how you feel down here..."
    new "Lass mich sehen, wie du dich hier unten fühlst..."

    # say L213 pla
    old "W- What are you doing [sis]?!"
    new "W- Was machst du da [sis]?!"

    # say L214 sis
    old "I just wanted to see how much you like my outfit..."
    new "Ich wollte nur sehen, wie sehr dir mein Outfit gefällt..."

    # say L220 sis
    old "And oh my god! Look at that!"
    new "Und oh mein Gott! Schau dir das an!"

    # say L221 sis
    old "You clearly really like it!"
    new "Du findest es echt toll, oder?"

    # say L222 pla
    old "Uh... I- I mean."
    new "Uh... Ich... ich meine."

    # say L223 sis
    old "It's ok [pla] I know you love it."
    new "Es ist okay [pla] ich weiß, dass du es liebst."

    # say L224 sis
    old "Just look at that big cock!"
    new "Schau dir nur diesen großen Schwanz an!"

    # say L225 sis
    old "What I could with it..."
    new "Was ich damit machen könnte..."

    # say L239 sis
    old "I'm sure the clients will love this new line!"
    new "Ich bin sicher, die Kunden werden diese neue Linie lieben!"

    # say L240 pla
    old "Umm, yeah, I guess they will."
    new "Klar, ich denke auch."

    # say L241 pla
    old "Hey, listen [sis]... Do you feel well?"
    new "Hey, hör mal [sis]... Geht's dir gut?"

    # say L242 sis
    old "Me? I feel great!"
    new "Ich? Mir geht's super!"

    # say L246 sis
    old "Why do you ask?"
    new "Warum fragst du?"

    # say L247 pla
    old "No reason, it's just a strange feeling..."
    new "Kein Grund, es ist nur ein komisches Gefühl..."

    # say L248 pla
    old "You know what? Forget it, it must be my imagination."
    new "Weißt du was? Lass es, es muss meine Einbildung sein."

    # say L250 sis
    old "Well, I have to work on some things for the website, you can leave now."
    new "Na ja, ich muss noch ein paar Dinge für die Website machen, du kannst jetzt gehen."

    # say L252 pla
    old "Uhh, right..."
    new "Uhh, klar..."

    # say L262 pla
    old "Uhh... That was weird..."
    new "Uhh... Das war seltsam..."

    # say L263 pla
    old "I still has that strange feeling... What was that?"
    new "Ich hab immer noch dieses komische Gefühl... Was war das?"

    # say L264 pla
    old "Anyway, I better go downstairs and see what happened with Lydia..."
    new "Jedenfalls, ich geh besser runter und sehe nach, was mit Lydia los ist..."

    # say L286 mo1
    old "Ah! [pla] honey!"
    new "Ah! [pla] Liebling!"

    # say L287 mo1
    old "You've arrived, wonderful!"
    new "Sie sind angekommen, wunderbar!"

    # say L288 mo1
    old "We're opening our Christmas gifts, you're just in time."
    new "Wir machen gerade unsere Weihnachtsgeschenke auf, du kommst genau richtig."

    # say L290 mo2
    old "It's your turn now [mo1], and this one's from me, why don't you open it?"
    new "Jetzt bist du dran [mo1], das hier ist von mir, mach es doch auf."

    # say L298 mo1
    old "Oh! Honey! Thank you!"
    new "Oh! Schatz! Danke!"

    # say L299 mo1
    old "I can't wait to see what it is!"
    new "Ich kann es kaum abwarten zu sehen, was es ist!"

    # say L306 mo1
    old "Oh my god [mo2]! This is just what I wanted!"
    new "Oh mein Gott [mo2]! Das ist genau das, was ich wollte!"

    # say L308 pla
    old "(Is that a bottle of lube?)"
    new "Ist das eine Flasche Gleitgel?"

    # say L313 mo1
    old "Of course I do! This is my favorite brand!"
    new "Natürlich tue ich das! Das ist meine Lieblingsmarke!"

    # say L314 mo2
    old "You know, this lube is very good because it enhance all sensations."
    new "Sie wissen, dieses Gleitgel ist sehr gut, weil es alle Empfindungen verstärkt."

    # say L315 pla
    old "(Holy shit, yes it is...)"
    new "Verdammt, ja, das ist es..."

    # say L319 mo2
    old "So, when we use it you can feel even harder when you're getting railed."
    new "So, wenn wir es benutzen, kannst du es noch intensiver spüren, wenn du geritten wirst."

    # say L320 pla
    old "(What the... Why are they talking like that in front of Lydia...)"
    new "Was zum... Warum reden die so vor Lydia..."

    # say L324 mo1
    old "Oh honey! That sounds fantastic! We have to use it as soon as we can!"
    new "Oh Schatz! Das klingt fantastisch! Wir müssen es so schnell wie möglich ausprobieren!"

    # say L325 mo2
    old "Off course! I really enjoy this one, is really warm..."
    new "Natürlich! Ich finde es wirklich toll, es ist so warm..."

    # say L326 mo2
    old "We have to put it to the test to see if you like it."
    new "Wir müssen es ausprobieren, um zu sehen, ob es dir gefällt."

    # say L331 lyd
    old "Oh please, stop..."
    new "Oh bitte, hören Sie auf..."

    # say L337 lyd
    old "Come on [mo2], is this a gift for [mo1], or is it a gift for you?"
    new "Komm schon [mo2], ist das ein Geschenk für [mo1] oder für dich?"

    # say L339 pla
    old "(What the...)"
    new "Was zum..."

    # say L344 mo1
    old "There's no reason why it couldn't be for the both of us!"
    new "Es gibt keinen Grund, warum es nicht für uns beide sein könnte!"

    # say L345 mo1
    old "As long as we both enjoy it, who cares who it is for!"
    new "Solange wir beide Spaß daran haben, wer kümmert sich darum, wem es eigentlich gilt!"

    # say L350 mo2
    old "That's right Lydia, relax."
    new "Das ist richtig Lydia, entspann dich."

    # say L356 mo2
    old "After all, I can fuck [mo1] with it, but she can also rail me later."
    new "Immerhin kann ich es mit [mo1] ficken, aber sie kann mich später auch durchnehmen."

    # say L357 lyd
    old "I guess you're right [mo1], [mo2]."
    new "Ich schätze, du hast recht [mo1], [mo2]."

    # say L358 lyd
    old "All gifts should be enjoyed equally."
    new "Alle Geschenke sollten gleichermaßen genossen werden."

    # say L359 lyd
    old "I think everybody should get to have a good time with these gifts."
    new "Ich denke, jeder sollte mit diesen Geschenken einen schönen Abend haben."

    # say L360 mo1
    old "Oh, I agree with that."
    new "Oh, da stimme ich zu."

    # say L362 pla
    old "Uhh... W- what is happening?"
    new "Uhh... W- was passiert hier?"

    # say L367 mo1
    old "Thinking about it... [pla], you haven't opened your presents yet."
    new "Bei genauerem Nachdenken... [pla], Sie haben Ihre Geschenke ja noch gar nicht ausgepackt."

    # say L368 pla
    old "M- me?"
    new "M- mir?"

    # say L370 pla
    old "I think I'm ok for now."
    new "Ich denke, ich bin fürs Erste okay."

    # say L371 pla
    old "I'll open my gifts later."
    new "Ich werde meine Geschenke später öffnen."

    # say L372 lyd
    old "Don't be foolish sweetie! You have to open them right now!"
    new "Sei nicht albern, Liebes! Du musst sie jetzt aufmachen!"

    # say L373 mo2
    old "Otherwise it is no fun."
    new "Sonst ist es kein Spaß."

    # say L374 mo1
    old "That's right [pla], come honey, open your presents."
    new "Das ist richtig [pla], komm Schatz, mach deine Geschenke auf."

    # say L382 pla
    old "I- I'm not sure I should."
    new "Ich bin mir nicht sicher, ob ich das sollte."

    # say L387 mo2
    old "Don't be a brag and do it!"
    new "Seien Sie kein Spielverderber und machen Sie mit!"

    # say L401 pla
    old "W- WHAT THA FUCK? THIS WEIRD THING AGAIN???"
    new "W- WAS ZUM TEUFEL? DIESER VERRÜCKTE SACH WIEDER???"

    # say L402 mo1
    old "Oh, don't worry honey, this is just one of your Christmas gifts."
    new "Oh, mach dir keine Sorgen, Schatz, das ist nur eines deiner Weihnachtsgeschenke."

    # say L403 mo1
    old "After all you have been such a good boy this year."
    new "Schließlich warst du dieses Jahr so ein braver Junge."

    # say L404 mo2
    old "And we have been such naughty girls."
    new "Und wir waren solche böse Mädchen."

    # say L405 lyd
    old "So, just relax and let us take care of you for a chance."
    new "Dann entspann dich einfach und lass uns mal für dich sorgen."

    # say L407 pla
    old "{i}(Lydia had already been acting weird since this morning.){/i}"
    new "{i}(Lydia war schon seit heute Morgen komisch drauf.){/i}"

    # say L409 pla
    old "{i}(Not to mention the way [sis] was acting when I went into her room...){/i}"
    new "{i}(Nicht zu vergessen, wie [sis] sich verhalten hat, als ich in ihr Zimmer gegangen bin...){/i}"

    # say L430 pla
    old "Woww... That thing again... I'm starting to feel dizzy..."
    new "Woww... Das Ding noch mal... Ich werd' langsam schwindelig..."

    # say L431 sis
    old "God [pla], you're so hard!"
    new "Verdammt [pla], du bist so hart!"

    # say L432 pla
    old "(What the fuck?? Now is [sis] here too?)"
    new "Was zur Hölle?? Jetzt ist [sis] auch hier?"

    # say L434 sis
    old "And your cock is so big!"
    new "Und dein Schwanz ist so groß!"

    # say L435 lyd
    old "And your tongue is so good baby!"
    new "Und deine Zunge ist so gut, Baby!"

    # say L436 mo1
    old "Oh! [mo2] honey, I love how you eat me out!"
    new "Oh! [mo2] Liebling, ich liebe es, wie du mich verwöhnst!"

    # say L438 pla
    old "{i}(When am I going to have another dream like this?){/i}"
    new "{i}(Wann werde ich wieder so einen Traum haben?){/i}"

    # say L449 pla
    old "L- Linett, whoah! You're in my dream too?"
    new "L- Linett, wow! Du bist auch in meinem Traum?"

    # say L450 pla
    old "Did you come to join in on the fun?"
    new "Bist du gekommen, um mitzumachen?"

    # say L451 pla
    old "I mean, I haven't done it with shinigamis and humans simultaneously."
    new "Ich meine, ich hab's noch nie gleichzeitig mit Shinigamis und Menschen gemacht."

    # say L452 pla
    old "But it could be interesting! Hop in!"
    new "Aber es könnte interessant werden! Steig ein!"

    # say L453 lin
    old "What? What are you talking about?"
    new "Was? Wovon redest du?"

    # say L454 pla
    old "Oh come on, you don't have to act like you don't want it."
    new "Oh komm schon, du musst nicht so tun, als würdest du es nicht wollen."

    # say L455 pla
    old "This is a dream after all."
    new "Das ist doch nur ein Traum."

    # say L456 lin
    old "This isn't a dream you dumbass!"
    new "Das ist kein Traum, du Idiot!"

    # say L457 pla
    old "W- What? What do you mean?"
    new "W- Was? Was meinst du damit?"

    # say L458 lin
    old "As you heard, this isn't a dream!"
    new "Wie du gehört hast, das ist kein Traum!"

    # say L459 lin
    old "This is all real [pla]!"
    new "Das ist alles echt [pla]!"

    # say L460 lin
    old "Apparently the magic concentrating spell we did in the church."
    new "Scheinbar der Zauber, den wir in der Kirche gewirkt haben."

    # say L464 lin
    old "Seems to have affected reality in a way we couldn't predict."
    new "Scheint, dass es die Realität auf eine Weise beeinflusst hat, die wir nicht vorhersehen konnten."

    # say L465 lin
    old "The ritual was successful but it's now starting to gather magic from all around."
    new "Das Ritual war erfolgreich, aber es fängt jetzt an, Magie aus der ganzen Umgebung zu sammeln."

    # say L466 lin
    old "And given that most magic in this world is stored in human bodies, it's trying to force it out!"
    new "Und da die meisten magischen Energien in dieser Welt in menschlichen Körpern gespeichert sind, versucht es sie jetzt herauszuzwingen!"

    # say L470 lin
    old "When that happens to human bodies they start to feel their life energy deplete."
    new "Wenn das bei menschlichen Körpern passiert, spüren sie, wie ihre Lebensenergie schwindet."

    # say L474 lin
    old "So, all the weird human behavior is caused because of the magic power..."
    new "Dann sind all die seltsamen Verhaltensweisen der Menschen auf die magische Energie zurückzuführen..."

    # say L475 lin
    old "They're not really themselves, they're in a sort of magically unconscious state..."
    new "Sie sind nicht wirklich sie selbst, sie befinden sich in einem magischen Bewusstlosigkeitszustand..."

    # say L476 lin
    old "And if it isn't stopped now it will wreak havoc in this world."
    new "Und wenn es jetzt nicht gestoppt wird, wird es in dieser Welt Chaos anrichten."

    # say L477 lin
    old "Although it already started. So, we have very little time."
    new "Obwohl es schon angefangen hat. Also, wir haben sehr wenig Zeit."

    # say L481 lin
    old "Truth be told, when we did the last ritual I noticed something was odd."
    new "Ehrlich gesagt, beim letzten Ritual habe ich schon gemerkt, dass etwas komisch war."

    # say L482 lin
    old "I probably should've done something about it then."
    new "Ich hätte wahrscheinlich etwas dagegen unternehmen sollen."

    # say L483 lin
    old "But I didn't expect anything like this to happen."
    new "Aber ich habe nicht damit gerechnet, dass so etwas passiert."

    # say L484 pla
    old "I- I- I'm not getting it at all..."
    new "Ich- Ich- Ich verstehe überhaupt nichts..."

    # say L488 lin
    old "What I'm telling you is that reality is starting to fragment!"
    new "Was ich dir sage, ist, dass die Realität zu bröckeln beginnt!"

    # say L489 lin
    old "So, we have to hurry and do something about it!"
    new "Dann müssen wir uns beeilen und etwas dagegen unternehmen!"

    # say L493 lin
    old "The ritual we did was successful."
    new "Das Ritual, das wir durchgeführt haben, war erfolgreich."

    # say L494 lin
    old "The problem  is that there's not enough magic density in this world to just create a portal."
    new "Das Problem ist, dass es in dieser Welt nicht genug Magiedichte gibt, um einfach ein Portal zu erschaffen."

    # say L499 pla
    old "What can we do about it?"
    new "Was können wir dagegen tun?"

    # say L503 lin
    old "I have a couple ideas."
    new "Ich habe ein paar Ideen."

    # say L504 lin
    old "Honestly I don't know if what I'm thinking off will work."
    new "Ehrlich gesagt, ich weiß nicht, ob das, was ich mir überlegt habe, funktionieren wird."

    # say L505 lin
    old "So, we'll have to try a couple of things to see what sticks."
    new "Dann müssen wir ein paar Dinge ausprobieren, um zu sehen, was funktioniert."

    # say L506 lin
    old "But whatever it is we do."
    new "Aber egal was wir tun."

    # say L510 lin
    old "I'm sure we'll need the other three shinigami for it, so, let's go."
    new "Ich bin sicher, wir brauchen die anderen drei Shinigami dafür, also los."

    # say L528 lin
    old "W- What? Who are you?!"
    new "W- Was? Wer bist du?!"

    # say L529 bri
    old "What the fuck is going on here?!"
    new "Was zur Hölle geht hier ab?!"

    # say L530 lin
    old "Uh- Listen, I don't know who you are."
    new "Uh- Hör zu, ich weiß nicht, wer du bist."

    # say L535 lin
    old "I didn't even know there was another shinigami around."
    new "Ich wusste gar nicht, dass es noch einen Shinigami gibt."

    # say L536 lin
    old "But nice to meet you... I guess. I'm Linnet."
    new "Aber nett, dich kennenzulernen... schätze. Ich bin Linnet."

    # say L540 lin
    old "Listen, right now there's no time for us to talk."
    new "Hör zu, im Moment haben wir keine Zeit zum Reden."

    # say L541 lin
    old "In case you haven't noticed, reality is tearing itself apart!"
    new "Falls dir das noch nicht aufgefallen ist, die Realität zerfällt!"

    # say L542 lin
    old "Are you going to help us or not?!"
    new "Wirst du uns helfen oder nicht?!"

    # say L543 bri
    old "Oh, I know full well who you are!"
    new "Oh, ich weiß genau, wer du bist!"

    # say L547 bri
    old "You're that idiot that keeps messing with the magic of this world!"
    new "Du bist dieses Idiot, der ständig die Magie dieser Welt durcheinanderbringt!"

    # say L553 bri
    old "Look at the mess you've made!"
    new "Schau dir das Chaos an, das du angerichtet hast!"

    # say L558 bri
    old "Not to mention that you keep setting [pla] down the wrong path!"
    new "Nicht zu vergessen, dass du [pla] ständig auf den falschen Weg bringst!"

    # say L559 bri
    old "Don't you see you're screwing our only chance of fixing the magical world?"
    new "Siehst du das nicht? Du versaust unsere einzige Chance, die magische Welt zu retten."

    # say L563 bri
    old "I'M NOT GOING TO LET YOU CONTINUE RUINING EVERYTHING!"
    new "Ich lasse dich nicht weiter alles vermasseln!"

    # say L583 pla
    old "B- Brixxida! W- What are you doing? She's an ally!"
    new "B- Brixxida! W- Was machst du da? Sie ist eine Verbündete!"

    # say L587 bri
    old "Oh! You shut up! Enough with the stupidities!"
    new "Oh! Du hältst jetzt die Klappe! Genug von deinem Unsinn!"

    # say L588 bri
    old "You've already ruined too many things."
    new "Du hast schon genug kaputtgemacht."

    # say L589 bri
    old "And I won't keep risking my life, this world, and the magic world."
    new "Und ich werde mein Leben, diese Welt und die magische Welt nicht weiter aufs Spiel setzen."

    # say L590 bri
    old "Because of the actions of a group of stupid inexperienced shinigamis."
    new "Wegen den Aktionen einer Gruppe dummer unerfahrener Shinigamis."

    # say L599 bri
    old "There, you take care of that."
    new "Da, du kümmert dich drum."

    # say L600 bri
    old "Put her some place where she won't be a bother."
    new "Stell sie irgendwo hin, wo sie nicht im Weg ist."

    # say L601 bri
    old "And come with me [pla], I'll fix this quickly."
    new "Und komm mit mir [pla], ich mache das schnell wieder gut."

    # say L634 pla
    old "So, what are we doing here?"
    new "Also, was machen wir hier?"

    # say L635 pla
    old "I don't see anything wrong..."
    new "Ich sehe nichts Falsches..."

    # say L636 bri
    old "Oh really? Use your Eye of Agamotto..."
    new "Oh wirklich? Benutz dein Auge von Agamotto..."

    # say L637 pla
    old "Uhh... Alright..."
    new "Uhh... Okay..."

    # say L647 pla
    old "Woah! What's this? What's happening?"
    new "Woah! Was ist das? Was passiert hier?"

    # say L648 bri
    old "This is what you and that idiot did!"
    new "Das ist das Ergebnis deiner und dieses Idioten Taten!"

    # say L652 bri
    old "What you're seeing is the result of a difficult spell being casted by an inexpert hand."
    new "Was du siehst, ist das Ergebnis eines schwierigen Zaubers, der von einer unerfahrenen Hand gewirkt wurde."

    # say L656 bri
    old "This is why you should've come to me with these things [pla]!"
    new "Das ist der Grund, warum du zu mir kommen solltest, wenn so was passiert [pla]!"

    # say L657 bri
    old "But it's ok, I'm here now."
    new "Aber es ist okay, ich bin jetzt hier."

    # say L658 pla
    old "Ok, but what's your plan to fix all this?"
    new "Okay, aber was ist dein Plan, um das alles zu beheben?"

    # say L659 bri
    old "Just watch."
    new "Guck einfach."

    # say L665 bri
    old "Now! Quick! We have to go to your house to stabilize it!"
    new "Jetzt! Schnell! Wir müssen zu deinem Haus, um es zu stabilisieren!"

    # say L667 pla
    old "Woah, Woah! What do you mean?!"
    new "Woah, Woah! Was meinst du damit?!"

    # say L668 pla
    old "Are you planning on putting that in my house?"
    new "Willst du das in mein Haus bringen?"

    # say L669 bri
    old "Don't worry nothing will happen."
    new "Keine Sorge, nichts passiert."

    # say L670 bri
    old "Unlike your little friend, I know how to do things properly."
    new "Im Gegensatz zu deinem kleinen Freund weiß ich, wie man das richtig macht."

    # say L672 bri
    old "So, let's hurry and go to your house!"
    new "Dann lass uns schnell zu deinem Haus gehen!"

    # say L674 pla
    old "R- Right!"
    new "R- Richtig!"

    # say L680 pla
    old "So, what now?"
    new "Und, was jetzt?"

    # say L681 bri
    old "I'm going to invoke the portal here."
    new "Ich werde das Portal hier aktivieren."

    # say L702 bri
    old "{b}*Sigh*{/b} That was dangerous."
    new "{b}*Seufz*{/b} Das war knapp."

    # say L703 bri
    old "But at least we now have a portal."
    new "Aber zumindest haben wir jetzt ein Portal."

    # say L707 pla
    old "Uhh... So, does that mean that we can go to the magical world now?"
    new "Uhh... Also, bedeutet das, dass wir jetzt in die magische Welt gehen können?"

    # say L709 bri
    old "Of course not. Going from one world to another is not that easy!"
    new "Natürlich nicht. Von einer Welt in die andere zu gelangen, ist nicht so einfach!"

    # say L710 bri
    old "To work, this portal needs a massive amount of magic to finish its development."
    new "Damit das funktioniert, braucht dieses Portal eine riesige Menge an Magie, um seine Entwicklung abzuschließen."

    # say L711 bri
    old "What it was doing before was sucking all of the magic power around, without any control or direction."
    new "Was es vorher getan hat, war, alle magischen Kräfte in der Umgebung ohne Kontrolle oder Richtung zu absorbieren."

    # say L715 bri
    old "That could've ended the world."
    new "Das hätte die Welt beenden können."

    # say L719 bri
    old "I just stabilized it so that it wouldn't continue extracting magic from all around and destroy the world."
    new "Ich hab's gerade stabilisiert, damit es nicht weiter Magie aus der Umgebung zieht und die Welt zerstört."

    # say L724 bri
    old "What we must do now is feed it magic power in a more controlled way."
    new "Was wir jetzt tun müssen, ist, es auf eine kontrolliertere Weise mit Magie zu versorgen."

    # say L728 pla
    old "Uh... ok."
    new "Uh... okay."

    # say L732 pla
    old "So, how do we feed it magic power now?"
    new "Also, wie füttern wir es jetzt mit Magie?"

    # say L736 bri
    old "Well, normally it would be just a simple issue of using the eye of Agamoto to stock up in magic power."
    new "Na ja, normalerweise wäre es einfach, das Auge von Agamoto zu benutzen, um die magische Energie aufzuladen."

    # say L737 bri
    old "And then just release it in the portal."
    new "Und dann einfach die Energie im Portal freisetzen."

    # say L741 bri
    old "But now, due to you and your little friend messing up."
    new "Aber jetzt, wegen dir und deinem kleinen Freund, der Mist gebaut hat."

    # say L742 bri
    old "It extracted a lot of free-flowing energy from the world."
    new "Es hat eine Menge freien Energie aus der Welt gezogen."

    # say L744 bri
    old "We can get it back, but it's going to take a longer time. And it will be a lot more dangerous."
    new "Wir können es zurückholen, aber es wird viel länger dauern. Und es wird viel gefährlicher werden."

    # say L748 bri
    old "All thanks to you and that stupid little shinigami with which you have been playing."
    new "Alles dank dir und diesem dummen kleinen Shinigami, mit dem du gespielt hast."

    # say L749 pla
    old "I'm sorry Brixxida, all I wanted was to help, you know?"
    new "Entschuldige Brixxida, ich wollte doch nur helfen, das weißt du, oder?"

    # say L753 bri
    old "Hmph."
    new "Hmpf."

    # say L754 pla
    old "So, what can we do to make the portal work?"
    new "Also, was können wir tun, um das Portal zum Laufen zu bringen?"

    # say L755 bri
    old "Well, the only way is to seed the magic power..."
    new "Na ja, der einzige Weg ist, die magische Kraft zu befruchten..."

    # say L757 pla
    old "Seed the magic power? What's that?"
    new "Magische Energie auffüllen? Was bedeutet das?"

    # say L758 bri
    old "It's a magic ritual we use to concentrate magic power."
    new "Es ist ein magischer Ritual, bei dem wir die magische Kraft konzentrieren."

    # say L759 bri
    old "By incubating it inside the bodies of humans."
    new "Durch das Einpflanzen in den Körper von Menschen."

    # say L760 bri
    old "The power grows and concentrates over time. Until it finally flows out and into the portal."
    new "Die Kraft wächst und konzentriert sich über die Zeit. Bis sie schließlich ausströmt und in das Portal fließt."

    # say L762 pla
    old "Ok, I think I get it. So, how do we do it?"
    new "Ok, ich glaube, ich hab's kapiert. Also, wie machen wir das?"

    # say L763 bri
    old "There's only one real way to do it. You have to plan the seed inside the body."
    new "Es gibt nur einen echten Weg, das zu tun. Du musst das Samenkorn im Körper pflanzen."

    # say L764 bri
    old "Once inside it gestates and grows, until it's time to come out."
    new "Drinnen reift es und wächst, bis es Zeit ist, herauszukommen."

    # say L766 pla
    old "Ok, but how do I do it?"
    new "Okay, aber wie mache ich das?"

    # say L768 bri
    old "Well, you have to seed them the same way you gather and give magic power out."
    new "Na ja, du musst sie auf die gleiche Weise befruchten, wie du Magie sammelst und gibst."

    # say L769 pla
    old "Woah! Woah! Woah! You mean I have to impregnate them?!"
    new "Woah! Woah! Woah! Du meinst, ich muss sie schwängern?!"

    # say L771 bri
    old "In human terms, that's what it's called, yeah."
    new "In menschlichen Begriffen, ja, so nennt man das."

    # say L773 pla
    old "What the fuck? Are you for real?"
    new "Was zum Teufel? Machst du Witze?"

    # say L774 pla
    old "I'm way too young to have children!"
    new "Ich bin viel zu jung, um Kinder zu haben!"

    # say L782 bri
    old "But don't worry, it's not the way you think."
    new "Aber mach dir keine Sorgen, es ist nicht so, wie du denkst."

    # say L784 bri
    old "During the growing period, the magic power will concentrate without a particular form."
    new "Während der Wachstumsphase konzentriert sich die magische Kraft ohne eine bestimmte Form."

    # say L787 bri
    old "And it will only change if, you decide it to be anything in particular."
    new "Und es wird sich nur verändern, wenn du entscheidest, dass es eine bestimmte Form annehmen soll."

    # say L789 bri
    old "It means that if you just take out all of the magic power from these women it will just be energy."
    new "Das bedeutet, wenn du all die magische Energie aus diesen Frauen entziehst, bleibt es einfach Energie."

    # say L790 bri
    old "Pure magic energy, without any form in particular."
    new "Reine magische Energie, ohne eine bestimmte Form."

    # say L791 bri
    old "And it will only take the shape of a human infant if you decide that you will leave energy remains behind."
    new "Und es wird nur die Form eines menschlichen Säuglings annehmen, wenn du entscheidest, Energiereste zurückzulassen."

    # say L793 bri
    old "Otherwise there won't be any reproduction between you and the humans we use for this ritual."
    new "Sonst wird es zwischen dir und den Menschen, die wir für diesen Ritual benutzen, keine Fortpflanzung geben."

    # say L795 pla
    old "I- I see, I guess that's..."
    new "Ich- Ich verstehe, schätze ich..."

    # say L796 pla
    old "Fine, I guess?"
    new "Na gut, schätze ich?"

    # say L798 bri
    old "However, until the magic power is ready to be taken out of their bodies and we do it."
    new "Allerdings, bis die magische Energie bereit ist, aus ihren Körpern entnommen zu werden, und wir es tun."

    # say L799 bri
    old "They will look like they are pregnant."
    new "Sie werden so aussehen, als wären sie schwanger."

    # say L801 bri
    old "The entire process it's going to be very similar to the way you humans gestate your infants."
    new "Der gesamte Prozess wird sich sehr ähnlich anfühlen, wie wenn ihr Menschen eure Babys austrägt."

    # say L802 bri
    old "Is just that at the end of it, there won't necessary be another human."
    new "Am Ende wird es aber nicht unbedingt ein weiterer Mensch sein."

    # say L803 bri
    old "So, their bodies will just go back to how they were before the ritual started."
    new "So, ihre Körper werden einfach wieder so sein wie vor dem Ritual."

    # say L805 pla
    old "I get it now."
    new "Ich verstehe jetzt."

    # say L806 bri
    old "Listen, I know you don't like it."
    new "Hör zu, ich weiß, dir gefällt das nicht."

    # say L807 bri
    old "But for now, that's the only way we have to power up the portal and return the magic world to what it was before."
    new "Aber für den Moment ist das der einzige Weg, um das Portal zu aktivieren und die magische Welt in ihren ursprünglichen Zustand zurückzubringen."

    # say L808 bri
    old "Not to mention avoiding the destruction of yours."
    new "Nicht zu vergessen, den Untergang deiner Welt zu verhindern."

    # say L809 pla
    old "I get it."
    new "Ich verstehe."

    # say L810 pla
    old "If I have to do it, I guess there's no choice."
    new "Wenn ich es machen muss, dann bleibt mir wohl nichts anderes übrig."

    # say L811 bri
    old "By the way; from now on, I will be in charge of everything, you get that?"
    new "Von jetzt an werde ich alles im Griff haben, das kapiert du doch?"

    # say L815 bri
    old "No more running around like an idiot with you dumbass shinigami friends messing everything up!!"
    new "Kein mehr rumlaufen wie ein Idiot mit deinen bescheuerten Shinigami-Freunden, die alles versaufen!"

    # say L816 pla
    old "Uh. I- sure..."
    new "Uh. Ich-sicher..."

    # say L817 bri
    old "Good, I'm glad you understand that."
    new "Gut, ich bin froh, dass du das verstehst."

    # say L819 bri
    old "Now, get ready, because there are a lot of things you will need to learn about all of this."
    new "Jetzt mach dich bereit, denn es gibt viele Dinge, die du über alles das lernen musst."

    # say L820 pla
    old "Oh, man... Alright..."
    new "Oh Mann... Okay..."

    # say L828 pla
    old "I guess I'll leave you here for now..."
    new "Dann lass ich dich jetzt erst mal hier."

    # say L829 pla
    old "I'm so sorry, about this Linnet."
    new "Es tut mir so leid, Linnet."

    # say L830 pla
    old "I promise that I will help you to get free from this."
    new "Ich verspreche, dass ich dir helfen werde, dich davon zu befreien."


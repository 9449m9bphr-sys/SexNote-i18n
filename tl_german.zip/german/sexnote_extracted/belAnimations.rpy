# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/belAnimations.rpy
translate german strings:

    # say L6 bil
    old "All right, how is that [pla]? Do you like how Belle jerks off your cock?"
    new "Okay, wie ist das [pla]? Gefällt dir, wie Belle deinen Schwanz wichst?"

    # say L7 pla
    old "Ohh yeah it feels really nice."
    new "Ohh ja, das fühlt sich echt gut an."

    # say L12 bil
    old "Ugh! That's really a big dick... Have you seen one like that before Belle?"
    new "Ugh! Das ist wirklich ein großer Schwanz... Hast du schon mal so einen gesehen, Belle?"

    # say L13 bel
    old "N- no, I had never seen a cock this big."
    new "N-nein, ich habe noch nie einen so großen Schwanz gesehen."

    # say L14 bil
    old "He seems to like it like that, keep going."
    new "Er scheint es zu mögen, mach weiter."

    # say L18 bil
    old "Keep going Belle! Don't stop."
    new "Weitermachen Belle! Hör nicht auf."

    # say L19 bil
    old "Do you like that [pla]?"
    new "Magst du das [pla]?"

    # say L20 pla
    old "Mmmm... Y- yeah."
    new "Mmmm... J- ja."

    # say L21 bel
    old "It's soo hard in my hand, right now!"
    new "Es ist so hart in meiner Hand, gerade jetzt!"

    # say L44 pla
    old "I-I think I'm cuming!"
    new "Ich glaube, ich komme!"

    # say L46 bil
    old "Yes! Cum [pla]!"
    new "Ja! Komm [pla]!"

    # say L47 bil
    old "Cum in her face!"
    new "Komm ihr ins Gesicht!"

    # say L54 bel
    old "Ughh... You gotta be more careful [pla], I'm all covered with cum now."
    new "Ughh... Du musst vorsichtiger sein [pla], ich bin jetzt total voll damit."

    # say L55 pla
    old "S- sorry, I couldn't really help it."
    new "S- sorry, ich konnte es echt nicht verhindern."

    # say L56 bil
    old "Hah! What's the matter Belle?"
    new "Hah! Was ist los, Belle?"

    # say L57 bil
    old "Aren't you happy you gave him a good time."
    new "Bist du etwa nicht froh, ihm einen schönen Abend bereitet zu haben?"

    # say L58 bel
    old "Phew, yeah right! As if I wanted this sticky thing on me."
    new "Puh, ja klar! Als ob ich das klebrige Zeug auf mir haben wollen würde."

    # say L59 bel
    old "Wait a minute, I'll clean myself."
    new "Warte mal, ich reinige mich."

    # say L71 sis2
    old "Oh! Oh my gosh!"
    new "Oh! Oh mein Gott!"

    # say L72 sis2
    old "This cock!"
    new "Dieser Schwanz!"

    # say L73 sis2
    old "It's so good!"
    new "Es ist so gut!"

    # say L77 sis2
    old "I love how deep into my throat it's going!"
    new "Ich liebe, wie tief es in meinen Hals geht!"

    # say L78 sis2
    old "Oh! Yeah! Do you guys like this?"
    new "Oh! Ja! Macht euch das auch so an?"

    # say L79 sis2
    old "Seeing this huge cock fill my mouth up?!"
    new "Das ist unglaublich, wie dieser riesige Schwanz meinen Mund ausfüllt?!"

    # say L83 sis2
    old "Yes! Yes! Yes!"
    new "Ja! Ja! Ja!"

    # say L84 sis2
    old "Oh my gosh this is the best taste ever!"
    new "Oh mein Gott, das ist der beste Geschmack überhaupt!"

    # say L85 sis2
    old "I can't get enough of this taste!"
    new "Ich kann nicht genug davon kriegen!"

    # say L108 sis2
    old "Oh my gosh!"
    new "Oh mein Gott!"

    # say L109 sis2
    old "He's about to fill my mouth with his cum!"
    new "Er wird gleich meinen Mund mit seinem Sperma füllen!"

    # say L110 sis2
    old "Do you want to see it?"
    new "Willst du es sehen?"

    # say L117 sis2
    old "That was fantastic guys!"
    new "Das war fantastisch, Leute!"

    # say L118 sis2
    old "And it's all thanks to your tips!"
    new "Und das alles dank euren Tipps!"

    # say L119 sis2
    old "If you want to see me getting fucked in the future remember to subscribe to premium and keep tipping."
    new "Wenn ihr mich in Zukunft ficken sehen wollt, denkt daran, das Premium-Abonnement zu nehmen und weiter zu tippen."

    # say L120 sis2
    old "And of course, join my fan club so you can download the video of this streaming."
    new "Und natürlich, tritt meinem Fanclub bei, damit du das Video von diesem Stream herunterladen kannst."

    # say L132 bel
    old "What great dick this is"
    new "Was für ein toller Schwanz das ist"

    # say L133 bel
    old "I love the way it feels in my hand!"
    new "Ich liebe, wie es sich in meiner Hand anfühlt!"

    # say L134 bel
    old "It's so big and so nice!"
    new "Es ist so groß und so schön!"

    # say L138 bel
    old "Do you like how I stroke it?"
    new "Magst du, wie ich es streichle?"

    # say L139 bel
    old "Do you like how I grab your big dick in my hand?"
    new "Magst du, wie ich deinen großen Schwanz in der Hand halte?"

    # say L140 bel
    old "It's such a nice big cock!"
    new "Es ist so ein schöner großer Schwanz!"

    # say L144 bel
    old "Oh my god!"
    new "Oh mein Gott!"

    # say L146 bel
    old "So big and hot!"
    new "So groß und heiß!"

    # say L169 bel
    old "I can feel you're about to cum!"
    new "Ich spüre, dass du gleich kommst!"

    # say L170 bel
    old "Your dick is twitching so hard in my hand!"
    new "Deine Schwanz zuckt so heftig in meiner Hand!"

    # say L171 bel
    old "Come! I want you to see you do it!"
    new "Komm! Ich will sehen, wie du es tust!"

    # say L177 bel
    old "That was sooo good!"
    new "Das war soo gut!"

    # say L178 bel
    old "But that's not all we're doing today guys!"
    new "Aber das ist noch nicht alles, was wir heute machen!"

    # say L179 bel
    old "Why don't I show you what I have next for you?"
    new "Warum zeige ich euch nicht, was ich als Nächstes für euch habe?"

    # say L194 bel
    old "Mmm! The taste of this big cock!"
    new "Mmm! Der Geschmack dieses großen Schwanzes!"

    # say L195 bel
    old "It's so hot and thick!"
    new "Es ist so heiß und dick!"

    # say L196 bel
    old "You guys wanted this, didn't you?"
    new "Ihr wolltet das doch, oder?"

    # say L206 bel
    old "Do you like how I stuff my mouth with your dick?"
    new "Magst du, wie ich deinen Schwanz in meinen Mund stopfe?"

    # say L207 bel
    old "I love it!"
    new "Ich liebe es!"

    # say L211 bel
    old "I love how you're filling my mouth with your big cock!!"
    new "Ich liebe es, wie du meinen Mund mit deinem großen Schwanz füllst!"

    # say L212 bel
    old "I can't get enough of it!"
    new "Ich kann einfach nicht genug davon kriegen!"

    # say L213 bel
    old "I love how it tastes!"
    new "Ich liebe, wie es schmeckt!"

    # say L217 bel
    old "My god! This taste is so good!"
    new "Mein Gott! Dieser Geschmack ist so gut!"

    # say L218 bel
    old "I love how you're ravishing my mouth!"
    new "Ich liebe, wie du mein Maul verwöhnst!"

    # say L219 bel
    old "I can't get enough of your dick guys!"
    new "Ich kann nicht genug von euren Schwänzen kriegen, Jungs!"

    # say L242 bel
    old "You guys want to cum in my mouth?"
    new "Wollt ihr in meinem Mund kommen?"

    # say L244 bel
    old "I want you to fill my throat with your hot load!"
    new "Ich will, dass ihr mich mit eurem heißen Saft füllt!"

    # say L250 bel
    old "That was so good guys!"
    new "Das war so gut, Jungs!"

    # say L251 bel
    old "This cum is so good!"
    new "Dieser Saft ist so gut!"

    # say L252 bel
    old "It's just the best taste in the world!"
    new "Das ist einfach der beste Geschmack der Welt!"

    # say L273 bel
    old "Mmm! oh my god! I can never get enough of this dick!"
    new "Mmm! Oh mein Gott! Ich kann nie genug von diesem Schwanz kriegen!"

    # say L274 bel
    old "This has to be the most amazing dick in the world!"
    new "Das muss der unglaublichste Schwanz der Welt sein!"

    # say L275 bel
    old "I love how much it's filling my mouth!"
    new "Ich liebe, wie es meinen Mund ausfüllt!"

    # say L281 bel
    old "Do you guys like seeing me like this? Who would want to have me right in front of you like this?"
    new "Mögt ihr es, mich so zu sehen? Wer würde nicht wollen, mich direkt vor sich zu haben?"

    # say L282 bel
    old "Do you like the way this cock is filling in my entire mouth?!"
    new "Magst du, wie dieser Schwanz meinen ganzen Mund ausfüllt?!"

    # say L283 bel
    old "Oh yes! I can feel it pushing all the way to my throat!"
    new "Oh ja! Ich spüre es, wie es bis in meinen Hals vordringt!"

    # say L290 bel
    old "Mmm! Oh my god guys look at this!"
    new "Mmm! Oh mein Gott, Jungs, schaut euch das an!"

    # say L291 bel
    old "This cock is just as hard as it was a minute ago!"
    new "Dieser Schwanz ist genauso hart wie vor einer Minute!"

    # say L292 bel
    old "My god! It's so good!"
    new "Mein Gott! Es ist so gut!"

    # say L293 bel
    old "It doesn't matter what happens, it's always so great!!"
    new "Egal was passiert, es ist immer so toll!!"

    # say L294 bel
    old "I- Slrrp! I bet you guys like this don't you?"
    new "I- Schlürf! Ich wette, euch gefällt das, oder?"

    # say L295 bel
    old "I- Mmm! I love it!"
    new "I- Mmm! Ich liebe es!"

    # say L300 bel
    old "OH! Yes! This cock tastes so great!"
    new "OH! Ja! Dieser Schwanz schmeckt so gut!"

    # say L301 bel
    old "Slrrrp! Mmmm! I can't get enough of it!"
    new "Slrrrp! Mmmm! Ich kann einfach nicht genug davon kriegen!"

    # say L302 bel
    old "Oh God I love the way you're fucking my mouth!"
    new "Oh Gott, ich liebe es, wie du meinen Mund fickst!"

    # say L326 bel
    old "Oh god! I can feel you getting tense!"
    new "Oh Gott! Ich spür, wie du dich anspannst!"

    # say L327 bel
    old "You're about to cum, right guys?!"
    new "Du bist gleich soweit, oder Jungs?!"

    # say L328 bel
    old "Do it! Don't hold it back!"
    new "Mach es! Lass es raus!"

    # say L329 bel
    old "Throw your cum in my throat!"
    new "Werdet nicht zurückhaltend, lasst euren Saft in meinem Hals spritzen!"

    # say L336 bel
    old "I'm so happy you liked it too!"
    new "Ich bin so froh, dass dir das auch gefallen hat!"

    # say L337 bel
    old "Especially because we've managed to get to the goal!"
    new "Besonders weil wir es geschafft haben, das Ziel zu erreichen!"

    # say L338 bel
    old "So now we can go ahead and I can show you!"
    new "Dann können wir jetzt weitermachen und ich zeig's dir!"

    # say L339 bel
    old "Just give me a couple of minutes, we're going to get ready for what comes next."
    new "Gib mir einfach ein paar Minuten, wir bereiten uns auf das Nächste vor."

    # say L340 bel
    old "Don't go anywhere because I know you're going to love it!"
    new "Geh nirgendwo hin, denn ich weiß, dass du es lieben wirst!"

    # say L349 bel
    old "Oh! Yeah!"
    new "Oh! Ja!"

    # say L350 bel
    old "The feeling in my throath is so great!"
    new "Das Gefühl in meinem Hals ist so toll!"

    # say L355 bel
    old "I like it so much!"
    new "Mir gefällt es so gut!"

    # say L356 bel
    old "Do you like to see me sucking cock guys?!"
    new "Mögt ihr es, mich beim Blasen zu sehen, Jungs?!"

    # say L361 bel
    old "Oh, yeah! Yeah!"
    new "Oh, ja! Ja!"

    # say L362 bel
    old "Oh my god! This is so good!"
    new "Oh mein Gott! Das ist so gut!"

    # say L363 bel
    old "I can't imagine a better tasting dick than this!"
    new "Ich kann mir keinen besser schmeckenden Schwanz vorstellen als diesen!"

    # say L386 bel
    old "Oh yeah!"
    new "Oh ja!"

    # say L387 bel
    old "I can feel your dick twitching."
    new "Ich spür, wie dein Schwanz zuckt."

    # say L388 bel
    old "I know you're about to come!"
    new "Ich weiß, dass du gleich kommst!"

    # say L389 bel
    old "Do it guys! Cum in my mouth!"
    new "Macht es, Jungs! Kommt in meinen Mund!"

    # say L394 bel
    old "That was lovely guys!"
    new "Das war toll, Jungs!"

    # say L395 bel
    old "But we're not stopping here!"
    new "Aber wir hören jetzt nicht auf!"

    # say L396 bel
    old "Let's get to what you really want to see!"
    new "Lasst uns zu dem kommen, was ihr wirklich sehen wollt!"

    # say L411 bel
    old "Oh god! This is so amazing!"
    new "Oh Gott! Das ist unglaublich!"

    # say L412 bel
    old "My god! This sensation is so good!"
    new "Mein Gott! Dieses Gefühl ist so gut!"

    # say L421 bel
    old "Oh my god! Oh my god!"
    new "Oh mein Gott! Oh mein Gott!"

    # say L423 bel
    old "I love the way you're making me feel!"
    new "Ich liebe, wie du mich fühlen lässt!"

    # say L427 bel
    old "I can't get enough of this dick!"
    new "Ich kann nicht genug von diesem Schwanz kriegen!"

    # say L428 bel
    old "My pussy feels so good!"
    new "Meine Pussy fühlt sich so gut an!"

    # say L429 bel
    old "This dick is so hot! It's so good!"
    new "Dieser Schwanz ist so heiß! Es fühlt sich so gut an!"

    # say L433 bel
    old "Ugh! Oh yes! yes!"
    new "Ugh! Oh ja! ja!"

    # say L434 bel
    old "I love the way this feels!"
    new "Ich liebe, wie sich das anfühlt!"

    # say L436 bel
    old "My pussy feels so great!"
    new "Meine Pussy fühlt sich so gut an!"

    # say L459 bel
    old "I know you guys want to come inside of me!"
    new "Ich weiß, dass ihr beide kommen wollt!"

    # say L460 bel
    old "Do it! Fill my pussy again with your hot load!"
    new "Macht es! Füllt meine Pussy wieder mit eurem heißen Saft!"

    # say L461 bel
    old "I want to feel that cum inside me!"
    new "Ich will das Sperma in mir spüren!"

    # say L468 bel
    old "I knew you would like it!"
    new "Ich wusste, dass dir das gefallen würde!"

    # say L480 bel
    old "Oh god!"
    new "Oh Gott!"

    # say L481 bel
    old "This cock was so impressive before"
    new "Dieser Schwanz war schon vorher beeindruckend"

    # say L482 bel
    old "But now that I have it on my ass!"
    new "Aber jetzt, wo ich es in meinem Arsch habe!"

    # say L483 bel
    old "It's even better!"
    new "Es ist sogar noch besser!"

    # say L487 bel
    old "God! It's so good!"
    new "Oh Gott! Das ist so gut!"

    # say L488 bel
    old "I love how hard you're fucking my ass guys!"
    new "Ich liebe, wie hart ihr meinen Arsch fickt, Jungs!"

    # say L489 bel
    old "Mmm! Do you like the way you're stretching me?!"
    new "Mmm! Gefällt euch, wie ihr mich dehnt?!"

    # say L493 bel
    old "Oh! Oh! Yes!"
    new "Oh! Oh! Ja!"

    # say L494 bel
    old "Yes! Keep fucking me like that!"
    new "Ja! Fick mich weiter so!"

    # say L495 bel
    old "I love the way it's filling me!"
    new "Ich liebe, wie es mich ausfüllt!"

    # say L496 bel
    old "It's just stretching my ass!"
    new "Es dehnt meinen Arsch gerade richtig aus!"

    # say L519 bel
    old "OH yes! I can feel it!"
    new "OH ja! Ich spür's!"

    # say L520 bel
    old "You're about to cum aren't you?"
    new "Du bist doch gleich soweit, oder?"

    # say L521 bel
    old "Do it! Cum!"
    new "Mach es! Komm!"

    # say L522 bel
    old "Fill my ass with your hot cum!"
    new "Füll meinen Arsch mit deinem heißen Sperma!"

    # say L529 bel
    old "That was so awesome guys!"
    new "Das war so geil, Jungs!"

    # say L530 bel
    old "I knew you guys would do great today!"
    new "Ich wusste, dass ihr heute großartig sein würdet!"

    # say L531 bel
    old "And you didn't disappoint!"
    new "Und ihr habt mich nicht enttäuscht!"

    # say L543 amo
    old "Slrrp! Oh my god!"
    new "Slrrp! Oh mein Gott!"

    # say L544 amo
    old "What a great taste this dick has!"
    new "Was für ein toller Geschmack dieser Schwanz hat!"

    # say L545 amo
    old "Mmm! It feels so amazing in my mouth!"
    new "Mmm! Es fühlt sich so unglaublich in meinem Mund an!"

    # say L549 bel
    old "Do you like seeing us taste dick guys?"
    new "Magst du es zu sehen, wie wir Schwänze lutschen?"

    # say L550 bel
    old "It's so amazing to lick it!"
    new "Es ist so geil, es zu lecken!"

    # say L551 bel
    old "I love how hot it is!"
    new "Ich liebe, wie heiß es ist!"

    # say L556 amo
    old "This dick is so hard!"
    new "Dieser Schwanz ist so hart!"

    # say L557 amo
    old "And the taste! So amazing!"
    new "Und der Geschmack! So unglaublich!"

    # say L580 bel
    old "I can feel this dick twitching!"
    new "Ich kann spüren, wie dieser Schwanz zuckt!"

    # say L581 bel
    old "You want to see him cum because of our tongues don't you?!"
    new "Du willst sehen, wie er kommt, wegen unserer Zungen, oder?!"

    # say L582 amo
    old "Oh yes! I want to see that!"
    new "Oh ja! Ich will das sehen!"

    # say L589 bel
    old "Oh my God guys! You're amazing!"
    new "Oh mein Gott, Jungs! Ihr seid unglaublich!"

    # say L590 bel
    old "You actually did it!"
    new "Ihr habt es tatsächlich geschafft!"

    # say L591 bel
    old "You reached the goal!"
    new "Ihr habt das Ziel erreicht!"

    # say L592 bel
    old "And you know what that means."
    new "Und du weißt, was das bedeutet."

    # say L594 amo
    old "This is what I was waiting for!"
    new "Das war's, worauf ich gewartet habe!"

    # say L608 amo
    old "Mmm! Oh God yes! This is what I had been waiting for!"
    new "Mmm! Oh Gott ja! Das habe ich mir so gewünscht!"

    # say L609 amo
    old "What an amazing cock!"
    new "Was für ein unglaublicher Schwanz!"

    # say L618 amo
    old "Oh yeah [pla]!"
    new "Oh ja [pla]!"

    # say L619 bel
    old "Do you like how he's stretching her pussy?"
    new "Magst du, wie er sie fickt, Jungs?"

    # say L620 amo
    old "I love the way it feels!"
    new "Ich liebe das Gefühl!"

    # say L624 bel
    old "Do you like how he's fucking her guys?"
    new "Magst du, wie er sie fickt, Jungs?"

    # say L625 bel
    old "It's amazing isn't it?"
    new "Es ist unglaublich, oder?"

    # say L626 amo
    old "Oh my God! This cock is so amazing!"
    new "Oh Gott! Dieser Schwanz ist unglaublich!"

    # say L630 amo
    old "Oh God! Oh yes!"
    new "Oh Gott! Oh ja!"

    # say L631 amo
    old "Yes! Yes! Keep stretching my pussy!"
    new "Ja! Ja! Mach weiter, dehne mich!"

    # say L632 amo
    old "What a great cock! It's so hard! And so big!"
    new "Was für ein toller Schwanz! Er ist so hart! Und so groß!"

    # say L655 amo
    old "I- Ah! I can feel his dick twitching!"
    new "I- Ah! Ich spür, wie sein Schwanz zuckt!"

    # say L656 bel
    old "Are you about to cum?! Do it!"
    new "Bist du gleich soweit?! Mach es!"

    # say L657 bel
    old "Fill her up with your cum!"
    new "Füll sie mit deinem Saft!"

    # say L658 amo
    old "Yes! Oh yes! I want to feel it inside!"
    new "Ja! Oh ja! Ich will es in dir spüren!"

    # say L665 amo
    old "That was wonderful guys!"
    new "Das war wunderbar, Leute!"

    # say L666 amo
    old "I felt so amazing!"
    new "Das war unglaublich!"

    # say L667 amo
    old "To have my pussy stretched like that!"
    new "Das war fantastisch, Mädels! Meine Pussy zu spüren, wie sie sich dehnt!"

    # say L668 amo
    old "But now it's time for Belle's turn."
    new "Aber jetzt ist es Zeit für Belles Reihe."

    # say L669 bel
    old "Alright! I was waiting for this too."
    new "Okay! Ich hab auch darauf gewartet."

    # say L682 amo
    old "Oh! That's fucking hot to see!"
    new "Oh! Das ist verdammt heiß zu sehen!"

    # say L683 amo
    old "How does it feel Belle?"
    new "Wie fühlt es sich an, Belle?"

    # say L692 bel
    old "Hmm! I love it!"
    new "Hmm! Ich liebe es!"

    # say L693 bel
    old "I can never get enough of this dick!"
    new "Ich kann nie genug von diesem Schwanz kriegen!"

    # say L694 bel
    old "No matter how many times I have it!"
    new "Egal wie oft ich es habe!"

    # say L698 amo
    old "God that's just so good to see!"
    new "Gott, das ist einfach unglaublich zu sehen!"

    # say L699 amo
    old "Look at how that dick comes in and out of your pussy!"
    new "Schau dir an, wie dieser Schwanz in und aus deiner Pussy gleitet!"

    # say L704 bel
    old "OH! OH! God!"
    new "OH! OH! Gott!"

    # say L705 bel
    old "This dick! Is so good!"
    new "Dieser Schwanz! Ist so gut!"

    # say L706 bel
    old "I love it! It's so hot!"
    new "Ich liebe es! Es ist so heiß!"

    # say L707 bel
    old "Do you like fucking me guys?"
    new "Macht es euch Spaß, mich zu ficken?"

    # say L730 bel
    old "I- Oh! I can feel his dick twitching!"
    new "Ich- Oh! Ich spüre, wie sein Schwanz zuckt!"

    # say L731 bel
    old "I feel it coming!"
    new "Ich spür's kommen!"

    # say L732 amo
    old "Do it! Cum inside her! Fill her pussy!"
    new "Mach es! Spritz in sie ab! Füll ihre Pussy!"

    # say L740 bel
    old "I'm so happy you reached the goal!"
    new "Ich bin so glücklich, dass du es geschafft hast!"

    # say L741 bel
    old "You never disappoint me!"
    new "Du enttäuschst mich nie!"

    # say L742 amo
    old "It really was great!"
    new "Es war wirklich toll!"


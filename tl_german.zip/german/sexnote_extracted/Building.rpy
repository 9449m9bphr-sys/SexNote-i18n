# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Building.rpy
translate german strings:

    # say L96 pla
    old "Uhh... Yes..."
    new "Uhh... Ja..."

    # say L99 pla
    old "Ohh, alright, don't worry I will come tomorrow. Thank you."
    new "Ohh, okay, mach dir keine Sorgen, ich komme morgen. Danke."

    # say L132 pla
    old "Good morning Barbie..."
    new "Guten Morgen Barbie..."

    # say L141 pla
    old "Good afternoon Barbie..."
    new "Guten Nachmittag Barbie..."

    # say L145 pla
    old "I'm [pla]... I was wondering if I can find a Therapist in this business center."
    new "Ich bin [pla]... Ich wollte wissen, ob ich hier im Geschäftszentrum einen Therapeuten finden kann."

    # say L150 pla
    old "Wow great, Can I go to talk with her?"
    new "Wow toll, kann ich mit ihr sprechen?"

    # say L155 pla
    old "Hmmm, actually is for a friend of mine, but thanks that's all that I needed it."
    new "Hmmm, eigentlich ist es für einen Freund von mir, aber danke, das war alles, was ich brauchte."

    # say L160 pla
    old "Thank you..."
    new "Danke..."

    # say L164 pla
    old "Now I can talk with Mrs. Jade."
    new "Jetzt kann ich mit Mrs. Jade sprechen."

    # say L196 pla
    old "I was wondering if Dr. Johnson is in her office."
    new "Ich wollte wissen, ob Dr. Johnson in ihrem Büro ist."

    # say L200 pla
    old "Great, thanks"
    new "Großartig, danke"

    # say L217 joh
    old "Hey [pla], did you make an appointment?"
    new "Hey [pla], haben Sie einen Termin gemacht?"

    # say L218 pla
    old "Oh, no, I'm sorry, I just-"
    new "Oh, nein, es tut mir leid, ich hab' nur-"

    # say L219 joh
    old "Don't worry if you need anything just let me know."
    new "Machen Sie sich keine Sorgen, wenn Sie etwas brauchen, lassen Sie es mich einfach wissen."

    # say L220 pla
    old "Ok, Thanks."
    new "Okay, danke."

    # say L248 pla
    old "No, no, sorry I was just looking for Hinn. I have to go."
    new "Nein, nein, entschuldigen Sie, ich suchte nur nach Hinn. Ich muss los."

    # say L255 joh
    old "Hi [pla], welcome back."
    new "Hallo [pla], willkommen zurück."

    # say L256 pla
    old "Hi doctor Johnson, I'm here because you mentioned we could repeat some lessons..."
    new "Hallo Dr. Johnson, ich bin hier, weil Sie erwähnt haben, dass wir einige Lektionen wiederholen könnten..."

    # say L257 joh
    old "That's great! So, what lesson you want to practice?"
    new "Das ist großartig! Welche Lektion möchten Sie üben?"

    # menu L262 
    old "Lesson 1"
    new "Lektion 1"

    # say L264 joh
    old "Great choice. Let's go to the  practice room..."
    new "Große Wahl. Lassen Sie uns ins Übungsraum gehen..."

    # say L277 joh
    old "Just like that, try to keep it wet, and slowly move a bit faster..."
    new "So machen Sie weiter, versuchen Sie, es feucht zu halten und langsam etwas schneller zu werden..."

    # say L278 joh
    old "Keep doing it like that... Ahh"
    new "So machen Sie weiter... Ahh"

    # menu L283 
    old "Lesson 2"
    new "Lektion 2"

    # say L305 joh
    old "Let's do it!"
    new "Lassen Sie uns es tun!"

    # menu L314 
    old "Lesson 3"
    new "Lektion 3"

    # menu L332 
    old "Lesson 4"
    new "Lektion 4"

    # say L358 joh
    old "You did it wonderful, I'm glad to have you here again..."
    new "Sie haben es wunderbar gemacht, ich freue mich, Sie hier wieder zu haben..."

    # say L359 pla
    old "Definitely, I will pass by more often."
    new "Definitiv, ich werde öfter vorbeischauen."

    # say L360 joh
    old "It would be the best thing to do, we can enjoy a lot."
    new "Das wäre das Beste, wir können viel Spaß miteinander haben."

    # say L361 pla
    old "I don't doubt it."
    new "Ich zweifle daran nicht."

    # say L362 joh
    old "Hope to see you soon."
    new "Hoffe, Sie sehen mich bald."

    # say L363 pla
    old "Thank you, have a great day."
    new "Danke, einen schönen Tag noch."

    # say L364 joh
    old "Bye bye!"
    new "Auf Wiedersehen!"


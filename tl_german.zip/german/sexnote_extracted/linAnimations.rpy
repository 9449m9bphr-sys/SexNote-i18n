# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/linAnimations.rpy
translate german strings:

    # say L6 lin
    old "You're definitely very good at this, I can start to feel much more energy inside of me..."
    new "Du bist definitiv sehr gut darin, ich spüre schon viel mehr Energie in mir..."

    # say L7 pla
    old "Hmm... T- Thanks."
    new "Hmm... D- Danke."

    # say L11 lin
    old "Does it feels good, Huhh?"
    new "Fühlt sich gut an, hm?"

    # say L12 pla
    old "Y- yes... It feels great..."
    new "Y- ja... Es fühlt sich toll an..."

    # say L16 lin
    old "Come one, I want to suck every drop that comes out of you."
    new "Komm schon, ich will jeden Tropfen aus dir saugen."

    # say L17 pla
    old "Oh God..."
    new "Oh Gott..."

    # say L41 lin
    old "Yes, yes! Give it to me!"
    new "Ja, ja! Gib es mir!"

    # say L50 lin
    old "Alright, it's my time to ride you..."
    new "Okay, dann bin ich dran, dich zu reiten..."

    # say L51 lin
    old "I want you to drill me, like you did with that girl."
    new "Ich will, dass du mich fickst, wie du es mit diesem Mädchen gemacht hast."

    # say L67 lin
    old "Wow... You're so good at this."
    new "Wow... Du bist echt gut darin."

    # say L69 lin
    old "I love it! Don't stop... Don't Stop..."
    new "Ich liebe es! Hör nicht auf... Hör nicht auf..."

    # say L73 lin
    old "Ahhh.... Ahhh...."
    new "Ahhh.... Ahhhh...."

    # say L74 lin
    old "I can feel all your energy entering my body..."
    new "Ich spüre all deine Energie in meinem Körper..."

    # say L79 lin
    old "Ahhhhh... I want more."
    new "Ahhhhh... Ich will mehr."

    # say L80 lin
    old "More give me more! Harder! HARDER!"
    new "Mehr gib mir mehr! Fester! FESTER!"

    # say L104 lin
    old "Oh yeahh cum inside me! Give me all your load!"
    new "Oh jaahh fick mich härter! Gib mir deinen ganzen Saft!"

    # say L122 pla
    old "Wow... What are you doing? Why are you tying me up?"
    new "Wow... Was machst du da? Warum fesselst du mich?"

    # say L123 lin
    old "I like to play a little while I share my energy with you."
    new "Ich mag es, ein bisschen zu spielen, während ich meine Energie mit dir teile."

    # say L128 lin
    old "Ohhh, It's great to feel so much energy when I'm with you."
    new "Ohhh, es ist toll, so viel Energie zu spüren, wenn ich bei dir bin."

    # say L133 lin
    old "Yes! Yes! I can feel all your energy inside me!"
    new "Ja! Ja! Ich kann deine ganze Energie in mir spüren!"

    # say L134 lin
    old "Don't stop, don't stop!"
    new "Hör nicht auf, hör nicht auf!"

    # say L162 lin
    old "Oh, that was fun, isn't?"
    new "Oh, das war toll, oder?"


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/ladAnimations.rpy
translate german strings:

    # say L6 lad
    old "I'm stimulating your testicles while I masturbate you so I can get the maximum amount of semen out."
    new "Ich stimuliere Ihre Hoden, während ich Sie masturbiere, damit ich die maximale Menge Sperma herausbekomme."

    # say L11 lad
    old "How is it? Do you feel ok?"
    new "Wie ist es? Fühlen Sie sich okay?"

    # say L12 pla
    old "Y- yes ma'am"
    new "J- ja, Ma'am"

    # say L13 lad
    old "Just relax and let me do the job. I promise it won't feel bad."
    new "Beruhigen Sie sich und lassen Sie es mich machen. Ich verspreche, es wird sich nicht schlecht anfühlen."

    # say L17 pla
    old "O- ohhh! I- I think I'm getting close."
    new "O- ohhh! I- Ich glaube, ich komme gleich."

    # say L18 lad
    old "Yes! I can feel your body tensing up."
    new "Ja! Ich spüre, wie sich Ihr Körper anspannt."

    # say L19 lad
    old "Mmmm! It's so hard!"
    new "Mmmm! Es ist so hart!"

    # say L42 pla
    old "Ma'am I-I think I'm cumming!"
    new "Frau, ich glaube, ich komme!"

    # say L43 lad
    old "Yes! I want you to!!"
    new "Ja! Ich will, dass Sie es tun!"

    # say L44 lad
    old "Slurrp! That's it, let it all out!"
    new "Slurrp! Das ist es, lassen Sie es alles raus!"

    # say L50 lad
    old "That was impressive, you came a lot."
    new "Das war beeindruckend, Sie haben wirklich viel gekommen."

    # say L51 lad
    old "This will really help me a lot. I'm already starting to feel it's effects."
    new "Das wird mir wirklich helfen. Ich spüre die Wirkung schon."

    # say L52 pla
    old "Really? Already? Well, I'm happy it worked."
    new "Wirklich? Schon? Na, ich freue mich, dass es funktioniert hat."

    # say L53 lad
    old "It really did. And I can't believe you came that much."
    new "Es hat wirklich. Und ich kann nicht glauben, dass Sie so viel gekommen sind."

    # say L54 lad
    old "Although we made a bit of a mess."
    new "Obwohl wir ein bisschen Chaos veranstaltet haben."

    # say L55 pla
    old "Sorry, I sometimes can't control myself."
    new "Entschuldigung, manchmal kann ich mich einfach nicht beherrschen."

    # say L56 lad
    old "It's ok, you were helping me anyway. Just wait a second and I'll clean myself."
    new "Es ist okay, Sie haben mir ja sowieso geholfen. Warten Sie einfach einen Moment, ich putze mich schnell."

    # say L66 lad
    old "Just relax and enjoy it."
    new "Lassen Sie sich einfach gehen und genießen Sie es."

    # say L67 pla
    old "Y- yes ma'am."
    new "J- ja, Ma'am."

    # say L71 lad
    old "Ahh! I-I feel like I'm getting better already"
    new "Ahh! I-I es fühlt sich an, als würde ich schon besser werden."

    # say L73 lad
    old "Oh yes! Just like this..."
    new "Oh ja! Genau so..."

    # say L74 lad
    old "Keep going! Don't stop!"
    new "Weiter so! Mach nicht auf halbem Weg schlapp!"

    # say L78 lad
    old "Yes! Yes! I can feel it!"
    new "Ja! Ja! Ich spüre es!"

    # say L79 lad
    old "This is amazing! Your dick fills me up completely!"
    new "Das ist unglaublich! Dein Schwanz füllt mich vollständig aus!"

    # say L103 lad
    old "Cum, now! I want to feel your cum fill me up."
    new "Kommen Sie, jetzt! Ich will spüren, wie Sie mich ausfüllen."

    # say L104 pla
    old "Y- yes! I'm about to!"
    new "J- ja! Ich bin gleich soweit!"

    # say L105 lad
    old "That's it! Yes!"
    new "Das ist es! Ja!"

    # say L111 lad
    old "Phew! That was impressive [pla]. Not only are you that well endowed, you know how to use your penis."
    new "Puh! Das war beeindruckend [pla]. Nicht nur, dass du so gut ausgestattet bist, du weißt auch, wie man damit umgeht."

    # say L112 lad
    old "It's fantastic!"
    new "Das ist fantastisch!"

    # say L113 pla
    old "T- thank you Miss. I'm glad you liked it."
    new "D- danke, Miss. Ich freue mich, dass es dir gefallen hat."

    # say L114 pla
    old "And I hope I was of help."
    new "Und ich hoffe, ich konnte dir helfen."

    # say L115 lad
    old "Oh, I'm sure you were."
    new "Oh, ich bin sicher, dass Sie das waren."

    # say L116 lad
    old "You came a great amount. I have no doubt I'll feel better with this."
    new "Sie sind in großer Menge gekommen. Ich bin mir sicher, dass ich mich damit besser fühlen werde."

    # say L117 lad
    old "Now, we better get dressed, it's late and you have to go home."
    new "Nun, wir sollten uns besser anziehen, es ist spät und Sie müssen nach Hause gehen."

    # say L118 pla
    old "Yes ma'am."
    new "Ja, Ma'am."

    # say L130 lad
    old "Just relax. And Iet us do the work."
    new "Beruhigen Sie sich. Und lassen Sie uns die Arbeit machen."

    # say L131 lad
    old "We'll get you off in no time."
    new "Wir werden Sie bald zum Höhepunkt bringen."

    # say L133 pla
    old "Y- yes, I am."
    new "Y- ja, ich bin."

    # say L137 lad
    old "Your penis is always so impressive [pla]!"
    new "Ihr Penis ist immer so beeindruckend [pla]!"

    # say L138 lad
    old "Mmm, and it has such a nice taste!"
    new "Mmm, und es hat so einen schönen Geschmack!"

    # say L139 dan
    old "Slurrp! Your dick... it's so warm, and it feels so nice in my mouth."
    new "Slurrp! Dein Schwanz... er ist so warm und fühlt sich so gut in meinem Mund an."

    # say L140 bela
    old "I- it's so big..."
    new "Es ist so groß..."

    # say L144 bela
    old "Your dick it's so amazing! I can feel it throbbing!"
    new "Dein Schwanz ist so unglaublich! Ich spüre ihn pochen!"

    # say L145 lad
    old "Yes! just like this! it's so nice!"
    new "Ja! Genau so! Das fühlt sich so gut an!"

    # say L146 dan
    old "It's so long! And so thick!"
    new "Es ist so lang! Und so dick!"

    # say L147 lad
    old "I can feel it, you're getting close!"
    new "Ich spüre es, Sie kommen gleich!"

    # say L170 pla
    old "I- I think I'm gonna...!"
    new "Ich... ich glaube, ich komme...!"

    # say L171 bela
    old "Mmmm! Yes!"
    new "Mmmm! Ja!"

    # say L172 lad
    old "It's ok, do it. Cum for us!"
    new "Es ist in Ordnung, mach es. Komm für uns!"

    # say L177 lad
    old "That was amazing [pla]! How do you feel? I hope you're not too drained."
    new "Das war fantastisch [pla]! Wie fühlen Sie sich? Ich hoffe, Sie sind nicht zu erschöpft."

    # say L178 pla
    old "Not at all, I feel very well... I know I can keep going."
    new "Nicht im Geringsten, ich fühle mich sehr gut... Ich weiß, dass ich weitermachen kann."

    # say L179 bela
    old "Wow, Y- you're not tired? Amazing!"
    new "Wow, Y- Sie sind nicht müde? Amazing!"

    # say L180 dan
    old "Incredible, I'd never met anybody that wouldn't feel tired after getting a blowjob from one of us. Let alone three!"
    new "Unglaublich, ich habe noch nie jemanden getroffen, der nach einem Blowjob von einer von uns nicht müde wäre. Geschweige denn von dreien!"

    # say L181 lad
    old "I told you, this young man is the key for us to get better."
    new "Ich hab's dir gesagt, dieser junge Mann ist der Schlüssel für uns, um es besser zu machen."

    # say L182 lad
    old "And we're just getting started."
    new "Und wir sind gerade erst angefangen."

    # say L194 lad
    old "My god! Look at this, you just came, and yet your cock is still rock hard."
    new "Mein Gott! Schau dir das an, du bist gerade gekommen und dein Schwanz ist immer noch steinhart."

    # say L195 lad
    old "Amazing!"
    new "Unglaublich!"

    # say L196 dan
    old "Hurry up mother, I think you're wanting it."
    new "Schnell, Mama, ich glaube, du willst es."

    # say L197 lad
    old "Mmm, I am darling, I am."
    new "Mmm, ich bin es, Liebling, ich bin es."

    # say L198 lad
    old "Now [pla], let's beginning."
    new "Jetzt [pla], lass uns anfangen."

    # say L208 lad
    old "Uhhh... Your cock... It's so big!"
    new "Uhhh... Dein Schwanz... Er ist so groß!"

    # say L209 lad
    old "Mmm! It fills me up completely!"
    new "Mmm! Es füllt mich vollständig aus!"

    # say L210 bela
    old "Wow mother, he really is deep into you!"
    new "Wow Mama, er steckt wirklich tief in dir drin!"

    # say L214 bela
    old "Mmm, I can see you're enjoying it a lot!"
    new "Mmm, ich sehe, dass du es richtig genießt!"

    # say L215 lad
    old "Ahh! Yes dear, It would be... Ahh! Impossible not to."
    new "Ahh! Ja Liebes, es wäre... Ahh! Unmöglich nicht zu."

    # say L216 lad
    old "Oh yeah, just like this..."
    new "Oh ja, genau so..."

    # say L220 lad
    old "Ohh! Oh my god!"
    new "Ohh! Oh mein Gott!"

    # say L221 lad
    old "Ah, it feels so good!"
    new "Ah, das fühlt sich so gut an!"

    # say L222 lad
    old "Ahhh! I- I'm close! I can feel it!"
    new "Ahhh! I- Ich bin gleich soweit! Ich spüre es!"

    # say L246 pla
    old "M- Ma'am! I think I'm cumming!"
    new "M- Ma'am! Ich glaube, ich komme!"

    # say L247 lad
    old "Ah! Do it! I want you to! Cum!"
    new "Ah! Machen Sie! Ich will, dass Sie es tun! Kommen Sie!"

    # say L253 lad
    old "My god! That was impressive, you came so much."
    new "Mein Gott! Das war beeindruckend, du hast so viel gekommen."

    # say L255 pla
    old "Phew, glad I can help."
    new "Phew, froh, dass ich helfen konnte."

    # say L256 lad
    old "But you know, I shouldn't keep you for myself..."
    new "Aber Sie wissen, ich sollte Sie nicht für mich allein behalten..."

    # say L257 lad
    old "It's your turn Daniela..."
    new "Es ist Ihre Zeit, Daniela..."

    # say L270 dan
    old "I hope you're not tired from being with mother, because I've been waiting for this."
    new "Ich hoffe, du bist nicht müde von der Zeit mit Mutter, denn ich habe schon lange auf diesen Moment gewartet."

    # say L272 lad
    old "Daniela darling, I know our health is a little compromised."
    new "Daniela, Liebling, ich weiß, dass unsere Gesundheit ein bisschen angegriffen ist."

    # say L273 lad
    old "But there's no need to pressure him that much."
    new "Aber es ist nicht nötig, ihn so sehr zu bedrängen."

    # say L274 bela
    old "Haha, I don't think she meant it that way mother."
    new "Haha, ich glaube, sie hat das nicht so gemeint, Mama."

    # say L287 dan
    old "Ok, here we go."
    new "Ok, dann mal los."

    # say L288 dan
    old "Mmm! This cock, it's reaching all the way!"
    new "Mmm! Dieser Schwanz, er reicht bis ganz nach hinten!"

    # say L289 bela
    old "Uhh, it looks amazing!"
    new "Uhh, das sieht unglaublich aus!"

    # say L290 dan
    old "And it is! Mmm! So good."
    new "Und es ist! Mmm! So gut."

    # say L294 lad
    old "I can see that you're enjoying this [pla]."
    new "Ich sehe, dass Sie das genießen [pla]."

    # say L295 pla
    old "Mmm... Y- yes ma'am"
    new "Mmm... J- ja, Ma'am"

    # say L296 bela
    old "Heh, Daniela is enjoying it too mother."
    new "Heh, Daniela genießt es auch, Mutter."

    # say L297 dan
    old "I- It's so thick, and I feel so warm inside."
    new "E- Es ist so dick, und ich fühle mich so warm drin."

    # say L298 lad
    old "What about if you go a little faster [pla]?."
    new "Was wäre, wenn du ein bisschen schneller wirst [pla]?"

    # say L302 dan
    old "Oh, Oh god!"
    new "Oh, Oh Gott!"

    # say L303 dan
    old "Yes! Yes! Like that! Pound me more!"
    new "Ja! Ja! So! Mach weiter so! Fick mich härter!"

    # say L328 dan
    old "I can feel it! Your body it's tensing up!"
    new "Ich spür's! Dein Körper spannt sich an!"

    # say L330 dan
    old "Yes! Cum! Cum inside me!"
    new "Ja! Komm! Komm in mir!"

    # say L336 dan
    old "Wow, that was amazing."
    new "Wow, das war unglaublich."

    # say L337 bela
    old "Look how much you came. I can't believe it."
    new "Schau dir an, wie viel du gekommen bist. Ich kann es nicht fassen."

    # say L338 lad
    old "You never cease to surprise me [pla]."
    new "Du überraschst mich immer wieder [pla]."

    # say L339 bela
    old "I think it's my turn now mother."
    new "Ich denke, jetzt bin ich dran, Mutter."

    # say L351 bela
    old "Be gentle with me, ok?"
    new "Sei sanft zu mir, ok?"

    # say L352 bela
    old "I don't like it as rough as my sister."
    new "Ich mag es nicht so rau wie meine Schwester."

    # say L363 bela
    old "That's it, slowly. Mmm."
    new "Das ist es, langsam. Mmm."

    # say L364 bela
    old "Ah! I can feel how you stretch me."
    new "Ah! Ich spüre, wie du mich dehnst."

    # say L365 dan
    old "Yes sister, I felt it too. It's unbelievable."
    new "Ja Schwester, ich hab's auch gespürt. Es ist unglaublich."

    # say L366 bela
    old "Y- You can do it, a little harder"
    new "Y- Du kannst es, ein bisschen fester"

    # say L370 dan
    old "You like that big cock sis?"
    new "Du magst diesen großen Schwanz, Schwester?"

    # say L371 bela
    old "Ohh, yes, yes, just like that."
    new "Ohh, ja, ja, genau so."

    # say L372 lad
    old "That's it Bela, enjoy it darling."
    new "Das ist es, Bela, genieße es, Liebling."

    # say L373 bela
    old "P- please, go a little faster."
    new "P- bitte, mach es ein bisschen schneller."

    # say L378 bela
    old "I- It's soooo fucking big!"
    new "I- Es ist soooo verdammt groß!"

    # say L379 bela
    old "It's warming me up inside!"
    new "Es wärmt mich von innen auf!"

    # say L403 bela
    old "Yes! Me too!"
    new "Ja! Mir auch!"

    # say L409 lad
    old "Amazing, you have such amazing endurance."
    new "Erstaunlich, Sie haben eine solche Ausdauer."

    # say L410 dan
    old "And he still hard... "
    new "Und er ist immer noch hart..."

    # say L411 lad
    old "Hmm, do you think you could give us a little bit more?"
    new "Hmm, glauben Sie, dass Sie uns noch ein bisschen mehr geben können?"

    # say L412 pla
    old "Uhhh.... I- I think so."
    new "Uhhh.... I- Ich denke schon."

    # say L424 lad
    old "Mmmm, that was lovely [pla]."
    new "Mmmm, das war wunderbar [pla]."

    # say L425 pla
    old "T- Thanks ma'am."
    new "D- Danke, Ma'am."

    # say L426 lad
    old "You managed to do it with all three of us."
    new "Sie sind es tatsächlich mit uns dreien geschafft."

    # say L427 lad
    old "I think we can give you a little extra."
    new "Ich denke, wir können Ihnen ein bisschen Extra geben."

    # say L437 dan
    old "God! your cock still so hard."
    new "Mein Gott! Ihr Schwanz ist immer noch so hart."

    # say L438 lad
    old "I can see you still have some left in the tank. Give it to us."
    new "Ich sehe, Sie haben noch etwas übrig. Geben Sie es uns."

    # say L443 bela
    old "I love how big you are."
    new "Ich liebe, wie groß du bist."

    # say L444 lad
    old "It's got such a nice smell."
    new "Es hat einen so schönen Geruch."

    # say L445 dan
    old "Let's do it a faster mother."
    new "Lass es uns schneller machen, Mutter."

    # say L449 lad
    old "Yes! That's it! I love seeing you enjoy it."
    new "Ja! Genau so! Ich liebe es, dich dabei zu sehen, wie du es genießt."

    # say L450 bela
    old "It's so warm, and it's getting harder."
    new "Es ist so warm, und es wird härter."

    # say L451 bela
    old "I think he's about to cum."
    new "Ich glaube, er kommt gleich."

    # say L474 pla
    old "I- I think I'm cumming!"
    new "Ich- Ich glaube, ich komme!"

    # say L475 lad
    old "Yes! Let it all out! Cum all over us!"
    new "Ja! Lassen Sie es raus! Kommen Sie über uns!"

    # say L482 dan
    old "Wow, that was really intense."
    new "Wow, das war wirklich intensiv."

    # say L483 pla
    old "Yes, it was. I think I'm finally feeling a little tired."
    new "Ja, das war es. Ich glaube, ich bin endlich ein bisschen müde."

    # say L489 dan
    old "Hah! Just now? I did it only once with you, and I'm already tired!"
    new "Hah! Erst jetzt? Ich hab's nur einmal mit dir getan und bin schon müde!"

    # say L490 lad
    old "Wow [pla], just wow! You really had sex with all three of us and are ok."
    new "Wow [pla], einfach wow! Sie haben wirklich mit uns dreien geschlafen und sind noch okay."

    # say L491 pla
    old "Well, I wouldn't say I don't feel it. But I wanted to help."
    new "Na, ich würde nicht sagen, dass ich es nicht spüre. Aber ich wollte helfen."

    # say L492 lad
    old "And you did. Right girls?"
    new "Und Sie haben es getan. Stimmt's, Mädels?"

    # say L493 bela
    old "Yes, you really are a lifesaver."
    new "Ja, du bist wirklich ein Lebensretter."

    # say L494 dan
    old "That's right, this is great for us."
    new "Das stimmt, das ist toll für uns."

    # say L495 pla
    old "Thank you very much."
    new "Danke schön."

    # say L496 lad
    old "Well, why don't we get dressed? I think you probably need to rest at home [pla]."
    new "Nun, warum ziehen wir uns nicht an? Ich denke, Sie sollten sich zu Hause ausruhen [pla]."

    # say L513 lad
    old "How are you feeling girls?"
    new "Wie fühlen Sie sich, Mädchen?"

    # say L514 bela
    old "I feel amazing, that was so good, and I feel myself getting better already!"
    new "Ich fühle mich fantastisch, das war unglaublich gut, und ich merke schon, wie es mir besser geht!"

    # say L515 dan
    old "Yeah, me too. The amount of cum we were able to take is amazing."
    new "Ja, mir geht's auch so. Die Menge an Sperma, die wir geschluckt haben, ist unglaublich."

    # say L516 pla
    old "I'm happy I can be of help to you all."
    new "Ich freue mich, dass ich euch helfen konnte."

    # say L517 pla
    old "I think I should probably go home and rest."
    new "Ich denke, ich sollte jetzt nach Hause gehen und mich ausruhen."

    # say L518 lad
    old "That's fine. But before you leave, allow us to thank you once again for everything you've done for us."
    new "Das ist in Ordnung. Aber bevor Sie gehen, lassen Sie uns Sie noch einmal für alles danken, was Sie für uns getan haben."

    # say L519 bela
    old "T- that's right [pla] thank you very much."
    new "D- das stimmt [pla] vielen Dank."

    # say L520 dan
    old "Thank you [pla], please come soon again."
    new "Danke [pla], kommen Sie bald wieder."

    # say L521 pla
    old "Sure, you can count on me."
    new "Klar, du kannst dich auf mich verlassen."

    # say L522 lad
    old "Aww, you're an angel. Thank you so much."
    new "Ach, Sie sind ein Engel. Vielen Dank."


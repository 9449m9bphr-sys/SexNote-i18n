# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Garage.rpy
translate german strings:

    # say L23 pla
    old "Hello. I just came to know if you need more magic power?"
    new "Hallo. Ich wollte nur wissen, ob du noch mehr magische Kraft brauchst?"

    # say L25 mil
    old "I think I have enough. Thank you..."
    new "Ich denke, ich habe genug. Danke..."

    # say L27 pla
    old "Oh come on. In our deal you were supposed to receive magical power from me, so don't worry."
    new "Oh komm schon. Im Deal war doch, dass ich dir magische Kraft gebe, also mach dir keine Sorgen."

    # say L29 mil
    old "Hmm, okay, I'll visit you tonight to get a little more magic."
    new "Hmm, okay, ich besuch dich heute Nacht, um noch ein bisschen mehr Magie zu kriegen."

    # say L31 pla
    old "Great, it's good for us to help each other..."
    new "Super, es ist gut, wenn wir uns gegenseitig helfen..."

    # say L33 mil
    old "Ok, see you tonight."
    new "Ok, bis später."

    # menu L43 
    old "Ask for Magic Power"
    new "Magie anfragen"

    # say L45 pla
    old "Hello! I wanted to know if you have any magic power to share with me. You know, to keep improving my skills..."
    new "Hallo! Ich wollte wissen, ob du mir ein bisschen von deiner Magie geben kannst. Du weißt schon, um meine Fähigkeiten weiter zu verbessern..."

    # say L49 mil
    old "Well, if you really need it I have some magic power for you."
    new "Na klar, wenn du es wirklich brauchst, habe ich ein bisschen Magie für dich."

    # say L51 pla
    old "Thank you. I really appreciate it."
    new "Danke. Ich schätze das wirklich."

    # say L53 mil
    old "Don't mention it. This was part of our deal"
    new "Das war Teil unserer Abmachung."

    # say L57 mil
    old "Ok, I'm ready. Let's do it."
    new "Ok, ich bin bereit. Lass uns anfangen."

    # say L59 pla
    old "Alright, alright..."
    new "Okay, okay..."

    # say L68 mil
    old "Sorry, but I don't have enough to share for now..."
    new "Tut mir leid, aber ich habe im Moment nicht genug, um es zu teilen..."

    # say L70 pla
    old "Oh ok. No problem. I will come later."
    new "Oh okay. Kein Problem. Ich komme später."

    # say L72 mil
    old "Bye."
    new "Bis dann."

    # say L96 pla
    old "Oh come on. In our deal you were supposed to get magical power from me, I'll take care of you."
    new "Oh komm schon. Im Deal war doch, dass ich dir magische Kraft gebe und du dich um mich kümmerst."

    # say L98 gom
    old "Mmm, okay. I'll visit you tonight to get a little more magic."
    new "Mmm, okay. Ich besuch dich heute Nacht, um noch ein bisschen mehr Magie zu kriegen."

    # say L100 pla
    old "Great,I like helping you..."
    new "Super, ich mag es, dir zu helfen..."

    # say L114 pla
    old "Hello! I wanted to know if you have any magic power to share with me You know, to keep improving my skills..."
    new "Hallo! Ich wollte wissen, ob du noch ein bisschen magische Kraft für mich hast. Du weißt schon, um meine Fähigkeiten weiter zu verbessern..."

    # say L118 gom
    old "Yes I have some magic power to give you."
    new "Ja, ich habe ein bisschen magische Kraft für dich."

    # say L120 pla
    old "Oh, sweet. Thank you!"
    new "Oh, toll. Danke!"

    # say L122 gom
    old "No problem, your progress benefits us all"
    new "Kein Problem, dein Fortschritt nützt uns allen."

    # say L126 gom
    old "Are you ready?."
    new "Bist du bereit?"

    # say L128 pla
    old "Yes! Let's get to it..."
    new "Ja! Lass uns anfangen..."

    # say L140 pla
    old "Oh, ok. No worries. I will come later."
    new "Oh, ok. Keine Sorge. Ich komme später."

    # say L142 gom
    old "Buh bye."
    new "Bis dann."

    # say L163 pla
    old "Hi there, I just came to know if you need more magic power?"
    new "Hi da, ich wollte nur wissen, ob du noch mehr magische Kraft brauchst?"

    # say L165 dev
    old "Well, maybe I might need a little..."
    new "Na ja, vielleicht brauche ich ein bisschen..."

    # say L167 pla
    old "Great, in that case visit me tonight so I can give you some magical power..."
    new "Super, dann komm heute Abend zu mir, damit ich dir ein bisschen magische Kraft geben kann..."

    # say L169 dev
    old "With pleasure! I'll see you tonight..."
    new "Mit Vergnügen! Bis heute Abend..."

    # say L181 pla
    old "Hey! I wanted to know if you have any magic power to share with me. I want to keep improving my skills..."
    new "Hey! Ich wollte wissen, ob du noch magische Kraft mit mir teilen kannst. Ich will meine Fähigkeiten weiter verbessern..."

    # say L184 dev
    old "Of course! I have plenty to share with you."
    new "Natürlich! Ich habe genug, um es mit dir zu teilen."

    # say L188 dev
    old "You can ask me whenever you want. Whenever I have enough I will give it to you..."
    new "Du kannst mich jederzeit fragen. Sobald ich genug habe, gebe ich es dir..."

    # say L190 pla
    old "Nice! Thank you."
    new "Nett! Danke."

    # say L198 dev
    old "Hmmm... Unfortunately, I don't have enough right now..."
    new "Hmmm... Leider habe ich im Moment nicht genug..."

    # say L200 dev
    old "However, look for me in a couple of days and I will have accumulated more to give you..."
    new "Allerdings, such mich in ein paar Tagen wieder, dann habe ich mehr gesammelt, um es dir zu geben..."

    # say L202 dev
    old "Or... You could also share with me and I'll give it back to you, just for the fun of sharing... Hehe"
    new "Oder... Du könntest es auch mit mir teilen und ich gebe es dir zurück, einfach nur zum Spaß... Hehe"

    # say L204 pla
    old "Oh, don't worry, it's really nothing urgent."
    new "Oh, mach dir keine Sorgen, es ist wirklich nicht dringend."

    # say L206 dev
    old "Oh... Ok then."
    new "Oh... Okay dann."

    # menu L226 
    old "Magic Power"
    new "Magische Energie"

    # menu L230 
    old "What is the Magic Power?"
    new "Was ist die Magische Kraft?"

    # say L232 bri
    old "Well, Magical power is an energy that was produced naturally in the magical world..."
    new "Na ja, magische Energie ist eine Kraft, die natürlicherweise in der magischen Welt entstanden ist..."

    # say L234 bri
    old "After its destruction all that magical energy ended up in the human world, the problem is that now it does not reproduce anymore..."
    new "Nach der Zerstörung landete all diese magische Energie in der Menschenwelt, das Problem ist nur, dass sie sich jetzt nicht mehr vermehrt..."

    # say L236 bri
    old "Only the remains of great magical sources, and all magical beings that once existed will be extinguished forever..."
    new "Nur die Überreste großer magischer Quellen und alle magischen Wesen, die einst existierten, werden für immer ausgelöscht werden..."

    # say L238 pla
    old "Ok, I understand it better now."
    new "Ok, ich verstehe es jetzt besser."

    # say L240 bri
    old "Great! What else do you want to know?"
    new "Super! Was möchtest du noch wissen?"

    # menu L247 
    old "How to get Magic Power?"
    new "Wie bekomme ich Magie?"

    # say L249 bri
    old "You have in fact 4 ways..."
    new "Du hast tatsächlich 4 Möglichkeiten..."

    # say L250 bri
    old "1. Picking up in each place with the agamoto's eye."
    new "1. In jedem Ort mit dem Auge der Agamato aufsammeln."

    # say L251 bri
    old "2. Using Ayax's hand and automatically picking up when moving between locations."
    new "2. Ayax' Hand benutzen und automatisch aufheben, wenn du zwischen Orten wechselst."

    # say L252 bri
    old "3. Having high levels of arousal caused by sexual activity with women."
    new "Hohe Erregungsniveaus durch sexuelle Aktivitäten mit Frauen."

    # say L253 bri
    old "4. Ask me to share you with my magical power!"
    new "Frag mich, ob ich meine magische Kraft mit dir teilen soll!"

    # say L255 pla
    old "Ok, interesting..."
    new "Ok, interessant..."

    # say L257 bri
    old "My favorite is the last one, but only when you share with me yours too..."
    new "Mein Lieblings ist die letzte, aber nur wenn du mir auch deine teilst..."

    # say L259 pla
    old "Yes, I know..."
    new "Ja, ich weiß..."

    # say L261 bri
    old "Well, What else do you want to know?"
    new "Na, was willst du denn noch wissen?"

    # menu L272 
    old "Spells"
    new "Zauber"

    # menu L276 
    old "Agamoto's Eye"
    new "Agamotos Auge"

    # say L278 bri
    old "Agamoto was one of the most powerful magicians who specialized in ocular power."
    new "Agamoto war einer der mächtigsten Magier, der sich auf okulare Kräfte spezialisiert hat."

    # say L280 bri
    old "They say that his power even came to see the soul and thoughts of any being."
    new "Sie sagen, dass seine Macht sogar die Seele und Gedanken jedes Wesens sehen konnte."

    # say L282 bri
    old "That is why Agamoto is a power of vision that allows you to see the dimension of the magical world and see beyond the objects of the real world."
    new "Deshalb ist Agamotos Kraft der Sicht, die dir ermöglicht, die Dimension der magischen Welt zu sehen und hinter die Dinge der realen Welt zu blicken."

    # say L284 pla
    old "Wow Really?"
    new "Wow echt?"

    # say L286 bri
    old "Yes, you should try it, you could only see through easy things like clothes, try using it on someone to see through their clothes."
    new "Ja, du solltest es ausprobieren, du könntest nur durch einfache Dinge wie Kleidung hindurchsehen, versuch es bei jemandem, um durch ihre Kleidung zu sehen."

    # say L288 pla
    old "Ok ok, I'm going to try it..."
    new "Ok ok, ich probier's mal..."

    # menu L297 
    old "Ayax's Hand"
    new "Ayax' Hand"

    # say L299 bri
    old "Ayax was one of the greatest thief magicians in history."
    new "Ayax war einer der größten Dieb-Magier in der Geschichte."

    # say L301 bri
    old "He reached the point of being able to turn his body into a magnet for valuables."
    new "Er war so weit gekommen, dass er seinen Körper in einen Magnet für Wertsachen verwandeln konnte."

    # say L303 bri
    old "Ayax's hand is basically this power that he achieved, with which you can automatically attract the magical power of the area where you are."
    new "Ayax' Hand ist praktisch diese Kraft, die er erlangt hat, mit der du automatisch die magische Energie des Ortes anziehen kannst, an dem du bist."

    # say L306 pla
    old "Wow, interesting..."
    new "Wow, interessant..."

    # say L308 bri
    old "What else do you want to know?"
    new "Was willst du noch wissen?"

    # menu L316 
    old "Sauron's Mouth"
    new "Saurons Mund"

    # say L318 bri
    old "Sauron was one of the greatest political influencers in the magical world."
    new "Sauron war einer der größten politischen Einflussnehmer in der magischen Welt."

    # say L320 bri
    old "He managed to create a manipulative skill with his mouth with which he managed to influence everyone."
    new "Er schaffte es, eine manipulative Fähigkeit mit seinem Mund zu entwickeln, mit der er jeden beeinflussen konnte."

    # say L322 bri
    old "This is how the Sauron's Mouth was created, with it you can influence all kinds of beings..."
    new "So wurde der Mund des Sauron geschaffen, mit dem kannst du alle Arten von Wesen beeinflussen..."

    # say L324 pla
    old "Like some kind of mind control?"
    new "Wie eine Art Gedankenkontrolle?"

    # say L326 bri
    old "What? Of course not, it is more an ability to influence or manipulate at certain levels, not to control the behavior."
    new "Was? Natürlich nicht, es ist eher eine Fähigkeit, auf bestimmten Ebenen zu beeinflussen oder zu manipulieren, aber nicht das Verhalten zu kontrollieren."

    # say L328 bri
    old "In fact, using it does not always work and you should improve it to the fullest and have a good relationship with who you use to increase your chances..."
    new "Tatsächlich funktioniert es nicht immer und du solltest es bis zum Äußersten verbessern und eine gute Beziehung zu demjenigen haben, den du beeinflussen möchtest, um deine Chancen zu erhöhen."

    # say L330 pla
    old "Ok, ok, understood."
    new "Ok, ok, verstanden."

    # menu L339 
    old "Jamliz's Heart"
    new "Jamliz' Herz"

    # say L341 bri
    old "Jamliz sought for years to make a very powerful spell that he never achieved, since he always needed more magical power."
    new "Jamliz suchte jahrelang danach, einen sehr mächtigen Zauber zu wirken, den er nie erreichte, da er immer mehr magische Kraft benötigte."

    # say L343 bri
    old "But, what he achieved was to increase the ability to store magical power in unthinkable amounts."
    new "Aber was er erreichte, war die Fähigkeit, magische Energie in unvorstellbaren Mengen zu speichern."

    # say L345 bri
    old "That's why the Jamliz's Heart is a skill that allows you to store more magical power in your body and thus make spells that require greater magical power."
    new "Deshalb ermöglicht dir das Herz von Jamliz, mehr magische Energie in deinem Körper zu speichern und so Zauber mit höherer magischer Kraft zu wirken."

    # say L347 pla
    old "Sounds pretty useful..."
    new "Klingt ziemlich nützlich..."

    # menu L361 
    old "What I have to do?"
    new "Was muss ich tun?"

    # say L363 bri
    old "The first thing you should do is improve your skills to the fullest. So obviously, you must get magical power."
    new "Das Erste, was du tun solltest, ist, deine Fähigkeiten voll auszuschöpfen. Also musst du natürlich magische Kraft bekommen."

    # say L365 bri
    old "But your main mission is to restore the magical world and with this shortage of magical power the only way is for you to generate it for yourself..."
    new "Aber deine Hauptmission ist es, die magische Welt wiederherzustellen, und bei diesem Mangel an magischer Kraft ist der einzige Weg, dass du sie selbst erzeugst..."

    # say L367 bri
    old "So you should seek to reach the highest level of sexual arousal. Experimenting with different women and situations to see what is most exciting for you..."
    new "Dann solltest du das höchste Level der sexuellen Erregung erreichen. Versuche verschiedene Frauen und Situationen aus, um herauszufinden, was dich am meisten anturnt..."

    # say L369 bri
    old "And have a lot of sex with many women to increase your power and gradually restore the power of the magical world!"
    new "Und viel Sex mit vielen Frauen haben, um deine Kraft zu steigern und die magische Welt allmählich wiederherzustellen!"

    # say L371 pla
    old "You do know that is not that easy, right?"
    new "Du weißt schon, dass das nicht so einfach ist, oder?"

    # say L373 bri
    old "Don't worry. You can gradually acquire more skills that you can use in the real world to make things easier for you..."
    new "Mach dir keine Sorgen. Du kannst allmählich mehr Fähigkeiten erwerben, die du in der realen Welt einsetzen kannst, um es dir leichter zu machen..."

    # say L375 bri
    old "For now you can progress little by little with some women and see if you can get very horny!"
    new "Für den Anfang kannst du dich langsam mit ein paar Frauen einlassen und sehen, ob du richtig geil werden kannst!"

    # say L377 pla
    old "Hmmm... Ok, I'll see how to do something about it."
    new "Hmmm... Okay, ich werd' mal sehen, was ich da machen kann."

    # say L416 pla
    old "I finally found you!"
    new "Ich hab dich endlich gefunden!"

    # say L423 dev
    old "WHAT DO YOU WANT FROM US?"
    new "Was wollt ihr von uns?"

    # say L425 pla
    old "I just want to talk..."
    new "Ich will nur reden..."

    # say L428 gom
    old "Where is your shinigami friend?"
    new "Wo ist deine Shinigami-Freundin?"

    # say L430 pla
    old "She is not here, I came alone... I just want to clarify that everything was a misunderstanding..."
    new "Sie ist nicht hier, ich bin allein gekommen... Ich will nur klären, dass alles ein Missverständnis war..."

    # say L432 pla
    old "I did not destroy the magical world..."
    new "Ich habe die magische Welt nicht zerstört..."

    # say L434 mil
    old "We know that, you didn't destroy the magical world..."
    new "Wir wissen, du hast die magische Welt nicht zerstört..."

    # say L436 pla
    old "That's right!, I didn't..."
    new "Stimmt, ich hab's nicht..."

    # say L440 pla
    old "What? No... I think you are confused "
    new "Was? Nein... Ich glaube, du bist verwirrt."

    # say L442 mil
    old "Kid, we are over 300 years old, and you how many? 18? We know all from the magical and human world. "
    new "Kind, wir sind über 300 Jahre alt und du? 18? Wir kennen uns mit der magischen und der menschlichen Welt aus."

    # say L444 pla
    old "But... Brixxida knows nothing about the destruction of the magical world..."
    new "Aber... Brixxida weiß nichts über die Zerstörung der magischen Welt..."

    # say L446 gom
    old "Doesn't know or doesn't want to tell you? Why do you think she needs you? "
    new "Weiß sie es nicht oder will sie es dir nicht sagen? Warum denkst du, dass sie dich braucht?"

    # say L448 pla
    old "To restore the magical world?"
    new "Um die magische Welt wiederherzustellen?"

    # say L450 dev
    old "And if she wants to restore the magical world why is she alone? Why there are no more shinigamis with her, like us? "
    new "Und wenn sie die magische Welt wiederherstellen will, warum ist sie dann allein? Warum sind keine Shinigami mehr bei ihr, wie wir?"

    # say L452 pla
    old "Well, I don't know..."
    new "Na ja, ich weiß es nicht..."

    # say L454 mil
    old "Who you have by your side is probably one of the most powerful being in the universe and you don't know her real intentions, you must be very careful..."
    new "Wer du an deiner Seite hast, ist wahrscheinlich eines der mächtigsten Wesen im Universum und du weißt nicht, was sie wirklich will, da musst du sehr vorsichtig sein..."

    # say L456 pla
    old "But she has only helped me..."
    new "Aber sie hat mir doch nur geholfen..."

    # say L458 dev
    old "We don't know what she may want from you... But she was who destroy the magic world..."
    new "Wir wissen nicht, was sie von dir will... Aber sie war es, die die magische Welt zerstört hat..."

    # say L460 pla
    old "And how do I know that it is not you who want to deceive me?"
    new "Und wie soll ich wissen, dass du nicht versuchst, mich zu täuschen?"

    # say L462 mil
    old "You don't have to believe us, we're not asking you anything, just let us try to survive, that's all..."
    new "Du musst uns nicht glauben, wir verlangen nichts von dir, lass uns einfach überleben, das ist alles..."

    # say L464 pla
    old "Ok, I want to propose something to you, I will be in charge of sharing magical power to all of you."
    new "Okay, ich schlage euch etwas vor, ich werde dafür sorgen, dass ich die magische Kraft mit euch teile."

    # say L466 pla
    old "I mean, you can come and collect magic power from me so you won't disappear..."
    new "Ich meine, du kannst zu mir kommen und dir Magie abholen, damit du nicht verschwindest..."

    # say L470 mil
    old "Thank you, but we don't need it..."
    new "Danke, aber wir brauchen das nicht..."

    # say L472 pla
    old "Oh come on, I have the SexNote, I have several skills that have allowed me to collect magical power quickly and efficiently."
    new "Oh komm schon, ich habe die SexNote, ich habe mehrere Fähigkeiten, die es mir ermöglichen, magische Energie schnell und effizient zu sammeln."

    # say L474 pla
    old "And... I can also generate magical power by myself..."
    new "Und... ich kann auch selbst magische Energie erzeugen..."

    # say L476 pla
    old "And you have less and less magical power left..."
    new "Und du hast immer weniger magische Kraft übrig..."

    # say L478 gom
    old "What do you want in return?"
    new "Was willst du dafür im Gegenzug?"

    # say L480 pla
    old "Nothing, I just want to help in whatever I can..."
    new "Nichts, ich will nur helfen, wo ich kann..."

    # say L482 mil
    old "Will you still collect magical power from the whole area?"
    new "Wirst du immer noch die magische Energie aus der ganzen Gegend sammeln?"

    # say L484 pla
    old "Well, with Ayax's Hand I automatically gather the magical power where I move..."
    new "Na ja, mit der Hand von Ayax sammle ich automatisch magische Energie, wo ich hingehe..."

    # say L486 pla
    old "But that's why whenever you need it you can go at night and suck up magical power from me..."
    new "Aber deshalb kannst du immer nachts kommen und die magische Energie von mir aufsaugen..."

    # say L488 dev
    old "Hmmm... Okay, but we'll just take what is necessary..."
    new "Hmmm... Okay, aber wir nehmen nur das Nötige..."

    # say L490 mil
    old "And we will return what we do not need, so you can look for us to receive magic power that we don't need..."
    new "Und wir geben zurück, was wir nicht brauchen, damit du uns suchen kannst, um die überschüssige Magie zu erhalten."

    # say L492 gom
    old "It really suits us that you rebuild the sources of magic power production..."
    new "Es passt uns wirklich, dass du die Quellen der Magieproduktion wiederherstellst..."

    # say L494 mil
    old "And that's why we will help you, so you you can find out about Brixxida's true intentions, and we will help you gather the magic power that remains."
    new "Und deshalb werden wir dir helfen, Brixxidas wahre Absichten herauszufinden, und wir werden dir helfen, die verbleibende Magie zu sammeln."

    # say L496 pla
    old "Okay, I'll go as far as I can and find out if Brixxida really has bad intentions or not..."
    new "Okay, ich werde tun, was ich kann, und rausfinden, ob Brixxida wirklich böse Absichten hat oder nicht..."

    # say L498 gom
    old "You must be careful, she is much smarter and more powerful than she seems..."
    new "Du musst vorsichtig sein, sie ist viel schlauer und mächtiger, als sie wirkt..."

    # say L500 dev
    old "You must act without raising suspicion..."
    new "Du musst handeln, ohne Verdacht zu erregen..."

    # say L502 mil
    old "And above all be careful that she does not find out about our deal..."
    new "Und vor allem, pass auf, dass sie nichts von unserem Deal mitkriegt..."

    # say L504 pla
    old "Okay, I'll keep that in mind... But then, where will I find all of you?"
    new "Okay, ich werde das im Hinterkopf behalten... Aber dann, wo werde ich euch alle finden?"

    # say L506 mil
    old "I will continue in the school zone..."
    new "Ich werde mich in der Schule aufhalten..."

    # say L508 gom
    old "I'll be in the house, where you found me..."
    new "Ich werde im Haus sein, wo du mich gefunden hast..."

    # say L510 dev
    old "And you will find me here, that's how we split this little town..."
    new "Und du wirst mich hier finden, so teilen wir uns diese kleine Stadt..."

    # say L512 pla
    old "Perfect, if you need to collect more magical power, you know where to find me..."
    new "Perfekt, wenn du mehr magische Kraft sammeln musst, weißt du, wo du mich findest..."

    # say L514 mil
    old "Okay... I think it's all for now, so we will be leaving..."
    new "Okay... ich denke, das war's für heute, wir werden jetzt gehen..."

    # say L518 gom
    old "You know where to find me... we'll be seeing each other [pla]"
    new "Du weißt, wo du mich findest... wir sehen uns [pla]"

    # say L523 dev
    old "Wait! before you go, I want to start our deal..."
    new "Warte! Bevor du gehst, will ich unser Geschäft beginnen..."

    # say L525 dev
    old "after all, I have collected the most magical power from you and have not returned any of it to you..."
    new "Warte! Bevor du gehst, will ich unser Geschäft beginnen... schließlich habe ich die meiste magische Kraft von dir gesammelt und noch keine davon an dich zurückgegeben..."

    # say L527 pla
    old "No, no, it is not necessary..."
    new "Nein, nein, das ist nicht nötig..."

    # say L532 dev
    old "I see it as a way to close the deal and you have already received magical power from all but me..."
    new "Ich sehe es als eine Art Abschluss und du hast ja schon magische Kraft von allen anderen bekommen..."

    # say L534 pla
    old "Hmm... alright, If it's fine for you."
    new "Hmm... gut, wenn es dir recht ist."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/HalloweenAnimations.rpy
translate german strings:

    # say L5 sis
    old "I'm ready... Do your thing and put it in..."
    new "Ich bin bereit... Mach weiter und steck es rein..."

    # say L6 pla
    old "Alright."
    new "Okay."

    # say L12 sis
    old "Oh God... It feels really nice... Your cock feels really nice in my ass..."
    new "Oh Gott... Das fühlt sich wirklich gut an... Dein Schwanz fühlt sich in meinem Arsch wirklich gut an..."

    # say L13 pla
    old "Uhh it feels.... Tight..."
    new "Uhh es fühlt sich... eng an..."

    # say L18 sis
    old "Ohh yesss... Keep doing it... Fuck my ass [pla]... Fuck my ass!"
    new "Ohh yesss... Mach weiter... Fick meinen Arsch [pla]... Fick meinen Arsch!"

    # say L43 sis
    old "Ohh God! I'm coming... I'm coming!!!"
    new "Oh Gott! Ich komme... Ich komme!!!"

    # say L59 mo1
    old "Does it feel nice baby?"
    new "Fühlt es sich gut an, Schatz?"

    # say L60 pla
    old "It feels amazing, please don't stop!"
    new "Es fühlt sich unglaublich an, bitte hör nicht auf!"

    # say L65 mo1
    old "Oh yes! Oh yes! Fuck my tits baby!"
    new "Oh ja! Oh ja! Fick meine Titten Baby!"

    # say L70 mo1
    old "Fuck my tits harder [pla]! I want you to cum on my tits baby."
    new "Fick meine Titten härter [pla]! Ich will, dass du auf meinen Titten kommst, Baby."

    # say L95 pla
    old "I- I am going to... Ahhh"
    new "Ich- Ich werde... Ahhh"

    # say L96 mo1
    old "Cum on my tits honey!"
    new "Kommen Sie auf meinen Titten, Schatz!"

    # say L111 sis
    old "Did you have a double blowjob before [pla]?"
    new "Hast du schon mal einen Doppel Blowjob bekommen [pla]?"

    # say L113 mo1
    old "Enjoy it baby!"
    new "Genieße es, Schatz!"

    # say L118 mo1
    old "What does it feel like to have your [mo1rel] and [sisrel] sucking your dick?"
    new "Was fühlt sich an, wenn Sie Ihre [mo1rel] und [sisrel] an Ihrem Schwanz saugen?"

    # say L119 pla
    old "(OH MY GOD I CAN'T BELIEVE IT.)"
    new "OH MEIN GOTT ICH KANN ES NICHT GLAUBEN"

    # say L120 sis
    old "It's probably his darkest fantasy..."
    new "Es ist wahrscheinlich seine dunkelste Fantasie..."

    # say L125 mo1
    old "And what about if you cum for us?"
    new "Und was ist, wenn du für uns kommst?"

    # say L127 sis
    old "Yes! Let's make him cum!"
    new "Ja! Lass uns ihn kommen lassen!"

    # say L151 pla
    old "Oh my... I- I am going to... "
    new "Oh mein... I- Ich werde..."

    # say L152 mo1
    old "Don't stop [sis]."
    new "Hör nicht auf [sis]."

    # say L167 mo2
    old "What a HUGE cock [pla]!"
    new "Was für ein riesiger Schwanz [pla]!"

    # say L169 mo1
    old "Does it taste great, isn't?"
    new "Schmeckt es gut, oder?"

    # say L170 mo2
    old "Oh yeah..."
    new "Oh ja..."

    # say L174 mo2
    old "Oh god I can't ever think about being fucked by this cock..."
    new "Oh Gott, ich kann nie wieder daran denken, von diesem Schwanz gefickt zu werden..."

    # say L175 sis
    old "Is fucking amazing... You should try it."
    new "Das ist unglaublich... Du solltest es ausprobieren."

    # say L176 mo2
    old "Definetely I will..."
    new "Definitiv werde ich das tun..."

    # say L182 mo2
    old "Enought waste of time, I want to fuck! Let's make him cum."
    new "Genug Zeitverschwendung, ich will ficken! Lass uns ihn kommen lassen."

    # say L184 sis
    old "Yes! Let's make him cum again!"
    new "Ja! Lass uns ihn nochmal kommen lassen!"

    # say L213 pla
    old "Alright... What the fuck is happening here?"
    new "Okay... Was zur Hölle geht hier ab?"

    # say L224 mo2
    old "Oh God! It's fucking huge..."
    new "Oh Gott! Es ist verdammt groß..."

    # say L225 mo1
    old "Does it hurt [mo2]?"
    new "Tut es weh [mo2]?"

    # say L226 mo2
    old "A little bit, but it feels so good..."
    new "Ein bisschen, aber es fühlt sich so gut an..."

    # say L231 mo2
    old "Oh my fucking God, he is drilling me!"
    new "Oh mein Gott, er fickt mich!"

    # say L232 mo2
    old "Don't stop, fuck me harder [pla]!"
    new "Hör nicht auf, fick mich härter [pla]!"

    # say L237 mo2
    old "Oh yessss! Harder, Fuck me harder baby!"
    new "Oh yessss! Harter, fick mich härter Baby!"

    # say L261 mo2
    old "Ahhhhh Ahhh, I'm cumming!"
    new "Ahhhhh Ahhh, ich komme!"

    # say L265 mo1
    old "Well, it's my turn now..."
    new "Na dann, jetzt bin ich dran..."

    # say L267 mo2
    old "I will bring one of our toys..."
    new "Ich werde eines unserer Spielzeuge holen..."

    # say L283 mo2
    old "We haven't tried anal sex in a long time... How does it feel to be completely filled?"
    new "Wir haben schon lange keinen Analverkehr mehr gehabt... Wie fühlt es sich an, komplett ausgefüllt zu sein?"

    # say L284 mo1
    old "Ohhhhh God, this is like a double penetration! It's to much..."
    new "Ohhhhh Gott, das ist wie eine Doppelpenetration! Das ist zu viel..."

    # say L289 mo1
    old "OHHH WOW! I can't handle this!"
    new "OHHH WOW! Das halte ich nicht aus!"

    # say L290 mo1
    old "Ahhh Ahhhh!"
    new "Ahhhh Ahhhh!"

    # say L294 mo2
    old "Let's fuck her harder [pla], let's fuck your [mo1rel] hard!"
    new "Lass uns sie härter ficken [pla], lass uns deinen [mo1rel] hart ficken!"

    # say L298 mo1
    old "Oh oh yeeesss! I have never feel something like this!"
    new "Oh oh yeeesss! Ich habe noch nie so etwas gespürt!"

    # say L321 mo1
    old "I- I... Ahhhhh I- am... Cumming!"
    new "I- Ich... Ahhhhh Ich- komme!"

    # say L326 pla
    old "Holy shit... I'm fucking dry."
    new "Verdammt nochmal... Ich bin total trocken."

    # say L327 sis
    old "Oh no... I have been waiting my turn."
    new "Oh nein... Ich habe auf meine Reihe gewartet."

    # say L345 mo1
    old "Honey, let him rest a bit, I'm going to help him get ready to fuck you too."
    new "Schatz, lass ihn erst ein bisschen ausruhen, ich helfe ihm, sich für dich bereit zu machen."

    # say L346 sis
    old "Hmmm Alright."
    new "Hmmm Okay."

    # say L350 sis
    old "Now! I want it now!"
    new "Jetzt! Ich will es jetzt!"

    # say L351 mo1
    old "Oh, honey just let me enjoy it a little bit more..."
    new "Oh, Schatz, lass mich es noch ein bisschen länger genießen..."

    # say L378 mo2
    old "Let her fuck [pla], she wants to enjoy too, don't be selfish..."
    new "Lass sie ficken [pla], sie will auch Spaß haben, sei nicht egoistisch..."

    # say L379 mo1
    old "Alright... It's your turn [sis], enjoy it "
    new "Okay... Jetzt bist du dran [sis], genieße es"

    # say L391 sis
    old "Ohhhh yeahh, this is what I'm talking about..."
    new "Ohhhh ja, genau das meinte ich..."

    # say L392 mo1
    old "Does it feel good honey?"
    new "Fühlt sich das gut an, Schatz?"

    # say L393 sis
    old "It feels great, I never get tired of this..."
    new "Es fühlt sich toll an, ich werde nie genug davon kriegen..."

    # say L397 sis
    old "Fuck me harder! I want you to make me cum like you did with [mo1rel]..."
    new "Fick mich härter! Ich will, dass du mich kommen lässt wie bei [mo1rel]..."

    # say L400 sis
    old "Ohh yeah, just like that, don't stop baby."
    new "Ohh ja, genau so, hör nicht auf, Baby."

    # say L404 mo2
    old "You are definetly a little pervert [pla], aren't you? You already fucked me, your [mo1rel] and now you are fucking your [sisrel]."
    new "Du bist definitiv ein kleiner Perverser [pla], oder? Du hast schon mich und deine [mo1rel] gevögelt und jetzt vögelst du deine [sisrel]."

    # say L405 mo1
    old "Oh god, but it feels really good."
    new "Oh Gott, aber es fühlt sich wirklich gut an."

    # say L406 sis
    old "Yes! He is making me cum!"
    new "Ja! Er bringt mich zum Kommen!"

    # say L430 sis
    old "Yesss Yesss... I'm cumming!!!"
    new "Yesss Yesss... ich komme!!!"

    # say L431 sis
    old "Ahhhhhh..."
    new "Ahhhhh..."

    # say L432 mo1
    old "I want it on my mouth."
    new "Ich will es auf meinem Mund."


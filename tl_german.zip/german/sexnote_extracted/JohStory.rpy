# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/JohStory.rpy
translate german strings:

    # say L6 joh
    old "Oh, hi [pla], I‘m glad you came. Are you ready to start?"
    new "Oh, hallo [pla], ich freue mich, dass Sie gekommen sind. Sind Sie bereit, anzufangen?"

    # say L7 pla
    old "Uhh... Hi, yes, sure."
    new "Uhh... Hallo, ja, sicher."

    # say L8 joh
    old "Ok, as we discussed last time, I'll need your help with some of my patients."
    new "Ok, wie wir letztes Mal besprochen haben, brauche ich Ihre Hilfe bei einigen meiner Patienten."

    # say L9 joh
    old "However, you will need a bit of instruction to gain more experience and do a better job."
    new "Allerdings werden Sie etwas Anleitung benötigen, um mehr Erfahrung zu sammeln und Ihre Aufgabe besser zu meistern."

    # say L10 pla
    old "Hmm, ‘Instruction'? What do you mean?"
    new "Hmm, ‘Instruktion’? Was meinst du damit?"

    # say L11 joh
    old "Just think about it like a class made just for you, I'll provide you with the proper training and tell you what to do."
    new "Stellen Sie sich das einfach wie einen Kurs vor, der nur für Sie gemacht ist. Ich werde Ihnen die richtige Ausbildung geben und Ihnen sagen, was zu tun ist."

    # say L12 pla
    old "Hmm, ok..."
    new "Hmm, okay..."

    # say L14 joh
    old "Ok, to start you need to know I assist some patients who have, most of the time, some... Hmm, ‘sexual difficulties'..."
    new "Okay, zum Anfang müssen Sie wissen, dass ich einige Patienten betreue, die in der Regel gewisse... Hmm, 'sexuelle Probleme' haben..."

    # say L15 joh
    old "Some of them are married women that don't enjoy their sexuality, this brings a lot of problems to their lives."
    new "Einige von ihnen sind verheiratete Frauen, die ihre Sexualität nicht genießen, was viele Probleme in ihrem Leben verursacht."

    # say L16 pla
    old "Hmm, I see."
    new "Hmm, ich verstehe."

    # say L17 joh
    old "In other words, I help them to discover and enjoy their sexuality and have more pleasant moments with their partners."
    new "Mit anderen Worten, ich helfe ihnen, ihre Sexualität zu entdecken und zu genießen, und sie erleben mehr angenehme Momente mit ihren Partnern."

    # say L18 pla
    old "Ok, I got it, but... What do I have to do?"
    new "Ok, ich hab's kapiert, aber... Was muss ich tun?"

    # say L19 joh
    old "Well, I know you can support me to achieve success in a lot of patients' treatment like you did with Hinn."
    new "Nun, ich weiß, dass Sie mir helfen können, bei vielen Patienten wie bei Hinn zu erfolgreich zu sein."

    # say L20 pla
    old "L- like I did with... H- Hinn?"
    new "L- wie ich es bei... H- Hinn gemacht habe?"

    # say L21 joh
    old "It's ok, I am pretty conscious about the process we will need to go through so you can do it well."
    new "Es ist in Ordnung, ich bin mir bewusst, welchen Prozess wir durchlaufen müssen, damit Sie es gut machen können."

    # say L23 joh
    old "Don't worry, we will have some lessons to teach you."
    new "Machen Sie sich keine Sorgen, wir werden einige Unterrichtsstunden haben, um Sie zu lehren."

    # say L24 joh
    old "Also, I'll be with you at all times, you just have to follow the instructions, okay?"
    new "Also, ich werde die ganze Zeit bei Ihnen sein, Sie müssen sich nur an die Anweisungen halten, okay?"

    # say L25 pla
    old "Hmm, got it."
    new "Hmm, verstanden."

    # say L26 joh
    old "I really want you to perform the best way possible and I will ensure you develop the skills you need."
    new "Ich möchte, dass Sie sich optimal entwickeln, und ich werde sicherstellen, dass Sie die nötigen Fähigkeiten erwerben."

    # say L27 joh
    old "So, let's not waste any more time and let's go to the practice room!"
    new "Dann verschwenden wir keine Zeit mehr und gehen in den Übungsraum!"

    # say L34 joh
    old "Well, to start, do you remember that Hinn learned how to please a man? Well, now is your turn!"
    new "Nun, zum Anfang, erinnern Sie sich noch daran, wie Hinn gelernt hat, einen Mann zu befriedigen? Nun ist Ihre Reihe!"

    # say L36 joh
    old "What I meant [pla] is, I'll teach you how to fuck like a pro..."
    new "Was ich meine [pla] ist, ich werde Ihnen beibringen, wie man es wie ein Profi treibt..."

    # say L38 joh
    old "At this point I think you must take it more natural since I've already sucked your cock several times so just relax."
    new "Ich denke, an diesem Punkt müssen Sie es etwas natürlicher angehen, da ich Ihren Schwanz schon mehrmals geleckt habe, also entspannen Sie sich einfach."

    # say L40 joh
    old "We are going to start with some oral sex, I want you to show me those skills, so I can be sure my patients are going be satisfied."
    new "Wir werden mit ein bisschen Oralsex beginnen, ich will sehen, wie gut du das kannst, damit ich sicher sein kann, dass meine Patienten zufrieden sind."

    # say L41 pla
    old "W- what? Do you mean you want me to give you... O- oral sex?"
    new "W- was? Meinen Sie, ich soll Ihnen... O- oral Sex geben?"

    # say L42 joh
    old "Yes, remember, just relax and follow my instructions."
    new "Ja, erinnern Sie sich, einfach entspannen und meinen Anweisungen folgen."

    # say L43 joh
    old "We are learning and this is part of your process, so, come here and get on your knees."
    new "Wir lernen, und das ist Teil deines Prozesses, also komm her und knie dich hin."

    # say L52 joh
    old "I can assure you this lesson is going to be useful for you."
    new "Ich kann Ihnen versichern, dass diese Lektion für Sie nützlich sein wird."

    # say L53 joh
    old "And it will be necessary for my patients, and of course, should be amusing for both of us, so, let's start."
    new "Und es wird für meine Patienten notwendig sein, und natürlich sollte es für uns beide amüsant sein, also los geht's."

    # say L56 joh
    old "I want you to kiss me, like if that were my mouth, move your tongue carefully, slowly..."
    new "Ich möchte, dass du mich küsst, als wäre das mein Mund, bewege deine Zunge vorsichtig und langsam..."

    # say L69 joh
    old "Just like that, try to keep it wet, and slowly move your tongue a bit faster..."
    new "Genau so, versuchen Sie es feucht zu halten und bewegen Sie Ihre Zunge etwas schneller..."

    # say L71 joh
    old "Keep doing it like that... Ahh."
    new "So machen Sie weiter... Ahh."

    # narrator L95 
    old "Try Again"
    new "Nochmal versuchen"

    # narrator L97 
    old "Next Round"
    new "Nächste Runde"

    # say L109 joh
    old "Oh careful!"
    new "Oh vorsichtig!"

    # say L111 joh
    old "Ouch!"
    new "Aua!"

    # say L113 joh
    old "NO! NO! STOP!"
    new "NEIN! NEIN! AUFHÖREN!"

    # say L119 pla
    old "Did I do something wrong?"
    new "Habe ich etwas falsch gemacht?"

    # say L120 joh
    old "Hmm, I think you could do it a lot better..."
    new "Hmm, ich denke, Sie könnten es viel besser machen..."

    # say L121 joh
    old "Softer, the idea is to make the patient experience a lot of pleasure and not the opposite, but we can work on that."
    new "Sanfter, das Ziel ist es, dem Patienten viel Vergnügen zu bereiten und nicht das Gegenteil, aber daran können wir arbeiten."

    # say L122 pla
    old "Hmm... Ok."
    new "Hmm... Okay."

    # say L123 joh
    old "Listen, that is something normal, we can always improve our abilities, don't feel bad about this particular moment where it was not as expected, it's ok."
    new "Hören Sie, das ist etwas Normales, wir können unsere Fähigkeiten immer verbessern. Machen Sie sich nicht schlecht fühlen, weil es in diesem Moment nicht so war, wie erwartet. Es ist okay."

    # say L126 joh
    old "Unfortunately, our time is up. I think you need to learn a couple of things more before continuing."
    new "Leider ist unsere Zeit um. Ich denke, Sie müssen noch ein paar Dinge lernen, bevor Sie weitermachen."

    # say L129 joh
    old "Perfect, see you later [pla]."
    new "Perfekt, bis später [pla]."

    # say L130 pla
    old "See you too, bye!"
    new "Bis dann, tschüss!"

    # say L144 joh
    old "Congratulations, you definitely have what it takes, so, we can do a perfect team."
    new "Herzlichen Glückwunsch, Sie haben definitiv das nötige Talent, wir werden ein perfektes Team abgeben."

    # say L145 joh
    old "I can see you have other talents and they are pretty valuable."
    new "Ich sehe, dass Sie andere Talente haben und die sind sehr wertvoll."

    # say L147 joh
    old "Yes, I'm very satisfied, you did just fine."
    new "Ja, ich bin sehr zufrieden, Sie haben es gut gemacht."

    # say L148 pla
    old "I am glad you liked it."
    new "Ich freue mich, dass es dir gefallen hat."

    # say L149 joh
    old "It can be better but I am proud of you, I can count on you to make the best for my patients."
    new "Es kann besser sein, aber ich bin stolz auf Sie. Ich kann mich darauf verlassen, dass Sie das Beste für meine Patienten tun."

    # say L150 joh
    old "The great news is that these lessons are going to be quite fascinating for me."
    new "Die gute Nachricht ist, dass diese Lektionen für mich ziemlich faszinierend werden werden."

    # say L159 joh
    old "I think that's all, you need to rest a bit, I am exhausted but I have some patients I have scheduled."
    new "Ich denke, das war's. Sie sollten sich ein bisschen ausruhen, ich bin erschöpft, aber ich habe noch einige Patienten, die ich eingetragen habe."

    # say L160 pla
    old "Ok, thank you."
    new "Ok, danke."

    # say L161 joh
    old "It was a pleasure... I hope you're on time tomorrow."
    new "Es war eine Freude... Ich hoffe, Sie sind morgen pünktlich."

    # say L163 joh
    old "I'll be waiting for you, there are some lessons we need to have go through."
    new "Ich werde auf Sie warten, es gibt einige Lektionen, die wir durchgehen müssen."

    # say L165 joh
    old "Perfect, see you tomorrow."
    new "Perfekt, bis morgen."

    # say L181 joh
    old "Hi [pla], glad to see you. There's no time to lose, let's go to the room."
    new "Hallo [pla], freut mich, Sie zu sehen. Es gibt keine Zeit zu verlieren, lass uns in den Raum gehen."

    # say L188 joh
    old "We need to repeat the session we were practising last time, I need you to finish it successfully."
    new "Wir müssen die Sitzung wiederholen, die wir letztes Mal geübt haben, ich brauche Sie, um sie erfolgreich zu beenden."

    # say L190 joh
    old "I have to budget my time because I have a couple of patients coming earlier, so please help me to finish on time."
    new "Ich muss meine Zeit einteilen, da ich noch einige Patienten habe, die früher kommen, also bitte helfen Sie mir, pünktlich fertig zu werden."

    # say L192 joh
    old "Let's start, you already know how to do it, so please do your best."
    new "Lass uns anfangen, Sie wissen ja schon, wie es geht, also geben Sie bitte Ihr Bestes."

    # say L207 joh
    old "Keep doing it like that... Ahh..."
    new "So machen Sie weiter... Ahh..."

    # say L262 joh
    old "Welcome [pla], I'm happy to have you here, we have a lot of things to work on."
    new "Willkommen [pla], ich freue mich, Sie hier willkommen zu heißen. Wir haben viel zu tun."

    # say L263 pla
    old "Hi... Uhh, ok, ok, I- I am ready."
    new "Hi... Uhh, ok, ok, ich bin bereit."

    # say L264 joh
    old "Wonderful! Today we have a new goal I want you to work on."
    new "Wunderbar! Heute haben wir ein neues Ziel, an dem ich Sie arbeiten lassen möchte."

    # say L265 pla
    old "Ok, what is it?"
    new "Okay, was ist es?"

    # say L266 joh
    old "I think it's something kind of new for you but I can walk you through it. It's related to self-mastery."
    new "Ich denke, es ist etwas Neues für Sie, aber ich kann Sie durch das Ganze führen. Es hat mit Selbstbeherrschung zu tun."

    # say L268 pla
    old "'Self-mastery'?"
    new "'Selbstbeherrschung'?"

    # say L269 joh
    old "Yeah, let me explain it to you, most of the time our desires or emotions can be really difficult to control..."
    new "Ja, lass es mich dir erklären, die meisten unserer Wünsche oder Emotionen können wirklich schwer zu kontrollieren sein..."

    # say L270 joh
    old "Once you can defeat them, you will be strong enough to act without their control."
    new "Wenn Sie sie besiegen können, werden Sie stark genug sein, um ohne ihre Kontrolle zu handeln."

    # say L271 joh
    old "The most visible aspect of this exercise will be that you can last longer during any kind of sexual interaction."
    new "Der sichtbarste Aspekt dieser Übung wird sein, dass Sie länger durchhalten können bei jeder Art von sexueller Interaktion."

    # say L272 pla
    old "Hmm interesting..."
    new "Hmm interessant..."

    # say L273 joh
    old "Talking about our sexual performance, we need to be sure we can control our body to react the exact way we want..."
    new "Wenn wir über unsere sexuelle Leistung sprechen, müssen wir sicherstellen, dass wir unseren Körper so kontrollieren können, wie wir es wollen..."

    # say L274 joh
    old "That way we can guarantee your sexual partner reaches the orgasm before you do."
    new "Auf diese Weise können wir garantieren, dass Ihr sexueller Partner vor Ihnen zum Orgasmus kommt."

    # say L277 joh
    old "That's cool, so today we are going to see if your performance can be mastered without cumming."
    new "Das ist gut, dann werden wir heute prüfen, ob Sie Ihre Leistung beherrschen können, ohne zu kommen."

    # say L278 joh
    old "Or we will need to work on it harder so you can perform better with the patients."
    new "Oder wir müssen härter daran arbeiten, damit Sie bei den Patienten besser abschneiden."

    # say L279 pla
    old "Ok, and how are we going to verify that?"
    new "Okay, und wie werden wir das überprüfen?"

    # say L280 joh
    old "That's an interesting part, I want you to relax and just be yourself, I will do the rest of the job, let's go to the room."
    new "Das ist der interessante Teil, ich möchte, dass du dich entspannst und einfach du selbst bist, ich werde den Rest machen, lass uns in den Raum gehen."

    # say L281 pla
    old "Uhh... Ok."
    new "Uhh... Okay."

    # say L287 joh
    old "Please take off your pants, so we can start..."
    new "Bitte ziehen Sie Ihre Hose aus, dann können wir beginnen..."

    # say L289 joh
    old "I want to test how long you can last, so, get ready because I will use my mouth, I will give you the best blowjob of your entire life."
    new "Ich möchte testen, wie lange du durchhältst, also bereite dich darauf vor, dass ich meinen Mund benutze, ich werde dir den besten Blowjob deines Lebens geben."

    # say L291 joh
    old "So, come on, take off your pants, I'm going to make myself comfortable too."
    new "Also, kommen Sie, ziehen Sie Ihre Hose aus, ich werde es mir auch gemütlich machen."

    # say L317 joh
    old "I am glad you like them because I want you to look at them carefully."
    new "Ich bin froh, dass Sie sie mögen, denn ich möchte, dass Sie sie sich genau ansehen."

    # say L318 joh
    old "I need you to be very stimulated to test your endurance."
    new "Ich brauche Sie sehr erregt, um Ihre Ausdauer zu testen."

    # say L320 joh
    old "The idea is that, even though all sensorial stimulation you feel, you can control your body and don't cum."
    new "Die Idee ist, dass Sie, obwohl Sie alle sensorischen Reize spüren, Ihren Körper kontrollieren und nicht abspritzen."

    # say L321 pla
    old "Are you serious?"
    new "Sind Sie ernsthaft?"

    # say L322 joh
    old "Absolutely, under any circumstance you must not cum, until I say you can, ok?"
    new "Absolut, unter keinen Umständen darfst du kommen, bis ich es dir sage, okay?"

    # say L323 pla
    old "Hmm ok..."
    new "Hmm okay..."

    # say L368 joh
    old "Ok now it comes the hard part, I will suck your entire dick, are you ready?"
    new "Okay, jetzt kommt der schwierige Teil, ich werde deinen ganzen Schwanz lutschen, bist du bereit?"

    # say L374 pla
    old "(Oh God, it feels so good...)"
    new "Oh Gott, das fühlt sich so gut..."

    # say L379 pla
    old "Dr. Johnson I- I- ... Ughhhh..."
    new "Dr. Johnson ich- ich-... Ughhhh..."

    # say L386 joh
    old "OH NO! You came before!"
    new "OH NEIN! Sie sind schon gekommen!"

    # say L392 pla
    old "I- I am... Sorry..."
    new "Ich bin... Tut mir leid, Dr. Johnson."

    # say L393 joh
    old "It's ok, it's something we knew could happen so calm down, what a mess you did..."
    new "Es ist okay, das war etwas, das passieren konnte, also beruhigen Sie sich, was für ein Chaos Sie angerichtet haben..."

    # say L394 pla
    old "I'm sorry, it was my fault."
    new "Es tut mir leid, es war meine Schuld."

    # say L395 joh
    old "It's ok, it wasn't that bad, the thing is that we now need to have this in mind to make sure you can control yourself."
    new "Es ist okay, es war nicht so schlimm, aber wir müssen jetzt daran denken, dass du dich unter Kontrolle halten musst."

    # say L396 joh
    old "We can't have this mess with a patient..."
    new "Wir können diesen Unsinn bei einem Patienten nicht gebrauchen..."

    # say L398 pla
    old "How can I do it better?"
    new "Wie kann ich es besser machen?"

    # say L400 joh
    old "I will help you, don't worry."
    new "Ich werde Ihnen helfen, machen Sie sich keine Sorgen."

    # say L402 joh
    old "But, I am running out of time, the patients are about to arrive and I need to clean this mess..."
    new "Aber ich habe nicht mehr viel Zeit, die Patienten werden gleich eintreffen und ich muss dieses Chaos beseitigen..."

    # say L403 joh
    old "I hope you be on time tomorrow, We need to correct this behavior."
    new "Ich hoffe, Sie sind morgen pünktlich, wir müssen dieses Verhalten korrigieren."

    # say L404 pla
    old "I am very sorry to disappoint you."
    new "Ich bin sehr betrübt, Sie zu enttäuschen."

    # say L405 joh
    old "There is nothing we can't improve, I'm sure next time it will be different."
    new "Es gibt nichts, was wir nicht verbessern können, ich bin sicher, beim nächsten Mal wird es anders sein."

    # say L406 joh
    old "I think that's all, you need to rest a bit, I have some patients scheduled, so, see you later."
    new "Ich denke, das war's für heute, Sie sollten sich ein bisschen ausruhen. Ich habe noch einige Patienten, also bis später."

    # say L409 joh
    old "We will need to repeat this exercise, I'll be waiting for you."
    new "Wir werden dieses Training wiederholen müssen, ich warte auf Sie."

    # say L410 pla
    old "Ok, see you later..."
    new "Ok, bis später..."

    # say L425 joh
    old "Oh great! That was good, you have surprised me! What a huge load, it's delicious."
    new "Oh toll! Das war gut, du hast mich überrascht! Was für eine riesige Ladung, das ist köstlich."

    # say L427 joh
    old "Congratulations, I can see that you havea lot more control of body."
    new "Meine Glückwünsche, ich sehe, dass Sie viel mehr Kontrolle über Ihren Körper haben."

    # say L432 joh
    old "All right, I'm gonna clean this mess. My next patient is about to arrive... I hope you be on time tomorrow."
    new "In Ordnung, ich werde dieses Chaos beseitigen. Mein nächster Patient wird gleich eintreffen... Ich hoffe, Sie sind morgen pünktlich."

    # say L435 joh
    old "Ok, there are some lessons we need to have to go through."
    new "Ok, es gibt noch einige Lektionen, die wir durchgehen müssen."

    # say L436 pla
    old "Got it, see you tomorrow then."
    new "Verstanden, bis morgen dann."

    # say L452 pla
    old "Fine! Thanks for asking, hope you are doing good too."
    new "Fein! Danke für die Nachfrage, hoffe, es geht Ihnen auch gut."

    # say L453 joh
    old "Oh absolutely! But I can tell you it will be better just in a moment, Are you ready?"
    new "Oh absolut! Aber ich kann Ihnen sagen, es wird gleich noch besser werden. Sind Sie bereit?"

    # say L454 pla
    old "Ready? For what?"
    new "Bereit? Wofür?"

    # say L456 joh
    old "Well, today we will continue your process to make you able to control yourself, the main focus for today will be performance."
    new "Nun, heute werden wir mit Ihrem Prozess fortfahren, um Ihnen die Kontrolle über sich selbst zu ermöglichen. Der Hauptfokus heute wird auf der Leistung liegen."

    # say L457 pla
    old "Performance?"
    new "Leistung?"

    # say L458 joh
    old "Yes, we need to test your capabilities to accomplish the tasks that you will have..."
    new "Ja, wir müssen Ihre Fähigkeiten testen, die Aufgaben zu bewältigen, die vor Ihnen liegen..."

    # say L459 joh
    old "So, you need to work not only on the time you can last, but the quality of that time."
    new "Sie müssen also nicht nur an der Dauer arbeiten, sondern auch an der Qualität dieser Zeit."

    # say L460 pla
    old "Oh... I understand."
    new "Oh... ich verstehe."

    # say L462 joh
    old "Today we have a very nice exercise, so I hope you put all your effort to make a successful session."
    new "Heute haben wir eine sehr schöne Übung, ich hoffe, Sie legen alle Kraft in die Bahn, um eine erfolgreiche Sitzung zu machen."

    # say L463 joh
    old "Remember, focus on the rhythm and performance."
    new "Denken Sie daran, sich auf das Tempo und die Leistung zu konzentrieren."

    # say L464 pla
    old "Uhh, ok."
    new "Uhh, okay."

    # say L465 joh
    old "So, let's go, we will have sex now."
    new "Also, los geht's, wir werden jetzt Sex haben."

    # say L466 pla
    old "I will hav-... W- wait, what? Sex?"
    new "Ich werde... W-warte, was? Sex?"

    # say L467 joh
    old "Of course, that is how we can practice, besides, I need to test the quality of my assistant."
    new "Natürlich, so können wir üben und ich muss die Qualität meiner Assistentin testen."

    # say L469 joh
    old "Great, let's get started, first we need to go to the practice room."
    new "Großartig, dann lass uns anfangen. Zuerst müssen wir in den Übungsraum gehen."

    # say L476 joh
    old "From this particular exercise and on, we will need to guarantee your partner reaches the orgasm, that is the key."
    new "Von diesem bestimmten Übungsteil an müssen wir sicherstellen, dass Ihr Partner zum Orgasmus kommt, das ist der Schlüssel."

    # say L477 pla
    old "Ok, I will focus on that."
    new "Okay, ich werde mich darauf konzentrieren."

    # say L478 joh
    old "But, anyways remember to enjoy what you are doing, let's get prepared. Take off your clothes."
    new "Aber egal, denken Sie daran, das, was Sie tun, zu genießen. Lassen Sie uns uns vorbereiten. Ziehen Sie sich aus."

    # say L482 joh
    old "Perfect, now that you are ready let's fuck!"
    new "Perfekt, jetzt wo Sie bereit sind, lass uns ficken!"

    # say L552 joh
    old "Huh, you finished quite earlier..."
    new "Huh, Sie sind ja schon viel früher fertig geworden..."

    # say L553 joh
    old "I know you are doing a great effort, but I need you to take control of yourself and wait for the right moment."
    new "Ich weiß, dass Sie sich große Mühe geben, aber ich muss Sie bitten, sich zu beherrschen und auf den richtigen Moment zu warten."

    # say L554 pla
    old "I- I'm trying to focus-"
    new "Ich- Ich versuch mich zu konzentrieren"

    # say L556 joh
    old "I know, we only need to work harder. "
    new "Ich weiß, wir müssen nur noch härter arbeiten."

    # say L557 joh
    old "I think you need to do some workout, so, you can keep your body up until I reach the orgasm."
    new "Ich denke, Sie sollten etwas Sport treiben, dann können Sie Ihren Körper länger durchhalten, bis ich zum Orgasmus komme."

    # say L559 pla
    old "I will improve, I think I was tired because of the rhythm."
    new "Ich werde mich verbessern, ich glaube, ich war einfach müde vom Rhythmus."

    # say L560 joh
    old "Sure you will improve, that's why we are doing this together, so you can develop all the skills you have."
    new "Natürlich werden Sie sich verbessern, deshalb machen wir das gemeinsam, damit Sie alle Ihre Fähigkeiten entwickeln können."

    # say L562 joh
    old "Don't mention it, let's clean this mess, I have to continue working..."
    new "Machen Sie sich nichts draus, lassen Sie uns dieses Chaos beseitigen, ich muss weiterarbeiten..."

    # say L577 joh
    old "I'm very impressed, you are quite awesome at this, let me tell you the exercise was a complete success."
    new "Ich bin sehr beeindruckt, Sie sind ziemlich toll darin, lassen Sie mich Ihnen sagen, das Training war ein voller Erfolg."

    # say L578 pla
    old "T- thanks... I did all that I could."
    new "D-danke... Ich hab mein Bestes gegeben."

    # say L579 joh
    old "Hahaha good job kid, you are doing the exercises very consciously."
    new "Hahaha, gute Arbeit, Junge. Du machst die Übungen sehr bewusst."

    # say L581 joh
    old "Keep working, the benefits will be incredible and remember the benefits won't be only yours..."
    new "Weitermachen, die Vorteile werden unglaublich sein und denken Sie daran, die Vorteile werden nicht nur Ihnen gehören..."

    # say L582 joh
    old "It was a very productive session, so, I hope next time we keep the level as high as today."
    new "Es war eine sehr produktive Sitzung, also hoffe ich, dass wir beim nächsten Mal das Niveau von heute halten können."

    # say L583 pla
    old "Sure, I will keep working hard."
    new "Natürlich, ich werde weiter hart arbeiten."

    # say L585 joh
    old "Yes... really Hard."
    new "Ja... wirklich hart."

    # say L601 joh
    old "Oh, you are here! Quite on time."
    new "Oh, Sie sind hier! Pünktlich wie immer."

    # say L602 pla
    old "Yes, I came a bit earlier."
    new "Ja, ich bin ein bisschen früher gekommen."

    # say L603 joh
    old "That's perfect, we have a lot to work on."
    new "Das ist perfekt, wir haben viel zu tun."

    # say L604 pla
    old "Ok, I am ready."
    new "Okay, ich bin bereit."

    # say L605 joh
    old "Great, today we will work on your strength, the power given on every sexual encounter."
    new "Großartig, heute werden wir an Ihrer Stärke arbeiten, der Kraft, die bei jeder sexuellen Begegnung ins Spiel kommt."

    # say L606 pla
    old "Hmm... Strength? What do you mean?"
    new "Hmm... Kraft? Was meinst du damit?"

    # say L607 joh
    old "Sex requires a lot of power if you really want to satisfy, I need you to start doing the process beyond the limits."
    new "Sex erfordert viel Kraft, wenn du wirklich zufriedenstellend sein willst. Ich brauche von Ihnen, dass Sie den Prozess über die Grenzen hinaus treiben."

    # say L609 pla
    old "Wow, And how can I achieve that?"
    new "Wow, und wie kann ich das erreichen?"

    # say L610 joh
    old "Well, I need you to focus because you are going to use your dick quite differently."
    new "Nun, ich brauche von Ihnen, dass Sie sich konzentrieren, denn Sie werden Ihren Schwanz auf eine ganz andere Weise einsetzen."

    # say L611 joh
    old "You must control your body so you can give a hardcore sex experience."
    new "Sie müssen Ihren Körper kontrollieren, damit Sie ein intensives Sexerlebnis bieten können."

    # say L612 pla
    old "Hmm, ok."
    new "Hmm, okay."

    # say L613 joh
    old "Let's go ahead to the practice room, I can't wait to get fucke- ... I mean to start the new exercise..."
    new "Lassen Sie uns in den Übungsraum gehen, ich kann es kaum abwarten, mit dem neuen Training zu beginnen..."

    # say L620 joh
    old "Ok, previous lesson was focused on endurance and lasting as much as I wanted."
    new "Ok, die letzte Stunde hat sich auf Ausdauer und darauf konzentriert, so lange zu halten, wie ich wollte."

    # say L621 joh
    old "This time I need you to keep this in mind, I want you to be hardcore hitting my pussy really hard."
    new "Dieses Mal möchte ich, dass Sie das im Hinterkopf behalten, ich will, dass Sie hart zustoßen, richtig tief in meiner Pussy."

    # say L623 joh
    old "Let's do it, please take off your clothes and get ready."
    new "Lassen Sie uns anfangen, bitte ziehen Sie sich aus und bereiten Sie sich vor."

    # say L682 pla
    old "Oh God! This is too much!"
    new "Oh Gott! Das ist zu viel!"

    # say L695 pla
    old "Did I cum quick, right?"
    new "Hab ich schnell abgespritzt, oder?"

    # say L696 joh
    old "Not just that... I'm afraid you are not strong enough, you need to hit harder, some girls will like to be pounded really hard."
    new "Nicht nur das... Ich fürchte, Sie sind nicht stark genug, Sie müssen härter zustoßen, manche Mädchen mögen es, richtig hart durchgenommen zu werden."

    # say L698 joh
    old "[pla], we need to satisfy certain preferences..."
    new "[pla], wir müssen bestimmte Vorlieben befriedigen..."

    # say L699 joh
    old "This is not a regular sexual encounter you will find really demanding girls that want something harder, and you need to provide that."
    new "Das ist kein gewöhnliches sexuelles Erlebnis, Sie werden wirklich fordernde Frauen treffen, die härteres Spiel wollen, und Sie müssen das bieten können."

    # say L700 pla
    old "You are right, I'm sorry.."
    new "Du hast recht, es tut mir leid."

    # say L701 joh
    old "Don't worry I know you can learn... But today I need to get ready for my next patient, so next time we will practice this lesson again."
    new "Machen Sie sich keine Sorgen, ich weiß, dass Sie lernen können... Aber heute muss ich mich auf meinen nächsten Patienten vorbereiten, also üben wir das nächste Mal diese Lektion noch einmal."

    # say L703 joh
    old "See you later kido."
    new "Bis später, Kido."

    # say L704 pla
    old "See you doctor."
    new "Bis später, Doktor."

    # say L718 joh
    old "You are doing great! Congratulations for this improvement, you definitely approved, my patients will love you."
    new "Sie machen großartige Fortschritte! Herzlichen Glückwunsch zu dieser Verbesserung, Sie wurden definitiv bestanden, meine Patienten werden Sie lieben."

    # say L719 pla
    old "Thank you, I appreciate it."
    new "Danke, ich schätze es."

    # say L720 joh
    old "The process has been successful, I want you to keep working..."
    new "Der Prozess war erfolgreich, ich möchte, dass Sie weiterarbeiten..."

    # say L723 joh
    old "I guess in the mornings we can continue with these lessons, because I want to... Hmm, help you practice more..."
    new "Ich denke, morgens können wir mit diesen Lektionen weitermachen, weil ich will, dass du... Hmm, mehr übst..."

    # say L724 pla
    old "Oh, ok that sounds good to me..."
    new "Oh, okay, das klingt gut für mich..."

    # say L725 joh
    old "Perfect, I'm looking forward to seeing your progress, there are many things we can improve."
    new "Perfekt, ich freue mich darauf, Ihren Fortschritt zu sehen. Es gibt viele Dinge, die wir verbessern können."

    # say L726 pla
    old "I appreciate your help."
    new "Ich schätze Ihre Hilfe."

    # say L727 joh
    old "In our next session we will have a patient to put what we have learned into practice."
    new "In unserer nächsten Sitzung werden wir einen Patienten haben, um das Gelernte in die Praxis umzusetzen."

    # say L729 joh
    old "Don't worry, I will walk you through so we can do an outstanding job."
    new "Machen Sie sich keine Sorgen, ich werde Sie durch alles führen, damit wir eine großartige Arbeit leisten."

    # say L733 joh
    old "All right, I need you to leave so I can get ready for my next patient, thanks for your great job, it was remarkable."
    new "In Ordnung, ich brauche Sie jetzt, damit ich mich auf meinen nächsten Patienten vorbereiten kann, vielen Dank für Ihre großartige Arbeit, es war bemerkenswert."

    # say L737 pla
    old "Bye!"
    new "Tschüss!"

    # say L747 joh
    old "(I can't believe myself, that dick is driving me so crazy...)"
    new "Ich kann es selbst nicht fassen, dieser Schwanz treibt mich noch in den Wahnsinn..."

    # say L761 joh
    old "Oh, [pla], I'm glad you came early, there's something I needed to talk to you about before we start."
    new "Oh, [pla], ich bin froh, dass Sie früh gekommen sind, da ist etwas, worüber ich vor dem Beginn mit Ihnen sprechen muss."

    # say L763 joh
    old "Well, today we're going to work with Angelina, she is a patient who doesn't enjoy having sex."
    new "Nun, heute werden wir mit Angelina arbeiten, sie ist eine Patientin, die keinen Sex mag."

    # say L764 joh
    old "I have tried with several exercises, but she is kind of stuck in the process..."
    new "Ich habe es mit mehreren Übungen versucht, aber sie steckt irgendwie fest im Prozess..."

    # say L765 joh
    old "Also, her marriage is in danger, because she doesn't want to have sex with her husband."
    new "Also, ihre Ehe ist in Gefahr, weil sie nicht mit ihrem Mann schlafen will."

    # say L767 pla
    old "Oh, that's really bad."
    new "Oh, das ist wirklich schlimm."

    # say L768 joh
    old "Yes, so we need to have noticeable progress as soon as possible, and we are going to achieve that with your help."
    new "Ja, deshalb müssen wir so schnell wie möglich sichtbare Fortschritte machen, und das werden wir mit Ihrer Hilfe schaffen."

    # say L769 pla
    old "With m- my... Help?"
    new "Mit m- meiner... Hilfe?"

    # say L770 joh
    old "Well, with the training you've been through we can help..."
    new "Nun, mit der Ausbildung, die Sie durchgemacht haben, können wir helfen..."

    # say L771 joh
    old "We will need to apply all the concepts that we have worked on so that she can discover how pleasurable sex is."
    new "Wir werden alle Konzepte anwenden müssen, die wir durchgearbeitet haben, damit sie entdecken kann, wie angenehm Sex sein kann."

    # say L774 joh
    old "Then everything she learns here, she can put into practice with her husband, and our treatment will be successful."
    new "Dann kann sie alles, was sie hier lernt, mit ihrem Mann in die Praxis umsetzen, und unsere Therapie wird erfolgreich sein."

    # say L775 pla
    old "Ohhh, that makes sense..."
    new "Ach so, das ergibt Sinn..."

    # say L776 joh
    old "Ok, so, please stay in the practice room and I will let you know when to come in to get involved with the session."
    new "Okay, bleiben Sie bitte im Übungsraum und ich werde Sie informieren, wann Sie ins Zimmer kommen sollen, um an der Sitzung teilzunehmen."

    # say L778 joh
    old "I will need you to be ready, I mean to have your cock prepared when I call you."
    new "Ich werde Sie benötigen, bereit zu sein, ich meine, Ihren Schwanz vorbereitet zu haben, wenn ich Sie rufe."

    # say L781 joh
    old "Remember to stay focused on her pleasure, you'll have to practice everything we've learned, once Angelina is ready I'll let you know."
    new "Denken Sie daran, sich auf ihr Vergnügen zu konzentrieren, Sie werden alles üben müssen, was wir gelernt haben. Sobald Angelina bereit ist, lasse ich es Sie wissen."

    # say L783 joh
    old "Ok, now go to the practice room, she could arrive at any time."
    new "Ok, jetzt geh in den Übungsraum, sie könnte jederzeit eintreffen."

    # say L796 joh
    old "Welcome Angelina, it's pretty nice to have you here again."
    new "Willkommen Angelina, es freut mich sehr, dich wieder hier zu haben."

    # say L797 ang
    old "Thank you doctor Johnson is good to see you again."
    new "Danke, Doktor Johnson, es freut mich, Sie wiederzusehen."

    # say L798 joh
    old "I'm very happy to hear that, how is it going?"
    new "Ich bin sehr froh das zu hören, wie geht es dir?"

    # say L799 ang
    old "Everything is fine I guess, except for what you already know."
    new "Alles ist gut, denke ich, außer dem, was Sie schon wissen."

    # say L800 joh
    old "Tell me about that please, did you see any improvement since the last session?"
    new "Erzähl mir davon bitte, hast du seit der letzten Sitzung irgendwelche Verbesserungen bemerkt?"

    # say L801 ang
    old "Hmm... Well, I'm doing the things that you told me to, but I'm not really comfortable when I'm doing it..."
    new "Hmm... Na ja, ich mache die Dinge, die Sie mir gesagt haben, aber ich fühle mich dabei einfach nicht wohl..."

    # say L802 ang
    old "I have tried all the ways but it feels really disgusting."
    new "Ich habe es auf alle Arten versucht, aber es fühlt sich echt widerlich an."

    # say L803 joh
    old "No worries darling, I understand and it's totally ok, it's part of the expectations we had set previously, so it's ok to feel that way..."
    new "Keine Sorge, Liebling, ich verstehe und es ist total in Ordnung. Es ist Teil der Erwartungen, die wir zuvor gesetzt haben, also ist es okay, sich so zu fühlen."

    # say L805 ang
    old "You are the only person I feel free to share this with."
    new "Du bist die einzige Person, mit der ich mich in dieser Sache frei fühle."

    # say L806 joh
    old "And I'm here for you, and I'll see to it that we get through this problem once and for all."
    new "Und ich bin für dich da, und ich werde sorgen, dass wir dieses Problem endgültig lösen."

    # say L807 ang
    old "I really appreciate that, because I have nothing else to do and..."
    new "Das schätze ich wirklich, denn ich habe sonst nichts zu tun und..."

    # say L810 joh
    old "And? Is it everything ok Angelina?"
    new "Und? Ist alles in Ordnung, Angelina?"

    # say L811 ang
    old "I think it is not."
    new "Ich denke, es ist nicht."

    # say L812 joh
    old "Is there something else you think I need to know?"
    new "Gibt es noch etwas, das ich wissen sollte?"

    # say L813 ang
    old "Well, lately we have been fighting a lot because of that."
    new "Na ja, lately haben wir viel gestritten deswegen."

    # say L815 joh
    old "Oh, darling, I understand how hard it must be, it's not your fault of course."
    new "Oh, Liebling, ich verstehe, wie schwer es für dich sein muss, natürlich ist es nicht deine Schuld."

    # say L816 ang
    old "I'd love to think it's not my fault, but I know it is, it's me not working the way it should."
    new "Ich wünschte, es wäre nicht meine Schuld, aber ich weiß, dass es so ist, ich funktioniere einfach nicht so, wie es sollte."

    # say L817 joh
    old "Honey, I know how you feel, but I've seen the progress from a different perspective and I can assure you that you've been doing your best."
    new "Schatz, ich weiß, wie du dich fühlst, aber ich habe deinen Fortschritt aus einer anderen Perspektive gesehen und kann dir versichern, dass du dein Bestes gegeben hast."

    # say L819 ang
    old "I'm not sure about that..."
    new "Ich bin mir da nicht so sicher..."

    # say L820 joh
    old "Angelina remember we talked about it at the beginning."
    new "Angelina, erinnerst du dich, dass wir am Anfang darüber gesprochen haben."

    # say L821 joh
    old "Some treatments may take longer than expected and the results won't be seen in the short term, you have to be patient."
    new "Manche Behandlungen dauern länger als erwartet und die Ergebnisse zeigen sich nicht sofort, du musst geduldig sein."

    # say L822 ang
    old "I know, I know, you are right-"
    new "Ich weiß, ich weiß, Sie haben recht-"

    # say L823 joh
    old "This is one of the stages we can be on, the treatment is working..."
    new "Dies ist eine der Phasen, durch die wir gehen können, die Behandlung funktioniert..."

    # say L824 joh
    old "We need to keep calm and keep working. I know today's session will show some improvements."
    new "Wir müssen ruhig bleiben und weiterarbeiten. Ich bin sicher, dass die Sitzung heute Verbesserungen zeigen wird."

    # say L826 joh
    old "I am sure of it."
    new "Ich bin mir sicher."

    # say L827 ang
    old "Oh, great please, I need to get this resolved as soon as possible."
    new "Oh, großartig, ich muss das so schnell wie möglich klären."

    # say L828 joh
    old "Ok, so let's get started. We don't have time to lose."
    new "Okay, dann fangen wir an. Wir dürfen keine Zeit verlieren."

    # say L829 ang
    old "Perfect! Thank you."
    new "Perfekt! Danke."

    # say L830 joh
    old "Okay, let's start with the previous exercise, remember? The one with the dildo?"
    new "Okay, fangen wir mit dem letzten Übung an, erinnerst du dich? Die mit dem Dildo?"

    # say L831 ang
    old "Hmm, I'm not sure, I mean, it's quite different when I do it with a dildo than it is with a real one, you know?"
    new "Hmm, ich bin mir nicht sicher, ich meine, es ist ziemlich anders, wenn ich es mit einem Dildo mache als mit einem echten, weißt du?"

    # say L832 joh
    old "Of course, and that is why today we are going to do the exercise bandaged."
    new "Natürlich, und deshalb werden wir das Training heute verbunden machen."

    # say L833 joh
    old "I want you to focus on the sensations, your caresses, and your mouth."
    new "Ich möchte, dass du dich auf die Empfindungen konzentrierst, deine Berührungen und deinen Mund."

    # say L834 ang
    old "Hmm ok, that sounds interesting..."
    new "Hmm okay, das klingt interessant..."

    # say L835 joh
    old "It is, and today I bring you a new toy, this one is particularly realistic, and this would help us take big steps in treatment..."
    new "Es ist so, und heute bringe ich dir ein neues Spielzeug mit, das besonders realistisch ist. Damit können wir große Fortschritte in der Therapie machen..."

    # say L836 ang
    old "Huh! That sounds really nice."
    new "Das klingt wirklich gut."

    # say L837 joh
    old "Ok, let's get comfortable, and start with the session."
    new "Okay, lass uns bequem werden und mit der Sitzung beginnen."

    # say L849 joh
    old "I want you to play with it, rediscover its shape, I want you to immerse yourself in it, discover the textures, the flavors, the sensations."
    new "Ich möchte, dass du damit spielst, die Form neu entdeckst, ich möchte, dass du dich darin verlierst, die Texturen, die Geschmäcker, die Empfindungen erforschst."

    # say L851 joh
    old "Remember that the main objective is to replicate this moment with your husband, try to enjoy it, and focus on pleasure."
    new "Denken Sie daran, dass das Hauptziel es ist, diesen Moment mit Ihrem Mann zu reproduzieren. Versuchen Sie, es zu genießen und sich auf das Vergnügen zu konzentrieren."

    # say L852 joh
    old "Keep in mind, his pleasure will also be your satisfaction."
    new "Denk daran, sein Vergnügen wird auch dein Genuss sein."

    # say L854 joh
    old "Is it good?"
    new "Ist es gut?"

    # say L855 ang
    old "Yes."
    new "Ja."

    # say L856 joh
    old "Use your whole mouth, your lips, moistened enough that you can move them freely and seductively."
    new "Nutze deinen ganzen Mund, deine Lippen, feucht genug, dass du sie frei und verführerisch bewegen kannst."

    # say L857 ang
    old "I- I think I like it... a bit."
    new "Ich... ich glaube, ich mag es... ein bisschen."

    # say L858 joh
    old "That is perfect, now let's move on."
    new "Das ist perfekt, jetzt gehen wir weiter."

    # say L864 joh
    old "{i}Pss! Pss! Come here, it is your turn.{/i}"
    new "{i}Pss! Pss! Kommen Sie her, es ist Ihre Reihe.{/i}"

    # say L865 pla
    old "(Oh God...){i} I- I'm coming.{/i}"
    new "(O Gott…) {i} I- Ich komme. {/i}"

    # say L869 joh
    old "Ok, please hold on, here is the new toy. We are going to do the same process we were doing with the previous one."
    new "Okay, bitte warten Sie, hier ist das neue Spielzeug. Wir werden denselben Prozess wie beim vorherigen durchführen."

    # say L875 joh
    old "Enjoy this new toy I have for you, the exercise will be better, and you will find it almost real, so please let me know what you think."
    new "Genießen Sie dieses neue Spielzeug, das ich für Sie habe. Die Übung wird besser und Sie werden es fast real finden, also teilen Sie mir bitte mit, was Sie davon halten."

    # say L877 ang
    old "Oh yes, this texture is really different... Something tasty, warm and the texture is flexible."
    new "Oh ja, diese Textur ist wirklich anders... Etwas Leckeres, Warmes und die Textur ist weich und flexibel."

    # say L878 joh
    old "I'm glad you like it, please do it like we have learned."
    new "Ich bin froh, dass dir das gefällt, mach es bitte so, wie wir es gelernt haben."

    # say L888 joh
    old "Yeah, please enjoy it, let's do the exercise, imagine it's natural, think he needs to feel really pleased..."
    new "Ja, genieße es, machen wir die Übung, stell dir vor, es ist ganz natürlich, denk daran, er soll sich wirklich gut fühlen..."

    # say L889 joh
    old "Remember to change the rhythm and to use the fluids to make it easier."
    new "Denke daran, das Tempo zu verändern und die Flüssigkeiten zu nutzen, um es einfacher zu machen."

    # say L891 joh
    old "Do you think the bandage on your eyes is helping?"
    new "Denkst du, dass das Verband vor deinen Augen hilft?"

    # say L892 ang
    old "Absolutely, I'm just thinking on what you are saying and focus on the exercise and the sensations."
    new "Absolut, ich denke gerade über das nach, was du gesagt hast, und konzentriere mich auf die Übung und die Empfindungen."

    # say L893 joh
    old "Perfect, I knew it was going to work..."
    new "Perfekt, ich wusste, dass es funktionieren würde..."

    # say L894 ang
    old "This one is pretty nice, it tastes really good."
    new "Dieser schmeckt wirklich gut."

    # say L895 joh
    old "That's great, I want you to enjoy it, try a little harder, and think of it as a real one."
    new "Das ist großartig, ich will, dass du es genießt. Versuch es ein bisschen härter und stell dir vor, es wäre echt."

    # say L908 joh
    old "Angelina, relax. This is part of the treatment."
    new "Angelina, entspann dich. Das gehört zur Therapie."

    # say L910 ang
    old "What?! B- But- Who is he? D- Did I sucked his- ? Why didn't you tell me?"
    new "Was?! A-Aber- Wer ist er? H-Habe ich seinen-? Warum hast du mir das nicht gesagt?"

    # say L911 joh
    old "He is one of my assistants and is specifically trained for this."
    new "Er ist einer meiner Assistenten und wurde speziell für dies ausgebildet."

    # say L912 joh
    old "This was necessary, we were stuck for weeks, you needed a shock therapy to progress."
    new "Das war notwendig, wir steckten wochenlang fest, du brauchtest eine Schocktherapie, um voranzukommen."

    # say L913 ang
    old "What? B- but... I- I cheated on my husband because of you!"
    new "Was? A-aber... I-ich habe meinen Mann betrogen, wegen dir!"

    # say L914 joh
    old "Again, calm down Angelina..."
    new "Wieder, beruhige dich, Angelina..."

    # say L915 joh
    old "This wasn't cheating, everything was done professionally, in a controlled environment and under my supervision."
    new "Das war keine Untreue, alles wurde professionell, in einer kontrollierten Umgebung und unter meiner Aufsicht durchgeführt."

    # say L917 ang
    old "B- but I sucked another guy's cock and I don't even know him! I can't understand, I didn't want to do this to my husband..."
    new "Aber ich hab einen anderen Typen geblasen und kenne ihn nicht mal! Ich versteh das nicht, ich wollte meinem Mann das nicht antun..."

    # say L918 joh
    old "Listen Angelina, this is part of the treatment, we have been going through a long process."
    new "Hör zu, Angelina, das gehört zur Therapie, wir durchlaufen einen langen Prozess."

    # say L919 joh
    old "And this was a great step, and it's the right one to solve your problem."
    new "Und das war ein großer Schritt, und es ist der richtige, um dein Problem zu lösen."

    # say L920 ang
    old "I- I just-"
    new "Ich- ich-"

    # say L921 joh
    old "Do you realize the results of this session?"
    new "Bist du dir der Ergebnisse dieser Sitzung bewusst?"

    # say L922 joh
    old "You did great, you were very confident, you enjoyed the session, everything went just as planned."
    new "Du hast großartig gemacht, du warst sehr selbstbewusst, du hast die Sitzung genossen, alles hat sich genau so entwickelt, wie geplant."

    # say L923 ang
    old "B- but... I- I- ... and He... Who is-"
    new "Aber... ich... und er... Wer ist-"

    # say L924 joh
    old "Don't worry, [pla] is a very well-trained member of my team."
    new "Mach dir keine Sorgen, [pla] ist ein sehr gut ausgebildetes Mitglied meines Teams."

    # say L925 joh
    old "He has been prepared by me and has followed the treatments of another patient, he is very professional and trustworthy."
    new "Er wurde von mir vorbereitet und hat die Behandlungen eines anderen Patienten durchlaufen, er ist sehr professionell und vertrauenswürdig."

    # say L928 ang
    old "I'm sorry, but I can't accept this, I feel like I'm betraying my husband..."
    new "Es tut mir leid, aber das kann ich nicht akzeptieren, ich fühle mich, als würde ich meinen Mann betrügen..."

    # say L929 ang
    old "I think there was a misunderstanding about this... I need to go."
    new "Ich denke, da war ein Missverständnis... Ich muss gehen."

    # say L937 pla
    old "Wow, she has left!"
    new "Wow, sie ist gegangen!"

    # say L938 joh
    old "It's okay, she has a lot of emotions to think about."
    new "Es ist in Ordnung, sie muss viele Gefühle verarbeiten."

    # say L939 joh
    old "So she's going to need some time to process what happened and understand what was necessary within his process."
    new "Dann wird sie Zeit brauchen, um zu verarbeiten, was passiert ist, und zu verstehen, was in seinem Prozess notwendig war."

    # say L941 joh
    old "Absolutely! That's what is called 'shock therapy'."
    new "Absolut! Das nennt man Schocktherapie."

    # say L942 pla
    old "But, looks like she feels pretty bad."
    new "Aber sie fühlt sich ziemlich schlecht."

    # say L944 joh
    old "Well, it is something that needs to happen."
    new "Nun, es ist etwas, das geschehen muss."

    # say L945 joh
    old "She is dealing with changing the most ingrained ideas about her sexuality and the way she expresses her love, so she needs time."
    new "Sie arbeitet daran, die tief verwurzelten Vorstellungen über ihre Sexualität und die Art, wie sie ihre Liebe ausdrückt, zu verändern. Deshalb braucht sie Zeit."

    # say L947 joh
    old "The only thing we can do is wait until she internalizes these new emotions and figure out how to deal with them."
    new "Das Einzige, was wir tun können, ist zu warten, bis sie diese neuen Gefühle in sich verinnerlicht und herausfindet, wie sie damit umgehen kann."

    # say L948 pla
    old "I understand."
    new "Ich verstehe."

    # say L949 joh
    old "I appreciate your commitment, you did an amazing job today."
    new "Ich schätze Ihr Engagement, Sie haben heute großartige Arbeit geleistet."

    # say L950 joh
    old "I'm sorry, but I have to go, another patient should be here in a few minutes."
    new "Es tut mir leid, aber ich muss gehen, ein anderer Patient sollte in ein paar Minuten hier sein."

    # say L951 pla
    old "Oh ok... But when should I come again?"
    new "Oh ok... Aber wann sollte ich wieder kommen?"

    # say L952 joh
    old "Once Angelina books her next session I will let you know, for now you can come in the morning to continue training."
    new "Sobald Angelina ihren nächsten Termin bucht, lasse ich es Sie wissen. Bis dahin können Sie morgens kommen, um das Training fortzusetzen."

    # say L954 joh
    old "Thank you and see you later [pla]."
    new "Vielen Dank und bis später [pla]."

    # say L955 pla
    old "Ok, see you doctor."
    new "Ok, bis später Doktor."

    # say L973 roo
    old "No Angelina, I can't tolerate this anymore!"
    new "Nein Angelina, ich kann das nicht länger ertragen!"

    # say L974 ang
    old "I'm doing all what I can, just to make you happy."
    new "Ich mache alles, was ich kann, nur um dich glücklich zu machen."

    # say L975 roo
    old "I don't see the effort you make, and I'm tired of waiting so long for you."
    new "Ich sehe deine Anstrengungen nicht und ich bin müde, so lange auf dich zu warten."

    # say L976 ang
    old "Why are you such a prick? You can't see how much I love you..."
    new "Warum bist du so ein Arsch? Du siehst doch nicht, wie sehr ich dich liebe..."

    # say L977 roo
    old "I know that but I need a real woman, not a beautiful doll beside me..."
    new "Ich weiß, aber ich brauche eine echte Frau, keine schöne Puppe an meiner Seite..."

    # say L978 roo
    old "I have been really patient... But I can't wait anymore... Look for me when you are ready to have sex like a normal person."
    new "Ich hab echt geduldig gewartet... Aber ich kann nicht mehr warten... Such mich, wenn du bereit bist, wie eine normale Person zu ficken."

    # say L979 ang
    old "Come on darling... Please, you know this is hard for me..."
    new "Komm schon Schatz... Bitte, du weißt doch, dass das für mich auch schwer ist..."

    # say L980 roo
    old "Are you serious? Listen 5 months without sex I- I... You know what? I will not discuss it anymore, see you later at home..."
    new "Bist du ernsthaft? Hör zu, 5 Monate ohne Sex, ich... Du weißt was? Ich werde das nicht weiter diskutieren, bis später zu Hause..."

    # say L987 ang
    old "Wait! Roonnie- !"
    new "Warte! Roonnie-!"

    # say L994 pla
    old "I'm sorry..."
    new "Es tut mir leid..."

    # say L999 ang
    old "It's ok, welcom-"
    new "Es ist okay, willkommen-"

    # say L1000 ang
    old "(WHAT IS HE DOING HERE?.)"
    new "Was macht er hier?"

    # say L1001 pla
    old "Huh, t- thank you."
    new "Huh, d- danke."

    # say L1002 ang
    old "N- nice to see you again... Ehh-"
    new "N- nett, dich wiederzusehen... Ehh-"

    # say L1004 ang
    old "Yes, the doctor Johnson's... assistant, right?"
    new "Ja, der Assistent von Dr. Johnson, oder?"

    # say L1006 pla
    old "Right, is Roonnie your husband?"
    new "Stimmt, ist Roonnie dein Mann?"

    # say L1008 ang
    old "Hmm it seems like not for long... Anyway, how are you?"
    new "Hmm, scheint so, als würde das nicht mehr lange so bleiben... Auf jeden Fall, wie geht's dir?"

    # say L1010 pla
    old "I'm fine, thanks for asking..."
    new "Mir geht's gut, danke fürs Nachfragen..."

    # say L1011 ang
    old "Great, and what are you doing here?"
    new "Super, und was machst du hier?"

    # say L1012 pla
    old "I'm sorry, I was not aware you were here-"
    new "Entschuldigung, ich war mir nicht bewusst, dass du hier bist-"

    # say L1013 ang
    old "Oh no don't worry, actually, I'm sorry that you had to listen to all of... This."
    new "Oh nein, mach dir keine Sorgen, eigentlich tut es mir leid, dass du all das mit anhören musstest."

    # say L1014 pla
    old "Oh no, it wasn't my intention, I- I didn't know-"
    new "Oh nein, das war nicht meine Absicht, ich- ich wusste es nicht-"

    # say L1015 ang
    old "Never mind, though, I've been thinking about last time and wanted to apologize for the incident in Dr. Johnson's office."
    new "Lass es gut sein, ich habe über das letzte Mal nachgedacht und wollte mich für den Vorfall im Büro von Dr. Johnson entschuldigen."

    # say L1016 pla
    old "Oh, no worries about that, I'm sorry about you and husband, I know it's something hard to deal with."
    new "Ach, mach dir keine Sorgen deswegen, es tut mir leid für dich und deinen Mann, ich weiß, dass das schwer zu bewältigen ist."

    # say L1017 ang
    old "Yes, he is lovely but he is also tired, he is right about what he says, I can't satisfy his needs..."
    new "Ja, er ist lieb, aber er ist auch müde, und er hat recht mit dem, was er sagt, ich kann seine Bedürfnisse nicht mehr befriedigen..."

    # say L1019 ang
    old "I'm sorry to tell you all this, I don't even know you..."
    new "Es tut mir leid, dir das alles zu erzählen, ich kenne dich ja gar nicht..."

    # say L1020 pla
    old "It's ok, don't worry."
    new "Alles gut, mach dir keine Sorgen."

    # say L1021 ang
    old "I appreciate that... And I still embarrassed about the last time-"
    new "Ich schätze das... Und ich bin immer noch peinlich berührt wegen dem letzten Mal-"

    # say L1022 pla
    old "Oh please forget it, it's not important."
    new "Oh bitte, vergiss es einfach, das ist nicht wichtig."

    # say L1023 ang
    old "It is, I was disrespectful to both of you and left the place without any explanation, and it's not your fault of course."
    new "Es war das, ich war euch beiden gegenüber respektlos und bin ohne jede Erklärung gegangen, und es ist natürlich nicht eure Schuld."

    # say L1025 ang
    old "I felt like I was betraying my husband, I had never cheated on him and I really love him..."
    new "Ich hatte das Gefühl, meinen Mann zu betrügen, ich habe ihn noch nie betrogen und ich liebe ihn wirklich..."

    # say L1026 ang
    old "I still don't know why doctor Johnson did something like that."
    new "Ich verstehe immer noch nicht, warum Dr. Johnson so etwas getan hat."

    # say L1027 pla
    old "I understand your point, I can't say too much because I was part of the session but..."
    new "Ich verstehe dich, ich kann nicht zu viel sagen, weil ich dabei war, aber..."

    # say L1028 pla
    old "I know she is quite good at what she does, I have seen the progress of other patients."
    new "Ich weiß, dass sie ziemlich gut in dem ist, was sie macht. Ich habe den Fortschritt anderer Patienten gesehen."

    # say L1031 pla
    old "Yes, that is why I met her, because one of my friends needed help."
    new "Ja, deshalb habe ich sie kennengelernt, weil einer meiner Freunde Hilfe gebraucht hat."

    # say L1032 pla
    old "And it was a very surprising thing to see how she changed and how positive it was for her."
    new "Und es war überraschend zu sehen, wie sie sich verändert hat und wie positiv es für sie war."

    # say L1033 ang
    old "Hmm, I don't know..."
    new "Hmm, ich weiß nicht..."

    # say L1034 pla
    old "I know, at the beginning I was sceptical..."
    new "Ich weiß, am Anfang war ich skeptisch..."

    # say L1035 pla
    old "But later on, my friend was improving so much that I had to be honest and recognize how amazing she did it with her treatment."
    new "Aber später hat meine Freundin sich so sehr verbessert, dass ich ehrlich sein und zugeben musste, wie unglaublich gut sie es mit ihrer Behandlung gemacht hat."

    # say L1036 ang
    old "I think I am sceptical now..."
    new "Ich denke, ich bin jetzt skeptisch..."

    # say L1037 pla
    old "It is pretty normal, your process is not easy and these experiences are new for everyone."
    new "Es ist ziemlich normal, dein Prozess ist nicht einfach und diese Erfahrungen sind für jeden neu."

    # say L1038 pla
    old "However, if she dares to try this method, it is because she knows you well enough."
    new "Allerdings, wenn sie es wagt, diese Methode zu versuchen, dann kennt sie dich gut genug."

    # say L1040 pla
    old "I must confess that I was a bit nervous, but we were in a very professional environment."
    new "Ich muss gestehen, dass ich ein bisschen nervös war, aber wir waren in einer sehr professionellen Umgebung."

    # say L1041 pla
    old "Everything was planned to make sure that you could overcome your fear."
    new "Alles war geplant, um sicherzustellen, dass du deine Angst überwinden kannst."

    # say L1042 ang
    old "Hmm, I thinnk you are right, maybe I overreacted that day, my marriage needs whatever effort I can make."
    new "Hmm, ich denke, du hast recht, vielleicht habe ich damals überreagiert, meine Ehe braucht einfach alles, was ich tun kann."

    # say L1043 pla
    old "I know you were confused but I am sure doctor Johnson is expecting to see you again no matter what happens before."
    new "Ich weiß, du warst verwirrt, aber ich bin sicher, dass Dr. Johnson dich wiedersehen will, egal was dazwischenkommt."

    # say L1044 ang
    old "I owe her an apology, but yes I need to solve this problem as soon as possible."
    new "Ich schulde ihr eine Entschuldigung, aber ja, ich muss dieses Problem so schnell wie möglich lösen."

    # say L1045 pla
    old "She will be very happy to see you and the most important thing you can continue the process you are in, you need to trust her."
    new "Sie wird sich sehr freuen, dich zu sehen, und das Wichtigste ist, dass du den Prozess fortsetzen kannst, du musst ihr vertrauen."

    # say L1046 ang
    old "You're right, I need this now more than ever, my husband is about to dump me, so I'll do whatever it takes."
    new "Du hast recht, ich brauche das jetzt mehr denn je, mein Mann wird mich gleich verlassen, also werde ich alles tun, was nötig ist."

    # say L1047 pla
    old "Don't worry, visit doctor Johnson, she will help you."
    new "Mach dir keine Sorgen, geh zu Dr. Johnson, sie wird dir helfen."

    # say L1048 ang
    old "Hmm alright, I will do an appointment,  I think I need to continue with my treatment, thank you so much for your words."
    new "Hmm okay, ich werde einen Termin machen, ich denke, ich muss mit meiner Behandlung weitermachen, danke dir sehr für deine Worte."

    # say L1049 pla
    old "You are welcome,I hope things improve soon."
    new "Gern geschehen, ich hoffe, es wird bald besser."

    # say L1050 ang
    old "I appreciate it."
    new "Ich schätze es."

    # say L1051 pla
    old "Good bye."
    new "Tschüss."

    # say L1052 ang
    old "Bye Bye."
    new "Tschüss."

    # say L1076 joh
    old "Welcome back Angelina, I am very happy to have you here again."
    new "Willkommen zurück, Angelina, ich freue mich sehr, Sie wieder hier zu haben."

    # say L1077 ang
    old "Hi doctor, I'm terribly sorry for my behavior last time..."
    new "Hallo Doktor, ich entschuldige mich sehr für mein Verhalten beim letzten Mal..."

    # say L1078 joh
    old "Listen, the past is just a page we can't see anymore. Now tell me, how is everything going?"
    new "Hör zu, die Vergangenheit ist nur eine Seite, die wir nicht mehr sehen können. Erzähl mir, wie läuft es momentan?"

    # say L1079 ang
    old "I need your help, my husband will dump me anytime because of my problem and I don't know what to do."
    new "Ich brauche Ihre Hilfe, mein Mann wird mich wegen meines Problems jederzeit verlassen und ich weiß nicht, was ich tun soll."

    # say L1080 joh
    old "Hmm, okay, we have to think carefully because we'll need something that will deliver immediate results."
    new "Hmm, gut, wir müssen sorgfältig überlegen, denn wir brauchen etwas, das sofortige Ergebnisse bringt."

    # say L1091 joh
    old "Oh, [pla], welcome, I'm glad to see you here."
    new "Oh, [pla], willkommen, ich freue mich, Sie hier zu sehen."

    # say L1092 pla
    old "Hello Dr. Johnson, hi Angelina."
    new "Hallo Dr. Johnson, hallo Angelina."

    # say L1093 ang
    old "Hi... [pla], nice to see you again."
    new "Hi... [pla], schön, Sie wiederzusehen."

    # say L1095 joh
    old "Well, now that [pla] is here, I have an idea to go ahead with the treatment."
    new "Nun, da [pla] hier ist, habe ich eine Idee, wie wir mit der Behandlung weitermachen können."

    # say L1096 joh
    old "But how do you feel about what happened last time with [pla]?"
    new "Aber wie fühlst du dich bei dem, was beim letzten Mal mit [pla] passiert ist?"

    # say L1097 ang
    old "Hmm, I had a chance to talk to him and now I feel much better."
    new "Hmm, ich hatte die Gelegenheit, mit ihm zu sprechen, und jetzt fühle ich mich viel besser."

    # say L1098 joh
    old "Oh really? Well, that makes things a lot easier for us."
    new "Oh wirklich? Nun, das erleichtert die Sache für uns sehr."

    # say L1099 joh
    old "All right, then, today we are going to continue the treatment."
    new "Also gut, dann fahren wir heute mit der Behandlung fort."

    # say L1100 joh
    old "So, [pla] remember that we will need to apply all the concepts you have learned."
    new "So, [pla] erinnern Sie sich daran, dass wir alle Konzepte anwenden müssen, die Sie gelernt haben."

    # say L1102 joh
    old "But before we start I want you to help her to get relaxed a bit so please give her a massage."
    new "Aber bevor wir beginnen, möchte ich, dass Sie ihr ein wenig beim Entspannen helfen, also geben Sie ihr bitte eine Massage."

    # say L1104 joh
    old "Also, Angelina, I want you to become more familiar with the image of your husband."
    new "Also, Angelina, ich möchte, dass Sie sich mehr mit dem Bild Ihres Mannes vertraut machen."

    # say L1105 joh
    old "So, [pla] will help us with that, he will play the role of your husband."
    new "So, [pla] wird uns dabei helfen, er wird die Rolle Ihres Ehemanns spielen."

    # say L1107 joh
    old "We will start with a basic exercise, this will prepare your mind and body, then we will have the real session."
    new "Wir fangen mit einer grundlegenden Übung an, das wird deinen Geist und Körper vorbereiten, dann folgt die eigentliche Sitzung."

    # say L1108 joh
    old "So, let's begin, please take off your shirt."
    new "So, lass uns beginnen, bitte zieh dein Shirt aus."

    # say L1109 ang
    old "But... I- I'm not wearing a bra..."
    new "Aber... ich trage keinen BH..."

    # say L1110 joh
    old "I know that darling."
    new "Ich weiß das, Liebling."

    # say L1111 ang
    old "So, do you mean stay topless?"
    new "So, meinst du, ich soll oben ohne bleiben?"

    # say L1112 joh
    old "That's correct, he will give you a little breasts massage, so, you can relax and get in the mood for the next exercise."
    new "Das ist korrekt, er wird dir eine kleine Brustmassage geben, damit du dich entspannen und in Stimmung für die nächste Übung kommen kannst."

    # say L1115 ang
    old "I- I am not... Sure about it..."
    new "Ich bin mir nicht... sicher..."

    # say L1116 joh
    old "Oh, darling, don't worry, we're already working on that, right? You shouldn't feel insecure about your body..."
    new "Oh, Liebling, mach dir keine Sorgen, wir arbeiten schon daran, oder? Du solltest dich nicht unsicher fühlen wegen deinem Körper..."

    # say L1117 ang
    old "I know, but... Having a man in the room makes this a little more difficult..."
    new "Ich weiß, aber... Ein Mann im Raum macht das Ganze ein bisschen schwieriger..."

    # say L1119 joh
    old "I know you had a tough adolescence, your body grew fast and you didn't feel comfortable about it..."
    new "Ich weiß, dass du eine schwierige Pubertät hattest, dein Körper ist schnell gewachsen und du dich damit nicht wohl gefühlt hast..."

    # say L1120 joh
    old "But, you already know that your body is beautiful, all men love it, your husband loves it, right?"
    new "Aber du weißt doch, dass dein Körper wunderschön ist, alle Männer lieben ihn, dein Mann liebt ihn, oder?"

    # say L1121 ang
    old "Yes, but he doesn't care..."
    new "Ja, aber er kümmert sich nicht drum..."

    # say L1123 joh
    old "Of course not, you are very hot, you are incredible, what do you think [pla]? You like them? Those are bigger than mine, aren't they?"
    new "Natürlich nicht, Sie sind sehr heiß, Sie sind unglaublich, was denken Sie [pla]? Gefallen Ihnen die? Die sind größer als meine, oder?"

    # say L1125 pla
    old "... Y- yes... I think you have a hug-... Beautiful boobs..."
    new "... J- ja... Ich denke, du hast s-... wunderschöne Titten..."

    # say L1127 joh
    old "Honey, I can tell you that I have not seen a more beautiful breast."
    new "Honey, ich kann Ihnen sagen, dass ich noch nie schönere Brüste gesehen habe."

    # say L1128 ang
    old "It's the first time someone tells me that..."
    new "Das ist das erste Mal, dass mir jemand das sagt..."

    # say L1129 joh
    old "It's not going to be the last time. I'm sure, now please get comfortable because our session about to begins."
    new "Das wird sicherlich nicht das letzte Mal sein. Bitte machen Sie es sich jetzt bequem, denn unsere Sitzung beginnt gleich."

    # say L1130 joh
    old "I told you and I want you to enjoy it a lot... [pla], please!"
    new "Ich habe es Ihnen gesagt und ich will, dass Sie es sehr genießen... [pla], bitte!"

    # say L1131 pla
    old "Of course!"
    new "Natürlich!"

    # say L1132 ang
    old "Thank... You..."
    new "Danke... dir..."

    # say L1133 joh
    old "Alright, let's take out those big babies..."
    new "Na gut, lassen Sie uns diese großen Schönheiten entfernen..."

    # say L1139 joh
    old "Ohhh, they are really beautiful... Don't you think [pla]?"
    new "Ohhh, die sind wirklich schön... Findest du nicht, [pla]?"

    # say L1141 joh
    old "Hahaha, you see Angelina, now he is speechless... Come on, [pla] please have a seat, and you Angelina, have a seat over his lap."
    new "HAHAHA, sehen Sie Angelina, jetzt ist er sprachlos... Kommen Sie, [pla] setzen Sie sich bitte, und Sie Angelina, setzen Sie sich auf seinen Schoß."

    # say L1151 joh
    old "Ok, [pla] to start, do it gently..."
    new "Ok, [pla] um zu beginnen, machen Sie es sanft..."

    # say L1152 pla
    old "Ok, like this?"
    new "Ok, so wie das?"

    # say L1153 joh
    old "Yeah, how do you feel Angelina?"
    new "Ja, wie fühlen Sie sich, Angelina?"

    # say L1154 ang
    old "I- It's ok... I'm fine..."
    new "I- Es ist okay... Mir geht es gut..."

    # say L1165 ang
    old "Next exercise?"
    new "Nächste Übung?"

    # say L1166 joh
    old "It's ok, You just follow [pla], he will walk you through. Now please take off your clothes."
    new "Es ist in Ordnung, du folgst einfach [pla], er wird dich durchführen. Bitte zieh dich jetzt aus."

    # say L1167 ang
    old "Do you want me to take off everything?"
    new "Möchten Sie, dass ich alles ausziehe?"

    # say L1169 joh
    old "Yes, please, and then lie on the bed..."
    new "Ja, bitte, und dann leg dich aufs Bett..."

    # say L1170 ang
    old "... Hmm alright."
    new "Hmm okay."

    # say L1172 joh
    old "Ohh, look at that, you so thick girl... Ok [pla], now is your turn."
    new "Ohh, schauen Sie sich das an, Sie sind ja so eine dicke Frau... Ok [pla], jetzt bist du dran."

    # say L1173 pla
    old "My... T- turn? What do you mean?"
    new "Mein... D-Druck? Was meinst du damit?"

    # say L1174 joh
    old "I'm sorry, I meant it's your turn to please Angelina. Now give oral sex to her."
    new "Entschuldigung, ich meinte, es ist Ihre Aufgabe, Angelina zu befriedigen. Jetzt machen Sie oralen Sex mit ihr."

    # say L1175 ang
    old "O- oral sex?"
    new "O- oral Sex?"

    # say L1177 joh
    old "Ok, Angelina, please remember this is part of the treatment for you, and your marriage."
    new "Ok, Angelina, bitte denke daran, dass das Teil der Therapie für dich und deine Ehe ist."

    # say L1178 ang
    old "You are right, I'm sorry."
    new "Sie haben recht, es tut mir leid."

    # say L1179 joh
    old "It's ok, let's move on, [pla] do your job, please."
    new "Es ist okay, lass uns weitermachen, [pla] mach deinen Job, bitte."

    # say L1187 joh
    old "[pla] please do it as soft as possible, she must just feel you over there."
    new "[pla] bitte mach es so sanft wie möglich, sie soll dich nur dort spüren."

    # say L1189 joh
    old "Close your eyes Angelina, focus on the sensations, and enjoy the experience."
    new "Schließe die Augen, Angelina, konzentriere dich auf die Empfindungen und genieße das Erlebnis."

    # say L1190 ang
    old "I will try..."
    new "Ich werde es versuchen..."

    # say L1199 joh
    old "Keep focused [pla], use your tongue like we have learned."
    new "Bleib konzentriert [pla], benutze deine Zunge so, wie wir es geübt haben."

    # say L1211 ang
    old "Wow, you can't imagine how happy I feel."
    new "Wow, Sie können sich nicht vorstellen, wie glücklich ich mich fühle."

    # say L1213 joh
    old "Well, that's fantastic because it means the process is working out."
    new "Na, das ist fantastisch, weil es bedeutet, dass der Prozess funktioniert."

    # say L1214 joh
    old "If you feel more confident to have sexual interactions, it means you are ready to try this with your husband with no fears."
    new "Wenn du dich sicherer fühlst, sexuelle Interaktionen zu haben, bedeutet das, dass du bereit bist, das mit deinem Mann ohne Angst auszuprobieren."

    # say L1216 joh
    old "Great, so let's get dressed and go to the therapy bedroom."
    new "Perfekt, dann ziehen wir uns an und gehen ins Therapie-Schlafzimmer."

    # say L1226 joh
    old "Ok, it was everything for today, but we need to continue working pretty hard."
    new "Okay, das war alles für heute, aber wir müssen ziemlich hart weiterarbeiten."

    # say L1227 joh
    old "Next session is really important, so, guys please get ready and see you soon."
    new "Die nächste Sitzung ist wirklich wichtig, also Jungs und Mädels, bitte bereitet euch gut vor und bis bald."

    # say L1229 ang
    old "Oh thank you, I will be here on time, bye bye!"
    new "Oh danke, ich werde pünktlich da sein, tschüss!"

    # say L1230 pla
    old "Good bye!"
    new "Tschüss!"

    # say L1245 joh
    old "Hi Angelina, how is everything going?"
    new "Hallo Angelina, wie läuft alles?"

    # say L1246 ang
    old "Wonderful! I applied what we did with my husband and he was really happy, now I just want to learn more."
    new "Wunderbar! Ich habe das angewendet, was wir mit meinem Mann gemacht haben, und er war wirklich glücklich. Jetzt will ich einfach mehr lernen."

    # say L1247 joh
    old "And you will, our session today is aimed at helping you do more exercises with your husband."
    new "Und das werden Sie, unsere Sitzung heute richtet sich darauf aus, Ihnen zu helfen, mehr Übungen mit Ihrem Mann zu machen."

    # say L1248 ang
    old "Sounds great!"
    new "Klingt großartig!"

    # say L1258 pla
    old "Hi, how are you doing?"
    new "Hallo, wie geht es dir?"

    # say L1259 ang
    old "Hi [pla], I'm doing amazing."
    new "Hi [pla], ich bin super."

    # say L1260 joh
    old "Welcome [pla], good to see you again, are you ready to start the new session?"
    new "Willkommen [pla], schön Sie wiederzusehen, sind Sie bereit, die neue Sitzung zu beginnen?"

    # say L1261 pla
    old "Yes, I am ready."
    new "Ja, ich bin bereit."

    # say L1265 joh
    old "Ok, Angelina, this time we are going to practice a fellation, this time with no fears and doing your best, ok?"
    new "Okay, Angelina, diesmal üben wir eine Fellatio, und zwar ohne Angst und mit aller Kraft, verstanden?"

    # say L1266 ang
    old "Oh... I had to... S- suck his cock?"
    new "Oh... Ich musste... S- seinen Schwanz lutschen?"

    # say L1268 joh
    old "Of course, last time you received all the pleasure, today we will make sure that you are able to provide it too."
    new "Natürlich, beim letzten Mal hast du all die Freude empfangen, heute werden wir sicherstellen, dass du sie auch geben kannst."

    # say L1269 joh
    old "So that we can guarantee that your husband will also be satisfied."
    new "Damit wir sicherstellen können, dass auch dein Mann zufrieden ist."

    # say L1271 ang
    old "Hmm, I guess you are right..."
    new "Hmm, ich schätze, Sie haben recht..."

    # say L1272 joh
    old "Great, just remember what we had practiced before with the dildo, and by the way you already sucked his cock before, so don't worry."
    new "Perfekt, denk dran, was wir vorher mit dem Dildo geübt haben, und außerdem hast du seinen Schwanz schon mal gelutscht, da musst du dir keine Sorgen machen."

    # say L1274 joh
    old "Ok, our time is short we need to work, so, let's start. [pla], take off your pants and Angelina, please start the fellation."
    new "Ok, unsere Zeit ist knapp, wir müssen anfangen. [pla], zieh deine Hose aus und Angelina, bitte beginne mit der Fellatio."

    # say L1286 ang
    old "Hmm... "
    new "Hmm..."

    # say L1288 joh
    old "Please enjoy it Angelina, try to focus only on what you feel, like last time, don't think about [pla], just enjoy what you can feel."
    new "Bitte genieße es, Angelina, versuch dich nur auf das zu konzentrieren, was du fühlst, wie beim letzten Mal, denk nicht an [pla], genieße einfach, was du spürst."

    # say L1300 joh
    old "Alright, now let's continue with the next exercise."
    new "In Ordnung, jetzt fahren wir mit dem nächsten Übung fort."

    # say L1303 ang
    old "NEXT EXERCISE?"
    new "Nächste Übung?"

    # say L1305 joh
    old "Of course, you're the one asking for faster improvement, aren't you?"
    new "Natürlich, du bist diejenige, die schneller Fortschritte verlangt, oder?"

    # say L1306 joh
    old "Also, we need you to be able to have sex with your husband as soon as possible, so your marriage can be saved."
    new "Also, wir müssen sicherstellen, dass du möglichst bald wieder mit deinem Mann schlafen kannst, damit deine Ehe gerettet werden kann."

    # say L1307 ang
    old "Hmm, you're right..."
    new "Hmm, Sie haben recht..."

    # say L1308 joh
    old "Alright, let's go to the bedroom, so you can have sex with [pla]."
    new "Okay, lass uns ins Schlafzimmer gehen, damit du mit [pla] schlafen kannst."

    # say L1311 joh
    old "Oh, relax, you are going to love it."
    new "Oh, entspann dich, du wirst es lieben."

    # say L1318 joh
    old "Alright, [pla] I need you to remember your trainin."
    new "Okay, [pla] ich muss dich daran erinnern, was du gelernt hast."

    # say L1319 joh
    old "You're going to have sex but you can't stop until she has reached the orgasm."
    new "Sie werden Sex haben, aber Sie dürfen nicht aufhören, bis sie den Orgasmus erreicht hat."

    # say L1323 joh
    old "Angelina, I need you to understand this, in your treatment, there is no way to learn about sex without having sex."
    new "Angelina, ich muss dir das erklären, bei deiner Therapie gibt es keinen Weg, über Sex zu lernen, ohne Sex zu haben."

    # say L1324 joh
    old "That is why we are here in a safe therapy so that you learn to enjoy it."
    new "Deshalb sind wir hier in einer sicheren Therapie, damit du lernst, es zu genießen."

    # say L1325 ang
    old "... Ok, thank you doctor Johnson."
    new "... Ok, danke Doktor Johnson."

    # say L1326 joh
    old "Alright, please, both get naked and let's start."
    new "Alles klar, bitte zieht euch beide aus und lasst uns beginnen."

    # say L1352 ang
    old "Wow, that was really good, I thank you so much doctor Johnson."
    new "Wow, das war wirklich gut, ich danke Ihnen sehr, Dr. Johnson."

    # say L1353 joh
    old "You still have a lot to learn, but now you are open to new experiences, and [pla] you did an outstanding job."
    new "Sie haben noch viel zu lernen, aber jetzt sind Sie offen für neue Erfahrungen, und [pla] Sie haben eine ausgezeichnete Leistung gezeigt."

    # say L1355 ang
    old "Yes, you [pla], you made me feel things I've never felt before with any man."
    new "Ja, Sie [pla], Sie haben mich Dinge fühlen lassen, die ich noch nie mit einem Mann gespürt habe."

    # say L1356 pla
    old "... I- I'm glad everything turned out okay..."
    new "... Ich- Ich bin froh, dass alles gut ausgegangen ist..."

    # say L1358 joh
    old "Alright, get dressed and let's go to the therapy room, I have a new patient in a few minutes."
    new "In Ordnung, ziehen Sie sich an und kommen Sie mit in den Therapieraum, ich habe in ein paar Minuten einen neuen Patienten."

    # say L1368 joh
    old "Alright, please apply these exercises with your husband."
    new "Bitte führen Sie diese Übungen mit Ihrem Ehemann durch."

    # say L1369 joh
    old "Focus on enjoying, but don't push it, as you will see the changes gradually."
    new "Konzentriere dich auf das Genießen, aber dränge dich nicht, du wirst die Veränderungen allmählich bemerken."

    # say L1370 ang
    old "Ok, I will have that in mind."
    new "Ok, ich werde das im Hinterkopf behalten."

    # say L1371 joh
    old "I'm glad to see you happy, I can't wait to hear how it went with your husband."
    new "Ich freue mich, dich glücklich zu sehen, ich kann es kaum erwarten zu hören, wie es mit deinem Mann gelaufen ist."

    # say L1372 ang
    old "Yes, I am a little anxious to try it as soon as possible."
    new "Ja, ich bin ein bisschen nervös, es so schnell wie möglich auszuprobieren."

    # say L1373 joh
    old "Okay, then don't waste any more time and go home. See you at the next session, darling."
    new "Okay, dann verschwende keine Zeit mehr und geh nach Hause. Bis zur nächsten Sitzung, Liebling."

    # say L1374 ang
    old "Alright, thank you so much!"
    new "Alles gut, vielen Dank!"

    # say L1375 joh
    old "See you. And please, have fun!"
    new "Bis dann. Und bitte, amüsier dich!"

    # say L1385 joh
    old "That was a significant step with her therapy."
    new "Das war ein wichtiger Schritt in ihrer Therapie."

    # say L1387 joh
    old "And you, Congratulations on such a fantastic performance, I can see that my lessons were very helpful, maybe better than I thought."
    new "Und Ihnen, Herzlichen Glückwunsch zu dieser fantastischen Leistung, ich sehe, dass meine Unterrichtsstunden sehr hilfreich waren, vielleicht sogar besser als gedacht."

    # say L1388 pla
    old "Thank you, I appreciate all your patient with me."
    new "Danke, ich schätze Ihre Geduld mit mir."

    # say L1389 joh
    old "You are welcome. Anyway, I have to get ready for my next patient, so, see you at the next session."
    new "Gern geschehen. Auf jeden Fall muss ich mich jetzt auf meinen nächsten Patienten vorbereiten, also bis zur nächsten Sitzung."

    # say L1390 pla
    old "Sure, good bye Dr. Johnson."
    new "Sicher, auf Wiedersehen Dr. Johnson."

    # say L1406 joh
    old "Welcome Angelina, how is everything going?"
    new "Willkommen Angelina, wie läuft alles?"

    # say L1407 ang
    old "I couldn't be happier."
    new "Ich könnte nicht glücklicher sein."

    # say L1408 joh
    old "So, were you able to do the exercises with your husband without problems? "
    new "Also, hast du die Übungen mit deinem Mann ohne Probleme machen können?"

    # say L1409 ang
    old "That's right! And my husband is really happy, your work is incredible!"
    new "Das stimmt! Und mein Mann ist wirklich glücklich, Ihre Arbeit ist unglaublich!"

    # say L1410 joh
    old "I'm so happy to hear that! I've prepared a new lesson today, you'll love it..."
    new "Das freut mich sehr zu hören! Ich habe heute eine neue Lektion vorbereitet, die wird dir gefallen..."

    # say L1421 joh
    old "Welcome [pla], we are happy to have you here."
    new "Willkommen [pla], wir freuen uns, Sie hier willkommen zu heißen."

    # say L1422 pla
    old "Hello!"
    new "Hallo!"

    # say L1425 joh
    old "Well guys, now [pla] is here, there's no time to lose, so, let's go to the room."
    new "Na dann, jetzt wo [pla] hier ist, verlieren wir keine Zeit und gehen in den Raum."

    # say L1426 ang
    old "Perfect!"
    new "Perfekt!"

    # say L1434 joh
    old "According to the advances that you mentioned that sex with your husband is reaching... Let's practice again with a sexual exercise."
    new "Gemäß den Fortschritten, die du erwähnt hast, dass der Sex mit deinem Mann erreicht hat... Lassen wir das noch einmal mit einer sexuellen Übung durchgehen."

    # say L1436 joh
    old "But, before we start, I want you to practice oral sex, that will drive your husband crazy."
    new "Aber bevor wir anfangen, möchte ich, dass du Oralsex übst, das wird deinen Mann wahnsinnig machen."

    # say L1437 ang
    old "Got it! I want to make sure I'm doing this the right way for my husband."
    new "Verstanden! Ich will sicherstellen, dass ich es richtig für meinen Mann mache."

    # say L1454 joh
    old "Now that we are ready, I have a special task for you Angelina."
    new "Nun, da wir bereit sind, habe ich eine besondere Aufgabe für dich, Angelina."

    # say L1455 ang
    old "Ok, I'm ready for whatever you want."
    new "Okay, ich bin bereit für alles, was Sie wollen."

    # say L1456 joh
    old "I love that enthusiasm! I want you to take the lead and fuck him wild, I want you to be the one to say what to do."
    new "Ich liebe dieses Engagement! Ich will, dass du die Führung übernimmst und ihn wild fickst, ich will, dass du sagst, was zu tun ist."

    # say L1457 joh
    old "So, I want you to get on him and take the rhythm and intensity, I want you to take an active role in sex..."
    new "So, ich möchte, dass du die Führung übernimmst und das Tempo und die Intensität bestimmst, ich möchte, dass du eine aktive Rolle beim Sex übernimmst."

    # say L1459 ang
    old "Hmm... I- I will try, get ready [pla]."
    new "Hmm... I- Ich werde es versuchen, bereite dich vor [pla]."

    # say L1476 ang
    old "You are the most amazing therapist I've ever had."
    new "Sie sind der unglaublichste Therapeut, den ich je hatte."

    # say L1477 joh
    old "I appreciate all the effort you did, I know it was not easy but now you can see the results."
    new "Ich schätze all die Mühe, die du dir gemacht hast, ich weiß, es war nicht einfach, aber jetzt kannst du die Ergebnisse sehen."

    # say L1478 ang
    old "Doctor, I have, no words to say how much I thank you for all the knowledge and patience you invested..."
    new "Doktor, ich habe keine Worte, um Ihnen zu sagen, wie dankbar ich bin für all das Wissen und die Geduld, die Sie investiert haben..."

    # say L1480 ang
    old "And I thank you too [pla], you really help me with your... Abilities."
    new "Und ich danke Ihnen auch [pla], Sie haben mir wirklich mit Ihren... Fähigkeiten geholfen."

    # say L1481 pla
    old "It's a pleasure, I'm glad to have helped you."
    new "Es ist mir ein Vergnügen, ich freue mich, dir geholfen zu haben."

    # say L1483 joh
    old "Ok, it's time guys, get dressed and let's go to the therapy bedroom..."
    new "Ok, es ist Zeit, Leute, zieht euch an und lasst uns ins Therapie-Schlafzimmer gehen..."

    # say L1494 joh
    old "Ok, today we finished our team practice sessions. Angelina, you and I will continue the process together with therapy."
    new "Ok, heute haben wir unsere Team-Trainings-Sessions beendet. Angelina, Sie und ich werden den Prozess gemeinsam mit der Therapie fortsetzen."

    # say L1495 ang
    old "Oh... So, there are no more sessions with [pla]?"
    new "Oh... Also gibt es keine Sitzungen mehr mit [pla]?"

    # say L1497 joh
    old "No, he did his job and now we can continue with therapy. Now is the moment to put all of this in practice with your husband."
    new "Nein, er hat seine Aufgabe erledigt und jetzt können wir mit der Therapie weitermachen. Jetzt ist der Moment, um all das mit deinem Mann in die Praxis umzusetzen."

    # say L1498 ang
    old "Oh, alright..."
    new "Oh, gut..."

    # say L1499 joh
    old "Remember we have other things to work on together. If we see we would need [pla]'s help again, I would bring him to therapy."
    new "Denk daran, wir haben noch andere Dinge, an denen wir gemeinsam arbeiten müssen. Wenn wir feststellen, dass wir wieder Hilfe von [pla] benötigen, werde ich ihn zur Therapie mitbringen."

    # say L1501 ang
    old "Oh, great, I'm glad to hear that. Anyway, I can't describe how happy I am and how happy I will make my husband..."
    new "Oh, toll, das freut mich zu hören. Egal, ich kann gar nicht beschreiben, wie glücklich ich bin und wie glücklich ich meinen Mann machen werde..."

    # say L1502 ang
    old "I will practice a lot with him! Thank you doctor Johnson, I will call you to make a new appointment."
    new "Ich werde viel mit ihm üben! Danke, Dr. Johnson, ich rufe Sie an, um einen neuen Termin zu machen."

    # say L1503 joh
    old "Ok, please have fun, it was nice to walk you through this process."
    new "Ok, bitte viel Spaß, es war schön, Sie durch diesen Prozess zu führen."

    # say L1506 pla
    old "Uhh... Goodbye Angelina."
    new "Uhh... Tschüss Angelina."

    # say L1514 joh
    old "Well, [pla], I really appreciate your job, you did amazing, every single session, I'm very proud of you."
    new "Nun, [pla], ich schätze Ihre Arbeit wirklich sehr, Sie haben in jeder einzelnen Sitzung fantastisch gemacht, ich bin sehr stolz auf Sie."

    # say L1515 pla
    old "Oh, t- thank you, I just followed all your instructions."
    new "Oh, d-danke, ich habe einfach alle Ihre Anweisungen befolgt."

    # say L1516 joh
    old "I know. By the way,  I want to have another session, just for you and me..."
    new "Ich weiß. Übrigens, ich möchte noch eine Session haben, nur für dich und mich..."

    # say L1517 joh
    old "But I have another patient coming, it's too late to cancel it..."
    new "Aber ich habe noch einen Patienten, es ist zu spät, um abzusagen..."

    # say L1518 pla
    old "Another session, what do you mean?"
    new "Eine weitere Sitzung, was meinst du damit?"

    # say L1520 joh
    old "Hmm, I mean I need to check something, so let's call it another lesson..."
    new "Hmm, ich meine, ich muss noch etwas überprüfen, also lassen Sie uns es als eine weitere Lektion betrachten..."

    # say L1521 pla
    old "... Hmm ok, sure."
    new "Hmm okay, klar."

    # say L1522 joh
    old "I know next session is going to be pretty fun, so please sleep well."
    new "Ich weiß, dass die nächste Sitzung ziemlich spaßig wird, also bitte gut schlafen."

    # say L1524 joh
    old "I am considering giving you a prize before we start another treatment, just because you were amazing with Angelina..."
    new "Ich denke daran, Ihnen vor dem nächsten Termin ein Geschenk zu machen, einfach weil Sie mit Angelina fantastisch waren..."

    # say L1526 joh
    old "Just come see me tomorrow and don't be late."
    new "Kommen Sie morgen zu mir und seien Sie pünktlich."

    # say L1527 pla
    old "Alright, I will be here."
    new "In Ordnung, ich werde da sein."

    # say L1528 joh
    old "Great, see you!"
    new "Gut, bis morgen!"

    # say L1543 joh
    old "Hi, I was waiting for you desperately."
    new "Guten Morgen, ich habe Sie verzweifelt erwartet."

    # say L1544 pla
    old "Good morning, thank you I tried to be on time-"
    new "Guten Morgen, danke, ich habe versucht pünktlich zu sein-"

    # say L1545 joh
    old "You are, don't worry! It's just that I don't want to talk."
    new "Sie sind es, machen Sie sich keine Sorgen! Es ist nur so, dass ich nicht reden will."

    # say L1546 pla
    old "Uhh, w- wha-?"
    new "Uhh, w-was?"

    # say L1548 joh
    old "Let's go to the room, there is no time to lose."
    new "Lassen Sie uns ins Zimmer gehen, wir dürfen keine Zeit verlieren."

    # say L1555 joh
    old "Well, I want to fuck you right now, no lessons, no patients just hard sex."
    new "Nun, ich will dich jetzt ficken, keine Lektionen, keine Patienten, nur harten Sex."

    # say L1557 joh
    old "Why don't you make yourself comfortable and let me suck your dick?"
    new "Warum machen Sie es sich nicht bequem und lassen Sie mich Ihren Schwanz lutschen?"

    # say L1580 joh
    old "Yummy!"
    new "Lecker!"

    # say L1587 joh
    old "It's delicious, do you like the way I suck it?"
    new "Es ist köstlich, gefällt Ihnen, wie ich es mache?"

    # say L1598 joh
    old "Wow, I needed that session. You can't imagine how hot it was, you did amazing."
    new "Wow, ich brauchte diese Sitzung. Sie können sich nicht vorstellen, wie heiß es war, Sie waren fantastisch."

    # say L1599 pla
    old "I did my best."
    new "Ich hab mein Bestes gegeben."

    # say L1600 joh
    old "Absolutely, you fucked me as I needed to.  I think I need a little more, though..."
    new "Absolut, Sie haben mich genau so gevögelt, wie ich es gebraucht habe. Ich denke, ich brauche noch ein bisschen mehr, aber..."

    # say L1601 joh
    old "Just keeps coming over sometimes just to... You know, have some fun lessons."
    new "Er kommt einfach manchmal vorbei, um... Na ja, um ein paar Spaßstunden zu haben."

    # say L1603 joh
    old "Perfect, and when I need your help again with another patient, I'll let you know."
    new "Perfekt, und wenn ich wieder Ihre Hilfe bei einem anderen Patienten brauche, lasse ich es Sie wissen."

    # say L1605 joh
    old "Ok, now I have to get ready for the session with my next patient, see you soon [pla]."
    new "Ok, dann muss ich mich jetzt auf die Sitzung mit meinem nächsten Patienten vorbereiten, bis bald [pla]."

    # say L1606 pla
    old "Got it. See you, doctor Johnson."
    new "Verstanden. Bis dann, Dr. Johnson."

    # say L1630 roo
    old "Hey buddy! What's up?"
    new "Hey Kumpel! Was ist los?"

    # say L1632 pla
    old "H- Hi."
    new "H- Hallo."

    # say L1633 ang
    old "Hey [pla], how are you doing?"
    new "Hey [pla], wie geht's dir?"

    # say L1634 roo
    old "Oh, so you guys know each other?"
    new "Oh, kennt ihr euch schon?"

    # say L1636 pla
    old "Uhh... W- well- "
    new "Uhh... W-was..."

    # say L1638 ang
    old "Yes! He is the assistant of doctor Johnson... He helped us with... With the treatment..."
    new "Ja! Er ist der Assistent von Dr. Johnson... Er hat uns bei... Bei der Therapie geholfen..."

    # say L1639 roo
    old "Wow, you are quite young, I didn't know you had such wonderful therapy abilities. You must know buddy, you saved my marriage!"
    new "Wow, du bist ja noch so jung, und trotzdem hast du solche wunderbaren Therapiefähigkeiten. Du musst wissen, Kumpel, du hast meine Ehe gerettet!"

    # say L1641 roo
    old "You don't know how important was this, I feel so thankful that I hope you go to the store so I can give an enormous discount."
    new "Du hast keine Ahnung, wie wichtig das war, ich bin so dankbar, dass ich hoffe, du gehst in den Laden, damit ich dir einen riesigen Rabatt geben kann."

    # say L1642 pla
    old "Oh, thanks."
    new "Oh, danke."

    # say L1643 roo
    old "I have no words to tell how I appreciate what you did for me, look Angelina is pregnant and we are very happy about it."
    new "Ich habe keine Worte, um auszudrücken, wie dankbar ich bin für das, was du für mich getan hast. Schau, Angelina ist schwanger und wir sind sehr glücklich darüber."

    # say L1646 roo
    old "I know the universe will reward you for this magnificent help and-"
    new "Ich weiß, das Universum wird dich für diese großartige Hilfe belohnen und-"

    # say L1647 ang
    old "We really appreciate your help. Darling we need to go, I want to get some fresh air."
    new "Wir schätzen deine Hilfe wirklich. Schatz, wir müssen los, ich will ein bisschen frische Luft schnappen."

    # say L1648 pla
    old "Oh sure, it was nice to see that you guys are happy."
    new "Oh sicher, es war schön zu sehen, dass ihr glücklich seid."

    # say L1649 roo
    old "We are very happy to see you too, now excuse us, we have to go."
    new "Es freut uns auch, dich zu sehen, aber jetzt müssen wir los."

    # say L1650 pla
    old "... Sure."
    new "... Klar."

    # say L1651 ang
    old "Have a nice day [pla]!"
    new "Einen schönen Tag noch [pla]!"

    # say L1652 roo
    old "Yes buddy! Have a great day."
    new "Ja Kumpel! Hab einen tollen Tag."

    # say L1653 pla
    old "See you!"
    new "Bis später!"

    # say L1658 pla
    old "Wow... So, she is pregnant..."
    new "Wow... Also, sie ist schwanger..."

    # say L1674 pla
    old "Hi Dr. Johnson, how are you?"
    new "Hallo Dr. Johnson, wie geht es Ihnen?"

    # say L1675 joh
    old "Hi [pla], I'm excellent, thanks for asking. What about yourself, young man?"
    new "Hallo [pla], ich bin ausgezeichnet, danke für Ihre Nachfrage. Wie geht es Ihnen, junger Mann?"

    # say L1676 pla
    old "I'm good, thanks! And hmm, I would like to talk about s- something with you, it would take just a couple of minutes."
    new "Ich bin gut, danke! Und hmm, ich würde gern etwas mit Ihnen besprechen, es dauert nur ein paar Minuten."

    # say L1677 joh
    old "Sure, what is it about?"
    new "Natürlich, worum geht es?"

    # say L1678 pla
    old "I wouldn't like to bother you but I'm f- facing a tough situation now and I'm l- looking for a job."
    new "Ich möchte Sie nicht belästigen, aber ich stecke gerade in einer schwierigen Situation und suche Arbeit."

    # say L1679 pla
    old "You know I'm a hard worker and I would do whatever you assign to me."
    new "Ich bin ein harter Arbeiter und werde alles tun, was Sie mir zuweisen."

    # say L1681 joh
    old "I see, but... I can't offer you anything right now."
    new "Ich sehe, aber... ich kann Ihnen im Moment nichts anbieten."

    # say L1682 joh
    old "I don't have any patients for you at the moment..."
    new "Ich habe momentan keine Patienten für Sie..."

    # say L1684 pla
    old "R- really? I had some hopes on you."
    new "Wirklich? Ich hatte doch Hoffnungen in dich gesetzt."

    # say L1685 pla
    old "Maybe if you think of somethin-"
    new "Vielleicht, wenn Sie sich etwas einfallen lassen-"

    # say L1686 joh
    old "[pla], I really don't have anything since I don't have many patients now, however, if I get to need you, I'll reach you out."
    new "[pla], ich habe im Moment wirklich nichts, da ich nicht viele Patienten habe, aber wenn ich Sie brauche, melde ich mich bei Ihnen."

    # say L1688 joh
    old "You have been very well trained and you were exceptional at your duties with the last patient."
    new "Sie wurden sehr gut ausgebildet und waren bei Ihrem letzten Patienten außergewöhnlich."

    # say L1689 joh
    old "I'll call you when I need you..."
    new "Ich werde Sie anrufen, wenn ich Sie brauche."

    # say L1691 pla
    old "I see... Hmm, alright... I'll keep looking for it. Thanks Dr. Johnson, I appreciate your time."
    new "Ich sehe... Hmm, okay... Ich werde weiter danach suchen. Danke Dr. Johnson, ich schätze Ihre Zeit."

    # say L1692 pla
    old "Goodbye and keep me posted in case you have jobs for me, I would appreciate it."
    new "Auf Wiedersehen und halten Sie mich auf dem Laufenden, falls Sie Aufträge für mich haben. Ich würde es zu schätzen wissen."

    # say L1693 joh
    old "Sure I will, have a nice day."
    new "Natürlich, ich halte Sie auf dem Laufenden. Einen schönen Tag noch."


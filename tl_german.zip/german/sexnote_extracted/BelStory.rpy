# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/BelStory.rpy
translate german strings:

    # say L20 pla
    old "Hey guys, how are you?"
    new "Hey Leute, wie geht's?"

    # say L25 hin
    old "Hi [pla], good morning."
    new "Hi [pla], guten Morgen."

    # say L26 mik
    old "Hi dude."
    new "Hi Kumpel."

    # say L27 bil
    old "Hey, what's up?"
    new "Hey, was ist los?"

    # say L30 pla
    old "What were you guys talking about?"
    new "Worüber habt ihr gerade gesprochen?"

    # say L34 bil
    old "Oh you know, just listening to Mike's dumb stuff."
    new "Oh, du weißt schon, ich hab mir Mikes blöden Quatsch angehört."

    # say L38 mik
    old "Hey, what do you mean dumb stuff?"
    new "Hey, was meinst du mit dummem Zeug?"

    # say L39 mik
    old "As I recall, you seemed to think it was very interesting."
    new "Wie ich mich erinnere, hast du es damals ziemlich interessant gefunden."

    # say L44 bel
    old "Well, it was only because there's nothing else going on this early in the morning."
    new "Na ja, es war nur, weil morgens so früh sowieso nichts los ist."

    # say L57 hin
    old "Hey guys, I think we should get going, classes are about to start."
    new "Hey Leute, ich glaube, wir sollten los, die Kurse fangen gleich an."

    # say L58 mik
    old "Yeah, we probably should."
    new "Ja, wir sollten wahrscheinlich."

    # say L75 bel
    old "[pla], wait."
    new "[pla], warte."

    # say L82 pla
    old "Yeah? What's up?"
    new "Klar, was ist los?"

    # say L83 bel
    old "Uhm, the thing is... That there's something I need your help with."
    new "Ähm, die Sache ist... Dass ich deine Hilfe bei etwas brauche."

    # say L85 pla
    old "Sure, what is it?"
    new "Klar, was ist los?"

    # say L86 bel
    old "Hmm, I think it would be better if we talk about this somewhere else."
    new "Hmm, ich denke, es wäre besser, wenn wir darüber woanders reden."

    # say L88 bel
    old "Besides, there's something I have to show you."
    new "Außerdem gibt es da noch was, das ich dir zeigen muss."

    # say L89 bel
    old "So, how about you come to my house after classes."
    new "Dann komm doch nach dem Unterricht zu mir nach Hause."

    # say L91 pla
    old "Uh, yeah, sure..."
    new "Klar, warum nicht..."

    # say L100 luc
    old "Good morning Belle, [pla]."
    new "Guten Morgen Belle, [pla]."

    # say L102 pla
    old "Godd morning Miss Lucy."
    new "Guten Morgen Miss Lucy."

    # say L103 bel
    old "Good morning Miss Lucy."
    new "Guten Morgen Miss Lucy."

    # say L106 luc
    old "Guys, classes are about to start."
    new "Jungs, die Unterrichtsstunden fangen gleich an."

    # say L107 luc
    old "It's not good that you two stay here talking in the hallway."
    new "Es ist nicht gut, dass ihr beiden hier im Flur rumsteht und quatscht."

    # say L109 luc
    old "Good, now go to the classroom you two..."
    new "Gut, dann geht jetzt in den Klassenraum, ihr beiden..."

    # say L141 bel
    old "Ugh, that was eternal."
    new "Mann, das war endlos."

    # say L142 bel
    old "Miss Lucy just kept talking and talking."
    new "Miss Lucy hat einfach weiter und weiter geredet."

    # say L143 pla
    old "Tell me about it. I thought classes weren't going to end today."
    new "Erzähl mir was. Ich dachte, die Unterrichtsstunden würden heute nie enden."

    # say L144 bel
    old "Yeah, but anyway."
    new "Ja, aber egal."

    # say L145 bel
    old "Now that that is over, will you come with me to my house?"
    new "Jetzt, wo das vorbei ist, kommst du mit zu mir nach Hause?"

    # say L146 pla
    old "Uhh, sure."
    new "Uhh, klar."

    # say L147 bel
    old "Alright, then let's go!"
    new "Dann lass uns gehen!"

    # say L173 pla
    old "What?! Oh."
    new "Was?! Oh."

    # say L175 pla
    old "I'm just realizing that I have never visited your house before."
    new "Ich merke gerade, dass ich noch nie bei dir zu Hause war."

    # say L177 bel
    old "Oh, I see."
    new "Oh, ich verstehe."

    # say L179 bel
    old "Well, I try to avoid inviting people over because my mom tends to be intrusive and it annoys me."
    new "Na ja, ich versuche, Leute nicht einzuladen, weil meine Mom neugierig ist und mich das nervt."

    # say L181 bel
    old "Although Mike has been here before."
    new "Obwohl Mike schon mal hier war."

    # say L183 bel
    old "I had to bring him when we were doing that team project."
    new "Ich musste ihn mitbringen, als wir an dem Teamprojekt gearbeitet haben."

    # say L185 bel
    old "And he met my mom..."
    new "Und er hat meine Mom kennengelernt..."

    # say L187 bel
    old "It wasn't any fun to see him constantly trying to hit on her..."
    new "Es war kein Vergnügen, ihn ständig versuchen zu sehen, sie anzumachen..."

    # say L188 pla
    old "I can imagine him doing that."
    new "Ich kann mir vorstellen, wie er das gemacht hat."

    # say L189 bel
    old "It was so awkward."
    new "Das war so peinlich."

    # say L191 bel
    old "But anyway, what do you think about the house?"
    new "Aber egal, was denkst du über das Haus?"

    # say L193 pla
    old "Uh... It's very nice. I like the decoration a lot."
    new "Äh... Es ist sehr schön. Mir gefällt die Einrichtung wirklich."

    # say L195 bel
    old "You do? My mom would be happy to hear that, she's really into interior design."
    new "Du findest es wirklich schön? Meine Mom würde sich freuen, das zu hören. Sie ist total in Innendesign."

    # say L196 pla
    old "She is? Really?"
    new "Wirklich?"

    # say L198 bel
    old "Yep, she's a graphic designer, so, she's quite into decorating and stuff."
    new "Klar, sie ist Grafikdesignerin, also ist sie ziemlich in Dekoration und so was drin."

    # say L200 pla
    old "Hmm, I guess that makes a lot of sense."
    new "Hmm, das ergibt Sinn."

    # say L202 bel
    old "So... Changing the subject."
    new "So... Thema wechseln."

    # say L204 bel
    old "About... Uhhh, what I wanted to talk to you [pla]."
    new "Über... Ähh, was ich dir sagen wollte [pla]."

    # say L205 pla
    old "Right, right, w- what is it?"
    new "Stimmt, stimmt, w-was ist es?"

    # say L206 bel
    old "Well, there's something I want to let you know about."
    new "Na ja, da ist was, das ich dir sagen will."

    # say L208 bel
    old "Something I- I've been keeping hidden about myself."
    new "Etwas, das ich- ich bisher vor dir verborgen habe."

    # say L209 pla
    old "Uhh... W- what is it?"
    new "Uhh... W- was ist es?"

    # say L210 bel
    old "Well, I- I think it's easier if I show you..."
    new "Na ja, ich glaube, es ist einfacher, wenn ich es dir zeige..."

    # say L213 bel
    old "This is it."
    new "Das ist es."

    # say L225 pla
    old "Oh wow, w- what is this?"
    new "Oh wow, w- was ist das?"

    # say L235 bel
    old "Well, not exactly."
    new "Na ja, nicht ganz."

    # say L236 bel
    old "I'm a webcam model, it's a little different."
    new "Ich bin eine Webcam-Model, das ist ein bisschen anders."

    # say L240 bel
    old "This is something I've been doing for a while now."
    new "Das mache ich schon seit einer Weile."

    # say L241 bel
    old "I started by streaming video games, and I enjoyed it a lot."
    new "Ich habe angefangen, Videospiele zu streamen, und ich habe es echt genossen."

    # say L243 bel
    old "Over time some of my followers started asking me about some..."
    new "Im Laufe der Zeit haben einige meiner Follower angefangen, mich nach ein paar..."

    # say L244 bel
    old "More adult content."
    new "Mehr erwachsene Inhalte."

    # say L246 bel
    old "I started thinking about it. And decided I should give it a go."
    new "Ich habe darüber nachgedacht und beschlossen, es auszuprobieren."

    # say L249 bel
    old "After all, I like being in front of the cameras, and I figured it would be alright as long as my face wasn't shown."
    new "Immerhin mag ich es vor der Kamera zu stehen, und ich dachte, es wäre in Ordnung, solange mein Gesicht nicht zu sehen ist."

    # say L252 bel
    old "From then on, I kept getting deeper and deeper into it."
    new "Von da an bin ich immer tiefer reingekommen."

    # say L254 bel
    old "After all, I discovered I really enjoyed it."
    new "Im Grunde habe ich festgestellt, dass ich es wirklich genieße."

    # say L255 bel
    old "I've gotten a lot of experience doing this now."
    new "Ich habe jetzt viel Erfahrung damit gesammelt."

    # say L256 pla
    old "I- I guess I get it."
    new "Ich- Ich glaube, ich verstehe es."

    # say L258 bel
    old "It's been good actually. I've even gotten to make some money off of it."
    new "Es war eigentlich ganz gut. Ich habe sogar ein bisschen Geld damit verdient."

    # say L260 pla
    old "Oh! That sounds good."
    new "Oh! Das klingt gut."

    # say L262 pla
    old "But why are you suddenly bringing this up?"
    new "Aber warum bringst du das plötzlich zur Sprache?"

    # say L263 pla
    old "It's just that I imagine this is the type of thing you would want to keep secret, right?"
    new "Es ist nur so, dass ich mir vorstelle, das ist die Art von Sache, die man lieber geheim hält, oder?"

    # say L265 bel
    old "I guess, so. Yeah."
    new "Ich schätze, ja."

    # say L266 bel
    old "But there's something happening, and I need some help with it."
    new "Aber da ist was los, und ich brauche dabei Hilfe."

    # say L267 bel
    old "And I think you're the one that could help me with it."
    new "Und ich denke, du bist der Richtige, der mir dabei helfen kann."

    # say L269 pla
    old "M- me?!"
    new "M- ich?!"

    # say L271 bel
    old "You see, this is only my first year camming."
    new "Siehst du, das ist erst mein erstes Jahr als Camgirl."

    # say L273 bel
    old "But my results have been very good. I have received a lot of fan engagement."
    new "Aber meine Ergebnisse waren sehr gut. Ich habe viel Engagement von meinen Fans bekommen."

    # say L276 bel
    old "I even got nominated for an award!"
    new "Ich bin sogar für einen Preis nominiert worden!"

    # say L277 pla
    old "That's great Belle!"
    new "Das ist toll, Belle!"

    # say L278 pla
    old "Uh, I- I mean... I think so..."
    new "Äh, ich- ich meine... Ich denke schon..."

    # say L280 bel
    old "Yeah, it is. It's a {b}'Female Revelation Streamer of the Year.'{/b}"
    new "Ja, ist es. Es ist ein {b}'Female Revelation Streamer of the Year'.{/b}"

    # say L281 bel
    old "And I'm one of the forerunners for it!"
    new "Und ich bin eine der Vorkämpferinnen dafür!"

    # say L282 pla
    old "I see, congrats Belle, that's awesome!"
    new "Ich sehe, gratuliere Belle, das ist toll!"

    # say L283 pla
    old "But all of that sounds very good."
    new "Aber das alles klingt sehr gut."

    # say L284 pla
    old "I don't see what you could need my help with."
    new "Ich sehe nicht, was du von meiner Hilfe brauchen könntest."

    # say L286 bel
    old "You see, these awards are measured as a popularity contest."
    new "Du siehst, diese Auszeichnungen werden wie ein Popularity-Wettbewerb bewertet."

    # say L288 bel
    old "So, the winner is decided by who gets the most fan votes and tips in their category by the end of the time period."
    new "Also, der Gewinner wird durch die meisten Fanstimmen und -spenden in ihrer Kategorie bis zum Ende der Zeitspanne entschieden."

    # say L290 bel
    old "The number of votes and tips each person receives is put into a public chart, so, we know who's in the lead."
    new "Die Anzahl der Stimmen und Trinkgelder, die jeder erhält, wird in eine öffentliche Tabelle eingetragen, also wissen wir, wer vorn liegt."

    # say L291 bel
    old "Well, that's only until the final days of the contest."
    new "Na ja, das gilt nur bis zu den letzten Tagen des Wettbewerbs."

    # say L292 bel
    old "Some days before it's over the results are hidden and the winner is announced at the end."
    new "Ein paar Tage vor Schluss werden die Ergebnisse versteckt und der Gewinner erst am Ende bekanntgegeben."

    # say L294 pla
    old "I see."
    new "Ich verstehe."

    # say L295 bel
    old "I've been doing pretty well on the polls."
    new "Ich habe ziemlich gut in den Umfragen abgeschnitten."

    # say L297 bel
    old "Since the beginning of the contest I have been at the top of the standings."
    new "Seit Beginn des Wettbewerbs bin ich an der Spitze der Tabelle."

    # say L298 bel
    old "So much so that I thought I was going to win it easily."
    new "So sehr, dass ich dachte, ich würde es leicht gewinnen."

    # say L300 bel
    old "However, recently a new model has been getting all the attention."
    new "Allerdings hat sich lately eine neue Model alle Aufmerksamkeit geschnappt."

    # say L301 bel
    old "There's this girl named Lana. She just appeared seemingly out of nowhere and overtook me."
    new "Da ist dieses Mädchen namens Lana. Sie ist einfach so aufgetaucht und hat mich überflügelt."

    # say L303 bel
    old "With the way things are going, she's going to run away with the lead, and beat me."
    new "Mit dem Tempo, das sie vorlegt, wird sie mir den Vorsprung nehmen und mich schlagen."

    # say L305 pla
    old "Oh, I'm sorry Belle, it sucks that something like this is happening."
    new "Oh, das tut mir leid Belle, dass so was passiert."

    # say L307 bel
    old "Oh! It really does! Especially because she's not getting the lead in the competition fairly!"
    new "Oh! Das tut es wirklich! Vor allem, weil sie den Hauptpreis im Wettbewerb nicht fair gewinnt!"

    # say L309 bel
    old "Well, I've been thinking about why this girl is so popular."
    new "Na ja, ich hab darüber nachgedacht, warum dieses Mädchen so beliebt ist."

    # say L311 bel
    old "And I figured it out."
    new "Und ich hab's rausgefunden."

    # say L312 bel
    old "It's just because she's not doing the same things I and the other girls in the category are doing."
    new "Es ist einfach, weil sie nicht das Gleiche macht wie ich und die anderen Mädchen in der Kategorie."

    # say L314 pla
    old "Isn't she doing livestreams like the others?"
    new "Macht sie nicht auch Livestreams wie die anderen?"

    # say L316 bel
    old "Yes, but, as I told you, the category in which I'm competing is called ‘Female Revelation Streamer of the Year.'"
    new "Ja, aber wie ich dir schon sagte, die Kategorie, in der ich mitmache, heißt „Female Revelation Streamer of the Year“."

    # say L317 bel
    old "It's a {i}single-person{/i} category."
    new "Es ist eine {i}Ein-Personen-{/i}-Kategorie."

    # say L318 bel
    old "Otherwise couples or even groups could take part and compete in it."
    new "Sonst könnten Paare oder sogar Gruppen daran teilnehmen und darum konkurrieren."

    # say L319 bel
    old "But they have their own category."
    new "Aber die haben ihre eigene Kategorie."

    # say L320 bel
    old "However, she is doing streams with a guy..."
    new "Allerdings macht sie Streams mit einem Typen..."

    # say L322 bel
    old "Obviously, this type of content is much more appealing to the audience since it's literally a sex live show."
    new "Offensichtlich ist dieser Typ von Inhalt viel ansprechender für das Publikum, da es buchstäblich eine Sex-Show im Live-Stream ist."

    # say L323 bel
    old "And this gives her a significant advantage over those of us who participate individually in our category..."
    new "Und das gibt ihr einen deutlichen Vorteil gegenüber uns, die wir einzeln in unserer Kategorie mitmachen..."

    # say L325 bel
    old "So she should be participating in another category, for example, {i}'Best Streamer couple of the Year'{/i}."
    new "Dann sollte sie in einer anderen Kategorie mitmachen, zum Beispiel {i}'Beste Streamer-Couple des Jahres'{/i}."

    # say L326 pla
    old "I see, I suppose that makes sense."
    new "Ich verstehe, das ergibt Sinn."

    # say L327 bel
    old "Of course, that makes sense! I even thought they would move her to a different category or suspend her for doing a different type of content..."
    new "Natürlich, das ergibt Sinn! Ich dachte sogar, sie würden sie in eine andere Kategorie verschieben oder sie für einen anderen Typ von Inhalt suspendieren..."

    # say L328 bel
    old "But apparently, there aren't any rules against what she is doing to compete in this category..."
    new "Aber anscheinend gibt es keine Regeln, die sie daran hindern, in dieser Kategorie mitzumachen..."

    # say L329 bel
    old "Since when she was nominated in the category, she was doing solo streams."
    new "Seit sie nominiert wurde, macht sie Solo-Streams."

    # say L330 bel
    old "But then, does that mean she can do whatever she wants and win?"
    new "Aber dann, bedeutet das, sie kann machen, was sie will, und trotzdem gewinnen?"

    # say L331 bel
    old "Taking advantage of doing things from other categories to get more attention?"
    new "Von anderen Kategorien zu profitieren, um mehr Aufmerksamkeit zu bekommen?"

    # say L332 pla
    old "Hmm, yes, I understand. If you look at it a certain way, it's like she's cheating."
    new "Hmm, ja, ich verstehe. Wenn man es so sieht, ist es wie Betrug."

    # say L333 bel
    old "That's exactly what I think too! But the webcam platform doesn't seem to care..."
    new "Das denke ich auch! Aber die Webcam-Plattform scheint das nicht zu stören..."

    # say L334 bel
    old "After all, is not the same to see a couple fucking on screen, to just seeing somebody playing with a toy or something."
    new "Immerhin ist es nicht das Gleiche, eine Couple beim ficken zu sehen, als nur jemanden mit einem Toy zu sehen oder so."

    # say L336 bel
    old "And the problem with that is that she's only doing it to win..."
    new "Und das Problem daran ist, dass sie es nur macht, um zu gewinnen..."

    # say L337 bel
    old "Which means she's only interested in winning in this category now, by using tactics that of course gain her more popularity here."
    new "Das bedeutet, sie interessiert sich jetzt nur dafür zu gewinnen, indem sie Taktiken anwendet, die ihr hier natürlich mehr Popularität einbringen."

    # say L338 bel
    old "Because she knows she wouldn't win doing what we do, or doing what she's doing in a couples category!"
    new "Weil sie weiß, dass sie so nicht gewinnen würde wie wir oder in der Kategorie Paare!"

    # say L342 bel
    old "Look, this is a recording from a recent streaming she did."
    new "Schau, das ist eine Aufnahme von einem ihrer letzten Streams."

    # say L361 sis2
    old "I know this is what you guys have been waiting for."
    new "Ich weiß, dass ihr darauf gewartet habt."

    # say L362 sis2
    old "You all wanted to see me sucking a big cock didn't you?"
    new "Ihr wolltet mich doch alle dabei sehen, wie ich einen großen Schwanz lutsche, oder?"

    # say L382 bel
    old "Do you see? She's practically doing live sex!"
    new "Siehst du? Sie macht praktisch Live-Sex!"

    # say L384 bel
    old "She shouldn't be in the 'Female Revelation Streamer' category!"
    new "Sie gehört nicht in die Kategorie 'Weibliche Offenbarungs-Streamerin'!"

    # say L386 pla
    old "I guess that her winning the contest by doing something that no one else is doing is unfair."
    new "Ich denke, es ist unfair, dass sie den Wettbewerb gewinnt, indem sie etwas tut, was niemand sonst macht."

    # say L387 pla
    old "I get it, I get it."
    new "Verstanden, verstanden."

    # say L388 pla
    old "And what are you planning to do about it?"
    new "Und was planst du dagegen zu unternehmen?"

    # say L390 bel
    old "Well, to be honest [pla]..."
    new "Na ja, ehrlich gesagt [pla]..."

    # say L394 bel
    old "I really like doing this, a lot."
    new "Ich mag das echt sehr, ehrlich gesagt."

    # say L396 bel
    old "I've worked so hard from the beginning."
    new "Ich hab' von Anfang an so viel Arbeit reingesteckt."

    # say L398 bel
    old "And ever since I started I've put a lot of effort into being number one."
    new "Und seitdem ich angefangen habe, habe ich mich total ins Zeug gelegt, um Nummer eins zu sein."

    # say L399 bel
    old "In fact, until just a few days ago I was first in the rankings."
    new "Tatsächlich war ich bis vor wenigen Tagen noch an erster Stelle in den Rankings."

    # say L400 bel
    old "So, I think I should be the one that wins that award!"
    new "Dann sollte ich auch derjenige sein, der diesen Preis gewinnt!"

    # say L401 bel
    old "Not some rando that just came out nowhere!"
    new "Nicht irgendeine Fremde, die plötzlich aus dem Nichts auftaucht!"

    # say L402 bel
    old "So, I've decided that I'm going to retake the lead in the contest."
    new "Also, ich hab entschieden, dass ich die Führung im Wettbewerb zurückgewinnen werde."

    # say L405 bel
    old "That's where I want you to help me."
    new "Da will ich, dass du mir hilfst."

    # say L406 pla
    old "Uhm... H- how?"
    new "Äh... W-wie?"

    # say L409 bel
    old "I want to fight fire with fire!"
    new "Ich will Feuer mit Feuer bekämpfen!"

    # say L410 bel
    old "I want to see if she will actually beat me if both of us are doing the same."
    new "Ich will sehen, ob sie mich tatsächlich schlägt, wenn wir beide das Gleiche tun."

    # say L414 pla
    old "You want to record yourself having sex on camera?!"
    new "Du willst dich beim Sex aufnehmen lassen?!"

    # say L416 bel
    old "W- Well... Technically we would be having s- sex live, but it would be recorded."
    new "W- Wohl... Technisch gesehen würden wir live Sex haben, aber es würde aufgezeichnet werden."

    # say L418 bel
    old "Well, yeah, that's why I need your help..."
    new "Na ja, genau deshalb brauche ich deine Hilfe..."

    # say L419 bel
    old "T- that way, I- I think I'll manage to get the votes to surpass Lana."
    new "D- dann, d- denke ich, kriege ich die Stimmen, um Lana zu überholen."

    # say L421 pla
    old "That's not the point..."
    new "Das ist nicht der Punkt..."

    # say L422 pla
    old "I kinda get what you're saying, but, this is a little unexpected, you know?"
    new "Ich verstehe schon, was du meinst, aber das ist schon ziemlich überraschend, weißt du?"

    # say L424 bel
    old "I- I know it is. But listen, I've put a lot of effort into this."
    new "Ich- Ich weiß, dass es das ist. Aber hör zu, ich habe echt viel Arbeit reingesteckt."

    # say L425 bel
    old "From streaming video games to getting into camming, and growing my fanbase."
    new "Vom Streamen von Videospielen bis zum Cammen und meinem Fanbase-Aufbau."

    # say L427 bel
    old "Losing is just not an option..."
    new "Verlieren ist einfach keine Option..."

    # say L429 bel
    old "So I need your help, please."
    new "Dann brauche ich deine Hilfe, bitte."

    # say L430 bel
    old "It will only be a couple of times, only until I can overtake her."
    new "Es wird nur ein paar Mal sein, nur bis ich sie überholen kann."

    # say L432 pla
    old "I mean, I think I get it."
    new "Ich meine, ich denke ich kapiere es."

    # say L433 pla
    old "What I don't understand is why it has to be me."
    new "Was ich nicht verstehe, ist warum es ausgerechnet ich sein muss."

    # say L434 pla
    old "Don't you know somebody that knows about this sort of thing?"
    new "Kennst du jemanden, der sich damit auskennt?"

    # say L435 pla
    old "You know... a professional?"
    new "Du weißt schon... einen Profi?"

    # say L437 bel
    old "Actually, I don't know anybody... Any men, I mean."
    new "Eigentlich kenne ich niemanden... Ich meine, keinen Mann."

    # say L439 bel
    old "I've been doing everything by myself."
    new "Ich mache alles selbst."

    # say L442 bel
    old "I haven't ever worked with anybody before, so I don't know any man inside this business that would do it."
    new "Ich habe noch nie mit jemandem zusammengearbeitet, also kenne ich keinen Mann in diesem Geschäft, der das machen würde."

    # say L444 bel
    old "But if I'm completely honest with you [pla], even if I knew a webcam actor or model I would still prefer to do it with you."
    new "Aber wenn ich ehrlich zu dir bin [pla], auch wenn ich einen Webcam-Schauspieler oder Model kennen würde, würde ich es lieber mit dir machen."

    # say L446 pla
    old "What? R- Really?"
    new "Was? Wirklich?"

    # say L448 bel
    old "Well, I don't want to do this with some unknown person. For me sex is a very intimate thing."
    new "Na ja, ich will das nicht mit irgendjemandem machen. Für mich ist Sex eine sehr intime Sache."

    # say L450 bel
    old "I at least want it to be with someone I trust."
    new "Ich will es wenigstens mit jemandem tun, dem ich vertraue."

    # say L451 pla
    old "I- uh... I understand."
    new "Ich- äh... Ich verstehe."

    # say L453 pla
    old "But I'm don't know Belle. I don't think I want people watching me have sex on camera."
    new "Aber ich weiß nicht, Belle. Ich glaube, ich will nicht, dass mich andere beim Sex auf Video sehen."

    # say L455 pla
    old "Besides, and I know this is kind of obvious... That also means that you and I would have to have sex, right?"
    new "Außerdem, und ich weiß, das ist irgendwie offensichtlich... Das bedeutet auch, dass wir miteinander schlafen müssen, oder?"

    # say L456 pla
    old "Are you ok with that?"
    new "Bist du damit okay?"

    # say L458 bel
    old "I- I do... As I told you [pla], I trust you."
    new "Ich- Ich tu's... Wie ich dir [pla] gesagt habe, ich vertraue dir."

    # say L460 bel
    old "Also, is not as if you and I have never done that sort of thing before, right?"
    new "Also, es ist ja nicht so, als hätten wir das noch nie gemacht, oder?"

    # say L461 bel
    old "This won't be too different from that."
    new "Das wird nicht viel anders sein."

    # say L463 bel
    old "And about the whole appearing on camera thing, you don't have to worry about that."
    new "Und was das Ganze mit der Kamera angeht, da musst du dir keine Sorgen machen."

    # say L465 bel
    old "I will focus the camera so that your face doesn't show in any way."
    new "Ich werde die Kamera so einstellen, dass dein Gesicht nirgendwo zu sehen ist."

    # say L467 bel
    old "Please [pla], I want to win this."
    new "Bitte [pla], ich will das gewinnen."

    # say L469 bel
    old "I know this is just what I need to win against Lana."
    new "Ich weiß, dass ich das brauche, um gegen Lana zu gewinnen."

    # say L476 pla
    old "I guess it's fine if it helps you..."
    new "Ich schätze, es ist in Ordnung, wenn es dir hilft..."

    # say L477 bel
    old "So, you'll do it?"
    new "Dann machst du es?"

    # say L480 pla
    old "I can't believe it, but I will."
    new "Ich kann es kaum glauben, aber ich werde es tun."

    # say L482 bel
    old "Thanks a lot [pla]!"
    new "Danke schön [pla]!"

    # say L483 bel
    old "So, I have to prepare everything on stream."
    new "Dann muss ich alles für den Stream vorbereiten."

    # say L485 bel
    old "I have to let my fans know about it."
    new "Ich muss meinen Fans Bescheid sagen."

    # say L488 bel
    old "Let them know there's a surprise coming and stuff."
    new "Lass sie wissen, dass eine Überraschung auf sie wartet und so."

    # say L489 bel
    old "I'll let you know when we'll do it."
    new "Ich lass es dich wissen, wann wir es machen."

    # say L493 bel
    old "Thanks a lot [pla]."
    new "Danke schön [pla]."

    # say L496 pla
    old "So... "
    new "So..."

    # say L497 pla
    old "I think I'll see you later then."
    new "Dann sehen wir uns später."

    # say L499 bel
    old "Sure, I'll prepare everything and let you know when we're ready to stream."
    new "Klar, ich bereite alles vor und melde mich, wenn wir startbereit sind."

    # say L500 pla
    old "Alright, great!"
    new "Okay, super!"

    # say L501 pla
    old "Bye Belle."
    new "Tschüss Belle."

    # say L502 bel
    old "Bye [pla], and thank you so much again."
    new "Tschüss [pla], und danke nochmal vielmals."

    # say L526 pla
    old "Hi Belle, good morning, how are you?"
    new "Hi Belle, guten Morgen, wie geht es dir?"

    # say L528 bel
    old "Listen [pla], my mother told me she won't be in the house this afternoon."
    new "Hör zu [pla], meine Mutter hat mir gesagt, dass sie heute Nachmittag nicht zu Hause sein wird."

    # say L529 bel
    old "She has a meeting or something."
    new "Sie hat ein Meeting oder so."

    # say L531 bel
    old "So, today can be the first day that you come and help me with my stream."
    new "Dann kann heute der erste Tag sein, an dem du kommst und mir bei meinem Stream hilfst."

    # say L535 bel
    old "Plus, I think this is a good opportunity for you to make your first appearance on camera."
    new "Plus, ich denke, das ist eine gute Gelegenheit für dich, dein erstes Mal vor der Kamera zu sein."

    # say L536 bel
    old "So that you can get a feel for it, and start getting used to beign on camera."
    new "Damit du dich einfühlst und dich daran gewöhnst, vor der Kamera zu sein."

    # say L538 pla
    old "O- ok sure, no problem."
    new "O- ok, klar, kein Problem."

    # say L539 pla
    old "L- lets do it."
    new "L- lass es uns machen."

    # say L541 bel
    old "Ok, great!"
    new "Ok, super!"

    # say L542 bel
    old "Come to my house in the afternoon."
    new "Komm nachmittags zu mir."

    # say L544 pla
    old "I thought I would go with you right after we finished classes."
    new "Ich dachte, ich gehe mit dir, sobald wir fertig sind mit den Kursen."

    # say L546 bel
    old "No, I will skip classes today. I need to go home and get everything ready for the stream. I just came to let you know."
    new "Nein, ich schwänze heute die Kurse. Ich muss nach Hause und alles für den Stream vorbereiten. Ich wollte dich nur informieren."

    # say L547 pla
    old "Alright, no problem."
    new "Okay, kein Problem."

    # say L549 bel
    old "So, see you later at my house."
    new "Dann bis später bei mir."

    # say L571 pla
    old "Ok, I think Belle must be waiting for me..."
    new "Ok, ich denke, Belle wartet auf mich..."

    # say L572 pla
    old "Phew, I don't know how I always get myself into these things..."
    new "Puh, ich hab echt keine Ahnung, wie ich mich da immer reingerate..."

    # say L593 ash
    old "Oh! Hello."
    new "Oh! Hallo."

    # say L595 pla
    old "Uh... H- hi, g- good afternoon."
    new "Uh... H- hallo, g- guten Nachmittag."

    # say L597 ash
    old "Good afternoon. Can I help you with something?"
    new "Guten Nachmittag. Kann ich dir irgendwie helfen?"

    # say L599 pla
    old "I- uh... yes, I'm [pla], I'm a friend of Belle."
    new "I- äh... ja, ich bin [pla], ein Freund von Belle."

    # say L600 pla
    old "I- I came to do some... Uh, s- schoolwork with her."
    new "Ich- Ich bin gekommen, um... Äh, s- Schulaufgaben mit ihr zu machen."

    # say L602 ash
    old "Oh! Nice meeting you [pla]! My name is Ashley, I'm Belle's mother."
    new "Oh! Schön, dich kennenzulernen [pla]! Ich bin Ashley, Belles Mutter."

    # say L603 pla
    old "H- Hi..."
    new "H- Hallo..."

    # say L606 pla
    old "Excuse me Mrs. Ashley..."
    new "Entschuldigung, Mrs. Ashley..."

    # say L608 ash
    old "Mrs. Ashley? Haha, oh dear no, just call me Ashley. I'm too young to have anyone call me Mrs."
    new "Mrs. Ashley? Haha, oh nein, nenn mich einfach Ashley. Ich bin zu jung, um Mrs. genannt zu werden."

    # say L610 pla
    old "O- ok, A- Ashley. Is Belle around? She told me to come at this time."
    new "O- ok, A- Ashley. Ist Belle da? Sie hat mir gesagt, ich soll zu dieser Zeit kommen."

    # say L612 ash
    old "She is dear, she's in her bedroom."
    new "Sie ist da, sie ist in ihrem Schlafzimmer."

    # say L613 ash
    old "I'll let her know you're here."
    new "Ich sag ihr Bescheid."

    # say L615 pla
    old "T- thanks."
    new "Danke."

    # say L625 bel
    old "[pla]! H- hi! I- I didn't notice you arrived! Sorry."
    new "[pla]! H- hallo! I- ich hab dich gar nicht kommen sehen! Tut mir leid."

    # say L627 bel
    old "Mom, why didn't you tell me a visit for me had arrived?"
    new "Mama, warum hast du mir nicht gesagt, dass ein Besuch für mich da ist?"

    # say L630 ash
    old "Well sweety, you didn't tell me you were expecting anyone."
    new "Na Liebes, du hast mir ja gar nicht gesagt, dass du jemanden erwartest."

    # say L633 ash
    old "But I was just about to come and tell you your friend had arrived."
    new "Aber ich wollte gerade kommen und dir sagen, dass dein Freund angekommen ist."

    # say L635 bel
    old "I- I see...."
    new "I- Ich sehe...."

    # say L636 bel
    old "Anyway mom, [pla] and I are going to be working in my room."
    new "Na ja, Mom, [pla] und ich werden in meinem Zimmer arbeiten."

    # say L639 bel
    old "So, it would be nice if you could avoid interrupting us."
    new "Dann wäre es schön, wenn du uns nicht stören würdest."

    # say L641 ash
    old "Well, I guess I'll do my best not to bother you, sweetheart."
    new "Na gut, ich werde mein Bestes tun, dich nicht zu stören, Schatz."

    # say L644 bel
    old "Come on [pla], let's go."
    new "Komm schon [pla], lass uns gehen."

    # say L658 pla
    old "Hey, what's up? I thought you said she wasn't going to be here today?"
    new "Hey, was ist los? Ich dachte, du hast gesagt, sie wäre heute nicht hier?"

    # say L659 bel
    old "Yeah I know, sorry"
    new "Ja, ich weiß, sorry"

    # say L661 bel
    old "She just suddenly came back home and said she was going to work from home today."
    new "Sie ist plötzlich nach Hause gekommen und hat gesagt, sie würde heute von zu Hause arbeiten."

    # say L662 bel
    old "I don't know why, I guess something happened at the office."
    new "Ich weiß auch nicht, wahrscheinlich ist was im Büro passiert."

    # say L663 pla
    old "Hmm ok, yeah, I understand."
    new "Hmm okay, ja, ich verstehe."

    # say L664 pla
    old "I suppose we're not streaming today then."
    new "Dann streamen wir heute wohl nicht, oder?"

    # say L666 bel
    old "Yep, we can't do the stream with my mother here."
    new "Klar, wir können nicht streamen, wenn meine Mutter hier ist."

    # say L668 bel
    old "She could come in at any time."
    new "Sie könnte jederzeit reinkommen."

    # say L670 bel
    old "She'll be bringing some snacks, or knocking on the door to see how we're doing, or something."
    new "Sie wird uns Snacks bringen oder an die Tür klopfen, um zu sehen, wie es uns geht, oder so was."

    # say L673 bel
    old "My mom's very controlling, and she'll want to know what we're doing here."
    new "Meine Mom ist sehr kontrollierend und wird wissen wollen, was wir hier machen."

    # say L675 bel
    old "So, it's better if we don't risk being caught in the middle of it."
    new "Dann ist es besser, wenn wir das Risiko nicht eingehen, mitten drin erwischt zu werden."

    # say L679 bel
    old "I'm sorry [pla]... that ruins our plans for today."
    new "Es tut mir leid [pla]... das ruiniert unsere Pläne für heute."

    # say L680 bel
    old "I'm sorry to have you come here for nothing."
    new "Es tut mir leid, dass du umsonst gekommen bist."

    # say L682 pla
    old "Oh, don't worry. We can do it on any other day. I'll head back home then."
    new "Oh, mach dir keine Sorgen. Wir können es an einem anderen Tag machen. Ich gehe dann nach Hause."

    # say L684 bel
    old "Well, maybe you should stay for a little while."
    new "Na, vielleicht solltest du noch ein bisschen bleiben."

    # say L685 bel
    old "After all, you just got here. My mom could get suspicious if you leave just after arriving."
    new "Schließlich bist du gerade erst angekommen. Meine Mom könnte misstrauisch werden, wenn du gleich wieder gehst."

    # say L687 pla
    old "Ok, so what are we going to do?"
    new "Okay, und was machen wir jetzt?"

    # say L689 bel
    old "I was thinking I could let you know a bit more about this whole camming thing, how it works and stuff."
    new "Ich dachte, ich könnte dir ein bisschen mehr über das ganze Camming-Ding erzählen, wie es funktioniert und so."

    # say L690 pla
    old "Oh, ok sure."
    new "Oh, okay klar."

    # say L692 bel
    old "So, the way the stream works is through a {i}'tips'{/i} system."
    new "Also, der Stream funktioniert über ein {i}'Tipps'{/i}-System."

    # say L694 bel
    old "While we're doing it, that's the most important thing to keep in mind."
    new "Während wir es machen, ist das das Wichtigste, woran du denken solltest."

    # say L696 bel
    old "And whatever I'm going to do, I do it live, instead of having it pre-recorded, like in porn."
    new "Und was ich machen werde, mache ich live, anstatt es vorzufilmen wie in Pornos."

    # say L697 bel
    old "Since everything is completely live, tips are very important."
    new "Da alles komplett live ist, sind Spenden sehr wichtig."

    # say L698 pla
    old "Why?"
    new "Warum?"

    # say L700 bel
    old "Well, because the livestream is a type of show."
    new "Na ja, weil der Livestream eine Art Show ist."

    # say L701 bel
    old "Which means that my fans have to be engage and entertained."
    new "Das bedeutet, dass meine Fans unterhalten und bei der Sache sein müssen."

    # say L703 bel
    old "And the only reliable way I can gauge if they really like it, is by seeing their tips."
    new "Und der einzige zuverlässige Weg, um zu erkennen, ob sie es wirklich mögen, ist, ihre Tips zu sehen."

    # say L704 bel
    old "So, the whole objective of each time I'm on camera is to get them to tip."
    new "Also, das ganze Ziel jedes Mal, wenn ich im Stream bin, ist es, sie dazu zu bringen, zu tippen."

    # say L705 pla
    old "Uhh... I see."
    new "Uhh... Ich verstehe."

    # say L706 bel
    old "So, whenever the stream starts, I have to set up some {i}'goals'{/i}."
    new "Also, sobald der Stream startet, muss ich mir ein paar {i}Ziele{/i} setzen."

    # say L708 bel
    old "Which is the number of tips I want my fans to give me before I do anything."
    new "Das ist die Anzahl der Tips, die ich von meinen Fans haben will, bevor ich was mache."

    # say L709 bel
    old "If the audience matches the goals by tipping, I do what I promised for that goal, and move into the next one."
    new "Wenn das Publikum die Ziele durch Spenden erreicht, mache ich, was ich für dieses Ziel versprochen habe, und gehe zum nächsten über."

    # say L711 pla
    old "I think I get it."
    new "Ich glaub, ich hab's kapiert."

    # say L712 pla
    old "So, whether we do something or not, depends on the audience?"
    new "Also, ob wir was machen oder nicht, hängt von der Audience ab?"

    # say L713 bel
    old "That's right, we decide what to do, but we only do it if the goal is met."
    new "Das stimmt, wir entscheiden, was wir tun, aber wir machen es nur, wenn das Ziel erreicht ist."

    # say L715 pla
    old "That sounds simple."
    new "Das klingt einfach."

    # say L717 bel
    old "Well, it's all about personality, and how much you connect with the audience, you know?"
    new "Na ja, es geht um die Persönlichkeit und wie gut man mit dem Publikum verbunden ist, verstehst du?"

    # say L718 bel
    old "So it's important to talk to them, try and pay attention to their comments, and the demands they make."
    new "Dann ist es wichtig, mit ihnen zu reden, auf ihre Kommentare zu achten und ihre Wünsche zu berücksichtigen."

    # say L720 pla
    old "That makes sense."
    new "Das ergibt Sinn."

    # say L722 bel
    old "And as I told you before, you don't need to talk or interact with them."
    new "Und wie ich dir schon gesagt habe, musst du nicht mit ihnen reden oder interagieren."

    # say L724 bel
    old "After all, my fans want to see me doing something with a... w- with a penis."
    new "Schließlich wollen meine Fans mich dabei sehen, wie ich etwas mit einem... w- mit einem Penis mache."

    # say L726 bel
    old "But they don't really want to get to know you."
    new "Aber sie wollen dich eigentlich gar nicht wirklich kennenlernen."

    # say L728 bel
    old "T- the most important is for you to... have a b- boner during the show."
    new "T- das Wichtigste ist, dass du... einen S- Steifen hast während der Show."

    # say L729 bel
    old "I- I'll take care of the rest."
    new "I- Ich kümmere mich um den Rest."

    # say L731 pla
    old "Well... I- I guess I can manage that."
    new "Na... Ich- Ich denke, ich kann das hinbekommen."

    # say L742 ash
    old "Hey guys! How are you doing?"
    new "Hey Leute! Wie geht's euch?"

    # say L744 bel
    old "Uhmm, we're doing fine mom."
    new "Uhmm, wir machen es gut, Mama."

    # say L745 bel
    old "But I would've appreciated it if you'd knocked on the door before entering."
    new "Aber ich hätte es geschätzt, wenn du vorher angeklopft hättest."

    # say L748 ash
    old "I'm sorry honey, but I just wanted to see if you needed anything."
    new "Es tut mir leid, Schatz, aber ich wollte nur sehen, ob du etwas brauchst."

    # say L750 ash
    old "Maybe you would like me to bring you some snacks?"
    new "Vielleicht möchtest du, dass ich dir etwas zu essen bringe?"

    # say L752 bel
    old "I think we're fine mom, thank you."
    new "Ich denke, wir kommen klar, danke Mom."

    # say L753 ash
    old "Ok sweety, I'll leave for now then."
    new "Ok Schatz, dann lass ich euch jetzt mal in Ruhe."

    # say L754 ash
    old "But if you two need anything, just let me know."
    new "Aber wenn ihr beiden was braucht, sagt Bescheid."

    # say L755 bel
    old "Yeah, right, thank you..."
    new "Ja, danke..."

    # say L763 bel
    old "Sorry, she just came in unannounced."
    new "Entschuldigung, sie ist einfach so reingekommen."

    # say L765 pla
    old "It's ok, we kinda knew she was going to do that."
    new "Ist okay, wir haben es ja schon geahnt, dass sie das machen würde."

    # say L766 bel
    old "Yeah... but that's why we can't do anything whenever she's here."
    new "Ja... aber deshalb können wir nichts tun, wenn sie hier ist."

    # say L767 pla
    old "Y- yeah, I- I get it..."
    new "Y- ja, ich- ich verstehe..."

    # say L769 bel
    old "Well, anyway, t- there hasn't been enough time since you came here."
    new "Na ja, auf jeden Fall, es war einfach noch nicht genug Zeit, seit du hier bist."

    # say L770 bel
    old "So, why don't I show you the webcam platform in the meantime?"
    new "Dann zeig ich dir mal die Webcam-Plattform, okay?"

    # say L771 pla
    old "Yeah... sure."
    new "Klar... okay."

    # say L780 bel
    old "Ok, this is my profile..."
    new "Ok, das ist mein Profil..."

    # say L792 bel
    old "Ok [pla], I think that should be enough time for my mom not to suspect anything."
    new "Ok [pla], ich denke, das sollte genug Zeit sein, damit meine Mom nichts ahnt."

    # say L793 bel
    old "I'll let you know when it's ok for you to come again."
    new "Ich geb dir Bescheid, wenn du wieder kommen kannst."

    # say L794 pla
    old "Yeah, sure, just tell me when and I'll come to help you."
    new "Klar, sag mir einfach Bescheid und ich komme, um dir zu helfen."

    # say L796 pla
    old "You're welcome Belle, I'm happy to help you."
    new "Gern geschehen Belle, ich freue mich, dir zu helfen."

    # say L797 bel
    old "I hope next time we won't have any problems streaming."
    new "Ich hoffe, beim nächsten Mal gibt es keine Probleme mehr beim Streamen."

    # say L799 bel
    old "The voting period is closing soon, and we won't be able to do anything if we have to postpone it too much."
    new "Die Abstimmungsphase schließt bald, und wenn wir es zu lange verschieben müssen, können wir nichts mehr tun."

    # say L801 pla
    old "I get it, but what happened today was just unexpected."
    new "Ich verstehe, aber was heute passiert ist, war einfach unerwartet."

    # say L802 pla
    old "I bet there won't be any problem going forward."
    new "Ich wette, es wird kein Problem mehr geben."

    # say L804 bel
    old "Yeah, you're probably right."
    new "Klar, du hast wahrscheinlich recht."

    # say L805 pla
    old "So, listen... I guess I should get going, right?"
    new "Also, hör mal... Ich denke, ich sollte jetzt gehen, oder?"

    # say L807 bel
    old "Sure, I'll see you later [pla], thanks again for coming."
    new "Klar, bis später [pla], danke nochmal, dass du gekommen bist."

    # say L808 pla
    old "You're welcome, see you later Belle."
    new "Gern geschehen, bis später Belle."

    # say L834 pla
    old "Uhm, I'm doing well, and you?"
    new "Ähm, ich bin gut drauf, und du?"

    # say L838 bel
    old "So listen, after you left, my mom said it was very nice to meet you."
    new "Dann hör mal, nachdem du gegangen bist, hat meine Mom gesagt, dass es sehr nett war, dich kennenzulernen."

    # say L840 pla
    old "S- she did?"
    new "S- sie hat?"

    # say L842 bel
    old "Yeah, she said that you seemed to be a good person."
    new "Ja, sie sagte, dass du ein guter Mensch zu sein scheinst."

    # say L844 pla
    old "I- I guess that's nice."
    new "I- Ich schätze, das ist nett."

    # say L846 bel
    old "It is, when she met Mike she went on an on about how rude he was."
    new "Das ist es, als sie Mike getroffen hat, hat sie sich ständig über seine Unhöflichkeit beschwert."

    # say L848 bel
    old "So, I'm glad she liked you."
    new "Dann bin ich froh, dass sie dich mag."

    # say L849 pla
    old "Uhh, w- well, that's great."
    new "Uhh, w-was gut."

    # say L851 bel
    old "Yeah, that may make things easier in the future."
    new "Ja, das könnte die Dinge in Zukunft erleichtern."

    # say L852 bel
    old "But leaving that aside, my mom told me she won't be home this afternoon."
    new "Aber das mal beiseite, meine Mom hat mir gesagt, dass sie heute Nachmittag nicht zu Hause sein wird."

    # say L854 bel
    old "So we can start streaming today!"
    new "Dann können wir heute mit dem Streamen anfangen!"

    # say L856 pla
    old "Ok... that sounds alright."
    new "Ok... das klingt gut."

    # say L858 bel
    old "Ok, let's go to my house after classes then."
    new "Ok, lass uns nach den Kursen zu mir gehen."

    # say L887 bel
    old "Ok, let's go to my house then."
    new "Ok, dann gehen wir zu mir nach Hause."

    # say L919 bel
    old "Alright, before we begin there's a couple of things we have to check."
    new "Okay, bevor wir anfangen, gibt es ein paar Dinge, die wir klären müssen."

    # say L920 pla
    old "Oh... Ok."
    new "Oh... Okay."

    # say L922 bel
    old "You remember what I told you about how it's important to talk to the audience, right?"
    new "Du erinnerst dich doch noch daran, dass ich dir gesagt habe, wie wichtig es ist, mit dem Publikum zu sprechen, oder?"

    # say L925 bel
    old "You also remember that I told you I'm the one who's going to be talking to them, right?"
    new "Du erinnerst dich auch noch daran, dass ich gesagt habe, dass ich diejenige bin, die mit ihnen sprechen wird, oder?"

    # say L926 pla
    old "Yeah, I do, no problem."
    new "Klar, hab ich, kein Problem."

    # say L928 bel
    old "Ok, I already announced that I was going to have a big surprise in today's stream."
    new "Okay, ich hab's schon angekündigt, dass ich heute im Stream eine große Überraschung habe."

    # say L929 bel
    old "So, I'll come in on stream and start the whole thing."
    new "Dann komme ich im Stream rein und fange das Ganze an."

    # say L931 bel
    old "Talking to the audience, and when it's the right time, I'll tell you to come in."
    new "Mit euch reden und wenn der richtige Moment kommt, sage ich euch, wann ihr reinkommen sollt."

    # say L933 pla
    old "Ok, I understand."
    new "Okay, ich verstehe."

    # say L935 bel
    old "The camera will be pointing in my direction."
    new "Die Kamera wird in meine Richtung zeigen."

    # say L936 bel
    old "You'll wait out of frame while I start the stream, and when I tell you, you come in."
    new "Du wartest außerhalb des Bildes, während ich den Stream starte, und wenn ich es sage, kommst du rein."

    # say L938 bel
    old "By the way, you won't be naked from the beginning... J- just wearing your shorts will be ok."
    new "Ach ja, du wirst am Anfang nicht nackt sein... N-nur deine Shorts reichen."

    # say L940 pla
    old "Ok, I think I get it."
    new "Ok, ich glaube, ich hab's kapiert."

    # say L942 bel
    old "You know, [pla], I'm very thankful to you for doing this."
    new "Du weißt, [pla], ich bin dir sehr dankbar für das, was du für mich tust."

    # say L944 bel
    old "I know this is new for you, and you're probably not very comfortable with it."
    new "Ich weiß, dass das neu für dich ist und du dich wahrscheinlich damit nicht sehr wohlfühlst."

    # say L945 bel
    old "So it means a lot to me that you're willing to help me this way."
    new "Dann bedeutet es mir sehr viel, dass du bereit bist, mir so zu helfen."

    # say L950 pla
    old "I will admit I was very surprised when you asked me to do this."
    new "Ich muss zugeben, ich war sehr überrascht, als du mich darum gebeten hast."

    # say L952 pla
    old "But you're a very good friend, and if this is important for you, then I'm happy to help you."
    new "Aber du bist eine sehr gute Freundin, und wenn das für dich wichtig ist, freue ich mich, dir zu helfen."

    # say L955 bel
    old "Now, we should go to my room."
    new "Jetzt sollten wir in mein Zimmer gehen."

    # say L976 bel
    old "Now, before we start, I have to change. Wait here a minute."
    new "Jetzt, bevor wir anfangen, muss ich mich umziehen. Warte hier einen Moment."

    # say L994 bel
    old "What are you making that face for?"
    new "Wofür machst du dieses Gesicht?"

    # say L997 pla
    old "Oh, n- nothing, you just..."
    new "Oh, n- nichts, du hast mich nur..."

    # say L1001 pla
    old "I- I wasn't expecting it."
    new "Ich- Ich hab damit nicht gerechnet."

    # say L1002 bel
    old "Well... thank you."
    new "Na ja... danke."

    # say L1003 bel
    old "So, I'll start with the stream, and let you know when to come into frame, ok?"
    new "Dann fange ich mal mit dem Stream an und sage dir Bescheid, wann du ins Bild kommen sollst, okay?"

    # say L1005 pla
    old "Right, sure."
    new "Okay, klar."

    # say L1020 bel
    old "Ok guys!"
    new "Ok Leute!"

    # say L1021 bel
    old "Hello! Are you all ready for a new session?"
    new "Hallo! Seid ihr bereit für eine neue Session?"

    # say L1022 bel
    old "I've missed you guys!"
    new "Ich hab euch vermisst!"

    # say L1023 bel
    old "Yes, I know I didn't stream the other day when I told you I would."
    new "Ja, ich weiß, dass ich vorgestern nicht gestreamt habe, obwohl ich es euch versprochen hatte."

    # say L1024 bel
    old "But something came up, and it became impossible to start the stream."
    new "Aber es ist was dazwischen gekommen, und ich konnte den Stream nicht starten."

    # say L1025 bel
    old "But I'm going to make it up to you guys!"
    new "Aber ich werde es euch wiedergutmachen!"

    # say L1026 bel
    old "As I promised you, I have a big surprise today!"
    new "Wie ich euch versprochen habe, habe ich heute eine große Überraschung für euch!"

    # say L1027 bel
    old "This is something a lot of you have been asking me about!"
    new "Das ist etwas, worum viele von euch mich schon lange gebeten haben!"

    # say L1028 bel
    old "So I decided to treat you!"
    new "Dann hab ich beschlossen, euch zu verwöhnen!"

    # say L1029 bel
    old "This is my first time doing something like this on camera. So I'm a little nervous."
    new "Das ist mein erstes Mal, so etwas vor der Kamera zu machen. Also bin ich ein bisschen nervös."

    # say L1030 bel
    old "But I bet that if you show me your support by tipping, I'll feel a lot better."
    new "Aber ich wette, wenn du mir durch ein Trinkgeld zeigst, dass du mich unterstützt, fühle ich mich viel besser."

    # say L1031 bel
    old "Now, do you want to see the surprise I have in store for you?"
    new "Jetzt, willst du sehen, was ich für dich vorbereitet habe?"

    # say L1033 bel
    old "This person is a very good friend of mine. And he's very excited to be joining me here in the stream today!"
    new "Dieser Typ ist ein sehr guter Freund von mir. Und er freut sich total, heute im Stream dabei zu sein!"

    # say L1034 bel
    old "Say hi to him!"
    new "Sag ihm Hallo!"

    # say L1039 bel
    old "Everyone, my friend is here because I promised you that you would see me having some fun with a real dick!"
    new "Alle, mein Freund ist hier, weil ich euch versprochen habe, dass ihr mich mit einem echten Schwanz Spaß haben sehen werdet!"

    # say L1040 bel
    old "And he came to help me with it."
    new "Und er ist hier, um mir dabei zu helfen."

    # say L1041 bel
    old "Why don't we see what he's hiding under these shorts then?"
    new "Warum sehen wir nicht, was er unter diesen Shorts versteckt?"

    # say L1049 bel
    old "Oh my god! Look at how big it is!"
    new "Oh mein Gott! Schau dir das mal an, wie groß es ist!"

    # say L1050 bel
    old "I bet you want to see me play with this big dick, right?"
    new "Ich wette, du willst sehen, wie ich mit diesem großen Schwanz spiele, oder?"

    # say L1051 bel
    old "You want me to care for it, and play with it, don't you?"
    new "Du willst, dass ich mich darum kümmere und damit spiele, stimmt's?"

    # say L1052 bel
    old "Let's not wait anymore for it then!"
    new "Dann lass uns nicht länger warten!"

    # say L1059 bel
    old "Oh! You have been waiting to see me play with your dick, haven't you?"
    new "Oh! Du hast schon die ganze Zeit darauf gewartet, mich mit deinem Schwanz spielen zu sehen, stimmt's?"

    # say L1060 bel
    old "I bet you love the way I stroke your big, thick, dick!"
    new "Ich wette, dir gefällt, wie ich deinen großen, dicken Schwanz streichle!"

    # say L1072 bel
    old "I knew you were going to love what I had in store for you!"
    new "Ich wusste, dass dir gefallen wird, was ich für dich vorbereitet habe!"

    # say L1073 bel
    old "Thanks a lot for accomplishing the goals!"
    new "Danke, dass ihr die Ziele erreicht habt!"

    # say L1074 bel
    old "You guys have made me very happy!"
    new "Ihr habt mich wirklich glücklich gemacht!"

    # say L1075 bel
    old "Now, sadly is time for me to disconnect, but be sure I'll come back soon."
    new "Jetzt, leider ist es Zeit für mich abzuschalten, aber seid sicher, ich werde bald wieder da sein."

    # say L1076 bel
    old "And, of course, my friend will be here, accompanying us once again."
    new "Und natürlich wird mein Freund wieder bei uns sein."

    # say L1077 bel
    old "Don't forget to subscribe to the stream!"
    new "Vergiss nicht, dich dem Stream zu abonnieren!"

    # say L1078 bel
    old "So you will get a notification the next time I'm online guys!"
    new "Dann kriegt ihr eine Benachrichtigung, wenn ich das nächste Mal online bin, Leute!"

    # say L1079 bel
    old "And of course, don't forget to check all my socials!"
    new "Und natürlich, vergesst nicht, meine Socials zu checken!"

    # say L1080 bel
    old "Thanks a lot guys!"
    new "Danke euch allen!"

    # say L1081 bel
    old "See you soon..."
    new "Bis bald..."

    # say L1091 bel
    old "It's amazing how many tips we got!"
    new "Es ist unglaublich, wie viele Tipps wir bekommen haben!"

    # say L1092 bel
    old "I already thought that we were going to do well because my fans had never seen me doing something like this."
    new "Ich dachte schon, dass wir gut wegkommen würden, weil meine Fans mich noch nie so was machen gesehen haben."

    # say L1094 bel
    old "But this is far more than I expected!"
    new "Aber das ist viel mehr, als ich erwartet habe!"

    # say L1095 bel
    old "They really came through with the tipping!"
    new "Sie haben wirklich gut getippt!"

    # say L1096 bel
    old "We reached the goal in no time!"
    new "Wir haben das Ziel gleich erreicht!"

    # say L1098 pla
    old "I'm very happy that it all came out better than you expected Belle."
    new "Ich bin sehr froh, dass alles besser ausgegangen ist, als du gedacht hast, Belle."

    # say L1100 pla
    old "That's very good."
    new "Das ist sehr gut."

    # say L1101 pla
    old "Do you think that with this you'll surpass Lana in the voting?"
    new "Glaubst du, dass du damit Lana in der Abstimmung überholst?"

    # say L1102 bel
    old "It's hard to tell, I think I will."
    new "Schwer zu sagen, ich denke schon."

    # say L1103 bel
    old "But only temporarily, with this type of thing you never know for certain who's going to win until the end."
    new "Aber nur vorübergehend, bei so was weiß man nie genau, wer am Ende gewinnt."

    # say L1105 pla
    old "Does that mean you're going to need my help on another occasion?"
    new "Das bedeutet, dass ich dich noch mal brauchen werde, oder?"

    # say L1107 bel
    old "Oh, don't doubt it! This is only the first time you're appearing on camera with me."
    new "Oh, daran solltest du nicht zweifeln! Das ist nur das erste Mal, dass du vor der Kamera mit mir auftauchst."

    # say L1109 bel
    old "And I'm very thankful for that [pla]."
    new "Und ich bin sehr dankbar dafür [pla]."

    # say L1111 pla
    old "Well, I'm happy to help."
    new "Na klar, ich freue mich, zu helfen."

    # say L1113 bel
    old "Thanks [pla]."
    new "Danke [pla]."

    # say L1125 bel
    old "{i}I don't know!{/i}"
    new "{i}Ich weiß es nicht!{/i}"

    # say L1131 pla
    old "{i}You better answer her, or else she's going to come here to see if everything is alright.{i}"
    new "{i}Du solltest besser antworten, sonst kommt sie hierher, um zu sehen, ob alles in Ordnung ist.{i}"

    # say L1134 bel
    old "I'm here mom! I... I was just doing some schoolwork!"
    new "Ich bin hier, Mama! Ich... ich habe nur meine Hausaufgaben gemacht!"

    # say L1135 ash
    old "I see honey, ok!"
    new "Ich sehe, Schatz, okay!"

    # say L1137 bel
    old "I think we better get dressed up and get out of here before she comes to check on me and sees us like this."
    new "Ich denke, wir sollten uns besser anziehen und hier verschwinden, bevor sie nach mir sieht und uns so findet."

    # say L1138 pla
    old "Yeah, yeah, you're right."
    new "Ja, ja, du hast recht."

    # say L1151 ash
    old "Oh [pla], hi, I didn't know you were here."
    new "Oh [pla], hallo, ich wusste gar nicht, dass du hier bist."

    # say L1152 pla
    old "H- hi, uh... A- Ashley."
    new "H- hallo, äh... A- Ashley."

    # say L1154 ash
    old "It's good seeing you again dear."
    new "Schön, dich wiederzusehen, Liebling."

    # say L1155 ash
    old "Are you guys working on that school work you told me about?"
    new "Arbeitet ihr an der Schularbeit, von der du mir erzählt hast?"

    # say L1157 pla
    old "Uh... y- yeah, t- that's right."
    new "Uh... j- ja, s- stimmt."

    # say L1160 bel
    old "What are you doing home mom? I thought you had that important meeting you had talked about."
    new "Was machst du zu Hause, Mom? Ich dachte, du hättest dieses wichtige Meeting, von dem du gesprochen hast."

    # say L1163 ash
    old "Oh honey, you won't believe what just happened!"
    new "Oh Schatz, du wirst es nicht glauben, was gerade passiert ist!"

    # say L1166 ash
    old "Today was supposed to be my first planning meeting with my team."
    new "Heute sollte mein erstes Planungstreffen mit meinem Team sein."

    # say L1167 ash
    old "You know, so we could make a marketing plan to show our clients."
    new "Du weißt schon, damit wir einen Marketingplan erstellen können, den wir unseren Kunden präsentieren."

    # say L1170 ash
    old "But the web developer I had hired suddenly backed out of the deal!"
    new "Aber der Webentwickler, den ich eingestellt hatte, zog plötzlich sein Angebot zurück!"

    # say L1173 ash
    old "Apparently he got a better job offer, and decided to take it."
    new "Scheinbar hat er ein besseres Jobangebot bekommen und sich dafür entschieden."

    # say L1174 ash
    old "But he didn't even give me a heads up or anything, he just bailed without notice!"
    new "Aber er hat mir nicht mal Bescheid gesagt, er ist einfach ohne Vorwarnung abgehauen!"

    # say L1176 ash
    old "What am I going to do now?"
    new "Was soll ich jetzt machen?"

    # say L1177 bel
    old "Can't you just replace him, mom? I'm sure there must be someone out there that you can hire."
    new "Kannst du ihn nicht einfach ersetzen, Mom? Ich bin sicher, da gibt es jemanden, den du einstellen kannst."

    # say L1179 ash
    old "If it was that easy I wouldn't have a problem."
    new "Wenn es so einfach wäre, hätte ich kein Problem."

    # say L1180 ash
    old "Getting that web developer wasn't easy."
    new "Den Webentwickler zu finden war nicht einfach."

    # say L1182 ash
    old "You know my firm is only setting up here in town, so we can't actually offer anybody long-term contracts."
    new "Du weißt ja, unsere Firma ist erst dabei, sich hier in der Stadt einzurichten, deshalb können wir niemandem langfristige Verträge anbieten."

    # say L1184 ash
    old "Finding somebody qualified that's willing to freelance for a while is very hard."
    new "Jemanden zu finden, der qualifiziert ist und als Freelancer arbeiten will, ist echt schwierig."

    # say L1185 ash
    old "But we already took the commission, and my bosses are expecting me to show them a marketing plan soon!"
    new "Aber wir haben die Auftrag schon angenommen, und meine Chefs erwarten von mir, dass ich ihnen bald einen Marketingplan zeige!"

    # say L1187 ash
    old "Tell me dear, do you know of anybody that could help me?"
    new "Sag mal, kennst du jemanden, der mir helfen könnte?"

    # say L1188 bel
    old "Me? Why would I happen to know someone who is a web developer?"
    new "Ich? Warum sollte ich zufällig jemanden kennen, der Webentwickler ist?"

    # say L1190 ash
    old "I don't know, maybe someone from your school?"
    new "Ich weiß nicht, vielleicht jemand von deiner Schule?"

    # say L1192 bel
    old "Well, I'm sorry to disappoint you, mom, but I don't know any web developers..."
    new "Na, tut mir leid, dich zu enttäuschen, Mom, aber ich kenne keinen Webdeveloper..."

    # say L1194 ash
    old "I see... that's disappointing."
    new "Ich sehe... das ist enttäuschend."

    # say L1207 bel
    old "MOM! What are you talking about? Don't rope him into this!"
    new "MOM! Wovon redest du? Lass ihn da nicht mit reinziehen!"

    # say L1209 ash
    old "Well honey, I'm sorry if you don't like me asking your friend for help."
    new "Na Liebling, es tut mir leid, wenn dir nicht gefällt, dass ich deinen Freund um Hilfe bitte."

    # say L1212 ash
    old "But I'm in a very thought spot right now, I need whatever help I can get."
    new "Aber ich stecke echt in der Patsche, ich brauche jede Hilfe, die ich kriegen kann."

    # say L1214 ash
    old "So, do you know of anybody that could help me [pla]?"
    new "So, kennst du jemanden, der mir helfen könnte [pla]?"

    # say L1217 pla
    old "Well... Actually, I- I think that... Maybe I could help"
    new "Na ja... Eigentlich, ich- ich denke, dass... Vielleicht könnte ich helfen."

    # say L1219 ash
    old "Really? Are you a web developer?"
    new "Wirklich? Bist du Webentwickler?"

    # say L1222 pla
    old "Well, I'm not a professional, but I have a little bit of experience."
    new "Na ja, ich bin kein Profi, aber ich habe schon ein bisschen Erfahrung."

    # say L1224 pla
    old "My [sisrel] has an online clothing store."
    new "Meine [sisrel] hat einen Online-Boutique."

    # say L1226 pla
    old "When she was getting started I was the one who set up the e-commerce for her."
    new "Als sie angefangen hat, habe ich den E-Commerce für sie eingerichtet."

    # say L1227 pla
    old "And... I have been doing the maintenance ever since."
    new "Und... ich mache die Wartung seitdem."

    # say L1230 ash
    old "And you think you could help me with this?"
    new "Und du denkst, du könntest mir dabei helfen?"

    # say L1232 pla
    old "W- well, I think so, I would have to see first what it is that you need me to do, though."
    new "W-was, ich denke schon, aber ich müsste erst sehen, was genau du von mir brauchst."

    # say L1234 ash
    old "That's wonderful [pla]! Oh my God! I would love it if you could help me."
    new "Das ist wunderbar [pla]! Oh mein Gott! Ich würde mich freuen, wenn du mir helfen könntest."

    # say L1236 ash
    old "Maybe asking you to do the whole website right now would be too much."
    new "Vielleicht wäre es jetzt zu viel verlangt, wenn ich dich bitten würde, die ganze Website zu machen."

    # say L1238 ash
    old "But I think you could help me with the planning of it, while I find a web developer to hire."
    new "Aber ich denke, du könntest mir bei der Planung helfen, während ich nach einem Webentwickler suche, den ich einstellen kann."

    # say L1240 ash
    old "It would only be a few times that I would need your help with the planning."
    new "Es wäre nur ein paar Mal, dass ich deine Hilfe bei der Planung brauchen würde."

    # say L1242 pla
    old "Hmm... Sure, I think I could do that."
    new "Hmm... Klar, ich denke, das könnte ich machen."

    # say L1244 ash
    old "That's great!"
    new "Das ist toll!"

    # say L1245 ash
    old "And don't worry, I'll make sure you get properly compensated for it. I can add the cost to the budget."
    new "Und mach dir keine Sorgen, ich sorge dafür, dass du angemessen entschädigt wirst. Ich kann die Kosten in den Haushaltsplan eintragen."

    # say L1246 ash
    old "So, there shouldn't be any problem with your pay."
    new "Dann sollte es kein Problem mit deinem Gehalt geben."

    # say L1248 pla
    old "I- I see... So, s- should I come to your office later?"
    new "I- Ich sehe... S- Soll ich dann später in dein Büro kommen?"

    # say L1250 ash
    old "Actually, I'm not sure if that would be a good idea because I wouldn't want the firm's directors to know about this."
    new "Eigentlich bin ich mir nicht sicher, ob das eine gute Idee wäre, weil ich nicht will, dass die Firmenchefs davon erfahren."

    # say L1252 ash
    old "I think it's better if we just work here at home."
    new "Ich denke, es ist besser, wenn wir hier zu Hause arbeiten."

    # say L1257 ash
    old "You're really helping me with this [pla], a lot! You have no idea about how useful you're being!"
    new "Du hilfst mir echt dabei, [pla], total! Du hast keine Ahnung, wie nützlich du bist!"

    # say L1258 ash
    old "Now, I left some documents that you'll need in the office, I'll go and grab them."
    new "Jetzt, ich hab ein paar Dokumente im Büro gelassen, die du brauchst, ich geh sie holen."

    # say L1259 ash
    old "But don't worry, we won't be starting right away, you can come back on another occasion and I'll let you know what the job is about."
    new "Aber mach dir keine Sorgen, wir fangen nicht gleich an, du kannst auch später wiederkommen und ich sag dir dann, um was für einen Job es geht."

    # say L1261 pla
    old "Alright, I'll be sure to do it."
    new "Okay, ich werd's machen."

    # say L1262 ash
    old "Great, see you later then [pla]."
    new "Super, dann bis später [pla]."

    # say L1270 bel
    old "I can't believe you're actually going to help her with that."
    new "Ich kann nicht glauben, dass du ihr wirklich dabei helfen willst."

    # say L1272 bel
    old "Don't you think that's going to get in the way of us doing the stream?"
    new "Findest du nicht, dass das unsere Stream-Pläne durchkreuzt?"

    # say L1274 pla
    old "In fact, I think it's convenient for us because since she needs me to work here, we'll know more accurately when she will be here and when she won't."
    new "Eigentlich denke ich, dass es uns sogar gut passt, weil wir dann genauer wissen, wann sie hier ist und wann nicht."

    # say L1277 bel
    old "But still, I'm sorry my mom is putting you up to this."
    new "Aber trotzdem, es tut mir leid, dass meine Mutter dich dazu bringt."

    # say L1279 pla
    old "Don't worry about it, I'm happy to help."
    new "Mach dir keine Sorgen, ich freue mich, zu helfen."

    # say L1280 bel
    old "Yeah, I know."
    new "Ja, ich weiß."

    # say L1281 bel
    old "You're being very nice helping both my mom and me like this."
    new "Du bist echt nett, uns beiden so zu helfen."

    # say L1282 bel
    old "That's very good of you [pla]."
    new "Das ist sehr nett von dir [pla]."

    # say L1284 pla
    old "Thanks for saying that."
    new "Danke, dass du das gesagt hast."

    # say L1291 pla
    old "Hey, so I think I should get going, after all, we just finished streaming, I bet you want to take a shower or something."
    new "Hey, dann denke ich, ich sollte jetzt gehen, wir haben gerade mit dem Stream aufgehört, du willst bestimmt duschen oder so."

    # say L1293 bel
    old "Uhh, yeah, sure, I'll let you know when we have to stream the next time, thanks again [pla]."
    new "Uhh, ja, klar, ich lass dich wissen, wann wir das nächste Mal streamen, danke nochmal [pla]."

    # say L1295 pla
    old "Sure, see you later, bye."
    new "Klar, bis später, tschüss."

    # say L1325 bel
    old "Hi [pla]! I have great news!"
    new "Hi [pla]! Ich hab tolle Neuigkeiten!"

    # say L1328 bel
    old "The poll results from yesterday came out this morning!"
    new "Die Umfrageergebnisse von gestern sind heute Morgen reingekommen!"

    # say L1332 bel
    old "I'm number one now!"
    new "Ich bin jetzt Nummer eins!"

    # say L1334 pla
    old "That's great belle!"
    new "Das ist toll, Belle!"

    # say L1335 pla
    old "I'm very happy for you."
    new "Ich freue mich sehr für dich."

    # say L1337 bel
    old "Thanks, this is wonderful!"
    new "Danke, das ist wunderbar!"

    # say L1339 bel
    old "She's been appearing with a guy on stream for longer, so I didn't know if I would be able to catch her with just one stream."
    new "Sie ist schon länger mit einem Typen im Stream aufgetreten, also wusste ich nicht, ob ich sie mit nur einem Stream erwischen könnte."

    # say L1341 bel
    old "But my fans really liked it!"
    new "Aber meine Fans haben es wirklich genossen!"

    # say L1343 bel
    old "If we keep going like this, she won't have any chance of catching me!"
    new "Wenn wir so weitermachen, hat sie keine Chance, mich einzuholen!"

    # say L1345 pla
    old "That sounds great."
    new "Das klingt toll."

    # say L1348 pla
    old "So, when it's the next stream?"
    new "Also, wann ist der nächste Stream?"

    # say L1349 bel
    old "Well, that's where we have a little bit of a problem."
    new "Na ja, da haben wir ein kleines Problem."

    # say L1350 pla
    old "Why? What happened?"
    new "Warum? Was ist passiert?"

    # say L1352 bel
    old "You see, I had already thought about what we're going to do next."
    new "Du siehst, ich habe schon darüber nachgedacht, was wir als Nächstes machen."

    # say L1353 bel
    old "My fans have been asking for me to do cosplay for a while, so I thought now it would be a good occasion."
    new "Meine Fans haben schon lange darum gebeten, dass ich Cosplay mache, also dachte ich, jetzt wäre eine gute Gelegenheit."

    # say L1356 bel
    old "Yes, we can't just repeat the same as last time."
    new "Ja, wir können nicht einfach das Gleiche wie letztes Mal machen."

    # say L1357 bel
    old "If we just do the same thing over and over the audience will get bored."
    new "Wenn wir immer das Gleiche machen, langweilen sich die Zuschauer."

    # say L1358 bel
    old "We have to give them some variety."
    new "Wir müssen ihnen ein bisschen Abwechslung bieten."

    # say L1362 bel
    old "But you see, I don't know when the next stream will be."
    new "Aber siehst du, ich weiß nicht, wann der nächste Stream sein wird."

    # say L1363 bel
    old "I already know what character I want to do."
    new "Ich weiß schon, welches Charakter ich machen will."

    # say L1364 bel
    old "It's somewhat of an interesting character, and my fans seem to have a fixation for that type of girl."
    new "Es ist eine ziemlich interessante Figur, und meine Fans scheinen eine Schwäche für solche Mädchen zu haben."

    # say L1365 bel
    old "So I wanted to please them, I even ordered for the cosplay to be delivered by express shipping."
    new "Dann wollte ich sie ja verwöhnen, habe sogar den Schnellversand für den Kostüm bestellt."

    # say L1367 bel
    old "But it turns out there was a mixup when I placed my order, when I bought it they had alredy sold it!"
    new "Aber es stellte sich heraus, dass es beim Bestellen einen Fehler gab, als ich es kaufte, hatten sie es schon verkauft!"

    # say L1368 bel
    old "And they don't seem to have any more!"
    new "Und sie scheinen auch keine mehr zu haben!"

    # say L1370 bel
    old "I have been looking for that same cosplay in other websites, but I can't find it!"
    new "Ich habe auf anderen Websites nach demselben Cosplay gesucht, aber ich kann es nirgendwo finden!"

    # say L1371 bel
    old "And I already promised the audience that's the character I was going to do."
    new "Und ich habe dem Publikum schon versprochen, dass das die Figur ist, die ich machen werde."

    # say L1372 bel
    old "I guess we'll have to postpone it for another time."
    new "Dann müssen wir es wohl verschieben."

    # say L1374 bel
    old "Besides, you also have to go help my mom with that website thing..."
    new "Außerdem musst du auch meiner Mom bei der Website helfen..."

    # say L1376 bel
    old "Ugh, this annoys me so much, Lana's going to overtake me again!"
    new "Mann, das nervt mich total, Lana wird mich wieder überholen!"

    # say L1378 pla
    old "Hmm, I might be able to do something about that. My [sisRel] has her own clothing store."
    new "Hmm, ich könnte da was machen. Meine [sisRel] hat ihren eigenen Bekleidungsladen."

    # say L1380 pla
    old "So, I think maybe she can find that cosplay for you in time for the next stream."
    new "Dann denke ich, sie kann dir vielleicht das Cosplay rechtzeitig für den nächsten Stream besorgen."

    # say L1382 bel
    old "Really? Oh [pla] that would be great!"
    new "Wirklich? Oh [pla] das wäre toll!"

    # say L1384 pla
    old "Well, it's not certain, I'll have to ask, but I think it's possible."
    new "Na ja, es ist nicht sicher, ich muss fragen, aber ich denke, es ist möglich."

    # say L1385 bel
    old "If you could, that would be wonderful."
    new "Wenn du könntest, wäre das wunderbar."

    # say L1386 pla
    old "I'll ask with my [sisRel] this afternoon, after classes."
    new "Ich frage [sisRel] heute Nachmittag, nach den Kursen."

    # say L1387 pla
    old "And I'll let you know."
    new "Und ich geb dir Bescheid."

    # say L1388 bel
    old "Sure, thanks a lot [pla]."
    new "Klar, danke schön [pla]."

    # say L1391 pla
    old "For now let's go to class."
    new "Lass uns jetzt in die Klasse gehen."

    # say L1412 pla
    old "Hi [sis], how are you?"
    new "Hi [sis], wie geht's dir?"

    # say L1413 sis
    old "I'm doing pretty well, working on a new collection."
    new "Mir geht's ziemlich gut, ich arbeite an einer neuen Kollektion."

    # say L1414 pla
    old "Uhh, so are you busy?"
    new "Uhh, bist du gerade beschäftigt?"

    # say L1415 sis
    old "Uhh a little bit, Why? What do you need?"
    new "Uhh ein bisschen, warum? Was brauchst du?"

    # say L1417 pla
    old "Well, I was wondering if you could help me with getting a cosplay."
    new "Na ja, ich dachte, du könntest mir helfen, eine Cosplay zu organisieren."

    # say L1418 sis
    old "A cosplay? I didn't know you were into that kind of stuff..."
    new "Eine Cosplay? Ich wusste gar nicht, dass du so was magst..."

    # say L1421 sis
    old "Anyway, what kind of cosplay is it? Like a superhero or something?"
    new "Na, welches Kostüm ist es denn? Ein Superheld oder so was?"

    # say L1423 pla
    old "Uhh, it's actually a female cosplay, it's a famous character from a videogame."
    new "Uhh, es ist eigentlich eine Frauen-Cosplay, ein berühmter Charakter aus einem Videospiel."

    # say L1424 sis
    old "A female cosplay? Why do you need that?"
    new "Eine Frauen-Cosplay? Warum brauchst du das?"

    # say L1426 sis
    old "Don't tell me you're thinking of becoming a drag queen."
    new "Sag bloß, du willst Dragqueen werden."

    # say L1428 pla
    old "W- what? Of course not!"
    new "W-was? Natürlich nicht!"

    # say L1430 pla
    old "It's for a friend of mine that needs it."
    new "Das mache ich für einen Freund, der es braucht."

    # say L1432 sis
    old "Oh! Is that so? And why are you getting it for her? Are you two doing something naughty?"
    new "Oh! Ist das so? Und warum holst du es für sie? Macht ihr zwei was Schmutziges?"

    # say L1434 pla
    old "N- no, we're not, I'm just doing her a favor because she needs it. That's all."
    new "N-nein, wir tun das nicht, ich mache ihr nur einen Gefallen, weil sie es braucht. Das ist alles."

    # say L1436 sis
    old "Haha! Relax, I'm just messing with you."
    new "Haha! Mach dich nicht so auf, ich hab dich nur auf den Arm genommen."

    # say L1438 sis
    old "I don't mind what you're doing with your friend."
    new "Mir ist es egal, was du mit deiner Freundin machst."

    # say L1439 sis
    old "As long as you keep helping me with my business, you can do whatever you want."
    new "Solange du mir weiterhilfst bei meinem Geschäft, kannst du machen, was du willst."

    # say L1441 sis
    old "I'll get you the cosplay, it should be easy to get it here soon."
    new "Ich hol dir das Cosplay, sollte hier bald leicht zu kriegen sein."

    # say L1442 pla
    old "Thanks a lot [sis]!"
    new "Danke schön [sis]!"

    # say L1444 sis
    old "I'm happy to help."
    new "Ich freue mich, dir zu helfen."

    # say L1445 sis
    old "I'll let you know when it's ready."
    new "Ich sag dir Bescheid, wenn es fertig ist."

    # say L1469 ash
    old "Hello [pla]! How are you dear?"
    new "Hallo [pla]! Wie geht es dir Liebling?"

    # say L1472 ash
    old "Just Ashley dear, remember what I told you, no need for the Mrs."
    new "Ashley, erinnerst du dich, was ich dir gesagt habe? Kein Bedarf für das Mrs."

    # say L1473 pla
    old "Uhh... Right."
    new "Uhh... Klar."

    # say L1476 ash
    old "That's better."
    new "Das ist besser."

    # say L1477 ash
    old "How have you been honey?"
    new "Wie geht es dir, Schatz?"

    # say L1479 ash
    old "Is school going well?"
    new "Geht die Schule gut?"

    # say L1481 pla
    old "Uhh? Y- yeah. I- I have been studying a lot..."
    new "Uhh? Y- ja. Ich hab' viel gelernt..."

    # say L1482 ash
    old "That's great dear."
    new "Das ist toll, Schatz."

    # say L1484 pla
    old "Uh... Listen, A- Ashley, about the w- website."
    new "Uh... Hören Sie, Ashley, was die W- Website angeht."

    # say L1486 ash
    old "Right! We should focus on that."
    new "Stimmt! Da sollten wir uns drauf konzentrieren."

    # say L1488 pla
    old "Sure ma'am. But I'm not entirely sure what it is that I will be doing."
    new "Klar, Ma'am. Aber ich bin mir nicht ganz sicher, was ich da genau machen soll."

    # say L1490 ash
    old "Well, before that, I would like to see the e-commerce site you told me you made for your [sisrel]."
    new "Na klar, bevor wir das machen, würde ich gerne den E-Commerce-Shop sehen, von dem du erzählt hast, den du für deine [sisrel] erstellt hast."

    # say L1491 ash
    old "To see what type of thing you've done before. Would you like to use my computer?"
    new "Um zu sehen, was für eine Art Ding du schon gemacht hast. Möchtest du meinen Computer benutzen?"

    # say L1493 pla
    old "Uh... Sure, no problem."
    new "Klar, kein Problem."

    # say L1503 pla
    old "So, this is the site where you can see the apparel that my [sisrel] sells."
    new "Also, das ist die Seite, wo du die Kleidung sehen kannst, die meine [sisrel] verkauft."

    # say L1504 pla
    old "And if you click here you can place an order."
    new "Und wenn du hier klickst, kannst du eine Bestellung aufgeben."

    # say L1505 pla
    old "Then, it will take you to the payment portal. And there you can finalize the purchase."
    new "Dann wird dich das zu einem Zahlungsportal weiterleiten. Und dort kannst du den Kauf abschließen."

    # say L1507 ash
    old "You know [pla]? This is very good."
    new "Du weißt schon [pla]? Das ist sehr gut."

    # say L1508 ash
    old "This is very high quality, even better than the work some of the developers I've worked with before."
    new "Das ist sehr hochwertig, sogar besser als die Arbeit einiger Entwickler, mit denen ich früher zusammengearbeitet habe."

    # say L1509 ash
    old "Actually, this is more than what I need you to do."
    new "Eigentlich, das ist mehr, als ich von dir brauche."

    # say L1512 ash
    old "After seeing this, I'm thinking that you could just take the full job of developing the website for the client."
    new "Nachdem ich das gesehen habe, denke ich, du könntest den ganzen Job übernehmen und die Website für den Kunden entwickeln."

    # say L1516 ash
    old "Come on, why are you surprised? You did a very good job with this website."
    new "Komm schon, warum bist du überrascht? Du hast eine tolle Arbeit bei dieser Website geleistet."

    # say L1518 ash
    old "And as I told you, this is even more than what I need to be done for the marketing campaign."
    new "Und wie ich dir schon gesagt habe, das ist sogar mehr, als ich für die Marketingkampagne brauche."

    # say L1519 ash
    old "You could just do the job by yourself."
    new "Du könntest den Job auch alleine machen."

    # say L1521 ash
    old "And It would really help me, because I wouldn't have to look for someone to finish the project."
    new "Und es würde mir echt helfen, weil ich dann nicht mehr nach jemandem suchen müsste, der das Projekt zu Ende bringt."

    # say L1522 pla
    old "I mean, that's a very nice offer, uh... Ashley, b- but I'm not sure if I have the experience to do it."
    new "Ich meine, das ist ein sehr nettes Angebot, äh... Ashley, aber ich bin mir nicht sicher, ob ich die Erfahrung habe, es zu machen."

    # say L1523 pla
    old "It would be a lot of responsability."
    new "Das wäre eine Menge Verantwortung."

    # say L1525 ash
    old "Don't worry about it, dear. I'll accompany you every time you work on it, so I'll tell you exactly what I need from you."
    new "Mach dir keine Sorgen, Liebling. Ich begleite dich jedes Mal, wenn du daran arbeitest, und sage dir genau, was ich von dir brauche."

    # say L1529 pla
    old "Alright, if you think it's ok for me to do it, I guess I can take the job."
    new "Okay, wenn du meinst, dass ich das kann, dann nehme ich die Stelle an."

    # say L1531 ash
    old "Great! That's just what I wanted to hear."
    new "Super! Das ist genau das, was ich hören wollte."

    # say L1533 pla
    old "Ok, but what exactly is the type of website that I'm going to be working on? Is it an e-commerce?"
    new "Okay, aber um was für eine Art von Website geht es genau? Ist es ein Online-Shop?"

    # say L1534 ash
    old "Not really, what I need you to make is one where we can show a lot of information about a business."
    new "Nein, was ich brauche, ist eine, bei der wir viel über ein Unternehmen erzählen können."

    # say L1535 ash
    old "The business in question is an organic coffee shop that's gotten very popular here in the city."
    new "Das Geschäft, das ich meine, ist ein Bio-Café, das hier in der Stadt sehr beliebt geworden ist."

    # say L1536 ash
    old "And they're looking to expand their business by franchising outside of town."
    new "Und sie wollen ihr Geschäft durch Franchising außerhalb der Stadt ausbauen."

    # say L1537 pla
    old "I see. So they hired you to do their marketing campaign?"
    new "Ich verstehe. Also haben sie dich engagiert, um ihre Marketingkampagne zu machen?"

    # say L1539 ash
    old "Not me, my marketing firm. I'm just leading my team."
    new "Nicht ich, meine Marketingfirma. Ich leite nur mein Team."

    # say L1541 ash
    old "But, I still have the responsibility for the entire marketing plan."
    new "Aber ich habe trotzdem die Verantwortung für den gesamten Marketingplan."

    # say L1543 ash
    old "Because the clients already paid for the service, and I already received the budget."
    new "Weil die Kunden schon für den Service bezahlt haben und ich das Budget schon bekommen habe."

    # say L1545 ash
    old "That's why it's so bad that the web developer quit all of a sudden. Because he put me in a very difficult position."
    new "Deshalb ist es so schlimm, dass der Webentwickler plötzlich gekündigt hat. Denn er hat mich in eine sehr schwierige Lage gebracht."

    # say L1547 pla
    old "I understand, I'm sorry that happened."
    new "Ich verstehe, das tut mir leid."

    # say L1549 ash
    old "That's very nice of you dear, thank you."
    new "Das ist sehr nett von dir, Schatz, danke."

    # say L1550 ash
    old "Now, why don't we get started and I'll tell you what to do along the way?"
    new "Na dann, lass uns anfangen und ich sage dir, was du machen sollst."

    # say L1562 ash
    old "Ok, now please put the title in higher case."
    new "Ok, jetzt mach bitte den Titel größer."

    # say L1564 ash
    old "That's it, perfect. Could you also make those pictures a little bigger?"
    new "Das ist es, perfekt. Könntest du die Bilder auch ein bisschen größer machen?"

    # say L1565 ash
    old "I want the raw coffee shots to be front and center."
    new "Ich will, dass die Rohkaffeeaufnahmen im Vordergrund stehen."

    # say L1567 pla
    old "Ok, is that because of their brand?"
    new "Ok, ist das wegen ihrer Marke?"

    # say L1569 ash
    old "That's right, they want to show themselves as an organic coffee business, that's a contrast to the bigger coffee chains you see everywhere."
    new "Stimmt, sie wollen sich als Bio-Kaffee-Unternehmen positionieren, das ist der Gegensatz zu den großen Kaffee-Ketten, die man überall sieht."

    # say L1570 pla
    old "I see, I think I get it."
    new "Ich verstehe, das macht Sinn."

    # say L1574 ash
    old "Well, the whole point of marketing is developing and delivering the message the client wants to show."
    new "Na ja, der ganze Punkt von Marketing ist es, die Botschaft zu entwickeln und zu vermitteln, die der Kunde zeigen will."

    # say L1575 ash
    old "So, I really enjoy the process of using optics and messaging to find good ways to attract attention to our clients."
    new "Dann finde ich es echt toll, mit Optiken und Messaging gute Wege zu finden, um die Aufmerksamkeit auf unsere Kunden zu lenken."

    # say L1576 pla
    old "That's really cool Ashley."
    new "Das ist echt cool, Ashley."

    # say L1577 ash
    old "Thanks dear..."
    new "Danke Schatz..."

    # say L1578 ash
    old "Now, let's keep going."
    new "Dann lass uns weitermachen."

    # say L1590 ash
    old "Yes! That's exactly what I wanted!"
    new "Ja! Das ist genau das, was ich wollte!"

    # say L1591 ash
    old "You're really good at this [pla], I can't believe you thought you wouldn't do it properly."
    new "Du bist echt gut darin [pla], ich kann nicht glauben, dass du gedacht hast, du würdest es nicht richtig machen."

    # say L1593 pla
    old "T- Thank you, Ashley, I hope your bosses will like it too."
    new "D- Danke, Ashley, ich hoffe, deine Chefs werden es auch mögen."

    # say L1594 ash
    old "I'm sure they will, this is turning out better than what I expected."
    new "Ich bin mir sicher, das wird besser als erwartet."

    # say L1595 ash
    old "Actually, I think you've done enough for today."
    new "Eigentlich denke ich, dass du heute genug gemacht hast."

    # say L1596 ash
    old "Why don't we stop and continue another day?"
    new "Warum hören wir nicht auf und machen es an einem anderen Tag weiter?"

    # say L1605 ash
    old "You're very good at this [pla], I think that with your help we will have this ready in no time."
    new "Du bist echt gut darin [pla], ich denke, mit deiner Hilfe werden wir das in null Komma nichts fertig kriegen."

    # say L1606 pla
    old "Thanks ma'am, I'm sure we will."
    new "Danke, ich bin sicher, wir schaffen das."

    # say L1608 pla
    old "So, I- I guess I should leave for know."
    new "Also, ich- ich glaube, ich sollte jetzt gehen."

    # say L1610 ash
    old "Wait, before you go, I wanted to ask you about how much time you have available to work on this."
    new "Warte, bevor du gehst, wollte ich dich fragen, wie viel Zeit du hast, um daran zu arbeiten."

    # say L1612 ash
    old "You're a student after all. I wouldn't want to use all of your time."
    new "Du bist ja schließlich Student. Ich würde nicht wollen, dass ich all deine Zeit in Anspruch nehme."

    # say L1613 ash
    old "But if I'm honest, I could use your help as often as possible."
    new "Aber ehrlich gesagt, ich könnte deine Hilfe so oft wie möglich gebrauchen."

    # say L1615 ash
    old "So, it occurs to me that you could tell me when it works best for you."
    new "Dann fällt mir ein, dass du mir sagen könntest, wann es dir am besten passt."

    # say L1616 ash
    old "For us to work on the website."
    new "Damit wir an der Website arbeiten können."

    # say L1619 pla
    old "I- I guess I could come... Maybe every other day and work with you?"
    new "Ich- Ich denke, ich könnte kommen... Vielleicht alle zwei Tage und mit dir arbeiten?"

    # say L1621 ash
    old "That's just perfect for me!"
    new "Das ist perfekt für mich!"

    # say L1622 pla
    old "Great, that's good to hear."
    new "Super, das freut mich zu hören."

    # say L1623 pla
    old "Alright, it's getting a bit late, so,I think I'll go home now, Ashley."
    new "Okay, es wird langsam spät, ich denke, ich gehe jetzt nach Hause, Ashley."

    # say L1625 ash
    old "Sure dear, thanks again for your great help."
    new "Klar, Schatz, danke nochmal für deine tolle Hilfe."

    # say L1626 pla
    old "You're welcome, see you later."
    new "Gern geschehen, bis später."

    # say L1628 ash
    old "See you honey."
    new "Bis später, Schatz."

    # say L1651 sis
    old "Listen, your cosplay has arrived."
    new "Hör mal, dein Cosplay ist angekommen."

    # say L1653 pla
    old "Really? It arrived this quickly? That's great!"
    new "Wirklich? Das ging ja schnell. Das ist toll!"

    # say L1654 sis
    old "Well, I have a direct contact, and they always send it via express delivery."
    new "Na, ich habe da einen direkten Kontakt, und die schicken es immer per Expresslieferung."

    # say L1655 pla
    old "Oh, that's great."
    new "Oh, das ist toll."

    # say L1656 sis
    old "Come with me, the package is in my bedroom."
    new "Komm mit, das Paket ist in meinem Schlafzimmer."

    # say L1657 pla
    old "Oh, right."
    new "Oh, klar."

    # say L1672 sis
    old "Wait here."
    new "Warte hier."

    # say L1685 sis
    old "Here it is."
    new "Hier ist es."

    # say L1687 sis
    old "I ordered it directly from a producer."
    new "Ich habe es direkt von einem Produzenten bestellt."

    # say L1689 sis
    old "I knew that you needed it quickly, right?"
    new "Ich wusste, dass du es schnell brauchst, oder?"

    # say L1693 pla
    old "This is great, thanks a lot."
    new "Das ist toll, danke schön."

    # say L1694 sis
    old "Don't worry about it, I'm happy to help you."
    new "Mach dir keine Sorgen, ich freue mich, dir zu helfen."

    # say L1695 sis
    old "I hope your friend likes it."
    new "Ich hoffe, deine Freundin mag es."

    # say L1696 pla
    old "I'm sure she will, thanks [sis]."
    new "Ich bin sicher, sie wird es mögen, danke [sis]."

    # say L1709 pla
    old "Hi belle, good morning."
    new "Hi Belle, guten Morgen."

    # say L1710 bel
    old "Hi [pla], how are you today?"
    new "Hi [pla], wie geht es dir heute?"

    # say L1714 pla
    old "Hey, listen, I got your cosplay!"
    new "Hey, hör mal, ich hab dein Cosplay bekommen!"

    # say L1716 bel
    old "Really? That's wonderful [pla]!"
    new "Wirklich? Das ist toll [pla]!"

    # say L1717 pla
    old "Yeah, I received it this morning. Is your mom going to be home this afternoon? If not, I can bring it to your house so you can try it on."
    new "Ja, ich hab es heute Morgen bekommen. Ist deine Mom heute Nachmittag zu Hause? Wenn nicht, kann ich es dir vorbeibringen, damit du es anprobieren kannst."

    # say L1719 bel
    old "She won't be, so we can stream today as well!"
    new "Sie wird nicht da sein, also können wir heute auch streamen!"

    # say L1721 pla
    old "You want to stream right away?"
    new "Willst du gleich streamen?"

    # say L1722 bel
    old "Of course, we have to."
    new "Natürlich, wir müssen."

    # say L1724 bel
    old "Lana has been putting up a lot of new content, I can't let any more time pass by."
    new "Lana hat neues Material hochgeladen, ich darf keine Zeit mehr verstreichen lassen."

    # say L1726 pla
    old "Yeah, you're right, I'll bring the cosplay after classes. Ok?"
    new "Klar, du hast recht, ich bringe den Cosplay nach den Kursen mit. Ok?"

    # say L1727 bel
    old "Yeah, perfect."
    new "Klar, perfekt."

    # say L1753 bel
    old "Ok, so you'll pick up the cosplay at your house and I'll set up the stream. Ok?"
    new "Ok, dann holst du das Kostüm zu Hause ab und ich richte den Stream ein. Ok?"

    # say L1754 pla
    old "Sure, I'll be there right away."
    new "Klar, ich bin gleich da."

    # say L1770 pla
    old "Hey Belle, here it is."
    new "Hey Belle, hier ist es."

    # say L1775 bel
    old "Great! Let's go up to my room and I'll try it on."
    new "Super! Lass uns nach oben in mein Zimmer gehen und ich ziehe es an."

    # say L1796 bel
    old "Ok, I'll put it on."
    new "Ok, ich ziehe es an."

    # say L1808 bel
    old "So, what do you think?"
    new "Was denkst du?"

    # say L1810 pla
    old "You look great Belle!"
    new "Du siehst toll aus, Belle!"

    # say L1811 pla
    old "It really fits you."
    new "Es steht dir wirklich gut."

    # say L1812 bel
    old "I'm happy you like it."
    new "Ich freue mich, dass dir's gefällt."

    # say L1813 bel
    old "Let's get started with the stream then."
    new "Dann lassen wir das Stream mal beginnen."

    # say L1828 bel
    old "Ok guys, it's time for another good time!"
    new "Ok Leute, es ist Zeit für eine weitere gute Zeit!"

    # say L1829 bel
    old "What do you think of the cosplay that I prepared for you?"
    new "Was denkt ihr über das Cosplay, das ich für euch vorbereitet habe?"

    # say L1830 bel
    old "I know you have been waiting to see me like this, so be sure to enjoy!"
    new "Ich weiß, dass ihr darauf gewartet habt, mich so zu sehen, also genießt es richtig!"

    # say L1831 bel
    old "But that's not all."
    new "Aber das ist noch nicht alles."

    # say L1832 bel
    old "Since you guys liked to see my friend so much last time, I brought him here again!"
    new "Da ihr Jungs letztes Mal so gerne meinen Freund gesehen habt, hab ich ihn wieder mitgebracht!"

    # say L1833 bel
    old "So say hi to him again!"
    new "Sagt ihm wieder Hallo!"

    # say L1839 bel
    old "Ok, guys, let's not waste any more time."
    new "Ok, Leute, lassen wir uns nicht mehr Zeit nehmen."

    # say L1840 bel
    old "I know you've been waiting for it, so let's get to it."
    new "Ich weiß, dass ihr darauf gewartet habt, also lasst es uns tun."

    # say L1847 bel
    old "OH! God! This cock!"
    new "OH! Gott! Dieser Schwanz!"

    # say L1848 bel
    old "I love it! It's just the best taste in the world!"
    new "Ich liebe es! Es ist der beste Geschmack der Welt!"

    # say L1849 bel
    old "Your dick is so big guys!"
    new "Euer Schwanz ist so groß, Jungs!"

    # say L1861 bel
    old "I'm happy you enjoyed the stream and my cosplay!"
    new "Ich freue mich, dass dir der Stream und mein Cosplay gefallen haben!"

    # say L1862 bel
    old "After all, I'm doing this for all of you!"
    new "Immerhin mache ich das alles für euch!"

    # say L1863 bel
    old "I'll end the stream here for now."
    new "Ich werde den Stream hier mal beenden."

    # say L1864 bel
    old "But be sure that I'll come back soon."
    new "Aber seid sicher, ich komme bald wieder."

    # say L1865 bel
    old "As always, remember to subscribe to the stream."
    new "Wie immer, vergiss nicht, dich dem Stream zu abonnieren."

    # say L1866 bel
    old "And you’ll be notified every time I’m online!"
    new "Und du wirst benachrichtigt, sobald ich online bin!"

    # say L1867 bel
    old "And of course, remember to check out my social media links!"
    new "Und natürlich, schaut mal auf meinen Social Media Links vorbei!"

    # say L1868 bel
    old "Thans for your support guys!"
    new "Danke für eure Unterstützung, Leute!"

    # say L1869 bel
    old "See you later, bye!"
    new "Bis später, tschüss!"

    # say L1879 bel
    old "I'm sure that with this, Lana will not have a chance to catch me!"
    new "Ich bin sicher, dass damit Lana keine Chance hat, mich einzuholen!"

    # say L1881 pla
    old "Awesome!"
    new "Super!"

    # say L1883 pla
    old "After all you've worked really hard for this."
    new "Schließlich hast du echt hart dafür gearbeitet."

    # say L1887 pla
    old "I think I'll head back home before your mother arrives."
    new "Ich denke, ich geh besser nach Hause, bevor deine Mutter kommt."

    # say L1888 bel
    old "Alright, I'll let you know how the voting goes tomorrow."
    new "Okay, ich lass dich wissen, wie die Abstimmung morgen läuft."

    # say L1889 pla
    old "Sure, I'm sure it's going to go great."
    new "Klar, ich bin sicher, es wird super laufen."

    # say L1906 pla
    old "Hi, Ashley, I'm fine thank you."
    new "Hi, Ashley, ich bin gut, danke."

    # say L1907 ash
    old "That's good, tell me, is there anything I can help you with?"
    new "Das ist gut, erzähl mir, gibt es etwas, bei dem ich dir helfen kann?"

    # say L1915 pla
    old "Well, I was thinking that I could keep helping you with developing the website."
    new "Na, ich dachte, ich könnte dir weiter bei der Entwicklung der Website helfen."

    # say L1916 ash
    old "That would be great [pla]!"
    new "Das wäre toll [pla]!"

    # say L1917 ash
    old "Ok, wait here a minute and I'll get everything ready."
    new "Ok, warte hier einen Moment, ich mache alles bereit."

    # say L1926 pla
    old "Oh, not much, I was just passing by."
    new "Oh, nicht viel, ich war nur gerade vorbei."

    # say L1929 ash
    old "Please remember to come work on the website project soon. The deadline is coming soon."
    new "Bitte denk dran, bald an dem Website-Projekt zu arbeiten. Die Frist kommt bald."

    # say L1931 pla
    old "Sure, don't worry I'll keep that in mind."
    new "Klar, mach ich."

    # say L1933 ash
    old "Thank you [pla], I'll see you later then."
    new "Danke [pla], dann sehen wir uns später."

    # say L1947 ash
    old "Ok, so for today I want us to focus on a new part of the project."
    new "Ok, dann konzentrieren wir uns heute auf einen neuen Teil des Projekts."

    # say L1948 pla
    old "Alright, what are we doing?"
    new "Okay, was machen wir?"

    # say L1950 ash
    old "Let's get started and I'll explain to you along the way."
    new "Lass uns anfangen und ich erkläre dir unterwegs."

    # say L1967 ash
    old "Ok, Ok, I really like how this turned out."
    new "Ok, ok, ich finde es echt toll, wie das ausgefallen ist."

    # say L1968 ash
    old "I think we can move on to the next category."
    new "Ich denke, wir können zur nächsten Kategorie übergehen."

    # say L1971 pla
    old "Really? Don't you want to use make any corrections?"
    new "Wirklich? Willst du keine Korrekturen vornehmen?"

    # say L1973 ash
    old "Not right now, because I haven't  seen how it works with other areas of the website."
    new "Nicht jetzt, weil ich noch nicht gesehen habe, wie es mit den anderen Bereichen der Website funktioniert."

    # say L1975 ash
    old "So, let's shift our focus to those, and then we can make any pertinent corrections."
    new "Dann konzentrieren wir uns darauf und machen danach die nötigen Korrekturen."

    # say L1977 pla
    old "I see, ok, let's do that."
    new "Okay, machen wir das."

    # say L1983 ash
    old "Alright [pla], I think that was enough for today. I think we can continue this another time."
    new "Okay [pla], ich denke, das war genug für heute. Wir können das nächste Mal weitermachen."

    # say L1984 ash
    old "Once again, thanks a lot for your help."
    new "Nochmal danke für deine Hilfe."

    # say L1985 pla
    old "You're welcome. My pleasure to help you."
    new "Gern geschehen. Es war mir ein Vergnügen, dir zu helfen."

    # say L1986 ash
    old "Now, it's a little late, so why don't you go home and rest?"
    new "Jetzt ist es ein bisschen spät, also warum gehst du nicht nach Hause und ruhst dich aus?"

    # say L1988 pla
    old "Yeah, you're right. See you later Ashley."
    new "Ja, du hast recht. Bis später, Ashley."

    # say L1989 ash
    old "See you later hon."
    new "Bis später Schatz."

    # say L2019 pla
    old "Hi Belle, how are you?"
    new "Hi Belle, wie geht's dir?"

    # say L2021 pla
    old "What? What's with that expresion?"
    new "Was? Was ist mit diesem Gesichtsausdruck?"

    # say L2022 pla
    old "Is there anything wrong?"
    new "Ist was los?"

    # say L2024 bel
    old "I guess you could say there is."
    new "Ich schätze, man könnte sagen, dass da was ist."

    # say L2025 bel
    old "I saw the latests results of the poll before I came."
    new "Ich hab die neuesten Ergebnisse der Umfrage gesehen, bevor ich gekommen bin."

    # say L2027 bel
    old "And Lana is still on top!"
    new "Und Lana steht immer noch an erster Stelle!"

    # say L2028 pla
    old "She is? But I thought you said that with what we did last time, there was no way she could catch you."
    new "Sie ist? Aber ich dachte, du hast gesagt, dass bei dem, was wir letztes Mal gemacht haben, sie dich nie einholen könnte."

    # say L2030 bel
    old "I know, but you just won't believe what that whore is doing now!"
    new "Ich weiß, aber du wirst es nicht glauben, was diese Schlampe jetzt macht!"

    # say L2032 bel
    old "She's doing anal!"
    new "Sie macht Anal!"

    # say L2033 bel
    old "I mean, can you believe it?!"
    new "Ich meine, kannst du das glauben?!"

    # say L2035 pla
    old "Uhmm, I mean... Is it weird for people to do webcamming?"
    new "Ähm, ich meine... Ist es komisch, wenn Leute Webcam machen?"

    # say L2037 bel
    old "For a new model, of course it is... She just started streaming a few weeks ago!"
    new "Für eine Neue, natürlich... Sie streamt erst seit ein paar Wochen!"

    # say L2039 bel
    old "She hasn't built a fanbase or anything yet, she is crazy!"
    new "Sie hat noch keine Fangemeinde oder so, sie ist verrückt!"

    # say L2041 bel
    old "Besides, you know what else she did?"
    new "Außerdem, weißt du was sie noch gemacht hat?"

    # say L2043 bel
    old "She just uploaded it as a video to her stream!"
    new "Sie hat es einfach als Video auf ihren Stream hochgeladen!"

    # say L2045 bel
    old "Well, she didn't do it live; she just recorded it off-camera and then uploaded it as if it were live..."
    new "Na ja, sie hat es nicht live gemacht; sie hat es einfach abseits der Kamera aufgenommen und dann so hochgeladen, als wäre es live..."

    # say L2048 bel
    old "I don't know for certain, but come on, you can tell she did."
    new "Ich bin mir nicht sicher, aber komm schon, man merkt doch, dass sie es gemacht hat."

    # say L2050 bel
    old "She's not interacting with her chat, answering questions, or anything."
    new "Sie chattet nicht, beantwortet keine Fragen oder so was."

    # say L2051 bel
    old "She's just doing it and that's it."
    new "Sie macht es einfach und basta."

    # say L2053 bel
    old "It's clear that it wasn't a live stream, that's for sure!"
    new "Das war definitiv keine Live-Stream-Sache."

    # say L2054 pla
    old "Ok, I get it, what are you going to do about it then?"
    new "Ok, ich verstehe, was wirst du dann tun?"

    # say L2056 bel
    old "Isn't it obvious?"
    new "Ist das nicht offensichtlich?"

    # say L2058 bel
    old "I'm going to match her!"
    new "Ich werde sie überholen!"

    # say L2059 bel
    old "I'm not going to just sit down and wait for her to pass me in the rankings!"
    new "Ich werde nicht einfach so dasitzen und darauf warten, dass sie mich in den Ranglisten überholen!"

    # say L2060 pla
    old "So... You're also doing anal too?"
    new "Also... Du machst das auch anal?"

    # say L2062 bel
    old "Yes, why? Are you against doing it or something?"
    new "Ja, warum? Bist du dagegen oder so?"

    # say L2063 pla
    old "Uhh, no, no, nothing like that."
    new "Uhh, nein, nein, so war das nicht gemeint."

    # say L2064 pla
    old "It's just surprising, that's all."
    new "Es ist nur überraschend, das ist alles."

    # say L2066 bel
    old "It wasn't my plan, obviously."
    new "Das war definitiv nicht mein Plan."

    # say L2067 bel
    old "But after I saw Lana's {i}'Stream'{/i}..."
    new "Aber nachdem ich Lanas {i}'Stream'{/i} gesehen habe..."

    # say L2068 bel
    old "I asked my followers if they would like to see me doing something similar."
    new "Ich habe meine Follower gefragt, ob sie es toll finden würden, wenn ich etwas Ähnliches mache."

    # say L2069 bel
    old "They said they'd totally love to see it."
    new "Sie sagten, sie würden es total liebend gern sehen."

    # say L2070 bel
    old "So that settles it, we're doing it!"
    new "Dann ist es ja beschlossen, wir machen es!"

    # say L2071 bel
    old "I told them we had a surprise coming the next time you appeared on the stream with me."
    new "Ich hab ihnen gesagt, wir hätten eine Überraschung für das nächste Mal, wenn du im Stream mit mir auftauchst."

    # say L2072 pla
    old "I see, w- well if you're ok with it, I- I guess it's fine."
    new "Ich sehe, n- na ja, wenn es dir recht ist, d- dann ist es in Ordnung."

    # say L2074 bel
    old "Yeah, I know that the next time you come to my house you have to do that website thing with my mom."
    new "Ja, ich weiß, dass das nächste Mal, wenn du zu mir kommst, du mit meiner Mum die Website-Sache machen musst."

    # say L2075 bel
    old "But perhaps we could do it afterwards."
    new "Aber vielleicht könnten wir es danach machen."

    # say L2077 pla
    old "Actually, it's going to be at least a couple of times that I come to your house and help your mom with the website."
    new "Tatsächlich, ich werde mindestens ein paar Mal zu dir nach Hause kommen und deiner Mom bei der Website helfen."

    # say L2079 bel
    old "Really?!"
    new "Wirklich?!"

    # say L2080 bel
    old "But we're really short on time [pla]!"
    new "Aber wir haben echt nicht viel Zeit [pla]!"

    # say L2081 pla
    old "I know, I'm sorry, but apparently, she has to show some progress to her bosses in the next meeting."
    new "Ich weiß, es tut mir leid, aber anscheinend muss sie in der nächsten Besprechung Fortschritte vorweisen."

    # say L2082 pla
    old "So, I kinda have to help her with it."
    new "Dann muss ich ihr wohl dabei helfen."

    # say L2084 bel
    old "Hmph OK, I guess that's fine."
    new "Hmpf, okay, ich schätze, das ist in Ordnung."

    # say L2085 bel
    old "I'll tell my fans to wait for a while before I show them the '{i}surprise{/i}' I'd promise them."
    new "Ich sag meinen Fans, dass sie noch ein bisschen warten müssen, bevor ich ihnen die '{i}Überraschung{/i}' zeige, die ich ihnen versprochen habe."

    # say L2086 bel
    old "But after that we have to do it, ok?"
    new "Aber danach müssen wir es tun, okay?"

    # say L2089 bel
    old "Ok, I guess we better go to classes for now."
    new "Okay, ich schätze, wir sollten jetzt zu unseren Kursen gehen."

    # say L2115 ash
    old "Thank you, dear. I'm very glad I've got to meet you, you know?"
    new "Danke, Liebste. Ich bin echt froh, dass ich dich kennengelernt habe, weißt du?"

    # say L2117 ash
    old "After all, Belle never introduces me to any of her friends."
    new "Immerhin stellt Belle mich nie einem ihrer Freunde vor."

    # say L2118 ash
    old "That girl's so secretive now."
    new "Das Mädchen ist jetzt so geheimnisvoll."

    # say L2119 pla
    old "So... Aren't you and Belle close?"
    new "Also... Seid ihr und Belle denn nicht eng befreundet?"

    # say L2120 ash
    old "No, we're not."
    new "Nein, sind wir nicht."

    # say L2121 ash
    old "We used to be very close before, but over the years she and I have distanced a lot."
    new "Früher waren wir sehr eng, aber im Laufe der Jahre haben wir uns viel voneinander entfernt."

    # say L2124 ash
    old "Yes, when Belle was growing up we were inseparable."
    new "Ja, als Belle aufgewachsen ist, waren wir unzertrennlich."

    # say L2126 ash
    old "I would never go anywhere without her, and you'd be hard-pressed to see one without the other."
    new "Ich würde nie ohne sie irgendwohin gehen, und du würdest dich schwer tun, die eine ohne die andere zu sehen."

    # say L2129 ash
    old "But as time went by we began to distance."
    new "Aber mit der Zeit haben wir uns voneinander entfernt."

    # say L2131 ash
    old "Now we barely even talk, and whenever we're together is like she's angry with me all the time."
    new "Jetzt reden wir kaum noch miteinander, und wenn wir zusammen sind, ist sie die ganze Zeit sauer auf mich."

    # say L2133 pla
    old "I'm sorry, I didn't know things were like that between the two of you."
    new "Es tut mir leid, ich wusste nicht, dass es zwischen euch so ist."

    # say L2135 ash
    old "Yeah, but I blame myself."
    new "Ja, aber ich mache mir selbst Vorwürfe."

    # say L2138 ash
    old "Well, I'm a single mother, and I had Belle when I was very young."
    new "Na ja, ich bin Single-Mutter und hatte Belle, als ich noch sehr jung war."

    # say L2140 ash
    old "I decided that I would do everything I could to raise her properly."
    new "Ich habe entschieden, alles zu tun, was in meiner Macht steht, um sie richtig zu erziehen."

    # say L2142 ash
    old "So, as she grew up, my focus was on my work."
    new "Also, während sie aufwuchs, lag mein Fokus auf meiner Arbeit."

    # say L2144 ash
    old "Since I was always working, I never had any time for her or the things related to school."
    new "Da ich immer gearbeitet habe, hatte ich nie Zeit für sie oder die Dinge, die mit der Schule zu tun hatten."

    # say L2146 ash
    old "Is not that I wasn't interested, is just that I was busy all the time."
    new "Das heißt nicht, dass ich nicht interessiert war, es ist nur, dass ich die ganze Zeit beschäftigt war."

    # say L2147 ash
    old "I sort of thought that as long as I was providing for her, things would be fine."
    new "Ich dachte irgendwie, solange ich für sie sorge, wären die Dinge in Ordnung."

    # say L2149 ash
    old "But I didn't realize she was pulling away from me. Nowadays I never know what she's doing."
    new "Aber ich habe nicht gemerkt, dass sie sich von mir entfernt hat. Heutzutage habe ich keine Ahnung, was sie so treibt."

    # say L2150 ash
    old "Her interests, or the things she's into..."
    new "Ihre Interessen, oder die Dinge, die sie mag..."

    # say L2152 ash
    old "It's a miracle I even know Hinn, and that's just because I came home one time while she was here."
    new "Es ist ein Wunder, dass ich Hinn überhaupt kenne, und das nur, weil ich einmal zu Hause war, als sie hier war."

    # say L2154 ash
    old "Oh, and that other friend... Mike."
    new "Oh, und dieser andere Freund... Mike."

    # say L2156 ash
    old "But I'd rather not to talk about him."
    new "Aber ich möchte lieber nicht über ihn sprechen."

    # say L2158 pla
    old "I- I'm sorry about that M- Mrs... I- I mean A- Ashley."
    new "I- Ich bin d- das mit der M- Mrs... Ich meine, A- Ashley leid."

    # say L2159 pla
    old "But I'm sure you and Belle will be fine."
    new "Aber ich bin sicher, dass du und Belle klarkommen wirst."

    # say L2161 ash
    old "You think so?"
    new "Du denkst das?"

    # say L2163 pla
    old "For sure, after all, you say you've always been close."
    new "Klar, schließlich sagst du doch, dass ihr euch immer nahegestanden habt."

    # say L2164 pla
    old "I'm sure Belle's just..."
    new "Ich bin sicher, Belle ist einfach..."

    # say L2165 pla
    old "Uhm... Worried about things from school and such."
    new "Äh... Sich Sorgen um die Schule und so."

    # say L2167 ash
    old "I guess I'll have to take your word for it. After all, you may be more informed about what she's doing lately than me."
    new "Ich schätze, ich muss dir einfach glauben. Schließlich bist du vielleicht besser informiert, was sie so treibt, als ich."

    # say L2169 ash
    old "The good thing is that she doesn't seem to be doing anything weird or out of the ordinary."
    new "Das Gute ist, dass sie nichts Seltsames oder Außergewöhnliches macht."

    # say L2170 ash
    old "She's just focused on school."
    new "Sie konzentriert sich einfach auf die Schule."

    # say L2173 ash
    old "Although I think it would be good if she went out a little bit more. She seems to expend most of her time on her computer."
    new "Aber ich denke, es wäre gut, wenn sie ein bisschen mehr rausgehen würde. Sie verbringt die meiste Zeit an ihrem Computer."

    # say L2175 ash
    old "But I guess that's good, at least she's not doing anything bad."
    new "Aber ich schätze, das ist gut, zumindest macht sie nichts Schlimmes."

    # say L2177 pla
    old "Uhh, sure..."
    new "Uhh, klar..."

    # say L2179 ash
    old "But anyway, enough of my lamenting, it's getting a little late [pla], and you've been here for a while."
    new "Aber egal, genug von meinem Gejammer, es wird langsam spät [pla], und du bist schon eine Weile hier."

    # say L2180 ash
    old "Why don't you go home for now? We can continue working some other time."
    new "Warum gehst du nicht nach Hause? Wir können das ein anderes Mal weitermachen."

    # say L2181 pla
    old "Oh! Sure!"
    new "Oh! Klar!"

    # say L2187 pla
    old "I'll see you later then. Goodbye, Ashley."
    new "Dann sehen wir uns später. Tschüss, Ashley."

    # say L2189 ash
    old "Goodbye hon, thanks for your help today."
    new "Tschüss Schatz, danke für deine Hilfe heute."

    # say L2190 ash
    old "And thank you, for listening to me."
    new "Und danke dir, dass du mir zugehört hast."

    # say L2192 pla
    old "Gladly, I'm happy to help you, and to talk to you."
    new "Gerne, ich freue mich, dir zu helfen und mit dir zu reden."

    # say L2194 ash
    old "That's very sweet."
    new "Das ist sehr lieb."

    # say L2199 pla
    old "I think I should get going then."
    new "Dann sollte ich wohl losgehen."

    # say L2200 ash
    old "Yeah, yeah, sure. Bye."
    new "Ja, ja, klar. Tschüss."

    # say L2222 bel
    old "Hi [pla], how are you?"
    new "Hi [pla], wie geht's dir?"

    # say L2224 bel
    old "Well, I wanted to discuss what we're going to do for our next stream together."
    new "Na, ich wollte besprechen, was wir bei unserem nächsten Stream machen."

    # say L2228 bel
    old "Well, I know you had to help my mom with that website she's working on."
    new "Na, ich weiß, dass du meiner Mum bei der Website geholfen hast, an der sie arbeitet."

    # say L2230 bel
    old "But I think today you're supposed to be free, right?"
    new "Aber ich denke, heute hast du frei, oder?"

    # say L2231 bel
    old "So, do you think you could come to my house today?"
    new "Dann, denkst du, du könntest heute zu mir kommen?"

    # say L2233 bel
    old "Great! So let's go after classes."
    new "Super! Dann lass uns nach den Kursen gehen."

    # say L2259 bel
    old "Ok, let's go."
    new "Ok, lass uns gehen."

    # say L2260 pla
    old "Right, let's do it."
    new "Okay, dann machen wir es."

    # say L2273 bel
    old "Alright, let's do this!"
    new "Okay, dann lass uns das machen!"

    # say L2274 pla
    old "Wait, before we start."
    new "Warte, bevor wir anfangen."

    # say L2275 pla
    old "Are you sure you want to do this?"
    new "Bist du dir sicher, dass du das willst?"

    # say L2276 pla
    old "I know it's not that big a deal to some people, but  you would be doing it for the first time."
    new "Ich weiß, dass es für manche kein großes Ding ist, aber du würdest es das erste Mal machen."

    # say L2277 bel
    old "I am, listen [pla], I've worked very hard for this."
    new "Ich bin es, hör zu [pla], ich habe sehr hart dafür gearbeitet."

    # say L2279 bel
    old "Winning this award means a lot to me."
    new "Dieser Preis bedeutet mir sehr viel."

    # say L2280 bel
    old "And I'm not backing down because of Lana suddenly coming into the scene."
    new "Und ich gebe nicht einfach so auf, nur weil Lana plötzlich auftaucht."

    # say L2282 bel
    old "So yeah, I'm sure!"
    new "Dann ja, ich bin mir sicher!"

    # say L2283 pla
    old "Ok, if you're this determined, let's do it."
    new "Okay, wenn du so entschlossen bist, dann machen wir es."

    # say L2285 bel
    old "Yeah! Let's do it!"
    new "Ja! Lass es uns tun!"

    # say L2298 bel
    old "Hello again guys!"
    new "Hallo nochmal Jungs!"

    # say L2299 bel
    old "I'm very happy to see you all again!"
    new "Ich freue mich total, euch alle wiederzusehen!"

    # say L2300 bel
    old "And I have very good news, everybody!"
    new "Und ich habe sehr gute Nachrichten für euch alle!"

    # say L2301 bel
    old "Remember the other surprise I'd talked to you about?!"
    new "Erinnert ihr euch an die andere Überraschung, von der ich gesprochen habe?!"

    # say L2302 bel
    old "Well, it's happening today!"
    new "Na, es passiert heute!"

    # say L2303 bel
    old "I know this is something you've been dying to see!"
    new "Ich weiß, dass du das schon die ganze Zeit sehen wolltest!"

    # say L2304 bel
    old "And I know you will love it!"
    new "Und ich weiß, dass du es lieben wirst!"

    # say L2305 bel
    old "So, say hello again to my friend, and let's get to it!"
    new "Sag Hallo zu meinem Freund und lass uns anfangen!"

    # say L2310 bel
    old "Remember guys, just as always! Today's surprise can only come if you guys reach our goal."
    new "Mädels und Jungs, genau wie immer! Die Überraschung von heute kriegt ihr erst, wenn wir das Ziel erreichen."

    # say L2311 bel
    old "But I'm sure you'll reach it!"
    new "Aber ich bin sicher, dass ihr es schafft!"

    # say L2318 bel
    old "For today we're going to need it well lubricated, isn't that right, guys?"
    new "Für heute müssen wir es gut einschmieren, stimmt's, Leute?"

    # say L2319 bel
    old "So I'll take care of doing a good job with my mouth to get it ready for what comes next."
    new "Dann kümmere ich mich mal darum, es mit meinem Mund gut vorzubereiten für den nächsten Schritt."

    # say L2320 bel
    old "My God! What a great cock!"
    new "Mein Gott! Was für ein toller Schwanz!"

    # say L2321 bel
    old "Right guys?!"
    new "Stimmt's, Jungs?!"

    # say L2322 bel
    old "I bet you can't wait to see me being ravaged by it."
    new "Ich wette, ihr könnt es kaum abwarten, mich damit zu ficken."

    # say L2323 bel
    old "Just be sure to get to the goal guys!"
    new "Aber sicher, dass ihr das Ziel erreicht, Jungs!"

    # say L2336 pla
    old "Uh- I- uh..."
    new "Uh- ich- uh..."

    # say L2337 pla
    old "I came to do something with Belle."
    new "Ich bin gekommen, um was mit Belle zu machen."

    # say L2339 pla
    old "Some... Uh- school work..."
    new "Einige... Äh- Schularbeiten..."

    # say L2341 ash
    old "Ok, I see, but where is Belle?"
    new "Okay, ich verstehe, aber wo ist Belle?"

    # say L2343 pla
    old "She... Uh- she went out for a while."
    new "Sie... Uh- sie ist für ein bisschen rausgegangen."

    # say L2344 pla
    old "She said something about picking up a thing at Hinn's house."
    new "Sie hat was von einem Besuch bei Hinn gesagt."

    # say L2346 ash
    old "I had to pop home to get some documents for work, and I wanted to talk with her."
    new "Ich musste kurz nach Hause, um ein paar Dokumente für die Arbeit zu holen, und ich wollte mit ihr sprechen."

    # say L2347 ash
    old "Well, it's good to see you anyway."
    new "Na ja, es freut mich trotzdem, dich zu sehen."

    # say L2348 ash
    old "I'll go back to the office, please tell Belle to give me a call when she gets back."
    new "Ich geh zurück ins Büro, sag Belle, sie soll mich anrufen, wenn sie zurück ist."

    # say L2349 ash
    old "See you later [pla]."
    new "Bis später [pla]."

    # say L2350 pla
    old "Sure, see you later ma'am."
    new "Klar, bis später."

    # say L2363 bel
    old "{i}Holy shit, I know... Anyway, let's just keep going with the stream... Shhh...{/i}"
    new "{i}Scheiße, ich weiß... Auf jeden Fall, lass uns einfach weitermachen mit dem Stream... Psst...{/i}"

    # say L2364 bel
    old "Sorry, guys! I'm sorry for that little interruption... You know, this can happen when you're doing it live..."
    new "Entschuldigung, Leute! Tut mir leid für diese kleine Unterbrechung... Wisst ihr, so was passiert, wenn man live geht..."

    # say L2365 bel
    old "Anyways, let's continue with the show!"
    new "Na los, lasst uns mit dem Stream weitermachen!"

    # say L2366 bel
    old "But now we can resume with what we were doing, and you know what that means."
    new "Aber jetzt können wir mit dem weitermachen, was wir gemacht haben, und du weißt, was das bedeutet."

    # say L2368 bel
    old "No, she won't be joining us or anything."
    new "Nein, sie wird uns nicht begleiten oder so."

    # say L2369 bel
    old "That was just an unplanned thing."
    new "Das war nur etwas Ungeplantes."

    # say L2370 bel
    old "But don't worry, we're not stopping here."
    new "Aber mach dir keine Sorgen, wir hören hier nicht auf."

    # say L2371 bel
    old "Let's keep going!"
    new "Lass uns weitermachen!"

    # say L2388 bel
    old "Wow, that was close!"
    new "Wow, das war knapp!"

    # say L2389 pla
    old "Really close."
    new "Wirklich knapp."

    # say L2390 pla
    old "That really scared me."
    new "Das hat mich echt erschreckt."

    # say L2391 bel
    old "It's good that she didn't see us doing anything."
    new "Es ist gut, dass sie uns nicht dabei gesehen hat."

    # say L2393 bel
    old "I can't imagine how we would explain the whole situation to her."
    new "Ich kann mir gar nicht vorstellen, wie wir ihr die ganze Situation erklären sollten."

    # say L2394 pla
    old "Yeah, tell me about it."
    new "Ja, sag mir was."

    # say L2395 bel
    old "Well, we should get back to the stream before the fans get impatient."
    new "Na dann, wir sollten wieder zum Stream zurückkehren, bevor die Fans ungeduldig werden."

    # say L2408 bel
    old "Hngh! Oh yes!"
    new "Hngh! Oh ja!"

    # say L2409 bel
    old "This is what you've all been waiting for isn't it?"
    new "Das ist es, worauf ihr alle gewartet habt, oder?"

    # say L2410 bel
    old "Well, you earned it!"
    new "Na, dann genießt es auch!"

    # say L2411 bel
    old "So, be sure to enjoy it!"
    new "Dann genießt es auch richtig!"

    # say L2424 bel
    old "Guys! I'm so glad you liked it!"
    new "Leute! Ich freue mich so, dass es euch gefallen hat!"

    # say L2425 bel
    old "You keep making all of this possible."
    new "Ihr macht all das hier möglich."

    # say L2426 bel
    old "Witout your support this just wouldn't be possible."
    new "Ohne eure Unterstützung wäre das alles nicht möglich."

    # say L2427 bel
    old "So, it makes me very happy to do this kind of thing for you."
    new "Dann freut es mich sehr, so etwas für dich zu tun."

    # say L2428 bel
    old "Ok guys, I have to leave for now."
    new "Ok Leute, ich muss jetzt los."

    # say L2429 bel
    old "But be sure that I'll be back soon with another stream."
    new "Aber seid sicher, ich komme bald wieder mit einem neuen Stream."

    # say L2430 bel
    old "I wonder what surprise I'll have for you then?"
    new "Ich frage mich, was für eine Überraschung ich dann für euch habe?"

    # say L2431 bel
    old "As always remember to subscribe so you will get notified of the next stream!"
    new "Und vergiss nicht, dich zu abonnieren, damit du benachrichtigt wirst, wenn das nächste Stream startet!"

    # say L2432 bel
    old "And remember to follow me on all my socials."
    new "Und folgt mir auf all meinen Socials."

    # say L2433 bel
    old "So you won't miss any updates!"
    new "Dann verpasst ihr keine Updates!"

    # say L2434 bel
    old "Until next time, see you guys! Love you!"
    new "Bis zum nächsten Mal, bis bald! Ich liebe euch!"

    # say L2443 bel
    old "That came out really well [pla]!"
    new "Das hat super geklappt [pla]!"

    # say L2444 bel
    old "They matched the goal so quickly!"
    new "Sie haben das Ziel so schnell erreicht!"

    # say L2445 bel
    old "I'm sure I'll overtake Lana in no time!"
    new "Ich bin sicher, ich holre Lana bald ein!"

    # say L2446 bel
    old "And this time I'm certain the first spot in the rankings is mine for sure!"
    new "Und dieses Mal bin ich mir sicher, dass der erste Platz in den Rankings mir gehört!"

    # say L2448 pla
    old "That's great to hear Belle, I'm sure you'll get it."
    new "Das ist toll zu hören Belle, ich bin sicher, du schaffst es."

    # say L2450 pla
    old "Although I hope your fans weren't bothered by your mom coming in midstream."
    new "Aber ich hoffe, deine Fans haben sich nicht gestört, als deine Mom hereinkam."

    # say L2452 pla
    old "That really scared me, I thought she was going to see us."
    new "Das hat mich echt erschreckt, ich dachte, sie würde uns sehen."

    # say L2454 bel
    old "Yeah, me too, I'm sorry that happened, by the way."
    new "Ja, mir auch, tut mir leid, dass das passiert ist."

    # say L2455 bel
    old "She just had to come in at the most inopportune time."
    new "Sie musste einfach genau dann reinkommen, als es am ungünstigsten war."

    # say L2456 bel
    old "But don't worry, the fans weren't too bothered by her intrusion."
    new "Aber mach dir keine Sorgen, die Fans waren nicht allzu besorgt über ihre Störung."

    # say L2458 bel
    old "Yeah... they were writing how thrilling it was."
    new "Ja... sie schrieben, wie aufregend es war."

    # say L2460 bel
    old "So many of them were even writing how hot it would be to see my mom fuck with us."
    new "So viele von ihnen haben sogar geschrieben, wie heiß es wäre, meine Mom mit uns ficken zu sehen."

    # say L2462 bel
    old "But leaving that aside, everything went better than I expected."
    new "Aber das mal beiseite, alles lief besser als ich gedacht hätte."

    # say L2464 bel
    old "Thanks a lot [pla], this wouldn't have been possible without you."
    new "Danke schön [pla], das wäre ohne dich nicht möglich gewesen."

    # say L2466 pla
    old "Don't even mention it, I'm happy I can help you."
    new "Mach dir nichts draus, ich freue mich, dir helfen zu können."

    # say L2467 pla
    old "I know how much this means to you."
    new "Ich weiß, wie wichtig das für dich ist."

    # say L2469 bel
    old "But even still, is not as if this is just nothing."
    new "Aber trotzdem, das ist nicht so, als ob es nichts wäre."

    # say L2471 bel
    old "After all, we're... Getting closer."
    new "Immerhin, wir werden... enger."

    # say L2473 pla
    old "Yeah... We are."
    new "Ja... Wir sind es."

    # say L2479 pla
    old "Well, I think I should leave for now."
    new "Na ja, ich denke, ich sollte jetzt gehen."

    # say L2481 bel
    old "Right, for sure! I think I better get dressed and call my mom before she goes crazy because I haven't talked to her."
    new "Stimmt, auf jeden Fall! Ich sollte mich besser anziehen und meiner Mum Bescheid sagen, bevor sie ausflippt, weil ich nicht mit ihr gesprochen habe."

    # say L2482 bel
    old "Once again [pla], thanks."
    new "Nochmal [pla], danke."

    # say L2483 bel
    old "You're doing so much for me, I can't thank you enough."
    new "Du tust so viel für mich, ich kann dir gar nicht genug danken."

    # say L2484 pla
    old "Don't worry, I'm just happy I can help you Belle, with anything you need."
    new "Mach dir keine Sorgen, ich freue mich einfach, dir zu helfen Belle, bei allem was du brauchst."

    # say L2485 pla
    old "I'll leave for now, see you later."
    new "Ich geh jetzt, bis später."

    # say L2507 pla
    old "Hi Ashley, I came to help you with the website."
    new "Hi Ashley, ich bin hier, um dir mit der Website zu helfen."

    # say L2508 ash
    old "Oh, is good that you're here I need your help with something right now."
    new "Oh, das ist gut, dass du da bist, ich brauche deine Hilfe bei etwas."

    # say L2510 ash
    old "Well, I was thinking about the design of the banners that we're making for the coffee shop."
    new "Na, ich habe über die Design der Banner nachgedacht, die wir für den Coffeeshop machen."

    # say L2511 ash
    old "And I remembered some banners that we had made before but never got around to releasing."
    new "Und ich hab an die Banner gedacht, die wir schon mal gemacht haben, aber nie veröffentlicht haben."

    # say L2512 ash
    old "I think we'll be able to reuse some of those ready-made designs to add them to the website."
    new "Ich denke, wir können einige dieser fertigen Designs wiederverwenden, um sie auf die Website zu bringen."

    # say L2513 ash
    old "I remembered that I saved those designs on an old flash drive, and I placed it up there on the shelves."
    new "Ich hab die Designs auf einem alten USB-Stick gespeichert und den hoch auf die Regale gestellt."

    # say L2514 ash
    old "But it's a bit too high for me to reach by myself without risking falling over."
    new "Aber es ist ein bisschen zu hoch für mich, um es allein zu erreichen, ohne Gefahr zu laufen, umzukippen."

    # say L2515 ash
    old "So, I need you to help me stay stable on the ladder while I look for it."
    new "Dann brauche ich deine Hilfe, um auf der Leiter sicher zu stehen, während ich danach suche."

    # say L2517 pla
    old "Uhh, s- sure, no problem."
    new "Uhh, s-sicher, kein Problem."

    # say L2518 ash
    old "Thank you, hun."
    new "Danke, Schatz."

    # say L2523 pla
    old "Are you okay there? Can you reach it?"
    new "Alles klar bei dir? Kannst du es erreichen?"

    # say L2524 ash
    old "Yeah, I'm close. Just a little more and I'll grab it."
    new "Ja, ich bin fast dran. Nur noch ein bisschen mehr und ich hab's."

    # say L2525 pla
    old "{i}(... Damn, I hadn't thought about it, but Ashley's really hot.){/i}"
    new "{i}(... Scheiße, ich hatte nicht dran gedacht, aber Ashley ist echt heiß.){/i}"

    # say L2529 pla
    old "{i}(I mean, just look at her ass...){/i}"
    new "{i}(Mann, schau dir ihren Hintern an...){/i}"

    # say L2533 pla
    old "Uh, yeah, yeah... Why do you ask?"
    new "Uh, ja, ja... Warum fragst du?"

    # say L2534 ash
    old "Well, you moved suddenly, so I was wondering if I made you lose your balance."
    new "Na ja, du bist plötzlich zusammengezuckt, da dachte ich, ich hab dich aus dem Gleichgewicht gebracht."

    # say L2535 pla
    old "No, no, Uhh, nothing happened, it's ok."
    new "Nein, nein, Uhh, nichts passiert, ist okay."

    # say L2536 ash
    old "Uh, ok... sure."
    new "Uh, okay... sicher."

    # say L2538 ash
    old "Ok, I think I've got them, I'm coming down."
    new "Ok, ich glaube, ich hab sie, ich komme runter."

    # say L2539 pla
    old "Oh, alright."
    new "Oh, okay."

    # say L2547 pla
    old "Ughh, damn, that was painful."
    new "Ughh, verdammt, das war schmerzhaft."

    # say L2548 pla
    old "{i}(Hmm? What is this? What do I have on my face?){/i}"
    new "{i}(Hm? Was ist das? Was habe ich im Gesicht?){/i}"

    # say L2549 pla
    old "{i}(Oh wow, it's Ashley's ass!){/i}"
    new "{i}(Ach wow, das ist Ashleys Hintern!){/i}"

    # say L2551 ash
    old "Ouch, that really hurt."
    new "Ouch, das hat echt wehgetan."

    # say L2555 ash
    old "{i}(Oh my gosh! H- He's got a boner!){/i}"
    new "{i}(O mein Gott! D- Da hat er aber einen Ständer!){/i}"

    # say L2556 pla
    old "Y- yeah, I- I am. I'm sorry, I think I was the one who slipped."
    new "Y- ja, ich bin. Es tut mir leid, ich glaube, ich war derjenige, der gestolpert ist."

    # say L2560 pla
    old "Uh... A- Ashley? Can you please move?"
    new "Uh... A- Ashley? Kannst du bitte weggehen?"

    # say L2561 ash
    old "Uh, I- I..."
    new "Uh, ich..."

    # say L2563 ash
    old "Is just that you have a..."
    new "Es ist nur, dass du da unten..."

    # say L2574 pla
    old "I- I uh... I'm sorry Ashley, it wasn't my intention..."
    new "I- ich, äh... Es tut mir leid Ashley, das war nicht meine Absicht..."

    # say L2575 pla
    old "I- its just that..."
    new "I- es ist nur so, dass..."

    # say L2576 ash
    old "It's fine, it's fine."
    new "Ist schon gut, ist schon gut."

    # say L2578 ash
    old "You're a young man after all. It's perfectly understandable that this happens."
    new "Du bist ja ein junger Mann, da ist das vollkommen normal, dass so was passiert."

    # say L2579 ash
    old "I fell on you and... M- my butt landed on your face..."
    new "Ich bin auf dich gefallen und... M- mein Po ist auf deinem Gesicht gelandet..."

    # say L2580 ash
    old "So, I think I understand that you would get a..."
    new "So, ich denke, ich verstehe, dass du da so reagierst..."

    # say L2598 pla
    old "Uhh... T- thank you... for understanding."
    new "Uhh... T- danke... dass du das verstehst."

    # say L2599 ash
    old "Hmm... Sure, i- it's very normal."
    new "Hmm... Klar, es ist total normal."

    # say L2604 pla
    old "Uhh, s- should we get to working on the website then?"
    new "Uhh, s- sollten wir dann mit der Website weitermachen?"

    # say L2606 ash
    old "I- I don't think that's a good idea right now [pla]."
    new "I- Ich glaube, das ist im Moment keine gute Idee [pla]."

    # say L2607 ash
    old "B- because I have to bring the banners to my team in the office, so they can use them to design the new ones."
    new "B- weil ich die Banner zu meinem Team ins Büro bringen muss, damit sie die neuen entwerfen können."

    # say L2609 pla
    old "Oh... Alright."
    new "Oh... Okay."

    # say L2611 pla
    old "I- I think I'll leave for now, see you later."
    new "I- Ich denke, ich geh jetzt, bis später."

    # say L2612 ash
    old "Y- yeah... S- see you later hon."
    new "Y- ja... B- bis später Schatz."

    # say L2618 ash
    old "Wow, he really has it very big c-... Now I understand why Belle likes him so much..."
    new "Wow, er hat es wirklich sehr groß c-... Jetzt verstehe ich, warum Belle ihn so mag..."

    # say L2638 pla
    old "Hey Belle, good morning, how are you?"
    new "Hey Belle, guten Morgen, wie geht’s dir?"

    # say L2640 bel
    old "To be honest, I'm quite upset..."
    new "Ehrlich gesagt, ich bin ziemlich sauer."

    # say L2641 pla
    old "Why? What happened now?"
    new "Warum? Was ist jetzt passiert?"

    # say L2643 bel
    old "Well, it's that bitch Lana."
    new "Na ja, diese Schlampe Lana."

    # say L2645 bel
    old "You won't believe what she pulled now!"
    new "Du wirst es nicht glauben, was sie jetzt wieder angestellt hat!"

    # say L2646 pla
    old "W- what? Why?!"
    new "W-was? Warum?!"

    # say L2647 pla
    old "I thought that you had surpassed her with what we did last time."
    new "Ich dachte, du hättest sie mit dem, was wir letztes Mal gemacht haben, schon überflügelt."

    # say L2649 bel
    old "And we did!"
    new "Und wir haben!"

    # say L2651 bel
    old "After our last streaming session I went up on the charts by a lot."
    new "Nach unserem letzten Streaming haben meine Charts echt gestiegen."

    # say L2653 bel
    old "So, I guess Lana felt desperate or something."
    new "Dann muss Lana wohl verzweifelt gewesen sein oder so."

    # say L2654 bel
    old "Because then she came out and did a threesome!"
    new "Denn dann kam sie raus und hat einen Dreier gemacht!"

    # say L2655 pla
    old "A threesome?"
    new "Eine Dreier?"

    # say L2657 bel
    old "Yeah, she just did it out of nowhere."
    new "Klar, sie hat es einfach so getan, aus heiterem Himmel."

    # say L2659 bel
    old "You know what really triggers me? She didn't even do it with another cam streamer or anything!"
    new "Du weißt was mich echt aufregt? Sie hat es nicht mal mit einem anderen Cam-Streamer gemacht oder so!"

    # say L2661 bel
    old "But of course she didn't, she doesn't know anybody in this business."
    new "Aber natürlich nicht, sie kennt niemanden in diesem Geschäft."

    # say L2663 bel
    old "I bet she just paid some amateur pornstar to do it with her, that whore!"
    new "Ich wette, sie hat einfach einen Amateur-Pornostar bezahlt, um es mit ihr zu tun, diese Schlampe!"

    # say L2664 pla
    old "OK, what is your plan then?"
    new "OK, was ist dann dein Plan?"

    # say L2666 bel
    old "What do you mean what is my plan? I'm going to answer her the same way of course?"
    new "Was meinst du mit was ist mein Plan? Ich werde ihr natürlich genauso antworten."

    # say L2667 pla
    old "Uhh, really? Are you sure?"
    new "Uhh, wirklich? Bist du dir sicher?"

    # say L2669 bel
    old "Of course I'm sure [pla], I've done too much to win this contest."
    new "Natürlich bin ich mir sicher [pla], ich habe zu viel investiert, um diesen Wettbewerb zu gewinnen."

    # say L2670 bel
    old "I've been working hard to get every vote I've received."
    new "Ich hab hart gearbeitet, um jede einzelne Stimme zu bekommen."

    # say L2671 bel
    old "I've augmented the number of times I stream weekly. I roped you into this."
    new "Ich habe die Anzahl meiner wöchentlichen Streams erhöht. Ich habe dich dazu überredet."

    # say L2673 bel
    old "I even let you fuck me in the ass!"
    new "Ich habe sogar zugelassen, dass du mich im Arsch fickst!"

    # say L2675 bel
    old "I've worked hard for this, and I'm not going to let some newcomer take it away."
    new "Ich hab hart dafür gearbeitet und ich lasse mir das nicht von irgendeinem Neuling wegnehmen."

    # say L2676 pla
    old "Well, I don't know what to tell you."
    new "Na ja, ich weiß auch nicht, was ich dir sagen soll."

    # say L2677 bel
    old "You don't have to say anything, all I need is for you to be willing to help me when I need it."
    new "Du musst nichts sagen, ich brauche nur, dass du bereit bist, mir zu helfen, wenn ich es brauche."

    # say L2679 pla
    old "Of course! You know I'll help you with anything I can."
    new "Natürlich! Du weißt, dass ich dir bei allem helfe, was ich kann."

    # say L2681 bel
    old "Thanks [pla], I'm glad I can count on you."
    new "Danke [pla], ich bin froh, dass ich mich auf dich verlassen kann."

    # say L2682 bel
    old "Also, I already have someone in mind who can help us with the threesome."
    new "Also, ich habe schon jemanden im Sinn, der uns bei dem Dreier helfen kann."

    # say L2683 bel
    old "I'll have to contact her and see when she would be available to arrange everything for the stream."
    new "Ich muss sie kontaktieren und sehen, wann sie verfügbar ist, um alles für den Stream zu organisieren."

    # say L2684 bel
    old "Meanwhile, you have to work with my mom the next time you come home, right?"
    new "Dann musst du beim nächsten Mal, wenn du nach Hause kommst, noch mit meiner Mom zusammenarbeiten, oder?"

    # say L2686 pla
    old "Uhh, yeah, we are still working on the website, there are still several things left to finish."
    new "Uhh, ja, wir arbeiten noch an der Website, da gibt’s noch einiges zu tun."

    # say L2688 bel
    old "Ok, so while you do that I'll talk with my friend and see if she can help us."
    new "Ok, dann rede ich mit meiner Freundin und sehe, ob sie uns helfen kann."

    # say L2689 bel
    old "I'll let you know as soon as we can do it."
    new "Ich lass es dich wissen, sobald wir es machen können."

    # say L2691 pla
    old "Uhh, alright."
    new "Uhh, okay."

    # say L2693 bel
    old "Great, then see you later [pla]."
    new "Super, dann bis später [pla]."

    # say L2695 pla
    old "See you Belle."
    new "Bis später, Belle."

    # say L2707 pla
    old "Well, I was thinking I could keep helping you develop the website."
    new "Na ja, ich dachte, ich könnte weiterhin dabei helfen, die Website zu entwickeln."

    # say L2708 ash
    old "Hmm... There might be a problem with that [pla]."
    new "Hmm... Da könnte ein Problem damit sein [pla]."

    # say L2709 pla
    old "Hmm, what is it?"
    new "Hmm, was ist los?"

    # say L2711 ash
    old "Well, my laptop isn't working right now."
    new "Na ja, mein Laptop funktioniert im Moment nicht."

    # say L2712 ash
    old "I was... Uh, u- using it the other day, looking for some... References."
    new "Ich war... Äh, v-vor ein paar Tagen damit beschäftigt, nach ein paar... Referenzen zu suchen."

    # say L2713 ash
    old "But it suddenly stopped working."
    new "Aber es hat plötzlich aufgehört zu funktionieren."

    # say L2715 ash
    old "I can turn it on now, it will even power up normally."
    new "Ich kann es jetzt anmachen, es startet sogar normal."

    # say L2716 ash
    old "But after that, it doesn't work."
    new "Aber danach funktioniert es nicht mehr."

    # say L2717 pla
    old "What do you mean? The screen just stays black?"
    new "Was meinst du? Der Bildschirm bleibt einfach schwarz?"

    # say L2718 ash
    old "No, it's not that. Once it's fully turned on, you simply can't do anything with it."
    new "Nein, so ist es nicht. Sobald es vollständig an ist, kannst du einfach nichts damit machen."

    # say L2720 ash
    old "If you click on something, multiple windows open up, and when you attempt to use the web browser, numerous tabs start to open up."
    new "Wenn du auf was klickst, öffnen sich mehrere Fenster, und wenn du versuchst, den Webbrowser zu benutzen, fangen eine Menge Tabs an, sich zu öffnen."

    # say L2721 ash
    old "And you can't close them down or do anything about it."
    new "Und du kannst sie nicht schließen oder dagegen tun."

    # say L2722 pla
    old "Hmm, that sounds like an adware."
    new "Hmm, das klingt nach Adware."

    # say L2724 pla
    old "But don't worry, I think I can fix it."
    new "Aber mach dir keine Sorgen, ich denke, ich kann das reparieren."

    # say L2727 pla
    old "Yeah, all I have to do is run an antivirus through it, and it should be completely fine."
    new "Klar, ich muss nur ein Antivirus-Programm drüberlaufen lassen, dann sollte alles wieder in Ordnung sein."

    # say L2728 ash
    old "That sounds great! Alright, let's do it."
    new "Das klingt super! Okay, dann machen wir das."

    # say L2743 ash
    old "There, that's what happens as soon as you try to use it."
    new "Da, das passiert, sobald du es benutzen willst."

    # say L2744 pla
    old "Hmm, yeah, I see what you mean."
    new "Hmm, ja, ich sehe, was du meinst."

    # say L2745 pla
    old "Yeah, this appears to be an adware virus. But don't worry, it can be easily fixed."
    new "Ja, das scheint ein Adware-Virus zu sein. Aber mach dir keine Sorgen, das lässt sich leicht beheben."

    # say L2746 pla
    old "I just have to run the antivirus, and it will take care of cleaning up all those annoying ads."
    new "Ich muss nur den Antivirus laufen lassen, und der kümmert sich um alle diese nervigen Anzeigen."

    # say L2747 pla
    old "It should start to work quickly."
    new "Es sollte schnell losgehen."

    # say L2754 pla
    old "See? It's already starting to work."
    new "Siehst du? Es fängt schon an zu funktionieren."

    # say L2760 pla
    old "Ok, now it's searching for viruses and malicious content."
    new "Ok, jetzt sucht es nach Viren und schädlichem Inhalt."

    # say L2761 pla
    old "As soon as it's done with the scanning, it will start deleting all the damaged files and threats to the system."
    new "Sobald es mit der Überprüfung fertig ist, wird es alle beschädigten Dateien und Bedrohungen des Systems löschen."

    # say L2762 ash
    old "Wow, you're very good with computers [pla]."
    new "Wow, du bist echt gut mit Computern [pla]."

    # say L2763 pla
    old "Well, it's not as difficult as it seems, heh."
    new "Na ja, es ist nicht so schwierig, wie es aussieht, heh."

    # say L2769 pla
    old "Ok, it's almost done, it shouldn't take much longer."
    new "Ok, es ist fast fertig, es sollte nicht mehr lange dauern."

    # say L2770 ash
    old "Wow, I didn't know it was so fast. I thought I would have to take it for maintenance and it would take days."
    new "Wow, ich wusste gar nicht, dass es so schnell geht. Ich dachte, ich müsste es zur Wartung bringen und es dauert Tage."

    # say L2777 pla
    old "Okay, we're done. The viruses that were affecting your computer should have been eliminated by now."
    new "Okay, wir sind fertig. Die Viren, die deinen Computer befallen haben, sollten jetzt beseitigt sein."

    # say L2778 ash
    old "Great, thank you!"
    new "Super, danke!"

    # say L2779 pla
    old "Just let me refresh it and we'll see..."
    new "Lass mich es nur noch aktualisieren und wir werden sehen..."

    # say L2786 pla
    old "Now, all of those ads and windows that it opened previously should start closing down."
    new "Jetzt sollten all die Werbeanzeigen und Fenster, die es vorher geöffnet hat, sich schließen."

    # say L2790 pla
    old "Oh! there's a webpage from your previous session."
    new "Oh! Da ist eine Webseite von deiner letzten Sitzung."

    # say L2791 pla
    old "Hmm, let's see, what does it say?"
    new "Hmm, lass mal sehen, was da steht."

    # say L2795 pla
    old "Sneaky Stepmom Fucks Step Daugther's Boyfri-..."
    new "Heimtückische Stiefmutter fickt Stieftochters Freund-..."

    # say L2797 ash
    old "Oh! T- that's..."
    new "Oh! D- das ist..."

    # say L2798 ash
    old "I- I Uh- I- I'm sorry [pla]! I don't know what that's doing in there."
    new "I- Ich Äh- I- Ich bin sorry [pla]! Ich hab keine Ahnung, was das da macht."

    # say L2799 ash
    old "M- maybe the virus s- send us to that website!"
    new "M- vielleicht hat der Virus u- uns auf diese Website geschickt!"

    # say L2800 pla
    old "Uhm... Yeah, that's probably what happened."
    new "Uhm... Ja, das wird es wohl gewesen sein."

    # say L2801 ash
    old "W- well, let's just close it. And keep checking if the pc is fine."
    new "W- wir sollten es einfach schließen. Und weiter überprüfen, ob der PC in Ordnung ist."

    # say L2809 pla
    old "Okay, I think the computer is good to go."
    new "Okay, ich denke, der Computer ist wieder fit."

    # say L2810 pla
    old "Now it shouldn't be a problem to continue with the work."
    new "Dann sollte es jetzt kein Problem mehr sein, mit der Arbeit weiterzumachen."

    # say L2812 ash
    old "Ohh, t- thank you [pla]."
    new "Ohh, d- danke [pla]."

    # say L2813 ash
    old "I- It's great that you managed to get it working again."
    new "I- Es ist toll, dass du es wieder zum Laufen gebracht hast."

    # say L2816 ash
    old "And I'm sorry about that website that you saw."
    new "Und es tut mir leid wegen dieser Website, die du gesehen hast."

    # say L2817 ash
    old "I don't know how that got in there."
    new "Ich hab keine Ahnung, wie das da reingekommen ist."

    # say L2819 pla
    old "Uhh sure... I'm just glad I can be of help."
    new "Uhh klar... Ich bin einfach froh, dass ich helfen kann."

    # say L2821 ash
    old "That's very nice of you."
    new "Das ist sehr nett von dir."

    # say L2827 ash
    old "Uhh, I guess we should continue working, right?"
    new "Uhh, ich denke, wir sollten weiterarbeiten, oder?"

    # say L2828 pla
    old "Oh, sure, we should get to that."
    new "Oh, klar, wir sollten uns daran machen."

    # say L2887 pla
    old "Hey Belle, how are you?"
    new "Hey Belle, wie geht's dir?"

    # say L2888 bel
    old "Actually, I'm doing great, you know? I have very good news!"
    new "Eigentlich geht es mir super, weißt du? Ich habe richtig gute Neuigkeiten!"

    # say L2891 bel
    old "Remember what I told you before? What we needed to do for the next stream?"
    new "Erinnerst du dich, was ich dir vorher gesagt habe? Was wir für den nächsten Stream machen mussten?"

    # say L2893 pla
    old "Uhh, yeah, I do."
    new "Uhh, ja, tu ich."

    # say L2895 bel
    old "Well, I got the girl we needed for the stream!"
    new "Na, ich hab die Frau für den Stream gefunden, die wir brauchten!"

    # say L2897 pla
    old "T- that's great."
    new "Das ist ja toll."

    # say L2898 bel
    old "Yeah, she's an amazing streamer."
    new "Ja, sie ist eine tolle Streamerin."

    # say L2899 bel
    old "So, get ready because today we're going to do the stream!"
    new "Dann mach dich bereit, denn heute machen wir den Stream!"

    # say L2901 pla
    old "A- alright, so, are we going to your house after class ends?"
    new "A- okay, dann fahren wir nach der Schule zu dir?"

    # say L2903 bel
    old "Uhh, actually, I will skip classes today."
    new "Uhh, eigentlich werde ich heute die Schule schwänzen."

    # say L2905 bel
    old "I have to go to the girl's house now to pick her up and take her to my house."
    new "Ich muss jetzt zu dem Mädchen rüberfahren, sie abholen und zu mir nach Hause bringen."

    # say L2906 bel
    old "And then I'll set up the stream and make sure that everything's ready."
    new "Und dann stelle ich den Stream ein und sorge dafür, dass alles bereit ist."

    # say L2909 bel
    old "So, don't worry, you go to class and we'll meet at my house when you're done."
    new "Keine Sorge, du gehst zu deinem Unterricht und wir treffen uns bei mir, wenn du fertig bist."

    # say L2914 bel
    old "You'll see, with this, I will definitely surpass Lana in the rankings for good."
    new "Du wirst sehen, mit dem werde ich Lana definitiv in den Rankings überholen."

    # say L2917 bel
    old "Thanks, [pla]. Now, I'll leave, and we'll meet at my house in the afternoon."
    new "Danke, [pla]. Jetzt geh ich, und wir sehen uns später bei mir."

    # say L2938 pla
    old "Ok, I guess  I'll go to Belle's house now."
    new "Okay, dann gehe ich jetzt zu Belles Haus."

    # say L2939 pla
    old "That's weird, I'm going to Belle's house to have a... Threesome, and with a girl I don't know..."
    new "Das ist seltsam, ich gehe zu Belles Haus, um eine... Dreiersonenszene zu haben, und mit einem Mädchen, das ich nicht kenne..."

    # say L2940 pla
    old "This definitely escalated quickly..."
    new "Das hat sich ja schnell aufgeheizt..."

    # say L2941 pla
    old "Well, anyway, I better go quickly. I don't want to be late for Belle's stream.."
    new "Na ja, egal, ich muss schnell los. Ich will nicht zu Belles Stream zu spät kommen."

    # say L2958 bel
    old "Hi [pla], thanks for coming."
    new "Hi [pla], danke dass du gekommen bist."

    # say L2959 bel
    old "So, this is my friend Amorette, she will be joining us for today's stream."
    new "Das ist meine Freundin Amorette, sie wird uns heute beim Stream Gesellschaft leisten."

    # say L2962 amo
    old "Hi! Nice meeting you!"
    new "Hi! Schön, dich kennenzulernen!"

    # say L2964 amo
    old "So this is the guy you've been streaming with lately, Belle!"
    new "Dann ist das also der Typ, mit dem du neuerdings streamst, Belle!"

    # say L2965 amo
    old "I can't believe I'm actually meeting you! You know, I'm a big fan of yours."
    new "Ich kann es nicht glauben, dass ich dich tatsächlich treffe! Du weißt schon, ich bin ein großer Fan von dir."

    # say L2966 pla
    old "My fan? Really?"
    new "Mein Fan? Wirklich?"

    # say L2968 amo
    old "Of course I follow Belle's stream because she's one of the best-ranked streamers."
    new "Natürlich folge ich Belles Stream, weil sie eine der besten Streamerinnen ist."

    # say L2970 amo
    old "And lately her content has been great, especially the one she's doing with you."
    new "Und lately ist ihr Content echt toll geworden, besonders das, was sie mit dir macht."

    # say L2971 amo
    old "So, I'm also a fan of yours."
    new "Dann bin ich auch ein Fan von dir."

    # say L2974 amo
    old "But how couldn't I be? After all, you have that amazing cannon in between your legs."
    new "Aber wie könnte ich nicht? Schließlich hast du diesen unglaublichen Kanonen zwischen den Beinen."

    # say L2976 amo
    old "With how long and thick it is... I know my views would skyrocket if I ever have you in one of my streams."
    new "Mit der Länge und dem Dickicht... Ich weiß, meine Zuschauerzahlen würden explodieren, wenn ich dich jemals in einem meiner Streams hätte."

    # say L2977 pla
    old "I- Uh- Well... I- I don't know what to say..."
    new "I- Äh- Na ja... I- Ich weiß nicht, was ich sagen soll..."

    # say L2979 amo
    old "Oh! Look at that reaction! It's so cute, hahaha."
    new "Oh! Schau dir diese Reaktion an! Das ist so süß, hahaha."

    # say L2985 bel
    old "Ok guys, everything's already set up, so we're ready to go."
    new "Ok Leute, alles ist schon vorbereitet, wir können loslegen."

    # say L2986 bel
    old "At first I'll be alone on camera, I'll introduce you and then you can come in Amorette."
    new "Zuerst bin ich allein im Bild, ich stelle dich vor und dann kannst du reinkommen Amorette."

    # say L2987 bel
    old "After that I'll bring you in [pla], and we can get started."
    new "Danach bringe ich euch rein [pla] und dann können wir anfangen."

    # say L2992 bel
    old "Great, then let's do it."
    new "Super, dann machen wir's so."

    # say L3009 bel
    old "Hey guys! It's great to see you all again!"
    new "Hey Leute! Es ist toll, euch alle wiederzusehen!"

    # say L3010 bel
    old "I've been waiting for today's show more than ever!"
    new "Ich habe mich auf die Show heute mehr als je gefreut!"

    # say L3011 bel
    old "Because I have yet another great surprise for you guys!"
    new "Denn ich habe noch eine tolle Überraschung für euch!"

    # say L3012 bel
    old "This is something you have been asking me about! And it's finally time for you guys to enjoy it."
    new "Das ist etwas, nach dem ihr mich schon lange gefragt habt! Und heute ist endlich der Tag, an dem ihr es genießen dürft."

    # say L3013 bel
    old "So, today I have with me a friend that's going to help us."
    new "Also, heute habe ich eine Freundin dabei, die uns helfen wird."

    # say L3014 bel
    old "I know you all know her because she's very popular, so please give a warm welcome to my friend Amorette!"
    new "Ich weiß, dass ihr sie alle kennt, weil sie sehr beliebt ist, also gebt ihr bitte einen warmen Willkommensapplaus für meine Freundin Amorette!"

    # say L3019 amo
    old "Hi guys! How are you?!"
    new "Hi Leute! Wie geht's euch?!"

    # say L3020 amo
    old "It's so nice to be here!"
    new "Es ist so schön hier zu sein!"

    # say L3021 amo
    old "Oh, some of you know me from my stream?"
    new "Oh, einige von euch kennen mich vielleicht aus meinem Stream?"

    # say L3022 amo
    old "It's great to see you!"
    new "Schön, dich zu sehen!"

    # say L3023 amo
    old "I hope we'll have a very good time together today guys!"
    new "Ich hoffe, wir werden heute zusammen eine tolle Zeit haben, Leute!"

    # say L3025 bel
    old "And of course, my friend from before is also here to help us!"
    new "Und natürlich ist auch mein Freund von vorhin hier, um uns zu helfen!"

    # say L3030 bel
    old "Well guys, it's time for me to tell you about the surprise I'd planned for you."
    new "Na Leute, es ist Zeit, euch von der Überraschung zu erzählen, die ich für euch geplant habe."

    # say L3032 bel
    old "And it's that today we're having a threesome!"
    new "Und es ist, dass wir heute eine Dreier haben!"

    # say L3034 bel
    old "It's great right?"
    new "Das ist toll, oder?"

    # say L3037 bel
    old "Oh! We've all been waiting for this! Let's not delay it anymore!"
    new "Oh! Wir haben alle darauf gewartet! Lass uns nicht länger warten!"

    # say L3038 bel
    old "So, remember to tip so that we can reach the goal!"
    new "Also, denkt dran zu tippen, damit wir das Ziel erreichen!"

    # say L3045 amo
    old "Oh wow, just look at that dick guys!"
    new "Oh wow, schaut euch das an, Leute!"

    # say L3046 amo
    old "I saw it before on screen, but it's so much bigger in person!"
    new "Ich hab's schon auf dem Bildschirm gesehen, aber in echt ist es viel größer!"

    # say L3047 bel
    old "It's great isn't it?"
    new "Es ist toll, oder?"

    # say L3064 bel
    old "Thanks guys, you are the best fans in the world!"
    new "Danke Jungs, ihr seid die besten Fans der Welt!"

    # say L3065 bel
    old "I'm very happy and proud of you!"
    new "Ich bin sehr glücklich und stolz auf euch!"

    # say L3066 bel
    old "I hope you enjoyed this threesome as much as we did."
    new "Ich hoffe, euch hat dieser Dreier genauso gefallen wie uns."

    # say L3068 amo
    old "Belle is right guys!"
    new "Belle hat recht, Leute!"

    # say L3069 amo
    old "That was so hot!"
    new "Das war so heiß!"

    # say L3072 amo
    old "You guys have been so nice!"
    new "Ihr seid alle so nett!"

    # say L3074 amo
    old "It makes me think of coming back to stream with Belle again..."
    new "Das macht mich nachdenken, wieder mit Belle zu streamen..."

    # say L3076 bel
    old "I know if Amorette comes back to stream with us, we will all enjoy it!"
    new "Ich weiß, wenn Amorette wieder mit uns streamt, werden wir alle es genießen!"

    # say L3078 bel
    old "And of course, my friend here will be back as well!"
    new "Und natürlich wird meine Freundin hier auch wieder dabei sein!"

    # say L3080 bel
    old "Well, guys, that's all for today."
    new "Na, Leute, das war's für heute."

    # say L3081 bel
    old "Remember to subscribe to my profile and follow me on my social networks!"
    new "Denkt daran, euch meinem Profil zu abonnieren und mir auf meinen Social Media zu folgen!"

    # say L3082 bel
    old "And remember to follow Amorette as well."
    new "Und vergesst nicht, Amorette zu folgen."

    # say L3083 bel
    old "She does some amazing things in her stream guys!"
    new "Sie macht echt unglaubliche Dinge in ihrem Stream, Leute!"

    # say L3085 amo
    old "Thanks for the warm reception guys!"
    new "Danke für die warme Begrüßung Leute!"

    # say L3086 amo
    old "And thank you for having me Belle."
    new "Und danke dir, dass du mich eingeladen hast, Belle."

    # say L3087 amo
    old "See you later guys!"
    new "Bis später, Leute!"

    # say L3088 bel
    old "Bye guys!"
    new "Tschüss Jungs!"

    # say L3107 bel
    old "They really reached the goal in no time!"
    new "Sie haben das Ziel echt in null Komma nichts erreicht!"

    # say L3108 bel
    old "Thanks a lot guys! I'm amazed it all went this well. And it's all thanks to you!"
    new "Danke euch allen! Ich bin total baff, wie gut das alles geklappt hat. Und das habt ihr alles zu verdanken!"

    # say L3109 amo
    old "You're welcome Belle."
    new "Gern geschehen Belle."

    # say L3110 amo
    old "I'm very happy to help, and this is also good for my own stream."
    new "Ich freue mich sehr, zu helfen, und das ist auch gut für meinen eigenen Stream."

    # say L3111 amo
    old "It's great that you managed to reach the goal."
    new "Es ist toll, dass du das Ziel erreicht hast."

    # say L3112 amo
    old "And I love that I was able to meet you [pla]."
    new "Und ich liebe es, dass ich dich treffen konnte [pla]."

    # say L3113 amo
    old "You definitely have to come to do one of my streams with me one of these days."
    new "Du musst definitiv mal bei einem meiner Streams mitmachen, das wird bestimmt toll."

    # say L3114 amo
    old "Just you and me, I'm sure you'll enjoy it."
    new "Nur du und ich, ich bin sicher, dir wird es gefallen."

    # say L3115 pla
    old "Uhh... Sure."
    new "Uhh... Klar."

    # say L3116 bel
    old "Ok, that's great."
    new "Okay, das ist toll."

    # say L3117 bel
    old "Guys, my mom's coming home soon."
    new "Leute, meine Mom kommt bald nach Hause."

    # say L3118 bel
    old "So it would be better if you go."
    new "Dann wäre es besser, wenn du gehst."

    # say L3121 amo
    old "Thanks again for having me Belle."
    new "Danke nochmal, dass ich hier war, Belle."

    # say L3122 amo
    old "I'll see you later."
    new "Dann sehen wir uns später."

    # say L3123 bel
    old "Sure, thanks for helping me."
    new "Klar, danke für deine Hilfe."

    # say L3131 pla
    old "I guess I'll see you later then."
    new "Dann sehen wir uns später."

    # say L3132 bel
    old "Of course, thank you, [pla]."
    new "Natürlich, danke, [pla]."

    # say L3133 bel
    old "I'm sure that with this, I can surpass Lana in the voting."
    new "Ich bin sicher, dass ich damit Lana in der Abstimmung übertrumpfen kann."

    # say L3134 bel
    old "And it's all because of you."
    new "Und das alles deinetwegen."

    # say L3135 pla
    old "Don't mention it, I know you've worked hard for it, so you deserve to win it."
    new "Mach dir nichts draus, ich weiß, dass du hart dafür gearbeitet hast, deshalb verdienst du es zu gewinnen."

    # say L3136 pla
    old "And I'm sure you will."
    new "Und ich bin sicher, dass du es wirst."

    # say L3137 bel
    old "Thank you so much, [pla]!"
    new "Danke schön, [pla]!"

    # say L3138 pla
    old "Alright, I'll get going then. See you later."
    new "Okay, dann mach ich mich auf den Weg. Bis später."

    # say L3154 pla
    old "Ok! I think I managed to finish it all."
    new "Ok! Ich glaube, ich hab alles geschafft."

    # say L3156 ash
    old "That's great [pla]!"
    new "Das ist super [pla]!"

    # say L3157 ash
    old "Can you show me?"
    new "Kannst du es mir zeigen?"

    # say L3161 pla
    old "Here, this is the homepage, in here I just left information about the business."
    new "Hier, das ist die Startseite, hier habe ich nur Informationen über das Geschäft gelassen."

    # say L3162 pla
    old "Their history and stuff."
    new "Ihre Geschichte und so."

    # say L3164 pla
    old "If you press here it will take you to the menu."
    new "Wenn du hier draufdrückst, kommst du zum Menü."

    # say L3166 pla
    old "If you wish to make an order to pick up in advance, you can place it here."
    new "Wenn du möchtest, kannst du hier eine Vorausbestellung aufgeben."

    # say L3167 pla
    old "There's also an option for you to customize your order."
    new "Du kannst auch deine Bestellung anpassen."

    # say L3168 ash
    old "Oh! I see!"
    new "Oh! Das sehe ich!"

    # say L3170 pla
    old "Yeah, you can even select the coffee by level of roasting."
    new "Ja, du kannst sogar die Röststufe des Kaffees auswählen."

    # say L3171 pla
    old "Or you can even select the region where it comes from."
    new "Oder du kannst sogar die Region auswählen, von der es stammt."

    # say L3173 ash
    old "This is really good work [pla]."
    new "Das ist wirklich gute Arbeit [pla]."

    # say L3174 ash
    old "This is better than what I have seen some professional web developers do."
    new "Das ist besser als das, was ich von manchen professionellen Webentwicklern gesehen habe."

    # say L3176 ash
    old "I know you're not looking for a job right now."
    new "Ich weiß, dass du gerade keine Arbeit suchst."

    # say L3177 ash
    old "Because you have to do things with school and stuff."
    new "Weil du ja noch mit der Schule und so zu tun hast."

    # say L3179 ash
    old "But if you ever want to get into web developing, just let me know."
    new "Aber wenn du mal in die Webentwicklung einsteigen willst, lass es mich wissen."

    # say L3180 ash
    old "I'm sure I'll be able to get you something good."
    new "Ich bin sicher, ich krieg was Gutes für dich."

    # say L3182 ash
    old "Also, if I ever need your help, I'll let you know."
    new "Also, wenn ich mal deine Hilfe brauche, lass ich es dich wissen."

    # say L3184 ash
    old "Maybe you can give me a hand with something."
    new "Vielleicht kannst du mir ja mal bei was helfen."

    # say L3185 pla
    old "For sure! If I can help you with anything, just tell me, I'll do my best to help you any time I can."
    new "Klar! Wenn ich dir bei was helfen kann, sag Bescheid, ich werd' mein Bestes tun, wann immer ich kann."

    # say L3191 pla
    old "I guess I'll leave for now Ashley. But I guess I'll see you later."
    new "Ich schätze, ich geh dann mal, Ashley. Aber wir sehen uns später."

    # say L3196 ash
    old "Wait [pla]."
    new "Warte [pla]."

    # say L3198 pla
    old "Yes ma'am?"
    new "Ja, Ma'am?"

    # say L3199 ash
    old "Before you leave, I just wanted to take a second to thank you for all the help you've given me these days."
    new "Bevor du gehst, wollte ich dir noch schnell danken für die Hilfe, die du mir in den letzten Tagen gegeben hast."

    # say L3201 ash
    old "I was in a very difficult situation, and with your help, I was able to solve it even better than I expected."
    new "Ich war in einer sehr schwierigen Situation, und mit deiner Hilfe konnte ich sie sogar besser lösen, als ich erwartet hatte."

    # say L3202 pla
    old "I just wanted to help you, I'm happy I was able to do something."
    new "Ich wollte dir nur helfen, ich freue mich, dass ich etwas tun konnte."

    # say L3203 ash
    old "And you really did, you're welcome here at our home any time you need."
    new "Und das hast du wirklich, du bist jederzeit bei uns zu Hause willkommen."

    # say L3205 ash
    old "So thanks again [pla], I hope I'll see you again soon."
    new "Dann danke nochmal [pla], ich hoffe, wir sehen uns bald wieder."

    # say L3207 pla
    old "Sure ma'am, I'm sure we'll see each other soon."
    new "Klar, ich bin sicher, wir sehen uns bald."

    # say L3208 pla
    old "Bye for now then."
    new "Bis dann."

    # say L3209 ash
    old "Bye [pla]."
    new "Tschüss [pla]."

    # say L3230 pla
    old "Why do you look so down?"
    new "Warum siehst du so niedergeschlagen aus?"

    # say L3232 bel
    old "Nothing bad, I'm just a little nervous."
    new "Nichts Schlimmes, ich bin nur ein bisschen nervös."

    # say L3236 bel
    old "Well, the results of the voting are coming out today."
    new "Na ja, die Ergebnisse der Abstimmung kommen heute raus."

    # say L3238 pla
    old "Already? It didn't take any time."
    new "Schon? Das ging ja schnell."

    # say L3240 bel
    old "The contest was a bit longer. It's just that when we started streaming, we were already close to the deadline."
    new "Das Wettbewerbs war ein bisschen länger. Es ist nur so, dass als wir anfingen zu streamen, waren wir schon fast am Ende."

    # say L3242 pla
    old "Well, I hope that all the streaming we did helped you win."
    new "Na, ich hoffe, dass das Streamen uns geholfen hat zu gewinnen."

    # say L3244 bel
    old "I don't know, I checked the voting before I went out today. Me and Lana were neck and neck."
    new "Ich weiß nicht, ich hab die Abstimmung heute Morgen noch mal überprüft. Lana und ich lagen Kopf an Kopf."

    # say L3245 bel
    old "I haven't seen anything else, I'll check it as soon as I get home."
    new "Ich hab nichts anderes gesehen, ich check es, sobald ich zu Hause bin."

    # say L3246 bel
    old "So, I wanted to know if you want to accompany me this afternoon to check the results."
    new "Dann wollte ich wissen, ob du mich heute Nachmittag begleiten willst, um die Ergebnisse zu überprüfen."

    # say L3248 pla
    old "Sure, I'll come with you."
    new "Klar, ich komme mit dir."

    # say L3249 bel
    old "Thank you [pla]. We can go to my house right after classes and check it."
    new "Danke [pla]. Wir können direkt nach den Kursen zu mir nach Hause gehen und sie überprüfen."

    # say L3250 pla
    old "For sure, let's go to class for now, and I'll come to your house with you when we're done."
    new "Klar, lass uns erst mal in die Klasse gehen und danach komme ich mit zu dir."

    # say L3281 bel
    old "I can't wait to see the results, but I'm also so nervous!"
    new "Ich freue mich schon darauf, die Ergebnisse zu sehen, aber ich bin auch total nervös!"

    # say L3282 pla
    old "Don't worry, everything will be fine. Let's get going so we can see the results at your place."
    new "Mach dir keine Sorgen, alles wird gut. Lass uns losgehen, damit wir die Ergebnisse bei dir sehen können."

    # say L3283 bel
    old "Yes, yes, you're right... Let's go. I'll feel calmer there."
    new "Ja, ja, du hast recht... Lass uns gehen. Da werde ich ruhiger."

    # say L3296 bel
    old "Ok, let's check how this all turned out."
    new "Ok, lass uns schauen, wie das alles ausgegangen ist."

    # say L3302 pla
    old "You did?!"
    new "Du hast?"

    # say L3303 pla
    old "That's great Belle! Congrats!"
    new "Das ist toll Belle! Herzlichen Glückwunsch!"

    # say L3305 bel
    old "Thank you so much [pla]!"
    new "Danke dir soooo viel [pla]!"

    # say L3307 bel
    old "This is all thanks to you!"
    new "Das ist alles deinetwegen!"

    # say L3308 pla
    old "What?! This is all because of you! You're the one that has been doing all the hard work."
    new "Was?! Das ist alles deinetwegen! Du bist diejenige, die all die harte Arbeit geleistet hat."

    # say L3309 pla
    old "Really Belle, congrats, you deserve this."
    new "Na komm, Belle, gratuliere, du hast es verdient."

    # say L3311 bel
    old "Well, it was impossible without you."
    new "Na klar, ohne dich wäre das unmöglich gewesen."

    # say L3312 bel
    old "I have no way of repaying you [pla], this is just so great."
    new "Ich habe keine Möglichkeit, dir das zurückzuzahlen [pla], das ist einfach unglaublich."

    # say L3314 pla
    old "Really Belle, congratulations, you deserve that victory. And I'm happy I was able to help you. It makes me very happy."
    new "Wirklich Belle, Glückwunsch, du hast diesen Sieg verdient. Und ich freue mich, dass ich dir helfen konnte. Das macht mich sehr glücklich."

    # say L3329 bel
    old "What do you mean by 'what's going on here?' And why are you barging into my room as if it's yours?"
    new "Was meinst du mit „was ist hier los?“ Und warum stürmst du mein Zimmer, als wäre es deins?"

    # say L3335 ash
    old "What the hell is happening?!"
    new "Was zur Hölle geht hier ab?!"

    # say L3337 bel
    old "Woah, woah, woah, where did you get that from?!"
    new "Woah, woah, woah, woher hast du das?"

    # say L3340 ash
    old "A coworker showed it to me! He caught his son using his credit card to send money to you on this website."
    new "Ein Kollege hat es mir gezeigt! Er hat seinen Sohn dabei erwischt, wie er sein Geld auf dieser Website an dich geschickt hat."

    # say L3342 ash
    old "He recognized you and decided to ask me if this was you!"
    new "Er hat dich erkannt und beschlossen, mich zu fragen, ob das wirklich du bist!"

    # say L3344 ash
    old "Oh my gosh Belle! What the hell are you doing?"
    new "Oh mein Gott Belle! Was zur Hölle machst du da?"

    # say L3346 ash
    old "Why are you asking for money from strangers on the internet?"
    new "Warum fragst du Fremde im Internet um Geld?"

    # say L3348 ash
    old "If you needed money you could've told me!"
    new "Wenn du Geld gebraucht hättest, hättest du es mir sagen können!"

    # say L3350 ash
    old "And doing it this way! Oh my god!"
    new "Und so zu machen! Oh mein Gott!"

    # say L3352 bel
    old "Wait a minute, what do you mean by {i}'doing it this way{/i}'?"
    new "Warte mal, was meinst du mit {i}'doing it this way{/i}'?"

    # say L3354 bel
    old "First of all, I'll let you know I'm not doing it for the money!"
    new "Erstens, lass mich dir sagen, ich mache das nicht wegen dem Geld!"

    # say L3357 bel
    old "I'm doing it because I like it."
    new "Ich mache es, weil ich es mag."

    # say L3360 bel
    old "But even if I was doing it for money. What's wrong with me doing something like that?"
    new "Aber selbst wenn ich es für Geld machen würde. Was ist daran falsch, so etwas zu tun?"

    # say L3362 bel
    old "You're the one who's always telling me that I should just live my sexuality any way I can."
    new "Du bist diejenige, die mir immer sagt, dass ich meine Sexualität so ausleben soll, wie ich will."

    # say L3364 bel
    old "And that I shouldn't care about what people have to say about me."
    new "Und dass ich mir nicht um das kümmern sollte, was die Leute über mich sagen."

    # say L3367 ash
    old "That isn't the problem here!"
    new "Das ist hier nicht das Problem!"

    # say L3369 ash
    old "You know that I'm just taking over my new role in the company!"
    new "Du weißt doch, dass ich nur meine neue Rolle im Unternehmen übernehme!"

    # say L3371 ash
    old "Imagine how I felt when my coworker told me his son is stealing money from him to give to my daughter for being naked online!"
    new "Stell dir vor, wie ich mich gefühlt habe, als mein Kollege mir erzählt hat, dass sein Sohn ihm Geld stiehlt, um es meiner Tochter zu geben, damit sie sich online auszieht!"

    # say L3372 ash
    old "This could bring problems to my image as the branch director of the company. The executives could fire me!"
    new "Das könnte mein Image als Abteilungsleiterin des Unternehmens ruinieren. Die Vorstände könnten mich feuern!"

    # say L3374 bel
    old "And what do you want me to do? To not do it just because those assholes at your job might think bad about it?"
    new "Und was willst du von mir? Dass ich es nicht mache, nur weil die Arschlöcher bei deinem Job schlecht über dich denken?"

    # say L3377 bel
    old "I'm sorry but I'm not doing that."
    new "Tut mir leid, aber ich mach das nicht."

    # say L3379 ash
    old "Oh my gosh could you be any more selfish?!"
    new "Oh mein Gott, kannst du noch egoistischer sein?!"

    # say L3380 pla
    old "Ok, ok, why don't you two try to talk about this in a calmer way?"
    new "Okay, okay, warum versucht ihr zwei das nicht etwas ruhiger zu besprechen?"

    # say L3381 pla
    old "Before either of you says anything that you may regret."
    new "Bevor einer von euch etwas sagt, das ihr später bereuen könnt."

    # say L3385 ash
    old "I was thinking about who's the person in the video with Belle! It's you isn't it?"
    new "Ich hab drüber nachgedacht, wer der Typ im Video mit Belle ist! Bist du das, oder?"

    # say L3387 ash
    old "I'm so stupid!"
    new "Ich bin so dumm!"

    # say L3389 ash
    old "Here I was thinking that you were just a good friend of Belle!"
    new "Hier dachte ich, du wärst nur eine gute Freundin von Belle!"

    # say L3390 ash
    old "Someone whom I could trust, and here doing this!"
    new "Jemandem, dem ich vertrauen konnte, und jetzt das hier!"

    # say L3391 ash
    old "And in my house, of all places!"
    new "Und in meinem Haus, ausgerechnet!"

    # say L3393 bel
    old "Wait a minute! Don't involve him in this!"
    new "Warte mal! Lass ihn da raus!"

    # say L3394 bel
    old "He was just helping me, and it's something that I wanted to do and there's nothing wrong with it!"
    new "Er hat mir nur geholfen, und es ist etwas, das ich machen wollte, und daran ist nichts auszusetzen!"

    # say L3396 ash
    old "Oh yeah? Well, I'm sorry you want to do it so badly because you're about to stop!"
    new "Oh ja? Tut mir leid, dass du es so sehr willst, aber du wirst gleich aufhören müssen!"

    # say L3397 ash
    old "I already told you, the people at my company are not okay with this!"
    new "Ich hab dir schon gesagt, die Leute in meiner Firma sind damit nicht einverstanden!"

    # say L3399 ash
    old "So, unless whatever money you're making with that is enough for you to pay for everything around here!"
    new "Dann hoffe ich mal, dass das Geld, das du damit verdienst, reicht, um hier alles zu bezahlen!"

    # say L3400 ash
    old "You're about to stop with this weird little hobby of yours!"
    new "Du wirst dieses seltsame Hobby jetzt aufgeben!"

    # say L3402 bel
    old "You have to be kidding me!"
    new "Du musst mich wohl verarschen!"

    # say L3403 bel
    old "Well I'm sorry, but I'm not going to stop doing anything! And if you don't like me doing it in your house then I guess I can leave!"
    new "Dann tut mir leid, aber ich werde nichts aufgeben! Und wenn dir nicht gefällt, was ich in deinem Haus mache, dann kann ich ja gehen!"

    # say L3405 ash
    old "Then I guess you can!"
    new "Dann tu es doch!"

    # say L3407 bel
    old "I'll do it then!"
    new "Dann mach ich es eben!"

    # say L3415 pla
    old "Wait! Belle!"
    new "Warte! Belle!"

    # say L3419 pla
    old "I- uh..."
    new "Ich- äh..."

    # say L3420 pla
    old "I- I'm sorry!"
    new "Ich- Es tut mir leid!"

    # say L3445 bel
    old "Hey, I guess I'm doing ok."
    new "Hey, ich denke, ich komme ziemlich gut klar."

    # say L3447 bel
    old "I left my mom's house, so at least she's not annoying me or anything."
    new "Ich bin aus dem Haus meiner Mom ausgezogen, also nervt sie mich zumindest nicht mehr."

    # say L3448 pla
    old "W- what? You actually left your home?"
    new "W-was? Du hast dein Zuhause tatsächlich verlassen?"

    # say L3450 bel
    old "I did, what else was I supposed to do?"
    new "Ich hab's getan, was sollte ich sonst machen?"

    # say L3451 bel
    old "I'm not going to stop streaming just to give her the pleasure."
    new "Ich werde nicht aufhören zu streamen, nur um ihr die Freude zu machen."

    # say L3452 bel
    old "This is too important for me, no matter what she says."
    new "Das ist zu wichtig für mich, egal was sie sagt."

    # say L3454 pla
    old "I see, I'm sorry Belle; I feel like I caused this."
    new "Ich verstehe, es tut mir leid Belle; ich fühle mich schuldig."

    # say L3455 bel
    old "Don't worry, this isn't your fault. It was bound to happen sooner or later."
    new "Mach dir keine Sorgen, das ist nicht deine Schuld. Es war früher oder später sowieso passieren."

    # say L3456 pla
    old "I guess."
    new "Ist ja gut."

    # say L3457 pla
    old "So, where are you staying now?"
    new "Und, wo bleibst du jetzt?"

    # say L3459 bel
    old "I'm staying at Amorette's apartment."
    new "Ich wohne in Amorettes Wohnung."

    # say L3460 bel
    old "It's really nice because she has an entire room where we can stream."
    new "Es ist echt toll, weil sie ein ganzes Zimmer hat, wo wir streamen können."

    # say L3461 bel
    old "By the way, she says that you're welcome to come to visit anytime you want."
    new "Übrigens, sie sagt, dass du jederzeit zu Besuch kommen darfst."

    # say L3462 pla
    old "I see... Well, thank you I guess."
    new "Ich sehe... Na ja, danke schätze ich."

    # say L3463 pla
    old "Leaving aside her offer."
    new "Abgesehen von ihrem Angebot."

    # say L3465 pla
    old "I hope things will be fixed between you and your mom soon."
    new "Ich hoffe, es wird zwischen dir und deiner Mom bald besser."

    # say L3467 bel
    old "Thanks... But I wouldn't count on it."
    new "Danke... Aber ich würde nicht darauf wetten."

    # say L3468 bel
    old "Listen, I have a couple of things to do now, so I'll see you later, ok?"
    new "Hör zu, ich hab noch ein paar Dinge zu erledigen, also sehen wir uns später, okay?"

    # say L3469 pla
    old "Yeah, see you."
    new "Klar, bis später."

    # say L3475 pla
    old "Damn, things between them really went out of whack."
    new "Scheiße, die Beziehung zwischen ihnen ist echt aus dem Ruder gelaufen."

    # say L3476 pla
    old "Maybe I could do something to help them."
    new "Vielleicht könnte ich was tun, um ihnen zu helfen."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/jadAnimations.rpy
translate german strings:

    # say L6 milJad
    old "I must say... Mmmm, the size of your dick never stops being surprising."
    new "Ich muss sagen... Mmmm, die Größe deines Schwanzes überrascht mich immer wieder."

    # say L7 milJad
    old "It’s impressive."
    new "Es ist beeindruckend."

    # say L8 milJad
    old "And this scent... I had never perceived it."
    new "Und dieser Geruch... Ich habe ihn noch nie wahrgenommen."

    # say L9 milJad
    old "It’s... nice."
    new "Es ist... schön."

    # say L13 milJad
    old "Are you enjoying this?"
    new "Genießt du das?"

    # say L14 milJad
    old "I ask because it’s important for you to cum."
    new "Ich frage, weil es wichtig ist, dass du kommst."

    # say L15 pla
    old "It feels good."
    new "Es fühlt sich gut an."

    # say L20 milJad
    old "This sensation! I’d never felt it before!"
    new "Diese Empfindung! Ich habe sie noch nie zuvor gespürt!"

    # say L21 milJad
    old "Ughh... It hurts, but it feels so good!"
    new "Ughh... Es tut weh, aber es fühlt sich so gut an!"

    # say L22 milJad
    old "I- I’m enjoying it!"
    new "Ich- Ich genieße es!"

    # say L45 pla
    old "I don’t think I will last longer!"
    new "Ich glaube, ich halte das nicht mehr lange aus!"

    # say L46 milJad
    old "It’s ok, cum for me!"
    new "Alles gut, komm für mich!"

    # say L48 milJad
    old "Cum! Give me the magic!"
    new "Komm! Gib mir die Magie!"

    # say L54 mil
    old "That... that was unexpected."
    new "Das... das war unerwartet."

    # say L55 pla
    old "Are you ok?"
    new "Alles okay mit dir?"

    # say L56 mil
    old "I’m fine."
    new "Mir geht's gut."

    # say L57 mil
    old "It’s just that I wasn’t expecting that."
    new "Es ist nur, dass ich das nicht erwartet habe."

    # say L58 mil
    old "The act feels so different with a human body."
    new "Die Tat fühlt sich so anders an mit einem menschlichen Körper."

    # say L59 mil
    old "And to be able to feel all that. Linett’s spell is very complete!"
    new "Und all das zu spüren. Linnets Zauber ist wirklich vollständig!"

    # say L60 pla
    old "Ah... sure. Hey listen, I think we need to get going before we’re discovered here."
    new "Ah... klar. Hör zu, ich glaube, wir sollten besser verschwinden, bevor uns jemand entdeckt."

    # say L61 pla
    old "I’ll clean Mrs. Jade, and then we take off. Ok?"
    new "Ich räume bei Mrs. Jade auf, und dann verschwinden wir. Okay?"

    # say L75 jad
    old "(Mmm, it feels so nice...)"
    new "(Mmm, es fühlt sich so gut...)"

    # say L76 jad
    old "(Uhh... A- am I moving? God, I- I can't control it... I hope [pla] doesn't notice.)"
    new "Uhh... A- bin ich in Bewegung? Gott, ich- ich kann es nicht kontrollieren... Ich hoffe, [pla] bemerkt es nicht."

    # say L77 pla
    old "(Wait, is she moving? What the-)"
    new "(Warte, bewegt sie sich? Was zur-)"

    # say L81 pla
    old "(Wow... Yeah, she is definitely moving... Geez, and just in front of Hinn...)"
    new "Wow... Ja, sie bewegt sich definitiv... Mann, und direkt vor Hinn..."

    # say L82 hin
    old "Hey, talking about dad, I saw he deleted the post about his marriage."
    new "Hey, von Papa rede ich, hab gesehen, dass er den Post über seine Ehe gelöscht hat."

    # say L83 hin
    old "Kinda late, we already saw it."
    new "Ist ja schon gut, wir haben es schon gesehen."

    # say L84 jad
    old "Mmm... Yeah, he’s just like that."
    new "Mmm... Ja, er ist einfach so."

    # say L85 jad
    old "Not surprising..."
    new "Nicht überraschend..."

    # say L89 jad
    old "(Oh my God! I can't help myself anymore, this feels so fucking good.)"
    new "Oh mein Gott! Ich kann mich nicht mehr zurückhalten, das fühlt sich so verdammt gut an."

    # say L93 jad
    old "(Holy cow!) U- uh, nothing, I just hurt my toe."
    new "Heilige Kuh! U- äh, nichts, ich hab mir nur den Zeh gestoßen."

    # say L94 jad
    old "A- accidentally."
    new "A- aus Versehen."

    # say L95 hin
    old "Oh, you should be more careful."
    new "Oh, du solltest vorsichtiger sein."

    # say L96 jad
    old "Yes honey, hehe, how silly of me..."
    new "Ja Schatz, hehe, wie dumm von mir..."

    # say L121 jad
    old "Are you about to finish?"
    new "Bist du gleich soweit?"

    # say L122 hin
    old "Yeah, I’m almost done."
    new "Ja, ich bin fast fertig."

    # say L123 jad
    old "Me too..."
    new "Ich auch..."

    # say L130 hin
    old "Well, that was a relief, I’m sorry I interrupted your shower."
    new "Na, das war eine Erleichterung, tut mir leid, dass ich deine Dusche unterbrochen habe."

    # say L132 jad
    old "Don’t worry honey."
    new "Mach dir keine Sorgen, Schatz."

    # say L133 hin
    old "I have to get going, gotta get back to school."
    new "Ich muss los, muss zurück zur Schule."

    # say L134 jad
    old "Sure honey."
    new "Klar, Schatz."

    # say L137 jad
    old "(Oh my god! What did I just do?)"
    new "Oh mein Gott! Was habe ich da gerade gemacht?"

    # say L138 jad
    old "I- I think we should get out of this tub [pla]."
    new "I- Ich glaube, wir sollten aus dieser Wanne rauskommen [pla]."

    # say L139 pla
    old "Uhh, right, right."
    new "Uhh, klar, klar."

    # say L152 jad
    old "Oh yeah, this feels so nice.."
    new "Oh ja, das fühlt sich so gut an.."

    # say L153 jad
    old "Mmm, I want that big hard cock inside of me!"
    new "Mmm, ich will diesen großen harten Schwanz in mir!"

    # say L154 jad
    old "I need it."
    new "Ich brauch es."

    # say L158 jad
    old "Uhh, I- it’s the biggest cock I’ve seen!"
    new "Uhh, das ist der größte Schwanz, den ich je gesehen habe!"

    # say L159 jad
    old "Oh God! I- I want to be fucked by him!"
    new "Oh Gott! I- Ich will von ihm gefickt werden!"

    # say L160 pla
    old "(She's thinking about someone she knows?)"
    new "Wow! Wow! Sie denkt doch nicht an mich, oder?!"

    # say L164 jad
    old "Mmm... I want him to fuck me like he fucks Hinn!"
    new "Mmm... Ich will, dass er mich so fickt wie er Hinn fickt!"

    # say L165 pla
    old "(Woah! Woah! She's not thinking about me, right?!)"
    new "Wow! Wow! Sie denkt doch nicht an mich, oder?!"

    # say L166 jad
    old "Oh yes, yes, yes!!"
    new "Oh ja, ja, ja!!"

    # say L167 jad
    old "I want to feel that hard cock inside me!"
    new "Ich will diesen harten Schwanz in mir spüren!"

    # say L168 jad
    old "That young, thick, hard, cock!"
    new "Dieser junge, dicke, harte Schwanz!"

    # say L191 jad
    old "AH! AH! Ohhh I'm cumming, I'm cumming!"
    new "AH! AH! Ohhh ich komme, ich komme!"

    # say L192 jad
    old "YES! YES! YES! YES!"
    new "JA! JA! JA! JA!"

    # say L198 jad
    old "Phew, that felt so good."
    new "Puh, das war so gut."

    # say L199 jad
    old "I needed that."
    new "Ich brauchte das."

    # say L200 jad
    old "But, it’s still not the same as a dick."
    new "Aber, es ist immer noch nicht das Gleiche wie ein Schwanz."

    # say L203 jad
    old "Wait, what was that sound?"
    new "Warte, was war das für ein Geräusch?"

    # say L211 jad
    old "Mmmm, that was a huge cock!"
    new "Mmmm, das war ein riesiger Schwanz!"

    # say L212 pla
    old "(Is she talking about my...)"
    new "(Redet sie von meinem...)"

    # say L213 jad
    old "Oh god, it barely fit in my mouth, and it tasted so good..."
    new "Oh Gott, es passte kaum in meinen Mund und es schmeckte so gut..."

    # say L217 jad
    old "Oh my God! I had never felt this before..."
    new "Oh mein Gott! Ich hab das noch nie gespürt..."

    # say L218 jad
    old "Mmmm, I want that cock so badly..."
    new "Mmmm, ich will diesen Schwanz so sehr..."

    # say L224 jad
    old "I- I want your big dick inside me [pla]!"
    new "I- Ich will deinen großen Schwanz in mir [pla]!"

    # say L225 jad
    old "I love you big cock!"
    new "Ich liebe deinen großen Schwanz!"

    # say L248 jad
    old "Ahh! Ahhh! I want you to fill me up!"
    new "Ahh! Ahhh! Ich will, dass du mich ausfüllst!"

    # say L249 jad
    old "Yes! Yes! Oh, this is so good!"
    new "Ja! Ja! Oh, das ist so gut!"

    # say L250 jad
    old "I- I’m cumming!"
    new "Ich- Ich komme!"

    # say L256 jad
    old "Phew... I bet that surprised you."
    new "Puh... Das hat dich sicher überrascht."

    # say L257 pla
    old "(Is she talking to me?)"
    new "(Spricht sie mit mir?)"

    # say L258 jad
    old "Sorry I couldn't help it, I've been a bit horny lately."
    new "Tut mir leid, ich konnte es nicht lassen, ich bin lately ein bisschen horny gewesen."

    # say L265 jad
    old "It’s ok, I knew you were there [pla], it’s just that I needed to loosen up a little bit before."
    new "Alles gut, ich wusste, dass du da bist [pla], ich musste mich nur ein bisschen entspannen."

    # say L266 pla
    old "Uhh... Before? Before what?"
    new "Uhh... Davor? Davor was?"

    # say L267 jad
    old "Before this."
    new "Davor."

    # say L288 whi
    old "I love how big is his cock, isn't it?"
    new "Ich liebe, wie groß sein Schwanz ist, finden Sie nicht?"

    # say L289 whi
    old "Are you enjoying the view Jade?"
    new "Genießt du den Anblick, Jade?"

    # say L294 whi
    old "Mmm, yeah, have you ever seen a deep throat, Jade?"
    new "Mmm, ja, haben Sie schon mal einen Deep Throat gesehen, Jade?"

    # say L295 whi
    old "Do you like what I'm doing with my mouth?"
    new "Magst du, was ich mit meinem Mund mache?"

    # say L300 whi
    old "What about if I get an oral creampie, would you like to see that jade?"
    new "Was wäre, wenn ich einen oralen Creampie kriege, würdest du das sehen wollen, Jade?"

    # say L302 whi
    old "That's all what I need to know."
    new "Das ist alles, was ich wissen muss."

    # say L325 pla
    old "Mmmm, I- I think I'm about to-"
    new "Mmmm, ich- ich glaube, ich bin gleich soweit-"

    # say L326 whi
    old "Yes! Do it! Show Jade what she's been missing!"
    new "Ja! Mach es! Zeig Jade, was sie verpasst hat!"

    # say L327 whi
    old "You want it too, don't you Jade?"
    new "Sie wollen es auch, oder Jade?"

    # say L328 whi
    old "You also want him to push this big hard dick in you mouth?"
    new "Sie wollen auch, dass er diesen großen harten Schwanz in Ihren Mund schiebt?"

    # say L340 whi
    old "Mmm, are you ready for your turn?"
    new "Mmm, bist du bereit für deine Runde?"

    # say L342 whi
    old "Well? Do you want to try it, isn't it?"
    new "Na? Willst du es ausprobieren, oder was?"

    # say L343 jad
    old "Uhh, I- I do."
    new "Uhh, ich- ich tu's."

    # say L344 whi
    old "Good! I'm glad you're finally admitting it."
    new "Gut! Ich bin froh, dass du es endlich zugeben kannst."

    # say L345 whi
    old "Great, now let's do it!"
    new "Großartig, dann lass es uns tun!"

    # say L354 whi
    old "That's it, girl, just relax, don’t think about anything else other than what you have in your mouth right now."
    new "Das ist es, Mädchen, einfach entspann dich, denk an nichts anderes als daran, was du gerade im Mund hast."

    # say L356 whi
    old "He must be enjoying this as hell, two sexy MILFS sucking his dick, that should be like heaven. Isn't it [pla]?"
    new "Er muss das echt genießen, zwei geile MILF-Schlampe, die seinen Schwanz blasen, das sollte wie der Himmel sein. Ist es nicht [pla]?"

    # say L357 pla
    old "Uhh... Mmmm, yeah..."
    new "Uhh... Mmmm, ja..."

    # say L358 whi
    old "Hehe, enjoy this huge cock Jade."
    new "Hehe, genieße diesen großen Schwanz, Jade."

    # say L367 whi
    old "I bet you've been wanting to get his hot dick in your mouth for a while, haven't you?"
    new "Ich wette, Sie haben sich schon lange danach gesehnt, seinen heißen Schwanz im Mund zu haben, oder?"

    # say L369 whi
    old "Hahaha, that's all the answer I needed."
    new "Hahaha, das war die Antwort, die ich brauchte."

    # say L373 whi
    old "I can tell you girl, this is about a hundred times better than your ex-husband's limp dick!"
    new "Ich kann dir sagen, Mädchen, das ist hundertmal besser als der schlaffe Schwanz deines Ex-Mannes!"

    # say L374 jad
    old "Slrrrrp! Mmmm, yeah!"
    new "Slrrrrp! Mmmm, ja!"

    # say L375 whi
    old "Mmmm, how sexy you look with a big cock in your mouth."
    new "Mmmm, wie sexy du aussiehst mit einem großen Schwanz im Mund."

    # say L379 whi
    old "Oh yeah baby! let's make him cum. You want him to cum in your mouth and taste that big load, right?"
    new "Oh ja Baby! Lass uns ihn kommen lassen. Du willst doch, dass er in deinem Mund kommt und du diesen großen Saft schmeckst, oder?"

    # say L380 jad
    old "...Y- yes, I want it..."
    new "...J- ja, ich will es..."

    # say L381 whi
    old "You already heard it please, don't hold back and give us a huge cumshot."
    new "Sie haben es schon gehört, bitte, halten Sie sich nicht zurück und geben Sie uns einen riesigen Spritzer."

    # say L405 pla
    old "I- I think I’m about to...!"
    new "I- Ich glaube, ich komme gleich...!"

    # say L406 whi
    old "That’s it, cum for us baby!"
    new "Das ist es, spritz für uns, Schatz!"

    # say L407 whi
    old "I want you to cum in her mouth!"
    new "Ich will, dass du in ihrem Mund kommst!"

    # say L408 whi
    old "You are going to drink every single drop, Jade."
    new "Du wirst jeden einzelnen Tropfen trinken, Jade."

    # say L415 whi
    old "Ohh yeah, that was a huge load. Did you enjoy it Jade?"
    new "Ohh ja, das war eine Menge. Hast du es genossen, Jade?"

    # say L416 jad
    old "Uhh... Y- yes..."
    new "Uhh... J- ja..."

    # say L417 whi
    old "What did I tell you? This is a lot better than masturbating."
    new "Was hab ich dir gesagt? Das ist viel besser als Selbstbefriedigung."

    # say L418 whi
    old "And with such a young gifted man, you didn’t know what you were missing on girl."
    new "Und bei so einem jungen talentierten Mann, da wusstest du gar nicht, was du verpasst hast, Mädchen."

    # say L419 jad
    old "I- I suppose you’re right."
    new "I- Ich schätze, Sie haben recht."

    # say L420 whi
    old "You know I’m right. Now let me help you clean up all this mess."
    new "Sie wissen, dass ich recht habe. Lassen Sie mich Ihnen helfen, das Chaos aufzuräumen."

    # say L432 pla
    old "Uhh, w- what is happening?"
    new "Uhh, w- was passiert hier?"

    # say L433 jad
    old "Well, you know what Mrs. White said last time."
    new "Na ja, Sie wissen ja, was Mrs. White letztes Mal gesagt hat."

    # say L434 jad
    old "Maybe we should try to do some of this on our own."
    new "Vielleicht sollten wir versuchen, ein bisschen davon selbst zu machen."

    # say L436 jad
    old "To be honest, I’ve been thinking about this way too much, it’s about time I do something about it."
    new "Ehrlich gesagt, ich hab schon viel zu viel darüber nachgedacht, es ist Zeit, dass ich was dagegen unternehme."

    # say L440 jad
    old "Hmph! Slrrrp!"
    new "Hmpf! Schlürp!"

    # say L441 jad
    old "I can kind of see why Hinn likes you so much."
    new "Ich kann irgendwie verstehen, warum Hinn dich so mag."

    # say L442 jad
    old "How could she not? With such an amazing cock!"
    new "Wie könnte sie nicht? Mit so einem unglaublichen Schwanz!"

    # say L446 jad
    old "I love how hot your cock is?"
    new "Ich liebe, wie heiß dein Schwanz ist."

    # say L447 jad
    old "Are you liking it, honey?"
    new "Magst du es, Schatz?"

    # say L448 pla
    old "Mmm, yeah..."
    new "Mmm, ja..."

    # say L449 jad
    old "Me too!"
    new "Mir auch!"

    # say L472 pla
    old "I- I think I’m about to cum!"
    new "Ich glaube, ich komme gleich!"

    # say L473 jad
    old "It’s ok, you can cum in my mouth!"
    new "Es ist okay, du kannst in meinem Mund kommen!"

    # say L474 jad
    old "I want to taste it again!"
    new "Ich will es wieder schmecken!"

    # say L481 jad
    old "Phew, that was really good [pla]."
    new "Puh, das war echt gut [pla]."

    # say L494 jad
    old "OH MY GOD!! Oh wow!"
    new "OH MEIN GOTT!! Oh wow!"

    # say L495 whi
    old "Hahaha, he’s huge isn’t he?"
    new "Hahaha, der ist ja riesig, oder?"

    # say L496 whi
    old "Just relax and enjoy it girl."
    new "Beruhige dich und genieße es einfach, Mädchen."

    # say L497 whi
    old "Not always can you enjoy something like this."
    new "Nicht immer kannst du so etwas genießen."

    # say L501 jad
    old "Ah! Ah! I can’t! This is just too good!"
    new "Ah! Ah! Ich kann nicht! Das ist einfach zu gut!"

    # say L502 whi
    old "Yeah that’s right, take it all."
    new "Ja, genau so, nimm es dir."

    # say L503 whi
    old "Ha! I bet that looser of your ex-husband never fucked you like this!"
    new "Ha! Ich wette, dieser Loser von deinem Ex-Mann hat dich nie so genommen!"

    # say L504 whi
    old "What do you say [pla]? How does it feel to have two MILFS like us just for you?"
    new "Was sagst du dazu [pla]? Wie fühlt es sich an, zwei MILF wie uns nur für dich zu haben?"

    # say L508 whi
    old "Did you ever feel anything like this before, Jade?"
    new "Hast du jemals so etwas gefühlt, Jade?"

    # say L509 jad
    old "Ahh! Ahh! O- of course not!"
    new "Ahh! Ahh! N-natürlich nicht!"

    # say L510 whi
    old "Hahaha, I love to see you like this!"
    new "Hahaha, ich liebe es, dich so zu sehen!"

    # say L511 whi
    old "Enjoy it girl, you deserve it!"
    new "Genieße es, Mädchen, du hast es verdient!"

    # say L534 whi
    old "Keep going [pla]!"
    new "Weiter so [pla]!"

    # say L535 whi
    old "You’re about to make her cum!"
    new "Du bist kurz davor, sie kommen zu lassen!"

    # say L536 whi
    old "Don’t stop! Don’t stop now!"
    new "Nicht aufhören! Nicht jetzt aufhören!"

    # say L544 jad
    old "Oh my! That was great, really great."
    new "Oh wow! Das war toll, echt toll."

    # say L545 whi
    old "And look at that, he just came and he’s still hard!"
    new "Und sieh dir das an, er ist gerade gekommen und ist immer noch hart!"

    # say L546 whi
    old "It must be great to be that young!"
    new "Es muss wunderbar sein, so jung zu sein!"

    # say L547 whi
    old "But now it’s my turn."
    new "Aber jetzt bin ich dran."

    # say L548 whi
    old "Come here [pla], I want you to fuck me hard."
    new "Kommen Sie hierher [pla], ich will, dass Sie mich hart ficken."

    # say L565 whi
    old "Nngh! Oh yeah, that’s it!"
    new "Nngh! Oh ja, genau so!"

    # say L566 whi
    old "That’s just what I have been waiting for."
    new "Das ist genau das, was ich die ganze Zeit erwartet habe."

    # say L567 whi
    old "Uhhh, it just fills me up!"
    new "Uhhh, es füllt mich einfach aus!"

    # say L571 whi
    old "Ah! Ah! Ah! It’s so big!"
    new "Ah! Ah! Ah! Es ist so groß!"

    # say L572 whi
    old "I want to keep being fucked by you everyday!"
    new "Ich will, dass du mich jeden Tag fickst!"

    # say L577 whi
    old "I- I never had any sex like this with my ex-husband either!"
    new "Ich- Ich habe auch mit meinem Ex-Mann noch nie so etwas erlebt!"

    # say L578 whi
    old "It’s unbelievable how good this is!"
    new "Es ist unglaublich, wie gut das ist!"

    # say L579 whi
    old "Keep going [pla]! Keep pounding my pussy!"
    new "Weiter so [pla]! Mach weiter, fick meine Pussy!"

    # say L580 whi
    old "Yes! yes! yes!"
    new "Ja! Ja! Ja!"

    # say L603 pla
    old "Mrs. White, I can’t hold it in any longer!"
    new "Mrs. White, ich kann es nicht länger zurückhalten!"

    # say L604 whi
    old "Cum! Cum inside me!"
    new "Kommen Sie! Kommen Sie in mir!"

    # say L605 whi
    old "Oh my God! I have missed this cock so much!"
    new "Oh mein Gott! Ich habe diesen Schwanz so sehr vermisst!"

    # say L606 whi
    old "I love being fucked by you!"
    new "Ich liebe es, von Ihnen gefickt zu werden!"

    # say L613 whi
    old "Well, I must say that was wonderful."
    new "Nun, ich muss sagen, das war wunderbar."

    # say L614 whi
    old "Just look at you Jade! You look so calm and relaxed now!"
    new "Schau dich an, Jade! Du siehst so ruhig und entspannt aus!"

    # say L615 jad
    old "Yeah, I think you’re absolutely right!"
    new "Ja, ich denke, du hast absolut recht!"

    # say L616 jad
    old "I can’t believe how relaxed I am!"
    new "Ich kann nicht glauben, wie entspannt ich bin!"

    # say L617 jad
    old "I must say, I don’t even care about what’s happening with Hiashi right now. I hope he’s very happy with his new wife."
    new "Ich muss sagen, ich kümmere mich im Moment gar nicht um Hiashi. Ich hoffe, er ist sehr glücklich mit seiner neuen Frau."

    # say L618 jad
    old "If she doesn’t cheat on him."
    new "Wenn sie ihn nicht betrügt."

    # say L621 whi
    old "Well, I think we should better get dressed before your daughter gets home."
    new "Na ja, ich denke, wir sollten uns besser anziehen, bevor deine Tochter nach Hause kommt."

    # say L622 jad
    old "Right, right."
    new "Stimmt, stimmt."

    # say L636 jad
    old "I- it's so big... Oh my God!"
    new "I- es ist so groß... Oh mein Gott!"

    # say L637 jad
    old "Mmmm [pla]! I could get addicted to your cock!"
    new "Mmmm [pla]! Ich könnte süchtig nach deinem Schwanz werden!"

    # say L638 jad
    old "No wonder Hinn always wants to fuck with you!"
    new "Kein Wunder, dass Hinn immer mit dir ficken will!"

    # say L643 jad
    old "It’s so hot! So thick and hard!"
    new "Es ist so heiß! So dick und hart!"

    # say L644 jad
    old "I can’t resist it!"
    new "Ich kann dem nicht widerstehen!"

    # say L648 jad
    old "Yes! Yes! Yes! Keep going!"
    new "Ja! Ja! Ja! Mach weiter!"

    # say L649 jad
    old "Just like that!"
    new "Genau so!"

    # say L650 jad
    old "Fuck me, fuck me harder [pla]!"
    new "Fick mich, fick mich härter [pla]!"

    # say L651 jad
    old "Ahhh! I love it!"
    new "Ahhh! Ich liebe es!"

    # say L674 jad
    old "I'm about to cum honey!"
    new "Ich komme gleich, Schatz!"

    # say L676 jad
    old "L- let's do it!"
    new "Lass es uns tun!"

    # say L677 jad
    old "Let's cum together!!"
    new "Lass uns zusammen kommen!"

    # say L685 jad
    old "Wow, that was wonderful honey."
    new "Wow, das war wunderbar Schatz."

    # say L686 jad
    old "And the shower it’s also working perfectly."
    new "Und die Dusche funktioniert auch perfekt."

    # say L687 jad
    old "Oh my God! It's too late, Come on honey, let’s get dressed."
    new "Oh mein Gott! Es ist zu spät, komm schon Schatz, zieh dich an."


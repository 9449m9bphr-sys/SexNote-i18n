# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Eventos Default.rpy
translate german strings:

    # say L9 pla
    old "Alright… time for some practice."
    new "Okay… Zeit für ein bisschen Übung."

    # say L10 pla
    old "Feels good to just sit down and play now."
    new "Es fühlt sich gut an, sich jetzt einfach hinzusetzen und zu spielen."

    # say L11 pla
    old "It’s becoming part of the routine… and I actually look forward to it."
    new "Es wird zum Ritual… und ich freue mich richtig drauf."

    # say L17 pla
    old "That one came out clean."
    new "Das hat sauber geklappt."

    # say L18 pla
    old "The chords are flowing better every day."
    new "Die Akkorde fließen jeden Tag besser."

    # say L19 pla
    old "Hand still gets tired, but it doesn’t fight me anymore."
    new "Die Hand wird immer noch müde, aber sie widersetzt sich mir nicht mehr."

    # say L20 pla
    old "Feels natural now… like the guitar is actually listening."
    new "Fühlt sich jetzt natürlich an… als würde die Gitarre mir wirklich zuhören."

    # say L23 pla
    old "Rhythm’s locking in nicely."
    new "Das Timing klappt jetzt super."

    # say L24 pla
    old "I can feel the music instead of just chasing the notes."
    new "Ich spüre die Musik jetzt, statt den Noten hinterherzujagen."

    # say L25 pla
    old "({i}This is actually fun… who would’ve thought?{/i})"
    new "{i}Das ist tatsächlich Spaß... wer hätte das gedacht?{/i}"

    # say L26 pla
    old "One more run-through. Let’s make it feel even smoother."
    new "Noch ein Durchgang. Lass uns es noch flüssiger machen."

    # say L30 pla
    old "Still a couple of rough spots… but overall it sounded solid."
    new "Noch ein paar holprige Stellen… aber insgesamt klang es solide."

    # say L31 pla
    old "I’m really starting to enjoy this."
    new "Ich fange echt an, das zu genießen."

    # say L32 pla
    old "It doesn’t feel like a chore anymore. It feels… right."
    new "Es fühlt sich nicht mehr wie eine Pflicht an. Es fühlt sich… richtig an."

    # say L33 pla
    old "Who knew picking up the guitar would end up being something I actually look forward to?"
    new "Wer hätte gedacht, dass das Gitarrespielen etwas wird, auf das ich mich wirklich freue?"

    # say L34 pla
    old "That’s enough for today. Fingers are happy."
    new "Das reicht für heute. Die Finger sind zufrieden."

    # say L35 pla
    old "Tomorrow I’ll pick it up again… no pressure, just playing."
    new "Morgen nehme ich es wieder in die Hand... kein Druck, nur spielen."

    # say L44 bil
    old "There you are."
    new "Da bist du ja."

    # say L46 bil
    old "Heh. Back again already?"
    new "Heh. Schon wieder zurück?"

    # say L47 bil
    old "The guitar at home not doing it for you anymore?"
    new "Die Gitarre zu Hause reicht dir nicht mehr?"

    # say L48 pla
    old "Yeah… I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "Klar… Ich übe viel alleine, aber ich merke, dass ich schneller Fortschritte mache, wenn ich mit dir zusammen bin."

    # say L49 bil
    old "Of course you do."
    new "Natürlich tust du das."

    # say L50 bil
    old "Heh. Come on. Let’s take this to my room."
    new "Heh. Komm schon. Lass uns das in mein Zimmer verlegen."

    # say L54 bil
    old "Alright, we're here."
    new "Okay, wir sind da."

    # say L55 bil
    old "So... what are we practicing today?"
    new "Also... was üben wir heute?"

    # say L66 pla
    old "Uhh, I would say let’s just rehearse the song together today."
    new "Uhh, ich würde sagen, lass uns heute einfach das Lied zusammen einüben."

    # say L67 pla
    old "I want to polish the chords even more, youb know..."
    new "Ich will die Akkorde noch weiter feilen, weißt du..."

    # say L68 bil
    old "Heh. Going for the safe route first? Fine by me… for now."
    new "Heh. Erst mal den sicheren Weg gehen? Ist mir auch recht… fürs Erste."

    # say L69 bil
    old "Grab the guitar. Show me what you’ve been working on."
    new "Nimm die Gitarre. Zeig mir, was du geübt hast."

    # say L74 bil
    old "{i}I used to float above the ground…{/i}"
    new "{i}Ich schwebte früher über dem Boden…{/i}"

    # say L75 pla
    old "{i}Now every step just pulls me down…{/i}"
    new "{i}Jetzt zieht jeder Schritt mich nach unten…{/i}"

    # say L79 bil
    old "Hmm… your changes are actually smooth now. You’ve been practicing."
    new "Hmm… deine Veränderungen sind jetzt tatsächlich flüssig. Du hast geübt."

    # say L80 bil
    old "We’re starting to sound like we really belong together on stage."
    new "Wir fangen an, wie ein echtes Team auf der Bühne zu klingen."

    # say L81 bil
    old "Not bad at all. You’re actually carrying your part."
    new "Nicht schlecht. Du übernimmst deinen Part wirklich gut."

    # say L82 pla
    old "Yeah, it feels good."
    new "Ja, das fühlt sich gut an."

    # say L83 bil
    old "See? When we rehearse like this, we both get better together."
    new "Siehst du? Wenn wir so üben, werden wir beide besser."

    # say L84 bil
    old "Still… I wouldn’t mind if you picked something a little more fun next time."
    new "Immer noch… ich würde nichts dagegen haben, wenn du beim nächsten Mal was Spannenderes auswählst."

    # say L87 pla
    old "Uhh, I- I think my fingers could use some... practice."
    new "Uhh, ich glaube, meine Finger könnten noch etwas... Übung gebrauchen."

    # say L88 pla
    old "You know what I mean?"
    new "Du weißt, was ich meine, oder?"

    # say L89 bil
    old "Heh. There it is. I was hoping you’d go for this."
    new "Heh. Da ist es. Ich hatte gehofft, dass du dich dafür entscheidest."

    # say L90 bil
    old "Good choice. I like when you get straight to it."
    new "Gute Wahl. Ich mag es, wenn du direkt bist."

    # say L92 bil
    old "Come here, let’s make ourselves comfortable."
    new "Komm her, lass uns es uns gemütlich machen."

    # say L94 bil
    old "This is what you wanted, huh?"
    new "Das wolltest du doch, oder?"

    # say L95 pla
    old "*Gulp*"
    new "*Gluck*"

    # say L96 bil
    old "They’re all yours today."
    new "Sie sind heute alle dein."

    # say L98 bil
    old "Hands on them. You already know exactly how I like it."
    new "Leg die Hände drauf. Du weißt genau, wie ich es mag."

    # say L102 pla
    old "They’re… so soft every time. I can feel them filling my hands."
    new "Sie sind… jedes Mal so weich. Ich kann sie in meinen Händen spüren."

    # say L103 bil
    old "Mmm… squeeze them slowly. Open and close your hands… just like that."
    new "Mmm… drück sie langsam. Mach die Hände auf und zu… genau so."

    # say L105 bil
    old "Nngh— yeah… a little harder now. Grip them properly."
    new "Nngh— ja… jetzt ein bisschen fester. Pack sie richtig."

    # say L107 bil
    old "Fuck… keep that pace. Squeeze them like you mean it."
    new "Scheiße… halt das Tempo. Kneife sie, als meinst du es ernst."

    # say L110 bil
    old "Now the nipples… grab them and pull… slow at first."
    new "Jetzt die Brustwarzen… pack sie und zieh daran… langsam zuerst."

    # say L112 bil
    old "That’s it… stretch them gently."
    new "Das ist es… ziehe sie sanft."

    # say L114 bil
    old "Mmm—harder. Tug them a little more. You’re getting really good at this."
    new "Mmm—fester. Zieh sie ein bisschen stärker. Du wirst echt gut darin."

    # say L116 bil
    old "Fuck… faster. Pull them nice and firm. I love how confident your hands feel now."
    new "Scheiße… schneller. Zieh sie schön fest. Ich liebe, wie sicher sich deine Hände jetzt anfühlen."

    # say L118 bil
    old "Mmm… your touch is way more precise lately. You’ve improved a lot."
    new "Mmm… deine Berührungen sind in letzter Zeit viel präziser. Du hast dich echt verbessert."

    # say L119 bil
    old "Your fingers are definitely improving. They feel so much more alive and sure of themselves."
    new "Deine Finger werden definitiv besser. Sie fühlen sich so viel lebendiger und selbstbewusster an."

    # say L120 bil
    old "Keep practicing that rhythm at home… or just come back whenever you want more of... this."
    new "Übe dieses Rhythmus zu Hause weiter… oder komm einfach wieder, wann immer du mehr davon willst."

    # say L124 pla
    old "Uhh, actually I was wondering if we could try the... 'advanced practice' today..."
    new "Uhh, eigentlich hab ich mich gefragt, ob wir heute die... 'fortgeschrittene Übung' machen könnten..."

    # say L125 bil
    old "Heh. Straight to my favorite part. I was really hoping you’d pick this one."
    new "Heh. Gerade zu meinem Lieblingsteil. Ich hab mich echt darauf gefreut, dass du dich für diesen entscheidest."

    # say L126 bil
    old "You know I like when you get straight to the fun stuff."
    new "Du weißt, dass ich es mag, wenn du direkt zur Sache kommst."

    # say L128 bil
    old "Get ready. I’m getting on top."
    new "Bereit? Ich setze mich oben drauf."

    # say L130 bil
    old "I know how much you like to see them, so why don’t we make it more enjoyable for both of us?"
    new "Ich weiß, wie gerne du das siehst, also lass uns es für uns beide angenehmer machen."

    # say L133 bil
    old "Now use those fingers right. Show me what you’ve learned."
    new "Jetzt benutz die Finger richtig. Zeig mir, was du gelernt hast."

    # say L135 bil
    old "Mmm… circle my clit first. Gentle, like I showed you."
    new "Mmm… kreise zuerst um meine Klitoris. Sanft, wie ich es dir gezeigt habe."

    # say L145 bil
    old "Shit… your fingers really kept perfect rhythm this time."
    new "Scheiße… deine Finger haben dieses Mal wirklich perfekten Rhythmus gehalten."

    # say L147 bil
    old "This is exactly the kind of dexterity we need… both on stage and off it."
    new "Das ist genau die Fingerfertigkeit, die wir brauchen… sowohl auf der Bühne als auch abseits davon."

    # say L151 pla
    old "Uhh… I’ve been practicing the guitar a lot by myself lately."
    new "Uhh… ich hab neulich ziemlich viel Gitarre geübt."

    # say L152 pla
    old "And I was thinking… maybe it would be good if I helped you with your practice too, you know?"
    new "Und ich dachte… vielleicht wäre es gut, wenn ich dir bei deiner Übung auch helfe, weißt du?"

    # say L153 pla
    old "Like… helping you stay steady under pressure… like last time…"
    new "Wie… dir helfen, ruhig zu bleiben, wenn es knifflig wird… wie beim letzten Mal…"

    # say L154 bil
    old "Heh… look at you trying to be all subtle."
    new "Heh… schau dir an, wie subtil du versuchst zu sein."

    # say L155 bil
    old "You’ve been practicing hard, huh? And now you want to 'help' me with my vocal training."
    new "Du hast hart geübt, was? Und jetzt willst du mir bei meinem Vokaltraining helfen."

    # say L156 bil
    old "Cute. Real cute."
    new "Cute. Wirklich süß."

    # say L157 bil
    old "I know exactly what you mean, dummy."
    new "Ich weiß genau, was du meinst, Dummerchen."

    # say L158 bil
    old "Lie down. Time to put that tongue to good use."
    new "Leg dich hin. Zeit, dass deine Zunge sich nützlich macht."

    # say L161 bil
    old "Tongue out. Keep me steady while I lose it."
    new "Zunge raus. Halte mich fest, während ich durchdrehe."

    # say L164 pla
    old "You’re already dripping…"
    new "Du bist schon ganz nass…"

    # say L172 bil
    old "Nngh… your tongue is getting way too good at this."
    new "Nngh… deine Zunge wird echt immer besser darin."

    # say L174 bil
    old "Every time you do this my voice gets stronger under pressure… and I get to enjoy that mouth of yours."
    new "Jedes Mal, wenn du das machst, wird meine Stimme unter Druck stärker… und ich darf deinen Mund genießen."

    # say L178 pla
    old "And sometimes I feel like I still need… a little extra motivation to keep improving."
    new "Und manchmal habe ich das Gefühl, dass ich immer noch... ein bisschen zusätzliche Motivation brauche, um weiterzukommen."

    # say L179 bil
    old "Heh… so that’s what this is really about."
    new "Heh… dann geht es also darum."

    # say L180 bil
    old "All that solo practice and you still need me to give you a little push, huh?"
    new "All diese Einzelübungen und du brauchst immer noch einen kleinen Ansporn von mir, hm?"

    # say L182 bil
    old "Would this be enough motivation for you?"
    new "Würde das genug Motivation für dich sein?"

    # say L183 bil
    old "Just looking at them… does that help?"
    new "Nur sie anzusehen... hilft das?"

    # say L185 pla
    old "Y-yeah… they look amazing but… I was thinking maybe something more… direct?"
    new "Y-ja… sie sehen toll aus, aber… ich dachte, vielleicht etwas… direkter?"

    # say L186 bil
    old "Oh? Not satisfied with just the view?"
    new "Oh? Nicht zufrieden mit nur dem Anblick?"

    # say L187 bil
    old "Greedy today, aren’t you?"
    new "Heute bist du aber gierig, hm?"

    # say L188 bil
    old "Heh… fine. I know exactly how to motivate you properly."
    new "Heh… gut. Ich weiß genau, wie ich dich richtig motivieren kann."

    # say L191 bil
    old "Let me take care of that motivation the right way."
    new "Lass mich das richtig angehen."

    # say L192 bil
    old "Eyes on me the whole time."
    new "Augen auf mich die ganze Zeit."

    # say L194 bil
    old "Mmm… look at you. Already so hard just from asking."
    new "Mmm… schau dir an. Schon so hart nur vom Fragen."

    # say L195 pla
    old "Billie… that feels so good…"
    new "Billie… das fühlt sich so gut an…"

    # say L197 bil
    old "Deeper now… I want to feel every throb."
    new "Tiefer jetzt… ich will jeden Schlag spüren."

    # say L198 pla
    old "Fuck… you’re way too good at this."
    new "Scheiße… du bist echt gut darin."

    # say L201 pla
    old "I’m— I’m close…!"
    new "Ich bin— ich bin kurz davor…!"

    # say L204 bil
    old "Mmm… every drop. Good boy."
    new "Mmm… jeden Tropfen. Guter Junge."

    # say L206 bil
    old "Heh… feeling more motivated already?"
    new "Heh… schon motivierter?"

    # say L208 bil
    old "Come back whenever you need some real motivation again… I’ll be waiting."
    new "Komm zurück, wann immer du wieder echte Motivation brauchst… Ich warte auf dich."

    # say L212 bil
    old "Phew, well, that’s enough for today."
    new "Phew, na ja, das reicht für heute."

    # say L213 bil
    old "You can come back whenever you need more 'practice'."
    new "Du kannst jederzeit wiederkommen, wenn du mehr Übung brauchst."

    # say L214 bil
    old "Just text me. I’ll always make time… especially if you want the fun version."
    new "Schreib mir einfach. Ich hab immer Zeit… besonders wenn du die spaßige Version willst."

    # say L215 pla
    old "I’ll be back soon."
    new "Ich komme bald wieder."

    # say L216 bil
    old "You better. Now get out before grandma walks in."
    new "Du besser. Jetzt raus, bevor Oma reinkommt."

    # say L223 bil
    old "Phew… that’s enough for today."
    new "Phew… das reicht für heute."

    # say L224 bil
    old "Not bad. You’re actually starting to sound like you belong up there with me."
    new "Nicht schlecht. Du klingst tatsächlich langsam so, als würdest du hier oben hingehören."

    # say L225 bil
    old "Oh, by the way…"
    new "Oh, übrigens..."

    # say L226 bil
    old "Tomorrow we have a practice with Bey. Don’t slack off tonight."
    new "Morgen haben wir ein Probenspiel mit Bey. Mach heute Nacht nicht so viel."

    # say L227 bil
    old "Get some rest, warm up your fingers, and meet me at school. We’re doing a full run-through with her watching."
    new "Klar, ruh dich aus, wärme deine Finger auf und triff mich in der Schule. Wir machen eine komplette Durchlaufprobe mit ihr im Publikum."

    # say L228 pla
    old "Got it. I’ll be there."
    new "Verstanden. Ich bin da."

    # say L229 bil
    old "You better. Don’t make me drag you out of bed."
    new "Du besser. Mach mich nicht noch dazu, dich aus dem Bett zu ziehen."

    # say L236 bil
    old "You’re getting better every time. I can feel it."
    new "Du wirst jedes Mal besser. Ich kann es spüren."

    # say L237 bil
    old "Hey… before you go."
    new "Hey… bevor du gehst."

    # say L238 bil
    old "I need a favor. Free up your afternoon tomorrow and come over."
    new "Ich brauche einen Gefallen. Mach deinen Nachmittag morgen frei und komm vorbei."

    # say L239 pla
    old "Sure, what for?"
    new "Klar, wofür?"

    # say L240 bil
    old "Just come. I need you to accompany me somewhere. No questions."
    new "Komm einfach. Ich brauche dich irgendwohin zu begleiten. Keine Fragen."

    # say L241 bil
    old "It’s important… and I don’t want to go alone."
    new "Es ist wichtig… und ich will nicht allein gehen."

    # say L242 pla
    old "A- alright. I’ll be here."
    new "A- okay. Ich bin hier."

    # say L243 bil
    old "Good. Don’t be late. Now get out before grandma walks in."
    new "Gut. Sei nicht zu spät. Und jetzt raus hier, bevor Oma reinkommt."


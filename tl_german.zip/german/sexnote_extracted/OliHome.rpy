# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/OliHome.rpy
translate german strings:

    # menu L12 
    old "Talk to her."
    new "Mit ihr reden"

    # say L89 oli
    old "Hmm, are we starting or what?"
    new "Hmm, fangen wir an oder was?"

    # say L90 pla
    old "Uhh... E- excuse me?"
    new "Uhh... E- entschuldige?"

    # say L92 oli
    old "I'm asking you if we're going to study or something."
    new "Ich frag dich, ob wir jetzt endlich anfangen zu lernen oder so."

    # say L94 oli
    old "Because you just stayed there staring at me like a creep."
    new "Weil du da rumgestanden und mich wie ein Stalker angestarrt hast."

    # say L96 pla
    old "S- sorry, I- I didn't notice I was doing it."
    new "S- sorry, ich- ich hab' gar nicht gemerkt, dass ich das gemacht hab'."

    # say L97 pla
    old "I was just passing by and wanted to say hello."
    new "Ich bin nur vorbeigekommen und wollte Hallo sagen."

    # say L99 oli
    old "That's it? Alright."
    new "Das ist alles? Okay."

    # say L101 oli
    old "But make sure to come back soon. We’ve got a lot to study."
    new "Aber mach sicher, dass du bald wiederkommst. Wir haben viel zu lernen."

    # say L102 pla
    old "Sure, don't worry about it. I'll see you soon."
    new "Klar, mach dir keine Sorgen. Ich sehe dich bald."

    # say L112 oli
    old "Hey, what's up? Did you come to study with me?"
    new "Hey, was ist los? Bist du gekommen, um mit mir zu lernen?"

    # say L114 pla
    old "Hey, oh no, I can't right now, I just wanted to say hi."
    new "Hey, oh nein, ich kann gerade nicht, ich wollte nur Hallo sagen."

    # say L116 oli
    old "Hmm, alright, but make sure you come back soon."
    new "Hmm, okay, aber mach sicher, dass du bald wiederkommst."

    # say L117 oli
    old "So we can hit the books together."
    new "Dann können wir zusammen lernen."

    # say L119 pla
    old "Sure thing."
    new "Klar, mach ich."

    # say L165 vee
    old "Excuse me [pla], do you need anything?"
    new "Entschuldigung [pla], brauchst du etwas?"

    # say L167 pla
    old "Uhmm, no, sorry ma'am, I- uh- I was just passing by."
    new "Ähm, nein, tut mir leid, ich- äh- ich war nur auf dem Weg."

    # say L169 vee
    old "I see... Well, I guess I'll see you around then."
    new "Ich sehe... Na ja, dann sehen wir uns wohl."

    # say L180 vee
    old "Hello [pla], how are you today?"
    new "Hallo [pla], wie geht es dir heute?"

    # say L182 pla
    old "Hello Mrs. Priya, I'm fine, how about you?"
    new "Hallo Mrs. Priya, mir geht es gut, und dir?"

    # say L184 vee
    old "I'm doing alright."
    new "Ich bin gut drauf."

    # say L185 vee
    old "Tell me, do you need anything?"
    new "Sag mal, brauchst du was?"

    # say L186 pla
    old "Oh, not really. I just wanted to say hello."
    new "Oh, nein, wirklich nicht. Ich wollte nur Hallo sagen."

    # say L188 vee
    old "I see, well, I guess I'll see you around then."
    new "Ich sehe, dann sehen wir uns wohl später."

    # say L189 pla
    old "Sure thing ma'am, see you."
    new "Klar, bis dann."


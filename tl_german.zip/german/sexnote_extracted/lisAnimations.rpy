# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/lisAnimations.rpy
translate german strings:

    # say L6 lis
    old "Just relax and feel all my body, focus on the new sensations."
    new "Lass dich einfach gehen und spür meinen ganzen Körper, konzentriere dich auf die neuen Empfindungen."

    # say L10 lis
    old "Can you feel my breast over your back?"
    new "Kannst du meine Brust auf deinem Rücken spüren?"

    # say L11 pla
    old "Y- yeah..."
    new "Y- ja..."

    # say L15 lis
    old "I'm going to do it faster so you can feel more all my energy."
    new "Ich werde schneller werden, damit du mehr von meiner Energie spürst."

    # say L41 lis
    old "You are very connected with the moment and the environment, it means we can go beyond, you are ready for the next step."
    new "Du bist sehr im Moment und in der Umgebung verbunden, das bedeutet, wir können weitergehen, du bist bereit für den nächsten Schritt."

    # say L42 pla
    old "... Ok."
    new "Okay."

    # say L47 lis
    old "Please lie down now on your back so we can expose the parts of your body that we need to balance the energy."
    new "Bitte leg dich jetzt auf den Rücken, damit wir die Körperteile ausbalancieren können, die wir brauchen."

    # say L50 lis
    old "We can heal your body together, we can heal each other, please follow my instructions so you can release all these negative experiences..."
    new "Wir können deinen Körper gemeinsam heilen, wir können einander heilen, bitte folge meinen Anweisungen, damit du all diese negativen Erfahrungen loslassen kannst..."

    # say L51 lis
    old "Please lie down on your back, so we can take the negative energy out..."
    new "Bitte leg dich auf den Rücken, damit wir die negative Energie herausnehmen können..."

    # say L63 lis
    old "Ok, we are done now, let's do the next exercise..."
    new "Ok, wir sind fertig, lass uns die nächste Übung machen..."

    # say L73 lis
    old "Is it pleasant?"
    new "Ist es angenehm?"

    # say L74 pla
    old "Yes..."
    new "Ja..."

    # say L78 lis
    old "Keep breathing, that is the key, your muscles must get extremely relaxed, my hands will clean the bad energies, let them do their job."
    new "Weiter atmen, das ist der Schlüssel, deine Muskeln müssen extrem entspannt sein, meine Hände werden die schlechten Energien entfernen, lass sie ihre Arbeit tun."

    # say L82 lis
    old "Please let yourself go, do not think about anything else, I will move faster so you can't release the tension, so you can let the chakra muladhara to be cleaned."
    new "Lass dich einfach gehen, denk an nichts anderes, ich werde schneller werden, damit du die Anspannung nicht loslassen kannst, damit das Chakra Muladhara gereinigt werden kann."

    # say L106 lis
    old "Do you feel the negative chakra leaving?"
    new "Spürst du, wie der negative Chakra abfließt?"

    # say L108 lis
    old "Let it out... Breath and let it out."
    new "Lass es raus... Atme und lass es raus."

    # say L113 pla
    old "Phew..."
    new "Puh..."

    # say L114 lis
    old "Wow, that was wonderful, our job had abundant results."
    new "Wow, das war wunderbar, unsere Arbeit hat reiche Früchte getragen."

    # say L129 lis
    old "Do you feel my boobs?"
    new "Spürst du meine Titten?"

    # say L133 lis
    old "Let it move... Feel me, I can see your body is doing it great..."
    new "Lass es sich bewegen... Spür mich, ich sehe, dass dein Körper es großartig macht..."

    # say L137 lis
    old "I can see it's hard to fight with your chakra muladhara but we can try harder than that, stay focused and just release the negative energy..."
    new "Ich sehe, dass es schwer ist, mit deinem Chakra Muladhara zu kämpfen, aber wir können härter daran arbeiten, bleib konzentriert und lass die negative Energie einfach los..."

    # say L160 lis
    old "Yes, breath, and feel how your energy is moving...  I want you to let it go..."
    new "Ja, atme und spür, wie deine Energie fließt... Lass es einfach los..."

    # say L166 lis
    old "Do you feel relieved?"
    new "Spürst du Erleichterung?"

    # say L168 lis
    old "Great, we will need to continue working on it but you are doing amazing."
    new "Großartig, wir müssen weiter daran arbeiten, aber du machst unglaublich gut."

    # say L233 lis
    old "Oh, yes... Just like that..."
    new "Oh, ja... Genau so..."

    # say L237 lis
    old "You really have a big cock... It feels... Good."
    new "Du hast wirklich einen großen Schwanz... Es fühlt sich... Gut an."

    # say L241 lis
    old "Wow, uhhh, yes [pla] keep doing it..."
    new "Wow, uhhh, ja [pla] mach weiter..."

    # say L264 pla
    old "Lisa, I'm goig to c- cum..."
    new "Lisa, ich komme..."

    # say L265 lis
    old "Oh, cum all over me."
    new "Oh, spritz alles auf mich."

    # say L289 lis
    old "Feel the fire of the universe with each kiss, you must know the universe is healing your body."
    new "Spür die Kraft des Universums bei jedem Kuss, du musst wissen, dass das Universum deinen Körper heilt."

    # say L290 pla
    old "Yeah, I can feel it."
    new "Ja, ich spüre es."

    # say L294 lis
    old "I will do it more intense so you feel the healing power of the universe at its fullest expression."
    new "Ich werde es intensiver machen, damit du die heilende Kraft des Universums in ihrer vollen Ausdrucksform spürst."

    # say L298 lis
    old "I will take that energy out."
    new "Ich werde diese Energie rausnehmen."

    # say L321 pla
    old "I- I'm goin-"
    new "Ich- Ich geh-"

    # say L322 lis
    old "Let it flow [pla], let it flow."
    new "Lass es fließen [pla], lass es fließen."

    # say L340 lis
    old "Oh [pla], what amazing energy you have."
    new "Oh [pla], was für eine unglaubliche Energie du hast."

    # say L344 lis
    old "Oh yes, I'm feeling the universe through you..."
    new "Oh ja, ich spüre das Universum durch dich..."

    # say L348 lis
    old "OH GOD, I NEED IT HARDER INSIDE OF ME!"
    new "OH GOTT, ICH BRAUCHE ES FESTER IN MIR!"

    # say L371 lis
    old "Let all your energy cum inside me, I need to feel it."
    new "Lass all deine Energie in mir explodieren, ich muss es spüren."

    # say L391 mik
    old "Ohh man, look at that, this is so fucking hot!"
    new "Oh Mann, schau dir das an, das ist so verdammt heiß!"

    # say L392 pla
    old "Hey, keep it down, they could hear you."
    new "Hey, leiser, die könnten uns hören."

    # say L393 mik
    old "Alright, alright."
    new "Okay, okay."

    # say L397 mik
    old "God damn it! This is getting me on!"
    new "Verdammt nochmal! Das bringt mich echt auf!"

    # say L398 pla
    old "Hey! Keep it down!"
    new "Hey! Mach leiser!"

    # say L399 mik
    old "Listen, dude, do you think you could leave for a couple of minutes?"
    new "Hör mal, Alter, könntest du für ein paar Minuten verschwinden?"

    # say L400 pla
    old "What? Hell no! What the hell are you thinking?"
    new "Was? Auf keinen Fall! Was soll das überhaupt heißen?"

    # say L404 mik
    old "Oh they're going faster! This is fucking amazing."
    new "Oh, die werden schneller! Das ist echt unglaublich."

    # say L405 pla
    old "I'm glad you like it man, but hey, we gotta go."
    new "Ich freu mich, dass dir's gefällt, Mann, aber hey, wir müssen los."

    # say L406 mik
    old "Ohhh no, please just a little more, I think they're about to finish."
    new "Ohhh nein, bitte nur noch ein bisschen, ich glaube, sie sind gleich soweit."

    # say L407 pla
    old "Hmm, alright."
    new "Hmm, okay."

    # say L430 mik
    old "Oh wow, that's the fucking best. I wasn't expecting that today."
    new "Oh wow, das ist der Fucking Hammer. Das habe ich heute echt nicht erwartet."

    # say L431 mik
    old "Thanks man."
    new "Danke Mann."

    # say L432 pla
    old "No problem bro, but let's get out of here before they see us."
    new "Kein Problem, Kumpel, aber lass uns hier verschwinden, bevor sie uns sehen."

    # say L444 lis
    old "Mmm, this is just what I needed."
    new "Mmm, das war genau das, was ich gebraucht habe."

    # say L448 pla
    old "{i}(What a weird position to do that.){/i}"
    new "{i}Was für eine seltsame Position, um das zu machen. {/i}"

    # say L449 pla
    old "{i}(I guess it has to do with her whole yoga thing.){/i}"
    new "{i}(Schätze, das hat was mit ihrer ganzen Yogasache zu tun.){/i}"

    # say L450 lis
    old "Oh yes! I can sense the energy moving!"
    new "Oh ja! Ich kann die Energie fließen spüren!"

    # say L455 lis
    old "Oh! Oh, I can feel the energy flowing."
    new "Oh! Oh, ich kann die Energie fließen spüren."

    # say L457 lis
    old "Oh! Oh yeah!"
    new "Oh! Oh ja!"

    # say L481 lis
    old "Ah! Ah! That's right!"
    new "Ah! Ah! Das ist es!"

    # say L482 lis
    old "I can feel it! My Muladhara chakra is in full harmony!"
    new "Ich spüre es! Mein Muladhara-Chakra ist voll im Einklang!"

    # say L489 lis
    old "That was absolutely perfect!"
    new "Das war absolut perfekt!"

    # say L490 lis
    old "And just what I needed, what a wonderful thing."
    new "Und genau das, was ich gebraucht habe, was für eine wunderbare Sache."

    # say L491 lis
    old "I can feel the energy flowing through my entire body."
    new "Ich spüre die Energie durch meinen ganzen Körper fließen."

    # say L492 lis
    old "I'm ready to continue my day now."
    new "Ich bin bereit, meinen Tag fortzusetzen."


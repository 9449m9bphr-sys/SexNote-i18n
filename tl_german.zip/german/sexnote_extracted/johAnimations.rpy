# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/johAnimations.rpy
translate german strings:

    # say L6 joh
    old "Perfect, you are doing it so good, don't stop..."
    new "Perfekt, Sie machen das so gut, hören Sie nicht auf..."

    # say L8 joh
    old "Please keep in mind the places where it's better to touch, where you can make your patient feel even more..."
    new "Bitte beachten Sie die Stellen, an denen es besser ist zu berühren, wo Sie Ihren Patienten noch mehr fühlen lassen können."

    # say L15 joh
    old "You are doing perfect, don't stop, it feels so good."
    new "Sie machen das perfekt, hören Sie nicht auf, es fühlt sich so gut an."

    # say L16 pla
    old "Slurp... Slurp..."
    new "Schluck... Schluck..."

    # say L39 joh
    old "Ahh, I want you to do it faster!... Go as fast as you c- can."
    new "Ahh, ich will, dass Sie schneller werden!... So schnell, wie Sie k- können."

    # say L40 joh
    old "Yeah, Yeah, YEAH! keep moving... I- I am cuming! AHH!"
    new "Ja, ja, JA! Mach weiter... I- Ich komme! AHH!"

    # say L59 joh
    old "Please, just let me to enjoy your dick..."
    new "Bitte, lassen Sie mich Ihren Schwanz genießen..."

    # say L61 joh
    old "It's so hard... I just wanted to have it since I saw you fucking Angelina."
    new "Es ist so hart... Ich wollte es schon haben, seit ich dich mit Angelina ficken gesehen habe."

    # say L64 joh
    old "I want you to feel the tip of my tongue playing with the head of your dick..."
    new "Ich will, dass Sie die Spitze meiner Zunge spüren, die mit der Eichel Ihres Schwanzes spielt..."

    # say L65 pla
    old "(Oh God...)"
    new "Oh Gott..."

    # say L70 joh
    old "I'm really really wet right now... Do you like my mouth?"
    new "Ich bin wirklich richtig nass gerade... Magst du meinen Mund?"

    # say L71 pla
    old "Oh God, yes, it feels really good..."
    new "Oh Gott, ja, es fühlt sich wirklich gut an..."

    # say L74 joh
    old "I need you to feel my mouth, to internalize the pleasure you are feeling, it's something you should handle. "
    new "Ich brauche, dass Sie meinen Mund spüren, die Lust, die Sie empfinden, internalisieren. Das ist etwas, das Sie bewältigen sollten."

    # say L80 joh
    old "Who do you prefer to suck your cock?  Me... Slurp... Or... Slurp... Angelina?"
    new "Wer soll deinen Schwanz lutschen? Ich... Schlürf... Oder... Schlürf... Angelina?"

    # say L82 joh
    old "Are you really considering it?"
    new "Stellen Sie sich das wirklich vor?"

    # say L85 joh
    old "Can you feel my tongue? Do you feel how wet it is now, feel the tip playing with your dick's head..."
    new "Können Sie meine Zunge spüren? Spüren Sie, wie nass sie jetzt ist, wie die Spitze mit der Eichel Ihres Schwanzes spielt..."

    # say L86 pla
    old "Yes, I- I can."
    new "Ja, ich- ich kann."

    # say L106 joh
    old "I'm gonna show you WHO is the MASTER..."
    new "Ich werde dir zeigen, WER der MEISTER ist..."

    # say L110 joh
    old "I'm going to do it with all I have, so be ready."
    new "Ich werde es mit allem, was ich habe, tun, also seien Sie bereit."

    # say L129 joh
    old "This is how a master do it..."
    new "So macht ein Meister das..."

    # say L133 joh
    old "Stay focused, you can't cum."
    new "Bleiben Sie konzentriert, Sie dürfen nicht kommen."

    # say L134 pla
    old "I won't."
    new "Ich werde nicht."

    # say L135 joh
    old "I hope so!"
    new "Ich hoffe es!"

    # say L139 joh
    old "So? What do you think now? Who is better?"
    new "So? Was denken Sie jetzt? Wer ist besser?"

    # say L140 pla
    old "Ahh... Y- you... You are better..."
    new "Ahh... S- Sie... Sie sind besser..."

    # say L141 joh
    old "That's what I wanted to ear..."
    new "Das wollte ich hören..."

    # say L144 joh
    old "I will speed up a bit, I know you will enjoy it."
    new "Ich werde ein bisschen schneller werden, ich weiß, dass Ihnen das gefallen wird."

    # say L152 joh
    old "I'm going to make you cum NOW!"
    new "Ich werde dich jetzt kommen lassen!"

    # say L154 joh
    old "You are doing it better than I expected... But you can't against my full speed."
    new "Sie machen es besser, als ich erwartet habe... Aber gegen meine volle Geschwindigkeit kommen Sie nicht an."

    # say L186 pla
    old "I- I think I'm going to-"
    new "Ich glaube, ich komme gleich-"

    # say L187 joh
    old "Oh, please let it go, spill it over my mouth..."
    new "Oh, bitte lassen Sie es los, lassen Sie es über meinen Mund laufen..."

    # say L188 pla
    old "A- are you sure?"
    new "Bist du dir sicher?"

    # say L189 joh
    old "Yess, I want to feel all you cum in my mouth, give it all to me!"
    new "Ja, ich will alles von dir schlucken, gib es mir!"

    # say L200 joh
    old "Definetly, I need to ride this cock, I want it all inside me, lie on the bed I need you to fuck me!"
    new "Definitiv, ich muss diesen Schwanz reiten, ich will ihn ganz in mir spüren, leg dich aufs Bett, ich brauche es, dass du mich fickst!"

    # say L202 joh
    old "I don't want any kids game, fuck me really HARD!"
    new "Ich will kein Kinderspiel, ficken Sie mich richtig hart!"

    # say L203 pla
    old "A- alright."
    new "A- in Ordnung."

    # say L219 joh
    old "Listen carefully, I want you to keep a regular rythm, and also an uniform strength..."
    new "Hören Sie genau zu, ich möchte, dass Sie ein regelmäßiges Tempo beibehalten und auch eine gleichmäßige Stärke..."

    # say L220 joh
    old "You need to plan your movements, your energy, I will tell when you can do it faster."
    new "Sie müssen Ihre Bewegungen und Ihre Energie planen, ich sage Ihnen, wann Sie schneller werden können."

    # say L225 joh
    old "Ahh... I like it, keep it like that..."
    new "Ahh... Ich mag es, mach weiter so..."

    # say L228 joh
    old "Oh, now faster, I'm very wet, do it harder."
    new "Oh, jetzt schneller, ich bin sehr nass, mach es härter."

    # say L229 pla
    old "O- ok."
    new "O- okay."

    # say L249 joh
    old "POUND ME HARDER!"
    new "HAMMERN SIE MICH FESTER!"

    # say L250 pla
    old "Huh..."
    new "Häh..."

    # say L271 joh
    old "Ahh, do it as hard as you have to, I want you to smash my pussy"
    new "Ahh, machen Sie es so hart wie nötig, ich will, dass Sie meine Pussy zerficken"

    # say L273 joh
    old "Oh yeah, don't stop, don't stop!"
    new "Oh ja, hören Sie nicht auf, hören Sie nicht auf!"

    # say L276 joh
    old "Show me how powerful your dick is, I want you to make cum!"
    new "Zeigen Sie mir, wie mächtig Ihr Schwanz ist, ich will, dass du mich zum Kommen bringst!"

    # say L278 pla
    old "Ughh... "
    new "Ughh..."

    # say L307 joh
    old "Oh God! I'm cumming!! Ahhh! Ahhhh!"
    new "Oh Gott! Ich komme!! Ahhh! Ahhhh!"

    # say L325 joh
    old "Yes, just like this baby..."
    new "Ja, genau so, Baby..."

    # say L326 pla
    old "Gulp..."
    new "Schluck..."

    # say L330 joh
    old "Ahh! Your dick is so good..."
    new "Ahh! Ihr Schwanz ist so gut..."

    # say L332 joh
    old "SO GOOD!!!"
    new "SO GUT!!!"

    # say L335 joh
    old "Ohh yeahh, it's so big!"
    new "Ohh ja, es ist so groß!"

    # say L337 joh
    old "HARDER, HARDER!"
    new "HÄRTER, HÄRTER!"

    # say L362 joh
    old "I'm gonna cum!!!"
    new "Ich komme!!!"

    # say L364 joh
    old "Let's cum together, DON'T STOP, DON'T STOP... AHHH!"
    new "Lassen Sie uns zusammen kommen, HÖREN SIE NICHT AUF, HÖREN SIE NICHT AUF... AHHH!"

    # say L365 pla
    old "Mmmm!! I- I'm coming..."
    new "Mmmm!! I- Ich komme..."

    # say L383 joh
    old "Oh yeah, I'm going to show you how an expert fucks!"
    new "Oh ja, ich werde Ihnen zeigen, wie ein Experte fickt!"

    # say L384 pla
    old "Ughh, It feels amazing..."
    new "Ughh, das fühlt sich unglaublich an..."

    # say L387 joh
    old "Mmmm... Riding you drives me crazy!"
    new "Mmmm... Dich zu reiten treibt mich in den Wahnsinn!"

    # say L388 pla
    old "Oh yess... Please don't stop it... Ahh!"
    new "Oh ja... Bitte hör nicht auf... Ahh!"

    # say L389 joh
    old "Yeah, you like it? Then I'm gonna fuck you harder!"
    new "Ja, das gefällt Ihnen? Dann werde ich Sie noch härter ficken!"

    # say L393 joh
    old "Uhhh... You have really huge cock! I can't fit it all in my pussy."
    new "Uhhh... Sie haben wirklich einen riesigen Schwanz! Ich kriege ihn gar nicht alles in meine Pussy rein."

    # say L394 joh
    old "Fuck me! Fuck me! I want you to fill my cunt of cum."
    new "Ficken Sie mich! Ficken Sie mich! Ich will, dass Sie mich mit Ihrem Sperma füllen."

    # say L419 joh
    old "Yeeeeesss... Yesss... I- I'm cumming!!"
    new "Yeeeeesss... Yesss... I- Ich komme!!"

    # say L420 pla
    old "Ahhhhh... Ughhh..."
    new "Ahhhh... Ughhh..."

    # say L426 joh
    old "Ohh, yes, I feel it inside, that's delicious."
    new "Ohh, ja, ich spüre es drin, das ist köstlich."

    # say L427 joh
    old "Don't even think about stopping... I need more of your cock NOW!"
    new "Denken Sie nicht einmal daran, aufzuhören... Ich brauche mehr von Ihrem Schwanz JETZT!"

    # say L442 joh
    old "Now softly... I wanna feel all your big cook..."
    new "Jetzt sanft... Ich will deinen großen Schwanz ganz spüren..."

    # say L443 joh
    old "Ohh yeahh... Just like that baby..."
    new "Ohh jaahh... Genau so, Liebling..."

    # say L447 joh
    old "Do you like my big boobs? How do they bounce when you fuck me?"
    new "Magst du meine großen Titten? Wie springen sie, wenn du mich fickst?"

    # say L448 pla
    old "Yes, I love your tits!"
    new "Ja, ich liebe deine Titten!"

    # say L449 joh
    old "Then, fuck me faster, with that huge cock!"
    new "Dann fick mich schneller, mit diesem riesigen Schwanz!"

    # say L453 joh
    old "Harder! Fuck me harder! I want you to make me cum as you did with Angelina!"
    new "Fester! Fick mich fester! Ich will, dass du mich kommen lässt, wie du es bei Angelina getan hast!"

    # say L455 joh
    old "OH GOD... I'M GONNA FUCK YOU EVERYDAY..."
    new "OH GOTT... ICH FICK DICH JEDEN TAG..."

    # say L479 pla
    old "I- I going to..."
    new "Ich... ich werde..."

    # say L480 joh
    old "Yes! Cum inside me!"
    new "Ja! Komm in mir!"


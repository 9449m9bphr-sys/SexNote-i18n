# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/MomStory.rpy
translate german strings:

    # say L11 mo1
    old "Hi honey! Your breakfast is ready!"
    new "Hallo Schatz! Dein Frühstück ist fertig!"

    # say L12 pla
    old "Thank you [mo1rel]."
    new "Danke [mo1rel]."

    # say L16 mo1
    old "[pla], I wanted to talk to you..."
    new "[pla], ich wollte mit Ihnen sprechen..."

    # say L19 mo1
    old "I was thinking of a way to improve your relationship with your [mo2rel]."
    new "Ich habe mir überlegt, wie du deine Beziehung zu deiner [mo2rel] verbessern könntest."

    # say L21 mo1
    old "Well, I think if you spend some time with her, it could help her get to know you."
    new "Na ja, ich denke, wenn du etwas Zeit mit ihr verbringst, könnte das helfen, sie besser kennenzulernen."

    # say L22 mo1
    old "You know she's pretty stressed. But only because she's not around enough since she's always working."
    new "Sie wissen ja, sie ist ziemlich gestresst. Aber nur, weil sie nicht oft genug da ist, seit sie immer arbeitet."

    # say L25 mo1
    old "Just try, please? Could you?... For me?"
    new "Versuchen Sie es doch, bitte? Könnten Sie das für mich tun?"

    # say L26 pla
    old "Uhmm... Fine."
    new "Hmm... Okay."

    # say L27 mo1
    old "Great, It's very simple. She needs some help for her job. She's thought about hiring an assistant..."
    new "Super, es ist sehr einfach. Sie braucht ein bisschen Hilfe für ihren Job. Sie hat sich überlegt, einen Assistenten einzustellen..."

    # say L28 mo1
    old "So, I asked her to let you work for her. And of course she will reward you for all your help."
    new "Also, ich habe sie gebeten, dich bei ihr arbeiten zu lassen. Und natürlich wird sie dich für deine Hilfe belohnen."

    # say L30 pla
    old "Alright, alright. I'll help her then..."
    new "Okay, okay. Ich werde ihr dann helfen..."

    # say L35 mo2
    old "Do you have the receipt of-"
    new "Haben Sie den Beleg-"

    # say L38 mo2
    old "Oh, there you are..."
    new "Oh, da sind Sie ja..."

    # say L39 pla
    old "Good morning, [mo2]. How are you today so far?"
    new "Guten Morgen, [mo2]. Wie geht es dir heute bisher?"

    # say L41 mo2
    old "Busy... Did you talk with him. Huh?"
    new "Beschäftigt... Hast du mit ihm gesprochen? Häh?"

    # say L42 mo1
    old "Yes, I just did. And you have nothing to worry about."
    new "Ja, ich habe gerade mit ihm gesprochen. Und Sie müssen sich keine Sorgen machen."

    # say L43 mo2
    old "... He's still a pervert."
    new "... Er ist immer noch ein Perverser."

    # say L44 pla
    old "I'm not a-"
    new "Ich bin kein-"

    # say L45 mo1
    old "He is just a teenager. No need to be rude. Everything is okay."
    new "Er ist einfach ein Teenager. Kein Grund, unhöflich zu sein. Alles ist in Ordnung."

    # say L47 mo2
    old "I will be doing some calls, [pla]. Look for me when you are ready."
    new "Ich werde ein paar Anrufe machen, [pla]. Suchen Sie mich, wenn Sie bereit sind."

    # say L51 pla
    old "Ok. (Geez)"
    new "Okay. (Mann)"

    # say L52 mo1
    old "Anyway, did you want to talk about something?"
    new "Na ja, wolltest du über etwas Bestimmtes sprechen?"

    # say L79 pla
    old "(W- what is she doing?)"
    new "W- was macht sie da?"

    # say L80 mo1
    old "Ohh, sorry I'm trying to apply some sunscreen on my butt, hehehe."
    new "Oh, entschuldige, ich versuche gerade Sonnencreme auf meinen Po zu tupfen, hehehe."

    # say L86 mo1
    old "Hi honey, are you coming to hang out in the pool?"
    new "Hi Schatz, kommst du zum Schwimmen?"

    # say L88 pla
    old "No, I don't want to swim today."
    new "Nein, heute will ich nicht schwimmen."

    # say L90 mo1
    old "Really? It's a shame on this beautiful day."
    new "Wirklich? Das ist schade an so einem schönen Tag."

    # say L92 mo1
    old "Why don't you help me then to apply some sunscreen on my back?"
    new "Warum hilfst du mir dann nicht, etwas Sonnencreme auf den Rücken zu tupfen?"

    # say L99 mo1
    old "Thanks sweetheart."
    new "Danke Schatz."

    # say L105 pla
    old "I'm sorry I have some things to do."
    new "Tut mir leid, ich muss noch ein paar Dinge erledigen."

    # say L107 mo1
    old "Oh, don't worry honey, go and do what you have to do."
    new "Oh, mach dir keine Sorgen, Schatz, geh und mach, was du tun musst."

    # say L109 pla
    old "Ok. See you later."
    new "Okay. Bis später."

    # say L119 mo1
    old "Be sure to cover the entire back."
    new "Stellen Sie sicher, dass Sie den gesamten Rücken abdecken."

    # say L120 pla
    old "I will, don't worry."
    new "Ich werd's machen, mach dir keine Sorgen."

    # say L137 pla
    old "I think that's it with your back, would you need anything else?"
    new "Ich denke, das war's mit deinem Rücken, brauchst du noch was anderes?"

    # say L140 mo1
    old "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} In fact, I would really appreciate it if you help me with some foot massages."
    new "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} Tatsächlich würde ich es sehr schätzen, wenn Sie mir bei ein paar Fußmassagen helfen könnten."

    # say L141 pla
    old "Okay, no problem."
    new "Okay, kein Problem."

    # say L156 pla
    old "Hmm, there still some areas that I think might need some Sunscreen."
    new "Hmm, da sind noch ein paar Stellen, die vielleicht noch etwas Sonnencreme brauchen."

    # say L175 pla
    old "(Should I try to go further?)"
    new "Soll ich versuchen, weiterzugehen?"

    # say L178 pla
    old "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} (I think is a good moment to try the Sauron's Mouth.)"
    new "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} Ich denke, es ist ein guter Moment, um den Mund des Sauron auszuprobieren."

    # say L179 pla
    old "{b}Sauron's mouth:{/b} [mo1rel], I'll give you a foot massage again, you just stay calm."
    new "{b}Saurons Mund:{/b} [mo1rel], ich mache dir wieder einen Fußmassage, bleib einfach ruhig."

    # say L181 pla
    old "(I think it works... Let's see.)"
    new "Ich denke, es funktioniert... Lass uns sehen."

    # say L191 pla
    old "Well it's done. I think you are perfect now."
    new "Na gut, ich denke, du bist jetzt perfekt."

    # say L202 pla
    old "Ok... (Maybe next time.)"
    new "Ok... (Vielleicht das nächste Mal.)"

    # say L233 mo1
    old "Hey, [pla], I wanted to ask if you could come with me to the doctor's office."
    new "Hey, [pla], ich wollte dich fragen, ob du mit mir zum Arzt kommen kannst."

    # say L235 pla
    old "What! Why? Did something happen to you? Are you sick?"
    new "Was! Warum? Ist dir was passiert? Bist du krank?"

    # say L237 mo1
    old "No, no, it's nothing bad. It's just a routine check up."
    new "Nein, nein, es ist nichts Schlimmes. Es ist nur eine Routineuntersuchung."

    # say L239 pla
    old "Oh, ok. Sure no problem"
    new "Oh, ok. Klar, kein Problem."

    # say L241 mo1
    old "Perfect! Wait for me while I get changed, okay?"
    new "Perfekt! Warte auf mich, während ich mich umziehe, okay?"

    # say L245 mo1
    old "Thank you, baby."
    new "Danke, Schatz."

    # say L259 mo1
    old "I'm ready! How do I look?"
    new "Ich bin fertig! Wie sehe ich aus?"

    # say L261 pla
    old "You look... (So hot) V- Very nice [mo1rel]."
    new "Du siehst... (So heiß) V- Sehr schön aus [mo1rel]."

    # say L263 mo1
    old "Aww, thanks, honey... Ok, let's head to the doctor's office."
    new "Aww, danke, Schatz... Okay, lass uns zum Arzt gehen."

    # say L270 pla
    old "Ok, we're here. What's the appointment about, [mo1rel]?"
    new "Ok, wir sind da. Worum geht's bei dem Termin, [mo1rel]?"

    # say L272 mo1
    old "Oh... It's called a mammogram. It's to make sure there's no problem with my boobies. Hehe."
    new "Oh... Es heißt Mammogramm. Damit stellen wir sicher, dass mit meinen Brüsten alles in Ordnung ist. Hehe."

    # say L274 pla
    old "Oh... ok, I understand... And what should we do?"
    new "Oh... okay, ich verstehe... Und was machen wir jetzt?"

    # say L276 mo1
    old "Well, it's time for the appointment! So we should go to nurse Mary's office right now."
    new "Na dann, es ist Zeit für den Termin! Wir sollten jetzt gleich zu Schwester Marys Büro gehen."

    # say L278 pla
    old "Ok, Come on..."
    new "Okay, komm schon..."

    # say L286 mo1
    old "Good morning..."
    new "Guten Morgen..."

    # say L289 mar
    old "Hello, How have you been? Long-time, no see."
    new "Hallo, wie geht es Ihnen? Lange nicht gesehen."

    # say L291 mar
    old "Ohh, and who is this handsome young man? Are you trying out young meat? "
    new "Ohh, und wer ist dieser hübsche junge Mann? Probierst du etwa frisches Fleisch aus?"

    # say L296 mo1
    old "Oh Mary. Haha. Don't be silly, I'm his [mo1rel], he's just joining me for my appointment."
    new "Oh Mary. Haha. Sei nicht albern, ich bin seine [mo1rel], er begleitet mich nur zu meinem Termin."

    # say L298 mar
    old "Oh, I see. Right... talking about the test... I have some bad news... The technical machine to do the mammogram is broken at the moment."
    new "Oh, ich verstehe. Richtig... beim Test... Ich habe schlechte Nachrichten... Die technische Maschine für die Mammografie ist momentan defekt."

    # say L300 mar
    old "So we will have to do it in the old fashioned way... So I get to give you a good massage on those babies ..."
    new "Dann machen wir es auf die alte Schule... Dann darf ich dir mal so richtig die Titten kneten..."

    # say L302 mo1
    old "Hehehe. It's fine Mary, as you wish..."
    new "Hehehe. Ist schon gut, Mary, machen Sie es wie Sie möchten..."

    # say L304 mar
    old "Well now, Sue, take off your clothes..."
    new "Na dann, Sue, zieh dich aus..."

    # say L306 pla
    old "... (Oh crap)"
    new "... (Oh Scheiße)"

    # say L308 pla
    old "Ehh ... Well ... I'll just head on out, to give you guys some privacy."
    new "Ehh... Na ja... Ich geh dann mal, damit ihr eure Privatsphäre habt."

    # say L310 mar
    old "Hey! Wait there. What a shy one you have here. Don't worry, sugar. This is nothing you haven't seen before."
    new "Hey! Warte mal. Was für eine Schüchterne du hier hast. Mach dir keine Sorgen, Süßer. Das hast du schon oft genug gesehen."

    # say L312 mar
    old "Besides, she won't get naked. Haha. Don't worry. This is very professional."
    new "Außerdem, sie wird sich nicht ausziehen. Haha. Mach dir keine Sorgen. Das hier ist sehr professionell."

    # say L314 pla
    old "Oh. Ok, then..."
    new "Oh. Okay, dann..."

    # say L320 mar
    old "Let's see those babies!... I'm going to massage them gently. Tell me, how does it feel?"
    new "Lass mal sehen!... Ich werde sie sanft massieren. Sag mir, wie sich das anfühlt?"

    # say L321 mar
    old "Wow, I didn't remember them being so big... Lucky you!"
    new "Wow, ich hatte sie gar nicht mehr so groß in Erinnerung... Glücklicherweise du!"

    # say L323 pla
    old "... (This is...)"
    new "... (Das ist...)"

    # say L324 mar
    old "Do you feel any pain?"
    new "Spürst du irgendwelche Schmerzen?"

    # say L326 mo1
    old "No, not at all. In fact, it feels very... good..."
    new "Nein, gar nicht. Im Gegenteil, es fühlt sich sehr... gut... an."

    # say L327 mar
    old "Hmm... Honestly, I haven't done this manually for a long time. I can't feel anything... I'm going to do it a little harder, ok?"
    new "Hmm... Ehrlich gesagt, habe ich das schon lange nicht mehr manuell gemacht. Ich spüre gar nichts... Ich werde es ein bisschen fester machen, okay?"

    # say L331 mar
    old "Well, that's it for now..."
    new "Na gut, das war's fürs Erste..."

    # say L335 mar
    old "I still couldn't feel anything..."
    new "Ich konnte immer noch nichts spüren..."

    # say L337 mar
    old "So, I would like you to come again. We can do the test again and be more thorough. How does Monday sound?"
    new "Dann würde ich dich gerne noch einmal sehen. Wir können den Test wiederholen und gründlicher vorgehen. Wie klingt Montag für dich?"

    # say L339 mo1
    old "Monday is perfect."
    new "Montag passt perfekt."

    # say L341 mar
    old "Ok, then Thursday, we will try again. It was really nice to see you again!"
    new "Ok, dann Donnerstag, wir werden es noch einmal versuchen. Es war wirklich schön, dich wiederzusehen!"

    # say L343 mo1
    old "Likewise, Mary."
    new "Ebenso, Mary."

    # say L345 mar
    old "See you later, young man..."
    new "Bis später, junger Mann..."

    # say L347 pla
    old "...See you later..."
    new "Bis später..."

    # say L367 mo1
    old "Hi, honey! Do you want to join me?"
    new "Hi, Schatz! Willst du mich begleiten?"

    # say L377 pla
    old "I am sorry, [mo1rel]. I'm a little tired. I'm gonna go to sleep."
    new "Tut mir leid, [mo1rel]. Ich bin ein bisschen müde. Ich werde schlafen gehen."

    # say L379 mo1
    old "Don't worry, honey. Go to sleep. I will watch a movie then head out myself."
    new "Keine Sorge, Schatz. Schlaf gut. Ich werde mir einen Film ansehen und dann auch ins Bett gehen."

    # say L381 pla
    old "Ok. Good night."
    new "Ok. Gute Nacht."

    # say L383 mo1
    old "Sweet dreams, dear."
    new "Sweet dreams, Liebling."

    # menu L390 
    old "Sure"
    new "Klar"

    # say L394 pla
    old "Are you sure, I think you drank a lot and should rest..."
    new "Bist du sicher? Ich glaube, du hast ziemlich viel getrunken und solltest dich ausruhen..."

    # say L396 mo1
    old "Awww, don't worry honey... I'm fine, I just want to relax a little..."
    new "Ach, mach dir keine Sorgen Schatz... Mir geht es gut, ich will nur ein bisschen entspannen..."

    # say L398 mo1
    old "I also like your company and your big-"
    new "Ich mag auch deine Gesellschaft und dein großes-"

    # say L402 mo1
    old "Your big... Heart is what I meant. Oh, come on, don't leave me alone, I want some company, please?"
    new "Ihr großes... Herz meine ich. Oh, komm schon, lass mich nicht allein, ich will Gesellschaft, bitte?"

    # say L406 mo1
    old "Great, you are the best!"
    new "Super, Sie sind die Beste!"

    # say L408 mo1
    old "But this time I choose the movie"
    new "Aber dieses Mal wähle ich den Film"

    # say L419 mo1
    old "Great, honey! What movie would you like to watch?"
    new "Großartig, Schatz! Welchen Film möchtest du denn sehen?"

    # menu L422 
    old "Romance"
    new "Romanze"

    # say L425 mo1
    old "Ohh, I love these kind of movies!"
    new "Ohh, ich liebe solche Filme!"

    # say L427 pla
    old "Great, let's enjoy it!"
    new "Super, lass uns es genießen!"

    # menu L436 
    old "Action"
    new "Aktion"

    # say L439 mo1
    old "This is your favorite type of movie, isn't it?"
    new "Das ist doch dein Lieblingsfilm, oder?"

    # say L441 pla
    old "Yup, but if you want, we can watch something else..."
    new "Klar, aber wenn du willst, können wir auch was anderes gucken..."

    # say L443 mo1
    old "Ohh no, don't worry honey. I'm happy to spend time with you."
    new "Oh nein, mach dir keine Sorgen, Schatz. Ich freue mich, Zeit mit dir zu verbringen."

    # say L454 mo1
    old "Are you sure? I don't want you to have any nightmares."
    new "Sind Sie sicher? Ich will nicht, dass Sie Albträume bekommen."

    # say L456 pla
    old "Hahaha. I can handle it, [mo1rel]."
    new "Hahaha. Ich pack das schon, [mo1rel]."

    # say L467 mo1
    old "Wait... Before we start, let me get a glass of wine. I want to relax a little and enjoy the movie."
    new "Warte... Bevor wir anfangen, hole ich mir ein Glas Wein. Ich will mich ein bisschen entspannen und den Film genießen."

    # say L469 pla
    old "Ok. No problem. (Hmm.)"
    new "Okay. Kein Problem. (Hmm.)"

    # say L471 mo1
    old "Thanks, honey!"
    new "Danke, Schatz!"

    # say L479 mo1
    old "Perfect! A movie night and a good glass of wine. What a great combination. Do you want a bit of wine, too, sugar?"
    new "Perfekt! Ein Filmabend und ein gutes Glas Wein. Was für eine tolle Kombination. Möchtest du auch ein bisschen Wein, Schatz?"

    # say L481 pla
    old "I'm fine for now."
    new "Ich bin gut so, danke."

    # say L483 mo1
    old "Ok, honey. Let's start the movie"
    new "Ok, Schatz. Lass uns das Movie starten."

    # say L512 mo1
    old "Wow, this movie is great, isn't it, honey?"
    new "Wow, dieser Film ist toll, oder, Schatz?"

    # say L513 pla
    old "Yeah, is pretty awesome-"
    new "Ja, ist ziemlich toll."

    # say L521 mo1
    old "Hmm, it looks like you are ready for the best moment of movie night..."
    new "Hmm, es sieht so aus, als wärst du bereit für den besten Moment des Filmabends..."

    # say L522 pla
    old "... W- what do you mean..."
    new "... W- was meinst du damit..."

    # say L523 mo1
    old "What I mean is... Take that big buddy of yours out..."
    new "Was ich meine ist... Holen Sie Ihren großen Freund raus..."

    # say L527 mo1
    old "Mmm, nice!... What do you want today, baby?"
    new "Mmm, schön!... Was willst du heute, Schatz?"

    # say L531 mo1
    old "Good choice! Let [mo1rel] handle this beast."
    new "Gute Wahl! Lassen Sie [mo1rel] sich darum kümmern."

    # say L540 mo1
    old "You really like this, huh?..."
    new "Sie gefällt Ihnen wirklich, oder?..."

    # say L550 mo1
    old "You read my mind..."
    new "Sie lesen meinen Gedanken..."

    # say L581 mo1
    old "Hmmm, honey? This movie is exciting you that much?"
    new "Hmmm, Schatz? Dieser Film macht dich so aufgeregt?"

    # say L582 pla
    old "I'm sorry, [mo1rel]. I can't handle it. I honestly didn't mean to..."
    new "Es tut mir leid, [mo1rel]. Ich schaffe es nicht. Ehrlich, ich wollte das nicht..."

    # say L583 mo1
    old "It's ok. Don't you worry. Let me give you a hand with that. I don't want you to be like this the whole movie."
    new "Es ist okay. Mach dir keine Sorgen. Lass mich dir helfen. Ich will nicht, dass du den ganzen Film so bist."

    # say L603 mo1
    old "Hmm, honey? Are you getting hard again?"
    new "Hmm, Schatz? Wird es schon wieder hart?"

    # say L604 pla
    old "Sorry [mo1rel], I didn't mean to..."
    new "Entschuldigung [mo1rel], ich wollte nicht..."

    # say L605 mo1
    old "It's ok. actually I wanted to try something a bit different this time..."
    new "Es ist okay. Eigentlich wollte ich dieses Mal etwas anderes ausprobieren..."

    # say L607 mo1
    old "Don't worry honey, you are going to love it."
    new "Mach dir keine Sorgen, Schatz, du wirst es lieben."

    # say L618 mo1
    old "The movie was great!"
    new "Der Film war toll!"

    # say L620 pla
    old "Yeah, I didn't expect that ending at all..."
    new "Ja, ich habe das Ende überhaupt nicht erwartet..."

    # say L622 mo1
    old "Thanks for spending time with me, [pla]."
    new "Danke, dass Sie Zeit mit mir verbracht haben, [pla]."

    # say L624 pla
    old "You don't have to thank me, [mo1rel]. I enjoy your company!"
    new "Du musst dich nicht bedanken, [mo1rel]. Ich genieße deine Gesellschaft!"

    # say L626 mo1
    old "Aww, that makes me happy. If you want to watch another movie, come to see me tomorrow night."
    new "Ach, das freut mich. Wenn du noch einen Film gucken möchtest, komm morgen Abend zu mir."

    # say L627 mo1
    old "I know we will have a good time together."
    new "Ich weiß, dass wir es gut miteinander haben werden."

    # say L628 pla
    old "You can count on it!"
    new "Du kannst dich drauf verlassen!"

    # say L630 mo1
    old "Ok, dear. Let's go to sleep."
    new "Ok, Liebling. Lass uns schlafen gehen."

    # say L632 pla
    old "Alright, [mo1rel]. Good night."
    new "Alles klar, [mo1rel]. Gute Nacht."

    # say L634 mo1
    old "Sweet dreams, honey..."
    new "Süße Träume, Schatz..."

    # say L650 mo1
    old "[pla]... I- I'm so sorry... I don't know what came over me... I'm your [mo1rel]! I shouldn't have... It must have been all the wine I drank..."
    new "[pla]... Ich- Ich bin so sorry... Ich weiß nicht, was über mich gekommen ist... Ich bin deine [mo1rel]! Ich hätte nicht... Es muss der Wein gewesen sein, den ich getrunken habe..."

    # say L652 pla
    old "Uhh, there's nothing wrong with that, you're just helping me... Also, I really enjoyed it a lot..."
    new "Uhh, da ist nichts falsch dran, du hast mir nur geholfen... Und ich habe es echt genossen..."

    # say L654 mo1
    old "Do you really think that?  "
    new "Finden Sie das wirklich?"

    # say L655 mo1
    old "Well... I haven't done that for years and I was trying to make you feel better. So, yeah, maybe there's nothing wrong with that."
    new "Na ja... Ich habe das schon seit Jahren nicht mehr getan und ich wollte dir einfach helfen. Also, vielleicht ist daran auch nichts Falsches."

    # say L657 pla
    old "Yeah, also, you're taking care of me so I can release all my repression. and I really appreciate it."
    new "Ja, außerdem kümmert du dich um mich, damit ich all meine Hemmungen ablegen kann. Und ich schätze das wirklich."

    # say L659 mo1
    old "Awww, of course, honey. You always make me feel better... Now let's clean this up... And remember, don't to tell anyone."
    new "Ach, natürlich, Schatz. Du machst mich immer glücklich... Jetzt lass uns das hier aufräumen... Und vergiss nicht, niemandem davon zu erzählen."

    # say L661 pla
    old "Don't worry, I won't."
    new "Keine Sorge, ich werd's niemandem sagen."

    # say L663 mo1
    old "That's a good boy. Let's go to bed."
    new "Das ist ein braver Junge. Lass uns ins Bett gehen."

    # say L665 pla
    old "Ok, [mo1rel]. Good night."
    new "Ok, [mo1rel]. Gute Nacht."

    # say L666 mo1
    old "Good night, honey. Sleep well."
    new "Gute Nacht, Schatz. Schlaf gut."

    # say L678 mo1
    old "That movie was great!"
    new "Der Film war toll!"

    # say L680 pla
    old "Yeah, it was fun..."
    new "Ja, es war lustig..."

    # say L682 mo1
    old "You know what? We could continue this upstairs."
    new "Wissen Sie was? Wir könnten das oben fortsetzen."

    # menu L685 
    old "Hell yeah"
    new "Hell ja"

    # say L687 pla
    old "Oh really?, Well what are we waiting for?"
    new "Oh wirklich?, Na worauf warten wir dann noch?"

    # say L688 mo1
    old "That's what I thought."
    new "Das dachte ich mir."

    # menu L692 
    old "Not tonight"
    new "Nicht heute Nacht"

    # say L694 mo1
    old "Ok honey, anyway if you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "Ok, Schatz, wenn du morgen noch einen Film gucken willst, komm einfach zu mir. Ich weiß, wir werden es gut miteinander haben..."

    # say L698 mo1
    old "Ok, honey. Let's go to sleep."
    new "Ok, honey. Lass uns schlafen gehen."

    # say L702 mo1
    old "Sweet dreams, honey. Sleep well."
    new "Schlaf gut, Schatz. Träum süß."

    # say L719 mo1
    old "Thanks for spending time with me, baby."
    new "Danke, dass du Zeit mit mir verbringst, Schatz."

    # say L721 pla
    old "You don't have to thank me [mo1rel]. I really enjoy it!"
    new "Du musst dich nicht bedanken [mo1rel]. Ich genieße es wirklich!"

    # say L723 mo1
    old "I'm glad to hear that. If you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "Ich freue mich, das zu hören. Wenn du noch einen Film gucken möchtest, komm morgen zu mir. Ich weiß, wir werden es gut miteinander haben..."

    # say L743 mo1
    old "Looks like someone is really happy for the movie..."
    new "Sieht aus, als wäre jemand wirklich glücklich über den Film..."

    # say L745 mo1
    old "You know what? I want to have sex here..."
    new "Sie wissen was? Ich will hier Sex haben..."

    # say L747 pla
    old "... Are you sure?"
    new "... Bist du sicher?"

    # say L748 mo1
    old "What is the difference, we already had sex..."
    new "Was macht der Unterschied, wir hatten schon Sex..."

    # say L772 mo1
    old "Good morning [pla]."
    new "Guten Morgen [pla]."

    # say L774 pla
    old "Good morning [mo1rel]."
    new "Guten Morgen [mo1rel]."

    # say L776 mo1
    old "I wanted to talk to you about yesterday ..."
    new "Ich wollte mit Ihnen über gestern sprechen..."

    # say L778 pla
    old "I- I'm really sorry... It wasn't-"
    new "Ich- Ich bin wirklich sorry... Es war nicht-"

    # say L780 mo1
    old "No, I want to apologize for the way I treated you ..."
    new "Nein, ich möchte mich für meine Behandlung von Ihnen entschuldigen..."

    # say L782 pla
    old "You want to... Apologize?"
    new "Du willst... Entschuldigungen machen?"

    # say L784 mo1
    old "Yes, I think I was very rude with you, but please understand, it was a bit shocking for me..."
    new "Ja, ich denke, ich war sehr unhöflich zu Ihnen, aber bitte verstehen Sie, es war für mich auch ein Schock..."

    # say L788 mo1
    old "I mean, I don't want you to think that I judge you, I know you're going through a lot."
    new "Ich meine, ich will nicht, dass du denkst, ich urteile über dich, ich weiß, dass du viel durchmachst."

    # say L790 mo1
    old "And I know this is hard for you, so I want you to know that I'm not mad at you."
    new "Und ich weiß, dass es für dich schwer ist, deshalb will ich, dass du weißt, dass ich dir nicht böse bin."

    # say L793 mo1
    old "Yes, In fact I think it was some kind of my fault..."
    new "Ja, ich denke, es war irgendwie auch meine Schuld..."

    # say L794 pla
    old "Your fault? W- what do you mean?"
    new "Deine Schuld? W-was meinst du damit?"

    # say L796 mo1
    old "I think I should have helped you more."
    new "Ich denke, ich hätte dir mehr helfen sollen."

    # say L797 mo1
    old "I mean, [mo2] is a bit strict, she didn't want me to talk to you about, you know... Sexual things."
    new "Ich meine, [mo2] ist ein bisschen streng, sie wollte nicht, dass ich mit dir über, du weißt schon... Sexuelle Dinge rede."

    # say L799 mo1
    old "And now you're a bit repressed, that's why your hormones are making you lose your mind."
    new "Und jetzt bist du ein bisschen zurückhaltend, deshalb machen dich deine Hormone wahnsinnig."

    # say L800 mo1
    old "And do things that... You shouldn't do."
    new "Und Dinge tust, die du nicht tun solltest."

    # say L801 pla
    old "I- it was not my intention."
    new "Ich- es war nicht meine Absicht."

    # say L802 mo1
    old "I know honey... I know this can be difficult for you, but if you can't control yourself in front of your [mo1rel]... It really worries me."
    new "Ich weiß, Schatz... Ich weiß, dass das für dich schwierig sein kann, aber wenn du dich vor deiner [mo1rel] nicht unter Kontrolle hast... Das macht mir wirklich Sorgen."

    # say L803 pla
    old "I won't do it again, I promise."
    new "Ich werde es nicht wieder tun, versprochen."

    # say L804 mo1
    old "Actually, what worries me is that you get to do it at school or in front of any other girl."
    new "Was mich wirklich besorgt, ist, dass du es an der Schule oder vor irgendeinem anderen Mädchen tust."

    # say L805 pla
    old "W- what? I- I won't-"
    new "W- was? I- ich werd's nicht-"

    # say L806 mo1
    old "It's not under your control, you already show me that."
    new "Das liegt nicht in deiner Kontrolle, das hast du mir schon gezeigt."

    # say L807 pla
    old "I- I'm sorry-"
    new "Ich- Ich bin sorry-"

    # say L808 mo1
    old "And it's my fault. I should have helped you before, now you are facing troubles because of my irresponsibility."
    new "Und es ist meine Schuld. Ich hätte dir früher helfen sollen, jetzt hast du Schwierigkeiten wegen meiner Verantwortungslosigkeit."

    # say L810 mo1
    old "And I have been thinking about it a lot and... I think I have to help you to... Release your, uhm... S- stress."
    new "Und ich habe viel darüber nachgedacht und... Ich denke, ich muss dir helfen, deinen, äh... S- Stress abzubauen."

    # say L811 pla
    old "Uhh, w- what do you mean?"
    new "Uhh, w- was meinst du damit?"

    # say L812 mo1
    old "Hmm you know honey... I'll help you with your... Ahem, load release."
    new "Hmm, du weißt schon, Schatz... Ich helfe dir bei deiner... Ähm, Lastabgabe."

    # say L814 pla
    old "No, [mo1rel], don't worry I can do it by myself..."
    new "Nein, [mo1rel], mach dir keine Sorgen, ich schaffe das alleine..."

    # say L815 mo1
    old "Sorry honey, but apparently you haven't done very well so far."
    new "Tut mir leid, Schatz, aber offensichtlich hast du bisher nicht sehr gut damit zurechtgekommen."

    # say L817 mo1
    old "I know it won't be comfortable for any of us, but I need to make sure you get it right."
    new "Ich weiß, dass es für keinen von uns angenehm sein wird, aber ich muss sicherstellen, dass du es richtig machst."

    # say L818 mo1
    old "I don't want you to keep repressing yourself and that it leads you to do worse things."
    new "Ich will nicht, dass du dich weiterhin verdrängst und dass es dich zu schlimmeren Dingen führt."

    # say L819 pla
    old "Are you right this is the only way?"
    new "Bist du dir sicher, dass das der einzige Weg ist?"

    # say L821 mo1
    old "Well, the thing is, I don't want [mo2] to realize it, that would really make things more difficult."
    new "Na ja, das Problem ist, ich will nicht, dass [mo2] es bemerkt, das würde die Sache wirklich noch schwieriger machen."

    # say L822 mo1
    old "So the best way is to do it here alone and keep everything between you and me."
    new "Dann ist es am besten, es hier allein zu machen und alles zwischen uns beiden zu belassen."

    # say L824 mo1
    old "Please [pla] don't make it more difficult than it already is."
    new "Bitte [pla] machen Sie es nicht schwieriger, als es schon ist."

    # say L826 mo1
    old "I will help you with a handjo-... Hmm with a massage, to help you relax and release your... Load and that's it."
    new "Ich werde dir mit einer Handmassage helfen, damit du dich entspannst und deinen... Druck loswirst, und das war's."

    # say L827 mo1
    old "Just think of it as some kind of sex ed class."
    new "Stell es dir einfach als eine Art Sexualkundeunterricht vor."

    # say L828 pla
    old "Sex ed class... Uhmm, alright."
    new "Sexkundeunterricht... Ähm, okay."

    # say L830 mo1
    old "Thanks honey."
    new "Danke, Schatz."

    # say L831 mo1
    old "Alright, come and sit on the bed and leave it all to me."
    new "Okay, komm und setz dich aufs Bett und lass es mich machen."

    # say L852 pla
    old "What the fuck is going on???"
    new "Was zur Hölle geht hier ab???"

    # say L872 pla
    old "What were those yells?? It's coming from the house's entrance."
    new "Was waren diese Schreie?? Es kommt von der Eingangstür des Hauses."

    # say L874 pla
    old "I better go check it out."
    new "Ich schau mal nach."

    # say L882 mo2
    old "I'm tired of this, I'm the only one who works in this house..."
    new "Ich bin es leid, ich bin die Einzige, die hier arbeitet..."

    # say L884 mo1
    old "But honey..."
    new "Aber Schatz..."

    # say L886 mo2
    old "It makes no sense to keep providing for three good for nothing bums!"
    new "Es hat keinen Sinn, für drei faule Säcke zu sorgen!"

    # say L888 mo1
    old "But we are a family."
    new "Aber wir sind eine Familie."

    # say L890 mo2
    old "No, you are leeches who want to live at my expense."
    new "Nein, ihr seid Parasiten, die von mir leben wollen."

    # say L894 mo2
    old "Besides, now your drinking wine every night and getting drunk. Don't you feel ashamed?!"
    new "Außerdem trinkst du jetzt jeden Abend Wein und wirst betrunken. Schämst du dich denn nicht?!"

    # say L896 mo1
    old "I'm not getting drunk..."
    new "Ich werde nicht betrunken..."

    # say L898 mo2
    old "You know what, I'm going to the office ... There is no point in continuing to argue"
    new "Ich gehe ins Büro... Es hat keinen Sinn, weiter zu streiten."

    # say L906 pla
    old "Hi [mo1rel], what happened?"
    new "Hi [mo1rel], was ist passiert?"

    # say L908 mo1
    old "Hi honey, don't worry... Just a little discussion."
    new "Hi Schatz, mach dir keine Sorgen... Nur ein kleines Gespräch."

    # say L912 mo1
    old "Oh yes, I'm fine, don't worry, I'll be in my room, ok?"
    new "Oh ja, mir geht es gut, mach dir keine Sorgen, ich bin in meinem Zimmer, okay?"

    # say L936 pla
    old "Oh, come on, are they arguing again?"
    new "Oh, komm schon, streiten sie sich wieder?"

    # say L938 pla
    old "I better go and make sure what's happening now."
    new "Ich geh besser mal nachschauen, was los ist."

    # say L944 mo2
    old "Seriously, were you drinking yesterday again?"
    new "Waren Sie gestern wieder einmal getrunken?"

    # say L946 mo1
    old "I'm sorry, but I was feeling bad..."
    new "Es tut mir leid, aber ich fühlte mich schlecht..."

    # say L948 mo2
    old "You are a sick alcoholic."
    new "Du bist eine kranke Alkoholikerin."

    # say L950 mo1
    old "NO!"
    new "Nein!"

    # say L954 mo1
    old "I'm not an alcoholic and I'm tired of your offenses and your aggressiveness!"
    new "Ich bin kein Alkoholiker und ich habe die Nase voll von deinen Anschuldigungen und deiner Aggressivität!"

    # say L956 mo2
    old "Well, I'm tired of living with good for nothings..."
    new "Na ja, ich bin müde, mit Nichtsnutzen zusammenzuleben..."

    # say L958 mo2
    old "Actually, I'm leaving this house, I'm not going to keep paying everything for all of you anymore."
    new "Eigentlich gehe ich aus diesem Haus, ich werde nicht mehr für euch alle zahlen."

    # say L966 pla
    old "Uhmm, [mo1rel] are you alright?"
    new "Hmm, [mo1rel], geht es dir gut?"

    # say L968 mo1
    old "No, not really."
    new "Nein, wirklich nicht."

    # say L970 pla
    old "I'm so sorry [mo1rel]"
    new "Es tut mir so leid [mo1rel]"

    # say L972 mo1
    old "Don't worry, I think it's for the best anyway."
    new "Machen Sie sich keine Sorgen, ich denke, es ist sowieso das Beste."

    # say L974 pla
    old "I didn't know you were having these problems."
    new "Ich wusste nicht, dass du diese Probleme hast."

    # say L976 mo1
    old "Always, from the beginning of the relationship, we are very different and as much as we try..."
    new "Von Anfang an waren wir sehr unterschiedlich, egal wie sehr wir es versucht haben..."

    # say L978 mo1
    old "I think we are simply not compatible."
    new "Ich denke, wir sind einfach nicht kompatibel."

    # say L980 pla
    old "Do you need anything?"
    new "Brauchst du was?"

    # say L982 mo1
    old "No, thanks, I just want to be alone."
    new "Nein, danke, ich möchte einfach alleine sein."

    # say L1008 pla
    old "I wanted to ask you again about your doctor's appointment..."
    new "Ich wollte dich noch mal nach deinem Arzttermin fragen..."

    # say L1010 mo1
    old "Oh, I had forgotten, can you go with me?"
    new "Oh, ich hatte das vergessen, kannst du mitkommen?"

    # say L1012 pla
    old "Yes, that's why I was looking for you..."
    new "Ja, deshalb habe ich dich gesucht..."

    # say L1014 mo1
    old "Perfect! Wait for me at the entrance while I get changed and come out, okay?"
    new "Perfekt! Warte am Eingang auf mich, während ich mich umziehe und rauskomme, okay?"

    # say L1016 pla
    old "Ok, I'll wait for you then..."
    new "Okay, ich warte auf dich."

    # say L1028 mo1
    old "Ok, I'm ready. Let's go to the hospital..."
    new "Ok, ich bin fertig. Lass uns ins Krankenhaus gehen..."

    # say L1046 mo1
    old "Hi, sweetie! What are you up to?"
    new "Hallo, Schatz! Was machst du so?"

    # say L1048 pla
    old "Hey, [mo1rel]. I'm good."
    new "Hey, [mo1rel]. Mir geht's gut."

    # say L1050 mo1
    old "Did you want to talk about something?"
    new "Hast du etwas Bestimmtes mit mir besprechen wollen?"

    # say L1096 pla
    old "As you know, I'm preparing a speech for class."
    new "Wie du weißt, bereite ich einen Vortrag für die Schule vor."

    # say L1098 mo1
    old "Yes! I'm proud of you for studying so hard, dear!"
    new "Ja! Ich bin stolz auf dich, dass du so fleißig lernst, Liebling!"

    # say L1100 pla
    old "Yeah… Well, I don't want to bother anyone, so I will be studying in the garage instead of my room."
    new "Klar, ich will niemanden stören, deshalb werde ich im Schuppen lernen anstatt in meinem Zimmer."

    # say L1102 mo1
    old "Aww, that's very considerate of you. Thank you."
    new "Ach, das ist sehr rücksichtsvoll von dir. Danke."

    # say L1104 pla
    old "So, I will be heading to the garage to study now."
    new "Dann gehe ich jetzt in die Garage, um zu lernen."

    # say L1106 mo1
    old "Ok, sweetie. Do you want to talk about anything else?"
    new "Ok, Schatz. Willst du noch über etwas anderes sprechen?"

    # say L1117 pla
    old "Yes, I wanted to ask you again about doctor's appointment..."
    new "Ja, ich wollte dich noch mal nach dem Arzttermin fragen..."

    # say L1119 mo1
    old "Sure, honey. The appointment is next Thursday... Only look for me in the morning to go to the hospital, okay?"
    new "Natürlich, Schatz. Der Termin ist nächsten Donnerstag... Such mich nur morgens im Haus auf, um ins Krankenhaus zu fahren, okay?"

    # say L1121 pla
    old "Oh, right. Then I'll look for you then."
    new "Oh, klar. Dann werde ich dich morgens suchen."

    # say L1123 mo1
    old "Okay, sweetie, do you want to talk about anything else?"
    new "Okay, Schatz, willst du noch über etwas anderes sprechen?"

    # say L1131 mo1
    old "Sure, honey. The appointment is next Monday... Only look for me in the morning to go to the hospital, okay?"
    new "Natürlich, Schatz. Der Termin ist nächsten Montag... Such mich nur morgens, um ins Krankenhaus zu gehen, okay?"

    # say L1143 pla
    old "Yes, I wanted to ask you again about doctor appointment..."
    new "Ja, ich wollte dich noch mal nach dem Arzttermin fragen..."

    # say L1145 mo1
    old "It's today, Can you go with me?"
    new "Es ist heute, kannst du mit mir kommen?"

    # say L1174 mo1
    old "By the way, please remember to visit my mom, remember that next week marks a month of my father's death..."
    new "Übrigens, bitte denk daran, meine Mutter zu besuchen, nächsten Woche ist es schon ein Monat, seit Vater gestorben ist..."

    # say L1176 pla
    old "Oh, has it been a month?"
    new "Oh, ist es schon ein Monat?"

    # say L1178 mo1
    old "Yes, and it would be a great gesture if you could visit her, now that she is a widow, she needs some company."
    new "Ja, und es wäre eine wunderbare Geste, wenn du sie besuchen könntest. Als Witwe braucht sie jetzt viel Gesellschaft."

    # say L1180 pla
    old "Perfect, I'll go visit her..."
    new "Perfekt, ich werde sie besuchen..."

    # say L1182 mo1
    old "Before you go, [mo2] talked to me... And, I want you to know that watching porn is perfectly normal."
    new "Bevor du gehst, hat [mo2] mit mir gesprochen... Und ich will, dass du weißt, dass Pornografie ganz normal ist."

    # say L1185 mo1
    old "You are at the age of exploring your body, stimulations and physical sensations..."
    new "Du bist im Alter, in dem du deinen Körper, Reize und körperliche Empfindungen entdeckst..."

    # say L1186 pla
    old "What?... I wasn't-"
    new "Was?... Ich war nicht-"

    # say L1188 mo1
    old "Don't worry, honey. Nobody is judging you. You have urges, and it is important for you to release them... It is very healthy."
    new "Mach dir keine Sorgen, Schatz. Niemand urteilt über dich. Du hast Bedürfnisse, und es ist wichtig, sie abzubauen... Das ist sehr gesund."

    # say L1192 mo1
    old "I just want you to know that if you have any questions or need help, please ask me."
    new "Ich will nur, dass du weißt, wenn du Fragen hast oder Hilfe brauchst, frag mich bitte."

    # say L1194 mo1
    old "I will be in the pool if you need me."
    new "Ich werde im Pool sein, wenn du mich brauchst."

    # say L1196 pla
    old "Ok, [mo1rel]. Thanks."
    new "Ok, [mo1rel]. Danke."

    # say L1209 mo1
    old "Alright, sweetie. I will be here if you need me..."
    new "Alles klar, Schatz. Ich bin hier, wenn du mich brauchst."

    # say L1221 mo1
    old "Would you like a-"
    new "Möchtest du-"

    # say L1224 mo1
    old "What the... Oh [mo2] you scared me ..."
    new "Was zum... Oh [mo2] du hast mich erschreckt..."

    # say L1225 mo1
    old "We... We were watching a movie, do you... Want to join?"
    new "Wir... Wir haben einen Film geschaut, möchtest du... Dich dazu gesellen?"

    # say L1226 mo2
    old "No, I don't want to join, but the Wi-Fi is better here and I.. need to download some files."
    new "Nein, ich will nicht mitmachen, aber das WLAN ist hier besser und ich... muss ein paar Dateien runterladen."

    # say L1227 mo2
    old "You keep watching your stupid movie, I'll be busy."
    new "Du siehst dir dein blödes Filmchen weiter an, ich hab zu tun."

    # say L1228 mo1
    old "Oh, ok we won't bother you."
    new "Oh, okay, wir werden dich nicht stören."

    # say L1232 mo1
    old "{i}Now where were we?{/i}"
    new "{i}Nun, wo waren wir?{/i}"

    # say L1234 mo1
    old "{i}Lower your voice. We don't want to be caught{/i}"
    new "{i}Senke deine Stimme. Wir wollen ja nicht erwischt werden. {/i}"

    # say L1236 mo1
    old "{i}This is more exciting, isn't?{/i}"
    new "{i}Das ist aufregender, oder?{/i}"

    # say L1254 pla
    old "Shit, she's not doing well. It's best to take her to her room so she can rest."
    new "Scheiße, es geht ihr nicht gut. Es ist am besten, sie ins Zimmer zu bringen, damit sie sich ausruhen kann."

    # say L1260 mo1
    old "Thank you honey for bringing me here, excuse me for being like this..."
    new "Danke, Schatz, dass du mich hierher bringst, entschuldige, dass ich so bin..."

    # say L1262 mo1
    old "I think I drank a little more... "
    new "Ich denke, ich habe ein bisschen mehr getrunken..."

    # say L1264 mo1
    old "But you know, the break up with [mo2] has affected me a little."
    new "Aber Sie wissen, der Bruch mit [mo2] hat mich ein bisschen mitgenommen."

    # say L1266 pla
    old "Don't worry, it's no problem, just try to rest..."
    new "Mach dir keine Sorgen, das ist kein Problem, versuch einfach zu ruhen..."

    # say L1274 mo1
    old "Could you sleep with me?... I don't want to sleep alone in such a cold bed."
    new "Könnten Sie mit mir schlafen?... Ich will nicht allein in so einem kalten Bett schlafen."

    # say L1276 pla
    old "Yes, don't worry I'll sleep with you ..."
    new "Ja, mach dir keine Sorgen, ich schlafe bei dir..."

    # say L1278 mo1
    old "Oh, thank you very much, excuse me for bothering you so much..."
    new "Oh, vielen Dank, es tut mir leid, dass ich Sie so belaste..."

    # say L1282 mo1
    old "Could you please come to bed after turning on the light? Everything is dark."
    new "Könnten Sie bitte das Licht anmachen und dann zu Bett kommen? Es ist stockdunkel."

    # say L1290 mo1
    old "Thank you so much for all your support, I really appreciate it,"
    new "Vielen Dank für Ihre Unterstützung, ich schätze das sehr,"

    # say L1292 mo1
    old "This break up has been very hard..."
    new "Diese Trennung war sehr schwer für mich..."

    # say L1294 mo1
    old "But you've been there for me..."
    new "Aber Sie waren für mich da..."

    # say L1296 mo1
    old "You are so handsome, did you know?"
    new "Sie sind so attraktiv, das wussten Sie schon?"

    # say L1298 mo1
    old "You've made me feel things I haven't felt in a long time..."
    new "Sie haben mich Dinge fühlen lassen, die ich schon seit sehr langer Zeit nicht mehr gefühlt habe."

    # say L1300 mo1
    old "The last time I was with a man was so many years ago..."
    new "Das letzte Mal, als ich mit einem Mann zusammen war, ist schon so viele Jahre her..."

    # say L1304 mo1
    old "But, he wasn't as big as you."
    new "Aber, er war nicht so groß wie Sie."

    # say L1308 mo1
    old "Look at this size, I think if I had met a man with something like that..."
    new "Schauen Sie sich das an, ich glaube, wenn ich einen Mann mit so etwas getroffen hätte..."

    # say L1309 mo1
    old "Probably never would have been with a woman."
    new "Wahrscheinlich nie mit einer Frau zusammen gewesen wäre."

    # say L1310 mo1
    old "You have been so good to me."
    new "Sie sind immer so gut zu mir gewesen."

    # say L1311 mo1
    old "I just want to reward you a little for that ..."
    new "Ich möchte Sie dafür ein bisschen belohnen..."

    # say L1312 mo1
    old "You know what, get on the edge of the bed, I will give you a good gift."
    new "Wissen Sie was, setzen Sie sich ans Bettende, ich werde Ihnen ein schönes Geschenk machen."

    # say L1333 pla
    old "(Wow...)"
    new "Wow..."

    # say L1334 pla
    old "(Sorry but I have to do it...)"
    new "(Sorry, aber ich muss das tun...)"

    # say L1336 mo1
    old "Hi honey..."
    new "Hi Schatz..."

    # say L1339 mo1
    old "Wow, what are you doing?"
    new "Wow, was machst du da?"

    # say L1342 mo1
    old "We shouldn't do it here honey... Your [sisrel] could caught us."
    new "Wir sollten das hier nicht tun, Schatz... Dein [sisrel] könnte uns erwischen."

    # say L1362 mo1
    old "Oh honey, do you need me?"
    new "Oh Schatz, brauchst du mich?"

    # say L1364 pla
    old "No, I was just walking around."
    new "Nein, ich war nur rumgelaufen."

    # say L1366 mo1
    old "Ok, Ill be here if you need me."
    new "Okay, ich bin hier, wenn du mich brauchst."

    # say L1377 mo1
    old "Wow that was pretty intense."
    new "Wow, das war ziemlich intensiv."

    # say L1381 mo1
    old "Next time, just make sure nobody is at home, ok?"
    new "Nächstes Mal sorgen Sie einfach dafür, dass niemand zu Hause ist, okay?"


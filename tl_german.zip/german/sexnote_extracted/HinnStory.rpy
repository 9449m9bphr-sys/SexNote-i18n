# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/HinnStory.rpy
translate german strings:

    # say L13 pla
    old "Hey, Hinn! How are you doing?"
    new "Hey, Hinn! Wie geht's dir?"

    # say L15 hin
    old "H... Hey [pla]! I...I'm fine. Thanks for asking?"
    new "H... Hallo [pla]! I...Ich bin gut. Danke fürs Nachfragen?"

    # say L17 pla
    old "Are we a couple?"
    new "Sind wir ein Paar?"

    # say L19 hin
    old "W... WHAT?... WE... WHAT?"
    new "W... WAS?... WIR... WAS?"

    # say L21 pla
    old "Well, we are partners for the class project, right?"
    new "Na ja, wir sind Partner für das Klassenprojekt, oder?"

    # say L23 hin
    old "Ohh... Riiight. Haha. The class project. Yeah, we are. Sorry, I just forgot..."
    new "Ohh... Richtig. Haha. Das Klassenprojekt. Ja, sind wir. Tut mir leid, ich hab's nur vergessen..."

    # say L25 pla
    old "Don't worry. We can meet to work on it. If you prefer, I could go to your house."
    new "Keine Sorge. Wir können uns treffen, um dran zu arbeiten. Wenn du willst, kann ich auch zu dir kommen."

    # say L27 hin
    old "W...What? My house? Why? Haha. I mean, why not your place?"
    new "W...Was? Meine Wohnung? Warum? Haha. Ich meine, warum nicht bei dir?"

    # say L29 pla
    old "Well, I just thought it would be more comfortable for you. But if you don't wanna-"
    new "Na ja, ich dachte, es wäre für dich angenehmer. Aber wenn du nicht willst-"

    # say L31 hin
    old "No! I don't have a problem with that. Hehe. We can meet at my house then. I will wait for you tomorrow after class so we can meet up, ok?"
    new "Nein! Ich habe damit kein Problem. Hehe. Wir können uns dann bei mir treffen. Ich warte morgen nach dem Unterricht auf dich, damit wir uns treffen können, ok?"

    # say L33 pla
    old "Sounds good to me!"
    new "Klingt gut für mich!"

    # say L35 hin
    old "Ok then... I... I have to go, see you tomorrow, [pla]."
    new "Ok dann... Ich... Ich muss los, bis morgen, [pla]."

    # say L37 pla
    old "See you tomorrow, Hinn!"
    new "Bis morgen, Hinn!"

    # say L52 pla
    old "Hey Hinn, how are you?"
    new "Hey Hinn, wie geht's dir?"

    # say L54 hin
    old "Hi [pla], I'm great!, I mean, I'm good, what about you?"
    new "Hi [pla], ich bin super, also, ich bin gut, und du?"

    # say L56 pla
    old "I'm good too. So, are you ready to start?"
    new "Ich bin auch gut. Also, bist du bereit anzufangen?"

    # say L58 hin
    old "Well yes! I- I think so..."
    new "Na ja! I- Ich denke schon..."

    # say L60 pla
    old "Ok, then, let's do it!"
    new "Ok, dann, lass es uns tun!"

    # say L69 rub
    old "Woah! Look who we have here, it's the girl who dresses as a man."
    new "Wow! Schau mal, wen wir hier haben, diejenige, die sich wie ein Junge kleidet."

    # say L71 oli
    old "Yes! Perhaps you have nothing but that horrible gigantic sweatshirt."
    new "Ja! Vielleicht hast du nichts außer diesem schrecklichen riesigen Sweatshirt."

    # say L76 rub
    old "You know what the problem is? the problem is that she is kind of fat and that's why she wears those sweatshirts hahaha."
    new "Du weißt, was das Problem ist? Das Problem ist, dass sie ziemlich dick ist und deshalb diese Oversize-Sweatshirts trägt, haha."

    # say L78 hin
    old "No, I'm not-"
    new "Nein, ich bin nicht-"

    # say L80 oli
    old "Hahaha you're a fat woman. Don't you have any sense of style?"
    new "Hahaha, du bist eine fette Frau. Hast du überhaupt keinen Stil?"

    # say L82 rub
    old "Style? Hahaha look at her such horrible clothes obviously she doesn't know what that is."
    new "Stil? Hahaha schau sie dir an mit diesen schrecklichen Klamotten, offensichtlich hat sie keine Ahnung davon."

    # say L86 pla
    old "Hey, you shouldn't be so bitchy to Hinn..."
    new "Hey, du solltest Hinn nicht so beleidigen..."

    # say L88 rub
    old "Hahaha check it out Olivia, the loser defends the fatty woman."
    new "Hahaha schau dir das an Olivia, der Verlierer verteidigt die fette Frau."

    # say L90 oli
    old "Why don't you go away with your fat girlfriend, loser?"
    new "Warum gehst du nicht mit deiner fetten Freundin ab, Verlierer?"

    # say L92 pla
    old "... Assholes."
    new "... Arschlöcher."

    # say L94 rub
    old "Bye Loser!"
    new "Tschüss, Verlierer!"

    # say L113 pla
    old "Wait Hinn..."
    new "Warte Hinn..."

    # say L120 pla
    old "Hmm... some stupid girls were bothering Hinn."
    new "Hmm... ein paar blöde Mädchen haben Hinn genervt."

    # say L124 pla
    old "Has this happened before?"
    new "Hat das schon mal passiert?"

    # say L126 jad
    old "Yes, but she won't let me go talk to the principal, she says that I would only embarrass her even more..."
    new "Ja, aber sie lässt mich nicht zum Rektor gehen, sie sagt, ich würde sie nur noch mehr blamieren..."

    # say L130 jad
    old "By the way, I'm Jade Hinn's mom, are you her friend?"
    new "Übrigens, ich bin Jades Mom, bist du ihre Freundin?"

    # say L132 pla
    old "Yes, right, I'm glad to meet you, my name is [pla]."
    new "Ja, richtig, freut mich, ich bin [pla]."

    # say L134 jad
    old "Hahaha, Nice to meet you. [pla] please excuse me for a moment. I'm going to talk to Hinn."
    new "Hahaha, schön dich kennenzulernen. [pla] entschuldige mich kurz, ich muss mit Hinn reden."

    # say L136 pla
    old "Okay, see you later."
    new "Okay, bis später."

    # say L138 jad
    old "Oh no, don't go wait for me here, get comfortable and I'll be back in a minute."
    new "Oh nein, geh nicht, warte hier auf mich, mach es dir gemütlich, ich bin gleich wieder da."

    # say L153 jad
    old "All right, I talked to her, everything is fine, she's just a little embarrassed."
    new "Okay, ich habe mit ihr gesprochen, alles ist in Ordnung, sie ist nur ein bisschen verlegen."

    # say L155 jad
    old "I can tell she really appreciates you that's why I want to take the opportunity to ask you a favor."
    new "Ich merke, dass sie dich wirklich schätzt, deshalb möchte ich die Gelegenheit nutzen und dich um einen Gefallen bitten."

    # say L159 jad
    old "I have encouraged her to seek therapy many times as she has had problems at times."
    new "Ich habe sie schon oft dazu ermutigt, Therapie zu machen, weil sie manchmal Probleme hatte."

    # say L161 pla
    old "To the psychologist?"
    new "Zur Psychologin?"

    # say L163 jad
    old "Yes, That would be the best option for her to improve her self-esteem, I know it could help her a lot, but she won't listen to me."
    new "Ja, das wäre die beste Option für sie, um ihr Selbstbewusstsein zu stärken. Ich weiß, dass es ihr viel helfen könnte, aber sie hört einfach nicht auf mich."

    # say L165 pla
    old "Hmm, I understand."
    new "Hmm, ich verstehe."

    # say L167 jad
    old "So, I thought you could help me convince her."
    new "Dann dachte ich, du könntest mir helfen, sie davon zu überzeugen."

    # say L171 jad
    old "Yes, I'm sure with your help we can convince her that that's the right thing to do."
    new "Ja, ich bin sicher, dass wir mit deiner Hilfe sie davon überzeugen können, dass das das Richtige ist."

    # say L173 pla
    old "Alright. But what should I do?"
    new "Okay. Aber was soll ich tun?"

    # say L175 jad
    old "First of all, help me find a psychologist, the truth is that I have been looking for one, but I haven't been able to find anyone."
    new "Erst mal hilf mir, einen Psychologen zu finden. Ehrlich gesagt suche ich schon seit einiger Zeit einen, aber ich hab noch keinen gefunden."

    # say L177 pla
    old "Hmm, ok, I can handle it."
    new "Hmm, okay, ich kümmere mich drum."

    # say L179 jad
    old "All right, as soon as you find a therapist let me know. You can meet me here in the morning."
    new "Okay, sobald du einen Therapeut gefunden hast, lass es mich wissen. Du kannst mich morgens hier treffen."

    # say L188 hin
    old "Hello [pla], sorry for the delay..."
    new "Hallo [pla], tut mir leid für die Verspätung..."

    # say L190 jad
    old "All right guys, I'll leave you, so, you can go on with your work."
    new "Okay Leute, ich lass euch jetzt, damit ihr weiterarbeiten könnt."

    # say L196 pla
    old "Don't worry Hinn, do you feel better?"
    new "Mach dir keine Sorgen, Hinn, geht es dir besser?"

    # say L198 hin
    old "Yes a little, I'm very sorry that-"
    new "Ja ein bisschen, es tut mir sehr leid, dass-"

    # say L200 pla
    old "No, you don't have to apologize for anything, they're just bitches."
    new "Nein, du musst dich für gar nichts entschuldigen, die sind einfach nur Schlampe."

    # say L202 hin
    old "Hehehe, if you say so."
    new "Hehehe, wenn du das sagst."

    # say L204 pla
    old "Do you want to work today? We could do it tomorrow if you think thats better."
    new "Willst du heute arbeiten? Wir könnten es auch morgen machen, wenn dir das besser passt."

    # say L206 hin
    old "No, no, I'm fine, we can start today."
    new "Nein, nein, mir geht's gut, wir können heute anfangen."

    # say L208 pla
    old "Ok, let's do it."
    new "Ok, dann machen wir es."

    # say L222 pla
    old "Wow, Hinn! I didn't know you were so good at this!"
    new "Wow, Hinn! Ich wusste gar nicht, dass du so gut darin bist!"

    # say L224 hin
    old "Well... It's not as difficult as it seems. Hehe. I just study a little here and there."
    new "Na ja... Es ist nicht so schwierig, wie es aussieht. Hehe. Ich studiere einfach ein bisschen hier und da."

    # say L226 pla
    old "Well, thanks to you, we made a lot of progress. I think we can stop for now."
    new "Danke dir, wir haben viel erreicht. Ich denke, wir können für heute Schluss machen."

    # say L228 hin
    old "Yes, it's getting late. We can continue tomorrow!"
    new "Ja, es wird spät. Wir können morgen weitermachen!"

    # say L230 pla
    old "Ok. I really enjoyed working with you. I think we make a very good team."
    new "Ok. Ich habe echt genossen, mit dir zu arbeiten. Ich denke, wir machen ein super Team."

    # say L232 hin
    old "Do... D- do you think that?"
    new "Do... D- denkst du das wirklich?"

    # say L234 pla
    old "Of course! I think we are going to kick some ass together."
    new "Natürlich! Ich denke, wir werden zusammen richtig abrasseln."

    # say L238 pla
    old "Well, see you tomorrow, Hinn. Have a good night."
    new "Na dann, bis morgen, Hinn. Schlaf gut."

    # say L240 hin
    old "You too. By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "Du auch. Übrigens, vergiss nicht, Mrs. Mia unseren Fortschritt zu zeigen, lass sie wissen, wie weit wir gekommen sind. Bis morgen."

    # say L242 pla
    old "Ok... See you."
    new "Ok... Bis morgen."

    # say L262 jad
    old "You came! I didn't know if you would actually come..."
    new "Du bist gekommen! Ich wusste nicht, ob du wirklich kommen würdest..."

    # say L264 pla
    old "Well, I like Hinn and I want to help her anyway I can, I finally found a therapist."
    new "Na ja, ich mag Hinn und will ihr auf jede mögliche Weise helfen, ich habe endlich einen Therapeuten gefunden."

    # say L266 jad
    old "That's excellent! What's their name?"
    new "Das ist toll! Wie heißt er/sie?"

    # say L268 pla
    old "She is Dr. Johnson, she has her office in the town Business Building."
    new "Sie ist Dr. Johnson, sie hat ihr Büro im Stadtgeschäftshaus."

    # say L270 jad
    old "Great, it's not far from here."
    new "Super, das ist nicht weit von hier."

    # say L272 pla
    old "No is not, if you want I can make an appointment to see her."
    new "Nein ist nicht, wenn du willst, kann ich einen Termin bei ihr machen."

    # say L274 jad
    old "Oh, don't worry I'll take care of it."
    new "Oh, mach dir keine Sorgen, ich kümmere mich darum."

    # say L278 jad
    old "However, now comes the toughest part, convincing Hinn to go to therapy."
    new "Allerdings kommt jetzt der schwierigste Teil, Hinn dazu zu bringen, Therapie zu machen."

    # say L280 jad
    old "So, I'll talk to her today but you should convince her to agree to do it."
    new "Dann rede ich heute mit ihr, aber du solltest sie dazu überreden, damit sie zustimmt."

    # say L282 pla
    old "Understood!"
    new "Verstanden!"

    # say L284 jad
    old "Perfect! Now hurry too school. I don't want you to be late because of me."
    new "Perfekt! Jetzt beeil dich zur Schule. Ich will nicht, dass du meinetwegen zu spät kommst."

    # say L286 pla
    old "Alright! Bye."
    new "Alles klar! Tschüss."

    # say L302 jad
    old "I only care about you and your well-being, sweetheart..."
    new "Ich mache mir nur Sorgen um dich und dein Wohlbefinden, Schatz..."

    # say L307 hin
    old "I don't need a psychologist. I'm not crazy!"
    new "Ich brauche keinen Psychologen. Ich bin nicht verrückt!"

    # say L309 jad
    old "Oh... Hi [pla]!"
    new "Oh... Hallo [pla]!"

    # say L311 hin
    old "(Oh no...)"
    new "Oh nein..."

    # say L313 pla
    old "Good morning Mr. Jade... Hello there, Hinn."
    new "Guten Morgen Mr. Jade... Hallo, Hinn."

    # say L315 hin
    old "Sorry, [pla]. My mother now thinks I'm crazy..."
    new "Tut mir leid, [pla]. Meine Mutter denkt jetzt, ich bin verrückt..."

    # say L318 jad
    old "I don't think you're crazy honey, I just want you to go to therapy to strengthen your self-esteem."
    new "Ich denke nicht, dass du verrückt bist, Schatz, ich will nur, dass du Therapie machst, um dein Selbstbewusstsein zu stärken."

    # say L320 hin
    old "I have nothing that I need to be strengthened!"
    new "Ich habe nichts, was gestärkt werden muss!"

    # say L322 jad
    old "Honey, I know the reason why you don't want to go, it is because you think they are going to make fun of you even more at school."
    new "Schatz, ich weiß, warum du nicht hingehen willst, du denkst, sie werden dich in der Schule noch mehr auslachen."

    # say L324 jad
    old "But I promise it won't happen, we can do everything without anyone knowing."
    new "Aber ich verspreche, das passiert nicht, wir können alles tun, ohne dass jemand was mitkriegt."

    # say L326 hin
    old "No, no, I won't do it, and I don't want you to continue embarrassing me."
    new "Nein, nein, ich mach das nicht und ich will auch nicht, dass du mich weiter bloßstellst."

    # say L328 jad
    old "[pla], would you think Hinn is crazy if she goes to the therapist?"
    new "[pla], würdest du denken, Hinn ist verrückt, wenn sie zu der Therapeutin geht?"

    # say L332 pla
    old "Actually, I think it's healthy, and if it's something that will help you feel better, I don't think it matters what others think, right?"
    new "Eigentlich denke ich, das ist gesund, und wenn es dir helfen wird, dich besser zu fühlen, ist es egal, was andere denken, oder?"

    # say L335 jad
    old "You see darling, there is nothing wrong with it, many people attend to therapy and it is completely normal."
    new "Siehst du, Schatz, daran ist nichts Falsches, viele Menschen gehen in Therapie und das ist total normal."

    # say L339 jad
    old "In fact, [pla] would you go with Hinn?"
    new "Tatsächlich, [pla] würdest du mit Hinn gehen?"

    # say L344 pla
    old "Sure, I'd love to."
    new "Klar, ich würde gerne mitkommen."

    # say L346 jad
    old "See honey, don't worry any more, go to a single session and then decide whether to continue or not."
    new "Siehst du, Schatz, mach dir keine Sorgen mehr, geh zu einer Einzelsitzung und dann entscheide selbst, ob du weitermachen willst oder nicht."

    # say L348 hin
    old "Would you really be willing to go with me?"
    new "Würdest du wirklich mit mir gehen?"

    # say L350 pla
    old "Of course, it should be fun."
    new "Natürlich, das sollte Spaß machen."

    # say L352 hin
    old "Okay, but don't think I don't realize how you are manipulating me."
    new "Okay, aber denk nicht, dass ich nicht merke, wie du mich manipulierst."

    # say L354 jad
    old "Excellent honey, I'm going to make the appointment. So, you can start studying now."
    new "Perfekt Schatz, ich mache den Termin. Dann kannst du jetzt mit dem Lernen anfangen."

    # say L361 hin
    old "She's unbelievable..."
    new "Sie ist unglaublich..."

    # say L364 pla
    old "Well, the truth is, I think she's doing the best she can to help you."
    new "Na ja, die Wahrheit ist, ich denke, sie gibt ihr Bestes, um dir zu helfen."

    # say L366 hin
    old "If you say so... Anyway, let's start to work."
    new "Wenn du meinst... Jedenfalls, lass uns anfangen zu arbeiten."

    # say L370 hin
    old "[pla], thank you... seriously. Thanks for having my back."
    new "[pla], danke... echt. Danke, dass du mir den Rücken stärkst."

    # say L372 pla
    old "It's nothing..."
    new "Ist schon gut..."

    # say L392 pla
    old "Ok, see you tomorrow, Hinn."
    new "Ok, bis morgen, Hinn."

    # say L396 pla
    old "Ok. Have a good night."
    new "Ok. Schlaf gut, Hinn."

    # say L416 hin
    old "Hello [pla], How are you doing?"
    new "Hallo [pla], wie geht es dir?"

    # say L418 pla
    old "Hey Hinn, I am doing great, you?"
    new "Hey Hinn, ich bin super, und du?"

    # say L420 hin
    old "Fine, thanks for asking. Today is the so-called “therapy session”, are you coming?"
    new "Alles gut, danke fürs Nachfragen. Heute ist die sogenannte „Therapiesitzung“. Kommst du mit?"

    # say L422 pla
    old "Is it today?"
    new "Ist es heute?"

    # say L424 hin
    old "Yes... My mother finally managed to schedule an appointment as we agreed."
    new "Ja... Meine Mutter hat es endlich geschafft, einen Termin zu vereinbaren, wie wir es besprochen haben."

    # say L426 pla
    old "Sure, I promised that I'll join you."
    new "Klar, ich hab's versprochen."

    # say L428 hin
    old "Awesome, are you ready?"
    new "Super, bist du bereit?"

    # say L430 pla
    old "Yes, let's get going."
    new "Ja, lass uns loslegen."

    # say L432 hin
    old "Very well."
    new "Sehr gut."

    # say L440 joh
    old "Good afternoon, nice to meet you, you must be Hinn, right?"
    new "Guten Nachmittag, freut mich, Sie kennenzulernen. Sie müssen Hinn sein, richtig?"

    # say L442 hin
    old "Yes, Dr. Johnson, nice to meet you too."
    new "Ja, Dr. Johnson, schön, Sie auch kennenzulernen."

    # say L444 joh
    old "Your mother has already told me a little about you and you are..."
    new "Ihre Mutter hat mir schon ein wenig von Ihnen erzählt und Sie sind..."

    # say L446 pla
    old "My name is [pla], nice to meet you."
    new "Mein Name ist [pla], schön dich kennenzulernen."

    # say L448 joh
    old "Oh, are you her boyfriend?"
    new "Oh, sind Sie ihr Freund?"

    # say L453 hin
    old "He's a friend..."
    new "Er ist ein Freund..."

    # say L455 joh
    old "Oh ok, I understand a friend..."
    new "Oh ok, ich verstehe, ein Freund..."

    # say L457 joh
    old "All right, I think it's time to start therapy. [pla] could you wait for us outside?"
    new "Na gut, ich denke, es ist Zeit, mit der Therapie zu beginnen. [pla] Könntest du draußen auf uns warten?"

    # narrator L465 
    old "A few minutes later"
    new "Ein paar Minuten später"

    # say L468 joh
    old "[pla] Can you come in for a moment, please?"
    new "[pla] Könnten Sie bitte hereinkommen?"

    # say L476 joh
    old "Very well, let me explain. With Hinn we have discussed the issue of bullying in the school."
    new "Sehr gut, lassen Sie mich das erklären. Mit Hinn haben wir das Problem der Mobbingfälle in der Schule besprochen."

    # say L478 joh
    old "And we have reached to the conclusion that it is best for her to try on other outfits so that she feels more comfortable with her body."
    new "Und wir sind zu dem Schluss gekommen, dass es am besten für sie ist, andere Outfits auszuprobieren, damit sie sich mit ihrem Körper wohler fühlt."

    # say L480 pla
    old "I understand, I think it's a good idea."
    new "Ich verstehe, ich denke, das ist eine gute Idee."

    # say L482 joh
    old "Yes, but to help her to have a better progress with the therapy, we require your help."
    new "Ja, aber um ihr bei der Therapie besser zu helfen, benötigen wir Ihre Unterstützung."

    # say L484 pla
    old "My help? How so?"
    new "Meine Hilfe? Wie genau?"

    # say L486 joh
    old "We need a male friend opinion for each outfit so Hinn can feel that someone cares for her."
    new "Wir benötigen die Meinung eines männlichen Freundes zu jedem Outfit, damit Hinn das Gefühl hat, dass jemand sich um sie kümmert."

    # say L488 pla
    old "Oh, I understand, no problem."
    new "Oh, ich verstehe, kein Problem."

    # say L492 pla
    old "Yes, it will be fun."
    new "Ja, das wird spaßig."

    # say L494 joh
    old "All right, in that case sit on the couch while Hinn takes off that sweatshirt."
    new "In Ordnung, dann setzen Sie sich auf die Couch, während Hinn das Sweatshirt auszieht."

    # say L509 joh
    old "Are you ready Hinn?"
    new "Sind Sie bereit, Hinn?"

    # say L511 hin
    old "Hmm, I think so."
    new "Hmm, ich denke schon."

    # say L513 joh
    old "Very well take off that sweatshirt and let us see your body better."
    new "Sehr gut, zieh das Sweatshirt aus und lass uns deinen Körper besser sehen."

    # say L517 joh
    old "Don't worry, you're in a safe place, nobody's going to judge you here."
    new "Keine Sorge, du bist in einem sicheren Ort, hier wird dich niemand verurteilen."

    # say L519 hin
    old "Hmm alright."
    new "Hmm okay."

    # say L523 joh
    old "But girl you have a great body!"
    new "Aber Mädchen, Sie haben eine tolle Figur!"

    # say L527 joh
    old "What about you [pla]? Her body shape looks better, right?"
    new "Was ist mit Ihnen [pla]? Ihre Figur sieht besser aus, oder?"

    # say L528 pla
    old "Yes, she certainly looks better."
    new "Ja, sie sieht definitiv besser aus."

    # say L532 joh
    old "Do you think you could survive without your Sweatshirt?"
    new "Könnten Sie ohne Ihr Sweatshirt überleben?"

    # say L534 hin
    old "They are going to criticize me at school, because of my... b- breasts."
    new "Sie werden mich in der Schule kritisieren, wegen meinen... b- Brüsten."

    # say L536 joh
    old "Hahaha, but how are you going to be embarrassed by those beautiful breasts?"
    new "Hahaha, aber wie sollen Sie sich wegen dieser wunderschönen Brüste schämen?"

    # say L537 joh
    old "What do you say [pla], Hinn should be ashamed?"
    new "Was sagen Sie [pla], sollte Hinn sich schämen?"

    # say L538 pla
    old "... Hmm no, really your breasts look great."
    new "Hmm nein, wirklich, deine Brüste sehen toll aus."

    # say L542 joh
    old "You have a blessing, you have a slim waist and a couple of really nice boobs, with those you might make all the boys crazy over you. "
    new "Sie haben ein Geschenk, eine schmale Taille und zwei wirklich hübsche Brüste, damit könnten Sie alle Jungs verrückt machen."

    # say L546 joh
    old "All right, all right, no problem, I think that's it for today."
    new "Na gut, na gut, kein Problem, ich denke, das reicht für heute."

    # say L554 joh
    old "However, we will have to get some more outfits to continue with your treatment."
    new "Allerdings werden wir einige zusätzliche Outfits benötigen, um mit Ihrer Behandlung fortzufahren."

    # say L556 joh
    old "Hmm, I'd rather it wasn't your own clothes, since from what I've see your clothes cover a lot."
    new "Hmm, ich würde es vorziehen, wenn es nicht Ihre eigenen Kleider wären, da die Kleider, die ich bisher gesehen habe, ziemlich viel bedecken."

    # say L558 pla
    old "I think I could help, I could get some clothes for Hinn."
    new "Ich denke, ich könnte helfen. Ich könnte ein paar Klamotten für Hinn besorgen."

    # say L560 joh
    old "Fantastic! Make sure it's a bit of a daring and revealing outfit."
    new "Fantastisch! Stellen Sie sicher, dass es ein wenig gewagt und offenherzig ist."

    # say L562 joh
    old "We need to gradually make Hinn feel more secure in her body."
    new "Wir müssen Hinn allmählich dazu bringen, sich in ihrem Körper wohler zu fühlen."

    # say L566 joh
    old "Ok, see you in the next session guys!"
    new "Ok, bis zur nächsten Sitzung, Leute!"

    # say L568 hin
    old "Thanks Dr. Johnson, goodbye."
    new "Danke Dr. Johnson, auf Wiedersehen."

    # say L570 pla
    old "Goodbye."
    new "Auf Wiedersehen."

    # say L577 pla
    old "How did you feel Hinn?"
    new "Wie hast du dich gefühlt, Hinn?"

    # say L579 hin
    old "Actually, it was quite interesting, I felt comfortable in therapy, confronting it a little I think it can help."
    new "Eigentlich war es ziemlich interessant, ich fühlte mich in der Therapie wohl und denke, dass es hilfreich sein kann, wenn ich es ein bisschen angehe."

    # say L581 pla
    old "Excellent, I think it's great that you feel that way."
    new "Perfekt, ich finde es toll, dass du so empfindest."

    # say L583 pla
    old "So, will you continue attending therapy?"
    new "Dann wirst du weiterhin Therapie machen?"

    # say L585 hin
    old "Hmm... Would you still accompany me?"
    new "Hmm... Würdest du mich immer noch begleiten?"

    # say L587 pla
    old "Of course I will."
    new "Natürlich werde ich."

    # say L590 hin
    old "Okay, let's just don't make a fuss in front of my mother, I don't want her to think she was right."
    new "Okay, lass uns einfach nicht vor meiner Mutter Theater machen, ich will nicht, dass sie denkt, sie hätte recht."

    # say L592 pla
    old "Hahaha, alright."
    new "Hahaha, klar."

    # say L594 hin
    old "Thanks again for your support."
    new "Danke nochmal für deine Unterstützung."

    # say L596 pla
    old "It's a pleasure, Hinn."
    new "Es ist mir ein Vergnügen, Hinn."

    # say L598 hin
    old "Could you come with me to my house today? I don't want my mother to ask me many questions."
    new "Kannst du heute mit zu mir kommen? Ich will nicht, dass meine Mutter mir viele Fragen stellt."

    # say L610 jad
    old "How did it go guys?"
    new "Wie war's, Leute?"

    # say L612 hin
    old "Hmm... it wasn't a bad idea after all..."
    new "Hmm... es war gar keine schlechte Idee..."

    # say L614 jad
    old "You should tell by now that therapy is a very positive thing to do."
    new "Du solltest inzwischen merken, dass Therapie eine sehr positive Sache ist."

    # say L616 jad
    old "Then I will immediately schedule the next appointment!"
    new "Dann werde ich sofort den nächsten Termin vereinbaren!"

    # say L618 hin
    old "No, I'm not going to go to therapy every day mom..."
    new "Nein, ich werde nicht jeden Tag zur Therapie gehen, Mom..."

    # say L620 jad
    old "But... I thought you liked it."
    new "Aber... ich dachte, dir hat es gefallen."

    # say L622 hin
    old "Yes, I will go but remember, I have more responsibilities, like the class project with [pla]."
    new "Ja, ich werde hingehen, aber denk dran, ich habe noch mehr Verantwortungen, wie das Klassenprojekt mit [pla]."

    # say L624 jad
    old "Hmm, I understand, So when I should make the next appointment?"
    new "Hmm, ich verstehe. Wann soll ich dann das nächste Treffen vereinbaren?"

    # say L626 hin
    old "No, I will make the appointments myself when I think it is appropriate."
    new "Nein, ich werde die Termine selbst machen, wenn ich es für angebracht halte."

    # say L628 hin
    old "Besides, [pla] must also agree when we should go, since he's going to the therapies as well."
    new "Außerdem muss auch [pla] zustimmen, wann wir hingehen, da er ja auch an den Therapien teilnimmt."

    # say L630 jad
    old "Okay, you're right, I'll leave that up to you, if you need anything don't hesitate to ask me."
    new "Okay, du hast recht, ich lass das dann bei dir, wenn du was brauchst, zögere nicht mich zu fragen."

    # say L632 jad
    old "I'll leave you alone, so, you can say goodbye to each other, heh."
    new "Ich lass euch allein, damit ihr euch verabschieden könnt, hehe."

    # say L647 pla
    old "I'm glad that everything went well with therapy."
    new "Ich bin froh, dass alles gut bei der Therapie gelaufen ist."

    # say L649 hin
    old "Yes, me too, at least my mom will stop bothering me every day, or I hope so."
    new "Ja, ich auch, zumindest wird meine Mom mich hoffentlich nicht mehr jeden Tag nerven."

    # say L651 pla
    old "Hahaha I don't think that's going to happen."
    new "Hahaha, ich glaube, das wird nicht passieren."

    # say L653 hin
    old "Hehehe neither do I."
    new "Hehehe, ich auch nicht."

    # say L659 pla
    old "Well, well, it's getting late, so I'm going home, see you tomorrow."
    new "Na dann, es wird spät, ich gehe nach Hause, bis morgen."

    # say L661 hin
    old "Yes, thank you so much for what you are doing."
    new "Ja, danke dir so sehr für das, was du tust."

    # say L663 pla
    old "You are welcome, I enjoyed it as much as you did and I love spending time with you."
    new "Gern geschehen, ich habe es genossen, genauso wie du, und ich liebe es, Zeit mit dir zu verbringen."

    # say L667 pla
    old "Well... see you tomorrow."
    new "Na... bis morgen."

    # say L687 pla
    old "Hey Hinn! How are you today?"
    new "Hey Hinn! Wie geht's dir heute?"

    # say L689 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy sesion."
    new "Mir geht's gut, danke [pla]. Ich habe auf dich gewartet, heute ist die neue Therapiesitzung."

    # say L691 pla
    old "Oh great, let's go then."
    new "Oh toll, dann lass uns gehen."

    # say L693 hin
    old "Ok, ok."
    new "Okay, okay."

    # say L701 joh
    old "Hi guys, how are you?"
    new "Hallo zusammen, wie geht es Ihnen?"

    # say L703 pla
    old "Fine, thanks."
    new "Alles gut, danke."

    # say L705 joh
    old "Ready to go on with the treatment?"
    new "Bereit, mit der Behandlung fortzufahren?"

    # say L707 hin
    old "I think so..."
    new "Ich denke schon..."

    # say L709 joh
    old "Excellent, [pla] you brought the clothes, didn't you?"
    new "Exzellent, [pla] Sie haben die Kleidung mitgebracht, oder?"

    # say L711 pla
    old "Well, yes although I'm not sure if this will work, the clothes are... a little more revealing than necessary."
    new "Na ja, schon, aber ich bin mir nicht sicher, ob das klappt. Die Klamotten sind... ein bisschen zu freizügig, finde ich."

    # say L713 joh
    old "Hmm, we'll see let's go Hinn, to the changing room."
    new "Hmm, wir werden sehen. Gehen wir, Hinn, in die Umkleidekabine."

    # say L715 hin
    old "Hmm... ok."
    new "Hmm... okay."

    # say L728 joh
    old "Well, it took me a while to convince her, but finally got her to try on this outfit..."
    new "Nun, es hat eine Weile gedauert, sie zu überzeugen, aber schließlich habe ich sie dazu gebracht, diesen Outfit anzuprobieren..."

    # say L739 joh
    old "What do you think [pla]?"
    new "Was denken Sie [pla]?"

    # say L740 pla
    old "(Oh my God!) Well, I think you look really good, Hinn..."
    new "Oh mein Gott! Na ja, ich finde, du siehst echt gut aus, Hinn..."

    # say L742 hin
    old "Do you really think so?"
    new "Findest du das wirklich?"

    # say L743 pla
    old "Yes, you look great."
    new "Ja, du siehst toll aus."

    # say L745 joh
    old "What did I tell you? You should wear these kinds of clothes every day."
    new "Was habe ich Ihnen gesagt? Sie sollten solche Kleidung jeden Tag tragen."

    # say L747 hin
    old "No way. I'm not going to wear this in public..."
    new "Keine Chance. Ich werde das nicht in der Öffentlichkeit tragen..."

    # say L749 joh
    old "Well, at least you tried it. We are making progress. However, we need to go further. Next time bring something more revealing, ok [pla]?"
    new "Na ja, zumindest hast du es versucht. Wir machen Fortschritte. Aber wir müssen weitergehen. Bring nächstes Mal etwas Aufreizenderes mit, ok [pla]?"

    # say L751 hin
    old "More revealing?!"
    new "Mehr freizügig?!"

    # say L754 joh
    old "Yeah, honey remember we are going to do it privately and in a safe place, so we can improve."
    new "Ja, Schatz, denk dran, dass wir es privat und an einem sicheren Ort machen werden, damit wir Fortschritte machen können."

    # say L764 joh
    old "Well, that's it. See you in the next session."
    new "Na gut, dann. Bis zur nächsten Sitzung."

    # say L766 hin
    old "Thanks Dr. Johnson."
    new "Danke Dr. Johnson."

    # say L775 hin
    old "Thank you so much for joining me again... I really appreciate it."
    new "Vielen Dank, dass Sie mich wieder begleitet haben... Ich schätze es sehr."

    # say L777 pla
    old "Oh, don't worry, I think it's fun."
    new "Oh, mach dir keine Sorgen, ich finde es lustig."

    # say L779 hin
    old "You're right, it's a bit fun..."
    new "Du hast recht, es ist ein bisschen lustig..."

    # say L781 pla
    old "Would you like me to walk you home?"
    new "Möchtest du, dass ich dich nach Hause bringe?"

    # say L783 hin
    old "Oh no, don't worry my mom will come to pick me up."
    new "Oh nein, mach dir keine Sorgen, meine Mom wird mich abholen."

    # say L785 pla
    old "Alright, then see you tomorrow?"
    new "Okay, dann bis morgen?"

    # say L787 hin
    old "Yes!... I mean, sure."
    new "Ja!... Ich meine, klar."

    # say L789 pla
    old "Great, see you tomorrow Hinn."
    new "Super, bis morgen Hinn."

    # say L791 hin
    old "See you tomorrow [pla]."
    new "Bis morgen [pla]."

    # say L810 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy session."
    new "Ich bin gut, danke [pla]. Ich habe auf dich gewartet, heute ist die neue Therapiesitzung."

    # say L826 joh
    old "Ready to get started with the treatment?"
    new "Bereit, mit der Behandlung zu beginnen?"

    # say L830 joh
    old "Excellent, let's go Hinn."
    new "Ausgezeichnet, lass uns gehen Hinn."

    # say L844 joh
    old "I love this outfit, I find it fancy and it looks great on you Hinn..."
    new "Ich liebe dieses Outfit, ich finde es schick und es steht dir großartig, Hinn..."

    # say L856 joh
    old "Look at you, wow, you look fantastic."
    new "Schau dich an, wow, du siehst fantastisch aus."

    # say L858 hin
    old "I think this skirt is too short..."
    new "Ich denke, dieser Rock ist zu kurz..."

    # say L860 joh
    old "That's the idea! To show those pretty legs of yours. Hehe. See how [pla] is drooling over them?"
    new "Das ist ja die Idee! Damit man diese schönen Beine von Ihnen sieht. Hehe. Schauen Sie, wie [pla] darüber sabbert?"

    # say L863 pla
    old "Mmm Yes... I mean no... I'm just watching. Nothing more."
    new "Mmm Ja... ich meine nein... Ich schaue nur zu. Nichts weiter."

    # say L865 joh
    old "Sure, you are... Do you think Hinn has pretty legs?"
    new "Natürlich, Sie sind... Glauben Sie, dass Hinn hübsche Beine hat?"

    # say L866 pla
    old "Uhhh... Well, actually yes, I do..."
    new "Uhhh... Na ja, eigentlich schon, finde ich..."

    # say L869 pla
    old "Yes, you really look nice."
    new "Ja, du siehst wirklich gut aus."

    # say L871 joh
    old "And how about that cleavage, aye?"
    new "Und wie ist es mit diesem Ausschnitt, hm?"

    # say L875 pla
    old "Uhh... It looks great, too. Hinn has a really good... Body."
    new "Uhh... Es sieht auch toll aus. Hinn hat wirklich eine tolle... Figur."

    # say L877 joh
    old "She has great boobs, too, doesn't she?"
    new "Sie hat auch tolle Brüste, oder?"

    # say L881 hin
    old "I'm going to change my clothes..."
    new "Ich werde mich umziehen..."

    # say L883 joh
    old "Hehe. I was just kidding..."
    new "Hehe. Ich habe nur gescherzt..."

    # say L891 joh
    old "Well, that's it, [pla] you can surprise me the next session with another beautiful outfit like today."
    new "Nun, das war's, [pla] Sie können mich bei der nächsten Sitzung mit einem anderen schönen Outfit überraschen wie heute."

    # say L893 pla
    old "I will try."
    new "Ich werde es versuchen."

    # say L895 joh
    old "Great! All right guys, see you in the next session."
    new "Großartig! Also, bis zur nächsten Sitzung, Leute."

    # say L897 hin
    old "Thank you Dr. Johnson."
    new "Danke Dr. Johnson."

    # say L910 hin
    old "You are right, it's a bit fun..."
    new "Sie haben recht, es ist ein bisschen lustig..."

    # say L912 pla
    old "Do you want me to walk you home?"
    new "Willst du, dass ich dich nach Hause bringe?"

    # say L939 pla
    old "I talked to Mrs. Mia... Ugh, I think she hates me or something."
    new "Ich hab mit Mrs. Mia geredet... Igitt, ich glaub, sie hasst mich oder so."

    # say L941 hin
    old "Why do you say that?"
    new "Warum sagst du das?"

    # say L943 pla
    old "She doesn't think I did anything on our project... And she wants you to talk to her alone."
    new "Sie denkt, ich hätte nichts für unser Projekt getan... Und sie will, dass du allein mit ihr redest."

    # say L945 hin
    old "Oh, no problem, [pla]. Don't worry I'll talk to her and let her know the truth."
    new "Oh, kein Problem, [pla]. Mach dir keine Sorgen, ich rede mit ihr und kläre alles."

    # say L947 pla
    old "Ok. Thank you, Hinn."
    new "Ok. Danke, Hinn."

    # say L965 hin
    old "Everything is fine. I explained everything to her."
    new "Alles ist in Ordnung. Ich habe ihr alles erklärt."

    # say L967 pla
    old "Really? Just like that, huh?"
    new "Wirklich? Einfach so, hm?"

    # say L969 hin
    old "Well, I can be very persuasive if I set my mind to it."
    new "Na ja, wenn ich mir was in den Kopf setze, kann ich ziemlich überzeugend sein."

    # say L971 pla
    old "Wow, Hinn! You sure have changed. You're way more open and secure..."
    new "Wow, Hinn! Du bist echt verändert. Viel offener und selbstsicher..."

    # say L975 pla
    old "Yes, I really do."
    new "Ja, das tue ich wirklich."

    # say L977 hin
    old "Hahaha. Well, thank you, [pla]. It seems that my mom's crazy ideas really worked somehow."
    new "Ha ha ha. Danke, [pla]. Scheint, dass die verrückten Ideen meiner Mum irgendwie funktioniert haben."

    # say L979 pla
    old "Yes. I definitely think so..."
    new "Ja. Ich denke definitiv, dass es so ist..."

    # say L981 hin
    old "Well, speaking of that, today is the new therapy session."
    new "Na, da fällt mir ein, heute ist die neue Therapiesitzung."

    # say L1011 joh
    old "Great, let's go Hinn."
    new "Großartig, dann lass uns gehen, Hinn."

    # say L1034 joh
    old "I honestly didn't think that Hinn was going to wear this... But we really are coming a long way..."
    new "Ehrlich gesagt, habe ich nicht gedacht, dass Hinn das wirklich anziehen würde... Aber wir machen wirklich Fortschritte..."

    # say L1037 hin
    old "I don't really feel comfortable..."
    new "Ich fühle mich echt nicht wohl..."

    # say L1039 joh
    old "You look fantastic, girl! With this outfit, you will drive them all crazy!"
    new "Du siehst fantastisch aus, Mädchen! In diesem Outfit wirst du alle um den Verstand bringen!"

    # say L1041 hin
    old "What! Who's supposed to wear this in public?"
    new "Was! Wer soll das denn in der Öffentlichkeit tragen?"

    # say L1043 joh
    old "Hahaha, I'd be surprised. What do you think, [pla]?"
    new "Hahaha, ich wäre überrascht. Was denken Sie, [pla]?"

    # say L1046 pla
    old "...(Oh shit! I'm getting hard.)"
    new "Oh Shit! Ich werde hart."

    # say L1053 joh
    old "Haha! Well, you've already made him get horny."
    new "Haha! Na, Sie haben ihn ja schon geil gemacht."

    # say L1057 joh
    old "Can't you see his pants?"
    new "Können Sie seine Hose nicht sehen?"

    # say L1061 joh
    old "That right there, Hinn, is the most honest show of appreciation you can receive from a man..."
    new "Das da, Hinn, ist die ehrlichste Form der Anerkennung, die Sie von einem Mann bekommen können..."

    # say L1064 hin
    old "Oh my..."
    new "Oh mein..."

    # say L1065 pla
    old "Sorry... It wasn't... My intention..."
    new "Entschuldigung... Es war nicht... Meine Absicht..."

    # say L1067 joh
    old "Oh, no. Don't worry, honey. In fact, Hinn, you should feel flattered."
    new "Oh nein. Machen Sie sich keine Sorgen, Liebes. Tatsächlich sollten Sie geschmeichelt sein, Hinn."

    # say L1068 joh
    old "Do you know what that erection means? [pla] is sexually attracted to you!"
    new "Wissen Sie, was diese Erektion bedeutet? [pla] ist sexuell von Ihnen angezogen!"

    # say L1069 pla
    old "(Oh shit!)"
    new "Oh Scheiße!"

    # say L1073 joh
    old "Well, since you are both quite young, I think I could take this chance to give you a little sex education lesson..."
    new "Nun, da Sie beide noch ziemlich jung sind, denke ich, ich könnte diese Gelegenheit nutzen, um Ihnen ein wenig Sexualkunde zu erteilen..."

    # say L1077 joh
    old "Hahaha, [pla], you have Hinn speechless... Come here, don't be shy..."
    new "Hahaha, [pla], Sie haben Hinn sprachlos gemacht... Kommen Sie her, seien Sie nicht schüchtern..."

    # say L1083 joh
    old "I have to admit, [pla], I didn't imagine it would be this big... His size is pretty impressive, huh, Hinn?"
    new "Ich muss zugeben, [pla], ich habe mir das nicht so groß vorgestellt... Seine Größe ist ziemlich beeindruckend, oder, Hinn?"

    # say L1084 hin
    old "(It's so big.)"
    new "Es ist so groß."

    # say L1085 joh
    old "Haha. This surely is the first time she's seen a real one and seeing one of this size even surprises me."
    new "Haha. Das ist sicher das erste Mal, dass sie einen echten sieht, und so einen großen zu sehen überrascht sogar mich."

    # say L1088 joh
    old "Let me get all this out of here..."
    new "Lass mich das alles hier wegräumen..."

    # say L1093 joh
    old "Certainly... This is awesome, kid... What a big cock you have down here!"
    new "Natürlich... Das ist fantastisch, Junge... Was für eine große Schwanz hast du hier!"

    # say L1100 joh
    old "Well, Hinn, pay close attention... I'm going to teach you how to please a man with your hands, this will be very useful knowledge..."
    new "Nun, Hinn, achten Sie genau darauf... Ich werde Ihnen zeigen, wie Sie einen Mann mit Ihren Händen befriedigen können, das wird sehr nützliches Wissen sein..."

    # say L1102 joh
    old "You have to take it in your hands and start to massage, from top to bottom very carefully..."
    new "Sie müssen es in Ihre Hände nehmen und vorsichtig von oben nach unten massieren..."

    # say L1115 joh
    old "Well... I hope you learned a little more about your sexuality, kids... If you want me to give you another small lesson, just let me know."
    new "Nun... ich hoffe, ihr habt ein bisschen mehr über eure Sexualität gelernt, Kinder... Wenn ihr wollt, dass ich euch noch eine kleine Lektion gebe, lasst es mich einfach wissen."

    # say L1117 joh
    old "See you in the next session."
    new "Bis zur nächsten Sitzung."

    # say L1132 hin
    old "Well..."
    new "Nun..."

    # say L1134 pla
    old "Your mom is coming to pick you up?"
    new "Deine Mom kommt dich abholen?"

    # say L1136 hin
    old "Yes, yes, she is coming to get me."
    new "Ja, ja, sie holt mich ab."

    # say L1138 pla
    old "Oh, ok, then see you tomorrow?"
    new "Oh, ok, dann bis morgen?"

    # say L1174 pla
    old "Yes, I love to help. Also, I think your mom did everything to help you."
    new "Ja, ich freue mich, zu helfen. Und ich denke, deine Mom hat auch alles getan, um dir zu helfen."

    # say L1178 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is how you feel about yourself."
    new "Ich denke echt, du siehst in allem gut aus, was du anziehst. Das Wichtigste ist, wie du dich dabei fühlst."

    # say L1180 hin
    old "Thank you, [pla]. I really appreciate it..."
    new "Danke, [pla]. Das bedeutet mir viel..."

    # say L1182 pla
    old "My pleasure... So, see you this afternoon?"
    new "Mein Vergnügen... Also, sehen wir uns heute Nachmittag?"

    # say L1184 hin
    old "For sure, see you in the afternoon."
    new "Natürlich, bis heute Nachmittag."

    # say L1186 pla
    old "Great. Bye."
    new "Super. Tschüss."

    # say L1217 joh
    old "Hi guys! Ready for the last session?"
    new "Hallo alle! Bereit für die letzte Sitzung?"

    # say L1219 hin
    old "Is this the last session?"
    new "Ist das die letzte Sitzung?"

    # say L1221 joh
    old "Yes, you have advanced very well with the therapy."
    new "Ja, du hast bei der Therapie sehr gut Fortschritte gemacht."

    # say L1222 joh
    old "And have managed to gain more security in yourself and in your body and that was the objective."
    new "Und du hast mehr Sicherheit in dir und deinem Körper gewonnen, und das war das Ziel."

    # say L1224 hin
    old "But... I- I don't feel... Ready."
    new "Aber... ich- ich fühle mich... noch nicht bereit."

    # say L1226 joh
    old "Well... We still have this session, right?"
    new "Na ja... Wir haben ja noch diese Sitzung, oder?"

    # say L1228 hin
    old "Hmm... ok..."
    new "Hmm... okay..."

    # say L1230 joh
    old "All right for this last one I told you that you didn't need to bring any more clothes [pla]."
    new "In Ordnung, für diese letzte Sitzung habe ich dir gesagt, dass du keine Kleidung mehr mitbringen musst [pla]."

    # say L1232 joh
    old "And that's because this last session we are going to do an exercise of accepting your own body."
    new "Und das, weil bei dieser letzten Sitzung wir ein Übungsprogramm machen werden, bei dem du deinen eigenen Körper akzeptierst."

    # say L1235 joh
    old "Right, little by little you started to wear clothes that exposed more of your body, this time there will be nothing covering your body..."
    new "Richtig, allmählich hast du Kleidung getragen, die mehr von deinem Körper gezeigt hat, dieses Mal wird nichts deinen Körper bedecken..."

    # say L1237 hin
    old "So?"
    new "Und?"

    # say L1239 joh
    old "Right, this time you'll be naked."
    new "Stimmt, dieses Mal wirst du nackt sein."

    # say L1245 joh
    old "Come on girl, that's not much different from what you've already done before."
    new "Komm schon, das ist nicht viel anders als das, was du schon gemacht hast."

    # say L1250 joh
    old "Just let's go girl, Your body is natural, your body is perfect."
    new "Kommen Sie schon, Ihre Figur ist natürlich, Ihr Körper ist perfekt."

    # say L1265 joh
    old "Well, I think we're ready!"
    new "Na, ich denke, wir sind bereit!"

    # say L1268 joh
    old "How are you feeling my dear?"
    new "Wie fühlst du dich, meine Liebe?"

    # say L1270 hin
    old "I don't feel very good..."
    new "Ich fühle mich nicht sehr gut..."

    # say L1272 joh
    old "But come on it's very natural, that's your body and it's beautiful, right [pla]?"
    new "Aber komm, es ist sehr natürlich, das ist dein Körper und er ist wunderschön, oder [pla]?"

    # say L1275 joh
    old "Hahaha again in silence?"
    new "Hahaha, wieder mal still?"

    # say L1277 joh
    old "I guess you guys will have played around a bit since the last lesson I gave you, right?"
    new "Ich denke, ihr habt seit der letzten Lektion, die ich euch gegeben habe, schon ein bisschen herumgespielt, oder?"

    # say L1279 hin
    old "... No, we haven't..."
    new "... Nein, haben wir nicht..."

    # say L1281 joh
    old "Oh really? That's a shame."
    new "Oh wirklich? Das ist schade."

    # say L1283 joh
    old "You know what I'll give you another free lesson, would you like to?"
    new "Ich geb dir noch eine kostenlose Stunde, möchtest du?"

    # say L1288 joh
    old "Hahaha, what are you trying to hide [pla] and Hinn's embarrassed face says yes."
    new "HAHAHA, was versuchen Sie zu verbergen [pla] und Hinn's beschämtes Gesicht sagt Ja."

    # say L1290 joh
    old "Okay, but only because it's our last session together."
    new "Okay, aber nur weil es unsere letzte Sitzung zusammen ist."

    # say L1292 joh
    old "Come here Hinn, I'll teach you how to take the next step in male pleasure."
    new "Kommen Sie her, Hinn, ich werde Ihnen beibringen, wie man den nächsten Schritt beim männlichen Vergnügen macht."

    # say L1301 joh
    old "Very well, you take it in your hand and this time you use your mouth."
    new "Sehr gut, Sie nehmen es in Ihre Hand und dieses Mal benutzen Sie Ihren Mund."

    # say L1302 joh
    old "You must pay close attention to the head, it is the most pleasant area"
    new "Sie müssen sich gut auf die Eichel konzentrieren, das ist der angenehmste Bereich."

    # say L1303 joh
    old "So, you should use your tongue and lips to stimulate that whole area."
    new "So, Sie sollten Ihre Zunge und Ihre Lippen verwenden, um diese ganze Region zu stimulieren."

    # say L1315 joh
    old "Well, you've been naked for over 10 min, in front of us and you look pretty comfortable with that."
    new "Nun, du bist schon über 10 Minuten nackt vor uns und siehst ziemlich entspannt damit aus."

    # say L1317 joh
    old "That is proof that my work is already done."
    new "Das ist der Beweis, dass meine Arbeit bereits Früchte trägt."

    # say L1319 hin
    old "Thank you very much Dr. Johnson."
    new "Vielen Dank, Dr. Johnson."

    # say L1321 joh
    old "But girl you can get dressed now, you don't have to be naked all the time..."
    new "Aber Mädchen, du kannst dich jetzt anziehen, du musst nicht die ganze Zeit nackt sein..."

    # say L1323 hin
    old "... Sorry."
    new "... Entschuldigung."

    # say L1332 joh
    old "Well this is it, I hope the sessions and the little lessons have helped you, enjoy your sexuality and your youth guys!"
    new "Nun, das war's. Ich hoffe, die Sitzungen und die kleinen Lektionen haben Ihnen geholfen. Genießen Sie Ihre Sexualität und Ihre Jugend!"

    # say L1336 joh
    old "I hope you do very well."
    new "Ich hoffe, Sie machen es sehr gut."

    # say L1345 pla
    old "How did you feel in today's session?"
    new "Wie hast du dich bei der heutigen Sitzung gefühlt?"

    # say L1347 hin
    old "I think it was exciting..."
    new "Ich denke, es war aufregend..."

    # say L1349 pla
    old "Ehmm, yes, it was exciting, right?"
    new "Ehmm, ja, es war aufregend, oder?"

    # say L1351 hin
    old "Did you like it?"
    new "Hast du es gemocht?"

    # say L1353 pla
    old "Well... Yes."
    new "Na ja... Ja."

    # say L1355 hin
    old "I liked too."
    new "Mir hat's auch gefallen."

    # say L1359 pla
    old "Ok, then see you tomorrow?"
    new "Ok, dann bis morgen?"

    # say L1398 pla
    old "See you, Hinn."
    new "Bis morgen, Hinn."

    # say L1412 pla
    old "Yes! We finally did it! We finished the project, even Mrs. Mia was happy with it!"
    new "Ja! Wir haben es geschafft! Das Projekt ist fertig, sogar Mrs. Mia war zufrieden damit!"

    # say L1414 hin
    old "Great, now that we're done, I want to ask you if... Will you continue to accompany me to therapy sessions?"
    new "Super, jetzt wo wir fertig sind, wollte ich dich fragen, ob... Wirst du weiter mit mir zu den Therapiesitzungen gehen?"

    # say L1418 hin
    old "FOR REAL?"
    new "Wirklich?"

    # say L1420 hin
    old "I mean... Seriously?"
    new "Ich meine... Ernsthaft?"

    # say L1422 pla
    old "Sure! Well, only if you want too."
    new "Klar! Also nur, wenn du willst."

    # say L1424 hin
    old "Yes, I would like it! You have helped me a lot and I would like to continue hanging out with you."
    new "Ja, ich würde das gerne! Du hast mir so viel geholfen und ich möchte gerne weiter mit dir abhängen."

    # say L1426 pla
    old "You can always count on me, Hinn."
    new "Du kannst dich immer auf mich verlassen, Hinn."

    # say L1428 hin
    old "...Thank you, [pla]! I really mean it."
    new "Danke, [pla]! Ich meine das wirklich ernst."

    # say L1430 hin
    old "But how are you going to keep the sessions going, Doctor Johnson said we were done."
    new "Aber wie willst du die Sitzungen weiterführen, Dr. Johnson hat gesagt, wir wären fertig."

    # say L1432 pla
    old "Hmm... Let me talk to her and see what I can do."
    new "Hmm... Lass mich mit ihr reden und sehen, was ich machen kann."

    # say L1434 hin
    old "Great! I hope you can convince her..."
    new "Super! Ich hoffe, du kannst sie überzeugen..."

    # say L1436 pla
    old "Yes me too."
    new "Ja, ich auch."

    # say L1459 ang
    old "Thank you very much Dr. Johnson, today's session was great."
    new "Vielen Dank, Dr. Johnson, das Gespräch heute war großartig."

    # say L1463 joh
    old "I hope these tips help you, in the next session and we will analyze the progress."
    new "Ich hoffe, diese Tipps helfen Ihnen. Bei der nächsten Sitzung werden wir den Fortschritt analysieren."

    # say L1465 ang
    old "Very well, goodbye doctor."
    new "Sehr gut, auf Wiedersehen Doktor."

    # say L1467 joh
    old "Bye bye."
    new "Auf Wiedersehen."

    # say L1471 joh
    old "Hey, hello [pla] how are you doing?"
    new "Hey, hallo [pla] wie geht es Ihnen?"

    # say L1473 pla
    old "I'm doing good Dr. Johnson."
    new "Ich bin gut, Dr. Johnson."

    # say L1475 joh
    old "How can I help you?"
    new "Wie kann ich Ihnen helfen?"

    # say L1477 pla
    old "Well... I've been thinking with Hinn... And we wonder if we can continue with the..."
    new "Nun... Ich habe mit Hinn darüber nachgedacht... Und wir fragen uns, ob wir mit der... weitermachen können."

    # say L1479 joh
    old "With the?"
    new "Mit der?"

    # say L1481 pla
    old "If we can continue with the therapy?"
    new "Können wir mit der Therapie weitermachen?"

    # say L1483 joh
    old "Oh, Hmm... I made an exception with you guys since that kind of session is for couple therapy..."
    new "Oh, Hmm... Ich habe bei Ihnen beiden eine Ausnahme gemacht, da diese Art von Sitzung eigentlich für Paartherapie gedacht ist..."

    # say L1485 pla
    old "Hmm, could we get some more of those?"
    new "Hmm, könnten wir noch mehr davon bekommen?"

    # say L1487 joh
    old "I don't think so, I'm sorry [pla]..."
    new "Ich denke nicht, dass das möglich ist, tut mir leid [pla]..."

    # say L1489 pla
    old "(Hmm... I think I should use it this time...)"
    new "Hmm... Ich denke, ich sollte es dieses Mal benutzen..."

    # say L1493 joh
    old "Hmm, you know what, let's make a deal..."
    new "Hmm, Sie wissen was, lassen Sie uns einen Deal machen..."

    # say L1495 joh
    old "I'll give those therapy sessions if you help me with another patients exercise, I think you could help me with them..."
    new "Ich werde diese Therapiesitzungen durchführen, wenn Sie mir bei den Übungen eines anderen Patienten helfen. Ich denke, Sie könnten mir dabei sehr weiterhelfen..."

    # say L1497 pla
    old "Help with another patients?"
    new "Hilfe bei anderen Patienten?"

    # say L1499 joh
    old "Yes, I actually have a case where I think you would be a great help..."
    new "Ja, ich habe tatsächlich einen Fall, bei dem ich denke, dass Sie eine große Hilfe wären..."

    # say L1501 pla
    old "Hmm okay, and will the therapy continue in return?"
    new "Hmm okay, und wird die Therapie im Gegenzug weitergehen?"

    # say L1503 joh
    old "Yes, I think it is an excellent deal."
    new "Ja, ich denke, das ist ein ausgezeichneter Deal."

    # say L1505 pla
    old "Very well then, Hinn will schedule the appointment for the next lesson."
    new "Sehr gut, dann wird Hinn den Termin für die nächste Lektion vereinbaren."

    # say L1507 joh
    old "Perfect, I'll let you know when I need you to work with my patient."
    new "Perfekt, ich werde Sie informieren, wenn ich Sie für die Behandlung meines Patienten benötige."

    # say L1509 pla
    old "Understood."
    new "Verstanden."

    # say L1516 hin
    old "Well? What happened?"
    new "Na? Was ist passiert?"

    # say L1518 pla
    old "Everything is settled, you just have to call her to make the next appointment."
    new "Alles ist geregelt, du musst sie nur anrufen, um den nächsten Termin zu vereinbaren."

    # say L1520 hin
    old "Really? Excellent! I'll call her right away, thanks [pla]."
    new "Wirklich? Prima! Ich rufe sie sofort an, danke [pla]."

    # say L1522 pla
    old "No problem. Then, see you tomorrow?"
    new "Kein Problem. Dann, bis morgen?"

    # say L1547 joh
    old "Wow Hinn, you decided to not wear the jacket, I see that the sessions served you well."
    new "Wow Hinn, Sie haben sich entschieden, die Jacke nicht zu tragen, ich sehe, dass die Sitzungen Ihnen gutgetan haben."

    # say L1552 joh
    old "Well, you're looking forward to continuing my therapy, uh?"
    new "Nun, Sie freuen sich darauf, die Therapie fortzusetzen, hm?"

    # say L1556 pla
    old "Well... "
    new "Na ja..."

    # say L1558 joh
    old "Hahaha I like to give therapy, so, don't worry guys."
    new "Hahaha ich gebe gerne Therapie, also machen Sie sich keine Sorgen, meine Herren."

    # say L1560 joh
    old "I think I've already given you a good introduction, what do you say if we go to Hinn's practice?"
    new "Ich denke, ich habe Ihnen bereits eine gute Einführung gegeben, was sagen Sie dazu, wenn wir zu Hinn's Praxis gehen?"

    # say L1564 joh
    old "Come on girl, don't be shy, after all you guys asked me for more lessons, right?"
    new "Komm schon, sei nicht schüchtern, immerhin habt ihr mich um mehr Unterricht gebeten, oder?"

    # say L1566 hin
    old "Yes, yes, I'm sorry..."
    new "Ja, ja, ich bin sorry..."

    # say L1568 joh
    old "All right, let's go step by step, ok?"
    new "Okay, lass uns Schritt für Schritt vorgehen, okay?"

    # say L1572 joh
    old "[pla] take off your shorts and sit on the couch, you come with me Hinn..."
    new "[pla] zieh deine Shorts aus und setz dich auf die Couch, du kommst mit mir Hinn..."

    # say L1580 joh
    old "Oh yeah take it like that, fill your hand completely right?"
    new "Oh ja, mach so, fülle deine Hand ganz damit, richtig?"

    # say L1582 joh
    old "How does it feel Hinn..."
    new "Wie fühlt es sich an, Hinn..."

    # say L1583 hin
    old "Warm and... Hard..."
    new "Warm und... Hart..."

    # say L1585 joh
    old "Hahaha the advantages of youth."
    new "Ha ha ha, die Vorteile der Jugend."

    # say L1598 joh
    old "All right guys I think that's it for this lesson."
    new "Okay Leute, ich denke, das war's für diese Lektion."

    # say L1600 joh
    old "I think you both enjoyed it a lot, and you already have some things to practice at home..."
    new "Ich denke, ihr habt beide sehr viel Spaß daran gehabt und habt schon ein paar Dinge zum Üben zu Hause..."

    # say L1604 joh
    old "It was really a pleasure guys, I'll wait for you for the next lesson..."
    new "Es war wirklich eine Freude, ich freue mich auf das nächste Mal..."

    # say L1611 hin
    old "That was... Fun."
    new "Das war... Spaß."

    # say L1613 pla
    old "Yes, I think it was... Very educational."
    new "Ja, ich denke es war... sehr aufschlussreich."

    # say L1615 hin
    old "Hehehe yes it was..."
    new "Hehehe ja, das war es..."

    # say L1621 pla
    old "Well, see you tomorrow Hinn."
    new "Na dann, bis morgen Hinn."

    # say L1640 pla
    old "Hi Hinn, how are you?"
    new "Hi Hinn, wie geht's dir?"

    # say L1642 hin
    old "I'm great-"
    new "Ich bin super-"

    # say L1650 rub
    old "Wow, did you lose your ugly sweatshirt girl?"
    new "Wow, hast du dein hässliches Sweatshirt verloren?"

    # say L1654 rub
    old "Yes, don't you feel sorry to show that fatness?"
    new "Ja, fühlst du dich nicht schade, das Fett zu zeigen?"

    # say L1656 pla
    old "Really, you aga-"
    new "Wirklich, du wieder-"

    # say L1658 hin
    old "Are you talking about my big boobs? You envious Ruby jerk?"
    new "Sprichst du von meinen großen Titten? Du neidische Ruby-Zicke?"

    # say L1660 rub
    old "What ?! I envy? I don't know what-"
    new "Was?! Neidisch? Ich hab keine Ahnung, wovon-"

    # say L1662 hin
    old "Ohh sorry, I'm a woman with a really good body and some brain..."
    new "Ohh Entschuldigung, ich bin eine Frau mit einem wirklich guten Körper und ein bisschen Grips..."

    # say L1668 hin
    old "Ohh I'm sorry, was it too much for your little head? Maybe tomorrow you will understand it..."
    new "Ohh, tut mir leid, war es zu viel für deinen kleinen Kopf? Vielleicht verstehst du es morgen..."

    # say L1670 hin
    old "Right now I don't have time to waste with a couple of stupid brainless girls like you. See ya..."
    new "Im Moment hab ich echt keine Zeit, mich mit so dummen, hirnlosen Mädels wie dir zu beschäftigen. Bis dann..."

    # say L1679 pla
    old "Hehehe see ya..."
    new "Hehehe, bis dann..."

    # say L1681 rub
    old "Oh you shut up, loser!"
    new "Oh du hältst die Klappe, Verlierer!"

    # say L1683 pla
    old "Ugh, sorry..."
    new "Ugh, tut mir leid..."

    # say L1693 pla
    old "Wow Hinn that was great!"
    new "Wow Hinn das war toll!"

    # say L1695 hin
    old "It doesn't matter, come sit on the couch."
    new "Das ist egal, komm und setz dich auf die Couch."

    # say L1697 pla
    old "What? What for?"
    new "Was? Wofür?"

    # say L1699 hin
    old "I'm going to suck it you, sit down..."
    new "Ich werde es dir blasen, setz dich hin..."

    # say L1701 pla
    old "(What the...) All right."
    new "(Was zum...) Okay."

    # say L1712 pla
    old "Are you sure-"
    new "Bist du dir sicher-"

    # say L1715 hin
    old "You just watch and enjoy."
    new "Du schaust einfach zu und genießt."

    # say L1729 hin
    old "Sorry, sorry. I was so impulsive... I just felt adrenaline after what happened and I wanted to try-"
    new "Entschuldigung, entschuldigung. Ich war so impulsiv... Ich habe einfach Adrenalin gespürt, nachdem das passiert ist, und ich wollte es ausprobieren-"

    # say L1731 pla
    old "No, don't worry, I'm amazed at your progress, you're more confident."
    new "Nein, mach dir keine Sorgen, ich bin beeindruckt von deinem Fortschritt, du bist selbstbewusster geworden."

    # say L1733 pla
    old "And I like that."
    new "Und ich mag das."

    # say L1737 pla
    old "Yes, it was exciting."
    new "Ja, es war aufregend."

    # say L1739 hin
    old "I think Dr. Johnson has helped a lot."
    new "Ich denke, Dr. Johnson hat wirklich viel geholfen."

    # say L1741 pla
    old "You bet she has..."
    new "Klar, sie hat echt geholfen..."

    # say L1745 hin
    old "Well, I think my mom will be here soon, we can continue tomorrow, what do you think?"
    new "Na ja, ich denke, meine Mom wird bald hier sein, wir können morgen weitermachen, was meinst du?"

    # say L1747 pla
    old "Sure, see you tomorrow Hinn."
    new "Klar, bis morgen Hinn."

    # say L1767 pla
    old "I love it."
    new "Ich liebe es."

    # say L1769 hin
    old "I'm glad you liked."
    new "Ich freue mich, dass es dir gefallen hat."

    # say L1771 hin
    old "Whenever you want another one we could practice again."
    new "Wann immer du wieder einen willst, können wir üben."

    # say L1775 hin
    old "Great. See you tomorrow."
    new "Super. Bis morgen."

    # say L1777 pla
    old "Good night Hinn."
    new "Gute Nacht Hinn."

    # say L1797 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy session."
    new "Ich bin super, danke [pla]. Ich habe auf dich gewartet, heute ist die neue Therapiesitzung."

    # say L1809 joh
    old "Hi guys! Think you're ready to go on with the lessons, uh?"
    new "Hallo alle! Denke, ihr seid bereit für die nächsten Lektionen, hm?"

    # say L1811 hin
    old "Yes, but we would like to try something more advanced..."
    new "Ja, aber wir möchten gerne etwas Fortgeschritteneres ausprobieren..."

    # say L1815 joh
    old "Hahaha, that's what I wanted to hear. And what about you [pla]? Ready for the next level?"
    new "Hahaha, das wollte ich hören. Und was ist mit Ihnen [pla]? Bereit für das nächste Level?"

    # say L1817 pla
    old "... Well-"
    new "... Na ja-"

    # say L1819 joh
    old "Great, let's not waste any more time..."
    new "Großartig, lassen Sie uns keine Zeit mehr verschwenden..."

    # say L1821 joh
    old "Let's heat the situation up a bit, since you want something more advanced Hinn, let's try a double blowjob."
    new "Lassen Sie uns die Situation ein wenig aufheizen, da Sie etwas Fortgeschritteneres wollen, Hinn. Lassen Sie uns einen Doppelblowjob versuchen."

    # say L1823 joh
    old "I hope it's not too much for you..."
    new "Ich hoffe, es ist nicht zu viel für dich..."

    # say L1825 hin
    old "Okay, let's try it."
    new "Okay, probieren wir's."

    # say L1827 joh
    old "Hahaha who are you and what did you do with Hinn?"
    new "Hahaha, wer bist du und was hast du mit Hinn gemacht?"

    # say L1829 joh
    old "All right [pla] down your pants and Hinn you bend down with me."
    new "Okay [pla] die Hose runter und Hinn, du beugst dich mit mir hinunter."

    # say L1836 joh
    old "With your tongue, stimulate the tip of the penis."
    new "Mit Ihrer Zunge reizen Sie die Spitze des Penis."

    # say L1837 joh
    old "This drives any man crazy..."
    new "Das treibt jeden Mann in den Wahnsinn..."

    # say L1849 joh
    old "Hmm, I think you guys are ready to do it right?"
    new "Hmm, ich denke, Sie sind bereit, es richtig zu machen?"

    # say L1851 pla
    old "Do... What?"
    new "Was... Was?"

    # say L1853 joh
    old "Fuck, let's fuck guys..."
    new "Verdammt, lasst uns ficken, Jungs..."

    # say L1857 joh
    old "Come with me."
    new "Kommen Sie mit mir."

    # say L1866 joh
    old "This is a practice room that I use with some patients."
    new "Dies ist ein Übungsraum, den ich mit einigen Patienten nutze."

    # say L1868 joh
    old "Come on guys take off your clothes, today you are going to have sex!"
    new "Kommen Sie, ziehen Sie sich aus, heute werden Sie miteinander schlafen!"

    # say L1876 joh
    old "What's up [pla]? Now are you the shy one?"
    new "Was ist los [pla]? Jetzt sind Sie der Schüchterne?"

    # say L1878 joh
    old "Maybe you need some example..."
    new "Vielleicht brauchen Sie ein Beispiel..."

    # say L1884 joh
    old "Well? What are you waiting for, you're the only one with clothes, don't you want to fuck this cute Hinn?"
    new "Na? Was wartest du noch, du bist der Einzige, der noch angezogen ist, willst du Hinn nicht ficken?"

    # say L1894 joh
    old "All right, as I know this is probably your first time, let's go smooth and slow..."
    new "Na gut, da ich weiß, dass es wahrscheinlich dein erstes Mal ist, machen wir es langsam und sanft..."

    # say L1895 joh
    old "Let me lubricate it well before we start."
    new "Lass mich es gut einreiben, bevor wir anfangen."

    # say L1907 joh
    old "Well guys, I hope to see you for a lesson soon... You can continue your practices in the meantime."
    new "Nun, ich hoffe, wir sehen uns bald für eine Lektion... Ihr könnt in der Zwischenzeit weiter üben."

    # say L1909 hin
    old "Yes, it was a lot of fun."
    new "Ja, es war richtig spaßig."

    # say L1911 joh
    old "Great, I think that's it for today let's get dressed and go to the office."
    new "Perfekt, ich denke, das war's für heute. Ziehen wir uns an und gehen ins Büro."

    # say L1919 joh
    old "Well guys, I hope to see you for a next lesson soon... You can continue your practices in the meantime."
    new "Na gut, ich hoffe, wir sehen uns bald bei der nächsten Stunde... Ihr könnt in der Zwischenzeit weiter üben."

    # say L1923 joh
    old "Alright, see you in the next lesson."
    new "Bis zum nächsten Mal."

    # say L1962 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy sesion."
    new "Ich bin großartig, danke [pla]. Ich habe auf Sie gewartet, heute ist die neue Therapiesitzung."

    # say L1974 joh
    old "What do we have here? Ready for another hardcore sex lesson?"
    new "Was haben wir denn hier? Bereit für eine weitere harte Sexstunde?"

    # say L1980 joh
    old "Haha that's great..."
    new "Haha das ist toll..."

    # say L1982 hin
    old "So, are we going to the couch?"
    new "Sind wir dann aufs Sofa unterwegs?"

    # say L1984 joh
    old "Ohh no, let's not waste time, let's go directly to a more comfortable place..."
    new "Oh nein, lass uns keine Zeit verschwenden, gehen wir direkt zu einem bequemeren Ort..."

    # say L1992 joh
    old "Alright lie down on the bed [pla] and Hinn get on top of him."
    new "Okay, leg dich aufs Bett [pla] und Hinn, setz dich auf ihn drauf."

    # say L1994 joh
    old "We're going to lubricate that cock well while [pla] giving you some pleasure."
    new "Wir werden diesen Schwanz gut eincremen, während [pla] dir ein bisschen Vergnügen bereitet."

    # say L2010 joh
    old "All right, are you ready for another hardfuck Hinn?"
    new "Alles klar, sind Sie bereit für einen weiteren harten Fick, Hinn?"

    # say L2014 joh
    old "I've seen that [pla] has been looking at my big boobs a lot, uh?"
    new "Ich habe gesehen, dass [pla] oft auf meine großen Brüste schaut, hm?"

    # say L2016 pla
    old "... No, no, I just-"
    new "Nein, nein, ich hab nur..."

    # say L2018 joh
    old "Hahaha, come on I've already sucked your penis, there's no reason to be ashamed."
    new "Hahaha, kommen Sie schon, ich habe Ihren Penis schon geleckt, da gibt es keinen Grund, sich zu schämen."

    # say L2020 joh
    old "Actually, today while you fuck Hinn you are going to enjoy my soft and big boobs..."
    new "Tatsächlich, heute, während Sie Hinn ficken, werden Sie meine weichen und großen Brüste genießen..."

    # say L2036 joh
    old "Another successful session guys... Let's get dressed."
    new "Noch eine erfolgreiche Sitzung, Leute... Lasst uns uns anziehen."

    # say L2044 joh
    old "All right that's it for today, I hope to see you soon for a next lesson guys."
    new "Na gut, das war's für heute, ich hoffe, euch sehe ich bald bei der nächsten Sitzung."

    # say L2046 hin
    old "Of course we will Dr. Johnson."
    new "Natürlich werden wir das, Dr. Johnson."

    # say L2097 joh
    old "Oh, but here are my favorite patients... Hehehe."
    new "Oh, aber hier sind meine Lieblingspatienten... Hehehe."

    # say L2099 hin
    old "Good afternoon Dr. Johnson."
    new "Guten Nachmittag Dr. Johnson."

    # say L2101 joh
    old "How are you guys? Ready for our last lesson?"
    new "Wie geht es Ihnen beiden? Bereit für unsere letzte Lektion?"

    # say L2103 pla
    old "Last lesson?"
    new "Letzte Lektion?"

    # say L2105 joh
    old "Yes, I think you already have the basics, it is important that you now experience for yourselves to discover your own sexuality."
    new "Ja, ich denke, Sie haben die Grundlagen schon begriffen. Es ist wichtig, dass Sie nun selbst erleben, um Ihre eigene Sexualität zu entdecken."

    # say L2107 hin
    old "But... Can't we go on?"
    new "Aber... Können wir nicht weitermachen?"

    # say L2109 joh
    old "Well, we could repeat some of the lessons we've already done..."
    new "Nun, wir könnten einige der bereits durchgeführten Übungen wiederholen..."

    # say L2111 hin
    old "Oh great, sounds good..."
    new "Oh toll, klingt gut..."

    # say L2113 pla
    old "So, what will we do today?"
    new "Also, was machen wir heute?"

    # say L2115 joh
    old "Let's go to the room and I'll explain."
    new "Gehen wir in den Raum und ich werde es Ihnen erklären."

    # say L2123 joh
    old "All right, let's heat things up a bit by lubricating it well, you know what to do."
    new "Also, lassen Sie uns die Sache ein bisschen aufheizen, indem wir es gut einschmieren, Sie wissen schon, was zu tun ist."

    # say L2137 joh
    old "Well, that was great, now you [pla] are going to fuck Hinn alone."
    new "Nun, das war großartig, jetzt wird [pla] Hinn alleine ficken."

    # say L2141 joh
    old "Yes, I will just be watching, the idea is that you can continue to do it yourself so that you can enjoy your sexuality alone."
    new "Ja, ich werde nur zusehen. Die Idee ist, dass du es selbst weitermachen kannst, damit du deine Sexualität allein genießen kannst."

    # say L2143 pla
    old "Hmm ok."
    new "Hmm okay."

    # say L2162 joh
    old "Well guys, that was it for today, get dressed."
    new "Na gut, Jungs, das war's für heute, zieht euch an."

    # say L2170 joh
    old "I think it's time for you to practice what you learned. Enjoy it guys!"
    new "Ich denke, es ist Zeit, dass Sie das Gelernte in die Praxis umsetzen. Viel Spaß damit!"

    # say L2172 joh
    old "If you want to repeat one of the lessons, don't hesitate to come back."
    new "Wenn du eine der Lektionen wiederholen möchtest, zögere nicht, zurückzukommen."

    # say L2212 hin
    old "I'm great, What about you?"
    new "Ich bin großartig, wie geht es dir?"

    # say L2216 hin
    old "So? Would you like to repeat some session with Dr. Johnson?"
    new "So? Möchten Sie eine Sitzung mit Dr. Johnson wiederholen?"

    # say L2221 pla
    old "Of course! Let's do it."
    new "Natürlich! Lass uns das machen."

    # say L2230 pla
    old "I really would like to... But I can't right now."
    new "Ich würde wirklich gerne... Aber ich kann im Moment nicht."

    # say L2232 hin
    old "Oh don't worry you can look for me if you change your mind."
    new "Oh mach dir keine Sorgen, du kannst mich suchen, wenn du deine Meinung änderst."

    # say L2234 pla
    old "I will do it."
    new "Ich werde es tun."

    # say L2255 joh
    old "I knew it would not take long for you to return from the last session."
    new "Ich wusste, es würde nicht lange dauern, bis Sie von der letzten Sitzung zurückkehren."

    # say L2257 joh
    old "So? What do you want to do today guys?"
    new "So? Was wollen Sie heute machen, Jungs?"

    # say L2269 joh
    old "Oh, you guys want to go from the beginning, right?"
    new "Oh, Sie wollen also von vorne beginnen, richtig?"

    # say L2273 joh
    old "I like it! Let's do it."
    new "Mir gefällt es! Lassen Sie uns das machen."

    # say L2283 joh
    old "It always surprises me!"
    new "Es überrascht mich immer wieder!"

    # say L2290 joh
    old "Well, let's do it..."
    new "Nun, machen wir es..."

    # say L2304 joh
    old "Do you need another blowjob lesson? Uh? Or just [pla] want a good blowjob from me?"
    new "Brauchen Sie noch eine Blasenstunde? Oder will [pla] einfach nur einen guten Blowjob von mir?"

    # say L2308 joh
    old "Anyway... I like it! Let's do it."
    new "Na ja... Ich mag es! Lass uns anfangen."

    # say L2329 joh
    old "O third lesson, let's team up to give [pla] a great amount of pleasure!"
    new "Dritte Lektion, lass uns zusammen [pla] eine Menge Vergnügen bereiten!"

    # say L2342 joh
    old "Your cock is in one of biggest I've ever saw."
    new "Ihr Schwanz ist einer der größten, die ich je gesehen habe."

    # say L2355 joh
    old "Double blowjob and Doggystyle? How great does it sounds?"
    new "Doppel Blowjob und Doggystyle? Wie großartig klingt das?"

    # say L2367 joh
    old "And you are becoming some kind of expert Hinn!"
    new "Und Sie werden langsam zu einem richtigen Experten, Hinn!"

    # menu L2372 
    old "Lesson 5"
    new "Lektion 5"

    # say L2380 joh
    old "Do you want to have my boobs on your face while you fuck Hinn, uh?"
    new "Möchten Sie, dass meine Titten Ihr Gesicht bedecken, während Sie Hinn ficken, hm?"

    # menu L2403 
    old "Lesson 6"
    new "Lektion 6"

    # say L2411 joh
    old "Oh god, I'm dying to see that pretty face covered with a good facial."
    new "Oh Gott, ich sterbe darauf, dieses hübsche Gesicht mit einem guten Gesichtsspritz benetzt zu sehen."

    # say L2423 joh
    old "Alright lie down on the bed [pla] and your Hinn get on top of him."
    new "Okay, leg dich aufs Bett [pla] und dein Hinn steigt auf ihn drauf."

    # say L2440 joh
    old "All right guys, that was fun, but it's all for today."
    new "Na gut, das war lustig, aber damit ist es für heute genug."

    # say L2444 hin
    old "Will come back soon..."
    new "Ich werde bald wiederkommen..."

    # say L2446 joh
    old "I will be waiting."
    new "Ich werde auf Sie warten."

    # say L2448 pla
    old "See you soon Dr Johnson."
    new "Bis bald, Dr. Johnson."

    # say L2457 hin
    old "That was hot, right?"
    new "Das war scharf, oder?"

    # say L2459 pla
    old "Yes, it was great."
    new "Ja, es war toll."

    # say L2461 hin
    old "Hehehe do want to repeat it tomorrow?"
    new "Hehehe, willst du es morgen wiederholen?"

    # say L2465 hin
    old "Nice, then see you tomorrow [pla]."
    new "Nett, dann bis morgen [pla]."

    # say L2467 pla
    old "Ok, see you tomorrow Hinn."
    new "Ok, bis morgen Hinn."


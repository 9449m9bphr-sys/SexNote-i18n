# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/hinAnimations.rpy
translate german strings:

    # say L6 joh
    old "Little by little, you start to increase the speed..."
    new "Langsam erhöhen Sie das Tempo..."

    # say L13 joh
    old "You can feel his body start to tense, warm up, that means he's close..."
    new "Du kannst spüren, wie sein Körper sich anspannt, warm wird, das bedeutet, er ist nah dran..."

    # say L38 joh
    old "Ready for the shot?"
    new "Bist du bereit für den Schuss?"

    # say L39 hin
    old "For what?"
    new "Wofür?"

    # say L45 joh
    old "That's it! Did you like [pla]?"
    new "Das ist es! Hat Ihnen [pla] gefallen?"

    # say L47 joh
    old "Haha. And what about you, Hinn? How was it for you?"
    new "Haha. Und wie war es für Sie, Hinn?"

    # say L62 pla
    old "It was great."
    new "Es war toll."

    # say L104 joh
    old "Wow, I wasn't expecting it... That was a lot."
    new "Wow, ich habe das nicht erwartet... Das war wirklich viel."

    # say L110 joh
    old "A lot of cum as always, yummy"
    new "Viel Sperma wie immer, lecker"

    # say L120 joh
    old "Go slowly increasing speed with me."
    new "Langsam mit mir, steigere die Geschwindigkeit."

    # say L124 joh
    old "How does it feel [pla]?"
    new "Wie fühlt es sich an [pla]?"

    # say L125 pla
    old "It... feels, very good..."
    new "Es... fühlt sich sehr gut an..."

    # say L129 joh
    old "How about if we make him cum Hinn?"
    new "Was halten Sie davon, wenn wir ihn zum Orgasmus bringen, Hinn?"

    # say L130 hin
    old "(Oh My... Yes!)"
    new "Oh mein Gott... Ja!"

    # say L155 joh
    old "Yes [pla], give us everything."
    new "Ja [pla], geben Sie uns alles."

    # say L163 joh
    old "Nice!"
    new "Schön!"

    # say L164 joh
    old "And it's still hard... Beautiful youth, I think we can continue with the next practice, what do you say Hinn?"
    new "Und es ist immer noch hart... Schöne Jugend, ich denke, wir können mit der nächsten Übung fortfahren, was sagen Sie Hinn?"

    # say L174 joh
    old "Well, you already saw me do it, in the last session, so it's your turn."
    new "Nun, Sie haben mich ja schon beim letzten Mal dabei beobachtet, also ist es jetzt Ihre Reihe."

    # say L176 joh
    old "Don't worry I will help you."
    new "Keine Sorge, ich werde Ihnen helfen."

    # say L178 joh
    old "Remember to brush your hair very well and be careful with your teeth, ok?"
    new "Denken Sie daran, Ihr Haar gut zu bürsten und vorsichtig mit Ihren Zähnen umzugehen, okay?"

    # say L182 joh
    old "Very well, go ahead you can do a little more..."
    new "Sehr gut, fahren Sie fort, Sie können noch ein bisschen mehr tun..."

    # say L187 joh
    old "You feel it in your throat right? Well now take it out slowly."
    new "Sie spüren es in Ihrem Hals, richtig? Nun nehmen Sie es langsam heraus."

    # say L196 joh
    old "Great! Now keep doing it."
    new "Gut! Machen Sie weiter so."

    # say L202 joh
    old "All right honey, you're doing great."
    new "Alles gut, Liebling, du machst das toll."

    # say L204 pla
    old "Uh... It feels very... good."
    new "Äh... Es fühlt sich sehr... gut an."

    # say L212 pla
    old "I going to..."
    new "Ich werde..."

    # say L222 joh
    old "And it's still hard... You know what to do Hinn... It's time to deepthroat!"
    new "Und es ist immer noch hart... Sie wissen, was zu tun ist, Hinn... Es ist Zeit, tief zu schlucken!"

    # say L243 joh
    old "All right, how about we do it a little faster?"
    new "Na gut, wie wäre es, wenn wir es ein bisschen schneller machen?"

    # say L251 joh
    old "You have to learn to read your partner's expressions."
    new "Sie müssen lernen, die Mimik Ihres Partners zu lesen."

    # say L252 joh
    old "Look how he starts to tense his legs, that means he is enjoying it, so, we have to do it a little faster."
    new "Siehst du, wie er seine Beine anspannt? Das bedeutet, dass er es genießt. Also, wir müssen es ein bisschen schneller machen."

    # say L276 joh
    old "All right, are you ready for the shot? Get it in your mouth, so, you don't make a mess here."
    new "Alles klar, bist du bereit für die Spritze? Nimm sie in den Mund, damit du hier keinen Dreck machst."

    # say L277 hin
    old "What?"
    new "Was?"

    # say L282 joh
    old "Great Hinn!"
    new "Großer Hinn!"

    # say L283 joh
    old "You did very well, right [pla]?"
    new "Sie haben sehr gut gemacht, richtig [pla]?"

    # say L284 pla
    old "Uh?... Sorry what?"
    new "Uh?... Entschuldigung, was?"

    # say L285 joh
    old "Hahaha, let's let [pla] to recover while I help you clean up in the bathroom."
    new "Hahaha, lassen Sie [pla] sich erst mal erholen, während ich Ihnen im Bad beim Saubermachen helfe."

    # say L291 hin
    old "Of course."
    new "Natürlich."

    # say L296 joh
    old "All right, Hinn!"
    new "Alles klar, Hinn!"

    # say L298 pla
    old "She did it awesome!"
    new "Sie hat es toll gemacht!"

    # say L299 joh
    old "Hahaha, you are improving Hinn."
    new "Hahaha, Sie verbessern sich, Hinn."

    # say L308 joh
    old "Wow, it looks like someone was practicing the lessons at home."
    new "Wow, es sieht so aus, als hätte jemand die Lektionen zu Hause geübt."

    # say L312 joh
    old "All right, let's go a little faster."
    new "Na gut, dann gehen wir ein bisschen schneller."

    # say L340 pla
    old "Girls, I think I'm going to..."
    new "Mädchen, ich glaube, ich mache jetzt..."

    # say L358 joh
    old "Well, it's time to fuck!"
    new "Nun, es ist Zeit, zu ficken!"

    # say L366 joh
    old "Let me lubricate it well before I start."
    new "Lassen Sie mich es gut einreiben, bevor ich anfange."

    # say L413 joh
    old "Well I think that's enough, now you're going to penetrate Hinn..."
    new "Ich denke, das reicht jetzt, Sie werden Hinn gleich penetrieren..."

    # say L414 pla
    old "Wow... Ok."
    new "Wow... Okay."

    # say L415 joh
    old "Slowly and carefully..."
    new "Langsam und vorsichtig..."

    # say L421 joh
    old "Hinn you're going to enjoy the wonder of being a woman."
    new "Hinn, Sie werden das Wunder, eine Frau zu sein, genießen."

    # say L425 joh
    old "Ready for that big cock Hinn?"
    new "Bereit für diesen großen Schwanz, Hinn?"

    # say L439 joh
    old "All right [pla], now let's go a little faster."
    new "Okay [pla], jetzt gehen wir ein bisschen schneller."

    # say L443 joh
    old "How you feeling Hinn?"
    new "Wie fühlst du dich, Hinn?"

    # say L444 hin
    old "Oh... It feels.... Aghh... Aghhh..."
    new "Oh... Es fühlt sich.... Aghh... Aghhh..."

    # say L445 joh
    old "That's what I thought..."
    new "Das dachte ich mir..."

    # say L449 joh
    old "Fuck her harder, make her cum with you!"
    new "Fick sie härter, bring sie zum Kommen!"

    # say L472 joh
    old "Get it out, get it out, come in my mouth!"
    new "Raus damit, raus damit, spritz in meinen Mund!"

    # say L478 joh
    old "Ohh yeah, yummy...."
    new "Ohh ja, lecker..."

    # say L502 joh
    old "He is going to cum..."
    new "Er kommt..."

    # say L503 hin
    old "Then, let's do it faster..."
    new "Dann machen wir es schneller..."

    # say L504 joh
    old "Good girl."
    new "Gutes Mädchen."

    # say L536 joh
    old "All right is time to fuck!"
    new "Dann ist es Zeit zu ficken!"

    # say L604 joh
    old "Very well [pla], you already know what to do..."
    new "Sehr gut [pla], Sie wissen ja schon, was zu tun ist..."

    # say L615 joh
    old "Do you like this [pla]? Do you like my tits on your face?"
    new "Gefällt Ihnen das [pla]? Gefallen Ihnen meine Titten in Ihrem Gesicht?"

    # say L616 pla
    old "(Hell yeah!)"
    new "Klar, verdammt!"

    # say L620 joh
    old "Yeah! yeah! Let's fuck Hinn harder!"
    new "Ja! Ja! Lass uns Hinn härter ficken!"

    # say L624 joh
    old "Are you enjoying it Hinn? Yes? Do you like [pla]'s cock?"
    new "Genießen Sie es, Hinn? Ja? Magst du [pla]s Schwanz?"

    # say L625 hin
    old "Oh, yess... Aghhh... Aghhh..."
    new "Oh, ja... Aghhh... Aghhh..."

    # say L648 joh
    old "Are you going to cum [pla]? Oh yeah? Cum inside her..."
    new "Wird [pla] kommen? Oh ja? In sie reinspritzen..."

    # say L655 joh
    old "Delicious!"
    new "Lecker!"

    # say L670 joh
    old "You are doing it great!"
    new "Sie machen das großartig!"

    # say L671 joh
    old "Speed it up a little."
    new "Machen Sie es ein bisschen schneller."

    # say L675 joh
    old "Look at her [pla], she is enjoying your cock."
    new "Sieh dir ihre [pla] an, sie genießt deinen Schwanz."

    # say L679 joh
    old "Are you cumming hin?"
    new "Kommst du hin?"

    # say L680 hin
    old "Oh please, don't stop, do it faster! I'm going to cum!"
    new "Oh bitte, hör nicht auf, mach es schneller! Ich komme gleich!"

    # say L707 hin
    old "Wow... That was awesome..."
    new "Wow... Das war unglaublich..."

    # say L714 joh
    old "Ohh, I think it's the perfect opportunity, for the last lesson."
    new "Ohh, ich denke, es ist die perfekte Gelegenheit für die letzte Lektion."

    # say L715 joh
    old "Get a good facial..."
    new "Bist du bereit für eine gute Besamung?"

    # say L718 joh
    old "Now let's ger a good facial Hinn."
    new "Jetzt lassen Sie uns ein gutes Gesicht bekommen, Hinn."

    # say L732 joh
    old "Look at her eyes [pla], she wants all your cum."
    new "Schauen Sie in ihre Augen [pla], sie will all Ihr Sperma."

    # say L736 joh
    old "Does it feel good? Do you want to cum on that pretty face?"
    new "Fühlt es sich gut an? Möchten Sie auf dieses hübsche Gesicht kommen?"

    # say L740 joh
    old "Get ready for the shot honey, he is ready."
    new "Bereiten Sie sich auf den Schuss vor, Liebling, er ist bereit."

    # say L763 joh
    old "Give it to her! Cum on Hinn face!"
    new "Geben Sie es ihr! Kommen Sie auf Hinn Gesicht!"

    # say L771 joh
    old "Ohh yes... Delicious..."
    new "Ohh ja... Lecker..."

    # say L817 pla
    old "Wow Hinn, I'm going to..."
    new "Wow Hinn, ich werde..."

    # say L822 pla
    old "Wow, that was awesome..."
    new "Wow, das war toll..."

    # say L823 hin
    old "I didn't say it's over. You just enjoy..."
    new "Ich hab' doch nicht gesagt, dass es vorbei ist. Genieße es einfach..."

    # say L864 pla
    old "Hinn, again I'm going to..."
    new "Hinn, wieder werde ich..."

    # say L872 hin
    old "That was fun..."
    new "Das war lustig..."

    # say L873 pla
    old "That... Was... Surprising."
    new "Das... War... Überraschend."

    # say L880 pla
    old "That was great."
    new "Das war toll."

    # say L889 hin
    old "It has a very nice smell."
    new "Es hat einen sehr schönen Geruch."

    # say L890 hin
    old "Mmm, [pla] I really like your penis, it's soo nice."
    new "Mmm, [pla] ich mag deinen Penis wirklich, er ist so schön."

    # say L892 hin
    old "Just relax, I'll make you feel good."
    new "Entspann dich, ich werde dir ein gutes Gefühl geben."

    # say L896 hin
    old "Slurrp, Yes, I see you like that."
    new "Slurrp, Ja, ich sehe, dass dir das gefällt."

    # say L897 hin
    old "I love the taste of you dick! I love how it feels in my mouth!"
    new "Ich liebe deinen Geschmack! Ich liebe, wie es sich in meinem Mund anfühlt!"

    # say L898 hin
    old "I'll do it a little bit faster."
    new "Ich mache es ein bisschen schneller."

    # say L903 bel
    old "(Hmm, they look like they're having fun. I better leave, I don't want them to know I saw them.)"
    new "Hmm, sie sehen aus, als hätten sie Spaß. Ich sollte besser gehen, ich will nicht, dass sie merken, dass ich sie gesehen habe."

    # say L905 bel
    old "For now..."
    new "Für jetzt..."

    # say L913 hin
    old "Uhhh, I can feel how your body tense up!"
    new "Uhhh, ich spüre, wie sich dein Körper anspannt!"

    # say L915 hin
    old "Mmmm! Yes, Yes!"
    new "Mmmm! Ja, ja!"

    # say L938 pla
    old "H-Hinn, I c- can't hold back anymore."
    new "H-Hinn, ich k- kann mich nicht mehr zurückhalten."

    # say L939 hin
    old "F- Finish, cum in my mouth!"
    new "F- Fick, spritz in meinen Mund!"

    # say L940 hin
    old "I want you to!"
    new "Ich will, dass du es tust!"

    # say L941 pla
    old "Ughh, Y- YES!"
    new "Ughh, J- JA!"

    # say L946 hin
    old "Phew! That was great. Did you like it [pla]?"
    new "Phew! Das war toll. Hast du es auch genossen [pla]?"

    # say L947 pla
    old "Y- yeah, I did, thank you Hinn."
    new "Y- ja, ich hab's genossen, danke Hinn."

    # say L948 hin
    old "Well, I'm glad you enjoyed it."
    new "Na, ich bin froh, dass es dir gefallen hat."

    # say L949 hin
    old "Although now I'm covered with cum."
    new "Obwohl ich jetzt voller Sperma bin."

    # say L950 pla
    old "Sorry about that."
    new "Tut mir leid, dass ich dich so verschmiert habe."

    # say L951 hin
    old "It's ok, I wanted to do that with you. Besides, we're in the bathroom."
    new "Ist okay, ich wollte das mit dir machen. Außerdem sind wir im Bad."

    # say L952 hin
    old "Help me clean up."
    new "Hilf mir beim Aufwischen."

    # say L1070 hin
    old "Mmm! It's been a while..."
    new "Mmm! Das ist lange her..."

    # say L1071 hin
    old "Ah! Oh yes! I've missed this..."
    new "Ah! Oh ja! Ich habe das vermisst..."

    # say L1072 pla
    old "Ohh God!"
    new "Oh Gott!"

    # say L1073 hin
    old "Ahh! It's so big! and It feels so good!"
    new "Ahh! Es ist so groß! und es fühlt sich so gut an!"

    # say L1077 hin
    old "Ah! Ah! I love to feel you inside [pla]!"
    new "Ah! Ah! Ich liebe es, dich in mir zu spüren [pla]!"

    # say L1078 hin
    old "Y- your cock is just the best!"
    new "D- dein Schwanz ist einfach der Beste!"

    # say L1080 hin
    old "I- I just love to have sex with you!"
    new "I- Ich liebe es einfach, mit dir zu ficken!"

    # say L1084 hin
    old "AHH! AHH! YES! YES!"
    new "AHH! AHH! JA! JA!"

    # say L1085 hin
    old "I love the way you always make me feel!"
    new "Ich liebe es, wie du mich immer fühlen lässt!"

    # say L1086 hin
    old "I LOVE IT!"
    new "Ich liebe es!"

    # say L1087 hin
    old "I want to keep doing it with you!"
    new "Ich will weiter mit dir machen!"

    # say L1110 pla
    old "H- Hinn! I- I think I'm about to...!"
    new "H- Hinn! I- Ich glaube, ich komme gleich...!"

    # say L1111 hin
    old "Ohh, yes yes!"
    new "Ohh, ja ja!"

    # say L1112 hin
    old "I want you to cum inside me!"
    new "Ich will, dass du in mir kommst!"

    # say L1119 hin
    old "Wow... That felt great."
    new "Wow... Das war toll."

    # say L1120 hin
    old "Did you enjoy it too [pla]?"
    new "Hast du es auch genossen [pla]?"

    # say L1121 pla
    old "O- of course, it was really good."
    new "O- natürlich, es war wirklich gut."

    # say L1130 jad
    old "What the hell is this?!!!"
    new "Was zur Hölle ist das?!!!"

    # say L1131 jad
    old "Hinn! [pla]! What do you think you're doing?!"
    new "Hinn! [pla]! Was denkst du dir eigentlich?!"

    # say L1141 hin
    old "Mmm! I just love the way your cock tastes."
    new "Mmm! Ich liebe einfach, wie dein Schwanz schmeckt."

    # say L1142 hin
    old "It really is great. I can't get over it."
    new "Es ist wirklich toll. Ich kann nicht genug davon kriegen."

    # say L1143 hin
    old "I love how it fills my mouth!"
    new "Ich liebe, wie es meinen Mund ausfüllt!"

    # say L1147 hin
    old "Are you enjoying it [pla]?"
    new "Genießt du es [pla]?"

    # say L1148 pla
    old "Ugh! Y- yes!"
    new "Ugh! J- ja!"

    # say L1149 hin
    old "M- me too! I love your cock!"
    new "M- mir auch! Ich liebe deinen Schwanz!"

    # say L1150 hin
    old "I- it's so hot!"
    new "I- es ist so heiß!"

    # say L1158 jad
    old "Honestly, I swear I don't understand what's going on in that girl's head sometimes."
    new "Ehrlich, ich schwöre, ich verstehe manchmal nicht, was in dem Mädchen vorgeht."

    # say L1159 jad
    old "Where did she take off too? They're not in her room."
    new "Wohin ist sie abgehauen? Sie sind nicht in ihrem Zimmer."

    # say L1160 jad
    old "And would you look at that? She left the bathroom light on!"
    new "Und sieh mal an? Sie hat das Badlicht angelassen!"

    # say L1161 jad
    old "I swear to God..."
    new "Ich schwör's..."

    # say L1167 jad
    old "(Oh my God! What are they doing?! Again?!)"
    new "Oh mein Gott! Was machen die da?! Wieder?!"

    # say L1168 jad
    old "(And in the bathroom of all places! These kids don't understand what shame is!)"
    new "Und im Badezimmer auch noch! Diese Kids haben echt keine Scham!"

    # say L1172 jad
    old "(And [pla]! My God! He's really big!)"
    new "Und [pla]! Mein Gott! Er ist wirklich groß!"

    # say L1173 jad
    old "(I can't believe that young man is like that.... Amazing.)"
    new "Ich kann nicht glauben, dass dieser junge Mann so ist.... Unglaublich."

    # say L1174 jad
    old "(I- is Hinn really putting all that in her mouth?)"
    new "(I- steckt Hinn das wirklich alles in den Mund?)"

    # say L1175 jad
    old "(I- I can't believe it.)"
    new "Ich- Ich kann es nicht glauben."

    # say L1182 hin
    old "Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"
    new "Slrrrrp! Mmmm! Y- Ja! I- Ich liebe deinen Schwanz!"

    # say L1183 hin
    old "I- it barely fits in my mouth!"
    new "I- es passt kaum in meinen Mund!"

    # say L1184 hin
    old "It's so amazing!"
    new "Es ist unglaublich!"

    # say L1185 jad
    old "(S- she's actually putting all of it in her mouth!)"
    new "(S- sie steckt es tatsächlich alles in den Mund!)"

    # say L1186 jad
    old "(I can't believe what I'm seeing!)"
    new "Ich kann nicht glauben, was ich da sehe!"

    # say L1187 jad
    old "(H- he's not going to cum in her mouth, right?)"
    new "(H- er wird doch nicht in ihrem Mund kommen, oder?)"

    # say L1210 pla
    old "H- Hinn... I- I think I'm about to!"
    new "H- Hinn... I- Ich glaube, ich komme gleich!"

    # say L1211 hin
    old "YES! CUM IN MY MOUTH!"
    new "JA! KOMM IN MEINEN MUND!"

    # say L1212 jad
    old "(I can't believe Hinn is saying that kind of stuff!)"
    new "Ich kann nicht glauben, dass Hinn so was sagt!"

    # say L1213 jad
    old "(I- is he going to do it?)"
    new "(Ich- macht er das wirklich?)"

    # say L1219 jad
    old "(My God, kids these days, honestly...)"
    new "(My Gott, die Kids heutzutage, ehrlich...)"

    # say L1220 jad
    old "(And they even say they're not a couple.)"
    new "Und sie sagen sogar, dass sie kein Paar sind."

    # say L1221 jad
    old "(I guess this is alright. I won't say anything for now, but Hinn really needs to learn to do it in her bedroom.)"
    new "(I schätze, das ist in Ordnung. Ich werde nichts sagen, aber Hinn muss wirklich lernen, das in ihrem Schlafzimmer zu machen.)"

    # say L1233 hin
    old "Hngh!! Oh yes!"
    new "Hngh!! Oh ja!"

    # say L1234 hin
    old "That's what I've been waiting for!"
    new "Das ist genau das, was ich wollte!"

    # say L1235 hin
    old "I just love how you fill me up!"
    new "Ich liebe einfach, wie du mich ausfüllst!"

    # say L1236 hin
    old "Oh! [pla]! Your cock is so big!"
    new "Oh! [pla]! Dein Schwanz ist so groß!"

    # say L1240 hin
    old "Are you enjoying it?"
    new "Genießt du es?"

    # say L1241 pla
    old "Mmm, y- yes!"
    new "Mmm, y- ja!"

    # say L1242 hin
    old "I- I'm loving it!"
    new "I- Ich liebe es!"

    # say L1247 jad
    old "Uhh... What is that noise?"
    new "Uhh... Was ist das für ein Geräusch?"

    # say L1250 jad
    old "(I can't believe they're doing it again!)"
    new "Ich kann nicht glauben, dass sie es wieder tun!"

    # say L1252 jad
    old "(But well, at least they're doing it privately.)"
    new "(Aber gut, zumindest tun sie es privat.)"

    # say L1253 jad
    old "Oh, my God! I- I can't help myself..."
    new "Oh Gott! I- ich kann mich nicht zurückhalten..."

    # say L1260 hin
    old "D- do it faster [pla]!"
    new "D- mach es schneller [pla]!"

    # say L1263 jad
    old "(H- he's so big! I- I wonder how it must feel to be penetrated by him...)"
    new "H- er ist so groß! I- ich frage mich, wie es sich anfühlen muss, von ihm durchgenommen zu werden..."

    # say L1265 hin
    old "AH! AH! AH! YES! YES!"
    new "AH! AH! AH! JA! JA!"

    # say L1266 hin
    old "I've been missing this so much!"
    new "Ich hab das so vermisst!"

    # say L1267 jad
    old "(Mmmm, and she's taking all of it!)"
    new "(Mmmm, und sie nimmt alles!)"

    # say L1268 hin
    old "I love how you fuck me!"
    new "Ich liebe, wie du mich fickst!"

    # say L1301 jad
    old "(H- he won't cum inside of her... Will he?)"
    new "(H- er wird doch nicht in ihr kommen... Oder?)"

    # say L1302 hin
    old "I- I want you to cum inside!"
    new "I- Ich will, dass du in mir kommst!"

    # say L1303 hin
    old "Let me get it all!"
    new "Lass mich alles kriegen!"

    # say L1304 pla
    old "Y- yes! I- I'm about to...!"
    new "Y- ja! I- Ich bin gleich...!"

    # say L1310 jad
    old "(God! I can't believe I just watched them have sex!)"
    new "(Gott! Ich fass es nicht, dass ich gerade zugesehen habe, wie sie Sex hatten!)"

    # say L1311 jad
    old "(But this time they did it in Hinn's bedroom, I'm the one who shouldn't be here spying on them.)"
    new "(Aber dieses Mal haben sie es in Hinns Schlafzimmer getan, ich bin diejenige, die hier nicht sein sollte und sie belauscht.)"

    # say L1316 hin
    old "That was so good [pla]."
    new "Das war so gut [pla]."

    # say L1317 hin
    old "It felt like an eternity since the last time we did it."
    new "Es fühlte sich an wie eine Ewigkeit, seit wir das letzte Mal so waren."

    # say L1318 pla
    old "Yeah..."
    new "Ja..."

    # say L1319 hin
    old "By the way, it's getting kinda late, I guess my mom will be here any minute."
    new "Ach ja, es wird langsam spät, meine Mum wird wahrscheinlich gleich hier sein."

    # say L1320 pla
    old "You're right! I guess we better get dressed soon!"
    new "Stimmt! Wir sollten uns besser bald anziehen."

    # say L1321 jad
    old "(I should leave before they find out I'm here.)"
    new "Ich sollte besser gehen, bevor sie merken, dass ich hier bin."

    # say L1326 jad
    old "Oh God, what is happening to me?"
    new "Oh Gott, was passiert hier mit mir?"


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Bedroom.rpy
translate german strings:

    # say L10 pla
    old "I should go to the garage to talk with Brixxida first..."
    new "Ich sollte zuerst mit Brixxida im Schuppen reden..."

    # say L22 pla
    old "Ah. I feel rested..."
    new "Ah. Ich fühle mich ausgeruht..."

    # say L61 pla
    old "I should probably go talk to Billie..."
    new "Ich sollte wohl mit Billie reden..."

    # menu L67 
    old "Sleep"
    new "Schlafen"

    # say L82 pla
    old "It's time to sleep..."
    new "Es ist Zeit zu schlafen..."

    # say L321 pla
    old "Ready for a new day!"
    new "Bereit für einen neuen Tag!"

    # say L323 pla
    old "Today is [mo1rel]'s medical appointment day, I should talk her."
    new "Heute ist [mo1rel]s Termin beim Arzt, ich sollte mit ihr reden."

    # say L365 pla
    old "Wow... What's going on..."
    new "Wow... Was ist los..."

    # say L383 pla
    old "Oh shit... Not again..."
    new "Oh Scheiße... Nicht schon wieder..."

    # say L400 pla
    old "What the hell!..."
    new "Was zum Teufel!..."

    # say L416 pla
    old "Really? You again!?..."
    new "Wirklich? Du wieder!?"


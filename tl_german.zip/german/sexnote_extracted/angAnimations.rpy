# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/angAnimations.rpy
translate german strings:

    # say L51 joh
    old "Are you enjoying it, honey?"
    new "Genießt du es, Liebling?"

    # say L52 ang
    old "Mmm, yes, this one is giving me a pretty warm and wet sensation."
    new "Mmm, ja, das hier gibt mir ein ziemlich warmes und nasses Gefühl."

    # say L53 joh
    old "Okay, you're doing a great job, now try to do it a little faster."
    new "Okay, Sie machen das sehr gut, versuchen Sie es jetzt ein bisschen schneller."

    # say L59 joh
    old "Oh yeah, just like that honey, don't stop, you are gonna make him cum soon..."
    new "Oh ja, genau so, Liebling, hör nicht auf, du wirst ihn bald kommen lassen..."

    # say L61 ang
    old "Slurp, slurp."
    new "Schluck, schluck."

    # say L84 joh
    old "Ok, you've had enough, you can cum now [pla]."
    new "Ok, Sie haben genug, Sie können jetzt kommen [pla]."

    # say L85 ang
    old "W- what?"
    new "W- was?"

    # say L90 ang
    old "Huh, what is this?"
    new "Häh, was ist das?"

    # say L95 ang
    old "WHAT THE FUCK!"
    new "Was zum Teufel!"

    # say L96 ang
    old "WHO THE HELL ARE YOU?!!"
    new "Wer zur Hölle sind Sie?!!"

    # say L110 joh
    old "Ok [pla], I need you to show her your tricky fingers..."
    new "Ok [pla], ich brauche, dass du ihr deine geschickten Finger zeigst..."

    # say L111 joh
    old "More speed and a bit of more pressure, she needs to enjoy more, to get hornier."
    new "Mehr Tempo und ein bisschen mehr Druck, sie soll es genießen, um noch geiler zu werden."

    # say L113 ang
    old "Uhh... It f- feels nice..."
    new "Uhh... Es f- fühlt sich gut an..."

    # say L114 joh
    old "Yes, just like that, [pla]."
    new "Ja, genau so, [pla]."

    # say L118 joh
    old "[pla], I want you to be tough now, press them hardly, feel them, touch them all."
    new "[pla], ich will, dass Sie jetzt fest werden, drücken Sie sie kräftig, fühlen Sie sie, berühren Sie sie überall."

    # say L119 pla
    old "Ok."
    new "Okay."

    # say L120 joh
    old "Do you like it Angelina?"
    new "Magst du es, Angelina?"

    # say L121 ang
    old "... Y- yes."
    new "... J- ja."

    # say L145 joh
    old "Perfect, now that we feel a bit more confident with each other let's move to the other exercise, in this case in the practice bedroom."
    new "Perfekt, jetzt wo wir uns etwas besser verstehen, gehen wir zu dem nächsten Übung, in diesem Fall ins Praxis-Schlafzimmer."

    # say L158 joh
    old "Do you like it?"
    new "Magst du es?"

    # say L159 ang
    old "Yes, it feels a bit... Nice."
    new "Ja, es fühlt sich ein bisschen... schön an."

    # say L160 joh
    old "You needed a better trained person to start enjoying it, let's make it more interesting, [pla], I want you to do it faster."
    new "Du brauchtest eine besser ausgebildete Person, um es zu genießen, lass uns es spannender machen, [pla], ich will, dass du schneller wirst."

    # say L162 joh
    old "How do you feel now?"
    new "Wie fühlst du dich jetzt?"

    # say L163 ang
    old "Ahh! I- I am... Starting to feel... n- nice."
    new "Ahh! I- Ich fange an... mich n- nett zu fühlen."

    # say L167 joh
    old "Ok, [pla], I want you to make her cum, do your thing!"
    new "Ok, [pla], ich will, dass du sie zum Orgasmus bringst, mach deinen Job!"

    # say L168 ang
    old "Ohhh...  Don't stop, ahh! Nngh!"
    new "Ohhh... Hör nicht auf, ahh! Nngh!"

    # say L191 ang
    old "Oh God! OH GOD! I feel like I'm going to... EXPLODE!"
    new "Oh Gott! OH GOTT! Ich fühle mich, als würde ich... AUSBRUCHEN!"

    # say L196 joh
    old "Wonderful!"
    new "Wunderbar!"

    # say L197 ang
    old "Oh God... I had never felt this before..."
    new "Oh Gott... Ich habe das noch nie zuvor gespürt."

    # say L209 joh
    old "So, what do you feel Angelina?"
    new "So, was spürst du, Angelina?"

    # say L210 ang
    old "Hmm, It's really hard and tasteful."
    new "Hmm, es ist wirklich hart und schmeckt gut."

    # say L211 joh
    old "That's perfect, how are you feeling, [pla]?"
    new "Das ist perfekt, wie fühlst du dich, [pla]?"

    # say L213 ang
    old "Hmm... Slurp, slurp."
    new "Hmm... Schlürf, schlürf."

    # say L214 joh
    old "Right, that's the best answer. Just enjoy it guys."
    new "Richtig, das ist die beste Antwort. Genießt es einfach, Leute."

    # say L218 joh
    old "You think you can hold on a bit more [pla]?"
    new "Du denkst, du kannst noch ein bisschen durchhalten [pla]?"

    # say L220 joh
    old "Perfect, now Angelina, I want you to give him all you have, I want you to make him cum."
    new "Perfekt, jetzt Angelina, ich will, dass du ihm alles gibst, ich will, dass du ihn zum Kommen bringst."

    # say L221 ang
    old "Mmm, ok."
    new "Mmm, okay."

    # say L245 joh
    old "Don't stop now, he is almost done, he will cum any time, so, keep moving your head."
    new "Hören Sie jetzt nicht auf, er ist fast soweit, er wird jeden Moment kommen, also bewegen Sie weiter Ihren Kopf."

    # say L253 ang
    old "Wow, that's a lot of cum, I think I did it."
    new "Wow, das ist wirklich viel Sperma, ich glaube, ich hab’s geschafft."

    # say L254 joh
    old "You did amazing!"
    new "Sie haben fantastisch gemacht!"

    # say L265 joh
    old "[pla], since Angelina is not so experienced I need you to be as gentle as you can be, she can't do it like me, so pease start softly."
    new "[pla], da Angelina noch nicht so erfahren ist, müssen Sie so sanft wie möglich vorgehen. Sie kann es nicht wie ich, also fangen Sie bitte sanft an."

    # say L266 pla
    old "Sure, I'll try my best."
    new "Klar, ich geb mir Mühe."

    # say L270 ang
    old "Mmm it hurts a bit... But it also feels good..."
    new "Mmm es tut ein bisschen weh... Aber es fühlt sich auch gut an..."

    # say L271 joh
    old "Told you. [pla] please, speed it up a bit, I want you to make her scream a bit, you already know how to do it."
    new "Hab ich doch gesagt. [pla] bitte, mach es etwas schneller, ich will, dass sie ein bisschen schreit, du weißt ja, wie man das macht."

    # say L276 joh
    old "Are you satisfied Angelina?"
    new "Bist du zufrieden, Angelina?"

    # say L277 ang
    old "Ohhh... Yess..."
    new "Ohhh... Ja..."

    # say L278 joh
    old "And we've got even more to go, so [pla], give her more!"
    new "Und wir haben noch viel mehr vor, also [pla], geben Sie ihr mehr!"

    # say L279 pla
    old "Got it."
    new "Verstanden."

    # say L281 ang
    old "HOLLY SHIT! AHHH!"
    new "HOLY SHIT! AHHH!"

    # say L304 joh
    old "Don't stop, she's about to cum!"
    new "Hören Sie nicht auf, sie kommt gleich!"

    # say L306 joh
    old "[pla], finish with her!"
    new "[pla], bring es zu Ende!"

    # say L307 ang
    old "I feel like an explosion inside just like the other day, I- I... AHH!"
    new "Ich fühle mich wie eine Explosion von innen, genau wie damals, ich... AHH!"

    # say L321 joh
    old "That's impressive, you are doing it really really good, do you like it [pla]?"
    new "Das ist beeindruckend, Sie machen das wirklich gut, gefällt es Ihnen [pla]?"

    # say L322 pla
    old "Absolutely!"
    new "Absolut!"

    # say L323 pla
    old "(She's getting really good at it.)"
    new "Sie wird wirklich gut darin."

    # say L325 joh
    old "I'm glad to see you feel more confident with your partner."
    new "Ich freue mich, dass Sie sich mit Ihrem Partner sicherer fühlen."

    # say L328 joh
    old "That's great, don't stop, remember is your husband pleasure what we are talking about."
    new "Das ist großartig, hören Sie nicht auf, denken Sie daran, es geht um das Vergnügen Ihres Ehemanns."

    # say L331 joh
    old "Now suck it faster, show me those blowjob skills."
    new "Jetzt saug schneller, zeig mir deine Fähigkeiten."

    # say L333 pla
    old "Woow!"
    new "Wow!"

    # say L337 joh
    old "Wow, I can see it's getting closer, do it faster, you want him to cum, don't you?"
    new "Wow, ich sehe, es wird immer enger, mach es schneller, du willst ihn doch kommen lassen, oder?"

    # say L338 ang
    old "Yes!"
    new "Ja!"

    # say L339 joh
    old "So, do it as fast as you can... make him cum in your throat!"
    new "So, machen Sie es so schnell wie möglich... lassen Sie ihn in Ihrem Mund kommen!"

    # say L363 pla
    old "Ahh yes! Take it."
    new "Ahh ja! Nimm es."

    # say L370 joh
    old "Wonderful, did you like it Angelina?"
    new "Wunderbar, hat dir das gefallen, Angelina?"

    # say L372 joh
    old "That's my girl."
    new "Das ist mein Mädchen."

    # say L383 joh
    old "Oh yeah, ride him Angelina, jump on him and fuck him."
    new "Oh ja, reite ihn, Angelina, spring auf ihn und fick ihn."

    # say L384 ang
    old "I didn't know riding was so intense, this is definitely the position I like the most."
    new "Ich wusste nicht, dass Reiten so intensiv sein kann, das ist definitiv die Position, die ich am liebsten mag."

    # say L385 pla
    old "(Oh wow, she moves really good, I like it.)"
    new "Oh wow, sie bewegt sich echt gut, ich mag es."

    # say L388 ang
    old "Oh God! I don't want to stop, we should do this for a week..."
    new "Oh Gott! Ich will gar nicht aufhören, wir sollten das eine Woche lang machen..."

    # say L389 pla
    old "I like it too."
    new "Mir gefällt es auch."

    # say L390 joh
    old "Fuck him Angelina, fuck [pla] hard!"
    new "Ficken Sie ihn, Angelina, ficken Sie [pla] hart!"

    # say L392 ang
    old "Ahhh..."
    new "Ahhh... Dein Schwanz ist so hart, dass ich ihn schneller ficken will."

    # say L396 ang
    old "Ahhh... Your dick is so hard that I want to hit it faster."
    new "Ahhh... Dein Schwanz ist so hart, dass ich schneller zustoßen will."

    # say L397 joh
    old "Fuck him harder, just as you want!"
    new "Fick ihn härter, genau so, wie du willst!"

    # say L422 ang
    old "Ahh! This is really delicious, I don't want to stop."
    new "Ahh! Das ist wirklich lecker, ich will gar nicht mehr aufhören."

    # say L423 ang
    old "I really love this, I want to feel you cuming."
    new "Ich liebe das wirklich, ich will deinen Orgasmus spüren."

    # say L424 pla
    old "I- I can't hold it anymore."
    new "Ich- Ich kann es nicht mehr zurückhalten."

    # say L430 ang
    old "Mmm, I- I want more... May I have another round?"
    new "Mmm, ich- ich will mehr... Darf ich noch eine Runde haben?"

    # say L431 joh
    old "Wow girl, you're insatiable... Well, if [pla] says she can go on, that's fine with me, we still have time."
    new "Wow, Sie sind unersättlich... Na gut, wenn [pla] sagt, dass sie weitermachen kann, ist das für mich in Ordnung, wir haben noch Zeit."

    # say L432 pla
    old "Uhh... Yes, I guess..."
    new "Uhh... Ja, ich denke schon..."

    # say L433 ang
    old "Ok, now you fuck me, I want you to make me cum again."
    new "Ok, jetzt fickst du mich, ich will, dass du mich nochmal kommen lässt."

    # say L434 pla
    old "A- Alright..."
    new "A- Alles klar..."

    # say L452 ang
    old "Oh yes, just like that. I have to say my husband is not as big as you."
    new "Oh ja, genau so. Ich muss sagen, mein Mann ist nicht so groß wie du."

    # say L453 ang
    old "Your huge cock makes me feel so much more!"
    new "Dein großer Schwanz macht mich so viel mehr an!"

    # say L457 ang
    old "Mmmm, it feels really nice, but I want more!"
    new "Mmmm, das fühlt sich echt gut an, aber ich will mehr!"

    # say L458 ang
    old "Give me more of your cock. I want you to fuck me harder!"
    new "Gib mir mehr deinen Schwanz. Ich will, dass du mich härter fickst!"

    # say L461 ang
    old "Uhhhh... Holly Shit! This is soo good."
    new "Uhhhh... Holy Shit! Das fühlt sich so gut an."

    # say L464 ang
    old "Don't stop baby, keep fucking me hard!"
    new "Hör nicht auf, Baby, fick mich weiter hart!"

    # say L465 ang
    old "I want you to make me cum! Please [pla], make cum!"
    new "Ich will, dass du mich kommen lässt! Bitte [pla], mach mich kommen!"

    # say L467 ang
    old "Ahhh! Ahhh! Oh my God!"
    new "Ahhh! Ahhh! Oh mein Gott!"

    # say L490 pla
    old "(Uhh... Doctor Johnson has been a bit quiet, that's weird)"
    new "Uhh... Dr. Johnson ist irgendwie still, das ist seltsam."

    # say L497 ang
    old "Yes! Yes! I- I cumming again! Ahhh!"
    new "Ja! Ja! Ich- ich komme wieder! Ahhh!"

    # say L501 ang
    old "Mmmm, it was so good."
    new "Mmmm, das war so gut."

    # say L502 joh
    old "Great job guys, I can tell you that the sessions have been very efficient..."
    new "Gute Arbeit, ich kann sehen, dass die Sitzungen sehr effektiv waren..."

    # say L503 joh
    old "Angelina as you can see you will be very happy with your husband!"
    new "Angelina, wie du siehst, wirst du sehr glücklich mit deinem Mann werden!"

    # say L515 ang
    old "Mmm... Oh God, this feeling..."
    new "Mmm... Oh Gott, dieses Gefühl..."

    # say L516 ang
    old "And the size of your cock!"
    new "Und die Größe deines Schwanzes!"

    # say L517 ang
    old "It brings so much back!"
    new "Es bringt so viel zurück!"

    # say L521 ang
    old "I haven't felt this way in forever!"
    new "Ich hab mich schon so lange nicht mehr so gefühlt!"

    # say L522 ang
    old "I've missed feeling this way!"
    new "Ich hab das Gefühl vermisst!"

    # say L523 ang
    old "Slrrp! It's been so long!"
    new "Slrrp! Es ist so lange her!"

    # say L527 ang
    old "This is nothing like my husband!"
    new "Das ist überhaupt nicht wie bei meinem Mann!"

    # say L528 ang
    old "I love how good it tastes!"
    new "Ich liebe, wie gut es schmeckt!"

    # say L529 ang
    old "Oh it makes me feel so good!"
    new "Oh, das fühlt sich so gut an!"

    # say L552 pla
    old "Angelina! I-I can't hold it in anymore!"
    new "Angelina! Ich kann es nicht mehr zurückhalten!"

    # say L553 ang
    old "Oh yes! I want you to let it out!"
    new "Oh ja! Lass es raus!"

    # say L554 ang
    old "Let me taste it!"
    new "Lass mich es kosten!"

    # say L562 ang
    old "Mmm that felt so good."
    new "Mmm das war so gut."

    # say L563 ang
    old "It was amazing."
    new "Es war unglaublich."

    # say L564 pla
    old "Uh, yeah, I guess so."
    new "Klar, war es auch."

    # say L565 pla
    old "But hey, let’s get up and clean this up before Lisa walks in and sees us."
    new "Aber hey, lass uns aufstehen und das aufräumen, bevor Lisa reinkommt und uns sieht."

    # say L566 ang
    old "Sure, sure."
    new "Klar, klar."

    # say L574 pla
    old "How are you feeling Angelina?"
    new "Wie fühlst du dich, Angelina?"

    # say L575 ang
    old "Great! That was fantastic! I want more!"
    new "Großartig! Das war fantastisch! Ich will mehr!"

    # say L576 pla
    old "Hmm, yeah sure."
    new "Hmm, klar doch."

    # say L582 ang
    old "Mmm! Oh yes!"
    new "Mmm! Oh ja!"

    # say L583 ang
    old "Oh God! this feels amazing!"
    new "Oh Gott! Das fühlt sich fantastisch an!"

    # say L584 ang
    old "Oh [pla], this is just what I wanted!"
    new "Oh [pla], das ist genau das, was ich wollte!"

    # say L596 ang
    old "Oh God [pla] I love it!"
    new "Oh Gott [pla], ich liebe es!"

    # say L597 ang
    old "This is so good!"
    new "Das ist so gut!"

    # say L601 ang
    old "My God [pla], I love the way you're doing it!"
    new "Mein Gott [pla], ich liebe es, wie du das machst!"

    # say L602 ang
    old "This is amazing [pla]!"
    new "Das ist unglaublich [pla]!"

    # say L606 ang
    old "Oh yes! Ah! AH!"
    new "Oh ja! Ah! AH!"

    # say L638 pla
    old "How do you feel?"
    new "Wie fühlst du dich?"

    # say L639 ang
    old "I feel amazing [pla]!"
    new "Ich fühle mich fantastisch [pla]!"

    # say L640 ang
    old "That's the best sex I've ever had!"
    new "Das war der beste Sex, den ich je hatte!"

    # say L641 pla
    old "Heh, that's good to hear."
    new "Heh, das ist gut zu hören."

    # say L651 ang
    old "Great! That was fantastic! I want more, please!"
    new "Super! Das war fantastisch! Ich will mehr, bitte!"

    # say L652 pla
    old "Yeah, that’s what I thought..."
    new "Ja, das dachte ich mir..."

    # say L671 ang
    old "Ohhh, yeah... it feels so deep..."
    new "Ohhh, ja... es fühlt sich so tief an..."

    # say L672 ang
    old "Mmm, this is the best!"
    new "Mmm, das ist der Hammer!"

    # say L676 ang
    old "Oh God, oh God! It's amazing."
    new "Oh Gott, oh Gott! Es ist unglaublich."

    # say L677 ang
    old "It feels so good..."
    new "Es fühlt sich so gut an..."

    # say L680 ang
    old "Ohh fuck, yes, yes, faster, faster [pla]..."
    new "Ohh fick, ja, ja, schneller, schneller [pla]..."

    # say L682 ang
    old "Mmm, that's right, don't stop [pla], don't stop!"
    new "Mmm, das ist richtig, hör nicht auf [pla], hör nicht auf!"

    # say L706 ang
    old "Oh my God! Yes, yes!"
    new "Oh mein Gott! Ja, ja!"

    # say L707 ang
    old "[pla], I'm about to cum, don't stop, give me more, give me more!"
    new "[pla], ich komme gleich, hör nicht auf, gib mir mehr, gib mir mehr!"

    # say L711 ang
    old "Ohhh that was amazing... Oh my God."
    new "Ohhh das war unglaublich... Oh mein Gott."

    # say L712 ang
    old "[pla], you really have no idea how wonderful that was."
    new "[pla], du hast echt keine Ahnung, wie wunderbar das war."

    # say L713 pla
    old "You're feeling better now, right?"
    new "Du fühlst dich jetzt besser, oder?"

    # say L714 ang
    old "Ohh, you have no idea."
    new "Ohh, du hast echt keine Ahnung."

    # say L715 pla
    old "I'm glad, but, let’s get up and clean this up before Lisa walks in and sees us."
    new "Ich bin froh, aber lass uns aufstehen und das aufräumen, bevor Lisa reinkommt und uns sieht."


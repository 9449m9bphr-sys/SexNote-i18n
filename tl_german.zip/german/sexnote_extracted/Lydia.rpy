# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Lydia.rpy
translate german strings:

    # say L60 lyd
    old "No Anna, you can't live your life like this."
    new "Nein Anna, du kannst dein Leben nicht so weiterleben."

    # say L62 ann
    old "I'm already big enough to decide what I do with my life."
    new "Ich bin schon groß genug, um selbst über mein Leben zu entscheiden."

    # say L64 lyd
    old "Yes, but in recent weeks you have been drinking excessively and even using drugs!"
    new "Ja, aber in den letzten Wochen trinkst du übermäßig und nimmst sogar Drogen!"

    # say L66 lyd
    old "I'm very worried about you, about your health, I know your father's loss was not easy, it hurts me a lot too-"
    new "Ich mache mir große Sorgen um dich, um deine Gesundheit, ich weiß, dass der Verlust deines Vaters nicht leicht war, es tut mir auch sehr weh-"

    # say L68 ann
    old "it has nothing to do with it... I just want to enjoy my life, I don't want to live locked up and self-conscious like... You."
    new "Das hat damit nichts zu tun... Ich will einfach mein Leben genießen, ich will nicht eingeschlossen und ständig selbstbewusst leben wie... Du."

    # say L76 ann
    old "Anyway... Don't wait for me tonight..."
    new "Egal... Warte heute Nacht nicht auf mich..."

    # say L80 lyd
    old "I'm sorry you heard that... Things have not been very easy for either of us."
    new "Es tut mir leid, dass du das gehört hast... Die Dinge sind für keinen von uns leicht gewesen."

    # say L82 pla
    old "I'm very sorry, I just came to accompany you a little..."
    new "Es tut mir sehr leid, ich wollte dich nur ein bisschen begleiten..."

    # say L85 lyd
    old "Aww thank you very much pumpkin."
    new "Ach danke schön, Schatz."

    # say L87 lyd
    old "But you don't have to worry, I know you have your things to do, and at the moment I don't feel very well."
    new "Aber du musst dir keine Sorgen machen, ich weiß, dass du deine Sachen zu erledigen hast, und im Moment fühle ich mich nicht besonders gut."

    # say L89 pla
    old "Hmm, is it because of the discussion with Anna?"
    new "Hmm, ist es wegen dem Gespräch mit Anna?"

    # say L91 lyd
    old "Yes honey, she was greatly affected by her father's death and has been... Quite bad lately."
    new "Ja Schatz, sie war sehr von ihrem Vater betroffen und es geht ihr... ziemlich schlecht."

    # say L93 pla
    old "I understand, I can come another day if you want."
    new "Ich verstehe, ich kann auch einen anderen Tag kommen, wenn du willst."

    # say L95 lyd
    old "You know what? Yes, come over the weekend and come with me to church, are you okay with that?"
    new "Weißt du was? Ja, komm am Wochenende vorbei und begleite mich zur Kirche, ist das in Ordnung für dich?"

    # say L97 pla
    old "Perfect! I will come in the weekend."
    new "Perfekt! Ich komme am Wochenende."

    # say L99 lyd
    old "Great, thank you for your visit and support honey, I really appreciate it."
    new "Super, danke für deinen Besuch und deine Unterstützung Schatz, das bedeutet mir wirklich viel."

    # say L101 pla
    old "Don't worry, I'm glad for helping you..."
    new "Keine Sorge, ich freue mich, dir zu helfen..."

    # say L120 lyd
    old "Oh hi pumpkin, did you come to help me with the dating app?"
    new "Oh hallo Schatz, bist du gekommen, um mir bei der Dating-App zu helfen?"

    # say L121 pla
    old "Uhh yeah, how's it going?"
    new "Uhh ja, wie läuft's?"

    # say L122 lyd
    old "Well, remember we have to do it in the afternoons, because Anna is here in the mornings..."
    new "Na, erinnerst du dich noch, dass wir es nachmittags machen müssen, weil Anna morgens hier ist..."

    # say L123 pla
    old "Ohh, you're right! I'm sorry, I totally forgot."
    new "Ohh, stimmt! Tut mir leid, ich hab's total vergessen."

    # say L124 lyd
    old "Don't worry pumpkin, just come back in a few hours."
    new "Mach dir keine Sorgen, Schatz, komm einfach in ein paar Stunden wieder."

    # say L125 pla
    old "Alright, see you later then."
    new "Okay, dann sehen wir uns später."

    # say L126 lyd
    old "See you later."
    new "Bis später."

    # say L135 lyd
    old "Hey pumpkin, did you come to accompany me to church?"
    new "Hey Schatz, bist du gekommen, um mich zur Kirche zu begleiten?"

    # say L137 pla
    old "Of course, are you ready?"
    new "Natürlich, bist du bereit?"

    # say L139 lyd
    old "Sure, let's go!"
    new "Klar, lass uns gehen!"

    # say L146 lyd
    old "Thank you so much for joining me to this mass in commemoration of my husband."
    new "Danke schön, dass du mich zu dieser Gedenkmesse für meinen Mann begleitest."

    # say L148 pla
    old "Don't worry, it's a pleasure to share with you."
    new "Keine Sorge, es ist mir eine Freude, bei dir zu sein."

    # say L150 lyd
    old "Oh honey, you don't know how important is the support like yours right now."
    new "Oh Liebling, du kannst dir gar nicht vorstellen, wie wichtig mir deine Unterstützung gerade ist."

    # say L153 jon
    old "Hi Lydia, I'm so sorry for your husband, how have you been these past few week?"
    new "Hallo Lydia, es tut mir sehr leid für Ihren Mann, wie geht es Ihnen in den letzten Wochen?"

    # say L155 lyd
    old "Coping with patience, Mrs. Jones."
    new "Mit Geduld zurechtkommen, Mrs. Jones."

    # say L157 jon
    old "Yes, I understand you perfectly, I also lost my husband 5 years ago."
    new "Ja, ich verstehe dich vollkommen, ich habe meinen Mann vor fünf Jahren auch verloren."

    # say L159 jon
    old "Do you know what helped me? Praying and approach to God."
    new "Weißt du, was mir geholfen hat? Beten und mich Gott zu nähern."

    # say L161 lyd
    old "Yes Mrs. Jones, that's the best."
    new "Ja, Mrs. Jones, das ist das Beste."

    # say L164 jon
    old "I will continue coming to church everyday, giving my life to the lord."
    new "Ich werde weiterhin jeden Tag in die Kirche gehen und mein Leben dem Herrn widmen."

    # say L166 lyd
    old "Yes... He comforts us..."
    new "Ja... Er tröstet uns..."

    # say L168 jon
    old "There's nothing like being faithful to the Lord all your life, right Lydia?"
    new "Da ist nichts Schöneres, als dem Herrn dein ganzes Leben zu widmen, oder Lydia?"

    # say L170 lyd
    old "Sure... Excuse me Mrs. Jones, I have to go, I hope to see you soon."
    new "Sicher... Entschuldigen Sie mich, Mrs. Jones, ich muss los, ich hoffe, Sie bald wiederzusehen."

    # say L172 jon
    old "Okay Lydia, remember that this is the house of God and here you will always be welcome."
    new "Okay Lydia, denken Sie daran, dass dies das Haus Gottes ist und hier werden Sie immer willkommen sein."

    # say L174 lyd
    old "Let's go [pla]."
    new "Lass uns gehen [pla]."

    # say L182 pla
    old "Are you feeling alright? You seem a little disturbed."
    new "Geht es dir gut? Du wirkst ein bisschen durcheinander."

    # say L184 lyd
    old "Did you hear what Mrs. Jones said?"
    new "Hast du gehört, was Mrs. Jones gesagt hat?"

    # say L186 pla
    old "Yes, she is a very religious woman, will you accompany her to church?."
    new "Ja, sie ist eine sehr religiöse Frau, begleitest du sie zur Kirche?"

    # say L188 lyd
    old "No, no, you don't understand..."
    new "Nein, nein, du verstehst das nicht..."

    # say L190 lyd
    old "I've been thinking... After so many years, I have never lived my life..."
    new "Ich hab nachgedacht... Nach all den Jahren habe ich nie wirklich gelebt..."

    # say L194 lyd
    old "[pla], I've never lived, I've always been a homely woman, I haven't really felt happy."
    new "[pla], ich habe nie gelebt, ich war immer nur eine brave Frau, ich habe mich nie wirklich gefreut."

    # say L196 lyd
    old "You know when you reach a certain age you start looking back and see what you've lived..."
    new "Weißt du, wenn man ein bestimmtes Alter erreicht, fängt man an, zurückzublicken und zu sehen, was man erlebt hat..."

    # say L198 lyd
    old "And after so many years I had conformed to what it should be like."
    new "Und nach all den Jahren hatte ich mich an das angepasst, was es sein sollte."

    # say L200 lyd
    old "But after listening to Mrs. Jones... That's not what I want for my life."
    new "Aber nachdem ich Mrs. Jones gehört habe... Das ist nicht das, was ich für mein Leben will."

    # say L204 lyd
    old "I already gave my whole life to a man, now he isn't here anymore, I don't want to stay locked up in a church now either."
    new "Ich hab mein ganzes Leben schon einem Mann geopfert, jetzt, wo er nicht mehr da ist, will ich mich auch nicht in einer Kirche einsperren."

    # say L208 lyd
    old "I don't want to be like Mrs Jones in 5 years, it's not what I want for my life..."
    new "Ich will in 5 Jahren nicht wie Mrs Jones enden, das ist nicht, was ich mir für mein Leben wünsche."

    # say L210 pla
    old "Then, what will you do?"
    new "Dann, was wirst du tun?"

    # say L212 lyd
    old "I think Anna is right... I have to start living my life, live new experiences."
    new "Ich denke, Anna hat recht... Ich muss mein Leben leben, neue Erfahrungen sammeln."

    # say L214 lyd
    old "You know? I never had sex with any other man... I really don't know if I enjoyed sex at least!"
    new "Weißt du? Ich habe noch nie mit einem anderen Mann geschlafen... Ich habe echt keine Ahnung, ob ich es überhaupt genossen habe!"

    # say L218 lyd
    old "Today was a revelation for me... and I don't want to bother you anymore."
    new "Heute war eine Offenbarung für mich... und ich will dich nicht mehr belasten."

    # say L220 lyd
    old "Thank you very much for your company, these days I will be thinking about what I should do with my life."
    new "Danke sehr für deine Gesellschaft, in den nächsten Tagen werde ich überlegen, was ich mit meinem Leben anstellen soll."

    # say L222 pla
    old "I understand, if you need anything just let me know..."
    new "Ich verstehe, wenn du was brauchst, lass es mich wissen..."

    # say L224 lyd
    old "In fact I think if I'm going to need several things from you..."
    new "Eigentlich denke ich, dass ich von dir mehrere Dinge brauchen werde..."

    # say L228 lyd
    old "Never mind, see you later pumpkin."
    new "Vergiss es, bis später Schatz."

    # say L243 lyd
    old "Hi Honey, remember that I need you to accompany me to the church the weekend."
    new "Hi Schatz, erinnerst du dich, dass ich dich das Wochenende mit zur Kirche nehmen will?"

    # say L245 pla
    old "Ohhh, of course, no problem, I'll be here on the weekend."
    new "Och, klar, kein Problem, ich bin am Wochenende hier."

    # say L247 lyd
    old "Thank you very much pumpkin!"
    new "Danke schön, Schatz!"

    # say L254 lyd
    old "Hi Honey, do you need me?"
    new "Hi Schatz, brauchst du mich?"

    # say L256 pla
    old "Oh no, sorry, I was just walking around."
    new "Oh nein, tut mir leid, ich war nur rumlaufen."

    # say L258 lyd
    old "Ok, pumpkin"
    new "Ok, Schatz"

    # say L286 pla
    old "Sorry, I was just walking around."
    new "Entschuldigung, ich war nur rumgelaufen."


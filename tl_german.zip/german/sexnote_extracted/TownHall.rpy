# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/TownHall.rpy
translate german strings:

    # menu L10 
    old "Talk"
    new "Reden"

    # say L11 sop
    old "Hello, Can I help you?"
    new "Hallo, kann ich dir helfen?"

    # say L12 pla
    old "Oh, no, sorry for bothering you."
    new "Oh, nein, tut mir leid, dass ich dich störe."

    # say L37 sop
    old "Hmm, Can I help you?"
    new "Hmm, kann ich dir helfen?"


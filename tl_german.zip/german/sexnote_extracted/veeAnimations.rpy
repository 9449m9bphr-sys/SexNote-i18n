# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/veeAnimations.rpy
translate german strings:

    # say L6 vee
    old "Oh yeah! This is just magical!"
    new "Oh ja! Das ist einfach magisch!"

    # say L7 vee
    old "I love that you're watching me, Daddy!"
    new "Ich liebe es, dass du mir zuschaust, Daddy!"

    # say L8 vee
    old "I miss your dick so much!"
    new "Ich vermisse deinen Schwanz so sehr!"

    # say L12 vee
    old "Do you like to see me touching my pussy?"
    new "Magst du es zu sehen, wie ich meine Pussy berühre?"

    # say L13 vih
    old "Oh yeah baby! I love it!"
    new "Oh ja Baby! Ich liebe es!"

    # say L14 vih
    old "I can't wait to fuck your pussy myself!"
    new "Ich kann es kaum abwarten, deine Pussy selbst zu ficken!"

    # say L18 vee
    old "Oh daddy! It feels as if you were here!"
    new "Oh Daddy! Es fühlt sich an, als wärst du hier!"

    # say L19 vee
    old "I can't get enough of this!"
    new "Ich kriege einfach nicht genug davon!"

    # say L20 vee
    old "I want more and more!"
    new "Ich will immer mehr!"

    # say L43 vee
    old "I- I'm about to cum honey!"
    new "Ich- Ich komme gleich, Schatz!"

    # say L44 vih
    old "Do it! I'm about to cum too!"
    new "Mach es! Ich bin auch gleich soweit!"

    # say L45 vee
    old "Oh yeah! Let's do it together!"
    new "Oh ja! Lass uns es zusammen tun!"

    # say L52 vee
    old "Oh that was magical honey."
    new "Oh das war magisch, Schatz."

    # say L53 vee
    old "I can't wait to see you again to feel you inside me."
    new "Ich freue mich schon darauf, dich wiederzusehen und in dir zu sein."

    # say L54 vih
    old "Oh yeah, I can't wait to fuck you too."
    new "Oh ja, ich freue mich auch darauf, dich zu ficken."

    # say L56 vee
    old "{i}(I- is that [pla]? What's he doing there?!!){/i}"
    new "{i}(Ich- ist das [pla]? Was macht der da?!!){/i}"

    # say L57 vih
    old "Is everything alright? You just got quiet all of a sudden."
    new "Ist alles in Ordnung? Du bist plötzlich so still."

    # say L58 vee
    old "What?! Oh yeah!"
    new "Was?! Oh ja!"

    # say L59 vee
    old "It's just that I think I heard some steps in the hallway."
    new "Es ist nur so, dass ich Schritte im Flur gehört zu haben glaube."

    # say L60 vee
    old "Maybe we should end the call here honey, in case one of the girls comes in."
    new "Vielleicht sollten wir das Gespräch hier beenden, Schatz, falls eine der Mädchen reinkommt."

    # say L61 vih
    old "Hmph, yeah you're right."
    new "Hmpf, ja, du hast recht."

    # say L62 vih
    old "Talk to you later then."
    new "Dann sprechen wir später."

    # say L63 vee
    old "Bye honey, I love you."
    new "Tschüss Schatz, ich liebe dich."

    # say L64 vee
    old "Hey, you! I already saw you there peeping, come in here and close the door behind you!"
    new "Hey, du da! Ich hab dich schon dabei beobachtet, wie du rumgeschnüffelt hast. Komm rein und mach die Tür hinter dir zu!"


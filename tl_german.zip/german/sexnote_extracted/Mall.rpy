# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mall.rpy
translate german strings:

    # say L30 roo
    old "Hey buddy, how are you doing?"
    new "Hey Kumpel, wie geht's dir?"

    # say L32 roo
    old "Oh! No worries at all, she is harmless, actually the only way to be attacked by them is that they feel threatened, it's ok, touch her."
    new "Oh! Mach dir keine Sorgen, sie ist harmlos. Eigentlich können sie nur angreifen, wenn sie sich bedroht fühlen. Alles gut, du kannst sie berühren."

    # say L33 pla
    old "No, no...  It's fine thank you."
    new "Nein, nein... Alles gut, danke."

    # say L35 roo
    old "Hehehe! It's ok, the first time is kind of impressive... Her name is Gorgo, I really love her, it's my pet."
    new "Hehehe! Ist schon okay, beim ersten Mal ist es schon beeindruckend... Ihr Name ist Gorgo, ich liebe sie wirklich, sie ist mein Haustier."

    # say L36 pla
    old "I can see it..."
    new "Ich seh's..."

    # say L37 roo
    old "Do you like snakes? Would you like to adopt one?"
    new "Magst du Schlangen? Möchtest du eine adoptieren?"

    # say L38 pla
    old "Oh no, no thank you... Hmm I'm more a cat person... You know..."
    new "Oh nein, danke... Hmm, ich bin eher ein Katzenmensch... Du weißt schon..."

    # say L39 roo
    old "Oh, they are beautiful too, here you can find anything you need related with any pet... You know their food, cat litter or any toy you want for them to play with."
    new "Oh, die sind auch wunderschön, hier findest du alles, was du für jedes Haustier brauchst... Du weißt schon, Futtermittel, Katzenstreu oder jedes Spielzeug, das du willst, damit sie spielen können."

    # say L40 pla
    old "Alright, thank you, I've never been to this place before! It 's amazing..."
    new "Okay, danke, ich war noch nie hier! Es ist unglaublich..."

    # say L42 roo
    old "Yes, I just opened a couple of months ago, so that's probably  why you haven't seen it before..."
    new "Ja, ich hab es vor ein paar Monaten erst aufgemacht, deshalb hast du es wahrscheinlich noch nicht gesehen..."

    # say L43 roo
    old "You can come at any time, this place is a free space for animals and earth care, you can find anything and help with everything to save this beautiful world..."
    new "Du kannst jederzeit kommen, dieser Ort ist ein freier Raum für Tiere und Umwelt, hier findest du alles und kannst bei allem helfen, um diese wunderschöne Welt zu retten."

    # say L44 pla
    old "Oh, it's very nice to see this kind of place."
    new "Oh, es ist sehr schön, einen solchen Ort zu sehen."

    # say L45 roo
    old "Anytime you want to come we are here for you, ok? What's your name buddy?"
    new "Du kannst jederzeit kommen, wir sind für dich da, ok? Wie heißt du, Kumpel?"

    # say L46 pla
    old "I'm [pla] nice to meet you."
    new "Ich bin [pla], nett dich kennenzulernen."

    # say L47 roo
    old "It's a pleasure [pla], I'm Roonie, I love the energy I can feel from people, yours is quite special keep that feeling, we need more people like you."
    new "Es ist eine Freude, [pla], ich bin Roonie. Ich liebe die Energie, die ich von Menschen spüre, und deine ist ganz besonders. Behalte dieses Gefühl, wir brauchen mehr Menschen wie dich."

    # say L48 pla
    old "Ok... Thank you..."
    new "Ok... Danke..."

    # say L49 roo
    old "It was nice to meet you! Have a peaceful day!"
    new "Es war schön, dich kennenzulernen! Hab einen ruhigen Tag!"

    # say L50 pla
    old "Thanks, see you!"
    new "Danke, bis dann!"

    # say L64 roo
    old "Hey buddy, how are you?"
    new "Hey Kumpel, wie geht's dir?"

    # say L65 pla
    old "I'm fine, thank you."
    new "Mir geht's gut, danke."

    # say L66 roo
    old "It's nice to see you here, very nice and positive energy you are spreading today."
    new "Schön, dich hier zu sehen, du verbreitest heute eine sehr positive Energie."

    # say L67 pla
    old "... Thank you."
    new "Danke."

    # say L68 roo
    old "What do you need today, I'm here to help you."
    new "Was brauchst du heute, ich bin hier, um dir zu helfen."

    # say L69 pla
    old "Oh, I was just passing by."
    new "Oh, ich war nur gerade vorbei."

    # say L71 roo
    old "Ok, Remember if you find any homeless animal you can bring it here, so we can help, I know this world is very mean to them..."
    new "Okay, denk dran, wenn du ein obdachloses Tier findest, kannst du es hierherbringen, damit wir ihm helfen können. Ich weiß, wie grausam diese Welt zu ihnen sein kann..."

    # say L72 pla
    old "I will do!"
    new "Ich werd's machen!"

    # say L73 roo
    old "Count on you buddy to make a more beautiful world for them."
    new "Ich zähle auf dich, Kumpel, um für sie eine schönere Welt zu schaffen."

    # say L74 pla
    old "Sure... I need to leave."
    new "Klar... ich muss los."

    # say L75 roo
    old "I know, busy day, isn't it?"
    new "Ich weiß, voller Termin, oder?"

    # say L76 pla
    old "Kind of..."
    new "Irgendwie..."

    # say L77 roo
    old "Thank you for stopping by to say hi."
    new "Danke, dass du vorbeigeschaut hast, um Hallo zu sagen."

    # say L78 pla
    old "Don't mention it."
    new "Keine Ursache."

    # say L80 pla
    old "You too, bye!"
    new "Bis dann, tschüss!"

    # say L93 pla
    old "Hey! How are you?"
    new "Hey! Wie geht's dir?"

    # say L94 roo
    old "Hey my man, nice seeing you again! I'm pretty fine, what about you?"
    new "Hey mein Mann, schön dich wiederzusehen! Mir geht's ziemlich gut, und dir?"

    # say L95 pla
    old "I'm glad... Well, Hmm, I'm ok."
    new "Ich bin froh... Na ja, hmm, ich bin okay."

    # say L96 roo
    old "Cool man! Is there anything I can do for you?"
    new "Cool Mann! Gibt es was, bei dem ich dir helfen kann?"

    # say L97 pla
    old "Hmm, actually yes... I- I w- wanted to ask you for a j- job? I thought you maybe had something for me."
    new "Hmm, eigentlich ja... I- Ich w- wollte dich fragen, ob du vielleicht eine Arbeit für mich hast? Ich dachte, du hättest vielleicht was für mich."

    # say L98 roo
    old "Really? [pla] you put me in a complicated situation. I would like to help you but now it's impossible. I don't have much resources right now and Angelina is pregnant."
    new "Wirklich? [pla] du bringst mich in eine schwierige Situation. Ich würde dir gerne helfen, aber im Moment ist das unmöglich. Ich habe gerade nicht viele Mittel und Angelina ist schwanger."

    # say L99 pla
    old "Pregnant? Oh right! Uhh...  Congrats Ronnie, t- that's... great."
    new "Schwanger? Oh richtig! Uhh... Herzlichen Glückwunsch Ronnie, d- das... ist... toll."

    # say L100 pla
    old "I'm sorry I bothered you, I understand you can't help me now. I should go now... I have things to do but thanks..."
    new "Es tut mir leid, dass ich dich belästigt habe, ich verstehe, dass du mir jetzt nicht helfen kannst. Ich sollte jetzt gehen... Ich hab noch was zu tun, aber danke..."

    # say L101 roo
    old "No, no, it's fine, sorry I couldn't help, but you don't have to go, stay and let's chit-chat."
    new "Nein, nein, alles gut, tut mir leid, dass ich nicht helfen konnte, aber du musst nicht gehen, bleib und lass uns quatschen."

    # say L103 pla
    old "Oh n- no, thanks but I really need to go now. See you!"
    new "Oh n- nein, danke, aber ich muss wirklich jetzt gehen. Bis dann!"

    # say L104 roo
    old "Have a nice one! Take care [pla]."
    new "Alles Gute! Pass auf dich auf [pla]."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/barAnimations.rpy
translate german strings:

    # say L53 pla
    old "Uhmm... I- I don't think that was in the script Barbie."
    new "Ähm... I- Ich glaube, das stand nicht im Drehbuch, Barbie."

    # say L112 pla
    old "B- barbie! I- I'm about to...!"
    new "B- barbie! Ich- Ich bin gleich...!"

    # say L123 pla
    old "Yeah... I'm glad."
    new "Ja... ich bin froh."

    # say L124 pla
    old "But I wasn't expecting that."
    new "Aber das habe ich nicht erwartet."

    # say L125 pla
    old "Maybe you should be careful when you drink..."
    new "Vielleicht solltest du vorsichtiger sein, wenn du trinkst..."

    # say L153 pla
    old "I- I do!"
    new "Ich- Ich tu's!"

    # say L176 pla
    old "B- barbie I- I can't hold it in anymore!"
    new "B- Barbie, ich kann es echt nicht mehr zurückhalten!"

    # say L188 pla
    old "Uhmm, yeah... But we really can't right now."
    new "Hmm, ja... Aber wir können wirklich nicht jetzt."

    # say L189 pla
    old "So how about you get up? So I can get my pants up."
    new "Dann stehst du mal auf? Damit ich meine Hose hochziehen kann."

    # say L239 pla
    old "B- Barbie! I- I'm about to cum!"
    new "B- Barbie! I- Ich bin gleich soweit!"

    # say L409 joh
    old "[pla]? What are you doing here?"
    new "[pla]? Was machen Sie hier?"

    # say L410 joh
    old "Are you here to see somebody?"
    new "Sind Sie hier, um jemanden zu besuchen?"

    # say L411 joh
    old "Is Hinn with you?"
    new "Ist Hinn bei Ihnen?"

    # say L413 pla
    old "D- Dr. Johnson! H- hi!"
    new "D- Dr. Johnson! H- hallo!"

    # say L414 pla
    old "N- no, I'm not here with anybody."
    new "N- nein, ich bin nicht mit jemandem hier."

    # say L415 pla
    old "I- uh- Ugh-"
    new "I- äh- Ugh-"

    # say L416 pla
    old "I'm here to deal with some things of my own!"
    new "Ich bin hier, um meine eigenen Angelegenheiten zu regeln!"

    # say L417 joh
    old "Why are you panting?"
    new "Warum keuchen Sie?"

    # say L419 joh
    old "I see you have your business in something here."
    new "Ich sehe, Sie haben hier Ihre Angelegenheiten zu regeln."

    # say L420 joh
    old "I- I'll let you be."
    new "Ich- Ich lasse Sie in Ruhe."

    # say L421 joh
    old "Have fun..."
    new "Viel Spaß..."

    # say L435 pla
    old "B- Barbie! You have to stop!"
    new "B- Barbie! Du musst aufhören!"

    # say L436 pla
    old "Someone already saw us!"
    new "Jemand hat uns schon gesehen!"

    # say L472 pla
    old "What are you talking about!"
    new "Wovon redest du!"

    # say L473 pla
    old "I'm sure Dr. Johnson caught us!"
    new "Ich bin sicher, Dr. Johnson hat uns gesehen!"

    # say L474 pla
    old "What if she says something to the building administrators?!"
    new "Was, wenn sie was zu den Hausverwaltungsleuten sagt?!"

    # say L594 pla
    old "Barbie I-!"
    new "Barbie ich-!"

    # say L654 pla
    old "B- Barbie - I feel like I'm cumming!"
    new "B- Barbie - ich glaube, ich komme!"

    # say L665 pla
    old "I- I'm glad you enjoyed it."
    new "Ich- Ich freue mich, dass es dir gefallen hat."

    # say L666 pla
    old "But hey, what do you say we get up and get dressed?"
    new "Aber hey, was sagst du dazu, wenn wir aufstehen und uns anziehen?"


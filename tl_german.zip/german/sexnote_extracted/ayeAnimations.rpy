# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/ayeAnimations.rpy
translate german strings:

    # say L6 aye
    old "My god this dick is so big!"
    new "Mein Gott, dieser Schwanz ist echt riesig!"

    # say L7 aye
    old "I noticed it the last time!"
    new "Ich hab's beim letzten Mal auch schon gemerkt!"

    # say L8 aye
    old "But having it in my mouth is just something else!"
    new "Aber es in meinem Mund zu haben, das ist einfach was anderes!"

    # say L12 aye
    old "I bet you've never gotten head like this before right?"
    new "Ich wette, du hast noch nie so einen geblasen bekommen, oder?"

    # say L13 aye
    old "I know I'm so much better than my sister!"
    new "Ich weiß, ich bin viel besser als meine Schwester!"

    # say L14 aye
    old "I'm sure there's no comparison!"
    new "Ich bin mir sicher, da gibt es keinen Vergleich!"

    # say L18 aye
    old "Is this good [pla]?!"
    new "Ist das gut [pla]?!"

    # say L19 pla
    old "Y- yeah, it is!"
    new "Y- ja, das ist es!"

    # say L21 aye
    old "Of course it is! I'm so much better than Olivia!"
    new "Natürlich ist es das! Ich bin viel besser als Olivia!"

    # say L44 aye
    old "I- I can feel like you're about to finish!"
    new "Ich- Ich spür, dass du gleich kommst!"

    # say L45 pla
    old "Y- yeah! I am!"
    new "Y- ja! Ich bin es!"

    # say L46 aye
    old "Do it! I want to get your cum in my mouth!"
    new "Mach es! Ich will deinen Saft in meinem Mund spüren!"

    # say L53 aye
    old "Look at how much you came!"
    new "Schau dir an, wie viel Sperma du abgespritzt hast!"

    # say L54 aye
    old "You see? I told you I was way better than Olivia!"
    new "Siehst du? Habe ich dir nicht gesagt, dass ich viel besser bin als Olivia?"

    # say L55 aye
    old "I bet you've never had anything like that before!"
    new "Ich wette, du hast noch nie so was erlebt!"

    # say L56 pla
    old "Yeah, yeah..."
    new "Ja, ja..."

    # say L57 pla
    old "Listen, get up before your mother or your sister come here and see us like this."
    new "Hör zu, steh auf, bevor deine Mutter oder deine Schwester hier reinkommen und uns so sehen."

    # say L58 aye
    old "Ugh, you're such a prude."
    new "Mann, du bist echt ein Spießer."


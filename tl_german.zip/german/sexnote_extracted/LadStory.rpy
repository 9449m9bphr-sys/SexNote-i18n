# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/LadStory.rpy
translate german strings:

    # say L11 mo1
    old "Good morning honey."
    new "Guten Morgen, Schatz."

    # say L12 pla
    old "Oh! good morning [mo1rel]."
    new "Oh! Guten Morgen [mo1rel]."

    # say L13 mo1
    old "Did you have a good night?"
    new "Hast du gut geschlafen?"

    # say L14 pla
    old "Yeah, I did. And you?"
    new "Ja, hab ich. Und du?"

    # say L16 mo1
    old "I did hun, thank you."
    new "Ich habe auch gut geschlafen, danke."

    # say L17 pla
    old "Is there anything I can help you with [mo1rel]?"
    new "Ist da was, bei dem ich dir helfen kann [mo1rel]?"

    # say L18 mo1
    old "Well, not really. I just wanted to see if you're doing anything with your friends for halloween."
    new "Naja, eigentlich nicht. Ich wollte nur sehen, ob du heute Abend schon was mit deinen Freunden vorhast."

    # say L20 pla
    old "Oh that's right! It's today! I'd totally forgotten about it."
    new "Oh stimmt! Heute ist es! Ich hatte es total vergessen."

    # say L21 pla
    old "That reminds me, I need to pick up my costume."
    new "Das erinnert mich daran, dass ich mein Kostüm noch abholen muss."

    # say L23 mo1
    old "Are you going to school in a costume?"
    new "Wollen Sie heute in Kostüm zur Schule gehen?"

    # say L24 pla
    old "Yeah, me and my friends are dressing up for Halloween."
    new "Klar, meine Freunde und ich verkleiden uns für Halloween."

    # say L25 mo1
    old "Really? Why? Are you having a party?"
    new "Wirklich? Warum? Macht ihr eine Party?"

    # say L26 pla
    old "No, no, nothing special like that. It's just that the school principal said all students get to wear costumes today."
    new "Nein, nein, nichts Besonderes. Es ist nur, dass der Schulleiter gesagt hat, alle Schüler dürfen heute Kostüme tragen."

    # say L27 mo1
    old "Seriously? That's cool."
    new "Ehrlich? Das ist cool."

    # say L28 pla
    old "Yeah, it's nice we get to do this once in a while. Everyone's excited about it."
    new "Ja, es ist schön, dass wir das ab und zu machen dürfen. Alle freuen sich darauf."

    # say L29 mo1
    old "Well [pla], that sounds like a lot of fun. I'm happy you get to do that with your friends."
    new "Na [pla], das klingt ja toll. Ich freue mich, dass du das mit deinen Freunden machen darfst."

    # say L30 mo1
    old "After all, this is your last Halloween at school, where you still get to dress up, so make sure to enjoy it."
    new "Schließlich ist das dein letztes Halloween an der Schule, wo du dich noch verkleiden darfst, also genieße es in vollen Zügen."

    # say L31 pla
    old "Yeah, I'll do. We're competing about who has the worst costume."
    new "Klar, mach ich. Wir wette, wer die schlimmste Kostüm hat."

    # say L32 mo1
    old "And do you have one already?"
    new "Und hast du schon eine?"

    # say L33 pla
    old "Yeah, I asked Kylee to get one for me. I should ask her if it's already arrived. Bye [mo1rel], see you later."
    new "Ja, ich hab Kylee gebeten, mir eins zu besorgen. Sollte sie mal fragen, ob es schon angekommen ist. Tschüss [mo1rel], bis später."

    # say L34 mo1
    old "Bye honey, have a good day."
    new "Tschüss Schatz, hab einen schönen Tag."

    # say L52 pla
    old "Hi [sis], good morning."
    new "Hi [sis], guten Morgen."

    # say L53 sis
    old "Hi [pla], good morning. How are you?"
    new "Hi [pla], guten Morgen. Wie geht es Ihnen?"

    # say L54 pla
    old "I'm fine. Hey, I just remembered I asked you to get my costume for Halloween. Did it arrive?"
    new "Ich bin gut. Hey, ich hab gerade dran gedacht, dass ich dich gebeten hab, mein Kostüm für Halloween zu besorgen. Ist es angekommen?"

    # say L55 sis
    old "Yeah, it did. It came in with the last shipment of clothing for the store."
    new "Ja, es ist angekommen. Es kam mit der letzten Lieferung von Kleidung für den Laden."

    # say L57 pla
    old "Great! Where is it?"
    new "Super! Wo ist es?"

    # say L59 sis
    old "Hmm... I haven't unpacked anything yet, so it must be in one of the boxes."
    new "Hmm... Ich habe noch nichts ausgepackt, also muss es in einem der Kartons sein."

    # say L60 sis
    old "Just wait here a minute. I'll go get it for you."
    new "Warte hier einen Moment. Ich hole es für dich."

    # say L72 sis
    old "Here you go."
    new "Hier, bitte."

    # say L75 pla
    old "This is great! Thanks [sis]."
    new "Das ist toll! Danke [sis]."

    # say L76 sis
    old "Well, you go try it on and let me know if it fits you, and you like it."
    new "Dann zieh es mal an und sag mir, ob es dir passt und gefällt."

    # say L77 pla
    old "Of course, by the way, how much do I owe you?"
    new "Natürlich, übrigens, wie viel schulde ich dir?"

    # say L78 sis
    old "Oh, don't worry about it..."
    new "Oh, mach dir keine Sorgen deswegen..."

    # say L79 sis
    old "It's on the house."
    new "Das geht aufs Haus."

    # say L80 pla
    old "Oh really? Well... Thank you [sis]."
    new "Oh wirklich? Na dann... Danke [sis]."

    # say L82 sis
    old "Now leave, I have a lot of work to do."
    new "Dann geh jetzt, ich hab noch viel zu tun."

    # say L83 pla
    old "Ok, I'll go try on the costume then. See you later [sis], thanks again."
    new "Okay, ich zieh dann mal den Kostüm an. Bis später [sis], danke nochmal."

    # say L84 sis
    old "You're welcome and enjoy it."
    new "Gern geschehen und viel Spaß damit."

    # say L102 pla
    old "Wow! This is so cool! [sis] has some really good products."
    new "Wow! Das ist ja super! [sis] hat echt tolle Produkte."

    # say L103 pla
    old "I think I'll definitely blow their minds with this."
    new "Ich denke, ich werde ihnen damit echt den Verstand rauben."

    # say L104 pla
    old "Now I'm ready for Halloween!"
    new "Jetzt bin ich bereit für Halloween!"

    # say L127 pla
    old "Hey guys, what 's up?"
    new "Hey Leute, was ist los?"

    # say L129 bel
    old "Whooa [pla]! What a costume!"
    new "Wow [pla]! Was für ein Kostüm!"

    # say L130 pla
    old "Cool, isn't it?"
    new "Cool, oder?"

    # say L131 bel
    old "It looks very good."
    new "Sieht wirklich gut aus."

    # say L132 mik
    old "Yeah dude, really cool."
    new "Ja Mann, echt cool."

    # say L134 mik
    old "But to be honest, not as cool as mine."
    new "Aber ehrlich gesagt, nicht so cool wie meiner."

    # say L135 bel
    old "Really? And why is that?"
    new "Wirklich? Und warum ist deins cooler?"

    # say L136 mik
    old "Because I'm Iron Man, I mean... Come on!"
    new "Weil ich der Iron Man bin, also... Komm schon!"

    # say L137 mik
    old "I'm the super rich, genius, chick magnet! No way Spiderman beats that."
    new "Ich bin der superreiche, geniale, Frauenmagnet! Da kann Spiderman nicht mithalten."

    # say L139 pla
    old "It actually is a cool Iron Man costume... Even the goatee."
    new "Das ist tatsächlich ein cooler Iron Man-Kostüm... sogar der Bart."

    # say L141 bel
    old "Hmph, I guess."
    new "Hmpf, ich schätze schon."

    # say L143 mik
    old "And you Belle? Are you like a type of rabbit?"
    new "Und du, Belle? Bist du eine Art Kaninchen?"

    # say L144 bel
    old "Not a type of rabbit. I'm a bunny, the coolest one, Lola Bunny!"
    new "Keine Kaninchenart. Ich bin ein Bunny, das coolste, Lola Bunny!"

    # say L145 pla
    old "Ohh right. I get it now."
    new "Ohh klar. Jetzt verstehe ich."

    # say L146 pla
    old "Cool costume, it looks really good on you."
    new "Cooler Kostüm, das steht dir echt gut."

    # say L160 rub
    old "Oh my, Olivia, would you look at that? The loser club in their dumb costumes. Aren't they childish?"
    new "Oh mein, Olivia, schau dir das an? Der Verliererclub in ihren blöden Kostümen. Sind die nicht kindisch?"

    # say L161 oli
    old "Yeah, always acting like little kids. Dumb, poor kids."
    new "Klar, immer wie kleine Kinder rumzulaufen. Blöde, arme Kids."

    # say L162 bel
    old "Don't you two airheads have anything better to do this early in the morning?"
    new "Habt ihr beiden Idioten nichts Besseres zu tun, so früh am Morgen?"

    # say L163 rub
    old "Better than showing you just how much of a dumbass you are? Don't think so."
    new "Besser als dir zu zeigen, wie blöd du bist? Ich denke nicht."

    # say L164 rub
    old "By the way, are you supposed to be Lola Bunny?"
    new "Übrigens, bist du etwa Lola Bunny?"

    # say L165 bel
    old "Y-yeah, I am. Why?"
    new "Y-ja, bin ich. Warum?"

    # say L166 rub
    old "Dear, you should realize that with those ears, and that pig nose of yours, you're much more of a Piglet."
    new "Liebling, du solltest doch merken, dass mit diesen Ohren und dieser Schweinenase du viel mehr ein Ferkel bist."

    # say L167 pla
    old "Hey! Don't you think that's too much?"
    new "Hey! Findest du das nicht ein bisschen zu viel?"

    # say L168 mik
    old "That's right. Shut up!"
    new "Stimmt. Maul halten!"

    # say L169 rub
    old "Wow Olivia, look who's defending Piglet! Spiderman the scrawny loser, and Iron fat."
    new "Wow Olivia, schau mal, wer Piglet verteidigt! Spiderman der Schlappschwanz und Iron Fett."

    # say L170 oli
    old "What's funny is that they're opposites. One is too slim to fill his Spiderman pajamas, and the other's too fat to fit into the costume."
    new "Was lustig ist, ist, dass sie Gegensätze sind. Der eine ist zu dünn, um seine Spiderman-Pyjamas auszufüllen, und der andere ist zu fett, um in den Kostüm zu passen."

    # say L171 rub
    old "Hey Iron Man, don't you think it's ridiculous that your belly's rounder than your chest?"
    new "Hey Iron Man, findest du es nicht lächerlich, dass dein Bauch runder ist als deine Brust?"

    # say L172 oli
    old "Maybe we should call him barrel man."
    new "Vielleicht sollten wir ihn Fassmann nennen."

    # say L179 hin
    old "Hey guys! What's up? It's everything ok?"
    new "Hey Leute! Was ist los? Ist alles in Ordnung?"

    # say L183 oli
    old "Ohh wow. What a costume..."
    new "Ohh wow. Was für ein Kostüm..."

    # say L184 rub
    old "My god! And what the hell are you wearing? You look like a WHORE."
    new "Mein Gott! Und was zum Teufel hast du an? Du siehst aus wie eine SCHLAMPE."

    # say L185 oli
    old "The stupid cow came dressed up like a bat-whore."
    new "Die blöde Kuh hat sich als Fledermaus-Hure verkleidet."

    # say L187 hin
    old "Hey! It's not a whore costume. I'm Morrigan from Darkstalkers. And for your information this took a lot of time to make..."
    new "Hey! Das ist kein Nuttenkostüm. Ich bin Morrigan aus Darkstalkers. Und falls es dich interessiert, das hat eine Menge Zeit gekostet..."

    # say L188 rub
    old "Ughh nerd... I don't care..."
    new "Ughh Nerd... Mir egal..."

    # say L189 rub
    old "I am only surprised that the shy moron I see here every day would bring such a revealing costume."
    new "Ich bin nur überrascht, dass die schüchterne Idiotin, die ich hier jeden Tag sehe, so einen aufreizenden Kostüm tragen würde."

    # say L190 oli
    old "Which by the way, it's disgusting."
    new "Das ist übrigens ekelhaft."

    # say L191 rub
    old "I mean, you couldn't wear ANYTHING more revealing! My god! You should be ashamed!"
    new "Ich meine, du könntest nichts Offenherzigeres tragen! Mein Gott! Du solltest dich schämen!"

    # say L192 hin
    old "W- what are you talking about? Your costume has also a cleavage..."
    new "W-wovon redest du? Dein Kostüm hat auch einen tiefen Ausschnitt..."

    # say L193 rub
    old "WHAT? YOU'VE GOTTA BE KIDDING ME!"
    new "Was? Du musst mich verarschen!"

    # say L194 rub
    old "We have decent classy costumes, there's nothing wrong with ours."
    new "Wir haben anständige, klassische Kostüme, da ist nichts falsch dran."

    # say L195 rub
    old "In case you haven't noticed, Olivia and I are Disney princesses..."
    new "Falls dir das noch nicht aufgefallen ist, Olivia und ich sind Disney-Prinzessinnen..."

    # say L196 rub
    old "While you just came in a stupid costume from some nerd stuff."
    new "Während du einfach in einem blöden Kostüm von irgendwelchem Nerdzeug aufgetaucht bist."

    # say L197 hin
    old "Well, I don't care, because I really have something to show and I feel comfortable with my body, unlike you two stupid bitches..."
    new "Na und, mir ist es egal, weil ich wirklich was zu zeigen habe und ich mich in meinem Körper wohlfühle, im Gegensatz zu euch beiden dummen Schlampe..."

    # say L198 rub
    old "W- what did you just say to me?! Olivia! Did you hear that?!!"
    new "W-was hast du mir gerade gesagt?! Olivia! Hast du das gehört?!!"

    # say L199 oli
    old "I did Ruby! How dare you talk to us like that? You bat-whore!"
    new "Ich hab's gehört, Ruby! Wie kannst du es wagen, so mit uns zu reden? Du Fledermaus-Schlampe!"

    # say L200 hin
    old "Shut up you two! You envious bitches!"
    new "Halt die Klappe, ihr beiden! Ihr neidischen Schlampe!"

    # say L201 bel
    old "Ohhhh! What's the matter, girls? You can dish it, but you can't take it?"
    new "Ooooo! Was ist los, Mädels? Ihr könnt es ausspucken, aber nicht schlucken, hm?"

    # say L202 pla
    old "H-Hey, Hinn, maybe it's best if we just leave, look, classes are about to start..."
    new "H-Hey, Hinn, vielleicht ist es besser, wenn wir einfach gehen, schau, die Unterrichtsstunden fangen gleich an..."

    # say L203 hin
    old "And why do we have to be the ones to leave?! These idiots are the ones who started."
    new "Und warum müssen wir diejenigen sein, die gehen?! Diese Idioten haben angefangen."

    # say L204 hin
    old "You two better get out here! I've had enough of your bullshit!"
    new "Ihr beiden haut ab hier! Ich hab genug von eurem Scheiß!"

    # say L205 rub
    old "Ughh. We're leaving! But it's not because you tell us to, you little whore! I just don't want to keep wasting my time with you, dumbasses."
    new "Ughh. Wir gehen! Aber nicht, weil du es sagst, du kleine Schlampe! Ich will nur meine Zeit nicht mehr mit euch Idiotinnen verschwenden."

    # say L206 rub
    old "Let 's go Olivia."
    new "Lass uns gehen, Olivia."

    # say L220 bel
    old "Wow! Hinn, what's happened to you? That was sooo awesome!"
    new "Wow! Hinn, was ist mit dir passiert? Das war soo toll!"

    # say L221 hin
    old "Hehe, you think so?"
    new "Hehe, findest du?"

    # say L222 bel
    old "Hell yeah! I don't know what you've been doing, but you're so confident now. Just look at how you put those airheads in their place!"
    new "Klar doch! Keine Ahnung, was du gemacht hast, aber du bist jetzt so selbstbewusst. Schau dir nur an, wie du diese Idioten in ihre Schranken gewiesen hast!"

    # say L223 hin
    old "And... What do you think [pla]?"
    new "Und... Was denkst du [pla]?"

    # say L224 pla
    old "I agree with Belle, you were totally awesome Hinn!"
    new "Ich stimme Belle zu, du warst total awesome, Hinn!"

    # say L225 hin
    old "Well, it's a relief to hear you guys say that... For a moment there I thought you may have thought ill of me."
    new "Na ja, es ist eine Erleichterung, das von euch zu hören... Einen Moment lang dachte ich, ihr könntet schlecht von mir denken."

    # say L227 pla
    old "Aww, we wouldn't. And hey, for what it's worth, I think your costume is great."
    new "Aww, wir würden das nie tun. Und hey, ehrlich gesagt, finde ich dein Kostüm super."

    # say L228 bel
    old "Yeah Hinn, you look gorgeous, and I'm happy you're finally showing some skin, it was about time!"
    new "Ja Hinn, du siehst toll aus, und ich freue mich, dass du endlich mal was weniger anhast, es war wirklich Zeit!"

    # say L229 hin
    old "Sigh, stop it with that."
    new "Seufz, hört auf damit."

    # say L230 mik
    old "Yeah Hinn, it really, really suits you."
    new "Ja Hinn, es steht dir wirklich, wirklich gut."

    # say L231 mik
    old "And hey, I support you sharing your natural gifts with us. It's a really nice view."
    new "Und hey, ich unterstütze dich dabei, deine natürlichen Gaben mit uns zu teilen. Es ist wirklich ein schöner Anblick."

    # say L233 bel
    old "Oh my gosh Mike, couldn't you be a little decent at least once?"
    new "Oh mein Gott Mike, konntest du wenigstens einmal anständig sein?"

    # say L234 mik
    old "What? What did I say? I was giving Hinn a compliment!"
    new "Was? Was hab ich gesagt? Ich hab Hinn doch nur ein Kompliment gemacht!"

    # say L235 bel
    old "Yeah right, sure you were..."
    new "Klar, sicher warst du das..."

    # say L236 bel
    old "Anyway, we better get going. It's almost time for class."
    new "Na ja, wir sollten besser los. Es ist gleich Zeit für den Unterricht."

    # say L237 mik
    old "Huh? But we still have some time."
    new "Hä? Aber wir haben doch noch Zeit."

    # say L239 bel
    old "I know, but you know Ms. Mia has her eyes on you because you keep skipping. So, let's go, come on!"
    new "Ich weiß, aber du weißt ja, Ms. Mia hat es auf dich abgesehen, weil du immer schwänzt. Also los, komm!"

    # say L250 hin
    old "W- was that true [pla]?"
    new "W-was das stimmt [pla]?"

    # say L253 hin
    old "What you said about my costume, do you really like it?"
    new "Was du über mein Kostüm gesagt hast, magst du es wirklich?"

    # say L254 pla
    old "Of course! I like it a lot."
    new "Natürlich! Mir gefällt es sehr."

    # say L255 pla
    old "And to be honest... I think you're the only student who could pull it off."
    new "Und ehrlich gesagt... ich denke, du bist die einzige Schülerin, die das wirklich hinbekommt."

    # say L256 hin
    old "Huh? You mean it?"
    new "Hinn: Was? Ernsthaft?"

    # say L257 pla
    old "Yeah! Nobody else could wear that costume that well."
    new "Klar! Niemand anderes könnte dieses Kostüm so gut tragen."

    # say L260 hin
    old "Come with me for a moment [pla]..."
    new "Komm mit mir einen Moment [pla]..."

    # say L262 pla
    old "Uhh, where are we going?"
    new "Uhh, wohin gehen wir?"

    # say L263 hin
    old "Just come."
    new "Komm einfach mit."

    # say L285 pla
    old "Hmm, Hinn, this is the girl's bathroom, I don't think it's ok for me to go in."
    new "Hmm, Hinn, das ist die Mädchen-Toilette, ich glaube, es ist nicht okay für mich da reinzugehen."

    # say L286 pla
    old "Maybe it's better if I wait outside."
    new "Vielleicht ist es besser, wenn ich draußen warte."

    # say L288 pla
    old "For you to use the bathroom..."
    new "Damit du die Toilette benutzt..."

    # say L289 hin
    old "Hahahaha. Don't be silly, I didn't bring you here for that."
    new "Hahahaha. Sei nicht albern, ich habe dich doch nicht deshalb hierhergebracht."

    # say L290 pla
    old "Uhh, you didn't? Then why?"
    new "Uhh, hast du nicht? Wozu dann?"

    # say L292 hin
    old "You see, working with you and Dr. Johnson has really helped me get over my shyness, that's how I was able to stand up to those bullies."
    new "Du siehst, die Arbeit mit dir und Dr. Johnson hat mir echt geholfen, meine Schüchternheit zu überwinden. Deshalb konnte ich den Bullies auch entgegentreten."

    # say L293 hin
    old "So, I thought maybe we could have a little session now. Besides, I want to thank you."
    new "Dann dachte ich, wir könnten jetzt ein kleines Session machen. Und außerdem will ich mich bei dir bedanken."

    # say L294 pla
    old "B- but here? What if someone sees us?"
    new "Aber hier? Was, wenn uns jemand sieht?"

    # say L295 hin
    old "Ohh, don't worry, I'm sure it's gonna be fine, classes are about to start, so there's nobody around."
    new "Ohh, mach dir keine Sorgen, ich bin sicher, es wird alles gut gehen. Die Vorlesungen fangen gleich an, da ist hier niemand."

    # say L296 pla
    old "Well, if you say so... I guess it's ok then."
    new "Na gut, wenn du das sagst... dann ist es wohl okay."

    # say L297 hin
    old "Yes, I'm sure nobody will see us."
    new "Ja, ich bin sicher, dass uns niemand sieht."

    # say L298 hin
    old "Come here, pull down your pants."
    new "Komm her, zieh deine Hose runter."

    # say L305 hin
    old "It's always amazing how big you are [pla]."
    new "Es ist immer erstaunlich, wie groß du bist [pla]."

    # say L306 pla
    old "I can believe we're doing it in the bathroom."
    new "Ich kann es nicht glauben, dass wir das im Badezimmer machen."

    # say L308 hin
    old "I'm happy you're this hard because of me."
    new "Ich freue mich, dass du so hart für mich bist."

    # say L317 hin
    old "Look, it's almost time for class."
    new "Schau, es ist fast Zeit für den Unterricht."

    # say L318 hin
    old "I'll go ahead. Don't be late."
    new "Ich geh schon mal vor. Sei nicht zu spät."

    # say L327 pla
    old "Wow! I don't know what that was, but I sure like this new Hinn."
    new "Wow! Ich hab keine Ahnung, was das war, aber ich mag diesen neuen Hinn echt."

    # say L340 pla
    old "Ohh! Wow, Billie! What are you doing here?"
    new "Ohh! Wow, Billie! Was machst du hier?"

    # say L342 bil
    old "Hey! What's up? I just transferred here. Today's my first day."
    new "Hey! Was ist los? Ich bin gerade hierher gewechselt. Heute ist mein erster Tag."

    # say L343 pla
    old "Ahh, I see. That's cool, what school did you transfer from?"
    new "Ahh, ich verstehe. Das ist cool, von welcher Schule kommst du?"

    # say L344 bil
    old "From nowhere actually. All my life I've been home schooled, and that's fine, I guess. But you see, this is my last year..."
    new "Von nirgendwo eigentlich. Mein ganzes Leben war ich zu Hause unterrichtet, und das ist okay, schätze ich. Aber siehst du, es ist mein letztes Jahr..."

    # say L345 bil
    old "So, I wanted to have the school experience at least for senior year."
    new "Dann wollte ich halt die Schule wenigstens im letzten Jahr erleben."

    # say L346 pla
    old "Well, I think that's a great idea! I'm glad you get to live that at least once. And hey, welcome."
    new "Na, ich finde das ist eine tolle Idee! Ich freue mich, dass du das wenigstens einmal erleben kannst. Und hey, willkommen."

    # say L348 bil
    old "It was a coincidence that my first day was Halloween. So, I had to come in costume. What do you think?"
    new "Es war Zufall, dass mein erster Tag Halloween war. Also musste ich verkleidet kommen. Was denkst du?"

    # say L349 pla
    old "I think it's great, it's really good. You look just like the real Harley Quinn."
    new "Ich finde es toll, echt gut. Du siehst genauso aus wie die echte Harley Quinn."

    # say L350 bil
    old "Thanks, and hey, I think you also make for a very good Spiderman."
    new "Danke, und hey, ich finde, du machst auch einen sehr guten Spiderman."

    # say L352 pla
    old "Thanks!"
    new "Danke!"

    # say L353 bil
    old "By the way. Why were you leaving the girls bathroom?"
    new "Ach ja. Warum bist du aus der Mädchentoilette rausgekommen?"

    # say L354 pla
    old "Ohh! Hmm, no reason."
    new "Ohh! Hmm, keinen Grund."

    # say L355 pla
    old "I guess, I- I just got confused."
    new "Ich schätze, ich- ich hab mich einfach verlaufen."

    # say L357 bil
    old "Uhh... Sure..."
    new "Uhh... Klar..."

    # say L358 pla
    old "We better get going, the class has already started."
    new "Wir sollten besser losgehen, die Stunde hat schon angefangen."

    # say L364 mia
    old "Ok guys, let's start today's lesson. Now who can tell me where we left it last time?"
    new "Ok Leute, lasst uns mit dem heutigen Unterricht beginnen. Wer kann mir sagen, bei welchem Thema wir letztes Mal aufgehört haben?"

    # say L379 pla
    old "Sorry ma'am! We came as quickly as we could."
    new "Entschuldigung, Frau Mia! Wir sind so schnell wie möglich gekommen."

    # say L380 mia
    old "Ugh! It's always the same with you [pla]! Would it kill you to act like a good student at least once?"
    new "Ugh! Es ist immer das Gleiche bei Ihnen [pla]! Würde es Sie umbringen, einmal wie ein guter Schüler zu handeln?"

    # say L381 pla
    old "I- I'm sorry Ms. Mia, it won't happen again, it's just that I met my friend in the hallway."
    new "Ich- Ich bin sorry, Frau Mia, es passiert nicht wieder, ich bin nur meinem Freund im Flur begegnet."

    # say L382 mia
    old "Yeah right! Always excuses with you. Anyway, go sit down!"
    new "Klar doch! Immer Ausreden bei Ihnen. Na los, setzen Sie sich!"

    # say L389 mia
    old "Ok guys, before we begin, I have to introduce you to a new student."
    new "Ok Leute, bevor wir anfangen, muss ich euch eine neue Schülerin vorstellen."

    # say L393 mia
    old "This is Billie, she's going to be accompanying us during this last year. Be sure to be nice to her."
    new "Das ist Billie, sie wird uns in diesem letzten Jahr Gesellschaft leisten. Seid nett zu ihr."

    # say L396 mia
    old "Take seat Billie, there's a spot for you there."
    new "Setz dich, Billie, da ist noch ein Platz für dich."

    # say L401 mia
    old "Ok guys, as I was saying before being so rudely interrupted by [pla].  Who can tell me what we were talking about last class?"
    new "Ok Leute, wie ich vorhin sagte, bevor ich so unhöflich von [pla] unterbrochen wurde. Wer kann mir sagen, worüber wir in der letzten Stunde gesprochen haben?"

    # say L409 mia
    old "Ok, that's it for today, don't forget to read up on the textbook before next class. It's better if you prepare your classes ahead."
    new "Okay, das war's für heute, vergesst nicht, das Buch vor der nächsten Stunde zu lesen. Es ist besser, wenn ihr euch vorbereitet."

    # say L423 bel
    old "Ok everybody, classes are over, and we have time. Why don't we go ask for some candy?"
    new "Ok alle, die Stunde ist vorbei, und wir haben Zeit. Warum gehen wir nicht und holen uns etwas Süßes?"

    # say L424 bil
    old "Ugh, candy? Are you serious? Don't you think we're a little too old for that?"
    new "Ugh, Süßigkeiten? Im Ernst? Finden Sie nicht, dass wir dafür ein bisschen zu alt sind?"

    # say L425 bel
    old "Ohh, come on! This is our last year, so we won't be able to do it anymore."
    new "Ohh, komm schon! Es ist unser letztes Jahr, danach können wir das nicht mehr machen."

    # say L426 mik
    old "Yeah! Billie, trick or treating is super cool, we'll have a great time."
    new "Klar! Billie, Trick or Treating ist total cool, wir werden einen tollen Abend haben."

    # say L427 bil
    old "I don't think walking around, knocking on front doors is a ‘great time.'"
    new "Ich glaube nicht, dass rumlaufen und an Türen klingeln ’ne tolle Zeit ist."

    # say L428 bil
    old "But whatever, if you all want to."
    new "Aber egal, wenn ihr alle wollt."

    # say L430 pla
    old "I actually want too, it's a good way to spend the afternoon."
    new "Ich will auch, es ist eine gute Art, den Nachmittag zu verbringen."

    # say L431 pla
    old "Besides, we get to use the costumes some more."
    new "Außerdem können wir die Kostüme noch mal tragen."

    # say L432 pla
    old "And what do you think Hinn?"
    new "Und was denkst du, Hinn?"

    # say L433 hin
    old "I think it's a nice idea. I wanna hang out some more."
    new "Ich finde es eine gute Idee. Ich will noch ein bisschen rumhängen."

    # say L434 hin
    old "And to be honest I also don't want to get out of my costume just yet."
    new "Und ehrlich gesagt, will ich auch noch nicht aus meinem Kostüm raus."

    # say L435 bil
    old "Oh my god, you guys are so lame."
    new "Oh mein Gott, ihr seid echt so langweilig."

    # say L436 bil
    old "But fine, fine, if you want to do it, I'll do it too. This better be good."
    new "Aber gut, gut, wenn ihr es machen wollt, mach ich's auch. Das sollte besser gut sein."

    # say L453 mik
    old "That was so awesome! I can't believe they gave us this much candy at our age."
    new "Das war so krass! Ich kann nicht glauben, dass sie uns bei unserem Alter so viel Süßigkeiten gegeben haben."

    # say L454 pla
    old "Definitely, a real success I'd say."
    new "Definitiv, ein echter Erfolg, würde ich sagen."

    # say L455 bel
    old "You see? It was totally worth it. I knew it was gonna be this much fun. Right Billie?"
    new "Siehst du? Es war absolut die Mühe wert. Ich wusste, es wird so viel Spaß machen. Stimmt’s, Billie?"

    # say L456 bil
    old "Yeah... I guess. It wasn't so bad after all."
    new "Klar... Ich schätze schon. War gar nicht so schlecht."

    # say L457 hin
    old "It's still early, we could keep going if you want to."
    new "Es ist noch früh, wir könnten weitermachen, wenn du willst."

    # say L458 mik
    old "Nah, I don't think so. This is nice and all, but my feet hurt, I'm a little tired of carrying this heavy custume."
    new "Nah, ich glaube nicht. Das ist schön und so, aber meine Füße tun weh, ich bin ein bisschen müde von diesem schweren Kostüm."

    # say L459 pla
    old "Come on man, don't ruin the mood, you're the one who wanted to ask for candy in the first place."
    new "Komm schon, Mann, verdirb nicht die Stimmung, du warst derjenige, der unbedingt Süßigkeiten holen wollte."

    # say L460 bel
    old "Actually [pla], it annoys me to say this, but I think Mike may be right. We've been going for a while now, we should rest."
    new "Eigentlich [pla], es nervt mich, das zu sagen, aber ich glaube, Mike hat recht. Wir sind schon eine Weile unterwegs, wir sollten uns ausruhen."

    # say L461 bil
    old "Well, if that's the case, we should go to the beach then, it's very nearby and we could sit and rest there."
    new "Na gut, wenn das so ist, sollten wir dann zum Strand gehen. Es ist ganz in der Nähe und wir könnten dort sitzen und ausruhen."

    # say L462 pla
    old "Hmm, and what do you think, Hinn? Do you want to keep going?"
    new "Hmm, und was denkst du, Hinn? Willst du weitermachen?"

    # say L463 hin
    old "Ohh, I'm fine. I only said it because I thought everyone else wanted to do it too, but if everyone it's ok with stopping here I'd agree."
    new "Ohh, mir geht's gut. Ich hab's nur gesagt, weil ich dachte, alle anderen wollen das auch, aber wenn es für alle in Ordnung ist, hier aufzuhören, bin ich einverstanden."

    # say L464 bel
    old "That settles it then, let's go to the beach."
    new "Dann ist das ja geklärt, lass uns zum Strand gehen."

    # say L478 pla
    old "Well, this is nice. I thought there were going to be people here."
    new "Na, das ist schön. Ich dachte, hier wären mehr Leute."

    # say L479 hin
    old "Yeah, it's good that it is so quiet, this is a good place to rest."
    new "Ja, es ist gut, dass es so ruhig ist, hier können wir uns gut ausruhen."

    # say L480 bel
    old "We should find a place to sit down."
    new "Wir sollten uns irgendwo hinsetzen."

    # say L481 hin
    old "Can't we just sit here?"
    new "Können wir uns nicht einfach hier hinsetzen?"

    # say L482 bel
    old "I think we could sit a little bit closer to the sea."
    new "Ich denke, wir könnten ein bisschen näher ans Meer gehen."

    # say L483 bil
    old "Let's just go to that spot over there"
    new "Lass uns einfach da drüben hingehen."

    # say L484 pla
    old "Yeah, that seems fine."
    new "Klar, das klingt gut."

    # say L498 bil
    old "Ok, since we're here. Why don't we make it a little bit more interesting than just sitting down doing nothing? Let's play truth or dare!"
    new "Ok, da wir hier sind. Warum machen wir es nicht ein bisschen spannender als nur rumzusitzen? Spielen wir Wahrheit oder Pflicht!"

    # say L499 hin
    old "Uhh, I'm sorry. Truth or what?"
    new "Uhh, Entschuldigung. Truth oder was?"

    # say L500 bil
    old "What? You don't know what truth or dare is?"
    new "Was? Du weißt nicht, was Wahrheit oder Pflicht ist?"

    # say L501 mik
    old "Hey! I know what it is."
    new "Hey! Ich weiß, was es ist."

    # say L502 pla
    old "Uhh, I think I know it, but I haven't played it."
    new "Uhh, ich glaube, ich weiß es, aber ich hab's noch nie gespielt."

    # say L503 pla
    old "Just so we're all on the same page, could you explain?"
    new "Damit wir alle auf demselben Stand sind, könntest du das erklären?"

    # say L505 bil
    old "It's very simple: Each round, one of us chooses someone and asks them 'truth or dare'"
    new "Es ist ganz einfach: In jeder Runde wählt einer von uns jemanden aus und fragt sie 'Wahrheit oder Pflicht'"

    # say L506 bil
    old "If the person chooses ‘truth' they have to answer whatever the other one asks. If they choose ‘dare', they have to do what the person tells them to."
    new "Wenn die Person „Wahrheit“ wählt, muss sie alles beantworten, was der Andere fragt. Wenn sie „Mut“ wählt, müssen sie das tun, was der Andere sagt."

    # say L507 pla
    old "All right..."
    new "Okay..."

    # say L508 bel
    old "You have to be really honest in answering or accomplishing the dare, otherwise, you must go and can't continue playing."
    new "Du musst echt ehrlich antworten oder die Herausforderung meistern, sonst darfst du nicht weitermachen und musst raus."

    # say L509 bil
    old "Yeah, just like that, it's really fun. Come on, let's play!"
    new "Ja, genau so, das ist echt spaßig. Los, lass uns spielen!"

    # say L511 pla
    old "Hmm, I don't know Billie..."
    new "Hmm, ich weiß nicht, Billie..."

    # say L512 mik
    old "Oh no! We're not backing down from this, [pla]. Come on! It sounds like a lot of fun!"
    new "Oh nein! Wir geben jetzt nicht auf, [pla]. Los, das klingt total spaßig!"

    # say L513 bel
    old "Yeah guys, let's do it. You never know, you may end up liking it."
    new "Ja, Leute, lasst es uns machen. Wer weiß, vielleicht gefällt es euch ja."

    # say L514 pla
    old "Ok, ok. If you guys really want to, let's do it."
    new "Ok, ok. Wenn ihr es wirklich wollt, machen wir's."

    # say L516 mik
    old "Alright! Let's do it!"
    new "Okay! Machen wir's!"

    # say L517 bil
    old "Did you get it Hinn?"
    new "Hast du es kapiert, Hinn?"

    # say L519 hin
    old "Yeah, it's not that hard."
    new "Klar, das ist doch nicht so schwer."

    # say L520 bel
    old "Ok, since you say you understood it Hinn. Let's start with you, truth or dare?"
    new "Okay, da du sagst, dass du es verstanden hast, Hinn. Fangen wir mit dir an, Wahrheit oder Pflicht?"

    # say L521 hin
    old "Uhmm, truth."
    new "Hmm, Wahrheit."

    # say L523 bel
    old "Hmm, are you in love with anybody here?"
    new "Hmm, bist du in jemanden hier verliebt?"

    # say L524 hin
    old "W- what? What kind of question is that?!"
    new "W-was? Was für eine Frage ist das?!"

    # say L525 bel
    old "Uhh, it's a valid question, and you have to answer it, those are the rules..."
    new "Uhh, das ist eine legitime Frage und du musst sie beantworten, das sind die Regeln..."

    # say L526 bil
    old "That's right, that's the game."
    new "Das stimmt, das sind die Regeln des Spiels."

    # say L528 hin
    old "*Sigh* O- ok. Y- yes, I- I'm in love with someone who's here."
    new "*Seufz* O- ok. Y- ja, ich bin in jemanden hier verliebt."

    # say L531 mik
    old "WHAT?! Who is it? Who is it?"
    new "Was?! Wer ist es? Wer ist es?"

    # say L532 pla
    old "Hey, hey! Not fair, dude, she already answered a question. You can't ask her anything else. Right Billie?"
    new "Hey, hey! Nicht fair, Alter, sie hat schon eine Frage beantwortet. Du kannst sie nicht noch was fragen. Stimmt’s, Billie?"

    # say L534 bil
    old "Yeah, if you really wanna know that kind of stuff, you're gonna have to ask better questions."
    new "Klar, wenn du das wirklich wissen willst, musst du bessere Fragen stellen."

    # say L535 bil
    old "But come on, I think we should go for dares... It makes the game exciting!"
    new "Aber komm schon, ich denke, wir sollten auf Wahrheit oder Pflicht gehen... Das macht das Spiel spannend!"

    # say L536 bil
    old "Anyway, since you already spoke, why don't you ask the next question [pla]?"
    new "Na ja, da du schon gesprochen hast, warum stellst du nicht die nächste Frage [pla]?"

    # say L537 pla
    old "Hmm, ok. Well then, Belle, truth or dare?"
    new "Hmm, okay. Dann, Belle, Wahrheit oder Pflicht?"

    # say L538 bel
    old "Truth."
    new "Wahrheit."

    # say L539 bil
    old "Oh come on! Don't be pussies! Dares are way more fun!"
    new "Oh Mann! Seid doch nicht so feige! Dares sind viel spannender!"

    # say L540 pla
    old "Hmm... H- have you ever kissed a man before?"
    new "Hmm... H- hast du schon mal einen Mann geküsst?"

    # say L542 bil
    old "What kind of question is that? Are you serious? Oh my god, you're a bunch of wusses."
    new "Was für eine Frage ist das? Ernsthaft? Oh mein Gott, ihr seid echt ein Haufen Waschlappen."

    # say L547 bil
    old "I'll ask the question. Belle, have you ever taken naked pics?"
    new "Ich stell die Frage. Belle, hast du schon mal nackte Fotos gemacht?"

    # say L548 bel
    old "W- whoa. Don't you think that's a little too far?"
    new "W-was? Ist das nicht ein bisschen zu weit gegangen?"

    # say L550 bil
    old "No it's not and answer the question."
    new "Nein, das ist es nicht und beantwortest die Frage."

    # say L551 mik
    old "Yeah Belle, those are the rules. You answer the question or leave!"
    new "Ja Belle, das sind die Regeln. Du beantwortest die Frage oder gehst!"

    # say L555 bel
    old "Ugh! Yeah fine, I've taken naked photos before."
    new "Ugh! Ja gut, ich habe schon mal Nacktfotos gemacht."

    # say L558 mik
    old "Whoa! Really?!"
    new "Wow! Wirklich?!"

    # say L561 bil
    old "Hehe, ok. Who 's next?"
    new "Hehe, ok. Wer ist der Nächste?"

    # say L562 mik
    old "Me, me, me! I'm next."
    new "Ich, ich, ich! Ich bin dran."

    # say L563 mik
    old "Ok, Billie. Truth or dare?"
    new "Ok, Billie. Wahrheit oder Pflicht?"

    # say L564 bil
    old "Dare! Unlike you guys, I actually have some guts."
    new "Klar! Im Gegensatz zu euch habe ich tatsächlich ein bisschen Courage."

    # say L568 mik
    old "Ok... Hmm... I dare you to... kiss Belle!"
    new "Ok... Hmm... Ich traue dir zu... Belle küssen!"

    # say L570 bel
    old "What? But I'm not the one with the dare! It's Billie."
    new "Was? Aber ich bin doch nicht diejenige, die den Wagemutigen sein soll! Das bist du, Billie."

    # say L571 bil
    old "Well, yeah. But this kind of dares are valid too. After all, I'm the one that has to do it."
    new "Na ja, klar. Aber solche Wagemutigkeiten gelten auch. Immerhin bin ich diejenige, die es tun muss."

    # say L572 mik
    old "Yeah! Remember, you have to do it or you're out!"
    new "Klar! Denk dran, du musst es machen, sonst bist du raus!"

    # say L573 bil
    old "Yeah whatever, I'll do it, it's no big deal."
    new "Klar, mach ich, ist ja kein Drama."

    # say L575 bil
    old "Come on, just help me with this... Otherwise I won't be able to continue playing..."
    new "Komm schon, hilf mir einfach dabei... Sonst kann ich das Spiel nicht weiterführen..."

    # say L577 bil
    old "Just come here, close your eyes and think of someone you like."
    new "Komm her, schließ die Augen und denk an jemanden, den du magst."

    # say L578 bil
    old "I'm sure we both are gonna enjoy it."
    new "Ich bin sicher, wir beide werden es genießen."

    # say L590 hin
    old "Ok. Now it's my turn to have a go!"
    new "Okay. Jetzt bin ich dran!"

    # say L592 hin
    old "Mike, truth or dare?"
    new "Mike, Wahrheit oder Pflicht?"

    # say L593 mik
    old "Of course dare."
    new "Natürlich Pflicht."

    # say L594 hin
    old "Well, I dare you to leave and go home."
    new "Na gut, ich trau mich, dass du gehst und nach Hause fährst."

    # say L596 bel
    old "Yeah! That's right, we all had to do our dares. You have to do the same."
    new "Klar! Das gilt für alle, die ihre Wahrheiten oder Aufgaben erfüllen müssen. Du musst das Gleiche tun."

    # say L597 hin
    old "What is it Mike? You can't do it, uhh?"
    new "Was ist los, Mike? Du kannst das doch nicht, oder?"

    # say L598 mik
    old "Of course I can do it! I'll show you!"
    new "Natürlich kann ich das! Ich zeig's euch!"

    # say L615 bil
    old "Yeah, I didn't think he would do it."
    new "Klar, ich dachte ja, er würde es nicht tun."

    # say L617 pla
    old "Hahaha, very good trick Hinn, well done."
    new "Hahaha, sehr guter Trick Hinn, gut gemacht."

    # say L619 bel
    old "Ok, now that he's gone. It's my turn again. [pla] truth or dare?"
    new "Ok, jetzt wo er weg ist. Ich bin wieder dran. [pla] Wahrheit oder Pflicht?"

    # say L620 pla
    old "Hmm, truth."
    new "Hmm, Wahrheit."

    # say L627 pla
    old "You know what? I- I choose dare."
    new "Du weißt was? I- Ich wähle die Herausforderung."

    # say L628 bel
    old "What? No, you've got to answer the question."
    new "Was? Nein, du musst die Frage beantworten."

    # say L629 bil
    old "No, it's fine. In fact, from now on let's play only with 'dares', no more truths."
    new "Nein, ist schon gut. Ab jetzt spielen wir nur noch mit \"Wagnissen\", keine Wahrheiten mehr."

    # say L630 bel
    old "Hmm, ok, if that's how it is. Then I dare you to take your penis out."
    new "Hmm, okay, wenn es so ist. Dann trau dich, deinen Penis rauszunehmen."

    # say L631 pla
    old "W- what? Why do I have to do that?"
    new "W-was? Warum muss ich das tun?"

    # say L632 bel
    old "Well, you can either do that, or answer my question!"
    new "Na dann, entweder du machst das, oder du beantwortest meine Frage!"

    # say L634 pla
    old "Hmm, fine..."
    new "Hmm, gut..."

    # say L643 bel
    old "(What a fucking big cock!)"
    new "Was für eine verdammt große Schwanz!"

    # say L644 pla
    old "Ok, now it's done."
    new "Okay, jetzt ist es fertig."

    # say L651 bil
    old "It's my turn again. And Belle, since you already made [pla] show something..."
    new "Meine Reihe ist wieder dran. Und Belle, da du [pla] schon was gezeigt hast..."

    # say L652 bil
    old "Why don't you show something of your own as well? What about if you take your boobs out?"
    new "Warum zeigst du nicht auch was von dir? Was hältst du davon, wenn du deine Titten rausnimmst?"

    # say L654 pla
    old "Hey, I already did it. You have to fulfill the dare."
    new "Hey, ich hab's schon gemacht. Du musst die Wette einlösen."

    # say L655 bel
    old "Fine. I'll do it."
    new "Okay. Ich mach's."

    # say L686 bel
    old "Ok, since I've done it... It's my turn, Billie! Show us your breasts too."
    new "Ok, da ich es schon gemacht habe... Billie, zeig uns auch deine Brüste."

    # say L687 bil
    old "Ughh, so original..."
    new "Ughh, so originell..."

    # say L715 bil
    old "Then, since there's only one person here that hasn't shown anything. Hinn, I dare you to take your breast out too."
    new "Dann, da hier nur noch eine Person übrig ist, die nichts gezeigt hat. Hinn, ich traue dir zu, auch deine Brust zu zeigen."

    # say L718 hin
    old "I- I... Uhh... I'm sorry guys, I- I can't do it."
    new "I- Ich... Uhh... Tut mir leid, Leute, ich- ich kann das nicht."

    # say L730 pla
    old "Hinn wait!"
    new "Hinn warte!"

    # say L731 bel
    old "No! [pla], just let her go. I think we went a little too far, right now she's a little nervous. Just leave her alone for now."
    new "Nein! [pla], lass sie einfach gehen. Ich glaube, wir sind ein bisschen zu weit gegangen. Im Moment ist sie ziemlich nervös. Lass sie einfach in Ruhe."

    # say L732 pla
    old "But... I think she needs company."
    new "Aber... ich denke, sie braucht Gesellschaft."

    # say L733 bel
    old "Not right now, if you go after her you're just going to make her feel worse."
    new "Nicht jetzt, wenn du ihr nachgehst, machst du es nur noch schlimmer für sie."

    # say L736 bel
    old "Trust me, it's better if you just let it be. You can talk to her later. Right Billie?"
    new "Vertrau mir, es ist besser, wenn du es dabei belässt. Du kannst später mit ihr reden. Stimmt’s, Billie?"

    # say L737 bil
    old "Yeah, what she said."
    new "Klar, wie sie gesagt hat."

    # say L740 pla
    old "Hmm, all right."
    new "Hmm, okay."

    # say L741 bil
    old "Well, I guess we can continue playing then."
    new "Na gut, dann können wir ja weitermachen."

    # say L742 bel
    old "I agree, since we already started playing. I think it's the best we can do."
    new "Ich stimme zu, da wir schon angefangen haben zu spielen. Ich denke, es ist das Beste, was wir tun können."

    # say L743 pla
    old "Yeah fine. Let's do it."
    new "Okay, dann machen wir weiter."

    # say L744 bel
    old "Now, it's your turn to do a dare again [pla]."
    new "Jetzt bist du wieder dran mit einem Wagnis [pla]."

    # say L745 bel
    old "Why don't you suck Billie's boobs?"
    new "Warum saugst du nicht Billies Titten?"

    # say L746 pla
    old "Whoa! Really?"
    new "Wow! Wirklich?"

    # say L747 bil
    old "Well, a dare is a dare, so..."
    new "Na ja, ein Wagnis ist ein Wagnis, also..."

    # say L748 pla
    old "A- all right."
    new "A- also gut."

    # say L767 bil
    old "Hmm, this isn't going to stay like this."
    new "Hmm, das wird sich nicht so einfach ändern."

    # say L770 bil
    old "Belle, since you like contact that much. Why don't you give [pla] a handjob?"
    new "Belle, da du ja so gerne Körperkontakt hast. Warum gibst du [pla] dann nicht einen Handjob?"

    # say L771 bel
    old "W- what? For real?!"
    new "W- was? Im Ernst?!"

    # say L773 bil
    old "That's right."
    new "Das ist richtig."

    # say L774 bel
    old "Ughh, fine, let's do it."
    new "Ughh, gut, lass es uns machen."

    # say L780 bel
    old "My god [pla] your dick is huge! I can't believe you carry this around."
    new "Mein Gott [pla] dein Schwanz ist riesig! Ich kann nicht glauben, dass du das mit dir rumträgst."

    # say L782 bil
    old "Come on, quit stalling and do it."
    new "Komm schon, hör auf zu zögern und mach es."

    # say L783 bel
    old "Yeah, well, here I come."
    new "Na gut, dann komm ich mal."

    # say L796 bel
    old "Ok, I did what you dared me too."
    new "Ok, ich hab gemacht, was du mir getraut hast."

    # say L797 bel
    old "But since you wanted to see that so badly, why don't you give [pla] a blowjob, Billie?"
    new "Da du es dir ja so sehr ansehen wolltest, warum bläst du dann nicht [pla], Billie?"

    # say L798 bil
    old "What's this, copying me again?"
    new "Was ist das, wieder nach mir abzuschreiben?"

    # say L799 bel
    old "What? After you made me do all of that, you can't do it?"
    new "Was? Nachdem du mich das alles hast machen lassen, kannst du es nicht?"

    # say L800 bil
    old "Tsk, of course I can, come on [pla] let's do it!"
    new "Tsk, natürlich kann ich, komm schon [pla] lass es uns tun!"

    # say L810 bil
    old "I still can't believe you pack this much."
    new "Ich kann immer noch nicht glauben, dass du so viel hast."

    # say L811 bel
    old "Are you nervous?"
    new "Bist du nervös?"

    # say L812 bil
    old "Of course not. I was just saying."
    new "Natürlich nicht. Ich hab's doch nur gesagt."

    # say L828 bil
    old "Ok, this has been fun. But what do you say about taking this to the next level?"
    new "Okay, das war lustig. Aber was sagst du dazu, wenn wir das auf die nächste Stufe bringen?"

    # say L830 bel
    old "The next level? Hasn't this been enough?"
    new "Das nächste Level? Reicht das hier nicht schon?"

    # say L831 bil
    old "No, I'm talking about something extreme, How about we go to the haunted house here in town?"
    new "Nein, ich meine was Extremes. Was hältst du davon, wenn wir ins Spukhaus in der Stadt gehen?"

    # say L832 pla
    old "Haunted house?"
    new "Geisterhaus?"

    # say L833 bil
    old "Yeah that's right. There's a house in town with vampires. Why don't we go?"
    new "Klar, genau. Es gibt ein Haus in der Stadt mit Vampiren. Warum gehen wir nicht hin?"

    # say L834 bel
    old "Ohh, you're talking about the old mansion."
    new "Ohh, du meinst das alte Herrenhaus."

    # say L836 pla
    old "B- but you said vampires. Which vampires?"
    new "Aber du hast von Vampiren gesprochen. Welche Vampire?"

    # say L838 bil
    old "There's a legend about that house, that says there are vampires in there."
    new "Es gibt eine Legende über dieses Haus, die besagt, dass dort Vampire wohnen."

    # say L839 bil
    old "All its inhabitants are women, people say that they have been seen kidnapping men, to then suck all of their blood out."
    new "Alle Bewohnerinnen sind Frauen, man sagt, sie hätten Männer entführt, um ihnen dann alles Blut aus dem Körper zu saugen."

    # say L840 bil
    old "And leave them completely dry."
    new "Und lassen sie sie komplett ausgetrocknet zurück."

    # say L842 bil
    old "Besides, it is said that they are all very pale, and apparently they only go out at night. Never in the sunlight. Surely to pick up another victim."
    new "Außerdem heißt es, dass sie alle sehr blass sind und angeblich nur nachts rausgehen. Nie im Sonnenlicht. Bestimmt um ein weiteres Opfer aufzulesen."

    # say L843 bel
    old "Yeah, yeah, yeah. It's super creepy and spooky, let's go!"
    new "Ja, ja, ja. Es ist total gruselig und unheimlich, lass uns gehen!"

    # say L844 pla
    old "Uhh... I- I'm not sure I want to go there."
    new "Uhh... Ich bin mir nicht sicher, ob ich dahin gehen will."

    # say L845 bil
    old "Aww, are you that much of a wuss? Come on, have some guts."
    new "Ach komm, bist du echt so ein Angsthase? Los, zeig mal Rückgrat."

    # say L846 pla
    old "I'm not a wuss... Ok, let's do it then."
    new "Ich bin kein Feigling... Okay, dann machen wir es."

    # say L855 bel
    old "Wow guys, this really feels sinister. It's quite terrifying."
    new "Wow Leute, das fühlt sich echt unheimlich an. Es ist ziemlich beängstigend."

    # say L856 pla
    old "Y-y-yeah, this is very scary. Maybe we should head back."
    new "Y-y-ja, das ist echt gruselig. Vielleicht sollten wir besser zurückgehen."

    # say L857 bil
    old "What? No, we're not doing that. We've gotta keep playing. And it's your turn again [pla]."
    new "Was? Nein, das machen wir nicht. Wir müssen weitermachen. Und es ist wieder deine Reihe [pla]."

    # say L858 bil
    old "And since you are spiderman... I dare you to climb up to the roof."
    new "Und da du Spiderman bist... traust du dich, aufs Dach zu klettern?"

    # say L859 pla
    old "W-what? B-but..."
    new "W-was? A-aber..."

    # say L860 bil
    old "It's a dare, isn't it? We accomplished ours very well."
    new "Das ist eine Herausforderung, oder? Wir haben unsere sehr gut gemeistert."

    # say L861 bil
    old "And you seemed to enjoy those a lot. Didn't you? it would be unfair if you chicken out now. Do it!"
    new "Und du hast das Ganze ja richtig genossen. Oder etwa nicht? Es wäre unfair, wenn du jetzt kneifst. Mach schon!"

    # say L862 pla
    old "Hmph, fine. I'll do it."
    new "Hmpf, gut. Ich mach's."

    # say L863 bil
    old "But use all the suit, even with the mask, just like spiderman."
    new "Aber benutz den ganzen Anzug, inklusive der Maske, genau wie Spiderman."

    # say L864 pla
    old "Really? Hmm, Alright."
    new "Wirklich? Hmm, okay."

    # say L870 bel
    old "That's it! Yes, you're doing well!"
    new "Das ist es! Ja, du machst das gut!"

    # say L873 bil
    old "Keep going! You can't just stop halfway up! You have to make it to the roof!"
    new "Weiter so! Du darfst nicht auf halbem Weg aufhören! Du musst bis zum Dach kommen!"

    # say L876 pla
    old "I know, ugh! I know!"
    new "Ich weiß, ugh! Ich weiß!"

    # say L882 pla
    old "Ok! I made it all the way up! Just wait there, I'm gonna go down again!"
    new "Ok! Ich bin ganz nach oben gekommen! Warte da, ich komm wieder runter!"

    # say L883 bil
    old "Yeah sure! You made it, come down!"
    new "Klar, komm runter! Du hast es geschafft!"

    # say L891 pla
    old "AAAAAAH!!"
    new "AAAAAAAHHH!!"

    # say L895 bil
    old "[pla]! [pla]! Can you hear us [pla]?! Talk to us!"
    new "[pla]! [pla]! Kannst du uns hören [pla]?! Rede mit uns!"

    # say L896 bel
    old "We're going to get some help! Just hang in there!"
    new "Wir holen Hilfe! Halte durch!"

    # say L909 pla
    old "W- what is this? W- where I-?"
    new "W- was ist das? W- wo bin ich?"

    # say L940 pla
    old "Ugh!! My god, what happened? Why does my head hurt so much?"
    new "Ugh!! Mein Gott, was ist passiert? Warum tut mein Kopf so weh?"

    # say L946 lad
    old "Oh, Hello! You're finally awake, I'm glad you woke up. I was thinking that if you didn't, I might have to call an ambulance."
    new "Oh, hallo! Sie sind endlich wach, das freut mich. Ich dachte schon, ich müsste einen Krankenwagen rufen, wenn Sie nicht aufwachen."

    # say L947 pla
    old "Whoa! Ah... W- where am I?"
    new "Werah! Ah... W- wo bin ich?"

    # say L948 lad
    old "Calm down, this is my house. You fell in here yesterday while you were playing on our roof."
    new "Beruhigen Sie sich, das ist mein Haus. Sie sind gestern hier reingefallen, als Sie auf unserem Dach gespielt haben."

    # say L949 pla
    old "Y- your house?"
    new "Y- dein Haus?"

    # say L950 lad
    old "Yes, that's right. Maybe you thought you actually were spiderman?"
    new "Ja, genau. Vielleicht dachtest du, du wärst wirklich Spiderman?"

    # say L952 pla
    old "Oh my God! It's morning already?!"
    new "Oh mein Gott! Es ist schon Morgen?!"

    # say L953 pla
    old "I- I have to go, [mo1rel] must be worried sick about me."
    new "I- Ich muss los, [mo1rel] macht sich bestimmt große Sorgen um mich."

    # say L954 lad
    old "Are you already leaving?"
    new "Sie gehen schon?"

    # say L955 pla
    old "Y- yes, but don't worry, I promise I'll come back to fix your roof."
    new "Y- ja, aber mach dir keine Sorgen, ich verspreche, ich werde wiederkommen, um dein Dach zu reparieren."

    # say L956 lad
    old "Ok, if you say so. Be careful though. You got a big hit there."
    new "Okay, wenn Sie das sagen. Passen Sie aber auf. Sie haben da einen ganz schönen Schlag abbekommen."

    # say L972 mo1
    old "Dear, you're home! Oh my god! You had me so worried. Where were you?!"
    new "Liebling, du bist zu Hause! Oh mein Gott! Du hast mich so besorgt gemacht. Wo warst du?!"

    # say L973 pla
    old "S- sorry [mo1rel]. Me and my friends went trick or treating yesterday after school was over."
    new "S- sorry [mo1rel]. Me und meine Freunde sind gestern nach der Schule zum Trick-or-Treating gegangen."

    # say L974 pla
    old "And after we were done Mike invited me to stay at his house."
    new "Und danach hat Mike mich eingeladen, bei ihm zu bleiben."

    # say L975 mo1
    old "That's not a problem. But why didn't you call to let us know where you were?!"
    new "Das ist kein Problem. Aber warum hast du uns nicht angerufen, um uns zu sagen, wo du bist?!"

    # say L976 pla
    old "I- I guess I just lost track of time and then forgot about it. Sorry [mo1rel] I didn't mean to scare you."
    new "Ich hab wohl die Zeit vergessen und dann hab ich es vergessen. Tut mir leid [mo1rel], ich wollte dich nicht erschrecken."

    # say L977 mo1
    old "Well you did! You're an adult, so you can do whatever you want, but at least call to let me know about this sort of thing."
    new "Na klar hast du das! Du bist ein Erwachsener, kannst machen, was du willst, aber ruf wenigstens an, wenn so was passiert."

    # say L978 pla
    old "You're right, my bad."
    new "Du hast recht, sorry."

    # say L979 mo1
    old "It's ok honey, I'm just happy to see you're safe."
    new "Ist schon gut, Schatz, ich bin einfach froh, dass es dir gut geht."

    # say L980 pla
    old "Thanks [mo1rel]. By the way, I've gotta get ready for school."
    new "Danke [mo1rel]. Übrigens, ich muss mich noch für die Schule fertigmachen."

    # say L985 pla
    old "Ohh, what a crazy day yesterday was. I can't believe we did all that."
    new "Ohh, was für ein verrückter Tag gestern war. Ich kann es kaum glauben, dass wir all das gemacht haben."

    # say L986 pla
    old "I would like to rest a little bit more. But I guess I better get to school. I don't want to give Ms. Mia any more reasons to suspend me."
    new "Ich würde gerne noch ein bisschen länger schlafen. Aber ich schätze, ich sollte besser zur Schule gehen. Ich will Ms. Mia keinen weiteren Grund geben, mich zu suspendieren."

    # say L1113 pla
    old "Hey girls, how are you?"
    new "Hey Mädels, wie geht's euch?"

    # say L1117 bil
    old "Are you really ok? We went asking for assistance but when we came back you weren't there."
    new "Bist du wirklich okay? Wir sind losgezogen, um Hilfe zu holen, aber als wir zurückkamen, warst du nicht mehr da."

    # say L1118 bil
    old "We were very worried because we didn't know where you went."
    new "Wir waren echt besorgt, weil wir nicht wussten, wo du hin bist."

    # say L1119 pla
    old "Yeah, sorry about that. But to be honest I don't know what happened either."
    new "Ja, tut mir leid. Aber ehrlich gesagt, ich habe auch keine Ahnung, was passiert ist."

    # say L1120 pla
    old "All I remember was hitting the ground really hard, and you calling out for me. But then I passed out."
    new "Alles, woran ich mich erinnere, ist, dass ich richtig hart auf dem Boden aufgeschlagen bin und du meinen Namen gerufen hast. Danach bin ich ohnmächtig geworden."

    # say L1121 pla
    old "I imagined it was the lady who moved me."
    new "Ich dachte, es war die Dame, die mich bewegt hat."

    # say L1123 bil
    old "Lady? You're talking about the vampire?!"
    new "Lady? Du redest von der Vampirin?!"

    # say L1124 pla
    old "Uhhh, I- I don't know, I just met her this morning when I woke up, apparently she took care of me."
    new "Uhhh, ich- ich weiß nicht, ich hab sie heute Morgen erst kennengelernt, als ich aufgewacht bin. Scheint, dass sie sich um mich gekümmert hat."

    # say L1125 bel
    old "Whoa! And how was it? Weren't you scared?"
    new "Whoa! Und wie war es? Hast du dich nicht gefürchtet?"

    # say L1126 pla
    old "Me? Not really? I was only surprised, because she wasn't angry. In fact, she was really nice to me."
    new "Mir? Ehrlich gesagt, nein. Ich war nur überrascht, weil sie nicht sauer war. Im Gegenteil, sie war richtig nett zu mir."

    # say L1127 pla
    old "I promised to come back later and fix the damage I did to her roof."
    new "Ich hab versprochen, später wiederzukommen und den Schaden an ihrem Dach zu reparieren."

    # say L1128 bil
    old "Whoa! Well I guess it's better that way."
    new "Wow! Na ja, dann ist es wohl besser so."

    # say L1130 bel
    old "Yeah, after all, you did ruin her roof. So, it's better if you fix it."
    new "Klar, schließlich hast du ihr Dach ruiniert. Also ist es besser, wenn du es reparierst."

    # say L1132 bil
    old "Yeah, I think I went a little overboard with that last dare."
    new "Ja, ich glaube, ich bin bei dem letzten Wagemut ein bisschen über das Ziel hinausgeschossen."

    # say L1133 bil
    old "I promise I'll make it up to you next time we play. Right Belle?"
    new "Ich verspreche, ich mache es beim nächsten Mal wieder gut. Okay, Belle?"

    # say L1134 bel
    old "Yeah, for sure."
    new "Klar, darauf kannst du dich verlassen."

    # say L1135 pla
    old "Well, I didn't think I would want to play that again."
    new "Na, ich dachte, ich würde das nicht noch mal spielen wollen."

    # say L1136 pla
    old "But if it's going to be like you say, then count me in for next time."
    new "Aber wenn es so wird, wie du sagst, dann bin ich dabei beim nächsten Mal."

    # say L1138 bel
    old "Well, we have classes now. See you later."
    new "Wir haben jetzt Unterricht. Bis später."

    # say L1139 pla
    old "Alright, see you girls."
    new "Alles klar, bis später, Mädels."

    # say L1156 hin
    old "G- good morning [pla]. How are you?"
    new "Guten Morgen [pla]. Wie geht es dir?"

    # say L1158 pla
    old "Hey Hinn. I'm fine, thank God I get to see you today."
    new "Hey Hinn. Mir geht's gut, danke. Gott sei Dank sehe ich dich heute."

    # say L1159 pla
    old "Hey, listen, I've been thinking, and I'm sorry about the way things ended up yesterday, me and the girls took it a little too far."
    new "Hey, hör mal, ich hab nachgedacht und es tut mir leid, wie gestern alles gelaufen ist. Kylee und ich, wir sind wohl ein bisschen zu weit gegangen."

    # say L1161 hin
    old "It's ok, actually I wanted to say sorry to you."
    new "Es ist okay, eigentlich wollte ich mich bei dir entschuldigen."

    # say L1162 hin
    old "To be honest, I'm still not used to being that open. It's ok when I'm with you and Dr. Johnson."
    new "Ehrlich gesagt, bin ich noch nicht daran gewöhnt, so offen zu sein. Es ist okay, wenn ich mit dir und Dr. Johnson zusammen bin."

    # say L1163 hin
    old "But if things turn sexual when there's other people around, and watching me, I just freeze."
    new "Aber wenn es sexuell wird und andere Leute sind dabei und gucken, dann friere ich einfach ein."

    # say L1164 hin
    old "And yesterday things got a little too dense for my liking, so I couldn't handle it, and took off."
    new "Und gestern wurde es ein bisschen zu intensiv für meinen Geschmack, da hab ich es nicht mehr ausgehalten und bin abgehauen."

    # say L1165 hin
    old "S- sorry for leaving like that, I hope I didn't ruin your night."
    new "Tut mir leid, dass ich so davongelaufen bin, ich hoffe, ich habe deinen Abend nicht ruiniert."

    # say L1166 pla
    old "No, not at all! You didn't ruin anything."
    new "Nein, überhaupt nicht! Du hast nichts ruiniert."

    # say L1168 pla
    old "Yes, really. I'm just happy to see you're doing fine."
    new "Ja, wirklich. Ich freue mich einfach, dass es dir gut geht."

    # say L1169 hin
    old "Thank you [pla]."
    new "Danke [pla]."

    # say L1170 hin
    old "But... honestly, I don't think I'm that well..."
    new "Aber... ehrlich gesagt, ich glaube nicht, dass es mir so gut geht..."

    # say L1172 hin
    old "Well, I- I've been thinking... maybe I could talk with Dr. Johnson again, take a couple more lessons from her."
    new "Na ja, ich- ich hab drüber nachgedacht... vielleicht könnte ich noch mal mit Dr. Johnson reden, ein paar weitere Lektionen bei ihr nehmen."

    # say L1173 pla
    old "Really? Do you feel you need it?"
    new "Wirklich? Fühlst du, dass du das brauchst?"

    # say L1174 hin
    old "I do. I know she's already helped me a lot. But it can't hurt to keep working on things. There's always room for improvement"
    new "Ich denke schon. Ich weiß, dass sie mir schon viel geholfen hat. Aber es kann nicht schaden, weiter daran zu arbeiten. Es gibt immer Raum für Verbesserungen."

    # say L1176 pla
    old "Hmm, well, if you think it's the best thing for you, I support you completely."
    new "Hmm, wenn du denkst, dass es das Beste für dich ist, unterstütze ich dich voll und ganz."

    # say L1177 hin
    old "Thank you, your support does mean a lot to me. Also, would you come with me? To the sessions? I think it's easier with you there."
    new "Danke, deine Unterstützung bedeutet mir wirklich viel. Und würdest du mitkommen? Zu den Sitzungen? Ich glaube, es ist einfacher, wenn du dabei bist."

    # say L1178 pla
    old "Of course I will, if you need me, I'm more than happy to help you."
    new "Natürlich werde ich das, wenn du mich brauchst, bin ich gerne für dich da."

    # say L1179 hin
    old "Thanks again [pla] I knew I could count on you."
    new "Danke nochmal [pla] Ich wusste, dass ich mich auf dich verlassen kann."

    # say L1181 pla
    old "Oh! Look at the time, I think we better get to class."
    new "Oh! Schau mal auf die Uhr, ich glaube, wir sollten besser in den Unterricht gehen."

    # say L1182 hin
    old "Yeah, if not Ms. Mia will be angry."
    new "Stimmt, sonst wird Ms. Mia sauer."

    # say L1183 pla
    old "You are right. let's go."
    new "Du hast recht. Lass uns gehen."

    # say L1198 pla
    old "Good morning ma'am, how are you?"
    new "Guten Morgen, Frau Mia, wie geht es Ihnen?"

    # say L1199 lad
    old "Ohh! This is a surprise... I didn't think you were gonna come back."
    new "Ohh! Das ist eine Überraschung... Ich dachte, Sie würden nicht mehr wiederkommen."

    # say L1200 pla
    old "No, I couldn't do that. I said I was gonna fix it, and that's what I'll do."
    new "Nein, das konnte ich nicht. Ich hab gesagt, ich werd es reparieren, und das werd ich auch tun."

    # say L1201 lad
    old "Well, isn't that nice?"
    new "Nun, das ist aber nett."

    # say L1202 lad
    old "Truth be told, I had already prepared some tools to fix it myself. But if you're gonna do it I'll lend them to you."
    new "Ehrlich gesagt, hatte ich schon einige Werkzeuge vorbereitet, um es selbst zu reparieren. Aber wenn Sie es machen wollen, leihe ich sie Ihnen gerne."

    # say L1203 pla
    old "Thank you ma'am. I promised it's going to be as good as new when I'm done."
    new "Danke, Ma'am. Ich verspreche, es wird so gut wie neu, wenn ich fertig bin."

    # say L1204 lad
    old "That's really nice of you, thank you."
    new "Das ist wirklich nett von Ihnen, danke."

    # say L1205 pla
    old "So, where are the tools and materials?"
    new "Also, wo sind die Werkzeuge und Materialien?"

    # say L1206 lad
    old "Oh, they're in the next room, in the garage."
    new "Oh, die sind im nächsten Raum, in der Garage."

    # say L1207 lad
    old "The damage isn't that small, so it's going to take you a while to finish completely, you may have to come a couple more times."
    new "Der Schaden ist nicht so gering, es wird eine Weile dauern, bis Sie fertig sind. Sie müssen vielleicht noch ein paar Mal kommen."

    # say L1209 pla
    old "That's fine, it was my fault, so it doesn't matter to me how much time it takes. I'll fix it completely."
    new "Das ist in Ordnung, es war meine Schuld, also spielt es für mich keine Rolle, wie viel Zeit es dauert. Ich werde es komplett reparieren."

    # say L1210 pla
    old "And once again ma'am. I'm sorry for doing that."
    new "Und noch einmal, Frau. Es tut mir leid, dass ich das getan habe."

    # say L1211 lad
    old "It's ok, what's important it's that you came back, and by the way, I'm Alcina Dimitrescu."
    new "Das ist in Ordnung, wichtig ist, dass Sie zurückgekommen sind, und übrigens, ich bin Alcina Dimitrescu."

    # say L1212 pla
    old "Ohh sorry... I haven't told you my name. I'm [pla], nice to meet you."
    new "Ohh sorry... Ich hab dir meinen Namen noch nicht gesagt. Ich bin [pla], freut mich."

    # say L1214 lad
    old "Oh don't worry, nice to meet you too [pla]..."
    new "Oh machen Sie sich keine Sorgen, freut mich auch, Sie kennenzulernen [pla]..."

    # say L1215 lad
    old "I'll be in the next room if you need me. I won't take more of your time and let you start your work..."
    new "Ich werde im nächsten Raum sein, wenn Sie mich brauchen. Ich nehme Ihnen nicht mehr von Ihrer Zeit und lasse Sie mit Ihrer Arbeit beginnen..."

    # say L1216 pla
    old "All right, thank you."
    new "Alles klar, danke."

    # say L1227 lad
    old "Congratulations! You made a lot of progress today."
    new "Herzlichen Glückwunsch! Sie haben heute viel Fortschritte gemacht."

    # say L1228 lad
    old "You're very fast, and it's all very well done."
    new "Sie sind sehr schnell und alles ist sehr gut gemacht."

    # say L1229 pla
    old "Thank you ma'am. I'm glad you like my progress."
    new "Danke, Ma'am. Ich freue mich, dass Ihnen mein Fortschritt gefällt."

    # say L1230 pla
    old "I'm sure if I keep going at this pace it'll be ready very soon."
    new "Ich bin sicher, wenn ich so weitermache, wird es bald fertig sein."

    # say L1231 lad
    old "Sure, I have no doubt about it. Very nice."
    new "Natürlich, ich habe keinen Zweifel daran. Sehr schön."

    # say L1232 pla
    old "Thank you ma'am."
    new "Danke, Ma'am."

    # say L1233 pla
    old "It's a little late, so I think I should be going home. But I'll come back soon."
    new "Es ist ein bisschen spät, also denke ich, ich sollte nach Hause gehen. Aber ich komme bald wieder."

    # say L1234 lad
    old "Oh yeah, don't worry, go home, I'll see you later then."
    new "Oh ja, machen Sie sich keine Sorgen, gehen Sie nach Hause, ich sehe Sie dann später."

    # say L1247 pla
    old "Hmm, this is harder than I expected."
    new "Hmm, das ist schwieriger als ich dachte."

    # say L1248 pla
    old "Sorry for doing so little. But I'm sure next time I'll progress a lot more."
    new "Tut mir leid, dass ich so wenig gemacht habe. Aber ich bin sicher, beim nächsten Mal mache ich viel mehr Fortschritte."

    # say L1249 lad
    old "Well, you didn't do much today, but I understand, it's a big job after all. "
    new "Nun, Sie haben heute nicht viel geschafft, aber ich verstehe, es ist schließlich eine große Aufgabe."

    # say L1250 lad
    old "Don't worry about the progress, I know you'll make it."
    new "Machen Sie sich keine Sorgen um den Fortschritt, ich weiß, dass Sie es schaffen werden."

    # say L1251 pla
    old "Yeah, thank you. I'll come back later and keep working on it."
    new "Ja, danke. Ich komme später wieder und arbeite weiter dran."

    # say L1252 lad
    old "Yes, it's a little late, so you should go home and come another time."
    new "Ja, es ist ein bisschen spät, Sie sollten nach Hause gehen und ein anderes Mal wiederkommen."

    # say L1253 pla
    old "You are right. Thank you."
    new "Du hast recht. Danke."

    # say L1263 pla
    old "Hmm, listen, ma'am before I leave, may I ask you something?"
    new "Hmm, hör mal, Frau, bevor ich gehe, darf ich dich noch was fragen?"

    # say L1264 lad
    old "And what may that be?"
    new "Und was wäre das?"

    # say L1265 pla
    old "Well, I'm a little ashamed to admit this."
    new "Nun, ich schäme mich ein bisschen, das zuzugeben."

    # say L1266 pla
    old "But the reason I crashed into your living room the other day was because a couple of my friends dared me to climb your roof."
    new "Aber der Grund, warum ich in dein Wohnzimmer geplatzt bin, war, dass ein paar Freunde mich getraut haben, auf dein Dach zu klettern."

    # say L1268 lad
    old "And why did they do that?"
    new "Und warum haben sie das getan?"

    # say L1269 pla
    old "Well... it's because there are some rumors about this house being haunted."
    new "Na ja... es gibt Gerüchte, dass dieses Haus gespenstert ist."

    # say L1271 lad
    old "Haunted you say?"
    new "Geisterhaft, sagen Sie?"

    # say L1272 pla
    old "Yeah... I mean, I don't believe them now, but that's what they say."
    new "Ja... ich meine, ich glaube ihnen jetzt nicht, aber so wird es erzählt."

    # say L1273 pla
    old "And, that's not all of it..."
    new "Und, das ist noch nicht alles..."

    # say L1274 lad
    old "It isn't?"
    new "Ist das so? Und was denken Sie? Sehe ich aus wie ein Vampir?"

    # say L1276 pla
    old "Well, apparently there's a story about a group of vampires living here..."
    new "Na, scheinbar gibt es eine Geschichte über eine Gruppe Vampire, die hier leben..."

    # say L1277 lad
    old "Is that so? And what do you think? Do I look like a vampire to you?"
    new "Ist das so? Und was denken Sie? Sehe ich aus wie ein Vampir?"

    # say L1278 pla
    old "O- of course not. I just wanted to apologize for the reason I climbed your roof. Because the rumor isn't true, right?"
    new "O- natürlich nicht. Ich wollte mich nur entschuldigen, warum ich auf dein Dach geklettert bin. Denn das Gerücht stimmt doch nicht, oder?"

    # say L1279 lad
    old "Hehe, of course not. Seriously, kids these days have some imagination."
    new "Hehe, natürlich nicht. Ernsthaft, die Kids heutzutage haben echt Fantasie."

    # say L1280 lad
    old "But now it's not the time for that, it's very late and I think you need to go home."
    new "Aber jetzt ist dafür nicht der richtige Zeitpunkt, es ist sehr spät und ich denke, Sie sollten nach Hause gehen."

    # say L1282 pla
    old "You're right, sorry for bothering you with all of this."
    new "Du hast recht, tut mir leid, dass ich dich damit belästige."

    # say L1283 pla
    old "And don't worry, I'll come soon to keep working on the roof."
    new "Und mach dir keine Sorgen, ich komme bald und arbeite weiter am Dach."

    # say L1284 lad
    old "I really appreciate your help. Have a good night."
    new "Ich schätze Ihre Hilfe sehr. Gute Nacht."

    # say L1301 pla
    old "Hello again lady Dimitrescu. How are you today?"
    new "Hallo wieder, Frau Dimitrescu. Wie geht es dir heute?"

    # say L1302 lad
    old "Hello [pla], I'm fine. You've come to keep working on the roof?"
    new "Hallo [pla], mir geht es gut. Sind Sie gekommen, um weiter am Dach zu arbeiten?"

    # say L1303 pla
    old "Yes ma'am. I'm going to get to it right away. So, I can finish it as soon as I can."
    new "Ja, Frau Dimitrescu. Ich werde gleich damit anfangen. So kann ich es so schnell wie möglich fertigstellen."

    # say L1304 lad
    old "Oh perfect. Well, I'll leave you to it. If you need me, I'm in the room next door."
    new "Oh perfekt. Nun, ich lasse Sie damit allein. Wenn Sie mich brauchen, bin ich im Nebenzimmer."

    # say L1310 pla
    old "Excuse ma'am, but before I go home, there's something else I'd like to ask you about."
    new "Entschuldigen Sie, aber bevor ich nach Hause gehe, gibt es noch etwas, das ich Sie fragen möchte."

    # say L1312 lad
    old "Perhaps another rumor?"
    new "Vielleicht ein weiteres Gerücht?"

    # say L1313 pla
    old "No, no. Nothing like that. It's just... After I fell and passed out. I remember waking up for a brief moment. "
    new "Nein, nein. So was Ähnliches. Es ist nur... Nachdem ich gestürzt und das Bewusstsein verloren habe. Ich erinnere mich daran, für einen kurzen Moment aufgewacht zu sein."

    # say L1314 pla
    old "And I could swear I saw you with someone else, watching me."
    new "Und ich könnte schwören, dass ich dich mit jemand anderem gesehen habe, der mich beobachtet hat."

    # say L1316 lad
    old "S- someone else, heh... What do you mean?"
    new "Jemand anderes, heh... Was meinen Sie damit?"

    # say L1317 pla
    old "Well, I saw two young ladies, they kinda looked like you. But I'm not sure..."
    new "Na ja, ich hab zwei junge Damen gesehen, die irgendwie wie du aussahen. Aber ich bin mir nicht sicher..."

    # say L1318 lad
    old "Hmm, sorry [pla], but I was alone when I picked you up."
    new "Hmm, tut mir leid [pla], aber ich war allein, als ich dich abgeholt habe."

    # say L1319 lad
    old "I think you must have seen some kind of hallucination or something."
    new "Ich denke, Sie müssen eine Art Halluzination gehabt haben oder so."

    # say L1320 pla
    old "Are you sure? It felt so real..."
    new "Bist du sicher? Es fühlte sich so real an..."

    # say L1321 lad
    old "Yes I'm sure. Now, It's getting very late, so you should go home now."
    new "Ja, ich bin sicher. Es wird sehr spät, Sie sollten jetzt nach Hause gehen."

    # say L1322 pla
    old "Hmm, ok. I think you're right. Bye ma'am."
    new "Hmm, okay. Ich denke, du hast recht. Tschau, Ma’am."

    # say L1323 lad
    old "Have a good night, [pla]."
    new "Gute Nacht, [pla]."

    # say L1338 pla
    old "Ok! That's it for today. It's almost done."
    new "Ok! Das war's für heute. Es ist fast fertig."

    # say L1339 lad
    old "Wow! Look at how much you have done already! I think you only need to come back one more time and you will have finished."
    new "Wow! Schauen Sie sich an, wie viel Sie schon geschafft haben! Ich denke, Sie müssen nur noch einmal wiederkommen, dann ist es fertig."

    # say L1340 pla
    old "Thank you ma'am, I'm happy you like how the repairs are going, I also think I only need to come once more, and it'll be ready."
    new "Danke, Ma'am, ich freue mich, dass dir der Fortschritt der Reparaturen gefällt. Ich denke auch, dass ich nur noch einmal kommen muss, und es ist dann fertig."

    # say L1341 lad
    old "I'm astounded at how fast you are, you're a very good worker."
    new "Ich bin beeindruckt, wie schnell Sie arbeiten, Sie sind ein sehr guter Arbeiter."

    # say L1342 pla
    old "Thank you very much!"
    new "Vielen Dank!"

    # say L1343 pla
    old "Well, I think I'll head home. I'll be sure to come back and finish."
    new "Na dann, ich denke, ich gehe mal nach Hause. Ich werde sicher wieder kommen und weitermachen."

    # say L1348 lad
    old "Wait! [pla]"
    new "Warten Sie! [pla]"

    # say L1351 pla
    old "Yes? Is there a problem?"
    new "Ja? Gibt es ein Problem?"

    # say L1352 lad
    old "A problem? No, no, nothing like that, I just wanted to thank you once again for how well the repairs are going."
    new "Ein Problem? Nein, nein, gar nicht, ich wollte Ihnen nur noch einmal danken, wie gut die Reparaturen vorankommen."

    # say L1353 lad
    old "Being completely honest, I didn't think you were actually going to do it. But I'm glad I was wrong."
    new "Ehrlich gesagt, habe ich nicht gedacht, dass Sie es wirklich tun würden. Aber ich freue mich, dass ich mich geirrt habe."

    # say L1354 pla
    old "Well, it's not a problem at all. It was my fault that the roof broke in the first place, I feel like it's only fair that I handle the repairs."
    new "Na klar, das ist überhaupt kein Problem. Es war ja meine Schuld, dass das Dach eingebrochen ist, da ist es nur fair, dass ich die Reparaturen mache."

    # say L1356 lad
    old "Well, I'm happy that you're such an upstanding young man."
    new "Nun, ich freue mich, dass Sie ein so anständiger junger Mann sind."

    # say L1357 lad
    old "And another thing..."
    new "Und noch etwas..."

    # say L1358 pla
    old "Yes?"
    new "Ja?"

    # say L1359 lad
    old "It's about those rumors that you mentioned. The truth is I have actually heard of them as well."
    new "Es geht um die Gerüchte, von denen Sie gesprochen haben. Die Wahrheit ist, ich habe auch davon gehört."

    # say L1360 pla
    old "You knew about them?"
    new "Du wusstest davon?"

    # say L1361 lad
    old "Of course I did. it's difficult not to notice when people look at me and murmur wherever I go."
    new "Natürlich wusste ich davon. Es ist schwer, nicht aufzufallen, wenn die Leute mich anstarren und tuscheln, wo immer ich hingehe."

    # say L1362 lad
    old "But some people are even worse, they come to my house and try to sneak in, or to get pics of the 'vampire lady'."
    new "Aber manche Leute sind noch schlimmer, sie kommen zu meinem Haus und versuchen reinzuschleichen oder Fotos von der \"Vampirfrau\" zu machen."

    # say L1363 lad
    old "It's really stressful, so I was a bit cautious of your intentions at first."
    new "Es ist wirklich stressig, deshalb war ich zu Beginn etwas vorsichtig mit Ihren Absichten."

    # say L1364 pla
    old "Ohh, I- I see, I'm sorry things are like that. It must be so awkward to have to deal with that all the time."
    new "Ohh, ich- ich verstehe, es tut mir leid, dass es so ist. Das muss echt unangenehm sein, das ständig zu ertragen."

    # say L1366 lad
    old "Oh yeah, it's tremendously stressful... Actually, there is a reason why those rumours exist."
    new "Oh ja, es ist unglaublich stressig... Tatsächlich gibt es einen Grund, warum diese Gerüchte existieren."

    # say L1367 pla
    old "Uhh? What do you mean?"
    new "Uhh? Was meinst du damit?"

    # say L1368 lad
    old "Well, as I said, I was a bit cautious of you, but I think you've managed to keep your word."
    new "Nun, wie ich schon sagte, ich war ein bisschen vorsichtig, was Sie betrifft, aber ich denke, Sie haben Ihr Wort gehalten."

    # say L1369 lad
    old "And I realize I haven't been completely honest with you..."
    new "Und ich merke, dass ich Ihnen gegenüber nicht ganz ehrlich war..."

    # say L1370 lad
    old "So, let me tell you the truth; it would be good if at least one person in town knows things as they really are."
    new "Also, lassen Sie mich die Wahrheit sagen; es wäre gut, wenn wenigstens eine Person im Ort die Dinge so kennt, wie sie wirklich sind."

    # say L1373 lad
    old "I suffer from a rare condition in which my body is unable to produce a certain type of amino acid."
    new "Ich leide an einer seltenen Erkrankung, bei der mein Körper nicht in der Lage ist, einen bestimmten Aminosäuretyp zu produzieren."

    # say L1374 lad
    old "Not all of them, but this particular one is very important. Do you know what that means [pla]?"
    new "Nicht alle, aber dieser eine ist sehr wichtig. Wissen Sie, was das bedeutet [pla]?"

    # say L1375 pla
    old "Hmm, not really."
    new "Hmm, nein, wirklich nicht."

    # say L1376 lad
    old "Haha, it means that I'm unable to produce and store a type of protein that the body needs to function properly."
    new "Haha, das bedeutet, dass ich nicht in der Lage bin, ein bestimmtes Protein zu produzieren und zu speichern, das der Körper zum Funktionieren braucht."

    # say L1379 lad
    old "As I said, it's not all of them, I'd be dead if it was like that. But this one is crucial nonetheless."
    new "Wie ich schon sagte, es sind nicht alle, sonst wäre ich tot. Aber dieser ist trotzdem entscheidend."

    # say L1380 lad
    old "Nor am I able to absorb it from the usual sources, like meat and vegetables."
    new "Ich bin auch nicht in der Lage, es aus den üblichen Quellen wie Fleisch und Gemüse zu gewinnen."

    # say L1381 pla
    old "So, does that mean your health is in danger?"
    new "Dann bedeutet das, dass deine Gesundheit in Gefahr ist?"

    # say L1382 lad
    old "Hmm kind of. My body it's very delicate to certain things. For example, I'm unable to go directly into the sunlight."
    new "Hmm, sozusagen. Mein Körper ist sehr empfindlich gegenüber bestimmten Dingen. Zum Beispiel kann ich nicht direkt in den Sonnenschein treten."

    # say L1383 lad
    old "If I did, I would start suffering from strong allergic reactions. So, every time I go outside it has to be during the nighttime."
    new "Wenn ich das täte, würde ich starke allergische Reaktionen bekommen. Deshalb muss ich immer nachts rausgehen."

    # say L1384 pla
    old "Ohh, so, is that why people think you're a vampire?"
    new "Ohh, deshalb denken die Leute, dass du ein Vampir bist?"

    # say L1385 lad
    old "Well, that and my appearance, that's also the result of my disease."
    new "Nun, das und mein Aussehen, das ist auch eine Folge meiner Krankheit."

    # say L1386 lad
    old "This amino acid helps with the creation of melanin, which is what gives colour to the skin."
    new "Dieses Aminosäure hilft bei der Produktion von Melanin, das der Haut ihre Farbe gibt."

    # say L1387 lad
    old "So I'm very white, and my eyes are pale."
    new "Dann bin ich sehr blass, und meine Augen sind hell."

    # say L1388 pla
    old "Oh, I get it now."
    new "Oh, jetzt verstehe ich."

    # say L1389 lad
    old "Yeah, and I understand them, if somebody who looks like me it's only seen outside at night. And well... people talk..."
    new "Ja, und ich verstehe das, wenn jemand wie ich nur nachts draußen gesehen wird. Und na ja... die Leute reden..."

    # say L1391 pla
    old "But, it's not fair, I mean, you can't judge people just because of their appearance."
    new "Aber das ist unfair, ich meine, man kann doch nicht nach dem Aussehen urteilen."

    # say L1392 lad
    old "Well, is not just that. The thing is, since I'm unable to produce this substance, I have to obtain it from a different source."
    new "Nun, es ist nicht nur das. Das Problem ist, da ich diese Substanz nicht selbst produzieren kann, muss ich sie aus einer anderen Quelle beziehen."

    # say L1393 pla
    old "But you said you couldn't get it from food either..."
    new "Aber du hast gesagt, du kannst es auch nicht aus der Nahrung beziehen..."

    # say L1394 lad
    old "That's right, I can't get it from food. But there's something else that can help me."
    new "Das stimmt, ich kann es nicht aus der Nahrung beziehen. Aber es gibt noch etwas anderes, das mir helfen kann."

    # say L1395 lad
    old "You see, for whatever reason I can actually receive the proteins that I need from semen."
    new "Sie sehen, aus irgendeinem Grund kann ich die Proteine, die ich brauche, tatsächlich aus Samen erhalten."

    # say L1397 lad
    old "So, I made a deal with some men from town that were willing to help me. That sustained me for a while..."
    new "Also, ich habe einen Deal mit einigen Männern aus der Stadt gemacht, die bereit waren, mir zu helfen. Das hat mich eine Weile über Wasser gehalten..."

    # say L1398 pla
    old "Ohh, I see..."
    new "Ohh, ich verstehe..."

    # say L1399 lad
    old "But the problem is that for whatever reason, when I touch a man, it has a very strong effect on them."
    new "Aber das Problem ist, dass aus irgendeinem Grund, wenn ich einen Mann berühre, es eine sehr starke Wirkung auf ihn hat."

    # say L1400 pla
    old "They caught the disease too?"
    new "Sie haben die Krankheit auch bekommen?"

    # say L1401 lad
    old "What? No, no, it's not that."
    new "Was? Nein, nein, es ist nicht so."

    # say L1402 lad
    old "What I have is not contagious, but it does cause certain effects on men."
    new "Was ich habe, ist nicht ansteckend, aber es hat bestimmte Auswirkungen auf Männer."

    # say L1404 lad
    old "So anytime one of them helped me. They would be very drained afterwards."
    new "Dann waren sie danach immer sehr erschöpft."

    # say L1405 lad
    old "They ended up looking pale and famished. That's probably where the vampire myth mostly comes from."
    new "Sie sahen blass und ausgehungert aus. Das ist wahrscheinlich der Grund, warum das Vampirmythos entstanden sind."

    # say L1406 pla
    old "Oh, I understand..."
    new "Oh, ich verstehe..."

    # say L1408 lad
    old "And as you know, there is a very large religious community in this town."
    new "Und wie Sie wissen, gibt es in dieser Stadt eine sehr große religiöse Gemeinde."

    # say L1409 lad
    old "Many women got worried that I would hurt their husbands, and even worse, that I would steal them."
    new "Viele Frauen machten sich Sorgen, dass ich ihren Männern wehtun könnte, und noch schlimmer, dass ich sie ihnen wegnehmen würde."

    # say L1410 lad
    old "And seeing how tired the men were after helping me, the rumors began to circulate."
    new "Und da die Männer so erschöpft waren nachdem sie mir geholfen hatten, begannen die Gerüchte zu kursieren."

    # say L1411 pla
    old "I see, I think I now understand better where the legend comes from."
    new "Ich sehe, ich denke, ich verstehe jetzt besser, wo die Legende herkommt."

    # say L1412 pla
    old "But still, your disease is no reason for them to be talking that way about you."
    new "Aber trotzdem ist deine Krankheit kein Grund, so über dich zu reden."

    # say L1413 pla
    old "I'm sorry ma'am, because not only do you have to take care of your condition. You also have to deal with the town's scorn."
    new "Es tut mir leid, Frau, denn Sie müssen nicht nur mit Ihrer Erkrankung leben. Sie müssen sich auch mit dem Spott der Stadt auseinandersetzen."

    # say L1415 lad
    old "It's really nice of you to say that, thank you. But I'm used to it already."
    new "Das ist sehr nett von Ihnen, danke. Aber ich bin schon daran gewöhnt."

    # say L1416 lad
    old "The only thing that really affects me is that I haven't been able to get the protein I need as of late."
    new "Das Einzige, was mich wirklich beeinflusst, ist, dass ich in letzter Zeit nicht genug Protein bekomme."

    # say L1417 pla
    old "Wait, so does that mean nobody is helping you right now? So, how do you meet your protein needs then?"
    new "Warte, das heißt also, niemand hilft dir gerade? Wie erfüllst du dann deine Proteinzufuhr?"

    # say L1418 lad
    old "Hmm, not really, it is true that nobody comes here anymore. "
    new "Hmm, nicht wirklich, es stimmt, dass niemand mehr hierher kommt."

    # say L1419 lad
    old "But I have a deal with the hospital, having a certificate for my condition allows me to receive some semen supplies from them."
    new "Aber ich habe eine Abmachung mit dem Krankenhaus, da ich eine Bescheinigung für meine Erkrankung habe, bekomme ich dort einige Spermienzufuhr."

    # say L1420 lad
    old "It all comes from donation to the sperm bank of the hospital. They give them to me because it's for the treatment of a medical condition."
    new "Es kommt alles von Spenden an die Spermabank des Krankenhauses. Sie geben es mir, weil es für die Behandlung einer medizinischen Erkrankung ist."

    # say L1422 pla
    old "Uhh, I see."
    new "Uhh, ich verstehe."

    # say L1423 lad
    old "It's not perfect, but it kind of works."
    new "Es ist nicht perfekt, aber es funktioniert irgendwie."

    # say L1424 lad
    old "So, you see now? Why do people believe in that legend? And where did those rumours start?"
    new "So, sehen Sie es jetzt? Warum glauben die Leute an diese Legende? Und wo haben diese Gerüchte angefangen?"

    # say L1425 pla
    old "Yeah, I can see it now, but I don't think it's fair!"
    new "Ja, ich sehe es jetzt, aber ich finde es nicht fair!"

    # say L1426 lad
    old "You're right, it isn't, but that's how things are."
    new "Sie haben recht, das ist es nicht, aber so sind die Dinge nun mal."

    # say L1427 lad
    old "And at least now you know the truth and are willing to talk to me."
    new "Und zumindest jetzt wissen Sie die Wahrheit und sind bereit, mit mir zu sprechen."

    # say L1428 pla
    old "Hmm, actually... I don't know if you're ok with me saying this."
    new "Hmm, eigentlich... ich weiß nicht, ob du damit okay bist, dass ich das sage."

    # say L1429 pla
    old "But I think I could do more than just listen to you."
    new "Aber ich denke, ich könnte mehr tun, als dir nur zuzuhören."

    # say L1430 pla
    old "If you're ok with me doing it, I would like to help you."
    new "Wenn du damit einverstanden bist, würde ich dir gerne helfen."

    # say L1432 pla
    old "I mean, you said that what you get from the hospital helps, but is not enough, right?"
    new "Ich meine, du hast gesagt, dass das, was du aus dem Krankenhaus bekommst, hilft, aber nicht genug, oder?"

    # say L1433 pla
    old "So, I want to help you."
    new "Dann will ich dir helfen."

    # say L1435 lad
    old "That's really nice of you to say, but I don't think you understand."
    new "Das ist wirklich nett von Ihnen, aber ich glaube, Sie verstehen das nicht richtig."

    # say L1437 lad
    old "I told you that the men who helped me were very drained after doing it."
    new "Ich habe Ihnen doch gesagt, dass die Männer, die mir geholfen haben, danach sehr erschöpft waren."

    # say L1438 pla
    old "Uhh... I mean, I could just do it in a cup or something and give it to you, right?"
    new "Uhh... Ich meine, ich könnte es auch in ein Glas machen oder so und es dir geben, oder?"

    # say L1439 lad
    old "Not really, you see, that's the problem with the sperm I get from the hospital."
    new "Nicht wirklich, sehen Sie, das ist das Problem mit dem Sperma, das ich vom Krankenhaus bekomme."

    # say L1440 lad
    old "I don't only get what I need from the semen, but also from the contact with the penis."
    new "Ich bekomme nicht nur das, was ich brauche, aus dem Samen, sondern auch durch die Berührung mit dem Penis."

    # say L1441 lad
    old "So if I only receive your semen, I won't be able to extract the necessary amount."
    new "Dann werde ich bei der Rezepturierung der benötigten Menge nicht in der Lage sein, sie vollständig zu extrahieren, wenn ich nur Ihren Samen erhalte."

    # say L1443 pla
    old "Well, I still think we can maybe do a small test and see how we do."
    new "Na ja, ich denke trotzdem, dass wir vielleicht eine kleine Testrunde machen und sehen können, wie es läuft."

    # say L1444 lad
    old "I don't know. Are you sure?"
    new "Ich weiß nicht. Sind Sie sich sicher?"

    # say L1445 pla
    old "Yeah, I think so. I really want to help you in any way I can."
    new "Klar, ich denke auch. Ich will dir auf jeden Fall helfen."

    # say L1446 lad
    old "Good, then I guess we can try testing how it goes."
    new "Gut, dann können wir es ja mal ausprobieren."

    # say L1447 pla
    old "Great, so let's do it."
    new "Super, dann lass es uns machen."

    # say L1448 lad
    old "All right, then take out your pants."
    new "Also gut, dann ziehen Sie Ihre Hose aus."

    # say L1457 lad
    old "I must say I'm impressed young man."
    new "Ich muss sagen, ich bin beeindruckt, junger Mann."

    # say L1458 lad
    old "You got one of the biggest penises I have ever seen."
    new "Sie haben einen der größten Penisse, die ich je gesehen habe."

    # say L1459 lad
    old "It's impressive."
    new "Es ist beeindruckend."

    # say L1460 pla
    old "Uhh... T- thank you ma'am... I guess."
    new "Uhh... D- danke, Ma'am... Ich schätze."

    # say L1472 pla
    old "It's good that you can feel better ma'am. I'll do it again if you need me to."
    new "Es ist gut, dass es dir besser geht. Ich mache es wieder, wenn du mich brauchst."

    # say L1473 lad
    old "Hmm, you seem to be very fine. Normally when I do this with a man, they look very tired afterwards. I wonder if it's because of your age."
    new "Hmm, Sie scheinen sehr gut drauf zu sein. Normalerweise sehen die Männer danach sehr müde aus. Ich frage mich, ob es an Ihrem Alter liegt."

    # say L1475 pla
    old "I don't know what it may be. But I am a little tired. Maybe I should go home for today. But I'll come back to finish the roof."
    new "Ich weiß nicht, was es sein könnte. Aber ich bin ein bisschen müde. Vielleicht sollte ich für heute nach Hause gehen. Aber ich komme wieder, um das Dach zu beenden."

    # say L1476 lad
    old "Ok, just remember to drink a lot of water, and eat as much as you can."
    new "Okay, trink viel Wasser und iss so viel wie möglich."

    # say L1477 lad
    old "You may not look tired, but I'm sure it must've had some effect on you. Be sure to rest."
    new "Sie sehen vielleicht nicht müde aus, aber ich bin sicher, es hat seinen Tribut gefordert. Achten Sie darauf, sich auszuruhen."

    # say L1478 pla
    old "I'll do, don't worry. See you later Lady Dimitrescu."
    new "Ich mach das, mach dir keine Sorgen. Bis später, Lady Dimitrescu."

    # say L1496 pla
    old "Good morning Lady Dimitrescu! I've come to continue repairing the roof."
    new "Guten Morgen Lady Dimitrescu! Ich bin hier, um die Dachreparatur fortzusetzen."

    # say L1497 lad
    old "Good morning."
    new "Guten Morgen."

    # say L1498 lad
    old "You know, I must say, you don't look very tired at all. Even though I'm certain I took a lot from you."
    new "Sie wissen, ich muss sagen, Sie sehen überhaupt nicht müde aus. Obwohl ich sicher bin, dass ich viel von Ihnen verlangt habe."

    # say L1500 pla
    old "(Hmm, I wonder if it's because of the magic power. Maybe it protected me from the effects.)"
    new "Hmm, ich frage mich, ob es an der magischen Kraft liegt. Vielleicht hat sie mich vor den Auswirkungen geschützt."

    # say L1501 pla
    old "I don't really know what to tell you, I actually don't feel bad at all."
    new "Ich weiß nicht so recht, was ich dir sagen soll, ich fühle mich eigentlich gar nicht schlecht."

    # say L1502 lad
    old "This is a surprise. Are you sure you're ok to work on the roof today?"
    new "Das ist eine Überraschung. Sind Sie sich sicher, dass Sie heute auf dem Dach arbeiten können?"

    # say L1504 pla
    old "Yes, don't worry, I feel great, I'm going to get to it right away. So, I can finish it as soon as I can."
    new "Ja, mach dir keine Sorgen, ich fühle mich super und fange gleich damit an. Dann kann ich es so schnell wie möglich fertigstellen."

    # say L1517 lad
    old "This is great! You really did it! Thank you so much, it's fantastic that you put in all this effort. "
    new "Das ist großartig! Sie haben es wirklich geschafft! Vielen Dank, es ist fantastisch, dass Sie so viel Mühe investiert haben."

    # say L1518 lad
    old "It looks even better than it was before."
    new "Es sieht sogar noch besser aus als vorher."

    # say L1519 pla
    old "I'm happy you like it ma'am. It makes all of that effort worth it."
    new "Ich freue mich, dass es dir gefällt, Lad. Es macht die ganze Arbeit wert."

    # say L1520 lad
    old "I don't know how to repay you."
    new "Ich weiß gar nicht, wie ich mich revanchieren soll."

    # say L1521 pla
    old "Oh no, you don't need to pay me or anything. After all, I did the initial damage."
    new "Oh nein, du musst mir nichts bezahlen oder so. Immerhin habe ich den Schaden angerichtet."

    # say L1522 lad
    old "Well, with this you have more than made up for it. Thanks again [pla]."
    new "Mit dem hast du mehr als wiedergutmachen. Danke nochmal [pla]."

    # say L1523 pla
    old "Once again, I'm sorry for damaging your roof, and thank you for your patience. This took a while, but you never got angry with me."
    new "Noch einmal, es tut mir leid, dass ich dein Dach beschädigt habe, und danke für dein Verständnis. Das hat eine Weile gedauert, aber du bist nie sauer auf mich geworden."

    # say L1525 lad
    old "Ohh, I wouldn't get angry."
    new "Ohh, ich würde mich nicht aufregen."

    # say L1526 lad
    old "As I told you, at this point I'm used to people just trying to take a peek into my house, so I was just annoyed when it happened"
    new "Wie ich Ihnen schon sagte, bin ich inzwischen daran gewöhnt, dass Leute versuchen, einen Blick in mein Haus zu werfen. Deshalb war ich nur leicht genervt, als es passierte."

    # say L1527 lad
    old "But you've proven to me that you're a stand up young man. I'm happy I got to meet you."
    new "Aber Sie haben mir bewiesen, dass Sie ein anständiger junger Mann sind. Ich freue mich, Sie kennengelernt zu haben."

    # say L1528 pla
    old "Thank you ma'am, if there's anything else I can do for you, please tell me. I'm more than happy to do it."
    new "Danke, Frau. Wenn ich noch etwas für Sie tun kann, sagen Sie es mir bitte. Ich bin mehr als bereit, Ihnen zu helfen."

    # say L1529 lad
    old "Well... Now that you mention it, there might be..."
    new "Nun ja... Da Sie es erwähnen, da wäre tatsächlich etwas..."

    # say L1530 pla
    old "Really? If that's the case, please tell me. I'll do my best to help you."
    new "Wirklich? Wenn das so ist, sag es mir. Ich werde mein Bestes tun, um dir zu helfen."

    # say L1531 lad
    old "You see, since you don't seem to be at all affected about the help you already gave me. I was wondering if I can ask for your help again."
    new "Sie sehen, da Sie überhaupt nicht besorgt über die Hilfe wirken, die Sie mir bereits geleistet haben. Ich fragte mich, ob ich noch einmal um Ihre Hilfe bitten kann."

    # say L1532 lad
    old "But this time it might be a little different."
    new "Aber diesmal könnte es etwas anders sein."

    # say L1534 pla
    old "Different? How?"
    new "Anders? Wie?"

    # say L1535 lad
    old "Let me explain, I can assimilate a lot through my digestive system, but the most efficient way of taking in the protein content is through my uterus."
    new "Lassen Sie mich erklären, ich kann viel durch mein Verdauungssystem aufnehmen, aber die effizienteste Art, den Proteingehalt zu absorbieren, ist durch meine Gebärmutter."

    # say L1536 lad
    old "Because that way my body can absorb it better."
    new "Weil auf diese Weise kann mein Körper es besser aufnehmen."

    # say L1537 pla
    old "Wow, does that mean you have to have sex with me?"
    new "Wow, bedeutet das, dass du mit mir schlafen musst?"

    # say L1538 lad
    old "Well, only if you are okay with that, of course."
    new "Nun, nur wenn Sie damit einverstanden sind, natürlich."

    # say L1540 pla
    old "Hmm... Well, if that actually helps you, and it's better for you, sure."
    new "Hmm... Na ja, wenn das dir wirklich hilft und es für dich besser ist, klar."

    # say L1541 pla
    old "After all, I did promise I would help you. didn't I?"
    new "Immerhin habe ich dir versprochen, dir zu helfen, oder?"

    # say L1542 lad
    old "Perfect! Thank you so much!"
    new "Perfekt! Vielen Dank!"

    # say L1543 lad
    old "Hmm, come with me to the stairs..."
    new "Hmm, kommen Sie mit mir die Treppe hinunter..."

    # say L1559 lad
    old "That was fantastic, thank you! You have no idea how much you help me."
    new "Das war fantastisch, danke! Sie haben keine Ahnung, wie sehr Sie mir helfen."

    # say L1560 pla
    old "I'm happy to help... and to be honest I enjoyed it too."
    new "Ich freue mich, zu helfen... und ehrlich gesagt, ich habe es auch genossen."

    # say L1561 lad
    old "It's very interesting that you don't get tired at all doing this with me."
    new "Es ist sehr interessant, dass du das mit mir gar nicht müde wirst."

    # say L1562 lad
    old "Maybe that could be of help..."
    new "Vielleicht könnte das von Vorteil sein..."

    # say L1563 pla
    old "Uhh, what do you mean?"
    new "Uhh, was meinst du damit?"

    # say L1564 lad
    old "Well, there's something I must let you know."
    new "Nun, da ist etwas, das ich Ihnen sagen muss."

    # say L1567 lad
    old "Do you remember what you told me about the night you fell in here? That you saw me with two other girls?"
    new "Erinnern Sie sich daran, was Sie mir über die Nacht erzählt haben, in der Sie hier reingefallen sind? Dass Sie mich mit zwei anderen Mädchen gesehen haben?"

    # say L1568 pla
    old "Yeah, the girls from my dream."
    new "Klar, die Mädchen aus meinem Traum."

    # say L1570 lad
    old "Well, actually they're my daughters. Or at least that's what I call them."
    new "Nun, eigentlich sind es meine Töchter. Oder zumindest nenne ich sie so."

    # say L1571 lad
    old "You see, years ago I found out I'm not the only person with my condition."
    new "Sie sehen, vor Jahren habe ich herausgefunden, dass ich nicht der Einzige mit meiner Bedingung bin."

    # say L1572 lad
    old "There are some other people, and I decided to help them. That's why I have this mansion, to receive people like me, and give them a hand."
    new "Es gibt noch andere Menschen, und ich habe mich entschieden, ihnen zu helfen. Deshalb habe ich dieses Anwesen, um Menschen wie mir Unterschlupf zu geben und ihnen eine Hand zu reichen."

    # say L1573 pla
    old "Really? So, you live with several people here? I haven't seen them."
    new "Wirklich? Also lebst du hier mit mehreren Leuten? Ich habe sie noch nicht gesehen."

    # say L1574 lad
    old "Right now it's only me and my two daughters. With the years some have come and go."
    new "Im Moment bin ich nur noch mit meinen beiden Töchtern hier. Im Laufe der Jahre sind einige gekommen und wieder gegangen."

    # say L1575 lad
    old "We communicate with each other every time anyone finds anything that can help us."
    new "Wir kommunizieren miteinander, wann immer jemand etwas findet, das uns helfen kann."

    # say L1576 pla
    old "Oh, it's a very nice gesture of you that you take people in and help them. You really are a good person."
    new "Oh, es ist sehr nett von dir, dass du Menschen aufnimmst und ihnen hilfst. Du bist wirklich ein guter Mensch."

    # say L1578 lad
    old "Thank you, I'm glad you think that about me."
    new "Danke, ich freue mich, dass Sie das so sehen."

    # say L1579 lad
    old "And yeah, we help each other cope with the condition. And since it's such a rare thing, it's really useful that we are all close to each other."
    new "Und ja, wir helfen uns gegenseitig, damit wir mit der Bedingung besser zurechtkommen. Da es so selten ist, ist es wirklich nützlich, dass wir alle in der Nähe sind."

    # say L1580 lad
    old "And you see, since you've now been able to help me twice, and don't seem to be affected..."
    new "Und Sie sehen, da Sie mir jetzt schon zweimal geholfen haben und nicht davon betroffen zu sein scheinen..."

    # say L1581 lad
    old "I was wondering if you could also help my two daughters."
    new "Ich dachte, Sie könnten meinen beiden Töchtern auch helfen."

    # say L1583 pla
    old "Oh! I see."
    new "Oh! Ich verstehe."

    # say L1584 lad
    old "I would love it if you could. They could really use your help to improve their health."
    new "Ich würde es sehr schätzen, wenn Sie das könnten. Sie könnten wirklich Ihre Hilfe gebrauchen, um ihre Gesundheit zu verbessern."

    # say L1585 pla
    old "Well, I think that if I really did help you treat your condition. I don't see why it couldn't do it for you daughters."
    new "Na ja, ich denke, wenn ich dir wirklich bei deiner Behandlung helfe, sehe ich nicht ein, warum ich das nicht auch für deine Töchter tun könnte."

    # say L1586 lad
    old "You're an angel. Then I'll talk to them, so that you can help them as soon as possible."
    new "Sie sind ein Engel. Dann spreche ich mit ihnen, damit Sie sie so schnell wie möglich behandeln können."

    # say L1587 lad
    old "Is that ok with you?"
    new "Ist das in Ordnung für Sie?"

    # say L1589 lad
    old "All right, have a good night [pla]."
    new "Alles klar, eine gute Nacht [pla]."

    # say L1590 pla
    old "Good night to you too, Lady Dimitrescu."
    new "Gute Nacht auch dir, Lady Dimitrescu."

    # say L1613 pla
    old "Good morning ma'am, I'm here to help you as we talked before."
    new "Guten Morgen, ich bin hier, um Ihnen zu helfen, wie wir besprochen haben."

    # say L1614 lad
    old "Good morning. I'm happy to see that you actually came."
    new "Guten Morgen. Ich freue mich, dass Sie tatsächlich gekommen sind."

    # say L1615 lad
    old "Allow me to introduce you to my daughters. These are Bela and Daniela."
    new "Erlauben Sie mir, Sie meinen Töchtern vorzustellen. Das sind Bela und Daniela."

    # say L1616 lad
    old "This is [pla] he's the one I've told you about and has come to help us with our condition."
    new "Das ist [pla], er ist der, von dem ich euch erzählt habe und der uns bei unserer Bedingung helfen wird."

    # say L1618 bela
    old "H- hi. I'm Bela, nice to meet you."
    new "H- hallo. Ich bin Bela, freut mich, Sie kennenzulernen."

    # say L1620 dan
    old "Hello, I'm Daniela, mother has told us about you, and what you're able to do for us. Thank you very much for coming."
    new "Hallo, ich bin Daniela, Mutter hat uns von Ihnen erzählt und was Sie für uns tun können. Vielen Dank, dass Sie gekommen sind."

    # say L1621 pla
    old "N- nice meeting you. I'm [pla], happy to be of help."
    new "N- nett, dich kennenzulernen. Ich bin [pla], freue mich, helfen zu können."

    # say L1622 lad
    old "Well, now that the introductions are over, I think it's best if we start."
    new "Nun, da wir uns kennengelernt haben, denke ich, es ist am besten, wenn wir anfangen."

    # say L1623 pla
    old "Uhh... Right now? And just like that?"
    new "Uhh... Gerade jetzt? Und einfach so?"

    # say L1624 lad
    old "Well, have in mind my daughters really needs it, and we use to do it in the past with other guys..."
    new "Nun, behalten Sie im Hinterkopf, dass meine Töchter es wirklich brauchen, und wir haben es in der Vergangenheit schon mit anderen Männern getan..."

    # say L1625 lad
    old "So, don't worry, just relax, and let us do all for you."
    new "Also, machen Sie sich keine Sorgen, entspannen Sie sich einfach und lassen Sie uns alles für Sie tun."

    # say L1633 lad
    old "Mmmm, look at that, you're already in the mood for it..."
    new "Mmmm, sieh dir das an, du bist schon bereit dafür..."

    # say L1634 dan
    old "Oh wow! Look at what you're packing there."
    new "Oh wow! Schau mal, was du da mitbringst."

    # say L1636 lad
    old "Daniela darling, please, you don't have to be this forward."
    new "Daniela, Liebling, bitte, du musst nicht so direkt sein."

    # say L1637 bela
    old "But mother, it is true that's an impressive size."
    new "Aber Mutter, es stimmt doch, dass das eine beeindruckende Größe ist."

    # say L1638 lad
    old "Hehe, we can't deny that..."
    new "Hehe, das können wir nicht leugnen..."

    # say L1639 lad
    old "But remember, we're doing this for a reason, so control yourselves."
    new "Aber denkt daran, wir tun das aus einem Grund, also beherrscht euch."

    # say L1640 dan
    old "Yes, mother."
    new "Ja, Mutter."

    # say L1642 lad
    old "Now, I think we've talked enough."
    new "Nun, ich denke, wir haben genug geredet."

    # say L1643 lad
    old "Are you ready [pla]?"
    new "Sind Sie bereit [pla]?"

    # say L1662 lad
    old "By the way, how are you feeling [pla]?"
    new "Übrigens, wie fühlen Sie sich [pla]?"

    # say L1663 pla
    old "Well, to be honest I'm a little tired. But it's nothing a nap and some food won't fix. I'll be ok."
    new "Na ja, ehrlich gesagt bin ich ein bisschen müde. Aber das wird eine kleine Pause und was zu essen schon wieder in Ordnung bringen. Mir geht's gut."

    # say L1664 lad
    old "I must admit your endurance is astounding."
    new "Ich muss zugeben, Ihre Ausdauer ist beeindruckend."

    # say L1665 lad
    old "But I'm happy you're fine."
    new "Aber ich freue mich, dass es Ihnen gut geht."

    # say L1666 pla
    old "And I'm happy I can be of help to you all."
    new "Und ich freue mich, dass ich euch allen helfen kann."

    # say L1670 dan
    old "Honestly, our health had been going down due to not being able to get enough semen for all three of us."
    new "Ehrlich gesagt, unser Gesundheitszustand war auf dem Rückweg, weil wir nicht genug Sperma für uns drei bekommen konnten."

    # say L1671 dan
    old "And even if the hospital donated more, it's not the same thing as receiving it directly from a person."
    new "Und selbst wenn das Krankenhaus mehr spendet, ist es nicht dasselbe wie es direkt von einer Person zu bekommen."

    # say L1672 pla
    old "Hmm, does that mean that if no one else helps you, you'll be in trouble again?"
    new "Hmm, bedeutet das, wenn niemand anders euch hilft, seid ihr wieder in Schwierigkeiten?"

    # say L1673 lad
    old "Sadly it does."
    new "Leider ja."

    # say L1674 pla
    old "Then I'll be sure to come back again and help you. I'll do it as many times as you need me to."
    new "Dann werde ich sicherstellen, dass ich wieder zurückkomme und dir helfe. So oft, wie du es brauchst."

    # say L1676 lad
    old "Hmm are you sure? I understand that one time is something. But if you do too many times it might affect you."
    new "Hmm, sind Sie sich sicher? Ich verstehe, dass einmal etwas Besonderes ist. Aber wenn Sie es zu oft tun, könnte es Sie beeinträchtigen."

    # say L1677 pla
    old "I think I could keep helping you some more, given that so far I haven't had any negative reaction."
    new "Ich denke, ich könnte dir weiterhelfen, da ich bisher keine negativen Reaktionen hatte."

    # say L1678 pla
    old "So you can count on me."
    new "Dann kannst du dich auf mich verlassen."

    # say L1679 lad
    old "Aww, you're an angel. Well then, when we need it, we'll be sure to call you on."
    new "Ach, Sie sind ein Engel. Na dann, wenn wir es brauchen, werden wir sicherlich auf Sie zählen."

    # say L1698 lad
    old "Oh, hi [pla], it's always nice to see you."
    new "Oh, hallo [pla], es ist immer schön, Sie zu sehen."

    # say L1699 lad
    old "How can I help you today?"
    new "Wie kann ich Ihnen heute helfen?"

    # menu L1703 
    old "Help them again"
    new "Sie wieder helfen"

    # say L1705 pla
    old "Well, I have been thinking about helping you again."
    new "Na ja, ich habe darüber nachgedacht, dir wieder zu helfen."

    # say L1706 lad
    old "Oh, have you come help us with our protein needs?"
    new "Oh, sind Sie gekommen, um uns bei unseren Proteinzufuhr zu helfen?"

    # say L1707 pla
    old "That's right, I thought you might need it."
    new "Das stimmt, ich dachte, du könntest es gebrauchen."

    # say L1708 lad
    old "That's perfect, you came at just the right moment."
    new "Das ist perfekt, Sie sind genau zur richtigen Zeit gekommen."

    # say L1709 lad
    old "Let me call the girls."
    new "Lassen Sie mich die Mädchen rufen."

    # say L1728 bela
    old "Hi [pla]! How are you?"
    new "Hi [pla]! Wie geht es Ihnen?"

    # say L1729 pla
    old "I'm fine, thank you, I came to see if you needed my help today."
    new "Mir geht es gut, danke. Ich bin gekommen, um zu sehen, ob du heute meine Hilfe brauchst."

    # say L1730 dan
    old "Yeah, mother told us."
    new "Ja, Mutter hat uns das gesagt."

    # say L1764 pla
    old "What?! Oh no, sorry, I was just a little distracted."
    new "Was?! Oh nein, sorry, ich war nur ein bisschen abgelenkt."

    # say L1766 lad
    old "Hmm, I see, well, be careful on the way back."
    new "Hmm, ich sehe, na ja, passen Sie auf dem Weg zurück auf."

    # say L1767 pla
    old "Yes ma'am, bye."
    new "Ja, Ma'am, tschüss."

    # say L1770 pla
    old "Oh, sorry, I was just passing by."
    new "Oh, entschuldige, ich war nur gerade vorbei."

    # say L1771 lad
    old "Hmm, I see, well, make sure you come when you have some free time."
    new "Hmm, ich sehe, na gut, stellen Sie sicher, dass Sie kommen, wenn Sie etwas freie Zeit haben."

    # say L1772 pla
    old "Yes ma'am, of course. See you later."
    new "Ja, klar. Bis später."

    # say L1773 lad
    old "Bye, take care."
    new "Auf Wiedersehen, passen Sie auf sich auf."


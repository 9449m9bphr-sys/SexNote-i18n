# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Institute.rpy
translate german strings:

    # say L15 pla
    old "I should go to the garage to talk with Brixxida first."
    new "Ich sollte zuerst ins Autohaus gehen, um mit Brixxida zu reden."

    # say L53 hin
    old "Well, she is in the classroom right now. You should go and show her."
    new "Na ja, sie ist gerade im Klassenzimmer. Du solltest zu ihr gehen und es ihr zeigen."

    # say L55 pla
    old "Ok. Doing it now."
    new "Okay. Mach ich jetzt."

    # say L174 pla
    old "Nothing much, it’s just that I haven’t seen you when I’ve gone to your home to do the repairs on the bathroom."
    new "Nichts Besonderes, es ist nur so, dass ich dich nicht zu Hause angetroffen habe, als ich die Badezimmerreparaturen machen wollte."

    # say L175 hin
    old "Yeah, I’m sorry about that."
    new "Ja, tut mir leid dafür."

    # say L176 hin
    old "This whole extracurricular work has been keeping me busy."
    new "Dieser ganze Nachhilfejob hält mich echt auf Trab."

    # say L177 hin
    old "But it’s supposed to count for extra credit for college, so, I guess that’s alright."
    new "Aber es zählt ja als Zusatzpunkte fürs College, also ist es okay."

    # say L178 pla
    old "Of course, of course, I totally get it."
    new "Natürlich, natürlich, ich verstehe total."

    # say L179 hin
    old "I’ll make it up to you once I’m done with all of this."
    new "Ich mache es wieder gut, sobald ich damit fertig bin."

    # say L180 hin
    old "We’ll also have some time to ourselves once you’re done with the bathroom."
    new "Wir haben dann auch Zeit für uns, wenn du mit dem Bad fertig bist."

    # say L181 pla
    old "Yeah, I guess I better hurry to finish with that. The sooner the better."
    new "Klar, ich sollte mich besser beeilen. Je schneller, desto besser."

    # say L182 hin
    old "It’s very kind of you to do that for us."
    new "Das ist sehr nett von dir, das für uns zu tun."

    # say L183 pla
    old "No problem, it’s rather easy."
    new "Kein Problem, es ist ziemlich einfach."

    # say L184 pla
    old "By the way, I think I’ll go work on that right now."
    new "Dann mach ich mich mal daran, gleich damit zu beginnen."

    # say L185 pla
    old "See you later Hinn."
    new "Bis später, Hinn."

    # say L187 hin
    old "Sure, see you later."
    new "Klar, bis später."

    # say L207 pla
    old "Do you have a therapy appointment today with Dr. Johnson?"
    new "Hast du heute eine Therapiesitzung bei Dr. Johnson?"

    # say L209 hin
    old "No, actually I think we should work on the class project today."
    new "Nein, eigentlich denke ich, wir sollten uns heute auf das Klassenprojekt konzentrieren."

    # say L211 pla
    old "You are right, we have work to do."
    new "Du hast recht, wir müssen arbeiten."

    # say L213 hin
    old "If we make a good progress I could set an appointment for tomorrow."
    new "Wenn wir gut vorankommen, könnte ich für morgen einen Termin vereinbaren."

    # say L215 pla
    old "Always that responsible. That sounds good to me."
    new "Immer so verantwortungsbewusst. Das klingt gut für mich."

    # say L218 hin
    old "Hehehe... Great, see you in my house."
    new "Hehehe... Toll, bis zu mir nach Hause."

    # say L220 pla
    old "Perfect. See you then."
    new "Perfekt. Bis dahin."

    # say L254 bel
    old "Did you start to work on your project?"
    new "Hast du schon mit deinem Projekt angefangen?"

    # say L256 pla
    old "Well, I talked to Hinn, I think we're going to start this afternoon..."
    new "Na, ich hab mit Hinn geredet, glaub ich, wir fangen heute Nachmittag an..."

    # say L258 bel
    old "Lucky you, I got paired with that asshole Mike this time. I don't know how everything is going to work out..."
    new "Glückspilz, ich bin mit diesem Arschloch Mike dran. Keine Ahnung, wie das alles laufen soll..."

    # say L260 pla
    old "Don't worry, Mike is good whenever he tries."
    new "Mach dir keine Sorgen, Mike ist gut, wann immer er es versucht."

    # say L262 bel
    old "Hmm... I sure hope so..."
    new "Hmm... ich hoffe wirklich, dass es klappt..."

    # say L264 pla
    old "Ok... Bell, I have to go to meet with Hinn. Bye."
    new "Okay... Bell, ich muss los, um mich mit Hinn zu treffen. Tschüss."

    # say L266 bel
    old "See you later, [pla]..."
    new "Bis später, [pla]..."

    # say L274 bel
    old "Hey, [pla]! How did it go with your project?"
    new "Hey, [pla]! Wie war's mit deinem Projekt?"

    # say L276 pla
    old "Actually, great! Hinn is quite good and she has taught me a lot..."
    new "Eigentlich super! Hinn ist ziemlich gut und hat mir viel beigebracht..."

    # say L278 bel
    old "Hmm... Right, Hinn is a pretty nerd... Mine is an ugly asshole..."
    new "Hmm... Stimmt, Hinn ist ziemlich ein Streber... Mein Typ ist ein hässlicher Arsch..."

    # say L280 pla
    old "It can't be that bad ..."
    new "Kann nicht so schlimm sein..."

    # say L282 bel
    old "It can't be that bad?... We went to my house to study and he tried to look in my underwear drawer... Three times!"
    new "Kann nicht so schlimm sein?... Wir sind zu mir nach Hause gegangen, um zu lernen, und er hat versucht, in meine Unterwäscheschublade zu gucken... Dreimal!"

    # say L284 pla
    old "Really?... Uhh weird..."
    new "Echt jetzt?... Uhh seltsam..."

    # say L286 bel
    old "Tell me about it... I have to do everything by myself."
    new "Erzähl mir was... Ich muss alles alleine machen."

    # say L288 pla
    old "Too bad... Fortunately, you are smart and you can actually do it alone. I really couldn't without help."
    new "Schade... Aber zum Glück bist du klug und kannst es tatsächlich alleine schaffen. Ich könnte das ohne Hilfe echt nicht."

    # say L290 bel
    old "... Seriously, every time I see Mike, I just want to kill him..."
    new "... Ernsthaft, jedes Mal, wenn ich Mike sehe, könnte ich ihn umbringen..."

    # say L292 pla
    old "Damn... Well, Bell, I have to go. I will see you later..."
    new "Scheiße... Na ja, Bell, ich muss los. Bis später..."

    # say L294 bel
    old "See you later, [pla]!"
    new "Bis später, [pla]!"

    # say L297 bel
    old "Hey, [pla]! How's it going?"
    new "Hey, [pla]! Wie läuft's?"

    # say L299 pla
    old "Hi Belle, I'm doing great!"
    new "Hi Belle, es geht mir super!"

    # say L300 pla
    old "A little busy with school work and stuff, you know."
    new "Ein bisschen beschäftigt mit Schule und so, weißt du."

    # say L302 bel
    old "Yeah, I get it."
    new "Klar, ich verstehe."

    # say L303 pla
    old "How about you?"
    new "Und du?"

    # say L305 bel
    old "Well, I guess I'm ok."
    new "Na ja, ich schätze, ich bin okay."

    # say L307 bel
    old "Lately my mom has been a little intense."
    new "Lately my mom has been a little intense. → Kürzlich ist meine Mom ein bisschen intensiv geworden."

    # say L308 bel
    old "She's always coming and going from home."
    new "Sie ist ständig zu Hause und wieder weg."

    # say L310 bel
    old "And every time she's home she wants to see me or talk to me "
    new "Und jedes Mal, wenn sie zu Hause ist, will sie mich sehen oder mit mir reden."

    # say L312 pla
    old "Hmm... I can imagine how annoying it must be."
    new "Hmm... Ich kann mir vorstellen, wie nervig das sein muss."

    # say L314 bel
    old "I guess I'll have to deal with it."
    new "Ich schätze, ich muss damit leben."

    # say L315 bel
    old "She's been handling a lot because of her job."
    new "Sie hat viel durchgemacht wegen ihrer Arbeit."

    # say L316 bel
    old "So, I guess that when the whole thing is over she'll be right back to normal."
    new "Dann wird sie, wenn alles vorbei ist, wahrscheinlich wieder die Alte sein."

    # say L317 pla
    old "Yeah, I'm sure she will."
    new "Klar, ich bin mir sicher, dass sie wieder zur Normalität zurückfindet."

    # say L318 pla
    old "Hey, I have to run, but I'll see you later."
    new "Hey, ich muss los, aber ich seh dich später."

    # say L320 bel
    old "Sure, see you."
    new "Klar, bis später."

    # say L323 pla
    old "Hi Belle, good morning."
    new "Hi Belle, guten Morgen."

    # say L326 bel
    old "How are you?"
    new "Wie geht es dir?"

    # say L327 pla
    old "I'm ok, how are you doing?"
    new "Ich bin okay, wie geht's dir?"

    # say L329 bel
    old "Well, I'm fine I think."
    new "Na, ich denke, ich bin okay."

    # say L330 bel
    old "The situation has been tense with my mom since our fight."
    new "Die Situation mit meiner Mom ist seit unserem Streit ziemlich angespannt."

    # say L332 bel
    old "So we're not actually talking right now."
    new "Dann reden wir also im Moment nicht miteinander."

    # say L334 bel
    old "But other than that I'm doing well."
    new "Aber ansonsten geht es mir gut."

    # say L335 bel
    old "Since I moved with Amorette, and I've been able to work from her home."
    new "Seit ich mit Amorette gezogen bin, kann ich von ihrem Haus aus arbeiten."

    # say L337 bel
    old "So on that end, everything's fine."
    new "Dann ist ja alles gut."

    # say L339 pla
    old "Ok, I see, well, I guess that's fine."
    new "Ok, ich verstehe, dann ist ja alles gut."

    # say L340 pla
    old "As long as you're ok, I suppose everything's alright."
    new "Solange es dir gut geht, ist alles in Ordnung, schätze ich."

    # say L342 bel
    old "Yeah."
    new "Klar."

    # say L343 pla
    old "Alright, it was nice to see you. See you later, Belle."
    new "Alles gut, war schön, dich zu sehen. Bis später, Belle."

    # say L345 bel
    old "Sure. See you later, [pla]."
    new "Klar. Bis später, [pla]."

    # say L375 pla
    old "Uhh... Nothing. I was just heading out. Sorry."
    new "Uhh... Nichts. Ich wollte gerade los. Tut mir leid."

    # say L402 mia
    old "What do you want [pla]?"
    new "Was wollen Sie, [pla]?"

    # say L405 pla
    old "I... wanted to talk about the final project."
    new "Ich... wollte über das Abschlussprojekt reden."

    # say L406 mia
    old "Is it ready? Do you have any progress to show?"
    new "Ist es fertig? Haben Sie schon Fortschritte gemacht, die Sie mir zeigen können?"

    # say L416 mia
    old "Wow, I can't believe it. You guys did it..."
    new "Wow, ich kann es nicht fassen. Sie haben es geschafft..."

    # say L418 pla
    old "And... How was it?"
    new "Und... Wie war es?"

    # say L420 mia
    old "Your project is... Good... I guess..."
    new "Ihr Projekt ist... Gut... Schätze ich..."

    # say L435 mia
    old "You have completed a lot. I have to say I am surprised..."
    new "Sie haben viel geschafft. Ich muss sagen, ich bin überrascht..."

    # say L437 mia
    old "By the way, I talked with your partner... And she said you have been working hard... I wasn't sure, but I have to believe her... Maybe I underestimated you, [pla]."
    new "Übrigens, ich habe mit Ihrem Partner gesprochen... Und sie sagte, Sie hätten hart gearbeitet... Ich war mir nicht sicher, aber ich muss ihr glauben... Vielleicht habe ich Sie unterschätzt, [pla]."

    # say L439 pla
    old "Thank you!"
    new "Danke!"

    # say L441 mia
    old "Don't get too excited. You still have a lot of work to do before it is done."
    new "Nicht so aufgeregt. Du hast noch viel Arbeit vor dir, bevor es fertig ist."

    # say L457 mia
    old "I can't believe you did something of this... I need to talk with your partner, tell her to come and talk with me... ALONE!"
    new "Ich kann nicht glauben, dass Sie etwas Derartiges... Ich muss mit Ihrem Partner sprechen, sagen Sie ihr, sie soll zu mir kommen... ALLEIN!"

    # say L459 pla
    old "Hmm... Ok... I will tell her..."
    new "Hmm... Okay... Ich werde es ihr sagen..."

    # say L474 mia
    old "Ok, now this is getting really suspicious..."
    new "Okay, jetzt wird das wirklich verdächtig."

    # say L478 mia
    old "Anyway, I'm busy to worry about you..."
    new "Na ja, ich bin zu beschäftigt, um mir Sorgen um Sie zu machen..."

    # say L480 pla
    old "Hmmm ok."
    new "Hmmm okay."

    # say L494 mia
    old "Oh? Have you made more progress? Is your partner doing everything?"
    new "Oh? Haben Sie mehr Fortschritte gemacht? Tut Ihr Partner alles, was nötig ist?"

    # say L496 pla
    old "What?! Of course not! This is all team work."
    new "Was?! Natürlich nicht! Das ist alles Teamarbeit."

    # say L498 mia
    old "Hmm... You haven't screwed it up yet. I will keep waiting."
    new "Hmm... Sie haben es noch nicht vermasselt. Ich werde weiter warten."

    # say L511 mia
    old "Oh, you have started... But you still have a lot of work to do before you are done..."
    new "Oh, Sie haben angefangen... Aber Sie haben noch viel Arbeit vor sich, bevor Sie fertig sind..."

    # say L513 pla
    old "But?... How is it?"
    new "Aber?... Wie ist es?"

    # say L515 mia
    old "For now, it's ok. But I'm sure you will screw it up, sooner or later."
    new "Bisher ist es in Ordnung. Aber ich bin sicher, Sie werden es irgendwann vermasseln."

    # say L526 mia
    old "As I thought... then don't bother me. Talk to me when you've made some progress... if you even can, of course..."
    new "Wie ich dachte... dann lass mich in Ruhe. Rede mit mir, wenn du Fortschritte gemacht hast... falls du das überhaupt kannst, natürlich."

    # say L537 mia
    old "Yeah, yeah congratulations, your project was good, are you happy?"
    new "Ja, ja, Glückwunsch, Ihr Projekt war gut, sind Sie zufrieden?"

    # say L539 pla
    old "Thanks! see you!..."
    new "Danke! Bis dann!"

    # menu L573 
    old "Start the Class"
    new "Kurs starten"

    # say L593 luc
    old "The class will start soon, [pla]."
    new "Die Stunde fängt gleich an, [pla]."

    # say L594 luc
    old "Just take a seat."
    new "Setzen Sie sich einfach."

    # say L595 pla
    old "... Uhhh sure."
    new "Klar, Luc."

    # say L755 mia
    old "Well, ladies and gentlemen. Please remember the final project you have to do..."
    new "Nun, meine Damen und Herren. Bitte denken Sie daran, das Abschlussprojekt, das Sie noch machen müssen..."

    # say L757 pla
    old "(Hmm... The final project... one of the hardest and boringest things ever!)"
    new "Hmm... Die Abschlussarbeit... eine der schwierigsten und langweiligsten Sachen überhaupt!"

    # say L758 pla
    old "(I mean, research? Bibliographies? Theoretical framework?... All that work on stuff I'll never use...)"
    new "(I meine, Recherche? Literaturverzeichnisse? Theoretische Rahmen?... All die Arbeit für Zeug, das ich nie brauchen werde...)"

    # say L764 pla
    old "(I really want to graduate and be free from all of this crap…)"
    new "Ich will echt abschließen und von all dem Mist befreit sein…"

    # say L773 pla
    old "Where did it fall from?... An airplane?"
    new "Wo ist es runtergefallen?... Aus einem Flugzeug?"

    # say L777 pla
    old "Sorry, Mrs. Mia. I'm listening. I was just... looking through the window..."
    new "Entschuldigung, Frau Mia. Ich höre zu. Ich war gerade... aus dem Fenster geschaut..."

    # say L778 mia
    old "Oh really? Then please tell us all the project requirements that I just explained..."
    new "Oh wirklich? Dann bitte sagen Sie uns doch alle Projektanforderungen, die ich gerade erklärt habe..."

    # say L789 pla
    old "Ughh... Finally free!..."
    new "Ughh... Endlich frei!..."

    # say L791 pla
    old "(I don't know how I'm going to get that project done.)"
    new "Ich hab echt keine Ahnung, wie ich das Projekt schaffe."

    # say L800 pla
    old "Hey, Bell! I wanted to ask you... if we... could work together in the class project?"
    new "Hey, Bell! Ich wollte dich fragen... ob wir... zusammen an dem Klassenprojekt arbeiten könnten?"

    # say L802 bel
    old "You wasn't paying attention, huh?"
    new "Du warst wohl nicht bei der Sache, oder?"

    # say L804 pla
    old "What?... What you mean?"
    new "Was?... Was meinst du damit?"

    # say L806 bel
    old "This project is for couples and your partner is Hinn."
    new "Dieses Projekt ist für Paare und dein Partner ist Hinn."

    # say L808 pla
    old "Really? OK, thanks anyway."
    new "Wirklich? Okay, danke trotzdem."

    # say L813 mik
    old "Heyyy guys! Did you notice  Mia`s neckline, every day she gets hotter and hotter."
    new "Heyyy Leute! Habt ihr Mias Dekolleté bemerkt? Jeden Tag wird sie heißer und heißer."

    # say L816 bel
    old "Really Mike? She could be your mother ... "
    new "Echt jetzt Mike? Sie könnte deine Mutter sein..."

    # say L818 mik
    old "That makes it even more sexy. A hot ass milf teaches us. Sounds nice, aye, [pla]?"
    new "Das macht es noch sexier. Eine heiße MILF, die uns unterrichtet. Klingt gut, oder, [pla]?"

    # say L820 pla
    old "I only know that she hates my guts and each day it gets worse. I just hope I'm alive at the end of the school year."
    new "Ich weiß nur, dass sie mich hasst und es jeden Tag schlimmer wird. Ich hoffe nur, dass ich am Ende des Schuljahres noch lebe."

    # say L822 bel
    old "Well, I'm leaving. I have things to do. And I don't want to stay here and keep listening to Mike's perversions."
    new "Na ja, ich geh dann. Ich hab zu tun und will nicht hier sitzen und Mikes Perversionen weiter anhören."

    # say L824 pla
    old "Bye, Belle. See you around."
    new "Tschüss, Belle. Bis dann."

    # say L831 mik
    old "Have you noticed how hot Belle is gettin'?"
    new "Hast du bemerkt, wie heiß Belle wird?"

    # say L833 pla
    old "Dude... Damn, you should calm down a little."
    new "Dude... Mann, du solltest dich ein bisschen beruhigen."

    # say L835 mik
    old "Why? Are you gay or something?"
    new "Warum? Bist du schwul oder so?"

    # say L837 pla
    old "Bye, Mike. I'll talk to you later"
    new "Tschüss, Mike. Reden wir später."

    # say L839 mik
    old "So I'm right, huh? But she is hot, isn't she?"
    new "Dann hab ich also recht, hm? Aber sie ist heiß, oder?"

    # say L856 pla
    old "Wait... Is this...?"
    new "Warte... Ist das...?"

    # say L858 pla
    old "The book that fell from the sky?"
    new "Das Buch, das vom Himmel gefallen ist?"

    # say L860 pla
    old "SexNote?  What could it be about?"
    new "SexNote? Was könnte da drin stehen?"

    # say L862 pla
    old "Weeeell, finders-keepers. Hehe."
    new "Na ja, Finderlohn. Hehe."

    # say L864 pla
    old "Maybe I can think of something interesting to draw in it."
    new "Vielleicht fällt mir was Interessantes ein, was ich da malen kann."

    # say L883 mik
    old "Hey, wait! Before you go... I have something to show you that will surely blow your mind."
    new "Hey, warte mal! Bevor du gehst... Ich hab was zu zeigen, das wird dich echt umhauen."

    # say L885 pla
    old "Now what weird thing do you have in mind?"
    new "Was für eine seltsame Sache hast du jetzt wieder im Sinn?"

    # say L887 mik
    old "Listen... Just go to my house and look for me in my room. I'll show you."
    new "Hör zu... Geh einfach zu mir nach Hause und such mich in meinem Zimmer. Ich zeig's dir."

    # say L889 pla
    old "Hmm, alright... I will see you then."
    new "Hmm, okay... Ich sehe dich dann."

    # say L891 mik
    old "Seriously, [pla].I assure you it will be worth it!"
    new "Im Ernst, [pla]. Ich verspreche dir, es wird sich lohnen!"

    # say L908 pla
    old "I shouldn't enter. This isn't my classroom."
    new "Ich sollte da nicht reingehen. Das ist nicht mein Klassenzimmer."


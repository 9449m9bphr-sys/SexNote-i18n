# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/momAnimations.rpy
translate german strings:

    # say L7 mo1
    old "Oh yes, just like that. Does it feel nice hun?"
    new "Oh ja, genau so. Fühlt es sich gut an, Schatz?"

    # say L8 pla
    old "Mmmm yeah, it feels really nice."
    new "Mmmm ja, es fühlt sich echt gut an."

    # say L9 mo1
    old "Great, just relax and enjoy the... Uhmm massage."
    new "Perfekt, einfach entspann dich und genieße die... Ähmm Massage."

    # say L13 mo1
    old "Let me do it a bit faster."
    new "Lass mich es ein bisschen schneller machen."

    # say L17 mo1
    old "Uhmm? does it hurt darling??"
    new "Hmm? Tut es weh, Liebling??"

    # say L18 pla
    old "No, no, don't worry. It feels better."
    new "Nein, nein, mach dir keine Sorgen. Es fühlt sich besser an."

    # say L19 mo1
    old "Ohh, ok, I'm glad."
    new "Ohh, ok, ich bin erleichtert."

    # say L23 pla
    old "Hmm, [mo1rel]? Would you please do it faster?"
    new "Hmm, [mo1rel]? Könntest du das bitte schneller machen?"

    # say L24 mo1
    old "Ohh, of course hun."
    new "Ohh, natürlich Schatz."

    # say L28 pla
    old "Ohhh yes, yes, just like this."
    new "Ohhh ja, ja, genau so."

    # say L29 mo1
    old "I can feel that body is tensing up. You can release your load whenever you want, darling."
    new "Ich spüre, dass sich dein Körper anspannt. Du kannst dich jederzeit entladen, Liebling."

    # say L53 pla
    old "Mmmm, [mo1rel] I- I feel like I'm going to explode..."
    new "Mmmm, [mo1rel] Ich- Ich fühle mich, als würde ich explodieren..."

    # say L54 mo1
    old "It's alright honey, just let it all go."
    new "Alles gut, Schatz, lass es einfach raus."

    # say L60 mo1
    old "Mmmm, good job honey. You did it just great."
    new "Mmmm, gut gemacht Schatz. Du hast es wirklich toll gemacht."

    # say L61 pla
    old "-Sigh- Thanks [mo1rel]."
    new "-Sigh- Danke [mo1rel]."

    # say L66 mo1
    old "Okay, this will definitely help."
    new "Okay, das wird definitiv helfen."

    # say L67 pla
    old "Thanks."
    new "Danke."

    # say L68 mo1
    old "You are welcome honey, I hope you feel better now."
    new "Gern geschehen, Schatz, ich hoffe, es geht dir jetzt besser."

    # say L69 pla
    old "Yes, I do. although I'm feeling a bit tired."
    new "Ja, das tue ich. Obwohl ich ein bisschen müde bin."

    # say L70 mo1
    old "Aww, don't worry hun, just rest a little."
    new "Ach, mach dir keine Sorgen, mein Schatz, ruh dich einfach ein bisschen aus."

    # say L72 mo1
    old "Oh, and remember, don't tell anyone. Especially [mo2]! She wouldn't understand and would kill us!"
    new "Oh, und denk dran, niemandem was sagen. Vor allem nicht [mo2]! Die würde es nicht verstehen und uns umbringen!"

    # say L74 mo1
    old "You know you can always count on me."
    new "Du weißt, dass du dich immer auf mich verlassen kannst."

    # say L75 pla
    old "Yes, thank you [mo1rel]."
    new "Ja, danke [mo1rel]."

    # say L76 mo1
    old "You are welcome. Well, if you need me, you know where to find me."
    new "Sie sind willkommen. Na ja, wenn Sie mich brauchen, wissen Sie ja, wo Sie mich finden."

    # say L98 mo1
    old "Oh my God, I can't believe how big it is."
    new "Oh mein Gott, ich kann nicht glauben, wie groß es ist."

    # say L100 mo1
    old "Is the biggest I have ever seen."
    new "Das größte, das ich je gesehen habe."

    # say L105 mo1
    old "Do you like how I'm jerking you off?"
    new "Möchtest du, wie ich dich wichse?"

    # say L106 pla
    old "... Y- yes it feels nice."
    new "... J- ja, das fühlt sich gut an."

    # say L107 mo1
    old "Mmm, your cock looks really tasty."
    new "Mmm, dein Schwanz sieht richtig lecker aus."

    # say L113 mo1
    old "Are you getting close?"
    new "Kommen Sie bald?"

    # say L114 pla
    old "Uhh y- yes."
    new "Uhh j- ja."

    # say L115 mo1
    old "Would you like to cum for me?"
    new "Möchten Sie für mich kommen?"

    # say L155 pla
    old "Mmmm, [mo1rel] I- I gonna cum..."
    new "Mmmm, [mo1rel] ich- ich komme..."

    # say L156 mo1
    old "Oh yeah, cum for mommy."
    new "Oh ja, komm für mommy."

    # say L162 pla
    old "Ughh, that was so intense, [mo1rel]."
    new "Ughh, das war so intensiv, [mo1rel]."

    # say L163 mo1
    old "Mmmm, I'm glad you liked it..."
    new "Mmmm, ich bin froh, dass es dir gefallen hat..."

    # say L164 mo1
    old "But... Now, let's finish watching this movie."
    new "Aber... Jetzt lass uns den Film zu Ende gucken."

    # say L165 pla
    old "For sure."
    new "Klar."

    # say L178 mo1
    old "Mmmm, it tastes really good."
    new "Mmmm, es schmeckt wirklich gut."

    # say L179 mo1
    old "Does it feels better than my hand, isn't it?"
    new "Fühlt es sich besser an als meine Hand, nicht wahr?"

    # say L180 pla
    old "Uhhh, yeah."
    new "Uhhh, ja."

    # say L185 mo1
    old "Do you like to feel my warm and wet mouth?"
    new "Magst du es, meine warme und feuchte Mund zu spüren?"

    # say L186 pla
    old "Ohhh, y- yes it feels amazing."
    new "Ohhh, j- ja, das fühlt sich unglaublich an."

    # say L187 mo1
    old "Then there is something that you are going to enjoy even more."
    new "Dann gibt es da noch etwas, das dir noch viel besser gefallen wird."

    # say L192 mo1
    old "Mmmm, I love to suck your cock!"
    new "Mmmm, ich liebe es, deinen Schwanz zu lutschen!"

    # say L193 mo1
    old "Would you like to cum in my mouth?"
    new "Möchtest du in meinem Mund kommen?"

    # say L194 pla
    old "Wow, can I?"
    new "Wow, kann ich?"

    # say L195 mo1
    old "Mmmm, please honey. I would love to taste all your load."
    new "Mmmm, bitte Schatz. Ich würde deinen ganzen Saft so gerne schmecken."

    # say L234 pla
    old "Mmmm, [mo1rel], I feel like..."
    new "Mmmm, [mo1rel], ich fühle mich wie..."

    # say L237 mo1
    old "Glurpp... Wow, it was a huge load."
    new "Glurpp... Wow, es war eine riesige Ladung."

    # say L239 mo1
    old "Glup... Whew, I had to swallow a lot."
    new "Glup... Phew, ich musste viel schlucken."

    # say L243 pla
    old "It was AMAZING [mo1rel]."
    new "Es war ERSTAUNLICH [mo1rel]."

    # say L244 mo1
    old "Well, I'm glad you loved it..."
    new "Na, ich bin froh, dass es dir gefallen hat..."

    # say L245 mo1
    old "But now let's continue the movie."
    new "Aber jetzt lass uns den Film weitersehen."

    # say L267 pla
    old "Is this a dream?"
    new "Ist das ein Traum?"

    # say L268 pla
    old "Oh my gosh! My [mo1rel] it's fucking hot!"
    new "Oh mein Gott! Meine [mo1rel], es ist arschheiß!"

    # say L273 pla
    old "Holly shit! Look at those tits bouncing!"
    new "Holly Scheiße! Schau dir diese Titten hüpfen!"

    # say L274 pla
    old "This view is amazing."
    new "Dieser Anblick ist unglaublich."

    # say L303 pla
    old "Wow... That was a dream?"
    new "Wow... Das war ein Traum?"

    # say L305 pla
    old "It was very strange because it felt very real..."
    new "Es war sehr seltsam, weil es sich so echt angefühlt hat..."

    # say L307 pla
    old "Anyway, I better go to sleep..."
    new "Na ja, ich sollte besser schlafen gehen..."

    # say L326 pla
    old "Mmmm, it feels really nice."
    new "Mmmm, das fühlt sich echt gut an."

    # say L327 mo1
    old "Sorry, did you say something?"
    new "Entschuldigung, haben Sie etwas gesagt?"

    # say L328 pla
    old "Uhmm, no, no sorry."
    new "Uhmm, nein, nein, tut mir leid."

    # say L329 pla
    old "(Shit I better stay quiet)"
    new "Verdammt, ich sollte besser still sein"

    # say L369 mo1
    old "Wow honey, did you spill more sunscreen in my legs?"
    new "Wow Schatz, hast du mehr Sonnencreme auf meinen Beinen verteilt?"

    # say L370 pla
    old "(Oh shit...) Yes, I spilled more to make sure, you don't get sunburned."
    new "Oh Scheiße... Ja, ich habe mehr draufgetan, um sicherzustellen, dass du keinen Sonnenbrand bekommst."

    # say L373 mo1
    old "Aww, you are a sweetheart."
    new "Ach, du bist ein Schatz."

    # say L374 pla
    old "(Oh fuck that was close... Should I make another try?)"
    new "Oh Scheiße, das war knapp... Soll ich es noch mal versuchen?"

    # say L385 pla
    old "{b}Sauron's mouth:{/b} Now is your turn... Use your feet to massage me, ok?"
    new "{b}Saurons Mund:{/b} Jetzt bist du dran... Benutz deine Füße, um mich zu massieren, okay?"

    # say L393 pla
    old "(Holly shit! Is working.)"
    new "Verdammt, das funktioniert ja."

    # say L398 pla
    old "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (No, I shouldn't take risks.)"
    new "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (Nein, ich sollte keine Risiken eingehen.)"

    # say L399 pla
    old "Well is done, I think you are perfect now."
    new "Na, das ist ja gemacht, ich denke, du bist jetzt perfekt."

    # say L400 mo1
    old "Aww, thank you so much, see you later sweetheart."
    new "Ach, danke schön, bis später, Liebling."

    # say L445 pla
    old "Holy shit, I can't help it anymore..."
    new "Verdammt, ich kann es nicht mehr aushalten..."

    # say L496 mo1
    old "What the fuck?"
    new "Was zum Teufel?"

    # say L497 pla
    old "(Oh... Shit.)"
    new "Oh... Scheiße."

    # say L505 mo1
    old "What the fuck were you doing [pla]!?"
    new "Was zum Teufel hast du da gemacht [pla]!?"

    # say L506 pla
    old "Sorry I... I..."
    new "Entschuldigung, ich... ich..."

    # say L508 mo1
    old "You were rubbing your... With my ass?"
    new "Du hast dein... Mit meinem Hintern gerieben?"

    # say L512 mo1
    old "I can't believe it! What's wrong with you?"
    new "Ich kann es nicht fassen! Was ist bloß los mit dir?"

    # say L513 pla
    old "Sorry... It was not my intention..."
    new "Entschuldigung... Das war nicht meine Absicht..."

    # say L515 mo1
    old "It wasn't your intention? What the fuck?..."
    new "Das war nicht Ihre Absicht? Was soll das Scheißgedrösel?"

    # say L516 mo1
    old "I... I'll clean it myself, I don't want to see you anymore..."
    new "Ich... Ich werde es selbst saubermachen, ich will dich nicht mehr sehen."

    # say L519 pla
    old "Oh shit, I messed it up."
    new "Oh Scheiße, ich hab's vermasselt."

    # say L527 mo1
    old "Again?"
    new "Wieder?"

    # say L533 mo1
    old "Oh honey again?"
    new "Oh Schatz, wieder?"

    # say L534 pla
    old "I'm sorry I couldn't resist, I can't control it"
    new "Es tut mir leid, ich konnte nicht widerstehen, ich kann es einfach nicht kontrollieren."

    # say L536 mo1
    old "Mmm... It's alright, just please try not to rub your... against my ass, ok?"
    new "Mmm... Ist schon gut, aber bitte versuch, dein... nicht gegen meinen Hintern zu reiben, okay?"

    # say L540 mo1
    old "If you need to release it, you can ask my help or do it by yourself."
    new "Wenn du es loswerden musst, kannst du um meine Hilfe bitten oder es selbst tun."

    # say L542 pla
    old "You're right... It was not my intention..."
    new "Du hast recht... Das war nicht meine Absicht..."

    # say L544 mo1
    old "I know sweetheart don't worry..."
    new "Ich weiß, Liebling, mach dir keine Sorgen..."

    # say L546 mo1
    old "I'm going to clean myself."
    new "Ich mache mich sauber."

    # say L562 mo1
    old "{i}Does it turn you on?{/i}"
    new "{i}Turns dich das an?{/i}"

    # say L563 pla
    old "{i}W- what?{/i}"
    new "{i}W- was?{/i}"

    # say L564 mo1
    old "{i}Does it turn you on, doing it in front of [mo2]?{/i}"
    new "{i}Macht es dich an, es vor [mo2] zu tun?{/i}"

    # say L570 mo1
    old "{i}If she caught us, she will kill us.{/i}"
    new "{i}Wenn sie uns erwischt, bringt sie uns um.{/i}"

    # say L572 mo1
    old "{i}Oh no, all of this is making me horny.{/i}"
    new "{i}Och nein, das alles macht mich richtig geil.{/i}"

    # say L577 mo1
    old "{i}Oh yeah, I'm gonna make you cum in front of [mo2].{/i}"
    new "{i}O ja, ich werde dich vor [mo2] zum Kommen bringen.{/i}"

    # say L604 mo1
    old "{i}Cum quietly!{/i}"
    new "{i}Komm leise!{/i}"

    # say L608 mo1
    old "{i}Wow, you still hard... We will need to do something else, right?{/i}"
    new "{i}Wow, du bist immer noch hart... Wir werden etwas anderes machen müssen, oder?{/i}"

    # say L609 pla
    old "{i}Oh come on... No, please we should stop now...{/i}"
    new "{i}Och komm schon... Nein, bitte, wir sollten jetzt aufhören...{/i}"

    # say L610 mo1
    old "{i}Shut up, and take your pants off...{/i}"
    new "{i}Halt die Klappe und zieh deine Hose aus...{/i}"

    # say L612 mo1
    old "{i}You will love this...{/i}"
    new "{i}Sie werden das lieben...{/i}"

    # say L624 pla
    old "{i}Holy Shit!{/i}"
    new "{i}Heilige Scheiße!{/i}"

    # say L627 pla
    old "Uhhh... No, no, I- I'm just excited by the movie..."
    new "Uhhh... Nein, nein, ich bin nur vom Film aufgeregt..."

    # say L628 mo2
    old "Can't you see a movie quietly?"
    new "Können Sie sich nicht ruhig einen Film ansehen?"

    # say L629 pla
    old "Yes, yes I- I'm sorry."
    new "Ja, ja, ich- ich bin sorry."

    # say L631 mo1
    old "{i}Shhh, just relax and enjoy...{/i}"
    new "{i}Psst, entspann dich einfach und genieße...{/i}"

    # say L648 mo1
    old "{i}Do you realize I'm giving you a blowjob almost in front of [mo2]?{/i}"
    new "{i}Wissen Sie, dass ich Ihnen fast vor [mo2] einen blase?{/i}"

    # say L649 pla
    old "{i}Yeah, that's crazy.{/i}"
    new "{i}Ja, das ist verrückt.{/i}"

    # say L650 mo1
    old "{i}Actually, is behind [mo2], and it sounds even naughtier... Hehehe.{/i}"
    new "{i}Eigentlich ist es hinter [mo2], und das klingt noch verwegener... Hehehe.{/i}"

    # say L651 pla
    old "{i}How much did you drink?{/i}"
    new "{i}Wie viel hast du getrunken?{/i}"

    # say L655 mo1
    old "{i}Are you ready for my oral creampie?{/i}"
    new "{i}Sind Sie bereit für meinen oralen Cremepie?{/i}"

    # say L683 mo1
    old "{i}Wow it was a lot... Did you like it?{/i}"
    new "{i}Wow, das war viel... Hat dir das gefallen?{/i}"

    # say L684 pla
    old "{i}Hell yeah, it was great...{/i}"
    new "{i}Verdammt ja, es war toll...{/i}"

    # say L685 mo1
    old "{i}Let's clean this mess quietly.{/i}"
    new "{i}Lass uns diesen Saustall leise aufräumen.{/i}"

    # say L696 pla
    old "Oh yes, it was awesome."
    new "Oh ja, es war toll."

    # say L698 mo2
    old "I thought it was stupid... Anyway I'm going bed."
    new "Ich fand es blöd... Jedenfalls, ich geh ins Bett."

    # say L701 mo1
    old "Yes, good night honey, sleep well."
    new "Ja, gute Nacht, Schatz, schlaf gut."

    # say L703 pla
    old "Good night"
    new "Gute Nacht"

    # say L718 mo1
    old "Do you like my tits, isn't it?"
    new "Magst du meine Titten, hm?"

    # say L719 mo1
    old "Well, I think you deserve a great titjob."
    new "Nun, ich denke, du verdienst eine großartige Tittennummer."

    # say L725 mo1
    old "How does it feel to have your [mo1rel] tits around your cock?"
    new "Wie fühlt es sich an, deinen [mo1rel] Titten um deinen Schwanz zu haben?"

    # say L726 pla
    old "Uhh... It feels amazing!"
    new "Uhh... Es fühlt sich unglaublich an!"

    # say L727 mo1
    old "Mmmm, I'm enjoying it too."
    new "Mmmm, ich genieße es auch."

    # say L732 mo1
    old "Would you like to cum on my tits?"
    new "Möchten Sie auf meinen Titten kommen?"

    # say L733 pla
    old "Oh yeah."
    new "Oh ja."

    # say L734 mo1
    old "So, cum on your [mo1rel]'s tits."
    new "So, spritz auf [mo1rel]s Titten."

    # say L760 mo1
    old "Oh yes! Cum all over me!"
    new "Oh ja! Spritz alles über mich!"

    # say L764 mo1
    old "Wow you came a lot..."
    new "Wow, Sie sind ja richtig viel gekommen..."

    # say L765 mo1
    old "I'm glad you're still hard, because I need you inside of me now."
    new "Ich bin froh, dass Sie noch hart sind, denn ich brauche Sie jetzt in mir."

    # say L767 mo1
    old "Come with me to the bed"
    new "Kommen Sie mit mir ins Bett"

    # say L786 mo1
    old "Uhhh, yes, just like that."
    new "Uhhh, ja, genau so."

    # say L787 mo1
    old "I'm I can feel your cock inside me, and it feels amazing!"
    new "Ich kann Ihren Schwanz in mir spüren, und es fühlt sich fantastisch an!"

    # say L792 mo1
    old "Mmmm, it feels so nice!"
    new "Mmmm, es fühlt sich so gut an!"

    # say L793 mo1
    old "Oh yeah, don't stop baby, don't stop!"
    new "Oh ja, hör nicht auf, Baby, hör nicht auf!"

    # say L798 mo1
    old "Ahhh, ahhh, yeah fuck me, fuck me!"
    new "Ahhh, ahhh, ja fick mich, fick mich!"

    # say L799 mo1
    old "Yess! Fuck your [mo1rel] harder!"
    new "Yess! Ficken Sie Ihre [mo1rel] härter!"

    # say L800 mo1
    old "Mmmm... I'm getting close, don't stop."
    new "Mmmm... Ich komme gleich, hör nicht auf."

    # say L828 mo1
    old "God, that was awesome."
    new "Oh Gott, das war fantastisch."

    # say L835 mo1
    old "Let's rest a little."
    new "Lass uns ein bisschen ausruhen."

    # say L845 mo1
    old "That was a fantastic night honey."
    new "Das war eine fantastische Nacht, Schatz."

    # say L847 pla
    old "Yes, I really enjoyed it."
    new "Ja, ich hab's wirklich genossen."

    # say L849 mo1
    old "Remember we must be careful, no one can know... Ok?"
    new "Denk dran, wir müssen vorsichtig sein, niemand darf es erfahren... Ok?"

    # say L851 pla
    old "Yes, don't worry."
    new "Ja, mach dir keine Sorgen."

    # say L853 mo1
    old "Go to your room quietly to avoid suspicion."
    new "Geh still in dein Zimmer, um keinen Verdacht zu erregen."

    # say L855 pla
    old "You're right! I will."
    new "Du hast recht! Ich werd's tun."

    # say L864 mo1
    old "Oh no... I'm sorry, I'm really sorry ..."
    new "Oh nein... Es tut mir leid, es tut mir wirklich leid..."

    # say L866 pla
    old "What? Why?"
    new "Was? Warum?"

    # say L868 mo1
    old "For what happened last night, it was definitely very bad, I drank too much and-"
    new "Wofür passiert ist letzte Nacht, es war definitiv sehr schlecht, ich habe zu viel getrunken und-"

    # say L870 pla
    old "No, we both decided to do it, I also agreed."
    new "Nein, wir beide haben das beschlossen, ich war auch einverstanden."

    # say L873 mo1
    old "But I am your [mo1rel]."
    new "Aber ich bin Ihre [mo1rel]."

    # say L875 pla
    old "(Hmmm... I could need a bit of help here ...)"
    new "Hmm... Ich könnte hier ein bisschen Hilfe gebrauchen..."

    # say L879 mo1
    old "Yes, we are both adults ..."
    new "Ja, wir sind beide Erwachsene..."

    # say L881 mo1
    old "You know what, what the hell, I'm not going to keep worrying about [mo2]."
    new "Sie wissen was, verdammt nochmal, ich werde mir keine Sorgen mehr machen über [mo2]."

    # say L883 mo1
    old "If you're okay with this, I think I'm fine too, right?"
    new "Wenn du damit einverstanden bist, denke ich, ich bin es auch, oder?"

    # say L887 mo1
    old "Also yesterday I really enjoyed it and can't believe I haven't done it in so many years!"
    new "Also gestern habe ich es wirklich genossen und kann nicht glauben, dass ich es so viele Jahre nicht getan habe!"

    # say L889 pla
    old "I also enjoyed it a lot."
    new "Ich habe es auch sehr genossen."

    # say L891 mo1
    old "Just be careful, I don't want anyone to notice, ok?"
    new "Sei vorsichtig, ich will nicht, dass jemand etwas bemerkt, okay?"

    # say L895 mo1
    old "Great honey, let's go, I have to prepare breakfast."
    new "Großartig Schatz, lass uns gehen, ich muss Frühstück machen."

    # say L902 pla
    old "Well, that was insane... I had sex with [mo1rel]..."
    new "Na, das war verrückt... Ich habe mit [mo1rel] geschlafen..."

    # say L993 mo1
    old "Ahhhh... It's so big"
    new "Ahhhh... Es ist so groß."

    # say L994 mo1
    old "Mmmm, it feels amazing!"
    new "Mmmm, es fühlt sich fantastisch an!"

    # say L999 mo1
    old "Uhhh yeah, baby I love your cock."
    new "Uhhh ja, Baby, ich liebe deinen Schwanz."

    # say L1000 mo1
    old "Oh God, oh God! I'm so wet."
    new "Oh Gott, oh Gott! Ich bin so nass."

    # say L1005 mo1
    old "Yeah, yeah, I love having your cock inside me."
    new "Ja, ja, ich liebe es, deinen Schwanz in mir zu spüren."

    # say L1006 mo1
    old "Ohh yeah, just like this..."
    new "Ohh ja, genau so..."

    # say L1041 mo1
    old "Ahhh... Ahhh! I- I'm cumming!"
    new "Ahhh... Ahhh! I- Ich komme!"

    # say L1042 pla
    old "Ughhhh m- me too."
    new "Ughhhh m- mir auch."

    # say L1047 mo1
    old "Oh yes... It was really good."
    new "Oh ja... Das war wirklich gut."

    # say L1048 mo1
    old "But I want more!"
    new "Aber ich will mehr!"

    # say L1067 mo1
    old "Ohhh God!"
    new "Ohhh Gott!"

    # say L1068 mo1
    old "This is amazing!"
    new "Das ist unglaublich!"

    # say L1073 mo1
    old "Uhh, I'll never get tired of this."
    new "Uhh, ich werde mich daran nie sattsehen."

    # say L1074 mo1
    old "Mmmm, do you like your [mo1rel] riding you?"
    new "Mmmm, gefällt es Ihnen, wie ich Ihren [mo1rel] reite?"

    # say L1075 pla
    old "Ohhh yes."
    new "Ohhh ja."

    # say L1080 mo1
    old "Yeah! Fuck me [pla], Fuck your [mo1rel]!"
    new "Ja! Fick mich [pla], fick deinen [mo1rel]!"

    # say L1081 mo1
    old "Ohhh my God!"
    new "Ohhh mein Gott!"

    # say L1107 mo1
    old "Mmmm, let me try something."
    new "Mmmm, lass mich etwas ausprobieren."

    # say L1108 mo1
    old "I'm sure you will enjoy this."
    new "Ich bin sicher, Sie werden das genießen."

    # say L1116 mo1
    old "Uhhh this feels even better."
    new "Uhhh das fühlt sich noch besser an."

    # say L1117 mo1
    old "Ohhh myy-"
    new "Ohhh meine Güte-"

    # say L1122 mo1
    old "Mmmm, I learned this in college."
    new "Mmmm, das habe ich auf dem College gelernt."

    # say L1123 mo1
    old "Do you like how I'm moving?"
    new "Mögen Sie, wie ich mich bewege?"

    # say L1129 mo1
    old "Ahhh... Oh my God it feels so fucking goood!"
    new "Ahhh... Oh Gott, das fühlt sich so verdammt gut!"

    # say L1130 mo1
    old "Yeah, yeah, I'm getting close!"
    new "Ja, ja, ich bin gleich soweit!"

    # say L1154 mo1
    old "Yeah yeah! Let's cum together!"
    new "Ja ja! Lassen Sie uns zusammen kommen!"

    # say L1156 mo1
    old "Yes, cum with mommy baby! Cum with me!"
    new "Ja, komm mit Mama Schatz! Komm mit mir!"

    # say L1160 mo1
    old "Holly shit, that was amazing!"
    new "Holly Scheiße, das war unglaublich!"

    # say L1161 pla
    old "Pheww... Ohh yeah."
    new "Pheww... Ohh ja."

    # say L1176 mo1
    old "It's getting better and better!"
    new "Es wird immer besser!"

    # say L1177 mo1
    old "Ohh my God!"
    new "Oh Gott!"

    # say L1182 mo1
    old "It's so big! Oh God I feel it so deep!"
    new "Es ist so groß! Oh Gott, ich spüre es so tief!"

    # say L1183 mo1
    old "Oh yes, fuck me [pla], fuck me!"
    new "Oh ja, ficken Sie mich [pla], ficken Sie mich!"

    # say L1188 mo1
    old "Oh yeah, faster, faster! Fuck me harder!"
    new "Oh ja, schneller, schneller! Fick mich härter!"

    # say L1189 mo1
    old "Uhhh, yes, yes, fuck your mommy!"
    new "Uhhh, ja, ja, fick deinen Mommy!"

    # say L1214 mo1
    old "Ohhhh m- my God! I'm cumming!"
    new "Ooooooh m- mein Gott! Ich komme!"

    # say L1215 pla
    old "Ughhh mee too!"
    new "Ughhh ich auch!"

    # say L1220 mo1
    old "Wow it was a huge load"
    new "Wow, es war eine riesige Ladung"

    # say L1221 mo1
    old "Mmmm, you cum all over me."
    new "Mmmm, Sie spritzen überall auf mich."

    # say L1222 mo1
    old "Let's clean this up before someone comes."
    new "Lass uns das saubermachen, bevor jemand kommt."


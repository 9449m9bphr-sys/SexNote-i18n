# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/rubAnimations.rpy
translate german strings:

    # say L6 gomRub
    old "Mmm, I love how it tastes."
    new "Mmm, ich liebe, wie es schmeckt."

    # say L7 gomRub
    old "Your dick is so big."
    new "Dein Schwanz ist so groß."

    # say L8 gomRub
    old "And you’re so hard."
    new "Und du bist so hart."

    # say L12 gomRub
    old "Sluurp! Are you enjoying it?"
    new "Sluurp! Gefällt dir das?"

    # say L13 pla
    old "Mmm...  I guess. it’s a bit weird with Ruby’s body though."
    new "Mmm... Ich schätze schon. Ist aber ein bisschen seltsam mit Rubys Körper."

    # say L14 gomRub
    old "Your dick, it’s twitching."
    new "Dein Schwanz, er zuckt."

    # say L15 gomRub
    old "Mmm! And it’s so tasty, I love it!"
    new "Mmm! Und es schmeckt so gut, ich liebe es!"

    # say L19 gomRub
    old "Yes, Yes! I love this feeling in my mouth!"
    new "Ja, ja! Ich liebe dieses Gefühl in meinem Mund!"

    # say L20 gomRub
    old "I can feel your body tensing up!"
    new "Ich spüre, wie sich dein Körper anspannt!"

    # say L21 pla
    old "T- This is, aaah!"
    new "D- Das ist, aaah!"

    # say L45 gomRub
    old "Yes! Yes! Do it!"
    new "Ja! Ja! Mach es!"

    # say L46 gomRub
    old "Give me that magic power!"
    new "Gib mir diese magische Kraft!"

    # say L52 gom
    old "Oh wow! You’d given me magic before, but this is way different!"
    new "Oh wow! Du hast mir schon mal Magie gegeben, aber das hier ist total anders!"

    # say L53 gom
    old "Human bodies are amazing. It feels so different."
    new "Menschliche Körper sind unglaublich. Es fühlt sich so anders an."

    # say L54 gom
    old "It didn’t feel bad before, it’s just so... weird!"
    new "Es hat sich vorher nicht schlecht angefühlt, es ist einfach so... seltsam!"

    # say L55 pla
    old "Hmm... Yeah, sure."
    new "Hmm... Ja, klar."


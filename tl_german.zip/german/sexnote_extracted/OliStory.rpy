# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/OliStory.rpy
translate german strings:

    # say L8 oli
    old "Did you see my notes report?!"
    new "Hast du meinen Notenbericht gesehen?!"

    # say L12 oli
    old "You're a fucking moron!"
    new "Du bist ein verdammter Idiot!"

    # say L14 oli
    old "{i}'Oh yeah, I know all the topics, I'll for sure help you get better...'{/i}"
    new "{i}'Klar, ich kenne alle Themen, ich werd dir bestimmt helfen, besser zu werden...'{/i}"

    # say L23 mik
    old "B- but, I- I really did teach you what was needed for the exam... I mean, I did well..."
    new "B- aber, ich- ich habe dir doch wirklich alles beigebracht, was du für die Klausur brauchst... Ich meine, ich hab das gut gemacht..."

    # say L24 oli
    old "Are you suggesting that I'm dumb? Or that it was my fault?"
    new "Meinst du damit, dass ich dumm bin? Oder dass es meine Schuld war?"

    # say L25 mik
    old "No, no, what I'm saying is that..."
    new "Nein, nein, was ich sagen will, ist dass..."

    # say L44 oli
    old "You assured me that if I spent time with you and let you do 'that' to me..."
    new "Du hast mir versichert, dass wenn ich Zeit mit dir verbringe und dir das lasse..."

    # say L47 oli
    old "... You were going to help me pass the exams."
    new "... Du hast mir versprochen, mir bei den Prüfungen zu helfen."

    # say L48 oli
    old "But I ended up failing anyway!"
    new "Aber ich habe trotzdem durchgefallen!"

    # say L51 oli
    old "If you didn't actually understand the subjects, you could've just told me that..."
    new "Wenn du die Themen gar nicht verstanden hast, hättest du mir das einfach sagen können..."

    # say L52 oli
    old "That way I wouldn't have wasted my time with you."
    new "Dann hätte ich mir die Zeit mit dir nicht vergeudet."

    # say L53 mik
    old "But I don't know what happened, I explained it to you just like [pla] did with m-..."
    new "Aber ich weiß nicht, was passiert ist, ich habe es dir doch genauso erklärt wie [pla]..."

    # say L56 oli
    old "What? [pla]? What does he have to do with all this?"
    new "Was? [pla]? Was hat der damit zu tun?"

    # say L58 mik
    old "N- nothing, nothing, I meant that I also helped him and he had a good result on the exam..."
    new "N- nichts, nichts, ich meinte nur, dass ich ihm auch geholfen habe und er ein gutes Ergebnis in der Klausur hatte..."

    # say L60 mik
    old "Maybe you just didn't understand the topics I explained well."
    new "Vielleicht hast du die Themen, die ich erklärt habe, einfach nicht so gut verstanden."

    # say L79 pla
    old "Hey man... That sounded rough. What's going on?"
    new "Hey Mann... Das klang ziemlich hart. Was ist los?"

    # say L81 mik
    old "Apparently, she did really poorly on the last set of exams we took."
    new "Scheint, sie hat die letzten Klausuren total vermasselt."

    # say L83 mik
    old "And now she's blaming me!"
    new "Und jetzt macht sie mich dafür verantwortlich!"

    # say L84 mik
    old "Like it's my fault..."
    new "Als ob es meine Schuld wäre..."

    # say L86 pla
    old "Well, you did promise her you'd help her with her exams."
    new "Na ja, du hast ihr versprochen, ihr bei den Prüfungen zu helfen."

    # say L87 pla
    old "But you didn't really follow through..."
    new "Aber du hast es nicht wirklich durchgezogen..."

    # say L89 mik
    old "W- well, t- that's just because..."
    new "W-was ist einfach nur, weil..."

    # say L91 mik
    old "I don't know, man, I really helped her!"
    new "Ich weiß nicht, Mann, ich hab ihr echt geholfen!"

    # say L92 mik
    old "I- I mean, I even got good grades, man!"
    new "I- Ich meine, ich hab sogar gute Noten bekommen, Mann!"

    # say L93 pla
    old "Well, yeah, but it doesn't matter how well you did."
    new "Na ja, aber es spielt keine Rolle, wie gut du warst."

    # say L94 pla
    old "What matters is that she didn't do well."
    new "Was zählt, ist, dass sie es nicht gut gemacht hat."

    # say L96 pla
    old "I think you just didn't know how to explain the subjects to her."
    new "Ich denke, du hast einfach nicht gewusst, wie du ihr die Themen erklären sollst."

    # say L97 mik
    old "Alright! You don't have to repeat what she said!"
    new "Okay! Du musst nicht immer wiederholen, was sie gesagt hat!"

    # say L99 mik
    old "Besides, I don't think you get to say anything to me, this is your fault after all."
    new "Außerdem, ich glaube, du hast hier gar nichts zu sagen, das ist schließlich deine Schuld."

    # say L100 pla
    old "Excuse me? What's that supposed to mean?"
    new "Entschuldigung? Was soll das heißen?"

    # say L101 mik
    old "What I said! You were supposed to explain the subjects to me so that I could help Olivia!"
    new "Was ich gesagt habe! Du solltest mir die Themen erklären, damit ich Olivia helfen konnte!"

    # say L103 mik
    old "But look at the results she got."
    new "Aber schau dir ihre Noten an."

    # say L105 pla
    old "That has nothing to do with me!"
    new "Das hat nichts mit mir zu tun!"

    # say L106 pla
    old "If she didn't learn anything, it's just because you're such a shit teacher!"
    new "Wenn sie nichts gelernt hat, dann nur, weil du ein beschissener Lehrer bist!"

    # say L108 pla
    old "Maybe you should've taught her properly instead of spending your time staring at her tits."
    new "Vielleicht hättest du sie richtig unterrichten sollen anstatt die ganze Zeit auf ihre Titten zu starren."

    # say L110 mik
    old "Yeah well, whatever the reason is, she's super angry with me now."
    new "Na ja, egal aus welchem Grund, sie ist jetzt total sauer auf mich."

    # say L112 mik
    old "If she fails the coming exams, that's going to really suck, man."
    new "Wenn sie die kommenden Klausuren vermasselt, wird das echt Scheiße, Mann."

    # say L113 pla
    old "Well, it would be bad, but she'll have other chances to pass."
    new "Na ja, es wäre schlecht, aber sie hat noch andere Chancen, zu bestehen."

    # say L115 mik
    old "What? That's not what I mean, dude."
    new "Was? Das meinte ich doch gar nicht, Mann."

    # say L117 mik
    old "If she fails, she'll just blame me, and I won't be able to move forward with her."
    new "Wenn sie durchfällt, wird sie mir die Schuld geben, und ich kann mit ihr nicht weiterkommen."

    # say L119 mik
    old "I'm so close to hooking up with her, dude, so close."
    new "Ich bin so nah dran, mit ihr zu schlafen, Alter, so nah."

    # say L120 mik
    old "She was just about to let me hit it, and now this."
    new "Sie war gerade dabei, mich ranlassen, und jetzt das."

    # say L121 pla
    old "... Sure, dude."
    new "Klar, Alter."

    # say L126 pla
    old "Hey, come on, let's go to class."
    new "Hey, komm schon, lass uns zur Stunde gehen."

    # say L127 pla
    old "You can keep worrying about this later."
    new "Du kannst dir später Sorgen machen."

    # say L129 mik
    old "Yeah... Okay."
    new "Klar... Okay."

    # say L160 oli
    old "Hey [pla]! Wait!"
    new "Hey [pla]! Warte mal!"

    # say L171 pla
    old "Uh, yeah? Do you need something?"
    new "Uh, ja? Brauchst du was?"

    # say L174 oli
    old "Yeah, I need to talk to you about something."
    new "Ja, ich muss mit dir über was reden."

    # say L175 pla
    old "Uh... Alright, what is it?"
    new "Uh... Okay, was ist los?"

    # say L177 oli
    old "Well, as you probably already know."
    new "Na ja, wie du wahrscheinlich schon weißt."

    # say L179 oli
    old "I've been having some problems with my grades lately."
    new "Na ja, wie du wahrscheinlich schon weißt, habe ich in letzter Zeit ein paar Probleme mit meinen Noten."

    # say L180 pla
    old "Hmph, I mean... I haven't really paid attention to what you've been doing or anything..."
    new "Hmpf, ich meine... Ich hab' nicht wirklich aufgepasst, was du so machst oder so..."

    # say L182 oli
    old "Oh please, don't pretend you haven't talked with that dumbass Mike."
    new "Oh bitte, tu nicht so, als hättest du nicht mit diesem Idioten Mike gesprochen."

    # say L183 oli
    old "I know he told you about him giving me lessons in the subjects I'm failing, so don't play dumb."
    new "Ich weiß, dass er dir von den Nachhilfestunden erzählt hat, bei denen ich durchfalle, also tu nicht so, als ob du nichts wüsstest."

    # say L185 pla
    old "Well, he did mention something about that."
    new "Na ja, er hat schon was davon erwähnt."

    # say L186 pla
    old "But what about it?"
    new "Aber was ist damit?"

    # say L188 oli
    old "The thing is, I haven't really learned much of anything."
    new "Das Problem ist, ich hab da eigentlich nichts gelernt."

    # say L189 oli
    old "Because he's so fucking bad at teaching!"
    new "Weil er einfach beschissen darin ist, zu unterrichten!"

    # say L191 oli
    old "But on the last exams, I did notice his grades got better."
    new "Aber bei den letzten Klassenarbeiten habe ich bemerkt, dass seine Noten besser wurden."

    # say L193 oli
    old "I thought that was strange, very strange."
    new "Das fand ich seltsam, sehr seltsam."

    # say L195 oli
    old "While spending time with him, I realized he's not the brightest guy."
    new "Während ich Zeit mit ihm verbracht habe, habe ich gemerkt, dass er nicht der Hellste ist."

    # say L197 oli
    old "Actually, he's a fucking idiot!"
    new "Eigentlich ist er ein beschissener Idiot!"

    # say L199 pla
    old "Okay, okay, but what does this have to do with me?"
    new "Okay, okay, aber was hat das mit mir zu tun?"

    # say L201 oli
    old "As I told you, spending time with your friend made me realize he's a fucking idiot."
    new "Wie ich dir schon sagte, hat mir der Zeit mit deinem Freund gezeigt, dass er ein verdammter Idiot ist."

    # say L203 oli
    old "It just didn't make sense to me that he would suddenly make such an improvement in his grades."
    new "Mir war einfach nicht klar, warum er plötzlich so einen Sprung in seinen Noten machen sollte."

    # say L205 oli
    old "So, I met him under the pretense that it was a date."
    new "Also, ich hab ihn unter dem Vorwand getroffen, dass es ein Date ist."

    # say L207 oli
    old "And I pushed him until he spilled the beans about how he'd suddenly managed to get good grades in the exams."
    new "Und ich habe ihn bedrängt, bis er mir verraten hat, wie er plötzlich bessere Noten geschafft hat."

    # say L209 oli
    old "After a while, he confessed that he wasn't any good at studying."
    new "Nach einer Weile hat er gestanden, dass er gar nicht gut im Lernen war."

    # say L211 oli
    old "But that it was thanks to YOU that he was able to get better grades."
    new "Aber dass es deinetwegen war, dass er bessere Noten bekommen hat."

    # say L212 pla
    old "T- that's what he told you?"
    new "D-das hat er dir gesagt?"

    # say L213 oli
    old "He did! And I should've known from the start that his grades didn't get better because of him!"
    new "Hat er! Und ich hätte gleich wissen müssen, dass seine Noten nicht besser geworden sind, weil er es geschafft hat!"

    # say L215 oli
    old "But anyway, that's not what I care about."
    new "Aber egal, das ist mir egal."

    # say L217 oli
    old "Because I'm still stuck with my bad grades."
    new "Weil ich immer noch mit meinen schlechten Noten sitze."

    # say L219 oli
    old "I got to thinking about it."
    new "Ich hab drüber nachgedacht."

    # say L225 oli
    old "Well, if you were able to teach that dumbass Mike enough to get good scores on the exams."
    new "Na ja, wenn du diesem Idioten Mike genug beigebracht hast, um gute Noten bei den Klausuren zu kriegen."

    # say L227 oli
    old "You should be more than capable of bringing me to the top of the class."
    new "Du solltest mehr als fähig sein, mich an die Spitze der Klasse zu bringen."

    # say L229 pla
    old "Yeah, I mean, thanks for the compliment."
    new "Ja, also, danke für das Kompliment."

    # say L231 pla
    old "But, why would I do that?"
    new "Aber warum sollte ich das tun?"

    # say L235 pla
    old "In case you don't remember, every time you and Ruby are around."
    new "Falls du dich nicht erinnerst, jedes Mal, wenn du und Ruby in der Nähe seid."

    # say L236 pla
    old "You attack and bully my friends and me. The only thing you know how to do is be rude to us."
    new "Du greifst meine Freunde und mich an und bist nur unhöflich zu uns."

    # say L238 pla
    old "Especially towards Belle and Hinn."
    new "Vor allem gegenüber Belle und Hinn."

    # say L240 pla
    old "So no, I think I'll pass."
    new "Dann nein, ich glaube, ich passe."

    # say L245 oli
    old "So that's how it is... Either way, you HAVE to help me whether you like it or not."
    new "Dann ist es so... Auf jeden Fall musst du mir helfen, ob dir das passt oder nicht."

    # say L247 pla
    old "And why would that be?"
    new "Und warum sollte das so sein?"

    # say L249 oli
    old "I'll tell you why."
    new "Dann sag ich dir warum."

    # say L253 oli
    old "You better help me, or I'll spill what I know."
    new "Du solltest mir besser helfen, sonst werde ich ausplaudern, was ich weiß."

    # say L254 oli
    old "And everyone will know just what kind of guy you are and the stuff you’re up to."
    new "Und alle werden genau wissen, was für ein Typ du bist und was du so treibst."

    # say L265 pla
    old "But I want to make something clear."
    new "Aber ich will eines klarstellen."

    # say L267 pla
    old "If I do this, you can't bring it up ever again, no matter what."
    new "Wenn ich das mache, darfst du es nie wieder erwähnen, egal was passiert."

    # say L269 pla
    old "SO, after I'm done helping you, you can't tell anyone about it!"
    new "Also, nachdem ich dir geholfen habe, darfst du niemandem davon erzählen!"

    # say L271 pla
    old "Are we clear?"
    new "Sind wir uns klar?"

    # say L272 oli
    old "Sure, I don't care about you or what you're doing."
    new "Klar, mir ist es egal, was du machst."

    # say L273 oli
    old "So I won't tell anyone."
    new "Dann werde ich niemandem was sagen."

    # say L275 oli
    old "But that's only if I do well on the exams."
    new "Aber das ist nur, wenn ich gut in den Klausuren abschneide."

    # say L277 oli
    old "So you better outdo Mike, for your own sake."
    new "Dann solltest du besser Mike übertrumpfen, für dein eigenes Wohl."

    # say L280 pla
    old "Hmph, sure."
    new "Hmpf, klar."

    # say L282 pla
    old "So... Should I go to your house?"
    new "Dann... Soll ich zu deinem Haus kommen?"

    # say L283 oli
    old "No, today's not a good day."
    new "Nein, heute ist nicht der richtige Tag."

    # say L285 oli
    old "There are a couple of things I have to deal with at home."
    new "Es gibt ein paar Dinge, die ich zu Hause regeln muss."

    # say L286 oli
    old "Just keep your schedule open for now, and I'll let you know when we can start."
    new "Lass dein Terminplan offen, ich sage dir Bescheid, wann wir anfangen können."

    # say L287 pla
    old "Hmm, alright..."
    new "Hmm, okay..."

    # say L289 oli
    old "Ok, see you later then. Bye."
    new "Ok, dann sehen wir uns später. Tschüss."

    # say L297 pla
    old "{b}*Sigh*{/b} This is something I wasn't expecting."
    new "{b}*Seufz*{/b} Das ist was ich nicht erwartet habe."

    # say L298 pla
    old "What a fucking situation this is..."
    new "Was für eine beschissene Situation das ist..."

    # say L301 pla
    old "{b}*Sigh*{/b} I guess I'll head home."
    new "{b}*Sigh*{/b} Ich denke, ich geh dann mal nach Hause."

    # say L313 pla
    old "Oh, h- hi dude, what's up?"
    new "Oh, h-hi, was ist los?"

    # say L315 mik
    old "I'm alright, but hey, don't dodge the question."
    new "Ich bin okay, aber hey, vermeide die Frage nicht."

    # say L317 mik
    old "What were you doing talking to my girl?"
    new "Was hast du gemacht, als du mit meiner Freundin geredet hast?"

    # say L319 mik
    old "Are you trying to snatch her from me?"
    new "Versuchst du, sie mir wegzuschnappen?"

    # say L320 pla
    old "{i}(Snatch her from him? So... He still thinks he has a chance with her? Is he serious?){/i}"
    new "{i}(Sie mir wegschnappen? Also... Er denkt immer noch, dass er eine Chance bei ihr hat? Ist er ernsthaft?){/i}"

    # say L321 pla
    old "It's not what you think, dude. She was just asking me for my notes from class."
    new "Das ist nicht so, wie du denkst, Mann. Sie hat mich nur nach meinen Klassennotizen gefragt."

    # say L324 pla
    old "Well, I think she just wants to do some extra studying, and she asked for my notes."
    new "Na ja, ich denke, sie will einfach ein bisschen mehr lernen und hat meine Notizen gefragt."

    # say L326 mik
    old "And why your notes? She could've asked for mine..."
    new "Und warum deine Notizen? Sie hätte sich auch meine holen können..."

    # say L327 pla
    old "Your notes? Do you even have any notes?"
    new "Deine Notizen? Hast du überhaupt welche?"

    # say L329 pla
    old "Did you even bring a notebook today?"
    new "Hast du heute überhaupt ein Heft mitgebracht?"

    # say L331 mik
    old "Well, I- I didn't."
    new "Na ja, ich hab' keine mitgebracht."

    # say L332 mik
    old "I understand, dude, but still, I hope you're not thinking of using this to take my girl away from me!"
    new "Ich versteh schon, Alter, aber trotzdem, ich hoffe, du willst damit nicht meine Freundin abstecken!"

    # say L333 pla
    old "Don't worry, dude..."
    new "Keine Sorge, Mann..."

    # say L334 pla
    old "I assure you that's not on my mind."
    new "Ich verspreche dir, das ist nicht meine Absicht."

    # say L336 mik
    old "Alright, I'll believe you."
    new "Okay, ich glaube dir."

    # say L337 mik
    old "We're pretty close, you know?"
    new "Wir sind ziemlich eng, oder?"

    # say L338 mik
    old "In no time she'll be mine, don't doubt it."
    new "In null Zeit gehört sie mir, da kannst du Gift drauf nehmen."

    # say L339 pla
    old "Sure dude, no doubt..."
    new "Klar, Alter, daran hab ich keinen Zweifel."

    # say L345 pla
    old "Anyway, I have to go home now, are you leaving too?"
    new "Jedenfalls, ich muss jetzt nach Hause, gehst du auch?"

    # say L347 mik
    old "Yeah sure, let's go."
    new "Klar, lass uns gehen."

    # say L375 pla
    old "Oh, damn, I'm really late. Has the class already ended?"
    new "Oh, verdammt, ich bin echt spät dran. Ist die Stunde schon zu Ende?"

    # say L395 rub
    old "Oh, look who decided to show up. Class ended a while ago, dumbass."
    new "Oh, guck mal, wer sich endlich blicken lässt. Die Stunde ist schon lange vorbei, Depp."

    # say L396 pla
    old "Oh crap, I totally lost track of time..."
    new "Oh Mist, ich hab total die Zeit vergessen..."

    # say L397 rub
    old "Really? I hadn't noticed. It's not like anyone wants to see your ugly face around here."
    new "Wirklich? Das war mir gar nicht aufgefallen. Als ob jemand dein hässliches Gesicht hier sehen will."

    # say L398 pla
    old "{b}*Sigh*{/b} Really? Do you want to do this now?"
    new "{b}*Seufz*{/b} Wirklich? Willst du das jetzt machen?"

    # say L399 rub
    old "What? Not feeling brave without your little friends around?"
    new "Was? Fühlst du dich ohne deine kleinen Freunde nicht mutig genug?"

    # say L401 pla
    old "You know? I don't have time to deal with you right now."
    new "Du weißt doch, ich habe jetzt keine Zeit, mich mit dir zu beschäftigen."

    # say L411 rub
    old "Can you believe that loser?"
    new "Kannst du das glauben? Was für ein Verlierer."

    # say L412 oli
    old "Yeah... What an idiot."
    new "Ja... Was für ein Idiot."

    # say L413 oli
    old "Hey, listen, I think we'll have to cancel our plans for today."
    new "Hey, hör mal, ich glaube, wir müssen unsere Pläne für heute absagen."

    # say L416 rub
    old "I thought you wanted to meet those cute guys today."
    new "Ich dachte, du willst heute die süßen Jungs treffen."

    # say L418 oli
    old "I do! I really do."
    new "Ich will! Ich will echt."

    # say L419 oli
    old "But I just remembered my mom needs me to help her with some stuff at home."
    new "Aber ich hab gerade dran gedacht, dass meine Mum mich zu Hause braucht."

    # say L420 oli
    old "So I have to go home early."
    new "Dann muss ich früher nach Hause."

    # say L422 rub
    old "Hmm, alright, I guess that's okay."
    new "Hmm, okay, ich schätze, das ist in Ordnung."

    # say L423 rub
    old "I guess I'll be hanging out with the guys by myself."
    new "Dann hänge ich wohl alleine mit den Jungs ab."

    # say L424 oli
    old "Sure, but next time I'll definitely be going out with you guys."
    new "Klar, aber beim nächsten Mal gehe ich definitiv mit euch aus."

    # say L426 rub
    old "Alright, I guess that's fine."
    new "Okay, das ist in Ordnung."

    # say L446 pla
    old "Yeah?"
    new "Klar?"

    # say L448 oli
    old "Listen, I was thinking today could be a good day for you to come over."
    new "Hör mal, ich dachte, heute könnte ein guter Tag sein, um vorbeizukommen."

    # say L449 oli
    old "So we can start studying."
    new "Dann können wir mit dem Lernen anfangen."

    # say L450 pla
    old "W- what... Now?"
    new "W-was... Jetzt?"

    # say L452 oli
    old "Yes, why? I told you to clear your schedule."
    new "Ja, warum? Ich hab dir doch gesagt, dass du deinen Terminplan freiräumen sollst."

    # say L453 pla
    old "No, no, you just caught me off guard."
    new "Nein, nein, du hast mich nur überrascht."

    # say L454 oli
    old "Well, you don't have to come if you don't want to."
    new "Na ja, du musst nicht kommen, wenn du nicht willst."

    # say L456 oli
    old "That is, if you don't care about everyone knowing you're fucking Mike's mom."
    new "Das heißt, wenn dir egal ist, dass alle erfahren, dass du Mikes Mom fickst."

    # say L458 pla
    old "{b}*Sigh*{/b} Alright, let's go to your house."
    new "{b}*Seufz*{/b} Okay, lass uns zu deinem Haus gehen."

    # say L481 oli
    old "Oh, m- mom, you're here."
    new "Oh, m- Mama, du bist hier."

    # say L483 oli
    old "I- I thought you were going to be out this afternoon."
    new "Ich dachte, du wolltest heute Nachmittag weg sein."

    # say L484 vee
    old "That was the plan, but the appointment got canceled, so I just came back home."
    new "Das war der Plan, aber der Termin wurde abgesagt, deshalb bin ich einfach wieder nach Hause gekommen."

    # say L486 vee
    old "But anyway honey, who's your friend here? Aren't you going to introduce me to him?"
    new "Aber egal, Schatz, wer ist dein Freund hier? Wirst du mich ihm nicht vorstellen?"

    # say L488 oli
    old "Well... Yeah."
    new "Na ja... Ja."

    # say L489 oli
    old "His name is [pla], he's a friend from school."
    new "Sein Name ist [pla], er ist ein Freund von der Schule."

    # say L494 oli
    old "[pla], this is my mother, her name's Priya."
    new "[pla], das ist meine Mutter, sie heißt Priya."

    # say L498 pla
    old "Hello Mrs. Priya, nice to meet you."
    new "Hallo Mrs. Priya, schön Sie kennenzulernen."

    # say L500 vee
    old "Nice to meet you too, [pla]."
    new "Nett, dich kennenzulernen, [pla]."

    # say L502 oli
    old "[pla]'s going to help me study some topics for school."
    new "[pla] wird mir helfen, ein paar Themen für die Schule zu lernen."

    # say L504 oli
    old "You know, some exams are coming up, and I want to do well."
    new "Du weißt ja, bald sind Prüfungen dran, und ich will gut abschneiden."

    # say L507 oli
    old "And [pla] here is a great student. He always gets top grades."
    new "Und [pla] hier ist ein großartiger Schüler. Er kriegt immer die besten Noten."

    # say L509 oli
    old "So I asked him to help me."
    new "Dann hab ich ihn gebeten, mir zu helfen."

    # say L510 vee
    old "Oh, that's so good to hear, honey!"
    new "Oh, das ist ja toll zu hören, Schatz!"

    # say L513 vee
    old "I'm so glad you're finally taking your studies seriously."
    new "Ich bin so froh, dass du endlich dein Studium ernst nimmst."

    # say L514 vee
    old "Your father's going to be very pleased if you do well in school, you know that."
    new "Dein Vater wird sehr stolz auf dich sein, wenn du gut in der Schule bist, das weißt du."

    # say L517 oli
    old "Yeah, yeah, I know what he wants..."
    new "Ja, ja, ich weiß, was er will..."

    # say L519 vee
    old "Honey, don't take that attitude."
    new "Schatz, nimm das nicht so."

    # say L522 vee
    old "I know your father can be hard to deal with sometimes."
    new "Ich weiß, dass dein Vater manchmal schwer zu ertragen sein kann."

    # say L525 vee
    old "But you have to understand that he just wants what's best for you."
    new "Aber du musst verstehen, dass er nur das Beste für dich will."

    # say L527 vee
    old "As do I."
    new "Das tue ich auch."

    # say L529 vee
    old "So, I'm very happy to see you making an effort to improve your grades."
    new "Dann bin ich sehr froh, dass du dich bemühst, deine Noten zu verbessern."

    # say L530 oli
    old "Yeah... Thank you."
    new "Ja... Danke."

    # say L535 oli
    old "Hey mom, [pla] and I are going to study in my room, alright?"
    new "Hey Mum, [pla] und ich werden in meinem Zimmer lernen, okay?"

    # say L537 vee
    old "Sure thing, sweetie."
    new "Klar, Schatz."

    # say L550 oli
    old "I'm sorry you had to see that."
    new "Es tut mir leid, dass du das sehen musstest."

    # say L552 oli
    old "I wasn't expecting my mom to be here."
    new "Ich habe nicht damit gerechnet, dass meine Mom hier ist."

    # say L554 pla
    old "It's okay."
    new "Ist schon gut."

    # say L556 pla
    old "You don't have to apologize."
    new "Du musst dich nicht entschuldigen."

    # say L559 oli
    old "Anyway, I guess it's a good thing she met you right away."
    new "Na ja, dann ist es wahrscheinlich gut, dass sie dich gleich getroffen hat."

    # say L561 oli
    old "That will make things easier in the future."
    new "Das wird die Dinge in Zukunft erleichtern."

    # say L564 oli
    old "So, should we get to it?"
    new "Dann mal los?"

    # say L574 pla
    old "Okay, let's start with this topic."
    new "Okay, fangen wir mit diesem Thema an."

    # say L575 pla
    old "And we'll work our way to the others. Alright?"
    new "Und wir arbeiten uns zu den anderen durch. Okay?"

    # say L577 oli
    old "Uhh... Sure, whatever you say."
    new "Uhh... Klar, wie du meinst."

    # say L585 pla
    old "See? This is the right way to prove that result."
    new "Siehst du? Das ist der richtige Weg, um dieses Ergebnis zu beweisen."

    # say L587 oli
    old "I see, that makes a lot of sense."
    new "Das ergibt Sinn, stimmt."

    # say L589 pla
    old "Alright, I think we can move on to the next topic!"
    new "Okay, ich denke, wir können zum nächsten Thema übergehen!"

    # say L595 pla
    old "I never could have guessed you'd be so good at this, you know?"
    new "Ich hätte nie gedacht, dass du so gut darin bist, weißt du?"

    # say L597 oli
    old "I know, everyone assumes that just because I'm pretty and popular, I'm just an airhead..."
    new "Ich weiß, alle denken, nur weil ich hübsch und beliebt bin, bin ich ein Flachpfeifer..."

    # say L599 oli
    old "But everyone is wrong, I'm not dumb at all..."
    new "Aber alle liegen falsch, ich bin gar nicht dumm..."

    # say L601 oli
    old "Even if it doesn't look like it, I do pay attention, just to what really interests me."
    new "Auch wenn es nicht so aussieht, ich bin durchaus aufmerksam, nur eben für das, was mich wirklich interessiert."

    # say L602 pla
    old "Uhh... What do you mean?"
    new "Uhh... Was meinst du damit?"

    # say L604 oli
    old "Well, I want to be a fashion designer, and for that, I don't need to memorize differential calculus formulas, you know what I mean?"
    new "Na ja, ich will Mode Designerin werden, und dafür brauche ich keine Differentialrechnungsformeln auswendig zu können, verstehst du?"

    # say L606 pla
    old "Hmm, so why do you want to improve your grades now?"
    new "Hmm, warum willst du jetzt plötzlich deine Noten verbessern?"

    # say L607 pla
    old "Is it because of what you were talking to your mom about your dad?"
    new "Ist es wegen dem, worüber du mit deiner Mum über deinen Dad geredet hast?"

    # say L609 oli
    old "Hmm, well, yeah... Something like that."
    new "Hmm, ja, so was in der Art..."

    # say L611 oli
    old "But wait!"
    new "Aber warte!"

    # say L613 oli
    old "What does this have to do with you?"
    new "Was hat das mit dir zu tun?"

    # say L615 oli
    old "How about we stop with the questions and get back to studying?"
    new "Lass uns mit den Fragen aufhören und wieder lernen."

    # say L617 pla
    old "Hmm, yeah right, let's keep going."
    new "Hmm, ja klar, lass uns weitermachen."

    # say L627 pla
    old "Alright, it was just our first session, but we got a lot done."
    new "Okay, es war nur unsere erste Session, aber wir haben viel geschafft."

    # say L628 pla
    old "We're very short on time."
    new "Wir haben sehr wenig Zeit."

    # say L630 pla
    old "But I think at this pace, we should be able to cover everything we need to before the exams."
    new "Aber ich denke, bei diesem Tempo schaffen wir es, alles vor den Prüfungen zu klären."

    # say L640 aye
    old "Hey sis, can I borrow your blue dress today for a- "
    new "Hey Schwester, kannst du mir dein blaues Kleid heute leihen für ein-"

    # say L642 aye
    old "Oh, I didn't know you had company..."
    new "Oh, ich wusste gar nicht, dass du Besuch hast..."

    # say L643 aye
    old "What were you two doing in here? Does Dad know you're bringing boys into your room?"
    new "Was habt ihr beiden hier drin gemacht? Weiß Dad, dass du Jungs in dein Zimmer bringst?"

    # say L645 oli
    old "We were studying... And it's none of your business..."
    new "Wir haben gelernt... Und das geht dich nichts an..."

    # say L646 aye
    old "Oh Olivia, where are your manners? You should introduce us."
    new "Oh Olivia, wo sind deine Manieren? Du solltest uns vorstellen."

    # say L647 aye
    old "Hi, my name is Ayeshaa, nice to meet you."
    new "Hi, ich bin Ayeshaa, schön dich kennenzulernen."

    # say L649 pla
    old "Uhh, hi, nice to meet you too, my name's [pla]."
    new "Uhh, hallo, freut mich auch, mein Name ist [pla]."

    # say L652 oli
    old "Alright, alright, what have I told you about coming into my room unannounced?"
    new "Okay, okay, was habe ich dir über das Unangemeldet reinspazieren in mein Zimmer gesagt?"

    # say L654 aye
    old "I just wanted to see if you could let me borrow the dress—"
    new "Ich wollte nur sehen, ob du mir das Kleid leihen kannst –"

    # say L656 oli
    old "No, you can't borrow my blue dress."
    new "Nein, du darfst mein blaues Kleid nicht leihen."

    # say L658 oli
    old "Now get the hell out of here."
    new "Dann verschwinde jetzt hier."

    # say L660 aye
    old "Ugh, why do you always have to have that nasty attitude?!"
    new "Mann, warum musst du immer so eine schlechte Laune haben?!"

    # say L663 aye
    old "You know what? I actually hope you screw up your grades..."
    new "Du weißt was? Ich hoffe echt, dass du deine Noten versaust..."

    # say L666 aye
    old "So dad will take you to India with him!"
    new "Dann wird Papa dich mit nach Indien nehmen!"

    # say L668 aye
    old "Maybe then you'll learn some humility."
    new "Vielleicht lernst du dann ein bisschen Bescheidenheit."

    # say L670 aye
    old "Alright, alright!"
    new "Okay, okay!"

    # say L671 aye
    old "Bye, cutie."
    new "Tschüss, Schatz."

    # say L672 pla
    old "B- bye..."
    new "B- bis dann..."

    # say L679 oli
    old "I'm sorry about that."
    new "Es tut mir leid dafür."

    # say L681 oli
    old "She's just a brat, and my mom always lets her get away with everything, that's why she acts like that."
    new "Sie ist einfach ein Gör, und meine Mom lässt sie immer damit durchkommen, deshalb benimmt sie sich so."

    # say L683 pla
    old "Uhh... S- sure, no problem."
    new "Uhh... S-sicher, kein Problem."

    # say L684 pla
    old "Uhmm, by the way, w- what she said about you going to India..."
    new "Ähm, übrigens, w- was sie über dich nach Indien gesagt hat..."

    # say L686 oli
    old "I told you! I'm not talking about that!"
    new "Ich hab's dir doch gesagt! Davon rede ich nicht!"

    # say L690 oli
    old "Anyway, I think we were done studying for today, right?"
    new "Na ja, ich denke, wir haben für heute genug gelernt, oder?"

    # say L692 pla
    old "Uhh, yeah, we made good progress today, but we still have more to do. You need to get a high grade to boost your average..."
    new "Uhh, ja, wir haben heute gute Fortschritte gemacht, aber es gibt noch mehr zu tun. Du musst eine hohe Note kriegen, um deinen Durchschnitt zu verbessern..."

    # say L693 pla
    old "I know you're worried, but I think we can handle it."
    new "Ich weiß, dass du dir Sorgen machst, aber ich denke, wir kriegen das hin."

    # say L695 oli
    old "If you say so..."
    new "Wenn du meinst..."

    # say L697 pla
    old "Alright, I think I have to go. So, are afternoons good for you to keep studying?"
    new "Okay, ich denke, ich muss los. Also, passt es dir nachmittags, um weiter zu lernen?"

    # say L699 oli
    old "Right, make sure to come by my house in the afternoons. Don't miss it, or you know what will happen..."
    new "Okay, komm nachmittags zu mir. Vergiss es bloß nicht, oder du weißt, was passiert..."

    # say L700 pla
    old "Yeah, sure, you don't have to remind me."
    new "Klar, musst du mich nicht daran erinnern."

    # say L701 pla
    old "Anyway, see you later."
    new "Na ja, bis später."

    # say L703 oli
    old "Ok, see you."
    new "Ok, bis später."

    # say L721 oli
    old "Hey, I was waiting for you. You’re here to help me study, right?"
    new "Hey, ich hab auf dich gewartet. Du bist hier, um mir beim Lernen zu helfen, oder?"

    # say L722 pla
    old "Yeah, I'm here to keep working on the stuff we still need to cover."
    new "Klar, ich bin hier, um weiterzumachen mit dem Zeug, das wir noch durchgehen müssen."

    # say L724 oli
    old "Great! I was getting worried you might take too long to come back."
    new "Super! Ich hab schon gedacht, du brauchst ewig, um zurückzukommen."

    # say L726 oli
    old "Let's not waste any time and get started."
    new "Lass uns keine Zeit verlieren und gleich loslegen."

    # say L727 pla
    old "Alright, let's continue where we left off last time."
    new "Okay, lass uns da weitermachen, wo wir letztes Mal aufgehört haben."

    # say L729 oli
    old "Sure, let's do it."
    new "Klar, lass uns anfangen."

    # say L758 pla
    old "Alright, I think that's enough for today."
    new "Okay, ich denke, das reicht für heute."

    # say L759 pla
    old "We still have some other things to cover, but I'll be back soon so we can continue with what's left."
    new "Wir haben noch ein paar andere Dinge zu besprechen, aber ich komme bald wieder, dann können wir mit dem Rest weitermachen."

    # say L760 pla
    old "And then we can move on to the next topic."
    new "Und dann können wir zum nächsten Thema übergehen."

    # say L762 oli
    old "Alright, sure, thanks for coming."
    new "Okay, klar, danke dass du gekommen bist."

    # say L763 oli
    old "I'll see you soon."
    new "Bis bald."

    # say L795 vee
    old "Hi [pla]! Good morning!"
    new "Hi [pla]! Guten Morgen!"

    # say L796 pla
    old "Hi Mrs. Priya, how are you today?"
    new "Hi Mrs. Priya, wie geht es Ihnen heute?"

    # say L798 vee
    old "I'm doing alright sweetheart."
    new "Ich bin okay, Schatz."

    # say L799 vee
    old "Honey, did you come to see Olivia?"
    new "Schatz, bist du gekommen, um Olivia zu sehen?"

    # say L800 vee
    old "Because right now it's time for school."
    new "Denn jetzt ist es Zeit für die Schule."

    # say L802 vee
    old "Shouldn't you be there?"
    new "Solltest du da nicht sein?"

    # say L803 pla
    old "Oh, yeah, Mrs. Priya, I just have the day off school to run a couple of errands."
    new "Oh, ja, Mrs. Priya, ich habe heute frei und muss ein paar Besorgungen machen."

    # say L804 pla
    old "And I wanted to say hi."
    new "Und ich wollte Hallo sagen."

    # say L805 vee
    old "I see, I'm glad to see you dear."
    new "Ich sehe, ich freue mich, dich zu sehen, Liebling."

    # say L806 vee
    old "I'll be sure to tell Olivia you stopped by."
    new "Ich werde Olivia sicher sagen, dass du vorbeigeschaut hast."

    # say L808 pla
    old "Alright, thanks ma'am."
    new "Okay, danke Frau Vee."

    # say L811 vee
    old "Hello, [pla]!"
    new "Hallo, [pla]!"

    # say L812 pla
    old "Hi, Mrs. Priya!"
    new "Hallo, Frau Priya!"

    # say L814 vee
    old "It's good to see you, dear. How are you today?"
    new "Schön, dich zu sehen, Liebling. Wie geht es dir heute?"

    # say L816 pla
    old "I'm fine, Mrs. Priya, and you?"
    new "Mir geht es gut, Mrs. Priya, und dir?"

    # say L818 vee
    old "I'm doing alright, dear. Keeping busy as usual, thanks for asking."
    new "Ich bin gut drauf, Lieber. Wie immer beschäftigt, danke fürs Nachfragen."

    # say L819 vee
    old "Tell me, did you come to see Olivia?"
    new "Erzähl mir, bist du gekommen, um Olivia zu sehen?"

    # say L823 vee
    old "Great! She's in her bedroom right now, dear."
    new "Prima! Sie ist gerade in ihrem Schlafzimmer, Liebling."

    # say L824 vee
    old "Don't mind me, you can go right in."
    new "Mach dir nichts draus, du kannst gleich reingehen."

    # say L826 pla
    old "Thanks, Mrs. Priya. I'll catch up with you later."
    new "Danke, Mrs. Priya. Ich sehe dich später."

    # say L828 vee
    old "That's alright, dear. Nice seeing you."
    new "Das ist in Ordnung, Liebling. Schön, dich zu sehen."

    # say L829 vee
    old "And if you kids need anything, just let me know."
    new "Und wenn ihr Kinder was braucht, sagt Bescheid."

    # say L840 pla
    old "Alright, that's it, that's the right method."
    new "Alles klar, das ist die richtige Methode."

    # say L842 pla
    old "Great, you got it!"
    new "Super, du hast es geschafft!"

    # say L844 pla
    old "You know, we're making very good progress."
    new "Wir machen echt gute Fortschritte."

    # say L846 pla
    old "At this rate we'll manage to go over every topic before the exams."
    new "Bei diesem Tempo schaffen wir es, alle Themen vor den Prüfungen durchzugehen."

    # say L847 oli
    old "Yeah, ok... Great."
    new "Ja, okay... Toll."

    # say L849 pla
    old "That doesn't seem like you're too sure about it."
    new "Das klingt nicht so, als wärst du dir sicher."

    # say L856 oli
    old "I just feel like this isn't working [pla]."
    new "Ich hab einfach das Gefühl, dass das nicht funktioniert [pla]."

    # say L858 oli
    old "You just said that you think we'll be able to tackle every topic before the exams."
    new "Du hast gerade gesagt, dass du denkst, wir werden vor den Klausuren jedes Thema schaffen."

    # say L860 oli
    old "But how well am I really going to do in them?"
    new "Aber wie gut werde ich da wirklich abschneiden?"

    # say L861 oli
    old "With so little time, there's only so much I can learn."
    new "Mit so wenig Zeit kann ich nur begrenzt was lernen."

    # say L863 pla
    old "Come on, don't be so negative."
    new "Komm schon, sei nicht so negativ."

    # say L865 pla
    old "I know what you mean. But it's worth giving it a shot."
    new "Ich verstehe, was du meinst. Aber es lohnt sich, es zu versuchen."

    # say L866 oli
    old "I know it is."
    new "Ich weiß."

    # say L868 oli
    old "It's just that when I see how much more we have to study."
    new "Es ist nur, wenn ich sehe, wie viel wir noch lernen müssen."

    # say L869 oli
    old "And the time that's left before the exams."
    new "Und die Zeit, die uns noch bleibt, bevor die Klausuren sind."

    # say L873 oli
    old "That was just a huge waste of time!"
    new "Das war einfach nur eine riesige Zeitverschwendung!"

    # say L874 pla
    old "Hey, hey, come on."
    new "Hey, hey, komm schon."

    # say L875 pla
    old "I understand how you feel, but let's not get discouraged."
    new "Ich verstehe, wie du dich fühlst, aber lass uns nicht entmutigen."

    # say L877 pla
    old "I'm sure you'll do well in these exams."
    new "Ich bin sicher, dass du gut abschneiden wirst bei den Klausuren."

    # say L879 pla
    old "I mean... Yeah, it would be very difficult to get perfect scores."
    new "Ich meine... Ja, es wäre sehr schwierig, perfekte Noten zu bekommen."

    # say L880 pla
    old "But I'm sure that if we keep studying at this pace, and with a little luck."
    new "Aber ich bin sicher, dass wenn wir so weiterlernen und ein bisschen Glück haben."

    # say L882 pla
    old "You'll get grades that are good enough for you to pass all the subjects."
    new "Du wirst Noten bekommen, die gut genug sind, um alle Fächer zu bestehen."

    # say L883 oli
    old "But that's the problem! I can't just get {i}‘passing grades'{/i}."
    new "Aber das ist ja gerade das Problem! Ich kann nicht einfach {i}«genügende Noten»{/i} bekommen."

    # say L885 oli
    old "If I don't get maximum grades, it won't be good enough!"
    new "Wenn ich nicht die besten Noten kriege, reicht es einfach nicht!"

    # say L887 pla
    old "Uh, ok?"
    new "Uh, okay?"

    # say L889 pla
    old "But why, though?"
    new "Aber warum denn?"

    # say L890 pla
    old "I mean, I understand that studying and grades are important."
    new "Ich meine, ich verstehe schon, dass Lernen und Noten wichtig sind."

    # say L892 pla
    old "But why is it so important to get the maximum grades?"
    new "Aber warum ist es so wichtig, die allerbesten Noten zu bekommen?"

    # say L900 oli
    old "I didn't want to tell you about this, but I guess it's better if you understand the full picture."
    new "Ich wollte dir das eigentlich nicht sagen, aber ich denke, es ist besser, wenn du die ganze Geschichte verstehst."

    # say L902 oli
    old "Listen, if I don't get maximum or top grades by the end of the term, I'll be sent to India to live with my dad."
    new "Hör zu, wenn ich bis zum Ende des Semesters keine maximalen oder besten Noten habe, werde ich nach Indien geschickt, um bei meinem Vater zu leben."

    # say L905 oli
    old "Well, you know my parents are from India, right?"
    new "Na, du weißt ja, dass meine Eltern aus Indien sind, oder?"

    # say L906 pla
    old "Hmm, yeah sure..."
    new "Hmm, klar..."

    # say L908 oli
    old "See, my father is still living there. He comes here often, but his business is located there."
    new "Siehst du, mein Vater lebt noch dort. Er kommt oft hierher, aber sein Geschäft ist dort."

    # say L909 oli
    old "While we stay here with my mother."
    new "Während wir hier bei meiner Mutter bleiben."

    # say L913 oli
    old "Well, my dad's a very traditional guy."
    new "Na ja, mein Dad ist ein sehr traditioneller Typ."

    # say L915 oli
    old "He cares a lot about upholding tradition and customs."
    new "Er legt großen Wert auf die Erhaltung von Traditionen und Bräuchen."

    # say L917 oli
    old "And since I'm the oldest daughter, he wants me to take part in a lot of those traditions."
    new "Und da ich die älteste Tochter bin, will er, dass ich an vielen davon teilnehme."

    # say L921 oli
    old "Without consulting me or letting me know about it!"
    new "Ohne mich zu fragen oder mich überhaupt zu informieren!"

    # say L922 pla
    old "Uh, I- I see."
    new "Uh, ich- ich sehe."

    # say L925 pla
    old "B- but, don’t you think if you talked to him, he’d understand you’re not in love with the guy he wants you to marry?"
    new "Aber, denkst du nicht, wenn du mit ihm redest, würde er verstehen, dass du dich nicht in den Typen verliebt hast, den er für dich ausgesucht hat?"

    # say L927 oli
    old "{b}*Sigh*{/b} Come on, be realistic."
    new "{b}*Seufz*{/b} Komm schon, sei realistisch."

    # say L929 oli
    old "Love has nothing to do with it [pla]."
    new "Liebe hat damit nichts zu tun [pla]."

    # say L931 oli
    old "The guy he engaged me to is the heir to a very successful company."
    new "Der Typ, den er mir vorgestellt hat, ist der Erbe eines sehr erfolgreichen Unternehmens."

    # say L932 oli
    old "He knows that by getting me married to him, he would get a big opportunity to do business."
    new "Er weiß, dass er durch unsere Ehe eine große Chance für Geschäfte bekommt."

    # say L934 oli
    old "He thinks that since I'm the oldest daughter, it is my duty to the family to go through with his plan!"
    new "Er denkt, dass es als älteste Tochter meine Pflicht gegenüber der Familie ist, seinen Plan durchzuziehen!"

    # say L935 pla
    old "B- but, isn't there anything that you can do?"
    new "Aber, gibt es denn nichts, was du tun kannst?"

    # say L937 oli
    old "Well, that's why I need to get good grades."
    new "Deshalb muss ich gute Noten kriegen."

    # say L939 oli
    old "My mom's a little more open-minded than my dad. She knows I don't want to live my life that way."
    new "Meine Mum ist ein bisschen offener als mein Dad. Sie weiß, dass ich nicht so leben will."

    # say L941 oli
    old "She's been supporting me, and interceding on my behalf with my dad."
    new "Sie unterstützt mich und spricht für mich mit meinem Dad."

    # say L943 oli
    old "That's been a huge problem between them, they've been fighting over it."
    new "Das war ein riesiges Problem zwischen ihnen, sie haben sich deswegen gestritten."

    # say L945 oli
    old "But my mom finally convinced him to let me off the hook if I get good grades by the end of the term."
    new "Aber meine Mom hat ihn schließlich überredet, mich laufen zu lassen, wenn ich bis zum Ende des Semesters gute Noten habe."

    # say L946 oli
    old "That's why I'm so desperate to get the highest scores! Because I really have to!"
    new "Deshalb bin ich so verzweifelt, die besten Noten zu kriegen! Denn ich muss es wirklich schaffen!"

    # say L948 pla
    old "I- I see. I understand."
    new "Ich- Ich verstehe. Ich sehe das ein."

    # say L949 pla
    old "I didn't know how important the exam results would be for you."
    new "Ich wusste nicht, wie wichtig die Prüfungsergebnisse für dich sind."

    # say L951 pla
    old "I'm not sure, but I think we can make it so that you'll be able to get the top grades."
    new "Ich bin mir nicht sicher, aber ich denke, wir können es so machen, dass du die besten Noten kriegst."

    # say L953 oli
    old "Do you really mean it?"
    new "Meinst du das wirklich?"

    # say L955 oli
    old "I know there's too little time to do this."
    new "Ich weiß, dass wir dafür zu wenig Zeit haben."

    # say L956 pla
    old "But I know we can make it, come on let's keep going!"
    new "Aber ich weiß, dass wir es schaffen können, komm schon, lass uns weitermachen!"

    # say L968 pla
    old "I think that's enough for today, but I'll be back soon so we can keep going."
    new "Ich denke, das reicht für heute, aber ich komme bald wieder, dann können wir weitermachen."

    # say L969 pla
    old "Don't worry, we'll get this done before you know it."
    new "Mach dir keine Sorgen, wir kriegen das hin, bevor du dich versiehst."

    # say L973 oli
    old "You know [pla], I'm not sure about this."
    new "Du weißt [pla], ich bin mir da nicht so sicher."

    # say L975 oli
    old "But if you say we can make it, I'll believe you."
    new "Aber wenn du sagst, dass wir es schaffen, glaube ich dir."

    # say L977 oli
    old "Thanks for the help [pla]."
    new "Danke für die Hilfe [pla]."

    # say L979 pla
    old "No problem, I'm happy to help."
    new "Kein Problem, ich freue mich, zu helfen."

    # say L980 pla
    old "I'll go for now, but I'll see you later."
    new "Ich geh jetzt, aber ich seh dich später."

    # say L1005 vee
    old "Yeah, that's right. Your aunt Fatima said she'd be sending Devika here to spend some time with us."
    new "Ja, genau. Tante Fatima hat gesagt, sie schickt Devika hierher, um etwas Zeit mit uns zu verbringen."

    # say L1008 vee
    old "Oh honey, don't make that face."
    new "Oh Schatz, mach doch nicht so ein Gesicht."

    # say L1011 oli
    old "I just don't know if she should come here."
    new "Ich hab einfach meine Bedenken, ob sie hierherkommen sollte."

    # say L1014 oli
    old "Where is she going to sleep?"
    new "Wo soll sie denn schlafen?"

    # say L1016 vee
    old "You don't need to worry about that."
    new "Das musst du dir nicht Sorgen machen."

    # say L1018 vee
    old "Besides, I know you like your cousin. You two used to be very close!"
    new "Außerdem, ich weiß, dass du deine Cousine magst. Ihr beiden wart früher sehr eng!"

    # say L1019 oli
    old "Hmm, that was a long time ago."
    new "Hmm, das ist lange her."

    # say L1021 oli
    old "But I guess it's alright if she comes here. I like Aunty Fatima, so it shouldn't be too much of a problem."
    new "Aber ich schätze, es ist in Ordnung, wenn sie hierher kommt. Tante Fatima mag ich, also sollte es kein großes Problem sein."

    # say L1027 pla
    old "Uh, s- sorry for interrupting."
    new "Uh, s- sorry for interrupting. Entschuldigung, dass ich störe."

    # say L1030 pla
    old "Hi Olivia, I came to continue our study sessions."
    new "Hi Olivia, ich bin hier, um unsere Lernsitzungen fortzusetzen."

    # say L1032 oli
    old "[pla], I'm so glad you're here! I was just waiting for you!"
    new "[pla], ich bin so froh, dass du da bist! Ich habe schon auf dich gewartet!"

    # say L1033 pla
    old "Uh... You were?"
    new "Klar... Du warst?"

    # say L1034 pla
    old "W- well, here I am, I guess."
    new "W- wow, hier bin ich also."

    # say L1035 oli
    old "Yeah, I was just waiting for you to make our announcement."
    new "Ja, ich habe auf dich gewartet, um unsere Ankündigung zu machen."

    # say L1037 pla
    old "O- our announcement? What do you-"
    new "O- unsere Ankündigung? Was meinst du-"

    # say L1043 oli
    old "Mom, there's something that [pla] and I have been wanting to tell you."
    new "Mom, da ist etwas, das [pla] und ich dir sagen wollen."

    # say L1044 oli
    old "And we decided this is the right time to do it."
    new "Und wir haben entschieden, dass jetzt der richtige Zeitpunkt dafür ist."

    # say L1046 vee
    old "Hmm, o-kay? What is it?"
    new "Hmm, okay? Was ist es?"

    # say L1048 oli
    old "Well, you see, the truth is that [pla] isn't actually my friend."
    new "Na ja, siehst du, die Wahrheit ist, dass [pla] eigentlich kein Freund von mir ist."

    # say L1050 oli
    old "Actually, it would be more accurate to say that he's not only my friend."
    new "Tatsächlich würde es besser passen zu sagen, dass er nicht nur mein Freund ist."

    # say L1055 oli
    old "What you just heard, Mom. [pla] and I have been dating for a while now."
    new "Was du gerade gehört hast, Mom. [pla] und ich sind schon eine Weile zusammen."

    # say L1057 vee
    old "I'm sorry, and why hadn't I heard about this until now?"
    new "Entschuldigung, und warum habe ich davon erst jetzt erfahren?"

    # say L1059 oli
    old "Because I just wanted to be sure about what he and I feel, and of our relationship."
    new "Weil ich einfach sicher sein wollte, was wir beide füreinander empfinden und was unsere Beziehung bedeutet."

    # say L1062 oli
    old "Also, I knew that you and Dad wouldn't have approved."
    new "Also, ich wusste, dass du und Dad das nicht gutgeheißen hätten."

    # say L1064 vee
    old "Oh, you think so?"
    new "Oh, findest du?"

    # say L1067 vee
    old "Not only are you dating someone without our approval."
    new "Du datierst jemanden ohne unsere Zustimmung."

    # say L1069 vee
    old "Now you also come and tell me like this?"
    new "Jetzt kommst du auch noch und erzählst es mir so?"

    # say L1072 vee
    old "You know full well that this is not how we do things, Olivia!"
    new "Du weißt genau, dass wir so nicht vorgehen, Olivia!"

    # say L1074 vee
    old "I can't even imagine the face Vihaan's going to make when he finds out about this."
    new "Ich kann mir gar nicht vorstellen, wie Vihaan reagieren wird, wenn er davon erfährt."

    # say L1075 oli
    old "That's precisely why I'm telling you this right now."
    new "Das ist genau der Grund, warum ich dir das jetzt sage."

    # say L1078 oli
    old "Mom, [pla] and I are in love."
    new "Mama, [pla] und ich sind verliebt."

    # say L1081 oli
    old "But I know that if I tell Dad about this, he'll never approve of us."
    new "Aber ich weiß, wenn ich es Dad sage, wird er uns nie akzeptieren."

    # say L1082 oli
    old "So I need your help to convince him that this is okay."
    new "Dann brauche ich deine Hilfe, um ihn davon zu überzeugen, dass das in Ordnung ist."

    # say L1085 vee
    old "It's not that simple, honey. You know I have no problem with you having a boyfriend."
    new "Das ist nicht so einfach, Schatz. Du weißt, ich habe kein Problem damit, dass du einen Freund hast."

    # say L1088 vee
    old "But Vihaan is a lot more traditional than me."
    new "Aber Vihaan ist viel traditioneller als ich."

    # say L1089 vee
    old "And he won't be pleased with this at all."
    new "Und er wird damit überhaupt nicht einverstanden sein."

    # say L1092 oli
    old "I know that, Mom, but I don't want to go along with Dad's plan."
    new "Ich weiß, Mom, aber ich will mich nicht an Dads Plan halten."

    # say L1093 oli
    old "You know what he wants..."
    new "Du weißt, was er will..."

    # say L1096 oli
    old "If it was up to him, I would already be wedded to that guy he wants me to marry."
    new "Wenn es nach ihm ginge, wäre ich schon mit diesem Typen verheiratet, den er für mich ausgesucht hat."

    # say L1099 oli
    old "But I don't want to live my life like that, Mom!"
    new "Aber ich will mein Leben nicht so leben, Mama!"

    # say L1102 oli
    old "I don't care about that guy I don't know."
    new "Mir ist es egal, was für ein Typ der Kerl ist, den ich nicht kenne."

    # say L1105 oli
    old "He's not what I want for my life."
    new "Er ist nicht das, was ich für mein Leben will."

    # say L1107 oli
    old "[pla] is the one I'm in love with!"
    new "[pla] ist derjenige, in den ich verliebt bin!"

    # say L1110 oli
    old "I need your help to convince Dad, please Mom."
    new "Ich brauche deine Hilfe, um Dad zu überzeugen, bitte, Mom."

    # say L1118 vee
    old "Alright, I can see you're serious about this."
    new "Okay, ich sehe, dass du es ernst meinst."

    # say L1119 oli
    old "That means you'll help me?"
    new "Das bedeutet, du wirst mir helfen?"

    # say L1121 vee
    old "Well, what choice do I have?"
    new "Na, was für eine Wahl habe ich denn?"

    # say L1123 vee
    old "You're putting me in a tough spot right now, honey."
    new "Du stellst mich jetzt echt in eine schwierige Situation, Schatz."

    # say L1126 vee
    old "But I wouldn't want to force your hand."
    new "Aber ich will dich auch nicht unter Druck setzen."

    # say L1129 vee
    old "And to be honest, I'm not too keen on this whole arranged marriage situation."
    new "Ehrlich gesagt, ich bin auch nicht besonders begeistert von dieser ganzen arrangierten Ehe."

    # say L1132 vee
    old "So I'll help you with your father for now."
    new "Dann helfe ich dir erst mal bei deinem Vater."

    # say L1134 oli
    old "That's great, Mom, thank you!"
    new "Das ist toll, Mama, danke!"

    # say L1137 vee
    old "Yeah well, that's only if you get good grades, you know."
    new "Klar, aber nur wenn du gute Noten bringst, das weißt du ja."

    # say L1138 vee
    old "Remember, that's a deal we already made with your father, so don't disappoint us."
    new "Denk dran, das ist eine Abmachung, die wir schon mit deinem Vater getroffen haben, also lass uns nicht enttäuschen."

    # say L1140 oli
    old "Don't worry, I promise you I'm working very hard."
    new "Mach dir keine Sorgen, ich verspreche, dass ich sehr hart arbeite."

    # say L1142 oli
    old "Come on [pla], let's get to studying."
    new "Komm schon [pla], lass uns mit dem Lernen anfangen."

    # say L1151 pla
    old "Uh, I- Uh... S- see to you later, Mrs. Priya."
    new "Uh, ich- ich... B- bis später, Mrs. Priya."

    # say L1161 oli
    old "Ok, that went well."
    new "Ok, das lief gut."

    # say L1164 pla
    old "Would you mind telling me what this business of us dating is about?"
    new "Kannst du mir sagen, was das mit uns beiden daten soll?"

    # say L1165 oli
    old "Well, you heard me talking to my mom."
    new "Na klar, du hast mich mit meiner Mum reden hören."

    # say L1167 oli
    old "Listen, after the last time you came here, I got to thinking about how much work is still left to do."
    new "Hör mal, nachdem du das letzte Mal hier warst, habe ich angefangen, über die Menge an Arbeit nachzudenken, die noch vor uns liegt."

    # say L1169 oli
    old "And I got worried about the possibility of not finishing it."
    new "Und ich hab mir Sorgen gemacht, dass wir es vielleicht nicht schaffen könnten."

    # say L1171 oli
    old "So I figured I needed a contingency plan in case my grades don't turn out to be good."
    new "Dann dachte ich, ich bräuchte einen Notfallplan, falls meine Noten nicht gut genug sind."

    # say L1172 pla
    old "So you came up with the idea of us dating? How is that going to help?"
    new "Dann bist du auf die Idee gekommen, dass wir zusammenkommen? Wie soll uns das helfen?"

    # say L1174 oli
    old "Think about it [pla], if I can convince my Dad that I'm in love with you."
    new "Überleg mal [pla], wenn ich Papa überzeugen kann, dass ich in dich verliebt bin."

    # say L1176 oli
    old "And that things are serious enough for me to consider marrying you."
    new "Und dass es ernst genug ist, dass ich dich heiraten könnte."

    # say L1178 oli
    old "Maybe he'll give up on trying to push me into that marriage."
    new "Vielleicht gibt er dann auf, mich in diese Ehe zu drängen."

    # say L1180 oli
    old "I'm sorry, is this a problem for you?"
    new "Entschuldigung, ist das ein Problem für dich?"

    # say L1182 pla
    old "No, not really. I promised to help you with this, and I get what you're doing."
    new "Nein, wirklich nicht. Ich hab versprochen, dir dabei zu helfen, und ich verstehe, was du machst."

    # say L1183 pla
    old "So it's alright, I'll help you with it."
    new "Dann ist es in Ordnung, ich helfe dir dabei."

    # say L1184 oli
    old "Thanks [pla], you have no idea how much I appreciate you saying that."
    new "Danke [pla], du hast ja keine Ahnung, wie sehr ich das zu schätzen weiß."

    # say L1185 pla
    old "I'm happy to help you."
    new "Ich freue mich, dir zu helfen."

    # say L1186 pla
    old "Now, let's get to studying, to ensure that you don't need your contingency plan."
    new "Dann lass uns mal anfangen zu lernen, damit du deinen Notfallplan nicht brauchst."

    # say L1196 oli
    old "Ugh! This is pointless!"
    new "Ugh! Das ist doch sinnlos!"

    # say L1197 pla
    old "W-what? What do you mean?"
    new "W-was? Was meinst du damit?"

    # say L1199 oli
    old "I'm talking about this whole studying for exams thing!"
    new "Ich rede von dem ganzen Lernen für die Klausuren!"

    # say L1200 oli
    old "It's pointless!"
    new "Das ist doch sinnlos!"

    # say L1201 pla
    old "W- why do you say that?"
    new "W-wieso sagst du das?"

    # say L1203 oli
    old "Think about it, [pla]..."
    new "Überleg doch mal, [pla]..."

    # say L1204 oli
    old "Look at how much I still have to do!"
    new "Schau dir an, wie viel ich noch zu tun habe!"

    # say L1206 oli
    old "There are so many topics!"
    new "Es gibt so viele Themen!"

    # say L1207 oli
    old "There's no way I can cram all of this into my head before the exams!"
    new "Da schaffe ich das nie, alles bis zu den Prüfungen in meinen Kopf zu kriegen!"

    # say L1220 aye
    old "Oh! Olivia is with her boyfriend in her room again?"
    new "Oh! Olivia ist wieder mit ihrem Freund in ihrem Zimmer?"

    # say L1221 aye
    old "I wonder what they talk about when they're alone..."
    new "Ich wundere mich, worüber sie sich allein unterhalten..."

    # say L1222 aye
    old "Or maybe they're doing some dirty stuff?"
    new "Oder vielleicht machen sie irgendwas Schmutziges?"

    # say L1228 aye
    old "I guess a little eavesdropping won't hurt."
    new "Ich denke, ein bisschen Lauschen kann nicht schaden."

    # say L1235 pla
    old "I can see why you're worried."
    new "Ich verstehe, warum du dir Sorgen machst."

    # say L1237 pla
    old "But you still have to try."
    new "Aber du musst es trotzdem versuchen."

    # say L1238 pla
    old "Look at how much work you've put in already."
    new "Schau dir an, wie viel Arbeit du schon geleistet hast."

    # say L1240 pla
    old "You can't give up now."
    new "Du darfst jetzt nicht aufgeben."

    # say L1242 oli
    old "I know I've put in a lot of work, [pla]."
    new "Ich weiß, dass ich schon viel Arbeit reingesteckt habe, [pla]."

    # say L1244 oli
    old "But come on, there's no way I'm going to be able to learn all of this before the exams."
    new "Aber komm schon, da ist keine Chance, dass ich das alles bis zu den Klausuren lerne."

    # say L1250 aye
    old "{i}(She'll finally get what she deserves!){/i}"
    new "{i}(Dann kriegt sie endlich, was sie verdient!){/i}"

    # say L1252 pla
    old "I get it, I know you're stressed and frustrated."
    new "Ich verstehe, ich weiß, dass du gestresst und frustriert bist."

    # say L1254 pla
    old "But come on, you can't give up."
    new "Aber komm schon, du darfst nicht aufgeben."

    # say L1256 oli
    old "I don't know, I think we should make another plan."
    new "Ich weiß nicht, ich denke, wir sollten einen anderen Plan machen."

    # say L1260 aye
    old "{i}(W-what? What is she talking about?){/i}"
    new "{i}(Was? Wovon redet sie da?){/i}"

    # say L1261 aye
    old "{i}(He's not her boyfriend?){/i}"
    new "{i}(Ist er nicht ihr Freund?){/i}"

    # say L1262 aye
    old "{i}(Oh, this is too good!){/i}"
    new "{i}(Ach, das ist zu gut!){/i}"

    # say L1274 aye
    old "Hey sis! How are you?"
    new "Hey Schwester! Wie geht's dir?"

    # say L1275 oli
    old "{b}*Sigh*{/b} What do you want?"
    new "{b}*Aufseufzen*{/b} Was willst du?"

    # say L1276 aye
    old "Oh, not much."
    new "Oh, nicht viel."

    # say L1277 aye
    old "I was just walking down the hallway a minute ago."
    new "Ich war gerade den Flur entlanggegangen."

    # say L1280 aye
    old "And I accidentally overheard something about [pla] here not being your boyfriend."
    new "Und ich habe zufällig was aufgeschnappt, dass [pla] hier nicht dein Freund ist."

    # say L1281 aye
    old "I wonder what that's about?"
    new "Ich frag mich, worum es da geht."

    # say L1283 oli
    old "I- I don't know what you're talking about."
    new "Ich- Ich weiß nicht, wovon du redest."

    # say L1284 aye
    old "Oh yeah, I bet you don't."
    new "Oh ja, ich wette, du hast keine Ahnung."

    # say L1287 aye
    old "You know, dad's going to be very displeased about this."
    new "Du weißt, dass Papa darüber sehr unzufrieden sein wird."

    # say L1289 aye
    old "I can already imagine his face when I tell him that you're apparently faking having a boyfriend."
    new "Ich kann mir schon vorstellen, wie sein Gesicht aussehen wird, wenn ich ihm sage, dass du angeblich einen Freund vortäuschst."

    # say L1291 aye
    old "I can't wait."
    new "Ich freu mich schon drauf."

    # say L1293 oli
    old "W-wait! You don't understand."
    new "W-warte! Du verstehst das falsch."

    # say L1294 oli
    old "I think you misheard us or something."
    new "Ich glaube, du hast uns missverstanden oder so."

    # say L1296 aye
    old "Oh no, don't give me that. I didn't mishear anything!"
    new "Oh nein, lass das. Ich hab nichts falsch gehört!"

    # say L1299 aye
    old "You know, I thought it was strange."
    new "Du weißt, ich fand es seltsam."

    # say L1300 aye
    old "When you suddenly brought a boyfriend home."
    new "Als du plötzlich einen Freund mit nach Hause gebracht hast."

    # say L1303 aye
    old "And not only that, from one moment to the next, you decided to start studying."
    new "Und nicht nur das, von einem Moment zum anderen hast du beschlossen, dich aufs Studium zu konzentrieren."

    # say L1305 aye
    old "When I had never seen you take your studies seriously."
    new "Als ich noch nie gesehen habe, dass du deine Studien ernst nimmst."

    # say L1307 aye
    old "I see now that this is just a ploy to avoid going to India with dad, isn't it?"
    new "Ich sehe jetzt, dass das nur eine Taktik ist, um mit Dad nach Indien zu fahren zu vermeiden, oder?"

    # say L1308 pla
    old "{i}(W-wow, she's sharp. She figured it out just like that!){/i}"
    new "{i}(W-wow, sie ist scharf. Sie hat es gleich rausgefunden!){/i}"

    # say L1311 oli
    old "Ugh, shut up! This has nothing to do with that!"
    new "Ugh, halt die Klappe! Das hat überhaupt nichts damit zu tun!"

    # say L1314 oli
    old "Now get out of my room before I throw you out!"
    new "Jetzt raus aus meinem Zimmer, bevor ich dich rausschmeiße!"

    # say L1316 aye
    old "Oh, I'll get out of here!"
    new "Oh, ich verschwinde hier!"

    # say L1319 aye
    old "And I'll go call Dad right away!"
    new "Und ich rufe gleich Dad an!"

    # say L1320 aye
    old "With all the work Dad's doing to grant you a future!"
    new "Mit all der Arbeit, die Dad für deine Zukunft leistet!"

    # say L1323 aye
    old "And this is how you decide to repay him, by lying to him!"
    new "Und das ist deine Art, ihm dankbar zu sein, indem du ihn anlügst!"

    # say L1325 aye
    old "I can't wait to let him know how bad his favorite daughter really is!"
    new "Ich freu mich schon darauf, ihm zu sagen, wie schlecht seine Lieblings-Tochter wirklich ist!"

    # say L1336 aye
    old "Yes? What do you want?"
    new "Ja? Was willst du?"

    # say L1343 oli
    old "{b}*Sigh*{/b} If I prove to you that he's my boyfriend, will you shut up and not talk to Dad?"
    new "{b}*Seufz*{/b} Wenn ich dir beweise, dass er mein Freund ist, hältst du dann endlich die Klappe und redest nicht mehr mit Dad?"

    # say L1344 aye
    old "Hmm... Maybe, if you can convince me, of course."
    new "Hmm... Vielleicht, wenn du mich überzeugen kannst, klar."

    # say L1345 oli
    old "I swear to God, one day."
    new "Ich schwöre bei Gott, eines Tages."

    # say L1349 oli
    old "Here I come, [pla]..."
    new "Da bin ich, [pla]..."

    # say L1363 oli
    old "There, are you happy?"
    new "Da, bist du jetzt zufrieden?"

    # say L1365 aye
    old "What? Happy?"
    new "Was? Glucklich?"

    # say L1370 aye
    old "I could kiss him right now too."
    new "Ich könnte ihn jetzt auch küssen."

    # say L1372 aye
    old "That doesn't prove anything!"
    new "Das beweist gar nichts!"

    # say L1374 oli
    old "What are you insinuating?"
    new "Was willst du damit sagen?"

    # say L1376 aye
    old "Come on sis, prove to me that you're really a couple."
    new "Na los, Schwesterherz, beweis mir, dass ihr wirklich ein Paar seid."

    # say L1378 oli
    old "What do you mean by that?"
    new "Was meinst du damit?"

    # say L1379 aye
    old "Oh come on! I knew you were dumb, but I didn't think this much."
    new "Oh komm schon! Ich wusste, dass du dumm bist, aber so dumm dachte ich dich nicht."

    # say L1384 oli
    old "W- what? What are you talking about? Do you think I just go around doing that?"
    new "W-was? Wovon redest du? Denkst du etwa, ich mache so was einfach so?"

    # say L1385 oli
    old "I don't do that sort of thing!"
    new "Ich mache so was nicht!"

    # say L1388 aye
    old "Don't treat me like I'm stupid!"
    new "Mach mich nicht dumm!"

    # say L1389 aye
    old "Maybe Mom and Dad are willing to buy your {i}‘nice girl'{/i} act..."
    new "Vielleicht sind Mom und Dad bereit, dein {i}„gutes Mädchen“{/i}-Theater zu kaufen..."

    # say L1390 aye
    old "But I know who you really are!"
    new "Aber ich weiß, wer du wirklich bist!"

    # say L1393 pla
    old "H- hey, hey! L- let's not get carried away, girls."
    new "H-hey, hey! L-lass uns nicht übertreiben, Mädels."

    # say L1397 oli
    old "Stay out of this!"
    new "Bleib da raus!"

    # say L1403 oli
    old "Listen, you little bitch."
    new "Hör zu, du kleine Schlampe."

    # say L1405 oli
    old "First, be very careful about who you're calling a whore."
    new "Erstens, sei sehr vorsichtig, wen du eine Hure nennst."

    # say L1407 oli
    old "Second, there must be something really wrong with your head if you want to see me fuck this guy in front of you."
    new "Zweitens, da muss echt was faul an deinem Kopf sein, wenn du willst, dass ich vor dir mit dem Typen ficke."

    # say L1410 oli
    old "And if you think I'll let you watch that."
    new "Und wenn du denkst, ich lasse dich das zuschauen."

    # say L1411 oli
    old "So why don't you get the hell out of here?!"
    new "Dann verpiss dich doch einfach!"

    # say L1414 aye
    old "Oh, I can leave, I told you I have no problem with that."
    new "Oh, ich kann gehen, hab ich dir doch gesagt, das ist für mich kein Problem."

    # say L1416 aye
    old "But you know what I'll do right away!"
    new "Aber du weißt, was ich sofort machen werde!"

    # say L1419 aye
    old "Because I don't have any proof that this guy is your real boyfriend."
    new "Weil ich keine Beweise habe, dass dieser Typ dein richtiger Freund ist."

    # say L1422 aye
    old "Thinking about it, right now it must be early morning in India."
    new "Im Moment muss es in Indien früh morgens sein."

    # say L1423 aye
    old "Daddy must be waiting for me to send him his good morning message."
    new "Daddy wartet bestimmt darauf, dass ich ihm meine Guten-Morgen-Nachricht schicke."

    # say L1424 aye
    old "I'm sure he'll appreciate the extra news!"
    new "Ich bin sicher, er wird sich freuen, die Extra-News zu kriegen!"

    # say L1430 oli
    old "{i}({b}*Sigh*{/b} I can't believe this...){/i}"
    new "{i}({b}*Seufz*{/b} Ich kann es nicht fassen...){/i}"

    # say L1431 oli
    old "Listen you..."
    new "Hör zu..."

    # say L1433 oli
    old "I'm NOT going to have sex with this guy in front of you."
    new "Ich werde definitiv nicht mit diesem Typen vor dir Sex haben."

    # say L1434 oli
    old "But if I do something sexual with him..."
    new "Aber wenn ich was Sexuelles mit ihm mache..."

    # say L1437 oli
    old "Will you stop saying he's not my boyfriend and leave us alone?"
    new "Wirst du dann aufhören zu sagen, dass er nicht mein Freund ist und uns in Ruhe lassen?"

    # say L1438 aye
    old "Hmm, I don't know, that really depends on you."
    new "Hmm, ich weiß nicht, das hängt wirklich von dir ab."

    # say L1441 aye
    old "It has to look real, sis."
    new "Es muss echt aussehen, Schwester."

    # say L1442 oli
    old "I get it..."
    new "Ich verstehe..."

    # say L1445 oli
    old "I will do this then."
    new "Dann mache ich das."

    # say L1450 oli
    old "The only reason I'm going along with this sick game of yours."
    new "Die einzige Grund, warum ich mit diesem kranken Spiel von dir mitspiele."

    # say L1453 oli
    old "Is because I don't have any other way of proving to you that this guy and I have a relationship."
    new "Das ist, weil ich keine andere Möglichkeit habe, dir zu beweisen, dass dieser Typ und ich eine Beziehung haben."

    # say L1455 oli
    old "But this is the last time I'll let you push me into something like this."
    new "Aber das ist das letzte Mal, dass ich mich von dir in so was reinziehen lasse."

    # say L1458 oli
    old "If you ever try this again, I don't care what you have to say to anyone, I'll fucking make you pay!"
    new "Wenn du das noch mal versuchst, ist mir egal, was du irgendwem erzählst, ich werde dich verdammt nochmal bezahlen lassen!"

    # say L1460 aye
    old "Very clear, sis, but I don't see you proving anything, so why don't you get to it?"
    new "Klar, Schwesterherz, aber ich seh nich, dass du was beweist. Also, worauf wartest du noch?"

    # say L1461 aye
    old "And remember, make it convincing."
    new "Und vergiss nicht, es überzeugend zu machen."

    # say L1466 pla
    old "W- woah! Woah! Is this for real? Do you want to do this in front of her?"
    new "W- wow! Ist das ernst gemeint? Willst du das wirklich vor ihr machen?"

    # say L1468 oli
    old "Do you get the situation, [pla]? Do you know how serious it is?"
    new "Verstehst du die Situation, [pla]? Weißt du, wie ernst es ist?"

    # say L1469 oli
    old "Of course I'm being serious..."
    new "Natürlich bin ich ernst..."

    # say L1484 aye
    old "Oh gosh! You're actually doing it!"
    new "Oh nein! Du machst es wirklich!"

    # say L1485 aye
    old "This is for real! I can't believe it!"
    new "Das ist echt! Ich fass es nicht!"

    # say L1496 aye
    old "I have to say, sis, that was quite the spectacle."
    new "Muss ich sagen, Schwester, das war ein echter Knaller."

    # say L1497 oli
    old "Are you satisfied?"
    new "Bist du zufrieden?"

    # say L1498 aye
    old "Oh! Of course, I am!"
    new "Oh! Klar bin ich!"

    # say L1499 aye
    old "I can tell how much you liked it!"
    new "Ich merke, wie sehr dir das gefallen hat!"

    # say L1502 aye
    old "You can just tell how much love there is between the two of you!"
    new "Man merkt einfach, wie viel Liebe zwischen euch beiden ist!"

    # say L1504 oli
    old "Alright, you have what you wanted. Now get the hell out of here!"
    new "Okay, du hast bekommen, was du wolltest. Jetzt verschwinde endlich hier!"

    # say L1506 oli
    old "And remember what I told you."
    new "Und denk dran, was ich dir gesagt habe."

    # say L1508 oli
    old "I won't allow this to happen a second time, now get the hell out of my room, you bitch!"
    new "Ich werde das nicht noch einmal zulassen, jetzt verschwinde aus meinem Zimmer, du Schlampe!"

    # say L1510 aye
    old "Oh, I'm leaving alright."
    new "Oh, ich geh' ja schon."

    # say L1511 aye
    old "But I can't wait to see you again soon, [pla]."
    new "Aber ich freue mich schon darauf, dich bald wiederzusehen, [pla]."

    # say L1512 oli
    old "Out!"
    new "Raus!"

    # say L1521 pla
    old "Uhmm... A- are you alright?"
    new "Hmm... Bist du okay?"

    # say L1523 oli
    old "Shut up, [pla]."
    new "Halt die Klappe, [pla]."

    # say L1524 oli
    old "We still have a lot of ground to cover."
    new "Wir haben noch viel vor uns."

    # say L1525 oli
    old "And not a lot of time, so let's just get back to studying."
    new "Und wir haben nicht viel Zeit, also lass uns einfach weiterlernen."

    # say L1526 pla
    old "R- right."
    new "R- richtig."

    # say L1545 pla
    old "I guess I'll go home for now. And I'll come back later."
    new "Ich schätze, ich geh jetzt nach Hause. Und komme später wieder."

    # say L1548 oli
    old "But before you leave, I want to make something clear."
    new "Aber bevor du gehst, will ich etwas klarstellen."

    # say L1550 oli
    old "What just happened here was just a one-time thing, alright?"
    new "Was hier gerade passiert ist, war nur ein Einmaliges, okay?"

    # say L1552 oli
    old "Don't get any ideas about it happening again."
    new "Mach dir keine Hoffnungen, dass das noch mal passiert."

    # say L1555 pla
    old "S-sure, of course."
    new "S-Sicher, klar."

    # say L1557 oli
    old "Alright, then I'll see you later."
    new "Okay, dann sehen wir uns später."

    # say L1558 pla
    old "Sure, bye."
    new "Okay, tschüss."

    # say L1574 pla
    old "Alright, we somehow managed to cover everything."
    new "Okay, wir haben es irgendwie geschafft, alles abzudecken."

    # say L1575 pla
    old "It might not have been too thorough."
    new "Es war vielleicht nicht allzu gründlich."

    # say L1576 pla
    old "But I'm sure you know enough now to shoot for the highest grades."
    new "Aber ich bin sicher, dass du jetzt genug weißt, um die besten Noten zu kriegen."

    # say L1581 pla
    old "I'm sure you'll do great."
    new "Ich bin sicher, du wirst es super machen."

    # say L1583 pla
    old "Just remember, all you have to do is stay calm while you're answering the questions."
    new "Denk dran, du musst nur ruhig bleiben, während du die Fragen beantwortest."

    # say L1585 pla
    old "As long as you don't worry too much, you should be fine to answer everything."
    new "Solange du dich nicht zu sehr aufregst, solltest du alles gut beantworten können."

    # say L1589 oli
    old "I'll do my best to answer everything as well as I can!"
    new "Ich werde mein Bestes tun, um alles so gut wie möglich zu beantworten!"

    # say L1591 oli
    old "I'm so thankful for your help!"
    new "Ich bin dir so dankbar für deine Hilfe!"

    # say L1593 oli
    old "Without you, I couldn't have gone through all those topics."
    new "Ohne dich hätte ich all diese Themen nicht durchstehen können."

    # say L1594 oli
    old "Really, thank you so much."
    new "Wirklich, danke dir so sehr."

    # say L1596 pla
    old "It's alright, I'm glad I was able to help you."
    new "Ist schon gut, ich freue mich, dass ich dir helfen konnte."

    # say L1598 pla
    old "And I'm sure you'll do great on the exam."
    new "Und ich bin sicher, du wirst die Prüfung bestehen."

    # say L1600 pla
    old "So, I'll leave for now, and I'll see you later."
    new "Dann lass ich dich jetzt mal, bis später."

    # say L1602 oli
    old "Alright, I'll be sure to let you know how I do in the exams."
    new "Okay, ich werde dir Bescheid sagen, wie es bei den Prüfungen läuft."

    # say L1630 pla
    old "Hmm, I just remembered, I need to check my exam results when I get home."
    new "Hmm, ich hab gerade dran gedacht, ich muss meine Prüfungsergebnisse checken, wenn ich zu Hause bin."

    # say L1637 pla
    old "Oh! Hey Olivia."
    new "Oh! Hallo Olivia."

    # say L1640 pla
    old "How did you do on the exams? Have you checked the results yet?"
    new "Wie bist du in den Prüfungen drauf gekommen? Hast du die Ergebnisse schon überprüft?"

    # say L1642 pla
    old "How do you think you did on them?"
    new "Wie denkst du, wie du abgeschnitten hast?"

    # say L1644 oli
    old "Well, about that, do you think you could come with me to my house?"
    new "Na ja, dazu, glaubst du, du könntest mit mir zu mir nach Hause kommen?"

    # say L1645 pla
    old "Uh, s-sure. Is there anything wrong?"
    new "Klar, s-sicher. Ist was passiert?"

    # say L1647 oli
    old "You have no idea... But I'll tell you at my house."
    new "Du hast keine Ahnung... Aber ich erzähl's dir bei mir zu Hause."

    # say L1648 oli
    old "Come on, let's go."
    new "Komm schon, lass uns gehen."

    # say L1673 vee
    old "Yeah, yeah, I know."
    new "Ja, ja, ich weiß."

    # say L1676 vee
    old "Oh my god, Vihaan! I said I got it!"
    new "Oh mein Gott, Vihaan! Ich hab’s doch gesagt!"

    # say L1682 vee
    old "What do you mean my fault?"
    new "Was meinst du damit, meine Schuld?"

    # say L1684 vee
    old "Maybe if you were here too..."
    new "Vielleicht wenn du auch hier wärst..."

    # say L1687 vee
    old "Yeah, I know..."
    new "Ja, ich weiß..."

    # say L1692 vee
    old "You know, this really isn't as bad as you're making it out to be."
    new "Du weißt, dass das gar nicht so schlimm ist, wie du es darstellst."

    # say L1693 vee
    old "Well, because this isn't the end of the world."
    new "Na ja, weil das Ende der Welt ist es nun auch wieder nicht."

    # say L1697 vee
    old "She can always try again..."
    new "Sie kann es immer noch mal versuchen..."

    # say L1698 vee
    old "Oh! I know full well what you think about that!"
    new "Oh! Ich weiß genau, was du darüber denkst!"

    # say L1702 vee
    old "But that's beside the point."
    new "Aber das ist nebensächlich."

    # say L1712 vee
    old "And what do you propose we do about her boyfriend?"
    new "Und was schlägst du vor, dass wir wegen ihrem Freund machen?"

    # say L1716 vee
    old "Of course it's important, Vihaan!"
    new "Natürlich ist es wichtig, Vihaan!"

    # say L1721 vee
    old "What do you mean why?"
    new "Was meinst du warum?"

    # say L1725 vee
    old "Because her feelings are important!"
    new "Weil ihre Gefühle wichtig sind!"

    # say L1729 vee
    old "I know that."
    new "Ich weiß."

    # say L1734 vee
    old "No, he's not rich."
    new "Nein, er ist nicht reich."

    # say L1735 vee
    old "But I think that's beside the..."
    new "Aber ich denke, das ist nebensächlich."

    # say L1739 vee
    old "Hmm, yeah that's true."
    new "Hmm, ja, das stimmt."

    # say L1744 vee
    old "{b}*Sigh*{/b} Yeah, you're very right."
    new "{b}*Seufz*{/b} Ja, du hast vollkommen recht."

    # say L1745 vee
    old "Yeah, I guess I'll talk to her."
    new "Ja, ich denke, ich rede mit ihr."

    # say L1746 vee
    old "Yes, you're right."
    new "Ja, du hast recht."

    # say L1748 vee
    old "You should talk to her as well."
    new "Du solltest auch mit ihr reden."

    # say L1749 vee
    old "Yeah, talk to you later then."
    new "Dann reden wir später."

    # say L1753 vee
    old "So, I guess you got what your father said in that conversation."
    new "Dann hast du also auch verstanden, was dein Vater in dem Gespräch gemeint hat."

    # say L1754 oli
    old "Yeah, I can figure."
    new "Klar, das hab ich kapiert."

    # say L1756 aye
    old "Oh! You're in trouble!"
    new "Oh! Du bist in Schwierigkeiten!"

    # say L1760 aye
    old "What's the matter, sis?"
    new "Was ist los, Schwester?"

    # say L1761 aye
    old "Is the favorite daughter not living up to expectations?"
    new "Ist das Lieblingstöchterchen nicht mehr brav?"

    # say L1764 oli
    old "Why don't you shut your mouth before I shut it for you?"
    new "Warum schließt du nicht endlich dein Maul, bevor ich es für dich tue?"

    # say L1765 vee
    old "OK! That's enough."
    new "OK! Das reicht jetzt."

    # say L1766 vee
    old "Listen, Olivia, I don't like the attitude your father's taking on this."
    new "Hör zu, Olivia, ich mag die Art und Weise nicht, wie dein Vater sich in dieser Sache verhält."

    # say L1767 vee
    old "But you were aware of what he wanted you to do."
    new "Aber du warst dir bewusst, was er von dir verlangt hat."

    # say L1768 vee
    old "And the only way that you could stop him from sending you to India was by getting good grades."
    new "Und der einzige Weg, ihn davon abzuhalten, dich nach Indien zu schicken, war, gute Noten zu bekommen."

    # say L1770 vee
    old "I know, I know, this isn't fair."
    new "Ich weiß, ich weiß, das ist nicht fair."

    # say L1771 vee
    old "But it is the way things are."
    new "Aber so sind die Dinge nun mal."

    # say L1774 aye
    old "Because you're too stupid."
    new "Weil du zu dumm bist."

    # say L1775 vee
    old "The point is that your dad decided that he's not going to wait for you to finish the school year."
    new "Der Punkt ist, dass dein Dad entschieden hat, dass er nicht auf das Ende des Schuljahrs warten wird."

    # say L1778 vee
    old "He told me that he wants you to start organizing your things."
    new "Er hat mir gesagt, dass er will, dass du anfängst, deine Sachen zu packen."

    # say L1782 vee
    old "After the next batch of exams, you're transferring to a school in India."
    new "Nach den nächsten Klausuren wechselst du auf eine Schule in Indien."

    # say L1785 oli
    old "But that's not fair! He doesn't get to decide that for me!"
    new "Aber das ist nicht fair! Er hat doch kein Recht, das für mich zu entscheiden!"

    # say L1786 vee
    old "Well, apparently he does."
    new "Na ja, anscheinend doch."

    # say L1790 vee
    old "And honestly, Olivia, you should've known this was going to happen."
    new "Und ehrlich gesagt, Olivia, hättest du das kommen sehen sollen."

    # say L1791 vee
    old "I'm sorry, honey, but at this point, there's not a lot more that I can do for you."
    new "Es tut mir leid, Schatz, aber ich kann im Moment nicht mehr für dich tun."

    # say L1792 aye
    old "It looks like you're taking a plane to our motherland, sis! Hahaha!"
    new "Siehst aus, als würdest du ein Flugzeug in Richtung unserer Heimat nehmen, Schwester! Hahaha!"

    # say L1797 vee
    old "You shouldn't be gloating too much, young lady."
    new "Du solltest dich nicht zu sehr freuen, junge Dame."

    # say L1799 vee
    old "With the way your grades are going, you'll be joining your sister."
    new "Mit deiner Note wirst du deine Schwester bald einholen."

    # say L1805 vee
    old "You heard me, your father wasn't only talking about Olivia."
    new "Hast du mich gehört, dein Vater hat nicht nur von Olivia gesprochen."

    # say L1806 vee
    old "And your grades aren't much better than hers."
    new "Und deine Noten sind nicht viel besser als ihre."

    # say L1807 aye
    old "But, I mean... Mom!"
    new "Aber, ich meine... Mama!"

    # say L1810 vee
    old "We'll talk about this later, I have to run some errands."
    new "Später reden wir drüber, ich muss noch ein paar Besorgungen machen."

    # say L1814 vee
    old "Listen, honey, I'm sorry about this, but I guess that's just how it is."
    new "Hör zu, Schatz, es tut mir leid, aber so ist es nun mal."

    # say L1820 aye
    old "Wait, Mom, let me go with you! We still need to talk about Dad!"
    new "Warte, Mom, lass mich mitkommen! Wir müssen noch über Dad reden!"

    # say L1829 oli
    old "I imagine you can guess what happened..."
    new "Ich denke, du kannst dir denken, was passiert ist."

    # say L1830 pla
    old "I think so... The exams didn't go well?"
    new "Ich denke schon... Die Prüfungen sind nicht gut gelaufen?"

    # say L1832 oli
    old "They didn't."
    new "Sie sind nicht gut gelaufen."

    # say L1833 pla
    old "But you studied so hard."
    new "Aber du hast so hart gelernt."

    # say L1835 oli
    old "I did, and you did a great job teaching me [pla]."
    new "Ich hab's getan und du hast mich super gut unterrichtet [pla]."

    # say L1836 oli
    old "But when I was taking the exams, I couldn't focus."
    new "Aber als ich die Prüfungen gemacht habe, konnte ich mich nicht konzentrieren."

    # say L1838 oli
    old "I just kept thinking about how important it was to get top marks."
    new "Ich hab nur an die Top-Noten gedacht."

    # say L1840 oli
    old "And the more I thought about it, the more scared I got."
    new "Und je mehr ich drüber nachgedacht hab, desto mehr Angst hab ich gekriegt."

    # say L1842 oli
    old "In the end, I couldn't answer anything correctly."
    new "Am Ende konnte ich keine einzige Frage richtig beantworten."

    # say L1844 pla
    old "I mean, I get it."
    new "Ich meine, ich verstehe das."

    # say L1846 pla
    old "With that much pressure, it would be hard to do well."
    new "Mit so viel Druck wäre es schwer, gut abzuschneiden."

    # say L1847 pla
    old "I'm sorry, Olivia."
    new "Es tut mir leid, Olivia."

    # say L1848 oli
    old "Well, it happens. Nothing I can do about it."
    new "Na ja, so was passiert. Da kann ich nichts dran ändern."

    # say L1849 oli
    old "But that doesn't mean I won't deal with this."
    new "Aber das bedeutet nicht, dass ich es nicht angehen werde."

    # say L1850 pla
    old "Oh... Okay, what do you have in mind?"
    new "Oh... Okay, was hast du vor?"

    # say L1852 oli
    old "Well, this is going to surprise you."
    new "Na ja, das wird dich überraschen."

    # say L1854 oli
    old "But I don't have an easy way to say this."
    new "Aber ich hab' keine einfache Art, das zu sagen."

    # say L1858 pla
    old "W- WHAT?! What are you talking about?!"
    new "W- WAS?! Wovon redest du?!"

    # say L1860 oli
    old "You heard me, I'm going to get pregnant."
    new "Du hast mich gehört, ich werde schwanger werden."

    # say L1861 pla
    old "Yeah, that doesn't explain anything."
    new "Das erklärt immer noch nichts."

    # say L1863 pla
    old "I'm sorry, like an actual pregnancy?"
    new "Entschuldigung, meinst du eine echte Schwangerschaft?"

    # say L1864 pla
    old "Or are you talking about pretending to be pregnant?"
    new "Oder meinst du, so tun als wärst du schwanger?"

    # say L1865 oli
    old "No, I mean literally pregnant."
    new "Nein, ich meine wörtlich schwanger."

    # say L1866 pla
    old "W- what? B- but why?"
    new "W-was? A-aber warum?"

    # say L1868 oli
    old "Because it's the only way to change my circumstances."
    new "Weil es der einzige Weg ist, meine Situation zu ändern."

    # say L1870 pla
    old "That's putting it mildly!"
    new "Das ist noch mild ausgedrückt!"

    # say L1872 pla
    old "Is this what you want? To be a mother?"
    new "Willst du das? Mutter werden?"

    # say L1874 oli
    old "I don't."
    new "Ich will das nicht."

    # say L1875 oli
    old "Or at least not yet."
    new "Oder zumindest noch nicht."

    # say L1877 pla
    old "Then why do you want to get pregnant?"
    new "Dann warum willst du schwanger werden?"

    # say L1879 oli
    old "Getting pregnant doesn't automatically mean I have to be a mother [pla]!"
    new "Schwanger zu werden bedeutet noch nicht automatisch, dass ich Mutter sein muss [pla]!"

    # say L1881 oli
    old "I don't plan on carrying the pregnancy to term."
    new "Ich plane nicht, die Schwangerschaft auszutragen."

    # say L1883 oli
    old "I just want to get rid of this whole {i}'arranged marriage'{/i} thing."
    new "Ich will mich einfach von dieser ganzen {i}'Ehearrangement'{/i}-Sache befreien."

    # say L1884 pla
    old "And how would that work?"
    new "Und wie soll das funktionieren?"

    # say L1886 oli
    old "In our culture, when a woman is arranged to marry, she's expected to be virtuous."
    new "In unserer Kultur wird von einer Frau erwartet, dass sie tugendhaft ist, wenn sie in eine Ehe eingehet."

    # say L1888 oli
    old "Nowadays, there's no way to ensure that the girl is a virgin."
    new "Heutzutage gibt es keine Möglichkeit, sicherzustellen, dass das Mädchen noch Jungfrau ist."

    # say L1889 oli
    old "So that tends to be overlooked."
    new "Dann wird das meistens übersehen."

    # say L1891 oli
    old "But a pregnancy is a very different thing."
    new "Aber eine Schwangerschaft ist eine ganz andere Sache."

    # say L1893 oli
    old "The family of the guy my dad chose for me is very illustrious and traditional."
    new "Die Familie des Typen, den mein Dad für mich ausgesucht hat, ist sehr angesehen und traditionell."

    # say L1895 oli
    old "If they find out I'm pregnant, they'll cancel it immediately."
    new "Wenn sie erfahren, dass ich schwanger bin, werden sie es sofort abblasen."

    # say L1897 oli
    old "And better yet, once the word spreads, it'll be impossible for my father to arrange another marriage for me."
    new "Und noch besser, sobald es sich herumspricht, wird es für meinen Vater unmöglich sein, eine andere Ehe für mich zu arrangieren."

    # say L1898 pla
    old "You seem very certain this will work."
    new "Du scheinst dir ziemlich sicher zu sein, dass das funktionieren wird."

    # say L1900 oli
    old "Well, because I've seen something like it."
    new "Na ja, weil ich schon mal so was gesehen habe."

    # say L1902 oli
    old "I have this cousin who was in a similar situation a couple of years ago."
    new "Ich hab da eine Cousine, die vor ein paar Jahren in einer ähnlichen Situation war."

    # say L1903 oli
    old "The difference is that she actually wanted to get married."
    new "Der Unterschied ist, dass sie tatsächlich heiraten wollte."

    # say L1905 oli
    old "The guy my uncle selected for her is a doctor who lives in Delhi."
    new "Der Typ, den mein Onkel für sie ausgesucht hat, ist ein Arzt, der in Delhi lebt."

    # say L1906 oli
    old "So on paper, she had the perfect deal."
    new "Auf dem Papier hatte sie also den perfekten Deal."

    # say L1909 oli
    old "The problem came when she went to a party and hooked up with some guy."
    new "Das Problem kam, als sie zu einer Party ging und sich mit einem Typen eingelassen hat."

    # say L1910 oli
    old "That's not a big deal, but she wasn't careful and ended up getting pregnant."
    new "Das ist kein großes Problem, aber sie war nicht vorsichtig und wurde schwanger."

    # say L1911 oli
    old "She tried to keep it under wraps while she dealt with it."
    new "Sie versuchte, es geheim zu halten, während sie damit umging."

    # say L1913 oli
    old "But that kind of thing is almost impossible to keep hidden in a place like Delhi, to be honest."
    new "Aber so was ist in einem Ort wie Delhi ehrlich gesagt fast unmöglich zu verheimlichen."

    # say L1915 oli
    old "So, her marriage was canceled almost immediately, there was nothing she could do."
    new "Also, ihre Ehe wurde fast sofort abgesagt, da konnte sie nichts machen."

    # say L1917 oli
    old "Moreover, she hasn't been able to get a single meeting to arrange a marriage."
    new "Außerdem hat sie nicht mal ein einziges Treffen für eine Verlobung bekommen."

    # say L1918 oli
    old "Much less a fiancé."
    new "Viel weniger einen Verlobten."

    # say L1919 pla
    old "Wow, is it really like that?"
    new "Wow, ist es wirklich so?"

    # say L1921 oli
    old "Of course it is."
    new "Natürlich ist es so."

    # say L1923 oli
    old "It's not good to say, but once a woman gets pregnant, she's no longer seen as virtuous."
    new "Es ist nicht gut zu sagen, aber wenn eine Frau schwanger wird, gilt sie nicht mehr als tugendhaft."

    # say L1925 oli
    old "Rather as {i}'damaged goods.'{/i} Ugh!"
    new "Eher als {i}'beflecktes Gut.'{/i} Igitt!"

    # say L1927 oli
    old "But yeah... That's why I believe my idea will work."
    new "Aber ja... Deshalb glaube ich, dass meine Idee funktionieren wird."

    # say L1929 pla
    old "Still, it sounds so drastic."
    new "Trotzdem klingt das ziemlich drastisch."

    # say L1931 pla
    old "Don't you think there's anything less... extreme you could do?"
    new "Findest du nicht, dass es etwas weniger... drastisches gibt, das du tun könntest?"

    # say L1932 pla
    old "How about taking other exams?"
    new "Und was ist mit anderen Prüfungen?"

    # say L1934 oli
    old "What will that do? You already heard my mother, my dad won't even let me finish the year."
    new "Was soll das bringen? Du hast doch gehört, was meine Mutter gesagt hat, und mein Vater lässt mich nicht mal das Jahr abschließen."

    # say L1936 oli
    old "And to be honest [pla], I don't think that was ever a real option."
    new "Und ehrlich gesagt [pla], ich glaube, das war nie eine echte Option."

    # say L1938 oli
    old "I think he was just entertaining my mom, but his real plan has always been to get me married to someone in India."
    new "Ich denke, er hat meiner Mom nur etwas vorgemacht, aber sein echter Plan war immer, mich mit jemandem in Indien zu verheiraten."

    # say L1940 oli
    old "But that's not what I want for myself [pla]!"
    new "Aber das ist nicht, was ich für mich will [pla]!"

    # say L1941 oli
    old "Life in an arranged marriage is restrictive."
    new "Das Leben in einer arrangierten Ehe ist eingeschränkt."

    # say L1943 oli
    old "You're not your own person; everything you want to do or have has to come through your husband."
    new "Du bist nicht dein eigener Mensch; alles, was du tun oder haben willst, muss durch deinen Mann gehen."

    # say L1944 oli
    old "Any social life you might want or access depends on him."
    new "Jeder Sozialleben, das du haben möchtest, hängt von ihm ab."

    # say L1946 oli
    old "In the best case, the guy will be understanding and permissive. And you can imagine how it is at the worst."
    new "Im besten Fall ist der Typ verständnisvoll und tolerant. Und du kannst dir vorstellen, wie es im schlimmsten Fall ist."

    # say L1948 oli
    old "I don't want that for myself! Why do I have to marry some guy I don't know just so my dad can make money from it?!"
    new "Das will ich mir nicht antun! Warum muss ich einen Kerl heiraten, den ich nicht kenne, damit mein Dad sich daran bereichern kann?!"

    # say L1949 oli
    old "So, if I have to get pregnant to stop myself from being married to some guy I don't know, I'll gladly do it."
    new "Dann werde ich mich eben schwanger machen, um dieser Ehe mit einem Fremden zu entgehen, das mache ich gerne."

    # say L1951 pla
    old "I see, but are you sure you can do this?"
    new "Ich verstehe, aber bist du dir sicher, dass du das kannst?"

    # say L1953 pla
    old "I mean, interrupting a pregnancy's not easy."
    new "Ich meine, eine Schwangerschaft abzubrechen ist nicht einfach."

    # say L1957 oli
    old "Well, abortion is legal and pretty common these days."
    new "Na ja, Abtreibungen sind heutzutage legal und ziemlich üblich."

    # say L1959 oli
    old "I know a girl who got one."
    new "Ich kenne ein Mädchen, das eine hatte."

    # say L1962 oli
    old "Yeah, she's a friend of Ruby."
    new "Ja, sie ist eine Freundin von Ruby."

    # say L1964 oli
    old "She got pregnant from a one-night stand with her ex-boyfriend."
    new "Sie ist schwanger geworden von einem One-Night-Stand mit ihrem Ex-Freund."

    # say L1965 oli
    old "But she went to the hospital to get an abortion, and it went very well. You know?"
    new "Aber sie ist ins Krankenhaus gegangen, um eine Abtreibung machen zu lassen, und es ist gut gelaufen. Wusstest du das?"

    # say L1966 pla
    old "I see... I think I get it."
    new "Ich sehe... Ich denke, ich verstehe."

    # say L1967 oli
    old "That's right, so you see it now, it's not a bad plan."
    new "Stimmt, jetzt siehst du es, es ist kein schlechter Plan."

    # say L1971 pla
    old "{i}(And she did tell me that I had to get as many women as I could pregnant.){/i}"
    new "{i}(Und sie hat mir auch gesagt, dass ich so viele Frauen wie möglich schwängern muss.){/i}"

    # say L1973 pla
    old "No, it isn't a bad plan."
    new "Nein, das ist kein schlechter Plan."

    # say L1975 oli
    old "And... That's more or less where you come in."
    new "Und... Da kommst du ins Spiel."

    # say L1976 oli
    old "Listen [pla], our original deal is already fulfilled."
    new "Hör zu [pla], unsere ursprüngliche Abmachung ist bereits erfüllt."

    # say L1978 oli
    old "I didn't pass my exams, but you still helped me the best way you could."
    new "Ich hab meine Prüfungen nicht bestanden, aber du hast mir trotzdem auf die beste Art und Weise geholfen."

    # say L1979 oli
    old "So I wouldn't tell you that you have to get me pregnant."
    new "Dann würde ich dir nicht sagen, dass du mich schwängern musst."

    # say L1981 oli
    old "But if I'm honest, it's hard for me to think of a better person to ask."
    new "Aber ehrlich gesagt, fällt es mir schwer, eine bessere Person zu finden, um das zu fragen."

    # say L1982 oli
    old "You know my situation in a way that I couldn't explain to anyone else."
    new "Du kennst meine Situation auf eine Weise, die ich niemandem sonst erklären könnte."

    # say L1984 oli
    old "And you wouldn't have to worry about it, all I need is your seed."
    new "Und du müsstest dir keine Sorgen machen, ich brauche nur dein Sperma."

    # say L1985 oli
    old "And I would take care of everything regarding the pregnancy and the interruption."
    new "Und ich würde mich um alles bezüglich der Schwangerschaft und der Unterbrechung kümmern."

    # say L1987 oli
    old "But I would understand if you didn't want to do it."
    new "Aber ich würde verstehen, wenn du das nicht machen willst."

    # say L1989 pla
    old "Actually, I was thinking that I wanted to help you with it."
    new "Eigentlich dachte ich, dass ich dir dabei helfen will."

    # say L1991 pla
    old "What you say is true. I am fully aware of your situation, both with your parents."
    new "Was du sagst, stimmt. Ich bin mir deiner Situation voll bewusst, sowohl bei deinen Eltern."

    # say L1993 pla
    old "And what you're doing to try and deal with it."
    new "Und was du machst, um damit klarzukommen."

    # say L1994 pla
    old "So I agree that I'm probably the best person to help you with this."
    new "Dann bin ich wohl der beste, um dir dabei zu helfen."

    # say L1996 pla
    old "Also, I'm really against what your parents are putting you through, you know?"
    new "Also, ich bin echt dagegen, was deine Eltern dir antun, weißt du?"

    # say L1998 pla
    old "I don't think it's fair at all that you have to live your life the way they want you to."
    new "Ich finde es total unfair, dass du dein Leben so leben musst, wie sie es wollen."

    # say L1999 pla
    old "So I'll help you get out of it."
    new "Dann helfe ich dir da raus."

    # say L2003 oli
    old "OK, let's go to my room."
    new "OK, lass uns in mein Zimmer gehen."

    # say L2004 pla
    old "W- what? Do it now?"
    new "W-was? Jetzt gleich?"

    # say L2005 oli
    old "Yeah, of course. I don't think there's a better time for it."
    new "Klar, warum nicht. Ich denke, es gibt keinen besseren Zeitpunkt dafür."

    # say L2006 oli
    old "My mom will be out with Ayesha running errands until late."
    new "Meine Mom wird mit Ayesha einkaufen gehen und erst spät zurückkommen."

    # say L2008 oli
    old "And we don't have much time. I need to get pregnant soon."
    new "Und wir haben nicht viel Zeit. Ich muss bald schwanger werden."

    # say L2009 oli
    old "So we should do it now."
    new "Dann machen wir es jetzt."

    # say L2026 oli
    old "Ok, so... Uhh, let's do it..."
    new "Okay, also... Uhh, machen wir es..."

    # say L2027 pla
    old "Uhh... Yeah, yeah..."
    new "Uhh... Ja, ja..."

    # say L2028 oli
    old "Well... Uhh, where do we start? I mean, I know how to do it, but... Uhhh you get what I mean..."
    new "Na ja... Uhh, wo fangen wir an? Ich meine, ich weiß, wie es geht, aber... Uhhh du verstehst schon, was ich meine..."

    # say L2030 pla
    old "Uhh... Well, I think, we should... Uhh..."
    new "Uhh... Also, ich denke, wir sollten... Uhh..."

    # say L2032 oli
    old "You know what, this is silly, we don't have time for this. After all, I've already sucked your cock..."
    new "Du weißt ja, das ist albern, wir haben dafür keine Zeit. Schließlich habe ich deinen Schwanz schon geleckt..."

    # say L2034 oli
    old "Alright, I'll start, after all, I'm the one who needs your help with this."
    new "Okay, ich fang an, schließlich bin ich diejenige, die deine Hilfe braucht."

    # say L2043 oli
    old "Does this feel good?"
    new "Fühlt sich das gut an?"

    # say L2044 pla
    old "U- uh, yeah..."
    new "U- äh, ja..."

    # say L2045 oli
    old "I have to say, you have a big... dick..."
    new "Ich muss sagen, du hast einen großen... Schwanz..."

    # say L2046 pla
    old "Uhh, thanks..."
    new "Uhh, danke..."

    # say L2055 oli
    old "Alright! That was great [pla]!"
    new "Okay! Das war toll [pla]!"

    # say L2056 oli
    old "It may be too soon to know if I'm pregnant yet, but I'll take a test as soon as I can and let you know."
    new "Es ist vielleicht noch zu früh, um zu wissen, ob ich schwanger bin, aber ich mache so bald wie möglich einen Test und lasse es dich wissen."

    # say L2058 pla
    old "Alright, that sounds good."
    new "Okay, das klingt gut."

    # say L2060 oli
    old "Thanks again for helping me [pla]."
    new "Danke nochmal für deine Hilfe [pla]."

    # say L2062 pla
    old "It's alright, I'm happy to help."
    new "Ist schon gut, ich freue mich, dir zu helfen."

    # say L2064 oli
    old "Anyway, I think you should get going before my mom gets back."
    new "Na ja, ich denke, du solltest besser gehen, bevor meine Mom zurückkommt."

    # say L2065 pla
    old "Oh! Right, sure, I'll see you later."
    new "Oh! Stimmt, klar, ich seh dich später."

    # say L2068 oli
    old "And hey, thank you again."
    new "Und danke nochmal."

    # say L2092 pla
    old "Hey! Brixxida! I have some very good news for you!"
    new "Hey! Brixxida! Ich habe eine super gute Nachricht für dich!"

    # say L2095 pla
    old "Well, I made an advancement in our plans!"
    new "Na, ich habe einen Fortschritt in unseren Plänen gemacht!"

    # say L2098 pla
    old "Our plan of getting women pregnant."
    new "Unser Plan, Frauen schwanger zu machen."

    # say L2099 pla
    old "You know, so we can use their magical power to feed the portal to the magic world."
    new "Du weißt schon, damit wir ihre magische Kraft nutzen können, um das Portal zur Magiewelt zu füttern."

    # say L2101 bri
    old "Okay? How did you make this {i}'advancement?'{/i}"
    new "Okay? Wie hast du diesen {i}'Fortschritt?'{/i} gemacht?"

    # say L2103 pla
    old "Well, I have this friend from school who asked me for some help studying."
    new "Na ja, ich hab einen Kumpel von der Schule, der mich gebeten hat, ihm beim Lernen zu helfen."

    # say L2105 pla
    old "As we studied, we got closer, and I got to know her."
    new "Während wir gelernt haben, sind wir enger geworden, und ich habe sie besser kennengelernt."

    # say L2106 pla
    old "It turns out that her problems were a lot bigger than just school."
    new "Stell sich heraus, dass ihre Probleme viel größer waren als nur die Schule."

    # say L2108 pla
    old "And that the only way out of them was to get pregnant."
    new "Und dass der einzige Weg aus ihnen raus war, schwanger zu werden."

    # say L2110 bri
    old "So... You're telling me that you got this woman pregnant?"
    new "Dann... Willst du mir sagen, dass du diese Frau schwanger gemacht hast?"

    # say L2112 pla
    old "I did!"
    new "Ich hab's getan!"

    # say L2113 pla
    old "Or at least I think I did, she told me she was going to take a pregnancy test."
    new "Oder zumindest denke ich das, sie hat gesagt, sie wird einen Schwangerschaftstest machen."

    # say L2117 bri
    old "You heard me!"
    new "Hast du mir etwa nicht zugehört?"

    # say L2118 bri
    old "Did you forget what I told you last time?"
    new "Hast du vergessen, was ich dir letztes Mal gesagt habe?"

    # say L2119 pla
    old "Uhmm- We need the magic?"
    new "Ähmm- Wir brauchen die Magie?"

    # say L2121 bri
    old "No! You idiot!"
    new "Nein! Du Idiot!"

    # say L2123 bri
    old "What I told you is that I had to be there when you have sex with the girl!"
    new "Was ich dir gesagt habe, ist, dass ich dabei sein muss, wenn du mit dem Mädchen vögelst!"

    # say L2126 bri
    old "Ugh, try to pay attention when I speak to you."
    new "Ugh, versuch mal aufzupassen, wenn ich mit dir rede."

    # say L2127 bri
    old "Listen, it's not just about you getting her pregnant and that's it."
    new "Hör zu, es geht nicht nur darum, dass du sie schwängerst und basta."

    # say L2128 bri
    old "I have to be there to perform a ritual while it's happening."
    new "Ich muss dabei sein, um ein Ritual durchzuführen."

    # say L2131 bri
    old "Of course! Otherwise, it would just be a regular pregnancy."
    new "Natürlich! Sonst wäre es ja nur eine normale Schwangerschaft."

    # say L2132 bri
    old "That's why it's so bad that you just went ahead and tried to get her pregnant!"
    new "Deshalb ist es ja so schlimm, dass du einfach vorgeprescht bist und versucht hast, sie schwanger zu machen!"

    # say L2133 bri
    old "Because if she is, then we will have lost the chance of getting a girl pregnant."
    new "Denn wenn sie es ist, haben wir die Chance verloren, ein Mädchen zu schwängern."

    # say L2135 bri
    old "And we'll have to look for another person."
    new "Und wir müssen nach jemand anderem suchen."

    # say L2140 pla
    old "If that's true, why weren't you there when I had sex with Barbie and got her pregnant?"
    new "Wenn das stimmt, warum warst du dann nicht da, als ich mit Barbie geschlafen und sie schwanger gemacht habe?"

    # say L2142 bri
    old "Who says that I wasn't?"
    new "Wer sagt, dass ich nicht da war?"

    # say L2145 bri
    old "Think about it [pla], where did you do it with Barbie the first time?"
    new "Überleg mal [pla], wo hast du es das erste Mal mit Barbie getrieben?"

    # say L2146 pla
    old "Uhm, we did it here."
    new "Hmm, wir haben es hier getan."

    # say L2148 bri
    old "Exactly, and this is where I spend most of my time."
    new "Genau, und hier verbringe ich die meiste Zeit."

    # say L2149 bri
    old "I'm either at the garage, taking care of the portal."
    new "Ich bin entweder in der Garage und kümmere mich um das Portal."

    # say L2150 bri
    old "Or I'm here resting."
    new "Oder ich bin hier und ruhe mich aus."

    # say L2151 bri
    old "So last time, when you arrived with Barbie, I was able to initiate the spell when you two started to have sex."
    new "Beim letzten Mal, als du mit Barbie gekommen bist, konnte ich den Zauber starten, als ihr beiden angefangen habt zu vögeln."

    # say L2152 bri
    old "Otherwise it would've been wasted."
    new "Sonst wäre es verschwendet gewesen."

    # say L2154 bri
    old "Yeah... Luckily that time we were fine."
    new "Ja... Glücklicherweise war damals alles in Ordnung."

    # say L2155 bri
    old "But I'm not omnipresent [pla]."
    new "Aber ich bin nicht allgegenwärtig [pla]."

    # say L2156 bri
    old "Now there's a chance that girl is pregnant and we may have lost our next chance."
    new "Jetzt gibt es die Chance, dass das Mädchen schwanger ist und wir unsere nächste Chance verloren haben."

    # say L2157 pla
    old "I- I'm sorry Brixxida, I should have talked it over with you before I had sex with her."
    new "Ich- Ich bin sorry, Brixxida, ich hätte vorher mit dir darüber reden sollen, bevor ich mit ihr geschlafen habe."

    # say L2158 pla
    old "But I mean, there's still a chance that she's not pregnant."
    new "Aber ich meine, es besteht immer noch die Chance, dass sie nicht schwanger ist."

    # say L2160 bri
    old "Hmph, for your sake, we better hope she isn't."
    new "Hmpf, für deinen Seelenfrieden hoffen wir besser, dass sie es nicht ist."

    # say L2162 bri
    old "Now, in order for this to not happen again."
    new "Jetzt, damit das nicht noch mal passiert."

    # say L2163 bri
    old "I think I should teach you a summoning spell."
    new "Ich denke, ich sollte dir einen Beschwörungszauber beibringen."

    # say L2164 bri
    old "So that this doesn't happen again."
    new "Damit das nicht noch mal passiert."

    # say L2166 pla
    old "S- summoning spell?!"
    new "S-Summoning spell?!"

    # say L2167 bri
    old "Right, this isn't the most complicated spell, so you should be able to master it easily."
    new "Stimmt, das ist kein besonders komplizierter Zauber, also solltest du ihn leicht beherrschen können."

    # say L2168 bri
    old "And it's good that you know it."
    new "Und es ist gut, dass du es weißt."

    # say L2169 bri
    old "So that you can call on me whenever you see yourself in a situation where you think we can start the ritual with someone."
    new "Damit du mich rufen kannst, wann immer du dich in einer Situation siehst, in der du denkst, wir können mit jemandem das Ritual beginnen."

    # say L2170 pla
    old "I see... Alright, so how does this spell work?"
    new "Ich seh's... Okay, wie funktioniert dieser Spruch dann?"

    # say L2171 bri
    old "I'll tell you, get your SexNote out."
    new "Ich erzähl's dir, hol deine SexNote raus."

    # say L2175 bri
    old "Alright, I'll explain everything to you, pay attention."
    new "Okay, ich erkläre dir alles, hör gut zu."

    # say L2184 bri
    old "Alright, that should be enough for now."
    new "Okay, das sollte fürs Erste reichen."

    # say L2185 bri
    old "With that, you should be able to do the spell properly without needing any kind of help from my end."
    new "Dann solltest du das Zauber jetzt richtig ausführen können, ohne meine Hilfe."

    # say L2187 pla
    old "I got it, I'll keep that in mind."
    new "Hab's kapiert, ich behalt's im Hinterkopf."

    # say L2190 pla
    old "By the way, since you say it isn't a normal pregnancy."
    new "Ach ja, da du sagst, dass es keine normale Schwangerschaft ist."

    # say L2192 pla
    old "How is a magical pregnancy different from a normal one?"
    new "Wie unterscheidet sich eine magische Schwangerschaft von einer normalen?"

    # say L2195 bri
    old "Listen, in general, she'll have more or less the same experience she would if this was a normal, human pregnancy."
    new "Hör zu, im Allgemeinen wird sie eine ähnliche Erfahrung machen wie bei einer normalen, menschlichen Schwangerschaft."

    # say L2196 bri
    old "But there will be two big differences."
    new "Aber es gibt zwei große Unterschiede."

    # say L2197 bri
    old "The first one is that it's going to be a lot faster than it would normally be."
    new "Das erste ist, dass es viel schneller gehen wird als normal."

    # say L2198 bri
    old "Since she'll be concentrating magic power within her."
    new "Da sie ihre magische Kraft konzentrieren wird."

    # say L2199 bri
    old "It's different from woman to woman, but it should be about a third of the time."
    new "Es ist bei jeder Frau anders, aber es sollte ungefähr ein Drittel der normalen Zeit dauern."

    # say L2201 bri
    old "Maybe even a fourth, who knows."
    new "Vielleicht sogar ein Viertel, wer weiß."

    # say L2204 bri
    old "Well, if you're going to be a father or not depends on whether or not she'll have the {i}'baby'{/i}."
    new "Na ja, ob du Vater wirst oder nicht, hängt davon ab, ob sie das {i}'Kind'{/i} behalten will."

    # say L2206 bri
    old "Either way, it doesn't make a difference for us."
    new "Egal, das macht für uns keinen Unterschied."

    # say L2207 pla
    old "It doesn't?"
    new "Nein?"

    # say L2208 pla
    old "That's good to hear."
    new "Das ist gut zu hören."

    # say L2210 bri
    old "Yeah, what we're doing is using the pregnancy to concentrate the magic in her body."
    new "Ja, was wir tun, ist, die Magie in ihrem Körper durch die Schwangerschaft zu konzentrieren."

    # say L2212 bri
    old "The baby itself is not actually important to our plans."
    new "Das Baby selbst ist für unsere Pläne eigentlich nicht wichtig."

    # say L2214 bri
    old "So, when the moment comes to harvest the magic, it can be done either by the baby being born."
    new "Dann kann die Magie entweder durch die Geburt des Babys geerntet werden."

    # say L2215 bri
    old "Or by the pregnancy being interrupted."
    new "Oder durch die Unterbrechung der Schwangerschaft."

    # say L2217 bri
    old "It doesn't matter, as long as I can harvest the magic growing within her."
    new "Mir ist es egal, Hauptsache ich kann die Magie ernten, die in ihr wächst."

    # say L2220 bri
    old "By the way, there's another small difference with a normal pregnancy you have to look out for."
    new "Übrigens, es gibt noch einen kleinen Unterschied zu einer normalen Schwangerschaft, auf den du achten musst."

    # say L2222 bri
    old "This pregnancy will come with the added need for magic power within her system."
    new "Diese Schwangerschaft wird mit der zusätzlichen Notwendigkeit von Magie in ihrem System einhergehen."

    # say L2224 bri
    old "As the baby grows in her womb, she'll naturally absorb it from the environment."
    new "Während das Baby in ihrem Bauch wächst, wird sie es natürlich aus der Umgebung aufnehmen."

    # say L2225 bri
    old "But you can expect that she'll still feel the need for sex. Much like how us shinigami need it from you."
    new "Aber du kannst erwarten, dass sie immer noch das Bedürfnis nach Sex hat. Genauso wie wir Shinigami es von dir brauchen."

    # say L2227 bri
    old "You'll probably have to have sex with her once in a while during her pregnancy."
    new "Du wirst wahrscheinlich ab und zu mit ihr schlafen müssen, während sie schwanger ist."

    # say L2228 bri
    old "So that's a very good thing for you."
    new "Das ist also eine sehr gute Sache für dich."

    # say L2231 bri
    old "Listen [pla], I hope that girl isn't pregnant, so that we won't miss a chance to add somebody to the ritual."
    new "Hör zu [pla], ich hoffe, das Mädchen ist nicht schwanger, damit wir die Chance haben, jemanden zum Ritual hinzuzufügen."

    # say L2232 pla
    old "I understand, and I'm sorry I didn't let you know about it before doing it."
    new "Ich verstehe, und es tut mir leid, dass ich dir das vorher nicht gesagt habe."

    # say L2233 pla
    old "I'll talk to her, and I'll let you know how things evolve."
    new "Ich rede mit ihr und lass dich wissen, wie es weitergeht."

    # say L2234 bri
    old "Alright, I'll be waiting for the news."
    new "Okay, ich warte auf die Neuigkeiten."

    # say L2254 pla
    old "Hey Olivia, I came to-"
    new "Hey Olivia, ich bin gekommen, um-"

    # say L2256 oli
    old "I can't believe this! I just can't believe it!"
    new "Ich kann es einfach nicht fassen!"

    # say L2258 vee
    old "I'm sorry honey, but this is not my fault."
    new "Es tut mir leid, Schatz, aber das ist nicht meine Schuld."

    # say L2260 oli
    old "And is it my fault?"
    new "Und ist es meine Schuld?"

    # say L2261 vee
    old "Well, who else?"
    new "Na, wer sonst?"

    # say L2262 oli
    old "Oh my God, I can't believe you're saying that!"
    new "Oh mein Gott, ich kann nicht glauben, dass du das sagst!"

    # say L2263 oli
    old "You know what this means, right?!"
    new "Du weißt, was das bedeutet, oder?!"

    # say L2265 oli
    old "He already decided on the date of the marriage!"
    new "Er hat das Datum der Hochzeit schon festgelegt!"

    # say L2267 oli
    old "He can't do that! How can you just let him decide that by himself!"
    new "Er kann das nicht machen! Wie kannst du ihm das einfach so durchgehen lassen!"

    # say L2269 vee
    old "This isn't my fault, Olivia!"
    new "Das ist nicht meine Schuld, Olivia!"

    # say L2270 vee
    old "I tried to help you, you know that."
    new "Ich hab versucht, dir zu helfen, das weißt du."

    # say L2273 vee
    old "But you didn't do your part!"
    new "Aber du hast deinen Teil nicht getan!"

    # say L2274 vee
    old "You knew what your father's expectations were."
    new "Du wusstest, was die Erwartungen deines Vaters waren."

    # say L2277 vee
    old "But instead of studying to improve your grades, you decided to waste time."
    new "Stattdessen, anstatt zu lernen, um deine Noten zu verbessern, hast du dich entschieden, Zeit zu verschwenden."

    # say L2278 vee
    old "What do you expect me to do for you then?"
    new "Was erwartest du dann von mir?"

    # say L2279 vee
    old "It was up to you, and you didn't do what you had to."
    new "Es lag an dir, und du hast nicht getan, was du tun musstest."

    # say L2282 oli
    old "And that means that I have to be sent away to be married to some stranger?!"
    new "Und das bedeutet, dass ich fortgeschickt werde, um einen Fremden zu heiraten?!"

    # say L2283 oli
    old "That's my punishment for doing badly in algebra?!"
    new "Das ist meine Strafe dafür, dass ich in Algebra schlecht war?!"

    # say L2284 oli
    old "I can't believe you, Mom! With all that you kept talking about how you don't agree with what Dad wants to do!"
    new "Ich fass es nicht, Mum! Nach all dem, was du die ganze Zeit über gesagt hast, dass du nicht mitziehst, was Dad will!"

    # say L2287 vee
    old "I don't agree with it! But you know that your father's word is law!"
    new "Ich bin damit nicht einverstanden! Aber du weißt, dass das Wort deines Vaters Gesetz ist!"

    # say L2290 vee
    old "If you wanted to get out of it so badly, all you had to do was study."
    new "Wenn du es so sehr vermeiden wolltest, hättest du nur lernen müssen."

    # say L2292 vee
    old "Now it's too late to cry over spilled milk."
    new "Jetzt ist es zu spät, um über verschüttete Milch zu weinen."

    # say L2294 vee
    old "You should've thought about that before wasting your time with the likes of Ruby."
    new "Du hättest dir das vorher überlegen sollen, bevor du deine Zeit mit Leuten wie Ruby verschwendest."

    # say L2297 vee
    old "I'm sorry honey, but this is just how it is."
    new "Tut mir leid, Schatz, aber so ist es nun mal."

    # say L2298 vee
    old "And you'll have to learn to live with it."
    new "Und du wirst lernen müssen, damit zu leben."

    # say L2299 oli
    old "Yeah... I don't think I will."
    new "Ja... Ich glaube, ich werde das nicht akzeptieren."

    # say L2301 oli
    old "I don't think I'll have to learn to live with it."
    new "Ich glaube nicht, dass ich das akzeptieren muss."

    # say L2302 oli
    old "I won't do what dad wants me to."
    new "Ich werde nicht tun, was Dad von mir verlangt."

    # say L2303 vee
    old "Olivia, be reasonable, how are you planning to go against your father's wishes?"
    new "Olivia, sei vernünftig, wie willst du gegen die Wünsche deines Vaters verstoßen?"

    # say L2305 oli
    old "I don't plan on doing anything."
    new "Ich plane gar nichts."

    # say L2308 oli
    old "Especially because I already did it."
    new "Besonders, weil ich es schon getan habe."

    # say L2309 vee
    old "Okay now you're just being cryptic, what are you talking about?"
    new "Okay, jetzt machst du es spannend, worüber redest du überhaupt?"

    # say L2313 vee
    old "W- what?! P- pregnant?! What do you mean?!"
    new "W- was?! P- schwanger?! Was meinst du damit?!"

    # say L2316 vee
    old "When did this happen?!"
    new "Wann ist das passiert?!"

    # say L2318 oli
    old "Well, I only found out last week, but I wouldn't know exactly when I got pregnant."
    new "Na ja, ich habe es erst letzte Woche erfahren, aber ich weiß nicht genau, wann ich schwanger geworden bin."

    # say L2321 oli
    old "But that's how things are, Mom. I wanted to be sure before letting you know, but the situation calls for me to let you know."
    new "Aber so ist es nun mal, Mama. Ich wollte erst sicher sein, bevor ich es dir sage, aber die Situation zwingt mich dazu, es dir jetzt zu sagen."

    # say L2322 vee
    old "And you think this is the best moment to bring that out?!"
    new "Und du denkst, das ist der beste Moment, das zu sagen?!"

    # say L2325 vee
    old "If you already knew, you should've let us know sooner!"
    new "Wenn du es schon wusstest, hättest du uns früher Bescheid sagen sollen!"

    # say L2327 vee
    old "Do you have any idea about what this means?!"
    new "Hast du eine Ahnung, was das bedeutet?!"

    # say L2328 vee
    old "Do you know how your dad will react?!"
    new "Weißt du, wie dein Dad darauf reagieren wird?!"

    # say L2330 oli
    old "I don't know, but he won't be able to send me to India like this."
    new "Ich weiß es nicht, aber so kann er mich nicht nach Indien schicken."

    # say L2333 vee
    old "And you think things are just going to be alright?!"
    new "Und du denkst, alles wird einfach so gut werden?!"

    # say L2335 vee
    old "Your father will come here and kill [pla]!"
    new "Dein Vater wird hierkommen und [pla] umbringen!"

    # say L2338 vee
    old "I can't believe this from you, Olivia! Not only did you get pregnant, but you also hid it!"
    new "Ich kann es nicht fassen, Olivia! Nicht nur bist du schwanger geworden, sondern du hast es auch verheimlicht!"

    # say L2340 oli
    old "But you guys were pushing me so hard into it! I just didn't know how to!"
    new "Aber ihr habt mich doch so unter Druck gesetzt! Ich wusste einfach nicht, wie ich damit umgehen soll!"

    # say L2341 vee
    old "No! I don't want to hear anything from you!"
    new "Nein! Ich will nichts mehr von dir hören!"

    # say L2343 vee
    old "You have no idea about what this that you're doing means."
    new "Du hast keine Ahnung, was das bedeutet, was du da machst."

    # say L2344 vee
    old "So I won't listen to you and I won't talk to you about it for now!"
    new "Dann werde ich dir nicht zuhören und auch nicht mit dir darüber reden, zumindest vorerst!"

    # say L2345 oli
    old "What? B- but!"
    new "Was? A-aber!"

    # say L2353 pla
    old "I- Uh... E- excuse me!"
    new "I- Ähm... E- Entschuldigung!"

    # say L2366 pla
    old "Sooo... I guess you're pregnant?"
    new "Sooo... Ich schätze, du bist schwanger?"

    # say L2368 oli
    old "Of course I'm not."
    new "Natürlich bin ich das nicht."

    # say L2370 oli
    old "We only did it once, it can happen but we weren't lucky."
    new "Wir haben es nur einmal gemacht, es könnte passieren, aber wir hatten einfach Pech."

    # say L2372 oli
    old "I only said that to my mom to get both her and my dad off my back."
    new "Ich hab das nur zu meiner Mum gesagt, damit sie und mein Dad mich in Ruhe lassen."

    # say L2373 oli
    old "But now I have to be pregnant for real!"
    new "Aber jetzt muss ich wirklich schwanger werden!"

    # say L2375 oli
    old "And it can't take too long."
    new "Und es darf nicht zu lange dauern."

    # say L2376 oli
    old "Because they'll want to check soon for it."
    new "Denn sie werden bald danach schauen wollen."

    # say L2379 pla
    old "So, s- should we do it now?"
    new "Dann, s- sollen wir es jetzt machen?"

    # say L2382 oli
    old "Of course not!"
    new "Natürlich nicht!"

    # say L2384 oli
    old "My mom said she didn't want to talk to me for now."
    new "Meine Mom hat gesagt, sie will jetzt nicht mit mir reden."

    # say L2386 oli
    old "But be sure that she's going to barge in here any minute now."
    new "Aber sei dir sicher, dass sie jeden Moment hier reinspazieren wird."

    # say L2388 oli
    old "Actually, I think it would be better if you leave for now."
    new "Eigentlich denke ich, es wäre besser, wenn du jetzt gehst."

    # say L2390 oli
    old "Just to avoid an awkward situation."
    new "Um eine peinliche Situation zu vermeiden."

    # say L2391 pla
    old "Oh yeah, sure, we can talk later."
    new "Oh ja, klar, wir können später reden."

    # say L2394 oli
    old "Sure, see you..."
    new "Klar, bis später..."

    # say L2423 oli
    old "I was just thinking that I have to talk to you."
    new "Ich hab gerade gedacht, dass ich mit dir reden muss."

    # say L2427 pla
    old "How did everything turn out after I left your home?"
    new "Wie war es nachdem ich dein Haus verlassen habe?"

    # say L2428 oli
    old "Ugh, you have no idea."
    new "Ugh, du hast keine Ahnung."

    # say L2430 oli
    old "My mom called my dad and told him everything."
    new "Meine Mom hat meinen Dad angerufen und ihm alles erzählt."

    # say L2432 oli
    old "He got incredibly angry and started screaming about honor and responsibility."
    new "Er ist total ausgerastet und hat über Ehre und Verantwortung geschrien."

    # say L2434 oli
    old "I'm glad it was only over the phone, I can't imagine what he would've done if I had been in front of him."
    new "Ich bin froh, dass es nur am Handy war, ich kann mir gar nicht vorstellen, was er gemacht hätte, wenn ich ihm gegenüber gestanden hätte."

    # say L2435 pla
    old "It got that bad, huh?"
    new "Hat es so schlimm gestanden?"

    # say L2437 pla
    old "I guess he's that worried about you then."
    new "Dann ist er wohl ziemlich besorgt um dich."

    # say L2438 oli
    old "I don't think it has anything to do with me."
    new "Ich glaube, das hat nichts mit mir zu tun."

    # say L2440 oli
    old "He's just angry about having to call off the engagement."
    new "Er ist einfach sauer, dass er die Verlobung lösen muss."

    # say L2441 pla
    old "Really?! That's what bothers him?"
    new "Wirklich?! Das macht ihn sauer?"

    # say L2443 oli
    old "It is, it's just an integral part of our culture [pla]."
    new "Das ist es, es ist einfach ein wesentlicher Teil unserer Kultur [pla]."

    # say L2445 oli
    old "In India, an arranged marriage is something to be taken seriously."
    new "In Indien ist eine arrangierte Ehe etwas Ernstes."

    # say L2446 oli
    old "Because it's a promise of uniting families."
    new "Weil es ein Versprechen ist, Familien zu vereinen."

    # say L2448 oli
    old "Now my dad has to go to his friend's house and explain to him why I can't get married."
    new "Jetzt muss mein Dad zu dem Haus seines Freundes gehen und ihm erklären, warum ich nicht heiraten kann."

    # say L2449 pla
    old "I see, I guess honor's very important there."
    new "Ich verstehe, Ehre scheint da sehr wichtig zu sein."

    # say L2451 oli
    old "It is, but if I'm honest with you, it has nothing to do with that."
    new "Das stimmt, aber ehrlich gesagt hat das damit gar nichts zu tun."

    # say L2454 oli
    old "He's just angry about losing this business."
    new "Er ist einfach sauer, weil er dieses Geschäft verloren hat."

    # say L2456 oli
    old "Yeah, those marriages are very honorable and whatever."
    new "Ja, diese Ehen sind sehr ehrenhaft und so."

    # say L2458 oli
    old "But what he cares about are the business opportunities he could get by marrying his daughters to rich men."
    new "Aber das, was ihm wichtig ist, sind die Geschäftschancen, die er durch die Heirat seiner Töchter mit reichen Männern bekommen könnte."

    # say L2461 oli
    old "But it doesn't matter now."
    new "Aber das spielt jetzt keine Rolle."

    # say L2463 oli
    old "Once the news that I'm pregnant starts spreading around, nobody will want to marry me."
    new "Sobald sich herumspricht, dass ich schwanger bin, wird niemand mehr mich heiraten wollen."

    # say L2464 oli
    old "And Dad will have to leave that alone."
    new "Und Papa muss das akzeptieren."

    # say L2465 pla
    old "Ok, so it's all done, right?"
    new "Ok, dann ist es ja alles geregelt, oder?"

    # say L2469 oli
    old "Yeah, he has to get off my back, but that only means that I HAVE to get pregnant."
    new "Ja, er muss mir endlich den Rücken freigeben, aber das bedeutet nur, dass ich schwanger werden muss."

    # say L2471 oli
    old "And that's where you come in."
    new "Und da kommst du ins Spiel."

    # say L2473 oli
    old "I wanted to ask you if you can come to my house with me."
    new "Ich wollte dich fragen, ob du mit zu mir kommen kannst."

    # say L2474 oli
    old "My mom's going to be out with my sister running some errands."
    new "Meine Mum wird mit meiner Schwester einkaufen gehen."

    # say L2475 oli
    old "Which means I'll have the house to myself for some hours."
    new "Das bedeutet, ich habe das Haus für ein paar Stunden ganz für mich allein."

    # say L2477 oli
    old "That's an opportunity that we can't let pass."
    new "Das ist eine Gelegenheit, die wir nicht ungenutzt lassen dürfen."

    # say L2478 oli
    old "So, can you come with me to my house?"
    new "Dann, kannst du mit mir zu mir nach Hause kommen?"

    # say L2481 oli
    old "Alright! Let's not waste any time and go then."
    new "Okay! Lass uns keine Zeit verlieren und losgehen."

    # say L2502 oli
    old "Alright, are you ready for it?"
    new "Okay, bist du bereit dafür?"

    # say L2505 oli
    old "Ok, give me a second to freshen up, and we'll do it."
    new "Okay, gib mir eine Sekunde, um mich frisch zu machen, dann machen wir es."

    # say L2512 pla
    old "Ok, I guess now's the time to call Brixxida."
    new "Okay, dann rufe ich jetzt wohl Brixxida an."

    # say L2525 bri
    old "Wow! What's this?"
    new "Wow! Was ist das?"

    # say L2527 pla
    old "Hey, this girl and I are about to start having sex."
    new "Hey, Brixxida, diese Frau und ich sind gerade dabei, miteinander zu schlafen."

    # say L2529 pla
    old "So I summoned you to make sure everything goes well."
    new "Dann habe ich dich gerufen, um sicherzustellen, dass alles gut läuft."

    # say L2530 bri
    old "I see, good, that's good."
    new "Ich sehe, gut, das ist gut."

    # say L2538 oli
    old "Hey, are you ready?"
    new "Hey, bist du bereit?"

    # say L2539 pla
    old "Sure, sure, let's do it."
    new "Klar, klar, lass uns anfangen."

    # say L2540 oli
    old "Ok, just remember to be gentle... I'm still not used to your big cock."
    new "Okay, aber vergiss nicht, vorsichtig zu sein... Ich bin noch nicht daran gewöhnt, wie groß du bist."

    # say L2541 pla
    old "Sure, of course..."
    new "Klar, natürlich..."

    # say L2559 oli
    old "I'm sure that this time it worked."
    new "Ich bin sicher, dass es dieses Mal geklappt hat."

    # say L2561 pla
    old "Yeah, I'm sure it did."
    new "Klar, ich bin mir sicher, dass es funktioniert hat."

    # say L2562 pla
    old "At least this way you can get your family off your back a little."
    new "Zumindest so kannst du deine Familie ein bisschen loswerden."

    # say L2565 oli
    old "Yeah, well, I wouldn't be so sure about that."
    new "Na ja, da wäre ich mir nicht so sicher."

    # say L2566 oli
    old "But let's see how everything goes."
    new "Aber lass uns abwarten, wie sich alles entwickelt."

    # say L2567 oli
    old "But now, I think you better leave before my mom comes back and sees us like this."
    new "Aber jetzt denke ich, du solltest besser gehen, bevor meine Mom zurückkommt und uns so sieht."

    # say L2568 oli
    old "That shouldn't be a problem if we're supposed to be dating."
    new "Das sollte kein Problem sein, wenn wir angeblich zusammen sind."

    # say L2569 oli
    old "But let's not push our luck."
    new "Aber lass uns nicht unser Glück strapazieren."

    # say L2570 pla
    old "Sure, I understand. I'll leave, but I'll check on you later to see how you're doing."
    new "Klar, ich verstehe. Ich geh dann, aber ich schau später noch mal nach dir."

    # say L2572 oli
    old "Thank you [pla], for everything."
    new "Danke [pla], für alles."

    # say L2574 pla
    old "Alright, I'll see you later."
    new "Okay, dann sehen wir uns später."

    # say L2591 bri
    old "I'm sure that this is going to work!"
    new "Ich bin sicher, dass das klappen wird!"

    # say L2592 bri
    old "Well done!"
    new "Gut gemacht!"

    # say L2593 pla
    old "Thank you, I'm glad you're satisfied with the results."
    new "Danke, ich freue mich, dass du mit den Ergebnissen zufrieden bist."

    # say L2595 bri
    old "Of course I am."
    new "Natürlich bin ich das."

    # say L2596 bri
    old "And now we can move on to the next target!"
    new "Und jetzt können wir uns dem nächsten Ziel widmen!"

    # say L2597 pla
    old "Don't we have to make sure that everything's alright with Olivia before doing that?"
    new "Müssen wir uns nicht erst vergewissern, dass es Olivia gut geht, bevor wir das tun?"

    # say L2598 bri
    old "Oh don't worry, I'm sure that everything's going to be alright!"
    new "Oh mach dir keine Sorgen, ich bin sicher, dass alles gut wird!"

    # say L2599 bri
    old "There's no doubt about it."
    new "Da bin ich mir sicher."

    # say L2601 pla
    old "I guess I'll get to looking for new girls."
    new "Ich schätze, ich werde nach neuen Mädchen suchen."

    # say L2602 pla
    old "I'll let you know what I find."
    new "Ich sag dir Bescheid, was ich finde."

    # say L2604 bri
    old "Great! I'll be waiting."
    new "Super! Ich freu mich drauf."

    # say L2605 bri
    old "Once again, well done [pla]."
    new "Noch einmal, gut gemacht [pla]."

    # say L2625 pla
    old "Hey Olivia, how are you?"
    new "Hey Olivia, wie geht's dir?"

    # say L2628 oli
    old "I'm doing fine."
    new "Mir geht es gut."

    # say L2629 oli
    old "Although I have to say it's been difficult to deal with my family these last few days."
    new "Obwohl ich zugeben muss, dass es in den letzten Tagen schwierig war, mit meiner Familie klarzukommen."

    # say L2630 pla
    old "It has?"
    new "Wirklich?"

    # say L2632 oli
    old "Yeah, I got a pregnancy test done."
    new "Ja, ich hab einen Schwangerschaftstest machen lassen."

    # say L2633 oli
    old "My dad and mom wanted to make sure that I actually was pregnant and I wasn't just lying to get out of the marriage."
    new "Mein Dad und Mom wollten sichergehen, dass ich wirklich schwanger bin und ich sie nicht angelogen habe, um der Hochzeit zu entkommen."

    # say L2634 oli
    old "So, they took me to an ob-gyn and asked them to do the test."
    new "Dann haben sie mich zu einem Frauenarzt gebracht und ihn gebeten, den Test durchzuführen."

    # say L2635 pla
    old "And? What did it say?"
    new "Und? Was hat es gesagt?"

    # say L2637 oli
    old "It came out positive!"
    new "Es war positiv!"

    # say L2638 oli
    old "It's good that I got pregnant when I did, because otherwise who knows what would've happened."
    new "Es ist gut, dass ich schwanger geworden bin, als ich es getan habe, sonst weiß man nicht, was passiert wäre."

    # say L2639 oli
    old "I would probably be on a plane on my way to India right now."
    new "Ich wäre wahrscheinlich jetzt auf dem Weg nach Indien."

    # say L2640 pla
    old "Well, I guess it's a good thing that you're pregnant then."
    new "Na, dann ist es ja gut, dass du schwanger bist."

    # say L2641 pla
    old "Does that mean that your parents are going to back off now?"
    new "Dann werden deine Eltern jetzt wohl Ruhe geben?"

    # say L2642 oli
    old "Well, not really, if anything I think they'll just get even more intense."
    new "Na ja, eigentlich nicht, im Gegenteil, ich denke, sie werden noch intensiver."

    # say L2644 oli
    old "My dad's incredibly furious right now."
    new "Mein Dad ist total wütend im Moment."

    # say L2645 oli
    old "You should've seen him, talking about how his good name is being dragged through the mud."
    new "Du hättest ihn sehen sollen, wie er über seinen guten Namen geschwafelt hat, der durch den Dreck gezogen wird."

    # say L2646 oli
    old "They also told me to let you know that you should get ready for a marriage."
    new "Sie haben mir auch gesagt, dass du dich auf eine Hochzeit vorbereiten sollst."

    # say L2647 oli
    old "Because there's no way that I'm having a bastard child."
    new "Weil ich auf keinen Fall ein Bastardkind haben werde."

    # say L2649 pla
    old "W- what? M- marriage?"
    new "W-was? E- eh, Heirat?"

    # say L2650 pla
    old "B- but I thought you said that wasn't going to happen."
    new "B- aber ich dachte, du hast gesagt, dass das nicht passieren würde."

    # say L2652 oli
    old "And it probably won't, because I won't let it come to that."
    new "Und es wird wahrscheinlich auch nicht passieren, weil ich das nicht zulassen werde."

    # say L2654 oli
    old "Besides, remember that the plan is to interrupt the pregnancy before it gets to term."
    new "Außerdem, erinnere dich daran, dass der Plan ist, die Schwangerschaft vor der Geburt abzubrechen."

    # say L2656 oli
    old "So there is some pressure because of it."
    new "Dann gibt es ja etwas Druck deswegen."

    # say L2658 oli
    old "But I don't think my mom's going to consult you about wedding plans anytime soon."
    new "Aber ich glaube nicht, dass meine Mom dich bald um Rat für die Hochzeitspläne fragen wird."

    # say L2659 pla
    old "I see... I guess that's a little reassuring."
    new "Ich sehe... Das ist ein bisschen beruhigend."

    # say L2660 oli
    old "But anyway, that's not what's most important."
    new "Aber egal, das ist nicht das Wichtigste."

    # say L2665 oli
    old "What's most important is what I'm going to do next after this pregnancy."
    new "Das Wichtigste ist, was ich als Nächstes nach dieser Schwangerschaft machen werde."

    # say L2667 pla
    old "Are you planning something else?"
    new "Planst du was anderes?"

    # say L2668 oli
    old "Of course, my plan is not to be a young mom."
    new "Natürlich, mein Plan ist es nicht, eine junge Mutter zu werden."

    # say L2670 oli
    old "And I didn't get pregnant just to get out of an arranged marriage."
    new "Und ich bin nicht schwanger geworden, um aus einer arrangierten Ehe rauszukommen."

    # say L2671 oli
    old "This whole situation is just to buy some time for me to start doing some things that I want to do."
    new "Diese ganze Situation ist nur, um mir etwas Zeit zu kaufen, um Dinge zu tun, die ich machen will."

    # say L2673 oli
    old "I decided that I want to get into college."
    new "Ich hab mich entschieden, ins College zu gehen."

    # say L2675 oli
    old "I need to get on my mother's good side, and to establish a future for myself."
    new "Ich muss in den guten books meiner Mutter kommen und mir eine Zukunft aufbauen."

    # say L2677 pla
    old "That sounds great Olivia, it sounds like a great plan."
    new "Das klingt toll Olivia, das hört sich wie ein super Plan an."

    # say L2679 oli
    old "Yeah, but listen..."
    new "Ja, aber hör mal..."

    # say L2681 oli
    old "I don't really know how to ask you this."
    new "Ich weiß nicht so recht, wie ich dich danach fragen soll."

    # say L2683 oli
    old "But I was wondering if you could help me study for the college entrance exams."
    new "Aber ich hab mich gefragt, ob du mir bei den Aufnahmeprüfungen fürs College helfen könntest."

    # say L2685 oli
    old "I know that I've already asked way too much of you, more than what would be reasonable."
    new "Ich weiß, dass ich schon viel zu viel von dir verlangt habe, mehr als fair wäre."

    # say L2687 oli
    old "But the truth is that you're a very good teacher, and I think that to get into college I will really need your help."
    new "Aber die Wahrheit ist, dass du ein sehr guter Lehrer bist und ich denke, um ins College zu kommen, werde ich deine Hilfe wirklich brauchen."

    # say L2689 oli
    old "I would understand it if you don't want to do it."
    new "Ich würde es verstehen, wenn du nicht willst."

    # say L2690 oli
    old "But if you will, that would be the greatest thing."
    new "Aber wenn du es tust, wäre das das Allergrößte."

    # say L2692 pla
    old "Oh yeah for sure, I'll help you."
    new "Oh ja klar, ich helfe dir."

    # say L2693 pla
    old "Of course, I don't have a problem with doing that."
    new "Natürlich, ich hab damit überhaupt kein Problem."

    # say L2694 pla
    old "And I think you need it, that would help you to get out from under your parents."
    new "Und ich denke, du brauchst das, das würde dir helfen, aus der Schusslinie deiner Eltern zu kommen."

    # say L2695 pla
    old "So I'll be more than happy to help you study."
    new "Dann mache ich das gerne für dich."

    # say L2697 oli
    old "Oh god [pla] you have no idea how good it is to hear that! Thank you so much!"
    new "Oh Gott [pla] du hast ja keine Ahnung, wie gut das klingt! Danke schön!"

    # say L2698 pla
    old "Glad to help you."
    new "Gern helfe ich dir."

    # say L2700 pla
    old "Hmm, so I guess we should get going to your house then?"
    new "Hmm, dann sollten wir wohl zu deinem Haus gehen, oder?"

    # say L2701 oli
    old "No, I don't think right now would be a good idea."
    new "Nein, ich glaube, jetzt wäre nicht der richtige Zeitpunkt."

    # say L2703 oli
    old "I have to gather some more information about college admission exams and such."
    new "Ich muss noch mehr Informationen über die Aufnahmeprüfungen fürs College sammeln."

    # say L2704 oli
    old "But as soon as I have it I'll let you know."
    new "Aber sobald ich es habe, lass ich es dich wissen."

    # say L2706 pla
    old "Alright, I'll be waiting."
    new "Okay, ich warte darauf."

    # say L2707 pla
    old "I guess I'll see you later."
    new "Dann sehen wir uns später."

    # say L2726 oli
    old "Hey [pla]! How are you doing?"
    new "Hey [pla]! Wie geht's dir?"

    # say L2727 pla
    old "I'm alright, and you?"
    new "Ich bin okay, und du?"

    # say L2729 oli
    old "I'm doing well, actually I'm glad that I caught you here."
    new "Mir geht es gut, ich bin froh, dich hier zu erwischen."

    # say L2730 oli
    old "I got to checking the information that I told you about."
    new "Ich hab die Infos angeguckt, von denen ich dir erzählt hab."

    # say L2731 oli
    old "So I was wondering if you could come with me to my house so that we can start studying today."
    new "Dann dachte ich, ob du mit zu mir kommen könntest, damit wir heute anfangen können zu lernen."

    # say L2733 pla
    old "Sure, I'll gladly come with you to study."
    new "Klar, ich komme gerne mit dir zum Lernen."

    # say L2734 oli
    old "Great! Let's go then."
    new "Super! Lass uns dann losgehen."

    # say L2748 oli
    old "Alright, I think we should get to it, right?"
    new "Okay, ich denke, wir sollten loslegen, oder?"

    # say L2759 pla
    old "Alright, so what are we going to study?"
    new "Okay, woran wollen wir uns denn mal ranhalten?"

    # say L2761 oli
    old "We're going to be covering the entrance exam for the design school."
    new "Wir werden uns mit dem Aufnahmetest für die Designschule befassen."

    # say L2762 oli
    old "It came to my mind that maybe there could be a couple of previous exams online that I could use to study."
    new "Mir ist eingefallen, dass es vielleicht ein paar alte Klausuren im Internet gibt, mit denen ich mich vorbereiten kann."

    # say L2764 pla
    old "Hmm, so you want to study design..."
    new "Hmm, willst du also Design studieren..."

    # say L2765 pla
    old "I mean, do you think I would be the best person to help you with it?"
    new "Ich meine, denkst du, ich wäre die beste Person, um dir dabei zu helfen?"

    # say L2767 pla
    old "I don't know anything about the subject, to be honest."
    new "Ich weiß ehrlich gesagt nichts über das Thema."

    # say L2768 oli
    old "That's alright, you don't actually have to know."
    new "Das ist in Ordnung, du musst es nicht unbedingt wissen."

    # say L2769 oli
    old "The college I'm applying to has a fundamental curriculum that every student must complete."
    new "Die Uni, auf die ich mich bewerbe, hat ein grundlegendes Curriculum, das jeder Student absolvieren muss."

    # say L2771 oli
    old "And it's very heavy on chemistry, math, and sciences."
    new "Und es legt sehr viel Wert auf Chemie, Mathematik und Naturwissenschaften."

    # say L2772 oli
    old "So it's alright if that's what we study. Because those topics are going to be the focus of the admission exam."
    new "Dann ist es okay, wenn wir uns damit beschäftigen. Denn diese Themen werden bei der Aufnahmeprüfung im Mittelpunkt stehen."

    # say L2774 pla
    old "Oh, I see, alright, let's get to it then."
    new "Oh, ich verstehe, okay, dann lass uns anfangen."

    # say L2785 pla
    old "Uhmm, not much, it's just that you're taking very well to this."
    new "Hmm, nicht viel, es ist nur, dass du dich hier wirklich gut anpasst."

    # say L2786 pla
    old "But before, you were struggling so much to learn the school topics."
    new "Aber vorher hast du dich doch so schwergetan, die Schultopics zu lernen."

    # say L2788 oli
    old "Well, as I told you before, I'm not dumb."
    new "Na, wie ich dir schon gesagt habe, bin ich nicht dumm."

    # say L2789 oli
    old "It's just that the school topics are so much more boring to me."
    new "Es ist nur, dass die Themen von der Schule mir so viel langweiliger sind."

    # say L2790 oli
    old "They're not interesting in any way."
    new "Sie sind auf keine Weise interessant."

    # say L2791 oli
    old "I mean, these are most of the same topics."
    new "Ich meine, es sind die meisten der gleichen Themen."

    # say L2793 oli
    old "But I'm studying them to get into college and do something that I actually want to do."
    new "Aber ich studiere sie, um ins College zu kommen und etwas zu machen, das ich wirklich will."

    # say L2796 oli
    old "It also has to do with the fact that I kinda know I have to push myself through this."
    new "Das hat auch damit zu tun, dass ich irgendwie weiß, dass ich mich durch diesen Mist quälen muss."

    # say L2797 oli
    old "With how far I've come already, it would be a real shame if I gave up now."
    new "Mit dem, was ich schon geschafft habe, wäre es echt schade, jetzt aufzugeben."

    # say L2799 pla
    old "I see, that actually makes a lot of sense."
    new "Das ergibt tatsächlich Sinn."

    # say L2800 oli
    old "Come on, let's keep going."
    new "Komm schon, lass uns weitermachen."

    # say L2808 pla
    old "Alright, I think that should be enough for today."
    new "Okay, ich denke, das reicht für heute."

    # say L2810 oli
    old "Really? Already?"
    new "Wirklich? Schon?"

    # say L2812 pla
    old "Yeah sure, this was just an introductory session."
    new "Klar, das war nur eine Einführungssession."

    # say L2813 pla
    old "So we should stop before we get too tired."
    new "Dann sollten wir besser aufhören, bevor wir zu müde werden."

    # say L2814 oli
    old "Hmm, yeah I guess you're right."
    new "Hmm, ja, ich schätze, du hast recht."

    # say L2823 pla
    old "Alright, that was very good."
    new "Okay, das war sehr gut."

    # say L2824 pla
    old "If we keep going like that, I'm sure you'll ace that entrance exam."
    new "Wenn wir so weitermachen, bin ich sicher, dass du den Aufnahmetest bestehst."

    # say L2826 oli
    old "For everything, you know?"
    new "Für alles, weißt du?"

    # say L2827 oli
    old "I have been coming up with these crazy plans, and you've kept supporting me."
    new "Ich habe diese verrückten Pläne geschmiedet und du hast mich die ganze Zeit unterstützt."

    # say L2828 oli
    old "Thanks a lot."
    new "Danke schön."

    # say L2830 pla
    old "So, I guess I should get going, but I'll come back soon so that we can keep studying."
    new "Dann werde ich wohl mal losgehen, aber ich komme bald wieder, damit wir weiterlernen können."

    # say L2831 pla
    old "And of course, to check on the pregnancy."
    new "Und natürlich, um nach der Schwangerschaft zu sehen."

    # say L2832 oli
    old "Sure thing [pla], thanks a lot."
    new "Klar, [pla], danke schön."

    # say L2850 oli
    old "Hey [pla]! Did you come to study again?"
    new "Hey [pla]! Bist du wieder zum Lernen gekommen?"

    # say L2851 pla
    old "Yeah, I figured that it's time for another session."
    new "Klar, ich dachte, es ist Zeit für eine weitere Session."

    # say L2852 oli
    old "Great, let's get to it then."
    new "Super, dann lass uns anfangen."

    # say L2853 pla
    old "Alright, where did we leave off last time?"
    new "Okay, wo waren wir das letzte Mal stehengeblieben?"

    # say L2854 oli
    old "I think it was this topic here..."
    new "Ich glaube, es war dieses Thema hier..."

    # say L2856 pla
    old "Oh yeah! For sure!"
    new "Oh ja! Auf jeden Fall!"

    # say L2858 pla
    old "Alright, let's continue from there then."
    new "Okay, dann fahren wir da weiter."

    # say L2895 pla
    old "Alright, that was a good session."
    new "Okay, das war eine gute Session."

    # say L2896 pla
    old "Just a couple more and I know you'll have what it takes to ace those exams."
    new "Noch ein paar und ich weiß, dass du die Klausuren bestehen wirst."

    # say L2898 oli
    old "Thanks a lot [pla]..."
    new "Danke [pla]..."

    # say L2899 oli
    old "For everything."
    new "Für alles."

    # say L2901 pla
    old "Hey, my pleasure."
    new "Hey, gerne geschehen."

    # say L2902 pla
    old "I have to leave for now, but I'll come back to see you soon, alright?"
    new "Ich muss jetzt los, aber ich komme bald wieder, okay?"

    # say L2903 oli
    old "Sure, no problem, see you."
    new "Klar, kein Problem, bis bald."

    # say L2944 pla
    old "Hi Mrs. Priya, how are you?"
    new "Hi Mrs. Priya, wie geht es Ihnen?"

    # say L2946 vee
    old "Are you here looking for Olivia?"
    new "Bist du hier, um Olivia zu suchen?"

    # say L2947 pla
    old "Uhh, yeah, I was kinda hoping to catch her here."
    new "Uhh, ja, ich hoffte, sie hier zu erwischen."

    # say L2948 vee
    old "Well, no, she's at school."
    new "Na, nein, sie ist in der Schule."

    # say L2949 vee
    old "And you should be there too, you know?"
    new "Und du solltest auch da sein, weißt du?"

    # say L2950 pla
    old "Uh, yeah, yeah, you're probably right."
    new "Klar, ja, du hast wahrscheinlich recht."

    # say L2951 pla
    old "I'll come by later then."
    new "Dann komme ich später vorbei."

    # say L2953 vee
    old "Sure, I'll let her know you stopped by."
    new "Klar, ich sag's ihr."

    # say L2956 pla
    old "Hi, Mrs. Priya, how are you?"
    new "Hi, Frau Priya, wie geht es Ihnen?"

    # say L2958 vee
    old "Hello, [pla]. I'm doing fine, and you?"
    new "Hallo, [pla]. Mir geht es gut, und dir?"

    # say L2960 pla
    old "I'm alright, thank you."
    new "Mir geht es gut, danke."

    # say L2962 vee
    old "That's good to hear..."
    new "Das ist gut zu hören..."

    # say L2964 vee
    old "So tell me, did you come looking for Olivia?"
    new "Dann erzähl mal, suchst du Olivia?"

    # say L2966 pla
    old "That's right. Is she here?"
    new "Das stimmt. Ist sie hier?"

    # say L2968 vee
    old "Great... Yes, she's in her room."
    new "Super... Ja, sie ist in ihrem Zimmer."

    # say L2970 vee
    old "You can go in, go ahead, don't mind me."
    new "Du kannst reingehen, mach ruhig, lass dich nicht stören."

    # say L2971 pla
    old "Uh... S- sure, thank you."
    new "Uh... S-sicher, danke."

    # say L2973 pla
    old "I guess I'll see you around, Mrs. Priya."
    new "Ich schätze, ich sehe dich dann mal, Mrs. Priya."

    # say L2974 vee
    old "Yes, of course. Good afternoon, [pla]."
    new "Ja, natürlich. Guten Nachmittag, [pla]."

    # say L2984 pla
    old "Alright, that's good. I think we can move on to something else."
    new "Okay, das ist gut. Ich denke, wir können zu was anderem übergehen."

    # say L2985 oli
    old "Ok, that sounds good."
    new "Ok, das klingt gut."

    # say L2988 vee
    old "Olivia, are you there? I'm coming in!"
    new "Olivia, bist du da? Ich komme rein!"

    # say L2999 vee
    old "Oh [pla], hi... So you were here too."
    new "Oh [pla], hallo... Du warst also auch hier."

    # say L3000 pla
    old "H- hi Mrs. Priya."
    new "H-hi Mrs. Priya."

    # say L3002 oli
    old "We were just studying, Mom, nothing else."
    new "Wir haben nur gelernt, Mama, nichts weiter."

    # say L3004 vee
    old "Yeah well, I hope it's going better than last time you two studied."
    new "Na ja, ich hoffe, es läuft besser als beim letzten Mal, als ihr gelernt habt."

    # say L3007 oli
    old "Anyway, what do you want?"
    new "Was willst du dann?"

    # say L3009 vee
    old "What do you mean by that? Did you forget that we have a phone call with your father to talk about your pregnancy?"
    new "Was meinst du damit? Hast du vergessen, dass wir mit deinem Vater telefonieren müssen, um über deine Schwangerschaft zu sprechen?"

    # say L3012 vee
    old "And before you ask, no, we cannot reschedule, you know how Vihaan is about his time."
    new "Und bevor du fragst, nein, wir können das nicht verschieben, du weißt ja, wie Vihaan mit seiner Zeit ist."

    # say L3013 oli
    old "Oh shoot! I forgot about it!"
    new "Oh Mist! Ich hab’s vergessen!"

    # say L3017 oli
    old "Listen [pla], I'm going to have to step out for a while, this call with my dad is very important."
    new "Hör zu [pla], ich muss für eine Weile raus, dieser Anruf mit meinem Dad ist sehr wichtig."

    # say L3018 oli
    old "But please don't leave."
    new "Aber bitte geh nicht."

    # say L3020 oli
    old "This isn't going to take too much time. And we have a lot more to cover in today's session."
    new "Das dauert nicht lange. Und wir haben noch viel mehr für heute zu tun."

    # say L3022 oli
    old "So, I'll talk to my dad, and I'll come back so that we can keep studying."
    new "Dann rede ich mit meinem Dad und komme wieder, damit wir weitermachen können."

    # say L3023 pla
    old "Oh, a- alright, sure, no problem."
    new "Oh, a-a klar, okay, kein Problem."

    # say L3025 vee
    old "Come on, we have to go call him now."
    new "Komm schon, wir müssen ihn jetzt anrufen."

    # say L3029 oli
    old "Alright, alright, let's go."
    new "Okay, okay, lass uns gehen."

    # say L3041 pla
    old "Hmm, I mean, I guess I'll just sit here and wait for her to come back."
    new "Hmm, ich meine, ich warte einfach hier, bis sie zurückkommt."

    # say L3049 aye
    old "Hey brother-in-law! How are you?"
    new "Hey Schwager! Wie geht's dir?"

    # say L3050 pla
    old "Uhmm, hi... I'm doing fine."
    new "Hmm, hallo... Mir geht's gut."

    # say L3059 aye
    old "But what are you doing here all alone?"
    new "Aber was machst du hier ganz allein?"

    # say L3061 pla
    old "Oh, I was helping your sister study."
    new "Oh, ich habe deiner Schwester beim Lernen geholfen."

    # say L3063 pla
    old "And you know, spending time with her and checking that the pregnancy is going well."
    new "Und du weißt, Zeit mit ihr verbringen und sicherstellen, dass die Schwangerschaft gut läuft."

    # say L3065 pla
    old "But she had to step out with your mom for a call they had scheduled with your dad."
    new "Aber sie musste mit deiner Mom rausgehen, weil sie mit deinem Dad telefonieren mussten."

    # say L3066 pla
    old "So I'm just waiting here for her to come back."
    new "Dann warte ich hier einfach auf sie, bis sie zurückkommt."

    # say L3068 aye
    old "I see, hmm, that's interesting, I guess."
    new "Ich seh, hm, das ist interessant, schätze."

    # say L3070 aye
    old "Do you like spending time with her?"
    new "Magst du Zeit mit ihr verbringen?"

    # say L3071 pla
    old "Uh, I mean, y- yeah sure."
    new "Klar, also ja, klar."

    # say L3072 aye
    old "I see, I see."
    new "Ich seh's, ich seh's."

    # say L3074 aye
    old "And you like to do it even though she's just a fat cow?"
    new "Und du magst es trotzdem, obwohl sie nur eine fette Kuh ist?"

    # say L3075 pla
    old "W- what? What are you talking about?"
    new "W-was? Wovon redest du?"

    # say L3077 aye
    old "Nothing much, I was just wondering if you still like to spend time with her."
    new "Nicht viel, ich hab mich nur gefragt, ob du immer noch gerne Zeit mit ihr verbringst."

    # say L3078 aye
    old "Because she no longer looks as beautiful as she did before."
    new "Weil sie nicht mehr so schön aussieht wie früher."

    # say L3080 aye
    old "You know, she's been getting fatter and fatter."
    new "Du weißt schon, sie wird immer dicker."

    # say L3082 aye
    old "I can't imagine that's attractive in any way."
    new "Ich kann mir nicht vorstellen, dass das auf irgendeine Weise attraktiv ist."

    # say L3084 pla
    old "Uhmm, to be honest with you that's not even something I had considered."
    new "Hmm, ehrlich gesagt hab ich mir das noch gar nicht überlegt."

    # say L3086 pla
    old "I mean, she just looks a little bit bigger because of the pregnancy."
    new "Ich meine, sie sieht einfach ein bisschen größer aus wegen der Schwangerschaft."

    # say L3088 pla
    old "But that's completely normal, right?"
    new "Aber das ist doch total normal, oder?"

    # say L3090 aye
    old "Yeah, yeah, as I was saying, she's a fat cow."
    new "Ja, ja, wie ich schon sagte, sie ist eine fette Kuh."

    # say L3092 aye
    old "But anyway, that's not important right now."
    new "Aber egal, das ist jetzt nicht wichtig."

    # say L3093 aye
    old "You know? I've been thinking a lot about you recently."
    new "Weißt du, ich hab ne Menge über dich nachgedacht lately."

    # say L3094 pla
    old "Y- you have? H- how come?"
    new "Du hast? W-wieso?"

    # say L3095 aye
    old "I just think it's very unfortunate that you had to fall in love with the worst part of our family."
    new "Ich finde es nur sehr schade, dass du dich in den schlechtesten Teil unserer Familie verliebt hast."

    # say L3097 aye
    old "I mean sure, my sister's pretty."
    new "Ich meine, klar, meine Schwester ist hübsch."

    # say L3099 aye
    old "But you know that she doesn't care about you, not really, right?"
    new "Aber du weißt doch, dass sie dir nicht wirklich zugetan ist, oder?"

    # say L3101 aye
    old "She's just using you to get out of going to India."
    new "Sie nutzt dich nur, um nicht nach Indien zu müssen."

    # say L3102 aye
    old "I'm sorry it has to be like that."
    new "Es tut mir leid, dass es so ist."

    # say L3103 pla
    old "Uh- I uh-"
    new "Uh- ich äh-"

    # say L3104 pla
    old "I'm not sure I know what you're talking about..."
    new "Ich bin mir nicht sicher, wovon du redest..."

    # say L3106 aye
    old "Yeah right, of course you don't!"
    new "Klar, natürlich weißt du das nicht!"

    # say L3107 aye
    old "But anyway, it's a shame that she's not only using you, but that you also have to have sex with her."
    new "Aber egal, es ist echt schade, dass sie dich nicht nur ausnutzt, sondern du auch noch mit ihr schlafen musst."

    # say L3108 aye
    old "With how bad she is, it surprises me that you're that much into her."
    new "Mit so einer Schlampe wundert es mich, dass du so abgehst."

    # say L3109 pla
    old "Uh... W- what do you mean?"
    new "Uh... W- was meinst du damit?"

    # say L3110 aye
    old "Oh come on [pla]!"
    new "Oh komm schon [pla]!"

    # say L3112 aye
    old "You know my sister's nothing special in bed."
    new "Du weißt doch, dass meine Schwester im Bett nichts Besonderes ist."

    # say L3113 aye
    old "It only took me the other day to be sure that she's not any good with sex stuff."
    new "Es hat mich nur den anderen Tag gekostet, sicher zu sein, dass sie im Bett nichts Besonderes ist."

    # say L3115 aye
    old "She was sucking your dick without any interest in doing it."
    new "Sie hat deinen Schwanz gelutscht, als wäre es ihr völlig egal."

    # say L3116 aye
    old "Which is a shame because that big dick of yours deserves better."
    new "Das ist schade, denn dieser dicke Schwanz von dir verdient besser."

    # say L3123 aye
    old "I mean, it's such an amazing dick. So big and so thick."
    new "Ich meine, es ist ein unglaublicher Schwanz. So groß und so dick."

    # say L3125 aye
    old "My sister's just wasting it with that sloppy technique of hers."
    new "Meine Schwester verschwendet es einfach mit ihrer schludrigen Technik."

    # say L3126 aye
    old "And in bed..."
    new "Und im Bett..."

    # say L3128 aye
    old "I bet she's just a dead fish, she probably isn't anything special there."
    new "Ich wette, sie ist nur eine tote Nudel, wahrscheinlich ist sie da auch nichts Besonderes."

    # say L3134 aye
    old "I was thinking that it would do you well to have a small tasting of what you've been missing..."
    new "Ich dachte, es würde dir guttun, einen kleinen Vorgeschmack auf das zu bekommen, was du bisher verpasst hast..."

    # say L3135 pla
    old "Uh, I uh..."
    new "Uh, ich äh..."

    # say L3136 pla
    old "I- think you shouldn't be here..."
    new "Ich- ich glaube, du solltest nicht hier sein..."

    # say L3137 pla
    old "Y- your sister could think the wrong thing."
    new "Y- deine Schwester könnte das Falsche denken."

    # say L3139 aye
    old "And what would that be?"
    new "Und was wäre das?"

    # say L3145 pla
    old "Y- you know... L- like."
    new "Y- du weißt schon... L- wie."

    # say L3146 aye
    old "Come on brother-in-law, I know you'll love it."
    new "Komm schon, Schwager, ich weiß, dass du es lieben wirst."

    # say L3156 pla
    old "W- what are you doing?!!"
    new "W- was machst du da?!"

    # say L3157 aye
    old "Come on! I know you'll love this!"
    new "Komm schon! Ich weiß, dass du das lieben wirst!"

    # say L3158 pla
    old "W- what if your sister or your mom comes in here?!"
    new "W- was, wenn deine Schwester oder deine Mum reinkommt?!"

    # say L3159 aye
    old "Ugh, relax, nothing will happen!"
    new "Ugh, beruhige dich, da passiert nichts!"

    # say L3170 aye
    old "I'm sure you've never had anything like it."
    new "Ich bin sicher, du hast noch nie so etwas erlebt."

    # say L3172 aye
    old "Now you can see what you're missing by doing it with my sister."
    new "Jetzt kannst du sehen, was du verpasst, wenn du es mit meiner Schwester machst."

    # say L3173 aye
    old "It's a shame that you have to endure something like that."
    new "Schade, dass du so etwas ertragen musst."

    # say L3175 aye
    old "But you never know, maybe you and I can have another one of these sessions sometime."
    new "Aber wer weiß, vielleicht können wir irgendwann mal wieder so eine Session haben."

    # say L3176 aye
    old "Or maybe we could do something else."
    new "Oder vielleicht könnten wir was anderes machen."

    # say L3177 pla
    old "Yeah... That's great."
    new "Klar... Das ist super."

    # say L3179 pla
    old "But it might be better if you leave for now, you know?"
    new "Aber es wäre vielleicht besser, wenn du jetzt gehst, weißt du?"

    # say L3180 aye
    old "Sure, I guess I will."
    new "Klar, ich denke, ich werde."

    # say L3181 aye
    old "But I'll be seeing you later."
    new "Aber ich seh dich später."

    # say L3188 pla
    old "God... She is something else."
    new "Verdammt... Sie ist was Besonderes."

    # say L3189 pla
    old "Is everyone in this family so brazen?"
    new "Ist jeder in dieser Familie so frech?"

    # say L3190 pla
    old "I'm just glad nobody saw us."
    new "Ich bin einfach froh, dass niemand uns gesehen hat."

    # say L3203 oli
    old "Hey [pla], I'm sorry I kept you waiting for so long."
    new "Hey [pla], es tut mir leid, dass ich dich so lange warten ließ."

    # say L3205 pla
    old "Hey, it's alright, no problem."
    new "Hey, ist schon gut, kein Problem."

    # say L3206 pla
    old "I imagine you had a lot to talk with your dad, didn't you?"
    new "Ich stelle mir vor, du hattest viel zu besprechen mit deinem Dad, oder?"

    # say L3208 oli
    old "Oh yeah, a lot, he just kept going and going."
    new "Oh ja, viel, er hat einfach weiter und weiter geredet."

    # say L3210 pla
    old "I understand. Are you ready to get back to studying?"
    new "Ich verstehe. Bist du bereit, wieder zu lernen?"

    # say L3212 oli
    old "You know what? I think we should stop for the day."
    new "Weißt du was? Ich denke, wir sollten für heute Schluss machen."

    # say L3213 oli
    old "I just had a very bad conversation with my Dad and mom and I don't feel like studying at the moment."
    new "Ich hatte gerade eine sehr schlechte Unterhaltung mit meinem Dad und meiner Mom und ich habe im Moment keine Lust zu lernen."

    # say L3214 oli
    old "I think I just want to rest a little bit."
    new "Ich glaube, ich will einfach ein bisschen ausruhen."

    # say L3215 pla
    old "Oh! Sure, sure, no problem."
    new "Oh! Klar, klar, kein Problem."

    # say L3248 pla
    old "Hey Oli, how are you?"
    new "Hey Oli, wie geht's dir?"

    # say L3250 oli
    old "Hey [pla], how are you doing right now?"
    new "Hey [pla], wie geht es dir gerade?"

    # say L3252 pla
    old "I'm doing fine, I came for us to continue studying. Are you ready?"
    new "Ich bin gut, ich bin hier, damit wir weiterlernen. Bist du bereit?"

    # say L3253 oli
    old "You know? I don't think I am."
    new "Weißt du, ich glaube, ich bin es nicht."

    # say L3254 oli
    old "I've been feeling really bad all day."
    new "Ich fühle mich den ganzen Tag echt schlecht."

    # say L3255 oli
    old "You know, things from the pregnancy."
    new "Du weißt schon, die Sache mit der Schwangerschaft."

    # say L3256 oli
    old "So I think I'll just lay down for a while."
    new "Dann leg ich mich mal ein bisschen hin."

    # say L3257 oli
    old "I'm sorry that you came all the way here for nothing."
    new "Es tut mir leid, dass du extra hierher gekommen bist."

    # say L3259 pla
    old "It's alright, I understand."
    new "Ist schon gut, ich verstehe."

    # say L3260 pla
    old "You're pregnant, it's only natural that the body would feel that way."
    new "Du bist schwanger, da ist es nur natürlich, dass der Körper so reagiert."

    # say L3261 pla
    old "The best thing would be for you to rest, and we can see each other later."
    new "Das Beste wäre, wenn du dich ausruhst, und wir sehen uns später."

    # say L3263 oli
    old "Sure [pla], see you later."
    new "Klar [pla], bis später."

    # say L3293 pla
    old "Hmm, you know, I think I need to use the bathroom."
    new "Hmm, weißt du, ich glaube, ich muss mal aufs Klo."

    # say L3294 oli
    old "Oh, sure!"
    new "Oh, klar!"

    # say L3295 oli
    old "No problem, it's down the hallway."
    new "Kein Problem, es ist den Flur runter."

    # say L3296 pla
    old "Alright, I'll be back in a minute."
    new "Okay, ich bin gleich wieder da."

    # say L3305 pla
    old "Hmm, there's a weird sound coming from that room, what's going on in there?"
    new "Hmm, da kommt ein komischer Laut aus dem Zimmer, was geht da ab?"

    # say L3306 pla
    old "I don't think there's any harm in checking, right?"
    new "Ich denke, da ist nichts dabei, nachzusehen, oder?"

    # say L3316 pla
    old "{i}(And she's masturbating!){/i}"
    new "{i}(Und sie masturbiert!){/i}"

    # say L3319 vee
    old "Oh yes! Yes, do you like what you're seeing honey?"
    new "Oh ja! Ja, gefällt dir, was du siehst, Schatz?"

    # say L3320 vih
    old "Of course I do! I love what I'm seeing!"
    new "Natürlich tue ich das! Ich liebe, was ich sehe!"

    # say L3330 vee
    old "What the fuck is wrong with you?"
    new "Was zum Teufel ist los mit dir?"

    # say L3332 vee
    old "How long were you there just peeping on me?"
    new "Wie lange bist du schon da und hast mich beobachtet?"

    # say L3334 vee
    old "You are my daughter's fiancé! Have you no shame at all?!"
    new "Du bist der Verlobte meiner Tochter! Hast du überhaupt keinen Anstand?!"

    # say L3335 pla
    old "I- I'm so sorry Mrs. Priya!"
    new "Ich- Ich bin so sorry, Mrs. Priya!"

    # say L3337 pla
    old "But I swear to god that it wasn't my intention to break your privacy."
    new "Aber ich schwöre bei Gott, dass es nicht meine Absicht war, deine Privatsphäre zu verletzen."

    # say L3339 pla
    old "I was just coming back from the bathroom when I heard some weird noise coming from the bedroom."
    new "Ich war gerade vom Badezimmer zurück, als ich komische Geräusche aus dem Schlafzimmer hörte."

    # say L3341 pla
    old "I just wanted to make sure that there wasn't anything wrong in here."
    new "Ich wollte nur sichergehen, dass hier alles in Ordnung ist."

    # say L3342 pla
    old "And I accidentally saw you..."
    new "Und ich habe dich versehentlich gesehen..."

    # say L3344 pla
    old "I thought about leaving, but I didn't want to make any noise that could alert you to my presence."
    new "Ich dachte daran zu gehen, aber ich wollte keinen Lärm machen, der dich auf mich aufmerksam machen könnte."

    # say L3345 pla
    old "But I swear to god this was just a big misunderstanding ma'am."
    new "Aber ich schwöre bei Gott, das war nur ein großes Missverständnis, Frau."

    # say L3347 vee
    old "I mean, I want to believe you but..."
    new "Ich meine, ich will dir glauben, aber..."

    # say L3352 vee
    old "{i}(My god is that his hand??){/i}"
    new "{i}(Mein Gott, ist das seine Hand??){/i}"

    # say L3353 vee
    old "{i}(How big is he?!){/i}"
    new "{i}(Wie groß ist er?!){/i}"

    # say L3354 vee
    old "{i}(He must be at least twice as big as Vihaan!){/i}"
    new "{i}(Er muss mindestens doppelt so groß wie Vihaan sein!){/i}"

    # say L3356 pla
    old "Uhmm, ma'am? Is everything alright?"
    new "Hmm, Ma'am? Ist alles in Ordnung?"

    # say L3358 vee
    old "What? Oh yeah..."
    new "Was? Oh ja..."

    # say L3360 vee
    old "Listen [pla], I'll believe you for now."
    new "Hör zu [pla], ich glaube dir fürs Erste."

    # say L3362 vee
    old "But it still isn't alright that you were just spying on me like that."
    new "Aber es ist trotzdem nicht in Ordnung, dass du mich einfach so beobachtet hast."

    # say L3364 vee
    old "Next time knock or something, so that I can at least be prepared."
    new "Das nächste Mal klopfst du oder so, dann bin ich wenigstens vorbereitet."

    # say L3365 pla
    old "Yeah, you're right, I'm sorry."
    new "Ja, du hast recht, tut mir leid."

    # say L3367 vee
    old "Now, my daughter will think something's happening if you take that long to come back from the bathroom."
    new "Jetzt wird meine Tochter noch denken, dass da was los ist, wenn du so lange aufs Klo brauchst."

    # say L3368 vee
    old "So go back already."
    new "Dann geh schon zurück."

    # say L3369 pla
    old "Uh... S- sure, excuse me."
    new "Uh... S-sicher, entschuldige."

    # say L3375 vee
    old "That was a very unpleasant surprise."
    new "Das war eine sehr unangenehme Überraschung."

    # say L3376 vee
    old "But I guess I'll believe him."
    new "Aber ich schätze, ich glaube ihm."

    # say L3377 vee
    old "But I wasn't expecting him to have such a huge boner from seeing me."
    new "Aber ich habe nicht damit gerechnet, dass er so einen riesigen Ständer bekommt, nur weil er mich sieht."

    # say L3378 vee
    old "Is that what Olivia is enjoying?"
    new "Ist das, was Olivia genießt?"

    # say L3379 vee
    old "Meanwhile all I have is my fingers and a laptop..."
    new "Dabei habe ich nur meine Finger und einen Laptop..."

    # say L3384 pla
    old "Damn! I wasn't expecting that!"
    new "Verdammt! Das habe ich nicht erwartet."

    # say L3385 pla
    old "I guess I'm lucky that she didn't get angrier with me."
    new "Ich schätze, ich habe Glück, dass sie nicht noch wütender auf mich wurde."

    # say L3386 pla
    old "Next time I should just keep walking and mind my own business."
    new "Nächstes Mal sollte ich einfach weitergehen und meine eigenen Angelegenheiten regeln."

    # say L3399 oli
    old "Hey, what took you so long? Are you alright?"
    new "Hey, was hat so lange gedauert? Geht es dir gut?"

    # say L3400 pla
    old "Me? O- oh yeah."
    new "Ich? O- oh ja."

    # say L3401 pla
    old "I - I think I just ate something bad."
    new "Ich - ich glaube, ich habe was Falsches gegessen."

    # say L3402 pla
    old "But I'm alright now."
    new "Aber jetzt geht's mir wieder gut."

    # say L3404 oli
    old "Well, let's keep studying."
    new "Na gut, lass uns weiterlernen."

    # say L3405 oli
    old "We have a lot more to do. Come on."
    new "Wir haben noch viel vor uns. Komm schon."

    # say L3428 pla
    old "Oh! Hi Olivia, how are you today?"
    new "Oh! Hallo Olivia, wie geht es dir heute?"

    # say L3430 oli
    old "I'm doing fine, and you? How are you?"
    new "Mir geht's gut, und dir? Wie läufst du so?"

    # say L3432 pla
    old "Oh I'm alright, you know, not much is happening."
    new "Oh, ich bin in Ordnung, weißt du, nicht viel los."

    # say L3433 pla
    old "How are you handling the pregnancy? Is everything alright?"
    new "Wie gehst du mit der Schwangerschaft um? Alles okay?"

    # say L3435 oli
    old "Oh yeah, for the most part it is."
    new "Oh ja, im Großen und Ganzen schon."

    # say L3436 oli
    old "My mom's still in a bad mood, but I think she'll come around."
    new "Meine Mum ist immer noch schlecht gelaunt, aber ich denke, sie wird sich damit abfinden."

    # say L3437 oli
    old "The other thing is that I've been feeling somewhat bad because of nausea and stuff."
    new "Das andere ist, dass ich mich ziemlich schlecht fühle, wegen Übelkeit und so."

    # say L3438 oli
    old "You have seen it, how I get, I start to feel bad and my head hurts and stuff."
    new "Du hast es gesehen, wie ich werde, ich fange an mich schlecht zu fühlen und mein Kopf tut weh und so."

    # say L3439 pla
    old "Yeah, I know, I'm sorry about that."
    new "Ja, ich weiß, es tut mir leid."

    # say L3440 pla
    old "I hope that as the pregnancy goes the symptoms will start to decrease."
    new "Ich hoffe, dass die Symptome im Laufe der Schwangerschaft nachlassen werden."

    # say L3442 oli
    old "Yeah, me too. But I mean is not as if I'm not managing to..."
    new "Ja, ich auch. Aber es ist ja nicht so, als ob ich das nicht schaffe..."

    # say L3450 rub
    old "Hey you idiot! What do you think you're doing bothering her this early in the morning?"
    new "Hey du Idiot! Was denkst du dir eigentlich, sie so früh am Morgen zu belästigen?"

    # say L3453 rub
    old "What? Did you think that just because Olivia's pregnant now you could just start harassing her like it was nothing?"
    new "Was? Glaubst du etwa, nur weil Olivia schwanger ist, kannst du sie einfach so belästigen, als wäre nichts?"

    # say L3456 rub
    old "Well think again buddy, because I'm not gonna let you bother her anymore!"
    new "Dann denk mal wieder, Kumpel, denn ich lasse dich nicht mehr an sie ran!"

    # say L3459 rub
    old "Actually, why don't you get out of here before I call the teachers of you for harassing Olivia?"
    new "Tatsächlich, warum gehst du nicht einfach, bevor ich die Lehrer wegen der Belästigung von Olivia rufe?"

    # say L3461 pla
    old "Hey! I'm not harassing anybody!"
    new "Hey! Ich belästige niemanden!"

    # say L3463 rub
    old "Get out of here or I'll call the teachers!"
    new "Verschwinde hier oder ich rufe die Lehrer!"

    # say L3464 rub
    old "We'll see who they believe more..."
    new "Wir werden sehen, wem sie mehr glauben..."

    # say L3465 pla
    old "Jeez, I'm leaving then."
    new "Mann, ich geh dann."

    # say L3471 rub
    old "Hpmh finally that stalker left."
    new "Hmpf, endlich ist dieser Stalker weg."

    # say L3472 rub
    old "How are you? Are you alright?"
    new "Wie geht's dir? Alles okay?"

    # say L3474 oli
    old "H- hi, I'm doing well, and you?"
    new "H-hi, mir geht's gut, und dir?"

    # say L3476 rub
    old "Well, I'm alright, you know. There's nothing much going on in my life."
    new "Na ja, mir geht's gut, weißt du. In meinem Leben passiert nicht viel."

    # say L3477 rub
    old "Unlike you..."
    new "Im Gegensatz zu dir..."

    # say L3479 rub
    old "I can't believe you didn't tell me about this before."
    new "Ich kann nicht glauben, dass du mir das vorher nicht gesagt hast."

    # say L3481 rub
    old "I'm only finding out because of your belly."
    new "Ich erfahre es erst, weil du schwanger bist."

    # say L3482 rub
    old "Why didn't you let me know before?"
    new "Warum hast du mir das nicht früher gesagt?"

    # say L3484 oli
    old "W- well, the truth is that even though I found out early, I wasn't really sure about who to tell."
    new "W- also, die Wahrheit ist, dass ich zwar früh davon erfahren habe, aber mir nicht sicher war, wem ich es sagen soll."

    # say L3485 rub
    old "Why not? Is everything alright?"
    new "Warum nicht? Ist alles in Ordnung?"

    # say L3486 oli
    old "Uhmm, I guess it is."
    new "Hmm, ich denke schon."

    # say L3487 oli
    old "I've just been dealing with my parents. You know how they are."
    new "Ich hab mich gerade mit meinen Eltern rumgeschlagen. Du weißt schon, wie die sind."

    # say L3489 rub
    old "Hmph, yeah, I have an idea."
    new "Hmpf, ja, ich hab da so eine Ahnung."

    # say L3491 rub
    old "And what does the father say? Is he helping you?"
    new "Und was sagt der Vater? Hilft er dir?"

    # say L3493 oli
    old "Hmm, w- well... W- we're actually not in contact."
    new "Hmm, w- wir sind eigentlich nicht in Kontakt."

    # say L3495 rub
    old "What? Is that scumbag not planning on answering for what he did?"
    new "Was? Macht dieser Mistkerl etwa nicht vor, was er getan hat?"

    # say L3496 rub
    old "Tell me who he is! I'll make him answer!"
    new "Sag mir, wer er ist! Ich werde ihn dazu bringen, sich zu verantworten!"

    # say L3497 oli
    old "N- no, it's nothing like what you're imagining."
    new "N-nein, es ist nicht so, wie du denkst."

    # say L3498 oli
    old "Is not that he doesn't want to answer for it, is just that..."
    new "Es ist nicht so, dass er nicht antworten will, es ist nur..."

    # say L3499 oli
    old "I don't know who he is."
    new "Ich weiß nicht, wer er ist."

    # say L3500 rub
    old "How come?"
    new "Wie kommt das?"

    # say L3501 oli
    old "Well, it happened at this party."
    new "Na ja, es ist bei dieser Party passiert."

    # say L3502 oli
    old "I didn't measure my drinks and got drunk."
    new "Ich hab meine Drinks nicht gemessen und bin betrunken geworden."

    # say L3503 oli
    old "And there was this very tall guy that I thought was cute."
    new "Und da war dieser sehr große Typ, den ich süß fand."

    # say L3505 oli
    old "I decided to approach him and we ended up spending the night together."
    new "Ich hab mich entschieden, ihn anzusprechen, und wir haben die Nacht zusammen verbracht."

    # say L3507 oli
    old "But I never asked him his name or where he goes to school or anything."
    new "Aber ich hab ihn nie nach seinem Namen oder seiner Schule gefragt oder so."

    # say L3509 oli
    old "To be honest, I barely remember his face."
    new "Ehrlich gesagt, ich erinnere mich kaum an sein Gesicht."

    # say L3511 oli
    old "So you see, there's not much use in worrying about the father."
    new "Dann siehst du, es hat keinen Sinn, sich über den Vater Gedanken zu machen."

    # say L3513 rub
    old "Hmph, I guess you're right."
    new "Hmpf, ich schätze, du hast recht."

    # say L3516 rub
    old "But it doesn't matter, you don't need that deadbeat to answer for anything."
    new "Aber das ist egal, du brauchst diesen Versager nicht, um für irgendwas zu antworten."

    # say L3518 rub
    old "You have your family and you have me, that's all you need."
    new "Du hast deine Familie und du hast mich, das ist alles, was du brauchst."

    # say L3519 oli
    old "Thanks Ruby, I know I can always count on you."
    new "Danke Ruby, ich weiß, dass ich mich immer auf dich verlassen kann."

    # say L3521 oli
    old "But to be honest, I don't know yet if I'll be keeping it you know?"
    new "Aber ehrlich gesagt, ich weiß noch nicht, ob ich es wirklich durchziehe, verstehst du?"

    # say L3522 oli
    old "Having a baby is a lot of work, so I'm still figuring out if I'll actually be a mother."
    new "Ein Baby ist eine Menge Arbeit, also überlege ich noch, ob ich wirklich Mutter werde."

    # say L3524 rub
    old "I see, I understand... That makes a lot of sense."
    new "Ich verstehe, das ergibt Sinn."

    # say L3525 rub
    old "And if you decide not to have it, what are you going to do about it?"
    new "Und wenn du dich entscheidest, es nicht zu behalten, was willst du dann machen?"

    # say L3527 oli
    old "Well, I was thinking that I could just go to the same doctor your friend went to that other time."
    new "Na ja, ich dachte, ich könnte einfach zu demselben Arzt gehen, zu dem deine Freundin damals gegangen ist."

    # say L3528 oli
    old "They did a very good job the last time, didn't they?"
    new "Sie haben letztes Mal eine sehr gute Arbeit geleistet, oder?"

    # say L3529 oli
    old "I think I could go to them."
    new "Ich denke, ich könnte zu ihnen gehen."

    # say L3531 rub
    old "I see, I understand... Well, I agree."
    new "Ich verstehe, ich sehe es ein... Na gut, ich stimme zu."

    # say L3532 rub
    old "You know I'll help you no matter what, right?"
    new "Du weißt, dass ich dir helfen werde, egal was passiert, oder?"

    # say L3533 rub
    old "Whatever you choose to do, I'm here for you."
    new "Was auch immer du tust, ich bin für dich da."

    # say L3534 oli
    old "I know that thanks."
    new "Ich weiß, danke."

    # say L3535 rub
    old "Hey, what do you say we skip classes for today?"
    new "Hey, was meinst du, wenn wir heute schwänzen?"

    # say L3536 rub
    old "Come on, let's go to the mall and have some ice cream."
    new "Komm schon, lass uns ins Einkaufszentrum gehen und Eis essen."

    # say L3537 oli
    old "Haha, alright let's do it."
    new "Haha, okay, machen wir."

    # say L3557 mik
    old "Dude! I'm so angry!"
    new "Kumpel! Ich bin so sauer!"

    # say L3558 pla
    old "H- huh? W- what's up?"
    new "H- huh? W- was ist los?"

    # say L3560 mik
    old "{i}'What's up?'{/i} Are you serious?"
    new "{i}'Was ist los?'{/i} Ernsthaft?"

    # say L3561 mik
    old "Olivia's pregnant man!"
    new "Olivia ist schwanger Mann!"

    # say L3562 pla
    old "Y- yeah, s- she is, so?"
    new "Y- ja, s- sie ist, und?"

    # say L3563 mik
    old "So? Don't you see what's wrong with that?"
    new "Was denn? Siehst du das Problem nicht?"

    # say L3565 mik
    old "I can't believe this treason!"
    new "Ich fass es nicht, dass sie das tut!"

    # say L3566 pla
    old "H- hey man, c- calm down..."
    new "H- hallo Mann, b- beruhige dich..."

    # say L3568 mik
    old "What do you mean calm down? Would you be able to if you were in my shoes?"
    new "Was meinst du damit, ruhig bleiben? Könntest du das, wenn du in meiner Situation wärst?"

    # say L3569 pla
    old "I know man, this doesn't look good."
    new "Ich weiß, Mann, das sieht nicht gut aus."

    # say L3570 pla
    old "B- but I can explain, I swear."
    new "Aber ich kann das erklären, ehrlich."

    # say L3572 mik
    old "Explain? You know who the guy is?"
    new "Erklären? Du weißt, wer der Typ ist?"

    # say L3573 pla
    old "Uhmm... What?"
    new "Ähm... Was?"

    # say L3575 mik
    old "Yeah, do you know who the guy that got Olivia pregnant is?"
    new "Klar, weißt du, wer der Typ ist, der Olivia schwanger gemacht hat?"

    # say L3577 pla
    old "Oh! S- so you don't know who the father is."
    new "Oh! D- dann weißt du also nicht, wer der Vater ist."

    # say L3579 mik
    old "Of course I don't, there are some rumors that it might be some jock in the football team."
    new "Natürlich nicht, es gibt Gerüchte, dass es vielleicht ein Footballspieler ist."

    # say L3581 mik
    old "But nobody knows."
    new "Aber niemand weiß."

    # say L3583 mik
    old "But since you say you can explain, I imagine you know who it is, don't you?"
    new "Aber da du sagst, dass du es erklären kannst, denke ich, dass du weißt, wer es ist, oder?"

    # say L3584 pla
    old "Uh... N- no, I- I don't know who the guy is."
    new "Äh... N-nein, ich- ich weiß nicht, wer der Typ ist."

    # say L3585 mik
    old "Then what did you mean by that?"
    new "Dann was hast du damit gemeint?"

    # say L3587 pla
    old "Uhmm... I just thought you were going to get into an argument with Olivia or something."
    new "Ähm... Ich dachte einfach, du würdest mit Olivia streiten oder so."

    # say L3588 pla
    old "And I figured I had to stop you."
    new "Und ich dachte, ich muss dich davon abhalten."

    # say L3590 mik
    old "What? Because she's pregnant?"
    new "Was? Weil sie schwanger ist?"

    # say L3591 mik
    old "No man, not at all."
    new "Nein Mann, überhaupt nicht."

    # say L3593 mik
    old "I'm hurt by her betrayal that's for certain!"
    new "Ich bin verletzt von ihrem Verrat, das steht fest!"

    # say L3595 mik
    old "But there's no way that I would ever be angry or fight with my beloved Olivia."
    new "Aber ich würde niemals wütend oder mit meiner geliebten Olivia streiten."

    # say L3597 mik
    old "I love her too much for it."
    new "Ich liebe sie zu sehr dafür."

    # say L3598 pla
    old "Is that so?"
    new "Ist das so?"

    # say L3599 mik
    old "Of course, it doesn't matter what she did to me."
    new "Natürlich, das spielt keine Rolle, was sie mir angetan hat."

    # say L3601 mik
    old "But that son of a bitch that got her pregnant, he's a different story."
    new "Aber dieser Arsch, der sie geschwängert hat, das ist eine andere Geschichte."

    # say L3603 mik
    old "When I catch the guy I swear to god that I'll make him pay for getting with my woman!"
    new "Wenn ich den Kerl kriege, schwöre ich bei Gott, dass ich ihn dafür bezahlen lasse, dass er mit meiner Frau geschlafen hat!"

    # say L3604 mik
    old "And with how close I was to scoring with her."
    new "Und dabei war ich schon so nah dran, es mit ihr zu treiben."

    # say L3606 pla
    old "Yeah, I understand buddy."
    new "Klar, ich verstehe, Kumpel."

    # say L3607 pla
    old "Must be rough."
    new "Das muss hart für dich sein."

    # say L3609 mik
    old "It's alright dude, nothing I can do about it."
    new "Alles gut, Alter, da kann ich nichts dran ändern."

    # say L3610 mik
    old "But anyway this doesn't mean that I won't be there for her anyway."
    new "Aber egal, das bedeutet nicht, dass ich nicht für sie da sein werde."

    # say L3613 mik
    old "Think about it dude, if no one knows who the father is it means he's a bum or a deadbeat."
    new "Überleg mal, wenn niemand weiß, wer der Vater ist, bedeutet das, dass er ein Versager oder ein Schlappschwanz ist."

    # say L3614 mik
    old "Which means my poor Olivia is having to go at this by herself."
    new "Das bedeutet, meine arme Olivia muss das alles alleine durchstehen."

    # say L3616 mik
    old "But she won't have to worry about anything man!"
    new "Aber sie muss sich um nichts Sorgen machen, Mann!"

    # say L3618 mik
    old "I'll step up! I'll answer for everything the kid needs."
    new "Ich werde mich einbringen! Ich werde für alles sorgen, was das Kind braucht."

    # say L3620 mik
    old "I'll even give him my last name so that they'll know I'm their father."
    new "Ich geb ihm sogar meinen Nachnamen, damit alle wissen, dass ich sein Vater bin."

    # say L3621 pla
    old "Oh, I mean, that's great man."
    new "Oh, das ist toll, Mann."

    # say L3623 pla
    old "But what does Olivia think about your noble intentions? Have you talked to her?"
    new "Aber was denkt Olivia über deine edlen Absichten? Hast du mit ihr gesprochen?"

    # say L3624 mik
    old "Hmm, no, not really. I haven't been able to talk to her."
    new "Hmm, nein, wirklich nicht. Ich habe noch nicht mit ihr gesprochen."

    # say L3625 mik
    old "But I will, don't doubt dude!"
    new "Aber ich werd's, zweifel nicht, Kumpel!"

    # say L3627 pla
    old "I'm sure you will bro, I'm sure you will."
    new "Ich bin sicher, dass du das wirst, Kumpel, ich bin sicher, dass du das wirst."

    # say L3637 pla
    old "Sorry ma'am."
    new "Entschuldigung, Ma'am."

    # say L3645 luc
    old "This will also be at the end of term exam, so be sure to take good notes."
    new "Das wird auch in der Abschlussprüfung dran kommen, also macht euch gute Notizen."

    # say L3656 luc
    old "Remember to practice the subject at home, the exam is very close, so don't relax too much and forget to study."
    new "Denk dran, das Thema zu Hause zu üben. Die Prüfung steht kurz bevor, also lass dich nicht zu sehr ablenken und vergiss nicht zu lernen."

    # say L3657 luc
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term exams."
    new "Ich weiß, das klingt wie viel Arbeit, aber du musst das machen, wenn du vor den Abschlussprüfungen alles richtig lernen willst."

    # say L3667 pla
    old "Hmph, that was a surprise."
    new "Hmpf, das war eine Überraschung."

    # say L3668 pla
    old "I thought Mike had figured out it was me who got Olivia pregnant."
    new "Ich dachte, Mike hat schon rausgefunden, dass ich der Vater von Olivias Baby bin."

    # say L3669 pla
    old "Thinking about it, now I have two things to keep hidden from him."
    new "Wenn ich drüber nachdenke, hab ich jetzt zwei Dinge, die ich vor ihm verstecken muss."

    # say L3670 pla
    old "Ugh, this is so awkward."
    new "Ugh, das ist so peinlich."

    # say L3684 oli
    old "Hey [pla], did you come to study again?"
    new "Hey [pla], bist du wieder zum Lernen gekommen?"

    # say L3686 pla
    old "Yeah, we've been advancing well lately, I figured we could have another study session."
    new "Klar, wir machen Fortschritte, dachte ich, wir könnten noch mal lernen."

    # say L3687 oli
    old "Hmm, that's a good idea."
    new "Hmm, das ist eine gute Idee."

    # say L3688 oli
    old "But... To be honest I'm not sure I'm up to it right now."
    new "Aber... Ehrlich gesagt bin ich mir nicht sicher, ob ich dazu im Moment in der Lage bin."

    # say L3689 pla
    old "Are you feeling bad again because of the pregnancy?"
    new "Spürst du dich wieder schlecht wegen der Schwangerschaft?"

    # say L3690 oli
    old "No, it's not that."
    new "Nein, es ist nicht das."

    # say L3691 oli
    old "Or rather, I think it is..."
    new "Oder vielmehr, ich denke schon..."

    # say L3692 oli
    old "I just don't think I can study right now [pla]."
    new "Ich glaube einfach nicht, dass ich jetzt lernen kann [pla]."

    # say L3694 pla
    old "I see, I understand."
    new "Ich verstehe, ich sehe es."

    # say L3695 pla
    old "Is there anything I can do to help you?"
    new "Gibt es was, bei dem ich dir helfen kann?"

    # say L3696 pla
    old "Could I get you something for the discomfort you're feeling?"
    new "Kann ich dir was holen, damit du dich besser fühlst?"

    # say L3699 oli
    old "I mean, I'm not in pain or anything like that."
    new "Ich meine, ich habe keinen Schmerz oder so."

    # say L3701 pla
    old "I'm asking you in case there's anything I could do to help."
    new "Ich frage dich, ob ich irgendwas tun kann, um dir zu helfen."

    # say L3703 oli
    old "I don't know [pla]..."
    new "Ich weiß nicht [pla]..."

    # say L3704 oli
    old "It's just a little embarrassing, you know?"
    new "Es ist nur ein bisschen peinlich, weißt du?"

    # say L3705 pla
    old "Is it? Why? What's happening?"
    new "Ist es? Warum? Was ist los?"

    # say L3710 oli
    old "{b}*Sigh*{/b} I guess there's no harm in telling you."
    new "{b}*Seufz*{/b} Ich schätze, es schadet nichts, es dir zu sagen."

    # say L3711 oli
    old "You know, ever since I got pregnant I've been feeling this kind of..."
    new "Du weißt schon, seit ich schwanger bin, habe ich dieses Gefühl von..."

    # say L3712 oli
    old "Tiredness? Fatigue?"
    new "Müdigkeit? Erschöpfung?"

    # say L3713 oli
    old "It's hard to explain, but since the pregnancy started that's how I've been feeling."
    new "Es ist schwer zu beschreiben, aber seit der Schwangerschaft fühle ich mich so."

    # say L3716 pla
    old "{i}(I wonder if it's because her body needs more magic.){/i}"
    new "{i}(Ich frage mich, ob es daran liegt, dass ihr Körper mehr Magie braucht.){/i}"

    # say L3717 oli
    old "I went to the doctor and asked if that's a normal thing to happen."
    new "Ich bin zum Arzt gegangen und habe gefragt, ob das normal ist."

    # say L3718 oli
    old "They said that it's uncommon, but I might be experiencing some sort of chronic fatigue because of the pregnancy."
    new "Sie sagten, dass es ungewöhnlich ist, aber ich könnte aufgrund der Schwangerschaft eine Art chronische Erschöpfung haben."

    # say L3719 oli
    old "But they ran several tests and concluded that I'm in good health."
    new "Aber sie haben mehrere Tests gemacht und festgestellt, dass ich gesund bin."

    # say L3721 pla
    old "Alright, and is it that fatigue the reason why you don't feel like studying?"
    new "Okay, und ist diese Müdigkeit der Grund, warum du keine Lust zum Lernen hast?"

    # say L3723 oli
    old "Not really..."
    new "Nicht wirklich..."

    # say L3724 oli
    old "I think it's related, but it's so hard to explain..."
    new "Ich denke, es hat damit zu tun, aber es ist so schwer zu erklären..."

    # say L3725 pla
    old "I think you can explain it to me. No problem."
    new "Ich denke, du kannst es mir erklären. Kein Problem."

    # say L3726 oli
    old "Hmm, you think so?"
    new "Hmm, du denkst das?"

    # say L3727 oli
    old "Ok, well..."
    new "Okay, also..."

    # say L3728 oli
    old "The thing that has me feeling bad is this weird..."
    new "Das, was mich beschäftigt, ist dieses komische..."

    # say L3730 oli
    old "H- horniness that I've been feeling ever since I got pregnant."
    new "H- Horniness, die ich seit der Schwangerschaft verspüre."

    # say L3731 pla
    old "O- oh! I- I see..."
    new "O- oh! I- Ich verstehe..."

    # say L3733 oli
    old "Y- yeah... And it's a very weird type of being horny."
    new "Y- ja... Und es ist eine sehr seltsame Art von Geilheit."

    # say L3734 oli
    old "At first I thought it was just because of the hormones."
    new "Am Anfang dachte ich, es wäre nur wegen der Hormone."

    # say L3735 oli
    old "But as that fatigue that I told you about has kept growing, so has this weird feeling of horniness."
    new "Aber je mehr diese Erschöpfung, von der ich dir erzählt habe, zunimmt, desto stärker wird auch dieses komische Gefühl der Geilheit."

    # say L3736 oli
    old "And lately sex is the only thing that I've been able to think about, you know?"
    new "Und lately ist Sex das Einzige, woran ich denken kann, weißt du?"

    # say L3737 pla
    old "I think I understand."
    new "Ich denke, ich verstehe."

    # say L3738 pla
    old "But if that's the case, why didn't you tell me about it before?"
    new "Aber wenn das so ist, warum hast du mir das vorher nicht gesagt?"

    # say L3739 pla
    old "I mean... It's not as if we don't know each other."
    new "Ich meine... Es ist ja nicht so, als würden wir uns nicht kennen."

    # say L3740 pla
    old "I could've helped you with it."
    new "Ich hätte dir dabei helfen können."

    # say L3742 oli
    old "I don't know [pla], you've already done so much for me."
    new "Ich weiß [pla], du hast schon so viel für mich getan."

    # say L3744 oli
    old "And it's not as if we're a couple, this whole pregnancy thing is just you helping me with a problem that I have."
    new "Und es ist ja nicht so, als wären wir ein Paar, das Ganze ist einfach, dass du mir bei meinem Problem hilfst."

    # say L3746 oli
    old "I wouldn't even know how to bring up the subject."
    new "Ich wüsste gar nicht, wie ich das ansprechen soll."

    # say L3747 pla
    old "Hey, I get that, but come on, if it's something that you need, I'll be more than happy to help you."
    new "Hey, ich verstehe das, aber komm schon, wenn es etwas ist, was du brauchst, bin ich mehr als bereit, dir zu helfen."

    # say L3748 pla
    old "So... i- if you think you could use my help, maybe I can do something for you."
    new "Also... i- wenn du denkst, dass du meine Hilfe brauchst, vielleicht kann ich ja was für dich tun."

    # say L3759 oli
    old "Ngnh! Oh god! This is amazing!"
    new "Ngnh! Oh Gott! Das ist unglaublich!"

    # say L3760 oli
    old "This big dick is just so great!"
    new "Diese große Schwanz ist einfach unglaublich!"

    # say L3761 oli
    old "Oh [pla]! I can't believe how good it feels!"
    new "Oh [pla]! Ich kann nicht glauben, wie gut sich das anfühlt!"

    # say L3770 oli
    old "Oh God [pla]! That feels so much better!"
    new "Oh Gott [pla]! Das fühlt sich so viel besser an!"

    # say L3771 oli
    old "I don't know why, but it's as if that tiredness had just left my body all of a sudden."
    new "Ich weiß nicht warum, aber es ist, als wäre plötzlich alle Müdigkeit aus meinem Körper gewichen."

    # say L3772 oli
    old "If I had known before that it was going to be that way, I would've told you about this sooner."
    new "Wenn ich das vorher gewusst hätte, hätte ich dir das viel früher gesagt."

    # say L3773 pla
    old "I'm very happy that you feel better."
    new "Ich bin sehr froh, dass es dir besser geht."

    # say L3774 pla
    old "That was the whole point, it's good that this worked."
    new "Das war ja der ganze Sinn, gut dass es funktioniert hat."

    # say L3776 oli
    old "You're the best, [pla]. Thank you so much."
    new "Du bist der Beste, [pla]. Danke schön."

    # say L3777 oli
    old "I don't think we'll be able to get to study right now."
    new "Ich glaube, wir kriegen das Studieren gerade nicht hin."

    # say L3778 oli
    old "But I think we can do it later."
    new "Aber ich denke, wir können es später machen."

    # say L3779 oli
    old "For now, thank you so much for the help [pla]."
    new "Danke dir so viel für die Hilfe [pla]."

    # say L3781 pla
    old "My pleasure, after all, we're in this together."
    new "Mein Vergnügen, schließlich sind wir drin zusammen."

    # say L3782 pla
    old "I guess I'll get going to my house and I'll see you later, alright?"
    new "Dann geh ich mal zu mir und sehe dich später, okay?"

    # say L3812 pla
    old "Oh! Hey Olivia, how are you?"
    new "Oh! Hey Olivia, wie geht's dir?"

    # say L3814 oli
    old "Hey [pla], well you know..."
    new "Hey [pla], na ja, du weißt schon..."

    # say L3816 pla
    old "What? Did something happen?"
    new "Was? Ist was passiert?"

    # say L3818 oli
    old "I mean, my family's still a little annoying."
    new "Ich meine, meine Familie ist immer noch ein bisschen nervig."

    # say L3820 oli
    old "It's been a little hard, you know, all this with my dad and mom..."
    new "Es ist ein bisschen schwer, weißt du, mit meinem Dad und meiner Mom..."

    # say L3821 oli
    old "And with my body getting fatter and fatter..."
    new "Und mit meinem Körper, der immer dicker wird..."

    # say L3823 pla
    old "You know... This makes me feel kinda guilty."
    new "Du weißt... Das macht mich irgendwie schuldig fühlen."

    # say L3825 pla
    old "Well... I mean, it is kinda my fault that you're in this situation."
    new "Na ja... ich meine, es ist irgendwie meine Schuld, dass du in dieser Situation bist."

    # say L3827 pla
    old "And I don't only mean the pregnancy."
    new "Und ich meine nicht nur die Schwangerschaft."

    # say L3829 pla
    old "But also what's happening with your family."
    new "Aber auch, was mit deiner Familie passiert."

    # say L3830 pla
    old "I can't avoid thinking that this is my responsibility."
    new "Ich kann nicht aufhören, daran zu denken, dass das meine Verantwortung ist."

    # say L3832 oli
    old "I understand why you would feel that way."
    new "Ich verstehe, warum du so denkst."

    # say L3833 oli
    old "I get what you're saying [pla]."
    new "Ich verstehe, was du meinst [pla]."

    # say L3835 oli
    old "But I don't think you should feel any guilt for it."
    new "Aber ich denke, du solltest dich deswegen nicht schuldig fühlen."

    # say L3837 oli
    old "After all, I was the one that came up with this idea."
    new "Schließlich war ich es, die diese Idee hatte."

    # say L3839 oli
    old "Not to mention I'm the one who dragged you into this whole situation."
    new "Nicht zu vergessen, dass ich dich in diese ganze Situation hineingezogen habe."

    # say L3840 pla
    old "Well, yeah, but still, you're the one bearing all the weight of this whole thing."
    new "Na ja, aber trotzdem trägst du das ganze Gewicht dieser Sache."

    # say L3841 pla
    old "Both figuratively and literally."
    new "Sowohl im übertragenen als auch im wörtlichen Sinne."

    # say L3843 oli
    old "Yeah, but is something that was needed."
    new "Ja, aber es war etwas, das nötig war."

    # say L3844 oli
    old "So don't beat yourself up too much for putting me in this state."
    new "Also mach dir nicht zu viele Vorwürfe, dass du mich in diesen Zustand gebracht hast."

    # say L3846 oli
    old "Besides, it's not as if we didn't both enjoy it, right?"
    new "Außerdem, es ist ja nicht so, als hätten wir beide es nicht genossen, oder?"

    # say L3847 pla
    old "Well, yeah, we did."
    new "Na klar, das haben wir."

    # say L3848 oli
    old "There you go. So don't beat yourself up over it. There's no problem."
    new "Da hast du es. Also mach dir keinen Kopf deswegen. Da ist kein Problem."

    # say L3849 pla
    old "I guess so."
    new "Ich denke schon."

    # say L3850 pla
    old "But still, I'd like it if you could feel a little bit more comfortable."
    new "Aber trotzdem würde ich mich freuen, wenn du dich ein bisschen wohler fühlen könntest."

    # say L3852 oli
    old "Oh, I think there's something that you could do to help me with that."
    new "Oh, ich denke, da gibt es etwas, das du tun könntest, um mir zu helfen."

    # say L3854 oli
    old "Come on, don't think too much about me being uncomfortable."
    new "Komm schon, denk nicht so viel darüber nach, dass ich unwohl bin."

    # say L3857 oli
    old "Now, let's go to my house."
    new "Jetzt, lass uns zu mir nach Hause gehen."

    # say L3858 oli
    old "The entrance exams are coming, so I want to study a little more."
    new "Die Aufnahmeprüfungen kommen, da will ich noch ein bisschen lernen."

    # say L3876 mik
    old "W- w- what was that?! W- what did I just hear?!"
    new "W- w- was war das?! W- was hab ich da gerade gehört?!"

    # say L3877 mik
    old "[pla]?! H- he got my girl pregnant?!"
    new "[pla]?! H- hat er meine Freundin schwanger gemacht?!"

    # say L3878 mik
    old "N- no way! I- it can't be..."
    new "N- nein! D- das kann nicht sein..."

    # say L3879 mik
    old "No! H- he wouldn't do that!"
    new "Nein! H- er würde das nicht tun!"

    # say L3880 mik
    old "With my girl?! What the hell?!"
    new "Mit meiner Freundin?! Was soll das?!"

    # say L3898 pla
    old "Oh! Brixxida, hi."
    new "Oh! Brixxida, hallo."

    # say L3900 bri
    old "Hey, good morning."
    new "Hey, guten Morgen."

    # say L3901 pla
    old "What are you doing here in my room so early?"
    new "Was machst du hier in meinem Zimmer so früh?"

    # say L3902 bri
    old "Well, I was about to wake you up actually.."
    new "Na ja, ich wollte dich eigentlich wecken."

    # say L3903 pla
    old "Oh! How come?"
    new "Oh! Warum denn?"

    # say L3905 bri
    old "Well, how long has it been since you implanted the magic in that girl?"
    new "Na, wie lange ist es her, seit du das Mädchen mit Magie belegt hast?"

    # say L3906 bri
    old "And you haven't given me any update on how things are going with her."
    new "Und du hast mir keine Updates gegeben, wie es mit ihr läuft."

    # say L3907 pla
    old "Uh, well, there haven't been any new updates."
    new "Na ja, es gab keine neuen Updates."

    # say L3908 pla
    old "The only thing that's happened is what you told me."
    new "Das Einzige, was passiert ist, ist das, was ich dir schon erzählt habe."

    # say L3909 pla
    old "She's been feeling a little tired, so she asked me to have sex with her."
    new "Sie war ein bisschen müde, also hat sie mich gebeten, mit ihr zu schlafen."

    # say L3910 bri
    old "And that's it? How's her pregnancy going?"
    new "Und das ist alles? Wie geht es bei der Schwangerschaft voran?"

    # say L3911 pla
    old "How's it going?"
    new "Wie läuft's?"

    # say L3912 pla
    old "Uhmm, it's very advanced, I would say."
    new "Hmm, es ist sehr weit fortgeschritten, würde ich sagen."

    # say L3913 pla
    old "Just as you told me, her belly grew so quickly."
    new "Genau wie du mir gesagt hast, ihr Bauch ist so schnell gewachsen."

    # say L3914 pla
    old "You would think she's going to give birth any time now."
    new "Du würdest denken, sie würde jeden Moment entbinden."

    # say L3916 bri
    old "That's exactly what I mean you dimwit!!"
    new "Das meine ich doch genau, du Idiot!!"

    # say L3917 pla
    old "W- why are you angry?"
    new "W-wieso bist du sauer?"

    # say L3919 bri
    old "Why do you think?"
    new "Warum denkst du?"

    # say L3920 bri
    old "I told you [pla]! This isn't a normal human pregnancy!"
    new "Ich hab's dir doch gesagt [pla]! Das ist keine normale menschliche Schwangerschaft!"

    # say L3922 bri
    old "Any moment now she could give birth! And we haven't made the closing ritual for the spell!"
    new "Jeden Moment könnte sie entbinden! Und wir haben den Abschlussritual für den Zauber noch nicht durchgeführt!"

    # say L3923 pla
    old "What are you talking about? Closing ritual?"
    new "Wovon redest du? Abschlussritual?"

    # say L3924 bri
    old "Yes [pla]! A closing ritual."
    new "Ja [pla]! Ein Abschlussritual."

    # say L3926 bri
    old "In the same way that I had to be there for the implantation of the magic."
    new "Genau wie ich bei der Implantierung der Magie dabei sein musste."

    # say L3930 pla
    old "E- extraction? What are you talking about?"
    new "E-Entfernung? Wovon redest du?"

    # say L3931 pla
    old "You never told me about any kind of extraction!"
    new "Du hast mir nie von irgendeiner Extraktion erzählt!"

    # say L3933 pla
    old "Where was all of this with Barbie?"
    new "Wo war das alles bei Barbie?"

    # say L3934 bri
    old "Well, for your information, we were never even close to finishing anything with Barbie because you decided to interrupt the spell!"
    new "Na, für deinen Info, wir waren noch nie nahe dran, irgendetwas mit Barbie zu beenden, weil du beschlossen hast, den Zauber zu unterbrechen!"

    # say L3936 bri
    old "Besides, I decided to modify the spell after your stupid tantrum last time with Barbie."
    new "Außerdem habe ich mich entschieden, den Zauber nach deinem blöden Wutanfall letztes Mal mit Barbie zu modifizieren."

    # say L3939 pla
    old "Uh, o- ok? But I don't get it, why?"
    new "Uh, o- ok? Aber ich verstehe nicht, warum?"

    # say L3940 bri
    old "As I told you, after what happened last time with Barbie, I gave it a thought and decided the best thing to do was modify the spell."
    new "Wie ich dir schon sagte, nach dem, was letztes Mal mit Barbie passiert ist, habe ich es mir überlegt und beschlossen, dass das Beste wäre, den Zauber zu modifizieren."

    # say L3941 bri
    old "This is because last time we ended up losing a lot of magic power."
    new "Das ist, weil letztes Mal wir viel magische Energie verloren haben."

    # say L3943 bri
    old "You see, the way it should work is that the condensation spell is over at the same time that the pregnancy is."
    new "Du siehst, der Trick ist, dass der Verdichtungszauber zu dem Zeitpunkt endet, wenn auch die Schwangerschaft beendet ist."

    # say L3945 bri
    old "But I realized that this approach only works if we let things come to term naturally."
    new "Aber ich habe gemerkt, dass dieser Ansatz nur funktioniert, wenn wir die Schwangerschaft natürlich zu Ende gehen lassen."

    # say L3947 bri
    old "But if it's something like what happened with Barbie were to happen again."
    new "Aber wenn so was wie bei Barbie noch mal passiert."

    # say L3948 bri
    old "We would end up losing all of the already cultivated magic power."
    new "Dann würden wir all die bereits angebaute magische Energie verlieren."

    # say L3951 pla
    old "But how did you solve it then?"
    new "Aber wie hast du es dann gelöst?"

    # say L3953 bri
    old "I did it by making a change to the way the spell works."
    new "Ich hab es gemacht, indem ich die Art und Weise geändert habe, wie der Zauber funktioniert."

    # say L3955 bri
    old "Instead of letting it end by itself, we're directly extracting the magic power from the girl."
    new "Statt es einfach enden zu lassen, ziehen wir die magische Kraft direkt aus dem Mädchen."

    # say L3957 bri
    old "This way it affords me a lot more control over the magic, and the moment it's extracted."
    new "So habe ich viel mehr Kontrolle über die Magie und den Zeitpunkt der Extraktion."

    # say L3958 bri
    old "So, even if something similar to what happened last time with Barbie were to happen again."
    new "So, selbst wenn etwas Ähnliches wie beim letzten Mal mit Barbie passieren würde."

    # say L3960 bri
    old "We could simply cancel the cultivation process and we wouldn't lose anything."
    new "Dann könnten wir den Kultivationsprozess einfach abbrechen und würden nichts verlieren."

    # say L3962 pla
    old "That's awesome Brixxida! And it's very reassuring!"
    new "Das ist super Brixxida! Und es ist sehr beruhigend!"

    # say L3964 bri
    old "Yeah, it's very good."
    new "Ja, das ist sehr gut."

    # say L3966 bri
    old "But there's a condition to the spell in this new form: there HAS to be an extraction."
    new "Aber es gibt eine Bedingung für den Zauber in dieser neuen Form: Es muss unbedingt eine Entnahme stattfinden."

    # say L3968 bri
    old "There's no point if we don't do it and the pregnancy just ends without us doing the extraction! We will lose all the magic!!"
    new "Es hat keinen Sinn, wenn wir es nicht machen und die Schwangerschaft einfach so endet, ohne dass wir die Extraktion durchführen! Wir werden all die Magie verlieren!!"

    # say L3969 pla
    old "I- I'm sorry Brixxida, I didn't know."
    new "I- Ich bin sorry, Brixxida, ich wusste es nicht."

    # say L3970 bri
    old "Hmph, as long as you understand."
    new "Hmpf, solange du es verstehst."

    # say L3972 bri
    old "But then you have to remember, sooner rather than later, we need to extract the magic power from her."
    new "Dann musst du dir aber merken, dass wir ihre magische Kraft so bald wie möglich extrahieren müssen."

    # say L3973 bri
    old "Otherwise, she'll have a human with a magic supercharge."
    new "Sonst hat sie einen Menschen mit magischer Superladung."

    # say L3974 bri
    old "And honestly, I don't know what that means in the long term."
    new "Ehrlich gesagt, ich weiß nicht, was das langfristig bedeutet."

    # say L3979 bri
    old "By the way, [pla], there's something else you should know."
    new "Übrigens, [pla], da gibt es noch etwas, das du wissen solltest."

    # say L3981 bri
    old "Before we do the magic extraction, she has to decide if she wants to be a mother or not."
    new "Bevor wir die magische Extraktion durchführen, muss sie entscheiden, ob sie Mutter werden will oder nicht."

    # say L3984 bri
    old "This is because when we extract the magic power, I need to know if I'll take it all or just a small part."
    new "Das ist, weil ich bei der Magie-Extraktion wissen muss, ob ich alles oder nur einen kleinen Teil nehme."

    # say L3985 pla
    old "What happens either way?"
    new "Was passiert in beiden Fällen?"

    # say L3987 bri
    old "Well, if she decides not to go through with the whole process, I'll extract all the magic power from her."
    new "Na ja, wenn sie sich entscheidet, den ganzen Prozess nicht durchzuziehen, werde ich all ihre magische Energie entziehen."

    # say L3989 bri
    old "And her pregnancy will be reversed."
    new "Und ihre Schwangerschaft wird rückgängig gemacht."

    # say L3991 bri
    old "So in the end, it'll be like she was never pregnant."
    new "Dann wird es am Ende so sein, als wäre sie nie schwanger gewesen."

    # say L3993 bri
    old "On the other hand, if she decides to go through the whole process."
    new "Andererseits, wenn sie sich für den ganzen Prozess entscheidet."

    # say L3995 bri
    old "I'll take most of it, but I'll leave a small amount of power, so a life will be created."
    new "Ich werde den Großteil davon übernehmen, aber ich lasse eine kleine Menge Kraft, damit ein Leben entsteht."

    # say L3996 pla
    old "I see... So that's how it is."
    new "Ich verstehe... So ist das also."

    # say L3997 pla
    old "Alright, I'll be sure to talk to her about it."
    new "Okay, ich werde mit ihr darüber reden."

    # say L3999 bri
    old "Good, make sure you do that."
    new "Okay, mach das sicher."

    # say L4000 pla
    old "Yeah, I'll do it and let you know."
    new "Okay, mach ich und geb dir Bescheid."

    # say L4014 pla
    old "Alright! That's it!"
    new "Alles klar! Das war's!"

    # say L4015 pla
    old "I think that's all the subjects we needed to study for the entrance exam."
    new "Ich denke, das waren alle Fächer, die wir für den Aufnahmetest brauchten."

    # say L4017 pla
    old "I think with that, you should ace the exam!"
    new "Ich denke, damit schaffst du die Prüfung mit Bravour!"

    # say L4019 oli
    old "Oh my god! Thank you so much, [pla]!"
    new "Oh mein Gott! Danke dir soooooo viel, [pla]!"

    # say L4021 oli
    old "At first, I couldn't believe we would ever manage to cover everything."
    new "Am Anfang konnte ich nicht glauben, dass wir jemals alles schaffen würden."

    # say L4023 oli
    old "But we did it!"
    new "Aber wir haben es geschafft!"

    # say L4025 oli
    old "I can't believe it, this is the best thing ever, [pla]!"
    new "Ich kann es nicht fassen, das ist das Allerbeste, [pla]!"

    # say L4027 pla
    old "Yeah, for a moment there, I also thought we wouldn't have time to cover everything."
    new "Ja, für einen Moment dachte ich auch, wir schaffen es nicht, alles zu schaffen."

    # say L4028 pla
    old "But you've been so disciplined, Olivia. It's amazing how much effort you've put in such a short time."
    new "Aber du warst so diszipliniert, Olivia. Es ist unglaublich, wie viel Arbeit du in so kurzer Zeit reingesteckt hast."

    # say L4029 pla
    old "This is definitely all because of your hard work."
    new "Das ist definitiv alles wegen deiner harten Arbeit."

    # say L4031 oli
    old "Still, you've been an amazing teacher, [pla]."
    new "Trotzdem warst du ein unglaublicher Lehrer, [pla]."

    # say L4032 oli
    old "Thinking about it, we had a very rocky start."
    new "Wenn ich drüber nachdenke, hatten wir einen ziemlich holprigen Start."

    # say L4034 oli
    old "With me blackmailing you with what I saw you do at Mike's house."
    new "Mit mir, wie ich dich mit dem erpresst habe, was ich bei Mike gesehen habe."

    # say L4035 oli
    old "I'm sorry about that, by the way."
    new "Es tut mir leid dafür, übrigens."

    # say L4037 pla
    old "I mean, it's alright, given the situation you were in."
    new "Ich meine, es ist in Ordnung, bei der Situation, in der du warst."

    # say L4039 pla
    old "I'm not saying it's okay, but I understand you were in a desperate position."
    new "Ich sage ja nicht, dass es okay ist, aber ich verstehe, dass du in einer verzweifelten Situation warst."

    # say L4041 pla
    old "But it's alright."
    new "Aber es ist okay."

    # say L4045 oli
    old "Thank you for your understanding."
    new "Danke für dein Verständnis."

    # say L4047 oli
    old "And for being so helpful."
    new "Und dafür, dass du mir so geholfen hast."

    # say L4048 oli
    old "I came up with such a crazy idea, and you decided to help me with it."
    new "Ich habe so eine verrückte Idee gehabt, und du hast dich entschieden, mir dabei zu helfen."

    # say L4050 oli
    old "And on top of that, you even took time to explain all these topics to me."
    new "Und obendrauf hast du dir sogar die Zeit genommen, mir all diese Themen zu erklären."

    # say L4053 oli
    old "I don't know how to show my gratitude."
    new "Ich weiß gar nicht, wie ich dir danken soll."

    # say L4055 oli
    old "But I can think of a couple of ways."
    new "Aber ich kann mir ein paar Dinge vorstellen."

    # say L4056 oli
    old "You know, I've been feeling a little tired lately."
    new "Weißt du, ich fühle mich lately ein bisschen müde."

    # say L4057 pla
    old "Y- you are?"
    new "Y- du auch?"

    # say L4059 oli
    old "Yeah, I'm not feeling my best lately."
    new "Ja, ich fühle mich lately nicht besonders gut."

    # say L4060 oli
    old "I was thinking maybe you could help me a bit with that."
    new "Ich dachte, vielleicht könntest du mir dabei ein bisschen helfen."

    # say L4061 oli
    old "And at the same time, maybe I can show my thanks for everything you've done for me."
    new "Und gleichzeitig kann ich dir vielleicht für alles danken, was du für mich getan hast."

    # say L4063 pla
    old "Uh, y- yeah sure, I don't see why not."
    new "Klar, y- yeah, warum nicht."

    # say L4065 oli
    old "Great! Give me a second to go to the bathroom, and I'll be right back."
    new "Super! Gib mir einen Moment, ich muss kurz ins Bad, bin gleich wieder da."

    # say L4066 oli
    old "Don't worry, you won't have to wait long."
    new "Keine Sorge, du musst nicht lange warten."

    # say L4068 pla
    old "Oh right! By the way."
    new "Oh richtig! Übrigens."

    # say L4069 pla
    old "I wanted to ask you something."
    new "Ich wollte dich was fragen."

    # say L4070 pla
    old "Maybe this isn't what you expect right now."
    new "Vielleicht ist das jetzt nicht das, was du erwartet hast."

    # say L4072 pla
    old "But I was thinking we still haven't talked about your decision regarding your pregnancy."
    new "Aber ich dachte, wir haben noch nicht über deine Entscheidung bezüglich deiner Schwangerschaft gesprochen."

    # say L4074 pla
    old "D- don't get me wrong, I'm not trying to convince you of anything."
    new "D- das will ich nicht sagen, ich will dich zu nichts überreden."

    # say L4076 pla
    old "I just want to know where you stand on it, you know?"
    new "Ich will nur wissen, wo du drüber stehst, weißt du?"

    # say L4077 pla
    old "Just because I worry about you."
    new "Nur weil ich mir Sorgen um dich mache."

    # say L4079 oli
    old "Well... I have to say I originally thought about waiting for the entrance exam results."
    new "Na ja... ich muss sagen, ich habe ursprünglich darüber nachgedacht, bis zu den Aufnahmeprüfungen zu warten."

    # say L4080 oli
    old "You know, because I wanted to know if I got into college."
    new "Weißt du, weil ich wissen wollte, ob ich es aufs College geschafft habe."

    # say L4081 oli
    old "But I thought about it and understood what I want."
    new "Aber ich habe darüber nachgedacht und verstanden, was ich will."

    # menu L4084 
    old "Extract the whole magic power."
    new "Ich will die ganze magische Kraft entziehen."

    # say L4087 oli
    old "I've decided that I don't want to be a mother."
    new "Ich hab mich entschieden, dass ich keine Mutter werden will."

    # say L4089 oli
    old "I- it's just that it wasn't my original plan, you know?"
    new "Es war einfach nicht mein ursprünglicher Plan, weißt du?"

    # say L4091 oli
    old "When I got myself into this situation, it was only to get my parents off my back."
    new "Als ich mich in diese Situation gebracht habe, war es nur, um meine Eltern loszuwerden."

    # say L4093 oli
    old "But I have to say, I've never considered being a mother so young."
    new "Aber ich muss sagen, Mutter zu werden so jung habe ich mir noch nie vorgestellt."

    # say L4094 oli
    old "There are still so many things I want to do, and being a mother would get in the way of all that."
    new "Da sind noch so viele Dinge, die ich machen will, und Mutter zu sein würde da nur im Weg stehen."

    # say L4096 oli
    old "Besides, I would be dragging you into this situation too."
    new "Außerdem würde ich dich auch in diese Situation hineinziehen."

    # say L4098 oli
    old "You've done a lot for me, [pla], but I can't ask any more from you."
    new "Du hast schon so viel für mich getan, [pla], aber ich kann nicht noch mehr von dir verlangen."

    # say L4100 oli
    old "So I think it's better if I just leave things as they are."
    new "Dann denke ich, es ist besser, wenn ich die Dinge so belasse, wie sie sind."

    # say L4103 pla
    old "I'm happy you're thinking about your future."
    new "Ich freue mich, dass du über deine Zukunft nachdenkst."

    # say L4104 pla
    old "And hey, thanks for trusting me."
    new "Und danke, dass du mir vertraust."

    # say L4106 oli
    old "I'm glad you've been my partner through this whole process, [pla]. Thank you so much."
    new "Ich bin froh, dass du mein Partner in diesem ganzen Prozess warst, [pla]. Danke schön."

    # menu L4110 
    old "Extract most of the magic power but leave a small part."
    new "Den größten Teil der magischen Kraft entziehen, aber einen kleinen Teil lassen."

    # say L4112 oli
    old "Well, I don't know how to tell you this."
    new "Na ja, ich weiß nicht, wie ich dir das sagen soll."

    # say L4114 oli
    old "But I decided that I want to be a mother."
    new "Aber ich hab mich entschieden, dass ich Mutter werden will."

    # say L4116 oli
    old "I- I don't mean that I want to make you a father or anything, [pla]!"
    new "I- Ich meine damit nicht, dass ich dich Vater machen will oder so, [pla]!"

    # say L4118 oli
    old "It's just that I've been thinking, and I think I want to give it a go."
    new "Es ist nur so, dass ich darüber nachgedacht habe und ich glaube, ich will es versuchen."

    # say L4120 oli
    old "Ever since this happened, I've been feeling better and better about the possibility of being a mother."
    new "Seitdem ist mir immer wohler bei der Vorstellung, Mutter zu werden."

    # say L4121 pla
    old "And you decided that you want to do it?"
    new "Und du hast dich entschieden, es zu tun?"

    # say L4122 oli
    old "Well, yeah."
    new "Na ja, klar."

    # say L4124 oli
    old "I've been thinking about it and I think it's possible."
    new "Ich hab drüber nachgedacht und ich denke, es ist möglich."

    # say L4126 oli
    old "Lately, my father has come around to the idea of me being a mom."
    new "L lately, mein Vater hat sich damit abgefunden, dass ich Mutter werde."

    # say L4128 oli
    old "And my mom's pretty excited about it too."
    new "Und meine Mom ist auch ziemlich aufgeregt darüber."

    # say L4130 oli
    old "So I figured I could try it."
    new "Dann dachte ich, ich könnte es mal ausprobieren."

    # say L4132 oli
    old "B- but I'm not trying to make you a father!"
    new "Aber ich will dich nicht zum Vater machen!"

    # say L4134 oli
    old "I don't expect you to get involved or anything."
    new "Ich erwarte nicht, dass du dich einmischst oder so."

    # say L4135 oli
    old "It's just what I want to do, [pla]."
    new "Es ist einfach das, was ich tun will, [pla]."

    # say L4137 pla
    old "It's alright, I understand. And I would never try to convince you otherwise."
    new "Alles gut, ich verstehe. Und ich würde dich nie dazu überreden wollen."

    # say L4138 pla
    old "I just wanted to know what your plans were."
    new "Ich wollte nur wissen, was du vorhast."

    # say L4140 pla
    old "And I'm happy you're in a position where you can decide this."
    new "Und ich freue mich, dass du in der Position bist, das selbst zu entscheiden."

    # say L4141 pla
    old "I'll help you in any way you need me to."
    new "Ich helfe dir auf jede Art, die du brauchst."

    # say L4146 oli
    old "Thanks for all your support, [pla]!"
    new "Danke für deine Unterstützung, [pla]!"

    # say L4147 oli
    old "Listen, I have to go to the bathroom."
    new "Hör zu, ich muss auf die Toilette."

    # say L4148 oli
    old "But when I come back, I want to see you ready."
    new "Aber wenn ich zurückkomme, will ich dich bereit sehen."

    # say L4154 pla
    old "Ok, I should take this chance to bring Brixxida here!"
    new "Ok, ich sollte diese Gelegenheit nutzen, um Brixxida hier zu holen!"

    # say L4164 bri
    old "What do you need?"
    new "Was brauchst du?"

    # say L4165 bri
    old "That really surprised me."
    new "Das hat mich echt überrascht."

    # say L4166 pla
    old "Well, I think now's the perfect time for you to end the spell."
    new "Na, ich denke, jetzt ist der perfekte Zeitpunkt, um den Zauber zu beenden."

    # say L4167 bri
    old "That's just perfect. Well done calling me here, [pla]!"
    new "Das ist ja toll. Gut gemacht, dass du mich hierher gerufen hast, [pla]!"

    # say L4175 oli
    old "Alright, let's do this."
    new "Okay, lass uns das machen."

    # say L4178 oli
    old "Come on, I want you to fuck me right now."
    new "Komm schon, ich will, dass du mich jetzt fickst."

    # say L4179 pla
    old "S- sure, right away!"
    new "Klar, sofort!"

    # say L4189 oli
    old "Oh God yes! That's just what I've been missing, [pla]!"
    new "Oh Gott ja! Das ist genau das, was ich gebraucht habe, [pla]!"

    # say L4190 bri
    old "Oh yeah, [pla]! That's just what I wanted!"
    new "Oh ja, [pla]! Das ist genau das, was ich wollte!"

    # say L4191 oli
    old "This feels so amazing!"
    new "Das fühlt sich so unglaublich an!"

    # say L4201 oli
    old "That was sooo good, [pla]!"
    new "Das war soo gut, [pla]!"

    # say L4202 oli
    old "Just like always, that dick of yours never disappoints."
    new "Genau wie immer, dein Schwanz enttäuscht mich nie."

    # say L4203 pla
    old "I'm glad you liked it."
    new "Ich freue mich, dass es dir gefallen hat."

    # say L4206 oli
    old "Well, mostly, yeah."
    new "Na ja, meistens schon."

    # say L4207 oli
    old "But you know? I still feel a little bit tired."
    new "Aber weißt du? Ich fühle mich immer noch ein bisschen müde."

    # say L4208 oli
    old "And I feel like I haven't thanked you enough for everything."
    new "Und ich fühle mich, als hätte ich dir noch nicht genug für alles gedankt."

    # say L4209 oli
    old "So I have another thing for you. Come here."
    new "Aber ich hab noch was für dich. Komm her."

    # say L4218 oli
    old "Slrrp! Oh yeah!"
    new "Slrrp! Oh ja!"

    # say L4219 oli
    old "Hmm! I wanted to taste this dick again!"
    new "Hmm! Ich wollte diesen Schwanz wieder schmecken!"

    # say L4220 oli
    old "Just relax and enjoy it [pla]!"
    new "Entspann dich und genieße es [pla]!"

    # say L4232 oli
    old "Alright! I think that does it!"
    new "Okay! Ich denke, das reicht!"

    # say L4233 oli
    old "I hope you liked my way of saying thanks to you, [pla]!"
    new "Ich hoffe, dir hat mein Weg, mich zu bedanken, gefallen, [pla]!"

    # say L4235 pla
    old "Yeah, I think it was great!"
    new "Ja, ich denke, es war toll!"

    # say L4237 oli
    old "I'm glad. Thanks again for everything, [pla]."
    new "Ich bin froh. Danke nochmal für alles, [pla]."

    # say L4239 oli
    old "I'm sure I'm going to do great on those exams."
    new "Ich bin sicher, dass ich bei den Prüfungen super abschneiden werde."

    # say L4240 pla
    old "I'm completely sure of it."
    new "Ich bin mir absolut sicher."

    # say L4242 pla
    old "You've worked very hard to get a good result."
    new "Du hast hart gearbeitet, um ein gutes Ergebnis zu erzielen."

    # say L4243 pla
    old "There's no doubt that you'll ace it."
    new "Da bin ich mir sicher, dass du es schaffst."

    # say L4245 oli
    old "Thanks, [pla]. Your support means everything to me."
    new "Danke, [pla]. Deine Unterstützung bedeutet mir alles."

    # say L4247 pla
    old "Hey, I think I should be going home, right?"
    new "Hey, ich glaube, ich sollte jetzt nach Hause gehen, oder?"

    # say L4248 pla
    old "So you'll have time to rest properly."
    new "Dann hast du Zeit, dich richtig auszuruhen."

    # say L4250 oli
    old "Sure, thanks again, [pla]."
    new "Klar, danke nochmal, [pla]."

    # say L4252 pla
    old "You're welcome, Olivia."
    new "Gern geschehen, Olivia."

    # say L4264 pla
    old "Okay, I think that settles everything with the spell, right?"
    new "Okay, ich denke, das regelt die Sache mit dem Zauber, oder?"

    # say L4266 bri
    old "That's right. Now that we stopped the spell, she'll return to normal soon."
    new "Das stimmt. Jetzt, wo wir den Zauber gestoppt haben, wird sie bald wieder normal sein."

    # say L4267 bri
    old "And don't worry about her health; she'll be completely fine."
    new "Und mach dir keine Sorgen um ihre Gesundheit; sie wird komplett in Ordnung sein."

    # say L4268 bri
    old "So it should be all good."
    new "Dann sollte alles in Ordnung sein."

    # say L4272 bri
    old "Now, we can't extract the magic power from you yet."
    new "Jetzt können wir noch nicht die magische Kraft aus dir extrahieren."

    # say L4273 bri
    old "Because we need a little bit of time for the magic you extracted from her to settle within you."
    new "Weil wir ein bisschen Zeit brauchen, damit die Magie, die du von ihr gezogen hast, sich in dir einleben kann."

    # say L4292 pla
    old "Hmm? Hello?"
    new "Hmm? Hallo?"

    # say L4293 pla
    old "Yes, this is him speaking."
    new "Ja, hier spricht er."

    # say L4294 pla
    old "W- what?! N- now?!"
    new "W- was?! J- jetzt?!"

    # say L4295 pla
    old "I- I'll be there right away!"
    new "I- Ich bin sofort da!"

    # say L4300 pla
    old "I can't believe Olivia's already in the hospital!"
    new "Ich kann nicht glauben, dass Olivia schon im Krankenhaus ist!"

    # say L4301 pla
    old "I better hurry!"
    new "Ich muss mich beeilen!"

    # say L4314 pla
    old "I- I can't believe you're already here!"
    new "Ich- Ich kann nicht glauben, dass du schon hier bist!"

    # say L4316 oli
    old "Me too, but my obgyn decided that now was the best time."
    new "Mir auch, aber mein Frauenarzt hat entschieden, dass jetzt der beste Zeitpunkt ist."

    # say L4318 oli
    old "So you know, I guess it's fine."
    new "Dann ist es wohl okay."

    # say L4320 pla
    old "And how do you feel? Are you ready?"
    new "Und wie fühlst du dich? Bist du bereit?"

    # say L4322 oli
    old "I am, thank you, [pla]."
    new "Ich bin es, danke, [pla]."

    # say L4323 oli
    old "And hey, don't worry too much about me."
    new "Und hey, mach dir nicht zu viele Sorgen um mich."

    # say L4324 oli
    old "I'm sure of my decision."
    new "Ich bin mir sicher bei meiner Entscheidung."

    # say L4325 oli
    old "And my mom and sister are already here to help with everything, so don't worry, alright?"
    new "Und meine Mom und Schwester sind schon hier, um mir zu helfen, also mach dir keine Sorgen, okay?"

    # say L4327 pla
    old "Alright, sure."
    new "Okay, klar."

    # say L4334 vee
    old "Honey, the nurse says they have to move you into the operating room."
    new "Schatz, die Schwester sagt, sie müssen dich in den OP bringen."

    # say L4336 oli
    old "Sure, mom, no problem."
    new "Klar, Mama, kein Problem."

    # say L4337 oli
    old "Alright, [pla], wish me luck."
    new "Okay, [pla], viel Glück."

    # say L4338 pla
    old "Good luck, I know you've got this."
    new "Viel Glück, ich weiß, dass du das kannst."

    # say L4348 pla
    old "Alright, that was rather fast."
    new "Okay, das ging ja schnell."

    # say L4350 oli
    old "I'm doing okay."
    new "Mir geht's gut."

    # say L4352 oli
    old "Really, [pla], I'm completely fine with this."
    new "Wirklich, [pla], ich bin damit total in Ordnung."

    # say L4354 oli
    old "I was a little worried that my mom was going to be all annoying about it."
    new "Ich war ein bisschen besorgt, dass meine Mom total nervig werden würde."

    # say L4356 oli
    old "But she seems to be completely okay with all of this, so there's no problem really."
    new "Aber sie scheint damit total okay zu sein, also gibt es eigentlich kein Problem."

    # say L4358 pla
    old "That sounds alright."
    new "Das klingt gut."

    # say L4365 mar
    old "I'm sorry to bother you, sir, but it's time for the patient to rest."
    new "Entschuldigen Sie die Störung, aber es ist Zeit, dass die Patientin sich ausruht."

    # say L4367 pla
    old "Alright, I guess I'll see you later then."
    new "Okay, dann sehen wir uns später."

    # say L4369 oli
    old "Sure, and hey, [pla], thanks again."
    new "Klar, und hey, [pla], danke nochmal."

    # say L4371 oli
    old "This big shift in my life wouldn't have been possible without you."
    new "Dieser große Wandel in meinem Leben wäre ohne dich nicht möglich gewesen."

    # say L4373 oli
    old "I hope we'll continue being friends."
    new "Ich hoffe, wir bleiben Freunde."

    # say L4375 oli
    old "And hey, come see me whenever you want. We don't have to stop having fun after this."
    new "Und hey, komm mich besuchen, wann du willst. Wir müssen nachher nicht aufhören, Spaß zu haben."

    # say L4376 pla
    old "Sure, I'll do it."
    new "Klar, ich mach das."

    # say L4385 pla
    old "Hey, how do you feel?"
    new "Hey, wie fühlst du dich?"

    # say L4387 oli
    old "I'm doing alright, it was a lot easier than I expected, you know?"
    new "Mir geht's gut, es war viel einfacher als ich dachte, weißt du?"

    # say L4388 pla
    old "It was?"
    new "Wirklich?"

    # say L4390 oli
    old "Yeah, it was. The doctor really helped me."
    new "Ja, war es. Der Arzt hat mir echt geholfen."

    # say L4391 oli
    old "So I didn't feel a lot of pain."
    new "Dann habe ich nicht viel Schmerzen gehabt."

    # say L4392 pla
    old "That sounds great, Olivia. That's awesome."
    new "Das klingt super, Olivia. Das ist toll."

    # say L4399 mar
    old "Would the new parents like to meet their newborn son?"
    new "Möchten die neuen Eltern ihren neugeborenen Sohn kennenlernen?"

    # say L4402 oli
    old "But I think I'm a little too tired to hold him right now."
    new "Aber ich glaube, ich bin ein bisschen zu müde, um ihn jetzt zu halten."

    # say L4403 oli
    old "But why don't you do it, [pla]?"
    new "Aber warum machst du es nicht, [pla]?"

    # say L4419 oli
    old "How about you, [pla]?"
    new "Wie wär's mit dir, [pla]?"

    # say L4422 pla
    old "I'm actually alright, you know?"
    new "Ich bin eigentlich okay, weißt du?"

    # say L4424 pla
    old "I have to say, I never expected to be a father so soon."
    new "Ich muss sagen, ich habe nie damit gerechnet, so früh Vater zu werden."

    # say L4426 pla
    old "But I can't say that I feel bad about any of this."
    new "Aber ich kann nicht sagen, dass ich deswegen schlecht drauf bin."

    # say L4428 pla
    old "I never expected to have all these feelings within me."
    new "Ich hätte nie gedacht, dass ich all diese Gefühle in mir habe."

    # say L4430 pla
    old "But I think it's great, really."
    new "Aber ich finde es toll, ehrlich gesagt."

    # say L4432 oli
    old "I'm so glad you feel that way, [pla]."
    new "Ich bin so froh, dass du das so siehst, [pla]."

    # say L4433 oli
    old "And by the way, you don't need to worry about anything related to money, you know?"
    new "Und übrigens, du musst dir keine Sorgen um Geld machen, okay?"

    # say L4435 oli
    old "My dad said he's moving here to be closer to his grandson."
    new "Mein Dad hat gesagt, er zieht hierher, um näher bei seinem Enkel zu sein."

    # say L4437 oli
    old "So I don't think you'll need to worry about that."
    new "Dann musst du dir darüber also keine Sorgen machen."

    # say L4439 pla
    old "I see, well, that's good."
    new "Ich sehe, na ja, das ist gut."

    # say L4441 oli
    old "And by the way, we can still keep in touch."
    new "Und übrigens, wir können immer noch Kontakt halten."

    # say L4442 oli
    old "I'll be expecting some of your visits in the future."
    new "Ich freue mich schon auf deine Besuche in Zukunft."

    # say L4443 pla
    old "A- and I'll be sure to visit you."
    new "A- und ich werde sicherstellen, dass ich dich besuche."

    # say L4450 mar
    old "I'm sorry, sir, but the mother needs to rest."
    new "Entschuldigung, aber die Mutter muss sich ausruhen."

    # say L4451 mar
    old "And visiting hours are almost over."
    new "Und die Besuchszeit ist fast vorbei."

    # say L4453 pla
    old "No problem, I'll leave right now."
    new "Kein Problem, ich geh jetzt."

    # say L4456 oli
    old "Sure, and [pla], thanks again. For everything."
    new "Klar, und [pla], danke nochmal. Für alles."

    # say L4468 bri
    old "Alright, [pla]! You are just on time!"
    new "Alles klar, [pla]! Du kommst gerade richtig!"

    # say L4469 bri
    old "We have to unload the magic from the spell into the magic portal."
    new "Wir müssen die Magie aus dem Zauber in das magische Portal entladen."

    # say L4471 pla
    old "Oh right, okay, how do we do that?"
    new "Oh richtig, okay, wie machen wir das?"

    # say L4472 bri
    old "Oh, that's the best part. Come with me."
    new "Oh, das ist der beste Teil. Komm mit mir."

    # say L4478 bri
    old "Alright, here we are, I've prepared the portal to receive the magic power you collected from Olivia."
    new "Okay, hier sind wir, ich habe das Portal vorbereitet, um die magische Energie aufzunehmen, die du von Olivia gesammelt hast."

    # say L4479 bri
    old "Now, drop your pants."
    new "Jetzt zieh deine Hose aus."

    # say L4480 pla
    old "Oh! So that's how it's done..."
    new "Oh! So das ist der Trick..."

    # say L4481 bri
    old "Of course! Were you expecting anything else? Come on, let me help you."
    new "Natürlich! Hast du etwas anderes erwartet? Komm schon, lass mich dir helfen."

    # say L4490 bri
    old "That's it, [pla]!"
    new "Das ist es, [pla]!"

    # say L4491 bri
    old "Just relax and let me do the work."
    new "Lass dich einfach gehen und lass mich machen."

    # say L4492 bri
    old "You just need to focus on enjoying it."
    new "Du musst dich nur darauf konzentrieren, es zu genießen."

    # say L4501 bri
    old "Wonderful, [pla]!"
    new "Wunderbar, [pla]!"

    # say L4502 bri
    old "This is the best first experience we could've hoped for."
    new "Das ist die beste erste Erfahrung, die wir hätten hoffen können."

    # say L4503 bri
    old "But now, don't forget that we need to keep looking for other subjects."
    new "Aber jetzt, vergiss nicht, dass wir weiter nach anderen Versuchspersonen suchen müssen."

    # say L4504 pla
    old "Hmph, yeah sure."
    new "Hmpf, klar."

    # say L4520 vee
    old "Hi, [pla], how are you doing?"
    new "Hi, [pla], wie geht's dir?"

    # say L4522 pla
    old "Hi, Mrs. Priya. I'm doing alright, and you?"
    new "Hi, Mrs. Priya. Mir geht’s gut, und dir?"

    # say L4524 vee
    old "I'm alright, honey."
    new "Mir geht's gut, Schatz."

    # say L4525 vee
    old "A little busy, but that's normal."
    new "Ein bisschen beschäftigt, aber das ist normal."

    # say L4529 vee
    old "And tell me, what brings you here today, honey?"
    new "Und sag mir, was führt dich heute hierher, Schatz?"

    # say L4530 pla
    old "Well, not much. I was just passing by and wanted to say hello."
    new "Na, nicht viel. Ich war nur in der Gegend und wollte Hallo sagen."

    # say L4532 vee
    old "Oh dear, aren't you sweet."
    new "Oh Liebling, bist du süß."

    # say L4534 vee
    old "It's good to see you."
    new "Schön, dich zu sehen."

    # say L4535 vee
    old "Be sure to come back soon, dear."
    new "Ach, sei ein Schatz und komm bald wieder, ja?"

    # say L4537 vee
    old "With all the help you've given Olivia, you're always more than welcome."
    new "Mit all der Hilfe, die du Olivia gegeben hast, bist du hier immer mehr als willkommen."

    # say L4538 pla
    old "Thanks a lot, ma'am."
    new "Danke schön, Ma'am."

    # say L4541 vee
    old "See you, honey."
    new "Bis dann, Schatz."

    # say L4545 vee
    old "Hello, [pla]! It's so good to see you. How are you?"
    new "Hallo, [pla]! Es ist so schön, dich zu sehen. Wie geht es dir?"

    # say L4548 vee
    old "I'm okay, dear."
    new "Mir geht's gut, Liebling."

    # say L4550 vee
    old "I've been a little busy ever since the baby came, you know."
    new "Ich bin ein bisschen beschäftigt, seitdem das Baby da ist, weißt du."

    # say L4552 vee
    old "But he's such a bundle of joy that he's made everything so cheerful around here!"
    new "Aber er ist solch ein Sonnenschein, dass er alles hier aufheitert!"

    # say L4554 pla
    old "That's very good to hear, Mrs. Priya."
    new "Das freut mich zu hören, Mrs. Priya."

    # say L4555 vee
    old "Tell me, honey, what brings you here today?"
    new "Sag mal, Schatz, was führt dich heute hierher?"

    # say L4557 pla
    old "Oh, I just wanted to say hello."
    new "Oh, ich wollte dich nur hallo sagen."

    # say L4559 pla
    old "See how you're doing and stuff."
    new "Schauen, wie es dir geht und so."

    # say L4561 vee
    old "Aren't you sweet?"
    new "Bist du süß."

    # say L4563 vee
    old "Well, as you can see, we're doing more than alright."
    new "Na, wie du siehst, geht es uns mehr als gut."

    # say L4565 vee
    old "It's a shame the baby's sleeping now, otherwise you could see him."
    new "Schade, dass das Baby gerade schläft, sonst könntest du ihn sehen."

    # say L4567 vee
    old "But maybe some other time."
    new "Aber vielleicht ein anderes Mal."

    # say L4570 pla
    old "Well, it was good seeing you, Mrs. Priya. I'll be sure to come back later."
    new "Na, es war schön, dich zu sehen, Mrs. Priya. Ich werde sicher später wieder vorbeikommen."

    # say L4572 vee
    old "Sure, dear, you're welcome anytime."
    new "Klar, Schatz, du bist jederzeit willkommen."

    # say L4574 vee
    old "Nice seeing you."
    new "Schön, dich zu sehen."

    # say L4576 pla
    old "Thanks, ma'am."
    new "Danke, Ma'am."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/janAnimations.rpy
translate german strings:

    # say L37 pla
    old "(Oh shit, I'm dead.)"
    new "Oh Scheiße, ich bin tot."

    # say L47 pla
    old "Wow! Are they... Having sex?"
    new "Wow! Machen die... Sex?"

    # say L95 pla
    old "I should leave... I don't want to get caught peeping."
    new "Ich sollte gehen... Ich will nicht erwischt werden, wie ich spioniere."

    # say L144 pla
    old "(Damn, she's so tight! Oh shit! I feel like... I am going to...)"
    new "Verdammt, sie ist so eng! Oh Scheiße! Ich fühle mich, als würde ich..."

    # say L148 mo2
    old "Fuck, baby. This new strap-on has a good lubrication system. It feels like a real cumshot... And it's so warm."
    new "Fuck, Baby. Dieses neue Strap-on hat ein tolles Lubrikationssystem. Es fühlt sich an wie ein echter Absprit... Und es ist so warm."

    # say L149 mo2
    old "Mmm. Let me rest a little..."
    new "Mmm. Lass mich kurz verschnaufen..."

    # say L150 pla
    old "(Alright. I should get out of here.)"
    new "(In Ordnung. Ich sollte jetzt gehen.)"

    # say L165 pla
    old "(She's so tight! Oh shit, I feel like... I am going to...)"
    new "(Sie ist so eng! Oh Scheiße, ich fühle mich... Ich werde...)"

    # say L169 mo2
    old "Mmm, still so good... Let me rest up, baby..."
    new "Mmm, immer noch so gut... Lass mich kurz verschnaufen, Schatz..."

    # say L170 pla
    old "(Ok, I should get out...)"
    new "Ok, ich sollte rauskommen..."

    # say L188 mo2
    old "So nice to see like a little rat on the floor..."
    new "So schön, ein kleines Nagetier auf dem Boden zu sehen..."

    # say L190 mo2
    old "Are getting horny again?"
    new "Wieder geil werden?"

    # say L191 mo2
    old "You're so gross... Getting horny just by sucking my foot."
    new "Sie sind so widerlich... Schon beim Saugen meines Fußes werden Sie geil."

    # say L195 mo2
    old "Yeah! This is what you like..."
    new "Ja! Das ist genau das, was Sie mögen..."

    # say L197 mo2
    old "I see you want more and more... You are a disgusting needy bastard."
    new "Ich sehe, Sie wollen immer mehr... Sie sind ein widerlicher, bedürftiger Bastard."

    # say L202 mo2
    old "That's what you deserve for being a fucking pervert!"
    new "Das bekommen Sie dafür, dass Sie ein verdammter Perversling sind!"

    # say L204 mo2
    old "I'm going to make you suck my foot! Every day you little rat!"
    new "Ich werde dich dazu zwingen, meinen Fuß zu lecken! Jeden Tag, du kleines Arschloch!"

    # say L228 mo2
    old "That's it. Enough!"
    new "Das ist es. Genug!"

    # say L230 mo2
    old "Fuck! This is gross... Now I have my foot full of your disgusting slime."
    new "Scheiße! Das ist eklig... Jetzt habe ich meinen Fuß voll mit deinem widerlichen Schleim."

    # say L231 mo2
    old "I hope you've learned your lesson and don't go back to being perverted with your disgusting hardon."
    new "Ich hoffe, Sie haben Ihre Lektion gelernt und kehren nicht mehr zu Ihrem perversen Verhalten mit Ihrem ekelhaften Steifen zurück."

    # say L232 mo2
    old "I need to clean myself from all this bullcrap..."
    new "Ich muss mich von all diesem Mist reinigen..."

    # say L245 mo2
    old "Is this what you like, you little pervert? Do you like that your boss treats you like a cockroach?"
    new "Ist das, was dir gefällt, du kleiner Perversling? Gefällt es dir, wenn dein Boss dich wie eine Made behandelt?"

    # say L246 mo2
    old "Does that turn you on, you fucking bastard?"
    new "Das turnt dich an, du verdammter Bastard?"

    # say L253 mo2
    old "I ASKED YOU. ANSWER YOUR BOSS!"
    new "ICH HABE GEFRAGT. ANTWORTEN SIE IHREM CHEF!"

    # say L254 pla
    old "Y- yes."
    new "Y- ja."

    # say L255 mo2
    old "Ohh poor baby, he thinks I'm doing this to please him..."
    new "Ohh armer Schatz, er denkt, ich mache das für ihn..."

    # say L259 mo2
    old "I'm doing this to torture you ..."
    new "Ich mache das, um dich zu foltern..."

    # say L260 mo2
    old "Because a pervert like you only thinks with the cock!"
    new "Weil ein Perverser wie Sie nur mit dem Schwanz denkt!"

    # say L261 mo2
    old "So, I won't make you cum until you get humillied, and accept you are a cockroach and I am your master."
    new "Dann werde ich dich nicht kommen lassen, bis du gedemütigt wurdest und akzeptierst, dass du eine Made bist und ich dein Meister bin."

    # say L263 mo2
    old "I'm gonna make you my bitch [pla]."
    new "Ich werde dich zu meiner Schlampe machen [pla]."

    # say L286 mo2
    old "Ohh, are you close?"
    new "Ohh, sind Sie schon nah?"

    # say L289 mo2
    old "Well, I'm not gonna let you cum."
    new "Na, ich werde dich nicht kommen lassen."

    # say L293 mo2
    old "If you want to cum, you have to beg for it."
    new "Wenn du kommen willst, musst du darum betteln."

    # say L294 pla
    old "W- What?"
    new "W- Was?"

    # say L295 mo2
    old "Yes! Beg for it!"
    new "Ja! Betteln Sie dafür!"

    # say L296 pla
    old "P- please... L- let me cum..."
    new "P- bitte... L- lass mich kommen..."

    # say L297 mo2
    old "Do you realize how pathetic that sounds?"
    new "Begreifen Sie, wie erbärmlich das klingt?"

    # say L298 mo2
    old "You are a cockroach, a disgusting and perverted cockroach ... What are you?"
    new "Sie sind eine Wanze, eine widerliche und perversierte Wanze... Was sind Sie?"

    # say L299 pla
    old "I- I am a... D- disgusting and p- perverted... Cockroach."
    new "Ich bin ein... e- ekliges und v- verdorbenes... Wanze."

    # say L303 mo2
    old "And who am I?"
    new "Und wer bin ich?"

    # say L304 pla
    old "Uhh... Y- you are m- my boss..."
    new "Uhh... D- du bist m- mein Boss..."

    # say L305 mo2
    old "I AM YOUR MASTER!"
    new "ICH BIN DEINE MEISTERIN!"

    # say L306 pla
    old "Uhh... My master, y- you are m- my master."
    new "Uhh... Meine Meisterin, d- du bist m- meine Meisterin."

    # say L307 mo2
    old "That sounds much better."
    new "Das klingt viel besser."

    # say L311 mo2
    old "I guess you are finally learning."
    new "Ich denke, Sie lernen endlich."

    # say L313 mo2
    old "Oh, are you close again?"
    new "Oh, sind Sie schon wieder so weit?"

    # say L314 mo2
    old "It would be a shame if I stop again, isn't it?"
    new "Es wäre schade, wenn ich wieder aufhöre, oder?"

    # say L315 pla
    old "No, please... Don't stop... It hurts."
    new "Nein, bitte... Hör nicht auf... Es tut weh."

    # say L316 mo2
    old "Then beg your master!"
    new "Dann bettle deinen Meister an!"

    # say L317 pla
    old "Please, master... Please let me cum... I- I'm your... Slave!"
    new "Bitte, Meister... Lass mich kommen... Ich bin deine... Sklavin!"

    # say L318 mo2
    old "Yes, you are..."
    new "Ja, das bist du..."

    # say L324 mo2
    old "Ughh gross..."
    new "Ughh eklig..."

    # say L325 mo2
    old "I guess you are learning some respect here, aren't you?"
    new "Ich schätze, Sie lernen hier ein bisschen Respekt, oder?"

    # say L327 mo2
    old "Now, clean this, it's disgusting."
    new "Jetzt reinigen Sie das, es ist ekelhaft."

    # say L340 mo2
    old "Ohh yeah, just like that little bitch."
    new "Oh ja, genau wie dieses kleine Flittchen."

    # say L342 mo2
    old "Keep licking it."
    new "Weiterleck es."

    # say L346 mo2
    old "Wow, you are not completely useless after all."
    new "Wow, Sie sind ja gar nicht so nutzlos, wie ich dachte."

    # say L347 mo2
    old "Ahh, finally you are doing a good job."
    new "Ahh, endlich machen Sie eine gute Arbeit."

    # say L348 mo2
    old "I see you love licking and kissing my pussy..."
    new "Ich sehe, Sie lieben es, meine Pussy zu lecken und zu küssen..."

    # say L354 mo2
    old "Oh yeah, keep going little bitch!"
    new "Oh ja, mach weiter, kleine Schlampe!"

    # say L356 mo2
    old "I'm your master and you gotta lick me until I tell you to stop."
    new "Ich bin deine Herrin und du musst mich lecken, bis ich dir sage, dass du aufhören sollst."

    # say L379 mo2
    old "Don't stop, don't stop, you fucking bastard..."
    new "Hör nicht auf, hör nicht auf, du verdammter Bastard..."

    # say L381 mo2
    old "Oh gosh! Ahhhhh! Fuck!"
    new "Oh Gott! Ahhhhh! Scheiße!"

    # say L390 mo2
    old "Ahh, that wasn't bad, you are finally good at something."
    new "Ahh, das war ja gar nicht schlecht, Sie sind endlich gut in etwas."

    # say L391 pla
    old "T- Thank-"
    new "D- Danke..."

    # say L392 mo2
    old "Anyway, get out, I have to work."
    new "Na los, raus hier, ich muss arbeiten."

    # say L397 mo2
    old "Uhhh, I think you are improving."
    new "Uhhh, ich denke, Sie verbessern sich."

    # say L398 mo2
    old "Maybe I could reward you for doing a good job, maybe that way you will stop being a stupid useless at everything else."
    new "Vielleicht könnte ich dich für gute Arbeit belohnen, vielleicht hörst du dann auf, in allem anderen dumm und nutzlos zu sein."

    # say L399 pla
    old "W- what do you mean?"
    new "W-was meinst du damit?"

    # say L400 mo2
    old "I'm tough but fair, and you have pleased me these last two times."
    new "Ich bin streng, aber fair, und du hast mich in den letzten beiden Malen zufriedengestellt."

    # say L401 mo2
    old "Now it's time for a reward for this little pervert. Now take out your pants."
    new "Jetzt ist es Zeit für eine Belohnung für diesen kleinen Perversling. Zieh jetzt deine Hose aus."

    # say L402 pla
    old "Y- yes master."
    new "J- ja, Meister."

    # say L409 mo2
    old "What are you waiting for? I'm not going to do it for you, if you want to cum you will have to do it yourself, idiot."
    new "Was wartest du noch? Ich mache das sicher nicht für dich, wenn du kommen willst, musst du es selbst tun, Idiot."

    # say L410 pla
    old "Uhh... R- right, sorry."
    new "Uhh... R- richtig, sorry."

    # say L422 mo2
    old "Hahaha, you look like a poor animal begging to cum with my foot."
    new "Hahaha, du siehst aus wie ein armer Tier, das bettelt, um zu kommen, mit meinem Fuß."

    # say L427 mo2
    old "Oh, you're getting more excited, just like a bitch in heat."
    new "Oh, du wirst ja immer aufgeregter, genau wie eine Hündin im Wurfstand."

    # say L429 mo2
    old "You are disgusting."
    new "Sie sind widerlich."

    # say L433 mo2
    old "I see you're speeding up, Are you getting close?"
    new "Ich sehe, Sie werden schneller, kommen Sie gleich?"

    # say L434 pla
    old "Y- yes..."
    new "Y- ja..."

    # say L435 mo2
    old "Don't you dare come on my foot, because I kill you."
    new "Du wagst es nicht, auf meinem Fuß zu kommen, sonst bringe ich dich um."

    # say L459 mo2
    old "Ohh, your cock is about to explode but you cannot cum because I haven't said you can do so..."
    new "Ohh, dein Schwanz will gleich explodieren, aber du darfst nicht kommen, weil ich es dir noch nicht erlaubt habe..."

    # say L460 mo2
    old "Poor boy can't cum because I won't let you do it. Unless you beg for it."
    new "Armer Junge, du darfst nicht kommen, weil ich es dir nicht erlaube. Es sei denn, du bettelst darum."

    # say L461 pla
    old "... P- please master... L- let me cum."
    new "P- bitte Meisterin... L- lass mich kommen."

    # say L462 mo2
    old "Hmm, I'm not sure... you should give it a better try."
    new "Hmm, ich bin mir nicht sicher... du solltest es besser versuchen."

    # say L463 pla
    old "I- I- I am your bitch... Just a cockroach, and you are my master, p- please let this cockroach c- cum..."
    new "I- I- Ich bin dein Schoßhündchen... Nur eine Wanze, und du bist mein Meister, b- bitte lass diese Wanze k- kommen..."

    # say L464 mo2
    old "Hmm, why do I have to be so merciful? Alright, stop moving, I'm gonna help you out."
    new "Hmm, warum muss ich denn so gnädig sein? Gut, hör auf zu zappeln, ich helfe dir weiter."

    # say L474 mo2
    old "One more time you see who is the Master..."
    new "Noch einmal, sehen Sie, wer der Meister ist..."

    # say L475 pla
    old "Y- Yes-"
    new "J- Ja-"

    # say L476 mo2
    old "You're shit... Don't talk if I don't tell you so..."
    new "Sie sind Scheiße... Reden Sie nur, wenn ich es Ihnen sage..."

    # say L477 pla
    old "S- sorr-"
    new "S- sorry, Mo..."

    # say L478 mo2
    old "Shut up!"
    new "Halt die Klappe!"

    # say L482 mo2
    old "Yeahh! I like when you don't talk and only listen to your master."
    new "Jaah! Ich mag es, wenn du nicht redest und nur deinem Meister zuhörst."

    # say L484 mo2
    old "Fucking pervert!"
    new "Verdammter Perversling!"

    # say L486 mo2
    old "Shut up and follow my words... You won't talk if your master wants silence..."
    new "Halten Sie den Mund und folgen Sie meinen Worten... Sie werden nicht sprechen, wenn Ihr Meister Stille will..."

    # say L490 mo2
    old "Oh look at you so vulnerable and needy."
    new "Oh, schauen Sie sich an, so verletzlich und bedürftig."

    # say L491 mo2
    old "Are you getting close? Because you look awful."
    new "Kommen Sie gleich? Denn Sie sehen schrecklich aus."

    # say L492 pla
    old "Y- yes, master."
    new "Y- ja, Meister."

    # say L493 mo2
    old "Alright, don't cum until I tell you."
    new "Okay, nicht kommen, bis ich es dir sage."

    # say L494 pla
    old "Uhh, Y- yes, m- master."
    new "Uhh, J- ja, M- Meister."

    # say L517 mo2
    old "Ask for permission if you want to cum."
    new "Frag deinen Meister um Erlaubnis, wenn du kommen willst."

    # say L519 mo2
    old "Yes! Ask your Master for permission."
    new "Ja! Frag deinen Meister um Erlaubnis."

    # say L520 pla
    old "I need to cum... N- now, please."
    new "Ich muss kommen... J-jetzt, bitte."

    # say L521 pla
    old "M- Maste-"
    new "M- Meister..."

    # say L522 mo2
    old "You'll come whenever I want, not when you need to..."
    new "Du wirst kommen, wann ich will, nicht, wenn du es brauchst..."

    # say L523 mo2
    old "Say that you're my little bitch... Say it and I'll make you cum, maybe... Who knows if I'll change my mind."
    new "Sagen Sie, dass Sie mein kleiner Schoßhund sind... Sagen Sie es und ich lasse Sie kommen, vielleicht... Wer weiß, ob ich meine Meinung nicht doch noch ändere."

    # say L525 pla
    old "I- I'm your L- little B- bitch."
    new "I- Ich bin d- deine k- kleine S- Schlampe."

    # say L526 pla
    old "Let me cum, please..."
    new "Lass mich kommen, bitte..."

    # say L532 mo2
    old "Uhh... Gross."
    new "Uhh... Ekelig."

    # say L544 mo2
    old "At least you're getting better on this."
    new "Zumindest werden Sie darin besser."

    # say L545 mo2
    old "Oh yeah, keep licking it."
    new "Oh ja, lecken Sie weiter."

    # say L547 mo2
    old "Uhh this position is pretty good!"
    new "Uhh, diese Position ist echt gut!"

    # say L551 mo2
    old "Do you like it? Having your master pussy on your face?"
    new "Magst du es? Deine Herrin Muschi auf deinem Gesicht?"

    # say L553 mo2
    old "Good boy, keep doing it, and I might reward you."
    new "Guter Junge, mach weiter so, und ich könnte dich belohnen."

    # say L557 mo2
    old "Ahh! Yess!"
    new "Ahh! Ja!"

    # say L558 mo2
    old "Oh yeah, keep going, keep going!"
    new "Oh ja, mach weiter, mach weiter!"

    # say L584 mo2
    old "You're my bitch... Keep doing it."
    new "Sie sind meine Hure... Machen Sie weiter."

    # say L586 mo2
    old "Oh gosh! Ahhhh! Fuck!"
    new "Oh Gott! Ahhhh! Scheiße!"

    # say L593 mo2
    old "You're a bad employee but since you've done well today, I'm gonna give you something."
    new "Sie sind eine schlechte Angestellte, aber da Sie sich heute gut geschlagen haben, werde ich Ihnen etwas geben."

    # say L598 mo2
    old "However, you will keep licking and you will make me cum again."
    new "Allerdings wirst du weiterlecken und mich noch einmal kommen lassen."

    # say L611 mo2
    old "Wow, you are definitely enjoying your master's pussy, right?"
    new "Wow, du genießt es definitiv, deiner Herrin die Muschi zu lecken, oder?"

    # say L612 pla
    old "Uhh I-"
    new "Uhh ich-"

    # say L613 mo2
    old "Don't ever stop licking, or I'll rip your cock off!"
    new "Hör nie auf zu lecken, oder ich reiße deinen Schwanz ab!"

    # say L618 mo2
    old "Look how much you enjoy it... Uhh? your little bastard."
    new "Schau dir an, wie sehr du es genießt... Uhh? Du kleiner Bastard."

    # say L619 mo2
    old "You are really a pervert, is this what you wanted? Uh?"
    new "Sie sind wirklich ein Perverser, ist das, was Sie wollten? Uh?"

    # say L621 mo2
    old "Just keep going."
    new "Weitermachen."

    # say L625 mo2
    old "Oh yeah, keep going, make me cum again!"
    new "Oh ja, mach weiter, bring mich nochmal zum Kommen!"

    # say L626 mo2
    old "Don't stop, don't stop, you little bastard."
    new "Hör nicht auf, hör nicht auf, du kleiner Bastard."

    # say L656 mo2
    old "Okay, I'm done here, I hope you don't screw it up again at work. Otherwise, next time it will be worse."
    new "Okay, ich bin hier fertig, ich hoffe, du versaust es nicht wieder bei der Arbeit. Sonst wird es beim nächsten Mal schlimmer."

    # say L657 mo2
    old "Get dressed and leave, I can't waste any more time with you."
    new "Zieh dich an und verschwinde, ich kann keine Zeit mehr mit dir verschwenden."

    # say L665 mo2
    old "Uhh that was good..."
    new "Uhh das war gut..."

    # say L666 pla
    old "Alright, I'm gonna get dressed."
    new "Okay, ich zieh mich an."

    # say L667 mo2
    old "Oh gosh, I want a little more."
    new "Oh Gott, ich will noch ein bisschen mehr."

    # say L669 mo2
    old "Shut up and keep licking. I'm going to try something different."
    new "Halten Sie den Mund und lecken Sie weiter. Ich werde etwas anderes versuchen."

    # say L677 pla
    old "Oh wow! What the fuck!"
    new "Oh wow! Was zur Hölle!"

    # say L678 mo2
    old "Don't even think about saying or doing something, keep quiet, and don't stop licking."
    new "Nicht mal dran denken, was zu sagen oder zu tun, sei still und hör nicht auf, zu lecken."

    # say L687 mo2
    old "This is what you always wanted, isn't it?"
    new "Das ist doch genau das, was du immer wolltest, oder?"

    # say L689 mo2
    old "Getting your naughty and disgusting cock sucked."
    new "Ihren schmutzigen und ekelhaften Schwanz lutschen."

    # say L693 mo2
    old "Do you like it? Uh? Do you like your master sucking your cock?"
    new "Magst du es? Uh? Magst du es, wenn dein Meister deinen Schwanz lutscht?"

    # say L695 mo2
    old "Of course you do, look how excited and horny you are."
    new "Natürlich, sehen Sie sich an, wie aufgeregt und geil Sie sind."

    # say L699 mo2
    old "Ohh, yeah, keep going, keep licking my pussy, you little pervert."
    new "Ohh, ja, mach weiter, leck meine Pussy, du kleiner Perversling."

    # say L700 mo2
    old "Are you going to remain useless, good for nothing? Are you going to keep doing it so that I continue to punish you?"
    new "Wollen Sie nutzlos und zu nichts zu gebrauchen bleiben? Wollen Sie weitermachen, damit ich Sie weiter bestrafe?"

    # say L701 mo2
    old "You're my bitch, [pla] never forget about it."
    new "Du bist mein Schoßhund, [pla] vergiss das nie."

    # say L724 mo2
    old "Ohh, yeah, don't stop, don't stop!"
    new "Ohh, ja, hör nicht auf, hör nicht auf!"

    # say L725 pla
    old "I- I'm cumming!"
    new "Ich- Ich komme!"

    # say L726 mo2
    old "Ahhh I- I'm cumming to!"
    new "Ahhh Ich- Ich komme!"

    # say L733 mo2
    old "Ughhh, gross..."
    new "Ughhh, eklig..."

    # say L734 mo2
    old "I better go clean this up, it's disgusting... "
    new "Ich sollte das besser aufräumen, das ist ekelig..."

    # say L745 mo2
    old "I'm your boss and your Master."
    new "Ich bin Ihre Chefin und Ihr Meister."

    # say L746 mo2
    old "And you're shit... And you do what I say."
    new "Und Sie sind Scheiße... Und Sie tun, was ich sage."

    # say L747 mo2
    old "Got it?"
    new "Verstanden?"

    # say L749 mo2
    old "You belong to me and I do whatever I fucking want with you."
    new "Du gehörst mir und ich mache mit dir, was ich verdammt nochmal will."

    # say L753 mo2
    old "Yeahh! This is what you like..."
    new "Jaah! Das ist genau das, was Sie mögen..."

    # say L755 mo2
    old "Fucking pervert! Fucking slave... Useless bitch."
    new "Verdammter Perversling! Verdammte Sklavin... Nutzlose Schlampe."

    # say L757 mo2
    old "Your cock is really hard but I won't make you cum yet... Not if you are so eagered. You don't deserve to cum now."
    new "Ihr Schwanz ist wirklich hart, aber ich werde dich noch nicht kommen lassen... Nicht wenn du so gierig bist. Du hast es jetzt nicht verdient zu kommen."

    # say L761 mo2
    old "You are about to explode! isn't it? Fuck you!"
    new "Du bist kurz davor zu explodieren, oder? Scheiß drauf!"

    # say L763 mo2
    old "Say who is your Master?"
    new "Wer ist Ihr Meister?"

    # say L765 mo2
    old "Say it out loud NOW!"
    new "Sagen Sie es laut JETZT!"

    # say L766 mo2
    old "If you wanna cum, you'll need to say it!"
    new "Wenn du kommen willst, musst du es sagen!"

    # say L767 pla
    old "Y- You... You're my Master."
    new "D-Du... Du bist meine Meisterin."

    # say L768 mo2
    old "You want to cum... Poor boy can't come because I won't let him do it."
    new "Du willst kommen... Armer Junge kann es nicht, weil ich es ihm nicht erlaube."

    # say L791 mo2
    old "If you want to come, you have to beg for it again."
    new "Wenn du kommen willst, musst du wieder darum betteln."

    # say L792 pla
    old "A- again..."
    new "Wieder..."

    # say L793 mo2
    old "Yes! Beg for it! You have to learn little bitch."
    new "Ja! Bettel darum! Du musst es lernen, kleine Schlampe."

    # say L794 pla
    old "P- please, I- I need to cum... I really need it... N- now."
    new "P- bitte, ich- ich muss abspritzen... Ich brauche es wirklich... J- jetzt."

    # say L795 mo2
    old "You'll cum whenever I want not when you need to..."
    new "Du wirst kommen, wann ich es will, nicht, wenn du es brauchst..."

    # say L796 mo2
    old "Say that you're my bitch... Say it and I'll let you cum."
    new "Sagen Sie, dass Sie meine Hure sind... Sagen Sie es und ich lasse Sie kommen."

    # say L798 pla
    old "I'm your b- bitch, master..."
    new "Ich bin deine B-Bitch, Meister..."

    # say L805 mo2
    old "I didn't expect this to happen but I'll do it..."
    new "Ich habe nicht damit gerechnet, aber ich werde es tun..."

    # say L806 mo2
    old "I've tried to show you who is the Master here but you still refuse to believe..."
    new "Ich habe versucht, dir zu zeigen, wer hier der Meister ist, aber du weigerst dich immer noch, es zu glauben..."

    # say L807 mo2
    old "We cannot keep going in the same way... Now you'll know who is the master and who is the slave."
    new "Wir können nicht so weitermachen... Jetzt wirst du erfahren, wer der Meister und wer die Sklavin ist."

    # say L809 mo2
    old "I'm your fucking Master and you're my slave, you listen and do as I say..."
    new "Ich bin dein verdammter Meister und du bist mein Sklave, du hörst zu und tust, was ich sage..."

    # say L810 mo2
    old "This is not a game! I'm gonna fuck you if I want, you do as I tell you..."
    new "Das ist kein Spiel! Ich ficke dich, wann ich will, und du tust, was ich sage..."

    # say L811 pla
    old "W- what-"
    new "W-was..."

    # say L827 mo2
    old "Little bastard, useless and needy..."
    new "Kleiner Bastard, nutzlos und bedürftig..."

    # say L829 mo2
    old "I'm your Master and I want you to say it more often."
    new "Ich bin dein Meister und ich will, dass du es öfter sagst."

    # say L831 mo2
    old "I don't hear you!"
    new "Ich höre dich nicht!"

    # say L832 mo2
    old "Say it! Who is your Master?"
    new "Sagen Sie es! Wer ist Ihr Meister?"

    # say L833 pla
    old "Y- You..."
    new "Y- Du..."

    # say L838 mo2
    old "Seems that the slave is doing okay..."
    new "Scheint, dass die Sklavin sich ganz gut schlägt..."

    # say L840 mo2
    old "Are you enjoying this? Who told you to enjoy this... You're just a fucking slave..."
    new "Genießen Sie das? Wer hat Ihnen gesagt, dass Sie das genießen dürfen... Sie sind doch nur ein beschissener Sklave..."

    # say L842 mo2
    old "You're almost nonexistent... Without me, you're nothing. Without your Master, you're nothing."
    new "Sie sind fast nichts... Ohne mich sind Sie nichts. Ohne Ihren Meister sind Sie nichts."

    # say L843 mo2
    old "I'll make you suffer, motherfucker!"
    new "Ich werde dich leiden lassen, du Scheißkerl!"

    # say L848 mo2
    old "You are about to explode! isn't it? Fucking idiot!"
    new "Sie sind kurz davor zu explodieren, oder? Verdammt nochmal, Idiot!"

    # say L850 mo2
    old "I'm fucking you, little bastard."
    new "Ich ficke dich, kleiner Bastard."

    # say L851 mo2
    old "Now you are my bitch, I'm fucking my little bitch."
    new "Jetzt bist du meine Schlampe, ich ficke meine kleine Schlampe."

    # menu L872 
    old "Change perspective"
    new "Perspektive wechseln"

    # say L882 mo2
    old "Ohh yeahh, can you feel how hard I'm fucking you?"
    new "Ohh ja, spüren Sie, wie hart ich Sie ficke?"

    # say L884 mo2
    old "Yes, I'm cuming on you fucking bastard"
    new "Ja, ich komme auf dir, du verdammter Bastard"

    # say L893 mo2
    old "All right, I already made you my bitch!"
    new "Alles klar, ich hab dich schon zu meiner Bitch gemacht!"

    # say L894 mo2
    old "Never ever, try to rebel against me, I am your master."
    new "Nie im Leben, versuch nicht, dich gegen mich aufzulehnen, ich bin dein Meister."

    # say L909 mo1
    old "Oh, yes [mo2]! I missed you so much..."
    new "Oh, ja [mo2]! Ich habe dich so sehr vermisst..."

    # say L910 mo2
    old "Uhh... You are fucking hot babe..."
    new "Uhh... Du bist verdammt heiß, Babe..."

    # say L911 mo1
    old "This feels so nice... Oh my God!"
    new "Das fühlt sich so gut... Oh Gott!"

    # say L915 mo2
    old "Ahhh, don't stop baby, don't stop!"
    new "Ahhh, hör nicht auf, Baby, hör nicht auf!"

    # say L916 mo1
    old "Oh yes! I have been waiting a lot for this!"
    new "Oh ja! Darauf habe ich schon so lange gewartet!"

    # say L917 mo1
    old "I love you [mo2], I love you so much!"
    new "Ich liebe dich [mo2], ich liebe dich so sehr!"

    # say L918 mo2
    old "I love you too. You are my girl."
    new "Ich liebe dich auch. Du bist mein Mädchen."

    # say L919 pla
    old "(What the fuck, she doesn't sound like the [mo2] I know...)"
    new "Was zur Hölle, das klingt ja gar nicht wie die [mo2], die ich kenne..."

    # say L923 mo2
    old "Oh yeah, just like that babe, Just like that!"
    new "Oh ja, genau so, Liebling, genau so!"

    # say L924 mo1
    old "Ahhh, Ahhh! I love you."
    new "Ahhh, Ahhh! Ich liebe Sie."

    # say L925 mo2
    old "Keep going, keep going!"
    new "Weiter so, weiter so!"

    # say L926 mo1
    old "Oh my God, I'm so fucking horny!"
    new "Oh Gott, ich bin so verdammt geil!"

    # say L950 mo2
    old "Yes, Yes, cum for me baby!"
    new "Ja, ja, komm für mich, Baby!"


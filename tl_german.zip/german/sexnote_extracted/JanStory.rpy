# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/JanStory.rpy
translate german strings:

    # say L13 pla
    old "Ugh, finally at home."
    new "Ugh, endlich zu Hause."

    # say L15 pla
    old "Hmm. What is that noise? It's coming from the living room..."
    new "Hmm. Was ist das für ein Geräusch? Es kommt aus dem Wohnzimmer..."

    # say L19 pla
    old "Woah! Are they... Having sex?"
    new "Woah! Machen die... Sex?"

    # say L35 pla
    old "I... Am... Sorry... I... Just... Heard..."
    new "Ich... bin... sorry... Ich... hab'... nur... gehört..."

    # say L37 mo2
    old "Weren't you supposed to come back at night?!"
    new "Waren Sie nicht erst spät zurückkommen sollen?!"

    # say L39 pla
    old "Yes, but my after school program was canceled..."
    new "Ja, aber mein Nachmittagsprogramm wurde abgesagt..."

    # say L46 pla
    old "... I'm sorry... I..."
    new "... Es tut mir leid... Ich..."

    # say L84 pla
    old "I know they are married but... They should do that in their room..."
    new "Ich weiß, dass sie verheiratet sind, aber... Das sollten sie in ihrem Zimmer machen..."

    # say L85 pla
    old "Anyway, I have all day to relax..."
    new "Jedenfalls, ich habe den ganzen Tag Zeit, um mich zu entspannen..."

    # say L96 mo1
    old "Listen, I want to talk to you about t- the living room"
    new "Hör zu, ich möchte mit Ihnen über das Wohnzimmer sprechen"

    # say L98 pla
    old "Oh, I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "Oh, ich verstehe. Ihr seid ein Paar, das finde ich total normal... Und du bist meine [mo1rel], du musst mir keine Erklärungen geben."

    # say L100 mo1
    old "I'm glad to hear that. But... I want to apologize. We were a bit careless getting... Intimate in the living room."
    new "Ich bin froh, das zu hören. Aber... ich möchte mich entschuldigen. Wir waren etwas unvorsichtig, als wir im Wohnzimmer... intim wurden."

    # say L106 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey."
    new "Na gut, ich werde dich nicht weiter stören. Bitte lern weiter fleißig, Schatz."

    # say L107 mo1
    old "Oh, by the way, you haven't had breakfast, come downstairs and I'll make you breakfast!"
    new "Oh, übrigens, du hast noch nichts gefrühstückt, komm nach unten, ich mache dir was zu essen!"

    # say L108 pla
    old "Oh right, thank you [mo1rel]."
    new "Oh richtig, danke [mo1rel]."

    # say L126 pla
    old "(What the fuck!... what are they doing?)"
    new "Was zur Hölle!... Was machen die da?"

    # say L132 pla
    old " (Shit!) Oh, no... Nuh uh... The door was open. I just didn't know someone was in here."
    new "(Scheiße!) Oh nein... Auf keinen Fall... Die Tür war offen. Ich wusste nur nicht, dass jemand hier drin ist."

    # say L133 mo1
    old "[pla], [mo2] and I were just giving each other a little hug, sweetie."
    new "[pla] und [mo2] haben uns gerade nur ein bisschen umarmt, Schatz."

    # say L134 mo2
    old "See, I tried to tell you he is a damn pervert!... GO AWAY!"
    new "Siehst du, ich hab’s dir doch gesagt, er ist ein verdammter Perversling!... VERSCWINDE!"

    # say L136 pla
    old "I wasn't... Nevermind... I'll go."
    new "Ich war nicht... Vergiss es... Ich geh."

    # say L158 mo1
    old "Oh hi [pla], I'm glad you're here, I wanted to talk to you too."
    new "Oh hallo [pla], ich freue mich, dass du da bist, ich wollte auch mit Ihnen sprechen."

    # say L159 pla
    old "Ehm... Is something happening?"
    new "Ehm... Passiert hier was?"

    # say L160 sis
    old "I don't know, I just arrived."
    new "Ich weiß nicht, ich bin gerade erst angekommen."

    # say L164 mo1
    old "Hmm... Actually, yes... That's why I need to talk to you both."
    new "Hmm... Eigentlich, ja... Deshalb muss ich mit Ihnen beiden sprechen."

    # say L166 mo1
    old "We are having some... Uhh, financial issues..."
    new "Wir haben ein paar... Naja, finanzielle Probleme..."

    # say L168 mo1
    old "Well, we don't have e- enough money to pay our obligations..."
    new "Nun, wir haben nicht genug Geld, um unsere Verpflichtungen zu bezahlen..."

    # say L170 sis
    old "But why didn't you say anything before?"
    new "Aber warum hast du nichts gesagt?"

    # say L171 mo1
    old "Hmm, I didn't want you to worry about it... It's my obligation to provide for both of you... It's just that our current monetary situation is getting worse and..."
    new "Hmm, ich wollte Sie nicht damit belasten... Es ist meine Pflicht, für Sie beide zu sorgen... Nur unsere finanzielle Situation wird immer schwieriger und..."

    # say L173 mo1
    old "I- I have been looking at some options and I have applied for different jobs but even that seems to be difficult."
    new "Ich hab schon nach ein paar Optionen gesucht und mich bei verschiedenen Jobs beworben, aber das ist auch nicht einfach."

    # say L175 mo1
    old "It's not that easy... Since I have been unemployed for so long, now it's much harder for me to find a job."
    new "Es ist nicht so einfach... Da ich schon seit so langer Zeit arbeitslos bin, fällt es mir jetzt viel schwerer, eine Arbeit zu finden."

    # say L176 mo1
    old "I have already talked to my [mo1rel] and friends but no luck... Nothing yet and only God knows when I'll get something good enough."
    new "Ich habe schon mit meinen [mo1rel] und Freunden gesprochen, aber kein Glück... Bisher nichts und nur Gott weiß, wann ich etwas Passendes finde."

    # say L178 mo1
    old "[mo2] was very generous with us when we were together, she paid for almost everything since she has a high salary income."
    new "[mo2] war sehr großzügig zu uns, als wir noch zusammen waren. Sie hat fast alles bezahlt, weil sie ein hohes Einkommen hat."

    # say L179 mo1
    old "Now that she is gone and we are no longer together, we are facing many more issues. I didn't expect the situation to go this way..."
    new "Nun, da sie fort ist und wir nicht mehr zusammen sind, stehen uns viele mehr Probleme gegenüber. Ich habe nicht damit gerechnet, dass es so kommen würde..."

    # say L180 pla
    old "You're not alone on this... Kyle and I will help you... Right?"
    new "Du bist nicht allein damit... Kyle und ich werden dir helfen... Okay?"

    # say L181 sis
    old "Yes, of course! I'm working and you know I can help, don't worry about it [mo1rel]."
    new "Natürlich! Ich arbeite und du weißt, dass ich helfen kann, mach dir keine Sorgen [mo1rel]."

    # say L182 mo1
    old "It's not that easy, I know you wanna help but we owe a lot of money... Argh! I- I don't know what to do."
    new "Es ist nicht so einfach, ich weiß, dass Sie helfen wollen, aber wir schulden viel Geld... Argh! I- Ich weiß nicht, was ich tun soll."

    # say L183 mo1
    old "And [mo2] is gone, she is gone and I'm here..."
    new "Und [mo2] ist weg, sie ist weg und ich bin hier..."

    # say L184 pla
    old "We'll find the way to solve thi-"
    new "Wir werden einen Weg finden, das zu lösen"

    # say L185 mo1
    old "I- I can't now, I better go to take some rest... I can't do this now... Sorry but I can't."
    new "Ich- Ich kann das jetzt nicht, ich sollte mich besser ausruhen... Ich schaffe das jetzt nicht... Es tut mir leid, aber ich kann das nicht."

    # say L186 pla
    old "S- Sure [mo1rel], it's fine."
    new "S-Sicher, [mo1rel], ist okay."

    # say L194 pla
    old "It's the first time I see [mo1rel] this worried and sad, especially sad. We gotta do something to help."
    new "Das ist das erste Mal, dass ich [mo1rel] so besorgt und traurig sehe, besonders traurig. Wir müssen etwas tun, um ihr zu helfen."

    # say L195 sis
    old "Yeah! I didn't imagine seeing her like this. [pla] find a job and I'll do my part, I'll find a way to help as well, even if she says isn't enough."
    new "Klar! Ich hätte nie gedacht, sie so zu sehen. [pla] such ich mir einen Job und du machst deinen Teil, ich werde auch einen Weg finden, ihr zu helfen, auch wenn sie sagt, es reicht nicht."

    # say L196 pla
    old "Sure! I'll start to look for something immediately... It's too sa-"
    new "Klar! Ich fange sofort an zu suchen... Es ist echt traurig-"

    # say L197 sis
    old "Yeah, yeah... I know it's sad but we gotta focus on finding a solution for this..."
    new "Ja, ja... Ich weiß, es ist traurig, aber wir müssen uns darauf konzentrieren, eine Lösung zu finden."

    # say L198 sis
    old "Tell me once you have found something..."
    new "Sag Bescheid, wenn du was gefunden hast..."

    # say L199 pla
    old "I will."
    new "Ich werd's tun."

    # say L200 sis
    old "Alright, See ya!"
    new "Okay, dann bis später!"

    # say L206 pla
    old "Shit! This is bad... I gotta find a job, my [mo1rel] is gonna get sick and depressed if we don't do something."
    new "Scheiße! Das ist schlecht... Ich muss einen Job finden, meine [mo1rel] wird krank und depressiv, wenn wir nichts tun."

    # say L207 pla
    old "Argh! But where? Really, where can I find a job?"
    new "Argh! Aber wo? Wo kann ich überhaupt einen Job finden?"

    # say L208 pla
    old "Maybe at the vet's store... Or with Dr. Johnson... I don't know!"
    new "Vielleicht bei der Tierhandlung... Oder bei Dr. Johnson... Ich weiß auch nicht!"

    # say L209 pla
    old "I know! With Lisa..."
    new "Ich weiß! Bei Lisa..."

    # say L210 pla
    old "Or [mo2]... No! What am I thinking about!... [mo2], no!... She would kick out my ass."
    new "Oder [mo2]... Nein! Was denke ich da!... [mo2], nein!... Die würde mir den Hintern versohlen."

    # say L211 pla
    old "I shouldn't keep wasting my time... I'll go to all and see what I find, I need a job, I cannot let my [mo1rel] down... She needs me"
    new "Ich sollte nicht mehr meine Zeit verschwenden... Ich werde bei allen vorbeischauen und sehen, was ich finde, ich brauche einen Job, ich kann [mo1rel] nicht im Stich lassen... Sie braucht mich."

    # say L229 pla
    old "What a day! Argh! It seems to be impossible to find a job... Don't know what I'm gonna do"
    new "Was für ein Tag! Argh! Es scheint unmöglich zu sein, eine Arbeit zu finden... Keine Ahnung, was ich machen soll."

    # say L230 pla
    old "Maybe I should ask at schoo-"
    new "Vielleicht sollte ich bei der Schule nachfragen-"

    # say L237 sis
    old "Hey [pla], we have to talk."
    new "Hey [pla], wir müssen reden."

    # say L239 sis
    old "What happened? Why the sad face?"
    new "Was ist passiert? Warum das traurige Gesicht?"

    # say L240 pla
    old "Well, I was looking for any job opportunity the whole day but no luck, nobody wants to hire me."
    new "Na ja, ich habe den ganzen Tag nach einem Job gesucht, aber ohne Erfolg, niemand will mich einstellen."

    # say L241 sis
    old "That's bad... You know, [mo1rel] was crying a lot today, she is feeling like shit."
    new "Das ist schlecht... Du weißt, [mo1rel] hat heute viel geweint, sie fühlt sich wie Scheiße."

    # say L242 sis
    old "Argh! I can't see her like that... You have to find something, you really have to."
    new "Argh! Ich kann sie so nicht sehen... Du musst was finden, echt jetzt."

    # say L243 pla
    old "Did she tell you anything? Did you talk to her?"
    new "Hat sie dir was gesagt? Hast du mit ihr geredet?"

    # say L244 sis
    old "No, she doesn't want us to notice how she's feeling, I didn't say anything and that's why I'm telling you."
    new "Nein, sie will nicht, dass wir merken, wie es ihr geht. Deshalb hab ich nichts gesagt und deshalb sag ich es dir."

    # say L245 pla
    old "I'll find something, we can't let [mo1rel] down."
    new "Ich finde was, wir können [mo1rel] nicht im Stich lassen."

    # say L246 sis
    old "No, we can't. You find something tomorrow... Do your best, man! Do something about it because we have serious bullshit here."
    new "Nein, können wir nicht. Du findest morgen was... Mach dein Bestes, Mann! Tu was dagegen, weil wir hier ernsthaften Scheiß haben."

    # say L247 pla
    old "I know, I know..."
    new "Ich weiß, ich weiß..."

    # say L248 sis
    old "Good, see you tomorrow then..."
    new "Gut, dann bis morgen..."

    # say L249 pla
    old "Bye..."
    new "Bis dann..."

    # say L254 pla
    old "Oh my Gosh! Where am I going to find a job now?"
    new "Oh mein Gott! Wo soll ich jetzt eine Arbeit finden?"

    # say L255 pla
    old "I already tried with the best options I had in mind... What abou-"
    new "Ich hab' schon die besten Optionen ausprobiert, die mir eingefallen sind... Was ist mit-"

    # say L256 pla
    old "[mo2]? Perhaps she doesn't hate me that much and I could have a chance there... Argh! No! Fuck, I don't wanna ask to her..."
    new "[mo2]? Vielleicht hasst sie mich ja nicht so sehr und ich hätte da eine Chance... Argh! Nein! Scheiße, ich will sie nicht danach fragen..."

    # say L258 pla
    old "Fuck it! I'll do it, this is about my [mo1rel], I have to try at least... Tomorrow I'll see [mo2]."
    new "Scheiß drauf! Ich mach's, das geht um meine [mo1rel], ich muss es zumindest versuchen... Morgen sehe ich [mo2]."

    # say L274 pla
    old "Hi Akita... I'm [pla]"
    new "Hi Akita... Ich bin [pla]"

    # say L275 aki
    old "Oh! Hey, I remember you, yes... You're the handsome delivery guy..."
    new "Oh! Hey, ich erinnere mich an dich, ja... Du bist der gut aussehende Paketbote..."

    # say L276 aki
    old "Tell me... What can I do for you?"
    new "Sag mal... Was kann ich für dich tun?"

    # say L278 pla
    old "H- Handsome? Haha t- thanks."
    new "H- Handsome? Haha danke."

    # say L279 pla
    old "Actually I'm here looking for [mo2]."
    new "Tatsächlich bin ich hier, um nach [mo2] zu suchen."

    # say L297 mo2
    old "[pla]? What the heck are you doing here?"
    new "[pla]? Was zum Teufel machst du hier?"

    # say L298 pla
    old "H- Hi [mo2], I- I don't want to bother you but I have to talk to you, I- I need to tell you something."
    new "H- Hallo [mo2], ich- ich will dich nicht stören, aber ich muss mit dir reden, ich- ich muss dir was sagen."

    # say L299 mo2
    old "What do you want?"
    new "Was willst du?"

    # say L300 pla
    old "I see but I really need to ask you for a favor..."
    new "Ich sehe, aber ich muss dich wirklich um einen Gefallen bitten..."

    # say L301 pla
    old "I need a job, I can do whatever you ask me to but I need to work. The situation at home is not ok and we all are worried."
    new "Ich brauche einen Job, ich mache alles, was du von mir verlangst, aber ich muss arbeiten. Die Situation zu Hause ist nicht in Ordnung und wir alle machen uns Sorgen."

    # say L303 mo2
    old "So you come to my office and you pretend I give you a job? Why should I do that!?"
    new "Dann kommen Sie in mein Büro und tun so, als würde ich Ihnen einen Job geben? Warum sollte ich das tun!?"

    # say L304 pla
    old "[mo2], please! I know you don't like me but believe you're the last option I have, I don't know what else to do."
    new "[mo2], bitte! Ich weiß, dass du mich nicht magst, aber glaub mir, du bist meine letzte Option. Ich weiß nicht, was ich sonst tun soll."

    # say L305 mo2
    old "Finally you got it! Yes, I don't like you and I won't hire you. Don't be stupid! Now go away! I don't want you here."
    new "Endlich haben Sie es kapiert! Ja, ich mag Sie nicht und ich werde Sie nicht einstellen. Seien Sie nicht dumm! Jetzt verschwinden Sie! Ich will Sie hier nicht haben."

    # say L306 mo2
    old "Now that you all need me, you come here looking for me! Well, I don't care!"
    new "Jetzt, wo ihr mich alle braucht, kommt ihr hierher und sucht mich! Na, mir egal!"

    # say L308 mo2
    old "I said get out!"
    new "Ich habe gesagt, raus hier!"

    # say L317 pla
    old "Now where I'm going to find a job?"
    new "Und wo soll ich jetzt Arbeit finden?"

    # say L318 pla
    old "Wait, what is that sound? It comes from the livingroom..."
    new "Warte, was ist das für ein Geräusch? Es kommt aus dem Wohnzimmer..."

    # say L333 pla
    old "Oh, [mo1rel]? A- Are you fine?"
    new "Oh, [mo1rel]? Geht es dir gut?"

    # say L336 pla
    old "Are you crying? I don't want to see you like this [mo1rel]."
    new "Weinst du? Ich will dich so nicht sehen, [mo1rel]."

    # say L337 mo1
    old "I- I know honey but it's hard... I'm feeling so sad, so lonely, I- I."
    new "Ich- Ich weiß, Schatz, aber es ist schwer... Ich fühle mich so traurig, so allein, ich- ich."

    # say L338 pla
    old "[mo1rel], you're not alone, we're here for you. I promise you I'll find a job and everything will be fine."
    new "[mo1rel], du bist nicht allein, wir sind für dich da. Ich verspreche dir, ich werde einen Job finden und alles wird gut werden."

    # say L339 mo1
    old "I'm sorry, it's just that it's a bunch of things, I would like to solve our monetary issues without putting pressure on you or your [sisrel]..."
    new "Es tut mir leid, es ist nur so viel auf einmal. Ich würde gerne unsere finanziellen Probleme lösen, ohne dich oder deinen [sisrel] unter Druck zu setzen..."

    # say L340 mo1
    old "And... I have to admit... I really miss her... It's been hard to be without her."
    new "Und... ich muss gestehen... ich vermisse sie wirklich... Es war schwer, ohne sie zu sein."

    # say L342 pla
    old "We'll do whatever it takes to make you feel better."
    new "Wir werden alles tun, was nötig ist, um dir zu helfen."

    # say L343 mo1
    old "The only thing that would make me feel better is... Argh!"
    new "Die einzige Sache, die mich besser fühlen lassen würde, ist... Argh!"

    # say L345 mo1
    old "This is hard, you know... It's really hard to feel so helpless, I feel my hands are tied and there is nothing I can do."
    new "Das ist schwer, wissen Sie... Es ist wirklich schwer, sich so hilflos zu fühlen, ich habe das Gefühl, meine Hände sind gebunden und ich kann nichts tun."

    # say L346 pla
    old "I'm so so sorry."
    new "Es tut mir so leid."

    # say L348 mo1
    old "I'll rest for now... I can barely talk..."
    new "Ich ruhe mich jetzt aus... Ich kann kaum noch sprechen."

    # say L349 pla
    old "Yes [mo1], just go and try to rest. I'll take care of this."
    new "Ja [mo1], geh und versuch dich auszuruhen. Ich kümmere mich darum."

    # say L350 mo1
    old "See you hun, thanks for being so good..."
    new "Bis später, Schatz, danke, dass du so ein guter Junge bist..."

    # say L355 pla
    old "My [mo1rel] doesn't deserve this, I'll insist to [mo2], she has to help me..."
    new "Meine [mo1rel] verdient das nicht, ich werde darauf bestehen, dass [mo2] mir hilft..."

    # say L356 pla
    old "It doesn't matter what I have to do to get that job... I don't want to see my [mo1rel] so depressed and worried."
    new "Es spielt keine Rolle, was ich tun muss, um diesen Job zu bekommen... Ich will nicht sehen, wie meine [mo1rel] so niedergeschlagen und besorgt ist."

    # say L357 pla
    old "I wish I could help her to come back with [mo2], it is obvious how much she misses her..."
    new "Ich wünschte, ich könnte ihr helfen, mit [mo2] zurückzukommen, es ist offensichtlich, wie sehr sie sie vermisst."

    # say L374 mo2
    old "This is absurd! What happened to the delivery boy?"
    new "Das ist ja lächerlich! Was ist mit dem Lieferjungen passiert?"

    # say L375 aki
    old "I- I'm calling him, but he doesn't answer."
    new "Ich rufe ihn an, aber er meldet sich nicht."

    # say L376 mo2
    old "What? It's incredible how useless everyone in this company is... What am I paying these people for!?"
    new "Was? Es ist unglaublich, wie nutzlos alle in diesem Unternehmen sind... Wofür bezahle ich diese Leute eigentlich!?"

    # say L377 mo2
    old "We should have sent those documents hours ago... "
    new "Wir hätten diese Unterlagen schon vor Stunden schicken sollen..."

    # say L383 pla
    old "[mo2]? Hi..."
    new "[mo2]? Hallo..."

    # say L385 mo2
    old "Argh! Again you..."
    new "Argh! Wieder Sie..."

    # say L387 mo2
    old "Akita, I'm waiting for an answer, what happened to the delivery boy? Can we get another one? I need you to solve this fucking issue NOW!"
    new "Akita, ich warte auf eine Antwort, was ist mit dem Lieferjungen passiert? Können wir einen anderen bekommen? Ich brauche, dass du dieses beschissene Problem sofort löst!"

    # say L388 aki
    old "It would be hard to find another one right now, it's pretty late and the Mayor's office is waiting for those documents. I don't know  Mrs. [mo2]."
    new "Es wäre schwierig, jetzt noch einen zu finden. Es ist ziemlich spät und das Büro des Bürgermeisters wartet auf diese Dokumente. Ich weiß es nicht, Mrs. [mo2]."

    # say L389 mo2
    old "You don't kno-?"
    new "Sie wissen nicht?"

    # say L390 pla
    old "I- I could d- deliver t- those d- documents..."
    new "Ich... ich könnte die Dokumente überbringen..."

    # say L392 mo2
    old "Are you fucking kidding me!? You're an idiot, I won't trust you with those things, just get out, I told you I don't want you here..."
    new "Spinnen Sie?! Sie sind ein Idiot, ich vertraue Ihnen da nicht, verschwinden Sie einfach, ich hab Ihnen doch gesagt, dass ich Sie hier nicht will..."

    # say L394 aki
    old "Mrs. [mo2]! That's actually a good idea and the only option we have if we want those documents to be delivered now."
    new "Mrs. [mo2]! Das ist tatsächlich eine gute Idee und die einzige Option, die wir haben, wenn wir diese Dokumente jetzt zustellen wollen."

    # say L396 mo2
    old "No and no! I don't want him to do anything... Akita, just find another way..."
    new "Nein und nochmal nein! Ich will nicht, dass er überhaupt etwas tut... Akita, such einfach einen anderen Weg..."

    # say L397 aki
    old "Uhh... I- I'm afraid there is no other way right now..."
    new "Uhh... Ich fürchte, es gibt im Moment keinen anderen Weg..."

    # say L398 pla
    old "I'll do it! I can do it well, I promise, please [mo2]... It's just a little help."
    new "Ich mach's! Ich kann das gut, versprochen, bitte [mo2]... Es ist nur ein bisschen Hilfe."

    # say L400 mo2
    old "Argh! FINE! Go and deliver the documents NOW! If I get to know that you did something wrong, I'll fucking kill you."
    new "Argh! FINE! Geh und bring die Dokumente jetzt sofort hin! Wenn ich erfahre, dass du was falsch gemacht hast, bringe ich dich um."

    # say L406 aki
    old "[pla], You have to take the documents to the Mayor's office, please go as fast as you can."
    new "[pla], Sie müssen die Dokumente ins Büro des Bürgermeisters bringen, bitte beeilen Sie sich."

    # say L407 pla
    old "Alright, I'm going now..."
    new "Okay, ich gehe jetzt..."

    # say L420 pla
    old "H- Hello?"
    new "H- Hallo?"

    # say L421 sop
    old "Yes, pardon me?"
    new "Ja, entschuldigung?"

    # say L422 pla
    old "Oh hi! I'm [pla], I'm coming from [mo2]'s office..."
    new "Oh hallo! Ich bin [pla], ich komme aus [mo2]s Büro..."

    # say L423 sop
    old "Hello! I'm Amy, nice meeting you."
    new "Hallo! Ich bin Amy, nett dich kennenzulernen."

    # say L424 sop
    old "Do you have the documents? Let me see them, please."
    new "Hast du die Unterlagen? Lass sie mal sehen, bitte."

    # say L426 pla
    old "Yes, here they are..."
    new "Ja, hier sind sie..."

    # say L428 sop
    old "Perfect... You came just in time, we were waiting for them."
    new "Perfekt... Du bist gerade noch rechtzeitig gekommen, wir haben auf sie gewartet."

    # say L430 pla
    old "Well... Guess that's it... Thank you."
    new "Na ja... Das wär's dann... Danke."

    # say L436 sop
    old "Huh! One more thing! Tell [mo2] that everything is in order and that we'll call her back."
    new "Huh! Noch was! Sag [mo2], dass alles in Ordnung ist und wir sie zurückrufen werden."

    # say L437 pla
    old "Alright, have a nice day."
    new "Alles klar, hab einen schönen Tag."

    # say L438 sop
    old "Bye! See ya."
    new "Tschüss! Bis dann."

    # say L440 pla
    old "Alright, I think that was easier than I expected. Now it's time to go back to [mo2]'s office."
    new "Okay, das war einfacher als gedacht. Jetzt muss ich zurück ins Büro von [mo2]."

    # say L460 pla
    old "H- Hello A- Akita..."
    new "H- Hallo A- Akita..."

    # say L462 pla
    old "(I can't even focus...)"
    new "Ich kann mich nicht mal konzentrieren..."

    # say L463 pla
    old "Good... I delivered everything."
    new "Gut... Ich habe alles geliefert."

    # say L469 aki
    old "So apparently you did a good job..."
    new "Scheint so, als hättest du gute Arbeit geleistet..."

    # say L470 pla
    old "Y- Yeah... Well, I delivered the documents and the girl said it was fine and that it was in time, so I guess, yeah..."
    new "Y-Yeah... Also, ich habe die Dokumente abgegeben und das Mädchen hat gesagt, es wäre in Ordnung und pünktlich, also, ja..."

    # say L471 aki
    old "I know, I know... And... Hmm."
    new "Ich weiß, ich weiß... Und... Hmm."

    # say L472 pla
    old "Yeah? What happened? Did I do anything wrong?"
    new "Ja? Was ist passiert? Hab ich was falsch gemacht?"

    # say L473 aki
    old "Well... Hmm, not here but... Did you notice what you have down there?"
    new "Na ja... Hmm, nicht hier aber... Hast du bemerkt, was du da unten hast?"

    # say L474 pla
    old "What? What do you mea-"
    new "Was? Was meinst du-"

    # say L476 pla
    old "Argh fuck! I- I don't kno- I- I h- have to go."
    new "Argh fuck! I- Ich weiß nicht, ich- ich muss los."

    # say L493 mo2
    old "You better have done it right!"
    new "Du hast es besser richtig gemacht!"

    # say L494 pla
    old "Y- yes [mo2], I- I did everything... S- She said she will call-"
    new "Y- ja [mo2], ich hab alles gemacht... S- sie hat gesagt, sie ruft an-"

    # say L495 mo2
    old "What's wrong with you? Why are you acting so weird?"
    new "Was ist los mit dir? Warum benimmst du dich so komisch?"

    # say L496 pla
    old "M- me? Uhh, no... Nothing..."
    new "M- mir? Uhh, nein... Nichts..."

    # say L497 mo2
    old "What do you have on your hands? Why are you acting like a freak? You idiot! Tell me what have you done?"
    new "Was hast du an deinen Händen? Warum benimmst du dich wie ein Freak? Du Idiot! Sag mir, was du angestellt hast!"

    # say L499 pla
    old "[mo2] I have done nothing... I don't know what you're talking about..."
    new "[mo2] Ich habe nichts getan... Ich weiß nicht, wovon du redest..."

    # say L500 mo2
    old "You're not gonna fool me... Let me see your hands now! What are you hiding?"
    new "Du wirst mich nicht hinters Licht führen... Zeig mir jetzt deine Hände! Was versteckst du?"

    # say L502 mo2
    old "What the fuck!? You are a fucking pervert!"
    new "Was zum Teufel!? Sie sind ein verdammter Perversling!"

    # say L504 mo2
    old "Why do you have a fucking boner right now?"
    new "Warum hast du jetzt einen verdammten Ständer?"

    # say L505 pla
    old "[mo2]... I- I c- can explai-"
    new "[mo2]... I- Ich k- kann das erklären-"

    # say L506 mo2
    old "Explain what?"
    new "Was soll das heißen?"

    # say L507 mo2
    old "That you got fucking horny and now you're having a BONER IN FRONT OF ME!?"
    new "Dass du geil geworden bist und jetzt einen STAND HAST VOR MIR!?"

    # say L508 pla
    old "N- not r- really..."
    new "N- nicht w- wirklich..."

    # say L509 mo2
    old "Bullcrap!"
    new "Quatsch!"

    # say L511 mo2
    old "I've had a pretty shitty day and now this... BUT! You'll see... Little motherfucker... You'll see!"
    new "Ich hab' schon einen beschissenen Tag und jetzt das... ABER! Du wirst sehen... kleiner Scheißer... Du wirst sehen!"

    # say L512 pla
    old "W- What? "
    new "W- Was?"

    # say L513 mo2
    old "Get on the floor... NOW!"
    new "Auf den Boden... JETZT!"

    # say L514 pla
    old "O- On t- the f- floor? W- why?"
    new "O- Auf d- dem B- Boden? W- warum?"

    # say L515 mo2
    old "I've given you an order! Do it, you are a stupid pervert... Do what I'm telling you and do it now."
    new "Ich habe Ihnen einen Befehl gegeben! Machen Sie, Sie sind ein dummer Perversling... Tun Sie, was ich sage, und tun Sie es jetzt."

    # say L516 pla
    old "(Oh fuck!)"
    new "Oh Scheiße!"

    # say L517 mo2
    old "Your knees on the floor NOW!"
    new "Auf den Boden mit deinen Knien JETZT!"

    # say L518 pla
    old "A- alright... Uhh."
    new "A- okay... Uhh."

    # say L522 mo2
    old "I'll have fun with you... You get horny here... I give you shit!"
    new "Ich werde mich mit dir amüsieren... Du wirst hier geil... Ich gebe dir die Hölle!"

    # say L523 mo2
    old "You will suck my foot!"
    new "Du wirst meinen Fuß lutschen!"

    # say L524 pla
    old "W- what!? Do you want me to suck you-"
    new "W-was!? Willst du, dass ich-"

    # say L525 mo2
    old "WHAT? WHY are you questioning me? I've just said, SUCK MY FOOT!"
    new "WAS? WARUM stellen Sie meine Anweisungen in Frage? Ich habe doch gerade gesagt, LUSTERN SIE MEINEN FUSS!"

    # say L543 mo2
    old "Go! Disappear from here... I don't want to see you."
    new "Verschwinde! Ich will dich hier nicht mehr sehen."

    # say L544 pla
    old "B- but what about the job? Can I c- come back?"
    new "A- aber was ist mit der Arbeit? K- kann ich wiederkommen?"

    # say L545 mo2
    old "Yes, whatever... Just go away."
    new "Ja, was auch immer... Geh einfach."

    # say L546 pla
    old "S- So am I hired?"
    new "S- So bin ich eingestellt?"

    # say L547 mo2
    old "Are you stupid or what? I just said YES! Now, GET OUT!"
    new "Sind Sie dumm oder was? Ich hab doch gerade JA gesagt! Jetzt ab mit Ihnen!"

    # say L552 pla
    old "Fuck! That was weird..."
    new "Scheiße! Das war seltsam..."

    # say L569 pla
    old "Oh, hi [mo1rel], how are you? A bit better?"
    new "Oh, hallo [mo1rel], wie geht es dir? Ein bisschen besser?"

    # say L570 mo1
    old "Hi honey, I'm ok... Not that good but I guess I'll be fine eventually..."
    new "Hallo Schatz, mir geht es okay... Nicht besonders gut, aber ich denke, ich werde irgendwann wieder auf die Beine kommen."

    # say L571 mo1
    old "I'm still worried about our economic situation..."
    new "Ich mache mir immer noch Sorgen um unsere finanzielle Situation..."

    # say L573 mo1
    old "A job? How? Where are you working?"
    new "Eine Arbeit? Wie? Wo arbeitest du?"

    # say L574 pla
    old "Hmm... I'm working in [mo2]'s office... Basically, I just started but yeah... It's good that I'll have some money to help..."
    new "Hmm... Ich arbeite in [mo2]s Büro... Eigentlich hab ich erst angefangen, aber ja... Es ist gut, dass ich jetzt etwas Geld habe, um dir zu helfen..."

    # say L575 mo1
    old "[mo2]? Are you serious?"
    new "[mo2]? Im Ernst?"

    # say L576 pla
    old "Yes, she gave me a chance to work for her..."
    new "Ja, sie hat mir die Chance gegeben für sie zu arbeiten..."

    # say L578 mo1
    old "And... Is she fine? Hmm, has she asked for me or anything...?"
    new "Und... Geht es ihr gut? Hmm, hat sie nach mir gefragt oder so...?"

    # say L579 pla
    old "She's fine [mo1rel]... You know, I haven't really talked much to her..."
    new "Sie geht es gut [mo1rel]... Du weißt, ich habe nicht viel mit ihr gesprochen..."

    # say L580 mo1
    old "Ok... Yeah, I assume she's fine... Probably better than me..."
    new "Ok... Ja, ich nehme an, es geht ihr gut... Wahrscheinlich besser als mir..."

    # say L583 mo1
    old "Honey, go get some rest... I guess you've been tired since you started working..."
    new "Schatz, geh ein bisschen schlafen... Ich denke, du bist schon seit du angefangen hast zu arbeiten müde."

    # say L584 pla
    old "Kinda, today it's been a very long and hard day... I'm gonna head to my room."
    new "Ja, heute war es ein sehr langer und harter Tag... Ich geh jetzt in mein Zimmer."

    # say L585 mo1
    old "I imagine how hard it is working with her..."
    new "Ich stelle mir vor, wie schwer es ist, mit ihr zu arbeiten..."

    # say L586 pla
    old "(Well... It was hard, quite literally...)"
    new "Na ja... es war hart, ziemlich wörtlich genommen."

    # say L587 pla
    old "If you need anything just tell me, ok? Love you [mo1rel]."
    new "Wenn du was brauchst, sag Bescheid, ok? Ich liebe dich [mo1rel]."

    # say L589 mo1
    old "Bye honey, love you too."
    new "Tschüss Schatz, ich liebe dich auch."

    # say L595 pla
    old "Hmm, [mo1rel] is feeling really sad for [mo2]..."
    new "Hmm, [mo1rel] fühlt sich wirklich traurig für [mo2]..."

    # say L596 pla
    old "And the worst part is that she misses her a lot but [mo2] doesn't even ask for her."
    new "Und das Schlimmste ist, dass sie sie sehr vermisst, aber [mo2] fragt nicht einmal danach."

    # say L597 pla
    old "I should find the way to talk with [mo2] about my [mo1rel]... I'll see."
    new "Ich sollte einen Weg finden, mit [mo2] über meine [mo1rel] zu reden... Mal sehen."

    # say L603 pla
    old "Hey Kylee! What's up?"
    new "Hey Kylee! Was ist los?"

    # say L604 sis
    old "I'm great. What about You?"
    new "Ich bin super. Und du?"

    # say L605 pla
    old "Well, I got a job!"
    new "Na, ich habe einen Job bekommen!"

    # say L606 sis
    old "Cool, finally man! What's it about?"
    new "Cool, endlich Mann! Worum geht's?"

    # say L607 pla
    old "That's the not so cool part... I'm working with [mo2]..."
    new "Das ist der weniger coole Teil... Ich arbeite mit [mo2]..."

    # say L608 sis
    old "[mo2]? Really?... But that woman hates you..."
    new "[mo2]? Wirklich?... Aber die Frau hasst dich..."

    # say L609 sis
    old "What are you doing for her?"
    new "Was machst du für sie?"

    # say L611 pla
    old "Hmm... Just l- like... delivery guy...."
    new "Hmm... Einfach wie... Lieferant...."

    # say L612 sis
    old "I see... Well you have talent for that, don't you? Hahaha. "
    new "Ich seh's... Na, da hast du ja Talent drfür, oder? Hahaha."

    # say L613 pla
    old "Yeah, so funny... "
    new "Ja, total witzig..."

    # say L614 sis
    old "At least you finally got a job."
    new "Zumindest hast du endlich einen Job gefunden."

    # say L615 pla
    old "Hmm, I know... I know..."
    new "Hmm, ich weiß... ich weiß..."

    # say L616 pla
    old "Today was a really weird day, I need some rest, see you."
    new "Heute war echt ein komischer Tag, ich brauch jetzt erst mal Ruhe, bis dann."

    # say L617 sis
    old "I believe you, Hahaha, see you."
    new "Ich glaube dir, Hahaha, bis dann."

    # say L635 aki
    old "Hi [pla], how's it going?"
    new "Hi [pla], wie läuft's?"

    # say L636 pla
    old "Hello Akita, all good... Getting involved in the job."
    new "Hallo Akita, alles gut... Ich bin gerade in die Arbeit eingestiegen."

    # say L637 aki
    old "Oh great, so are you ready to start with the new deliveries?"
    new "Oh toll, bist du dann bereit, mit den neuen Lieferungen anzufangen?"

    # say L638 pla
    old "Yeah, please explain to me what I have to do."
    new "Klar, erklär mir einfach, was ich machen muss."

    # say L639 aki
    old "Well, it really is very simple, at the moment we must send correspondence from some projects to three specific places."
    new "Na ja, es ist wirklich sehr einfach, im Moment müssen wir Korrespondenz von einigen Projekten an drei bestimmte Orte schicken."

    # say L641 aki
    old "They all have a different format depending on where they should go."
    new "Sie haben alle ein unterschiedliches Format, je nachdem, wohin sie gehen sollen."

    # say L642 aki
    old "For example, all mayoral documents have a red border."
    new "Zum Beispiel, alle Bürgermeisterdokumente haben einen roten Rand."

    # say L643 aki
    old "While the documents that go to the bank are green."
    new "Während die Dokumente für die Bank grün sind."

    # say L644 aki
    old "And finally the yellow documents for the factory."
    new "Und schließlich die gelben Dokumente für die Fabrik."

    # say L646 pla
    old "Red, green and yellow, got it."
    new "Rot, grün und gelb, verstanden."

    # say L647 aki
    old "It shouldn't be difficult at all, you just need to send them quickly to reach all the deliveries of the day."
    new "Das sollte überhaupt kein Problem sein, du musst sie nur schnell schicken, damit alle Lieferungen des Tages erreicht werden."

    # say L648 aki
    old "Anyway if you need anything else just let me know."
    new "Jedenfalls, wenn du noch was brauchst, lass es mich wissen."

    # say L649 pla
    old "Alright, thank you."
    new "Alles klar, danke."

    # say L650 aki
    old "So? Are you ready to start the deliveries?"
    new "So? Sind Sie bereit, mit den Lieferungen zu beginnen?"

    # say L651 pla
    old "Sure! Let's do it."
    new "Klar! Lass uns anfangen."

    # say L662 mo2
    old "So do you think I'm paying to do a shitty job? Is that what you think?"
    new "Glauben Sie etwa, ich zahle, damit Sie eine miserable Arbeit leisten? Ist das Ihr Ernst?"

    # say L663 pla
    old "No! No [mo2]! I'm sorry... I'm still learning but I promise I'll do it better."
    new "Nein! Nein [mo2]! Es tut mir leid... Ich lerne noch, aber ich verspreche, dass ich es besser machen werde."

    # say L664 mo2
    old "You're an idiot... I seriously doubt you'll do it better..."
    new "Sie sind ein Idiot... Ich bezweifle ernsthaft, dass Sie es besser machen werden."

    # say L665 mo2
    old "I can let this go... You gotta learn a lesson out of this."
    new "Ich lasse das noch mal durchgehen... Aber du musst daraus lernen."

    # say L666 pla
    old "A- A l- lesson? But I just started working with you..."
    new "A- A Lektion? Aber ich hab doch erst angefangen mit dir zu arbeiten..."

    # say L667 mo2
    old "And now you're questioning my decisions... You better change that fucking shitty behavior or you'll suffer in this office."
    new "Und jetzt hinterfragst du meine Entscheidungen... Du solltest besser dieses beschissene Verhalten ändern, sonst wirst du in diesem Büro leiden."

    # say L668 mo2
    old "Do you understand that?"
    new "Verstehen Sie das?"

    # say L670 mo2
    old "DO YOU? I'm asking..."
    new "VERSTEHEN SIE? Ich frage..."

    # say L671 pla
    old "Y- Yeah... I do."
    new "Y- Ja... ich verstehe."

    # say L672 mo2
    old "Good! Now get on the floor... You'll see what it's like not doing a good job for me..."
    new "Gut! Jetzt auf den Boden... Du wirst sehen, wie sich das anfühlt, wenn du deinen Job bei mir nicht gut machst..."

    # say L680 mo2
    old "I guess lastime wasn't enough for you... You deserve to be on the floor where you belong!"
    new "Ich schätze, letztes Mal war nicht genug für dich... Du verdienst es, auf dem Boden zu sein, wo du hingehörst!"

    # say L681 mo2
    old "You're my little bitch on the floor... Waiting for me to feed you."
    new "Sie sind mein kleines Miststück auf dem Boden... Auf mich warten, bis ich Sie füttere."

    # say L683 mo2
    old "That's how you should be treated, like the cockroach that you are!"
    new "So sollten Sie behandelt werden, wie das Mistkäferchen, das Sie sind!"

    # say L687 mo2
    old "You got a hardon?! Ughh... That's disgusting!"
    new "Sie haben eine Erektion?! Ughh... Das ist widerlich!"

    # say L691 mo2
    old "Alright, if this is what a pervert wants, maybe I should use other methods of punishment."
    new "Na gut, wenn das ist, was ein Perverser will, sollte ich vielleicht andere Strafmethoden anwenden."

    # say L692 mo2
    old "Let's see if this teaches you a lesson!"
    new "Lass mal sehen, ob das dir eine Lehre sein wird!"

    # say L703 pla
    old "[mo2]? Hmm, I- I wanted to tell you something..."
    new "[mo2]? Hmm, ich- ich wollte dir was sagen..."

    # say L704 mo2
    old "Be quick and get out from here!"
    new "Schnell, verschwinde hier!"

    # say L705 pla
    old "It's about my [mo1rel], you know she has been asking for you... I don't know if maybe you could call her or you know... Something."
    new "Es geht um meine [mo1rel], du weißt schon, sie fragt ständig nach dir... Ich weiß nicht, ob du vielleicht mit ihr sprechen könntest oder so..."

    # say L706 mo2
    old "Oh gosh! Really?"
    new "Oh Gott! Wirklich?"

    # say L707 mo2
    old "I won't talk to her."
    new "Ich werde nicht mit ihr sprechen."

    # say L708 mo2
    old "Now just get out idiot! I feel gross just by seeing you."
    new "Jetzt raus mit dir, Idiot! Mir wird schlecht, wenn ich dich sehe."

    # say L714 pla
    old "What am I doing?"
    new "Was mache ich hier?"

    # say L715 pla
    old "[mo2] is crazy... I can't keep doing whatever she wants."
    new "[mo2] ist verrückt... Ich kann nicht immer machen, was sie will."

    # say L732 pla
    old "Hello Akita, all good..."
    new "Hallo Akita, alles gut..."

    # say L733 aki
    old "Great! You know what you've to do... So just let me know if you need help."
    new "Super! Du weißt, was du zu tun hast... Sag Bescheid, wenn du Hilfe brauchst."

    # say L738 pla
    old "I would like to know if all the documents that must be sent today are ready?"
    new "Ich würde gerne wissen, ob alle Dokumente, die heute geschickt werden müssen, bereit sind?"

    # say L739 aki
    old "Hmm, There are still several documents missing that [mo2] must sign, if you come in the afternoon I will have them ready for you."
    new "Hmm, es fehlen noch einige Dokumente, die [mo2] unterschreiben muss. Wenn du am Nachmittag kommst, habe ich sie für dich bereit."

    # say L741 aki
    old "Great, see you later."
    new "Super, bis später."

    # say L746 aki
    old "Yes, I got all of them."
    new "Ja, ich hab sie alle."

    # say L747 pla
    old "Oh, perfect."
    new "Oh, perfekt."

    # say L754 pla
    old "Could you please explain to me again the what I have to do."
    new "Kannst du mir das noch mal erklären, was ich machen soll."

    # say L755 aki
    old "Sure, it's very simple, at the moment we must send correspondence from some projects to three specific places."
    new "Klar, es ist sehr einfach, im Moment müssen wir Korrespondenz von einigen Projekten an drei bestimmte Orte schicken."

    # say L758 aki
    old "For example, all documents sent to the mayor or his office have a red frame."
    new "Zum Beispiel, alle Dokumente, die an den Bürgermeister oder sein Büro geschickt werden, haben einen roten Rand."

    # say L761 pla
    old "Red, green and yellow, got it, "
    new "Rot, grün und gelb, verstanden."

    # say L804 aki
    old "Wow, You're good at this!"
    new "Wow, du bist gut darin!"

    # say L805 pla
    old "Haha, thanks! I'm doing my best..."
    new "Haha, danke! Ich geb mein Bestes..."

    # say L806 aki
    old "Good job, keep it up!"
    new "Gute Arbeit, mach so weiter!"

    # say L807 pla
    old "I've to... You know how [mo2] is..."
    new "Ich muss... Du weißt schon, wie [mo2] ist..."

    # say L808 aki
    old "Yeah, I totally understand."
    new "Klar, ich verstehe total."

    # say L809 pla
    old "Hey, do you know if I can talk to [mo2]?"
    new "Hey, weißt du, ob ich mit [mo2] reden kann?"

    # say L810 aki
    old "Uhh, well she is busy all the time, I don't think I will attend to you, unless it's to scold or punish you..."
    new "Uhh, na ja, sie ist die ganze Zeit beschäftigt, ich glaube nicht, dass ich mich um dich kümmern werde, es sei denn, um dich zu tadeln oder zu bestrafen..."

    # say L811 pla
    old "Hmm, right... Ok, thank you Akita."
    new "Hmm, klar... Okay, danke Akita."

    # say L812 aki
    old "Have a good day [pla]."
    new "Einen schönen Tag noch [pla]."

    # say L814 pla
    old "Hmm maybe, I shouldn't be so good at this, if I want to have the chance to speak with [mo2] whenever she calls me to her office..."
    new "Hmm, vielleicht sollte ich das nicht so gut machen, wenn ich die Chance haben will, mit [mo2] zu sprechen, wann immer sie mich in ihr Büro ruft..."

    # say L815 pla
    old "Maybe if I do bad work, [mo2] will call me to break my balls and I'll get the chance to talk to her about [mo1rel]..."
    new "Vielleicht wenn ich schlechte Arbeit leiste, wird [mo2] mich rufen, um mir die Eier zu brechen, und ich habe die Chance, mit ihr über [mo1rel] zu reden..."

    # say L816 pla
    old "Oh man, I'm sure I will regret this."
    new "Oh Mann, ich bin sicher, ich werde das bereuen."

    # say L829 aki
    old "Hmm... Sorry [pla], I hope next time you can do it better."
    new "Hmm... Tut mir leid [pla], ich hoffe, beim nächsten Mal machst du es besser."

    # say L830 pla
    old "Argh! Yes... I'll be more focused next time, sorry."
    new "Argh! Ja... Ich werde mich beim nächsten Mal mehr konzentrieren, sorry."

    # say L831 aki
    old "It's fine, just do your best because you know how [mo2] is, she'll give you shit if you keep failing."
    new "Ist schon gut, mach einfach dein Bestes, du weißt ja, wie [mo2] ist, sie wird dir die Hölle heiß machen, wenn du weiter versagst."

    # say L834 pla
    old "Gulp, I guess it's time."
    new "Na ja, dann ist es wohl so weit."

    # say L835 aki
    old "Good luck..."
    new "Viel Glück..."

    # say L857 mo2
    old "I know you were stupid but I didn't imagine this much."
    new "Ich wusste, dass Sie dumm waren, aber so dumm hätte ich Sie mir nicht vorgestellt."

    # say L858 pla
    old "Listen, I- I know I did wrong again but... I- I am sorry [mo2]."
    new "Hör zu, ich- ich weiß, ich hab wieder was falsch gemacht, aber... ich- ich bin sorry [mo2]."

    # say L859 pla
    old "I'll be more careful next time."
    new "Ich werde vorsichtiger sein."

    # say L860 mo2
    old "Yeah... Whatever... I don't care about the next time..."
    new "Ja... Was auch immer... Mir ist es egal, was danach kommt..."

    # say L861 mo2
    old "Now you gotta pay for this one."
    new "Jetzt müssen Sie dafür bezahlen."

    # say L862 pla
    old "A- Again?"
    new "Wieder?"

    # say L863 mo2
    old "I have done some stuff wrong with you..."
    new "Ich habe bei dir schon einige Fehler gemacht..."

    # say L864 mo2
    old "You shouldn't get so much pleasure for all mistakes you've done here..."
    new "Sie sollten nicht so viel Vergnügen aus all den Fehlern ziehen, die Sie hier gemacht haben..."

    # say L866 mo2
    old "You have been a lucky idiot!"
    new "Sie waren ein Glückspilz!"

    # say L867 mo2
    old "But not anymore!"
    new "Aber nicht mehr!"

    # say L869 mo2
    old "I should get something in return for hiring such a stupid person... And for still paying you."
    new "Ich sollte etwas dafür bekommen, so eine dumme Person eingestellt zu haben... Und dafür, dass ich Sie immer noch bezahle."

    # say L870 mo2
    old "You have been the worst employee I have ever had... The most useless person I have worked with. You're disgusting."
    new "Sie waren der schlechteste Mitarbeiter, den ich je hatte... Die nutzloseste Person, mit der ich je gearbeitet habe. Sie sind widerlich."

    # say L872 mo2
    old "What kind of punishment should I give you this time?"
    new "Welche Art von Strafe soll ich dir dieses Mal geben?"

    # say L873 mo2
    old "I definitely did wrong giving you pleasure, an idiot like you will only learn the hard way."
    new "Ich habe definitiv falsch gehandelt, indem ich dir Vergnügen bereitet habe. Ein Idiot wie du wird nur durch harte Strafen lernen."

    # say L874 mo2
    old "Then perhaps the best thing is that this time you are the one who gives pleasure, like the useless little bitch you are."
    new "Dann ist vielleicht das Beste, dass du dieses Mal diejenige bist, die Vergnügen verschafft, so wie es sich für ein nutzloses kleines Miststück gehört."

    # say L875 mo2
    old "I know! Come here!"
    new "Ich weiß! Komm her!"

    # say L883 mo2
    old "You'll lick my pussy... Let's see if you can do it well or you're completely useless..."
    new "Du wirst meine Pussy lecken... Lass uns sehen, ob du es gut kannst oder völlig nutzlos bist..."

    # say L884 pla
    old "W- WHAT? Y- Your puss-"
    new "W- WAS? Y- Deine Mus-"

    # say L885 mo2
    old "I don't understand why you keep talking... More licking and less talking. You're my bitch, remember?"
    new "Ich verstehe nicht, warum du immer weiter redest... Mehr lecken und weniger reden. Du bist meine Hure, das weißt du doch?"

    # say L901 pla
    old "Well, it's about [mo1], she-"
    new "Na ja, es geht um [mo1], sie-"

    # say L902 mo2
    old "Ohh come on, you again with that?"
    new "Ohh komm schon, Sie wieder mit demselben Thema?"

    # say L903 mo2
    old "I don't care! Don't waste my time with this bullshit."
    new "Mir egal! Verschwend nicht meine Zeit mit diesem Scheiß."

    # say L904 mo2
    old "I'm not going to pay again for all of you leechers..."
    new "Ich werde nicht noch einmal für euch alle Parasiten bezahlen..."

    # say L905 pla
    old "No, isn't about paying-"
    new "Nein, es geht nicht ums Bezahlen-"

    # say L906 mo2
    old "Just go away."
    new "Gehen Sie einfach."

    # say L912 pla
    old "Hmm, this is not working..."
    new "Hmm, das funktioniert nicht..."

    # say L929 sis
    old "[pla], [mo1rel] has been locked in her room all day long."
    new "[pla], [mo1rel] sitzt schon den ganzen Tag in ihrem Zimmer fest."

    # say L931 sis
    old "Yes... She's so depressed..."
    new "Ja... Sie ist so niedergeschlagen."

    # say L932 pla
    old "This is serious... I don't know, we gotta do something."
    new "Das ist ernst... Ich weiß nicht, wir müssen was tun."

    # say L933 pla
    old "Today I told [mo2] about my [mo1rel] but you know how she is... She refuses to get in touch."
    new "Heute hab ich [mo2] von meinem [mo1rel] erzählt, aber du kennst sie ja... Sie will einfach keinen Kontakt."

    # say L934 sis
    old "She's a proud motherfucker!"
    new "Sie ist eine stolze Kuh!"

    # say L935 sis
    old "Keep insisting... My [mo1rel] can't be like this... We have to help her."
    new "Weiter dran bleiben... Meine [mo1rel] kann nicht so sein... Wir müssen ihr helfen."

    # say L936 pla
    old "I know... I will..."
    new "Ich weiß... Ich werde..."

    # say L937 pla
    old "Don't worry Kylee, we'll do something."
    new "Mach dir keine Sorgen Kylee, wir werden was tun."

    # say L939 sis
    old "I hope we do... See you, then."
    new "Ich hoffe es... Bis dann."

    # say L945 pla
    old "I definitely have to keep trying to talk with [mo2]."
    new "Ich muss definitiv weiter versuchen, mit [mo2] zu reden."

    # say L962 mo2
    old "It really seems you're a big idiot! You keep making the same mistakes..."
    new "Es scheint wirklich, dass Sie ein großer Idiot sind! Sie machen immer wieder die gleichen Fehler..."

    # say L964 mo2
    old "I assume you're already imagining how you gonna pay for it..."
    new "Ich nehme an, du bildest dir schon ein, wie du das wieder gutmachen wirst..."

    # say L965 pla
    old "(Oh God, Now what?)"
    new "Oh Gott, was jetzt?"

    # say L966 pla
    old "[mo2]... I'll try to improve, it's just that... I- I'm worried about other things and it's difficult to focus sometimes."
    new "[mo2]... Ich werd's versuchen, es ist nur... Ich- Ich mache mir Sorgen um andere Dinge und es fällt mir manchmal schwer, mich zu konzentrieren."

    # say L967 mo2
    old "I don't CARE! I don't care about your shitty life."
    new "Mir ist es egal! Mir ist es egal, was für ein beschissenes Leben du hast."

    # say L969 mo2
    old "You'll need to focus on this NOW!"
    new "Sie werden sich jetzt darauf konzentrieren!"

    # say L970 mo2
    old "Now you will do what I tell you to do! You'll do whatever I want! I'm your Master, I'm the one paying you and you'll follow my orders!"
    new "Jetzt wirst du tun, was ich dir sage! Du wirst alles machen, was ich will! Ich bin dein Meister, ich zahle dir und du wirst meinen Befehlen folgen!"

    # say L971 mo2
    old "Your job and what you do is shit! Now do what I tell you."
    new "Ihre Arbeit und was Sie machen ist Scheiße! Jetzt tun Sie, was ich Ihnen sage."

    # say L972 mo2
    old "Now is the time to pay back the money I'm paying you for all your shitty work."
    new "Jetzt ist es an der Zeit, das Geld zurückzuzahlen, das ich für deine beschissene Arbeit bezahle."

    # say L979 mo2
    old "Come on, you already know what to do."
    new "Na los, Sie wissen doch schon, was zu tun ist."

    # say L994 pla
    old "I know you don't wanna hear about my [mo1rel] but... B- But she is not ok, she keeps crying for you..."
    new "Ich weiß, du willst nichts über meine [mo1rel] hören, aber... S-Sie geht es nicht gut, sie weint ständig nach dir..."

    # say L995 pla
    old "I think she's getting depressed."
    new "Ich glaube, sie wird depressiv."

    # say L996 pla
    old "Why don't you call her? Just to... Argh!"
    new "Warum rufst du sie nicht an? Nur um... Argh!"

    # say L998 mo2
    old "Crying? Is she that bad?"
    new "Weinen? Ist es ihr so schlecht?"

    # say L999 pla
    old "I'm not lying, she's feeling like shit."
    new "Ich lüge nicht, sie fühlt sich wie Scheiße."

    # say L1000 mo2
    old "I could visi-"
    new "Ich könnte sie besuchen-"

    # say L1001 mo2
    old "No! Just stop with that bullshit... And get out..."
    new "Nein! Lassen Sie das jetzt und gehen Sie..."

    # say L1016 pla
    old "What the... W- what are you doing."
    new "Was zum... W- was machst du da."

    # say L1019 mo2
    old "Well, I knew you wouldn't learn so I'll have to use more drastic methods."
    new "Nun, ich wusste ja, dass du es nicht lernst, also werde ich härtere Methoden anwenden müssen."

    # say L1020 mo2
    old "So I'm going to give you a couple of new lessons, it seems that with you it will always have to be in the hard way."
    new "Dann werde ich dir ein paar neue Lektionen erteilen, es scheint, dass bei dir immer der harte Weg notwendig ist."

    # say L1027 mo2
    old "Alright, undress and lie on the floor."
    new "Na gut, zieh dich aus und leg dich auf den Boden."

    # say L1028 pla
    old "B- but... I- I don't-"
    new "Aber... ich... ich will nicht..."

    # say L1029 mo2
    old "Are you questioning your master's orders?"
    new "Stellen Sie Ihre Befehle infrage?"

    # say L1030 pla
    old "No, no, I'm sorry master."
    new "Nein, nein, es tut mir leid, Meister."

    # say L1031 mo2
    old "That sounds a lot better."
    new "Das klingt schon viel besser."

    # say L1044 mo2
    old "Again? Let me guess, it's about [mo1], isn't it?"
    new "Wieder? Lassen Sie mich raten, es geht um [mo1], oder?"

    # say L1045 pla
    old "Well, yes, she is-"
    new "Na ja, stimmt, sie ist-"

    # say L1046 mo2
    old "Not today, I really don't have time, I already wasted it all with you."
    new "Nicht heute, ich habe wirklich keine Zeit, ich habe sie schon alle mit dir verschwendet."

    # say L1047 mo2
    old "Maybe if you do a good job I wouldn't have to waste time with you."
    new "Vielleicht müsste ich dann nicht so viel Zeit mit dir verschwenden, wenn du deinen Job gut machen würdest."

    # say L1062 mo2
    old "What a surprise, again complaints about your work."
    new "Was für eine Überraschung, wieder Beschwerden über deine Arbeit."

    # say L1063 pla
    old "Could we start, talking about [mo1]?"
    new "Können wir anfangen, über [mo1] zu sprechen?"

    # say L1064 mo2
    old "Do you pretend to be the one who gives the orders?"
    new "Pretendieren Sie, derjenige zu sein, der die Befehle gibt?"

    # say L1065 pla
    old "No, I'm sorry, master."
    new "Nein, es tut mir leid, Meisterin."

    # say L1066 mo2
    old "That sounds so much better."
    new "Das klingt viel besser."

    # say L1067 mo2
    old "Okay, let's not waste any more time, so get naked and lie down on the floor."
    new "Okay, lassen Sie uns keine Zeit mehr verschwenden, ziehen Sie sich aus und legen Sie sich auf den Boden."

    # say L1068 pla
    old "Yes, master."
    new "Ja, Meisterin."

    # say L1081 pla
    old "[mo2]... You can hate this... Torture me if you want... B- But my [mo1rel] is really bad, she's not even eating."
    new "[mo2]... Du kannst das hassen... Foltere mich, wenn du willst... A- Aber mein [mo1rel] geht es echt schlecht, sie isst nicht mal mehr."

    # say L1083 pla
    old "Visit her, please... Make me work more if you want... But just visit her."
    new "Besuch sie, bitte... Mach mich härter arbeiten, wenn du willst... Aber besuch sie einfach."

    # say L1084 mo2
    old "Argh! Ok... Let's imagine I'll go... When should I pass by."
    new "Argh! Okay... Lassen Sie uns mal annehmen, ich gehe... Wann soll ich vorbeischauen."

    # say L1085 pla
    old "Really? Well... Let me check with her. [mo2], thanks! This will make her so happy."
    new "Wirklich? Gut... Lass mich das mit ihr abklären. [mo2], danke! Das wird sie total glücklich machen."

    # say L1086 mo2
    old "Listen little bastard! I'll go just because I wanna see if she is really that bad, not because of you. Got it?"
    new "Hör zu, kleiner Bastard! Ich gehe nur, um zu sehen, ob sie wirklich so schlimm ist, und nicht deinetwegen. Kapiert?"

    # say L1087 pla
    old "Yes, yes... T- Thanks anyway."
    new "Ja, ja... Danke trotzdem."

    # say L1089 mo2
    old "Ask her when it's a good time to swing by and I'll be there..."
    new "Frage sie, wann es ein guter Zeitpunkt ist vorbeizuschauen, und ich werde da sein..."

    # say L1090 mo2
    old "I hope you're not lying to me..."
    new "Ich hoffe, Sie lügen mich nicht an..."

    # say L1092 pla
    old "N- No."
    new "N- Nein."

    # say L1093 mo2
    old "Fuck! I'll kill you if you're lying to me."
    new "Verdammt! Ich bringe dich um, wenn du mich anlügst."

    # say L1094 mo2
    old "Alright, go away. I have to work."
    new "Na gut, verschwinde. Ich muss arbeiten."

    # say L1096 pla
    old "(At least she'll see [mo1rel]... That's something.)"
    new "Zumindest wird sie [mo1rel] sehen... Das ist schon was."

    # say L1115 pla
    old "Hi [mo1rel]! How are you?"
    new "Hi [mo1rel]! Wie geht's dir?"

    # say L1116 mo1
    old "Hi honey... I'm fine, and you?"
    new "Hi Schatz... Mir geht es gut, und dir?"

    # say L1117 pla
    old "Guess what?"
    new "Rate mal?"

    # say L1118 mo1
    old "I don't know, what happened?"
    new "Ich weiß nicht, was passiert ist?"

    # say L1119 pla
    old "[mo2] is coming to see you..."
    new "[mo2] kommt dich besuchen..."

    # say L1120 mo1
    old "What? [mo2] wants to see me? When?"
    new "Was? [mo2] will mich sehen? Wann?"

    # say L1121 pla
    old "Well, I talked to her and she said she will come whenever you want..."
    new "Na ja, ich hab mit ihr gesprochen und sie sagte, sie kommt, wann immer du willst..."

    # say L1122 mo1
    old "Oh God! That's great! Tell her to come tomorrow."
    new "Oh Gott! Das ist toll! Sag ihr, sie soll morgen kommen."

    # say L1123 mo1
    old "I'll have to wear something nice... Yes, tell her that tomorrow is fine and that I'll be waiting for her."
    new "Ich muss was Schönes anziehen... Ja, sag ihr, dass morgen gut ist und dass ich auf sie warte."

    # say L1124 pla
    old "I'll... And I'm glad you're feeling better now."
    new "Ich... Und ich freue mich, dass es dir jetzt besser geht."

    # say L1125 mo1
    old "Thanks for doing this for me..."
    new "Danke, dass Sie das für mich machen..."

    # say L1126 mo1
    old "Get some rest, honey... You've been working a lot."
    new "Ruh dich aus, Schatz... Du hast viel gearbeitet."

    # say L1127 pla
    old "Every day is harder, [mo1rel]... But it's fine as long as you're fine and less worried."
    new "Jeden Tag wird es härter, [mo1rel]... Aber solange es dir gut geht und du weniger besorgt bist, ist alles in Ordnung."

    # say L1128 pla
    old "I'm heading to my room... Love you [mo1rel]!"
    new "Ich geh in mein Zimmer... Ich liebe dich [mo1rel]!"

    # say L1147 mo2
    old "And here you are again... You are definitely a lost cause."
    new "Und hier sind Sie wieder... Sie sind definitiv ein hoffnungsloser Fall."

    # say L1148 pla
    old "I know, I know, I'm sorry..."
    new "Ich weiß, ich weiß, es tut mir leid..."

    # say L1149 pla
    old "However, I actually wanted to talk about the visit- "
    new "Aber ich wollte eigentlich über den Besuch sprechen"

    # say L1150 mo2
    old "Shut up! I give a shit about what you want. I am your master and it's time for your punishment."
    new "Halt die Klappe! Mir ist es egal, was du willst. Ich bin dein Herr und es ist Zeit für deine Strafe."

    # say L1151 mo2
    old "Get on the floor... That's your place."
    new "Auf den Boden... Das ist dein Platz."

    # say L1152 pla
    old "Come on, just a second. I don't want to do this."
    new "Komm schon, nur eine Sekunde. Ich will das nicht tun."

    # say L1153 mo2
    old "Get on the fucking floor now..."
    new "Auf den verdammten Boden, jetzt!"

    # say L1154 pla
    old "I- I'm not gonna do it... No, no more."
    new "Ich werd's nicht tun... Nein, ich mach das nicht mehr."

    # say L1155 mo2
    old "I'm telling you to get on the fucking floor!"
    new "Ich sage Ihnen, dass Sie sich jetzt auf den verdammten Boden legen sollen!"

    # say L1156 pla
    old "You can't keep doing this, it's humiliating for me."
    new "Du kannst nicht immer so weitermachen, das ist erniedrigend für mich."

    # say L1157 mo2
    old "WHAT!? What did you just say to me? Did you say NO to your Master?"
    new "Was!? Was haben Sie mir gerade gesagt? Haben Sie Nein zu Ihrem Meister gesagt?"

    # say L1162 mo2
    old "Do you think you are better than me? I have kicked bigger butts than yours!"
    new "Denken Sie, Sie sind besser als ich? Ich habe schon größere Hintern getreten als Ihren!"

    # say L1163 mo2
    old "You're getting in real trouble with me! I'm commanding you, did you get that part?"
    new "Du kommst echt in Schwierigkeiten mit mir! Ich befehle es dir, hast du das kapiert?"

    # say L1165 mo2
    old "Don't you dare to say NO to me, you obey to whatever I say because I'm your fucking master and you're nothing..."
    new "Wagen Sie es ja nicht, mir NEIN zu sagen, Sie tun, was ich sage, denn ich bin Ihr verdammter Meister und Sie sind nichts..."

    # say L1166 mo2
    old "You're my little bitch, a cockroach, my slave..."
    new "Du bist mein kleines Miststück, eine Wanze, meine Sklavin..."

    # say L1167 mo2
    old "This time you will really be punished, you must learn to obey your master."
    new "Dieses Mal wirst du wirklich bestraft, du musst lernen, deinem Meister zu gehorchen."

    # say L1183 pla
    old "Master? May I ask you something?"
    new "Meister? Darf ich dich etwas fragen?"

    # say L1184 mo2
    old "Hmm... You're learning... You're starting to understand..."
    new "Hmm... Sie lernen... Sie fangen an zu verstehen..."

    # say L1185 mo2
    old "It's good that you ask me... You don't do anything without my permission."
    new "Es ist gut, dass Sie mich fragen... Sie tun nichts ohne meine Erlaubnis."

    # say L1186 mo2
    old "Speak..."
    new "Sprechen Sie..."

    # say L1187 pla
    old "I spoke to my [mo1rel] and she said you can go and see her today... I- if you want..."
    new "Ich hab mit meiner [mo1rel] gesprochen und sie sagte, du kannst heute zu ihr kommen... W-wenn du willst..."

    # say L1188 mo2
    old "Hmm... Fine... I'm going today... Just want to get it over with..."
    new "Hmm... Gut... Ich gehe heute... Ich will es nur hinter mich bringen..."

    # say L1189 pla
    old "T- Thanks..."
    new "Danke..."

    # say L1190 mo2
    old "Alright, now get out!"
    new "Na los, jetzt raus mit dir!"

    # say L1196 pla
    old "Oh God, what just happened... At least [mo1rel] will be happy today..."
    new "Oh Gott, was ist da gerade passiert... Zumindest wird [mo1rel] heute zufrieden sein."

    # say L1197 pla
    old "I can't keep working here, I need to get away from [mo2]'s office."
    new "Ich kann hier nicht mehr arbeiten, ich muss weg von [mo2]s Büro."

    # say L1214 mo1
    old "Hi honey, how do I look?"
    new "Hi Schatz, wie sehe ich aus?"

    # say L1215 pla
    old "Wow, you look gorgeous!"
    new "Wow, du siehst fantastisch aus!"

    # say L1216 mo1
    old "Oh, really? Thank you honey..."
    new "Oh, wirklich? Danke Schatz..."

    # say L1217 mo1
    old "So? Do you have any news about [mo2]?"
    new "So? Haben Sie schon Neuigkeiten über [mo2]?"

    # say L1218 pla
    old "Uhh, yes, [mo2] is coming today... If that's what you're asking..."
    new "Uhh, ja, [mo2] kommt heute... Wenn das deine Frage war."

    # say L1219 mo1
    old "Great! I'm gonna get ready for her."
    new "Großartig! Ich werde mich für sie fertigmachen."

    # say L1220 pla
    old "I hope you enjoy seeing her... And if you need anything, just let me know, [mo1rel]..."
    new "Ich hoffe, du freust dich auf sie... Und wenn du was brauchst, sag Bescheid, [mo1rel]..."

    # say L1221 pla
    old "Now I gotta go, I need to take a nap..."
    new "Jetzt muss ich los, ich muss noch ein Nickerchen machen..."

    # say L1222 mo1
    old "Sure, take care, honey."
    new "Natürlich, pass auf dich auf, Schatz."

    # say L1230 pla
    old "(Huh? What's that noise?)"
    new "Was ist das für ein Geräusch?"

    # say L1235 pla
    old "It's on my [mo1rel]'s bedroom..."
    new "Es ist in [mo1rel]s Schlafzimmer..."

    # say L1242 pla
    old "Wow, they are having sex!"
    new "Wow, die beiden haben Sex!"

    # say L1243 pla
    old "Oh my God, I have never been so happy to see someone having sex!"
    new "Oh mein Gott, ich bin noch nie so froh gewesen, jemanden beim Sex zu sehen!"

    # say L1251 pla
    old "Fuck! This is great! I won't have to work for [mo2] anymore..."
    new "Scheiße! Das ist großartig! Ich muss nicht mehr für [mo2] arbeiten..."

    # say L1252 pla
    old "They're back together, everything will be fine and I won't have to go back to her office."
    new "Sie sind wieder zusammen, alles wird gut und ich muss nicht mehr in ihr Büro zurückkehren."

    # say L1270 pla
    old "From now on, I am free! I will no longer have to bear Jane's humiliations!"
    new "Von jetzt an bin ich frei! Ich muss Janes Demütigungen nicht länger ertragen!"

    # say L1281 pla
    old "H- Hey... [mo2], h- how are you?"
    new "H- Hallo... [mo2], h- wie geht es dir?"

    # say L1282 mo2
    old "Don't pretend to be a good guy... I know how shitty you're and how pervert you can be."
    new "Pretendieren Sie nicht, ein guter Mensch zu sein... Ich weiß, wie mies und pervers Sie sein können."

    # say L1284 mo2
    old "I have a business trip, but I'll see you in the office in a few weeks..."
    new "Ich habe eine Geschäftsreise, aber ich sehe dich im Büro in ein paar Wochen..."

    # say L1285 pla
    old "B- But..."
    new "Aber..."

    # say L1286 mo2
    old "Excuse me!?"
    new "Entschuldigung!?"

    # say L1287 mo2
    old "Did I hear a BUT?"
    new "Haben Sie etwa „Aber“ gesagt?"

    # say L1288 mo2
    old "I thought you had already learned how you have to talk to me..."
    new "Ich dachte, Sie hätten schon gelernt, wie Sie mit mir sprechen müssen..."

    # say L1291 pla
    old "Master... May I talk to you?"
    new "Master... Darf ich mit dir sprechen?"

    # say L1292 mo2
    old "Now you can, slave."
    new "Jetzt können Sie, Sklave."

    # say L1293 pla
    old "You said that we'll see each other in the office bu-"
    new "Du hast gesagt, wir sehen uns im Büro, aber-"

    # say L1294 mo2
    old "Yes, I said it!"
    new "Ja, das habe ich gesagt!"

    # say L1295 mo2
    old "You'll do whatever I want, nothing's gonna change..."
    new "Sie werden tun, was ich will, das wird sich nicht ändern..."

    # say L1296 mo2
    old "Regardless of the situation between [mo1] and I, you'll keep obeying me... I'm your master and that won't change."
    new "Egal was zwischen [mo1] und mir läuft, Sie werden weiterhin meinen Befehlen gehorchen... Ich bin Ihr Meister und das wird sich nicht ändern."

    # say L1297 mo2
    old "Don't forget that... Now you are my bitch."
    new "Vergiss das nicht... Jetzt bist du mein Schoßhund."

    # say L1299 pla
    old "Y- Yes..."
    new "J-Ja..."

    # say L1301 pla
    old "Oh God... "
    new "Oh Gott..."


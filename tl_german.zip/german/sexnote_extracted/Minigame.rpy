# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mechanics/Minigame.rpy
translate german strings:

    # narrator L270 
    old "Drag the documents that must be sent to the right destination, do it quickly to reach all the deliveries of the day."
    new "Die Dokumente, die versandt werden müssen, zum richtigen Ziel ziehen. Mach es schnell, um alle Lieferungen des Tages zu schaffen."

    # say L311 drag_name
    old "Town Hall"
    new "Rathaus"

    # narrator L396 
    old "To fix the roof you have to drag the tiles one by one to cover the damage."
    new "Um das Dach zu reparieren, musst du die Dachziegel einzeln ziehen, um den Schaden abzudecken."

    # narrator L633 
    old "Open up the boxes two by two, and pair them up with the one equal to them."
    new "Die Kisten öffnen und die passenden Paare finden."

    # narrator L744 
    old "Try to select the profiles that are more akin to what Lydia wants. Swipe the correct ones right and the wrong ones left."
    new "Versuche, die Profile auszuwählen, die eher Lydias Wünschen entsprechen. Wisch die richtigen nach rechts und die falschen nach links."

    # narrator L746 
    old "Remember that these are some of the characteristics that Lydia doesn't like: white hair, red hair, old look and mustache."
    new "Denk daran, dass Lydia diese Eigenschaften nicht mag: weiße Haare, rote Haare, älteres Aussehen und Schnurrbart."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/shiAnimations.rpy
translate german strings:

    # say L45 pla
    old "And... Who are you?"
    new "Und... Wer bist du?"

    # say L47 dev
    old "Wow, can you see me? So it was true. Interesting... "
    new "Wow, kannst du mich sehen? Also war es wahr. Interessant..."

    # say L50 dev
    old "You are the human with Agamoto's Eye?"
    new "Du bist der Mensch mit dem Auge von Agamoto?"

    # say L51 pla
    old "Yes... and you... are you a... shinigami?"
    new "Ja... und du... bist du eine... Shinigami?"

    # say L53 dev
    old "Yes! This is the first time I've met a human."
    new "Ja! Das ist das erste Mal, dass ich einen Menschen treffe."

    # say L54 pla
    old "Ok... So, do you know the shinigami of the other night?"
    new "Ok... Kennst du die Shinigami von neulich?"

    # say L56 dev
    old "You mean Mildret?"
    new "Meinst du Mildret?"

    # say L57 pla
    old "I don't know her name, but she also sucked up my magical power..."
    new "Ich kenne ihren Namen nicht, aber sie hat auch meine magische Energie aufgesaugt..."

    # say L59 dev
    old "Yes, then you talk about Mildret  hehehe."
    new "Dann sprechen wir von Mildret, hehehe."

    # say L60 pla
    old "Are there more shinigami, besides Mildret and... you?"
    new "Gibt es noch mehr Shinigami außer Mildret und... dir?"

    # say L62 dev
    old "Yes we are only three and I am Devonne. Nice to meet you!"
    new "Ja, wir sind nur zu dritt und ich bin Devonne. Schön, dich kennenzulernen!"

    # say L63 pla
    old "Nice... to... meet... you. My name is [pla]..."
    new "Nett... dich... kennenzulernen. Mein Name ist [pla]..."

    # say L65 dev
    old "Wow, [pla]? What strange names humans have... hahaha."
    new "Wow, [pla]? Was für seltsame Namen haben Menschen... hahaha."

    # say L66 pla
    old "You're not mad at me?"
    new "Bist du nicht sauer auf mich?"

    # say L68 dev
    old "Me? No... Why would I be?"
    new "Me? Nein... Warum sollte ich?"

    # say L69 pla
    old "Because Mildret accused me of stealing magical power..."
    new "Weil Mildret mich beschuldigt hat, magische Kraft zu stehlen..."

    # say L71 dev
    old "Ohhh you mean that... Well, there has been someone who has been gathering the magical power in this area and we think it's you... Is it you?"
    new "Ohhh das meinst du... Na ja, es gibt jemanden, der hier in der Gegend magische Kraft sammelt, und wir denken, dass du es bist... Bist du es?"

    # say L72 pla
    old "Well, yes... But..."
    new "Na ja, ja... Aber..."

    # say L74 dev
    old "Ohhh... Then it's true, You are the thief... And you were starting to like me... I better go before you take away the little I recovered..."
    new "Ohhh... Dann ist es wahr, du bist der Dieb... Und du hast angefangen, mich zu mögen... Ich sollte besser gehen, bevor du mir das bisschen nimmt, das ich wiederhergestellt habe..."

    # say L77 pla
    old "No,wait!"
    new "Nein, warte!"

    # say L78 pla
    old "Hmm... Again... And they are three huh?"
    new "Hmm... Wieder... Und es sind schon drei, hm?"

    # say L98 pla
    old "So, did you get enought magic power?"
    new "So, hast du genug Magie gesammelt?"

    # say L100 dev
    old "Yeay! Thank you so much..."
    new "Ja! Danke schön..."

    # say L101 pla
    old "Don't worry, I just wanna help you..."
    new "Mach dir keine Sorgen, ich will dir nur helfen..."

    # say L103 dev
    old "You are the best!"
    new "Du bist der Beste!"

    # say L105 dev
    old "Well I have to go... Goodbye, [pla]"
    new "Na ja, ich muss los... Tschüss, [pla]"

    # say L171 pla
    old "I hoped you wouldn't steal more magical power..."
    new "Ich hatte gehofft, du würdest keine mehr stehlen..."

    # say L173 dev
    old "You destroyed the magical world!!!"
    new "Du hast die magische Welt zerstört!!!"

    # say L176 dev
    old "You are the worst being in the universe!..."
    new "Du bist das schlimmste Wesen im Universum!"

    # say L177 pla
    old "I don't understand... Why do you say that?..."
    new "Ich verstehe nicht... Warum sagst du das?"

    # say L179 dev
    old "You have already done a lot of damage, and now you want to make us disappear by talking away the magical power... Leave us alone, once and for all..."
    new "Du hast schon genug Schaden angerichtet und jetzt willst du uns auch noch das magische Kraft nehmen, indem du uns wegdiskutierst... Lass uns endlich in Ruhe..."

    # say L182 pla
    old "... What the hell?..."
    new "Was zur Hölle?..."

    # say L272 dev
    old "Oh boy, there is nothing more fun than sharing magical power."
    new "Oh Mann, es gibt nichts Schöneres als magische Kraft zu teilen."

    # say L274 pla
    old "I'm glad you feel good, you can still count on receiving magical power when you need me, you can go when you want it..."
    new "Ich freue mich, dass es dir gut geht, du kannst immer noch auf meine magische Kraft zählen, wenn du mich brauchst, du kannst jederzeit kommen, wenn du willst..."

    # say L276 dev
    old "Do not hesitate..."
    new "Zögere nicht..."

    # say L278 pla
    old "Well, I must go now, I'm glad I closed the deal and finished everything in good terms..."
    new "Na ja, ich muss jetzt los, ich bin froh, dass ich den Deal abgeschlossen und alles gut beendet habe..."

    # say L280 dev
    old "[pla], take care of Brixxida, she's not what she seems..."
    new "[pla], pass auf Brixxida auf, sie ist nicht das, was sie zu sein scheint..."

    # say L282 pla
    old "Yes, I'll be careful..."
    new "Ja, ich werde vorsichtig sein..."

    # say L306 dev
    old "Yeay! really fun... right?..."
    new "Ja, echt toll... oder?"

    # say L308 pla
    old "Haha right, it was fun."
    new "Haha stimmt, es war lustig."

    # say L310 dev
    old "Ok, I'm going to collect more magic power to do it again..."
    new "Ok, ich sammle noch mehr Magie, um es wieder zu tun..."

    # say L312 pla
    old "Just take it easy... Ok?"
    new "Lass es langsam angehen... Ok?"

    # say L421 pla
    old "(Perfect, I must use Sauron's mouth) {b}Sauron's mouth!{/b}"
    new "Perfekt, ich muss Saurons Mund benutzen {b}Saurons Mund!{/b}"

    # say L422 pla
    old "Tell me your name shinigami!"
    new "Sag mir deinen Namen, Shinigami!"

    # say L424 gom
    old "My name is Gomory..."
    new "Mein Name ist Gomory..."

    # say L426 pla
    old "Hmmm... Do you know Devonne and... Mildret? "
    new "Hmmm... Kennst du Devonne und... Mildret?"

    # say L428 gom
    old "Yes, they are two allied shinigamis..."
    new "Ja, sie sind zwei verbündete Shinigami..."

    # say L430 pla
    old "Why are you stealing magic power from me?"
    new "Warum stiehlst du mir Magie?"

    # say L432 gom
    old "You have been collecting magical power from this area, which has left us with few reserves... and soon we'll not enough to exist."
    new "Du hast hier in der Gegend magische Energie gesammelt, wodurch uns kaum noch Reserven bleiben... und bald werden wir nicht genug haben, um zu existieren."

    # say L434 gom
    old "I should go... I've said enough..."
    new "Ich sollte gehen... Ich habe schon genug gesagt..."

    # say L435 pla
    old "No, no, wait! I didn't know I was taking magic power from you..."
    new "Nein, nein, warte! Ich wusste gar nicht, dass ich dir Magie abziehe..."

    # say L438 gom
    old "Well, actually, it is not the magic power from us. It's just that there is less and less in the area."
    new "Na ja, eigentlich geht es nicht um die magische Kraft von uns. Es ist nur so, dass es in der Gegend immer weniger davon gibt."

    # say L439 gom
    old "I think we will soon cease to exist because there will be no more..."
    new "Ich denke, wir werden bald aufhören zu existieren, weil es dann nichts mehr gibt..."

    # say L442 gom
    old "And you do not need the magic power to exist..."
    new "Und du brauchst die magische Kraft nicht, um zu existieren..."

    # say L445 pla
    old "Ohhh... I understand perfectly... I didn't know... I mean, I knew it, but I didn't know you existed..."
    new "Ohhh... Ich verstehe perfekt... Ich wusste es nicht... Ich meine, ich wusste es, aber ich wusste nicht, dass du existierst..."

    # say L447 gom
    old "Well, you already know... It is not something that makes much difference. At some point all the magical power will end and we will disappear..."
    new "Na ja, du weißt schon... Es macht nicht viel Unterschied. Irgendwann wird die magische Kraft versiegen und wir werden verschwinden..."

    # say L448 pla
    old "What about the 'Chosen One'? Who will rebuild the magical world? "
    new "Was ist mit dem 'Auserwählten'? Wer wird die magische Welt wieder aufbauen?"

    # say L450 gom
    old "It's a myth... No one really thinks that will happen since years have passed... Anyway... I'm leaving..."
    new "Das ist ein Mythos... Niemand glaubt wirklich daran, seit Jahren... Jedenfalls... ich gehe..."

    # say L453 pla
    old "But... Hmm... Now I understand... I have to talk with Brixxida"
    new "Aber... Hmm... Jetzt verstehe ich... Ich muss mit Brixxida reden."

    # say L473 pla
    old "Well, did you get enough magic power?"
    new "Na, hast du genug magische Kraft bekommen?"

    # say L475 gom
    old "Yes, I have enough for now..."
    new "Ja, ich habe genug für jetzt..."

    # say L476 pla
    old "Ok, you can come anytime if you need more..."
    new "Ok, du kannst jederzeit kommen, wenn du mehr brauchst..."

    # say L478 gom
    old "Ok, thanks. I have to go."
    new "Ok, danke. Ich muss los."

    # say L543 gom
    old "Damn, you left me with too little energy..."
    new "Verdammt, du hast mich mit zu wenig Energie zurückgelassen..."

    # say L545 pla
    old "{b}Sauron's mouth!{/b}"
    new "Verdammt, {b}Saurons Mund!{/b}"

    # say L547 pla
    old "Answer me, why do you say that I destroyed the magical world?"
    new "Antworte mir, warum sagst du, dass ich die magische Welt zerstört habe?"

    # say L549 gom
    old "You are the owner of the SexNote, who destroyed the magical world..."
    new "Du bist die Besitzerin von SexNote, die die magische Welt zerstört hat..."

    # say L552 pla
    old "What? But I didn't..."
    new "Was? Aber ich hab doch nicht..."

    # say L554 pla
    old "How was the magical world destroyed? "
    new "Wie wurde die magische Welt zerstört?"

    # say L556 gom
    old "A powefull being who possessed the SexNote, performed a forbidden spell that caused the magical world to collapse..."
    new "Eine mächtige Kreatur, die den SexNote besaß, hat einen verbotenen Zauber gewirkt, der die magische Welt zusammenbrechen ließ..."

    # say L559 pla
    old "What the fuck?..."
    new "Was zum Teufel?..."

    # say L564 bri
    old "Thieves!! Stop stealing the magic power!"
    new "Diebe!! Hört auf, die magische Energie zu stehlen!"

    # say L567 gom
    old "We have little magic energy left for Mildret and me... Don't attack us anymore..."
    new "Wir haben nur noch wenig magische Energie für Mildret und mich... Hört auf, uns anzugreifen..."

    # say L569 bri
    old "You must die! I will finish you!"
    new "Ihr müsst sterben! Ich werde euch erledigen!"

    # say L573 pla
    old "What are you doing!?"
    new "Was machst du!?"

    # say L575 bri
    old "I'm trying to make them not bother you again..."
    new "Ich versuche, sie dazu zu bringen, dich in Ruhe zu lassen..."

    # say L577 pla
    old "I was getting information... You chased her away..."
    new "Ich habe Informationen gesammelt... Du hast sie verjagt..."

    # say L579 bri
    old "Sorry, I am upset about the magical power that was stolen from us..."
    new "Entschuldigung, ich bin sauer, weil uns unsere magische Kraft gestohlen wurde..."

    # say L581 pla
    old "But... Why did you do that?"
    new "Aber... Warum hast du das getan?"

    # say L583 pla
    old "Anyway, just let's go home..."
    new "Na ja, lass uns einfach nach Hause gehen..."

    # say L585 bri
    old "Ok..."
    new "Okay..."

    # say L590 pla
    old "Hmm... Things are very suspicious... I'll have to talk to Brixxida to clarify everything..."
    new "Hmm... Die Dinge sind sehr verdächtig... Ich muss mit Brixxida reden, um alles zu klären..."

    # say L608 gom
    old "Well I hope this little help you, to improve your skills..."
    new "Na ja, ich hoffe, dass diese kleine Hilfe dir hilft, deine Fähigkeiten zu verbessern."

    # say L610 pla
    old "Thank you, I really appreciate all your help."
    new "Danke, ich schätze deine Hilfe wirklich."

    # say L612 gom
    old "You're welcome, we count on you to save the magical world."
    new "Gern geschehen, wir zählen auf dich, um die magische Welt zu retten."

    # say L614 pla
    old "I'll take care of fixing everything, I promise..."
    new "Ich werde alles reparieren, das verspreche ich..."

    # say L616 gom
    old "Thank you."
    new "Danke."

    # say L676 pla
    old "What the fuck? Who are you? And What was that?!"
    new "Was zur Hölle? Wer bist du? Und was war das?!"

    # say L678 mil
    old "What? Can you see me?"
    new "Was? Kannst du mich sehen?"

    # say L679 pla
    old "Yes! Of course, I can see you..."
    new "Ja! Klar sehe ich dich..."

    # say L681 mil
    old "How the fuck can you see me? You are a simple human... "
    new "Wie zur Hölle kannst du mich sehen? Du bist doch nur ein einfacher Mensch..."

    # say L682 pla
    old "Uhh no... I think it's because I have Agamoto's eyes."
    new "Uhh nein... Ich denke, das liegt daran, dass ich Agamotos Augen habe."

    # say L684 mil
    old "What?! You have Agamoto's eyes?"
    new "Was?! Du hast die Augen von Agamoto?"

    # say L685 pla
    old "Ehh yeah... But who are you?"
    new "Ehh ja... Aber wer bist du?"

    # say L687 mil
    old "Sooo... it's you who's been stealing the magic power?!"
    new "Sooo... du bist also derjenige, der die magische Kraft stiehlt?!"

    # say L688 pla
    old "What? Stealing magic power?"
    new "Was? Magie stehlen?"

    # say L690 mil
    old "Look, I'll only warn you this once... If you keep stealing the magic power I will be forced to take extreme measures..."
    new "Schau, ich warne dich nur einmal... Wenn du weiter die magische Kraft stahlst, werde ich gezwungen sein, drastische Maßnahmen zu ergreifen..."

    # say L691 pla
    old "Extreme measures?"
    new "Extreme Maßnahmen?"

    # say L693 mil
    old "This is not a children's game... You better stop stealing the magical power."
    new "Das ist kein Kinderspiel... Du solltest besser aufhören, die magische Kraft zu stehlen."

    # say L696 pla
    old "But- wait... What?"
    new "Aber-warte... Was?"

    # say L697 pla
    old "Hmm... Will have to talk to Brixxida tomorrow..."
    new "Hmm... Muss morgen mit Brixxida reden..."

    # say L723 pla
    old "Well, did you get enough?"
    new "Na, hast du genug bekommen?"

    # say L725 mil
    old "Yes, thank you for everything..."
    new "Ja, danke für alles..."

    # say L726 pla
    old "No problem. You can come back anytime if you need more..."
    new "Kein Problem. Du kannst jederzeit wiederkommen, wenn du mehr brauchst..."

    # say L728 mil
    old "We just need a little to not disappear..."
    new "Wir brauchen nur ein bisschen, um nicht zu verschwinden..."

    # say L730 mil
    old "Anyway I will let you keep sleeping... Bye..."
    new "Jedenfalls lass ich dich weiter schlafen... Tschüss..."

    # say L798 mil
    old "Don't you see? You're a thief... And now you steal directly."
    new "Siehst du das nicht? Du bist ein Dieb... Und jetzt stehlst du direkt."

    # say L800 pla
    old "I'm not... I'm only recovering what you took away from me, Nothing more."
    new "Ich bin nicht... Ich nehme nur zurück, was du mir genommen hast. Nichts weiter."

    # say L802 mil
    old "You have been taking away all the energy in these past few days..."
    new "Du hast in den letzten Tagen all die Energie geraubt..."

    # say L804 mil
    old "You don't need it to exist..."
    new "Du brauchst es nicht, um zu existieren..."

    # say L806 pla
    old "I am the chosen one, I will be able to restore the magical world..."
    new "Ich bin der Auserwählte, ich werde die magische Welt wiederherstellen können..."

    # say L808 mil
    old "You are a simple human, you cannot do anything for the magical world..."
    new "Du bist ein einfacher Mensch, du kannst nichts für die magische Welt tun..."

    # say L810 pla
    old "I am the owner of the SexNote!..."
    new "Ich bin der Besitzer der SexNote!"

    # say L812 mil
    old "You... have... the... SexNote?..."
    new "Du... hast... das... SexNote?..."

    # say L814 pla
    old "That's right... I will rebuild the magical world..."
    new "Das stimmt... Ich werde die magische Welt wieder aufbauen..."

    # say L820 pla
    old "Wait... Hmm..."
    new "Warte... Hmm..."

    # say L840 mil
    old "Ok, I think is enought for now, right?..."
    new "Okay, ich denke, das reicht für jetzt, oder?"

    # say L842 pla
    old "Well, yes, thank you... But if you have little just left tell me."
    new "Na ja, danke... Aber wenn du noch was übrig hast, sag Bescheid."

    # say L844 mil
    old "Don't worry I'm good for now..."
    new "Keine Sorge, ich bin fürs Erste gut drauf..."

    # say L846 mil
    old "Now let me rest and recover some magic power..."
    new "Dann lass mich jetzt ausruhen und meine magische Energie wieder auffrischen..."

    # say L848 pla
    old "Ok, see you..."
    new "Okay, bis später..."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/miaAnimations.rpy
translate german strings:

    # say L7 devMia
    old "This is very different."
    new "Das ist sehr anders."

    # say L8 devMia
    old "Don’t stop."
    new "Hör nicht auf."

    # say L12 devMia
    old "I- I wasn’t expecting this. This sensation."
    new "I- Ich habe damit nicht gerechnet. Diese Empfindung."

    # say L14 devMia
    old "Oh, I’m more than ok."
    new "Oh, ich bin mehr als okay."

    # say L15 devMia
    old "Do it faster."
    new "Schneller."

    # say L19 devMia
    old "AH, yes, like that, keep going!"
    new "AH, ja, so, mach weiter!"

    # say L20 pla
    old "I- feel..."
    new "Ich- fühle..."

    # say L21 devMia
    old "Don’t stop! KEEP GOING!"
    new "Hör nicht auf! WEITER SO!"

    # say L45 pla
    old "I think I can’t hold it back anymore!"
    new "Ich glaube, ich kann es nicht mehr zurückhalten!"

    # say L46 devMia
    old "Let it go, cum inside me!"
    new "Lass es raus, spritz in mir ab!"

    # say L47 devMia
    old "I want you to give that magic power!"
    new "Ich will, dass du mir diese magische Kraft gibst!"

    # say L48 devMia
    old "Oh yes!"
    new "Oh ja!"

    # say L54 dev
    old "Oh my! That was fantastic!"
    new "Oh wow! Das war fantastisch!"

    # say L55 dev
    old "Linnet had told me about it, but this is just another level!"
    new "Linnet hatte mir davon erzählt, aber das ist einfach auf einem anderen Level!"

    # say L56 dev
    old "We have to try this again!"
    new "Wir müssen das noch mal machen!"

    # say L57 pla
    old "Are you insane?"
    new "Bist du verrückt?"

    # say L58 pla
    old "We were already at risk doing it here, in the classroom."
    new "Wir waren schon gefährdet, es hier im Klassenzimmer zu tun."

    # say L59 pla
    old "We need to leave before someone comes... But help me clean her first."
    new "Wir müssen verschwinden, bevor jemand kommt... Aber hilf mir erst, sie sauber zu machen."

    # say L71 mia
    old "You say you don’t know what’s happening, yet you still have this boner."
    new "Sie sagen, Sie wissen nicht, was los ist, und trotzdem haben Sie immer noch einen Steifen."

    # say L72 pla
    old "W- well, t- that’s just because..."
    new "W-was soll das heißen..."

    # say L73 mia
    old "Spare me, will you?"
    new "Sparen Sie mir das, ja?"

    # say L74 mia
    old "I just need you to finish, I’ll go faster."
    new "Ich brauche nur, dass Sie fertig werden, ich werde schneller machen."

    # say L78 mia
    old "You’re fucking disgusting for doing this, you know? To force me this way."
    new "Sie sind echt eklig, dass Sie so was machen. Mich auf diese Weise zu zwingen."

    # say L79 pla
    old "I- I already said I don’t know what are you talking abut."
    new "Ich- Ich hab’ doch schon gesagt, ich weiß nicht, wovon du redest."

    # say L80 mia
    old "Sure... I guess this boner is just because I’m pretty, right? You are sick!"
    new "Sicher... Ich schätze, dieser Steifen ist einfach, weil ich hübsch bin, oder? Du bist krank!"

    # say L81 mia
    old "Will you just finish already?"
    new "Wollen Sie endlich fertig werden?"

    # say L85 mia
    old "I just can’t believe you’d stood up this low."
    new "Ich kann einfach nicht glauben, dass Sie so tief sinken konnten."

    # say L86 mia
    old "I will never forgive this, and I’ll make sure you pay for this."
    new "Ich werde das niemals vergessen, und ich werde sicherstellen, dass Sie dafür bezahlen."

    # say L87 mia
    old "Don’t you think for a single second that you’ll pull this shit again."
    new "Denken Sie nicht einmal daran, dass Sie das noch mal versuchen."

    # say L110 pla
    old "M-Miss Mia, if you keep going, I-I’ll...!"
    new "M-Miss Mia, wenn du so weitermachst, ich-ich werd'...!"

    # say L111 mia
    old "Fucking finally!"
    new "Endlich!"

    # say L112 mia
    old "Finish quickly will you? I don’t want to keep touching your dick."
    new "Beeilen Sie sich, ich will nicht die ganze Zeit Ihren Schwanz anfassen."

    # say L117 mia
    old "Ughhh... This is so gross..."
    new "Ughhh... Das ist ja ekelig..."

    # say L118 mia
    old "Anyway, let's finish this shit."
    new "Na los, bringen wir’s hinter uns."

    # say L119 pla
    old "W- What? Now what?"
    new "W- Was? Was jetzt?"

    # say L124 pla
    old "What the hell was that?"
    new "Was zur Hölle war das?"

    # say L125 pla
    old "Why did you suddenly do that?"
    new "Warum hast du das plötzlich gemacht?"

    # say L126 mia
    old "I see you’re planning on keeping this up, huh?"
    new "Ich sehe, Sie planen, das durchzuziehen, hm?"

    # say L127 mia
    old "You know [pla], I always thought you were an idiot."
    new "Sie wissen [pla], ich habe Sie immer für einen Idioten gehalten."

    # say L128 mia
    old "But I never thought you’d be the kind of disgusting cockroach that would do this type of shit."
    new "Aber ich hätte nie gedacht, dass du der widerliche Kakerlake bist, der so etwas macht."

    # say L140 den
    old "Yeah that’s right, get his dick in your mouth."
    new "Ja, genau, steck seinen Schwanz in deinen Mund."

    # say L141 den
    old "Like the whore you are."
    new "Wie die Nutte, die du bist."

    # say L142 mia
    old "S- shut up!"
    new "S- halten Sie den Mund!"

    # say L146 den
    old "You must be enjoying this, aren’t you?"
    new "Du musst das ja genießen, oder?"

    # say L148 den
    old "You little whore, look at how you do that."
    new "Du kleine Schlampe, schau dir an, wie du das machst."

    # say L149 den
    old "It must be your experience from all the cocks you’ve sucked."
    new "Es muss deine Erfahrung von all den Schwänzen, die du gelutscht hast, sein."

    # say L153 den
    old "Tell me Mia, how much are you enjoying this?"
    new "Sag mir, Mia, wie sehr genießt du das?"

    # say L154 mia
    old "Glurpp... F- fuck you!"
    new "Glurpp... F- ficken Sie mich!"

    # say L155 den
    old "Ha, you’re gagging on cock and you’re telling me to shut up?"
    new "Ha, du würgst am Schwanz und sagst mir, ich soll die Klappe halten?"

    # say L178 den
    old "I see you’re about to finish [pla], that’s good, that’s good."
    new "Ich sehe, du bist gleich soweit [pla], das ist gut, das ist gut."

    # say L179 den
    old "Why don’t you go ahead and cum in her mouth?"
    new "Warum gehst du nicht einfach und spritzt ihr in den Mund?"

    # say L180 den
    old "Don't worry, she'll swallow it all, that's what she used to do."
    new "Mach dir keine Sorgen, sie wird alles schlucken, so wie früher."

    # say L181 den
    old "You better drink every drop Mia, that’s an order."
    new "Du solltest jeden Tropfen trinken, Mia, das ist ein Befehl."

    # say L187 pla
    old "Are you ok Miss Mia?"
    new "Geht es Ihnen gut, Miss Mia?"

    # say L189 mia
    old "Ohh, yes, I’m fine, just let me gather my bearings for a second."
    new "Ohh, ja, ich bin in Ordnung, geben Sie mir einfach einen Moment, um mich zu sammeln."

    # say L190 pla
    old "I’m sorry, for finishing in your mout-... I mean for everything."
    new "Entschuldigung, dass ich in deinem Mund... ich meine, für alles."

    # say L193 mia
    old "That asshole is the one who made us do this."
    new "Dieser Arschloch ist der, der uns das hat tun lassen."

    # say L212 den
    old "Ha, what’s the matter Ms? Is it too big for you?"
    new "Ha, was ist los, Ms? Ist es zu groß für dich?"

    # say L213 den
    old "But you’re so experienced! Come on! I know you can take it all!"
    new "Aber du bist doch so erfahren! Komm schon! Ich weiß, dass du das alles kannst!"

    # say L217 den
    old "Hey [pla]! You’re fucking your teacher that always tormented you!"
    new "Hey [pla]! Du vögelst die Lehrerin, die dich immer gequält hat!"

    # say L218 den
    old "I bet it must feel really nice, huh?"
    new "Ich wette, das fühlt sich echt gut an, oder?"

    # say L219 den
    old "I know you wanted to do this bro! She’s been messing with you after all."
    new "Ich weiß, dass du das wolltest, Alter! Schließlich hat sie dir immer das Leben schwer gemacht."

    # say L220 den
    old "That’s it, fuck her like the whore she is!"
    new "Das ist es, fick sie wie die Nutte, die sie ist!"

    # say L224 den
    old "How do you feel Ms. Mia?"
    new "Wie fühlst du dich, Ms. Mia?"

    # say L225 den
    old "I bet you like having his big cock inside!"
    new "Ich wette, dir gefällt es, seinen großen Schwanz in dir zu spüren!"

    # say L226 den
    old "Just like the old days, huh?"
    new "Genau wie in alten Zeiten, was?"

    # say L227 mia
    old "S- Mmm! Shut up!"
    new "S- Mmm! Halten Sie den Mund!"

    # say L250 pla
    old "M-Miss Mia, I think - I think I’m..."
    new "M-Miss Mia, ich glaube - ich glaube, ich bin..."

    # say L251 den
    old "Yeah! That’s it [pla], fill her up!"
    new "Ja! Mach weiter [pla], füll sie aus!"

    # say L252 den
    old "Fill that pussy up with cum!"
    new "Füll ihre Pussy mit Sperma!"

    # say L257 pla
    old "A-are you ok Miss Mia?"
    new "A-Are you okay, Miss Mia?"

    # say L258 pla
    old "I’m sorry."
    new "Es tut mir leid."

    # say L260 mia
    old "It’s ok, you shouldn’t have to apologize."
    new "Es ist in Ordnung, Sie müssen sich nicht entschuldigen."

    # say L261 mia
    old "You’re also a victim here."
    new "Sie sind auch ein Opfer hier."

    # say L262 mia
    old "You’re actually a big help."
    new "Sie sind eigentlich eine große Hilfe."

    # say L282 den
    old "Yeah, you probably missed that dick, didn’t you Mia?"
    new "Ja, du hast wahrscheinlich diesen Schwanz vermisst, oder Mia?"

    # say L284 den
    old "Answer me Mia!"
    new "Antworte mir Mia!"

    # say L285 mia
    old "Y- Nghn! Mmm! Y-Yeah I do!"
    new "Y- Nghn! Mmm! Y-Yeah, ich tu’s!"

    # say L289 den
    old "I bet you like fucking in the bathroom!"
    new "Ich wette, dir gefällt es, im Bad zu ficken!"

    # say L290 den
    old "You like that you almost got caught, don’t you Mia?"
    new "Du magst es, fast erwischt worden zu sein, stimmt’s Mia?"

    # say L291 den
    old "Is exciting isn’t it?"
    new "Das ist aufregend, oder?"

    # say L292 den
    old "I can’t hear you!"
    new "Ich kann dich nicht hören!"

    # say L293 mia
    old "Y-yes! Ah! Is... Ah! Very exciting!"
    new "J-ja! Ah! Ist... Ah! Sehr aufregend!"

    # say L316 den
    old "I see you’re about to finish [pla]."
    new "Ich sehe, du bist kurz davor zu kommen [pla]."

    # say L317 den
    old "It’s ok dude, let it out!"
    new "Alles gut, lass es raus!"

    # say L318 den
    old "I want you to fill her pussy up!"
    new "Ich will, dass du ihre Pussy füllst!"

    # say L319 pla
    old "M-Miss Mia, I- I’m about to...!"
    new "M-Miss Mia, ich bin gleich soweit...!"

    # say L320 mia
    old "J-just do it!"
    new "J-just tun Sie es!"

    # say L325 den
    old "Well guys, I would say that was perfect! Don’t you agree?"
    new "Na Leute, ich würde sagen, das war perfekt! Oder seht ihr das anders?"

    # say L326 den
    old "Hahahaha, you can really tell Mia has some experience in front of the camera."
    new "Hahahaha, man merkt echt, dass Mia schon Erfahrung vor der Kamera hat."

    # say L327 den
    old "You too [pla], you’re a natural dude!"
    new "Du auch [pla], du bist ein Naturtalent, Alter!"

    # say L328 den
    old "Well, I think I should just leave you two little lovebirds to comfort each other."
    new "Na ja, ich denke, ich sollte euch beiden kleinen Turteltauben einfach Trost spenden lassen."

    # say L329 den
    old "But remember, all of this has been recorded, I don’t have to remind you what that means... Anyway, bye."
    new "Aber denk dran, alles wurde aufgezeichnet, ich muss dich nicht daran erinnern, was das bedeutet... Also, tschüss."

    # say L345 dir
    old "Oh yeah! That’s it!"
    new "Oh ja! Das ist es!"

    # say L346 dir
    old "Yes! Yes! It’s so good!"
    new "Ja! Ja! Es ist so gut!"

    # say L347 dir
    old "It’s even better than a real dick!"
    new "Es ist sogar noch besser als ein echter Schwanz!"

    # say L352 dir
    old "Ah! Ah! Yeah!"
    new "Ah! Ah! Ja!"

    # say L353 dir
    old "That’s just what I wanted!"
    new "Das ist genau das, was ich wollte!"

    # say L354 dir
    old "YES!"
    new "JA!"

    # say L387 mia
    old "Mmm, it’s so hard"
    new "Mmm, es ist so hart"

    # say L389 pla
    old "M-Mia, lower your voice."
    new "M-Mia, dämpfe deine Stimme."

    # say L393 dir
    old "Oh, oh fuck yeah!"
    new "Oh, oh Scheiße ja!"

    # say L395 dir
    old "MMMM! FUCK YEAH!"
    new "MMMM! FICK JA!"

    # say L399 dir
    old "Well, that just cheered me up!"
    new "Na, das hat mich ja richtig aufgemuntert!"

    # say L400 dir
    old "What a great way to start the day!"
    new "Was für eine tolle Art, den Tag zu beginnen!"

    # say L413 black1
    old "Yes, oh you look so fucking good."
    new "Ja, oh du siehst so verdammt gut aus."

    # say L414 miavid
    old "Mmmm! Ahhh! It's so big..."
    new "Mmmm! Ahhh! Es ist so groß..."

    # say L415 black1
    old "That’s what I wanna hear."
    new "Das ist genau das, was ich hören will."

    # say L416 black2
    old "Keep sucking bitch."
    new "Weiter saugen, Schlampe."

    # say L418 pla
    old "You had to memorize these dialogues or..."
    new "Du musstest dir diese Dialoge merken oder..."

    # say L419 mia
    old "Uhh... Something like that... That’s how it usually is in that industry."
    new "Uhh... So ähnlich... So läuft das in der Branche meistens."

    # say L420 mia
    old "Also my moans and everything, you have to pretend it all."
    new "Also meine Seufzer und alles, Sie müssen so tun, als wäre es alles echt."

    # say L424 miavid
    old "Mmm! Slurp! Slurp!"
    new "Mmm! Schlürf! Schlürf!"

    # say L425 black1
    old "Mmm yeah babe, it feels really nice..."
    new "Mmm ja Babe, das fühlt sich echt gut an..."

    # say L426 miavid
    old "Oh, yeah!"
    new "Oh, ja!"

    # say L428 pla
    old "Did you guys ever improvised the lines or anything?"
    new "Habt ihr je die Zeilen improvisiert oder so?"

    # say L429 mia
    old "Yeah, the only script we had was for the set ups, but most of the time we were improvising."
    new "Ja, das einzige Drehbuch, das wir hatten, war für die Einleitungen, aber meistens haben wir improvisiert."

    # say L430 pla
    old "Yeah, I could kinda tell."
    new "Ja, das hab ich irgendwie gemerkt."

    # say L434 black2
    old "Oh my gosh, I can feel it reaching your throat."
    new "Oh mein Gott, ich kann es fühlen, wie es deine Kehle erreicht."

    # say L435 miavid
    old "Mmmm... Yeah baby..."
    new "Mmmm... Ja, Baby..."

    # say L436 black1
    old "That’s what you wanted bitch!"
    new "Das wolltest du doch, Schlampe!"

    # say L437 miavid
    old "Yeah! Yeah!"
    new "Ja! Ja!"

    # say L438 miavid
    old "I love your big black cocks!"
    new "Ich liebe eure großen schwarzen Schwänze!"

    # say L440 pla
    old "You know... You were very good at this."
    new "Du warst echt gut darin."

    # say L441 mia
    old "Ugh! Come on! Really [pla]?"
    new "Ugh! Komm schon! Wirklich [pla]?"

    # say L442 mia
    old "That’s what you have to say about it?"
    new "Das ist alles, was Sie dazu sagen?"

    # say L443 pla
    old "Sorry, sorry, you’re right, that was out of line, I was just saying."
    new "Entschuldigung, entschuldigung, du hast recht, das war unpassend, ich wollte nur sagen."

    # say L444 mia
    old "Yeah, yeah, I know what you mean..."
    new "Ja, ja, ich weiß, was Sie meinen..."

    # menu L465 
    old "Skip"
    new "Überspringen"

    # say L466 mia
    old "Ok, that’s enough, there aren’t any more videos or anything else in the folder."
    new "Okay, das reicht, es gibt keine weiteren Videos oder etwas anderes im Ordner."

    # say L467 mia
    old "So we don’t need to keep checking this out."
    new "Dann müssen wir uns das also nicht mehr anschauen."

    # say L468 pla
    old "Yeah, you’re right."
    new "Ja, du hast recht."

    # say L478 miavid
    old "I-It’s so fucking big!"
    new "E-Es ist so verdammt groß!"

    # say L479 miavid
    old "I can’t handle it! AH!"
    new "Ich schaff das nicht! AH!"

    # say L480 black1
    old "That’s right baby, take that big black cock!"
    new "Das ist richtig, Baby, nimm diesen großen schwarzen Schwanz!"

    # say L483 pla
    old "Well, they are very big."
    new "Na, die sind schon ziemlich groß."

    # say L484 mia
    old "Mmm, not the biggest ever."
    new "Mmm, nicht die größten, die ich je gesehen habe."

    # say L503 mia
    old "Just don’t take too much time."
    new "Nehmen Sie sich einfach nicht zu viel Zeit."

    # say L504 mia
    old "We’re supposed to already be going to the principal's office."
    new "Wir sollten schon auf dem Weg zum Büro des Schulleiters sein."

    # say L508 mia
    old "Hurry up!"
    new "Beeilen Sie sich!"

    # say L509 pla
    old "I-I’m trying, but I can’t do it if you keep rushing me!"
    new "Ich versuch’s ja, aber ich schaffe es nicht, wenn du mich so drängst!"

    # say L510 mia
    old "Just let go and enjoy it."
    new "Lassen Sie sich einfach gehen und genießen Sie es."

    # say L511 mia
    old "That way you’ll cum quickly."
    new "So wirst du schnell kommen."

    # say L512 mia
    old "I’ll go faster!"
    new "Ich werde schneller!"

    # say L517 mia
    old "That’s it, I can feel you getting harder."
    new "Das ist es, ich spüre, wie du härter wirst."

    # say L518 mia
    old "There you go, just enjoy my mouth!"
    new "Da sind Sie, genießen Sie einfach meinen Mund!"

    # say L519 pla
    old "I-I think it’s working."
    new "I-I glaube, es funktioniert."

    # say L520 pla
    old "J-just don’t stop."
    new "J-just nicht aufhören."

    # say L543 pla
    old "M-Mia I think I’m cuming!"
    new "M-Mia, ich glaube, ich komme!"

    # say L544 mia
    old "Do it, quickly!"
    new "Machen Sie es, schnell!"

    # say L545 mia
    old "Finish!"
    new "Komm!"

    # say L551 mia
    old "I mean, did you have to finish all over me?"
    new "Ich meine, mussten Sie sich wirklich überall auf mir ergießen?"

    # say L552 mia
    old "You covered me in cum!"
    new "Sie haben mich mit Sperma bedeckt!"

    # say L553 pla
    old "S-sorry, I couldn’t really control it."
    new "S-Sorry, ich konnte es echt nicht kontrollieren."

    # say L554 mia
    old "Whatever, listen, I’ll get clean quickly and we’ll go to the principal’s office."
    new "Was auch immer, hören Sie, ich werde mich schnell saubermachen und dann gehen wir ins Büro der Schulleiterin."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/lydAnimations.rpy
translate german strings:

    # say L6 lyd
    old "You definitely should make many young girls very happy."
    new "Du solltest definitiv viele junge Mädchen sehr glücklich machen."

    # say L7 lyd
    old "It's so long and thick."
    new "Es ist so lang und dick."

    # say L8 lyd
    old "And rock solid too."
    new "Und steinhart auch."

    # say L12 lyd
    old "Oh my god! You're getting even harder!"
    new "Oh mein Gott! Du wirst noch härter!"

    # say L13 lyd
    old "Your dick! It's so hard and hot in my hand!"
    new "Dein Schwanz! Er ist so hart und heiß in meiner Hand!"

    # say L14 lyd
    old "That's it, let go! Just let me stroke it!"
    new "Das ist es, lass los! Lass mich es einfach streicheln!"

    # say L18 lyd
    old "Do you like this? Do you like how I play with your dick?"
    new "Magst du das? Magst du, wie ich mit deinem Schwanz spiele?"

    # say L20 lyd
    old "Is this dick that hard because of me? Do you think I'm sexy?"
    new "Ist dieser Schwanz so hart wegen mir? Findest du mich sexy?"

    # say L22 pla
    old "Y-yes, you are sexy!"
    new "Y-ja, du bist sexy!"

    # say L45 pla
    old "I- I think I'm about to!"
    new "I- Ich glaube, ich komme gleich!"

    # say L46 lyd
    old "Yes! cum!"
    new "Ja! komm!"

    # say L47 lyd
    old "I want to see you shoot all your hot stuff because of me!"
    new "Ich will sehen, wie du wegen mir all deinen heißen Saft spritzt!"

    # say L63 lyd
    old "Oh yeah! It's just as I imagined."
    new "Oh ja! Genau so habe ich es mir vorgestellt."

    # say L64 lyd
    old "It has an amazing taste!"
    new "Es hat einen unglaublichen Geschmack!"

    # say L65 lyd
    old "And it's so hot!"
    new "Und es ist so heiß!"

    # say L69 lyd
    old "I don't think I've ever blown a dick this big, even in the past."
    new "Ich glaube, ich habe noch nie einen so großen Schwanz geblasen, auch nicht in der Vergangenheit."

    # say L70 lyd
    old "I think this is the best dick I've seen."
    new "Ich denke, das ist der beste Schwanz, den ich je gesehen habe."

    # say L71 lyd
    old "And it's also the biggest!"
    new "Und es ist auch der größte!"

    # say L76 lyd
    old "Do you like my mouth?"
    new "Magst du meinen Mund?"

    # say L77 lyd
    old "Do you like how I do it?!"
    new "Magst du, wie ich das mache?!"

    # say L101 lyd
    old "I can feel how your dick twitches in my mouth!"
    new "Ich spüre, wie dein Schwanz in meinem Mund zuckt!"

    # say L102 lyd
    old "Do it [pla]!"
    new "Mach es [pla]!"

    # say L103 lyd
    old "Cum in my mouth young man!"
    new "Komm in meinem Mund, junger Mann!"

    # say L104 pla
    old "O- ok!"
    new "O- okay!"

    # say L111 lyd
    old "That was great. Young men really are something special."
    new "Das war toll. Junge Männer sind wirklich etwas Besonderes."

    # say L112 lyd
    old "But you know [pla], I think you're extra special."
    new "Aber du weißt schon [pla], ich finde, du bist besonders."

    # say L113 lyd
    old "I mean, even when I was young, I never saw a dick like yours before."
    new "Ich meine, selbst als ich jung war, habe ich noch nie einen Schwanz wie deinen gesehen."

    # say L114 lyd
    old "It's amazing how big and hard it is."
    new "Es ist unglaublich, wie groß und hart es ist."

    # say L115 lyd
    old "It makes me wonder..."
    new "Es macht mich neugierig..."

    # say L116 pla
    old "Ok... I think I should get dressed again."
    new "Okay... ich denke, ich sollte mich wieder anziehen."

    # say L117 lyd
    old "Yeah, you're right. It would be best."
    new "Ja, du hast recht. Es wäre am besten."

    # say L129 lyd
    old "Nngh! Wow, it's so big."
    new "Nngh! Wow, es ist so groß."

    # say L131 lyd
    old "Y- yes, it's just that it's been a while."
    new "Y- ja, es ist nur, dass es schon eine Weile her ist."

    # say L132 lyd
    old "And you're so big!"
    new "Und du bist so groß!"

    # say L136 lyd
    old "Ah! Ah! Yes! Yes!"
    new "Ah! Ah! Ja! Ja!"

    # say L137 lyd
    old "Your dick, it's so big, and so hot!"
    new "Dein Schwanz, er ist so groß und so heiß!"

    # say L138 lyd
    old "It's filling me up so hard!"
    new "Es füllt mich so hart aus!"

    # say L139 lyd
    old "L- let's do it a little faster!"
    new "Lass uns ein bisschen schneller machen!"

    # say L143 lyd
    old "Yes! Just like that!"
    new "Ja! Genau so!"

    # say L144 lyd
    old "Don't stop! Keep going!"
    new "Hör nicht auf! Mach weiter so!"

    # say L145 lyd
    old "Nngh! Yes! YES!"
    new "Nngh! Ja! JA!"

    # say L168 pla
    old "I- I think I can't hold it in longer!"
    new "Ich glaube, ich kann es nicht mehr zurückhalten!"

    # say L169 lyd
    old "Don't! Don't hold it!"
    new "Nicht! Lass es raus!"

    # say L170 lyd
    old "You can do it! CUM INSIDE!"
    new "Du schaffst das! KOMM DRIN!"

    # say L176 lyd
    old "You know? I believe this might have worked, I feel so much better now, like a weight has been lifted off my shoulders."
    new "Ich glaube, das hat wirklich funktioniert, ich fühle mich jetzt viel besser, als hätte mir eine Last von den Schultern genommen."

    # say L177 pla
    old "I'm glad you feel like that. I hope this actually helped you."
    new "Ich freue mich, dass es dir so geht. Ich hoffe, das hat dir wirklich geholfen."

    # say L178 lyd
    old "I'm sure it did, thanks a lot [pla]!"
    new "Ich bin mir sicher, dass es geholfen hat, danke schön [pla]!"

    # say L179 pla
    old "You're welcome, I'm happy to help."
    new "Gern geschehen, ich freue mich, dir zu helfen."

    # say L191 lyd
    old "I'm gonna use my tongue all over the tip of your cock."
    new "Ich werde meine Zunge über die Spitze deines Schwanzes lecken."

    # say L194 pla
    old "Uhh, I love that sensation, babe."
    new "Uhh, ich liebe dieses Gefühl, Babe."

    # say L198 lyd
    old "Mmmm... It tastes so good! I love it."
    new "Mmmm... Es schmeckt so gut! Ich liebe es."

    # say L201 pla
    old "Oh yeah babe, I'll definitely love your mouth."
    new "Oh ja Babe, ich werd' deinen Mund definitiv lieben."

    # say L202 lyd
    old "Slrrrp! Uhh you have no idea!"
    new "Slrrrp! Uhh du hast keine Ahnung!"

    # say L209 pla
    old "You should have a lot of experience, don't you?"
    new "Du solltest eine Menge Erfahrung haben, oder?"

    # say L210 lyd
    old "Mmmm, yeah baby, but not with huge cocks like yours."
    new "Mmmm, ja Schatz, aber nicht mit so großen Schwänzen wie deinem."

    # say L213 pla
    old "Oh yeah babe, you will really enjoy my huge cock!"
    new "Oh ja Babe, du wirst meinen riesigen Schwanz wirklich genießen!"

    # say L214 lyd
    old "Mmm, that's exactly what I'm expecting."
    new "Mmm, das ist genau, was ich erwarte."

    # say L239 pla
    old "Ohh babe, I'm about to cum."
    new "Ohh Babe, ich komme gleich."

    # say L240 lyd
    old "Oh no, you don't. That's barely the beginning. You know what comes next."
    new "Oh nein, das ist erst der Anfang. Du weißt doch, was als Nächstes kommt."

    # say L241 pla
    old "(Oh God.)"
    new "Oh Gott."

    # say L244 pla
    old "Oh, I know what comes next, that's right, you want to put it all in your mouth, don't you?"
    new "Oh, ich weiß genau, was als Nächstes kommt, du willst es dir doch ganz in den Mund schieben, oder?"

    # say L245 lyd
    old "Yes! I want to feel it all in my mouth."
    new "Ja! Ich will es ganz in meinem Mund spüren."

    # say L252 lyd
    old "I love how big your cock is!"
    new "Ich liebe, wie groß dein Schwanz ist!"

    # say L255 pla
    old "Suck it! Put my cock in your mouth!"
    new "Saug es! Steck meinen Schwanz in deinen Mund!"

    # say L263 lyd
    old "Mmm, I just love the taste of your cock!"
    new "Mmm, ich liebe einfach den Geschmack deines Schwanzes!"

    # say L265 lyd
    old "I love how big and hot it always gets!"
    new "Ich liebe, wie groß und heiß es immer wird!"

    # say L268 pla
    old "Yeah! Tell me more!"
    new "Ja! Erzähl mir mehr!"

    # say L272 lyd
    old "This is the best cock I've ever had!"
    new "Das ist der beste Schwanz, den ich je hatte!"

    # say L274 lyd
    old "Nngh! Mmmm! I want more and more of it!"
    new "Nngh! Mmmm! Ich will immer mehr davon!"

    # say L277 pla
    old "Oh yeah? You want me to fuck you with it?"
    new "Oh ja? Willst du, dass ich dich damit ficke?"

    # say L278 lyd
    old "Yes! I love how it feels inside!"
    new "Ja! Ich liebe, wie es sich in mir anfühlt!"

    # say L284 pla
    old "Do you like how my dick fills your mouth?"
    new "Magst du, wie mein Schwanz deinen Mund ausfüllt?"

    # say L285 lyd
    old "Slrrrp! I love it! I can't get enough of it!"
    new "Slrrrp! Ich liebe es! Ich kann einfach nicht genug davon kriegen!"

    # say L287 lyd
    old "Don't cum yet! I want you to keep pushing your cock in my mouth!"
    new "Warte, spritz noch nicht ab! Ich will, dass du weiter deinen Schwanz in meinen Mund schiebst!"

    # say L290 pla
    old "That's it! Gobble on my cock!"
    new "Das ist es! Saug an meinem Schwanz!"

    # say L314 pla
    old "I'm about to cum baby! Tell me you want it in your mouth!"
    new "Ich komme gleich, Baby! Sag mir, dass du es in deinem Mund willst!"

    # say L315 lyd
    old "Yes! Yes! Shoot it all in my mouth!"
    new "Ja! Ja! Spritz alles in meinen Mund!"

    # say L317 lyd
    old "Fill my mouth with your hot cum!"
    new "Füll meinen Mund mit deinem heißen Sperma!"

    # say L325 pla
    old "Phew... This guy is writing again, he says 'Wow, that was so great!'"
    new "Puh... Dieser Typ schreibt wieder, er sagt „Wow, das war so toll!“"

    # say L326 lyd
    old "Hahaha, great? Don't you say?"
    new "Hahaha, toll? Sagst du das wirklich?"

    # say L327 lyd
    old "Tell him 'It really was, I can't wait for what's next.'"
    new "Sag ihm, es war wirklich so, ich freue mich schon auf das Nächste."

    # say L331 pla
    old "He answered with 'Yeah, me neither, but that'll have to wait, I have to go work, I'm 30 minutes over my break! Talk to you later, bye!'"
    new "Er hat geantwortet: „Ja, ich auch, aber das muss warten, ich muss zur Arbeit, ich bin schon 30 Minuten über meine Pause! Wir reden später, tschüss!“"

    # say L332 pla
    old "'But be sure I'm crazy to see you!'"
    new "Aber sei dir sicher, ich bin wahnsinnig darauf, dich zu sehen!"

    # say L333 lyd
    old "That's nice, I guess we'll talk later."
    new "Das ist schön, dann reden wir später."

    # say L334 pla
    old "You don't want me to answer anything back?"
    new "Willst du nicht, dass ich was zurück sage?"

    # say L335 lyd
    old "There's no need, he'll talk to me later anyway."
    new "Da ist kein Grund, er wird sowieso später mit mir reden."

    # say L349 lyd
    old "Nngh! Oh yes! This is just what I've been wanting!"
    new "Nngh! Oh ja! Das ist genau das, was ich wollte!"

    # say L350 lyd
    old "This long, thick hard cock of yours!"
    new "Dein langer, dicker, harter Schwanz!"

    # say L351 lyd
    old "There's no other cock like it!"
    new "Es gibt keinen anderen Schwanz wie deinen!"

    # say L355 lyd
    old "Y- your cock is the best!"
    new "Y- dein Schwanz ist der Beste!"

    # say L356 lyd
    old "I've never had any cock like this!"
    new "Ich hab noch nie so einen Schwanz gehabt!"

    # say L357 lyd
    old "Yes, yes, fuck me more!"
    new "Ja, ja, fick mich mehr!"

    # say L361 lyd
    old "Ohh! I love how you push into my pussy!"
    new "Ohh! Ich liebe, wie du in meine Pussy stößt!"

    # say L362 lyd
    old "I can't have enough of this hot cock!"
    new "Ich kann nicht genug von diesem heißen Schwanz kriegen!"

    # say L363 lyd
    old "Fuck me! Fuck me more!"
    new "Fick mich! Fick mich härter!"

    # say L386 pla
    old "L- Lydia! I think I'm about to..."
    new "L- Lydia! Ich glaube, ich komme gleich..."

    # say L387 lyd
    old "Yes! Let it all out!"
    new "Ja! Lass es raus!"

    # say L388 lyd
    old "Fill me with your hot cum!"
    new "Lass mich von deinem heißen Saft füllen!"

    # say L394 lyd
    old "That was good!"
    new "Das war gut!"

    # say L395 lyd
    old "Just what I was expecting."
    new "Das war genau das, was ich erwartet habe."

    # say L397 pla
    old "Listen, I'm glad you're feeling better."
    new "Hör zu, ich freue mich, dass es dir besser geht."

    # say L398 pla
    old "But, I think it's better if you just leave. Remember this isn't your house, someone could hear us."
    new "Aber ich denke, es ist besser, wenn du jetzt gehst. Vergiss nicht, dass das hier nicht dein Haus ist, jemand könnte uns hören."

    # say L399 lyd
    old "Leave? What are you talking about?"
    new "Gehen? Wovon redest du?"

    # say L400 lyd
    old "This is just the beginning!"
    new "Das ist erst der Anfang!"

    # say L401 pla
    old "W- What? What else do you want to do?"
    new "W- Was? Was willst du denn noch tun?"

    # say L402 lyd
    old "Ohh, it's something I wanted to try for the longest time."
    new "Ohh, es ist etwas, das ich schon seit Ewigkeiten ausprobieren wollte."

    # say L403 lyd
    old "But my husband was too much of a prude for it."
    new "Aber mein Mann war dafür viel zu prüde."

    # say L404 lyd
    old "Him and his stupid morale, always draggin me back!"
    new "Er und seine blöde Moral, immer zieht er mich zurück!"

    # say L405 lyd
    old "So, now you're going to give me what I want..."
    new "Dann wirst du mir jetzt geben, was ich will..."

    # say L407 lyd
    old "Just come here and find out."
    new "Komm her und sieh selbst."

    # say L424 lyd
    old "It's ok if you start sl-"
    new "Es ist okay, wenn du anfängst zu-"

    # say L427 lyd
    old "Oh yes! This is what I wanted!"
    new "Oh ja! Das ist genau das, was ich wollte!"

    # say L428 lyd
    old "Mmm, nngh, it hurts a little, but is perfect!"
    new "Mmm, nngh, es tut ein bisschen weh, aber es ist perfekt!"

    # say L432 lyd
    old "Y- your dick is massive!"
    new "D- dein Schwanz ist riesig!"

    # say L433 lyd
    old "It's stretching my ass so much!"
    new "Es dehnt meinen Arsch so sehr aus!"

    # say L434 pla
    old "S- should I stop?"
    new "S- soll ich aufhören?"

    # say L435 lyd
    old "No! Don't you dare!"
    new "Nein! Wage es ja nicht!"

    # say L436 lyd
    old "I'm loving this!"
    new "Ich liebe das!"

    # say L440 lyd
    old "YES! YES! You fucking my ass with that big dick!"
    new "JA! JA! Du fickst mein Arschloch mit diesem großen Schwanz!"

    # say L441 lyd
    old "It's just what I wanted!"
    new "Das ist genau das, was ich wollte!"

    # say L442 lyd
    old "I'll never have enough of this dick!"
    new "Ich werde nie genug von diesem Schwanz kriegen!"

    # say L443 lyd
    old "I love it when you fuck me!"
    new "Ich liebe es, wenn du mich fickst!"

    # say L466 lyd
    old "I can feel your dick twitching in my ass!"
    new "Ich spüre, wie dein Schwanz in meinem Arsch zuckt!"

    # say L467 pla
    old "I- I'm about to finish!"
    new "Ich- Ich komme gleich!"

    # say L468 lyd
    old "Do it! Finish in my ass!"
    new "Mach es! Spritz in mir ab!"


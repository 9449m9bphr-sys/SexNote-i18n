# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Bathroom.rpy
translate german strings:

    # menu L11 
    old "Look at her better"
    new "Sieh sie dir genauer an"

    # say L19 pla
    old "I should leave... I don't want to make her think I'm perverted."
    new "Ich sollte gehen... Ich will nicht, dass sie denkt, ich bin pervers."


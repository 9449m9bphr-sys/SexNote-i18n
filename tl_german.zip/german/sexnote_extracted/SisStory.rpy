# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/SisStory.rpy
translate german strings:

    # say L9 sis
    old "Hey [pla], I heard [mo1] and [mo2] arguing about you last night."
    new "Hey [pla], ich hab gehört, dass [mo1] und [mo2] sich gestern Abend über dich gestritten haben."

    # say L10 sis
    old "Do you know what happened?"
    new "Weißt du, was passiert ist?"

    # say L11 pla
    old "About me? Oh, fuck... "
    new "Über mich? Oh, Scheiße..."

    # say L12 sis
    old "What? Do you know what it was about?"
    new "Was? Weißt du, worum es ging?"

    # say L13 pla
    old "No, no I don't know. I, uh... I have to go."
    new "Nein, nein, ich weiß es nicht. Ich, äh... ich muss los."

    # say L18 sis
    old "Wait, don't leave yet! I kinda need your help... "
    new "Warte, geh noch nicht! Ich brauch irgendwie deine Hilfe..."

    # say L22 sis
    old "Well, you know all the nerdy shit, right?"
    new "Na ja, du weißt doch all den nerdigen Kram, oder?"

    # say L23 pla
    old "... What are you trying to say?"
    new "Was willst du damit sagen?"

    # say L24 sis
    old "What I mean is, do you know how to make a website?"
    new "Meinst du, ob ich weiß, wie man eine Website erstellt?"

    # say L25 pla
    old "Well, yes, I know how to do it."
    new "Na ja, klar, ich weiß, wie man das macht."

    # say L26 sis
    old "See, that's nerdy shit... "
    new "Siehst du, das ist so ein nerdischer Kram..."

    # say L27 pla
    old "Come out with it. What do you need?"
    new "Sag schon. Was brauchst du?"

    # say L28 sis
    old "Haha. Ok, just come to my room in the afternoon and I will explain everything..."
    new "Haha. Okay, komm einfach nachmittags zu mir ins Zimmer und ich erkläre dir alles..."

    # say L60 pla
    old "Oh, shit..."
    new "Oh, Scheiße..."

    # say L64 sis
    old "(GOD that's his... It's huge...)"
    new "Gott, das ist seins... Es ist riesig..."

    # say L70 pla
    old "No... It's... Not... What... It seems..."
    new "Nein... Es ist... Nicht... Was... Es scheint..."

    # say L87 pla
    old "Oh shit, did she see you?"
    new "Oh Scheiße, hat sie dich gesehen?"

    # say L89 bri
    old "Of course not. No one but you can see me..."
    new "Natürlich nicht. Niemand außer dir kann mich sehen..."

    # say L91 pla
    old "Yeah... But she saw me... Like this... Fuck..."
    new "Klar... Aber sie hat mich gesehen... So... Scheiße..."

    # say L93 pla
    old "Now what? It doesn't go down..."
    new "Und jetzt? Es geht nicht runter..."

    # say L95 bri
    old "Well, I think that interrupting the process of transferring magic power so abruptly was not a good thing..."
    new "Na ja, ich denke, das abrupte Unterbrechen des Vorgangs der Magieübertragung war nicht besonders gut."

    # say L97 pla
    old "So, now what do I do to get this thing down?"
    new "Und, was mache ich jetzt, damit das Ding wieder runterkommt?"

    # say L99 bri
    old "Well... It would be best to wait for your body to process all the magical power it received for the first time."
    new "Na ja... Es wäre am besten, wenn du abwartest, bis dein Körper die magische Energie verarbeitet hat, die er zum ersten Mal erhalten hat."

    # say L101 pla
    old "Okay. It's probably best to go to my room before someone else comes in and sees me with this..."
    new "Okay. Wahrscheinlich ist es am besten, ich gehe in mein Zimmer, bevor noch jemand reinkommt und mich so sieht..."

    # say L103 bri
    old "Ok, I'll rest and try to recover some magical energy."
    new "Okay, ich werde mich ausruhen und versuchen, etwas magische Energie wiederherzustellen."

    # say L130 pla
    old "Oh... Hi, [sis]... "
    new "Oh... Hallo, [sis]..."

    # say L131 sis
    old "I've been waiting for you. Let's jump right into it, shall we?"
    new "Ich habe auf dich gewartet. Lass uns gleich damit anfangen, okay?"

    # say L132 pla
    old "... Sure, I guess."
    new "Klar, warum nicht."

    # say L134 sis
    old "Now, pay attention... As you know, I have been selling clothes to friends and acquaintances."
    new "Jetzt, konzentrier dich... Wie du weißt, habe ich schon Kleidung an Freunde und Bekannte verkauft."

    # say L135 sis
    old "But now I want to sell them on the internet! That's why I need you to help me make a website."
    new "Aber jetzt will ich sie im Internet verkaufen! Deshalb brauche ich deine Hilfe, um eine Website zu machen."

    # say L136 pla
    old "Well, I've never done a storefront site before... But it should be easy enough."
    new "Na, ich hab noch nie einen Online-Shop gebaut... Aber es sollte ja nicht so schwer sein."

    # say L137 sis
    old "Perfect! Good nerd! Because I will need it ready for next week. I have a lot of items to post."
    new "Perfekt! Guter Nerd! Denn ich brauche es nächste Woche fertig. Ich habe viele Artikel online zu stellen."

    # say L138 pla
    old "What? That's gonna be pretty hard to make it that fast, [sis]."
    new "Was? Das wird ziemlich knifflig, so schnell fertig zu kriegen, [sis]."

    # say L139 pla
    old "Making a good website takes time. You'd have to work on it for days, sometimes weeks. And then it could be buggy and-."
    new "Ein guter Websiteaufbau braucht Zeit. Du müsstest tagelang, manchmal wochenlang daran arbeiten. Und dann könnte sie noch buggig sein und-"

    # say L140 sis
    old "Oh, come on, [pla]! You're a nerd. King nerd, in fact. I trust you can whip my site up in no time."
    new "Oh, komm schon, [pla]! Du bist ein Nerd. Ein König der Nerds, um genau zu sein. Ich vertraue darauf, dass du meine Seite in null Komma nichts auf die Beine stellst."

    # say L141 pla
    old "It's just not as simple as you think. Actually, I'm going to need you to work closely with me to tell me how you want it designed."
    new "Es ist einfach nicht so einfach, wie du denkst. Tatsächlich werde ich dich brauchen, um eng mit mir zusammenzuarbeiten und mir zu sagen, wie du es gestaltet haben möchtest."

    # say L142 sis
    old "Alright, but how long will this take? And I'm not trying to just get this for free. I'm willing to pay a small fee for your help."
    new "Okay, aber wie lange wird das dauern? Und ich will nicht, dass du das umsonst machst. Ich bin bereit, dir ein kleines Honorar zu zahlen."

    # say L143 pla
    old "Really? Hmmm... Maybe we can work in the afternoons and see how far we can go with it."
    new "Wirklich? Hmmm... Vielleicht können wir nachmittags zusammenarbeiten und sehen, wie weit wir kommen."

    # say L144 sis
    old "That's the spirit, little dude. And hey, if it all works out well, I could share some of the profits."
    new "Das ist der richtige Geist, kleiner Mann. Und wenn alles gut läuft, könnte ich dir von den Gewinnen abgeben."

    # say L145 pla
    old "Nice. Sounds good to me."
    new "Klingt gut für mich."

    # say L146 sis
    old "Perfect! Then I will wait for you in the afternoon in my room so we can start working. And don't have me waiting like you did yesterday."
    new "Perfekt! Dann warte ich heute Nachmittag in meinem Zimmer auf dich, damit wir anfangen können. Und lass mich nicht wieder warten wie gestern."

    # say L147 pla
    old "Ok, I will see you in the afternoon to help you."
    new "Okay, ich sehe dich nachmittags, um dir zu helfen."

    # say L148 sis
    old "Thank you so much! By the way, what have you been doing in the garage?"
    new "Danke schön! Übrigens, was hast du denn in der Garage gemacht?"

    # say L149 pla
    old "Well... Uhh... A school project... "
    new "Na ja... Äh... Ein Schulauftrag..."

    # say L150 sis
    old "And what's so exciting in the project that's making your dick so hard?"
    new "Und was ist so aufregend an dem Projekt, dass es deinen Schwanz so hart macht?"

    # say L151 pla
    old "What? Uhh... I don't know... What are you're talking about... "
    new "Was? Uhh... Ich weiß nicht... Wovon redest du..."

    # say L152 sis
    old "Haha. Yeah, right. You know I saw it?"
    new "Haha. Ja, klar. Du weißt doch, dass ich es gesehen habe?"

    # say L154 sis
    old "Ok, ok, don't answer me. I was just being curious... If you need to go ahead with your project, do your thing."
    new "Ok, ok, musst du mir nichts sagen. Ich war nur neugierig... Wenn du mit deinem Projekt weitermachen willst, mach ruhig."

    # say L155 sis
    old "Just don't forget me in the afternoons."
    new "Aber vergiss mich nicht am Nachmittag."

    # say L185 sis
    old "Damn, it's late. I didn't realize how much time has passed."
    new "Verdammt, es ist schon spät. Ich habe gar nicht gemerkt, wie viel Zeit vergangen ist."

    # say L189 pla
    old "Yup, we did a lot of work today."
    new "Stimmt, wir haben heute viel gearbeitet."

    # say L190 sis
    old "That's right, you deserve a break today. Thanks for your hard work."
    new "Stimmt, du hast dir heute eine Pause verdient. Danke für die harte Arbeit."

    # say L191 pla
    old "Ok, you are very welcome... See you later, good night."
    new "Ok, gerne geschehen... Bis später, gute Nacht."

    # say L200 pla
    old "Yeah, but we are making so much progress."
    new "Ja, aber wir machen so viel Fortschritte."

    # say L201 sis
    old "Right! I like this kind of work. You typing all of those codes and me saying what to do... "
    new "Stimmt! Mir gefällt diese Art von Arbeit. Du tippst all die Codes und ich sage, was zu tun ist..."

    # say L202 pla
    old "Yeah... That was really fun... "
    new "Ja... Das war wirklich Spaß..."

    # say L203 sis
    old "Oh, come on, it wasn't that bad and I will pay you... "
    new "Oh, komm schon, es war nicht so schlimm und ich werde dich bezahlen..."

    # say L204 pla
    old "You are right about that. We are a good team."
    new "Du hast recht. Wir sind ein gutes Team."

    # say L205 sis
    old "That's better! Ok, let's link back up tomorrow to keep working!"
    new "Das ist besser! Okay, lass uns morgen wieder zusammenarbeiten!"

    # say L206 pla
    old "Ok, see you later, [sis]. Have a good night."
    new "Ok, bis später, [sis]. Schlaf gut."

    # say L220 pla
    old "What the fuck! What is this?"
    new "Was zur Hölle! Was ist das?"

    # say L227 sis
    old "NOTHING... NOTHING! (Shit!) I THINK WE'RE DONE FOR TODAY!"
    new "Nichts... nichts! (Scheiße!) Ich glaube, wir sind für heute fertig!"

    # say L228 pla
    old "But... There is still so much to do."
    new "Aber... Da ist noch so viel zu tun."

    # say L229 sis
    old "A Virus! My laptop has a virus and I need to fix it... Come tomorrow. Leave now."
    new "Ein Virus! Mein Laptop hat einen Virus und ich muss ihn reparieren... Komm morgen. Geh jetzt."

    # say L230 pla
    old "... (Hmm, that was weird.)"
    new "... (Hmm, das war seltsam.)"

    # say L247 pla
    old "I should check if [sis] needs help with the website."
    new "Ich sollte überprüfen, ob [sis] Hilfe mit der Website braucht."

    # say L259 pla
    old "I- I'm sorry, I didn't k- know..."
    new "Ich- Ich bin sorry, ich hab' nicht gewusst..."

    # say L260 sis
    old "Oh, come on... This isn't what you wanted to see?"
    new "Oh, komm schon... Das wolltest du doch sehen?"

    # say L262 sis
    old "Turn around [pla], I want you to see me..."
    new "Dreh dich um [pla], ich will, dass du mich siehst..."

    # say L265 sis
    old "Ohh... Look what we have here... You definitely have a huge cock..."
    new "Ohh... Schau mal, was wir hier haben... Du hast definitiv einen riesigen Schwanz..."

    # say L267 sis
    old "You have worked very, very hard for me, maybe you deserve a small reward."
    new "Du hast sehr, sehr hart für mich gearbeitet, vielleicht verdienst du eine kleine Belohnung."

    # say L269 sis
    old "Well I think you have something for me down there, maybe I should take care of it."
    new "Ich denke, du hast da unten was für mich, vielleicht sollte ich mich drum kümmern."

    # say L271 sis
    old "I know you want to fuck me... I think I could let you fuck my mouth, would you like that?"
    new "Ich weiß, dass du mich ficken willst... Ich denke, ich könnte dir erlauben, meinen Mund zu ficken. Würdest du das mögen?"

    # say L273 sis
    old "Yes, I'll let you fuck my mouth, with that huge cock..."
    new "Ja, ich lasse dich meinen Mund ficken, mit diesem riesigen Schwanz..."

    # say L274 sis
    old "Now, take out that cock and come here!"
    new "Jetzt hol ihn raus und komm her!"

    # say L292 pla
    old "Wow! That was just a dream..."
    new "Wow! Das war nur ein Traum..."

    # say L293 pla
    old "I should definitely stop playing visual novels..."
    new "Ich sollte definitiv aufhören, Visual Novels zu spielen..."

    # say L294 pla
    old "Working with her so much is affecting me in some way."
    new "So viel Zeit mit ihr zu verbringen, wirkt sich irgendwie auf mich aus."

    # say L325 pla
    old "Ufff finally... I think that's it, we are done."
    new "Ufff endlich... Ich glaube, das war's, wir sind fertig."

    # say L326 sis
    old "Really? Finally? Excellent!!! So, how do we start selling products?"
    new "Wirklich? Endlich? Toll!!! Also, wie fangen wir an, die Produkte zu verkaufen?"

    # say L327 pla
    old "Hmm... I'm a bit tired because of all I have done, we can check tomorrow."
    new "Hmm... Ich bin ein bisschen müde von all dem, was ich gemacht habe, wir können das morgen machen."

    # say L328 sis
    old "What?! I've been waiting for weeks! I need to sell my products as fast as I can, it will take just a moment and you're not going die for that... "
    new "Was?! Ich warte schon seit Wochen! Ich muss meine Produkte so schnell wie möglich verkaufen, das dauert nur einen Moment und du wirst dafür auch nicht sterben..."

    # say L329 pla
    old "Ok, I will explain, pay attention to this."
    new "Okay, ich erkläre es dir, hör gut zu."

    # say L336 pla
    old "Oh, this is a very interesting part on web designing, I used javascript in order to make your webpage responsive, I apply the layouts and-"
    new "Oh, das ist ein sehr interessanter Teil der Webdesign, ich habe JavaScript verwendet, um deine Webseite responsiv zu machen, ich habe die Layouts angewendet und-"

    # say L337 sis
    old "Come On! straight to the point nerd! How do I upload the content?"
    new "Komm schon! Auf den Punkt, Nerd! Wie lade ich den Inhalt hoch?"

    # say L338 pla
    old "Ok, well, to upload the pics and info, you need to access with the admin account, open the products window and there you can upload, item by item... "
    new "Okay, also, um die Bilder und Infos hochzuladen, musst du dich mit dem Admin-Account anmelden, das Produktfenster öffnen und dann kannst du alles einzeln hochladen..."

    # say L339 pla
    old "The description needs a title, detailed info of the product, the pics and finally the price, and there you go!"
    new "Die Beschreibung braucht einen Titel, detaillierte Infos zum Produkt, die Bilder und schließlich den Preis, und schon ist es online!"

    # say L340 sis
    old "Woow, amazing, let me try myself... "
    new "Wow, toll, lass mich es selbst ausprobieren..."

    # say L344 pla
    old "Ok... "
    new "Ok..."

    # say L345 sis
    old "It's not as hard as you said, actually it's pretty simple... "
    new "Ist gar nicht so schwer, wie du gesagt hast, eigentlich ist es ziemlich einfach..."

    # say L346 pla
    old "Well, it's because the hardest part was done already with the coding... "
    new "Na ja, das Schwierigste war ja schon mit dem Codieren erledigt..."

    # say L347 sis
    old "Suuuuure. Now, how can an user make a purchase?"
    new "Suuuure. Jetzt, wie kann ein Benutzer einen Kauf tätigen?"

    # say L348 pla
    old "Well, everything is done thru the security framework-"
    new "Alles läuft über das Sicherheitssystem -"

    # say L349 sis
    old "BORING! just tell me how I can see the money. "
    new "LANGWEILIG! Sag mir einfach, wie ich das Geld sehen kann."

    # say L350 pla
    old "Hmm ok. You need to go to the sales window, here you will see the customer info, products and money."
    new "Hmm okay. Du musst zum Verkaufsfenster gehen, da siehst du die Kundendaten, Produkte und Geld."

    # say L351 sis
    old "Wujuu! If you behave I think, there is an option to make you my partner."
    new "Wujuu! Wenn du brav bist, denke ich, gibt es die Option, dich zu meinem Partner zu machen."

    # say L352 pla
    old "Yeah right. Well I think that's all for today, need anything else?"
    new "Klar, dann ist das wohl alles für heute. Brauchst du noch was?"

    # say L353 sis
    old "No, if I need something I'll reach out to you... You better not doing something weird... "
    new "Nein, wenn ich was brauche, melde ich mich... Du solltest besser nichts Seltsames machen..."

    # say L355 sis
    old "Nevermind... I will be busy, doing my work, see you later... "
    new "Vergiss es... Ich werde beschäftigt sein, meine Arbeit machen, bis später..."

    # say L356 pla
    old "Hmm, Ok... (You are welcome, by the way... )"
    new "Hmm, okay... (Du bist willkommen, übrigens... )"

    # say L374 pla
    old "(Oh shit! My [sisrel] is taking a shower... )"
    new "Oh Shit! Meine [sisrel] nimmt ein Bad..."

    # say L375 pla
    old "(She's got such an amazing body... )"
    new "Sie hat so einen unglaublichen Körper..."

    # say L387 pla
    old "(I should leave... I don't want to make her think I'm perverted.)"
    new "Ich sollte gehen... Ich will nicht, dass sie denkt, ich bin ein Perversling."

    # say L391 pla
    old "(I should leave... I don't want to make her think I'm a pervert.)"
    new "Ich sollte gehen... Ich will nicht, dass sie denkt, ich bin ein Perversling."

    # say L396 sis
    old "What the fuck! What are you doing, [pla]?"
    new "Was zum Teufel! Was machst du da, [pla]?"

    # say L397 pla
    old "Sorry, I was-."
    new "Entschuldigung, ich war-"

    # say L398 sis
    old "COME IN... AND CLOSE THE DOOR."
    new "Komm rein... und mach die Tür zu."

    # say L399 pla
    old "(Shit!)"
    new "Scheiße!"

    # say L405 pla
    old "Look I... "
    new "Schau, ich..."

    # say L406 sis
    old "Shut up... You just saw me... Now it's my turn."
    new "Halt die Klappe... Du hast mich gerade gesehen... Jetzt bin ich dran."

    # say L407 pla
    old "(Gulp) What? What do you mean?"
    new "Was? Was meinst du damit?"

    # say L408 sis
    old "I mean, show me what you got in those shorts."
    new "Ich meine, zeig mir, was du da in den Shorts hast."

    # say L409 pla
    old "Whaat?... "
    new "Was?..."

    # say L410 sis
    old "Well, if you don't show me, I'm going to scream and tell [mo1] and [mo2] you were peeping on me."
    new "Na, wenn du es mir nicht zeigst, schreie ich und erzähle [mo1] und [mo2], dass du mich beobachtet hast."

    # say L411 pla
    old "B- but... Why do you want to see me naked?"
    new "B- aber... Warum willst du mich nackt sehen?"

    # say L412 sis
    old "Is justice for a pervert... And I'm just curious about what I saw in the garage last time... So show me... Now!"
    new "Das ist Gerechtigkeit für einen Perversen... Und ich bin einfach neugierig auf das, was ich letztes Mal in der Garage gesehen habe... Also zeig es mir... Jetzt!"

    # say L413 pla
    old "Alright, alright... "
    new "Okay, okay..."

    # say L421 sis
    old "(Mmm... It's bigger than some pornstars I use to see.)"
    new "Mmm... Es ist größer als bei einigen Pornostars, die ich mal gesehen habe."

    # say L422 sis
    old "And... Why were you so excited at the garage?"
    new "Und... Warum warst du im Schuppen so aufgeregt?"

    # say L423 pla
    old "Hmm... I- I don't know what you're talking about."
    new "Hmm... Ich- ich weiß nicht, wovon du redest."

    # say L424 sis
    old "Ugh. Ok, nevermind... I should go... "
    new "Ugh. Okay, egal... Ich geh dann mal..."

    # say L428 pla
    old "Wait... That's my? "
    new "Warte... Das ist mein?"

    # say L429 sis
    old "Bye... "
    new "Tschüss..."

    # say L436 pla
    old "What the hell! She took my clothes!"
    new "Was zur Hölle! Sie hat meine Klamotten genommen!"

    # say L437 pla
    old "Oh shit! What do I do now?"
    new "Oh Scheiße! Was mache ich jetzt?"

    # say L438 pla
    old "I gotta get to my room really fast!"
    new "Ich muss echt schnell in mein Zimmer kommen!"

    # say L443 pla
    old "Ok I don't see anyone nearby, now is my chance... "
    new "Ok, ich sehe niemanden in der Nähe, jetzt ist meine Chance..."

    # say L453 mo2
    old "WHAT THE FUCK?!"
    new "WAS ZUM TEUFEL?!"

    # say L454 pla
    old "(... Oh god..) Sorry... "
    new "(... Oh Gott...) Tut mir leid..."

    # say L465 mo2
    old "YOU ARE A FUCKING PERVERT AND AN EXHIBITIONIST!!!"
    new "Sie sind ein verdammter Perverser und Exhibitionist!!!"

    # say L466 pla
    old "(Oh shit, oh shit. I almost died! Fuck!)"
    new "Oh Scheiße, oh Scheiße. Ich bin fast gestorben! Verdammt!"

    # say L467 pla
    old "It's probably best to stay here until tomorrow... "
    new "Es ist wahrscheinlich am besten, wenn wir hier bis morgen bleiben..."

    # say L490 sis
    old "Well, I am kind of ok."
    new "Na ja, ich bin ziemlich okay."

    # say L491 pla
    old "Hmm... Is everything alright?"
    new "Hmm... Ist alles in Ordnung?"

    # say L492 sis
    old "Not really, the website is not working and I don't know what's wrong."
    new "Nicht wirklich, die Website funktioniert nicht und ich hab keine Ahnung, was da los ist."

    # say L493 pla
    old "Is not working? You wanna check it together to see what the problem could be?"
    new "Funktioniert nicht? Willst du es zusammen mit mir überprüfen, um zu sehen, was das Problem sein könnte?"

    # say L494 sis
    old "Oh please, because I feel a bit down, you know."
    new "Oh bitte, ich fühle mich gerade ein bisschen down, weißt du."

    # say L495 pla
    old "Don't worry, we can find a solution."
    new "Keine Sorge, wir finden eine Lösung."

    # say L502 pla
    old "I can see that your webpage has been visited several times, so there are actually people looking at it."
    new "Ich sehe, dass deine Webseite schon mehrmals besucht wurde, also schauen tatsächlich Leute drauf."

    # say L503 sis
    old "I think the clothes are nice, but do you think they're maybe too expensive?"
    new "Ich finde die Klamotten schön, aber findest du sie vielleicht zu teuer?"

    # say L504 pla
    old "Hmmm, I think you have a good variety of prices, so I don't think that is the problem."
    new "Hmmm, ich denke, du hast eine gute Preismischung, das ist also wahrscheinlich kein Problem."

    # say L505 sis
    old "Could it be that the products aren't that nice?"
    new "Könnte es sein, dass die Produkte nicht so toll sind?"

    # say L506 pla
    old "I actually like them, I've seen you wearing some of the clothes, they look cool."
    new "Ich finde sie eigentlich cool, ich hab dich schon in ein paar von den Klamotten gesehen, die sehen toll aus."

    # say L507 sis
    old "Is the website running correctly?"
    new "Funktioniert die Website eigentlich richtig?"

    # say L508 pla
    old "What do you mean? Sure! it works, I made it myself."
    new "Was meinst du? Klar, es funktioniert, ich hab es selbst gebaut."

    # say L509 sis
    old "Let's try to make a purchase to see if the website is ok."
    new "Lass uns einen Kauf tätigen, um zu sehen, ob die Website funktioniert."

    # say L510 pla
    old "I did everything carefully... Hmm, but we can double check."
    new "Ich hab alles sorgfältig gemacht... Hmm, aber wir können es nochmal überprüfen."

    # say L511 sis
    old "Perfect, select that shirt, then those pants, add them to the shopping cart."
    new "Perfekt, wähle dieses Shirt aus, dann diese Hose, und füge sie dem Warenkorb hinzu."

    # say L512 sis
    old "What's next?"
    new "Was kommt als Nächstes?"

    # say L513 pla
    old "The delivery info"
    new "Die Lieferinformationen"

    # say L514 sis
    old "Ok, let's use ours."
    new "Ok, nehmen wir unsere."

    # say L515 pla
    old "Oh, payment options, let's put the card in."
    new "Oh, Zahlungsmethoden, lass uns die Karte eintragen."

    # say L517 pla
    old "Finally, summary cart."
    new "Endlich, Warenkorb Zusammenfassung."

    # say L518 pla
    old "Order went through successfully, the website works perfectly. That's not the problem."
    new "Die Bestellung war erfolgreich, die Website funktioniert einwandfrei. Das ist nicht das Problem."

    # say L519 sis
    old "Cancel the order."
    new "Bestellung stornieren"

    # say L520 sis
    old "I don't get it... What am I doing wrong?"
    new "Ich versteh das nicht... Was mach ich falsch?"

    # say L521 sis
    old "What do other people do to sell?"
    new "Was machen andere Leute, um zu verkaufen?"

    # say L522 pla
    old "Huh! that's brilliant."
    new "Huh! Das ist genial."

    # say L523 sis
    old "Really? Wait... What's brilliant?"
    new "Wirklich? Moment... Was ist brillant?"

    # say L524 pla
    old "A very good idea could be to check how other people do it."
    new "Eine sehr gute Idee wäre, zu schauen, wie andere es machen."

    # say L525 pla
    old "Let's compare ours with other websites, that way we can take some ideas too."
    new "Lass uns unsere mit anderen Websites vergleichen, dann können wir auch ein paar Ideen abgucken."

    # say L526 pla
    old "Let's check a big one like... Hmm I don't know, Calvin Klown."
    new "Schauen wir uns einen großen wie... Hmm, ich weiß nicht, Calvin Klown an."

    # say L527 sis
    old "Yeah, that could work."
    new "Ja, das könnte funktionieren."

    # say L528 pla
    old "They are really good, this looks amazing."
    new "Sie sind wirklich gut, das sieht fantastisch aus."

    # say L529 sis
    old "Yeah, it's very depressing."
    new "Ja, es ist echt deprimierend."

    # say L531 sis
    old "Just look! They are just so gorgeous, mine doesn't look even close."
    new "Schau dir das an! Die sind einfach wunderschön, meins sieht dagegen gar nicht so aus."

    # say L532 pla
    old "Well, it's not fair if you compare yourself with them, this is a worldwide fashion business!"
    new "Na ja, es ist nicht fair, wenn du dich mit ihnen vergleichst, das ist ein weltweites Modegeschäft!"

    # say L533 pla
    old "Consider, that they invest millions on advertisement, Internet, TV characters, even music videos and artists."
    new "Denk dran, sie investieren Millionen in Werbung, im Internet, in TV-Figuren, sogar in Musikvideos und Künstler."

    # say L534 sis
    old "Yeah, that's very impressive."
    new "Ja, das ist wirklich beeindruckend."

    # say L535 pla
    old "Alright, that was enough Calvin Klown for one day."
    new "Okay, das war genug Calvin Klown für einen Tag."

    # say L541 pla
    old "Hmm... I have something in mind."
    new "Hmm... Ich hab da was im Sinn."

    # say L542 pla
    old "Well, we could, and I am not sure... But try some options to show the clothes like they do."
    new "Wir könnten, und ich bin mir nicht sicher... Aber versuchen wir ein paar Optionen, um die Klamotten so zu zeigen, wie sie es machen."

    # say L543 sis
    old "You mean the way they use models and take the pics?"
    new "Meinst du so, wie sie Models benutzen und die Fotos machen?"

    # say L544 pla
    old "Yes, it could look more... Interesting? I guess so?"
    new "Ja, es könnte interessanter aussehen? Ich denke schon."

    # say L545 pla
    old "We can give it a try, doing the pics instead of using the ones you're using."
    new "Wir können es mal versuchen, die Fotos selbst zu machen, anstatt die zu benutzen, die du hast."

    # say L546 sis
    old "Hmm but we'll need a model and we can't afford that... "
    new "Hmm, aber wir brauchen ein Modell und das können wir uns nicht leisten..."

    # say L547 sis
    old "Wait a minute... I could be the model, can't I?"
    new "Warte mal... Ich könnte doch das Modell sein, oder?"

    # say L548 pla
    old "I considered that an option at first, but I saw there are some clothes where you would be almost naked."
    new "Ich hab das auch schon in Erwägung gezogen, aber bei einigen Klamotten wärst du fast nackt."

    # say L549 pla
    old "I mean some clothes are 'sexy' and a lot of people would watch them... Are you sure you are ok with that?"
    new "Ich meine, manche Klamotten sind ziemlich 'sexy' und viele Leute würden sie sich anschauen... Bist du dir sicher, dass du damit okay bist?"

    # say L550 sis
    old "Actually, I like the idea... I think it's kind of exciting!"
    new "Eigentlich mag ich die Idee... Ich finde, das ist irgendwie aufregend!"

    # say L551 pla
    old "Well, if you'd like we would have covered an important part of the problem and if you are the model that would be very useful to have a defined market image."
    new "Na ja, wenn dir das gefällt, hätten wir einen wichtigen Teil des Problems gelöst und wenn du das Model bist, wäre das sehr nützlich, um ein klares Marktbild zu haben."

    # say L552 sis
    old "Ok, so, what do we need?"
    new "Okay, also, was brauchen wir?"

    # say L553 pla
    old "We will for sure need a photographer."
    new "Wir werden auf jeden Fall einen Fotografen brauchen."

    # say L554 sis
    old "Wait a minute! A photographer could be really expensive."
    new "Warte mal! Ein Fotograf könnte echt teuer werden."

    # say L555 sis
    old "Why don't you take the pics instead?"
    new "Warum nimmst du die Fotos nicht selbst?"

    # say L556 pla
    old "Technically, I could but I have no camera."
    new "Technisch gesehen könnte ich, aber ich habe keine Kamera."

    # say L557 sis
    old "I think I can handle that. But can you use a professional camera?"
    new "Ich denke, ich kann das machen. Aber kannst du eine Profikamera benutzen?"

    # say L558 sis
    old "What I'm asking for of course a nerd knows."
    new "Was ich verlange, kennt natürlich ein Nerd."

    # say L560 sis
    old "That's great, so if you take the pictures, we can save a little without asking for the help of a photographer."
    new "Das ist toll, wenn du die Fotos machst, können wir ein bisschen sparen und müssen keinen Fotografen engagieren."

    # say L561 sis
    old "So, I will use all my money to buy a lot of clothes, so we can take tons of pics."
    new "Dann werde ich mein ganzes Geld dafür ausgeben, uns eine Menge Klamotten zu kaufen, damit wir unzählige Fotos machen können."

    # say L562 pla
    old "Wait what? No, no, no, calm down! It isn't convenient to use all the money you have."
    new "Warte, was? Nein, nein, nein, beruhige dich! Es ist nicht sinnvoll, alles Geld zu verwenden."

    # say L563 sis
    old "But we will need the clothes for the pics... "
    new "Aber wir brauchen die Klamotten für die Fotos..."

    # say L564 pla
    old "Yes, we do, however, we have to do some baby steps to check if it works."
    new "Ja, wir brauchen die Klamotten, aber wir sollten erst kleine Schritte machen, um zu sehen, ob es klappt."

    # say L565 pla
    old "If we can see some progress then you can invest more to see an improvement."
    new "Wenn wir Fortschritte sehen, kannst du mehr investieren, um eine Verbesserung zu sehen."

    # say L566 sis
    old "Hmm... Yeah, I think you're right."
    new "Hmm... Ja, ich denke, du hast recht."

    # say L567 sis
    old "Ok, I need time now, to get all of this ready. thanks for your help, I really appreciate it."
    new "Ok, ich brauche jetzt Zeit, um alles vorzubereiten. danke für deine Hilfe, das bedeutet mir viel."

    # say L568 sis
    old "I will let you know as soon as I have everything ready."
    new "Ich werde dir Bescheid sagen, sobald ich alles vorbereitet habe."

    # say L569 pla
    old "Cool, I'll see you then."
    new "Cool, dann sehen wir uns später."

    # say L589 sis
    old "[pla], where were you? I've been looking for you."
    new "[pla], wo warst du? Ich hab dich schon überall gesucht."

    # say L590 sis
    old "Let's go, the delivery has just arrived."
    new "Lass uns gehen, die Lieferung ist gerade angekommen."

    # say L591 sis
    old "You can't imagine how excited I am, I almost jumped from the window when I saw the driver."
    new "Du kannst dir nicht vorstellen, wie aufgeregt ich bin, ich bin fast aus dem Fenster gesprungen, als ich den Fahrer gesehen habe."

    # say L592 pla
    old "I can see that, you're all anxious to start."
    new "Ich seh's, du kannst es kaum abwarten anzufangen."

    # say L593 sis
    old "Yes, we can't waste time, I have been waiting for this, the website needs this."
    new "Ja, wir dürfen keine Zeit verschwenden, ich habe schon so lange darauf gewartet, die Website braucht das."

    # say L594 sis
    old "Let's go to my bedroom."
    new "Lass uns in mein Schlafzimmer gehen."

    # say L602 sis
    old "Give me a moment, I don't know where to start. "
    new "Gib mir einen Moment, ich weiß nicht, wo ich anfangen soll."

    # say L603 pla
    old "Ok, just calm down a bit."
    new "Okay, beruhige dich erst mal."

    # say L613 sis
    old "I'm pretty impatient we can start right away."
    new "Ich bin ziemlich ungeduldig, wir können sofort loslegen."

    # say L614 sis
    old "This is for you."
    new "Das ist für dich."

    # say L619 pla
    old "Wow, this is huge, looks like a very good camera."
    new "Wow, das ist riesig, sieht aus wie eine sehr gute Kamera."

    # say L620 sis
    old "I am sure you will figure out how it works."
    new "Ich bin sicher, du kriegst raus, wie es funktioniert."

    # say L621 sis
    old "Bear with me a moment while I get ready. You should try the cam in the meantime."
    new "Warte kurz, ich bereite mich vor. Du solltest in der Zwischenzeit die Kamera ausprobieren."

    # say L622 pla
    old "Ok, Sure, I will start checking (It doesn't look so hard.)"
    new "Okay, klar, ich fang mal an rumzuschnüffeln (Sieht ja nicht so schwierig aus.)"

    # say L628 pla
    old "(I think auto mode should work just fine to start, I'll give a further review later.)"
    new "Ich denke, der Automodus sollte erst mal reichen, ich schau's mir später genauer an."

    # say L629 pla
    old "(Let's check... She bought really nice clothes.)"
    new "Lass uns mal sehen... Sie hat echt tolle Klamotten gekauft."

    # say L636 pla
    old "(This is very short and tiny. How does she fit in?)"
    new "Das ist sehr kurz und klein. Wie passt sie da rein?"

    # say L642 pla
    old "(This is a great color for a pic, I think I have a couple of ideas.)"
    new "Das ist eine tolle Farbe für ein Bild, ich glaube, ich habe ein paar Ideen."

    # say L648 pla
    old "(What is this?)"
    new "Was ist das?"

    # say L651 pla
    old "(Ohh... This is a...)"
    new "Ohh... Das ist ein..."

    # say L654 sis
    old "Wow,wow, wow. GET AWAY FROM MY STUFF... You little snoopy."
    new "Wow, wow, wow. Finger weg von meinen Sachen... Du kleiner Schnüffler."

    # say L660 sis
    old "Where did you get it?"
    new "Wo hast du das her?"

    # say L661 sis
    old "I mean why are you looking through my stuff?"
    new "Ich meine, warum schnüffelst du in meinen Sachen rum?"

    # say L662 pla
    old " I... I- I just... "
    new "Ich... ich hab' es einfach..."

    # say L663 sis
    old " I... I... I... What?"
    new "Ich... ich... ich... Was?"

    # say L664 pla
    old "I was checking the clothes you bought, and it was just there."
    new "Ich hab die Klamotten angeguckt, die du gekauft hast, und da war es einfach."

    # say L665 pla
    old "I was not snooping, just checking the clothes and that appeared out nowhere."
    new "Ich hab nicht herumgeschnüffelt, ich wollte nur die Klamotten checken und da war es plötzlich."

    # say L666 sis
    old "THERE'S NO TIME TO WASTE, WE CAME TO WORK, LET'S GET STARTED."
    new "Es gibt keine Zeit zu verlieren, wir sind hier, um zu arbeiten, lass uns anfangen."

    # say L667 pla
    old "You're right, I'm sorry."
    new "Du hast recht, tut mir leid."

    # say L668 sis
    old "Alright, just get everything ready while I change."
    new "Okay, bereite einfach alles vor, während ich mich umziehe."

    # say L676 sis
    old "Well... How do I look?"
    new "Na... Wie sehe ich aus?"

    # say L677 pla
    old "Gulp... Y-you look ho- nice, you look pretty nice."
    new "Gulp... Y-you look ho- schön, du siehst wirklich gut aus."

    # say L678 sis
    old "Let's start, we have already wasted enough."
    new "Lass uns anfangen, wir haben schon genug Zeit verschwendet."

    # say L693 pla
    old "Ok, let me try... I will stay here to catch you better, stay right there."
    new "Okay, lass mich versuchen... Ich bleibe hier, um dich besser auffangen zu können, bleib einfach da."

    # say L700 pla
    old "(Oh shit.. It's not as easy as I thought...)"
    new "Oh Scheiße... Es ist nicht so einfach, wie ich dachte..."

    # say L702 pla
    old "Ehh... Just give me a second... I- I'm finding your best... Angle."
    new "Ehh... Gib mir einfach eine Sekunde... Ich- ich finde deinen besten... Winkel."

    # say L703 pla
    old "(Shit! I must take the picture when it's fully focused...)"
    new "Scheiße! Ich muss das Bild scharf stellen, bevor ich es aufnehme..."

    # say L741 pla
    old "Ehmm... Fine, we could check it at the end of the session..."
    new "Ehmm... Okay, wir können es am Ende der Sitzung überprüfen..."

    # say L742 sis
    old "You're right, sorry I'm just a bit anxious."
    new "Stimmt, tut mir leid, ich bin nur ein bisschen nervös."

    # say L743 pla
    old "Don't worry, relax a bit to look more natural."
    new "Mach dir keine Sorgen, entspann dich ein bisschen, dann siehst du natürlicher aus."

    # say L744 sis
    old "Okay, so for the next photo what should I do?"
    new "Okay, und für das nächste Foto, was soll ich machen?"

    # say L745 pla
    old "Hmm, I think we should take a picture from behind to show the back of the dress..."
    new "Hmm, ich denke, wir sollten ein Bild von hinten machen, um den Rücken des Kleids zu zeigen..."

    # say L746 sis
    old "Oh right! So what position should I take?"
    new "Oh richtig! Und welche Position soll ich einnehmen?"

    # say L747 pla
    old "Hmm, I think we could use the bed, what about if you lean on the edge of the bed with you back pointing to me in a... Sexy way."
    new "Hmm, ich denke wir könnten das Bett nehmen, was meinst du dazu, wenn du dich an den Bettrand lehnst und mir deinen Rücken zukehrst, auf eine... sexy Art."

    # say L748 sis
    old "Alright ..."
    new "Okay..."

    # say L758 sis
    old "So, do I look good like this?"
    new "So, sehe ich gut so aus?"

    # say L759 pla
    old "(Wow) Yeah... You look, great, let me focus on the camera ..."
    new "Wow, ja... Du siehst toll aus, lass mich mich auf die Kamera konzentrieren..."

    # say L760 pla
    old "(Oh shit, I'm getting hard. She looks really hot.)"
    new "Oh Scheiße, ich werde hart. Sie sieht echt heiß aus."

    # say L792 pla
    old "(I hope she doesn't notice my hardon...)"
    new "Ich hoffe, sie bemerkt meinen Ständer nicht..."

    # say L795 pla
    old "Ok... I- I think that's enough, for now."
    new "Ok... Ich glaube, das reicht erst mal."

    # say L796 sis
    old "What? Just two pics? No, I actually have an idea for a next photo..."
    new "Was? Nur zwei Fotos? Nein, ich hab eigentlich eine Idee für ein nächstes Foto..."

    # say L797 pla
    old "R- really? With a front and backside photo of the dress is not... Enough?"
    new "R- wirklich? Mit einem Foto von vorne und hinten ist das Kleid doch nicht... Genug?"

    # say L798 sis
    old "(Why is he acting so strange.) No, let's take one last photo, ok?"
    new "(Warum verhält er sich so komisch.) Nein, lass uns noch ein letztes Foto machen, okay?"

    # say L800 sis
    old "Let me try something I saw."
    new "Lass mich was ausprobieren, was ich gesehen hab."

    # say L813 sis
    old "(Is he ok?, he's walking different) Do you think this looks good?"
    new "Ist er in Ordnung? Er geht anders. Denkst du, das sieht gut aus?"

    # say L814 pla
    old "(Shit... I'm so hard right now...)"
    new "Scheiße... Ich bin gerade so hart..."

    # say L815 pla
    old "Y- yes, you look great..."
    new "Y- ja, du siehst toll aus..."

    # say L816 sis
    old "(What he gots there? Ohh! He has a boner. How could I not realize it before?)"
    new "Was hat er da? Ohh! Er hat einen Ständer. Wie konnte ich das vorher nicht bemerken?"

    # say L817 sis
    old "(Well, I need to let him work, he is very focused, and don't want to make him feel uncomfortable.)"
    new "(Naja, ich muss ihm seine Arbeit lassen, er ist sehr konzentriert und ich will ihn nicht verlegen machen.)"

    # say L851 sis
    old "Alright, I think that's enough for now..."
    new "Okay, ich denke, das reicht für jetzt..."

    # say L852 pla
    old "Oh, great, so it's done then see you later..."
    new "Oh, super, dann ist es ja fertig. Bis später..."

    # say L856 sis
    old "Wait a minute..."
    new "Warte mal..."

    # say L858 sis
    old "You said we could check the photos at the end of the session..."
    new "Du hast gesagt, wir können am Ende der Sitzung die Fotos anschauen..."

    # say L860 pla
    old "You're right..."
    new "Du hast recht..."

    # say L863 pla
    old "Ok... L- let's see the photos..."
    new "Ok... L- lass uns die Fotos ansehen..."

    # menu L883 
    old "Watch again"
    new "Noch einmal ansehen"

    # menu L887 
    old "Not Again"
    new "Wiederholung"

    # say L900 sis
    old "These photos are out of focus! They look really bad..."
    new "Diese Fotos sind verschwommen! Sie sehen echt schlecht aus..."

    # say L901 pla
    old "I am sorry, I think I need to practice more."
    new "Es tut mir leid, ich glaube, ich muss noch mehr üben."

    # say L902 sis
    old "Oh no, this is not good, I wanted to have this material for the website really soon."
    new "Oh nein, das ist nicht gut, ich wollte dieses Material für die Website echt bald haben."

    # say L903 pla
    old "I can make it better, just need some time."
    new "Ich kann es besser machen, ich brauche nur etwas Zeit."

    # say L904 sis
    old "So you need time but a moment ago you were snooping through my personal stuff."
    new "Dann brauchst du Zeit, aber vorhin hast du in meinen persönlichen Sachen herumgeschnüffelt."

    # say L905 sis
    old "I can't believe it."
    new "Ich kann es nicht fassen."

    # say L906 pla
    old "I'm sorry, I will practice more."
    new "Es tut mir leid, ich werde mehr üben."

    # say L907 sis
    old "All right, take the cam with you, and next time you better do it right."
    new "Okay, nimm die Kamera mit und beim nächsten Mal mach es besser."

    # say L931 sis
    old "Well, I am not surprised."
    new "Na, ich bin nicht überrascht."

    # say L932 pla
    old "Why, don't you like them?"
    new "Warum, gefallen sie dir nicht?"

    # say L933 sis
    old "Yep, I look gorgeous, I mean what could I expect from the 'nerd'."
    new "Klar, ich sehe toll aus, was hätte ich von dem 'Nerd' auch erwarten sollen."

    # say L934 pla
    old "I just wanted to help you."
    new "Ich wollte dir nur helfen."

    # say L935 sis
    old "You did well nerd."
    new "Du hast es gut gemacht, Nerd."

    # say L936 sis
    old "I didn't mean they are not good, don't take me the wrong way, I meant I knew it."
    new "Ich hab' nicht gesagt, dass sie schlecht sind, versteh mich nicht falsch, ich meinte, ich wusste es."

    # say L937 sis
    old "I appreciated it."
    new "Ich hab's geschätzt."

    # say L938 sis
    old "Time is money, let me upload this material, I need to sell."
    new "Zeit ist Geld, lass mich das Material hochladen, ich muss es verkaufen."

    # say L939 pla
    old "Ok, I guess I'm leaving then."
    new "Okay, dann geh ich wohl."

    # say L971 sis
    old "Ready to repeat the last photoshoot?"
    new "Bereit, das letzte Fotoshooting zu wiederholen?"

    # say L972 pla
    old "Yes, I practiced and I know I'll do better now..."
    new "Ja, ich hab geübt und ich weiß, dass ich es jetzt besser machen werde..."

    # say L973 sis
    old "You better do it right this time... Don't waste more time. Get ready while I get changed."
    new "Du solltest es dieses Mal richtig machen... Verschwend nicht mehr Zeit. Mach dich bereit, während ich mich umziehe."

    # say L978 sis
    old "Oh, by the way, do you need some help before we start?"
    new "Oh, übrigens, brauchst du Hilfe, bevor wir anfangen?"

    # say L984 pla
    old "Well... Ok."
    new "Na gut... Okay."

    # say L985 sis
    old "Hahaha, I'm going to make you cum fast..."
    new "Hahaha, ich werde dich schnell kommen lassen..."

    # say L995 sis
    old "I'm gonna get changed. You get the camera and stay ready."
    new "Ich zieh mich um. Hol die Kamera und sei bereit."

    # say L1000 pla
    old "It's ok, I think I will be fine."
    new "Alles gut, ich denke, ich komme klar."

    # say L1002 pla
    old "Yes, don't worry. I appreciate your help."
    new "Ja, mach dir keine Sorgen. Ich schätze deine Hilfe."

    # say L1003 sis
    old "Perfect! then let's go, we have so much to do!"
    new "Perfekt! dann lass uns loslegen, wir haben so viel zu tun!"

    # say L1004 sis
    old "I am excited, I just want to upload the new pics to get more sales!"
    new "Ich bin total aufgeregt, ich will nur die neuen Fotos hochladen, um mehr Verkäufe zu machen!"

    # say L1033 sis
    old "Alright, let's start! "
    new "Okay, lass uns anfangen!"

    # say L1059 sis
    old "I already know all the positions. You just focus on taking good pictures this time..."
    new "Ich kenne schon alle Positionen. Du konzentrierst dich einfach darauf, gute Fotos zu machen..."

    # say L1112 pla
    old "Ehmm... Done..."
    new "Ehm... Fertig..."

    # say L1113 sis
    old "Alright, next one. You know what to do."
    new "Okay, nächste. Du weißt, was du zu tun hast."

    # say L1169 sis
    old "Very well, last one. I hope all the photos are perfect, right?"
    new "Na gut, letztes. Ich hoffe, alle Fotos sind perfekt, oder?"

    # say L1170 pla
    old "Yes, don't worry..."
    new "Ja, mach dir keine Sorgen..."

    # say L1223 sis
    old "Ok, let's see the new photos!"
    new "Ok, lass uns die neuen Fotos ansehen!"

    # say L1281 sis
    old "Really [pla]?! Again out of focus... I can't believe it..."
    new "Wirklich [pla]?! Wieder aus dem Fokus... Ich kann es nicht glauben..."

    # say L1282 pla
    old "I-it wasn't my fault, I really tried to improve..."
    new "Es war nicht meine Schuld, ich hab echt versucht, mich zu verbessern..."

    # say L1283 sis
    old "Well, it wasn't enough... And you are making me lose money!"
    new "Na ja, das war nicht genug... Und du bringst mich dazu, Geld zu verlieren!"

    # say L1284 sis
    old "Get out... Come back when you learn to use that damn camera..."
    new "Raus... Komm zurück, wenn du endlich gelernt hast, diesen verdammten Kameratrigger zu benutzen..."

    # say L1317 sis
    old "Well, finally! These photos are great."
    new "Na endlich! Diese Fotos sind toll."

    # say L1318 sis
    old "I hope next time we don't have to do the photoshoot twice again..."
    new "Ich hoffe, beim nächsten Mal müssen wir das Fotoshooting nicht noch einmal machen..."

    # say L1319 pla
    old "Don't worry..."
    new "Mach dir keine Sorgen..."

    # say L1320 sis
    old "Hmm... Time is money, let me upload this material, I need to sell."
    new "Hmm... Zeit ist Geld, lass mich das Material hochladen, ich muss es verkaufen."

    # say L1321 pla
    old "Ok, leaving now."
    new "Okay, geh jetzt."

    # say L1395 pla
    old "(Holy shit! If I get caught she'll kill me!)"
    new "Verdammt! Wenn sie mich erwischen würde, wäre ich geliefert!"

    # say L1398 sis
    old "Hey, big boy. Do you need some help?"
    new "Hey, großer Junge. Brauchst du Hilfe?"

    # say L1407 pla
    old "Oh, god. Thanks. If she would have caught me, I'd be a goner."
    new "Oh, Gott. Danke. Wenn sie mich erwischt hätte, wäre ich geliefert gewesen."

    # say L1408 sis
    old "It's ok! you are saved now, just relax."
    new "Alles gut! Du bist gerettet, entspann dich einfach."

    # say L1409 pla
    old "Yes, I appreciate it, you saved my ass."
    new "Ja, danke, du hast mir echt den Arsch gerettet."

    # say L1410 sis
    old "I feel thankful too, last time you were great with the pics."
    new "Ich bin auch dankbar, letztes Mal warst du super mit den Fotos."

    # say L1411 sis
    old "Haven't given you a proper reward."
    new "Hab dich noch nicht richtig belohnt."

    # say L1412 pla
    old "Wh- What... Do you mean?"
    new "W- Was meinst du damit?"

    # say L1413 sis
    old "What I mean is... Take off those pants and show me that dick."
    new "Was ich meine ist... Zieh die Hose aus und zeig mir deinen Schwanz."

    # say L1414 pla
    old "Oh, come on, [sis]..."
    new "Oh, komm schon, [sis]..."

    # say L1415 sis
    old "Just do it... Your [mo2rel] is close. And you don't want me to call her..."
    new "Mach es einfach... Dein [mo2rel] ist nah dran. Und du willst doch nicht, dass ich sie rufe..."

    # say L1416 pla
    old "Really?… Ugh... Ok."
    new "Wirklich?… Äh… Okay."

    # say L1423 sis
    old "I knew it! It's fucking huge..."
    new "Ich hab's gewusst! Es ist verdammt groß..."

    # say L1425 sis
    old "Just let me turn on the lights to get a better look at it."
    new "Lass mich einfach das Licht anmachen, damit ich es besser sehen kann."

    # say L1444 sis
    old "Hey buddy, guess what?"
    new "Hey Kumpel, rat mal was?"

    # say L1446 sis
    old "Your idea was a big noise, it pulled off selling!"
    new "Deine Idee war ein großer Knaller, sie hat sich super verkauft!"

    # say L1448 sis
    old "Yep, come to my bedroom I need your help with something..."
    new "Klar, komm in mein Schlafzimmer, ich brauch deine Hilfe bei was..."

    # say L1455 sis
    old "Well, besides the messages I have now. We actually got a new customer, she was pretty interested in the last pics we did, remember?"
    new "Na klar, abgesehen von den Nachrichten, die ich jetzt habe. Wir haben tatsächlich einen neuen Kunden, sie war ziemlich interessiert an den letzten Fotos, an die wir gemacht haben, erinnerst du dich?"

    # say L1456 pla
    old "Yeah! I know which ones."
    new "Klar! Ich weiß, welche es sind."

    # say L1457 sis
    old "Anyway, I need your help now, we have several customers' messages."
    new "Jedenfalls, ich brauche jetzt deine Hilfe, wir haben mehrere Kundennachrichten."

    # say L1458 sis
    old "I'll need to answer them as some of them are very potential purchases."
    new "Ich muss ihnen antworten, da einige von ihnen sehr potenzielle Käufer sind."

    # say L1459 sis
    old "Need you to take one package to a customer."
    new "Brauche, dass du ein Paket zu einem Kunden bringst."

    # say L1460 pla
    old "You mean today?"
    new "Meinst du jetzt gleich?"

    # say L1461 sis
    old "Oh no, I mean right now."
    new "Oh nein, ich meine sofort."

    # say L1462 pla
    old "I am kind of busy now."
    new "Ich bin gerade ziemlich beschäftigt."

    # say L1463 sis
    old "That's not a business wise decision."
    new "Das ist keine geschäftliche Entscheidung."

    # say L1465 sis
    old "You know this is not actually a favor, it's included in the money you are expecting."
    new "Du weißt, dass das eigentlich kein Gefallen ist, es ist im Geld, das du erwarten darfst, inbegriffen."

    # say L1466 pla
    old "Hmm... I know, but I can't do it right away... We never discussed these kind of things."
    new "Hmm... Ich weiß, aber ich kann es nicht sofort machen... Wir haben so was noch nie besprochen."

    # say L1467 sis
    old "Yes, I know but we have to be committed to make this business grow."
    new "Ja, das weiß ich, aber wir müssen uns einbringen, damit das Geschäft wächst."

    # say L1468 pla
    old "Come on, almost everybody knows about me here in town, it's not comfortable."
    new "Komm schon, fast jeder hier im Ort kennt mich, das ist nicht angenehm."

    # say L1469 pla
    old "I don't want to be embarrassed delivering sexy panties to a classmate's mother."
    new "Ich will mich nicht blamieren, wenn ich sexy Unterwäsche bei der Mutter eines Klassenkameraden abliefere."

    # say L1470 sis
    old "Why would you be embarrassed, it isn't like you're the one wearing it."
    new "Warum solltest du dich schämen, als ob du es selbst trägst."

    # say L1471 sis
    old "Here is the thing, do you still wanna be helped like the other night?"
    new "Hier ist die Sache, willst du immer noch so geholfen werden wie neulich?"

    # say L1472 sis
    old "So, think about the 'business', if you help me I'll help you. I think my help is amazing, don't you like it?"
    new "Also, überleg dir das mit dem 'Geschäft'. Wenn du mir hilfst, helfe ich dir. Ich finde, meine Hilfe ist spitze, findest du nicht?"

    # say L1473 pla
    old "Hmm... Fine, but don't take me wrong, It's for business!"
    new "Hmm... Okay, aber missverstehe mich nicht, es ist wegen der Sache!"

    # say L1474 sis
    old "Hehehe, yeah sure! The business..."
    new "Hehehe, klar doch! Das Geschäft..."

    # say L1475 sis
    old "You will find all the info you need on the package."
    new "Du wirst alle Infos, die du brauchst, auf dem Paket finden."

    # say L1477 pla
    old "Hmm alright..."
    new "Hmm okay..."

    # say L1482 pla
    old "I think it's here... I hope it's not someone I know."
    new "Ich denke, es ist hier... Ich hoffe, es ist niemand, den ich kenne."

    # say L1485 jon
    old "Yes, sir, how can I help you?"
    new "Ja, Sir, wie kann ich Ihnen helfen?"

    # say L1486 pla
    old "(For real? Is she wearing this?)"
    new "Echt jetzt? Trägt sie das wirklich?"

    # say L1487 pla
    old "Hmmm, I think this package is for you."
    new "Hmmm, ich denke, dieses Paket ist für dich."

    # say L1488 jon
    old "(Wow! I know this young man, I met him in church.) "
    new "Wow! Ich kenne diesen jungen Mann, ich habe ihn in der Kirche getroffen."

    # say L1489 jon
    old "For me?"
    new "Für mich?"

    # say L1490 pla
    old "Yes, we had your order record, let me confirm, it is the Ultra short skirt, marvelous night surprise dress."
    new "Ja, wir hatten deine Bestellunterlagen, lass mich bestätigen, es ist der Ultrakurzer Rock, das wunderbare Nachtsurprise-Kleid."

    # say L1491 jon
    old "... What? This must be a mistake."
    new "Was? Das muss ein Irrtum sein."

    # say L1492 pla
    old "(Of course is yours, who else could be, has your name on it.)"
    new "Natürlich ist es deins, von wem sonst könnte es sein, es hat deinen Namen drauf."

    # say L1493 pla
    old "It could be, however, you're Mrs. Jones, right?"
    new "Es könnte sein, aber du bist doch Mrs. Jones, oder?"

    # say L1494 jon
    old "Yes, that's me..."
    new "Ja, das bin ich..."

    # say L1495 pla
    old "Well, we have all your information here, and the payment was done online... So..."
    new "Na ja, wir haben alle deine Informationen hier und die Bezahlung wurde online durchgeführt... Also..."

    # say L1496 jon
    old "(Hmm... I need to make up something, he knows me...)"
    new "Hmm... Ich muss mir etwas einfallen lassen, er kennt mich..."

    # say L1497 jon
    old "Oh! I remembered now, this is for my daughter, I forgot completely, hehehe."
    new "Oh! Ich habe mich jetzt erinnert, das ist für meine Tochter, ich hatte es völlig vergessen, hehehe."

    # say L1498 pla
    old "Hmm... It's ok, I understand, hope you daughter likes it."
    new "Hmm... Ist schon gut, ich verstehe, hoffe, deine Tochter mag es."

    # say L1503 jon
    old "Ok... Thank you! Bye bye."
    new "Ok... Danke! Tschüss."

    # say L1511 pla
    old "It's done!"
    new "Es ist geschafft!"

    # say L1512 sis
    old "Awesome, What happened? I wanna know everything."
    new "Super, was ist passiert? Ich will alles wissen."

    # say L1513 pla
    old "It was ok, gave her the package, that was it."
    new "Es war okay, hab ihr das Paket gegeben, das war’s."

    # say L1514 sis
    old "Was she excited about the purchase?"
    new "War sie aufgeregt über den Kauf?"

    # say L1515 pla
    old "Couldn't tell you, she was kind of reserved."
    new "Kann ich dir nicht sagen, sie war ziemlich zurückhaltend."

    # say L1516 sis
    old "Did you see if she liked it?"
    new "Hast du gesehen, ob sie es gemocht hat?"

    # say L1517 pla
    old "No, I just gave her the package and she said thank you."
    new "Nein, ich hab ihr nur das Paket gegeben und sie hat danke gesagt."

    # say L1518 sis
    old "I need you to pay careful attention to those details in future deliveries. "
    new "Ich brauche, dass du in Zukunft besser auf die Details achtest, wenn du die Pakete überbringst."

    # say L1519 pla
    old "What do you mean by future deliveries?"
    new "Was meinst du mit zukünftigen Lieferungen?"

    # say L1520 sis
    old "I have more merchandise coming so get prepare for another photoshoot session. "
    new "Ich habe noch mehr Ware auf dem Weg, also bereite dich auf eine weitere Fotoshooting-Sitzung vor."

    # say L1521 pla
    old "Hmm... All right."
    new "Hmm... Okay."

    # say L1522 sis
    old "Now leave me alone. It's late and I have a lot to do... "
    new "Jetzt lass mich in Ruhe. Es ist spät und ich habe viel zu tun..."

    # say L1544 sis
    old "Hey!, You won't believe the great news I have, I am so excited, this is working really well."
    new "Hey! Du wirst es nicht glauben, ich habe super Neuigkeiten, ich bin total aufgeregt, das läuft wirklich gut."

    # say L1545 sis
    old "We have a new customer, she ordered almost the entire website catalogue."
    new "Wir haben eine neue Kundin, sie hat fast den gesamten Katalog bestellt."

    # say L1546 pla
    old "Wow, that's great!"
    new "Wow, das ist toll!"

    # say L1547 sis
    old "The order already went through, soooo... I need your help!"
    new "Die Bestellung ist schon durchgegangen, also... ich brauche deine Hilfe!"

    # say L1548 pla
    old "Let me guess, you want me to make the delivery?"
    new "Lass mich raten, du willst, dass ich die Lieferung mache?"

    # say L1549 sis
    old "Yes, but if you go right now, you won't have to do it later, huh?"
    new "Ja, aber wenn du jetzt gehst, musst du es später nicht mehr machen, oder?"

    # say L1550 pla
    old "Well, it's still me doing the delivery!"
    new "Na klar, ich mache immer noch die Lieferung!"

    # say L1551 sis
    old "I love how engaged you are, this is why we are growing and growing!"
    new "Ich liebe, wie engagiert du bist, deshalb wächst unser Geschäft immer weiter!"

    # say L1552 pla
    old "Hmm, alright, I'll do the damn delivery... "
    new "Hmm, okay, ich mach die verdammte Lieferung..."

    # say L1553 sis
    old "Hahaha remember is for the ‘business'."
    new "Ha ha ha, das ist fürs Geschäft."

    # say L1555 sis
    old "Alright, let me know when it's done, see you later."
    new "Okay, lass es mich wissen, wenn es erledigt ist, bis später."

    # say L1558 pla
    old "(Hmmm I hope it isn't anyone I know like last time.)"
    new "Hmm, ich hoffe, es ist niemand, den ich kenne, wie letztes Mal."

    # say L1562 pla
    old "(Alright, is here...)"
    new "(In Ordnung, hier ist es...)"

    # say L1564 ana
    old "Good morning, how can I help you?"
    new "Guten Morgen, wie kann ich dir helfen?"

    # say L1567 pla
    old "G-good morning, Mrs. Anastasia? Here is your package!"
    new "Guten Morgen, Anastasia? Hier ist dein Paket!"

    # say L1568 ana
    old "Oh, Thank you so much! So? Are you the business guy behind this?"
    new "Oh, danke schön! Also? Bist du der Geschäftsmann hinter alldem?"

    # say L1569 pla
    old "Oh no, this is my [sisrel] business, I'm just helping."
    new "Oh nein, das ist mein [sisrel] Geschäft, ich helfe nur."

    # say L1570 ana
    old "That's so sweet, She is very lucky to have a handsome young man like you helping."
    new "Das ist ja süß, sie hat großes Glück, einen attraktiven jungen Mann wie dich zu haben, der ihr hilft."

    # say L1571 pla
    old "Thanks... We are trying to get some extra income."
    new "Danke... Wir versuchen ein bisschen extra Geld zu verdienen."

    # say L1574 ana
    old "I like your products, surely I will look forward to knowing more about you guys."
    new "Ich mag eure Produkte, ich freue mich darauf, mehr über euch zu erfahren."

    # say L1575 ana
    old "Specially you, sweety."
    new "Vor allem dich, Schatz."

    # say L1576 pla
    old "Hmmm... T-thanks."
    new "Hmmm... D-danke."

    # say L1577 ana
    old "My pleasure, see you later sweetheart..."
    new "Mein Vergnügen, bis später, Liebling."

    # say L1579 pla
    old "(What a nice lady.)"
    new "Was für eine nette Lady."

    # say L1585 pla
    old "Well, I am back."
    new "Na, ich bin wieder da."

    # say L1586 sis
    old "How was it? I'm kind of busy, but let me know everything."
    new "Wie war es? Ich bin ziemlich beschäftigt, aber erzähl mir alles."

    # say L1587 pla
    old "She was very interested in the clothes."
    new "Sie war sehr interessiert an den Klamotten."

    # say L1588 sis
    old "Great, what did you tell her?"
    new "Super, was hast du ihr erzählt?"

    # say L1589 pla
    old "The common stuff, you know, I said hello, the information of the delivery."
    new "Die üblichen Sachen, du weißt schon, ich hab hallo gesagt und die Infos zur Lieferung gegeben."

    # say L1590 pla
    old "She mentioned she will order more."
    new "Sie hat erwähnt, dass sie mehr bestellen wird."

    # say L1591 sis
    old "Fantastic, I will need your help next time, so she feels engaged with the purchase."
    new "Fantastisch, ich werde deine Hilfe beim nächsten Mal brauchen, damit sie sich mit dem Kauf verbunden fühlt."

    # say L1592 sis
    old "Let me continue... I have more and more customers messaging."
    new "Lass mich weitermachen... Ich habe immer mehr Kunden, die mir schreiben."

    # say L1595 pla
    old "Sure, you are very welcome!"
    new "Klar, du bist sehr willkommen!"

    # say L1615 sis
    old "You ready for the pics? I've been waiting for you."
    new "Bist du bereit für die Fotos? Ich habe schon auf dich gewartet."

    # say L1616 pla
    old "Oh right, I'm going for the camera, I'll see you in your bedroom."
    new "Oh richtig, ich geh zur Kamera, bis gleich in deinem Schlafzimmer."

    # say L1624 pla
    old "(Holy shit!)"
    new "Scheiße!"

    # say L1625 sis
    old "Finally, I have good ideas for today's session."
    new "Endlich, ich habe gute Ideen für die heutige Session."

    # say L1626 sis
    old "What do you think? Do I look beautiful?"
    new "Was denkst du? Sehe ich schön aus?"

    # say L1627 pla
    old "Gulp... (Wow, she is really hot) I think you look very... N-nice."
    new "Gulp... (Wow, sie ist wirklich heiß) Ich denke, du siehst sehr... N-nice aus."

    # say L1628 sis
    old "Great... But, before we start do you think, you need any... Help?"
    new "Super... Aber bevor wir anfangen, denkst du, du brauchst vielleicht ein bisschen... Hilfe?"

    # say L1629 pla
    old "What do you mean? I have the camera and everything..."
    new "Was meinst du? Ich habe die Kamera und alles..."

    # say L1630 sis
    old "I mean if you need to 'relax' before we start..."
    new "Ich meine, ob du dich vorher ein bisschen entspannen musst..."

    # say L1631 pla
    old "I-I don't understand..."
    new "Ich-ich verstehe nicht..."

    # say L1632 sis
    old "I mean, don't be flushed I know you got hard last time and is totally normal..."
    new "Ich meine, du musst dich doch nicht schämen, ich weiß, dass du letztes Mal hart geworden bist und das ist total normal..."

    # say L1634 sis
    old "It's because of the clothes I'm wearing, I think it's fair, you know, you help me, I can help you too and I already did, didn't I?"
    new "Ich denke, es ist nur fair, du weißt schon, du hilfst mir und ich kann dir auch helfen, oder?"

    # say L1635 pla
    old "I'm not sure if it's okay..."
    new "Ich bin mir nicht sicher, ob das in Ordnung ist..."

    # say L1636 sis
    old "Oh come on, you're not going to take good pictures if you're hard the whole session..."
    new "Oh komm schon, du wirst keine guten Fotos machen, wenn du die ganze Zeit steif bist..."

    # say L1637 sis
    old "It's because of business, remember?"
    new "Es ist wegen der Arbeit, oder?"

    # say L1639 sis
    old "Great, take off your pants I'm going to suck you off..."
    new "Na gut, zieh deine Hose aus, ich mache dich fertig..."

    # say L1640 pla
    old "W-WHAT?! Are you going to suck-..."
    new "W-WAS?! Willst du mich etwa blasen..."

    # say L1641 sis
    old "Well... You did a great job with the deliveries, I think you deserve a reward, don't you think?"
    new "Na ja... Du hast super bei den Lieferungen mitgemacht, ich denke, du hast dir eine Belohnung verdient, oder?"

    # say L1643 sis
    old "By the way, I'll have to take off my clothes, just to be sure I don't stain the clothes for the photos..."
    new "Übrigens, ich muss mich ausziehen, nur um sicherzustellen, dass ich die Klamotten für die Fotos nicht versaue..."

    # say L1644 sis
    old "Does it bother you?"
    new "Stört dich das?"

    # say L1646 sis
    old "Hahaha you will love it..."
    new "Hahaha, du wirst es lieben..."

    # say L1663 sis
    old "I hope you are relaxed now, so let's do it!"
    new "Ich hoffe, du bist jetzt entspannt, lass uns es tun!"

    # say L1678 sis
    old "You think this way it looks good?"
    new "Du findest, dass es so gut aussieht?"

    # say L1679 pla
    old "Absolutely."
    new "Absolut."

    # say L1680 pla
    old "Let me be sure the skirt stands out. I will take a pic of entire clothes."
    new "Lass mich sicherstellen, dass der Rock gut zur Geltung kommt. Ich mache ein Foto von deiner gesamten Outfit."

    # say L1715 pla
    old "Yes, let's do the next one from another position."
    new "Ja, machen wir das nächste von einer anderen Position."

    # say L1716 sis
    old "Great! I saw one I want to try."
    new "Super! Ich hab eine im Kopf, die ich ausprobieren will."

    # say L1717 pla
    old "Sure, what do you have on mind?"
    new "Klar, was hast du im Sinn?"

    # say L1718 sis
    old "I want to take some pics on the bed."
    new "Ich will ein paar Fotos auf dem Bett machen."

    # say L1719 pla
    old "Well, we haven't done anything like that before. Let's do it!"
    new "Na klar, wir haben das noch nie gemacht. Lass es uns tun!"

    # say L1720 pla
    old "Lay down on the bed but leave the legs out of the bed so we can see your butt."
    new "Leg dich aufs Bett, aber lass die Beine raus, damit wir deinen Hintern sehen können."

    # say L1721 sis
    old "Nicee."
    new "Nett."

    # say L1731 sis
    old "I hope it looks sexy."
    new "Ich hoffe, es sieht sexy aus."

    # say L1732 pla
    old "(Holy shit...) I-I am sure you're gonna love these."
    new "(Holy Shit...) Ich bin sicher, du wirst die lieben."

    # say L1733 pla
    old "But let me try to catch a bit more, your legs must look huge."
    new "Aber lass mich noch ein bisschen mehr einfangen, deine Beine müssen riesig aussehen."

    # say L1759 pla
    old "I think I have it."
    new "Ich denke, ich hab's."

    # say L1768 pla
    old "Ok, for the next picture I need you to turn around please, I want to try an option like the last time but slightly different."
    new "Ok, für das nächste Bild musst du dich bitte umdrehen, ich will eine Variante von letztes Mal ausprobieren, aber ein bisschen anders."

    # say L1769 pla
    old "Do not look at the camera and try to lift a bit more your butt, hold your hair with one hand."
    new "Schau nicht in die Kamera und versuch, deinen Hintern ein bisschen höher zu heben, halte dein Haar mit einer Hand."

    # say L1770 sis
    old "Ohh, I like it!"
    new "Ohh, ich mag es!"

    # say L1781 pla
    old "It's perfect."
    new "Es ist perfekt."

    # say L1806 pla
    old "Ok, I think we are done."
    new "Okay, ich denke, wir sind fertig."

    # say L1814 sis
    old "Awesome!!! Let me see them!"
    new "Super!!! Lass sie mir sehen!"

    # say L1819 pla
    old "Ok... Gallery... Done"
    new "Ok... Galerie... Fertig"

    # say L1854 pla
    old "I do not know what's happening today, these photos are not sharp enough."
    new "Ich hab keine Ahnung, was heute los ist, diese Fotos sind nicht scharf genug."

    # say L1855 sis
    old "We will need to try again, this material is important. "
    new "Wir müssen es noch mal versuchen, das Material ist wichtig."

    # say L1856 pla
    old "Yes, I am sure we can make it a lot better."
    new "Ja, ich bin sicher, wir können es viel besser machen."

    # say L1857 pla
    old "I just need to practice more."
    new "Ich muss einfach mehr üben."

    # say L1858 sis
    old "I need you to put more effort, we can't keep wasting time like this."
    new "Ich brauche mehr Engagement von dir, wir können nicht so weitermachen."

    # say L1859 pla
    old "It won't happen again!"
    new "Es passiert nicht nochmal!"

    # say L1884 sis
    old "Wow, we're on fire!"
    new "Wow, wir sind richtig in Fahrt!"

    # say L1885 sis
    old "Look at me, so hot. I like your job and I'm not talking about the pics only."
    new "Schau mich an, so heiß. Mir gefällt deine Arbeit und ich rede nicht nur von den Bildern."

    # say L1886 pla
    old "We are doing a great job."
    new "Wir machen echt eine tolle Arbeit."

    # say L1887 sis
    old "Yes, everyday I have more customers, you're a big help."
    new "Ja, jeden Tag habe ich mehr Kunden, du bist eine große Hilfe."

    # say L1888 sis
    old "I will go ahead to upload this content on the website."
    new "Ich werde das jetzt auf der Website hochladen."

    # say L1889 pla
    old "Ok, bye."
    new "Okay, tschüss."

    # say L1910 sis
    old "Hey, now that you are here, do you remember Mrs Anastasia? Well, she placed another order, it was mostly the last ones we took pics of!"
    new "Hey, da du jetzt hier bist, erinnerst du dich noch an Mrs Anastasia? Sie hat wieder eine Bestellung aufgegeben, hauptsächlich die letzten Fotos, die wir gemacht haben!"

    # say L1911 sis
    old "Need you to be really nice with her, I'm sure, she will buy anything we post later!"
    new "Du musst echt nett zu ihr sein, ich bin sicher, sie wird alles kaufen, was wir später posten!"

    # say L1912 sis
    old "So you better give her amazing customer service, don't want you to mess things up with her."
    new "Dann gib ihr halt richtig guten Service, wir wollen doch nicht, dass du bei ihr versagst."

    # say L1913 pla
    old "Ok... I'll go right away."
    new "Okay... Ich geh gleich."

    # say L1914 sis
    old "Don't forget to be really kind, she is a very important client."
    new "Vergiss nicht, wirklich nett zu sein, sie ist eine sehr wichtige Kundin."

    # say L1916 pla
    old "Yes, yes, I know!"
    new "Ja, ja, ich weiß!"

    # say L1922 pla
    old "Good morning Mrs, I have another package for you!"
    new "Guten Morgen, ich habe noch ein Paket für Sie!"

    # say L1923 ana
    old "Oh, it's you again, you came really fast, Thank you very much!"
    new "Oh, du bist es wieder, du warst wirklich schnell, vielen Dank!"

    # say L1924 pla
    old "We really appreciate your purchase."
    new "Wir schätzen deine Bestellung wirklich."

    # say L1925 ana
    old "I do appreciate how much of a gentleman you are."
    new "Ich schätze es wirklich, wie ein Gentleman du bist."

    # say L1926 pla
    old "Hmmm, thank you... Uhh this is your package."
    new "Hmmm, danke... Uhh das ist dein Paket."

    # say L1927 ana
    old "Thank you sweety!"
    new "Danke Schatz!"

    # say L1932 ana
    old "You know what? you deserve a tip."
    new "Du weißt was? Du verdienst ein Trinkgeld."

    # say L1933 pla
    old "Oh please don't worry..."
    new "Oh bitte, mach dir keine Sorgen..."

    # say L1934 ana
    old "Give me just a second, your kindness deserves compensation."
    new "Gib mir einfach eine Sekunde, deine Freundlichkeit verdient eine Belohnung."

    # say L1935 pla
    old "It's not necessary, I am very glad to bring your package."
    new "Das ist nicht nötig, ich freue mich sehr, deinen Karton zu bringen."

    # say L1936 ana
    old "Do not dare to leave!"
    new "Trau dich nicht wegzulaufen!"

    # say L1948 ana
    old "I beg your pardon... Can't find my purse."
    new "Entschuldigung... Ich finde meine Handtasche nicht."

    # say L1949 pla
    old "Do not worry, it's not a problem."
    new "Mach dir keine Sorgen, das ist kein Problem."

    # say L1950 ana
    old "Oh no, you deserve it."
    new "Oh nein, du hast es verdient."

    # say L1951 ana
    old "Let me see if I could have something here... Hope you like it."
    new "Lass mich sehen, ob ich hier was habe... Hoffe, dir gefällt es."

    # say L1953 pla
    old "(Wow) ..."
    new "Wow..."

    # say L1954 ana
    old "(He's so shy... Hehehe, can't even speak.)"
    new "Er ist ja so schüchtern... Hehehe, kann gar nicht sprechen."

    # say L1955 pla
    old "Gulp, tha-... Thank you."
    new "Gulp, danke..."

    # say L1957 ana
    old "Hehehe, You are kind of tender."
    new "Hehehe, du bist ja richtig zartbesaitet."

    # say L1958 ana
    old "I hope I can see you next time, I'll have cash handy. Bye handsome!"
    new "Ich hoffe, ich sehe dich beim nächsten Mal, ich hab dann Bargeld dabei. Tschüss, Schönling!"

    # say L1966 sis
    old "Was everything alright?"
    new "Alles in Ordnung?"

    # say L1967 pla
    old "Definitely, she is amazing!"
    new "Definitiv, sie ist unglaublich!"

    # say L1968 sis
    old "(Amazing?) Hmm ok, thank you!"
    new "(Amazing?) Hmm okay, danke!"

    # say L1969 sis
    old "Does she like the products."
    new "Mag sie die Produkte?"

    # say L1970 pla
    old "She seemed to be very interested about the new products."
    new "Sie schien sich sehr für die neuen Produkte zu interessieren."

    # say L1971 sis
    old "That's fascinating."
    new "Das ist faszinierend."

    # say L1972 sis
    old "Hope you are doing your part, so she definitely keeps her business with us."
    new "Hoffe, du machst deinen Teil, damit sie definitiv weiter mit uns Geschäfte macht."

    # say L1974 sis
    old "Besides, I need you to get prepared, we have more products coming."
    new "Außerdem musst du dich vorbereiten, wir kriegen bald mehr Produkte."

    # say L1976 sis
    old "Yes, we need to work hard."
    new "Ja, wir müssen hart arbeiten."

    # say L1977 pla
    old "Uhh, let's see what happens."
    new "Uhh, lass uns sehen, was passiert."

    # say L1978 sis
    old "You can be sure it's worth."
    new "Du kannst dir sicher sein, dass es sich lohnt."

    # say L2002 sis
    old "Come on [pla]! Time is money and you're late, let's go to the pool."
    new "Komm schon [pla]! Zeit ist Geld und du bist spät dran, lass uns zum Pool gehen."

    # say L2003 pla
    old "To the p-pool?"
    new "Zum P-Pool?"

    # say L2004 sis
    old "Yep, the pool. Summer is coming, bikinis are amazing so I need all your effort today."
    new "Klar, der Pool. Der Sommer kommt und Bikinis sind einfach toll, also brauche ich heute dein ganzes Engagement."

    # say L2005 sis
    old "We are selling new things and people are crazy with the new summer alternatives."
    new "Wir verkaufen neue Sachen und die Leute flippen total für die neuen Sommermodelle."

    # say L2007 sis
    old "Do you need some help before we start?"
    new "Willst du vorher Hilfe?"

    # say L2009 sis
    old "I mean do you want me to suck your dick, because at the pool it's not that easy. "
    new "Ich meine, willst du, dass ich deinen Schwanz lutsche, denn im Pool ist das nicht so einfach."

    # say L2010 sis
    old "And don't beat around the bush!"
    new "Und hör auf, rumzudrücken!"

    # say L2016 pla
    old "I-I am not sure."
    new "Ich bin mir nicht sicher."

    # say L2017 sis
    old "Do you want it or not?"
    new "Willst du es oder nicht?"

    # say L2019 sis
    old "We don't have time to lose I will take it as a yes..."
    new "Wir haben keine Zeit zu verlieren, ich nehme das als Ja..."

    # say L2020 sis
    old "I'm going to make you cum fast..."
    new "Ich werde dich schnell kommen lassen..."

    # say L2044 sis
    old "I hope you're better now, let's do it!"
    new "Ich hoffe, es geht dir besser, lass uns loslegen!"

    # say L2052 sis
    old "Oh, I will love the pics today, look at the sun, the pool, everything in its right place."
    new "Oh, ich freue mich auf die Fotos heute, schau dir die Sonne an, den Pool, alles ist perfekt."

    # say L2053 pla
    old "Yeah I couldn't ask for a better light and place."
    new "Klar, ich könnte mir keinen besseren Lichtstand und Ort wünschen."

    # say L2054 sis
    old "Don't lose more time, let's start."
    new "Verlier keine Zeit mehr, lass uns anfangen."

    # say L2055 pla
    old "You're right. Stay right there, let me start with a full body!"
    new "Du hast recht. Bleib so, ich fang mit einem Vollkörperbild an!"

    # say L2056 sis
    old "Ok, I will stay like this."
    new "Okay, ich bleibe so."

    # say L2057 pla
    old "I think you should look to the right, to get a better perspective..."
    new "Ich denke, du solltest nach rechts schauen, um eine bessere Perspektive zu kriegen..."

    # say L2058 sis
    old "Alright, you are the nerd..."
    new "Okay, du bist der Nerd..."

    # say L2073 pla
    old "Wonderful, the light is perfect, your hair looks very bright."
    new "Wunderbar, das Licht ist perfekt, deine Haare sehen sehr hell aus."

    # say L2074 sis
    old "Perfect, make sure I look sexy."
    new "Perfekt, sorg dafür, dass ich sexy aussehe."

    # say L2102 pla
    old "Got it!"
    new "Verstanden!"

    # say L2111 pla
    old "It would be more interesting if we take advantage of some elements of the place."
    new "Es wäre interessanter, wenn wir einige Elemente des Ortes nutzen."

    # say L2112 sis
    old "Hmmm, what do you think about the pool?"
    new "Hmmm, was denkst du über den Pool?"

    # say L2113 pla
    old "I don't think so, we need the clothes dry."
    new "Ich denke nicht, wir brauchen die Klamotten trocken."

    # say L2114 pla
    old "You now what? Go to the chair, something casual, let's use those glasses you have."
    new "Du weißt schon, geh zu dem Stuhl, etwas Casual, lass uns die Gläser benutzen, die du hast."

    # say L2115 sis
    old "Yes, just like that, that's perfect."
    new "Ja, genau so, das ist perfekt."

    # say L2126 pla
    old "Perfect, try to hold the glasses with your hands."
    new "Perfekt, versuch die Brille mit den Händen zu halten."

    # say L2127 sis
    old "Try to show my boobs a bit more, I want them to stand out."
    new "Versuch, meine Titten noch ein bisschen mehr zu zeigen, ich will, dass sie richtig zur Geltung kommen."

    # say L2128 pla
    old "I think this is the pic you're looking for."
    new "Ich denke, das ist das Bild, nach dem du suchst."

    # say L2153 pla
    old "Ok, next photo..."
    new "Ok, nächste Foto..."

    # say L2161 pla
    old "I have a great idea, let's show a different emotion."
    new "Ich hab eine tolle Idee, lass uns eine andere Emotion zeigen."

    # say L2162 sis
    old "I am listening..."
    new "Ich höre zu..."

    # say L2163 pla
    old "Let's take advantage of the pool but I don't want the same poses we already tried before, I want to do something unexpected."
    new "Lass uns das Schwimmbad nutzen, aber ich will nicht die gleichen Posen wie letztes Mal, ich will was Unerwartetes machen."

    # say L2164 pla
    old "Hmm, turn around and try to look at me, but close your eyes..."
    new "Hmm, dreh dich um und versuch mich anzusehen, aber schließ deine Augen..."

    # say L2165 sis
    old "With my eyes closed? Alright, let me try it."
    new "Mit geschlossenen Augen? Okay, ich probier's mal."

    # say L2176 pla
    old "keep that smile, do not change your face."
    new "halt das Lächeln, ändere dein Gesicht nicht"

    # say L2177 pla
    old "That's a plot twist."
    new "Das ist eine Plotwende."

    # say L2178 pla
    old "I like it."
    new "Ich mag es."

    # say L2202 pla
    old "Ok, I think that's it."
    new "Okay, ich glaube, das war's."

    # say L2214 pla
    old "Ok... Here they are."
    new "Ok... Hier sind sie."

    # say L2247 pla
    old "I don't know what's happening today, they are not sharp enough."
    new "Ich hab keine Ahnung, was heute los ist, sie sind einfach nicht scharf genug."

    # say L2251 sis
    old "I need you to put more effort, we can't waste time like today."
    new "Du musst mehr Einsatz zeigen, wir können keine Zeit verschwenden wie heute."

    # say L2253 sis
    old "Hmm, look for me to repeat the sesion again..."
    new "Hmm, sieh zu, dass du die Sache noch mal wiederholst..."

    # say L2276 sis
    old "I like them, but there's something not working."
    new "Ich mag sie, aber da ist was, das nicht klappt."

    # say L2277 pla
    old "What's not working? I can check, so you like them more."
    new "Was funktioniert nicht? Ich kann es überprüfen, damit du sie mehr magst."

    # say L2278 sis
    old "Oh no, it's not you, I need some sunbathing."
    new "Oh nein, es ist nicht du, ich brauche einfach etwas Sonnenbaden."

    # say L2279 sis
    old "Don't you think so?"
    new "Findest du nicht auch?"

    # say L2280 pla
    old "I think you look great."
    new "Ich finde, du siehst toll aus."

    # say L2281 sis
    old "Hehehe of course... "
    new "Hehehe natürlich..."

    # say L2282 sis
    old "Anyway, I'm going work on the website, have a good one."
    new "Na ja, ich werde mich mal um die Website kümmern, hab einen schönen Tag."

    # say L2310 sis
    old "Glad that you came, quite on time to apply my sunscreen, can you help me?"
    new "Schön, dass du gekommen bist, gerade noch rechtzeitig, um mir den Sonnenmilch einzucremen, kannst du mir helfen?"

    # say L2312 sis
    old "I can show you how to do it... Let's start with my boobs."
    new "Ich zeig dir, wie es geht... Fangen wir mit meinen Titten an."

    # say L2313 pla
    old "Your... Wh- What?"
    new "Deine... Was?"

    # say L2314 sis
    old "My boobs, I need to show the bikinis, so my boobs are important. And you see them all the time in the photoshoots."
    new "Meine Brüste, ich muss die Bikinis zeigen, also sind meine Brüste wichtig. Und du siehst sie ständig bei den Fotoshoots."

    # say L2315 pla
    old "Hmmm... Alright..."
    new "Hmmm... Okay..."

    # say L2319 pla
    old "Wow! What are you doing?"
    new "Wow! Was machst du da?"

    # say L2320 sis
    old "Taking off my bra, you weren't pretending to tan my breasts with it on, did you?"
    new "Ich ziehe mein BH aus, oder hast du vor, meine Brüste mit dem BH drunter einzucremen?"

    # say L2321 pla
    old "So you want me to apply the sunscreen like thi-"
    new "Dann willst du also, dass ich das Sonnenöl so auftrage-"

    # say L2322 sis
    old "Oh, shut up... You and I both know you're dying to touch them..."
    new "Oh, halt die Klappe... Du und ich wissen beide, dass du sie am liebsten anfassen würdest..."

    # say L2323 sis
    old "And I just want a good massage and sunbathe to get a tan."
    new "Und ich will einfach nur eine gute Massage und mich sonnen, um einen Teint zu bekommen."

    # say L2325 sis
    old "So stop acting like an idiot and play with my babies..."
    new "Dann hör auf, wie ein Idiot zu tun, und spiele mit meinen Babys..."

    # say L2336 sis
    old "Do you want more, [pla]?"
    new "Willst du mehr, [pla]?"

    # say L2338 sis
    old "Don't try to hide it from me... I know you're hard already."
    new "Versuch es nicht vor mir zu verstecken... Ich weiß, dass du schon hart bist."

    # say L2339 pla
    old "I-I don't know what you mea-"
    new "Ich hab keine Ahnung, wovon du redest"

    # say L2340 sis
    old "Let me give you a clue... I've heard cum is a great treatment for the skin, so I wanted to test it on my boobs."
    new "Lass mich dir einen Tipp geben... Ich habe gehört, dass Sperma eine tolle Hautpflege ist, deshalb wollte ich es mal auf meinen Titten ausprobieren."

    # say L2341 pla
    old "W-What!?... "
    new "W-Was!?..."

    # say L2342 sis
    old "Shut up and come here..."
    new "Halt die Klappe und komm her..."

    # say L2358 sis
    old "Did you enjoy it?"
    new "Hast du es genossen?"

    # say L2359 pla
    old "Yeah!"
    new "Klar!"

    # say L2360 sis
    old "I would love to have this skin care therapy more often."
    new "Ich würde mich freuen, diese Hautpflege-Therapie öfter zu genießen."

    # say L2361 sis
    old "I'll enjoy the sun, thank you."
    new "Ich werde die Sonne genießen, danke."

    # say L2362 pla
    old "You're welcome, see you later!"
    new "Gern geschehen, bis später!"

    # say L2385 sis
    old "Oh, you came at the right time."
    new "Oh, du kommst gerade richtig."

    # say L2387 sis
    old "Fortunately there is good news, I want to tell you something to cheer you up a bit."
    new "Zum Glück gibt es gute Nachrichten, ich will dir was erzählen, um dich ein bisschen aufzumuntern."

    # say L2389 sis
    old "The bikini session was great, Anastasia ordered again."
    new "Die Bikini-Sitzung war toll, Anastasia hat wieder bestellt."

    # say L2391 sis
    old "I need you to be nice with her again, so she feels comfortable."
    new "Ich brauche dich, um wieder nett zu ihr zu sein, damit sie sich wohl fühlt."

    # say L2392 pla
    old "Ok, I will."
    new "Okay, ich werd's machen."

    # say L2393 sis
    old "You already know her place, remember, that everything you do is really important."
    new "Du weißt schon, wo sie steht, oder? Denk dran, dass alles, was du tust, wirklich wichtig ist."

    # say L2401 pla
    old "Good morning Mrs."
    new "Guten Morgen, Frau."

    # say L2402 ana
    old "Oh what a nice surprise, It's my favorite delivery boy!"
    new "Oh was für eine nette Überraschung, das ist mein Lieferjunge!"

    # say L2403 pla
    old "Hehehe, Thank you, I am glad to see you too."
    new "Hehehe, Danke, ich freue mich auch, dich zu sehen."

    # say L2404 pla
    old "Here you are!"
    new "Hier bist du!"

    # say L2409 ana
    old "Thank you, you're so kind."
    new "Danke, du bist so lieb."

    # say L2410 pla
    old "I hope you enjoy your purchase, have a nice day!"
    new "Ich hoffe, dir gefällt dein Kauf, und einen schönen Tag noch!"

    # say L2411 ana
    old "Oh, are you planning on leaving already? Actually I was considering to ask you for a big favor and I have nobody else to help me."
    new "Oh, willst du schon gehen? Eigentlich wollte ich dich um einen großen Gefallen bitten und habe niemand anderen, der mir helfen könnte."

    # say L2412 ana
    old "I think since you're a man you could help me."
    new "Ich denke, da du ein Mann bist, könntest du mir helfen."

    # say L2413 pla
    old "(I have to make her feel comfortable, she's our best client.)"
    new "Klar, wie kann ich dir helfen?"

    # say L2414 ana
    old "It won't take you too long, I promise."
    new "Es dauert nicht lange, versprochen."

    # say L2415 pla
    old "Oh, sure, how can I help you?"
    new "Oh, klar, wie kann ich dir helfen?"

    # say L2416 ana
    old "Please come in."
    new "Bitte komm rein."

    # say L2424 ana
    old "Just wait a second, I will be right back."
    new "Warte kurz, ich bin gleich wieder da."

    # say L2438 pla
    old "(Wow, Wow!)"
    new "Wow, Wow!"

    # say L2439 ana
    old "I needed a second opinion, and I just thought you could help."
    new "Ich brauchte eine zweite Meinung und dachte, du könntest mir helfen."

    # say L2440 ana
    old "Please be honest, do you like it?"
    new "Sei ehrlich, gefällt es dir?"

    # say L2441 pla
    old "Gulp, You look..."
    new "Gulp, Du siehst..."

    # say L2443 pla
    old "No, no, no, of course not, You look... A-amazing."
    new "Nein, nein, nein, natürlich nicht, Du siehst... A-ama... w-wunderbar aus."

    # say L2445 pla
    old "Y-Yes... I- I am being really honest."
    new "Y-Yeah... I-Ich bin wirklich ehrlich."

    # say L2448 pla
    old "(Oh shit... I'm getting hard.)"
    new "Oh Scheiße... ich werde hart."

    # say L2449 ana
    old "Wow dear, what you got in there?"
    new "Wow Schatz, was hast du da drin?"

    # say L2450 pla
    old "I'm sorry, I didn't mean to-"
    new "Entschuldigung, ich wollte nicht-"

    # say L2451 ana
    old "Ohh, You are very sweet, I apologize for this, I didn't mean to make you feel uncomfortable."
    new "Ohh, du bist sehr süß, ich entschuldige mich dafür, ich wollte dich nicht unbehaglich machen."

    # say L2453 pla
    old "I-I am sorry, I-I... Just should leave."
    new "Ich-ich bin sorry, ich... Sollte einfach gehen."

    # say L2454 ana
    old "Oh no, please let me apologize correctly, you can't leave like that."
    new "Oh nein, lass mich das richtig machen, du kannst nicht einfach so gehen."

    # say L2456 ana
    old "I think you deserve a bigger tip this time due to this big inconvenience."
    new "Ich denke, du verdienst dieses Mal ein größeres Trinkgeld wegen dieser großen Unannehmlichkeit."

    # say L2459 ana
    old "How about if you just relax a little bit on the couch and let me fix this with my own hands. "
    new "Wie wäre es, wenn du dich einfach ein bisschen auf die Couch zurücklehnen lässt und ich das mit meinen eigenen Händen wieder in Ordnung bringe."

    # say L2466 ana
    old "Please, relax and let me compensate for the situation, just close your eyes and enjoy."
    new "Bitte, entspann dich und lass mich die Situation ausgleichen, einfach die Augen schließen und genießen."

    # say L2478 ana
    old "I hope you liked it..."
    new "Ich hoffe, dir hat es gefallen..."

    # say L2479 pla
    old "Uhh... Y-yes, thank you"
    new "Uhh... J-ja, danke"

    # say L2480 ana
    old "Alright sweetie, thanks for your help, it was very clear to me that this bikini suits me very well... I hope to see you in my next delivery."
    new "Okay Schatz, danke für deine Hilfe, es war sehr deutlich, dass mir dieser Bikini wirklich gut steht... Ich freue mich darauf, dich bei meiner nächsten Lieferung zu sehen."

    # say L2481 pla
    old "(Wow, I'm starting to love this job)"
    new "Wow, ich fange an, diesen Job zu lieben."

    # say L2482 pla
    old "Of course, I'll bring your next purchase."
    new "Natürlich, ich bringe deine nächste Bestellung."

    # say L2483 ana
    old "That sounds great..."
    new "Das klingt toll..."

    # say L2492 sis
    old "Hey, you are back."
    new "Hey, du bist wieder da."

    # say L2493 pla
    old "Yep."
    new "Klar."

    # say L2494 sis
    old "So? Everything went alright?"
    new "Und? Alles gut gelaufen?"

    # say L2495 pla
    old "It was... Wonderful."
    new "Es war... wunderbar."

    # say L2496 sis
    old "(Wonderful?) Hmm, ok thanks for your help."
    new "(Wunderbar?) Hmm, ok danke für deine Hilfe."

    # say L2497 sis
    old "Did she like it?"
    new "Hat sie es denn gemocht?"

    # say L2498 pla
    old "Yeah, she loved it."
    new "Ja, sie hat es geliebt."

    # say L2499 sis
    old "How are you so sure about it?"
    new "Wie kannst du dir da so sicher sein?"

    # say L2500 pla
    old "Well... Is the second time she purchases, so she liked the first one."
    new "Na ja... Es ist das zweite Mal, dass sie es kauft, also hat sie das erste Mal wohl gemocht."

    # say L2501 sis
    old "Ok... I'll let you know once we are ready for the next photography session."
    new "Ok... Ich geb dir Bescheid, sobald wir bereit für die nächste Fotosession sind."

    # say L2502 pla
    old "I'll look forward to it."
    new "Ich freu mich drauf."

    # say L2529 sis
    old "Uhh... I am so horny, I'll need more."
    new "Uhh... Ich bin so geil, ich brauche mehr."

    # say L2531 pla
    old "(Oh shit... She saw me!)"
    new "Oh Scheiße... Sie hat mich gesehen!"

    # say L2539 sis
    old "I know you have been there for a while."
    new "Ich weiß, dass du schon eine Weile da bist."

    # say L2540 pla
    old "Sorry... I-I was just-"
    new "Entschuldigung... Ich hab' nur-"

    # say L2541 sis
    old "It's ok dummy! I think it is time to get paid back."
    new "Es ist okay, Dummerchen! Ich denke, es ist Zeit, dass du mir zurückzahlst."

    # say L2543 sis
    old "I mean, I need you to pay me back, I know that you have more than enough to give."
    new "Ich meine, ich brauche das Geld zurück, ich weiß, dass du genug hast, um es mir zu geben."

    # say L2545 sis
    old "Come here, let me suck that big dick."
    new "Komm her, lass mich deinen großen Schwanz blasen."

    # say L2550 sis
    old "Grab my head and fuck my mouth!"
    new "Nimm meinen Kopf und fick meinen Mund!"

    # say L2560 sis
    old "Oh, shit. I can't handle it anymore... Want you to fuck me, I need you inside of me now."
    new "Oh, Scheiße. Ich kann das nicht mehr aushalten... Ich will, dass du mich fickst, ich brauche dich jetzt in mir."

    # say L2562 sis
    old "Come here and fuck your [sisrel]... Fuck me hard [pla]!"
    new "Komm her und fick deinen [sisrel]... Fick mich hart [pla]!"

    # say L2578 sis
    old "Wow, you did great!"
    new "Wow, das war toll gemacht!"

    # say L2580 sis
    old "Ugh, I got really tired, that was pretty intense."
    new "Ugh, ich bin echt müde, das war ziemlich intensiv."

    # say L2582 sis
    old "Anyway, I'm gonna need some of your skills tomorrow too."
    new "Na ja, ich werde morgen auch wieder auf deine Fähigkeiten zählen."

    # say L2584 sis
    old "Hahaha, I'm talking about the photshoot, dummy. I'm preparing a new one, so, I count on you."
    new "Ha ha ha, ich rede von der Fotosession, Dummerchen. Ich bereite eine neue vor, also zähle ich auf dich."

    # say L2585 pla
    old "Sure, I'll be ready."
    new "Klar, ich bin bereit."

    # say L2586 sis
    old "Now leave me alone. I just want to rest..."
    new "Lass mich jetzt in Ruhe. Ich will nur ausruhen."

    # say L2587 pla
    old "Hmm, alright... See you later."
    new "Hmm, okay... Bis später."

    # say L2609 sis
    old "Hey, did you sleep well?"
    new "Hey, hast du gut geschlafen?"

    # say L2610 pla
    old "Yeah, pretty well!"
    new "Ja, ziemlich gut!"

    # say L2611 sis
    old "Good, that means we're gonna rock today!"
    new "Gut, dann werden wir heute richtig abrocken!"

    # say L2644 sis
    old "I will be at the pool, don't be late."
    new "Ich bin am Pool, komm nicht zu spät."

    # say L2645 pla
    old "I'm going to pick up the camera and see you there."
    new "Ich hole die Kamera und sehe dich da."

    # say L2652 sis
    old "This is the newest collection, what do you think?"
    new "Das ist die neueste Kollektion, was denkst du?"

    # say L2653 pla
    old "Really? It's pretty nice!"
    new "Wirklich? Ist ziemlich toll!"

    # say L2654 pla
    old "I have some ideas for today."
    new "Ich hab ein paar Ideen für heute."

    # say L2655 sis
    old "Awesome, what are we waiting for?"
    new "Super, worauf warten wir noch?"

    # say L2656 pla
    old "Ok, let's start with you standing up in front of the pool for a full body one."
    new "Okay, stell dich vor dem Pool auf, damit ich dich von oben bis unten fotografieren kann."

    # say L2669 sis
    old "Ok, do I look good like this?"
    new "Ok, sehe ich so gut aus?"

    # say L2670 pla
    old "Yeah, keep your hand there, do not move... It looks more fancy."
    new "Ja, lass deine Hand da, beweg dich nicht... So sieht es eleganter aus."

    # say L2706 pla
    old "Now I want try something special."
    new "Jetzt will ich was Besonderes ausprobieren."

    # say L2707 sis
    old "Tell me what to do."
    new "Sag mir, was ich tun soll."

    # say L2708 pla
    old "Please get on your knees, looking at me very very enticingly and to move your shoulders a bit ahead of your body..."
    new "Bitte knie dich hin, schau mich sehr sehr verführerisch an und bewege deine Schultern ein wenig nach vorne..."

    # say L2719 sis
    old "Do you like it this way?"
    new "Magst du es so?"

    # say L2745 pla
    old "Oh boy, this is by far one of the best ones."
    new "Oh Mann, das ist definitiv einer der besten."

    # say L2753 pla
    old "Hmm I think would be great another one on the floor, but you turning around."
    new "Hmm, ich denke, es wäre toll, wenn du dich umdrehst und noch eine auf dem Boden machst."

    # say L2754 sis
    old "Alright, but what kind of position should I do?"
    new "Okay, aber in welcher Position soll ich mich aufstellen?"

    # say L2755 pla
    old "Let's see if we can make it a bit hotter..."
    new "Lass uns sehen, ob wir es ein bisschen heißer machen können..."

    # say L2756 pla
    old "Try to spread a bit your legs... And look at the camera. Also lift up your butt a bit more but try to keep your breast lower."
    new "Versuch dich ein bisschen breiter zu stellen... Und schau in die Kamera. Hebe auch deinen Hintern ein wenig an, aber versuch, deine Brust tiefer zu halten."

    # say L2757 sis
    old "Hmm, let me try."
    new "Hmm, lass mich es versuchen."

    # say L2768 pla
    old "Oh perfect! let me take the picture."
    new "Oh perfekt! Lass mich das Bild machen."

    # say L2792 pla
    old "This looks amazing."
    new "Das sieht fantastisch aus."

    # say L2799 pla
    old "Ok, I really think we are done..."
    new "Ok, ich denke wirklich, wir sind fertig..."

    # say L2801 sis
    old "Really? Yayyy! let me see them."
    new "Wirklich? Yayyy! Lass sie mir sehen."

    # say L2802 pla
    old "Of course..."
    new "Natürlich..."

    # say L2839 pla
    old "I do not know what's happening today, they are not sharp enough."
    new "Ich hab keine Ahnung, was heute los ist, sie sind einfach nicht scharf genug."

    # say L2857 pla
    old "Hmm, again with that..."
    new "Hmm, wieder damit..."

    # say L2858 sis
    old "Hahaha, You did it well nerd."
    new "Hahaha, du hast es gut gemacht, Nerd."

    # say L2867 sis
    old "Anyway, I'm going to upload more material, I need to sell."
    new "Jedenfalls, ich werde mehr Material hochladen, ich muss was verkaufen."

    # say L2869 sis
    old "Oh by the way... I'm considering bringing some sexy friends so we can make pics with new models."
    new "Oh übrigens... ich denke daran, ein paar sexy Freundinnen mitzubringen, damit wir Fotos mit neuen Models machen können."

    # say L2870 sis
    old "It would help us get everybody's attention and it means more sales, more money."
    new "Das würde uns helfen, die Aufmerksamkeit aller zu bekommen und bedeutet mehr Verkäufe, mehr Geld."

    # say L2872 sis
    old "Sure, you are gonna like it!"
    new "Klar, dir wird das gefallen!"

    # say L2873 sis
    old "Well time is money, see you around..."
    new "Na ja, Zeit ist Geld, bis später..."

    # say L2875 pla
    old "New models, uh?"
    new "Neue Modelle, hm?"

    # say L2898 sis
    old "Well you're on time, wanna have fun? I need help with my sunscreen again."
    new "Na dann, du bist pünktlich, willst du Spaß haben? Ich brauche wieder Hilfe mit meinem Sonnencreme."

    # say L2900 sis
    old "Let's start with my butt."
    new "Lass uns mit meinem Po anfangen."

    # say L2904 sis
    old "I love the sun, it feels great and makes me look better, don't you think."
    new "Ich liebe die Sonne, sie fühlt sich toll an und macht mich besser aussehen, findest du nicht?"

    # say L2906 sis
    old "Please pay attention, I need you to spread it aaaaall over my butt while giving a slow massage."
    new "Ach komm, konzentrier dich. Ich will, dass du es dir Zeit lässt und es mir gründlich auf den Hintern einmassierst."

    # say L2924 sis
    old "You know what? Let's fuck right now!"
    new "Weißt du was? Lass uns jetzt ficken!"

    # say L2925 pla
    old "Wha-? But... Someone could see us."
    new "Was? Aber... Jemand könnte uns sehen."

    # say L2926 sis
    old "People are busy, nobody is gonna come, I already checked."
    new "Die Leute sind beschäftigt, niemand kommt, das hab ich schon überprüft."

    # say L2927 sis
    old "Last time you weren't so worried about that!"
    new "Das letzte Mal hast du dich nicht so gesorgt!"

    # say L2929 sis
    old "Don't worry about the people, think just about my ass"
    new "Mach dir keine Sorgen um die Leute, denk einfach an meinen Arsch"

    # say L2941 sis
    old "I really liked it, you are by far much better than my toy."
    new "Mir hat es echt gefallen, du bist bei Weitem besser als mein Vibrator."

    # say L2942 sis
    old "It's like a super toy, delicious!"
    new "Es ist wie ein Super-Spielzeug, lecker!"

    # say L2943 sis
    old "Hope you liked it too, gonna take a shower."
    new "Hoffe, dir hat's auch gefallen, ich geh duschen."

    # say L2944 sis
    old "Bye now."
    new "Bis später."

    # say L2968 pla
    old "Yep, how bout you?"
    new "Klar, und du?"

    # say L2969 sis
    old "Amazing, sun makes me feel good."
    new "Amazing, die Sonne macht mich richtig gut drauf."

    # say L2970 sis
    old "I want to share some news to you."
    new "Ich will dir was erzählen."

    # say L2972 sis
    old "Sure, meet me in my bedroom."
    new "Klar, treffen wir uns in meinem Schlafzimmer."

    # say L2973 pla
    old "Coming."
    new "Komme."

    # say L2980 sis
    old "Well, being honest, the business is running pretty good."
    new "Na ja, ehrlich gesagt, läuft das Geschäft ziemlich gut."

    # say L2981 sis
    old "Part of this success has been your help with the website, the pics, and your effort."
    new "Teil dieses Erfolgs ist auch deine Hilfe mit der Website, den Fotos und deiner Einsatzbereitschaft."

    # say L2982 sis
    old "I know you have been more than the 'nerd' with the website, but also the one who delivers, photographer, market couch, you name it."
    new "Ich weiß, dass du mehr als der \"Nerd\" für die Website warst, sondern auch derjenige, der die Sachen liefert, der Fotograf, der Markenberater, nenn es wie du willst."

    # say L2983 pla
    old "Well, that is not true, but thanks."
    new "Das stimmt nicht, aber danke."

    # say L2984 sis
    old "I think it would be fair if we split the incomes instead of just giving you part of it, because you are more like my partner."
    new "Ich denke, es wäre fair, wenn wir die Einnahmen teilen und nicht nur dir einen Teil geben, weil du eher wie mein Partner bist."

    # say L2985 pla
    old "Wow... I am glad to hear that."
    new "Wow... Ich freue mich, das zu hören."

    # say L2986 sis
    old "To be honest, there is more you should know."
    new "Ehrlich gesagt, gibt es noch mehr, was du wissen solltest."

    # say L2987 sis
    old "This is just part of the incomes, there is something you should be more excited about."
    new "Das ist nur ein Teil des Einkommens, da ist etwas, wovon du noch viel aufgeregter sein solltest."

    # say L2989 sis
    old "Lay on the bed, I will show you."
    new "Leg dich aufs Bett, ich zeig's dir."

    # say L2992 sis
    old "Let me give you something money can't buy."
    new "Lass mich dir etwas geben, das Geld nicht kaufen kann."

    # say L3001 sis
    old "Ohh, I love this taste..."
    new "Ohh, ich liebe diesen Geschmack..."

    # say L3002 sis
    old "Now, let's fuck! I'm going to ride you..."
    new "Jetzt ficken wir! Ich reite dich..."

    # say L3015 sis
    old "That was intense... What a mess we've made."
    new "Das war intensiv... Was für ein Chaos haben wir angerichtet."

    # say L3022 pla
    old "Hell yeah."
    new "Hell ja."

    # say L3023 sis
    old "I think this is how a very successful partnership starts!"
    new "Ich denke, so beginnt eine sehr erfolgreiche Partnerschaft!"

    # say L3024 sis
    old "I appreciate your hard work especially in this extra activity."
    new "Ich schätze deine harte Arbeit, besonders bei dieser zusätzlichen Aktivität."

    # say L3025 sis
    old "From now you can ask anything from me. I mean we are partners."
    new "Ab jetzt kannst du mich alles fragen. Ich meine, wir sind Partner."

    # say L3027 sis
    old "I need a bit of rest... See you later [pla]"
    new "Ich brauch ein bisschen Ruhe... Bis später [pla]"

    # say L3028 pla
    old "See you later [sis]."
    new "Bis später [sis]"

    # say L3029 sis
    old "I really love your cock, Nerd!"
    new "Ich liebe deinen Schwanz echt, Nerd!"

    # say L3061 sis
    old "I asked you to come to my bedroom in the afternoons, dummy..."
    new "Ich hab dich gebeten, nachmittags zu meinem Schlafzimmer zu kommen, Dummerchen..."

    # say L3063 pla
    old "Oh, my bad. I will be in the garage studying then."
    new "Oh, tut mir leid. Ich werde dann im Schuppen lernen."

    # say L3068 sis
    old "Studying in the garage?... (Hmm, I wonder what he's really doing in there.)"
    new "Studieren im Schuppen?... (Hm, ich wüsste wirklich gern, was er da treibt.)"

    # say L3098 pla
    old "Oh... sorry. I was just thinking of something..."
    new "Oh... sorry. Ich hab gerade an was anderes gedacht..."


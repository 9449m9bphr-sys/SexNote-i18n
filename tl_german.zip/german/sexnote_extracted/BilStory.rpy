# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/BilStory.rpy
translate german strings:

    # say L64 pla
    old "What's this? Doodles, messy scratches... hold up, are these lyrics?"
    new "Was ist das? Kritzel, verwischte Striche... Moment, sind das Liedtexte?"

    # say L65 pla
    old "Music notes scribbled everywhere. 'Faded echoes, songs we lost...'"
    new "Musiknoten überall hingeschmiert. „Verblasste Echos, Lieder, die wir verloren haben...“"

    # say L69 pla
    old "Yeah, that's the right call."
    new "Ja, das ist der richtige Weg."

    # say L144 pla
    old "Hold up, what’s this flyer on the floor?"
    new "Warte mal, was ist das für ein Flyer auf dem Boden?"

    # say L150 pla
    old "School’s doing a music contest? 'Sign up now'..."
    new "Die Schule macht einen Musikwettbewerb? „Jetzt anmelden“..."

    # say L339 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 percent yourself. Ready? Let’s make magic!"
    new "Also, atmen, Spaß haben und daran denken: Die Bühne ist der einzige Ort, wo du hundertprozentig du selbst sein darfst. Bereit? Lass uns Magie machen!"

    # say L415 bey
    old "Arielle and Kayla!"
    new "Arielle und Kayla!"

    # say L425 bey
    old "Lord have mercy on my edges! Arielle, those whistle tones cleaner than my Sunday choir. Kayla, that belt could wake the dead."
    new "Herr, erbarme dich meiner Kanten! Arielle, diese Pfeiftonen sind sauberer als mein Sonntagchor. Kayla, dieser Falsetto könnte die Toten wecken."

    # say L474 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100 percent. Volume was whisper quiet, but somehow you filled the entire room."
    new "Dein Ton ist reine Seide, die Phrasierung berührt bis ins Mark, die emotionale Wahrheit 100 Prozent. Die Lautstärke war kaum mehr als ein Flüstern, aber irgendwie hast du den ganzen Raum gefüllt."

    # say L476 bey
    old "However, [pla]... sweetheart, you were a potted plant."
    new "Allerdings, [pla]... Schatz, du warst ein Topfblume."

    # say L478 bey
    old "Next time you move, you breathe with her, you support her. Deal?"
    new "Das nächste Mal bewegst du dich mit ihr, atmest mit ihr, stützt sie. Abgemacht?"

    # say L496 bey
    old "Sharpay & Ryan: spectacle and precision. Arielle & Kayla: vocal olympics. Billie & [pla]: pure soul."
    new "Sharpay & Ryan: Spektakel und Präzision. Arielle & Kayla: Vokale Olympiade. Billie & [pla]: reine Seele."

    # say L873 pla
    old "Watched like three tutorials last night. How hard can be?"
    new "Hab gestern Abend drei Tutorials geschaut. Wie schwer kann es schon sein?"

    # say L892 pla
    old "Let’s try again..."
    new "Lass uns noch mal versuchen..."

    # say L905 pla
    old "One more time. Come on, [pla]."
    new "Noch einmal. Komm schon, [pla]."

    # say L933 pla
    old "Okay... that almost sounded like music... right?"
    new "Okay... das klang fast wie Musik... oder?"

    # say L934 pla
    old "Ugh, enough for today. Fingers are officially dead."
    new "Ugh, genug für heute. Die Finger sind offiziell tot."

    # say L1109 pla
    old "Wow... you're amazing."
    new "Wow... du bist unglaublich."

    # say L1377 pla
    old "Still not perfect... but it sounded more like a song this time."
    new "Immer noch nicht perfekt... aber es klang mehr wie ein Lied dieses Mal."

    # say L1551 pla
    old "T- they're so sensitive... I can feel them hardening more."
    new "S- sie sind so empfindlich... ich kann spüren, wie sie härter werden."

    # say L1604 pla
    old "W- what do you have in mind?"
    new "W- was hast du im Sinn?"

    # say L1613 bil
    old "And of course, I know you’re gonna need a little extra motivation..."
    new "Und natürlich weiß ich, dass du ein bisschen Extra-Motivation brauchst..."

    # say L1623 bil
    old "Shh. Focus. This is practical training, remember?"
    new "Pssst. Konzentrier dich. Das ist praktisches Training, erinnerst du dich?"

    # say L1625 bil
    old "Mmm... good. Feel how it responds under your fingers?"
    new "Mmm... gut. Spürst du, wie es unter deinen Fingern reagiert?"

    # say L1626 pla
    old "It's... getting wetter already."
    new "Es wird... schon nasser."

    # say L1627 bil
    old "That's normal. Keep the rhythm steady. You're learning the technique."
    new "Das ist normal. Halte das Tempo konstant. Du lernst die Technik."

    # say L1632 bil
    old "Now increase the pressure a bit. Faster circles. Don't lose the rhythm."
    new "Jetzt erhöhe den Druck ein bisschen. Schnellere Kreise. Verliere das Tempo nicht."

    # say L1634 bil
    old "Nngh— yes... that's it. You're doing well. Keep going."
    new "Nngh— ja... genau so. Du machst das gut. Mach weiter."

    # say L1639 bil
    old "Harder. Don't stop. Make me feel it."
    new "Fester. Hör nicht auf. Mach mich spüren."

    # say L1640 pla
    old "[bil]... you're breathing heavier."
    new "[bil]... du atmest schwerer."

    # say L1641 bil
    old "Fuck... just like that. Keep going. Don't you dare slow down."
    new "Scheiße... genau so. Mach weiter. Wage es ja nicht, langsamer zu werden."

    # say L1646 bil
    old "Ngh- Stop, stop, stop..."
    new "Ngh- Stopp, stopp, stopp..."

    # say L1647 pla
    old "... Did I do something wrong?"
    new "... Hab ich was Falsches gemacht?"

    # say L1648 bil
    old "Mmm, no, no... actually you were doing it really well."
    new "Mmm, nein, nein... eigentlich hast du es wirklich gut gemacht."

    # say L1649 bil
    old "But I want you to try something... Uhh, more advanced."
    new "Aber ich will, dass du was anderes probierst... Ähm, was Fortgeschritteneres."

    # say L1650 bil
    old "Now... use two fingers. Slide them in together. Start slow."
    new "Jetzt... benutz zwei Finger. Schieb sie zusammen rein. Mach langsam an."

    # say L1652 pla
    old "Uhh... like this?"
    new "Uhh... so?"

    # say L1653 bil
    old "Mmm, yeah, just like that..."
    new "Mmm, ja, genau so..."

    # say L1654 bil
    old "Curl them. Find the spot and start moving them slowly... let me feel it."
    new "Kreuze sie. Finde die Stelle und bewege sie langsam... lass mich es spüren."

    # say L1755 bil
    old "Ready for your advanced practice?"
    new "Bist du bereit für deine Fortgeschrittenenübungen?"

    # say L1808 bil
    old "Finally. You're late."
    new "Endlich. Du bist spät dran."

    # say L1809 pla
    old "I know, I know... I’m sorry."
    new "Ich weiß, ich weiß... Tut mir leid."

    # say L1810 bil
    old "We don’t have time for this. The teacher’s expecting us."
    new "Wir haben dafür keine Zeit. Die Lehrerin wartet auf uns."

    # say L1813 pla
    old "Billie... Wait!"
    new "Billie... Warte!"

    # say L1815 pla
    old "I- I don’t think I can do this."
    new "Ich glaube, ich schaff das nicht."

    # say L1816 bil
    old "Here we go again."
    new "Da geht es wieder los."

    # say L1817 pla
    old "I mean it. I don’t feel ready. Not even close."
    new "Ich meine es ernst. Ich fühle mich nicht bereit. Gar nicht."

    # say L1818 bil
    old "Come on! You’ve been practicing for days. You improved a ton."
    new "Komm schon! Du hast tagelang geübt. Du bist viel besser geworden."

    # say L1819 pla
    old "Yeah, but only with you. Or at home. This is different. With the teacher... with pressure... I’m not ready."
    new "Klar, aber nur mit dir. Oder zu Hause. Das hier ist was anderes. Mit der Lehrerin... unter Druck... Ich bin nicht bereit."

    # say L1820 bil
    old "Relax, you don’t have to be perfect today."
    new "Beruhige dich, du musst heute nicht perfekt sein."

    # say L1821 pla
    old "But I’m barely even good. What if I mess everything up?"
    new "Aber ich bin doch gar nicht gut. Was, wenn ich alles vermassle?"

    # say L1822 bil
    old "Then you mess up. It happens."
    new "Dann machst du was falsch. Passiert eben."

    # say L1823 pla
    old "I don't know, Billie... maybe you should just do this one alone."
    new "Ich weiß nicht, Billie... vielleicht solltest du das einfach alleine machen."

    # say L1824 bil
    old "Stop. You’re not backing out now."
    new "Hör auf. Du ziehst jetzt nicht mehr zurück."

    # say L1825 pla
    old "Billie... I really don’t think I can do this."
    new "Billie... Ich glaube echt, ich schaff das nicht."

    # say L1826 bil
    old "Shut Up! I know you can. You’ve improved. A lot."
    new "Halt die Klappe! Ich weiß, dass du das kannst. Du hast dich echt verbessert."

    # say L1827 pla
    old "But what if I freeze? What if everything falls apart? What if—"
    new "Aber was, wenn ich einfriere? Was, wenn alles auseinanderfällt? Was, wenn—"

    # say L1828 bil
    old "Okay, okay, breathe. You’re spiraling."
    new "Okay, okay, atmen. Du drehst durch."

    # say L1829 pla
    old "I- I don’t know... I feel like I’m gonna choke the moment she looks at me."
    new "Ich- Ich weiß nicht... Ich hab das Gefühl, ich ersticke, sobald sie mich ansieht."

    # say L1830 bil
    old "Look, standing here arguing isn’t helping either. Come with me."
    new "Schau, hier rumzustreiten hilft auch nicht. Komm mit mir."

    # say L1831 pla
    old "What? W- where?"
    new "Was? W- wohin?"

    # say L1832 bil
    old "Somewhere quiet. You need to reset before we walk in there."
    new "Irgendwo ruhig. Du musst dich beruhigen, bevor wir da reingehen."

    # say L1855 pla
    old "The bathroom? [bil], what are we—"
    new "Die Toilette? [bil], was machen wir hier—"

    # say L1856 bil
    old "Shh. Ok, i locked the door."
    new "Pst. Okay, ich hab die Tür abgeschlossen."

    # say L1857 pla
    old "Uhh, W- what? Why? We should be heading to class."
    new "Uhh, w-was? Warum? Wir sollten doch zum Unterricht gehen."

    # say L1858 bil
    old "Listen, you need to chill first. Watch."
    new "Hör zu, du musst dich erst beruhigen. Schau mal."

    # say L1862 bil
    old "There. Take a look."
    new "Da. Schau mal."

    # say L1863 pla
    old "I... Uh... they're... wow."
    new "Ich... Äh... die sind... wow."

    # say L1864 bil
    old "Heh. Does this help?"
    new "Heh. Hilft dir das?"

    # say L1865 pla
    old "Kinda? But... this isn't about that."
    new "Irgendwie? Aber... das ist nicht der Punkt."

    # say L1866 bil
    old "You can touch them if you want. Might relax you more."
    new "Du kannst sie anfassen, wenn du willst. Das könnte dich mehr entspannen."

    # say L1867 pla
    old "Hmm... to be honest, I don't think this is gonna help with the anxiety."
    new "Hmm... ehrlich gesagt, glaube ich nicht, dass das die Angst loswerden hilft."

    # say L1868 bil
    old "Really? Not even a little?"
    new "Wirklich? Nicht mal ein bisschen?"

    # say L1869 pla
    old "I mean, I really like them, of course. But I'm still freaked about performing."
    new "Ich meine, ich mag sie wirklich, aber ich bin immer noch total nervös beim Gedanken an die Aufführung."

    # say L1870 bil
    old "Hmm. Okay, okay... Plan B then."
    new "Hmm. Okay, okay... Plan B dann."

    # say L1872 bil
    old "Yeah. Something that always works."
    new "Klar. Etwas, das immer funktioniert."

    # say L1879 pla
    old "Oh God, [bil]..."
    new "Oh Gott, [bil]..."

    # say L1880 bil
    old "Shh. Let me handle your stress."
    new "Psst. Lass mich deinen Stress abbauen."

    # say L1881 pla
    old "This is crazy... but... don't stop."
    new "Das ist verrückt... aber... hör nicht auf."

    # say L1893 bil
    old "Told you. My methods are foolproof."
    new "Hab ich doch gesagt. Meine Methoden sind unfehlbar."

    # say L1894 pla
    old "Phew... okay, nerves are gone. Mostly."
    new "Phew... okay, die Nerven sind weg. Zum Großteil."

    # say L1895 bil
    old "Good. Now let's go before Bey bails on us."
    new "Gut. Jetzt lass uns gehen, bevor Bey uns sitzen lässt."

    # say L1896 pla
    old "Right. I'm ready now. I think."
    new "Okay. Ich bin bereit. Glaube ich."

    # say L1897 bil
    old "You are. Come on."
    new "Du bist. Los, komm."

    # say L1906 bey
    old "Oh! There you two are. I was about to leave."
    new "Oh! Da seid ihr ja. Ich wollte schon losfahren."

    # say L1907 bil
    old "Sorry. We had... a situation."
    new "Entschuldigung. Wir hatten... eine Situation."

    # say L1909 bey
    old "A situation?"
    new "Eine Situation?"

    # say L1910 bil
    old "Stage panic. I had to calm him down with... a technique that always works."
    new "Bühnenpanik. Ich musste ihn mit... einer Technik beruhigen, die immer funktioniert."

    # say L1911 bey
    old "Oh! Well, whatever you did, I’m glad it helped. Next time, bring him here, I have plenty of ways to help with anxiety too."
    new "Oh! Was auch immer du getan hast, ich bin froh, dass es geholfen hat. Bring ihn das nächste Mal mit, ich habe auch genug Methoden, um mit Angst umzugehen."

    # say L1912 bil
    old "Don’t worry. I have a method that works every time."
    new "Keine Sorge. Ich habe eine Methode, die immer funktioniert."

    # say L1914 bey
    old "Well, as long as he’s fine now."
    new "Na, Hauptsache, es geht ihm jetzt gut."

    # say L1915 pla
    old "I... think so."
    new "Ich... denke schon."

    # say L1916 bey
    old "Good. Now tell me, how have you two been? Practicing together?"
    new "Gut. Erzähl mir, wie geht es euch beiden? Übt ihr zusammen?"

    # say L1917 bil
    old "A lot. He’s been improving faster than I expected."
    new "Viel. Er verbessert sich schneller, als ich gedacht hätte."

    # say L1918 bey
    old "Really? That’s wonderful."
    new "Wirklich? Das ist wunderbar."

    # say L1919 pla
    old "Uhh, actually, I’m still not that great."
    new "Uhh, eigentlich bin ich noch nicht so gut."

    # say L1920 bey
    old "No one expects you to be. What matters is progress."
    new "Niemand erwartet das von dir. Wichtig ist der Fortschritt."

    # say L1921 bil
    old "He’s now supporting me with guitar for the performance."
    new "Er unterstützt mich jetzt mit der Gitarre für die Performance."

    # say L1922 bey
    old "Ah! Excellent idea. Your voice with live accompaniment gives the duet a lot of potential."
    new "Ah! Exzellente Idee. Deine Stimme mit Live-Begleitung gibt dem Duett viel Potential."

    # say L1923 bil
    old "Yeah, that’s the plan."
    new "Ja, das ist der Plan."

    # say L1924 bey
    old "Alright then, let’s hear you. Perform as if it were the actual contest. After that, I’ll give you both feedback."
    new "Dann mal los, lass es uns hören. Spielt, als wäre es der echte Wettbewerb. Danach gebe ich euch beiden Feedback."

    # say L1927 pla
    old "({i}No pressure... no pressure...{/i})"
    new "{i}Kein Druck... kein Druck...{/i}"

    # say L1936 bey
    old "Okay! Why don’t we do this like a mock presentation?"
    new "Okay! Warum machen wir das nicht wie eine Vortragsübung?"

    # say L1938 bey
    old "Imagine you’re already on stage at the contest. Perform the piece you’ve been working on."
    new "Stell dir vor, du bist schon auf der Bühne beim Wettbewerb. Führe das Stück auf, an dem du gearbeitet hast."

    # say L1939 pla
    old "{i}Billie... I don—{/i}"
    new "{i}Billie... ich kann nicht...{/i}"

    # say L1940 bil
    old "Don’t start panicking again. Just do what we’ve practiced."
    new "Lass dich nicht wieder in Panik verfallen. Mach einfach, was wir geübt haben."

    # say L1941 pla
    old "{i}Right... right.{/i}"
    new "{i}Richtig... richtig.{/i}"

    # say L1975 bey
    old "Wow. That was genuinely impressive."
    new "Wow. Das war echt beeindruckend."

    # say L1977 bey
    old "Absolutely. You two have grown a lot."
    new "Absolut. Ihr zwei seid echt gewachsen."

    # say L1978 bey
    old "[pla]... last time you barely moved. You were like a decorative tree."
    new "[pla]... letztes Mal hast du dich kaum bewegt. Du warst wie ein dekorativer Baum."

    # say L1980 bey
    old "This time you actually you played. And with feeling. I’m proud of that."
    new "Dieses Mal hast du tatsächlich gespielt. Und mit Gefühl. Das macht mich stolz."

    # say L1981 bey
    old "You still get nervous, and it shows in your transitions. A few spots were shaky."
    new "Du kriegst immer noch Butter bei den Händen, und das merkt man in deinen Übergängen. An ein paar Stellen war es wackelig."

    # say L1983 bey
    old "It’s normal. With more practice you'll smooth it out. If you want, you can come to extra sessions with me. I can help strengthen your hand technique."
    new "Das ist normal. Mit mehr Übung wirst du es glätten. Wenn du willst, kannst du zu Extra-Trainings mit mir kommen. Ich kann dir dabei helfen, deine Handtechnik zu verbessern."

    # say L1984 bil
    old "No need. I’ve already got him on a very effective practice."
    new "Keine Sorge. Ich habe schon eine sehr effektive Übung mit ihm."

    # say L1985 bey
    old "Oh! Great. If it works, keep doing it. You two clearly connect well."
    new "Oh! Toll. Wenn es funktioniert, mach weiter so. Ihr beiden versteht euch offensichtlich gut."

    # say L1986 bey
    old "Now, Billie. As always your voice is beautiful. Rich tone, controlled color, great emotional delivery."
    new "Jetzt, Billie. Wie immer klingt deine Stimme wunderschön. Reicher Ton, kontrollierte Farbe, großartige emotionale Ausdrucksstärke."

    # say L1988 bey
    old "However, there’s room to grow. You rely a bit too much on natural skill."
    new "Allerdings gibt es noch Raum für Wachstum. Du verlässt dich ein bisschen zu sehr auf dein natürliches Talent."

    # say L1989 bey
    old "We need to work on technique, breath support, especially sustaining phrases without losing power."
    new "Wir müssen an Technik und Atemunterstützung arbeiten, besonders daran, Phrasen ohne Kraftverlust zu halten."

    # say L1990 bey
    old "Your diaphragm engagement is good, but not consistent. With proper training, your projection and stability will improve a lot."
    new "Deine Bauchatmung ist gut, aber nicht konstant. Mit der richtigen Ausbildung werden deine Projektion und Stabilität stark verbessern."

    # say L1991 bil
    old "Oh, ok..."
    new "Oh, okay..."

    # say L1992 bey
    old "I’d love to train that with you. Come for vocal sessions, and we’ll shape your sound for the contest."
    new "Ich würde gerne mit dir trainieren. Komm zu den Vokal-Trainings, dann formen wir deinen Klang für den Wettbewerb."

    # say L1993 bey
    old "Just you and me. We’ll polish your technique and make sure you’re ready for the real contest."
    new "Nur du und ich. Wir werden deine Technik feinjustieren und sicherstellen, dass du für den echten Wettbewerb bereit bist."

    # say L1994 bil
    old "Sounds good. I’m in."
    new "Klingt gut. Ich bin dabei."

    # say L1995 bey
    old "Perfect. And [pla], keep practicing with Billie. You two work wonderfully together."
    new "Perfekt. Und [pla], übe weiter mit Billie. Ihr beide passt fantastisch zusammen."

    # say L1996 pla
    old "We will."
    new "Wir werden."

    # say L1997 bil
    old "Oh, trust me... We definitely will."
    new "Oh, verlass dich drauf... Wir werden definitiv."

    # say L1998 bey
    old "You both have something special together."
    new "Ihr beide habt da was Besonderes zusammen."

    # say L1999 bey
    old "Keep up the rhythm. I’ll call you both again for another evaluation soon."
    new "Haltet das Tempo. Ich rufe euch beide bald wieder für eine weitere Evaluation an."

    # say L2000 bil
    old "Thank you for everything."
    new "Danke für alles."

    # say L2016 ari
    old "Well, well... look who actually survived a real practice session."
    new "Na, na... schaut mal, wer tatsächlich eine echte Übungsstunde überlebt hat."

    # say L2017 tay
    old "We heard you two through the wall. That was... almost not terrible. Hahaha"
    new "Wir haben euch durch die Wand gehört. Das war... fast nicht schrecklich. Hahaha"

    # say L2019 bil
    old "Heh. Almost?"
    new "Heh. Fast?"

    # say L2020 ari
    old "Your breath control still wavers on the sustain, sweetie. Fix it or you’ll crack on stage."
    new "Dein Atemkontrolle schwankt noch beim Halten, Schatz. Behebe es, sonst platzt du auf der Bühne."

    # say L2021 tay
    old "And you, [pla]... congrats on finally moving. You’re only half a statue now."
    new "Und du, [pla]... Glückwunsch, dass du endlich bewegst. Du bist jetzt nur noch halb so steif wie eine Statue."

    # say L2022 pla
    old "Thanks... I think?"
    new "Danke... glaub ich?"

    # say L2023 bil
    old "Keep taking notes, girls. We’re just warming up."
    new "Macht weiter mit den Notizen, Mädels. Wir sind erst am Aufwärmen."

    # say L2024 ari
    old "Please. Technique beats 'raw emotion' every single time."
    new "Bitte. Technik schlägt rohe Emotion jedes Mal."

    # say L2026 tay
    old "See you at the contest... try not to choke when it actually counts."
    new "Bis zum Wettbewerb dann... versuch bloß nicht zu versagen, wenn es drauf ankommt."

    # say L2032 pla
    old "They’re still exactly the same, huh?"
    new "Sie sind immer noch genau die gleichen, hm?"

    # say L2033 bil
    old "Perfect. Makes crushing them way more satisfying."
    new "Perfekt. Machen es den Sieg noch süßer."

    # say L2040 bil
    old "Okay... I have to admit, that went better than I expected."
    new "Okay... ich muss zugeben, das ging besser als erwartet."

    # say L2041 pla
    old "Way better. I didn’t completely freeze."
    new "Viel besser. Ich bin nicht komplett eingefroren."

    # say L2042 bil
    old "Wow, what an achievement. Should we throw you a parade?"
    new "Wow, was für ein Erfolg. Sollten wir dir eine Parade veranstalten?"

    # say L2043 pla
    old "Hey, for me that’s huge."
    new "Hey, für mich ist das riesig."

    # say L2044 bil
    old "Yeah... it kinda is."
    new "Ja... so ist es."

    # say L2045 pla
    old "Seriously, thanks for earlier. Uhh, you know."
    new "Serious, danke für vorhin. Uhh, du weißt schon."

    # say L2046 pla
    old "If you hadn’t helped me calm down, I would’ve messed everything up."
    new "Wenn du mir nicht geholfen hättest, mich zu beruhigen, hätte ich alles vermasselt."

    # say L2047 bil
    old "I know."
    new "Ich weiß."

    # say L2048 bil
    old "You owe me one."
    new "Du schuldest mir was."

    # say L2049 pla
    old "Actually, more than one. I mean it."
    new "Eigentlich mehr als eine. Ich meine es ernst."

    # say L2050 bil
    old "Relax. You did the hard part. You didn’t run away."
    new "Beruhige dich. Du hast den schweren Teil geschafft. Du bist nicht weggelaufen."

    # say L2051 pla
    old "Heh, I almost did."
    new "Heh, ich war kurz davor."

    # say L2052 bil
    old "And I almost slapped you. Balance."
    new "Und ich hätte dich fast geschlagen. Gleichgewicht."

    # say L2053 pla
    old "Still... I’m glad you didn’t let me quit."
    new "Trotzdem... Ich bin froh, dass du mich nicht aufgegeben hast."

    # say L2054 bil
    old "Good. Because you’re way more useful when you don’t panic every five seconds."
    new "Gut. Denn du bist viel nützlicher, wenn du nicht alle fünf Sekunden in Panik ausbrichst."

    # say L2055 pla
    old "I’m working on that."
    new "Ich arbeite daran."

    # say L2056 bil
    old "And you’re getting better. With the guitar. With the nerves. With everything."
    new "Und du wirst besser. Mit der Gitarre. Mit den Nerven. Mit allem."

    # say L2057 pla
    old "You really think so?"
    new "Du denkst wirklich?"

    # say L2058 bil
    old "Don’t get cocky. But yeah... you’re not useless anymore."
    new "Werde bloß nicht übermütig. Aber ja... du bist nicht mehr nutzlos."

    # say L2059 pla
    old "Haha, that’s the nicest thing you’ve ever said to me."
    new "Haha, das ist das Netteste, was du mir je gesagt hast."

    # say L2060 bil
    old "Don’t get used to it."
    new "Werde dich nicht dran gewöhnen."

    # say L2061 pla
    old "So... what now?"
    new "So... was jetzt?"

    # say L2062 bil
    old "Now we keep practicing. You, with the guitar. Me, with the teacher."
    new "Jetzt üben wir weiter. Du mit der Gitarre. Ich mit dem Lehrer."

    # say L2063 bil
    old "And together... We make this thing actually work."
    new "Und zusammen... bringen wir das Ganze zum Laufen."

    # say L2064 pla
    old "Deal."
    new "Abgemacht."

    # say L2067 bil
    old "Alright, it’s getting late. Go home before you turn into a pumpkin."
    new "Okay, es wird spät. Geh nach Hause, bevor du zu einer Kürbiswurzel wirst."

    # say L2068 pla
    old "Yeah, I should. But... thanks again. For everything."
    new "Ja, sollte ich. Aber... danke nochmal. Für alles."

    # say L2069 bil
    old "Yeah, yeah. Just don’t waste what we started."
    new "Ja, ja. Versau’s bloß nicht, was wir angefangen haben."

    # say L2070 pla
    old "I won’t. I promise."
    new "Ich werd's nicht. Versprochen."

    # say L2072 pla
    old "See you soon."
    new "Bis bald."

    # say L2092 bil
    old "Finally. You're here."
    new "Endlich. Du bist da."

    # say L2093 pla
    old "Yeah, your text said it was urgent. What's up?"
    new "Klar, deine Nachricht klang dringend. Was ist los?"

    # say L2094 bil
    old "Well, I've been in lessons with the teacher. It's going okay, but I need your help with something."
    new "Na ja, ich hab Unterricht bei der Lehrerin gehabt. Geht so, aber ich brauch deine Hilfe bei was."

    # say L2095 pla
    old "Do you need my help?"
    new "Brauchst du meine Hilfe?"

    # say L2096 bil
    old "Better talk in my room. Come on."
    new "Lass uns in mein Zimmer gehen. Komm schon."

    # say L2103 bil
    old "Alright, so, those vocal sessions with Bey were way tougher than I expected."
    new "Okay, also, diese Vokalsessions mit Bey waren echt härter, als ich dachte."

    # say L2104 pla
    old "'Tougher' for you? Seriously?"
    new "Schwerer für dich? Ernsthaft?"

    # say L2105 bil
    old "Yeah, I mean, I have the talent, sure. But I haven't practiced consistently in years."
    new "Ja, ich meine, ich habe das Talent, klar. Aber ich habe seit Jahren nicht regelmäßig geübt."

    # say L2106 bil
    old "I lost some edge on breath control, especially under pressure."
    new "Ich habe etwas von meiner Atemkontrolle verloren, besonders unter Druck."

    # say L2107 bil
    old "Like, when nerves hit or heart rate spikes, my voice shakes. So, I can't sustain some notes without cracking."
    new "Wie, wenn die Nerven mit mir durchgehen oder der Puls hochgeht, zittert meine Stimme. Also, ich kann manche Töne nicht halten, ohne zu brechen."

    # say L2108 pla
    old "That sounds rough. What does the teacher say?"
    new "Das klingt hart. Was sagt die Lehrerin dazu?"

    # say L2109 bil
    old "She's got me on diaphragmatic breathing deep belly breaths to stabilize. And box breathing: inhale four, hold four, exhale four, hold four."
    new "Sie hat mich auf Bauchatmung gesetzt, um mich zu stabilisieren. Und Boxatmung: vier einatmen, vier halten, vier ausatmen, vier halten."

    # say L2110 bil
    old "Helps calm the nervous system, reduces anxiety. But it's not enough for real stage stress."
    new "Hilft, das Nervensystem zu beruhigen und die Angst zu reduzieren. Aber für echten Auftrittsstress reicht es nicht."

    # say L2111 pla
    old "Stage stress? Like performance anxiety?"
    new "Bühnenstress? Wie Auftrittsnervosität?"

    # say L2112 bil
    old "Exactly. Heart pounding, shallow breaths... Voice goes to shit. Need to practice holding technique when everything's agitated."
    new "Genau. Herz rast, flache Atemzüge... Die Stimme geht kaputt. Muss Techniken üben, die mich beruhigen, wenn alles in Aufruhr ist."

    # say L2113 pla
    old "Ohh, like exercises while running or something?"
    new "Ohh, wie Übungen beim Laufen oder so was?"

    # say L2114 bil
    old "Hmm, kinda. I already tried that stuff. Jogging while singing, high-heart-rate drills... even picturing the crowd without freaking out."
    new "Hmm, so was Ähnliches. Ich hab das schon ausprobiert. Joggen und singen, Hochpuls-Übungen... sogar mich daran gewöhnen, die Menge zu sehen, ohne auszuflippen."

    # say L2115 bil
    old "Progress is slow. With the contest coming, traditional stuff won't cut it."
    new "Der Fortschritt ist langsam. Mit dem Wettbewerb vor der Tür reicht die traditionelle Vorbereitung nicht mehr."

    # say L2116 pla
    old "Damn. So what's the plan?"
    new "Verdammt. Was ist der Plan?"

    # say L2117 bil
    old "Well, I've been researching some non-traditional stuff. Found training under extreme stimulation to build resilience."
    new "Na ja, ich hab ein bisschen über non-traditionelle Methoden recherchiert. Da hab ich was über Training unter extremem Reizgefälle gefunden, um die Ausdauer zu steigern."

    # say L2118 pla
    old "Like... What kind?"
    new "Wie... Welche Art?"

    # say L2119 bil
    old "Ways to spike heart rate and nerves, but controlled. Make the body adapt to singing through it."
    new "Ways to steigern das Herzfrequenz und die Nerven, aber kontrolliert. Damit der Körper sich daran anpasst, durch das Singen hindurchzukommen."

    # say L2121 bil
    old "Anyway, the thing is I need you, because I wanna practice vocals under some strong stimulation. You know, to simulate the pressure."
    new "Jedenfalls, ich brauche dich, weil ich meine Stimme unter starken Reizen üben will. Du weißt schon, um den Druck zu simulieren."

    # say L2122 pla
    old "Strong stimulation? Like... Distracting you?"
    new "Starke Reize? So wie... dich ablenken?"

    # say L2123 bil
    old "Why do you have to be so slow sometimes?"
    new "Warum musst du manchmal so langsam sein?"

    # say L2125 bil
    old "Listen, I need my heart racing and my body all tense while I'm practicing singing."
    new "Hör zu, ich brauche mein Herz, das rast, und meinen Körper, der gespannt ist, während ich singe."

    # say L2126 pla
    old "Still not following..."
    new "Verstehe immer noch nicht..."

    # say L2127 bil
    old "Ughh. I need you to stimulate me... sexually. While I sing."
    new "Ughh. Ich brauche, dass du mich anmachst... sexuell. Während ich singe."

    # say L2128 pla
    old "Ohhhh..."
    new "Ohaaa..."

    # say L2129 bil
    old "Yeah, it's not orthodox, but time's short. And hey, I've helped you with 'non-traditional' methods before."
    new "Ja, es ist nicht orthodox, aber die Zeit ist knapp. Und hey, ich habe dir schon mal mit 'nicht-traditionellen' Methoden geholfen."

    # say L2130 bil
    old "You owe me a few, remember?"
    new "Du schuldest mir ein paar, oder?"

    # say L2131 pla
    old "Well, that’s... fair, I guess."
    new "Na ja, das ist... fair, schätze ich."

    # say L2132 bil
    old "But, I mean, I’m not saying you’re obligated."
    new "Aber, ich meine, ich sage ja nicht, dass du verpflichtet bist."

    # say L2133 bil
    old "I’m saying this could actually help me control my voice when everything inside me is going wild."
    new "Ich meine, das könnte mir tatsächlich helfen, meine Stimme unter Kontrolle zu halten, wenn alles in mir aus dem Ruder läuft."

    # say L2134 pla
    old "And you really think this will work?"
    new "Und du denkst echt, dass das funktioniert?"

    # say L2135 bil
    old "Well, I’m not doing it just for fun."
    new "Na, ich mache das nicht nur zum Spaß."

    # say L2136 bil
    old "Okay, maybe a little."
    new "Okay, vielleicht ein bisschen."

    # say L2137 pla
    old "Heh. Alright, if you’re serious, then... Yeah. I’ll help."
    new "Heh. Okay, wenn du es ernst meinst, dann... Ja. Ich helfe dir."

    # say L2139 pla
    old "You helped me when I was stuck. If this is what you need, I’m in."
    new "Du hast mir geholfen, als ich steckengeblieben war. Wenn das ist, was du brauchst, bin ich dabei."

    # say L2141 bil
    old "If you’re going to help, we’ll treat this like real training."
    new "Wenn du mir helfen willst, behandeln wir das wie echtes Training."

    # say L2142 pla
    old "Alright... So what exactly am I supposed to do?"
    new "Okay... Was genau soll ich denn tun?"

    # say L2143 bil
    old "Ok, first, you follow my lead."
    new "Okay, erstens folgst du meinem Beispiel."

    # say L2144 bil
    old "Second, you don’t overthink it."
    new "Zweitens, du denkst dir nichts dabei."

    # say L2145 bil
    old "Third, remember the goal: I have to keep singing no matter what I’m feeling."
    new "Drittens, denk dran: Ich muss weiter singen, egal was ich fühle."

    # say L2146 pla
    old "Got it. You sing, I... create the distraction."
    new "Verstanden. Du singst, ich... sorge für die Ablenkung."

    # say L2147 bil
    old "Yeah. If we do this right, my voice should stays steady even when everything else is falling apart."
    new "Klar. Wenn wir das richtig machen, bleibt meine Stimme ruhig, egal was sonst passiert."

    # say L2148 pla
    old "Alright, I'm in. Just tell me exactly what you need, and I'll handle it."
    new "Okay, ich bin dabei. Sag mir genau, was du brauchst, und ich kümmere mich darum."

    # say L2149 bil
    old "Ok, first let me get ready..."
    new "Okay, erst mal lass mich mich vorbereiten..."

    # say L2153 bil
    old "Do you like what you see? Heh?"
    new "Magst du, was du siehst? Heh?"

    # say L2158 bil
    old "What about now?"
    new "Und jetzt?"

    # say L2159 pla
    old "Holy... fuck..."
    new "Heilige... Scheiße..."

    # say L2160 bil
    old "No reason we both can't benefit from this 'practice', right?"
    new "Kein Grund, warum wir beide nicht von dieser 'Übung' profitieren können, oder?"

    # say L2161 bil
    old "Heh. Still takes your breath away every time, huh?"
    new "Heh. Nimmt dir immer noch den Atem weg, was?"

    # say L2162 bil
    old "Perfect. Means you're properly motivated."
    new "Perfekt. Das bedeutet, du bist richtig motiviert."

    # say L2163 bil
    old "Now that you're all fired up... let me get comfortable."
    new "Jetzt, wo du so aufgeheizt bist... lass mich mich wohlfühlen."

    # say L2164 bil
    old "Now lie down on the floor before you pass out staring."
    new "Jetzt leg dich auf den Boden, bevor du vor lauter Starren ohnmächtig wirst."

    # say L2169 bil
    old "Perfect."
    new "Perfekt."

    # say L2173 bil
    old "Your job: stimulate me as hard as you can. Mine: keep breath controlled, sustain notes, hold pitch no matter what."
    new "Deine Aufgabe: reize mich so intensiv wie möglich. Meine: halte die Atmung unter Kontrolle, behalte die Noten und den Ton, egal was passiert."

    # say L2174 pla
    old "Got it. Let's do this."
    new "Verstanden. Lass uns loslegen."

    # say L2186 bil
    old "Phew... that was intense."
    new "Puh... das war intensiv."

    # say L2187 pla
    old "Yeah... did it actually work?"
    new "Ja... hat es wirklich funktioniert?"

    # say L2188 bil
    old "Big time. I could feel the control improving even as everything else was going crazy."
    new "Klarer Fall. Ich konnte die Kontrolle spüren, die sich verbesserte, selbst als alles andere aus dem Ruder lief."

    # say L2189 bil
    old "Voice held up better than I expected... but yeah, I'm definitely gonna need more of this."
    new "Die Stimme hat besser gehalten, als ich dachte... aber ja, ich werde definitiv mehr davon brauchen."

    # say L2190 bil
    old "A lot more practice before the stage doesn't wreck me."
    new "Viel mehr Übung, bevor die Bühne mich nicht mehr runterzieht."

    # say L2191 pla
    old "Uhh, if you need it, I'm down to keep helping. Same way you've been helping me."
    new "Uhh, wenn du es brauchst, bin ich dabei, weiter zu helfen. Genauso wie du mir geholfen hast."

    # say L2192 pla
    old "You know... with the 'advanced practice' and all."
    new "Du weißt schon... mit der 'fortgeschrittenen Übung' und so."

    # say L2193 bil
    old "Oh, I get it."
    new "Oh, ich verstehe."

    # say L2194 bil
    old "Heh. Tit for tat, huh? Fair enough."
    new "Heh. Auge um Auge, stimmt's? Ist fair."

    # say L2195 bil
    old "Deal. You keep me steady under pressure... I'll keep those fingers of yours 'motivated'."
    new "Abgemacht. Du hältst mich unter Druck stabil... ich sorge dafür, dass deine Finger motiviert bleiben."

    # say L2196 bil
    old "We're both getting better this way. Win-win."
    new "So werden wir beide besser. Win-win."

    # say L2197 pla
    old "Exactly. Looking forward to it."
    new "Genau. Ich freue mich drauf."

    # say L2198 bil
    old "Alright, perv. Now seriously, get out before grandma shows up and smells the trouble."
    new "Okay, Perversling. Im Ernst, verschwinde, bevor Oma auftaucht und den Trouble riecht."

    # say L2199 pla
    old "On my way. See you soon... for more 'practice'."
    new "Bin schon unterwegs. Bis bald... für mehr Übung."

    # say L2200 bil
    old "You better. Don't slack on that guitar either."
    new "Du schon. Und lass das Gitarrespielen nicht sausen."

    # say L2201 pla
    old "Wouldn't dream of it."
    new "Wär’ mir nie in den Sinn gekommen."

    # say L2220 bil
    old "Wow, you’re on time. That’s new."
    new "Wow, du bist pünktlich. Das ist neu."

    # say L2221 pla
    old "Yeah... I made sure to wake up early today. Been doing extra practice every day. Feeling ready for whatever comes today."
    new "Ja... Ich habe mich heute früh geweckt. Mache jeden Tag extra Übungen. Bin bereit für alles, was heute kommt."

    # say L2222 bil
    old "Wow. Actual growth. Who would’ve thought?"
    new "Wow. Tatsächliches Wachstum. Wer hätte das gedacht?"

    # say L2223 bil
    old "So? No panic attack today?"
    new "So? Kein Panikanfall heute?"

    # say L2224 pla
    old "A little butterflies, sure... but I'm fine. We've got this."
    new "Ein bisschen Schmetterlinge, klar... aber ich bin okay. Wir kriegen das hin."

    # say L2225 bil
    old "Look at you. All grown up."
    new "Schau dich an. Ganz erwachsen."

    # say L2226 pla
    old "Yeah. I trust what we’ve practiced."
    new "Klar. Ich vertraue darauf, was wir geübt haben."

    # say L2227 bil
    old "Good. Because today is just about showing what we can already do."
    new "Gut. Denn heute geht es nur darum, zu zeigen, was wir schon können."

    # say L2228 bil
    old "No panic, no drama."
    new "Keine Panik, kein Drama."

    # say L2229 pla
    old "I'll try to keep the drama to a minimum."
    new "Ich werd' versuchen, das Drama auf ein Minimum zu reduzieren."

    # say L2230 bil
    old "Do that and I might even be proud of you."
    new "Mach das und ich könnte sogar stolz auf dich sein."

    # say L2231 pla
    old "High honor."
    new "Hohe Ehre."

    # say L2242 sha
    old "Darlings! Look who we found!"
    new "Lieblinge! Schaut mal, wen wir gefunden haben!"

    # say L2243 rya
    old "We just finished our private session with Bey. Absolute perfection!"
    new "Wir haben gerade unsere private Session mit Bey beendet. Vollkommen perfekt!"

    # say L2244 sha
    old "The choreography, the lighting cues, the costume changes... we have a full Broadway production ready, honey!"
    new "Die Choreografie, die Lichtsignale, die Kostümwechsel... wir haben eine vollständige Broadway-Produktion bereit, Schatz!"

    # say L2245 rya
    old "Everything planned down to the last sparkle. The crowd is going to lose their minds!"
    new "Alles bis zum letzten Glitzer durchgeplant. Das Publikum wird ausflippen!"

    # say L2247 bil
    old "Great for you."
    new "Super für euch."

    # say L2248 sha
    old "Oh, look at their little faces. So serious. So... scared."
    new "Oh, schau dir ihre kleinen Gesichter an. So ernst. So... ängstlich."

    # say L2249 rya
    old "It’s adorable, really. Like two lost puppies trying to play with the big dogs."
    new "Es ist wirklich süß. Wie zwei verlorene Welpen, die versuchen mit den großen Hunden zu spielen."

    # say L2250 sha
    old "You two still look like you’re auditioning for your very first school play."
    new "Ihr beiden seht immer noch aus, als würdet ihr für euer allererstes Schultheater vorsprechen."

    # say L2251 rya
    old "While we just delivered a show stopping number that will make people stand up and cheer."
    new "Während wir gerade eine Nummer hingelegt haben, die die Leute aufspringen und applaudieren lassen wird."

    # say L2252 bil
    old "Keep talking, Sparkle Twins."
    new "Redet weiter, Glitzerzwillinge."

    # say L2253 sha
    old "Cute. Very cute. The underdogs always have that fighting spirit."
    new "Cute. Sehr cute. Die Außenseiter haben immer diesen Kämpfergeist."

    # say L2254 rya
    old "Good luck in there, sweethearts. Try not to faint from all the pressure."
    new "Viel Glück da drin, Lieblinge. Versucht bloß nicht vor lauter Druck ohnmächtig zu werden."

    # say L2255 sha
    old "Ta-ta, lovebirds! The stage belongs to the stars... not the scared little duo."
    new "Tschüss, Turteltauben! Die Bühne gehört den Sternen... nicht dem ängstlichen kleinen Duo."

    # say L2263 bil
    old "Ughh... I hate those two so much."
    new "Ughh... ich hasse die beiden so sehr."

    # say L2264 pla
    old "They really know how to get under your skin..."
    new "Sie wissen wirklich, wie man einen auf die Palme bringen kann..."

    # say L2265 bil
    old "Good. Let’s use that anger. Time to show Bey what we can really do."
    new "Gut. Lass uns diesen Frust nutzen. Zeit, Bey zu zeigen, was wir draufhaben."

    # say L2274 bey
    old "There you are already! Early today, I wasn’t expecting you two so soon."
    new "Da seid ihr ja schon! Früh heute, ich habe euch beiden nicht so früh erwartet."

    # say L2275 bil
    old "This time we didn't wanna show up late like last session."
    new "Dieses Mal wollten wir nicht zu spät kommen wie beim letzten Mal."

    # say L2276 pla
    old "Yeah, sorry if we’re a little early this time."
    new "Klar, tut uns leid, wenn wir ein bisschen zu früh sind."

    # say L2277 bey
    old "That’s a good problem to have. Gives us extra time to really dig in."
    new "Das ist ein gutes Problem. Gibt uns mehr Zeit, richtig reinzusteigen."

    # say L2278 bey
    old "So, this is our last tutoring session before the contest."
    new "Das ist unser letztes Nachhilfegespräch bevor der Wettbewerb losgeht."

    # say L2279 bey
    old "How are you both feeling?"
    new "Wie fühlt ihr euch beide?"

    # say L2280 bil
    old "Ready."
    new "Bereit."

    # say L2281 pla
    old "Nervous... but ready."
    new "Nervös... aber bereit."

    # say L2282 bey
    old "That’s exactly how you should feel."
    new "Das ist genau, wie du dich fühlen solltest."

    # say L2283 bey
    old "Alright, let’s do this like before."
    new "Okay, lass uns das wie beim letzten Mal machen."

    # say L2284 bey
    old "Perform as if you were already on stage at the contest."
    new "Mach es so, als wärst du schon auf der Bühne beim Wettbewerb."

    # say L2286 pla
    old "Alright... let’s go."
    new "Okay... los geht's."

    # say L2320 bil
    old "Is that a good ‘wow’ or...?"
    new "Ist das ein gutes Wow oder...?"

    # say L2321 bey
    old "Oh honey, it’s a ‘hell yes’ wow!"
    new "Oh Schatz, es ist ein ‘Hallelujah’ Wow!"

    # say L2322 bey
    old "This is night and day from your audition. Completely different level."
    new "Das ist Tag und Nacht im Vergleich zu deiner Vorspeich. Ein komplett anderes Niveau."

    # say L2323 bey
    old "[pla], look at you!"
    new "[pla], schau dir das an!"

    # say L2324 pla
    old "Me?"
    new "Ich?"

    # say L2325 bey
    old "From that quiet little tree in the audition to actually carrying the whole song with her!"
    new "Von diesem stillen Baum in der Vorsicht bis hin zu der, die das ganze Lied trägt!"

    # say L2326 bey
    old "Your chords are locking in perfectly now, your rhythm is steady, and you’re breathing with Billie like you were born to do this."
    new "Deine Akkorde passen jetzt perfekt, dein Rhythmus ist stabil und du atmest mit Billie, als wärst du dafür geboren."

    # say L2327 bey
    old "You’re not just following anymore... you’re complementing her. You’re making her voice shine even brighter."
    new "Du folgst nicht mehr nur mit... du ergänzt sie. Du machst ihre Stimme noch heller."

    # say L2328 pla
    old "For real? That actually worked?"
    new "Echt jetzt? Das hat tatsächlich funktioniert?"

    # say L2329 bey
    old "Yes! You two are finally sounding like a real duo."
    new "Ja! Ihr klingt endlich wie ein echtes Duo."

    # say L2330 bey
    old "And Billie... that breath control? Chef’s kiss."
    new "Und Billie... diese Atemkontrolle? Chef’s kiss."

    # say L2332 bey
    old "Absolutely. Way more power behind those soft notes. You’re letting that voice breathe."
    new "Absolut. Da ist viel mehr Kraft hinter diesen sanften Tönen. Du lässt deine Stimme richtig atmen."

    # say L2333 bey
    old "Your breath support is stronger, and you’re keeping your tone stable even in longer phrases."
    new "Dein Atemsupport ist stärker, und du hältst deinen Ton stabil, selbst in längeren Phrasen."

    # say L2334 bey
    old "You’re managing your diaphragm much more consciously now."
    new "Du kontrollierst jetzt viel bewusster dein Diaphragma."

    # say L2335 bil
    old "That’s... really good to hear."
    new "Das ist... echt gut zu hören."

    # say L2336 bey
    old "You both sound like a team now."
    new "Ihr klingt jetzt wie ein Team."

    # say L2337 bey
    old "Not just two people doing their own thing, but one performance."
    new "Nicht nur zwei Leute, die ihr eigenes Ding machen, sondern eine einzige Performance."

    # say L2338 bil
    old "That’s what we were aiming for."
    new "Das war unser Ziel."

    # say L2340 bey
    old "Well, I think you’re ready for the contest."
    new "Na, ich denke, du bist bereit für den Wettbewerb."

    # say L2341 bil
    old "You mean... really ready?"
    new "Du meinst... wirklich bereit?"

    # say L2342 bey
    old "Yes. You should keep practicing, of course."
    new "Ja. Du solltest weiter üben, natürlich."

    # say L2343 bey
    old "But now it’s about polishing, not fixing big problems."
    new "Aber jetzt geht es um Feilen, nicht um große Probleme zu beheben."

    # say L2344 bey
    old "Also... don’t forget to rest."
    new "Also... vergiss nicht, dich auszuruhen."

    # say L2345 bey
    old "Overworking right before a performance can be just as bad as not practicing."
    new "Überstunden machen kurz vor der Aufführung kann genauso schlimm sein wie gar nicht zu üben."

    # say L2347 pla
    old "We’ll be careful."
    new "Wir werden vorsichtig sein."

    # say L2348 bey
    old "And one more thing."
    new "Und noch was."

    # say L2349 bey
    old "Start thinking about your stage look."
    new "Anfangt mal drüber nachzudenken, wie ihr auf der Bühne aussehen wollt."

    # say L2350 bil
    old "O- Our look?"
    new "O- Unser Look?"

    # say L2351 bey
    old "Clothes, style, how you present yourselves."
    new "Kleidung, Stil, wie ihr euch präsentiert."

    # say L2352 bey
    old "Your music has a mood. Your image should match it."
    new "Eure Musik hat eine Stimmung. Euer Image sollte dazu passen."

    # say L2353 pla
    old "Oh, That actually sounds fun."
    new "Oh, das klingt tatsächlich spaßig."

    # say L2355 bey
    old "I’ll be cheering for you both."
    new "Ich werde für euch beide jubeln."

    # say L2356 bil
    old "Thank you. For everything."
    new "Danke. Für alles."

    # say L2357 pla
    old "Yeah, thank you."
    new "Ja, danke."

    # say L2379 bil
    old "Well... that timing was just perfect."
    new "Na ja... der Timing war einfach perfekt."

    # say L2380 pla
    old "Yeah, that rain came out of nowhere."
    new "Ja, der Regen kam wirklich aus dem Nichts."

    # say L2381 bil
    old "Tell me about it."
    new "Sag mal."

    # say L2382 bil
    old "Anyway, go dry off in the bathroom, towel's there."
    new "Jedenfalls, trockne dich im Bad ab, Handtuch liegt da."

    # say L2383 bil
    old "I'm heading to my bedroom to change."
    new "Ich gehe in mein Schlafzimmer, um mich umzuziehen."

    # say L2385 bil
    old "Try not to flood the place."
    new "Versuch bloß nicht, den ganzen Badezimmer zu überschwemmen."

    # say L2386 pla
    old "No promises."
    new "Keine Versprechen."

    # say L2396 pla
    old "Hey [bil], sorry, I kinda flooded the bathroom floor while drying off-"
    new "Hey [bil], sorry, ich hab die Badezimmerfließe ein bisschen überflutet, als ich mich abgetrocknet hab-"

    # say L2399 bil
    old "Hey, eyes up here, perv."
    new "Hey, Augen nach oben, Perversling."

    # say L2402 bil
    old "Heh, what? Rain made them look that good?"
    new "Heh, was? Hat der Regen sie so gut aussehen lassen?"

    # say L2403 pla
    old "Uhhh, well, I- I can literally see your nipples through the shirt..."
    new "Uhhh, also, ich- ich kann deine Nippel durch das Shirt sehen..."

    # say L2404 bil
    old "Haha, you’re practically drooling already... you're such a mess"
    new "Haha, du bist ja schon fast am Sabbern... du bist echt ein Chaos."

    # say L2406 bil
    old "Heh, wanna get a better view?"
    new "Heh, willst du dir das aus der Nähe ansehen?"

    # say L2407 pla
    old "I— I- I- Uhhh... y- yea-"
    new "I— I- I- Uhhh... j- ja-"

    # say L2412 bil
    old "There. Way better without anything in the way, right?"
    new "Da. Viel besser ohne was im Weg, oder?"

    # say L2413 pla
    old "Holy shit, [bil]..."
    new "Heilige Scheiße, [bil]..."

    # say L2415 bil
    old "Heh, oh my gosh... look at you."
    new "Heh, oh mein Gott... schau dich an."

    # say L2416 bil
    old "Someone got rock hard just from staring at my tits."
    new "Jemand ist ja schon hart geworden, nur weil er meine Titten angestarrt hat."

    # say L2417 pla
    old "S- Sorry, I can't help it..."
    new "S-Sorry, ich kann es nicht ändern..."

    # say L2420 bil
    old "Obviously. I love how easily I can turn a perv like you into a complete mess."
    new "Offensichtlich. Ich liebe es, wie leicht ich einen Perversen wie dich zu einem vollkommenen Chaos machen kann."

    # say L2427 bil
    old "You know... good boys who practice as hard as you do deserve something special."
    new "Du weißt... brave Jungs, die so hart üben wie du, verdienen etwas Besonderes."

    # say L2434 bil
    old "And you’ve been such a good boy lately..."
    new "Und du bist lately so ein braver Junge gewesen..."

    # say L2441 bil
    old "Yeah, so I think you’ve earned yourself a little prize."
    new "Ja, also denke ich, dass du dir ein kleines Geschenk verdient hast."

    # say L2448 bil
    old "Mmm... feel that? Every single inch sliding in..."
    new "Mmm... spürst du das? Jeden einzelnen Zentimeter, der reingeht..."

    # say L2449 pla
    old "God... you’re so fucking tight..."
    new "Verdammt... du bist so verdammt eng..."

    # say L2450 bil
    old "Slow... nice and deep. Let me take control."
    new "Langsam... tief und intensiv. Lass mich das Kommando übernehmen."

    # say L2459 pla
    old "({i}That was... intense. Too intense.{/i})"
    new "({i}Das war... intensiv. Zu intensiv.{/i})"

    # say L2460 bil
    old "You okay? You look like I just broke your brain."
    new "Alles okay? Du siehst aus, als hätte ich dir gerade den Verstand geraubt."

    # say L2461 pla
    old "I... yeah. I’m good. Just... damn."
    new "Ich... ja. Mir geht's gut. Einfach... verdammt."

    # say L2462 bil
    old "Heh. 'Damn' is right. We both really needed that, didn’t we?"
    new "Heh. 'Verdammt' trifft’s genau. Wir beide haben das wirklich gebraucht, oder?"

    # say L2463 pla
    old "Yeah... I think we did."
    new "Ja... ich glaube, wir beide haben das gebraucht."

    # say L2465 pla
    old "But... it felt different this time..."
    new "Aber... es war anders dieses Mal..."

    # say L2467 pla
    old "I mean, when we were looking at each other... I could see it in your eyes. You were feeling it too."
    new "Ich meine, als wir uns angesehen haben... Ich konnte es in deinen Augen sehen. Du hast es auch gespürt."

    # say L2468 bil
    old "Uhh.. D- Don’t get all sappy on me now..."
    new "Uhh.. D- Das ist jetzt aber sentimental"

    # say L2470 bil
    old "Listen, it was just blowing off steam, okay? Don't start reading too much into it."
    new "Hör zu, es war einfach nur Stressabbau, okay? Mach jetzt bloß nicht daraus was Großes."

    # say L2471 pla
    old "I guess, you're right, still... it felt really good."
    new "Ich schätze, du hast recht, trotzdem... es hat sich echt gut angefühlt."

    # say L2472 bil
    old "Heh. Yeah... you weren’t half bad yourself."
    new "Heh. Ja... du warst selbst nicht schlecht."

    # say L2473 bil
    old "Doesn’t mean I’m going soft on you though."
    new "Das heißt aber nicht, dass ich dir gegenüber weicher werde."

    # say L2474 bil
    old "The contest is in a few days. We can’t afford to get distracted."
    new "Das Turnier ist in ein paar Tagen. Wir können uns keine Ablenkung leisten."

    # say L2475 pla
    old "Right... back to serious practice."
    new "Richtig... zurück zur ernsten Übung."

    # say L2476 bil
    old "Exactly. Guitar for you, vocals for me. No slacking."
    new "Genau. Gitarre für dich, Gesang für mich. Kein Herumlungern."

    # say L2479 bil
    old "But... if you need a little extra 'motivation' again... I guess I can make time."
    new "Aber... wenn du ein bisschen extra 'Motivation' brauchst... dann kann ich mir schon was einfallen lassen."

    # say L2480 pla
    old "I’ll take that."
    new "Ich nehm das an."

    # say L2481 bil
    old "Don’t get cocky. Next time I might make you work even harder for it."
    new "Werde nicht übermütig. Das nächste Mal lasse ich dich vielleicht noch härter dafür arbeiten."

    # say L2482 pla
    old "Bring it."
    new "Bring es."

    # say L2484 bil
    old "Now seriously, we need to clean up before my grandma walks in and smells sex and rain in my room."
    new "Jetzt im Ernst, wir müssen aufräumen, bevor meine Oma reinkommt und Sex und Regen in meinem Zimmer riecht."

    # say L2485 pla
    old "Yeah... I’m moving."
    new "Ja... ich beweg mich."

    # say L2486 bil
    old "And [pla]?"
    new "Und [pla]?"

    # say L2488 bil
    old "Uhh, nevermind... Just keep practicing like your life depends on it. I expect results."
    new "Uhh, egal... Übe weiter, als hinge dein Leben davon ab. Ich erwarte Ergebnisse."

    # say L2489 pla
    old "I will. Promise."
    new "Ich werd's. Versprochen."

    # say L2509 pla
    old "Yeah, you said you needed me for something. But... we've been practicing a lot lately, right?"
    new "Ja, du hast gesagt, du brauchst mich für was. Aber... wir haben in letzter Zeit ziemlich viel geübt, oder?"

    # say L2510 bil
    old "Heh, yeah. But no, I don't need you for that today."
    new "Heh, ja. Aber nein, ich brauch dich heute nicht dafür."

    # say L2511 pla
    old "Wait, seriously? Not practice?"
    new "Warte, im Ernst? Kein Training?"

    # say L2512 bil
    old "Nope. Today I need you for something else."
    new "Nein. Heute brauch ich dich für was anderes."

    # say L2514 bil
    old "I want to go buy some clothes. For the contest."
    new "Ich will neue Klamotten kaufen. Für den Wettbewerb."

    # say L2515 pla
    old "Clothes? Like... an outfit?"
    new "Klamotten? So wie... ein Outfit?"

    # say L2516 bil
    old "Exactly. I don't want to show up in my usual stuff."
    new "Genau. Ich will nicht in meinen üblichen Klamotten auftauchen."

    # say L2517 bil
    old "Those other idiots are probably gonna be all glitter and sequins. I don't wanna look like I didn't even try."
    new "Die anderen Idioten werden wahrscheinlich alle Glitzer und Pailletten tragen. Ich will nicht aussehen, als hätte ich es nicht mal versucht."

    # say L2518 pla
    old "Okay, that makes sense. Let's go then. I'll help you pick."
    new "Okay, das ergibt Sinn. Lass uns losgehen. Ich helfe dir dabei auszusuchen."

    # say L2519 bil
    old "Good. I already have a few ideas. Come on."
    new "Gut. Ich hab schon ein paar Ideen. Komm."

    # say L2525 bil
    old "Alright, there's this store I saw online. Not really my usual vibe, but they might have something that works for the stage."
    new "Okay, da gibt es diesen Laden, den ich online gesehen habe. Ist nicht so mein Stil, aber sie könnten was haben, das für die Bühne passt."

    # say L2526 pla
    old "What exactly are you thinking?"
    new "Was genau hast du im Sinn?"

    # say L2527 bil
    old "Honestly? I don't know yet. I wanna look around, try a bunch of stuff, and see what feels right. Let's just go in."
    new "Ehrlich gesagt? Ich weiß noch nicht. Ich will einfach rumgucken, ein paar Sachen ausprobieren und sehen, was sich richtig anfühlt. Lass uns reingehen."

    # say L2544 bil
    old "Hi. I'm performing in a music contest in a few days and I need an outfit that fits the stage."
    new "Hi. Ich trete in ein paar Tagen bei einem Musikwettbewerb auf und brauche ein Outfit, das zur Bühne passt."

    # say L2546 bil
    old "Hello?"
    new "Hallo?"

    # say L2547 lan
    old "Huh? Oh. Yeah, everything's for sale. Just browse and bring whatever you want to the counter when you're ready."
    new "Häh? Ach so. Ja, alles ist zum Verkauf. Schau dich einfach um und bring, was du willst, zur Kasse, wenn du fertig bist."

    # say L2549 pla
    old "({i}Wow, helpful.{/i})"
    new "{i}Wow, hilfsbereit.{/i}"

    # say L2556 bil
    old "Hmm, whatever. Let's just look around."
    new "Hmm, egal. Lass uns einfach rumgucken."

    # say L2557 pla
    old "Yeah. What are you searching for exactly?"
    new "Klar. Was suchst du genau?"

    # say L2558 bil
    old "I'm not totally sure yet. I'll grab a few things, try them on, and you tell me what you think. Deal?"
    new "Ich bin mir noch nicht ganz sicher. Ich nehme ein paar Sachen, probiere sie an, und du sagst mir, was du davon hältst. Abgemacht?"

    # say L2559 pla
    old "Deal. I'll be honest."
    new "Deal. Ich werde ehrlich sein."

    # say L2560 bil
    old "You better be."
    new "Du besser."

    # say L2566 pla
    old "Ready?"
    new "Bereit?"

    # say L2568 bil
    old "Yeah. I grabbed a few options... even some wigs. Didn't expect that here."
    new "Klar. Ich hab ein paar Optionen mitgebracht... sogar ein paar Perücken. Das hier war nicht unbedingt zu erwarten."

    # say L2569 pla
    old "Wigs? For the contest?"
    new "Perücken? Für den Wettbewerb?"

    # say L2570 bil
    old "I'm trying to switch up my whole look a bit. Not going full Sparkle Queen like the others, but... something different."
    new "Ich versuche einfach, mein Aussehen ein bisschen zu verändern. Nicht so eine volle Glitzerqueen wie die anderen, aber... etwas anderes."

    # say L2579 bil
    old "Okay, first one coming out."
    new "Okay, der erste kommt raus."

    # say L2587 bil
    old "Okay... I was thinking something like what those empty headed girls would wear. Bright, short, cute. What do you think?"
    new "Okay... ich dachte an so was, wie diese leeren Mädchen tragen. Hell, kurz, süß. Was meinst du?"

    # say L2588 pla
    old "({i}Holy shit... she actually looks amazing in this. I wasn't expecting the pink to suit her this well.{/i})"
    new "{i}Verdammt... sie sieht darin echt toll aus. Ich hätte nicht gedacht, dass Rosa so gut zu ihr passt.{/i}"

    # menu L2591 
    old "Use Agamoto's eye"
    new "Agamotos Auge benutzen"

    # say L2595 pla
    old "Uhh... Y- you look really good actually. The color pops and the skirt is beautiful... wait, and that hair? It's completely black now."
    new "Uhh... Y- du siehst echt gut aus. Die Farbe steht dir und der Rock ist wunderschön... Moment, und die Haare? Die sind jetzt komplett schwarz."

    # say L2605 bil
    old "It's a wig, obviously."
    new "Es ist eine Perücke, offensichtlich."

    # say L2606 bil
    old "My green hair would clash horribly with this pink. It'd look ridiculous, so I grabbed a black one to match the outfit."
    new "Meine grünen Haare würden schrecklich zu diesem Rosa passen. Es würde lächerlich aussehen, deshalb hab ich eine schwarze Perücke genommen, die zum Outfit passt."

    # say L2607 bil
    old "Uhh... So? What do you think overall? Do you like it?"
    new "Uhh... Also? Was denkst du insgesamt? Magst du es?"

    # say L2608 pla
    old "Totally. It screams 'stage presence'."
    new "Total. Es schreit förmlich \"Bühnenpräsenz\"."

    # say L2609 bil
    old "But... it's so pink. So girly. So... not me. Ugh, too cutesy. Nope."
    new "Aber... es ist so rosa. So mädchenhaft. So... nicht ich. Igitt, zu süß. Nein."

    # say L2611 bil
    old "Whatever. Next one."
    new "Egal. Nächste."

    # say L2624 bil
    old "Ok, now this one... more elegant, kinda bohemian, long flowy thing. Thoughts?"
    new "Ok, jetzt diese hier... eleganter, irgendwie bohemian, langes fließendes Teil. Was meinst du?"

    # say L2625 pla
    old "({i}Wow... she looks absolutely stunning. The long dress and blonde hair completely transform her vibe.{/i})"
    new "{i}Wow... sie sieht absolut atemberaubend aus. Das lange Kleid und die blonden Haare verleihen ihr eine völlig neue Ausstrahlung.{/i}"

    # say L2632 pla
    old "Uhh... Damn, Billie... you look like a whole vibe. Sophisticated, mysterious... and that blonde hair? It's wild on you."
    new "Uhh... Verdammt, Billie... du siehst aus wie eine ganz andere Person. Elegante, mysteriös... und diese blonden Haare? Die stehen dir total."

    # say L2643 bil
    old "It doesn't look much like a wig, right? I picked one that blended in pretty well."
    new "Sieht nicht besonders wie eine Perücke aus, oder? Ich hab eine ausgesucht, die gut zu mir passt."

    # say L2644 pla
    old "Well, it looks a bit odd to me, but I think it's just because I know you."
    new "Na ja, es sieht ein bisschen komisch aus, aber ich denke, das liegt nur daran, dass ich dich kenne."

    # say L2645 pla
    old "It's like seeing a completely different person, you know?"
    new "Es ist, als würde ich eine völlig andere Person sehen, weißt du?"

    # say L2646 bil
    old "A different person? Uhh, but do you think it could actually work for the contest?"
    new "Eine andere Person? Uhh, aber denkst du, dass es für den Wettbewerb funktionieren könnte?"

    # say L2647 pla
    old "I guess so. It's classy as hell. You'd definitely stand out for sure."
    new "Ich denke schon. Es ist arschig nobel. Du würdest auf jeden Fall auffallen."

    # say L2648 bil
    old "Hmm, I don't know... I think it's too much. Way too much, you know?"
    new "Hmm, ich weiß nicht... Ich finde, es ist zu viel. Total übertrieben, verstehst du?"

    # say L2649 bil
    old "I feel like I'm playing dress up as some celebrity. This isn't me at all."
    new "Ich fühle mich, als würde ich mich als Berühmtheit verkleiden. Das bin ich gar nicht."

    # say L2650 bil
    old "Ughh, and no more wigs after this. They're boiling hot and I feel super fake wearing them."
    new "Ughh, und keine Perücken mehr danach. Die sind furchtbar heiß und ich fühle mich total falsch damit."

    # say L2651 bil
    old "Alright, moving on."
    new "Na gut, weiter geht's."

    # say L2665 bil
    old "Okay, this one's bolder. Short skirt, tight top... figured it might grab attention. Be honest."
    new "Okay, das Outfit ist mutiger. Kurzer Rock, enges Top... dachte, es könnte Aufmerksamkeit erregen. Sei ehrlich."

    # say L2666 pla
    old "({i}Holy fuck... her ass is completely exposed. That skirt is barely covering anything...{/i})"
    new "({i}Scheiße... ihr Arsch ist komplett frei. Der Rock bedeckt kaum was...{/i})"

    # say L2690 pla
    old "({i}Shit... no, not now! Why the hell am I getting hard right here in the middle of the store? This is so bad...{/i})"
    new "({i}Scheiße... nein, nicht jetzt! Warum zur Hölle werde ich hier mitten im Laden hart? Das ist echt schlecht...{/i})"

    # say L2691 bil
    old "So? What do you think?"
    new "So? Was denkst du?"

    # say L2692 pla
    old "I- I... Uhh... That's... This one is really nic- ass..."
    new "I- Ich... Äh... Das ist... Dieses hier ist wirklich schön..."

    # say L2695 bil
    old "Ohhh, look at that. Someone really liked what he saw."
    new "Ohhh, schau dir das an. Jemand hat wirklich gefallen, was er gesehen hat."

    # say L2696 bil
    old "You're already rock hard just from staring at my ass. How cute."
    new "Du bist schon steinhart, nur weil du meinen Hintern angestarrt hast. Wie süß."

    # say L2697 pla
    old "I- I can't help it... you look way too good like that."
    new "Ich kann einfach nicht anders... du siehst in dem Outfit echt zu gut aus."

    # say L2698 bil
    old "Mmm, really? Then don't just look."
    new "Mmm, wirklich? Dann tu doch was."

    # say L2704 bil
    old "So, you really liked this outfit, huh? Why could that be?"
    new "So, dir gefällt dieses Outfit echt so gut, hm? Warum könnte das sein?"

    # say L2705 bil
    old "Do you like how your cock looks between my cheeks?"
    new "Magst du, wie dein Schwanz zwischen meinen Backen aussieht?"

    # say L2707 bil
    old "Pull it out. I want to feel that warm big cock against my skin."
    new "Zieh es raus. Ich will dieses warme, große Ding an meiner Haut spüren."

    # say L2708 pla
    old "W- wait! Billie! We're in a fitting room... someone could walk in any second!"
    new "W-warte! Billie! Wir sind in einer Umkleidekabine... jemand könnte jeden Moment reinkommen!"

    # say L2709 bil
    old "Relax, dummy. That stupid salesgirl is still glued to her phone. No one's coming this way. We're basically alone."
    new "Beruhige dich, Dummerchen. Diese blöde Verkäuferin klebt immer noch an ihrem Handy. Niemand kommt hier rein. Wir sind praktisch allein."

    # say L2710 bil
    old "Now take your cock out... or should I do it for you?"
    new "Jetzt hol deinen Schwanz raus... oder soll ich es für dich machen?"

    # say L2714 bil
    old "Mmm... it feels warm... and so hard."
    new "Mmm... es fühlt sich warm an... und so hart."

    # say L2715 pla
    old "[bil], this is so risky..."
    new "[bil], das ist so riskant..."

    # say L2716 bil
    old "That's what makes it fun."
    new "Das ist genau das, was es spannend macht."

    # say L2730 bil
    old "It's nice you like it so much..."
    new "Es ist schön, dass dir das so gefällt..."

    # say L2732 bil
    old "Besides, this feels way too slutty for the stage. Like I'm selling my ass instead of my voice. Hard pass."
    new "Außerdem fühlt sich das viel zu schlampehaft für die Bühne an. Als würde ich meinen Arsch verkaufen anstatt meiner Stimme. Da sage ich nein."

    # say L2733 pla
    old "({i}She does look fire though... but yeah, she is right.{/i})"
    new "{i}Sie sieht heiß aus, aber ja, sie hat recht.{/i}"

    # say L2734 bil
    old "Next."
    new "Nächste."

    # say L2748 bil
    old "Last one. Casual but edgy. Urban, not too flashy. What do you say?"
    new "Letzte. Casual aber cool. Urban, nicht zu auffällig. Was sagst du?"

    # say L2749 pla
    old "({i}Fuck... even in this one she looks incredible. Those tits in that blue bra...{/i})"
    new "{i}Scheiße... selbst in diesem Outfit sieht sie unglaublich aus. Diese Titten in dem blauen BH...{/i}"

    # say L2773 pla
    old "({i}Nooo... not again! I just came all over her ass two minutes ago... What the hell is wrong with me?!{/i})"
    new "({i}Neeein... nicht schon wieder! Ich hab' doch gerade erst über ihren Arsch abgespritzt... Was zur Hölle stimmt nicht mit mir?!{/i})"

    # say L2775 pla
    old "Uhh... yeah, this one is nice too..."
    new "Uhh... ja, die ist auch schön..."

    # say L2776 bil
    old "What? Just that? Wait a second..."
    new "Was? Nur das? Warte mal..."

    # say L2777 bil
    old "Are you serious right now?! You just blew a huge load on my ass and you're already rock hard again? Just from seeing me squeeze my tits?"
    new "Bist du jetzt ernsthaft?! Du hast gerade einen riesigen Schwall auf meinen Arsch gespritzt und bist schon wieder total hart? Nur weil du mich meine Titten quetschen siehst?"

    # say L2778 bil
    old "Damn... these really drive you crazy, huh?"
    new "Verdammt... die bringen dich echt um den Verstand, oder?"

    # say L2780 bil
    old "Mmm, greedy boy... still got more for me? Let me milk you dry."
    new "Mmm, gieriger Junge... hast du noch mehr für mich? Lass mich dich leer saugen."

    # say L2781 bil
    old "Come here. Let me take care of that with my tits."
    new "Komm her. Lass mich das mit meinen Titten regeln."

    # say L2796 bil
    old "Alright, this one isn't right either."
    new "Okay, das passt auch nicht."

    # say L2797 pla
    old "What? W-why?"
    new "Was? W-warum?"

    # say L2798 bil
    old "Judging by the way you just got hard again... it doesn't make much difference from the last one."
    new "Wenn ich sehe, wie du gerade wieder hart geworden bist... macht das nicht viel Unterschied zum letzten Mal."

    # say L2799 pla
    old "Yeah... I guess you're right."
    new "Klar... Ich schätze, du hast recht."

    # say L2800 bil
    old "Hmm, whatever... I'm just gonna change back."
    new "Hmm, egal... Ich zieh mich einfach wieder um."

    # say L2801 pla
    old "({i}I thought this would be easier...{/i})"
    new "({i}Ich dachte, das wäre einfacher...{/i})"

    # say L2809 bil
    old "Alright, let's go."
    new "Okay, lass uns gehen."

    # say L2815 pla
    old "W- What? so, none of them? You didn't like any?"
    new "W- Was? Also, keine von ihnen? Dir hat keine gefallen?"

    # say L2816 bil
    old "No. None of them feel right. All that color, glitter, fake glamour..."
    new "Nein. Keines davon fühlt sich richtig an. All der Farben, Glitzer, diese künstliche Glamour..."

    # say L2817 bil
    old "It's not me. I don't want to pretend to be someone I'm not just to compete with those idiots."
    new "Das bin nicht ich. Ich will nicht so tun, als wäre ich jemand anderes, nur um mit diesen Idioten mithalten zu können."

    # say L2818 pla
    old "({i}She's got a point. That's what makes her special.{/i})"
    new "{i}Sie hat recht. Das macht sie besonders.{/i}"

    # say L2819 pla
    old "Okay, fair enough. So... sticking with your usual look for the contest?"
    new "Okay, fair enough. Also... bleibst du bei deinem üblichen Look für den Wettbewerb?"

    # say L2820 bil
    old "For now, yeah. I'll keep thinking, but I'm not forcing something that doesn't feel like me. Thanks for coming with me though. Seriously."
    new "Im Moment, ja. Ich werde weiter drüber nachdenken, aber ich zwing' mir nix auf, was nich zu mir passt. Danke, dass du mitgekommen bist. Ehrlich."

    # say L2821 pla
    old "Anytime. I had fun watching you rock every single one, even if you hated them."
    new "Immer. Es war toll, dir bei jedem Outfit zuzusehen, auch wenn du sie gehasst hast."

    # say L2822 bil
    old "Heh. Flatterer. Come on, let's get out of here before I change my mind and buy the whole store."
    new "Heh. Schmeichler. Komm, lass uns hier verschwinden, bevor ich es mir anders überlege und den ganzen Laden kaufe."

    # say L2842 bil
    old "You made it."
    new "Du hast es geschafft."

    # say L2843 pla
    old "Of course. You texted 'last practice' like it was serious."
    new "Natürlich. Du hast 'letzte Probe' geschrieben, als wäre es wichtig."

    # say L2845 pla
    old "Uh... You okay?"
    new "Uh... Geht's dir gut?"

    # say L2846 bil
    old "Yeah, don't worry. Come in."
    new "Ja, mach dir keine Sorgen. Komm rein."

    # say L2852 bil
    old "Tomorrow’s the contest."
    new "Morgen ist der Wettbewerb."

    # say L2853 pla
    old "Yeah... kinda crazy, huh?"
    new "Ja... irgendwie verrückt, oder?"

    # say L2854 bil
    old "I never thought I’d stand on a stage again."
    new "Ich dachte nie, dass ich wieder auf einer Bühne stehen würde."

    # say L2855 pla
    old "'Again'?"
    new "Wieder?"

    # say L2856 bil
    old "I mean... after everything."
    new "Ich meine... nach allem."

    # say L2857 pla
    old "But you’re here."
    new "Aber du bist hier."

    # say L2858 bil
    old "Yeah. And that scares me more than the stage."
    new "Ja. Und das macht mir mehr Angst als die Bühne."

    # say L2860 bil
    old "Because the stage can’t leave."
    new "Weil die Bühne nicht weggehen kann."

    # say L2861 pla
    old "You don’t have to carry everything alone, you know."
    new "Du musst nicht alles allein tragen, weißt du."

    # say L2863 bil
    old "Let’s run it once. Soft. No pressure."
    new "Lass uns es einmal durchgehen. Sanft. Kein Druck."

    # say L2903 pla
    old "That felt different."
    new "Das hat sich anders angefühlt."

    # say L2904 bil
    old "It always does..."
    new "Es tut das immer..."

    # say L2907 bil
    old "Do you know why I really stopped singing?"
    new "Weißt du, warum ich wirklich aufgehört habe zu singen?"

    # say L2908 pla
    old "Uhh, your grandma told me some of it."
    new "Uhh, deine Oma hat mir ein bisschen davon erzählt."

    # say L2909 bil
    old "She tells the gentle version."
    new "Sie erzählt die sanfte Version."

    # say L2910 pla
    old "What’s the real one?"
    new "Was ist die echte Version?"

    # say L2911 bil
    old "When they died... everyone said 'be strong’."
    new "Als sie starben... hat jeder gesagt, ich soll stark sein."

    # say L2912 bil
    old "So I was."
    new "Dann war ich es."

    # say L2913 bil
    old "I stopped crying. Stopped singing. Stopped needing."
    new "Ich habe aufgehört zu weinen. Aufgehört zu singen. Aufgehört zu brauchen."

    # say L2914 pla
    old "That’s not strength."
    new "Das ist keine Stärke."

    # say L2915 bil
    old "Well, it felt like survival."
    new "Na, es fühlte sich wie Überleben an."

    # say L2916 bil
    old "Every song sounded like them."
    new "Jedes Lied klang wie sie."

    # say L2917 bil
    old "Every note felt like losing them again."
    new "Jede Note fühlte sich an wie ein weiterer Verlust."

    # say L2918 pla
    old "So you buried it."
    new "Dann hast du es begraben."

    # say L2919 bil
    old "Yeah. And I buried part of me with it."
    new "Ja. Und ich habe einen Teil von mir mit begraben."

    # say L2921 bil
    old "But then you showed up. Loud. Stubborn. Impossible."
    new "Aber dann bist du aufgetaucht. Laut. Dickköpfig. Unmöglich."

    # say L2922 pla
    old "I guess I have a talent for that."
    new "Ich schätze, ich habe dafür ein Talent."

    # say L2923 bil
    old "You dragged me back to something I was scared to touch."
    new "Du hast mich zurück zu etwas gezogen, vor dem ich Angst hatte, es anzufassen."

    # say L2924 bil
    old "And now I’m scared of losing it again."
    new "Und jetzt habe ich Angst, es wieder zu verlieren."

    # say L2926 pla
    old "You won’t."
    new "Du wirst es nicht."

    # say L2927 bil
    old "You don’t know that."
    new "Du weißt das nicht."

    # say L2928 pla
    old "I know I’ll be with you."
    new "Ich weiß, dass ich bei dir sein werde."

    # say L2929 bil
    old "You promise too easily."
    new "Du versprichst zu leicht."

    # say L2930 pla
    old "I don’t make promises I can’t keep."
    new "Ich mache keine Versprechen, die ich nicht halten kann."

    # say L2931 bil
    old "I don’t want to be alone tomorrow, [pla]."
    new "Ich will morgen nicht allein sein, [pla]."

    # say L2932 pla
    old "You won’t be."
    new "Du wirst nicht allein sein."

    # say L2933 bil
    old "I mean... really alone."
    new "Ich meine... wirklich allein."

    # say L2937 pla
    old "Then don’t be."
    new "Dann sei es nicht."

    # say L2938 bil
    old "You don’t run when things get heavy?"
    new "Du flippst nicht aus, wenn es ernst wird?"

    # say L2939 pla
    old "I would never leave you."
    new "Ich würde dich nie verlassen."

    # say L2941 bil
    old "What if I break on stage?"
    new "Was, wenn ich auf der Bühne zusammenbreche?"

    # say L2942 pla
    old "Then I’ll be right there, with you."
    new "Dann bin ich direkt da, bei dir."

    # say L2943 bil
    old "What if I fail?"
    new "Was ist, wenn ich versage?"

    # say L2944 pla
    old "Then you still tried. And that already makes you brave."
    new "Dann hast du es trotzdem versucht. Und das macht dich schon mutig."

    # say L2945 bil
    old "I don’t want to have to hide anymore."
    new "Ich will nicht mehr verstecken müssen."

    # say L2946 pla
    old "Then don’t."
    new "Dann tu es nicht."

    # say L2947 bil
    old "I don’t know how to do this..."
    new "Ich weiß nicht, wie ich das machen soll..."

    # say L2948 pla
    old "Don’t. Just be real."
    new "Lass es. Sei einfach ehrlich."

    # say L2950 bil
    old "If this goes wrong tomorrow..."
    new "Wenn das morgen schiefgeht..."

    # say L2951 pla
    old "It won’t erase everything we’ve done."
    new "Es wird nicht alles, was wir getan haben, auslöschen."

    # say L2952 bil
    old "You’re not scared of me falling apart?"
    new "Du hast keine Angst, dass ich auseinanderfalle?"

    # say L2953 pla
    old "I’m scared of you thinking you have to."
    new "Ich hab Angst, dass du denkst, du musst."

    # say L2960 bil
    old "I don’t know what this is..."
    new "Ich weiß nicht, was das ist..."

    # say L2961 pla
    old "Neither do I. But I know it’s real."
    new "Ich auch nicht. Aber ich weiß, dass es echt ist."

    # say L2967 bil
    old "That... wasn’t in the plan."
    new "Das... stand nicht im Plan."

    # say L2968 pla
    old "Neither was any of this."
    new "Das auch nicht."

    # say L2969 bil
    old "I don’t want this to be a mistake."
    new "Ich will, dass das kein Fehler ist."

    # say L2970 pla
    old "Then let it be a choice."
    new "Dann lass es eine Entscheidung sein."

    # say L2971 bil
    old "I think I want you... right now..."
    new "Ich denke, ich will dich... gerade jetzt..."

    # say L2986 pla
    old "Hey... whatever happens tomorrow..."
    new "Hey... egal was morgen passiert..."

    # say L2987 pla
    old "I'm really glad you decided to do this. And I’m really proud of you."
    new "Ich bin echt froh, dass du dich dazu entschieden hast. Und ich bin echt stolz auf dich."

    # say L2989 bil
    old "Don’t make me all soft right now."
    new "Mach mich jetzt nicht so weich."

    # say L2990 bil
    old "But... thank you. For pushing me. For being here tonight."
    new "Aber... danke. Dafür, dass du mich angetrieben hast. Dafür, dass du heute Abend hier bist."

    # say L2991 pla
    old "I’ll be right there with you on that stage."
    new "Ich werde direkt neben dir auf der Bühne stehen."

    # say L2992 bil
    old "You better not run away when I get nervous."
    new "Du darfst nicht wegrennen, wenn ich nervös werde."

    # say L2994 pla
    old "Goodnight, Billie."
    new "Gute Nacht, Billie."

    # say L2997 bil
    old "Goodnight... and [pla]?"
    new "Gute Nacht... und [pla]?"

    # say L3000 bil
    old "Wait... I almost forgot something."
    new "Warte... ich hab fast was vergessen."

    # say L3005 bil
    old "Give me a second. Don’t move."
    new "Warte mal. Rühr dich nicht."

    # say L3012 bil
    old "Here. I have something for you."
    new "Hier. Ich habe was für dich."

    # say L3015 pla
    old "A jacket?"
    new "Eine Jacke?"

    # say L3017 bil
    old "It’s my dad’s old one."
    new "Es ist das alte von meinem Dad."

    # say L3018 pla
    old "Billie... I can’t take this."
    new "Billie... ich kann das nicht annehmen."

    # say L3019 bil
    old "Yes, you can. And you will."
    new "Doch, das kannst du. Und das wirst du."

    # say L3020 bil
    old "No one else deserves to wear it more than you."
    new "Niemand verdient es mehr als du, es zu tragen."

    # say L3021 bil
    old "Besides, I can’t let you show up to the contest in that same old t-shirt and those ridiculous pink shorts again."
    new "Außerdem kann ich dich nicht wieder in diesem alten T-Shirt und diesen lächerlichen rosa Shorts zum Wettbewerb gehen lassen."

    # say L3022 pla
    old "Hah... fair point."
    new "Hah... gute Argumente."

    # say L3024 bil
    old "I’m serious. I want you to have it."
    new "Ich mein's ernst. Ich will, dass du es bekommst."

    # say L3025 bil
    old "It feels right... you wearing it. It meant a lot to me."
    new "Es fühlt sich richtig an... du trägst es. Es hat mir viel bedeutet."

    # say L3027 pla
    old "Then... thank you. I’ll take good care of it."
    new "Dann... danke. Ich werde gut darauf achten."

    # say L3032 bil
    old "Mmm, looking good, handsome."
    new "Mmm, siehst gut aus, Schatz."

    # say L3033 pla
    old "Heh... you really think so?"
    new "Heh... du findest wirklich?"

    # say L3034 bil
    old "Well, not as good as it looked on him... but damn, it still looks good on you."
    new "Na ja, nicht so gut wie bei ihm... aber verdammt, es sieht immer noch toll an dir aus."

    # say L3036 bil
    old "Now go. Before I change my mind and drag you back to bed."
    new "Jetzt geh. Bevor ich es mir anders überlege und dich zurück ins Bett ziehe."

    # say L3037 pla
    old "Whoa... you really have gotten bold tonight."
    new "Wow... du bist heute echt draufgängerisch geworden."

    # say L3038 pla
    old "But yeah... we both need to rest. Big day tomorrow."
    new "Aber ja... wir beide müssen uns ausruhen. Großer Tag morgen."

    # say L3039 bil
    old "Go home. Sleep. And be ready."
    new "Geh nach Hause. Schlaf. Und sei bereit."

    # say L3040 pla
    old "I will. See you tomorrow... on that stage."
    new "Ich werd's. Bis morgen... auf der Bühne."

    # say L3041 bil
    old "See you tomorrow."
    new "Bis morgen."

    # say L3044 bil
    old "({i}Tomorrow changes everything... but tonight was ours.{/i})"
    new "{i}Morgen ändert alles... aber heute Nacht war unsere.{/i}"

    # say L3061 pla
    old "Today’s the day..."
    new "Heute ist der Tag..."

    # say L3062 pla
    old "The contest. Our contest."
    new "Der Wettbewerb. Unser Wettbewerb."

    # say L3063 pla
    old "I feel... ready. For the first time in a long time."
    new "Ich fühle mich... bereit. Zum ersten Mal seit langem."

    # say L3072 pla
    old "This jacket... it feels like she’s with me already."
    new "Diese Jacke... es fühlt sich an, als wäre sie schon bei mir."

    # say L3073 pla
    old "Alright. Let’s go win this thing."
    new "Okay. Lass uns das Ding gewinnen."

    # say L3081 pla
    old "I’m actually early for once."
    new "Ich bin tatsächlich mal früh dran."

    # say L3082 pla
    old "Billie should be here any minute. She said she’d meet me right here."
    new "Billie sollte jeden Moment hier sein. Sie hat gesagt, sie trifft sich mit mir genau hier."

    # say L3083 pla
    old "We’ve practiced so much... today’s gonna be good."
    new "Wir haben so viel geübt... heute wird es gut werden."

    # say L3096 pla
    old "Okay... she’s still not here."
    new "Okay... sie ist immer noch nicht da."

    # say L3097 pla
    old "Where is she? The contest is gonna start soon."
    new "Wo ist sie? Das Wettbewerb fängt bald an."

    # say L3098 pla
    old "She’s probably just running a little late. No big deal."
    new "Sie ist wahrscheinlich nur ein bisschen spät dran. Ist kein Problem."

    # say L3111 ari
    old "Look who it is. The tree and his little jacket upgrade."
    new "Schau mal, wer da ist. Der Baum und sein kleiner Jackett-Upgrade."

    # say L3112 tay
    old "Cute jacket, [pla]. Do you think that’s enough to impress anyone?"
    new "Cute Jacke, [pla]. Denkst du, das reicht, um jemanden zu beeindrucken?"

    # say L3113 ari
    old "Yeah, good luck trying not to be a statue again."
    new "Klar, viel Glück damit, wieder kein Standbild zu sein."

    # say L3114 pla
    old "Whatever. You two just worry about your own act."
    new "Was immer. Ihr beiden kümmert euch einfach um eure eigene Nummer."

    # say L3115 ari
    old "We’re up soon. See you losers on stage."
    new "Wir sind gleich dran. Bis später, Verlierer."

    # say L3126 pla
    old "They’re already heading in... the contest really is starting."
    new "Sie sind schon drin... der Wettbewerb fängt wirklich an."

    # say L3138 pla
    old "Still no sign of her..."
    new "Immer noch keine Spur von ihr..."

    # say L3139 pla
    old "Come on, Billie... you promised."
    new "Komm schon, Billie... du hast es versprochen."

    # say L3140 pla
    old "Screw it. I’m gonna check if the contest already started."
    new "Vergiss es. Ich werde nachsehen, ob der Wettbewerb schon angefangen hat."

    # say L3145 pla
    old "Oh no... fuck... the contest already started!"
    new "Oh nein... Scheiße... der Wettbewerb hat schon angefangen!"

    # say L3146 pla
    old "Fuck, fuck, fuck... Billie still hasn’t arrived."
    new "Scheiße, Scheiße, Scheiße... Billie ist immer noch nicht da."

    # say L3147 pla
    old "Why isn’t she here? What happened?"
    new "Warum ist sie noch nicht hier? Was ist passiert?"

    # say L3155 pla
    old "Should I run to her house? But what if she shows up and doesn’t see me?"
    new "Soll ich zu ihrem Haus rennen? Aber was, wenn sie auftaucht und mich nicht sieht?"

    # say L3156 pla
    old "No... I have to wait here. She said she’d come. I know she’s coming."
    new "Nein... Ich muss hier warten. Sie hat gesagt, sie kommt. Ich weiß, dass sie kommt."

    # say L3163 pla
    old "Billie! There you are! Finally!"
    new "Billie! Da bist du ja endlich!"

    # say L3164 pla
    old "Oh wow! You look... beautiful. Really. That outfit... wow."
    new "Oh wow! Du siehst... wunderschön aus. Ehrlich. Das Outfit... wow."

    # say L3166 bil
    old "[pla], I... I can’t do this."
    new "[pla], ich... ich kann das nicht."

    # say L3167 pla
    old "Hey, hey what’s wrong? Talk to me."
    new "Hey, hey, was ist los? Rede mit mir."

    # say L3168 bil
    old "My hands won’t stop shaking. I feel like I’m going to throw up."
    new "Meine Hände zittern die ganze Zeit. Ich fühle mich, als müsste ich mich übergeben."

    # say L3169 bil
    old "Every time I close my eyes I hear their voices... my parents. And then I remember they’re gone."
    new "Jedes Mal, wenn ich die Augen schließe, höre ich ihre Stimmen... meine Eltern. Und dann erinnere ich mich, dass sie weg sind."

    # say L3170 bil
    old "What if I open my mouth and nothing comes out? What if I break in front of everyone?"
    new "Was, wenn ich den Mund aufmache und nichts rauskommt? Was, wenn ich vor allen zusammenbreche?"

    # say L3171 pla
    old "Breathe. Look at me."
    new "Atme. Schau mich an."

    # say L3172 bil
    old "I’m not ready. I thought I was, but I’m not."
    new "Ich bin nicht bereit. Ich dachte, ich wäre es, aber ich bin es nicht."

    # say L3173 pla
    old "Come with me. We’re going somewhere quieter."
    new "Komm mit mir. Wir gehen an einen ruhigeren Ort."

    # say L3185 pla
    old "Ok, just breathe with me, okay? In... and out."
    new "Okay, atme einfach mit mir, okay? Ein... und aus."

    # say L3186 bil
    old "I can’t... my chest feels tight."
    new "Ich kann nicht... meine Brust fühlt sich eng an."

    # say L3187 pla
    old "You’re safe. I’m right here."
    new "Du bist sicher. Ich bin hier bei dir."

    # say L3188 bil
    old "It doesn’t feel safe... it feels like I’m about to lose everything again."
    new "Es fühlt sich nicht sicher an... es fühlt sich an, als würde ich alles wieder verlieren."

    # say L3203 bil
    old "What if I freeze on stage... what if I open my mouth and nothing comes out..."
    new "Was ist, wenn ich auf der Bühne einfriere... was ist, wenn ich den Mund aufmache und nichts rauskommt..."

    # say L3204 pla
    old "Billie, look at me. You’ve practiced this a thousand times."
    new "Billie, sieh mich an. Du hast das tausendmal geübt."

    # say L3205 bil
    old "Practicing is not the same as standing in front of everyone..."
    new "Das Üben ist nicht das Gleiche, wie vor allen zu stehen..."

    # say L3206 bil
    old "Every note is going to bring them back... and then they’ll disappear again..."
    new "Jede Note wird sie zurückbringen... und dann werden sie wieder verschwinden..."

    # say L3212 pla
    old "Hey... hey, come here."
    new "Hey... hey, komm her."

    # say L3214 bil
    old "I can’t... I can’t do this..."
    new "Ich schaff das nicht... ich schaff das einfach nicht..."

    # say L3217 pla
    old "({i}Nothing I say is working... she’s spiraling hard.{/i})"
    new "{i}Was ich auch sage, hilft nichts... sie dreht total durch.{/i}"

    # say L3218 pla
    old "Wait! I have an idea!"
    new "Warte! Ich hab eine Idee!"

    # say L3229 pla
    old "I don’t want to get your dad’s jacket dirty."
    new "Ich will das Jackett deines Vaters nicht schmutzig machen."

    # say L3230 bil
    old "I don’t understand..."
    new "Ich verstehe nicht..."

    # say L3231 pla
    old "Well, I want you to take off your dress... and your underwear."
    new "Dann zieh dein Kleid aus... und dein Höschen."

    # say L3232 bil
    old "W- what...?"
    new "W-was...?"

    # say L3233 pla
    old "Well, I’m using that technique you showed me once... the one that always works."
    new "Na, ich verwende die Methode, die du mir mal gezeigt hast... die, die immer funktioniert."

    # say L3234 pla
    old "It's called 'Plan B'"
    new "Es heißt Plan B"

    # say L3235 bil
    old "I- I am not sur-"
    new "Ich- Ich bin mir nicht si- sicher..."

    # say L3236 pla
    old "You calmed me down the same way once. Let me do the same for you."
    new "Du hast mich damals auch so beruhigt. Lass mich das jetzt für dich tun."

    # say L3237 bil
    old "This is insane..."
    new "Das ist verrückt..."

    # say L3238 pla
    old "Come on. Take off your dress... and the underwear. Now."
    new "Komm schon. Zieh dein Kleid aus... und das Unterzeug. Jetzt."

    # say L3240 pla
    old "I’m not asking twice. Come on, take it all off."
    new "Ich frage nicht noch einmal. Komm schon, zieh alles aus."

    # say L3241 pla
    old "Sit on my face. Let me take care of you."
    new "Setz dich auf mein Gesicht. Lass mich mich um dich kümmern."

    # say L3249 bil
    old "You’re really doing this..."
    new "Du machst das wirklich..."

    # say L3250 bil
    old "Mmm... your tongue..."
    new "Mmm... deine Zunge..."

    # say L3268 bil
    old "We’re late... but I think I can do this now."
    new "Wir sind spät dran... aber ich denke, ich kann das jetzt."

    # say L3269 pla
    old "Then let’s go win this thing."
    new "Dann lass uns das Ding gewinnen."

    # say L3273 bey
    old "Last call for Billie and [pla]!"
    new "Letzte Ansage für Billie und [pla]!"

    # say L3283 pla
    old "We’re here! We’re coming!"
    new "Wir sind da! Wir kommen!"

    # say L3285 pla
    old "Hey... look at me."
    new "Hey... schau mich an."

    # say L3286 pla
    old "You’ve got this. You’re not alone up there."
    new "Du schaffst das. Du bist da nicht allein."

    # say L3287 pla
    old "Breathe with me, okay? In... and out."
    new "Atme mit mir, okay? Ein... und aus."

    # say L3288 bil
    old "Okay... T- thank you..."
    new "Okay... D- danke..."

    # say L3289 pla
    old "You’re the one with the voice. I’m just there to hold you steady."
    new "Du bist diejenige mit der Stimme. Ich bin nur da, um dich zu stützen."

    # say L3290 pla
    old "You ready?"
    new "Bist du bereit?"

    # say L3291 bil
    old "No... but I’m doing it anyway."
    new "Nein... aber ich mach es trotzdem."

    # say L3292 pla
    old "That's good, let´s go!"
    new "Das ist gut, lass uns losgehen!"

    # say L3312 pla
    old "Do it for them."
    new "Mach es für sie."

    # say L3314 pla
    old "Do it for your mom... and your dad. They’d be so proud of you right now."
    new "Mach es für deine Mom... und deinen Dad. Sie wären jetzt so stolz auf dich."

    # say L3316 bil
    old "They would, wouldn’t they?"
    new "Sie würden, oder?"

    # say L3317 bil
    old "Thank you... for reminding me why I’m here."
    new "Danke... dass du mich daran erinnerst, warum ich hier bin."

    # say L3318 bil
    old "Let’s do this."
    new "Lass uns das machen."

    # say L3319 pla
    old "Together."
    new "Gemeinsam."

    # say L3339 bey
    old "Wow... what a night."
    new "Wow... was für eine Nacht."

    # say L3340 bey
    old "First of all, thank you all for waiting so patiently... I know we made you sit through a lot today."
    new "Zuerst danke ich euch allen für eins: Dass ihr so geduldig wart... Ich weiß, wir haben euch heute viel zumuten lassen."

    # say L3341 bey
    old "Because you didn’t just perform... you gave us a show we’re never going to forget."
    new "Denn ihr habt nicht nur aufgetreten... ihr habt uns ein Spektakel geboten, das wir nie vergessen werden."

    # say L3342 bey
    old "Every duo showed heart, talent, and courage."
    new "Jedes Duo hat Herz, Talent und Mut gezeigt."

    # say L3343 bey
    old "This wasn’t just a Music contest. This was a night full of real stories, real voices, and real passion."
    new "Das war nicht nur ein Musikwettbewerb. Das war eine Nacht voller echter Geschichten, echter Stimmen und echter Leidenschaft."

    # say L3344 bey
    old "The jury had an almost impossible job tonight."
    new "Die Jury hatte heute Abend eine fast unmögliche Aufgabe."

    # say L3345 bey
    old "They argued, they debated, they went back and forth... because every single performance deserved to be celebrated."
    new "Sie haben gestritten, debattiert und hin- und hergewechselt... denn jede einzelne Performance verdiente gefeiert zu werden."

    # say L3346 bey
    old "But after long deliberation... they finally made their decision."
    new "Aber nach langer Beratung... haben sie ihre Entscheidung getroffen."

    # say L3348 bey
    old "The winners of this year’s Music Contest are..."
    new "Die Gewinner des diesjährigen Musikwettbewerbs sind..."

    # say L3356 bey
    old "Come on up here, you two! You earned this."
    new "Kommt hoch, ihr beiden! Ihr habt es euch verdient."

    # say L3357 bey
    old "Get your prize and let everyone see the duo that stole the show tonight!"
    new "Holt euren Preis und lasst alle den Duo sehen, das heute Abend die Show gestohlen hat!"

    # say L3371 pla
    old "We... we actually did it."
    new "Wir... wir haben es tatsächlich geschafft."

    # say L3372 bil
    old "I... I can’t believe it."
    new "Ich... ich kann es nicht fassen."

    # say L3373 pla
    old "We did it."
    new "Wir haben es geschafft."

    # say L3374 bey
    old "Come on, darling... come and get your trophy."
    new "Komm schon, Schatz... komm und hol deinen Preis."

    # say L3377 pla
    old "Go ahead, this is your moment..."
    new "Mach schon, das ist dein Moment..."

    # say L3393 bey
    old "Billie, honey... would you like to say a few words to the audience?"
    new "Billie, Schatz... möchtest du ein paar Worte an das Publikum richten?"

    # say L3395 bil
    old "I... no, I’m not good with words."
    new "Ich... nein, ich bin nicht gut mit Worten."

    # say L3396 bil
    old "I don’t think I can..."
    new "Ich glaube, ich kann das nicht..."

    # say L3397 pla
    old "Come on, Billie. Say something."
    new "Komm schon, Billie. Sag was."

    # say L3398 pla
    old "They want to hear from you. You earned this moment."
    new "Sie wollen dich hören. Du hast dir diesen Moment verdient."

    # say L3401 bil
    old "Okay... just this once."
    new "Okay... nur dieses eine Mal."

    # say L3404 bil
    old "I... I didn’t think I’d ever sing again."
    new "Ich... Ich dachte, ich würde nie wieder singen."

    # say L3405 bil
    old "For years I buried this part of me because every note reminded me of my parents."
    new "Jahrelang habe ich diesen Teil von mir vergraben, weil jede Note mich an meine Eltern erinnerte."

    # say L3406 bil
    old "They taught me to sing. They taught me to love music. And when I lost them... I lost that too."
    new "Sie haben mir das Singen beigebracht. Sie haben mir beigebracht, Musik zu lieben. Und als ich sie verlor... habe ich das auch verloren."

    # say L3408 bil
    old "But someone stubborn refused to let me hide forever."
    new "Aber jemand stur weigerte sich, mich für immer zu verstecken."

    # say L3410 bil
    old "He dragged me back to the stage... even when I fought him every step of the way."
    new "Er hat mich zurück auf die Bühne gezerrt... auch wenn ich mich bei jedem Schritt gewehrt habe."

    # say L3411 bil
    old "Come here, dummy."
    new "Komm her, Dummerchen."

    # say L3420 bil
    old "So tonight... this win isn’t just mine. It’s ours."
    new "Also heute Abend... dieser Sieg gehört nicht nur mir. Er gehört uns."

    # say L3421 bil
    old "Mom... Dad... this one’s for you."
    new "Mom... Dad... das war für euch."

    # say L3437 bil
    old "I still can’t believe we actually won..."
    new "Ich kann es immer noch nicht fassen, dass wir wirklich gewonnen haben..."

    # say L3438 pla
    old "You were incredible up there. Everyone saw it."
    new "Du warst unglaublich da oben. Das hat jeder gesehen."

    # say L3439 bil
    old "I didn’t think I’d ever stand on a stage again... and now I’m holding a trophy."
    new "Ich dachte, ich würde nie wieder auf einer Bühne stehen... und jetzt halte ich einen Pokal in den Händen."

    # say L3440 bil
    old "For a long time I told myself I was going to win just to look strong... I never really believed it."
    new "Einen langen Zeit habe ich mir selbst eingeredet, dass ich gewinnen würde, um stark zu wirken... aber tief drin hab ich’s nie wirklich geglaubt."

    # say L3441 pla
    old "But you did win. And it wasn’t fake. It was real."
    new "Aber du hast gewonnen. Und es war echt. Keine Show."

    # say L3442 pla
    old "Your voice came straight from your heart. The others were all flash and technique... but you? You made people feel something."
    new "Deine Stimme kam direkt aus deinem Herzen. Die anderen waren alles Show und Technik... aber du? Du hast die Leute etwas fühlen lassen."

    # say L3444 pla
    old "I know so. That’s why you won. Not because of any outfit or trick... because it was you."
    new "Ich weiß. Deshalb hast du gewonnen. Nicht wegen irgendwelcher Klamotten oder Tricks... sondern weil du du bist."

    # say L3446 bil
    old "It’s weird... I spent years running from this, and now it feels like I finally got a piece of myself back."
    new "Es ist seltsam... Ich habe jahrelang davor geflohen, und jetzt fühlt es sich an, als hätte ich endlich ein Stück von mir zurückbekommen."

    # say L3447 pla
    old "You did. And I’m really proud of you."
    new "Du hast es geschafft. Und ich bin echt stolz auf dich."

    # say L3448 bil
    old "I couldn’t have done any of this without you."
    new "Ich hätte das alles nicht geschafft ohne dich."

    # say L3449 bil
    old "You pushed me when I wanted to hide. You stayed when I tried to push you away."
    new "Du hast mich angetrieben, als ich mich verstecken wollte. Du bist geblieben, als ich dich wegschicken wollte."

    # say L3450 pla
    old "I wasn’t going anywhere."
    new "Ich war nirgendwohin unterwegs."

    # say L3451 bil
    old "I know... and that means more than you’ll ever understand."
    new "Ich weiß... und das bedeutet mehr, als du je verstehen wirst."

    # say L3452 bil
    old "Speaking of outfits... you never really said anything about this one."
    new "Von Outfits gesprochen... du hast noch gar nichts zu diesem gesagt."

    # say L3453 bil
    old "What do you think? Be honest."
    new "Was denkst du? Sei ehrlich."

    # say L3454 pla
    old "You look... stunning. It’s edgy, it’s dark, it’s completely you. No one else could pull it off like that."
    new "Du siehst... atemberaubend aus. Es ist wild, es ist dunkel, es ist vollkommen du. Niemand sonst könnte das so hinbekommen."

    # say L3455 bil
    old "Heh... good answer."
    new "Heh... gute Antwort."

    # say L3456 bil
    old "I was nervous about wearing something so different... but the way you’re looking at me right now..."
    new "Ich war nervös, so was anderes zu tragen... aber der Blick, den du mir gerade zuwirfst..."

    # say L3457 bil
    old "Makes me want to give you a better view."
    new "Macht mich neugierig, dir einen besseren Blick zu gönnen."

    # say L3468 bil
    old "Tonight I want to celebrate... my way."
    new "Heute Nacht will ich feiern... auf meine Art."

    # say L3477 bil
    old "You’ve been staring at my tits all night... time to give them some attention."
    new "Du hast die ganze Nacht meine Titten angestarrt... Zeit, ihnen ein bisschen Aufmerksamkeit zu schenken."

    # say L3486 bil
    old "Mmm... morning already?"
    new "Mmm... ist es schon Morgen?"

    # say L3487 pla
    old "Yeah... I don’t want it to be."
    new "Klar... ich will nicht, dass es schon Morgen ist."

    # say L3488 bil
    old "Last night still feels like a dream."
    new "Letzte Nacht fühlt sich immer noch wie ein Traum an."

    # say L3489 pla
    old "It wasn’t a dream. You won. We won."
    new "Es war kein Traum. Du hast es geschafft. Wir haben es geschafft."

    # say L3490 bil
    old "And I didn’t completely fall apart... thanks to you."
    new "Und ich bin nicht komplett auseinandergefallen... dank dir."

    # say L3491 pla
    old "You didn’t need me to win. You just needed to remember who you are."
    new "Du hast mich nicht gebraucht, um zu gewinnen. Du musstest dich nur daran erinnern, wer du bist."

    # say L3492 bil
    old "Still... having you there made it feel possible."
    new "Trotzdem... dass du da warst, hat es möglich gemacht."

    # say L3494 bil
    old "I don’t usually do the whole ‘morning after’ thing."
    new "Ich mache normalerweise nicht so was am Morgen danach."

    # say L3495 pla
    old "Neither do I... but I’m really glad we did."
    new "Ich auch nicht... aber ich bin echt froh, dass wir es getan haben."

    # say L3496 bil
    old "Don’t get used to it, though. I’m still the same Billie."
    new "Aber gewöhn dich dran nicht, ich bin immer noch die gleiche Billie."

    # say L3497 pla
    old "Good. I like that Billie."
    new "Gut. Mir gefällt diese Billie."

    # say L3499 bil
    old "You should probably head home before your family starts asking questions."
    new "Du solltest wahrscheinlich nach Hause gehen, bevor deine Familie anfängt, Fragen zu stellen."

    # say L3501 pla
    old "But last night... everything we did, everything we said..."
    new "Aber letzte Nacht... alles, was wir getan haben, alles, was wir gesagt haben..."

    # say L3502 pla
    old "It meant a lot to me."
    new "Es hat mir viel bedeutet."

    # say L3504 bil
    old "It meant a lot to me too."
    new "Mir hat es auch viel bedeutet."

    # say L3505 bil
    old "I’m not great at saying this stuff, but... thank you. For not giving up on me. For pushing me. For staying."
    new "Ich bin nicht gut darin, so was zu sagen, aber... danke. Dafür, dass du nicht aufgegeben hast. Dafür, dass du mich angefeuert hast. Dafür, dass du geblieben bist."

    # say L3508 bil
    old "Alright, we better get dressed."
    new "Okay, wir sollten uns besser anziehen."

    # say L3515 pla
    old "I’ll see you at school later?"
    new "Dann sehen wir uns später in der Schule?"

    # say L3516 bil
    old "Yeah... I’ll be there."
    new "Klar... ich werd da sein."

    # say L3517 bil
    old "And don’t be late, or I’ll drag you back here again."
    new "Und komm nicht zu spät, sonst ziehe ich dich wieder hierher."

    # say L3518 pla
    old "Wouldn’t miss it."
    new "Würde ich nicht verpassen."

    # say L3524 pla
    old "Take care of yourself, Billie."
    new "Pass auf dich auf, Billie."

    # say L3525 bil
    old "You too."
    new "Du auch."

    # say L3530 bil
    old "({i}He really stayed... and I didn’t push him away.{/i})"
    new "({i}E ist wirklich geblieben... und ich habe ihn nicht weggestoßen.{/i})"

    # say L3531 bil
    old "I guess I know what it means..."
    new "Ich schätze, ich weiß, was das bedeutet..."

    # say L3551 pla
    old "Alright... time for some practice."
    new "Okay... Zeit für ein bisschen Übung."

    # say L3553 pla
    old "It’s becoming part of the routine... and I actually look forward to it."
    new "Es wird zum Ritual... und ich freue mich sogar drauf."

    # say L3574 pla
    old "Feels natural now... like the guitar is actually listening."
    new "Fühlt sich jetzt natürlich an... als würde die Gitarre tatsächlich zuhören."

    # say L3590 pla
    old "({i}This is actually fun... who would’ve thought?{/i})"
    new "{i}Das ist tatsächlich Spaß... wer hätte das gedacht?{/i}"

    # say L3605 pla
    old "Still a couple of rough spots... but overall it sounded solid."
    new "Noch ein paar holprige Stellen... aber insgesamt klang es solide."

    # say L3607 pla
    old "It doesn’t feel like a chore anymore. It feels... right."
    new "Es fühlt sich nicht mehr wie eine Pflicht an. Es fühlt sich... richtig an."

    # say L3610 pla
    old "Tomorrow I’ll pick it up again... no pressure, just playing."
    new "Morgen nehme ich es wieder auf... ohne Druck, einfach so spielen."

    # say L3651 pla
    old "Yeah... I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "Klar... Ich hab schon viel alleine geübt, aber ich merke, dass ich schneller besser werde, wenn ich mit dir zusammen bin."

    # menu L3663 
    old "Rehearse the song together"
    new "Das Lied gemeinsam üben"

    # say L3665 pla
    old "I want to polish the chords even more, you know..."
    new "Ich will die Akkorde noch besser kriegen, weißt du..."

    # say L3666 bil
    old "Heh. Going for the safe route first? Fine by me... for now."
    new "Heh. Erst mal den sicheren Weg gehen? Ist mir auch recht... fürs Erste."

    # say L3701 bil
    old "Hmm... your changes are actually smooth now. You’ve been practicing."
    new "Hmm... deine Änderungen sind jetzt tatsächlich glatt. Du hast geübt."

    # say L3706 bil
    old "Still... I wouldn’t mind if you picked something a little more fun next time."
    new "Immer noch... ich würde nichts dagegen haben, wenn du beim nächsten Mal etwas Spannenderes auswählst."

    # menu L3708 
    old "Finger practice"
    new "Fingerübungen"

    # say L3743 pla
    old "They’re... so soft every time. I can feel them filling my hands."
    new "Sie sind... jedes Mal so weich. Ich kann sie in meinen Händen spüren, wie sie sich füllen."

    # say L3744 bil
    old "Mmm... squeeze them slowly. Open and close your hands... just like that."
    new "Mmm... drück sie langsam. Mach die Hände auf und zu... genau so."

    # say L3747 bil
    old "Nngh— yeah... a little harder now. Grip them properly."
    new "Nngh— ja... jetzt ein bisschen fester. Pack sie richtig."

    # say L3750 bil
    old "Fuck... keep that pace. Squeeze them like you mean it."
    new "Scheiße... halt das Tempo. Kneife sie, als meinst du es ernst."

    # say L3753 bil
    old "Now the nipples... grab them and pull... slow at first."
    new "Jetzt die Nippel... pack sie und zieh daran... langsam zuerst."

    # say L3764 bil
    old "That’s it... stretch them gently."
    new "Das ist es... zieh sie sanft."

    # say L3772 bil
    old "Fuck... faster. Pull them nice and firm. I love how confident your hands feel now."
    new "Scheiße... schneller. Zieh sie kräftig. Ich liebe, wie sicher sich deine Hände jetzt anfühlen."

    # say L3777 bil
    old "Mmm... your touch is way more precise lately. You’ve improved a lot."
    new "Mmm... deine Berührungen sind in letzter Zeit viel präziser. Du hast dich echt verbessert."

    # say L3779 bil
    old "Keep practicing that rhythm at home... or just come back whenever you want more of... this."
    new "Übe dieses Rhythmus zu Hause... oder komm einfach wieder, wenn du mehr von... dem hier willst."

    # menu L3781 
    old "Advanced finger practice"
    new "Fortgeschrittene Fingerübungen"

    # say L3801 pla
    old "Uhh... I’ve been practicing the guitar a lot by myself lately."
    new "Uhh... Ich hab ne Menge geübt, alleine zu Hause."

    # say L3802 pla
    old "And I was thinking... maybe it would be good if I helped you with your practice too, you know?"
    new "Und ich dachte... vielleicht wäre es gut, wenn ich dir auch bei deiner Übung helfe, weißt du?"

    # say L3803 pla
    old "Like... helping you stay steady under pressure... like last time..."
    new "Wie... dir helfen, unter Druck ruhig zu bleiben... wie beim letzten Mal..."

    # say L3804 bil
    old "Heh... look at you trying to be all subtle."
    new "Heh... schau dir an, wie subtil du versuchst zu sein."

    # menu L3826 
    old "Get motivated"
    new "Mich motivieren"

    # say L3828 pla
    old "And sometimes I feel like I still need... a little extra motivation to keep improving."
    new "Und manchmal habe ich das Gefühl, dass ich immer noch... ein bisschen zusätzliche Motivation brauche, um weiterzukommen."

    # say L3829 bil
    old "Heh... so that’s what this is really about."
    new "Heh... dann geht es also darum."

    # say L3834 bil
    old "Just looking at them... does that help?"
    new "Nur sie anzusehen... hilft das?"

    # say L3836 pla
    old "Y-yeah... they look amazing but... I was thinking maybe something more... direct?"
    new "Y-ja... sie sehen unglaublich aus, aber... ich dachte, vielleicht etwas direkter?"

    # say L3839 bil
    old "Heh... fine. I know exactly how to motivate you properly."
    new "Heh... gut. Ich weiß genau, wie ich dich richtig motivieren kann."

    # say L3859 bil
    old "Phew... that’s enough for today."
    new "Phew... das reicht für heute."

    # say L3861 bil
    old "Hey... before you go."
    new "Hey... bevor du gehst."

    # say L3865 bil
    old "It’s important... and I don’t want to go alone."
    new "Es ist wichtig... und ich will nicht alleine gehen."

    # say L3875 bil
    old "Oh, by the way..."
    new "Oh, übrigens..."

    # say L3887 bil
    old "Just text me. I’ll always make time... especially if you want the fun version."
    new "Schreib mir einfach. Ich mache immer Zeit... besonders wenn du die spaßige Version willst."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mechanics/Interface.rpy
translate german strings:

    # say L7 pla
    old "I shouldn't, is weekend."
    new "Ich sollte nicht, es ist Wochenende."

    # say L412 bri
    old "This is not what it looks like..."
    new "Das ist nicht so, wie es aussieht..."

    # say L413 bri
    old "This is not a real bug... However it looks like you are using a really old file save..."
    new "Das ist kein echter Fehler... Aber es sieht so aus, als würdest du eine wirklich alte Speicherdatei verwenden..."

    # say L414 bri
    old "That's not bad, however as you can see this game has really improved since last months..."
    new "Das ist nicht schlecht, aber wie du siehst, hat sich das Spiel in den letzten Monaten wirklich verbessert."

    # say L415 bri
    old "And this version is only compatible with the two last updates 0.14.0 and 0.14.5."
    new "Und diese Version ist nur kompatibel mit den beiden letzten Updates 0.14.0 und 0.14.5."

    # say L416 bri
    old "So, if you use an old save from old versions or an old save bugged it would probably cause bugs in this version..."
    new "Dann würden wahrscheinlich Fehler auftreten, wenn du ein altes Speicherstand von früheren Versionen oder ein fehlerhaftes altes Speicherstand verwendest..."

    # say L417 bri
    old "And we don't want to ruin your experience... So, to avoid that, we suggest you try the 'Skip to new content' option."
    new "Und wir wollen dein Erlebnis ja nicht vermasseln... Deshalb empfehlen wir dir, die Option 'Zum neuen Inhalt springen' zu nutzen."

    # say L418 bri
    old "So you can play a full version of the game with only the new content in this update."
    new "Dann kannst du die vollständige Version des Spiels spielen, aber nur mit dem neuen Inhalt dieses Updates."

    # say L419 bri
    old "You just have to play start, name your character and then click the 'Skip to new content' option!"
    new "Du musst nur mit dem Spiel starten, deinen Charakter benennen und dann auf die Option 'Zum neuen Inhalt springen' klicken!"

    # say L420 bri
    old "And if you want to play an old game that you haven't played before, you can contact the developers on {a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}"
    new "Und wenn du ein altes Spiel spielen willst, das du noch nie gespielt hast, kannst du die Entwickler auf {a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a} kontaktieren."

    # say L421 bri
    old "They can give you all the support you need."
    new "Sie können dir alle Unterstützung geben, die du brauchst."

    # say L422 bri
    old "All right, that's it."
    new "Okay, das war's."

    # say L423 bri
    old "See you soon, here on Sexnote."
    new "Bis bald, hier auf SexNote."

    # say L713 pla
    old "I shouldn't go there right now."
    new "Ich sollte jetzt nicht dahin gehen."

    # say L731 pla
    old "It's too late... I shouldn't go there right now."
    new "Es ist zu spät... Ich sollte da jetzt nicht hingehen."

    # say L738 pla
    old "I'm already very tired, I should rest and continue tomorrow..."
    new "Ich bin schon sehr müde, ich sollte mich ausruhen und morgen weitermachen..."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/jonAnimations.rpy
translate german strings:

    # say L6 jon
    old "It barely fits in my mouth... My god! You really have something big here."
    new "Es passt kaum in meinen Mund... Mein Gott! Sie haben wirklich etwas Großes hier."

    # say L10 jon
    old "It's a massive cock, just like my husband's dick."
    new "Das ist ein riesiger Schwanz, genau wie der von meinem Mann."

    # say L11 pla
    old "(Wow! I can see she has some good experience at this...)"
    new "Wow! Ich sehe, sie hat wirklich Erfahrung darin..."

    # say L15 jon
    old "It's so big and Mmmm... So good..."
    new "Es ist so groß und Mmmm... So gut..."

    # say L39 pla
    old "Mrs. Jones I'm cum-"
    new "Mrs. Jones, ich komme-"

    # say L40 jon
    old "Oh Yes! Give me your sacred cum..."
    new "Oh ja! Geben Sie mir Ihren heiligen Saft..."

    # say L42 jon
    old "Ahhhhhhhhh!"
    new "Ahhhhhhhh!"

    # say L48 jon
    old "Oh my God, I really need to feel your divine presense inside me..."
    new "Oh Gott, ich muss wirklich Ihr göttliches Wesen in mir spüren..."

    # say L50 jon
    old "Come to my bedroom..."
    new "Kommen Sie in mein Schlafzimmer..."

    # say L64 pla
    old "I- I'm doing it right?"
    new "I- Ich mache das richtig?"

    # say L65 jon
    old "My pussy is speaking for me... Just feel how wet it's for you."
    new "Meine Pussy spricht für mich... Spüre nur, wie nass sie für dich ist."

    # say L69 jon
    old "I haven't felt like this in years !!"
    new "Ich habe mich schon seit Jahren nicht mehr so gefühlt!!"

    # say L70 jon
    old "Being with a young and vigorous man like you, has no comparison."
    new "Mit einem jungen und kräftigen Mann wie Ihnen kann es sich einfach nicht vergleichen."

    # say L74 pla
    old "Oh god! Oh God!"
    new "Oh Gott! Oh Gott!"

    # say L75 jon
    old "You'll make me come so badly!"
    new "Sie werden mich so schlimm kommen lassen!"

    # say L98 pla
    old "I- I'm cumming-"
    new "Ich- Ich komme-"

    # say L99 jon
    old "Ohhh mee too!!!"
    new "Ohhh ich auch!!!"

    # say L103 jon
    old "Wow, that was great... We should, get dressed before Billie arrives."
    new "Wow, das war toll... Wir sollten uns besser anziehen, bevor Billie kommt."

    # say L116 jon
    old "Oh yeah! Fuck my mouth you little boy!"
    new "Oh ja! Fick meinen Mund, du kleiner Junge!"

    # say L117 pla
    old "Oh God!"
    new "Oh Gott!"

    # say L121 jon
    old "It's so good to have it inside my mouth... I can feel your veins pumping..."
    new "Es fühlt sich so gut an, es in meinem Mund zu haben... Ich spüre, wie deine Adern pulsieren..."

    # say L122 pla
    old "Ahhhhhhh! You're so good..."
    new "Ahhhhhh! Du bist so gut..."

    # say L126 jon
    old "Yes! Faster! Faster I want you to cum on my mouth!"
    new "Ja! Schneller! Ich will, dass du in meinem Mund kommst!"

    # say L150 jon
    old "Ohh... I can feel your body tensing!"
    new "Ohh... Ich kann spüren, wie sich Ihr Körper anspannt!"

    # say L151 jon
    old "Fill my mouth with your cum!"
    new "Füllen Sie meinen Mund mit Ihrem Saft!"

    # say L162 jon
    old "I'm so wet... But today I want you to fuck my ass..."
    new "Ich bin so nass... Aber heute will ich, dass du mich von hinten fickst..."

    # say L163 pla
    old "... W- what?"
    new "W- was?"

    # say L164 jon
    old "I just want to remember the good times with my husband ..."
    new "Ich will einfach die schönen Zeiten mit meinem Mann in Erinnerung behalten..."

    # say L182 jon
    old "Oh God, it's so big it hurts!"
    new "Oh Gott, es ist so groß, dass es wehtut!"

    # say L183 pla
    old "Do you want me to stop?"
    new "Willst du, dass ich aufhöre?"

    # say L184 jon
    old "Ohh no, please don't stop, I want you to fuck my ass just like my husband used to do..."
    new "Oh nein, bitte hör nicht auf, ich will, dass du mich fickst, genau wie mein Mann es früher getan hat..."

    # say L187 jon
    old "Faster! I want you to fuck me harder!"
    new "Schneller! Ich will, dass du mich härter fickst!"

    # say L193 jon
    old "Oh yes! Just like that! Don't stop, don't stop!!"
    new "Oh ja! Genau so! Hör nicht auf, hör nicht auf!!"

    # say L194 jon
    old "It hurts, but it feels so good!"
    new "Es tut weh, aber es fühlt sich so gut an!"

    # say L217 jon
    old "Oh yeah, fill my ass with your cum!"
    new "Oh ja, füll meinen Arsch mit deinem Sperma!"

    # say L220 jon
    old "Oh God, you are definitely better than my husband..."
    new "Oh Gott, du bist definitiv besser als mein Mann..."

    # say L234 bil
    old "Wow, it's bigger than I remember..."
    new "Wow, es ist größer, als ich es in Erinnerung habe..."

    # say L235 jon
    old "Ahhhh! So nice."
    new "Ahhhh! Das ist so schön."

    # say L236 gra
    old "My goddess!"
    new "Meine Göttin!"

    # say L240 jon
    old "Let me give you a hand with this..."
    new "Lass mich dir dabei helfen..."

    # say L243 bil
    old "Oh, it looks so hot!"
    new "Oh, das sieht ja so heiß aus!"

    # say L247 bil
    old "Yeah! get that cock ready to fuck us!"
    new "Ja! Mach den Schwanz bereit, uns zu ficken!"

    # say L248 jon
    old "Oh, Billie, please watch your mouth..."
    new "Oh, Billie, bitte pass auf, was du sagst..."

    # say L271 jon
    old "Alright, I guess it's time to start, sister Grace is waiting hun!"
    new "Na gut, dann lass uns anfangen, Schwester Grace wartet schon, Liebste!"

    # say L282 gra
    old "Oh my God! It feels amazing inside of me!"
    new "Oh mein Gott! Es fühlt sich unglaublich in mir an!"

    # say L283 bil
    old "I have a great view of your pussy being fucked sister Grace..."
    new "Ich habe einen tollen Blick auf deine Pussy, die gefickt wird, Schwester Grace..."

    # say L289 gra
    old "My body and soul really needed this ritual."
    new "Mein Körper und meine Seele haben diesen Ritual wirklich gebraucht."

    # say L291 jon
    old "More... More..."
    new "Mehr... Mehr..."

    # say L292 bil
    old "If I had known about these rituals I would have become a nun too!"
    new "Wenn ich von diesen Ritualen gewusst hätte, wäre ich auch Nonne geworden!"

    # say L296 gra
    old "Oh! My dear... You'll make me cum with so much g- grace..."
    new "Oh! Meine Liebe... Du wirst mich mit so viel G-Gnade kommen lassen..."

    # say L297 gra
    old "Ahhh! I'm about t-"
    new "Ahhh! Ich bin gleich dran..."

    # say L298 bil
    old "Fuck! This is so damn good!"
    new "Verdammt! Das ist so verdammt gut!"

    # say L322 jon
    old "So good, my God!"
    new "So gut, mein Gott!"

    # say L323 pla
    old "Fuck! I'm cuming!"
    new "Fuck! Ich komme!"

    # say L324 gra
    old "Me too... Ahhh!"
    new "Mir auch... Ahhh!"

    # say L333 bil
    old "Wow, that was intense..."
    new "Wow, das war intensiv..."

    # say L334 gra
    old "My God! Thanks for this..."
    new "Mein Gott! Danke dafür..."

    # say L335 jon
    old "[pla], you're my holy savior...  Take me!"
    new "[pla], Sie sind mein himmlischer Retter... Nehmen Sie mich!"

    # say L336 pla
    old "(This is h- heaven... Shit!)"
    new "Das ist h- Himmel... Scheiße!"

    # say L341 bil
    old "Do you like what you see?"
    new "Magst du, was du siehst?"

    # say L343 jon
    old "Come on hun, it's time to give me some blessed cock."
    new "Kommen Sie schon, Schatz, es ist Zeit, mir ein gesegnetes Glied zu geben."

    # say L344 gra
    old "Oh yeah, guide Mrs. Jones, just like you did with me."
    new "Oh ja, führe Mrs. Jones, genau wie du es bei mir getan hast."

    # say L359 bil
    old "Do you feel 'God's presence' right now?"
    new "Spürst du 'Gottes Präsenz' gerade?"

    # say L360 jon
    old "Oh yes, I feel it... Very deep inside."
    new "Oh ja, ich spüre es... Tief in mir drin."

    # say L361 gra
    old "I feel too so much of your divine presence, my heavenly God!"
    new "Ich spüre auch so viel von deiner göttlichen Gegenwart, mein himmlischer Gott!"

    # say L366 jon
    old "My God! It feels amazing!"
    new "Mein Gott! Es fühlt sich fantastisch an!"

    # say L367 bil
    old "Oh yes, fuck my granny, just like you fucked me!"
    new "Oh ja, fick meine Oma, genau wie du mich gefickt hast!"

    # say L369 gra
    old "[pla], my spiritual guide, you're the best..."
    new "[pla], meine geistige Begleiterin, du bist die Beste..."

    # say L373 bil
    old "This is the best religion ever!"
    new "Das ist die beste Religion überhaupt!"

    # say L374 jon
    old "Oh, you have no idea!"
    new "Oh, Sie haben absolut keine Ahnung!"

    # say L375 jon
    old "I'm touching God right now... This is so good..."
    new "Ich berühre gerade Gott... Das ist so gut..."

    # say L399 pla
    old "I- I'm cuming again..."
    new "Ich- Ich komme wieder..."

    # say L400 jon
    old "Ahhhhhh!"
    new "Ahhhhh!"

    # say L401 bil
    old "Yeesss!"
    new "Ja!"

    # say L402 gra
    old "We need your cum, right now! We to purify ourselves."
    new "Wir brauchen deinen Samen, sofort! Wir müssen uns reinigen."

    # say L411 bil
    old "Oh, oh, it's my turn! It's my turn!"
    new "Oh, oh, es ist meine Reihe! Es ist meine Reihe!"

    # say L412 jon
    old "I'm sorry, my dear, But you must stay a virgin until marriage."
    new "Es tut mir leid, meine Liebe, aber du musst Jungfrau bleiben, bis zur Hochzeit."

    # say L413 bil
    old "W- what the fuck!? But you already had sex with him!"
    new "W- was zum Teufel!? Aber du hast doch schon mit ihm geschlafen!"

    # say L414 jon
    old "Yes, my dear, I'm a widow..."
    new "Ja, mein Liebes, ich bin eine Witwe..."

    # say L415 gra
    old "Don't worry Mrs. Jones I have an idea..."
    new "Keine Sorge, Mrs. Jones, ich habe eine Idee..."

    # say L429 pla
    old "Wow! it feels great."
    new "Wow! Das fühlt sich toll an."

    # say L430 bil
    old "Ohhh yeahh, Fuck! This is good!... Thanks sister."
    new "Ohhh ja, verdammt! Das ist gut!... Danke, Schwester."

    # say L431 gra
    old "Enjoy it honey..."
    new "Genieße es, Schatz..."

    # say L432 gra
    old "You are welcome, we all can get closer to God with [pla]'s help."
    new "Gern geschehen, wir können uns alle mit [pla]s Hilfe näher an Gott heranbringen."

    # say L435 bil
    old "Faster, I need it fater!"
    new "Schneller, ich brauche es schneller!"

    # say L438 jon
    old "We need you to do more..."
    new "Wir brauchen mehr von dir..."

    # say L439 bil
    old "The three of us need to get enough of you... Please, keep going!"
    new "Die drei von uns brauchen einfach mehr von dir... Bitte, mach weiter!"

    # say L440 gra
    old "Don't stop!"
    new "Hör nicht auf!"

    # say L444 bil
    old "Yeah, yeah, yeah... Just like this!"
    new "Ja, ja, ja... Genau so!"

    # say L445 jon
    old "Oh God! Woww!"
    new "Oh Gott! Woww!"

    # say L446 gra
    old "Ahhh! Your cock is so damn good!"
    new "Ahhh! Dein Schwanz ist so verdammt gut!"

    # say L447 gra
    old "I mean... So divine and big... Ahhh!"
    new "Ich meine... So göttlich und groß... Ahhh!"

    # say L475 gra
    old "I feel your sacred milk..."
    new "Ich spüre deinen heiligen Saft..."

    # say L476 bil
    old "Hmm, big load! Ahhh"
    new "Hmm, große Ladung! Ahhh"

    # say L477 jon
    old "This is more than enough for the three of us... But we want more..."
    new "Das reicht mehr als genug für uns drei... Aber wir wollen mehr..."

    # say L498 bil
    old "Your cock is so big and good!"
    new "Dein Schwanz ist so groß und gut!"

    # say L499 gra
    old "Yeah... This is what my soul was asking for..."
    new "Ja... Das war es, wonach meine Seele verlangt hat..."

    # say L505 gra
    old "Uhhh... It's a divine cock... So good..."
    new "Uhhh... Es ist ein göttlicher Schwanz... So gut..."

    # say L506 bil
    old "I wanna taste you more and more!"
    new "Ich will dich immer mehr schmecken!"

    # say L510 bil
    old "Fuck her... She needs more [pla], she wants more of your-"
    new "Fick sie... Sie braucht mehr [pla], sie will mehr von deinem-"

    # say L511 gra
    old "Of your massive and saint cock..."
    new "Deines riesigen und heiligen Schwanzes..."

    # say L512 bil
    old "Fuck, I need it too.."
    new "Verdammt, ich brauche es auch.."

    # say L535 bil
    old "We want your cum in our mouths..."
    new "Wir wollen deinen Saft in unseren Mündern..."

    # say L536 jon
    old "Oh yes hun, give it to us!"
    new "Oh ja, gib es uns!"


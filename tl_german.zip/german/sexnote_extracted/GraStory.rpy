# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/GraStory.rpy
translate german strings:

    # say L5 pla
    old "(God! I hope everybody is sleeping already... I gotta whisper to her...)"
    new "Verdammt! Ich hoffe, alle schlafen schon... Ich muss flüstern..."

    # say L6 pla
    old "{i}Psst psst psst, Hey... I'm [pla], I know you are in trouble... I can help you! Where are you?{/i}"
    new "{i}Psst psst psst, Hallo... Ich bin [pla], ich weiß, dass du in Schwierigkeiten steckst... Ich kann dir helfen! Wo bist du?{/i}"

    # say L7 pla
    old "{i}You can trust me... Just let me see you, I came here to help you.{/i}"
    new "{i}Du kannst mir vertrauen... Lass mich dich nur sehen, ich bin hier, um dir zu helfen.{/i}"

    # say L9 gra
    old "Hello! Who's there?"
    new "Hallo! Wer ist da?"

    # say L11 gra
    old "If you come to steal, you are in the wrong place... Don't you see this is God's house?!"
    new "Wenn du gekommen bist, um zu stehlen, bist du hier falsch... Siehst du das nicht, dass dies Gottes Haus ist?!"

    # say L13 pla
    old "(Holy shit! The nun heard me... I need to hide.)"
    new "Heilige Scheiße! Die Nonne hat mich gehört... Ich muss mich verstecken."

    # say L22 gra
    old "(But... I don't see anybody... God! Maybe it is Father Morgan...)"
    new "Aber... ich sehe niemanden... Gott! Vielleicht ist es Father Morgan..."

    # say L28 gra
    old "Father Morgan? It is you? I'm sorry, I thought it was somebody else, a thief... I didn't know you would have been here so late."
    new "Father Morgan? Sind Sie das? Es tut mir leid, ich dachte, es wäre jemand anders, ein Dieb... Ich wusste nicht, dass Sie so spät hier sein würden."

    # say L37 pla
    old "(Holy fuck!! She also entered the confessional.)"
    new "Heilige Scheiße!! Sie ist auch in die Beichte gekommen."

    # say L40 gra
    old "Father? Are you upset? I'm sorry if I disturbed you with my shouting."
    new "Pater? Sind Sie verärgert? Es tut mir leid, wenn ich Sie mit meinem Geschrei gestört habe."

    # say L41 gra
    old "I see what you're thinking... I have done wrong again and I must clean up that offense I have committed, that's why you're so quiet."
    new "Ich sehe, was Sie denken... Ich habe wieder gesündigt und muss die Sünde tilgen, deshalb sind Sie so still."

    # say L43 gra
    old "No father Morgan... You don't have to say a word."
    new "Nein Vater Morgan... Sie müssen nichts sagen."

    # say L44 gra
    old "You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "Sie wissen, dass ich dem Willen des Herrn vollkommen treu bin, ich werde Sie erneut leiten lassen, um meinen Körper von diesen schlechten Gedanken zu reinigen."

    # say L45 gra
    old "Thoughts that I had a few minutes ago."
    new "Gedanken, die ich vor ein paar Minuten hatte."

    # say L46 pla
    old "(What? What's she talking about?!)"
    new "Was? Wovon spricht sie?!"

    # say L47 pla
    old "(What's happening with her-)"
    new "Was passiert mit ihr-"

    # say L48 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I'm giving you my spirit through my body, Father."
    new "Mein Glaube an Gott bedeutet, keine Angst zu haben, und Sie sind mein Führer. Helfen Sie mir, diese sündige Seele zu reinigen. Ich gebe Ihnen meinen Geist durch meinen Körper, Vater."

    # say L49 pla
    old "(I- is she talking about... s- sex?)"
    new "I- spricht sie von... s- Sex?"

    # say L50 gra
    old "I'm ready to receive your sacred water, your purifying milk... It's my mission to reach divinity through you, let me try it one more time."
    new "Ich bin bereit, Ihr heiliges Wasser, Eure reinigende Milch zu empfangen... Es ist meine Mission, durch Euch die Göttlichkeit zu erreichen, lasst mich es noch einmal versuchen."

    # say L51 pla
    old "(Oh shit!... This is so wrong...)"
    new "Oh Scheiße... Das ist so falsch..."

    # say L52 gra
    old "I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Tell me something or show me your help, please!"
    new "Ich bitte Sie um Hilfe, ich stand am Rande der Dunkelheit und Sie haben mir das Licht gezeigt... Father Morgan? Sagen Sie etwas oder zeigen Sie mir Ihre Hilfe, bitte!"

    # say L54 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, Father."
    new "Ich will, dass unser Gott glücklich ist, es gibt nichts Besseres oder Schöneres, und ich werde ihn durch Sie glücklich machen, Vater."

    # say L55 pla
    old "(My God! Alright, I gotta do this. If I don't, she'll suspect and see that I'm not the Father Morgan.)"
    new "Mein Gott! Okay, ich muss das tun. Wenn ich es nicht tue, wird sie Verdacht schöpfen und merken, dass ich nicht der Father Morgan bin."

    # say L76 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. One more time, you've shown me how big and great you're, I feel your grace."
    new "Mein großer Father Morgan, ich habe keine Worte, um auszudrücken, wie dankbar ich bin. Noch einmal hast du mir gezeigt, wie groß und mächtig du bist, ich spüre deine Gnade."

    # say L77 gra
    old "I will go to pray for you and for your great and powerful divine tool."
    new "Ich werde für Sie beten und für Ihr großes und mächtiges göttliches Werkzeug."

    # say L79 gra
    old "Good night Father Morgan, I'll be eager to see you again."
    new "Gute Nacht, Father Morgan, ich freue mich schon darauf, Sie wiederzusehen."

    # say L93 pla
    old "(What a night!...)"
    new "Was für eine Nacht!"

    # say L94 pla
    old "(Argh! The shinigami... Shit! I couldn't find her! But I can't risk myself, perhaps the nun or the priest could come back...)"
    new "(Argh! Die Shinigami... Scheiße! Ich konnte sie nicht finden! Aber ich kann mich nicht gefährden, vielleicht kommt die Nonne oder der Priester zurück...)"

    # say L95 pla
    old "(I better come back another day...)"
    new "Ich sollte besser an einem anderen Tag wiederkommen..."

    # say L108 pla
    old "(I hope the Sister Grace doesn't not appear tonight...)"
    new "Ich hoffe, Schwester Grace taucht heute Nacht nicht auf..."

    # say L109 pla
    old "{i}Psst psst psst, Hey shinigami... I'm [pla], I know you are in trouble...{/i}"
    new "{i}Psst psst psst, Hallo Shinigami... Ich bin [pla], ich weiß, dass du in Schwierigkeiten steckst...{/i}"

    # say L110 pla
    old "{i}You can trust me... I came here to help you, let me see where you are.{/i}"
    new "{i}Du kannst mir vertrauen... Ich bin hier, um dir zu helfen, lass mich sehen, wo du bist.{/i}"

    # say L112 gra
    old "Hello! F- Father Morgan?"
    new "Hallo! F-Father Morgan?"

    # say L114 gra
    old "Is it you again?..."
    new "Ist es wieder Sie?..."

    # say L116 pla
    old "(Oh no! She's back... Damn it!)"
    new "Oh nein! Sie ist wieder da... Scheiße!"

    # say L126 gra
    old "Father Morgan? I was eager to see you again..."
    new "Father Morgan? Ich freue mich, Sie wiederzusehen..."

    # say L135 gra
    old "Father? I'm sorry for bothering you again but I still need some help, my sins keep disturbing my soul."
    new "Vater? Es tut mir leid, dass ich Sie noch einmal belästige, aber ich brauche immer noch Hilfe, meine Sünden belasten mich sehr."

    # say L136 gra
    old "I need to continue with the penance."
    new "Ich muss mit der Buße fortfahren."

    # say L140 gra
    old "No father Morgan... You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "Nein, Vater Morgan... Sie wissen, dass ich dem Willen des Herrn vollkommen treu bin, ich werde Sie erneut bitten, mich zu leiten, um meinen Körper von diesen schlechten Gedanken zu reinigen."

    # say L141 gra
    old "Thoughts that I had today, again..."
    new "Gedanken, die ich heute wieder hatte..."

    # say L142 pla
    old "(I guess I already know what she wants...)"
    new "(I schätze, ich weiß schon, was sie will...)"

    # say L143 pla
    old "(But what's happening with her, why to do this?)"
    new "(Aber was ist mit ihr los, warum macht sie das?)"

    # say L144 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "Glauben an Gott bedeutet, keine Angst zu haben, und Sie sind mein Führer. Helfen Sie mir, diese sündige Seele zu reinigen. Ich gebe Ihnen meinen Geist durch meinen Körper, Vater."

    # say L145 pla
    old "(Well, I gotta do it... Otherwise she'll realized I'm not the Father Morgan)"
    new "Na gut, ich muss es tun... Sonst merkt sie, dass ich nicht Father Morgan bin."

    # say L146 gra
    old "Yes, I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Show me your help, please!"
    new "Ja, ich bitte Sie um Hilfe, ich stand am Rande der Dunkelheit und Sie haben mir das Licht gezeigt... Father Morgan? Zeigen Sie mir Ihre Hilfe, bitte!"

    # say L148 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, my greatest Father."
    new "Ich will, dass unser Gott glücklich ist, da ist nichts Besseres oder Schöneres, und ich werde ihn durch dich glücklich machen, mein größter Vater."

    # say L149 gra
    old "My soul is open to be purified, as opened as my mouth right now..."
    new "Meine Seele ist bereit, gereinigt zu werden, genauso wie mein Mund es gerade ist..."

    # say L150 pla
    old "(Oh God!)"
    new "Oh Gott!"

    # say L166 gra
    old "My great Father Morgan, you have no idea how grateful I'm. One more time, you've shown me how big and great you're, I can taste your grace."
    new "Mein großer Vater Morgan, Sie haben keine Ahnung, wie dankbar ich bin. Noch einmal haben Sie mir gezeigt, wie groß und mächtig Sie sind, ich kann Ihre Gnade schmecken."

    # say L169 gra
    old "Good night Father Morgan, I'll be needing more of your sacred assistance to purify my existence in this world."
    new "Gute Nacht, Father Morgan, ich werde mehr von Ihrer heiligen Hilfe benötigen, um mein Dasein in dieser Welt zu reinigen."

    # say L183 pla
    old "(Damn it! I couldn't find the shinigami tonight either... I better come back another day... This is to risky, the nun could come back...)"
    new "(Dreck! Ich konnte das Shinigami heute Nacht auch nicht finden... Ich sollte besser an einem anderen Tag wiederkommen... Das ist zu riskant, die Nonne könnte zurückkommen...)"

    # say L196 pla
    old "(God! This is my last chance to find the shinigami, I gotta find her tonight.)"
    new "(Gott! Das ist meine letzte Chance, den Shinigami zu finden, ich muss sie heute Nacht finden.)"

    # say L197 pla
    old "{i}Psst psst psst, Hi... I'm [pla], a friend of shinigamis... I know you are in trouble, please show up!{/i}"
    new "{i}Psst psst psst, Hallo... Ich bin [pla], ein Freund der Shinigamis... Ich weiß, dass du in Schwierigkeiten steckst, bitte zeig dich!{/i}"

    # say L200 gra
    old "Father Morgan... I'm so glad you're here."
    new "Father Morgan... Ich bin so froh, dass Sie hier sind."

    # say L203 pla
    old "(Argh! No... No again!!!)"
    new "Argh! Nein... Nicht schon wieder!!!"

    # say L213 gra
    old "I was waiting for you, my holy savior."
    new "Ich habe auf Sie gewartet, mein heiliger Retter."

    # say L221 gra
    old "Father Morgan? How should we start tonight? Just tell me..."
    new "Father Morgan? Wie sollen wir heute beginnen? Sag es mir einfach..."

    # say L222 pla
    old "(Holy fuck!! She'll catch me this time...)"
    new "Heilige Scheiße!! Sie wird mich dieses Mal erwischen..."

    # say L223 gra
    old "Father? I already know you don't like to talk much when you're praying and well... I know what my soul needs this time. "
    new "Vater? Ich weiß schon, dass Sie nicht viel reden, wenn Sie beten und na ja... ich weiß, was meine Seele diesmal braucht."

    # say L227 gra
    old "Thoughts that I have had since long time ago."
    new "Gedanken, die ich schon lange habe."

    # say L229 gra
    old "Having faith in your God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "Mein Glaube an Ihren Gott bedeutet, keine Angst zu haben, und Sie sind mein Führer. Helfen Sie mir, diese sündige Seele zu reinigen. Ich gebe Ihnen meinen Geist durch meinen Körper, Vater."

    # say L230 pla
    old "(Shit!... I gotta do it again.)"
    new "Scheiße!... Ich muss es noch mal tun."

    # say L248 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're, I feel your grace inside."
    new "Mein großer Father Morgan, ich habe keine Worte, um auszudrücken, wie dankbar ich bin. Sie haben mir gezeigt, wie groß und mächtig Sie sind, ich spüre Ihre Gnade in mir."

    # say L251 gra
    old "Good night Father Morgan, I can't wait to feel you inside of me again."
    new "Gute Nacht, Father Morgan, ich freue mich schon darauf, dich wieder in mir zu spüren."

    # say L266 pla
    old "(Damn it! This is becoming more and more complicated.)"
    new "Verdammt! Das wird immer komplizierter."

    # say L281 pla
    old "Hmm looks like no one is around."
    new "Hmm, sieht so aus, als wäre niemand da."

    # say L282 pla
    old "Maybe the nun will come later... I better go to wait at the confessional."
    new "Vielleicht kommt die Nonne später... Ich sollte besser zum Beichtstuhl gehen."

    # say L292 gra
    old "Father Morgan? You're already here, right?"
    new "Father Morgan? Sie sind schon da, richtig?"

    # say L301 gra
    old "Thank God! So, how should we start tonight Father? Just tell me..."
    new "Gott sei Dank! Also, wie sollen wir heute Abend beginnen, Vater? Sag mir einfach..."

    # say L308 gra
    old "No,  you know what? It is better to trust in divine providence and may the Lord be the one to guide the forgiveness of my sins tonight."
    new "Nein, Sie wissen was? Es ist besser, sich auf die göttliche Vorsehung zu verlassen und dem Herrn zu überlassen, wie er mir heute Nacht bei der Sühne meiner Sünden hilft."

    # say L342 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're."
    new "Mein großer Vater Morgan, ich habe keine Worte, um auszudrücken, wie dankbar ich bin. Sie haben mir gezeigt, wie groß und mächtig Sie sind."

    # say L354 pla
    old "(It's too late, I better go to sleep...)"
    new "Es ist zu spät, ich sollte besser schlafen gehen..."

    # say L367 pla
    old "Hi sister Grace, I'm fine and you?"
    new "Hallo Schwester Grace, mir geht's gut und dir?"

    # say L368 gra
    old "I'm blessed thank God... Tell me, how can I help you?"
    new "Ich bin gesegnet, danke Gott... Erzählen Sie mir, wie ich Ihnen helfen kann?"

    # say L393 gra
    old "[pla], are you ok?"
    new "[pla], geht es Ihnen gut?"

    # say L398 pla
    old "Oh don't worry, I'm just checking if everything is okay."
    new "Oh mach dir keine Sorgen, ich checke nur, ob alles in Ordnung ist."

    # say L399 gra
    old "Oh right, thank you so much for all your help."
    new "Oh richtig, vielen Dank für Ihre Hilfe."

    # say L400 pla
    old "You are welcome, see you later."
    new "Gern geschehen, bis später."

    # say L401 gra
    old "God be with you."
    new "Gott sei mit Ihnen."


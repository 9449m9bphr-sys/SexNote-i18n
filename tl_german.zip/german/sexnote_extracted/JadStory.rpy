# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/JadStory.rpy
translate german strings:

    # say L7 pla
    old "Hi Hinn, good morning. How are you?"
    new "Hi Hinn, guten Morgen. Wie geht's dir?"

    # say L10 pla
    old "Boy, I feel like it's been a while since I've seen you."
    new "Kann sein, dass es eine Weile her ist, seit wir uns gesehen haben."

    # say L12 hin
    old "Yeah... We haven't really hung out lately."
    new "Ja... Wir haben uns echt lange nicht mehr gesehen."

    # say L13 hin
    old "Actually, I've been thinking..."
    new "Eigentlich, ich hab drüber nachgedacht..."

    # say L14 hin
    old "Do you think you would like to come to my house? Maybe we could watch a movie together?"
    new "Möchtest du vielleicht zu mir kommen? Wir könnten zusammen einen Film schauen."

    # say L15 hin
    old "I- if you want to... Of course."
    new "I- wenn du willst... Natürlich."

    # say L16 pla
    old "Of course, that would be nice."
    new "Natürlich, das wäre schön."

    # say L17 hin
    old "Really? That's great!"
    new "Wirklich? Das ist toll!"

    # say L18 hin
    old "Well, since we're done with school for the day. Would you like to go now?"
    new "Na, da die Schule für heute vorbei ist. Möchtest du jetzt losgehen?"

    # say L19 pla
    old "Sure, that sounds great."
    new "Klar, das klingt super."

    # say L33 pla
    old "Ok, so, what movie do you think you would like to watch?"
    new "Ok, also, welchen Film möchtest du denn gucken?"

    # say L34 hin
    old "Well, I've been wanting to watch this new movie called 'Lusted Note.'"
    new "Na ja, ich wollte eigentlich diesen neuen Film anschauen, der „Lusted Note“ heißt."

    # say L35 pla
    old "Uhh, ok... What's it about?"
    new "Uhh, ok... Worum geht's da?"

    # say L36 hin
    old "It's a romance movie about a stepbrother and stepsister who fall in love."
    new "Es ist ein Liebesfilm über einen Stiefbruder und eine Stiefschwester, die sich verlieben."

    # say L37 hin
    old "It's been all the rage lately, everyone says it's so good! And the lead actress is really good, I'm her fan!"
    new "Es ist gerade total in Mode, alle sagen, es ist so gut! Und die Hauptdarstellerin ist echt klasse, ich bin ihre Fan!"

    # say L38 pla
    old "Well, sounds interesting, let's watch it."
    new "Klingt interessant, lass uns es ansehen."

    # say L54 pla
    old "Wow this movie is actually really good."
    new "Wow, dieser Film ist echt gut."

    # say L55 hin
    old "Yeah, it's great."
    new "Ja, es ist toll."

    # say L56 hin
    old "I really like their love story, it's so beautiful."
    new "Ich mag ihre Liebesgeschichte wirklich, sie ist so schön."

    # say L57 hin
    old "You know, I'm very happy you decided to come, today."
    new "Weißt du, ich bin sehr froh, dass du heute gekommen bist."

    # say L58 hin
    old "I thought maybe, you wouldn't want to come."
    new "Ich dachte, vielleicht willst du gar nicht kommen."

    # say L61 pla
    old "What? Why would you think that?"
    new "Was? Warum hättest du das denken sollen?"

    # say L62 hin
    old "Well, it's just that you're such a popular guy, you know..."
    new "Na ja, du bist einfach so ein beliebter Typ, weißt du..."

    # say L63 pla
    old "Popular? Me??"
    new "Beliebt? Ich?"

    # say L64 pla
    old "Come on... There's no way you think I'm popular."
    new "Komm schon... Da kannst du doch nicht ernsthaft glauben, dass ich beliebt bin."

    # say L65 hin
    old "Well, you seem to get along quite well with a lot of people."
    new "Na ja, du kommst ziemlich gut mit vielen Leuten klar."

    # say L66 hin
    old "You know... You get along so well with Belle and Billie."
    new "Du weißt schon... Du kommst super gut mit Belle und Billie klar."

    # say L70 pla
    old "Well, you know... They're my friends too."
    new "Na ja, du weißt schon... Sie sind auch meine Freunde."

    # say L71 pla
    old "And I really like hanging out with them."
    new "Und ich mag es echt, mit ihnen abzuhängen."

    # say L72 pla
    old "But that doesn't mean I wouldn't want to hang out with you. Or that I would be too busy."
    new "Aber das heißt nicht, dass ich nicht auch gerne Zeit mit dir verbringen würde. Oder dass ich zu beschäftigt wäre."

    # say L73 pla
    old "I really enjoy spending time with you Hinn."
    new "Ich verbringe wirklich gerne Zeit mit dir, Hinn."

    # say L78 hin
    old "Thank you [pla], I really like spending time with you too."
    new "Danke [pla], ich mag es auch wirklich, Zeit mit dir zu verbringen."

    # say L92 hin
    old "You know, my mom won't come home for a while."
    new "Du weißt, meine Mom kommt erst in einer Weile nach Hause."

    # say L94 hin
    old "So... If you want, we could... You know..."
    new "Also... Wenn du willst, könnten wir... Du weißt schon..."

    # say L95 pla
    old "Uhh... Should we go up to your bedroom?"
    new "Uhh... Sollten wir nach oben in dein Schlafzimmer gehen?"

    # say L97 hin
    old "Haha, there's no need."
    new "Haha, das ist nicht nötig."

    # say L98 hin
    old "She'll take a while, so, we can just do it here."
    new "Sie wird eine Weile brauchen, also können wir es hier machen."

    # say L117 jad
    old "Well?!"
    new "Na?!"

    # say L118 jad
    old "Aren't you going to say anything?"
    new "Wirst du gar nichts sagen?"

    # say L122 hin
    old "Wait a minute! What are you doing home so early?! You told me you were going to be late today!"
    new "Warte mal! Was machst du schon zu Hause?! Du hast mir doch gesagt, dass du heute später kommst!"

    # say L123 jad
    old "I decided to come home early today."
    new "Ich hab mich entschieden, heute früher nach Hause zu kommen."

    # say L124 jad
    old "But I see now this is why you kept asking me what I was going to be doing today..."
    new "Aber jetzt sehe ich, warum du mich die ganze Zeit gefragt hast, was ich heute machen würde..."

    # say L125 jad
    old "This is incredible..."
    new "Das ist unglaublich..."

    # say L127 hin
    old "We weren't doing anything wrong you know."
    new "Wir haben doch nichts Falsches gemacht, weißt du."

    # say L128 jad
    old "I didn't say you were!"
    new "Ich hab' doch gar nichts gesagt!"

    # say L129 jad
    old "Listen Hinn, [pla], I understand you two are adults now, I'm not bothered by you having sex or anything."
    new "Hinn, [pla], ich verstehe, dass ihr beide erwachsen seid, mich stört es nicht, wenn ihr miteinander schlaft oder so."

    # say L130 jad
    old "But if you're going to have sex, please do it in a private place!"
    new "Aber wenn ihr miteinander schlaft, dann bitte in einem privaten Raum!"

    # say L131 jad
    old "Just look at the way you two are right now!"
    new "Schaut euch mal an, wie ihr beiden gerade seid!"

    # say L132 jad
    old "Just standing there completely naked!"
    new "Einfach so da stehen, komplett nackt!"

    # say L140 jad
    old "(Whoah, h-he's so big!)"
    new "Wow, d-du bist ja so groß!"

    # say L141 jad
    old "You have to think about other people, you know..."
    new "Du musst an andere denken, weißt du..."

    # say L142 hin
    old "We just didn't know you were coming home so soon..."
    new "Wir haben einfach nicht gewusst, dass du schon so früh nach Hause kommst..."

    # say L143 jad
    old "Listen, I know you guys are young and full of hormones..."
    new "Hör zu, ich weiß, ihr seid jung und voller Hormone..."

    # say L146 jad
    old "But this is the living room! I usually watch tv on that couch!"
    new "Aber das ist das Wohnzimmer! Da schaue ich normalerweise fern!"

    # say L147 jad
    old "Besides, I could've come home with company..."
    new "Außerdem hätte ich auch jemanden mit nach Hause bringen können..."

    # say L148 jad
    old "Imagine what would have happened if someone saw you and your boyfriend having sex on the couch Hinn."
    new "Stell dir vor, was passiert wäre, wenn jemand euch beim Sex auf der Couch gesehen hätte, Hinn."

    # say L151 hin
    old "B- boyfriend? (Gosh! Mom why can't you shut up...)"
    new "B- Boyfriend? (Oh Gott! Mama, kannst du nicht einfach die Klappe halten...)"

    # say L152 hin
    old "Uhh... W- We are not a... C- couple... (Not yet, THANKS MOM!)"
    new "Uhh... W- Wir sind kein... C- Couple... (Noch nicht, DANKE MOM!)"

    # say L153 hin
    old "We still being... Uhh, just friends."
    new "Wir sind noch... Äh, nur Freunde."

    # say L157 jad
    old "E- excuse me?"
    new "E- entschuldige?"

    # say L158 jad
    old "B- but you two were just..."
    new "B- aber ihr beiden wart doch gerade erst..."

    # say L159 hin
    old "Mom please, this is not your business!"
    new "Mom, das geht dich nichts an!"

    # say L161 jad
    old "Well, I guess that's just how you do things these days..."
    new "Na ja, scheint so, als würdet ihr das heutzutage einfach so machen..."

    # say L162 jad
    old "I get it, young people are a little more open nowadays, as long as your kids are safe... I guess it's alright."
    new "Ich verstehe, junge Leute sind heutzutage ein bisschen offener, solange die Kids sicher sind... Ich schätze, das ist in Ordnung."

    # say L163 jad
    old "But that's not the point, the point is that you should be more careful with these things."
    new "Aber das ist nicht der Punkt, der Punkt ist, dass du vorsichtiger damit sein solltest."

    # say L164 jad
    old "If you're going to be having sex, do it in your bedroom."
    new "Wenn ihr Sex haben wollt, macht es in eurem Schlafzimmer."

    # say L165 jad
    old "It doesn't matter if I'm not home, try to be a little respectful, will you?"
    new "Es spielt keine Rolle, ob ich zu Hause bin, versuch wenigstens ein bisschen respektvoll zu sein, okay?"

    # say L167 hin
    old "Oh my gosh! It was an accident!"
    new "Oh mein Gott! Es war ein Unfall!"

    # say L168 hin
    old "Ugh, I don't want to talk about this anymore. Come on [pla], let's go to my bedroom!"
    new "Ugh, ich will nicht mehr darüber reden. Komm schon [pla], lass uns in mein Schlafzimmer gehen!"

    # say L175 pla
    old "Sorry, Mrs. Jade."
    new "Entschuldigung, Mrs. Jade."

    # say L185 jad
    old "(God, he really has a huge...)"
    new "Mann, der hat echt einen großen..."

    # say L202 hin
    old "Listen [pla], I'm sorry about that, I didn't expect her to come home so early."
    new "Hör zu [pla], es tut mir leid, ich habe nicht damit gerechnet, dass sie so früh nach Hause kommt."

    # say L203 hin
    old "I'm also sorry about what she said. She can be a drag sometimes."
    new "Es tut mir auch leid, was sie gesagt hat. Manchmal kann sie echt nerven."

    # say L205 pla
    old "It's ok. Besides, I sort of think that she's  right."
    new "Ist okay. Und ich muss zugeben, sie hat irgendwie recht."

    # say L208 pla
    old "Yeah, I mean, we did it in the living room."
    new "Ja, ich meine, wir haben es im Wohnzimmer getan."

    # say L209 pla
    old "In a way, we're lucky she wasn't even angrier."
    new "Auf eine Art sind wir froh, dass sie nicht noch wütender war."

    # say L211 hin
    old "{b}*Sigh*{/b} Yeah, I guess you're right."
    new "{b}*Seufz*{/b} Ja, ich schätze, du hast recht."

    # say L212 hin
    old "I suppose next time we'll just have to be more careful."
    new "Ich schätze, beim nächsten Mal müssen wir einfach vorsichtiger sein."

    # say L214 hin
    old "I guess you have to go, right?"
    new "Ich schätze, du musst gehen, oder?"

    # say L215 pla
    old "Yeah, I better go home, but, maybe we can finish the movie some other time."
    new "Ja, ich sollte besser nach Hause gehen, aber vielleicht können wir das Film ein anderes Mal zu Ende schauen."

    # say L217 hin
    old "Yeah, that would be great!"
    new "Ja, das wäre toll!"

    # say L219 hin
    old "Alright, see you later [pla]."
    new "Okay, dann bis später [pla]."

    # say L238 pla
    old "Hi Hinn, I'm great. And you? How are things with your mom?"
    new "Hi Hinn, ich bin super. Und du? Wie läuft's mit deiner Mom?"

    # say L239 hin
    old "Oh, it's fine, she wasn't really all that angry."
    new "Oh, es ist in Ordnung, sie war nicht wirklich so wütend."

    # say L240 pla
    old "I see, that's good I guess."
    new "Ich sehe, das ist gut, schätze ich."

    # say L241 hin
    old "On that note, I was thinking..."
    new "Daraufhin dachte ich..."

    # say L242 hin
    old "You know, since last time we couldn't actually finish the movie, what do you think if you come over and we finish it?"
    new "Du weißt ja, letztes Mal konnten wir den Film ja nicht zu Ende gucken. Was meinst du, wenn du rüberkommst und wir ihn fertig sehen?"

    # say L244 pla
    old "Huh? Come over? To your house?"
    new "Hä? Zu dir kommen? In dein Haus?"

    # say L246 hin
    old "Yeah, of course."
    new "Klar, natürlich."

    # say L247 hin
    old "Is there a problem?"
    new "Ist da ein Problem?"

    # say L248 pla
    old "No, no problem. I'm just not sure about it, you know?"
    new "Nein, kein Problem. Ich bin nur nicht sicher, weißt du?"

    # say L249 pla
    old "What if your mother doesn't like that I go there?"
    new "Was ist, wenn deine Mutter nicht damit einverstanden ist, dass ich dahin gehe?"

    # say L250 hin
    old "Don't be silly, I told you, she's not angry."
    new "Sei nicht albern, ich hab dir doch gesagt, sie ist nicht sauer."

    # say L251 hin
    old "We just need to be careful and nothing will happen."
    new "Wir müssen einfach vorsichtig sein, dann passiert nichts."

    # say L253 pla
    old "Hmm, I guess you're right."
    new "Hmm, ich schätze, du hast recht."

    # say L254 pla
    old "Ok, I'm in."
    new "Okay, ich bin dabei."

    # say L283 jad
    old "Oh, hi [pla]! I didn't know you were here!"
    new "Oh, hallo [pla]! Ich wusste gar nicht, dass du hier bist!"

    # say L286 pla
    old "Hi Mrs. Jade, how are you? I was just watching a movie with Hinn."
    new "Hallo Mrs. Jade, wie geht es Ihnen? Ich habe gerade einen Film mit Hinn geschaut."

    # say L288 jad
    old "Well, it's good to see you again..."
    new "Na, schön Sie wiederzusehen..."

    # say L296 jad
    old "So, what are you watching?"
    new "Was seht ihr euch an?"

    # say L300 whi
    old "Phew, I definitely should take some extra parking lessons, heh."
    new "Puh, ich sollte definitiv noch ein paar zusätzliche Fahrstunden nehmen, hehe."

    # say L304 whi
    old "Oh, hi kids! How are you?"
    new "Oh, hallo Kinder! Wie geht es euch?"

    # say L314 whi
    old "Oh, it's been a while [pla]..."
    new "Oh, es ist schon eine Weile her [pla]..."

    # say L315 pla
    old "Hi Mrs. White... Nice to see you..."
    new "Hallo Mrs. White... Schön, Sie zu sehen..."

    # say L317 hin
    old "Hello Mrs. White, how are you?"
    new "Hallo Mrs. White, wie geht es Ihnen?"

    # say L318 whi
    old "I'm very good darling. I have to say I love your new outfit, it suits you much better than that old jumper you used before."
    new "Ich bin sehr gut, Darling. Ich muss sagen, ich liebe Ihr neues Outfit, es steht Ihnen viel besser als der alte Pullover, den Sie früher getragen haben."

    # say L319 whi
    old "I have to say [pla], you're also very good-looking."
    new "Ich muss sagen [pla], du siehst auch sehr gut aus."

    # say L320 whi
    old "These kids just get so big from one moment to another, right Jade?"
    new "Diese Kinder wachsen einfach so schnell, oder Jade?"

    # say L321 jad
    old "You're right, it's amazing..."
    new "Du hast recht, das ist wirklich erstaunlich..."

    # say L323 hin
    old "So, you two were out together?"
    new "So, ihr beiden wart zusammen unterwegs?"

    # say L324 jad
    old "Yeah, that's right, Mrs. White was helping me with some shores."
    new "Stimmt, Mrs. White hat mir bei ein paar Dingen geholfen."

    # say L325 jad
    old "And I told her to come to hang out with me."
    new "Und ich hab sie gebeten, mit mir abzuhängen."

    # say L326 jad
    old "We hadn't spoken in a while."
    new "Wir hatten schon eine Weile nicht mehr gesprochen."

    # say L327 hin
    old "Oh, ok. That's great."
    new "Oh, ok. Das ist toll."

    # narrator L331 
    old "{b}*PHONE RINGING*{/b}"
    new "{b}*Handy klingelt*{/b}"

    # say L333 jad
    old "Uhh, the phone is ringing. I'll be right back."
    new "Uhh, das Handy klingelt. Ich bin gleich wieder da."

    # say L338 whi
    old "So, you two were watching a movie?"
    new "Na, Sie beiden haben also einen Film geschaut?"

    # say L339 pla
    old "Yeah... that's right."
    new "Ja... genau."

    # say L340 whi
    old "Well? Was it good?"
    new "Nun? War es gut?"

    # say L341 hin
    old "Umm, yeah, I guess..."
    new "Umm, ja, ich denke schon..."

    # say L342 hin
    old "I think we're going to keep watching it, so, if you don't mind"
    new "Ich denke, wir werden weiter zuschauen, also, wenn dir das nichts ausmacht"

    # say L343 whi
    old "Oh well, I'll watch it with you then."
    new "Oh gut, dann sehe ich es mir mit euch an."

    # say L356 jad
    old "I can't believe you! I just simply can't"
    new "Ich kann es einfach nicht fassen!"

    # say L357 jad
    old "Why don't you take..."
    new "Warum nimmst du dir nicht mal selbst die Zeit, es dir anzusehen?"

    # say L358 jad
    old "No! I did not say that!"
    new "Nein! Das hab ich nicht gesagt!"

    # say L364 jad
    old "It's always the same with you Hiashi!"
    new "Es ist immer das Gleiche bei dir, Hiashi!"

    # say L370 jad
    old "It's almost as if you don't care about your daughter's well-being."
    new "Es ist fast so, als ob dir das Wohlergehen deiner Tochter egal wäre."

    # say L371 jad
    old "My God!!"
    new "Mein Gott!!"

    # say L372 jad
    old "No, NO! YOU listen to me! You have to figure out something and fulfill your responsibility or I'm taking action."
    new "Nein, NEIN! DU hörst mir zu! Du musst etwas finden und deine Verantwortung übernehmen, oder ich werde handeln."

    # say L383 jad
    old "Ok, I'm here again."
    new "Ok, ich bin wieder da."

    # say L393 whi
    old "Are you ok? What happened?"
    new "Geht es dir gut? Was ist passiert?"

    # say L394 jad
    old "Uhh, please don't tell me you heard everything I said..."
    new "Uhh, bitte sag mir nicht, dass du alles gehört hast, was ich gesagt habe..."

    # say L395 whi
    old "You weren't very quiet, to be honest..."
    new "Du warst nicht gerade leise, ehrlich gesagt..."

    # say L397 jad
    old "{b}*Sigh*{/b}... I'm very sorry, it wasn't my intention."
    new "{b}*Seufz*{/b}... Es tut mir sehr leid, das war nicht meine Absicht."

    # say L399 jad
    old "Let's just pretend it never happened, and enjoy the movie."
    new "Lass uns einfach so tun, als wäre nichts passiert, und den Film genießen."

    # say L413 whi
    old "Well, that was very good!"
    new "Na ja, das war wirklich gut!"

    # say L414 hin
    old "It really was."
    new "Es war wirklich toll."

    # say L416 whi
    old "I think I'll watch it in full when I get home. Don't you think it was great Jade?"
    new "Ich denke, ich schaue es mir zu Hause in voller Länge an. Findest du nicht auch, dass es großartig war, Jade?"

    # say L419 jad
    old "What? Oh, yeah... Very good."
    new "Was? Ach so, ja... Sehr gut."

    # say L421 whi
    old "Ok, tell me, what is it?"
    new "Okay, sag mir, was ist los?"

    # say L423 whi
    old "Come on, don't play dumb with me."
    new "Komm schon, spiel nicht die Unschuldige mit mir."

    # say L424 whi
    old "What did Hiashi say this time?"
    new "Was hat Hiashi diesmal gesagt?"

    # say L425 jad
    old "Honestly, I don't want to talk about this, especially not in front of the kids."
    new "Ehrlich, ich will nicht darüber reden, besonders nicht vor den Kindern."

    # say L426 whi
    old "Oh come on, they're adults now. Nothing bad will happen to them."
    new "Oh komm schon, sie sind jetzt Erwachsene. Ihnen passiert schon nichts."

    # say L427 whi
    old "Just spit it out, if you don't talk about it you'll be in a bad mood all week."
    new "Sag es einfach, wenn du nicht darüber redest, wirst du die ganze Woche schlecht gelaunt sein."

    # say L429 jad
    old "That was Hiashi, saying, once again! That he can't pay my alimony this month."
    new "Das war Hiashi, der sagt wieder einmal, dass er mir dieses Monat die Alimente nicht zahlen kann."

    # say L430 jad
    old "That's four months in a row! That irresponsible bum!"
    new "Das ist jetzt der vierte Monat hintereinander! Dieser verantwortungslose Kerl!"

    # say L431 jad
    old "And it's not as if things are any easy around here, he should know how the economy is around here."
    new "Und es ist ja nicht so, als ob es hier leichter wäre, er sollte wissen, wie die Wirtschaft hier ist."

    # say L432 whi
    old "That's Hiashi for you, always the same guy..."
    new "Das ist Hiashi, immer der gleiche Kerl..."

    # say L434 whi
    old "I bet he's still seeing that 19-year-old bimbo isn't he?"
    new "Ich wette, er trifft sich immer noch mit diesem 19-jährigen Flittchen, oder?"

    # say L435 jad
    old "Yes, he is! God! That's what bothers me! He doesn't have enough money to help his daughter!"
    new "Ja, das tut er! Gott! Das ist es, was mich nervt! Er hat nicht genug Geld, um seiner Tochter zu helfen!"

    # say L437 jad
    old "But he can go around buying expensive clothes and vacations for some hussy that could be his grandchild!"
    new "Aber er kann teure Klamotten und Urlaube für irgendeine Schlampe kaufen, die sein Enkelkind sein könnte!"

    # say L439 jad
    old "I'm sorry Hinn, sweety, I wouldn't want to talk to you about your father like that."
    new "Es tut mir leid, Hinn, Schatz, ich würde nicht so über deinen Vater reden wollen."

    # say L442 hin
    old "Hmph, whatever, not like any of this is new to me."
    new "Hmpf, egal, als ob das für mich was Neues wäre."

    # say L443 hin
    old "But I would've liked to have a calm movie night."
    new "Aber ich hätte gerne einen ruhigen Filmabend gehabt."

    # say L444 hin
    old "Come on [pla] let's get out of here."
    new "Komm schon [pla], lass uns hier abhauen."

    # say L457 hin
    old "Listen, I'm sorry for what happened."
    new "Hör zu, es tut mir leid, was passiert ist."

    # say L458 hin
    old "God! My mom ruins everything!"
    new "Mann! Meine Mutter ruiniert alles!"

    # say L459 pla
    old "No, no, don't worry. That's ok, I understand."
    new "Nein, nein, mach dir keine Sorgen. Das ist okay, ich verstehe."

    # say L460 pla
    old "I get it, this type of thing can stress anybody."
    new "Ich verstehe, so was kann jeden stressen."

    # say L462 hin
    old "You know, you're always very sweet."
    new "Du bist immer so lieb."

    # say L464 hin
    old "Yes, and it deserves a reward..."
    new "Ja, und das verdient eine Belohnung..."

    # say L484 pla
    old "What are we doing here?"
    new "Was machen wir hier?"

    # say L485 hin
    old "Well, we needed privacy to give you a special reward."
    new "Na ja, wir brauchten ein bisschen Privatsphäre, um dir ein besonderes Geschenk zu machen."

    # say L488 pla
    old "Whoah! What are you doing?"
    new "Whoah! Was machst du da?"

    # say L489 hin
    old "I told you, I'm giving you a reward."
    new "Hab ich doch gesagt, ich geb dir ein Geschenk."

    # say L490 hin
    old "I was thinking that we could finish what we started the other night."
    new "Ich dachte, wir könnten das beenden, was wir neulich angefangen haben."

    # say L491 hin
    old "But my mom and Mrs. White got home when I wasn't expecting it."
    new "Aber meine Mom und Mrs. White sind nach Hause gekommen, als ich es nicht erwartet habe."

    # say L492 hin
    old "So, I'll just give  you a little something before you go home."
    new "Dann gebe ich dir eben was Kleines, bevor du nach Hause gehst."

    # say L494 pla
    old "{b}*Glup*{/b}"
    new "{b}*Glups*{/b}"

    # say L510 whi
    old "Hey, what are you doing there?"
    new "Hey, was machen Sie da?"

    # say L512 jad
    old "What?! Oh, my God! You surprised me!"
    new "Was?! Oh, mein Gott! Du hast mich erschreckt!"

    # say L513 whi
    old "Well, you were taking your sweet time and you left the stove on... Do you want me to finish dinner for you?"
    new "Na ja, du hast dir Zeit gelassen und hast den Herd angelassen... Soll ich das Essen für dich fertig machen?"

    # say L514 jad
    old "No, no, I just got distracted by... Something."
    new "Nein, nein, ich war nur abgelenkt von... Etwas."

    # say L516 whi
    old "Right... Is there anything in the bathroom?"
    new "Na klar... Ist da irgendwas im Bad?"

    # say L518 jad
    old "Nothing! Nothing! I was just looking for Hinn, but she isn't there."
    new "Nichts! Nichts! Ich habe nur nach Hinn gesucht, aber sie ist nicht da."

    # say L519 whi
    old "Ok, sure."
    new "Okay, klar."

    # say L520 jad
    old "Anyway, let's go, help me with the mac and cheese."
    new "Na los, lass uns gehen, hilf mir mit dem Mac and Cheese."

    # say L538 hin
    old "That was very good."
    new "Das war sehr gut."

    # say L539 pla
    old "Yeah, it was, I wasn't expecting it though."
    new "Ja, war es, hab's aber nicht erwartet."

    # say L540 hin
    old "Well, I wanted to make it up to you for the interruption last time, you know."
    new "Na ja, ich wollte es dir für das letzte Mal wiedergutmachen, weißt du."

    # say L541 pla
    old "Yeah, I think I get it."
    new "Ja, ich denke, ich verstehe."

    # say L542 pla
    old "Anyway, I think, I shoould go home."
    new "Na ja, ich glaube, ich sollte nach Hause gehen."

    # say L543 hin
    old "Hmm, yeah you are right."
    new "Hmm, ja, du hast recht."

    # say L544 hin
    old "Listen, I'm really sorry about today, with my mom yelling all the movie and everything."
    new "Hör zu, es tut mir echt leid wegen heute, mit meiner Mom, die die ganze Zeit gebrüllt hat und so."

    # say L545 hin
    old "It ruined the movie afternoon."
    new "Es hat den Nachmittag ruiniert."

    # say L546 pla
    old "Oh come on, I still had a great time."
    new "Oh komm schon, ich hab trotzdem einen tollen Nachmittag gehabt."

    # say L547 pla
    old "If you'd like, maybe we could watch another movie some other day."
    new "Wenn du möchtest, können wir an einem anderen Tag noch einen Film gucken."

    # say L549 pla
    old "Let's do it then."
    new "Dann machen wir das."

    # say L551 pla
    old "Alright, so, I better go now."
    new "Okay, dann geh ich jetzt besser."

    # say L552 hin
    old "Oh, right. Have a good night [pla]."
    new "Oh, stimmt. Gute Nacht [pla]."

    # say L553 pla
    old "Thank you, I really enjoyed the day. See you soon Hinn."
    new "Danke, ich hab den Tag echt genossen. Bis bald Hinn."

    # say L572 hin
    old "I'm great actually, my mom and I talked, and we're both feeling a lot better."
    new "Ich bin eigentlich gut drauf, meine Mom und ich haben geredet, und wir fühlen uns beide viel besser."

    # say L573 pla
    old "That's good, it's great that you can talk about those things."
    new "Das ist gut, es ist toll, dass du darüber reden kannst."

    # say L574 pla
    old "It's a shame about the movie tho, though I suppose that still annoys you a little bit..."
    new "Schade eigentlich, was das Kino angeht, obwohl ich schätze, das nervt dich immer noch ein bisschen..."

    # say L575 hin
    old "Well, about that..."
    new "Na ja, dazu..."

    # say L577 hin
    old "Do you think you would like to go to my house again?"
    new "Meinst du, du möchtest noch mal zu mir nach Hause kommen?"

    # say L578 hin
    old "There's another movie that I would like to watch with you..."
    new "Es gibt noch einen Film, den ich mir gerne mit dir ansehen würde..."

    # say L580 pla
    old "Hmm... Yeah, sure, I don't see why not."
    new "Hmm... Ja, klar, ich sehe keinen Grund dagegen."

    # say L581 hin
    old "Hey, that's great."
    new "Hey, das ist toll."

    # say L582 hin
    old "And listen, this time my mom will be leaving for some event dinner she was invited to."
    new "Und hör zu, dieses Mal wird meine Mutter zu einem Dinner gehen, zu dem sie eingeladen wurde."

    # say L583 hin
    old "So, maybe we can finish the movie... And something else."
    new "Dann können wir vielleicht den Film zu Ende schauen... Und noch was anderes."

    # say L584 pla
    old "Oh, sure."
    new "Oh, klar."

    # say L585 pla
    old "Sounds good."
    new "Klingt gut."

    # say L587 hin
    old "Great! So, let's go."
    new "Super! Dann lass uns gehen."

    # say L617 jad
    old "God dammit!"
    new "Verdammt!"

    # say L618 hin
    old "Ugh! What now?!"
    new "Ugh! Was jetzt?!"

    # say L629 jad
    old "Oh! Hi [pla]!"
    new "Oh! Hallo [pla]!"

    # say L633 jad
    old "I didn't know you were here honey!"
    new "Ich wusste gar nicht, dass du hier bist, Schatz!"

    # say L636 jad
    old "Are you having a good time?"
    new "Bist du gut gelaunt?"

    # say L637 pla
    old "Hello Mrs. Jade, I was just watching a movie with Hinn."
    new "Hallo Mrs. Jade, ich habe gerade einen Film mit Hinn geschaut."

    # say L639 jad
    old "I'm glad honey."
    new "Ich bin froh, Schatz."

    # say L640 hin
    old "What happened now mom?"
    new "Was ist jetzt passiert, Mama?"

    # say L641 hin
    old "Why did you scream and come out running in a towel?"
    new "Warum hast du geschrien und bist im Handtuch rausgerannt?"

    # say L642 jad
    old "Well, I was taking a shower to get ready for that dinner I told you about."
    new "Na ja, ich habe mich gerade für das Abendessen, von dem ich dir erzählt habe, geduscht."

    # say L643 jad
    old "But, then my shower suddenly exploded!"
    new "Aber dann ist mein Duschkopf plötzlich explodiert!"

    # say L644 jad
    old "Now there's a lot of water running out of the piping."
    new "Jetzt läuft eine Menge Wasser aus den Rohren."

    # say L646 hin
    old "So? Just call a plumber to fix it."
    new "Und? Ruf einfach einen Klempner an, damit der es repariert."

    # say L647 jad
    old "Well, young lady, in case you haven't been paying attention lately. We're not exactly swimming in money right now."
    new "Na, junge Dame, falls dir das noch nicht aufgefallen sein sollte. Wir sind im Moment nicht gerade reich."

    # say L648 jad
    old "Since your father hasn't been paying my alimony, I've been having to take care of things."
    new "Da dein Vater meine Alimente nicht zahlt, muss ich mich selbst um alles kümmern."

    # say L649 jad
    old "Right now I just can't afford to have somebody come and redo the entire bathroom tubing."
    new "Im Moment kann ich mir einfach nicht leisten, dass jemand kommt und die gesamte Badezimmerinstallation erneuert."

    # say L651 hin
    old "Oh great!"
    new "Oh toll!"

    # say L652 pla
    old "Uh, I think that maybe I could do something about that."
    new "Ich denke, ich könnte da was machen."

    # say L653 jad
    old "Really? You know how to fix that type of thing?"
    new "Wirklich? Du weißt, wie man das reparieren kann?"

    # say L654 pla
    old "I mean, I'd have to take a look, but maybe I can do something."
    new "Ich meine, ich müsste mir das mal ansehen, aber vielleicht kann ich was machen."

    # say L655 hin
    old "Oh great, another fantastic movie night..."
    new "Oh toll, noch ein fantastischer Filmabend..."

    # say L661 pla
    old "Ok, ok, I see what happened, there was a rusty pipe, and it broke."
    new "Ok, ok, ich sehe, was passiert ist, da war eine rostige Röhre, und die ist gebrochen."

    # say L663 pla
    old "I should be able to fix that."
    new "Ich sollte das reparieren können."

    # say L664 jad
    old "Really? You think so?"
    new "Wirklich? Du denkst, das kriegst du hin?"

    # say L665 pla
    old "Well, it's going to take a while, because I'll have to change the whole piping for the bathroom."
    new "Na ja, es wird eine Weile dauern, weil ich das gesamte Rohrsystem fürs Badezimmer austauschen muss."

    # say L666 pla
    old "And that means breaking some of the wall and the floor."
    new "Und das bedeutet, dass ich Teile der Wand und des Bodens aufbrechen muss."

    # say L667 pla
    old "But it shouldn't be too much of a problem."
    new "Aber das sollte kein allzu großes Problem sein."

    # say L668 pla
    old "I actually have some experience doing house repairs and stuff."
    new "Ich hab tatsächlich schon mal was mit Hausreparaturen zu tun gehabt."

    # say L669 jad
    old "You do? Did you have a part-time job doing that?"
    new "Du hast? Hast du da einen Nebenjob gehabt?"

    # say L671 pla
    old "I guess you could call it a summer job."
    new "Ich schätze, man könnte es einen Sommerjob nennen."

    # say L673 jad
    old "I see, well, I guess the only thing I can say is. When do you start?"
    new "Ich sehe, na dann ist das Einzige, was ich sagen kann: Wann fängst du an?"

    # say L675 pla
    old "Well, I would need to get some materials. But overall it shouldn't be too expensive."
    new "Na ja, ich bräuchte ein paar Materialien. Aber insgesamt sollte es nicht zu teuer werden."

    # say L676 pla
    old "It's not too late, so, I should be able to make it to the hardware store."
    new "Es ist noch nicht zu spät, also sollte ich es noch zum Baumarkt schaffen."

    # say L678 jad
    old "Oh, but you shouldn't spend your own money on that honey."
    new "Oh, aber du solltest dein eigenes Geld dafür nicht ausgeben, Schatz."

    # say L679 pla
    old "Well, I'll just buy some things, and if you want me to, I'll just hand you the receipt the next time I'm here."
    new "Na klar, ich kaufe einfach ein paar Sachen und wenn du willst, gebe ich dir die Quittung das nächste Mal mit, wenn ich hier bin."

    # say L680 jad
    old "That would be really nice of you."
    new "Das wäre wirklich nett von dir."

    # say L681 pla
    old "Don't worry, this won't be expensive at all."
    new "Mach dir keine Sorgen, das wird überhaupt nicht teuer."

    # say L682 jad
    old "That's a relief to hear."
    new "Das ist eine Erleichterung zu hören."

    # say L683 pla
    old "Alright, I better go now, before they close."
    new "Okay, ich muss jetzt los, bevor sie schließen."

    # say L684 jad
    old "Thank you [pla], I really appreciate it."
    new "Danke [pla], ich schätze das wirklich."

    # say L685 pla
    old "Oh, it's nothing, don't worry. But, I better hurry up, it's getting a bit late."
    new "Oh, das ist nichts, mach dir keine Sorgen. Aber ich sollte mich beeilen, es wird langsam spät."

    # say L706 hin
    old "So? How bad it is?"
    new "So? Wie schlimm ist es?"

    # say L707 pla
    old "Well, not that bad, but it will definitely take a few days of work."
    new "Na ja, so schlimm ist es nicht, aber es wird definitiv ein paar Tage Arbeit brauchen."

    # say L708 hin
    old "Oh [pla], that sounds like a lot of work, you don't have to do it."
    new "Oh [pla], das klingt nach viel Arbeit, du musst das nicht machen."

    # say L709 pla
    old "Oh, don't worry. It won't be nothing, and I will be here visiting you more often."
    new "Oh, mach dir keine Sorgen. Es wird schon nicht so schlimm sein, und ich werde öfter hier sein, um dich zu besuchen."

    # say L712 hin
    old "Hmm, I really can't belive you mom..."
    new "Hmm, ich kann es echt nicht glauben, Mom..."

    # say L713 hin
    old "Anyway, so, let's finish the movie."
    new "Na ja, dann lass uns den Film zu Ende gucken."

    # say L714 pla
    old "Uhh, actually... I have to try and get to the hardware store before they close."
    new "Uhh, eigentlich... ich muss noch schnell in den Baumarkt, bevor sie schließen."

    # say L728 jad
    old "I'm sorry [pla], it wasn't my intention to ruin your movie afternoon."
    new "Es tut mir leid [pla], ich wollte euren Filmnachmittag nicht vermasseln."

    # say L729 pla
    old "It's ok, I get why she's angry. No problem, besides, you didn't know this was going to happen."
    new "Ist okay, ich verstehe, warum sie sauer ist. Kein Problem, außerdem konntest du ja nicht wissen, dass das passiert."

    # say L732 pla
    old "No problem."
    new "Kein Problem."

    # say L733 pla
    old "Now, I better leave before they close the hardware store."
    new "Dann sollte ich besser gehen, bevor der Baumarkt schließt."

    # say L734 jad
    old "Sure, thanks again, honey."
    new "Klar, danke nochmal, Schatz."

    # say L753 hin
    old "I'm fine, I guess..."
    new "Mir geht's so lala, schätze..."

    # say L754 hin
    old "Listen [pla], I wanted to apologize about the way I acted yesterday."
    new "Hör zu [pla], ich wollte mich für mein Verhalten gestern entschuldigen."

    # say L758 hin
    old "Is just that things haven't been great at home this past few days."
    new "Es ist nur, dass es zu Hause in den letzten Tagen nicht so gut gelaufen ist."

    # say L759 hin
    old "Mom has been stressed a lot, which means I've been stressed even more."
    new "Meine Mutter ist total gestresst, und deshalb bin ich es auch noch mehr."

    # say L760 hin
    old "And I thought that maybe you and I could relax a little bit."
    new "Und ich dachte, vielleicht könnten wir zwei ein bisschen entspannen."

    # say L762 hin
    old "But everytime we tried we kept being interrupted."
    new "Aber jedes Mal, wenn wir es versucht haben, wurden wir unterbrochen."

    # say L763 hin
    old "And it's just frustrating."
    new "Und es ist einfach frustrierend."

    # say L764 pla
    old "It's ok, I know how important our movie times are to you."
    new "Es ist okay, ich weiß, wie wichtig unsere Filmabende dir sind."

    # say L765 pla
    old "I completely get it, don't worry."
    new "Ich verstehe dich total, mach dir keine Sorgen."

    # say L766 hin
    old "Thank you, [pla]!"
    new "Danke, [pla]!"

    # say L767 pla
    old "By the way, I was thinking maybe I could drop by your house this afternoon."
    new "Übrigens, ich dachte, vielleicht könnte ich heute Nachmittag bei dir vorbeikommen."

    # say L768 pla
    old "And start working on the repairs for the bathroom."
    new "Und mit den Reparaturen im Badezimmer anfangen."

    # say L769 pla
    old "Maybe we could even finish that movie we started last time."
    new "Vielleicht könnten wir dann ja auch den Film zu Ende schauen, den wir letztes Mal angefangen haben."

    # say L770 hin
    old "Oh, sorry [pla], actually, I'll be staying late here in school for some days."
    new "Oh, sorry [pla], eigentlich werde ich noch ein paar Tage länger in der Schule bleiben."

    # say L771 hin
    old "I have some extracurricular activities. Helping the teacher and stuff."
    new "Ich habe ein paar außerschulische Aktivitäten. Helfe dem Lehrer und so."

    # say L773 hin
    old "But, my mom will be there. So, why don't you go and start working on the repairs?"
    new "Aber meine Mum wird da sein. Warum gehst du nicht und fängst mit den Reparaturen an?"

    # say L774 hin
    old "That way it won't take you that long, and we can have time to..."
    new "Dann dauert es nicht so lange, und wir haben Zeit, um..."

    # say L775 hin
    old "Finish the movie when I'm done with my stuff here."
    new "Dann können wir den Film zu Ende schauen, wenn ich hier fertig bin."

    # say L777 pla
    old "That's a good idea."
    new "Das ist eine gute Idee."

    # say L778 pla
    old "Ok, sure, I'll go there and get started on the repairs."
    new "Ok, klar, ich fange dann mal mit den Reparaturen an."

    # say L779 hin
    old "Alright, then see you soon. And sorry about my mom once again."
    new "Okay, dann bis bald. Und nochmal sorry wegen meiner Mom."

    # say L780 pla
    old "Hey, don't worry, everything will be alright. See you later."
    new "Hey, mach dir keine Sorgen, alles wird gut. Bis später."

    # say L796 pla
    old "Good morning, Mrs. Jade."
    new "Guten Morgen, Mrs. Jade."

    # say L797 jad
    old "Oh, Hi [pla]! Hi, how are you?"
    new "Oh, hallo [pla]! Wie geht es dir?"

    # say L798 pla
    old "Fine, thank you."
    new "Alles gut, danke."

    # say L799 jad
    old "How did it go? Were you able to get all the things you need for the repair?"
    new "Wie war es? Hast du alles bekommen, was du für die Reparatur brauchst?"

    # say L800 pla
    old "Yes, I got everything without problems, and it was even cheaper than I expected."
    new "Ja, ich hab alles ohne Probleme bekommen, und es war sogar billiger als gedacht."

    # say L801 jad
    old "Oh, thank God! Alright, then I will let you work, if you need something, please just let me know."
    new "Oh, Gott sei Dank! Okay, dann lass ich dich arbeiten, wenn du was brauchst, sag Bescheid."

    # say L803 pla
    old "Alright, I'll get to it."
    new "Okay, mach ich."

    # say L812 pla
    old "Hi Mrs. Jade, how are you?"
    new "Hallo Mrs. Jade, wie geht es dir?"

    # say L813 jad
    old "[pla]! Hi, how are you?"
    new "[pla]! Hallo, wie geht es dir?"

    # say L816 jad
    old "Did you come to work in the bathroom?"
    new "Bist du hier, um im Badezimmer zu arbeiten?"

    # say L818 pla
    old "Yes, there is still work to be done."
    new "Ja, es gibt noch Arbeit zu tun."

    # say L819 jad
    old "Oh, thank you darling. Well, you know where the materials are, I won't bother you."
    new "Oh, danke Schatz. Du weißt ja, wo die Materialien sind, ich störe dich nicht."

    # say L821 pla
    old "Sure, I'll get to it."
    new "Klar, ich mach das."

    # say L827 pla
    old "There's some work to do here. But, I know what I have to do, so, it should be easy."
    new "Hier gibt es Arbeit zu tun. Aber ich weiß, was ich tun muss, also sollte es einfach sein."

    # say L828 pla
    old "Well, I guess I'll get to it."
    new "Na gut, dann mach ich mal."

    # say L829 pla
    old "I'll try and finish this quickly."
    new "Ich werd' versuchen, das schnell zu beenden."

    # say L872 pla
    old "Phew, I got a lot done today."
    new "Phew, ich hab heute echt viel geschafft."

    # say L873 pla
    old "Although, I still have quite a bit to do, anyway, at least this is something."
    new "Obwohl ich noch ziemlich viel zu tun habe, ist es immerhin schon was."

    # say L874 pla
    old "It's kinda late, so, let's call it a day."
    new "Es ist ziemlich spät, lass uns für heute Schluss machen."

    # say L895 pla
    old "But, she knew I was here, just next to her bedroom..."
    new "Aber sie wusste, dass ich hier bin, direkt neben ihrem Schlafzimmer..."

    # say L911 jad
    old "It's getting a bit late [pla], I think we just better call it a day."
    new "Es wird langsam spät [pla], ich denke, wir sollten besser Schluss machen."

    # say L913 pla
    old "That's right Mrs. Jade, I'm actually happy with it, I got quite a bit done today."
    new "Das stimmt, Mrs. Jade, ich bin eigentlich zufrieden, ich habe heute ganz schön viel geschafft."

    # say L914 pla
    old "But you are right, it's kinda late now, I better come back and continue another time."
    new "Aber du hast recht, es ist schon ziemlich spät, ich sollte besser ein anderes Mal wiederkommen und weitermachen."

    # say L915 jad
    old "Well, it's great that you had progressed a lot, thanks, honey."
    new "Na, das ist ja toll, dass du so viel geschafft hast, danke, Schatz."

    # say L916 jad
    old "You have no idea of how helpful you are."
    new "Du hast keine Ahnung, wie hilfreich du bist."

    # say L917 pla
    old "My pleasure."
    new "Mein Vergnügen."

    # say L918 jad
    old "You're so sweet."
    new "Du bist so lieb."

    # say L919 jad
    old "By the way, don't forget to bring me the bill for the materials, so, that I can reimburse you."
    new "Ach ja, vergiss nicht, mir die Rechnung für die Materialien zu bringen, damit ich dich entschädigen kann."

    # say L920 pla
    old "Sure thing. Well, good night Mrs. Jade."
    new "Klar. Also, eine gute Nacht, Mrs. Jade."

    # say L921 jad
    old "Good night honey."
    new "Gute Nacht Schatz."

    # say L958 hin
    old "Hi [pla], you came to help mom with the bathroom?"
    new "Hi [pla], bist du gekommen, um Mom beim Badezimmer zu helfen?"

    # say L960 pla
    old "I wasn't expecting to see you here. I thought you had that extra work with the teacher."
    new "Ich habe dich hier nicht erwartet. Ich dachte, du hast noch Extraunterricht bei der Lehrerin."

    # say L962 hin
    old "Well, I did, but the teacher had something important to do."
    new "Na, das hatte ich, aber die Lehrerin hatte was Wichtiges zu erledigen."

    # say L963 hin
    old "So, I'm free today."
    new "Dann bin ich heute frei."

    # say L965 hin
    old "Yeah, it is, and my mom is  not here, and she'll be out for a while... You know what this means, right?"
    new "Ja, und meine Mum ist nicht da und wird auch noch eine Weile weg sein... Du weißt schon, was das bedeutet, oder?"

    # say L966 pla
    old "Uhh, you want to finish the movie?"
    new "Uhh, willst du den Film zu Ende gucken?"

    # say L967 hin
    old "Hahaha, no you dummy."
    new "Hahaha, nein, du Dummerchen."

    # say L968 hin
    old "I mean that we're finally alone."
    new "Ich meine, dass wir endlich allein sind."

    # say L974 hin
    old "We have some privacy to be a little... Intimate."
    new "Wir haben ein bisschen Privatsphäre, um ein wenig... intim zu sein."

    # say L975 pla
    old "Oh... A- alright."
    new "Oh... A- abgemacht."

    # say L976 hin
    old "So, what do you say? We should go up to my bedroom."
    new "Also, was sagst du? Wir sollten in mein Schlafzimmer gehen."

    # say L977 pla
    old "Uhh... Are you sure about this? I mean what if your mom comes home and sees us again?"
    new "Uhh... Bist du dir da sicher? Ich meine, was ist, wenn deine Mom nach Hause kommt und uns wieder sieht?"

    # say L979 hin
    old "Relax, she won't be home for a while. Besides, you heard what she told us, she's ok with us doing it."
    new "Beruhige dich, sie wird noch eine Weile nicht zu Hause sein. Außerdem hast du gehört, was sie uns gesagt hat, sie ist damit einverstanden, dass wir es tun."

    # say L980 hin
    old "And we'll be in my bedroom."
    new "Und wir werden in meinem Schlafzimmer sein."

    # say L981 pla
    old "I- I guess you're right."
    new "I- Ich schätze, du hast recht."

    # say L983 hin
    old "Stop worrying, just come with me."
    new "Hör auf, dir Sorgen zu machen, komm einfach mit mir."

    # say L991 hin
    old "I've been waiting for this for a while."
    new "Ich habe schon lange darauf gewartet."

    # say L992 hin
    old "Every time we've tried to do it we've been getting interrupted."
    new "Jedes Mal, wenn wir es versucht haben, wurden wir unterbrochen."

    # say L993 hin
    old "I was thinking we were never going to have a chance to do it again."
    new "Ich dachte, wir kriegen nie wieder die Chance dazu."

    # say L994 pla
    old "Well, we're finally alone."
    new "Na, endlich sind wir allein."

    # say L995 hin
    old "Yeah, so, let's don't waste more time. I want to feel you inside."
    new "Dann lass uns keine Zeit mehr verschwenden. Ich will dich in mir spüren."

    # say L1009 hin
    old "Well, I'm very happy we finally got to do it without being interrupted."
    new "Na, ich bin echt froh, dass wir endlich ungestört sind."

    # say L1010 pla
    old "Yeah, me too..."
    new "Ja, ich auch..."

    # say L1011 hin
    old "Are you going home now?"
    new "Geht es jetzt nach Hause?"

    # say L1012 pla
    old "I think I'll go take a look at the bathroom before your mom gets home."
    new "Ich denke, ich schau mir noch schnell die Toilette an, bevor deine Mom nach Hause kommt."

    # say L1013 hin
    old "Ok, then I guess I'll just stay here and organize my bedroom."
    new "Ok, dann bleibe ich wohl hier und räume mein Schlafzimmer auf."

    # say L1025 pla
    old "Oh! Hi Mrs. Jade."
    new "Oh! Hallo Mrs. Jade."

    # say L1026 pla
    old "I didn't know you were home already."
    new "Ich wusste nicht, dass du schon zu Hause bist."

    # say L1028 jad
    old "Hi [pla], I- I just arrived."
    new "Hi [pla], ich bin gerade erst angekommen."

    # say L1029 jad
    old "Did you come to check on the bathroom?"
    new "Bist du gekommen, um das Badezimmer zu überprüfen?"

    # say L1030 pla
    old "Uhh... I did, yeah, then I ran into Hinn, and we started talking."
    new "Uhh... hab ich, ja, dann bin ich Hinn über den Weg gelaufen und wir haben angefangen zu quatschen."

    # say L1031 jad
    old "Oh, that's ok."
    new "Oh, das ist in Ordnung."

    # say L1032 jad
    old "Actually, [pla], it's getting kind of late, and I'm sure you must be tired from working so... Hard."
    new "Eigentlich, [pla], wird es langsam spät und ich bin sicher, du musst müde sein von der ganzen harten Arbeit."

    # say L1034 jad
    old "Why don't you go home for now? And just come back another time?"
    new "Warum gehst du nicht nach Hause? Und kommst einfach ein anderes Mal wieder?"

    # say L1036 pla
    old "Are you sure? I'm not really all that tired, I could just work a little on the bathroom and..."
    new "Bist du sicher? Ich bin eigentlich gar nicht so müde, ich könnte noch ein bisschen im Bad weitermachen und..."

    # say L1037 jad
    old "I'm sure. I think I would like to go to bed early today, so, it's fine if you take a day free."
    new "Ich bin sicher. Ich denke, ich würde heute gerne früher ins Bett gehen, also ist es in Ordnung, wenn du dir heute freinimmst."

    # say L1038 pla
    old "Uh, ok, sure."
    new "Uh, okay, klar."

    # say L1039 pla
    old "Then I guess I'll leave for today."
    new "Dann geh ich wohl für heute."

    # say L1040 jad
    old "Sure honey, see you later."
    new "Klar Schatz, bis später."

    # say L1056 pla
    old "Oh, hi Hinn! I didn't think I'd see you here. I thought you were going to be in school."
    new "Oh, hallo Hinn! Ich dachte, du wärst in der Schule."

    # say L1057 hin
    old "Hi [pla], I only popped in to grab a couple of books, I'm on my way back."
    new "Hi [pla], ich bin nur kurz reingekommen, um ein paar Bücher zu holen, ich muss gleich wieder zurück."

    # say L1059 pla
    old "Uhh, yeah."
    new "Uhh, ja."

    # say L1060 hin
    old "Well, my mom's not home right now, but you can go ahead and get started."
    new "Na, meine Mom ist gerade nicht da, aber du kannst schon mal anfangen."

    # say L1061 hin
    old "She'll be here in no time."
    new "Sie wird gleich da sein."

    # say L1063 hin
    old "Good, that way you'll finish quickly."
    new "Gut, dann bist du schnell fertig."

    # say L1064 hin
    old "So, that we'll have time to ourselves again."
    new "Dann haben wir wieder Zeit für uns."

    # say L1066 hin
    old "Well, I gotta run, bye [pla]."
    new "Na, dann muss ich los, tschüss [pla]."

    # say L1067 pla
    old "See you Hinn!"
    new "Bis dann, Hinn!"

    # say L1090 jad
    old "Oh God! [pla]! W- What are you doing here?"
    new "Oh Gott! [pla]! W- Was machst du hier?"

    # say L1097 pla
    old "I- I came to work on the bathroom."
    new "I- Ich bin hier, um im Badezimmer zu arbeiten."

    # say L1098 pla
    old "I didn't know you were here Mrs. Jade."
    new "Ich wusste nicht, dass du hier bist, Mrs. Jade."

    # say L1099 jad
    old "Uhh... I- it's fine, I suppose Hinn let you in while I wasn't in here, right?"
    new "Uhh... I- es ist okay, ich schätze, Hinn hat dich reingelassen, während ich nicht hier war, oder?"

    # say L1100 pla
    old "Y- yeah, yeah, that's what happened..."
    new "Y- ja, ja, das ist passiert..."

    # say L1101 jad
    old "I'm sorry it's my fault, I didn't know you were already here. You just startled me, that's all."
    new "Es tut mir leid, das ist meine Schuld, ich wusste nicht, dass du schon hier bist. Du hast mich einfach nur überrascht, das ist alles."

    # say L1108 pla
    old "I- I think I should leave now."
    new "I- Ich glaube, ich sollte jetzt gehen."

    # say L1110 jad
    old "Yeah, you probably should."
    new "Ja, du solltest wahrscheinlich gehen."

    # say L1111 pla
    old "R- Right... See you later Mrs. Jade."
    new "R- Richtig... Bis später, Mrs. Jade."

    # say L1133 jad
    old "The gaul off the man!!!"
    new "Der Nerv des Mannes!!!"

    # say L1134 hin
    old "I know, I know!! You don't need to keep telling me about it!"
    new "Ich weiß, ich weiß!! Du musst es mir nicht ständig unter die Nase reiben!"

    # say L1135 jad
    old "I just can't believe your father sometimes!!!"
    new "Ich kann es einfach nicht fassen, was für ein Nerv dein Vater manchmal ist!!!"

    # say L1136 jad
    old "So, this is why he never had any money and he kept coming up with excuses when it came to paying the alimony!"
    new "Dann ist das der Grund, warum er nie Geld hatte und ständig Ausreden erfand, wenn es um die Unterhaltszahlungen ging!"

    # say L1137 hin
    old "I know mom, I know, but again, I have nothing to do with it!!"
    new "Ich weiß, Mama, ich weiß, aber ich hab damit nichts zu tun!!"

    # say L1138 jad
    old "I didn't say you had to."
    new "Ich hab' das nicht gesagt."

    # say L1143 jad
    old "{b}*Sigh*{/b} I'm sorry Hinn, honey, I shouldn't be screaming like this."
    new "{b}*Seufz*{/b} Es tut mir leid, Hinn, Schatz, ich sollte nicht so schreien."

    # say L1144 jad
    old "But I just can't believe how brazen your father is!!!"
    new "Aber ich kann einfach nicht fassen, wie dreist dein Vater ist!!!"

    # say L1145 jad
    old "Not only does he take his little girlfriend on some expensive vacation."
    new "Nicht nur nimmt er seine kleine Freundin auf eine teure Reise mit."

    # say L1146 jad
    old "But he's also asking her to marry him?!!!"
    new "Aber er fragt sie auch noch heiraten?!!!"

    # say L1147 jad
    old "I mean! GOD!!"
    new "Ich meine! GOTT!!"

    # say L1148 hin
    old "Oh, [pla]! H- Hi, I didn't notice when you came in."
    new "Oh, [pla]! H- Hallo, ich habe dich gar nicht hereinkommen bemerkt."

    # say L1152 jad
    old "[pla], H- Hi honey."
    new "[pla], H- Hallo Schatz."

    # say L1153 pla
    old "H- hi Mrs. Jade, I came to work in the bathroom, is everything ok?"
    new "H- hallo Mrs. Jade, ich bin hier, um im Badezimmer zu arbeiten. Ist alles in Ordnung?"

    # say L1154 jad
    old "Well, not really."
    new "Na ja, eigentlich nicht wirklich."

    # say L1155 jad
    old "I- I think I need to let my head cool down a bit. I'll just leave you two alone so you can talk."
    new "Ich denke, ich muss meinen Kopf ein bisschen abkühlen. Ich lass euch zwei allein, damit ihr reden könnt."

    # say L1165 hin
    old "Sorry you had to see that."
    new "Tut mir leid, dass du das sehen musstest."

    # say L1167 pla
    old "It's ok. So, I take it your father has been giving you some trouble?"
    new "Ist schon gut. Also, ich nehme an, dein Vater macht dir Schwierigkeiten?"

    # say L1168 hin
    old "Hmph, you can say that twice."
    new "Hmpf, das kannst du laut sagen."

    # say L1169 hin
    old "Listen [pla], we're very thankful that you're taking the time to come work on the bathroom repairs."
    new "Hör zu [pla], wir sind sehr dankbar, dass du Zeit findest, um die Badezimmerreparaturen durchzuführen."

    # say L1170 hin
    old "But I don't think today's a good day. With my father acting like an idiot my mom's not in a very good mood."
    new "Aber ich glaube, heute ist kein guter Tag. Mit meinem Vater, der sich wie ein Idiot benimmt, ist meine Mutter nicht gerade in bester Stimmung."

    # say L1171 hin
    old "And I don't feel good either. Do you think you could come another time?"
    new "Und ich fühle mich auch nicht gut. Meinst du, du könntest ein anderes Mal kommen?"

    # say L1172 pla
    old "Of course, of course. Hey, don't worry about it, this is completely understandable."
    new "Natürlich, natürlich. Hey, mach dir keinen Stress, das ist total verständlich."

    # say L1173 pla
    old "It's fine. I'll just leave, so, the two of you can rest, and I'll come back some other day."
    new "Ist gut. Ich geh dann mal, damit ihr beiden euch ausruhen könnt. Ich komm ein anderes Mal wieder."

    # say L1174 hin
    old "Thank you, I'm glad you understand."
    new "Danke, ich bin froh, dass du das verstehst."

    # say L1176 pla
    old "Alright, then see you later."
    new "Okay, dann bis später."

    # say L1177 hin
    old "See you [pla], thank you again."
    new "Bis später [pla], danke nochmal."

    # say L1195 pla
    old "Oh! dammit, the pipe got broken again, and now my pants are all wet."
    new "Oh! verdammt, die Leitung ist wieder kaputt, und jetzt sind meine Hose total nass."

    # say L1203 jad
    old "[pla]! Is everything ok?! I heard a loud noise."
    new "[pla]! Geht es dir gut?! Ich hab einen lauten Knall gehört."

    # say L1205 pla
    old "Yeah, yeah, don't worry. Is just that one of the pipes broke and I got spilled with water. But I'm ok."
    new "Ja, ja, mach dir keine Sorgen. Einer der Rohre ist kaputt gegangen und ich bin nass geworden. Aber mir geht’s gut."

    # say L1206 jad
    old "Oh, ok, that's somewhat of a relief."
    new "Oh, okay, das ist irgendwie eine Erleichterung."

    # say L1207 jad
    old "Come with me, let's go to the other bathroom, so, you can towel dry."
    new "Komm mit, lass uns ins andere Bad gehen, damit du dich abtrocknen kannst."

    # say L1208 pla
    old "Oh, don't worry, I'm fine really."
    new "Oh, mach dir keine Sorgen, mir geht's wirklich gut."

    # say L1209 jad
    old "Don't be silly, you don't want to catch a cold. Come with me."
    new "Komm schon, du willst doch nicht erkälten. Komm mit mir."

    # say L1222 jad
    old "Okay, let me give you a hand with that."
    new "Okay, lass mich dir dabei helfen."

    # say L1240 pla
    old "Uhh, I- I'm sorry Mrs. Jade, I don't know what to say. It's just that..."
    new "Uhh, ich- ich bin Ihnen sehr dankbar, Mrs. Jade, ich weiß nur nicht, was ich sagen soll. Es ist einfach..."

    # say L1241 jad
    old "It's ok, it's ok, don't worry. You're a young man, after all."
    new "Es ist okay, es ist okay, mach dir keine Sorgen. Du bist schließlich ein junger Mann."

    # say L1243 jad
    old "I- I'll take it as a compliment."
    new "Ich- Ich nehme es als Kompliment."

    # say L1245 pla
    old "S- sure, t- thank you."
    new "S-sicher, d-danke."

    # say L1246 jad
    old "Now, why don't you take those pants off? So, I'll throw them in the dryer."
    new "Jetzt, warum ziehst du die Hose aus? Dann werfe ich sie in den Trockner."

    # say L1248 pla
    old "Uhh... Alright."
    new "Uhh... Okay."

    # say L1254 jad
    old "(What?! He's not wearing anything!!)"
    new "Was?! Er trägt gar nichts!"

    # say L1255 jad
    old "(Does he just go outside without underwear on?)"
    new "(Uht, geht er etwa ohne Unterwäsche raus?)"

    # say L1256 jad
    old "(But I must say, it's so... big! Is that what my daughters been putting in her?)"
    new "Aber ich muss sagen, es ist so... groß! Ist das, was meine Tochter da reingesteckt hat?"

    # say L1257 pla
    old "Uhh... Mrs. Jade?"
    new "Uhh... Frau Jade?"

    # say L1262 jad
    old "What? Oh, right!"
    new "Was? Ach ja!"

    # say L1263 jad
    old "Just wait here, I'm going to put this on the dryer and see if there's a pajama bottom or something that you can use."
    new "Warte hier, ich lege das in den Trockner und schaue, ob ich eine Pyjamahose oder so was für dich finde."

    # say L1277 jad
    old "{i}OH MY GOD, HINN IS HERE!{/i}"
    new "{i}OH MEIN GOTT, HINN IST DA!{/i}"

    # say L1280 jad
    old "Uhh... H- hi honey! How did school go?"
    new "Uhh... H- hallo Schatz! Wie war die Schule?"

    # say L1281 hin
    old "Fine. Hey mom, are you going to be there much longer?"
    new "Alles gut. Hey Mama, bist du noch lange da?"

    # say L1282 hin
    old "I kinda need to use the bathroom."
    new "Ich muss irgendwie aufs Klo."

    # say L1285 jad
    old "{i}OH, NO, NO, NO... SHE CAN'T SEE US LIKE THIS...{/i}"
    new "{i}OH, NEIN, NEIN, NEIN... SIE DARF UNS SO NICHT SEHEN...{/i}"

    # say L1288 jad
    old "Uhhh! I'll be here for a while, honey."
    new "Uhhh! Ich bleibe hier noch eine Weile, Schatz."

    # say L1289 jad
    old "I- I'm taking a shower and.... Uhh, I just got in. Sorry honey."
    new "Ich... ich dusche gerade und... Uhh, ich bin gerade erst reingekommen. Tut mir leid, Schatz."

    # say L1290 hin
    old "Oh, but I only need to use the toilet, so, it should be fine."
    new "Oh, aber ich muss nur aufs Klo, das sollte also okay sein."

    # say L1295 jad
    old "{i}Shut! What are we going to do?!!{/i}"
    new "{i}Pst! Was sollen wir bloß tun?!!{/i}"

    # say L1296 jad
    old "{i}If she sees you here she'll flip her mind.{/i}"
    new "{i}Wenn sie dich hier sieht, dreht sie durch.{/i}"

    # say L1297 jad
    old "{i}And with how difficult it's been to deal with her lately.{/i}"
    new "{i}Und bei dem Stress, den sie uns in letzter Zeit macht.{/i}"

    # say L1298 jad
    old "{i}We need to hide you!{/i}"
    new "{i}Wir müssen dich verstecken!{/i}"

    # say L1299 jad
    old "{i}Especially because you're naked from the waist down!{/i}"
    new "{i}Auch weil du von der Taille abwärts nackt bist!{/i}"

    # say L1300 pla
    old "{i}I don't really know where I could hide Mrs. Jade.{/i}"
    new "{i}Ich hab echt keine Ahnung, wo ich Mrs. Jade verstecken könnte.{/i}"

    # say L1304 jad
    old "Uhh, yeah, yeah, j- just give a sec, honey."
    new "Uhh, ja, ja, g- gib mir einen Moment, Schatz."

    # say L1305 hin
    old "Ughh, come on mom, you can just keep taking your shower."
    new "Ughh, komm schon, Mama, du kannst dein Bad weiternehmen."

    # say L1306 jad
    old "J- just give me a second!"
    new "J- gib mir einfach eine Sekunde!"

    # say L1309 jad
    old "{i}Come with me! Hurry up!{/i}"
    new "{i}Komm mit mir! Beeil dich!{/i}"

    # say L1322 jad
    old "Ok, you can come in!"
    new "Ok, du kannst reinkommen!"

    # say L1330 hin
    old "Mom, didn't [pla] come today?"
    new "Mom, ist [pla] heute nicht gekommen?"

    # say L1331 jad
    old "Uhh... N- no, he didn't. I guess he must be very busy with school."
    new "Uhh... N- nein, das hat er nicht. Ich schätze, er muss sehr beschäftigt mit der Schule sein."

    # say L1332 hin
    old "Hmm, that makes sense."
    new "Hmm, das ergibt Sinn."

    # say L1333 jad
    old "He's very busy, so, we should just let him come when he can find the time."
    new "Er ist sehr beschäftigt, also sollten wir ihm einfach Zeit lassen, zu kommen, wenn er kann."

    # say L1335 jad
    old "(Wait... What is this I'm feeling... Is [pla]'s cock between my legs?)"
    new "(Warte... Was fühle ich da... Ist [pla]s Schwanz zwischen meinen Beinen?)"

    # say L1339 jad
    old "(Holy cow! It's huge!)"
    new "Heilige Scheiße! Das ist riesig!"

    # say L1340 jad
    old "(And still hard... Oh my God...)"
    new "(Und immer noch hart... Oh Gott...)"

    # say L1342 jad
    old "Uhh, w- what? With Hiashi?"
    new "Uhh, w- was? Mit Hiashi?"

    # say L1343 jad
    old "I- I haven't."
    new "I- Ich habe nicht."

    # say L1344 jad
    old "(Mmm... Damn, I feel so horny all of a sudden… I haven't been in an intimate situation like this in years...)"
    new "Mmm... Verdammt, ich fühle mich plötzlich so geil… Ich war schon seit Jahren nicht mehr in einer solchen intimen Situation."

    # say L1345 jad
    old "I- I called him but he didn't answer."
    new "Ich hab ihn angerufen, aber er hat nicht geantwortet."

    # say L1356 jad
    old "Listen, I think it's best if you leave now. Here are your pants."
    new "Hör zu, ich glaube, es ist besser, wenn du jetzt gehst. Hier sind deine Hose."

    # say L1362 jad
    old "I'm sorry, I wasn't able to dry them for you."
    new "Es tut mir leid, ich konnte sie nicht für dich trocknen."

    # say L1363 jad
    old "But Hinn might come back, and this situation is already difficult to explain."
    new "Aber Hinn könnte zurückkommen, und die Situation ist schon schwierig genug zu erklären."

    # say L1364 pla
    old "It's ok, I'll just go straight home."
    new "Ist okay, ich geh direkt nach Hause."

    # say L1365 jad
    old "Yeah, that's the best idea."
    new "Ja, das ist die beste Idee."

    # say L1366 pla
    old "Ok, see you another time Mrs. Jade. I'll come back later to keep working on the repairs"
    new "Okay, bis dann, Mrs. Jade. Ich komme später wieder, um weiterzuarbeiten."

    # say L1385 jad
    old "That's good."
    new "Das ist gut."

    # say L1386 jad
    old "Listen, I'm glad you came."
    new "Hör zu, ich bin froh, dass du gekommen bist."

    # say L1387 pla
    old "Uhh, really? Why?"
    new "Uhh, echt? Warum?"

    # say L1388 jad
    old "Well, I wanted to talk to you. About what happened last time."
    new "Na ja, ich wollte mit dir reden. Über das, was letztes Mal passiert ist."

    # say L1391 pla
    old "Uh... sure."
    new "Uh... klar."

    # say L1393 jad
    old "I'm so sorry [pla], I don't know what got into me."
    new "Es tut mir so leid [pla], ich weiß auch nicht, was über mich gekommen ist."

    # say L1394 jad
    old "It's just that I've been so stressed out about so many things."
    new "Es ist nur, dass ich wegen so vielen Dingen total gestresst bin."

    # say L1396 jad
    old "You know, dealing with my husband's behavior, and Hinn's not been easy either."
    new "Du weißt ja, mit dem Verhalten meines Mannes und Hinn ist es auch nicht einfach gewesen."

    # say L1398 jad
    old "So, I'm sorry, very, very sorry."
    new "So, es tut mir leid, sehr, sehr leid."

    # say L1399 pla
    old "I- it's ok, Mrs. Jade. Really, don't worry."
    new "I- es ist okay, Mrs. Jade. Wirklich, mach dir keine Sorgen."

    # say L1400 pla
    old "I understand, it was an accident. It's fine."
    new "Ich verstehe, es war ein Unfall. Ist schon gut."

    # say L1402 pla
    old "Yes, I know that you and Hinn are going through a lot lately."
    new "Ja, ich weiß, dass du und Hinn momentan viel durchmachst."

    # say L1403 pla
    old "Uhh, and yesterday, it was mostly a misunderstanding that escalated quickly."
    new "Uhh, und gestern war esmostly hauptsächlich ein Missverständnis, das sich schnell verschärft hat."

    # say L1404 jad
    old "Oh, thank you [pla]! Thanks for understanding, you're such a good young man."
    new "Oh, danke [pla]! Danke für dein Verständnis, du bist so ein guter junger Mann."

    # say L1405 pla
    old "Thanks for saying that Mrs. Jade."
    new "Danke, dass du das gesagt hast, Mrs. Jade."

    # say L1407 pla
    old "So, I'll just go to work in the bathroom. I think it shouldn't be long before I finish."
    new "Dann geh ich mal ins Bad arbeiten. Ich denke, es dauert nicht mehr lange."

    # say L1408 jad
    old "Sure, sure, also, thanks a lot for doing that."
    new "Klar, klar, danke auch vielmals dafür."

    # say L1409 pla
    old "It's not a problem."
    new "Das ist kein Problem."

    # say L1423 pla
    old "Hi! Hello? Hinn? Mrs. Jade?"
    new "Hallo? Hinn? Frau Jade?"

    # say L1424 pla
    old "That's weird, they're usually here in the afternoon."
    new "Das ist seltsam, sie sind normalerweise nachmittags hier."

    # say L1425 pla
    old "Hello?!"
    new "Hallo?!"

    # say L1433 pla
    old "Hinn? Mrs. Jade? Anyone here?"
    new "Hinn? Mrs. Jade? Ist hier jemand?"

    # say L1434 pla
    old "This is odd."
    new "Das ist seltsam."

    # say L1435 pla
    old "I guess they went out."
    new "Ich schätze, sie sind ausgegangen."

    # say L1436 pla
    old "I suppose there's no problem if I go up and work on the bathroom."
    new "Ich denke, es ist okay, wenn ich nach oben gehe und im Badezimmer arbeite."

    # say L1459 jad
    old "Oh my God! [pla]! W- what are you doing there?!"
    new "Oh mein Gott! [pla]! W- was machst du da?!"

    # say L1460 pla
    old "S- sorry! I didn't see anything, I was looking for you and I just opened the door."
    new "S- sorry! Ich hab nichts gesehen, ich suchte dich und hab einfach die Tür aufgemacht."

    # say L1461 pla
    old "I was going to work in the bathroom, but, I think I should just leave."
    new "Ich wollte im Bad arbeiten, aber, ich glaube, ich sollte einfach gehen."

    # say L1469 jad
    old "Uhh, this is my fault, I'd forgotten you were coming today."
    new "Uhh, das ist meine Schuld, ich hatte vergessen, dass du heute kommst."

    # say L1470 jad
    old "So, I'll just dress up and you can get to work on the repairs."
    new "Dann ziehe ich mich schnell an und du kannst mit den Reparaturen beginnen."

    # say L1471 jad
    old "Can we just pretend this never happened?"
    new "Können wir einfach so tun, als wäre nichts passiert?"

    # say L1472 pla
    old "Uhhh, sure."
    new "Uhhh, klar."

    # say L1480 jad
    old "(My God, he has another boner, and it's so big.)"
    new "Mein Gott, er hat schon wieder einen Ständer, und der ist riesig."

    # say L1481 pla
    old "I- I think I'll start working on the bathroom, then."
    new "I- Ich denke, ich fange dann mal im Badezimmer an."

    # say L1482 jad
    old "R- right, right. Well, you know where everything is."
    new "R- richtig, richtig. Also, du weißt ja, wo alles ist."

    # say L1492 pla
    old "Wow, that was crazy..."
    new "Wow, das war verrückt..."

    # say L1493 pla
    old "Thank God, she is very calm and reasonable."
    new "Gott sei Dank, sie ist sehr ruhig und vernünftig."

    # say L1494 pla
    old "Anyway, I better finish this as soon as possible."
    new "Jedenfalls, ich sollte das so schnell wie möglich zu Ende bringen."

    # say L1507 pla
    old "Oh, hi Mrs. Jade, yeah, I'm done for today."
    new "Oh, hallo Mrs. Jade, ja, ich bin für heute fertig."

    # say L1508 pla
    old "It's almost done, I don't think it will be too long until I'm finished with the repairs."
    new "Es ist fast fertig, ich denke, es wird nicht mehr lange dauern, bis ich mit den Reparaturen durch bin."

    # say L1509 jad
    old "That's great honey, thank you."
    new "Das ist toll, Schatz, danke."

    # say L1510 jad
    old "And listen, about what you saw me doing today."
    new "Und hör zu, was du heute gesehen hast."

    # say L1511 jad
    old "I'm sorry, I wouldn't have wanted you to see that. It must've been very awkward."
    new "Es tut mir leid, ich hätte nicht gewollt, dass du das siehst. Es muss sehr peinlich für dich gewesen sein."

    # say L1513 pla
    old "No, no, I'm the one who should be apologizing, this is your house after all."
    new "Nein, nein, ich bin derjenige, der sich entschuldigen sollte, das ist schließlich dein Haus."

    # say L1514 pla
    old "I shouldn't have come into your bedroom without knocking."
    new "Ich hätte nicht in dein Schlafzimmer kommen sollen, ohne anzuklopfen."

    # say L1515 jad
    old "Well, anyway, I'm sorry you had to see that."
    new "Na ja, tut mir leid, dass du das sehen musstest."

    # say L1516 jad
    old "I'm sure it must not be enjoyable to see an older woman in those... Circumstances."
    new "Ich bin sicher, das war nicht angenehm für dich, eine ältere Frau in so einer Situation zu sehen."

    # say L1518 pla
    old "Ohh, of course not, you're a very beautiful woman."
    new "Ohh, natürlich nicht, du bist eine sehr schöne Frau."

    # say L1520 pla
    old "I- I mean...!"
    new "Ich- Ich meine...!"

    # say L1521 jad
    old "I get it, I get it, thank you [pla]."
    new "Ich hab's kapiert, ich hab's kapiert, danke [pla]."

    # say L1523 pla
    old "Oh, ok."
    new "Oh, okay."

    # say L1524 pla
    old "Well, I think I should get going."
    new "Na ja, ich glaube, ich sollte jetzt gehen."

    # say L1525 jad
    old "Yeah, it's getting a little late."
    new "Ja, es wird langsam spät."

    # say L1526 pla
    old "Have a good night Mrs. Jade."
    new "Gute Nacht, Mrs. Jade."

    # say L1527 jad
    old "You too darling."
    new "Gute Nacht, mein Lieber."

    # say L1546 pla
    old "Oh, hi Mrs. Jade, Mrs. White."
    new "Oh, hallo Mrs. Jade, Mrs. White."

    # say L1551 whi
    old "Well hello there [pla]. Tell me jade? What is this fine young man doing here?"
    new "Na hallo [pla]. Erzählen Sie mir, Jade? Was macht dieser nette junge Mann hier?"

    # say L1552 jad
    old "Well, do you remember I told you there was some damage in my bathroom?"
    new "Na, erinnern Sie sich noch, dass ich Ihnen von den Schäden in meinem Badezimmer erzählt habe?"

    # say L1554 jad
    old "Well, I'll have you know that [pla] here was kind enough to volunteer to help me do the repairs."
    new "Na, du wirst es nicht glauben, aber [pla] hier hat sich freundlicherweise bereit erklärt, mir bei den Reparaturen zu helfen."

    # say L1556 jad
    old "He did. You know that with everything that's been going on with Hiashi things have been a little tight around here."
    new "Er hat. Du weißt ja, mit allem, was bei Hiashi los ist, ist es hier ein bisschen knapp geworden."

    # say L1557 whi
    old "Uhmm."
    new "Hmm."

    # say L1558 jad
    old "Well, I couldn't really afford for a plumber to do it, but [pla] has been  perfect."
    new "Na ja, ich konnte mir keinen Klempner leisten, aber [pla] war perfekt."

    # say L1559 jad
    old "He's such a fine young man."
    new "Er ist so ein feiner junger Mann."

    # say L1561 whi
    old "Oh, you don't have to tell me too much about it."
    new "Oh, Sie müssen mir da gar nichts erzählen."

    # say L1563 whi
    old "I know full well what a helpful capable young man [pla] is. He actually helped me with something in the past."
    new "Ich weiß sehr gut, was für ein hilfsbereiter und fähiger junger Mann [pla] ist. Er hat mir in der Vergangenheit schon geholfen."

    # say L1564 pla
    old "Uh... I think I'll go work in the bathroom for now."
    new "Äh... Ich denke, ich gehe jetzt ins Bad und arbeite dort."

    # say L1565 jad
    old "Sure honey, you know where everything is."
    new "Natürlich, Schatz, du weißt ja, wo alles ist."

    # say L1566 pla
    old "With your permission, see you later, Mrs. White and Mrs Jade."
    new "Mit Ihrer Erlaubnis, bis später, Mrs. White und Mrs. Jade."

    # say L1576 whi
    old "So, tell me, what came of that whole business with Hiashi? Did you get him to pay your alimony?"
    new "So, erzählen Sie mir, was aus der ganzen Sache mit Hiashi geworden ist? Hat er Ihnen das Unterhalts Geld gezahlt?"

    # say L1577 jad
    old "Ha! Not only he didn't pay, but he also took that little bimbo he calls his girlfriend on vacation."
    new "Ha! Nicht nur, dass er nicht gezahlt hat, er hat auch dieses kleine Flittchen, das er seine Freundin nennt, mit auf Urlaub genommen."

    # say L1578 whi
    old "No way!"
    new "Keine Chance!"

    # say L1579 whi
    old "You're joking."
    new "Du machst Witze."

    # say L1581 jad
    old "I wish, but that's not all of it. Apparently, while they were there."
    new "Ich wünschte, aber das ist noch nicht alles. Offenbar, während sie dort waren."

    # say L1582 jad
    old "He asked her to marry him!"
    new "Er hat sie gebeten, ihn zu heiraten!"

    # say L1583 whi
    old "Oh my God! I can't believe it!"
    new "Oh mein Gott! Das kann ich kaum glauben!"

    # say L1584 whi
    old "I remember he was a pig, but I didn't know just how low he could sink."
    new "Ich erinnere mich, dass er ein Schwein war, aber ich wusste nicht, wie tief er sinken konnte."

    # say L1585 jad
    old "Ugh, Tell me about it!"
    new "Ugh, Das kannst du laut sagen!"

    # say L1586 jad
    old "After he posted the photos with the engagement ring, he realized that they were public, so, he took them down."
    new "Nachdem er die Fotos mit dem Verlobungsring gepostet hatte, merkte er, dass sie öffentlich waren, also hat er sie wieder runtergenommen."

    # say L1587 jad
    old "But by that point, it was already too late. We had already seen them."
    new "Aber da war es schon zu spät. Wir hatten sie schon gesehen."

    # say L1588 whi
    old "I just can't believe how irresponsible that man is."
    new "Ich kann einfach nicht fassen, wie verantwortungslos dieser Mann ist."

    # say L1589 jad
    old "{b}*Sigh*{/b} In a way, I can't either, I mean, ever since we broke up I never had any hopes that he would be exemplary."
    new "{b}*Seufz*{/b} Einerseits kann ich das auch nicht, ich meine, seit wir Schluss gemacht haben, habe ich nie erwartet, dass er ein Vorbild sein würde."

    # say L1590 jad
    old "But I didn't want to believe he would stand this low. It's always the same disappointing story when it comes to him."
    new "Aber ich wollte nicht glauben, dass er so tief sinken würde. Es ist immer die gleiche enttäuschende Geschichte, wenn es um ihn geht."

    # say L1591 jad
    old "And that's not all, I've been having terrible migraines, and insomnia because of it."
    new "Und das ist noch nicht alles, ich habe furchtbare Migräne und Schlafstörungen deswegen."

    # say L1592 jad
    old "Not to mention that Hinn's been a real handful as of late. I swear to God, I don't even know how to talk to her anymore."
    new "Und ganz zu schweigen davon, dass Hinn lately eine echte Nervensäge ist. Ehrlich, ich hab echt keine Ahnung mehr, wie ich mit ihr reden soll."

    # say L1593 jad
    old "The whole thing has culminated in me being in constant panic and with my emotions all over the place!"
    new "Das Ganze mündet darin, dass ich ständig in Panik bin und meine Emotionen total durcheinander sind!"

    # say L1594 jad
    old "I've been thinking that maybe I should go to a psychiatrist. Maybe I have some sort of anxiety, you know?"
    new "Ich hab drüber nachgedacht, vielleicht sollte ich zu einem Psychiater gehen. Vielleicht hab ich ja so eine Art Angstzustand, weißt du?"

    # say L1595 whi
    old "Well... I guess you could call it that..."
    new "Na ja... man könnte es so nennen..."

    # say L1596 jad
    old "Well, duh, that's the name of it. What else could it be?"
    new "Na klar, das ist der Name dafür. Was sollte es sonst sein?"

    # say L1597 whi
    old "For one thing, a lack of sex."
    new "Einen Mangel an Sex."

    # say L1599 jad
    old "A what?!"
    new "Was?!"

    # say L1600 whi
    old "You heard me, it sounds to me that what you have is a typical case of not fucking."
    new "Du hast mich gehört, mir klingt es so, als hättest du einen typischen Fall von Nicht-Ficken."

    # say L1602 whi
    old "Hey, I've been there myself, so, I know the symptoms."
    new "Hey, ich war selbst schon mal da, also kenne ich die Symptome."

    # say L1603 whi
    old "You've been under a lot of stress lately, all of that accumulates in your body."
    new "Du bist lately unter viel Stress gestanden, das sammelt sich in deinem Körper."

    # say L1604 whi
    old "And since you're not sexually active with anybody you just get anxious."
    new "Und da du momentan mit niemandem sexuell aktiv bist, wirst du einfach nur nervös."

    # say L1606 jad
    old "Oh, come on! Be serious please..."
    new "Oh, komm schon! Sei bitte ernst..."

    # say L1608 whi
    old "I am!"
    new "Ich bin ernst!"

    # say L1609 whi
    old "Listen, you're not having sex, but you still need to do it."
    new "Hör zu, du hast zwar keinen Sex, aber du musst es trotzdem tun."

    # say L1610 whi
    old "Add to that all of the other problems that you have to deal with."
    new "Dazu kommen all die anderen Probleme, mit denen Sie sich auseinandersetzen müssen."

    # say L1611 whi
    old "And you're a ticking time bomb!"
    new "Und Sie sind eine tickende Zeitbombe!"

    # say L1612 whi
    old "You're repressed Jade, and believe me, that's not good for you."
    new "Du bist unterdrückt, Jade, und glaub mir, das ist nicht gut für dich."

    # say L1613 whi
    old "It's clear to me that what you need is a good fucking. That'll help you."
    new "Es ist mir klar, dass du eine gute Nummer gebrauchen könntest. Das würde dir helfen."

    # say L1614 jad
    old "Hahaha, yeah right. Who am I going to do it with?"
    new "Hahaha, klar. Und mit wem soll ich das machen?"

    # say L1615 jad
    old "I'm an old divorced woman."
    new "Ich bin eine alte geschiedene Frau."

    # say L1616 jad
    old "Who's going to want to be with me?"
    new "Wer will schon mit mir zusammen sein?"

    # say L1617 whi
    old "Oh! You know you're pretty. Any man would give an arm and a leg to have a chance to jump into your bed."
    new "Oh! Du weißt, dass du hübsch bist. Jeder Mann würde ein Bein dafür geben, in dein Bett zu kommen."

    # say L1618 jad
    old "Yeah right."
    new "Klar, sicher."

    # say L1620 whi
    old "Listen, girl, I'm not saying it just to mess with you. You need physical intimacy, it's good for you."
    new "Hör zu, Mädchen, ich sage das nicht, um dich zu ärgern. Du brauchst körperliche Intimität, das ist gut für dich."

    # say L1621 whi
    old "If you don't do something about it you'll just start getting depressed and maybe even having anxiety attacks!"
    new "Wenn du nichts dagegen unternimmst, wirst du dich nur noch depressiver fühlen und vielleicht sogar Angstanfälle bekommen!"

    # say L1622 whi
    old "You need to release all of those things you're holding in."
    new "Du musst all diese Dinge loswerden, die du in dir drin hast."

    # say L1624 jad
    old "Hmm, maybe you're right..."
    new "Hmm, vielleicht haben Sie recht..."

    # say L1626 jad
    old "But even so? Who would I even be intimate with?"
    new "Aber selbst dann? Mit wem würde ich überhaupt intim werden?"

    # say L1640 pla
    old "Ok Mrs. Jade, I've  finished for today."
    new "Ok Mrs. Jade, ich bin für heute fertig."

    # say L1642 jad
    old "Thank you, honey, you were done very quickly!"
    new "Danke, Schatz, du warst wirklich schnell fertig!"

    # say L1643 pla
    old "Yeah, I would've liked to do some more, but sadly I'm busy with some school work, so, I'm gonna have to go for today."
    new "Ja, ich hätte gerne noch mehr gemacht, aber leider habe ich noch Schulaufgaben zu erledigen. Also muss ich heute Schluss machen."

    # say L1644 jad
    old "That's ok honey, see you another time."
    new "Das ist in Ordnung, Schatz, bis zum nächsten Mal."

    # say L1645 whi
    old "By the way [pla], you should come to my house one of these days."
    new "Übrigens [pla], Sie sollten mal zu mir nach Hause kommen."

    # say L1646 whi
    old "I can think of one or two things you could help me fix."
    new "Ich kann mir ein oder zwei Dinge vorstellen, bei denen Sie mir helfen könnten."

    # say L1647 pla
    old "Yeah, haha... Maybe I'll go later."
    new "Ja, haha... Vielleicht komme ich später vorbei."

    # say L1648 pla
    old "Well, hope to see you soon. Bye."
    new "Na ja, hoffe, dich bald zu sehen. Tschüss."

    # say L1650 jad
    old "Bye honey."
    new "Tschüss Schatz."

    # say L1652 whi
    old "See you later sweetie."
    new "Bis später, Liebes."

    # say L1661 jad
    old "So, what were we talking about?"
    new "Also, worüber haben wir gesprochen?"

    # say L1662 whi
    old "We were saying that you need to fuck!"
    new "Wir haben gesagt, dass du ficken musst!"

    # say L1663 jad
    old "Ah, right, that..."
    new "Ah, richtig, das..."

    # say L1664 jad
    old "But you know, it's not as if I'm not doing anything, I masturbate often, and I feel like that's good."
    new "Aber du weißt, es ist nicht so, als würde ich nichts tun, ich masturbiere oft und ich denke, das ist gut."

    # say L1665 whi
    old "That won't be enough. Believe me, I have some experience with this."
    new "Das wird nicht reichen. Glaub mir, ich habe da so meine Erfahrungen."

    # say L1666 whi
    old "What you need is a big, hard cock to ravage you."
    new "Was du brauchst, ist ein großer, harter Schwanz, der dich fickt."

    # say L1668 jad
    old "So classy..."
    new "So elegant..."

    # say L1670 jad
    old "But then again, who's it going to be? I don't know anybody, and I'm too busy, and frankly tired, to go out looking for dates."
    new "Aber dann, wer soll es denn sein? Ich kenne niemanden und bin zu beschäftigt und ehrlich gesagt auch zu müde, um nach Dates zu suchen."

    # say L1672 whi
    old "Also, not just anybody can do it. It has to be someone that can rock you."
    new "Also, nicht jeder kann das. Es muss jemand sein, der dich richtig in Schwung bringen kann."

    # say L1676 whi
    old "Well, I'll tell you what, I think I know just the right guy to do it!"
    new "Na ja, ich werde dir sagen, ich glaube, ich kenne genau den Richtigen dafür!"

    # say L1677 jad
    old "You do? Do we have any common friends that I don't know about?"
    new "Du kennst ihn? Haben wir gemeinsame Freunde, von denen ich nichts weiß?"

    # say L1680 whi
    old "Listen, what you don't need is some old guy who's just going to get tired after a couple of pumps."
    new "Hör zu, was du nicht brauchst, ist so ein alter Mann, der nach ein paar Stößen schon müde wird."

    # say L1681 whi
    old "You need a young, healthy stallion that's going to pump you full, and it's going to make you scream with his big dick."
    new "Du brauchst einen jungen, gesunden Hengst, der dich vollpumpt und der dich mit seinem großen Schwanz zum Schreien bringt."

    # say L1682 jad
    old "Hahaha, what are you saying?"
    new "Hahaha, was redest du da?"

    # say L1683 jad
    old "Ok, let's say that's what I need. Where am I going to find this young stallion that's going to do that to me?"
    new "Okay, lass uns sagen, das ist, was ich brauche. Wo soll ich diesen jungen Hengst finden, der so was mit mir macht?"

    # say L1684 whi
    old "Baby, you've already met him!"
    new "Baby, du hast ihn schon getroffen!"

    # say L1686 jad
    old "I have?"
    new "Ich habe?"

    # say L1687 whi
    old "Well of course! He's always here at your house!"
    new "Natürlich! Er ist doch immer hier bei dir zu Hause!"

    # say L1689 jad
    old "What? You mean [pla]?!! What are you talking about?!"
    new "Was? Du meinst [pla]?! Wovon redest du überhaupt?!"

    # say L1690 whi
    old "What? What's so odd about that?"
    new "Was? Was ist daran so seltsam?"

    # say L1691 whi
    old "He's young, he's healthy, he's a very good kid."
    new "Er ist jung, er ist gesund, er ist ein sehr guter Junge."

    # say L1692 whi
    old "And he has some experience."
    new "Und er hat schon etwas Erfahrung."

    # say L1693 whi
    old "He's just what you need!"
    new "Er ist genau das, was du brauchst!"

    # say L1694 jad
    old "Yeah right! As if!"
    new "Na klar! Als ob!"

    # say L1696 whi
    old "Oh my God! Why not?!"
    new "Oh mein Gott! Warum nicht?!"

    # say L1697 jad
    old "Well, for one thing, he's actually having sex with my daughter!"
    new "Na ja, zum einen fickt er tatsächlich mit meiner Tochter!"

    # say L1698 whi
    old "So, are they officially dating?"
    new "Also, sind sie jetzt offiziell zusammen?"

    # say L1699 jad
    old "Well, it's complicated, it's one of those new things the kids are doing these days."
    new "Na ja, es ist kompliziert, so eine von diesen neuen Sachen, die die Kids heute machen."

    # say L1700 jad
    old "You know, having sex without an official relationship... I honestly don't understand."
    new "Du weißt schon, Sex ohne offizielle Beziehung... Ich verstehe das ehrlich gesagt nicht."

    # say L1701 whi
    old "Then there's no problem!"
    new "Dann gibt es kein Problem!"

    # say L1702 whi
    old "Of course you couldn't tell Hinn, but that's not too much of a big deal."
    new "Natürlich konntest du es Hinn nicht sagen, aber das ist nicht so schlimm."

    # say L1703 jad
    old "That's not all of it!"
    new "Das ist noch nicht alles!"

    # say L1704 whi
    old "It isn't? What else then?"
    new "Ist es nicht? Was denn noch?"

    # say L1705 jad
    old "He's too young..."
    new "Er ist zu jung..."

    # say L1706 jad
    old "He could be my son!"
    new "Er könnte mein Sohn sein!"

    # say L1707 whi
    old "Oh please! So what? Why do you think Hiashi is dating that nineteen-year-old hussy?"
    new "Oh bitte! Was soll's? Warum denkst du, dass Hiashi mit dieser neunzehnjährigen Schlampe geht?"

    # say L1709 whi
    old "It's because the sex it's really, really good, and she helps him feel good."
    new "Weil der Sex wirklich, wirklich gut ist und sie ihm dabei hilft, sich gut zu fühlen."

    # say L1710 whi
    old "Also, you can use this as a chance to get back at that pig of your ex-husband's for what he's doing."
    new "Also, du kannst das als Chance nutzen, um dich an diesem Schwein von deinem Ex-Mann für das zu rächen, was er macht."

    # say L1711 jad
    old "Hmm, I don't know... That would be really inappropriate."
    new "Hmm, ich weiß nicht... Das wäre wirklich unangemessen."

    # say L1712 whi
    old "Oh! Stop acting as if I'm saying something crazy."
    new "Oh! Hör auf, so zu tun, als ob ich etwas Verrücktes sage."

    # say L1713 jad
    old "Aren't you?"
    new "Nein, tue ich nicht."

    # say L1714 whi
    old "Please! With all of the time that he's been in here."
    new "Bitte! Mit all der Zeit, die er hier verbracht hat."

    # say L1716 whi
    old "Can you honestly tell me that you've never thought about having your way with him?"
    new "Kannst du mir ehrlich sagen, dass du noch nie daran gedacht hast, es mit ihm zu treiben?"

    # say L1717 whi
    old "Or him having his way with you. Whichever way you prefer."
    new "Oder dass er es mit dir treibt. Egal, wie du es magst."

    # say L1720 whi
    old "Wait! Wait a minute!"
    new "Warte! Warte mal!"

    # say L1721 whi
    old "Don't tell me you already did something with him!"
    new "Sag mir jetzt nicht, dass du schon was mit ihm hattest!"

    # say L1722 jad
    old "No, no, no, no!"
    new "Nein, nein, nein, nein!"

    # say L1723 jad
    old "Nothing like what you're thinking."
    new "Nichts, was du denkst."

    # say L1725 whi
    old "But you did do something didn't you?"
    new "Aber du hast doch etwas gemacht, oder?"

    # say L1726 jad
    old "You're unbelievable."
    new "Du bist unglaublich."

    # say L1727 jad
    old "Ok, the other day as he was doing something in the bathroom one of the pipes broke, and his pants got wet."
    new "Ok, neulich, als er im Bad etwas gemacht hat, ist eine der Leitungen geplatzt und seine Hose ist nass geworden."

    # say L1731 jad
    old "So, I told him that maybe he should take them off just so that I could throw them in the dryer."
    new "Also, ich hab ihm gesagt, dass er sie vielleicht ausziehen sollte, damit ich sie in den Trockner werfen kann."

    # say L1732 whi
    old "I like where this is going."
    new "Ich mag, wohin das führt."

    # say L1734 jad
    old "Well, the thing is that... For some reason, he had a boner, and wasn't wearing drawls."
    new "Na ja, der Punkt ist, dass... aus irgendeinem Grund hatte er einen Ständer und trug keine Unterhose."

    # say L1736 whi
    old "Oh my God and you saw his boner?!"
    new "Oh mein Gott und du hast seinen Ständer gesehen?!"

    # say L1737 whi
    old "Hahaha, this is great! It was huge wasn't it?"
    new "Hahaha, das ist ja toll! Es war riesig, oder?"

    # say L1738 jad
    old "You're terrible, you know that?"
    new "Du bist echt schrecklich, das weißt du, oder?"

    # say L1739 jad
    old "... But yes, he was very big. Like, very, very big."
    new "Aber ja, er war sehr groß. Einfach sehr, sehr groß."

    # say L1740 jad
    old "But that's it, nothing else happened."
    new "Aber das war's, sonst ist nichts passiert."

    # say L1741 jad
    old "At all..."
    new "Überhaupt..."

    # say L1742 whi
    old "It doesn't matter, this is great!"
    new "Das spielt keine Rolle, das ist toll!"

    # say L1745 whi
    old "Don't you see? He got a boner because of you! He already thinks you're hot!"
    new "Siehst du das nicht? Er hat einen Ständer bekommen, weil er dich heiß findet! Er denkt schon, dass du scharf bist!"

    # say L1746 whi
    old "But that kid's too timid to do anything, he won't make a move unless he thinks you want it too."
    new "Aber der Junge ist zu schüchtern, um was zu tun, er macht keinen Zug, es sei denn, er denkt, dass du es auch willst."

    # say L1747 whi
    old "But that's not a problem, I can deal with that."
    new "Aber das ist kein Problem, damit kann ich umgehen."

    # say L1748 jad
    old "Wait! What are you going to do?!"
    new "Warte! Was hast du vor?!"

    # say L1750 whi
    old "Don't worry, I won't do anything you don't want."
    new "Mach dir keine Sorgen, ich werde nichts tun, was du nicht willst."

    # say L1751 jad
    old "Wait, don't do anything dumb."
    new "Warte, mach nichts Dummes."

    # say L1752 whi
    old "Me? I'll just take care of this for you, that's all."
    new "Ich? Ich werde mich einfach darum kümmern, das ist alles."

    # say L1753 whi
    old "And I better leave before you change your mind."
    new "Und ich sollte besser gehen, bevor Sie es sich anders überlegen."

    # say L1769 jad
    old "Oh my God, what did I get myself into?"
    new "Oh mein Gott, in was für eine Situation habe ich mich da reingeritten?"

    # say L1791 mo1
    old "Sweetie, Mrs. White's outside, she says she has something to talk to you about."
    new "Schätzchen, Mrs. White ist draußen, sie sagt, sie muss mit dir sprechen."

    # say L1792 pla
    old "She wants to talk to me?"
    new "Sie will mit mir reden?"

    # say L1793 mo1
    old "Yes, she says it's something about your friend Mike."
    new "Ja, sie sagt, es geht um deinen Freund Mike."

    # say L1794 pla
    old "I see, well, I'll be right out."
    new "Ich sehe, dann komme ich gleich raus."

    # say L1795 mo1
    old "Ok, honey."
    new "Ok, Schatz."

    # say L1805 pla
    old "Hi Mrs. White, is everything alright with Mike?"
    new "Hallo Mrs. White, ist alles in Ordnung mit Mike?"

    # say L1806 whi
    old "Hi honey, yeah, yeah, don't worry. It's just that I need you to come with me to my house for a second."
    new "Hi Liebling, ja, ja, mach dir keine Sorgen. Ich brauche dich nur kurz bei mir zu Hause."

    # say L1807 whi
    old "There's something I want you to talk about with Mike."
    new "Es gibt etwas, worüber ich mit Mike sprechen möchte."

    # say L1808 pla
    old "Me? Is it something serious?"
    new "Ich? Ist es was Ernstes?"

    # say L1809 whi
    old "Not really, but it's more of a guy thing, so, I think it would be better if he hears it from another man."
    new "Nicht wirklich, aber es ist eher eine Männerangelegenheit, deshalb denke ich, es wäre besser, wenn er es von einem anderen Mann hört."

    # say L1810 pla
    old "Oh, ok, I guess that's fine. Sure, I'll come with you."
    new "Oh, okay, das ist in Ordnung. Klar, ich komme mit dir."

    # say L1817 pla
    old "So, it's Mike in his bedroom?"
    new "Dann ist es Mike in seinem Schlafzimmer?"

    # say L1818 whi
    old "No, actually, I must admit I lied to you, he's not in the house, and he won't be for a while."
    new "Nein, eigentlich muss ich zugeben, dass ich Ihnen etwas vorgemacht habe. Er ist nicht im Haus und wird auch eine Weile nicht hier sein."

    # say L1819 pla
    old "Then how am I supposed to talk to him?"
    new "Dann wie soll ich ihm denn überhaupt noch was sagen?"

    # say L1820 whi
    old "Well, to be honest with you [pla], I don't actually want you to talk to Mike."
    new "Nun, ehrlich gesagt [pla], ich möchte eigentlich nicht, dass Sie mit Mike sprechen."

    # say L1821 pla
    old "You don't?"
    new "Du nicht?"

    # say L1822 whi
    old "No, the person I want you to help is a friend of mine, who needs something from you."
    new "Nein, die Person, der ich helfen möchte, ist eine Freundin von mir, die etwas von Ihnen braucht."

    # say L1823 pla
    old "Who is it?"
    new "Wer ist es?"

    # say L1824 whi
    old "Well honey, it's Jade, there's something that she needs from you."
    new "Nun, Schatz, es ist Jade, sie braucht etwas von dir."

    # say L1825 pla
    old "Did anything happen to her?"
    new "Ist ihr was passiert?"

    # say L1827 whi
    old "Not yet."
    new "Noch nicht."

    # say L1828 pla
    old "I have to tell you, Mrs. White, you're not really making a lot of sense here, you know?"
    new "Ich muss Ihnen sagen, Mrs. White, Sie machen hier wirklich nicht viel Sinn, wissen Sie?"

    # say L1829 whi
    old "That's because I haven't really told you anything."
    new "Das ist, weil ich Ihnen noch gar nichts gesagt habe."

    # say L1830 whi
    old "Listen [pla], the thing I want you to do, is to have sex with Jade."
    new "Hören Sie [pla], das, was ich von Ihnen verlange, ist, dass Sie mit Jade schlafen."

    # say L1831 pla
    old "What?!"
    new "Was?!"

    # say L1832 whi
    old "Just as you hear it, you are going to help Jade by fucking her."
    new "Genau so, wie du es hörst, wirst du Jade helfen, indem du sie fickst."

    # say L1833 pla
    old "Why would I do that?"
    new "Warum sollte ich das tun?"

    # say L1835 whi
    old "Well, there's a lot to explain, but basically, Jade's been under a lot of pressure."
    new "Nun, es gibt viel zu erklären, aber im Grunde steht Jade unter enormem Druck."

    # say L1836 whi
    old "She wouldn't admit it, but she's repressed. So, she really needs to release that, you know what I mean?"
    new "Sie würde es nicht zugeben, aber sie ist unterdrückt. Also, sie muss das wirklich loswerden, Sie wissen schon, was ich meine?"

    # say L1837 whi
    old "And since I know how gifted you are in that regard, I thought that you're the right person to help her."
    new "Und da ich weiß, wie begabt Sie in dieser Hinsicht sind, dachte ich, Sie wären die richtige Person, um ihr zu helfen."

    # say L1838 pla
    old "This is crazy Mrs. White, I mean, how do we even know that Mrs. Jade would want to do anything with me?"
    new "Das ist verrückt, Mrs. White, ich meine, wie sollen wir überhaupt wissen, dass Mrs. Jade irgendetwas mit mir machen will?"

    # say L1839 whi
    old "Oh, don't you play dumb with me!"
    new "Oh, machen Sie sich jetzt nicht dumm!"

    # say L1840 whi
    old "I already know you two have done a couple of things already."
    new "Ich weiß schon, dass Sie und sie schon ein paar Dinge miteinander gemacht haben."

    # say L1842 whi
    old "So, listen carefully, this is what's going to happen..."
    new "Also, hör gut zu, das ist jetzt so ablaufen..."

    # say L1853 jad
    old "Hey, where have you been?"
    new "Hey, wo warst du?"

    # say L1854 whi
    old "I was just having a little word with [pla], you know, getting him onboard and what not."
    new "Ich war gerade dabei, ein Wörtchen mit [pla] zu reden, weißt du, ihn einzubinden und so."

    # say L1855 jad
    old "Oh my God! Did you actually bring him here?"
    new "Oh mein Gott! Hast du ihn wirklich hierhergebracht?"

    # say L1856 jad
    old "I can't believe I let you talk me into doing something this crazy!"
    new "Ich kann nicht glauben, dass ich dich dazu überreden lassen habe, so etwas Verrücktes zu machen!"

    # say L1857 whi
    old "Well, he's already here, so, no turning back now."
    new "Nun, er ist schon hier, also gibt es kein Zurück mehr."

    # say L1859 whi
    old "Listen, I already talked to him, so, you don't need to worry about anything other than enjoying yourself."
    new "Hör zu, ich habe schon mit ihm gesprochen, also musst du dir um nichts Sorgen machen außer, dass du Spaß hast."

    # say L1860 whi
    old "I don't want you thinking about anything stressful, or about your daughter."
    new "Ich will nicht, dass Sie sich über etwas Belastendes Gedanken machen, oder über Ihre Tochter."

    # say L1861 whi
    old "I especially don't want you thinking about that asshole Hiashi!"
    new "Ich will vor allem nicht, dass Sie an diesen Arschloch Hiashi denken!"

    # say L1862 whi
    old "All you need to do is focus on your own pleasure. Ok?"
    new "Sie müssen sich nur auf Ihr eigenes Vergnügen konzentrieren. Ok?"

    # say L1865 whi
    old "Good, then I'll tell [pla] to come in."
    new "Gut, dann sage ich [pla], dass er reinkommen kann."

    # say L1867 whi
    old "Hey [pla]! You can come in now honey!"
    new "Hey [pla]! Du kannst jetzt reinkommen, Schatz!"

    # say L1874 pla
    old "H- hi Mrs. Jade..."
    new "H- hallo Frau Jade..."

    # say L1875 jad
    old "H- hi [pla]."
    new "H- hallo [pla]."

    # say L1876 whi
    old "Oh! What is this tension? You have to loosen up!"
    new "Oh! Was ist das für eine Anspannung? Sie müssen sich entspannen!"

    # say L1877 whi
    old "Well, I think this might help a little."
    new "Na, ich denke, das könnte ein bisschen helfen."

    # say L1881 whi
    old "Look at that, isn't that just an amazing dick?"
    new "Schau dir das an, ist das nicht einfach ein unglaublicher Schwanz?"

    # say L1882 whi
    old "I bet he's even bigger than you remember isn't Jade?"
    new "Ich wette, er ist sogar noch größer, als du dich erinnerst, nicht wahr, Jade?"

    # say L1883 jad
    old "W- well..."
    new "W-was soll ich dazu sagen..."

    # say L1884 whi
    old "And it's so thick, hot, and hard..."
    new "Und es ist so dick, heiß und hart..."

    # say L1894 whi
    old "Hmph, slrrrrp!"
    new "Hmpf, slrrrrp!"

    # say L1895 whi
    old "My God [pla] you really have the best tasting dick in the world."
    new "Mein Gott [pla] Sie haben wirklich den besten schmeckenden Schwanz der Welt."

    # say L1896 whi
    old "It's so great!"
    new "Es ist so gut!"

    # say L1897 whi
    old "I could suck it all day!"
    new "Ich könnte es den ganzen Tag lutschen!"

    # say L1898 whi
    old "I bet you want to have a taste too, don't you Jade?"
    new "Ich wette, Sie möchten auch einen Geschmack davon haben, nicht wahr, Jade?"

    # say L1899 whi
    old "It's great, believe me!"
    new "Es ist großartig, glauben Sie mir!"

    # say L1900 whi
    old "But he's mine first!"
    new "Aber er gehört erst einmal mir!"

    # say L1910 whi
    old "I hope this has helped you take some tension off."
    new "Ich hoffe, das hat Ihnen geholfen, etwas Spannung abzubauen."

    # say L1911 whi
    old "Now that we've broken the ice, you can do it at her house."
    new "Da wir nun das Eis gebrochen haben, können Sie es bei ihr zu Hause machen."

    # say L1915 whi
    old "Oh come on, Is that a problem?"
    new "Oh komm schon, ist das ein Problem?"

    # say L1917 whi
    old "Come on, you both enjoyed it and it's a win win."
    new "Kommen Sie schon, es hat euch beiden gefallen und es ist ein Gewinn für alle."

    # say L1920 whi
    old "You [pla], did you like to had your dick sucked by a hot MILF as Jade?"
    new "Sie [pla], hat es Ihnen gefallen, von einer heißen MILF wie Jade einen geblasen zu bekommen?"

    # say L1922 pla
    old "Uhh, y- yes..."
    new "Uhh, j- ja..."

    # say L1923 whi
    old "And you Jade? Did you enjoyed with a real big cock in your mouth?"
    new "Und Sie, Jade? Haben Sie es genossen, einen richtig großen Schwanz im Mund zu haben?"

    # say L1925 whi
    old "Well that's it, enjoy it together and don't make a fuss about it."
    new "Na dann, genießt es zusammen und macht keinen Aufstand darum."

    # say L1926 whi
    old "Sadly, I won't be able to be there with you guys every time you fool around, but Jade still needs some stress relief."
    new "Leider werde ich nicht immer dabei sein können, wenn ihr beiden euren Spaß habt, aber Jade braucht immer noch etwas Stressabbau."

    # say L1927 whi
    old "So, I trust that you'll give it to her whenever she needs it."
    new "So, ich vertraue darauf, dass Sie es ihr geben, wann immer sie es braucht."

    # say L1930 whi
    old "Now, Mike's about to come home, so, sadly we'll have to see each other again another time."
    new "Nun, Mike kommt gleich nach Hause, also müssen wir uns leider ein anderes Mal wiedersehen."

    # say L1931 whi
    old "But I've enjoyed a lot this little meeting."
    new "Aber ich habe diesen kleinen Besuch sehr genossen."

    # say L1932 pla
    old "I guess I have to get going too."
    new "Ich denke, ich muss auch los."

    # say L1934 jad
    old "Y- yeah, uhh, me too. But before we leave."
    new "Y- ja, äh, mir auch. Aber bevor wir gehen."

    # say L1937 jad
    old "Uhh... T- thank you [pla]."
    new "Uhh... D- danke [pla]."

    # say L1939 pla
    old "Uhmm... Sure, no problem."
    new "Hmm... Klar, kein Problem."

    # say L1940 pla
    old "I'm happy I'm able to help you Mrs. Jade."
    new "Ich bin froh, dass ich Ihnen helfen konnte, Mrs. Jade."

    # say L1941 whi
    old "That's great, alright, see you later guys."
    new "Das ist großartig, okay, dann sehen wir uns später, Leute."

    # say L1958 jad
    old "Wow, that was nice, isn't it?"
    new "Wow, das war schön, oder?"

    # say L1959 pla
    old "Phew, I wasn't expecting that to be honest.."
    new "Phew, ich hab ehrlich gesagt damit nicht gerechnet."

    # say L1960 jad
    old "Heh, well, I figured that if I was going to do it, I should just go ahead and try."
    new "Heh, na ja, ich dachte, wenn ich es tue, dann sollte ich es einfach mal ausprobieren."

    # say L1961 jad
    old "I'm glad you did seem to enjoy it."
    new "Ich bin froh, dass dir das gefallen hat."

    # say L1963 jad
    old "I've been thinking a lot about what Mrs. White said, and..."
    new "Ich hab viel über das nachgedacht, was Mrs. White gesagt hat, und..."

    # say L1964 jad
    old "I think she's right, I need to relax a bit more."
    new "Ich denke, sie hat recht, ich muss ein bisschen mehr locker werden."

    # say L1965 jad
    old "So, I'm happy I took the leap."
    new "Dann bin ich froh, dass ich den Sprung gewagt habe."

    # say L1967 pla
    old "Well, I'm happy I can be of help to you."
    new "Na, ich freue mich, dass ich dir helfen kann."

    # say L1968 jad
    old "You're a lot more than that honey."
    new "Du bist viel mehr als das, Schatz."

    # say L1969 jad
    old "About what just happened, you can think of it as your reward for all of the hard work you've been doing lately."
    new "Was gerade passiert ist, kannst du dir als Belohnung für all die harte Arbeit denken, die du lately geleistet hast."

    # say L1971 jad
    old "Well, now, if you'll excuse me, I think I'll lay down for a bit, honey."
    new "Na dann, wenn du mich entschuldigst, ich denke, ich werde mich jetzt ein bisschen hinlegen, Schatz."

    # say L1972 pla
    old "Sure, I'll see you later."
    new "Klar, bis später."

    # say L1973 jad
    old "Sure, good bye."
    new "Na klar, tschüss."

    # say L1982 pla
    old "I can't believe that actually happened."
    new "Ich kann nicht glauben, dass das tatsächlich passiert ist."

    # say L1983 pla
    old "Oh God, how do I always get into this."
    new "Oh Gott, wie komme ich immer in so was."

    # say L2001 pla
    old "Hi? Mrs. Jade? Hinn? I came to work in the bathroom!"
    new "Hi? Frau Jade? Hinn? Ich bin hier, um im Badezimmer zu arbeiten!"

    # say L2012 pla
    old "Uhh, This feels like Deja Vu..."
    new "Uhh, das fühlt sich wie Déjà-Vu an..."

    # say L2013 pla
    old "Hmm, I don't like where this is going..."
    new "Hmm, mir gefällt nicht, wohin das führt..."

    # say L2022 pla
    old "O- oh! Mrs. Jade, Mrs. White, you're here... Hi."
    new "O- oh! Frau Jade, Frau White, ihr seid hier... Hallo."

    # say L2024 jad
    old "Nevermind that [pla], we've been waiting for you."
    new "Lassen Sie das [pla], wir haben auf Sie gewartet."

    # say L2025 pla
    old "W- waiting?"
    new "W- warten?"

    # say L2026 whi
    old "Well sweetie, Jade was thinking maybe it was time to get drilled by your huge cock."
    new "Na Liebes, Jade dachte, es wäre vielleicht Zeit, von deinem großen Schwanz durchgefickt zu werden."

    # say L2027 pla
    old "... (Holly Shit...)"
    new "... (Heilige Scheiße...)"

    # say L2028 whi
    old "So, I thought I should be here to give her a little nudge forward."
    new "So, ich dachte, ich sollte hier sein, um ihr ein bisschen nachzuhelfen."

    # say L2030 jad
    old "Now honey, don't just stand there looking lost."
    new "Jetzt Schatz, steh nicht da und sieh aus wie verloren."

    # say L2031 whi
    old "Come here and fuck us [pla]!"
    new "Komm her und fick uns [pla]!"

    # say L2046 whi
    old "Ok, I'm glad I was able to be of help to you Jade."
    new "Ok, ich bin froh, dass ich dir helfen konnte, Jade."

    # say L2047 whi
    old "I suppose the next time you two won't need my assistance."
    new "Ich denke, das nächste Mal werdet ihr zwei meine Hilfe nicht mehr brauchen."

    # say L2048 whi
    old "But, don't be selfish, you can always invite me to spend a sexy afternoon like today."
    new "Aber, sei nicht egoistisch, du kannst mich immer einladen, einen solchen heißen Nachmittag wie heute zu verbringen."

    # say L2049 jad
    old "For sure I will."
    new "Klar, mach ich."

    # say L2050 whi
    old "Nice! So, I guess it's ok if I leave for now."
    new "Nett! Dann lass ich mich mal verabschieden."

    # say L2051 jad
    old "Ok, but again, thank you so much for all your help."
    new "Okay, aber nochmal danke für deine Hilfe."

    # say L2052 jad
    old "You were completely right about everything."
    new "Du hattest absolut recht in allem."

    # say L2053 whi
    old "Well, I'm always right, girl, you know that."
    new "Na, ich hab's dir ja gesagt, Mädchen, das weißt du."

    # say L2054 whi
    old "I'll be seeing you later [pla]."
    new "Ich seh dich später [pla]."

    # say L2060 jad
    old "Well, I guess it's too late for you to work on the bathroom now."
    new "Na, dann ist es wohl zu spät für dich, jetzt noch an dem Badezimmer zu arbeiten."

    # say L2061 jad
    old "And you must be very tired anyway, so, I suppose we'll see each other another time."
    new "Und Sie müssen sehr müde sein, also sehen wir uns wohl ein anderes Mal."

    # say L2062 pla
    old "Yeah, don't worry. I'll be back soon..."
    new "Klar, mach dir keine Sorgen. Ich bin bald wieder da..."

    # say L2063 pla
    old "See you later Mrs. Jade."
    new "Bis später, Mrs. Jade."

    # say L2064 jad
    old "See you later honey."
    new "Bis später Schatz."

    # say L2078 pla
    old "Ok! That's it! I think I'm done!"
    new "Ok! Das war's! Ich glaube, ich bin fertig!"

    # say L2079 pla
    old "Finally."
    new "Endlich."

    # say L2080 pla
    old "I think I should go tell Mrs. Jade."
    new "Ich glaube, ich sollte Mrs. Jade Bescheid sagen."

    # say L2088 pla
    old "Alright Mrs. Jade, I finished fixing the shower."
    new "Okay, Frau Jade, ich hab die Dusche repariert."

    # say L2090 pla
    old "You can now use it as before, it should be completely fine."
    new "Du kannst es jetzt wieder benutzen, es sollte komplett in Ordnung sein."

    # say L2091 jad
    old "Really? That's very good."
    new "Wirklich? Das ist sehr gut."

    # say L2092 pla
    old "Yeah, why don't you come with me so you can see it?"
    new "Klar, warum kommst du nicht mit mir, damit du es dir ansehen kannst?"

    # say L2102 pla
    old "You see? It's fine now."
    new "Siehst du? Alles gut jetzt."

    # say L2104 jad
    old "Thanks great! Thank you so much [pla]!"
    new "Danke schön! Danke dir so viel [pla]!"

    # say L2108 pla
    old "W- what? What are you doing Mrs. Jade?"
    new "W- was? Was machst du da, Mrs. Jade?"

    # say L2111 jad
    old "Well, since the shower's now working, I figured I should give it a try, don't you think?"
    new "Na ja, da die Dusche jetzt funktioniert, dachte ich, ich sollte sie mal ausprobieren, findest du nicht?"

    # say L2113 jad
    old "And since you've been working so hard, you should also try it, so you can relax a little bit after all of that hard work."
    new "Und da du so hart gearbeitet hast, solltest du es auch ausprobieren, damit du ein bisschen entspannen kannst nach all der harten Arbeit."

    # say L2114 jad
    old "So, now you and I are going to take a shower together."
    new "Dann gehen du und ich jetzt zusammen duschen."

    # say L2115 jad
    old "Now take off your clothes and get in the shower [pla]."
    new "Jetzt zieh dich aus und komm ins Bad [pla]."

    # say L2128 jad
    old "Ok, honey, I guess that's it with the bathroom."
    new "Ok, Schatz, dann ist das Bad wohl fertig."

    # say L2129 jad
    old "Thanks a lot for what you did."
    new "Danke schön für das, was du gemacht hast."

    # say L2130 jad
    old "I don't know how much it would've cost to fix it if I had contacted a plumber."
    new "Ich weiß gar nicht, wie teuer es geworden wäre, wenn ich einen Klempner gerufen hätte."

    # say L2131 pla
    old "No problem Mrs. Jade, I'm happy to help."
    new "Kein Problem, Frau Jade, ich freue mich, zu helfen."

    # say L2132 jad
    old "Oh, you did a lot more than that."
    new "Oh, du hast viel mehr getan als das."

    # say L2133 jad
    old "And I hope you know I expect to see you around here soon."
    new "Und ich hoffe, du weißt, dass ich erwarte, dich bald wiederzusehen."

    # say L2134 jad
    old "Please remember to come and pay me a visit once in a while."
    new "Bitte denk dran, mich mal zu besuchen."

    # say L2135 jad
    old "I know you'll enjoy it."
    new "Ich weiß, dass du es genießen wirst."

    # say L2136 pla
    old "Sure, I'll come by soon."
    new "Klar, ich komme bald vorbei."

    # say L2137 jad
    old "That's good honey, very good."
    new "Das ist gut, Schatz, sehr gut."

    # say L2138 jad
    old "I suppose you have to go?"
    new "Ich schätze, du musst los?"

    # say L2140 pla
    old "Yeah, it's a little bit late, and I'm really tired..."
    new "Ja, es ist schon ziemlich spät und ich bin echt müde..."

    # say L2141 jad
    old "Oh yeah, honey, you deserve a good rest."
    new "Oh ja, Schatz, du hast eine gute Ruhe verdient."

    # say L2142 pla
    old "Yeah, I will sleep like a baby tonight."
    new "Ja, ich werde heute Nacht wie ein Baby schlafen."

    # say L2144 pla
    old "Alright, have a good night Mrs. Jade."
    new "Alles Gute für die Nacht, Mrs. Jade."

    # say L2145 jad
    old "Have a good night, honey."
    new "Gute Nacht, Schatz."

    # say L2162 pla
    old "Oh, hi Hinn."
    new "Oh, hallo Hinn."

    # say L2163 pla
    old "How are you? How have your extra classes been going?"
    new "Wie geht es dir? Wie läufen deine Nachhilfestunden?"

    # say L2166 hin
    old "Hey, I wanted to thank you for all the hard work you did at my house with fixing the shower and stuff."
    new "Hey, ich wollte mich bei dir persönlich bedanken für die ganze harte Arbeit, die du bei mir zu Hause geleistet hast, bei der Dusche und so."

    # say L2168 pla
    old "Oh, my pleasure. I'm glad I was able to help you."
    new "Oh, das war mir ein Vergnügen. Ich bin froh, dass ich dir helfen konnte."

    # say L2169 hin
    old "Yeah well, I still wanted to thank you personally, because I bet my mom didn't even say thank you, did she?"
    new "Na ja, ich wollte dich trotzdem persönlich danken, weil ich wetten würde, dass meine Mom dir gar nicht gedankt hat, oder?"

    # say L2170 pla
    old "Uhh... She did, she did."
    new "Uhh... Sie hat, sie hat."

    # say L2171 pla
    old "She was actually very, very grateful."
    new "Sie war tatsächlich sehr, sehr dankbar."

    # say L2173 hin
    old "She was? Well, that's a surprise."
    new "Sie war? Na, das ist ja eine Überraschung."

    # say L2174 hin
    old "I'm glad she did."
    new "Ich bin froh, dass sie es getan hat."

    # say L2175 hin
    old "But don't think I forgot to give you my own thank you."
    new "Aber denk nicht, dass ich vergessen habe, dir meinen eigenen Dank zu geben."

    # say L2177 hin
    old "I'll be busy a couple more days with my extracurricular activities."
    new "Ich bin noch ein paar Tage mit meinen außerschulischen Aktivitäten beschäftigt."

    # say L2178 hin
    old "But as soon as I'm free I'll give you something to really say thanks."
    new "Aber sobald ich frei bin, gebe ich dir was, um dich richtig zu bedanken."

    # say L2179 hin
    old "Well, I don't have much more time, so, I have to leave, see you later [pla]."
    new "Na, ich hab nicht mehr viel Zeit, also muss ich los, bis später [pla]."

    # say L2191 hin
    old "By the way, I almost forgot to tell you. "
    new "Übrigens, ich hab fast vergessen, dir zu sagen."

    # say L2192 hin
    old "My mom asked me to tell you that there are a couple more things in the house that need fixing."
    new "Meine Mum hat mich gebeten, dir zu sagen, dass es noch ein paar Sachen im Haus gibt, die repariert werden müssen."

    # say L2193 hin
    old "And wanted to know if you could come and help us with that."
    new "Und wollte wissen, ob du uns dabei helfen kannst."

    # say L2194 hin
    old "Which is terrible of her to ask after all you already did. So, if you can't do it just tell me and I'll set her straight."
    new "Das ist echt viel zu viel von ihr zu verlangen, nach allem, was du schon getan hast. Also, wenn du es nicht kannst, sag mir einfach Bescheid und ich kläre das mit ihr."

    # say L2195 pla
    old "Uhh, yeah, actually it's fine, I kinda have an idea of what she wants me to do, so, don't worry, it's fine."
    new "Uhh, ja, eigentlich ist es in Ordnung, ich hab so eine Ahnung, was sie von mir will, also mach dir keine Sorgen, ist alles gut."

    # say L2196 hin
    old "It is? Well, I'm glad it doesn't bother you."
    new "Ist es? Na, dann bin ich froh, dass dich das nicht stört."

    # say L2197 hin
    old "Thanks a lot [pla], I'll see you later."
    new "Danke schön [pla], dann sehen wir uns später."

    # say L2217 jad
    old "Hi honey, tell me, do you need anything?"
    new "Hi Schatz, erzähl mir, brauchst du was?"

    # say L2222 pla
    old "I should find a therapist first."
    new "Ich sollte erst einen Therapeuten finden."

    # say L2234 jad
    old "Hey [pla], don't you have to be at school?"
    new "Hey [pla], musst du nicht in der Schule sein?"

    # say L2236 pla
    old "Right, I was just looking for Hinn."
    new "Stimmt, ich hab nur nach Hinn gesucht."

    # say L2238 jad
    old "Hinn? She is already at school... Don't be late, [pla]... "
    new "Hinn? Die ist schon in der Schule... Komm nicht zu spät, [pla]..."

    # say L2240 pla
    old "You're right. Sorry. I better go now..."
    new "Du hast recht. Tut mir leid. Ich sollte jetzt besser losgehen..."

    # say L2242 jad
    old "...(Hmm.)"
    new "(Hmm.)"

    # say L2276 jad
    old "What? But right now it's school time!"
    new "Was? Aber jetzt ist Schultime!"

    # say L2277 jad
    old "It's very sweet of you to come here to help, but I don't want you missing any classes because of me."
    new "Das ist sehr lieb von dir, dass du hierher kommst, um mir zu helfen, aber ich will nicht, dass du wegen mir Unterricht verpasst."

    # say L2278 jad
    old "You should go to school, I'll be here in the afternoon, so you can come and do the bathroom then."
    new "Du solltest zur Schule gehen, ich bin dann nachmittags hier, da kannst du dann kommen und das Bad machen."

    # say L2279 pla
    old "Yeah, I think you're right."
    new "Ja, ich denke, du hast recht."

    # say L2280 pla
    old "I'll come here later then."
    new "Dann komme ich später hierher."


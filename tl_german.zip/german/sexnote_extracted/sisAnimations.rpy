# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/sisAnimations.rpy
translate german strings:

    # say L6 pla
    old "W- What are you doing?"
    new "W- Was machst du?"

    # say L7 sis
    old "What does it look like?"
    new "Was siehst du denn?"

    # say L12 sis
    old "Hmm, your cock is so tasty!"
    new "Hmm, dein Schwanz schmeckt so lecker!"

    # say L13 sis
    old "Don't you like it?"
    new "Magst du es nicht?"

    # say L18 sis
    old "I can't believe you have such a big cock!"
    new "Ich kann nicht glauben, dass du so einen großen Schwanz hast!"

    # say L43 pla
    old "Please, stop. You are... Gonna make me-"
    new "Bitte, hör auf. Du bringst mich noch dazu-"

    # say L44 sis
    old "Cum? Oh please do it. I'm dying to see this monster cock cum all over..."
    new "Kommst du? Oh bitte, tu es. Ich sterbe darauf, zu sehen, wie dieser Monsterpenis überall spritzt..."

    # say L50 sis
    old "Shit! That was so intense... Did you like it?"
    new "Scheiße! Das war so intensiv... Hast du es genossen?"

    # say L51 pla
    old "Ye... I- I have to go..."
    new "Ja... Ich- Ich muss jetzt gehen..."

    # say L58 pla
    old "What the fuck was that?"
    new "Was zur Hölle war das?"

    # say L59 pla
    old "I better go to sleep now..."
    new "Ich sollte jetzt schlafen gehen..."

    # say L74 pla
    old "Ready for a new day!..."
    new "Bereit für einen neuen Tag!"

    # say L92 sis
    old "Hmm I love this taste."
    new "Hmm, ich liebe diesen Geschmack."

    # say L93 sis
    old "Do you like how it feels inside my mouth?"
    new "Magst du, wie es sich in meinem Mund anfühlt?"

    # say L97 sis
    old "It's fucking huge, I want to have it all inside, do you think I'm capable?"
    new "Es ist verdammt groß, ich will es ganz in mir haben, glaubst du, dass ich das schaffe?"

    # say L99 sis
    old "Oh my god, I can feel it reaching my throat."
    new "Oh mein Gott, ich spüre es bis in meinen Hals."

    # say L103 sis
    old "What about a deepthroat?"
    new "Was ist mit einem Deepthroat?"

    # say L105 pla
    old "Oh my God!"
    new "Oh mein Gott!"

    # say L106 sis
    old "Oh my, I can feel every inch inside my mouth!"
    new "Oh mein, ich kann jeden Zentimeter in meinem Mund spüren!"

    # say L129 pla
    old "Ohhh, I- I!"
    new "Ohhh, ich- ich!"

    # say L134 sis
    old "Wow... That was massive, let me clean this mess... "
    new "Wow... Das war riesig, lass mich das Chaos beseitigen..."

    # say L163 pla
    old "(Oh man in a second I will be hard...)"
    new "Oh Mann, in einer Sekunde bin ich wieder hart..."

    # say L166 sis
    old "Ohh, I love it ... My tits are very sensitive, I'm getting horny..."
    new "Ohh, ich liebe es... Meine Titten sind sehr empfindlich, ich werde geil..."

    # say L170 sis
    old "Ohh yeah, just like that... Don't stop baby..."
    new "Ohh ja, genau so... Hör nicht auf, Baby..."

    # say L207 sis
    old "How does it feel in between these amazing boobs?"
    new "Wie fühlt es sich zwischen diesen unglaublichen Titten an?"

    # say L208 pla
    old "Ohh... It... Feels great."
    new "Ohh... Es... fühlt sich toll an."

    # say L211 sis
    old "Ohh... It feels really good..."
    new "Ohh... Es fühlt sich wirklich gut an..."

    # say L212 sis
    old "Do not try to stop, keep moving faster."
    new "Versuch nicht, aufzuhören, beweg dich schneller."

    # say L216 sis
    old "Oh yeah, fuck my tits! Harder, fuck them harder!"
    new "Oh ja, fick meine Titten! Fester, fick sie fester!"

    # say L240 pla
    old "[sis], I'm going to..."
    new "[sis], ich komme..."

    # say L241 sis
    old "Oh yeah, cum all over me!"
    new "Oh ja, spritz alles über mich!"

    # say L260 pla
    old "Oh shit, she is playing with her dildo..."
    new "Oh Scheiße, sie spielt mit ihrem Dildo..."

    # say L261 pla
    old "I have to keep quiet so she doesn't notice me."
    new "Ich muss leise sein, damit sie mich nicht bemerkt."

    # say L265 sis
    old "Mmm, it feels so good!"
    new "Mmm, das fühlt sich so gut!"

    # say L266 sis
    old "My pussy wants a big, hard cock!"
    new "Meine Pussy will einen großen, harten Schwanz!"

    # say L270 sis
    old "Oh yeah! it feels better than fingering!"
    new "Oh ja! Es fühlt sich besser an als beim Fingern!"

    # say L271 sis
    old "I'm so fucking wet right now."
    new "Ich bin so nass im Moment."

    # say L302 sis
    old "Ughhh I can't take it anymore, I want to feel my pussy fucked! "
    new "Ughhh ich kann es nicht mehr aushalten, ich will meine Pussy gefickt spüren!"

    # say L304 pla
    old "(Oh wow!)"
    new "Oh wow!"

    # say L305 sis
    old "Ohhh yeah!"
    new "Ohhh ja!"

    # say L309 sis
    old "Ahhh, yes! Right there."
    new "Ahhh, ja! Genau da."

    # say L310 sis
    old "This is so fucking good!"
    new "Das ist so verdammt gut!"

    # say L314 sis
    old "Mmmm, I want to cum now!"
    new "Mmmm, ich will jetzt kommen!"

    # say L343 sis
    old "Oh, yeah! Yeahh!!!"
    new "Oh, ja! Jaah!!!"

    # say L344 sis
    old "I'm cumming!"
    new "Ich komme!"

    # say L360 pla
    old "(Oh my god it's like my dream!)"
    new "Oh mein Gott, das ist wie mein Traum!"

    # say L361 sis
    old "Oh yeah, fuck my mouth [pla]."
    new "Oh ja, fick meinen Mund [pla]."

    # say L364 sis
    old "Come on! I want you to fuck my throat harder!"
    new "Komm schon! Ich will, dass du meinen Hals härter fickst!"

    # say L365 pla
    old "A- alright..."
    new "A- okay..."

    # say L370 sis
    old "I want to have it all inside my mouth."
    new "Ich will es ganz in meinem Mund haben."

    # say L371 sis
    old "Harder [pla], fuck my mouth harder!"
    new "Fester [pla], fick meinen Mund fester!"

    # say L397 sis
    old "Don't stop, don't stop! Cum inside my throat!"
    new "Hör nicht auf, hör nicht auf! Spritz in meinen Rachen!"

    # say L414 sis
    old "Ohh! It's so big..."
    new "Ohh! Es ist so groß..."

    # say L415 sis
    old "Your cock is so much better than my dildo."
    new "Dein Schwanz ist so viel besser als mein Dildo."

    # say L419 sis
    old "Come on, I want you harder, fuck me harder [pla]!"
    new "Komm schon, ich will dich härter, fick mich härter [pla]!"

    # say L422 sis
    old "Do you like being inside your [sisrel]?"
    new "Magst du es, wenn ich in dir bin [sisrel]?"

    # say L426 sis
    old "Yeah! Yeah! Fuck me [pla], Fuck me!"
    new "Ja! Ja! Fick mich [pla], fick mich!"

    # say L428 sis
    old "Oh gosh! It's fucking huge!"
    new "Oh Gott! Es ist verdammt groß!"

    # say L429 sis
    old "You're drilling me"
    new "Du fickst mich durch"

    # say L452 sis
    old "I'M GONNA... I'M GONNA-"
    new "ICH BIN DRAUF... ICH BIN DRAUF-"

    # say L453 sis
    old "OOOOOHHHH! YEAHHH..."
    new "OOOOHHHH! JAAAAH..."

    # say L457 sis
    old "Fuck... It was really good..."
    new "Scheiße... Das war echt gut..."

    # say L466 pla
    old "Ok... Let me try, like this?"
    new "Ok... Lass mich es so versuchen?"

    # say L467 sis
    old "Just relax your hands and enjoy what you are doing, don't you like it?"
    new "Lass einfach deine Hände locker und genieße, was du tust, magst du es etwa nicht?"

    # say L468 pla
    old "Gulp... Y-yes."
    new "Gulp... J-ja."

    # say L471 sis
    old "Yeah, you're doing great, very gentle."
    new "Ja, du machst das super, sehr zart."

    # say L472 pla
    old "(This is delicious, she is so hot.)"
    new "Das ist köstlich, du bist so heiß."

    # say L473 sis
    old "Do you like my ass?"
    new "Magst du meinen Arsch?"

    # say L478 sis
    old "Be creative, you can touch all you want! I like it."
    new "Du kannst dich gerne auslassen, berühre mich, wie du willst! Mir gefällt es."

    # say L479 sis
    old "Do it harder baby..."
    new "Mach es härter, Baby..."

    # say L517 sis
    old "Ugghh... It feels great."
    new "Ugghh... Das fühlt sich toll an."

    # say L518 sis
    old "Oh yeah... Fuck my pussy baby."
    new "Oh ja... Fick meine Pussy Baby."

    # say L522 sis
    old "Ohh yeah baby, don't stop."
    new "Ohh ja Baby, hör nicht auf."

    # say L523 sis
    old "Yes! Yes! Just like that fuck me [pla]!"
    new "Ja! Ja! Genau so fick mich [pla]!"

    # say L527 sis
    old "Ohhh, ohhh, I'm goona cum. Harder. Fuck me harder!"
    new "Ohhh, ohhh, ich komme gleich. Fester. Fick mich fester!"

    # say L551 sis
    old "OHH GOD, OHH GOD. I'M CUMMING!"
    new "OHH GOTT, OHH GOTT. ICH KOMME!"

    # say L553 pla
    old "I- I'm cumming too!"
    new "Ich- Ich komme auch!"

    # say L556 sis
    old "Oh yeah... I can feel it all inside me."
    new "Oh ja... ich spüre es alles in mir."

    # say L570 sis
    old "I love playing with your cock"
    new "Ich liebe es, mit deinem Schwanz zu spielen"

    # say L571 sis
    old "Enjoy the view..."
    new "Genieße den Anblick..."

    # say L574 sis
    old "Do you like my throat?"
    new "Magst du meinen Rachen?"

    # say L575 pla
    old "Oh yes..."
    new "Oh ja..."

    # say L576 sis
    old "Then, what are you waiting to fuck it?"
    new "Dann, worauf wartest du noch, es zu ficken?"

    # say L580 sis
    old "Harder [pla], fuck your [sisrel] throat!"
    new "Fester [pla], fick deinen [sisrel] Hals!"

    # say L606 pla
    old "[sis] I'm going to-"
    new "[sis] Ich komme-"

    # say L607 sis
    old "Cum in my mouth baby..."
    new "Komm in meinen Mund Baby..."

    # say L625 sis
    old "Ughh, is so big."
    new "Ughh, das ist so groß."

    # say L626 sis
    old "I love it!!!"
    new "Ich liebe es!!!"

    # say L627 sis
    old "Ohhh nicee baby, yeah fuck your [sisrel]!"
    new "Ohhh nicee Baby, ja fick deinen [sisrel]!"

    # say L630 sis
    old "Ohh I want you deep inside me..."
    new "Ohh ich will dich tief in mir spüren..."

    # say L633 sis
    old "My pussy is gripping that fucking cock."
    new "Meine Pussy umschließt deinen fickenden Schwanz."

    # say L636 sis
    old "HARDER! FUCK ME HARDER BABY!"
    new "HÄRTER! FICK MICH HÄRTER, SCHATZ!"

    # say L638 sis
    old "OH GOD, OH GOD! I'M CUMING!"
    new "OH GOTT, OH GOTT! ICH KOMME!"

    # say L661 pla
    old "I'm gonna-"
    new "Ich komme-"

    # say L662 sis
    old "YES BABY CUM INSIDE ME!"
    new "JA BABY, KOMM IN MICH!"

    # say L707 sis
    old "Alright, now it's time to wake up."
    new "Okay, jetzt ist es Zeit aufzuwachen."

    # say L709 sis
    old "This is a dream, dummy... "
    new "Das ist ein Traum, Dummerchen..."

    # say L710 sis
    old "Did you really think that I would let you fuck my mouth?"
    new "Hast du wirklich gedacht, dass ich dir das durchgehen lasse?"

    # say L721 linSis
    old "That’s right, just let me do the work."
    new "Genau, lass mich das machen."

    # say L722 linSis
    old "Mmmm! It’s so big."
    new "Mmmm! Es ist so groß."

    # say L723 pla
    old "Do you feel ok? Has anything changed?"
    new "Alles okay? Hat sich was verändert?"

    # say L724 linSis
    old "I do, it feels so different, human bodies are more sensitive after all."
    new "Es tut, es fühlt sich so anders an, menschliche Körper sind nun mal sensibler."

    # say L725 linSis
    old "But nothing has changed, no problem."
    new "Aber es hat sich nichts geändert, kein Problem."

    # say L729 linSis
    old "Oh, yes, like that."
    new "Oh, ja, so gut."

    # say L730 linSis
    old "It feels soo great."
    new "Das fühlt sich so gut an."

    # say L731 pla
    old "Do you feel any magic?"
    new "Spürst du schon etwas Magisches?"

    # say L732 linSis
    old "Not yet... Ah! keep going."
    new "Noch nicht... Ah! Mach weiter."

    # say L733 linSis
    old "Maybe in a little. Mmmm."
    new "Vielleicht gleich. Mmmm."

    # say L737 linSis
    old "AH, AH, YES!"
    new "AH, AH, JA!"

    # say L738 linSis
    old "N- now I feel it."
    new "N- jetzt spür ich es."

    # say L739 linSis
    old "Don’t stop, keep going!"
    new "Hör nicht auf, mach weiter!"

    # say L762 pla
    old "I- I can’t hold it anymore."
    new "Ich halte es nicht mehr aus."

    # say L764 linSis
    old "Oh yes, do it!"
    new "Oh ja, mach weiter!"

    # say L766 linSis
    old "Ohh yeahh!"
    new "Ohh jaah!"

    # say L772 lin
    old "Amazing, it’s incredible how much magic power you’re able to hold and release."
    new "Unglaublich, wie viel magische Kraft du halten und freisetzen kannst."

    # say L773 lin
    old "And doing it in a human body felt so different and good!"
    new "Und es in einem menschlichen Körper zu tun, fühlte sich so anders und gut an!"


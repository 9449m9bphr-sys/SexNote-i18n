# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/HomePool.rpy
translate german strings:

    # say L13 pla
    old "I should talk with Brixxida first."
    new "Ich sollte erst mit Brixxida reden."

    # say L37 pla
    old "No, no, sorry I was just walking around."
    new "Nein, nein, tut mir leid, ich bin nur rumgelaufen."

    # say L55 ann
    old "[pla]... Are you trying to peek at me while I sunbathe?"
    new "[pla]... Versuchst du etwa, mich beim Sonnenbaden zu beobachten?"

    # say L57 pla
    old "What? No, I wasn't-"
    new "Was? Nein, ich war nicht-"

    # say L59 ann
    old "Uhm, you get very nervous, kid..."
    new "Ähm, du wirst ganz nervös, Kleiner..."

    # say L61 ann
    old "Is this what you want to see?"
    new "Ist das, was du sehen willst?"

    # say L66 ann
    old "Well, if that's what you want..."
    new "Na gut, wenn das ist, was du willst..."

    # say L68 ann
    old "Just don't bother me while I sunbathe, ok?"
    new "Lass mich einfach in Ruhe, während ich mich sonne, okay?"

    # say L82 ann
    old "Didn't I tell you not to bother me? Don't keep bothering me."
    new "Hab ich dir nicht gesagt, mich nicht zu stören? Lass das jetzt."

    # say L84 pla
    old "Ok, sorry."
    new "Okay, tut mir leid."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/JonStory.rpy
translate german strings:

    # say L6 bil
    old "Oh... hey."
    new "Oh... hallo."

    # say L7 pla
    old "... Uhh hi."
    new "... Äh, hallo."

    # say L8 bil
    old "This is a bit awkward... Do you need something?"
    new "Das ist ein bisschen unangenehm... Brauchst du was?"

    # say L33 bil
    old "Weird."
    new "Komisch."

    # say L39 pla
    old "Oh, no, no sorry, I was just looking for Mrs. Jones."
    new "Oh nein, nein, entschuldige, ich suchte nur nach Mrs. Jones."

    # say L41 pla
    old "... Alright, see you."
    new "Okay, dann bis später."

    # say L53 pla
    old "Hi everybody, how are you doing?"
    new "Hi alle, wie geht's euch?"

    # say L54 gra
    old "Hi [pla], God be with you!"
    new "Hallo [pla], Gott sei mit Ihnen!"

    # say L55 jon
    old "Hi [pla] so happy to see you! We were talking about you..."
    new "Hallo [pla], ich freue mich so, Sie zu sehen! Wir haben gerade über Sie gesprochen..."

    # say L56 gra
    old "In fact, we were talking about you with Father Morgan as well."
    new "Tatsächlich haben wir auch mit Father Morgan über Sie gesprochen."

    # say L57 pla
    old "Oh! Really? What were you saying about me? Am I in trouble?"
    new "Oh! Wirklich? Was habt ihr über mich gesagt? Bin ich in Schwierigkeiten?"

    # say L58 jon
    old "Noo! It's the opposite, we are so grateful for what you've done for us."
    new "Nein! Ganz im Gegenteil, wir sind Ihnen sehr dankbar für das, was Sie für uns getan haben."

    # say L59 jon
    old "Billie is feeling good now and we can feel our church is a peaceful place again, all thanks to you."
    new "Billie fühlt sich jetzt gut und wir können spüren, dass unsere Kirche wieder ein friedlicher Ort ist, alles dank Ihnen."

    # say L60 pla
    old "Well... I-I just did what God told me to do... It was actually him, not me."
    new "Na ja... I-I ich habe nur getan, was Gott mir gesagt hat... Es war eigentlich er, nicht ich."

    # say L62 gra
    old "And that's why we want you to be part of our community, we want you to join our activities."
    new "Und deshalb möchten wir, dass Sie Teil unserer Gemeinschaft werden, wir möchten, dass Sie sich an unseren Aktivitäten beteiligen."

    # say L63 jon
    old "We saw how God works through your hands, you've shown us that you're like a saint."
    new "Wir haben gesehen, wie Gott durch Ihre Hände wirkt, Sie haben uns gezeigt, dass Sie wie eine Heilige sind."

    # say L64 gra
    old "Join us, please! It would be our pleasure to have you here."
    new "Treten Sie bei uns ein, bitte! Es wäre uns eine Freude, Sie hier bei uns zu haben."

    # say L65 pla
    old "(Yes! This is the perfect chance to get closer to them...)"
    new "Ja! Das ist die perfekte Gelegenheit, ihnen näher zu kommen..."

    # say L66 pla
    old "I'm so glad to hear that, of course I will be more than happy to be here helping and being part of the community."
    new "Ich freue mich sehr zu hören, natürlich werde ich gerne hier sein und helfen und Teil der Gemeinschaft werden."

    # say L67 pla
    old "I can start whenever you want... Just tell me what to do."
    new "Ich kann jederzeit anfangen... Sag mir einfach, was ich tun soll."

    # say L69 jon
    old "Oh really hun, that's great!"
    new "Oh wirklich, das ist toll!"

    # say L70 gra
    old "Well, our main interest is to attract more young people to the community."
    new "Nun, unser Hauptinteresse ist es, mehr junge Menschen in die Gemeinde zu locken."

    # say L72 jon
    old "That's why we believe that you are the best to help us and with your example and attitude we believe that we will be able to attract many young people."
    new "Deshalb glauben wir, dass Sie die Beste sind, um uns zu helfen, und mit Ihrem Vorbild und Ihrer Einstellung denken wir, dass wir viele junge Leute anziehen können."

    # say L73 gra
    old "Even get to have altar girls in the church!"
    new "Sogar Altardienerinnen in der Kirche haben!"

    # say L74 pla
    old "Wow, that's sounds good, so what do you want me to do?"
    new "Wow, das klingt gut, was soll ich denn machen?"

    # say L75 gra
    old "Well, we have to wait a bit for that. Father Morgan is a bit busy these days and we can't start without him."
    new "Nun, wir müssen noch ein wenig warten. Father Morgan ist derzeit sehr beschäftigt und ohne ihn können wir nicht beginnen."

    # say L76 jon
    old "However, we still need help in other activities. And a young hand would be very useful."
    new "Allerdings brauchen wir immer noch Hilfe bei anderen Aktivitäten. Und eine junge Hand wäre sehr nützlich."

    # say L77 jon
    old "For example, cleaning the church after every mass is very tiring for just the two of us."
    new "Zum Beispiel, das Reinigen der Kirche nach jeder Messe ist für uns beide sehr anstrengend."

    # say L80 gra
    old "Perfect! So, you can come every afternoon to help us with the cleaning, the three of us can finish in a jiffy."
    new "Perfekt! Dann kannst du jeden Nachmittag kommen, um uns beim Saubermachen zu helfen, zu dritt schaffen wir das im Nu."

    # say L82 jon
    old "Great, then why don't we start tomorrow, okay?"
    new "Großartig, dann fangen wir doch morgen an, okay?"

    # say L83 pla
    old "Alright! So I'll be back tomorrow."
    new "Okay! Dann bin ich morgen wieder da."

    # say L84 jon
    old "Thank you so much hun, see you tomorrow!"
    new "Vielen Dank, meine Liebe, bis morgen!"

    # say L85 gra
    old "Bye [pla]"
    new "Tschüss [pla]"

    # say L86 pla
    old "S-see you Mrs. Jones and sister Grace."
    new "S-Bis dann, Mrs. Jones und Schwester Grace."

    # say L102 gra
    old "Oh, hi [pla], you came just in time!"
    new "Oh, hallo [pla], du kommst gerade richtig!"

    # say L103 pla
    old "Hi, well, I don't want to leave all the work to just the two of you."
    new "Hi, na klar, ich will euch beiden die ganze Arbeit nicht überlassen."

    # say L104 jon
    old "Oh thank you honey, you are so kind."
    new "Oh danke Schatz, Sie sind so lieb."

    # say L105 gra
    old "Ok, let me explain you, it's simple, we just have to clean up the church a bit... As you can see, it's a mess!"
    new "Ok, lassen Sie mich es Ihnen erklären, es ist einfach, wir müssen nur ein bisschen die Kirche aufräumen... Wie Sie sehen, ist es ein Chaos!"

    # say L106 gra
    old "[pla], pick up papers if you see them on the floor... You know, make the place pretty."
    new "[pla], wenn du Papiere auf dem Boden siehst, dann aufheben... Du weißt schon, den Ort schön machen."

    # say L108 jon
    old "And pick up what shouldn't be in the church right now... All those stuff."
    new "Und sammeln Sie auf, was nicht in der Kirche sein sollte... All das Zeug."

    # say L110 jon
    old "This will be too easy for you, cleaning won't be an issue..."
    new "Das wird für Sie ein Kinderspiel sein, Saubermachen wird kein Problem für Sie sein..."

    # say L111 pla
    old "Don't worry, I wanna be as quick as possible."
    new "Keine Sorge, ich will so schnell wie möglich fertig werden."

    # say L112 gra
    old "So, hurry up hun, hahaha."
    new "Dann mach mal schnell, Schatz, hahaha."

    # say L124 gra
    old "Oh, hi [pla], How are you today?"
    new "Oh, hallo [pla], wie geht es Ihnen heute?"

    # say L125 pla
    old "Hi sister Grace, I'm pretty good, thanks for asking."
    new "Hallo Schwester Grace, mir geht's ziemlich gut, danke fürs Nachfragen."

    # say L126 jon
    old "Great Hun, are you ready to start with cleaning?"
    new "Großartig, Liebling, sind Sie bereit, mit dem Saubermachen zu beginnen?"

    # say L127 pla
    old "Sure, I'm ready to start."
    new "Klar, ich bin bereit loszulegen."

    # say L128 gra
    old "Perfect, let's start to clean the church."
    new "Perfekt, dann fangen wir an, die Kirche zu putzen."

    # say L139 jon
    old "Hi [pla], you came early, I'm waiting for sister Grace, she is with Father Morgan."
    new "Hi [pla], Sie sind früh dran, ich warte auf Schwester Grace, sie ist bei Father Morgan."

    # say L140 pla
    old "Oh, don't worry. I can accompany you in the meantime."
    new "Oh, mach dir keine Sorgen. Ich kann dich in der Zwischenzeit begleiten."

    # say L141 jon
    old "Oh, thanks hun... I really appreciate your help on this."
    new "Oh, danke Schatz... Ich schätze deine Hilfe wirklich."

    # say L142 jon
    old "I'm old and you know... I'm not as flexible as I was before."
    new "Ich bin alt und Sie wissen... ich bin nicht mehr so flexibel wie früher."

    # say L143 pla
    old "Hmm... I'm sorry to hear that... I think you're still young, though."
    new "Hmm... Das tut mir leid zu hören... Ich denke, du bist immer noch jung, Jon."

    # say L144 jon
    old "You know, when I look at you... I see a very kind person, you're really nice, dear."
    new "Sie wissen, wenn ich Sie ansehe... sehe ich einen sehr netten Menschen, Sie sind wirklich lieb, mein Lieber."

    # say L145 pla
    old "Haha, thanks Mrs. Jones!"
    new "Haha, danke Mrs. Jones!"

    # say L146 jon
    old "You're like an angel... Sent by God!"
    new "Sie sind wie ein Engel... von Gott gesandt!"

    # say L148 pla
    old "That's very nice of you but I'm just a normal guy..."
    new "Das ist sehr nett von dir, aber ich bin nur ein ganz normaler Kerl..."

    # say L149 jon
    old "You know dear... It's like destiny, I think you're here for a reason.."
    new "Sie wissen doch, lieber... Es ist wie Schicksal, ich denke, Sie sind hier aus einem Grund."

    # say L150 pla
    old "Ehm... Really?"
    new "Ehm... Wirklich?"

    # say L152 jon
    old "I've seen what you've done and well... Yeah! I think so..."
    new "Ich habe gesehen, was Sie getan haben und ja... Ich denke schon."

    # say L153 jon
    old "You're very spiritual and you remind me of..."
    new "Sie sind sehr spirituell und Sie erinnern mich an..."

    # say L154 pla
    old "Remind you of? W- Who?"
    new "W- Wer?"

    # say L156 jon
    old "You remind me of my husband. When he was alive, he was so kind and strong, just like you."
    new "Sie erinnern mich an meinen Mann. Als er noch lebte, war er so freundlich und stark, genau wie Sie."

    # say L157 jon
    old "He was amazing, I truly miss him."
    new "Er war unglaublich, ich vermisse ihn wirklich."

    # say L165 gra
    old "Hey [pla], I didn't know you were here... I see you're very committed to our community. How are you?"
    new "Hey [pla], ich wusste gar nicht, dass Sie hier sind... Ich sehe, Sie engagieren sich sehr in unserer Gemeinde. Wie geht es Ihnen?"

    # say L166 pla
    old "I'm fine... And you?"
    new "Mir geht's gut... Und dir?"

    # say L168 gra
    old "All good!"
    new "Alles gut!"

    # say L169 gra
    old "Great! Mrs. Jones? We need to start cleaning, this is really a mess!"
    new "Großartig! Mrs. Jones? Wir müssen anfangen zu putzen, das ist wirklich ein Chaos!"

    # say L170 jon
    old "Yeah, sure sister Grace..."
    new "Ja, klar Schwester Grace..."

    # say L171 gra
    old "Let's get this done! We have many things to do."
    new "Lass uns das erledigen! Wir haben noch viel zu tun."

    # say L172 pla
    old "(I have to find the way to get closer to Mrs. Jones...)"
    new "Ich muss einen Weg finden, um Mrs. Jones näher zu kommen..."

    # say L173 gra
    old "[pla]? Are you with us?"
    new "[pla]? Sind Sie bei uns?"

    # say L174 pla
    old "Yeah... Yeah, sure... Let's do it."
    new "Ja... Ja, klar... Machen wir."

    # say L188 jon
    old "Wow! That was a hard job! I'm exhausted..."
    new "Wow! Das war eine harte Arbeit! Ich bin erschöpft..."

    # say L189 gra
    old "It was a lot, yeah... "
    new "Es war viel, ja..."

    # say L191 jon
    old "sister Grace, I'm gonna go now..."
    new "Schwester Grace, ich geh jetzt..."

    # say L192 gra
    old "Oh, do you have to leave early today?"
    new "Oh, musst du heute schon so früh gehen?"

    # say L193 jon
    old "Yes, I think it would be nice to spend some time with Billie too, I'll go to see her."
    new "Ja, ich denke, es wäre schön, auch etwas Zeit mit Billie zu verbringen. Ich gehe sie besuchen."

    # say L194 gra
    old "Ahh! Of course, Mrs. Jones... Have fun with your granddaughter. I'll be in good hands with [pla] here."
    new "Ach ja, natürlich, Mrs. Jones... Viel Spaß mit Ihrer Enkelin. Ich bin hier in guten Händen mit [pla]."

    # say L195 jon
    old "You'll, see you sister Grace..."
    new "Bis dann, Schwester Grace..."

    # say L197 jon
    old "See you [pla]."
    new "Bis dann [pla]."

    # say L198 pla
    old "Bye Mrs. Jones, take care."
    new "Tschüss Mrs. Jones, pass auf dich auf."

    # say L204 gra
    old "You did a great job today [pla]."
    new "Sie haben heute eine großartige Arbeit geleistet [pla]."

    # say L205 pla
    old "Thanks, we all worked really hard."
    new "Danke, wir haben alle wirklich hart gearbeitet."

    # say L207 gra
    old "I've noticed how spiritual and good you're... I'm a bit embarrased to ask you this but..."
    new "Ich habe bemerkt, wie fromm und gut du bist... Ich bin etwas verlegen, dich danach zu fragen, aber..."

    # say L208 gra
    old "But... I would like to ask for your help."
    new "Aber... ich würde gerne um Ihre Hilfe bitten."

    # say L210 pla
    old "My help? Sure, tell me sister Grace. What can I do for you?"
    new "Deine Hilfe? Klar, erzähl mir, Schwester Grace. Was kann ich für dich tun?"

    # say L211 gra
    old "W- well... I wanna clean my spirit and my soul... I've been working on this with Father Morgan..."
    new "N- nun... ich möchte meinen Geist und meine Seele reinigen... Ich arbeite daran mit Father Morgan..."

    # say L212 gra
    old "But to be honest I think you're much more spiritual than him, perhaps you could help me more..."
    new "Aber ehrlich gesagt, ich denke, Sie sind viel spiritueller als er, vielleicht können Sie mir mehr helfen..."

    # say L214 pla
    old "(I think see where this is going...)"
    new "Ich denke, ich sehe, wohin das führt..."

    # say L215 gra
    old "I mean, you did the exorcism... You helped Billie and you're nice with everyone. I can feel your energy is different."
    new "Ich meine, Sie haben den Exorzismus durchgeführt... Sie haben Billie geholfen und sind nett zu allen. Ich kann spüren, dass Ihre Energie anders ist."

    # say L216 gra
    old "It's divine and sacred."
    new "Es ist göttlich und heilig."

    # say L217 pla
    old "I'm glad you think that of me and if you truly believe I could help you out, I'll do it..."
    new "Ich freue mich, dass du das so siehst, und wenn du wirklich glaubst, dass ich dir helfen kann, mache ich es..."

    # say L218 gra
    old "I feel a bit embarrassed, I'll do what I believe is good and saint, and I'm thinking of you as a blessed man..."
    new "Ich fühle mich ein bisschen verlegen, ich werde tun, was ich für gut und heilig halte, und ich denke an dich als einen gesegneten Mann..."

    # say L219 gra
    old "I'll be honest with you... Since I saw you performing the ritual with Billie, I have been constantly thinking of you."
    new "Ich werde ehrlich zu Ihnen sein... Seit ich Sie bei dem Ritual mit Billie gesehen habe, denke ich ständig an Sie."

    # say L223 gra
    old "I feel like you can help me as you helped her. You saved her and you could save me too."
    new "Ich habe das Gefühl, dass Sie mir helfen können, wie Sie ihr geholfen haben. Sie haben sie gerettet und könnten auch mich retten."

    # say L224 pla
    old "(Wow) O- ok..."
    new "W-Wow... Okay..."

    # say L225 gra
    old "I need to cleanse my soul."
    new "Ich muss meine Seele reinigen."

    # say L226 gra
    old "I would need to go down on you."
    new "Ich müsste dir einen blasen."

    # say L228 pla
    old "W-What? D-down?"
    new "W-Was? D-Down?"

    # say L229 gra
    old "I have to pray in a different way."
    new "Ich muss auf andere Weise beten."

    # say L231 pla
    old "A- Are y- you s- sure about that?"
    new "B- Bist d- du d- dir d- da s- sicher?"

    # say L232 gra
    old "You helped Billie and everytime I'm next to you, I can feel your divine and strong energy."
    new "Sie haben Billie geholfen und jedes Mal, wenn ich in Ihrer Nähe bin, kann ich Ihre göttliche und starke Energie spüren."

    # say L233 gra
    old "W- Would you please... L- let me suck your... D- dick?"
    new "W- Würden Sie bitte... L- lassen Sie mich Ihren... D- Schwanz lutschen?"

    # say L235 pla
    old "(This is really in line with the plan, I should do whatever it takes.)"
    new "Das passt wirklich ins Konzept, ich sollte alles tun, was nötig ist."

    # say L236 pla
    old "S- sister Grace... I'll always do what is required to help you and to help the church's community."
    new "S- Schwester Grace... Ich werde immer tun, was nötig ist, um dir zu helfen und der Gemeinde der Kirche."

    # say L237 gra
    old "I will really appreciate your help."
    new "Ich werde Ihre Hilfe wirklich zu schätzen wissen."

    # say L251 gra
    old "Wow, I do feel much better now, kinda renewed. I'm your faithful devotee."
    new "Wow, ich fühle mich jetzt viel besser, irgendwie erneuert. Ich bin deine treue Anhängerin."

    # say L252 gra
    old "I would do everything for you as you have done everything for our community."
    new "Ich würde alles für Sie tun, genauso wie Sie alles für unsere Gemeinde getan haben."

    # say L253 pla
    old "(Oh hell! She really liked it.)"
    new "Oh Mann! Sie hat es wirklich genossen."

    # say L254 pla
    old "You don't have to... I'm glad to help sister Grace..."
    new "Du musst das nicht... Ich freue mich, helfen zu können, Schwester Grace..."

    # say L256 gra
    old "And you're so humble..."
    new "Und Sie sind so bescheiden..."

    # say L257 gra
    old "I feel a bit embarrassed now, I've kept you here for quite a long time. I'm sure you have to rest."
    new "Ich fühle mich jetzt ein bisschen verlegen, ich habe dich schon so lange hier festgehalten. Ich bin sicher, du musst dich ausruhen."

    # say L259 pla
    old "Actually, yes, I do but it's fine."
    new "Tatsächlich, ja, aber es ist okay."

    # say L260 gra
    old "Thank you so much."
    new "Vielen Dank."

    # say L261 pla
    old "Hmm ok... I- I think should go..."
    new "Hmm ok... Ich glaube, ich sollte jetzt gehen..."

    # say L262 gra
    old "Yeah, of course, I have to go as well, see you [pla]."
    new "Ja, natürlich, ich muss auch los, bis dann [pla]."

    # say L263 pla
    old "See you sister Grace."
    new "Bis dann, Schwester Grace."

    # say L280 jon
    old "I'm more tired than last time... And my back is killing me."
    new "Ich bin mehr müde als letztes Mal... Und mein Rücken tut höllisch weh."

    # say L281 gra
    old "Ohh, I'm so sorry Mrs. Jones... [pla] could you please take Mrs. Jones to her house?"
    new "Ohh, ich bin so sorry, Mrs. Jones... [pla] Könnten Sie bitte Mrs. Jones nach Hause bringen?"

    # say L282 pla
    old "Of course, I'll be happy to do it."
    new "Natürlich, ich mache das gerne."

    # say L283 jon
    old "Oh no, it's not necessary, don't worry..."
    new "Oh nein, das ist nicht nötig, machen Sie sich keine Sorgen..."

    # say L284 gra
    old "Mrs Jones, I inssist... [pla], she lives pretty close to the church."
    new "Mrs Jones, ich bestehe darauf... [pla], sie wohnt ziemlich nah an der Kirche."

    # say L285 pla
    old "Alright, I will go with you Mrs. Jones, it's not a problem."
    new "Okay, ich komme mit, Mrs. Jones, das ist kein Problem."

    # say L286 jon
    old "Hmm alright, but just this time."
    new "Hmm gut, aber nur dieses Mal."

    # say L287 pla
    old "Sure, don't worry."
    new "Klar, mach dir keine Sorgen."

    # say L288 gra
    old "Ok guys, see you tomorrow. Hope you get better, Mrs. Jones."
    new "Ok Leute, bis morgen. Ich wünsche Ihnen eine gute Besserung, Mrs. Jones."

    # say L289 jon
    old "Thank you honey."
    new "Danke, Liebling."

    # say L295 jon
    old "I'm so glad you could come with me."
    new "Ich bin so froh, dass Sie mit mir gekommen sind."

    # say L296 pla
    old "My pleasure Mrs. Jones."
    new "Mein Vergnügen, Mrs. Jones."

    # say L297 jon
    old "Come inside with me... Let me give you something to drink."
    new "Kommen Sie mit rein... Lassen Sie mich Ihnen etwas zu trinken geben."

    # say L298 pla
    old "Hmm... Yes, why not?"
    new "Hmm... Ja, warum nicht?"

    # say L304 jon
    old "By the way, I'm still surprised at how similar you're to my husband when he was young."
    new "Übrigens, ich bin immer noch überrascht, wie ähnlich Sie meinem Mann waren, als er jung war."

    # say L305 pla
    old "Oh, really? I imagine how great he was."
    new "Oh, wirklich? Ich stelle mir vor, wie toll er war."

    # say L306 jon
    old "He was... So strong and manly."
    new "Er war... So stark und männlich."

    # say L307 jon
    old "Just like you..."
    new "Genauso wie Sie..."

    # say L310 jon
    old "Hmm... I don't wanna put you in an uncomfortable position... Tell me more about yourself, we haven't talked about your spiritual development."
    new "Hmm... Ich möchte Sie nicht in eine unangenehme Situation bringen... Erzählen Sie mir mehr über sich selbst, wir haben noch nicht über Ihre spirituelle Entwicklung gesprochen."

    # say L311 pla
    old "(Actually, there is no a spiritual development...)"
    new "Eigentlich gibt es keine spirituelle Entwicklung..."

    # say L312 pla
    old "Ahhh! Well... It started- hmm, one day when I was walking and... Suddenly I felt the light, like a warm light all around my arms... Yeah, it was something like that."
    new "Ahhh! Also... Es fing an - hmm, an einem Tag, als ich spazieren ging und... Plötzlich spürte ich das Licht, wie ein warmes Licht um meine Arme... Ja, so ähnlich war es."

    # say L315 jon
    old "I asked because I want you to be my spiritual guide, I want to feel the grace of God within me. "
    new "Ich habe gefragt, weil ich Sie als meinen spirituellen Führer haben möchte, ich will die Gnade Gottes in mir spüren."

    # say L316 pla
    old "Your spiritual guide? Ok, but how do you think I could help you?"
    new "Dein spiritueller Führer? Okay, aber wie denkst du, dass ich dir helfen könnte?"

    # say L318 jon
    old "Well... The first time I saw you, I felt really impressed by your beauty. You're extremely handsome."
    new "Nun... Das erste Mal, als ich Sie sah, war ich wirklich beeindruckt von Ihrer Schönheit. Sie sind unglaublich attraktiv."

    # say L319 jon
    old "And as I told you the other day... You remind me of my great husband."
    new "Und wie ich Ihnen schon neulich sagte... Sie erinnern mich an meinen großartigen Mann."

    # say L322 jon
    old "You know, when I look at you... I see that you could be my savior as he was years ago."
    new "Sie wissen, wenn ich Sie ansehe... sehe ich, dass Sie mein Retter sein könnten, wie er es vor Jahren war."

    # say L323 pla
    old "Y- your savior? What do you mean Mrs. Jones?"
    new "Y- Ihre Retterin? Was meinen Sie damit, Mrs. Jones?"

    # say L324 jon
    old "Well, I know I look old but I have the needs of a young woman."
    new "Nun, ich weiß, ich sehe alt aus, aber ich habe die Bedürfnisse einer jungen Frau."

    # say L325 pla
    old "Needs? Which type of needs?"
    new "Bedürfnisse? Welche Art von Bedürfnissen?"

    # say L326 jon
    old "Don't you imagine which needs I have? It's really easy to guess, I'm a widow."
    new "Stellen Sie sich nicht vor, welche Bedürfnisse ich habe? Es ist wirklich leicht zu erraten, ich bin eine Witwe."

    # say L327 pla
    old "I- I... Don't k- know if I- I am thinking wrong..."
    new "I- Ich... Weiß n- nicht, ob ich f- falsch denke..."

    # say L328 jon
    old "I need a man in my life, I need to feel some adrenaline and you're like send by God... You're beautiful on the inside and outside."
    new "Ich brauche einen Mann in meinem Leben, ich brauche etwas Aufregung und Sie sind wie von Gott gesandt... Sie sind wunderschön, sowohl innen als auch außen."

    # say L330 jon
    old "You're like a saint man and I believe in you since you helped Billie... I truly believe you can guide my spiritual journey."
    new "Sie sind wie ein Heiliger und ich glaube an Sie seit Sie Billie geholfen haben... Ich glaube wirklich, dass Sie meine spirituelle Reise leiten können."

    # say L331 pla
    old "What? Me?"
    new "Was? Ich?"

    # say L332 jon
    old "Yes, you! I saw how you cured my granddaughter and I am not planning to let you go."
    new "Ja, Sie! Ich habe gesehen, wie Sie meine Enkelin geheilt haben, und ich plane nicht, Sie gehen zu lassen."

    # say L333 jon
    old "Not without a taste of what is divine... I want you to be my holy savior until I feel what Billie felt."
    new "Ohne einen Vorgeschmack von Göttlichem... Ich möchte, dass du mein heiliger Retter bist, bis ich das fühle, was Billie gefühlt hat."

    # say L335 pla
    old "I- I don't know what to say... I mean, you're such a beautiful woman but... I don't know..."
    new "Ich- ich weiß nicht, was ich sagen soll... Ich meine, du bist eine wunderschöne Frau, aber... ich weiß nicht..."

    # say L336 jon
    old "You already have the answer... Follow the will of God, you know this is the right thing to do, handsome."
    new "Sie haben die Antwort schon... Folgen Sie dem Willen Gottes, Sie wissen, dass das richtig ist, junger Mann."

    # say L337 pla
    old "(Ok, I think this can help me to do the ritual.)"
    new "Okay, ich denke, das kann mir helfen, den Ritual zu vollziehen."

    # say L338 pla
    old "Yes, if that is what you need, I'll do what is required. I'll follow God's will."
    new "Ja, wenn das ist, was du brauchst, werde ich tun, was erforderlich ist. Ich werde Gottes Willen folgen."

    # say L339 jon
    old "I have no doubts... You were sent to clean my sins like I used to do with my husband..."
    new "Ich habe keine Zweifel... Sie wurden gesandt, um meine Sünden zu reinigen, wie ich es früher mit meinem Mann getan habe..."

    # say L340 pla
    old "What would you like to do that reminds you of him?"
    new "Was möchtest du tun, das dich an ihn erinnert?"

    # say L341 jon
    old "Well, I would love to start by putting your dick inside my mouth and then brushing it with my sinful lips..."
    new "Nun, ich würde gerne damit beginnen, Ihren Schwanz in meinen Mund zu nehmen und ihn mit meinen sündhaften Lippen zu reinigen..."

    # say L342 pla
    old "... I guess God will be happy with that..."
    new "... Ich denke, Gott wird damit zufrieden sein..."

    # say L344 jon
    old "I want to have your sacred presence on my lips and keep the taste on my tongue..."
    new "Ich möchte Ihre heilige Gegenwart auf meinen Lippen spüren und den Geschmack auf meiner Zunge behalten..."

    # say L345 pla
    old "(Maybe this is getting a bit out of hand?)"
    new "Vielleicht geht das jetzt ein bisschen zu weit."

    # say L360 jon
    old "That was incredible, you're a divine presence in my life and well..."
    new "Das war unglaublich, Sie sind eine göttliche Präsenz in meinem Leben und..."

    # say L361 jon
    old "I do feel so renewed and younger now."
    new "Ich fühle mich wirklich erneuert und jünger jetzt."

    # say L362 pla
    old "Hmm... I just did what God told me to do... It was my pleasure to help you."
    new "Hmm... Ich habe nur getan, was Gott mir gesagt hat... Es war mir eine Freude, dir zu helfen."

    # say L363 jon
    old "Did you enjoy it? Isn't?"
    new "Haben Sie es genossen? Oder?"

    # say L365 jon
    old "Oh no hun! I'm sorry, I know this is just part of your holy duty... I shouldn't ask those things."
    new "Oh nein Schatz! Es tut mir leid, ich weiß, das ist nur Teil deiner heiligen Pflicht... Ich sollte solche Fragen nicht stellen."

    # say L366 pla
    old "Y- Yes Mrs. Jones, it's m- my d- duty."
    new "J- Ja, Mrs. Jones, es ist m- meine P- Pflicht."

    # say L367 pla
    old "I should go now... It's getting late."
    new "Ich sollte jetzt gehen... Es wird spät."

    # say L369 jon
    old "Go with God, handsome... And thanks again. I'll be eager for more."
    new "Gehen Sie mit Gott, junger Mann... Und danke nochmal. Ich freue mich schon auf mehr."

    # say L370 pla
    old "S- sure, goodbye Mrs. Jones."
    new "S-sicher, tschüss Mrs. Jones."

    # say L386 gra
    old "It was nice, now the church looks much better."
    new "Es war schön, jetzt sieht die Kirche viel besser aus."

    # say L387 pla
    old "It looks better now..."
    new "Es sieht jetzt besser aus..."

    # say L389 jon
    old "It's tiring to clean... "
    new "Es ist anstrengend, zu putzen..."

    # say L390 jon
    old "I'll see tomorrow... I gotta go now."
    new "Ich sehe morgen… Ich muss jetzt los."

    # say L391 pla
    old "See you Mrs. Jones..."
    new "Bis morgen, Mrs. Jones."

    # say L392 gra
    old "Take care, dear."
    new "Passen Sie auf sich auf, Liebes."

    # say L399 gra
    old "I'm glad it's just the two of us now."
    new "Ich bin froh, dass wir jetzt allein sind."

    # say L400 pla
    old "Hmm... Yeah, it's nice."
    new "Hmm... Ja, das ist schön."

    # say L401 gra
    old "[pla] I have to tell you something."
    new "[pla] Ich muss dir etwas sagen."

    # say L403 gra
    old "I think shouldn't feel so good when I'm with you... I should pay with pain, I should suffer..."
    new "Ich denke, es sollte sich nicht so gut anfühlen, wenn ich bei dir bin... Ich sollte mit Schmerz bezahlen, ich sollte leiden..."

    # say L406 gra
    old "I have never felt so much grace within me, my body feels renewed."
    new "Ich habe noch nie so viel Gnade in mir gespürt, mein Körper fühlt sich erneuert."

    # say L407 gra
    old "But I'm not sure if that is ok... A spiritual journey requires suffering and I do not feel that it's fair just to feel pleasure and purification through you."
    new "Aber ich bin mir nicht sicher, ob das in Ordnung ist... Eine spirituelle Reise verlangt Leid, und ich fühle, dass es nicht gerecht ist, nur Freude und Reinigung durch dich zu erfahren."

    # say L408 gra
    old "I need you to punish me, I have to do penance..."
    new "Ich brauche Ihre Hilfe, um Buße zu tun, ich muss Sühne leisten..."

    # say L409 pla
    old "W-what?"
    new "W-was?"

    # say L410 gra
    old "Yes, I know is what God wants and I know that with pain I will purify my soul..."
    new "Ja, ich weiß, was Gott will, und ich weiß, dass ich durch Schmerz meine Seele reinigen werde..."

    # say L412 gra
    old "But I need you to guide and help me... Since you have given me so much purification, you should be the one punishing and showing me the way..."
    new "Aber ich brauche Sie, um mich zu leiten und mir zu helfen... Da Sie mir schon so viel Reinigung geschenkt haben, sollten Sie auch diejenige sein, die mich bestraft und mir den Weg zeigt..."

    # say L414 pla
    old "A- alright... B- but, h- how?"
    new "A- okay... B- aber, w- wie?"

    # say L415 gra
    old "You're like my master. I need you to see me as your sinful slave who needs to come out of the dark side."
    new "Sie sind wie mein Meister. Ich brauche, dass Sie mich als Ihre sündige Sklavin sehen, die aus der Dunkelheit herausfinden muss."

    # say L417 gra
    old "As I get naked, I know that God will enlighten you and act through you for your guidance."
    new "Während ich mich ausziehe, weiß ich, dass Gott dich erleuchten und durch dich handeln wird, um dich zu leiten."

    # say L419 gra
    old "He'll tell you what to do..."
    new "Er wird dir sagen, was du tun sollst..."

    # say L420 gra
    old "Please! The pain and pleasure will go away but my submission and loyalty to you will remain eternally in my soul... I need it."
    new "Bitte! Der Schmerz und die Lust werden vergehen, aber meine Unterwerfung und Loyalität zu Ihnen werden ewig in meiner Seele bleiben... Ich brauche es."

    # say L421 pla
    old "If that's what you need, I'll do it."
    new "Wenn das ist, was du brauchst, werde ich es tun."

    # say L435 gra
    old "I would like to thank you... You can't imagine how important this was to me."
    new "Ich möchte mich bedanken... Du kannst dir nicht vorstellen, wie wichtig das für mich war."

    # say L436 pla
    old "I- I am glad, sister Grace."
    new "Ich- Ich bin froh, Schwester Grace."

    # say L437 pla
    old "I should go now, I have to be home soon..."
    new "Ich sollte jetzt gehen, ich muss bald zu Hause sein..."

    # say L439 gra
    old "Alright! I have to go as well. I'll be thinking of your great and massive..."
    new "Na klar! Ich muss auch los. Ich werde an deinen großen und mächtigen..."

    # say L440 gra
    old "... Spirit and soul."
    new "... Geist und Seele."

    # say L456 lin
    old "hi [pla], how are you?"
    new "Hallo [pla], wie geht es Ihnen?"

    # say L457 pla
    old "Hey! I'm fine... What about you?"
    new "Hey! Mir geht's gut... Und dir?"

    # say L458 lin
    old "I'm a bit worried [pla], you know we don't have much time to perform the ritual, you gotta hurry up!"
    new "Ich bin ein bisschen besorgt [pla], du weißt ja, wir haben nicht viel Zeit für den Ritual, du musst dich beeilen!"

    # say L459 pla
    old "I'm working on it, you don't need to worry about it, I'll do it and everything will be fine."
    new "Ich arbeite dran, du musst dich nicht sorgen, ich krieg das hin und alles wird gut."

    # say L460 lin
    old "Alright! I just wanna make sure you have everything ready because we're running out of time..."
    new "Okay! Ich will nur sichergehen, dass du alles bereit hast, weil die Zeit knapp wird..."

    # say L462 pla
    old "Hmm, okay, I'll have to rush the plans ... "
    new "Hmm, okay, ich muss die Pläne beschleunigen..."

    # say L463 lin
    old "Great, and who will be with you in the ritual? Which humans?"
    new "Super, und wer wird bei dir im Ritual dabei sein? Welche Menschen?"

    # say L464 pla
    old "Mrs. Jones and the sister Grace, they both have a lot of accumulated energy."
    new "Mrs. Jones und die Schwester Grace, sie haben beide eine Menge angesammelte Energie."

    # say L465 lin
    old "Do they know what they have to do?"
    new "Wissen sie, was sie tun müssen?"

    # say L467 pla
    old "Well, not yet... But they'll do it, I have been working on getting closer to them and it's going better than I expected."
    new "Noch nicht... Aber sie werden es tun, ich arbeite daran, ihnen näher zu kommen und es läuft besser als erwartet."

    # say L468 lin
    old "Ok, I don't wanna put more pressure on you but we have to... We do need that energy to perform the ritual."
    new "Ok, ich will dir nicht mehr Druck machen, aber wir müssen... Wir brauchen diese Energie, um den Ritual durchzuführen."

    # say L470 pla
    old "I know! In fact, I'm going to talk to them and get everything ready..."
    new "Ich weiß! Tatsächlich werde ich mit ihnen reden und alles vorbereiten..."

    # say L472 lin
    old "Ok, since you have everything almost ready for the ritual... I wanna share some energy with you."
    new "Ok, da du fast alles für den Ritual vorbereitet hast... will ich dir etwas Energie geben."

    # say L474 pla
    old "S- Sure... Let's do it!"
    new "S-Sicher... Lass es uns tun!"

    # say L475 lin
    old "All right, get naked and lie on the bed... "
    new "Okay, zieh dich aus und leg dich aufs Bett..."

    # say L489 lin
    old "It's done, go and prepare everything for the ritual! "
    new "Alles klar, geh und bereite alles für den Ritual vor!"

    # say L490 pla
    old "Got it, thanks, see you!"
    new "Alles klar, danke, bis gleich!"

    # say L491 lin
    old "See ya..."
    new "Bis später..."

    # say L492 lin
    old "The best of luck!!! I'm so excited for you..."
    new "Viel Glück!!! Ich freue mich so für dich..."

    # say L507 pla
    old "Hi sister Grace, I'm ready to start cleaning..."
    new "Hallo Schwester Grace, ich bin bereit anzufangen zu putzen..."

    # say L508 gra
    old "It's so nice to see you, hi [pla]... Actually we don't have to clean today..."
    new "Schön, Sie zu sehen, hallo [pla]... Eigentlich müssen wir heute gar nicht putzen..."

    # say L510 gra
    old "We have some issues now..."
    new "Wir haben jetzt ein paar Probleme..."

    # say L511 gra
    old "[pla]... Your help it's been exceptional, I'm so grateful with you."
    new "[pla]... Ihre Hilfe war außergewöhnlich, ich bin Ihnen so dankbar."

    # say L513 pla
    old "It's what God wants me to do... I could help even more if needed."
    new "Das ist Gottes Wille... Ich könnte noch mehr helfen, wenn nötig."

    # say L515 gra
    old "Well... Now that you mentioned it, I need you to do something..."
    new "Nun, da Sie es erwähnen, brauche ich tatsächlich Ihre Hilfe bei etwas..."

    # say L516 pla
    old "(Not punishment, please!)"
    new "(Nicht als Strafe, bitte!)"

    # say L517 pla
    old "Hmm, tell me sister Grace, what can I do for you?"
    new "Hmm, erzähl mir, Schwester Grace, was kann ich für dich tun?"

    # say L518 gra
    old "Mrs. Jones is feeling a bit sick but I can't go to see her...  I can't leave the church right now. Would you please stop by her house to see how she's doing?"
    new "Mrs. Jones fühlt sich etwas krank, aber ich kann sie nicht besuchen... Ich kann die Kirche jetzt nicht verlassen. Würden Sie bitte bei ihr vorbeischauen, um zu sehen, wie es ihr geht?"

    # say L519 pla
    old "I'm so sorry she's sick... I'll go right now."
    new "Es tut mir leid, dass es ihr schlecht geht... Ich gehe sofort."

    # say L520 gra
    old "Thanks dear [pla]... Call me if you need anything, alright!"
    new "Danke, lieber [pla]... Rufen Sie mich an, wenn Sie etwas brauchen, ja!"

    # say L524 pla
    old "(I hope she's not that sick... I'll need her for the ritual)"
    new "Ich hoffe, sie ist nicht so krank... Ich werde sie für das Ritual brauchen."

    # say L525 pla
    old "(Hmm... Actually, before I go... I should definitely talk to the nun about the ritual...)"
    new "(Hmm... Eigentlich, bevor ich gehe... Sollte ich definitiv mit der Nonne über das Ritual sprechen...)"

    # say L529 pla
    old "Sister Grace? Sorry! Hmm... I wanna tell you something before I go..."
    new "Sister Grace? Tut mir leid! Hmm... Ich wollte dir noch was sagen, bevor ich gehe..."

    # say L530 gra
    old "Yeah? Tell me [pla]... What's that?"
    new "Ja? Erzählen Sie [pla]... Was ist es?"

    # say L531 pla
    old "You said you were my faithful devotee and you would always be loyal to me, right?"
    new "Du hast gesagt, du wärst meine treue Anhängerin und würdest mir immer treu bleiben, oder?"

    # say L532 gra
    old "Yes, of course. After all you've done to me and for me, I would do anything for you."
    new "Ja, natürlich. Nach allem, was du für mich getan hast, würde ich alles für dich tun."

    # say L533 pla
    old "Well... I have to do a spiritual ritual, it's very important and it has to be done here at the church... And I would like you to help me to perform it."
    new "Na ja... Ich muss ein spirituelles Ritual durchführen, es ist sehr wichtig und es muss hier in der Kirche geschehen... Und ich würde dich gerne bitten, mir dabei zu helfen."

    # say L534 gra
    old "Yes, I'm not even gonna question you about it, as a submissive being to your will, I will always be at your service."
    new "Natürlich, ich werde es nicht einmal infrage stellen. Als unterwürfiges Wesen Ihrer Wille, ich werde immer zu Ihrem Dienst bereit sein."

    # say L535 pla
    old "Well! That's great, thanks! I knew I could count on you."
    new "Na! Das ist toll, danke! Ich wusste, dass ich mich auf dich verlassen kann."

    # say L536 pla
    old "I need you to make sure the church is empty at night, we can't allow sinful people to be here..."
    new "Ich brauche, dass du sicherstellst, dass die Kirche nachts leer ist, wir können keine sündigen Menschen hier dulden..."

    # say L538 gra
    old "I'm always obedient to God and to you."
    new "Ich bin immer gehorsam gegenüber Gott und Ihnen."

    # say L539 pla
    old "Hmm by the way... We won't be alone, one more person will join us, you already know her and I'm sure you'll do great during the ritual."
    new "Hmm, übrigens... Wir werden nicht allein sein, noch eine Person wird uns begleiten, du kennst sie schon und ich bin sicher, du wirst während des Rituals großartig sein."

    # say L540 gra
    old "One more person? Who?"
    new "Eine weitere Person? Wer?"

    # say L541 pla
    old "Trust me... You know I'm the hand of God."
    new "Vertrau mir... Du weißt, dass ich die Hand Gottes bin."

    # say L542 gra
    old "I'm so sorry!"
    new "Es tut mir so leid!"

    # say L543 pla
    old "Just make sure the place is ready..."
    new "Stell einfach sicher, dass der Ort bereit ist..."

    # say L545 gra
    old "I'll do everything to please you."
    new "Ich werde alles tun, um Sie zu befriedigen."

    # say L547 pla
    old "You're great! I'll go now since we need to know how Mrs. Jones is..."
    new "Du bist toll! Ich geh jetzt, wir müssen wissen, wie es Mrs. Jones geht..."

    # say L548 gra
    old "Go with God..."
    new "Gehen Sie mit Gott..."

    # say L553 pla
    old "Hello? Mrs. Jones? "
    new "Hallo? Mrs. Jones?"

    # say L555 pla
    old "Are you here?"
    new "Bist du da?"

    # say L556 jon
    old "Dear? [pla]?"
    new "Liebling? [pla]?"

    # say L557 jon
    old "Come here, handsome..."
    new "Kommen Sie her, Liebling..."

    # say L565 jon
    old "Hi dear, I was waiting for you..."
    new "Hallo Lieber, ich habe auf dich gewartet..."

    # say L567 pla
    old "Wow! Mrs. Jones what are you wearing?"
    new "Wow! Frau Jones, was hast du an?"

    # say L576 jon
    old "I'm so happy you're here... How are you, handsome?"
    new "Ich bin so froh, dass du hier bist... Wie geht es dir, Schatz?"

    # say L577 pla
    old "H- hi Mrs. Jones, I'm fine... But tell me how are you feeling?"
    new "H-hi Mrs. Jones, mir geht's gut... Aber erzähl mir, wie geht es dir?"

    # say L578 pla
    old "The sister Grace told me you have been quite sick..."
    new "Die Schwester Grace hat mir erzählt, dass es dir ziemlich schlecht ging..."

    # say L579 pla
    old "But you look d- different..."
    new "Aber du siehst anders aus..."

    # say L581 jon
    old "I'm fine as you can see... Maybe a bit hot ..."
    new "Ich bin gut, wie Sie sehen... Vielleicht ein bisschen heiß..."

    # say L583 jon
    old "You should enjoy what you're seeing right now... As much as I'm enjoying having you here."
    new "Sie sollten das genießen, was Sie gerade sehen... Genauso wie ich es genieße, dass Sie hier sind."

    # say L585 pla
    old "M- mrs. Jones, why are you wearing that?"
    new "M- Mrs. Jones, warum trägst du das?"

    # say L586 jon
    old "Well, You were the one bringing me this dress time ago... You made me remember my younger years with my husband..."
    new "Nun, Sie waren es, der mir dieses Kleid vor einiger Zeit gebracht hat... Sie haben mich an meine jungen Jahre mit meinem Mann erinnert..."

    # say L587 jon
    old "I used to wear a similar dress to this one and my husband used to devore me with his hands..."
    new "Ich habe früher ein ähnliches Kleid getragen und mein Mann hat mich mit seinen Händen regelrecht verschlungen..."

    # say L588 jon
    old "We liked rough sex... You know..."
    new "Wir mochten rauen Sex... Das wissen Sie doch..."

    # say L589 pla
    old "(W- What?)"
    new "W-Was?"

    # say L590 jon
    old "I forgot you're a bit shy sometimes... But perhaps you forgot I'm not and I want to have you now!"
    new "Ich habe vergessen, dass du manchmal ein bisschen schüchtern bist... Aber vielleicht hast du vergessen, dass ich das nicht bin und ich dich jetzt will!"

    # say L593 jon
    old "I'll take the initiative... I know you like when your cock is between my lips."
    new "Ich werde die Initiative ergreifen... Ich weiß, dass dir gefällt, wenn dein Schwanz zwischen meinen Lippen ist."

    # say L594 jon
    old "And I know you're getting hard as fuck right now... Just let me take off your pants, handsome."
    new "Und ich weiß, dass Sie jetzt hart wie Stein sind... Lassen Sie mich einfach Ihre Hose ausziehen, Schönheit."

    # say L608 jon
    old "I'm feeling much better now... I should say thank you..."
    new "Ich fühle mich viel besser jetzt... Ich sollte mich bedanken..."

    # say L609 pla
    old "(Hmm sure...) I hope you're much better now."
    new "Hmm sicher... Ich hoffe, es geht dir jetzt viel besser."

    # say L610 jon
    old "Totally hun... Thanks for passing by..."
    new "Totaler Schatz... Danke, dass du vorbeigeschaut hast..."

    # say L611 pla
    old "Hmm... Mrs. Jones, I actually wanted to ask you a favor..."
    new "Hmm... Mrs. Jones, ich wollte dich actually um einen Gefallen bitten..."

    # say L613 jon
    old "A favor? Sure, anything for you, love..."
    new "Einen Gefallen? Natürlich, alles für Sie, Liebling..."

    # say L614 pla
    old "I'll have to perform a ritual at the church to clean the energies..."
    new "Ich muss im Kirchenritual die Energien reinigen..."

    # say L615 pla
    old "And since we're closer now and you know that I've such a spiritual development, I would like you to be part of that ritual."
    new "Und da wir uns jetzt näher sind und du weißt, dass ich mich spirituell weiterentwickelt habe, würde ich dich gerne bei diesem Ritual dabeihaben."

    # say L616 pla
    old "Sister Grace would be there, you and me... Would you help me? "
    new "Schwester Grace wäre da, du und ich... Würdest du mir helfen?"

    # say L618 jon
    old "You've done so much for me, hun... I already told you, I would do whatever you ask me to do. You can count on me for it."
    new "Sie haben schon so viel für mich getan, Schatz... Ich habe Ihnen ja schon gesagt, ich werde tun, was Sie von mir verlangen. Sie können sich auf mich verlassen."

    # say L619 pla
    old "Thanks Mrs. Jones, I didn't expect less from you..."
    new "Danke, Mrs. Jones, ich habe nichts anderes von Ihnen erwartet."

    # say L620 pla
    old "I'll see at the church, now I should go..."
    new "Dann sehen wir uns in der Kirche, jetzt sollte ich gehen..."

    # say L621 jon
    old "See you there, handsome."
    new "Bis dahin, junger Mann."

    # say L637 pla
    old "Ok... Today is the ritual day!"
    new "Ok... Heute ist der Ritualtag!"

    # say L638 lin
    old "And you'll be great, we count on you..."
    new "Und du wirst großartig sein, wir zählen auf dich..."

    # say L639 pla
    old "I know Linett, I've everything ready and well... It'll be fine."
    new "Ich weiß, Linett, ich hab alles vorbereitet und... es wird gut gehen."

    # say L640 lin
    old "[pla] make sure you have sex with both, the nun and the older woman, it's extremely important to get energy from both. I'll be there with you..."
    new "[pla] stell sicher, dass du mit beiden, der Nonne und der älteren Frau, fickst. Es ist extrem wichtig, die Energie von beiden zu bekommen. Ich werde bei dir sein..."

    # say L641 pla
    old "Great! I didn't know you were coming with me..."
    new "Super! Das wusste ich nicht, dass du mitkommst..."

    # say L644 lin
    old "So are you ready... We gotta start the ritual now."
    new "Dann bist du bereit... Wir müssen jetzt mit dem Ritual beginnen."

    # say L645 pla
    old "Yeah... Let's do it!"
    new "Ja... Lass es uns tun!"

    # say L651 pla
    old "Oh, they are back there..."
    new "Oh, die sind schon da..."

    # say L652 pla
    old "Great! It's time to start the ritual."
    new "Großartig! Es ist Zeit, das Ritual zu beginnen."

    # say L662 pla
    old "Mrs. Jones, sister Grace... Hi, I'm glad you both are here..."
    new "Frau Jones, Schwester Grace... Hallo, ich freue mich, dass ihr beide hier seid."

    # say L663 jon
    old "Good night hun."
    new "Gute Nacht, Liebling."

    # say L664 gra
    old "Hi [pla], it's a pleasure to be here with you."
    new "Hallo [pla], es ist eine Freude, hier bei Ihnen zu sein."

    # say L671 pla
    old "Billie? W- What are you doing here?"
    new "Billie? W- Was machst du hier?"

    # say L672 jon
    old "Oh, I invited her... As you said you are going to clean the bad energies I thought it would be a great idea to invite Billie..."
    new "Oh, ich habe sie eingeladen... Da du gesagt hast, du willst die schlechten Energien bannen, dachte ich, es wäre eine tolle Idee, Billie einzuladen..."

    # say L673 pla
    old "W- what? B- but she doesn't know what we are going to have se- ... An important ritual..."
    new "W- was? A- aber sie weiß doch gar nicht, was wir vorhaben... E- ein wichtiges Ritual..."

    # say L674 jon
    old "Oh, don't worry hun, I already explained it to her, she was really worried about her sexorcis-... I mean exorcism."
    new "Oh, machen Sie sich keine Sorgen, ich habe es ihr schon erklärt, sie war echt besorgt wegen ihrem Sexorzis-... ich meine Exorzismus."

    # say L675 bil
    old "I wanted to come... I never thought that I could be religious having sex."
    new "Ich wollte kommen... Ich habe nie gedacht, dass ich religiös sein könnte, wenn ich Sex habe."

    # say L676 bil
    old "And I wanna thank you for what you did for me as well..."
    new "Und ich möchte mich auch bei Ihnen bedanken für das, was Sie für mich getan haben..."

    # say L677 pla
    old "Hmm alright... I- I see..."
    new "Hmm okay... I- Ich sehe das..."

    # say L678 lin
    old "{i}Pstt... [pla], we are running out of time... Start now!{/i}"
    new "{i}Pstt... [pla], wir haben nicht mehr viel Zeit... Fang jetzt an!{/i}"

    # say L679 pla
    old "(Oh shit, she is right.)"
    new "Oh Scheiße, sie hat recht."

    # say L680 pla
    old "Well ladies, this is a spiritual ritual in which we all will do a transfer of spirituality among us..."
    new "Na dann, Ladys, das ist ein spiritueller Ritual, bei dem wir alle unsere Spiritualität untereinander übertragen werden..."

    # say L681 pla
    old "I've noticed how spiritual you all are and that's why I've chosen you for this."
    new "Ich habe bemerkt, wie spirituell ihr alle seid, deshalb habe ich euch für dies ausgewählt."

    # say L682 pla
    old "We'll have to open our hearts to God and give to each other what's required..."
    new "Wir müssen unsere Herzen zu Gott öffnen und einander geben, was erforderlich ist..."

    # say L683 jon
    old "I can't wait to do it... You have all of me for this..."
    new "Ich freue mich darauf, es zu tun... Sie haben von mir alles, was Sie brauchen..."

    # say L684 gra
    old "I agree with Mrs. Jones..."
    new "Ich stimme Mrs. Jones zu..."

    # say L685 pla
    old "The better we do it, the better our lives will be in the eyes of God..."
    new "Je besser wir es machen, desto besser wird unser Leben in Gottes Augen sein..."

    # say L686 pla
    old "Put all your faith on me and I'll guide through the ritual, it's all about spirituality and love."
    new "Setze dein Vertrauen in mich und ich werde dich durch das Ritual führen, es geht alles um Spiritualität und Liebe."

    # say L687 bil
    old "Can't we just start?"
    new "Können wir nicht einfach anfangen?"

    # say L688 pla
    old "Right, can you turn on the lights before we start?"
    new "Klar, kannst du das Licht anmachen, bevor wir anfangen?"

    # say L696 bil
    old "Let's start with the sex!"
    new "Lass uns mit dem Sex anfangen!"

    # say L698 jon
    old "Oh dear please calm down..."
    new "Oh je, bitte beruhigen Sie sich..."

    # say L711 lin
    old "Good job! Now it's my turn!"
    new "Gute Arbeit! Jetzt bin ich dran!"

    # say L734 pla
    old "W- Well... Thank you... It was an excellent ritual, you all did good and I'm very thankful..."
    new "W-Wow... Danke... Es war ein ausgezeichnetes Ritual, ihr habt alle gut gemacht und ich bin sehr dankbar..."

    # say L735 jon
    old "I'm happy we got to help you and you helped us during this ritual..."
    new "Ich freue mich, dass wir dir helfen durften und du uns bei diesem Ritual unterstützt hast..."

    # say L736 bil
    old "It was cool..."
    new "Es war cool..."

    # say L737 gra
    old "I feel totally new... Totally different, thanks so much [pla]..."
    new "Ich fühle mich total neu... Total anders, vielen Dank [pla]..."

    # say L738 pla
    old "I'm glad..."
    new "Ich freue mich, dass es dir so gut geht..."

    # say L739 pla
    old "I have to go now... "
    new "Ich muss jetzt los..."

    # say L741 gra
    old "See you [pla], I need some rest after this..."
    new "Bis dann [pla], ich brauche jetzt etwas Ruhe nach alldem..."

    # say L742 jon
    old "Goodbye, dear... See you!"
    new "Auf Wiedersehen, lieber... Bis bald!"

    # say L749 lin
    old "Hi... How are you feeling?"
    new "Hallo... Wie fühlen Sie sich?"

    # say L750 pla
    old "I'm happy, we did it!"
    new "Ich bin glücklich, wir haben es geschafft!"

    # say L751 lin
    old "Well... It didn't work..."
    new "Na ja... Es hat nicht funktioniert..."

    # say L752 pla
    old "What? Why? What happened?"
    new "Was? Warum? Was ist passiert?"

    # say L753 lin
    old "It simply didn't work... It happens sometimes, it's a complex ritual and well... This time it didn't work..."
    new "Es hat einfach nicht funktioniert... Manchmal passiert das, es ist ein komplexer Ritual und... Dieses Mal hat es nicht geklappt..."

    # say L754 pla
    old "Really? Now what?"
    new "Wirklich? Und was jetzt?"

    # say L755 lin
    old "There is nothing we can do now... We have to wait until christmas, there is no other way..."
    new "Da können wir jetzt nichts mehr machen... Wir müssen bis Weihnachten warten, es gibt keine andere Möglichkeit..."

    # say L756 lin
    old "During christmas there is a load of human energy all around and that's the only chance we will have..."
    new "Während der Weihnachtszeit gibt es eine Menge menschlicher Energie, und das ist unsere einzige Chance..."

    # say L757 lin
    old "For now there is nothing we can do..."
    new "Im Moment können wir nichts tun..."

    # say L759 pla
    old "I see... We'll try for Christmas..."
    new "Ich sehe... Wir werden es zu Weihnachten versuchen..."


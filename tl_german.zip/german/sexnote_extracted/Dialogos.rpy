# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Dialogos.rpy
translate german strings:

    # say L9 pla
    old "Another day..."
    new "Noch ein Tag..."

    # say L10 pla
    old "Let’s just get through classes and survive."
    new "Lass uns einfach die Kurse überstehen und überleben."

    # say L11 pla
    old "Hope nothing weird happens today."
    new "Hoffe, heute passiert nichts Seltsames."

    # say L16 pla
    old "Hmm... What's that sound coming down the hall?"
    new "Hmm... Was ist das für ein Geräusch, das da den Gang runterkommt?"

    # narrator L17 
    old "{i}Now every step just pulls me down...{/i}"
    new "{i}Jetzt zieht jeder Schritt mich nach unten...{/i}"

    # say L18 pla
    old "({i}Sounds like music, but faint. Someone’s phone playing a song?{/i})"
    new "{i}Klingt wie Musik, aber leise. Vielleicht spielt jemand ein Lied auf dem Handy?{/i}"

    # say L20 pla
    old "No way, it’s a voice. Singing softly... from the girls’ bathroom?"
    new "Keine Chance, das ist eine Stimme. Leise singend... aus der Mädchen-Toilette?"

    # say L22 pla
    old "({i}That melody’s got so much heart. Who’s in there?{/i})"
    new "{i}Diese Melodie hat so viel Herz. Wer ist da drin?{/i}"

    # say L26 pla
    old "Hey [bil]... that singing? Was that you?"
    new "Hey [bil]... das Singen? Warst das du?"

    # say L27 bil
    old "Heh, singing? Nah, probably just music from next classroom."
    new "Heh, singen? Nein, wahrscheinlich nur Musik aus dem Nebenraum."

    # say L28 pla
    old "Uhh, music? It sounded like someone singing, like right here."
    new "Uhh, Musik? Es klang, als würde jemand hier singen."

    # say L30 bil
    old "Or someone’s phone blasting some old track. This place is a noise fest."
    new "Oder jemandes Handy spielt einen alten Track. Dieser Ort ist ein echtes Geräuschchaos."

    # say L31 pla
    old "({i}She’s dodging it hard. But that voice was totally hers.{/i})"
    new "{i}Sie weicht es total aus. Aber diese Stimme war definitiv ihre.{/i}"

    # say L32 pla
    old "Come on, [bil], it was too good to be just an echo."
    new "Komm schon, [bil], es war zu gut, um nur ein Echo zu sein."

    # say L33 bil
    old "Too good? Dude, if I was singing, I’d be viral already. Blame the vents."
    new "Zu gut? Alter, wenn ich gesungen hätte, wäre ich schon viral. Schuld sind die Lüftungsschächte."

    # say L34 pla
    old "The vents? For real? It had this raw emotion..."
    new "Die Lüftungsschächte? Ernsthaft? Es hatte diese echte Emotion..."

    # say L35 bil
    old "Emotional vents, then. Case closed. Catch you later, [pla]."
    new "Emotionale Lüftungsschächte also. Fall gelöst. Bis später, [pla]."

    # say L37 pla
    old "Whoa, her notebook just dropped."
    new "Wow, ihr Notizbuch ist gerade runtergefallen."

    # say L39 pla
    old "What’s this? Doodles, messy scratches... hold up, are these lyrics?"
    new "Was ist das? Kritzel, verwischte Striche... Moment mal, sind das Liedtexte?"

    # say L40 pla
    old "Music notes scribbled everywhere. ‘Faded echoes, songs we lost...’"
    new "Noten überall gekritzelt. ‘Verblasste Echos, Lieder, die wir verloren...’"

    # say L41 pla
    old "({i}This matches the melody perfectly. It was definitely her.{/i})"
    new "{i}Das passt perfekt zu der Melodie. Es war definitiv sie. {/i}"

    # say L42 pla
    old "Why deny it? Someone with this talent..."
    new "Warum leugnen? Jemand mit diesem Talent..."

    # say L43 pla
    old "({i}Hiding something this raw doesn’t make sense. I’ll take it to her place.{/i})"
    new "{i}So etwas Rohes zu verstecken, ergibt keinen Sinn. Ich bringe es zu ihr nach Hause. {/i}"

    # say L44 pla
    old "Yeah, that’s the right call."
    new "Ja, das ist die richtige Entscheidung."

    # say L50 jon
    old "Oh, [pla]! What a treat to see you, honey!"
    new "Oh, [pla]! Was für eine Freude, dich zu sehen, Liebling!"

    # say L51 pla
    old "Hey, Mrs. Jones. Sorry for dropping by unannounced."
    new "Hey, Mrs. Jones. Tut mir leid, dass ich so unangemeldet vorbeikomme."

    # say L52 jon
    old "Nonsense, you’re always welcome. How’s school going?"
    new "Quatsch, Sie sind immer willkommen. Wie läuft die Schule?"

    # say L53 pla
    old "It’s alright. Keeps me on my toes."
    new "Alles gut. Hält mich auf Trab."

    # say L54 jon
    old "Oh, you’re always so busy! [bil]’s out with friends, but what brings you by?"
    new "Oh, Sie sind immer so beschäftigt! [bil] ist mit Freunden unterwegs, aber was führt Sie hierher?"

    # say L55 pla
    old "Well, she dropped her notebook at school. Figured it’s important."
    new "Na ja, sie hat ihr Notizbuch in der Schule liegen lassen. Dachte, es ist wichtig."

    # say L56 jon
    old "Let me see... Oh, these sketches and notes. Takes me way back."
    new "Lassen Sie mich sehen... Oh, diese Skizzen und Notizen. Bringt mich zurück in die Vergangenheit."

    # say L57 pla
    old "Way back? To what, if it’s okay to ask?"
    new "Wohin, wenn ich fragen darf?"

    # say L58 jon
    old "To when she was little. Her parents... they used to sing with her every night."
    new "Zur Zeit, als sie noch klein war. Ihre Eltern... sie haben jeden Abend mit ihr gesungen."

    # say L59 pla
    old "({i}Singing together? That’s so sweet.{/i})"
    new "{i}Gemeinsam singen? Das ist ja süß.{/i}"

    # say L60 pla
    old "I can imagine that. Must’ve been her whole world."
    new "Ich kann mir das vorstellen. Das muss ihre ganze Welt gewesen sein."

    # say L61 jon
    old "It was. Her dad with his old guitar, her mom humming along. It lit her up."
    new "Es war so. Ihr Vater mit seiner alten Gitarre, ihre Mutter, die mit summte. Das hat sie zum Leuchten gebracht."

    # say L62 pla
    old "({i}So that’s where her gift comes from.{/i})"
    new "{i}Dann kommt ihr Talent also von da.{/i}"

    # say L63 pla
    old "I heard her today. It really hit me deep."
    new "Ich hab sie heute gehört. Es hat mich echt tief berührt."

    # say L64 jon
    old "Oh really? You heard her singing today?"
    new "Oh wirklich? Sie haben sie heute singen gehört?"

    # say L65 jon
    old "Well, she used to sing all the time. It was such a lovely thing to hear... but after her parents passed, everything changed for her."
    new "Nun, sie sang früher ständig. Es war wunderschön zu hören... aber nachdem ihre Eltern gestorben waren, hat sich alles für sie geändert."

    # say L66 pla
    old "Oh, I didn't know? I’m so sorry, Mrs. Jones. That sounds so tough."
    new "Oh, das wusste ich nicht? Es tut mir sehr leid, Mrs. Jones. Das klingt ja schrecklich."

    # say L67 jon
    old "It was a long time ago... A car accident. Took them both in an instant."
    new "Das war lange her... Ein Autounfall. Hat sie beide im Nu dahingerafft."

    # say L68 pla
    old "({i}Gone just like that. No wonder it shook her.{/i})"
    new "{i}Einfach so weg. Kein Wunder, dass es sie erschüttert hat.{/i}"

    # say L69 pla
    old "That’s so sad. How did [bil] get through it?"
    new "Das ist ja schrecklich. Wie hat [bil] das nur durchgestanden?"

    # say L70 jon
    old "Faith carried us. But for her, singing turned into pain."
    new "Der Glaube hat uns getragen. Aber für sie wurde das Singen zu Schmerz."

    # say L71 jon
    old "Every note brought their voices back. First happy, then just the hurt."
    new "Jede Note brachte ihre Stimmen zurück. Zuerst fröhlich, dann nur noch der Schmerz."

    # say L72 pla
    old "So it stopped being joy. More like ripping open old wounds?"
    new "Dann war es keine Freude mehr. Eher wie das Aufriss alte Wunden?"

    # say L73 jon
    old "Exactly. She shut it down, like flipping a switch."
    new "Genau. Sie hat es abgestellt, als würde sie einen Schalter umlegen."

    # say L74 pla
    old "({i}That cool act she pulls... it’s gotta be shielding all this.{/i})"
    new "{i}Diese coole Fassade, die sie aufsetzt... sie muss all das hier abwehren.{/i}"

    # say L75 pla
    old "I get why she’d hide something tied to them."
    new "Ich verstehe, warum sie etwas verbirgt, das mit ihnen zu tun hat."

    # say L76 jon
    old "You see her heart, [pla]. Not many do."
    new "Sie sehen ihr Herz, [pla]. Nicht viele tun das."

    # say L77 pla
    old "Just wish it didn’t weigh her down like that. Feels so unfair."
    new "Wünschte, es würde sie nicht so belasten. Das ist echt unfair."

    # say L78 jon
    old "Life’s not always kind, honey. But you’re sweet to care."
    new "Das Leben ist nicht immer freundlich, Schatz. Aber es ist lieb von dir, dass du dich sorgst."

    # say L79 pla
    old "I’ll leave the notebook. Tell her I didn’t snoop too much."
    new "Ich lass das Notizbuch da. Sag ihr, ich hab nicht allzu viel herumgeschnüffelt."

    # say L80 jon
    old "Of course, dear. Safe walk home now."
    new "Natürlich, lieber. Passen Sie auf dem Heimweg auf."

    # say L81 pla
    old "Thanks, Mrs. Jones. See you soon."
    new "Danke, Mrs. Jones. Bis bald."

    # say L87 pla
    old "Man... what a day."
    new "Mann... was für ein Tag."

    # say L88 pla
    old "So that’s why she acts like nothing touches her."
    new "Deshalb wirkt sie, als könnte nichts sie erschüttern."

    # say L89 pla
    old "Losing both parents at once... and singing was the last thing connecting her to them."
    new "Beide Eltern auf einmal zu verlieren... und Singen war die letzte Verbindung zu ihnen."

    # say L90 pla
    old "Now I get why she kept dodging the whole thing. Every note probably feels like losing them again."
    new "Jetzt verstehe ich, warum sie das ganze Ding immer ausgewichen ist. Jede Note fühlt sich wahrscheinlich an wie ein neuer Verlust."

    # say L91 pla
    old "She’s not hiding because she’s shy. She’s hiding because it hurts too much to let it out."
    new "Sie versteckt sich nicht, weil sie schüchtern ist. Sie versteckt sich, weil es zu wehtut, es rauszulassen."

    # say L92 pla
    old "That cool girl armor isn’t just attitude. It’s survival."
    new "Diese coole Girl-Rüstung ist nicht nur Show. Es ist Überleben."

    # say L93 pla
    old "But that voice... It’s still in there. And it’s beautiful."
    new "Aber diese Stimme... Sie ist immer noch da drin. Und sie ist wunderschön."

    # say L94 pla
    old "If there’s even a tiny chance something could help her feel that joy again... I have to try."
    new "Wenn es auch nur die geringste Chance gibt, dass etwas ihr dieses Glück wieder bringen könnte... muss ich es versuchen."

    # say L95 pla
    old "I don’t know how yet, but I’m not letting her carry this alone."
    new "Ich weiß noch nicht wie, aber ich lasse sie das nicht allein tragen."

    # say L104 pla
    old "({i}Still can’t get [bil]’s voice out of my head. That song was something else.{/i})"
    new "{i}Kann immer noch [bil]s Stimme nicht aus dem Kopf kriegen. Dieses Lied war was Besonderes.{/i}"

    # say L105 pla
    old "Hold up, what’s this flyer on the wall?"
    new "Warte mal, was ist das für ein Flyer an der Wand?"

    # say L107 pla
    old "School’s doing a music contest? Sign-ups are open..."
    new "Die Schule macht einen Musikwettbewerb? Anmeldungen sind offen..."

    # say L108 pla
    old "Wait. This is exactly what [bil] needs right now."
    new "Warte. Das ist genau das, was [bil] jetzt braucht."

    # say L111 pla
    old "({i}She’s literally going to murder me for signing her up without asking.{/i})"
    new "({i}Sie wird mich buchstäblich umbringen, weil ich sie ohne zu fragen angemeldet habe. {/i})"

    # say L112 pla
    old "({i}Like, straight-up bury me in the backyard. But it’s worth the risk, right?{/i})"
    new "{i}So, direkt im Garten begraben. Aber es lohnt sich, oder?{/i}"

    # say L113 pla
    old "Gotta do it."
    new "Muss es tun."

    # say L119 pla
    old "Hi, are you Ms. Beylaine?"
    new "Hi, bist du Ms. Beylaine?"

    # say L120 bey
    old "That’s me, honey! Come in, come in."
    new "Das bin ich, Schatz! Komm rein, komm rein."

    # say L121 pla
    old "I saw the flyer about the music contest. Looks really cool."
    new "Ich hab den Flyer zum Musikwettbewerb gesehen. Sieht echt cool aus."

    # say L122 bey
    old "Cool? Baby, it’s about to be everything."
    new "Cool? Baby, das wird der Hammer."

    # say L123 pla
    old "I wanna sign up. Me and my friend [bil]."
    new "Ich will mich anmelden. Mein Freund [bil] und ich."

    # say L124 bey
    old "Love the duo energy! Tell me about you two."
    new "Liebe die Duo-Energie! Erzähl mir mehr über euch beide."

    # say L125 pla
    old "Well, she’s got an insane voice, but she keeps it hidden. I thought this might be good for her."
    new "Na ja, sie hat eine unglaubliche Stimme, aber sie versteckt sie. Ich dachte, das hier könnte gut für sie sein."

    # say L126 bey
    old "Hidden talent? That’s my favorite kind."
    new "Verstecktes Talent? Das ist mein Lieblingstyp."

    # say L127 bey
    old "What about you, handsome? What do you bring to the stage?"
    new "Was ist mit dir, Schönling? Was bringst du auf die Bühne?"

    # say L128 pla
    old "Uhh... honestly? Nothing. I can’t sing, can’t play. Zero."
    new "Uhh... ehrlich gesagt? Nichts. Ich kann nicht singen, kann nicht spielen. Null."

    # say L129 bey
    old "Zero today doesn’t mean zero tomorrow."
    new "Null heute heißt noch lange nicht Null morgen."

    # say L130 bey
    old "Don't worry, we’re doing practice sessions first. Technique, composition, stage fire. I pull the best out of everybody."
    new "Mach dir keine Sorgen, wir machen erst Übungssessions. Technik, Komposition, Bühnenpräsenz. Ich hole das Beste aus jedem raus."

    # say L131 pla
    old "So we get actual coaching before the contest?"
    new "Dann kriegen wir also richtig Coaching, bevor der Wettbewerb losgeht?"

    # say L132 bey
    old "Exactly. I don’t just throw y’all to the wolves. We build it together."
    new "Genau. Ich werfe euch nicht einfach den Wölfen zum Fraß vor. Wir bauen es gemeinsam auf."

    # say L133 pla
    old "Oh, that sounds perfect, actually."
    new "Oh, das klingt perfekt, ehrlich gesagt."

    # say L134 bey
    old "Ok, to start, I just need you to fill out a couple forms for you and your friend. After that, I’ll reach out to schedule the audition."
    new "Okay, zum Anfang brauch ich nur, dass du ein paar Formulare für dich und deinen Freund ausfüllst. Danach melde ich mich, um den Termin für die Vorsicht zu vereinbaren."

    # say L135 pla
    old "Got it, thanks, Ms. Beylaine. This means a lot."
    new "Alles klar, danke, Ms. Beylaine. Das bedeutet mir viel."

    # say L136 bey
    old "Call me Bey. And tell your friend: when she’s ready to own that stage, I got her."
    new "Nenn mich Bey. Und sag deiner Freundin: wenn sie bereit ist, die Bühne zu erobern, hab ich sie im Griff."

    # say L142 pla
    old "({i}Best idea I’ve ever had.{/i})"
    new "({i}Die beste Idee, die ich je hatte.{/i})"

    # say L154 pla
    old "Hey [bil]! You’re not gonna believe what I just did!"
    new "Hey [bil]! Du wirst es nicht glauben, was ich gerade gemacht habe!"

    # say L155 bil
    old "Hmm, what now?"
    new "Hmm, was jetzt?"

    # say L156 pla
    old "I signed us up for the music contest!"
    new "Ich hab uns für den Musikwettbewerb angemeldet!"

    # say L157 bil
    old "You... did what?"
    new "Du... hast was getan?"

    # say L158 pla
    old "Yeah! They’ve got coaching and everything. It’s perfect!"
    new "Klar! Sie bieten sogar Coaching. Das ist perfekt!"

    # say L159 bil
    old "You signed me up. Without even asking."
    new "Du hast mich angemeldet. Ohne mich überhaupt zu fragen."

    # say L160 pla
    old "I know, I know, it sounds crazy, but just hear me out—"
    new "Ich weiß, ich weiß, das klingt verrückt, aber hör mir einfach zu –"

    # say L161 bil
    old "No. You don’t get to decide that for me, [pla]."
    new "Nein. Du hast da keine Entscheidung zu treffen, [pla]."

    # say L162 pla
    old "No, no, it's just that you have this insane voice. Like, people need to hear it."
    new "Nein, nein, es ist nur so, dass du diese verrückte Stimme hast. Die Leute müssen sie hören."

    # say L163 bil
    old "That’s not the point. It’s my thing, not yours."
    new "Das ist nicht der Punkt. Es ist meine Sache, nicht deine."

    # say L164 pla
    old "Come on, it’s just a contest! You’d crush everyone."
    new "Komm schon, es ist doch nur ein Wettbewerb! Du würdest alle in den Schatten stellen."

    # say L165 bil
    old "Stop acting like you know what’s best for me."
    new "Hör auf, so zu tun, als wüsstest du, was für mich am besten ist."

    # say L166 pla
    old "I’m not! I just... saw the flyer and thought 'this is made for [bil]'."
    new "Ich tu's nicht! Ich hab' nur den Flyer gesehen und gedacht, das ist genau für [bil]."

    # say L167 bil
    old "Well, you thought wrong."
    new "Na, da hast du dich wohl geirrt."

    # say L170 pla
    old "Wait, your grandma told me how much you used to love singing with your parents—"
    new "Warte, deine Oma hat mir erzählt, wie sehr du früher mit deinen Eltern gesungen hast –"

    # say L174 pla
    old "I- I- I’m sorry!"
    new "I- I- Es tut mir leid!"

    # say L175 pla
    old "I- I didn’t mean it l- like that, I- I swear!"
    new "Ich- Ich hab das nicht so gemeint, ehrlich!"

    # say L176 bil
    old "You have no idea what you’re talking about."
    new "Du hast keine Ahnung, wovon du redest."

    # say L177 pla
    old "I know! I messed up, okay? I’m really sorry."
    new "Ich weiß! Ich hab’s vermasselt, okay? Es tut mir echt leid."

    # say L178 pla
    old "I just... I thought it would help. That’s all."
    new "Ich hab nur... Ich dachte, es würde helfen. Ehrlich."

    # say L179 bil
    old "You don’t get to dig into my life like that!"
    new "Du hast kein Recht, dich so in mein Leben einzumischen!"

    # say L180 pla
    old "You’re right. I overstepped. Big time."
    new "Du hast recht. Ich bin zu weit gegangen. Vollkommen."

    # say L182 pla
    old "I- I’m sorry, [bil]. Seriously."
    new "Ich- Ich bin sorry, [bil]. Ehrlich."

    # say L183 bil
    old "Tsk..."
    new "Pfft..."

    # say L185 bil
    old "Mind your own business, [pla]. This isn’t your thing to fix."
    new "Kümmer dich um deinen eigenen Kram, [pla]. Das ist nicht deine Sache, die du regeln musst."

    # say L186 pla
    old "I get it. But your voice... it’s too good to stay hidden."
    new "Verstehe. Aber deine Stimme... sie ist zu gut, um verborgen zu bleiben."

    # say L187 bil
    old "Why do you even care?"
    new "Warum interessiert dich das überhaupt?"

    # say L188 pla
    old "Because I hate seeing you hold back something you’re amazing at."
    new "Weil ich es hasse, dich etwas zurückhalten zu sehen, bei dem du unglaublich gut bist."

    # say L189 bil
    old "It’s not that simple."
    new "Es ist nicht so einfach."

    # say L190 pla
    old "I know it’s not. But just one practice. One."
    new "Ich weiß, dass es das nicht ist. Aber nur ein Probelauf. Einer."

    # say L191 bil
    old "You’re seriously not dropping this?"
    new "Du gibst das echt nicht auf?"

    # say L192 pla
    old "I can’t. Not when I know how much talent you have."
    new "Ich kann nicht. Nicht, wenn ich weiß, wie viel Talent du hast."

    # say L193 bil
    old "You’re impossible."
    new "Du bist unmöglich."

    # say L194 pla
    old "Please. One session. If it sucks, we never talk about it again."
    new "Bitte. Eine Session. Wenn es Mist ist, reden wir nie wieder drüber."

    # say L196 bil
    old "You’re gonna keep bugging me until I say yes, aren’t you?"
    new "Du wirst mich wohl so lange nerven, bis ich Ja sage, oder?"

    # say L197 pla
    old "Uhh... pretty much."
    new "Uhh... ziemlich genau."

    # say L198 bil
    old "Ughh... fine. One practice. Just to shut you up."
    new "Ughh... gut. Ein Probelauf. Nur, um dich ruhig zu stellen."

    # say L199 bil
    old "But that’s it. And after that, we’re done talking about it. Got it? End of discussion."
    new "Aber das ist's. Und danach reden wir nicht mehr drüber. Kapiert? Ende der Diskussion."

    # say L200 pla
    old "Deal! Thank you!"
    new "Abgemacht! Danke!"

    # say L201 bil
    old "Don’t thank me yet."
    new "Noch nicht danke."

    # say L202 bil
    old "And don’t you ever ever bring up my parents again. You hear me?"
    new "Und erwähne meine Eltern nie wieder. Hast du mich verstanden?"

    # say L203 pla
    old "Uhh, yeah, got it..."
    new "Uhh, ja, hab's kapiert..."

    # say L205 pla
    old "Phew.... Well, she didn’t kill me... I’ll call that a win."
    new "Phew.... Na ja, sie hat mich nicht umgebracht... Ich nenne das mal einen Sieg."

    # say L206 pla
    old "One practice. That’s all I needed."
    new "Eine Probe. Das war alles, was ich gebraucht habe."

    # say L216 pla
    old "The audition. The contest thing. Oh man, [bil] better not bail on me."
    new "Die Vorsicht. Das Wettbewerbsding. Oh Mann, [bil] darf mich jetzt nicht im Stich lassen."

    # say L217 pla
    old "She said she’d show... right?"
    new "Sie hat gesagt, dass sie... zeigen würde, oder?"

    # say L218 pla
    old "I have zero clue what I’m doing up there, but it’s for her. Gotta move."
    new "Ich hab keine Ahnung, was ich da oben mache, aber es ist für sie. Muss los."

    # say L224 pla
    old "There you are! Ready for this?"
    new "Da bist du ja! Bereit dafür?"

    # say L225 bil
    old "Ready? I’m here because you wouldn’t shut up about it."
    new "Bereit? Ich bin hier, weil du nicht aufgehört hast, davon zu reden."

    # say L226 pla
    old "Come on, it’s gonna be fine. Just one showcase."
    new "Komm schon, es wird super. Nur eine Vorstellung."

    # say L227 bil
    old "Yeah, yeah. Let’s get this over with so I can go back to my life."
    new "Ja, ja. Lass uns das hinter uns bringen, dann kann ich wieder zu meinem Leben zurück."

    # say L228 pla
    old "You’re gonna kill it, [bil]. I know it."
    new "Du wirst es rocken, [bil]. Ich weiß es."

    # say L229 bil
    old "Save the pep talk, [pla]. I’m doing this to make you stop bugging me, remember?"
    new "Spar dir die Aufmunterung, [pla]. Ich mach das, damit du mich endlich in Ruhe lässt, okay?"

    # say L230 pla
    old "Fair enough."
    new "In Ordnung."

    # say L232 bil
    old "Whatever. Let's go I don't have all day."
    new "Was immer. Lass uns gehen, ich hab nicht den ganzen Tag Zeit."

    # say L233 pla
    old "Sure, let's go."
    new "Klar, lass uns gehen."

    # say L240 bey
    old "I’m Beylaine, but you can call me Bey, and I’m the teacher who’s going to get you ready to take this year’s Music Contest crown."
    new "Ich bin Beylaine, aber du kannst mich Bey nennen, und ich bin der Lehrer, der dich bereit machen wird, diesen Jahres Musikwettbewerb zu gewinnen."

    # say L241 bey
    old "Look around you. Every single person in this room has fire inside them."
    new "Schau dich um. Jede einzelne Person in diesem Raum hat ein Feuer in sich."

    # say L242 bey
    old "Some of you know it, some of you are scared of it, some of you are still hiding it. My job? Pull that fire out and turn it into a supernova."
    new "Einige von euch wissen es, einige von euch haben Angst davor, und einige von euch verstecken es noch. Meine Aufgabe? Dieses Feuer hervorholen und es zu einer Supernova machen."

    # say L244 bey
    old "From today until the final I’m your personal mentor, private feedback, whatever each of you needs to bring your absolute best act."
    new "Von heute bis zur Finalshow bin ich euer persönlicher Mentor, gebe euch individuelles Feedback und sorge dafür, dass jeder von euch sein absolutes Bestes gibt."

    # say L245 bey
    old "You’ll cry, you’ll laugh, you’ll hate me on Tuesdays and love me on Fridays, but by the final show you’ll thank me when the entire school is screaming your names."
    new "Ihr werdet weinen, lachen, mich am Dienstag hassen und am Freitag lieben, aber bei der Abschlussshow werdet ihr mir danken, wenn die gesamte Schule eure Namen brüllt."

    # say L246 bey
    old "I'll be here for everything you need, we’re talking vocal technique, stage command, songwriting, harmonies, emotional truth, the whole package."
    new "Ich bin für alles da, was du brauchst, von Gesangstechnik, Bühnenpräsenz, Songwriting, Harmonien, emotionaler Authentizität, das komplette Paket."

    # say L252 sha
    old "Hit it, darling!"
    new "Los, Schatz!"

    # say L253 rya
    old "Let’s give them a show they’ll never forget!"
    new "Lass uns ihnen ein Show geben, die sie nie vergessen werden!"

    # say L256 sha
    old "{i}We’re the headliners, baby, front page news!{/i}"
    new "{i}Wir sind die Hauptakteure, Baby, Titelstory!{/i}"

    # say L257 rya
    old "{i}Spotlights on us, no time to lose!{/i}"
    new "{i}Scheinwerfer auf uns, keine Zeit zu verlieren!{/i}"

    # say L258 sha
    old "{i}Diamonds flashing, sequins bright!{/i}"
    new "{i}Diamanten funkeln, Glitzer sprüht!{/i}"

    # say L259 rya
    old "{i}We own the stage every single night!{/i}"
    new "{i}Wir besitzen die Bühne jede einzelne Nacht!{/i}"

    # say L267 bey
    old "Y’all just brought Broadway to this classroom! Energy off the charts, synchronization tighter than my ponytail, costume game insane."
    new "Ihr habt gerade Broadway in den Klassenzimmer gebracht! Energie durch die Decke, Synchronisation enger als mein Pferdeschwanz, Kostümlook der Wahnsinn."

    # say L268 bey
    old "My only note: sometimes less is more. When every second is maximum sparkle, there’s nowhere left to go for the big moments. Save some glitter for the finale, babies. Otherwise? Flawless."
    new "Mein einziger Tipp: Manchmal ist weniger mehr. Wenn jede Sekunde maximal funkelt, bleibt für die großen Momente nichts übrig. Spart ein bisschen Glitzer für den Finale, Babys. Sonst? Perfekt."

    # say L272 ari
    old "Let’s remind them why we’re here."
    new "Lass uns ihnen zeigen, warum wir hier sind."

    # say L273 tay
    old "Exactly."
    new "Genau."

    # say L276 ari
    old "{i}I’m feeling dangerous, feeling so brand new{/i}"
    new "{i}Ich fühle mich gefährlich, so neu und bereit{/i}"

    # say L277 tay
    old "{i}Shaking off the dust, ready for round two{/i}"
    new "{i}Den Staub abgeschüttelt, bereit für Runde zwei{/i}"

    # say L278 ari
    old "{i}High notes climbing, watch me touch the sky{/i}"
    new "{i}Hohe Töne steigen, sieh mich den Himmel berühren{/i}"

    # say L279 tay
    old "{i}Beat drops heavy, no more asking why!{/i}"
    new "{i}Der Beat ist schwer, keine Fragen mehr!{/i}"

    # say L287 bey
    old "Lord have mercy on my edges! Ariana, those whistle tones cleaner than my Sunday choir. Taylor, that belt could wake the dead."
    new "Herr, hab Erbarmen mit meinen Kanten! Ariana, diese Pfeiftonen sind sauberer als mein Sonntagchor. Taylor, dieser Crescendo könnte die Toten wecken."

    # say L288 bey
    old "Pitch perfect, breath control insane, harmony game lethal."
    new "Pitch perfekt, Atemkontrolle wahnsinnig, Harmoniespiel tödlich."

    # say L289 bey
    old "My tiny note: sometimes perfection can feel safe. Next time risk a little crack, a little rawness. Vulnerability wins hearts. But technically? Untouchable."
    new "Meine kleine Note: Manchmal kann Perfektion sich sicher anfühlen. Nächstes Mal ein bisschen Risse, ein bisschen Rohheit wagen. Verletzbarkeit gewinnt Herzen. Aber technisch? Unantastbar."

    # say L293 pla
    old "Uhh... W- we didn’t really get a chance to rehearse..."
    new "Uhh... W- wir hatten eigentlich keine Zeit zu proben..."

    # say L294 bil
    old "Ugh, just give me the mic."
    new "Ugh, gib mir einfach das Mikro."

    # say L308 bey
    old "Oh my gosh, Billie... honey. That wasn’t singing. That was bleeding through music."
    new "Oh mein Gott, Billie... Schatz. Das war kein Singen. Das war Musik, die durch dich hindurchgegangen ist."

    # say L309 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100%. Volume was whisper quiet, but somehow you filled the entire room."
    new "Dein Ton ist reine Seide, die Phrasierung zerreißt das Herz, die emotionale Wahrheit ist 100 %. Die Lautstärke war flüsterleise, aber irgendwie hast du den ganzen Raum gefüllt."

    # say L310 bey
    old "Stage presence was nonexistent, lighting was wrong for that mood, and [pla]... sweetheart, you were a potted plant."
    new "Die Bühnenpräsenz war gleich null, die Beleuchtung passte nicht zu der Stimmung, und [pla]... Schatz, du warst ein Blumentopf."

    # say L311 bey
    old "But the voice? The voice is once in a generation. We’re going to protect it, grow it, and teach it to roar when it needs to roar."
    new "Aber die Stimme? Die Stimme ist einmalig in der Generation. Wir werden sie schützen, sie gedeihen lassen und sie lehren, zu brüllen, wenn es sein muss."

    # say L312 bey
    old "[pla], next time you move, you breathe with her, you support her. Deal?"
    new "[pla], beim nächsten Mal bewegst du dich mit ihr, atmest mit ihr, stützt sie. Abgemacht?"

    # say L313 pla
    old "Uhh... Y- yeah sure."
    new "Uhh... J- ja, klar."

    # say L319 bey
    old "Well, I have goosebumps from head to toe. Three completely different universes in one room."
    new "Na, ich habe Gänsehaut von Kopf bis Fuß. Drei völlig verschiedene Universen in einem Raum."

    # say L320 bey
    old "Sharpay & Ryan: spectacle and precision. Ariana & Taylor: vocal olympics. Billie & [pla]: pure soul."
    new "Sharpay und Ryan: Spektakel und Präzision. Ariana und Taylor: Vokalolymp. Billie und [pla]: reine Seele."

    # say L321 bey
    old "Next sessions we start real work: breathing, dynamics, choreography, song choice, storytellin, everyone gets one-on-one time with me."
    new "Bei den nächsten Sitzungen geht's ans Ertüchtigen: Atmung, Dynamik, Choreografie, Liedauswahl, Storytelling – jeder von euch kriegt seine Einzelstunde mit mir."

    # say L322 bey
    old "Because every single one of you can win this thing. I’m not here to pick favorites; I’m here to make favorites out of all of you."
    new "Weil jeder von euch dieses Ding gewinnen kann. Ich bin nicht hier, um Favoriten zu wählen; ich bin hier, um aus jedem von euch einen Favoriten zu machen."

    # say L323 bey
    old "Go home, rest those voices, dream big, and come back hungry. See you at the next session!"
    new "Geht nach Hause, lasst eure Stimmen ausruhen, träumt groß und kommt hungrig zurück. Bis zur nächsten Session!"

    # say L327 pla
    old "Wow, Billie, did you hear everything she was saying about your voice?"
    new "Wow, Billie, hast du alles gehört, was sie über deine Stimme gesagt hat?"

    # say L328 bil
    old "Yeah, yeah, Anyway. I did the one practice. We’re done."
    new "Ja, ja, egal. Ich hab das eine Mal geübt. Wir sind fertig."

    # say L329 pla
    old "W- what? Are you serius? You were unbelievable—"
    new "W-was? Ernsthaft? Du warst unglaublich—"

    # say L333 sha
    old "Unbelievable is right. Unbelievably depressing."
    new "Unfassbar ist gut. Unfassbar deprimierend."

    # say L335 sha
    old "What was that, a lullaby for the dead?"
    new "Was war das, ein Wiegenlied für die Toten?"

    # say L339 sha
    old "Volume exists for a reason, sweetie. The back row couldn’t hear a thing."
    new "Lautstärke gibt es aus gutem Grund, Schatz. Die Leute hinten haben gar nichts gehört."

    # say L341 ari
    old "Oh, wait, is this the girl who whispered her whole song? Heh"
    new "Oh, warte, ist das das Mädchen, das den ganzen Song geflüstert hat? Heh"

    # say L343 tay
    old "I thought someone forgot to plug in the mic, hahaha."
    new "Ich dachte, jemand hat das Mikro vergessen anzuschließen, hahaha."

    # say L344 sha
    old "Exactly. Bedroom sad girl vibes don’t win contests, sweetie."
    new "Genau. Schlafzimmer-Sad-Girl-Vibes gewinnen keinen Wettbewerb, Schatz."

    # say L345 ari
    old "We’re trying to make people dance, not cry."
    new "Wir wollen die Leute tanzen lassen, nicht weinen."

    # say L346 tay
    old "Yeah, save the therapy session for TikTok."
    new "Ja, spart euch die Therapiesitzung für TikTok."

    # say L347 pla
    old "Hey, that’s enough—"
    new "Hey, das reicht jetzt —"

    # say L349 sha
    old "Oh, and her backup tree finally speaks!"
    new "Oh, und ihr Ersatzbaum spricht endlich!"

    # say L351 ari
    old "What did you contribute, [pla]? Standing there like a scared statue?"
    new "Was hast du beigetragen, [pla]? Da stehst du wie eine ängstliche Statue?"

    # say L352 tay
    old "Cute support system. Zero talent, zero movement."
    new "Cute Supportsystem. Null Talent, null Bewegung."

    # say L353 sha
    old "Maybe both of you should just quit now."
    new "Vielleicht solltet ihr beide jetzt einfach aufhören."

    # say L357 pla
    old "Hey, we are not-"
    new "Hey, wir sind noch nicht-"

    # say L361 bil
    old "You know what’s funny?"
    new "Du weißt was lustig ist?"

    # say L362 bil
    old "You three spend twenty minutes jumping and screaming so hard nobody can even remember the melody."
    new "Ihr drei vergebt zwanzig Minuten damit, so wild zu springen und zu schreien, dass niemand sich noch an die Melodie erinnern kann."

    # say L363 bil
    old "But sure, tell me my quiet voice is the problem."
    new "Aber klar, sag mir einfach, mein leiser Ton ist das Problem."

    # say L364 bil
    old "And [pla] standing still? At least he’s not faking it with glitter and fake smiles."
    new "Und [pla] stillstehen? Zumindest tut er es nicht mit Glitzer und falschen Lächeln."

    # say L368 bil
    old "It’s kinda cute how you go all out screaming and dancing just to get a little attention."
    new "Es ist irgendwie süß, wie du dich voll auskotzt, um ein bisschen Aufmerksamkeit zu kriegen."

    # say L369 bil
    old "But volume isn’t talent, sweetie, glitter isn’t personality..."
    new "Aber Lautstärke ist noch lange kein Talent, Schatz, Glitter ist noch lange keine Persönlichkeit..."

    # say L370 bil
    old "And sequins don’t hide the fact you’re all noise and no soul."
    new "Und Pailletten verbergen nicht, dass du nur Lärm und kein Herz hast."

    # say L371 bil
    old "See you in the final, girls."
    new "Bis zum Finale, Mädels."

    # say L372 bil
    old "Try not to choke when someone actually feels something."
    new "Versuch bloß nicht zu ersticken, wenn jemand tatsächlich was fühlt."

    # say L377 pla
    old "And that's how it's done."
    new "Und so macht man das."

    # say L383 pla
    old "Hey Billie, wait!"
    new "Hey Billie, warte!"

    # say L386 pla
    old "Are you okay?"
    new "Alles okay?"

    # say L387 bil
    old "Yeah, that was nothing. They’re just a bunch of idiots."
    new "Ja, das war nichts. Die sind einfach nur Idioten."

    # say L388 pla
    old "Yeah, you’re right. But the way you shut them down? Damn, that was epic. I’ll never forget their faces haha."
    new "Ja, du hast recht. Aber die Art, wie du sie abgefertigt hast? Mann, das war episch. Ich werde ihre Gesichter nie vergessen, haha."

    # say L389 pla
    old "And what was that about seeing them in the finals? I thought you were dropping out after the audition... like you said."
    new "Und was war das mit dem Finale? Ich dachte, du wolltest nach der Vorsicht aussteigen... wie du gesagt hast."

    # say L390 bil
    old "Drop out?"
    new "Ausbüxen?"

    # say L391 bil
    old "Please. After that little circus?"
    new "Bitte. Nach diesem kleinen Zirkus?"

    # say L392 bil
    old "I’m not giving them the satisfaction."
    new "Ich gebe ihnen die Genugtuung nicht."

    # say L393 pla
    old "So you’re staying?"
    new "Dann bleibst du?"

    # say L394 bil
    old "Yeah, I’m staying."
    new "Ja, ich bleibe."

    # say L395 bil
    old "And we’re winning."
    new "Und wir gewinnen."

    # say L396 pla
    old "Wait, for real?"
    new "Warte, im Ernst?"

    # say L397 bil
    old "Dead serious. You wanted me in this mess? Congratulations."
    new "Im Ernst. Du wolltest mich in diese Scheiße reinziehen? Herzlichen Glückwunsch."

    # say L398 bil
    old "Now we’re doing it my way. Every day. No excuses."
    new "Jetzt machen wir es nach meiner Art. Jeden Tag. Keine Ausreden."

    # say L399 bil
    old "Come to my place so we can start rehearsing and get ready."
    new "Komm zu mir, damit wir mit der Vorbereitung beginnen können."

    # say L400 pla
    old "Of course I will!"
    new "Natürlich werd ich!"

    # say L401 bil
    old "Alright. I’ll see you later, then."
    new "Okay. Bis später dann."

    # say L402 pla
    old "S- sure, see you later."
    new "Sicher, bis später."

    # say L404 pla
    old "({i}Holy crap... she’s actually doing it.{/i})"
    new "{i}Verdammt... sie macht es wirklich.{/i}"

    # say L405 pla
    old "I seriously did not think she was gonna say yes."
    new "Ich hab echt nicht gedacht, dass sie ja sagen würde."

    # say L406 pla
    old "Like... damn, she walked out of here looking way more motivated than I expected."
    new "Verdammt, sie sah echt motivierter aus, als ich gedacht hätte."

    # say L407 pla
    old "Heh, I guess I owe part of that to those bullies running their mouths earlier."
    new "Heh, scheint so, als hätte ich das den Idioten zu verdanken, die vorhin ihre Klappe nicht halten konnten."

    # say L408 pla
    old "If they hadn’t pushed her buttons, she’d never have agreed that fast."
    new "Wenn die sie nicht so aufgeregt hätten, hätte sie nie so schnell zugestimmt."

    # say L409 pla
    old "Phew... okay... okay, that’s one problem solved."
    new "Phew... okay... okay, das ist eines der Probleme gelöst."

    # say L411 pla
    old "What the hell am I supposed to do in a music contest when I know absolutely nothing about music?"
    new "Was soll ich denn bei einem Musikwettbewerb machen, wenn ich von Musik absolut nichts verstehe?"

    # say L412 pla
    old "Oh man... this is gonna be a disaster."
    new "Oh Mann... das wird ein Desaster."

    # say L413 pla
    old "({i}Yeah... I’m so screwed.{/i})"
    new "({i}Ja... ich bin total am Arsch.{/i})"

    # say L422 bil
    old "Took you long enough."
    new "Hat ja lange genug gedauert."

    # say L423 pla
    old "Hey, sorry. Got caught up with stuff."
    new "Hey, tut mir leid. Bin in was reingezwickert."

    # say L424 bil
    old "Whatever. Come in, grandma’s out."
    new "Was immer. Komm rein, die Oma ist ausgeflogen."

    # say L429 bil
    old "Alright, Before we dive in, what do you know about music?"
    new "Okay, bevor wir loslegen, was weißt du über Musik?"

    # say L430 pla
    old "Uhh... I can tell when a song’s good?"
    new "Uhh... Ich merke, wenn ein Lied gut ist?"

    # say L431 bil
    old "That’s it? No instruments? No singing lessons?"
    new "Das ist alles? Kein Instrument? Keine Gesangsunterricht?"

    # say L432 pla
    old "Uhh nope. Closest I got was humming in the shower."
    new "Uhh nein. Das Nächste, was ich drauf hatte, war im Duschen summen."

    # say L433 bil
    old "Hmph, great start."
    new "Hmpf, toller Anfang."

    # say L434 bil
    old "Okay. We’re trying everything today. Voice, rhythm, keys. See what sticks to your zero skills."
    new "Okay. Wir probieren heute alles aus. Stimme, Rhythmus, Tasten. Schauen wir, was an deinen null Skills haftet."

    # say L435 pla
    old "Everything?"
    new "Alles?"

    # say L436 bil
    old "Yes, we’re gonna find something you don’t completely suck at."
    new "Ja, wir werden etwas finden, bei dem du nicht komplett daneben bist."

    # say L437 bil
    old "I’m your coach now. And it’s gonna be brutal, because we’re winning this thing."
    new "Ich bin jetzt dein Trainer. Und es wird hart werden, denn wir gewinnen dieses Ding."

    # say L438 bil
    old "No mercy, no excuses. You wanted me in? Now you’re in all the way."
    new "Keine Gnade, keine Ausreden. Du wolltest mich dabei haben? Jetzt bist du drin, ganz und gar."

    # say L439 pla
    old "No pressure then."
    new "Dann gibt es ja keinen Druck."

    # say L440 bil
    old "All the pressure. We’re winning this, so get ready to sweat."
    new "Alles Druck. Wir gewinnen das, also bereite dich darauf vor zu schwitzen."

    # say L445 bil
    old "Ok, voice first. Easiest to test."
    new "Okay, Stimme zuerst. Einfachste Möglichkeit zum Testen."

    # say L446 bil
    old "Repeat after me, same melody."
    new "Wiederhole nach mir, selbe Melodie."

    # say L451 bil
    old "Your turn."
    new "Deine Reihe."

    # say L455 bil
    old "Jesus Christ. Were you aiming for every wrong note?"
    new "Jesus Christ. Hast du absichtlich jede falsche Note getroffen?"

    # say L456 pla
    old "I told you I can’t sing..."
    new "Ich hab dir doch gesagt, dass ich nicht singen kann..."

    # say L457 bil
    old "Come on, try again. Feel the words."
    new "Komm schon, versuch’s noch mal. Spür die Worte."

    # say L460 bil
    old "Hmm, that wasn’t singing, that was a hate crime against music."
    new "Hmm, das war kein Singen, das war ein Verbrechen gegen die Musik."

    # say L461 pla
    old "I’ve never had lessons, okay?"
    new "Ich hab noch nie Unterricht gehabt, okay?"

    # say L462 bil
    old "Noted. Voice is a disaster. Moving on."
    new "Notiert. Stimme ist eine Katastrophe. Weitermachen."

    # say L466 bil
    old "Keyboard. C major scale. Slow and clean."
    new "Tastatur. C-Dur-Skala. Langsam und sauber."

    # say L467 pla
    old "I think I can do piano... kind of."
    new "Ich denke, ich kann Klavier spielen... irgendwie."

    # say L470 bil
    old "Great! You just played a car alarm."
    new "Super! Du hast gerade eine Autotaler spielend nachgeahmt."

    # say L471 pla
    old "My fingers won’t cooperate."
    new "Meine Finger wollen einfach nicht mitspielen."

    # say L472 bil
    old "Your fingers have the coordination of drunk spaghetti."
    new "Deine Finger haben die Koordination von betrunkenen Spaghetti."

    # say L473 pla
    old "I’ve never touched a piano in my life..."
    new "Ich hab noch nie in meinem Leben ein Klavier angefasst..."

    # say L474 bil
    old "Clearly, try again."
    new "Klar, versuch’s noch mal."

    # say L477 bil
    old "Wrong finger. Index, not pinky."
    new "Falscher Finger. Zeigefinger, nicht kleiner Finger."

    # say L478 pla
    old "Sorry, I guess I don’t have much finger dexterity."
    new "Entschuldigung, ich schätze, ich habe nicht viel Fingerfertigkeit."

    # say L479 bil
    old "Oh? No practice with the fingers, huh?"
    new "Oh? Keine Übung mit den Fingern, hm?"

    # say L481 bil
    old "Just saying. You’ve got zero practice to do... in a lot of areas."
    new "Sag ich doch. Du hast null Übung... in vielen Bereichen."

    # say L482 pla
    old "This is humiliating."
    new "Das ist erniedrigend."

    # say L483 bil
    old "You´re right. Keyboard out. Next one."
    new "Du hast recht. Tastatur raus. Nächste."

    # say L487 bil
    old "Ok, let's try with congas. Hands only. Feel the groove."
    new "Ok, probieren wir's mit den Congas. Nur die Hände. Spür den Rhythmus."

    # say L488 bil
    old "Four simple beats. One-two-three-four. Like a heartbeat."
    new "Vier einfache Schläge. Eins-zwei-drei-vier. Wie ein Herzschlag."

    # say L489 pla
    old "I got this."
    new "Ich hab's im Griff."

    # say L493 bil
    old "You're rushing a little... No problem. Try again."
    new "Du gehst ein bisschen zu schnell... Kein Problem. Versuch's noch mal."

    # say L494 pla
    old "Uhh ok..."
    new "Uhh okay..."

    # say L497 bil
    old "Hmm, you’re dragging a little now."
    new "Hmm, du ziehst jetzt ein bisschen."

    # say L498 bil
    old "All good, here we go."
    new "Alles gut, los geht's."

    # say L501 bil
    old "No, not quite my tempo."
    new "Nein, nicht ganz mein Tempo."

    # say L502 pla
    old "What does that even—"
    new "Was soll das denn—"

    # say L507 pla
    old "Uhh... I... I d- don’t kn-"
    new "Uhh... Ich... Ich w-weiß nicht"

    # say L508 bil
    old "Tell me are you a rusher, are you a dragger, or are you going to be ON MY FUCKING TIME!?"
    new "Sag mal, bist du ein Schnellficker, ein Langsamficker oder bleibst du bei MEINER VERDAMMTEN ZEIT?!"

    # say L509 pla
    old "W- what?!"
    new "W- was?!"

    # say L510 bil
    old "Ugh... Nevermind. Mostly. Rhythm is dead."
    new "Ugh... Egal. Der Rhythmus ist tot."

    # say L515 pla
    old "This is pointless. I suck at everything."
    new "Das ist sinnlos. Ich bin in allem schlecht."

    # say L516 pla
    old "I’m just gonna embarrass you in front of the whole school."
    new "Ich mache dich noch vor der ganzen Schule zum Gespött."

    # say L518 pla
    old "I’m dragging you down. You saw those girls. They’re pros."
    new "Ich ziehe dich runter. Du hast die Mädchen gesehen. Die sind Profis."

    # say L519 pla
    old "I’m the weak link. Maybe you should just go solo."
    new "Ich bin der schwache Punkt. Vielleicht solltest du besser allein weitermachen."

    # say L520 bil
    old "Are you quitting on me right now?"
    new "Willst du jetzt aufgeben?"

    # say L521 pla
    old "I’m just being realistic."
    new "Ich bin nur realistisch."

    # say L522 pla
    old "I don’t want to be the reason you lose."
    new "Ich will nicht der Grund sein, warum du aufgibst."

    # say L523 bil
    old "You’re the reason I’m even doing this."
    new "Du bist der Grund, warum ich das überhaupt mache."

    # say L524 bil
    old "You pushed me. Remember? 'You’ve got talent, don’t hide it.' Ring a bell?"
    new "Du hast mich angestiftet. Erinnerst du dich? „Du hast Talent, versteck es nicht.“ Klingelt da was?"

    # say L525 bil
    old "So no. You don’t get to bail when it’s your turn."
    new "Dann nein. Du darfst dich jetzt nicht aus der Verantwortung stehlen."

    # say L526 pla
    old "That’s different. You’re actually good."
    new "Das ist was anderes. Du bist wirklich gut."

    # say L527 bil
    old "I wasn’t always. And I’m not doing this alone."
    new "Ich war nicht immer gut. Und ich mache das nicht allein."

    # say L528 pla
    old "But I’m useless."
    new "Aber ich bin nutzlos."

    # say L529 bil
    old "You’re not useless. You’re untrained. And I’m fixing that."
    new "Du bist nicht nutzlos. Du bist unerfahren. Und ich ändere das."

    # say L530 pla
    old "This is gonna be tough... I mean, I basically suck at everything."
    new "Das wird hart... Ich meine, ich bin basically in allem schlecht."

    # say L531 bil
    old "Hmm, maybe not at everything. Wait here."
    new "Hmm, vielleicht nicht bei allem. Warte hier."

    # say L535 bil
    old "This was my dad’s."
    new "Das war von meinem Dad."

    # say L536 pla
    old "Whoa..."
    new "Wow..."

    # say L537 bil
    old "He taught me my first chords on this."
    new "Er hat mir meine ersten Akkorde darauf beigebracht."

    # say L539 bil
    old "Now it’s yours to borrow."
    new "Jetzt gehört es dir zum Ausleihen."

    # say L540 pla
    old "Ohh.. I- I’ll be careful."
    new "Ohh.. Ich werd vorsichtig sein."

    # say L541 bil
    old "You better. If you break it, I break you."
    new "Du besser. Wenn du es kaputt machst, mache ich dich kaputt."

    # say L542 pla
    old "Noted."
    new "Notiert."

    # say L543 bil
    old "We’ll start with three chords. Easiest thing in the world."
    new "Wir fangen mit drei Akkorden an. Das Einfachste der Welt."

    # say L544 bil
    old "You’re gonna learn them. Even if I have to sit on you."
    new "Du wirst sie lernen. Selbst wenn ich mich auf dich setzen muss."

    # say L545 pla
    old "That’s... motivational?"
    new "Das ist... motivierend?"

    # say L546 bil
    old "Damn right it is."
    new "Verdammt richtig."

    # say L548 bil
    old "Alright. Before we even start real lessons, you need to get familiar with that guitar."
    new "Okay. Bevor wir überhaupt mit den richtigen Lektionen anfangen, musst du dich erst mal mit der Gitarre vertraut machen."

    # say L549 pla
    old "Yeah, I figured. But, what should I actually do with it?"
    new "Klar, das dachte ich mir. Aber, was soll ich eigentlich damit machen?"

    # say L550 bil
    old "Well, familiarize yourself with the strings, stop poking the guitar like it’s a wild animal."
    new "Na, vertraut mit den Saiten werden, hör auf, die Gitarre anzustarren, als wäre sie ein wildes Tier."

    # say L551 bil
    old "And please! Use your fingers. Right now they move like you borrowed them from a mannequin."
    new "Und bitte! Benutz deine Finger. Im Moment bewegen sie sich, als hättest du sie von einem Mannequin ausgeliehen."

    # say L552 pla
    old "Come on, they’re not that bad..."
    new "Komm schon, sie sind doch nicht so schlecht..."

    # say L553 bil
    old "Relly? You need agility. Flexibility. Some kind of life in those fingers."
    new "Wirklich? Du brauchst Geschicklichkeit. Beweglichkeit. Ein bisschen Leben in den Fingern."

    # say L554 pla
    old "Okay, so... practice the strings? Just messing around with them?"
    new "Okay, also... die Saiten üben? Einfach so rumspielen?"

    # say L555 bil
    old "Exactly. Touch them, get used to the tension, the spacing, the feel."
    new "Genau. Berühre sie, gewöhne dich an die Spannung, den Abstand, das Gefühl."

    # say L556 bil
    old "Learn what each string does when you press it... without crying."
    new "Lerne, was jede Saite macht, wenn du sie drückst... ohne zu weinen."

    # say L557 pla
    old "Well, I can do that."
    new "Na klar, das krieg ich hin."

    # say L558 bil
    old "Good. Because in your current state, I can’t teach you anything yet."
    new "Gut. Denn in deinem aktuellen Zustand kann ich dir noch gar nichts beibringen."

    # say L559 pla
    old "That bad, huh?"
    new "So schlimm, hm?"

    # say L560 bil
    old "Let’s just say your dexterity is... nonexistent."
    new "Lass uns einfach sagen, deine Fingerfertigkeit ist... gleich null."

    # say L561 bil
    old "Which tells me you haven’t used those fingers for anything interesting."
    new "Das sagt mir, dass du diese Finger noch für nichts Interessantes benutzt hast."

    # say L562 pla
    old "H- hey..."
    new "H-hör auf..."

    # say L563 bil
    old "Point is: practice. Move your fingers up and down the strings. Build some coordination."
    new "Der Punkt ist: Übung. Beweg deine Finger auf und ab über die Saiten. Baue Koordination auf."

    # say L564 pla
    old "Alright. I’ll work on that."
    new "Okay. Ich werde daran arbeiten."

    # say L565 bil
    old "And once your hands stop embarrassing me, come back."
    new "Und sobald deine Hände mich nicht mehr blamieren, kommst du wieder."

    # say L566 pla
    old "Ok, ok, got it."
    new "Ok, ok, hab's kapiert."

    # say L567 bil
    old "Good. But for today, we’re done."
    new "Gut. Aber für heute sind wir fertig."

    # say L568 pla
    old "Already?"
    new "Schon?"

    # say L569 bil
    old "Yeah. You should leave before my grandma shows up."
    new "Ja. Du solltest gehen, bevor meine Oma auftaucht."

    # say L570 pla
    old "W-what? Why?"
    new "W-was? Warum?"

    # say L571 bil
    old "I don’t want her finding me here with all these instruments and with you."
    new "Ich will nicht, dass sie mich hier mit all diesen Instrumenten und mit dir findet."

    # say L572 bil
    old "She’ll think I’m getting back into music."
    new "Sie wird denken, ich mache wieder Musik."

    # say L573 pla
    old "But... what’s wrong with that?"
    new "Aber... was ist daran falsch?"

    # say L574 bil
    old "Not your problem. Don’t dig into it."
    new "Ist nicht dein Problem. Lass es gut sein."

    # say L575 pla
    old "Alright... Alright."
    new "Okay... Okay."

    # say L576 bil
    old "So practice. When you're actually ready, come find me."
    new "Dann übe. Wenn du bereit bist, komm zu mir."

    # say L577 pla
    old "I will. I’ll get better and I’ll be back soon."
    new "Ich werd's tun. Ich werde besser und bald wieder da sein."

    # say L587 pla
    old "It’s really late now, I should leave guitar practice for tomorrow."
    new "Es ist wirklich spät, ich sollte die Gitarrenübung für morgen verschieben."

    # say L590 pla
    old "I’d better let my fingers rest a bit, or they’re gonna start bleeding..."
    new "Ich sollte meinen Fingern ein bisschen Ruhe gönnen, sonst fangen sie noch an zu bluten..."

    # say L594 pla
    old "Okay... here we go. First time ever touching a real guitar."
    new "Okay... los geht's. Erstes Mal, dass ich eine echte Gitarre anfasse."

    # say L595 pla
    old "This thing’s heavier than it looks."
    new "Dieses Ding ist schwerer, als es aussieht."

    # say L596 pla
    old "And it smells like old wood... it’s nice though."
    new "Und es riecht nach altem Holz... ist aber schön."

    # say L597 pla
    old "Alright... let’s see if those YouTube videos helped at all."
    new "Okay... lass uns sehen, ob die YouTube-Videos was gebracht haben."

    # say L598 pla
    old "Watched like three tutorials last night. How hard can open chords be?"
    new "Hab gestern drei Tutorials geschaut. Wie schwer können offene Akkorde schon sein?"

    # say L604 pla
    old "Ow! That buzzed like a dying bee."
    new "Au! Das hat wie eine sterbende Biene gesummt."

    # say L605 pla
    old "Strings hurt more than I expected."
    new "Die Saiten tun mehr weh, als ich gedacht habe."

    # say L606 pla
    old "Let’s try again... second fret, second string... mute the others..."
    new "Lass uns noch mal versuchen... zweiter Bund, zweite Saite... die anderen dämpfen..."

    # say L609 pla
    old "Why do my fingers feel like drunk spaghetti? It´s just like [bil] said."
    new "Warum fühlen sich meine Finger wie betrunkene Spaghetti an? Es ist genau wie [bil] gesagt hat."

    # say L610 pla
    old "One chord. ONE chord. Come on, [pla]."
    new "Eine Akkord. EINE Akkord. Komm schon, [pla]."

    # say L615 pla
    old "I’m literally the worst guitarist in history. Zero dexterity."
    new "Ich bin buchstäblich der schlechteste Gitarrist der Geschichte. Null Fingerfertigkeit."

    # say L616 pla
    old "She’s gonna murder me if I don’t improve."
    new "Sie wird mich umbringen, wenn ich nicht besser werde."

    # say L617 pla
    old "({i}But I’m not quitting. Not after she trusted me with this guitar.{/i})"
    new "{i}Aber ich gebe nicht auf. Nicht nachdem sie mir dieses Gitarr gegeben hat.{/i}"

    # say L618 pla
    old "I have to keep practicing."
    new "Ich muss weiter üben."

    # say L622 pla
    old "Okay... that one almost sounded like an actual chord."
    new "Okay... das klang fast wie ein richtiger Akkord."

    # say L623 pla
    old "Progress! Tiny, painful progress."
    new "Fortschritt! Kleiner, schmerzhafter Fortschritt."

    # say L624 pla
    old "Enough for today. Fingers are officially dead."
    new "Reicht für heute. Die Finger sind offiziell tot."

    # say L625 pla
    old "Tomorrow I’ll be slightly less terrible."
    new "Morgen bin ich ein bisschen weniger schrecklich."

    # say L636 pla
    old "Okay, even if it’s tough, I’ve gotta keep practicing. I need to get better at guitar or Billie’s gonna kill me."
    new "Okay, auch wenn es schwer ist, muss ich weiter üben. Ich muss besser werden, sonst bringt mich Billie um."

    # say L637 pla
    old "My fingers are still sore from last time. Awesome."
    new "Meine Finger tun immer noch weh von letztes Mal. Toll."

    # say L638 pla
    old "Sigh... let’s try this again."
    new "Seufz... lass uns das noch mal versuchen."

    # say L644 pla
    old "Still buzzing on the high E. Damn it!"
    new "Immer noch high auf der E. Scheiße!"

    # say L645 pla
    old "Left hand cramps, right hand can’t keep time."
    new "Linke Hand verkrampft, rechte Hand kann den Takt nicht halten."

    # say L646 pla
    old "Come on, come on, again."
    new "Komm schon, komm schon, noch mal."

    # say L649 pla
    old "Rhythm’s all over the place. Why can’t I get this?"
    new "Das Timing ist total durcheinander. Warum krieg ich das nicht hin?"

    # say L650 pla
    old "I thought I’d be better by now. This is torture."
    new "Ich dachte, ich wäre jetzt besser. Das ist Folter."

    # say L651 pla
    old "({i}She’s probably nailing everything while I’m stuck here.{/i})"
    new "{i}Sie wahrscheinlich haut alles raus, während ich hier stecke.{/i}"

    # say L652 pla
    old "Hmm, one more run through. Clean changes or bust."
    new "Hmm, noch ein Durchgang. Saubere Änderungen oder nichts."

    # say L657 pla
    old "Nope. Still sounds like crap."
    new "Nein. Klingt immer noch wie Mist."

    # say L658 pla
    old "Fingers raw, brain fried, and zero improvement."
    new "Finger wund, Hirn leer, und null Fortschritt."

    # say L659 pla
    old "That’s it for now. Can’t force it."
    new "Das war's für heute. Kann es nicht erzwingen."

    # say L660 pla
    old "Tomorrow. Maybe it’ll click tomorrow."
    new "Morgen. Vielleicht klappt es morgen."

    # say L671 pla
    old "I’m not getting anywhere on my own. This isn’t working."
    new "Ich komme allein nicht weiter. Das funktioniert nicht."

    # say L672 pla
    old "({i}I need help. [bil]’s the only one who can teach me.{/i})"
    new "{i}Ich brauche Hilfe. [bil] ist die Einzige, die mir was beibringen kann.{/i}"

    # say L673 pla
    old "Time to text her. Can’t stay stuck forever."
    new "Zeit, sie zu texten. Kann nicht ewig stecken bleiben."

    # say L674 pla
    old "That’s it for today. Tomorrow, I’m going to her."
    new "Das war’s für heute. Morgen gehe ich zu ihr."

    # say L683 bil
    old "Hey, you look like someone kicked your puppy."
    new "Hey, du siehst aus, als hätte jemand deinem Welpen einen Tritt verpasst."

    # say L685 bil
    old "You texted like the world was ending. What's up?"
    new "Du hast so getextet, als wäre die Welt untergegangen. Was ist los?"

    # say L686 pla
    old "It's the guitar. I tried... really tried."
    new "Es ist die Gitarre. Ich hab's versucht... echt versucht."

    # say L687 bil
    old "And?"
    new "Und?"

    # say L688 pla
    old "Nothing. Fingers won't move right, everything buzzes. I'm stuck."
    new "Nichts. Die Finger bewegen sich nicht richtig, alles klingt wie Sau. Ich stecke fest."

    # say L689 bil
    old "Stuck over just a couple of days? That’s dramatic."
    new "Steckst du schon nach ein paar Tagen fest? Das ist ja dramatisch."

    # say L690 pla
    old "I'm serious. YouTube videos, hours... still crap."
    new "Ich mein's ernst. YouTube-Videos, Stunden... immer noch Mist."

    # say L691 bil
    old "Okay, okay. Let's fix it. Room. Now."
    new "Okay, okay. Lass uns das fixen. Zimmer. Jetzt."

    # say L695 bil
    old "Okay, spill. What exactly did you try?"
    new "Okay, erzähl. Was hast du genau versucht?"

    # say L696 pla
    old "Well, I watched videos, did the finger positions, strummed, practiced for hours... and still nothing."
    new "Na ja, ich hab Videos geguckt, die Fingerpositionen ausprobiert, gestrichen, stundenlang geübt... und trotzdem nichts."

    # say L697 bil
    old "Okay, relax. You’re not hopeless, just untrained."
    new "Okay, entspann dich. Du bist nicht hoffnungslos, nur unerfahren."

    # say L698 pla
    old "Hmm, I feel hopeless."
    new "Hmm, ich fühle mich hoffnungslos."

    # say L699 bil
    old "Well, it does at first. That's normal. We'll figure it out."
    new "Na klar, das fühlt sich am Anfang so an. Das ist normal. Wir kriegen das hin."

    # say L700 pla
    old "Really?"
    new "Wirklich?"

    # say L701 bil
    old "Yeah. I'm your coach. Brutal, but we'll get you there."
    new "Klar. Ich bin deine Trainerin. Brutal, aber wir kriegen das hin."

    # say L702 bil
    old "First, let me show you how it's done. Watch."
    new "Erst mal zeig ich dir, wie es geht. Schau zu."

    # say L709 pla
    old "Holy... you're amazing."
    new "Heilige... du bist unglaublich."

    # say L710 pla
    old "It looks so easy when you do it."
    new "Sieht so einfach aus, wenn du es machst."

    # say L711 bil
    old "It’s just practice. Your turn."
    new "Das ist nur Übung. Deine Reihe."

    # say L715 pla
    old "Uhh, like... this?"
    new "Uhh, so... wie das?"

    # say L718 bil
    old "Buzzing. Press harder on the strings."
    new "Summend. Drück fester auf die Saiten."

    # say L719 pla
    old "Ow... got it."
    new "Au... hab's kapiert."

    # say L723 bil
    old "Better. Still ugly, but better."
    new "Besser. Immer noch hässlich, aber besser."

    # say L724 bil
    old "Try shifting your hand a bit. Find a spot that actually sounds alive."
    new "Versuch, deine Hand ein bisschen zu verschieben. Finde einen Punkt, der wirklich lebendig klingt."

    # say L725 pla
    old "Switching... crap."
    new "Wechselnd... Scheiße."

    # say L729 bil
    old "Slow. Don't rush the change."
    new "Langsam. Mach die Änderung nicht zu hastig."

    # say L730 pla
    old "It's like my fingers hate me."
    new "Meine Finger sind echt gegen mich."

    # say L731 bil
    old "They're lazy. Make 'em work."
    new "Sie sind faul. Mach sie mithelfen."

    # say L732 pla
    old "Like this...."
    new "So..."

    # say L735 bil
    old "No, you're not covering the strings properly."
    new "Nein, du legst die Finger nicht richtig auf die Saiten."

    # say L736 bil
    old "Closer. But your fingers are stiff as boards."
    new "Näher. Aber deine Finger sind steif wie Bretter."

    # say L737 pla
    old "Yeah... no dexterity."
    new "Klar... keine Fingerfertigkeit."

    # say L738 bil
    old "Reset your hand. Try the last position. Light touch, then press."
    new "Setz deine Hand neu. Versuch die letzte Position. Leichter Touch, dann Druck."

    # say L743 pla
    old "I- I can't. This is stupid."
    new "Ich- Ich kann nicht. Das ist bescheuert."

    # say L747 pla
    old "You're wasting your time with me."
    new "Du verschwendest deine Zeit mit mir."

    # say L748 pla
    old "You know what? I should probably go."
    new "Du weißt was? Ich sollte wohl gehen."

    # say L751 bil
    old "No."
    new "Nein."

    # say L754 pla
    old "B- but-"
    new "B- aber-"

    # say L760 bil
    old "You're frustrated. I get it."
    new "Du bist frustriert. Ich verstehe."

    # say L761 pla
    old "I suck. Completely."
    new "Ich bin schlecht. Total."

    # say L762 bil
    old "You don't suck. It's hard. Not everyone even tries."
    new "Du bist nicht schlecht. Es ist schwer. Nicht jeder versucht es überhaupt."

    # say L763 pla
    old "I know... but I’m failing so bad."
    new "Ich weiß... aber ich scheitere total."

    # say L764 bil
    old "Trying and failing is braver than not trying at all."
    new "Versuchen und scheitern ist mutiger als gar nicht erst zu versuchen."

    # say L765 pla
    old "Feels like I'm just letting you down."
    new "Ich fühle mich, als würde ich dich enttäuschen."

    # say L766 bil
    old "You’re not. You’re working hard, and that means a lot."
    new "Du bist das nicht. Du arbeitest hart, und das zählt wirklich."

    # say L767 pla
    old "But I have no talents. Zero. I'm good at... existing?"
    new "Aber ich hab keine Talente. Null. Ich bin gut darin... zu existieren?"

    # say L768 bil
    old "What do you mean you have no talents? Now you’re just being an idiot, you’ve got plenty."
    new "Was meinst du, du hast keine Talente? Jetzt machst du dich selbst fertig, du hast doch genug."

    # say L769 bil
    old "You're friendly. Always helping everyone, even when it's inconvenient."
    new "Du bist freundlich. Immer bereit, anderen zu helfen, auch wenn es dir selbst schwerfällt."

    # say L770 pla
    old "I guess..."
    new "Ich schätze..."

    # say L771 bil
    old "Stubborn too. Look at this, we wouldn’t even be in this mess if you hadn’t pushed and pushed, even when I almost hit you."
    new "Stur bist du auch. Schau dir das an, wir wären nicht in dieser Situation, wenn du nicht immer weitergemacht hättest, selbst als ich dich fast geschlagen hätte."

    # say L772 pla
    old "Yeah, but that backfired."
    new "Ja, aber das hat sich rückwirkend gerächt."

    # say L773 bil
    old "It didn't. It got us here."
    new "Es hat uns hierhergebracht."

    # say L774 bil
    old "And you're funny. That dying cat voice? Gold."
    new "Und du bist witzig. Diese sterbende Katzenstimme? Gold."

    # say L775 pla
    old "Those aren’t really talen-"
    new "Das sind doch gar keine Talente-"

    # say L777 bil
    old "Also... you’re kinda cute, in that awkward, pushy way."
    new "Also... du bist irgendwie süß, auf diese unbeholfene, aufdringliche Art."

    # say L778 pla
    old "A-are you serious?"
    new "Bist du ernst?"

    # say L779 bil
    old "And now that I think about it... you’ve got a huge talent down there, huh..."
    new "Und jetzt, wo ich drüber nachdenke... du hast da unten echt ein großes Talent, oder?"

    # say L781 bil
    old "Well... I mean, you do have talents after all. You see it now?"
    new "Na ja... ich meine, du hast schon Talente. Das siehst du jetzt, oder?"

    # say L782 pla
    old "Uhh... I guess, but what about the guitar?"
    new "Uhh... Ich schätze schon, aber was ist mit der Gitarre?"

    # say L783 bil
    old "Well, guitar's just one more to unlock. But those fingers... they really need waking up."
    new "Na ja, Gitarre ist einfach noch eine mehr, die man knacken muss. Aber diese Finger... die müssen echt mal wachgekitzelt werden."

    # say L785 pla
    old "Yeah, I know... but how am I supposed to do that?"
    new "Ja, ich weiß... aber wie soll ich das machen?"

    # say L787 bil
    old "You know what, I have an idea."
    new "Weißt du was, ich hab da eine Idee."

    # say L789 pla
    old "W- whaat a- are you d- doing?"
    new "W- was m- machst du d- denn?"

    # say L791 bil
    old "Well, I think you need some extra motivation with those sausage fingers, you know?"
    new "Na, ich denke, du brauchst ein bisschen Extra-Motivation mit diesen Würstchenfingern, weißt du?"

    # say L794 pla
    old "Hey, what the Fuc-!"
    new "Hey, was zur Hölle...!"

    # say L795 bil
    old "Shh. Focus on your fingers. Feel the touch."
    new "Pssst. Konzentrier dich auf deine Finger. Spür die Berührung."

    # say L796 pla
    old "[bil]... this is..."
    new "[bil]... das ist..."

    # say L797 bil
    old "Relax... Focus on the task. Circle gently, don't rush it."
    new "Relax... Konzentriere dich auf die Aufgabe. Kreise sanft, mach es nicht zu schnell."

    # say L799 pla
    old "({i}Oh God...{/i})"
    new "{i}Oh Gott...{/i}"

    # say L800 bil
    old "Mmm... that's better. How do they feel to you, [pla]? Soft enough for your liking?"
    new "Mmm... das ist besser. Wie fühlen sie sich für dich, [pla]? Weich genug nach deinem Geschmack?"

    # say L801 pla
    old "They're... so soft, [bil]. It feels amazing."
    new "Sie sind... so weich, [bil]. Das fühlt sich unglaublich an."

    # say L802 bil
    old "Heh, good answer. Now, add a bit more pressure. Let's see if you can actually handle the real thing."
    new "Heh, gute Antwort. Jetzt, füge ein bisschen mehr Druck hinzu. Lass uns sehen, ob du das echte Zeug tatsächlich bewältigen kannst."

    # say L805 pla
    old "Like this? Am I doing it right?"
    new "So? Mach ich das richtig?"

    # say L806 bil
    old "Nngh—yeah. Exactly like that..."
    new "Nngh—ja. Genau so..."

    # say L807 bil
    old "See? you're learning."
    new "Siehst du? Du lernst schnell."

    # say L808 pla
    old "({i}This is insane... and it's working?{/i})"
    new "({i}Das ist verrückt... und es funktioniert?{/i})"

    # say L809 bil
    old "Mmm, nice. Now pick up the pace. Let’s see if you can keep your finesse while speeding up."
    new "Mmm, schön. Jetzt mach schneller. Lass uns sehen, ob du dein Geschick beibehalten kannst, wenn du schneller wirst."

    # say L811 bil
    old "Tell me how they feel right now."
    new "Sag mir, wie sie sich gerade anfühlen."

    # say L813 pla
    old "Hot... heavy... and every time I squeeze they bounce a little. It's insane."
    new "Heiß... schwer... und jedes Mal, wenn ich zudrücke, springen sie ein bisschen. Es ist verrückt."

    # say L814 bil
    old "Good feedback. Noted."
    new "Gutes Feedback. Notiert."

    # say L815 bil
    old "Keep going. Feel the rhythm."
    new "Weiter so. Spür den Rhythmus."

    # say L816 pla
    old "I... I feel something."
    new "Ich... ich spür etwas."

    # say L817 bil
    old "Yeah, I noticed. Looks like your other talent’s waking up, huh?"
    new "Ja, das hab ich gemerkt. Scheint, als würde dein anderes Talent aufwachen, hm?"

    # say L819 pla
    old "Oh shit... sorry!"
    new "Oh Scheiße... tut mir leid!"

    # say L820 bil
    old "Oh, come on, you're literally groping my tits..."
    new "Oh, komm schon, du fasst mich ja buchstäblich an den Titten an..."

    # say L822 bil
    old "You know what? Come here, let me show you one of my hidden talents too..."
    new "Du weißt was? Komm her, lass mich dir auch eine meiner verborgenen Talente zeigen..."

    # say L823 bil
    old "This throat does more than just sing, you know?"
    new "Dieser Hals kann mehr als nur singen, weißt du?"

    # say L828 pla
    old "Hooooly shit!"
    new "Hooooley Scheiße!"

    # say L829 bil
    old "So... you like my other talent too, huh?"
    new "So... dir gefällt mein anderer Talent auch, hm?"

    # say L830 pla
    old "Oh, yeah, it feels so good..."
    new "Oh, ja, das fühlt sich so gut an..."

    # say L831 bil
    old "Mmm... I’ve missed this since that stupid spin-the-bottle game."
    new "Mmm... Ich hab das vermisst, seit diesem blöden Flaschendreh-Spiel."

    # say L832 pla
    old "You... you have?"
    new "Du... du hast?"

    # say L833 bil
    old "Shut up. Let me show you my real talent."
    new "Halt die Klappe. Lass mich dir mein echtes Talent zeigen."

    # say L861 bil
    old "So... I guess we made some progress today."
    new "Also... Ich denke, wir haben heute einiges erreicht."

    # say L862 pla
    old "Oh yeah, a lot."
    new "Oh ja, viel."

    # say L864 bil
    old "I meant with the guitar."
    new "Ich meinte mit der Gitarre."

    # say L865 pla
    old "Oh, right. Yes. That too."
    new "Oh, stimmt. Ja. Das auch."

    # say L866 bil
    old "And from what I see, you definitely have plenty of motivation now."
    new "Und nach dem, was ich sehe, hast du definitiv genug Motivation."

    # say L867 pla
    old "Oh, that’s for sure."
    new "Oh, das ist sicher."

    # say L868 bil
    old "Good. Because that whole quit-the-contest nonsense better be gone."
    new "Gut. Denn dieser ganzen Unsinn, dass du aus dem Wettbewerb aussteigen willst, ist hoffentlich passé."

    # say L869 pla
    old "Of course. I’m not quitting."
    new "Natürlich. Ich gebe nicht auf."

    # say L870 bil
    old "Perfect. Then keep practicing at home like you’ve been doing."
    new "Perfekt. Dann übe weiter zu Hause, wie du es bisher getan hast."

    # say L871 bil
    old "Your fingers still need work... a lot of work."
    new "Deine Finger brauchen noch viel Übung... wirklich viel Übung."

    # say L872 pla
    old "I’ll practice every day. I actually want to improve."
    new "Ich werde jeden Tag üben. Ich will echt besser werden."

    # say L873 bil
    old "Hmm. And if you need something, just tell me."
    new "Hmm. Und wenn du was brauchst, sag Bescheid."

    # say L874 pla
    old "I will. Thanks... seriously."
    new "Ich werd's tun. Danke... echt."

    # say L875 bil
    old "Alright. Let’s leave it here for today."
    new "Okay. Lass uns es für heute dabei bewenden."

    # say L876 bil
    old "Go home before my grandma shows up."
    new "Geh nach Hause, bevor meine Oma auftaucht."

    # say L877 pla
    old "Yeah, I should. I’ll come back soon."
    new "Klar, ich muss los. Ich komme bald wieder."

    # say L878 bil
    old "You better."
    new "Du besser."

    # say L889 pla
    old "Okay... it’s still hard, but I can’t skip practice now."
    new "Okay... es ist immer noch schwer, aber ich kann die Übung jetzt nicht mehr sausen lassen."

    # say L890 pla
    old "I’m not great yet, but I’m not totally hopeless either."
    new "Ich bin noch nicht super, aber ich bin auch nicht völlig hoffnungslos."

    # say L891 pla
    old "Alright. Let’s see if I can do this a little better today."
    new "Okay. Lass uns sehen, ob ich es heute ein bisschen besser hinbekomme."

    # say L898 pla
    old "Hey... that one didn’t buzz as bad."
    new "Hey... das hat nicht so geschwirrt."

    # say L899 pla
    old "Still not perfect... but it sounded more like a chord this time."
    new "Immer noch nicht perfekt... aber es klang mehr wie eine Akkord diesmal."

    # say L900 pla
    old "Hand’s tired, but it’s moving better."
    new "Die Hand ist müde, aber sie bewegt sich besser."

    # say L901 pla
    old "Ok, again. Same thing."
    new "Okay, noch mal. Das Gleiche."

    # say L905 pla
    old "Rhythm’s still messy... but I didn’t completely lose it."
    new "Das Tempo ist noch unregelmäßig... aber ich hab’s nicht total verloren."

    # say L906 pla
    old "I can actually feel where I mess up now."
    new "Ich spüre jetzt tatsächlich, wo ich Fehler mache."

    # say L907 pla
    old "({i}Okay... that’s something. I didn’t feel that before.{/i})"
    new "{i}Okay... das ist schon was. Das hab ich vorher nicht gespürt.{/i}"

    # say L908 pla
    old "One more time. Let’s make it cleaner."
    new "Noch einmal. Lass es sauberer werden."

    # say L914 pla
    old "Still rough... but not total garbage."
    new "Immer noch rau... aber nicht mehr vollkommen Mist."

    # say L915 pla
    old "That sounded... closer."
    new "Das klang... näher dran."

    # say L916 pla
    old "Yeah. Not there yet, but it’s moving."
    new "Ja. Noch nicht perfekt, aber es bewegt sich."

    # say L917 pla
    old "Enough for today. Don’t want to ruin what I actually did right."
    new "Reicht für heute. Will nicht ruinieren, was ich richtig gemacht hab."

    # say L918 pla
    old "Tomorrow... let’s see if it gets even better."
    new "Morgen... lass uns sehen, ob es noch besser wird."

    # say L931 bil
    old "Oh, look who showed up."
    new "Oh, schau mal wer da ist."

    # say L932 pla
    old "Yeah, I wanted to practice with you again."
    new "Ja, ich wollte wieder mit dir üben."

    # say L933 bil
    old "Right, you texted about that. How's it going?"
    new "Stimmt, du hast mir davon geschrieben. Wie läuft's?"

    # say L934 pla
    old "Uhh, better than before... kinda."
    new "Uhh, besser als vorher... irgendwie."

    # say L935 bil
    old "Oh really? Hah. I need to see that to believe it."
    new "Oh wirklich? Hah. Ich muss das sehen, um es zu glauben."

    # say L936 bil
    old "Come on. Let’s go to my room and talk properly."
    new "Komm schon. Lass uns in mein Zimmer gehen und richtig reden."

    # say L939 bil
    old "Okay, spill. What did you do these days?"
    new "Okay, raus damit. Was hast du in den letzten Tagen gemacht?"

    # say L940 pla
    old "Honestly... a lot. I practiced every day. My fingers feel way more alive now."
    new "Ehrlich... viel. Ich habe jeden Tag geübt. Meine Finger fühlen sich jetzt viel lebendiger an."

    # say L941 bil
    old "Good. About time they woke up from the dead."
    new "Gut. Es wird Zeit, dass sie aus dem Tode auferstehen."

    # say L942 pla
    old "Yeah, but... I feel like I hit a wall again."
    new "Ja, aber... ich habe das Gefühl, ich bin wieder an eine Wand gestoßen."

    # say L943 bil
    old "Hmm. Typical. Let me see. Take the guitar."
    new "Hmm. Typisch. Lass mich mal sehen. Gib mir die Gitarre."

    # say L949 pla
    old "Alright... here goes."
    new "Okay... hier geht's."

    # say L953 bil
    old "Huh... pressure’s steadier. The tone’s still messy, but at least you’re not fighting the guitar anymore."
    new "Hm... der Druck ist gleichmäßiger. Der Ton ist noch immer unordentlich, aber zumindest kämpfst du nicht mehr gegen die Gitarre."

    # say L954 pla
    old "Yeah, I feel more control. I can switch positions smoother now."
    new "Ja, ich hab mehr Kontrolle. Ich kann die Positionen wechseln, ohne zu stolpern."

    # say L955 bil
    old "Still too slow. But hey, your hand is finally acting like it belongs to a living person."
    new "Immer noch zu langsam. Aber hey, deine Hand verhält sich endlich so, als würde sie zu einem lebenden Menschen gehören."

    # say L956 bil
    old "Not bad. Your fingers actually woke up this time."
    new "Nicht schlecht. Deine Finger sind dieses Mal tatsächlich wach geworden."

    # say L957 pla
    old "Yeah, but that’s the problem. I think I hit my limit again. I can’t push past this alone."
    new "Ja, aber das ist das Problem. Ich glaube, ich habe wieder meine Grenze erreicht. Ich schaffe es nicht allein weiterzukommen."

    # say L960 pla
    old "Honestly... I was hoping you could help me practice again."
    new "Ehrlich... ich hatte gehofft, dass du mir wieder beim Üben helfen könntest."

    # say L961 bil
    old "Huh?"
    new "Hä?"

    # say L962 bil
    old "So that’s why you came back. You want more 'practice'."
    new "Deshalb bist du also wieder hier. Du willst mehr Übung."

    # say L963 pla
    old "Exactly. Something a bit more advanced. Something that forces my fingers to—"
    new "Genau. Etwas Fortgeschritteneres. Etwas, das meine Finger dazu zwingt—"

    # say L964 bil
    old "Oh, I see where this is going."
    new "Oh, ich sehe, wohin das führt."

    # say L965 bil
    old "Yeah, sure. More 'advanced practice', right?"
    new "Klar, klar. Mehr \"fortgeschrittene Übungen\", richtig?"

    # say L966 pla
    old "Exactly! I need something beyond the basics. I’m not improving anymore."
    new "Genau! Ich brauche was über die Grundlagen hinaus. Ich mache keinen Fortschritt mehr."

    # say L967 bil
    old "Alright, alright, I get it. No need to act innocent."
    new "Okay, okay, ich hab's kapiert. Muss ich echt unschuldig tun?"

    # say L969 bil
    old "Come on, don’t be shy. I know what you’re actually here for."
    new "Komm schon, sei nicht schüchtern. Ich weiß, wofür du wirklich hier bist."

    # say L971 pla
    old "No, no, that’s not—"
    new "Nein, nein, das ist nicht—"

    # say L972 bil
    old "Stop overthinking. You came to practice."
    new "Hör auf, dir den Kopf zu zerbrechen. Du bist hier, um zu üben."

    # say L973 bil
    old "So let’s practice."
    new "Dann lass uns üben."

    # say L975 pla
    old "({i}Oh God, they feel incredible...{/i})"
    new "{i}Oh Gott, sie fühlen sich unglaublich an...{/i}"

    # say L976 bil
    old "There. Full palms first. feel how soft they are when you take your time."
    new "Da. Zuerst die flachen Handflächen. Spürst du, wie weich sie sich anfühlen, wenn du langsam machst."

    # say L978 bil
    old "Keep that rhythm. Don't rush the ‘practice’."
    new "Halte das Tempo. Mach die ‘Übung’ nicht zu schnell."

    # say L979 pla
    old "Fuck... [bil], they feel unreal."
    new "Fuck... [bil], sie fühlen sich unwirklich an."

    # say L980 bil
    old "Limited edition, baby."
    new "Limited Edition, Baby."

    # say L981 bil
    old "Come on, a little more pressure. You know what I like."
    new "Komm schon, ein bisschen mehr Druck. Du weißt, was ich mag."

    # say L983 pla
    old "L-like... this?"
    new "L-Lass mich... so?"

    # say L984 bil
    old "Yes... perfect. You're doing better than I expected."
    new "Ja... perfekt. Du machst besser, als ich erwartet habe."

    # say L985 pla
    old "Your nipples... they're getting hard. Does that mean I'm doing good?"
    new "Deine Nippel... die werden hart. Das bedeutet, dass ich gut mache, oder?"

    # say L986 bil
    old "Means you’re not completely hopeless. Keep going."
    new "Das bedeutet, dass du nicht völlig hoffnungslos bist. Mach weiter."

    # say L987 bil
    old "Okay, new part. First time for this one."
    new "Okay, neuer Teil. Erstes Mal dafür."

    # say L988 bil
    old "Nipples only. Start super gentle... just the tips of your fingers."
    new "Nippel nur. Fang ganz sanft an... nur die Spitzen deiner Finger."

    # say L990 pla
    old "T-they're so sensitive... I can feel them hardening more."
    new "S-sie sind so empfindlich... Ich spüre, wie sie härter werden."

    # say L991 bil
    old "Good. Now a little harder. Build it up, don't rush."
    new "Gut. Jetzt ein bisschen fester. Steiger es, aber nicht zu schnell."

    # say L992 pla
    old "A-are you sure?"
    new "Bist du dir sicher?"

    # say L993 bil
    old "Harder, [pla]. Don’t be scared. Make me feel it."
    new "Fester, [pla]. Hab keine Angst. Mach mich spüren, wie es ist."

    # say L995 pla
    old "L-like this? God, you're starting to breathe heavier..."
    new "L-wie das? Gott, du atmest schon schwerer..."

    # say L996 bil
    old "Yes—fuck—keep going. Harder now, make it count."
    new "Ja—fick—mach weiter. Härter jetzt, lass es zählen."

    # say L997 bil
    old "({i}Fuck... he’s careful but he’s getting it...{/i})"
    new "{i}Scheiße... er ist vorsichtig, aber er kriegt es hin...{/i}"

    # say L998 pla
    old "I- I don’t want to hurt you..."
    new "Ich- Ich will dich nicht verletzen..."

    # say L999 bil
    old "You won’t. Trust me. Slowly harder each time."
    new "Du wirst es nicht. Vertrau mir. Jedes Mal ein bisschen fester."

    # say L1002 pla
    old "I-I can feel you tensing... come for me, [bil]?"
    new "Ich spür dich anspannen... komm für mich, [bil]?"

    # say L1003 bil
    old "Harder—now—ahh—fuck—yes—!"
    new "Fester—jetzt—ahh—fick—ja—!"

    # say L1005 bil
    old "Okay... that was more than enough warm up for your fingers."
    new "Okay... das war mehr als genug Vorbereitung für deine Finger."

    # say L1006 pla
    old "Y- yeah... definitely intense."
    new "Y- ja... definitiv intensiv."

    # say L1008 bil
    old "So? Feeling more agile now?"
    new "Also? Fühlst du dich jetzt geschickter?"

    # say L1009 pla
    old "Honestly... a little. But... I don’t think that alone will fix everything."
    new "Ehrlich... ein bisschen. Aber... ich glaube nicht, dass das allein alles löst."

    # say L1010 bil
    old "Oh, really?"
    new "Oh, wirklich?"

    # say L1011 pla
    old "Yeah. I mean... thanks for the help, seriously, but I don’t think that kind of practice is enough to improve my speed or accuracy."
    new "Klar. Also... danke für die Hilfe, echt jetzt, aber ich glaube nicht, dass so eine Übung reicht, um meine Geschwindigkeit oder Genauigkeit zu verbessern."

    # say L1013 bil
    old "So what, now you want something even more advanced?"
    new "Und was jetzt? Willst du jetzt was noch Schwierigeres?"

    # say L1014 pla
    old "Well— I mean— I just—"
    new "Na ja— ich meine— ich hab doch nur—"

    # say L1015 bil
    old "No. No, no, no. Don’t even think I’m giving you a blowjob every time you struggle with a chord."
    new "Nein. Nein, nein, nein. Denk nicht mal dran, dass ich dir jedes Mal einen blase, wenn du mit einem Akkord kämpfst."

    # say L1016 pla
    old "Wait— what? No! That’s not what I meant!"
    new "Warte – was? Nein! Das meinte ich doch gar nicht!"

    # say L1017 bil
    old "Good. Because I’m not doing that every time you show up."
    new "Gut. Denn das mache ich nicht jedes Mal, wenn du auftauchst."

    # say L1018 pla
    old "N- no! I swear I wasn’t asking for that!"
    new "N-nein! Ich schwöre, ich hab das nicht gemeint!"

    # say L1019 bil
    old "Then what were you asking for?"
    new "Dann was wolltest du denn?"

    # say L1020 pla
    old "I just... genuinely need help finding a better exercise. Something real. Something useful for my fingers."
    new "Ich hab nur... echt Hilfe gebraucht, um eine bessere Übung zu finden. Etwas Reales. Etwas Nützliches für meine Finger."

    # say L1021 bil
    old "So you’re... actually serious."
    new "Dann bist du also... ernsthaft."

    # say L1022 pla
    old "Yes. I figured you’d know something. A technique, an exercise, something."
    new "Ja. Ich dachte, du weißt da was. Eine Technik, ein Übung, irgendetwas."

    # say L1023 pla
    old "Exactly, that’s what I’m looking for."
    new "Genau, das ist es, wonach ich suche."

    # say L1024 bil
    old "Okay, okay, Hmm, then let me think."
    new "Okay, okay, Hmm, dann lass mich nachdenken."

    # say L1025 bil
    old "Hmm... something advanced for finger dexterity... something that forces your hand to adapt..."
    new "Hmm... etwas Fortgeschrittenes für die Fingerfertigkeit... etwas, das deine Hand zwingt sich anzupassen..."

    # say L1026 pla
    old "Yeah. Exactly."
    new "Ja. Genau."

    # say L1029 bil
    old "...I have an idea."
    new "...Ich hab eine Idee."

    # say L1030 pla
    old "You do? What is it?"
    new "Du hast eine? Was ist es?"

    # say L1031 bil
    old "You’ll see. Just stay there."
    new "Du wirst schon sehen. Bleib einfach da."

    # say L1033 pla
    old "So... what do you have in mind?"
    new "Also... was hast du vor?"

    # say L1034 bil
    old "Something advance. Trust me."
    new "Etwas Fortgeschrittenes. Vertrau mir."

    # say L1036 pla
    old "W- what are you doing?!"
    new "W- was machst du?!"

    # say L1037 bil
    old "Relax. This is the training. Just extreme level."
    new "Beruhige dich. Das ist die Ausbildung. Nur auf Extremstufe."

    # say L1040 bil
    old "Now... use those fingers. Start slow."
    new "Jetzt... benutz diese Finger. Fang langsam an."

    # say L1042 bil
    old "Shh. Focus. Circle the clit gently."
    new "Pssst. Konzentrier dich. Kreise sanft um die Klitoris."

    # say L1046 bil
    old "Mmm... good. Now slide one in."
    new "Mmm... gut. Jetzt schieb einen rein."

    # say L1047 pla
    old "Like... this?"
    new "Wie... so?"

    # say L1048 bil
    old "Yes... curl it. Find the spot."
    new "Ja... krümme es. Finde die Stelle."

    # say L1050 bil
    old "Faster now. Add another finger."
    new "Schneller jetzt. Füge einen weiteren Finger hinzu."

    # say L1052 pla
    old "[bil]... you're squeezing..."
    new "[bil]... du drückst richtig zu..."

    # say L1053 bil
    old "That's it. Rub harder."
    new "Das ist es. Reib fester."

    # say L1054 pla
    old "Fuck... you're dripping."
    new "Scheiße... du bist nass."

    # say L1055 bil
    old "Deeper. Don't stop."
    new "Tiefer. Hör nicht auf."

    # say L1057 bil
    old "Harder... make me cum."
    new "Fester... mach mich kommen."

    # say L1060 pla
    old "Oh fuck... cum for me."
    new "Oh Scheiße... komm für mich."

    # say L1063 pla
    old "Yes... feel it all."
    new "Ja... spür es alles."

    # say L1064 bil
    old "Oh god... that's it."
    new "Oh Gott... das ist es."

    # say L1072 bil
    old "Alright, THAT was definetly an advance training..."
    new "Okay, DAS war definitiv eine Fortgeschrittenenstufe..."

    # say L1073 pla
    old "Y-yeah... that was... a lot."
    new "Y-ja... das war... viel."

    # say L1074 bil
    old "But hey, your fingers definitely kept up this time."
    new "Aber hey, deine Finger haben definitiv mithalten können dieses Mal."

    # say L1075 pla
    old "I did feel a big difference. Seriously."
    new "Ich hab' einen großen Unterschied gespürt. Ernsthaft."

    # say L1076 bil
    old "Good. Then keep practicing at home. Use what you learned today."
    new "Gut. Dann übe weiter zu Hause. Nutze, was du heute gelernt hast."

    # say L1077 bil
    old "If you get stuck again, come back. We’ll figure something out."
    new "Wenn du wieder stecken bleibst, komm zurück. Wir finden eine Lösung."

    # say L1078 pla
    old "I will. Thanks... for everything."
    new "Ich werd's machen. Danke... für alles."

    # say L1079 bil
    old "Alright, event’s over. Go home before my grandma arrives."
    new "Okay, das Event ist vorbei. Geh nach Hause, bevor meine Oma kommt."

    # say L1091 bil
    old "Finally. Took you long enough."
    new "Endlich. Hat ja lange genug gedauert."

    # say L1092 pla
    old "You texted me. Said it was important."
    new "Du hast mir geschrieben. Hast gesagt, es wäre wichtig."

    # say L1093 bil
    old "Yeah. Because it is. The teacher called me."
    new "Ja. Weil es wichtig ist. Die Lehrerin hat mich angerufen."

    # say L1094 pla
    old "Wait... what? Already?"
    new "Warte... was? Schon?"

    # say L1095 bil
    old "She wants to schedule our supervised practice."
    new "Sie will unser überwachtes Training terminieren."

    # say L1096 pla
    old "Like... with her? Watching me? Listening to me?"
    new "Wie... mit ihr? Mich beobachten? Mich anhören?"

    # say L1097 bil
    old "Mhm. Exactly that."
    new "Mhm. Genau das."

    # say L1098 pla
    old "Oh man... I’m not ready for that."
    new "Oh Mann... Ich bin dafür noch nicht bereit."

    # say L1099 bil
    old "That’s why I told you to come."
    new "Deshalb hab ich dir gesagt, dass du kommen sollst."

    # say L1100 bil
    old "We need to polish you up before she sees anything."
    new "Wir müssen dich noch aufpolieren, bevor sie was sieht."

    # say L1101 pla
    old "I don’t know if I can—"
    new "Ich weiß nicht, ob ich das kann—"

    # say L1102 bil
    old "Stop. You’re doing it. We’re doing it. End of story."
    new "Stopp. Du machst es. Wir machen es. Ende der Geschichte."

    # say L1103 bil
    old "Come on. Room. We’ll talk there."
    new "Komm schon. Zimmer. Wir reden da drüber."

    # say L1108 bil
    old "Alright. Tell me. How’ve you been since last time?"
    new "Okay. Erzähl mir. Wie geht’s dir seit dem letzten Mal?"

    # say L1109 pla
    old "Honestly? Way better. After all that... 'advanced practice'... I definitely improved."
    new "Ehrlich? Viel besser. Nach all dem... 'fortgeschrittenen Training'... hab ich definitiv Fortschritte gemacht."

    # say L1110 bil
    old "Oh, I bet you did."
    new "Oh, das glaube ich dir aufs Wort."

    # say L1112 bil
    old "Yeah, yeah. Show me."
    new "Ja, ja. Zeig's mir."

    # say L1116 pla
    old "Okay... here goes."
    new "Okay... hier geht's."

    # say L1118 bil
    old "Huh. Look at that."
    new "Huh. Schau dir das an."

    # say L1119 bil
    old "Hand’s lighter. Movement’s cleaner. You’re not strangling the strings anymore."
    new "Die Hand ist leichter. Die Bewegung ist flüssiger. Du würgst die Saiten nicht mehr."

    # say L1120 pla
    old "Yeah, I feel the difference. And switching positions isn’t torture now."
    new "Ja, ich spür den Unterschied. Und die Positionen wechseln ist jetzt kein Horror mehr."

    # say L1121 bil
    old "Well, seems last session really loosened you up."
    new "Na, scheint, dass die letzte Session dich wirklich gelockert hat."

    # say L1122 pla
    old "I... guess so."
    new "Ich... schätze schon."

    # say L1123 bil
    old "Still not perfect. You need a final push if you want to stand in front of a teacher."
    new "Noch nicht perfekt. Du brauchst den letzten Kick, wenn du vor einer Lehrerin stehen willst."

    # say L1124 pla
    old "You really think I need more?"
    new "Du denkst echt, ich brauche noch mehr?"

    # say L1125 bil
    old "Oh, absolutely. A little more ‘advanced training’ won’t hurt."
    new "Oh, absolut. Ein bisschen mehr 'fortgeschrittene Ausbildung' kann nicht schaden."

    # say L1126 pla
    old "Billie... I don’t know. I think I’ve improved a lot already."
    new "Billie... ich weiß nicht. Ich denke, ich bin schon viel besser geworden."

    # say L1127 bil
    old "You did. But if you want her to take you seriously, you need your fingers sharp."
    new "Du hast. Aber wenn du willst, dass sie dich ernst nimmt, musst du deine Finger geschickt sein."

    # say L1128 bil
    old "And we both know exactly what helped last time."
    new "Und wir wissen beide genau, was letztes Mal geholfen hat."

    # say L1129 pla
    old "B- Billie, I—"
    new "B- Billie, ich—"

    # say L1130 bil
    old "Save it. We’re not wasting time. The supervised practice is soon."
    new "Spaar es dir. Wir verschwenden keine Zeit. Die überwachte Übung beginnt bald."

    # say L1131 bil
    old "So let's get you ready properly."
    new "Dann lass uns dich richtig vorbereiten."

    # say L1143 bil
    old "Okay... damn. You’ve definitely improved again."
    new "Okay... verdammt. Du hast definitiv wieder zugenommen."

    # say L1145 bil
    old "Yeah. I can feel it. Your fingers are way more confident now."
    new "Ja. Ich spür’s. Deine Finger sind jetzt viel sicherer."

    # say L1146 pla
    old "I... still don’t know if I’m ready for the teacher, though."
    new "Ich... bin mir noch nicht sicher, ob ich bereit für die Lehrerin bin."

    # say L1147 bil
    old "Relax."
    new "Beruhige dich."

    # say L1148 bil
    old "You’re not being tested for the contest yet. This is just to show progress."
    new "Du wirst erst noch nicht für den Wettbewerb getestet. Das hier dient nur, um Fortschritte zu zeigen."

    # say L1149 pla
    old "Right... progress."
    new "Okay... Fortschritt."

    # say L1150 bil
    old "She’ll give us feedback. Then we adjust. Simple."
    new "Sie gibt uns Feedback. Dann passen wir an. Einfach."

    # say L1151 pla
    old "Okay... I guess that makes sense."
    new "Okay... Ich schätze, das ergibt Sinn."

    # say L1152 bil
    old "Good. Then keep practicing at home. A lot."
    new "Gut. Dann übe zu Hause. Viel."

    # say L1153 bil
    old "Don’t make me regret putting in all this effort."
    new "Mach mich nicht bitter, dass ich so viel Mühe investiert habe."

    # say L1154 pla
    old "I won’t. I’ll practice."
    new "Ich werd's nicht. Ich werd' üben."

    # say L1155 bil
    old "Alright... I’m done. Literally done. And I’m getting sleepy."
    new "Okay... ich bin fertig. Wirklich fertig. Und ich werde müde."

    # say L1156 pla
    old "Sleepy?"
    new "Schlafmütze?"

    # say L1157 bil
    old "Yeah. ‘Advanced training’ is exhausting, in case you didn’t notice."
    new "Klar. 'Fortgeschrittene Ausbildung' ist echt anstrengend, falls dir das noch nicht aufgefallen ist."

    # say L1158 pla
    old "R-right... sorry."
    new "Richtig... tut mir leid."

    # say L1159 bil
    old "Go home. Practice. And don’t come back useless."
    new "Geh nach Hause. Übe. Und komm nicht als Versager zurück."

    # say L1160 pla
    old "I’ll do my best. I’ll see you soon."
    new "Ich werde mein Bestes geben. Bis bald."


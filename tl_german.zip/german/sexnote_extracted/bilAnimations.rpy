# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/bilAnimations.rpy
translate german strings:

    # say L6 lin
    old "Wow! I see you've a lot of energy repressed... Big and impressive."
    new "Wow! Ich sehe, du hast eine Menge Energie zurückgehalten... Groß und beeindruckend."

    # say L7 pla
    old "... I guess..."
    new "Ich schätze..."

    # say L13 lin
    old "Ohh it tastes great! I really like it."
    new "Ohh, das schmeckt toll! Ich mag es wirklich."

    # say L19 lin
    old "Oh yeah... Give it to me... Give me all your load!"
    new "Oh ja... Gib es mir... Gib mir alles von dir!"

    # say L44 lin
    old "Ahhh... I'm feeling it on my mouth!"
    new "Ahhh... Ich spüre es auf meinen Lippen!"

    # say L49 lin
    old "Hmmm, It was great... Now I need your dick inside, the energy transfer should be done now."
    new "Hmmm, das war toll... Jetzt brauche ich deinen Schwanz drin, die Energieübertragung sollte abgeschlossen sein."

    # say L71 lin
    old "Oh yeah... I haven't felt this in a long time ..."
    new "Oh ja... Ich hab das schon lange nicht mehr gespürt..."

    # say L76 lin
    old "Wow is huge and is drilling this girl..."
    new "Wow, das ist riesig und fickt mich richtig durch..."

    # say L82 lin
    old "Ohhh yeahhh, harder, harder!"
    new "Ohhh yeahhh, härter, härter!"

    # say L83 lin
    old "Don't stop! Gimme more! I want it all!"
    new "Hör nicht auf! Gib mir mehr! Ich will alles!"

    # say L107 lin
    old "Ahhhhh.... Yeah!"
    new "Ahhhhh.... Ja!"

    # say L113 pla
    old "Pfff... "
    new "Pfff..."

    # say L124 bel
    old "Hmm, Billie has really big boobs, isn't she [pla]?"
    new "Hmm, Billie hat wirklich große Titten, oder [pla]?"

    # say L125 pla
    old "Ohh yeah..."
    new "Ohh ja..."

    # say L130 bel
    old "How does it feel to get your boobs sucked Billie?"
    new "Wie fühlt es sich an, wenn dir jemand die Brüste lutscht, Billie?"

    # say L131 bil
    old "I'm not gonna lie, it feels pretty nice."
    new "Ich lüge nicht, es fühlt sich ziemlich gut an."

    # say L137 bel
    old "Woahh, [pla] are you getting excited?"
    new "Woahh, [pla], du wirst ja richtig aufgeil."

    # say L138 bil
    old "Mmm, I'm really enjoying it..."
    new "Mmm, ich finde es echt toll..."

    # say L162 bil
    old "All right, I think is enough."
    new "Okay, ich denke, das reicht."

    # say L173 bel
    old "So Billie? Do you like that big dick in your mouth?"
    new "So Billie? Magst du diesen großen Schwanz in deinem Mund?"

    # say L175 bel
    old "Yeah, I bet you do. Just enjoy it."
    new "Klar, ich wette, dir gefällt es. Genieße es einfach."

    # say L181 bel
    old "Keep going, you have to do it well. Are you enjoying it [pla]?"
    new "Weiter so, du musst es gut machen. Bist du dabei [pla]?"

    # say L183 bel
    old "He's enjoying it Billie!"
    new "Er genießt es, Billie!"

    # say L184 bil
    old "Gulp."
    new "Schluck."

    # say L189 bil
    old "Slurrp, I- I can feel you getting even harder."
    new "Slurrp, ich- ich kann spüren, wie du noch härter wirst."

    # say L190 bel
    old "He's close Billie! Keep going!"
    new "Er kommt gleich Billie! Mach weiter so!"

    # say L215 bel
    old "That's it Billie! Just like that."
    new "Das ist es, Billie! Genau so."

    # say L216 pla
    old "Ahh! I- I'm cumming!"
    new "Ahh! I- Ich komme!"

    # say L221 bil
    old "Ugh, duuude, you came all in my mouth!"
    new "Ugh, duuude, du hast mir den ganzen Mund voll gekommen!"

    # say L222 bil
    old "And Belle had already told you to be careful!"
    new "Und Belle hatte dir doch schon gesagt, dass du vorsichtig sein sollst!"

    # say L223 pla
    old "S- sorry, I couldn't stop myself."
    new "S- sorry, ich konnte mich nicht zurückhalten."

    # say L224 bel
    old "Yeah, he does come a lot, doesn't he?"
    new "Ja, er kommt wirklich oft, oder?"

    # say L225 bil
    old "He does, anyway, help me clean myself."
    new "Na klar, hilf mir einfach, mich zu reinigen."

    # say L226 pla
    old "S- sure..."
    new "S-sicher..."

    # say L239 pla
    old "Oh God... [bil]..."
    new "Oh Gott... [bil]..."

    # say L240 bil
    old "Mmm... you taste even better than I remembered."
    new "Mmm... du schmeckst noch besser, als ich es in Erinnerung hatte."

    # say L241 pla
    old "This feels... insane."
    new "Das fühlt sich... wahnsinnig an."

    # say L242 bil
    old "Good. That's the point."
    new "Gut. Das ist ja genau der Sinn."

    # say L247 bil
    old "A little faster now..."
    new "Ein bisschen schneller jetzt..."

    # say L248 pla
    old "Yes... please... don't stop."
    new "Ja... bitte... hör nicht auf."

    # say L249 bil
    old "Your cock's throbbing... love feeling you like this."
    new "Dein Schwanz pocht... ich liebe es, dich so zu spüren."

    # say L254 bil
    old "Harder... give me more."
    new "Fester... gib mir mehr."

    # say L255 pla
    old "[bil]... I'm close..."
    new "[bil]... Ich komme..."

    # say L256 bil
    old "Yeah? Cum for me. Fill my mouth."
    new "Klar? Komm für mich. Füll meinen Mund."

    # say L257 pla
    old "Oh fuck... yes!"
    new "Oh Scheiße... ja!"

    # say L281 pla
    old "I- I'm cumming—!"
    new "I- Ich komme—!"

    # say L282 bil
    old "Mmm... give it all to me."
    new "Mmm... gib es mir alles."

    # say L283 bil
    old "Every drop... that's it."
    new "Jede Tropfen... genau."

    # say L290 pla
    old "That was... wow."
    new "Das war... wow."

    # say L291 bil
    old "Better?"
    new "Besser?"

    # say L292 pla
    old "Uhh, yeah, definetly, t- thank you..."
    new "Uhh, ja, definitiv, danke..."

    # say L293 bil
    old "Alright... we should clean up this mess before my grandma walks in."
    new "Okay... wir sollten dieses Chaos aufräumen, bevor meine Oma reinkommt."

    # say L294 pla
    old "Yeah... good idea."
    new "Ja... gute Idee."

    # say L306 pla
    old "Is this okay?"
    new "Ist das okay?"

    # say L307 bil
    old "Oh god, yeah... you're doing it right. Keep the technique."
    new "Oh Gott, ja... du machst das richtig. Bleib bei der Technik."

    # say L311 bil
    old "Faster now. Rub harder."
    new "Schneller jetzt. Reib fester."

    # say L312 pla
    old "You're so tight..."
    new "Du bist so eng..."

    # say L313 bil
    old "Deeper. D-don't stop-"
    new "Tiefer. D-du darfst nicht aufhören-"

    # say L317 bil
    old "Harder! I want to feel you deeper."
    new "Fester! Ich will dich tiefer spüren."

    # say L318 pla
    old "[bil]... you're pulsing..."
    new "[bil]... du pulsierst..."

    # say L319 bil
    old "Yes! I'm close!"
    new "Ja! Ich bin gleich soweit!"

    # say L320 pla
    old "Oh fuck..."
    new "Oh Scheiße..."

    # say L344 bil
    old "Oh God... that's it."
    new "Oh Gott... das ist es."

    # say L350 pla
    old "That was... intense."
    new "Das war... intensiv."

    # say L351 bil
    old "Phew... yeah, it was nice."
    new "Phew... ja, das war schön."

    # say L352 bil
    old "Better fingers?"
    new "Bessere Finger?"

    # say L353 pla
    old "Way better. Like they woke up."
    new "Viel besser. Als wären sie aufgewacht."

    # say L368 bil
    old "Mmm... feel better already?"
    new "Mmm... fühlt sich schon besser an?"

    # say L369 pla
    old "Yeah... tension's melting away."
    new "Ja... die Anspannung löst sich auf."

    # say L373 bil
    old "Good. Deeper now."
    new "Gut. Tiefer jetzt."

    # say L374 pla
    old "Fuck... yes."
    new "Scheiße... ja."

    # say L378 bil
    old "Cum for me. Let it all out."
    new "Komm für mich. Lass es alles raus."

    # say L379 pla
    old "I'm... close!"
    new "Ich bin... kurz davor!"

    # say L402 pla
    old "Ahh— cumming!"
    new "Ahh— komme!"

    # say L403 bil
    old "Mmm... that's it."
    new "Mmm... das ist es."

    # say L410 pla
    old "Wow... that was... intense."
    new "Wow... das war... intensiv."

    # say L411 bil
    old "Feeling better?"
    new "Geht's dir besser?"

    # say L412 pla
    old "Yeah, actually. A lot. Thanks, [bil]. Didn't think it'd work that well."
    new "Ja, eigentlich schon. Viel besser. Danke, [bil]. Hab nicht gedacht, dass es so gut funktioniert."

    # say L427 pla
    old "You're already tensing up... feel that?"
    new "Du spannst dich schon an... spürst du das?"

    # say L428 bil
    old "Mmm—keep it slow—notes steady... don't rush me yet..."
    new "Mmm—mach langsam—Noten ruhig... lass mich nicht drängeln..."

    # say L432 bil
    old "{i}Now every step... just pulls me down...{/i}"
    new "{i}Jetzt bei jedem Schritt... zieht es mich runter...{/i}"

    # say L433 pla
    old "Heart's racing already, huh? Your voice is still holding strong."
    new "Das Herz rast schon, hm? Deine Stimme hält aber noch durch."

    # say L434 bil
    old "Yes—fuck—deeper now—everything I wanted... slips right through my hands..."
    new "Ja—Scheiße—tiefer jetzt—alles, was ich wollte... gleitet mir durch die Finger..."

    # say L438 bil
    old "{i}And I’m still breathing... but I don’t... understand—{/i}"
    new "{i}Und ich atme noch... aber ich verstehe nicht—{/i}"

    # say L439 bil
    old "{i}Ahh—fuck—keep going—don't stop—{/i}"
    new "{i}Ahh—fick—mach weiter—hör nicht auf—{/i}"

    # say L440 pla
    old "You're pulsing around my fingers... you're so close, [bil]."
    new "Du pulsierst um meine Finger... du bist so nah dran, [bil]."

    # say L441 bil
    old "Harder—yes—right there—I'm—I'm gonna—"
    new "Fester—ja—genau da—Ich—Ich werd—"

    # say L464 bil
    old "I-I'm—cumming—fuck—yes—!"
    new "Ich—Ich komme—Scheiße—ja—!"

    # say L465 bil
    old "Nngh... holy shit..."
    new "Nngh... verdammt..."

    # say L473 pla
    old "... Damn..."
    new "... Scheiße..."

    # say L474 bil
    old "Okay... that... was something else."
    new "Okay... das... war was anderes."

    # say L475 pla
    old "You... held it together. Mostly."
    new "Du... hast dich zusammengerissen. Zum Großteil."

    # say L476 bil
    old "Mostly? I felt the slip at the peak... but I pulled it back. That's progress."
    new "Meistens? Ich hab den Riss gespürt, als es hochging... aber ich hab ihn zurückgezogen. Das ist Fortschritt."

    # say L477 bil
    old "This method is insane... but it might just work."
    new "Diese Methode ist verrückt... aber sie könnte funktionieren."

    # say L478 pla
    old "Yeah... insane in the best way."
    new "Ja... wahnsinnig auf die beste Art."

    # say L490 bil
    old "Do you like when I ride you like this?"
    new "Magst du es, wenn ich dich so reite?"

    # say L491 pla
    old "Fuck yes... you’re perfect..."
    new "Fuck ja... du bist perfekt..."

    # say L492 bil
    old "Good boy... keep looking at me."
    new "Guter Junge... sieh mich weiter an."

    # say L496 bil
    old "Faster now... bounce with me."
    new "Schneller jetzt... spring mit mir."

    # say L497 pla
    old "Bil... you’re gonna make me lose it..."
    new "Bil... du bringst mich noch um den Verstand..."

    # say L498 bil
    old "Not yet. I want to feel you throb inside me."
    new "Noch nicht. Ich will dich zucken in mir spüren."

    # say L502 bil
    old "Harder— give it to me—"
    new "Fester – gib es mir –"

    # say L503 pla
    old "I’m so close..."
    new "Ich bin so nah..."

    # say L504 bil
    old "Inside! Cum inside me-"
    new "Drinnen! Komm in mir-"

    # say L527 bil
    old "Yes— fill me up—!"
    new "Ja— füll mich aus—!"

    # say L528 pla
    old "Ahh— fuck— cumming— !"
    new "Ahh— fick— komme—!"

    # say L529 bil
    old "Nngh... that’s it... every drop..."
    new "Nngh... das ist es... jeden Tropfen..."

    # say L536 bil
    old "Mmm... good boy. That felt so damn good."
    new "Mmm... gut gemacht. Das hat sich verdammt gut angefühlt."

    # say L537 pla
    old "That was... insane."
    new "Das war... Wahnsinn."

    # say L538 bil
    old "Heh. Way better than any vocal warm up, right?"
    new "Heh. Viel besser als jede Stimmaufwärmung, oder?"

    # say L539 bil
    old "But we gotta stop... grandma could walk in any second."
    new "Aber wir müssen aufhören... Oma könnte jeden Moment reinkommen."

    # say L540 pla
    old "Right, right..."
    new "Stimmt, stimmt..."

    # say L553 bil
    old "Mmm... feel how soft and warm my ass is rubbing all over your hard cock?"
    new "Mmm... spürst du, wie weich und warm mein Arsch auf deinem harten Schwanz reibt?"

    # say L554 pla
    old "Fuck... Billie... that feels incredible..."
    new "Fuck... Billie... das fühlt sich unglaublich an..."

    # say L558 bil
    old "You're throbbing so much between my cheeks. My ass turns you on that bad, huh?"
    new "Du pulsierst so sehr zwischen meinen Backen. Mein Arsch macht dich so an, hm?"

    # say L559 pla
    old "Yes... don't stop..."
    new "Ja... hör nicht auf..."

    # say L563 bil
    old "Do you like feeling my ass? Then cum for me. I want you to finish all over it."
    new "Magst du das Gefühl meines Arsches? Dann komm für mich. Ich will, dass du dich überall auf mir ergießt."

    # say L564 pla
    old "Oh God, Billie, don't stop..."
    new "Oh Gott, Billie, hör nicht auf..."

    # say L587 pla
    old "Ahh— fuck— I'm cumming—!"
    new "Ahh— Scheiße— ich komme—!"

    # say L588 bil
    old "Mmm... yes, that's it. Cum all over my ass."
    new "Mmm... ja, genau so. Spritz alles auf meinen Arsch."

    # say L594 bil
    old "Heh... look at the mess you made on me. Someone really liked this outfit."
    new "Heh... schau dir das Chaos an, das du angerichtet hast. Jemand hat dieses Outfit wirklich gemocht."

    # say L595 pla
    old "That was insane... we could've been caught..."
    new "Das war verrückt... wir hätten erwischt werden können..."

    # say L596 bil
    old "But we weren't. Now help me clean up before that lazy bitch looks up from her phone."
    new "Aber wir wurden nicht. Jetzt hilf mir sauber zu werden, bevor diese faule Schlampe ihr Handy hochschaut."

    # say L607 bil
    old "Mmm... feel how soft and warm they are wrapping all around your cock?"
    new "Mmm... spür, wie weich und warm sie sich um deinen Schwanz schließen?"

    # say L608 pla
    old "Fuck... Billie... your tits feel amazing..."
    new "Fuck... Billie... deine Titten fühlen sich unglaublich an..."

    # say L612 bil
    old "You're throbbing so much between them. You love fucking my tits, don't you?"
    new "Du pulsierst so sehr zwischen ihnen. Du liebst es, meine Titten zu ficken, oder?"

    # say L617 bil
    old "That's it... fuck my tits harder. I want you to cum all over them."
    new "Das ist es... fick meine Titten härter. Ich will, dass du über sie abspritzt."

    # say L618 pla
    old "Billie... I'm gonna cum..."
    new "Billie... ich komme..."

    # say L619 bil
    old "Do it. Cover my tits. I want to feel your hot load on me."
    new "Mach es. Bedecke meine Titten. Ich will deinen heißen Saft auf mir spüren."

    # say L642 pla
    old "Ahh— fuck— I'm cumming!"
    new "Ahh— Scheiße— ich komme!"

    # say L643 bil
    old "Mmm... yes, give it to me. Cum all over my tits."
    new "Mmm... ja, gib es mir. Spritz alles auf meine Titten."

    # say L650 bil
    old "Heh... look at you. Made another mess on me."
    new "Heh... schau dir das an. Hast du wieder einen Sauhaufen auf mir gemacht."

    # say L651 bil
    old "Guess my tits are too much for you."
    new "Scheint, als wären meine Titten zu viel für dich."

    # say L652 bil
    old "It's nice you like them so much..."
    new "Es ist schön, dass dir die so gut gefallen..."

    # say L664 bil
    old "Mmm... slow... just like this... I want to feel every inch of you."
    new "Mmm... langsam... genau so... ich will jeden Zentimeter von dir spüren."

    # say L665 pla
    old "You feel so good... so warm..."
    new "Du fühlst dich so gut... so warm..."

    # say L666 bil
    old "Mmm... deeper... I need you inside me... all of you."
    new "Mmm... tiefer... ich brauche dich in mir... ganz und gar."

    # say L670 bil
    old "Ahh... yes... right there..."
    new "Ahh... ja... genau da..."

    # say L671 pla
    old "Fuck... Billie... you’re perfect."
    new "Fuck... Billie... du bist perfekt."

    # say L672 bil
    old "Don’t hold back... I want all of you tonight... I need this."
    new "Halt dich nicht zurück... ich will alles von dir heute Nacht... ich brauche das."

    # say L676 bil
    old "Harder... don’t stop... I want to feel you lose control..."
    new "Fester... hör nicht auf... ich will spüren, wie du die Kontrolle verlierst..."

    # say L677 pla
    old "I’m getting so close..."
    new "Ich bin schon so nah dran..."

    # say L678 bil
    old "Inside me... cum inside me... I want to feel you let go completely."
    new "In mir... spritz in mir ab... ich will dich vollkommen loslassen spüren."

    # say L701 pla
    old "Billie— I’m cumming—!"
    new "Billie— ich komme—!"

    # say L702 bil
    old "Yes— fill me up... give me everything..."
    new "Ja— füll mich aus... gib mir alles..."

    # say L708 bil
    old "Mmm... I can still feel you pulsing inside me..."
    new "Mmm... Ich spüre dich immer noch in mir pulsieren..."

    # say L709 pla
    old "That was... incredible."
    new "Das war... unglaublich."

    # say L710 bil
    old "That wasn’t everything. Tonight I don’t want to stop until you’ve given me all of you."
    new "Das war noch nicht alles. Heute Nacht will ich nicht aufhören, bis du mir alles gegeben hast."

    # say L711 bil
    old "Come here... don’t pull out yet."
    new "Komm her... zieh dich noch nicht zurück."

    # say L712 bil
    old "I want to feel you again... deeper this time."
    new "Ich will dich wieder spüren... diesmal tiefer."

    # say L728 bil
    old "Slow... just like that... I love feeling you fill me completely."
    new "Langsam... genau so... ich liebe es, dich vollständig in mir zu spüren."

    # say L729 pla
    old "God, Billie... you’re so tight... so warm..."
    new "Gott, Billie... du bist so eng... so warm..."

    # say L730 bil
    old "Mmm... keep your eyes on me... I know how much you love looking at my tits like this."
    new "Mmm... halt deinen Blick auf mich gerichtet... ich weiß, wie sehr du es liebst, meine Titten so zu sehen."

    # say L731 bil
    old "Look at them bouncing for you... they’re all yours tonight."
    new "Schau sie an, wie sie für dich hüpfen... sie gehören heute Nacht ganz dir."

    # say L735 bil
    old "Ahh... yes... right there... harder now..."
    new "Ahh... ja... genau da... härter jetzt..."

    # say L736 pla
    old "You feel amazing... I can’t get enough of you."
    new "Du fühlst dich unglaublich... ich kann nicht genug von dir kriegen."

    # say L737 bil
    old "Don’t hold back... I need you to lose yourself in me tonight."
    new "Halt dich nicht zurück... ich brauche, dass du dich in mir verlierst heute Nacht."

    # say L741 bil
    old "Faster... fuck me harder... I want everything you have left."
    new "Schneller... fick mich härter... ich will alles, was du noch hast."

    # say L742 pla
    old "Billie... I’m so close again..."
    new "Billie... ich bin schon wieder so nah..."

    # say L743 bil
    old "Then give it to me... cum inside me again... fill me up."
    new "Dann gib es mir... spritz in mir ab... fülle mich aus."

    # say L767 bil
    old "Yes— deep inside... let go... I want to feel every drop."
    new "Ja— tief drin... lass los... ich will jeden Tropfen spüren."

    # say L773 bil
    old "Mmm... I feel you throbbing again... so warm..."
    new "Mmm... ich spüre dich wieder pulsieren... so warm..."

    # say L774 bil
    old "I don’t want this night to end..."
    new "Ich will, dass diese Nacht nie endet..."

    # say L775 pla
    old "Neither do I."
    new "Ich auch nicht."

    # say L776 bil
    old "But tomorrow is going to be a long day..."
    new "Aber morgen wird ein langer Tag..."

    # say L777 pla
    old "Yeah... I know."
    new "Ja... ich weiß."

    # say L778 bil
    old "I hate saying it, but we both need to rest."
    new "Ich hasse es zu sagen, aber wir beide müssen uns ausruhen."

    # say L779 pla
    old "You’re right, we better get dressed in case your grandma shows up."
    new "Du hast recht, wir sollten uns besser anziehen, falls deine Oma auftaucht."

    # say L792 bil
    old "Ahh... just like that..."
    new "Ahh... genau so..."

    # say L793 pla
    old "Focus on my mouth... nothing else matters right now."
    new "Konzentrier dich auf meinen Mund... im Moment zählt nichts anderes."

    # say L797 bil
    old "Yes... right there... don’t stop..."
    new "Ja... genau da... hör nicht auf..."

    # say L798 pla
    old "You’re getting so wet... that’s it, let go."
    new "Du wirst so nass... genau so, lass los."

    # say L802 bil
    old "Harder... use your tongue... I’m so close..."
    new "Fester... benutz deine Zunge... ich bin so nah..."

    # say L804 bil
    old "Ahh— I’m— I’m cumming—!"
    new "Ahh— ich— ich komme—!"

    # say L832 bil
    old "Fuck... that actually worked..."
    new "Scheiße... das hat tatsächlich funktioniert..."

    # say L833 pla
    old "You look a lot calmer now."
    new "Du siehst jetzt viel ruhiger aus."

    # say L834 bil
    old "I do... thank you. I really needed that."
    new "Ich tu's... danke. Ich hab das wirklich gebraucht."

    # say L835 pla
    old "I don’t want to freak you out, but the contest already started. We gotta get on stage."
    new "Ich will dich nicht erschrecken, aber der Wettbewerb hat schon angefangen. Wir müssen auf die Bühne."

    # say L836 bil
    old "Okay, okay... yeah, I feel way better now. Let’s go."
    new "Okay, okay... ja, ich fühle mich viel besser jetzt. Lass uns gehen."

    # say L848 bil
    old "Mmm... feel how soft they are wrapping around you?"
    new "Mmm... spürst du, wie weich sie sich um dich schließen?"

    # say L849 pla
    old "Fuck... Billie... they feel perfect..."
    new "Fuck... Billie... sie fühlen sich perfekt an..."

    # say L853 bil
    old "You’re throbbing so much between them... you love fucking my tits, don’t you?"
    new "Du pulsierst so sehr zwischen ihnen... du liebst es, meine Titten zu ficken, oder?"

    # say L854 pla
    old "Yes... don’t stop..."
    new "Ja... hör nicht auf..."

    # say L858 bil
    old "Harder... fuck them... I want you to cum all over them."
    new "Fester... fick sie... ich will, dass du überall auf ihnen kommst."

    # say L859 pla
    old "Billie... I’m so close..."
    new "Billie... ich bin so kurz davor..."

    # say L860 bil
    old "Then do it. Cover me."
    new "Dann mach es. Bedecke mich."

    # say L883 pla
    old "Ahh— fuck— I’m cumming—!"
    new "Ahh— Scheiße— ich komme—!"

    # say L884 bil
    old "Mmm... yes, give me every drop... paint them nice and white."
    new "Mmm... ja, gib mir jeden Tropfen... mal sie schön weiß."

    # say L891 bil
    old "Heh... look at the mess you made."
    new "Heh... schau dir das Chaos an, das du angerichtet hast."

    # say L893 bil
    old "We’re not done yet."
    new "Wir sind noch nicht fertig."

    # say L894 bil
    old "Come here... I want you inside me again."
    new "Komm her... ich will dich wieder in mir spüren."

    # say L906 bil
    old "Slow at first... I want to feel all of you."
    new "Langsam zuerst... ich will alles von dir spüren."

    # say L916 bil
    old "Mmm... yes... just like that..."
    new "Mmm... ja... genau so..."

    # say L917 pla
    old "You feel so good... so tight..."
    new "Du fühlst dich so gut... so eng..."

    # say L921 bil
    old "Harder... don’t hold back..."
    new "Fester... halt dich nicht zurück..."

    # say L922 pla
    old "Billie... you’re perfect."
    new "Billie... du bist perfekt."

    # say L926 bil
    old "Fuck me... I want everything you have left..."
    new "Fick mich... ich will alles, was du noch hast..."

    # say L927 pla
    old "I’m gonna cum again..."
    new "Ich komme nochmal..."

    # say L928 bil
    old "Inside me... fill me up one more time."
    new "In mir... füll mich noch einmal aus."

    # say L952 bil
    old "Yes... give it all to me..."
    new "Ja... gib es mir alles..."

    # say L959 bil
    old "Mmm... I can feel you... so warm inside..."
    new "Mmm... ich kann dich spüren... so warm in mir..."

    # say L960 pla
    old "I don’t think I can move..."
    new "Ich glaube, ich kann mich nicht bewegen..."

    # say L961 bil
    old "Then don’t. Stay right here with me."
    new "Dann nicht. Bleib einfach hier bei mir."

    # say L962 bil
    old "Tonight... everything feels right."
    new "Heute Nacht... alles fühlt sich richtig an."

    # say L963 pla
    old "We did it. Together."
    new "Wir haben es geschafft. Zusammen."

    # say L964 bil
    old "Yeah... we really did."
    new "Ja... wir haben es wirklich getan."

    # say L965 bil
    old "({i}Tomorrow the world will keep spinning... but right now, this is all I need.{/i})"
    new "{i}Morgen wird die Welt weiterdrehen... aber im Moment ist das alles, was ich brauche.{/i}"

    # say L978 bil
    old "Mmm... circle my clit first. Gentle, like I showed you."
    new "Mmm... kreis mein Kitzler zuerst. Sanft, wie ich es dir gezeigt habe."

    # say L979 pla
    old "Like this?"
    new "So?"

    # say L980 bil
    old "Deeper. Slide one in and curl it. You already know the spot."
    new "Tiefer. Schieb einen rein und kreuze ihn. Du weißt schon, wo es hin muss."

    # say L984 bil
    old "Add another—fuck—yes, right there. You’re getting so good at this."
    new "Noch einen—fick—ja, genau da. Du wirst echt gut darin."

    # say L988 bil
    old "Harder, baby. Make me cum all over your hand."
    new "Fester, Baby. Mach mich kommen, über deine Hand."

    # say L1011 bil
    old "I’m—cumming—fuck—!"
    new "Ich—komme—Scheiße—!"

    # say L1017 bil
    old "Shit... your fingers really kept perfect rhythm this time."
    new "Scheiße... deine Finger haben dieses Mal wirklich perfekten Rhythmus gehalten."

    # say L1018 bil
    old "You’re getting faster and way more precise every time. I can feel it."
    new "Du wirst immer schneller und präziser. Ich spüre es."

    # say L1019 bil
    old "This is exactly the kind of dexterity we need... both on stage and off it."
    new "Das ist genau die Fingerfertigkeit, die wir brauchen... sowohl auf der Bühne als auch außerhalb."

    # say L1034 bil
    old "{i}I used to float above the ground...{/i}"
    new "{i}Ich schwebte mal über dem Boden...{/i}"

    # say L1035 pla
    old "You’re already dripping..."
    new "Du bist schon nass..."

    # say L1039 bil
    old "Deeper—fuck—keep the rhythm steady."
    new "Tiefer—fick—halt das Tempo konstant."

    # say L1043 bil
    old "Faster—make me cum while I try to hold the note—ahh—!"
    new "Schneller—bring mich zum Kommen, während ich versuche, die Note zu halten—ahh—!"

    # say L1066 bil
    old "I’m cumming—fuck—yes—!"
    new "Ich komme—Scheiße—ja—!"

    # say L1073 bil
    old "Nngh... your tongue is getting way too good at this."
    new "Nngh... deine Zunge wird echt immer besser darin."

    # say L1074 bil
    old "You held me through it perfectly. That’s the kind of control I need."
    new "Du hast mich perfekt durch das Ganze gehalten. Das ist genau die Kontrolle, die ich brauche."

    # say L1075 bil
    old "Every time you do this my voice gets stronger under pressure... and I get to enjoy that mouth of yours."
    new "Jedes Mal, wenn du das machst, wird meine Stimme unter Druck stärker... und ich darf deinen Mund genießen."

    # say L1088 bil
    old "Mmm... look at you. Already so hard just from asking."
    new "Mmm... schau dir an. Schon so hart nur vom Fragen."

    # say L1089 pla
    old "Billie... that feels so good..."
    new "Billie... das fühlt sich so gut an..."

    # say L1094 bil
    old "Deeper now... I want to feel every throb."
    new "Tiefer jetzt... ich will jeden Schlag spüren."

    # say L1095 pla
    old "Fuck... you’re way too good at this."
    new "Scheiße... du bist echt gut darin."

    # say L1100 bil
    old "Don’t hold back. Cum for me. Let me give you the motivation you need."
    new "Halte dich nicht zurück. Komm für mich. Lass mich dir den Ansporn geben, den du brauchst."

    # say L1101 pla
    old "I’m— I’m close...!"
    new "Ich bin— ich bin gleich dran...!"

    # say L1126 bil
    old "Mmm... every drop. Good boy."
    new "Mmm... jeden Tropfen. Guter Junge."

    # say L1133 bil
    old "Heh... feeling more motivated already?"
    new "Heh... schon motivierter?"

    # say L1134 bil
    old "Your confidence always shoots up after this. I can tell."
    new "Dein Selbstbewusstsein steigt immer danach. Das merke ich."

    # say L1135 bil
    old "Come back whenever you need some real motivation again... I’ll be waiting."
    new "Komm wieder, wenn du mal wieder richtig motiviert werden musst... Ich warte auf dich."


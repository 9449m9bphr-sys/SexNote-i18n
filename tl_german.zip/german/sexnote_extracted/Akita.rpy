# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Akita.rpy
translate german strings:

    # menu L36 
    old "Talk to her"
    new "Mit ihr reden"

    # say L39 aki
    old "Hello, welcome to Jamliz Corporation! How can I help you?"
    new "Hallo, willkommen bei Jamliz Corporation! Wie kann ich dir helfen?"

    # say L41 pla
    old "Hi, nice to meet you. My name is [pla]. I was sent by my [mo2rel], to give you these documents..."
    new "Hi, nett dich kennenzulernen. Mein Name ist [pla]. Meine [mo2rel] hat mich geschickt, um dir diese Unterlagen zu bringen..."

    # say L44 aki
    old "Ohh right. She told me she was going to send a delivery boy with those documents. Perfect... Thank you very much!"
    new "Ohh richtig. Sie hat mir gesagt, dass sie einen Boten mit den Dokumenten schicken würde. Perfekt... Danke schön!"

    # say L46 pla
    old "Delivery boy? Ok, well... I think that's it... right?"
    new "Paketer? Okay, dann... glaub ich, das wär's... oder?"

    # say L48 aki
    old "Yes, and by the way, my name is Akita nice to meet you..."
    new "Ja, und übrigens, mein Name ist Akita, nett dich kennenzulernen..."

    # say L50 pla
    old "Oh, yes, I'm [pla]. The pleasure is mine..."
    new "Oh, ja, ich bin [pla]. Die Freude ist ganz meinerseits..."

    # say L52 aki
    old "Yes, yes you already told me... Hahaha."
    new "Ja, ja, das hast du mir schon gesagt... Hahaha."

    # say L54 pla
    old "Oh... right, of course, my bad... Well, it was nice to meet you, see you later..."
    new "Oh... stimmt, klar, sorry... Na ja, es war schön, dich kennenzulernen, bis später..."

    # say L56 aki
    old "See you later, [pla]."
    new "Bis später, [pla]."

    # say L68 aki
    old "Oh, hi [pla], Mrs. [mo2] sent you with more documents or did you come to visit me?"
    new "Oh, hallo [pla], hat Mrs. [mo2] dich mit mehr Dokumenten geschickt oder bist du gekommen, um mich zu besuchen?"

    # say L70 pla
    old "Well, Mr. [mo2] sent me..."
    new "Na, Mr. [mo2] hat mich geschickt..."

    # say L73 aki
    old "Hahaha, I'm just messing with you, perfect... Thank you very much."
    new "Hahaha, ich mach nur Spaß, perfekt... Danke schön."

    # say L75 pla
    old "Well... You're welcome, see you later..."
    new "Na ja... Gerne geschehen, bis später..."

    # say L77 aki
    old "Goodbye, handsome."
    new "Tschüss, Schöner."

    # say L88 pla
    old "I shouldn't bother her. She's working."
    new "Ich sollte sie nicht stören. Sie arbeitet."

    # menu L100 
    old "Use Agamoto Eye 1"
    new "Agamoto Auge verwenden"

    # menu L104 
    old "Use Agamoto Eye 2"
    new "Agamoto Auge 2 verwenden"

    # menu L108 
    old "Use Agamoto Eye 3"
    new "Agamoto Auge 3 verwenden"

    # say L115 pla
    old "No, no. Sorry. I was just walking around."
    new "Nein, nein. Tut mir leid. Ich war nur rumlaufen."

    # menu L117 
    old "Back"
    new "Zurück"


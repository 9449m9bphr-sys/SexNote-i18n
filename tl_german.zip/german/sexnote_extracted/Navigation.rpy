# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Mechanics/Navigation.rpy
translate german strings:

    # say L361 pla
    old "I shouldn't for now."
    new "Ich sollte jetzt nicht."

    # say L372 pla
    old "I shouldn't for now"
    new "Ich sollte jetzt nicht."

    # say L417 pla
    old "I shouldn't now"
    new "Ich sollte jetzt nicht"

    # say L953 pla
    old "The school is closed. I should just go home."
    new "Die Schule ist geschlossen. Ich sollte einfach nach Hause gehen."

    # say L1248 pla
    old "I shouldn't enter right now. I don't have any appointments..."
    new "Ich sollte jetzt nicht reingehen. Ich habe keine Termine..."


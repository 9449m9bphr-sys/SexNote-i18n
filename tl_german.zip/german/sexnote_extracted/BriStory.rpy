# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/BriStory.rpy
translate german strings:

    # say L11 pla
    old "I can't believe they were getting freaky in the living room."
    new "Ich fass es nicht, dass die beiden im Wohnzimmer rumgemacht haben."

    # say L13 pla
    old "I know they are married but... they should do that in their room..."
    new "Ich weiß, dass sie verheiratet sind, aber... das sollten sie in ihrem Zimmer machen..."

    # say L15 pla
    old "Anyway... let's take a look at this weird book."
    new "Na ja... lass uns mal dieses seltsame Buch anschauen."

    # say L17 pla
    old "Let's see what it says..."
    new "Lass uns sehen, was drinsteht..."

    # say L19 pla
    old "Expergiscimini defensoris librum... The hell does that mean? Did that airplane came from China?"
    new "Erwache, Verteidiger des Buches... Was zur Hölle soll das bedeuten? Hat dieses Flugzeug etwa aus China gekommen?"

    # say L28 pla
    old "What the fuck! What is this?!"
    new "Was zur Hölle! Was ist das?!"

    # say L29 sap
    old "Qui audet excitare me!"
    new "Wer wagt es, mich zu wecken!"

    # say L30 pla
    old "Oh my God! Please don't hurt me. I'm too young to die."
    new "Oh mein Gott! Bitte tu mir nichts. Ich bin zu jung, um zu sterben."

    # say L31 sap
    old "Latina loqui tibi."
    new "Ich spreche Lateinisch mit dir."

    # say L32 pla
    old "What?  I- I don't understand. Just please don't kill me... I didn't do anything... This thing just fell from an airplane..."
    new "Was? I- Ich verstehe das nicht. Bitte tu mir nichts... Ich hab doch nichts getan... Das Ding ist einfach aus einem Flugzeug gefallen..."

    # say L33 sap
    old "Huh? What fell from an airplane?"
    new "Huh? Was ist vom Flugzeug gefallen?"

    # say L34 pla
    old "What? Oh, um, yeah! The book... This book fell from an airplane."
    new "Was? Oh, äh, ja! Das Buch... Dieses Buch ist aus einem Flugzeug gefallen."

    # say L35 sap
    old "Oooh, hehe. Let's start from the beginning, shall we?"
    new "Oooh, hehe. Lass uns am Anfang beginnen, okay?"

    # say L36 sap
    old "Nice to meet you!  My name is Brixxida."
    new "Schön, dich kennenzulernen! Mein Name ist Brixxida."

    # say L42 pla
    old "Bri... xxi... da? Da fuck? Do you speak English?"
    new "Bri... xxi... da? Was zur Hölle? Sprichst du Englisch?"

    # say L43 bri
    old "Well, yes! I'm speaking it now. Hehe. I can actually speak all human languages..."
    new "Na klar! Ich spreche es gerade. Hehe. Eigentlich kann ich alle menschlichen Sprachen..."

    # say L45 pla
    old "Human languages? That's a weird way to say it. What exactly are you?"
    new "Menschensprachen? Das ist eine komische Art, es zu sagen. Was bist du genau?"

    # say L46 bri
    old "I'm the protective shinigami of the book you have there."
    new "Ich bin der schützende Shinigami des Buches, das du da hast."

    # say L49 pla
    old "OH FUCK! A shinigami? Oh my God..."
    new "OH SCHOSS! Ein Shinigami? Oh mein Gott..."

    # say L50 pla
    old "I'm so sorry, miss shinigami lady. I just found this on the ground and I picked it up. Brought it home. It looked cool."
    new "Entschuldigung, Shinigami-Frau. Ich hab’s einfach auf der Straße gefunden und mitgenommen. Hat cool ausgesehen."

    # say L52 pla
    old "I didn't mean to-"
    new "Ich wollte nicht-"

    # say L53 bri
    old "Calm down, human. Hehe. If you were the one who found and opened the book, it means that you are the 'chosen One'."
    new "Beruhige dich, Mensch. Hehe. Wenn du das Buch gefunden und geöffnet hast, bedeutet das, dass du der \"Auserwählte\" bist."

    # say L56 bri
    old "That's right!  And now the book belongs to you. And that also means I now belong to you. Hehe"
    new "Stimmt genau! Und jetzt gehört das Buch dir. Und das bedeutet auch, dass ich dir gehöre. Hehe"

    # say L58 pla
    old "What? You belong to me?  That means you are not going to kill me?"
    new "Was? Du gehörst mir? Das bedeutet, du wirst mich nicht umbringen?"

    # say L59 bri
    old "No, of course not. Why would you think that?"
    new "Nein, natürlich nicht. Warum solltest du das denken?"

    # say L61 pla
    old "Because you look like a monster about to devour me."
    new "Weil du wie ein Monster aussiehst, das mich verschlingen will."

    # say L62 bri
    old "Oh? Sorry about that."
    new "Oh? Tut mir leid dafür."

    # say L68 bri
    old "...Is this form better? Hehe."
    new "...Ist diese Form besser? Hehe."

    # say L77 mo2
    old "Why are you making that face, [pla]?"
    new "Warum machen Sie dieses Gesicht, [pla]?"

    # say L79 pla
    old "[mo2]... It is not what it looks like… I can explain... she is... naked... but she is... a shinigami-"
    new "[mo2]... Das ist nicht so, wie es aussieht… Ich kann das erklären... sie ist... nackt... aber sie ist... eine Shinigami-"

    # say L81 mo2
    old "What?! What are you talking about? Were you watching porn again?"
    new "Was?! Wovon redest du? Hast du wieder Pornos geguckt?"

    # say L83 pla
    old "What? Porn... No. I was just-"
    new "Was? Porno... Nein. Ich war gerade-"

    # say L85 mo2
    old "Hmm... probably were. You fucking pervert... I'll just have your [mo1rel] talk to you about this."
    new "Hmm... wahrscheinlich schon. Du verdammter Perversling... Ich lass deinen [mo1rel] sich damit befassen."

    # say L87 mo2
    old "Finish whatever you were doing."
    new "Was immer du da getan hast, beenden."

    # say L94 pla
    old "What the hell? Didn't she see you?"
    new "Was zum Teufel? Hat sie dich etwa nicht gesehen?"

    # say L104 bri
    old "Only you can see or hear me... And she called you [pla]? Is that your name?"
    new "Nur du kannst mich sehen oder hören... Und sie hat dich [pla] genannt? Ist das dein Name?"

    # say L105 pla
    old "Yes, that's my name. And-um, why are you naked???"
    new "Ja, das ist mein Name. Und-äh, warum bist du nackt???"

    # say L107 bri
    old "Oh, I'm sorry! Hehe. I took human form to be more familiar to you, but I forgot that humans cover their bodies with 'clothing'."
    new "Oh, entschuldige! Hehe. Ich habe menschliche Form angenommen, um dir vertrauter zu sein, aber ich habe vergessen, dass Menschen ihre Körper mit „Kleidung“ bedecken."

    # say L113 pla
    old "Couldn't find anything that covers you a little bit more, huh? But at least nobody can see you. Now tell me again, who are you exactly?"
    new "Konntest du nichts finden, das dich ein bisschen mehr bedeckt? Aber zumindest kann dich niemand sehen. Erzähl mir noch mal, wer du genau bist."

    # say L115 bri
    old "I am Brixxida! A shinigami. I can shift and adapt to the form of any species, although my true form is this... "
    new "Ich bin Brixxida! Eine Shinigami. Ich kann mich in die Form jeder Spezies verwandeln, obwohl meine wahre Form diese ist..."

    # say L120 bri
    old "...I am now much smaller, but I like being this size. Much more comfortable. Hehe"
    new "...Ich bin jetzt viel kleiner, aber mir gefällt diese Größe. Viel bequemer. Hehe"

    # say L128 pla
    old "Ok, ok. I get it now. I'm going crazy. This isn't real. It's a dream! Yeah, that's it! It's a dream..."
    new "Ok, ok. Ich hab's kapiert. Ich spinne. Das ist nicht echt. Es ist ein Traum! Ja, genau! Es ist ein Traum..."

    # say L130 pla
    old "I fell asleep in class and soon I'm going to wake up... hmmm... I am going to wake up now.... hmmm."
    new "Ich bin im Unterricht eingeschlafen und werde gleich aufwachen... hmm... ich werde jetzt aufwachen... hmm."

    # say L134 pla
    old "I'm trying to wake up from this dream."
    new "Ich versuche, aus diesem Traum aufzuwachen."

    # say L136 bri
    old "You look wide awake to me, [pla]."
    new "Du siehst mir aber wach aus, [pla]."

    # say L138 pla
    old "That's right!  I'm too tired, so I should rest. And tomorrow I will be back to normal."
    new "Stimmt! Ich bin zu müde, also sollte ich mich ausruhen. Und morgen bin ich wieder der Alte."

    # say L140 pla
    old "Yes, yes. I'm going to sleep... "
    new "Ja, ja. Ich geh schlafen..."

    # say L142 bri
    old "Ok! Goodnight. Hehe."
    new "Ok! Gute Nacht. Hehe."

    # say L148 pla
    old "Hmm... what a weird ass dream. I gotta lay off playing so many weird visual novels..."
    new "Hmm... was für ein seltsamer Traum. Ich muss mit den komischen Visual Novels aufhören..."

    # say L153 bri
    old "What are visual novels?"
    new "Was sind Visual Novels?"

    # say L156 pla
    old "Oh shit!  You... and you're naked again!"
    new "Oh Scheiße! Du... und du bist wieder nackt!"

    # say L158 bri
    old "Oh, my mistake.  I'm sorry. You humans are very dramatic about this... "
    new "Oh, mein Fehler. Entschuldigung. Ihr Menschen seid in solchen Dingen wirklich sehr dramatisch..."

    # say L164 pla
    old "Ok, ok. Just explain to me, Brixxida, why did the book fall from the sky?"
    new "Okay, okay. Erklär mir einfach, Brixxida, warum das Buch vom Himmel gefallen ist."

    # say L166 bri
    old "The book chooses you! Now you are part of a tradition of sorcerers that can use the book's magical powers."
    new "Das Buch wählt dich! Jetzt bist du Teil einer Tradition von Zauberern, die die magischen Kräfte des Buches nutzen können."

    # say L168 pla
    old "Magic powers, you say?...  The hell-?"
    new "Magische Kräfte, sagst du?... Was soll das denn sein?"

    # say L172 mo1
    old "[pla]?  Are you awake?  Who were you talking to?"
    new "[pla]? Sind Sie wach? Mit wem haben Sie gesprochen?"

    # say L181 pla
    old "Me? Oh, hmmm, nobody... I'm, uhh... preparing a speech for a class project..."
    new "Ich? Oh, hmmm, niemand... Ich bin, uhh... eine Rede für ein Klassenprojekt vorbereite..."

    # say L183 mo1
    old "Very good, [pla]!"
    new "Sehr gut, [pla]!"

    # say L185 mo1
    old "Listen, I want to talk to you about yesterday... About the living room."
    new "Hör zu, ich möchte mit dir über gestern sprechen... Über das Wohnzimmer."

    # say L187 pla
    old "Oh, [mo1], I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "Oh, [mo1], ich verstehe. Ich denke, es ist völlig normal, dass ihr ein Paar seid... Und du bist meine [mo1rel], du musst mir keine Erklärungen geben."

    # say L189 mo1
    old "I'm glad to hear that. But... I do want to apologize. We were a bit careless getting... Intimate in the living room."
    new "Ich bin froh, das zu hören. Aber... ich möchte mich entschuldigen. Wir waren etwas unvorsichtig, als wir im Wohnzimmer... intim wurden."

    # say L191 pla
    old "Don't worry about it. I actually think it's good that you keep the flame alive in your relationship over all these years."
    new "Mach dir keine Sorgen. Ich finde es sogar gut, dass ihr nach all den Jahren die Flamme in eurer Beziehung am brennen haltet."

    # say L193 mo1
    old "Do you really think that? Thank you so much for being so understanding, [pla]!"
    new "Finden Sie das wirklich? Vielen Dank für Ihr Verständnis, [pla]!"

    # say L195 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey, if you need me I will be in kitchen."
    new "Na gut, ich werde dich nicht länger stören. Lern weiter fleißig, Schatz, und wenn du mich brauchst, bin ich in der Küche."

    # say L204 pla
    old "Didn't you say they can't hear you?"
    new "Hast du nicht gesagt, dass sie dich nicht hören können?"

    # say L206 bri
    old "Nope! But they can hear you! Hehe."
    new "Nein! Aber sie können dich hören! Hehe."

    # say L208 pla
    old "Oh... Ok, that makes sense... but explain everything to me again."
    new "Oh... Okay, das ergibt Sinn... aber erklär mir alles noch mal."

    # say L210 bri
    old "What do you want to know, [pla]?"
    new "Was willst du wissen, [pla]?"

    # menu L220 
    old "Who are you?"
    new "Wer bist du?"

    # say L222 bri
    old "Again, I'm Brixxida, a shinigami. I am the protector of the book you found. Hehe."
    new "Wiederhole, ich bin Brixxida, eine Shinigami. Ich bin die Wächterin des Buches, das du gefunden hast. Hehe."

    # say L224 pla
    old "Ok. Now, where did you come from?"
    new "Ok. Und wo kommst du her?"

    # say L226 bri
    old "I come from another dimension. There, magic and power were natural, but that world has been destroyed."
    new "Ich komme aus einer anderen Dimension. Dort waren Magie und Macht ganz natürlich, aber diese Welt wurde zerstört."

    # say L228 pla
    old "So... you are a time traveler?"
    new "So... du bist eine Zeitreisende?"

    # say L230 bri
    old "What? No, no... I have been asleep for hundreds of years with a spell. But when you opened and read the book, I woke up."
    new "Was? Nein, nein... Ich war hundert Jahre lang mit einem Zauber in tiefem Schlaf. Aber als du das Buch geöffnet und gelesen hast, bin ich aufgewacht."

    # say L232 pla
    old "Ok, I think I'm starting to understand."
    new "Ok, ich glaube, ich fang an zu verstehen."

    # menu L239 
    old "What's this book about?"
    new "Worum geht es in diesem Buch?"

    # say L241 bri
    old "Well... this book contains all the knowledge of that magical world..."
    new "Na ja... dieses Buch enthält das gesamte Wissen jener magischen Welt..."

    # say L243 pla
    old "Eww. So, it's like a history book?"
    new "Eww. Also, ist es wie ein Geschichtsbuch?"

    # say L245 bri
    old "No, silly. This book contains specific spells and mantras that enable impressive magic powers beyond human understanding."
    new "Nein, dummkopf. Dieses Buch enthält spezifische Zauber und Mantras, die beeindruckende magische Kräfte jenseits menschlichen Verstehens ermöglichen."

    # say L247 pla
    old "Ok, I get that part."
    new "Ok, das verstehe ich."

    # menu L254 
    old "Magic, you say?"
    new "Magie, sagst du?"

    # say L256 bri
    old "Yes! The magic is a natural power that was lost, but you can get it and actually improve it..."
    new "Ja! Die Magie ist eine natürliche Kraft, die verloren gegangen ist, aber du kannst sie erlangen und sogar verbessern..."

    # say L258 pla
    old "Yeah, yeah. But... what can I do with magic?"
    new "Klar, klar. Aber... was kann ich mit Magie überhaupt machen?"

    # say L260 bri
    old "Actually, there are no limits with magic! It is the most powerful force in the known universe..."
    new "Eigentlich gibt es mit Magie keine Grenzen! Es ist die mächtigste Kraft im bekannten Universum..."

    # say L262 pla
    old "Really? Interesting..."
    new "Wirklich? Interessant..."

    # say L264 bri
    old "What else do you want to know, [pla]?"
    new "Was noch willst du wissen, [pla]?"

    # menu L269 
    old "What do I have to do?"
    new "Was muss ich tun?"

    # say L271 bri
    old "Well... you have to learn different spells and mantras to achieve powerful skills but... you will find everything in the book."
    new "Na ja... du musst verschiedene Sprüche und Mantras lernen, um mächtige Fähigkeiten zu erlangen, aber... du findest alles im Buch."

    # say L273 pla
    old "Imperium mens et feminam. What is that? Russian or some shit?"
    new "Imperium mens et feminam. Was ist das? Russisch oder so ein Quatsch?"

    # say L275 bri
    old "Actually, Latin is the language in which it was written... But don't worry, my job is to help the Chosen One translate..."
    new "Tatsächlich ist es Latein, die Sprache, in der es geschrieben wurde... Aber mach dir keine Sorgen, meine Aufgabe ist es, dem Auserwählten zu helfen, es zu übersetzen..."

    # say L277 pla
    old "Do I have to learn a lot of information about spells and mantras?"
    new "Muss ich viel über Sprüche und Mantras lernen?"

    # say L279 bri
    old "That's right! Hehe. And gaining a lot of power!"
    new "Stimmt! Hehe. Und eine Menge Macht zu gewinnen!"

    # say L281 pla
    old "Ok, I hope this is all worth it."
    new "Ok, ich hoffe, das lohnt sich alles."

    # say L283 bri
    old "Alright, [pla]. What else do you want to know?"
    new "Okay, [pla]. Was willst du noch wissen?"

    # say L290 bri
    old "That's the spirit!  So, look at the beginning of the book for an easy spell..."
    new "Das ist der Geist! Also, schau am Anfang des Buches nach einem einfachen Zauber..."

    # say L292 pla
    old "Let's see here..."
    new "Lass mal sehen..."

    # say L295 pla
    old "Damn, forgot. Everyone can hear me in this room. I gotta look for a better place to do this..."
    new "Verdammt, ich hab's vergessen. Hier kann mich jeder hören. Ich muss einen besseren Ort finden, um das zu machen..."

    # say L297 pla
    old "Hmm, probably the garage. Noone can hear me in there. Could you go there with me, Brixxida?"
    new "Hmm, wahrscheinlich die Garage. Da kann niemand mich hören. Könntest du mit mir dorthin kommen, Brixxida?"

    # say L299 bri
    old "I will follow you wherever you tell me."
    new "Ich werde dir folgen, wohin du mich auch bittest."

    # say L301 pla
    old "Perfect! Let's do this in the garage."
    new "Perfekt! Lass uns das in der Garage machen."

    # say L316 bri
    old "So? Are you ready to start?"
    new "Bist du bereit loszulegen?"

    # say L318 pla
    old "I should talk with my [mo1rel] before we begin."
    new "Ich sollte vorher mit meiner [mo1rel] reden."

    # say L331 pla
    old "Alright, I spoke to my [mo1rel] and explained to her that I will be in here preparing my project."
    new "Okay, ich habe mit meiner [mo1rel] gesprochen und ihr erklärt, dass ich hier drin sein werde, um mein Projekt vorzubereiten."

    # say L333 pla
    old "So, how does all this work, Brixxida?"
    new "Also, wie funktioniert das Ganze, Brixxida?"

    # say L338 bri
    old "Well, first you must understand the magical power..."
    new "Na ja, zuerst musst du die magische Kraft verstehen..."

    # say L340 pla
    old "Magical power?"
    new "Magische Kraft?"

    # say L342 bri
    old "Yes, you must have the magical power to be able to do any spell..."
    new "Ja, du musst die magische Kraft haben, um überhaupt einen Zauber wirken zu können..."

    # say L344 pla
    old "I understand, but then how do I generate that magical power?"
    new "Ich verstehe, aber dann, wie erzeuge ich diese magische Energie?"

    # say L346 bri
    old "Well, magical power is an energy that was produced naturally in the magical world..."
    new "Na ja, magische Energie ist eine Kraft, die im magischen Reich natürlich entsteht..."

    # say L352 pla
    old "Even you?"
    new "Selbst du?"

    # say L354 bri
    old "Yes... We feed on magical energy, when in the real world all the remaining energy has been used up, I will disappear..."
    new "Ja... Wir ernähren uns von magischer Energie, wenn im echten Welt all die verbleibende Energie aufgebraucht ist, werde ich verschwinden..."

    # say L356 pla
    old "Wow... And how do we prevent magic energy from running out?"
    new "Wow... Und wie verhindern wir, dass die magische Energie ausgeht?"

    # say L358 bri
    old "The magical energy will continue to run out until there be a new being so powerful that it can restore the magical world and return everything to its natural balance..."
    new "Die magische Energie wird weiter abnehmen, bis ein neues Wesen so mächtig wird, dass es die magische Welt wiederherstellen und alles in sein natürliches Gleichgewicht zurückbringen kann."

    # say L360 pla
    old "That powerful being is supposed to be... me?..."
    new "Dass mächtige Wesen soll... ich sein?"

    # say L362 bri
    old "Yes.. You are the chosen one."
    new "Ja.. Du bist der Auserwählte."

    # say L364 pla
    old "Hmm, it's a lot of responsibility..."
    new "Hmm, das ist eine Menge Verantwortung..."

    # say L366 bri
    old "Don't worry. I know we will make it!"
    new "Mach dir keine Sorgen. Ich weiß, wir schaffen das!"

    # say L368 pla
    old "Okay, but then how can I make spells if I don't have magic energy?"
    new "Okay, aber wie kann ich dann Zaubersprüche wirken, wenn ich keine magische Energie habe?"

    # say L369 bri
    old "Well, let me think... It's really not difficult, The magic energy is in the air."
    new "Na, lass mich nachdenken... Es ist wirklich nicht schwierig, die magische Energie ist in der Luft."

    # say L370 bri
    old "I can see it. What you need to do is acquire a certain skill that allows you to see it too..."
    new "Ich sehe es. Was du tun musst, ist eine bestimmte Fähigkeit zu erlernen, die dir ermöglicht, es auch zu sehen..."

    # say L373 bri
    old "Agamoto's eye! With it, you can see all the particles of magical power and collect them..."
    new "Agamotos Auge! Damit kannst du alle Partikel der magischen Energie sehen und sammeln..."

    # say L377 bri
    old "Agamoto's eye, is a special ability of vision. It will allow you to see many things of the magical world and expand your vision in a way never seen before by humans..."
    new "Agamotos Auge ist eine besondere Sehfähigkeit. Es wird dir ermöglichen, viele Dinge der magischen Welt zu sehen und deine Wahrnehmung auf eine Weise zu erweitern, die noch nie von Menschen gesehen wurde..."

    # say L379 pla
    old "Great. How do I get that ability then?"
    new "Super. Und wie krieg ich dann diese Fähigkeit?"

    # say L381 bri
    old "Ohhh... Well, heh... You'll need magical power... Hahaha."
    new "Ohhh... Na ja, hehe... Du wirst magische Kraft brauchen... Hahaha."

    # say L383 pla
    old "Really?... So how can I get magic power? If I need magic power to get magic power..."
    new "Wirklich?... Also, wie kann ich magische Kraft bekommen? Wenn ich magische Kraft brauche, um magische Kraft zu bekommen..."

    # say L385 bri
    old "Well, I think the easiest way is that I share you magic power!"
    new "Na ja, ich denke der einfachste Weg ist, dass ich dir meine magische Kraft gebe!"

    # say L387 pla
    old "You share magic power with me?"
    new "Du teilst mir Magie mit?"

    # say L389 bri
    old "Yes! As I explained to you, all magical beings are constituted of magical power."
    new "Ja! Wie ich dir erklärt habe, bestehen alle magischen Wesen aus magischer Energie."

    # say L390 bri
    old "In fact, we are like little magnets that we are gathering magical power constantly to live."
    new "Tatsächlich sind wir wie kleine Magnete, die ständig magische Energie anziehen, um zu leben."

    # say L392 bri
    old "In the magical world it was totally normal to share our magical energy with others because there were lots..."
    new "In der magischen Welt war es total normal, unsere magische Energie mit anderen zu teilen, weil es da viel davon gab."

    # say L394 bri
    old "The problem is that in this world there is less and less, so if I share more than necessary, it could disappear forever."
    new "Das Problem ist, dass in dieser Welt immer weniger davon vorhanden ist. Wenn ich mehr teile, als nötig, könnte es für immer verschwinden."

    # say L396 pla
    old "Wow, it looks dangerous... So what will we do?"
    new "Wow, das klingt gefährlich... Was machen wir jetzt?"

    # say L398 bri
    old "Bah, I'm going to share enough, and then you can return me some magical power so that nothing happens to me."
    new "Bah, ich werde genug teilen, und dann kannst du mir etwas magische Kraft zurückgeben, damit mir nichts passiert."

    # say L400 pla
    old "Okay, how do you share me then?"
    new "Okay, wie teilst du es mir dann mit?"

    # say L402 bri
    old "Hmm, let's see. Take off your pants and lie on the floor..."
    new "Hmm, lass mal sehen. Zieh deine Hose aus und leg dich auf den Boden..."

    # say L404 pla
    old "What... Why do I have to take off my pants?"
    new "Was... Warum muss ich meine Hose ausziehen?"

    # say L407 bri
    old "Oh, of course... You humans treat nudity as a taboo. Even though it's something natural..."
    new "Oh, natürlich... Ihr Menschen behandelt Nacktheit als Tabu. Obwohl es etwas ganz Normales ist..."

    # say L408 bri
    old "Besides what we're going to do... How do you call it?... Uhh, sex!"
    new "Außerdem, was wir machen werden... Wie nennt ihr das noch?... Ah, Sex!"

    # say L410 pla
    old "What the fuck!? Are we going to have sex?"
    new "Was zum Teufel!? Sollen wir Sex haben?"

    # say L412 bri
    old "Yes, it's super fun... I understand that you see it in a different way. But for us, this is simply a form of common energy exchange..."
    new "Ja, es ist total Spaß... Ich verstehe, dass du das anders siehst. Aber für uns ist das einfach eine Form der gemeinsamen Energieaustausch..."

    # say L414 pla
    old "Are you saying that this is how you are going to share magical power?"
    new "Meinst du, dass das der Weg ist, wie ihr eure magische Kraft teilt?"

    # say L416 bri
    old "Exactly, the magic power resides in an inner gland, and the only way to transfer it is to excite it..."
    new "Genau, die magische Energie befindet sich in einer inneren Drüse, und der einzige Weg, sie zu übertragen, ist, sie anzuregen..."

    # say L418 bri
    old "In my case, you must be inside me and you will receive my magic power!"
    new "In meinem Fall musst du in mir drin sein und dann bekommst du meine magische Kraft!"

    # say L420 pla
    old "... And there is no other way. I'm not sure if it's a good idea..."
    new "... Und es gibt keine andere Möglichkeit. Ich bin mir nicht sicher, ob das eine gute Idee ist..."

    # say L422 bri
    old "Oh come on! You humans are very complicated, but you have to see it as a magical being..."
    new "Oh komm schon! Ihr Menschen seid sehr kompliziert, aber du musst es als magisches Wesen sehen..."

    # say L424 bri
    old "Think of sex as a way to feed yourself with magical energy... Is very natural."
    new "Stell dir Sex als eine Art, dich mit magischer Energie zu ernähren vor... Das ist sehr natürlich."

    # say L426 pla
    old "Alright, let's do it then..."
    new "Okay, dann machen wir es..."

    # say L429 bri
    old "Excellent! Take off your pants and get on the floor!"
    new "Perfekt! Zieh deine Hose aus und leg dich auf den Boden!"

    # say L434 bri
    old "Wow, this is very good! I haven't done it for a long time..."
    new "Wow, das ist sehr gut! Ich habe es schon lange nicht mehr gemacht..."

    # say L442 pla
    old "Do you have some magic power to share with me?"
    new "Hast du irgendwelche magischen Kräfte, die du mit mir teilen kannst?"

    # say L444 bri
    old "Do you need more from me?"
    new "Brauchst du noch mehr von mir?"

    # say L446 pla
    old "Well, only if you have some to share..."
    new "Na klar, aber nur wenn du auch was zu geben hast..."

    # say L448 bri
    old "Ok, but just because is really fun... hahaha"
    new "Okay, aber nur weil es echt Spaß macht... hahaha"

    # say L452 bri
    old "Take off your pants and lie on the floor..."
    new "Zieh deine Hose aus und leg dich auf den Boden..."

    # say L478 pla
    old "Wow, I've never slept that well."
    new "Wow, ich hab noch nie so gut geschlafen."

    # say L480 bri
    old "I see that your body was able to completely assimilate magic. How do you feel?"
    new "Ich sehe, dass dein Körper die Magie vollständig aufgenommen hat. Wie fühlst du dich?"

    # say L482 pla
    old "I don't feel any different..."
    new "Ich fühle mich nicht anders..."

    # say L484 bri
    old "Well, the best thing to do is to use the magic energy that I gave you to acquire Agamoto's Eye before it runs out..."
    new "Dann ist es am besten, die magische Energie, die ich dir gegeben habe, zu nutzen, um das Auge von Agamoto zu erwerben, bevor sie verloren geht..."

    # say L486 pla
    old "Does that mean that if I don't use the magic power it will run out?"
    new "Das bedeutet also, wenn ich die magische Energie nicht nutze, verliert sie ihre Kraft?"

    # say L488 bri
    old "Yes, indeed. Every day you will have less magical power, which is why it is urgent that you acquire the skill."
    new "Ja, genau. Jeden Tag hast du weniger magische Kraft, deshalb ist es dringend, dass du die Fähigkeit erwerbst."

    # say L490 pla
    old "Perfect, let's go to the garage to do it then..."
    new "Perfekt, dann lass uns in die Garage gehen, um es zu tun..."

    # say L496 pla
    old "So, what should I do?"
    new "Also, was soll ich tun?"

    # say L497 bri
    old "Well, actually, yesterday we couldn't finish our magic transfer..."
    new "Na ja, eigentlich konnten wir unser Magietransfer gestern nicht beenden..."

    # say L498 bri
    old "So, we should do it again, in order to you get completly charged with magic power."
    new "Dann sollten wir es noch mal machen, damit du vollständig mit magischer Energie aufgeladen wirst."

    # say L499 pla
    old "Hmm alright, but I'm not going to lay on the floor like last time, I don't want someone else to see me in that weird position..."
    new "Hmm okay, aber ich werde mich nicht wieder auf den Boden legen, ich will nicht, dass jemand mich in dieser seltsamen Position sieht..."

    # say L500 bri
    old "All right!"
    new "Okay!"

    # say L513 pla
    old "All right. Now what should I do?"
    new "Okay. Was soll ich jetzt machen?"

    # say L515 bri
    old "First open your SexNote"
    new "Erst mal deine SexNote öffnen"

    # say L525 bri
    old "Now check the first spell named 'Agamoto's eye' and activate it."
    new "Jetzt überprüfe den ersten Zauber namens 'Agamotos Auge' und aktiviere ihn."

    # say L526 pla
    old "Understood..."
    new "Verstanden..."

    # say L539 pla
    old "I think it's done... But I don't feel anything different..."
    new "Ich glaube, es ist fertig... Aber ich spüre keinen Unterschied..."

    # say L541 bri
    old "You must activate it, click on ability and look at the magic dimension!"
    new "Du musst es aktivieren, auf die Fähigkeit klicken und in die magische Dimension schauen!"

    # say L568 pla
    old "Wow... It looks so... Magical?..."
    new "Wow... Das sieht so... Magisch aus?..."

    # say L569 bri
    old "Do you see those little colored spheres? That is magic power, it has become particles, you just have to pick it all up..."
    new "Siehst du diese kleinen farbigen Kugeln? Das ist magische Energie, sie hat sich in Partikel verwandelt, du musst sie nur alle einsammeln..."

    # say L570 bri
    old "And when you do it, just click the Agamoto's Eye to desactivate it and see the real world."
    new "Und wenn du es tust, klickst du einfach auf das Auge von Agamoto, um es zu deaktivieren und die echte Welt zu sehen."

    # say L579 pla
    old "Wow, it's easier than I expected..."
    new "Wow, das ist einfacher, als ich gedacht hätte..."

    # say L581 bri
    old "Of course, what did you expect? Having to memorize and recite strange meaningless words or make puzzles that never fit in  corners?"
    new "Natürlich, was hast du erwartet? Dass du seltsame, sinnlose Worte auswendig lernen oder Puzzles lösen musst, die nie passen?"

    # say L583 pla
    old "What?..."
    new "Was?"

    # say L585 bri
    old "Nevermind... It's simple, you just have to look for the spheres of magic power and that's it..."
    new "Vergiss es... Es ist einfach, du musst nur nach den Kugeln der magischen Energie suchen und fertig."

    # say L587 bri
    old "In fact... There is a spell you can use called Ayax's Hand"
    new "Tatsächlich... Es gibt einen Zauber, den du benutzen kannst, der heißt Ayax' Hand."

    # say L589 bri
    old "With this one your body will automatically begin to collect magic power everywhere you move, it's sorta like a magnet.."
    new "Mit dem kannst du automatisch Magieenergie sammeln, egal wo du hingehst, es ist so was wie ein Magnet."

    # say L591 pla
    old "Yes, you're right, there are several more spells I saw in the SexNote, how can I activate them?"
    new "Stimmt, da waren noch mehr Zaubersprüche in der SexNote, die ich gesehen habe. Wie kann ich sie aktivieren?"

    # say L593 bri
    old "Very easy you only spend the magic power you have in them and so you can activate those spells, each one has three different levels of power."
    new "Sehr einfach, du musst nur die Magie, die du hast, in sie investieren, dann kannst du diese Zauber aktivieren. Jeder hat drei verschiedene Stärken."

    # say L595 bri
    old "For example, the higher the level of power you have with Agamoto's eye, the more spheres you will see and so you can collect more magical power!"
    new "Zum Beispiel, je höher die Stufe von Agamotos Auge, desto mehr Sphären siehst du und kannst so mehr magische Kraft sammeln!"

    # say L597 pla
    old "Ohhh understood, and when I have collected all the magical power from a place?"
    new "Ohhh verstanden, und wenn ich alle magischen Kräfte von einem Ort gesammelt habe?"

    # say L599 bri
    old "Check this out, power spheres group everyday so keep an eye out and collect more magical power!"
    new "Schau mal, die Kraftkugeln sammeln sich jeden Tag, also bleib wachsam und sammle mehr magische Energie!"

    # say L602 bri
    old "Something important is that your body cannot store much magical power..."
    new "Etwas Wichtiges ist, dass dein Körper nicht viel magische Energie speichern kann..."

    # say L603 bri
    old "For that you must use a spell, and thus increase the amount of power that you can store within yourself."
    new "Dafür musst du einen Zauber benutzen und so die Menge der Magie erhöhen, die du in dir speichern kannst."

    # say L605 pla
    old "Excellent, so I'm going to devote myself to collecting some magical power in the meantime..."
    new "Perfekt, dann widme ich mich mal dem Sammeln von magischer Energie..."

    # say L607 bri
    old "Perfect, now that you can do it... You could give me a little, remember that I need it to exist."
    new "Perfekt, jetzt wo du das kannst... Du könntest mir ein bisschen geben, ich brauche es, um zu existieren."

    # say L609 pla
    old "Ohh yes, I'm sorry, let me pick up some more magical power and I will give you later..."
    new "Ohh ja, entschuldige, ich sammle noch ein bisschen mehr magische Energie und gebe dir dann was."

    # say L611 bri
    old "Oh, by the way! Keep in mind that using your Agamotto Eye spends some magical power and time."
    new "Oh, übrigens! Denk dran, dass der Einsatz deines Agamotto-Auges sowohl magische Energie als auch Zeit kostet."

    # say L615 bri
    old "Well, all magical skills, requires some magical power to be used..."
    new "Na ja, alle magischen Fähigkeiten benötigen etwas magische Energie, um eingesetzt zu werden..."

    # say L618 bri
    old "And when you are in the magic dimension time passes a little faster too."
    new "Und wenn du in der magischen Dimension bist, vergeht die Zeit auch etwas schneller."

    # say L620 bri
    old "If you use only a couple of times, you will not see much difference but if you use them alot you will end the day very quickly."
    new "Wenn du sie nur ein paarmal benutzt, siehst du kaum einen Unterschied, aber wenn du sie häufiger anwendest, vergeht der Tag schneller."

    # say L622 pla
    old "Ohh ok, understood..."
    new "Ohh ok, verstanden..."

    # say L624 bri
    old "It is indeed a good way to kill time if you have nothing to do at some point."
    new "Es ist tatsächlich eine gute Art, die Zeit zu vertreiben, wenn du mal nichts zu tun hast."

    # say L626 pla
    old "I guess you are right..."
    new "Ich schätze, du hast recht..."

    # say L628 bri
    old "Ok, I'll be here if you need me."
    new "Okay, ich bin hier, wenn du mich brauchst."

    # say L701 pla
    old "Hey Brixxida... I think I was visited by another shinigami, like you, yesterday."
    new "Hey Brixxida... ich glaube, ich wurde gestern von einem anderen Shinigami besucht, wie du."

    # say L705 pla
    old "You are the only shinigami alive in the human world?"
    new "Du bist die einzige Shinigami, die im menschlichen Welt lebt?"

    # say L707 bri
    old "I'm not sure, there are likely to be more, the magical world was very big..."
    new "Ich bin mir nicht sicher, es gibt wahrscheinlich noch mehr, die magische Welt war sehr groß..."

    # say L709 pla
    old "Well, one of them visited me last night and she was sucking my... She was stealing my magic power..."
    new "Na, eine von ihnen hat mich letzte Nacht besucht und sie hat an meinem... Sie hat meine magische Kraft gestohlen..."

    # say L711 bri
    old "Wow... Really?"
    new "Wow... Wirklich?"

    # say L713 pla
    old "Who is she and why did she steal my magic power?"
    new "Wer ist sie und warum hat sie meine magische Kraft gestohlen?"

    # say L715 bri
    old "I don't know, it's not like I knew all the magical beings..."
    new "Ich weiß es nicht, ich kannte nicht alle magischen Wesen..."

    # say L717 pla
    old "So what can we do?"
    new "Was können wir dann tun?"

    # say L719 bri
    old "I don't think it will happen again, it's best we wait. If she steals from you again we'll have to defend ourselves..."
    new "Ich denke, es wird nicht wieder passieren, wir sollten abwarten. Wenn sie dir noch mal was stiehlt, müssen wir uns verteidigen..."

    # say L721 pla
    old "What do you mean defend ourselves?"
    new "Was meinst du mit uns verteidigen?"

    # say L723 bri
    old "Well, we would have to hunt her and take away her magical power instead..."
    new "Na ja, wir müssten sie jagen und ihre magische Kraft nehmen..."

    # say L725 pla
    old "All her magical power? That would make her disappear... wouldn't it?"
    new "All ihre magische Kraft? Das würde sie verschwinden lassen... oder?"

    # say L727 bri
    old "Well if she attack you again, we can't sit by while she keeps stealing our magical power! We must stop her somehow..."
    new "Wenn sie dich wieder angreift, können wir nicht tatenlos zusehen, wie sie unsere magische Kraft stiehlt! Wir müssen sie irgendwie aufhalten..."

    # say L729 pla
    old "Hmmm... Ok, just let's wait and hopefully she won't  show up again."
    new "Hmmm... Okay, lass uns einfach abwarten und hoffen, dass sie nicht wieder auftaucht."

    # say L731 bri
    old "Right... Don't worry, thought. Just keep improving with your skills..."
    new "Richtig... Mach dir keine Sorgen, aber bleib bei der Stange und verbessere dich weiter."

    # say L745 pla
    old "Brixxida, last night another shinigami visited me!"
    new "Brixxida, gestern Nacht hat mich wieder ein Shinigami besucht!"

    # say L747 bri
    old "Another? And did she steal more magic power from you?"
    new "Noch einer? Und hat sie dir wieder mehr magische Kraft gestohlen?"

    # say L749 pla
    old "Well... yes."
    new "Na ja... ja."

    # say L751 bri
    old "Damn! That can't keep happening! We must recover my magical power... I mean, our magical power..."
    new "Verdammt! Das darf nicht weiter passieren! Wir müssen meine magische Energie zurückgewinnen... ich meine, unsere magische Energie..."

    # say L753 pla
    old "And how do we do it?"
    new "Und wie machen wir das?"

    # say L755 bri
    old "We must go on the hunt... We will attack them so they don't bother us again..."
    new "Wir müssen auf die Jagd gehen... Wir werden sie angreifen, damit sie uns nicht mehr belästigen..."

    # say L757 pla
    old "No, no, this time I was able to talk with her a little more..."
    new "Nein, nein, dieses Mal konnte ich ein bisschen länger mit ihr reden..."

    # say L758 pla
    old "In fact she didn't steal much magic from me... and I would like to understand the situation better..."
    new "Tatsächlich hat sie mir nicht viel Magie gestohlen... und ich möchte die Situation besser verstehen..."

    # say L760 bri
    old "They have stolen magical power. If it continues, we will be wasting valuable time that we must use to collect more magical power..."
    new "Sie haben magische Kraft gestohlen. Wenn das so weitergeht, verschwenden wir wertvolle Zeit, die wir dafür brauchen, mehr magische Kraft zu sammeln..."

    # say L762 pla
    old "Let me try one more time. When they return I will try to find out more and see if we can calm them down..."
    new "Lass mich noch einmal versuchen. Wenn sie zurückkommen, werde ich versuchen, mehr herauszufinden und sehen, ob wir sie beruhigen können..."

    # say L764 bri
    old "Hmm, if they steal your magic power again, we will have to defend ourselves, okay?"
    new "Hmm, wenn sie deine magische Kraft wieder stehlen, müssen wir uns verteidigen, okay?"

    # say L766 pla
    old "Okay. I will try to use Sauron's Mouth to find out more next time..."
    new "Okay. Ich werde versuchen, das Maul von Sauron zu nutzen, um mehr herauszufinden..."

    # say L768 bri
    old "Well, make sure you have the skill at the highest level to get as much information as possible."
    new "Stell sicher, dass du die Fähigkeit auf höchster Stufe hast, um so viel Information wie möglich zu bekommen."

    # say L770 pla
    old "For sure..."
    new "Klar..."

    # say L782 pla
    old "Well, things will be fine ..."
    new "Na, alles wird gut..."

    # say L784 bri
    old "You put a stop to the night robberies?"
    new "Du hast die Nachträubereien gestoppt?"

    # say L786 pla
    old "Well, Not really..."
    new "Na ja, eigentlich nicht..."

    # say L788 bri
    old "Then we will have to fight back now..."
    new "Dann werden wir uns jetzt wehren müssen..."

    # say L790 pla
    old "No, wait! The problem is that I have taken magical energy that they need to live..."
    new "Nein, warte! Das Problem ist, dass ich magische Energie genommen habe, die sie zum Leben brauchen..."

    # say L792 bri
    old "You have taken magical energy that is scattered throughout the world. You have never attacked any of them..."
    new "Du hast magische Energie an dich gezogen, die im ganzen Welt verbreitet ist. Du hast noch nie einen von ihnen angegriffen..."

    # say L794 pla
    old "But... I can generate magical power in other ways..."
    new "Aber... ich kann auf andere Weise magische Energie erzeugen..."

    # say L796 bri
    old "You still don't have enough sexual activity with other women, to guarantee a constant production of magical energy."
    new "Du hast immer noch nicht genug sexuelle Aktivität mit anderen Frauen, um eine ständige Produktion von magischer Energie zu gewährleisten."

    # say L798 pla
    old "I can do it and not affect them..."
    new "Ich kann es und es beeinflusst sie nicht..."

    # say L800 bri
    old "You must think about the main goal and it is to be able to rebuild the magical world."
    new "Du musst an das Hauptziel denken und das ist es, die magische Welt wieder aufzubauen."

    # say L802 bri
    old "There are many magical beings that will disappear..."
    new "Es gibt viele magische Wesen, die verschwinden werden..."

    # say L803 bri
    old "And we can do nothing but work harder to rebuild everything as quickly as possible..."
    new "Und wir können nichts anderes tun, als härter zu arbeiten, um alles so schnell wie möglich wieder aufzubauen..."

    # say L805 pla
    old "Hmm... I guess you're right, but we don't have to attack them."
    new "Hmm... Ich schätze, du hast recht, aber wir müssen sie nicht angreifen."

    # say L806 pla
    old "I will try to produce our own energy and little by little we can move forward with the spells..."
    new "Ich werde versuchen, unsere eigene Energie zu produzieren und Schritt für Schritt können wir mit den Zaubersprüchen vorankommen..."

    # say L808 bri
    old "They will continue stealing your magical power if we do nothing."
    new "Sie werden weiterhin deine magische Kraft stehlen, wenn wir nichts tun."

    # say L809 bri
    old "We don't have to take away all the magical power, just enough to scare them and they won't look for you again..."
    new "Wir müssen ihnen nicht die ganze magische Kraft nehmen, nur genug, um sie zu erschrecken und sie werden dich nicht mehr jagen..."

    # say L811 pla
    old "Hmm that's fine... How do we do it?"
    new "Hmm das klingt gut... Wie machen wir das?"

    # say L813 bri
    old "I'll take care of tracking them and you'll do the attacking..."
    new "Ich kümmere mich um die Verfolgung und du wirst sie angreifen..."

    # say L815 pla
    old "Attack them?"
    new "Sie angreifen?"

    # say L817 bri
    old "Yes, you will have to fuck them..."
    new "Ja, du musst sie ficken..."

    # say L819 pla
    old "Hmmm... Ok."
    new "Hmmm... Okay."

    # say L821 bri
    old "Ok, give me a second. I'm going to use a special spell to detect nearby magical beings..."
    new "Ok, gib mir eine Sekunde. Ich werde einen besonderen Zauber benutzen, um magische Wesen in der Nähe zu erkennen..."

    # say L829 bri
    old "Done... I already identified where one of them are! She is in your classroom at school! Go there and fuck her..."
    new "Fertig... Ich habe schon eine von ihnen geortet! Sie ist in deinem Klassenzimmer an der Schule! Geh dorthin und fick sie..."

    # say L831 pla
    old "But... What if other people are there?"
    new "Aber... Was ist, wenn andere Leute da sind?"

    # say L833 bri
    old "Don't worry! When you are in the magical dimension with Agamoto's Eye nobody can see you..."
    new "Mach dir keine Sorgen! Wenn du in der magischen Dimension mit Agamotos Auge bist, kann dich niemand sehen..."

    # say L835 pla
    old "Ok, I'm going there then..."
    new "Okay, dann gehe ich da hin..."

    # say L837 bri
    old "Good luck! See you later..."
    new "Viel Glück! Bis später..."

    # say L843 pla
    old "(Well, she is supposed to be here...)"
    new "Na ja, sie soll ja hier sein..."

    # say L845 pla
    old "(Let's use the Agamoto's Eye.)"
    new "(Lass uns das Auge von Agamoto benutzen.)"

    # say L852 mil
    old "What the fuck are you doing here?"
    new "Was zum Teufel machst du hier?"

    # say L860 bri
    old "So, how did it go? Did you get magic power back?"
    new "Und, wie war's? Hast du deine magischen Kräfte zurückbekommen?"

    # say L862 pla
    old "Yes, I already recovered my magic power..."
    new "Ja, ich habe meine magischen Kräfte schon wieder."

    # say L864 bri
    old "Great... I don't think they will bother again after that..."
    new "Großartig... Ich glaube nicht, dass sie noch einmal Ärger machen werden..."

    # say L866 pla
    old "Hmm I don't know... We shall see."
    new "Hmm, ich weiß nicht... Wir werden sehen."

    # say L878 pla
    old "Again, problems with these shinigamis, I think they've gone crazy..."
    new "Wieder Probleme mit diesen Shinigamis, ich glaube, die sind durchgedreht..."

    # say L880 bri
    old "AGAIN? Okay let's finish them..."
    new "WIEDER? Okay, dann erledigen wir sie..."

    # say L882 pla
    old "No, no... It's very strange. The one who I talked to yesterday was very kind and friendly after having accused me of destroying the magical world..."
    new "Nein, nein... Es ist sehr seltsam. Der, mit dem ich gestern gesprochen habe, war nachdem er mich beschuldigt hatte, die magische Welt zu zerstören, sehr freundlich und nett..."

    # say L884 bri
    old "What?... Ehh... They are totally crazy... It's best to make them disappear. We don't want to deal with them later..."
    new "Was?... Ehh... Die sind total verrückt... Am besten machen wir sie verschwinden. Wir wollen später nicht damit zu tun haben..."

    # say L886 pla
    old "We'll let's try this... I will try to find the next shinigami and I will see what's happening..."
    new "Dann lass uns das mal versuchen... Ich werde versuchen, den nächsten Shinigami zu finden und sehen, was da los ist..."

    # say L888 bri
    old "But you should kill them! We've had enough..."
    new "Aber du solltest sie umbringen! Wir haben genug davon..."

    # say L890 pla
    old "No, no. Let me handle this. I have an idea..."
    new "Nein, nein. Lass mich das regeln. Ich habe eine Idee..."

    # say L892 bri
    old "Hmmm ok. I'm gonna use the spell again and I'll tell you where to find the next shinigami..."
    new "Hmmm okay. Ich werde den Zauber noch mal benutzen und dir sagen, wo du den nächsten Shinigami findest..."

    # say L900 bri
    old "Well, she is in fact in your friend Hinn's living room."
    new "Na ja, sie ist tatsächlich im Wohnzimmer deines Freundes Hinn."

    # say L902 pla
    old "Hmmm, alright... No problem."
    new "Hmmm, okay... Kein Problem."

    # say L904 bri
    old "But you should consider killing them. It can't waste more time..."
    new "Aber du solltest sie umbringen. Das verschwendet keine Zeit mehr..."

    # say L906 pla
    old "I know what to do..."
    new "Ich weiß, was zu tun ist..."

    # say L908 bri
    old "Hmm, Ok."
    new "Hmm, okay."

    # say L914 pla
    old "(Great, no one is in the livingroom...)"
    new "Perfekt, niemand ist im Wohnzimmer..."

    # say L919 pla
    old "Excellent! Just what I wanted..."
    new "Exzellent! Genau das wollte ich..."

    # say L930 mil
    old "What? What are you doing?"
    new "Was? Was machst du da?"

    # say L939 pla
    old "I have some questions to ask you..."
    new "Ich habe ein paar Fragen an dich..."

    # say L941 bri
    old "Sure! Do you want to know more about spells?"
    new "Klar! Willst du mehr über Zaubersprüche erfahren?"

    # say L943 pla
    old "No, in fact, I want you to tell me who destroyed the magical world..."
    new "Nein, eigentlich will ich, dass du mir sagst, wer die magische Welt zerstört hat..."

    # say L946 bri
    old "Of course, the magical world was a wonderful place. Everyone lived in harmony..."
    new "Natürlich, die magische Welt war ein wunderbarer Ort. Alle lebten im Einklang..."

    # say L948 bri
    old "But a dark being, for unknown reasons, destroyed everything with a spell. When started to act it was too late because the being had too much power..."
    new "Aber ein dunkles Wesen, aus unbekannten Gründen, hat alles mit einem Zauber zerstört. Als es anfing, war es schon zu spät, weil das Wesen zu viel Macht hatte..."

    # say L950 pla
    old "And why did the shinigami tell me the person who destroyed the magical world was the SexNote owner?"
    new "Und warum hat mir der Shinigami gesagt, dass die Person, die die magische Welt zerstört hat, der Besitzer von SexNote war?"

    # say L952 bri
    old "I don't know... It could have been the former owner of the SexNote or it could have been another SexNote..."
    new "Ich weiß es nicht... Es könnte der ehemalige Besitzer des SexNote gewesen sein oder auch ein anderer SexNote..."

    # say L954 pla
    old "Is there more than one SexNote?"
    new "Gibt es mehr als eine SexNote?"

    # say L957 bri
    old "It is not known for sure. Nobody knows. In fact, many ignore the real existence of a SexNote. It is something very secret because of the power it has..."
    new "Es ist nicht sicher bekannt. Niemand weiß. Tatsächlich ignorieren viele die wahre Existenz einer SexNote. Es ist etwas sehr Geheimes wegen der Macht, die es hat..."

    # say L959 bri
    old "That's why you're the Chosen One to use it to repair all the damage..."
    new "Deshalb bist du der Auserwählte, um es zu benutzen, um all den Schaden zu reparieren..."

    # say L961 pla
    old "I understand... Still, you don't know anything about the previous owner of the SexNote or who destroyed the magical world?"
    new "Ich verstehe... Trotzdem weißt du nichts über den vorherigen Besitzer der SexNote oder wer die magische Welt zerstört hat?"

    # say L963 bri
    old "Correct, My mission was entrusted after the destruction of the magical world, to find a way to preserve the remaining magic of the universe..."
    new "Richtig, meine Mission wurde mir nach der Zerstörung der magischen Welt anvertraut, um einen Weg zu finden, die verbleibende Magie des Universums zu bewahren..."

    # say L965 pla
    old "Got cha. Then everything is a silly misunderstanding... Help me look again for the shinigami to talk to them..."
    new "Verstanden. Dann ist alles nur ein blöder Missverständnis... Hilf mir noch mal, den Shinigami zu finden, damit ich mit ihnen rede..."

    # say L967 bri
    old "I don't think that is for the best. After what happened, it could be dangerous. It is best to leave it be as I doubt they'll look for you again..."
    new "Ich glaube nicht, dass das das Beste ist. Nach dem, was passiert ist, könnte es gefährlich sein. Es ist am sichersten, es auf sich beruhen zu lassen, da ich bezweifle, dass sie noch einmal nach dir suchen werden."

    # say L969 pla
    old "But you heard them, they are running out of magic power..."
    new "Aber du hast sie gehört, sie sind am Verlust ihrer magischen Kraft..."

    # say L971 bri
    old "The magic power is scattered throughout the world, they just have to go to other places to collect. It is not as serious as they want you to think..."
    new "Die magische Energie ist über die ganze Welt verteilt, sie müssen nur an andere Orte gehen, um sie zu sammeln. Es ist nicht so dramatisch, wie sie es darstellen."

    # say L973 pla
    old "Hmmm... Ok... I guess you're right"
    new "Hmmm... Okay... Ich schätze, du hast recht."

    # say L975 pla
    old "Well, I'm going to keep improving my skills and collecting magical power."
    new "Na gut, ich werde meine Fähigkeiten weiter verbessern und magische Kraft sammeln."

    # say L977 bri
    old "Great! See you later."
    new "Super! Bis später."

    # say L983 pla
    old "(I still think there is something up with Brixxida. I should try to talk with those shinigamis again)"
    new "Ich denke immer noch, dass mit Brixxida was nicht stimmt. Ich sollte versuchen, noch mal mit den Shinigamis zu reden."

    # say L985 pla
    old "(But, I can't ask Brixxida to look for them...)"
    new "Aber ich kann Brixxida nicht bitten, nach ihnen zu suchen..."

    # say L987 pla
    old "(I will have to look for them by myself)"
    new "Ich werde sie selbst suchen müssen"

    # say L989 pla
    old "Ok, I should look around to find them..."
    new "Okay, ich sollte mich umsehen, um sie zu finden..."

    # menu L996 
    old "Talk with her"
    new "Mit ihr sprechen"

    # say L1010 pla
    old "Well, I already collected enough magic power, I think I can share some with you..."
    new "Na, ich habe schon genug magische Kraft gesammelt, denke ich kann dir ein bisschen davon geben..."

    # say L1013 bri
    old "Yummy. I love to share the magic power. It's very fun!"
    new "Lecker. Ich liebe es, die magische Energie zu teilen. Das ist total spaßig!"

    # menu L1022 
    old "Repeat"
    new "Wiederholen"

    # say L1033 pla
    old "Wait... What are you doing..."
    new "Warte... Was machst du da..."

    # say L1034 bri
    old "Duh. Receiving your magical power, this is how it is done..."
    new "Klar. Deine magische Kraft zu empfangen, geht eben so..."

    # say L1035 pla
    old "But..."
    new "Aber..."

    # say L1036 bri
    old "You must stop being so dramatic with this. You have to be more professional and understand that this is the way it is done. So stop being so... Human..."
    new "Du musst aufhören, so dramatisch zu sein. Du musst professioneller werden und verstehen, dass es so gemacht wird. Also hör auf, so... menschlich zu sein."


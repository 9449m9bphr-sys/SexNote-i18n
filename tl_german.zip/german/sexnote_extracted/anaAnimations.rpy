# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/anaAnimations.rpy
translate german strings:

    # say L12 ana
    old "What a nice cock do you have..."
    new "Was für einen schönen Schwanz du hast..."

    # say L16 ana
    old "Do you like it, Uh? Do you want it faster baby?"
    new "Du magst es, hm? Willst du es schneller, Baby?"

    # say L20 ana
    old "Oh yeah baby, I wanna see that huge cock cumming..."
    new "Oh ja Baby, ich will sehen, wie dieser große Schwanz abspritzt..."

    # say L45 pla
    old "Mrs Anastasia... I- going to-"
    new "Mrs Anastasia... ich- ich komme-"

    # say L46 ana
    old "Oh yes, cum for mommy, give it to me..."
    new "Oh ja, spritz für Mama, gib es mir..."

    # say L51 ana
    old "Wow that was a lot of cum..."
    new "Wow, das war eine Menge Sperma..."

    # say L60 ana
    old "Mmm, I love your huge cock!"
    new "Mmm, ich liebe deinen riesigen Schwanz!"

    # say L64 ana
    old "Do you like my mounth, baby?"
    new "Magst du meinen Mund, Baby?"

    # say L68 ana
    old "Come on fuck my throat with your big cock!"
    new "Komm schon, fick meinen Rachen mit deinem großen Schwanz!"

    # say L92 pla
    old "Anastasia I'm going to..."
    new "Anastasia, ich werde..."

    # say L93 ana
    old "Ohh yeah, cum all over my face!"
    new "Ohh ja, spritz mir alles ins Gesicht!"

    # say L98 ana
    old "Uhhh warm and sweet..."
    new "Uhhh warm und süß..."

    # say L115 ana
    old "Ahhh, yeah baby fuck me, FUCK ME!"
    new "Ahhh, ja Baby fick mich, FICK MICH!"

    # say L119 ana
    old "Oh god, Oh god, It feels great!"
    new "Oh Gott, oh Gott, das fühlt sich toll an!"

    # say L123 ana
    old "H- Harder... Fuck me harder!"
    new "Härter... Fick mich härter!"

    # say L147 ana
    old "Ahhh I'm cumming!"
    new "Ahhh, ich komme!"

    # say L148 pla
    old "I- I'm cumming too..."
    new "Ich- Ich komme auch..."

    # say L169 ana
    old "Oh my God! This is amazing! Fuck me, Fuck me!"
    new "Oh mein Gott! Das ist unglaublich! Fick mich, fick mich!"

    # say L173 ana
    old "AHHHH AHHHH, YEAH YEAH, HARDER BABY, HARDEER!"
    new "AHHHH AHHHH, JAA JAA, FESTER SCHATZ, FESTER!"

    # say L177 ana
    old "OH MY GOD I LOVE YOUR COCK! GIMME MOREE!"
    new "OH MEIN GOTT, ICH LIEBE DEINEN SCHWANZ! GIB MIR MEEHR!"

    # say L212 ana
    old "Oh my god! I loved it..."
    new "Oh mein Gott! Ich hab's geliebt..."

    # say L213 pla
    old "I- I like it... too."
    new "Ich- Ich mag es... auch."

    # say L216 ana
    old "Oh my god! You are amazing, I loved it..."
    new "Oh mein Gott! Du bist unglaublich, ich habe es geliebt..."

    # say L220 ana
    old "I loved it..."
    new "Ich hab's geliebt..."

    # say L229 ana
    old "Ohhh, your cock feels so nice!"
    new "Ohhh, dein Schwanz fühlt sich so gut an!"

    # say L233 ana
    old "YEAH, BABY, FASTER, FASTER!"
    new "JA, BABY, SCHReller, SCHReler!"

    # say L237 ana
    old "OH MY FUCKING GOD! HARDER, FUCK ME HARDER!"
    new "OH MEIN GOTT! FESTER, FICK MICH FESTER!"

    # say L275 lis
    old "Alright, take a few moments to settle into your position."
    new "Okay, nimm dir einen Moment, um dich in Position zu bringen."

    # say L276 lis
    old "Bring your attention to your breath."
    new "Achte auf deinen Atem."

    # say L277 lis
    old "Focus on the air coming in and out."
    new "Konzentriere dich auf die Luft, die ein- und ausströmt."

    # say L281 lis
    old "Notice the cool air entering your nostrils and the warm air leaving them."
    new "Spür die kühle Luft, die deine Nase betritt, und die warme Luft, die sie verlässt."

    # say L282 lis
    old "Without trying to change your breath, simply observe it."
    new "Ohne deinen Atem zu verändern, beobachte ihn einfach."

    # say L283 lis
    old "Let your body and mind relax."
    new "Lass deinen Körper und deinen Geist sich entspannen."

    # say L289 lis
    old "If your mind begins to wander, that's okay."
    new "Wenn dein Geist abzuschweifen beginnt, ist das in Ordnung."

    # say L290 lis
    old "Let your body feel everything it needs to feel."
    new "Lass deinem Körper alles fühlen, was er fühlen muss."

    # say L291 lis
    old "The sensation of my and [pla]'s hands going over your body."
    new "Das Gefühl von meinen und [pla]s Händen, die über deinen Körper gleiten."

    # say L296 lis
    old "Gently guide your focus back to the sensation of breathing."
    new "Lass dich sanft zurück zur Empfindung des Atmens führen."

    # say L297 lis
    old "Allow yourself to be fully present with each breath."
    new "Lass dich mit jedem Atemzug vollständig hier und jetzt sein."

    # say L298 lis
    old "Finding calm and clarity in this simple act."
    new "In dieser einfachen Handlung Ruhe und Klarheit finden."

    # say L303 ana
    old "Mmm, this feels great, guys."
    new "Mmm, das fühlt sich toll an, Leute."

    # say L304 ana
    old "M-My body's feeling amazing!"
    new "M-Mein Körper fühlt sich unglaublich an!"

    # say L305 lis
    old "That's good, that's your body reacting to the energy flowing within you."
    new "Das ist gut, das ist dein Körper, der auf die Energie reagiert, die in dir fließt."

    # say L306 lis
    old "As your chakras are being cleansed."
    new "Während deine Chakras gereinigt werden."

    # say L327 lis
    old "[pla], place yourself between her legs, and help her energy flow through a massage."
    new "[pla], stell dich zwischen ihre Beine und hilf ihrer Energie durch eine Massage fließen."

    # say L336 ana
    old "I... Oh my god!"
    new "Ich... Oh mein Gott!"

    # say L337 ana
    old "This feels incredible!"
    new "Das fühlt sich unglaublich an!"

    # say L338 ana
    old "I feel like I'm having an orgasm, Lisa!"
    new "Ich fühle mich, als würde ich einen Orgasmus haben, Lisa!"

    # say L339 lis
    old "Good! Enjoy that feeling!"
    new "Gut! Genieße dieses Gefühl!"

    # say L340 lis
    old "Let yourself fall deeply into it!"
    new "Lass dich tief hineinfallen!"

    # say L347 ana
    old "Oh gosh! I can't believe it!"
    new "Oh Gott! Ich kann es nicht fassen!"

    # say L348 ana
    old "I actually had an orgasm that way."
    new "Ich hatte tatsächlich einen Orgasmus auf diese Weise."

    # say L349 lis
    old "Of course, your body reacted positively to your Mudhalara chakra coming into balance."
    new "Natürlich hat dein Körper positiv auf die Ausbalancierung deines Mudhalara-Chakras reagiert."

    # say L350 lis
    old "That is the beauty of a tantric process."
    new "Das ist die Schönheit eines tantrischen Prozesses."

    # say L351 ana
    old "I have to say it was amazing!"
    new "Ich muss sagen, es war unglaublich!"

    # say L352 lis
    old "Haha, I'm glad you liked it."
    new "Haha, ich freue mich, dass es dir gefallen hat."

    # say L353 lis
    old "I'll let you get up now."
    new "Ich lass dich jetzt aufstehen."

    # say L361 ana
    old "Uhh, that was so good!"
    new "Uhh, das war so gut!"

    # say L362 ana
    old "I loved it!"
    new "Ich hab's geliebt!"

    # say L363 lis
    old "I see that your connection with yourself and the balance of your chakras is improving."
    new "Ich sehe, dass deine Verbindung zu dir selbst und das Gleichgewicht deiner Chakras sich verbessert."

    # say L364 lis
    old "I think that with this we can move on to the next exercise."
    new "Ich denke, damit können wir zum nächsten Übungsschritt übergehen."

    # say L365 ana
    old "Great!"
    new "Super!"

    # say L387 lis
    old "Remember to focus on your breathing, Anastasia."
    new "Denk dran, auf deinen Atem zu achten, Anastasia."

    # say L388 lis
    old "Feel the air going in and out of your body."
    new "Spür die Luft, die in deinen Körper ein- und wieder ausströmt."

    # say L389 lis
    old "Let go of any thoughts or worries, allowing them to drift away with your breath."
    new "Lass los, alle Gedanken und Sorgen, und lass sie mit deinem Atem davontreiben."

    # say L393 lis
    old "Continue to focus on this flow of energy, allowing it to move freely and naturally."
    new "Konzentriere dich weiter auf diesen Energiefluss, lass ihn frei und natürlich verlaufen."

    # say L394 lis
    old "With each breath, feel more relaxed and centered."
    new "Mit jedem Atemzug fühlst du dich entspannter und zentrierter."

    # say L395 lis
    old "Just breathe and let your energy flow in and out."
    new "Atme einfach und lass deine Energie fließen."

    # say L399 ana
    old "Mmm! This feels amazing, Lisa."
    new "Mmm! Das fühlt sich unglaublich an, Lisa."

    # say L400 lis
    old "Yes! Focus on that sensation!"
    new "Ja! Konzentriere dich auf dieses Gefühl!"

    # say L401 lis
    old "Let your body guide you in what you need!"
    new "Lass deinen Körper dir zeigen, was du brauchst!"

    # say L424 ana
    old "I'm about to... Cum Lisa!"
    new "Ich bin kurz davor... zu kommen Lisa!"

    # say L425 lis
    old "Yes! Yes! Let it all out!"
    new "Ja! Ja! Lass es alles raus!"

    # say L426 lis
    old "Let everything flow out of you!"
    new "Lass alles aus dir herausfließen!"

    # say L434 ana
    old "Oh that was so amazing!"
    new "Oh das war unglaublich!"

    # say L435 ana
    old "It felt so good!"
    new "Das war unglaublich gut!"

    # say L436 lis
    old "I'm glad you enjoyed it, that's your Mudhalara chakra coming into balance."
    new "Ich freue mich, dass es dir gefallen hat, das ist dein Mudhalara-Chakra, das sich ausbalanciert."

    # say L437 lis
    old "I belive we're on the right path."
    new "Ich glaube, wir sind auf dem richtigen Weg."

    # say L438 lis
    old "But now, let's get up, so that [pla] can also rest a little."
    new "Aber jetzt, lass uns aufstehen, damit [pla] auch ein bisschen ausruhen kann."

    # say L450 lis
    old "Relax, feel the depth of your energy."
    new "Entspann dich, spür die Tiefe deiner Energie."

    # say L451 lis
    old "Feel how far it goes inside you."
    new "Spür, wie tief es in dir drin ist."

    # say L452 lis
    old "And the connection [pla]'s helping you achieve."
    new "Und die Verbindung [pla] hilft dir dabei."

    # say L456 lis
    old "Do you feel it, Anastasia?"
    new "Spürst du es, Anastasia?"

    # say L457 lis
    old "How deep inside you your energy goes?"
    new "Wie tief in dir drin deine Energie fließt?"

    # say L458 lis
    old "Do you feel it flowing?"
    new "Spürst du es fließen?"

    # say L459 ana
    old "Y-Yes I do."
    new "Ja, ich spüre es."

    # say L460 ana
    old "I can feel it very deep inside me!"
    new "Ich spüre es tief in mir!"

    # say L464 lis
    old "Do you feel your energy flowing inside, Anastasia?"
    new "Spürst du, wie deine Energie in dir fließt, Anastasia?"

    # say L465 ana
    old "Oh yes! It's going so far inside me!"
    new "Oh ja! Es geht so tief in mir rein!"

    # say L466 ana
    old "I love how it feels!"
    new "Ich liebe, wie sich das anfühlt!"

    # say L489 ana
    old "Lisa! [pla]! I can't hold it in anymore!"
    new "Lisa! [pla]! Ich halte es nicht mehr aus!"

    # say L490 lis
    old "Don't! Let yourself go!"
    new "Lass es raus!"

    # say L491 lis
    old "Let it all out!"
    new "Lass es raus!"

    # say L499 lis
    old "How do you feel, Anastasia?"
    new "Wie fühlst du dich, Anastasia?"

    # say L500 ana
    old "I feel amazing!"
    new "Ich fühle mich fantastisch!"

    # say L501 lis
    old "Were you able to make an internal connection?"
    new "Könntest du eine innere Verbindung herstellen?"

    # say L502 ana
    old "I can feel it all inside me."
    new "Ich kann es alles in mir spüren."

    # say L503 lis
    old "Wonderful! That was the objective of this!"
    new "Wunderbar! Das war das Ziel davon!"

    # say L504 ana
    old "Now, time to get up and get cleaned up."
    new "Jetzt, Zeit aufzustehen und mich zu säubern."


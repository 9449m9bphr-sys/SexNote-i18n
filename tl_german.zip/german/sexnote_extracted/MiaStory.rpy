# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/MiaStory.rpy
translate german strings:

    # say L11 mia
    old "Hmph, I see you're late again [pla], you never learn, do you?"
    new "Hmpf, ich sehe, Sie sind wieder einmal zu spät [pla], Sie lernen nie, oder?"

    # say L12 mia
    old "Although that's not really a surprise, you're always doing this kinda stuff."
    new "Das ist ja auch nicht überraschend, Sie machen das immer wieder."

    # say L13 pla
    old "Uhh... Good morning, Miss Mia."
    new "Uhh... Guten Morgen, Miss Mia."

    # say L14 mia
    old "I'm sorry? Don't think that you can be a wise ass with me young man, and get in the classroom already! We're about to start."
    new "Entschuldigung? Denken Sie nicht, dass Sie mit mir schlau werden können, junger Mann, und kommen Sie endlich in die Klasse! Wir sind gleich los."

    # say L15 mia
    old "Don't you see there are some students that DO care about studying?"
    new "Sehen Sie denn nicht, dass es Schüler gibt, die sich tatsächlich fürs Lernen interessieren?"

    # say L23 pla
    old "(What the hell got into her?)"
    new "Was ist denn plötzlich in sie gefahren?"

    # say L24 pla
    old "(Gosh, this is gonna be a looong day)"
    new "(Gott, das wird ein langer Tag)"

    # say L29 mia
    old "As you can see, establishing a single reason for the start of world war I is nearly impossible."
    new "Wie Sie sehen können, ist es fast unmöglich, einen einzigen Grund für den Ausbruch des Ersten Weltkriegs zu nennen."

    # say L30 mia
    old "Certainly the detonating event was the killing of Archduke Franz Ferdinand."
    new "Natürlich war der Auslösezeitpunkt der Mord an Erzherzog Franz Ferdinand."

    # say L31 mia
    old "But as I explained already, this was merely a consequence of the authoritarian rule..."
    new "Aber wie ich schon erklärt habe, war dies lediglich eine Folge der autoritären Herrschaft..."

    # say L34 pla
    old "(Geez this is boring... What do I need to know any of this stuff for?)"
    new "Mann, das ist ja langweilig... Wozu brauche ich all diesen Kram überhaupt?"

    # say L54 pla
    old "(Isn't she wearing underwear?)"
    new "(Trägt sie eigentlich Unterwäsche?)"

    # say L62 mia
    old "As I was saying, what's most important to remember when examining the causes of the war..."
    new "Wie ich sagte, was am wichtigsten ist, wenn man die Ursachen des Krieges untersucht..."

    # say L63 mia
    old "It's that the political climate of Europe was tremendously charged..."
    new "Das politische Klima in Europa war unglaublich angespannt..."

    # say L67 pla
    old "{i}Hey Mike, dude! Did you see that?! {/i}"
    new "{i}Hey Mike, Alter! Hast du das gesehen?! {/i}"

    # say L68 mik
    old "{i}U-uh? Are you talking to me? Did Ms. Mia ask a question?{/i}"
    new "{i}U-ah? Sprechen Sie mit mir? Hat Frau Mia eine Frage gestellt?{/i}"

    # say L69 pla
    old "{i}What? No dude! You didn't see that?{/i}"
    new "{i}Waaas? Nein, Alter! Hast du das nicht gesehen?{/i}"

    # say L70 mik
    old "{i}See what?{/i}"
    new "{i}Wovon redest du?{/i}"

    # say L71 pla
    old "{i}Nevermind...{/i}"
    new "{i}Egal...{/i}"

    # say L72 pla
    old "(Was I the only one that saw that?)"
    new "Hab ich das etwa als Einziger gesehen?"

    # say L73 pla
    old "(I'm sure I saw she wasn't wearing any panties.)"
    new "Ich bin mir sicher, dass ich gesehen habe, dass sie keinen Slip trug."

    # say L75 mia
    old "Ok guys, that's today's class, remember I'm going to need you to write a three-page report on the causes of world war I for the next class."
    new "Ok Leute, das war die Stunde von heute, denkt dran, ich brauche von euch eine dreiseitige Abhandlung über die Ursachen des Ersten Weltkriegs für die nächste Stunde."

    # say L76 mia
    old "And [pla], remember to be on time for next time!"
    new "Und [pla], denken Sie daran, pünktlich zu sein beim nächsten Mal!"

    # say L98 mia
    old "Hmm, late again! You just never learn, do you [pla]?"
    new "Hmm, wieder zu spät! Das lernst du wohl nie, oder [pla]?"

    # say L99 pla
    old "Hi Miss Mia, were you waiting for me? I mean, I'm just on time."
    new "Hi Miss Mia, hast du auf mich gewartet? Ich meine, ich bin doch gerade noch pünktlich."

    # say L100 mia
    old "Just on time to interrupt the class by entering late!"
    new "Pünktlich genug, um die Klasse durch dein Spätkommen zu stören!"

    # say L101 mia
    old "I'm telling you, you better straighten up!"
    new "Ich sage Ihnen, Sie sollten sich besser zusammenreißen!"

    # say L110 dir
    old "Oh! Mia, good morning."
    new "Oh! Mia, guten Morgen."

    # say L111 mia
    old "Good Morning ma'am, how are you today?"
    new "Guten Morgen, wie geht es Ihnen heute?"

    # say L112 dir
    old "I'm pretty good, thank you, just checking up on things before I go to my office to start the day."
    new "Ich bin ziemlich gut, danke, ich schaue nur kurz alles durch, bevor ich ins Büro gehe, um den Tag zu beginnen."

    # say L113 dir
    old "By the way, don't you think it's about time for you to start with your class?"
    new "Übrigens, findest du nicht, dass es Zeit wird, mit deinem Unterricht zu beginnen?"

    # say L115 mia
    old "You're right, sorry ma'am, I was just waiting for this student, he needs a little extra attention."
    new "Sie haben recht, entschuldigen Sie bitte, ich habe nur auf diesen Schüler gewartet, der braucht ein bisschen mehr Aufmerksamkeit."

    # say L117 mia
    old "This is [pla]."
    new "Das ist [pla]."

    # say L118 pla
    old "Good morning ma'am.."
    new "Guten Morgen, Frau."

    # say L120 dir
    old "Ah, this is the student you told me about."
    new "Ah, das ist der Schüler, von dem Sie mir erzählt haben."

    # say L122 dir
    old "Well [pla], given what Mia has told me about you, I don't think it's very good that you're arriving this late to class."
    new "Na [pla], wenn man bedenkt, was Mia mir über dich erzählt hat, finde ich es gar nicht gut, dass du so spät zur Stunde kommst."

    # say L123 pla
    old "You're right ma'am, I'm sorry."
    new "Sie haben recht, Frau, es tut mir leid."

    # say L124 dir
    old "Trust me, you don't want to see your classmates move on and you being stuck here."
    new "Vertrau mir, du willst nicht sehen, wie deine Klassenkameraden weiterkommen und du hier steckst."

    # say L125 dir
    old "So, make sure you buckle down and start studying seriously."
    new "Dann sorg dafür, dass du dich ernsthaft ins Zeug legst und anfängst zu lernen."

    # say L126 dir
    old "Otherwise you'll have to come here and take extra classes during your Holidays."
    new "Sonst musst du im Sommer hierherkommen und Nachhilfe nehmen."

    # say L127 pla
    old "You're right, ma'am."
    new "Sie haben recht, Ma'am."

    # say L128 dir
    old "Just keep it in mind. Mia already has an eye on you, be thankful that your teacher cares so much."
    new "Behalt es im Hinterkopf. Mia hat schon ein Auge auf dich geworfen, sei dankbar, dass deine Lehrerin sich so um dich sorgt."

    # say L129 pla
    old "Hmm... Yes ma'am."
    new "Hmm... Ja, Ma'am."

    # say L130 dir
    old "Good boy."
    new "Guter Junge."

    # say L131 dir
    old "Now Mia, I think it's time for you to start your class."
    new "Jetzt, Mia, ich denke, es ist Zeit für dich, deinen Unterricht zu beginnen."

    # say L132 mia
    old "Yes ma'am, I'm about to."
    new "Ja, Ma'am, ich bin gerade dabei."

    # say L133 mia
    old "Have a very good day ma'am."
    new "Einen sehr schönen Tag noch, Ma'am."

    # say L134 dir
    old "You too dear."
    new "Du auch, Liebes."

    # say L142 mia
    old "You see? That's your second warning about your studies. You better listen!"
    new "Sie sehen? Das ist Ihre zweite Warnung wegen Ihrer Studien. Sie sollten besser darauf hören!"

    # say L143 mia
    old "And come in!"
    new "Und kommen Sie herein!"

    # say L149 mia
    old "Ok guys, we'll continue with the world war one chapter."
    new "Ok Leute, wir fahren mit dem Kapitel über den Ersten Weltkrieg fort."

    # say L150 mia
    old "This time we'll talk about Africa and the Ottoman Empire during this period of time."
    new "Dieses Mal sprechen wir über Afrika und das Osmanische Reich in dieser Zeit."

    # say L156 mia
    old "Is it me or is it really hot today? I think I need to get a bit more comfortable."
    new "Ist es nur ich oder ist es heute wirklich heiß? Ich denke, ich muss mich ein bisschen wohler fühlen."

    # say L160 pla
    old "(What the fuck?! She's not wearing a bra!)"
    new "Was zur Hölle?! Sie trägt keinen BH!"

    # say L161 pla
    old "(What's happening with her?)"
    new "(Was ist mit ihr los?)"

    # say L169 mia
    old "Phew, too much better, ok, let's continue with the subject..."
    new "Phew, viel besser, okay, lassen Sie uns mit dem Thema fortfahren..."

    # say L171 mik
    old "{i}Dude! Are you seeing what I'm seeing?{/i}"
    new "{i}Kumpel! Siehst du das auch, was ich sehe?{/i}"

    # say L174 mik
    old "{i}I don't know, but this is totally rad!{/i}"
    new "{i}Keine Ahnung, aber das ist total krass!{/i}"

    # say L176 mia
    old "Is there something you want to share with the class? Or can I continue with the class."
    new "Gibt es etwas, das Sie mit der Klasse teilen möchten? Oder kann ich mit dem Unterricht fortfahren."

    # say L177 mik
    old "U- uh, sorry Miss Mia."
    new "U- äh, tut mir leid, Miss Mia."

    # say L178 pla
    old "Yeah, sorry."
    new "Ja, tut mir leid."

    # say L179 mia
    old "Honestly, I would hope that you of all people should be the one paying the most attention [pla]."
    new "Ehrlich gesagt, hätte ich gedacht, dass Sie von allen am meisten aufpassen [pla]."

    # say L180 mia
    old "Let me remind you that your grades have been terrible."
    new "Lassen Sie mich daran erinnern, dass Ihre Noten katastrophal waren."

    # say L181 mia
    old "I imagine that paper you had to write must be excellent, right?"
    new "Ich stelle mir vor, dass die Arbeit, die Sie schreiben mussten, hervorragend ist, oder?"

    # say L182 pla
    old "I said I was sorry..."
    new "Ich hab mich entschuldigt..."

    # say L183 mia
    old "Hmph, you better be."
    new "Hmph, Sie hätten besser sein lassen."

    # say L184 mia
    old "I'm sorry class, let's just continue, I know some of you actually want to learn."
    new "Entschuldigung, Klasse, lasst uns einfach weitermachen, ich weiß, dass einige von euch tatsächlich lernen wollen."

    # say L191 mik
    old "Dude! [pla], did you notice?!"
    new "Kerl! [pla], hast du das gesehen?!"

    # say L192 mik
    old "You could see her nipples! It was the best class ever!"
    new "Du konntest ihre Nippel sehen! Es war der beste Unterricht je!"

    # say L193 pla
    old "Yeah, that was weird."
    new "Ja, das war seltsam."

    # say L202 mik
    old "Hey Belle, did you see that?"
    new "Hey Belle, hast du das gesehen?"

    # say L203 mik
    old "Now we have a new motivation to come to class!"
    new "Jetzt haben wir eine neue Motivation, in die Klasse zu kommen!"

    # say L205 bel
    old "Yes, I noticed that Miss Mia wasn't wearing a bra... I assume that's what you mean?"
    new "Ja, ich hab’s gesehen, dass Miss Mia keinen BH getragen hat... Das meinst du doch, oder?"

    # say L206 pla
    old "That was weird, and it's not the first time, last class I also noticed something."
    new "Das war seltsam, und es ist nicht das erste Mal, letzte Stunde habe ich auch was bemerkt."

    # say L207 bel
    old "Yeah, I also saw that."
    new "Ja, das hab ich auch gesehen."

    # say L210 mik
    old "What? Last class?"
    new "Was? Letzte Stunde?"

    # say L211 mik
    old "I didn't see anything."
    new "Ich hab nichts gesehen."

    # say L212 mik
    old "What was it? What was it?"
    new "Was war es? Was war es?"

    # say L215 bel
    old "There's something odd about Ms. Mia's behavior lately."
    new "Es gibt etwas Seltsames an Ms. Mias Verhalten in letzter Zeit."

    # say L216 pla
    old "I know what you mean."
    new "Ich weiß, was du meinst."

    # say L217 pla
    old "But I guess that's none of our concern."
    new "Aber das geht uns wohl nichts an."

    # say L220 bel
    old "By the way, I'm going over to Billie's to hang out."
    new "Übrigens, ich geh zu Billie rüber, um abzuhängen."

    # say L221 bel
    old "You guys wanna come?"
    new "Wollt ihr mitkommen?"

    # say L224 pla
    old "I would love to."
    new "Ich würde liebend gern kommen."

    # say L225 pla
    old "But I have to get working on the next project, otherwise Ms. Mia will never get off my back."
    new "Aber ich muss an dem nächsten Projekt arbeiten, sonst wird Ms. Mia mir nie von der Pelle gehen."

    # say L226 bel
    old "She really doesn't like you, does she?"
    new "Sie mag dich wirklich nicht, oder?"

    # say L227 pla
    old "Ha, that's saying little."
    new "Ha, das ist noch untertrieben."

    # say L229 pla
    old "Oh, damn, I just realized, I forgot my notes in the classroom."
    new "Oh, verdammt, mir ist gerade aufgefallen, dass ich meine Notizen im Klassenzimmer vergessen habe."

    # say L230 pla
    old "I have to go back and grab them. See you later guys!"
    new "Ich muss noch mal zurück, um sie zu holen. Bis später, Leute!"

    # say L239 mik
    old "So, where are we going Belle?"
    new "Also, wohin gehen wir, Belle?"

    # say L251 mia
    old "Yeah, yeah, I did what you asked!! Okay?!"
    new "Ja, ja, ich habe getan, was Sie verlangt haben!! Okay?!"

    # say L252 mia
    old "Yeah, but I won't be doing that shit again!"
    new "Aber ich mach das Scheißzeug nicht noch mal!"

    # say L253 mia
    old "This was so embarrassing. You went way overboard with this!"
    new "Das war so peinlich. Sie sind da wirklich zu weit gegangen!"

    # say L254 mia
    old "And I'm telling you now, I'm not doing anything more in public!"
    new "Und ich sage Ihnen jetzt, ich mache nichts mehr in der Öffentlichkeit!"

    # say L259 mia
    old "What...?!"
    new "Was...?!"

    # say L260 mia
    old "Ugh, great, just what I needed!"
    new "Ugh, toll, genau das, was ich gebraucht habe!"

    # say L262 pla
    old "Um, sorry, I just came back to pick up my notes, I'm leaving now."
    new "Äh, tut mir leid, ich bin nur zurückgekommen, um meine Notizen zu holen, ich gehe jetzt."

    # say L269 mia
    old "Uh? What? Him?"
    new "Uh? Was? Er?"

    # say L270 mia
    old "He's nobody, just another one of my stupid students."
    new "Er ist niemand, nur einer meiner dummen Schüler."

    # say L271 mia
    old "Nah, he just came in, he heard nothing."
    new "Nein, er ist gerade erst hereingekommen, er hat nichts gehört."

    # say L272 mia
    old "What does his name have to do with anything?"
    new "Was hat sein Name damit zu tun?"

    # say L273 mia
    old "Yeah, I don't like him, so what?"
    new "Na und, ich mag ihn nicht, was soll's?"

    # say L274 mia
    old "What? Listen, that doesn't have anything to do with our conversation."
    new "Was? Hören Sie, das hat nichts mit unserem Gespräch zu tun."

    # say L275 mia
    old "The point is that I'm not doing anything else, so you better stop harassing me, you got that?!"
    new "Der Punkt ist, dass ich nichts anderes mache, also lassen Sie mich in Ruhe, kapiert?!"

    # say L284 pla
    old "Hmm, I guess Mike and Belle already left."
    new "Hmm, ich schätze, Mike und Belle sind schon gegangen."

    # say L285 pla
    old "(But what the hell was that phone call about? That was so weird.)"
    new "Aber was zur Hölle war das für ein Handy-Anruf? Das war ja total seltsam."

    # say L286 pla
    old "(Although I guess it's not my business.)"
    new "(Aber ich schätze, das geht mich nichts an.)"

    # say L301 mia
    old "All right guys, today we'll talk about American development during the period from 1925 to 1938, the period between the two world wars..."
    new "Na gut, Jungs, heute sprechen wir über die amerikanische Entwicklung im Zeitraum von 1925 bis 1938, der Periode zwischen den beiden Weltkriegen..."

    # say L302 pla
    old "(God this is so fucking boring.)"
    new "(Gott, das ist ja so was von langweilig.)"

    # say L304 pla
    old "(What?)"
    new "(Was?)"

    # say L305 pla
    old "(Is she looking at me?)"
    new "(Ist sie mich anstarren?)"

    # say L306 mia
    old "The European crisis allowed the emergence of powerful industrialists, like Rockefeller and Ford."
    new "Die europäische Krise ermöglichte den Aufstieg mächtiger Industrieller wie Rockefeller und Ford."

    # say L307 pla
    old "(Why does she look so angry?)"
    new "Warum sieht sie so wütend aus?"

    # say L313 mia
    old "Ok, guys, that's it for today, for the next class I'll need you to read about the treaty of Versailles."
    new "Okay, Leute, das war's für heute, für die nächste Stunde müsst ihr über den Vertrag von Versailles lesen."

    # say L319 mik
    old "Aw, dude, that was so dull!"
    new "Mann, das war ja total langweilig!"

    # say L320 mik
    old "I'm exhausted, can't wait for lunch."
    new "Ich bin müde, kann es kaum erwarten, zu Mittag zu essen."

    # say L330 mia
    old "Hey [pla], I'm going to need you to stay."
    new "Hey [pla], ich muss Sie bitten, noch zu bleiben."

    # say L332 mik
    old "Uh-oh, you're in trouble dude. I think I better get going home."
    new "Oh je, da bist du in Schwierigkeiten, Kumpel. Ich glaube, ich sollte besser nach Hause gehen."

    # say L334 mik
    old "Good luck dude."
    new "Viel Glück, Alter."

    # say L336 pla
    old "See you dude."
    new "Bis dann, Alter."

    # say L343 pla
    old "If this is about the project I-"
    new "Wenn das wegen dem Projekt ist, ich-"

    # say L344 mia
    old "Oh shut up! Just shut up! Who cares about that stupid project?!"
    new "Oh halten Sie den Mund! Einfach den Mund halten! Wer interessiert sich schon für dieses blöde Projekt?!"

    # say L345 pla
    old "Uh w-what? But you said..."
    new "Uh w-was? Aber du hast gesagt..."

    # say L346 mia
    old "So, it was you, wasn't it?!"
    new "So, Sie waren das also, oder?!"

    # say L347 mia
    old "I see, of course, he had someone on the inside."
    new "Ich sehe, natürlich, er hatte jemanden im Haus."

    # say L348 mia
    old "You're the bastard that's been verifying that I do his stupid challenges. I should've known."
    new "Sie sind der Bastard, der die ganze Zeit überprüft hat, ob ich seine blöden Herausforderungen erfülle. Das hätte ich mir denken können."

    # say L349 pla
    old "Uhmm, what? What are you talking about?"
    new "Hmm, was? Wovon redest du?"

    # say L351 mia
    old "Well, I'll let you know I'm tired of this bullshit! You better not think you'll keep getting away with this disgusting behavior."
    new "Nun, ich werde Ihnen sagen, dass ich es satt habe, mit diesem Scheiß fertig zu werden! Sie sollten besser nicht denken, dass Sie damit durchkommen werden, dieses widerliche Verhalten fortzusetzen."

    # say L352 mia
    old "I was so stupid not to realize it was you, of course, you were the clear option."
    new "Ich war so dumm, es nicht zu erkennen. Natürlich waren Sie die klare Wahl."

    # say L353 mia
    old "I should've known from the beginning. It was obvious."
    new "Ich hätte es von Anfang an wissen sollen. Es war offensichtlich."

    # say L354 pla
    old "Excuse me, I don't know what you're accusing me of, but I haven't done anything."
    new "Entschuldige, ich habe keine Ahnung, wovon du redest, aber ich habe nichts getan."

    # say L355 mia
    old "Will you stop playing dumb already?!!! You know very well what I'm talking about!"
    new "Wollen Sie endlich aufhören, dumm zu spielen?! Sie wissen genau, wovon ich spreche!"

    # say L356 mia
    old "Or are you telling me you haven't been following that bastard Denzel's orders to spy on me?"
    new "Oder wollen Sie mir weismachen, dass Sie nicht auf die Befehle dieses Bastards Denzel gehört haben, um mich auszuspionieren?"

    # say L357 pla
    old "Denzel? What the-"
    new "Denzel? Was zum-"

    # say L358 mia
    old "Or that you just happened to come into the classroom just as I was reporting to him?!"
    new "Oder dass du zufällig ins Klassenzimmer gekommen bist, während ich ihm Bericht erstattete?!"

    # say L359 mia
    old "I know you're a bastard, but spare me your stupid lies!"
    new "Ich weiß, dass Sie ein Bastard sind, aber ersparen Sie mir Ihre blöden Lügen!"

    # say L360 pla
    old "I already told you I don't know what you're talking about!"
    new "Ich hab dir schon gesagt, ich hab keine Ahnung, wovon du redest!"

    # say L361 mia
    old "Ugh, whatever, let's just get this over with."
    new "Pfff, egal, lass uns das einfach hinter uns bringen."

    # say L369 pla
    old "Woah! Woah! What do you think you're doing?"
    new "Woah! Woah! Was denkst du dir eigentlich?"

    # say L370 mia
    old "Will you stop pretending you don't know what's going on?!!"
    new "Wollen Sie aufhören, so zu tun, als wüssten Sie nicht, was los ist?!!"

    # say L371 mia
    old "How can you keep acting like this after all that you've made me do?!"
    new "Wie können Sie nach allem, was Sie mich haben tun lassen, weiter so tun?"

    # say L372 mia
    old "At least pretend you have some decency, will you?!"
    new "Zumindest vorgeben, dass Sie noch Anstand haben, ja?!"

    # say L373 pla
    old "I-I don't... W- what do you mean?"
    new "Ich hab doch keine Ahnung, wovon du redest."

    # say L374 pla
    old "I already told you, I have no idea what you're talking about."
    new "Ich hab's dir schon gesagt, ich hab keine Ahnung, wovon du redest."

    # say L375 mia
    old "Yeah right... As if I'll believe anything you say."
    new "Natürlich... Als ob ich Ihnen auch nur ein Wort glauben würde."

    # say L376 mia
    old "But I'll give you what you want, you sick freak."
    new "Aber ich gebe dir, was du willst, du kranker Perversling."

    # say L385 mia
    old "Listen, I've had enough of your bullshit for one day."
    new "Hören Sie, ich habe genug von Ihrem Quatsch für heute."

    # say L386 mia
    old "I already sent that asshole the picture. Just leave me alone."
    new "Ich habe dem Arschloch das Bild schon geschickt. Lass mich einfach in Ruhe."

    # say L393 pla
    old "What the fuck?!"
    new "Was zum Teufel?!"

    # say L415 mia
    old "Of course, your little accomplice would come!"
    new "Natürlich würde Ihr kleiner Komplize kommen!"

    # say L416 mia
    old "What are you two, sick freaks, planning now?"
    new "Was planen Sie beiden kranken Freaks jetzt wieder?"

    # say L417 pla
    old "W- what? I... What are you talking about?"
    new "W-was? Ich... Wovon redest du?"

    # say L418 pla
    old "I just came early for class!"
    new "Ich bin doch nur früh für die Klasse gekommen!"

    # say L419 mia
    old "Ugh! Denzel, could you tell your little minion to stop acting?"
    new "Ugh! Denzel, könnten Sie Ihrem kleinen Lakaien sagen, aufzuhören zu schauspielern?"

    # say L421 den
    old "Well, Miss Mia, I must say this is the first time I've seen your student."
    new "Nun, Miss Mia, ich muss sagen, das ist das erste Mal, dass ich Ihren Schüler sehe."

    # say L422 den
    old "I don't even know his name."
    new "Ich kenne seinen Namen noch nicht mal."

    # say L423 mia
    old "What?! What do you mean?"
    new "Was?! Was meinen Sie damit?"

    # say L425 den
    old "Well, I don't think you even have enough in that empty head of yours to remember."
    new "Na, ich glaube nicht, dass in deinem leeren Kopf genug drin ist, um dich daran zu erinnern."

    # say L426 den
    old "But while you were my teacher, you made my life miserable, absolutely horrible."
    new "Aber während du meine Lehrerin warst, hast du mein Leben elendig gemacht, absolut schrecklich."

    # say L427 den
    old "And from what I can see, that's something you're still doing..."
    new "Und soweit ich sehen kann, machst du das immer noch..."

    # say L429 den
    old "Well, I've noticed you always pick on a poor and innocent guy from your classes to torment."
    new "Na ja, ich hab bemerkt, dass du immer einen armen und unschuldigen Kerl aus deinen Klassen auswählst, um ihn zu quälen."

    # say L430 den
    old "Tremendously immature of you, I must say, someone would think a teacher would be a little bit more... nuanced."
    new "Das finde ich ziemlich unreif von dir, muss ich sagen. Man würde denken, eine Lehrerin wäre ein bisschen... nuancierter."

    # say L431 den
    old "So, the other day, after listening to your answer when we were talking and you got interrupted by him."
    new "Also, neulich, nachdem ich deine Antwort gehört habe, als wir uns unterhalten haben und er dich unterbrochen hat."

    # say L432 den
    old "It came to my mind, why not give the young guy a chance to take some revenge on his horrible teacher?"
    new "Mir kam der Gedanke, warum nicht dem jungen Mann die Chance geben, sich an seinem schrecklichen Lehrer zu rächen?"

    # say L433 mia
    old "... The fuck?"
    new "... Was zum Teufel?"

    # say L434 pla
    old "W-w-what the hell is happening? What are you guys talking about?"
    new "W-w-was zur Hölle geht hier vor? Wovon sprecht ihr?"

    # say L436 den
    old "Oh, how rude of me, I went into a monologue without even introducing myself. Apologies buddy."
    new "Oh, wie unhöflich von mir, ich bin in ein Monolog verfallen, ohne mich vorzustellen. Entschuldigung, Kumpel."

    # say L437 den
    old "My name is Denzel, and just like you, I was once a victim of this so-called teacher's horrible personality."
    new "Mein Name ist Denzel, und genau wie du war ich einmal Opfer dieser angeblichen Lehrerin und ihrer schrecklichen Persönlichkeit."

    # say L439 den
    old "She used to be my teacher, and she made my life miserable too."
    new "Sie war auch meine Lehrerin und hat mir das Leben zur Hölle gemacht."

    # say L441 den
    old "I never forgave her, but I didn't actually have any way to get back at her for anything."
    new "Ich hab ihr nie verziehen, aber ich hatte keine Möglichkeit, mich an ihr zu rächen."

    # say L442 den
    old "That is, until recently, when I learned a couple of things from her past that she would prefer to have hidden."
    new "Das hat sich erst kürzlich geändert, als ich ein paar Dinge aus ihrer Vergangenheit erfahren habe, die sie lieber geheim halten würde."

    # say L443 mia
    old "No! Don't say anything about that! Please, I'm already doing whatever you ask me."
    new "Nein! Sagen Sie nichts darüber! Bitte, ich tue schon alles, was Sie von mir verlangen."

    # say L445 pla
    old "W-what are you talking about?"
    new "W-wovon sprechen Sie?"

    # say L447 den
    old "Go ahead Mia, tell your favorite student all about your past..."
    new "Los, Mia, erzähl deinem Lieblingsstudenten alles über deine Vergangenheit..."

    # say L448 mia
    old "Please... No..."
    new "Bitte... Nein..."

    # say L450 den
    old "I mean, there's nothing to feel ashamed about, is there?"
    new "Ich meine, da gibt es doch nichts, wofür du dich schämen müsstest, oder?"

    # say L455 den
    old "That's right! Can you believe it? She's always so self-righteous, always taking her anger out on other people."
    new "Stimmt! Kannst du es fassen? Sie ist immer so selbstgerecht und nimmt ihren Frust an anderen aus."

    # say L456 den
    old "She's offensive, arrogant, and demanding, when she used to be just a whore!"
    new "Sie ist beleidigend, arrogant und fordernd, dabei war sie früher nur eine Nutte!"

    # say L458 den
    old "Anyway, she got out of that, but I found out and got proof that she used to be a pornstar."
    new "Na ja, sie ist da rausgekommen, aber ich hab es rausgefunden und habe Beweise, dass sie früher Pornodarstellerin war."

    # say L459 den
    old "And if she doesn't want to be fired, and get her life ruined,  she'll have to do as I say."
    new "Und wenn sie ihren Job behalten und ihr Leben nicht ruinieren will, muss sie tun, was ich sage."

    # say L460 den
    old "Or I'll out her as the whore she is, and her life here will be over."
    new "Oder ich mache sie öffentlich zur Hure, und ihr Leben hier ist vorbei."

    # say L461 mia
    old "You fucking bastard!"
    new "Sie verdammter Bastard!"

    # say L463 den
    old "Oh, call me what you want, that only makes it better when I punish you."
    new "Oh, nenn mich, wie du willst, das macht es nur besser, wenn ich dich bestrafe."

    # say L466 den
    old "By the way... I think it's about time for your next punishment."
    new "Übrigens... ich glaube, es ist Zeit für deine nächste Strafe."

    # say L467 den
    old "Oh, sorry, we're calling them challenges. Right?"
    new "Oh, entschuldige, wir nennen sie jetzt Herausforderungen. Richtig?"

    # say L468 mia
    old "Challenge? Punishment?!"
    new "Herausforderung? Bestrafung?!"

    # say L469 mia
    old "This is blackmail! And abuse!"
    new "Das ist Erpressung! Und Missbrauch!"

    # say L470 den
    old "Call it whatever you want, but you have to do it."
    new "Nenn es, wie du willst, aber du musst es tun."

    # say L471 den
    old "And seeing as your favorite student's here, why don't we have you give him a little bit of attention?"
    new "Und da dein Lieblings-Schüler hier ist, warum gibst du ihm nicht ein bisschen Aufmerksamkeit?"

    # say L473 den
    old "Give him a blowjob."
    new "Ihm einen blasen."

    # say L474 mia
    old "What?! You must be kidding me! A blowjob?!"
    new "Was?! Sie müssen mich auf den Arm nehmen! Ein Blowjob?!"

    # say L475 mia
    old "This is going way too far!"
    new "Das geht wirklich zu weit!"

    # say L476 mia
    old "Didn't you have enough with your pictures and stuff?"
    new "Haben Sie mit Ihren Fotos und so nicht schon genug?"

    # say L477 den
    old "Oh, I really enjoyed those, but that's not what I want right now."
    new "Oh, die Fotos haben mir echt gefallen, aber das ist jetzt nicht, was ich will."

    # say L478 den
    old "I already told you what to do, take out his dick and suck it!"
    new "Ich hab dir schon gesagt, was du tun sollst, hol seinen Schwanz raus und blas ihn!"

    # say L479 den
    old "Otherwise I suppose tomorrow the school principal will receive a mail with an interesting video."
    new "Sonst wird morgen wohl der Schulleiter ein interessantes Video per Mail bekommen."

    # say L492 mia
    old "You sick freak..."
    new "Sie kranker Perversling..."

    # say L493 mia
    old "I'll do it, ok? Just don't spread anything, ok?"
    new "Ich mach's, okay? Nur verbreiten Sie nichts, okay?"

    # say L496 mia
    old "Ugh, come here [pla]... I'll do this quickly."
    new "Ugh, komm her [pla]... Ich mach das schnell."

    # say L498 pla
    old "Y- you can't be serious."
    new "Kannst du das ernsthaft meinen?"

    # say L499 mia
    old "Well, what do you think stupid?!"
    new "Na, was denken Sie denn dummes?!"

    # say L500 mia
    old "I wouldn't joke about this shit."
    new "Ich würde nicht über so was Witze machen."

    # say L501 pla
    old "I- I'm sorry Miss Mia, but I don't have anything to do with this. I should just leave."
    new "I- Ich bin Ihnen sehr leid, Miss Mia, aber ich habe damit nichts zu tun. Ich sollte einfach gehen."

    # say L508 den
    old "Well, I guess you could just leave. But if you do, I'll just leak the information I have about her."
    new "Na gut, Sie könnten einfach gehen. Aber wenn Sie das tun, werde ich die Informationen, die ich über sie habe, weitergeben."

    # say L509 den
    old "That's also an option by the way."
    new "Das ist auch eine Option, oder?"

    # say L511 den
    old "After all, she's also been cruel to you all this time, you may as well just let her suffer with this."
    new "Schließlich war sie dir die ganze Zeit auch nicht gerade freundlich gesinnt, da kannst du sie ruhig mit dem hier leiden lassen."

    # say L513 den
    old "Tell you what, maybe you'll change your mind if you see her beg for it. How about it?"
    new "Sag mal, vielleicht überlegst du es dir anders, wenn du sie betteln siehst. Was meinst du?"

    # say L515 den
    old "Go ahead Mia, beg him to let you suck his dick, remember what's at stake here for you."
    new "Los, Mia, bettle ihn an, dir seinen Schwanz lutschen zu lassen. Denk dran, was auf dem Spiel steht."

    # say L517 mia
    old "Listen, [pla] I don't want this to happen any more than you do."
    new "Hören Sie, [pla] ich will das genauso wenig wie Sie."

    # say L518 den
    old "Ha! What a weird way to beg! heh."
    new "Ha! Was für eine seltsame Art zu betteln! heh."

    # say L519 mia
    old "But if we don't do this, he'll just release his disgusting pictures and videos of me."
    new "Aber wenn wir das nicht tun, wird er einfach seine widerlichen Fotos und Videos von mir veröffentlichen."

    # say L520 mia
    old "Please, please, please help me out."
    new "Bitte, bitte, bitte helfen Sie mir."

    # say L521 mia
    old "After my life went to shit because of what happened before, it's taken me so much work to create something here."
    new "Nachdem mein Leben durch das, was vorher passiert ist, den Bach runterging, habe ich so viel Arbeit investiert, um hier etwas aufzubauen."

    # say L522 den
    old "Aww, you're breaking my heart."
    new "Ach, das bricht mir das Herz."

    # say L524 pla
    old "Hmm, ok, I'll do it."
    new "Hmm, okay, ich mach's."

    # say L526 den
    old "You will, Ha! I knew it, you also want to get revenge on her, right?"
    new "Du wirst, Ha! Ich wusste es, du willst dich auch an ihr rächen, oder?"

    # say L527 pla
    old "No!"
    new "Nein!"

    # say L528 pla
    old "I'll do it just to help her, I don't want revenge on anyone."
    new "Ich mach's nur, um ihr zu helfen, ich will niemandem Rache."

    # say L529 den
    old "Heh, whatever you say, kid."
    new "Heh, wie du meinst, Kleiner."

    # say L531 den
    old "All right Mia, it's time to do what you do best!"
    new "Na gut Mia, es ist Zeit, das zu tun, was du am besten kannst!"

    # say L542 mia
    old "(I can't believe I'm actually doing this, and to [pla] of all people!)"
    new "Ich kann es nicht glauben, dass ich das tatsächlich mache, und dann auch noch mit [pla]."

    # say L543 den
    old "I bet you actually wanted this, even if you left the porn business."
    new "Ich wette, du hast das die ganze Zeit gewollt, auch wenn du aus der Pornobranche ausgestiegen bist."

    # say L544 den
    old "After all you're just a whore."
    new "Schließlich bist du nur eine Hure."

    # say L546 mia
    old "Whatever you say, but remember, you won't get away with this for long."
    new "Was immer Sie sagen, aber merken Sie sich, Sie werden das nicht lange durchziehen können."

    # say L547 den
    old "Heh, we'll see."
    new "Heh, wir werden sehen."

    # say L557 mia
    old "Woah, what the fuck?!"
    new "Woah, was zur Hölle?!"

    # say L559 mia
    old "What are you doing? What did you take that picture for?"
    new "Was machen Sie da? Wofür haben Sie dieses Bild gemacht?"

    # say L560 den
    old "Don't worry about it, that's just to..."
    new "Mach dir keine Sorgen, das ist einfach, um..."

    # say L561 den
    old "Let's say, commemorate the occasion."
    new "Lass uns sagen, die Gelegenheit festhalten."

    # say L563 den
    old "Anyway, I think I should just leave."
    new "Na ja, ich glaube, ich sollte einfach gehen."

    # say L564 den
    old "Well done [pla], I bet you liked that."
    new "Gut gemacht [pla], ich wette, dir hat das gefallen."

    # say L566 den
    old "Until we see each other again, bye."
    new "Bis zum nächsten Mal, tschüss."

    # say L577 pla
    old "U-uh, Miss Mia, I- I think..."
    new "U-äh, Miss Mia, ich glaube..."

    # say L578 mia
    old "I don't want to talk, or anything. Bye."
    new "Ich will nicht reden, oder so. Tschüss."

    # say L586 pla
    old "Damn."
    new "Verdammt."

    # say L587 pla
    old "(What did I get myself into now?)"
    new "Was hab ich mir jetzt wieder eingebrockt?"

    # say L606 pla
    old "Eh, ehem."
    new "Eh, ähm."

    # say L611 pla
    old "Hi Miss Mia, good morning."
    new "Hallo Miss Mia, guten Morgen."

    # say L612 mia
    old "G-good morning."
    new "Guten Morgen."

    # say L613 mia
    old "I see you're early today, congratulations."
    new "Ich sehe, dass Sie heute früh dran sind, gratuliere."

    # say L614 mia
    old "The class doesn't start yet, so take a seat and wait for your classmates."
    new "Die Klasse fängt noch nicht an, also setz dich und warte auf deine Klassenkameraden."

    # say L618 pla
    old "Hmm, actually, I was kinda hoping we could talk."
    new "Hmm, eigentlich hatte ich gehofft, dass wir reden könnten."

    # say L619 pla
    old "You know, about what happened last time..."
    new "Du weißt schon, wegen dem, was letztes Mal passiert ist..."

    # say L622 mia
    old "Listen, we don't have anything to talk about."
    new "Hören Sie, wir haben nichts zu besprechen."

    # say L623 mia
    old "I'm really sorry that you saw yourself being dragged into it, and I thank you for helping me."
    new "Ich bedaure sehr, dass Sie da mit hineingezogen wurden, und danke Ihnen für Ihre Hilfe."

    # say L624 mia
    old "But that's all I will say about that issue."
    new "Aber das ist alles, was ich dazu sagen werde."

    # say L625 mia
    old "Which, by the way, it's my own business, so I would appreciate it if you didn't interfere."
    new "Das ist übrigens meine eigene Angelegenheit, und ich würde es zu schätzen wissen, wenn Sie sich nicht einmischen."

    # say L626 pla
    old "What? You can't be talking seriously."
    new "Was? Du kannst doch nicht ernsthaft darüber sprechen."

    # say L627 pla
    old "Listen, what happened yesterday wasn't ok, and you can't let him keep forcing you into that kind of stuff."
    new "Hör zu, was gestern passiert ist, war nicht in Ordnung, und du kannst nicht zulassen, dass er dich weiterhin so behandelt."

    # say L628 pla
    old "It's just not right, you have to do something..."
    new "Das ist einfach nicht richtig, du musst was tun..."

    # say L629 mia
    old "And you think I don't know that?!"
    new "Und Sie denken, ich weiß das nicht?!"

    # say L630 mia
    old "Of course it's not right! But I can't do anything, I've racked my brain to come up with a satisfying solution. But nothing."
    new "Natürlich ist das nicht richtig! Aber ich kann nichts tun, ich habe mir den Kopf zerbrochen, um eine befriedigende Lösung zu finden. Aber es fällt mir nichts ein."

    # say L631 mia
    old "Otherwise, I wouldn't be stuck following his orders! Don't treat me like an idiot!"
    new "Sonst würde ich ja nicht hier herumstehen und seinen Befehlen folgen! Machen Sie sich nicht über mich lustig!"

    # say L633 pla
    old "I know you're not dumb, but that's why I wanted to talk to you because I think maybe I could help you."
    new "Ich weiß, dass du nicht dumm bist, deshalb wollte ich mit dir reden, weil ich denke, dass ich dir vielleicht helfen könnte."

    # say L635 pla
    old "Listen, I just don't think it's right that he keeps pushing you around like that."
    new "Hör zu, ich finde es einfach nicht richtig, dass er dich ständig herumkommandiert."

    # say L636 pla
    old "I want to do something to help you."
    new "Ich will dir helfen."

    # say L637 pla
    old "I think it's the best thing that I can do. If you'll let me."
    new "Ich denke, das ist das Beste, was ich tun kann. Wenn du mich lässt."

    # say L639 mia
    old "Hmm... I guess you're right."
    new "Hmm... Ich schätze, Sie haben recht."

    # say L640 mia
    old "Listen, Denzel, is a previous student of mine, that apparently recent me from when I was his teacher."
    new "Hören Sie, Denzel war ein ehemaliger Schüler von mir, der anscheinend immer noch an der Zeit hängt, als ich sein Lehrer war."

    # say L641 mia
    old "And he's decided to get back at me by threatening to release some footage that he found from when I was..."
    new "Und er hat sich entschieden, sich an mir zu rächen, indem er droht, einige Aufnahmen freizugeben, die er von damals gefunden hat, als ich..."

    # say L642 mia
    old "From when I was..."
    new "Von damals, als ich..."

    # say L643 mia
    old "Ugh! It's even hard to talk about it!"
    new "Ugh! Es ist sogar schwer, darüber zu sprechen!"

    # say L644 mia
    old "From when I was a pornstar, ok?"
    new "Von damals, als ich Pornodarstellerin war, okay?"

    # say L646 mia
    old "That was a long time ago, I was just fresh out of high school, and didn't have any money to pay for college."
    new "Das war lange her, ich war gerade aus der Schule und hatte kein Geld fürs College."

    # say L647 mia
    old "Somebody had talked to me about how much money you could make in little time working on porn."
    new "Jemand hat mir erzählt, wie viel Geld man in kurzer Zeit mit Pornos verdienen kann."

    # say L648 mia
    old "I was young, so I didn't really think it through, and just decided to do it."
    new "Ich war jung und habe es mir nicht richtig überlegt, deshalb habe ich mich einfach dazu entschieden."

    # say L649 mia
    old "But I regret it so much, it didn't bring anything good to my life. That period gave me very low self-esteem."
    new "Aber ich bereue es so sehr, es hat nichts Gutes in mein Leben gebracht. Diese Zeit hat mir ein sehr schlechtes Selbstbild eingetrichtert."

    # say L650 mia
    old "Besides, it caused me depression and anxiety that lasted for a very long time."
    new "Außerdem hat es mir Depressionen und Angstzustände beschert, die sehr lange anhielten."

    # say L654 mia
    old "At the end I decided I couldn't take it anymore, so I just got away from it, and did everything I could to conceal that part of my past."
    new "Am Ende habe ich beschlossen, dass ich das nicht mehr aushalten konnte, also bin ich einfach davongelaufen und habe alles getan, um diesen Teil meiner Vergangenheit zu verbergen."

    # say L655 mia
    old "Finally things worked out, but I had to change my entire life, move city, change name, everything. Just to get away from it."
    new "Am Ende hat sich alles gefügt, aber ich musste mein gesamtes Leben ändern, die Stadt wechseln, den Namen ändern, alles. Nur um davon wegzukommen."

    # say L656 mia
    old "You can imagine then how hard it is for me to see that material is still out there, and somebody could see it."
    new "Sie können sich vorstellen, wie schwer es für mich ist, zu sehen, dass dieses Material immer noch da draußen ist und jemand es sehen könnte."

    # say L657 pla
    old "I mean, I get that. But what do you mean 'Still out there'?"
    new "Ich verstehe, aber was meinst du mit \"Immer noch da draußen\"?"

    # say L658 pla
    old "I imagine that whatever you filmed before would just be on the internet, right?"
    new "Ich stelle mir vor, dass alles, was du davor gefilmt hast, einfach im Internet ist, oder?"

    # say L659 pla
    old "Why is it weird that Denzel has pictures and videos of you?"
    new "Warum ist es seltsam, dass Denzel Fotos und Videos von dir hat?"

    # say L660 mia
    old "Because..."
    new "Weil..."

    # say L661 mia
    old "Even though I was working hard, I never actually left college, so when I got out of porn, I wanted to work on what I had studied."
    new "Obwohl ich hart gearbeitet habe, bin ich nie wirklich aus dem College rausgekommen, also wollte ich nachdem ich aus der Pornobranche ausgestiegen bin, mich auf das konzentrieren, was ich studiert habe."

    # say L662 mia
    old "It may be because I was so young, but I didn't think my previous job was going to be an issue."
    new "Es könnte daran liegen, dass ich so jung war, aber ich dachte nicht, dass mein früherer Job ein Problem sein würde."

    # say L663 mia
    old "Nobody wanted to hire, a lot of parents, teachers, and principals at schools had seen my work."
    new "Niemand wollte mich einstellen, viele Eltern, Lehrer und Schulleiter hatten meine Arbeit gesehen."

    # say L664 mia
    old "Ugh, they believed it was inappropriate for me to teach the children..."
    new "Ugh, sie fanden es unangemessen, dass ich Kindern Unterricht gebe..."

    # say L665 mia
    old "I suppose it wasn't to jack up to my face."
    new "Ich schätze, es war nicht gerade dazu angetan, mir ins Gesicht zu passen."

    # say L666 mia
    old "Anyway, I decided that since I wasn't working in that industry any longer I didn't want my videos and pictures out there."
    new "Jedenfalls habe ich entschieden, dass ich, da ich nicht mehr in dieser Branche arbeite, meine Videos und Fotos nicht mehr online haben will."

    # say L667 mia
    old "So, I sued my previous producer, and I managed to get everything taken down."
    new "So, ich habe meinen früheren Produzenten verklagt und es geschafft, alles entfernen zu lassen."

    # say L668 pla
    old "Wow, that's amazing."
    new "Wow, das ist unglaublich."

    # say L670 mia
    old "But it didn't really fix things where I lived, in the end, I had to move... several times."
    new "Aber es hat die Dinge an dem Ort, wo ich gelebt habe, nicht wirklich verbessert. Am Ende musste ich umziehen... mehrmals."

    # say L671 mia
    old "A lot of people in different places knew who I was. Finally, I came to this place, where nobody seems to know me."
    new "Viele Leute an verschiedenen Orten wussten, wer ich bin. Schließlich bin ich hierher gekommen, wo niemand zu wissen scheint, wer ich bin."

    # say L672 pla
    old "I understand, so you don't want people finding out about it."
    new "Ich verstehe, du willst also nicht, dass die Leute davon erfahren."

    # say L674 mia
    old "Of course not, it's taken me a lot of work to build a life for myself here."
    new "Natürlich nicht, es hat mich viel Arbeit gekostet, mir hier ein Leben aufzubauen."

    # say L676 pla
    old "I see, but how did he manage to get that material of you if it was all taken down?"
    new "Ich verstehe, aber wie ist er an das Material gekommen, wenn alles gelöscht war?"

    # say L677 mia
    old "Honestly I have no idea, I've looked for hours on end for traces of my material."
    new "Ehrlich gesagt, habe ich keine Ahnung. Ich habe stundenlang nach Spuren meines Materials gesucht."

    # say L678 mia
    old "And I haven't been able to find anything, at all. So, it's a mystery to me that he was able to put his hands on it."
    new "Und ich habe nichts gefunden, gar nichts. Also bleibt mir ein Rätsel, wie er an das Material gekommen ist."

    # say L679 mia
    old "And now he's using it to blackmail me, either I do what he demands, or he takes it to the principal and outs me in front of everybody."
    new "Und jetzt benutzt er es, um mich zu erpressen. Entweder ich tue, was er verlangt, oder er bringt es dem Rektor und macht mich vor allen bloß."

    # say L680 mia
    old "After all this work! You have no idea how hard it's been for me to rebuild my life!"
    new "Nach all der Arbeit! Sie haben keine Ahnung, wie schwer es für mich war, mein Leben wieder aufzubauen!"

    # say L682 mia
    old "How much I enjoy teaching! Instead of...!"
    new "Wie sehr ich unterrichten genieße! Stattdessen...!"

    # say L683 mia
    old "Instead of letting random actors do what they wanted to me on camera!"
    new "Statt zuzulassen, dass zufällige Schauspieler mit mir machen, was sie wollen, vor der Kamera!"

    # say L685 mia
    old "What's worse about it, is that ever since he began blackmailing me, I've given him more content to use."
    new "Was noch Schlimmeres daran ist, ist dass ich seitdem, als er mich erpresst, ihm noch mehr Material zur Verfügung gestellt habe."

    # say L686 mia
    old "Being that desperate I've been following his orders, and he has a lot of stuff of me doing inappropriate things at school."
    new "Seitdem ich so verzweifelt bin, befolge ich seine Befehle, und er hat viele Dinge von mir, die ich an der Schule angestellt habe."

    # say L687 mia
    old "Like that picture he took of us..."
    new "Wie dieses Bild, das er von uns gemacht hat..."

    # say L689 pla
    old "Listen, Ms. Mia, we'll do everything we can to stop him."
    new "Hören Sie, Ms. Mia, wir werden alles tun, was in unserer Macht steht, um ihn aufzuhalten."

    # say L691 mia
    old "Oh really? How?"
    new "Oh wirklich? Wie denn?"

    # say L692 pla
    old "Uh... I don't really know yet, but there must be a way."
    new "Äh... Ich weiß noch nicht genau, aber es muss einen Weg geben."

    # say L694 pla
    old "Maybe we can hack his computer, or follow him and steal it from him."
    new "Vielleicht können wir seinen Computer hacken oder ihm folgen und es ihm stehlen."

    # say L695 pla
    old "Or maybe there's something we can use against him, like his place of work, or something like..."
    new "Oder es gibt etwas, das wir gegen ihn verwenden können, wie seinen Arbeitsplatz oder so was..."

    # say L696 mia
    old "Ok, enough! Who do you think you're talking to? Don't you think I already thought about every way I could handle this?"
    new "Ok, genug! Mit wem glauben Sie eigentlich zu sprechen? Glauben Sie etwa, ich hätte mir das nicht schon von allen Seiten überlegt?"

    # say L697 mia
    old "All of these suggestions of yours are very nice, but they amount to nothing."
    new "All diese Vorschläge von Ihnen sind sehr schön, aber sie bringen nichts."

    # say L698 mia
    old "So, I think it's better if we no longer talk about it, I'll deal with Denzel by myself."
    new "Also, ich denke, es ist besser, wenn wir nicht mehr darüber sprechen. Ich werde mich selbst um Denzel kümmern."

    # say L699 pla
    old "What? B-but Miss Mia, I really want to help you, and..."
    new "Was? A-aber Miss Mia, ich will dir wirklich helfen und..."

    # say L700 mia
    old "That's very sweet, but there's nothing you can do for me [pla]."
    new "Das ist sehr lieb, aber da kann mir niemand helfen [pla]."

    # say L701 pla
    old "But."
    new "Aber."

    # say L702 mia
    old "Class Is about to start, your classmates will arrive soon and I don't want them catch us talking about this. So drop it!"
    new "Die Stunde fängt gleich an, Ihre Klassenkameraden werden bald hier sein und ich will nicht, dass sie uns dabei erwischen, wie wir darüber reden. Lassen Sie es also!"

    # say L722 pla
    old "Fine."
    new "In Ordnung."

    # say L734 mia
    old "Ok, from today on we'll talk about Latin American political history in the twentieth century."
    new "Ok, ab heute werden wir uns mit der politischen Geschichte Lateinamerikas im 20. Jahrhundert befassen."

    # say L735 mia
    old "And we'll start with the Cuban coup d'etat..."
    new "Und wir beginnen mit dem Kubanischen Staatsstreich..."

    # say L741 mia
    old "Ok, that's all for today, I hope you took proper notes of the class."
    new "Ok, das war's für heute, ich hoffe, Sie haben sich die wichtigsten Punkte notiert."

    # say L742 mia
    old "Remember to practice the subject at home, the test is very close, so don't relax too much and forget to study."
    new "Denken Sie daran, das Thema zu Hause zu üben, die Klausur steht kurz bevor, also lassen Sie sich nicht zu sehr ablenken und vergessen Sie nicht zu lernen."

    # say L743 mia
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term tests."
    new "Ich weiß, das klingt nach viel Arbeit, aber Sie müssen das tun, wenn Sie alle Fächer bis zu den Abschlussprüfungen richtig lernen wollen."

    # say L745 mik
    old "See you at the next class guys."
    new "Bis zur nächsten Stunde, Leute."

    # say L769 pla
    old "Oh! It's you."
    new "Oh! Das bist du."

    # say L772 den
    old "I came to see you, we need to talk."
    new "Ich bin gekommen, um mit dir zu reden, wir müssen uns unterhalten."

    # say L773 pla
    old "Do we?"
    new "Müssen wir?"

    # say L774 pla
    old "About what?"
    new "Worüber?"

    # say L775 den
    old "About Mia, of course, I want you to work with me."
    new "Natürlich über Mia, ich will, dass du mit mir zusammenarbeitest."

    # say L776 pla
    old "You what?"
    new "Was willst du?"

    # say L777 den
    old "Yeah dude, listen, she has no way to get out of this."
    new "Klar, Mann, hör zu, sie hat keine Chance, sich rauszureden."

    # say L778 den
    old "I have all the information, and the videos and pictures. We can both use it to get revenge on her."
    new "Ich hab alle Infos und die Videos und Fotos. Wir können beide damit Rache an ihr nehmen."

    # say L779 pla
    old "Come on, revenge? Really?"
    new "Komm schon, Rache? Im Ernst?"

    # say L781 den
    old "Listen, I know she's been terrible to you, right?"
    new "Hör zu, ich weiß, dass sie dir das Leben schwer gemacht hat, oder?"

    # say L782 den
    old "If we both work together, we can make that little bitch pay for everything she's done to us."
    new "Wenn wir beide zusammenarbeiten, können wir dieser kleinen Schlampe zeigen, was sie uns alles angetan hat."

    # say L783 den
    old "Besides, imagine all the things you can get her to do to you, just by telling her you'll release the pictures."
    new "Außerdem, stell dir vor, was sie alles für dich tun wird, wenn du ihr sagst, dass du die Fotos freigibst."

    # say L784 den
    old "We'll make sure that she pays like the little slut she is."
    new "Wir werden sicherstellen, dass sie bezahlt wie das kleine Flittchen, das sie ist."

    # say L785 den
    old "What do you say, huh?"
    new "Was sagst du dazu, hm?"

    # say L786 pla
    old "What's wrong with you dude?! Revenge?! Make her pay? Slut?"
    new "Was ist los mit dir, Alter?! Rache?! Sie bezahlen lassen? Schlampe?"

    # say L787 pla
    old "Are you really that twisted? The fuck?! This is a person's life you're talking about!"
    new "Bist du wirklich so verdreht? Was zur Hölle?! Du redest hier von einem Menschenleben!"

    # say L789 pla
    old "You would destroy her life just because she was a little mean to you?"
    new "Du würdest ihr Leben zerstören, nur weil sie ein bisschen gemein zu dir war?"

    # say L790 pla
    old "There's something seriously wrong with you dude..."
    new "Da stimmt was ernsthaft nicht mit dir, Alter..."

    # say L791 den
    old "Oh, so that's how it is, I thought you would understand, but it turns out you're just one of those moralist idiots."
    new "Oh, so ist das, ich dachte, du würdest verstehen, aber du bist einfach einer dieser moralischen Idioten."

    # say L792 pla
    old "I'm an molarist idiot? You're the one who thinks he can destroy someone's life and get away with it."
    new "Ich bin ein Moralistenidiot? Du bist derjenige, der glaubt, er kann jemandes Leben zerstören und damit durchkommen."

    # say L793 den
    old "Don't give me that bullshit! Listen pal, Mia's just a simple whore who enjoys making others suffer."
    new "Gib mir das nicht! Hör zu, Kumpel, Mia ist einfach nur eine billige Nutte, die es genießt, anderen das Leben schwer zu machen."

    # say L794 den
    old "What's wrong with making her pay for all of the bad shit she does?"
    new "Was ist daran falsch, sie für all das Schlechte bezahlen zu lassen, was sie anderen antut?"

    # say L795 den
    old "After all, it's just giving her a taste of her own medicine."
    new "Schließlich ist es doch nur, dass sie einen Vorgeschmack auf ihre eigene Medizin bekommt."

    # say L796 pla
    old "What's wrong with you? I won't do anything like that, you asshole."
    new "Was ist los mit dir? Ich werde so was nicht machen, du Arschloch."

    # say L797 pla
    old "It's true that Mia has a bad temper and a strong character, but not enough for you to justify destroying her life."
    new "Es stimmt, dass Mia ein schlechtes Temperament und einen starken Charakter hat, aber das reicht nicht, um ihr Leben zu zerstören zu rechtfertigen."

    # say L798 pla
    old "You're just hung up on some shit that happened a long time ago and you haven't been able to let it go."
    new "Du hängst einfach an irgendwelchem Scheiß fest, der schon lange passiert ist, und kannst ihn nicht loslassen."

    # say L800 den
    old "You're even more fucking stupid than I thought!"
    new "Du bist noch dümmer, als ich dachte!"

    # say L801 den
    old "But it's ok dude, you'll understand, after all, I can still punish Mia by myself."
    new "Aber es ist okay, Kumpel, du wirst es verstehen, schließlich kann ich Mia auch alleine bestrafen."

    # say L803 pla
    old "Whatever you say dude, I don't want anything to do with you or your sick plans."
    new "Wie du meinst, Kumpel, ich will nichts mit dir oder deinen kranken Plänen zu tun haben."

    # say L804 den
    old "Yeah well, remember this, I'll take my revenge on Mia, and one way or another you'll have to do with it."
    new "Ja, und merk dir das, ich werde mich an Mia rächen, und auf irgendeine Weise wirst du damit leben müssen."

    # say L815 pla
    old "Wow, what is wrong with that guy?"
    new "Wow, was ist bloß mit dem los?"

    # say L823 pla
    old "Oh, hey Belle, morning."
    new "Oh, hey Belle, Morgen."

    # say L824 bel
    old "Hey, who was that guy that was talking with you at the entrance? He looked like he was angry, were you arguing?"
    new "Hey, wer war der Typ, der am Eingang mit dir geredet hat? Er sah aus, als wäre er sauer, habt ihr gestritten?"

    # say L825 pla
    old "Oh, him? He's just some guy I know, don't worry about it."
    new "Oh, der? Das ist nur ein Typ, den ich kenne, mach dir keine Sorgen."

    # say L827 bel
    old "Hmm, I thought that maybe he has something to do with Ms. Mia."
    new "Hmm, ich dachte, der hat vielleicht was mit Ms. Mia zu tun."

    # say L828 pla
    old "W-why do you think that?"
    new "W-warum denkst du das?"

    # say L829 pla
    old "Did you hear anything?"
    new "Hast du was gehört?"

    # say L831 bel
    old "Well, it's just that lately, I've seen you talking with Ms. Mia, so I figured that maybe he had something to do with it."
    new "Na ja, es ist einfach so, dass ich dich lately oft mit Ms. Mia reden gesehen habe, also dachte ich, er hat vielleicht damit zu tun."

    # say L833 pla
    old "Uhhh, no, no, he has nothing to do with it."
    new "Uhhh, nein, nein, er hat damit nichts zu tun."

    # say L834 pla
    old "I've just been talking to Ms. Mia about my grades, you know she's always harping on me."
    new "Ich hab nur mit Ms. Mia über meine Noten geredet, du weißt ja, sie nervt mich immer damit."

    # say L836 bel
    old "Oh, I see, I guess you do need to pay attention to your grades."
    new "Oh, ich verstehe, Sie müssen sich wohl um Ihre Noten kümmern."

    # say L846 mia
    old "Hey, it's time for classes, so come in!"
    new "Hey, es ist Zeit für die Unterrichtsstunden, also kommt rein!"

    # say L851 mia
    old "Ok guys, it's time to start preparing for the midterm test, so today we'll do a couple of mock tests to help you get ready for it."
    new "Okay Leute, es ist Zeit, sich auf die Halbzeitklausur vorzubereiten. Deshalb machen wir heute ein paar Übungstests, um euch auf den großen Tag vorzubereiten."

    # say L856 mia
    old "So, I hope you found the excersises useful, remember to practice again at home, the test is very close, so don't relax too much and forget to study."
    new "Also, ich hoffe, die Übungen waren hilfreich. Übt noch mal zu Hause, die Klausur steht kurz bevor, also lasst es nicht zu, dass ihr faul werdet und das Lernen vernachlässigt."

    # say L892 mia
    old "[pla], wait a minute, I'll need you stay, we need to talk about your grades."
    new "[pla], warten Sie einen Moment, Sie müssen noch bleiben, wir müssen über Ihre Noten sprechen."

    # say L907 mia
    old "What the fuck did you do?!! You idiot! I told you to stay out of it!"
    new "Was zum Teufel haben Sie gemacht?! Sie Idiot! Ich hab Ihnen gesagt, Sie sollen sich raushalten!"

    # say L909 mia
    old "Denzel called me and was very fucking angry! He said you were gonna pay him for saying what you said!"
    new "Denzel hat mich angerufen und war total wütend! Er sagte, du würdest ihm dafür bezahlen, was du gesagt hast!"

    # say L910 mia
    old "What did you do?!"
    new "Was haben Sie getan?!"

    # say L911 pla
    old "Nothing, nothing! I swear to God! He's the one that came to talk to me this morning, when I was arriving at school!"
    new "Nichts, nichts! Ich schwöre bei Gott! Er war derjenige, der heute Morgen mit mir geredet hat, als ich zur Schule kam!"

    # say L912 pla
    old "He wanted me to allie with him and help him mess with you."
    new "Er wollte, dass ich mich mit ihm verbünde und dir eins auswische."

    # say L913 pla
    old "But I told him no, that I wasn't gonna be part of it."
    new "Aber ich hab ihm gesagt, dass ich nicht mitmache."

    # say L914 mia
    old "Oh FUCK! Why did you have to get involved with this!"
    new "Oh verdammt! Warum mussten Sie sich da einmischen!"

    # say L915 mia
    old "This has nothing to do with you!"
    new "Das hat überhaupt nichts mit Ihnen zu tun!"

    # say L916 mia
    old "Because of what you told him he's now fucking angry!"
    new "Wegen dem, was Sie ihm erzählt haben, ist er jetzt richtig sauer!"

    # say L917 mia
    old "Listen to me [pla], stay out of this, okay?! This has absolutely nothing to do with you!"
    new "Hören Sie mir zu [pla], bleiben Sie da raus, okay?! Das hat absolut nichts mit Ihnen zu tun!"

    # say L918 mia
    old "Don't talk to that guy, don't make contact. Nothing!"
    new "Mit dem Typen nicht reden, keinen Kontakt. Gar nichts!"

    # say L919 mia
    old "Do you get it?!"
    new "Verstehen Sie?!"

    # say L920 pla
    old "Whatever you say, but that guy is the one that came to me, and you know he's insane."
    new "Wie du meinst, aber der Typ war derjenige, der zu mir gekommen ist, und du weißt, dass er durchgeknallt ist."

    # say L936 den
    old "I came to visit, I had to see my favorite teacher."
    new "Ich bin gekommen, um meine Lieblingslehrerin zu sehen."

    # say L938 den
    old "And look at that! My good friend [pla] is here as well!"
    new "Und sieh an! Mein guter Freund [pla] ist auch hier!"

    # say L939 den
    old "Good, good, just what I was expecting."
    new "Gut, gut, genau das, was ich erwartet habe."

    # say L942 pla
    old "Dude, don't you have anything else to do besides stalking Ms. Mia all day?"
    new "Kumpel, hast du nichts Besseres zu tun, als den ganzen Tag Ms. Mia zu stalken?"

    # say L943 den
    old "Heh, you shouldn't worry that much about what I do to fill my time."
    new "Heh, du solltest dich nicht so sehr um das kümmern, was ich so treibe."

    # say L944 den
    old "It's more interesting what you're about to do!"
    new "Es ist viel interessanter, was du gleich tun wirst!"

    # say L945 den
    old "After all, I think it's about time that you two start."
    new "Schließlich denke ich, es ist höchste Zeit, dass ihr beiden anfangt."

    # say L947 den
    old "'Ms.' Mia, you haven't told him about the new challenge?"
    new "Ms. Mia, du hast ihm noch nichts von der neuen Herausforderung erzählt?"

    # say L949 mia
    old "Don't even think about Denzel."
    new "Denken Sie nicht einmal daran, Denzel."

    # say L950 mia
    old "It's not happening! No way in hell!"
    new "Das kommt nicht infrage! Auf keinen Fall!"

    # say L951 den
    old "Well, that surprises me, I guess that you don't mind then about the school principal receiving an interesting mail, do you?"
    new "Na, das überrascht mich, ich dachte, es wäre dir egal, wenn der Schulleiter eine interessante E-Mail erhält, oder?"

    # say L953 pla
    old "Wait, what's happening? What did you ask this time."
    new "Warte, was passiert hier? Was hast du diesmal gefragt."

    # say L955 den
    old "Tell him, Mia."
    new "Sagen Sie es ihm, Mia."

    # say L956 mia
    old "{i}*Sigh*{/i} The thing is, this sick bastard wants us to have sex."
    new "{i}*Seufz*{/i} Die Sache ist die, dieser kranke Bastard will, dass wir miteinander schlafen."

    # say L957 pla
    old "What?! What the fuck?!"
    new "Was?! Was zum Teufel?!"

    # say L958 pla
    old "There's something seriously wrong with you pal! That's way too far! I'm going to the police!"
    new "Da stimmt was ernsthaft nicht mit Ihnen, Kumpel! Das geht echt zu weit! Ich gehe zur Polizei!"

    # say L959 den
    old "HA! Do it! Fine by me!"
    new "HA! Mach es! Mir egal!"

    # say L960 den
    old "I mean, sure, maybe I'll get trial for blackmail, nothing severe 'cause you don't have any evidence..."
    new "Ich meine, klar, vielleicht krieg ich eine Verhandlung wegen Erpressung, aber nichts Schlimmes, weil du keine Beweise hast..."

    # say L962 den
    old "But what's gonna happen when they review the photos and videos I got from you, what do you think will happen then, eh [pla]?"
    new "Aber was passiert, wenn sie die Fotos und Videos durchsehen, die ich von dir habe, was denkst du, wird dann passieren, hm [pla]?"

    # say L963 den
    old "All of that is gonna come out to the public, and everyone will know Mia used to be a pornstar."
    new "Das alles wird an die Öffentlichkeit kommen, und jeder wird wissen, dass Mia früher Pornodarstellerin war."

    # say L964 den
    old "But that's not the worst part."
    new "Aber das ist noch nicht das Schlimmste."

    # say L965 den
    old "What will really make people angry is the fact that she's fucking her students."
    new "Was die Leute wirklich wütend machen wird, ist die Tatsache, dass sie ihre Schüler fickt."

    # say L966 den
    old "Imagine what will happen then, hahaha."
    new "Stell dir vor, was dann passiert, hahaha."

    # say L967 pla
    old "W-what?! Fucking her student? The hell are you talking about?"
    new "W-was?! Einen Schüler vögeln? Von was redest du da?"

    # say L968 den
    old "I suppose you remember that picture I took of you the other day."
    new "Ich schätze, du erinnerst dich an das Bild, das ich von dir gemacht habe."

    # say L969 den
    old "Come on, everybody will believe that you two have been fucking anyway."
    new "Komm schon, jeder wird sowieso denken, dass ihr miteinander gevögelt habt."

    # say L970 den
    old "I'll just make it a reality."
    new "Ich werde es einfach zur Wirklichkeit machen."

    # say L971 pla
    old "You're sick dude!"
    new "Du bist krank, Mann!"

    # say L972 mia
    old "Wait [pla], stop... just stop."
    new "Warten [pla], aufhören... einfach aufhören."

    # say L973 mia
    old "{i}*Sigh*{/i} All right Denzel, you win... We'll do it."
    new "{i}*Seufz*{/i} Gut, Denzel, du hast gewonnen... Wir machen es."

    # say L974 pla
    old "You can't be serious!"
    new "Du kannst nicht ernsthaft sein!"

    # say L975 pla
    old "You can't let this guy get away with something like that! We have to go to the police!"
    new "Du kannst doch nicht zulassen, dass dieser Typ so etwas durchzieht! Wir müssen zur Polizei gehen!"

    # say L976 mia
    old "And then what?! You heard him! If we go to the police my life will be ruined!"
    new "Und dann?! Sie haben ihn gehört! Wenn wir zur Polizei gehen, wird mein Leben ruiniert sein!"

    # say L977 mia
    old "Besides, with the other photos that he has, he could also drag you down with me!"
    new "Außerdem könnte er mit den anderen Fotos auch dich mit reinziehen!"

    # say L978 pla
    old "Hmph!"
    new "Hmpf!"

    # say L980 mia
    old "Look, I don't want this, but I really need your help. Please [pla]."
    new "Schauen Sie, ich will das nicht, aber ich brauche wirklich Ihre Hilfe. Bitte [pla]."

    # say L981 pla
    old "{i}*Sigh*{/i} Ok, I guess we have to."
    new "{i}*Seufz*{/i} Okay, ich schätze, wir müssen."

    # say L983 mia
    old "Ok, Denzel, we'll do it."
    new "Ok, Denzel, wir werden es tun."

    # say L984 den
    old "Fantastic! I knew you guys would come around!"
    new "Fantastisch! Ich wusste, dass ihr euch entscheiden würdet!"

    # say L985 den
    old "Ok, let's get to it!"
    new "Ok, dann mal los!"

    # say L986 mia
    old "What? Here? Now?"
    new "Was? Hier? Jetzt?"

    # say L987 den
    old "What would be better?"
    new "Was wäre besser?"

    # say L988 den
    old "It's ok, I don't think the janitor will come anytime soon. So nobody will notice us."
    new "Es ist okay, ich denke nicht, dass der Hausmeister bald kommt. Also wird niemand uns bemerken."

    # say L989 pla
    old "Wait, 'us'? Does that mean you're gonna be here while we do it?"
    new "Warte, 'uns'? Das bedeutet, du bleibst hier, während wir es tun?"

    # say L991 den
    old "Of course I'm serious! What else am I going to do?"
    new "Natürlich bin ich ernst! Was soll ich denn sonst machen?"

    # say L992 den
    old "Besides, you can't be angry about it Mia, you're used to fucking in front of other people, right? This should be easy for you."
    new "Außerdem kannst du dich nicht darüber aufregen, Mia. Du bist es ja gewohnt, vor anderen Leuten zu ficken. Das sollte für dich ein Kinderspiel sein."

    # say L993 den
    old "Just close your eyes and imagine it's the good old days. You whore."
    new "Schließ einfach die Augen und stell dir vor, es sind die guten alten Zeiten. Du Schlampe."

    # say L994 den
    old "Oh, by the way, remember to take your tits out. You've been keeping them hidden, and I think it's time for you to let them out."
    new "Oh, übrigens, vergiss nicht, deine Titten rauszunehmen. Du hast sie die ganze Zeit versteckt, und ich denke, es ist Zeit, dass du sie endlich zeigst."

    # say L995 mia
    old "You're fucking pathetic."
    new "Sie sind echt erbärmlich."

    # say L996 den
    old "Hehehe, sure, sure."
    new "Hehehe, klar, klar."

    # say L1005 den
    old "I bet you're happy getting drilled by that cock."
    new "Ich wette, du bist glücklich, von diesem Schwanz gefickt zu werden."

    # say L1006 mia
    old "Ugh, whatever dude."
    new "Ugh, was auch immer, Mann."

    # say L1007 mia
    old "We're only doing this because you're forcing us, you ass."
    new "Wir machen das nur, weil du uns dazu zwingst, du Arsch."

    # say L1008 den
    old "You know, you're making me sound like the bad guy, but I'm sure you're enjoying this."
    new "Du machst mich hier ja zum Bösewicht, aber ich bin mir sicher, dass dir das gefällt."

    # say L1009 den
    old "You may fool yourself and others with this whole 'teacher' thing, but I know that you're really a whore."
    new "Du kannst dich und andere vielleicht mit dieser ganzen „Lehrerin“-Nummer täuschen, aber ich weiß, dass du in Wirklichkeit eine Hure bist."

    # say L1010 mia
    old "You're sick."
    new "Sie sind krank."

    # say L1011 den
    old "Hahaha, you keep fucking like the bitch you are."
    new "Hahaha, Sie ficken weiter wie das Flittchen, das Sie sind."

    # say L1023 mia
    old "Oh come on!"
    new "Oh komm schon!"

    # say L1025 pla
    old "Come on dude!"
    new "Komm schon, Alter!"

    # say L1026 den
    old "Oh, I'm sorry, I interrupted you guys when you were having such a sweet time together."
    new "Oh, ich bin wirklich sorry, ich habe euch unterbrochen, als ihr gerade so einen süßen Moment zusammen hattet."

    # say L1028 den
    old "I'm so rude."
    new "Ich bin so unhöflich."

    # say L1029 den
    old "But you see, now I have actual evidence that you guys fucked!"
    new "Aber seht her, jetzt habe ich tatsächlich Beweise, dass ihr gevögelt habt!"

    # say L1030 den
    old "I guess that means that I now have two bitches instead of just one. Am I right?"
    new "Dann bedeutet das wohl, dass ich jetzt zwei Schlampe habe anstatt nur einer. Hab ich recht?"

    # say L1032 den
    old "I told you you were going to be a part of this [pla]."
    new "Ich hab dir doch gesagt, dass du Teil davon wirst [pla]."

    # say L1033 mia
    old "You're really twisted."
    new "Sie sind wirklich verdreht."

    # say L1034 den
    old "I think I should get going, but don't worry guys, I'll be seeing you soon."
    new "Ich glaube, ich sollte jetzt gehen, aber macht euch keine Sorgen, Jungs, wir sehen uns bald."

    # say L1039 pla
    old "There's something seriously wrong with that guy's head."
    new "Mit dem Kerl stimmt was ernsthaft nicht."

    # say L1041 mia
    old "{i}*Sigh*{/i} Whatever. For now, let's just get dressed."
    new "{i}*Seufz*{/i} Egal. Lassen Sie uns jetzt erst einmal anziehen."

    # say L1047 pla
    old "Listen, Ms. Mia, I know that what just happened's disheartening, but I'm sure there must be something we can do."
    new "Hör zu, Mia, ich weiß, dass das gerade sehr entmutigend ist, aber ich bin sicher, dass es etwas gibt, was wir tun können."

    # say L1048 pla
    old "We can't just give in to what that maniac wants."
    new "Wir können nicht einfach nachgeben, was dieser Verrückte will."

    # say L1049 mia
    old "No, there isn't anything, he's already got us."
    new "Nein, da ist nichts, er hat uns schon."

    # say L1050 mia
    old "It's just as he says, we're his bitches."
    new "Es ist genau so, wie er sagt, wir sind seine Huren."

    # say L1051 mia
    old "Let's just leave it at that."
    new "Lass uns das einfach so lassen."

    # say L1056 pla
    old "Damn it, there has to be something I can do, I'm sure of it."
    new "Verdammt, da muss doch was sein, was ich tun kann, da bin ich mir sicher."

    # say L1077 mia
    old "Oh, thanks God, I found you! Please come here for a minute."
    new "Oh, danke Gott, ich habe Sie gefunden! Bitte kommen Sie einen Moment her."

    # say L1084 mia
    old "Listen, I have to tell you something."
    new "Hören Sie, ich muss Ihnen etwas sagen."

    # say L1085 mia
    old "Denzel called me, he gave us another 'challenge'."
    new "Denzel hat mich angerufen, er hat uns eine neue 'Herausforderung' gegeben."

    # say L1086 pla
    old "What? Are you for real?"
    new "Was? Ernsthaft?"

    # say L1087 pla
    old "What does he want now?"
    new "Was will er jetzt wieder?"

    # say L1088 mia
    old "Well, every time he's given me a new 'challenge' to do, they have been getting riskier and riskier."
    new "Nun, jedes Mal, wenn er mir eine neue „Herausforderung“ gegeben hat, wurden sie immer riskanter."

    # say L1089 mia
    old "This time is the same, he wants us to... Have sex in the school bathroom."
    new "Dieses Mal ist es das Gleiche, er will, dass wir... im Schulbadezimmer miteinander schlafen."

    # say L1091 pla
    old "Woah! Really? But that's way too risky!"
    new "Woah! Echt jetzt? Aber das ist viel zu riskant!"

    # say L1092 pla
    old "I mean, last time everyone had already gone home. What will happen if someone sees us?"
    new "Ich meine, letztes Mal waren alle schon nach Hause gegangen. Was passiert, wenn uns jemand sieht?"

    # say L1093 mia
    old "I already thought of that, that's why I'm telling you now because everyone else is in their classrooms."
    new "Ich habe daran schon gedacht, deshalb sage ich es dir jetzt, weil alle anderen in ihren Klassenzimmern sind."

    # say L1094 mia
    old "If we do it now nobody should see us."
    new "Wenn wir es jetzt machen, sollte uns niemand sehen."

    # say L1096 pla
    old "So we should go have sex in the bathroom now?"
    new "Dann sollten wir jetzt ins Badezimmer gehen, um es zu tun?"

    # say L1097 mia
    old "That's right, he said I have to do a video call... for him to see us."
    new "Das stimmt, er sagte, ich soll ein Videoanruf machen... damit er uns sehen kann."

    # say L1098 pla
    old "Jesus! What the hell is wrong with that freak?!"
    new "Jesus! Was ist bloß mit diesem Freak los?!"

    # say L1099 pla
    old "No way we're doing that."
    new "Keine Chance, dass wir das machen."

    # say L1100 mia
    old "Not this again..."
    new "Nicht schon wieder..."

    # say L1101 mia
    old "[pla], this is really difficult for me, you know? You know all the stuff he has of us."
    new "[pla], das ist wirklich schwierig für mich, wissen Sie? Sie wissen doch, was er alles von uns hat."

    # say L1102 mia
    old "Please don't make me beg you again, I really need you to help me."
    new "Bitte zwingen Sie mich nicht, Sie noch einmal anzuflehen, ich brauche wirklich Ihre Hilfe."

    # say L1103 pla
    old "Hmm, yeah, you're right."
    new "Hmm, ja, du hast recht."

    # say L1104 pla
    old "{i}*Sigh*{/i} Ok, let's go then."
    new "{i}*Seufz*{/i} Okay, dann lass uns gehen."

    # say L1111 pla
    old "I know I keep putting too many hurdles, but are you sure about this?"
    new "Ich weiß, ich stelle immer zu viele Hürden, aber bist du dir sicher?"

    # say L1112 mia
    old "As I already told you, we don't have any other choice."
    new "Wie ich Ihnen schon sagte, haben wir keine andere Wahl."

    # say L1113 pla
    old "Hmph, yeah, yeah, you're right."
    new "Hmpf, ja, ja, du hast recht."

    # say L1115 mia
    old "Ok, let's call this asshole."
    new "Okay, dann rufen wir diesen Arschloch an."

    # narrator L1116 
    old "... Ringing ..."
    new "... Klingeln..."

    # say L1117 den
    old "Hello! Wow, you guys are early!"
    new "Hallo! Wow, ihr seid ja früh dran!"

    # say L1118 den
    old "This is the perfect location, isn't it Mia?"
    new "Das ist der perfekte Ort, oder Mia?"

    # say L1119 den
    old "A dirty little place for a dirty little whore. Hahaha."
    new "Ein schmutziges kleines Loch für eine schmutzige kleine Hure. Hahaha."

    # say L1121 den
    old "What about you [pla]? Aren't you happy you get to fuck your dear teacher again?"
    new "Was ist mit dir [pla]? Bist du nicht froh, dass du deinen lieben Lehrer wieder ficken darfst?"

    # say L1122 pla
    old "Fuck you dude! Don't think you can keep getting away with this for too long."
    new "Fick dich, Mann! Denk nicht, dass du damit noch lange durchkommen wirst."

    # say L1123 den
    old "Hahaha, whatever, let's just get started with this."
    new "Hahaha, egal, lass uns einfach anfangen."

    # say L1124 den
    old "Oh! And remember to take your tits out Mia, I'm recording this, so I want it to be good quality."
    new "Oh! Und vergiss nicht, deine Titten rauszunehmen Mia, ich filme das, da will ich eine gute Qualität."

    # say L1134 den
    old "Oh yeah, just like that, nice."
    new "Oh ja, genau so, schön."

    # say L1141 bel
    old "My gosh, I hate P.E. so much! I'm so sweaty!"
    new "Mein Gott, ich hasse Sport so sehr! Ich bin total verschwitzt!"

    # say L1143 mia
    old "{i}Stop, stop! Oh shit! Someone is coming!{/i}"
    new "{i}Aufhören, aufhören! Oh Scheiße! Da kommt jemand!{/i}"

    # say L1145 bil
    old "Ugh, I know, like, look at my makeup!"
    new "Ugh, ich weiß, guck dir mein Make-up an!"

    # say L1146 bil
    old "Now I'm gonna have to re-do it all over again!"
    new "Jetzt muss ich das Ganze noch mal machen!"

    # say L1147 bel
    old "Hey, by the way, had you noticed how Mia is acting lately?"
    new "Hey, übrigens, hast du bemerkt, wie sich Mia neuerdings benimmt?"

    # say L1148 bil
    old "Oh my god yeah! She's acting like a whore, flashing off in front of the whole classroom!"
    new "Oh mein Gott ja! Sie benimmt sich wie eine Schlampe und zeigt allen im Klassenzimmer ihre Titten!"

    # say L1152 bil
    old "What was that?"
    new "Was war das?"

    # say L1153 bel
    old "Like... a voice?"
    new "Wie... eine Stimme?"

    # say L1159 bel
    old "Hmm, it's nothing, maybe somebody spoke in the hall."
    new "Hmm, es ist nichts, vielleicht hat jemand im Flur gesprochen."

    # say L1160 bil
    old "Yeah, you're right."
    new "Stimmt, du hast recht."

    # say L1161 bel
    old "Ok, I'm ready."
    new "Ok, ich bin bereit."

    # say L1162 bil
    old "Yeah, me too, let's go. Anyway, as I was telling you, what the fuck is wrong with Mia?"
    new "Ja, ich auch, lass uns gehen. Egal, wie ich dir gerade erzählen wollte, was zur Hölle ist mit Mia los?"

    # say L1167 pla
    old "Ok, ok, they are gone."
    new "Ok, ok, sie sind weg."

    # say L1168 den
    old "Ha! What's the matter Mia? Afraid of getting caught?"
    new "Ha! Was ist los, Mia? Angst davor, erwischt zu werden?"

    # say L1169 den
    old "But I know you like people seeing your pussy! What's the big deal?"
    new "Aber ich weiß, dass dir gefällt, wenn die Leute deinen Schoß sehen! Was ist denn das Problem?"

    # say L1173 mia
    old "Ugh, let's just get this over with [pla]."
    new "Ugh, lass uns das einfach hinter uns bringen [pla]."

    # say L1182 pla
    old "Fuck, this is getting more and more risky!"
    new "Verdammt, das wird immer riskanter!"

    # say L1183 pla
    old "At the end it won't matter if he tells on us or not!"
    new "Am Ende spielt es keine Rolle, ob er uns verpfeift oder nicht!"

    # say L1184 pla
    old "People will end up catching us anyway!"
    new "Egal ob er uns verpfeift oder nicht, wir werden sowieso auffliegen!"

    # say L1186 pla
    old "We have to do something."
    new "Wir müssen was unternehmen."

    # say L1188 mia
    old "I'm also not happy with this. And It's already started to affect me, I can't even sleep well."
    new "Ich bin auch damit nicht glücklich. Und es hat schon angefangen, mich zu belasten, ich kann nicht einmal mehr gut schlafen."

    # say L1189 mia
    old "I'm starting to get severe anxiety again, and the nightmares have come back. But what can I do?"
    new "Ich bekomme wieder starke Angstzustände, und die Albträume sind zurück. Aber was kann ich tun?"

    # say L1190 mia
    old "We can't just go to the police! I don't want to lose my life! And now he has stuff that's even worse!"
    new "Wir können nicht einfach zur Polizei gehen! Ich will mein Leben nicht verlieren! Und jetzt hat er noch schlimmere Dinge!"

    # say L1191 pla
    old "I know this is hard, but there must be a solution."
    new "Ich weiß, dass es schwer ist, aber es muss eine Lösung geben."

    # say L1192 mia
    old "Well, if there is one I don't know what it may be."
    new "Nun, wenn es eine Lösung gibt, weiß ich nicht, was es sein könnte."

    # say L1193 mia
    old "Let's just let's get out of here before someone comes again."
    new "Lass uns einfach hier verschwinden, bevor wieder jemand kommt."

    # say L1198 pla
    old "(She's feeling really bad, I'm sorry for her.)"
    new "Sie fühlt sich echt schlecht, das tut mir leid für sie."

    # say L1199 pla
    old "I bet there's something else I could do..."
    new "Ich wette, da gibt es noch was anderes, was ich tun könnte..."

    # say L1200 pla
    old "Hmmm... But I do have the SexNote..."
    new "Hmmm... Aber ich habe ja die SexNote..."

    # say L1219 pla
    old "Hey Linett. How are you?"
    new "Hey Linett. Wie geht's dir?"

    # say L1220 lin
    old "Oh, [pla] I'm fine, thanks for asking, what about you?"
    new "Oh, [pla] ich bin gut, danke fürs Nachfragen, und du?"

    # say L1221 pla
    old "Hmm, a little bit worried actually, I have a small problem that I would like you to help me with."
    new "Hmm, ein bisschen besorgt eigentlich, ich habe ein kleines Problem, bei dem ich deine Hilfe brauche."

    # say L1222 lin
    old "Oh, interesting."
    new "Oh, interessant."

    # say L1224 pla
    old "Well, I know a person that's being blackmailed."
    new "Na ja, ich kenne jemanden, der erpresst wird."

    # say L1226 lin
    old "Blackmailed? What is that?"
    new "Erpresst? Was bedeutet das?"

    # say L1227 lin
    old "I've never heard of it, is it some type of tradition between humans?"
    new "Ich hab noch nie davon gehört, ist das so eine Tradition zwischen Menschen?"

    # say L1229 pla
    old "Uhh, somebody being blackmailed means that somebody else is threatening them with something that they care about."
    new "Uhh, jemand wird erpresst, wenn jemand anderes ihn mit etwas bedroht, das ihm wichtig ist."

    # say L1230 pla
    old "That can be anything, something that belongs to them, or something they want."
    new "Das kann alles Mögliche sein, etwas, das ihnen gehört, oder etwas, das sie wollen."

    # say L1231 pla
    old "And if you don't do what that person wants, they'll punish you with what they have against you."
    new "Und wenn du nicht tust, was die Person will, dann bestrafen sie dich mit dem, was sie gegen dich in der Hand haben."

    # say L1232 lin
    old "Wow, that sounds horrible! You humans really are something else!"
    new "Wow, das klingt schrecklich! Ihr Menschen seid echt was Besonderes!"

    # say L1233 lin
    old "The type of things you do to each other is always surprising."
    new "Die Art von Dingen, die ihr euch antut, ist immer überraschend."

    # say L1234 pla
    old "Yeah, well, this person I know is going through that. So, I'm trying to help her."
    new "Ja, klar, eine Person, die ich kenne, erlebt das gerade. Deshalb versuch ich, ihr zu helfen."

    # say L1235 lin
    old "That's very good, you should do that."
    new "Das ist sehr gut, das solltest du tun."

    # say L1239 lin
    old "Well, I'm glad I was able to help you [pla]."
    new "Na, ich freue mich, dass ich dir helfen konnte [pla]."

    # say L1242 pla
    old "That wasn't the point."
    new "Das war nicht der Punkt."

    # say L1243 lin
    old "Oh, ok, so what is it?"
    new "Oh, okay, und was ist es dann?"

    # say L1245 pla
    old "Uhhh, I'll tell you the story, this person we're talking about is my teacher."
    new "Uhhh, ich erzähl dir die Geschichte, die Person, von der wir sprechen, ist meine Lehrerin."

    # say L1246 pla
    old "The thing is that some guy found some 'information' about her that she doesn't want anyone to see."
    new "Die Sache ist, dass jemand Infos über sie gefunden hat, die sie auf keinen Fall rausgehen lassen will."

    # say L1247 pla
    old "But there's no way of stopping him from putting it out there. At least not through anything we can do."
    new "Aber es gibt keine Möglichkeit, ihn daran zu hindern, es rauszugeben. Zumindest nicht mit den Mitteln, die wir haben."

    # say L1249 pla
    old "So, I was thinking that maybe there's a way to do it through the SexNote."
    new "Dann dachte ich, vielleicht gibt es einen Weg durch die SexNote."

    # say L1250 lin
    old "What kind of information is this?"
    new "Welche Art von Informationen sind das?"

    # say L1251 pla
    old "It's videos and pictures, they must be safe in his computer or something."
    new "Es sind Videos und Fotos, die müssen sicher auf seinem Computer oder so sein."

    # say L1253 lin
    old "Well, don't you think it would just be easier if you steal his computer and delete that?"
    new "Na, findest du nicht, es wäre einfacher, wenn du seinen Computer klaut und das löscht?"

    # say L1255 pla
    old "I don't think that would do anything, he wouldn't be that stupid not to make any copies of it."
    new "Ich glaube nicht, dass das was bringen würde, er wäre doch nicht so dumm, keine Kopien davon zu machen."

    # say L1256 pla
    old "Besides, he also remembers it all, if he just tells the police or the press or anyone what he knows, they could find something."
    new "Außerdem erinnert er sich an alles, wenn er der Polizei oder der Presse oder irgendwem erzählt, was er weiß, könnten sie etwas finden."

    # say L1257 lin
    old "Hmm, I see what you mean."
    new "Hmm, ich sehe, was du meinst."

    # say L1258 lin
    old "So basically, what you want is a spell that'll change reality."
    new "Also basically brauchst du einen Zauber, der die Realität verändert."

    # say L1259 pla
    old "U-uh, w-what? I-I don't think..."
    new "U-äh, w-was? I-Ich glaube nicht..."

    # say L1261 lin
    old "Well, that's what you need, isn't it?"
    new "Na ja, das ist doch genau das, was du brauchst, oder?"

    # say L1262 lin
    old "I mean, you need every version of this information to disappear."
    new "Ich meine, du musst jede Version dieser Information verschwinden lassen."

    # say L1263 lin
    old "That includes his memories, so that he won't go around telling it to people."
    new "Das beinhaltet auch seine Erinnerungen, damit er es nicht herumerzählen kann."

    # say L1264 lin
    old "That's a very high requirement for a spell [pla]."
    new "Das ist eine sehr hohe Anforderung für einen Zauber [pla]."

    # say L1266 lin
    old "But... There's a way..."
    new "Aber... Es gibt einen Weg..."

    # say L1268 lin
    old "Something like that, there's a way to erase stuff magically... or at least their 'presence'."
    new "Etwas in der Art, es gibt einen Weg, Dinge magisch zu löschen... oder zumindest ihre 'Anwesenheit'."

    # say L1270 pla
    old "'Presence'? W- what do you mean?"
    new "'Präsenz'? W- was meinst du damit?"

    # say L1272 lin
    old "I mean just that, you humans live in a world full of traces, all of your technology is marked with traces of who you are."
    new "Ich meine genau das, ihr Menschen lebt in einer Welt voller Spuren, all eure Technik ist mit Spuren von euch selbst gekennzeichnet."

    # say L1273 lin
    old "Like those pictures that you take of each other and then you can save or send."
    new "Wie diese Fotos, die ihr voneinander macht und dann speichern oder senden könnt."

    # say L1274 lin
    old "But also memories, whatever traces left by time in the mind of someone else. That's also a 'presence'."
    new "Aber auch Erinnerungen, egal welche Spuren die Zeit im Geist eines anderen hinterlässt. Das ist auch eine Art von Präsenz."

    # say L1275 lin
    old "All of that can be gone. With a big spell."
    new "Das alles kann verschwinden. Mit einem großen Zauber."

    # say L1276 lin
    old "I suppose that's what you mean when you say you want me to help you."
    new "Ich denke, das ist genau das, was du meinst, wenn du sagst, dass du meine Hilfe brauchst."

    # say L1277 pla
    old "Uhh, I mean, I think I do, but I'm not sure. I- I don't really understand all what you said."
    new "Uhh, ich meine, ich denke schon, aber ich bin mir nicht sicher. Ich- Ich verstehe nicht alles, was du gesagt hast."

    # say L1278 lin
    old "What I said is that I can use a spell that can erase all information about her, that's what you are asking me, right?"
    new "Was ich gesagt habe, ist, dass ich einen Zauber kenne, der alle Informationen über sie löschen kann, das ist doch genau das, was du von mir willst, oder?"

    # say L1279 pla
    old "Yes! That's exactly what I need..."
    new "Ja! Das ist genau, was ich brauche..."

    # say L1280 pla
    old "And if you have another spell for the bad guy, you know, something to make him forget all about her."
    new "Und wenn du noch einen Zauber für den Bösewicht hast, du weißt schon, so was, dass er alles über sie vergisst."

    # say L1282 lin
    old "Yeah, with the same spell the bad human doing the 'blackmail' thing, he won't even remember her."
    new "Ja, mit demselben Zauber wird der böse Mensch, der das 'Erpressung' Ding macht, sie nicht mal mehr erinnern."

    # say L1283 lin
    old "Everything about her would be forgotten."
    new "Alles über sie wäre vergessen."

    # say L1284 lin
    old "If he can't remember anything about her, and all the information he has is also gone. That would solve your problem, would it not?"
    new "Wenn er sich an nichts mehr erinnern kann und alle Informationen, die er hat, auch weg sind, würde das dein Problem lösen, oder?"

    # say L1285 pla
    old "Wow! Yeah, that's perfect!"
    new "Wow! Ja, das ist perfekt!"

    # say L1286 lin
    old "All right, this spell is somewhat difficult to execute, but is possible."
    new "Okay, dieser Zauber ist etwas schwierig auszuführen, aber es ist möglich."

    # say L1288 pla
    old "Ok, what do I need?"
    new "Okay, was brauch ich?"

    # say L1290 lin
    old "Hmm, to be honest, you're still not very good with magic..."
    new "Hmm, ehrlich gesagt, bist du noch nicht besonders gut im Umgang mit Magie..."

    # say L1291 lin
    old "So, I'll have to prepare a lot of things beforehand to make it easier for you to use that spell."
    new "Dann muss ich vorher eine Menge Dinge vorbereiten, damit du den Zauber leichter benutzen kannst."

    # say L1292 pla
    old "Oh, it can't be done today? I mean, I have a bit of an urgency with this..."
    new "Oh, dann klappt das heute wohl nicht? Ich meine, da hab ich schon ein bisschen Dringlichkeit drin..."

    # say L1293 lin
    old "No, I'll need a couple of days to get everything ready, we can't afford any mistakes with this."
    new "Nein, ich brauche ein paar Tage, um alles vorzubereiten. Wir können uns bei diesem Zauber keine Fehler leisten."

    # say L1294 pla
    old "Hmm, I guess that's fine if there's no way to do it now."
    new "Hmm, ich schätze, das ist in Ordnung, wenn es jetzt nicht geht."

    # say L1295 pla
    old "Thanks for your help Linnet, I'm counting on you."
    new "Danke für deine Hilfe, Linnet, ich zähle auf dich."

    # say L1296 lin
    old "I'll do my best to help you, don't worry."
    new "Ich werde mein Bestes tun, um dir zu helfen, mach dir keine Sorgen."

    # say L1304 pla
    old "I knew it, magic should be useful for something."
    new "Ich wusste es, Magie sollte doch für was gut sein."

    # say L1305 pla
    old "With this I'm sure I'll be able to help Ms. Mia."
    new "Mit diesem werde ich Ms. Mia sicherlich helfen können."

    # say L1328 mia
    old "[pla]... I'm gonna need you to come to the classroom with me."
    new "[pla]... Ich werde Sie brauchen, kommen Sie bitte mit in den Klassenraum."

    # say L1329 pla
    old "Oh, not Denzel again, come on. What does he want now?"
    new "Oh, nicht schon wieder Denzel, komm schon. Was will er jetzt schon wieder?"

    # say L1330 mia
    old "Just come with me."
    new "Kommen Sie einfach mit mir."

    # say L1345 mia
    old "Denzel said he wanted to talk to both of us, let me call him and I'll put the call on speaker."
    new "Denzel hat gesagt, er möchte mit uns beiden sprechen, lass mich ihn anrufen und ich stelle den Anruf auf Lautsprecher."

    # say L1350 mia
    old "Denzel, hi."
    new "Denzel, hallo."

    # say L1351 den
    old "Hi there Ms. Mia! How are you? Is my good friend [pla] over there?"
    new "Hallo Ms. Mia! Wie geht es Ihnen? Ist mein guter Freund [pla] da?"

    # say L1352 pla
    old "I'm here."
    new "Ich bin hier."

    # say L1354 den
    old "Excellent, excellent! Ok, guys, I've been thinking, and I came to a conclusion."
    new "Exzellent, exzellent! Okay, Leute, ich habe nachgedacht und bin zu einem Schluss gekommen."

    # say L1356 den
    old "Well, I've decided that it's time for you two to take your relationship to the next level."
    new "Na ja, ich hab mich entschieden, dass es Zeit für euch beide ist, eure Beziehung aufs nächste Level zu bringen."

    # say L1357 den
    old "Given that you already consummated your teacher-student love."
    new "Da ihr eure Lehrer-Schüler-Liebe schon vollzogen habt."

    # say L1359 den
    old "I think you need to take the next step?"
    new "Ich denke, ihr müsst den nächsten Schritt machen?"

    # say L1360 pla
    old "The next step? We already had sex, what do you even mean?"
    new "Der nächste Schritt? Wir hatten schon Sex, was meinst du damit überhaupt?"

    # say L1361 pla
    old "Stop beating around the bush and tell us already!"
    new "Hör auf, um den heißen Brei herumzureden, und sag es uns endlich!"

    # say L1362 den
    old "Easy there buddy! Trust me, you'll like what I have in store for you guys today."
    new "Komm schon, Alter! Vertrau mir, ihr werdet euch über meine Pläne für heute freuen."

    # say L1365 den
    old "Well, I want you to fuck Mia in the ass. It's time she gets her ass fucked."
    new "Na gut, ich will, dass du Mia im Arsch fickst. Es ist Zeit, dass sie ihren Arsch gefickt kriegt."

    # say L1367 pla
    old "W-what?!"
    new "W-was?!"

    # say L1368 mia
    old "I-I can't do that, I've never done it before! Not even when I was a porn actress!"
    new "Ich kann das nicht, ich habe es noch nie gemacht! Nicht einmal als Pornodarstellerin!"

    # say L1369 den
    old "Well, I guess there's a first time for everything, am I right?"
    new "Na ja, für alles gibt es ein erstes Mal, oder?"

    # say L1370 den
    old "Of course you'll do it on video call with me so that I can record it."
    new "Natürlich wirst du es bei dem Videoanruf mit mir machen, damit ich es aufnehmen kann."

    # say L1371 den
    old "We wouldn't want to waste that good material right?"
    new "Wir wollen doch das gute Material nicht verschwenden, oder?"

    # say L1372 pla
    old "You're crazy if you think we'll do this!"
    new "Du bist verrückt, wenn du denkst, dass wir das machen!"

    # say L1374 pla
    old "This is way too much! We're not doing anything!"
    new "Das ist viel zu viel! Wir machen gar nichts!"

    # say L1376 den
    old "Aww, this again dude?"
    new "Ach, das noch mal, Alter?"

    # say L1377 den
    old "Come on [pla], don't you ever get bored of this routine? It really annoys me that you say no to everything I tell you to do."
    new "Komm schon [pla], langweilst du dich nie an diesem Ritual? Es nervt mich echt, dass du bei allem, was ich dir sage, nein sagst."

    # say L1378 den
    old "Only to then turn around and do it anyway."
    new "Nur um es dann trotzdem zu tun."

    # say L1379 den
    old "It really tests my patience, so shut up and do it!"
    new "Das reizt meine Geduld echt aufs Äußerste, also halt die Klappe und mach es!"

    # say L1380 pla
    old "We're not doing anything!"
    new "Wir machen gar nichts!"

    # say L1381 mia
    old "W- wait [pla]!"
    new "W-warten [pla]!"

    # say L1382 mia
    old "You know we have to do it. We have no choice."
    new "Sie wissen, dass wir es tun müssen. Wir haben keine Wahl."

    # say L1383 mia
    old "If what he has on us comes out we'll both be ruined!"
    new "Wenn das herauskommt, was er über uns weiß, sind wir beide ruiniert!"

    # say L1384 pla
    old "No! Think about it!"
    new "Nein! Überleg doch mal!"

    # say L1385 pla
    old "What is it going to be next time?! He already made us do all those things! Next time he'll make us fuck in the principals office!"
    new "Was kommt beim nächsten Mal dran?! Er hat uns schon all das machen lassen! Das nächste Mal wird er uns dazu zwingen, im Büro des Schulleiters zu ficken!"

    # say L1386 mia
    old "But we have to!"
    new "Aber wir müssen!"

    # say L1387 pla
    old "No we don't, and I won't do anything!"
    new "Nein, das müssen wir nicht, und ich werde nichts tun!"

    # say L1388 den
    old "That so? Well, then I guess you leave me no choice."
    new "Ist das so? Na dann bleibt mir wohl nichts anderes übrig."

    # say L1389 den
    old "I suppose this was gonna happen anyway, I was already getting bored with you two."
    new "Ich schätze, das war sowieso irgendwann so weit, ich hab mich schon langweilen lassen von euch beiden."

    # say L1390 mia
    old "Wait! Wait! Give us a minute, I can convince him!"
    new "Warten! Warten! Geben Sie uns eine Minute, ich kann ihn überzeugen!"

    # say L1391 den
    old "You already heard him Mia, he's not gonna do anything."
    new "Du hast ihn doch schon gehört, Mia, er wird nichts tun."

    # say L1392 den
    old "So, I guess he's fine with me sending the information out."
    new "Dann schätze ich, er hat damit kein Problem, dass ich die Informationen weitergebe."

    # say L1393 den
    old "And that's what I will do, I'll send it straight to your school's principal."
    new "Und das werde ich tun, ich schicke es direkt an die Schulleiterin."

    # say L1394 den
    old "I'll be eager to see how things pan out for you 'Ms.' Mia."
    new "Ich freue mich darauf zu sehen, wie sich die Dinge für dich, 'Ms.' Mia, entwickeln."

    # say L1395 mia
    old "No, please don't' do this!"
    new "Nein, bitte tun Sie das nicht!"

    # say L1396 den
    old "I have to say it was an honor to be a student of Mia the pornstar."
    new "Ich muss sagen, es war eine Ehre, Mias Schüler zu sein."

    # say L1397 den
    old "I bet that when things blow out, you'll get that job back in no time."
    new "Ich wette, wenn der Staub sich legt, kriegst du deinen Job zurück, Mia."

    # say L1399 den
    old "And [pla], you see what you fucking did? I hope you're happy with that!"
    new "Und [pla], siehst du was du verdammt nochmal angerichtet hast? Ich hoffe, du bist zufrieden damit!"

    # say L1400 mia
    old "Wait... Hello? Denzel?? Hello?"
    new "Warten Sie... Hallo? Denzel?? Hallo?"

    # say L1401 mia
    old "Oh, no, no, no, no, no!"
    new "Oh nein, nein, nein, nein, nein!"

    # say L1404 mia
    old "What the fuck you did [pla]! I have to call him again..."
    new "Was zum Teufel haben Sie gemacht [pla]! Ich muss ihn nochmal anrufen..."

    # narrator L1406 
    old "... Ringing... {w} Ringing..."
    new "... Klingeln... {w} Klingeln..."

    # say L1408 mia
    old "FUCK! HE DOESN'T ANSWER!"
    new "VERDAMMT! ER NIMMT NICHT AB!"

    # say L1411 mia
    old "Oh my gosh! Why did you do that? You idiot!!"
    new "Oh Gott! Warum haben Sie das getan? Sie Idiot!!"

    # say L1412 mia
    old "Don't you care what will happen to you?! Or me?!"
    new "Sie interessieren sich doch gar nicht dafür, was mit Ihnen passiert?! Oder mit mir?!"

    # say L1413 mia
    old "You said you wanted to help me, and this is what you do?!!"
    new "Sie sagten, Sie wollten mir helfen, und das ist, was Sie tun?!!"

    # say L1414 mia
    old "You fucking asshole! What are we going to do now?!"
    new "Sie verdammter Arsch! Was sollen wir jetzt tun?!"

    # say L1415 pla
    old "You know he was going to do this sooner or later. He's that type of bastard."
    new "Du weißt doch, dass er das früher oder später tun würde. Er ist einfach so ein Arschloch."

    # say L1416 mia
    old "Well, he did it now! So what are we going to do?!"
    new "Na gut, er hat es jetzt getan! Was sollen wir also tun?!"

    # say L1417 pla
    old "Calm down, listen, look, he kept talking about a mail."
    new "Beruhige dich, hör zu, siehst du, er hat die ganze Zeit von einer E-Mail gesprochen."

    # say L1418 pla
    old "Which means he's gonna have to send it through some physical means, a cd or a usb."
    new "Das bedeutet, er muss es auf physischem Weg verschicken, also per CD oder USB."

    # say L1420 pla
    old "So, all we have to do is intercept it before it arrives. Even if it's an express delivery, that's going to take a little while."
    new "Dann müssen wir es nur abfangen, bevor es ankommt. Selbst wenn es eine Expresslieferung ist, dauert das noch ein bisschen."

    # say L1421 mia
    old "And then what? Even if we stop that, he still has copies!"
    new "Und dann? Auch wenn wir das abfangen, hat er immer noch Kopien!"

    # say L1422 mia
    old "He could just send it to the police! Or the news! Or somewhere else!"
    new "Er könnte es einfach zur Polizei schicken! Oder in die Nachrichten! Oder an einen anderen Ort!"

    # say L1423 mia
    old "Then what?!"
    new "Dann was?!"

    # say L1424 pla
    old "Ha, I've got a way to deal with that."
    new "Ha, ich hab da eine Lösung dafür."

    # say L1425 pla
    old "Listen, I'm going to need you to trust me on this, ok?"
    new "Hör zu, ich brauche, dass du mir vertraust, okay?"

    # say L1426 pla
    old "If everything goes according to my plan, not only will everything remain a secret, you'll never have to worry about it ever again."
    new "Wenn alles nach meinem Plan läuft, bleibt nicht nur alles geheim, du musst dir auch nie wieder Sorgen deswegen machen."

    # say L1428 mia
    old "What are you going to do?"
    new "Was haben Sie vor?"

    # say L1429 pla
    old "That... I can't tell you, but trust me, everything's going to be alright."
    new "Das... das kann ich dir nicht sagen, aber vertrau mir, alles wird gut."

    # say L1430 pla
    old "All I have to do is go check if everything's ready."
    new "Alles, was ich tun muss, ist nachsehen, ob alles bereit ist."

    # say L1432 mia
    old "What are you talking about? You're not making any sense!"
    new "Wovon reden Sie? Das ergibt überhaupt keinen Sinn!"

    # say L1433 pla
    old "I know you don't get it right now, but you'll see... Please just trust me."
    new "Ich weiß, dass du es jetzt nicht verstehst, aber du wirst sehen... Bitte vertrau mir einfach."

    # say L1434 mia
    old "I guess I have no choice..."
    new "Ich schätze, ich habe keine Wahl..."

    # say L1435 pla
    old "For now, we have to deal with what Denzel's about to send to the school principal."
    new "Im Moment müssen wir uns um das kümmern, was Denzel dem Schulleiter schicken wird."

    # say L1436 pla
    old "That's the priority."
    new "Das ist die Priorität."

    # say L1437 mia
    old "What do you propose then?"
    new "Was schlagen Sie dann vor?"

    # say L1438 pla
    old "I think we're gonna have to steal it."
    new "Ich denke, wir müssen es klauen."

    # say L1439 pla
    old "For now just stay here and check if a delivery guy comes, I'll go to my house to check on things."
    new "Bleib hier und schau, ob ein Lieferant kommt, ich geh zu mir nach Hause und checke, was los ist."

    # say L1441 mia
    old "Again, what are you talking about?!"
    new "Wiederhole, wovon sprechen Sie?!"

    # say L1442 pla
    old "As I said, you'll understand later."
    new "Wie ich schon sagte, du wirst es später verstehen."

    # say L1443 pla
    old "But I really have to rush home, will you stay here and check if anything arrives?"
    new "Aber ich muss echt schnell nach Hause, bleibst du hier und schaust, ob was ankommt?"

    # say L1444 mia
    old "Yes, fine, I'll be here. You better know what you're doing."
    new "Ja, gut, ich bleibe hier. Sie sollten besser wissen, was Sie tun."

    # say L1446 pla
    old "I really think I do. I'll be back soon."
    new "Ich denke wirklich, dass ich es weiß. Ich bin bald zurück."

    # say L1451 mia
    old "I can't believe it, now everything depends on him..."
    new "Ich kann es nicht fassen, jetzt hängt alles von ihm ab..."

    # say L1458 lin
    old "Oh, hi [pla]."
    new "Oh, hallo [pla]."

    # say L1459 pla
    old "I'm going to need that spell of yours right now."
    new "Ich brauche jetzt deinen Zauber."

    # say L1460 pla
    old "Do you think we can use it?"
    new "Glaubst du, wir können es benutzen?"

    # say L1462 lin
    old "No, we can't, this is a process [pla], and we can't just force it out. Sorry."
    new "Nein, können wir nicht, das ist ein Prozess [pla] und wir können ihn nicht einfach herauszwingen. Tut mir leid."

    # say L1463 pla
    old "Oh really?! Fuck I really need it now..."
    new "Oh echt?! Scheiße, ich brauch es jetzt wirklich..."

    # say L1464 pla
    old "When do you think we'll be able to do it?"
    new "Wann denkst du, können wir es machen?"

    # say L1465 lin
    old "Well, if I'm quick with this, tomorrow, I'll need another day."
    new "Na ja, wenn ich damit schnell fertig werde, morgen. Ich brauche aber noch einen Tag."

    # say L1467 pla
    old "Hmm... Are you sure it'll be ready tomorrow?"
    new "Hmm... Bist du dir sicher, dass es morgen fertig sein wird?"

    # say L1468 lin
    old "Yeah, it'll be difficult, but I can make it."
    new "Klar, es wird schwierig, aber ich schaffe das."

    # say L1469 pla
    old "Ok, then I guess we'll have to find a way to make it tomorrow."
    new "Okay, dann müssen wir uns was einfallen lassen, um es morgen zu schaffen."

    # say L1470 pla
    old "Please help me with that, I really need it as soon as possible."
    new "Bitte hilf mir dabei, ich brauche es wirklich so schnell wie möglich."

    # say L1471 lin
    old "Ok then I will continue working on the spell."
    new "Okay, dann werde ich mit dem Zauber weitermachen."

    # say L1483 mia
    old "Hey, what happened? I have been waiting for you... Did you get what you need? Is everything solved?"
    new "Hey, was ist passiert? Ich habe auf Sie gewartet... Haben Sie bekommen, was Sie brauchen? Ist alles geklärt?"

    # say L1484 pla
    old "Hmm, n-not really."
    new "Hmm, n-nein, wirklich nicht."

    # say L1485 pla
    old "It's almost ready, but it's still going to take a little while."
    new "Es ist fast fertig, aber es wird noch ein bisschen dauern."

    # say L1486 pla
    old "At least until tomorrow."
    new "Bis morgen auf jeden Fall."

    # say L1487 mia
    old "I still don't understand, what's going to take until tomorrow?"
    new "Ich verstehe immer noch nicht, was bis morgen dauern soll."

    # say L1489 pla
    old "Just trust me. After tomorrow everything will be solved."
    new "Vertrau mir einfach. Nach morgen wird alles gelöst sein."

    # say L1491 mia
    old "Are you going to kill Denzel?"
    new "Sind Sie etwa vor, Denzel zu töten?"

    # say L1492 pla
    old "What?! No! How can you think something like that?"
    new "Was?! Nein! Wie kannst du so etwas denken?"

    # say L1494 pla
    old "Just relax. You'll get it tomorrow.."
    new "Beruhige dich. Du kriegst es morgen."

    # say L1495 pla
    old "But we're gonna have to deal with the delivery."
    new "Aber wir müssen uns um die Lieferung kümmern."

    # say L1496 pla
    old "We have to find a way to steal away what Denzel sent today."
    new "Wir müssen einen Weg finden, um das zu stehlen, was Denzel heute geschickt hat."

    # say L1497 pla
    old "So that the principal won't see them."
    new "Damit die Schulleiterin sie nicht sieht."

    # say L1498 mia
    old "Well, she's already gone home. So even if it arrives today, she won't see it until tomorrow."
    new "Nun, sie ist schon nach Hause gegangen. Also selbst wenn es heute ankommt, wird sie es erst morgen sehen."

    # say L1499 pla
    old "Ok, so I suppose we'll have to steal it tomorrow before she sees it."
    new "Ok, dann müssen wir es morgen klauen, bevor sie es sieht."

    # say L1500 pla
    old "We'll have to arrive very early. Before she does."
    new "Wir müssen sehr früh da sein. Vor ihr."

    # say L1501 pla
    old "After that everything will be fine."
    new "Danach wird alles gut sein."

    # say L1503 mia
    old "It will? But what are you going to do?"
    new "Es wird? Aber was haben Sie vor?"

    # say L1504 pla
    old "I just can't tell you."
    new "Ich kann dir das einfach nicht sagen."

    # say L1506 mia
    old "Damn, ok, whatever. You better make whatever you do really work..."
    new "Verdammt, okay, egal. Machen Sie bloß sicher, dass es funktioniert..."

    # say L1507 pla
    old "Don't worry."
    new "Mach dir keine Sorgen."

    # say L1508 mia
    old "So, we'll meet here tomorrow?"
    new "Also, wir sehen uns morgen hier?"

    # say L1510 pla
    old "Yeah, before classes."
    new "Klar, bevor die Kurse anfangen."

    # say L1511 mia
    old "Ok, that's it then. Don't be late."
    new "Ok, dann ist es so. Kommen Sie nicht zu spät."

    # say L1512 pla
    old "Of course not."
    new "Natürlich nicht."

    # say L1513 mia
    old "All right, see you tomorrow then."
    new "Also, bis morgen dann."

    # say L1514 pla
    old "Ok, don't worry tomorrow this will all be over."
    new "Ok, mach dir keine Sorgen, morgen ist alles vorbei."

    # say L1534 mia
    old "At this point I think just Mia's fine."
    new "Ab diesem Punkt denke ich, dass einfach Mia reicht."

    # say L1536 mia
    old "Ok, so I came in very early to check that the coast is clear."
    new "Ok, ich bin sehr früh gekommen, um sicherzustellen, dass die Luft rein ist."

    # say L1537 mia
    old "Nobody's around."
    new "Niemand ist da."

    # say L1538 pla
    old "That's perfect, so we should be able to get it with no problem."
    new "Das ist perfekt, dann sollten wir das ohne Probleme schaffen."

    # say L1539 mia
    old "Ok, let's go, we need to check out the principal's office."
    new "Ok, dann los, wir müssen das Büro des Schulleiters überprüfen."

    # say L1554 pla
    old "Have you found anything?"
    new "Hast du was gefunden?"

    # say L1555 mia
    old "Nothing, everything look's fine."
    new "Nichts, alles sieht in Ordnung aus."

    # say L1556 pla
    old "Hmm, there must be something."
    new "Hmm, da muss doch was sein."

    # say L1566 pla
    old "Ah, that must be it."
    new "Ah, das muss es sein."

    # say L1568 pla
    old "Why else would there be a CD on her desk?"
    new "Warum sonst sollte es eine CD auf ihrem Schreibtisch geben?"

    # say L1569 mia
    old "Yeah, you're probably right. It must've arrived during the evening and the janitor put it here."
    new "Ja, Sie haben wahrscheinlich recht. Es muss während des Abends angekommen sein und der Hausmeister hat es hier hingelegt."

    # say L1572 mia
    old "Ok, so what do we do now?"
    new "Ok, was machen wir dann jetzt?"

    # say L1573 pla
    old "What we have to do is just..."
    new "Was wir tun müssen, ist einfach..."

    # say L1575 mia
    old "Wait! I just heard something! I think someone's coming."
    new "Warten Sie! Ich habe gerade etwas gehört! Ich glaube, jemand kommt."

    # say L1576 mia
    old "Quick get in that closet."
    new "Schnell, rein in den Schrank."

    # say L1588 pla
    old "What are we going to do?"
    new "Was sollen wir tun?"

    # say L1589 mia
    old "Shhhh, someone's coming, they'll hear us."
    new "Pssst, jemand kommt, sie werden uns hören."

    # say L1597 dir
    old "Ok, I see some correspondence arrived yesterday. What do we have here?"
    new "Okay, ich sehe, dass gestern einige Korrespondenzen eingetroffen sind. Was haben wir denn da?"

    # say L1600 dir
    old "Oh! Not the auditing process again!"
    new "Oh! Nicht wieder der Auditing-Prozess!"

    # say L1603 dir
    old "The day just started and it's already ruined, everytime they do it we have to jump through so many hurdles."
    new "Der Tag hat gerade angefangen und ist schon ruiniert, jedes Mal, wenn sie das machen, müssen wir so viele Hürden nehmen."

    # say L1608 dir
    old "{i}*Sigh*{/i} I guess there's nothing to do, I'll just deal with it."
    new "{i}*Seufz*{/i} Ich schätze, da bleibt mir nichts anderes übrig, ich werde es einfach durchstehen."

    # say L1609 dir
    old "But first..."
    new "Aber erst mal..."

    # say L1615 dir
    old "Nothing wrong with dealing with some stress early before work."
    new "Nichts falsch daran, ein bisschen Stress vor der Arbeit abzubauen."

    # say L1616 dir
    old "I don't usually do this here at the office, but what the hell."
    new "Ich mache das normalerweise nicht im Büro, aber was soll's."

    # say L1617 dir
    old "It's been quite a while, I think it will be fun."
    new "Es ist schon eine Weile her, ich denke, es wird Spaß machen."

    # say L1620 mia
    old "What the hell? Do you actually have a boner right now?"
    new "Was soll das? Haben Sie etwa wirklich eine Erektion?"

    # say L1621 pla
    old "S- sorry, I just can't help it."
    new "Entschuldigung, ich kann einfach nicht anders."

    # say L1622 pla
    old "It's not my intention."
    new "Es ist nicht meine Absicht."

    # say L1623 mia
    old "Ugh, you're incredible, I can't believe you."
    new "Ugh, Sie sind unglaublich, ich kann es nicht fassen."

    # say L1633 dir
    old "Mmm, oh yeah, this is just what I needed."
    new "Mmm, oh ja, das ist genau, was ich gebraucht habe."

    # say L1634 dir
    old "Oh! It's so good!"
    new "Oh! Das ist so gut!"

    # say L1635 dir
    old "That's it, yeah, yeah."
    new "Das ist es, ja, ja."

    # say L1638 pla
    old "Wow, she is..."
    new "Wow, sie ist..."

    # say L1639 mia
    old "Shhh..."
    new "Pssst..."

    # say L1646 pla
    old "W-what are you doing?"
    new "W-was machst du da?"

    # say L1647 mia
    old "Shhh, be quiet, she'll find us if you keep talking."
    new "Pssst, seien Sie still, sie findet uns, wenn Sie weiterreden."

    # say L1648 pla
    old "But you're- ..."
    new "Aber du bist-"

    # say L1649 mia
    old "Shhh, just shut up!"
    new "Pst, halten Sie doch einfach den Mund!"

    # say L1657 dir
    old "Fantastic!"
    new "Fantastisch!"

    # say L1658 dir
    old "But I better go check on things around the school before the students arrive."
    new "Aber ich sollte besser die Schule vor dem Eintreffen der Schüler überprüfen."

    # say L1667 mia
    old "Mmm! Oh! Oh yeah!"
    new "Mmm! Oh! Oh ja!"

    # say L1669 pla
    old "Hmm, M-Mia, the principal just left."
    new "Hmm, M-Mia, die Direktorin ist gerade gegangen."

    # say L1670 pla
    old "I think we better get out of here before she or anybody else comes back."
    new "Ich denke, wir sollten besser verschwinden, bevor sie oder jemand anderes zurückkommt."

    # say L1671 mia
    old "Uh, what? Oh yeah!"
    new "Uh, was? Oh ja!"

    # say L1672 mia
    old "You're right, l- let's get out of here."
    new "Sie haben recht, l- lassen Sie uns hier verschwinden."

    # say L1684 mia
    old "Ok, we have to go then, we can't keep wasting any more time here."
    new "Okay, dann müssen wir los, wir können hier keine Zeit mehr verschwenden."

    # say L1685 pla
    old "Yeah, I guess you're right, don't forget to bring the CD."
    new "Ja, ich schätze, du hast recht, vergiss nicht das CD mitzunehmen."

    # say L1707 mia
    old "Phew, it's good that we made it."
    new "Phew, es ist gut, dass wir es geschafft haben."

    # say L1708 mia
    old "I can't believe we almost got caught. Hehe, right?"
    new "Ich kann es nicht glauben, dass wir fast erwischt worden wären. Hehe, stimmt's?"

    # say L1709 pla
    old "Eh, yeah, you're right haha, that was close, phew!"
    new "Eh, ja, du hast recht haha, das war knapp, phew!"

    # say L1711 mia
    old "What now then?"
    new "Was jetzt dann?"

    # say L1713 pla
    old "Well, we're relieved, but we're not sure if this really is what we were looking for."
    new "Na ja, wir sind erleichtert, aber wir sind uns nicht sicher, ob das wirklich das ist, wonach wir gesucht haben."

    # say L1714 pla
    old "So we better check in the computer to see if it is."
    new "Dann sollten wir besser im Computer nachschauen, ob es das wirklich ist."

    # say L1716 mia
    old "Yeah, you're right, we should check."
    new "Ja, Sie haben recht, wir sollten das überprüfen."

    # say L1722 pla
    old "That's very weird, there only seems to be a single video."
    new "Das ist sehr seltsam, es scheint nur ein einzelnes Video zu geben."

    # say L1723 pla
    old "Nothing else."
    new "Nichts anderes."

    # say L1724 mia
    old "Well, open it, we need to see if it is."
    new "Na dann öffnen Sie es, wir müssen sehen, ob es so ist."

    # say L1734 pla
    old "Woah! I wasn't expecting that."
    new "Wow! Das habe ich nicht erwartet."

    # say L1735 mia
    old "Oh my god! It is."
    new "Oh mein Gott! Es ist wahr."

    # say L1736 mia
    old "I can't believe he actually found something."
    new "Ich kann es nicht fassen, dass er tatsächlich etwas gefunden hat."

    # say L1737 mia
    old "It seems the producers didn't get rid of everything as I wanted them to."
    new "Es scheint, die Produzenten haben nicht alles entfernt, wie ich es wollte."

    # say L1738 mia
    old "How did Denzel get his hands on this?"
    new "Wie ist Denzel an das gekommen?"

    # say L1753 dir
    old "I need to see you both in my office."
    new "Ich muss euch beide in meinem Büro sehen."

    # say L1754 dir
    old "So come to my office as soon as you're done working on whatever it is you're working on that computer."
    new "Dann kommt so schnell wie möglich in mein Büro, wenn ihr mit eurer Arbeit am Computer fertig seid."

    # say L1761 mia
    old "W-what? Why does she want to see us there?"
    new "W-was? Warum will sie uns dort sehen?"

    # say L1763 mia
    old "Oh no, she found out we were there, or maybe Denzel sent her another thing!"
    new "Oh nein, sie hat rausgefunden, dass wir da waren, oder vielleicht hat Denzel ihr wieder was geschickt!"

    # say L1765 pla
    old "Calm down, calm down, there's no reason why she would know we were in her office."
    new "Beruhige dich, beruhige dich, da gibt es keinen Grund, warum sie wissen sollte, dass wir in ihrem Büro waren."

    # say L1766 pla
    old "And why would Denzel send her another CD?"
    new "Und warum sollte Denzel ihr noch eine CD schicken?"

    # say L1767 mia
    old "Then what do you think she wants to talk to us about?"
    new "Dann was denken Sie, worüber sie mit uns sprechen will?"

    # say L1768 pla
    old "I guess we have to talk to her."
    new "Dann müssen wir wohl mit ihr reden."

    # say L1770 mia
    old "{i}*Sigh*{/i} Ok, let's go then, I guess we'll have to see."
    new "{i}*Seufz*{/i} Okay, dann lass es uns hinter uns bringen, schätze ich."

    # say L1777 mia
    old "Why aren't you walking?"
    new "Warum gehen Sie nicht?"

    # say L1778 pla
    old "Hmm, the thing is, I-I kinda can't right now."
    new "Hmm, die Sache ist, ich-ich kann im Moment irgendwie nicht."

    # say L1779 mia
    old "Why not?"
    new "Warum nicht?"

    # say L1780 pla
    old "Uhhh...I just need a few minutes... I mean after I watched your video."
    new "Uhhh... Ich brauch einfach ein paar Minuten... Ich meine, nachdem ich dein Video gesehen habe."

    # say L1784 mia
    old "You're really unbelievable, you know?! I can't believe you actually got a boner from that!"
    new "Sie sind wirklich unglaublich, wissen Sie das?! Ich kann nicht glauben, dass Sie tatsächlich eine Erektion davon bekommen haben!"

    # say L1785 pla
    old "Well, I'm still a man, you know? It's not like I want to go around with a boner."
    new "Na ja, ich bin immer noch ein Mann, weißt du? Das heißt nicht, dass ich damit rumlaufen will."

    # say L1786 mia
    old "Ugh, shut up. Just get rid of it, will you?"
    new "Ugh, halten Sie den Mund. Machen Sie es einfach weg, ja?"

    # say L1787 pla
    old "Get rid of it? How?"
    new "Loswerden? Wie denn?"

    # say L1788 mia
    old "How do you think genius? Jerk off!"
    new "Wie Sie denken, Genie? Wichsen Sie!"

    # say L1789 mia
    old "And do it quickly the principal is waiting for us."
    new "Und machen Sie es schnell, der Direktor wartet auf uns."

    # say L1790 pla
    old "I don't think that will work, I mean, I'm very nervous, and I just don't have my mind in it."
    new "Ich glaube, das wird nichts, ich meine, ich bin total nervös und kann mich einfach nicht konzentrieren."

    # say L1791 mia
    old "I just can't believe this."
    new "Ich kann es einfach nicht fassen."

    # say L1792 mia
    old "Ughh... We have to do it now before he comes back..."
    new "Ughh... Wir müssen es jetzt machen, bevor er zurückkommt..."

    # say L1793 pla
    old "Just give me a couple of minutes..."
    new "Gib mir einfach ein paar Minuten..."

    # say L1794 mia
    old "Hmm, you know what, I'll do it then."
    new "Hmm, Sie wissen was, ich mache es dann."

    # say L1804 mia
    old "What do you think genius? I'm making you cum."
    new "Was denken Sie, Genie? Ich mache dich kommen."

    # say L1805 mia
    old "We can't take too much time, the principal is waiting for us."
    new "Wir können uns nicht zu viel Zeit nehmen, der Direktor wartet auf uns."

    # say L1806 mia
    old "And since you can't do it yourself, I guess I'll have to do it for you."
    new "Und da Sie es selbst nicht schaffen, werde ich es wohl für Sie machen müssen."

    # say L1808 mia
    old "Come on [pla], it's not something we haven't done before, just focus on finishing quickly."
    new "Komm schon [pla], das haben wir schon oft genug gemacht, konzentrier dich einfach darauf, es schnell zu beenden."

    # say L1825 dir
    old "You took a while to come..."
    new "Du hast lange gebraucht, um zu kommen..."

    # say L1826 mia
    old "Ah, yeah, sorry. We didn't mean to."
    new "Ah, ja, entschuldigen Sie. Wir haben nicht vor, Sie zu belasten."

    # say L1827 mia
    old "It's just that the... thing we were doing took a little longer than expected."
    new "Es ist nur so, dass die... Sache, die wir gemacht haben, etwas länger gedauert hat als erwartet."

    # say L1830 dir
    old "Ok, listen up. Mia, last week you gave me a report..."
    new "Ok, hör zu. Mia, letzte Woche hast du mir einen Bericht gegeben..."

    # say L1832 dir
    old "In which [pla] appeared as someone to pay attention to because he wasn't performing up to the standards of the school. Right?"
    new "In dem Bericht, in dem [pla] als jemand aufgefallen ist, der seine Leistungen an der Schule nicht zufriedenstellend erbringt. Richtig?"

    # say L1834 mia
    old "Y-yeah, that's right. Is there a problem with it ma'am?"
    new "Y-ja, das stimmt. Ist damit ein Problem, Ma'am?"

    # say L1835 dir
    old "Not per se, after all, there's nothing unusual about a student needing to improve his grades."
    new "Nicht unbedingt, schließlich ist es nichts Ungewöhnliches, wenn ein Schüler seine Noten verbessern muss."

    # say L1836 dir
    old "The problem is that this morning I received a letter informing me we're about to be audited by the superintendent."
    new "Das Problem ist, dass ich heute Morgen einen Brief bekommen habe, der uns mitteilte, dass wir bald von der Schulbehörde überprüft werden."

    # say L1838 dir
    old "And it would be very good for us if we don't have a student about to be expelled due to his poor performance."
    new "Und es wäre sehr gut für uns, wenn wir keinen Schüler hätten, der wegen seiner schlechten Leistungen gleich exmatrikuliert wird."

    # say L1840 dir
    old "So, Mia, I normally wouldn't do this, but I need you to start helping him personally with his studies."
    new "Mia, ich würde das normalerweise nicht tun, aber ich brauche dich, dass du ihm persönlich bei seinen Studien hilfst."

    # say L1842 mia
    old "Sorry? Do you want me to tutor him? Personally?"
    new "Entschuldigung? Soll ich ihn Nachhilfe geben? Persönlich?"

    # say L1843 dir
    old "Exactly, think of it as extra classes for him. It must be done."
    new "Genau, denk dran, dass es zusätzliche Stunden für ihn sind. Das muss gemacht werden."

    # say L1844 dir
    old "We can't have any bad marks for the school qualification."
    new "Wir können keine schlechten Noten für die Schulqualifikation gebrauchen."

    # say L1845 mia
    old "I see, great."
    new "Ich verstehe, gut."

    # say L1846 dir
    old "Great?"
    new "Großartig?"

    # say L1847 mia
    old "Uh, I mean, I think it's great that we can get a good score just by doing that."
    new "Äh, ich meine, ich finde es großartig, dass wir einfach so einen guten Punktestand erreichen können."

    # say L1849 mia
    old "Actually ma'am, [pla]'s notes have been getting a lot better recently."
    new "Tatsächlich, [pla]s Notizen sind in letzter Zeit viel besser geworden."

    # say L1851 mia
    old "I'm sure that his grades will be on par with everyone else's when the auditing starts."
    new "Ich bin sicher, dass seine Noten auf dem gleichen Niveau wie die der anderen sein werden, wenn die Prüfung beginnt."

    # say L1852 dir
    old "Well, that's great to hear. I trust you have this Mia."
    new "Das freut mich zu hören. Ich vertraue darauf, dass du das im Griff hast, Mia."

    # say L1853 dir
    old "Now, I'm very busy, so you two can go back to class."
    new "Jetzt bin ich sehr beschäftigt, also könnt ihr beiden zurück in die Klasse gehen."

    # say L1854 mia
    old "Sure ma'am. Thank you."
    new "Natürlich, Ma'am. Danke."

    # say L1868 mia
    old "{i}*Sigh*{/i} Oh my god, that was very close."
    new "{i}*Seufz*{/i} Oh Gott, das war knapp."

    # say L1869 mia
    old "I thought we were done for. I was sure she had received another copy of the video from Denzel or something."
    new "Ich dachte, wir wären dran. Ich war sicher, dass sie eine weitere Kopie des Videos von Denzel bekommen hatte oder so."

    # say L1870 pla
    old "Yeah, me too, I'm glad we managed to avoid the trouble."
    new "Ja, ich auch. Ich bin froh, dass wir den Ärger vermeiden konnten."

    # say L1871 mia
    old "Well, that was just the start of it, we still have to deal with Denzel."
    new "Nun, das war erst der Anfang, wir müssen immer noch mit Denzel fertig werden."

    # say L1872 mia
    old "Which by the way, you still haven't told me anything about how you plan on doing that."
    new "Das übrigens, Sie haben mir immer noch nichts davon erzählt, wie Sie das vorhaben."

    # say L1873 pla
    old "It's ok, it should be ready by now, I think I just have to go handle that."
    new "Alles gut, es sollte jetzt bereit sein, ich denke, ich muss nur noch rangehen."

    # say L1874 mia
    old "Ready? What do you mean by that?"
    new "Bereit? Was meinen Sie damit?"

    # say L1875 pla
    old "Don't think too much about it."
    new "Mach dir nicht zu viele Gedanken darüber."

    # say L1876 pla
    old "You just have to know that by this afternoon not only will we have dealt with Denzel."
    new "Du musst nur wissen, dass bis heute Nachmittag nicht nur Denzel Geschichte ist."

    # say L1877 pla
    old "There's going to be no way of him or anyone else using anything from your past to try and hurt you."
    new "Da wird niemand, weder er noch sonst jemand, etwas aus deiner Vergangenheit gegen dich verwenden können."

    # say L1878 mia
    old "You make it sound so easy."
    new "Sie machen das klingen, als wäre es so einfach."

    # say L1879 mia
    old "But you seem to be very confident about this. So, I'll trust you."
    new "Aber Sie scheinen da sehr selbstsicher zu sein. Also, ich vertraue Ihnen."

    # say L1881 mia
    old "But wait, will you look for me to tell me if whatever it is you plan on doing works?"
    new "Aber warten Sie, werden Sie mich Bescheid sagen, ob das klappt, was Sie vorhaben?"

    # say L1883 pla
    old "Sure, you just focus on getting rid of that CD with your video on it."
    new "Klar, du konzentrierst dich einfach darauf, dieses CD mit deinem Video loszuwerden."

    # say L1884 pla
    old "And I'll handle the rest."
    new "Und ich kümmere mich um den Rest."

    # say L1885 mia
    old "Ok, whatever you say."
    new "Ok, wie Sie sagen."

    # say L1886 pla
    old "Thank you, I have to go, I'll see you later."
    new "Danke, ich muss los, sehen wir uns später."

    # say L1906 pla
    old "Hey! Hey! Linett! Are you ready?"
    new "Hey! Hey! Linett! Bist du bereit?"

    # say L1907 pla
    old "I need to know if the spell's ready to be used!"
    new "Ich muss wissen, ob der Zauber bereit ist, ihn zu benutzen!"

    # say L1908 lin
    old "Hi [pla]! Yeah, you're right on time, I just finished it."
    new "Hi [pla]! Ja, du kommst genau richtig, ich hab's gerade fertiggestellt."

    # say L1909 lin
    old "The spell's ready, so we can now use the SexNote to conjure it."
    new "Der Zauber ist bereit, also können wir jetzt die SexNote benutzen, um ihn zu beschwören."

    # say L1911 pla
    old "That's great, so what do we do?"
    new "Das ist toll, und was machen wir jetzt?"

    # say L1913 lin
    old "The hard work was already done by me, by focusing the magic power on the person you told me about."
    new "Die harte Arbeit habe ich schon geleistet, indem ich die magische Kraft auf die Person fokussiert habe, von der du mir erzählt hast."

    # say L1914 lin
    old "And limiting the reach of the spell."
    new "Und die Reichweite des Zaubers begrenzen."

    # say L1915 lin
    old "All you have to do is read it from the SexNote, and it will be cast."
    new "Du musst es nur aus der SexNote vorlesen, und es wird wirksam."

    # say L1916 pla
    old "Ok, that's very simple, can we do it now?"
    new "Ok, das ist sehr einfach, können wir es jetzt machen?"

    # say L1917 lin
    old "Sure, it should have already appeared in the SexNote, so you just have to read it, and that's it."
    new "Klar, es sollte schon im SexNote erschienen sein, also musst du es nur lesen, und fertig."

    # say L1920 pla
    old "You're right! Is there!"
    new "Stimmt! Da ist es!"

    # say L1921 pla
    old "So, all I have to do is read it?"
    new "Dann muss ich es nur lesen?"

    # say L1922 lin
    old "That's it."
    new "Das ist es."

    # say L1923 pla
    old "Ok, here it goes."
    new "Ok, dann mal los."

    # say L1926 pla
    old "Elementum recolligo Huic Commodo locus mihi vestri vox."
    new "Ich sammle mich, hier ist der richtige Ort für deine Stimme."

    # say L1927 pla
    old "Venire ventus venire, sinere solus sentire relaxari."
    new "Lass den Wind kommen, lass mich allein entspannen."

    # say L1930 lin
    old "I-I think it's starting to take effect!"
    new "Ich glaube, es fängt an zu wirken!"

    # say L1931 pla
    old "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"
    new "Lass mich noch ein Gefühl kommen, ich rede von den Geistern der Zwischenwelt!"

    # say L1932 pla
    old "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"
    new "Lass meinen Verstand frei, ich sage es, Geist, hör mein Urteil, mein Verstand, den ich verliere, Mia!"

    # say L1955 pla
    old "What's happening?!!"
    new "Was passiert hier?!!"

    # say L1961 pla
    old "Where am I?! What's this place?!"
    new "Wo bin ich?! Was ist das für ein Ort?!"

    # say L1962 pla
    old "What the hell?! What's this?"
    new "Was zur Hölle?! Was ist das hier?"

    # say L1963 pla
    old "Where are we Linett?"
    new "Wo sind wir Linett?"

    # say L1964 lin
    old "Hmmm, it seems something went awry with the spell..."
    new "Hmmm, es scheint, dass etwas mit dem Zauber schiefgelaufen ist..."

    # say L1965 pla
    old "What?! Can we fix it? What happened and where are we?!"
    new "Was?! Können wir es reparieren? Was ist passiert und wo sind wir?!"

    # say L1966 lin
    old "I don't know, I think we'll just have to wait."
    new "Ich weiß es nicht, ich denke, wir müssen einfach abwarten."

    # say L1967 pla
    old "W- what?..."
    new "W-was?..."

    # say L1972 lin
    old "Oh wow, you look like another person now!"
    new "Oh wow, du siehst jetzt wie eine andere Person aus!"

    # say L1977 pla2
    old "The fuck is happening Linett?!"
    new "Was zur Hölle ist hier los, Linett?!"

    # say L1978 lin
    old "Well, I told you, something went awry, apparently the energy is fluctuating..."
    new "Na ja, hab's dir gesagt, irgendwas ist schiefgelaufen, scheinbar fluktuiert die Energie..."

    # say L1980 pla2
    old "I don't know what that means!"
    new "Ich hab keine Ahnung, was das bedeutet!"

    # say L1986 pla
    old "Wait, we're back to normal."
    new "Warte, sind wir wieder normal?"

    # say L1987 pla
    old "What was that all about Linett? Was there something wrong with the spell?"
    new "Was war das gerade, Linett? War da etwas mit dem Zauber nicht in Ordnung?"

    # say L1989 lin
    old "It could be, but I don't think so. I think it has more to do with all of the power that it takes to call the spell."
    new "Es könnte sein, aber ich glaube nicht. Ich denke, es hat mehr mit der Menge an Energie zu tun, die nötig ist, um den Zauber zu wirken."

    # say L1990 lin
    old "All of that energy must've caused a tear in our reality that connected us to another one."
    new "All diese Energie muss einen Riss in unserer Realität verursacht haben, der uns mit einer anderen verbunden hat."

    # say L1991 lin
    old "The energy probably began to flow into the tear, and that made things begin switching places between the two realities."
    new "Die Energie ist wahrscheinlich in den Riss geflossen, und das hat dazu geführt, dass Dinge zwischen den beiden Realitäten getauscht wurden."

    # say L1993 pla
    old "Uh, sure..."
    new "Klar, sicher..."

    # say L1994 pla
    old "But what does that mean? Is everything alright?"
    new "Aber was bedeutet das? Ist alles in Ordnung?"

    # say L1996 lin
    old "There shouldn't be any problem, things must've stabilized after you finished the spell."
    new "Da sollte kein Problem sein, alles muss stabilisiert sein, nachdem du den Zauber beendet hast."

    # say L1997 lin
    old "The person you wanted to be forgotten is no longer in the mind of the bad human."
    new "Die Person, die du vergessen wolltest, ist nicht mehr im Kopf des schlechten Menschen."

    # say L1998 lin
    old "Also, every single trace of her presence has been removed."
    new "Also, jede einzelne Spur ihrer Anwesenheit wurde beseitigt."

    # say L1999 pla
    old "Does that mean no more videos or pictures of anything?"
    new "Das bedeutet also, es gibt keine Videos oder Fotos mehr von irgendwas?"

    # say L2001 lin
    old "Everything has been removed [pla]."
    new "Alles wurde entfernt [pla]."

    # say L2003 pla
    old "Great! That's awesome, thanks Linett!"
    new "Super! Das ist toll, danke Linett!"

    # say L2004 lin
    old "I'm happy to help you [pla], after all, you've done a lot for me and the other shinigamis."
    new "Ich freue mich, dir zu helfen [pla], schließlich hast du schon so viel für mich und die anderen Shinigami getan."

    # say L2005 pla
    old "I'll go and talk to Mia right now!"
    new "Ich geh jetzt und rede mit Mia!"

    # say L2018 pla
    old "Mia! Hey! It's done!"
    new "Mia! Hey! Es ist erledigt!"

    # say L2020 mia
    old "What are you talking about? What's done?"
    new "Wovon reden Sie? Was ist denn schon erledigt?"

    # say L2021 pla
    old "You just have to know that I already took care of your problem with Denzel."
    new "Du musst wissen, dass ich schon deinem Problem mit Denzel nachgekommen bin."

    # say L2022 pla
    old "He won't bother you any longer, there are no more videos or pictures or anything!"
    new "Er wird dich nicht mehr belästigen, es gibt keine Videos oder Fotos oder so was mehr!"

    # say L2023 mia
    old "Uh- I mean, I think that's good, but what about him? He can just go to the press and talk about me."
    new "Äh - ich meine, ich denke das ist gut, aber was ist mit ihm? Er kann doch einfach zur Presse gehen und über mich reden."

    # say L2024 pla
    old "Don't worry about that either, he won't even remember you, trust me."
    new "Mach dir darüber auch keine Sorgen, er wird dich nicht mal mehr erkennen, vertrau mir."

    # say L2025 mia
    old "What do you mean he won't even remember me?"
    new "Was meinen Sie damit, er wird mich nicht einmal mehr erkennen?"

    # say L2026 pla
    old "You know what? Let's check it, why don't you call him?"
    new "Du weißt was? Lass uns das überprüfen, warum rufst du ihn nicht an?"

    # say L2027 mia
    old "Now I really think you have gone insane. Call him?"
    new "Jetzt denke ich wirklich, dass Sie den Verstand verloren haben. Ihn anrufen?"

    # say L2028 pla
    old "Just trust me, everything will be fine."
    new "Vertrau mir einfach, alles wird gut."

    # say L2030 mia
    old "I guess we can try."
    new "Ich schätze, wir können es versuchen."

    # say L2034 pla
    old "Yeah, don't worry."
    new "Ja, mach dir keine Sorgen."

    # say L2038 den
    old "Hello, who is this? I don't recognize the number."
    new "Hallo, wer ist da? Ich kenne die Nummer nicht."

    # say L2039 mia
    old "Wh-?!"
    new "W-?!"

    # say L2040 mia
    old "Denzel? It's me, Mia... Uhh... from the school...."
    new "Denzel? Ich bin's, Mia... Äh... von der Schule...."

    # say L2041 den
    old "Listen, I don't know who you are, if you think you can scam me you better think twice!"
    new "Hör zu, ich weiß nicht, wer du bist, aber wenn du glaubst, mich reinlegen zu können, solltest du dir das noch mal überlegen!"

    # say L2042 mia
    old "What? No! I mean..."
    new "Was? Nein! Ich meine..."

    # say L2044 mia
    old "Hello? Helloo?..."
    new "Hallo? Halloo?..."

    # say L2045 mia
    old "He hung up, he said he didn't know who I was..."
    new "Er hat aufgelegt, er sagte, er wüsste nicht, wer ich bin..."

    # say L2047 pla
    old "See?"
    new "Siehst du?"

    # say L2048 mia
    old "What did you do?"
    new "Was haben Sie getan?"

    # say L2049 pla
    old "I'm sorry but I can't tell you that, all that matters is that with that your problem should be taken care of."
    new "Es tut mir leid, aber ich kann dir das nicht sagen. Wichtig ist nur, dass damit dein Problem gelöst sein sollte."

    # say L2051 mia
    old "I mean, I guess it is, but this is very odd."
    new "Ich meine, ich schätze schon, aber das ist sehr seltsam."

    # say L2053 pla
    old "Listen, all you have to do is trust me, ok?"
    new "Hör zu, du musst mir einfach vertrauen, okay?"

    # say L2054 pla
    old "If you think it'll make you feel any safer, why don't we both go tomorrow to the principal's office again?"
    new "Wenn du denkst, dass es dich sicherer fühlen lässt, können wir beide morgen noch mal ins Büro der Schulleiterin gehen."

    # say L2055 pla
    old "That way we can check if everything will be in order."
    new "Dann können wir überprüfen, ob alles in Ordnung ist."

    # say L2058 mia
    old "Ok, let's do as you say."
    new "Ok, wie Sie sagen."

    # say L2059 pla
    old "Great, then I'll see you tomorrow."
    new "Super, dann sehen wir uns morgen."

    # say L2068 mia
    old "I don't know what you did, but thank you."
    new "Ich weiß nicht, was Sie getan haben, aber danke."

    # say L2094 pla
    old "Oh, Belle, hi!"
    new "Oh, Belle, hallo!"

    # say L2095 pla
    old "What are you doing here so early?"
    new "Was machst du hier so früh?"

    # say L2097 bel
    old "Hi [pla] good morning."
    new "Hi [pla], guten Morgen."

    # say L2098 bel
    old "I just came because Miss Lucy asked me, I'm helping her with a group project."
    new "Ich bin nur hier, weil Miss Lucy mich gebeten hat, ich helfe ihr bei einem Gruppenprojekt."

    # say L2099 pla
    old "Miss Lucy? Who's that? Like a new teacher?"
    new "Miss Lucy? Wer ist das? Eine neue Lehrerin?"

    # say L2100 bel
    old "What? Are you messing with me? Of course, you know Ms Lucy, our teacher."
    new "Was? Spinnst du? Natürlich kennst du Ms Lucy, unsere Lehrerin."

    # say L2101 pla
    old "Who?!"
    new "Wer?!"

    # say L2103 bel
    old "I mean, I know you two don't like each other [pla] but this is a little childish for you."
    new "Ich meine, ich weiß, dass ihr beide euch nicht leiden könnt [pla] aber das ist jetzt echt kindisch von dir."

    # say L2104 pla
    old "What? I really don't know who she is!"
    new "Was? Ich hab echt keine Ahnung, wer sie ist!"

    # say L2105 pla
    old "I have no idea what you're talking about."
    new "Ich hab echt keine Ahnung, wovon du redest."

    # say L2115 luc
    old "Hi Belle, how are you today sweetheart?"
    new "Hi Belle, wie geht es dir heute Schatz?"

    # say L2117 luc
    old "Hmph, what are you doing here so early [pla]? I hope you're not planning anything stupid."
    new "Hmpf, was machst du hier so früh [pla]? Ich hoffe, du planst nichts Dummes."

    # say L2118 luc
    old "I also hope you won't corrupt Belle, your are bad influence!"
    new "Ich hoffe auch, dass du Belle nicht verderben wirst, du bist ein schlechter Einfluss!"

    # say L2120 luc
    old "And you Belle, you need better friends."
    new "Und du Belle, du brauchst bessere Freunde."

    # say L2122 pla
    old "... (What the fuck?)"
    new "Was zum Teufel?"

    # say L2123 luc
    old "Well, see you later in class. Belle, come with me."
    new "Na, dann sehen wir uns später im Unterricht. Belle, komm mit mir."

    # say L2124 bel
    old "Sorry [pla], see you later!"
    new "Tut mir leid [pla], bis später!"

    # say L2133 pla
    old "What te fuck? What is happening?"
    new "Was zur Hölle? Was geht hier ab?"

    # say L2140 mia
    old "[pla]! What the hell did you do?!"
    new "[pla]! Was zum Teufel haben Sie getan?!"

    # say L2142 pla
    old "I mean, as I said, I thought I had fixed the issue. Did Denzel contact you again?"
    new "Ich meine, wie ich schon sagte, ich dachte, ich hätte das Problem gelöst. Hat Denzel dich wieder kontaktiert?"

    # say L2143 mia
    old "No! Not that."
    new "Nein! Nicht das."

    # say L2144 mia
    old "Nobody remembers who I am!"
    new "Niemand erinnert sich daran, wer ich bin!"

    # say L2147 mia
    old "That's right! When I woke up I wasn't in any of the pictures on my wall!"
    new "Das stimmt! Als ich aufgewacht bin, war ich nicht auf einem der Fotos an meiner Wand!"

    # say L2148 mia
    old "Even the doorman here didn't want to let me in! He asked if I was someone's parent!"
    new "Selbst der Portier hier wollte mich nicht reinlassen! Er hat gefragt, ob ich die Eltern von jemandem bin!"

    # say L2149 mia
    old "There's even another teacher giving my class! I already looked at the lists, I don't appear in any of them!"
    new "Es gibt sogar eine andere Lehrerin, die meinen Kurs gibt! Ich habe schon die Listen überprüft, ich stehe auf keiner davon!"

    # say L2150 mia
    old "It's like if I didn't ever exist, What did you do [pla]? And how did you do it?!"
    new "Es ist, als hätte ich nie existiert. Was haben Sie [pla] getan? Und wie haben Sie das geschafft?!"

    # say L2152 pla
    old "What? But that's... that's..."
    new "Was? Aber das ist... das ist..."

    # say L2153 mia
    old "You know what? Denzel didn't ruin my life, but you did!"
    new "Sie wissen was? Denzel hat mein Leben nicht ruiniert, aber Sie haben es getan!"

    # say L2154 mia
    old "I don't know how you did it, but you blew it! I shouldn't have trusted you!"
    new "Ich weiß nicht, wie Sie es gemacht haben, aber Sie haben es vermasselt! Ich hätte Ihnen nicht trauen sollen!"

    # say L2160 pla
    old "What the- "
    new "Was zum-"

    # say L2168 mik
    old "Whoah [pla], Who's that babe?"
    new "Werah [pla], wer ist denn das heiße Girl?"

    # say L2169 mik
    old "She's super hot!"
    new "Sie ist total heiß!"

    # say L2170 mik
    old "Although she's a little too old for you."
    new "Obwohl sie ein bisschen zu alt für dich ist."

    # say L2171 mik
    old "You dog, did you get a sugar mommy somewhere?"
    new "Du Schlawiner, hast du dir etwa eine Zucker-Mama angelacht?"

    # say L2173 pla
    old "Don't you know who she is? That's Ms. Mia, our history teacher!"
    new "Kennst du sie etwa nicht? Das ist Ms. Mia, unsere Geschichtslehrerin!"

    # say L2174 mik
    old "Well, I had never seen her before."
    new "Na, ich hatte sie noch nie gesehen."

    # say L2175 mik
    old "But if that babe's gonna be our teacher I wouldn't mind paying a little more attention in class."
    new "Aber wenn die Babe unsere Lehrerin wird, würde ich nichts dagegen haben, ein bisschen mehr aufzupassen."

    # say L2176 mik
    old "She's looks super hot, like a pornstar!"
    new "Sie sieht super heiß aus, wie eine Pornostar!"

    # say L2184 pla
    old "Linett, what the hell happened?! The spell went wrong!"
    new "Linett, was zur Hölle ist passiert?! Der Spruch ist schiefgelaufen!"

    # say L2185 lin
    old "What? Did that guy appear again?"
    new "Was? Ist dieser Typ wieder aufgetaucht?"

    # say L2186 pla
    old "No! That's not it! He doesn't remember her!"
    new "Nein! Das ist es nicht! Er erinnert sich nicht an sie!"

    # say L2188 lin
    old "Then what's the problem?"
    new "Dann was ist das Problem?"

    # say L2189 pla
    old "That no one does! Not a single person knows who she is!"
    new "Dass niemand das tut! Nicht eine einzige Person weiß, wer sie ist!"

    # say L2190 lin
    old "Well... yeah."
    new "Na ja... genau."

    # say L2192 pla
    old "What? What do you mean..."
    new "Was? Was meinst du damit..."

    # say L2193 lin
    old "I told you, didn't I? 'Every trace of her presence will be gone.' All of it [pla]."
    new "Ich hab's dir doch gesagt, oder? „Jede Spur ihrer Anwesenheit wird verschwinden.“ Alles davon [pla]."

    # say L2196 pla
    old "Wait, this can't happen, we need to revert this, how do we do it?"
    new "Warte, das kann doch nicht sein, wir müssen das rückgängig machen, wie machen wir das?"

    # say L2197 lin
    old "I don't know, I don't even think it's possible."
    new "Ich hab keine Ahnung, ich glaube nicht mal, dass es möglich ist."

    # say L2198 pla
    old "Holly shit..."
    new "Holly Scheiße..."

    # say L2214 pla
    old "Eh... What's happening?"
    new "Eh... Was passiert hier?"

    # say L2221 pla
    old "Where am I? Who are you?"
    new "Wo bin ich? Wer bist du?"

    # say L2222 pla2
    old "What the fuck? Who are you? And what are you doing in my bedroom?"
    new "Was zur Hölle? Wer bist du? Und was machst du in meinem Schlafzimmer?"

    # say L2228 lin
    old "[pla], listen things are alot worse than I thought."
    new "[pla], hör zu, die Dinge sind viel schlimmer, als ich dachte."

    # say L2229 pla2
    old "Who the hell are you?!"
    new "Wer zur Hölle bist du?!"

    # say L2230 pla2
    old "And why are you naked?"
    new "Und warum bist du nackt?"

    # say L2231 lin
    old "Nevermind that... Listen [pla] the tear between realities that we oppenned with our spell was a lot bigger than I thought it would be."
    new "Vergiss das... Hör zu [pla] der Riss zwischen den Realitäten, den wir mit unserem Zauber geöffnet haben, war viel größer, als ich dachte."

    # say L2232 pla
    old "What? So? What does that mean?"
    new "Was? Und? Was bedeutet das?"

    # say L2233 lin
    old "It means that both realities are about to collapse on each other!"
    new "Das bedeutet, dass beide Realitäten sich gleich gegenseitig verschlucken werden!"

    # say L2235 pla
    old "Collapse? You mean like everything will be destroyed?"
    new "Einklappen? Meinst du, alles wird zerstört werden?"

    # say L2237 lin
    old "No, fortunately I was able to find the disturbance early, I think I can fix it."
    new "Nein, zum Glück konnte ich die Störung früh genug finden, ich denke, ich kann sie beheben."

    # say L2238 lin
    old "And I'll do that right now."
    new "Und ich werde das jetzt sofort machen."

    # say L2239 lin
    old "I'm just not sure if I'll make it on time, but I have to try..."
    new "Ich bin mir nur nicht sicher, ob ich es rechtzeitig schaffe, aber ich muss es versuchen..."

    # say L2240 pla2
    old "Wow, this is a very trippy dream."
    new "Wow, das ist ein sehr surrealer Traum."

    # say L2249 pla
    old "Where I am? What is this???"
    new "Wo bin ich? Was ist das???"

    # say L2253 pla
    old "Is he the guy I saw a few moments ago?"
    new "Ist das der Typ, den ich vorhin gesehen habe?"

    # say L2257 pla
    old "Is this a Dream or I'm going crazy?"
    new "Ist das ein Traum oder werde ich verrückt?"

    # say L2261 pla
    old "Oh God, this is making me dizzy..."
    new "Oh Gott, das dreht mir den Kopf."

    # say L2278 pla
    old "What the fuck was that? Was it all a dream?"
    new "Was zur Hölle war das? War es alles ein Traum?"

    # say L2292 mia
    old "All right class, it's time to start."
    new "Alles klar, Klasse, es ist Zeit anzufangen."

    # say L2293 mia
    old "Today we'll start a new subject, so, take out your textbooks and open them in the next chapter."
    new "Heute beginnen wir ein neues Thema, also, holt eure Schulbücher raus und schlagt das nächste Kapitel auf."

    # say L2294 mia
    old "This will also be at the end of term test, so be sure to take good notes."
    new "Das wird auch im Abschlussetest vorkommen, also macht euch bitte gute Notizen."

    # say L2298 mia
    old "Please read the first page of the chapter."
    new "Bitte lesen Sie die erste Seite des Kapitels."


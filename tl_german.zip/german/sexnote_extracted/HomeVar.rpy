# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/HomeVar.rpy
translate german strings:

    # say L116 sis
    old "What do you want? I'm busy with the website..."
    new "Was willst du? Ich bin mit der Website beschäftigt..."

    # say L117 pla
    old "Do you need some help?"
    new "Willst du Hilfe?"

    # say L118 sis
    old "No, I need to be alone..."
    new "Nein, ich muss allein sein..."

    # say L119 pla
    old "Ok... (What is wrong with her?)"
    new "Okay... (Was ist bloß mit ihr los?)"

    # say L147 pla
    old "Hey [sis], I was thinking about repeat a photoshoot."
    new "Hey [sis], ich hab dran gedacht, das Fotoshooting zu wiederholen."

    # say L148 sis
    old "Do you want to repeat a photoshoot?"
    new "Willst du ein Fotoshooting wiederholen?"

    # say L149 pla
    old "Right, I think it would be useful to have more photos even with the same outfits..."
    new "Stimmt, ich denke, es wäre nützlich, mehr Fotos zu haben, auch mit denselben Outfits..."

    # say L150 sis
    old "Alright, you are the nerd here."
    new "Okay, du bist hier der Nerd."

    # say L151 sis
    old "Which photoshoot should we repeat?"
    new "Welches Fotoshooting sollen wir wiederholen?"

    # menu L154 
    old "The first one"
    new "Die erste"

    # say L155 sis
    old "Good choice..."
    new "Gute Wahl..."

    # menu L161 
    old "The second one"
    new "Die zweite"

    # say L162 sis
    old "Hmm I really like that one..."
    new "Hmm, ich mag den wirklich..."

    # menu L167 
    old "The third one"
    new "Der dritte"

    # say L168 sis
    old "Great, let's go to the pool..."
    new "Super, dann gehen wir zum Pool..."

    # menu L174 
    old "The fourth one"
    new "Der vierte"

    # say L175 sis
    old "Oh, I love this photoshoot..."
    new "Oh, ich liebe dieses Fotoshooting..."

    # say L190 sis
    old "Are you ready to work on the website?"
    new "Bist du bereit, an der Website zu arbeiten?"

    # say L191 pla
    old "Yeah, I think so."
    new "Ja, ich denke schon."

    # say L192 sis
    old "So, what are we waiting for? Let's work!"
    new "Was warten wir dann noch? Lass uns anfangen!"

    # say L215 sis
    old "Mmm, what do we have here?"
    new "Mmm, was haben wir denn hier?"

    # say L216 pla
    old "(Gulp) Well..."
    new "(Gulp) Na ja..."

    # say L217 sis
    old "I already know... You want my help, right?"
    new "Ich weiß es schon... Du willst meine Hilfe, oder?"

    # say L219 sis
    old "With all my pleasure! Hehe."
    new "Mit größtem Vergnügen! Hehe."

    # say L253 sis
    old "Glad that you came, quite on time for applying the sunscreen, would you help me again?"
    new "Schön, dass du gekommen bist, gerade noch rechtzeitig für die Sonnencreme, würdest du mir wieder helfen?"

    # say L257 pla
    old "Hmm, Sure."
    new "Hmm, klar."

    # say L260 pla
    old "I can't right now..."
    new "Ich kann gerade nicht..."

    # say L261 sis
    old "Oh, it's a shame, I was expecting a new skin care therapy..."
    new "Oh, das ist schade, ich hatte auf eine neue Gesichtspflege gehofft..."

    # say L263 sis
    old "Alright, I will be here taking a sunbath if you change your mind..."
    new "Okay, ich werde hier in der Sonne liegen, wenn du deine Meinung änderst..."

    # say L274 sis
    old "Great, I wanted to have some fun today..."
    new "Super, ich wollte heute ein bisschen Spaß haben..."

    # say L285 sis
    old "So, what do you want to do today?"
    new "Also, was willst du heute machen?"

    # say L289 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your boobs..."
    new "Hmm, ich denke, es wäre toll, wenn wir beim nächsten Fotoshooting auf deine Titten fokussieren..."

    # say L290 sis
    old "I like that too... Al right, let's do it..."
    new "Mir gefällt das auch... Okay, machen wir es so..."

    # say L302 sis
    old "Ready to fuck them?"
    new "Bereit, sie zu ficken?"

    # say L320 sis
    old "Uhhh, that's it. I love how much it is, let me spread it all over, I am ready to take a sunbath."
    new "Uhhh, das ist es. Ich liebe, wie viel es ist, lass mich es überall verteilen, ich bin bereit, eine Sonnenbräune zu bekommen."

    # say L321 sis
    old "Thanks for your help again, [pla]"
    new "Danke für deine Hilfe, [pla]"

    # say L322 pla
    old "You are welcome, always trying to help."
    new "Gern geschehen, ich bin immer bereit zu helfen."

    # say L323 sis
    old "Hahaha Sure."
    new "Hahaha Klar."

    # menu L333 
    old "Ass"
    new "Arsch"

    # say L334 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your ass..."
    new "Hmm ich denke, es wäre toll für das nächste Fotoshooting, uns auf deinen Hintern zu konzentrieren..."

    # say L335 sis
    old "Oh yeah, let's focus on my ass..."
    new "Oh ja, lass uns auf meinen Arsch fokussieren..."

    # say L342 sis
    old "You can touch all you want! I love it."
    new "Du kannst mich anfassen, so viel du willst! Ich liebe es."

    # say L349 sis
    old "Alright, now let's fuck!"
    new "Na los, jetzt ficken wir!"

    # say L369 sis
    old "Uhhh, it was delicious..."
    new "Uhhh, es war köstlich..."


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/LydStory.rpy
translate german strings:

    # say L11 ann
    old "I mean mom, online dating?!! What the fuck?!!!"
    new "Ich meine, Mom, Online-Verabredungen?!!! Was soll das denn?!!!"

    # say L12 ann
    old "You couldn't think about anything else?"
    new "Konntest du dir nichts Besseres überlegen?"

    # say L13 ann
    old "Why don't you just join a knitting group? Or play bingo like any other widow?"
    new "Warum gehst du nicht in einen Strickclub? Oder spielst Bingo wie jede andere Witwe?"

    # say L14 lyd
    old "What's so bad about what I said?"
    new "Was ist denn so schlimm an dem, was ich gesagt habe?"

    # say L15 lyd
    old "I don't think there's anything wrong with a single woman thinking about meeting new people."
    new "Ich finde nichts dabei, wenn eine alleinstehende Frau daran denkt, neue Leute kennenzulernen."

    # say L16 lyd
    old "Now that your father's not here I'd like to make some new friends, and..."
    new "Jetzt, wo dein Vater nicht mehr da ist, würde ich gerne neue Freunde kennenlernen, und..."

    # say L17 ann
    old "Do you think you're at the age where you should be meeting people through a dating app?"
    new "Glaubst du, du bist im richtigen Alter, um Leute durch eine Dating-App kennenzulernen?"

    # say L18 ann
    old "Besides, who the hell is going to talk to you? To a widowed grandmother?"
    new "Außerdem, wer zum Teufel wird schon mit dir reden? Eine verwitwete Großmutter?"

    # say L19 ann
    old "If you want to meet new people why don't you just go to an elderly home?"
    new "Wenn du neue Leute kennenlernen willst, warum gehst du nicht einfach in ein Altenheim?"

    # say L20 ann
    old "Maybe there you'll find some people your age."
    new "Vielleicht findest du da Leute in deinem Alter."

    # say L21 lyd
    old "It's that way to talk to your mother?"
    new "So redest du mit deiner Mutter?"

    # say L22 lyd
    old "Are you listening to yourself?"
    new "Hörst du dich eigentlich selbst reden?"

    # say L23 ann
    old "I don't care!"
    new "Mir egal!"

    # say L24 ann
    old "You should be the one thinking about what you're saying! Dad's not even been dead for a year!"
    new "Du solltest dir mal überlegen, was du da sagst! Papa ist noch nicht einmal ein Jahr tot!"

    # say L25 ann
    old "And here you are thinking about picking guys up like you're some... Ugh!"
    new "Und hier denkst du darüber nach, Typen aufzureißen, als wärst du irgend so eine... Igitt!"

    # say L26 ann
    old "I don't want my mother to go around giving herself up to some randoms on the internet."
    new "Ich will nicht, dass meine Mutter sich im Internet irgendwelchen Typen an den Hals wirft."

    # say L27 ann
    old "Listen, you can do what you want, but don't expect me to help you with anything..."
    new "Hör zu, du kannst machen, was du willst, aber erwarte nicht, dass ich dir dabei helfe..."

    # say L28 ann
    old "Ugh! I don't even want to keep talking to you!"
    new "Ugh! Ich will gar nicht mehr mit dir reden!"

    # say L42 pla
    old "Uh, hi..."
    new "Uh, hallo..."

    # say L43 lyd
    old "[pla]! H- hi!"
    new "[pla]! H- hallo!"

    # say L44 lyd
    old "I hope you didn't see much of what just happened..."
    new "Ich hoffe, du hast nicht viel von dem gesehen, was gerade passiert ist..."

    # say L46 pla
    old "Uhhh... Just the last bit of it, I think..."
    new "Uhhh... Nur den letzten Teil, glaube ich..."

    # say L47 pla
    old "All I heard was Anna being as annoying as always."
    new "Alles, was ich gehört hab, war Anna, die wie immer nervt."

    # say L48 pla
    old "What's the matter? Why is she acting up now?"
    new "Was ist los? Warum macht sie jetzt so ein Theater?"

    # say L50 lyd
    old "Well... How can I put it?"
    new "Na ja... Wie soll ich es sagen?"

    # say L51 lyd
    old "Do you remember the other day when you went with me to church?"
    new "Erinnerst du dich an den Tag, als wir zusammen in die Kirche gegangen sind?"

    # say L52 pla
    old "Hmmm, yeah."
    new "Hmmm, ja."

    # say L53 lyd
    old "The thing is, ever since we ran into Mrs. Jones, I've been thinking and..."
    new "Das Ding ist, seitdem wir Mrs. Jones getroffen haben, denke ich darüber nach und..."

    # say L54 lyd
    old "I don't want to be like that [pla]. Her husband died five years ago, and she's been unable to move on from that."
    new "Ich will nicht so werden wie sie [pla]. Ihr Mann ist vor fünf Jahren gestorben, und sie kann einfach nicht darüber hinwegkommen."

    # say L55 pla
    old "She hasn't moved on? What do you mean?"
    new "Sie hat sich nicht weiterentwickelt? Was meinst du damit?"

    # say L56 lyd
    old "You know, all she ever does is talk about God and faith. Frankly, it's pitying."
    new "Du weißt schon, sie redet ständig von Gott und Glauben. Ehrlich gesagt, das finde ich echt bedauernswert."

    # say L57 lyd
    old "I decided I don't want that to happen to me too."
    new "Ich hab beschlossen, dass ich das nicht auch passieren lassen will."

    # say L60 lyd
    old "So, I've been trying to get myself out there, I've gone to a couple of bars, and clubs."
    new "Also, ich hab versucht, mich da rauszuknipsen, bin ein paarmal in Bars und Clubs gegangen."

    # say L61 lyd
    old "Trying to meet new people, you know?"
    new "Versuche, neue Leute kennenzulernen, weißt du?"

    # say L62 lyd
    old "But, it's been to no avail. It turns out people don't really go to bars or clubs to meet new people anymore."
    new "Aber, es war umsonst. Es stellt sich heraus, dass die Leute heute nicht mehr in Bars oder Clubs hingehen, um neue Leute kennenzulernen."

    # say L64 lyd
    old "It's not as common to go out to meet new people. Nowadays, if someone goes out it's because they already have plans with someone else."
    new "Es ist nicht mehr so üblich, ausgehen, um neue Leute kennenzulernen. Heutzutage geht man eher aus, wenn man schon etwas vorhat."

    # say L65 lyd
    old "So, I thought maybe I should do what I heard young people are doing these days, and try online dating."
    new "Dann dachte ich, vielleicht sollte ich das machen, was ich gehört habe, dass junge Leute heutzutage machen, und Online-Dating ausprobieren."

    # say L66 pla
    old "Well, that sounds like a good idea."
    new "Na, das klingt wie eine gute Idee."

    # say L68 lyd
    old "I guess so, but the whole internet thing just flies over my head. It's so complicated."
    new "Ich schätze schon, aber das ganze Internetzeug geht mir über den Kopf. Es ist so kompliziert."

    # say L69 lyd
    old "Given that I can't really do it myself I asked Anna to help me out."
    new "Da ich es selbst nicht kann, hab ich Anna gefragt, ob sie mir hilft."

    # say L70 lyd
    old "But, you already saw how that turned out."
    new "Aber, du hast ja schon gesehen, wie das ausgegangen ist."

    # say L71 pla
    old "Hmph, I did..."
    new "Hmph, ich hab's ja gesehen..."

    # say L72 lyd
    old "Although maybe she's right. Maybe I'm just too old to be thinking about doing things like online dating and such."
    new "Vielleicht hat sie recht. Vielleicht bin ich einfach zu alt, um an so was wie Online-Verabredungen zu denken."

    # say L73 lyd
    old "I'm just an old, lonely widow after all... So I'll just give up."
    new "Ich bin schließlich nur eine alte, einsame Witwe... Also werde ich einfach aufgeben."

    # say L74 pla
    old "Woah, woah, wait a minute."
    new "Woah, woah, warte mal."

    # say L75 pla
    old "Listen, you don't have to say all those bad things about you, and you also shouldn't say that you're going to give up."
    new "Hör zu, du musst nicht all diese schlechten Dinge über dich sagen und du darfst auch nicht aufgeben."

    # say L76 pla
    old "I actually agree with you, you have every right to live your life any way you want to."
    new "Ich stimme dir zu, du hast das Recht, dein Leben so zu leben, wie du willst."

    # say L77 pla
    old "Anna's just jealous because you're her mother. And she's always very possessive."
    new "Anna ist einfach eifersüchtig, weil du ihre Mutter bist. Und sie ist immer sehr besitzergreifend."

    # say L78 pla
    old "But you're free to do whatever you want. And I'm totally sure you can be with anyone you want to."
    new "Aber du bist frei, zu tun, was du willst. Und ich bin mir total sicher, dass du mit jedem sein kannst, den du willst."

    # say L82 pla
    old "Of course I do! Anyone would be lucky to meet you. I'm sure of it."
    new "Natürlich tu ich das! Jeder wäre glücklich, dich kennenzulernen. Da bin ich mir sicher."

    # say L83 pla
    old "In fact, if Anna won't do it. Let me help you, I'll set up your profile for you."
    new "Na klar, wenn Anna es nicht macht. Lass mich dir helfen, ich erstelle dein Profil für dich."

    # say L86 pla
    old "Of course, I'll do it right now."
    new "Natürlich, ich mach das sofort."

    # say L87 lyd
    old "Ohh! That's so nice of you! Thank you [pla]!"
    new "Ohh! Das ist so nett von dir! Danke [pla]!"

    # say L88 lyd
    old "Let's go to my room, my computer's there."
    new "Lass uns in mein Zimmer gehen, mein Computer ist da."

    # say L89 pla
    old "Oh no, there's no need. These days the best and easiest ways to meet people online are dating apps."
    new "Oh nein, da ist kein Grund. Heutzutage sind Dating-Apps die einfachsten und besten Wege, um Leute online kennenzulernen."

    # say L90 pla
    old "You know, on the phone. Have you ever heard of Tinder?"
    new "Du weißt schon, auf dem Handy. Hast du schon mal von Tinder gehört?"

    # say L91 lyd
    old "Tinder? No, no idea what it is."
    new "Tinder? Nein, habe keine Ahnung, was das ist."

    # say L92 pla
    old "Well, it's this new dating app, in which you create a profile with your information on it."
    new "Na ja, es ist eine neue Dating-App, bei der du ein Profil mit deinen Informationen erstellst."

    # say L93 pla
    old "The profile is public, so anyone can see it, and decide if they would like to talk to you or not."
    new "Das Profil ist öffentlich, also kann jeder es sehen und entscheiden, ob er mit dir chattet oder nicht."

    # say L94 lyd
    old "I see, what kind of information should go in there?"
    new "Ich verstehe, welche Art von Informationen sollte man da reindaten?"

    # say L95 pla
    old "Nothing private, just the type of person you are, what you like and dislike."
    new "Nichts Privates, nur der Typ Mensch, der du bist, was du magst und was du nicht magst."

    # say L96 pla
    old "And a couple of pictures of you, so they know how you look."
    new "Und ein paar Fotos von dir, damit sie wissen, wie du aussiehst."

    # say L97 pla
    old "You can also write what you want to find in a partner, so they know if you'll like them."
    new "Du kannst auch schreiben, was du in einem Partner suchst, damit sie wissen, ob ihr zusammenpasst."

    # say L98 lyd
    old "That sounds interesting. How does it work?"
    new "Das klingt interessant. Wie funktioniert das?"

    # say L99 pla
    old "It's very simple, once your profile is on the app it will be visible to people in it."
    new "Es ist ganz einfach, sobald dein Profil auf der App ist, wird es für die Leute in der App sichtbar."

    # say L100 pla
    old "And they get to decide if they would like to meet you."
    new "Und sie können entscheiden, ob sie dich treffen möchten."

    # say L101 pla
    old "If they do, all they have to do is swipe your profile to the right, if they don't they swipe left."
    new "Wenn sie dich mögen, swipen sie nach rechts, wenn nicht, swipen sie nach links."

    # say L102 pla
    old "And it's the same with you, if you see a profile you swipe either right or left, depending on if you like them or not."
    new "Und es ist das Gleiche bei dir, wenn du ein Profil siehst, swipst du entweder rechts oder links, je nachdem, ob du die Person magst oder nicht."

    # say L103 pla
    old "If both of you swipe right, that means it's a match, and you can both start talking."
    new "Wenn ihr beide nach rechts swipet, bedeutet das, dass es ein Match ist, und ihr könnt anfangen zu chatten."

    # say L104 lyd
    old "Hmm, that sounds very simple and practical."
    new "Hmm, das klingt sehr einfach und praktisch."

    # say L105 pla
    old "It is, come on, I'll help you set your profile."
    new "Ist es, komm schon, ich helfe dir bei deinem Profil."

    # say L112 pla
    old "Ok, so, first of all, is setting up your bio, it's just a small description of you and the things you like and your interests."
    new "Okay, also, zuerst ist das Einrichten deines Profils, das ist einfach eine kurze Beschreibung von dir und den Dingen, die du magst und deine Interessen."

    # say L113 lyd
    old "Ok, so let me see, hmm... I got it!"
    new "Ok, lass mich mal sehen, hmm... Ich hab's!"

    # say L114 lyd
    old "I'm a single woman who enjoys the simple things in life. I love long walks, enjoying nature and talking."
    new "Ich bin eine Single-Frau, die die einfachen Dinge im Leben genießt. Lange Spaziergänge, die Natur und gute Gespräche machen mich glücklich."

    # say L115 lyd
    old "My perfect evening is a summer afternoon enjoying a glass of merlot and reading a good book."
    new "Mein perfekter Abend ist ein Sommernachmittag mit einem Glas Merlot und einem guten Buch."

    # say L124 pla
    old "Ok, so that's your profile all set."
    new "Ok, dann ist dein Profil fertig gestellt."

    # say L125 lyd
    old "Oh wow, that took no time, and it looks great!"
    new "Oh wow, das hat ja gar nicht lange gedauert, und es sieht toll aus!"

    # say L127 lyd
    old "So? What do I do now?"
    new "Und? Was mache ich jetzt?"

    # say L128 pla
    old "Well, now that you have your own profile, what you have to do is look at other people's profiles."
    new "Na ja, jetzt, wo du deinen eigenen Profil hast, musst du dir die Profile anderer Leute anschauen."

    # say L129 pla
    old "And see if you like any of them. You do this by swiping right or left..."
    new "Und guck, ob dir jemand gefällt. Das machst du, indem du nach rechts oder links wischst..."

    # say L130 lyd
    old "Woah, woah, that's a little too fast for me, and it sounds a bit complicated."
    new "Wow, wow, das geht mir ein bisschen zu schnell, und es klingt ziemlich kompliziert."

    # say L131 lyd
    old "Hmm, why don't you do it for me?"
    new "Hmm, warum machst du es nicht für mich?"

    # say L133 pla
    old "Hmm... ok sure, no problem, it's not hard, once you get it, it will be really easy."
    new "Hmm... okay, klar, kein Problem, es ist nicht schwer, wenn du es erst mal drauf hast, wird es echt einfach."

    # say L134 pla
    old "Alright, let's start, but, if I'm the one doing it, I won't know what kind of guy you're into."
    new "Okay, lass uns anfangen, aber wenn ich es mache, weiß ich nicht, welcher Typ Mann dir gefällt."

    # say L135 pla
    old "Why don't you tell me what you're looking for in a man?"
    new "Warum erzählst du mir nicht, was du an einem Mann suchst?"

    # say L136 pla
    old "That way I'll know who to select."
    new "Dann weiß ich, wen ich auswählen soll."

    # say L137 lyd
    old "What I'm looking for? Hmm, let's see..."
    new "Was ich suche? Hmm, lass mich überlegen..."

    # say L138 lyd
    old "Well, I tend to like guys with beards, I think they look very manly, but it's not a requirement."
    new "Na ja, ich mag Typen mit Bart, finde ich, sie sehen sehr maskulin aus, aber das ist kein Muss."

    # say L139 pla
    old "Hmm, ok, I'll keep that in mind."
    new "Hmm, ok, ich werd's mir merken."

    # say L140 lyd
    old "But, be sure that it's a beard, not a mustache, I hate mustaches."
    new "Aber, stell sicher, dass es ein Bart ist und kein Schnurrbart, ich hasse Schnurrbärte."

    # say L141 lyd
    old "My husband used to have one and I was never able to get him to shave it."
    new "Mein Mann hatte früher einen und ich konnte ihn nie dazu bringen, ihn abzurasieren."

    # say L142 pla
    old "Sure, that's an important detail."
    new "Klar, das ist ein wichtiges Detail."

    # say L143 pla
    old "Anything else?"
    new "Ist noch was?"

    # say L145 lyd
    old "I don't like bald men, I prefer a nice head of hair, but no white hair, not even at the sides."
    new "Ich mag keine kahlen Männer, ich bevorzuge eine schöne Mähne, aber keine grauen Haare, auch nicht an den Seiten."

    # say L146 pla
    old "Alright, no bald men or white hair."
    new "Okay, keine kahlen Männer oder graue Haare."

    # say L147 lyd
    old "Well, to be honest, I'm looking for a young guy, so I'd rather he didn't look old, like wrinkles and stuff..."
    new "Ehrlich gesagt, suche ich nach einem jungen Kerl, also lieber ohne Falten und so..."

    # say L148 pla
    old "Got it. Something else?"
    new "Verstanden. Was noch?"

    # say L149 lyd
    old "Oh right, I don't know why but I have never been into gingers... So, no red hair, nothing personal..."
    new "Oh stimmt, keine Ahnung warum, aber ich stehe einfach nicht auf Rothaarige... Also, keine roten Haare, nichts für ungut..."

    # say L150 pla
    old "Hmm, Ok, I think I got everything. I'll try my best to find you someone like that."
    new "Hmm, ok, ich denke, ich hab alles. Ich werd mein Bestes tun, um dir jemanden wie den zu finden."

    # say L152 lyd
    old "Woah, thank you pumpkin, this is exciting!"
    new "Wow, danke Schatz, das ist aufregend!"

    # say L167 pla
    old "Ok Lydia, here you go, I think I got just what you wanted."
    new "Ok Lydia, hier ist es, ich denke, ich habe genau das, was du wolltest."

    # say L168 pla
    old "And look at that, you already matched with a couple of them!"
    new "Und sieh mal an, du hast dich schon mit ein paar von ihnen verpaart!"

    # say L169 pla
    old "If you want to you can start talking with them."
    new "Wenn du willst, kannst du mit ihnen anfangen zu reden."

    # say L170 lyd
    old "That's wonderful pumpkin!"
    new "Das ist wunderbar, Schatz!"

    # say L171 lyd
    old "Oh, they all look very interesting indeed!"
    new "Oh, sie sehen alle sehr interessant aus!"

    # say L172 lyd
    old "This is great, I'll start talking to them."
    new "Das ist toll, ich fange gleich an, mit ihnen zu reden."

    # say L173 pla
    old "I'm glad you think they're good picks."
    new "Ich freue mich, dass dir die Auswahl gefällt."

    # say L174 lyd
    old "I do, they look great."
    new "Ich finde, sie sehen toll aus."

    # say L175 lyd
    old "Now listen [pla], I'm very happy and thankful that you're helping me with this."
    new "Jetzt hör zu [pla], ich bin sehr glücklich und dankbar, dass du mir dabei hilfst."

    # say L176 lyd
    old "But, Anna might come back soon, and I fear what she'll say if she sees us doing this."
    new "Aber, Anna könnte bald zurückkommen, und ich fürchte, was sie sagen wird, wenn sie uns dabei sieht."

    # say L177 lyd
    old "I think it would be better if you leave before she comes back."
    new "Ich denke, es wäre besser, wenn du gehst, bevor sie zurückkommt."

    # say L181 pla
    old "Oh, sure, you're right! I'd forgotten about Anna."
    new "Oh, klar, du hast recht! Ich hatte Anna vergessen."

    # say L182 pla
    old "I'll come back later to see how it went with the guys, ok?"
    new "Ich komme später wieder, um zu sehen, wie es mit den Jungs gelaufen ist, okay?"

    # say L184 lyd
    old "Sure, but please come in the afternoon, when Anna is usually out."
    new "Klar, aber komm bitte am Nachmittag, wenn Anna normalerweise nicht da ist."

    # say L185 pla
    old "Alright, I will come in the afternoon."
    new "Okay, ich komme dann am Nachmittag."

    # say L186 lyd
    old "Thank you so much pumpkin, I really appreciate your help."
    new "Danke dir so sehr, Kürbisch, ich schätze deine Hilfe wirklich."

    # say L187 pla
    old "No biggie, I'm happy to help, bye!"
    new "Kein Problem, ich freu mich, zu helfen, tschüss!"

    # say L203 pla
    old "Damn, I think I didn't do a good job with this Lydia, sorry."
    new "Verdammt, ich glaube, ich hab das nicht gut gemacht, Lydia, sorry."

    # say L204 lyd
    old "Really? Did the phone fail?"
    new "Wirklich? Hat das Handy versagt?"

    # say L205 pla
    old "No, no, it's just that I think I selected some profiles wrong. So you may not like them too much."
    new "Nein, nein, es ist nur, dass ich glaube, ich habe ein paar Profile falsch ausgewählt. Also werden sie dir vielleicht nicht so gefallen."

    # say L206 lyd
    old "Aw, that's ok, you don't need to stress too much about it."
    new "Ach, das ist okay, du musst dich deswegen nicht zu sehr aufregen."

    # say L207 lyd
    old "We're both learning about this kind of thing. It's ok, really."
    new "Wir lernen beide noch dran. Ist schon okay, ehrlich."

    # say L208 pla
    old "Thanks... Well, I think there's still a couple of matches, so you may talk to a couple of them, if you want to of course."
    new "Danke... Also, ich glaube, es gibt noch ein paar Matches, du kannst mit ein paar von ihnen reden, wenn du willst."

    # say L209 lyd
    old "I'll do it, maybe they're not that bad. But for now, I think it would be better if you left."
    new "Ich mach's, vielleicht sind sie ja gar nicht so schlecht. Aber im Moment wäre es besser, wenn du gehst."

    # say L210 lyd
    old "Anna has been out for a little while now, so she could come back at any moment."
    new "Anna ist schon eine Weile weg, sie könnte also jeden Moment zurückkommen."

    # say L211 lyd
    old "I don't even know what she would say if she finds out about this."
    new "Ich habe keine Ahnung, was sie sagen würde, wenn sie davon erfährt."

    # say L212 lyd
    old "I don't want any more trouble with her. So it's best if you leave."
    new "Ich will keine weiteren Probleme mit ihr. Also ist es besser, wenn du jetzt gehst."

    # say L214 pla
    old "Yeah, you're right. I'll come back later to help again, bye Lydia."
    new "Ja, du hast recht. Ich komme später wieder, um zu helfen, tschüss Lydia."

    # say L235 lyd
    old "Hi pumpkin! How are you?"
    new "Hi Kürbiskopf! Wie geht's dir?"

    # say L237 pla
    old "Hey, it's Anna around?"
    new "Hey, ist Anna da?"

    # say L238 lyd
    old "She isn't, why?"
    new "Sie ist nicht da, warum?"

    # say L243 pla
    old "Well, I thought I could help you again with the app."
    new "Na, ich dachte, ich könnte dir wieder mit der App helfen."

    # say L244 pla
    old "How has it been going since the last time? Have you talked to anybody?"
    new "Wie läuft es seit dem letzten Mal? Hast du mit jemandem gesprochen?"

    # say L245 lyd
    old "Oh, not really, I've had a couple of conversations with some people, but nothing interesting."
    new "Oh, nicht wirklich, ich habe ein paar Gespräche geführt, aber nichts Interessantes."

    # say L248 pla
    old "Well, that's why I'm here, to help you out. So let's see the app."
    new "Dann bin ich ja genau richtig gekommen, um dir zu helfen. Lass uns mal die App anschauen."

    # say L262 pla
    old "Ok, here you go, I think I got just what you wanted."
    new "Ok, hier ist es, ich denke, das ist genau, was du wolltest."

    # say L270 pla
    old "With that done, I think it's better if I leave."
    new "Dann lass ich dich mal besser allein."

    # say L272 pla
    old "We wouldn't want Anna to get here and catch us."
    new "Wir wollen doch nicht, dass Anna uns hier erwischt."

    # say L273 lyd
    old "Sure, thanks again [pla], I really appreciate your help."
    new "Klar, danke nochmal [pla], ich schätze deine Hilfe echt."

    # say L319 lyd
    old "Hmm, I guess that's ok, you don't need to stress too much about it."
    new "Hmm, ich denke das ist okay, du musst dich deswegen nicht zu sehr stressen."

    # say L321 pla
    old "Thanks... Well, I think there's still a couple of them you could talk to if you want to of course."
    new "Danke... Na ja, ich denke, es gibt immer noch ein paar, mit denen du sprechen könntest, wenn du willst."

    # say L347 pla
    old "Hi Lydia, how are you?"
    new "Hi Lydia, wie geht's dir?"

    # say L348 lyd
    old "Hmm, hello [pla] I'm ok, I guess..."
    new "Hmm, hallo [pla], ich bin okay, schätze ich..."

    # say L349 pla
    old "What? Did something happen? Why do you look so sad?"
    new "Was? Ist was passiert? Warum siehst du so traurig aus?"

    # say L350 lyd
    old "Well... the thing is..."
    new "Na ja... die Sache ist die..."

    # say L351 lyd
    old "Ugh, I've been talking with a couple of men on tinder, and..."
    new "Ugh, ich habe mit ein paar Männern auf Tinder geredet, und..."

    # say L352 pla
    old "Oh, did I make a mistake choosing their profiles? Is there something wrong with them?"
    new "Oh, hab ich einen Fehler gemacht, ihre Profile auszuwählen? Gibt es etwas an ihnen, das dir nicht gefällt?"

    # say L354 lyd
    old "Hmm, their perfectly nice gentlemen, very smart and all."
    new "Hmm, sie sind perfekt nette Herren, sehr klug und so."

    # say L355 lyd
    old "But, they're very old! As old as my ex husband was! And I don't want that!"
    new "Aber, sie sind sehr alt! So alt wie mein Ex-Mann! Und das will ich nicht!"

    # say L356 lyd
    old "I mean, I just widowed a man that age."
    new "Ich meine, ich habe erst kürzlich einen Mann in dem Alter verwitwet."

    # say L357 lyd
    old "When I talked about dating again I was thinking more along the lines of young, energetic men, full of vitality... You know?"
    new "Wenn ich von wieder ausgehen gesprochen habe, habe ich eher an junge, energiegeladene Männer gedacht, voller Vitalität... Du weißt schon?"

    # say L359 pla
    old "I- I guess I do."
    new "Ich- Ich schätze schon."

    # say L360 lyd
    old "Why is the app only pairing me with these old guys?"
    new "Warum paart die App mich nur mit diesen alten Typen?"

    # say L361 pla
    old "Uhh, I don't really know why."
    new "Uhh, ich hab echt keine Ahnung warum."

    # say L362 pla
    old "Maybe it's the algorithm putting you with people your age."
    new "Vielleicht ist es der Algorithmus, der dich mit Leuten in deinem Alter matcht."

    # say L363 pla
    old "But, I think there might be something we can do about that."
    new "Aber ich denke, da können wir was dran machen."

    # say L364 lyd
    old "Yeah? What is it?"
    new "Klar? Was genau meinst du damit?"

    # say L365 pla
    old "Well, we could 'fix' your profile. Improve it a little."
    new "Na ja, wir könnten dein Profil 'verbessern'. Ein bisschen aufpolieren."

    # say L366 lyd
    old "What do you mean by 'fix'?"
    new "Was meinst du mit 'fixen'?"

    # say L367 pla
    old "We could, for example, put a better picture of you. Or maybe another description of you in the bio."
    new "Wir könnten zum Beispiel ein besseres Foto von dir hochladen. Oder eine andere Beschreibung in deinem Profil."

    # say L368 pla
    old "Something that will be more attractive to younger men."
    new "Etwas, das für jüngere Männer attraktiver ist."

    # say L370 lyd
    old "That sounds like a great idea!"
    new "Das klingt wie eine tolle Idee!"

    # say L371 pla
    old "Yeah, keeping in mind that those are the things that people will see when they go to your profile."
    new "Klar, mit im Hinterkopf, dass das die Dinge sind, die die Leute sehen, wenn sie auf deinem Profil landen."

    # say L372 pla
    old "We could work on them to get more young people to swipe right instead of left on your profile."
    new "Wir könnten sie so bearbeiten, dass mehr junge Leute rechts und nicht links wischen auf deinem Profil."

    # say L373 lyd
    old "That'd be perfect, let's do it."
    new "Das wäre perfekt, lass uns das machen."

    # say L382 pla
    old "The first thing is the picture, do you have any picture in which you look a little more casual?"
    new "Das Erste ist das Foto, hast du irgendwo ein Foto, auf dem du ein bisschen lässiger aussiehst?"

    # say L383 lyd
    old "I think I do, yeah, there must be a couple of some trips and excursions there in the phone."
    new "Ich denke schon, da müssten ein paar von meinen Trips und Ausflügen drauf sein."

    # say L388 pla
    old "Ok, that's perfect, now for the bio."
    new "Ok, das ist perfekt, jetzt zum Lebenslauf."

    # say L389 pla
    old "I think we could maybe change it for either something more casual or a little bit more... Uhh, seductive."
    new "Ich denke, wir könnten es vielleicht ein bisschen lockerer oder ein bisschen... äh, verführerischer machen."

    # say L390 pla
    old "What do you think?"
    new "Was denkst du?"

    # say L392 lyd
    old "Well, if that helps, I think we should give it a try."
    new "Na gut, wenn das hilft, sollten wir es ausprobieren."

    # say L393 pla
    old "Alright, let me think in something."
    new "Okay, lass mich drüber nachdenken."

    # say L398 pla
    old "Ok, it's ready, what do you think?"
    new "Ok, es ist fertig, was denkst du?"

    # say L399 lyd
    old "It looks great! And I think I get what you were saying, this one definitely sounds and looks a lot more attractive."
    new "Das sieht toll aus! Und ich glaube, ich verstehe, was du meinst. Dieser hier klingt und sieht definitiv viel ansprechender."

    # say L402 pla
    old "I'm glad you like it. I'm sure this time we'll attract some younger men."
    new "Ich freue mich, dass dir das gefällt. Ich bin sicher, dieses Mal werden wir einige jüngere Männer anlocken."

    # say L404 pla
    old "Do you want to try now? I could get on the app and see if you can make a match with some new people."
    new "Willst du es jetzt ausprobieren? Ich könnte mich in die App einloggen und sehen, ob du mit ein paar neuen Leuten matchen kannst."

    # say L405 lyd
    old "Sure, just one little thing pumpkin. What does that GILF thing mean? Is it some kind of world play?"
    new "Klar, nur eine kleine Sache Schatz. Was bedeutet eigentlich dieses GILF? Ist das so eine Art Wortspiel?"

    # say L406 pla
    old "Uhh, t-that... yeah."
    new "Uhh, d-das... ja."

    # say L407 pla
    old "It's actually an acronym."
    new "Es ist eigentlich ein Akronym."

    # say L409 lyd
    old "It is? What does it stand for?"
    new "Ist es? Wofür steht es?"

    # say L410 pla
    old "Hmm, it stands for... Great... I- Intelligent, L- Loving... Friend."
    new "Hmm, es steht für... G- Großartig... I- Intelligenz, L- Liebe... Freund."

    # say L411 pla
    old "It's something that people my age understand, don't worry."
    new "Das ist was, das Leute in meinem Alter verstehen, mach dir keine Sorgen."

    # say L413 lyd
    old "Ohh, I see! That's great! Thank you."
    new "Ohh, ich verstehe! Das ist toll! Danke."

    # say L414 lyd
    old "Well, I guess we can start looking for some profiles now."
    new "Na dann, lass uns mal ein paar Profile anschauen."

    # say L433 lyd
    old "Hi pumpkin!"
    new "Hi Schatz!"

    # say L434 lyd
    old "I'm very fine, thank you."
    new "Mir geht es sehr gut, danke."

    # say L435 pla
    old "Oh yeah? Has anything good happened on tinder?"
    new "Oh ja? Hat sich was Gutes auf Tinder getan?"

    # say L436 lyd
    old "Well, you could say that. Ever since we changed my profile the number of young men talking to me has increased. It's been very exciting."
    new "Naja, man könnte sagen. Seit wir mein Profil geändert haben, hat sich die Anzahl der jungen Männer, die mit mir sprechen, erhöht. Es war sehr aufregend."

    # say L437 pla
    old "That's good to hear. So, it worked! it's what you expected, right?"
    new "Das freut mich zu hören. Also, es hat funktioniert! War das so, wie du es dir vorgestellt hast?"

    # say L438 lyd
    old "Hmm, it kinda is but..."
    new "Hmm, es ist so, aber..."

    # say L439 pla
    old "What? Anything wrong with anyone?"
    new "Was? Irgendwas mit den Leuten, mit denen du sprichst, oder der App?"

    # say L440 lyd
    old "No, nothing wrong per se with the people I'm speaking to or the app."
    new "Nein, nichts stimmt wirklich falsch mit den Leuten, mit denen ich spreche, oder der App."

    # say L442 pla
    old "Then what is it?"
    new "Dann was ist es?"

    # say L444 lyd
    old "Well, it's more to do with their language."
    new "Na ja, es hat mehr mit ihrer Sprache zu tun."

    # say L445 lyd
    old "To be honest I don't understand a lot of what they say. There is this one guy I was talking to."
    new "Ehrlich gesagt, verstehe ich nicht viel von dem, was sie sagen. Da war dieser Typ, mit dem ich gesprochen habe."

    # say L446 lyd
    old "And he suddenly began writing things like, lmao, brb, tbh."
    new "Und er fing plötzlich an, Sachen wie lmao, brb, tbh zu schreiben."

    # say L448 lyd
    old "And when asked him what he meant."
    new "Und als ich ihn fragte, was er damit meint."

    # say L449 lyd
    old "And he answered saying: 'lol, Idk wdym?"
    new "Und er antwortete: 'lol, Idk wdym?"

    # say L450 lyd
    old "What?! What does that even mean?!"
    new "Was?! Was soll das denn heißen?"

    # say L453 lyd
    old "Yeah, how am I even supposed to talk to these people?"
    new "Ja, wie soll ich überhaupt mit diesen Leuten reden?"

    # say L455 lyd
    old "Don't laugh, this isn't funny."
    new "Lach nicht, das ist nicht lustig."

    # say L456 pla
    old "Y-you're right, sorry."
    new "Du hast recht, tut mir leid."

    # say L457 pla
    old "It's just that I wasn't expecting that. But, I get what you mean, I guess young people talk in a confusing way."
    new "Es ist nur, dass ich das nicht erwartet habe. Aber, ich verstehe, was du meinst, denke ich. Junge Leute sprechen manchmal schon komisch."

    # say L458 pla
    old "Don't worry, they're not saying anything weird, they're just abbreviations, so you don't have to write the whole thing."
    new "Mach dir keine Sorgen, sie sagen nichts Seltsames, es sind einfach Abkürzungen, damit man nicht das ganze schreiben muss."

    # say L459 pla
    old "I'll teach you how to use them."
    new "Ich zeig dir, wie du sie benutzt."

    # say L460 lyd
    old "Well, I thank you, but I don't think that's going to do much for me. Because I've got another problem with the app."
    new "Na, danke, aber ich glaube, das wird mir nicht viel helfen. Denn ich hab ein anderes Problem mit der App."

    # say L461 lyd
    old "And is that damned keyboard, it's so small! I have no idea how you can write so fast on those little keyboards; you can't even see them!"
    new "Und dieses verdammte Tastatur, die ist so klein! Ich hab keine Ahnung, wie du auf diesen winzigen Tasten so schnell schreiben kannst; man kann sie ja gar nicht richtig sehen!"

    # say L462 pla
    old "Come on, come on, don't stress too much about it."
    new "Komm schon, komm schon, mach dir nicht so viele Gedanken darum."

    # say L463 pla
    old "Let's just work on it and in no time you'll master them. You'll see."
    new "Lass uns einfach dran arbeiten und im Nu beherrschst du sie. Wirst schon sehen."

    # say L464 lyd
    old "If you say so. I guess I can try to learn..."
    new "Wenn du das sagst. Ich schätze, ich kann es versuchen zu lernen..."

    # say L470 lyd
    old "What a coincidence, this is the guy I was talking with yesterday night."
    new "Was für ein Zufall, das ist der Typ, mit dem ich gestern Abend gesprochen habe."

    # say L471 lyd
    old "I know! Why don't we try speaking to him now? You could write for me!"
    new "Ich weiß! Warum probieren wir's nicht jetzt gleich? Du könntest für mich schreiben!"

    # say L472 pla
    old "Hmm, I don't know, I mean, it's your conversation."
    new "Hmm, ich weiß nicht, ich meine, das ist dein Gespräch."

    # say L473 lyd
    old "Oh please, since you'll actually understand if he uses those abbreviations, and you can use the keyboard."
    new "Oh bitte, du verstehst ja, wenn er Abkürzungen benutzt, und du kannst die Tastatur bedienen."

    # say L474 lyd
    old "Why don't you just tell me what he's saying and I'll tell you what to answer?"
    new "Warum erzählst du mir nicht einfach, was er sagt, und ich sage dir, was du antworten sollst?"

    # say L475 pla
    old "Hahaha, that sounds odd."
    new "Hahaha, das klingt komisch."

    # say L476 pla
    old "But I guess we can try."
    new "Aber ich schätze, wir können es versuchen."

    # say L477 pla
    old "So, you see that it's not that difficult."
    new "Dann siehst du ja, dass es nicht so schwierig ist."

    # say L491 lyd
    old "What did he say?"
    new "Was hat er gesagt?"

    # say L492 pla
    old "He's just saying hello, and asking how you are today."
    new "Er sagt nur Hallo und fragt, wie es dir heute geht."

    # say L493 lyd
    old "Well, don't keep him waiting! Say hello back!"
    new "Na, dann lass ihn nicht warten! Sag hallo zurück!"

    # say L497 lyd
    old "What did he say now?"
    new "Was hat er denn jetzt gesagt?"

    # say L498 pla
    old "He said..."
    new "Er hat gesagt..."

    # say L499 lyd
    old "Here, let me see!"
    new "Hier, lass mich mal sehen!"

    # say L500 lyd
    old "Hmm, 'hbu'? What is that supposed to mean?"
    new "Hmm, „hbu“? Was soll das denn bedeuten?"

    # say L501 pla
    old "It means 'How about you?'"
    new "Das bedeutet „Wie ist es mit dir?“"

    # say L502 lyd
    old "Jesus, and he couldn't write that? How lazy are young people these days?"
    new "Jesus, und der kann das nicht schreiben? Wie faul sind die jungen Leute heute eigentlich?"

    # say L503 pla
    old "It's not about being lazy, just answering fast."
    new "Es geht nicht um Faulheit, sondern darum, schnell zu antworten."

    # say L504 pla
    old "Which by the way, he's waiting for us to answer him."
    new "Übrigens, er wartet darauf, dass wir ihm antworten."

    # say L505 lyd
    old "Oh shoot, right!"
    new "Oh Mist, richtig!"

    # say L506 lyd
    old "Tell him: 'Oh, it's so good that you exercise, that's very good for the joints and muscles."
    new "Sag ihm: 'Oh, das ist ja toll, dass du Sport treibst, das ist sehr gut für die Gelenke und Muskeln."

    # say L507 lyd
    old "Be sure to hydrate and rest properly."
    new "Aber vergiss nicht, dich richtig zu hydratisieren und auszuruhen."

    # say L508 pla
    old "Wait, what?!"
    new "Warte, was?!"

    # say L510 lyd
    old "Now what's so funny?"
    new "Was ist denn jetzt so lustig?"

    # say L511 pla
    old "Hahaha, well, we can't tell him that. You'd sound like a P.E. teacher. You have to be a little more playful."
    new "Hahaha, na ja, das können wir ihm nicht sagen. Du würdest wie ein Sportlehrer klingen. Du musst ein bisschen spielerischer sein."

    # say L513 lyd
    old "Playful?"
    new "Spielhaft?"

    # say L514 pla
    old "Yeah you know, something about how attractive that is to you and stuff."
    new "Ja, du weißt schon, wie anziehend das für dich ist und so."

    # say L515 lyd
    old "I see, well..."
    new "Ich sehe, na ja..."

    # say L516 lyd
    old "How about this?"
    new "Wie wäre es damit?"

    # say L517 lyd
    old "I love that you exercise, you must be in great shape then."
    new "Ich liebe es, dass du trainierst, du musst dann ja in super Form sein."

    # say L518 pla
    old "Hmm, not really playful, but it could work."
    new "Hmm, nicht wirklich spielerisch, aber es könnte funktionieren."

    # say L519 pla
    old "Let's see how it goes."
    new "Lass es uns ausprobieren."

    # say L523 pla
    old "He said 'Oh yeah, maybe if you're lucky I'll let you take a peek later.'"
    new "Er hat gesagt: „Oh ja, vielleicht lass ich dich später mal einen Blick riskieren, wenn du Glück hast.“"

    # say L524 lyd
    old "Oh, hahaha, that's so cute. Then tell him that..."
    new "Oh, hahaha, das ist ja süß. Dann sag ihm, dass..."

    # say L525 pla
    old "Wait, there's more."
    new "Warte, da ist noch mehr."

    # say L527 pla
    old "Hmm, he says 'Judging from your pictures you must be super hot too.'"
    new "Hmm, er sagt: \"Anhand deiner Fotos muss du auch total heiß sein.\""

    # say L528 lyd
    old "Oh, really? That's so nice!"
    new "Oh, wirklich? Das ist ja nett!"

    # say L529 lyd
    old "Hmm... Tell him 'You're joking, right? I'm just an old woman.'"
    new "Hmm... Sag ihm, dass du Witze machst, oder? Ich bin doch nur eine alte Frau."

    # say L530 pla
    old "Really? Hmm alright..."
    new "Wirklich? Hmm okay..."

    # say L534 pla
    old "He says 'Come on! Don't say that, I'm sure you're beautiful.'"
    new "Komm schon! Sag das nicht, ich bin sicher, du bist schön."

    # say L535 pla
    old "And then he says 'Also, I wouldn't call you 'old'. On the contrary, I think you're very experienced, and experience is sexy.'"
    new "Und dann sagt er: „Außerdem würde ich dich nicht als 'alt' bezeichnen. Im Gegenteil, ich finde, du bist sehr erfahren, und Erfahrung istsexy.“"

    # say L536 lyd
    old "Hahaha, what a cute guy."
    new "Hahaha, was für ein süßer Kerl."

    # say L537 lyd
    old "Tell him 'Well it seems you know how to compliment a lady.'"
    new "Dann sag ihm: Na, scheint so, als wüsstest du, wie man eine Dame schmeichelt."

    # say L542 pla
    old "He says 'That's not the only thing I know how to do with a lady.'"
    new "Das ist nicht das Einzige, was ich mit einer Lady kann."

    # say L545 pla
    old "And now he adds 'Why don't we go out for dinner and you let me show you?'"
    new "Und jetzt fügt er hinzu: Warum gehen wir nicht essen und du lässt mich es dir zeigen?"

    # say L546 lyd
    old "Well isn't he brave? He just invited me to date out of the blue!"
    new "Na, der ist ja mutig! Er hat mich einfach so zu einem Date eingeladen!"

    # say L547 lyd
    old "But I don't think I should accept just like that, I don't want him to think that I'm desperate."
    new "Aber ich glaube, ich sollte das nicht einfach so annehmen, ich will ihm ja nicht weismachen, dass ich verzweifelt bin."

    # say L548 pla
    old "Then what should I tell him?"
    new "Dann was soll ich ihm sagen?"

    # say L549 lyd
    old "Hmm, let me think..."
    new "Hmm, lass mich nachdenken..."

    # say L550 lyd
    old "I got it."
    new "Ich hab's."

    # say L551 lyd
    old "Tell him 'Ohh, I don't know, I think you'll be bored if you go out with an old woman like me.'"
    new "Sag ihm 'Ohh, ich weiß nicht, ich denke, du wirst dich langweilen, wenn du mit einer alten Frau wie mir ausgehst.'"

    # say L553 lyd
    old "Why did you write 'idk' what does that mean?"
    new "Warum hast du 'idk' geschrieben? Was bedeutet das?"

    # say L554 pla
    old "I mean 'I don't know' it's just so that he doesn't think you're super formal."
    new "Ich meine „Ich weiß nicht“, es ist nur, damit er nicht denkt, dass du total formell bist."

    # say L555 lyd
    old "Ohh, I see."
    new "Ach so, ich verstehe."

    # say L557 lyd
    old "Hmm, isn't he something?"
    new "Hmm, ist er das nicht?"

    # say L558 lyd
    old "Write 'Oh really? Are you sure you're not just saying that to try and get in my pants?'"
    new "Oh wirklich? Bist du dir sicher, dass du das nicht nur sagst, um in meine Hose zu kommen?"

    # say L563 pla
    old "He's saying 'Of course not, I honestly think you're super interesting.'"
    new "Natürlich nicht, ich finde dich echt interessant."

    # say L564 pla
    old "And also 'But hey, for what it's worth, I do like my women a little older ;)'"
    new "Und auch 'Aber hey, für was es gilt, ich mag meine Frauen ein bisschen älter;)'"

    # say L567 lyd
    old "Hahahaha, tell him 'Well, aren't you something?'"
    new "Hahahaha, sag ihm 'Na, bist du was Besonderes?'"

    # say L571 pla
    old "Uhh... Now he's saying 'Baby I'm a little more than just something'"
    new "Uhh... Baby, ich bin ein bisschen mehr als nur was Besonderes"

    # say L572 pla
    old "And he is asking if you want to... Uhh, see."
    new "Und er fragt, ob du willst... Na ja, sehen."

    # say L573 lyd
    old "See? See what?"
    new "Siehst du? Was genau?"

    # say L574 pla
    old "Well... you know."
    new "Na ja... du weißt schon."

    # say L575 lyd
    old "Know what? Ask him, 'see what?'"
    new "Was denn? Frag ihn doch, was er meint."

    # say L580 pla
    old "He replied 'lol, you bad girl, you know what I mean...'"
    new "Er hat geantwortet: „Lol, du böse Mädchen, du weißt schon, was ich meine...“"

    # say L581 lyd
    old "Lol? What's that?"
    new "Lol? Was ist das?"

    # say L582 pla
    old "It means: 'Laughing out loud'."
    new "Das bedeutet: 'Lachen'."

    # say L584 lyd
    old "So, something that I said was funny?"
    new "Dann hat etwas, was ich gesagt habe, lustig geklungen?"

    # say L586 lyd
    old "But what? And what's he talking about me knowing what he means?"
    new "Aber was? Und was meint er damit, dass ich weiß, was er meint?"

    # say L589 lyd
    old "Oh wow! I wasn't expecting that!"
    new "Oh wow! Das habe ich nicht erwartet!"

    # say L590 pla
    old "Hmm, me neither..."
    new "Hmm, ich auch nicht..."

    # say L591 lyd
    old "What do I answer now?"
    new "Was soll ich jetzt antworten?"

    # say L593 pla
    old "Hmm, I- I guess you can tell him how surprised you are."
    new "Hmm, ich- ich schätze, du kannst ihm sagen, wie überrascht du bist."

    # say L594 lyd
    old "Sure, tell him that I wasn't expecting that picture."
    new "Klar, sag ihm, dass ich das Bild nicht erwartet habe."

    # say L598 pla
    old "He replied: 'Hahaha, well, you know... yolo, right?'"
    new "Er hat geantwortet: „Hahaha, na ja, weißt du... yolo, oder?“"

    # say L602 pla
    old "You only live once."
    new "Du lebst nur einmal."

    # say L603 lyd
    old "You young people, honestly..."
    new "Ihr jungen Leute, ehrlich..."

    # say L605 pla
    old "He wants to know what you thought about the picture."
    new "Er will wissen, was du von dem Bild denkst."

    # say L606 lyd
    old "Really? W- what should I tell him?"
    new "Wirklich? W- was soll ich ihm sagen?"

    # say L608 pla
    old "Just tell him what you think."
    new "Sag ihm einfach, was du denkst."

    # say L609 lyd
    old "Well, let me see it again..."
    new "Na, lass es mich noch mal sehen..."

    # say L616 lyd
    old "Well, I wasn't expecting him to just send it. That was very unexpected."
    new "Na ja, ich habe nicht damit gerechnet, dass er es einfach so schickt. Das war sehr überraschend."

    # say L617 lyd
    old "But if I'm honest, it's very... impressive. Also, he's rock hard, do you think that's for me?"
    new "Aber ehrlich gesagt, es ist sehr... beeindruckend. Und er ist total hart, glaubst du, das ist für mich?"

    # say L619 pla
    old "Do I tell him that?"
    new "Soll ich ihm das sagen?"

    # say L620 lyd
    old "Well, that's what I think about that pic."
    new "Na ja, das denke ich über dieses Bild."

    # say L621 pla
    old "Alright, I'll tell him that."
    new "Okay, ich sag's ihm."

    # say L628 pla
    old "Of course it is, to be honest, you're super hot, so hot that you make me hard just thinking about being with you."
    new "Natürlich, ehrlich gesagt, du bist super heiß, so heiß, dass ich schon hart werde, wenn ich nur daran denke, mit dir zu sein."

    # say L630 lyd
    old "That that's very sweet, thank you."
    new "Das ist sehr süß, danke."

    # say L633 lyd
    old "And to be honest, seeing your hard dick also turns on a little."
    new "Und ehrlich gesagt, deiner harten Schwanz zu sehen macht mich auch ein bisschen an."

    # say L636 pla
    old "Oh yeah? Tell me how much."
    new "Oh ja? Erzähl mir, wie sehr."

    # say L637 lyd
    old "Mmm, just seeing your hard dick is making me horny."
    new "Mmm, nur der Anblick deines harten Schwanzes macht mich schon geil."

    # say L640 pla
    old "That's it baby and thinking about your wet pussy makes me even harder."
    new "Das ist es, Baby, und wenn ich an deine nasse Pussy denke, werde ich noch härter."

    # say L648 lyd
    old "Yes, my pussy is dripping just thinking about your cock."
    new "Ja, meine Pussy tropft schon beim Gedanken an deinen Schwanz."

    # say L652 pla
    old "Oh baby, I want to fuck you with this big cock."
    new "Oh Baby, ich will dich mit diesem großen Schwanz ficken."

    # say L653 lyd
    old "Oh yes, I want you to come over and put that hard cock in me."
    new "Oh ja, ich will, dass du rüberkommst und deinen harten Schwanz in mich schiebst."

    # say L656 pla
    old "Do you really want that baby?"
    new "Willst du das wirklich, Baby?"

    # say L657 lyd
    old "Oh yes! I want it so bad!"
    new "Oh ja! Ich will es so sehr!"

    # say L662 pla
    old "Tell me, what else do you want me to do to you?"
    new "Sag mir, was ich sonst noch mit dir machen soll?"

    # say L663 lyd
    old "I want you to come over and pull my hair while you fuck me!"
    new "Ich will, dass du rüberkommst und mein Haar ziehst, während du mich fickst!"

    # say L666 pla
    old "Yes! I'll pull your hair while I fuck you from behind!"
    new "Ja! Ich ziehe an deinen Haaren, während ich dich von hinten ficke!"

    # say L669 lyd
    old "Yes! Yes! I want you to pull my hair and slap my ass!"
    new "Ja! Ja! Ich will, dass du meine Haare ziehst und meinen Arsch schlägst!"

    # say L672 pla
    old "I'll pull your hair and call you my little slut!"
    new "Ich werde deine Haare ziehen und dich meine kleine Schlampe nennen!"

    # say L673 lyd
    old "Oh yeah! I'm your little slut!"
    new "Oh ja! Ich bin deine kleine Schlampe!"

    # say L681 lyd
    old "Mmmm... Phew..."
    new "Mmmm... Puh..."

    # say L682 lyd
    old "Wow, that was fun."
    new "Wow, das war toll."

    # say L688 pla
    old "He says he has to go now, he is late for his work."
    new "Ich muss jetzt los, ich bin schon spät dran für die Arbeit."

    # say L689 lyd
    old "Ohh... hmm, sure."
    new "Ohh... hmm, klar."

    # say L693 pla
    old "He says 'It was awesome, you really are cool. I can't wait to meet you in person.'"
    new "Es war awesome, du bist echt cool. Ich freu mich schon, dich persönlich zu treffen."

    # say L695 lyd
    old "Uhh t- thanks... see you later."
    new "Uhh danke... bis später."

    # say L697 pla
    old "Ok, I think it's done, so I'm going home."
    new "Okay, ich glaube, es ist fertig, dann gehe ich nach Hause."

    # say L707 lyd
    old "Uhh... Listen [pla]. I- I'm sorry. I didn't mean it for things to turn this way."
    new "Uhh... Hör zu [pla]. Es tut mir leid. Ich wollte nicht, dass es so kommt."

    # say L708 lyd
    old "I'm sorry, I don't know what happened."
    new "Es tut mir leid, ich weiß nicht, was passiert ist."

    # say L709 lyd
    old "It's just that it's been so long since any kind of you know... Release."
    new "Es ist nur, dass es schon so lange her ist, seit es so eine Art von... Entspannung gab."

    # say L710 lyd
    old "I wasn't expecting the conversation to take a turn that way."
    new "Ich habe nicht damit gerechnet, dass das Gespräch so eine Wendung nimmt."

    # say L711 lyd
    old "But please believe me that I didn't plan any of this, I just couldn't help it."
    new "Aber glaub mir bitte, ich habe das alles nicht geplant, ich konnte einfach nicht anders."

    # say L712 pla
    old "Hey, hey, it's ok. Don't worry."
    new "Hey, hey, ist schon gut. Mach dir keine Sorgen."

    # say L713 pla
    old "I understand, and I'm not angry."
    new "Ich verstehe, und ich bin nicht sauer."

    # say L714 pla
    old "I won't lie, I'm a little surprised."
    new "Ich lüge nicht, ich bin ein bisschen überrascht."

    # say L715 pla
    old "But, I understand. After all, the whole point of doing this was for you to let loose and meet new people."
    new "Aber ich verstehe. Schließlich ging es darum, dass du dich ausleben und neue Leute kennenlernen kannst."

    # say L716 lyd
    old "Thank you so much [pla]. You're an angel for understanding."
    new "Danke dir so sehr [pla]. Du bist ein Engel, dass du das verstehst."

    # say L717 pla
    old "No biggie, but maybe I should go now."
    new "Kein Problem, aber vielleicht sollte ich jetzt gehen."

    # say L718 lyd
    old "Yeah, you're right. Anna might come back any minute."
    new "Ja, du hast recht. Anna könnte jeden Moment zurückkommen."

    # say L719 pla
    old "Yeah, however, I'm glad to see that you're making progress with your online app."
    new "Ja, aber ich freue mich, dass du mit deiner Online-App vorankommst."

    # say L721 lyd
    old "But being honest it's all thanks to your help."
    new "Aber ehrlich gesagt ist es alles deiner Hilfe zu verdanken."

    # say L722 pla
    old "It's nothing, I'm glad I can be of help to you."
    new "Ist doch nichts, ich freue mich, dass ich dir helfen kann."

    # say L723 pla
    old "Keep chatting and I'll be back soon to keep helping you."
    new "Weiter so, ich bin bald wieder da und helfe dir weiter."

    # say L724 lyd
    old "All right, Thank you!"
    new "Alles gut, danke!"

    # say L746 pla
    old "Hi, how a..."
    new "Hi, wie geht's dir?"

    # say L748 pla
    old "Is everything alright? Did anything happen?"
    new "Alles in Ordnung? Ist was passiert?"

    # say L750 lyd
    old "Hi [pla] how are you?"
    new "Hi [pla] wie geht's dir?"

    # say L751 lyd
    old "I guess everything's right. I'm just not feeling well right now."
    new "Ich denke, alles ist in Ordnung. Ich fühle mich nur gerade nicht so gut."

    # say L753 lyd
    old "Hmm, well, it's not much."
    new "Hmm, na ja, es ist nicht viel."

    # say L754 lyd
    old "It's just that I went out with that guy you were helping me chat with."
    new "Es war nur so, dass ich mit dem Typen ausgegangen bin, mit dem du mir beim Chatten geholfen hast."

    # say L756 lyd
    old "And it didn't go well, it was actually kinda bad."
    new "Und es hat nicht gut funktioniert, es war eigentlich ziemlich schlecht."

    # say L759 pla
    old "Did he say anything bad to you?"
    new "Hat er dir etwas Schlechtes gesagt?"

    # say L761 lyd
    old "No, no. The problem is that it didn't feel good."
    new "Nein, nein. Das Problem ist, dass es sich einfach nicht gut angefühlt hat."

    # say L763 lyd
    old "We only talked about everyday stuff and the conversation didn't go anywhere from there. Is just as if he had lost all interest."
    new "Wir haben nur über Alltägliches geredet und das Gespräch ist da stehen geblieben. Als hätte er jegliches Interesse verloren."

    # say L764 lyd
    old "I swear to god he wasn't even looking at me!"
    new "Ich schwör's, er hat mich nicht mal angesehen!"

    # say L765 lyd
    old "And after saying all that stuff on our chat."
    new "Und nachdem ich all das auf unserem Chat gesagt habe."

    # say L766 lyd
    old "It's extremely disappointing."
    new "Das ist extrem enttäuschend."

    # say L767 pla
    old "I see, I'm sorry that happened."
    new "Ich sehe, tut mir leid, dass das passiert ist."

    # say L769 lyd
    old "But to be honest [pla]. This date got me thinking."
    new "Aber ehrlich gesagt [pla]. Dieses Date hat mich zum Nachdenken gebracht."

    # say L770 lyd
    old "And I don't think this whole thing of looking for younger men is for me."
    new "Und ich glaube, diese Sache mit der Suche nach jüngeren Männern ist nichts für mich."

    # say L772 lyd
    old "Think about it, I don't even understand what they're saying when they write with those strange words they make up."
    new "Überleg mal, ich verstehe noch nicht mal, was sie schreiben, mit diesen komischen Wörtern, die sie sich ausdenken."

    # say L773 lyd
    old "And when I got a date with a guy that seemingly wanted to have something with me."
    new "Und als ich ein Date mit einem Typen hatte, der angeblich was mit mir wollte."

    # say L774 lyd
    old "He just lost all interest and began treating me all cordial and distant."
    new "Er hat einfach alles Interesse verloren und fing an, mich höflich und distanziert zu behandeln."

    # say L777 lyd
    old "I didn't like that at all. I'm not doing this to be looked at as if I was their grandma."
    new "Das habe ich überhaupt nicht gemocht. Ich mache das nicht, damit ich wie ihre Oma behandelt werde."

    # say L778 lyd
    old "So it's better if we just look for older men that are my age, I think I can date then."
    new "Dann ist es besser, wenn wir einfach nach älteren Männern suchen, die in meinem Alter sind. Ich denke, ich kann dann daten."

    # say L780 pla
    old "Well, I get what you mean."
    new "Na ja, ich verstehe, was du meinst."

    # say L781 pla
    old "But I don't actually think that's what you want Lydia."
    new "Aber ich glaube nicht, dass das wirklich das ist, was du willst, Lydia."

    # say L782 pla
    old "Listen, that guy was an idiot. You shouldn't let his attitude bring you down."
    new "Hör zu, der Typ war ein Idiot. Lass dir von seinem Verhalten nicht die Laune verderben."

    # say L783 lyd
    old "Hmm, you say that but..."
    new "Hmm, du sagst das, aber..."

    # say L784 pla
    old "Listen, you went on a date, and it didn't go great because the guy turned out to be an asshole."
    new "Hör zu, du warst auf einem Date, und es hat nicht gut gelaufen, weil der Typ ein Arschloch war."

    # say L785 pla
    old "I get it sucks, but that stuff happens."
    new "Ich verstehe, es ist scheiße, aber so was passiert."

    # say L786 pla
    old "Believe me, if it didn't go well it's because of him. You didn't have anything to do with that."
    new "Glaub mir, wenn es nicht gut gelaufen ist, liegt das an ihm. Du hast da gar nichts dran schuld."

    # say L790 pla
    old "Of course! I mean, look at you. You are beautiful, and you're great to hang around. Any guy would be lucky to be with you."
    new "Natürlich! Ich meine, schau dich an. Du bist wunderschön und super, um mit dir abzuhängen. Jeder Kerl wäre froh, mit dir zusammen zu sein."

    # say L791 lyd
    old "Hmph, you're sweet, but I know you're only saying that to cheer me up. I know you don't mean it."
    new "Hmpf, du bist süß, aber ich weiß, dass du das nur sagst, um mich aufzumuntern. Ich weiß, dass du es nicht ernst meinst."

    # say L792 pla
    old "Swear to god that I do."
    new "Ich schwöre bei Gott, dass ich es ernst meine."

    # say L793 lyd
    old "Well then you're the only one!"
    new "Dann bist du die Einzige!"

    # say L794 lyd
    old "I mean let's just face it [pla]. I'm an old lonely widow with nothing to offer to any guy."
    new "Ich meine, lass uns ehrlich sein [pla]. Ich bin eine alte einsame Witwe, die keinem Mann etwas zu bieten hat."

    # say L795 lyd
    old "Besides, I can't compete with the girls young men go around with. With their perfect toned bodies."
    new "Außerdem kann ich nicht mit den Mädchen mithalten, die die jungen Männer um sich haben. Mit ihren perfekt durchtrainierten Körpern."

    # say L796 lyd
    old "I'm old, any sex appeal that I had I lost a long time ago."
    new "Ich bin alt, jeden Reiz, den ich mal hatte, habe ich schon lange verloren."

    # say L797 pla
    old "W- What?! What are you saying? You can't be serious."
    new "W- Was?! Was redest du da? Das kannst du nicht ernst meinen."

    # say L798 lyd
    old "Well, I am!"
    new "Na klar, bin ich!"

    # say L799 lyd
    old "It's just true, I'm no longer pretty."
    new "Das stimmt einfach, ich bin nicht mehr hübsch."

    # say L800 pla
    old "What are you talking about, you're so beautiful."
    new "Was redest du da, du bist so schön."

    # say L801 pla
    old "You're still a very sexy woman, your face, your body, everything about you is perfect."
    new "Du bist immer noch eine sehr sexy Frau, dein Gesicht, deine Figur, alles an dir ist perfekt."

    # say L802 lyd
    old "Yeah right..."
    new "Klar, und ich bin die Queen von Saba."

    # say L803 pla
    old "I mean it, any man would find you to be incredibly sexy."
    new "Ich meine es ernst, jeder Mann würde dich unglaublich sexy finden."

    # say L808 lyd
    old "Any man?"
    new "Jeder Mann?"

    # say L809 pla
    old "All of them?"
    new "Alle?"

    # say L811 lyd
    old "... Even you?"
    new "... Sogar du?"

    # say L814 lyd
    old "Yeah, you, you said any man would think I'm sexy."
    new "Klar, du hast gesagt, jeder Mann würde mich sexy finden."

    # say L815 lyd
    old "How about you? Do you really think I'm sexy?"
    new "Und du? Findest du mich wirklich sexy?"

    # say L817 pla
    old "Uhh, w- well, yeah, I mean..."
    new "Uhh, w-was, ja, also..."

    # say L818 lyd
    old "You mean what?"
    new "Du meinst was?"

    # say L819 lyd
    old "I knew it! You also just think I'm old!"
    new "Ich hab's gewusst! Du findest mich auch nur alt!"

    # say L820 pla
    old "No, no, not at all."
    new "Nein, nein, überhaupt nicht."

    # say L821 pla
    old "It's just that I wasn't expecting you to ask me that."
    new "Es ist nur, dass ich nicht damit gerechnet habe, dass du mich das fragst."

    # say L822 pla
    old "But I mean, of course, I also think you're sexy."
    new "Aber ich meine, klar, ich finde dich auch sexy."

    # say L824 lyd
    old "Really? And you actually mean it? You're not just saying that to please me?"
    new "Wirklich? Und du meinst das ernst? Du sagst das nicht nur, um mich zu beruhigen?"

    # say L826 pla
    old "For real, I mean it 100."
    new "Klar, ich meine es ernst, 100."

    # say L828 lyd
    old "Well, I don't know if you're lying, but just you saying I'm sexy is not enough."
    new "Na, ich weiß nicht, ob du lügst, aber nur zu sagen, dass ich sexy bin, reicht mir nicht."

    # say L829 lyd
    old "But there's one way to know for certain... Your cock."
    new "Aber es gibt einen Weg, um sicherzugehen... Dein Schwanz."

    # say L830 pla
    old "My cock? W- what do you mean?"
    new "Mein Schwanz? W-was meinst du damit?"

    # say L831 lyd
    old "To know if you're lying, you may say I'm sexy, but if you don't have an erection I won't believe you."
    new "Um zu wissen, ob du lügst, kannst du sagen, dass ich sexy bin, aber wenn du keine Erektion hast, glaube ich dir nicht."

    # say L832 lyd
    old "It's the same with all men, the penis never lies."
    new "Bei allen Männern ist es das Gleiche, der Penis lügt nie."

    # say L837 pla
    old "W- whoa! What are you doing?"
    new "W-was?! Was machst du da?"

    # say L841 lyd
    old "Well, I wanted to know what you think about my breasts."
    new "Na ja, ich wollte wissen, was du von meinen Brüsten hältst."

    # say L842 lyd
    old "How about now? Do you still think I'm sexy?"
    new "Und jetzt? Findest du mich immer noch sexy?"

    # say L843 pla
    old "Y- yeah, of course."
    new "Y- ja, natürlich."

    # say L844 lyd
    old "So, look at them, and let's see if your cock thinks the same."
    new "Dann schau sie dir an und lass uns sehen, was dein Schwanz dazu sagt."

    # say L845 pla
    old "I don't think that's a good idea. After all..."
    new "Ich glaube, das ist keine gute Idee. Immerhin..."

    # say L846 lyd
    old "Stop putting up excuses and see my tit!"
    new "Hör auf, Ausreden zu finden, und sieh dir meine Titten an!"

    # say L847 lyd
    old "Or I'll know you're lying to me."
    new "Oder ich weiß, dass du mich anlügst."

    # say L854 lyd
    old "Oh wow, this is impressive."
    new "Oh wow, das ist beeindruckend."

    # say L855 lyd
    old "Ok, I believe you, if you're this hard you must be telling the truth."
    new "Okay, ich glaube dir, wenn du so hart bist, musst du die Wahrheit sagen."

    # say L856 pla
    old "Yeah, well, I do believe you're very beautiful."
    new "Ja, ich glaube, du bist sehr schön."

    # say L857 lyd
    old "Well, I have no doubt about that now."
    new "Na, daran habe ich jetzt keinen Zweifel mehr."

    # say L858 lyd
    old "I must say [pla] your cock is something else."
    new "Ich muss sagen [pla] dein Schwanz ist was Besonderes."

    # say L859 lyd
    old "It's so... big."
    new "Es ist so... groß."

    # say L860 lyd
    old "I- I can believe that it is because of me."
    new "I- Ich kann es kaum glauben, dass es wegen mir ist."

    # say L862 lyd
    old "It's really flattering that such a young man like you can feel that way about a woman my age."
    new "Es ist wirklich schmeichelhaft, dass ein junger Mann wie du so empfinden kann für eine Frau in meinem Alter."

    # say L868 lyd
    old "I- I just want to see it closer..."
    new "I- Ich will es mir nur näher ansehen..."

    # say L869 lyd
    old "It's been a long time since I've seen one so close."
    new "Es ist lange her, dass ich einen so nah gesehen habe."

    # say L873 lyd
    old "And, it wasn't that big... Not at all..."
    new "Und, es war nicht besonders groß... Überhaupt nicht..."

    # say L874 lyd
    old "Knowing this is caused by me really makes me tingle."
    new "Dass das von mir verursacht wird, macht mich echt kribbeln."

    # say L875 lyd
    old "I'm sorry to ask but, may I see it... I mean, out of your pants?"
    new "Es tut mir leid, aber darf ich es sehen... Ich meine, aus deiner Hose?"

    # say L876 lyd
    old "To be honest, is the first time I have seen one that big, and really makes me curious..."
    new "Ehrlich gesagt, ist es das erste Mal, dass ich einen so großen sehe, und es macht mich wirklich neugierig..."

    # say L881 lyd
    old "Oh wow! It's even bigger than I thought it was..."
    new "Oh wow! Es ist sogar noch größer, als ich dachte..."

    # say L882 lyd
    old "I have never thought you were this... gifted."
    new "Ich hätte nie gedacht, dass du so... beschenkt bist."

    # say L884 lyd
    old "And it's so hard... really seen just this old boob make you so hard?"
    new "Und es ist so hart... wirklich nur diese alte Tittie macht dich so hart?"

    # say L885 pla
    old "It was something instinctive, you know a natural reaction..."
    new "Es war eine Art Instinkt, weißt du, eine natürliche Reaktion..."

    # say L886 lyd
    old "That is the most honest answer a woman can get from a man..."
    new "Das ist die ehrlichste Antwort, die eine Frau von einem Mann bekommen kann..."

    # say L887 lyd
    old "Thanks [pla], you really made me regain some self-esteem after the bad date I had with the other guy..."
    new "Danke [pla], du hast mir echt wieder Selbstbewusstsein gegeben nach dem schlechten Date mit dem anderen Typ..."

    # say L888 pla
    old "You have to know you are really beautiful and sexy, any man can see that, really."
    new "Du musst wissen, dass du wirklich schön und sexy bist, das sieht jeder Mann, ehrlich."

    # say L889 lyd
    old "Yeah, now I can see it..."
    new "Ja, jetzt kann ich es sehen..."

    # say L891 lyd
    old "Uhh... C- can I touch it?"
    new "Uhh... K- kann ich es anfassen?"

    # say L893 lyd
    old "I mean, I just want to see how hard you are, if you're really excited or if it's just barely."
    new "Ich meine, ich will nur fühlen, wie hart du bist, ob du wirklich erregt bist oder ob es nur so aussieht."

    # say L894 pla
    old "And you can't tell just from seeing it?"
    new "Und das siehst du nicht einfach so?"

    # say L895 lyd
    old "You can't always know that from just looking."
    new "Du kannst das nicht immer nur vom Ansehen erkennen."

    # say L896 lyd
    old "It's always better to check with my own hands."
    new "Es ist immer besser, es mit meinen eigenen Händen zu überprüfen."

    # say L904 lyd
    old "Woah, you're really hard!"
    new "Wow, du bist wirklich hart!"

    # say L905 lyd
    old "And you're so big! This is impressive!"
    new "Und du bist so groß! Das ist beeindruckend!"

    # say L915 lyd
    old "L-listen [pla]. I'm sorry. I didn't mean to do that when you got here."
    new "L-listen [pla]. Es tut mir leid. Das wollte ich nicht tun, als du gekommen bist."

    # say L916 lyd
    old "It's just that you've been so good to me, and I was feeling rather vulnerable."
    new "Es ist nur, dass du so gut zu mir warst und ich mich ziemlich verletzbar gefühlt habe."

    # say L917 lyd
    old "And seeing how hard you got because of me."
    new "Und zu sehen, wie sehr du darauf reagiert hast, weil ich es war."

    # say L918 lyd
    old "But, I swear to God I didn't mean to..."
    new "Aber, ich schwöre bei Gott, ich wollte das nicht..."

    # say L919 pla
    old "Hey, hey, it's ok."
    new "Hey, hey, ist schon gut."

    # say L920 pla
    old "No need for you to stress over this."
    new "Mach dir keine Sorgen deswegen."

    # say L921 pla
    old "I'm not angry with you. I understand."
    new "Ich bin nicht sauer auf dich. Ich verstehe."

    # say L923 pla
    old "Yeah, I do, it's ok."
    new "Klar, ist schon okay."

    # say L925 lyd
    old "Hmm, but maybe we should clean this up before we keep talking."
    new "Hmm, aber vielleicht sollten wir das hier aufräumen, bevor wir weiterreden."

    # say L931 lyd
    old "Thanks a lot for your help [pla]."
    new "Danke schön für deine Hilfe [pla]."

    # say L932 lyd
    old "The truth is that what happened with that guy really affected me. I was feeling really down."
    new "Die Wahrheit ist, dass mich das, was mit diesem Typen passiert ist, echt mitgenommen hat. Ich war total niedergeschlagen."

    # say L933 lyd
    old "Thanks for helping me feel better."
    new "Danke, dass du mir geholfen hast, mich besser zu fühlen."

    # say L934 pla
    old "No problem, I understand, that kind of thing can make you feel really bad."
    new "Kein Problem, ich verstehe, so was kann dich echt runterziehen."

    # say L935 pla
    old "I'm glad you're ok now."
    new "Ich bin froh, dass es dir jetzt besser geht."

    # say L936 pla
    old "Now that I see you feel better, I think I should go home."
    new "Jetzt, wo ich sehe, dass es dir besser geht, denke ich, ich sollte nach Hause gehen."

    # say L937 lyd
    old "Sure, no problem. Bye."
    new "Klar, kein Problem. Tschüss."

    # say L955 pla
    old "Hey Lydia. How are you today?"
    new "Hey Lydia. Wie geht's dir heute?"

    # say L956 lyd
    old "Hi [pla]! Nice seeing you. You arrive just at the perfect time."
    new "Hi [pla]! Schön, dich zu sehen. Du kommst gerade zur perfekten Zeit."

    # say L957 pla
    old "The perfect time? For what?"
    new "Die perfekte Zeit? Wofür?"

    # say L958 lyd
    old "You see, I've been talking to this new guy on Tinder, and the conversations have been going pretty well."
    new "Du siehst, ich habe mit einem neuen Typen auf Tinder geredet, und die Konversationen laufen ziemlich gut."

    # say L960 lyd
    old "Yeah, it is."
    new "Ja, ist es."

    # say L961 lyd
    old "The thing is that he has been asking to see some pictures of me for a while..."
    new "Die Sache ist, dass er schon eine Weile darum bittet, ein paar Fotos von mir zu sehen..."

    # say L962 lyd
    old "And he has sent me a lot of pics, and the conversation is going really well, so, I want to send them to him a few ones."
    new "Und er hat mir schon viele Fotos geschickt, und das Gespräch läuft echt gut, also will ich ihm auch ein paar schicken."

    # say L963 lyd
    old "But, to be honest, I don't really know what to send him."
    new "Aber ehrlich gesagt, ich weiß nicht so recht, was ich ihm schicken soll."

    # say L964 lyd
    old "So, I think you could take some pictures of me so I can send him some good ones."
    new "Dann denk ich, du könntest ein paar Fotos von mir machen, damit ich ihm was Gutes schicken kann."

    # say L966 lyd
    old "So, what do you say? Do you think you can do it?"
    new "Was meinst du? Denkst du, du kannst das machen?"

    # say L967 pla
    old "Hmm, sure, I guess I can."
    new "Hmm, klar, ich denke schon."

    # say L975 lyd
    old "Ok, I think something casual, like this, what do you think?"
    new "Ok, ich denke, so was Casual, wie das, was meinst du?"

    # say L976 pla
    old "It looks great!"
    new "Sieht toll aus!"

    # say L987 lyd
    old "But it's ok, take it, if you like it I think he will too."
    new "Aber es ist okay, nimm es, wenn dir's gefällt, denke ich, wird ihm auch gefallen."

    # say L997 lyd
    old "Is it ok? Do you like it?"
    new "Ist es in Ordnung? Magst du es?"

    # say L998 pla
    old "Yeah, I think it looks very good."
    new "Ja, ich denke, es sieht sehr gut aus."

    # say L999 lyd
    old "Great! So, next one."
    new "Super! Dann mal zur nächsten."

    # say L1006 lyd
    old "Ok, for this one I want to try something a little hotter."
    new "Ok, für diesen hier will ich was ein bisschen heißeres ausprobieren."

    # say L1007 lyd
    old "Does my ass look good enough?"
    new "Sieht mein Arsch gut genug aus?"

    # say L1008 pla
    old "Sure, I think it looks great."
    new "Klar, ich finde es super."

    # say L1026 lyd
    old "Do I look fat? What do you think? Do you like that one?"
    new "Mach ich einen dicken Eindruck? Was meinst du? Magst du den?"

    # say L1027 pla
    old "Don't worry, I think you look just perfect."
    new "Mach dir keine Sorgen, ich finde, du siehst einfach perfekt aus."

    # say L1028 lyd
    old "Great, I've got an idea for the next one."
    new "Super, ich hab eine Idee für das Nächste."

    # say L1036 lyd
    old "Ha! I knew it, you men and breasts, I don't know why you're so crazy about them."
    new "Ha! Ich wusste es, ihr Männer und Brüste, ich verstehe echt nicht, warum ihr so verrückt danach seid."

    # say L1039 lyd
    old "The truth is, he's already sent me a couple of pictures of himself."
    new "Die Wahrheit ist, er hat mir schon ein paar Bilder von sich geschickt."

    # say L1040 lyd
    old "And some of those are actually very spicy."
    new "Und einige davon sind tatsächlich ziemlich scharf."

    # say L1041 lyd
    old "So, I thought that maybe I could send him some like that too."
    new "Dann dachte ich, ich könnte ihm auch so welche schicken."

    # say L1043 pla
    old "I- I think it's great."
    new "Ich- Ich finde es toll."

    # say L1044 lyd
    old "Yeah, I can see that. Fufu."
    new "Ja, das sehe ich auch. Fufu."

    # say L1046 lyd
    old "Anyway, take the picture."
    new "Na los, mach das Foto."

    # say L1052 lyd
    old "So how does the picture look?"
    new "Und wie sieht das Bild aus?"

    # say L1053 pla
    old "Very well I think."
    new "Sehr gut, denke ich."

    # say L1054 lyd
    old "And my breasts? They don't look soggy or wrinkled?"
    new "Und meine Brüste? Sie sehen nicht faltig oder aufgeweicht aus?"

    # say L1055 pla
    old "No, no, they look great as well."
    new "Nein, nein, die sehen auch toll aus."

    # say L1056 lyd
    old "That's great, I'm glad that's how it is."
    new "Das ist toll, ich bin froh, dass es so ist."

    # say L1063 lyd
    old "That was very good [pla], thank you."
    new "Das war sehr gut [pla], danke."

    # say L1064 pla
    old "It's ok, happy to help."
    new "Alles gut, gern geschehen."

    # say L1065 lyd
    old "I hope he likes the pictures."
    new "Ich hoffe, er mag die Fotos."

    # say L1066 pla
    old "I'm sure he will, you look great, don't worry."
    new "Ich bin sicher, er wird sie lieben, du siehst toll aus, mach dir keine Sorgen."

    # say L1067 lyd
    old "Well thank you, that's very sweet of you."
    new "Danke, das ist sehr nett von dir."

    # say L1068 lyd
    old "I believe you this time."
    new "Ich glaube dir dieses Mal."

    # say L1069 lyd
    old "After all, I can see it this time."
    new "Schließlich kann ich es dieses Mal sehen."

    # say L1071 pla
    old "Sorry, it's just that you took your shirt off all of a sudden."
    new "Entschuldigung, es ist nur, dass du plötzlich dein Shirt ausgezogen hast."

    # say L1073 lyd
    old "It's ok, don't worry, I actually like to see that reaction."
    new "Es ist okay, mach dir keine Sorgen, ich finde es eigentlich ganz schön, diese Reaktion zu sehen."

    # say L1074 lyd
    old "I think it's very flattering."
    new "Ich finde es sehr schmeichelhaft."

    # say L1075 lyd
    old "To see such a young man get so hard because of me, I can never get tired of it."
    new "Es ist immer wieder aufregend, einen so jungen Mann so hart werden zu sehen, weil ich es bin."

    # say L1076 lyd
    old "In fact, how about I help you with that? I know it can take a while for your dick to calm down."
    new "Eigentlich, wie wäre es, wenn ich dir dabei helfe? Ich weiß, dass es eine Weile dauern kann, bis dein Schwanz sich beruhigt."

    # say L1077 pla
    old "You don't really have to do it."
    new "Du musst das wirklich nicht tun."

    # say L1078 lyd
    old "Well, you helped me with the pictures, it's fine if I help you back. Don't you think?"
    new "Na, du hast mir bei den Fotos geholfen, da ist es doch nur fair, wenn ich dir auch helfe. Oder findest du nicht?"

    # say L1079 lyd
    old "And to be honest, doing these photos made me a bit horny..."
    new "Und ehrlich gesagt, diese Fotos haben mich ein bisschen gegeilt..."

    # say L1081 lyd
    old "Now come, let me help you."
    new "Komm schon, lass mich dir helfen."

    # say L1088 lyd
    old "I didn't notice last time, but your dick has a great smell."
    new "Ich hab das letztes Mal gar nicht bemerkt, aber dein Schwanz riecht super."

    # say L1089 lyd
    old "And I can't believe how hard you get."
    new "Und ich kann nicht glauben, wie hart du wirst."

    # say L1090 lyd
    old "Young men are amazing."
    new "Junge Männer sind unglaublich."

    # say L1091 lyd
    old "It's sooo big too."
    new "Es ist auch sooo groß."

    # say L1092 lyd
    old "Honestly I'm not sure it will fill all in my mouth."
    new "Ehrlich gesagt, bin ich mir nicht sicher, ob es alles in meinem Mund passt."

    # say L1093 lyd
    old "But don't worry, I'll make sure you finish in a moment."
    new "Aber mach dir keine Sorgen, ich sorge dafür, dass du gleich abspritzt."

    # say L1104 pla
    old "Well, I think I should go home."
    new "Na, ich denke, ich sollte jetzt nach Hause gehen."

    # say L1105 lyd
    old "Sure thing, thanks again for the pictures. I'll let you know if he likes them."
    new "Klar, danke nochmal für die Fotos. Ich geb dir Bescheid, wenn er sie mag."

    # say L1126 ann
    old "I mean, what the fuck mom?! What the actual fuck?!"
    new "Ich meine, was zur Hölle, Mum?! Was zum Teufel?!"

    # say L1127 ann
    old "Now you're coming home late? JESUS!"
    new "Jetzt kommst du auch noch spät nach Hause? JESUS!"

    # say L1128 ann
    old "After all those times you scolded me for doing it when I was a teenager. And not only that, but I'm sure you were on a date with someone."
    new "Nach all den Malen, wo du mich als Teenager dafür angebrüllt hast. Und nicht nur das, ich bin mir sicher, dass du mit jemandem verabredet warst."

    # say L1129 ann
    old "I imagine it was some guy you must've met there. What's wrong with you?"
    new "Ich stelle mir vor, da war irgendein Typ, den du da getroffen hast. Was ist bloß los mit dir?"

    # say L1130 ann
    old "Don't you realize you're too old to be going out with guys like those?"
    new "Bist du dir eigentlich bewusst, dass du zu alt bist, um mit Typen wie denen auszugehen?"

    # say L1131 ann
    old "Honestly..."
    new "Ehrlich..."

    # say L1132 lyd
    old "Why are you so angry?"
    new "Warum bist du so sauer?"

    # say L1133 lyd
    old "I get that I forgot to tell you I was going out last night, but that's no reason to be acting like this."
    new "Ich verstehe, dass ich dir gestern Abend nicht gesagt habe, dass ich ausgehen würde, aber das ist doch kein Grund, so zu reagieren."

    # say L1134 lyd
    old "Listen, your mother is a mature woman, and I have every right to go out and date anyone I want to."
    new "Hör zu, deine Mutter ist eine erwachsene Frau, und ich habe jedes Recht, mit wem ich will ausgehen."

    # say L1136 ann
    old "I DON'T GIVE A FUCK!"
    new "Mir ist das total egal!"

    # say L1137 ann
    old "I just don't want to go around picking up random dudes that you find on the street!"
    new "Ich will einfach nicht rumlaufen und irgendwelche Typen auf der Straße auflesen!"

    # say L1138 ann
    old "I mean, what's everyone going to think? That you're just some whore looking for dick!"
    new "Ich meine, was sollen die anderen denn denken? Dass du nur eine Schlampe bist, die auf der Straße Typen aufgabelst!"

    # say L1139 ann
    old "They would be right by the way! Because that's what you're acting like!!!"
    new "Sie hätten ja recht! Denn genau so benimmst du dich!"

    # say L1142 ann
    old "Ugh! I'm so mad mom! I swear to god!"
    new "Ugh! Ich bin so wütend, Mama! Ich schwör's!"

    # say L1143 ann
    old "You know what? I won't keep talking about this!"
    new "Du weißt was? Ich rede nicht weiter darüber!"

    # say L1144 ann
    old "I'm out of here!"
    new "Ich geh jetzt!"

    # say L1158 lyd
    old "Oh [pla], hi. How are you?"
    new "Oh [pla], hallo. Wie geht’s dir?"

    # say L1159 pla
    old "Never mind me, how about you? What was Anna mad about this time?"
    new "Lass mich mal außen vor, wie geht's dir? Was war Anna denn diesmal wieder aufgefallen?"

    # say L1160 lyd
    old "Well, remember the guy that we took the pictures for?"
    new "Na, erinnerst du dich noch an den Typen, für den wir die Fotos gemacht haben?"

    # say L1163 lyd
    old "Well, we went out on a date, and we ended up staying out until very late, and Anna noticed it."
    new "Na ja, wir waren auf einem Date, und es wurde ziemlich spät, und Anna hat das bemerkt."

    # say L1164 lyd
    old "As you can see, she's not too thrilled about it."
    new "Wie du sehen kannst, ist sie nicht besonders begeistert davon."

    # say L1165 pla
    old "Yeah, I caught that she's not too happy about the situation."
    new "Ja, ich hab gemerkt, dass sie damit nicht glücklich ist."

    # say L1166 pla
    old "But so what? You're a grown woman, and she can't be telling you what to do or not."
    new "Aber was soll's? Du bist eine erwachsene Frau, und sie kann dir nicht vorschreiben, was du tun oder lassen sollst."

    # say L1167 lyd
    old "I don't know, lately I've been thinking that she may be right and that I'm actually acting like a whore."
    new "Ich weiß nicht, lately habe ich gedacht, dass sie recht haben könnte und ich mich wie eine Hure benehme."

    # say L1168 pla
    old "Whoah, whoah, whoah."
    new "Woa, woa, woa."

    # say L1169 pla
    old "No, no, let's not go there."
    new "Nein, nein, lass uns das nicht machen."

    # say L1170 pla
    old "Listen, Anna's just angry, and since she's such a hothead she doesn't know how to deal with it."
    new "Hör zu, Anna ist einfach wütend und weil sie so ein Kurzschluss ist, weiß sie nicht damit umzugehen."

    # say L1171 pla
    old "All she knows is how to get angry, scream and be cruel. Don't pay any attention to what she says, ok?"
    new "Sie kennt nur Wut, Schreien und Grausamkeit. Mach dir nichts aus dem, was sie sagt, okay?"

    # say L1173 lyd
    old "Ok, I guess you have a point."
    new "Okay, ich schätze, du hast recht."

    # say L1175 pla
    old "Now, tell me how your night went."
    new "Jetzt, erzähl mir, wie dein Abend war."

    # say L1176 pla
    old "It sounds like it was a very good time."
    new "Klingt, als wäre es eine tolle Nacht gewesen."

    # say L1177 lyd
    old "Hmm, yeah, I guess so..."
    new "Hmm, ja, schätze schon..."

    # say L1178 pla
    old "Yeah? Because you don't look very excited about it."
    new "Ja? Denn du siehst nicht gerade begeistert aus."

    # say L1179 lyd
    old "Well... you see."
    new "Na ja... siehst du."

    # say L1180 lyd
    old "The date went well, he was a perfect gentleman, and I think we had a lot of chemistry. He actually said he wanted to see me again soon."
    new "Das Date war gut, er war ein perfekter Gentleman, und ich denke, wir hatten viel Chemie. Er hat tatsächlich gesagt, dass er mich bald wiedersehen will."

    # say L1181 lyd
    old "But that got me thinking, with the way things are going, that we could end up having sex next time."
    new "Aber das hat mich nachdenken lassen, bei der Art, wie es läuft, könnten wir beim nächsten Mal Sex haben."

    # say L1182 pla
    old "Well, yeah, that's usually how those things go."
    new "Na ja, so läuft das meistens."

    # say L1183 pla
    old "You don't want to?"
    new "Willst du nicht?"

    # say L1184 lyd
    old "It's not that, I obviously want to."
    new "Das ist es nicht, ich will es natürlich."

    # say L1185 lyd
    old "The problem is that it's been a while since I had sex for the last time."
    new "Das Problem ist, dass es schon eine Weile her ist, seit ich das letzte Mal Sex hatte."

    # say L1186 lyd
    old "Even with my deceased husband, the last few years of our relationship we barely had any contact."
    new "Selbst mit meinem verstorbenen Mann, in den letzten Jahren unserer Beziehung hatten wir kaum noch Kontakt."

    # say L1187 lyd
    old "I'm afraid that I'm not gonna be good enough or that I'll end up disappointing him."
    new "Ich habe Angst, dass ich nicht gut genug bin oder ihn enttäusche."

    # say L1188 lyd
    old "After all this time it's a lot of pressure you know?"
    new "Nach so langer Zeit ist das echt viel Druck, weißt du?"

    # say L1189 lyd
    old "Especially since I'm not sure he'll like my body."
    new "Vor allem, weil ich nicht sicher bin, ob ihm mein Körper gefällt."

    # say L1190 lyd
    old "What if he thinks that I'm too old? or that I'm not hot enough?"
    new "Was, wenn er denkt, dass ich zu alt bin? Oder dass ich nicht heiß genug bin?"

    # say L1191 pla
    old "What? Not at all!"
    new "Was? Auf keinen Fall!"

    # say L1192 pla
    old "Don't even think about it. That guy has already seen pictures of you, and if he says that you're hot, you should believe him."
    new "Denk gar nicht dran. Der Typ hat schon Fotos von dir gesehen, und wenn er sagt, dass du heiß bist, dann glaub ihm."

    # say L1193 pla
    old "Everything is gonna be fine, believe me."
    new "Alles wird gut, glaub mir."

    # say L1194 lyd
    old "Ok, I'll stop worrying about it. Thanks again [pla], I don't know what I would do without all your help."
    new "Ok, ich mache mir keine Sorgen mehr. Danke nochmal [pla], ich weiß nicht, was ich ohne deine Hilfe machen würde."

    # say L1196 pla
    old "Don't even mention it."
    new "Das ist doch selbstverständlich."

    # say L1198 pla
    old "So, since I'm already here, do you want us to browse through some tinder profiles?"
    new "Also, da ich schon mal hier bin, sollen wir uns ein paar Tinder-Profilseiten anschauen?"

    # say L1200 lyd
    old "I don't really feel like doing that right now, besides, since Anna is in her room she could come down any second."
    new "Ich hab jetzt echt keine Lust darauf, außerdem könnte Anna jederzeit runterkommen."

    # say L1201 lyd
    old "I don't want to have to deal with her temper again today."
    new "Ich will heute nicht noch einmal mit ihrem Temperament konfrontiert werden."

    # say L1202 pla
    old "I understand, then I guess it's better if I leave."
    new "Ich verstehe, dann ist es wohl besser, wenn ich gehe."

    # say L1203 pla
    old "But before I go, remember what I told you."
    new "Aber bevor ich gehe, denk dran, was ich dir gesagt hab."

    # say L1204 pla
    old "You're a beautiful woman, and you're in your right to be or date anyone."
    new "Du bist eine wunderschöne Frau und hast das Recht, mit wem du willst zusammen zu sein."

    # say L1205 pla
    old "No matter what Anna thinks about that. She can keep her opinions to herself."
    new "Egal was Anna darüber denkt. Sie kann ihre Meinung für sich behalten."

    # say L1206 lyd
    old "Thank you [pla] I'll be sure to remember that."
    new "Danke [pla], ich werd's mir merken."

    # say L1207 pla
    old "That's cool, goodbye then."
    new "Das ist cool, dann tschüss."

    # say L1226 lyd
    old "Hi [pla], I guess I'm fine, thank you."
    new "Hi [pla], ich denke, ich bin okay, danke."

    # say L1227 pla
    old "You guess? What happened?"
    new "Du vermutest? Was ist passiert?"

    # say L1228 lyd
    old "Oh [pla], it's just so bad..."
    new "Oh [pla], es ist einfach so schlimm..."

    # say L1229 pla
    old "What's bad? You're worrying me now, tell me."
    new "Was ist schlimm? Du machst mir jetzt echt Sorgen, erzähl schon."

    # say L1231 lyd
    old "Well, the thing is that I did go on that date with the guy I told you about."
    new "Na ja, der Sache ist es, dass ich tatsächlich mit dem Typen ausgegangen bin, von dem ich dir erzählt habe."

    # say L1232 lyd
    old "I suppose it went well, just like last time he was a gentleman, the conversation was good and we had a good time."
    new "Ich denke, es war gut, genauso wie beim letzten Mal. Er war ein Gentleman, wir haben uns gut unterhalten und es war schön."

    # say L1233 lyd
    old "The problem came later... when we were about to have sex."
    new "Das Problem kam später... als wir gerade Sex haben wollten."

    # say L1234 pla
    old "Ohh... Why?"
    new "Ohh... Warum?"

    # say L1235 lyd
    old "Well, after dinner he asked me if I wanted to continue the evening at his house, I said yes and we went there."
    new "Na ja, nach dem Abendessen hat er mich gefragt, ob ich den Abend bei ihm weiterführen will, ich hab gesagt, ja, und wir sind dorthin gegangen."

    # say L1236 lyd
    old "I really wanted to do it, and things were going so well..."
    new "Ich wollte es wirklich, und alles lief so gut..."

    # say L1237 lyd
    old "But, I just couldn't do it... I got nervous and uncomfortable."
    new "Aber ich konnte es einfach nicht... Ich bin nervös und unwohl geworden."

    # say L1239 pla
    old "Was it something he did?"
    new "War es etwas, was er getan hat?"

    # say L1241 lyd
    old "Oh no, nothing like that, he was actually very nice, as I said, a perfect gentleman."
    new "Oh nein, so war es gar nicht, er war tatsächlich sehr nett, wie ich schon sagte, ein perfekter Gentleman."

    # say L1242 lyd
    old "I was the one with the problem, no matter what we tried all I could think was about my husband, and Anna's words."
    new "Ich war das Problem, egal was wir versuchten, ich konnte nur an meinen Mann und Annas Worte denken."

    # say L1243 lyd
    old "Telling me that I was ugly and undesirable, that what I was doing was wrong."
    new "Mir sagen, dass ich hässlich und unattraktiv bin, dass das, was ich tue, falsch ist."

    # say L1244 lyd
    old "After a while, I just backed out and asked him to drive me home."
    new "Nach einer Weile bin ich einfach ausgestiegen und habe ihn gebeten, mich nach Hause zu fahren."

    # say L1245 lyd
    old "After all I think Mrs. Jones was right, at my age it's just impossible for me to form a connection with another person."
    new "Nach allem, was passiert ist, denke ich, dass Mrs. Jones recht hatte. In meinem Alter ist es einfach unmöglich, eine Verbindung zu jemandem aufzubauen."

    # say L1246 lyd
    old "I think I should just give up and become a church lady like her."
    new "Ich denke, ich sollte einfach aufgeben und eine Kirchenfrau wie sie werden."

    # say L1247 pla
    old "Wait, wait, don't say that."
    new "Warte, warte, sag das nicht."

    # say L1248 pla
    old "Listen, what you went through is perfectly normal, you don't need to beat yourself over it."
    new "Hör zu, was du durchgemacht hast, ist total normal, du musst dich deswegen nicht fertig machen."

    # say L1249 pla
    old "Sure it would be good if you could have sex with the guy."
    new "Klar wäre es gut, wenn du mit ihm schlafen könntest."

    # say L1250 pla
    old "But think about it, you were out of the dating game for a long time, it's ok to feel insecure."
    new "Aber denk dran, du warst lange aus dem Dating-Spiel raus, es ist okay, unsicher zu sein."

    # say L1251 pla
    old "There's no need for you to feel that you're going to become someone like Mrs. Jones."
    new "Du musst dich nicht wie Mrs. Jones fühlen."

    # say L1252 lyd
    old "That's very cute of you, but [pla] I don't know, it's just too difficult."
    new "Das ist sehr süß von dir, aber [pla] ich weiß nicht, es ist einfach zu schwierig."

    # say L1254 pla
    old "It is, but that doesn't mean you should give up, or pay any attention to what Anna says."
    new "Das ist es, aber das heißt nicht, dass du aufgeben sollst oder auf das, was Anna sagt, hören musst."

    # say L1255 pla
    old "Listen, you're doing this for yourself, not for Anna, or your husband or anyone else, just for you."
    new "Hör zu, du machst das für dich selbst, nicht für Anna, deinen Mann oder irgendjemand anderen, sondern nur für dich."

    # say L1256 pla
    old "You have every right to be happy and to search for that happiness."
    new "Du hast jedes Recht, glücklich zu sein und nach diesem Glück zu suchen."

    # say L1257 pla
    old "So, there's no need for you to feel guilty about living your life."
    new "Dann musst du dich also nicht schuldig fühlen, dein Leben zu leben."

    # say L1258 lyd
    old "I understand what you're saying, but I don't know how to do it."
    new "Ich verstehe, was du meinst, aber ich weiß nicht, wie ich das machen soll."

    # say L1259 lyd
    old "How do I manage to do it when I feel so uncomfortable?"
    new "Wie soll ich das schaffen, wenn ich mich so unwohl fühle?"

    # say L1260 lyd
    old "I wasn't able to even get naked!"
    new "Ich bin nicht mal dazu gekommen, mich auszuziehen!"

    # say L1261 lyd
    old "I can't imagine even trying to be even more intimate in a physical way."
    new "Ich kann mir nicht vorstellen, wie ich überhaupt versuchen soll, körperlich noch intimer zu werden."

    # say L1263 pla
    old "Hmm... It's just you haven't done it in a long time, you're a bit... Rusty..."
    new "Hmm... Es ist nur, du hast es einfach lange nicht mehr gemacht, du bist ein bisschen... Rostig..."

    # say L1264 lyd
    old "But how do I fix it? How can I ever be able to have some sexual contact again?"
    new "Aber wie mache ich das wieder gut? Wie kann ich jemals wieder zu sexuellen Kontakten fähig sein?"

    # say L1266 pla
    old "Wait... What about me?"
    new "Warte... Was ist mit mir?"

    # say L1269 pla
    old "Well, you say that, but you've been able to do a few sexual things with... me."
    new "Na ja, du sagst das, aber du hast schon ein paar sexuelle Dinge mit... mir gemacht."

    # say L1270 lyd
    old "Oh... Yeah well, that's different."
    new "Oh... Ja, das ist anders."

    # say L1273 lyd
    old "I don't know... with you it doesn't feel like I'm doing some weird thing with a stranger, you just feel... safer."
    new "Ich weiß nicht... mit dir fühlt es sich nicht so an, als würde ich etwas Seltsames mit einem Fremden machen, du fühlst dich einfach... sicherer."

    # say L1274 lyd
    old "With this other guy I felt very awkward like we didn't have a bond, or anything connecting us."
    new "Mit dem anderen Typen habe ich mich total unwohl gefühlt, als hätten wir keine Verbindung oder so."

    # say L1275 pla
    old "Hmph, I think I get what you're saying."
    new "Hmpf, ich glaube, ich verstehe, was du meinst."

    # say L1277 lyd
    old "Oh, I have an idea."
    new "Oh, ich hab eine Idee."

    # say L1280 lyd
    old "I think that my problem might be taking that first step to physical intimacy. That's what's holding me back."
    new "Ich denke, mein Problem könnte darin liegen, den ersten Schritt zur körperlichen Intimität zu wagen. Das hält mich zurück."

    # say L1281 lyd
    old "It's just as you said, I'm rusty, so, maybe I just need a bit of practice?"
    new "Genau wie du gesagt hast, ich bin eingerostet, also, vielleicht brauche ich einfach ein bisschen Übung?"

    # say L1282 pla
    old "Practice?"
    new "Übung?"

    # say L1283 lyd
    old "I think that if I do it with someone at least once, from there on it should be a lot easier with other guys."
    new "Ich denke, wenn ich es mit jemandem wenigstens einmal mache, wird es danach mit anderen Typen viel leichter sein."

    # say L1285 pla
    old "Ohh, I get it... Well, that makes a lot of sense. I think you're right."
    new "Ohh, ich verstehe... Das ergibt Sinn. Ich denke, du hast recht."

    # say L1286 pla
    old "But who are you gonna do it with first?"
    new "Aber mit wem willst du es als Erstes tun?"

    # say L1287 lyd
    old "Well... so far there's only one man I think I feel comfortable enough to do it with."
    new "Na ja... bisher gibt es nur einen Mann, mit dem ich mich wohl genug fühle, um es zu tun."

    # say L1288 pla
    old "And who is it?"
    new "Und wer ist es?"

    # say L1289 pla
    old "Oh wait, you don't mean... me?!"
    new "Oh warte, du meinst doch nicht... mich?!"

    # say L1290 lyd
    old "What can I tell you? As you've seen you're the only one with which I've been able to do anything without feeling weird."
    new "Was soll ich dir sagen? Wie du gesehen hast, bist du der Einzige, mit dem ich so etwas tun kann, ohne mich seltsam zu fühlen."

    # say L1291 pla
    old "B- but you know."
    new "B- aber du weißt ja."

    # say L1293 lyd
    old "I know, it sounds crazy, and maybe I'm just saying this impulsively, but this wouldn't be the first time we do something of the sort."
    new "Ich weiß, das klingt verrückt, und vielleicht sage ich das spontan, aber das wäre nicht das erste Mal, dass wir so was machen."

    # say L1294 lyd
    old "And I think that I wouldn't have any problem if it were you, I'm clearly comfortable with you...."
    new "Und ich denke, ich hätte damit kein Problem, wenn es dich betrifft, ich fühle mich offensichtlich wohl bei dir."

    # say L1295 pla
    old "B- but, that would be way too far over the line!"
    new "Aber, das wäre viel zu weit über die Grenze!"

    # say L1296 lyd
    old "You are right... I better stop this and settle down."
    new "Du hast recht... Ich sollte besser damit aufhören und mich beruhigen."

    # say L1297 pla
    old "No, no, it's not about that."
    new "Nein, nein, es geht nicht darum."

    # say L1298 pla
    old "It's just that the solution sounds way too drastic."
    new "Es ist nur, dass die Lösung viel zu drastisch klingt."

    # say L1299 pla
    old "Why don't you try other solutions first? Going to therapy, or maybe trying with some other dude..."
    new "Warum probierst du nicht erst andere Lösungen aus? Therapie machen oder mal mit einem anderen Typen..."

    # say L1300 lyd
    old "Oh please, you know that's not going to help me!"
    new "Oh bitte, du weißt doch, dass das mir nicht helfen wird!"

    # say L1301 lyd
    old "Besides, this isn't easy for me either."
    new "Außerdem ist es für mich auch nicht einfach."

    # say L1302 lyd
    old "Just imagine how embarrassing it would be to keep trying with one and another person without managing to do anything."
    new "Stell dir vor, wie peinlich es wäre, es immer wieder mit einem und dem nächsten zu versuchen, ohne überhaupt etwas zu erreichen."

    # say L1304 lyd
    old "It's not like I want my life to be in shambles like this, you know [pla]?"
    new "Es ist ja nicht so, als wollte ich, dass mein Leben so chaotisch ist, weißt du [pla]?"

    # say L1305 lyd
    old "All I'm telling you is that I'm trying to put my life back together so that I don't end up like Mrs. Jones."
    new "Alles, was ich sage, ist, dass ich versuche, mein Leben wieder in Ordnung zu bringen, damit ich nicht wie Mrs. Jones ende."

    # say L1306 lyd
    old "Won't you help me with that?"
    new "Wirst du mir dabei helfen?"

    # say L1307 lyd
    old "After all, it would just be this one time, just so that I get used to it again."
    new "Schließlich wäre es doch nur dieses eine Mal, damit ich mich wieder daran gewöhnen kann."

    # say L1308 pla
    old "Hmm, I suppose what you're saying makes sense."
    new "Hmm, ich schätze, was du sagst, ergibt Sinn."

    # say L1309 pla
    old "I'm not sure I like this, but ok, I suppose we can do it."
    new "Ich bin mir nicht sicher, ob ich das mag, aber okay, ich schätze, wir können es machen."

    # say L1310 lyd
    old "Really? Thank you so much [pla]!"
    new "Wirklich? Danke schön [pla]!"

    # say L1312 lyd
    old "Don't worry just lie on the couch and leave everything to me!"
    new "Keine Sorge, leg dich einfach auf die Couch und lass alles auf mich kommen!"

    # say L1327 pla
    old "I think the best thing is that I go for today."
    new "Ich denke, das Beste ist, ich gehe heute."

    # say L1328 pla
    old "Are you going to keep talking with the guy?"
    new "Sprichst du weiter mit ihm?"

    # say L1329 lyd
    old "I will, I really like him, so, I hope we can have another date."
    new "Ich werd's tun, ich mag ihn wirklich, also hoffe ich, dass wir noch mal ausgehen können."

    # say L1330 lyd
    old "And this time I'm sure everything will go well."
    new "Und dieses Mal bin ich mir sicher, dass alles gut läuft."

    # say L1331 pla
    old "I'm sure it will, good luck."
    new "Ich bin sicher, dass es klappen wird, viel Glück."

    # say L1350 lyd
    old "Oh hi [pla]! It's good seeing you."
    new "Oh hallo [pla]! Schön, dich zu sehen."

    # say L1352 lyd
    old "I'm fine thanks for asking!"
    new "Mir geht's gut, danke fürs Nachfragen!"

    # say L1353 pla
    old "Great, so tell me, everything went well on your date, right?"
    new "Super, dann erzähl mal, war alles gut bei deinem Date, oder?"

    # say L1354 lyd
    old "Oh, that? Not at all!"
    new "Oh, das? Überhaupt nicht!"

    # say L1355 pla
    old "What's with that face?"
    new "Was ist mit diesem Gesicht?"

    # say L1356 pla
    old "Don't tell me things went wrong again on your date."
    new "Sag bloß, dein Date ist wieder schiefgelaufen."

    # say L1357 lyd
    old "Ugh. Then I don't know what else to tell you."
    new "Ugh. Dann weiß ich auch nicht, was ich dir noch sagen soll."

    # say L1360 lyd
    old "Nothing happened, that's the problem."
    new "Nichts ist passiert, das ist das Problem."

    # say L1361 pla
    old "Nothing? Nothing at all?"
    new "Nichts? Gar nichts?"

    # say L1362 lyd
    old "Well, yes..."
    new "Na ja, schon..."

    # say L1363 lyd
    old "Oh [pla], that was so frustrating"
    new "Oh [pla], das war so frustrierend"

    # say L1364 pla
    old "But why?"
    new "Aber warum?"

    # say L1366 lyd
    old "I don't know, the date went well, he was as well behaved as always, but when the moment came I just felt that I couldn't do it."
    new "Ich weiß nicht, das Date war gut, er war wie immer tadellos, aber als der Moment kam, hab ich einfach gemerkt, dass ich es nicht kann."

    # say L1368 pla
    old "But, I thought you had gotten over your intimacy problem, that's why we did what we did, right?"
    new "Aber ich dachte, du hättest dein Problem mit Intimität überwunden, deshalb haben wir das gemacht, oder?"

    # say L1369 lyd
    old "Yeah, yeah, and I think it did help. After all, this time I wasn't scared or feeling bad or anything."
    new "Ja, ja, und ich denke, es hat geholfen. Immerhin war ich dieses Mal nicht ängstlich oder unwohl oder so."

    # say L1370 lyd
    old "I just didn't want him to put his hands on me, I don't know, I guess we just didn't have any sexual attraction."
    new "Ich wollte einfach nicht, dass er mich anfasst, keine Ahnung, ich denke, da war einfach keine sexuelle Anziehung."

    # say L1371 lyd
    old "You have no idea how annoyed I am because of that."
    new "Du hast keine Ahnung, wie genervt ich deswegen bin."

    # say L1372 pla
    old "Hmm, well, if you say that you didn't feel bad or scared, I guess that's a good thing."
    new "Hmm, na ja, wenn du sagst, dass du dich nicht schlecht oder ängstlich gefühlt hast, dann ist das wohl ein gutes Zeichen."

    # say L1373 pla
    old "Those things happen."
    new "Das passiert halt."

    # say L1374 lyd
    old "I'm still very frustrated though."
    new "Ich bin trotzdem noch sehr frustriert."

    # say L1375 lyd
    old "But I understand that the problem wasn't me, I think the problem was that I didn't like him enough."
    new "Aber ich verstehe, dass das Problem nicht ich war, ich denke das Problem war, dass ich ihn einfach nicht genug gemocht habe."

    # say L1377 pla
    old "Hmph, if you say so."
    new "Hmpf, wenn du das sagst."

    # say L1378 lyd
    old "Oh, don't be mad, at least I'm not feeling bad about it."
    new "Oh, sei nicht sauer, zumindest mache ich mir deswegen keine Sorgen."

    # say L1379 lyd
    old "Just a little bit annoyed."
    new "Einen kleinen Ärger hab ich schon."

    # say L1380 pla
    old "I guess we can call that a silver lining..."
    new "Ich schätze, das können wir als Silberstreif betrachten..."

    # say L1381 pla
    old "But if that's not the thing that has you in a good mood, what is it?"
    new "Aber wenn das nicht der Grund für deine gute Laune ist, was ist es dann?"

    # say L1382 lyd
    old "Right, that!"
    new "Stimmt, das!"

    # say L1383 lyd
    old "I've been talking to another guy, and actually, things seem to be going well."
    new "Ich habe mit einem anderen Typen gesprochen, und ehrlich gesagt, läuft es ziemlich gut."

    # say L1384 lyd
    old "We haven't met, but I really like his personality."
    new "Wir haben uns noch nicht getroffen, aber ich mag seine Persönlichkeit echt."

    # say L1385 pla
    old "That's cool."
    new "Das ist cool."

    # say L1387 lyd
    old "Hmm, in fact, I think you could help me out with that."
    new "Hmm, eigentlich denke ich, dass du mir dabei helfen könntest."

    # say L1388 pla
    old "Help you?"
    new "Dir helfen?"

    # say L1389 lyd
    old "Yeah, to talk to him, just before you arrived we were in the middle of a conversation."
    new "Ja, um mit ihm zu reden, wir waren gerade mitten in einem Gespräch, als du gekommen bist."

    # say L1390 lyd
    old "I think you could help me chat with him."
    new "Ich denke, du könntest mir helfen, mit ihm zu reden."

    # say L1391 pla
    old "Hmm, I don't know... I mean, if you've been talking with these guys I think you can keep up the conversation without my help."
    new "Hmm, ich weiß nicht... Ich meine, wenn du schon mit diesen Typen redest, denkst du nicht, dass du die Konversation auch ohne meine Hilfe weiterführen kannst?"

    # say L1392 lyd
    old "Oh, don't say that, you are really a great help to me."
    new "Oh, sag das nicht, du bist mir wirklich eine große Hilfe."

    # say L1393 lyd
    old "But you know I have some problems with the keyboard and his expressions."
    new "Aber du weißt, ich habe ein paar Probleme mit der Tastatur und seinen Ausdrücken."

    # say L1394 pla
    old "I guess you're right. I suppose it would do no harm to give you a hand."
    new "Ich schätze, du hast recht. Es würde sicherlich nicht schaden, dir ein bisschen zu helfen."

    # say L1396 lyd
    old "Great, then, let's go to the sofa to chat more comfortably."
    new "Super, dann lass uns aufs Sofa gehen, um es uns gemütlicher zu machen."

    # say L1411 lyd
    old "This is where we were in the conversation a little before you arrived."
    new "Das war der Stand der Dinge, kurz bevor du gekommen bist."

    # say L1412 pla
    old "I see, things seem to be going well."
    new "Ich sehe, die Dinge scheinen gut zu laufen."

    # say L1413 lyd
    old "I guess they are... so what do I tell him now?"
    new "Ich schätze, das sind sie... und was sage ich ihm jetzt?"

    # say L1414 pla
    old "Well, as I told you last time, you have to be playful, but a little suggestive."
    new "Na, wie ich dir letztes Mal gesagt habe, musst du spielerisch sein, aber ein bisschen anzüglich."

    # say L1415 lyd
    old "I was​​ thinking of telling him something about my clothes, about how sexy they would be."
    new "Ich dachte daran, ihm was von meinen Klamotten zu erzählen, wie sexy die sein würden."

    # say L1416 pla
    old "That sounds good, how do you want me to say it?"
    new "Das klingt gut, wie soll ich es sagen?"

    # say L1417 lyd
    old "Like this 'To start, I would get there wearing a trench coat'."
    new "So: Zum Anfang würde ich da in einem Trenchcoat auftauchen."

    # say L1419 pla
    old "What? That's not sexy at all!"
    new "Was? Das ist überhaupt nichtsexy!"

    # say L1420 lyd
    old "Of course it isn't, it's something I read in a magazine a long time ago, just write it."
    new "Natürlich nicht, das hab ich mal in einem Magazin gelesen, schreib es einfach."

    # say L1424 pla
    old "He answered 'a trench coat?' See? That's not sexy."
    new "Er hat geantwortet 'einen Trenchcoat?' Siehst du? Das ist nichtsexy."

    # say L1426 lyd
    old "Fufu, what's sexy is what I would bring underneath."
    new "Fufu, wassexy ist, was ich drunter anhabe."

    # say L1427 lyd
    old "Write 'Then I would take it off, to let you see the black lingerie that I'm wearing underneath.'"
    new "Dann würde ich es ausziehen, damit du die schwarze Wäsche sehen kannst, die ich darunter trage."

    # say L1429 pla
    old "Oh! I see what you mean."
    new "Oh! Jetzt verstehe ich, was du meinst."

    # say L1432 pla
    old "He really seemed to like that, now he's asking 'Then what else?'"
    new "Er schien das wirklich zu mögen, jetzt fragt er: „Dann was noch?“"

    # say L1434 lyd
    old "I would take you by the hand and bring you to the couch, where I would want you to lay down."
    new "Ich würde dich an der Hand nehmen und zu der Couch bringen, wo ich will, dass du dich hinlegst."

    # say L1438 pla
    old "He says 'Oh yeah? And what would you do once I'm laying down on the couch baby?'"
    new "Oh ja? Und was würdest du tun, wenn ich auf der Couch liege, Baby?"

    # say L1439 lyd
    old "I would lay down on top of you, and I would take those lips of yours on a hot, rough kiss."
    new "Ich würde mich auf dich legen und deine Lippen zu einem heißen, rauen Kuss nehmen."

    # say L1442 pla
    old "He wrote 'I like that! But that's all you'd want?'"
    new "Ich mag das! Aber das ist alles, was du willst?"

    # say L1444 lyd
    old "Haha, so cute, tell him 'Well, aren't we a little impatient tonight?'"
    new "Haha, so süß, sag ihm 'Na, sind wir heute ein bisschen ungeduldig?'"

    # say L1447 pla
    old "Hmm, he says 'I'm sorry baby, it's just that I can't resist you.'"
    new "Hmm, er sagt: „Tut mir leid, Schatz, ich kann dir einfach nicht widerstehen.“"

    # say L1448 lyd
    old "That's very cute of him."
    new "Das ist sehr süß von ihm."

    # say L1449 lyd
    old "Write 'It's ok, I can't resist you either.'"
    new "Das ist okay, ich kann dir auch nicht widerstehen."

    # say L1451 lyd
    old "So while we're kissing, I slowly bring my hand down your chest, pass your abs... and over that big bulging dick under your pants."
    new "Während wir uns küssen, lasse ich meine Hand langsam über deinen Brustkorb gleiten, deine Sixpack-Muskeln streifen... und dann über diese große, pralle Beule in deiner Hose."

    # say L1462 pla
    old "That's it baby! Yeah, you know just what I want."
    new "Das ist es, Baby! Ja, du weißt genau, was ich will."

    # say L1463 lyd
    old "Fufu, and you haven't seen anything yet..."
    new "Fufu, und das ist erst der Anfang..."

    # say L1466 pla
    old "Tell me more!"
    new "Erzähl mir mehr!"

    # say L1467 lyd
    old "I'll feel your big hard cock with my hand, and that is gonna make me horny..."
    new "Ich werde deinen großen harten Schwanz mit meiner Hand berühren, und das wird mich richtig anmachen..."

    # say L1478 lyd
    old "And I'm going to rub it over your pants, feeling how big it is..."
    new "Und ich werde es über deinen Hosenbund reiben, spüren, wie groß es ist..."

    # say L1481 pla
    old "Ohh, you'll love to feel every inch of me..."
    new "Ohh, du wirst jede einzelne Stelle an mir spüren..."

    # say L1482 lyd
    old "I already love it... But you'll love what I'm going to do next..."
    new "Ich liebe es schon... Aber du wirst noch mehr lieben, was ich als Nächstes mache..."

    # say L1485 pla
    old "Ohh yes babe, what are you gonna do next?"
    new "Ohh ja Babe, was wirst du als Nächstes tun?"

    # say L1486 lyd
    old "Well, I'm going to kneel in front of you and I'm going to take out that huge cock."
    new "Na ja, ich werde vor dir knien und deinen riesigen Schwanz herausnehmen."

    # say L1495 lyd
    old "Then, I'll bring my head down and kiss and lick the tip of your cock."
    new "Dann senke ich meinen Kopf und küsse und lecke die Spitze deines Schwanzes."

    # say L1504 pla
    old "Mmm, I love that, I love how you kiss it."
    new "Mmm, ich liebe das, ich liebe, wie du es küssst."

    # say L1514 lyd
    old "That was a great conversation! Wasn't it?"
    new "Das war ein toller Gespräch, oder?"

    # say L1516 pla
    old "Uhm, sure... I was very good."
    new "Uhm, klar... Ich war sehr gut."

    # say L1517 lyd
    old "I think this might be the right guy for me, he's hot, he's into me. He's just great, right?"
    new "Ich denke, das könnte der Richtige für mich sein. Er ist heiß, er steht auf mich. Er ist einfach toll, oder?"

    # say L1518 pla
    old "Yeah, yeah... He sounds like a great guy."
    new "Ja, ja... Er klingt wie ein toller Typ."

    # say L1519 pla
    old "Anyway, I think I should probably go now."
    new "Na ja, ich glaube, ich sollte jetzt besser gehen."

    # say L1520 pla
    old "You know, before Anna arrives and stuff."
    new "Du weißt schon, bevor Anna kommt und so."

    # say L1522 lyd
    old "Yeah, that's probably better. Thank you so much."
    new "Ja, das ist wahrscheinlich besser. Danke schön."

    # say L1538 pla
    old "Whoaa?! What are you doing here?!"
    new "Whoaa?! Was machst du hier?!"

    # say L1539 lyd
    old "H- Heelloo [pla]!"
    new "H- Hallo [pla]!"

    # say L1540 lyd
    old "Did I zurprish you?"
    new "Hab ich dich überrascht?"

    # say L1542 lyd
    old "Did I s- surprize you?!"
    new "Hast du dich s- überrascht?"

    # say L1543 pla
    old "Oh! Yes, you did! Why are you in my room?"
    new "Oh! Ja, das hast du! Was machst du in meinem Zimmer?"

    # say L1544 pla
    old "How did you get in?"
    new "Wie bist du reingekommen?"

    # say L1545 lyd
    old "Sue gave 'e a key."
    new "Sue hat mir einen Schlüssel gegeben."

    # say L1547 pla
    old "I see, well, that makes sense."
    new "Ich sehe, das ergibt Sinn."

    # say L1548 pla
    old "But you still haven't answered, what are you doing in my room? And this smell... It's alcohol."
    new "Aber du hast immer noch nicht geantwortet, was machst du in meinem Zimmer? Und dieser Geruch... Es ist Alkohol."

    # say L1549 pla
    old "Are you drunk? I thought tonight was the night of your date."
    new "Bist du betrunken? Ich dachte, heute Abend ist dein Date."

    # say L1550 pla
    old "Shouldn't you be with the guy?"
    new "Solltest du nicht bei ihm sein?"

    # say L1551 lyd
    old "I 'uess I zhould be. But it didn't go well, like a' all."
    new "Ich glaube, ich sollte. Aber es hat nicht gut gelaufen, wie üblich."

    # say L1552 pla
    old "It didn't? What happened this time?"
    new "Hat es nicht? Was ist dieses Mal passiert?"

    # say L1553 lyd
    old "I don't know!"
    new "Ich hab's einfach nicht geschafft, als der Moment kam, hab ich einfach... nichts gespürt."

    # say L1554 lyd
    old "I just wasn't able to, when 'e moment came I just felt... nothing."
    new "Ich hab's einfach nicht geschafft, als der Moment kam, hab ich einfach... nichts gespürt."

    # say L1555 pla
    old "What do you mean nothing? I thought you liked the guy."
    new "Was meinst du mit nichts? Ich dachte, du magst ihn."

    # say L1556 lyd
    old "I did, I really did, and I think he's cute, and sexy, and funny... but I just wasn't able to focus on him."
    new "Ich hab's wirklich gewollt, und ich find ihn süß,sexy und witzig... aber ich konnte mich einfach nicht auf ihn konzentrieren."

    # say L1557 lyd
    old "I just didn't want to do it with him... but I still want to have sex."
    new "Ich wollte es einfach nicht mit ihm tun... aber ich will trotzdem Sex."

    # say L1559 pla
    old "I don't get it, if you want sex all you had to do was sleep with that guy."
    new "Ich verstehe das nicht, wenn du Sex willst, hättest du doch nur mit dem Typen schlafen müssen."

    # say L1560 lyd
    old "I don't really think that would have worked."
    new "Ich glaube nicht, dass das funktioniert hätte."

    # say L1561 lyd
    old "I think I was wrong about some'ing, I'm not the type of woman who... hips!"
    new "Ich glaube, ich habe mich in was geirrt, ich bin nicht die Art Frau, die... hips!"

    # say L1562 lyd
    old "Sorry... who sleeps around. I'm a one-man woman!"
    new "Tut mir leid... ich bin keine Frau, die herumschläft. Ich bin eine Frau für einen einzigen Mann!"

    # say L1563 pla
    old "I get that, but you told me you believed this guy was that one man, why did you suddenly backed out of it? "
    new "Ich verstehe, aber du hast mir gesagt, dass du an diesen Typen geglaubt hast, warum hast du plötzlich abgebrochen?"

    # say L1564 lyd
    old "D- don't you get it? I already have a man in my life."
    new "D- verstehst du das nicht? Ich habe schon einen Mann in meinem Leben."

    # say L1565 pla
    old "What? Don't tell me you're still thinking about grandpa."
    new "Was? Sag mir bloß, du denkst immer noch an Opa."

    # say L1566 pla
    old "I think you need to move on from that, that's the whole point, that you wouldn't be caught up in the past."
    new "Ich denke, du musst da drüber wegkommen, das ist der Punkt, dass du nicht im Vergangenen hängen bleibst."

    # say L1567 lyd
    old "No, not, no, think about it, there's only one man that I let, and want to touch me."
    new "Nein, nein, denk dran, es gibt nur einen Mann, dem ich das erlaube und den ich berühren will."

    # say L1569 pla
    old "You don't mean... me?!"
    new "Du meinst... mich?!"

    # say L1570 lyd
    old "Who else dummy?"
    new "Wer sonst, Dummerchen?"

    # say L1572 pla
    old "W- w- what?"
    new "W-was?"

    # say L1574 lyd
    old "As I said you're the only one I'll allow to touch me."
    new "Wie ich schon sagte, du bist der Einzige, dem ich das erlaube."

    # say L1575 lyd
    old "Not only that, you're the only man I was able to think about when I tried to do it with those other guys."
    new "Nicht nur das, du bist der einzige Mann, an den ich denken konnte, als ich es mit den anderen Typen versucht habe."

    # say L1576 lyd
    old "Oh [pla]! I know it sounds crazy to you, but that's how it is, and I don't want to go around wasting my time with those other men."
    new "Oh [pla]! Ich weiß, das klingt verrückt für dich, aber so ist es nun mal, und ich will meine Zeit nicht mit anderen Männern verschwenden."

    # say L1577 lyd
    old "After having seen all those dick pics they kept sending me, now I only think they're not much. Nothing compared to you."
    new "Nachdem ich all die Schwanzfotos gesehen habe, die sie mir geschickt haben, finde ich sie jetzt alle nicht mehr so toll. Verglichen mit dir sind sie nichts."

    # say L1578 lyd
    old "Besides, all of those guys, they're so childish, going all out on a phone."
    new "Außerdem, all diese Typen, sie sind so kindisch, total ausflippen auf dem Handy."

    # say L1579 lyd
    old "Ugh!"
    new "Pah!"

    # say L1580 lyd
    old "There's only one man I want to be intimate with..."
    new "Es gibt nur einen Mann, mit dem ich intim werden will..."

    # say L1581 pla
    old "Are you for real? Do you really mean this?"
    new "Bist du echt? Meinst du das wirklich?"

    # say L1582 lyd
    old "I do, I really do."
    new "Ich meine es ernst, ich meine es wirklich."

    # say L1583 lyd
    old "And I also know you want it too, come on, I know you liked it, the other times. So come on, let's just do it."
    new "Und ich weiß auch, dass du es willst, komm schon, ich weiß, dass dir die anderen Male gefallen hat. Also komm, lass uns es einfach tun."

    # say L1585 lyd
    old "Why do you think I came all the way here?"
    new "Warum denkst du, dass ich extra hierher gekommen bin?"

    # say L1586 lyd
    old "It wasn't only to tell you that I couldn't get it on with some other guys."
    new "Das war nicht der einzige Grund, warum ich hierher gekommen bin."

    # say L1587 pla
    old "But- but... w- we're in my room, I don't think we should."
    new "Aber aber... w-wir sind in meinem Zimmer, ich glaube, wir sollten das nicht tun."

    # say L1589 lyd
    old "Shhh, don't worry, nobody will listen to us. It's ok..."
    new "Psst, mach dir keine Sorgen, niemand wird uns belauschen. Alles gut..."

    # say L1596 lyd
    old "What do you think, I'm finally cutting loose and doing what I want."
    new "Was denkst du, ich lasse mich endlich gehen und tue, was ich will."

    # say L1605 lyd
    old "Ever since last time I've been wanting you to fuck me again."
    new "Seit dem letzten Mal will ich, dass du mich wieder fickst."

    # say L1606 lyd
    old "It's because of this dick of yours that I haven't been able to be with other guys."
    new "Wegen deinem Schwanz konnte ich seitdem keinen anderen Mann mehr an mich ran lassen."

    # say L1607 lyd
    old "I still remember how good it felt that one time."
    new "Ich kann es noch immer spüren, wie gut es damals war."

    # say L1608 lyd
    old "Now, let's not delay it anymore, I want it in me right now!"
    new "Jetzt lass uns nicht länger warten, ich will es jetzt in mir spüren!"

    # say L1617 lyd
    old "Oh! Oh my god! What am I doing in your room?!"
    new "Oh! Oh mein Gott! Was mache ich hier in deinem Zimmer?!"

    # say L1619 pla
    old "Uhh... Well... yesterday you came here."
    new "Uhh... Na ja... gestern bist du hierher gekommen."

    # say L1620 pla
    old "You were drunk and..."
    new "Du warst betrunken und..."

    # say L1621 lyd
    old "Oh God! That's right! I came in here when I was drunk!"
    new "Oh Gott! Das stimmt! Ich bin hier reingekommen, als ich betrunken war!"

    # say L1622 lyd
    old "Listen [pla], I'm sorry, I don't know what happened."
    new "Hör zu [pla], es tut mir leid, ich hab keine Ahnung, was passiert ist."

    # say L1623 lyd
    old "And I shouldn't be here, last night was just a product of the alcohol and nothing else."
    new "Und ich sollte nicht hier sein, letzte Nacht war nur ein Produkt des Alkohols und sonst nichts."

    # say L1625 lyd
    old "Don't say anything, it's getting very early and somebody could see us."
    new "Sag nichts, es wird sehr früh und jemand könnte uns sehen."

    # say L1626 lyd
    old "I should just leave, bye."
    new "Ich sollte einfach gehen, tschüss."

    # say L1644 pla
    old "Hi... Uhh, h- how are you... feeling?"
    new "Hi... Ähm, w-wie fühlst du dich?"

    # say L1645 lyd
    old "[pla]! H- hi."
    new "[pla]! H-hi."

    # say L1647 lyd
    old "Listen [pla] what happened last night made me think a lot about some stuff."
    new "Hör zu [pla], was letzte Nacht passiert ist, hat mich viel nachdenken lassen."

    # say L1648 lyd
    old "That was a horrible mistake, and it shouldn't have happened."
    new "Das war ein schrecklicher Fehler, und das hätte nicht passieren dürfen."

    # say L1649 lyd
    old "So, I decided we shouldn't see each other or talk again for a while."
    new "Dann hab ich mich entschieden, dass wir uns und miteinander reden sollten, aber erst mal eine Pause machen."

    # say L1651 pla
    old "Listen, I know you're shook and confused."
    new "Hör zu, ich weiß, dass du durcheinander und verwirrt bist."

    # say L1652 pla
    old "But I don't think you should be alone right now."
    new "Aber ich denke, du solltest jetzt nicht allein sein."

    # say L1653 lyd
    old "This isn't just a rash decision."
    new "Das ist keine spontane Entscheidung."

    # say L1654 lyd
    old "I think I made a mistake with this whole online dating thing."
    new "Ich glaube, ich habe einen Fehler gemacht mit dieser ganzen Online-Verabredungssache."

    # say L1655 lyd
    old "I did want to meet and date somebody."
    new "Ich wollte wirklich jemanden kennenlernen und daten."

    # say L1656 lyd
    old "But it got out of my hands at one point. You saw how much it was affecting me."
    new "Aber es hat sich irgendwann aus dem Ruder gelaufen. Du hast gesehen, wie sehr es mich belastet hat."

    # say L1657 lyd
    old "My sudden mood swings, and odd behavior."
    new "Meine plötzlichen Stimmungsschwankungen und seltsames Verhalten."

    # say L1658 lyd
    old "I don't want to deal with that anymore."
    new "Ich will damit nicht mehr zu tun haben."

    # say L1659 lyd
    old "No, what I need is time to think and get my bearings together."
    new "Nein, was ich brauche, ist Zeit zum Nachdenken und um mich zu sortieren."

    # say L1660 pla
    old "So, I shouldn't have helped you?"
    new "Dann hätte ich dir also nicht helfen sollen?"

    # say L1661 lyd
    old "That's not what I said. I actually think that your help was good for me, and I'm grateful for it."
    new "Das habe ich doch gar nicht gesagt. Eigentlich denke ich, dass deine Hilfe gut für mich war, und ich bin dir dankbar dafür."

    # say L1662 lyd
    old "It's just that I feel that things have gotten out of hand lately, so we should just relax for a little while. You know?"
    new "Es ist nur, dass ich das Gefühl habe, dass die Dinge lately aus dem Ruder gelaufen sind, wir sollten einfach ein bisschen entspannen. Verstehst du?"

    # say L1663 pla
    old "I guess that if that is what you want..."
    new "Ich schätze, wenn das ist, was du willst..."

    # say L1664 lyd
    old "It is, it really is."
    new "Es ist so, es ist wirklich so."

    # say L1666 pla
    old "I see... I understand. If you're ok, then I guess I better leave."
    new "Ich sehe... Ich verstehe. Wenn es dir gut geht, dann lass ich dich besser allein."

    # say L1667 pla
    old "But if you ever feel like you need to talk, don't hesitate to call me. Ok?"
    new "Aber wenn du mal reden musst, zögere nicht, mich anzurufen. Ok?"

    # say L1668 lyd
    old "I will, thank you."
    new "Ich werd's tun, danke."


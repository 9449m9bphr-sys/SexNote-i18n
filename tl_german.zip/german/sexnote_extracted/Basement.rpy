# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Basement.rpy
translate german strings:

    # say L16 mo2
    old "So? Are you ready to do something useful with your life?"
    new "Also? Sind Sie bereit, endlich etwas Nützliches mit Ihrem Leben anzufangen?"

    # say L18 pla
    old "Umm..."
    new "Äh..."

    # say L20 mo2
    old "I don't feel comfortable with a young pervert around me, but your [mo1rel] asked me to do this for you..."
    new "Ich fühle mich nicht wohl mit einem jungen Perversen in meiner Nähe, aber deine [mo1rel] hat mich gebeten, dir zu helfen..."

    # say L24 mo2
    old "Which means that this is an opportunity for you to see how to make some money..."
    new "Das bedeutet, dass du die Gelegenheit hast, zu sehen, wie man Geld verdienen kann..."

    # say L26 pla
    old "Sweet! You're going to teach me?"
    new "Cool! Du wirst mir was beibringen?"

    # say L28 mo2
    old "Oh, hell no! I'm not your damn teacher. Just do what I tell you. And watch what I do, then maybe you will learn on your own..."
    new "Oh nein! Ich bin nicht dein verdammter Lehrer. Mach einfach, was ich dir sage. Und sieh zu, was ich mache, dann lernst du vielleicht von selbst..."

    # say L30 pla
    old "Ok, ok... So what do you need me to do?"
    new "Ok, ok... Was soll ich also tun?"

    # say L32 mo2
    old "First of all, I don't need you. I'm letting you work for me and learn."
    new "Erstens, ich brauche dich nicht. Ich lasse dich für mich arbeiten und lernen."

    # say L34 mo2
    old "Secondly, if you try to peep on me at work or do something perverted, I will fire your ass. Understood?"
    new "Zweitens, wenn du versuchst, mich bei der Arbeit zu beobachten oder etwas Perverses zu machen, feuere ich dich. Verstanden?"

    # say L35 pla
    old "(This is going to be harder than I thought.)"
    new "Das wird härter werden, als ich dachte."

    # say L37 pla
    old "Hey! I'm not a-"
    new "Hey! Ich bin doch kein-"

    # say L39 mo2
    old "Shut up! Pervert!"
    new "Halt die Klappe! Perversling!"

    # say L41 pla
    old "...Ok. So, you are my boss now and I will respect you... Is that better?"
    new "Okay. Du bist also jetzt meine Chefin und ich werde dich respektieren... Ist das besser?"

    # say L43 mo2
    old "That's the respect you have to show me all the time, got it?. But enough talk, [pla]. Let's get to work!"
    new "Das ist der Respekt, den du mir immer zeigen musst, kapiert? Aber genug geredet, [pla]. Lass uns an die Arbeit gehen!"

    # say L45 pla
    old "Nice. What do you need me to do?"
    new "Schön. Was soll ich für dich tun?"

    # say L47 mo2
    old "I need you to take these documents to my office and give them to the secretary. Then come back to me."
    new "Ich brauche, dass Sie diese Unterlagen in mein Büro bringen und der Sekretärin geben. Dann kommen Sie wieder zu mir."

    # say L49 pla
    old "As you wish."
    new "Wie du wünschst."

    # say L64 pla
    old "Done! I already delivered the documents to Akita."
    new "Fertig! Ich habe die Dokumente schon bei Akita abgegeben."

    # say L66 mo2
    old "Well, was that very difficult?"
    new "Nun, war das sehr schwierig?"

    # say L68 pla
    old "Hmm, not really..."
    new "Hmm, nicht wirklich..."

    # say L70 mo2
    old "Alright. Look for me tomorrow to take a new delivery to Akita..."
    new "In Ordnung. Such mich morgen auf, um eine neue Lieferung nach Akita zu bringen..."

    # say L124 pla
    old "I must deliver the documents to Akita first."
    new "Ich muss erst die Unterlagen nach Akita bringen."

    # say L131 mo2
    old "Are you ready to work today? I don't want any interruptions from you..."
    new "Bist du bereit zu arbeiten heute? Ich will keine Unterbrechungen von dir..."

    # menu L134 
    old "Ready to work for you"
    new "Bereit, für Sie zu arbeiten"

    # say L138 mo2
    old "Ok then, You know what to do. Take these documents to my secretary, then come back to me..."
    new "Dann los, Sie wissen, was zu tun ist. Bringen Sie diese Unterlagen zu meiner Sekretärin und kommen Sie dann wieder zu mir..."

    # say L140 pla
    old "Of course, [mo2]!"
    new "Natürlich, [mo2]!"

    # menu L150 
    old "Not now"
    new "Nicht jetzt"

    # say L152 pla
    old "Actually, I have to do something first... I'll talk to you later."
    new "Eigentlich muss ich erst was machen... Ich rede später mit dir."

    # say L154 mo2
    old "Ugh. Ok, [pla]. Don't waste my time. Come talk to me when you're really ready"
    new "Ugh. Ok, [pla]. Verschwend nicht meine Zeit. Komm zu mir, wenn du wirklich bereit bist."

    # say L185 pla
    old "Uh... Nothing, I was just going to my bedroom, sorry."
    new "Äh... Nichts, ich wollte nur in mein Schlafzimmer, sorry."


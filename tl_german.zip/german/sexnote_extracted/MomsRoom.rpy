# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/MomsRoom.rpy
translate german strings:

    # say L22 pla
    old "(Let's try this again...)"
    new "Lass uns das noch mal versuchen..."

    # say L26 mo2
    old "Oh! Again, baby? You sure are horny these days."
    new "Oh! Wieder, Schatz? Du bist ja in letzter Zeit richtig geil."

    # say L28 mo2
    old "But I definitely do love it!"
    new "Aber ich liebe es definitiv!"

    # say L29 pla
    old "(Nice. She still thinks I'm my [mo1rel]!)"
    new "(Nett. Sie denkt immer noch, ich bin mein [mo1rel]!)"

    # say L39 pla
    old "(I'll just do it very carefully...)"
    new "(Ich werde es einfach sehr vorsichtig machen...)"

    # say L50 pla
    old "(What if...)"
    new "Was wenn..."

    # say L51 pla
    old "(Oh no... She would kill me... But on the other hand... What if she doesn't notice...)"
    new "Oh nein... Sie würde mich umbringen... Aber andererseits... Was, wenn sie es nicht bemerkt..."

    # say L52 pla
    old "(Well... I think there is a chance and if it works I can keep doing it.)"
    new "Na ja... Ich denke, da ist eine Chance und wenn es klappt, kann ich weitermachen."

    # say L53 pla
    old "(All I need to do is be really careful and I'll get out of this alive...)"
    new "Alles, was ich tun muss, ist vorsichtig zu sein und ich komme lebendig davon..."

    # say L55 pla
    old "(Oh man, I think I will regret this.)"
    new "Oh Mann, ich glaube, ich werde das bereuen."

    # say L57 mo2
    old "Is that you, baby?"
    new "Ist das du, Schatz?"

    # say L58 pla
    old "(OH SHIT! I'M DEAD MEAT!)"
    new "OH SHIT! ICH BIN FLEISCH FÜR DIE MESSER!"

    # say L59 mo2
    old "Mmm, is it my turn to be fucked?"
    new "Mmm, ist es meine Zeit, gevögelt zu werden?"

    # say L60 pla
    old "(What the hell? She thinks I'm [mo1]! Score!)"
    new "Was zur Hölle? Sie denkt, ich bin [mo1]! Volltreffer!"

    # say L67 mo2
    old "Oh, I see. You don't want the kids to hear us. Ok, then fuck me quietly..."
    new "Oh, ich verstehe. Du willst nicht, dass die Kinder uns hören. Okay, dann fick mich leise..."

    # say L68 pla
    old "(Yup. I'm definitely the luckiest guy ever!)"
    new "Klar. Ich bin definitiv der Glücklichste auf der Welt!"

    # say L69 mo2
    old "Mmm, fuck! It feels bigger than usual. Are you using a new strap-on?"
    new "Mmm, fick! Das fühlt sich größer an als sonst. Benutzt du ein neues Strap-on?"

    # say L71 mo2
    old "Fine. Be quiet, just please don't stop!"
    new "Fein. Sei still, hör bloß nicht auf!"

    # say L72 mo2
    old "(This is the best I've ever had!)"
    new "Das ist das Beste, was ich je hatte!"

    # say L81 pla
    old "(I will just do it carefully...)"
    new "(I werde vorsichtig sein...)"

    # say L90 pla
    old "(Damn!... She's amazing but... I should leave. I don't want to wake her up.)"
    new "Verdammt!... Sie ist unglaublich, aber... ich sollte gehen. Ich will sie nicht wecken."

    # say L100 pla
    old "(Carefully...)"
    new "Vorsichtig..."

    # say L104 pla
    old "(Fuck! She is almost naked! So sexy.)"
    new "Scheiße! Sie ist fast nackt! So sexy."

    # say L105 pla
    old "(I should go, though. I don't want to wake her up.)"
    new "Ich sollte gehen, sonst wecke ich sie noch auf."

    # say L116 pla
    old "(She's sleeping? I shouldn't make any noise.)"
    new "Sie schläft? Ich sollte keinen Lärm machen."

    # say L134 pla
    old "(Wait... What was that noise?)"
    new "Warte... Was war das für ein Geräusch?"

    # say L137 pla
    old "It's coming from my [mo1rel]'s bedroom... I should go check it out."
    new "Es kommt aus dem Schlafzimmer von meiner [mo1rel]... Ich sollte nachsehen gehen."


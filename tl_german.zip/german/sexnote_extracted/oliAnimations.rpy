# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/oliAnimations.rpy
translate german strings:

    # say L6 aye
    old "Oh yeah, sis! Woohoo!"
    new "Oh ja, Schwester! Hurra!"

    # say L7 aye
    old "I can tell how good you are at this!"
    new "Ich merke, wie gut du darin bist!"

    # say L8 aye
    old "Look at that huge cock filling your mouth!"
    new "Schau dir diesen riesigen Schwanz an, der deinen Mund ausfüllt!"

    # say L12 aye
    old "I know you like it, sis!"
    new "Ich weiß, dass dir das gefällt, Schwester!"

    # say L13 aye
    old "With how big his cock is, I'd say you chose well!"
    new "Bei der Größe seines Schwanzes würde ich sagen, du hast gut gewählt!"

    # say L14 aye
    old "Look at you go to town on that monster cock!"
    new "Schau dir an, wie du dich an diesem Monster Schwanz verausläufst!"

    # say L18 aye
    old "How about you, brother-in-law? Do you like it?"
    new "Und du, Schwager? Magst du es?"

    # say L19 aye
    old "Come on, tell me! Don't leave me hanging!"
    new "Komm schon, sag es mir! Lass mich nicht hängen!"

    # say L20 oli
    old "Slrrp, j- just answer her!"
    new "Slrrp, j- ja, antworte ihr!"

    # say L22 aye
    old "Haha! Oh yeah!"
    new "Haha! Oh ja!"

    # say L45 pla
    old "O- Olivia! I- I'm about to cum!"
    new "O- Olivia! I- Ich komme gleich!"

    # say L46 aye
    old "Yeah! Cum in her mouth! Come on!"
    new "Ja! Komm in ihrem Mund! Los!"

    # say L47 aye
    old "I want to see that!"
    new "Ich will das sehen!"

    # say L48 oli
    old "I- it's alright, just let it out!"
    new "I- es ist okay, lass es einfach raus!"

    # say L55 aye
    old "Oh my gosh look at how much you came!"
    new "Oh mein Gott, schau dir an, wie viel du gekommen bist!"

    # say L56 aye
    old "That's amazing!"
    new "Das ist unglaublich!"

    # say L57 aye
    old "I have to say, sis, this guy may not look like much."
    new "Ich muss sagen, Schwester, der Typ sieht vielleicht nicht vielversprechend aus."

    # say L58 aye
    old "But he is certainly well gifted."
    new "Aber er ist definitiv gut ausgestattet."

    # say L59 oli
    old "Oh shut up, just let me clean up and leave us alone."
    new "Oh halt die Klappe, lass mich einfach aufräumen und uns in Ruhe lassen."

    # say L71 oli
    old "Oh, wow... Your cock is getting even harder..."
    new "Oh, wow... Dein Schwanz wird noch härter..."

    # say L72 oli
    old "It feels soft and warm though."
    new "Es fühlt sich weich und warm an."

    # say L73 oli
    old "Does my hand feel good?"
    new "Fühlt sich meine Hand gut an?"

    # say L74 pla
    old "Yes, it feels really nice..."
    new "Ja, es fühlt sich wirklich gut an..."

    # say L78 oli
    old "To be honest, it's the biggest I've ever seen..."
    new "Ehrlich gesagt, es ist das Größte, das ich je gesehen habe..."

    # say L80 oli
    old "I mean, it's pretty impresive..."
    new "Ich meine, es ist ziemlich beeindruckend..."

    # say L83 oli
    old "I'll do it a little faster..."
    new "Ich mache es ein bisschen schneller..."

    # say L84 oli
    old "Is that okay?"
    new "Ist das in Ordnung?"

    # say L85 pla
    old "Uhh, s- sure..."
    new "Uhh, s-sicher..."

    # say L110 oli
    old "Ok, I think that's enough... I don't want you to waste your cum..."
    new "Okay, ich denke, das reicht... Ich will ja nicht, dass du deinen Saft verschwendest..."

    # say L111 oli
    old "I mean, I need your sperm, you know the idea is to get pregnant..."
    new "Ich meine, ich brauche dein Sperma, du weißt schon, das Ziel ist es, schwanger zu werden..."

    # say L112 pla
    old "Uhh, yeah, you're right..."
    new "Uhh, ja, du hast recht..."

    # say L113 oli
    old "Alright, I'm going to take off my pants and get on the edge of the bed. I guess you know what to do..."
    new "Okay, ich ziehe meine Hose aus und setze mich ans Bettende. Ich denke, du weißt, was zu tun ist..."

    # say L119 pla
    old "Uhh, yeah, of course..."
    new "Uhh, klar, natürlich..."

    # say L136 oli
    old "Uhh, your cock is so big, so, I'm going to ask you to please be gentle..."
    new "Uhh, dein Schwanz ist so groß, also, ich werde dich bitten, bitte vorsichtig zu sein..."

    # say L137 pla
    old "Ohh, s- sure, don't worry."
    new "Ohh, s-sicher, mach dir keine Sorgen."

    # say L142 oli
    old "Hngh! Oh God!"
    new "Hngh! Oh Gott!"

    # say L143 oli
    old "It's even bigger than I thought!"
    new "Es ist sogar noch größer, als ich dachte!"

    # say L144 pla
    old "A- are you alright?"
    new "A- Alles okay?"

    # say L145 oli
    old "Y- yes, don't worry, don't stop..."
    new "Y- ja, mach dir keine Sorgen, hör nicht auf..."

    # say L148 oli
    old "Come on, do it a little faster, I want you to cum inside me..."
    new "Komm schon, mach es ein bisschen schneller, ich will, dass du in mir kommst..."

    # say L150 oli
    old "Mmm, it feels so deep... I've never felt anything like this before..."
    new "Mmm, das fühlt sich so tief an... Ich habe noch nie etwas Derartiges gespürt..."

    # say L151 oli
    old "Uhh... T- this is so good!"
    new "Uhh... D- das ist so gut!"

    # say L152 pla
    old "Ughh... Yes..."
    new "Ughh... Ja..."

    # say L175 oli
    old "[pla] I- I'm about to finish!"
    new "[pla] I- Ich bin gleich soweit!"

    # say L176 pla
    old "M- me too! I'm about to cum!"
    new "M- ich auch! Ich komme gleich!"

    # say L177 oli
    old "Y- yes! Yes! Cum inside me!"
    new "Y- ja! Ja! Komm in mir!"

    # say L183 oli
    old "W- woah!"
    new "W- wow!"

    # say L184 oli
    old "I- I wasn't expecting it to be that way."
    new "I- Ich habe es nicht erwartet, so zu sein."

    # say L185 oli
    old "I was a lot better than I thought!"
    new "Es war viel besser, als ich gedacht habe!"

    # say L186 oli
    old "Did you like it too [pla]?"
    new "Hast du es auch gemocht [pla]?"

    # say L187 pla
    old "Yeah, it was great."
    new "Ja, es war toll."

    # say L188 oli
    old "Alright, awesome!"
    new "Okay, super!"

    # say L189 oli
    old "Now, let's get cleaned before my mom comes back and sees us."
    new "Dann lass uns sauber werden, bevor meine Mom zurückkommt und uns sieht."

    # say L201 oli
    old "Ohhh, yeah, I've missed this feeling..."
    new "Ohhh, ja, ich hab dieses Gefühl echt vermisst..."

    # say L202 bri
    old "[pla]! She's really liking this!"
    new "[pla]! Sie mag das echt!"

    # say L203 bri
    old "I can see her emotions, she wants to get pregnant very badly!"
    new "Ich sehe ihre Gefühle, sie will unbedingt schwanger werden!"

    # say L207 oli
    old "Oh my God! Your cock is so big!"
    new "Oh mein Gott! Dein Schwanz ist so groß!"

    # say L209 oli
    old "Yeah, yeah, just don't stop!"
    new "Ja, ja, hör nicht auf!"

    # say L212 oli
    old "Oh God yes!"
    new "Oh Gott ja!"

    # say L213 oli
    old "F- fuck me harder! Harder"
    new "Fick mich härter! Härter"

    # say L215 oli
    old "Mmm... I love this!"
    new "Mmm... Das liebe ich!"

    # say L238 pla
    old "O- Olivia! I think I'm about to cum!"
    new "O- Olivia! Ich glaube, ich komme gleich!"

    # say L239 oli
    old "Y- yeah! D- do it!"
    new "Y- ja! M- mach es!"

    # say L240 oli
    old "Fill me up with your cum!"
    new "Füll mich mit deinem Saft!"

    # say L241 oli
    old "Get me pregnant!"
    new "Mach mich schwanger!"

    # say L247 oli
    old "God! That was fantastic [pla]!"
    new "Oh Gott! Das war fantastisch [pla]!"

    # say L248 oli
    old "I can't believe how good it was!"
    new "Ich kann nicht glauben, wie gut das war!"

    # say L249 oli
    old "I'm sure this time I'll be pregnant for real."
    new "Ich bin sicher, dieses Mal werde ich wirklich schwanger."

    # say L250 pla
    old "I hope so..."
    new "Ich hoffe es..."

    # say L251 oli
    old "Alright, let's get up and get cleaned before my family comes back."
    new "Okay, lass uns aufstehen und uns saubermachen, bevor meine Familie zurückkommt."

    # say L263 oli
    old "Ah! ah! I'm loving it!"
    new "Ah! ah! Ich liebe es!"

    # say L264 oli
    old "I've missed your dick so much [pla]!"
    new "Ich hab deinen Schwanz so vermisst [pla]!"

    # say L265 oli
    old "There's just nothing like it!"
    new "Da ist einfach nichts dran zu machen!"

    # say L269 oli
    old "D- do you like it [pla]?"
    new "D- magst du es [pla]?"

    # say L270 oli
    old "How it feels?"
    new "Wie sich das anfühlt?"

    # say L275 oli
    old "Oh god yes this is just what I've been missing!"
    new "Oh Gott ja, das ist genau das, was ich gebraucht habe!"

    # say L276 oli
    old "I can already start to feel myself getting better!"
    new "Ich spüre schon, wie es mir besser geht!"

    # say L277 oli
    old "This is unbelievable!"
    new "Das ist unglaublich!"

    # say L300 oli
    old "Oh [pla]! I'm about to cum!"
    new "Oh [pla]! Ich komme gleich!"

    # say L302 oli
    old "G- great! Let's do it together!"
    new "G- gut! Lass uns es zusammen tun!"

    # say L309 oli
    old "Oh God! That was so great!"
    new "Oh Gott! Das war unglaublich!"

    # say L310 oli
    old "I can't believe how good it felt [pla]!"
    new "Ich kann nicht glauben, wie gut sich das angefühlt hat [pla]!"

    # say L311 oli
    old "I think that's just what I needed!"
    new "Ich glaube, das war genau das, was ich gebraucht habe!"

    # say L312 pla
    old "I- I'm glad it helped you."
    new "Ich- Ich freue mich, dass es dir geholfen hat."

    # say L313 oli
    old "Did you like it too?"
    new "Hast du es auch genossen?"

    # say L314 pla
    old "Oh yeah, it was very good."
    new "Oh ja, es war sehr gut."

    # say L315 pla
    old "Now, how about we get up before your Mom comes back."
    new "Dann lass uns aufstehen, bevor deine Mom zurückkommt."

    # say L316 oli
    old "Sure!"
    new "Klar!"

    # say L328 oli
    old "Oh god! Yes! Yes!"
    new "Oh Gott! Ja! Ja!"

    # say L329 oli
    old "Oh yes daddy! Fuck me just like that!"
    new "Oh ja Daddy! Fick mich genau so!"

    # say L330 oli
    old "This is so amazing [pla]!"
    new "Das ist so unglaublich [pla]!"

    # say L334 bri
    old "That's it [pla]!"
    new "Das ist es [pla]!"

    # say L336 bri
    old "Keep going! That's just what's needed for the spell!"
    new "Weiter so! Das ist genau das, was der Zauber braucht!"

    # say L340 oli
    old "Oh God [pla]!"
    new "Oh Gott [pla]!"

    # say L341 oli
    old "Y- you're making me go insane!"
    new "Du machst mich noch wahnsinnig!"

    # say L342 oli
    old "This is so great!"
    new "Das ist so geil!"

    # say L367 oli
    old "Oh fuck yes! I want you to fill me up!"
    new "Oh Scheiße ja! Füll mich aus!"

    # say L369 bri
    old "You've already extracted the magic power! Let yourself go!"
    new "Du hast die magische Kraft schon freigesetzt! Lass dich einfach gehen!"

    # say L375 bri
    old "That was awesome [pla]!"
    new "Das war toll [pla]!"

    # say L376 bri
    old "Just what we needed to end the ritual!"
    new "Das war genau das, was wir brauchten, um den Ritual zu beenden!"

    # say L377 oli
    old "Oh God [pla] that felt so good!"
    new "Oh Gott [pla] das hat sich so gut angefühlt!"

    # say L389 oli
    old "Oh god [pla]! The taste of your dick!"
    new "Oh Gott [pla]! Der Geschmack deines Schwanzes!"

    # say L390 oli
    old "This is such an amazing dick!"
    new "Das ist echt ein unglaublicher Schwanz!"

    # say L391 oli
    old "It never disappoints me!"
    new "Es enttäuscht mich nie!"

    # say L397 oli
    old "I just love feeling it in my mouth!"
    new "Ich liebe es, es in meinem Mund zu spüren!"

    # say L401 oli
    old "I love it [pla]!"
    new "Ich liebe es [pla]!"

    # say L402 oli
    old "I love this dick!"
    new "Ich liebe diesen Schwanz!"

    # say L403 oli
    old "I love it's taste and smell!"
    new "Ich liebe seinen Geschmack und seinen Geruch!"

    # say L426 pla
    old "O- Olivia! I- ugh! I can't hold it in anymore!"
    new "O- Olivia! I- ugh! Ich kann es nicht mehr zurückhalten!"

    # say L427 oli
    old "That's alright! I don't want you to!"
    new "Das ist in Ordnung! Ich will doch, dass du es tust!"

    # say L428 oli
    old "You don't need to hold it in!"
    new "Du musst es nicht zurückhalten!"

    # say L429 oli
    old "Let go and fill my mouth with your hot cum!"
    new "Lass los und fülle meinen Mund mit deinem heißen Saft!"

    # say L436 oli
    old "Mmm! That's an amazing taste [pla]!"
    new "Mmm! Das ist ein unglaublicher Geschmack [pla]!"

    # say L437 oli
    old "This is just wonderful!"
    new "Das ist einfach wunderbar!"

    # say L439 pla
    old "I- I'm glad you like it."
    new "Ich freue mich, dass dir das so gut schmeckt."

    # say L440 oli
    old "Oh yeah, I love it!"
    new "Oh ja, ich liebe es!"

    # say L441 oli
    old "Now, I think we should get clean before my mom comes back and finds us like this."
    new "Jetzt denke ich, wir sollten uns saubermachen, bevor meine Mom zurückkommt und uns so findet."

    # say L442 pla
    old "Sure, sure!"
    new "Klar, klar!"


# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/HalloweenEvent.rpy
translate german strings:

    # say L10 pla
    old "Uhh, I didn't sleep well last night... I should drink a cup of water... "
    new "Uhh, ich hab letzte Nacht nicht gut geschlafen... Ich sollte ein Glas Wasser trinken..."

    # say L25 mo1
    old "Oh, hi honey, good morning!"
    new "Oh, hallo Schatz, guten Morgen!"

    # say L26 pla
    old "Uhh, good morning..."
    new "Uhh, guten Morgen..."

    # say L27 mo1
    old "Do you have everything ready for tonight?"
    new "Hast du schon alles für heute Abend vorbereitet?"

    # say L28 pla
    old "T- onight?"
    new "T- heute Abend?"

    # say L29 mo1
    old "The halloween party is tonight... Don't you have your costume already?"
    new "Die Halloween-Party ist heute Abend... Hast du dein Kostüm schon?"

    # say L30 pla
    old "Ohh... Right, I completely forget about that... Ehmm no, actually I don't have a costume yet..."
    new "Ohh... Stimmt, ich hab das total vergessen... Ähm, nein, eigentlich hab ich noch keinen Kostüm."

    # say L31 mo1
    old "Oh, don't worry, Talk with [sis], she was the one who got us our costumes, she could have one for you too."
    new "Oh, machen Sie sich keine Sorgen, mit [sis] reden Sie, sie war diejenige, die uns unsere Kostüme besorgt hat, sie könnte auch eines für dich haben."

    # say L32 pla
    old "Oh, great, I'm going to talk with her. Thank you!"
    new "Oh, toll, ich werde mit ihr reden. Danke!"

    # say L33 mo1
    old "You are welcome honey."
    new "Gern geschehen, Schatz."

    # say L52 sis
    old "Ohh, hey [pla]! How do I look with this costume?"
    new "Ohh, hallo [pla]! Wie sehe ich in diesem Kostüm aus?"

    # say L54 sis
    old "Where is your [mo1rel]?"
    new "Wo ist dein [mo1rel]?"

    # say L56 sis
    old "Where is [mo1]?"
    new "Wo ist [mo1]?"

    # say L57 pla
    old "Hmm she is in the kitchen... Why?"
    new "Hmm, sie ist in der Küche... Warum?"

    # say L58 sis
    old "Perfect. Do you wanna see the fun thing about this costume?"
    new "Perfekt. Willst du das Coole an diesem Kostüm sehen?"

    # say L59 pla
    old "The fun... Thing? What do you mean?"
    new "Das Spaß... Teil? Was meinst du damit?"

    # say L60 sis
    old "Hahaha, you are going to love it!"
    new "Hahaha, du wirst es lieben!"

    # say L61 pla
    old "Hmm a- alright..."
    new "Hmm a- okay..."

    # say L62 sis
    old "Well, I chose this costume for just one reason, it has a tail. Do you see it?"
    new "Na, ich hab dieses Kostüm aus einem einzigen Grund ausgesucht, es hat einen Schwanz. Siehst du ihn?"

    # say L63 pla
    old "Hmm... Yes."
    new "Hmm... Ja."

    # say L64 sis
    old "Ok, now I'm going to take it out."
    new "Okay, jetzt ziehe ich es raus."

    # say L65 pla
    old "You are going to wha-"
    new "Du willst was-"

    # say L72 sis
    old "I wanted something like this from a long time ago... Did you know I have never try anal sex?"
    new "Ich wollte schon lange so etwas... Hast du gewusst, dass ich noch nie Analsex hatte?"

    # say L77 sis
    old "Well I wanna change that today... I want you to fuck my ass..."
    new "Dann will ich das heute ändern... Ich will, dass du mich von hinten fickst..."

    # say L88 sis
    old "Uhhh [pla], do it gently... Is my first time..."
    new "Uhhh [pla], mach es vorsichtig... Es ist mein erstes Mal..."

    # say L102 sis
    old "Wow, it was better than I thought, and your big cock didn't hurt me at all..."
    new "Wow, das war besser als gedacht, und dein großer Schwanz hat mir überhaupt nicht wehgetan..."

    # say L103 pla
    old "I did it gently..."
    new "Ich hab's vorsichtig gemacht..."

    # say L104 sis
    old "Definitely we need to repeat it."
    new "Definitiv müssen wir das wiederholen."

    # say L106 sis
    old "Anyway, I have work, see you later [pla]."
    new "Na ja, ich muss arbeiten, bis später [pla]."

    # say L107 pla
    old "Wait... Hmm I came, because I need a halloween costume."
    new "Warte... Hmm ich bin gekommen, weil ich eine Kostüm für Halloween brauche."

    # say L108 sis
    old "Ohh, your costume? Is in your bedroom."
    new "Ohh, dein Kostüm? Ist in deinem Schlafzimmer."

    # say L109 pla
    old "Oh really?"
    new "Oh wirklich?"

    # say L110 sis
    old "Yes, I left it there a few minutes ago."
    new "Ja, ich hab es vor ein paar Minuten da hingelegt."

    # say L111 pla
    old "Ohh, thank you so much."
    new "Ohh, danke schön."

    # say L112 sis
    old "You're welcome. You will like that costume, it's perfect for you."
    new "Gern geschehen. Du wirst das Kostüm bestimmt lieben, es passt perfekt zu dir."

    # say L113 pla
    old "Hmm... Alright."
    new "Hmm... Okay."

    # say L126 pla
    old "Uhh, yes."
    new "Uhh, ja."

    # say L127 mo1
    old "Hmm could you please come for a minute?"
    new "Hmm, könnten Sie bitte einen Moment kommen?"

    # say L138 mo1
    old "I'm sorry... Is just that this costume is a bit hard to dress up... Could you please help me with that?"
    new "Entschuldigung... Es ist nur, dass dieses Kostüm ziemlich schwierig anzulegen ist... Könnten Sie mir bitte dabei helfen?"

    # say L139 pla
    old "Uhh... S- sure."
    new "Uhh... Klar."

    # say L140 mo1
    old "Thank you. You are a sweetheart!"
    new "Danke. Sie sind ein Schatz!"

    # say L141 pla
    old "Ok... Let's see..."
    new "Ok... Lass uns mal sehen..."

    # say L146 pla
    old "Well, I think is done..."
    new "Na ja, ich denke, es ist fertig..."

    # say L151 mo1
    old "Oh, it's perfect just like in the box picture!"
    new "Oh, es ist perfekt, genau wie auf dem Bild der Verpackung!"

    # say L152 mo1
    old "Oh, wait... It doesn't cover up my nipples at all..."
    new "Oh, Moment mal... Es bedeckt meine Brustwarzen überhaupt nicht."

    # say L155 mo1
    old "Maybe it is a bit small for me...  What do you think [pla]?"
    new "Vielleicht ist es ein bisschen klein für mich... Was denken Sie [pla]?"

    # say L161 pla
    old "(Oh God, I just had sex! How can I get this horny again?..."
    new "Oh Gott, ich hab gerade Sex gehabt! Wie kann ich schon wieder so geil sein?"

    # say L163 mo1
    old "[pla]? Are you-... Oh, you got hard-"
    new "[pla]? Sind Sie... Oh, Sie sind hart geworden-"

    # say L164 pla
    old "Sorry... I didn't mean to-"
    new "Entschuldigung... Das wollte ich nicht-"

    # say L165 mo1
    old "Oh, honey don't worry... You got hard for my tits?"
    new "Oh, Schatz, mach dir keine Sorgen... Du bist hart geworden für meine Titten?"

    # say L168 mo1
    old "Ok, what about if I help you with them?"
    new "Ok, was wäre, wenn ich dir dabei helfe?"

    # say L170 mo1
    old "Get naked and let me return you the help."
    new "Zieh dich aus und lass mich dir helfen."

    # say L178 mo1
    old "Do you like my boobs honey?"
    new "Magst du meine Titten, Schatz?"

    # say L179 pla
    old "Uhh.... Y- yes... I love your boobs."
    new "Uhh.... J- ja... Ich liebe deine Titten."

    # say L180 mo1
    old "Then fuck them!"
    new "Dann fick sie!"

    # say L196 mo1
    old "Do you feel better now honey?"
    new "Fühlst du dich jetzt besser, Schatz?"

    # say L197 pla
    old "Y- yes... Thank you."
    new "Y- ja... Danke."

    # say L198 mo1
    old "No, thanks to you for your help with this costume. By the way did you talk with [sis]?"
    new "Nein, danke dir für deine Hilfe bei diesem Kostüm. Übrigens, hast du mit [sis] gesprochen?"

    # say L199 pla
    old "Uhh... W- with [sis]..."
    new "Uhh... W- mit [sis]..."

    # say L200 mo1
    old "Yes, about your costume."
    new "Ja, über dein Kostüm."

    # say L201 pla
    old "Ohhh the costume, right... Yes, I have it in my bedroom, I need to try it"
    new "Ohhh das Kostüm, stimmt... Ja, ich hab es in meinem Schlafzimmer, ich muss es anprobieren."

    # say L202 mo1
    old "Oh great, then go, if you need any help just let me know. Now I'm going to clean this mess."
    new "Oh toll, dann geh mal. Wenn du Hilfe brauchst, lass es mich wissen. Jetzt werde ich hier aufräumen."

    # say L203 pla
    old "Alright, Thank you."
    new "Okay, danke."

    # say L208 pla
    old "(Alright, I should try the costume.)"
    new "Okay, ich sollte mal den Kostüm probieren."

    # say L213 pla
    old "Hmm, it looks a bit weird... What is this? Maybe I'm doing something wrong, I better ask [sis]."
    new "Hmm, das sieht irgendwie komisch aus... Was ist das? Vielleicht mach ich was falsch, ich sollte besser [sis] fragen."

    # say L229 pla
    old "Hey, I was looking for you."
    new "Hey, ich hab dich gesucht."

    # say L230 sis
    old "Oh, you have your costume! You look great!"
    new "Oh, du hast deinen Kostüm! Du siehst toll aus!"

    # say L231 pla
    old "Thank you, but I was wondering what is t-"
    new "Danke, aber ich wollte gerade fragen, was ist -"

    # say L232 sis
    old "Hmm your costume is not ready..."
    new "Hmm, dein Kostüm ist noch nicht fertig..."

    # say L234 sis
    old "You need to get hard to fill the snake."
    new "Du musst hart werden, um die Schlange zu füllen."

    # say L235 pla
    old "F- fill the snake? "
    new "F-Füll die Schlange?"

    # say L236 sis
    old "You always have to be that slow?"
    new "Du musst immer so langsam sein?"

    # say L238 sis
    old "Alright, let me give you a blowjob to make you hard-"
    new "Na gut, lass mich dir einen blasen, damit du hart wirst-"

    # say L245 mo1
    old "Hi guys, what are you doing?"
    new "Hallo Jungs, was macht ihr da?"

    # say L247 pla
    old "(Oh shit...)"
    new "Oh Scheiße..."

    # say L248 sis
    old "Well, [pla] needs help with his costume..."
    new "Na ja, [pla] braucht Hilfe bei seinem Kostüm..."

    # say L249 mo1
    old "Oh really, what does he need?"
    new "Oh wirklich, was braucht er denn?"

    # say L250 sis
    old "He needs to get hard to fill his costume."
    new "Er muss hart werden, um sein Kostüm auszufüllen."

    # say L253 mo1
    old "Oh, the snake will become to anaconda?"
    new "Oh, die Schlange wird also zur Anaconda?"

    # say L255 pla
    old "(What the hell!?)"
    new "Was zum Teufel!?"

    # say L256 sis
    old "Exactly! I was thinking in a blowjob. What do you think?"
    new "Genau! Ich dachte an einen Blowjob. Was meinst du?"

    # say L258 mo1
    old "What about a double blowjob, I think that would make him hard for all night!"
    new "Was halten Sie von einem Doppelblowjob? Ich denke, das würde ihn die ganze Nacht lang hart machen!"

    # say L260 pla
    old "(WHAT THE FUCK IS GOING ON?!)"
    new "Was zur Hölle geht hier ab?!"

    # say L261 sis
    old "Great idea!"
    new "Große Idee!"

    # say L265 pla
    old "Uhh...  W- what is happening?"
    new "Uhh... W-was passiert hier?"

    # say L266 mo1
    old "Hahaha, let's show him what is happening [sis]..."
    new "HAHAHA, lass uns ihm zeigen, was los ist [sis]..."

    # say L293 mo2
    old "I- I REALLY CAN BELIEVE IT..."
    new "Ich kann es wirklich nicht glauben..."

    # say L294 pla
    old "(OH GOD I'M DEAD.)"
    new "Oh Gott, ich bin tot."

    # say L295 mo2
    old "I can't believe all of you started the party without me..."
    new "Ich kann nicht glauben, dass ihr alle ohne mich angefangen habt..."

    # say L296 pla
    old "WHAAAAATTT...."
    new "WAAAAAAAS????"

    # say L297 mo1
    old "There is more for you too..."
    new "Es gibt noch mehr für Sie..."

    # say L299 sis
    old "We will give you the best spot."
    new "Wir werden dir den besten Platz geben."

    # say L301 mo2
    old "And what are we waiting for? Let's enjoy!"
    new "Und worauf warten wir noch? Lass uns genießen!"

    # say L314 mo1
    old "This is just a halloween party..."
    new "Das ist doch nur eine Halloween-Party..."

    # say L315 sis
    old "Don't you want to join us?"
    new "Möchten Sie sich uns nicht anschließen?"

    # say L316 mo2
    old "You can't lose this chance..."
    new "Sie können diese Chance nicht verpassen..."

    # say L317 pla
    old "... What the hell... Let's do it!"
    new "... Was soll's... Lass es uns tun!"

    # say L326 pla
    old "Oh God... I can't anymore"
    new "Oh Gott... ich schaffe das nicht mehr"

    # say L330 sis
    old "Hey [pla], we want to keep fucking."
    new "Hey [pla], wir wollen weiter vögeln."

    # say L331 pla
    old "Hmm... I- I just can't... I'm really tired..."
    new "Hmm... ich- ich kann einfach nicht mehr... Ich bin echt müde..."

    # say L332 mo1
    old "Oh no honey, you don't understand."
    new "Oh nein Schatz, Sie verstehen das nicht."

    # say L333 mo2
    old "You fucked us, now is our turn to fuck you."
    new "Du hast uns gevögelt, jetzt ist es unsere Reihe, dich zu vögeln."

    # say L339 sis
    old "We want to fuck you..."
    new "Wir wollen dich ficken..."

    # say L340 mo1
    old "Just like you did..."
    new "Genau wie du es getan hast..."

    # say L341 mo2
    old "We are going to drill you."
    new "Wir werden Sie ficken."

    # say L350 pla
    old "Wow... It was just a nightmare... Thank God."
    new "Wow... Es war nur ein Albtraum... Gott sei Dank."

    # say L351 pla
    old "Hmm... Actually it wasn't a nightmare at all..."
    new "Hmm... Eigentlich war es gar kein Albtraum..."


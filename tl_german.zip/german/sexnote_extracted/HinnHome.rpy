# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/HinnHome.rpy
translate german strings:

    # say L20 pla
    old "I should find a therapist and talk with Mrs. Jade first."
    new "Ich sollte einen Therapeuten finden und erst mit Mrs. Jade sprechen."

    # say L26 pla
    old "I should talk with Mrs. Jade first."
    new "Ich sollte erst mit Mrs. Jade reden."

    # say L32 pla
    old "I should talk with Dr. Johnson first."
    new "Ich sollte erst mit Dr. Johnson reden."

    # say L93 hin
    old "Hi [pla], how are you doing?"
    new "Hi [pla], wie geht's dir?"

    # say L95 pla
    old "Great and you?"
    new "Alles gut und du?"

    # say L97 hin
    old "I'm fine. I wanted to ask you if you've shown our progress to Mrs. Mia?"
    new "Ich bin gut. Ich wollte dich fragen, ob du Mrs. Mia schon von unserem Fortschritt erzählt hast?"

    # say L99 pla
    old "Oh sorry. I haven't yet."
    new "Oh sorry. Ich hab's noch nicht gemacht."

    # say L101 hin
    old "Well, we should do it before continuing."
    new "Dann sollten wir das vorher machen."

    # say L103 pla
    old "Ok, doing it now."
    new "Ok, mach ich jetzt."

    # say L114 pla
    old "Hey, Hinn... I wanted to talk about yesterday."
    new "Hey, Hinn... Ich wollte über gestern sprechen."

    # say L116 hin
    old "Oh... Listen... I'm so sorry. I shouldn't have got you into all this. It's my fault..."
    new "Oh... Hör zu... Es tut mir so leid. Ich hätte dich da nicht mit reinziehen sollen. Das ist alles meine Schuld..."

    # say L118 pla
    old "No, no, I agreed to help, in fact I think it was... fun."
    new "Nein, nein, ich habe mich ja bereitwillig gemeldet. Eigentlich fand ich es sogar... spaßig."

    # say L122 pla
    old "Yes, I liked helping. Also, I think your mom did everything with good intentions."
    new "Ja, mir hat das Helfen gefallen. Und ich denke, deine Mom hat alles mit guten Absichten getan."

    # say L124 hin
    old "Hmm... Maybe in her own way. But you're probably right."
    new "Hmm... Vielleicht auf ihre Art. Aber du hast wahrscheinlich recht."

    # say L126 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is that you feel good about yourself."
    new "Ich finde, du siehst gut aus, egal was du anhast. Das Wichtigste ist, dass du dich damit wohlfühlst."

    # say L129 hin
    old "Thank you, [pla]. (He's so sweet.) I really appreciate it..."
    new "Danke, [pla]. (Er ist so süß.) Ich schätze das wirklich..."

    # say L131 pla
    old "My pleasure... Well, should we continue with the class project?"
    new "Mein Vergnügen... Also, sollen wir mit dem Klassenprojekt weitermachen?"

    # say L134 hin
    old "Yes, lets do it."
    new "Ja, lass uns weitermachen."

    # say L136 pla
    old "Great."
    new "Super."

    # say L154 pla
    old "Wow Hinn, you changed your outfit..."
    new "Wow Hinn, du hast dein Outfit gewechselt..."

    # say L156 hin
    old "Well... I wanted to try something new... What do you think?"
    new "Na ja... ich wollte mal was Neues ausprobieren... Was meinst du?"

    # say L158 pla
    old "You look great."
    new "Du siehst toll aus."

    # say L162 pla
    old "Yes, but the most important thing is how do you feel?"
    new "Ja, aber das Wichtigste ist, wie du dich fühlst."

    # say L165 hin
    old "Hmmm, I feel comfortable, the sessions with Dr. Johnson worked."
    new "Hmmm, ich fühle mich wohl, die Sitzungen mit Dr. Johnson haben geholfen."

    # say L169 hin
    old "Actually, we have a new session today."
    new "Eigentlich haben wir heute eine neue Sitzung."

    # say L171 pla
    old "Oh perfect, are you ready?"
    new "Oh perfekt, bist du bereit?"

    # say L173 hin
    old "Yes, let's go."
    new "Ja, lass uns losgehen."

    # say L189 hin
    old "I'm fine, thanks."
    new "Ich bin gut, danke."

    # say L191 pla
    old "I was wondering if you have a scheduled a new session with Dr. Johnson."
    new "Ich hab mich gefragt, ob du schon einen neuen Termin bei Dr. Johnson hast."

    # say L193 hin
    old "Yes, tomorrow morning don't worry."
    new "Ja, morgen früh, mach dir keine Sorgen."

    # say L195 pla
    old "Oh great, see you tomorrow then."
    new "Oh toll, dann sehen wir uns morgen."

    # say L200 hin
    old "Wait..."
    new "Warte..."

    # say L202 hin
    old "We could... Practice again... If you want."
    new "Wir könnten... noch mal üben... Wenn du willst."

    # say L207 pla
    old "Sounds great."
    new "Klingt gut."

    # say L209 hin
    old "Nice."
    new "Nett."

    # say L216 pla
    old "That sounds great, but I can't right now."
    new "Das klingt toll, aber ich kann gerade nicht."

    # say L218 hin
    old "Oh don't worry, see you tomorrow then."
    new "Oh mach dir keine Sorgen, bis morgen dann."

    # say L220 pla
    old "Great, see you."
    new "Super, bis morgen."

    # say L227 hin
    old "Great!."
    new "Super!"

    # say L245 pla
    old "I was wondering if you you have a scheduled a new sesión with Dr. Johnson."
    new "Ich hab mich gefragt, ob du einen neuen Termin bei Dr. Johnson hast."

    # say L251 hin
    old "See you."
    new "Bis dann."

    # say L296 pla
    old "No, no, sorry I was just walking around. I have to go."
    new "Nein, nein, tut mir leid, ich war nur rumlaufen. Ich muss los."

    # say L315 hin
    old "Hi [pla], Are you ready to start?"
    new "Hi [pla], bist du bereit anzufangen?"

    # say L319 pla
    old "Yes, I'm ready. Let's get to it."
    new "Ja, ich bin bereit. Lass uns anfangen."

    # menu L324 
    old "Not"
    new "Na klar, ich bin bereit. Lass uns anfangen."

    # say L326 pla
    old "Actually, I come to tell you I can't work with you today."
    new "Tatsächlich komme ich, um dir zu sagen, dass ich heute nicht mit dir arbeiten kann."

    # say L328 hin
    old "Oh, ok, don't worry we could work tomorrow on the class project."
    new "Oh, ok, mach dir keine Sorgen, wir können morgen an dem Klassenprojekt arbeiten."

    # say L330 pla
    old "Of course, tomorrow we will be working hard!"
    new "Natürlich, morgen werden wir hart arbeiten!"

    # say L332 hin
    old "Hehehe great, see you."
    new "Hehehe toll, bis dann."

    # say L334 pla
    old "See you Hinn."
    new "Bis morgen, Hinn."

    # say L363 pla
    old "Damn, are we done? Really?"
    new "Verdammt, sind wir fertig? Wirklich?"

    # say L365 hin
    old "Yup... Looks like that's everything..."
    new "Klar... Scheint so, als wären das alles gewesen..."

    # say L367 pla
    old "Hinn? You look sad. You ok?"
    new "Hinn? Du siehst traurig aus. Alles okay?"

    # say L369 hin
    old "Yeah, I'm fine... I'm happy we finally finished this project..."
    new "Ja, mir geht's gut... Ich freue mich, dass wir endlich dieses Projekt abgeschlossen haben..."

    # say L371 pla
    old "Really?..."
    new "Wirklich?..."

    # say L373 hin
    old "Yes, it's nothing. Don't worry. Just give the final project to Mrs. Mia tomorrow and let me know what she says. Ok?"
    new "Ja, ist schon gut. Mach dir keine Sorgen. Gib morgen einfach das finale Projekt Mrs. Mia und lass mich wissen, was sie sagt. Okay?"

    # say L375 pla
    old "Alright, Hinn. No problem."
    new "Alles klar, Hinn. Kein Problem."

    # say L377 hin
    old "See you tomorrow, [pla]."
    new "Bis morgen, [pla]."

    # say L380 pla
    old "See you tomorrow, Hinn."
    new "Bis morgen, Hinn."

    # say L396 pla
    old "Well, we made a lot of progress!"
    new "Na, wir haben ja eine Menge geschafft!"

    # say L398 hin
    old "Yes, it's a little late. We should continue tomorrow."
    new "Ja, es ist schon spät. Wir sollten morgen weitermachen."

    # say L400 pla
    old "Ok, see you tomorrow, Hinn. Have a good night."
    new "Okay, bis morgen, Hinn. Schlaf gut."

    # say L402 hin
    old "By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "Ach ja, lass Mrs. Mia unser Fortschritt sehen, sie soll wissen, wie weit wir gekommen sind. Bis morgen."


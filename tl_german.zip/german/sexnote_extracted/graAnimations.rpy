# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Animations/graAnimations.rpy
translate german strings:

    # say L6 gra
    old "I feel I'm in heaven just by touching it! Oh my Father, I'm so grateful."
    new "Ich fühle mich im Himmel, nur indem ich es berühre! Oh mein Vater, ich bin so dankbar."

    # say L7 pla
    old "(My God!...)"
    new "Mein Gott!..."

    # say L12 gra
    old "The feeling of your big grace on my hands, it's so pure."
    new "Das Gefühl Ihrer großen Gnade in meinen Händen, es ist so rein."

    # say L17 gra
    old "My heavenly God!... It's so... S- So great and big, divine!"
    new "Mein himmlischer Gott!... Es ist so... S- So groß und großartig, göttlich!"

    # say L41 gra
    old "I feel that grace is going to come in my fac- Ahhhhhh!!!"
    new "Ich spüre, dass diese Gnade in mein Gesicht kommen wird - AHHHHHH!!!"

    # say L58 gra
    old "Your divine phallus is precious, just by seeing it I can feel the glory in him."
    new "Ihr göttlicher Phallus ist wertvoll, schon beim Anblick spüre ich die Herrlichkeit in ihm."

    # say L59 pla
    old "(Wow is s- she... S- sucking it...)"
    new "Wow, sie... sie saugt es..."

    # say L63 gra
    old "Your divine phallus tastes like heaven... Oh my Father, I'm so grateful."
    new "Ihr göttlicher Phallus schmeckt wie Himmel... Oh mein Vater, ich bin so dankbar."

    # say L67 gra
    old "My soul is silent and my door is open for you, I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "Meine Seele ist still und meine Tür ist für dich geöffnet, ich brauche dein heiliges Wasser in meinem Mund, ich habe viel Falsches gesagt und muss das reinigen."

    # say L68 gra
    old "I wanna feel it in my tongue... My tongue is thirsty of you..."
    new "Ich will es auf meiner Zunge spüren... Meine Zunge dürstet nach dir..."

    # say L91 gra
    old "I feel that grace is going to come... To come in my lips!!!"
    new "Ich spüre, dass die Gnade kommen wird... In meine Lippen!!!"

    # say L95 gra
    old "Ahhhhhhhh!!"
    new "Ahhhhhhh!!"

    # say L96 gra
    old "(My Godness!... This is heaven, divine!)"
    new "Meine Göttlichkeit!... Das ist der Himmel, göttlich!"

    # say L108 pla
    old "(Wow is s- she... S- sucking it again...)"
    new "Wow, sie... sie saugt es wieder..."

    # say L116 gra
    old "I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "Ich brauche Ihr heiliges Wasser in meinem Mund, ich habe viel Falsches gesagt und muss das reinigen."

    # say L147 gra
    old "Oh father, my soul is silent and my door is open for you, I need you inside of me cleaning my impure soul."
    new "Oh Vater, meine Seele ist still und meine Tür ist für dich offen, ich brauche dich in mir, um meine unreine Seele zu reinigen."

    # say L148 pla
    old "Does she wants me to f- fuck... her?"
    new "Will sie, dass ich sie... ficke?"

    # say L167 gra
    old "Ohhh father, I can feel your grace inside me!"
    new "Ohhh Vater, ich kann deine Gnade in mir spüren!"

    # say L168 gra
    old "And it feels sooo goood!"
    new "Und es fühlt sich soo gut an!"

    # say L169 pla
    old "(Ohh yeah...)"
    new "Ohh ja..."

    # say L173 gra
    old "Yes, father! Please clean all my sins harder!"
    new "Ja, Vater! Bitte reinige alle meine Sünden härter!"

    # say L174 gra
    old "Ohhh God! Oh God!"
    new "Ohhh Gott! Oh Gott!"

    # say L178 gra
    old "Ahhh Ahhh father. Yes, give me more! MORE!"
    new "Ahhh Ahhh Vater. Ja, gib mir mehr! MEHR!"

    # say L201 gra
    old "(My heavenly God!... I'm seeing the heaven!)"
    new "Mein himmlischer Gott!... Ich sehe den Himmel!"

    # say L202 gra
    old "I feel that grace is going to come... To come insid- Ahhhhhh!!!"
    new "Ich spüre, dass die Gnade kommt... Kommt rein- Ahhhhhh!!!"

    # say L219 gra
    old "My heavenly God, it's so big."
    new "Mein himmlischer Gott, es ist so groß."

    # say L224 gra
    old "Oh God! It tastes like heaven..."
    new "Oh Gott! Es schmeckt wie im Himmel..."

    # say L228 gra
    old "I need to purify my soul with your holy milk."
    new "Ich muss meine Seele mit deiner heiligen Milch reinigen."

    # say L251 pla
    old "Sister Grace... I- I-"
    new "Sister Grace... ich- ich-"

    # say L252 gra
    old "Oh yeah! I want to feel that grace in my mouth-"
    new "Oh ja! Ich will dieses Gefühl deiner Gnade in meinem Mund spüren-"

    # say L268 gra
    old "Ahhhhhh!!! I can feel the greatness of your body inside me..."
    new "Ahhhhh!!! Ich kann die Größe deines Körpers in mir spüren..."

    # say L273 gra
    old "I wanted this so badly... There is no pain I can't bear for God."
    new "Ich wollte das so sehr... Es gibt keinen Schmerz, den ich für Gott nicht ertragen würde."

    # say L274 gra
    old "Harder! Harder! I want you to make me feel more pain!"
    new "Stärker! Stärker! Ich will, dass du mir mehr Schmerz zufügst!"

    # say L279 gra
    old "Ahhhhhh! Ahhhhh! Ahhh!"
    new "Ahhhhh! Ahhhhh! Ahhh!"

    # say L280 gra
    old "My soul needs as much forgiveness as my body needs punishment."
    new "Meine Seele braucht so viel Vergebung wie mein Körper Bestrafung."


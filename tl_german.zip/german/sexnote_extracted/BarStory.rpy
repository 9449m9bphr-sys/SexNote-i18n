# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/BarStory.rpy
translate german strings:

    # say L4 bri
    old "Hey [pla], wake up!"
    new "Hey [pla], wach auf!"

    # say L5 pla
    old "Hmm... Just a little longer..."
    new "Hmm... Nur noch ein bisschen länger..."

    # say L6 bri
    old "I said..."
    new "Ich hab gesagt..."

    # say L13 pla
    old "What? What's happening? Is there anything wrong?!"
    new "Was? Was ist los? Ist was passiert?!"

    # say L14 bri
    old "What's wrong is that it's been a while since I created the portal we're going to use to restore the magic world."
    new "Was los ist, ist, dass es schon eine Weile her ist, seit ich das Portal geschaffen habe, das wir benutzen werden, um die magische Welt wiederherzustellen."

    # say L16 bri
    old "But I haven't seen you make any progress with our objective ever since."
    new "Aber ich habe seitdem keinen Fortschritt bei unserem Ziel gesehen."

    # say L17 bri
    old "Why is it taking so long for you to get to it?"
    new "Warum dauert es so lange, bis du dich daran machst?"

    # say L19 pla
    old "What?! You woke me up for that? What are you talking about?"
    new "Was?! Du hast mich dafür geweckt? Wovon redest du überhaupt?"

    # say L20 pla
    old "It's not as if it's easy you know?"
    new "Das ist ja nicht so einfach, weißt du?"

    # say L22 pla
    old "Do you want me to just walk around and tell people {i}'Hey! let me get you pregnant'{/i}?"
    new "Willst du, dass ich rumlaufe und Leuten sage {i}'Hey! Lass mich dich schwängern'{/i}?"

    # say L23 pla
    old "I can already imagine the looks I'll get."
    new "Ich kann mir schon vorstellen, wie sie mich ansehen werden."

    # say L25 bri
    old "That's not what you're going to do! You have to seduce them!"
    new "Das wirst du nicht tun! Du musst sie verführen!"

    # say L27 bri
    old "I thought you were supposed to be charming to human females."
    new "Ich dachte, du solltest charmant zu menschlichen Frauen sein."

    # say L29 bri
    old "Try that!"
    new "Versuch das!"

    # say L33 pla
    old "Why are you so worried about me doing it quickly anyway?"
    new "Warum machst du dir so viele Sorgen, dass ich es schnell mache?"

    # say L35 pla
    old "I thought you had stabilized the portal. So we have time, right?"
    new "Ich dachte, du hast das Portal stabilisiert. Also haben wir Zeit, oder?"

    # say L36 bri
    old "Yeah, time to do the ritual properly."
    new "Ja, Zeit, um das Ritual ordentlich durchzuführen."

    # say L38 bri
    old "Not to laze around and not get anything done!"
    new "Nicht rumzulümmeln und nichts zu tun!"

    # say L40 bri
    old "This is urgent business [pla]."
    new "Das ist dringendes Geschäft [pla]."

    # say L42 bri
    old "The magic world is gone, and this portal might be the only chance we get to save it."
    new "Die magische Welt ist verschwunden, und dieses Portal könnte unsere einzige Chance sein, sie zu retten."

    # say L44 bri
    old "And the fact that it's stable for now doesn't mean it's going to last forever."
    new "Und die Tatsache, dass es momentan stabil ist, heißt noch lange nicht, dass es ewig so bleibt."

    # say L46 bri
    old "If we want to reform the magic world we need to move fast!"
    new "Wenn wir die magische Welt retten wollen, müssen wir uns beeilen!"

    # say L48 bri
    old "There's no time to just lay about doing nothing."
    new "Da ist keine Zeit, rumzulümmeln und nichts zu tun."

    # say L49 pla
    old "Ok, I get it I get it! I'll get to it!"
    new "Ok, ich hab's kapiert! Ich mach's!"

    # say L50 bri
    old "When?"
    new "Wann?"

    # say L51 pla
    old "Soon!"
    new "Bald!"

    # say L53 pla
    old "Jeez! What's gotten into you all of a sudden?!"
    new "Mann! Was ist plötzlich in dich gefahren?!"

    # say L57 bri
    old "I'll remind you that you and your little friend Linnet made a mess out of this entire situation!"
    new "Ich werde dir noch mal ins Gedächtnis rufen, dass du und dein kleiner Freund Linnet diese ganze Situation versaucht habt!"

    # say L58 bri
    old "And I'm the one that's going to have to fix it!"
    new "Und ich bin diejenige, die das wieder in Ordnung bringen muss!"

    # say L60 bri
    old "So, since the portal won't last forever, and you clearly don't want to re-start the process from the beginning..."
    new "Dann such mal die Leute, die wir brauchen!"

    # say L62 bri
    old "Start looking for the people we need!"
    new "Dann such nach den Leuten, die wir brauchen!"

    # say L63 pla
    old "Ok, ok, I'll do it!... I guess I could start talking to people."
    new "Okay, okay, ich mach's!... Ich könnte wohl mal mit Leuten reden."

    # say L65 pla
    old "It's just that that's quite difficult to do, you know?"
    new "Das ist einfach ziemlich schwierig, weißt du?"

    # say L66 bri
    old "Oh come on, it won't be that bad."
    new "Oh komm schon, es wird nicht so schlimm sein."

    # say L68 bri
    old "I bet you'll get to have plenty of fun."
    new "Ich wette, du wirst viel Spaß dabei haben."

    # say L76 mo1
    old "Hello [pla], good morning."
    new "Hallo [pla], guten Morgen."

    # say L79 pla
    old "H- hi [mo1rel], how are you? Good morning."
    new "H-hi [mo1rel], wie geht es dir? Guten Morgen."

    # say L80 mo1
    old "Were you talking to someone?"
    new "Hast du mit jemandem gesprochen?"

    # say L81 pla
    old "What? No, no, no..."
    new "Was? Nein, nein, nein..."

    # say L82 pla
    old "Just to myself, you know?"
    new "Nur mit mir selbst, weißt du?"

    # say L85 mo1
    old "Listen [pla], I need you to do me a favor."
    new "Hör zu [pla], ich brauche einen Gefallen von dir."

    # say L92 pla
    old "Uhh... Sure, what do you need?"
    new "Uhh... Klar, was brauchst du?"

    # say L94 mo1
    old "Well, I was wondering if you could please bring some documents to the [mo2]'s office for me."
    new "Nun, ich wondered, ob du mir bitte ein paar Dokumente ins Büro der [mo2] bringen könntest."

    # say L95 mo1
    old "You don't need to go up to her office, just leave them at the reception of the building."
    new "Sie müssen nicht bis zu ihrem Büro hochgehen, legen Sie sie einfach an der Rezeption des Gebäudes ab."

    # say L97 pla
    old "Sure, no problem."
    new "Klar, kein Problem."

    # say L99 mo1
    old "Thank you so much, honey. You are always so helpful."
    new "Danke schön, Schatz. Du bist immer so hilfsbereit."

    # say L107 bri
    old "Hmm... I suppose you're going to do that for your [mo1rel] now, aren't you?"
    new "Hmm... Ich vermute, du wirst das jetzt für deinen [mo1rel] tun, oder?"

    # say L108 pla
    old "Uhh... Yeah, Of course."
    new "Uhh... Ja, klar."

    # say L110 bri
    old "Okay, I'm coming with you. You won't stop our task, so I'll help you look for our first target."
    new "Okay, ich komme mit. Du wirst unsere Aufgabe nicht aufhalten, also helfe ich dir bei der Suche nach unserem ersten Ziel."

    # say L112 pla
    old "{b}*Sigh*{/b} Alright, let's go."
    new "{b}*Seufz*{/b} Okay, lass uns gehen."

    # say L139 bri
    old "So, as I was saying, you should've at least talked to somebody while we were coming here."
    new "Also, wie ich schon sagte, hättest du dich wenigstens mit jemandem unterhalten, während wir hierher gekommen sind."

    # say L141 bri
    old "At this rate you're never going to end with what we have to do!"
    new "So, wenn du so weitermachst, wirst du nie damit fertig werden, was wir tun müssen!"

    # say L142 bri
    old "You should be putting all your focus on that!"
    new "Du solltest dich ganz darauf konzentrieren!"

    # say L149 pla
    old "But I have to do this first! So let me finish here, and then we can start looking for people for your ritual!"
    new "Aber ich muss das erst machen! Lass mich hier fertig werden, und dann können wir anfangen, Leute für dein Ritual zu suchen!"

    # say L151 bri
    old "Alright! But as soon as you finish, I'll pester you to get to it!"
    new "Okay! Aber sobald du fertig bist, werde ich dich drängeln, damit wir endlich anfangen!"

    # say L152 pla
    old "Yeah, yeah, whatever."
    new "Ja, ja, was auch immer."

    # say L221 pla
    old "Oh... Uhh... Yeah, Hi Barbie, how are you doing?"
    new "Oh... Uhh... Ja, hallo Barbie, wie geht's dir?"

    # say L232 pla
    old "Uhh... No, actually, I didn't come to see her."
    new "Uhh... Nein, eigentlich bin ich nicht hier, um sie zu sehen."

    # say L233 pla
    old "I have something for [mo2], but I was told I could just leave it with you."
    new "Ich hab was für [mo2], aber man hat mir gesagt, ich kann es einfach bei dir lassen."

    # say L236 bri
    old "Hey, [pla]!! Did you hear what I told you?!"
    new "Hey, [pla]!! Hast du gehört, was ich dir gesagt habe?!"

    # say L244 pla
    old "What? No, no, sorry."
    new "Was? Nein, nein, sorry."

    # say L245 pla
    old "I- uhm, I didn't mean to be rude."
    new "Ich- ähm, ich wollte nicht unhöflich sein."

    # say L247 pla
    old "I meant to say, {i}‘ok, alright, that's great'{/i}."
    new "Ich wollte sagen, {i}okay, okay, das ist super{/i}."

    # say L250 pla
    old "Right."
    new "Okay."

    # say L255 pla
    old "Sure, thank you."
    new "Klar, danke."

    # say L257 pla
    old "Thanks Barbie, I guess I'll see you later."
    new "Danke Barbie, ich schätze, ich seh dich später."

    # say L273 bri
    old "Great news [pla]! As I told you before, we have the first target to start cultivating power for the spell!"
    new "Große Neuigkeiten [pla]! Wie ich dir schon gesagt habe, haben wir das erste Ziel, um die Macht für den Zauber zu kultivieren!"

    # say L275 pla
    old "Yeah, I figured..."
    new "Klar, ich hab's mir schon gedacht..."

    # say L276 pla
    old "Is that why you interrupted me while I was talking to her?"
    new "Ist deshalb, dass du mich unterbrochen hast, während ich mit ihr geredet hab?"

    # say L278 bri
    old "Well, it was important that you knew..."
    new "Na ja, es war wichtig, dass du es weißt..."

    # say L279 bri
    old "But anyway, that doesn't matter."
    new "Aber egal, das ist jetzt egal."

    # say L281 bri
    old "What's important is that that woman you were talking with will be our first target."
    new "Wichtig ist, dass die Frau, mit der du gesprochen hast, unser erstes Ziel sein wird."

    # say L283 bri
    old "Well, while you two were talking, I was examining her."
    new "Während ihr beiden geredet habt, habe ich sie mir angesehen."

    # say L285 pla
    old "Yeah, I noticed... That was weird, luckily no one else can see you."
    new "Ja, das hab ich gemerkt... Das war seltsam, zum Glück kann uns niemand sonst sehen."

    # say L287 bri
    old "Yeah, yeah, whatever, the point is that she's the first person you have to seduce for our ritual."
    new "Ja, ja, egal, das Wichtigste ist, dass sie die Erste ist, die du für unseren Ritual verführen musst."

    # say L288 pla
    old "Huh?! W- why? Why does it have to be her?"
    new "Huh?! W- warum? Warum muss es ausgerechnet sie sein?"

    # say L290 bri
    old "Because she's the right specimen, she has just the right qualities we need for it."
    new "Weil sie das richtige Exemplar ist, sie hat genau die Eigenschaften, die wir dafür brauchen."

    # say L292 bri
    old "As far as you humans go, she's the best prospect I could have expected to find to start our ritual."
    new "Was die Menschen angeht, ist sie die beste Kandidatin, die ich mir für unseren Ritual hätte wünschen können."

    # say L294 pla
    old "Why? What's so special about her?"
    new "Warum? Was ist so Besonderes an ihr?"

    # say L296 bri
    old "Well, as I said she has the perfect qualities... To- to..."
    new "Na ja, wie ich schon sagte, sie hat die perfekten Eigenschaften... Zu- zu..."

    # say L298 bri
    old "H- host and... Condense the magic power within her."
    new "H- host und... die magische Energie in ihr kondensieren."

    # say L299 bri
    old "Her body composition is just the right one."
    new "Ihre Körpermischung ist genau die Richtige."

    # say L300 pla
    old "Right..."
    new "Richtig..."

    # say L301 bri
    old "Besides, this should be easy to do, right?"
    new "Außerdem, das sollte doch einfach sein, oder?"

    # say L303 bri
    old "Isn't she the type of female you male humans like?"
    new "Ist sie nicht genau der Typ Frau, den ihr männlichen Menschen magt?"

    # say L305 bri
    old "Her mammary glands are gigantic, even for the standards of what your species would consider big."
    new "Ihre Brüste sind riesig, selbst nach den Maßstäben dessen, was eure Spezies als groß betrachtet."

    # say L307 bri
    old "And I {i}know{/i} you just love that sort of thing."
    new "Und ich {i}weiß{/i}, dass du so was liebst."

    # say L309 bri
    old "So don't think too much about it. Just focus on having a good time."
    new "Dann denk nicht so viel drüber nach. Konzentrier dich einfach darauf, es zu genießen."

    # say L310 bri
    old "If you seduce her, and implant the magic within her you'll enjoy it, won't you?"
    new "Wenn du sie verführst und den Zauber in ihr implizierst, wirst du das genießen, oder?"

    # say L311 pla
    old "Ugh, I guess you're right."
    new "Ugh, ich schätze, du hast recht."

    # say L313 pla
    old "But I barely know her, we have never exchanged more than a couple of words, how the hell am I going to seduce her?"
    new "Aber ich kenne sie doch kaum, wir haben nie mehr als ein paar Worte gewechselt, wie soll ich sie da verführen?"

    # say L314 bri
    old "Don't worry, I'll help you with that."
    new "Mach dir keine Sorgen, ich helfe dir dabei."

    # say L315 pla
    old "Hahaha... Really? How?"
    new "Hahaha... Wirklich? Wie denn?"

    # say L317 bri
    old "By using magic of course!"
    new "Natürlich mit Magie!"

    # say L319 bri
    old "There's a lot of magic you still don't know about, you've barely scratched the surface of what's possible."
    new "Es gibt noch viel Magie, die du nicht kennst, du hast erst die Oberfläche gestreift, was möglich ist."

    # say L321 bri
    old "By employing a simple mind reading spell, I can get inside her thoughts and emotions."
    new "Durch den Einsatz eines einfachen Gedankenlesens kann ich in ihre Gedanken und Gefühle eintauchen."

    # say L322 bri
    old "And let you know what she has in her mind while you're speaking to her."
    new "Und dir verraten, was sie denkt, während du mit ihr sprichst."

    # say L324 bri
    old "I can even read deep thoughts, and see if anything is influencing her deep mind."
    new "Ich kann sogar tiefe Gedanken lesen und sehen, ob etwas ihren tiefen Geist beeinflusst."

    # say L326 pla
    old "I have to say, that sounds amazing."
    new "Ich muss sagen, das klingt unglaublich."

    # say L328 bri
    old "It is, but it's also inconvinient. Since I'll be reading her mind and telling you what she's thinking."
    new "Das ist es, aber es ist auch unangenehm. Denn ich werde ihre Gedanken lesen und dir sagen, was sie denkt."

    # say L329 bri
    old "That means that whenever you talk to her I'll have to be with you."
    new "Das bedeutet, dass ich immer bei dir sein muss, wenn du mit ihr redest."

    # say L331 bri
    old "Besides, in order to maintain the mind-reading, I have to keep the channel between her mind and mine open."
    new "Außerdem muss ich, um die Gedanken lesen zu können, den Kanal zwischen ihrem Geist und meinem offen halten."

    # say L332 bri
    old "That drains the magic power too quickly."
    new "Das verbraucht die magische Energie zu schnell."

    # say L333 bri
    old "So you'll have to be sure to make good use of the information I'm able to give you."
    new "Dann musst du sicherstellen, dass du die Informationen nutzt, die ich dir geben kann."

    # say L335 pla
    old "I get it, but if it's that difficult, why don't you teach me the spell to do it myself?"
    new "Verstehe, aber wenn es so schwierig ist, warum lehrst du mich dann nicht den Zauber, damit ich es selbst machen kann?"

    # say L336 pla
    old "That way I can just do the mind reading by myself, and your magic reserves won't have to be drained."
    new "Dann kann ich das Gedankenlesen selbst machen und deine magischen Reserven müssen nicht leer werden."

    # say L338 bri
    old "Sadly I can't do that, this spell is a level beyond your current abilities."
    new "Leider kann ich das nicht, dieser Zauber ist eine Stufe über deinen derzeitigen Fähigkeiten."

    # say L339 bri
    old "The complexity is too high for you to handle right now."
    new "Die Komplexität ist für dich im Moment zu hoch."

    # say L341 bri
    old "Maybe if you had been a bit more diligent with your practices..."
    new "Vielleicht, wenn du ein bisschen fleißiger bei deinen Übungen gewesen wärst..."

    # say L342 bri
    old "And had improved your abilities with the Sexnote, you'd be able to do it."
    new "Und hättest du deine Fähigkeiten mit dem SexNote verbessert, könntest du es jetzt."

    # say L343 bri
    old "But it didn't happen, did it?"
    new "Aber es ist nicht passiert, oder?"

    # say L345 bri
    old "So, I'll have to do the hard work of reading her mind and telling you what to say."
    new "Dann werde ich wohl die harte Arbeit machen müssen, ihre Gedanken zu lesen und dir zu sagen, was du sagen sollst."

    # say L346 pla
    old "I see, I guess that's how it has to be."
    new "Ich sehe, dann muss ich wohl die harte Arbeit machen und dir sagen, was du sagen sollst."

    # say L348 pla
    old "Oh! I know!"
    new "Oh! Ich hab's!"

    # say L350 pla
    old "What about the {i}Sauron Mouth?{/i} I could use that instead of you having to use your magic, right?"
    new "Was ist mit dem {i}Sauron Mund{/i}? Ich könnte den nehmen, anstatt dass du deine Magie benutzen musst, oder?"

    # say L352 bri
    old "What? What are you talking about? Didn't you pay attention when you learned the spell?!"
    new "Was? Wovon redest du? Hast du nicht aufgepasst, als du den Zauber gelernt hast?!"

    # say L354 bri
    old "The {i}Sauron Mouth{/i} doesn't work like that."
    new "Das {i}Sauron Maul{/i} funktioniert nicht so."

    # say L355 bri
    old "There are two conditions that prevent anyone from using it to just outright control another person."
    new "Es gibt zwei Bedingungen, die verhindern, dass jemand es benutzt, um einfach so eine andere Person zu kontrollieren."

    # say L357 bri
    old "First, it's not a mental power; it works by {b}influencing{/b}, not {b}forcing{/b} the will of the target."
    new "Erstens, es ist keine mentale Kraft; es wirkt durch {b}beeinflussen{/b}, nicht durch {b}Erzwingen{/b} des Willens des Ziels."

    # say L359 bri
    old "So, you can't just make someone do something they don't want to do, you can't go over personal limits."
    new "Du kannst also niemanden dazu zwingen, etwas zu tun, was er nicht will, du kannst seine persönlichen Grenzen nicht überschreiten."

    # say L361 bri
    old "Is not like you can just tell someone to fall in love with you or anything."
    new "Das ist nicht so, dass du jemandem einfach sagen kannst, sich in dich zu verlieben oder so."

    # say L362 pla
    old "I get it, I can't 'force' anyone with the {i}Sauron Mouth{/i}."
    new "Ich verstehe, ich kann niemanden mit dem {i}Sauron Mund{/i} 'zwingen'."

    # say L363 bri
    old "Is not just that, you can't use it on someone if you don't have a connection to them."
    new "Das ist nicht nur so, du kannst es bei jemandem nicht anwenden, wenn du keine Verbindung zu ihm hast."

    # say L365 bri
    old "So, even if you go up to her and tell her to do something, it won't work, since you barely know each other."
    new "Also, egal was du ihr sagst, es funktioniert nicht, wenn ihr euch kaum kennt."

    # say L367 bri
    old "There are no shortcuts for this [pla], you have to do it properly."
    new "Da gibt es keine Abkürzungen [pla], du musst es richtig machen."

    # say L368 pla
    old "I get it, I get it, so that's a no on the {i}Sauron Mouth{/i} then."
    new "Verstanden, verstanden, dann ist das also nein für die {i}Sauron Mund{/i}."

    # say L369 bri
    old "It is, you see why I keep pestering you to start working on the ritual? It's a lot of work, and we don't have much time."
    new "Dann siehst du, warum ich dich ständig dränge, mit dem Ritual anzufangen. Es ist eine Menge Arbeit, und wir haben nicht viel Zeit."

    # say L370 pla
    old "Yeah, yeah I get it."
    new "Ja, ja, ich verstehe."

    # say L372 bri
    old "Good, now that you understand it, let's go."
    new "Gut, jetzt wo du es verstehst, lass uns gehen."

    # say L374 pla
    old "What?! Now?"
    new "Was?! Jetzt?"

    # say L376 bri
    old "Yes, now! Haven't you understood how urgent this is?"
    new "Ja, jetzt! Hast du nicht verstanden, wie dringend das ist?"

    # say L377 pla
    old "But we just arrived! I was just there a moment ago! If I go back now, it will look weird."
    new "Aber wir sind gerade erst angekommen! Ich war gerade noch da! Wenn ich jetzt zurückgehe, sieht das komisch aus."

    # say L379 bri
    old "Don't you worry about that, after all, I will be reading her mind and telling you what you need to know to handle the situation."
    new "Mach dir darüber keine Sorgen, schließlich werde ich ihre Gedanken lesen und dir sagen, was du wissen musst, um die Situation zu meistern."

    # say L380 pla
    old "You sound very confident about this."
    new "Du klingst sehr selbstsicher dabei."

    # say L381 bri
    old "Well is not as if it's difficult..."
    new "Na ja, es ist ja nicht so, als wäre es schwierig..."

    # say L383 bri
    old "You humans are so easy to manipulate! You just have to say the right thing and you fold!"
    new "Ihr Menschen seid so leicht zu manipulieren! Man muss nur das Richtige sagen und schon gebt ihr nach!"

    # say L385 pla
    old "We do? How do you know that?"
    new "Machen wir das? Wie kommst du darauf?"

    # say L386 bri
    old "I- I mean..."
    new "Ich- Ich meine..."

    # say L388 bri
    old "It's what I've observed in my time here watching you and the other humans."
    new "Das ist, was ich in der Zeit hier beobachtet habe, wenn ich dir und den anderen Menschen zugesehen habe."

    # say L390 pla
    old "Hmm... alright."
    new "Hmm... okay."

    # say L391 pla
    old "I guess you're right."
    new "Ich schätze, du hast recht."

    # say L393 bri
    old "Of course I am!"
    new "Natürlich bin ich das!"

    # say L394 bri
    old "Now, let's go seduce that human with the big mammary glands!"
    new "Na los, lass uns den Menschen mit den großen Brüsten verführen!"

    # say L395 pla
    old "{b}*Sigh*{/b} Alright let's go."
    new "{b}*Seufz*{/b} Okay, lass uns gehen."

    # say L411 pla
    old "... Again."
    new "... Wieder."

    # say L417 pla
    old "Uhm, no."
    new "Uhm, nein."

    # say L419 pla
    old "I actually came to talk with you."
    new "Ich bin eigentlich gekommen, um mit dir zu reden."

    # say L422 pla
    old "Hmm, yeah..."
    new "Hmm, ja..."

    # say L424 pla
    old "About what..."
    new "Worüber..."

    # say L425 pla
    old "Hmm, that's... {i}a good question...{/i}"
    new "Hmm, das ist... {i} eine gute Frage...{/i}"

    # say L426 bri
    old "Sigh! Look at you strugling to come up with something."
    new "Seufz! Schau dir an, wie du da kämpfst, um was zu sagen."

    # say L427 bri
    old "Don't worry, I have this."
    new "Mach dir keine Sorgen, ich hab das im Griff."

    # say L432 bri
    old "[pla]! She's feeling sad about something."
    new "[pla]! Sie sieht traurig aus."

    # say L435 pla
    old "Is just that you looked a little sad to me when I saw you."
    new "Ich dachte nur, du siehst ein bisschen traurig aus, als ich dich gesehen habe."

    # say L436 pla
    old "So I was wondering if there's anything that I could do for you, maybe you would like to talk about it?"
    new "Dann dachte ich mir, vielleicht gibt es etwas, das ich für dich tun kann, möchtest du darüber reden?"

    # say L447 bri
    old "That's a lie! She's feeling a great sadness!"
    new "Das ist eine Lüge! Sie fühlt sich sehr traurig!"

    # say L448 bri
    old "I don't know yet what it is, but she's definitely sad about something."
    new "Ich weiß noch nicht genau, was es ist, aber sie ist definitiv traurig über etwas."

    # say L450 pla
    old "Are you sure about it?"
    new "Bist du dir da sicher?"

    # say L451 pla
    old "I don't want to be annoying or anything, is just that you seem like you have a lot on your mind."
    new "Ich will dich nicht nerven oder so, aber es scheint, als hättest du viel im Kopf."

    # say L453 pla
    old "And I would like to help you with {i}anything{/i} if possible."
    new "Und ich würde dir gerne bei {i}allem{/i}helfen, wenn es geht."

    # say L463 bri
    old "Oh! It seems she's feeling frustrated about something!"
    new "Oh! Es scheint, sie ist über etwas frustriert!"

    # say L464 bri
    old "It's just hard to tell about what... She has a lot of emotions and thoughts going through her..."
    new "Es ist einfach schwer zu sagen, worum es geht... Sie hat so viele Gefühle und Gedanken im Kopf..."

    # say L465 bri
    old "Just give me a second."
    new "Gib mir einfach einen Moment."

    # say L467 pla
    old "Really? That's a relief to hear, it's good that you're doing so well."
    new "Wirklich? Das ist eine Erleichterung zu hören, es ist gut, dass es dir so gut geht."

    # say L468 pla
    old "It just looked for a moment there like you had something in your mind."
    new "Es sah nur so aus, als hättest du was im Kopf."

    # say L470 pla
    old "Kind of as if you were feeling {b}frustrated{/b} about something."
    new "Als ob du wegen etwas {b}frustriert{/b} wärst."

    # say L471 pla
    old "But you aren't, right?"
    new "Aber das bist du doch nicht, oder?"

    # say L484 bri
    old "And it's related to why she's feeling frustrated."
    new "Und es hat damit zu tun, warum sie frustriert ist."

    # say L485 bri
    old "She recently failed at something..."
    new "Sie hat kürzlich bei etwas versagt..."

    # say L487 bri
    old "An audition!"
    new "Eine Besetzung!"

    # say L490 bri
    old "What's an audition?"
    new "Was ist eine Besetzung?"

    # say L491 pla
    old "{i}(I see now!){/i}"
    new "{i}(I sehe es jetzt!){/i}"

    # say L492 pla
    old "Well, I'm happy you're feeling well."
    new "Na, ich freue mich, dass es dir gut geht."

    # say L494 pla
    old "Maybe I'm just projecting myself."
    new "Vielleicht projiziere ich mich einfach."

    # say L496 pla
    old "You see, I recently failed an interview for a job I wanted."
    new "Du, ich hab kürzlich ein Vorstellungsgespräch für einen Job vermasselt, den ich wollte."

    # say L501 pla
    old "Yeah... I really wanted to get it. And I thought I was the best for it, but the hiring team chose someone else."
    new "Ja... Ich hab's echt gewollt. Und ich dachte, ich wär der Beste dafür, aber das Bewerbungsteam hat jemand anderen genommen."

    # say L508 bri
    old "[pla]! Now she's remembering something else!"
    new "[pla]! Jetzt fällt ihr was anderes ein!"

    # say L511 bri
    old "What is this feeling?..."
    new "Was ist dieses Gefühl?..."

    # say L518 pla
    old "But I guess I have to let it go."
    new "Aber ich schätze, ich muss es loslassen."

    # say L520 pla
    old "I think that, sadly, sometimes our projects don't turn out the way we want them to. You know?"
    new "Ich denke, manchmal müssen wir einfach akzeptieren, dass unsere Projekte nicht so laufen, wie wir es uns wünschen. Du weißt schon?"

    # say L523 pla
    old "You do?"
    new "Du meinst?"

    # say L529 pla
    old "Yeah, that's right."
    new "Stimmt, genau."

    # say L530 pla
    old "But you know what? I think I'll give it another go and I'll try to get that job."
    new "Aber weißt du was? Ich denke, ich geb's noch mal einen Versuch und werde versuchen, den Job zu kriegen."

    # say L536 pla
    old "Well, I guess I'll just have to try again, and again until I make it."
    new "Dann werde ich eben weitermachen, bis es klappt."

    # say L538 pla
    old "After all, this job is sort of a {i}dream{/i} of mine."
    new "Schließlich ist dieser Job so eine Art {i}Traum{/i} von mir."

    # say L539 pla
    old "So I wouldn't want to give up on it for nothing."
    new "Dann würde ich es für nichts aufgeben."

    # say L544 pla
    old "Do you? What do you mean?"
    new "Meinst du das ernst? Was willst du damit sagen?"

    # say L547 pla
    old "Is there something you shouldn't give up on?"
    new "Gibt es etwas, woran du nicht aufgeben solltest?"

    # say L548 bri
    old "Ohh, he is not bad at this..."
    new "Ohh, der ist ja gar nicht schlecht darin..."

    # say L551 pla
    old "Come on, I know there's something on your mind that's been making you feel rather bad."
    new "Komm schon, ich weiß, dass da was ist, das dir ziemlich zu schaffen macht."

    # say L554 pla
    old "If you need to talk about it I'll be more than happy to hear you."
    new "Wenn du darüber reden willst, bin ich mehr als bereit, dir zuzuhören."

    # say L556 pla
    old "After all... I already told you about my situation."
    new "Schließlich... Ich habe dir doch schon von meiner Situation erzählt."

    # say L558 pla
    old "Maybe I could help you with yours."
    new "Vielleicht könnte ich dir bei deinem helfen."

    # say L564 pla
    old "What? What do you mean?"
    new "Was? Was meinst du damit?"

    # say L566 pla
    old "Listen, if this is something you want, and it's important to you, there's no way that it is ridiculous!"
    new "Hör zu, wenn das für dich wichtig ist und du es willst, dann ist das auf keinen Fall lächerlich!"

    # say L574 bri
    old "She's feeling very bad [pla], there's something bothering her deeply."
    new "Sie fühlt sich sehr schlecht [pla], da ist etwas, das sie tief bewegt."

    # say L575 bri
    old "What she's transmitting more strongly is a very deep feeling of insecurity."
    new "Was sie stärker vermittelt, ist ein tiefes Gefühl von Unsicherheit."

    # say L578 pla
    old "Listen Barbie."
    new "Hör zu, Barbie."

    # say L579 pla
    old "I understand that sometimes things don't go the way we want them to."
    new "Ich verstehe, dass manchmal Dinge nicht so laufen, wie wir wollen."

    # say L581 pla
    old "But if it's something that's really important for you, I think it's worth it to give it a shot."
    new "Aber wenn es etwas ist, das dir wirklich wichtig ist, denke ich, es lohnt sich, es zu versuchen."

    # say L583 pla
    old "Don't you think? Why don't you let me know about it?"
    new "Meinst du nicht? Warum erzählst du mir nicht davon?"

    # say L599 pla
    old "I see, it must be very frustrating to deal with that."
    new "Ich verstehe, das muss sehr frustrierend sein."

    # say L601 pla
    old "But I'm sure you still can make that dream a reality..."
    new "Aber ich bin sicher, dass du diesen Traum noch verwirklichen kannst..."

    # say L602 pla
    old "I mean, I'm sure there are a lot of auditions being held every day, aren't there?"
    new "Ich meine, es gibt doch sicherlich jeden Tag viele Vorsprechaufnahmen, oder?"

    # say L604 pla
    old "You might land a role sooner rather than later, and that could propel you upward, isn't that right?"
    new "Du könntest eine Rolle schneller als gedacht ergattern und das könnte dich nach oben katapultieren, oder?"

    # say L614 pla
    old "Why would you say that?"
    new "Warum sagst du das?"

    # say L626 pla
    old "That's terrible! They have no right to treat you that way!"
    new "Das ist schrecklich! Sie haben kein Recht, dich so zu behandeln!"

    # say L627 pla
    old "Besides, it isn't fair to say something like that."
    new "Außerdem ist es nicht fair, so etwas zu sagen."

    # say L630 pla
    old "I'm sorry about that, Barbie."
    new "Das tut mir leid, Barbie."

    # say L635 pla
    old "No, they're not."
    new "Nein, das sind sie nicht."

    # say L637 pla
    old "You don't have to believe that just because they say it to you."
    new "Du musst das nicht glauben, nur weil sie es dir sagen."

    # say L643 bri
    old "[pla]! She's thinking about something!"
    new "[pla]! Sie denkt über etwas nach!"

    # say L644 bri
    old "But it isn't clear what it is."
    new "Aber es ist nicht klar, was es ist."

    # say L646 bri
    old "Keep talking to her, maybe she'll open up more."
    new "Rede weiter mit ihr, vielleicht wird sie sich mehr öffnen."

    # say L648 pla
    old "I mean, I'm sure you've faced some obstacles, right?"
    new "Ich meine, ich bin sicher, du hast schon ein paar Hürden überwunden, oder?"

    # say L650 bri
    old "Something just came up on her mind!"
    new "Irgendetwas ist ihr gerade eingefallen!"

    # say L651 bri
    old "Something about..."
    new "Etwas bezüglich..."

    # say L652 bri
    old "{i}Number of auditions?{/i}"
    new "{i}Anzahl der Vorsprechaufnahmen?{/i}"

    # say L654 bri
    old "What is that?"
    new "Was meinst du damit?"

    # say L658 pla
    old "Like, have you gotten enough auditions? I bet you haven't been able to attend to many, right?"
    new "Hast du genug Vorsprechaufnahmen gemacht? Ich wette, du konntest nicht viele machen, oder?"

    # say L664 pla
    old "You see? It isn't your fault."
    new "Du siehst? Das ist nicht deine Schuld."

    # say L672 bri
    old "[pla]! Something else just came into her mind!"
    new "[pla]! Irgendetwas anderes ist ihr gerade eingefallen!"

    # say L674 bri
    old "I'm not sure, her mind's kinda foggy."
    new "Ich bin mir nicht sicher, ihr Kopf ist irgendwie vernebelt."

    # say L681 bri
    old "Practice! She's thinking about not being able to practice!"
    new "Üben! Sie denkt daran, dass sie nicht genug Zeit zum Üben hat!"

    # say L683 pla
    old "I mean, you are working here full time, I bet it's very difficult to do things like acting if you don't have enough practice time."
    new "Ich meine, du arbeitest hier Vollzeit, ich wette, es ist sehr schwierig, Dinge wie Schauspielerei zu machen, wenn du nicht genug Übungszeit hast."

    # say L684 pla
    old "Right?"
    new "Stimmt?"

    # say L692 bri
    old "She's not thinking about time [pla], there's something else there."
    new "Sie denkt nicht an die Zeit [pla], da ist noch was anderes."

    # say L694 bri
    old "Partners?"
    new "Partner?"

    # say L696 bri
    old "I don't know what she means by that."
    new "Ich hab keine Ahnung, was sie damit meint."

    # say L697 pla
    old "{i}But I think I do! Thanks Brixxida!{/i}"
    new "{i}Aber ich glaube schon! Danke Brixxida!{/i}"

    # say L699 pla
    old "Yeah, I bet that since you're always working here."
    new "Klar, ich wette, dass es schwierig ist, Partner zu finden, wenn man ständig hier arbeitet."

    # say L702 pla
    old "It must be very difficult  to find partners to practice with."
    new "Es muss sehr schwierig sein, Partner zu finden, mit denen du üben kannst."

    # say L704 pla
    old "And even if you did find them, making the space to practice must be very difficult. Right?"
    new "Und wenn du sie gefunden hättest, Platz zum Üben zu finden muss auch ziemlich schwierig sein, oder?"

    # say L710 pla
    old "But you know, those things can be dealt with."
    new "Aber du weißt, das kann man regeln."

    # say L712 pla
    old "How about I help you with them?"
    new "Dann lass mich dir dabei helfen."

    # say L719 pla
    old "Uhm... W- well..."
    new "Äh... W-wie..."

    # say L720 pla
    old "S- since you can't practice with other actors, how about I do it with you?"
    new "Da du dich mit anderen Schauspielern nicht üben kannst, wie wäre es, wenn ich es mit dir mache?"

    # say L721 pla
    old "I could give you pointers and help you memorize your lines."
    new "Ich könnte dir Tipps geben und dir helfen, deine Zeilen auswendig zu lernen."

    # say L730 pla
    old "M- maybe I could help you find another audition."
    new "M- vielleicht könnte ich dir helfen, eine andere Besetzung zu finden."

    # say L731 pla
    old "I understand that you're very busy."
    new "Ich verstehe, dass du sehr beschäftigt bist."

    # say L732 pla
    old "So, how about I'm the one that searches around, and helps you find auditions for roles that you may be good at?"
    new "Dann suche ich mal nach Rollen, die zu dir passen könnten, und helfe dir bei den Vorsprechen?"

    # say L737 pla
    old "Y- Your agent?"
    new "D- Deine Agentin?"

    # say L742 pla
    old "I- I don't think that's..."
    new "Ich glaube nicht, dass das..."

    # say L748 bri
    old "Yes! Say yes! That's exactly what she wants! I can see it in her mind!"
    new "Ja! Sag ja! Das ist genau das, was sie will! Ich sehe es in ihrem Kopf!"

    # say L749 pla
    old "{i}B- but, being an agent is...{/i}"
    new "{i}B- aber, Agent zu sein ist...{/i}"

    # say L751 bri
    old "What are you so hesitant about? Just say yes or you won't be able to establish a relationship with her!"
    new "Was zögerst du so? Sag einfach Ja, sonst wirst du keine Beziehung zu ihr aufbauen können!"

    # say L752 bri
    old "We'll figure out how to do that later!"
    new "Wir klären das später!"

    # say L753 pla
    old "{b}*Sigh*{/b}"
    new "{b}*Seufz*{/b}"

    # say L756 pla
    old "Yeah, you're right, I would be acting as your manager."
    new "Ja, du hast recht, ich würde als dein Manager agieren."

    # say L757 pla
    old "... I guess."
    new "Na ja, ich schätze."

    # say L759 pla
    old "Well, I just want to help you."
    new "Na ja, ich will dir einfach nur helfen."

    # say L761 pla
    old "After all, I told you you shouldn't give up on your dreams."
    new "Schließlich hab ich dir gesagt, dass du deine Träume nicht aufgeben sollst."

    # say L763 pla
    old "So... How about I go home for now and start making some calls?"
    new "Dann... Wie wär's, wenn ich jetzt nach Hause gehe und ein paar Anrufe mache?"

    # say L765 pla
    old "And if something comes up I'll let you know."
    new "Und wenn was passiert, lass ich es dich wissen."

    # say L778 pla
    old "Uhm, happy to help..."
    new "Uhm, gerne helfe ich dir..."

    # say L779 pla
    old "I guess I'll see you later then, Bye."
    new "Dann sehen wir uns später, tschüss."

    # say L795 pla
    old "Ok, I think that went well."
    new "Okay, ich denke, das lief gut."

    # say L797 bri
    old "What are you talking about?! Why didn't you have sex with her?!"
    new "Wovon redest du?! Warum hast du nicht mit ihr geschlafen?!"

    # say L799 bri
    old "I told you, you humans are very easy to manipulate."
    new "Ich hab's dir doch gesagt, ihr Menschen seid sehr leicht zu manipulieren."

    # say L801 bri
    old "I thought that by helping you talk to her you would already be having sex with her!"
    new "Ich dachte, indem ich dir helfe, mit ihr zu reden, würdest du schon längst mit ihr schlafen!"

    # say L803 bri
    old "You know we don't have much time!"
    new "Du weißt, wir haben nicht viel Zeit!"

    # say L805 pla
    old "Well, I'm sorry, I thought you didn't have any spells that would make her have sex with me right away."
    new "Na ja, tut mir leid, ich dachte, du hättest keine Sprüche, die sie sofort mit mir schlafen lassen."

    # say L806 bri
    old "I don't have any, that doesn't exist."
    new "Ich hab keine, das gibt es nicht."

    # say L808 pla
    old "Then how about you let me handle this and stop yelling at me about it?"
    new "Dann lass mich das doch machen und hör auf, mich deswegen anzuschreien."

    # say L810 pla
    old "What you told me about her barely helped me a little to connect with her."
    new "Was du mir über sie erzählt hast, hat mir nur ein bisschen geholfen, mich mit ihr zu verbinden."

    # say L811 pla
    old "Listen, is not as easy to convince humans to have sex just like that."
    new "Hör zu, es ist nicht so einfach, Menschen dazu zu bringen, einfach so mit dir zu schlafen."

    # say L813 pla
    old "You may be able to read minds, but you don't know how human emotions work."
    new "Du kannst vielleicht Gedanken lesen, aber du verstehst nicht, wie menschliche Emotionen funktionieren."

    # say L815 pla
    old "So let me handle this, ok?"
    new "Dann lass mich das machen, ok?"

    # say L816 bri
    old "Fine... I'll let you do what you want."
    new "Okay... Ich lasse dir freie Hand."

    # say L818 bri
    old "But be sure to do it quickly!"
    new "Aber mach es schnell!"

    # say L820 bri
    old "Magic power is not eternal in case you forgot!"
    new "Magie ist nicht ewig, falls dir das entfallen sein sollte!"

    # say L821 bri
    old "And I already used a lot of it today, so be sure you do this properly."
    new "Und ich habe heute schon viel davon verbraucht, also mach das jetzt richtig."

    # say L822 pla
    old "Yeah, yeah, I'll be sure to do what you need."
    new "Ja, ja, ich werde sicherstellen, dass ich es richtig mache."

    # say L824 pla
    old "But I'm in a tight spot with this. I know nothing about acting. I'll have to come up with something."
    new "Aber ich stecke hier echt in der Klemme. Ich hab keine Ahnung von Schauspielerei. Muss mir was einfallen lassen."

    # say L826 pla
    old "But I just don't have any ideas about how..."
    new "Aber ich hab einfach keine Ideen, wie..."

    # say L827 pla
    old "And I don't know anybody that works in acting, how am I going to get her an audition..."
    new "Und ich kenne niemanden, der im Schauspielbusiness arbeitet, wie soll ich ihr denn ein Vorsprechen besorgen..."

    # say L828 bri
    old "Well, that was your idea after all..."
    new "Na ja, das war deine Idee, oder?"

    # say L829 pla
    old "What? You were the one who told me to accept being your agent. I didn't even..."
    new "Was? Du warst diejenige, die mir gesagt hat, ich soll dein Agent werden. Ich hab ja gar nicht..."

    # say L834 pla
    old "She's very into content creation and social media."
    new "Sie ist total in Content Creation und Social Media drin."

    # say L836 pla
    old "It may be a long shot, but maybe she knows somebody who could help us with this."
    new "Das ist vielleicht ein Schuss ins Blaue, aber vielleicht kennt sie jemanden, der uns helfen könnte."

    # say L838 pla
    old "Right now is a little late, but I'll go talk to her soon to see if she could help me."
    new "Jetzt ist es ein bisschen spät, aber ich rede bald mit ihr, um zu sehen, ob sie mir helfen kann."

    # say L839 bri
    old "Yes, honestly, I need to recharge. I spent a lot of magical power today, so I need to recover, and I won't be able to help you for a few days."
    new "Ja, ehrlich gesagt, ich muss mich aufladen. Ich habe heute viel magische Energie verbraucht und brauche Zeit, um mich zu regenerieren. In den nächsten Tagen werde ich dir nicht helfen können."

    # say L840 pla
    old "Hmm, alright, I can handle it with Belle for now, and what you helped with Barbie was a lot; at least, she trusts me now."
    new "Hmm, okay, ich komme mit Belle zurecht, und was du für Barbie getan hast, war schon viel; zumindest vertraut sie mir jetzt."

    # say L841 bri
    old "Ok, then see you tomorrow, [pla]."
    new "Ok, dann bis morgen, [pla]."

    # say L842 pla
    old "Sure, have a good rest."
    new "Klar, schlaf gut."

    # say L863 pla
    old "Hey Belle! How are you?"
    new "Hey Belle! Wie geht's dir?"

    # say L865 bel
    old "Hey [pla]! Good morning! I'm fine, thank you."
    new "Hey [pla]! Guten Morgen! Mir geht’s gut, danke."

    # say L867 bel
    old "How about you? Are you doing well?"
    new "Und du? Geht es dir gut?"

    # say L869 pla
    old "Well... Yeah, I'm doing well."
    new "Na ja... Ja, mir geht's auch gut."

    # say L871 pla
    old "But you see... There's this situation.... It's a little complicated and I was wondering if you could help me with it."
    new "Aber du siehst... Da ist diese Situation... Es ist ein bisschen kompliziert und ich dachte, du könntest mir dabei helfen."

    # say L873 bel
    old "Uhmm... Sure, whatever I can help you with, I'll be happy to do it."
    new "Hmm... Klar, was immer ich tun kann, mache ich gerne."

    # say L874 bel
    old "What  is it?"
    new "Was ist los?"

    # say L876 pla
    old "Well, do you know the business building in the center of town?"
    new "Na klar, kennst du das Geschäftshaus im Stadtzentrum?"

    # say L878 bel
    old "Sure, my mom's previous office was located there. I used to go from time to time."
    new "Klar, da war das Büro meiner Mom früher. Ich bin ab und zu mal hin."

    # say L880 pla
    old "Oh, nice. Well, the thing is that I sometimes have to go there."
    new "Oh, toll. Also, manchmal muss ich da hin, um ein paar Dokumente für einen Familienmitglied abzugeben oder so."

    # say L881 pla
    old "You know, to bring documents for a family member from time to time, that kind of stuff."
    new "Du weißt schon, um mal Dokumente für eine Familienmitglied abzugeben, so was in der Art."

    # say L885 pla
    old "Well the other day I came there to bring some documents, and I got to talking with the receptionist of the building."
    new "Na ja, letzten Dienstag war ich da, um ein paar Dokumente abzugeben, und da habe ich mich mit der Rezeptionistin des Gebäudes unterhalten."

    # say L889 pla
    old "Yeah, do you know her?"
    new "Klar, kennst du sie?"

    # say L891 bel
    old "I do, from when I used to come to my mom's office."
    new "Klar, von damals, als ich oft bei meiner Mutter im Büro war."

    # say L893 bel
    old "We never really talked much, but I remember she's a very nice girl."
    new "Wir haben nie viel gesprochen, aber ich erinnere mich, dass sie ein sehr nettes Mädchen ist."

    # say L894 pla
    old "Oh yeah, sure, she's very nice."
    new "Oh ja, klar, sie ist sehr nett."

    # say L896 pla
    old "But you see, when I got there the other day, I saw that she was very sad."
    new "Aber weißt du, als ich da war, hab ich gesehen, dass sie total traurig war."

    # say L897 bel
    old "Why? Is she okay?"
    new "Warum? Geht es ihr gut?"

    # say L898 pla
    old "Well, nothing bad has happened, but you see..."
    new "Na ja, nichts Schlimmes ist passiert, aber siehst du..."

    # say L900 pla
    old "I asked her what was wrong."
    new "Ich hab sie gefragt, was los ist."

    # say L902 pla
    old "And after we got to talking, she told me that she's been feeling very frustrated as of late."
    new "Und nachdem wir uns unterhalten haben, hat sie mir erzählt, dass sie sich schon seit einiger Zeit sehr frustriert fühlt."

    # say L904 pla
    old "Because she feels like her life is just coming to a halt, and she doesn't know what to do about it."
    new "Weil sie das Gefühl hat, dass ihr Leben zum Stillstand gekommen ist, und sie weiß nicht, was sie dagegen tun soll."

    # say L905 bel
    old "Why? What's happening?"
    new "Warum? Was passiert da?"

    # say L907 pla
    old "Well, as she told me, she originally came to town looking for opportunities to be an actress."
    new "Na ja, wie sie mir erzählt hat, ist sie ursprünglich in die Stadt gekommen, um als Schauspielerin Karriere zu machen."

    # say L908 pla
    old "But ever since she arrived, she's been attending one audition after another."
    new "Aber seit sie hier ist, geht sie von einer Besetzungstestsitzung zur nächsten."

    # say L910 pla
    old "Without ever being selected to any roles."
    new "Ohne jemals für eine Rolle ausgewählt zu werden."

    # say L911 bel
    old "I understand [pla], that's a very sad thing."
    new "Ich verstehe [pla], das ist sehr traurig."

    # say L912 bel
    old "The thing you wanted me to help you with is related to that?"
    new "Die Sache, bei der du meine Hilfe gebraucht hast, hat damit zu tun?"

    # say L914 pla
    old "It is, at first I only thought that she was just a little frustrated about not being able to book any roles."
    new "Es ist so, am Anfang dachte ich nur, sie wäre ein bisschen frustriert, weil sie keine Rollen bekommen konnte."

    # say L915 pla
    old "But while we talked I came to realize how important being an actress is to her."
    new "Aber während wir geredet haben, wurde mir klar, wie wichtig es für sie ist, Schauspielerin zu sein."

    # say L916 pla
    old "This is what she wants to do the most in life."
    new "Das ist das Wichtigste für sie im Leben."

    # say L918 pla
    old "To the point where she's feeling depressed for being unable to get any opportunities to act."
    new "So sehr, dass sie depressiv wird, weil sie keine Chancen bekommt, Schauspielerin zu sein."

    # say L919 bel
    old "I get it [pla], I understand that feeling."
    new "Ich verstehe [pla], ich kenne dieses Gefühl."

    # say L920 bel
    old "The frustration of not being able to live your dreams."
    new "Die Frustration, nicht imstande zu sein, deine Träume zu leben."

    # say L921 bel
    old "It's overwhelming..."
    new "Es ist überwältigend..."

    # say L922 pla
    old "Yeah it is, but it's not just that."
    new "Ja, das ist es, aber es ist nicht nur das."

    # say L923 pla
    old "She's also feeling bad about not being able to even try."
    new "Sie fühlt sich auch schlecht, weil sie es nicht mal versuchen kann."

    # say L924 pla
    old "Since she's always so busy working, she can't look for auditions."
    new "Da sie immer so beschäftigt mit der Arbeit ist, kann sie nicht nach Vorsprechen suchen."

    # say L926 pla
    old "Or attend acting classes whenever she gets a role."
    new "Oder an Schauspielkurse teilnehmen, wann immer sie eine Rolle kriegt."

    # say L928 pla
    old "So, after hearing of all the things she's been going through, I decided to help her."
    new "Also, nachdem ich von all den Dingen gehört habe, die sie durchmacht, hab ich mich entschieden, ihr zu helfen."

    # say L929 pla
    old "I think that's just the best thing that I could do right now, you know?"
    new "Ich denke, das ist einfach das Beste, was ich im Moment tun kann, weißt du?"

    # say L931 bel
    old "Yeah, I understand [pla], and I think that's just a great thing for you to do."
    new "Ja, ich verstehe [pla], und ich finde das ist eine tolle Sache, die du tust."

    # say L932 pla
    old "Thanks Belle!"
    new "Danke Belle!"

    # say L934 pla
    old "And that's more or less what I need your help with."
    new "Und das ist mehr oder weniger, bei dem ich deine Hilfe brauche."

    # say L936 pla
    old "I ended up promising her that I would help her with the whole process of getting auditions."
    new "Ich hab ihr versprochen, ihr bei dem ganzen Prozess mit den Vorsprechen zu helfen."

    # say L937 pla
    old "But truth be told, I don't know how to do that."
    new "Aber ehrlich gesagt, ich habe keine Ahnung, wie man das macht."

    # say L939 pla
    old "I haven't ever even seen any acting agencies, or anything like that. So I don't know where to start."
    new "Ich hab noch nie eine Schauspielschule oder so was gesehen. Also hab ich keine Ahnung, wo ich anfangen soll."

    # say L941 pla
    old "That's why I thought you might be able to help me with it."
    new "Deshalb dachte ich, du könntest mir dabei helfen."

    # say L943 pla
    old "I know you're very active on social media and you know a lot of people in the industry."
    new "Ich weiß, dass du sehr aktiv auf Social Media bist und viele Leute aus der Branche kennst."

    # say L944 pla
    old "And you know, you also work a lot in content creation and that kind of stuff."
    new "Und du arbeitest ja auch viel im Content Creation und so."

    # say L946 pla
    old "So, I was thinking that maybe you knew of a way for me to get an audition for her."
    new "Dann dachte ich mir, vielleicht kennst du ja einen Weg, wie ich bei ihr vorsprechen kann."

    # say L947 pla
    old "Or maybe you knew of a studio of something like that..."
    new "Oder vielleicht kennst du ein Studio oder so was..."

    # say L948 bel
    old "Hmm, I see what you mean..."
    new "Hmm, ich verstehe, was du meinst..."

    # say L950 bel
    old "You know, there may be someone that could..."
    new "Du, da könnte jemand sein, der..."

    # say L959 luc
    old "[pla], Belle, the class bell already rang."
    new "[pla], Belle, die Schulglocke hat schon geläutet."

    # say L960 luc
    old "Hurry up and get to the classroom or you'll be late."
    new "Schnell ins Klassenzimmer, sonst kommst du zu spät."

    # say L994 bel
    old "So, while we were in class I got to thinking, and it came to my mind that I might know of a place where she could go."
    new "Na ja, während wir im Unterricht waren, habe ich nachgedacht und mir ist eingefallen, dass ich vielleicht einen Ort kenne, wo sie hin könnte."

    # say L995 pla
    old "You did? Great!"
    new "Du hast? Toll!"

    # say L996 bel
    old "Yeah, just let me do a couple of calls and I'll let you know."
    new "Klar, lass mich ein paar Anrufe machen und ich geb dir Bescheid."

    # say L1000 bel
    old "In fact, I'll call right now and I'll let you know right away."
    new "Tatsächlich rufe ich gleich an und lass es dich sofort wissen."

    # say L1012 bel
    old "Alright, I talked with a couple of my contacts."
    new "Okay, ich habe mich mit ein paar Kontakten von mir unterhalten."

    # say L1014 bel
    old "Great news! They said they would agree to audition her for an upcoming role."
    new "Super Neuigkeiten! Sie haben zugesagt, sie für eine kommende Rolle vorsprechen zu lassen."

    # say L1016 bel
    old "I'll give you their number so you can call and see when she could go there."
    new "Ich geb dir ihre Nummer, damit du anrufen kannst und gucken, wann sie da vorbeikommen kann."

    # say L1018 bel
    old "I already gave them your info, so they'll know you're calling on my recommendation."
    new "Ich hab ihnen schon deine Infos gegeben, dann wissen sie, dass du auf meine Empfehlung anrufst."

    # say L1019 pla
    old "Great! Thanks a lot, Belle!"
    new "Super! Danke schön, Belle!"

    # say L1021 bel
    old "It's fine, I'm happy to be able to help."
    new "Kein Problem, ich freue mich, helfen zu können."

    # say L1022 bel
    old "From what you told me about Barbie's story, she needs this opportunity."
    new "Von dem, was du mir über Barbies Geschichte erzählt hast, braucht sie diese Chance."

    # say L1023 bel
    old "I know that if it was me I would love to get any help that I could get."
    new "Ich weiß, wenn es mich beträfe, würde ich jede Hilfe, die ich kriegen könnte, liebend gern annehmen."

    # say L1024 bel
    old "So I'm very happy to help."
    new "Dann freue ich mich sehr, zu helfen."

    # say L1026 pla
    old "That's great Belle, and a huge help!"
    new "Das ist toll, Belle, und eine riesige Hilfe!"

    # say L1027 pla
    old "Thank you so much!"
    new "Danke schön!"

    # say L1028 bel
    old "You're welcome, I hope things will go well."
    new "Gern geschehen, ich hoffe, alles läuft gut."

    # say L1029 bel
    old "Let me know how this turns out."
    new "Lass es mich wissen, wie es ausgeht."

    # say L1031 pla
    old "I'll see you later then, thanks again."
    new "Dann sehen wir uns später, danke nochmal."

    # say L1043 pla
    old "Asking Belle about it turned out Better than expected."
    new "Belle danach zu fragen war besser als erwartet."

    # say L1044 pla
    old "Barbie will really like this news."
    new "Barbie wird sich echt freuen, das zu hören."

    # say L1045 pla
    old "Now is too late for me to go talk to her. But I'll go there soon and let her now."
    new "Jetzt ist es zu spät für mich, mit ihr zu reden. Aber ich werde bald hingehen und es ihr sagen."

    # say L1064 pla
    old "Hey Barbie, how are you doing?"
    new "Hey Barbie, wie geht's dir?"

    # say L1070 pla
    old "Well, let me tell you that that may be about to change. Because I got you an audition."
    new "Lass mich dir sagen, dass sich das bald ändern könnte. Denn ich habe dir eine Probebesetzung organisiert."

    # say L1073 pla
    old "Yeah, it's a role in an upcoming movie."
    new "Ja, es ist eine Rolle in einem kommenden Film."

    # say L1075 pla
    old "It’s being produced by an indie studio from outside of town."
    new "Es wird von einem unabhängigen Studio aus der Gegend produziert."

    # say L1076 pla
    old "They’re holding some castings here for it."
    new "Sie halten hier ein paar Castings für es ab."

    # say L1078 pla
    old "I already booked you a spot in their next auditions block."
    new "Ich hab dir schon einen Platz in ihrem nächsten Vorsprechen gebucht."

    # say L1079 pla
    old "So you'll have a chance of getting a role."
    new "Dann hast du die Chance, eine Rolle zu bekommen."

    # say L1081 pla
    old "You're welcome, I'm happy to help you. I'm sure you'll do a great job with the role."
    new "Gern geschehen, ich freue mich, dir zu helfen. Ich bin sicher, du wirst eine tolle Figur machen."

    # say L1084 pla
    old "You'll be auditioning for the role of a rich girl who's in love with a man that her family doesn't approve of."
    new "Du wirst für die Rolle eines reichen Mädchens vorsprechen, das sich in einen Mann verliebt hat, den ihre Familie nicht akzeptiert."

    # say L1088 pla
    old "It is, you'll be auditioning for the lead role!"
    new "Das ist es, du wirst dich für die Hauptrolle vorsprechen!"

    # say L1090 pla
    old "That's great, isn't it?"
    new "Das ist doch toll, oder?"

    # say L1093 pla
    old "Is... Is there a problem?"
    new "Ist... Ist da ein Problem?"

    # say L1096 pla
    old "Why not? Is there something wrong?"
    new "Warum nicht? Ist was faul?"

    # say L1101 pla
    old "Why do you think that?"
    new "Warum denkst du das?"

    # say L1111 bri
    old "I followed you in case you needed my help. Just because there's no certainty that you will know how to speak to her."
    new "Ich bin dir gefolgt, falls du meine Hilfe brauchst. Einfach so, weil ich nicht sicher bin, dass du weißt, wie mit ihr zu reden."

    # say L1112 bri
    old "So, do you want my help?"
    new "Also, willst du meine Hilfe?"

    # say L1113 pla
    old "{i}I think I can convince her on my own.{/i}"
    new "{i}Ich denke, ich kann sie selbst überzeugen.{/i}"

    # say L1115 pla
    old "I mean, I'm sure you're more than capable of taking the role, you know?"
    new "Ich meine, ich bin sicher, dass du die Rolle locker übernehmen kannst, weißt du?"

    # say L1116 pla
    old "I know you're very talented."
    new "Ich weiß, dass du sehr talentiert bist."

    # say L1117 pla
    old "And sure, there's going to be some competition."
    new "Und klar, da wird schon Konkurrenz sein."

    # say L1118 pla
    old "But you're just as good as any of them, you're more than capable of holding your own in the audion, no doubt."
    new "Aber du bist genauso gut wie jeder von ihnen, du kannst dich in der Audien sicher behaupten, da bin ich mir sicher."

    # say L1127 pla
    old "B- but you were so excited just a minute ago!"
    new "Aber du warst doch gerade noch so aufgeregt!"

    # say L1138 pla
    old "Listen, I understand that you're feeling insecure because of what's happened before."
    new "Hör zu, ich verstehe, dass du wegen dem, was vorher passiert ist, unsicher bist."

    # say L1139 pla
    old "But you'll never know if you don't try it."
    new "Aber du wirst es nie wissen, wenn du es nicht versuchst."

    # say L1150 bri
    old "So... You don't seem to be {i}'handling'{/i} things too well."
    new "Also... Du scheinst die Dinge nicht besonders gut zu {i}'handhaben'{/i}."

    # say L1151 bri
    old "Will you let me help you now?"
    new "Wirst du mich jetzt lassen, dir zu helfen?"

    # say L1152 bri
    old "I also need you to have sex with this human female, so this is also in my best interest."
    new "Ich brauche dich auch, um mit dieser menschlichen Frau zu schlafen, das liegt also auch in meinem Interesse."

    # say L1154 pla
    old "{i}Alright, alright! Get in her head and tell me what's really troubling her.{/i}"
    new "{i}Okay, okay! Mach dich an sie ran und sag mir, was sie wirklich bedrückt.{/i}"

    # say L1160 pla
    old "I understand that because of what's happened before you feel uncomfortable with the idea of auditioning."
    new "Ich verstehe, dass dir die Vorstellung, dich zu bewerben, wegen dem, was schon mal passiert ist, unangenehm ist."

    # say L1161 pla
    old "But you shouldn't let that stop you."
    new "Aber das solltest du nicht davon abhalten lassen."

    # say L1162 bri
    old "Hold on, I'm starting to get something."
    new "Warte, ich kriege da was."

    # say L1163 bri
    old "She feels like she's a failure."
    new "Sie fühlt sich, als wäre ihr Leben ein Versagen."

    # say L1166 bri
    old "No, no, she feels like her life's a failure."
    new "Nein, nein, sie fühlt sich, als wäre ihr Leben ein Versagen."

    # say L1168 pla
    old "{i}Her life is a failure?{/i}"
    new "{i}Ihr Leben ist ein Versagen?{/i}"

    # say L1170 pla
    old "I- I mean, I understand that you may feel like a failure."
    new "Ich- Ich meine, ich verstehe, dass du dich wie eine Versagerin fühlst."

    # say L1172 pla
    old "But the reason I'm helping you is because I believe in you and your talent."
    new "Aber der Grund, warum ich dir helfe, ist, weil ich an dich und dein Talent glaube."

    # say L1179 bri
    old "She's afraid of being rejected [pla]!"
    new "Sie hat Angst abgewiesen zu werden [pla]!"

    # say L1180 bri
    old "What strong emotions, wow!"
    new "Was für starke Gefühle, wow!"

    # say L1183 pla
    old "You know, I understand that you may feel a fear of being rejected."
    new "Du weißt, ich verstehe, dass du Angst vor Abweisung hast."

    # say L1185 pla
    old "But I do believe you're more than capable of getting the role."
    new "Aber ich glaube, dass du mehr als fähig bist, die Rolle zu bekommen."

    # say L1187 pla
    old "You have been trying for so long to finally get an acting career."
    new "Du hast schon so lange daran gearbeitet, endlich eine Schauspielerkarriere zu starten."

    # say L1189 pla
    old "And you haven't ever given up no matter what."
    new "Und du hast nie aufgegeben, egal was war."

    # say L1191 pla
    old "I just know that you have an amazing amount of passion for this."
    new "Ich weiß einfach, dass du eine unglaubliche Leidenschaft dafür hast."

    # say L1193 pla
    old "With how hard you've worked, I don't think anyone deserves the role any more than you do."
    new "Mit der ganzen Arbeit, die du reingesteckt hast, denke ich, dass niemand die Rolle mehr verdient als du."

    # say L1197 pla
    old "Of course I do, I truly believe in what you can do."
    new "Natürlich tue ich das, ich glaube wirklich daran, was du kannst."

    # say L1198 pla
    old "What do you say?"
    new "Was sagst du?"

    # say L1199 pla
    old "Will you give it a try?"
    new "Wirst du es versuchen?"

    # say L1210 pla
    old "Of course you should. I know, you'll crush it."
    new "Natürlich solltest du. Ich weiß, du wirst es rocken."

    # say L1215 pla
    old "You're welcome Barbie, I know you'll do great."
    new "Danke Barbie, ich weiß, du wirst großartig sein."

    # say L1216 pla
    old "Anyway, I have to go home for now."
    new "Na ja, ich muss jetzt erst mal nach Hause."

    # say L1217 pla
    old "But I'll send you the info about the address and date for the audition."
    new "Aber ich schick dir die Infos zur Adresse und zum Termin für das Vorsingen."

    # say L1221 pla
    old "I'll see you later then, bye."
    new "Dann sehen wir uns später, tschüss."

    # say L1238 pla
    old "Alright, that went well."
    new "Okay, das lief gut."

    # say L1239 pla
    old "Thanks for the help Brixxida."
    new "Danke für die Hilfe, Brixxida."

    # say L1241 bri
    old "Yeah yeah, but why aren't you having sex already with her?"
    new "Ja ja, aber warum hast du noch nicht mit ihr geschlafen?"

    # say L1244 bri
    old "I told you how she was feeling so that you could have sex with her right away!"
    new "Ich hab dir doch gesagt, wie es ihr geht, damit du gleich mit ihr schlafen kannst!"

    # say L1245 bri
    old "Two times talking and you still haven't achieved anything."
    new "Zwei Mal geredet und du hast immer noch nichts erreicht."

    # say L1246 bri
    old "What's taking you so long?"
    new "Was dauert da so lange?"

    # say L1247 pla
    old "I thought I told you."
    new "Ich dachte, ich hab's dir schon gesagt."

    # say L1248 pla
    old "Is not so simple to get somebody into bed."
    new "Ist nicht so einfach, jemanden ins Bett zu kriegen."

    # say L1250 pla
    old "You can't just say something nice to someone once or twice, and suddenly they'll want to fuck you out of nowhere."
    new "Du kannst nicht einfach ein paarmal was Nettes zu jemandem sagen und plötzlich wollen sie mit dir ficken."

    # say L1251 bri
    old "Ok, then how long will it take?"
    new "Ok, dann wie lange wird es dauern?"

    # say L1252 bri
    old "You're not the only one who's making an effort, you know?"
    new "Du bist nicht der Einzige, der sich Mühe gibt, weißt du?"

    # say L1254 bri
    old "I'm using a lot of magical power every time I read her mind, this isn't easy to do."
    new "Ich verwende jedes Mal viel magische Kraft, wenn ich ihre Gedanken lese, das ist nicht einfach."

    # say L1255 bri
    old "And unlike in my world, magical power isn't infinite here."
    new "Und im Gegensatz zu meiner Welt ist hier magische Energie nicht unendlich."

    # say L1256 pla
    old "I know, and I understand that this must be hard for you."
    new "Ich weiß und ich verstehe, dass das für dich schwer sein muss."

    # say L1258 pla
    old "But I can't just ask her to have sex with me just because. That's not how it works."
    new "Aber ich kann sie nicht einfach bitten, mit mir zu schlafen, nur so. So funktioniert das nicht."

    # say L1260 bri
    old "You humans are so complicated. When shinigamis have sex is just an energy exchange. Nothing else."
    new "Ihr Menschen seid so kompliziert. Wenn Shinigami Sex haben, ist das einfach ein Energieaustausch. Nichts weiter."

    # say L1261 pla
    old "Listen, I'm doing my best to do what we need. So just trust me on this and let me handle it. Ok?"
    new "Hör zu, ich tue mein Bestes, um zu tun, was wir brauchen. Vertrau mir einfach und lass mich das regeln. Okay?"

    # say L1263 bri
    old "Okay,  I'll trust that you know what you're doing."
    new "Okay, ich vertraue darauf, dass du weißt, was du tust."

    # say L1264 bri
    old "But don't take too long, I remind you that this is just the beginning of this process."
    new "Aber lass dir nicht zu viel Zeit, ich erinnere dich daran, dass das erst der Anfang dieses Prozesses ist."

    # say L1266 pla
    old "Don't worry, I haven't forgotten about that."
    new "Keine Sorge, ich hab das nicht vergessen."

    # say L1292 pla
    old "I'm ok, I came to check up on you."
    new "Alles gut, ich bin hier, um nach dir zu sehen."

    # say L1294 pla
    old "I wanted to know how the audition went."
    new "Ich wollte wissen, wie die Audition gelaufen ist."

    # say L1296 pla
    old "Did it go well? Did you feel alright?"
    new "Hat es gut geklappt? Hast du dich wohl gefühlt?"

    # say L1310 pla
    old "Alright, that sounds great. When's the next audition?"
    new "Okay, das klingt super. Wann ist die nächste Audition?"

    # say L1319 pla
    old "I see, and how long is it?"
    new "Ich sehe, und wie lange dauert es?"

    # say L1325 pla
    old "Ohh wow, t- that's a lot."
    new "Ohh wow, d-das ist viel."

    # say L1333 pla
    old "Oh, come on, why not?"
    new "Oh, komm schon, warum nicht?"

    # say L1340 pla
    old "{i}Could you please give me a hand...{/i}"
    new "{i}Kannst du mir bitte helfen...{/i}"

    # say L1346 bri
    old "Ok, I'm getting some strong emotional waves from her!"
    new "Ok, ich spüre starke emotionale Wellen von ihr!"

    # say L1347 bri
    old "She's feeling, very, very insecure."
    new "Sie fühlt sich sehr, sehr unsicher."

    # say L1348 bri
    old "I hadn't seen her like that before."
    new "Ich hatte sie noch nie so erlebt."

    # say L1350 bri
    old "She's closing her emotions! Just say something to reassure her."
    new "Sie schließt ihre Gefühle ab! Sag einfach was, um sie zu beruhigen."

    # say L1352 pla
    old "I- I understand what you're saying Barbie... I really do."
    new "Ich- Ich verstehe, was du meinst, Barbie... echt."

    # say L1354 pla
    old "But you know... Uhh, I don't think that this is as bad a situation as you think."
    new "Aber du weißt... Äh, ich glaube nicht, dass die Situation so schlimm ist, wie du denkst."

    # say L1359 bri
    old "Yeah, why not?"
    new "Ja, warum nicht?"

    # say L1360 pla
    old "Uhh... Well, that's certainly a lot of pages, but I don't think they are expecting you to memorize all of it."
    new "Uhh... Na ja, das sind sicher viele Seiten, aber ich glaube nicht, dass sie erwarten, dass du alles auswendig lernst."

    # say L1361 pla
    old "I think it's more about how you say and act with the lines."
    new "Ich denke, es geht mehr darum, wie du die Zeilen sagst und dich verhältst."

    # say L1363 pla
    old "Maybe all you have to do is read it ahead of time, and practice it."
    new "Vielleicht musst du es dir nur vorher durchlesen und üben."

    # say L1373 pla
    old "Ok, how about you do it with me?"
    new "Okay, wie wär's, wenn du es mit mir machst?"

    # say L1375 pla
    old "Sure, I mean, I don't know anything about acting, but I could still read the dialogues with you."
    new "Klar, ich meine, ich weiß ja nichts über Schauspielerei, aber ich könnte trotzdem die Dialoge mit dir lesen."

    # say L1376 pla
    old "And I could give you my opinion about how I think you are doing it."
    new "Und ich könnte dir sagen, was ich von deiner Darbietung halte."

    # say L1380 pla
    old "Well, we don't lose anything by trying, and this way, you could be more prepared for your role."
    new "Na, wir verlieren nichts dabei, wenn wir es versuchen, und so könntest du dich besser auf deine Rolle vorbereiten."

    # say L1393 pla
    old "How about you come to my house after you leave work."
    new "Wie wär's, wenn du nach der Arbeit zu mir kommst."

    # say L1395 pla
    old "And we can start practicing."
    new "Und wir können anfangen zu üben."

    # say L1401 pla
    old "So, what do you think if you let me take a look at the script they gave you while I wait for you to finish your shift?"
    new "Was meinst du, wenn du mir währenddessen das Drehbuch zeigst, das sie dir gegeben haben?"

    # say L1406 pla
    old "Okay, I'll go through them while you finish. I'll be in the hallway."
    new "Okay, ich schau sie mir an, während du fertig wirst. Ich warte im Flur."

    # say L1417 pla
    old "Great, let's go."
    new "Super, lass uns gehen."

    # say L1433 pla
    old "So, I checked out the script, and honestly, it's pretty interesting."
    new "Okay, ich hab mir das Skript angesehen, und ehrlich gesagt, ist es ziemlich interessant."

    # say L1435 pla
    old "Yeah, and I really do think you're not supposed to memorize this. It's rather about you reading it."
    new "Ja, und ich denke echt, du solltest das nicht auswendig lernen. Es geht eher darum, es zu lesen."

    # say L1436 pla
    old "Otherwise I don't think anybody could learn this entire thing by memory."
    new "Sonst denke ich, könnte niemand das ganze Ding auswendig lernen."

    # say L1437 pla
    old "Besides, if there are several participants the audition would just take too long."
    new "Außerdem würde die Vorlesung bei mehreren Teilnehmern einfach zu lange dauern."

    # say L1441 pla
    old "What I think is best is for us to focus on how you can portray the character."
    new "Was ich für das Beste halte, ist, dass du dich darauf konzentrierst, die Figur darzustellen."

    # say L1442 pla
    old "I mean, act as you read, so you can be better prepared tomorrow having practiced your role."
    new "Ich meine, du solltest die Rolle spielen, während du liest, damit du dich morgen besser vorbereitet hast."

    # say L1443 pla
    old "I know a scene with a lot of emotions."
    new "Ich kenne eine Szene mit vielen Emotionen."

    # say L1444 pla
    old "Here, take the full script, I got a few copies..."
    new "Hier, nimm das vollständige Drehbuch, ich hab ein paar Kopien gemacht..."

    # say L1448 pla
    old "Is in the second act, page 57."
    new "Ist im zweiten Akt, Seite 57."

    # say L1449 pla
    old "The two protagonists are fighting, but the scene ends in their reconciliation, I think it would be appropriate."
    new "Die beiden Hauptfiguren kämpfen, aber die Szene endet mit ihrer Versöhnung, ich denke, das wäre angemessen."

    # say L1452 pla
    old "Alright, let's start with the reading, and I'll give you pointers along the way."
    new "Okay, lass uns mit dem Lesen anfangen, und ich gebe dir Hinweise unterwegs."

    # say L1459 pla
    old "'Don't leave! Don't turn your back on me now!'"
    new "Bleib hier! Dreh mir jetzt nicht den Rücken zu!"

    # say L1461 pla
    old "'If you do, what little remains of this heart will disappear!'"
    new "Wenn du das tust, verschwindet der letzte Rest dieses Herzens!"

    # say L1487 pla
    old "I think you're doing it... Well."
    new "Ich glaube, du machst das... gut."

    # say L1489 pla
    old "But, the volume of what you're saying is a little high."
    new "Aber die Lautstärke von dem, was du sagst, ist ein bisschen hoch."

    # say L1491 pla
    old "Also, you're... Yelling some words, and saying others a little low."
    new "Also, du schreist manche Worte und flüsterst andere ein bisschen."

    # say L1494 pla
    old "Hmm, it's okay to add emotion to the lines, but try to keep the volume average, or it might sound a bit odd."
    new "Hmm, es ist okay, den Zeilen Emotion zu verleihen, aber versuch, die Lautstärke gleichmäßig zu halten, sonst klingt es vielleicht ein bisschen seltsam."

    # say L1497 pla
    old "Great, let's try it again."
    new "Okay, lass uns das noch mal versuchen."

    # say L1501 pla
    old "You know what? Maybe it isn't necessary to start over every time."
    new "Weißt du was? Vielleicht müssen wir nicht jedes Mal von vorne anfangen."

    # say L1502 pla
    old "How about you just keep reading where you left it?"
    new "Wie wär's, wenn du einfach da weiterliest, wo du aufgehört hast?"

    # say L1516 pla
    old "Oh, right, right."
    new "Oh, stimmt, stimmt."

    # say L1521 pla
    old "'Why? You ask?'"
    new "Warum? Fragst du?"

    # say L1522 pla
    old "'Because it isn't little!'"
    new "Weil es nicht klein ist!"

    # say L1523 pla
    old "'What I offer is my heart!'"
    new "Was ich dir biete, ist mein Herz!"

    # say L1524 pla
    old "'Naked, with no obstructions, just for you!'"
    new "Nackt, ohne Hindernisse, nur für dich!"

    # say L1548 pla
    old "I see..."
    new "Ich sehe..."

    # say L1550 pla
    old "But maybe that's not necessary, you know?"
    new "Aber vielleicht ist das nicht nötig, weißt du?"

    # say L1551 pla
    old "I think it can be a little distracting."
    new "Ich denke, das kann ein bisschen ablenkend sein."

    # say L1553 pla
    old "And people might not understand what you're trying to do."
    new "Und die Leute könnten nicht verstehen, was du vorhast."

    # say L1559 pla
    old "Hey, that's why we're practicing."
    new "Hey, deshalb üben wir ja."

    # say L1560 pla
    old "I don't think you need to feel bad about it."
    new "Ich denke, du musst dich deswegen nicht schlecht fühlen."

    # say L1561 pla
    old "Come on, don't let yourself feel down, let's continue."
    new "Komm schon, lass dich nicht runterziehen, lass uns weitermachen."

    # say L1566 pla
    old "'How can you say that I let you down?'"
    new "Wie kannst du sagen, dass ich dich enttäuscht habe?"

    # say L1567 pla
    old "'When I gave everything to you?!'"
    new "Wann habe ich dir alles gegeben?!"

    # say L1568 pla
    old "'I left myself change for your sake!'"
    new "Ich hab mich für dich verändert!"

    # say L1569 pla
    old "'For our sake!'"
    new "Für uns!"

    # say L1570 pla
    old "'All I've ever wanted in this relationship is to give you happiness!'"
    new "Alles, was ich in dieser Beziehung je wollte, war, dir Glück zu schenken!"

    # say L1584 pla
    old "'I didn't leave!'"
    new "Ich bin nicht gegangen!"

    # say L1585 pla
    old "'I couldn't be here for you!'"
    new "Ich konnte nicht für dich da sein!"

    # say L1586 pla
    old "'There's no way I wouldn't be here if I could avoid it!'"
    new "Da wäre ich doch nie weg, wenn ich könnte!"

    # say L1587 pla
    old "'You have to believe.'"
    new "Du musst mir glauben."

    # say L1588 pla
    old "'You're my life!'"
    new "Du bist mein Leben!"

    # say L1589 pla
    old "'You're my heart!'"
    new "Du bist mein Herz!"

    # say L1600 pla
    old "Uhh... So, there's something else I'd like to tell you."
    new "Uhh... Also, da ist noch was, das ich dir sagen möchte."

    # say L1606 pla
    old "Well, is just that..."
    new "Na ja, es ist einfach so, dass..."

    # say L1607 pla
    old "You keep changing your face while reading the lines."
    new "Du veränderst ständig dein Gesicht, während du die Zeilen liest."

    # say L1609 pla
    old "I- uh... No, I wouldn't say is wrong."
    new "Ich- äh... Nein, ich würde sagen, es ist nicht falsch."

    # say L1610 pla
    old "Is just that it's a little distracting from the dialogue, that's all."
    new "Es ist nur ein bisschen ablenkend vom Dialog, das ist alles."

    # say L1611 pla
    old "I wouldn't say is a bad thing though."
    new "Das muss aber nicht schlecht sein."

    # say L1619 pla
    old "W- what are you talking about?"
    new "W- wovon redest du?"

    # say L1620 pla
    old "W- why?"
    new "W- warum?"

    # say L1625 pla
    old "B- but that's just me tryting to help you!"
    new "B- aber das mache ich doch nur, um dir zu helfen!"

    # say L1626 pla
    old "But I don't think you're bad."
    new "Aber ich denke nicht, dass du schlecht bist."

    # say L1628 pla
    old "You just need a little practice."
    new "Du brauchst nur ein bisschen Übung."

    # say L1629 pla
    old "You know, to learn the character."
    new "Du weißt schon, um den Charakter zu lernen."

    # say L1637 pla
    old "W- what? Are you serious?"
    new "W-was? Im Ernst?"

    # say L1641 pla
    old "Come on, you can't just give up like this."
    new "Komm schon, du kannst nicht einfach so aufgeben."

    # say L1642 pla
    old "You have to try it."
    new "Du musst es versuchen."

    # say L1646 pla
    old "It isn't impossible, you don't have to know the script."
    new "Es ist nicht unmöglich, du musst das Skript nicht kennen."

    # say L1647 pla
    old "Or even read the whole thing."
    new "Oder es sogar komplett durchlesen."

    # say L1648 pla
    old "Let's just keep practicing this part."
    new "Lass uns einfach diesen Teil weiter üben."

    # say L1649 pla
    old "And I'm sure you'll be able to use what we practice here today for the audition tomorrow."
    new "Und ich bin sicher, dass du das, was wir heute üben, morgen bei der Vorsicht benutzen kannst."

    # say L1661 bri
    old "[pla], is just the same as earlier, her emotions are all over the place!"
    new "[pla], ist genauso wie vorhin, ihre Emotionen sind total durcheinander!"

    # say L1662 bri
    old "I'm not even reading her mind right now and I can tell."
    new "Ich muss sie mir erst anschauen."

    # say L1664 bri
    old "Let me see."
    new "Lass mich sehen."

    # say L1671 bri
    old "Hmm, I don't know."
    new "Hmm, ich weiß nicht."

    # say L1672 bri
    old "All I can tell is that she's incredibly stressed."
    new "Alles, was ich sagen kann, ist, dass sie unglaublich gestresst ist."

    # say L1673 bri
    old "It's amazing [pla], she's under so much tension!"
    new "Es ist unglaublich [pla], sie steht unter so viel Spannung!"

    # say L1674 bri
    old "With the way she's feeling now she won't listen to anything you have to say to her."
    new "Mit dem Stress, den sie hat, wird sie dir gar nicht zuhören."

    # say L1678 pla
    old "{i}What about you? Don't you have something that could be useful?{/i}"
    new "{i}Wovon redest du? Hast du nichts, das hilfreich sein könnte?{/i}"

    # say L1680 pla
    old "{i}Like a spell to calm her nerves or something?{/i}"
    new "{i}Eine Art Zauber, um ihre Nerven zu beruhigen oder so?{/i}"

    # say L1681 bri
    old "There's nothing like that."
    new "Da ist nichts so."

    # say L1683 bri
    old "Yeah, all I could do with a spell is try to influence her will, but there's nothing to change emotions into others."
    new "Klar, alles, was ich mit einem Zauber tun könnte, ist, ihren Willen zu beeinflussen, aber es gibt nichts, um Emotionen in andere zu verwandeln."

    # say L1685 pla
    old "{i}Because she's very certain that she's terrible.{/i}"
    new "{i}Weil sie ist sich sehr sicher, dass sie schrecklich ist.{/i}"

    # say L1687 bri
    old "Isn't there anything you could use to calm her feelings?"
    new "Ist da nichts, was du benutzen könntest, um ihre Gefühle zu beruhigen?"

    # say L1688 bri
    old "Don't you humans have a substance you ingest in these situations?"
    new "Haben eure Menschen nicht etwas, das ihr in solchen Situationen einnehmt?"

    # say L1689 bri
    old "I've seen your [mo1rel] use it before, she seems to calm down with it."
    new "Ich hab gesehen, wie deine [mo1rel] es benutzt, sie beruhigt sich damit."

    # say L1697 pla
    old "What? No, no, nothing like that."
    new "Was? Nein, nein, so was haben wir nicht."

    # say L1698 pla
    old "I'm sure you can do it."
    new "Ich bin sicher, dass du das kannst."

    # say L1699 pla
    old "Just wait here a second, I know of something that can help."
    new "Warte hier einen Moment, ich kenne da was, das helfen kann."

    # say L1710 pla
    old "Alright, I think this is just what we need."
    new "Okay, ich denke, das ist genau das, was wir brauchen."

    # say L1712 pla
    old "Well, no, not really."
    new "Na ja, eigentlich nicht wirklich."

    # say L1713 pla
    old "But I think that drinking a little might help."
    new "Aber ich denke, dass ein bisschen trinken helfen könnte."

    # say L1716 pla
    old "I can't remember exactly where I read it"
    new "Ich kann mich nicht genau daran erinnern, wo ich das gelesen habe"

    # say L1717 pla
    old "But it was about how some famous actors sometimes drink a little alcohol before shooting some of their scenes."
    new "Aber es ging darum, wie einige berühmte Schauspieler manchmal ein bisschen Alkohol trinken, bevor sie ihre Szenen drehen."

    # say L1718 pla
    old "This is supposed to help them feel relaxed, and be able to act more naturally."
    new "Das soll ihnen helfen, sich zu entspannen und natürlicher zu wirken."

    # say L1721 pla
    old "I understand that it seems a bit odd, but we could give it a try."
    new "Ich verstehe, dass es komisch klingt, aber wir könnten es mal ausprobieren."

    # say L1722 pla
    old "After all, you are feeling a little stressed. Maybe this could help you relax enough for you to recite the lines."
    new "Schließlich bist du ein bisschen gestresst. Vielleicht hilft dir das, dich so zu entspannen, dass du die Zeilen aufsagen kannst."

    # say L1726 pla
    old "Oh come on, you can be a little bit more positive than that. I'm sure this is going to help you."
    new "Oh komm schon, du kannst ein bisschen positiver sein. Ich bin sicher, dass das hilft."

    # say L1750 pla
    old "I'm glad you like it."
    new "Ich freue mich, dass es dir gefällt."

    # say L1751 pla
    old "Do you feel better now?"
    new "Fühlst du dich jetzt besser?"

    # say L1765 pla
    old "I see you're feeling better. Let's try it."
    new "Ich sehe, dass es dir besser geht. Lass uns es versuchen."

    # say L1771 pla
    old "I can prove it!'"
    new "Ich kann es beweisen!"

    # say L1772 pla
    old "'I can tell you!"
    new "Ich kann es dir sagen!"

    # say L1773 pla
    old "'I'm here now! And you didn't call me!'"
    new "Ich bin jetzt hier! Und du hast mich nicht angerufen!"

    # say L1774 pla
    old "'I came because you needed me!'"
    new "Ich bin gekommen, weil du mich gebraucht hast!"

    # say L1783 pla
    old "{i}(Now it's my line, I better not brake her concentration now that she's finally doing it well.){/i}"
    new "{i}(Jetzt bin ich dran, ich darf sie jetzt nicht ablenken, wo sie es endlich gut macht.){/i}"

    # say L1788 pla
    old "'Not staying was a mistake!'"
    new "Nicht geblieben war ein Fehler!"

    # say L1789 pla
    old "'I should've stayed by your side, I should've been here when you needed me!'"
    new "Ich hätte an deiner Seite bleiben sollen, ich hätte hier sein sollen, wenn du mich gebraucht hast!"

    # say L1790 pla
    old "'But that's why I'm here now!'"
    new "Aber deshalb bin ich jetzt hier!"

    # say L1791 pla
    old "'To be your companion!'"
    new "Um dir zur Seite zu stehen!"

    # say L1792 pla
    old "'Your rock! Your partner!'"
    new "Dein Fels! Dein Partner!"

    # say L1805 pla
    old "'I will be!'"
    new "Ich werde es sein!"

    # say L1806 pla
    old "'I promise you!'"
    new "Ich verspreche es dir!"

    # say L1814 pla
    old "You know what? It was, it really was."
    new "Du weißt was? Es war, es war wirklich so."

    # say L1815 pla
    old "I think the alcohol really helped you. Because that last part was great."
    new "Ich denke, der Alkohol hat dir wirklich geholfen. Denn der letzte Teil war großartig."

    # say L1816 pla
    old "But let's keep going until we finish this part of the dialogue."
    new "Aber lass uns weitermachen, bis wir diesen Teil des Dialogs beendet haben."

    # say L1822 pla
    old "'So! Do you believe me when I say it?'"
    new "Dann! Glaubst du mir, wenn ich das sage?"

    # say L1823 pla
    old "'That I want to be by you!'"
    new "Dass ich bei dir sein will!"

    # say L1824 pla
    old "'That I need to be by your side!'"
    new "Dass ich an deiner Seite sein muss!"

    # say L1825 pla
    old "'Nothing would make me happier!'"
    new "Nichts würde mich glücklicher machen!"

    # say L1840 pla
    old "'It means that we love each other!'"
    new "Das bedeutet, dass wir uns lieben!"

    # say L1849 pla
    old "{i}(Hmm, there's a kiss scene coming, and I didn't tell her where the scene would end.){/i}"
    new "{i}(Hmm, da kommt eine Kuss-Szene, und ich hab ihr nicht gesagt, wo die Szene endet.){/i}"

    # say L1860 pla
    old "'I can, and I will!'"
    new "Ich kann, und ich werde!"

    # say L1861 pla
    old "'If you say yes now I promise I'll always be there!'"
    new "Wenn du jetzt ja sagst, verspreche ich, dass ich immer für dich da sein werde!"

    # say L1862 pla
    old "'I will always be the rock that you need!'"
    new "Ich werde immer der Felsen sein, den du brauchst!"

    # say L1863 pla
    old "'No matter what!'"
    new "Egal was passiert!"

    # say L1884 pla
    old "{i}(That was unexpected, but I guess she's really into the role.){/i}"
    new "{i}(Das war unerwartet, aber ich schätze, sie nimmt ihre Rolle wirklich ernst.){/i}"

    # say L1897 pla
    old "'I'll gladly take it!'"
    new "Ich nehm's gerne!"

    # say L1898 pla
    old "'But in return, I'll let you have mine!'"
    new "Aber im Gegenzug darfst du meins haben!"

    # say L1899 pla
    old "'Because this is a partnership!'"
    new "Denn das ist eine Partnerschaft!"

    # say L1900 pla
    old "'We're meant to be together!'"
    new "Wir sind füreinander bestimmt!"

    # say L1901 pla
    old "'I know it!'"
    new "Ich weiß!"

    # say L1924 pla
    old "'Are you sure?'"
    new "Bist du dir sicher?"

    # say L1925 pla
    old "'Does this mean that you'll stay by my side?'"
    new "Das bedeutet, dass du an meiner Seite bleibst, oder?"

    # say L1960 pla
    old "Uhh... Y- yeah, it was, it really, really was."
    new "Uhh... J- ja, es war, es war wirklich, wirklich so."

    # say L1961 pla
    old "I- I mean, your acting was great."
    new "I- Ich meine, deine Schauspielerei war toll."

    # say L1962 pla
    old "I think you won't have any problems when the audition comes."
    new "Ich denke, du wirst bei der Vorsicht keine Probleme haben."

    # say L1966 pla
    old "Hmm... Sure."
    new "Hmm... Klar."

    # say L1980 pla
    old "But maybe we should change the scene because this one ends in a love scene between the leads."
    new "Aber vielleicht sollten wir die Szene ändern, weil diese hier in einer Liebesszene zwischen den Hauptfiguren endet."

    # say L1981 pla
    old "So, we could look for another one."
    new "Dann könnten wir uns nach einer anderen umsehen."

    # say L1987 pla
    old "U- Uhh, I- I don't know how- ."
    new "U- Uhh, ich- ich weiß nicht, wie-"

    # say L1998 pla
    old "Don't you think you're drinking a little too much of that?"
    new "Trinkst du nicht ein bisschen zu viel davon?"

    # say L2015 pla
    old "W- what are you doing Barbie?"
    new "W- was machst du da, Barbie?"

    # say L2035 pla
    old "Listen... About last night..."
    new "Hör mal... Was letzte Nacht angeht..."

    # say L2041 pla
    old "Uhh... Yeah, yeah, sure, don't worry about it..."
    new "Uhh... Ja, ja, klar, mach dir keine Sorgen..."

    # say L2052 pla
    old "Good luck with the audition, I know you'll do great."
    new "Viel Glück bei der Vorsicht, ich weiß, dass du großartig sein wirst."

    # say L2063 bri
    old "That was great [pla]!"
    new "Das war großartig [pla]!"

    # say L2065 bri
    old "You finally did it! Well done!"
    new "Du hast es endlich geschafft! Gut gemacht!"

    # say L2067 bri
    old "Of course you'll have to have more sex with her..."
    new "Natürlich musst du noch mehr mit ihr schlafen..."

    # say L2069 bri
    old "But now that you've done it once, you shouldn't have any problems doing it again..."
    new "Aber jetzt, wo du es einmal geschafft hast, solltest du kein Problem damit haben, es wieder zu tun..."

    # say L2070 bri
    old "Now we can focus on finding the next specimen."
    new "Jetzt können wir uns auf die Suche nach dem nächsten Exemplar konzentrieren."

    # say L2073 bri
    old "Well of couse."
    new "Natürlich."

    # say L2074 bri
    old "Now that you know you're going to have sex with this woman so easily."
    new "Jetzt, wo du weißt, dass du es mit dieser Frau so leicht haben wirst."

    # say L2075 bri
    old "You can stop wasting time on her and focus on finding the next person we need."
    new "Du kannst aufhören, Zeit an sie zu verschwenden und dich darauf konzentrieren, die nächste Person zu finden, die wir brauchen."

    # say L2076 pla
    old "Hey, hey, stop it right there!"
    new "Hey, hey, hör auf damit!"

    # say L2077 pla
    old "I don't know what it is you have in mind."
    new "Ich hab keine Ahnung, was du vorhast."

    # say L2079 pla
    old "But is not that easy..."
    new "Aber das ist nicht so einfach..."

    # say L2081 pla
    old "I promised I would help her with this, and I plan to fulfill that promise."
    new "Ich hab versprochen, ihr dabei zu helfen, und ich plane, dieses Versprechen einzulösen."

    # say L2083 pla
    old "So I'm sorry to disappoint you, but until she gets an acting job, I won't be looking for another 'specimen'..."
    new "Dann tut es mir leid, dich zu enttäuschen, aber bis sie eine Schauspielaufgabe hat, werde ich nach keinem anderen „Exemplar“ suchen..."

    # say L2085 pla
    old "Besides, I don't think there's going to be a next time having sex with her if I just leave her hanging."
    new "Außerdem, ich glaube nicht, dass es ein nächstes Mal mit ihr geben wird, wenn ich sie einfach hängen lasse."

    # say L2086 pla
    old "And you still need me to do it with her more times, isn't it?"
    new "Und du brauchst mich immer noch, um es mit ihr zu tun, oder?"

    # say L2088 bri
    old "Ughh! You humans are so complicated!"
    new "Ughh! Ihr Menschen seid so kompliziert!"

    # say L2090 bri
    old "Fine! Do as you wish!"
    new "Fein! Mach, was du willst!"

    # say L2092 bri
    old "But do it quickly! We don't have much time to lose!"
    new "Aber mach es schnell! Wir haben nicht viel Zeit zu verlieren!"

    # say L2093 pla
    old "Yeah, yeah, you've made that clear."
    new "Ja, ja, das hast du schon klar gemacht."

    # say L2117 pla
    old "Hey Barbie, how are you?"
    new "Hey Barbie, wie geht's dir?"

    # say L2121 pla
    old "W- what? Why?"
    new "W-was? Warum?"

    # say L2126 pla
    old "It did? You didn't feel comfortable?"
    new "Hat es? Du hast dich nicht wohl gefühlt?"

    # say L2131 pla
    old "I get it, I mean... I guess fear made you forget the dialogue..."
    new "Ich verstehe, ich meine... Angst hat dich wohl das Sprechen vergessen lassen."

    # say L2153 pla
    old "Who does he think he is? He has no right to treat you like that!"
    new "Wer glaubt er eigentlich, wer er ist? Er hat kein Recht, dich so zu behandeln!"

    # say L2154 pla
    old "I'm sorry Barbie, you didn't deserve him treating you like that."
    new "Entschuldige, Barbie, du hast es nicht verdient, so behandelt zu werden."

    # say L2160 pla
    old "No you're not, don't make what he told you a law."
    new "Nein, das bist du nicht, lass dir nicht einreden, was er gesagt hat."

    # say L2161 pla
    old "You're very talented Barbie, I saw it the other day while we were practicing."
    new "Du bist sehr talentiert, Barbie, das hab ich gesehen, als wir letztes Mal geübt haben."

    # say L2162 pla
    old "I'm sure it's going to be better in the next audition you go to."
    new "Ich bin sicher, es wird beim nächsten Vorsprechen besser."

    # say L2167 pla
    old "B- but that's your dream, to be part of show business."
    new "Aber das ist dein Traum, Teil der Unterhaltungsbranche zu werden."

    # say L2168 pla
    old "You know, to work in acting and stuff."
    new "Du weißt schon, im Schauspielen und so."

    # say L2180 pla
    old "Wait! Wait!"
    new "Warte! Warte!"

    # say L2181 pla
    old "Don't think so bad about yourself!"
    new "Du solltest nicht so schlecht von dir selbst denken!"

    # say L2182 pla
    old "You shouldn't believe that you're not good enough to act!"
    new "Du solltest nicht glauben, dass du nicht gut genug bist, um zu schauspielern!"

    # say L2183 pla
    old "I know you're more than capable of it."
    new "Ich weiß, dass du das kannst."

    # say L2191 pla
    old "Hey I have an idea!"
    new "Hey, ich hab eine Idee!"

    # say L2192 pla
    old "Listen, I know you're feeling bad."
    new "Hör zu, ich weiß, dass du dich schlecht fühlst."

    # say L2193 pla
    old "But I think there's a way so that you don't have to give up on your dream."
    new "Aber ich denke, es gibt einen Weg, dass du dein Traum nicht aufgeben musst."

    # say L2197 pla
    old "I get it, but listen, your dream is to be famous, right?"
    new "Ich verstehe, aber hör zu, dein Traum ist es doch berühmt zu werden, oder?"

    # say L2198 pla
    old "But there's more than one way of achieving it."
    new "Aber es gibt mehr als einen Weg, es zu erreichen."

    # say L2200 pla
    old "For example, have you thought about modeling?"
    new "Zum Beispiel, hast du schon mal dran gedacht, Model zu werden?"

    # say L2204 pla
    old "Sure!  Listen, maybe you're right about not being the best actor right now."
    new "Klar! Hör mal, vielleicht hast du recht, dass ich im Moment noch kein besonders guter Schauspieler bin."

    # say L2205 pla
    old "But that's not the only way to earn fame."
    new "Aber das ist nicht der einzige Weg, um berühmt zu werden."

    # say L2206 pla
    old "There are several different things that you can do."
    new "Es gibt mehrere verschiedene Dinge, die du machen kannst."

    # say L2208 pla
    old "And I think you could easily be an amazing model!"
    new "Und ich denke, du könntest leicht ein toller Model werden!"

    # say L2211 pla
    old "Of course I do!"
    new "Natürlich tu ich das!"

    # say L2212 pla
    old "There are several actors that got their start as models, and over time they moved into acting."
    new "Es gibt mehrere Schauspieler, die als Model angefangen haben und im Laufe der Zeit in die Schauspielerei gewechselt sind."

    # say L2213 pla
    old "With how beautiful you are. I don't see why you couldn't do the same thing."
    new "Mit deinem Aussehen. Ich sehe nicht, warum du das nicht auch schaffen könntest."

    # say L2217 pla
    old "You have to be kidding me."
    new "Du musst mich auf den Arm nehmen."

    # say L2218 pla
    old "I mean, look at yourself. You're beautiful."
    new "Ich meine, sieh dich an. Du bist wunderschön."

    # say L2219 pla
    old "And you have an amazing body!"
    new "Und du hast einen unglaublichen Körper!"

    # say L2220 pla
    old "Of course you can be a model!"
    new "Natürlich kannst du Model werden!"

    # say L2227 pla
    old "How can you say that?"
    new "Wie kannst du das sagen?"

    # say L2228 pla
    old "Maybe what you're saying about models was true several years ago."
    new "Vielleicht war das, was du über Models gesagt hast, vor ein paar Jahren noch wahr."

    # say L2230 pla
    old "But there are several different types now. And you are one of the most beautiful women that I've met."
    new "Aber es gibt jetzt verschiedene Typen. Und du bist eine der schönsten Frauen, die ich je getroffen habe."

    # say L2231 pla
    old "I'm sure you'll find work in any agency you want in no time."
    new "Ich bin sicher, du findest in jeder Agentur, bei der du dich bewirbst, schnell Arbeit."

    # say L2236 pla
    old "Of course I believe it. And I'm sure it's going to go great."
    new "Natürlich glaube ich das. Und ich bin sicher, es wird super laufen."

    # say L2240 pla
    old "R- right... Sure."
    new "Richtig... Klar."

    # say L2241 pla
    old "I'll get you something as a model."
    new "Ich besorge dir was als Modell."

    # say L2242 pla
    old "So, I'm going to have to make a couple of calls, but I'll let you know later about what I find."
    new "Dann mache ich ein paar Anrufe und lass dich später wissen, was ich gefunden habe."

    # say L2246 pla
    old "You're more than welcome."
    new "Du bist mehr als willkommen."

    # say L2247 pla
    old "I'm just happy to help."
    new "Ich bin einfach froh, helfen zu können."

    # say L2248 pla
    old "I'll go for now, and I'll see you later, alright?"
    new "Ich geh dann mal, und wir sehen uns später, okay?"

    # say L2260 pla
    old "Hmm, I guess it's good that Barbie's feeling better now."
    new "Hmm, ich schätze, es ist gut, dass Barbie sich jetzt besser fühlt."

    # say L2261 pla
    old "But now, how will I get her a modeling casting?"
    new "Aber jetzt, wie kriege ich sie denn zu einem Model-Casting?"

    # say L2262 pla
    old "I don't know anyone who works as a model or something similar..."
    new "Ich kenne niemanden, der als Model oder so arbeitet..."

    # say L2263 pla
    old "Hmph, I don't want to bother Belle again to get me an audition..."
    new "Hmpf, ich will Belle nicht noch mal um ein Vorsprechen bitten..."

    # say L2264 pla
    old "Who else could help me with this..."
    new "Wer könnte mir sonst noch helfen..."

    # say L2268 bri
    old "What are you doing?"
    new "Was machst du?"

    # say L2270 bri
    old "When you went looking for her, I thought you would come back together to have sex..."
    new "Als du losgegangen bist, um sie zu suchen, dachte ich, ihr würdet zusammen zurückkommen, um es zu tun..."

    # say L2271 pla
    old "Of course not, things don't work like that..."
    new "Natürlich nicht, so läuft das nicht..."

    # say L2273 pla
    old "Perhaps you should be helping me instead of complaining so much."
    new "Vielleicht solltest du mir helfen, anstatt so viel zu meckern."

    # say L2274 pla
    old "Maybe this way we can help Barbie more quickly..."
    new "Vielleicht auf diese Weise können wir Barbie schneller helfen..."

    # say L2275 pla
    old "And so we can wrap this up and start looking for the next 'specimen' as you want..."
    new "Und dann können wir das hier abschließen und mit der Suche nach dem nächsten 'Exemplar' beginnen, wie du willst..."

    # say L2276 bri
    old "Hmph, I guess you leave me no choice..."
    new "Hmpf, ich schätze, du lässt mir keine andere Wahl..."

    # say L2278 pla
    old "It's not easy, really, unless you magically know somebody that can get a casting with a modeling agency."
    new "Das ist nicht einfach, ehrlich gesagt, es sei denn, du kennst jemanden, der bei einem Modelagentur arbeitet."

    # say L2280 pla
    old "I need someone who works with models, you know, like these clothes and lingerie brands, or something like that..."
    new "Ich brauche jemanden, der mit Modellen arbeitet, du weißt schon, wie diese Mode- und Dessousmarken oder so was..."

    # say L2287 pla
    old "Wait! I got it! [sis]!"
    new "Warte! Ich hab's! [sis]!"

    # say L2288 pla
    old "Right now it's too late, but tomorrow I'll go talk with my [sisrel]."
    new "Im Moment ist es zu spät, aber morgen rede ich mit meinem [sisrel]."

    # say L2289 bri
    old "Oh no, why do I get the feeling this is going to take even longer?"
    new "Oh nein, warum habe ich das Gefühl, dass das noch länger dauern wird?"

    # say L2290 pla
    old "Relax, you help me to talk with [sis] tomorrow and we could get Barbie a model job, and that's it."
    new "Beruhige dich, du hilfst mir morgen, mit [sis] zu reden, und dann könnten wir Barbie eine Model-Job besorgen, und das wäre es."

    # say L2291 bri
    old "Hmm, if you say so..."
    new "Hmm, wenn du das sagst..."

    # say L2292 pla
    old "Anyway, I'm a bit tired, so, I'm going to sleep now..."
    new "Jedenfalls, ich bin ein bisschen müde, also, ich geh jetzt schlafen..."

    # say L2294 pla
    old "See you tomorrow Brixxida."
    new "Bis morgen Brixxida."

    # say L2295 bri
    old "See you..."
    new "Bis morgen..."

    # say L2318 sis
    old "What brings you here so early?"
    new "Was bringt dich so früh hierher?"

    # say L2319 pla
    old "Hey [sis]. Good morning."
    new "Hey [sis]. Guten Morgen."

    # say L2322 sis
    old "What's up?"
    new "Was ist los?"

    # say L2323 pla
    old "W- well... Uhmm."
    new "W-was... Ähm."

    # say L2325 pla
    old "T- the thing is that I kinda need a favor from you."
    new "T- die Sache ist, dass ich irgendwie eine Bitte an dich habe."

    # say L2328 pla
    old "But... I don't really know how to ask you..."
    new "Aber... ich weiß einfach nicht, wie ich dich fragen soll..."

    # say L2329 sis
    old "Well just do it."
    new "Na dann mach es doch."

    # say L2330 sis
    old "You know I'll help you with anything you want."
    new "Du weißt, dass ich dir bei allem helfe, was du willst."

    # say L2334 pla
    old "Do you know Barbie? The receptionist of the building where Jane's office is located?"
    new "Kennst du Barbie? Die Rezeptionistin im Gebäude, wo Janes Büro ist?"

    # say L2336 sis
    old "Yeah, sure I do. That silicon-filled bimbo."
    new "Klar, kennen wir doch. Diese silikonbefüllte Bimbo."

    # say L2337 sis
    old "What about her?"
    new "Was ist mit ihr?"

    # say L2338 pla
    old "Uh... W- well, the thing is that..."
    new "Äh... W- warte, die Sache ist die, dass..."

    # say L2339 pla
    old "S- she kind of needs help with something right now, and I promised I would give her that help."
    new "S- sie braucht gerade Hilfe bei etwas, und ich hab versprochen, ihr dabei zu helfen."

    # say L2340 sis
    old "Are you serious right now [pla]?!"
    new "Bist du jetzt ernsthaft [pla]?!"

    # say L2341 sis
    old "What kind of help? And what favor are you gonna ask me?"
    new "Was für eine Hilfe? Und was für einen Gefallen willst du von mir?"

    # say L2342 pla
    old "Well, a few days ago I came into the building to bring some documents from [mo1] and...."
    new "Na ja, vor ein paar Tagen bin ich ins Gebäude gekommen, um ein paar Dokumente von [mo1] zu bringen und..."

    # say L2343 pla
    old "We got to talking and she told me that lately she's been feeling very sad about not being able to..."
    new "Wir haben uns unterhalten und sie hat mir erzählt, dass sie in letzter Zeit sehr traurig ist, weil sie es nicht schafft..."

    # say L2349 pla
    old "Well, she wants to be a model, so I said that I would help her with that."
    new "Na ja, sie will Model werden, also hab ich gesagt, dass ich ihr dabei helfen würde."

    # say L2350 pla
    old "But the truth is that I have no contacts in the modeling industry."
    new "Aber die Wahrheit ist, dass ich keine Kontakte in der Modelbranche habe."

    # say L2351 pla
    old "So, I was wondering if you would consider having her model for your online business."
    new "Dann dachte ich, du könntest vielleicht darüber nachdenken, sie für dein Online-Geschäft zu engagieren."

    # say L2353 sis
    old "No I would not accept it!"
    new "Nein, das würde ich nicht akzeptieren!"

    # say L2356 sis
    old "Why would I want that vulgar, plastic bimbo modeling in my clothes?!"
    new "Warum sollte ich diese vulgäre, plastische Bimbo in meiner Kleidung modellieren lassen?!"

    # say L2357 sis
    old "It would ruin the reputation of my brand!"
    new "Das würde den Ruf meiner Marke ruinieren!"

    # say L2360 sis
    old "Which by the way, I'm surprised you're so interested in her as to come here and ask me if I would let her model my clothes!"
    new "Übrigens, ich wundere mich, dass du dich so für sie interessierst, dass du hierher kommst und mich fragst, ob ich ihr erlauben würde, meine Kleider zu modellieren!"

    # say L2361 sis
    old "You know [pla], I thought you had better taste than that."
    new "Du weißt [pla], ich dachte, du hättest besseren Geschmack."

    # say L2362 sis
    old "I mean..."
    new "Ich meine..."

    # say L2364 sis
    old "All of this just because you want to bang that stupid girl?"
    new "Das alles nur, weil du diese blöde Kuh flachlegen willst?"

    # say L2367 pla
    old "What? Come on, is not like that."
    new "Was? Komm schon, es ist nicht so."

    # say L2368 sis
    old "Oh yeah? Then how is it?"
    new "Oh ja? Dann wie ist es?"

    # say L2371 sis
    old "Because it seems to me that you're more interested in fucking her than anything else."
    new "Weil es mir so vorkommt, als würdest du mehr daran interessiert sein, sie zu ficken, als an allem anderen."

    # say L2372 sis
    old "You men are so predictable, you see some stupid girl with tits and ass like balloons and you go crazy."
    new "Ihr Männer seid so vorhersehbar, seht eine blöde Tussi mit Titten und Arsch wie Luftballons und geht durch die Decke."

    # say L2373 pla
    old "I already told you, is not like that..."
    new "Ich hab dir doch schon gesagt, das ist nicht so..."

    # say L2374 bri
    old "Boy, you seem to have a talent for altering people's feelings."
    new "Du scheinst ein Talent dafür zu haben, die Gefühle von anderen zu verändern."

    # say L2376 bri
    old "Every time I'm with you, you're making some woman angry or cry or just lose her temper."
    new "Jedes Mal, wenn ich bei dir bin, machst du irgendeine Frau wütend oder zum Weinen oder sie verliert einfach die Nerven."

    # say L2378 pla
    old "Why don't you help me then?"
    new "Warum hilfst du mir dann nicht?"

    # say L2380 sis
    old "What? Do you need even more explanations?"
    new "Was? Brauchst du noch mehr Erklärungen?"

    # say L2381 pla
    old "Uhh? No, no, I- I-... Nevermind..."
    new "Uhh? Nein, nein, ich- ich... Vergiss es..."

    # say L2384 bri
    old "Hahaha, look at you! Grasping for words."
    new "Ha ha ha, schau dir mal zu! Du suchst nach Worten."

    # say L2385 bri
    old "I'll help you then."
    new "Dann helfe ich dir."

    # say L2393 bri
    old "Listen [pla]."
    new "Hör zu [pla]."

    # say L2395 bri
    old "She's experiencing a very negative emotion. And it's all directed at you."
    new "Sie erlebt gerade eine sehr negative Emotion. Und die richtet sich allesamt gegen dich."

    # say L2397 sis
    old "Anyway, you can leave, I'm busy."
    new "Na los, verschwinde, ich hab zu tun."

    # say L2399 bri
    old "No wait! It's not directed at you!"
    new "Warte! Das ist nicht gegen dich!"

    # say L2402 bri
    old "Is about that girl!"
    new "Es geht um dieses Mädchen!"

    # say L2403 bri
    old "She's..."
    new "Sie ist..."

    # say L2405 bri
    old "Jelaous!"
    new "Eifersüchtig!"

    # say L2407 bri
    old "That's it, she's feeling jealous."
    new "Das ist es, sie fühlt sich eifersüchtig."

    # say L2408 sis
    old "No, [pla], I'm not gonna help you to bang that bimbo..."
    new "Nein, [pla], ich werd dir nicht helfen, diese Schlampe zu flachsen..."

    # say L2409 bri
    old "Uhh, you better do something about that or she really won't help you at all."
    new "Uhh, du solltest da was unternehmen, sonst hilft sie dir wirklich nicht mehr."

    # say L2411 pla
    old "I mean, I think I didn't express explain properly."
    new "Ich meine, ich glaube, ich hab mich nicht richtig ausgedrückt."

    # say L2413 pla
    old "Listen, the reason why I want to help Barbie is not that I want to sleep with her or something like that."
    new "Hör zu, der Grund, warum ich Barbie helfen will, ist nicht, dass ich mit ihr schlafen will oder so."

    # say L2414 pla
    old "The truth is that I've been thinking that I would like to be a photographer."
    new "Die Wahrheit ist, ich hab drüber nachgedacht, dass ich Fotograf werden will."

    # say L2417 sis
    old "A photographer?"
    new "Eine Fotografin?"

    # say L2419 pla
    old "Yeah, you know I'm good with the camera."
    new "Ja, du weißt ja, dass ich gut mit der Kamera umgehen kann."

    # say L2420 pla
    old "And that I know how to edit and present pictures."
    new "Und dass ich weiß, wie man Fotos bearbeitet und präsentiert."

    # say L2421 pla
    old "So it came to my mind that I could do some work in that field. You know for magazines and stuff."
    new "Dann kam mir der Gedanke, dass ich in dem Bereich arbeiten könnte. Du weißt schon, für Magazine und so."

    # say L2422 pla
    old "But getting a job as a photographer is too difficult."
    new "Aber einen Job als Fotograf zu kriegen ist zu schwierig."

    # say L2423 pla
    old "But then I talked with Barbie, and it came to my mind that maybe that was it."
    new "Aber dann habe ich mit Barbie geredet und mir gedacht, dass das vielleicht der richtige Weg ist."

    # say L2424 pla
    old "That if I helped her it could be good for the both of us, and that I could get a job as a photographer like that."
    new "Dass wenn ich ihr helfe, es für uns beide gut sein könnte und ich so einen Job als Fotograf bekommen könnte."

    # say L2426 sis
    old "Hmm, are you serius?"
    new "Hmm, bist du ernst?"

    # say L2427 pla
    old "Yeah, that's really all I'm looking for. I don't know where you got the idea about sex..."
    new "Klar, das ist alles, was ich will. Keine Ahnung, wo du die Idee mit dem Sex her hast..."

    # say L2429 sis
    old "Well, that's not such a bad idea [pla]."
    new "Na, das ist ja gar keine schlechte Idee [pla]."

    # say L2431 sis
    old "It's actually some good thinking on your part."
    new "Das ist eigentlich ganz gute Überlegung von dir."

    # say L2432 sis
    old "But why didn't you start with that?"
    new "Aber warum hast du damit nicht angefangen?"

    # say L2433 pla
    old "W- well you know."
    new "W- wieso, du weißt schon."

    # say L2434 pla
    old "I- I didn't think that was that important."
    new "Ich dachte, das wäre nicht so wichtig."

    # say L2436 sis
    old "You didn't think that was important?"
    new "Du hast nicht gedacht, dass das wichtig ist?"

    # say L2437 sis
    old "But you thought it was more important to just tell me you want to help that plastic bimbo?"
    new "Aber du hast gedacht, es wäre wichtiger, mir einfach zu sagen, dass du dieser plastischen Bimbo helfen willst?"

    # say L2438 sis
    old "Very smart."
    new "Sehr schlau."

    # say L2440 sis
    old "But anyway, I think I see your point."
    new "Aber egal, ich glaube, ich verstehe deinen Standpunkt."

    # say L2441 sis
    old "And you are good with the camera."
    new "Und du bist gut mit der Kamera."

    # say L2442 sis
    old "You could be a good photographer."
    new "Du könntest ein guter Fotograf werden."

    # say L2443 sis
    old "Now, let me see your portfolio of her pictures."
    new "Dann zeig mir mal dein Portfolio von ihren Fotos."

    # say L2446 sis
    old "Well of course."
    new "Na klar."

    # say L2447 sis
    old "I mean, you do have a portfolio of pictures right?"
    new "Ich meine, du hast doch ein Bilderverzeichnis, oder?"

    # say L2448 pla
    old "I- I don't..."
    new "Ich... ich hab' keine..."

    # say L2449 sis
    old "Ugh, be serious [pla]."
    new "Ugh, sei doch ernst [pla]."

    # say L2450 sis
    old "You say you want to be a photographer, but you don't know anything."
    new "Du sagst, du willst Fotograf werden, aber du weißt gar nichts."

    # say L2451 sis
    old "If you want someone to give you a job in photography you need to have pictures to show."
    new "Wenn du willst, dass jemand dir einen Job in der Fotografie gibt, musst du Fotos vorweisen können."

    # say L2452 sis
    old "Especially with something like pictures of that little plastic dumb."
    new "Vor allem bei so was wie Fotos von diesem kleinen Plastikdummkopf."

    # say L2453 sis
    old "How else is someone going to hire her?"
    new "Wie soll sie sonst jemand einstellen?"

    # say L2454 pla
    old "I understand, so you need me to take pictures of her?"
    new "Ich verstehe, dann brauchst du, dass ich Fotos von ihr mache?"

    # say L2455 pla
    old "I think I can do that, and bring some of those for you."
    new "Ich denke, ich kann das machen und dir ein paar davon mitbringen."

    # say L2457 sis
    old "Good. Be sure they're good so that I can show them to the people that might hire her."
    new "Gut. Stell sicher, dass sie gut sind, damit ich sie den Leuten zeigen kann, die sie eventuell einstellen."

    # say L2459 sis
    old "By the way, I hope you understand I'm not doing this out of the goodness of my heart, right?"
    new "Übrigens, ich hoffe, du verstehst, dass ich das nicht aus reiner Herzensgüte mache, oder?"

    # say L2461 sis
    old "If she's going to get money for it, and I got her the job, I want my cut."
    new "Wenn sie dafür Geld kriegt und ich ihr den Job besorgt habe, will ich meinen Anteil."

    # say L2462 pla
    old "Uhh, yeah yeah, sure..."
    new "Uhh, ja ja, klar..."

    # say L2463 pla
    old "If you get her a job, then sure, I can give you a commission."
    new "Wenn du ihr einen Job besorgst, dann klar, ich geb dir eine Provision."

    # say L2465 sis
    old "I want a 10 percent! Is that clear?"
    new "Ich will zehn Prozent! Ist das klar?"

    # say L2466 pla
    old "Sure, whatever."
    new "Klar, wie du willst."

    # say L2467 pla
    old "Hey, thanks a lot [sis]."
    new "Hey, danke schön [sis]."

    # say L2469 sis
    old "Yeah well, I'm not doing it for her."
    new "Na ja, ich mache das nicht für sie."

    # say L2470 sis
    old "I'm helping you."
    new "Ich helfe dir."

    # say L2471 pla
    old "Sure, but thanks anyway."
    new "Klar, aber danke trotzdem."

    # say L2472 sis
    old "You're welcome."
    new "Gern geschehen."

    # say L2473 pla
    old "I'll talk to Barbie later and let her know about this."
    new "Ich rede später mit Barbie und sage ihr Bescheid."

    # say L2475 sis
    old "Listen, I have to leave for now, so I'll send you the info when I get it."
    new "Hör zu, ich muss jetzt los, also schick ich dir die Infos, sobald ich sie habe."

    # say L2500 pla
    old "I'm doing well, thank you."
    new "Mir geht's gut, danke."

    # say L2501 pla
    old "Hey listen, I have great news!"
    new "Hey, hör mal, ich hab tolle Neuigkeiten!"

    # say L2503 pla
    old "You could say that."
    new "Kann man so sagen."

    # say L2504 pla
    old "Do you remember what we had talked about modeling?"
    new "Erinnerst du dich noch an unser Gespräch über das Modeln?"

    # say L2506 pla
    old "Well, after we talked I got in contact with someone I know that has some connections to the modeling business."
    new "Na ja, nachdem wir geredet haben, habe ich jemanden kontaktiert, den ich kenne und der Verbindungen zur Modelbranche hat."

    # say L2507 pla
    old "And she told me that she could get you an interview!"
    new "Und sie hat mir gesagt, dass sie dir ein Vorstellungsgespräch besorgen kann!"

    # say L2510 pla
    old "Yeah, but you see..."
    new "Ja, aber du siehst..."

    # say L2512 pla
    old "She told me that I had to take some pictures of you, to show to the agency."
    new "Sie hat mir gesagt, dass ich ein paar Fotos von dir machen muss, um sie der Agentur zu zeigen."

    # say L2513 pla
    old "Like a portfolio or something."
    new "Wie ein Portfolio oder so."

    # say L2515 pla
    old "You know, to see how you look."
    new "Du weißt schon, um zu sehen, wie du aussiehst."

    # say L2519 pla
    old "Actually, I can take them myself."
    new "Klar, ich kann die Fotos selbst machen."

    # say L2523 pla
    old "Yeah sure, it wouldn't be a problem."
    new "Klar, das wäre kein Problem."

    # say L2524 pla
    old "I have some experience as a photographer."
    new "Ich habe schon etwas Erfahrung als Fotograf."

    # say L2527 pla
    old "Heh, well thank you."
    new "Heh, danke schön."

    # say L2528 pla
    old "But you see, we have to take the pictures soon."
    new "Aber du siehst, wir müssen die Fotos bald machen."

    # say L2529 pla
    old "She wants to send them as soon as possible."
    new "Sie will sie so schnell wie möglich verschicken."

    # say L2530 pla
    old "So, how about we go to my house after you finish work and take the photos?"
    new "Dann, wie wäre es, wenn wir nach der Arbeit zu mir gehen und die Fotos machen?"

    # say L2534 pla
    old "Come on, you don't have to worry about it."
    new "Komm schon, du musst dich echt nicht darum sorgen."

    # say L2535 pla
    old "What you're wearing is perfect, you don't need to worry about it."
    new "Was du anhast, ist perfekt, du musst dir keine Sorgen machen."

    # say L2539 pla
    old "Of course, you look perfect the way you are."
    new "Natürlich, du siehst perfekt aus, wie du bist."

    # say L2544 pla
    old "Great, so I'll wait until your shift is over, and after we can go to my house."
    new "Okay, ich warte bis deine Schicht zu Ende ist, und danach können wir zu mir gehen."

    # say L2554 pla
    old "Okay, lets go."
    new "Okay, lass uns gehen."

    # say L2567 pla
    old "Alright, we can get started then-"
    new "Okay, dann können wir loslegen-"

    # say L2570 pla
    old "Don't worry about it."
    new "Mach dir keine Sorgen."

    # say L2571 pla
    old "I can show you."
    new "Ich kann dir zeigen."

    # say L2573 pla
    old "Well, I've helped my [sisRel] before with her work."
    new "Na ja, ich habe meiner [sisRel] schon mal bei ihrer Arbeit geholfen."

    # say L2574 pla
    old "She has an online clothing business."
    new "Sie hat ein Online-Bekleidungsgeschäft."

    # say L2575 pla
    old "And sometimes I'm the one that takes the pictures of her new clothes."
    new "Und manchmal bin ich derjenige, der Fotos von ihren neuen Klamotten macht."

    # say L2578 pla
    old "Heh, thank you."
    new "Heh, danke."

    # say L2579 pla
    old "Anyway, I guess we can get started then."
    new "Na ja, dann können wir ja loslegen."

    # say L2581 pla
    old "Just relax, I'll tell you how you should pose."
    new "Entspann dich, ich sag dir, wie du posieren sollst."

    # say L2582 pla
    old "So, for the first picture..."
    new "Dann, für das erste Bild..."

    # say L2583 pla
    old "How about you sit down in the bed with your legs open, looking this way."
    new "Setz dich aufs Bett und spreiz die Beine, schau in diese Richtung."

    # say L2584 pla
    old "Put your left arm up behind your head, and bring the right one to your neck."
    new "Leg deinen linken Arm hinter deinem Kopf und bring den rechten zu deinem Hals."

    # say L2585 pla
    old "Over your right breast."
    new "Über deine rechte Brust."

    # say L2586 pla
    old "And look straight at the camera, Ok?"
    new "Und guck direkt in die Kamera, okay?"

    # say L2598 pla
    old "Alright perfect! "
    new "Alles klar perfekt!"

    # say L2599 pla
    old "That way you're more than perfect!"
    new "So bist du mehr als perfekt!"

    # say L2600 pla
    old "Just stay put and I'll take the first picture."
    new "Bleib so stehen und ich mache das erste Foto."

    # say L2621 pla
    old "That was perfect Barbie!"
    new "Das war perfekt, Barbie!"

    # say L2622 pla
    old "Now, for the second pose."
    new "Jetzt zur zweiten Pose."

    # say L2624 pla
    old "Hmm, let's see..."
    new "Hmm, lass mal sehen..."

    # say L2625 pla
    old "I think we should show you from all angles."
    new "Ich denke, wir sollten dich von allen Seiten zeigen."

    # say L2626 pla
    old "So, how about you take more of a kneeling position in the bed."
    new "Dann knie dich mal im Bett hin."

    # say L2627 pla
    old "With your legs towards me."
    new "Mit deinen Beinen zu mir."

    # say L2628 pla
    old "And put your weight on your left arm."
    new "Und stütz dich auf deinen linken Arm ab."

    # say L2642 pla
    old "Yes! That's perfect!"
    new "Ja! Das ist perfekt!"

    # say L2643 pla
    old "Great Barbie!"
    new "Großartig, Barbie!"

    # say L2645 pla
    old "Just stay like that, and I'll take the picture."
    new "Bleib so, ich mach das Foto."

    # say L2666 pla
    old "Alright, that's great!"
    new "Okay, das ist super!"

    # say L2667 pla
    old "Now, I think we can take another picture."
    new "Jetzt denke ich, wir können ein weiteres Bild machen."

    # say L2669 pla
    old "Sure, for the third one let's make it a close-up."
    new "Klar, für das dritte Bild machen wir ein Nahaufnahme."

    # say L2670 pla
    old "So, turn to face the camera."
    new "Dann dreh dich zur Kamera."

    # say L2671 pla
    old "And bring your breasts forward with your hands while you smile."
    new "Und drück deine Brüste mit den Händen nach vorne, während du lächelst."

    # say L2672 pla
    old "Ok, I know what you mean."
    new "Ok, ich verstehe, was du meinst."

    # say L2685 pla
    old "That's right! Perfect!"
    new "Das ist es! Perfekt!"

    # say L2686 pla
    old "You're very good at this Barbie!"
    new "Du bist echt gut darin, Barbie!"

    # say L2688 pla
    old "No matter how good I am, it wouldn't be possible without such a beautiful model."
    new "Egal wie gut ich bin, wäre das ohne so ein schönes Modell nicht möglich gewesen."

    # say L2709 pla
    old "Alright, that's it, I think that we have enough pictures with those ones."
    new "Okay, das reicht jetzt, ich denke, wir haben genug Bilder von denen."

    # say L2711 pla
    old "Yeah, I think those are more than enough."
    new "Ja, ich denke, das reicht mehr als aus."

    # say L2716 pla
    old "Ok, I think these came out great!"
    new "Ok, ich denke, die sind super geworden!"

    # say L2720 pla
    old "Here, look."
    new "Hier, schau mal."

    # say L2729 pla
    old "I'm sure they will."
    new "Ich bin mir sicher, dass sie toll werden."

    # say L2730 pla
    old "Besides, I still have to do a couple of edits on them."
    new "Außerdem muss ich noch ein paar Änderungen dran machen."

    # say L2731 pla
    old "When I'm done they're going to look even better."
    new "Wenn ich fertig bin, sehen sie noch besser aus."

    # say L2735 pla
    old "What? There's no way this is just because of me taking the pictures!"
    new "Was? Das kann doch nicht nur daran liegen, dass ich die Fotos gemacht habe!"

    # say L2736 pla
    old "These pictures are because of how beautiful you are."
    new "Diese Bilder sind, weil du so schön bist."

    # say L2737 pla
    old "After all the only thing I'm doing is just taking the pictures."
    new "Im Grunde mache ich doch nur die Fotos."

    # say L2738 pla
    old "You're the one that's posing."
    new "Du bist diejenige, die posiert."

    # say L2739 pla
    old "And if they come up any good, is just because of how well you posed."
    new "Und wenn sie gut werden, dann nur, weil du so gut posiert hast."

    # say L2755 pla
    old "Woah, woah, w- what are you doing Barbie?"
    new "Woah, woah, w-was machst du da, Barbie?"

    # say L2758 pla
    old "B- but..."
    new "Aber..."

    # say L2771 pla
    old "Alright, so I'll send the pictures to my contact today. And she'll let me know if she can get the interview for you."
    new "Okay, dann schick ich die Fotos heute an meinen Kontakt. Und sie wird mir Bescheid sagen, ob sie das Interview für dich organisieren kann."

    # say L2773 pla
    old "It will probably not be something big, at least not to start with."
    new "Es wird wahrscheinlich nichts Großes sein, zumindest am Anfang nicht."

    # say L2774 pla
    old "But I think that it might be a good starting point for you."
    new "Aber ich denke, es könnte ein guter Anfang für dich sein."

    # say L2786 pla
    old "Yeah, I have to get to it now."
    new "Ja, ich muss mich jetzt dranmachen."

    # say L2787 pla
    old "But as soon as the pictures are done I'll hand them over to my contact."
    new "Aber sobald die Fotos fertig sind, gebe ich sie an meinen Kontakt weiter."

    # say L2788 pla
    old "And when I get an answer I'll let you know."
    new "Und sobald ich eine Antwort kriege, lass ich es dich wissen."

    # say L2852 pla
    old "Hey [sis], good morning, how are you?"
    new "Hey [sis], guten Morgen, wie geht’s dir?"

    # say L2854 sis
    old "I'm doing great, and you?"
    new "Mir geht's super, und dir?"

    # say L2855 pla
    old "I'm ok, thank you."
    new "Ich bin okay, danke."

    # say L2857 pla
    old "Hey, listen, about the favor that I asked you last time."
    new "Hey, hör mal, wegen dem Gefallen, den ich dich letztes Mal gebeten habe."

    # say L2858 sis
    old "Oh yeah, your little plastic girl's pictures."
    new "Oh ja, die Bilder von deiner kleinen Plastikpuppe."

    # say L2859 sis
    old "I send them over to a friend of mine that works for another clothing business."
    new "Ich schicke sie an einen Freund von mir, der für ein anderes Bekleidungsunternehmen arbeitet."

    # say L2860 sis
    old "Their clothes are more like the type of thing that that idiot would wear."
    new "Ihre Klamotten sind eher der Typ, den dieser Idiot tragen würde."

    # say L2861 pla
    old "And what did they say?"
    new "Und was haben sie gesagt?"

    # say L2868 pla
    old "When do they want to meet her?"
    new "Wann wollen sie sie treffen?"

    # say L2869 sis
    old "In a couple of days."
    new "In ein paar Tagen."

    # say L2870 sis
    old "I'll send you the info."
    new "Ich schick dir die Infos."

    # say L2871 sis
    old "And don't worry, I talked with them."
    new "Und mach dir keine Sorgen, ich hab schon mit ihnen gesprochen."

    # say L2872 sis
    old "They said that if they hire her they'll be sure to give us our cut."
    new "Sie haben gesagt, wenn sie sie einstellen, kriegen wir auf jeden Fall unseren Anteil."

    # say L2873 pla
    old "I see... That's great."
    new "Ich sehe... Das ist toll."

    # say L2874 pla
    old "Alright, I'll have to tell her about this."
    new "Okay, ich muss ihr das sagen."

    # say L2875 pla
    old "Thanks a lot [sis]."
    new "Danke schön [sis]."

    # say L2878 sis
    old "Remember to tell your little friend that she has to be there on time."
    new "Denk dran, deiner kleinen Freundin zu sagen, dass sie pünktlich sein muss."

    # say L2880 sis
    old "I don't want her to make me look bad by getting there late or anything."
    new "Ich will nicht, dass sie mich durch ihre Verspätung blamieren."

    # say L2881 sis
    old "Is that clear?"
    new "Ist das klar?"

    # say L2882 pla
    old "Yeah, yeah, it is."
    new "Klar, klar, ist es."

    # say L2883 sis
    old "Good."
    new "Gut."

    # say L2884 pla
    old "Yeah.. I'll see you later then."
    new "Okay.. dann sehen wir uns später."

    # say L2885 pla
    old "Bye [sis], thanks for the help."
    new "Tschüss [sis], danke für die Hilfe."

    # say L2909 pla
    old "I'm good, and listen I have some great news!"
    new "Ich bin gut, und hör zu, ich hab tolle Neuigkeiten!"

    # say L2911 pla
    old "That contact I told you about got an interview for you!"
    new "Die Kontaktperson, von der ich dir erzählt habe, hat für dich ein Vorstellungsgespräch organisiert!"

    # say L2914 pla
    old "Yeah, it's to apply for a position as a model for a clothing brand that works mainly online."
    new "Ja, es ist eine Stelle als Model für eine Kleidermarke, die hauptsächlich online tätig ist."

    # say L2915 pla
    old "It's not the biggest job in the world but..."
    new "Das ist zwar nicht die größte Aufgabe der Welt, aber..."

    # say L2919 pla
    old "It's my pleasure."
    new "Es ist mir ein Vergnügen."

    # say L2920 pla
    old "I'm happy to be able to help you."
    new "Ich freue mich, dir helfen zu können."

    # say L2921 pla
    old "I'll send you the details, don't forget to go, alright?'"
    new "Ich schick dir die Details, vergiss nicht hinzugehen, okay?"

    # say L2923 pla
    old "Hey, don't thank me yet. Let's wait until you get the job."
    new "Hey, danke mir noch nicht. Lass uns abwarten, bis du den Job hast."

    # say L2925 pla
    old "I'll come by later to see how everything went, alright?"
    new "Ich komme später vorbei, um zu sehen, wie alles gelaufen ist, okay?"

    # say L2945 bri
    old "You're taking too long, how many more times are you going to see this woman?"
    new "Du brauchst echt lang, wie oft willst du diese Frau noch sehen?"

    # say L2946 pla
    old "I already told you. Until I'm done helping her with everything I promised I would do."
    new "Ich hab's dir schon gesagt. Bis ich ihr bei allem geholfen habe, was ich versprochen hab."

    # say L2947 pla
    old "What are you doing here anyway?"
    new "Was machst du hier überhaupt?"

    # say L2948 bri
    old "I thought I told you, you take too long."
    new "Ich dachte, ich hab dir gesagt, dass du zu langsam bist."

    # say L2949 bri
    old "So, I came to help you deal with this quickly."
    new "Dann bin ich hier, um dir zu helfen, das schnell zu erledigen."

    # say L2950 pla
    old "Ok, thank you I guess."
    new "Ok, danke, schätze ich."

    # say L2951 pla
    old "But I think everything's going to go well, you know?"
    new "Aber ich denke, alles wird gut gehen, weißt du?"

    # say L2952 pla
    old "Since I got her the interview, I'm sure that went well, and now she has good news."
    new "Da ich ihr das Vorstellungsgespräch besorgt habe, bin ich sicher, dass es gut gelaufen ist, und jetzt hat sie gute Nachrichten."

    # say L2953 pla
    old "But let's go and talk to her."
    new "Aber lass uns zu ihr gehen und mit ihr reden."

    # say L2963 pla
    old "Hey Barbie, good morning."
    new "Hey Barbie, guten Morgen."

    # say L2967 pla
    old "W- what's wrong Barbie?"
    new "W-was ist los, Barbie?"

    # say L2970 pla
    old "It didn't go well?"
    new "Ist was passiert?"

    # say L2972 pla
    old "What happened?"
    new "Was ist passiert?"

    # say L2975 pla
    old "S- sure, no problem."
    new "Klar, kein Problem."

    # say L2976 pla
    old "I'll see you later then."
    new "Dann sehen wir uns später."

    # say L3000 pla
    old "Ok, so now will you tell me about what happened?"
    new "Ok, dann erzählst du mir jetzt, was passiert ist?"

    # say L3001 pla
    old "How did the interview go?"
    new "Wie war das Gespräch?"

    # say L3007 pla
    old "Ok, that's good to hear."
    new "Okay, das ist gut zu hören."

    # say L3008 pla
    old "But then what went wrong?"
    new "Aber was ist dann schiefgelaufen?"

    # say L3014 pla
    old "So, did he say anything to you about that?"
    new "Hat er dir was dazu gesagt?"

    # say L3030 pla
    old "What the hell? Who does he think he is?!"
    new "Was soll das? Wer glaubt er eigentlich, wer er ist?!"

    # say L3031 pla
    old "I'm sorry Barbie, I had no idea things would turn out that way."
    new "Tut mir leid, Barbie, ich hatte keine Ahnung, dass es so kommen würde."

    # say L3032 pla
    old "I didn't expect that."
    new "Ich hab das nicht erwartet."

    # say L3033 pla
    old "But I'll get you another interview in a better place."
    new "Aber ich sorge dafür, dass du ein neues Bewerbungsgespräch in einem besseren Ort bekommst."

    # say L3034 pla
    old "And I'll make sure that this doesn't happen again."
    new "Und ich sorge dafür, dass das nicht noch mal passiert."

    # say L3039 pla
    old "W- wait!"
    new "W-warte!"

    # say L3040 pla
    old "I get it, you've had a bad streak with the auditions and interviews."
    new "Ich verstehe, du hattest eine schlechte Phase bei den Vorsprechen und Interviews."

    # say L3041 pla
    old "But that doesn't mean that you should give up."
    new "Aber das heißt nicht, dass du aufgeben sollst."

    # say L3042 pla
    old "Don't let a couple of bad experiences rob you of your dream."
    new "Lass dir nicht von ein paar schlechten Erfahrungen deinen Traum nehmen."

    # say L3046 pla
    old "D- do you want to talk about it?"
    new "D- willst du darüber reden?"

    # say L3050 pla
    old "Listen Barbie, what you have been going through with these... Bad experiences."
    new "Hör zu, Barbie, was du durchgemacht hast mit diesen... Schlechten Erfahrungen."

    # say L3051 pla
    old "I can't imagine how frustrating it must be."
    new "Ich kann mir nicht vorstellen, wie frustrierend das für dich sein muss."

    # say L3052 pla
    old "Especially if there are things from your past that are related to this. I think that causes you a lot of pain."
    new "Besonders wenn da Dinge aus deiner Vergangenheit sind, die damit zusammenhängen. Ich denke, das bereitet dir viel Schmerz."

    # say L3056 pla
    old "I understand, and that's fair."
    new "Ich verstehe, und das ist fair."

    # say L3057 pla
    old "But I also think you still shouldn't give up on your dream of becoming a star Barbie."
    new "Aber ich denke auch, dass du dein Traum von der Star-Barbie nicht aufgeben solltest."

    # say L3058 pla
    old "I've seen your passion for it. And I know how much of a hard worker you are."
    new "Ich hab deine Leidenschaft gesehen. Und ich weiß, wie hart du arbeitest."

    # say L3059 pla
    old "If someone deserves a shot at something like that, it's you."
    new "Wenn jemand eine Chance verdient, dann bist du das."

    # say L3064 pla
    old "Hmm, I see..."
    new "Hmm, ich sehe..."

    # say L3065 pla
    old "Listen, you already told me that something's troubling you."
    new "Hör mal, du hast mir doch schon gesagt, dass was dich belastet."

    # say L3066 pla
    old "But you told me you don't want to talk about it."
    new "Aber du hast mir gesagt, dass du nicht darüber reden willst."

    # say L3067 pla
    old "Which I understand."
    new "Das verstehe ich."

    # say L3068 pla
    old "But I think you should talk about it."
    new "Aber ich denke, du solltest darüber reden."

    # say L3069 pla
    old "Maybe opening up about it would do you well."
    new "Vielleicht wäre es gut, darüber zu sprechen."

    # say L3071 pla
    old "I get it, it must be a painful memory, but you know, there's nothing to be afraid of."
    new "Ich verstehe, es muss eine schmerzhafte Erinnerung sein, aber weißt du, du musst dich vor nichts fürchten."

    # say L3072 pla
    old "You can trust me with anything you want to share."
    new "Du kannst mir alles anvertrauen, was du teilen willst."

    # say L3073 pla
    old "No matter what it is, I want to support you and make sure that you feel safe and happy."
    new "Egal was es ist, ich will dich unterstützen und sichergehen, dass du dich sicher und glücklich fühlst."

    # say L3074 pla
    old "I mean it Barbie, whatever it is."
    new "Ich meine es ernst, Barbie, egal was es ist."

    # say L3076 pla
    old "That makes sense, but I'll be more than happy to listen to what you have to say."
    new "Das ist logisch, aber ich freue mich, dir zuzuhören."

    # say L3077 pla
    old "To listen to you."
    new "Dir zuhören"

    # say L3078 pla
    old "Maybe talking about it you can get rid of some of that pain, you know?"
    new "Vielleicht hilft es dir, wenn du darüber redest, den Schmerz loszuwerden, weißt du?"

    # say L3099 pla
    old "And... W- what happened?"
    new "Und... W- was ist passiert?"

    # say L3124 pla
    old "Listen Barbie, I know that what happened in your past was very painful."
    new "Hör zu, Barbie, ich weiß, dass das, was in deiner Vergangenheit passiert ist, sehr schmerzhaft war."

    # say L3126 pla
    old "And that we can't go back and changed it."
    new "Und dass wir nicht zurückgehen und es ändern können."

    # say L3128 pla
    old "But I don't think you're wrong for chasing your dreams."
    new "Aber ich denke nicht, dass du falsch bist, weil du deine Träume verfolgst."

    # say L3130 pla
    old "Or that you have made any mistakes by choosing to chase your dreams."
    new "Oder dass du Fehler gemacht hast, indem du deinen Träumen nachgejagt bist."

    # say L3132 pla
    old "Yes it's true that you've been unlucky with how things have gone in the past."
    new "Stimmt, du hattest Pech, wie sich die Dinge in der Vergangenheit entwickelt haben."

    # say L3133 pla
    old "But I believe you still have a lot of chances for things to go your way."
    new "Aber ich glaube, du hast noch viele Chancen, dass sich alles zum Guten wendet."

    # say L3135 pla
    old "You're a beautiful and hard-working woman."
    new "Du bist eine wunderschöne und fleißige Frau."

    # say L3136 pla
    old "I'm sure if you keep trying, sooner or later you'll someday meet someone that will be different from the rest."
    new "Ich bin sicher, wenn du weiter versuchst, wirst du früher oder später jemanden treffen, der anders ist als die anderen."

    # say L3139 pla
    old "Of course you will!"
    new "Natürlich wirst du!"

    # say L3141 pla
    old "You're diligent and capable."
    new "Du bist fleißig und fähig."

    # say L3142 pla
    old "And I'm completely sure that you will find very good fortune."
    new "Und ich bin mir absolut sicher, dass dir sehr viel Glück beschieden sein wird."

    # say L3144 pla
    old "As I told you, if someone deserves good things coming their way, that is you."
    new "Wie ich dir schon gesagt habe, wenn jemand es verdient, dass ihm Gutes widerfährt, dann bist du das."

    # say L3145 pla
    old "So, if you'll believe me, I would like to help you keep working towards achieving your dream."
    new "Dann, wenn du mir glaubst, würde ich gerne helfen, dass du weiterhin deinen Traum verfolgen kannst."

    # say L3160 pla
    old "I'm just happy that I get to be here for you Barbie."
    new "Ich bin einfach froh, dass ich für dich da sein kann, Barbie."

    # say L3161 pla
    old "About the other things, I'm just saying the truth every time we talk."
    new "Bei den anderen Dingen sage ich jedes Mal die Wahrheit, wenn wir reden."

    # say L3162 pla
    old "You're a capable and talented person."
    new "Du bist eine fähige und talentierte Person."

    # say L3195 pla
    old "I- I'll do my best."
    new "Ich- Ich werde mein Bestes geben."

    # say L3197 pla
    old "Really, the next one will be better."
    new "Wirklich, das nächste Mal wird es besser."

    # say L3199 pla
    old "I'm sure of it Barbie."
    new "Ich bin mir sicher, Barbie."

    # say L3203 pla
    old "I'm glad you feel that way."
    new "Ich bin froh, dass du so denkst."

    # say L3204 pla
    old "Even though there have been a couple of inconveniences."
    new "Aber es gab schon ein paar Unannehmlichkeiten."

    # say L3205 pla
    old "But I'm sure we'll get you a job that's good enough for you."
    new "Aber ich bin sicher, wir finden für dich einen Job, der gut genug ist."

    # say L3214 pla
    old "U- Uh, I- I mean."
    new "U- Äh, ich- ich meine."

    # say L3223 pla
    old "Uh, s- sure, see you later."
    new "Uh, s-sicher, bis später."

    # say L3244 sis
    old "Hey [pla], good morning."
    new "Hey [pla], guten Morgen."

    # say L3245 pla
    old "Hey [sis], good morning."
    new "Hey [sis], guten Morgen."

    # say L3246 sis
    old "How are you today?"
    new "Wie geht es dir heute?"

    # say L3248 pla
    old "I'm doing fine, but there's something we have to talk about."
    new "Ich bin okay, aber da ist etwas, über das wir reden müssen."

    # say L3249 sis
    old "What is it?"
    new "Was ist los?"

    # say L3250 pla
    old "Well, I don't know the full details."
    new "Na ja, ich kenne die ganzen Details nicht."

    # say L3252 pla
    old "But as Barbie told me, the guy who interviewed her for the modeling job tried to sleep with her."
    new "Aber wie Barbie mir erzählt hat, der Typ, der sie für den Modeljob interviewt hat, wollte mit ihr ins Bett."

    # say L3255 pla
    old "Yeah, he did. Apparently, he told her that there were a lot of good candidates for that job."
    new "Ja, das hat er. Scheint, als hätte er ihr gesagt, dass es viele gute Kandidatinnen für den Job gibt."

    # say L3257 pla
    old "So if she wanted the job, she would have to give him a {i}'payment'{/i} for it."
    new "Dann müsste sie ihm also einen {i}'Service'{/i} dafür leisten, wenn sie den Job will."

    # say L3259 sis
    old "That pig!"
    new "Was für ein Schwein!"

    # say L3261 sis
    old "I mean what the fuck! What's wrong with him?!"
    new "Ich meine, was zum Teufel! Was ist bloß mit ihm los?!"

    # say L3262 sis
    old "What a disgusting thing."
    new "Was für ein widerliches Arschloch."

    # say L3264 sis
    old "Can you believe that bastard was trying to get me to model some clothes for his brand?"
    new "Kannst du glauben, dass dieser Arsch versucht hat, mich dazu zu kriegen, für seine Marke zu modeln?"

    # say L3265 sis
    old "But I hadn't had the time to do it."
    new "Aber ich hatte einfach keine Zeit dazu."

    # say L3267 sis
    old "That means that if I had been available he would probably have tried the same thing with me!"
    new "Das bedeutet, wenn ich verfügbar gewesen wäre, hätte er wahrscheinlich das Gleiche bei mir versucht!"

    # say L3269 sis
    old "And he had the gall to try and pull that with her?!"
    new "Und er hatte die Frechheit, das bei ihr zu versuchen?!"

    # say L3271 sis
    old "Sure, he probably realized that she needed that opportunity and decided to take advantage."
    new "Klar, er hat wahrscheinlich gemerkt, dass sie die Chance braucht, und sich entschieden, das auszunutzen."

    # say L3273 sis
    old "What a fucking coward!"
    new "Was für ein verdammter Feigling!"

    # say L3274 pla
    old "Uhm... Yeah."
    new "Uhm... Ja."

    # say L3276 sis
    old "But don't worry [pla], I'm not going to let things stay like this."
    new "Aber mach dir keine Sorgen [pla], ich werde nicht zulassen, dass es dabei bleibt."

    # say L3278 sis
    old "I'm actually in contact with a couple of brands that are working with that guy."
    new "Ich bin eigentlich in Kontakt mit ein paar Marken, die mit dem Typen zusammenarbeiten."

    # say L3280 sis
    old "But they won't be after I tell them what happened."
    new "Aber das werden sie nicht mehr, nachdem ich ihnen erzähle, was passiert ist."

    # say L3281 sis
    old "I'll make everyone knows what that bastard tried to do."
    new "Ich werde jedem sagen, was dieser Bastard versucht hat."

    # say L3282 sis
    old "That way that pig will learn how to treat women!"
    new "Dann wird dieser Schweinehund lernen, wie man Frauen behandelt!"

    # say L3283 pla
    old "Uh- I- I see."
    new "Uh- Ich- Ich sehe."

    # say L3285 sis
    old "Tell Barbie sorry on my behalf."
    new "Sag Barbie von mir aus sorry."

    # say L3286 sis
    old "I may not like her too much, but I would have never knowingly sent her to a place like that."
    new "Ich mag sie vielleicht nicht besonders, aber ich hätte sie nie absichtlich an so einen Ort geschickt."

    # say L3288 sis
    old "And of course, I'll make her up for it."
    new "Und natürlich werde ich es wiedergutmachen."

    # say L3289 sis
    old "So don't worry, I'll get her another interview."
    new "Mach dir also keine Sorgen, ich werde ihr ein neues Bewerbungsgespräch besorgen."

    # say L3291 sis
    old "And I'll make sure that this time is with a reputable place."
    new "Und ich sorge dafür, dass es diesmal bei einem seriösen Arbeitgeber ist."

    # say L3292 pla
    old "That sounds great [sis], thank you!"
    new "Das klingt super [sis], danke!"

    # say L3294 sis
    old "Now, I'll talk to you later."
    new "Dann sprechen wir später."

    # say L3295 sis
    old "I have a couple of calls to make."
    new "Ich hab noch ein paar Anrufe zu machen."

    # say L3296 pla
    old "Uh- S- sure, see you later."
    new "Klar, bis später."

    # say L3319 sis
    old "Good news, I brought something for you."
    new "Gute Nachrichten, ich habe was für dich mitgebracht."

    # say L3320 pla
    old "Oh really? How come?"
    new "Oh wirklich? Wie kommst du darauf?"

    # say L3322 sis
    old "Well, I got another interview for Barbie."
    new "Na ja, ich habe noch ein Vorstellungsgespräch für Barbie bekommen."

    # say L3324 pla
    old "That's great [sis]! Thank you."
    new "Das ist toll [sis]! Danke."

    # say L3325 sis
    old "Don't worry about it. I'm happy to help her."
    new "Mach dir keine Sorgen. Ich freue mich, ihr zu helfen."

    # say L3326 sis
    old "And this time I made sure that the place where I'm sending her is quite reputable."
    new "Und dieses Mal habe ich sichergestellt, dass der Ort, wohin ich sie schicke, sehr seriös ist."

    # say L3327 sis
    old "So you can be sure that nothing like what happened last time will happen again."
    new "Dann kannst du sicher sein, dass so was wie letztes Mal nicht noch mal passiert."

    # say L3328 pla
    old "That's awesome [sis]!"
    new "Das ist super [sis]!"

    # say L3329 pla
    old "So, what you have in the box is related to that?"
    new "Und was du in der Schachtel hast, hat damit zu tun?"

    # say L3331 sis
    old "It is."
    new "Das ist es."

    # say L3332 sis
    old "The place where Barbie's going is a lingerie company."
    new "Die Firma, bei der Barbie arbeiten wird, ist ein Dessous-Unternehmen."

    # say L3333 sis
    old "So, when I send them the pictures you had given me of Barbie, they thought she looked very good."
    new "Dann, als ich ihnen die Bilder von Barbie gezeigt habe, die du mir gegeben hast, fanden sie, dass sie sehr gut aussieht."

    # say L3334 sis
    old "But they said they wanted to see her posing in some lingerie or underwear."
    new "Aber sie sagten, sie möchten sie in Unterwäsche oder Lingerie posieren sehen."

    # say L3335 sis
    old "And I imagine you don't have a portfolio of pictures of her in lingerie, right?"
    new "Und ich stelle mir vor, du hast kein Bildermaterial von ihr im Negligé, oder?"

    # say L3337 pla
    old "Uh- n- no, I don't"
    new "Uh- n- nein, hab ich nicht"

    # say L3339 sis
    old "Well, that's why I took the liberty of getting some new lingerie that would fit her. You know, for you to take some pictures."
    new "Na klar, deshalb hab ich mir die Freiheit genommen, ein paar neue Dessous für sie zu besorgen, die ihr passen. Du weißt schon, damit du ein paar Fotos machen kannst."

    # say L3340 pla
    old "Oh wow [sis], t- that's awesome!"
    new "Oh wow [sis], d- das ist toll!"

    # say L3341 sis
    old "Well, I think it was the least I could do. You know?"
    new "Na ja, ich dachte, das ist das Mindeste, was ich tun kann. Du weißt schon?"

    # say L3343 sis
    old "So, take this. And talk to her to take the pictures as soon as you can."
    new "Dann nimm das. Und rede mit ihr, damit sie die Fotos machen kann, so schnell wie möglich."

    # say L3349 pla
    old "Alright, I'll talk to her as soon as I can."
    new "Okay, ich rede mit ihr, sobald ich kann."

    # say L3351 sis
    old "Alright. I'll be waiting for the pictures then."
    new "Okay. Ich warte dann auf die Fotos."

    # say L3352 sis
    old "By the way, you haven't forgotten about my 10 percent right?"
    new "Übrigens, du hast mein 10-Prozent noch nicht vergessen, oder?"

    # say L3353 pla
    old "No, no, I got you."
    new "Nein, nein, ich hab's im Kopf."

    # say L3354 sis
    old "Alright, I'll see you later then."
    new "Okay, dann sehen wir uns später."

    # say L3357 pla
    old "Sure, Bye."
    new "Klar, tschüss."

    # say L3381 pla
    old "I'm fine."
    new "Mir geht's gut."

    # say L3382 pla
    old "Actually I'm more than fine, I just got some good news."
    new "Eigentlich bin ich mehr als gut, ich habe gerade gute Nachrichten bekommen."

    # say L3384 pla
    old "That contact I told you about got you an interview!"
    new "Die Kontaktperson, von der ich dir erzählt habe, hat dir ein Vorstellungsgespräch besorgt!"

    # say L3385 pla
    old "And don't worry, this time she ensured me that what happened last time wouldn't happen again."
    new "Und mach dir keine Sorgen, sie hat mir versichert, dass so was wie letztes Mal nicht noch mal passiert."

    # say L3390 pla
    old "Well, that's the thing, before they interview you. They said they would like to see a couple of pictures of you."
    new "Na ja, das ist die Sache, bevor sie dich interviewen. Sie sagten, sie würden gerne ein paar Fotos von dir sehen."

    # say L3393 pla
    old "Yeah, and they really liked them."
    new "Ja, und sie haben sie echt gemocht."

    # say L3394 pla
    old "But you see, this new place is a lingerie retailer."
    new "Aber du siehst, dieser neue Laden verkauft Unterwäsche."

    # say L3396 pla
    old "So they said they'd be interested in seeing how you look in lingerie before you go."
    new "Dann haben sie gesagt, dass sie interessiert wären, zu sehen, wie du in Lingerie aussiehst, bevor du gehst."

    # say L3397 pla
    old "So, my contact got some lingerie for you to try."
    new "Dann hat mein Kontakt also ein paar Dessous für dich zum Ausprobieren besorgt."

    # say L3399 pla
    old "I was thinking that maybe after you're done with your shift you'd like to come with me to my house and you can try it on."
    new "Ich dachte, vielleicht magst du nach deiner Schicht mit zu mir kommen und es anprobieren."

    # say L3404 pla
    old "Great, then I'll wait until your shift is over and then we can come back to my house."
    new "Okay, dann warte ich, bis dein Schichtende ist, und danach können wir zu mir nach Hause gehen."

    # say L3415 pla
    old "Alright, let's go then."
    new "Okay, dann lass uns gehen."

    # say L3428 pla
    old "Alright, this is the lingerie, why don't you change into it? And we'll do the pictures."
    new "Okay, das ist das Dessous, zieh es doch mal an. Und dann machen wir die Fotos."

    # say L3440 pla
    old "S- sorry, is not that I don't like it, I was just surprised because of how beautiful you look."
    new "Entschuldigung, es ist nicht so, dass ich es nicht mag, ich war nur überrascht, wie wunderschön du aussiehst."

    # say L3441 pla
    old "That lingerie looks very good on you."
    new "Das Dessous steht dir sehr gut."

    # say L3445 pla
    old "What? Of course not!"
    new "Was? Natürlich nicht!"

    # say L3446 pla
    old "You look just perfect!"
    new "Du siehst einfach perfekt aus!"

    # say L3447 pla
    old "You look very beautiful, I mean it."
    new "Du siehst sehr schön aus, das meine ich ernst."

    # say L3450 pla
    old "Why? You don't think the same?"
    new "Warum? Du denkst doch nicht anders, oder?"

    # say L3454 pla
    old "You know, if you don't feel alright about this we don't have to do it."
    new "Du weißt, wenn dir das nicht recht ist, müssen wir das nicht machen."

    # say L3461 pla
    old "Come on, no one's going to think that."
    new "Komm schon, das denkt doch niemand."

    # say L3462 pla
    old "You are one of the most beautiful girls I know  Barbie."
    new "Du bist eines der schönsten Mädchen, die ich kenne, Barbie."

    # say L3463 pla
    old "I'm sure that as soon as they see you they'll want to hire you."
    new "Ich bin sicher, sobald sie dich sehen, wollen sie dich engagieren."

    # say L3465 pla
    old "Of course I do."
    new "Natürlich tu ich das."

    # say L3480 pla
    old "Ok, the first picture is just going to be you standing there normally."
    new "Okay, das erste Bild wird einfach nur dich zeigen, wie du da stehst."

    # say L3481 pla
    old "So don't move while I take the picture."
    new "Dann beweg dich nicht, während ich das Foto mache."

    # say L3502 pla
    old "Alright, that was good."
    new "Okay, das war gut."

    # say L3503 pla
    old "So, for the second picture, how about you lay on your right side."
    new "Dann, für das zweite Bild, leg dich auf die rechte Seite."

    # say L3504 pla
    old "Open your body a little bit, and put your left leg up."
    new "Mach deinen Körper ein bisschen frei und heb dein linkes Bein an."

    # say L3505 pla
    old "Then rest your left hand on your hip, and lift your torso up a little using your right arm."
    new "Dann lege deine linke Hand auf die Hüfte und stütze dich mit dem rechten Arm ein wenig ab."

    # say L3518 pla
    old "That's it, perfect!"
    new "Das ist es, perfekt!"

    # say L3540 pla
    old "I do, you look wonderful"
    new "Ich tu's, du siehst wunderbar aus"

    # say L3542 pla
    old "Alright, for the next one."
    new "Okay, für die Nächste."

    # say L3543 pla
    old "How about we show a little bit of how you look from behind?"
    new "Was meinst du, zeigst du mir auch, wie du von hinten aussiehst?"

    # say L3545 pla
    old "Great, kneel with your back towards  me."
    new "Super, knie dich mit dem Rücken zu mir."

    # say L3546 pla
    old "While you rest your forearms on the bed."
    new "Während du deine Unterarme aufs Bett legst."

    # say L3547 pla
    old "And turn your head over your right shoulder while you look at me."
    new "Und dreh deinen Kopf über deine rechte Schulter, während du mich ansiehst."

    # say L3559 pla
    old "That's it! Perfect!"
    new "Das ist es! Perfekt!"

    # say L3560 pla
    old "That's great Barbie!"
    new "Das ist toll Barbie!"

    # say L3562 pla
    old "You look great Barbie!"
    new "Du siehst toll aus, Barbie!"

    # say L3563 pla
    old "{i}(Dang, she really does look amazing.){/i}"
    new "{i}(Scheiße, sie sieht echt unglaublich aus.){/i}"

    # say L3591 pla
    old "Alright, I think that's it."
    new "Okay, ich glaube, das war's."

    # say L3592 pla
    old "W- why don't you go change while I put the camera away?"
    new "W- warum gehst du nicht dich umziehen, während ich die Kamera wegräume?"

    # say L3601 pla
    old "Uhh... w- well, y- you know."
    new "Uhh... w- weißt du."

    # say L3614 pla
    old "W- what are you doing?"
    new "W- was machst du da?"

    # say L3627 pla
    old "Uhh, I- I'm glad you liked it."
    new "Uhh, ich- ich freue mich, dass dir das gefallen hat."

    # say L3634 pla
    old "I'll let you know what they say about the pictures, alright?"
    new "Ich sag dir Bescheid, was sie zu den Bildern sagen, okay?"

    # say L3659 pla
    old "Why are you waking me up at this time?"
    new "Warum weckst du mich um diese Zeit?"

    # say L3661 bri
    old "Well, I have something to tell you."
    new "Na, ich hab was zu erzählen."

    # say L3664 bri
    old "Great news! The process of implantation of the magic power within Barbie is complete!"
    new "Große Neuigkeiten! Der Vorgang der Magie-Implantation in Barbie ist abgeschlossen!"

    # say L3666 bri
    old "So we can now move into the next objective!"
    new "Dann können wir jetzt das nächste Ziel angehen!"

    # say L3667 pla
    old "Implantation of the magic power? What do you mean?"
    new "Magieimplantation? Was meinst du damit?"

    # say L3668 bri
    old "Ugh, I see that you forgot about what we were trying to do here."
    new "Ugh, ich sehe, dass du vergessen hast, was wir hier tun wollten."

    # say L3669 bri
    old "Did you forget that we're trying to get you to implant magic power into different women."
    new "Hast du vergessen, dass wir versuchen, dir bei der Magieimplantation in verschiedene Frauen zu helfen."

    # say L3670 bri
    old "So that they can cultivate the magic power within their bodies?"
    new "Damit sie die magische Kraft in ihren Körpern kultivieren können?"

    # say L3671 pla
    old "Hmm... Yeah, right."
    new "Hmm... Ja, stimmt."

    # say L3673 pla
    old "According to what you told me last time."
    new "Nach dem, was du mir letztes Mal erzählt hast."

    # say L3674 pla
    old "Does that mean that she's pregnant now?!"
    new "Das heißt, sie ist jetzt schwanger?!"

    # say L3676 bri
    old "Hmph, I guess that from your point of view that's how it looks."
    new "Hmpf, aus deiner Sicht sieht es wohl so aus."

    # say L3677 bri
    old "But not really."
    new "Aber nicht wirklich."

    # say L3679 bri
    old "She'll just look and feel as if she is, but she's not pregnant."
    new "Sie wird nur so aussehen und sich so anfühlen, als wäre sie es, aber sie ist nicht schwanger."

    # say L3680 bri
    old "So you don't have to worry, when we're done with the spell we'll just collect the power."
    new "Du musst dir also keine Sorgen machen, wenn wir mit dem Zauber fertig sind, sammeln wir einfach die Kraft."

    # say L3682 bri
    old "And she'll just go back to normal."
    new "Und sie wird wieder normal werden."

    # say L3684 pla
    old "When we're done with the spell?!"
    new "Wenn wir mit dem Zauber fertig sind?!"

    # say L3686 pla
    old "So until we're not done with it she'll be pregnant?"
    new "Dann ist sie also bis dahin schwanger?"

    # say L3687 pla
    old "That's not okay!"
    new "Das ist nicht in Ordnung!"

    # say L3688 pla
    old "She just barely got a chance to work."
    new "Sie hat gerade erst die Chance bekommen zu arbeiten."

    # say L3690 pla
    old "And if she's pregnant she won't even be able to work."
    new "Und wenn sie schwanger ist, wird sie überhaupt nicht mehr arbeiten können."

    # say L3691 pla
    old "You'll have to reverse it."
    new "Du musst es rückgängig machen."

    # say L3692 bri
    old "Reverse it?! Are you crazy?"
    new "Umkehren?! Bist du verrückt?"

    # say L3693 bri
    old "With all of the time and magic power that has gone into it?!"
    new "Mit all der Zeit und Magie, die da reingesteckt wurden?!"

    # say L3694 bri
    old "How can you even say such a thing?"
    new "Wie kannst du so was überhaupt sagen?"

    # say L3695 pla
    old "Because, as I told you! She can't be pregnant!"
    new "Weil ich dir doch gesagt habe! Sie kann nicht schwanger sein!"

    # say L3696 pla
    old "I understand that you want me to hurry up with the ritual."
    new "Ich verstehe, dass du willst, dass ich mich mit dem Ritual beeile."

    # say L3697 pla
    old "And I promise you that if you do it I'll make sure to do what you need me to for the ritual to go well."
    new "Und ich verspreche dir, dass ich alles tun werde, was nötig ist, damit der Ritual gut läuft."

    # say L3699 bri
    old "Ugh, you're so difficult to handle [pla]."
    new "Ugh, du bist echt schwierig zu handhaben [pla]."

    # say L3701 bri
    old "Fine, I'll do it."
    new "Okay, ich mach's."

    # say L3702 bri
    old "But I want you to start working on the next target right away!"
    new "Aber ich will, dass du sofort mit dem nächsten Ziel anfängst!"

    # say L3703 pla
    old "Sure... But just let me finish what I have to do with Barbie."
    new "Klar... Aber lass mich erst fertig werden mit Barbie."

    # say L3706 pla
    old "I just have to finish a couple of things with her, and I'll get into working in the person."
    new "Ich muss noch ein paar Dinge mit ihr erledigen, dann fange ich an, an der Person zu arbeiten."

    # say L3708 bri
    old "{b}*Sigh*{/b}."
    new "{b}*Seufz*{/b}."

    # say L3709 bri
    old "Alright, but remember what you promised me [pla]."
    new "Okay, aber denk dran, was du mir versprochen hast [pla]."

    # say L3710 pla
    old "Sure, sure..."
    new "Klar, klar..."

    # say L3733 pla
    old "I'm okay, but I imagine that not as well as you will."
    new "Ich bin okay, aber ich stelle mir vor, dass es dir besser gefällt."

    # say L3736 pla
    old "You bet!"
    new "Klar, klar!"

    # say L3737 pla
    old "I just got a text from the person who got you the interview for the modeling gig."
    new "Ich hab gerade eine Nachricht vom Typen bekommen, der dir das Model-Job-Interview besorgt hat."

    # say L3738 pla
    old "They said that they loved the pictures, and how you look with the lingerie on!"
    new "Sie haben gesagt, dass sie die Fotos lieben und wie du in der Wäsche aussiehst!"

    # say L3740 pla
    old "They said they wanted to meet with you to discuss hiring you as their model!"
    new "Sie sagten, sie möchten sich mit dir treffen, um über deine Anstellung als Model zu sprechen!"

    # say L3747 pla
    old "Haha, I'm glad this makes you happy."
    new "Haha, ich freue mich, dass dir das gefällt."

    # say L3751 pla
    old "Oh no, it isn't."
    new "Oh nein, das ist es nicht."

    # say L3752 pla
    old "I've only made a couple of phone calls."
    new "Ich hab nur ein paar Anrufe gemacht."

    # say L3753 pla
    old "This is because of your effort."
    new "Das ist wegen deiner Mühe."

    # say L3754 pla
    old "Although don't forget you still have to go to the interview."
    new "Aber vergiss nicht, dass du immer noch zum Vorstellungsgespräch musst."

    # say L3755 pla
    old "But I'm sure everything's going to go well."
    new "Aber ich bin sicher, alles wird gut gehen."

    # say L3771 pla
    old "W- w- what are you doing Barbie?"
    new "W- w- was machst du da, Barbie?"

    # say L3772 pla
    old "Y- you can't do that here!"
    new "D- du darfst das hier nicht tun!"

    # say L3775 pla
    old "B- but, t- there are cameras!"
    new "B- aber, d- da sind Kameras!"

    # say L3776 pla
    old "O- or someone could walk through here!"
    new "O- oder jemand könnte hier reinkommen!"

    # say L3787 pla
    old "I can't believe you actually did that!"
    new "Ich fass es nicht, dass du das wirklich gemacht hast!"

    # say L3792 pla
    old "Well... Whatever."
    new "Na ja... Was soll's."

    # say L3793 pla
    old "Don't forget that you have to go to the interview, alright?"
    new "Vergiss nicht, dass du zu dem Vorstellungsgespräch musst, okay?"

    # say L3796 pla
    old "It's alright, no problem."
    new "Ist gut, kein Problem."

    # say L3798 pla
    old "I'll see you later so you can tell me how the interview went, alright?"
    new "Ich seh dich später, dann erzählst du mir, wie das Gespräch gelaufen ist, okay?"

    # say L3819 pla
    old "Hmm, who could it be?"
    new "Hmm, wer könnte das sein?"

    # say L3820 pla
    old "I better hurry up and open the door..."
    new "Ich sollte mich beeilen und die Tür aufmachen..."

    # say L3826 pla
    old "Oh, hi Barbie, nice to see you here."
    new "Oh, hallo Barbie, schön dich hier zu sehen."

    # say L3829 pla
    old "You did?! That's awesome Barbie!"
    new "Du hast?! Das ist klasse, Barbie!"

    # say L3830 pla
    old "So I take it the interview went well, right?"
    new "Dann war das Gespräch wohl gut, oder?"

    # say L3834 pla
    old "That's great, hey, let's come to my room."
    new "Das ist toll, hey, lass uns in mein Zimmer kommen."

    # say L3835 pla
    old "That way you can tell me everything."
    new "Dann kannst du mir alles erzählen."

    # say L3851 pla
    old "That's so awesome Barbie, congrats!"
    new "Das ist so toll, Barbie, gratuliere!"

    # say L3885 pla
    old "Well, I'm glad you're happy."
    new "Na, ich freue mich, dass du glücklich bist."

    # say L3888 pla
    old "You're still going to work?"
    new "Du gehst immer noch arbeiten?"

    # say L3901 bri
    old "Alright! I hear all of that!"
    new "Alles klar! Ich hab alles gehört!"

    # say L3902 bri
    old "She's happy, and you accomplished what you wanted."
    new "Sie ist glücklich, und Sie haben erreicht, was Sie wollten."

    # say L3903 bri
    old "That means we can get to my thing now, right?"
    new "Das bedeutet, wir können jetzt zu meinem Teil kommen, oder?"

    # say L3917 mo1
    old "[pla], wake up!"
    new "[pla], wach auf!"

    # say L3923 pla
    old "[mo1]? What's happening?"
    new "[mo1]? Was ist los?"

    # say L3924 mo1
    old "Well, you see, Barbie's in the livingroom, she's waiting there to talk to you."
    new "Na ja, siehst du, Barbie sitzt im Wohnzimmer, sie wartet darauf, mit dir zu reden."

    # say L3925 pla
    old "Ohh, sure, I'll be downstairs in a minute."
    new "Ohh, klar, ich bin in einer Minute unten."

    # say L3926 mo1
    old "Ok, by the way. she's pregnant..."
    new "Ok, übrigens. Sie ist schwanger..."

    # say L3927 mo1
    old "Do you know anything about that?"
    new "Wissen Sie etwas darüber?"

    # say L3928 pla
    old "Me? No, nothing! I don't know what this is about..."
    new "Ich? Nein, gar nichts! Ich hab keine Ahnung, wovon du redest..."

    # say L3929 pla
    old "But I'll go down and talk to her."
    new "Aber ich geh runter und rede mit ihr."

    # say L3930 mo1
    old "Okay honey."
    new "Okay Schatz."

    # say L3936 pla
    old "B- Barbie! H- hi!"
    new "B- Barbie! H- hallo!"

    # say L3937 pla
    old "W- what's happening?"
    new "W- was passiert?"

    # say L3945 pla
    old "I- I... W- what's this?"
    new "I- Ich... W- was ist das?"

    # say L3946 pla
    old "Y- you're pregnant!"
    new "D- du bist schwanger!"

    # say L3954 pla
    old "H- hey, don't worry, we'll figure something out."
    new "H- hey, mach dir keine Sorgen, wir kriegen das hin."

    # say L3958 pla
    old "I know, I know."
    new "Ich weiß, ich weiß."

    # say L3959 pla
    old "But I'm sure everything will be fine."
    new "Aber ich bin sicher, alles wird gut."

    # say L3960 pla
    old "And I can promise you that I'll be here for you, no matter what. Alright?"
    new "Und ich verspreche dir, dass ich immer für dich da sein werde, egal was passiert. Okay?"

    # say L3962 pla
    old "Let's just wait for now, and give ourselves time to think about this."
    new "Lass uns einfach abwarten und uns Zeit geben, darüber nachzudenken."

    # say L3969 pla
    old "Of course, I understand."
    new "Natürlich, ich verstehe."

    # say L3971 pla
    old "But before we make any decision let's just make sure that you check with a doctor to see how you're doing."
    new "Aber bevor wir eine Entscheidung treffen, lass uns sicherstellen, dass du dich bei einem Arzt checken lässt, um zu sehen, wie es dir geht."

    # say L3972 pla
    old "You know, you're physical state."
    new "Du weißt schon, deinen körperlichen Zustand."

    # say L3974 pla
    old "You know, just to make sure everything's fine with you."
    new "Du weißt schon, nur um sicherzustellen, dass alles in Ordnung mit dir ist."

    # say L3978 pla
    old "I think it is."
    new "Ich denke schon."

    # say L3979 pla
    old "I know a lot is going through your head right now."
    new "Ich weiß, dass du gerade viel im Kopf hast."

    # say L3980 pla
    old "But precisely because of that, I think we shouldn't rush into anything."
    new "Aber genau deshalb denke ich, wir sollten uns nicht überstürzen."

    # say L3986 pla
    old "That's a great idea."
    new "Das ist eine tolle Idee."

    # say L3987 pla
    old "And keep me informed if you can, I'd like to know how you're doing."
    new "Und lass mich wissen, wie es dir geht, okay?"

    # say L3990 pla
    old "Hey, I'm happy to help you."
    new "Hey, ich freue mich, dir zu helfen."

    # say L4002 bri
    old "Hey [pla], why the long face?"
    new "Hey [pla], warum so traurig?"

    # say L4003 pla
    old "You ask why?!"
    new "Du fragst warum?!"

    # say L4004 pla
    old "Barbie just came here, she's pregnant!"
    new "Barbie ist gerade hier aufgetaucht, sie ist schwanger!"

    # say L4005 pla
    old "I thought you had stopped the spell!"
    new "Ich dachte, du hättest den Zauber gestoppt!"

    # say L4006 bri
    old "Well, I did stop it."
    new "Na ja, ich hab's gestoppt."

    # say L4007 bri
    old "But the magic cultivation process had already started."
    new "Aber der Prozess der magischen Kultivierung war bereits gestartet."

    # say L4008 bri
    old "You should know by now that when it comes to magic, nothing is ever as simple as 'canceling' a spell."
    new "Du solltest inzwischen wissen, dass bei Magie nichts so einfach ist wie ein Zauber abzubrechen."

    # say L4009 bri
    old "It's not like flipping a switch."
    new "Das ist nicht wie der Umstellung eines Schalters."

    # say L4011 bri
    old "The magic power is already in cultivation inside of her."
    new "Die magische Energie ist bereits in ihr."

    # say L4012 bri
    old "Or in human words, she's already pregnant."
    new "Oder auf Deutsch gesagt, sie ist schon schwanger."

    # say L4014 bri
    old "Besides, the magic spell to direct the magic you implanted in her."
    new "Außerdem ist der Zauberspruch, um die Magie zu lenken, die du in sie gepflanzt hast, und die Magie, die sich in ihr entwickelt, zwei verschiedene Dinge."

    # say L4015 bri
    old "And said magic developing within her are two different things."
    new "Und die Magie, die sich in ihr entwickelt, sind zwei verschiedene Dinge."

    # say L4017 pla
    old "Then what's the point of even canceling the spell?"
    new "Dann was bringt es überhaupt, den Zauber aufzuheben?"

    # say L4019 pla
    old "If she's still going to go through with it. We might as well have let her go through with it."
    new "Wenn sie es trotzdem durchziehen will, hätten wir sie genauso gut gewähren lassen können."

    # say L4021 bri
    old "I wasn't finished!"
    new "Ich war noch nicht fertig!"

    # say L4023 bri
    old "If what you're describing was the case, I wouldn't have done anything."
    new "Wenn das wäre, wie du es beschreibst, hätte ich nichts getan."

    # say L4024 bri
    old "Yes, she's still condensing magic within her."
    new "Ja, sie kondensiert immer noch Magie in sich."

    # say L4026 bri
    old "But that doesn't mean that there's nothing we can do."
    new "Aber das heißt nicht, dass wir nichts tun können."

    # say L4028 bri
    old "Listen, even though this appears to be a normal human pregnancy, you must keep in mind that magic's involved."
    new "Hör zu, obwohl es wie eine normale menschliche Schwangerschaft aussieht, musst du im Kopf behalten, dass Magie im Spiel ist."

    # say L4029 bri
    old "I can't just make her pregnancy go away. But I can make it go a lot faster than it normally would."
    new "Ich kann ihre Schwangerschaft nicht einfach verschwinden lassen. Aber ich kann sie viel schneller voranschreiten lassen als normal."

    # say L4031 pla
    old "W- what? So she'll have a baby soon?!"
    new "W-was? Sie wird also bald ein Baby bekommen?!"

    # say L4032 bri
    old "Hmph, no, she won't."
    new "Hmph, nein, das wird sie nicht."

    # say L4033 pla
    old "Uhh... Alright? I'm a little confused."
    new "Uhh... Okay? Ich bin ein bisschen verwirrt."

    # say L4034 bri
    old "Well... Magic adheres to the natural laws of your world..."
    new "Na ja... Magie unterliegt den natürlichen Gesetzen deiner Welt..."

    # say L4035 bri
    old "And that's why, even though it may seem 'pregnant,' what it's actually gestating is magical power..."
    new "Und deshalb, obwohl es vielleicht wie eine Schwangerschaft aussieht, was da tatsächlich entsteht, ist magische Energie..."

    # say L4037 pla
    old "Ok, so there is not baby?"
    new "Ok, also kein Baby?"

    # say L4038 bri
    old "Well, technically, a baby could be born from this process since it's all magical power..."
    new "Na ja, theoretisch könnte auch ein Baby aus diesem Prozess entstehen, da es sich um magische Energie handelt..."

    # say L4039 bri
    old "However, that would only happen if we decide that a portion of the magical power she's gestating materializes and develops."
    new "Allerdings würde das nur passieren, wenn wir entscheiden, dass ein Teil der magischen Energie, die sie trägt, materialisiert und sich entwickelt."

    # say L4040 bri
    old "That way, a portion of the magical power would adapt to the woman's womb..."
    new "So würde ein Teil der magischen Energie sich dem Körper der Frau anpassen..."

    # say L4041 bri
    old "And, powered by the condensing magical energy, it would develop like a human baby."
    new "Und angetrieben von der verdichteten magischen Energie würde es sich wie ein menschliches Baby entwickeln."

    # say L4042 bri
    old "So by the time the magic is fully cultivated they both come out of the body together."
    new "Dann, wenn die Magie vollständig ausgereift ist, kommen sie beide zusammen aus dem Körper."

    # say L4044 bri
    old "But in this case things are going to be very different."
    new "Aber in diesem Fall wird alles ganz anders sein."

    # say L4045 bri
    old "Since it's going to be a lot faster than normal, only the magic will develop inside of her."
    new "Da es viel schneller als normal sein wird, entwickelt sich nur die Magie in ihr."

    # say L4046 bri
    old "So by the time she gives birth only the magic will be coming out of her."
    new "Dann wird bei der Geburt nur die Magie aus ihr herauskommen."

    # say L4047 pla
    old "Ok, ok... I think I understand."
    new "Ok, ok... Ich glaube, ich hab's kapiert."

    # say L4049 pla
    old "But wait! What's going to happen when she goes to the doctor? Won't they realize there's something weird going on?"
    new "Aber warte! Was passiert, wenn sie zum Arzt geht? Wird da niemand merken, dass was Seltsames los ist?"

    # say L4050 bri
    old "I can see why you would think that."
    new "Ich verstehe, warum du das denkst."

    # say L4052 bri
    old "But in human terms, she's still pregnant, even if it's just with magic."
    new "Aber im menschlichen Sinne ist sie immer noch schwanger, auch wenn es nur mit Magie ist."

    # say L4054 bri
    old "When she goes to get checked with doctors and such, everything will appear to be normal."
    new "Wenn sie bei Ärzten untersucht wird oder so, wird alles normal aussehen."

    # say L4056 bri
    old "So everything should be ok."
    new "Dann sollte alles in Ordnung sein."

    # say L4058 pla
    old "Alright, that's good to hear."
    new "Okay, das ist gut zu hören."

    # say L4060 pla
    old "So everything should be okay from here on out, right?"
    new "Dann ist alles ab hier in Ordnung, oder?"

    # say L4062 bri
    old "Hmm, not entirely."
    new "Hmm, nicht ganz."

    # say L4063 pla
    old "R- really?"
    new "R- wirklich?"

    # say L4064 pla
    old "Is there something else?"
    new "Gibt es noch was anderes?"

    # say L4066 bri
    old "Well, what we're doing with this spell is trying to condense the magic energy needed to power up the portal to the magic world."
    new "Was wir mit diesem Zauber tun, ist versuchen, die magische Energie zu verdichten, die nötig ist, um das Portal zur Magiewelt zu aktivieren."

    # say L4067 bri
    old "And we're doing it by condensing magic within the bodies of women."
    new "Und wir tun das, indem wir die Magie in den Körpern von Frauen verdichten."

    # say L4068 pla
    old "Yeah, I get that."
    new "Klar, das verstehe ich."

    # say L4070 bri
    old "Well, the thing is that these women aren't natural magic wielders."
    new "Na ja, das Ding ist, dass diese Frauen keine natürlichen Magiebegabten sind."

    # say L4071 bri
    old "Their bodies aren't able to condense magic at the same rate that the spell demands it."
    new "Ihre Körper können das Mana nicht so schnell verdichten, wie der Zauber es verlangt."

    # say L4073 bri
    old "They would need your help with providing the magic they can't procure for themselves."
    new "Sie bräuchten deine Hilfe, um das Magie zu beschaffen, das sie selbst nicht aufbringen können."

    # say L4075 bri
    old "So, under normal circumstances, Barbie would need you to help her by giving her magic."
    new "Also, unter normalen Umständen, würde Barbie deine Hilfe brauchen, indem du ihr Magie gibst."

    # say L4076 bri
    old "But since this pregnancy will be so short, I don't think she'll need you to give her any condensed magic power."
    new "Aber da diese Schwangerschaft so kurz sein wird, denke ich nicht, dass sie von dir kondensierte Magie braucht."

    # say L4078 pla
    old "How would that work? The giving her magic part?"
    new "Wie würde das funktionieren? Das Teil mit dem Geben von Magie?"

    # say L4080 bri
    old "Oh, you know full well how that works, the same way you do it for me."
    new "Oh, das weißt du doch genau, genauso wie du es bei mir machst."

    # say L4081 pla
    old "I- I see..."
    new "I- Ich verstehe..."

    # say L4083 bri
    old "But as I explained to you, given her particular conditions I can't be sure about what's about to happen with her."
    new "Aber wie ich dir erklärt habe, bei ihren besonderen Bedingungen kann ich nicht sicher sein, was mit ihr passieren wird."

    # say L4084 bri
    old "So just be sure to be vigilant about what can happen to her. Just to make that she's fine."
    new "Dann achte einfach darauf, was mit ihr passieren könnte. Nur um sicherzustellen, dass es ihr gut geht."

    # say L4086 pla
    old "I understand, alright, I'll be sure to do that."
    new "Ich verstehe, okay, ich werde darauf achten."

    # say L4087 pla
    old "But thanks anyway Brixxida, this gives me some peace of mind."
    new "Aber danke trotzdem, Brixxida, das beruhigt mich."

    # say L4088 bri
    old "Well, I'm just letting you know what happened."
    new "Na ja, ich will dich nur über das Geschehene aufklären."

    # say L4090 bri
    old "But don't forget that now you have to keep going with our plans."
    new "Aber vergiss nicht, dass du jetzt mit unseren Plänen weitermachen musst."

    # say L4091 bri
    old "I'm letting you off the hook with this one, but be sure to keep searching the next specimen."
    new "Ich lass dich diesmal davonkommen, aber vergiss nicht, die nächste Probe zu suchen."

    # say L4092 pla
    old "Yeah, alright."
    new "Okay, klar."

    # say L4122 pla
    old "Oh, Barbie, hi!"
    new "Oh, Barbie, hallo!"

    # say L4125 pla
    old "Hi, how are you?"
    new "Hi, wie geht's dir?"

    # say L4126 pla
    old "Is everything alright?"
    new "Alles in Ordnung?"

    # say L4132 pla
    old "Uhmm... Are you alright?"
    new "Hmm... Geht es dir gut?"

    # say L4134 pla
    old "Did you go to the doctor? Is everything okay?"
    new "Bist du beim Arzt gewesen? Ist alles in Ordnung?"

    # say L4137 pla
    old "Are you sure?"
    new "Bist du dir sicher?"

    # say L4141 pla
    old "Uhm... Sure, I don't see why not."
    new "Äh... Klar, ich sehe keinen Grund, warum nicht."

    # say L4142 pla
    old "Let's go to my bedroom and we'll talk there."
    new "Lass uns in mein Schlafzimmer gehen und dort reden."

    # say L4148 pla
    old "Alright, do you want to tell me what's going on?"
    new "Okay, willst du mir sagen, was los ist?"

    # say L4149 pla
    old "Because I can tell that something's not right."
    new "Weil ich merke, dass was nicht stimmt."

    # say L4158 pla
    old "So what's the problem?"
    new "Was ist das Problem?"

    # say L4162 pla
    old "Fatigue? Like you're tired?"
    new "Ermüdung? Als ob du müde bist?"

    # say L4168 pla
    old "How do you know that?"
    new "Wie kommst du darauf?"

    # say L4177 pla
    old "Hot?"
    new "Heiß?"

    # say L4181 pla
    old "Oh! I- I see."
    new "Oh! I- Ich sehe."

    # say L4187 bri
    old "This is it [pla]! This is what I told you about!"
    new "Das ist es [pla]! Das ist, was ich dir erzählt habe!"

    # say L4188 bri
    old "This fatigue she's talking about is her body manifesting its need for magic."
    new "Diese Erschöpfung, von der sie spricht, ist ihr Körper, der seine Magiebrauchbarkeit zeigt."

    # say L4189 bri
    old "And the feeling of being {i}'horny'{/i} is her body telling her what she has to do to solve it."
    new "Und das Gefühl, {i}'geil'{/i} zu sein, ist ihr Körper, der ihr sagt, was sie tun muss, um es zu lösen."

    # say L4190 bri
    old "I wasn't expecting it to go this way, since the spell was canceled and everything."
    new "Ich habe das nicht erwartet, nachdem der Zauber aufgehoben wurde und so."

    # say L4191 bri
    old "But what you have to do now is have sex with her so that she can feed off your magic!"
    new "Aber was du jetzt tun musst, ist mit ihr zu schlafen, damit sie sich von deiner Magie ernähren kann!"

    # say L4195 pla
    old "W- what? N- no, of course not."
    new "W-was? N-nein, auf keinen Fall."

    # say L4197 pla
    old "Why would I think that there's anything weird about it?"
    new "Warum sollte ich denken, dass daran etwas Seltsames wäre?"

    # say L4199 pla
    old "I think that's very normal."
    new "Ich denke, das ist total normal."

    # say L4200 pla
    old "After all, you're pregnant, I think it's pretty normal that you would have those feelings."
    new "Schließlich bist du schwanger, ich finde es ziemlich normal, dass du so empfindest."

    # say L4203 pla
    old "What's wrong?"
    new "Was ist los?"

    # say L4213 pla
    old "Ohh, come on, what are you talking about?"
    new "Ohh, komm schon, worüber redest du da?"

    # say L4215 pla
    old "Yeah, it's true that you don't look like you usually do."
    new "Ja, es stimmt, dass du nicht so aussiehst wie sonst."

    # say L4216 pla
    old "But that doesn't mean you look bad in any way."
    new "Aber das heißt nicht, dass du schlecht aussiehst."

    # say L4218 pla
    old "I mean, you look just as sexy as you always have."
    new "Ich meine, du siehst genauso sexy aus wie immer."

    # say L4221 pla
    old "Of course I would!"
    new "Natürlich würde ich das!"

    # say L4222 pla
    old "I'm surprised that you even feel like you'd have to ask me."
    new "Ich bin überrascht, dass du überhaupt das Gefühl hast, mich danach fragen zu müssen."

    # say L4223 pla
    old "You look just as beautiful as you always have."
    new "Du siehst genauso schön aus wie immer."

    # say L4224 pla
    old "And I'll be more than happy to help you feel better."
    new "Und ich werde mich freuen, dir dabei zu helfen, dich besser zu fühlen."

    # say L4229 pla
    old "Come on, don't say that."
    new "Komm schon, sag das nicht."

    # say L4230 pla
    old "You're just as beautiful as always."
    new "Du bist genauso schön wie immer."

    # say L4231 pla
    old "Let me show you."
    new "Lass mich es dir zeigen."

    # say L4257 pla
    old "I'm glad to be able to help you."
    new "Ich freue mich, dir helfen zu können."

    # say L4258 pla
    old "After all, you didn't get into this situation by yourself."
    new "Schließlich bist du nicht allein in diese Situation geraten."

    # say L4259 pla
    old "I figure this is the least that I can do."
    new "Ich denke, das ist das Mindeste, was ich tun kann."

    # say L4260 pla
    old "I'm glad it actually works."
    new "Ich bin froh, dass es tatsächlich funktioniert."

    # say L4267 pla
    old "Sure, I'll be seeing you later."
    new "Klar, ich seh dich später."

    # say L4274 bri
    old "Well done [pla]!"
    new "Gut gemacht [pla]!"

    # say L4275 bri
    old "With what you just did I'm sure that she'll be alright."
    new "Mit dem, was du gerade gemacht hast, bin ich mir sicher, dass es ihr gut gehen wird."

    # say L4277 pla
    old "Hmm, I guess that if she's going to be alright with just that, then that's fine."
    new "Hmm, wenn sie damit schon zufrieden ist, dann ist das in Ordnung."

    # say L4278 bri
    old "She will be. Don't worry, I'm sure that that's more than enough."
    new "Sie wird. Mach dir keine Sorgen, ich bin sicher, das war mehr als genug."

    # say L4279 bri
    old "Which is great, because now you  can focus on what's next."
    new "Das ist toll, denn jetzt kannst du dich auf den nächsten Schritt konzentrieren."

    # say L4281 pla
    old "However, this time I'll choose. We were lucky this time, but really 'impregnating' someone is not easy at all..."
    new "Dieses Mal werde ich die Wahl treffen. Wir hatten Glück, aber wirklich jemanden zu 'befruchten' ist gar nicht so einfach..."

    # say L4283 bri
    old "Alright... But you can't take too long; we need to keep incubating more magical power for the portal..."
    new "Okay... Aber du darfst nicht zu lange brauchen; wir müssen mehr magische Kraft für das Portal aufbauen."

    # say L4285 bri
    old "Anyway, I'm gonna rest, I spend too much magic power with Barbie..."
    new "Na ja, ich mach dann eine Pause, ich hab zu viel Magie bei Barbie verbraucht..."

    # say L4286 pla
    old "Ok, see you later."
    new "Ok, bis später."


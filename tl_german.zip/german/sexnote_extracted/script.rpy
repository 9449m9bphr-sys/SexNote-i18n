# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/System/script.rpy
translate german strings:

    # say L562 ladGuide
    old "Go to Sleep."
    new "Schlaf gut."

    # say L563 linGuide
    old "Go to sleep."
    new "Schlaf jetzt."

    # say L565 belGuide
    old "Go to school in the morning."
    new "Morgens zur Schule gehen"

    # say L566 barGuide
    old "Keep progressing with Brixxida."
    new "Mit Brixxida weitermachen"

    # say L568 bilGuide
    old "Keep progressing with other characters."
    new "Mit den anderen Charakteren weitermachen."

    # say L584 mom2Rel
    old "step mom"
    new "Stiefmutter"

    # say L700 sisGuide
    old "Meet her in the hallway."
    new "Sie im Flur treffen."

    # say L701 johGuide
    old "Keep progressing with Hinn."
    new "Mit Hinn weitermachen."

    # say L703 lydGuide
    old "Go to her house."
    new "Zu ihrem Haus gehen."


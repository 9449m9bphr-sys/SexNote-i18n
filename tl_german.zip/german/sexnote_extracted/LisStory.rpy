# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

# Source: code/Story/LisStory.rpy
translate german strings:

    # say L9 mo2
    old "No! You are my sister, but it doesn't mean I will give you money for every stupid scheme you can think of. I have my own responsibilities..."
    new "Nein! Du bist meine Schwester, aber das bedeutet nicht, dass ich dir für jedes dumme Vorhaben, das dir einfällt, Geld gebe. Ich habe meine eigenen Verantwortlichkeiten..."

    # say L10 lis
    old "But, I'm not asking you to give me money. Just lend me some or invest in my plan. This time what I have planned is sure to work..."
    new "Aber, ich bitte dich nicht um Geld. Nur leih mir etwas oder investiere in meinen Plan. Diesmal wird es bestimmt funktionieren..."

    # say L11 mo2
    old "Really, Lisa? Do you think that a simple yoga academy is a million-dollar venture? "
    new "Wirklich, Lisa? Glaubst du ernsthaft, dass eine einfache Yogaschule ein Millionengeschäft ist?"

    # say L12 lis
    old "Well, maybe not a million, but I know it will help me pay off the debts I owe you."
    new "Vielleicht nicht eine Million, aber ich weiß, dass es mir helfen wird, die Schulden bei dir abzuzahlen."

    # say L13 mo2
    old "You know what? I already gave too much of you. Get that money from some other sucker."
    new "Du weißt was? Ich hab dir schon viel zu viel gegeben. Hol dir das Geld von einem anderen Idioten."

    # say L17 lis
    old "But... but..."
    new "Aber... aber..."

    # say L21 lis
    old "Oh... Hi there, [pla]. I'm sorry you had to hear all that... My sister is kind of a bitch sometimes..."
    new "Oh... Hallo, [pla]. Tut mir leid, dass du das mitbekommen hast... Meine Schwester ist manchmal ziemlich eine Zicke..."

    # say L22 pla
    old "Oh yeah... I know what you mean..."
    new "Oh ja... Ich verstehe dich total..."

    # say L23 lis
    old "Well, that won't stop me! I'm going to build my own yoga academy, with or without her help..."
    new "Na, das wird mich nicht aufhalten! Ich werde meine eigene Yogaschule gründen, mit oder ohne ihre Hilfe..."

    # say L24 pla
    old "That seems like a good idea..."
    new "Das klingt wie eine gute Idee..."

    # say L25 lis
    old "Thank you, [pla]! You are always a charm... Well, I have to go. If you need me, you can look for me at my house..."
    new "Danke, [pla]! Du bist immer ein Schatz... Also, ich muss los. Wenn du mich brauchst, findest du mich bei mir zu Hause..."

    # say L26 pla
    old "Ok [lis]! See you later..."
    new "Ok [lis]! Bis später..."

    # say L42 lis
    old "Hey, [pla], how are you doing?"
    new "Hey, [pla], wie geht's dir?"

    # say L43 pla
    old "Hi, I am fine."
    new "Hi, ich bin gut."

    # say L44 pla
    old "You sure? I mean... I hope you're better."
    new "Bist du dir sicher? Ich meine... ich hoffe, es geht dir besser."

    # say L45 lis
    old "Oh I see, you mean about me and my sister..."
    new "Oh, ich verstehe, du meinst mich und meine Schwester..."

    # say L46 pla
    old "Hmm... Yeah."
    new "Hmm... Ja."

    # say L47 lis
    old "You know my inner peace remains the same... I understand that she has her own business. I think that's the way the universe tells me I need to try by my own, because I know..."
    new "Du weißt, mein innerer Frieden bleibt unverändert... Ich verstehe, dass sie ihre eigenen Dinge zu tun hat. Ich denke, das ist der Weg, wie das Universum mir sagt, dass ich es selbst versuchen muss, weil ich weiß..."

    # say L48 lis
    old "I feel great things are coming, and I think this is the moment I can show the world what I am made of, and I know this is a dream today but it will soon be real."
    new "Ich spüre, dass großartige Dinge auf mich zukommen, und ich denke, es ist der Moment, der Welt zu zeigen, was in mir steckt. Ich weiß, dass es heute noch ein Traum ist, aber bald wird es Wirklichkeit."

    # say L49 lis
    old "If fate puts a dream in your heart is because it's meant to be."
    new "Wenn das Schicksal dir einen Traum ins Herz legt, dann ist es, damit er wahr wird."

    # say L52 lis
    old "It's ok, you should to learn a little more, why not learn meditation with me."
    new "Alles gut, du solltest noch ein bisschen mehr lernen, warum lernst du nicht Meditation mit mir."

    # say L53 lis
    old "You need to learn to find the perfect balance in your body and soul so you can be one with yourself along with the universe, to better feel and understand your purpose and of life itself."
    new "Du musst lernen, die perfekte Balance in deinem Körper und deiner Seele zu finden, damit du eins mit dir selbst und dem Universum werden kannst, um dein Leben und seinen Zweck besser zu fühlen und zu verstehen."

    # say L54 pla
    old "Hmm...  s- sure."
    new "Hmm... k-klar."

    # say L55 lis
    old "You know what, I will go today and check the options at the mall to see if I could run my own yoga academy from there, I will find the perfect place and fill out all the paperwork."
    new "Ich werde heute ins Einkaufszentrum gehen und die Möglichkeiten überprüfen, ob ich dort meine eigene Yogaschule betreiben kann. Ich werde den perfekten Ort finden und alle Papiere ausfüllen."

    # say L57 lis
    old "Yeah, but there is so much work to do, you know... The place, the rent, the equipment, the ambience, everything must flow with the same energy."
    new "Ja, aber da ist so viel zu tun, weißt du... Der Ort, die Miete, die Ausrüstung, die Atmosphäre, alles muss in der gleichen Energie harmonieren."

    # say L58 lis
    old "Once I get all the info, I will have an idea about the budget."
    new "Sobald ich alle Infos habe, weiß ich Bescheid über das Budget."

    # say L59 pla
    old "Hope you get all the info you need, good luck!"
    new "Hoffe, du kriegst alle Infos, die du brauchst, viel Glück!"

    # say L77 pla
    old "Hi, Lisa, how are you?"
    new "Hi, Lisa, wie geht's dir?"

    # say L78 lis
    old "Oh no [pla], I think I need to reconsider my entire project."
    new "Oh nein [pla], ich glaube, ich muss mein gesamtes Projekt überdenken."

    # say L80 lis
    old "Well, [pla], I went to the mall, had a hard time finding the manager, but think it was just fate trying to save me from that pain."
    new "Na ja, [pla], ich war im Einkaufszentrum, habe mich schwer getan, den Manager zu finden, aber ich denke, es war einfach Schicksal, das mich vor diesem Ärger bewahren wollte."

    # say L81 lis
    old "I mean the rent for just a very small place was huge, something really out of my league, the requirements to rent the place are quite stressful."
    new "Ich meine, die Miete für eine winzige Bude war gigantisch, total außerhalb meiner Liga, und die Anforderungen, um da einzuziehen, sind echt stressig."

    # say L82 lis
    old "I'm so frustrated, I- I need to think of a different project..."
    new "Ich bin so frustriert, ich- ich muss mir ein anderes Projekt überlegen..."

    # say L83 lis
    old "But the worst part of that day was when I discovered THERE WAS a yoga academy, as if that wasn't enough it was also really close to the place I was looking at..."
    new "Aber das Schlimmste an dem Tag war, als ich herausfand, dass es eine Yogaschule gibt, und die war auch noch ganz in der Nähe von der Wohnung, die ich mir angesehen habe..."

    # say L84 pla
    old "Wait what? So you will have to compete."
    new "Warte, was? Du musst also mit denen konkurrieren."

    # say L85 lis
    old "Well, that academy was bigger than what I was thinking, I think they have been there for a while because there was a lot of people, it was so amazing, the place was radiant and beautiful..."
    new "Na ja, die Akademie war größer, als ich gedacht hatte, und sie scheinen schon seit einer Weile da zu sein, weil es viele Leute gab. Der Ort war strahlend und wunderschön..."

    # say L87 lis
    old "Yeah, I immediately thought to myself I could be better than any of their instructors but clearly I can't compete with that company..."
    new "Ja, ich hab mir gleich gedacht, dass ich besser sein könnte als ihre Lehrer, aber offensichtlich kann ich da nicht mithalten..."

    # say L88 pla
    old "I understand..."
    new "Ich verstehe..."

    # say L89 lis
    old "Yeah, I think I need to be humble and to accept fate as it is..."
    new "Ja, ich denke, ich muss bescheiden sein und das Schicksal akzeptieren, wie es ist."

    # say L90 pla
    old "But... There has to be something you can do..."
    new "Aber... Da muss doch was sein, was du tun kannst."

    # say L91 lis
    old "What are my options? There's nothing I can do."
    new "Was sind meine Optionen? Da ist nichts, was ich tun kann."

    # say L92 pla
    old "I mean, you can check different places, not just the mall."
    new "Ich meine, du kannst andere Orte überprüfen, nicht nur das Einkaufszentrum."

    # say L93 lis
    old "Hmm I don't know, I just need time to focus on a different idea."
    new "Hmm, ich weiß nicht, ich brauche einfach Zeit, um mich auf eine andere Idee zu konzentrieren."

    # say L94 pla
    old "Sorry to hear you so frustrated, but you know what? You can count on me."
    new "Tut mir leid, dich so frustriert zu sehen, aber weißt du was? Du kannst dich auf mich verlassen."

    # say L95 lis
    old "Oh that's very sweet of you."
    new "Oh das ist sehr lieb von dir."

    # say L96 pla
    old "I know you can get a yoga academy like you want, we just need to look for alternatives."
    new "Ich weiß, dass du eine Yogaschule wie gewünscht bekommen kannst, wir müssen nur nach Alternativen suchen."

    # say L97 lis
    old "I'll think about it, thanks for being so supporting, I appreciate your time."
    new "Ich denke drüber nach, danke, dass du so supporting bist, ich schätze deine Unterstützung."

    # say L98 pla
    old "It's ok, I just hope I can help."
    new "Alles gut, ich hoffe nur, ich kann helfen."

    # say L116 pla
    old "Hi, how-"
    new "Hi, wie-"

    # say L117 lis
    old "Hey! I needed to talk to you, I have great news!"
    new "Hey! Ich musste mit dir reden, ich hab tolle Neuigkeiten!"

    # say L118 pla
    old "Wow, I can see you're feeling better now..."
    new "Wow, ich sehe, dass es dir jetzt besser geht..."

    # say L120 lis
    old "I really am, last time we talked I was very down, but I started my daily meditation practice. While breathing I discovered some light within the darkness..."
    new "Ich bin wirklich, beim letzten Mal war ich total niedergeschlagen, aber ich habe mit der täglichen Meditation angefangen. Beim Atmen habe ich ein bisschen Licht in der Dunkelheit entdeckt..."

    # say L122 lis
    old "While I was doing this yoga position to relax, I thought I was doing something wrong, then I corrected the position, I still wasn't sure what exactly was wrong..."
    new "Während ich diese Yogaposition gemacht habe, um mich zu entspannen, dachte ich, ich mache etwas falsch, dann habe ich die Position korrigiert, war mir aber immer noch nicht sicher, was genau nicht stimmte..."

    # say L123 lis
    old "So I slightly moved my arms and legs to get the perfect position, I know it sounds a bit silly but, when I corrected the position, it felt like my body was in a different place..."
    new "Dann habe ich meine Arme und Beine ein wenig bewegt, um die perfekte Position zu finden. Ich weiß, es klingt ein bisschen albern, aber als ich die Position korrigiert habe, fühlte sich mein Körper plötzlich an einem anderen Ort..."

    # say L125 lis
    old "I mean, sometimes meditation is not about knowing the Asanas but how you connect in the moment and the environment..."
    new "Ich meine, manchmal geht es beim Meditieren nicht darum, die Asanas zu kennen, sondern wie du im Moment und mit der Umgebung verbunden bist..."

    # say L126 lis
    old "It's not about how you follow the rules but how you connect your body and soul through exercise, do you understand?"
    new "Es geht nicht darum, die Regeln zu befolgen, sondern wie du deinen Körper und deine Seele durch die Übung verbindest, verstehst du?"

    # say L127 pla
    old "Hmm... I think so."
    new "Hmm... Ich denke schon."

    # say L128 lis
    old "That was my reflection, I'm not a regular Yoga instructor, I mean this academy at the mall can have 10 teachers but I am no a regular teacher, yoga and meditation is part of my life..."
    new "Das war meine Reflexion, ich bin keine normale Yogalehrerin, ich meine, in diesem Einkaufszentrum können 10 Lehrer sein, aber ich bin keine normale Lehrerin, Yoga und Meditation sind Teil meines Lebens..."

    # say L130 lis
    old "For me, yoga is not just about the equipment or space, I don't need that so I can perform a good pranayama, those are things for a comfortable service experience."
    new "Für mich ist Yoga nicht nur eine Frage von Ausrüstung oder Raum, ich brauche das nicht, um eine gute Pranayama durchzuführen. Das sind Dinge für ein komfortables Service-Erlebnis."

    # say L131 lis
    old "My personal experience can't be beat because it's actually richer than any other yoga experience, I'm not selling a product! I'm sharing my own experience..."
    new "Meine persönliche Erfahrung ist unerreicht, weil sie reicher ist als jeder andere Yogakurs. Ich verkaufe kein Produkt, ich teile meine Erfahrung!"

    # say L132 pla
    old "Very interesting."
    new "Sehr interessant."

    # say L133 lis
    old "And you were right..."
    new "Und du hattest recht..."

    # say L135 lis
    old "Yes! About the mall, my business can be run in a totally different place... In fact... I think... Since I don't need any special place, I can just have it at my own HOUSE."
    new "Ja! Was das Einkaufszentrum angeht, kann ich mein Geschäft an einem ganz anderen Ort betreiben... Tatsächlich... Ich denke... Da ich keinen besonderen Ort brauche, kann ich es einfach bei mir zu HAUSE machen."

    # say L136 pla
    old "That would be very convenient."
    new "Das wäre sehr praktisch."

    # say L137 lis
    old "Here, my customers can experience a very close yoga training, focus on the intimate learning, no distractions, no rules, only the yoga experience I provide."
    new "Hier können meine Kunden eine sehr persönliche Yogastunde erleben, sich ganz auf das intime Lernen konzentrieren, ohne Ablenkungen, ohne Regeln, nur die Yogaterapie, die ich anbiete."

    # say L139 lis
    old "Well, I will need to check how to obtain the necessary business permits and licenses."
    new "Na klar, ich muss noch überprüfen, wie ich die notwendigen Genehmigungen und Lizenzen bekomme."

    # say L140 pla
    old "I am sure that won't be any trouble."
    new "Ich bin sicher, das wird kein Problem sein."

    # say L141 lis
    old "Thank you for listening to me and giving me the support, I needed I appreciate it."
    new "Danke, dass du mir zuhörst und mich unterstützt hast, das bedeutet mir viel."

    # say L142 pla
    old "I actually did nothi-"
    new "Ich habe eigentlich nichts-"

    # say L143 lis
    old "Oh, by the way, let me show you some ideas I have for the yoga room."
    new "Oh, übrigens, lass mich dir ein paar Ideen für den Yogaraum zeigen."

    # say L145 lis
    old "Please come, I'm sure you are going to like it too, I wasn't aware my house was so perfect for this."
    new "Komm bitte, ich bin sicher, dir wird es auch gefallen, ich war mir nicht bewusst, wie perfekt mein Haus dafür geeignet ist."

    # say L146 pla
    old "Is it?"
    new "Ist es?"

    # say L147 lis
    old "Yes, the second floor is big and a good area I can take advantage of."
    new "Ja, die zweite Etage ist groß und ein guter Bereich, den ich ausnutzen kann."

    # say L155 pla
    old "Hmm, this room is pretty big."
    new "Hmm, dieses Zimmer ist ziemlich groß."

    # say L157 lis
    old "You see it? It is so private, very intimate, and full of silence, this place is perfect... I did not realize it was that big until I took out all the stuff... What do you think?"
    new "Siehst du es? Es ist so privat, sehr intim und voller Stille. Dieser Ort ist perfekt... Ich habe erst gemerkt, wie groß es ist, als ich alles rausgeräumt habe... Was denkst du?"

    # say L158 pla
    old "It is very nice and peaceful."
    new "Es ist sehr schön und ruhig."

    # say L159 lis
    old "Actually, it's going to be better, you know music, fragrances, all that it takes to meditate and find your inner peace."
    new "Eigentlich wird es noch besser, du weißt schon, Musik, Duftstoffe, alles, was man braucht, um zu meditieren und innere Ruhe zu finden."

    # say L160 pla
    old "Wow, you have your business almost running. If you need something, you can count on me anytime."
    new "Wow, du hast dein Geschäft fast am Laufen. Wenn du was brauchst, kannst du dich jederzeit auf mich verlassen."

    # say L161 lis
    old "You're really sweet... I think I am ok-"
    new "Du bist echt lieb... Ich denke, ich komme klar-"

    # say L162 lis
    old "Wait, you know what?..."
    new "Warte, weißt du was?..."

    # say L163 lis
    old "I was wondering yesterday, how a customer would feel, you know the place... The energy... I just want to have an idea how they could feel."
    new "Ich habe mich gestern gefragt, wie ein Kunde sich fühlen würde, du weißt schon, der Ort... Die Energie... Ich möchte einfach ein Gefühl dafür kriegen, wie sie sich fühlen könnten."

    # say L164 lis
    old "Would you like to help me? You just need to be like my ‘instructor' I will tell you step by step what to do... What do you think?"
    new "Möchtest du mir helfen? Du musst nur so mein „Instruktor“ sein, ich sage dir Schritt für Schritt, was zu tun ist... Was denkst du?"

    # say L165 pla
    old "Hmm, I can help you sure..."
    new "Hmm, ich kann dir sicher helfen..."

    # say L166 lis
    old "Thank you, I will walk you through every single step so you can learn too."
    new "Danke, ich werde dir jeden einzelnen Schritt zeigen, damit du auch lernen kannst."

    # say L167 lis
    old "Let's do a couple of regular exercises."
    new "Lass uns ein paar normale Übungen machen."

    # say L172 lis
    old "First we will try something casual, this position is called ‘Utkatasana', it's quite focused on breathing and your legs so since you will be the trainer..."
    new "Zuerst probieren wir etwas Leichtes aus, diese Position heißt 'Utkatasana', sie konzentriert sich sehr aufs Atmen und die Beine, da du der Trainer bist..."

    # say L173 lis
    old "I will do the position so please follow me, don't do the position with me but control the position from the back, helping me to keep my balance, you got it?"
    new "Ich werde die Position machen, also bitte folge mir, mach die Position nicht mit mir, sondern kontrolliere sie von hinten und hilf mir, das Gleichgewicht zu halten, klar?"

    # say L176 lis
    old "Ok... Here we go, please put your hands on my waist."
    new "Ok... Los geht's, bitte leg deine Hände auf meine Taille."

    # say L183 lis
    old "Like I said follow my movement, I will go down..."
    new "Wie ich gesagt habe, folge meiner Bewegung, ich werde runtergehen..."

    # say L189 pla
    old "Sure..."
    new "Klar..."

    # say L192 lis
    old "You're keeping cool good, let's go up... Perfect."
    new "Du bleibst cool, das ist gut, lass uns hochgehen... Perfekt."

    # say L199 lis
    old "Well, I can feel it positive, I can breathe perfectly, the light is quite good, do you feel comfortable?"
    new "Ich spüre es positiv, ich kann perfekt atmen, das Licht ist ziemlich gut, fühlst du dich wohl?"

    # say L200 pla
    old "Yes, I feel nice."
    new "Ja, ich fühle mich gut."

    # say L201 lis
    old "Well, that was very productive, I feel relaxed, don't forget to keep breathing."
    new "Na, das war sehr ergiebig, ich fühle mich entspannt, vergiss nicht weiterzuatmen."

    # say L202 pla
    old "Sure, I'm focused."
    new "Klar, ich bin konzentriert."

    # say L203 lis
    old "That's perfect, let's try a different pose..."
    new "Das ist perfekt, lass uns eine andere Position ausprobieren..."

    # say L210 lis
    old "Next one will be totally different it's on the floor, its name is ‘Upward Facing Dog', for this position your help is very important..."
    new "Die nächste ist total anders, sie ist auf dem Boden, sie heißt 'Upward Facing Dog'. Für diese Position ist deine Hilfe sehr wichtig..."

    # say L211 lis
    old "Because you will help me with the effort applied to my back, so I'll lie down looking up, if you want to be more comfortable, please get on your needs."
    new "Weil du mir bei der Anstrengung auf meinem Rücken helfen wirst, ich lege mich hin und schaue nach oben, wenn du es bequemer hast, kannst du dich bitte auf die Knie stellen."

    # say L218 lis
    old "I really like this position, I can feel a lot of energies running through me."
    new "Mir gefällt diese Position wirklich, ich spüre so viel Energie in mir."

    # say L219 lis
    old "Ahh it's so relieving, please push a bit towards my shoulders."
    new "Ahh das tut so gut, drück bitte ein bisschen Richtung Schultern."

    # say L232 lis
    old "Oh yeah, like that, this is very relaxing for me."
    new "Oh ja, genau so, das ist sehr entspannend für mich."

    # say L233 pla
    old "(She looks very enticing... I need to focus.)"
    new "(Sie sieht so verlockend aus... Ich muss mich konzentrieren.)"

    # say L241 pla
    old "(Oh shit... I'm getting hard... Oh, please not now...)"
    new "Oh Scheiße... Ich werde hart... Oh, bitte nicht jetzt..."

    # say L248 lis
    old "You are doing amazing."
    new "Du machst das fantastisch."

    # say L250 lis
    old "I think this place is incredible to do this... I can't wait to bring the candles, the music... It'll be so perfect!"
    new "Ich finde, dieser Ort ist unglaublich dafür... Ich kann es kaum erwarten, die Kerzen, die Musik... Es wird perfekt sein!"

    # say L251 lis
    old "Alright, we need to continue... Listen, the next position is amazing, it's one of the most interesting and very easy to learn."
    new "Okay, wir müssen weitermachen... Hör zu, die nächste Position ist unglaublich, eine der interessantesten und sehr einfach zu lernen."

    # say L257 lis
    old "This asana sequence is called ‘Extended Puppy Pose', it's really relaxing, so please pay attention..."
    new "Diese Asanareihe heißt 'Verlängerte Hundepose', sie ist wirklich entspannend, also bitte konzentrier dich..."

    # say L259 pla
    old "W- what do you need me to do?"
    new "W-was soll ich tun?"

    # say L260 pla
    old "(I need to control myself or she will notice my hardon.)"
    new "Ich muss mich zusammenreißen, sonst merkt sie noch, wie hart ich bin."

    # say L261 lis
    old "Well... For this position the hips and legs are very important, so I will need you to push them, so I can stretch my back to the fullest..."
    new "Na ja... Für diese Position sind die Hüften und Beine sehr wichtig, also werde ich dich bitten, sie zu stützen, damit ich meinen Rücken optimal dehnen kann."

    # say L262 lis
    old "Please hold my waist behind me and help me keep my balance."
    new "Bitte halte meine Taille von hinten und hilf mir, das Gleichgewicht zu halten."

    # say L264 pla
    old "(I hope she doesn't notice it.."
    new "Ich hoffe, sie bemerkt es nicht."

    # say L271 lis
    old "Please try to rest your waist with mine, control your breathing too."
    new "Versuch, deine Taille an meine zu legen und beherrsche auch deinen Atem."

    # say L281 lis
    old "I need to feel you firmly so I can rest my back and relax my body."
    new "Ich muss dich fest spüren, damit ich meinen Rücken abstützen und mich entspannen kann."

    # say L282 pla
    old "(Oh It feels so delicious.)"
    new "Oh, das fühlt sich so köstlich an."

    # say L284 lis
    old "Can push me harder, that way both of us will be able to the do exercise more intensely."
    new "Kannst du mich fester drücken, dann können wir beide das Training intensiver machen."

    # say L292 lis
    old "Yes, just like that."
    new "Ja, genau so."

    # say L294 lis
    old "That was perfect... I think we are done!"
    new "Das war perfekt... Ich denke, wir sind fertig!"

    # say L297 lis
    old "I like your enthusiasm but I think you can stop now."
    new "Ich mag dein Enthusiasmus, aber ich denke, du kannst jetzt aufhören."

    # say L303 pla
    old "OH!? Yes, I am sorry, I was... I... Was quite focused on the position."
    new "OH!? Ja, es tut mir leid, ich war... ich... War ziemlich konzentriert auf die Position."

    # say L314 lis
    old "Oh that's fantastic, I'm sorry to interrupt you."
    new "Oh das ist fantastisch, es tut mir leid, dich zu unterbrechen."

    # say L315 pla
    old "(Phew, thank god, she didn't notice.)"
    new "Phew, Gott sei Dank, sie hat es nicht bemerkt."

    # say L316 pla
    old "Oh no, it's ok no worries."
    new "Oh nein, ist schon okay, mach dir keine Sorgen."

    # say L317 lis
    old "Amazing, you did a wonderful job, I appreciate your commitment."
    new "Wow, du hast fantastische Arbeit geleistet, ich schätze deine Engagement."

    # say L318 pla
    old "No problem..."
    new "Kein Problem..."

    # say L319 lis
    old "I'm very surprised how our chakras get together so well... I am sure that is going to be the feeling I have with my customers."
    new "Ich bin sehr überrascht, wie gut unsere Chakras zusammenpassen... Ich bin sicher, das wird auch das Gefühl sein, das ich bei meinen Kunden habe."

    # say L320 lis
    old "I'll let you rest, thank you so much for your help, I will keep meditating a little longer."
    new "Ich lass dich jetzt ausruhen, danke dir sehr für deine Hilfe, ich werde noch ein bisschen länger meditieren."

    # say L321 lis
    old "If you want to learn more, I could give you a few more lessons."
    new "Wenn du mehr lernen möchtest, könnte ich dir noch ein paar Unterrichtsstunden geben."

    # say L322 pla
    old "... Alright... I'm gonna leave you, so you can practice more."
    new "Okay... Ich lass dich jetzt allein, damit du weiter üben kannst."

    # say L323 lis
    old "Thank you honey, see you later."
    new "Danke Schatz, bis später."

    # say L324 pla
    old "Have a good one."
    new "Alles Gute, Schatz. Bis später."

    # say L328 pla
    old "(That was close... I think she didn't realize...)"
    new "Das war knapp... Ich glaube, sie hat es nicht gemerkt."

    # say L348 pla
    old "Oh, hi Lisa, what a surprise! Did you come to talk with [mo2]?"
    new "Oh, hallo Lisa, was für eine Überraschung! Bist du gekommen, um mit [mo2] zu reden?"

    # say L349 lis
    old "Oh no, don't worry, I am fine, I just came because I... Wanted to talk to you."
    new "Oh nein, mach dir keine Sorgen, mir geht's gut, ich bin nur gekommen, weil ich... mit dir reden wollte."

    # say L350 pla
    old "With me? Ok..."
    new "Mit mir? Okay..."

    # say L352 lis
    old "I have already had some customers; they are really happy with how we do things."
    new "Ich habe schon ein paar Kunden gehabt, die sind echt zufrieden mit dem, wie wir das machen."

    # say L353 pla
    old "Oh... That's amazing."
    new "Oh... Das ist fantastisch."

    # say L354 lis
    old "Yes, but this is just the beginning, better things are coming."
    new "Ja, aber das ist erst der Anfang, noch Besseres kommt."

    # say L355 pla
    old "I am glad that you are very positive."
    new "Ich freue mich, dass du so positiv bist."

    # say L356 lis
    old "I am just thankful for everything the universe is preparing for me."
    new "Ich bin einfach dankbar für alles, was das Universum für mich bereithält."

    # say L357 lis
    old "Actually, I need to ask you something, I don't want to do this but you're the one who would understand what I need."
    new "Eigentlich muss ich dich was fragen, ich will das nicht machen, aber du bist der Einzige, der verstehen würde, was ich brauche."

    # say L358 pla
    old "Hmm... What is this about?"
    new "Hmm... Worum geht's?"

    # say L359 lis
    old "Like I said the business is taking shape, I already have some customers, however I am very busy lately with paperwork to get the final license and all of that... You know..."
    new "Wie ich schon gesagt habe, das Geschäft nimmt Form an, ich habe schon einige Kunden, aber ich bin momentan ziemlich beschäftigt mit dem Papierkram für die endgültige Lizenz und so... Du weißt schon..."

    # say L360 lis
    old "The thing is I have a new customer in the afternoon coming, she is very very enthusiastic and is quite interested on the yoga program."
    new "Das Ding ist, ich habe neuerdings eine Kundin am Nachmittag, die ist total begeistert und sehr interessiert an dem Yogaprogramm."

    # say L362 lis
    old "Yeah, she paid for the entire course and I'm already planning her sessions."
    new "Ja, sie hat für den ganzen Kurs bezahlt und ich plane ihre Sitzungen schon."

    # say L363 lis
    old "However the time frame she said she is available is exactly the same time I have a very important appointment..."
    new "Das Problem ist, der Zeitrahmen, den sie angegeben hat, passt genau in die Zeit, in der ich ein sehr wichtiges Treffen habe..."

    # say L364 lis
    old "It's an interview to verify the information to approve the business. I already have all the documentation needed to legally open it..."
    new "Es ist ein Vorstellungsgespräch, um die Informationen zu überprüfen und das Geschäft zu genehmigen. Ich habe schon alle erforderlichen Unterlagen, um es rechtlich zu eröffnen..."

    # say L365 lis
    old "But this is a temporary one, this interview  gives me the approval so... I do need your help now... If you can cover me, so I can attend it."
    new "Aber das ist nur vorübergehend, dieses Gespräch gibt mir die Genehmigung, also... Ich brauche jetzt deine Hilfe... Wenn du mich abdecken kannst, damit ich hingehen kann."

    # say L366 pla
    old "Well... I think I can... But-"
    new "Na ja... ich denke schon... Aber-"

    # say L367 lis
    old "Amazing! that is fantastic. The entire universe is making it possible once again, did you know you are being an instrument of the universe?"
    new "Das ist fantastisch! Das Universum macht es wieder möglich, wusstest du, dass du ein Instrument des Universums bist?"

    # say L368 pla
    old "M- me... ?"
    new "M- mir...?"

    # say L369 lis
    old "Of course! I am very grateful... You cannot not imagine how important this is for me. You only need to help me with this session..."
    new "Natürlich! Ich bin sehr dankbar... Du kannst dir gar nicht vorstellen, wie wichtig das für mich ist. Du musst mir nur bei dieser Sitzung helfen..."

    # say L370 lis
    old "Since you have already done the basic yoga training with me you are the only one that can cover me, it's going to be the same routine."
    new "Da du schon die Grundausbildung im Yoga mit mir gemacht hast, bist du der Einzige, der mich vertreten kann. Es wird das gleiche Programm sein wie beim letzten Mal."

    # say L371 lis
    old "I know you are very intuitive and can do the session like we did before, I already checked with the customer and she is ok with that."
    new "Ich weiß, dass du sehr intuitiv bist und die Sitzung wie beim letzten Mal durchführen kannst, ich habe mich schon mit der Kundin abgestimmt und sie hat nichts dagegen."

    # say L373 lis
    old "Please reach me at home later, I am very sorry we won't have enough time to plan it but I am sure you will do great."
    new "Bitte ruf mich später zu Hause an, es tut mir sehr leid, wir haben nicht genug Zeit, es zu planen, aber ich bin sicher, du wirst großartig machen."

    # say L374 pla
    old "Hmm ok, I'll be there on time."
    new "Hmm okay, ich werde pünktlich da sein."

    # say L375 lis
    old "Thank you so much... See you then."
    new "Danke schön... Bis dann."

    # say L376 pla
    old "No problem, bye."
    new "Kein Problem, tschüss."

    # say L393 pla
    old "(Oh my god, is Anastasia, What is she doing here.)"
    new "Oh mein Gott, ist das Anastasia, was macht sie hier."

    # say L395 lis
    old "Oh, hey [pla]! thank so much for coming."
    new "Oh, hallo [pla]! Danke schön, dass du gekommen bist."

    # say L398 lis
    old "Oh, I am sorry, let me introduce you guys properly... [pla], this is Anastasia... Anastasia, this is  [pla]."
    new "Oh, entschuldigt, lasst mich euch richtig vorstellen... [pla], das ist Anastasia... Anastasia, das ist [pla]."

    # say L399 ana
    old "Thank you Lisa, It's nice to see you again [pla]!"
    new "Danke Lisa, schön dich wiederzusehen [pla]!"

    # say L400 pla
    old "G- good to see you too."
    new "Gut dich wiederzusehen."

    # say L402 lis
    old "Oh... So do you guys already know each other?"
    new "Oh... Kennt ihr euch schon?"

    # say L403 ana
    old "Hehehe, Yes, we know each other pretty well, right [pla]?"
    new "Hehehe, ja, wir kennen uns ziemlich gut, oder [pla]?"

    # say L405 lis
    old "Oh really? Please tell me... Once you guys arrived I just felt like fate was planning this meeting."
    new "Oh wirklich? Erzähl mir mehr... Als ihr beiden gekommen seid, habe ich das Gefühl gehabt, als würde das Schicksal dieses Treffen planen."

    # say L406 pla
    old "Well, she has bought some products... From [sis]'s website."
    new "Na ja, sie hat ein paar Produkte... von [sis]' Website gekauft."

    # say L407 ana
    old "Yeah, I met him as the delivery guy, I was surprised by his manners and because he is very intelligent with pretty huge talent..."
    new "Ja, ich habe ihn als Lieferant getroffen, ich war überrascht von seinen Manieren und weil er sehr intelligent und mit ziemlich großem Talent ist..."

    # say L409 lis
    old "I am very glad to hear that you understand each other, I will try to be back as soon as possible, in the meantime [pla] will help you with the first session Anastasia."
    new "Ich freue mich sehr, dass ihr euch versteht. Ich werde versuchen, so schnell wie möglich zurück zu sein. In der Zwischenzeit wird [pla] dir bei der ersten Sitzung helfen, Anastasia."

    # say L410 ana
    old "Oh, that's very interesting, don't you think [pla]?"
    new "Oh, das finde ich sehr interessant, findest du nicht [pla]?"

    # say L412 pla
    old "Y- yes... Very interesting..."
    new "Y- ja... Sehr interessant..."

    # say L414 lis
    old "I‘ve got the feeling this session will be really nice. Well guys, please enjoy the session, I will be back as soon as possible."
    new "Ich habe das Gefühl, dass diese Sitzung wirklich schön wird. Also, Jungs, genießt die Sitzung, ich bin so schnell wie möglich wieder da."

    # say L415 ana
    old "Bye bye Lisa."
    new "Tschüss Lisa."

    # say L424 ana
    old "Finally we are alone. I am  very ready for the class."
    new "Endlich sind wir allein. Ich bin sehr bereit für die Stunde."

    # say L425 pla
    old "Well... Yes, I- I thank you for coming today, we did prepare a very great Yoga session for you."
    new "Na ja... Ja, ich danke dir, dass du heute gekommen bist, wir haben eine sehr tolle Yogastunde für dich vorbereitet."

    # say L426 ana
    old "Oh, I like that, I wasn't expecting to have a very handsome trainer, it's going to be really fun."
    new "Oh, das gefällt mir, ich habe nicht damit gerechnet, einen so gut aussehenden Trainer zu bekommen, das wird richtig Spaß machen."

    # say L428 pla
    old "Why don't we go to the yoga room where it's more comfortable for the session."
    new "Warum gehen wir nicht in den Yogaraum, wo es für die Sitzung gemütlicher ist."

    # say L437 pla
    old "This is going to be our yoga room, we hope you enjoy not only the lesson but also the finer details for this experience."
    new "Das wird unser Yogaraum, wir hoffen, dass dir nicht nur der Unterricht, sondern auch die Feinheiten dieser Erfahrung gefallen."

    # say L438 ana
    old "It's beautiful, smells very nice."
    new "Es ist wunderschön, riecht sehr angenehm."

    # say L439 pla
    old "Every detail has been thought out to make your experience better."
    new "Jede Einzelheit wurde bedacht, um dein Erlebnis zu verbessern."

    # say L440 ana
    old "You guys are doing it very well."
    new "Ihr macht das wirklich gut."

    # say L441 pla
    old "Now, let's start with the lesson, so you can get to relax a bit more."
    new "Dann fangen wir jetzt mit der Lektion an, damit du dich noch besser entspannen kannst."

    # say L447 pla
    old "Alright, for the first position I will be behind you to help you keep your body balanced, and that way we can do the exercise properly."
    new "Okay, für die erste Position werde ich hinter dir stehen, um dir beim Gleichgewicht zu helfen, dann können wir die Übung richtig machen."

    # say L448 ana
    old "That's perfect."
    new "Das ist perfekt."

    # say L449 pla
    old "We will start straight up and then we will go down keeping the straight position and correct breathing."
    new "Wir fangen direkt an und dann gehen wir runter, dabei die Position halten und richtig atmen."

    # say L460 pla
    old "Try to keep your thoughts focus on the exercise."
    new "Versuch dich auf die Übung zu konzentrieren."

    # say L461 pla
    old "(Her butt is really big, I need to think of something different. She's so hot...)"
    new "Ihre Hüfte ist wirklich groß, ich muss an was anderes denken. Sie ist so heiß..."

    # say L462 ana
    old "Am I doing it right?"
    new "Mache ich das richtig?"

    # say L463 pla
    old "Yes... Delicious."
    new "Ja... Lecker."

    # say L466 pla
    old "I- mean... Correct, yes, you are doing it correctly."
    new "Ich meine... Richtig, ja, du machst es richtig."

    # say L467 ana
    old "Oh, thank you."
    new "Oh, danke."

    # say L468 pla
    old "Do you feel relaxed?"
    new "Fühlst du dich entspannt?"

    # say L469 ana
    old "Yes, I like it."
    new "Ja, es gefällt mir."

    # say L470 pla
    old "It was good, we are going to stop now and continue with the following, did you like it?"
    new "Es war gut, wir werden jetzt aufhören und mit dem Nächsten weitermachen, hat dir das gefallen?"

    # say L471 ana
    old "It was nice."
    new "Es war schön."

    # say L477 pla
    old "I hope you feel calmer now... So, our next position will help with the balance of our energies..."
    new "Ich hoffe, du fühlst dich jetzt ruhiger... Also, unsere nächste Position wird uns dabei helfen, die Balance unserer Energien zu finden..."

    # say L478 pla
    old "I'll need you to lie down on your stomach, first we will stretch your legs and back, raising your head up, later you will let it down to breathe again."
    new "Du musst dich auf den Bauch legen, zuerst dehnen wir deine Beine und deinen Rücken, indem du den Kopf anhebst, später lässt du ihn wieder sinken, um wieder zu Atem zu kommen."

    # say L480 pla
    old "This position is quite demanding, I will be there to make sure you can focus more and make the most out of it."
    new "Diese Position ist ziemlich anspruchsvoll, ich werde da sein, um dir zu helfen, dich besser zu konzentrieren und das Beste daraus zu machen."

    # say L481 ana
    old "Sounds good!"
    new "Klingt gut!"

    # say L487 pla
    old "First relax and breathe while lying down in that position."
    new "Erst mal entspannen und tief durchatmen, während du in dieser Position liegst."

    # say L488 ana
    old "Hmm it feels good."
    new "Hmm, das fühlt sich gut an."

    # say L489 pla
    old "Now you are going to stretch your arms and I'm going to press your shoulders back so you can tense your muscles, and tilt your head back."
    new "Jetzt streckst du die Arme aus und ich drücke deine Schultern zurück, damit du die Muskeln anspannen kannst und den Kopf nach hinten neigst."

    # say L503 pla
    old "(Wow... I can see her boobs!)"
    new "Wow... ich sehe ihre Titten!"

    # say L504 pla
    old "(Oh no... I am getting a hardon again. Shit... I should act normal so she doesn't notice.)"
    new "Oh nein... Ich kriege schon wieder einen Steifen. Scheiße... Ich muss normal bleiben, damit sie es nicht merkt."

    # say L512 ana
    old "So... Like this?"
    new "So... Wie ist es jetzt?"

    # say L515 ana
    old "Are you getting distracted?"
    new "Du bist abgelenkt, oder?"

    # say L517 pla
    old "Oh no... I am ok... Let's breath a bit more."
    new "Oh nein... Mir geht's gut... Lass uns noch ein bisschen durchatmen."

    # say L524 pla
    old "(Dammit she noticed it.)"
    new "Verdammt, sie hat es bemerkt."

    # say L525 ana
    old "I thought you were a bit distracted but now I know you brought a bit of company, I think one of your muscles needs to relax a bit too..."
    new "Ich dachte, du bist nur abgelenkt, aber jetzt sehe ich, dass du ein bisschen Gesellschaft mitgebracht hast. Ich denke, einer deiner Muskeln muss sich auch noch entspannen."

    # say L526 pla
    old "I- am very sorry, please do not take me wrong way, I am... I am just very nervous."
    new "Ich- es tut mir sehr leid, bitte versteh mich nicht falsch, ich bin... ich bin einfach nur sehr nervös."

    # say L529 ana
    old "It's totally ok, I feel very flattered and I like it... The effort makes you feel a bit stressed, I think since you are helping, I should help you too, so you can feel better."
    new "Das ist total in Ordnung, ich fühle mich sehr geschmeichelt und ich mag es... Die Anstrengung macht dich ein bisschen nervös, denke ich. Da du mir hilfst, sollte ich dir auch helfen, damit du dich besser fühlst."

    # say L530 pla
    old "W- What? Oh no, of course not.. I think this is moment to finish the session."
    new "W- Was? Oh nein, natürlich nicht... Ich denke, es ist Zeit, die Sitzung zu beenden."

    # say L531 ana
    old "I know you want it... I remember last time you enjoyed it with my hands, probably this time we can try with... I don't know, maybe my mouth?"
    new "Ich weiß, dass du es willst... Ich erinnere mich, dass dir letztes Mal meine Hände gefallen haben, vielleicht können wir es diesmal mit... ich weiß nicht, vielleicht meinem Mund ausprobieren?"

    # say L532 pla
    old "... (What the fuck!)"
    new "Was zur Hölle!"

    # say L533 ana
    old "Why don't you relax a bit, let me check it out on my own, I know you will like it... Let's open this sweet gift."
    new "Warum entspannst du dich nicht ein bisschen, lass mich es mir selbst ansehen, ich weiß, dir wird es gefallen... Lass uns dieses süße Geschenk öffnen."

    # say L541 ana
    old "Wow, it's huge, things are getting better since last time, looks very tasty... Do you mind if I give it a taste?"
    new "Wow, das ist ja riesig, es wird von Mal zu Mal besser, sieht sehr lecker aus... Stört es dich, wenn ich es probiere?"

    # say L543 ana
    old "Let me take care of this now!"
    new "Lass mich das jetzt übernehmen!"

    # say L555 ana
    old "Did you like it?  You are not the only expert here, I am quite ready for this kind of 'exercises', how would you rate my performance?"
    new "Hat es dir gefallen? Du bist nicht der Einzige, der hier gut ist, ich bin auch bereit für solche 'Übungen'. Wie würdest du meine Leistung bewerten?"

    # say L568 lis
    old "Hey guys, I'm finally here, did you guys finish already?"
    new "Hey Leute, ich bin endlich da, seid ihr schon fertig?"

    # say L569 pla
    old "(Oh god, for a few minutes early and she could have discovered us...)"
    new "Oh Gott, wenn sie nur ein paar Minuten früher gekommen wäre, hätte sie uns entdecken können..."

    # say L570 ana
    old "Yes, it was very good. [pla] is the most wonderful partner I could ask for..."
    new "Ja, es war sehr gut. [pla] ist der wunderbarste Partner, den ich mir wünschen kann..."

    # say L571 ana
    old "He is very pleasant even though some positions got very hard, I like it too much!"
    new "Er ist sehr angenehm, obwohl einige Positionen sehr intensiv waren, ich mag es auch zu sehr!"

    # say L572 lis
    old "Aww, that's dazzling... I appreciate your words."
    new "Aww, das ist beeindruckend... Ich schätze deine Worte."

    # say L574 ana
    old "For sure, I know I will be coming very often, I didn't know it was so amusing, very ‘delicious', I was fully satisfied."
    new "Klar, ich weiß, dass ich oft kommen werde, ich wusste nicht, dass es so amüsant und köstlich ist, ich war total zufrieden."

    # say L575 lis
    old "Sounds terrific... Wait, what's that on your face?"
    new "Klingt toll... Warte, was ist das in deinem Gesicht?"

    # say L577 ana
    old "Oh, what's that? Ahh, It must be sweat, you know this is kind of new for me-"
    new "Oh, was ist das? Ahh, es muss Schweiß sein, weißt du, das ist für mich noch ziemlich neu-"

    # say L578 lis
    old "Yeah, right."
    new "Klar, klar."

    # say L579 ana
    old "But no worries, I will clean it in a moment, thank you."
    new "Aber keine Sorge, ich werde es gleich saubermachen, danke."

    # say L582 ana
    old "Thank you very much Lisa, once again, today's session was amazing, and [pla], this definitely be repeated, I need more... I mean sessions like this one."
    new "Danke schön Lisa, nochmal, heute war es fantastisch und [pla], das wird auf jeden Fall wiederholt werden, ich brauche mehr... ich meine solche Sitzungen."

    # say L583 pla
    old "... Y- yes, see you later..."
    new "... J- ja, bis später..."

    # say L584 lis
    old "Bye bye, Anastasia."
    new "Tschüss, Anastasia."

    # say L594 lis
    old "I really wanted to thank you, I know you weren't prepared enough but you actually did incredible, I am very embarrassed because it was all of the sudden for you to do it."
    new "Ich wollte dich wirklich bedanken, ich weiß, du warst nicht gut vorbereitet, aber du hast unglaubliche Arbeit geleistet. Mir ist total peinlich, dass ich dich so spontan damit konfrontiert habe."

    # say L595 pla
    old "No problem, I am happy to be of help."
    new "Kein Problem, ich bin froh, helfen zu können."

    # say L596 lis
    old "I just want you to know that you're fantastic, you accomplished to do the session without the proper training..."
    new "Ich will dir nur sagen, dass du fantastisch bist, du hast die Sitzung ohne die richtige Vorbereitung geschafft..."

    # say L597 lis
    old "I can see a great talent in you, I'm willing to teach you if want to know more, I hope I will not bother you again."
    new "Ich sehe großes Talent in dir, ich bin bereit, dich zu unterrichten, wenn du mehr lernen möchtest, ich hoffe, ich werde dich nicht wieder belasten."

    # say L598 pla
    old "Thank you very much, and don't worry you can ask me if you need more help."
    new "Danke schön, und mach dir keine Sorgen, du kannst mich fragen, wenn du mehr Hilfe brauchst."

    # say L599 lis
    old "Thank you honey, I appreciate your kindness."
    new "Danke Schatz, ich schätze deine Freundlichkeit."

    # say L619 lis
    old "Hi, [pla], how are you?"
    new "Hi, [pla], wie geht es dir?"

    # say L620 pla
    old "I am fine, thank you. How about you?"
    new "Mir geht es gut, danke. Wie ist es bei dir?"

    # say L621 lis
    old "I am well, actually I'm kind of concerned..."
    new "Ich bin eigentlich etwas besorgt..."

    # say L622 pla
    old "Why is that?"
    new "Warum das?"

    # say L623 lis
    old "To be honest, I think you're better than what I thought, Anastasia was really pleased with your job last time, so she wants to continue the program with you..."
    new "Ehrlich gesagt, denke ich, dass du besser bist, als ich dachte. Anastasia war letztes Mal wirklich zufrieden mit deiner Arbeit, deshalb möchte sie das Programm mit dir fortsetzen..."

    # say L625 lis
    old "Yes, however, my concern is... I didn't want to ask you again, however since Anastasia is asking for you, I want her to have the best experience..."
    new "Ja, aber meine Bedenken sind... Ich wollte dich eigentlich nicht noch einmal fragen, aber da Anastasia nach dir verlangt, möchte ich, dass sie die beste Erfahrung macht..."

    # say L626 lis
    old "Of course the decision hasn't been made yet, I explained to her I needed to discuss it with you first, before I could say yes or no, so I just wanted to let you know."
    new "Natürlich ist die Entscheidung noch nicht gefallen, ich habe ihr erklärt, dass ich erst mit dir sprechen muss, bevor ich Ja oder Nein sagen kann, wollte dich nur informieren."

    # say L628 lis
    old "Last time you helped me but since this is going to be a more frequent assistances, I am thinking you can be part of the business and you will have an income..."
    new "Das letzte Mal hast du mir geholfen, aber da es jetzt öfter sein wird, denke ich, du könntest Teil des Geschäftes werden und ein Einkommen haben..."

    # say L629 lis
    old "It will also bring positive things to your life, making it part of this new way of living. You know the more that you feel the universe the better you can share with others."
    new "Es wird auch positive Dinge in dein Leben bringen, Teil dieses neuen Lebensstils zu sein. Je mehr du das Universum spürst, desto besser kannst du es mit anderen teilen."

    # say L630 lis
    old "I will give you the proper training, so you'll have the knowledge you need, we can make the business grow together, I know other customers will love your job too."
    new "Ich werde dir die richtige Ausbildung geben, damit du die nötigen Kenntnisse hast, wir können das Geschäft gemeinsam wachsen lassen, ich weiß, dass auch andere Kunden deine Arbeit lieben werden."

    # say L631 pla
    old "I appreciate you considering me as an option, I will gladly help you."
    new "Ich schätze es, dass du mich in Betracht ziehst, ich werde dir gerne helfen."

    # say L632 lis
    old "Oh [pla], you are very kind, I have no words on how I appreciate your help, I will do everything I can so you can learn more."
    new "Oh [pla], du bist sehr lieb, ich weiß gar nicht, wie ich dir danken soll, ich werde alles tun, damit du mehr lernen kannst."

    # say L633 pla
    old "Don't worry, I'm glad to help."
    new "Mach dir keine Sorgen, ich freue mich, zu helfen."

    # say L634 lis
    old "Actually, are you too busy right now?"
    new "Eigentlich, hast du gerade Zeit?"

    # say L635 pla
    old "You mean now? I think I can stay for a while, why do you ask?"
    new "Meinst du jetzt? Ich denke, ich kann noch ein bisschen bleiben, warum fragst du?"

    # say L636 lis
    old "It's because we can go ahead with a practice today the next session you will have with Anastasia."
    new "Dann können wir heute üben, damit du dich für die nächste Session mit Anastasia besser vorbereiten kannst."

    # say L637 pla
    old "Oh, I see, sounds good."
    new "Oh, ich verstehe, klingt gut."

    # say L638 lis
    old "Perfect, let's go."
    new "Perfekt, lass uns loslegen."

    # say L646 lis
    old "Now let's get ready to start, please remember to control your breathing so we can make the most out of the exercise."
    new "Dann lass uns bereit machen, um anzufangen. Bitte denk daran, deinen Atem zu kontrollieren, damit wir das Beste aus der Übung herausholen können."

    # say L648 lis
    old "Since the previous positions  you worked with her were more aimed to release stress and anxiety, this time we will get more into the yoga world, so you can discover more sensations."
    new "Da die vorherigen Positionen, mit denen du gearbeitet hast, mehr darauf abzielten, Stress und Angst abzubauen, werden wir diesmal tiefer in die Welt des Yogas eintauchen, damit du mehr Empfindungen entdecken kannst."

    # say L650 lis
    old "The first position we will work on is extremely demanding, you need to be very careful so you can give the right directions..."
    new "Die erste Position, die wir durchgehen, ist extrem anspruchsvoll, du musst sehr vorsichtig sein, um die richtigen Anweisungen zu geben."

    # say L651 lis
    old "Depending on you the customer can feel more energy coming thru."
    new "Je nach dir kann der Kunde mehr Energie spüren."

    # say L652 pla
    old "Ok, what... Do I need to do?"
    new "Okay, was... Was muss ich tun?"

    # say L653 lis
    old "For the position, we will focus on the back, You will make sure I can get the perfect position, I will be on my hands and feet, looking straight."
    new "Für die Position konzentrieren wir uns auf den Rücken. Du sorgst dafür, dass ich die perfekte Position finde. Ich werde auf Händen und Knien sein und geradeaus schauen."

    # say L654 lis
    old "You need to help stretch the back by applying some pressure on the hips, Initially the weight of the body will be on the arms..."
    new "Du musst mir helfen, den Rücken zu dehnen, indem du ein bisschen Druck auf die Hüften ausübst. Am Anfang wird das Gewicht des Körpers auf den Armen liegen..."

    # say L655 lis
    old "After some seconds we will need to change and apply it to the legs, you need to help the customer lift the hips and now firmly apply pressure with your pelvis."
    new "Nach ein paar Sekunden müssen wir wechseln und den Druck auf die Beine übertragen. Du musst dem Kunden helfen, die Hüften anzuheben, und dann mit deinem Becken fest Druck ausüben."

    # say L664 lis
    old "We will need to repeat that movement several times, watch your breathing and making sure the position is being done properly. Got it?"
    new "Wir müssen diese Bewegung mehrmals wiederholen, auf deinen Atem achten und sicherstellen, dass die Position richtig ausgeführt wird. Kapiert?"

    # say L666 lis
    old "Perfect, let's try it."
    new "Perfekt, lass uns es versuchen."

    # say L673 lis
    old "That's it... You are doing it right."
    new "Das ist es... Du machst es richtig."

    # say L674 pla
    old "(Oh god this is quite enticing, I will need to touch her butt to grab her hips...)"
    new "Oh Gott, das ist ziemlich verlockend, ich muss ihren Po berühren, um ihre Hüften zu packen..."

    # say L675 lis
    old "Don't forget to hold the hips firmly, the muscle must be exercised."
    new "Vergiss nicht, die Hüften fest zu packen, das Muskeltraining ist wichtig."

    # say L676 pla
    old "(If I do it any harder, I'll touch her pussy.)"
    new "Wenn ich fester drücke, berühre ich ihre Pussy."

    # say L677 pla
    old "Don't worry... I will do it."
    new "Keine Sorge... Ich werde es machen."

    # say L678 lis
    old "Perfect, that will help us to ensure the customer is getting the right position."
    new "Perfekt, das wird uns helfen, sicherzustellen, dass der Kunde die richtige Position bekommt."

    # say L679 lis
    old "That was very good, you are doing good. Now let's move to the second position."
    new "Das war sehr gut, du machst das toll. Jetzt gehen wir zur zweiten Position."

    # say L685 pla
    old "Good! What's up with this one?"
    new "Gut! Was ist mit der hier?"

    # say L686 lis
    old "As you can imagine, we need to increase the difficulty, for the next position your help is essential, I will relax my entire body, you will hold my hips..."
    new "Wie du dir vorstellen kannst, müssen wir die Schwierigkeit erhöhen. Bei der nächsten Position ist deine Hilfe entscheidend, ich werde meinen gesamten Körper entspannen, du wirst meine Hüften halten..."

    # say L687 lis
    old "The first step will be to carry my body weight, you can support yourself with your pelvis, however I understand that could be very tiring, that is why we'll have some tiny breaks."
    new "Der erste Schritt besteht darin, mein Körpergewicht zu tragen, du kannst dich mit deinem Becken abstützen, aber ich verstehe, dass das sehr anstrengend sein könnte, deshalb machen wir kleine Pausen."

    # say L688 lis
    old "Since you are using your pelvis, the breaks moment will be to relax your pelvis and let the weight remain on the customers arms and your legs."
    new "Da du dein Becken einsetzt, werden die Pausen dazu dienen, dein Becken zu entspannen und das Gewicht auf den Armen des Kunden und deinen Beinen ruhen zu lassen."

    # say L689 pla
    old "Ok, sounds a bit difficult."
    new "Okay, klingt ein bisschen schwierig."

    # say L690 lis
    old "Not really... However, that is why you need to keep breathing and stay focused so you can use your strength smartly and make the exercise enjoyable for you too."
    new "Nicht wirklich... Aber deshalb musst du weiter atmen und dich konzentrieren, damit du deine Kraft klug einsetzen kannst und die Übung auch für dich Spaß macht."

    # say L692 lis
    old "Let's do it! Now that you have the idea."
    new "Lass uns anfangen! Jetzt, wo du den Dreh raus hast."

    # say L693 pla
    old "Sure, go ahead."
    new "Klar, mach mal."

    # say L699 lis
    old "Use your chakras to control your breathing that is the key for a position like this."
    new "Nutze deine Chakras, um deinen Atem zu kontrollieren, das ist der Schlüssel für eine solche Position."

    # say L708 pla
    old "Sure, I am breathing deeply and consciously."
    new "Okay, ich atme tief und bewusst."

    # say L709 lis
    old "I am very satisfied to hear that, try to use all your energy."
    new "Ich bin sehr zufrieden, das zu hören. Versuch, all deine Energie einzusetzen."

    # say L710 pla
    old "(This feels very delectable, she's rubbing my cock... I'm getting hard now...)"
    new "Das fühlt sich sehr lecker an, sie reibt meinen Schwanz... Ich werde jetzt hart..."

    # say L713 lis
    old "You need to focus too, so the exercise can be effective."
    new "Du musst dich auch konzentrieren, damit die Übung wirksam ist."

    # say L715 lis
    old "Keep doing that for a while with your customer, we will stop for now so we can continue with our next position, I can see you learn very fast."
    new "Mach das noch ein bisschen mit deinem Kunden, wir machen jetzt eine Pause und gehen zur nächsten Position über, ich sehe, dass du dich sehr schnell anpasst."

    # say L716 pla
    old "(Oh, thanks god!)..."
    new "Oh, danke Gott!"

    # say L722 pla
    old "(I don't know if I will be able to hide my boner this time.)"
    new "(Ich weiß nicht, ob ich meinen Ständer dieses Mal verstecken kann.)"

    # say L723 lis
    old "The last position is quite interesting, is related with the energies we have accumulated in the back, we will need to ignite them so we can release more of our chakra's potential..."
    new "Die letzte Position ist ziemlich interessant, sie hat mit den Energien zu tun, die wir im Rücken gespeichert haben. Wir müssen sie aktivieren, damit wir mehr von unserem Chakrapotential freisetzen können."

    # say L724 lis
    old "Since they are located in your back right before the gluteus,the position is aimed to get those points. Your customer will probably need you to get in that position."
    new "Da sie sich in deinem Rücken direkt vor dem Gesäß befinden, zielt die Position darauf ab, diese Punkte zu erreichen. Dein Kunde wird wahrscheinlich von dir verlangen, dass du dich in diese Position begibst."

    # say L725 lis
    old "I will lie down on my shoulders, but I will hold my waist with my hands, my arms are going to be the main support."
    new "Ich werde mich auf meine Schultern legen, aber ich halte meine Taille mit den Händen, meine Arme werden die Hauptsupport sein."

    # say L727 lis
    old "You will keep balance of the body as well as the pressure needed in two different points, the legs and back of the customer."
    new "Du wirst das Gleichgewicht des Körpers halten und gleichzeitig den Druck auf zwei verschiedene Punkte ausüben, die Beine und den Rücken des Kunden."

    # say L728 lis
    old "Let's start the position so you can have a better idea..."
    new "Lass uns die Position einnehmen, damit du einen besseren Überblick hast..."

    # say L729 pla
    old "(This position looks demanding so I will stay focused, I need to breath and to think something different.)"
    new "Diese Position sieht anspruchsvoll aus, ich werde mich konzentrieren, ich muss atmen und an etwas anderes denken."

    # say L730 pla
    old "Perfect, I am ready."
    new "Perfekt, ich bin bereit."

    # say L731 lis
    old "Perfect here we go..."
    new "Perfekt, dann mal los..."

    # say L738 pla
    old "(Oh no, this position is making me feel very horny, I am sure she will notice pretty soon.)"
    new "Oh nein, diese Position macht mich total geil, ich bin sicher, sie wird es bald merken."

    # say L739 lis
    old "Are you breathing properly, remember this is important for you to be able to assist your customer."
    new "Atmest du richtig? Das ist wichtig, damit du deiner Kundin helfen kannst."

    # say L740 pla
    old "Hmm... Sure, yes."
    new "Hmm... Klar, ja."

    # say L743 lis
    old "I can see you are quite motivated with this asana, you will need to control your energies so you can decide how to express or attract with your body."
    new "Ich sehe, dass du bei dieser Asana ganz schön motiviert bist, du wirst deine Energie kontrollieren müssen, damit du entscheiden kannst, wie du mit deinem Körper ausdrücken oder anziehen willst."

    # say L745 lis
    old "Alright, I think we are done..."
    new "Okay, ich denke, wir sind fertig..."

    # say L757 lis
    old "OH MY GOD!"
    new "OH MEIN GOTT!"

    # say L769 pla
    old "I- I'm sorry, I'm so sorry these positions are really enticing... A- and I can't help it."
    new "I- Ich bin sorry, ich bin so sorry, diese Positionen sind echt verlockend... Und ich kann einfach nicht anders."

    # say L770 lis
    old "Don't worry, it's natural, I just got surprised by the... Size..."
    new "Mach dir keine Sorgen, es ist natürlich, ich bin nur von der... Größe überrascht worden."

    # say L772 lis
    old "Well, this happened because your chakras are unbalanced."
    new "Na ja, das ist passiert, weil deine Chakras unbalanciert sind."

    # say L773 pla
    old "My cha- kras?"
    new "Meine Cha- kras?"

    # say L774 lis
    old "Yes, I think you need to reharmonize your chakra ‘Muladhara', this is the sexual chakra and is clearly unbalanced in you."
    new "Ja, ich denke, du musst dein Chakra 'Muladhara' reharmonisieren, das ist das sexuelle Chakra und bei dir offensichtlich unbalanciert."

    # say L775 lis
    old "But, don't worry, once you harmonize your chakra Muladhara, you will be more stable, and you will be able to prevent these unexpected body reactions."
    new "Aber mach dir keine Sorgen, sobald du dein Chakra Muladhara harmonisierst, wirst du stabiler und kannst diese unerwarteten Körpereaktionen verhindern."

    # say L777 lis
    old "I think you need to work on that, we can do some tantric rituals so you can restore your chakras to their natural energy."
    new "Ich denke, du solltest daran arbeiten, wir können einige tantrische Rituale machen, damit du deine Chakras auf ihre natürliche Energie zurückbringst."

    # say L778 pla
    old "A tantric what?"
    new "Ein tantrisches Was?"

    # say L779 lis
    old "Tantric rituals, it's a very spiritual technique where we clean your chakras. I think we should do it tonight."
    new "Tantrische Rituale, das ist eine sehr spirituelle Technik, bei der wir deine Chakras reinigen. Ich denke, wir sollten es heute Abend machen."

    # say L780 pla
    old "T- tonight?"
    new "T- heute Abend?"

    # say L781 lis
    old "Yes, I need to prepare a few things for the ritual, And you need to balance your chakras before your next yoga session with Anastasia."
    new "Ja, ich muss noch ein paar Dinge für das Ritual vorbereiten. Und du musst deine Chakras ausbalancieren, bevor du dein nächstes Yogastudio mit Anastasia hast."

    # say L782 lis
    old "We don't want you to have this kind of... Reactions with her, don't we?"
    new "Wir wollen doch nicht, dass du so etwas... mit ihr hast, oder?"

    # say L783 pla
    old "Hmm... No, no, of course not... No."
    new "Hmm... Nein, nein, natürlich nicht... Nein."

    # say L784 lis
    old "Ok, then I'll make the preparations for our tantric ritual."
    new "Okay, dann mache ich die Vorbereitungen für unser tantrisches Ritual."

    # say L786 lis
    old "It was nice to practice with you today! See you later."
    new "Es war schön, heute mit dir zu üben! Bis später."

    # say L787 pla
    old "See you then."
    new "Bis dann."

    # say L806 pla
    old "Wow... W- what are you... W- wearing?"
    new "Wow... W- was trägst du... W- das da?"

    # say L807 lis
    old "Oh, hi, [pla], glad to see you... These collars you see are some elements that make part of the ritual we will do tonight; they will help to keep the balance of your chakras."
    new "Oh, hallo [pla], schön, dich zu sehen... Diese Halsbänder sind Elemente, die Teil des Rituals werden, das wir heute Abend durchführen; sie helfen dabei, deine Chakren auszubalancieren."

    # say L808 lis
    old "Let's go to the room so I can explain everything to you..."
    new "Lass uns ins Zimmer gehen, damit ich dir alles erklären kann..."

    # say L817 lis
    old "Everything is set in this room so we can cleanse those energies and balance your chakras..."
    new "Alles ist in diesem Raum vorbereitet, damit wir diese Energien reinigen und deine Chakren ausbalancieren können..."

    # say L818 lis
    old "I hope you can take advantage of the lights, the fragrances, as well as the location, we are about to do a very important ritual, so every single detail must help us get in the mood."
    new "Ich hoffe, du kannst die Lichter, die Düfte und den Ort genießen, wir werden ein sehr wichtiges Ritual durchführen, bei dem jedes Detail dazu beitragen soll, dass wir in Stimmung kommen."

    # say L819 lis
    old "Please I need you to open your mind so the exercises we do tonight will be more effective..."
    new "Bitte, ich brauche, dass du deinen Geist öffnest, damit die Übungen heute Abend wirksamer sind..."

    # say L820 lis
    old "Some of the exercises of the ritual will have a lot of contact so please let the massages follow its course, it is a very spiritual process."
    new "Einige der Übungen des Rituals werden viel Körperkontakt erfordern, also lass die Massagen ihren Lauf nehmen, es ist ein sehr spiritueller Prozess."

    # say L821 pla
    old "M- massages?"
    new "M-Massagen?"

    # say L822 lis
    old "We need to compenetrate each other today so I can balance right your chakras."
    new "Wir müssen heute miteinander verschmelzen, damit ich deine Chakras ausbalancieren kann."

    # say L824 lis
    old "I did some meditation today so the massages can be very deep and productive for you so please merge with me to have a great experience."
    new "Ich habe heute meditiert, damit die Massagen sehr tiefgehend und förderlich für dich sein können, also bitte vereine dich mit mir, um eine großartige Erfahrung zu haben."

    # say L826 lis
    old "It's a very beautiful way to perceive what surrounds you, so you need to express according to the energies that you will be able to recognize... Let's start."
    new "Es ist eine sehr schöne Art, die Welt wahrzunehmen, also musst du dich nach den Energien ausdrücken, die du erkennen wirst... Lass uns beginnen."

    # say L828 lis
    old "First, I need you to undress so we can uncover our energies."
    new "Erst einmal musst du dich ausziehen, damit wir unsere Energien freilegen können."

    # say L829 pla
    old "U- undress?"
    new "Ausziehen?"

    # say L830 lis
    old "Yes, please don't take it the wrong way, this is a very pure experience so I need you to undress not only the clothes but also your mind and soul."
    new "Ja, bitte versteh es nicht falsch, dies ist eine sehr reine Erfahrung, deshalb musst du dich nicht nur ausziehen, sondern auch deinen Geist und deine Seele entblößen."

    # say L831 lis
    old "Keep in mind your body is something beautiful and it doesn't make you feel embarrassed, it's natural as universe is and we are going beyond to see how to control its energy."
    new "Denk daran, dein Körper ist etwas Schönes und du musst dich nicht dafür schämen, es ist so natürlich wie das Universum. Wir gehen darüber hinaus, um zu lernen, wie wir seine Energie kontrollieren können."

    # say L838 lis
    old "Let's keep working on our breathing, remember the pranayama, we need to concentrate so you can open your senses, that is the main purpose of this exercise today."
    new "Lass uns weiter an unserer Atmung arbeiten, denke an die Pranayama, wir müssen uns konzentrieren, damit du deine Sinne öffnen kannst, das ist das Hauptziel dieses Übungs heute."

    # say L839 pla
    old "Hmm, sure..."
    new "Hmm, klar..."

    # say L840 lis
    old "I need you to concentrate, smell the candles, the ambience we have for this moment, do you feel the fragrance?"
    new "Ich brauche deine Konzentration, riech die Kerzen, die Atmosphäre, die wir für diesen Moment geschaffen haben, spürst du den Duft?"

    # say L841 pla
    old "Yes, it smells nice."
    new "Ja, es riecht gut."

    # say L842 lis
    old "Great!, now please lie down with your stomach on the floor, then relax, I will do the massage, you will feel my body helping yours to open your senses."
    new "Super, jetzt leg dich bitte mit dem Bauch nach unten auf den Boden, dann entspann dich, ich werde die Massage machen, du wirst mein Körper spüren, der deinen hilft, deine Sinne zu öffnen."

    # say L851 lis
    old "let me start with your shoulders, so you can feel more."
    new "Lass mich mit deinen Schultern beginnen, damit du es besser spürst."

    # say L853 lis
    old "Please hold your breath a bit more, so we can intensify the fragrance and focus your thoughts."
    new "Bitte halte noch etwas die Luft an, damit wir den Duft intensivieren und deine Gedanken fokussieren können."

    # say L857 lis
    old "Good, do you feel my touch, my skin... How do you feel?"
    new "Gut, spürst du meine Berührung, meine Haut... Wie fühlst du dich?"

    # say L858 pla
    old "It's very soft."
    new "Es ist sehr weich."

    # say L859 lis
    old "That's perfect, you are doing good."
    new "Das ist perfekt, du machst das gut."

    # say L873 lis
    old "Let me touch your skin now so we can release the pressure, breath with me, it's just one pace, don't stop..."
    new "Lass mich deine Haut berühren, damit wir den Druck abbauen können, atme mit mir, es ist nur ein Schritt, hör nicht auf..."

    # say L875 lis
    old "Feel free to express and feel everything your body wants to feel at this moment, I will control everything so you can go freely wherever your mind wants."
    new "Lass dich gehen und fühle alles, was dein Körper will, ich habe die Kontrolle, du kannst dich ganz deinen Gedanken hingeben."

    # say L876 lis
    old "Try harder to focus, it's just this moment, there is nothing else to think about, but the sensations, can you smell it?"
    new "Versuch dich stärker zu konzentrieren, es gibt nur diesen Moment, denk an nichts anderes als die Empfindungen, kannst du es riechen?"

    # say L877 pla
    old "Yes, I can."
    new "Ja, ich kann."

    # say L888 pla
    old "I feel amazing, I appreciate your time and effort to help me."
    new "Ich fühle mich fantastisch, ich schätze deine Zeit und Mühe, die du investierst, um mir zu helfen."

    # say L889 lis
    old "Oh no, it's no trouble, I'm just an instrument from the universe to help you with your energies."
    new "Oh nein, das ist kein Problem, ich bin nur ein Instrument des Universums, um dir bei deiner Energie zu helfen."

    # say L890 lis
    old "Just relax and please keep learning so you can apply all your knowledge to the sessions with your customers. I am sure now you won't have these issues with Anastasia."
    new "Entspann dich einfach und lerne weiter, damit du dein Wissen in die Sitzungen mit deinen Kunden einbringen kannst. Ich bin sicher, dass du jetzt keine Probleme mehr mit Anastasia haben wirst."

    # say L891 lis
    old "I can also feel a different aura on you now, I can feel your spirit is more calmed."
    new "Ich kann auch eine andere Aura an dir spüren, ich fühle, dass dein Geist ruhiger geworden ist."

    # say L892 pla
    old "Thank you for all that you have done."
    new "Danke für alles, was du getan hast."

    # say L893 lis
    old "It's something I enjoy, please have some rest."
    new "Das mache ich gerne, ruh dich bitte aus."

    # say L894 pla
    old "I'll do it, have a great one too."
    new "Ich mach's, hab auch einen schönen Abend."

    # say L895 lis
    old "Good night, [pla]."
    new "Gute Nacht, [pla]."

    # say L896 pla
    old "Good night."
    new "Gute Nacht."

    # say L916 lis
    old "Welcome [pla], we were waiting for you."
    new "Willkommen [pla], wir haben auf dich gewartet."

    # say L917 pla
    old "Hi, I am sorry if I'm late."
    new "Hi, ich bin sorry, wenn ich zu spät dran bin."

    # say L918 lis
    old "Oh don't worry, you are just on time."
    new "Oh mach dir keine Sorgen, du bist genau pünktlich."

    # say L919 lis
    old "How do you feel today, are you ready to have the second session with Anastasia?"
    new "Wie fühlst du dich heute? Bist du bereit für die zweite Sitzung mit Anastasia?"

    # say L920 pla
    old "Yes, I've been thinking about it."
    new "Ja, ich habe darüber nachgedacht."

    # say L921 lis
    old "Perfect, Well guys I am glad to see you both, I know you are working hard and improving!"
    new "Perfekt, ich freue mich, euch beide zu sehen. Ich weiß, ihr arbeitet hart und macht Fortschritte!"

    # say L922 lis
    old "How about you Anastasia, how do you feel today?"
    new "Wie geht es dir heute, Anastasia?"

    # say L923 ana
    old "I am quite happy with my trainer because he has HUGE talent, I am prepared today. [pla], is it going to be HARDER than last time?"
    new "Ich bin ziemlich zufrieden mit meinem Trainer, weil er ein riesiges Talent hat. Ich bin heute gut vorbereitet. [pla], wird es SCHWIERIGER als beim letzten Mal?"

    # say L925 pla
    old "I- I'm sure this is going to... to be a good session."
    new "Ich bin sicher, dass es... dass es eine gute Sitzung wird."

    # say L926 lis
    old "Perfect, I will leave you guys alone so you can do the session with no inconveniences. I will be here to give you proper privacy."
    new "Perfekt, ich lasse euch allein, damit ihr ungestört trainieren könnt. Ich werde hier sein, um euch die nötige Privatsphäre zu geben."

    # say L927 lis
    old "The room is already prepared."
    new "Der Raum ist schon vorbereitet."

    # say L929 lis
    old "Anastasia I hope you enjoy your session you will be in good hands."
    new "Anastasia, ich hoffe, du genießt die Sitzung, du bist in guten Händen."

    # say L931 ana
    old "Yes, I'm pretty sure he's really good with his hands, I'll enjoy the session."
    new "Ja, ich bin ziemlich sicher, dass er wirklich gut mit seinen Händen ist, ich werde die Sitzung genießen."

    # say L932 lis
    old "Aww, I love that energy, please work hard... See you guys."
    new "Aww, ich liebe diese Energie, bitte gebt euer Bestes... Bis später."

    # say L933 pla
    old "... See you."
    new "Bis später."

    # say L947 pla
    old "Well, Today we will continue the meditation process, remem-"
    new "Na, heute werden wir das Meditationsprozess fortsetzen, erinnerst du dich-"

    # say L948 ana
    old "I wanted to- sorry to interrupt you..."
    new "Ich wollte nur- tut mir leid, dass ich dich unterbreche..."

    # say L949 pla
    old "Oh, it's ok, tell me."
    new "Oh, ist schon gut, erzähl mir."

    # say L950 ana
    old "It is just that... I wanted to try something different today, you know."
    new "Es ist nur... ich wollte heute etwas anderes ausprobieren, weißt du."

    # say L951 pla
    old "Hmm... What did you have in mind?"
    new "Hmm... Was hast du im Sinn?"

    # say L952 ana
    old "Well being honest, I was kind of distracted, I was not able to forget about your cock... And I want you to fuck me with that big hard cock."
    new "Ehrlich gesagt war ich ziemlich abgelenkt, ich konnte an deinen Schwanz nicht aufhören zu denken... Und ich will, dass du mich mit diesem großen, harten Schwanz fickst."

    # say L953 pla
    old "(WHAT THE FUCK!)"
    new "Was zum Teufel!"

    # say L954 pla
    old "WHAT? B- but, we need to have a yoga session..."
    new "Was? A-aber, wir müssen noch Yoga machen..."

    # say L955 ana
    old "The truth is I am very horny today, I came considering to have sex with you..."
    new "Die Wahrheit ist, ich bin heute total scharf, ich hab überlegt, mit dir zu ficken..."

    # say L961 ana
    old "Oh, it seems like you're getting ready... Why don't you get these pants off?"
    new "Oh, es sieht so aus, als wärst du bereit... Warum ziehst du nicht diese Hose aus?"

    # say L962 pla
    old "I- it's not-"
    new "I- es ist nicht-"

    # say L963 ana
    old "Don't be shy, I know both of us will feel very good after that, I am just a bit thirsty, can I get a taste?"
    new "Sei nicht schüchtern, ich weiß, dass wir beide danach sehr gut drauf sein werden, ich bin nur ein bisschen durstig, kann ich einen Vorgeschmack bekommen?"

    # say L973 ana
    old "Oh, yeah, this is what I'm talking about..."
    new "Oh ja, genau das meine ich..."

    # say L987 ana
    old "That was delicious, but now I want you to fuck me!"
    new "Das war lecker, aber jetzt will ich, dass du mich fickst!"

    # say L988 pla
    old "W- what? Oh, no Lisa is downstairs she could-"
    new "W-was? Oh, nein, Lisa ist unten, sie könnte-"

    # say L989 ana
    old "Maybe you need a bit of motivation... You want to see them again, don't you?"
    new "Vielleicht brauchst du ein bisschen Motivation... Du willst sie doch wiedersehen, oder?"

    # say L1002 ana
    old "Now, let's fuck!"
    new "Jetzt, lass uns ficken!"

    # say L1015 ana
    old "You were amazing, I loved this session, I need this kind of session more often."
    new "Du warst fantastisch, ich habe diese Session geliebt, ich brauche solche Sessions öfter."

    # say L1017 ana
    old "I can keep this a secret if you are afraid of your boss, she doesn't need to know our particular sessions, besides she doesn't have the big talent you have."
    new "Ich kann das geheim halten, wenn du Angst vor deiner Chefin hast, sie muss ja nicht wissen, was für Sitzungen wir haben, außerdem hat sie nicht so viel Talent wie du."

    # say L1018 ana
    old "I am considering you can get a tip later, for your hard work..."
    new "Ich denke darüber nach, dir später ein Trinkgeld zu geben, für deine harte Arbeit..."

    # say L1019 pla
    old "... I- I think we shouldn't-"
    new "... Ich- Ich denke, wir sollten das nicht tun-"

    # say L1020 ana
    old "Do not worry honey, this was your best yoga session ever."
    new "Mach dir keine Sorgen, Schatz, das war deine beste Yogastunde überhaupt."

    # say L1032 lis
    old "Hi guys, congratulations I can see you are sweating, that means you had a very hard job today."
    new "Hi Leute, gratuliere, ich sehe, ihr schwitzt, das bedeutet, ihr hattet heute eine harte Arbeit."

    # say L1033 ana
    old "Yes, [pla] took a lot out of me today."
    new "Ja, [pla] hat mich heute ganz schön ausgelaugt."

    # say L1035 lis
    old "He is improving every day; I can tell you he's putting in a big effort."
    new "Er verbessert sich jeden Tag, ich sehe, dass er sich richtig ins Zeug legt."

    # say L1036 ana
    old "I can see that, I hope we can meet again later, the sooner the better."
    new "Ich sehe das, ich hoffe, wir können uns später wiedersehen, am liebsten so bald wie möglich."

    # say L1037 lis
    old "Oh sure, I have your appointment already set. Don't worry, we will be waiting for you."
    new "Oh sicher, ich habe deinen Termin schon festgelegt. Mach dir keine Sorgen, wir werden auf dich warten."

    # say L1038 ana
    old "Perfect, thank you for the session today... And thank you very much for your hard, hard work [pla], I really enjoy it."
    new "Perfekt, danke für die Sitzung heute... Und danke sehr für deine harte, harte Arbeit [pla], ich genieße sie wirklich."

    # say L1042 lis
    old "Bye Anastasia, have a great day!"
    new "Bis später Anastasia, hab einen schönen Tag!"

    # say L1052 lis
    old "I am very satisfied with your job, I wanted you to know that I am considering to introduce you to other customers, I think you are so easy going, that people will just connect with you."
    new "Ich bin sehr zufrieden mit deiner Arbeit, ich wollte, dass du weißt, dass ich überlege, dich anderen Kunden vorzustellen. Ich denke, du bist so locker, dass die Leute einfach mit dir harmonieren werden."

    # say L1053 pla
    old "O- other customers, I- I don't know-"
    new "A- andere Kunden, ich- ich weiß nicht-"

    # say L1054 lis
    old "You can help other people, your energy will just bring you what you need, you only need to keep on working hard..."
    new "Du kannst anderen Menschen helfen, deine Energie wird dir geben, was du brauchst, du musst nur weiter hart arbeiten..."

    # say L1055 pla
    old "Hmm if you say so..."
    new "Hmm, wenn du das sagst..."

    # say L1056 lis
    old "Oh, by the way, remember we will have tomorrow a new ritual, the tantric massages need to be continued so we can balance your chakras."
    new "Oh, übrigens, morgen haben wir ein neues Ritual, die tantrischen Massagen müssen weitergehen, damit wir deine Chakras ausbalancieren können."

    # say L1058 lis
    old "Amazing, thank you for today, please get some rest."
    new "Wunderbar, danke für heute, bitte ruh dich aus."

    # say L1059 lis
    old "See you later [pla]!"
    new "Bis später [pla]!"

    # say L1078 lis
    old "Hi [pla], nice to see you again!"
    new "Hi [pla], schön dich wiederzusehen!"

    # say L1079 pla
    old "Hello, Thank you."
    new "Hallo, danke."

    # say L1080 lis
    old "I am very happy because you are very committed with this extra training."
    new "Ich bin sehr glücklich, dass du dich so engagierst bei diesem Extra-Training."

    # say L1081 pla
    old "I appreciate you are taking the time to teach me."
    new "Ich schätze, dass du dir die Zeit nimmst, mich zu unterrichten."

    # say L1082 lis
    old "Any time, you are helping a lot with my business, I will do my best so you can be as good as me."
    new "Jederzeit, du hilfst mir unglaublich viel bei meinem Geschäft, ich werde mein Bestes geben, damit du genauso gut wie ich wirst."

    # say L1083 pla
    old "Hmm, that is very nice of you."
    new "Hmm, das ist sehr nett von dir."

    # say L1084 lis
    old "Let's go to the room so we can start the tantric session."
    new "Lass uns ins Zimmer gehen, damit wir mit der tantrischen Sitzung beginnen können."

    # say L1092 lis
    old "Have you seen any improvement thanks to last session?"
    new "Hast du schon eine Verbesserung durch die letzte Sitzung bemerkt?"

    # say L1093 pla
    old "Yes... I can feel in a better mood."
    new "Ja... ich fühle mich besser drauf."

    # say L1094 lis
    old "Good, you will see better results."
    new "Gut, du wirst bessere Ergebnisse sehen."

    # say L1095 lis
    old "Today we need to improve a lot because you need to be able to balance your chakra muladhara as soon as possible, that way you can offer a more delightful experience."
    new "Heute müssen wir viel verbessern, weil du so schnell wie möglich dein Chakra Muladhara ausbalancieren musst, damit du eine noch angenehmere Erfahrung bieten kannst."

    # say L1096 lis
    old "Please get comfortable, you know we need to open our mind, just relax because this is not any casual meeting, your body is more than flesh, blood and energy..."
    new "Bitte mach es dir bequem, du weißt, wir müssen unser Geist öffnen, einfach entspann dich, denn das ist kein gewöhnliches Treffen, dein Körper ist mehr als Fleisch, Blut und Energie..."

    # say L1097 lis
    old "So, there's nothing to feel shy about, please undress."
    new "Dann gibt es also nichts, worüber du dich schämst, bitte zieh dich aus."

    # say L1103 lis
    old "Perfect, so today we need to increase the perception of our senses, you must feel more, once you connect your sexual chakra, we will start with the massage."
    new "Perfekt, heute müssen wir die Wahrnehmung unserer Sinne steigern, du musst mehr fühlen. Sobald du dein sexuelles Chakra verbindest, beginnen wir mit der Massage."

    # say L1104 lis
    old "The idea is to recognize some feelings that only you can see, some situations that are deep inside, no one will be able to get there... Do not forget to feel the energy..."
    new "Die Idee ist, einige Gefühle zu erkennen, die nur du sehen kannst, Situationen, die tief in dir drin sind, wo niemand hinkommt... Vergiss nicht, die Energie zu spüren..."

    # say L1112 lis
    old "While feeling my body on your skin please bring that healing energy in and allow it to wash through your body and mind."
    new "Während du meinen Körper auf deiner Haut spürst, lass diese heilende Energie in dich hineinströmen und sie durch deinen Körper und Geist fließen."

    # say L1114 lis
    old "Let your skin merge with mine, feel my fragrance, connect your senses with mine."
    new "Lass deine Haut mit meiner verschmelzen, spür meinen Duft, verbinde deine Sinne mit meinen."

    # say L1124 pla
    old "So, are you going to use your hands like last time?"
    new "So, willst du wieder deine Hände benutzen wie letztes Mal?"

    # say L1125 lis
    old "No, we need to do better than last time, this time I want you to be able to experience a more intense moment, so I think my breast is going to be perfect."
    new "Nein, wir müssen es dieses Mal besser machen. Dieses Mal will ich, dass du ein intensiveres Erlebnis hast, deshalb denke ich, meine Brust wird perfekt sein."

    # say L1126 pla
    old "Y- your breast? ..."
    new "D- deine Brust?..."

    # say L1127 lis
    old "Yes, remember this is not a sexual act, this a spiritual ritual to connect together and cleanse your chakras."
    new "Ja, denk dran, das ist kein sexueller Akt, sondern ein spirituelles Ritual, um uns zu verbinden und deine Chakras zu reinigen."

    # say L1128 lis
    old "Don't get distracted, keep focused so we can do the session and control your breathing."
    new "Lass dich nicht ablenken, bleib konzentriert, damit wir die Sitzung durchziehen und deinen Atem kontrollieren können."

    # say L1129 pla
    old "... O- ok."
    new "O- ok."

    # say L1137 lis
    old "Just relax your body it is a part of the universe, where I can move freely and that way we can take it out..."
    new "Lass deinen Körper entspannen, er ist Teil des Universums, wo ich mich frei bewegen kann, und so können wir es tun..."

    # say L1146 lis
    old "I can see your energy is more stable now, I am really proud of the effort you are putting in."
    new "Ich sehe, dass deine Energie jetzt stabiler ist, ich bin echt stolz auf die Anstrengung, die du investierst."

    # say L1147 lis
    old "I think we have just one lesson left, according to the progress I have seen, this chakra muladhara is not so strong now, you are getting the balance you need."
    new "Ich denke, wir haben nur noch eine Lektion übrig, nach dem Fortschritt, den ich gesehen habe, ist dieses Chakra Muladhara jetzt nicht mehr so stark, du bekommst die Balance, die du brauchst."

    # say L1148 lis
    old "There are still more things to learn, see you next time, you need to get some rest, don't forget tomorrow's lesson with Anastasia."
    new "Es gibt noch mehr zu lernen, bis dann, du solltest dich ausruhen, vergiss nicht die Stunde mit Anastasia morgen."

    # say L1149 pla
    old "Sure, I'll be here... Thank you, bye."
    new "Klar, ich bin hier... Danke, tschüss."

    # say L1169 lis
    old "Hi Anastasia, welcome to your yoga session once again, I hope you are ready for the routine today."
    new "Hi Anastasia, willkommen zu deiner Yogastunde, ich hoffe, du bist bereit für das Training heute."

    # say L1170 ana
    old "Hi Lisa, you are right I came prepared, this time I want to give my best and I hope [pla] brings a harder... Activity today."
    new "Hi Lisa, du hast recht, ich bin bereit. Dieses Mal will ich mein Bestes geben und ich hoffe, [pla] bringt eine härtere... Aktivität heute."

    # say L1177 pla
    old "Hi... Am I late?"
    new "Hi... Bin ich zu spät?"

    # say L1179 lis
    old "Oh no, it's perfect timing, Anastasia was telling me she came prepared today..."
    new "Oh nein, das Timing ist perfekt, Anastasia hat mir gerade erzählt, dass sie heute gut vorbereitet ist..."

    # say L1180 lis
    old "I am very happy that your training has become something personal, it means that you guys are feeling connected through these exercises."
    new "Ich bin sehr froh, dass eure Trainingssessions persönlicher geworden sind, das zeigt, dass ihr euch durch diese Übungen verbunden fühlt."

    # say L1181 lis
    old "I am so proud that you guys are improving together, I will leave you alone so you can do your routine, in case you need me, please let me know."
    new "Ich bin so stolz, dass ihr euch gemeinsam verbessert, ich lasse euch allein, damit ihr euer Training machen könnt, falls ihr mich braucht, sagt Bescheid."

    # say L1182 pla
    old "Sure, I will let you know in case we need you, let's go to the room to start the lesson."
    new "Klar, ich geb dir Bescheid, wenn wir dich brauchen. Lass uns ins Zimmer gehen und mit dem Training anfangen."

    # say L1190 pla
    old "Well, we have a very-"
    new "Na, wir haben eine sehr-"

    # say L1191 ana
    old "I needed this urgently, so let's get straight to it..."
    new "Ich brauchte das dringend, also lass uns direkt damit anfangen..."

    # say L1212 ana
    old "I want MORE! I want you to be rude... Fuck me harder PLEASE!"
    new "Ich will Mehr! Ich will, dass du grob bist... Fick mich härter BITTE!"

    # say L1226 ana
    old "Oh, you've accomplished it, this was by far better than last time."
    new "Oh, du hast es geschafft, das war bei Weitem besser als letztes Mal."

    # say L1227 ana
    old "Could you make it better next time? I wanna see that!"
    new "Kannst du es beim nächsten Mal noch besser machen? Ich will das sehen!"

    # say L1228 pla
    old "N- next time?"
    new "Nächste-mal?"

    # say L1229 ana
    old "I am really happy for every penny I have spent here; I will speak highly of you with some friends, they will love you..."
    new "Ich bin echt froh über jeden Cent, den ich hier ausgegeben habe; ich werde ein gutes Wort für dich bei ein paar Freunden einlegen, die werden dich lieben..."

    # say L1231 ana
    old "Alright, thanks for everything it's time to go."
    new "Okay, danke für alles, es ist Zeit zu gehen."

    # say L1241 pla
    old "Oh Lisa, h- how are you?"
    new "Oh Lisa, h- wie geht es dir?"

    # say L1242 lis
    old "I can see the 'Lesson' has finished."
    new "Ich sehe, dass die 'Lektion' beendet ist."

    # say L1247 lis
    old "I want to congratulate you guys for the effort you are doing on every lesson, I can see every time is better, did you like it Anastasia."
    new "Ich möchte euch beiden für euren Einsatz bei jeder Lektion gratulieren, ich sehe, dass es jedes Mal besser wird, hast du es genossen, Anastasia?"

    # say L1248 ana
    old "It was the best session ever; I am considering opening my schedule so we can make my sessions more frequent."
    new "Es war die beste Sitzung überhaupt; ich überlege, meinen Terminplan zu öffnen, damit wir meine Sitzungen häufiger machen können."

    # say L1249 lis
    old "Of course we could discuss it later, you can have as many sessions as you need..."
    new "Natürlich können wir das später besprechen, du kannst so viele Sitzungen haben, wie du brauchst..."

    # say L1250 ana
    old "Fascinating! Next meeting we will check that."
    new "Faszinierend! Bei unserem nächsten Treffen werden wir das überprüfen."

    # say L1251 lis
    old "Hope you get some rest Anastasia, see you on next appointment."
    new "Hoffe, du kommst zur Ruhe, Anastasia. Bis zum nächsten Termin."

    # say L1252 ana
    old "Oh thank you, I will, see you next time."
    new "Oh danke, ich werd's tun, bis zum nächsten Mal."

    # say L1253 ana
    old "Everything was amazing, thank you [pla]."
    new "Alles war fantastisch, danke [pla]."

    # say L1254 pla
    old "No problem, see you next session."
    new "Kein Problem, bis zur nächsten Session."

    # say L1263 lis
    old "Are you leaving too?"
    new "Geht es dir auch?"

    # say L1264 pla
    old "I guess so... ?"
    new "Ich schätze schon...?"

    # say L1265 lis
    old "I need to talk to you about something before you leave."
    new "Ich muss noch was mit dir besprechen, bevor du gehst."

    # say L1266 pla
    old "Hmm, sure... What is it?"
    new "Hmm, klar... Was ist los?"

    # say L1267 lis
    old "I think it's not acceptable... I know you are not doing the routine we have been preparing..."
    new "Ich denke, das ist nicht in Ordnung... Ich weiß, dass du die Routine, die wir vorbereitet haben, nicht durchführst..."

    # say L1269 lis
    old "I assume the previous routines were not done either, am I right?"
    new "Ich gehe davon aus, dass die vorherigen Routines auch nicht gemacht wurden, oder?"

    # say L1270 pla
    old "(Oh shit... Did she noticed we were having SEX)"
    new "Oh Scheiße... Hat sie gemerkt, dass wir Sex hatten?"

    # say L1271 pla
    old "W- what are you... T- talking about?"
    new "W- was redest du... D- davon?"

    # say L1272 lis
    old "Do not try to hide it, do you think I didn't hear her moaning?"
    new "Versuch es nicht zu verstecken, glaubst du, ich hab sie nicht stöhnen hören?"

    # say L1273 pla
    old "I- I don't know what-"
    new "I- Ich weiß nicht, wovon-"

    # say L1274 lis
    old "[pla], I heard what you were doing, and I can swear, it was not a yoga routine, you both were having sex!"
    new "[pla], ich hab gehört, was ihr gemacht habt, und ich wette, es war kein Yoga-Training, ihr hattet Sex!"

    # say L1275 pla
    old "(Oh God, she's going to kill me.)"
    new "Oh Gott, sie wird mich umbringen."

    # say L1276 pla
    old "I- I am very sorry, it wasn't my inte-"
    new "Ich- Ich bin sehr sorry, es war nicht meine Absicht-"

    # say L1277 lis
    old "Do you know what really pisses me off?"
    new "Weißt du, was mich echt wütend macht?"

    # say L1279 lis
    old "I mean I don't care if you are having sex or not, you can connect with anybody and share your energy, sex is beautiful and good way to connect together."
    new "Ich meine, es ist mir egal, ob du Sex hast oder nicht, du kannst dich mit jedem verbinden und deine Energie teilen, Sex ist schön und eine gute Art, miteinander verbunden zu sein."

    # say L1280 lis
    old "But you should be applying the meditation and yoga experience with the client. This is not what I'm selling..."
    new "Aber du solltest die Meditationserfahrung und Yoga mit dem Klienten anwenden. Das ist nicht, was ich anbiete..."

    # say L1281 pla
    old "I'm so sorry..."
    new "Es tut mir so leid..."

    # say L1282 lis
    old "[pla], I think you have too many things to learn still, in this process... If someone is really learning to connect his body and soul, it means we are doing the process fine..."
    new "[pla], ich denke, du musst noch viel lernen in diesem Prozess... Wenn jemand wirklich lernt, seinen Körper und seine Seele zu verbinden, bedeutet das, dass wir den Prozess gut machen..."

    # say L1283 lis
    old "Anastasia is not doing it, she has been distracted, I mean my academy is not about other things different from the energy, meditation and yoga..."
    new "Anastasia macht das nicht, sie ist abgelenkt, ich meine, meine Akademie dreht sich nicht um andere Dinge als Energie, Meditation und Yoga..."

    # say L1284 lis
    old "She is not getting that here. I'm not doing this for money or business, it's about fate and helping others to connect with the universe."
    new "Sie bekommt das hier nicht. Ich mache das nicht für Geld oder Geschäft, es geht um Schicksal und darum, anderen zu helfen, sich mit dem Universum zu verbinden."

    # say L1285 lis
    old "Can you understand what I am saying?"
    new "Kannst du verstehen, was ich sage?"

    # say L1287 pla
    old "I apologize if I disappointed you, I know you probably don't want me to be here anymore, I understand, just let me tell you it wasn't on purpose."
    new "Entschuldige, wenn ich dich enttäuscht habe, ich weiß, du willst wahrscheinlich nicht, dass ich hier bin, ich verstehe, lass mich dir nur sagen, dass es nicht absichtlich war."

    # say L1288 lis
    old "What are you talking about? I do want you to be here."
    new "Wovon redest du? Ich will doch, dass du hier bist."

    # say L1289 pla
    old "(Wait, what? Is she upset or not)"
    new "Warte, was? Ist sie sauer oder nicht?"

    # say L1290 lis
    old "I just need you to help me by doing the things right, I thought that you were learning with the sessions you are doing with me, am I wasting my time?"
    new "Ich brauche einfach deine Hilfe, indem du die Dinge richtig machst, ich dachte, du lernst mit den Sitzungen, die wir zusammen machen, verschwende ich meine Zeit?"

    # say L1291 pla
    old "... No, of course not, I'm sorry..."
    new "Nein, natürlich nicht, es tut mir leid..."

    # say L1292 lis
    old "I mean, you already know about this, you started a process, you should apply it to every activity you perform in your life... Even if it is sex... Yoga is deeply connected with sex."
    new "Ich meine, du weißt doch schon Bescheid, du hast den Prozess gestartet, du solltest es auf jede Aktivität in deinem Leben anwenden... Auch wenn es um Sex geht... Yoga ist tief mit Sex verbunden."

    # say L1293 lis
    old "We definitely need to discuss this more... Wait a minute..."
    new "Wir müssen das definitiv weiter besprechen... Moment mal..."

    # say L1295 lis
    old "I think... That could work! if she is into you because of the sex, you guys can actually do a great job if you apply the yoga knowledge to the sex experience..."
    new "Ich denke... Das könnte funktionieren! Wenn sie auf dich steht wegen dem Sex, könnt ihr beide wirklich großartige Dinge machen, wenn ihr das Yogawissen auf eure sexuelle Erfahrung anwendet."

    # say L1297 lis
    old "Actually if she is interested in you because of the sex, the yoga can make that experience richer than you both can imagine, she won't ever let you go."
    new "Wenn sie sich für dich interessiert, weil du gut im Bett bist, kann Yoga das Erlebnis reicher machen, als ihr euch beide vorstellen könnt. Sie wird dich nie wieder loslassen."

    # say L1298 lis
    old "[pla], I need you to get ready, tomorrow you will have the most important lesson of your life, I'll wait for you, I will get ready too, to teach you very well."
    new "[pla], du musst dich vorbereiten, morgen hast du die wichtigste Lektion deines Lebens. Ich warte auf dich, ich werde mich auch vorbereiten, um dich gut zu unterrichten."

    # say L1302 pla
    old "(I don't get it, but I feel better to knowing she is not as mad as I thought she would be.)"
    new "Ich verstehe es nicht, aber ich fühle mich besser, weil sie nicht so wütend ist, wie ich dachte."

    # say L1320 lis
    old "Hi, I am glad you came."
    new "Hi, ich freue mich, dass du gekommen bist."

    # say L1321 pla
    old "Hello, thanks for this new opportunity."
    new "Hallo, danke für diese neue Chance."

    # say L1322 lis
    old "I didn't mean to be mad at you yesterday, it's just that... This is very important for me,  this is my destiny..."
    new "Ich wollte dir gestern nicht böse sein, es ist nur... Das ist sehr wichtig für mich, das ist mein Schicksal..."

    # say L1323 pla
    old "I... Understand..."
    new "Ich... verstehe..."

    # say L1324 lis
    old "That's not important... Not anymore, it was a new opportunity, the universe showed me there are different ways to reach the goal I am pursuing."
    new "Das ist nicht wichtig... Nicht mehr. Es war eine neue Chance, das Universum hat mir gezeigt, dass es verschiedene Wege gibt, mein Ziel zu erreichen."

    # say L1325 lis
    old "Let's go to the room."
    new "Lass uns ins Zimmer gehen."

    # say L1334 lis
    old "You see, Yoga is like a language, it helps you to understand the world and its people, we are all energy and love, that is why we need to balance our spirit so we can merge..."
    new "Du siehst, Yoga ist wie eine Sprache, sie hilft dir, die Welt und ihre Menschen zu verstehen. Wir sind alle Energie und Liebe, deshalb müssen wir unseren Geist ausbalancieren, damit wir uns vereinen können..."

    # say L1335 lis
    old "That's why it is not weird that you can connect with another person so easily, that your bodies want to share their energies and eventually become one..."
    new "Deshalb ist es nicht seltsam, dass du dich so leicht mit einer anderen Person verbinden kannst, dass eure Körper ihre Energien teilen und letztendlich eins werden wollen..."

    # say L1337 lis
    old "I meant what I told you, you started the process, you should apply it on every activities you perform in your life... Even if it's sex...."
    new "Ich meinte, was ich dir gesagt habe, du hast den Prozess gestartet, du solltest es auf jede Aktivität in deinem Leben anwenden... Auch wenn es Sex ist..."

    # say L1338 lis
    old "That's why I decided to prepare this lesson, it's really important because this way you will realize how everything is connected by energies."
    new "Deswegen habe ich diese Lektion vorbereitet, es ist wirklich wichtig, weil du so erkennst, wie alles durch Energien verbunden ist."

    # say L1339 lis
    old "You see, if you do some research you will find a very big part of yoga focuses on postures, you can find them according to your body type, the benefits it can give..."
    new "Du siehst, wenn du ein bisschen recherchierst, findest du heraus, dass ein großer Teil des Yoga sich auf Haltungen konzentriert. Du kannst sie nach deinem KörperTyp auswählen und die Vorteile, die sie bieten..."

    # say L1340 lis
    old "I have a complete library if you want, but if I asked you 'what is sex about' what would you say?"
    new "Ich habe eine komplette Bibliothek, wenn du willst, aber wenn ich dich fragen würde, worum es beim Sex geht, was würdest du sagen?"

    # say L1341 pla
    old "I think... Positions?"
    new "Ich denke... Positionen?"

    # say L1342 lis
    old "That's what everyone gets wrong... sex is bigger than the position you choose, as is Yoga, bigger than a posture to meditate or meditation its itself."
    new "Das ist der Fehler, den alle machen... Sex ist größer als die Position, die du wählst, genauso wie Yoga größer ist als eine Haltung zum Meditieren oder Meditation selbst."

    # say L1343 lis
    old "However both have that in common, the posture, so this is how you are going to apply all the yoga knowledge you have on this important activity..."
    new "Allerdings haben beide das Gemeinsame, die Haltung, also wirst du all dein Yogawissen auf diese wichtige Tätigkeit anwenden."

    # say L1344 lis
    old "Let's start."
    new "Lass uns anfangen."

    # say L1348 pla
    old "Wait, what are you doing?"
    new "Warte, was machst du da?"

    # say L1349 lis
    old "What do you think I'm doing? We are here to learn about Yoga and sex, to see how they are meant to be... So you should get naked too..."
    new "Was denkst du, was ich mache? Wir sind hier, um Yoga und Sex kennenzulernen, um zu sehen, wie sie zusammengehören... Also solltest du dich auch ausziehen..."

    # say L1350 pla
    old "... Alright."
    new "... Okay."

    # say L1355 lis
    old "Now, let's start properly. I will lie down but I need you to get on your knees and hold my legs... Please relax yourself so you can feel it too."
    new "Okay, lass uns richtig damit beginnen. Ich werde mich hinlegen, aber ich brauche, dass du dich hinkniest und meine Beine hältst... Bitte entspann dich, damit du es auch spüren kannst."

    # say L1366 lis
    old "Excellent, this is very interesting position, Do you like it?"
    new "Das ist eine sehr interessante Position, magst du sie?"

    # say L1367 pla
    old "... Yes."
    new "... Ja."

    # say L1368 lis
    old "This is a very intimate way to share your energy, as you could see, it was quite demanding but very rewarding."
    new "Dies ist eine sehr intime Art, deine Energie zu teilen. Wie du sehen konntest, war es ziemlich anstrengend, aber auch sehr belohnend."

    # say L1369 lis
    old "So, let's start, move your hips and let me suck your penis."
    new "Dann lass uns anfangen, beweg deinen Hintern und lass mich deinen Schwanz blasen."

    # say L1370 pla
    old "(Oh god, yes!)"
    new "Oh Gott, ja!"

    # say L1372 lis
    old "I know, maybe this position is not going to be the very first option to propose, but you will estimate the proper moment to help a client..."
    new "Ich weiß, vielleicht ist diese Position nicht die erste Wahl, aber du wirst den richtigen Moment erkennen, um einem Kunden zu helfen..."

    # say L1373 lis
    old "I hope you can start to tell apart sex and a real connection with a person thru Yoga?"
    new "Ich hoffe, du kannst anfangen, Sex und eine echte Verbindung zu einer Person durch Yoga auseinanderzuhalten?"

    # say L1387 lis
    old "Do realize how much energy you let out by using the proper technique? I mean using these yoga positions in some sexual practices?"
    new "Spürst du, wie viel Energie du durch die richtige Technik freisetzt? Ich meine, diese Yogastellungen in sexuellen Praktiken zu nutzen?"

    # say L1389 lis
    old "I'm glad you can realize how different it is."
    new "Ich freue mich, dass du erkennst, wie unterschiedlich das ist."

    # say L1390 lis
    old "Now, let's try another option, this can be easier for any of your customers but a bit more demanding for you, however I know you can do it."
    new "Lass uns jetzt eine andere Option ausprobieren, das kann für deine Kunden einfacher sein, aber ein bisschen mehr von dir verlangen. Ich weiß, dass du das kannst."

    # say L1392 lis
    old "This position implies a lot more effort on your end, even though your partner may be experienced, almost the other person's weight will rely on your body."
    new "Diese Position verlangt viel mehr von dir, auch wenn dein Partner erfahren sein mag, wird fast das gesamte Gewicht der anderen Person auf deinem Körper lasten."

    # say L1393 lis
    old "There are different conditions that can make it easier or not, however I think, Anastasia, will need more of your assistance because of her height."
    new "Es gibt verschiedene Bedingungen, die es einfacher oder schwieriger machen können, aber ich denke, Anastasia wird mehr von deiner Unterstützung brauchen, wegen ihrer Größe."

    # say L1394 lis
    old "This time, I will hold my right leg up, and support a bit on my arms, I will need you to help me keep my balance and also to guide the entire movement, follow your intuition."
    new "Dieses Mal halte ich mein rechtes Bein hoch und stütze mich ein bisschen mit den Armen ab. Ich brauche deine Hilfe, um das Gleichgewicht zu halten und die Bewegung zu leiten. Vertrau auf dein Gefühl."

    # say L1407 lis
    old "Wow, that was quite good, I'm exhausting, how did you feel?"
    new "Wow, das war ziemlich gut, ich bin erschöpft, wie hast du dich gefühlt?"

    # say L1408 pla
    old "It was... Quite interesting."
    new "Es war... ziemlich interessant."

    # say L1409 lis
    old "Right? I felt so much of me and you at the same time, it was like embracing life, I can see your progress, how calm you can perform and still communicate."
    new "Stimmt? Ich hab so viel von uns beiden gespürt, es war wie ein Leben umarmen. Ich sehe deinen Fortschritt, wie ruhig du dich bewegen kannst und trotzdem kommunizierst."

    # say L1410 lis
    old "The tantric massages gave you an impressive control over your chakras, you looked more than focused."
    new "Die tantrischen Massagen haben dir eine beeindruckende Kontrolle über deine Chakras gegeben, du sahst mehr als konzentriert aus."

    # say L1411 lis
    old "Remember this is a training, from now on, you must use these positions, actually, try it in the next session, do it at the end of the session you have been doing."
    new "Erinnere dich, das ist eine Ausbildung, ab jetzt musst du diese Positionen benutzen, versuch es in der nächsten Sitzung, mach es am Ende der Sitzung, die du gerade durchführst."

    # say L1412 lis
    old "Try to introduce it carefully so she can receive it positively, and the results can be more productive."
    new "Versuch es vorsichtig einzuführen, damit sie es positiv aufnimmt und die Ergebnisse produktiver sind."

    # say L1413 pla
    old "(Is she really asking me to do that)"
    new "(Stellt sie sich das wirklich von mir vor?)"

    # say L1415 lis
    old "Yes, That way she will not only enjoy your lesson but also learn what she wanted to."
    new "Ja, dann wird sie nicht nur deinen Unterricht genießen, sondern auch lernen, was sie wollte."

    # say L1417 lis
    old "Please, be on time tomorrow!"
    new "Bitte, sei morgen pünktlich!"

    # say L1418 pla
    old "Not a problem! See you then."
    new "Kein Problem! Bis dann."

    # say L1439 ana
    old "So, how are you today?"
    new "So, wie geht es dir heute?"

    # say L1440 lis
    old "I am very well, thanks for asking, it's nice to see you again."
    new "Ich bin sehr gut, danke fürs Nachfragen, schön dich wiederzusehen."

    # say L1441 ana
    old "Thank you, I came today with my best mood..."
    new "Danke, ich bin heute mit meiner besten Laune gekommen..."

    # say L1442 lis
    old "That's terrific, I am sure today's lesson will change your perception of the previous ones, we planned a very great session that you will find useful."
    new "Das ist toll, ich bin sicher, dass der heutige Unterricht deine Meinung zu den vorherigen ändern wird. Wir haben eine sehr gute Sitzung geplant, die dir sicherlich nützlich sein wird."

    # say L1448 ana
    old "Ok, thank you... Every day I can learn something new... Hi [pla], nice to see you again."
    new "Ok, danke... Jeden Tag kann ich etwas Neues lernen... Hallo [pla], schön dich wiederzusehen."

    # say L1451 pla
    old "Hello guys..."
    new "Hallo Leute..."

    # say L1454 lis
    old "Please, enjoy yourselves... The yoga room is already prepared for your session."
    new "Bitte, macht es euch gemütlich... Der Yogaraum ist schon für eure Sitzung vorbereitet."

    # say L1455 pla
    old "Thank you Lisa, Anastasia please come in."
    new "Danke Lisa, Anastasia komm bitte rein."

    # say L1456 ana
    old "Sure, I can't wait."
    new "Klar, ich freue mich schon drauf."

    # say L1464 ana
    old "I need to confess that I did not study for today's lesson, so... Professor are you going to punish me?"
    new "Ich muss gestehen, dass ich für die heutige Stunde nicht gelernt habe, also... Herr Professor, werden Sie mich bestrafen?"

    # say L1465 pla
    old "... I- (I should be confident, that's what Lisa expect from me.)"
    new "Ich... ich sollte selbstbewusst sein, das erwartet Lisa von mir."

    # say L1466 ana
    old "What about if we just improvise?"
    new "Was wäre, wenn wir einfach improvisieren?"

    # say L1480 ana
    old "Are you going to fuck me harder today?"
    new "Wirst du mich heute härter ficken?"

    # say L1487 ana
    old "Oh yeah baby, Fuck me like that again."
    new "Oh ja Baby, fick mich noch mal so."

    # say L1496 pla
    old "There is something new I want you to try."
    new "Da ist etwas Neues, das ich ausprobieren will."

    # say L1497 ana
    old "Wow, I can see you don't need to rest young man, I am anxious to try it even if I feel a bit tired."
    new "Wow, ich sehe, du brauchst wirklich keine Pause, junger Mann. Ich bin gespannt, es auszuprobieren, auch wenn ich ein bisschen müde bin."

    # say L1498 pla
    old "We still have a lot to learn."
    new "Wir haben noch viel zu lernen."

    # say L1499 ana
    old "Sign me up."
    new "Melde mich an."

    # say L1500 pla
    old "I will need you to relax your body so I can take your legs, I will hold them with my hands, but I will need you to hold me firmly with your hands."
    new "Ich brauche, dass du deinen Körper entspannst, damit ich deine Beine nehmen kann. Ich halte sie mit meinen Händen, aber du musst mich fest mit deinen Händen halten."

    # say L1501 ana
    old "I will do anything you ask of me."
    new "Ich werde alles tun, was du von mir verlangst."

    # say L1502 pla
    old "Alright... Let's start."
    new "Okay... Lass uns anfangen."

    # say L1509 ana
    old "Oh, wow you are getting creative!"
    new "Oh, wow, du bist ja richtig kreativ!"

    # say L1519 ana
    old "Oh my god, that was unbelievable, I am so astonished! Is this the exercise Lisa mentioned you were preparing lately?"
    new "Oh mein Gott, das war unglaublich, ich bin total baff! Ist das die Übung, von der Lisa gesagt hat, dass du dich darauf vorbereitest?"

    # say L1521 ana
    old "So does she know? Wow, You guys don't stop surprising me."
    new "Dann weiß sie Bescheid? Wow, ihr hört nie auf mich zu überraschen."

    # say L1523 ana
    old "Let me ask you something, because this has blown my mind... Does Lisa offer these lessons with more than one instructor? I mean a team session with her would be pretty interesting..."
    new "Lass mich was fragen, das hat mich echt umgehauen... Bietet Lisa so was mit mehr als einem Trainer an? Ich meine, eine Gruppensession mit ihr wäre ziemlich interessant..."

    # say L1524 pla
    old "I- I'm not sure, I think I will need to ask her."
    new "Ich- Ich bin mir nicht sicher, ich denke, ich muss sie fragen."

    # say L1525 ana
    old "Alright, I have to go, let's get dressed."
    new "Okay, ich muss los, ziehen wir uns an."

    # say L1540 lis
    old "So guys, how was the session today?"
    new "Also Leute, wie war die Session heute?"

    # say L1542 ana
    old "Lisa, I think this has been the most incredible Yoga experience I have had in my entire life. I love your work, and of course your... Teamwork."
    new "Lisa, ich denke, das war die unglaublichste Yogastunde, die ich je hatte. Ich liebe deine Arbeit und natürlich eure... Teamarbeit."

    # say L1543 ana
    old "Some friends are very interested in coming, I have persuaded them because of my experience, so hope you are ready for them."
    new "Einige Freunde sind sehr interessiert mitzukommen, ich habe sie überzeugt, weil es bei mir so unglaublich war. Hoffe, ihr seid bereit für sie."

    # say L1544 lis
    old "I appreciate you sharing your experience with your friends. I am sure you will learn more, do not doubt we will do our best to surprise you and your friends every time."
    new "Ich schätze es, dass du deine Erfahrung mit deinen Freunden teilst. Ich bin sicher, ihr werdet noch mehr lernen, zweifel nicht daran, dass wir unser Bestes tun werden, um dich und deine Freunde jedes Mal zu überraschen."

    # say L1545 ana
    old "Love you guys, see you next time."
    new "Ich liebe euch, bis zum nächsten Mal."

    # say L1546 lis
    old "Sure, I have already scheduled your next appointment so I will be calling you."
    new "Klar, ich habe euren nächsten Termin schon eingetragen, also erwarte meinen Anruf."

    # say L1547 ana
    old "Perfect, I will look forward to."
    new "Perfekt, ich freue mich drauf."

    # say L1548 lis
    old "Nice to have you here, bye bye!"
    new "Schön, dass du da warst, tschüss!"

    # say L1549 ana
    old "See you next time."
    new "Bis zum nächsten Mal."

    # say L1559 lis
    old "Did you feel it?"
    new "Hast du es gespürt?"

    # say L1560 pla
    old "Yes... I- I did."
    new "Ja... ich... ich hab's gespürt."

    # say L1561 lis
    old "This is what we need to share with others, once you understand the language of the universe, you can translate to others, I am very proud that you are improving."
    new "Das ist das, was wir anderen mitteilen müssen, sobald du die Sprache des Universums verstehst, kannst du sie anderen übersetzen. Ich bin sehr stolz, dass du dich verbessert hast."

    # say L1563 lis
    old "I know you are quite good however remember this is a process... we need to continue working... So... we need to continue working on your chakra."
    new "Ich weiß, dass du schon ziemlich gut bist, aber denk dran, das ist ein Prozess... Wir müssen weiter daran arbeiten... Also... wir müssen weiter an deinem Chakra arbeiten."

    # say L1565 lis
    old "I'll be waiting for you tomorrow night, those tantric sessions need to continue, as you saw today, you will become a very great Yoga instructor, so don't stop."
    new "Ich warte auf dich morgen Abend, die tantrischen Sitzungen müssen weitergehen, wie du heute gesehen hast, wirst du ein großartiger Yogalehrer, also hör nicht auf."

    # say L1587 lis
    old "Hello, I was waiting for you."
    new "Hallo, ich habe auf dich gewartet."

    # say L1589 lis
    old "I was very excited because with this session we concluded this chapter with your chakras, remember the process is to find the perfect balance is not something we can call finished."
    new "Ich war sehr aufgeregt, weil wir mit dieser Sitzung dieses Kapitel mit deinen Chakren abgeschlossen haben. Denk dran, das Finden des perfekten Gleichgewichts ist etwas, das man nie als abgeschlossen betrachten kann."

    # say L1590 pla
    old "I understand, I will continue working on it."
    new "Ich verstehe, ich werde weiter daran arbeiten."

    # say L1591 lis
    old "Actually, I wanted you to know that we can still work again on this, since this is a very good exercise for us both you can count on me to help you."
    new "Eigentlich wollte ich dir sagen, dass wir nochmal drüber arbeiten können, da es für uns beide eine sehr gute Übung ist. Du kannst dich auf mich verlassen."

    # say L1592 pla
    old "I really... Appreciate everything you do for me."
    new "Ich schätze echt, was du alles für mich tust."

    # say L1593 lis
    old "It's my way to say thank you, I want to thank you for your hard work."
    new "Das ist meine Art, mich zu bedanken. Ich will dich für deine harte Arbeit danken."

    # say L1594 lis
    old "Let's go to the room to start the session..."
    new "Lass uns ins Zimmer gehen, um die Sitzung zu beginnen..."

    # say L1602 lis
    old "Regular sex is about exploring and feeling pleasure desperately... The tantric experience is different, it's about the energy and sensations you can have with your partner."
    new "Regulärer Sex geht darum, Vergnügen zu erkunden und verzweifelt Lust zu spüren... Die tantrische Erfahrung ist anders, es geht um die Energie und die Empfindungen, die du mit deinem Partner teilen kannst."

    # say L1603 lis
    old "Sex consists of penetration and cumming, that takes out part of the connection, tantric sex otherwise means eye contacting, touching, breathing, to hear the noises."
    new "Sex besteht aus Penetration und Abspritzen, das nimmt einen Teil der Verbindung heraus, tantrischer Sex bedeutet hingegen Augenkontakt, Berühren, Atmen, die Geräusche wahrzunehmen."

    # say L1605 lis
    old "That is why we start with the massage, so we can open our senses, open ourselves to the other."
    new "Deshalb fangen wir mit der Massage an, damit wir unsere Sinne öffnen und uns dem anderen öffnen können."

    # say L1606 lis
    old "Please lie down to start the massage..."
    new "Bitte leg dich hin, um die Massage zu beginnen..."

    # say L1621 lis
    old "We will need to work harder today so let me start with some lubrication, the universe it self is all about love, so nothing better than kisses to start, to help you expel the negative chakra."
    new "Wir müssen heute härter arbeiten, also lass mich mit etwas Gleitmittel beginnen. Das Universum selbst dreht sich um Liebe, also gibt es nichts Besseres als Küsse, um zu beginnen und dir zu helfen, die negative Chakras abzustoßen."

    # say L1623 lis
    old "Just relax, remember to release the tension so you can do the exercise effectively."
    new "Entspann dich einfach, vergiss die Anspannung, damit du die Übung effektiv machen kannst."

    # say L1639 pla
    old "That was great... I felt really good... Are we done?"
    new "Das war toll... Ich hab mich echt gut gefühlt... Sind wir fertig?"

    # say L1640 lis
    old "Of course not, since the main purpose is to finally connect deeply with yourself, there is a lot more to learn. I have a very special exercise for you to conclude this chakra training."
    new "Natürlich nicht, da das Hauptziel letztendlich ein tiefes Verbindung mit dir selbst herzustellen ist, gibt es noch viel mehr zu lernen. Ich habe eine sehr besondere Übung für dich, um diese Chakrainseln abzuschließen."

    # say L1641 lis
    old "I will need you to lie down again so I can do the movements needed."
    new "Du musst dich wieder hinlegen, damit ich die nötigen Bewegungen machen kann."

    # say L1642 lis
    old "Let me show you how it works..."
    new "Lass mich dir zeigen, wie es funktioniert..."

    # say L1648 lis
    old "Feel all inside me."
    new "Spür alles in mir."

    # say L1649 lis
    old "I'm feeling all of you."
    new "Ich spüre dich ganz."

    # say L1659 lis
    old "To be honest, I feel you're shining lately, these exercises have brought you wellness to your spirit and I can perceive it, I hope you can see the changes too."
    new "Ehrlich gesagt, ich spüre, dass du in letzter Zeit strahlst, diese Übungen haben deinem Geist Wohlbefinden gebracht und ich kann es wahrnehmen, ich hoffe, du siehst die Veränderungen auch."

    # say L1660 pla
    old "For sure, I think I feel much better now."
    new "Klar, ich denke, ich fühle mich viel besser jetzt."

    # say L1661 lis
    old "Remember that it is really important to continue this training, if you want to reach out to me any night, so we can work on your chakra training..."
    new "Denk dran, es ist wirklich wichtig, mit der Trainingseinheit weiterzumachen. Wenn du nachts zu mir kommen willst, können wir an deinem Chakra-Training arbeiten..."

    # say L1662 lis
    old "You know it helps you to stay more balanced and focused in your chakras... I'll have nights free so we can repeat the tantric ritual anytime you need."
    new "Du weißt, dass es dir hilft, mehr Balance und Fokus in deinen Chakren zu finden... Ich habe abends Zeit, wir können das tantrische Ritual jederzeit wiederholen, wenn du es brauchst."

    # say L1663 lis
    old "I think, now that you have balanced your energies, and your chakra muladhara has been controlled, you can even lead the tantric sessions with some of our customers."
    new "Ich denke, jetzt, wo du deine Energien ausbalanciert hast und dein Chakra Muladhara unter Kontrolle hast, kannst du sogar die tantrischen Sitzungen mit einigen unserer Kunden leiten."

    # say L1664 lis
    old "I'm sure the universe has great things for you, you already know you can count on me."
    new "Ich bin sicher, das Universum hat großartige Dinge für dich, du weißt ja, dass du dich auf mich verlassen kannst."

    # say L1665 pla
    old "I appreciate that."
    new "Ich schätze das."

    # say L1666 lis
    old "Don’t forget you can keep up the yoga sessions with Anastasia in the afternoons, whenever you’ve got time!"
    new "Vergiss nicht, dass du die Yogastunden mit Anastasia nachmittags machen kannst, wann immer du Zeit hast!"

    # say L1667 lis
    old "Your lessons have evolved now that you are better balanced and applying your yoga knowledge to the sex connection..."
    new "Deine Übungen haben sich entwickelt, seit du besser balancierst und dein Yogawissen in die sexuelle Verbindung einbringst."

    # say L1668 lis
    old "If you feel you need to review the previous trainings we have done, any morning I'll be working on that so you prepare better always to help your customers."
    new "Wenn du das Gefühl hast, dass du die früheren Trainings noch einmal durchgehen musst, mache ich jeden Morgen daran weiter, damit du dich besser auf deine Kunden vorbereiten kannst."

    # say L1670 lis
    old "I am happy to hear that... We need to rest now, have a good night [pla]."
    new "Ich freue mich, das zu hören... Wir müssen jetzt ausruhen, gute Nacht [pla]."

    # say L1671 pla
    old "Ok, good night Lisa!"
    new "Ok, gute Nacht Lisa!"

    # say L1695 pla
    old "Hey Lisa! It's so nice to see you, how are you?"
    new "Hey Lisa! Es ist so schön, dich zu sehen, wie geht es dir?"

    # say L1696 lis
    old "Hi dear! I'm very good, and you?"
    new "Hi Liebling! Mir geht es sehr gut, und dir?"

    # say L1697 pla
    old "I'm not so fine, we're having some financial issues..."
    new "Ich bin nicht so gut, wir haben gerade finanzielle Probleme..."

    # say L1698 lis
    old "Really? I'm so sorry... How could I help you?"
    new "Wirklich? Das tut mir leid... Wie könnte ich dir helfen?"

    # say L1699 pla
    old "Actually, that's why I'm here. I thought maybe you needed someone to help you out with your business, I really need to find a job."
    new "Tatsächlich, deshalb bin ich hier. Ich dachte, vielleicht brauchst du jemanden, der dir bei deinem Geschäft hilft, ich muss echt dringend eine Arbeit finden."

    # say L1701 pla
    old "I could work on anything... Doesn't matter what it's."
    new "Ich könnte bei allem helfen... Ist mir egal, was es ist."

    # say L1702 lis
    old "Sadly, I can't hire you. I don't really need help right now."
    new "Tut mir leid, aber ich kann dich im Moment nicht einstellen. Ich brauche wirklich keine Hilfe."

    # say L1703 lis
    old "I haven't had much sales lately... I'm barely doing some Yoga classes for a few people."
    new "Ich habe in letzter Zeit nicht viele Verkäufe gehabt... Ich mache gerade nur ein paar Yogastunden für einige Leute."

    # say L1704 lis
    old "However, I'm planning on improving my sales by implementing some new marketing strategies and I might need you sometime soon."
    new "Aber ich plane, meine Verkäufe durch neue Marketingstrategien zu verbessern und es könnte sein, dass ich dich in naher Zukunft brauche."

    # say L1706 lis
    old "But not really right now..."
    new "Aber nicht wirklich im Moment..."

    # say L1708 lis
    old "Sorry about that..."
    new "Tut mir leid..."

    # say L1709 pla
    old "No, it's ok. Not your fault, I gotta keep looking... I guess."
    new "Nein, ist schon gut. Ist nicht deine Schuld, ich muss weiter suchen... schätze ich."

    # say L1710 lis
    old "You'll find something good."
    new "Du wirst schon was Gutes finden."

    # say L1711 pla
    old "Hmm, I hope. Thanks anyway, it's always nice to see you."
    new "Hmm, ich hoffe es. Danke trotzdem, es ist immer schön, dich zu sehen."

    # say L1712 lis
    old "I say the same... I'm glad you came to visit."
    new "Ich sage das Gleiche... Ich bin froh, dass du gekommen bist."

    # say L1714 pla
    old "I should go, I really have to find a job, see you Lisa."
    new "Ich sollte gehen, ich muss echt einen Job finden, bis dann Lisa."

    # say L1737 pla
    old "Hmm, this is weird, she should be here at this time of day."
    new "Hmm, das ist komisch, sie sollte zu dieser Tageszeit hier sein."

    # say L1738 pla
    old "Lisa! Are you here?"
    new "Lisa! Bist du hier?"

    # say L1739 pla
    old "So odd, where is she?"
    new "Komisch, wo steckt sie?"

    # say L1754 pla
    old "What is that noise? I guess she's in the yoga room."
    new "Was ist das für ein Geräusch? Ich schätze, sie ist im Yogaraum."

    # say L1766 pla
    old "{i}(I- I wasn't expecting that.){/i}"
    new "{i}(Ich- Ich habe das nicht erwartet.){/i}"

    # say L1767 pla
    old "{i}(That's- Umm... Quite an interesting position.){/i}"
    new "{i}(Das ist- Äh... Eine ziemlich interessante Position.){/i}"

    # say L1783 lis
    old "Oh, [pla], I didn't realize you were around."
    new "Oh, [pla], ich habe dich gar nicht bemerkt."

    # say L1784 lis
    old "I'm sorry for not noticing before."
    new "Es tut mir leid, dass ich dich vorher nicht bemerkt habe."

    # say L1786 pla
    old "I- I'm sorry, Lisa! I- I didn't mean to spy on you."
    new "I- Ich bin sorry, Lisa! I- Ich wollte dich nicht belauschen."

    # say L1788 lis
    old "It's quite alright, I didn't realize I left the door open."
    new "Das ist schon in Ordnung, ich habe gar nicht gemerkt, dass die Tür offen war."

    # say L1789 lis
    old "Besides, all I was doing was resonating my Muladhara chakra with the energy of the universe."
    new "Außerdem habe ich nur meinen Muladhara-Chakra mit der Energie des Universums in Resonanz gebracht."

    # say L1790 lis
    old "There's nothing to hide about that. So you don't need to worry about anything."
    new "Da ist nichts, worüber man sich Sorgen machen muss."

    # say L1794 lis
    old "So, what brings you here?"
    new "Also, was bringt dich hierher?"

    # say L1796 pla
    old "Uhmm, w- well, I just wanted to see how you're doing."
    new "Ähm, na ja, ich wollte einfach sehen, wie es dir geht."

    # say L1797 pla
    old "You know, to check how everything's going."
    new "Du weißt schon, um zu sehen, wie alles läuft."

    # say L1799 lis
    old "Well, I've been a little stressed, you know, this whole business thing is a little tiring."
    new "Na ja, ich bin ein bisschen gestresst, weißt du, das ganze Geschäftsstress ist ziemlich anstrengend."

    # say L1800 lis
    old "But that's precisely why I was just realigning my energy with the universe."
    new "Aber genau deshalb habe ich gerade meine Energie mit dem Universum realigniert."

    # say L1801 lis
    old "After stimulating my Muladhara chakra, I feel like I've been relieved of all stress now."
    new "Nachdem ich meinen Muladhara-Chakra gestimuliert habe, fühle ich mich jetzt, als wäre alles Stress von mir abgefallen."

    # say L1805 pla
    old "Is it that effective?"
    new "Ist es wirklich so effektiv?"

    # say L1806 pla
    old "{i}(I mean, it just looked like she was just jacking off to me.){/i}"
    new "{i}(Meaning, es sah einfach so aus, als würde sie sich nur einen runterholen.){/i}"

    # say L1807 lis
    old "Of course it is! The Muladhara chakra is the second of the body and the one that regulates our sacred sexual energy."
    new "Natürlich ist es das! Der Muladhara-Chakra ist der zweite im Körper und regelt unsere heilige sexuelle Energie."

    # say L1808 lis
    old "It may have looked like I was just masturbating, but it's a lot more than that."
    new "Es mag so ausgesehen haben, als würde ich mich nur befriedigen, aber es ist viel mehr als das."

    # say L1809 lis
    old "The Muladhara regulates our self-esteem."
    new "Das Muladhara regelt unser Selbstwertgefühl."

    # say L1810 lis
    old "By properly stimulating it you can improve your mood because your energy's in line with the rest of the universe."
    new "Durch die richtige Stimulation kannst du deine Stimmung verbessern, weil deine Energie im Einklang mit dem Rest des Universums ist."

    # say L1812 pla
    old "Uh... I- I see."
    new "Uh... Ich... Ich sehe."

    # say L1813 pla
    old "So, this {i}'Proper stimulation'{/i}, is that why you were upside down?"
    new "Also, diese {i}'richtige Stimulation'{/i}, deshalb warst du kopfüber?"

    # say L1815 lis
    old "Yes, that's right."
    new "Ja, genau."

    # say L1816 lis
    old "By taking that position, I was letting my energy flow outwards from my head."
    new "Durch diese Position habe ich mein Energiefluss von meinem Kopf nach außen gesteigert."

    # say L1817 lis
    old "And replenishing my Muladhara chakra with positive energy coming from the top."
    new "Und ich fülle meinen Muladhara-Chakra mit positiver Energie, die von oben kommt."

    # say L1818 lis
    old "It's tremendously effective [pla], I highly recommend it to you."
    new "Das ist unglaublich effektiv [pla], ich kann es dir nur empfehlen."

    # say L1820 pla
    old "Y- you do?"
    new "Y- du tust?"

    # say L1822 lis
    old "Oh yeah, it's somewhat difficult to do."
    new "Oh ja, es ist etwas schwierig, das hinzu kriegen."

    # say L1823 lis
    old "But I'm sure I can guide you towards a path of proper alignment with the universe."
    new "Aber ich bin sicher, dass ich dich auf den richtigen Pfad führen kann, um dich mit dem Universum auszurichten."

    # say L1825 pla
    old "Uh, I- I guess I'll think about it."
    new "Ich, ich werd's mir überlegen."

    # say L1826 lis
    old "Oh, by the way, I was hoping you'd come, seems like the energies drew you here. It's so beautiful when the universe conspires in your favor."
    new "Oh, übrigens, ich hatte gehofft, dass du kommst, scheint so, als hätten die Energien dich hierher gezogen. Es ist wunderschön, wenn das Universum für dich arbeitet."

    # say L1827 pla
    old "Oh, do you need me for something?"
    new "Oh, brauchst du mich für was?"

    # say L1828 lis
    old "Yeah, but let me get dressed and comfy. Meet me downstairs and we'll chat for a bit."
    new "Klar, aber lass mich erst anziehen und gemütlich machen. Treffen wir uns unten und quatschen ein bisschen."

    # say L1829 pla
    old "Uh, yeah, sure. I'll be waiting downstairs."
    new "Klar, ich warte unten auf dich."

    # say L1840 lis
    old "I'm ready, thanks for waiting. I'm really glad you came today."
    new "Ich bin bereit, danke dass du gewartet hast. Ich freue mich echt, dass du heute gekommen bist."

    # say L1841 pla
    old "Uh, sure. So, what did you want to talk about?"
    new "Klar. Also, worüber wolltest du sprechen?"

    # say L1843 lis
    old "Well, you see, I need to ask a favor of you."
    new "Na ja, du siehst, ich muss dich um einen Gefallen bitten."

    # say L1845 pla
    old "Really? What is it?"
    new "Wirklich? Was ist es?"

    # say L1847 lis
    old "It's about this client that I have, I've been working with her for a while."
    new "Es geht um eine Kundin, mit der ich schon eine Weile arbeite."

    # say L1848 lis
    old "I would like you to be her instructor during her next class, instead of me."
    new "Ich würde gerne, dass du bei ihrem nächsten Kurs ihr Trainer bist, statt ich."

    # say L1850 pla
    old "Oh! Are you busy again? Sure, I'll cover you."
    new "Oh! Bist du wieder mal ausgebucht? Klar, ich übernehme für dich."

    # say L1851 lis
    old "No, it's nothing like that. I don't have anything else to do during that session."
    new "Nein, so ist es nicht. Ich habe während dieser Sitzung nichts anderes zu tun."

    # say L1853 pla
    old "So what is it?"
    new "Was ist es dann?"

    # say L1854 lis
    old "Well, she's come to every appointment without fail, she also does every yoga pose correctly."
    new "Na ja, sie kommt zu jedem Termin ohne Ausnahme und macht auch jede Yogapose perfekt."

    # say L1856 lis
    old "But in spite of that, I would say she's not actually doing well."
    new "Aber trotzdem würde ich sagen, es geht ihr nicht gut."

    # say L1857 pla
    old "She isn't?"
    new "Sie nicht?"

    # say L1859 lis
    old "Yeah, I'm not feeling her energy flowing the way it should."
    new "Nein, ich spüre ihre Energie einfach nicht so, wie sie sollte."

    # say L1861 lis
    old "It's hard to explain, but even though she's been progressing in terms of flexibility and poses."
    new "Es ist schwer zu erklären, aber trotzdem macht sie Fortschritte in Bezug auf Flexibilität und Posen."

    # say L1863 lis
    old "I still feel like she needs something else in order to thrive."
    new "Ich spüre trotzdem, dass sie noch etwas anderes braucht, um richtig zu gedeihen."

    # say L1864 pla
    old "And you think that {i}'something else'{/i} has to do with me?"
    new "Und du denkst, dass {i}'das Etwas andere'{/i} etwas mit mir zu tun hat?"

    # say L1865 lis
    old "Yes, that's correct."
    new "Ja, das stimmt."

    # say L1867 lis
    old "I think that maybe your masculine energy will be able to unearth whatever's stopping her from progressing."
    new "Ich denke, deine männliche Energie könnte das aufspüren, was sie davon abhält, voranzuschreiten."

    # say L1869 lis
    old "After all, you already helped Anastasia in a very effective way."
    new "Schließlich hast du Anastasia schon sehr effektiv geholfen."

    # say L1870 lis
    old "So I thought that it would be worth it to give it a go with this girl as well."
    new "Dann dachte ich, es wäre auch bei diesem Mädchen einen Versuch wert."

    # say L1872 pla
    old "Uh, well, if you say so, sure."
    new "Na ja, wenn du meinst, klar."

    # say L1873 pla
    old "I'll be happy to help you."
    new "Ich helfe dir gerne."

    # say L1875 lis
    old "That's great! I'll let her know about it and I'll see you in the afternoon then."
    new "Das ist toll! Ich sag's ihr Bescheid und dann sehen wir uns am Nachmittag."

    # say L1877 pla
    old "Sure, no problem, I'll see you later."
    new "Klar, kein Problem, ich sehe dich später."

    # say L1902 pla
    old "Hi Lisa, I came for the class you told me about-"
    new "Hi Lisa, ich bin wegen der Stunde, von der du mir erzählt hast, hier-"

    # say L1906 pla
    old "{i}(Is that Angelina? What's she doing here?){/i}"
    new "{i}(Ist das Angelina? Was macht sie hier?){/i}"

    # say L1907 ang
    old "{i}(Oh my God! That's [pla]! W- what is he doing here?!){/i}"
    new "{i}(O mein Gott! Das ist [pla]! W- was macht er hier?!){/i}"

    # say L1908 lis
    old "Hello [pla], you arrived just in time, this is Angelina, the client that you'll be helping today."
    new "Hallo [pla], du kommst gerade richtig, das ist Angelina, die Kundin, die du heute betreuen wirst."

    # say L1910 pla
    old "Uh, yeah... Hi A- Angelina, nice to meet you."
    new "Uh, ja... Hallo A- Angelina, nett dich kennenzulernen."

    # say L1912 ang
    old "Uh, yeah, hi to you too... Nice meeting you."
    new "Uh, ja, hallo... Schön, dich kennenzulernen."

    # say L1913 lis
    old "So, as I told you a moment ago, [pla] will be taking over your class today."
    new "Also, wie ich dir gerade gesagt habe, wird [pla] heute deinen Kurs übernehmen."

    # say L1917 ang
    old "Y- yes, of course. Please, continue."
    new "Ja, natürlich. Bitte, fahr fort."

    # say L1919 lis
    old "Okay, as I was saying earlier, he has been helping me recently by giving classes to some of my clients."
    new "Okay, wie ich schon gesagt habe, hilft er mir in letzter Zeit, indem er ein paar meiner Kunden unterrichtet."

    # say L1921 lis
    old "You don't have to worry about anything, he's very knowledgeable and he has a spectacular energy."
    new "Du musst dir keine Sorgen machen, er ist sehr erfahren und hat eine fantastische Ausstrahlung."

    # say L1924 lis
    old "So, I'm sure he'll be capable of helping you in the way you need."
    new "Dann bin ich sicher, dass er dir auf die Art helfen kann, die du brauchst."

    # say L1926 ang
    old "I- I see, well... I'll be in his care then."
    new "I- Ich sehe, na ja... Ich werde mich dann in seine Obhut begeben."

    # say L1928 lis
    old "Let's go to the yoga studio so you two can start your class."
    new "Lass uns ins Yogastudio gehen, damit ihr beide mit dem Kurs beginnen könnt."

    # say L1938 lis
    old "I'll leave you two alone so you can start with the session, I hope you enjoy it, Angelina."
    new "Ich lass euch zwei allein, damit ihr mit der Sitzung beginnen könnt, ich hoffe, es macht dir Spaß, Angelina."

    # say L1939 ang
    old "W- well, thank you."
    new "W- danke."

    # say L1941 pla
    old "We'll see you later."
    new "Wir sehen uns später."

    # say L1950 pla
    old "Uhh, alright, so..."
    new "Uhh, okay, dann..."

    # say L1956 pla
    old "I- I guess we better get started with the class."
    new "Ich glaube, wir sollten besser mit dem Unterricht anfangen."

    # say L1958 ang
    old "Wait a minute."
    new "Warte mal."

    # say L1960 ang
    old "Can you please tell me what you're doing here? I thought you were supposed to be Dr. Johnson's assistant."
    new "Kannst du mir bitte sagen, was du hier machst? Ich dachte, du solltest Dr. Johnsons Assistentin sein."

    # say L1961 ang
    old "How come I'm running into you here? And you're teaching yoga?"
    new "Wieso laufe ich dir hier über den Weg? Und du gibst Yogaunterricht?"

    # say L1963 ang
    old "What's next? Will you be my waiter if I go to a restaurant?"
    new "Was kommt als Nächstes? Wirst du mein Kellner, wenn ich ins Restaurant gehe?"

    # say L1964 pla
    old "Hmm, I can see why this would surprise you, but believe me, it was a surprise for me too."
    new "Hmm, ich verstehe, warum dich das überrascht, aber glaub mir, für mich war es auch eine Überraschung."

    # say L1966 pla
    old "But it's nothing like what you're imagining."
    new "Aber es ist ganz anders, als du denkst."

    # say L1968 pla
    old "I'm related to Lisa, she's my [mom2Rel]'s younger sister."
    new "Ich bin mit Lisa verwandt, sie ist die jüngere Schwester von meiner [mom2Rel]."

    # say L1970 pla
    old "And since she started the studio I've been giving her a hand with some particular clients."
    new "Und seit sie das Studio gegründet hat, helfe ich ihr bei einigen besonderen Kunden."

    # say L1971 pla
    old "But I swear that I didn't know that you were the client I was supposed to help with the class today."
    new "Aber ich schwöre, dass ich nicht wusste, dass du der Klient bist, den ich heute bei dem Kurs unterstützen sollte."

    # say L1973 pla
    old "She just came to my house asking me for a hand with a client, and that's it."
    new "Sie ist einfach zu mir nach Hause gekommen und hat mich um Hilfe mit einem Klienten gebeten, und das war's."

    # say L1975 ang
    old "I don't know."
    new "Ich weiß es nicht."

    # say L1977 ang
    old "It's just so weird that I keep running into you."
    new "Es ist einfach so seltsam, dass ich ständig auf dich treffe."

    # say L1978 pla
    old "I know, trust me, it's very weird for me too."
    new "Ich weiß, glaub mir, für mich ist es auch sehr seltsam."

    # say L1979 pla
    old "But if you let me, I'll be more than happy to help you with the class."
    new "Aber wenn du mich lässt, helfe ich dir gerne bei der Klasse."

    # say L1981 ang
    old "I guess that if Lisa says it's alright, I have no reason to not believe what you're saying."
    new "Ich denke, wenn Lisa sagt, dass es in Ordnung ist, habe ich keinen Grund, dir nicht zu glauben."

    # say L1982 ang
    old "So I guess I'll do it."
    new "Dann mach ich das wohl."

    # say L1984 pla
    old "Great! And hey, how's Roonie doing?"
    new "Super! Und, wie geht’s Roonie?"

    # say L1986 pla
    old "I bet he must be happy about the baby."
    new "Ich wette, er freut sich auf das Baby."

    # say L1987 ang
    old "Uhm, yeah... He's doing alright."
    new "Uhm, ja... Es geht ihm gut."

    # say L1988 pla
    old "I see, good, good. A- and how's the pregnancy been treating you?"
    new "Ich sehe, gut, gut. A- und wie geht es dir in der Schwangerschaft?"

    # say L1990 ang
    old "I've been alright... I think"
    new "Ich bin okay... glaube ich"

    # say L1991 ang
    old "The doctor told me that I should try to stay active during my pregnancy."
    new "Der Arzt hat mir gesagt, dass ich während der Schwangerschaft aktiv bleiben sollte."

    # say L1992 ang
    old "That's why I'm taking yoga lessons, I was told it's one of the best things that you could do as a pregnant woman."
    new "Deshalb mache ich Yoga, habe ich gehört, das ist eines der Besten, was man als schwangere Frau tun kann."

    # say L1993 pla
    old "Oh yeah?"
    new "Oh ja?"

    # say L1995 ang
    old "Yes, it's supposed to improve sleep by reducing stress, and also helping relieve anxiety."
    new "Ja, es soll den Schlaf verbessern, indem es Stress reduziert, und auch helfen, Angstzustände zu lindern."

    # say L1996 ang
    old "And apparently it helps to strengthen the muscles needed for childbirth."
    new "Und anscheinend hilft es auch, die Muskeln zu stärken, die für die Geburt wichtig sind."

    # say L1997 ang
    old "And the flexibility of course."
    new "Und die Flexibilität natürlich."

    # say L1998 ang
    old "So that's why I'm doing yoga."
    new "Deshalb mache ich Yoga."

    # say L1999 pla
    old "I see, that all makes a lot of sense."
    new "Ich sehe, das ergibt alles Sinn."

    # say L2007 pla
    old "Uhmm, w- well, what do you say we get started with the session."
    new "Hmm, w-was sagst du, wir fangen mit der Sitzung an."

    # say L2011 pla
    old "Alright, let's start with the first asana."
    new "Okay, lass uns mit der ersten Asana beginnen."

    # say L2012 pla
    old "This first one's called Setu Bandha."
    new "Dieser erste heißt Setu Bandha."

    # say L2013 ang
    old "Ok? Is it too hard?"
    new "Ok? Ist es zu schwer?"

    # say L2014 ang
    old "I mean, I ask because I'm pregnant."
    new "Ich meine, ich frage, weil ich schwanger bin."

    # say L2016 pla
    old "Nah, it's not too hard."
    new "Nah, es ist nicht zu schwer."

    # say L2017 pla
    old "Sure it can be a little challenging."
    new "Klar, es kann ein bisschen herausfordernd sein."

    # say L2018 pla
    old "But don't worry, I'll be there helping you during it."
    new "Aber mach dir keine Sorgen, ich helfe dir dabei."

    # say L2020 ang
    old "Ok, how do I do it?"
    new "Okay, wie mache ich das?"

    # say L2022 pla
    old "It's simple, just lay on your back with your knees up and your heels towards your butt."
    new "Es ist einfach, leg dich auf den Rücken, die Knie hoch und die Fersen Richtung Po."

    # say L2023 pla
    old "And then just push through the soles of your feet and lift your hips up, like making an arch."
    new "Und dann drückst du mit den Füßen ab und hebst dein Becken an, als würdest du eine Brücke bilden."

    # say L2024 ang
    old "Hmm, ok, I guess I get it."
    new "Hmm, okay, ich glaube, ich hab's kapiert."

    # say L2030 pla
    old "Yeah, you're doing it well, but you're a little tense through the shoulders."
    new "Ja, du machst es gut, aber du bist ein bisschen angespannt in den Schultern."

    # say L2031 pla
    old "Try to relax a little bit more."
    new "Versuch dich noch ein bisschen mehr zu entspannen."

    # say L2039 pla
    old "{i}(Hmm, I see what Lisa was telling me, she's doing the position right.){/i}"
    new "{i}(Hmm, ich sehe, was Lisa mir erzählt hat, sie macht die Position richtig.){/i}"

    # say L2040 pla
    old "{i}(But I can see that she's very tense.){/i}"
    new "{i}(Aber ich sehe, dass sie sehr angespannt ist.){/i}"

    # say L2042 pla
    old "Ok, that's very good, now let's move into the next one."
    new "Okay, das ist sehr gut, jetzt lassen wir uns in die nächste Position gleiten."

    # say L2051 pla
    old "Alright, that was a good start."
    new "Okay, das war ein guter Start."

    # say L2052 pla
    old "So I guess we can move into the next position."
    new "Dann können wir wohl zur nächsten Position übergehen."

    # say L2053 pla
    old "This one's called Balasana."
    new "Dies nennt sich Balasana."

    # say L2054 pla
    old "It's even easier than the previous one, but it's very good to stretch the shoulders and back."
    new "Es ist sogar einfacher als die vorherige, aber es ist sehr gut, um die Schultern und den Rücken zu dehnen."

    # say L2055 ang
    old "I see, how do I do it?"
    new "Ich verstehe, wie mache ich das?"

    # say L2057 pla
    old "It's simple, you're going to start in a tabletop pose."
    new "Es ist einfach, du beginnst in einer Tischhaltung."

    # say L2058 pla
    old "From there, just move your hips back and down while you leave your hands where they are."
    new "Dann bewegst du einfach dein Becken nach hinten und runter, während du deine Hände da lässt, wo sie sind."

    # say L2059 pla
    old "That will give you a proper stretch through your shoulders and back."
    new "Das wird dir einen guten Stretch durch die Schultern und den Rücken geben."

    # say L2061 ang
    old "Hmm, ok, I think I can do that."
    new "Hmm, okay, ich denke, das krieg ich hin."

    # say L2063 pla
    old "Yeah, and I'll be there to help you, so don't worry."
    new "Ja, und ich bin da, um dir zu helfen, also mach dir keine Sorgen."

    # say L2065 ang
    old "Ok, let's try it."
    new "Okay, lass es uns versuchen."

    # say L2068 ang
    old "Am I doing this right?"
    new "Mach ich das richtig?"

    # say L2071 pla
    old "Yeah, that's alright, but try to let go a little bit more."
    new "Ja, das ist gut, aber versuch dich noch mehr zu entspannen."

    # say L2072 ang
    old "A-alright."
    new "A-alles klar."

    # say L2079 ang
    old "{i}(Hmm, he's closer than before.){/i}"
    new "{i}(Hmm, er ist näher als vorhin.){/i}"

    # say L2080 ang
    old "{i}(What's this I'm starting to feel?){/i}"
    new "{i}(Was ist das, was ich jetzt spüre?){/i}"

    # say L2082 pla
    old "{i}(Why is she so stiff?){/i}"
    new "{i}(Warum ist sie so steif?){/i}"

    # say L2085 pla
    old "Ok, I think that's enough of this position, we can move on to the next one."
    new "Okay, ich denke, das reicht für diese Position. Lass uns zur nächsten übergehen."

    # say L2093 pla
    old "Ok, you're doing well so far."
    new "Ok, du machst das gut bisher."

    # say L2094 pla
    old "But I think you're still a little tense. So I want us to change into a more relaxed position."
    new "Aber ich denke, du bist noch ein bisschen angespannt. Lass uns in eine entspanntere Position wechseln."

    # say L2095 pla
    old "The idea for this next position is for you to relax and let go."
    new "Die Idee für diese nächste Position ist, dass du dich entspannst und loslässt."

    # say L2097 ang
    old "L-let myself go?"
    new "L-Lass mich loslassen?"

    # say L2098 pla
    old "That's right, I want you to relax and just let your energy flow through the position."
    new "Das ist richtig, ich will, dass du dich entspannst und einfach deiner Energie freien Lauf lässt."

    # say L2100 pla
    old "I can see that you have an energy block."
    new "Ich sehe, dass du einen Energiestau hast."

    # say L2102 pla
    old "If you keep going that way you won't be able to feel the energy flow through you."
    new "Wenn du so weitermachst, wirst du die Energie nicht mehr spüren können."

    # say L2104 ang
    old "I-I see, I think I get it."
    new "Ich-ich verstehe, ich glaube, ich kapiere es."

    # say L2106 pla
    old "Ok, so be sure to just relax."
    new "Ok, dann entspann dich einfach."

    # say L2107 pla
    old "This next one's called Upavistha Konasana."
    new "Die nächste nennt sich Upavistha Konasana."

    # say L2108 pla
    old "Except that it's a modified version."
    new "Nur eine angepasste Version."

    # say L2109 ang
    old "Modified? Will it be too hard?"
    new "Modifiziert? Wird es zu schwer?"

    # say L2110 pla
    old "Not at all, don't worry."
    new "Keine Sorge, das wird schon."

    # say L2112 pla
    old "It involves a forward fold while you push your legs outwards and reach for your ankles."
    new "Es geht um eine Vorneigung, bei der du die Beine nach außen drückst und dich nach den Knöcheln streckst."

    # say L2113 pla
    old "But I will be helping you, so you won't have to make much effort."
    new "Aber ich helfe dir dabei, also musst du dich nicht viel anstrengen."

    # say L2114 pla
    old "I'll help you by opening your legs with mine, and I'll pull you forward, so you just focus on the stretch through your groin and lower back."
    new "Ich helfe dir, indem ich deine Beine mit meinen öffne und dich nach vorne ziehe, dann musst du dich nur auf die Dehnung in deinem Schritt und unterem Rücken konzentrieren."

    # say L2116 ang
    old "Hmm, it sounds hard, but I'll trust you."
    new "Hmm, klingt schwierig, aber ich vertraue dir."

    # say L2119 pla
    old "Alright, you're doing ok."
    new "Alles klar, du machst das gut."

    # say L2122 pla
    old "But try to let yourself go a little bit more. Ok?"
    new "Aber versuch dich noch ein bisschen mehr fallen zu lassen. Ok?"

    # say L2130 ang
    old "{i}(W- what is this I'm feeling again?){/i}"
    new "{i}(W-was ist das, was ich gerade spüre?){/i}"

    # say L2131 ang
    old "{i}(T-this... Is like what I felt that time.){/i}"
    new "{i}(D-das... Ist wie damals, als ich das gefühlt habe.){/i}"

    # say L2133 pla
    old "{i}(Hmph, I guess this isn't working.){/i}"
    new "{i}(Hmpf, scheint so, als würde das nichts bringen.){/i}"

    # say L2134 pla
    old "Alright, I think that's enough for this position."
    new "Okay, ich denke, das reicht für diese Position."

    # say L2142 pla
    old "Ok, I think that's enough for today."
    new "Okay, ich denke, das reicht für heute."

    # say L2143 pla
    old "How did you feel?"
    new "Wie war es für dich?"

    # say L2145 ang
    old "I- Uhmm... I think I felt alright."
    new "Ich- Ähm... Ich denke, ich habe mich gut gefühlt."

    # say L2146 ang
    old "I feel my body a lot more loose now."
    new "Ich fühle mich jetzt viel entspannter."

    # say L2148 pla
    old "Hmph, well, as long as you don't feel bad, I guess that's ok."
    new "Hmpf, na ja, solange du dich nicht schlecht fühlst, ist das wohl okay."

    # say L2149 pla
    old "Why don't we go down and let Lisa know that we're done?"
    new "Warum gehen wir nicht runter und sagen Lisa, dass wir fertig sind?"

    # say L2167 lis
    old "Hello guys, are you done with the class?"
    new "Hallo Leute, seid ihr mit dem Unterricht fertig?"

    # say L2171 lis
    old "Alright, and how did it go? How are you feeling right now Angelina?"
    new "Alles klar, und wie war es? Wie fühlst du dich gerade, Angelina?"

    # say L2173 ang
    old "It was good... Yeah, it was a good class."
    new "Es war gut... Ja, es war eine gute Stunde."

    # say L2174 ang
    old "[pla] helped me through every position, and they weren't too difficult."
    new "[pla] hat mich durch jede Position geführt, und sie waren nicht zu schwierig."

    # say L2176 lis
    old "I'm happy to hear that. [pla] knows very well what he's doing, so I was sure that it would be a good class."
    new "Ich freue mich, das zu hören. [pla] weiß genau, was er tut, da war ich mir sicher, dass es eine gute Stunde war."

    # say L2177 ang
    old "It was."
    new "Es war."

    # say L2178 ang
    old "I’m afraid it’s getting quite late, I must be going now."
    new "Ich fürchte, es wird ziemlich spät, ich muss jetzt gehen."

    # say L2180 ang
    old "Thanks a lot for the class [pla]."
    new "Danke schön für die Stunde [pla]."

    # say L2181 pla
    old "You are welcome."
    new "Gern geschehen."

    # say L2184 ang
    old "Goodbye, Lisa. I’ll see you at the next class."
    new "Tschüss, Lisa. Bis zur nächsten Stunde."

    # say L2185 lis
    old "See you next class, sweetheart. Take care."
    new "Bis zur nächsten Stunde, Schatz. Pass auf dich auf."

    # say L2197 lis
    old "So? What did you think? How did it go?"
    new "So? Was hast du davon gehalten? Wie war es?"

    # say L2198 pla
    old "Hmm, in general, I would say it was alright."
    new "Hmm, im Allgemeinen würde ich sagen, es war okay."

    # say L2199 pla
    old "But I can see what you mean about her having some sort of energetic block."
    new "Aber ich sehe, was du meinst, dass sie irgendwie energetisch blockiert ist."

    # say L2201 pla
    old "I felt that she was very tense in all the positions we did."
    new "Ich hab gemerkt, dass sie in allen Positionen sehr angespannt war."

    # say L2202 lis
    old "I see, so her energy's still blocked inside her."
    new "Ich verstehe, dann ist ihre Energie also immer noch blockiert."

    # say L2204 pla
    old "Well, maybe that has to do with the fact that she's pregnant?"
    new "Vielleicht hat das damit zu tun, dass sie schwanger ist?"

    # say L2205 pla
    old "By the way, I would've liked to have known that before."
    new "Ach ja, das hätte ich vorher gerne gewusst."

    # say L2207 lis
    old "Oh, I failed to mention that, I'm sorry."
    new "Oh, das habe ich vergessen zu erwähnen, tut mir leid."

    # say L2208 lis
    old "But I don't think it makes such a difference."
    new "Aber ich denke, das macht keinen so großen Unterschied."

    # say L2209 lis
    old "What I've been feeling she lacks is that masculine energy I told you about."
    new "Was ich bei ihr vermisse, ist diese maskuline Energie, von der ich dir erzählt habe."

    # say L2210 lis
    old "So I think that it was still beneficial for her to have that session with you."
    new "Dann denke ich, dass es trotzdem hilfreich für sie war, diese Sitzung mit dir zu haben."

    # say L2212 pla
    old "I see, well, I sure hope that it actually helped her because she was just so tense during the session."
    new "Ich sehe, hoffentlich hat es ihr wirklich geholfen, denn sie war während der Sitzung total angespannt."

    # say L2214 lis
    old "Her next session's with me, so I'll see how her energy's changed. I'll let you know how she's doing."
    new "Ihre nächste Sitzung ist bei mir, da werde ich sehen, wie ihre Energie sich verändert hat. Ich lass es dich wissen, wie es ihr geht."

    # say L2217 lis
    old "Before you head out, there's something I'd like to discuss with you."
    new "Bevor du gehst, gibt es etwas, worüber ich mit dir sprechen möchte."

    # say L2218 pla
    old "Uh, sure. What's on your mind?"
    new "Klar, was willst du mir sagen?"

    # say L2219 lis
    old "Well, recently, I've been doing very well."
    new "Na ja, kürzlich läuft es bei mir wirklich gut."

    # say L2220 lis
    old "I've gotten a good number of new clients, and they seem to be very happy with my classes."
    new "Ich habe eine gute Anzahl neuer Kunden bekommen, und sie scheinen sehr zufrieden mit meinen Kursen zu sein."

    # say L2221 lis
    old "I'm very happy with how things have been going lately."
    new "Ich bin sehr zufrieden, wie sich alles entwickelt hat."

    # say L2223 pla
    old "That sounds great! Congrats, Lisa!"
    new "Das klingt toll! Glückwunsch, Lisa!"

    # say L2224 lis
    old "Thanks, [pla]."
    new "Danke, [pla]."

    # say L2225 lis
    old "But you see, some of my students are actually becoming very advanced in yoga."
    new "Aber du siehst, einige meiner Schüler werden tatsächlich sehr fortgeschritten in Yoga."

    # say L2226 lis
    old "So, I'm pondering what else I can offer my clients in the way of spiritual guidance and development."
    new "Also, ich überlege, was ich meinen Klienten noch an geistiger Führung und Entwicklung anbieten kann."

    # say L2230 lis
    old "Especially because my work goes beyond just yoga and meditation, you have seen it."
    new "Besonders weil meine Arbeit über Yoga und Meditation hinausgeht, das hast du ja gesehen."

    # say L2231 lis
    old "Rather than just a yoga guru, I want to be known as a complete spiritual wellness guide."
    new "Stattdessen will ich als umfassender spiritueller Wohlfühlführer bekannt sein."

    # say L2232 lis
    old "So that my students can progress in whatever way they feel benefits them the most."
    new "Damit meine Schüler in der Art vorankommen können, die ihnen am meisten nützt."

    # say L2233 pla
    old "Ok, that sounds like a very good idea."
    new "Ok, das klingt wie eine sehr gute Idee."

    # say L2235 lis
    old "Thanks, [pla]. So I came up with the idea of adding classes in mindfulness, transcendental meditation."
    new "Danke, [pla]. Deshalb habe ich die Idee entwickelt, Kurse in Achtsamkeit und transzendentaler Meditation anzubieten."

    # say L2236 lis
    old "As well as Tai Chi, Reiki, and Tantric sex."
    new "Außerdem Tai Chi, Reiki und tantrischen Sex."

    # say L2237 lis
    old "And different healing treatments, like Chakra Healing, Acupuncture, Sound Healing, and herbal medicines."
    new "Und verschiedene Heilmethoden, wie Chakra-Heilung, Akupunktur, Schallheilung und Kräutermedizin."

    # say L2238 pla
    old "I- I see, that's a lot."
    new "I- Ich sehe, das ist ziemlich viel."

    # say L2240 pla
    old "So you want to expand your portfolio, right?"
    new "Dann willst du dein Angebot erweitern, oder?"

    # say L2242 lis
    old "Hmm... Yeah, to put it in simpler terms."
    new "Hmm... Ja, um es einfacher auszudrücken."

    # say L2244 lis
    old "Of course, I intend to implement this gradually. I’d like to conduct a few tests before applying it to additional clients."
    new "Natürlich, ich plane das schrittweise umzusetzen. Ich möchte vorher ein paar Tests durchführen, bevor ich es bei weiteren Kunden anwende."

    # say L2245 pla
    old "That makes sense, so, Do you already have a plan for how to begin?"
    new "Das ergibt Sinn, also, hast du schon einen Plan, wie du anfangen willst?"

    # say L2247 lis
    old "Well, I have this client that's been working with me for a while."
    new "Na ja, ich habe diesen Klienten, mit dem ich schon eine Weile arbeite."

    # say L2249 lis
    old "And she has in fact asked me several times about the possibility of having tantric sex sessions."
    new "Und sie hat mich tatsächlich mehrere Male gefragt, ob wir tantrische Sexsitzungen machen könnten."

    # say L2250 pla
    old "I see, well, that makes a lot of sense, and if she wants to do it, I think it's a great idea."
    new "Ich sehe, das ergibt Sinn, und wenn sie es will, finde ich es eine tolle Idee."

    # say L2252 lis
    old "Yes, and you see, this client's Anastasia."
    new "Ja, und wie du siehst, ist diese Kundin Anastasia."

    # say L2254 pla
    old "Oh, I see, I think she did mention that."
    new "Oh, ich sehe, ich glaube, sie hat das erwähnt."

    # say L2256 lis
    old "Yeah, and given that she's relatively advanced in her yoga journey, I think this would be a good moment to introduce her to more advanced concepts."
    new "Ja, und da sie schon ziemlich weit fortgeschritten in ihrer Yogapraxis ist, denke ich, es ist der richtige Moment, sie mit fortschrittlicheren Konzepten vertraut zu machen."

    # say L2257 lis
    old "Especially tantric sex, I think it would be good for her to follow that practice."
    new "Besonders tantrischer Sex, ich denke, es wäre gut für sie, diese Praxis zu erlernen."

    # say L2258 lis
    old "After all, the benefits are great, I think it would really help her with reducing stress and improving her relaxation."
    new "Schließlich bringt es viele Vorteile, ich denke, es würde ihr wirklich helfen, Stress abzubauen und besser zu entspannen."

    # say L2260 lis
    old "Which will help her with her sleep."
    new "Das wird ihr beim Schlaf helfen."

    # say L2262 lis
    old "Not to mention her sexual satisfaction, which I believe is clear to the both of us she needs to improve on."
    new "Nicht zu vergessen ihre sexuelle Befriedigung, die ich glaube, dass wir beide wissen, dass sie dringend verbessern muss."

    # say L2264 lis
    old "But more importantly, her personal and spiritual growth, tantra will help her with it, and I believe she'll benefit greatly from it."
    new "Aber wichtiger noch, ihre persönliche und spirituelle Entwicklung, Tantra wird ihr dabei helfen, und ich bin überzeugt, dass sie davon enorm profitieren wird."

    # say L2265 pla
    old "All of that sounds great, I'm sure you'll have a great time teaching her."
    new "Alles klingt super, ich bin sicher, du wirst eine tolle Zeit haben, sie zu unterrichten."

    # say L2267 lis
    old "Well, since you mentioned it, that's where you come in."
    new "Na ja, da du es erwähnt hast, da kommst du ins Spiel."

    # say L2269 lis
    old "Anastasia asked me if it would be possible for you to accompany us during the tantric sex sessions."
    new "Anastasia hat mich gefragt, ob es möglich wäre, dass du uns bei den tantrischen Sexsitzungen begleitest."

    # say L2270 pla
    old "M-Me? Do you need me to be there?"
    new "M-Mich? Muss ich dabei sein?"

    # say L2271 pla
    old "I mean, with your experience, I don't see why I would need to be there. Don't you just do that directly?"
    new "Ich meine, mit deiner Erfahrung sehe ich nicht, warum ich da sein müsste. Machst du das nicht direkt?"

    # say L2273 lis
    old "Of course I can teach her everything, but the reason I want you to go there is to be my assistant."
    new "Natürlich kann ich ihr alles beibringen, aber der Grund, warum ich will, dass du mitkommst, ist, dass du mein Assistent sein sollst."

    # say L2275 pla
    old "Your assistant?"
    new "Dein Assistent?"

    # say L2277 lis
    old "Yeah, that's right, but not in the way that you may think of."
    new "Klar, aber nicht so, wie du denkst."

    # say L2278 lis
    old "What I need from you is that you play the role of an intermediary between Anastasia and me."
    new "Was ich von dir brauche, ist, dass du die Rolle des Vermittlers zwischen Anastasia und mir spielst."

    # say L2280 pla
    old "I-I'm not sure I get what you're saying."
    new "Ich bin mir nicht sicher, was du meinst."

    # say L2282 lis
    old "Think about it [pla], you've already worked with Anastasia in the past, so she's comfortable with you in that sense."
    new "Überleg mal [pla], du hast schon mit Anastasia zusammengearbeitet, da fühlt sie sich mit dir schon wohler."

    # say L2283 lis
    old "So, when I'm doing the sessions with her, your role will be to help her feel more relaxed and comfortable."
    new "Dann wirst du bei den Sitzungen mit ihr dabei sein, um ihr zu helfen, sich entspannter und wohler zu fühlen."

    # say L2284 lis
    old "So that the session can flow smoothly and without any problems."
    new "Damit die Sitzung reibungslos und ohne Probleme verläuft."

    # say L2286 pla
    old "Hmm, I see, that makes quite a lot of sense."
    new "Hmm, das ergibt Sinn."

    # say L2288 pla
    old "But hey, you and I are still working on my own tantric session."
    new "Aber hey, du und ich arbeiten ja noch an meiner eigenen tantrischen Sitzung."

    # say L2289 pla
    old "Are you sure it will be a good idea for me to be there? Wouldn't it be better if it's just the two of you?"
    new "Bist du sicher, dass es eine gute Idee ist, wenn ich dabei bin? Wäre es nicht besser, wenn es nur euch beide betrifft?"

    # say L2290 lis
    old "Well, at the beginning I did think it strange when she asked for it."
    new "Am Anfang fand ich es schon seltsam, als sie danach gefragt hat."

    # say L2291 lis
    old "But it makes a lot of sense since you've already helped her with her chakra balancing in the past."
    new "Aber es ergibt Sinn, da du ihr schon bei der Chakrabilanzierung geholfen hast."

    # say L2293 lis
    old "In addition, I believe it would be good practice for you, it would be a good way for you to work with other clients in the future. If the opportunity arises of course."
    new "Außerdem denke ich, es wäre eine gute Übung für dich, es wäre eine gute Möglichkeit, mit anderen Klienten in der Zukunft zu arbeiten. Wenn sich die Gelegenheit ergibt natürlich."

    # say L2295 lis
    old "But of course, it all depends on you, if you feel the universe is guiding you towards a teaching role."
    new "Aber natürlich, es hängt alles von dir ab, wenn du das Gefühl hast, dass das Universum dich zu einer Lehrrolle führt."

    # say L2297 lis
    old "If you don't feel like it, there's no problem, I'll understand."
    new "Wenn du dich nicht danach fühlst, ist das auch okay, ich versteh’s."

    # say L2299 pla
    old "Oh, no, no, there's no problem with it. I'll do it, with the way you explain it, it makes a lot of sense."
    new "Oh nein, nein, da ist kein Problem. Ich mach’s, bei der Art, wie du es erklärt hast, ergibt das total Sinn."

    # say L2301 lis
    old "Excellent [pla]! Thank you very much! I know it's going to be great."
    new "Exzellent [pla]! Vielen Dank! Ich weiß, dass es toll werden wird."

    # say L2302 lis
    old "I’ve scheduled an appointment for tomorrow evening, would you happen to be available?"
    new "Ich habe für morgen Abend einen Termin vereinbart, wärst du zufällig verfügbar?"

    # say L2304 pla
    old "Uhh, I think so."
    new "Uhh, ich denke schon."

    # say L2306 lis
    old "Wonderful, I'll get everything ready, and I'll see you later."
    new "Wunderbar, ich werde alles vorbereiten und dich später sehen."

    # say L2308 pla
    old "Sure, goodbye then."
    new "Klar, dann bis später."

    # say L2335 pla
    old "Anastasia, hi. You're already here, great."
    new "Anastasia, hallo. Du bist schon da, toll."

    # say L2338 ana
    old "Yeah, I just arrived, Lisa wasn't here so I decided to wait a while."
    new "Ja, ich bin gerade angekommen. Lisa war nicht da, also hab ich beschlossen, ein bisschen zu warten."

    # say L2340 pla
    old "Oh, she's probably already up in the yoga room waiting for us."
    new "Oh, die ist wahrscheinlich schon im Yogaraum und wartet auf uns."

    # say L2344 pla
    old "Sure, let's go up."
    new "Klar, lass uns hochgehen."

    # say L2369 ana
    old "Oh! Hi Lisa, [pla] and I ran into each other in your living room and..."
    new "Oh! Hi Lisa, [pla] und ich sind uns in deinem Wohnzimmer über den Weg gelaufen und..."

    # say L2373 lis
    old "Hmm, Anastasia are you alright?"
    new "Hmm, Anastasia, geht es dir gut?"

    # say L2374 ana
    old "Yeah, sorry, sorry."
    new "Ja, tut mir leid, tut mir leid."

    # say L2376 ana
    old "It's just that the outfit you're wearing... It surprised me."
    new "Es ist nur, dass das Outfit, das du trägst... Es hat mich überrascht."

    # say L2379 lis
    old "I see, that's understandable, but these collars are necessary for what we're about to do."
    new "Ich verstehe, das ist nachvollziehbar, aber diese Halsbänder sind notwendig für das, was wir gleich tun."

    # say L2380 lis
    old "They're an important element that will help to keep the balance of your chakras."
    new "Sie sind ein wichtiges Element, das dazu beiträgt, das Gleichgewicht deiner Chakras zu halten."

    # say L2382 ana
    old "I-I see."
    new "Ich-ich verstehe."

    # say L2384 lis
    old "Yes, because you see, this is a physical process, so the idea is to be fully in contact with our energies."
    new "Ja, denn wie du siehst, ist das ein physischer Prozess, also sollten wir vollständig in Kontakt mit unseren Energien sein."

    # say L2385 lis
    old "So we need to get rid of everything that could get in the way of that connection. Of course, our clothes are part of that."
    new "Dann müssen wir alles loswerden, was diese Verbindung behindern könnte. Natürlich gehören dazu auch unsere Kleider."

    # say L2386 ana
    old "D-Does that mean that I will be naked too?"
    new "D-Das bedeutet, dass ich auch nackt sein werde?"

    # say L2388 lis
    old "Of course, but don't worry about it, this is a spiritual process, and both [pla] and I are very professional about it."
    new "Natürlich, aber mach dir keine Sorgen, das ist ein spiritueller Prozess und sowohl [pla] als auch ich sind sehr professionell dabei."

    # say L2390 ana
    old "I-I see, I understand."
    new "I-Ich verstehe, ich sehe."

    # say L2392 lis
    old "Good, then let's get started. Why don't you go ahead into the yoga room and get ready?"
    new "Gut, dann lass uns anfangen. Warum gehst du nicht schon mal in den Yogaraum und bereitest dich vor?"

    # say L2393 lis
    old "[pla] and I will go in a minute."
    new "[pla] und ich kommen gleich rein."

    # say L2394 ana
    old "Sure, I'll do that. So, I have to get naked in there?"
    new "Klar, mach ich. Also, muss ich mich da ausziehen?"

    # say L2396 lis
    old "Yes, the idea is that you'll be ready for when [pla] and I come in."
    new "Ja, die Idee ist, dass du bereit bist, wenn [pla] und ich reinkommen."

    # say L2398 ana
    old "I see, I'll do it then."
    new "Okay, dann mache ich das."

    # say L2404 lis
    old "Alright, you know what the idea is, right? You'll support me during the session, and you'll also be without any clothes."
    new "Okay, du weißt ja, wie das abläuft, oder? Du wirst mich bei der Sitzung unterstützen und dich auch komplett ausziehen."

    # say L2406 pla
    old "Yeah sure, no problem."
    new "Klar, kein Problem."

    # say L2408 lis
    old "However, for this session onwards, I prepared a special outfit for you."
    new "Allerdings habe ich für diese Sitzung eine besondere Outfit für dich vorbereitet."

    # say L2409 pla
    old "A- a special outfit?"
    new "A- ein besonderes Outfit?"

    # say L2411 lis
    old "Yes, up until now I've been guiding you in this development journey."
    new "Ja, bisher habe ich dich auf dieser Entwicklungsreise begleitet."

    # say L2412 lis
    old "But today you will be the one taking the position of the guide. From now on, you'll be a Yogi."
    new "Aber heute wirst du die Rolle des Führers übernehmen. Ab jetzt bist du ein Yogi."

    # say L2415 lis
    old "A yogi, that's the title that a yoga instructor receives when they're guiding somebody."
    new "Ein Yogi, das ist der Titel, den ein Yogalehrer erhält, wenn er jemanden führt."

    # say L2416 lis
    old "You're not a guru, like I am, but I think it's appropriate that I call you a Yogi, especially because you've already guided Anastasia on the right path."
    new "Du bist zwar kein Guru wie ich, aber ich finde es passend, dich einen Yogi zu nennen, vor allem weil du Anastasia schon auf den richtigen Weg geführt hast."

    # say L2417 lis
    old "That's why I prepared a special outfit for you. You being on another level needs to be reflected in what you're wearing."
    new "Deshalb habe ich ein besonderes Outfit für dich vorbereitet. Dass du auf einer anderen Ebene bist, sollte sich auch in deiner Kleidung widerspiegeln."

    # say L2418 lis
    old "That and because they're needed to protect and balance your energy."
    new "Das und weil sie nötig sind, um deine Energie zu schützen und auszubalancieren."

    # say L2419 pla
    old "I-I see, thank you, Lisa."
    new "I-Ich sehe, danke, Lisa."

    # say L2421 lis
    old "You're more than welcome. Now go and get changed. Anastasia is waiting for us."
    new "Gern geschehen. Jetzt zieh dich um. Anastasia wartet auf uns."

    # say L2422 lis
    old "You'll find what you have to wear on the bed."
    new "Du wirst auf dem Bett finden, was du anziehen musst."

    # say L2441 pla
    old "S- so, I wasn't sure if I was putting it on correctly, but I saw some instructions over the bed."
    new "S- so, ich war mir nicht sicher, ob ich es richtig angezogen habe, aber ich hab ein paar Anweisungen über dem Bett gesehen."

    # say L2442 pla
    old "What do you think? Does it fit me properly?"
    new "Was denkst du? Passt es mir?"

    # say L2443 lis
    old "It does, you look great, like a proper yogi."
    new "Es tut es, du siehst toll aus, wie eine echte Yogalehrerin."

    # say L2444 lis
    old "Let's go in, Anastasia's waiting for us."
    new "Lass uns reingehen, Anastasia wartet auf uns."

    # say L2471 pla
    old "{i}(Oh, wow, she's just naked there.){/i}"
    new "{i}Oh, wow, sie ist da einfach nackt. {/i}"

    # say L2473 pla
    old "{i}(I sometimes forget that Anastasia's so hot.){/i}"
    new "{i}(Schätze, manchmal vergesse ich, wie heiß Anastasia ist.){/i}"

    # say L2478 ana
    old "You look like a proper shaman now."
    new "Du siehst jetzt wie ein richtiger Schamane aus."

    # say L2481 lis
    old "Hahaha, what [pla]'s wearing is actually a very important part of the tantra ritual that we're going to be performing with you."
    new "Ha, was [pla] trägt, ist tatsächlich ein sehr wichtiger Teil des Tantra-Rituals, das wir mit dir durchführen werden."

    # say L2482 lis
    old "Because the idea is that this is as good an experience for you as we can make it."
    new "Denn das Ziel ist, dass es für dich so angenehm wie möglich wird."

    # say L2483 lis
    old "So, are you ready to start?"
    new "Dann, bist du bereit anzufangen?"

    # say L2485 ana
    old "Oh yeah, for sure, I've been waiting for this."
    new "Oh ja, auf jeden Fall, ich hab schon drauf gewartet."

    # say L2486 ana
    old "I'm a little nervous."
    new "Ich bin ein bisschen nervös."

    # say L2487 ana
    old "But once we start, I'm sure I'll feel a lot better."
    new "Aber sobald wir anfangen, bin ich sicher, dass ich mich viel besser fühlen werde."

    # say L2491 lis
    old "Listen, Anastasia, I understand the type of situation this is, and how arousing it potentially is."
    new "Hör zu, Anastasia, ich verstehe, was für eine Situation das ist und wie aufregend sie sein kann."

    # say L2493 lis
    old "But it's important that you keep in mind that this is not for the sake of having sex."
    new "Aber es ist wichtig, dass du im Kopf behältst, dass das hier nicht um Sex geht."

    # say L2495 lis
    old "The most important part of this whole process is to learn to control those sexual impulses that sometimes take hold of us."
    new "Der wichtigste Teil dieses ganzen Prozesses ist, diese sexuellen Impulse zu kontrollieren, die uns manchmal überkommen."

    # say L2497 lis
    old "So my focus for you during this whole process is that you are able to balance your chakras and put your energy in order."
    new "Mein Fokus bei diesem ganzen Prozess liegt darauf, dass du deine Chakras ausbalancierst und deine Energie ordnest."

    # say L2499 ana
    old "Hmm, yeah, I guess you're right, but does that mean that we won't be having sex?"
    new "Hmm, ja, ich schätze, du hast recht, aber heißt das, dass wir nicht miteinander schlafen werden?"

    # say L2501 lis
    old "In the most strict sense of the word, no."
    new "Im strengsten Sinne des Wortes, nein."

    # say L2502 lis
    old "We will come to it when the time comes, but what's most important is that you are able to relax."
    new "Wir werden es tun, wenn die Zeit reif ist, aber am wichtigsten ist, dass du dich entspannen kannst."

    # say L2503 lis
    old "To control your sexual energy and come to internal balance with your energy and chakras."
    new "Um deine sexuelle Energie zu kontrollieren und zu einem inneren Gleichgewicht mit deiner Energie und deinen Chakras zu kommen."

    # say L2505 lis
    old "Now, let's get started so that you can see how this process feels."
    new "Dann lass uns anfangen, damit du spürst, wie dieser Prozess sich anfühlt."

    # say L2507 ana
    old "O-Okay, sure."
    new "O-Okay, klar."

    # say L2508 lis
    old "So, before we start with the first session, I want you to keep in mind that you need to focus on your breathing and relaxing your body."
    new "Also, bevor wir mit der ersten Sitzung beginnen, möchte ich, dass du dich auf deinen Atem und die Entspannung deines Körpers konzentrierst."

    # say L2509 lis
    old "Let yourself go and listen to my instructions while you keep your breathing constant."
    new "Lass dich gehen und hör auf meine Anweisungen, während du deinen Atem ruhig hältst."

    # say L2529 lis
    old "I want to congratulate you, Anastasia."
    new "Ich möchte dich beglückwünschen, Anastasia."

    # say L2530 lis
    old "The fact that you were able to truly connect with yourself by doing this therapy."
    new "Das du dich dabei so gut mit dir selbst verbinden konntest."

    # say L2531 ana
    old "I was surprised by how good it feels, I wasn't expecting it. Thank you so much, Lisa! And you too, [pla]."
    new "Ich war überrascht, wie gut es sich anfühlt, ich habe das nicht erwartet. Danke schön, Lisa! Und dir auch, [pla]."

    # say L2532 lis
    old "I'm glad I'm able to help you."
    new "Ich bin froh, dass ich dir helfen konnte."

    # say L2533 lis
    old "But there still remains much to be done."
    new "Aber es bleibt noch viel zu tun."

    # say L2534 lis
    old "So we will continue during the next session, ok?"
    new "Dann machen wir das beim nächsten Mal weiter, ok?"

    # say L2536 ana
    old "Oh, we're done? I thought that maybe we could do some more..."
    new "Oh, wir sind fertig? Ich dachte, wir könnten noch mehr machen..."

    # say L2538 lis
    old "I understand that you may feel like it, but we're doing this little by little."
    new "Ich verstehe, dass du das Gefühl hast, aber wir machen das Schritt für Schritt."

    # say L2539 lis
    old "Besides, you may not feel like it now, but you need to rest before you can do more. Believe me, you'll feel it later."
    new "Außerdem, du magst es jetzt vielleicht nicht spüren, aber du musst dich ausruhen, bevor du mehr machen kannst. Vertrau mir, du wirst es später spüren."

    # say L2541 ana
    old "Hmm, ok, I get it."
    new "Hmm, okay, ich verstehe."

    # say L2543 lis
    old "Yes, by the way, it's getting a little late."
    new "Ja, übrigens, es wird langsam ein bisschen spät."

    # say L2544 lis
    old "It's better if we get changed and ready for you to return home."
    new "Es ist besser, wenn wir uns umziehen und du dich bereit machst, nach Hause zu gehen."

    # say L2551 lis
    old "Well, I would say that was a very good first session. I'm glad with the progress you made today, Anastasia."
    new "Na, ich würde sagen, das war eine sehr gute erste Session. Ich bin froh über den Fortschritt, den du heute gemacht hast, Anastasia."

    # say L2553 ana
    old "Thank you very much, Lisa. I wasn't expecting it to be that good, but it was amazing."
    new "Danke schön, Lisa. Ich habe nicht erwartet, dass es so gut wird, aber es war unglaublich."

    # say L2554 ana
    old "And of course, thanks to you too, [pla]. With you here, I was able to feel so much more comfortable."
    new "Und natürlich danke ich dir auch, [pla]. Mit dir hier konnte ich mich viel wohler fühlen."

    # say L2557 lis
    old "She's right, [pla]. You being here really brings our energies to a state of balance. Thanks a lot."
    new "Sie hat recht, [pla]. Dass du hier bist, bringt unsere Energien wirklich ins Gleichgewicht. Danke schön."

    # say L2558 pla
    old "Oh, well, I'm happy to help."
    new "Oh, ich freue mich, helfen zu können."

    # say L2560 ana
    old "Anyway, it's getting a bit late, so I should head out. I can’t wait for the next tantric class."
    new "Na ja, es wird langsam spät, ich sollte dann mal los. Ich freue mich schon auf den nächsten tantrischen Kurs."

    # say L2561 lis
    old "Goodbye, darling, see you at the next yoga session this afternoon."
    new "Tschüss, Liebling, bis zur nächsten Yogastunde heute Nachmittag."

    # say L2562 pla
    old "Good night, have a great evening."
    new "Gute Nacht, hab einen schönen Abend."

    # say L2564 ana
    old "Oh, of course I'll have a wonderful night. Thanks again, you two."
    new "Oh, natürlich werde ich eine wunderbare Nacht haben. Danke nochmal, ihr beiden."

    # say L2574 lis
    old "Oh [pla], I think it was a total success, I could feel our energies connecting and merging during the tantric exercise."
    new "Oh [pla], ich denke, es war ein voller Erfolg, ich konnte unsere Energien miteinander verschmelzen spüren während der tantrischen Übung."

    # say L2575 lis
    old "I definitely believe the universe is opening a door for my business. It's calling me to guide more clients spiritually. Did you feel it too?"
    new "Ich bin mir sicher, dass das Universum eine Tür für mein Geschäft öffnet. Es ruft mich, mehr Kunden spirituell zu führen. Hast du es auch gespürt?"

    # say L2577 pla
    old "Uhh, y- yeah, I totally felt it, that energy was... Definitely something."
    new "Uhh, j- ja, ich hab es auch gespürt, diese Energie war... definitiv etwas Besonderes."

    # say L2578 lis
    old "Right? It was almost a religious experience."
    new "Stimmt? Es war fast wie eine religiöse Erfahrung."

    # say L2579 lis
    old "Oh wow, look at the time, it's really late."
    new "Oh wow, schau mal auf die Uhr, es ist echt spät."

    # say L2580 lis
    old "Ugh, I wanted to talk to you about Angelina, but I think we'll leave that for another day."
    new "Ugh, ich wollte mit dir über Angelina reden, aber lass uns das für einen anderen Tag machen."

    # say L2581 lis
    old "Could you swing by in the afternoon so we can talk? It won't take long."
    new "Kannst du am Nachmittag vorbeikommen, damit wir reden können? Das wird nicht lange dauern."

    # say L2582 pla
    old "Uhh, yeah, sure. No problem."
    new "Uhh, ja, klar. Kein Problem."

    # say L2583 lis
    old "Perfect. Let's leave it here so you can get some rest. You've helped me a lot today, [pla]. Thanks."
    new "Perfekt. Lass es dabei, dann kannst du dich ausruhen. Du hast mir heute echt geholfen, [pla]. Danke."

    # say L2601 pla
    old "Hi Lisa, how are you?"
    new "Hi Lisa, wie geht's dir?"

    # say L2603 lis
    old "Hey, my energy’s flowing beautifully today, how about you?"
    new "Hey, meine Energie fließt heute wunderbar, wie geht es dir?"

    # say L2604 pla
    old "I'm fine... Thanks for asking."
    new "Mir geht's gut... Danke fürs Nachfragen."

    # say L2605 pla
    old "I came about that thing you mentioned, you wanted to talk about Angelina."
    new "Ich bin wegen der Sache gekommen, von der du gesprochen hast. Du wolltest über Angelina reden."

    # say L2606 lis
    old "Oh, yes, of course. Thanks for coming."
    new "Oh, ja, natürlich. Danke, dass du gekommen bist."

    # say L2607 lis
    old "Well, I had a session with her, and she asked me if you could be the teacher in her next class."
    new "Na ja, ich hatte eine Sitzung mit ihr, und sie hat mich gefragt, ob du der Lehrer in ihrem nächsten Kurs sein könntest."

    # say L2609 pla
    old "She did?!"
    new "Hat sie das?!"

    # say L2611 lis
    old "Uhh, yes, why are you so surprised?"
    new "Uhh, ja, warum bist du so überrascht?"

    # say L2613 pla
    old "Well, I just wasn't expecting that."
    new "Na ja, ich hab das einfach nicht erwartet."

    # say L2614 pla
    old "Because last time she almost looked uncomfortable during the class."
    new "Weil beim letzten Mal sah sie fast unwohl aus während des Unterrichts."

    # say L2615 pla
    old "So it's kind of a surprise that you tell me she wants another class with me."
    new "Dann ist es ja eine Überraschung, dass du mir erzählst, sie will noch eine Stunde mit mir."

    # say L2617 lis
    old "Well, she had another class with me after yours."
    new "Na ja, sie hatte noch eine Stunde mit mir nach deiner."

    # say L2618 lis
    old "And yes, I've noticed that her energy seems stuck. Her Muladhara chakra is completely out of balance."
    new "Und ja, ich habe bemerkt, dass ihre Energie blockiert zu sein scheint. Ihr Muladhara-Chakra ist vollkommen aus dem Gleichgewicht."

    # say L2619 lis
    old "And it's affecting the flow of prana through her nadis. There might be a deep-rooted samskara causing this blockage."
    new "Und es beeinflusst den Fluss von Prana durch ihre Nadis. Es könnte eine tief sitzende Samskara die Ursache für diesen Block sein."

    # say L2620 lis
    old "But after her class with you, I've noticed her blockage has started to dissipate."
    new "Aber nach ihrem Kurs mit dir habe ich bemerkt, dass die Blockierung sich aufgelöst hat."

    # say L2622 pla
    old "For real?"
    new "Echt jetzt?"

    # say L2624 lis
    old "Yes, I've noticed that after her session with you, her energy has started to flow a lot better inside her."
    new "Ja, ich habe bemerkt, dass nach ihrer Sitzung mit dir ihre Energie viel besser in ihr fließt."

    # say L2626 pla
    old "Hmm, I have to say, that's a surprise."
    new "Hmm, ich muss sagen, das ist eine Überraschung."

    # say L2627 pla
    old "But if you say that it's alright, and she actually requested another session with me, then I guess it's alright."
    new "Aber wenn du sagst, dass es in Ordnung ist, und sie hat tatsächlich um eine weitere Session mit mir gebeten, dann ist es wohl okay."

    # say L2629 lis
    old "It is, if she wants to see you again, it means you did a very good job."
    new "Wenn sie dich wiedersehen will, bedeutet das, dass du eine sehr gute Arbeit geleistet hast."

    # say L2631 pla
    old "Uhh, alright..."
    new "Uhh, okay..."

    # say L2633 lis
    old "So, can I count on you for the next session with Angelina?"
    new "Also, kannst du dich auf die nächste Session mit Angelina verlassen?"

    # say L2635 pla
    old "Sure, sure, no problem."
    new "Klar, klar, kein Problem."

    # say L2637 lis
    old "That's wonderful [pla], thanks a lot."
    new "Das ist wunderbar [pla], danke schön."

    # say L2638 lis
    old "I'll go ahead and schedule Angelina's next yoga session."
    new "Ich werde Angelinas nächsten Yogastunden terminieren."

    # say L2639 lis
    old "So, as you know, I'll see you this afternoon for your next yoga class."
    new "Dann, wie du weißt, sehe ich dich heute Nachmittag für deinen nächsten Yogakurs."

    # say L2641 pla
    old "Sure, count on it."
    new "Klar, darauf kannst du dich verlassen."

    # say L2642 lis
    old "Thank you so much [pla], the universe has great things in store for you!"
    new "Danke schön [pla], das Universum hat großartige Dinge für dich im Sinn!"

    # say L2643 pla
    old "Heh, thanks. Well, I guess I'll see you later. Bye."
    new "Heh, danke. Na ja, dann sehen wir uns später. Tschüss."

    # say L2644 lis
    old "Goodbye [pla], take care."
    new "Tschüss [pla], pass auf dich auf."

    # say L2671 lis
    old "Oh, hi [pla]! it's good to see you."
    new "Oh, hallo [pla]! Es ist schön, dich zu sehen."

    # say L2674 pla
    old "Hi, have you been waiting too long for me?"
    new "Hi, hast du schon lange auf mich gewartet?"

    # say L2676 lis
    old "Not at all, Angelina just arrived a couple of minutes ago."
    new "Gar nicht, Angelina ist erst vor ein paar Minuten angekommen."

    # say L2677 lis
    old "So you're just in time for the class."
    new "Dann bist du gerade noch rechtzeitig für die Klasse."

    # say L2678 lis
    old "But it's better if you don't lose time."
    new "Aber es ist besser, wenn du keine Zeit verlierst."

    # say L2680 lis
    old "So why don't you two go upstairs to the yoga room?"
    new "Dann geht doch ihr beiden besser mal nach oben ins Yogazimmer?"

    # say L2682 pla
    old "Sure, we'll see you later then."
    new "Klar, dann sehen wir uns später."

    # say L2692 pla
    old "Alright, I guess that if you're feeling alright, we can get started with the session."
    new "Okay, wenn du dich gut fühlst, können wir mit der Sitzung beginnen."

    # say L2694 ang
    old "S- sure, let's do it."
    new "Sicher, lass es uns tun."

    # say L2695 pla
    old "{i}(Hmm, she's still feeling uncomfortable? It's a surprise that she wanted another session.){/i}"
    new "{i}(Hmm, sie fühlt sich immer noch unwohl? Es überrascht mich, dass sie eine weitere Session will.){/i}"

    # say L2696 pla
    old "{i}(I guess she'll relax when we start with the asanas.){/i}"
    new "{i}(Ich denke, sie wird sich entspannen, wenn wir mit den Asanas anfangen.){/i}"

    # say L2697 pla
    old "Okay, let's get started with the first position then."
    new "Okay, dann fangen wir mit der ersten Position an."

    # say L2706 ang
    old "{i}(I didn't notice before, but this is a very comfortable position.){/i}"
    new "{i}(Ich hatte das vorher gar nicht bemerkt, aber diese Position ist wirklich sehr bequem.){/i}"

    # say L2707 pla
    old "Ok, I see you're doing a little better than last time."
    new "Ok, ich sehe, du bist ein bisschen besser dran als letztes Mal."

    # say L2708 ang
    old "T-Thank you."
    new "D-Danke."

    # say L2709 pla
    old "That's it, you're doing very well."
    new "Das ist es, du machst das sehr gut."

    # say L2710 pla
    old "{i}(Well, her movement's a lot more smooth.){/i}"
    new "{i}(Nun, ihre Bewegungen sind viel flüssiger.){/i}"

    # say L2712 pla
    old "You're doing very, very well."
    new "Du machst das sehr, sehr gut."

    # say L2714 pla
    old "Remember to keep focusing on your breathing and how your muscles feel."
    new "Denk dran, auf deinen Atem und das Gefühl in deinen Muskeln zu achten."

    # say L2715 pla
    old "Excellent, I think we can stop there."
    new "Perfekt, ich denke, wir können da aufhören."

    # say L2726 pla
    old "Alright! That was an excellent start!"
    new "Alles klar! Das war ein super Anfang!"

    # say L2727 pla
    old "I can tell that you're doing so much better than last time."
    new "Ich merke, dass du viel besser drauf bist als beim letzten Mal."

    # say L2728 pla
    old "Are you feeling better than during the last session?"
    new "Fühlst du dich besser als beim letzten Mal?"

    # say L2730 ang
    old "T-Thank you [pla]."
    new "D-Danke [pla]."

    # say L2731 ang
    old "Yeah, I'm feeling a little better than before."
    new "Ja, ich fühle mich ein bisschen besser als vorher."

    # say L2739 pla
    old "Okay, that's very good."
    new "Okay, das ist sehr gut."

    # say L2740 pla
    old "{i}(She's doing a lot better, great!){i}"
    new "{i}(Sie geht es viel besser, toll!){i}"

    # say L2741 pla
    old "Very good Angelina! I can see that you're a lot more relaxed!"
    new "Sehr gut Angelina! Ich sehe, dass du viel entspannter bist!"

    # say L2744 pla
    old "{i}(And the way she's pushing it against me...){/i}"
    new "{i}(Und wie sie es gegen mich drückt...){/i}"

    # say L2756 ang
    old "I'm still doing well [pla]?"
    new "Ich bin immer noch gut drauf [pla]?"

    # say L2757 pla
    old "Y- yeah, you are, w- why don't we move on to the next position?"
    new "Y- ja, du bist es, w- warum gehen wir nicht zur nächsten Position?"

    # say L2758 pla
    old "Ok, you're doing amazing."
    new "Ok, du machst das toll."

    # say L2759 pla
    old "Now, I think we can move on to the third position."
    new "Jetzt, ich denke, wir können zur dritten Position übergehen."

    # say L2761 ang
    old "Oh yeah, sure."
    new "Oh ja, klar."

    # say L2771 pla
    old "Uhh, just keep your eyes closed... t- to feel the energy better..."
    new "Uhh, halt einfach die Augen geschlossen... d-damit du die Energie besser spürst..."

    # say L2774 ang
    old "Hmm, this feels very good [pla]."
    new "Hmm, das fühlt sich sehr gut an [pla]."

    # say L2775 pla
    old "T- that's very good, well done."
    new "Das ist sehr gut, gut gemacht."

    # say L2776 pla
    old "Remember to keep breathing."
    new "Denk dran, weiterzuatmen."

    # say L2777 pla
    old "{i}(She's finally feeling comfortable, I wouldn't want to make her feel awkward.){/i}"
    new "{i}(Sie fühlt sich endlich wohl, ich will sie nicht verlegen machen.){/i}"

    # say L2778 ang
    old "Am I doing it alright [pla]?"
    new "Mache ich das gut [pla]?"

    # say L2779 pla
    old "Y-yes! You're doing great!"
    new "Y-ja! Du machst das super!"

    # say L2780 ang
    old "{i}(Huh? What did I just touch with my head?){/i}"
    new "{i}(Was? Ist das seins? Oh mein...){/i}"

    # say L2783 ang
    old "{i}(W- what? Is that his? Oh my...){/i}"
    new "{i}(W-was? Ist das seins? Oh mein...){/i}"

    # say L2786 ang
    old "{i}(I did feel something during the last position, but I thought it was just his arm.){/i}"
    new "{i}(Ich habe da was gespürt in der letzten Position, aber ich dachte, es wäre nur sein Arm.){/i}"

    # say L2789 ang
    old "{i}(I feel better than I've felt in a while.){/i}"
    new "{i}(Ich fühle mich besser als seit langem.){/i}"

    # say L2790 ang
    old "{i}(I haven't felt this way since my therapy sessions with Dr. Johnson...){/i}"
    new "{i}(Ich habe mich nicht mehr so gefühlt, seit ich die Therapiesitzungen bei Dr. Johnson hatte...){/i}"

    # say L2791 pla
    old "Ok, I think we can stop for now Angelina."
    new "Okay, ich denke, wir können jetzt aufhören Angelina."

    # say L2792 ang
    old "Do we have to? I think this is really helping me."
    new "Müssen wir? Ich glaube, das hilft mir wirklich."

    # say L2793 ang
    old "I'm enjoying it a lot."
    new "Ich genieße es wirklich."

    # say L2794 pla
    old "Uhh, o- ok, I guess we can keep going for a while."
    new "Uhh, o- ok, ich denke, wir können noch ein bisschen weitermachen."

    # say L2798 ang
    old "I should just do it!"
    new "Ich sollte es einfach tun!"

    # say L2805 pla
    old "Angelina? W-what are you doing?"
    new "Angelina? W-was machst du da?"

    # say L2807 ang
    old "Well, I noticed your boner."
    new "Na ja, ich hab dein Ständer bemerkt."

    # say L2808 ang
    old "And I thought I should give you a hand with it."
    new "Und ich dachte, ich sollte dir dabei helfen."

    # say L2809 pla
    old "B-But..."
    new "Aber..."

    # say L2810 ang
    old "Oh come on, just let me do this."
    new "Oh komm schon, lass mich das machen."

    # say L2811 ang
    old "I want to do it, and it's not like we haven't done it before!"
    new "Ich will es tun, und es ist ja nicht so, als hätten wir es noch nie getan!"

    # say L2828 pla
    old "Uhmm, hey, are you alright?"
    new "Uhmm, hey, geht's dir gut?"

    # say L2829 pla
    old "Would you mind telling me what that was?"
    new "Kannst du mir sagen, was das gerade war?"

    # say L2830 ang
    old "I'm sorry [pla], I suppose you weren't expecting that."
    new "Entschuldige [pla], ich glaube, damit hast du nicht gerechnet."

    # say L2831 ang
    old "I- I didn't mean to surprise you that way."
    new "Ich- Ich wollte dich nicht so erschrecken."

    # say L2832 pla
    old "Hey, it's alright... I think."
    new "Hey, ist schon gut... glaub ich."

    # say L2833 pla
    old "It's just that you caught me off guard."
    new "Es ist nur, dass du mich überrascht hast."

    # say L2835 ang
    old "Again, I'm sorry about that."
    new "Wieder, es tut mir leid dafür."

    # say L2836 ang
    old "The thing is that I've been so frustrated lately that when I noticed you had an erection I just let myself go."
    new "Das Ding ist, ich war lately so frustriert, dass als ich gemerkt habe, dass du eine Erektion hast, ich mich einfach habe gehen lassen."

    # say L2837 pla
    old "Oh yeah? Why are you so frustrated?"
    new "Oh ja? Warum bist du denn so frustriert?"

    # say L2839 ang
    old "Well, I- I haven't been having sex with my husband lately."
    new "Na ja, ich- ich habe neuerdings nicht mehr mit meinem Mann geschlafen."

    # say L2840 pla
    old "You haven't? But I thought that the sessions with Dr. Johnson..."
    new "Du nicht? Aber ich dachte, die Sitzungen mit Dr. Johnson..."

    # say L2842 ang
    old "They did help..."
    new "Sie haben geholfen..."

    # say L2844 ang
    old "After we were done, I did become more open in that regard. I'm now able to perform my duties as a wife."
    new "Nachdem wir fertig waren, bin ich da offener geworden. Ich kann jetzt meine Pflichten als Ehefrau erfüllen."

    # say L2846 ang
    old "But I would be lying if I said that I enjoy it."
    new "Aber ich würde lügen, wenn ich sagen würde, dass ich es genieße."

    # say L2848 ang
    old "To be honest, I haven't enjoyed sex since I was with you and Dr. Johnson."
    new "Ehrlich gesagt, ich habe seit dir und Dr. Johnson keinen Spaß mehr daran gehabt."

    # say L2850 ang
    old "When I got pregnant I got this huge boost in my libido."
    new "Als ich schwanger wurde, habe ich einen riesigen Libidoboost bekommen."

    # say L2851 ang
    old "I was hoping that it would improve things in bed with my husband."
    new "Ich hatte gehofft, dass es das zwischen uns im Bett verbessern würde."

    # say L2852 pla
    old "And did it help?"
    new "Und hat es geholfen?"

    # say L2854 ang
    old "Not at all, I just don't desire him. So I'm just left feeling frustrated."
    new "Gar nicht, ich hab einfach kein Verlangen nach ihm. Deshalb fühle ich mich nur frustriert."

    # say L2855 ang
    old "I guess that's why I reacted that way when I noticed that you had that boner."
    new "Dann ist es wohl auch klar, warum ich so reagiert habe, als ich gemerkt hab, dass du eine Erektion hattest."

    # say L2856 ang
    old "I'm sorry [pla]."
    new "Es tut mir leid [pla]."

    # say L2858 pla
    old "Nah, it's alright, don't worry."
    new "Nah, ist schon gut, mach dir keine Sorgen."

    # say L2859 pla
    old "You just caught me by surprise, but it's no problem really."
    new "Du hast mich nur überrascht, aber es ist wirklich kein Problem."

    # say L2860 pla
    old "But you know, I think there might be something that I can do for you."
    new "Aber weißt du, ich denke, da könnte was sein, das ich für dich tun kann."

    # say L2862 ang
    old "There is?!"
    new "Da ist?!"

    # say L2864 pla
    old "Sure! Yoga's not just about positions."
    new "Klar! Yoga geht nicht nur um die Positionen."

    # say L2865 pla
    old "It's about improving your relationship with yourself by helping you balance your energy and your chakras."
    new "Es geht darum, deine Beziehung zu dir selbst zu verbessern, indem du dein Energiegleichgewicht und deine Chakras ausbalancierst."

    # say L2866 pla
    old "I already helped you once before, I don't see why not help you again."
    new "Ich habe dir schon einmal geholfen, ich sehe keinen Grund, es nicht wieder zu tun."

    # say L2867 pla
    old "So for the next session, I think we'll focus on that."
    new "Dann konzentrieren wir uns beim nächsten Mal darauf."

    # say L2869 ang
    old "Oh that sounds amazing [pla]! Thank you so much!"
    new "Oh das klingt wunderbar [pla]! Danke schön!"

    # say L2872 pla
    old "But for now I think we should get going, so Lisa won't worry about this taking too long."
    new "Aber für jetzt denke ich, wir sollten aufbrechen, damit Lisa sich nicht sorgt, dass es zu lange dauert."

    # say L2890 lis
    old "Well, how do you feel, Angelina?"
    new "Na, wie fühlst du dich, Angelina?"

    # say L2891 ang
    old "I feel great! Thanks, Lisa!"
    new "Ich fühle mich großartig! Danke, Lisa!"

    # say L2892 lis
    old "I can see that, I'm glad to see evidence of the positive effect yoga's having on you."
    new "Das sehe ich, ich freue mich, dass die Yoga-Übungen so positiv auf dich wirken."

    # say L2893 lis
    old "It also makes me happy to see that [pla]'s been a proper guide for you on this yoga journey."
    new "Es freut mich auch zu sehen, dass [pla] dir auf deiner Yogareise eine gute Führung gibt."

    # say L2895 ang
    old "He really has been, and I can't wait for my next class."
    new "Er hat es wirklich getan, und ich freue mich schon auf meine nächste Stunde."

    # say L2897 lis
    old "Well, I'll schedule it right away."
    new "Dann werde ich es gleich einplanen."

    # say L2899 ang
    old "Thank you, and thank you, [pla]."
    new "Danke, und danke, [pla]."

    # say L2901 pla
    old "You're welcome, I'll see you next time."
    new "Gern geschehen, bis zum nächsten Mal."

    # say L2905 lis
    old "Goodbye, and until next time."
    new "Tschüss und bis zum nächsten Mal."

    # say L2920 lis
    old "Okay, so, tell me how did you feel her energy today?"
    new "Okay, also, erzähl mir, wie hast du ihre Energie heute gespürt?"

    # say L2921 pla
    old "Well, honestly, I saw that she was doing the exercises better."
    new "Na ja, ehrlich gesagt, habe ich gesehen, dass sie die Übungen besser gemacht hat."

    # say L2922 lis
    old "Really? In my last session with her, I felt her so much more connected."
    new "Wirklich? In meiner letzten Sitzung mit ihr habe ich sie viel mehr verbunden gefühlt."

    # say L2923 lis
    old "Definitely, a masculine energy was just what her chakras needed to let go."
    new "Definitiv, eine männliche Energie war genau das, was ihre Chakras brauchten, um loszulassen."

    # say L2925 pla
    old "Yeah, she really let herself go..."
    new "Ja, sie hat sich wirklich fallen lassen..."

    # say L2926 lis
    old "Excellent, [pla], fate truly gifted me by bringing you into my path."
    new "Exzellent, [pla], das Schicksal hat mich wahrhaft begünstigt, indem es dich auf meinen Weg geführt hat."

    # say L2929 lis
    old "By the way, I wanted to ask how your evenings look for scheduling the next tantric session with Anastasia?"
    new "Übrigens, ich wollte fragen, wie deine Abende aussehen, um den nächsten tantrischen Session mit Anastasia zu planen?"

    # say L2930 pla
    old "Hmm, fine, I don't think I’ll have any problem coming at night."
    new "Hmm, gut, ich denke, ich werde abends kein Problem haben zu kommen."

    # say L2931 lis
    old "Excellent! See how the universe puts everything in its place?"
    new "Prima! Siehst du, wie das Universum alles an seinen Platz stellt?"

    # say L2932 lis
    old "I'll talk to Anastasia and set up an appointment for the next tantric session. We'll be expecting you at night as always."
    new "Ich rede mit Anastasia und vereinbare den Termin für die nächste tantrische Sitzung. Wir erwarten dich wie immer am Abend."

    # say L2934 pla
    old "Sure, count me in."
    new "Klar, zähl mich mit ein."

    # say L2935 lis
    old "Wonderful, I'll get everything ready, and I'll see you then."
    new "Wunderbar, ich werde alles vorbereiten und mich auf dich freuen."

    # say L2964 pla
    old "Hmm, this is odd, there's no one here."
    new "Hmm, das ist seltsam, hier ist niemand."

    # say L2965 pla
    old "Anastasia hasn't arrived? Maybe she's running late?"
    new "Anastasia ist noch nicht da? Vielleicht ist sie aufgehalten worden?"

    # say L2966 pla
    old "I'll take a look upstairs, maybe they're already in the yoga room."
    new "Ich schau mal oben nach, vielleicht sind sie schon im Yogaraum."

    # say L2987 pla
    old "Oh! You're both here already, did I arrive too late?"
    new "Oh! Ihr seid beide schon da, bin ich zu spät gekommen?"

    # say L2989 lis
    old "Hi [pla], good evening."
    new "Hi [pla], guten Abend."

    # say L2990 lis
    old "No, it's alright, Anastasia just got here early, so we got ready and were just chatting."
    new "Nein, alles in Ordnung, Anastasia ist nur etwas früher gekommen, also haben wir uns vorbereitet und ein bisschen geplaudert."

    # say L2992 lis
    old "But you're not late or anything."
    new "Aber du bist nicht zu spät oder so."

    # say L2993 pla
    old "I see, that's good to hear."
    new "Ich sehe, das ist gut zu hören."

    # say L2995 lis
    old "Yeah, but now that you're here, we can begin. Why don't you go and get changed?"
    new "Okay, aber jetzt, wo du hier bist, können wir anfangen. Warum ziehst du dich nicht um?"

    # say L3018 pla
    old "Alright, I'm ready."
    new "Okay, ich bin bereit."

    # say L3020 lis
    old "Excellent."
    new "Perfekt."

    # say L3023 lis
    old "Ok, are you ready to start, Anastasia?"
    new "Okay, bist du bereit loszulegen, Anastasia?"

    # say L3025 ana
    old "Oh yeah, I'm more than ready!"
    new "Oh ja, ich bin mehr als bereit!"

    # say L3026 ana
    old "After last time, I've been waiting for this."
    new "Nach dem letzten Mal habe ich darauf gewartet."

    # say L3028 ana
    old "I can't wait to have another orgasm like last time. I want to cum."
    new "Ich freue mich schon auf den nächsten Orgasmus wie beim letzten Mal. Ich will kommen."

    # say L3030 lis
    old "Well, I'm glad you're this excited for the session."
    new "Na, ich freue mich, dass du so aufgeregt bist für die Sitzung."

    # say L3032 lis
    old "But remember, what's most important is that you're able to connect with yourself and feel the energy flow through you."
    new "Aber denk dran, das Wichtigste ist, dass du dich mit dir selbst verbindest und die Energie durch dich fließen spürst."

    # say L3034 ana
    old "Of course, of course."
    new "Natürlich, natürlich."

    # say L3035 ana
    old "I haven't forgotten what you taught me last time."
    new "Ich hab's nicht vergessen, was du mir letztes Mal beigebracht hast."

    # say L3037 lis
    old "Good, then we can begin."
    new "Gut, dann können wir anfangen."

    # say L3039 lis
    old "Are you ready too, [pla]?"
    new "Bist du auch bereit, [pla]?"

    # say L3040 pla
    old "Oh yeah, for sure."
    new "Oh ja, auf jeden Fall."

    # say L3041 lis
    old "Great, let's begin then."
    new "Super, dann fangen wir an."

    # say L3059 lis
    old "So, how was it, Anastasia? Did you enjoy the process?"
    new "Also, wie war es, Anastasia? Hast du den Prozess genossen?"

    # say L3061 ana
    old "Oh yeah! I loved it! It was amazing!"
    new "Oh ja! Ich hab's geliebt! Es war unglaublich!"

    # say L3063 ana
    old "It felt amazing, just like last time. I loved it!"
    new "Es war unglaublich, genau wie beim letzten Mal. Ich hab's geliebt!"

    # say L3065 lis
    old "I'm glad to hear that. It's a testament to the work being done to help you bring your chakras and energies into balance."
    new "Ich freue mich, das zu hören. Das zeigt, dass die Arbeit, um deine Chakras und Energien ins Gleichgewicht zu bringen, Früchte trägt."

    # say L3066 lis
    old "And I can see that you're doing very well, right [pla]?"
    new "Und ich sehe, dass es dir sehr gut geht, stimmt's [pla]?"

    # say L3068 pla
    old "Oh yeah, you're doing great."
    new "Oh ja, du machst das super."

    # say L3069 pla
    old "I can tell by your good mood that your Muladhara chakra is already getting balanced."
    new "Ich merke an deiner guten Laune, dass dein Muladhara-Chakra schon ins Gleichgewicht kommt."

    # say L3070 lis
    old "[pla]'s right, your energy is flowing so much better through your body."
    new "[pla] hat recht, deine Energie fließt viel besser durch deinen Körper."

    # say L3072 ana
    old "Thank you guys, I'm very happy to hear that."
    new "Danke euch beiden, ich freue mich sehr das zu hören."

    # say L3073 ana
    old "But, I was wondering if maybe we could do a little bit more."
    new "Aber, ich dachte, vielleicht könnten wir noch ein bisschen weitermachen."

    # say L3074 ana
    old "Y-You know, s-since you say I'm doing so well."
    new "Y-Ya, da ihr sagt, dass ich so gut mache."

    # say L3075 ana
    old "I would like to know if we can keep going."
    new "Ich würde gerne wissen, ob wir weitermachen können."

    # say L3076 ana
    old "Maybe we could do another exercise?"
    new "Vielleicht könnten wir noch eine Übung machen?"

    # say L3077 ana
    old "That's only if you think it's alright!"
    new "Das ist nur, wenn du das okay findest!"

    # say L3079 lis
    old "Actually, I was about to tell you just that."
    new "Eigentlich wollte ich dir gerade das Gleiche vorschlagen."

    # say L3081 lis
    old "You've done very well during this first stage of the process of chakra balancing."
    new "Du hast dich sehr gut in diesem ersten Schritt der Chakrabalancierung geschlagen."

    # say L3083 lis
    old "So I believe you're ready to try something new."
    new "Dann denke ich, du bist bereit, etwas Neues auszuprobieren."

    # say L3084 ana
    old "Really? Great! What will we be doing? I can't wait."
    new "Wirklich? Toll! Was werden wir machen? Ich kann es kaum erwarten."

    # say L3086 lis
    old "Well, the goal with what we've been doing so far is getting you to connect with yourself."
    new "Na ja, das Ziel bei dem, was wir bisher gemacht haben, war es, dir zu helfen, dich mit dir selbst zu verbinden."

    # say L3087 lis
    old "So that you could feel the flow of energy in your body."
    new "Damit du die Energieflüsse in deinem Körper spüren kannst."

    # say L3088 lis
    old "Now, it's time to create a connection with the outside, and for that, [pla] will be helping us in this new practice."
    new "Jetzt ist es an der Zeit, eine Verbindung nach außen herzustellen, und dafür wird uns [pla] bei dieser neuen Übung helfen."

    # say L3089 pla
    old "Alright, what are we going to do?"
    new "Okay, was machen wir jetzt?"

    # say L3091 lis
    old "We're engaging in a posture where the goal is for the three of us to create an energetic chain."
    new "Wir gehen in eine Position, bei der das Ziel ist, dass wir drei eine energetische Kette bilden."

    # say L3092 lis
    old "The point of that is that we're able to unite our energies."
    new "Das Ziel dabei ist, dass wir unsere Energien vereinen können."

    # say L3093 lis
    old "And you can allow yourself to release what's pent up inside of you, Anastasia."
    new "Und du kannst dich erlauben, das zu entladen, was in dir steckt, Anastasia."

    # say L3094 ana
    old "Okay, that sounds interesting."
    new "Okay, das klingt interessant."

    # say L3095 ana
    old "I bet that's going to feel even better than the massage."
    new "Ich wette, das wird sich noch besser anfühlen als die Massage."

    # say L3096 lis
    old "Sure, it might."
    new "Klar, könnte sein."

    # say L3097 lis
    old "But you have to remember that whatever sexual pleasure you get from this is only secondary to the actual goal of getting your chakras in proper balance."
    new "Aber du musst dran denken, dass die sexuelle Befriedigung, die du daraus ziehst, nur sekundär ist im Vergleich zum eigentlichen Ziel, deine Chakras in Balance zu bringen."

    # say L3099 ana
    old "Of course, of course, I haven't forgotten."
    new "Natürlich, natürlich, ich hab's nicht vergessen."

    # say L3101 lis
    old "Alright, it's time to start."
    new "Okay, es ist Zeit anzufangen."

    # say L3110 ana
    old "I- Is this okay? Am I positioned properly?"
    new "I- Ist das okay? Bin ich richtig positioniert?"

    # say L3111 lis
    old "You are, that's just perfect."
    new "Du bist es, das ist perfekt."

    # say L3112 lis
    old "How are you [pla]? Is this comfortable for you?"
    new "Wie geht es dir [pla]? Ist das für dich angenehm?"

    # say L3113 pla
    old "Y- yeah! No problem!"
    new "K- klar! Kein Problem!"

    # say L3114 lis
    old "Good, then we're going to start moving slowly."
    new "Gut, dann fangen wir langsam an."

    # say L3128 lis
    old "Ok, I would like to ask if you have any comments on how this process is going."
    new "Okay, ich würde gerne fragen, ob du irgendwelche Anmerkungen zu dem, wie der Prozess verläuft, hast."

    # say L3130 ana
    old "The only thing I have to say is that it's been amazing!"
    new "Das Einzige, was ich sagen kann, ist, dass es unglaublich war!"

    # say L3131 ana
    old "It's just as good as I wanted it to be."
    new "Es ist genau so gut, wie ich es mir gewünscht habe."

    # say L3132 ana
    old "Although, I still would love to do something a little... Harder with [pla]."
    new "Aber ich würde immer noch gerne etwas ein bisschen... Harteres mit [pla] machen."

    # say L3133 lis
    old "All in good time."
    new "Alles zu seiner Zeit."

    # say L3134 lis
    old "But I'm glad to hear that you're satisfied with the way this has been working."
    new "Aber ich freue mich zu hören, dass dir die Art und Weise gefällt, wie das bisher funktioniert hat."

    # say L3135 lis
    old "What do you say we get dressed and come down?"
    new "Was sagst du, wir ziehen uns an und kommen runter?"

    # say L3145 lis
    old "Alright, I will be seeing you both for the next session."
    new "Okay, ich sehe euch beide bei der nächsten Sitzung."

    # say L3147 ana
    old "Sure, but before I leave, I want to thank you, Lisa."
    new "Klar, aber bevor ich gehe, wollte ich mich bei dir bedanken, Lisa."

    # say L3150 ana
    old "At first, I was only interested in having sex with you guys."
    new "Am Anfang war ich nur daran interessiert, mit euch beiden zu schlafen."

    # say L3153 ana
    old "But doing this has been an eye-opening experience for me."
    new "Aber das hier war eine Augeneröffnung für mich."

    # say L3154 ana
    old "This has completely changed my perspective about what pleasure and enjoyment are."
    new "Das hat meine Sicht auf Vergnügen und Freude komplett verändert."

    # say L3156 lis
    old "I'm glad you feel this way about what we've been doing. That's the main goal of this."
    new "Ich freue mich, dass du so empfindest, was wir gemacht haben. Das ist das Hauptziel davon."

    # say L3157 ana
    old "Thanks a lot, Lisa, and also you, [pla]. I can't wait for the next session."
    new "Danke schön, Lisa, und auch dir, [pla]. Ich freue mich schon auf die nächste Session."

    # say L3159 lis
    old "Very well. We’ll schedule it after our next yoga session."
    new "Sehr gut. Wir legen es nach unserer nächsten Yogastunde fest."

    # say L3173 lis
    old "So, how did you find today's session? Did you feel all that energy and balance between the three of you?"
    new "So, wie hast du die Sitzung heute gefunden? Hast du diese Energie und Balance zwischen euch dreien gespürt?"

    # say L3174 pla
    old "Hmm, yeah, I definitely felt it a lot."
    new "Hmm, ja, ich hab's definitiv gespürt."

    # say L3175 lis
    old "It's amazing. And did you hear what she said about the whole process?"
    new "Das ist unglaublich. Und hast du gehört, was sie über den ganzen Prozess gesagt hat?"

    # say L3176 lis
    old "I really feel like I'm an instrument of the universe, balancing and transmitting energy to all my clients."
    new "Ich fühle mich wirklich wie ein Instrument des Universums, das Energie an alle meine Kundinnen ausgleicht und weitergibt."

    # say L3177 pla
    old "Yes, you’ve truly helped all the women you’ve worked with."
    new "Ja, du hast wirklich allen Frauen geholfen, mit denen du gearbeitet hast."

    # say L3178 lis
    old "Thank you for your words. By the way, I wanted to talk to you about Angelina."
    new "Danke für deine Worte. Übrigens, ich wollte mit dir über Angelina sprechen."

    # say L3179 pla
    old "Uhh, sure, tell me..."
    new "Uhh, klar, erzähl mir..."

    # say L3180 lis
    old "Well, I had a yoga session with Angelina, and I have to tell you that I've seen an impressive improvement in her condition."
    new "Na ja, ich hatte eine Yogastunde mit Angelina und muss dir sagen, dass ich einen beeindruckenden Fortschritt bei ihrem Zustand feststellen konnte."

    # say L3181 lis
    old "The problems with her Muladhara chakra seem to be getting resolved."
    new "Die Probleme mit ihrem Muladhara-Chakra scheinen sich zu lösen."

    # say L3182 lis
    old "She's still not entirely ok, but I can feel her prana flowing better within her body."
    new "Sie ist noch nicht vollständig okay, aber ich spüre, dass ihr Prana in ihrem Körper besser fließt."

    # say L3183 lis
    old "Her energy is a lot more balanced, and I can see her being more receptive to the flow of energy among her chakras."
    new "Ihre Energie ist viel ausgeglichener, und ich spüre, dass sie offener für den Energiestrom in ihren Chakren wird."

    # say L3184 lis
    old "I must start recommending you to my other clients that may have some problems with their energy flow."
    new "Ich muss anfangen, dich meinen anderen Kunden zu empfehlen, die Probleme mit ihrem Energiefluss haben."

    # say L3185 lis
    old "You've done so much by helping first Anastasia, and then Angelina."
    new "Du hast so viel erreicht, indem du zuerst Anastasia und dann Angelina geholfen hast."

    # say L3186 lis
    old "You've done an excellent job [pla], congratulations."
    new "Du hast eine ausgezeichnete Arbeit geleistet [pla], gratuliere."

    # say L3187 pla
    old "W-well, thank you."
    new "W-nun, danke."

    # say L3189 lis
    old "The last thing is that she asked me if there was a possibility of you giving her another class."
    new "Die letzte Sache ist, dass sie mich gefragt hat, ob es eine Möglichkeit gibt, dass du ihr noch eine Stunde gibst."

    # say L3191 pla
    old "Sure! If our sessions together are working, then I'm more than happy to do it. No problem."
    new "Klar! Wenn unsere Sitzungen gut laufen, bin ich gerne bereit, es zu tun. Kein Problem."

    # say L3193 lis
    old "Excellent, I'm glad you're willing to accept because I believe she still needs it."
    new "Perfekt, ich bin froh, dass du bereit bist, es zu akzeptieren, denn ich glaube, sie braucht es immer noch."

    # say L3194 lis
    old "So thank you [pla]."
    new "Dann danke dir [pla]."

    # say L3196 pla
    old "You're welcome, you know I'm more than happy to help you."
    new "Gern geschehen, du weißt ja, ich bin immer bereit, dir zu helfen."

    # say L3198 lis
    old "Thanks a lot [pla], I'll see you later then."
    new "Danke schön [pla], dann sehen wir uns später."

    # say L3227 pla
    old "Hey Lisa, hi Angelina, how are you?"
    new "Hey Lisa, hey Angelina, wie geht’s euch?"

    # say L3229 lis
    old "Hello [pla], good afternoon."
    new "Hallo [pla], guten Nachmittag."

    # say L3230 ang
    old "Hi, [pla], nice to see you again"
    new "Hi, [pla], schön dich wiederzusehen"

    # say L3233 lis
    old "Are you ready for your next session?"
    new "Bist du bereit für deine nächste Sitzung?"

    # say L3235 pla
    old "Yeah, sure, I'm ready."
    new "Klar, ich bin bereit."

    # say L3237 lis
    old "Great, I've already talked with Angelina and she's ready too. So let's go to the yoga room then."
    new "Super, ich habe schon mit Angelina gesprochen und sie ist auch bereit. Dann gehen wir mal in den Yogaraum."

    # say L3241 lis
    old "Well, I'll let you guys be, I hope you enjoy today's session as well Angelina."
    new "Na dann, ich lass euch mal, ich hoffe, ihr genießt die Sitzung heute auch, Angelina."

    # say L3243 ang
    old "Thank you, Lisa."
    new "Danke, Lisa."

    # say L3245 pla
    old "See you, Lisa."
    new "Bis später, Lisa."

    # say L3254 pla
    old "So, how are you?"
    new "So, wie geht's dir?"

    # say L3256 ang
    old "I'm feeling alright."
    new "Mir geht's ganz gut."

    # say L3257 ang
    old "But this whole deal with the pregnancy hormones has me going through the roof."
    new "Aber diese ganzen Schwangerschaftshormone bringen mich echt zum Dach hinaus."

    # say L3259 ang
    old "The doctor explained to me that it's perfectly normal."
    new "Der Arzt hat mir erklärt, dass das völlig normal ist."

    # say L3261 ang
    old "But I'm not sure about that, because I wasn't feeling this way before, it's just since I saw you that I started feeling this weird way."
    new "Aber ich bin mir da nicht so sicher, weil ich vorher nicht so gefühlt habe, erst seit ich dich gesehen habe, fühl ich mich so komisch."

    # say L3265 ang
    old "Yeah, but he said that as soon as the baby's born, everything should be fine."
    new "Ja, aber er sagte, sobald das Baby geboren ist, sollte alles wieder in Ordnung sein."

    # say L3267 ang
    old "So, keeping that in mind... I wanted to ask a favor of you [pla]."
    new "So, das im Hinterkopf... wollte ich dich um einen Gefallen bitten [pla]."

    # say L3269 ang
    old "Do you think you would be willing to help me again with these... needs that I have?"
    new "Glaubst du, du könntest mir wieder bei diesen... Bedürfnissen helfen?"

    # say L3271 ang
    old "I- It would just be the one time, I swear."
    new "Es wäre nur das eine Mal, ich schwöre."

    # say L3273 ang
    old "It's just that I'm feeling this enormous tension as of late, and I really need to deal with it."
    new "Es ist nur so, dass ich in letzter Zeit eine enorme Anspannung spüre und ich muss dringend damit fertig werden."

    # say L3274 ang
    old "And I think you're the only one who can really help me with it."
    new "Und ich denke, du bist der Einzige, der mir wirklich helfen kann."

    # say L3276 pla
    old "Uhh, I don't know... Lisa's downstairs and could come by any moment."
    new "Uhh, ich weiß nicht... Lisa ist unten und könnte jeden Moment reinschauen."

    # say L3277 pla
    old "Also, you're pregnant, I don't know how safe this is."
    new "Also, du bist schwanger, ich weiß nicht, wie sicher das ist."

    # say L3278 ang
    old "Don't worry about that, it's nothing dangerous. I already checked with my doctor. It'll just be quick, I promise I won't make much noise."
    new "Mach dir darüber keine Sorgen, es ist nichts Gefährliches. Ich habe mich schon bei meinem Arzt erkundigt. Es wird schnell gehen, ich verspreche, ich werde leise sein."

    # say L3279 pla
    old "But what about the yoga class..."
    new "Aber was ist mit dem Yogakurs..."

    # say L3280 ang
    old "Look, I signed up for the class with Lisa because I felt so repressed, just like when I studied with Dr. Johnson."
    new "Schau, ich habe mich für den Kurs mit Lisa angemeldet, weil ich mich so unterdrückt gefühlt habe, genau wie damals, als ich bei Dr. Johnson studiert habe."

    # say L3281 ang
    old "And being pregnant, I wanted to try something different... But I ended up finding you again, and well, my hormones went wild and they're practically shouting for it."
    new "Und schwanger wollte ich einfach was Neues ausprobieren... Aber dann hab ich dich wiedergetroffen und, na ja, meine Hormone sind durchgedreht und schreien praktisch danach."

    # say L3283 ang
    old "This would really help me more than a yoga class, and I think you know that."
    new "Das würde mir wirklich mehr helfen als ein Yogakurs, und ich denke, du weißt das."

    # say L3284 pla
    old "{b}*Sigh*{/b}, alright, but only this once, and then we'll go back to yoga classes like before."
    new "{b}*Seufz*{/b}, okay, aber nur dieses eine Mal, und danach gehen wir wieder zu den Yogastunden zurück."

    # say L3285 ang
    old "Yes, yes, go ahead, my body is craving it and I think you'll enjoy it too, really."
    new "Ja, ja, mach schon, mein Körper sehnt sich danach und ich denke, dir wird es auch gefallen, ehrlich."

    # say L3286 pla
    old "Hmm... Alright..."
    new "Hmm... Okay..."

    # say L3287 ang
    old "Ok, lie back and let me enjoy suking that big cock of yours."
    new "Ok, leg dich hin und lass mich genießen, wie ich deinen großen Schwanz blase."

    # say L3297 ang
    old "Mmm! I have been waiting for this since last time!"
    new "Mmm! Ich habe schon seit letztes Mal darauf gewartet!"

    # say L3298 ang
    old "I can't have enough of this!"
    new "Ich kann nie genug davon kriegen!"

    # say L3309 ang
    old "That felt wonderful [pla]!"
    new "Das hat sich wunderbar angefühlt [pla]!"

    # say L3311 pla
    old "Well, I'm glad that you're feeling better, that was the whole point of this."
    new "Na, ich bin froh, dass es dir besser geht, das war ja der Sinn der Sache."

    # say L3313 ang
    old "Thank you [pla], I also think that once the baby's born I'll feel a lot better."
    new "Danke [pla], ich denke auch, dass ich mich nach der Geburt viel besser fühlen werde."

    # say L3315 pla
    old "I'm sure you will."
    new "Ich bin sicher, dass du das wirst."

    # say L3316 pla
    old "Remember, if you really want a YOGA class, you can talk to Lisa."
    new "Denk dran, wenn du wirklich einen YOGA-Kurs willst, kannst du mit Lisa reden."

    # say L3318 ang
    old "Thank you [pla], I'll keep it in mind, and of course, if I ever need it, I'll let Lisa know."
    new "Danke [pla], ich werd's mir merken und natürlich, wenn ich mal was brauche, sag ich Lisa Bescheid."

    # say L3319 ang
    old "And I hope she'll tell you."
    new "Und ich hoffe, sie wird es dir sagen."

    # say L3322 ang
    old "Great! But for now, it's getting late, so I think I'll head home."
    new "Super! Aber für jetzt wird es spät, also denke ich, ich gehe nach Hause."

    # say L3323 ang
    old "But once again, thank you [pla], for all your help. This has been great."
    new "Aber nochmal danke [pla], für deine Hilfe. Das war toll."

    # say L3338 lis
    old "Are you guys done?"
    new "Seid ihr fertig?"

    # say L3340 ang
    old "We are. It was great, Lisa."
    new "Wir sind fertig. Es war toll, Lisa."

    # say L3341 lis
    old "I can see that, it seems the yoga really worked on you, Angelina."
    new "Das sehe ich, das Yoga hat dir wirklich gutgetan, Angelina."

    # say L3343 lis
    old "I can see your energy flowing a lot better within you."
    new "Ich sehe, dass deine Energie viel besser in dir fließt."

    # say L3344 lis
    old "Very good, [pla], you've done a good job."
    new "Sehr gut, [pla], du hast gute Arbeit geleistet."

    # say L3346 ang
    old "He has been a very good teacher."
    new "Er war ein sehr guter Lehrer."

    # say L3348 lis
    old "I can see that."
    new "Das sehe ich."

    # say L3349 lis
    old "I hope you'll keep coming to classes after this, Angelina."
    new "Ich hoffe, du kommst auch nach dem Baby weiterhin zu den Kursen, Angelina."

    # say L3351 ang
    old "I will, I'll keep coming even after the baby's born."
    new "Ich werd's tun, ich werde auch nach der Geburt des Babys weiterkommen."

    # say L3352 lis
    old "That's wonderful news."
    new "Das ist wunderbare Neuigkeit."

    # say L3354 ang
    old "Thank you, both of you."
    new "Danke, euch beiden."

    # say L3355 ang
    old "I'll go home now."
    new "Ich gehe jetzt nach Hause."

    # say L3356 ang
    old "But I'll come back soon for my next class."
    new "Aber ich komme bald wieder für meinen nächsten Kurs."

    # say L3357 lis
    old "Of course, see you soon."
    new "Natürlich, bis bald."

    # say L3372 lis
    old "She's definitely looking much better, [pla]. You did a great job with her today."
    new "Sie sieht definitiv viel besser aus, [pla]. Du hast heute großartige Arbeit geleistet."

    # say L3373 pla
    old "Uh, yeah, it was an excellent session. She really enjoyed it."
    new "Ja, es war eine ausgezeichnete Sitzung. Sie hat es wirklich genossen."

    # say L3374 lis
    old "Awesome! You’ve learned how to transmit that energy well. I truly feel you’ll become a great instrument for the universe."
    new "Super! Du hast gelernt, diese Energie gut zu übertragen. Ich spüre echt, dass du ein großartiges Instrument für das Universum werden wirst."

    # say L3375 lis
    old "Speaking of which, I’m scheduling a new tantric session with Angelina. Could you come by one evening soon?"
    new "Ach ja, ich plane gerade eine neue tantrische Sitzung mit Angelina. Könntest du eines Abends vorbeikommen?"

    # say L3376 pla
    old "Uh, sure, no problem."
    new "Klar, kein Problem."

    # say L3403 pla
    old "Hmm, they're not here again."
    new "Hmm, sie sind wieder mal nicht da."

    # say L3404 pla
    old "Well, I imagine that just means that they're already up in the yoga room."
    new "Dann sind sie wahrscheinlich schon im Yogaraum."

    # say L3425 lis
    old "Hello [pla], I'm glad you arrived."
    new "Hallo [pla], ich freue mich, dass du angekommen bist."

    # say L3427 pla
    old "Hey, were you waiting too long for me?"
    new "Hey, hast du schon lange auf mich gewartet?"

    # say L3429 lis
    old "No, Anastasia arrived not too long ago, and we just got ready. Why don't you get changed so we can start?"
    new "Nein, Anastasia ist erst vor kurzem angekommen und wir haben uns gerade fertig gemacht. Warum ziehst du dich nicht um, dann können wir anfangen?"

    # say L3454 lis
    old "Great, then we can start with the session."
    new "Super, dann können wir mit der Sitzung beginnen."

    # say L3456 ana
    old "Lisa told me that we would be trying something new today."
    new "Lisa hat mir gesagt, dass wir heute etwas Neues ausprobieren werden."

    # say L3457 ana
    old "I can't wait to see what we'll do."
    new "Ich freue mich schon darauf, zu sehen, was wir machen werden."

    # say L3460 lis
    old "Of course, but remember that before anything else you have to connect with yourself."
    new "Natürlich, aber denk dran, dass du vor allem mit dir selbst verbunden sein musst."

    # say L3461 lis
    old "And focus on the balance of your chakras."
    new "Und konzentriere dich auf das Gleichgewicht deiner Chakras."

    # say L3464 ana
    old "It's just that I'm very excited to see what's coming."
    new "Es ist nur, dass ich sehr gespannt bin, was kommt."

    # say L3466 lis
    old "Let's begin then, so you can see how it is."
    new "Dann lass uns anfangen, damit du sehen kannst, wie es ist."

    # say L3484 lis
    old "Well done Anastasia, I can see by how well you're doing that these sessions have been very effective for you."
    new "Gut gemacht Anastasia, ich sehe daran, wie gut du dich machst, dass diese Sitzungen sehr erfolgreich für dich waren."

    # say L3485 lis
    old "How do you feel about what we've been doing?"
    new "Wie fühlst du dich bei dem, was wir machen?"

    # say L3487 ana
    old "I feel great! I no longer feel any nervousness or anxiety about what we're doing."
    new "Ich fühle mich großartig! Ich habe keine Nervosität oder Angst mehr, was wir tun."

    # say L3488 ana
    old "And it's all thanks to you both, [pla] and Lisa. Thank you."
    new "Und das habe ich alles euch beiden, [pla] und Lisa, zu verdanken. Danke."

    # say L3490 pla
    old "Hey, I'm happy to help."
    new "Hey, ich freue mich, dir zu helfen."

    # say L3491 lis
    old "It makes me happy to see that you're doing so well."
    new "Es freut mich zu sehen, dass es dir so gut geht."

    # say L3492 lis
    old "And I believe you're ready for the next stage."
    new "Und ich glaube, du bist bereit für die nächste Stufe."

    # say L3493 ana
    old "Alright, great! I trust that you know what's best."
    new "Okay, toll! Ich vertraue darauf, dass du weißt, was das Beste für mich ist."

    # say L3495 lis
    old "Now, for this next exercise, the idea is that you finish the internal connection with yourself."
    new "Für die nächste Übung sollst du die innere Verbindung mit dir selbst vervollständigen."

    # say L3496 lis
    old "The first one we made was to help you relax and understand yourself on a deeper level."
    new "Die erste haben wir gemacht, um dir zu helfen, dich zu entspannen und dich auf einer tieferen Ebene zu verstehen."

    # say L3497 lis
    old "The second one was focused on you learning to let your energy flow freely in and out of you."
    new "Die zweite Übung war darauf ausgerichtet, dass du lernst, deine Energie frei in und aus dir fließen zu lassen."

    # say L3498 lis
    old "This last one is about you using what you have learned to forge a new connection with your inner being."
    new "Dieses letzte Mal geht es darum, dass du das Gelernte nutzt, um eine neue Verbindung zu deinem Inneren zu schmieden."

    # say L3499 lis
    old "For this, [pla] will be playing an important role, but what's most important is that you focus on yourself, okay?"
    new "Für das hier wird [pla] eine wichtige Rolle spielen, aber am wichtigsten ist, dass du dich auf dich selbst konzentrierst, okay?"

    # say L3501 ana
    old "Sure! I get it!"
    new "Klar! Ich hab's kapiert!"

    # say L3503 lis
    old "Alright, let's get started."
    new "Okay, dann fangen wir an."

    # say L3511 lis
    old "Ok, are you ready?"
    new "Ok, bist du bereit?"

    # say L3512 ana
    old "Yes, I am, I feel like I can do this now."
    new "Ja, ich bin bereit, ich fühle mich jetzt stark genug dafür."

    # say L3513 lis
    old "Remember to keep your breathing stable."
    new "Denk dran, dein Atmen gleichmäßig zu halten."

    # say L3514 lis
    old "Focus on yourself, what you're feeling deep inside."
    new "Konzentriere dich auf dich selbst, auf das, was du tief drinnen spürst."

    # say L3515 lis
    old "On the balance of your chakras."
    new "Auf die Balance deiner Chakras."

    # say L3529 lis
    old "Well done, Anastasia. I can clearly see a change in you from the time we started this process to now."
    new "Gut gemacht, Anastasia. Ich sehe deutlich, wie sich an dir verändert hat, seit wir mit diesem Prozess begonnen haben."

    # say L3530 lis
    old "Your chakras are much more balanced now, and I can feel all the positive energy coming from you."
    new "Deine Chakras sind jetzt viel ausgeglichener, und ich spüre all die positive Energie, die von dir ausgeht."

    # say L3532 ana
    old "Thank you, Lisa, and thank you, [pla]."
    new "Danke, Lisa, und danke, [pla]."

    # say L3535 ana
    old "Because of this great help from you two, my perspective on sex has completely changed."
    new "Dank eurer großartigen Hilfe hat sich mein Blick auf Sex vollständig verändert."

    # say L3536 ana
    old "I'll be sure to apply this to my own life in the future."
    new "Ich werde das sicher in mein eigenes Leben integrieren."

    # say L3537 lis
    old "Excellent! Because that's exactly what this is about!"
    new "Super! Denn genau darum geht es hier!"

    # say L3538 lis
    old "As I already explained to [pla], this is something that you can live in every area of your life."
    new "Wie ich [pla] schon erklärt habe, ist das etwas, das du in jedem Bereich deines Lebens leben kannst."

    # say L3539 lis
    old "It's not just about sex, but about how you project your energy daily, and it makes me happy that you understood that."
    new "Es geht nicht nur um Sex, sondern darum, wie du deine Energie täglich projizierst, und es freut mich, dass du das verstanden hast."

    # say L3541 ana
    old "Thank you, Lisa, I'll be sure to remember that."
    new "Danke, Lisa, ich werde das sicher nicht vergessen."

    # say L3542 ana
    old "Really, what I got from these sessions is more than what I was expecting."
    new "Wirklich, was ich aus diesen Sitzungen mitgenommen habe, ist mehr, als ich erwartet habe."

    # say L3544 lis
    old "I'm happy that's how you feel, but this isn't a finished process."
    new "Ich freue mich, dass du so denkst, aber das ist noch kein abgeschlossener Prozess."

    # say L3545 lis
    old "It's important that you keep practicing these teachings in the future."
    new "Es ist wichtig, dass du diese Lehren auch in Zukunft weiter übst."

    # say L3547 ana
    old "I'll be sure to do that."
    new "Ich werde dran arbeiten."

    # say L3548 lis
    old "Great! Now, it's late, so let's get changed so that you two can go home."
    new "Super! Es ist schon spät, also ziehen wir uns um, damit ihr beiden nach Hause könnt."

    # say L3558 lis
    old "Alright, that's it for now, but remember, we will see each other soon, okay? Both for your regular yoga classes, and for tantric sesions."
    new "Okay, das war's für heute, aber denk dran, wir sehen uns bald, okay? Sowohl bei deinen regulären Yogastunden als auch bei den tantrischen Sitzungen."

    # say L3560 ana
    old "Sure, I'll be seeing you soon."
    new "Klar, ich sehe dich bald."

    # say L3561 ana
    old "Thanks again to both of you, see you."
    new "Danke nochmal euch beiden, bis bald."

    # say L3562 pla
    old "Happy to help, see you later."
    new "Gern geschehen, bis später."

    # say L3574 lis
    old "Okay, I think this first step of adding other areas besides yoga to my classes was a total success."
    new "Okay, ich denke, dieser erste Schritt, neben Yoga auch andere Bereiche in meine Kurse aufzunehmen, war ein voller Erfolg."

    # say L3575 pla
    old "Yeah, I think it would go really well if you offered it to more of your clients."
    new "Ja, ich denke, es würde super funktionieren, wenn du es mehr deinen Klienten anbietest."

    # say L3576 lis
    old "Wow [pla], I feel so excited about this path the universe is taking me on."
    new "Wow [pla], ich fühle mich so aufgeregt über diesen Weg, den das Universum mir zeigt."

    # say L3577 lis
    old "I believe we can do great things to help a lot of people."
    new "Ich glaube, wir können großartige Dinge tun, um vielen Menschen zu helfen."

    # say L3578 pla
    old "I'm sure of it."
    new "Ich bin mir sicher."

    # say L3579 lis
    old "I’ll follow the natural flow of destiny, I’ll take it step by step; I don’t want things to get out of hand."
    new "Ich werde dem natürlichen Verlauf des Schicksals folgen, Schritt für Schritt; ich will nicht, dass alles außer Kontrolle gerät."

    # say L3580 lis
    old "I hope you can keep helping me, there are many clients who would really benefit from your energy and vitality."
    new "Ich hoffe, du kannst weiterhin helfen, es gibt viele Kunden, die von deiner Energie und Vitalität profitieren würden."

    # say L3581 pla
    old "Of course, count on me whenever you need."
    new "Natürlich, zähl auf mich, wann immer du mich brauchst."

    # say L3582 lis
    old "Aww, you’ve been such a wonderful gift from the universe to me."
    new "Ach, du bist ein wunderbares Geschenk des Universums für mich."

    # say L3583 lis
    old "Oh, speaking of that, I didn’t think it was necessary, but Angelina asked again for you to accompany her in a new class."
    new "Oh, da fällt mir ein, ich dachte, es wäre nicht nötig, aber Angelina hat wieder nach dir gefragt, um sie in einer neuen Klasse zu begleiten."

    # say L3584 pla
    old "Hmm, yeah, I figured that would happen."
    new "Hmm, ja, das habe ich mir schon gedacht."

    # say L3585 lis
    old "You’ve done so much good for that girl, the difference is noticeable. She looks radiant, smiling, with such special energy."
    new "Du hast so viel Gutes für dieses Mädchen getan, der Unterschied ist auffällig. Sie sieht strahlend aus, lächelt und hat eine ganz besondere Energie."

    # say L3586 lis
    old "Does it sound good if I schedule you with her for a session in the afternoon?"
    new "Klingt gut, wenn ich euch für den Nachmittag ein plane?"

    # say L3587 pla
    old "Yes, go ahead, no problem. I’ll talk to her about what she really wants to focus on."
    new "Ja, mach ruhig, kein Problem. Ich rede mit ihr über das, was sie sich wirklich wünscht."

    # say L3588 lis
    old "Sounds great, you’re a real guru! I’ll schedule the appointment with her and we’ll see each other then for your next session with her."
    new "Klingt super, du bist ein echter Guru! Ich werde den Termin mit ihr vereinbaren und dann sehen wir uns bei deiner nächsten Sitzung mit ihr."

    # say L3589 pla
    old "Okay, thanks Lisa, we’ll meet then for Angelina’s next session. Have a good night."
    new "Okay, danke Lisa, dann sehen wir uns bei Angelinas nächster Sitzung. Gute Nacht."

    # say L3590 lis
    old "Rest well [pla], take care."
    new "Schlaf gut [pla], pass auf dich auf."

    # say L3617 lis
    old "Oh, hey [pla], you’re just in time, Angelina just arrived too."
    new "Oh, hey [pla], du kommst gerade richtig, Angelina ist auch gerade angekommen."

    # say L3618 ang
    old "Hi [pla], great to see you again."
    new "Hi [pla], toll dich wiederzusehen."

    # say L3619 pla
    old "Hey Angelina, how are you?"
    new "Hey Angelina, wie geht's dir?"

    # say L3620 ang
    old "Excited for the new yoga class."
    new "Ich freue mich auf den neuen Yogakurs."

    # say L3621 pla
    old "Uh, heh, yeah, I can imagine..."
    new "Uh, heh, ja, ich kann mir das vorstellen..."

    # say L3623 lis
    old "Well, I see you’re both eager for the class, so why not head upstairs and enjoy it?"
    new "Na, ich sehe, ihr seid beide ganz wild auf den Kurs. Warum geht ihr nicht nach oben und genießt ihn?"

    # say L3624 ang
    old "Sounds perfect, I’m excited, let’s go [pla]."
    new "Klingt perfekt, ich bin aufgeregt, lass uns gehen [pla]."

    # say L3625 pla
    old "{b}*Sigh*{/b}, Sure, let’s go."
    new "{b}*Seufz*{/b}, Klar, lass uns gehen."

    # say L3633 pla
    old "Okay, okay, what did we talk last time?"
    new "Okay, okay, worüber haben wir das letzte Mal gesprochen?"

    # say L3634 pla
    old "Because I don’t think you came just to practice yoga exercises, right?"
    new "Weil ich nicht glaube, dass du nur gekommen bist, um Yogaübungen zu machen, oder?"

    # say L3635 ang
    old "Look, I know, but seriously my body is going crazy, you don’t understand."
    new "Schau, ich weiß, aber ehrlich, mein Körper dreht total durch, du verstehst das nicht."

    # say L3636 ang
    old "Being pregnant turns me into a teenager full of hormones."
    new "Die Schwangerschaft macht mich zu einem hormongesteuerten Teenager."

    # say L3637 ang
    old "And after weeks of sexual frustration, seeing you again reactivated so many things in me that I’d only felt during therapy with Dr. Johnson."
    new "Und nach Wochen der sexuellen Frustration hat mich dein Anblick wieder so viele Gefühle geweckt, die ich nur während der Therapie mit Dr. Johnson gespürt habe."

    # say L3639 ang
    old "Honestly, if it weren’t so necessary for me right now, I wouldn’t bother you."
    new "Ehrlich, wenn es jetzt nicht so notwendig wäre, würde ich dich nicht damit belasten."

    # say L3640 pla
    old "{b}*Sigh*{/b}, Okay, let’s do it if it makes you feel better."
    new "{b}*Seufz*{/b}, Okay, machen wir es, wenn es dir besser geht."

    # say L3641 ang
    old "I appreciate it [pla], I’ll make sure you enjoy it."
    new "Ich schätze es [pla], ich werde sicherstellen, dass du es genießt."

    # say L3650 ang
    old "Oh, yes, I’ve been fantasizing about this since last time..."
    new "Oh, ja, ich habe seit dem letzten Mal davon geträumt..."

    # say L3651 ang
    old "Mmm, it feels so good, I could never get tired of it."
    new "Mmm, das fühlt sich so gut an, ich könnte mich daran nie sattmachen."

    # say L3662 ang
    old "Wow, that was amazing, [pla]!"
    new "Wow, das war unglaublich, [pla]!"

    # say L3663 pla
    old "I’m really happy you’re feeling better."
    new "Ich freue mich echt, dass es dir besser geht."

    # say L3664 pla
    old "And hey, if you ever want a real YOGA session, just let me know."
    new "Und hey, wenn du mal eine echte YOGA-Session willst, lass es mich wissen."

    # say L3665 ang
    old "Thanks, [pla]. I’ll definitely keep that in mind."
    new "Danke, [pla]. Ich werde dran denken."

    # say L3666 ang
    old "This has been wonderful, but it’s getting late. I should head home."
    new "Das war wunderbar, aber es wird langsam spät. Ich sollte nach Hause gehen."

    # say L3667 ang
    old "Really, thank you so much for all your GREAT help today, it means a lot."
    new "Wirklich, danke dir so viel für deine großartige Hilfe heute, das bedeutet mir sehr viel."

    # say L3668 pla
    old "You’re welcome. Now let's go down to talk with Lisa."
    new "Gern geschehen. Lass uns jetzt zu Lisa runtergehen."

    # say L3683 lis
    old "Oh, Are you guys done?"
    new "Oh, seid ihr fertig?"

    # say L3684 lis
    old "How do you feel after our yoga session?"
    new "Wie fühlt ihr euch nach unserer Yogastunde?"

    # say L3685 ang
    old "It was amazing, Lisa, thank you!"
    new "Es war unglaublich, Lisa, danke!"

    # say L3686 lis
    old "I can sense a calm clarity in your energy now, Angelina."
    new "Ich spüre eine ruhige Klarheit in deiner Energie jetzt, Angelina."

    # say L3687 lis
    old "Your inner balance has really deepened."
    new "Dein inneres Gleichgewicht hat sich wirklich vertieft."

    # say L3688 lis
    old "And [pla], you did an excellent job guiding her through the flow."
    new "Und [pla], du hast sie wirklich gut durch den Fluss geführt."

    # say L3689 ang
    old "He was so attentive and supportive."
    new "Er war so aufmerksam und unterstützend."

    # say L3690 lis
    old "Absolutely, you two make a great team."
    new "Absolut, ihr seid ein großartiges Team."

    # say L3691 lis
    old "Angelina, I hope you'll continue with these sessions. [pla] and I are always here for you."
    new "Angelina, ich hoffe, du machst mit den Sitzungen weiter. [pla] und ich sind immer für dich da."

    # say L3692 ang
    old "I definitely will, even after the baby arrives, I’ll keep practicing."
    new "Ich werde definitiv weitermachen, auch nachdem das Baby da ist, werde ich weiter üben."

    # say L3693 lis
    old "That’s wonderful to hear."
    new "Das freut mich zu hören."

    # say L3694 ang
    old "Thank you both for your guidance."
    new "Danke euch beiden für eure Anleitung."

    # say L3695 ang
    old "I’ll head back now, but I’m looking forward to our next class."
    new "Ich gehe jetzt zurück, aber ich freue mich auf unseren nächsten Kurs."

    # say L3696 lis
    old "We’ll be ready, see you soon!"
    new "Wir sind bereit, bis bald!"

    # say L3697 pla
    old "Take care, Angelina."
    new "Pass auf dich auf, Angelina."

    # say L3708 lis
    old "As always, you did an amazing job, [pla]."
    new "Wie immer hast du eine fantastische Arbeit geleistet, [pla]."

    # say L3709 lis
    old "I can see it in the vibrant energy you both radiate afterward."
    new "Ich sehe es an der lebendigen Energie, die ihr beide danach ausstrahlt."

    # say L3710 pla
    old "Uh, thanks, yeah, I really put my effort into it."
    new "Danke, ja, ich hab echt mein Bestes gegeben."

    # say L3711 lis
    old "I love your dedication and your calling to help others. You remind me of myself when I was younger."
    new "Ich liebe deine Hingabe und deinen Berufsweg, anderen zu helfen. Du erinnerst mich an mich selbst, als ich jünger war."

    # say L3712 lis
    old "Anyway, it’s quite late. You should get some rest."
    new "Jedenfalls, es ist ziemlich spät. Du solltest dich ausruhen."

    # say L3713 pla
    old "You’re right. Goodbye, and rest well."
    new "Du hast recht. Gute Nacht und schlaf gut."

    # say L3714 lis
    old "Same to you, [pla]. Take care, and we’ll see each other soon."
    new "Gleichfalls, [pla]. Pass auf dich auf, und wir sehen uns bald."

    # say L3733 pla
    old "Hey Lisa, how have you been?"
    new "Hey Lisa, wie geht's dir?"

    # say L3734 lis
    old "Hi [pla], great to see you! Are you here for another yoga session with me?"
    new "Hi [pla], toll dich zu sehen! Bist du hier, um noch eine Yogastunde mit mir zu machen?"

    # say L3735 pla
    old "Uh, maybe another day..."
    new "Vielleicht ein anderes Mal..."

    # say L3736 pla
    old "Actually, I was wondering, why haven’t we had any new sessions with Anastasia or Angelina lately?"
    new "Eigentlich, ich hab mich gefragt, warum wir keine neuen Sitzungen mit Anastasia oder Angelina hatten."

    # say L3737 lis
    old "Oh, well, Anastasia actually went out of town for a bit, but I’ve stayed in touch with her. She’s planning to return soon."
    new "Oh, na ja, Anastasia ist actually für ein paar Tage aus der Stadt, aber ich bleibe in Kontakt mit ihr. Sie plant bald zurückzukehren."

    # say L3738 pla
    old "Oh, nice. I hope she’s enjoying her trip. Did she mention when she’ll be back?"
    new "Oh, schön. Ich hoffe, sie genießt ihre Reise. Hat sie gesagt, wann sie zurückkommt?"

    # say L3739 lis
    old "She said in a few weeks."
    new "Sie sagte, in ein paar Wochen."

    # say L3740 pla
    old "Oh, alright. And Angelina?"
    new "Oh, okay. Und Angelina?"

    # say L3741 lis
    old "Oh, you didn’t hear? The doctor told Angelina to take it easy, no workouts or anything, so we’re giving her a break from the sessions."
    new "Oh, hast du das nicht gehört? Der Arzt hat Angelina gesagt, sie soll es sich ruhig angehen lassen, keine Workouts oder so, deshalb machen wir eine Pause mit den Sitzungen."

    # say L3742 pla
    old "Oh really? Well, makes sense. Health first."
    new "Oh wirklich? Na klar, Gesundheit geht vor."

    # say L3743 lis
    old "Absolutely. She was disappointed, she loved the sesions, but she needs to focus on her well-being."
    new "Absolut. Sie war enttäuscht, sie liebte die Sitzungen, aber sie muss sich auf ihre Gesundheit konzentrieren."

    # say L3744 lis
    old "I’m sorry I didn’t let you know earlier, you’re a blessing for always caring about others."
    new "Es tut mir leid, dass ich dir das nicht früher gesagt habe, du bist immer so rücksichtsvoll und denkst an andere."

    # say L3745 pla
    old "Oh, no, it’s nothing. I was just wondering, since we’ve had some busy days with Angelina and Anastasia’s sessions lately."
    new "Oh, nein, ist schon gut. Ich hab mich nur gewundert, weil wir die letzten Tage mit Angelina und Anastasias Sitzungen ziemlich ausgelastet waren."

    # say L3746 lis
    old "Don't worry, once Angelina and Anastasia resume, we’ll pick up right where we left off."
    new "Mach dir keine Sorgen, sobald Angelina und Anastasia wieder da sind, fangen wir genau da an, wo wir aufgehört haben."

    # say L3747 lis
    old "And who knows, we might even add a group workshop."
    new "Und wer weiß, wir könnten sogar ein Gruppenseminar hinzufügen."

    # say L3748 pla
    old "A group workshop? Uhh, o- ok, yeah sure..."
    new "Eine Gruppenworkshop? Uhh, o- ok, ja klar..."

    # say L3749 lis
    old "It’s so thrilling, right? I can’t wait to see what else the universe has in store."
    new "Das ist so aufregend, oder? Ich kann es kaum erwarten, zu sehen, was das Universum noch alles für uns bereithält."

    # say L3750 lis
    old "Everything is happening so fast, it’s so exhilarating..."
    new "Alles passiert so schnell, es ist so aufregend..."

    # say L3751 pla
    old "Heh, I’m glad you’re so excited."
    new "Heh, ich freue mich, dass du so aufgeregt bist."

    # say L3752 pla
    old "Well, I’ll be on standby for whenever you need me."
    new "Na klar, ich stehe dir jederzeit zur Verfügung."

    # say L3753 lis
    old "Yes, don’t worry, you’ll be back here helping me soon. There are even new clients I’d like you to meet."
    new "Ja, mach dir keine Sorgen, du wirst bald wieder hier sein und mir helfen. Es gibt sogar neue Kunden, die ich dir vorstellen möchte."

    # say L3754 lis
    old "For now, rest and keep working on your exercises and inner energy."
    new "Für den Moment ruh dich aus und arbeite an deinen Übungen und deiner inneren Energie."

    # say L3755 pla
    old "Sure, I’ll keep that in mind."
    new "Klar, ich behalte das im Hinterkopf."

    # say L3756 lis
    old "Excellent, have a great day [pla], we’ll see each other soon."
    new "Prima, hab einen schönen Tag [pla], wir sehen uns bald."

    # say L3757 pla
    old "Goodbye Lisa, see you soon."
    new "Tschüss Lisa, bis bald."

    # say L3781 pla
    old "Hello Lisa, how are you?"
    new "Hallo Lisa, wie geht es dir?"

    # say L3782 lis
    old "Good, the energies have come to me, how about you."
    new "Gut, die Energien sind zu mir gekommen, und bei dir?"

    # say L3783 pla
    old "Pretty nice, I am glad to see everything is going well."
    new "Schön, ich freue mich, dass alles gut läuft."

    # say L3784 lis
    old "I can't complain, the business is running just fine."
    new "Ich kann mich nicht beklagen, das Geschäft läuft prima."

    # say L3785 pla
    old "Hmm... I'm happy for you."
    new "Hmm... Ich freue mich für dich."

    # say L3786 lis
    old "Remember that you are free to come over any time you want for a few free yoga lessons."
    new "Erinnerst du dich, dass du jederzeit vorbeikommen kannst, um ein paar kostenlose Yogastunden zu nehmen?"

    # say L3787 pla
    old "Sure, I think, I'll make an appointment soon."
    new "Klar, ich denke, ich werde bald einen Termin machen."

    # say L3788 lis
    old "That sounds good, you have such energy and potential."
    new "Das klingt gut, du hast so viel Energie und Potenzial."

    # say L3789 pla
    old "Thank you. Anyway, I will let you keep working, it was nice to see you."
    new "Danke. Jedenfalls lass ich dich weiterarbeiten, war schön, dich zu sehen."

    # say L3790 lis
    old "It was nice to you too, have a wonderful day."
    new "Es war auch schön, dich zu sehen. Hab einen wunderschönen Tag."

    # say L3826 pla
    old "No, no, sorry I was just walking around. See you later..."
    new "Nein, nein, tut mir leid, ich war nur rumlaufen. Bis später..."

    # say L3841 lis
    old "Hey, good morning, nice to see you so early."
    new "Hey, guten Morgen, schön dich so früh zu sehen."

    # say L3842 pla
    old "Hehehe,It's nice to see you too."
    new "Hehehe, schön dich auch zu sehen."

    # say L3843 lis
    old "I am always ready very early to make the sungreeting, it's one of my favorites, you can't imagine how grateful I feel with the universe."
    new "Ich bin immer sehr früh bereit, um die Morgengruß zu machen, das ist einer meiner Lieblingsmomente, du kannst dir nicht vorstellen, wie dankbar ich dem Universum dafür bin."

    # say L3844 pla
    old "Sounds very interesting."
    new "Klingt sehr interessant."

    # say L3846 lis
    old "By the way, why are you so early here? Do you want to practice?"
    new "Ach so, warum bist du denn so früh hier? Willst du üben?"

    # say L3850 pla
    old "Oh no, I can't at this moment."
    new "Oh nein, ich kann im Moment nicht."

    # say L3851 lis
    old "It's ok, remember you need to keep on training so you can take the most out of you and your energy."
    new "Okay, aber denk dran, du musst weiter trainieren, um das Beste aus dir und deiner Energie herauszuholen."

    # say L3852 pla
    old "You are right."
    new "Du hast recht."

    # say L3853 lis
    old "Don't forget you are welcome to train whenever you need."
    new "Vergiss nicht, dass du jederzeit trainieren kannst, wenn du es brauchst."

    # say L3854 pla
    old "I appreciate your kindness."
    new "Ich schätze deine Freundlichkeit."

    # say L3855 lis
    old "It's always good to have you here, come back anytime you want."
    new "Es ist immer schön, dich hier zu haben, komm jederzeit wieder, wenn du willst."

    # say L3856 pla
    old "I'll do, bye bye."
    new "Ich mach das, tschüss."

    # say L3857 lis
    old "bye!"
    new "Bis dann!"

    # say L3860 pla
    old "Yes, I think I need to work on that, so I came to check if you are not busy."
    new "Ja, ich denke, ich muss daran arbeiten, deshalb bin ich gekommen, um zu sehen, ob du nicht beschäftigt bist."

    # say L3861 lis
    old "Oh no, I was about to start my training too so we can do it together."
    new "Oh nein, ich wollte gerade mit meinem Training anfangen, dann können wir es zusammen machen."

    # say L3863 lis
    old "Let's go to the training room to be more comfortable."
    new "Lass uns in den Trainingsraum gehen, um es uns gemütlicher zu machen."

    # say L3866 lis
    old "What exercise would you like to train with?"
    new "Welche Übung möchtest du trainieren?"

    # say L3870 lis
    old "Excellent choice, let's start to make the most out of this morning."
    new "Exzellente Wahl, lass uns das Beste aus diesem Morgen machen."

    # say L3871 pla
    old "Wonderful, I am full of energy today."
    new "Wunderbar, ich bin heute voller Energie."

    # say L3893 lis
    old "That was wonderful, please keep that enthusiasm, Yoga is better with such a great attitude like yours."
    new "Das war wunderbar, bitte behalte diese Begeisterung, Yoga ist mit so einer großartigen Einstellung wie deiner viel besser."

    # say L3894 pla
    old "Yes, I'm in a very good mood, every position helped me today to feel a lot better."
    new "Ja, ich bin in einer sehr guten Stimmung, jede Position hat mir heute geholfen, mich viel besser zu fühlen."

    # say L3895 lis
    old "We can continue training anytime you need..."
    new "Wir können jederzeit weitertrainieren, wenn du es brauchst."

    # say L3896 pla
    old "Sure, I will be coming more often to improve!"
    new "Klar, ich werde öfter kommen, um mich zu verbessern!"

    # say L3897 lis
    old "I love to hear that."
    new "Das freut mich zu hören."

    # say L3903 pla
    old "Thank you, it was a very incredible time today."
    new "Danke, es war ein unglaublicher Tag heute."

    # say L3904 lis
    old "You did a fantastic job, keep working hard."
    new "Du hast fantastische Arbeit geleistet, bleib dran."

    # say L3905 pla
    old "I will!"
    new "Ich werd's tun!"

    # say L3906 lis
    old "Remember the lessons with Anastasia at the afternoon and also the tantric sessions at night, you have a lot of work to do."
    new "Denk dran, die Stunden mit Anastasia am Nachmittag und auch die tantrischen Sitzungen am Abend, du hast noch viel zu tun."

    # say L3907 pla
    old "Yes, I will be on time."
    new "Ja, ich werde pünktlich sein."

    # say L3908 lis
    old "It was nice to see you."
    new "Schön, dich zu sehen."

    # say L3909 pla
    old "It was nice to see you too, see you later."
    new "Schön, dich auch gesehen zu haben, bis später."

    # say L3910 lis
    old "Perfect, keep your energies for this afternoon."
    new "Perfekt, spar dir die Energie für heute Nachmittag."

    # say L3911 pla
    old "I sure will."
    new "Klar, mach ich."

    # say L3925 lis
    old "Hello [pla], how are you?"
    new "Hallo [pla], wie geht's dir?"

    # say L3926 pla
    old "Hi, Pretty good, how about you?"
    new "Hi, Pretty good, wie geht's dir?"

    # say L3927 lis
    old "I'm great... So? Are you ready to have another tantric session?"
    new "Ich bin super... Also? Bist du bereit für eine weitere tantrische Sitzung?"

    # say L3931 pla
    old "Oh no, thank you."
    new "Oh nein, danke."

    # say L3932 lis
    old "It's ok, remember you need to keep training so you can make the most out of you and your energy."
    new "Okay, denk dran, du musst weiter trainieren, damit du das Beste aus dir und deiner Energie herausholen kannst."

    # say L3937 pla
    old "I will, bye bye."
    new "Ich werd's tun, tschüss."

    # say L3940 lis
    old "It's really important for you to continue these trainings so you can control your chakras better, you know this is a complete process you can't stop."
    new "Es ist wirklich wichtig, dass du diese Trainings fortsetzt, damit du deine Chakras besser kontrollieren kannst. Du weißt, dass das ein vollständiger Prozess ist, den du nicht abbrechen darfst."

    # say L3941 pla
    old "Yes, you are right."
    new "Ja, du hast recht."

    # say L3942 lis
    old "Let's go to the room so we can start."
    new "Lass uns in den Raum gehen, damit wir anfangen können."

    # say L3944 lis
    old "What session did you like the most? Whichever it is we can repeat it."
    new "Welche Sitzung hat dir am besten gefallen? Egal welche es ist, wir können sie wiederholen."

    # menu L3947 
    old "Session 1"
    new "Sitzung 1"

    # say L3948 lis
    old "Good option, let's start to make the most out of this tantric session tonight."
    new "Gute Wahl, lass uns das Beste aus dieser tantrischen Sitzung heute Nacht machen."

    # say L3949 pla
    old "Perfect, I am very relaxed and ready to start the massage..."
    new "Perfekt, ich bin total entspannt und bereit, die Massage zu beginnen..."

    # menu L3953 
    old "Session 2"
    new "Sitzung 2"

    # say L3975 lis
    old "It has been a really good time, I can see your improvement with every single session, your energy has totally changed."
    new "Es war wirklich eine tolle Zeit, ich sehe deine Verbesserung bei jeder einzelnen Sitzung, deine Energie hat sich total verändert."

    # say L3976 pla
    old "I appreciate all that you say."
    new "Ich schätze alles, was du sagst."

    # say L3977 lis
    old "It's really amazing to see the progress you have achieved."
    new "Es ist wirklich beeindruckend, den Fortschritt zu sehen, den du gemacht hast."

    # say L3978 pla
    old "Any progress is thanks to you."
    new "Jeder Fortschritt verdankt sich dir."

    # say L3979 lis
    old "We need to keep training to be better every time."
    new "Wir müssen weiter trainieren, um jedes Mal besser zu werden."

    # say L3985 lis
    old "I'm grateful with the universe for this wonderful opportunity, I hope we can meet more often, so you can improve the control over your chakras."
    new "Ich bin dem Universum dankbar für diese wunderbare Gelegenheit, ich hoffe, wir können öfter zusammenkommen, damit du die Kontrolle über deine Chakras verbessern kannst."

    # say L3986 pla
    old "Sure, I will come more often."
    new "Klar, ich werde öfter kommen."

    # say L3987 lis
    old "It was nice to see, have a good one."
    new "Schön, dich gesehen zu haben, mach’s gut."

    # say L3988 pla
    old "Same or you, bye!"
    new "Gleichfalls, tschüss!"

    # say L4002 lis
    old "Hi Anastasia, how is everything going?"
    new "Hi Anastasia, wie läuft alles?"

    # say L4003 ana
    old "Very good, been waiting all day for my training session."
    new "Sehr gut, habe den ganzen Tag auf meine Trainingsstunde gewartet."

    # say L4004 lis
    old "That is perfect! [pla] must be about to-"
    new "Das ist perfekt! [pla] muss gleich hier sein-"

    # say L4012 pla
    old "Good afternoon guys."
    new "Guten Nachmittag, Mädels."

    # say L4015 lis
    old "Hello [pla], how are you doing?"
    new "Hallo [pla], wie geht es dir?"

    # say L4016 pla
    old "Pretty Fine! Hi Anastasia."
    new "Alles gut! Hallo Anastasia."

    # say L4017 ana
    old "Hi, I was waiting for you, glad to see you got here fine, I came ready to have a good session today."
    new "Hi, ich habe auf dich gewartet, freut mich, dass du gut hier angekommen bist, ich bin bereit für eine gute Session heute."

    # say L4018 pla
    old "Oh perfect!"
    new "Oh perfekt!"

    # say L4019 lis
    old "Well guys, I will leave alone so you can work hard, in case you need me, I will be here."
    new "Na dann, ich lass euch allein, damit ihr euch konzentrieren könnt. Falls ihr mich braucht, ich bin hier."

    # say L4020 pla
    old "I appreciate that..."
    new "Ich schätze das..."

    # say L4021 ana
    old "Let's go to the room, I need to train NOW..."
    new "Lass uns ins Zimmer gehen, ich muss jetzt trainieren..."

    # say L4028 ana
    old "What exercise are we going to do today?"
    new "Welche Übung machen wir heute?"

    # say L4029 pla
    old "Well, let me tell you..."
    new "Na, lass mich dir sagen..."

    # menu L4032 
    old "Exercise 1"
    new "Übung 1"

    # say L4033 ana
    old "That's a great choice, I will do my best to ensure that you learn as much we can."
    new "Das ist eine tolle Wahl, ich werde mein Bestes tun, um sicherzustellen, dass du so viel wie möglich lernst."

    # say L4034 pla
    old "Sounds really good."
    new "Klingt echt gut."

    # menu L4038 
    old "Exercise 2"
    new "Übung 2"

    # menu L4044 
    old "Exercise 3"
    new "Übung 3"

    # menu L4050 
    old "Exercise 4"
    new "Übung 4"

    # say L4062 ana
    old "It was delicious, I really love these sessions."
    new "Es war köstlich, ich liebe diese Sitzungen wirklich."

    # say L4063 pla
    old "I am glad that you are satisfied, I am training hard so I can help you better."
    new "Ich bin froh, dass du zufrieden bist, ich trainiere hart, um dir besser helfen zu können."

    # say L4064 ana
    old "Please, don't stop training, your job is quite interesting."
    new "Bitte, hör nicht auf zu trainieren, dein Job ist ziemlich interessant."

    # say L4065 pla
    old "Ok, I will continue working hard."
    new "Okay, ich werde weiter hart arbeiten."

    # say L4066 ana
    old "Perfect, because you are scheduled for me from now on."
    new "Perfekt, weil du ab jetzt für mich eingeplant bist."

    # say L4067 pla
    old "Ok, I hope to see you next session."
    new "Ok, ich freue mich auf unser nächstes Treffen."

    # say L4068 ana
    old "I'll be here ready for a new adventure."
    new "Ich werde hier sein und bereit für ein neues Abenteuer."

    # say L4069 pla
    old "I'll be ready!"
    new "Ich werde bereit sein!"


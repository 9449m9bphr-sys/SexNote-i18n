# SexNote german — Qwen2.5-72B AWQ context ±2 + logic review
# Do not edit English sources
# Format: translate german strings: (old/new)
# Font: DejaVuSans.ttf

translate german strings:

    old "History"
    new "Verlauf"

    old "Save"
    new "Speichern"

    old "Q.Save"
    new "S.Speichern"

    old "Q.Load"
    new "S.Laden"

    old "Prefs"
    new "Optionen"

    old "Load"
    new "Laden"

    old "Preferences"
    new "Einstellungen"

    old "Gallery"
    new "Galerie"

    old "End Replay"
    new "Replay beenden"

    old "Main Menu"
    new "Hauptmenü"

    old "About"
    new "Über"

    old "Help"
    new "Hilfe"

    old "Quit"
    new "Beenden"

    old "Return"
    new "Zurück"

    old "Visit our Patreon {color=#ff8b00}{a=https://www.patreon.com/sexnote}{b}SexNote{/b}{/a}{/color} and {color=#ff8b00}{a=https://www.patreon.com/lustlegacy}{b}Lust Legacy{/b}{/a}{/color}. "
    new "Besuche unseren Patreon {color=#ff8b00}{a=https://www.patreon.com/sexnote}{b}SexNote{/b}{/a}{/color} und {color=#ff8b00}{a=https://www.patreon.com/lustlegacy}{b}Lust Legacy{/b}{/a}{/color}."

    old "{size=+10}{color=#a6ecff}{b}THANKS TO OURS PATRONS!:{/b}{/color}{/size}"
    new "{size=+10}{color=#a6ecff}{b}DANK UNSEREN SPENDERN!:{/b}{/color}{/size}"

    old "{color=#16a5cc}{b}Dark Wizards:{/b}{/color} - Oerni -, 3ddi3k, aneondarkey, Anthony Fantini, Benjamin Lane, Bernier Jerome, Call Me Unseen, controller__, cronkdrong, DarkDrago, Dawn Jennifer McCool, Dean Miller, Declan Kyle Regan, Dennis Langston Jr., Donkykang, DRAGNEEL, Dusty, Dániel Seres, Elliott Goers, Emory, Forezra, Fused Dstyles, g420, god is dead, Haakon Thorsheim, HiddenJackalope, ies, james mcveigh, James Register, Jamie Allen, Jeremiah Koahou, JJ, Jonathon Viser, Joseph, Laura García Garcés, Lazy_domo, Louis Siu, Marco, meatntea, Mikael Linderoth, Muhtesem Valdo, NeoBoy, Noé Guinebert, Peter Sileo, phantom demon, PMK1N, ramsey, RebelCj, Reiley Simmons, Rezel, Rictor86, Robert Narron, roguez, sam, Scooty Popsr4, Sean Walsh, Shadow_Wolf, sichen zou, Spanksr, Staple, Stephen Carlo, Jr, thacrow456, TorumSie, Tuấn Trần, X_Konsti_X, Yatzee, Zodiac, 부 두."
    new "{color=#16a5cc}{b}Hexenmeister:{/b}{/color} - Oerni -, 3ddi3k, aneondarkey, Anthony Fantini, Benjamin Lane, Bernier Jerome, Call Me Unseen, controller__, cronkdrong, DarkDrago, Dawn Jennifer McCool, Dean Miller, Declan Kyle Regan, Dennis Langston Jr., Donkykang, DRAGNEEL, Dusty, Dániel Seres, Elliott Goers, Emory, Forezra, Fused Dstyles, g420, Gott ist tot, Haakon Thorsheim, HiddenJackalope, ies, James McVeigh, James Register, Jamie Allen, Jeremiah Koahou, JJ, Jonathon Viser, Joseph, Laura García Garcés, Lazy_domo, Louis Siu, Marco, meatntea, Mikael Linderoth, Muhtesem Valdo, NeoBoy, Noé Guinebert, Peter Sileo, Phantomdä"

    old "{color=#16a5cc}{b}Wizards:{/b}{/color}#, A AA, A Guy named Stefan, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew steffen, andrew tozer, anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson, Dino Torres, Dj Happg, DJNipTwist, Doc Pan As, Doc854, Doctor Giraffe, dragon hunter, Draven x, El Rando Salvo, Elias, Elias Ritter, Emmanuel Abel, Eric, Ethan, Ethan Blessemaille, Fjallar Otterson, Franklin Snyder, Fredrik, Gaming Account, Gareth Whitlow, Geoff, Gin, Grimm, Halic1108, Harry Hunsberger, Harvey Mountford, Herb665, ingerbr, iron Kill, Isaiah Coleman, Isaiah Pacheco, Iseedeadllamas, Ivan Flores, Jack Fair, jackson lynch, James, jayden weatherford, Jesus Fregozo, Jetendra Lalchan, Joe Gehling, Joel Harper, John Fugate, John T, Johnathan Balfour, Jordan L, Jorgito Breton, Joseph P Hawley, Joseph Righter, Josh Dischinger, junangulas, Justin, Justin Smith, Justin Spahn, JustThatGuy, KaiserRob, kazuo kenshin, ken smith, Kieran Coles, lmninja64, Logan Cooper, Lord Eagle, Lucas Hogh-Janovsky, MajehEX, Marco Scherer, matt congrove, Matt Richardson, Matthew Ober, Maxx, Mickel Rateliff, MLordBoss97, mole man, Mungan, Nathan Cochran, NerdyCaveman, Nick Moore, Nobody, NU, OffbeatLemon137, Omar, Omnibreed001, ouweseun, Patricio Pulgar, Patrick Bertin, Patrick Tanner, philip carter, Pierson trueblood, PutasBoy, Quinton Woods, R4ttenf4enger, Rail Meiko, Ray Smith, Rey Mitchell, Richard Roche, Rick Stout, Rob Banks, Rob Willard, Robert Duplessis, Roul Druck, Rust, RwEd ForTheWin, Saggy Sauce, Samic, ScarlettAurora, Shane Antonacci, SpookyMan, ssbn571 ., Stoven, Tena Fich, Thana.N.Ye, TheLoneKek, Thereader, Titan91, Toot Poot, Tummetott, Tyren Gray, UUVG, Victor Saganoff, Wezz, William, Willim Ortega, Yang Eric, zac, Zlaire Asberry, عبدالعزيز وارد, ・ひで・, 恭郡 何, 김종근 김, "
    new "{color=#16a5cc}{b}Zauberer:{/b}{/color}#, A AA, Ein Typ namens Stefan, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew Steffen, Andrew Tozer, Anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson"

    old "{color=#16a5cc}{b}Conjurers:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallardt, Jim Max, John Tyler, Keith Alexander, Kevin, Kuba Kluszczynski, Lauritsbb, Lhurlu, loiq fortin, Lurtz111, Manna Moth, marc witten, mark rodriguez, Matisse Vobaure, Matthew Myers, Max, michael finch, miloarty, Murphy Wakefield, Nathaniel Brooks, Nova, Oz, Paris, Petzy33, Pimmel Warze, PrDauny21, Ramz, Raptor2283, Ronnie S, , SAITAMA CAPA, Scott Liebenow, Sebastian Lopez, SetforDark, Shadow Blackheart, SkullKidDanzen, Sou11ess19, sumu black, Tapelesslion Gaming, Tobias, Tom Schubert, torsten kristensen, Tyler M., uchihazelda, ViolentBone, Whyze, William Walker, บิ มา กายโรสแมรี่."
    new "{color=#16a5cc}{b}Beschwörer:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallardt, Jim Max, John Tyler, Keith Alexander, Kevin, Kuba Kluszczynski, Lauritsbb, Lhurlu, loiq fortin, Lurtz111, Manna Moth, marc witten, mark rodriguez, Matisse Vobaure, Matthew Myers, Max, michael finch, miloarty, Murphy Wakefield, Nathaniel Brooks, Nova, Oz, Paris, Petzy33, Pimmel Warze, PrDa"

    old "Page {}"
    new "Seite {}"

    old "Automatic saves"
    new "Automatische Speicherungen"

    old "Quick saves"
    new "Schnellspeicher"

    old "empty slot"
    new "leerer Slot"

    old "Display"
    new "Anzeigen"

    old "Window"
    new "Fenster"

    old "Fullscreen"
    new "Vollbild"

    old "Rollback Side"
    new "Seite zurückspielen"

    old "Disable"
    new "Deaktivieren"

    old "Left"
    new "Links"

    old "Right"
    new "Rechts"

    old "Unseen Text"
    new "Unsichtbarer Text"

    old "After Choices"
    new "Nach den Entscheidungen"

    old "Transitions"
    new "Übergänge"

    old "Language"
    new "Sprache"

    old "English"
    new "Englisch"

    old "Text Speed"
    new "Textgeschwindigkeit"

    old "Auto-Forward Time"
    new "Auto-Forward-Zeit"

    old "Music Volume"
    new "Musiklautstärke"

    old "Sound Volume"
    new "Effektlautstärke"

    old "Voice Volume"
    new "Stimmlautstärke"

    old "Mute All"
    new "Alles stummschalten"

    old "The dialogue history is empty."
    new "Das Dialogverlauf ist leer."

    old "Keyboard"
    new "Tastatur"

    old "Mouse"
    new "Maus"

    old "Enter"
    new "Eingeben"

    old "Advances dialogue and activates the interface."
    new "Bewegt das Dialogfenster und aktiviert die Schnittstelle."

    old "Space"
    new "Leertaste"

    old "Advances dialogue without selecting choices."
    new "Dialog fortsetzen"

    old "Arrow Keys"
    new "Pfeiltasten"

    old "Navigate the interface."
    new "Spiel navigieren"

    old "Escape"
    new "Entweichen"

    old "Accesses the game menu."
    new "Spielmenü aufrufen"

    old "Skips dialogue while held down."
    new "Wird das Dialog überspringen, solange gedrückt."

    old "Toggles dialogue skipping."
    new "Dialog überspringen umschalten"

    old "Page Up"
    new "Seite hoch"

    old "Rolls back to earlier dialogue."
    new "Zurück zu früheren Dialogen"

    old "Page Down"
    new "Seite runter"

    old "Rolls forward to later dialogue."
    new "Zur späteren Dialogrolle vorwärts springen"

    old "Hides the user interface."
    new "Benutzeroberfläche ausblenden"

    old "Takes a screenshot."
    new "Screenshot machen"

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Assistive {a=https://www.renpy.org/l/voicing}Selbstansage{/a} umschalten"

    old "Left Click"
    new "Linksklick"

    old "Middle Click"
    new "Mittlerer Klick"

    old "Right Click"
    new "Rechtsklick"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "Mausrad hoch"

    old "Mouse Wheel Down"
    new "Mausrad nach unten"

    old "Right Trigger\nA/Bottom Button"
    new "Rechte Abzugsstufe"

    old "Left Trigger\nLeft Shoulder"
    new "Left Trigger"

    old "Right Shoulder"
    new "Rechte Schulter"

    old "D-Pad, Sticks"
    new "D-Pad, Joysticks"

    old "Y/Top Button"
    new "Y/Oben"

    old "Calibrate"
    new "Kalibrieren"

    old "Skipping"
    new "Überspringen"

    old "Menu"
    new "Menü"

    old "Developer"
    new "Entwickler"


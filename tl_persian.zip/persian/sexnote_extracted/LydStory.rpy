# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/LydStory.rpy
translate persian strings:

    # say L11 ann
    old "I mean mom, online dating?!! What the fuck?!!!"
    new "منظورت اینه مامان، دیتینگ آنلاین؟!!! چه خبره؟!!!"

    # say L12 ann
    old "You couldn't think about anything else?"
    new "نمی‌تونستی به چیز دیگه‌ای فکر کنی؟"

    # say L13 ann
    old "Why don't you just join a knitting group? Or play bingo like any other widow?"
    new "چرا نمی‌تونی به یه گروه خیاطی بپیوندی؟ یا مثل سایر بیوه‌ها باینگو بازی کنی؟"

    # say L14 lyd
    old "What's so bad about what I said?"
    new "من فکر می‌کنم هیچ چیز اشتباهی در آن نبود."

    # say L15 lyd
    old "I don't think there's anything wrong with a single woman thinking about meeting new people."
    new "من فکر نمی‌کنم هیچ چیز اشتباهی در مورد یک زن تنها که به دنبال آشنایی با افراد جدید باشد، باشه."

    # say L16 lyd
    old "Now that your father's not here I'd like to make some new friends, and..."
    new "الان که پدرت نیست می‌خوام دوستان جدیدی بکنم، و..."

    # say L17 ann
    old "Do you think you're at the age where you should be meeting people through a dating app?"
    new "فکر می‌کنی تو این سن باید از طریق اپلیکیشن‌های آشنا شدن با مردم جدید آشنا شی؟"

    # say L18 ann
    old "Besides, who the hell is going to talk to you? To a widowed grandmother?"
    new "البته، چه کسی خواهد آمد و با تو صحبت کند؟ با یک باباگی که از همسرش برده است؟"

    # say L19 ann
    old "If you want to meet new people why don't you just go to an elderly home?"
    new "اگر می‌خوای افراد جدیدی بشناسی چرا نمی‌روی به یک خانه مسنا؟"

    # say L20 ann
    old "Maybe there you'll find some people your age."
    new "شاید اونجا نفراتی مثل تو پیدا کنی."

    # say L21 lyd
    old "It's that way to talk to your mother?"
    new "این جوری با مادرت صحبت می‌کنی؟"

    # say L22 lyd
    old "Are you listening to yourself?"
    new "آیا به خودت گوش می‌کنی؟"

    # say L23 ann
    old "I don't care!"
    new "من نمی‌خواهم!"

    # say L24 ann
    old "You should be the one thinking about what you're saying! Dad's not even been dead for a year!"
    new "تو باید به چیزی که می‌گی‌ی فکر کنی! پدر حتی یک سال هم مرده نیست!"

    # say L25 ann
    old "And here you are thinking about picking guys up like you're some... Ugh!"
    new "و اینجایی فکر می‌کنی درباره چطور مردان رو جذب کنی مثل یه... اوه!"

    # say L26 ann
    old "I don't want my mother to go around giving herself up to some randoms on the internet."
    new "من نمی‌خوام مادرم روی اینترنت با آدم‌های تصادفی رابطه داشته باشه."

    # say L27 ann
    old "Listen, you can do what you want, but don't expect me to help you with anything..."
    new "بگو، تو می‌تونی هر چی می‌خوای بکنی، اما نباید بیای از من کمک ببری..."

    # say L28 ann
    old "Ugh! I don't even want to keep talking to you!"
    new "اوه! من حتی نمی‌خوام با تو صحبت کنم!"

    # say L42 pla
    old "Uh, hi..."
    new "اوه، سلام..."

    # say L43 lyd
    old "[pla]! H- hi!"
    new "[pla]! ه- سلام!"

    # say L44 lyd
    old "I hope you didn't see much of what just happened..."
    new "امیدوارم خیلی از آنچه اتفاق افتاده ندیدی..."

    # say L46 pla
    old "Uhhh... Just the last bit of it, I think..."
    new "اوه... فقط آخرش رو دیدم، فکر کنم..."

    # say L47 pla
    old "All I heard was Anna being as annoying as always."
    new "همه چیزی که شنیدم این بود که آنا مثل همیشه سر در می‌آورد."

    # say L48 pla
    old "What's the matter? Why is she acting up now?"
    new "چه کاری داره؟ چرا الان اینجوری می‌کنه؟"

    # say L50 lyd
    old "Well... How can I put it?"
    new "خب... چطور بگم؟"

    # say L51 lyd
    old "Do you remember the other day when you went with me to church?"
    new "آیا به یاد داری روزی که با من به کلیسا رفتی؟"

    # say L52 pla
    old "Hmmm, yeah."
    new "Hmm، بله."

    # say L53 lyd
    old "The thing is, ever since we ran into Mrs. Jones, I've been thinking and..."
    new "الان، از وقتی با خانم مس جونز برخورد کردیم، من فکر می‌کنم و..."

    # say L54 lyd
    old "I don't want to be like that [pla]. Her husband died five years ago, and she's been unable to move on from that."
    new "من نمی‌خوام مثل اون باشم [pla]. شوهرش پنج سال پیش مرده و او هیچ وقت نتونسته از اون جا پیش بری."

    # say L55 pla
    old "She hasn't moved on? What do you mean?"
    new "او پیش نرفته؟ منظورت چیه؟"

    # say L56 lyd
    old "You know, all she ever does is talk about God and faith. Frankly, it's pitying."
    new "می‌دونی، همه وقت فقط در مورد خدا و ایمان حرف می‌زنه. صراحی، اینجوری برام خیلی غم‌انگیزه."

    # say L57 lyd
    old "I decided I don't want that to happen to me too."
    new "من تصمیم گرفتم نمی‌خوام همچین چیزی برایم بیفتد."

    # say L60 lyd
    old "So, I've been trying to get myself out there, I've gone to a couple of bars, and clubs."
    new "پس من سعی کردم خودمو بیرون ببرم، چند بار به بارها و کلاب‌ها رفتم."

    # say L61 lyd
    old "Trying to meet new people, you know?"
    new "سعی می‌کنم افراد جدیدی بشناختم، می‌دونی؟"

    # say L62 lyd
    old "But, it's been to no avail. It turns out people don't really go to bars or clubs to meet new people anymore."
    new "اما، هیچ فایده‌ای نداشت. به نظر می‌رسد مردم خیلی به بارها یا کلاب برای آشنایی با افراد جدید نمی‌روند."

    # say L64 lyd
    old "It's not as common to go out to meet new people. Nowadays, if someone goes out it's because they already have plans with someone else."
    new "بیرون رفتن برای آشنایی با افراد جدید همچون قبلاً رایج نیست. امروزه اگر کسی بیرون می‌رود، معمولاً چون برنامه‌ای با کسی دیگر دارد."

    # say L65 lyd
    old "So, I thought maybe I should do what I heard young people are doing these days, and try online dating."
    new "پس فکر کردم شاید باید مثل آنچه که شنیدم جوان‌ها این روزها می‌کنند، امتحانی برای دیتینگ آنلاین بزنم."

    # say L66 pla
    old "Well, that sounds like a good idea."
    new "خب، این یه ایده خوبه."

    # say L68 lyd
    old "I guess so, but the whole internet thing just flies over my head. It's so complicated."
    new "باید همین‌طور باشه، اما کل موضوع اینترنت برایم خیلی پیچیده است."

    # say L69 lyd
    old "Given that I can't really do it myself I asked Anna to help me out."
    new "چون خودم نمی‌تونم انجام بدم، از آنا پرسیدم کمکم کنه."

    # say L70 lyd
    old "But, you already saw how that turned out."
    new "ولی، قطعاً دیدی چطور پایان یافت."

    # say L71 pla
    old "Hmph, I did..."
    new "همف، من هم دیدم..."

    # say L72 lyd
    old "Although maybe she's right. Maybe I'm just too old to be thinking about doing things like online dating and such."
    new "البته شاید هم درست می‌گه. شاید من فقط خیلی پیر هستم برای فکر کردن به چیزهایی مثل دیتینگ آنلاین و اینا."

    # say L73 lyd
    old "I'm just an old, lonely widow after all... So I'll just give up."
    new "من فقط یک بیوه قدیمی و تنها هستم... پس باید این کار رو برمی‌اندازم."

    # say L74 pla
    old "Woah, woah, wait a minute."
    new "وای، وای، بی‌چین بی‌چین."

    # say L75 pla
    old "Listen, you don't have to say all those bad things about you, and you also shouldn't say that you're going to give up."
    new "بله، نباید همه این حرف‌های بد رو در مورد خودت بزنی، و همچنین نباید بگی که قصد داری تسلیم شی."

    # say L76 pla
    old "I actually agree with you, you have every right to live your life any way you want to."
    new "من در واقع با تو موافقم، تو هر حقی داری که زندگیت رو همین طور بزن."

    # say L77 pla
    old "Anna's just jealous because you're her mother. And she's always very possessive."
    new "آننا فقط حسودت می‌کنه چون تو ماماشی. و همیشه خیلی مالکانه است."

    # say L78 pla
    old "But you're free to do whatever you want. And I'm totally sure you can be with anyone you want to."
    new "اما تو آزادی داری هر کاری که می‌خوای انجام بدی. و من کاملاً مطمئنم که می‌تونی با هر کسی که می‌خوای باشی."

    # say L82 pla
    old "Of course I do! Anyone would be lucky to meet you. I'm sure of it."
    new "البته! هر کسی خوشحالم که با تو آشنا شده. این جوری مطمئنم."

    # say L83 pla
    old "In fact, if Anna won't do it. Let me help you, I'll set up your profile for you."
    new "در واقع، اگر آنا نمی‌خواد انجام بده. بیا من بهت کمک می‌کنم، پروفایلت رو تنظیم می‌کنم."

    # say L86 pla
    old "Of course, I'll do it right now."
    new "البته، الان هم انجام میدم."

    # say L87 lyd
    old "Ohh! That's so nice of you! Thank you [pla]!"
    new "اوه! اینقدر لطف داری! ممنون [pla]!"

    # say L88 lyd
    old "Let's go to my room, my computer's there."
    new "بیای به اتاقم، کامپیوترم اونجا هست."

    # say L89 pla
    old "Oh no, there's no need. These days the best and easiest ways to meet people online are dating apps."
    new "اوه نه، لازم نیست. این روزها بهترین و راحت‌ترین راه برای آشنایی با افراد در اینترنت اپلیکیشن‌های دیتینگ هست."

    # say L90 pla
    old "You know, on the phone. Have you ever heard of Tinder?"
    new "می‌دونی، توی گوشی. تایندر شنیدی؟"

    # say L91 lyd
    old "Tinder? No, no idea what it is."
    new "تیندر؟ نه، هیچ ایده‌ای ندارم."

    # say L92 pla
    old "Well, it's this new dating app, in which you create a profile with your information on it."
    new "خب، این یک اپ جدید برای آشنایی است که تویش می‌تونی پروفایلی با اطلاعاتت بسازی."

    # say L93 pla
    old "The profile is public, so anyone can see it, and decide if they would like to talk to you or not."
    new "پروفایل عمومیه، هر کس می‌تونه ببینه و بفهمه که آیا می‌خواد با تو صحبت کنه یا نه."

    # say L94 lyd
    old "I see, what kind of information should go in there?"
    new "می‌فهمم، اطلاعات چه نوعی باید تویش قرار بگیره؟"

    # say L95 pla
    old "Nothing private, just the type of person you are, what you like and dislike."
    new "هیچ چیز خصوصی، فقط نوع شخصیتت، چیزهایی که دوست داری و نداری."

    # say L96 pla
    old "And a couple of pictures of you, so they know how you look."
    new "و چند عکس از خودت هم بگذاری، تا بدونن چه شکلی داری."

    # say L97 pla
    old "You can also write what you want to find in a partner, so they know if you'll like them."
    new "می‌تونی بنویسی چه کسی رو به عنوان همراه خواسته‌ت، تا بدونن اگه باهاشون سازگاری داری."

    # say L98 lyd
    old "That sounds interesting. How does it work?"
    new "این جالب است. چطور کار می‌کنه؟"

    # say L99 pla
    old "It's very simple, once your profile is on the app it will be visible to people in it."
    new "این خیلی ساده است، یک بار پروفایلت روی اپ قرار گرفت، برای افراد درون آن دیده خواهد شد."

    # say L100 pla
    old "And they get to decide if they would like to meet you."
    new "و اونا می‌تونن بگن که آیا می‌خوان تو رو ببینن."

    # say L101 pla
    old "If they do, all they have to do is swipe your profile to the right, if they don't they swipe left."
    new "اگر مایل باشند، فقط کافیه پروفایلت رو به راست بکشند، اگر نه به چپ."

    # say L102 pla
    old "And it's the same with you, if you see a profile you swipe either right or left, depending on if you like them or not."
    new "و همینطور تو هم هستی، اگه پروفایلی ببینی که می‌پسندی به راست می‌شوی، اگه نه به چپ."

    # say L103 pla
    old "If both of you swipe right, that means it's a match, and you can both start talking."
    new "اگر هر دوی شما به راست سوایید، این بدان معناست که مطابقت پیدا کردید و می‌توانید شروع به صحبت کنید."

    # say L104 lyd
    old "Hmm, that sounds very simple and practical."
    new "هم، این خیلی ساده و عملی به نظر می‌رسه."

    # say L105 pla
    old "It is, come on, I'll help you set your profile."
    new "بله، بیا، من بهت کمک می‌کنم برای تنظیم پروفایلت."

    # say L112 pla
    old "Ok, so, first of all, is setting up your bio, it's just a small description of you and the things you like and your interests."
    new "خب، اول اینکه، تنظیم بایوی تو هست، فقط یه توضیح کوتاه از خودت و چیزهایی که دوست داری و علاقه‌هایت."

    # say L113 lyd
    old "Ok, so let me see, hmm... I got it!"
    new "باشه، بیا ببینم، هم... گرفتم!"

    # say L114 lyd
    old "I'm a single woman who enjoys the simple things in life. I love long walks, enjoying nature and talking."
    new "من زنی مجرد هستم که از چیزهای ساده در زندگی لذت می‌برم. دوست دارم پیاده‌روی‌های طولانی بکنم، با طبیعت لحظات خوب را بگذرانم و صحبت کنم."

    # say L115 lyd
    old "My perfect evening is a summer afternoon enjoying a glass of merlot and reading a good book."
    new "عصر تابستانی ایده‌آل من، لذت بردن از یک لیوان مرلو و خواندن یک کتاب خوب است."

    # say L124 pla
    old "Ok, so that's your profile all set."
    new "خب، پروفایلت الان آماده شد."

    # say L125 lyd
    old "Oh wow, that took no time, and it looks great!"
    new "اوه وای، این هیچ وقت نگرفت و خیلی خوب به نظر می‌رسه!"

    # say L127 lyd
    old "So? What do I do now?"
    new "پس؟ حالا من چی کار می‌کنم؟"

    # say L128 pla
    old "Well, now that you have your own profile, what you have to do is look at other people's profiles."
    new "خب، حالا که پروفایل خودت رو داری، باید پروفایل‌های دیگران رو بررسی کنی."

    # say L129 pla
    old "And see if you like any of them. You do this by swiping right or left..."
    new "و ببین اگه کسی رو دوست داری. اینجوری با رایت یا لفت سوایپ می‌کنی..."

    # say L130 lyd
    old "Woah, woah, that's a little too fast for me, and it sounds a bit complicated."
    new "وای، وای، این برای من خیلی سریعه و کمی پیچیده به نظر می‌رسه."

    # say L131 lyd
    old "Hmm, why don't you do it for me?"
    new "Hmm، چرا تو این کار رو برای من انجام بدی؟"

    # say L133 pla
    old "Hmm... ok sure, no problem, it's not hard, once you get it, it will be really easy."
    new "Hmm... خب حس شد، مشکلی نداره، یه بار یاد بگیری خیلی آسون میشه."

    # say L134 pla
    old "Alright, let's start, but, if I'm the one doing it, I won't know what kind of guy you're into."
    new "باشه، بیاین شروع کنیم، ولی اگر من هستم که این کار رو انجام می‌دم، نمی‌دونم چه جور مردی دوست داری."

    # say L135 pla
    old "Why don't you tell me what you're looking for in a man?"
    new "چرا به من نمی‌گی از چه نوع مرد خوشت می‌آید؟"

    # say L136 pla
    old "That way I'll know who to select."
    new "این جوری می‌دونم چه کسی رو باید انتخاب کنم."

    # say L137 lyd
    old "What I'm looking for? Hmm, let's see..."
    new "چیزی که می‌خوام؟ هم، بیاین ببینیم..."

    # say L138 lyd
    old "Well, I tend to like guys with beards, I think they look very manly, but it's not a requirement."
    new "خب، معمولاً به پسرانی که لیس دارن علاقه دارم، فکر کنم لیس خیلی مردانه به نظر می‌رسه، اما این الزامی نیست."

    # say L139 pla
    old "Hmm, ok, I'll keep that in mind."
    new "Hmm، خب، اینو به ذهنم می‌سپارم."

    # say L140 lyd
    old "But, be sure that it's a beard, not a mustache, I hate mustaches."
    new "اما مطمئن شو که اون لیس باشه، نه ریش، من ریش رو می‌نخوام."

    # say L141 lyd
    old "My husband used to have one and I was never able to get him to shave it."
    new "مرد من قبلاً داشت و هرگز نتونستم بیا خودش رو ببرد."

    # say L142 pla
    old "Sure, that's an important detail."
    new "بله، این جزئیات مهمه."

    # say L143 pla
    old "Anything else?"
    new "چیز دیگه‌ای؟"

    # say L145 lyd
    old "I don't like bald men, I prefer a nice head of hair, but no white hair, not even at the sides."
    new "من نمی‌تونم به مردان بی‌مو خوشحالم، دوست دارم سری خوبی داشته باشند، اما موی سفید نه، حتی از طرف‌ها هم."

    # say L146 pla
    old "Alright, no bald men or white hair."
    new "باشه، هیچ مرد بی‌مو یا گری‌مو نه."

    # say L147 lyd
    old "Well, to be honest, I'm looking for a young guy, so I'd rather he didn't look old, like wrinkles and stuff..."
    new "البته، صداقت بگم، من به دنبال یه پسر جوان هستم، پس ترجیح میدم به نظر سالخورده نباشه، مثل ریش و اینا..."

    # say L148 pla
    old "Got it. Something else?"
    new "فهمیدم. چیز دیگه‌ای هست؟"

    # say L149 lyd
    old "Oh right, I don't know why but I have never been into gingers... So, no red hair, nothing personal..."
    new "اوه درسته، نمی‌دونم چرا ولی هیچ وقت به مردان قرمز مو علاقه نداشتم... پس، بدون مو قرمز، هیچ اشکالی نداره..."

    # say L150 pla
    old "Hmm, Ok, I think I got everything. I'll try my best to find you someone like that."
    new "Hmm، اوکی، فکر کنم همه چی رو گرفتم. سعی می‌کنم بهترین کار رو برایت انجام بدم."

    # say L152 lyd
    old "Woah, thank you pumpkin, this is exciting!"
    new "وای، ممنون عزیزم، این خیلی هیجان‌انگیزه!"

    # say L167 pla
    old "Ok Lydia, here you go, I think I got just what you wanted."
    new "خب لیدیا، اینجا هست، فکر کنم دقیقاً آنچه می‌خواستی رو پیدا کردم."

    # say L168 pla
    old "And look at that, you already matched with a couple of them!"
    new "و ببین، قطعاً با چند تاشون همپوشانی پیدا کردی!"

    # say L169 pla
    old "If you want to you can start talking with them."
    new "اگه می‌خوای می‌تونی باهاشون حرف بزنی."

    # say L170 lyd
    old "That's wonderful pumpkin!"
    new "این عالیه، عزیزم!"

    # say L171 lyd
    old "Oh, they all look very interesting indeed!"
    new "اوه، همه‌شون واقعاً جالب به نظر می‌اند!"

    # say L172 lyd
    old "This is great, I'll start talking to them."
    new "این عالیه، شروع می‌کنم با اونا صحبت کنم."

    # say L173 pla
    old "I'm glad you think they're good picks."
    new "خوشحالم که فکر می‌کنی انتخاب‌هامون خوب هستند."

    # say L174 lyd
    old "I do, they look great."
    new "بله، خیلی خوب هستند."

    # say L175 lyd
    old "Now listen [pla], I'm very happy and thankful that you're helping me with this."
    new "الان بگوش [pla]، خیلی خوشحالم و ممنون از کمکت به من در این کار."

    # say L176 lyd
    old "But, Anna might come back soon, and I fear what she'll say if she sees us doing this."
    new "اما آنی ممکن است زودباز برگرده و من نگرانم اگر او ما رو در حال انجام این کار ببینه."

    # say L177 lyd
    old "I think it would be better if you leave before she comes back."
    new "من فکر می‌کنم بهتر باشه قبل از برگشت اونجا بروی."

    # say L181 pla
    old "Oh, sure, you're right! I'd forgotten about Anna."
    new "اوه، البته، درست می‌گی، من فراموش کرده بودم از آنا."

    # say L182 pla
    old "I'll come back later to see how it went with the guys, ok?"
    new "بعداً می‌آیم می‌بینم با پسران چطور شد، خوبه؟"

    # say L184 lyd
    old "Sure, but please come in the afternoon, when Anna is usually out."
    new "بله، ولی لطفاً بعد از ظهر بیا، وقتی آنا معمولاً خارج است."

    # say L185 pla
    old "Alright, I will come in the afternoon."
    new "باشه، بعد از ظهر می‌آیم."

    # say L186 lyd
    old "Thank you so much pumpkin, I really appreciate your help."
    new "ممنونم عزیزم، واقعاً از کمکت خوشحالم."

    # say L187 pla
    old "No biggie, I'm happy to help, bye!"
    new "خواهش می‌کنم، خوشحالم که کمک کردم، بای!"

    # say L203 pla
    old "Damn, I think I didn't do a good job with this Lydia, sorry."
    new "دیوونه، فکر کنم کار خوبی انجام ندادم لیدیا، معذرت."

    # say L204 lyd
    old "Really? Did the phone fail?"
    new "وای، همینجوری؟ گوشی خراب شد؟"

    # say L205 pla
    old "No, no, it's just that I think I selected some profiles wrong. So you may not like them too much."
    new "نه، نه، فقط فکر می‌کنم چند پروفایل رو اشتباه انتخاب کردم. پس ممکنه خیلی لایک نکنی."

    # say L206 lyd
    old "Aw, that's ok, you don't need to stress too much about it."
    new "اوه، این جوری هم خوبه، نباید خیلی نگرانش باشی."

    # say L207 lyd
    old "We're both learning about this kind of thing. It's ok, really."
    new "ما هر دو در این جور چیزها یاد می‌گیریم. واقعاً مشکلی نداره."

    # say L208 pla
    old "Thanks... Well, I think there's still a couple of matches, so you may talk to a couple of them, if you want to of course."
    new "ممنون... خب، فکر کنم هنوز چند نفر هستن، پس اگه می‌خوای با چند تاشون حرف بزنی، می‌تونی."

    # say L209 lyd
    old "I'll do it, maybe they're not that bad. But for now, I think it would be better if you left."
    new "من انجام می‌دم، شاید بد نباشند. ولی الان بهتره که بروی."

    # say L210 lyd
    old "Anna has been out for a little while now, so she could come back at any moment."
    new "آننا از یک روزه خارج شده، پس ممکنه هر لحظه برگرده."

    # say L211 lyd
    old "I don't even know what she would say if she finds out about this."
    new "حتی نمی‌دونم اگه این جوری شد، چه می‌گفت."

    # say L212 lyd
    old "I don't want any more trouble with her. So it's best if you leave."
    new "من نمی‌خوام باش هیچ مشکلی داشته باشیم. پس بهتره که بروی."

    # say L214 pla
    old "Yeah, you're right. I'll come back later to help again, bye Lydia."
    new "بله، درست می‌گی. بعداً می‌آیم دوباره کمکت کنم، خداحافظ لیدیا."

    # say L235 lyd
    old "Hi pumpkin! How are you?"
    new "سلام عزیزم! چطوری؟"

    # say L237 pla
    old "Hey, it's Anna around?"
    new "سلام لیدیا، آنا اینجا هست؟"

    # say L238 lyd
    old "She isn't, why?"
    new "نیست، چرا؟"

    # say L243 pla
    old "Well, I thought I could help you again with the app."
    new "خب، فکر کردم می‌تونم دوباره به تو در مورد اپ کمک کنم."

    # say L244 pla
    old "How has it been going since the last time? Have you talked to anybody?"
    new "از آخر بار چطور بود؟ با کسی صحبت کردی؟"

    # say L245 lyd
    old "Oh, not really, I've had a couple of conversations with some people, but nothing interesting."
    new "اوه، خیلی نه، با چند نفر صحبت کردم، اما هیچ چیز جالبی نبود."

    # say L248 pla
    old "Well, that's why I'm here, to help you out. So let's see the app."
    new "خب، برای همین اینجا آمدم تا به تو کمک کنم. بیای، ببینیم اپ چطوره."

    # say L262 pla
    old "Ok, here you go, I think I got just what you wanted."
    new "خب، اینجاست، فکر کنم همون چیزی هست که می‌خواستی."

    # say L270 pla
    old "With that done, I think it's better if I leave."
    new "با این کار انجام شده، فکر می‌کنم بهتره من برگردم."

    # say L272 pla
    old "We wouldn't want Anna to get here and catch us."
    new "ما نمی‌خوایم آنا بیاد و ما رو ببینه."

    # say L273 lyd
    old "Sure, thanks again [pla], I really appreciate your help."
    new "بله، ممنون دوباره [pla]، واقعاً از کمکت خوشحالم."

    # say L319 lyd
    old "Hmm, I guess that's ok, you don't need to stress too much about it."
    new "Hmm، فکر کنم این جوری هم خوبه، نباید خیلی نگرانش بشی."

    # say L321 pla
    old "Thanks... Well, I think there's still a couple of them you could talk to if you want to of course."
    new "ممنون... خب، فکر کنم هنوز چند نفر هستن که می‌تونی باهاشون صحبت کنی اگه می‌خوای طبعاً."

    # say L347 pla
    old "Hi Lydia, how are you?"
    new "سلام لیدیا، حالت چطوره؟"

    # say L348 lyd
    old "Hmm, hello [pla] I'm ok, I guess..."
    new "هم، سلام [pla] خوبم، حدس می‌زنم..."

    # say L349 pla
    old "What? Did something happen? Why do you look so sad?"
    new "چه کاری داری؟ چرا چهرت چنین ناراحتانه است؟"

    # say L350 lyd
    old "Well... the thing is..."
    new "خب... اونجوری که هست، می‌تونی بگی..."

    # say L351 lyd
    old "Ugh, I've been talking with a couple of men on tinder, and..."
    new "اوه، من با چند مرد در تایندر صحبت کردم، و..."

    # say L352 pla
    old "Oh, did I make a mistake choosing their profiles? Is there something wrong with them?"
    new "او، من اشتباهی کردم در انتخاب پروفایل‌هایشون؟ مشکلی با اونا داری؟"

    # say L354 lyd
    old "Hmm, their perfectly nice gentlemen, very smart and all."
    new "هم، اونا مردان خوبی هستن، خیلی هوشمند و همه."

    # say L355 lyd
    old "But, they're very old! As old as my ex husband was! And I don't want that!"
    new "ولی، آنها خیلی قدیمی هستند! مثل همسر سابق من! و من نمی‌خوام اینطور باشم!"

    # say L356 lyd
    old "I mean, I just widowed a man that age."
    new "من قصدم اینه که مردی به همین سن را بیوه کنم."

    # say L357 lyd
    old "When I talked about dating again I was thinking more along the lines of young, energetic men, full of vitality... You know?"
    new "وقتی درباره دوباره رفتار عاشقانه صحبت می‌کردم، به مردان جوان و انرژی‌دار، پر از زنده‌بودن فکر می‌کردم... می‌فهمی؟"

    # say L359 pla
    old "I- I guess I do."
    new "من- من حدس می‌زنم بله."

    # say L360 lyd
    old "Why is the app only pairing me with these old guys?"
    new "چرا اپ فقط منو با اینا جفت می‌کنه؟"

    # say L361 pla
    old "Uhh, I don't really know why."
    new "اوه، واقعاً نمی‌دونم چرا."

    # say L362 pla
    old "Maybe it's the algorithm putting you with people your age."
    new "شاید الگوریتم تو رو با افراد هم سن جفت می‌کنه."

    # say L363 pla
    old "But, I think there might be something we can do about that."
    new "اما فکر کنم می‌تونیم چیزی برای این کار بکنیم."

    # say L364 lyd
    old "Yeah? What is it?"
    new "بله؟ چیه؟"

    # say L365 pla
    old "Well, we could 'fix' your profile. Improve it a little."
    new "خب، می‌تونیم پروفایلت رو اصلاح کنیم. یه کم بهترش بکنیم."

    # say L366 lyd
    old "What do you mean by 'fix'?"
    new "می‌خوای بگی اصلاح چیه؟"

    # say L367 pla
    old "We could, for example, put a better picture of you. Or maybe another description of you in the bio."
    new "مثلاً می‌تونیم عکس بهتری از تو بذاریم. یا شاید توضیحات جدیدی در بیو بنویسیم."

    # say L368 pla
    old "Something that will be more attractive to younger men."
    new "چیزی که برای مردان جوان جذاب‌تر باشه."

    # say L370 lyd
    old "That sounds like a great idea!"
    new "این یک ایده عالیه!"

    # say L371 pla
    old "Yeah, keeping in mind that those are the things that people will see when they go to your profile."
    new "بله، با توجه به اینکه این‌ها چیزهایی هستند که مردم وقتی به پروفایلت می‌رسن، می‌بینن."

    # say L372 pla
    old "We could work on them to get more young people to swipe right instead of left on your profile."
    new "می‌تونیم اونا رو تغییر بدیم تا بیشتر جوان‌ها روی پروفایلت به راست سوایشون کنن."

    # say L373 lyd
    old "That'd be perfect, let's do it."
    new "عالی، بیایم انجام بدیم."

    # say L382 pla
    old "The first thing is the picture, do you have any picture in which you look a little more casual?"
    new "اولین چیز عکس هست، تو عکسی داری که کمی طبیعی‌تر به نظر بیاد؟"

    # say L383 lyd
    old "I think I do, yeah, there must be a couple of some trips and excursions there in the phone."
    new "فکر کنم هست، بله، حتماً چند تا از سفرها و تورهایی که رفته‌ام توی گوشی هست."

    # say L388 pla
    old "Ok, that's perfect, now for the bio."
    new "باشه، این هم خوبه، حالا برای بیو."

    # say L389 pla
    old "I think we could maybe change it for either something more casual or a little bit more... Uhh, seductive."
    new "فکر کنم می‌تونیم اون رو تغییر بدیم، هم برای چیزی آسان‌تر یا یه کمی بیشتر... اوه، جذاب‌تر."

    # say L390 pla
    old "What do you think?"
    new "چه نظری داری؟"

    # say L392 lyd
    old "Well, if that helps, I think we should give it a try."
    new "خب، اگر این کمک کنه، فکر می‌کنم باید امتحانش کنیم."

    # say L393 pla
    old "Alright, let me think in something."
    new "باشه، بیایم چیزی فکر کنیم."

    # say L398 pla
    old "Ok, it's ready, what do you think?"
    new "باشه، آماده شد، تو چه فکر می‌کنی؟"

    # say L399 lyd
    old "It looks great! And I think I get what you were saying, this one definitely sounds and looks a lot more attractive."
    new "عالی به نظر می‌رسه! و فکر کنم متوجه شدم، این تا از همه جذاب‌تر به نظر می‌رسه."

    # say L402 pla
    old "I'm glad you like it. I'm sure this time we'll attract some younger men."
    new "خوشحالم که لایکش کردی. این بار مطمئنم جوان‌ترین مردان رو جذب می‌کنیم."

    # say L404 pla
    old "Do you want to try now? I could get on the app and see if you can make a match with some new people."
    new "می‌خوای حالا امتحان کنیم؟ می‌تونم تو اپ برسم و ببینم آیا بتونی با افراد جدیدی همپوشانی پیدا کنی."

    # say L405 lyd
    old "Sure, just one little thing pumpkin. What does that GILF thing mean? Is it some kind of world play?"
    new "بله، فقط یه چیز کوچیک عزیزم. اون چیز GILF یعنی چی؟ این یه بازی کلماته؟"

    # say L406 pla
    old "Uhh, t-that... yeah."
    new "اوه، آن... بله."

    # say L407 pla
    old "It's actually an acronym."
    new "این در واقع یک اکرانیسم هست."

    # say L409 lyd
    old "It is? What does it stand for?"
    new "این هست؟ این برای چه چیزی است؟"

    # say L410 pla
    old "Hmm, it stands for... Great... I- Intelligent, L- Loving... Friend."
    new "هم، این به معنی... Great... I- هوشمند، L- عاشقانه... دوست."

    # say L411 pla
    old "It's something that people my age understand, don't worry."
    new "این چیزیه که مردم مثل من فهمیدن، نگران نباش."

    # say L413 lyd
    old "Ohh, I see! That's great! Thank you."
    new "اوه، متوجه شدم! خوبه! ممنون."

    # say L414 lyd
    old "Well, I guess we can start looking for some profiles now."
    new "خب، به نظر می‌رسه می‌تونیم الان شروع کنیم به جستجوی پروفایل‌ها."

    # say L433 lyd
    old "Hi pumpkin!"
    new "سلام عزیزم!"

    # say L434 lyd
    old "I'm very fine, thank you."
    new "من خیلی خوب هستم، ممنون."

    # say L435 pla
    old "Oh yeah? Has anything good happened on tinder?"
    new "اوه همینطور؟ چیز خوبی تو تایندر افتاده؟"

    # say L436 lyd
    old "Well, you could say that. Ever since we changed my profile the number of young men talking to me has increased. It's been very exciting."
    new "می‌تونی همین‌جوری بگی. از وقتی پروفایلم رو تغییر دادیم، تعداد مردان جوانی که با من صحبت می‌کنند افزایش یافته. خیلی هیجان‌انگیز بوده."

    # say L437 pla
    old "That's good to hear. So, it worked! it's what you expected, right?"
    new "خوشحالم که شنیدم. پس کار کرد! همینطوری که انتظار داشتی، درسته؟"

    # say L438 lyd
    old "Hmm, it kinda is but..."
    new "هم، نوعاً هست ولی..."

    # say L439 pla
    old "What? Anything wrong with anyone?"
    new "چیه؟ کسی مشکلی داره؟"

    # say L440 lyd
    old "No, nothing wrong per se with the people I'm speaking to or the app."
    new "نه، هیچ مشکلی با افرادی که با من صحبت می‌کنم یا با اپ نیست."

    # say L442 pla
    old "Then what is it?"
    new "پس چیه؟"

    # say L444 lyd
    old "Well, it's more to do with their language."
    new "خب، بیشتر مربوط به زبانشون هست."

    # say L445 lyd
    old "To be honest I don't understand a lot of what they say. There is this one guy I was talking to."
    new "صusch، خیلی از چیزهایی که می‌گن نمی‌فهمم. هست یه نفری که باهاش حرف زدم."

    # say L446 lyd
    old "And he suddenly began writing things like, lmao, brb, tbh."
    new "و او忽然 شروع کرد به نوشتن چیزهایی مثل، lmao، brb، tbh."

    # say L448 lyd
    old "And when asked him what he meant."
    new "و وقتی ازش پرسیدم که چه می‌خواست بگه."

    # say L449 lyd
    old "And he answered saying: 'lol, Idk wdym?"
    new "و او جواب داد: lol، Idk wdym؟"

    # say L450 lyd
    old "What?! What does that even mean?!"
    new "چه؟! این یعنی چی؟!"

    # say L453 lyd
    old "Yeah, how am I even supposed to talk to these people?"
    new "بله، من چطور باید با این مردم صحبت کنم؟"

    # say L455 lyd
    old "Don't laugh, this isn't funny."
    new "خنده نکن، این جدیه."

    # say L456 pla
    old "Y-you're right, sorry."
    new "بله، درست می‌گویی، معذرت."

    # say L457 pla
    old "It's just that I wasn't expecting that. But, I get what you mean, I guess young people talk in a confusing way."
    new "البته، من هم انتظار نداشتم. ولی، منظورت رو متوجه شدم، به نظر می‌رسه جوان‌ها به طوری حرف می‌زنن که گیج کننده است."

    # say L458 pla
    old "Don't worry, they're not saying anything weird, they're just abbreviations, so you don't have to write the whole thing."
    new "نگران نباش، هیچ چیز عجیبی نمی‌گن، فقط مخفف‌ها هستن، پس نمی‌تونی همه چی رو بنویسی."

    # say L459 pla
    old "I'll teach you how to use them."
    new "من بهت یادم میدم که چطور ازشون استفاده کنی."

    # say L460 lyd
    old "Well, I thank you, but I don't think that's going to do much for me. Because I've got another problem with the app."
    new "البته، ممنونم، اما فکر نمی‌کنم این به من کمک زیادی بکنه. چون مشکل دیگه‌ای هم با اپ دارم."

    # say L461 lyd
    old "And is that damned keyboard, it's so small! I have no idea how you can write so fast on those little keyboards; you can't even see them!"
    new "و اون کیبورد شیطانی، خیلی کوچیکه! نمیدونم چطور می‌تونی به این سرعت روی اون کلیدهای کوچیک بنویسی؛ حتی نمی‌شناسن!"

    # say L462 pla
    old "Come on, come on, don't stress too much about it."
    new "بیا بیا، خیلی نگران نباش."

    # say L463 pla
    old "Let's just work on it and in no time you'll master them. You'll see."
    new "بیای بیشتر نگنجدت، با کمی تلاش اونا رو فهم می‌کنی. ببینی."

    # say L464 lyd
    old "If you say so. I guess I can try to learn..."
    new "اگه می‌گی، می‌تونم بیام و یاد بگیرم..."

    # say L470 lyd
    old "What a coincidence, this is the guy I was talking with yesterday night."
    new "این چقدر مصادفه، این همون دستاوردیه که دیروز شب باش حرف زدم."

    # say L471 lyd
    old "I know! Why don't we try speaking to him now? You could write for me!"
    new "می‌دونم! چرا همین حالا باش حرف نزنیم؟ تو می‌تونی برای من بنویسی!"

    # say L472 pla
    old "Hmm, I don't know, I mean, it's your conversation."
    new "Hmm، نمی‌دونم، یعنی این هم خودتو حرف می‌زنی."

    # say L473 lyd
    old "Oh please, since you'll actually understand if he uses those abbreviations, and you can use the keyboard."
    new "لطفاً، چون تو واقعاً می‌فهمی اگه اون اصطلاحات رو بکار ببره، و می‌تونی از کیبورد استفاده کنی."

    # say L474 lyd
    old "Why don't you just tell me what he's saying and I'll tell you what to answer?"
    new "چرا نمی‌گی برام اونو ترجمه کنی و من بگم باید چی جواب بدم؟"

    # say L475 pla
    old "Hahaha, that sounds odd."
    new "حاحاحا، این خیلی عجیب به نظر می‌رسه."

    # say L476 pla
    old "But I guess we can try."
    new "ولی به نظر می‌رسه می‌تونیم امتحان کنیم."

    # say L477 pla
    old "So, you see that it's not that difficult."
    new "پس می‌بینی که اینقدر سخت نیست."

    # say L491 lyd
    old "What did he say?"
    new "او چه گفت؟"

    # say L492 pla
    old "He's just saying hello, and asking how you are today."
    new "می‌گه سلام و می‌پرسه امروز حالت چطوره."

    # say L493 lyd
    old "Well, don't keep him waiting! Say hello back!"
    new "خب، نگه نداشته باش! به او هم سلام بده!"

    # say L497 lyd
    old "What did he say now?"
    new "الان چه گفت؟"

    # say L498 pla
    old "He said..."
    new "او گفت..."

    # say L499 lyd
    old "Here, let me see!"
    new "بیا، برام نشون بده!"

    # say L500 lyd
    old "Hmm, 'hbu'? What is that supposed to mean?"
    new "هم، 'هبو'؟ این چه معنی داره؟"

    # say L501 pla
    old "It means 'How about you?'"
    new "این به معنی «تو چطوری؟» است"

    # say L502 lyd
    old "Jesus, and he couldn't write that? How lazy are young people these days?"
    new "یا خدا، و نمی‌تونست اینو بنویسه؟ جوانان امروز چقدر لازی هستن؟"

    # say L503 pla
    old "It's not about being lazy, just answering fast."
    new "این در مورد لازی بودن نیست، فقط سریع جواب میدم."

    # say L504 pla
    old "Which by the way, he's waiting for us to answer him."
    new "به هر حال، او منتظر جواب ما هست."

    # say L505 lyd
    old "Oh shoot, right!"
    new "اوه، درسته!"

    # say L506 lyd
    old "Tell him: 'Oh, it's so good that you exercise, that's very good for the joints and muscles."
    new "بهش بگو: «اوه، خوشحالم که تمرین می‌کنی، این برای مفاصل و عضلاتت خیلی خوبه.»"

    # say L507 lyd
    old "Be sure to hydrate and rest properly."
    new "حتماً آب خور و به درستی استراحت کن."

    # say L508 pla
    old "Wait, what?!"
    new "وای، چی؟!"

    # say L509 pla
    old "Hahahahaha."
    new "هahaha، خب، نمی‌تونیم بهش بگیم این. صدایت مثل معلم تربیت بدنی می‌شه. باید کمی بازیگرتر باشی."

    # say L510 lyd
    old "Now what's so funny?"
    new "الان چه خنده‌داری؟"

    # say L511 pla
    old "Hahaha, well, we can't tell him that. You'd sound like a P.E. teacher. You have to be a little more playful."
    new "حاحاحا، خب، نمی‌تونیم بهش اینو بگیم. تو مثل معلم تربیت بدنی می‌گلی. باید یه کم بازی‌باز باشی."

    # say L513 lyd
    old "Playful?"
    new "بازی‌باز؟"

    # say L514 pla
    old "Yeah you know, something about how attractive that is to you and stuff."
    new "بله، مثلاً چطور این جالب برایت هست و اینجوری."

    # say L515 lyd
    old "I see, well..."
    new "می‌بینم، خب..."

    # say L516 lyd
    old "How about this?"
    new "این جوری چطور؟"

    # say L517 lyd
    old "I love that you exercise, you must be in great shape then."
    new "من عاشق اینم که تو ورزش می‌کنی، باید شکل خوبی داشته باشی."

    # say L518 pla
    old "Hmm, not really playful, but it could work."
    new "Hmm، خیلی بازی‌باز نیست، اما می‌تونه کار کنه."

    # say L519 pla
    old "Let's see how it goes."
    new "ببینیم چطور می‌شه."

    # say L523 pla
    old "He said 'Oh yeah, maybe if you're lucky I'll let you take a peek later.'"
    new "او گفت «آره، شاید اگه خوشحالم بعداً به تو اجازه بدم نگاه کنی.»"

    # say L524 lyd
    old "Oh, hahaha, that's so cute. Then tell him that..."
    new "اوه، هahaha، اینقدر لطیفه. بعد بهش بگو که..."

    # say L525 pla
    old "Wait, there's more."
    new "پیش، بیشتر هست."

    # say L527 pla
    old "Hmm, he says 'Judging from your pictures you must be super hot too.'"
    new "هم، او می‌گه «با توجه به عکس‌هایت باید خیلی جذاب باشی هم.»"

    # say L528 lyd
    old "Oh, really? That's so nice!"
    new "اوه، واقعاً؟ این خیلی لطف داره!"

    # say L529 lyd
    old "Hmm... Tell him 'You're joking, right? I'm just an old woman.'"
    new "همم... بهش بگو 'دیوانه‌ای، مزح داری، درسته؟ من فقط یه بابا هستم.'"

    # say L530 pla
    old "Really? Hmm alright..."
    new "وای، واقعاً؟ خب خوب..."

    # say L534 pla
    old "He says 'Come on! Don't say that, I'm sure you're beautiful.'"
    new "می‌گه «بیا! نگو اینجوری، مطمئنم زیبا هستی.»"

    # say L535 pla
    old "And then he says 'Also, I wouldn't call you 'old'. On the contrary, I think you're very experienced, and experience is sexy.'"
    new "و بعد می‌گه «همچنین، من تو رو «بزرگ» نمی‌خوانم. بلکه فکر می‌کنم تجربه‌ات خیلی زیاده و تجربه جذابه.»"

    # say L536 lyd
    old "Hahaha, what a cute guy."
    new "هahaha، چه پسر لطیفی."

    # say L537 lyd
    old "Tell him 'Well it seems you know how to compliment a lady.'"
    new "خب به نظر می‌رسه می‌دونی چطور یه خانم رو لایق بگیری."

    # say L542 pla
    old "He says 'That's not the only thing I know how to do with a lady.'"
    new "می‌گه «این تنها چیزی نیست که با یه خانم می‌تونم انجام بدم.»"

    # say L545 pla
    old "And now he adds 'Why don't we go out for dinner and you let me show you?'"
    new "چرا ما برای شام نرویم و من بهت نشون بدم؟"

    # say L546 lyd
    old "Well isn't he brave? He just invited me to date out of the blue!"
    new "خب، این جسورت‌اش هست؟ فقط و فقط دیدم که منو به روز دیت دعوت کرده!"

    # say L547 lyd
    old "But I don't think I should accept just like that, I don't want him to think that I'm desperate."
    new "اما فکر نمی‌کنم باید همینطور پذیرفت، نمی‌خوام فکر کنه من نیازمند هستم."

    # say L548 pla
    old "Then what should I tell him?"
    new "بعدش چی بگم؟"

    # say L549 lyd
    old "Hmm, let me think..."
    new "Hmm، بیایم فکر کنم..."

    # say L550 lyd
    old "I got it."
    new "فهمیدم."

    # say L551 lyd
    old "Tell him 'Ohh, I don't know, I think you'll be bored if you go out with an old woman like me.'"
    new "بهش بگو اوه، نمی‌دونم، فکر کنم خسته بشی اگه با یه مادربزرگ مثل من بره."

    # say L553 lyd
    old "Why did you write 'idk' what does that mean?"
    new "چرا idk نوشتی؟ این چه معنی داره؟"

    # say L554 pla
    old "I mean 'I don't know' it's just so that he doesn't think you're super formal."
    new "من قصه‌ای می‌گم که نمی‌دونم، فقط برای اینه که فکر نکنه تو خیلی رسمی هستی."

    # say L555 lyd
    old "Ohh, I see."
    new "اوه، متوجه شدم."

    # say L557 lyd
    old "Hmm, isn't he something?"
    new "Hmm، او چه کسی نیست؟"

    # say L558 lyd
    old "Write 'Oh really? Are you sure you're not just saying that to try and get in my pants?'"
    new "اوه واقعاً؟ مطمئنی که فقط برای اینکه بتوانی به لباس من برسی هم نمی‌گی؟"

    # say L563 pla
    old "He's saying 'Of course not, I honestly think you're super interesting.'"
    new "البته نه، من واقعاً فکر می‌کنم تو خیلی جالبی."

    # say L564 pla
    old "And also 'But hey, for what it's worth, I do like my women a little older ;)'"
    new "و همچنین 'اما بله، برای ارزشی که داره، من هم به زنان بزرگتر علاقه دارم؛)'"

    # say L567 lyd
    old "Hahahaha, tell him 'Well, aren't you something?'"
    new "حاحاحا، بهش بگو «خب، نیستی چیزی، هستی؟»"

    # say L571 pla
    old "Uhh... Now he's saying 'Baby I'm a little more than just something'"
    new "اوه... حالا می‌گه «حباب، من چیزی بیشتر از فقط چیزی هستم»"

    # say L572 pla
    old "And he is asking if you want to... Uhh, see."
    new "و او می‌پرسه اگه می‌خوای... اوه، ببینی."

    # say L573 lyd
    old "See? See what?"
    new "ببین؟ ببین چه چیزی؟"

    # say L574 pla
    old "Well... you know."
    new "خب... می‌دونی."

    # say L575 lyd
    old "Know what? Ask him, 'see what?'"
    new "می‌دونی چی؟ ازش بپرس، «ببین چی؟»"

    # say L580 pla
    old "He replied 'lol, you bad girl, you know what I mean...'"
    new "lol، تو دختر بدی، می‌دونی من چی می‌خوام بگم..."

    # say L581 lyd
    old "Lol? What's that?"
    new "lol؟ این چیه؟"

    # say L582 pla
    old "It means: 'Laughing out loud'."
    new "این به معنی «خنده دادن به صورت بلند» هست."

    # say L584 lyd
    old "So, something that I said was funny?"
    new "پس، چیزی که من گفتم خنده‌دار بود؟"

    # say L586 lyd
    old "But what? And what's he talking about me knowing what he means?"
    new "ولی چه کار؟ و اونجوری داره می‌گه من می‌دونم چی می‌خواد بگه؟"

    # say L589 lyd
    old "Oh wow! I wasn't expecting that!"
    new "اوه وای! اینو منتظر نبودم."

    # say L590 pla
    old "Hmm, me neither..."
    new "همم، من هم نبودم..."

    # say L591 lyd
    old "What do I answer now?"
    new "الان چی بگم؟"

    # say L593 pla
    old "Hmm, I- I guess you can tell him how surprised you are."
    new "Hmm، من- من فکر می‌کنم می‌تونی بهش بگی چقدر شوک شدی."

    # say L594 lyd
    old "Sure, tell him that I wasn't expecting that picture."
    new "بله، بگو بهش که این عکس رو منتظر نبودم."

    # say L598 pla
    old "He replied: 'Hahaha, well, you know... yolo, right?'"
    new "هahaha، خب، می‌دونی... یولو، درسته؟"

    # say L600 lyd
    old "Yolo?"
    new "یولو؟"

    # say L602 pla
    old "You only live once."
    new "فقط یک بار زنده‌ایم."

    # say L603 lyd
    old "You young people, honestly..."
    new "شما جوان‌ها، واقعاً..."

    # say L605 pla
    old "He wants to know what you thought about the picture."
    new "می‌خواد بدونه از عکس چه نظری داری."

    # say L606 lyd
    old "Really? W- what should I tell him?"
    new "وای، من واقعاً چه بگم؟"

    # say L608 pla
    old "Just tell him what you think."
    new "بله، فقط بهش بگو چه فکری داری."

    # say L609 lyd
    old "Well, let me see it again..."
    new "خب، بیای دوباره ببینم..."

    # say L616 lyd
    old "Well, I wasn't expecting him to just send it. That was very unexpected."
    new "خب، من منتظر نبودم که فقط بفرسته. این خیلی غیرمنتظره بود."

    # say L617 lyd
    old "But if I'm honest, it's very... impressive. Also, he's rock hard, do you think that's for me?"
    new "ولی اگر صادقانه باشم، خیلی... عالیه. همچنین، او سخته، فکر می‌کنی برای من هست؟"

    # say L619 pla
    old "Do I tell him that?"
    new "من بهش بگم؟"

    # say L620 lyd
    old "Well, that's what I think about that pic."
    new "خب، این همینه که از اون عکس فکر می‌کنم."

    # say L621 pla
    old "Alright, I'll tell him that."
    new "باشه، بهش می‌گم."

    # say L628 pla
    old "Of course it is, to be honest, you're super hot, so hot that you make me hard just thinking about being with you."
    new "البته، صادقانه بگم تو خیلی جذابی، همین فکر از کنارم بودنت می‌تونه مرا سخت کنه."

    # say L630 lyd
    old "That that's very sweet, thank you."
    new "این خیلی شیرینه، ممنون."

    # say L633 lyd
    old "And to be honest, seeing your hard dick also turns on a little."
    new "و صادقانه بگم، دیدن ناخودت هم من رو خیلی آتش زد."

    # say L636 pla
    old "Oh yeah? Tell me how much."
    new "اوه بله؟ برام بگو چقدر."

    # say L637 lyd
    old "Mmm, just seeing your hard dick is making me horny."
    new "می‌دونی، فقط دیدن ناخون تو می‌تونه منو خیلی خیس کنه."

    # say L640 pla
    old "That's it baby and thinking about your wet pussy makes me even harder."
    new "این هستش عزیزم و فکر کردن به مهیجت تو من رو هم بیشتر سخت می‌کنه."

    # say L648 lyd
    old "Yes, my pussy is dripping just thinking about your cock."
    new "بله، مهیجتم فقط فکر کردن به ناخن تو مرا خیلی خیس می‌کنه."

    # say L652 pla
    old "Oh baby, I want to fuck you with this big cock."
    new "اوه بیبی، می‌خوام با این ناخن بزرگ تو رو بکنم."

    # say L653 lyd
    old "Oh yes, I want you to come over and put that hard cock in me."
    new "اوه بله، می‌خوام بیایی و اون ناخن سختتو توی من بزاری."

    # say L656 pla
    old "Do you really want that baby?"
    new "می‌خوای واقعاً اینجوری باشه؟"

    # say L657 lyd
    old "Oh yes! I want it so bad!"
    new "اوه بله! خیلی می‌خوام!"

    # say L662 pla
    old "Tell me, what else do you want me to do to you?"
    new "بگو، چیز دیگری هم می‌خوای از من بکنم؟"

    # say L663 lyd
    old "I want you to come over and pull my hair while you fuck me!"
    new "می‌خوام بیایی و مویم رو بکشی در حالی که باهام جنس می‌کنی!"

    # say L666 pla
    old "Yes! I'll pull your hair while I fuck you from behind!"
    new "بله! از پشت به تو خواهم زد و موت خواهم کشید!"

    # say L669 lyd
    old "Yes! Yes! I want you to pull my hair and slap my ass!"
    new "بله! بله! می‌خوام تو مویم رو بکشی و پاشم رو بزنی!"

    # say L672 pla
    old "I'll pull your hair and call you my little slut!"
    new "من موتو کشونم و تو رو خر کوچولویم بخونم!"

    # say L673 lyd
    old "Oh yeah! I'm your little slut!"
    new "اوه بله! من خر کوچولویت!"

    # say L681 lyd
    old "Mmmm... Phew..."
    new "ممنن... خوب..."

    # say L682 lyd
    old "Wow, that was fun."
    new "واو، این خوشحالم بود."

    # say L688 pla
    old "He says he has to go now, he is late for his work."
    new "من باید برم، برای کار تأخیرم کردم."

    # say L689 lyd
    old "Ohh... hmm, sure."
    new "اوه... هم، البته."

    # say L693 pla
    old "He says 'It was awesome, you really are cool. I can't wait to meet you in person.'"
    new "می‌گه عالی بود، واقعاً خوبی. نمی‌تونم صبر کنم تا تو رو در واقعیت ببینم."

    # say L695 lyd
    old "Uhh t- thanks... see you later."
    new "اوه ممنون... بعداً ببینیم."

    # say L697 pla
    old "Ok, I think it's done, so I'm going home."
    new "باشه، فکر کنم تمام شده، پس من به خونه می‌رم."

    # say L707 lyd
    old "Uhh... Listen [pla]. I- I'm sorry. I didn't mean it for things to turn this way."
    new "اوه... شنیدی [pla]. من- من خیلی متاسفم. من قصد نداشتم اینجوری بشه."

    # say L708 lyd
    old "I'm sorry, I don't know what happened."
    new "متاسفم، نمی‌دونم چه اتفاقی افتاد."

    # say L709 lyd
    old "It's just that it's been so long since any kind of you know... Release."
    new "فقط اینجاست که از آن زمان که هیچ نوع رهاکنندگی نداشتیم طول زیادی گذشته."

    # say L710 lyd
    old "I wasn't expecting the conversation to take a turn that way."
    new "من منتظر نبودم که مکالمه به این طرف برود."

    # say L711 lyd
    old "But please believe me that I didn't plan any of this, I just couldn't help it."
    new "اما لطفاً باور کن که من هیچی از این‌ها رو برنامه‌ریزی نکردم، فقط نتونستم خودمو کنترل کنم."

    # say L712 pla
    old "Hey, hey, it's ok. Don't worry."
    new "بیا بیا، خوبه. نگران نباش."

    # say L713 pla
    old "I understand, and I'm not angry."
    new "من فهمیدم، و غصب ندارم."

    # say L714 pla
    old "I won't lie, I'm a little surprised."
    new "من دروغ نمی‌کنم، یه کم شوکه‌ام."

    # say L715 pla
    old "But, I understand. After all, the whole point of doing this was for you to let loose and meet new people."
    new "ولی من متوجه هستم. در نهایت، هدف اصلی این کار این بود که تو راحت شوی و آدم‌های جدید بشناختی."

    # say L716 lyd
    old "Thank you so much [pla]. You're an angel for understanding."
    new "ممنونم خیلی [pla]. تو مثل یک فرشتگی هستی که فهمیدی."

    # say L717 pla
    old "No biggie, but maybe I should go now."
    new "بزرگی نیست، ولی شاید باید حالا برسم."

    # say L718 lyd
    old "Yeah, you're right. Anna might come back any minute."
    new "بله، درست می‌گویی. آنا ممکن است هر لحظه برگردد."

    # say L719 pla
    old "Yeah, however, I'm glad to see that you're making progress with your online app."
    new "بله، اما خوشحالم که می‌بینم تو با اپلیکیشن آنلاین خود پیشرفت می‌کنی."

    # say L721 lyd
    old "But being honest it's all thanks to your help."
    new "البته، اما صادقانه همه این به کمکت برمی‌گردد."

    # say L722 pla
    old "It's nothing, I'm glad I can be of help to you."
    new "هیچی، خوشحالم که می‌تونم به تو کمک کنم."

    # say L723 pla
    old "Keep chatting and I'll be back soon to keep helping you."
    new "بگو چطوری، من همینجا خواهم بود تا به تو کمک کنم."

    # say L724 lyd
    old "All right, Thank you!"
    new "البته، ممنون!"

    # say L746 pla
    old "Hi, how a..."
    new "سلام، چطوری؟"

    # say L748 pla
    old "Is everything alright? Did anything happen?"
    new "همه چیز خوبه؟ چیزی اتفاق افتاد؟"

    # say L750 lyd
    old "Hi [pla] how are you?"
    new "سلام ز[pla] چطوری؟"

    # say L751 lyd
    old "I guess everything's right. I'm just not feeling well right now."
    new "به نظر می‌رسه همه چی خوبه. فقط الان خوب نیستم."

    # say L753 lyd
    old "Hmm, well, it's not much."
    new "Hmm، خب، خیلی خوب نیست."

    # say L754 lyd
    old "It's just that I went out with that guy you were helping me chat with."
    new "فقط اینکه با آن دستا که تو به من کمک کردی برای صحبت باشون رفتم."

    # say L756 lyd
    old "And it didn't go well, it was actually kinda bad."
    new "و خوب نرفت، در واقع بد بود."

    # say L759 pla
    old "Did he say anything bad to you?"
    new "او چیز بدی به تو گفت؟"

    # say L761 lyd
    old "No, no. The problem is that it didn't feel good."
    new "نه، نه. مشکل اینه که خوب نبود."

    # say L763 lyd
    old "We only talked about everyday stuff and the conversation didn't go anywhere from there. Is just as if he had lost all interest."
    new "ما فقط درباره چیزهای روزمره صحبت کردیم و هیچ جا نرفت. مثل اینه که همه علاقه‌اش رفت."

    # say L764 lyd
    old "I swear to god he wasn't even looking at me!"
    new "قسمت خدا حتی به من نگاهی نمی‌کرد!"

    # say L765 lyd
    old "And after saying all that stuff on our chat."
    new "و بعد از همه آن حرف‌هایی که در چت ما زدیم."

    # say L766 lyd
    old "It's extremely disappointing."
    new "این خیلی ناامید کننده است."

    # say L767 pla
    old "I see, I'm sorry that happened."
    new "می‌بینم، متاسفم که اینجوری شد."

    # say L769 lyd
    old "But to be honest [pla]. This date got me thinking."
    new "اما صداقت بگم [pla]. این تاریخ من رو فکر کردن کرد."

    # say L770 lyd
    old "And I don't think this whole thing of looking for younger men is for me."
    new "و فکر می‌کنم این کل موضوع جستجوی مردان جوان برای من مناسب نیست."

    # say L772 lyd
    old "Think about it, I don't even understand what they're saying when they write with those strange words they make up."
    new "فکر کن، من حتی نمی‌فهمم وقتی با این کلمات عجیبی که ساخته‌اند نوشتن، چه می‌گویند."

    # say L773 lyd
    old "And when I got a date with a guy that seemingly wanted to have something with me."
    new "و وقتی با یه مرد جوانی رنده شدم که به نظر می‌رسید مایل بود با من چیزی داشته باشه."

    # say L774 lyd
    old "He just lost all interest and began treating me all cordial and distant."
    new "او فقط همه علاقه‌اش رو از دست داد و شروع کرد به رفتار با من مثل یه آدم دوردست و رسمی."

    # say L777 lyd
    old "I didn't like that at all. I'm not doing this to be looked at as if I was their grandma."
    new "من هیچ لذتی از این نبردم. من اینجوری نمی‌خوام مثل باباهاشون در نظر گرفته بشه."

    # say L778 lyd
    old "So it's better if we just look for older men that are my age, I think I can date then."
    new "پس بهتره ما فقط به دنبال مردان بزرگتری که سنم هستن بگردیم، فکر کنم بتونم با اونا رابطه داشته باشم."

    # say L780 pla
    old "Well, I get what you mean."
    new "خب، من معنایت رو متوجه شدم."

    # say L781 pla
    old "But I don't actually think that's what you want Lydia."
    new "اما من واقعاً فکر نمی‌کنم این همچین چیزی باشه که می‌خوای لیدیا."

    # say L782 pla
    old "Listen, that guy was an idiot. You shouldn't let his attitude bring you down."
    new "بله، آدمی بی‌هیچی بود. نباید اجازه بدی رفتارش تو رو پایین ببره."

    # say L783 lyd
    old "Hmm, you say that but..."
    new "Hmm، تو اینجوری می‌گی، ولی..."

    # say L784 pla
    old "Listen, you went on a date, and it didn't go great because the guy turned out to be an asshole."
    new "بگو، رفتی توی دیت، و خوب نرفت چون آدم آن قدر احمق بود."

    # say L785 pla
    old "I get it sucks, but that stuff happens."
    new "فهمیدم، معلومه که خوب نبود، اما اینجوری‌ها می‌افتد."

    # say L786 pla
    old "Believe me, if it didn't go well it's because of him. You didn't have anything to do with that."
    new "باور کن، اگه خوب نگذشته، به خاطر او بوده. تو هیچ سر و تهی نداشته."

    # say L790 pla
    old "Of course! I mean, look at you. You are beautiful, and you're great to hang around. Any guy would be lucky to be with you."
    new "البته! منظورم اینه، به تو نگاه کن. تو زیبا هستی و با تو همراه بودن خوشحالم. هر مردی خوشحال می‌شود که با تو باشد."

    # say L791 lyd
    old "Hmph, you're sweet, but I know you're only saying that to cheer me up. I know you don't mean it."
    new "همف، شیرینی، اما می‌دونم فقط برای اینکه من راحت شم می‌گی‌ای اینا. می‌دونم معنی‌ش جدی نیست."

    # say L792 pla
    old "Swear to god that I do."
    new "قسمت خدا می‌خورم که همینطور هست."

    # say L793 lyd
    old "Well then you're the only one!"
    new "خب تو تنها هستی!"

    # say L794 lyd
    old "I mean let's just face it [pla]. I'm an old lonely widow with nothing to offer to any guy."
    new "من قراره بگم بیایم بگذاریم این حقیقت رو زیر چشمان بگیریم [pla]. من یه مادربزرگ تنها هستم که هیچ چیزی برای هیچ پسری ندارم."

    # say L795 lyd
    old "Besides, I can't compete with the girls young men go around with. With their perfect toned bodies."
    new "البته، من نمی‌تونم با دختران جوانی که با پسران می‌روند رقابت کنم. با اون بدن‌های کامل و تن‌دارشون."

    # say L796 lyd
    old "I'm old, any sex appeal that I had I lost a long time ago."
    new "من قدیمی هستم، هر جاذبه‌ای که داشتم از زمان‌ها خارج شده."

    # say L797 pla
    old "W- What?! What are you saying? You can't be serious."
    new "و- وای! چه حرفی می‌زنی؟ نمی‌تونی جدی باشی."

    # say L798 lyd
    old "Well, I am!"
    new "البته هستم!"

    # say L799 lyd
    old "It's just true, I'm no longer pretty."
    new "این فقط حقیقت است، دیگر زیبا نیستم."

    # say L800 pla
    old "What are you talking about, you're so beautiful."
    new "دستت در گرمی، تو خیلی زیبایی."

    # say L801 pla
    old "You're still a very sexy woman, your face, your body, everything about you is perfect."
    new "تو هنوز هم خیلی جذابی هستی، چهرت، بدنت، همه چیز در موردت کامله."

    # say L802 lyd
    old "Yeah right..."
    new "حق با تو نیست..."

    # say L803 pla
    old "I mean it, any man would find you to be incredibly sexy."
    new "من جدی هستم، هر مردی تو رو خیلی جذاب می‌بینه."

    # say L808 lyd
    old "Any man?"
    new "هر مردی؟"

    # say L809 pla
    old "All of them?"
    new "همه؟"

    # say L811 lyd
    old "... Even you?"
    new "حتی تو؟"

    # say L814 lyd
    old "Yeah, you, you said any man would think I'm sexy."
    new "بله، تو هم، تو خودت گفتی هر مرد فکر می‌کنه من جذابم."

    # say L815 lyd
    old "How about you? Do you really think I'm sexy?"
    new "تو چطوری؟ واقعاً فکر می‌کنی من جذابم؟"

    # say L817 pla
    old "Uhh, w- well, yeah, I mean..."
    new "اوه، خب، بله، منظورم..."

    # say L818 lyd
    old "You mean what?"
    new "منظورت چیه؟"

    # say L819 lyd
    old "I knew it! You also just think I'm old!"
    new "میدونستم! تو هم فکر می‌کنی من قدیمی هستم!"

    # say L820 pla
    old "No, no, not at all."
    new "نه، نه، هیچ کس نگفتم."

    # say L821 pla
    old "It's just that I wasn't expecting you to ask me that."
    new "فقط اینجاست که منتظر نبودم این سوال رو از من بپرسی."

    # say L822 pla
    old "But I mean, of course, I also think you're sexy."
    new "ولی منظورم اینه، البته فکر می‌کنم تو جذابی هستی."

    # say L824 lyd
    old "Really? And you actually mean it? You're not just saying that to please me?"
    new "وای، می‌گی؟ و واقعاً اینجوری فکر می‌کنی؟ فقط برای خوش کردن من نیستی؟"

    # say L826 pla
    old "For real, I mean it 100."
    new "حق باهات، من 100 درصد جدی هستم."

    # say L828 lyd
    old "Well, I don't know if you're lying, but just you saying I'm sexy is not enough."
    new "خب، نمی‌دونم آیا در می‌گویی، اما فقط با گفتن اینکه من جذاب هستم کافی نیست."

    # say L829 lyd
    old "But there's one way to know for certain... Your cock."
    new "اما راهی هست که مطمئن شوم... نشستت."

    # say L830 pla
    old "My cock? W- what do you mean?"
    new "پوسم؟ و- و منظورت چیه؟"

    # say L831 lyd
    old "To know if you're lying, you may say I'm sexy, but if you don't have an erection I won't believe you."
    new "برای اینکه بفهمم آیا در می‌گویی، می‌تونی بگی من جذابم، اما اگر نشستت سخت نشده باشه، من باورت نمی‌کنم."

    # say L832 lyd
    old "It's the same with all men, the penis never lies."
    new "همه مردان همینطور هستند، نشست هرگز دروغ نمی‌گن."

    # say L833 lyd
    old "So..."
    new "پس..."

    # say L837 pla
    old "W- whoa! What are you doing?"
    new "وای! تو چه کاری می‌کنی؟"

    # say L841 lyd
    old "Well, I wanted to know what you think about my breasts."
    new "خب، می‌خواستم بدونم تو در مورد سینام چه فکری داری."

    # say L842 lyd
    old "How about now? Do you still think I'm sexy?"
    new "الان چطوره؟ هنوز فکر می‌کنی من جذابم؟"

    # say L843 pla
    old "Y- yeah, of course."
    new "بله، البته."

    # say L844 lyd
    old "So, look at them, and let's see if your cock thinks the same."
    new "پس، بهشون نگاه کن و ببین آرهت هم همین فکر رو داره."

    # say L845 pla
    old "I don't think that's a good idea. After all..."
    new "من فکر می‌کنم این خوب نیست. در نهایت..."

    # say L846 lyd
    old "Stop putting up excuses and see my tit!"
    new "توقف از گذاشتن عذر و به سینم نگاه کن!"

    # say L847 lyd
    old "Or I'll know you're lying to me."
    new "یا می‌دونم به من در می‌آیی."

    # say L854 lyd
    old "Oh wow, this is impressive."
    new "او وای، این خیلی عالی است."

    # say L855 lyd
    old "Ok, I believe you, if you're this hard you must be telling the truth."
    new "خب، باورتم می‌کنم، اگر اینقدر سختی باید حقیقت رو می‌گیه."

    # say L856 pla
    old "Yeah, well, I do believe you're very beautiful."
    new "بله، خوب، من هم باور دارم تو خیلی زیبایی."

    # say L857 lyd
    old "Well, I have no doubt about that now."
    new "خب، الان شکی هم ندارم."

    # say L858 lyd
    old "I must say [pla] your cock is something else."
    new "باید بگم [pla] نوزک تو خیلی متفاوته."

    # say L859 lyd
    old "It's so... big."
    new "اینقدر... بزرگ است."

    # say L860 lyd
    old "I- I can believe that it is because of me."
    new "من- من می‌تونم باور کنم این به خاطر من است."

    # say L862 lyd
    old "It's really flattering that such a young man like you can feel that way about a woman my age."
    new "الان واقعاً لطیفه که مرد جوانی مثل تو احساس این‌جوری برای زنی مثل من داشته باشی."

    # say L868 lyd
    old "I- I just want to see it closer..."
    new "من - من فقط می‌خوام نزدیک‌تر ببینم..."

    # say L869 lyd
    old "It's been a long time since I've seen one so close."
    new "از آن زمان که آخر بار یکی رو اینقدر نزدیک دیدم طول زیادی گذشته."

    # say L873 lyd
    old "And, it wasn't that big... Not at all..."
    new "و، خیلی بزرگ نبود... هیچ..."

    # say L874 lyd
    old "Knowing this is caused by me really makes me tingle."
    new "دانستن اینکه این به خاطر من اتفاق افتاده واقعاً منو تحریک می‌کنه."

    # say L875 lyd
    old "I'm sorry to ask but, may I see it... I mean, out of your pants?"
    new "ببخشید ولی می‌تونم ببینمش... منظورم از پایین شلوار؟"

    # say L876 lyd
    old "To be honest, is the first time I have seen one that big, and really makes me curious..."
    new "صusch، این اولین باره می‌بینم یکی اینقدر بزرگ، و واقعاً خیلی کنجکاو می‌کنم..."

    # say L877 pla
    old "... Hmm o- ok."
    new "...Hmm اوکی."

    # say L881 lyd
    old "Oh wow! It's even bigger than I thought it was..."
    new "اوه وای! حتی بزرگتر از آنچه فکر می‌کردم است..."

    # say L882 lyd
    old "I have never thought you were this... gifted."
    new "هیچ وقت فکر نکردم تو اینقدر... هدیه‌دار باشی."

    # say L884 lyd
    old "And it's so hard... really seen just this old boob make you so hard?"
    new "و همینجور سخت شده... واقعاً فقط این سینه قدیمی من رو اینقدر سخت کرده؟"

    # say L885 pla
    old "It was something instinctive, you know a natural reaction..."
    new "این یه واکنش طبیعی بود، می‌دونی مثل یه چیزی غریزی..."

    # say L886 lyd
    old "That is the most honest answer a woman can get from a man..."
    new "این بهترین پاسخ صادقانه‌ای است که یک زن از مرد می‌تواند بگیرد..."

    # say L887 lyd
    old "Thanks [pla], you really made me regain some self-esteem after the bad date I had with the other guy..."
    new "ممنون [pla]، تو واقعاً باعث شدی که من دوباره قدرت خودمو پیدا کنم بعد از آن روز بدی که با آن مرد داشتم..."

    # say L888 pla
    old "You have to know you are really beautiful and sexy, any man can see that, really."
    new "باید بدونی واقعاً زیبا و جذابی هستی، هر مردی اینو می‌بینه، واقعاً."

    # say L889 lyd
    old "Yeah, now I can see it..."
    new "بله، حالا می‌تونم ببینم..."

    # say L891 lyd
    old "Uhh... C- can I touch it?"
    new "اوه... می‌تونم لمسش کنم؟"

    # say L893 lyd
    old "I mean, I just want to see how hard you are, if you're really excited or if it's just barely."
    new "من فقط می‌خوام ببینم چقدر سختی، اگه واقعاً خوشحالی یا فقط یه کم."

    # say L894 pla
    old "And you can't tell just from seeing it?"
    new "و از دیدنش نمی‌تونی فهمید؟"

    # say L895 lyd
    old "You can't always know that from just looking."
    new "همیشه از فقط نگاه کردن نمی‌تونی اینو فهمید."

    # say L896 lyd
    old "It's always better to check with my own hands."
    new "همیشه بهتره با دست خودم بررسی کنم."

    # say L904 lyd
    old "Woah, you're really hard!"
    new "وای، تو واقعاً سختی!"

    # say L905 lyd
    old "And you're so big! This is impressive!"
    new "و تو هم خیلی بزرگی! این واقعاً مدهشه!"

    # say L915 lyd
    old "L-listen [pla]. I'm sorry. I didn't mean to do that when you got here."
    new "ب-bبین [pla]. خواهش می‌کنم. من قصد نداشتم وقتی اومدی اینجوری بشه."

    # say L916 lyd
    old "It's just that you've been so good to me, and I was feeling rather vulnerable."
    new "این فقط به این دلیل است که تو به من خیلی خوبی نشون دادی، و من حس ضعیفی داشتم."

    # say L917 lyd
    old "And seeing how hard you got because of me."
    new "و دیدن اینکه چقدر به خاطر من سخت شدی."

    # say L918 lyd
    old "But, I swear to God I didn't mean to..."
    new "ولی قسمت خدا من قصد نداشتم..."

    # say L919 pla
    old "Hey, hey, it's ok."
    new "بیا، بیا، خوبه."

    # say L920 pla
    old "No need for you to stress over this."
    new "نگران نباش، هر چیه."

    # say L921 pla
    old "I'm not angry with you. I understand."
    new "من با تو خشم ندارم. فهمیدم."

    # say L923 pla
    old "Yeah, I do, it's ok."
    new "بله، من هم، خوبه."

    # say L925 lyd
    old "Hmm, but maybe we should clean this up before we keep talking."
    new "Hmm، اما شاید باید اینجا رو پاک کنیم قبل از اینکه بیشتر صحبت کنیم."

    # say L931 lyd
    old "Thanks a lot for your help [pla]."
    new "ممنونم از کمکت [pla]."

    # say L932 lyd
    old "The truth is that what happened with that guy really affected me. I was feeling really down."
    new "حقیقتاً آنچه با آن مرد اتفاق افتاد واقعاً برایم تأثیر گذاشت. حس کردم خیلی ناراحت هستم."

    # say L933 lyd
    old "Thanks for helping me feel better."
    new "ممنونم که کمکت کردی من رو بهتر حس کنم."

    # say L934 pla
    old "No problem, I understand, that kind of thing can make you feel really bad."
    new "هیچ اشکالی ندارم، من درک می‌کنم، این جور چیزها می‌تونن باعث حس بد شدنت بشه."

    # say L935 pla
    old "I'm glad you're ok now."
    new "خوشحالم که حالا خوبی"

    # say L936 pla
    old "Now that I see you feel better, I think I should go home."
    new "الان که می‌بینم حالت بهتر شده، فکر می‌کنم باید برم خونه."

    # say L937 lyd
    old "Sure, no problem. Bye."
    new "بله، هیچ اشکالی نداره. خداحافظ."

    # say L955 pla
    old "Hey Lydia. How are you today?"
    new "هی لیدیا. امروز چطوری؟"

    # say L956 lyd
    old "Hi [pla]! Nice seeing you. You arrive just at the perfect time."
    new "سلام [pla]! خوشحالم که دیدم تو. وقتی هم درست رسیدی."

    # say L957 pla
    old "The perfect time? For what?"
    new "وقت مناسب؟ برای چه؟"

    # say L958 lyd
    old "You see, I've been talking to this new guy on Tinder, and the conversations have been going pretty well."
    new "دیدی، من با یه نفر جدید تو تایندر صحبت می‌کردم و همه چی خوب پیش می‌رفت."

    # say L960 lyd
    old "Yeah, it is."
    new "بله، هست."

    # say L961 lyd
    old "The thing is that he has been asking to see some pictures of me for a while..."
    new "البته، اونجوری که هست، او از یک مدت قبل درخواست کرده تا عکس‌های من رو ببینه..."

    # say L962 lyd
    old "And he has sent me a lot of pics, and the conversation is going really well, so, I want to send them to him a few ones."
    new "و او هم به من عکس زیادی ارسال کرده، و مکالمه ما خیلی خوب جلو می‌رود، پس می‌خوام بهش چند تا عکس بفرستم."

    # say L963 lyd
    old "But, to be honest, I don't really know what to send him."
    new "ولی، صادقانه بگم، نمی‌دونم چه عکس‌هایی باید بهش بفرستم."

    # say L964 lyd
    old "So, I think you could take some pictures of me so I can send him some good ones."
    new "پس فکر می‌کنم می‌تونی برای من چند عکس ببری تا بتونم چندتا خوب بهش بفرستم."

    # say L966 lyd
    old "So, what do you say? Do you think you can do it?"
    new "پس، چه می‌گی؟ فکر می‌کنی می‌تونی این کار رو بکنی؟"

    # say L967 pla
    old "Hmm, sure, I guess I can."
    new "Hmm، مطمئناً، فکر کنم می‌تونم."

    # say L975 lyd
    old "Ok, I think something casual, like this, what do you think?"
    new "خب، فکر کنم چیزی آسان مثل این، چطور به نظرت می‌رسه؟"

    # say L976 pla
    old "It looks great!"
    new "عالیه!"

    # say L987 lyd
    old "But it's ok, take it, if you like it I think he will too."
    new "ولی خوبه، بگیر، اگر تو دوست داشته باشی فکر کنم او هم دوست داشته باشه."

    # say L997 lyd
    old "Is it ok? Do you like it?"
    new "آیا خوبه؟ دوست داری؟"

    # say L998 pla
    old "Yeah, I think it looks very good."
    new "بله، فکر کنم خیلی خوب به نظر می‌رسه."

    # say L999 lyd
    old "Great! So, next one."
    new "عالی! پس، بعدی."

    # say L1006 lyd
    old "Ok, for this one I want to try something a little hotter."
    new "باشه، برای این تاش کاری گرم‌تر می‌تونم انجام بدم."

    # say L1007 lyd
    old "Does my ass look good enough?"
    new "آیا پشت من خوب به نظر می‌رسه؟"

    # say L1008 pla
    old "Sure, I think it looks great."
    new "بله، فکر کنم خیلی خوب هست."

    # say L1026 lyd
    old "Do I look fat? What do you think? Do you like that one?"
    new "من چرب می‌تونم باشم؟ فکرتون چیه؟ آن یکی رو دوست دارید؟"

    # say L1027 pla
    old "Don't worry, I think you look just perfect."
    new "نگران نباش، فکر کنم تو فقط کاملی هستی."

    # say L1028 lyd
    old "Great, I've got an idea for the next one."
    new "عالی، یه ایده برای بعدی دارم."

    # say L1036 lyd
    old "Ha! I knew it, you men and breasts, I don't know why you're so crazy about them."
    new "حاحا! این رو می‌دونستم، شما مردان و سینه‌ها، نمی‌دونم چرا ازشون همینقدر خوشحال می‌شید."

    # say L1039 lyd
    old "The truth is, he's already sent me a couple of pictures of himself."
    new "حقیقت اینه که قبلاً چند عکس از خودش به من فرستاده."

    # say L1040 lyd
    old "And some of those are actually very spicy."
    new "و بعضی از اونا واقعاً تند و خوشحالم کنن."

    # say L1041 lyd
    old "So, I thought that maybe I could send him some like that too."
    new "پس فکر کردم شاید بتونم همچین عکس‌هایی بهش بفرستم."

    # say L1043 pla
    old "I- I think it's great."
    new "من فکر می‌کنم عالیه."

    # say L1044 lyd
    old "Yeah, I can see that. Fufu."
    new "بله، من هم می‌تونم ببینم. فوفو."

    # say L1046 lyd
    old "Anyway, take the picture."
    new "بگیر عکسشو."

    # say L1052 lyd
    old "So how does the picture look?"
    new "عکس چطوره؟"

    # say L1053 pla
    old "Very well I think."
    new "من فکر می‌کنم خوب است."

    # say L1054 lyd
    old "And my breasts? They don't look soggy or wrinkled?"
    new "و سینه‌های من؟ آب‌دهیده یا شورده نیستن؟"

    # say L1055 pla
    old "No, no, they look great as well."
    new "نه، نه، آنها هم خوب هستند."

    # say L1056 lyd
    old "That's great, I'm glad that's how it is."
    new "عالی، خوشحالم که اینجوری هست."

    # say L1063 lyd
    old "That was very good [pla], thank you."
    new "این خیلی خوب بود [pla]، ممنون."

    # say L1064 pla
    old "It's ok, happy to help."
    new "خوشحالم که کمک کردم، هیچ اشکالی نداره."

    # say L1065 lyd
    old "I hope he likes the pictures."
    new "امیدوارم عکس‌ها رو دوست داشته باشه."

    # say L1066 pla
    old "I'm sure he will, you look great, don't worry."
    new "مطمئنم خوشحال می‌شه، تو خیلی خوبت، نگران نباش."

    # say L1067 lyd
    old "Well thank you, that's very sweet of you."
    new "ممنون، خیلی لطف داری."

    # say L1068 lyd
    old "I believe you this time."
    new "من این بار به تو باور می‌کنم."

    # say L1069 lyd
    old "After all, I can see it this time."
    new "البته، این بار می‌تونم ببینم."

    # say L1071 pla
    old "Sorry, it's just that you took your shirt off all of a sudden."
    new "ببخشید، فقط اینکه ناگهان پولوتو برداشتی."

    # say L1073 lyd
    old "It's ok, don't worry, I actually like to see that reaction."
    new "باشه، نگران نباش، در واقع خوشحالم که این واکنش رو می‌بینم."

    # say L1074 lyd
    old "I think it's very flattering."
    new "من فکر می‌کنم این خیلی لطف‌آمیز است."

    # say L1075 lyd
    old "To see such a young man get so hard because of me, I can never get tired of it."
    new "دیدن اینکه چه جوانی به خاطر من اینقدر سخت می‌شود، هرگز خسته نمی‌شوم."

    # say L1076 lyd
    old "In fact, how about I help you with that? I know it can take a while for your dick to calm down."
    new "در واقع، چطور این کار رو به تو کمک کنم؟ می‌دونم می‌تونه طول بکشه تا ناخودت آرام شه."

    # say L1077 pla
    old "You don't really have to do it."
    new "تو واقعاً نمی‌تونی این کار رو بکنی."

    # say L1078 lyd
    old "Well, you helped me with the pictures, it's fine if I help you back. Don't you think?"
    new "خب، تو به من در مورد عکس‌ها کمک کردی، من هم به تو کمک کنم. نمی‌فکری خوبه؟"

    # say L1079 lyd
    old "And to be honest, doing these photos made me a bit horny..."
    new "و صداقت بگم، این عکس‌ها من رو یه کم خیالی کردند..."

    # say L1081 lyd
    old "Now come, let me help you."
    new "الان بیا، بگذار من به تو کمک کنم."

    # say L1088 lyd
    old "I didn't notice last time, but your dick has a great smell."
    new "پشیمانته آخرت متوجه نشدم، ولی لخت تو خوشبویی خوبی داره."

    # say L1089 lyd
    old "And I can't believe how hard you get."
    new "و نمی‌تونم باور کنم چقدر سخت می‌شه."

    # say L1090 lyd
    old "Young men are amazing."
    new "پسران جوان شگفت‌انگیز هستند."

    # say L1091 lyd
    old "It's sooo big too."
    new "این هم خیلی بزرگه."

    # say L1092 lyd
    old "Honestly I'm not sure it will fill all in my mouth."
    new "من صادقانه مطمئن نیستم که همه جا در دهانت وارد بشه."

    # say L1093 lyd
    old "But don't worry, I'll make sure you finish in a moment."
    new "ولی نگران نباش، مطمئن می‌شوم که تو لحظه‌ای تمام می‌شوی."

    # say L1104 pla
    old "Well, I think I should go home."
    new "خب، فکر کنم باید برم خانه."

    # say L1105 lyd
    old "Sure thing, thanks again for the pictures. I'll let you know if he likes them."
    new "بازهم ممنون از عکس‌ها. اگر لایکش کرد، بهت می‌گم."

    # say L1126 ann
    old "I mean, what the fuck mom?! What the actual fuck?!"
    new "من می‌گم، چه خربه مامان؟! چه خربه واقعی؟!"

    # say L1127 ann
    old "Now you're coming home late? JESUS!"
    new "الان هم دیر می‌آیی؟ خدایی!"

    # say L1128 ann
    old "After all those times you scolded me for doing it when I was a teenager. And not only that, but I'm sure you were on a date with someone."
    new "بعد از همه آن بارها که تو من رو به خاطر همین توی دوران نوجوانی تنبیه می‌کردی. و نه فقط این، بلکه مطمئنم که تو با کسی دیت می‌زدی."

    # say L1129 ann
    old "I imagine it was some guy you must've met there. What's wrong with you?"
    new "من فکر می‌کنم یه مردی بود که تو اونجا باهاش ملاقات کردی. تو چطوری؟"

    # say L1130 ann
    old "Don't you realize you're too old to be going out with guys like those?"
    new "می‌دونی خودت بزرگ‌سالی هستی تا با آدمای اون جوری بروی؟"

    # say L1132 lyd
    old "Why are you so angry?"
    new "چرا اینقدر خشمگینی؟"

    # say L1133 lyd
    old "I get that I forgot to tell you I was going out last night, but that's no reason to be acting like this."
    new "می‌دونم که فراموش کردم برات بگم دیروز بیرون رفتم، اما این هیچ دلیلی برای اینکه اینجور رفتار می‌کنی نیست."

    # say L1134 lyd
    old "Listen, your mother is a mature woman, and I have every right to go out and date anyone I want to."
    new "بله، مادرت زن بزرگسالیه و من حق دارم بیرون برسم و با هر کسی که می‌خوام رابطه داشته باشم."

    # say L1136 ann
    old "I DON'T GIVE A FUCK!"
    new "من فریک نمی‌دم!"

    # say L1137 ann
    old "I just don't want to go around picking up random dudes that you find on the street!"
    new "من فقط نمی‌خوام بیرون برسم و مردان تصادفی رو که توی خیابون می‌بینم جمع کنم!"

    # say L1138 ann
    old "I mean, what's everyone going to think? That you're just some whore looking for dick!"
    new "من می‌گم، همه چی می‌فکرند؟ که تو فقط یه دختر سرپرده‌ای هستی که به دنبال شاخ‌زدن می‌گردی!"

    # say L1139 ann
    old "They would be right by the way! Because that's what you're acting like!!!"
    new "درست هست! زیرا همینطور عمل می‌کنی!"

    # say L1142 ann
    old "Ugh! I'm so mad mom! I swear to god!"
    new "اوه! خیلی غصب دارم مامان! قسمت خدا می‌خورم!"

    # say L1143 ann
    old "You know what? I won't keep talking about this!"
    new "میدونی چی؟ من دیگه در این مورد حرف نمی‌زنم!"

    # say L1144 ann
    old "I'm out of here!"
    new "من از اینجا برمی‌گردم!"

    # say L1158 lyd
    old "Oh [pla], hi. How are you?"
    new "اوه ز[pla]، سلام. چطوری؟"

    # say L1159 pla
    old "Never mind me, how about you? What was Anna mad about this time?"
    new "به من نگاه نکن، تو چطوری؟ این بار آنا چرا خسته شد؟"

    # say L1160 lyd
    old "Well, remember the guy that we took the pictures for?"
    new "خب، به خاطر داری آن مردی که عکس‌هایش رو گرفتیم؟"

    # say L1163 lyd
    old "Well, we went out on a date, and we ended up staying out until very late, and Anna noticed it."
    new "خب، ما روزی روزی رفتیم و تا خیلی شبانه‌روز خارج بودیم و آننا این موضوع رو متوجه شد."

    # say L1164 lyd
    old "As you can see, she's not too thrilled about it."
    new "همانطور که می‌بینی، او خوشحال نیست."

    # say L1165 pla
    old "Yeah, I caught that she's not too happy about the situation."
    new "بله، متوجه شدم که او خوشحال نیست از این وضعیت."

    # say L1166 pla
    old "But so what? You're a grown woman, and she can't be telling you what to do or not."
    new "ولی چه کاری؟ تو یه زن بزرگ هستی و نمی‌تونه به تو بگه که باید چی کنی یا نکنی."

    # say L1167 lyd
    old "I don't know, lately I've been thinking that she may be right and that I'm actually acting like a whore."
    new "نمی‌دونم، اخیرا فکر می‌کنم ممکنه هم درسته و من واقعاً مثل یه زن سفه‌باز رفتار می‌کنم."

    # say L1168 pla
    old "Whoah, whoah, whoah."
    new "وای، وای، وای."

    # say L1169 pla
    old "No, no, let's not go there."
    new "نه، نه، بیای دیگه اینجا نبریم."

    # say L1170 pla
    old "Listen, Anna's just angry, and since she's such a hothead she doesn't know how to deal with it."
    new "بله، آنا فقط خشمگینه و چون اینقدر سرسریه نمی‌دونه چهارش رو چطور مدیریت کنه."

    # say L1171 pla
    old "All she knows is how to get angry, scream and be cruel. Don't pay any attention to what she says, ok?"
    new "همه‌چیزی که می‌دونه اینه که خشم بره، صدا بزنه و بد باشه. به حرف‌هایش توجه نکن، خب؟"

    # say L1173 lyd
    old "Ok, I guess you have a point."
    new "باشه، به نظر می‌رسه دلتنگت درسته."

    # say L1175 pla
    old "Now, tell me how your night went."
    new "خب، بگو چطور شبتو بود؟"

    # say L1176 pla
    old "It sounds like it was a very good time."
    new "به نظر می‌رسه وقت خوبی بود."

    # say L1177 lyd
    old "Hmm, yeah, I guess so..."
    new "Hmm، بله، حدس زدم..."

    # say L1178 pla
    old "Yeah? Because you don't look very excited about it."
    new "بله؟ چون نگاهت خوشحال نیست."

    # say L1179 lyd
    old "Well... you see."
    new "خب... می‌بینی."

    # say L1180 lyd
    old "The date went well, he was a perfect gentleman, and I think we had a lot of chemistry. He actually said he wanted to see me again soon."
    new "تاریخ ما خوب بود، او رفتار احترام‌آمیزی داشت، و فکر می‌کنم ما هم‌دیگر همپوشانی زیادی داشتیم. او در واقع گفت که می‌خواست به زودی دوباره من رو ببینه."

    # say L1181 lyd
    old "But that got me thinking, with the way things are going, that we could end up having sex next time."
    new "ولی این همه من رو به فکر آورد که با توجه به نحوه پیشرفت رابطه، ممکنه دفعه بعد جنس کنیم."

    # say L1182 pla
    old "Well, yeah, that's usually how those things go."
    new "بله، همینجور معمولاً می‌شه."

    # say L1183 pla
    old "You don't want to?"
    new "تو نمی‌خوای؟"

    # say L1184 lyd
    old "It's not that, I obviously want to."
    new "این همچین نیست، من حتماً می‌خوام."

    # say L1185 lyd
    old "The problem is that it's been a while since I had sex for the last time."
    new "مشکل اینه که از آخر باری که جنس کردم مدت زیادی گذشته."

    # say L1186 lyd
    old "Even with my deceased husband, the last few years of our relationship we barely had any contact."
    new "حتی با همسرم مرده، در سال‌های آخر رابطه‌ی ما تقریباً هیچ تماسی نداشتیم."

    # say L1187 lyd
    old "I'm afraid that I'm not gonna be good enough or that I'll end up disappointing him."
    new "می‌تونم خوب نباشم یا اونجا بیافتم که او راضی نمی‌شه."

    # say L1188 lyd
    old "After all this time it's a lot of pressure you know?"
    new "بعد از همه این زمان، فشار خیلی زیادی هست، می‌دونی؟"

    # say L1189 lyd
    old "Especially since I'm not sure he'll like my body."
    new "به خصوص اینکه مطمئن نیستم او بدنم رو پسنده."

    # say L1190 lyd
    old "What if he thinks that I'm too old? or that I'm not hot enough?"
    new "اگه فکر کنه من خیلی قدیمی هستم؟ یا اینکه خوب نیستم؟"

    # say L1191 pla
    old "What? Not at all!"
    new "چه؟ هیچ!"

    # say L1192 pla
    old "Don't even think about it. That guy has already seen pictures of you, and if he says that you're hot, you should believe him."
    new "فکر نکن. اون دستا قبلاً عکس‌هایت رو دیده، و اگه می‌گه که خوبی، باید باورش کنی."

    # say L1193 pla
    old "Everything is gonna be fine, believe me."
    new "همه چیز خوب می‌شه، باور کن."

    # say L1194 lyd
    old "Ok, I'll stop worrying about it. Thanks again [pla], I don't know what I would do without all your help."
    new "باشه، دیگه نگرانش نمی‌شوم. مجدد ممنون [pla]، نمی‌دونم بدون کمکت چی می‌کردم."

    # say L1196 pla
    old "Don't even mention it."
    new "نه، اصلاً به ذهنم نمی‌رسه."

    # say L1197 pla
    old "Hmmm."
    new "Hmm."

    # say L1198 pla
    old "So, since I'm already here, do you want us to browse through some tinder profiles?"
    new "پس، چون قراره اینجا برم، می‌خوای یه چند پروفایل تایندر بررسی کنیم؟"

    # say L1200 lyd
    old "I don't really feel like doing that right now, besides, since Anna is in her room she could come down any second."
    new "الان خیلی هم تمایلی به این کار ندارم، علاوه بر این، چون آنا تو اتاقش هست می‌تونه هر لحظه بیاد پایین."

    # say L1201 lyd
    old "I don't want to have to deal with her temper again today."
    new "امروز دوباره نمی‌خوام با خشم‌الله‌اش سر کار داشته باشم."

    # say L1202 pla
    old "I understand, then I guess it's better if I leave."
    new "من متوجهم، پس به نظر می‌رسه بهتره من برسم."

    # say L1203 pla
    old "But before I go, remember what I told you."
    new "اما قبل از برخاستن، به خاطر داشته باش چیزی که به تو گفتم."

    # say L1204 pla
    old "You're a beautiful woman, and you're in your right to be or date anyone."
    new "تو یک زن زیبا هستی و حق داری با هر کسی که می‌خوای رابطه داشته باشی."

    # say L1205 pla
    old "No matter what Anna thinks about that. She can keep her opinions to herself."
    new "با این حالات آنایا همچنین. می‌تونی نظرش رو برای خودت بگه."

    # say L1206 lyd
    old "Thank you [pla] I'll be sure to remember that."
    new "ممنون [pla] حتماً این رو به یاد خواهم گذاشت."

    # say L1207 pla
    old "That's cool, goodbye then."
    new "خوب، خداحافظ بعد."

    # say L1226 lyd
    old "Hi [pla], I guess I'm fine, thank you."
    new "سلام [pla]، به نظر می‌رسه خوبم، ممنون."

    # say L1227 pla
    old "You guess? What happened?"
    new "گیس؟ چه اتفاقی افتاد؟"

    # say L1228 lyd
    old "Oh [pla], it's just so bad..."
    new "اوه ز[pla]، فقط خیلی بده..."

    # say L1229 pla
    old "What's bad? You're worrying me now, tell me."
    new "چه چیزی بد است؟ حالا من رو نگران کردی، بگو."

    # say L1231 lyd
    old "Well, the thing is that I did go on that date with the guy I told you about."
    new "خب، اونجوری که می‌دونی من با آن مردی که به تو گفتم رفتیم."

    # say L1232 lyd
    old "I suppose it went well, just like last time he was a gentleman, the conversation was good and we had a good time."
    new "باید خوب بوده، مثل آخر هم او آقایی بود، صحبت‌هامون خوب بود و وقت خوبی گذرونده."

    # say L1233 lyd
    old "The problem came later... when we were about to have sex."
    new "مشکل بعداً پیش اومد... وقتی می‌خواستیم جنس کنیم."

    # say L1234 pla
    old "Ohh... Why?"
    new "اوه... چرا؟"

    # say L1235 lyd
    old "Well, after dinner he asked me if I wanted to continue the evening at his house, I said yes and we went there."
    new "خب، بعد از شام از من پرسید که آیا می‌خوام به خونه‌اش برم، من هم بله گفتم و رفتیم."

    # say L1236 lyd
    old "I really wanted to do it, and things were going so well..."
    new "من واقعاً می‌خواستم انجام بدم، و همه چیز خیلی خوب پیش می‌رفت..."

    # say L1237 lyd
    old "But, I just couldn't do it... I got nervous and uncomfortable."
    new "ولی، نتونستم انجام بدم... خیلی ناراحت و حواس پرت شدم."

    # say L1239 pla
    old "Was it something he did?"
    new "آره، اونجوری که می‌گی، مشکل از او نبود."

    # say L1241 lyd
    old "Oh no, nothing like that, he was actually very nice, as I said, a perfect gentleman."
    new "نه، هیچ ارتباطی به اون نداشت، او در واقع خیلی لطف داشت، همانطور که گفتم، یک آقای شایسته بود."

    # say L1242 lyd
    old "I was the one with the problem, no matter what we tried all I could think was about my husband, and Anna's words."
    new "من بودم که مشکل داشتم، هر چه امتحان می‌کردیم من فقط به مردمو و کلمات آنا فکر می‌کردم."

    # say L1243 lyd
    old "Telling me that I was ugly and undesirable, that what I was doing was wrong."
    new "به من می‌گفت که من قبیح و غیرقابل تمایل هستم، که آنچه می‌کنم اشتباه است."

    # say L1244 lyd
    old "After a while, I just backed out and asked him to drive me home."
    new "بعد از یک段时间，我只是退出了，让他开车送我回家。"

    # say L1245 lyd
    old "After all I think Mrs. Jones was right, at my age it's just impossible for me to form a connection with another person."
    new "البته فکر می‌کنم خانم جونز درست می‌گفت، در سن من امکان‌پذیر نیست که با شخص دیگری ارتباط برقرار کنم."

    # say L1246 lyd
    old "I think I should just give up and become a church lady like her."
    new "فکر کنم باید این کار رو بگذaram و مثل او یه خانم کلیسا بشم."

    # say L1247 pla
    old "Wait, wait, don't say that."
    new "بیا، بیا، نگو اینجوری."

    # say L1248 pla
    old "Listen, what you went through is perfectly normal, you don't need to beat yourself over it."
    new "بله، آنچه تجربه کردی کاملاً طبیعیه، نباید خودت رو به هم زنی."

    # say L1249 pla
    old "Sure it would be good if you could have sex with the guy."
    new "البته، اگر بتونی با اون مرد جنسیت کنی خوبه."

    # say L1250 pla
    old "But think about it, you were out of the dating game for a long time, it's ok to feel insecure."
    new "اما فکر کن، تو خیلی زمانی توی بازار روابط عاشقانه نبودی، حس ناامنی کردن هم طبیعیه."

    # say L1251 pla
    old "There's no need for you to feel that you're going to become someone like Mrs. Jones."
    new "نیازی نیست احساس کنی مثل خانم جونز می‌شی."

    # say L1252 lyd
    old "That's very cute of you, but [pla] I don't know, it's just too difficult."
    new "این خیلی لطف داری، اما [pla] نمی‌دونم، فقط خیلی سخته."

    # say L1254 pla
    old "It is, but that doesn't mean you should give up, or pay any attention to what Anna says."
    new "بله، اما این به معنای این نیست که باید تسلیم شوی یا به آنچه安娜 می‌گوید توجه کنی."

    # say L1255 pla
    old "Listen, you're doing this for yourself, not for Anna, or your husband or anyone else, just for you."
    new "بله، این برای خودت هست، نه برای آنا یا شوهرت یا هر کس دیگر، فقط برای خودت."

    # say L1256 pla
    old "You have every right to be happy and to search for that happiness."
    new "تو هر حقی برای خوشحال شدن و جستجوی آن خوشحالی داری."

    # say L1257 pla
    old "So, there's no need for you to feel guilty about living your life."
    new "پس، هیچ دلیلی برای احساس گناهکاری در زندگی کردن نداری."

    # say L1258 lyd
    old "I understand what you're saying, but I don't know how to do it."
    new "من متوجه هستم چه می‌گی، اما نمی‌دونم چطور باید این کار رو انجام بدم."

    # say L1259 lyd
    old "How do I manage to do it when I feel so uncomfortable?"
    new "من چطور باید این کار رو انجام بدم وقتی اینقدر ناراحت هستم؟"

    # say L1260 lyd
    old "I wasn't able to even get naked!"
    new "من حتی نتونستم خودمو عریان کنم!"

    # say L1261 lyd
    old "I can't imagine even trying to be even more intimate in a physical way."
    new "من نمی‌تونم حتی فکر کنم که چطور می‌تونم در تماس‌های جسمی بیشتر پیش برسم."

    # say L1263 pla
    old "Hmm... It's just you haven't done it in a long time, you're a bit... Rusty..."
    new "Hmm... فقط اینه که تو خیلی وقتی این کار رو نکردی، یه کم... خسته‌ای."

    # say L1264 lyd
    old "But how do I fix it? How can I ever be able to have some sexual contact again?"
    new "ولی چطور می‌تونم این مشکل رو حل کنم؟ چطور می‌تونم دوباره تماس جنسی داشته باشم؟"

    # say L1266 pla
    old "Wait... What about me?"
    new "پیش... من چطور؟"

    # say L1269 pla
    old "Well, you say that, but you've been able to do a few sexual things with... me."
    new "خب، اینجوری می‌گی، ولی چند تا از چیزهای جنسی رو با... تو انجام دادی."

    # say L1270 lyd
    old "Oh... Yeah well, that's different."
    new "اوه... بله، اما اون جوری هست."

    # say L1273 lyd
    old "I don't know... with you it doesn't feel like I'm doing some weird thing with a stranger, you just feel... safer."
    new "نمی‌دونم... با تو احساس نمی‌کنم که چیز عجیبی با یه ناشناخته انجام میدم، تو فقط... امن‌تر احساس می‌شی."

    # say L1274 lyd
    old "With this other guy I felt very awkward like we didn't have a bond, or anything connecting us."
    new "با اون دیگه‌ی پسر حس کردم خیلی غیرطبیعی بود، مثل اینکه هیچ ارتباطی بین ما نبود."

    # say L1275 pla
    old "Hmph, I think I get what you're saying."
    new "همف، فکر کنم متوجه هستم چه می‌گی."

    # say L1277 lyd
    old "Oh, I have an idea."
    new "اوه، یه ایده دارم."

    # say L1280 lyd
    old "I think that my problem might be taking that first step to physical intimacy. That's what's holding me back."
    new "فکر می‌کنم مشکلم اینه که اون قدم اول برای ارتباط جسمی رو نمی‌گیرم. این همینه که من رو متوقف می‌کنه."

    # say L1281 lyd
    old "It's just as you said, I'm rusty, so, maybe I just need a bit of practice?"
    new "همینطوری که گفتی، من خیلی ریز و خسته‌ام، پس شاید فقط نیاز به تمرین داشته باشم؟"

    # say L1282 pla
    old "Practice?"
    new "تمرین؟"

    # say L1283 lyd
    old "I think that if I do it with someone at least once, from there on it should be a lot easier with other guys."
    new "من فکر می‌کنم اگه یه بار با کسی انجام بدم، از آن جا به بعد با سایر پسران خیلی راحت‌تر می‌شه."

    # say L1285 pla
    old "Ohh, I get it... Well, that makes a lot of sense. I think you're right."
    new "اوه، متوجه شدم... خب، این جوری هم خیلی منطقیه. فکر کنم درست می‌گی."

    # say L1286 pla
    old "But who are you gonna do it with first?"
    new "ولی اول با کی می‌تونی این کار رو بکنی؟"

    # say L1287 lyd
    old "Well... so far there's only one man I think I feel comfortable enough to do it with."
    new "خب... تا حالا فقط یک مرد وجود داره که فکر می‌کنم با او آماده‌ام این کار رو انجام بدم."

    # say L1288 pla
    old "And who is it?"
    new "و اون کیه؟"

    # say L1289 pla
    old "Oh wait, you don't mean... me?!"
    new "اوه، بی‌خیال، منظورت... من هستم؟!"

    # say L1290 lyd
    old "What can I tell you? As you've seen you're the only one with which I've been able to do anything without feeling weird."
    new "من چه بگم؟ همانطور که دیدی تو تنها کسی هستی که باهام این کار رو انجام می‌دهیم بدون اینکه عجیب و غریب برایم بیاد."

    # say L1291 pla
    old "B- but you know."
    new "ب- ولی تو می‌دونی."

    # say L1293 lyd
    old "I know, it sounds crazy, and maybe I'm just saying this impulsively, but this wouldn't be the first time we do something of the sort."
    new "می‌دونم، خیلی عجیب به نظر می‌رسه، و شاید فقط به طور ضرب‌الامثال اینجوری می‌گم، اما این نخستین باری نیست که چیزی از این جوری با هم انجام میدیم."

    # say L1294 lyd
    old "And I think that I wouldn't have any problem if it were you, I'm clearly comfortable with you...."
    new "و فکر می‌کنم اگه تو بودی، مشکلی نداشتم، واضحه که با تو راحتم."

    # say L1295 pla
    old "B- but, that would be way too far over the line!"
    new "B- بله، اما این خیلی خیلی دور از خط است!"

    # say L1296 lyd
    old "You are right... I better stop this and settle down."
    new "درست می‌فرمایی... بهتر است اینجا متوقف شوم و آرامش بیاورم."

    # say L1297 pla
    old "No, no, it's not about that."
    new "نه، نه، این به همین معنی نیست."

    # say L1298 pla
    old "It's just that the solution sounds way too drastic."
    new "فقط اینجاست که راه‌حل خیلی شدید به نظر می‌رسه."

    # say L1299 pla
    old "Why don't you try other solutions first? Going to therapy, or maybe trying with some other dude..."
    new "چرا اول سایر راه‌حل‌ها رو امتحان نمی‌کنی؟ مثلاً رفتنت به درمان یا شاید با یه نفر دیگه امتحان کنی..."

    # say L1300 lyd
    old "Oh please, you know that's not going to help me!"
    new "لطفاً، می‌دونی این کار به من کمک نمی‌کنه!"

    # say L1301 lyd
    old "Besides, this isn't easy for me either."
    new "البته، این برای من هم آسان نیست."

    # say L1302 lyd
    old "Just imagine how embarrassing it would be to keep trying with one and another person without managing to do anything."
    new "فقط فکر کن چقدر خجلت‌آور است که با یک نفر و بعد از آن با نفر دیگری تلاش کنی و هیچ کاری انجام ندهی."

    # say L1304 lyd
    old "It's not like I want my life to be in shambles like this, you know [pla]?"
    new "مثلاً من نمی‌خوام زندگی‌ام اینجوری در هم بیافتد، دیگه [pla]؟"

    # say L1305 lyd
    old "All I'm telling you is that I'm trying to put my life back together so that I don't end up like Mrs. Jones."
    new "من فقط می‌گم که سعی می‌کنم زندگیم رو مرتب کنم تا مثل خانم جونز نشوم."

    # say L1306 lyd
    old "Won't you help me with that?"
    new "می‌تونی به من در این مورد کمک کنی؟"

    # say L1307 lyd
    old "After all, it would just be this one time, just so that I get used to it again."
    new "البته، فقط این باره، فقط برای اینکه دوباره به آن عادت کنم."

    # say L1308 pla
    old "Hmm, I suppose what you're saying makes sense."
    new "هم، فکر کنم چیزی که می‌گی برات معنی داره."

    # say L1309 pla
    old "I'm not sure I like this, but ok, I suppose we can do it."
    new "مطمئن نیستم که خوشحالم از این، ولی بله، فکر کنم می‌تونیم اینجوری کنیم."

    # say L1310 lyd
    old "Really? Thank you so much [pla]!"
    new "حقاً؟ ممنونم خیلی [pla]!"

    # say L1312 lyd
    old "Don't worry just lie on the couch and leave everything to me!"
    new "نگران نباش، فقط روی میز دراز شو و همه چیز رو به من بسپر."

    # say L1327 pla
    old "I think the best thing is that I go for today."
    new "من فکر می‌کنم بهتره امروز برسم."

    # say L1328 pla
    old "Are you going to keep talking with the guy?"
    new "تو قراره با اون دستورالعمل هم بگپ؟"

    # say L1329 lyd
    old "I will, I really like him, so, I hope we can have another date."
    new "من خواهم گفت، واقعاً دوستش دارم، پس امیدوارم بتونیم دوباره همراهی کنیم."

    # say L1330 lyd
    old "And this time I'm sure everything will go well."
    new "و این بار مطمئن هستم همه چیز خوب پیش می‌رود."

    # say L1331 pla
    old "I'm sure it will, good luck."
    new "مطمئنم همه خوب می‌شه، موفق باش."

    # say L1350 lyd
    old "Oh hi [pla]! It's good seeing you."
    new "اوه سلام [pla]! خوشحالم که دیدمت."

    # say L1352 lyd
    old "I'm fine thanks for asking!"
    new "خوبم، ممنون که پرسیدی!"

    # say L1353 pla
    old "Great, so tell me, everything went well on your date, right?"
    new "عالی، پس بگو، همه چیز در تاریخت خوب پیش رفت، درسته؟"

    # say L1354 lyd
    old "Oh, that? Not at all!"
    new "اوه، آن؟ هیچ!"

    # say L1355 pla
    old "What's with that face?"
    new "چرا چهره‌ت اینجوریه؟"

    # say L1356 pla
    old "Don't tell me things went wrong again on your date."
    new "بگو نه، دوباره هم چیزی اشتباه شده در تاریخت."

    # say L1357 lyd
    old "Ugh. Then I don't know what else to tell you."
    new "اوه. پس نمی‌دونم چی دیگه برات بگم."

    # say L1360 lyd
    old "Nothing happened, that's the problem."
    new "هیچ چیز اتفاق نیوفت، این هم مشکل است."

    # say L1361 pla
    old "Nothing? Nothing at all?"
    new "هیچی؟ هیچی هم نه؟"

    # say L1362 lyd
    old "Well, yes..."
    new "خب، بله..."

    # say L1363 lyd
    old "Oh [pla], that was so frustrating"
    new "اوه ز[pla]، اینقدر ناراحت‌کننده بود."

    # say L1364 pla
    old "But why?"
    new "ولی چرا؟"

    # say L1366 lyd
    old "I don't know, the date went well, he was as well behaved as always, but when the moment came I just felt that I couldn't do it."
    new "نمیدونم، روز ملاقات خوب بود، او هم مثل همیشه خوب رفت، ولی وقتی لحظه رسید فقط احساس کردم نمی‌تونم این کار رو بکنم."

    # say L1368 pla
    old "But, I thought you had gotten over your intimacy problem, that's why we did what we did, right?"
    new "ولی فکر کردم مشکل اینتیمیتت رو حل کردی، برای همین هم کاری کردیم که باید کردیم، درسته؟"

    # say L1369 lyd
    old "Yeah, yeah, and I think it did help. After all, this time I wasn't scared or feeling bad or anything."
    new "بله، بله، و فکر می‌کنم کمک کرد. این بار هیچ جور ترسی یا حس بدی نداشتم."

    # say L1370 lyd
    old "I just didn't want him to put his hands on me, I don't know, I guess we just didn't have any sexual attraction."
    new "من فقط نمی‌خواستم دست‌اش رو به من بگذونه، نمی‌دونم، شاید ما جذابیت جنسی نداشتیم."

    # say L1371 lyd
    old "You have no idea how annoyed I am because of that."
    new "تو هیچ ایده‌ای نداری چقدر از این خسته شدم."

    # say L1372 pla
    old "Hmm, well, if you say that you didn't feel bad or scared, I guess that's a good thing."
    new "Hmm، خب، اگر می‌گی‌ای که نمی‌تونستی بد یا ترسناک بود، حدس می‌زنم این یه چیز خوبه."

    # say L1373 pla
    old "Those things happen."
    new "این‌جوری چیزها می‌افتد."

    # say L1374 lyd
    old "I'm still very frustrated though."
    new "اگرچه هنوز خیلی ناراحت هستم."

    # say L1375 lyd
    old "But I understand that the problem wasn't me, I think the problem was that I didn't like him enough."
    new "ولی من متوجه شدم که مشکل از من نبود، فکر کنم مشکل این بود که من به اندازه کافی به او علاقه نداشتم."

    # say L1377 pla
    old "Hmph, if you say so."
    new "همف، اگه می‌گی."

    # say L1378 lyd
    old "Oh, don't be mad, at least I'm not feeling bad about it."
    new "او، نباشی خسته، حداقل من در موردش احساس بد نمی‌کنم."

    # say L1379 lyd
    old "Just a little bit annoyed."
    new "فقط یه کم خسته‌ام."

    # say L1380 pla
    old "I guess we can call that a silver lining..."
    new "بازهم یه نکته مثبت پیدا کردی..."

    # say L1381 pla
    old "But if that's not the thing that has you in a good mood, what is it?"
    new "اما اگر اون چیزی که خوشحالی رو باعث نشده، چیزی دیگه چیه؟"

    # say L1382 lyd
    old "Right, that!"
    new "درسته، اون!"

    # say L1383 lyd
    old "I've been talking to another guy, and actually, things seem to be going well."
    new "من با یه دستاگاه دیگه حرف زدم، و در واقع، به نظر می‌رسه که خوب هم می‌ریم."

    # say L1384 lyd
    old "We haven't met, but I really like his personality."
    new "ما هنوز ندیده‌ایم، اما واقعاً شخصیت‌اش رو دوست دارم."

    # say L1385 pla
    old "That's cool."
    new "این خوبه."

    # say L1387 lyd
    old "Hmm, in fact, I think you could help me out with that."
    new "Hmm، در واقع فکر می‌کنم می‌تونی به من کمک کنی با این."

    # say L1388 pla
    old "Help you?"
    new "می‌تونم به تو کمک کنم؟"

    # say L1389 lyd
    old "Yeah, to talk to him, just before you arrived we were in the middle of a conversation."
    new "بله، باهاش صحبت کن، وقتی اومدی ما در وسط یه مکالمه بودیم."

    # say L1390 lyd
    old "I think you could help me chat with him."
    new "فکر می‌کنم می‌تونی به من کمک کنی تا باش حرف بزنم."

    # say L1391 pla
    old "Hmm, I don't know... I mean, if you've been talking with these guys I think you can keep up the conversation without my help."
    new "Hmm، نمی‌دونم... منظورم اینه که اگه با این جون‌ها صحبت می‌کردی، فکر کنم بدون کمک من هم می‌تونی صحبت رو ادامه بدی."

    # say L1392 lyd
    old "Oh, don't say that, you are really a great help to me."
    new "اوه، نگو اینجوری، تو واقعاً به من کمک زیادی می‌کنی."

    # say L1393 lyd
    old "But you know I have some problems with the keyboard and his expressions."
    new "اما می‌دونی من با کیبورد و ابرازاتش مشکل دارم."

    # say L1394 pla
    old "I guess you're right. I suppose it would do no harm to give you a hand."
    new "فکر کنم درست می‌گویی. فکر کنم آسونه کمکت کنم."

    # say L1396 lyd
    old "Great, then, let's go to the sofa to chat more comfortably."
    new "عالی، پس برویم به صندلی برای صحبت کردن راحت‌تر."

    # say L1411 lyd
    old "This is where we were in the conversation a little before you arrived."
    new "اینجا هستیم که قبل از رسیدنتون به این مکان بودیم."

    # say L1412 pla
    old "I see, things seem to be going well."
    new "می‌بینم، به نظر می‌رسه خوب هست."

    # say L1413 lyd
    old "I guess they are... so what do I tell him now?"
    new "باید بهش چی بگم حالا؟"

    # say L1414 pla
    old "Well, as I told you last time, you have to be playful, but a little suggestive."
    new "خب، مثل آنگاهی که به تو گفتم، باید بازی کنی، اما یه کم پردازش باشه."

    # say L1415 lyd
    old "I was​​ thinking of telling him something about my clothes, about how sexy they would be."
    new "من فکر می‌کنم بهش بگم در مورد لباس‌هام، چقدر جذاب هستن."

    # say L1416 pla
    old "That sounds good, how do you want me to say it?"
    new "این خوبه، می‌خوای من چطور بگم؟"

    # say L1417 lyd
    old "Like this 'To start, I would get there wearing a trench coat'."
    new "مثلاً این‌جوری: «ابتدا من با لباس کت بلند می‌رسیدم»."

    # say L1419 pla
    old "What? That's not sexy at all!"
    new "آهای، این هیچ جور جنسی نیست!"

    # say L1420 lyd
    old "Of course it isn't, it's something I read in a magazine a long time ago, just write it."
    new "البته نیست، این چیزی هست که یه وقت‌ها توی مجله خوندم، فقط بنویس."

    # say L1424 pla
    old "He answered 'a trench coat?' See? That's not sexy."
    new "او جواب داد 'یک روزنه؟' ببین، این جنسی نیست."

    # say L1426 lyd
    old "Fufu, what's sexy is what I would bring underneath."
    new "فوفو، آنچه جنسیه همچین چیزی است که من زیرش می‌آورم."

    # say L1427 lyd
    old "Write 'Then I would take it off, to let you see the black lingerie that I'm wearing underneath.'"
    new "بعد از اون، آن رو بر می‌دارم تا به تو نشون بدم لینجری سیاهی که زیرش پوشیده‌ام."

    # say L1429 pla
    old "Oh! I see what you mean."
    new "اوه! حالا متوجه شدم."

    # say L1432 pla
    old "He really seemed to like that, now he's asking 'Then what else?'"
    new "ویا، او واقعاً لذت برده، حالا می‌پرسه «بعد از اون چه؟»"

    # say L1434 lyd
    old "I would take you by the hand and bring you to the couch, where I would want you to lay down."
    new "دستت رو می‌گیرم و تو رو به سویا می‌برم، جایی که می‌خوام تو روی آن لیگردی."

    # say L1438 pla
    old "He says 'Oh yeah? And what would you do once I'm laying down on the couch baby?'"
    new "او بله؟ و بعد از اینکه روی سویا دراز کشیدی چه کاری می‌کردی، عزیزم؟"

    # say L1439 lyd
    old "I would lay down on top of you, and I would take those lips of yours on a hot, rough kiss."
    new "من روی تو دراز می‌کنم و آن لب‌هایت رو با یکبوکه تلخ و داغ می‌بوسم."

    # say L1442 pla
    old "He wrote 'I like that! But that's all you'd want?'"
    new "من نوشتم 'می‌پسندم! اما این همه‌ت هم خواسته‌ت؟'"

    # say L1444 lyd
    old "Haha, so cute, tell him 'Well, aren't we a little impatient tonight?'"
    new "هه، خیلی لطیف، بهش بگو «خب، اینجوری بی‌صبر نیستی؟»"

    # say L1447 pla
    old "Hmm, he says 'I'm sorry baby, it's just that I can't resist you.'"
    new "Hmm، او می‌گه 'ببخه عزیزم، فقط اینجوری نمی‌تونم مقاومت کنم.'"

    # say L1448 lyd
    old "That's very cute of him."
    new "این خیلی لطیف ازش است."

    # say L1449 lyd
    old "Write 'It's ok, I can't resist you either.'"
    new "خوبه، من هم نمی‌تونم از تو خودمو بردارم."

    # say L1451 lyd
    old "So while we're kissing, I slowly bring my hand down your chest, pass your abs... and over that big bulging dick under your pants."
    new "پس در حالی که می‌بوسیم، من آرام آرام دستم رو روی سینوت می‌بردم، از عضلات شکمتو می‌گذرتون... و بالای آن لوله بزرگ و بلند زیر پانتالونت می‌رفتم."

    # say L1462 pla
    old "That's it baby! Yeah, you know just what I want."
    new "آره بیبی! همینه، می‌دونی دقیقاً چی می‌خوام."

    # say L1463 lyd
    old "Fufu, and you haven't seen anything yet..."
    new "فوفو، و هنوز هم هیچ چیز ندیده‌ای..."

    # say L1466 pla
    old "Tell me more!"
    new "بیشتر بگو!"

    # say L1467 lyd
    old "I'll feel your big hard cock with my hand, and that is gonna make me horny..."
    new "من با دستم اون نوک بزرگ و سختتو می‌بینم، و این خودمو خیلی عصبی می‌کنه..."

    # say L1478 lyd
    old "And I'm going to rub it over your pants, feeling how big it is..."
    new "و من آن رو روی لباست می‌سازم، احساس می‌کنم چقدر بزرگ است..."

    # say L1481 pla
    old "Ohh, you'll love to feel every inch of me..."
    new "اوه، تو دوست خواهی داشت که هر اینچ از من رو حس کنی..."

    # say L1482 lyd
    old "I already love it... But you'll love what I'm going to do next..."
    new "من قبلاً دوست دارم... اما تو دوست خواهی داشت آنچه بعداً می‌کنم."

    # say L1485 pla
    old "Ohh yes babe, what are you gonna do next?"
    new "اوه بله عزیزم، تو بعداً چه کاری می‌کنی؟"

    # say L1486 lyd
    old "Well, I'm going to kneel in front of you and I'm going to take out that huge cock."
    new "خب، من قراره جلوت بنشینم و اون لولوی بزرگت رو بیرون بیارم."

    # say L1495 lyd
    old "Then, I'll bring my head down and kiss and lick the tip of your cock."
    new "بعد از آن، سرمو پایین می‌آورم و سر لولوت رو بوسیده و لیس می‌کنم."

    # say L1504 pla
    old "Mmm, I love that, I love how you kiss it."
    new "ممنون، عاشق اینجوری می‌بوسی شدم."

    # say L1514 lyd
    old "That was a great conversation! Wasn't it?"
    new "این حرف‌ها عالی بود! همینطور نیست؟"

    # say L1516 pla
    old "Uhm, sure... I was very good."
    new "اوه، البته... من خیلی خوب بودم."

    # say L1517 lyd
    old "I think this might be the right guy for me, he's hot, he's into me. He's just great, right?"
    new "من فکر می‌کنم این شاید مرد مناسبی برایم باشه، خوبه، به من علاقه داره. فقط عالیه، درسته؟"

    # say L1518 pla
    old "Yeah, yeah... He sounds like a great guy."
    new "بله، بله... به نظر می‌رسه یه مرد خوبیه."

    # say L1519 pla
    old "Anyway, I think I should probably go now."
    new "باید احتمالاً حالا برم."

    # say L1520 pla
    old "You know, before Anna arrives and stuff."
    new "بله، قبل از اینکه آنا بیاید و همین‌طور."

    # say L1522 lyd
    old "Yeah, that's probably better. Thank you so much."
    new "بله، احتمالاً بهتره. ممنونم خیلی."

    # say L1538 pla
    old "Whoaa?! What are you doing here?!"
    new "واییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییی"

    # say L1539 lyd
    old "H- Heelloo [pla]!"
    new "ه- هلوو [pla]!"

    # say L1540 lyd
    old "Did I zurprish you?"
    new "من شما رو شوک زدم؟"

    # say L1542 lyd
    old "Did I s- surprize you?!"
    new "من شما رو هم شوک زدم؟!"

    # say L1543 pla
    old "Oh! Yes, you did! Why are you in my room?"
    new "اوه! بله، همینطور! چرا تو توی اتاقم هستی؟"

    # say L1544 pla
    old "How did you get in?"
    new "چطور داخل شدی؟"

    # say L1545 lyd
    old "Sue gave 'e a key."
    new "سو بهش کلید داد."

    # say L1547 pla
    old "I see, well, that makes sense."
    new "می‌بینم، خوب، اینجوری معقوله."

    # say L1548 pla
    old "But you still haven't answered, what are you doing in my room? And this smell... It's alcohol."
    new "ولی هنوز جواب ندادی، تو در اتاق من چیکار می‌کنی؟ و این بو... الکل هست."

    # say L1549 pla
    old "Are you drunk? I thought tonight was the night of your date."
    new "تو خودت رو مست کردی؟ فکر کردم امشب شب تاریخت هست."

    # say L1550 pla
    old "Shouldn't you be with the guy?"
    new "باید با آن دستاوش بودی؟"

    # say L1551 lyd
    old "I 'uess I zhould be. But it didn't go well, like a' all."
    new "باید بودم. اما خوب نرفت، مثل همیشه."

    # say L1552 pla
    old "It didn't? What happened this time?"
    new "این بار هم نپیشتم؟ چه اتفاقی افتاد؟"

    # say L1553 lyd
    old "I don't know!"
    new "نمیدونم!"

    # say L1554 lyd
    old "I just wasn't able to, when 'e moment came I just felt... nothing."
    new "من فقط نتونستم، وقتی لحظه رسید، فقط حس کردم... هیچ."

    # say L1555 pla
    old "What do you mean nothing? I thought you liked the guy."
    new "من قصه‌ات رو نمی‌فهمم. فکر کردم تو از اون جون لایک می‌کنی."

    # say L1556 lyd
    old "I did, I really did, and I think he's cute, and sexy, and funny... but I just wasn't able to focus on him."
    new "من همینجور فکر می‌کردم، و فکر می‌کردم او خوشکار، جذاب و مازه‌داره... اما وقتی لحظه رسید، نتونستم رویش تمرکز کنم."

    # say L1557 lyd
    old "I just didn't want to do it with him... but I still want to have sex."
    new "من فقط نمی‌خواستم باشون هم این کار رو بکنم... ولی همچنان می‌خواهم جنس کنم."

    # say L1559 pla
    old "I don't get it, if you want sex all you had to do was sleep with that guy."
    new "من نمی‌فهمم، اگه می‌خواستی جنس کنی کافی بود با آن مرد خوابیدی."

    # say L1560 lyd
    old "I don't really think that would have worked."
    new "من واقعاً فکر نمی‌کنم اونجوری کار کرده باشه."

    # say L1561 lyd
    old "I think I was wrong about some'ing, I'm not the type of woman who... hips!"
    new "فکر می‌کنم در مورد چیزی اشتباه می‌کردم، من اون نوع زن نیستم که... لولا!"

    # say L1562 lyd
    old "Sorry... who sleeps around. I'm a one-man woman!"
    new "ببخشید... من اون نوع زنی نیستم که با همه خوابم. من فقط برای یه مرد هستم!"

    # say L1563 pla
    old "I get that, but you told me you believed this guy was that one man, why did you suddenly backed out of it? "
    new "من اینو می‌فهمم، ولی تو خودت به من گفتی این مرد همون یک تنی هست که تو بهش اعتماد داری، چرا الان بازموندی؟"

    # say L1564 lyd
    old "D- don't you get it? I already have a man in my life."
    new "د- نمی‌فهمی؟ من قبلاً مردی توی زندگیم هست."

    # say L1565 pla
    old "What? Don't tell me you're still thinking about grandpa."
    new "چه کاری؟ نمی‌گویی هنوز به پاپا فکر می‌کنی؟"

    # say L1566 pla
    old "I think you need to move on from that, that's the whole point, that you wouldn't be caught up in the past."
    new "من فکر می‌کنم باید از اونجا جلوتر بری، این همینه که نباید در گذشته گیر کنی."

    # say L1567 lyd
    old "No, not, no, think about it, there's only one man that I let, and want to touch me."
    new "نه، نه، فکر کن، فقط یک مرد هست که اجازه میدم لمس کنه و میخوام لمسش کنم."

    # say L1569 pla
    old "You don't mean... me?!"
    new "منو می‌خوای؟!"

    # say L1570 lyd
    old "Who else dummy?"
    new "چه کسی دیگه، بی‌حوصله؟"

    # say L1572 pla
    old "W- w- what?"
    new "و- و- چه؟"

    # say L1574 lyd
    old "As I said you're the only one I'll allow to touch me."
    new "همانطور که گفتم تو تنها نفری هستی که اجازه میدم لمست کنم."

    # say L1575 lyd
    old "Not only that, you're the only man I was able to think about when I tried to do it with those other guys."
    new "نه فقط این، تو تنها مردی بودی که وقتی سعی می‌کردم با آن پسران دیگر انجام بدم، در ذهنم به یادت می‌آمد."

    # say L1576 lyd
    old "Oh [pla]! I know it sounds crazy to you, but that's how it is, and I don't want to go around wasting my time with those other men."
    new "اوه ز[pla]! میدونم به نظرت عجیب به نظر می‌رسه، اما همینطور هست و من نمی‌خوام وقتم رو با آن دستا مرد هدر بدهم."

    # say L1577 lyd
    old "After having seen all those dick pics they kept sending me, now I only think they're not much. Nothing compared to you."
    new "بعد از همه عکس‌های نیم‌پوشانی که به من می‌فرستادن، حالا فقط فکر می‌کنم که آنها خیلی خوب نیستند. هیچ‌کدام با تو قابل مقایسه نیستند."

    # say L1578 lyd
    old "Besides, all of those guys, they're so childish, going all out on a phone."
    new "البته، همه اونا مردان کودک‌پوز هستن، توی گوشی‌شون تمام می‌شن."

    # say L1579 lyd
    old "Ugh!"
    new "اوه!"

    # say L1580 lyd
    old "There's only one man I want to be intimate with..."
    new "فقط یک مرد هست که می‌خوام باشون پیش زمینه برم..."

    # say L1581 pla
    old "Are you for real? Do you really mean this?"
    new "می‌گیری واقعاً؟ واقعاً همین می‌خوایی بگی؟"

    # say L1582 lyd
    old "I do, I really do."
    new "بله، واقعاً همین می‌خوام."

    # say L1583 lyd
    old "And I also know you want it too, come on, I know you liked it, the other times. So come on, let's just do it."
    new "و همین‌طور می‌دونم تو هم می‌خوای، بیا، می‌دونم دوست داشتی، همون بار‌های قبل. پس بیا، بیاین بزنیم."

    # say L1585 lyd
    old "Why do you think I came all the way here?"
    new "چرا فکر می‌کنی من همه این مسافت رو طی کردم؟"

    # say L1586 lyd
    old "It wasn't only to tell you that I couldn't get it on with some other guys."
    new "من نه فقط برای این اومدم که بگم نمی‌تونم با دیگه‌ی پسران هم کار کنم."

    # say L1587 pla
    old "But- but... w- we're in my room, I don't think we should."
    new "اما... اما... ما در اتاق من هستیم، فکر نمی‌کنم باید اینجوری کنیم."

    # say L1589 lyd
    old "Shhh, don't worry, nobody will listen to us. It's ok..."
    new "شhhh، نگران نباش، هیچ‌کس به ما گوش نمی‌ده. خوبه..."

    # say L1596 lyd
    old "What do you think, I'm finally cutting loose and doing what I want."
    new "فکر می‌کنی من در نهایت آزاد می‌شوم و انجام می‌دهم آنچه می‌خواهم."

    # say L1605 lyd
    old "Ever since last time I've been wanting you to fuck me again."
    new "از آن بار که گذشته همیشه داشتم می‌خواستم دوباره تو باهام بکنی."

    # say L1606 lyd
    old "It's because of this dick of yours that I haven't been able to be with other guys."
    new "به خاطر این ناخودت نتونستم با مردان دیگه باشم."

    # say L1607 lyd
    old "I still remember how good it felt that one time."
    new "هنوز هم به یاد دارم چقدر خوب احساسش بود آن بار."

    # say L1608 lyd
    old "Now, let's not delay it anymore, I want it in me right now!"
    new "الان، دیگه تأخیر ندهیم، من می‌خوام الان توی من باشه!"

    # say L1617 lyd
    old "Oh! Oh my god! What am I doing in your room?!"
    new "اوه! اوه خداوند! من الان چیکار در اتاق تو می‌کنم؟!"

    # say L1619 pla
    old "Uhh... Well... yesterday you came here."
    new "اوه... خب... دیروز تو اینجا آمدی."

    # say L1620 pla
    old "You were drunk and..."
    new "تو خودت مست بودی و..."

    # say L1621 lyd
    old "Oh God! That's right! I came in here when I was drunk!"
    new "اوه خداوند! درسته! وقتی مست بودم وارد اینجا شدم!"

    # say L1622 lyd
    old "Listen [pla], I'm sorry, I don't know what happened."
    new "بگو [pla]، معذرت، نمی‌دونم چه اتفاقی افتاد."

    # say L1623 lyd
    old "And I shouldn't be here, last night was just a product of the alcohol and nothing else."
    new "و من نباید اینجا باشم، فکر کنم همه چیز فقط به خاطر آلوش بود و هیچ چیز دیگری نیست."

    # say L1624 pla
    old "Hey..."
    new "هی…"

    # say L1625 lyd
    old "Don't say anything, it's getting very early and somebody could see us."
    new "چیزی نگو، خیلی زود شده و ممکنه کسی ما رو ببینه."

    # say L1626 lyd
    old "I should just leave, bye."
    new "باید برم، خداحافظ."

    # say L1644 pla
    old "Hi... Uhh, h- how are you... feeling?"
    new "سلام... اوه، چ- چطور حس می‌کنی؟"

    # say L1645 lyd
    old "[pla]! H- hi."
    new "[pla]! ه- هی."

    # say L1647 lyd
    old "Listen [pla] what happened last night made me think a lot about some stuff."
    new "بگو [pla]، چیزهایی که پس از آن چیزی که دیروز شب اتفاق افتاد فکر کردم، خیلی باعث فکرشده برام."

    # say L1648 lyd
    old "That was a horrible mistake, and it shouldn't have happened."
    new "این یک اشتباه وحشتناک بود و نباید اتفاق می‌افتاد."

    # say L1649 lyd
    old "So, I decided we shouldn't see each other or talk again for a while."
    new "پس، فکر کردم ما نباید یه مدت هم ملاقات کنیم، هم حرف با هم بزنیم."

    # say L1651 pla
    old "Listen, I know you're shook and confused."
    new "بله، میدونم تو لرزان و گیجی."

    # say L1652 pla
    old "But I don't think you should be alone right now."
    new "اما فکر می‌کنم الان باید تنها نباشی."

    # say L1653 lyd
    old "This isn't just a rash decision."
    new "این فقط یک تصمیم سریع نیست."

    # say L1654 lyd
    old "I think I made a mistake with this whole online dating thing."
    new "فکر می‌کنم اشتباهی در این موضوع رابطه آنلاین کردم."

    # say L1655 lyd
    old "I did want to meet and date somebody."
    new "من هم خواستم با کسی آشنا شم و رابطه‌ای داشته باشم."

    # say L1656 lyd
    old "But it got out of my hands at one point. You saw how much it was affecting me."
    new "اما در یک زمان از دست من بیرون رفت. دیدی چقدر برایم تأثیرگذار بود."

    # say L1657 lyd
    old "My sudden mood swings, and odd behavior."
    new "مودهای ناگهانی من و رفتار عجیبم."

    # say L1658 lyd
    old "I don't want to deal with that anymore."
    new "دیگه نمی‌خوام با این مشکل درگیر شم."

    # say L1659 lyd
    old "No, what I need is time to think and get my bearings together."
    new "نه، آنچه به من لازم است، وقت برای فکر کردن و خودم را مرتب کردن است."

    # say L1660 pla
    old "So, I shouldn't have helped you?"
    new "پس من نباید به تو کمک کردم؟"

    # say L1661 lyd
    old "That's not what I said. I actually think that your help was good for me, and I'm grateful for it."
    new "این همین نیست که گفتم. در واقع فکر می‌کنم که کمکت برایم خوب بوده و از آن ممنونم."

    # say L1662 lyd
    old "It's just that I feel that things have gotten out of hand lately, so we should just relax for a little while. You know?"
    new "فقط اینجاست که احساس می‌کنم اوضاع از دست خارج شده، پس باید یه کم آرامش ببریم. میدونی؟"

    # say L1663 pla
    old "I guess that if that is what you want..."
    new "باید باشه، اگر این هستون چی که می‌خوای..."

    # say L1664 lyd
    old "It is, it really is."
    new "بله، واقعاً همینطور است."

    # say L1666 pla
    old "I see... I understand. If you're ok, then I guess I better leave."
    new "می‌بینم... متوجه شدم. اگه خوبی، فکر کنم بهتره برم."

    # say L1667 pla
    old "But if you ever feel like you need to talk, don't hesitate to call me. Ok?"
    new "اما اگر وقتی هم حس کردی باید صحبت کنی، هیچ تردیدی نداشته باش برای تماس با من. خب؟"

    # say L1668 lyd
    old "I will, thank you."
    new "بله، ممنون."


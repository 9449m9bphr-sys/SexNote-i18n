# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/HinnStory.rpy
translate persian strings:

    # say L13 pla
    old "Hey, Hinn! How are you doing?"
    new "هی، هین! چطوری؟"

    # say L15 hin
    old "H... Hey [pla]! I...I'm fine. Thanks for asking?"
    new "ه... هی ز[pla]! من... من خوبم. ممنون از سؤال؟"

    # say L17 pla
    old "Are we a couple?"
    new "ما جفت هستیم؟"

    # say L19 hin
    old "W... WHAT?... WE... WHAT?"
    new "W... چه؟... ما... چه؟"

    # say L21 pla
    old "Well, we are partners for the class project, right?"
    new "خب، ما همکار هستیم برای پروژه کلاس، درسته؟"

    # say L23 hin
    old "Ohh... Riiight. Haha. The class project. Yeah, we are. Sorry, I just forgot..."
    new "اوه... درسته. هاها. پروژه کلاس. بله، ما هستیم. ببخشید، فقط فراموش کردم..."

    # say L25 pla
    old "Don't worry. We can meet to work on it. If you prefer, I could go to your house."
    new "نگران نباش. می‌تونیم برای کار روی پروژه جمع بشیم. اگه خوای، می‌تونم به خونت برم."

    # say L27 hin
    old "W...What? My house? Why? Haha. I mean, why not your place?"
    new "و... وای. خونه من؟ چرا؟ هاها. منظورم اینه، چرا نه خونه تو؟"

    # say L29 pla
    old "Well, I just thought it would be more comfortable for you. But if you don't wanna-"
    new "خب، فکر کردم برایت راحت‌تر باشه. اما اگه نمی‌خوای-"

    # say L31 hin
    old "No! I don't have a problem with that. Hehe. We can meet at my house then. I will wait for you tomorrow after class so we can meet up, ok?"
    new "نه! من مشکلی ندارم. ههه. می‌تونیم توی خونه‌ام بیادیم. منتظرت می‌مونم فردا بعد از کلاس تا ببینیم هم، خوبه؟"

    # say L33 pla
    old "Sounds good to me!"
    new "با من هم همنوایی داره!"

    # say L35 hin
    old "Ok then... I... I have to go, see you tomorrow, [pla]."
    new "باشه... من... من باید برسم، فردا می‌بینیم، [pla]."

    # say L37 pla
    old "See you tomorrow, Hinn!"
    new "ببینم تو روز بعد، هین!"

    # say L52 pla
    old "Hey Hinn, how are you?"
    new "هین، چطوری؟"

    # say L54 hin
    old "Hi [pla], I'm great!, I mean, I'm good, what about you?"
    new "سلام ز[pla]، خوبم، منظورم اینه که خوبم، تو چطوری؟"

    # say L56 pla
    old "I'm good too. So, are you ready to start?"
    new "من هم خوبم. پس، آماده‌ای شروع کنیم؟"

    # say L58 hin
    old "Well yes! I- I think so..."
    new "بله همین! من- من فکر می‌کنم آماده‌ام..."

    # say L60 pla
    old "Ok, then, let's do it!"
    new "خب، پس بیایم شروع کنیم!"

    # say L69 rub
    old "Woah! Look who we have here, it's the girl who dresses as a man."
    new "وای! نگاه کنید کی اومده، دختری که مثل مرد لباس می‌کنه."

    # say L71 oli
    old "Yes! Perhaps you have nothing but that horrible gigantic sweatshirt."
    new "بله! شاید هیچ چیزی جز آن بلوز وحشتناک بزرگ نداری."

    # say L76 rub
    old "You know what the problem is? the problem is that she is kind of fat and that's why she wears those sweatshirts hahaha."
    new "می‌دونی چی مشکل هست؟ مشکل اینه که تو یه قدر چربی داری و برای همین اون بلوزهای بزرگ رو می‌پوشی هahaha."

    # say L78 hin
    old "No, I'm not-"
    new "نه، من نیستم-"

    # say L80 oli
    old "Hahaha you're a fat woman. Don't you have any sense of style?"
    new "هahaha تو یه زن چربی هستی. اصلاً سلیقه‌ای برای لباس‌پوشی نداری؟"

    # say L82 rub
    old "Style? Hahaha look at her such horrible clothes obviously she doesn't know what that is."
    new "ستایل؟ هahaha نگاه کن به لباس‌های وحشتناکش، مشخصه که اصلاً نمی‌دونه اون چیه."

    # say L86 pla
    old "Hey, you shouldn't be so bitchy to Hinn..."
    new "هی، نباید به هین اینقدر بد زن بیان."

    # say L88 rub
    old "Hahaha check it out Olivia, the loser defends the fatty woman."
    new "هahasahaha ببین اولیویا، لузر به دفاع از زن چرب می‌آید."

    # say L90 oli
    old "Why don't you go away with your fat girlfriend, loser?"
    new "چرا نمی‌روی با دوستت چاق، شکسته‌سر؟"

    # say L92 pla
    old "... Assholes."
    new "... خرا."

    # say L94 rub
    old "Bye Loser!"
    new "بای لوزر!"

    # say L113 pla
    old "Wait Hinn..."
    new "هین، بیا بیشتر نگو."

    # say L120 pla
    old "Hmm... some stupid girls were bothering Hinn."
    new "Hmm... بعضی دختران خفن هین رو آزار می‌دادن."

    # say L124 pla
    old "Has this happened before?"
    new "این قبلاً اتفاق افتاده؟"

    # say L126 jad
    old "Yes, but she won't let me go talk to the principal, she says that I would only embarrass her even more..."
    new "بله، اما او نمی‌خواد بیام با رئیس مدرسه صحبت کنم، می‌گه من فقط می‌تونم اون رو بیشتر خجالت‌زده کنم..."

    # say L130 jad
    old "By the way, I'm Jade Hinn's mom, are you her friend?"
    new "البته، من مامان جد هین هستم، تو دوستش هستی؟"

    # say L132 pla
    old "Yes, right, I'm glad to meet you, my name is [pla]."
    new "بله، درسته، خوشحالم که با تو آشنا شدم، من ز[pla] هستم."

    # say L134 jad
    old "Hahaha, Nice to meet you. [pla] please excuse me for a moment. I'm going to talk to Hinn."
    new "هahaha، خوشحالم که با تو آشنا شدم. [pla] لطفاً برای یک لحظه صبر کن، من می‌روم با هین حرف بزنم."

    # say L136 pla
    old "Okay, see you later."
    new "باشه، بعداً می‌بینیم."

    # say L138 jad
    old "Oh no, don't go wait for me here, get comfortable and I'll be back in a minute."
    new "نه، برو اینجا منتظرم نشو، راحت شو، من یه لحظه بعد بر می‌گردم."

    # say L153 jad
    old "All right, I talked to her, everything is fine, she's just a little embarrassed."
    new "باشه، باهاش حرف زدم، همه چی خوبه، فقط کمی خجالت زده."

    # say L155 jad
    old "I can tell she really appreciates you that's why I want to take the opportunity to ask you a favor."
    new "می‌دونم او خیلی ازت قدردانی می‌کنه، برای همین می‌خوام ازت یه درخواست کنم."

    # say L159 jad
    old "I have encouraged her to seek therapy many times as she has had problems at times."
    new "من چند بار تشویقش کردم که به درمانگر برود، چون گاهی مشکلاتی داشته."

    # say L161 pla
    old "To the psychologist?"
    new "به روان‌شناس؟"

    # say L163 jad
    old "Yes, That would be the best option for her to improve her self-esteem, I know it could help her a lot, but she won't listen to me."
    new "بله، این بهترین گزینه برای افزایش خودباوری‌اش هست، می‌دونم می‌تونه خیلی بهش کمک کنه، ولی به من نمی‌گه."

    # say L165 pla
    old "Hmm, I understand."
    new "Hmm، من متوجه شدم."

    # say L167 jad
    old "So, I thought you could help me convince her."
    new "پس فکر کردم می‌تونی به من کمک کنی تا قانعش بشه."

    # say L171 jad
    old "Yes, I'm sure with your help we can convince her that that's the right thing to do."
    new "بله، مطمئنم با کمکت می‌تونیم اونو قانع کنیم که این کار درسته."

    # say L173 pla
    old "Alright. But what should I do?"
    new "باشه. ولی من چی کنم؟"

    # say L175 jad
    old "First of all, help me find a psychologist, the truth is that I have been looking for one, but I haven't been able to find anyone."
    new "اول اینکه، به من کمک کن تا یک روان‌شناس پیدا کنم، در واقع همیشه دنبال یکی می‌گردم ولی تا حالا هیچ‌کس پیدا نکردم."

    # say L177 pla
    old "Hmm, ok, I can handle it."
    new "Hmm، خوب، من اینو می‌تونم انجام بدم."

    # say L179 jad
    old "All right, as soon as you find a therapist let me know. You can meet me here in the morning."
    new "باشه، هر وقت پیدا کردی یک روان‌شناس به من بگو. می‌تونی صبح بیایی اینجا."

    # say L188 hin
    old "Hello [pla], sorry for the delay..."
    new "سلام ز[pla]، متاسفم از تأخیر..."

    # say L190 jad
    old "All right guys, I'll leave you, so, you can go on with your work."
    new "ببینید جون‌ها، من از راه می‌روم، تا بتونید با کارتون بادام زنید."

    # say L196 pla
    old "Don't worry Hinn, do you feel better?"
    new "نگران نباش هین، حالت بهتر شده؟"

    # say L198 hin
    old "Yes a little, I'm very sorry that-"
    new "بله یه کم، خیلی متاسفم که-"

    # say L200 pla
    old "No, you don't have to apologize for anything, they're just bitches."
    new "نه، نباید برای هیچی جدای اعتذار نکنی، فقط مالیدن هستند."

    # say L202 hin
    old "Hehehe, if you say so."
    new "خخخ، اگه می‌گی برات همینه."

    # say L204 pla
    old "Do you want to work today? We could do it tomorrow if you think thats better."
    new "می‌خوای امروز کار کنیم؟ می‌تونیم فردا هم بکنیم اگه فکر می‌کنی بهتره."

    # say L206 hin
    old "No, no, I'm fine, we can start today."
    new "نه، نه، من خوبم، می‌تونیم امروز شروع کنیم."

    # say L208 pla
    old "Ok, let's do it."
    new "باشه، بیایم بکنیم."

    # say L222 pla
    old "Wow, Hinn! I didn't know you were so good at this!"
    new "واو، هین! نمی‌دونستم اینقدر خوبی هستی!"

    # say L224 hin
    old "Well... It's not as difficult as it seems. Hehe. I just study a little here and there."
    new "خب... اینقدر سخت نیست. ههه. من فقط کم کم مطالعه می‌کنم."

    # say L226 pla
    old "Well, thanks to you, we made a lot of progress. I think we can stop for now."
    new "البته، ممنون از تو، هین. پیشرفت زیادی کردیم. فکر کنم می‌تونیم الان متوقف شیم."

    # say L228 hin
    old "Yes, it's getting late. We can continue tomorrow!"
    new "بله، وقت شد. فردا ادامه میدیم!"

    # say L230 pla
    old "Ok. I really enjoyed working with you. I think we make a very good team."
    new "باشه. خوشحالم که با تو کار کردم. فکر می‌کنم ما تیم خوبی هستیم."

    # say L232 hin
    old "Do... D- do you think that?"
    new "د... د- دوستت هم اینجور فکر می‌کنم."

    # say L234 pla
    old "Of course! I think we are going to kick some ass together."
    new "البته! فکر می‌کنم با هم خوب کار می‌کنیم."

    # say L238 pla
    old "Well, see you tomorrow, Hinn. Have a good night."
    new "خب، ببینم فردا، هین. شب خوبی داشت."

    # say L240 hin
    old "You too. By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "تو هم. بینی، به خانم میا پیشرفتمون نشون بده، بگو تا چه جایی رسیدیم. ببینم فردا."

    # say L242 pla
    old "Ok... See you."
    new "باشه... ببینمتم."

    # say L262 jad
    old "You came! I didn't know if you would actually come..."
    new "آمدی! نمی‌دونستم واقعاً می‌آیی..."

    # say L264 pla
    old "Well, I like Hinn and I want to help her anyway I can, I finally found a therapist."
    new "خب، من هین رو دوست دارم و می‌خوام بهش کمک کنم، در نهایت یه روان‌شناس پیدا کردم."

    # say L266 jad
    old "That's excellent! What's their name?"
    new "این خیلی خوبه! اسمش چیه؟"

    # say L268 pla
    old "She is Dr. Johnson, she has her office in the town Business Building."
    new "او دکتر جانسون هست، آفلایش تو ساختمان تجاری شهر هست."

    # say L270 jad
    old "Great, it's not far from here."
    new "عالی، از اینجا دور نیست."

    # say L272 pla
    old "No is not, if you want I can make an appointment to see her."
    new "نه، اگه می‌خوای می‌تونم برایت وقت بگذونم."

    # say L274 jad
    old "Oh, don't worry I'll take care of it."
    new "اوه، نگران نباش، من این کار رو انجام میدم."

    # say L278 jad
    old "However, now comes the toughest part, convincing Hinn to go to therapy."
    new "البته، حالا بخش سخت‌تر اومده، هین رو قانع کردن که به درمان برود."

    # say L280 jad
    old "So, I'll talk to her today but you should convince her to agree to do it."
    new "پس من امروز باهاش حرف می‌زنم ولی تو باید او رو قانع کنی که بپذیره."

    # say L282 pla
    old "Understood!"
    new "فهمیدم!"

    # say L284 jad
    old "Perfect! Now hurry too school. I don't want you to be late because of me."
    new "عالی! حالا به سرعت به مدرسه برو. نمی‌خوام به خاطر من دیر برسی."

    # say L286 pla
    old "Alright! Bye."
    new "باشه! خداحافظ."

    # say L302 jad
    old "I only care about you and your well-being, sweetheart..."
    new "من فقط نگران تو و سلامتت هستم، عزیزم..."

    # say L307 hin
    old "I don't need a psychologist. I'm not crazy!"
    new "من به روان‌شناسی نیاز ندارم. دیوانه نیستم!"

    # say L309 jad
    old "Oh... Hi [pla]!"
    new "اوه... سلام ز[pla]!"

    # say L311 hin
    old "(Oh no...)"
    new "اوه نه..."

    # say L313 pla
    old "Good morning Mr. Jade... Hello there, Hinn."
    new "صبح بخیر آقای جد... سلام هین."

    # say L315 hin
    old "Sorry, [pla]. My mother now thinks I'm crazy..."
    new "ببخشید، [pla]. مامان الان فکر می‌کنه من دیوانه هستم..."

    # say L318 jad
    old "I don't think you're crazy honey, I just want you to go to therapy to strengthen your self-esteem."
    new "من فکر نمی‌کنم تو دیوانه باشی عزیزم، فقط می‌خوام خودت رو قوی‌تر کنی."

    # say L320 hin
    old "I have nothing that I need to be strengthened!"
    new "من هیچ چیزی ندارم که باید تقویت شه!"

    # say L322 jad
    old "Honey, I know the reason why you don't want to go, it is because you think they are going to make fun of you even more at school."
    new "حبیبی، من میدونم دلیل اینکه نمی‌خوای بری اینه که فکر می‌کنی در مدرسه بیشتر مسخره می‌کنند."

    # say L324 jad
    old "But I promise it won't happen, we can do everything without anyone knowing."
    new "اما قول می‌دم اینجوری نمی‌شه، می‌تونیم همه چی رو بدون اینکه هیچ کس متوجه بشه انجام بدیم."

    # say L326 hin
    old "No, no, I won't do it, and I don't want you to continue embarrassing me."
    new "نه، نه، من این کار رو نمی‌کنم و نمی‌خوام تو هم ادامه بدی به خجلمخالی کردن من."

    # say L328 jad
    old "[pla], would you think Hinn is crazy if she goes to the therapist?"
    new "[pla]، اگه هین به روان‌پزشک برود، می‌تونی بگی هیجان‌زاست؟"

    # say L332 pla
    old "Actually, I think it's healthy, and if it's something that will help you feel better, I don't think it matters what others think, right?"
    new "در واقع فکر می‌کنم سالم است، و اگر چیزی است که به تو کمک می‌کنه حس خوبی داشته باشی، مهم نیست دیگران چه فکر می‌کنند، درسته؟"

    # say L335 jad
    old "You see darling, there is nothing wrong with it, many people attend to therapy and it is completely normal."
    new "دیدی عزیزم، هیچ اشکالی نداره، خیلی‌ها به درمانگر مراجعه می‌کنن و این کاملاً عادیه."

    # say L339 jad
    old "In fact, [pla] would you go with Hinn?"
    new "در واقع، [pla] می‌خوای با هین بره؟"

    # say L344 pla
    old "Sure, I'd love to."
    new "بله، خوشحالم برم."

    # say L346 jad
    old "See honey, don't worry any more, go to a single session and then decide whether to continue or not."
    new "ببین عزیزم، دیگه نگنجد، یه جلسه برو و بعدش ببینی ادامه بدی یا نه."

    # say L348 hin
    old "Would you really be willing to go with me?"
    new "می‌خوای واقعاً با من بیایی؟"

    # say L350 pla
    old "Of course, it should be fun."
    new "البته، باید لذت ببریم."

    # say L352 hin
    old "Okay, but don't think I don't realize how you are manipulating me."
    new "البته، ولی نفکر کنی نمی‌فهمم چطور می‌خوای از من استفاده کنی."

    # say L354 jad
    old "Excellent honey, I'm going to make the appointment. So, you can start studying now."
    new "عالی عزیزم، من می‌رم وقت ملاقات رو تعیین کنم. پس می‌تونی الان شروع به مطالعه کنی."

    # say L361 hin
    old "She's unbelievable..."
    new "وای، اونجوری که هست..."

    # say L364 pla
    old "Well, the truth is, I think she's doing the best she can to help you."
    new "البته، من فکر می‌کنم او تلاش خوبی برای کمک به تو می‌کنه."

    # say L366 hin
    old "If you say so... Anyway, let's start to work."
    new "اگه می‌گی براش... بیای، شروع کنیم کار رو."

    # say L370 hin
    old "[pla], thank you... seriously. Thanks for having my back."
    new "[pla]، ممنون... جدی هستم. ممنون که برایم حرف زدی."

    # say L372 pla
    old "It's nothing..."
    new "هیچی..."

    # say L392 pla
    old "Ok, see you tomorrow, Hinn."
    new "باشه، ببینم چه کاری می‌کنم، هین."

    # say L396 pla
    old "Ok. Have a good night."
    new "باشه، شب خوبی داشته باش."

    # say L416 hin
    old "Hello [pla], How are you doing?"
    new "سلام ز[pla]، چطوری؟"

    # say L418 pla
    old "Hey Hinn, I am doing great, you?"
    new "هین، من خوب هستم، تو چطوری؟"

    # say L420 hin
    old "Fine, thanks for asking. Today is the so-called “therapy session”, are you coming?"
    new "خوبم، ممنون از جویایی. امروز جلسه درمانی هست، می‌آیی؟"

    # say L422 pla
    old "Is it today?"
    new "امروز هست؟"

    # say L424 hin
    old "Yes... My mother finally managed to schedule an appointment as we agreed."
    new "بله... مادرم در نهایت توانست ملاقاتی را مثل آنچه توافق کردیم برنامه‌ریزی کند."

    # say L426 pla
    old "Sure, I promised that I'll join you."
    new "بله، قول دادم که همراهت می‌شوم."

    # say L428 hin
    old "Awesome, are you ready?"
    new "عالی، آماده‌ای؟"

    # say L430 pla
    old "Yes, let's get going."
    new "بله، بیایید شروع کنیم."

    # say L432 hin
    old "Very well."
    new "خوب است."

    # say L440 joh
    old "Good afternoon, nice to meet you, you must be Hinn, right?"
    new "بعد از ظهر، خوشحالم که با شما آشنا شدم، شما حتماً هین هستید، درست است؟"

    # say L442 hin
    old "Yes, Dr. Johnson, nice to meet you too."
    new "بله، دکتر جانسون، خوشحالم که با شما آشنا شدم."

    # say L444 joh
    old "Your mother has already told me a little about you and you are..."
    new "ما مادر شما قبلاً در مورد شما به من گفته و شما..."

    # say L446 pla
    old "My name is [pla], nice to meet you."
    new "اسم من [pla] هست، خوشحالم که با شما آشنا شدم."

    # say L448 joh
    old "Oh, are you her boyfriend?"
    new "اوه، شما دوستش هستید؟"

    # say L453 hin
    old "He's a friend..."
    new "او دوستی است..."

    # say L455 joh
    old "Oh ok, I understand a friend..."
    new "اوه خب، متوجه شدم دوستی..."

    # say L457 joh
    old "All right, I think it's time to start therapy. [pla] could you wait for us outside?"
    new "باشه، فکر کنم وقت شروع درمان رسیده. [pla] می‌تونی بیرون منتظرمون بمانی؟"

    # narrator L465 
    old "A few minutes later"
    new "چند دقیقه بعد"

    # say L476 joh
    old "Very well, let me explain. With Hinn we have discussed the issue of bullying in the school."
    new "بسیار خب، بگذارم توضیح بدم. ما با هین در مورد مشکل آزاردهی در مدرسه صحبت کرده‌ایم."

    # say L478 joh
    old "And we have reached to the conclusion that it is best for her to try on other outfits so that she feels more comfortable with her body."
    new "و ما به این نتیجه رسیده‌ایم که بهتر است او لباس‌های دیگری را امتحان کند تا با بدن خود راحت‌تر شود."

    # say L480 pla
    old "I understand, I think it's a good idea."
    new "فهمیدم، فکر می‌کنم ایده خوبیه."

    # say L482 joh
    old "Yes, but to help her to have a better progress with the therapy, we require your help."
    new "بله، اما برای اینکه او درمان خود را بهتر پیش ببرد، به کمک شما نیاز داریم."

    # say L484 pla
    old "My help? How so?"
    new "کمک من؟ چطور؟"

    # say L486 joh
    old "We need a male friend opinion for each outfit so Hinn can feel that someone cares for her."
    new "ما نیاز داریم نظر یک دوست مرد برای هر لباس رو بگیریم تا هین حس کنه که کسی به او اهمیت میده."

    # say L488 pla
    old "Oh, I understand, no problem."
    new "اوه، متوجه شدم، هیچ اشکالی ندارم."

    # say L492 pla
    old "Yes, it will be fun."
    new "بله، خوشحالم."

    # say L494 joh
    old "All right, in that case sit on the couch while Hinn takes off that sweatshirt."
    new "البته، در این صورت روی میز نشین تا هین آن سویی شرت را ببرد."

    # say L509 joh
    old "Are you ready Hinn?"
    new "آماده‌ای هین؟"

    # say L511 hin
    old "Hmm, I think so."
    new "Hmm، فکر کنم آماده‌ام."

    # say L513 joh
    old "Very well take off that sweatshirt and let us see your body better."
    new "خوب، پیش‌دست اون بلوز را ببردار و بیای بیشتر بدنت رو ببینیم."

    # say L517 joh
    old "Don't worry, you're in a safe place, nobody's going to judge you here."
    new "نگران نباش، تو جای امنی هستی، هیچ‌کس تو رو اینجا قضاوت نمی‌کنه."

    # say L519 hin
    old "Hmm alright."
    new "خوب، اما من آرامش دارم."

    # say L523 joh
    old "But girl you have a great body!"
    new "اما دختر، تو بدن خوبی داری!"

    # say L528 pla
    old "Yes, she certainly looks better."
    new "بله، حتماً او بهتر به نظر می‌رسد."

    # say L532 joh
    old "Do you think you could survive without your Sweatshirt?"
    new "آیا فکر می‌کنی بدون پولویت خودت می‌تونی زنده بمانی؟"

    # say L534 hin
    old "They are going to criticize me at school, because of my... b- breasts."
    new "در مدرسه به خاطر سینام از من می‌انتقاد کنن... b- سینام."

    # say L536 joh
    old "Hahaha, but how are you going to be embarrassed by those beautiful breasts?"
    new "حاحاحا، اما چطور می‌تونی به خاطر اون سینه‌های زیبالت خجول باشی؟"

    # say L537 joh
    old "What do you say [pla], Hinn should be ashamed?"
    new "چه می‌گی [pla]، هین باید خجالت زنی؟"

    # say L538 pla
    old "... Hmm no, really your breasts look great."
    new "Hmm نه، واقعاً سینه‌هایت خوب هستند."

    # say L542 joh
    old "You have a blessing, you have a slim waist and a couple of really nice boobs, with those you might make all the boys crazy over you. "
    new "شما دارید لطفی، کمری نازک و دو تای سینه‌ای خوب دارید، با این‌ها ممکن است تمام پسران را دیوانه کنید."

    # say L546 joh
    old "All right, all right, no problem, I think that's it for today."
    new "باشه، باشه، هیچ اشکالی نداره، فکر کنم برای امروز کافیه."

    # say L554 joh
    old "However, we will have to get some more outfits to continue with your treatment."
    new "البته، اما برای ادامه درمان باید لباس‌های بیشتری پیدا کنیم."

    # say L556 joh
    old "Hmm, I'd rather it wasn't your own clothes, since from what I've see your clothes cover a lot."
    new "البته، بهتر است لباس‌های جدید باشند، زیرا از آنچه دیدم، لباس‌های شما خیلی پوشیده هستند."

    # say L558 pla
    old "I think I could help, I could get some clothes for Hinn."
    new "فکر کنم می‌تونم کمک کنم، می‌تونم لباس‌هایی برای هین بخرم."

    # say L560 joh
    old "Fantastic! Make sure it's a bit of a daring and revealing outfit."
    new "عالی! حتماً لباسی جسورانه و نشان‌دهنده بیاور."

    # say L562 joh
    old "We need to gradually make Hinn feel more secure in her body."
    new "باید تدریجا هین را مطمئن‌تر کنیم در مورد بدن خودش."

    # say L566 joh
    old "Ok, see you in the next session guys!"
    new "باشه، تا جلسه بعد می‌بینیم دوستان!"

    # say L568 hin
    old "Thanks Dr. Johnson, goodbye."
    new "ممنون دکتر جانسون، خداحافظ."

    # say L570 pla
    old "Goodbye."
    new "خداحافظ."

    # say L577 pla
    old "How did you feel Hinn?"
    new "حین، احساست چطور بود؟"

    # say L579 hin
    old "Actually, it was quite interesting, I felt comfortable in therapy, confronting it a little I think it can help."
    new "در واقع، خیلی جالب بود، حس کردم درمان روانشناسی راحتی داشتم، مواجهه کردن با آن تا حدی می‌تونه کمک کنه."

    # say L581 pla
    old "Excellent, I think it's great that you feel that way."
    new "عالی، خوشحالم که اینطور می‌تونی حس کنی."

    # say L583 pla
    old "So, will you continue attending therapy?"
    new "پس، می‌خوای ادامه بدهی به درمان؟"

    # say L585 hin
    old "Hmm... Would you still accompany me?"
    new "Hmm... همچنان همراه من می‌شوی؟"

    # say L587 pla
    old "Of course I will."
    new "البته خواهم آمد."

    # say L590 hin
    old "Okay, let's just don't make a fuss in front of my mother, I don't want her to think she was right."
    new "باشه، فقط بیای با من در برابر مادرم هیچ اشکالی نداشته باش، نمی‌خوام فکر کنه درسته بود."

    # say L592 pla
    old "Hahaha, alright."
    new "حاحاحا، خوب."

    # say L594 hin
    old "Thanks again for your support."
    new "ممنونم از حمایتت"

    # say L596 pla
    old "It's a pleasure, Hinn."
    new "خوشحالم، هین."

    # say L598 hin
    old "Could you come with me to my house today? I don't want my mother to ask me many questions."
    new "می‌تونی همراه من به خونه بیاد؟ نمی‌خوام مادرم از من سؤالات زیادی بپرسه."

    # say L610 jad
    old "How did it go guys?"
    new "چطور بود، دوستاه؟"

    # say L612 hin
    old "Hmm... it wasn't a bad idea after all..."
    new "هم... در نهایت ایده بدی نبود."

    # say L614 jad
    old "You should tell by now that therapy is a very positive thing to do."
    new "باید حالا متوجه شده باشی که درمان روانشناسی چیز خوبیه."

    # say L616 jad
    old "Then I will immediately schedule the next appointment!"
    new "پس من فوراً نوبت بعدی رو رزرو می‌کنم!"

    # say L618 hin
    old "No, I'm not going to go to therapy every day mom..."
    new "نه، من نمی‌تونم هر روز برم مامان..."

    # say L620 jad
    old "But... I thought you liked it."
    new "ولی... فکر کنم دوست داشتی."

    # say L622 hin
    old "Yes, I will go but remember, I have more responsibilities, like the class project with [pla]."
    new "بله، می‌روم ولی به خاطر داشت، مسئولیت‌های دیگری هم دارم، مثل پروژه کلاس با [pla]."

    # say L624 jad
    old "Hmm, I understand, So when I should make the next appointment?"
    new "همم، من متوجه شدم، پس باید چه زمانی برای نوبت بعدی تعیین کنم؟"

    # say L626 hin
    old "No, I will make the appointments myself when I think it is appropriate."
    new "نه، من خودم وقتی مناسب می‌دونم موعد می‌ذارم."

    # say L628 hin
    old "Besides, [pla] must also agree when we should go, since he's going to the therapies as well."
    new "البته، باید ز[pla] هم موافقت کنه که وقتی باید بریم، چون او هم به درمان‌ها می‌ره."

    # say L630 jad
    old "Okay, you're right, I'll leave that up to you, if you need anything don't hesitate to ask me."
    new "باشه، درست می‌گی، این کار رو به تو می‌ذارم، اگه نیازی داشتی به من بگو."

    # say L632 jad
    old "I'll leave you alone, so, you can say goodbye to each other, heh."
    new "من از شما برمی‌آم، براحتی می‌تونید با هم خداحافظی کنید، هه."

    # say L647 pla
    old "I'm glad that everything went well with therapy."
    new "خوشحالم که همه چیز خوب پیش رفت درمان."

    # say L649 hin
    old "Yes, me too, at least my mom will stop bothering me every day, or I hope so."
    new "بله، من هم همینطور فکر می‌کنم، حداقل مامان دیگه هر روز بهم تلیفون نمی‌کنه، یا امیدوارم همینطور باشه."

    # say L651 pla
    old "Hahaha I don't think that's going to happen."
    new "حاحاحا فکر نمی‌کنم اینجوری باشه."

    # say L653 hin
    old "Hehehe neither do I."
    new "هههه من هم نه."

    # say L659 pla
    old "Well, well, it's getting late, so I'm going home, see you tomorrow."
    new "خب خب، وقت شد، من بر می‌گردم، فردا می‌بینم."

    # say L661 hin
    old "Yes, thank you so much for what you are doing."
    new "بله، ممنونم از همه چیزی که برای من انجام می‌دهی."

    # say L663 pla
    old "You are welcome, I enjoyed it as much as you did and I love spending time with you."
    new "خواهش می‌کنم، من هم لذت بردم مثل تو و خوشحالم وقت با تو می‌گذرم."

    # say L667 pla
    old "Well... see you tomorrow."
    new "خب... فردا می‌بینیم."

    # say L687 pla
    old "Hey Hinn! How are you today?"
    new "هین! امروز چطوری؟"

    # say L689 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy sesion."
    new "من خوبم ممنون [pla]، منتظرت بودم، امروز جلسه درمان جدیده."

    # say L691 pla
    old "Oh great, let's go then."
    new "عالی، برویم هین."

    # say L693 hin
    old "Ok, ok."
    new "باشه، باشه."

    # say L701 joh
    old "Hi guys, how are you?"
    new "سلام بچه‌ها، چطور هستید؟"

    # say L703 pla
    old "Fine, thanks."
    new "خوب هستم، ممنون."

    # say L705 joh
    old "Ready to go on with the treatment?"
    new "آماده هستید تا درمان را ادامه بدید؟"

    # say L707 hin
    old "I think so..."
    new "فکر کنم بله..."

    # say L709 joh
    old "Excellent, [pla] you brought the clothes, didn't you?"
    new "عالی، [pla] لباس‌ها رو آوردی، درسته؟"

    # say L711 pla
    old "Well, yes although I'm not sure if this will work, the clothes are... a little more revealing than necessary."
    new "خب، بله اگرچه نمیدونم این کار می‌تونه خوب بشه، لباسا... کمی بیشتر از لازم آشکار هستند."

    # say L713 joh
    old "Hmm, we'll see let's go Hinn, to the changing room."
    new "Hmm، ببینیم برو هین، به اتاق جایگزینی لباس."

    # say L715 hin
    old "Hmm... ok."
    new "Hmm... خب."

    # say L728 joh
    old "Well, it took me a while to convince her, but finally got her to try on this outfit..."
    new "خب، مدتی طول کشید تا قانع کنم، اما در نهایت راضی شد این لباس رو امتحان کنه..."

    # say L739 joh
    old "What do you think [pla]?"
    new "چه نظری داری [pla]؟"

    # say L740 pla
    old "(Oh my God!) Well, I think you look really good, Hinn..."
    new "اوه خدا! خوب، فکر می‌کنم تو خیلی خوب هستی، هین..."

    # say L742 hin
    old "Do you really think so?"
    new "وای، واقعاً اینطور فکر می‌کنی؟"

    # say L743 pla
    old "Yes, you look great."
    new "بله، تو خیلی خوب هستی، هین."

    # say L745 joh
    old "What did I tell you? You should wear these kinds of clothes every day."
    new "من چه گفتم؟ باید این جور لباس‌ها رو هر روز بپوشی."

    # say L747 hin
    old "No way. I'm not going to wear this in public..."
    new "نه، هیچ راهی. من نمی‌تونم این لباس رو در جای عمومی بپوشم..."

    # say L749 joh
    old "Well, at least you tried it. We are making progress. However, we need to go further. Next time bring something more revealing, ok [pla]?"
    new "خب، حداقل امتحانش کردی. پیشرفتی داریم. اما باید بیشتر پیش بریم. بار بعد چیزی محرمانه‌تر بیاور، خب [pla]؟"

    # say L751 hin
    old "More revealing?!"
    new "بیشتر آشکار؟!"

    # say L754 joh
    old "Yeah, honey remember we are going to do it privately and in a safe place, so we can improve."
    new "بله، عزیزم، به خاطر داشتی که ما این کار رو خصوصی و در جایی امن انجام میدیم، پس میتونیم بهتر شیم."

    # say L764 joh
    old "Well, that's it. See you in the next session."
    new "خب، این همه است. تا جلسه بعد می‌بینیم."

    # say L766 hin
    old "Thanks Dr. Johnson."
    new "ممنونم دکتر جانسون."

    # say L775 hin
    old "Thank you so much for joining me again... I really appreciate it."
    new "ممنونم که دوباره همراه من شدید... خیلی از این بابت قدردانی می‌کنم."

    # say L777 pla
    old "Oh, don't worry, I think it's fun."
    new "اوه، نگران نباش، فکر کنم خوشحالم."

    # say L779 hin
    old "You're right, it's a bit fun..."
    new "درست می‌گی، یه کم خنده‌داره..."

    # say L781 pla
    old "Would you like me to walk you home?"
    new "می‌خوای من به خونه برسونم؟"

    # say L783 hin
    old "Oh no, don't worry my mom will come to pick me up."
    new "نه، نگران نباش، مامانم می‌آید مرا ببرد."

    # say L785 pla
    old "Alright, then see you tomorrow?"
    new "البته، پس فردا می‌بینیم؟"

    # say L787 hin
    old "Yes!... I mean, sure."
    new "بله!... منظورم اینه، حتماً."

    # say L789 pla
    old "Great, see you tomorrow Hinn."
    new "عالی، فردا می‌بینیم هین."

    # say L791 hin
    old "See you tomorrow [pla]."
    new "فردا می‌بینیم [pla]."

    # say L810 hin
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy session."
    new "خوبم ممنون [pla]، منتظرت بودم، امروز جلسه درمان جدید هست."

    # say L826 joh
    old "Ready to get started with the treatment?"
    new "آماده‌ای برای شروع درمان؟"

    # say L830 joh
    old "Excellent, let's go Hinn."
    new "عالی، بیای Hinn."

    # say L844 joh
    old "I love this outfit, I find it fancy and it looks great on you Hinn..."
    new "این لباس رو عاشق شدم، خیلی جدابه و بر تو خیلی خوب می‌نشینه هین..."

    # say L856 joh
    old "Look at you, wow, you look fantastic."
    new "ببین، وای، تو خیلی خوب به نظر می‌رسی."

    # say L858 hin
    old "I think this skirt is too short..."
    new "فکر می‌کنم این مینی‌لباس خیلی کوتاهه..."

    # say L860 joh
    old "That's the idea! To show those pretty legs of yours. Hehe. See how [pla] is drooling over them?"
    new "این همینه! برای نشون دادن آن پای‌های زیبایت. ههه. ببین چطور [pla] رویشون لعاب کشیده."

    # say L863 pla
    old "Mmm Yes... I mean no... I'm just watching. Nothing more."
    new "ممن می‌دونم... منظورم نه... فقط نگاه می‌کنم. هیچ چیز دیگه نیست."

    # say L865 joh
    old "Sure, you are... Do you think Hinn has pretty legs?"
    new "بله، حتماً... فکر می‌کنی هین قایق‌های زیبایی داره؟"

    # say L866 pla
    old "Uhhh... Well, actually yes, I do..."
    new "اوه... خب، در واقع بله، من همین فکر دارم..."

    # say L869 pla
    old "Yes, you really look nice."
    new "بله، تو واقعاً خوب به نظر می‌رسی."

    # say L871 joh
    old "And how about that cleavage, aye?"
    new "و اون بین دو سینو هم خوبه، همینطور؟"

    # say L875 pla
    old "Uhh... It looks great, too. Hinn has a really good... Body."
    new "آره... همینطور خوبه. هین یک بدن خیلی خوبی داره."

    # say L877 joh
    old "She has great boobs, too, doesn't she?"
    new "او هم سینه‌های خوبی داره، نه؟"

    # say L881 hin
    old "I'm going to change my clothes..."
    new "من قصد دارم لباس‌هام رو عوض کنم..."

    # say L883 joh
    old "Hehe. I was just kidding..."
    new "هههه. من فقط مزح زدلم..."

    # say L891 joh
    old "Well, that's it, [pla] you can surprise me the next session with another beautiful outfit like today."
    new "خب، این همه است، [pla] شاید در جلسه بعد با لباس زیبایی مثل امروز من را متعجب کنید."

    # say L893 pla
    old "I will try."
    new "من سعی خواهم کرد."

    # say L895 joh
    old "Great! All right guys, see you in the next session."
    new "عالی! خب بچه‌ها، تا جلسه بعد می‌بینیم."

    # say L897 hin
    old "Thank you Dr. Johnson."
    new "ممنونم دکتر جانسون."

    # say L910 hin
    old "You are right, it's a bit fun..."
    new "درست می‌فرمایید، یه جور خنده‌داره..."

    # say L912 pla
    old "Do you want me to walk you home?"
    new "می‌خوای منت به خونه ببرم؟"

    # say L939 pla
    old "I talked to Mrs. Mia... Ugh, I think she hates me or something."
    new "من با خانم میا حرف زدم... اوه، فکر کنم از من نفرت داره یا چیزی."

    # say L941 hin
    old "Why do you say that?"
    new "چرا اینجوری می‌گی؟"

    # say L943 pla
    old "She doesn't think I did anything on our project... And she wants you to talk to her alone."
    new "او فکر نمی‌کنه من هیچ کاری توی پروژه‌مون انجام داده‌ام... و می‌خواد تو باهاش تنها صحبت کنی."

    # say L945 hin
    old "Oh, no problem, [pla]. Don't worry I'll talk to her and let her know the truth."
    new "اوه، هیچ اشکالی نداره، [pla]. نگران نباش، باهاش حرف می‌زنم و حقیقت رو بهش می‌گم."

    # say L947 pla
    old "Ok. Thank you, Hinn."
    new "باشه. ممنون، هین."

    # say L965 hin
    old "Everything is fine. I explained everything to her."
    new "همه چیز خوبه. همه چیز رو بهش توضیح دادم."

    # say L967 pla
    old "Really? Just like that, huh?"
    new "وای، هین! واقعاً همینطور، همینطور؟"

    # say L969 hin
    old "Well, I can be very persuasive if I set my mind to it."
    new "البته، وقتی من تصمیم می‌گیرم، می‌توانم خیلی متقاعدکننده باشم."

    # say L971 pla
    old "Wow, Hinn! You sure have changed. You're way more open and secure..."
    new "واو، هین! خیلی تغییر کردی. خیلی بیشتر باز و اعتماد به نفس شدی..."

    # say L975 pla
    old "Yes, I really do."
    new "بله، واقعاً همینطور است."

    # say L977 hin
    old "Hahaha. Well, thank you, [pla]. It seems that my mom's crazy ideas really worked somehow."
    new "هahaha. خب، ممنون، [pla]. به نظر می‌رسه ایده‌های دیوانه مامان واقعاً کار کرده."

    # say L979 pla
    old "Yes. I definitely think so..."
    new "بله. من قطعاً همینطور فکر می‌کنم..."

    # say L981 hin
    old "Well, speaking of that, today is the new therapy session."
    new "البته، در مورد این، امروز جلسه درمان جدیدمون هست."

    # say L1011 joh
    old "Great, let's go Hinn."
    new "عالی، برویم هین."

    # say L1034 joh
    old "I honestly didn't think that Hinn was going to wear this... But we really are coming a long way..."
    new "من واقعاً فکر نکردم که هین این لباس رو بپوشی... اما ما واقعاً پیشرفت زیادی کرده‌ایم..."

    # say L1037 hin
    old "I don't really feel comfortable..."
    new "من واقعاً راحت نیستم..."

    # say L1039 joh
    old "You look fantastic, girl! With this outfit, you will drive them all crazy!"
    new "تو خیلی خوب هستی، دختر! با این لباس، همه رو خواهی دیوانه کرد!"

    # say L1041 hin
    old "What! Who's supposed to wear this in public?"
    new "چه کسی باید اینو توی خیابون بپوشه؟"

    # say L1043 joh
    old "Hahaha, I'd be surprised. What do you think, [pla]?"
    new "هاهاها، من شوک نمی‌شدم. تو چه فکر می‌کنی، [pla]؟"

    # say L1046 pla
    old "...(Oh shit! I'm getting hard.)"
    new "اوه شیطان! من سخت می‌شوم."

    # say L1053 joh
    old "Haha! Well, you've already made him get horny."
    new "هه هه! خب، شما قبلاً اونو آماده کردین."

    # say L1057 joh
    old "Can't you see his pants?"
    new "نمی‌تونی پانتالونش رو ببینی؟"

    # say L1061 joh
    old "That right there, Hinn, is the most honest show of appreciation you can receive from a man..."
    new "اینجا، هین، صادقانه‌ترین نشانه قدردانی که از مردی می‌توانی دریافت کنی..."

    # say L1064 hin
    old "Oh my..."
    new "اوه، خودت..."

    # say L1065 pla
    old "Sorry... It wasn't... My intention..."
    new "ببخشید... من قصد نداشتم..."

    # say L1067 joh
    old "Oh, no. Don't worry, honey. In fact, Hinn, you should feel flattered."
    new "نه، نگران نباش، عزیزم. در واقع، هین، باید افتخار کنی."

    # say L1068 joh
    old "Do you know what that erection means? [pla] is sexually attracted to you!"
    new "میدونی این ارگزیشن یعنی چی؟ [pla] جنسی به تو علاقه‌مند هست!"

    # say L1069 pla
    old "(Oh shit!)"
    new "اوه شیطون!"

    # say L1073 joh
    old "Well, since you are both quite young, I think I could take this chance to give you a little sex education lesson..."
    new "خب، چون هر دو شما حدوداً جوان هستید، فکر می‌کنم می‌توانم از این فرصت استفاده کنم و یک درس کوچک آموزش جنسی به شما بدهم..."

    # say L1077 joh
    old "Hahaha, [pla], you have Hinn speechless... Come here, don't be shy..."
    new "هahaha، [pla]، هین رو بی‌صدا کردی... بیا اینجا، نباید خجول باشی..."

    # say L1083 joh
    old "I have to admit, [pla], I didn't imagine it would be this big... His size is pretty impressive, huh, Hinn?"
    new "باید بپذیرم، [pla]، فکر نمی‌کردم اینقدر بزرگ باشه... اندازه‌اش خیلی جالب است، هن؟"

    # say L1084 hin
    old "(It's so big.)"
    new "این هم خیلی بزرگ است."

    # say L1085 joh
    old "Haha. This surely is the first time she's seen a real one and seeing one of this size even surprises me."
    new "هahaha. این قطعاً اولین باره که یکی واقعی رو می‌بینه و حتی من هم از این اندازه شگفت‌زده شدم."

    # say L1088 joh
    old "Let me get all this out of here..."
    new "بیاین همه اینا رو از اینجا ببرم..."

    # say L1093 joh
    old "Certainly... This is awesome, kid... What a big cock you have down here!"
    new "البته... این خیلی عالیه، بچه... چقدر پوسه بزرگی داری اینجا!"

    # say L1100 joh
    old "Well, Hinn, pay close attention... I'm going to teach you how to please a man with your hands, this will be very useful knowledge..."
    new "خوب، هین، به خوبی توجه کن... من می‌خوام یادت بدم چطور با دست‌هات یک مرد رو خوشحال کنی، این دانش برایت خیلی مفید خواهد بود..."

    # say L1102 joh
    old "You have to take it in your hands and start to massage, from top to bottom very carefully..."
    new "باید اون رو تو دستت بگیری و شروع به ماساژ کردن از بالا به پایین بکنی، خیلی دقت کن..."

    # say L1115 joh
    old "Well... I hope you learned a little more about your sexuality, kids... If you want me to give you another small lesson, just let me know."
    new "البته... امیدوارم کمی بیشتر در مورد جنسیت خودtan یاد گرفتین، بچه‌ها... اگر می‌خواهید به من بگویید تا برای شما درس کوچکی دیگر بدهم، فقط به من بگویید."

    # say L1117 joh
    old "See you in the next session."
    new "در جلسه بعد می‌بینیم."

    # say L1132 hin
    old "Well..."
    new "خب..."

    # say L1134 pla
    old "Your mom is coming to pick you up?"
    new "مامانت می‌آیه تا تو رو ببره؟"

    # say L1136 hin
    old "Yes, yes, she is coming to get me."
    new "بله، بله، مامان می‌آید مرا ببرد."

    # say L1138 pla
    old "Oh, ok, then see you tomorrow?"
    new "اوه، خب، پس فردا می‌بینیم؟"

    # say L1174 pla
    old "Yes, I love to help. Also, I think your mom did everything to help you."
    new "بله، خوشحالم که کمک کنم. همچنین فکر می‌کنم مامانت هم همه کارها رو برایت انجام داده."

    # say L1178 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is how you feel about yourself."
    new "من واقعاً فکر می‌کنم هر لباسی که انتخاب می‌کنی برایت مناسب است، مهم‌ترین چیز اینه که تو چطور احساس می‌کنی."

    # say L1180 hin
    old "Thank you, [pla]. I really appreciate it..."
    new "ممنون، [pla]. واقعاً از این قدر می‌باشم..."

    # say L1182 pla
    old "My pleasure... So, see you this afternoon?"
    new "لذت من بود... پس، بعد از ظهر می‌بینم؟"

    # say L1184 hin
    old "For sure, see you in the afternoon."
    new "حتماً، بعد از ظهر می‌بینیم."

    # say L1186 pla
    old "Great. Bye."
    new "عالی. خداحافظ."

    # say L1217 joh
    old "Hi guys! Ready for the last session?"
    new "سلام بچه‌ها! آماده‌این برای آخرین جلسه؟"

    # say L1219 hin
    old "Is this the last session?"
    new "این آخرین جلسه است؟"

    # say L1221 joh
    old "Yes, you have advanced very well with the therapy."
    new "بله، تو درمان را خوب پیش برده‌ای."

    # say L1222 joh
    old "And have managed to gain more security in yourself and in your body and that was the objective."
    new "و توانستی امنیت بیشتری در خودت و بدنات پیدا کنی و این هدف ما بود."

    # say L1224 hin
    old "But... I- I don't feel... Ready."
    new "اما... من- من حس نمی‌کنم... آماده باشم."

    # say L1226 joh
    old "Well... We still have this session, right?"
    new "خب... هنوز این جلسه رو داریم، درسته؟"

    # say L1228 hin
    old "Hmm... ok..."
    new "Hmm... خب..."

    # say L1230 joh
    old "All right for this last one I told you that you didn't need to bring any more clothes [pla]."
    new "باشه برای این آخری به تو گفتم که نباید لباس بیشتری بیاوری [pla]."

    # say L1232 joh
    old "And that's because this last session we are going to do an exercise of accepting your own body."
    new "و این به خاطر این هست که در این جلسه آخر ما تمرینی برای پذیرش بدن خودت انجام می‌دهیم."

    # say L1235 joh
    old "Right, little by little you started to wear clothes that exposed more of your body, this time there will be nothing covering your body..."
    new "بله، تدریجی شروع کردی به پوشیدن لباس‌هایی که بیشتر بدن‌ت رو نشون می‌داد، این بار هیچ چیز بدن‌ت رو پوشش نمی‌ده..."

    # say L1237 hin
    old "So?"
    new "پس؟"

    # say L1239 joh
    old "Right, this time you'll be naked."
    new "بله، این بار تو خالی‌باز خواهی بود."

    # say L1245 joh
    old "Come on girl, that's not much different from what you've already done before."
    new "بیا دختر، این خیلی متفاوت از آنچه قبلاً انجام دادی نیست."

    # say L1250 joh
    old "Just let's go girl, Your body is natural, your body is perfect."
    new "بیای دختر، بدن تو طبیعیه، بدن تو کامله."

    # say L1265 joh
    old "Well, I think we're ready!"
    new "خب، فکر کنم آماده‌ایم!"

    # say L1268 joh
    old "How are you feeling my dear?"
    new "حالت چطوره عزیزم؟"

    # say L1270 hin
    old "I don't feel very good..."
    new "حالت خوب نیست..."

    # say L1272 joh
    old "But come on it's very natural, that's your body and it's beautiful, right [pla]?"
    new "ولی بیای بگو، این خیلی طبیعیه، این بدنتو هست و زیباست، درسته [pla]؟"

    # say L1275 joh
    old "Hahaha again in silence?"
    new "هahaha دوباره صامت شدی؟"

    # say L1277 joh
    old "I guess you guys will have played around a bit since the last lesson I gave you, right?"
    new "بگو خوب، از آخرین درسی که به تو دادم، شاید یکم با هم بازی کرده‌ای، درسته؟"

    # say L1279 hin
    old "... No, we haven't..."
    new "نه، ما نه..."

    # say L1281 joh
    old "Oh really? That's a shame."
    new "اوه وای؟ این خیلی خیالی است."

    # say L1283 joh
    old "You know what I'll give you another free lesson, would you like to?"
    new "میدونی چی؟ من دوباره یه درس رایگان بهت میدم، میخوای؟"

    # say L1288 joh
    old "Hahaha, what are you trying to hide [pla] and Hinn's embarrassed face says yes."
    new "حاحاحا، می‌خوای چی رو پوشش بدی [pla] و چهره خجسته هین می‌گه بله."

    # say L1290 joh
    old "Okay, but only because it's our last session together."
    new "البته، ولی فقط چون این آخرین جلسه‌ی ما با هم است."

    # say L1292 joh
    old "Come here Hinn, I'll teach you how to take the next step in male pleasure."
    new "اونجا بیا هین، من بهت یادم دم که چجوری مرحله بعدی لذت مردانه رو تجربه کنی."

    # say L1301 joh
    old "Very well, you take it in your hand and this time you use your mouth."
    new "بسیار خب، شما آن را در دست خود بگیرید و این بار از دهان خود استفاده کنید."

    # say L1302 joh
    old "You must pay close attention to the head, it is the most pleasant area"
    new "باید به سر خوب توجه کنی، این منطقه لذت‌بخش‌ترین است."

    # say L1303 joh
    old "So, you should use your tongue and lips to stimulate that whole area."
    new "پس باید با زبان و لب‌هایتان آن منطقه را تحریک کنید."

    # say L1315 joh
    old "Well, you've been naked for over 10 min, in front of us and you look pretty comfortable with that."
    new "خب، تو بیش از ۱۰ دقیقه عریان جلوی ما هستی و به نظر می‌رسه با این وضعیت خیلی راحتی داری."

    # say L1317 joh
    old "That is proof that my work is already done."
    new "این اثبات می‌کنه که کار من قبلاً تمام شده."

    # say L1319 hin
    old "Thank you very much Dr. Johnson."
    new "ممنونم دکتر جانسون."

    # say L1321 joh
    old "But girl you can get dressed now, you don't have to be naked all the time..."
    new "اما دختر، حالا می‌تونی لباس بپوشی، نمی‌تونی همیشه عریان باشی..."

    # say L1323 hin
    old "... Sorry."
    new "... معذرت."

    # say L1325 joh
    old "Hahaha."
    new "حاحاحا."

    # say L1332 joh
    old "Well this is it, I hope the sessions and the little lessons have helped you, enjoy your sexuality and your youth guys!"
    new "خب این همه است، امیدوارم جلسات و درس‌های کوچک به شما کمک کرده باشند، از جوانی و جنسیت خود لذت ببرید بچه‌ها!"

    # say L1336 joh
    old "I hope you do very well."
    new "امیدوارم خوب انجام بدید."

    # say L1345 pla
    old "How did you feel in today's session?"
    new "امروز جلسه چطور بود؟"

    # say L1347 hin
    old "I think it was exciting..."
    new "فکر کنم هیجان‌انگیز بود..."

    # say L1349 pla
    old "Ehmm, yes, it was exciting, right?"
    new "اهم، بله، هیجان‌انگیز بود، درسته؟"

    # say L1351 hin
    old "Did you like it?"
    new "تو خوشت اومد؟"

    # say L1353 pla
    old "Well... Yes."
    new "خب... بله."

    # say L1355 hin
    old "I liked too."
    new "من هم خوشت اومد."

    # say L1359 pla
    old "Ok, then see you tomorrow?"
    new "خب، پس فردا می‌بینیم؟"

    # say L1398 pla
    old "See you, Hinn."
    new "ببینم، هین."

    # say L1412 pla
    old "Yes! We finally did it! We finished the project, even Mrs. Mia was happy with it!"
    new "بله! در نهایت انجامش دادیم! پروژه رو تمام کردیم، حتی خانم میا هم راضی بود!"

    # say L1414 hin
    old "Great, now that we're done, I want to ask you if... Will you continue to accompany me to therapy sessions?"
    new "عالی، حالا که تمام شد، می‌خوام ازت بپرسم... آیا همچنان قراره با من به جلسات درمانی برسی؟"

    # say L1418 hin
    old "FOR REAL?"
    new "حق باهات؟"

    # say L1420 hin
    old "I mean... Seriously?"
    new "من قصه‌ای... جدی؟"

    # say L1422 pla
    old "Sure! Well, only if you want too."
    new "بله! البته اگه خودت هم بخوای."

    # say L1424 hin
    old "Yes, I would like it! You have helped me a lot and I would like to continue hanging out with you."
    new "بله، من می‌خوام! تو خیلی به من کمک کردی و می‌خوام با تو همچنان همراه باشم."

    # say L1426 pla
    old "You can always count on me, Hinn."
    new "می‌تونی همیشه بر من حساب کنی، هین."

    # say L1428 hin
    old "...Thank you, [pla]! I really mean it."
    new "...ممنونم، [pla]! من هم همینطور فکر می‌کنم."

    # say L1430 hin
    old "But how are you going to keep the sessions going, Doctor Johnson said we were done."
    new "ولی چطور می‌تونی جلسات رو ادامه بدهی، دکتر جانسون گفت که تمام شد."

    # say L1432 pla
    old "Hmm... Let me talk to her and see what I can do."
    new "Hmm... بیای دیدم چه کاری می‌تونم کرد."

    # say L1434 hin
    old "Great! I hope you can convince her..."
    new "عالی! امیدوارم بتونی قانعش کنی..."

    # say L1436 pla
    old "Yes me too."
    new "بله من هم همین امیدوارم."

    # say L1459 ang
    old "Thank you very much Dr. Johnson, today's session was great."
    new "ممنونم دکتر جانسون، جلسه امروز عالی بود."

    # say L1463 joh
    old "I hope these tips help you, in the next session and we will analyze the progress."
    new "امیدوارم این نکات به شما کمک کنند، در جلسه بعد پیشرفت را بررسی خواهیم کرد."

    # say L1465 ang
    old "Very well, goodbye doctor."
    new "خوب بود، خداحافظ دکتر."

    # say L1467 joh
    old "Bye bye."
    new "خدا حافظ."

    # say L1471 joh
    old "Hey, hello [pla] how are you doing?"
    new "سلام ز[pla]، اوضاعت چطوره؟"

    # say L1473 pla
    old "I'm doing good Dr. Johnson."
    new "من خوب هستم دکتر جانسون."

    # say L1475 joh
    old "How can I help you?"
    new "چطور می‌توانم به شما کمک کنم؟"

    # say L1477 pla
    old "Well... I've been thinking with Hinn... And we wonder if we can continue with the..."
    new "خوب... من با هین فکر کرده‌ام... و می‌خواهیم بدانیم آیا می‌توانیم ادامه دهیم با..."

    # say L1479 joh
    old "With the?"
    new "با؟"

    # say L1481 pla
    old "If we can continue with the therapy?"
    new "آیا می‌توانیم ادامه درمان رو بدهیم؟"

    # say L1483 joh
    old "Oh, Hmm... I made an exception with you guys since that kind of session is for couple therapy..."
    new "اوه، هم... استثنا برای شما دو نفر کردم زیرا این جلسات برای درمان زوج‌ها هستند..."

    # say L1485 pla
    old "Hmm, could we get some more of those?"
    new "Hmm، می‌تونیم یه کمی بیشتر از اونا بگیریم؟"

    # say L1487 joh
    old "I don't think so, I'm sorry [pla]..."
    new "من فکر نمی‌کنم، ببخشید [pla]..."

    # say L1489 pla
    old "(Hmm... I think I should use it this time...)"
    new "ممکنه این بار از اون استفاده کنم؟"

    # say L1493 joh
    old "Hmm, you know what, let's make a deal..."
    new "Hmm، می‌دونی چی، بیاین توافقی بکنیم..."

    # say L1495 joh
    old "I'll give those therapy sessions if you help me with another patients exercise, I think you could help me with them..."
    new "من این جلسات درمانی رو برای شما انجام می‌دم اگر به من در تمرینات بیمار دیگری کمک کنید، فکر می‌کنم می‌تونید به من کمک کنید..."

    # say L1497 pla
    old "Help with another patients?"
    new "با بیماران دیگر کمک کنم؟"

    # say L1499 joh
    old "Yes, I actually have a case where I think you would be a great help..."
    new "بله، در واقع یک مورد دارم که فکر می‌کنم می‌توانی به من کمک کنی..."

    # say L1501 pla
    old "Hmm okay, and will the therapy continue in return?"
    new "Hmm خب، و درمان هم به صورت متقابل ادامه خواهد داشت؟"

    # say L1503 joh
    old "Yes, I think it is an excellent deal."
    new "بله، فکر می‌کنم این قرارداد عالی است."

    # say L1505 pla
    old "Very well then, Hinn will schedule the appointment for the next lesson."
    new "بسیار خب، هین زمان جلسه بعد را تعیین خواهد کرد."

    # say L1507 joh
    old "Perfect, I'll let you know when I need you to work with my patient."
    new "البته، وقتی نیاز داشتم که با بیمار من همکاری کنی، اطلاع می‌دهم."

    # say L1509 pla
    old "Understood."
    new "فهمیدم."

    # say L1516 hin
    old "Well? What happened?"
    new "خب؟ چه اتفاقی افتاد؟"

    # say L1518 pla
    old "Everything is settled, you just have to call her to make the next appointment."
    new "همه چیز حل شد، فقط باید برای نوبت بعدی باهاش تماس بگیری."

    # say L1520 hin
    old "Really? Excellent! I'll call her right away, thanks [pla]."
    new "حقاً؟ عالی! همین حالا ازش تماس می‌گیرم، ممنون [pla]."

    # say L1522 pla
    old "No problem. Then, see you tomorrow?"
    new "هیچ اشکالی. پس، فردا می‌بینیم؟"

    # say L1547 joh
    old "Wow Hinn, you decided to not wear the jacket, I see that the sessions served you well."
    new "واو هین، فکر کنم جلسات برایت خوب بوده. متوجه شدم که پوستک رو نپوشیدی."

    # say L1552 joh
    old "Well, you're looking forward to continuing my therapy, uh?"
    new "خب، شما به ادامه درمان خودتون علاقه دارید، همین‌طور؟"

    # say L1556 pla
    old "Well... "
    new "خب..."

    # say L1558 joh
    old "Hahaha I like to give therapy, so, don't worry guys."
    new "حاحاحا من دوست دارم درمان بدهم، پس نگران نباشید."

    # say L1560 joh
    old "I think I've already given you a good introduction, what do you say if we go to Hinn's practice?"
    new "من فکر می‌کنم قبلاً مقدمه خوبی به شما دادم، چطور می‌گویید اگر به مطب هین برویم؟"

    # say L1564 joh
    old "Come on girl, don't be shy, after all you guys asked me for more lessons, right?"
    new "بیا دختر، نباشی خجالتی، در نهایت شماها از من درس بیشتر خواسته‌اید، درسته؟"

    # say L1566 hin
    old "Yes, yes, I'm sorry..."
    new "بله، بله، معذرت..."

    # say L1568 joh
    old "All right, let's go step by step, ok?"
    new "باشه، بیایید مرحله به مرحله برگردیم، خوب؟"

    # say L1572 joh
    old "[pla] take off your shorts and sit on the couch, you come with me Hinn..."
    new "[pla] پانتالونت رو ببرد و روی مبل بنشین، تو با من بیا هین..."

    # say L1580 joh
    old "Oh yeah take it like that, fill your hand completely right?"
    new "بله، همینطور کن، دستت رو کاملاً پر کن، درسته؟"

    # say L1582 joh
    old "How does it feel Hinn..."
    new "حاسه چطور هین..."

    # say L1583 hin
    old "Warm and... Hard..."
    new "گرم و... سخت..."

    # say L1585 joh
    old "Hahaha the advantages of youth."
    new "خخخ مزایای جوانی."

    # say L1598 joh
    old "All right guys I think that's it for this lesson."
    new "بچه‌ها خوب فکر کنم این جلسه به پایان رسید."

    # say L1600 joh
    old "I think you both enjoyed it a lot, and you already have some things to practice at home..."
    new "فکر می‌کنم هر دوی شما خیلی لذت برده‌اید و قطعاً چیزهایی برای تمرین در خانه دارید..."

    # say L1604 joh
    old "It was really a pleasure guys, I'll wait for you for the next lesson..."
    new "خوشحالم، جون، منتظر شما برای درس بعدی هستم..."

    # say L1611 hin
    old "That was... Fun."
    new "این... لذت‌بخش بود."

    # say L1613 pla
    old "Yes, I think it was... Very educational."
    new "بله، فکر کنم بود... خیلی آموزنده."

    # say L1615 hin
    old "Hehehe yes it was..."
    new "هههه بله بود..."

    # say L1621 pla
    old "Well, see you tomorrow Hinn."
    new "خب، ببینم فردا هین."

    # say L1640 pla
    old "Hi Hinn, how are you?"
    new "سلام هین، چطوری؟"

    # say L1642 hin
    old "I'm great-"
    new "من عالی هستم-"

    # say L1650 rub
    old "Wow, did you lose your ugly sweatshirt girl?"
    new "وای، آیا پوشش خشنودت رو افتادی دختر؟"

    # say L1654 rub
    old "Yes, don't you feel sorry to show that fatness?"
    new "بله، آیا از نشون دادن اون چربی خودت ناراحت نیستی؟"

    # say L1656 pla
    old "Really, you aga-"
    new "وای، واقعاً تو اگه-"

    # say L1658 hin
    old "Are you talking about my big boobs? You envious Ruby jerk?"
    new "آیا درباره سینه‌های بزرگ من صحبت می‌کنی؟ تو حسادتی روبلی!"

    # say L1660 rub
    old "What ?! I envy? I don't know what-"
    new "چه؟! من حسادت می‌کنم؟ نمی‌دونم چه-"

    # say L1662 hin
    old "Ohh sorry, I'm a woman with a really good body and some brain..."
    new "اوه خواهش می‌کنم، من یک زن با بدن خوب و مغزی هستم..."

    # say L1664 oli
    old "Ouchh..."
    new "اوه آوایی..."

    # say L1668 hin
    old "Ohh I'm sorry, was it too much for your little head? Maybe tomorrow you will understand it..."
    new "اوه خواهش می‌کنم، آیا برای سرت کوچک خیلی زیاد بود؟ شاید فردا متوجه بشی..."

    # say L1670 hin
    old "Right now I don't have time to waste with a couple of stupid brainless girls like you. See ya..."
    new "الان وقت ندارم با چند تا دختر بی‌مغز مثل تو بگذرم. ببینی..."

    # say L1679 pla
    old "Hehehe see ya..."
    new "هههه خداحافظ..."

    # say L1681 rub
    old "Oh you shut up, loser!"
    new "ببین تو بنشین، خسرو!"

    # say L1683 pla
    old "Ugh, sorry..."
    new "اوه، معذرت..."

    # say L1693 pla
    old "Wow Hinn that was great!"
    new "وای هین، خوب بود!"

    # say L1695 hin
    old "It doesn't matter, come sit on the couch."
    new "اهمیتی نداره، بیا روی مبل بنشین."

    # say L1697 pla
    old "What? What for?"
    new "چه کاری؟ برای چه؟"

    # say L1699 hin
    old "I'm going to suck it you, sit down..."
    new "من قراره اونو شیر کنم، بنشین..."

    # say L1701 pla
    old "(What the...) All right."
    new "(چه کاری...) خوب."

    # say L1712 pla
    old "Are you sure-"
    new "مطمئنی-"

    # say L1715 hin
    old "You just watch and enjoy."
    new "تو فقط ببین و لذت ببر."

    # say L1729 hin
    old "Sorry, sorry. I was so impulsive... I just felt adrenaline after what happened and I wanted to try-"
    new "ببخشید، ببخشید. من خیلی تندخوی بودم... فقط هورمون‌های آدرنالین پس از اون حالت بالا آمد و می‌خواستم امتحان کنم-"

    # say L1731 pla
    old "No, don't worry, I'm amazed at your progress, you're more confident."
    new "نه، نگران نباش، من از پیشرفتت شگفت‌زده‌ام، خیلی اعتماد به نفس‌تر شدی."

    # say L1733 pla
    old "And I like that."
    new "و من هم دوست دارم."

    # say L1737 pla
    old "Yes, it was exciting."
    new "بله، خیلی هیجان‌انگیز بود."

    # say L1739 hin
    old "I think Dr. Johnson has helped a lot."
    new "من فکر می‌کنم دکتر جانسون خیلی کمک کرده."

    # say L1741 pla
    old "You bet she has..."
    new "بله، قطعاً کمک زیادی کرده."

    # say L1745 hin
    old "Well, I think my mom will be here soon, we can continue tomorrow, what do you think?"
    new "خب، فکر کنم مامان هم زود بر می‌یاد، می‌تونیم فردا ادامه بدیم، تو چطور؟"

    # say L1747 pla
    old "Sure, see you tomorrow Hinn."
    new "بله، دوست دارم. ببینم چه کاری می‌کنی فردا، هین."

    # say L1767 pla
    old "I love it."
    new "من هم دوست دارم."

    # say L1769 hin
    old "I'm glad you liked."
    new "خوشحالم که دوست داشتی."

    # say L1771 hin
    old "Whenever you want another one we could practice again."
    new "هر وقت می‌خوای دیگه هم می‌تونیم تمرین کنیم."

    # say L1775 hin
    old "Great. See you tomorrow."
    new "عالی. ببینم چه کاری می‌کنی فردا."

    # say L1777 pla
    old "Good night Hinn."
    new "شب خوبی هین."

    # say L1797 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy session."
    new "ممنون [pla]. من منتظرت بودم، امروز جلسه درمان جدید هست."

    # say L1809 joh
    old "Hi guys! Think you're ready to go on with the lessons, uh?"
    new "سلام همه! فکر کنم آماده‌اید برای ادامه درس‌ها، نه؟"

    # say L1811 hin
    old "Yes, but we would like to try something more advanced..."
    new "بله، اما ما می‌خواهیم چیزی پیشرفته‌تر رو امتحان کنیم..."

    # say L1815 joh
    old "Hahaha, that's what I wanted to hear. And what about you [pla]? Ready for the next level?"
    new "حاحاحا، این همین بود که می‌خواستم بشنوم. و تو [pla]، آماده‌ای برای مرحله بعدی؟"

    # say L1817 pla
    old "... Well-"
    new "... خب-"

    # say L1819 joh
    old "Great, let's not waste any more time..."
    new "عالی، بیایید زمان بیشتری را ضایع نکنیم..."

    # say L1821 joh
    old "Let's heat the situation up a bit, since you want something more advanced Hinn, let's try a double blowjob."
    new "بیایید شرایط رو گرم کنیم یه کم، چون می‌خوای چیزی پیشرفته‌تر، هین، بیایید امتحان کنیم که دو تا همزمان."

    # say L1823 joh
    old "I hope it's not too much for you..."
    new "امیدوارم برای تو خیلی سنگین نباشه..."

    # say L1825 hin
    old "Okay, let's try it."
    new "باشه، بیاین امتحان کنیم."

    # say L1827 joh
    old "Hahaha who are you and what did you do with Hinn?"
    new "هahaha کی هستی و چه کاری با هین انجام دادی؟"

    # say L1829 joh
    old "All right [pla] down your pants and Hinn you bend down with me."
    new "باشه [pla] روی لباست بیا و هین، با من خم شو."

    # say L1836 joh
    old "With your tongue, stimulate the tip of the penis."
    new "با زبانت، سر پیشوند رو تحریک کن."

    # say L1837 joh
    old "This drives any man crazy..."
    new "این هر مرد رو دیوانه می‌کنه..."

    # say L1849 joh
    old "Hmm, I think you guys are ready to do it right?"
    new "Hmm، فکر کنم شماها آماده هستید که درست انجام بدید؟"

    # say L1851 pla
    old "Do... What?"
    new "اوه... چه کاری؟"

    # say L1853 joh
    old "Fuck, let's fuck guys..."
    new "بیایید، بیایید با هم سکس کنیم..."

    # say L1857 joh
    old "Come with me."
    new "با من بیایید."

    # say L1866 joh
    old "This is a practice room that I use with some patients."
    new "این اتاق تمرینی است که من با برخی بیماران استفاده می‌کنم."

    # say L1868 joh
    old "Come on guys take off your clothes, today you are going to have sex!"
    new "بیایید لباس‌هایتان را بگذارید، امروز قراره جنس کنید!"

    # say L1876 joh
    old "What's up [pla]? Now are you the shy one?"
    new "چه خبر [pla]؟ حالا شما خجالتی هستید؟"

    # say L1878 joh
    old "Maybe you need some example..."
    new "شاید به یک مثال نیاز دارید..."

    # say L1884 joh
    old "Well? What are you waiting for, you're the only one with clothes, don't you want to fuck this cute Hinn?"
    new "خب؟ منتظر چی هستی، تنها کسی که لباس داری هستی، آیا نمی‌خوای این حن خوب را بفراموش کنی؟"

    # say L1894 joh
    old "All right, as I know this is probably your first time, let's go smooth and slow..."
    new "باشه، میدونم احتمالاً اولین بارت هست، بیایید آرام و آهسته شروع کنیم..."

    # say L1895 joh
    old "Let me lubricate it well before we start."
    new "بیای برامون خوب آماده کنم قبل از شروع."

    # say L1907 joh
    old "Well guys, I hope to see you for a lesson soon... You can continue your practices in the meantime."
    new "خب دوستان، امیدوارم زودی برای یک درس با من بیایید... می‌تونید در این میان تمرین‌های خودتون رو ادامه بدید."

    # say L1909 hin
    old "Yes, it was a lot of fun."
    new "بله، خیلی لذت بر بود."

    # say L1911 joh
    old "Great, I think that's it for today let's get dressed and go to the office."
    new "عالی، فکر کنم برای امروز کافیه. بیایید لباس‌مون رو بپوشیم و به دفتر برویم."

    # say L1919 joh
    old "Well guys, I hope to see you for a next lesson soon... You can continue your practices in the meantime."
    new "خب دوستان، امیدوارم در جلسه بعدی هم بیایید... در این میان می‌تونید تمرین‌های خودتون رو ادامه بدید."

    # say L1923 joh
    old "Alright, see you in the next lesson."
    new "البته، تا دوره بعدی می‌بینیم."

    # say L1962 hin
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy sesion."
    new "من خوبم ممنون [pla]. منتظرت بودم، امروز جلسه درمان جدیده."

    # say L1974 joh
    old "What do we have here? Ready for another hardcore sex lesson?"
    new "چه چیزی داریم؟ آماده‌ی درس جدید سکس هستی؟"

    # say L1980 joh
    old "Haha that's great..."
    new "هه هه خوبه..."

    # say L1982 hin
    old "So, are we going to the couch?"
    new "پس، ما می‌رویم به مبل؟"

    # say L1984 joh
    old "Ohh no, let's not waste time, let's go directly to a more comfortable place..."
    new "اوه نه، بیایید وقت نباشیم، برویم مستقیماً به جایی راحت‌تر..."

    # say L1992 joh
    old "Alright lie down on the bed [pla] and Hinn get on top of him."
    new "باشه، روی تخت بخواب [pla] و هین، رویش بنشین."

    # say L1994 joh
    old "We're going to lubricate that cock well while [pla] giving you some pleasure."
    new "ما آن نیم‌شاخ رو خوب روغن می‌دهیم در حالی که [pla] لذت می‌دهیم به تو."

    # say L2010 joh
    old "All right, are you ready for another hardfuck Hinn?"
    new "باشه، آماده‌ای برای یه سکس سخت دیگه هین؟"

    # say L2014 joh
    old "I've seen that [pla] has been looking at my big boobs a lot, uh?"
    new "دیدم که [pla] به سینه‌های بزرگ من خیلی نگاه کرده، همین‌جوری؟"

    # say L2016 pla
    old "... No, no, I just-"
    new "نه، نه، من فقط-"

    # say L2018 joh
    old "Hahaha, come on I've already sucked your penis, there's no reason to be ashamed."
    new "هه هه هه، بیا، من قبلاً نیتت رو شصت کردم، هیچ دلیلی برای خجولی نداری."

    # say L2020 joh
    old "Actually, today while you fuck Hinn you are going to enjoy my soft and big boobs..."
    new "در واقع، امروز هنگامی که تو Hinn رو می‌پردازی، از سینه‌های نرم و بزرگ من لذت ببری..."

    # say L2036 joh
    old "Another successful session guys... Let's get dressed."
    new "پیش زمینه موفقیت‌آمیزی دیگر بود... بیایید لباس‌مون رو بگذاریم."

    # say L2044 joh
    old "All right that's it for today, I hope to see you soon for a next lesson guys."
    new "البته، امیدوارم زودترین وقت رو برای جلسه بعدی ببینم دوستان."

    # say L2046 hin
    old "Of course we will Dr. Johnson."
    new "البته خواهیم آمد دکتر جانسون."

    # say L2097 joh
    old "Oh, but here are my favorite patients... Hehehe."
    new "اوه، اما اینجا بیماران مورد علاقه‌ام هستند... هههه."

    # say L2099 hin
    old "Good afternoon Dr. Johnson."
    new "بعد از ظهر دکتر جانسون."

    # say L2101 joh
    old "How are you guys? Ready for our last lesson?"
    new "اوضا، شماها چطورید؟ آماده‌این برای آخرین جلسه‌مون؟"

    # say L2103 pla
    old "Last lesson?"
    new "آخرین درس؟"

    # say L2105 joh
    old "Yes, I think you already have the basics, it is important that you now experience for yourselves to discover your own sexuality."
    new "بله، فکر کنم شما قاعده‌های اصلی را قبلاً یاد گرفته‌اید، مهم است که حالا خودتان تجربه کنید تا جنسیت خود را کشف کنید."

    # say L2107 hin
    old "But... Can't we go on?"
    new "ولی... نمی‌تونیم ادامه بدیم؟"

    # say L2109 joh
    old "Well, we could repeat some of the lessons we've already done..."
    new "خب، می‌تونیم برخی از درس‌هایی که قبلاً گرفتیم رو تکرار کنیم..."

    # say L2111 hin
    old "Oh great, sounds good..."
    new "عالی، خوبه..."

    # say L2113 pla
    old "So, what will we do today?"
    new "پس، امروز چه کاری می‌کنیم؟"

    # say L2115 joh
    old "Let's go to the room and I'll explain."
    new "بیایید به اتاق برویم و من توضیح می‌دم."

    # say L2123 joh
    old "All right, let's heat things up a bit by lubricating it well, you know what to do."
    new "باشه، بیایید یکم گرم کنیم با خوب روغن زدن، می‌دونی چه کاری باید بکنی."

    # say L2137 joh
    old "Well, that was great, now you [pla] are going to fuck Hinn alone."
    new "خوب، این خوب بود، حالا تو [pla] می‌تونی هین رو تنها بفراموشی."

    # say L2139 pla
    old "Alone?"
    new "تنهایی؟"

    # say L2141 joh
    old "Yes, I will just be watching, the idea is that you can continue to do it yourself so that you can enjoy your sexuality alone."
    new "بله، من فقط مشاهده خواهم کرد، هدف این است که تو بتوانی خودت ادامه دهی و از جنسیت خود لذت ببری."

    # say L2143 pla
    old "Hmm ok."
    new "Hmm خب."

    # say L2162 joh
    old "Well guys, that was it for today, get dressed."
    new "خب بچه‌ها، این همه بود برای امروز، لباس‌تون رو بپوشید."

    # say L2170 joh
    old "I think it's time for you to practice what you learned. Enjoy it guys!"
    new "من فکر می‌کنم وقت برای اینه که آنچه یاد گرفتید را تمرین کنید. لذت ببرید بچه‌ها!"

    # say L2172 joh
    old "If you want to repeat one of the lessons, don't hesitate to come back."
    new "اگر می‌خوای یکی از درس‌ها رو تکرار کنی، نباید هیچ تردیدی داشته باشی که برگردی."

    # say L2212 hin
    old "I'm great, What about you?"
    new "من خوبم، شما چطورید؟"

    # say L2216 hin
    old "So? Would you like to repeat some session with Dr. Johnson?"
    new "پس؟ آیا می‌خواهی برخی جلسات رو با دکتر جانسون تکرار کنی؟"

    # say L2221 pla
    old "Of course! Let's do it."
    new "البته! بیایم."

    # say L2230 pla
    old "I really would like to... But I can't right now."
    new "من واقعاً می‌خواستم... اما الان نمی‌تونم."

    # say L2232 hin
    old "Oh don't worry you can look for me if you change your mind."
    new "اوه نگران نباش، اگر رأیت تغییر کرد به من بگو."

    # say L2234 pla
    old "I will do it."
    new "من انجام می‌دم."

    # say L2255 joh
    old "I knew it would not take long for you to return from the last session."
    new "میدونستم طول نمی‌بره تا از جلسه قبل برگردی."

    # say L2257 joh
    old "So? What do you want to do today guys?"
    new "پس؟ شماها امروز چی می‌خواهید بکنید؟"

    # say L2269 joh
    old "Oh, you guys want to go from the beginning, right?"
    new "اوه، شماها می‌خواهید از اول شروع کنیم، درسته؟"

    # say L2273 joh
    old "I like it! Let's do it."
    new "می‌پسندم! بیایید انجام بدیم."

    # say L2283 joh
    old "It always surprises me!"
    new "همیشه من را شگفت‌زده می‌کند!"

    # say L2290 joh
    old "Well, let's do it..."
    new "خب، بیایید انجام بدیم..."

    # say L2304 joh
    old "Do you need another blowjob lesson? Uh? Or just [pla] want a good blowjob from me?"
    new "آیا نیاز داری به درس بعدی زدن زنگ؟ یا فقط [pla] می‌خوای از من یک زدن زنگ خوب بگیری؟"

    # say L2308 joh
    old "Anyway... I like it! Let's do it."
    new "با هر حال... من دوست دارم! بیاین انجام بدیم."

    # say L2329 joh
    old "O third lesson, let's team up to give [pla] a great amount of pleasure!"
    new "درس سوم، بیایید همکاری کنیم تا [pla] لذت زیادی ببریم!"

    # say L2342 joh
    old "Your cock is in one of biggest I've ever saw."
    new "پنجه‌ات در میان بزرگ‌ترین‌هایی هست که تا حال دیدم."

    # say L2355 joh
    old "Double blowjob and Doggystyle? How great does it sounds?"
    new "دبل جاب و داستایل؟ چقدر عالی به نظر می‌رسه؟"

    # say L2367 joh
    old "And you are becoming some kind of expert Hinn!"
    new "و شما در حال تبدیل شدن به متخصص هین هستید!"

    # menu L2372 
    old "Lesson 5"
    new "درس ۵"

    # say L2380 joh
    old "Do you want to have my boobs on your face while you fuck Hinn, uh?"
    new "آیا می‌خواهی تا نیمروی من روی چهره‌ت باشه در حالی که تو با هین سکس می‌کنی، هه؟"

    # menu L2403 
    old "Lesson 6"
    new "درس ۶"

    # say L2411 joh
    old "Oh god, I'm dying to see that pretty face covered with a good facial."
    new "اوه خدا، من مردم خواهم دید آن چهره زیبا رو با یک جیز خوب پوشانده شود."

    # say L2423 joh
    old "Alright lie down on the bed [pla] and your Hinn get on top of him."
    new "باشه، روی تخت بخواب [pla] و هین رویش بنشین."

    # say L2440 joh
    old "All right guys, that was fun, but it's all for today."
    new "باشه دوستان، این خوشحالم کننده بود، اما برای امروز کافیه."

    # say L2444 hin
    old "Will come back soon..."
    new "به زودی برگشتم..."

    # say L2446 joh
    old "I will be waiting."
    new "منتظر خواهم ماندم."

    # say L2448 pla
    old "See you soon Dr Johnson."
    new "به زودی می‌بینیم دکتر جانسون."

    # say L2457 hin
    old "That was hot, right?"
    new "این گرم بود، درسته؟"

    # say L2459 pla
    old "Yes, it was great."
    new "بله، خیلی خوب بود."

    # say L2461 hin
    old "Hehehe do want to repeat it tomorrow?"
    new "هههه آیا دوست داری فردا تکرارش کنیم؟"

    # say L2465 hin
    old "Nice, then see you tomorrow [pla]."
    new "خوب، پس فردا می‌بینیم [pla]."

    # say L2467 pla
    old "Ok, see you tomorrow Hinn."
    new "باشه، ببینمتم فردا هین."


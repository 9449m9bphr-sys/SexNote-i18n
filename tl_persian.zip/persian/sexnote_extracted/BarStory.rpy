# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/BarStory.rpy
translate persian strings:

    # say L4 bri
    old "Hey [pla], wake up!"
    new "هی ز[pla]، بیدار شو!"

    # say L5 pla
    old "Hmm... Just a little longer..."
    new "همم... فقط یه کمی بیشتر..."

    # say L6 bri
    old "I said..."
    new "من گفتم..."

    # say L13 pla
    old "What? What's happening? Is there anything wrong?!"
    new "چی؟ چه خبر؟ مشکلی هست؟!"

    # say L14 bri
    old "What's wrong is that it's been a while since I created the portal we're going to use to restore the magic world."
    new "مشکل اینجاست که از آن موقع که من دروازه‌ای ساختم تا برای بازگرداندن جهان جادویی استفاده کنیم، مدت زیادی گذشته."

    # say L16 bri
    old "But I haven't seen you make any progress with our objective ever since."
    new "اما از آن موقع هیچ پیشرفتی در هدفمون ندیدم."

    # say L17 bri
    old "Why is it taking so long for you to get to it?"
    new "چرا طول می‌کشه تا بهش برسی؟"

    # say L19 pla
    old "What?! You woke me up for that? What are you talking about?"
    new "چه کاری؟ بیدار کردی برای این؟ تو چه چیزی رو می‌گی؟"

    # say L20 pla
    old "It's not as if it's easy you know?"
    new "اینقدر آسون نیست، می‌دونی؟"

    # say L22 pla
    old "Do you want me to just walk around and tell people {i}'Hey! let me get you pregnant'{/i}?"
    new "می‌خوای از من برم و به مردم بگم {i}هی! بیا تو رو بارور کنم{/i}؟"

    # say L23 pla
    old "I can already imagine the looks I'll get."
    new "می‌تونم تصور بکنم چه نگاه‌هایی به من خواهند زد."

    # say L25 bri
    old "That's not what you're going to do! You have to seduce them!"
    new "این همچین کاری نیست! باید اونا رو فریب داد!"

    # say L27 bri
    old "I thought you were supposed to be charming to human females."
    new "فکر می‌کردم باید برای زنان انسانی جذاب باشی."

    # say L29 bri
    old "Try that!"
    new "آزمایشش کن!"

    # say L33 pla
    old "Why are you so worried about me doing it quickly anyway?"
    new "چرا اصلاً نگرانی که من سریع انجام بدم؟"

    # say L35 pla
    old "I thought you had stabilized the portal. So we have time, right?"
    new "من فکر می‌کردم پرتال رو ثابت کردی. پس وقت داریم، درسته؟"

    # say L36 bri
    old "Yeah, time to do the ritual properly."
    new "بله، وقت برای انجام مراسم به درستی وجود داره."

    # say L38 bri
    old "Not to laze around and not get anything done!"
    new "نباشیم و هیچ کاری انجام ندهیم!"

    # say L40 bri
    old "This is urgent business [pla]."
    new "این کار ضروریه [pla]."

    # say L42 bri
    old "The magic world is gone, and this portal might be the only chance we get to save it."
    new "دنیای جادویی رفت و این دروازه ممکن است تنها فرصت ما برای نجات آن باشد."

    # say L44 bri
    old "And the fact that it's stable for now doesn't mean it's going to last forever."
    new "و اینکه الان پایداره معنی‌اش این نیست که همیشه پایدار باشه."

    # say L46 bri
    old "If we want to reform the magic world we need to move fast!"
    new "اگه می‌خوایم جهان جادویی رو دوباره تشکیل بدیم باید سریع حرکت کنیم!"

    # say L48 bri
    old "There's no time to just lay about doing nothing."
    new "وقتی برای خوشبختی در حال گذشت نیست، نمی‌تونیم فقط نشسته باشیم و هیچ کاری نکنیم."

    # say L49 pla
    old "Ok, I get it I get it! I'll get to it!"
    new "باشه، متوجه شدم! همین الان می‌روم!"

    # say L50 bri
    old "When?"
    new "وقتی؟"

    # say L51 pla
    old "Soon!"
    new "به زودی!"

    # say L53 pla
    old "Jeez! What's gotten into you all of a sudden?!"
    new "جیز! اینجوری خودت رو چرا از یک لحظه به بعد عوض کردی؟!"

    # say L57 bri
    old "I'll remind you that you and your little friend Linnet made a mess out of this entire situation!"
    new "من به تو یادت می‌آورم که تو و دوست کوچولویت لینت این وضعیت رو خراب کردید!"

    # say L58 bri
    old "And I'm the one that's going to have to fix it!"
    new "و من هستم که باید این مشکل رو حل کنم!"

    # say L60 bri
    old "So, since the portal won't last forever, and you clearly don't want to re-start the process from the beginning..."
    new "پس، چون دروازه همیشه باز نمی‌مونه، و مشخصاً تو دوباره از اول شروع کردن رو خواسته نیستی..."

    # say L62 bri
    old "Start looking for the people we need!"
    new "بگرد برای افرادی که نیاز داریم!"

    # say L63 pla
    old "Ok, ok, I'll do it!... I guess I could start talking to people."
    new "باشه، باشه، انجام میدم!... فکر کنم میتونم شروع کنم با مردم صحبت کنم."

    # say L65 pla
    old "It's just that that's quite difficult to do, you know?"
    new "می‌دونی این کار خیلی سخته."

    # say L66 bri
    old "Oh come on, it won't be that bad."
    new "بیا بیا، اینقدر بد نمی‌شه."

    # say L68 bri
    old "I bet you'll get to have plenty of fun."
    new "من مطمئن هستم که خیلی لذت برده‌ای."

    # say L76 mo1
    old "Hello [pla], good morning."
    new "سلام ز[pla]، صبح بخیر."

    # say L79 pla
    old "H- hi [mo1rel], how are you? Good morning."
    new "ه- هی [mo1rel]، چطوری؟ صبح بخیر."

    # say L80 mo1
    old "Were you talking to someone?"
    new "با کسی حرف می‌زدی؟"

    # say L81 pla
    old "What? No, no, no..."
    new "چه؟ نه، نه، نه..."

    # say L82 pla
    old "Just to myself, you know?"
    new "به خودم حرف می‌زنم، می‌دونی؟"

    # say L83 mo1
    old "Ohh... Okay."
    new "اوه... خب."

    # say L85 mo1
    old "Listen [pla], I need you to do me a favor."
    new "بزرگوار، من ازت یک لطفی می‌خواهم [pla]."

    # say L91 mo1
    old "Hmm... [pla]?"
    new "همم... [pla]؟"

    # say L92 pla
    old "Uhh... Sure, what do you need?"
    new "اوه... البته، چه کاری می‌خوای؟"

    # say L94 mo1
    old "Well, I was wondering if you could please bring some documents to the [mo2]'s office for me."
    new "خب، فکر می‌کردم می‌تونی برای من مدارک رو به دفتر [mo2] ببری."

    # say L95 mo1
    old "You don't need to go up to her office, just leave them at the reception of the building."
    new "نیازی نداری به اتاق او بروی، فقط اسناد رو به دسترسی ساختمان ببر."

    # say L97 pla
    old "Sure, no problem."
    new "بله، هیچ اشکالی ندارم."

    # say L99 mo1
    old "Thank you so much, honey. You are always so helpful."
    new "ممنونم، عزیزم. همیشه اینقدر کمک‌کننده‌ای هستی."

    # say L107 bri
    old "Hmm... I suppose you're going to do that for your [mo1rel] now, aren't you?"
    new "هم... فکر کنم قراره اینجوری برای [mo1rel] کاری کنی، درسته؟"

    # say L108 pla
    old "Uhh... Yeah, Of course."
    new "اوه... بله، البته."

    # say L110 bri
    old "Okay, I'm coming with you. You won't stop our task, so I'll help you look for our first target."
    new "باشه، همراهت می‌آیم. نمی‌تونی از کارمون باز بیاد، پس بهت کمک می‌کنم برای هدف اولمون جستجو کنم."

    # say L112 pla
    old "{b}*Sigh*{/b} Alright, let's go."
    new "{b}*تنفر*{/b} خب، برویم."

    # say L139 bri
    old "So, as I was saying, you should've at least talked to somebody while we were coming here."
    new "پس، همانطور که می‌گفتم، باید حداقل با کسی صحبت می‌کردی در حالی که ما اینجا می‌آمدیم."

    # say L141 bri
    old "At this rate you're never going to end with what we have to do!"
    new "با این سرعت هیچ وقت به کاری که باید انجام بدی نمی‌رسی!"

    # say L142 bri
    old "You should be putting all your focus on that!"
    new "باید تمام تمرکزت رو به اون بگذاری!"

    # say L149 pla
    old "But I have to do this first! So let me finish here, and then we can start looking for people for your ritual!"
    new "ولی من اول باید اینو بکنم! بیا برامون فرصت بده تا اینجا تمام شه، بعد می‌تونیم شروع کنیم به جستجوی مردم برای مراسمتو!"

    # say L151 bri
    old "Alright! But as soon as you finish, I'll pester you to get to it!"
    new "البته! ولی همین جا که تمام می‌شه، من می‌خوام تو رو تحریک کنم که شروع کنی!"

    # say L152 pla
    old "Yeah, yeah, whatever."
    new "بله، بله، هر چی."

    # say L221 pla
    old "Oh... Uhh... Yeah, Hi Barbie, how are you doing?"
    new "اوه... اوه... بله، سلام بربی، حالت چطوره؟"

    # say L232 pla
    old "Uhh... No, actually, I didn't come to see her."
    new "اوه... نه، در واقع، من برای دیدنش نیومده‌ام."

    # say L233 pla
    old "I have something for [mo2], but I was told I could just leave it with you."
    new "من چیزی برای [mo2] دارم، اما به من گفتند می‌تونم به تو بدم."

    # say L236 bri
    old "Hey, [pla]!! Did you hear what I told you?!"
    new "هی، [pla]!! آنچه به تو گفتم رو شنیدی؟!"

    # say L244 pla
    old "What? No, no, sorry."
    new "چه؟ نه، نه، معذرت."

    # say L245 pla
    old "I- uhm, I didn't mean to be rude."
    new "من- اوه، من قصد نداشتم خشن باشم."

    # say L247 pla
    old "I meant to say, {i}‘ok, alright, that's great'{/i}."
    new "من قصد داشتم بگم، {i}باشه، خوبه، عالیه{/i}."

    # say L250 pla
    old "Right."
    new "درست."

    # say L255 pla
    old "Sure, thank you."
    new "بله، ممنون."

    # say L257 pla
    old "Thanks Barbie, I guess I'll see you later."
    new "ممنون باربی، حدس می‌زدم بعداً می‌بینیم."

    # say L273 bri
    old "Great news [pla]! As I told you before, we have the first target to start cultivating power for the spell!"
    new "خبر خوب [pla]! همانطور که قبلاً به تو گفتم، ما اولین هدف برای شروع تقویت جادو را پیدا کرده‌ایم!"

    # say L275 pla
    old "Yeah, I figured..."
    new "بله، حدس زدم..."

    # say L276 pla
    old "Is that why you interrupted me while I was talking to her?"
    new "این به همین خاطر بود که تو رو وقتی با او حرف زدی قطع کردی؟"

    # say L278 bri
    old "Well, it was important that you knew..."
    new "خب، مهم بود که بدانی..."

    # say L279 bri
    old "But anyway, that doesn't matter."
    new "اما هر حال، این مهم نیست."

    # say L281 bri
    old "What's important is that that woman you were talking with will be our first target."
    new "مهم اینه که آن زنی که باهاش حرف می‌زدی هدف اول ما خواهد بود."

    # say L283 bri
    old "Well, while you two were talking, I was examining her."
    new "خب، در حالی که شما دو نفر با هم صحبت می‌کردید، من در حال بررسی او بودم."

    # say L285 pla
    old "Yeah, I noticed... That was weird, luckily no one else can see you."
    new "بله، متوجه شدم... اونجور بود، خوشحالم که هیچ کس دیگه نتونست تورو ببینه."

    # say L287 bri
    old "Yeah, yeah, whatever, the point is that she's the first person you have to seduce for our ritual."
    new "بله، بله، هر چی، مهم اینه که او اولین شخصیه که باید برای مراسم ما فریب دادی."

    # say L288 pla
    old "Huh?! W- why? Why does it have to be her?"
    new "هییی؟! چ- چرا؟ چرا باید همین باشه؟"

    # say L290 bri
    old "Because she's the right specimen, she has just the right qualities we need for it."
    new "چون او نمونه‌ی درسته، ویژگی‌های لازم رو برای این کار داره."

    # say L292 bri
    old "As far as you humans go, she's the best prospect I could have expected to find to start our ritual."
    new "به نظرت از بین انسان‌ها، او بهترین امیدواری بود که می‌تونستم برای شروع مراسم پیدا کنم."

    # say L294 pla
    old "Why? What's so special about her?"
    new "چرا؟ چی خاصی داره؟"

    # say L296 bri
    old "Well, as I said she has the perfect qualities... To- to..."
    new "خب، همانطور که گفتم او ویژگی‌های مناسبی دارد... تا- تا..."

    # say L298 bri
    old "H- host and... Condense the magic power within her."
    new "میزبان و... قدرت جادویی را درون خود متمرکز می‌کند."

    # say L299 bri
    old "Her body composition is just the right one."
    new "تشکیل بدن او دقیقاً مناسب است."

    # say L300 pla
    old "Right..."
    new "درسته..."

    # say L301 bri
    old "Besides, this should be easy to do, right?"
    new "البته، این کار باید آسون باشه، درسته؟"

    # say L303 bri
    old "Isn't she the type of female you male humans like?"
    new "آیا او همین نوع زنی نیست که شما مردان انسان دوست دارید؟"

    # say L305 bri
    old "Her mammary glands are gigantic, even for the standards of what your species would consider big."
    new "پستان‌هایش از اندازه‌ای هستند که حتی برای استانداردهای گونه‌ات بزرگ محسوب می‌شن."

    # say L309 bri
    old "So don't think too much about it. Just focus on having a good time."
    new "پس خیلی فکر نکن. فقط روی لذت بردن تمرکز کن."

    # say L310 bri
    old "If you seduce her, and implant the magic within her you'll enjoy it, won't you?"
    new "اگر تو او رو فریب دهی و جادو رو درونش قرار بدی، لذت می‌بری، هستی؟"

    # say L311 pla
    old "Ugh, I guess you're right."
    new "اوه، حدس می‌زنم درست می‌گی."

    # say L313 pla
    old "But I barely know her, we have never exchanged more than a couple of words, how the hell am I going to seduce her?"
    new "اما من هاردی اشناستم، هیچ وقت بیش از چند کلمه با هم صحبت نکرده‌ایم، چطور خدا می‌تونم اش را فریب دهم؟"

    # say L314 bri
    old "Don't worry, I'll help you with that."
    new "نگران نباش، من بهت کمک می‌کنم."

    # say L315 pla
    old "Hahaha... Really? How?"
    new "حاحاحا... واقعاً؟ چطور؟"

    # say L317 bri
    old "By using magic of course!"
    new "با استفاده از جادو طبعاً!"

    # say L319 bri
    old "There's a lot of magic you still don't know about, you've barely scratched the surface of what's possible."
    new "هنوز از جادو خیلی چیزهایی نمی‌دونی، فقط سطح سطحی از امکانات رو دیده‌ای."

    # say L321 bri
    old "By employing a simple mind reading spell, I can get inside her thoughts and emotions."
    new "با استفاده از یک جایزه ساده خواندن ذهن، می‌تونم داخل فکرهاش و احساساتش برسم."

    # say L322 bri
    old "And let you know what she has in her mind while you're speaking to her."
    new "و به تو بگم چه چیزی در ذهنش هست، وقتی با او صحبت می‌کنی."

    # say L324 bri
    old "I can even read deep thoughts, and see if anything is influencing her deep mind."
    new "می‌تونم حتی فکر عمیق‌اش رو بخونم و ببینم آیا چیزی بر فکر عمیق‌اش تأثیر گذاشته."

    # say L326 pla
    old "I have to say, that sounds amazing."
    new "باید بگم، این خیلی عالی به نظر می‌رسه."

    # say L328 bri
    old "It is, but it's also inconvinient. Since I'll be reading her mind and telling you what she's thinking."
    new "بله، اما همینطور ناراحت‌کننده است. چون من باید ذهنش رو بخونم و به تو بگم که چه فکر می‌کنه."

    # say L329 bri
    old "That means that whenever you talk to her I'll have to be with you."
    new "این بدان معناست که هر بار که باهاش حرف می‌زنی، من باید با تو باشم."

    # say L331 bri
    old "Besides, in order to maintain the mind-reading, I have to keep the channel between her mind and mine open."
    new "البته، برای حفظ ارتباط ذهنی، باید کانال بین ذهن من و او باز باقی بماند."

    # say L332 bri
    old "That drains the magic power too quickly."
    new "این به سرعت توان جادویی رو می‌بره."

    # say L333 bri
    old "So you'll have to be sure to make good use of the information I'm able to give you."
    new "پس باید از اطلاعاتی که به تو می‌دهم به خوبی استفاده کنی."

    # say L335 pla
    old "I get it, but if it's that difficult, why don't you teach me the spell to do it myself?"
    new "فهمیدم، اما اگه همینجور سخته، چرا نمی‌تونی به من جادویی رو بیاموزی؟"

    # say L336 pla
    old "That way I can just do the mind reading by myself, and your magic reserves won't have to be drained."
    new "این جوری من می‌تونم خودم ذهن رو بخونم و ذخایر جادویت تو خشک نشه."

    # say L338 bri
    old "Sadly I can't do that, this spell is a level beyond your current abilities."
    new "متأسفانه نمی‌تونم این کار رو بکنم، این جادویی سطحی بالاتر از توانایی‌های فعلی تو هست."

    # say L339 bri
    old "The complexity is too high for you to handle right now."
    new "پیچیدگی برای تو خیلی بالاست تا حالا این کار رو انجام بدی."

    # say L341 bri
    old "Maybe if you had been a bit more diligent with your practices..."
    new "شاید اگه کمی دقت‌تر تمرین می‌کردی..."

    # say L342 bri
    old "And had improved your abilities with the Sexnote, you'd be able to do it."
    new "و با تقویت توانایی‌ات با سکس‌نوت، می‌تونستی این کار رو انجام میدادی."

    # say L343 bri
    old "But it didn't happen, did it?"
    new "ولی اینجوری نشد، درسته؟"

    # say L345 bri
    old "So, I'll have to do the hard work of reading her mind and telling you what to say."
    new "پس من باید کار سخت خواندن ذهنش و گفتن باید چی بگی را انجام بدم."

    # say L346 pla
    old "I see, I guess that's how it has to be."
    new "بگشتم، به نظر می‌رسه باید اینجوری باشه."

    # say L348 pla
    old "Oh! I know!"
    new "اوه! من می‌دونم!"

    # say L350 pla
    old "What about the {i}Sauron Mouth?{/i} I could use that instead of you having to use your magic, right?"
    new "می‌تونم از دهان ز{i}Sauron {/i} استفاده کنم؟ به جای اینکه تو باید جادو بکنی، درسته؟"

    # say L352 bri
    old "What? What are you talking about? Didn't you pay attention when you learned the spell?!"
    new "چه کاری می‌تونی بگی؟ وقتی جادو رو یاد گرفتی، نگاهت اینجوری نبود؟!"

    # say L354 bri
    old "The {i}Sauron Mouth{/i} doesn't work like that."
    new "دستورالعمل ز{i}سورون مونث{/i} همینطور نیست."

    # say L355 bri
    old "There are two conditions that prevent anyone from using it to just outright control another person."
    new "دو شرط وجود داره که مانع می‌شه از استفاده ازش برای کنترل کامل شخص دیگه شد."

    # say L359 bri
    old "So, you can't just make someone do something they don't want to do, you can't go over personal limits."
    new "پس نمی‌تونی کسی رو برای انجام کاری که نمی‌خواد اجبار کنی، نمی‌تونی از مرزهای شخصی کسی عبور کنی."

    # say L361 bri
    old "Is not like you can just tell someone to fall in love with you or anything."
    new "مثل این نیست که بتونی به کسی بگی عاشق تو شه یا همچین چیزی."

    # say L362 pla
    old "I get it, I can't 'force' anyone with the {i}Sauron Mouth{/i}."
    new "فهمیدم، نمی‌تونم با {i}Sauron Mouth{/i} کسی رو زور بذaram."

    # say L363 bri
    old "Is not just that, you can't use it on someone if you don't have a connection to them."
    new "نه، فقط این نیست، نمی‌تونی از کسی استفاده کنی اگر به تو هیچ ارتباطی نداشته باشه."

    # say L365 bri
    old "So, even if you go up to her and tell her to do something, it won't work, since you barely know each other."
    new "پس حتی اگه بری براش بگی کاری کنی، هیچ جور نمی‌تونه کار کنه، چون شما دو تا هم نمی‌شناسید."

    # say L367 bri
    old "There are no shortcuts for this [pla], you have to do it properly."
    new "برای این کار هیچ میان‌راهی نیست [pla]، باید همه چی رو درست انجام بدی."

    # say L368 pla
    old "I get it, I get it, so that's a no on the {i}Sauron Mouth{/i} then."
    new "فهمیدم، فهمیدم، پس اینجوری نمی‌تونم با {i}Sauron Mouth{/i} کار کنم."

    # say L369 bri
    old "It is, you see why I keep pestering you to start working on the ritual? It's a lot of work, and we don't have much time."
    new "ببینی، همین جوری می‌فهمی چرا همیشه ازت می‌خواهم شروع به کار روی مراسم کنی. کار زیادی هست و وقت خیلی کم."

    # say L370 pla
    old "Yeah, yeah I get it."
    new "بله، بله متوجه شدم."

    # say L372 bri
    old "Good, now that you understand it, let's go."
    new "خوب، حالا که فهمیدی، برویم."

    # say L374 pla
    old "What?! Now?"
    new "چه؟! حالا؟"

    # say L376 bri
    old "Yes, now! Haven't you understood how urgent this is?"
    new "بله، حالا! آیا هنوز متوجه اهمیت این کار نشده‌ای؟"

    # say L377 pla
    old "But we just arrived! I was just there a moment ago! If I go back now, it will look weird."
    new "اما ما همین جا رسیدیم! همین الان اونجا بودم! اگه الان برگردم، عجیب می‌تونه به نظر برسه."

    # say L379 bri
    old "Don't you worry about that, after all, I will be reading her mind and telling you what you need to know to handle the situation."
    new "نگران اون نباش، در نهایت من خواهم دید چه فکر می‌کنه و به تو می‌گم چطور باید با این وضعیت برخورد کنی."

    # say L380 pla
    old "You sound very confident about this."
    new "تو خیلی اعتماد به نفسی داری در این موضوع."

    # say L381 bri
    old "Well is not as if it's difficult..."
    new "خب، اینقدر سخت نیست..."

    # say L383 bri
    old "You humans are so easy to manipulate! You just have to say the right thing and you fold!"
    new "شما انسان‌ها خیلی آسان هستید برای کنترل! فقط کافیه چیز درست رو بگم و شما خمش می‌کنید!"

    # say L385 pla
    old "We do? How do you know that?"
    new "ما همین‌جوری؟ چطور می‌دونی؟"

    # say L386 bri
    old "I- I mean..."
    new "من- من به این معنا بودم..."

    # say L388 bri
    old "It's what I've observed in my time here watching you and the other humans."
    new "این همین چیزیه که من در اینجا با نظارت بر تو و سایر انسان‌ها مشاهده کردم."

    # say L390 pla
    old "Hmm... alright."
    new "Hmm... خب."

    # say L391 pla
    old "I guess you're right."
    new "بی‌خیال، درست می‌گی‌ی."

    # say L393 bri
    old "Of course I am!"
    new "البته من هستم!"

    # say L394 bri
    old "Now, let's go seduce that human with the big mammary glands!"
    new "بیای حالا، برویم آن انسان با سینه‌های بزرگ رو فریب دهیم!"

    # say L395 pla
    old "{b}*Sigh*{/b} Alright let's go."
    new "{b}*تنفر*{/b} خب برویم."

    # say L409 pla
    old "Hi Barbie."
    new "سلام بربی."

    # say L411 pla
    old "... Again."
    new "... دوباره."

    # say L417 pla
    old "Uhm, no."
    new "نه."

    # say L419 pla
    old "I actually came to talk with you."
    new "اصلًا برای صحبت با تو اومدم."

    # say L422 pla
    old "Hmm, yeah..."
    new "هم، بله..."

    # say L424 pla
    old "About what..."
    new "درباره چی..."

    # say L425 pla
    old "Hmm, that's... {i}a good question...{/i}"
    new "هم، این... {i} سوال خوبیه...{/i}"

    # say L426 bri
    old "Sigh! Look at you strugling to come up with something."
    new "آه! ببین چطور تلاش می‌کنی چیزی بیاوری."

    # say L427 bri
    old "Don't worry, I have this."
    new "نگران نباش، من اینو دارم."

    # say L432 bri
    old "[pla]! She's feeling sad about something."
    new "[pla]! به نظر می‌رسه چیزی به تو افتاده."

    # say L435 pla
    old "Is just that you looked a little sad to me when I saw you."
    new "فقط اینجاست که وقتی تو رو دیدم، نگاهت یه جوره بود."

    # say L436 pla
    old "So I was wondering if there's anything that I could do for you, maybe you would like to talk about it?"
    new "پس فکر کردم شاید می‌تونم برایت کاری بکنم، ممکنه بخوای در موردش صحبت کنی؟"

    # say L447 bri
    old "That's a lie! She's feeling a great sadness!"
    new "این دروغه! او احساس غم زیادی داره!"

    # say L448 bri
    old "I don't know yet what it is, but she's definitely sad about something."
    new "نمیدونم هنوز چیه، ولی حتماً به خاطر چیزی ناراحته."

    # say L450 pla
    old "Are you sure about it?"
    new "مطمئنی در مورد این؟"

    # say L451 pla
    old "I don't want to be annoying or anything, is just that you seem like you have a lot on your mind."
    new "من نمی‌خوام لازم باشم یا هیچ، فقط اینجور می‌تونم بگم که تو خیلی چیز‌ها رو تو ذهن داری."

    # say L463 bri
    old "Oh! It seems she's feeling frustrated about something!"
    new "اوه! به نظر می‌رسه در مورد چیزی ناراحت شده."

    # say L464 bri
    old "It's just hard to tell about what... She has a lot of emotions and thoughts going through her..."
    new "فقط خیلی سخته در مورد چه چیزی باشه... او خیلی احساسات و فکرها در ذهنش داره..."

    # say L465 bri
    old "Just give me a second."
    new "بی‌خیال باش، فقط یه لحظه بده."

    # say L467 pla
    old "Really? That's a relief to hear, it's good that you're doing so well."
    new "وای، این خبر خوبه، خوشحالم که حالت خوبه."

    # say L468 pla
    old "It just looked for a moment there like you had something in your mind."
    new "فقط به نظر می‌رسید لحظه‌ای چیزی در ذهن تو بود."

    # say L470 pla
    old "Kind of as if you were feeling {b}frustrated{/b} about something."
    new "به نظر می‌رسید که یه چیزی تو ذهنت بود، یعنی گونه‌ای که یه چیزی رو {b}ناامید {/b}بودی."

    # say L471 pla
    old "But you aren't, right?"
    new "ولی تو نیستی، درسته؟"

    # say L484 bri
    old "And it's related to why she's feeling frustrated."
    new "و این مربوط به دلیلی است که او ناراحت شده."

    # say L485 bri
    old "She recently failed at something..."
    new "او اخیراً در چیزی شکست خورد..."

    # say L487 bri
    old "An audition!"
    new "آزمون هنری!"

    # say L490 bri
    old "What's an audition?"
    new "چیزی مثل آزمون برای یک نقش؟"

    # say L491 pla
    old "{i}(I see now!){/i}"
    new "{i}( حالا متوجه شدم! ){/i}"

    # say L492 pla
    old "Well, I'm happy you're feeling well."
    new "البته خوشحالم که حالت خوبه."

    # say L494 pla
    old "Maybe I'm just projecting myself."
    new "شاید من فقط خودمو پروجکت می‌کنم."

    # say L496 pla
    old "You see, I recently failed an interview for a job I wanted."
    new "دیدی، اخیراً برای شغلی که می‌خواستم مصاحبه شکست خوردم."

    # say L501 pla
    old "Yeah... I really wanted to get it. And I thought I was the best for it, but the hiring team chose someone else."
    new "بله... واقعاً می‌خواستم اون رو بگیرم. فکر می‌کردم بهترین نفر برای اون هستم، ولی تیم استخدام کسی دیگه رو انتخاب کرد."

    # say L508 bri
    old "[pla]! Now she's remembering something else!"
    new "[pla]! حالا به چیز دیگه‌ای فکر می‌کنم."

    # say L509 pla
    old "{i}What is it?!{/i}"
    new "{i}چه کاری هست؟!{/i}"

    # say L511 bri
    old "What is this feeling?..."
    new "این احساس چیه؟..."

    # say L518 pla
    old "But I guess I have to let it go."
    new "اما به نظر می‌رسه باید این رو رها کنم."

    # say L520 pla
    old "I think that, sadly, sometimes our projects don't turn out the way we want them to. You know?"
    new "من فکر می‌کنم، متاسفانه، گاهی پروژه‌های ما مثل آنچه می‌خواهیم نمی‌شوند. می‌دونی؟"

    # say L523 pla
    old "You do?"
    new "می‌دونی؟"

    # say L529 pla
    old "Yeah, that's right."
    new "بله، همینطور است."

    # say L530 pla
    old "But you know what? I think I'll give it another go and I'll try to get that job."
    new "اما می‌دونی چی؟ فکر کنم دوباره امتحان بدم و بپرزم اون شغل رو."

    # say L536 pla
    old "Well, I guess I'll just have to try again, and again until I make it."
    new "باید دوباره سعی کنم، و دوباره تا زمانی که به هدفم برسم."

    # say L538 pla
    old "After all, this job is sort of a {i}dream{/i} of mine."
    new "در نهایت، این شغل نوعی {i}رویا{/i} من هست."

    # say L539 pla
    old "So I wouldn't want to give up on it for nothing."
    new "پس من نمی‌خوام برای هیچ چیز ازش کنار برسم."

    # say L544 pla
    old "Do you? What do you mean?"
    new "می‌خوای بگی چی؟ منظورت چیه؟"

    # say L547 pla
    old "Is there something you shouldn't give up on?"
    new "آیا چیزی هست که نباید ازش کنار بری؟"

    # say L548 bri
    old "Ohh, he is not bad at this..."
    new "اوه، او در این کار بد نیست..."

    # say L551 pla
    old "Come on, I know there's something on your mind that's been making you feel rather bad."
    new "بیا، می‌دونم چیزی هست که از آن خوب نیستی."

    # say L554 pla
    old "If you need to talk about it I'll be more than happy to hear you."
    new "اگه می‌خوای در موردش صحبت کنی، خوشحالم که بهت گوش کنم."

    # say L556 pla
    old "After all... I already told you about my situation."
    new "در نهایت... من قبلاً درباره وضعیتم با تو صحبت کردم."

    # say L558 pla
    old "Maybe I could help you with yours."
    new "شاید بتونم به تو کمک کنم."

    # say L564 pla
    old "What? What do you mean?"
    new "چی؟ منظورت چیه؟"

    # say L566 pla
    old "Listen, if this is something you want, and it's important to you, there's no way that it is ridiculous!"
    new "بله، اگر این برایت مهمه و می‌خوای انجام بدی، حتماً من کمکت می‌کنم؛ اصلاً خنده‌دار نیست!"

    # say L574 bri
    old "She's feeling very bad [pla], there's something bothering her deeply."
    new "او خیلی بد حس می‌کنه [pla]، چیزی عمیقاً از او درد می‌برده."

    # say L575 bri
    old "What she's transmitting more strongly is a very deep feeling of insecurity."
    new "آنچه که او بیشتر منتقل می‌کند احساسی بسیار عمیق از ناامنی است."

    # say L578 pla
    old "Listen Barbie."
    new "بیا باربی، بگو چه مشکلی داری."

    # say L579 pla
    old "I understand that sometimes things don't go the way we want them to."
    new "من می‌فهمم که گاهی اوقات چیزهایی مثل آنچه می‌خواهیم اتفاق نمی‌افتد."

    # say L581 pla
    old "But if it's something that's really important for you, I think it's worth it to give it a shot."
    new "اما اگر اونقدر مهم برایت هست، فکر می‌کنم باید یه فرصت بدی."

    # say L583 pla
    old "Don't you think? Why don't you let me know about it?"
    new "می‌تونی به من بگی در مورد چیه؟"

    # say L599 pla
    old "I see, it must be very frustrating to deal with that."
    new "باید خیلی ناراحت کننده باشه که با این مشکل روبرو باشی."

    # say L601 pla
    old "But I'm sure you still can make that dream a reality..."
    new "اما مطمئنم هنوز می‌تونی اون رویایت رو واقعی کنی..."

    # say L602 pla
    old "I mean, I'm sure there are a lot of auditions being held every day, aren't there?"
    new "من می‌گم، حتماً هر روز آزمون‌های صدا زیادی برگزار می‌شن، نه؟"

    # say L604 pla
    old "You might land a role sooner rather than later, and that could propel you upward, isn't that right?"
    new "شاید زودتر از آنچه فکر می‌کنی نقشی پیدا کنی و این تو رو بالا برده، درسته؟"

    # say L614 pla
    old "Why would you say that?"
    new "چرا اینجوری می‌گی؟"

    # say L626 pla
    old "That's terrible! They have no right to treat you that way!"
    new "این خیلی بد است! آنها حق ندارن به تو اینجوری برخورد کنند!"

    # say L627 pla
    old "Besides, it isn't fair to say something like that."
    new "البته، این عادلانه نیست که چیزی مثل این بگی."

    # say L630 pla
    old "I'm sorry about that, Barbie."
    new "متاسفم، باربی."

    # say L635 pla
    old "No, they're not."
    new "نه، آنها نیستند."

    # say L637 pla
    old "You don't have to believe that just because they say it to you."
    new "تو نمی‌تونی فقط برای اینکه اونا بهت می‌گن باورش کنی."

    # say L643 bri
    old "[pla]! She's thinking about something!"
    new "[pla]! او به چیزی فکر می‌کنه!"

    # say L644 bri
    old "But it isn't clear what it is."
    new "اما مشخص نیست که چه چیزی است."

    # say L646 bri
    old "Keep talking to her, maybe she'll open up more."
    new "باهاش حرف بزن، شاید بیشتر باز می‌شود."

    # say L648 pla
    old "I mean, I'm sure you've faced some obstacles, right?"
    new "من می‌گم، حتماً با برخی مشکلات مواجه شده‌ای، درسته؟"

    # say L650 bri
    old "Something just came up on her mind!"
    new "چیزی به ذهنش خورد!"

    # say L651 bri
    old "Something about..."
    new "چیزی مربوط به..."

    # say L652 bri
    old "{i}Number of auditions?{/i}"
    new "{i}تعداد آزمون‌ها؟{/i}"

    # say L654 bri
    old "What is that?"
    new "این چیه؟"

    # say L658 pla
    old "Like, have you gotten enough auditions? I bet you haven't been able to attend to many, right?"
    new "مثلاً، آیا توش کار کافی برای اودیشن کردن کردی؟ حتماً نتونستی خیلی شرکت کنی، درسته؟"

    # say L664 pla
    old "You see? It isn't your fault."
    new "دیویدی، این گناه تو نیست."

    # say L672 bri
    old "[pla]! Something else just came into her mind!"
    new "[pla]! چیزی دیگه به ذهنم رسید!"

    # say L673 pla
    old "{i}What is it?{/i}"
    new "{i}چه کاری؟{/i}"

    # say L674 bri
    old "I'm not sure, her mind's kinda foggy."
    new "مطمئن نیستم، ذهنش یه جور مبهمه."

    # say L681 bri
    old "Practice! She's thinking about not being able to practice!"
    new "تمرین! او به نظر می‌رسه فکر می‌کنه نتونه تمرین کنه!"

    # say L683 pla
    old "I mean, you are working here full time, I bet it's very difficult to do things like acting if you don't have enough practice time."
    new "من قصدم اینه، تو اینجا کار می‌کنی، حتماً برای کارهایی مثل بازیگری خیلی سخته اگه وقت کافی برای تمرین نداشته باشی."

    # say L684 pla
    old "Right?"
    new "حق باهات؟"

    # say L692 bri
    old "She's not thinking about time [pla], there's something else there."
    new "[pla] وقت نیست در نظرش، چیز دیگری هست."

    # say L694 bri
    old "Partners?"
    new "همکاران؟"

    # say L696 bri
    old "I don't know what she means by that."
    new "نمی‌دونم اونجا چی قصه داره."

    # say L697 pla
    old "{i}But I think I do! Thanks Brixxida!{/i}"
    new "{i}ولی، ولی من فکر می‌کنم بله! ممنون Brixxida!{/i}"

    # say L699 pla
    old "Yeah, I bet that since you're always working here."
    new "بله، حدس می‌زنم چون همیشه اینجا کار می‌کنی."

    # say L702 pla
    old "It must be very difficult  to find partners to practice with."
    new "پیدا کردن همکار برای تمرین باید خیلی سخت باشه."

    # say L704 pla
    old "And even if you did find them, making the space to practice must be very difficult. Right?"
    new "و حتی اگر پیدا کنی، فضا برای تمرین رو آماده کردن باید خیلی سخت باشه. درسته؟"

    # say L710 pla
    old "But you know, those things can be dealt with."
    new "اما می‌دونی، اینا می‌تونن حل بشه."

    # say L712 pla
    old "How about I help you with them?"
    new "من می‌تونم به تو کمک کنم."

    # say L719 pla
    old "Uhm... W- well..."
    new "اوه... خب..."

    # say L720 pla
    old "S- since you can't practice with other actors, how about I do it with you?"
    new "چون نمی‌تونی با بازیگران دیگه تمرین کنی، چطور اگه من با تو تمرین کنم؟"

    # say L721 pla
    old "I could give you pointers and help you memorize your lines."
    new "می‌تونم بهت اشاره‌هایی بدم و کمکت کنم خط‌هات رو حفظ کنی."

    # say L730 pla
    old "M- maybe I could help you find another audition."
    new "شاید بتونم بهت کمک کنم تا اودیشن دیگه‌ای پیدا کنی."

    # say L731 pla
    old "I understand that you're very busy."
    new "من می‌فهمم که خیلی مشغولی."

    # say L732 pla
    old "So, how about I'm the one that searches around, and helps you find auditions for roles that you may be good at?"
    new "پس، چطور اگه من جستجو کنم و بهت کمک کنم تا نقش‌هایی که می‌تونی ایفا کنی پیدا کنم؟"

    # say L737 pla
    old "Y- Your agent?"
    new "Y- تو عامل من؟"

    # say L742 pla
    old "I- I don't think that's..."
    new "من فکر نمی‌کنم این خوب باشه..."

    # say L748 bri
    old "Yes! Say yes! That's exactly what she wants! I can see it in her mind!"
    new "بله! بله بگو! همین هست که او می‌خواهد! من این رو در ذهنش می‌بینم!"

    # say L749 pla
    old "{i}B- but, being an agent is...{/i}"
    new "{i}ب- اما، عامل بودن...{/i}"

    # say L751 bri
    old "What are you so hesitant about? Just say yes or you won't be able to establish a relationship with her!"
    new "تو چه تردیدی داری؟ فقط بله بگو، در غیر این صورت نمی‌تونی با او رابطه برقرار کنی!"

    # say L752 bri
    old "We'll figure out how to do that later!"
    new "بعداً راهش رو پیدا می‌کنیم!"

    # say L753 pla
    old "{b}*Sigh*{/b}"
    new "{b}*تنفر*{/b}"

    # say L756 pla
    old "Yeah, you're right, I would be acting as your manager."
    new "بله، درست می‌گی، من به عنوان مدیرت عمل می‌کنم."

    # say L757 pla
    old "... I guess."
    new "باید هست."

    # say L759 pla
    old "Well, I just want to help you."
    new "من فقط می‌خوام به تو کمک کنم."

    # say L761 pla
    old "After all, I told you you shouldn't give up on your dreams."
    new "در نهایت، من به تو گفتم نباید از رویاهایت بازمی‌آیی."

    # say L763 pla
    old "So... How about I go home for now and start making some calls?"
    new "پس... چطور اگه من حالا برم خونه و شروع به زنگ زدن کنم؟"

    # say L765 pla
    old "And if something comes up I'll let you know."
    new "اگر چیزی پیش اومد بهت می‌گم."

    # say L778 pla
    old "Uhm, happy to help..."
    new "خوشحالم که بتونم کمکت کنم..."

    # say L779 pla
    old "I guess I'll see you later then, Bye."
    new "bebem بعداً هم می‌تونیم ببینیم، خداحافظ."

    # say L795 pla
    old "Ok, I think that went well."
    new "خب، فکر کنم خوب رفت."

    # say L797 bri
    old "What are you talking about?! Why didn't you have sex with her?!"
    new "تو در مورد چی حرف می‌زنی؟! چرا باهاش جنس نکردی؟!"

    # say L799 bri
    old "I told you, you humans are very easy to manipulate."
    new "من به تو گفتم، شما انسان‌ها خیلی آسان هستید برای دستکاری."

    # say L801 bri
    old "I thought that by helping you talk to her you would already be having sex with her!"
    new "فکر کردم با کمک من برای صحبت با او قراره شما با هم جنسیتی داشته باشید!"

    # say L803 bri
    old "You know we don't have much time!"
    new "می‌دونی وقت زیادی نداریم!"

    # say L805 pla
    old "Well, I'm sorry, I thought you didn't have any spells that would make her have sex with me right away."
    new "خب، معذرت، فکر کردم تو هیچ جادویی نداری که بشه اونجوری با من جنسی شه."

    # say L806 bri
    old "I don't have any, that doesn't exist."
    new "من هیچ جادویی ندارم، این چیزی وجود نداره."

    # say L808 pla
    old "Then how about you let me handle this and stop yelling at me about it?"
    new "پس چرا نمی‌گی هم اینو برام بگذاری و در موردش صدایت نگرفت؟"

    # say L810 pla
    old "What you told me about her barely helped me a little to connect with her."
    new "اینطوری که به من در موردش گفتی، فقط یه کم به من کمک کرد تا باهاش ارتباط برقرار کنم."

    # say L811 pla
    old "Listen, is not as easy to convince humans to have sex just like that."
    new "بله، اینقدر ساده نیست که انسان‌ها رو متقاعد کنیم جنسیت داشته باشند."

    # say L813 pla
    old "You may be able to read minds, but you don't know how human emotions work."
    new "شاید بتونی ذهن‌ها رو بخونی، اما نمی‌دونی احساسات انسان‌ها چطور کار می‌کنن."

    # say L815 pla
    old "So let me handle this, ok?"
    new "پس بگذار من این رو انجام بدم، خوبه؟"

    # say L816 bri
    old "Fine... I'll let you do what you want."
    new "خوب... بگذار تو هر چی می‌خوای انجام بدی."

    # say L818 bri
    old "But be sure to do it quickly!"
    new "اما حتماً سریع انجام بده!"

    # say L820 bri
    old "Magic power is not eternal in case you forgot!"
    new "تو قدرت جادویی رو فراموش نکرده‌ای، اونقدر طول نمی‌کشه!"

    # say L821 bri
    old "And I already used a lot of it today, so be sure you do this properly."
    new "و من امروز خیلی از قدرت جادوییم رو استفاده کردم، پس حتماً این کار رو درست انجام بده."

    # say L822 pla
    old "Yeah, yeah, I'll be sure to do what you need."
    new "بله، بله، حتماً این کار رو مثلی که می‌خوای انجام می‌دم."

    # say L824 pla
    old "But I'm in a tight spot with this. I know nothing about acting. I'll have to come up with something."
    new "ولی من در موقعیت سختی هستم. از بازیگری هیچ نمیدونم. باید چیزی پیش بیارم."

    # say L826 pla
    old "But I just don't have any ideas about how..."
    new "ولی هیچ ایده‌ای ندارم که چطور..."

    # say L827 pla
    old "And I don't know anybody that works in acting, how am I going to get her an audition..."
    new "و من هم نمی‌دونم کسی که توی بازیگری کار می‌کنه، چطور می‌تونم برایش اودیشن پیدا کنم..."

    # say L828 bri
    old "Well, that was your idea after all..."
    new "خب، این همین ایده‌ت بود در نهایت..."

    # say L829 pla
    old "What? You were the one who told me to accept being your agent. I didn't even..."
    new "چه کاری؟ تو بودی که به من گفتی قبول شدن اجنتت رو. من حتی..."

    # say L833 pla
    old "Belle!"
    new "بلل!"

    # say L834 pla
    old "She's very into content creation and social media."
    new "او خیلی علاقه‌مند به ایجاد محتوا و رسانه‌های اجتماعی هست."

    # say L836 pla
    old "It may be a long shot, but maybe she knows somebody who could help us with this."
    new "ممکنه یه شانس بلند باشه، اما شاید او دانستن کسی هست که بتونه به ما کمک کنه."

    # say L838 pla
    old "Right now is a little late, but I'll go talk to her soon to see if she could help me."
    new "الان کمی دیره، ولی همین جا می‌روم باهاش صحبت کنم تا ببینم می‌تونه به من کمک کنه."

    # say L839 bri
    old "Yes, honestly, I need to recharge. I spent a lot of magical power today, so I need to recover, and I won't be able to help you for a few days."
    new "بله، صدایا، من نیاز به بازپردازی دارم. امروز توان جادویی زیادی را صرف کردم و باید بهبود پیدا کنم؛ برای چند روز نمی‌توانم به تو کمک کنم."

    # say L840 pla
    old "Hmm, alright, I can handle it with Belle for now, and what you helped with Barbie was a lot; at least, she trusts me now."
    new "Hmm، خوب، می‌تونم با Belle اینجا را اداره کنم، و همچنین کمکی که به Barbie کردی خیلی زیاد بود؛ حداقل حالا او به من اعتماد داره."

    # say L841 bri
    old "Ok, then see you tomorrow, [pla]."
    new "باشه، پس فردا می‌بینیم، [pla]."

    # say L842 pla
    old "Sure, have a good rest."
    new "بله، خوب بخواب."

    # say L863 pla
    old "Hey Belle! How are you?"
    new "هی Belle! چطوری؟"

    # say L865 bel
    old "Hey [pla]! Good morning! I'm fine, thank you."
    new "اوه ز[pla]! صبح بخیر! خوبم، ممنون."

    # say L867 bel
    old "How about you? Are you doing well?"
    new "تو چطوری؟ خوب هستی؟"

    # say L869 pla
    old "Well... Yeah, I'm doing well."
    new "بله... من هم خوبم."

    # say L871 pla
    old "But you see... There's this situation.... It's a little complicated and I was wondering if you could help me with it."
    new "ولی می‌بینی... اوضاع یه کم پیچیده شده و فکر می‌کنم نیاز به کمکت دارم."

    # say L873 bel
    old "Uhmm... Sure, whatever I can help you with, I'll be happy to do it."
    new "اهم... البته، هر کمکی که بتونم بکنم خوشحال می‌شوم."

    # say L874 bel
    old "What  is it?"
    new "چه کاری هست؟"

    # say L876 pla
    old "Well, do you know the business building in the center of town?"
    new "خب، آیا اون بنا کاری در مرکز شهر رو می‌شناسی؟"

    # say L878 bel
    old "Sure, my mom's previous office was located there. I used to go from time to time."
    new "بله، دفتر مامان قبلاً همینجا بود. من گاهی می‌رفتم."

    # say L880 pla
    old "Oh, nice. Well, the thing is that I sometimes have to go there."
    new "اوه، خوبه. گاهی باید اونجا برسم."

    # say L881 pla
    old "You know, to bring documents for a family member from time to time, that kind of stuff."
    new "می‌دونی، گاهی باید اسناد برای یه نفر از خانواده‌ام ببرم، همین جوری."

    # say L885 pla
    old "Well the other day I came there to bring some documents, and I got to talking with the receptionist of the building."
    new "بفرمایید، روزی هم رفتم برای بردن برخی اسناد و با میزبانی ساختم حرف زدم."

    # say L887 bel
    old "Barbie?"
    new "باربی؟"

    # say L889 pla
    old "Yeah, do you know her?"
    new "بله، می‌شناسی اش؟"

    # say L891 bel
    old "I do, from when I used to come to my mom's office."
    new "بله، از زمانی که به دفتر مامانم می‌رفتم می‌شناختم."

    # say L893 bel
    old "We never really talked much, but I remember she's a very nice girl."
    new "ما هر زدی خیلی صحبت نکردیم، اما به یاد دارم که دختر خوبی هست."

    # say L894 pla
    old "Oh yeah, sure, she's very nice."
    new "اوه بله، البته، او خیلی لطف داره."

    # say L896 pla
    old "But you see, when I got there the other day, I saw that she was very sad."
    new "اما دیدی، وقتی روزی همینجا رسیدم، دیدم که او خیلی ناراحت بود."

    # say L897 bel
    old "Why? Is she okay?"
    new "چرا؟ حالت خوبه؟"

    # say L898 pla
    old "Well, nothing bad has happened, but you see..."
    new "خب، هیچ چیز بدی اتفاق نیوفته، ولی می‌دونی..."

    # say L900 pla
    old "I asked her what was wrong."
    new "من ازش پرسیدم چه مشکلی داره."

    # say L902 pla
    old "And after we got to talking, she told me that she's been feeling very frustrated as of late."
    new "و بعد از صحبت‌های ما، به من گفت که اخیراً خیلی ناراحت است."

    # say L904 pla
    old "Because she feels like her life is just coming to a halt, and she doesn't know what to do about it."
    new "چون احساس می‌کنه زندگی‌اش متوقف شده و نمی‌دونه چه کار بکنه."

    # say L905 bel
    old "Why? What's happening?"
    new "چرا؟ چه اتفاقی افتاده؟"

    # say L907 pla
    old "Well, as she told me, she originally came to town looking for opportunities to be an actress."
    new "خب، مثلی که به من گفت، اول به شهر آمد برای یافتن فرصت‌هایی برای بازیگری."

    # say L908 pla
    old "But ever since she arrived, she's been attending one audition after another."
    new "ولی از زمانی که اومده، یک آزمون بعد از دیگری رو داشته."

    # say L910 pla
    old "Without ever being selected to any roles."
    new "هیچ وقت هم برای نقشی انتخاب نشده."

    # say L911 bel
    old "I understand [pla], that's a very sad thing."
    new "فهمیدم [pla]، این یه حالت خیلی ناراحت کننده."

    # say L912 bel
    old "The thing you wanted me to help you with is related to that?"
    new "چیزی که می‌خواستی از من کمک بگیری به اون مربوطه؟"

    # say L914 pla
    old "It is, at first I only thought that she was just a little frustrated about not being able to book any roles."
    new "بله، اول فقط فکر می‌کردم که او فقط یه کم ناراحته از اینکه نتونسته نقشی بگیره."

    # say L915 pla
    old "But while we talked I came to realize how important being an actress is to her."
    new "اما در حال حرف زدن متوجه شدم چقدر بازیگری برایش مهمه."

    # say L916 pla
    old "This is what she wants to do the most in life."
    new "این همچنین مهم‌ترین چیزی است که توی زندگی می‌خواد بکنه."

    # say L918 pla
    old "To the point where she's feeling depressed for being unable to get any opportunities to act."
    new "به جایی که برای نتونستن یه فرصت برای بازیگری پیدا کردن افسردگ شده."

    # say L919 bel
    old "I get it [pla], I understand that feeling."
    new "فهمیدم [pla]، اون حس رو می‌فهمم."

    # say L920 bel
    old "The frustration of not being able to live your dreams."
    new "ناامیدی از نتونستن رویاهایت رو زندگی کنی."

    # say L921 bel
    old "It's overwhelming..."
    new "احساس فشار آورنده است..."

    # say L922 pla
    old "Yeah it is, but it's not just that."
    new "بله، اونجوره، ولی فقط این نیست."

    # say L923 pla
    old "She's also feeling bad about not being able to even try."
    new "او هم از این بابت ناراحت است که حتی تلاش کردنی."

    # say L924 pla
    old "Since she's always so busy working, she can't look for auditions."
    new "چون همیشه خیلی مشغول کاره، نمی‌تونه برای آزمون‌ها جستجو کنه."

    # say L926 pla
    old "Or attend acting classes whenever she gets a role."
    new "یا هر وقت نقشی پیدا کرد، به کلاس‌های بازیگری برود."

    # say L928 pla
    old "So, after hearing of all the things she's been going through, I decided to help her."
    new "پس بعد از شنیدن همه چیزهایی که اومده، تصمیم گرفتم کمکش کنم."

    # say L929 pla
    old "I think that's just the best thing that I could do right now, you know?"
    new "می‌دونم این بهترین چیزیه که الان می‌تونم بکنم، می‌دونی؟"

    # say L931 bel
    old "Yeah, I understand [pla], and I think that's just a great thing for you to do."
    new "بله، من متوجه هستم [pla]، و فکر می‌کنم این کار عالی‌ای برایت هست."

    # say L932 pla
    old "Thanks Belle!"
    new "ممنون Belle!"

    # say L934 pla
    old "And that's more or less what I need your help with."
    new "و این هم تقریباً همان چیزیه که به تو کمک می‌خواهم."

    # say L936 pla
    old "I ended up promising her that I would help her with the whole process of getting auditions."
    new "من در نهایت قول دادم که به او کمک کنم تا کل فرآیند آزمون‌ها رو طی کنه."

    # say L937 pla
    old "But truth be told, I don't know how to do that."
    new "اما صداقت بگم، نمی‌دونم این کار رو چطور باید بکنم."

    # say L939 pla
    old "I haven't ever even seen any acting agencies, or anything like that. So I don't know where to start."
    new "من هیچ وقت با اجنس اکتینگی آشنا نشدم، یا چیزی مثل اون. پس نمی‌دونم از کجا شروع کنم."

    # say L941 pla
    old "That's why I thought you might be able to help me with it."
    new "پس فکر کردم ممکنه تو بتونی به من کمک کنی."

    # say L943 pla
    old "I know you're very active on social media and you know a lot of people in the industry."
    new "میدونم تو خیلی فعالی توی شبکه‌های اجتماعی هستی و افراد زیادی رو توی صنعت می‌شناسی."

    # say L944 pla
    old "And you know, you also work a lot in content creation and that kind of stuff."
    new "و میدونی که تو هم خیلی در ایجاد محتوا و این جوری کار می‌کنی."

    # say L946 pla
    old "So, I was thinking that maybe you knew of a way for me to get an audition for her."
    new "پس فکر کردم شاید راهی برای اینکه من برایش آزمون بازی کنم بلدی."

    # say L947 pla
    old "Or maybe you knew of a studio of something like that..."
    new "یا شاید میدونی درباره یه استودیو یا چیزی مثل اون..."

    # say L948 bel
    old "Hmm, I see what you mean..."
    new "همم، من متوجه شدم..."

    # say L950 bel
    old "You know, there may be someone that could..."
    new "می‌دونی، ممکنه کسی باشه که بتونه..."

    # say L960 luc
    old "Hurry up and get to the classroom or you'll be late."
    new "سریع شو و به کلاس بری، نمی‌خوای دیر برسی."

    # say L994 bel
    old "So, while we were in class I got to thinking, and it came to my mind that I might know of a place where she could go."
    new "پس، وقتی ما در کلاس بودیم، به ذهنم رسید که ممکن است جایی بدانم که او بره."

    # say L995 pla
    old "You did? Great!"
    new "تو هم؟ عالی!"

    # say L996 bel
    old "Yeah, just let me do a couple of calls and I'll let you know."
    new "بله، فقط چند تا تماس بزنم و بهت خبر می‌دم."

    # say L1000 bel
    old "In fact, I'll call right now and I'll let you know right away."
    new "در واقع الان می‌تونم تماس ببرم و همین الان بهت خبر می‌دم."

    # say L1012 bel
    old "Alright, I talked with a couple of my contacts."
    new "البته، با چند نفر از ارتباطات من صحبت کردم."

    # say L1014 bel
    old "Great news! They said they would agree to audition her for an upcoming role."
    new "خبر خوب! گفتند موافقت می‌کنند که برای نقشی جدید از او آزمون بگیرند."

    # say L1016 bel
    old "I'll give you their number so you can call and see when she could go there."
    new "من شماره‌شون رو بهت می‌دم تا ببینی وقتی می‌تونه بره."

    # say L1018 bel
    old "I already gave them your info, so they'll know you're calling on my recommendation."
    new "اینفوتو بهشون دادم، پس می‌دونن تو رو بر اساس توصیه‌ی من می‌فرخونی."

    # say L1019 pla
    old "Great! Thanks a lot, Belle!"
    new "عالی! ممنون بسیار، بِل!"

    # say L1021 bel
    old "It's fine, I'm happy to be able to help."
    new "خواهش می‌کنم، خوشحالم که بتونم کمکتون کنم."

    # say L1022 bel
    old "From what you told me about Barbie's story, she needs this opportunity."
    new "با توجه به داستان باربی که به من گفتی، او به این فرصت نیاز داره."

    # say L1023 bel
    old "I know that if it was me I would love to get any help that I could get."
    new "می‌دونم اگه من بودم خوشحالم می‌شدم هر کمکی که می‌تونستم بگیرم."

    # say L1024 bel
    old "So I'm very happy to help."
    new "پس خوشحالم که کمک می‌کنم."

    # say L1026 pla
    old "That's great Belle, and a huge help!"
    new "عالیه بل، و خیلی کمک‌کننده است!"

    # say L1027 pla
    old "Thank you so much!"
    new "ممنونم بسیار از تو"

    # say L1028 bel
    old "You're welcome, I hope things will go well."
    new "خواهش می‌کنم، امیدوارم خوب پیش برود."

    # say L1029 bel
    old "Let me know how this turns out."
    new "بفرمای اگر چطور پیش رفت به من بگو."

    # say L1031 pla
    old "I'll see you later then, thanks again."
    new "بعداً می‌بینیم، ممنون دوباره."

    # say L1043 pla
    old "Asking Belle about it turned out Better than expected."
    new "پرسیدن بله ازش بهتر از انتظار بود."

    # say L1044 pla
    old "Barbie will really like this news."
    new "باربی خوشحال می‌شه از این خبر."

    # say L1045 pla
    old "Now is too late for me to go talk to her. But I'll go there soon and let her now."
    new "الان برای من خیلی دیره تا برم باهاش صحبت کنم. اما زودی می‌روم و ازش خبر می‌دم."

    # say L1064 pla
    old "Hey Barbie, how are you doing?"
    new "باربی، چطوری؟"

    # say L1070 pla
    old "Well, let me tell you that that may be about to change. Because I got you an audition."
    new "خب، بگذار برات بگم که این ممکنه تغییر کنه. چون برایت یه آزمون بازیگری گرفتم."

    # say L1073 pla
    old "Yeah, it's a role in an upcoming movie."
    new "بله، نقشی در فیلمی جدید هست."

    # say L1075 pla
    old "It’s being produced by an indie studio from outside of town."
    new "این فیلم توسط یک استودیو مستقل از خارج شهر تولید می‌شه."

    # say L1076 pla
    old "They’re holding some castings here for it."
    new "اینجا برای اون هم آزمون بازیگری دارن."

    # say L1078 pla
    old "I already booked you a spot in their next auditions block."
    new "من قبلاً برایت جایی در آزمون بازیگری بعدی رزرو کردم."

    # say L1079 pla
    old "So you'll have a chance of getting a role."
    new "پس شансی برای دریافت نقش خواهی."

    # say L1081 pla
    old "You're welcome, I'm happy to help you. I'm sure you'll do a great job with the role."
    new "خوشحالم که بتونم به تو کمک کنم. مطمئنم تو توی این نقش خوب عمل می‌کنی."

    # say L1084 pla
    old "You'll be auditioning for the role of a rich girl who's in love with a man that her family doesn't approve of."
    new "تو برای نقش یک دختر ثروتمند که عاشق مردی شده که خانواده‌اش از او قبول نمی‌کنه، آزمون خواهی داد."

    # say L1088 pla
    old "It is, you'll be auditioning for the lead role!"
    new "بله، تو برای نقش اصلی آزمون خواهی داد!"

    # say L1090 pla
    old "That's great, isn't it?"
    new "این خوب نیست؟"

    # say L1093 pla
    old "Is... Is there a problem?"
    new "آره... مشکلی نیست؟"

    # say L1096 pla
    old "Why not? Is there something wrong?"
    new "چرا نه؟ مشکلی هست؟"

    # say L1101 pla
    old "Why do you think that?"
    new "چرا فکر می‌کنی؟"

    # say L1109 bri
    old "Hey [pla]."
    new "سلام ز[pla]."

    # say L1110 pla
    old "{i}What are you doing here?{/i}"
    new "{i}تو اینجا چی کار داری؟{/i}"

    # say L1111 bri
    old "I followed you in case you needed my help. Just because there's no certainty that you will know how to speak to her."
    new "من پشت تو آمد تا در صورت نیاز به کمکت برسنم. فقط چون مطمئن نیستم که بتونی باهاش صحبت کنی."

    # say L1112 bri
    old "So, do you want my help?"
    new "پس، می‌خوای کمکم؟"

    # say L1113 pla
    old "{i}I think I can convince her on my own.{/i}"
    new "{i}من فکر می‌کنم می‌تونم خودم قانع کنم او رو.{/i}"

    # say L1115 pla
    old "I mean, I'm sure you're more than capable of taking the role, you know?"
    new "من قصدم اینه که مطمئن شم تو قابلیت ایفا کردن نقش رو داری، می‌دونی؟"

    # say L1116 pla
    old "I know you're very talented."
    new "میدونم تو خیلی مهارت داری."

    # say L1117 pla
    old "And sure, there's going to be some competition."
    new "و البته، رقابتی هم خواهد بود."

    # say L1118 pla
    old "But you're just as good as any of them, you're more than capable of holding your own in the audion, no doubt."
    new "اما تو هم مثل هیچ‌کدوم ازون ها هستی، قطعاً تونستی خودت رو در آزمون صداشوینگری ثابت کنی."

    # say L1127 pla
    old "B- but you were so excited just a minute ago!"
    new "B- ب- بیشون هم خوشحالم، یه لحظه پیش همین هیجانت بودی!"

    # say L1138 pla
    old "Listen, I understand that you're feeling insecure because of what's happened before."
    new "بله، من می‌فهمم که به خاطر چیزهایی که قبلاً اتفاق افتاده، امنیت خودت رو از دست داده‌ای."

    # say L1139 pla
    old "But you'll never know if you don't try it."
    new "ولی هرگز نمی‌دونی اگه نسوزی."

    # say L1150 bri
    old "So... You don't seem to be {i}'handling'{/i} things too well."
    new "پس... به نظر می‌رسه تو اون موضوع رو خوب {i}مدیریت {/i}کردی."

    # say L1151 bri
    old "Will you let me help you now?"
    new "آیا اجازه می‌دهی من کمکت کنم؟"

    # say L1152 bri
    old "I also need you to have sex with this human female, so this is also in my best interest."
    new "من هم نیاز دارم تو با این زن انسانی جنس کنی، پس این برای من هم مصلحت است."

    # say L1154 pla
    old "{i}Alright, alright! Get in her head and tell me what's really troubling her.{/i}"
    new "{i}باشه، باشه! وارد ذهنش شو و به من بگو چه چیزی واقعاً اونجورش کرده.{/i}"

    # say L1155 bri
    old "Okay!"
    new "باشه!"

    # say L1160 pla
    old "I understand that because of what's happened before you feel uncomfortable with the idea of auditioning."
    new "فهمیدم که به خاطر چیزهایی که پیش اومده، از ایده آزمون دادن ناراحتی داری."

    # say L1161 pla
    old "But you shouldn't let that stop you."
    new "اما نباید این خیال تو رو بازداره."

    # say L1162 bri
    old "Hold on, I'm starting to get something."
    new "بیا، من شروع می‌کنم چیزی را درک می‌کنم."

    # say L1163 bri
    old "She feels like she's a failure."
    new "احساسش اینه که شکسته است."

    # say L1164 pla
    old "{i}Uhhh... {/i}"
    new "{i}اوه... {/i}"

    # say L1166 bri
    old "No, no, she feels like her life's a failure."
    new "نه، نه، او حس می‌کنه که زندگی‌اش شکسته است."

    # say L1168 pla
    old "{i}Her life is a failure?{/i}"
    new "{i}زندگی‌اش شکسته است؟{/i}"

    # say L1170 pla
    old "I- I mean, I understand that you may feel like a failure."
    new "من- من می‌فهمم که ممکنه احساس شکسته شدن داشته باشی."

    # say L1172 pla
    old "But the reason I'm helping you is because I believe in you and your talent."
    new "ولی دلیلی که من به تو کمک می‌کنم اینه که من به تو و تالانتت باور دارم."

    # say L1179 bri
    old "She's afraid of being rejected [pla]!"
    new "او از رد شدن می‌ترسه [pla]!"

    # say L1180 bri
    old "What strong emotions, wow!"
    new "هیجان‌های قوی، وای!"

    # say L1183 pla
    old "You know, I understand that you may feel a fear of being rejected."
    new "می‌دونی، من فهمیدم که ممکنه ترسی از رد شدن داشته باشی."

    # say L1185 pla
    old "But I do believe you're more than capable of getting the role."
    new "ولی من باور دارم تو قابلیت کافی رو برای این نقش داری."

    # say L1187 pla
    old "You have been trying for so long to finally get an acting career."
    new "تو همیشه برای اینکه در نهایت شغل بازیگری پیدا کنی تلاش کردی."

    # say L1189 pla
    old "And you haven't ever given up no matter what."
    new "و تو هرگز تسلیم نشدی، هر چه بود."

    # say L1191 pla
    old "I just know that you have an amazing amount of passion for this."
    new "می‌دونم تو برای این کار همین قدر عاشق هستی."

    # say L1193 pla
    old "With how hard you've worked, I don't think anyone deserves the role any more than you do."
    new "با همه تلاشت که کردی، فکر نمی‌کنم کسی بیشتر از تو به این نقش احقاق داشته باشه."

    # say L1197 pla
    old "Of course I do, I truly believe in what you can do."
    new "البته، من واقعاً به توانایت باور دارم."

    # say L1198 pla
    old "What do you say?"
    new "چه می‌گی؟"

    # say L1199 pla
    old "Will you give it a try?"
    new "می‌تونی امتحانش بکنی؟"

    # say L1210 pla
    old "Of course you should. I know, you'll crush it."
    new "البته باید. میدونم تو اینو خوب انجام می‌دی."

    # say L1215 pla
    old "You're welcome Barbie, I know you'll do great."
    new "بله باربی، مطمئن هستم که خوب انجام می‌دی."

    # say L1216 pla
    old "Anyway, I have to go home for now."
    new "باید حالا برای خونه برم."

    # say L1217 pla
    old "But I'll send you the info about the address and date for the audition."
    new "ولی اطلاعات آدرس و تاریخ آزمون را به تو می‌فرستم."

    # say L1221 pla
    old "I'll see you later then, bye."
    new "بعداً می‌بینیم، خداحافظ."

    # say L1238 pla
    old "Alright, that went well."
    new "باشه، اینجوری خوب بود."

    # say L1239 pla
    old "Thanks for the help Brixxida."
    new "ممنون از کمکت بریکسیدا."

    # say L1241 bri
    old "Yeah yeah, but why aren't you having sex already with her?"
    new "بله بله، ولی چرا هنوز با او جنس نکرده‌ای؟"

    # say L1244 bri
    old "I told you how she was feeling so that you could have sex with her right away!"
    new "من به تو گفتم که اونجوری حس می‌کنه تا بشه همین حالا جنسی باهاش کرد!"

    # say L1245 bri
    old "Two times talking and you still haven't achieved anything."
    new "دو بار حرف زدی و هنوز هیچ کاری انجام ندادی."

    # say L1246 bri
    old "What's taking you so long?"
    new "چرا طول می‌کشی؟"

    # say L1247 pla
    old "I thought I told you."
    new "من فکر کردم به تو گفته‌ام."

    # say L1248 pla
    old "Is not so simple to get somebody into bed."
    new "به بید اینقدر ساده نیست کسی رو به بیت برسونی."

    # say L1250 pla
    old "You can't just say something nice to someone once or twice, and suddenly they'll want to fuck you out of nowhere."
    new "نمی‌تونی فقط یه دفعه یا دو دفعه چیز خوبی به کسی بگی و ناگهان بیاد بخواهند با تو جنسی شنید."

    # say L1251 bri
    old "Ok, then how long will it take?"
    new "خب، پس چقدر طول می‌کشه؟"

    # say L1252 bri
    old "You're not the only one who's making an effort, you know?"
    new "تو نه تنها کسی نیستی که تلاش می‌کنه، میدونی؟"

    # say L1254 bri
    old "I'm using a lot of magical power every time I read her mind, this isn't easy to do."
    new "هر بار که ذهنش رو می‌خونم، خیلی توانایی جادویی استفاده می‌کنم، این کار آسون نیست."

    # say L1255 bri
    old "And unlike in my world, magical power isn't infinite here."
    new "و برخلاف جهان من، قدرت سحر اینجا نامحدود نیست."

    # say L1256 pla
    old "I know, and I understand that this must be hard for you."
    new "می‌دونم، و متوجهم که این برایت سخته."

    # say L1258 pla
    old "But I can't just ask her to have sex with me just because. That's not how it works."
    new "ولی نمی‌تونم ازش بخواهم فقط برای همین جنس کنه. اینجوری کار نمی‌شه."

    # say L1260 bri
    old "You humans are so complicated. When shinigamis have sex is just an energy exchange. Nothing else."
    new "شما انسان‌ها خیلی پیچیده هستید. وقتی شینیگامی‌ها جنس می‌کنند فقط تبادل انرژی است. هیچ چیز دیگری نیست."

    # say L1261 pla
    old "Listen, I'm doing my best to do what we need. So just trust me on this and let me handle it. Ok?"
    new "بله، من بهتر تلاش می‌کنم که این کار رو انجام بدم. پس فقط به من اعتماد کن و بگذار من این رو مدیریت کنم. خوب؟"

    # say L1263 bri
    old "Okay,  I'll trust that you know what you're doing."
    new "باشه، اعتماد می‌کنم که می‌دونی چی کار می‌کنی."

    # say L1264 bri
    old "But don't take too long, I remind you that this is just the beginning of this process."
    new "اما زودتر انجام بده، به تو یادت دادم که این فقط شروع همه‌چیزه."

    # say L1266 pla
    old "Don't worry, I haven't forgotten about that."
    new "نگران نباش، من فراموش نکردم."

    # say L1292 pla
    old "I'm ok, I came to check up on you."
    new "من خوبم، بیا تا از تو پرسش کنم."

    # say L1294 pla
    old "I wanted to know how the audition went."
    new "می‌خواستم بدونم آزمون چطور بود."

    # say L1296 pla
    old "Did it go well? Did you feel alright?"
    new "خوب بود؟ حس خوبی داشتی؟"

    # say L1310 pla
    old "Alright, that sounds great. When's the next audition?"
    new "باشه، این خوبه. اون بعدی کیه؟"

    # say L1319 pla
    old "I see, and how long is it?"
    new "ببینم، و چقدر طول می‌کشه؟"

    # say L1325 pla
    old "Ohh wow, t- that's a lot."
    new "اوه وای، م- می‌تونه همینقدر باشه."

    # say L1333 pla
    old "Oh, come on, why not?"
    new "اوه، بیای، چرا نه؟"

    # say L1340 pla
    old "{i}Could you please give me a hand...{/i}"
    new "{i}می‌تونی به من کمک کنی...{/i}"

    # say L1346 bri
    old "Ok, I'm getting some strong emotional waves from her!"
    new "خب، امواج عاطفی قوی از او می‌آیند!"

    # say L1347 bri
    old "She's feeling, very, very insecure."
    new "او خیلی، خیلی امنیت نداره."

    # say L1348 bri
    old "I hadn't seen her like that before."
    new "قبلا هیچ وقت اینجوری ندیده‌ام."

    # say L1350 bri
    old "She's closing her emotions! Just say something to reassure her."
    new "او عاطفه‌اش رو می‌بنده! فقط چیزی بگو تا اطمینانش رو بدهی."

    # say L1352 pla
    old "I- I understand what you're saying Barbie... I really do."
    new "من- من می‌فهمم چه می‌گی‌ی Barbie... واقعاً می‌فهمم."

    # say L1354 pla
    old "But you know... Uhh, I don't think that this is as bad a situation as you think."
    new "اما می‌دونی... اوه، فکر نمی‌کنم این وضعیت همینجور بد باشه مثلی که تو فکر می‌کنی."

    # say L1359 bri
    old "Yeah, why not?"
    new "بله، چرا نه؟"

    # say L1360 pla
    old "Uhh... Well, that's certainly a lot of pages, but I don't think they are expecting you to memorize all of it."
    new "اوه... خب، البته صفحات زیادی هست، ولی فکر نمی‌کنم بخواهند همه‌شو حفظ کنی."

    # say L1361 pla
    old "I think it's more about how you say and act with the lines."
    new "فکر کنم مهم‌تر اینه که چطور خطوط رو می‌گیی و باهاشون رفتار می‌کنی."

    # say L1363 pla
    old "Maybe all you have to do is read it ahead of time, and practice it."
    new "شاید فقط باید قبل از وقت خونده و تمرین کنی."

    # say L1373 pla
    old "Ok, how about you do it with me?"
    new "باشه، چطور اینجوری با من انجام بدی؟"

    # say L1375 pla
    old "Sure, I mean, I don't know anything about acting, but I could still read the dialogues with you."
    new "بله، منظورم اینه که من هیچ چیزی درباره بازیگری نمی‌دونم، ولی می‌تونم با تو دیالوگ‌ها رو بخونم."

    # say L1376 pla
    old "And I could give you my opinion about how I think you are doing it."
    new "و من می‌تونم نظرم رو در مورد اینکه چطور انجام میدی بهت بگم."

    # say L1380 pla
    old "Well, we don't lose anything by trying, and this way, you could be more prepared for your role."
    new "خب، هیچ جور از امتحان کردن خسارتی نمی‌بیاد، و اینجوری می‌تونی برای نقشت آماده‌تر شی."

    # say L1393 pla
    old "How about you come to my house after you leave work."
    new "بیا به خونه‌ام بعد از کار"

    # say L1395 pla
    old "And we can start practicing."
    new "و می‌تونیم شروع به تمرین کنیم."

    # say L1401 pla
    old "So, what do you think if you let me take a look at the script they gave you while I wait for you to finish your shift?"
    new "پس، چطور می‌تونی برام اجازه بدی که نگاهی به اون سکانیو که بهت دادن بیاندازم، همینجا منتظرت بمونم تا شیفتت تمام بشه؟"

    # say L1406 pla
    old "Okay, I'll go through them while you finish. I'll be in the hallway."
    new "باشه، من همشون را بررسی می‌کنم در حالی که تو کارت رو تمام می‌کنی. من در راهرو خواهم بود."

    # say L1417 pla
    old "Great, let's go."
    new "عالی، برویم."

    # say L1433 pla
    old "So, I checked out the script, and honestly, it's pretty interesting."
    new "من اون سکریپت را بررسی کردم و صد در صد جالب هست."

    # say L1435 pla
    old "Yeah, and I really do think you're not supposed to memorize this. It's rather about you reading it."
    new "بله، و من واقعاً فکر می‌کنم نباید اینو حفظ کنی. بیشتر اینجاست که بخونی."

    # say L1436 pla
    old "Otherwise I don't think anybody could learn this entire thing by memory."
    new "البته، من فکر می‌کنم هیچ‌کس نتونه این همه چی رو به خاطر بسپره."

    # say L1437 pla
    old "Besides, if there are several participants the audition would just take too long."
    new "البته، اگر شرکت‌کننده‌ها زیاد باشند، مصاحبه طول می‌کشد."

    # say L1441 pla
    old "What I think is best is for us to focus on how you can portray the character."
    new "به نظر من بهتره تمرکز کنیم روی اینکه می‌تونی شخصیت رو نشون بدی."

    # say L1442 pla
    old "I mean, act as you read, so you can be better prepared tomorrow having practiced your role."
    new "من قصد دارم بگم که وقتی می‌خونی، نقشت رو بهتر بازی کنی تا فردا آماده‌تر باشی."

    # say L1443 pla
    old "I know a scene with a lot of emotions."
    new "من یه صحنه می‌دونم که احساسات زیادی داره."

    # say L1444 pla
    old "Here, take the full script, I got a few copies..."
    new "بگیر، این همه صفحه رو، چند نسخه برداشتم..."

    # say L1448 pla
    old "Is in the second act, page 57."
    new "در اکت دوم، صفحه ۵۷."

    # say L1449 pla
    old "The two protagonists are fighting, but the scene ends in their reconciliation, I think it would be appropriate."
    new "دو نفر اصلی با هم در حال جنگ هستند، اما صحنه با آرامش آنها تمام می‌شود، فکر کنم مناسب است."

    # say L1452 pla
    old "Alright, let's start with the reading, and I'll give you pointers along the way."
    new "باشه، بیایم شروع به خواندن کنیم، من هم در میان نکاتت بهت بدم."

    # say L1459 pla
    old "'Don't leave! Don't turn your back on me now!'"
    new "برو نمی‌رو! حالا به من پشت نده!"

    # say L1461 pla
    old "'If you do, what little remains of this heart will disappear!'"
    new "اگه اینجوری کنی، آنچه از این قلب باقی مونده هم محو می‌شه!"

    # say L1484 pla
    old "Hmm... Barbie?"
    new "Hmm... باربی؟"

    # say L1487 pla
    old "I think you're doing it... Well."
    new "فکر کنم خوب انجام می‌دی..."

    # say L1489 pla
    old "But, the volume of what you're saying is a little high."
    new "اما، حجم صدایت کمی بالاست."

    # say L1491 pla
    old "Also, you're... Yelling some words, and saying others a little low."
    new "همچنین، بعضی از کلمات رو... صدا می‌زنه، و بعضی رو خیلی آرام می‌گی."

    # say L1494 pla
    old "Hmm, it's okay to add emotion to the lines, but try to keep the volume average, or it might sound a bit odd."
    new "Hmm، اضافه کردن احساس به خطوط خوبه، ولی سعی کن حجم صدایت متوسط باشه، یا ممکنه کمی عجیب به نظر برسه."

    # say L1497 pla
    old "Great, let's try it again."
    new "عالی، بیاین دوباره سعی کنیم."

    # say L1501 pla
    old "You know what? Maybe it isn't necessary to start over every time."
    new "دیویس، ممکنه هر بار از اول شروع نکنیم."

    # say L1502 pla
    old "How about you just keep reading where you left it?"
    new "بیا، ادامه بده جایی که متوقف شدی."

    # say L1512 pla
    old "{i}(Why is she making that accent in those words?){/i}"
    new "{i}چرا اون اکسنت رو در اون کلمات می‌زنه؟{/i}"

    # say L1516 pla
    old "Oh, right, right."
    new "اوه، درسته، درسته."

    # say L1521 pla
    old "'Why? You ask?'"
    new "چرا؟ تو پرسیدی؟"

    # say L1522 pla
    old "'Because it isn't little!'"
    new "چون کوچیک نیست!"

    # say L1523 pla
    old "'What I offer is my heart!'"
    new "چیزی که به تو ارائه می‌کنم قلبم است!"

    # say L1524 pla
    old "'Naked, with no obstructions, just for you!'"
    new "بله، بدون هیچ مانعی، فقط برای تو!"

    # say L1548 pla
    old "I see..."
    new "می‌بینم..."

    # say L1550 pla
    old "But maybe that's not necessary, you know?"
    new "اما شاید این لازم نیست، می‌دونی؟"

    # say L1551 pla
    old "I think it can be a little distracting."
    new "من فکر می‌کنم می‌تونه یه کم توجه رو پرتونه."

    # say L1553 pla
    old "And people might not understand what you're trying to do."
    new "و احتمالاً مردم متوجه نشون خواهند شد که می‌خوای چی کنی."

    # say L1559 pla
    old "Hey, that's why we're practicing."
    new "ببین، همین به همین خاطر تمرین می‌کنیم."

    # say L1560 pla
    old "I don't think you need to feel bad about it."
    new "فکر نمی‌کنم باید از این ناراحت باشی."

    # say L1561 pla
    old "Come on, don't let yourself feel down, let's continue."
    new "بیا، نباید خودت رو ناراحت کنی، بیاین ادامه بدیم."

    # say L1566 pla
    old "'How can you say that I let you down?'"
    new "چطور می‌تونی بگی من تو رو ناراحت کردم؟"

    # say L1567 pla
    old "'When I gave everything to you?!'"
    new "وقتی همه‌چی رو به تو دادم؟!"

    # say L1568 pla
    old "'I left myself change for your sake!'"
    new "من برای تو تغییر کردم!"

    # say L1569 pla
    old "'For our sake!'"
    new "برای ما!"

    # say L1570 pla
    old "'All I've ever wanted in this relationship is to give you happiness!'"
    new "همیشه در این رابطه هدفم این بوده که تو رو خوشحال کنم!"

    # say L1584 pla
    old "'I didn't leave!'"
    new "من نرفتم!"

    # say L1585 pla
    old "'I couldn't be here for you!'"
    new "من نمی‌تونستم برایت اینجا باشم!"

    # say L1586 pla
    old "'There's no way I wouldn't be here if I could avoid it!'"
    new "حتماً اگر بتونستم، هیچ جای دیگه نمی‌موندم!"

    # say L1587 pla
    old "'You have to believe.'"
    new "باید باور کنی."

    # say L1588 pla
    old "'You're my life!'"
    new "تو حیات منی!"

    # say L1589 pla
    old "'You're my heart!'"
    new "تو قلب منی!"

    # say L1600 pla
    old "Uhh... So, there's something else I'd like to tell you."
    new "اوه... در واقع چیزی دیگه‌ای هست که می‌خوام بهت بگم."

    # say L1606 pla
    old "Well, is just that..."
    new "خب، فقط اینه که..."

    # say L1607 pla
    old "You keep changing your face while reading the lines."
    new "تو هر وقت خطوط رو می‌خونی، صورتت همینجوری تغییر می‌کنه."

    # say L1609 pla
    old "I- uh... No, I wouldn't say is wrong."
    new "من- اوه... نه، نمی‌گم اشتباهه."

    # say L1610 pla
    old "Is just that it's a little distracting from the dialogue, that's all."
    new "فقط اینجاست که کمی از دیالوگ توجه رو پرت می‌کنه، همه‌چی."

    # say L1611 pla
    old "I wouldn't say is a bad thing though."
    new "ولی من نمی‌گم بد بودن."

    # say L1619 pla
    old "W- what are you talking about?"
    new "و- و درباره چه چیزی حرف می‌زنی؟"

    # say L1620 pla
    old "W- why?"
    new "چ- چرا؟"

    # say L1625 pla
    old "B- but that's just me tryting to help you!"
    new "ب- ولی این فقط من هستم که می‌خوام به تو کمک کنم!"

    # say L1626 pla
    old "But I don't think you're bad."
    new "ولی فکر نمی‌کنم بد باشی."

    # say L1628 pla
    old "You just need a little practice."
    new "تو فقط نیاز به تمرین کمی داری."

    # say L1629 pla
    old "You know, to learn the character."
    new "می‌دونی، برای یادگیری شخصیت."

    # say L1637 pla
    old "W- what? Are you serious?"
    new "و- وای، جدی می‌گی؟"

    # say L1641 pla
    old "Come on, you can't just give up like this."
    new "بیا، نمی‌تونی اینجوری خودت رو تسلیم کنی."

    # say L1642 pla
    old "You have to try it."
    new "باید امتحانش کنی."

    # say L1646 pla
    old "It isn't impossible, you don't have to know the script."
    new "این غیرممکن نیست، نیازی نداری اسکریپت رو بلد باشی."

    # say L1647 pla
    old "Or even read the whole thing."
    new "یا حتی همه‌ش رو بخونی."

    # say L1648 pla
    old "Let's just keep practicing this part."
    new "بیای بیشتر این بخش رو تمرین کنیم."

    # say L1649 pla
    old "And I'm sure you'll be able to use what we practice here today for the audition tomorrow."
    new "و مطمئن هستم که بتونی از آنچه امروز تمرین می‌کنیم برای آزمون صداپیشگی فردا استفاده کنی."

    # say L1661 bri
    old "[pla], is just the same as earlier, her emotions are all over the place!"
    new "[pla]، همونطوره که اول بود، حالتون همه جا پخش شده!"

    # say L1662 bri
    old "I'm not even reading her mind right now and I can tell."
    new "من حتی حالا ذهنش رو خواند نیستم و می‌دونم."

    # say L1664 bri
    old "Let me see."
    new "بیاین ببینم."

    # say L1671 bri
    old "Hmm, I don't know."
    new "Hmm، نمی‌دونم."

    # say L1672 bri
    old "All I can tell is that she's incredibly stressed."
    new "تنها چیزی که می‌تونم بگم اینه که او خیلی استرس داره."

    # say L1673 bri
    old "It's amazing [pla], she's under so much tension!"
    new "البته [pla]، او تحت فشار شدیدی است!"

    # say L1674 bri
    old "With the way she's feeling now she won't listen to anything you have to say to her."
    new "با حالتون که الان هست، هیچ چیزی که بهش می‌گی زنگ نمی‌خوره."

    # say L1678 pla
    old "{i}What about you? Don't you have something that could be useful?{/i}"
    new "{i}تو چطوری؟ چیزی نداری که می‌تونه کمک کنه؟{/i}"

    # say L1680 pla
    old "{i}Like a spell to calm her nerves or something?{/i}"
    new "{i}مثل جایزه‌ای برای آرامش دادن به اعصابش یا چیزی؟{/i}"

    # say L1681 bri
    old "There's nothing like that."
    new "هیچ چیزی مانند اون ندارم."

    # say L1683 bri
    old "Yeah, all I could do with a spell is try to influence her will, but there's nothing to change emotions into others."
    new "بله، تنها چیزی که می‌تونم با یه جادو انجام بدم اینه که خواسته‌اش رو تغییر بدیم، اما هیچ چیزی برای تغییر احساساتش به چیز دیگه نیست."

    # say L1685 pla
    old "{i}Because she's very certain that she's terrible.{/i}"
    new "{i}چون او خیلی مطمئن هست که خودش بد هست.{/i}"

    # say L1687 bri
    old "Isn't there anything you could use to calm her feelings?"
    new "آیا هیچ چیزی برای آرام کردن احساساتش نیست؟"

    # say L1688 bri
    old "Don't you humans have a substance you ingest in these situations?"
    new "آدم‌ها شما در این موقعیت‌ها چیزی مصرف می‌کنید؟"

    # say L1689 bri
    old "I've seen your [mo1rel] use it before, she seems to calm down with it."
    new "من قبلاً دیدم [mo1rel] از اون چیز استفاده می‌کنه، به نظر می‌رسه با اون آرام می‌شه."

    # say L1697 pla
    old "What? No, no, nothing like that."
    new "نه، نه، هیچ چیزی مثل اون نیست."

    # say L1698 pla
    old "I'm sure you can do it."
    new "مطمئنم تو می‌تونی این کار رو بکنی."

    # say L1699 pla
    old "Just wait here a second, I know of something that can help."
    new "بیا اینجا صبر کن یه لحظه، می‌دونم چیزی هست که می‌تونه کمکت کنه."

    # say L1710 pla
    old "Alright, I think this is just what we need."
    new "خب، فکر می‌کنم این همون چیزیه که بهش نیاز داریم."

    # say L1712 pla
    old "Well, no, not really."
    new "خب، نه، واقعاً نه."

    # say L1713 pla
    old "But I think that drinking a little might help."
    new "ولی فکر می‌کنم نوشیدن یه کم می‌تونه کمک کنه."

    # say L1716 pla
    old "I can't remember exactly where I read it"
    new "من دقیقاً به خاطر نمی‌آورم کجا خوندم"

    # say L1717 pla
    old "But it was about how some famous actors sometimes drink a little alcohol before shooting some of their scenes."
    new "اما این در مورد این بود که برخی بازیگران مشهور گاهی قبل از فیلمبرداری صحنه‌هایشون یه کم الکل می‌نوسن."

    # say L1718 pla
    old "This is supposed to help them feel relaxed, and be able to act more naturally."
    new "این باید بهشون کمک کنه آرام شدن و بتوانن طبیعی‌تر بازی کنن."

    # say L1721 pla
    old "I understand that it seems a bit odd, but we could give it a try."
    new "فهمیدم که عجیب به نظر می‌رسه، ولی می‌تونیم امتحانش کنیم."

    # say L1722 pla
    old "After all, you are feeling a little stressed. Maybe this could help you relax enough for you to recite the lines."
    new "در نهایت، تو کمی استرس داری. شاید این به تو کمک کنه که آرام شو و خطوط رو بخونی."

    # say L1726 pla
    old "Oh come on, you can be a little bit more positive than that. I'm sure this is going to help you."
    new "بیا، می‌تونی مثبت‌تر باشی. مطمئنم این بهت کمک می‌کنه."

    # say L1750 pla
    old "I'm glad you like it."
    new "خوشحالم که لذت برده‌ای."

    # say L1751 pla
    old "Do you feel better now?"
    new "حالا حالت بهتر شده؟"

    # say L1765 pla
    old "I see you're feeling better. Let's try it."
    new "ببینم حالت بهتر شده. بیاین امتحان کنیم."

    # say L1771 pla
    old "I can prove it!'"
    new "من می‌تونم اثبات کنم!"

    # say L1772 pla
    old "'I can tell you!"
    new "من می‌تونم به تو بگم!"

    # say L1773 pla
    old "'I'm here now! And you didn't call me!'"
    new "من حالا اینجا هستم! و تو نخواندی منو!"

    # say L1774 pla
    old "'I came because you needed me!'"
    new "من برای این جاومدم که نیازت به من بود!"

    # say L1783 pla
    old "{i}(Now it's my line, I better not brake her concentration now that she's finally doing it well.){/i}"
    new "{i}(حالا منم باید جمله‌ام رو بگم، نمی‌تونم اون قسمت تمرکزشو بشکنم حالا که بالاخره خوب می‌کنه.){/i}"

    # say L1788 pla
    old "'Not staying was a mistake!'"
    new "موندن اشتباه بود!"

    # say L1789 pla
    old "'I should've stayed by your side, I should've been here when you needed me!'"
    new "باید کنار تو موندم، باید وقتی نیازت به من بود اینجا بودم!"

    # say L1790 pla
    old "'But that's why I'm here now!'"
    new "ولی همین‌جوری حالا اینجا هستم!"

    # say L1791 pla
    old "'To be your companion!'"
    new "تا همراه تو باشم!"

    # say L1792 pla
    old "'Your rock! Your partner!'"
    new "سنگت! همکار تو!"

    # say L1805 pla
    old "'I will be!'"
    new "من خواهم بود!"

    # say L1806 pla
    old "'I promise you!'"
    new "بله، قول می‌دهم!"

    # say L1814 pla
    old "You know what? It was, it really was."
    new "دیت روش، واقعاً همین بود."

    # say L1815 pla
    old "I think the alcohol really helped you. Because that last part was great."
    new "من فکر می‌کنم الکل واقعاً به تو کمک کرد. چون اون قسمت آخر واقعاً عالی بود."

    # say L1816 pla
    old "But let's keep going until we finish this part of the dialogue."
    new "اما بیاین تا این بخش رو تمام کنیم."

    # say L1822 pla
    old "'So! Do you believe me when I say it?'"
    new "پس! آیا وقتی می‌گم باورت می‌شه؟"

    # say L1823 pla
    old "'That I want to be by you!'"
    new "من می‌خوام کنار تو باشم!"

    # say L1824 pla
    old "'That I need to be by your side!'"
    new "من باید کنار تو باشم!"

    # say L1825 pla
    old "'Nothing would make me happier!'"
    new "هیچ چیز مرا خوشحال‌تر نمی‌کند!"

    # say L1840 pla
    old "'It means that we love each other!'"
    new "این بیان اینه که ما دوست داریم هم هستیم!"

    # say L1849 pla
    old "{i}(Hmm, there's a kiss scene coming, and I didn't tell her where the scene would end.){/i}"
    new "{i}( Hmm، نگاه کنم اینجا صحنه‌ای از بوسیدن هست و من به او نگفتم که صحنه چه جا تمام می‌شه.){/i}"

    # say L1850 pla
    old "{i}(She won't kiss me without talking with me about it, right?){/i}"
    new "{i}(او بدون اینکه با من صحبت کنه نمی‌بوسه من، درسته؟){/i}"

    # say L1860 pla
    old "'I can, and I will!'"
    new "من می‌تونم، و خواهم کرد!"

    # say L1861 pla
    old "'If you say yes now I promise I'll always be there!'"
    new "اگر الان بله می‌گی، قول می‌دم همیشه کنارت باشم!"

    # say L1862 pla
    old "'I will always be the rock that you need!'"
    new "من همیشه سنگی برایت خواهم بود که به آن سندی!"

    # say L1863 pla
    old "'No matter what!'"
    new "همیشه برایت اینجا خواهم بود!"

    # say L1884 pla
    old "{i}(That was unexpected, but I guess she's really into the role.){/i}"
    new "{i}(این برایم غیرمنتظره بود، اما به نظر می‌رسه او واقعاً به نقش خودش علاقه‌مند است.){/i}"

    # say L1897 pla
    old "'I'll gladly take it!'"
    new "من خوشحالانه می‌گیرم!"

    # say L1898 pla
    old "'But in return, I'll let you have mine!'"
    new "اما به جای آن، من اجازه می‌دم تو از من بگیری!"

    # say L1899 pla
    old "'Because this is a partnership!'"
    new "چون این همکاریه!"

    # say L1900 pla
    old "'We're meant to be together!'"
    new "ما برای هم هستیم!"

    # say L1901 pla
    old "'I know it!'"
    new "می‌دونم!"

    # say L1924 pla
    old "'Are you sure?'"
    new "مطمئنی؟"

    # say L1925 pla
    old "'Does this mean that you'll stay by my side?'"
    new "این بمعنای اینه که تو همیشه کنارم می‌مانی؟"

    # say L1960 pla
    old "Uhh... Y- yeah, it was, it really, really was."
    new "اوه... ب- بله، واقعاً، واقعاً همین‌جوری بود."

    # say L1961 pla
    old "I- I mean, your acting was great."
    new "من قصه‌تو خوب بازی کردی، واقعاً خوب بود."

    # say L1962 pla
    old "I think you won't have any problems when the audition comes."
    new "فکر می‌کنم وقتی مصاحبه برگزار شد، هیچ مشکلی نخواهی داشت."

    # say L1966 pla
    old "Hmm... Sure."
    new "Hmm... بله."

    # say L1979 pla
    old "Okay."
    new "باشه."

    # say L1980 pla
    old "But maybe we should change the scene because this one ends in a love scene between the leads."
    new "اما شاید باید صحنه رو تغییر بدیم چون این به یه صحنه عاشقانه بین اصلی‌ها می‌رسه."

    # say L1981 pla
    old "So, we could look for another one."
    new "پس می‌تونیم جایی دیگه بیابیم."

    # say L1987 pla
    old "U- Uhh, I- I don't know how- ."
    new "ا- اوه، من- من نمی‌دونم چ- چطور."

    # say L1998 pla
    old "Don't you think you're drinking a little too much of that?"
    new "می‌تونی یه کم کمتر از اون نوشیدنی بیاد؟"

    # say L2015 pla
    old "W- what are you doing Barbie?"
    new "ب-�اربی، تو چه کاری داری؟"

    # say L2035 pla
    old "Listen... About last night..."
    new "بله... در مورد شب گذشته..."

    # say L2041 pla
    old "Uhh... Yeah, yeah, sure, don't worry about it..."
    new "اوه... بله، بله، حتماً، نگران نباش..."

    # say L2052 pla
    old "Good luck with the audition, I know you'll do great."
    new "بفرمایی برای آزمون، میدونم خوب می‌کنی."

    # say L2063 bri
    old "That was great [pla]!"
    new "عالی بود [pla]!"

    # say L2065 bri
    old "You finally did it! Well done!"
    new "تو در نهایت انجام دادی! خوب کردی!"

    # say L2067 bri
    old "Of course you'll have to have more sex with her..."
    new "البته باید با او دوباره هم جنسی کنی..."

    # say L2069 bri
    old "But now that you've done it once, you shouldn't have any problems doing it again..."
    new "البته حالا که یک بار انجام دادی، باید برای دوباره هیچ مشکلی نداشته باشی..."

    # say L2070 bri
    old "Now we can focus on finding the next specimen."
    new "البته حالا می‌تونیم تمرکز کنیم برای پیدا کردن نمونه بعدی."

    # say L2073 bri
    old "Well of couse."
    new "البته."

    # say L2074 bri
    old "Now that you know you're going to have sex with this woman so easily."
    new "حالا که می‌دونی با این زن به راحتی جنسیت می‌کنی."

    # say L2075 bri
    old "You can stop wasting time on her and focus on finding the next person we need."
    new "تو می‌تونی وقت رو برایش ضایع نکنی و به جستجوی اون نفر بعدی که به ما لازم هست، بپردازی."

    # say L2076 pla
    old "Hey, hey, stop it right there!"
    new "هی، هی، بیا بگو برات متوقف شو!"

    # say L2077 pla
    old "I don't know what it is you have in mind."
    new "من نمی‌دونم تو چه قصدی داری."

    # say L2079 pla
    old "But is not that easy..."
    new "اما اونقدر ساده نیست..."

    # say L2081 pla
    old "I promised I would help her with this, and I plan to fulfill that promise."
    new "بله، قول دادم که به این کار کمکش کنم، و قصد دارم این قول رو برآورده کنم."

    # say L2083 pla
    old "So I'm sorry to disappoint you, but until she gets an acting job, I won't be looking for another 'specimen'..."
    new "پس متاسفانه اینجا خبر خوبی نداره، تا زمانی که شغل بازیگری پیدا کنه، من به دنبال نمونه‌ای دیگه نمی‌گردم..."

    # say L2085 pla
    old "Besides, I don't think there's going to be a next time having sex with her if I just leave her hanging."
    new "البته، فکر نمی‌کنم دفعه بعدی جنس باش رو اگه هم اجازه بدی به او خیانت کنم، اتفاق بیفتد."

    # say L2086 pla
    old "And you still need me to do it with her more times, isn't it?"
    new "و هنوز هم نیاز داری از من برم این کار رو باهاش بیشتر انجام بدم، درسته؟"

    # say L2088 bri
    old "Ughh! You humans are so complicated!"
    new "آه! شما انسان‌ها خیلی پیچیده هستید!"

    # say L2090 bri
    old "Fine! Do as you wish!"
    new "خوب! بکن همچون خواستت!"

    # say L2092 bri
    old "But do it quickly! We don't have much time to lose!"
    new "اما سریع انجام بده! وقت زیادی نداریم."

    # say L2093 pla
    old "Yeah, yeah, you've made that clear."
    new "بله، بله، این هم خیلی روشن شد."

    # say L2117 pla
    old "Hey Barbie, how are you?"
    new "هی بربری، چطوری؟"

    # say L2121 pla
    old "W- what? Why?"
    new "و- وای؟ چرا؟"

    # say L2126 pla
    old "It did? You didn't feel comfortable?"
    new "بله؟ تو راحت نبودی؟"

    # say L2131 pla
    old "I get it, I mean... I guess fear made you forget the dialogue..."
    new "فهمیدم، منظورم... حدس می‌زنم ترس بهت اینجوری یادت رفت که حرف بزنی."

    # say L2153 pla
    old "Who does he think he is? He has no right to treat you like that!"
    new "او فکر می‌کنه چیه؟ او حق نداره به تو اینجوری برخورد کنه!"

    # say L2154 pla
    old "I'm sorry Barbie, you didn't deserve him treating you like that."
    new "ببخشید بربی، تو اینجوری رفتارش رو نمی‌تونستی تحمل کنی."

    # say L2160 pla
    old "No you're not, don't make what he told you a law."
    new "نه تو نیستی، نباید اون حرفایی رو قانون بکنی."

    # say L2161 pla
    old "You're very talented Barbie, I saw it the other day while we were practicing."
    new "باربی، تو خیلی موهبت داری، همون روزی که تمرین می‌کردیم دیدم."

    # say L2162 pla
    old "I'm sure it's going to be better in the next audition you go to."
    new "مطمئن هستم در آزمون بعدیت بهتر خواهد بود."

    # say L2167 pla
    old "B- but that's your dream, to be part of show business."
    new "ب- ولی اون همون رویایت هست، برای ورود به صنعت سرگرمی."

    # say L2168 pla
    old "You know, to work in acting and stuff."
    new "می‌دونی، برای بازیگری و همچین."

    # say L2180 pla
    old "Wait! Wait!"
    new "پیش! پیش!"

    # say L2181 pla
    old "Don't think so bad about yourself!"
    new "فکر بدی در مورد خودت نکن!"

    # say L2182 pla
    old "You shouldn't believe that you're not good enough to act!"
    new "نباید باور کنی که برای بازیگری کافی نیستی."

    # say L2183 pla
    old "I know you're more than capable of it."
    new "میدونم تو قابلیت کافی برای این کار رو داری."

    # say L2191 pla
    old "Hey I have an idea!"
    new "بله من یه ایده دارم!"

    # say L2192 pla
    old "Listen, I know you're feeling bad."
    new "بله، می‌دونم تو خوب حس نمی‌کنی."

    # say L2193 pla
    old "But I think there's a way so that you don't have to give up on your dream."
    new "اما فکر می‌کنم راهی هست که نباید از رویا‌ت صرف نظر کنی."

    # say L2197 pla
    old "I get it, but listen, your dream is to be famous, right?"
    new "من متوجهم، ولی بگو، رویا‌ت اینه که مشهور بشی، درسته؟"

    # say L2198 pla
    old "But there's more than one way of achieving it."
    new "اما راه‌های مختلفی برای رسیدن به اون وجود داره."

    # say L2200 pla
    old "For example, have you thought about modeling?"
    new "مثلاً، فکر کردی به مدلینگ؟"

    # say L2204 pla
    old "Sure!  Listen, maybe you're right about not being the best actor right now."
    new "بله! ولی ممکنه همین حالا بهترین بازیگر نباشم."

    # say L2205 pla
    old "But that's not the only way to earn fame."
    new "اما این تنها راه برای به دست آوردن شهرت نیست."

    # say L2206 pla
    old "There are several different things that you can do."
    new "می‌تونی چیزهای مختلفی انجام بدی."

    # say L2208 pla
    old "And I think you could easily be an amazing model!"
    new "و فکر می‌کنم می‌تونی راحتی یک مدل عالی باشی!"

    # say L2211 pla
    old "Of course I do!"
    new "البته که می‌تونم!"

    # say L2212 pla
    old "There are several actors that got their start as models, and over time they moved into acting."
    new "چند تا از بازیگران هم از مدل شروع کردن و با گذشت زمان به بازیگری روی آوردند."

    # say L2213 pla
    old "With how beautiful you are. I don't see why you couldn't do the same thing."
    new "با چقدر زیبایتی داری. نمی‌دونم چرا نتونی همین کار رو بکنی."

    # say L2217 pla
    old "You have to be kidding me."
    new "می‌خوای با من شوخی کنی؟"

    # say L2218 pla
    old "I mean, look at yourself. You're beautiful."
    new "من می‌گم، خودت رو ببین. زیبا هستی."

    # say L2219 pla
    old "And you have an amazing body!"
    new "و تو یک بدن شگفت‌انگیز داری!"

    # say L2220 pla
    old "Of course you can be a model!"
    new "البته می‌تونی مدل بشی!"

    # say L2227 pla
    old "How can you say that?"
    new "چطور می‌تونی اینا بگی؟"

    # say L2228 pla
    old "Maybe what you're saying about models was true several years ago."
    new "شاید آنچه می‌گویی درباره مدل‌ها چند سال پیش درست بود."

    # say L2230 pla
    old "But there are several different types now. And you are one of the most beautiful women that I've met."
    new "ولی الان انواع مختلفی هستن. و تو یکی از زیباترین زنانی هستی که دیدم."

    # say L2231 pla
    old "I'm sure you'll find work in any agency you want in no time."
    new "مطمئن هستم که تو زودی کار در هر آژانسی که خواستی پیدا می‌کنی."

    # say L2236 pla
    old "Of course I believe it. And I'm sure it's going to go great."
    new "البته باورم هست. و مطمئنم که خوب می‌ری."

    # say L2240 pla
    old "R- right... Sure."
    new "بله... البته."

    # say L2241 pla
    old "I'll get you something as a model."
    new "من چیزی برایت به عنوان مدل می‌آورم."

    # say L2242 pla
    old "So, I'm going to have to make a couple of calls, but I'll let you know later about what I find."
    new "پس، باید چند تا تماس ببرم، ولی بعداً از آنچه پیدا می‌کنم خبرت می‌دم."

    # say L2243 pla
    old "Ok?"
    new "باشه؟"

    # say L2246 pla
    old "You're more than welcome."
    new "ممنونم، خوشحالم که کمک کردم."

    # say L2247 pla
    old "I'm just happy to help."
    new "من فقط خوشحالم که کمک کردم."

    # say L2248 pla
    old "I'll go for now, and I'll see you later, alright?"
    new "من حالا می‌روم، بعداً می‌بینیم، خوبه؟"

    # say L2260 pla
    old "Hmm, I guess it's good that Barbie's feeling better now."
    new "خوب، به نظر می‌رسه خوشحالم که باربی حالا بهتر است."

    # say L2261 pla
    old "But now, how will I get her a modeling casting?"
    new "اما حالا، چطور می‌تونم برایش یه اودیشن مدلینگ پیدا کنم؟"

    # say L2262 pla
    old "I don't know anyone who works as a model or something similar..."
    new "من هیچ کسی نمی‌شناسم که مدل باشه یا چیزی مشابه..."

    # say L2263 pla
    old "Hmph, I don't want to bother Belle again to get me an audition..."
    new "همف، نمی‌خوام دوباره به بل بگم تا برایم اودیشنی پیدا کنه..."

    # say L2264 pla
    old "Who else could help me with this..."
    new "چه کسی دیگه می‌تونه به من کمک کنه..."

    # say L2268 bri
    old "What are you doing?"
    new "تو چه کاری داری؟"

    # say L2270 bri
    old "When you went looking for her, I thought you would come back together to have sex..."
    new "وقتی تو جایش رو می‌گذاشتی، فکر می‌کردم با هم بر می‌گردید تا جنس کنیم..."

    # say L2271 pla
    old "Of course not, things don't work like that..."
    new "البته نه، اینجوری کار نمی‌شه..."

    # say L2273 pla
    old "Perhaps you should be helping me instead of complaining so much."
    new "شاید باید به جای اینکه بهم ترکیب می‌زنشی، به من کمک کنی."

    # say L2274 pla
    old "Maybe this way we can help Barbie more quickly..."
    new "شاید این راه ما بتونیم سریع‌تر به باربی کمک کنیم..."

    # say L2275 pla
    old "And so we can wrap this up and start looking for the next 'specimen' as you want..."
    new "و اینجوری می‌تونیم این کار رو تمام کنیم و شروع به جستجوی بعدی «نمونه» کنیم، مثل آنگه که می‌خوای..."

    # say L2276 bri
    old "Hmph, I guess you leave me no choice..."
    new "همف، به نظر می‌رسه تو هیچ انتخابی برای من نمی‌ذاری..."

    # say L2278 pla
    old "It's not easy, really, unless you magically know somebody that can get a casting with a modeling agency."
    new "این خیلی آسان نیست، مگر اینکه تو به طور جادویی کسی رو بشناسی که بتونه با یک آژانس مدلینگ قرار مونده باشه."

    # say L2280 pla
    old "I need someone who works with models, you know, like these clothes and lingerie brands, or something like that..."
    new "من به کسی نیاز دارم که با مدل‌ها کار می‌کنه، مثلاً این برندهای لباس و لینجری، یا چیزی مثل اون..."

    # say L2287 pla
    old "Wait! I got it! [sis]!"
    new "بیا! فهمیدم! [sis]!"

    # say L2288 pla
    old "Right now it's too late, but tomorrow I'll go talk with my [sisrel]."
    new "الان خیلی دیره، ولی فردا می‌رم و با [sisrel] صحبت می‌کنم."

    # say L2289 bri
    old "Oh no, why do I get the feeling this is going to take even longer?"
    new "اوه نه، چرا احساس می‌کنم این هم بیشتر طول می‌کشه؟"

    # say L2290 pla
    old "Relax, you help me to talk with [sis] tomorrow and we could get Barbie a model job, and that's it."
    new "آرام، فردا تو مرا کمک کنی تا با [sis] صحبت کنم و می‌تونیم برای باربی کار مدل پیدا کنیم، و این همه."

    # say L2291 bri
    old "Hmm, if you say so..."
    new "اگر می‌گی‌ای..."

    # say L2292 pla
    old "Anyway, I'm a bit tired, so, I'm going to sleep now..."
    new "بی، من یه کم خسته‌ام، پس حالا می‌روم بخوابم..."

    # say L2294 pla
    old "See you tomorrow Brixxida."
    new "بای خوب، ببینم چه کاری می‌کنم. ببین همینجا... ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینیم چه می‌شه. ببینی"

    # say L2295 bri
    old "See you..."
    new "ببینم..."

    # say L2318 sis
    old "What brings you here so early?"
    new "چرا اینقدر زود اومدی؟"

    # say L2319 pla
    old "Hey [sis]. Good morning."
    new "هی [sis]. صبح بخیر."

    # say L2322 sis
    old "What's up?"
    new "چه خبر؟"

    # say L2323 pla
    old "W- well... Uhmm."
    new "خب... اومmmm."

    # say L2325 pla
    old "T- the thing is that I kinda need a favor from you."
    new "خوب، اونجوری که می‌دونی، من یه لطفی ازت می‌خوام."

    # say L2328 pla
    old "But... I don't really know how to ask you..."
    new "ولی... نمی‌دونم چطور بپرسم از تو..."

    # say L2329 sis
    old "Well just do it."
    new "بله، فقط بگو."

    # say L2330 sis
    old "You know I'll help you with anything you want."
    new "می‌دونی من به هر چی که می‌خوای کمکت می‌کنم."

    # say L2332 pla
    old "{b}*Sigh*{/b} Well, here it goes..."
    new "{b}*تنفه*{/b} خب، برویم..."

    # say L2334 pla
    old "Do you know Barbie? The receptionist of the building where Jane's office is located?"
    new "باربی رو می‌شناسی؟ همون میزبان بنا که اداره جین قرار داره؟"

    # say L2336 sis
    old "Yeah, sure I do. That silicon-filled bimbo."
    new "بله، حتماً. آن دختر پر سیلیکون."

    # say L2337 sis
    old "What about her?"
    new "درباره‌اش چه کاری؟"

    # say L2338 pla
    old "Uh... W- well, the thing is that..."
    new "اوه... خب، اونجوری که..."

    # say L2339 pla
    old "S- she kind of needs help with something right now, and I promised I would give her that help."
    new "خوب، یعنی اونجوری که می‌دونی، او الان به یه کمکی نیاز داره و من قول دادم بهش کمک کنم."

    # say L2340 sis
    old "Are you serious right now [pla]?!"
    new "هیچ وقت جدی نیستی [pla]؟!"

    # say L2341 sis
    old "What kind of help? And what favor are you gonna ask me?"
    new "چه کمکی؟ و چه لطفی از من می‌خوای؟"

    # say L2342 pla
    old "Well, a few days ago I came into the building to bring some documents from [mo1] and...."
    new "خب، چند روز پیش وارد ساختمون شدم تا برخی اسناد رو از [mo1] بیارم و..."

    # say L2343 pla
    old "We got to talking and she told me that lately she's been feeling very sad about not being able to..."
    new "ما به صحبت پرداختیم و او به من گفت که اخیراً خیلی ناراحت است به خاطر نتواندن..."

    # say L2349 pla
    old "Well, she wants to be a model, so I said that I would help her with that."
    new "خوب، او می‌خواسته مدل شه، پس من گفتم که بهش کمک می‌کنم."

    # say L2350 pla
    old "But the truth is that I have no contacts in the modeling industry."
    new "اما در واقع من هیچ ارتباطی با صنعت مدلینگ ندارم."

    # say L2351 pla
    old "So, I was wondering if you would consider having her model for your online business."
    new "پس من فکر می‌کنم اگر تو قبول کنی که اونجا مدل شه برای کسب و کار آنلاین تو، خوب باشه."

    # say L2353 sis
    old "No I would not accept it!"
    new "نه، من قبول نمی‌کنم!"

    # say L2356 sis
    old "Why would I want that vulgar, plastic bimbo modeling in my clothes?!"
    new "چرا باید اون دختر شوکی و پلاستیکی رو توی لباس‌هام مدل بذارم؟!"

    # say L2357 sis
    old "It would ruin the reputation of my brand!"
    new "این برند من رو خراب می‌کنه!"

    # say L2360 sis
    old "Which by the way, I'm surprised you're so interested in her as to come here and ask me if I would let her model my clothes!"
    new "البته، همینطور که می‌گم، تعجب کردم اینقدر به او علاقه‌مند باشی و بیایی اینجا و از من بپرسی آیا می‌تونم لباس‌هایم رو برایش طراحی کنم!"

    # say L2362 sis
    old "I mean..."
    new "من قصدم اینه..."

    # say L2364 sis
    old "All of this just because you want to bang that stupid girl?"
    new "همه اینا فقط برای اینکه می‌خوای با آن دختر خفن بزنی؟"

    # say L2367 pla
    old "What? Come on, is not like that."
    new "چه کاری؟ بیا، همینطور نیست."

    # say L2368 sis
    old "Oh yeah? Then how is it?"
    new "اوه بله؟ پس چطوره؟"

    # say L2371 sis
    old "Because it seems to me that you're more interested in fucking her than anything else."
    new "چون به نظر می‌رسه تو بیشتر علاقه‌ت به فکر کردن در مورد او هست، نه به چیز دیگه‌ای."

    # say L2372 sis
    old "You men are so predictable, you see some stupid girl with tits and ass like balloons and you go crazy."
    new "شما مردان خیلی پیش‌بینی‌پذیر هستید، یک دختر خفنی با سینه و پاشون مثل بادکنک‌ها می‌بینید و دیوانه می‌شوید."

    # say L2373 pla
    old "I already told you, is not like that..."
    new "من قبلاً به تو گفتم، اینجوری نیست..."

    # say L2374 bri
    old "Boy, you seem to have a talent for altering people's feelings."
    new "بچه، به نظر می‌رسه تالنتت برای تغییر احساسات مردم هست."

    # say L2376 bri
    old "Every time I'm with you, you're making some woman angry or cry or just lose her temper."
    new "هر بار که با تو هستم، تو یه زن رو غصب یا گریه یا فقط خشم‌زده می‌کنی."

    # say L2378 pla
    old "Why don't you help me then?"
    new "چرا نمی‌کمکی به من؟"

    # say L2380 sis
    old "What? Do you need even more explanations?"
    new "چه کاری؟ آیا حتی توضیحات بیشتری هم می‌خوای؟"

    # say L2381 pla
    old "Uhh? No, no, I- I-... Nevermind..."
    new "اوه؟ نه، نه، من- من-... فراموش کن."

    # say L2384 bri
    old "Hahaha, look at you! Grasping for words."
    new "هahaha، نگاه کن به تو! کلمه‌ها رو از دست می‌رون."

    # say L2385 bri
    old "I'll help you then."
    new "من به تو کمک می‌کنم."

    # say L2393 bri
    old "Listen [pla]."
    new "بگوش [pla]."

    # say L2395 bri
    old "She's experiencing a very negative emotion. And it's all directed at you."
    new "او حالا احساسات منفی خیلی زیادی داره. و همه‌ش به تو هستند."

    # say L2397 sis
    old "Anyway, you can leave, I'm busy."
    new "باز هم، می‌تونی بری، من مشغولم."

    # say L2399 bri
    old "No wait! It's not directed at you!"
    new "نخست! این به تو نیست!"

    # say L2402 bri
    old "Is about that girl!"
    new "درباره آن دختر هست!"

    # say L2403 bri
    old "She's..."
    new "او..."

    # say L2405 bri
    old "Jelaous!"
    new "حسود!"

    # say L2407 bri
    old "That's it, she's feeling jealous."
    new "درسته، اونجوری که می‌گم، حسودی داره."

    # say L2408 sis
    old "No, [pla], I'm not gonna help you to bang that bimbo..."
    new "نه، [pla]، من نمی‌تونم به تو کمک کنم تا اون دختر را بزنی..."

    # say L2409 bri
    old "Uhh, you better do something about that or she really won't help you at all."
    new "اوه، بهتره که برای این کاری بکنی، چون واقعاً هیچ کمکی به تو نمی‌کنه."

    # say L2411 pla
    old "I mean, I think I didn't express explain properly."
    new "من قصد دارم، فکر کنم من درست توضیح ندادم."

    # say L2413 pla
    old "Listen, the reason why I want to help Barbie is not that I want to sleep with her or something like that."
    new "بله، منظورم اینه که دلیلی که می‌خوام به باربی کمک کنم، این نیست که بخوام باهاش خواب برم یا چیزی مثل این."

    # say L2414 pla
    old "The truth is that I've been thinking that I would like to be a photographer."
    new "حقیقت اینه که من فکر می‌کنم می‌خوام عکاس شم."

    # say L2417 sis
    old "A photographer?"
    new "عکاس؟"

    # say L2419 pla
    old "Yeah, you know I'm good with the camera."
    new "بله، میدونی من با دوربین خوب هستم."

    # say L2420 pla
    old "And that I know how to edit and present pictures."
    new "و اینکه می‌دونم چطور عکس‌ها رو ویرایش و ارائه کنم."

    # say L2421 pla
    old "So it came to my mind that I could do some work in that field. You know for magazines and stuff."
    new "پس به ذهنم رسید که می‌تونم توی اون حوزه کار کنم. مثل مجلات و همین‌جوری."

    # say L2422 pla
    old "But getting a job as a photographer is too difficult."
    new "اما پیدا کردن شغلی به عنوان عکاس خیلی سخته."

    # say L2423 pla
    old "But then I talked with Barbie, and it came to my mind that maybe that was it."
    new "بعد از آن با باربی صحبت کردم و به ذهنم رسید که شاید این همراهی خوب باشه."

    # say L2424 pla
    old "That if I helped her it could be good for the both of us, and that I could get a job as a photographer like that."
    new "اگر به تو کمک کنم می‌تونه برای هر دو ما خوب باشه، و من هم می‌تونم اینجوری شغل فتوگرافر پیدا کنم."

    # say L2426 sis
    old "Hmm, are you serius?"
    new "Hmm، می‌گیری جدی هستی؟"

    # say L2427 pla
    old "Yeah, that's really all I'm looking for. I don't know where you got the idea about sex..."
    new "بله، این واقعاً همه چیزیه که من به دنبالش هستم. نمی‌دونم ایده‌ی جنسی از کجا به ذهن تو رسید..."

    # say L2429 sis
    old "Well, that's not such a bad idea [pla]."
    new "خب، این هم چنین ایده‌ای بد نیست [pla]."

    # say L2431 sis
    old "It's actually some good thinking on your part."
    new "این در واقع ایده خوبی از طرف توست."

    # say L2432 sis
    old "But why didn't you start with that?"
    new "ولی چرا از اول با این شروع نکردی؟"

    # say L2433 pla
    old "W- well you know."
    new "خوب، می‌دونی."

    # say L2434 pla
    old "I- I didn't think that was that important."
    new "من- من فکر نکردم اینقدر مهمه."

    # say L2436 sis
    old "You didn't think that was important?"
    new "تو فکر نکردی این اهمیتی داره؟"

    # say L2437 sis
    old "But you thought it was more important to just tell me you want to help that plastic bimbo?"
    new "ولی تو فکر کردی مهم‌تره فقط به من بگی خواستی به اون دختر پلاستیکی کمک کنی؟"

    # say L2438 sis
    old "Very smart."
    new "خیلی هوشمندی."

    # say L2440 sis
    old "But anyway, I think I see your point."
    new "اما هر حال، فکر کنم می‌فهمم نکتت چیه."

    # say L2441 sis
    old "And you are good with the camera."
    new "و تو با دوربین هم خوبی."

    # say L2442 sis
    old "You could be a good photographer."
    new "تو می‌تونی عکاس خوبی باشی."

    # say L2443 sis
    old "Now, let me see your portfolio of her pictures."
    new "الان، بیا برام پورتفوی عکس‌هایش رو نشون بده."

    # say L2444 pla
    old "Portfolio?"
    new "پورتفو؟"

    # say L2446 sis
    old "Well of course."
    new "البته."

    # say L2447 sis
    old "I mean, you do have a portfolio of pictures right?"
    new "من قراره، تو یه پورتفو از عکس‌ات داری، درسته؟"

    # say L2448 pla
    old "I- I don't..."
    new "من- من نه..."

    # say L2449 sis
    old "Ugh, be serious [pla]."
    new "آه، جدی باش [pla]."

    # say L2450 sis
    old "You say you want to be a photographer, but you don't know anything."
    new "تو می‌گی بخوای عکاس شی، ولی هیچ چیز نمی‌دونی."

    # say L2451 sis
    old "If you want someone to give you a job in photography you need to have pictures to show."
    new "اگه می‌خوای کسی بهت کار در عکاسی بده باید عکس‌هایی برای نشون دادن داشته باشی."

    # say L2452 sis
    old "Especially with something like pictures of that little plastic dumb."
    new "به خصوص وقتی از عکس‌های آن قطعه پلاستیکی کوچک حرف می‌زنی."

    # say L2453 sis
    old "How else is someone going to hire her?"
    new "چطور دیگه کسی اون رو استخدام کنه؟"

    # say L2454 pla
    old "I understand, so you need me to take pictures of her?"
    new "فهمیدم، پس باید عکس‌هایی از او ببرم؟"

    # say L2455 pla
    old "I think I can do that, and bring some of those for you."
    new "فکر کنم بتونم این کار رو بکنم و برای تو چند تاشونو بیارم."

    # say L2457 sis
    old "Good. Be sure they're good so that I can show them to the people that might hire her."
    new "خوب. حتماً خوب بگیر تا بتونم به افرادی که ممکن است اون رو استخدام کنند نشون بدم."

    # say L2459 sis
    old "By the way, I hope you understand I'm not doing this out of the goodness of my heart, right?"
    new "البته، امیدوارم متوجه باشی که من این کار رو برای خیر و نیکویی قلبم نمی‌کنم، درسته؟"

    # say L2461 sis
    old "If she's going to get money for it, and I got her the job, I want my cut."
    new "اگه پول می‌بره و من کارش رو پیدا کردم، من هم سهمم رو می‌خوام."

    # say L2462 pla
    old "Uhh, yeah yeah, sure..."
    new "آره آره، البته..."

    # say L2463 pla
    old "If you get her a job, then sure, I can give you a commission."
    new "اگه تو بهش کاری میدی، خب بله، میتونم بهت کمیسیون بدم."

    # say L2465 sis
    old "I want a 10 percent! Is that clear?"
    new "من می‌خوام درصد ده! مشخصه؟"

    # say L2466 pla
    old "Sure, whatever."
    new "بله، هر چی دوست داری."

    # say L2467 pla
    old "Hey, thanks a lot [sis]."
    new "بله، ممنون زیادی [sis]."

    # say L2469 sis
    old "Yeah well, I'm not doing it for her."
    new "بله، ولی من برای او این کار رو نمی‌کنم."

    # say L2470 sis
    old "I'm helping you."
    new "من به تو کمک می‌کنم."

    # say L2471 pla
    old "Sure, but thanks anyway."
    new "بله، ولی هر حال ممنون."

    # say L2472 sis
    old "You're welcome."
    new "خواهش می‌کنم."

    # say L2473 pla
    old "I'll talk to Barbie later and let her know about this."
    new "بعداً با باربی صحبت می‌کنم و از این موضوع اطلاعش می‌دهم."

    # say L2475 sis
    old "Listen, I have to leave for now, so I'll send you the info when I get it."
    new "بله، باید حالا برسم، پس وقتی اطلاعات رو گرفتم بهت می‌فرستم."

    # say L2500 pla
    old "I'm doing well, thank you."
    new "من خوب هستم، ممنون."

    # say L2501 pla
    old "Hey listen, I have great news!"
    new "بلا، اسمع، خبر خوبی دارم!"

    # say L2503 pla
    old "You could say that."
    new "می‌تونی همین‌جوری بگی."

    # say L2504 pla
    old "Do you remember what we had talked about modeling?"
    new "می‌تونی به خاطر بیان چه چیزی که در مورد مدلینگ صحبت کردیم؟"

    # say L2506 pla
    old "Well, after we talked I got in contact with someone I know that has some connections to the modeling business."
    new "بعد از آن صحبت‌ها با کسی که شناخته‌ام تماس گرفتم که روابط خوبی در حوزه مدلینگ داره."

    # say L2507 pla
    old "And she told me that she could get you an interview!"
    new "و او به من گفت که می‌تونه تو رو به مصاحبه ببره!"

    # say L2510 pla
    old "Yeah, but you see..."
    new "بله، ولی می‌دونی..."

    # say L2512 pla
    old "She told me that I had to take some pictures of you, to show to the agency."
    new "او به من گفت که باید چند عکس از تو ببرم تا به آژانس نشون بدم."

    # say L2513 pla
    old "Like a portfolio or something."
    new "مثل یک پرتفوی یا چیزی مشابه."

    # say L2515 pla
    old "You know, to see how you look."
    new "می‌دونی، برای اینکه ببینن چطوری."

    # say L2519 pla
    old "Actually, I can take them myself."
    new "در واقع، می‌تونم خودم بگیرم."

    # say L2523 pla
    old "Yeah sure, it wouldn't be a problem."
    new "بله حتماً، مشکلی نداره."

    # say L2524 pla
    old "I have some experience as a photographer."
    new "من تجربه‌ای به عنوان عکاس دارم."

    # say L2527 pla
    old "Heh, well thank you."
    new "خوب، ممنون."

    # say L2528 pla
    old "But you see, we have to take the pictures soon."
    new "اما می‌دونی، باید عکس‌ها رو زودتر بگیریم."

    # say L2529 pla
    old "She wants to send them as soon as possible."
    new "او می‌خواهد هر زودتر ارسال کنند."

    # say L2530 pla
    old "So, how about we go to my house after you finish work and take the photos?"
    new "پس، چطور اگه بعد از کار به خونه‌ام بیایی و عکس‌ها رو ببریم؟"

    # say L2534 pla
    old "Come on, you don't have to worry about it."
    new "بیا، نباید نگران باشی."

    # say L2535 pla
    old "What you're wearing is perfect, you don't need to worry about it."
    new "چیزی که پوشیده‌ای عالیه، نباید نگران باشی."

    # say L2539 pla
    old "Of course, you look perfect the way you are."
    new "البته، تو همینطور کاملی هستی."

    # say L2544 pla
    old "Great, so I'll wait until your shift is over, and after we can go to my house."
    new "عالی، پس منتظر می‌مونم تا شفتت تمام بشه، بعد می‌ره‌یم به خونه‌ام."

    # say L2554 pla
    old "Okay, lets go."
    new "باشه، برویم."

    # say L2567 pla
    old "Alright, we can get started then-"
    new "باشه، می‌تونیم شروع کنیم-"

    # say L2570 pla
    old "Don't worry about it."
    new "با این نگران نباش."

    # say L2571 pla
    old "I can show you."
    new "من می‌تونم به تو نشون بدم."

    # say L2573 pla
    old "Well, I've helped my [sisRel] before with her work."
    new "خب، قبلاً به [sisRel] کمک کردم تا کارش رو انجام بده."

    # say L2574 pla
    old "She has an online clothing business."
    new "او یک بیزینس لباس آنلاین داره."

    # say L2575 pla
    old "And sometimes I'm the one that takes the pictures of her new clothes."
    new "و بعضی مواقع من هستم که عکس لباس‌های جدیدش رو می‌برم."

    # say L2578 pla
    old "Heh, thank you."
    new "هه، ممنون."

    # say L2579 pla
    old "Anyway, I guess we can get started then."
    new "بازهم، فکر کنم می‌تونیم شروع کنیم."

    # say L2581 pla
    old "Just relax, I'll tell you how you should pose."
    new "هیچ نگرانی، من بهت می‌گم چطور باید ایستادی."

    # say L2582 pla
    old "So, for the first picture..."
    new "پس برای اولین عکس..."

    # say L2583 pla
    old "How about you sit down in the bed with your legs open, looking this way."
    new "بیا تو روی تخت بنشین با پاشون باز، این طرف نگاه کن."

    # say L2584 pla
    old "Put your left arm up behind your head, and bring the right one to your neck."
    new "دست چپت رو بالای سرتو بگذار و دست راستت رو به گردنات ببر."

    # say L2585 pla
    old "Over your right breast."
    new "روی سینه‌ی راستت بگذار."

    # say L2586 pla
    old "And look straight at the camera, Ok?"
    new "و به دوربین نگاه کن، خوب؟"

    # say L2598 pla
    old "Alright perfect! "
    new "البته، عالی!"

    # say L2599 pla
    old "That way you're more than perfect!"
    new "اینطوری تو بیش از کاملی!"

    # say L2600 pla
    old "Just stay put and I'll take the first picture."
    new "بیا اینجا بنشین و من اولین عکس رو بگیرم."

    # say L2621 pla
    old "That was perfect Barbie!"
    new "این هم خوب بود باربی!"

    # say L2622 pla
    old "Now, for the second pose."
    new "الان، برای پوز دوم."

    # say L2624 pla
    old "Hmm, let's see..."
    new "ببینم..."

    # say L2625 pla
    old "I think we should show you from all angles."
    new "فکر می‌کنم باید از همه جهاتت نشون داده بشه."

    # say L2626 pla
    old "So, how about you take more of a kneeling position in the bed."
    new "پس، چطور اگه تو روی تخت به صورت زنده‌باز بنشینی."

    # say L2627 pla
    old "With your legs towards me."
    new "با پای تو به سمت من."

    # say L2628 pla
    old "And put your weight on your left arm."
    new "و وزن خودت رو روی بازوی چپ بگذار."

    # say L2642 pla
    old "Yes! That's perfect!"
    new "بله! همینه!"

    # say L2643 pla
    old "Great Barbie!"
    new "عالی باربی!"

    # say L2645 pla
    old "Just stay like that, and I'll take the picture."
    new "همینطور بمان، من عکس می‌گیرم."

    # say L2666 pla
    old "Alright, that's great!"
    new "باشه، خوبه!"

    # say L2667 pla
    old "Now, I think we can take another picture."
    new "الان، فکر می‌کنم می‌تونیم عکس دیگه‌ای ببریم."

    # say L2669 pla
    old "Sure, for the third one let's make it a close-up."
    new "بله، برای عکس سوم بیای تو نزدیک‌تر بگیری."

    # say L2670 pla
    old "So, turn to face the camera."
    new "پس، به دوربین بگرد."

    # say L2671 pla
    old "And bring your breasts forward with your hands while you smile."
    new "و با دست‌هایت سینات رو به جلو بیا، همینطور با لبخند."

    # say L2672 pla
    old "Ok, I know what you mean."
    new "باشه، من می‌فهمم."

    # say L2685 pla
    old "That's right! Perfect!"
    new "درسته! عالی!"

    # say L2686 pla
    old "You're very good at this Barbie!"
    new "تو خیلی خوبی در این باربی!"

    # say L2688 pla
    old "No matter how good I am, it wouldn't be possible without such a beautiful model."
    new "با همه این توانایی‌هام، بدون چنین مدل زیبایی امکان‌پذیر نبود."

    # say L2709 pla
    old "Alright, that's it, I think that we have enough pictures with those ones."
    new "باشه، فکر کنم عکس‌های کافی از این‌ها گرفتیم."

    # say L2711 pla
    old "Yeah, I think those are more than enough."
    new "بله، فکر کنم اینا کاملاً کافی هستند."

    # say L2716 pla
    old "Ok, I think these came out great!"
    new "باشه، فکر کنم اینا عالی شدند!"

    # say L2720 pla
    old "Here, look."
    new "ببین، اینجا هستند."

    # say L2729 pla
    old "I'm sure they will."
    new "مطمئنم خوب می‌شون."

    # say L2730 pla
    old "Besides, I still have to do a couple of edits on them."
    new "البته، هنوز چند تغییر در اونا باید بکنم."

    # say L2731 pla
    old "When I'm done they're going to look even better."
    new "وقتی تمام شدم، حتماً بهتر به نظر می‌رسن."

    # say L2735 pla
    old "What? There's no way this is just because of me taking the pictures!"
    new "چه؟ نمی‌تونم باور کنم فقط به خاطر اینکه من عکس می‌برم باشه!"

    # say L2736 pla
    old "These pictures are because of how beautiful you are."
    new "این عکس‌ها به خاطر زیبایی تو هستند."

    # say L2737 pla
    old "After all the only thing I'm doing is just taking the pictures."
    new "در نهایت من فقط عکس می‌برم."

    # say L2738 pla
    old "You're the one that's posing."
    new "تو هستی که پوز می‌کنی."

    # say L2739 pla
    old "And if they come up any good, is just because of how well you posed."
    new "و اگر عکس‌ها خوب بیاد، فقط به خاطر همینه که تو خوب پوز کردی."

    # say L2755 pla
    old "Woah, woah, w- what are you doing Barbie?"
    new "وای، وای، ب-�چه، تو چه کاری انجام می‌دی باربی؟"

    # say L2758 pla
    old "B- but..."
    new "B- ب- ولی..."

    # say L2771 pla
    old "Alright, so I'll send the pictures to my contact today. And she'll let me know if she can get the interview for you."
    new "باشه، پس من امروز عکس‌ها رو به ارتباط خودم می‌فرستم. و او به من می‌گه اگه می‌تونه مصاحبه‌ای برایت ترتیب بده."

    # say L2773 pla
    old "It will probably not be something big, at least not to start with."
    new "احتمالاً چیز بزرگی نخواهد بود، حداقل در ابتدا."

    # say L2774 pla
    old "But I think that it might be a good starting point for you."
    new "ولی فکر می‌کنم می‌تونه نقطه شروع خوبی برایت باشه."

    # say L2786 pla
    old "Yeah, I have to get to it now."
    new "بله، باید الان شروع کنم."

    # say L2787 pla
    old "But as soon as the pictures are done I'll hand them over to my contact."
    new "اما همین زمانی که عکس‌ها رو تکمیل کنم به ارتباط من می‌دهم."

    # say L2788 pla
    old "And when I get an answer I'll let you know."
    new "و وقتی جواب گرفتم ازت خبر می‌دم."

    # say L2852 pla
    old "Hey [sis], good morning, how are you?"
    new "سلام ز[sis]، صبح بخیر، چطوری؟"

    # say L2854 sis
    old "I'm doing great, and you?"
    new "من خوب هستم، تو چطوری؟"

    # say L2855 pla
    old "I'm ok, thank you."
    new "من خوبم، ممنون."

    # say L2857 pla
    old "Hey, listen, about the favor that I asked you last time."
    new "بله، بگو، درباره آن لطفی که از تو خواستم آخر بار."

    # say L2858 sis
    old "Oh yeah, your little plastic girl's pictures."
    new "اوه بله، عکس‌های آن دختر پلاستیکی."

    # say L2859 sis
    old "I send them over to a friend of mine that works for another clothing business."
    new "من اونا رو به دوستی که توی یه شرکت لباس کار می‌کنه فرستادم."

    # say L2860 sis
    old "Their clothes are more like the type of thing that that idiot would wear."
    new "لباس‌هایشون مثل چیزی هستن که آن احمق می‌پوشه."

    # say L2861 pla
    old "And what did they say?"
    new "و اونا چه جوری پاسخ دادن؟"

    # say L2868 pla
    old "When do they want to meet her?"
    new "وقتی می‌خوان ازش دیدن؟"

    # say L2869 sis
    old "In a couple of days."
    new "چند روز دیگه."

    # say L2870 sis
    old "I'll send you the info."
    new "من اطلاعات رو به تو می‌فرستم."

    # say L2871 sis
    old "And don't worry, I talked with them."
    new "و نگران نباش، باهاشون حرف زدم."

    # say L2872 sis
    old "They said that if they hire her they'll be sure to give us our cut."
    new "گفتند اگر اونا رو استخدام کنند حتماً بخشی از سود رو به ما میدن."

    # say L2873 pla
    old "I see... That's great."
    new "ممنون... خوبه."

    # say L2874 pla
    old "Alright, I'll have to tell her about this."
    new "باشه، باید اینجوری بهش بگم."

    # say L2875 pla
    old "Thanks a lot [sis]."
    new "ممنون زیادی [sis]."

    # say L2878 sis
    old "Remember to tell your little friend that she has to be there on time."
    new "به دوست عزیزم یادت باشه که باید به موقع حاضر باشه."

    # say L2880 sis
    old "I don't want her to make me look bad by getting there late or anything."
    new "نمی‌خوام او با تأخیر رسیدنش باعث بد نشون دادن من بشه."

    # say L2881 sis
    old "Is that clear?"
    new "معلوم شد؟"

    # say L2882 pla
    old "Yeah, yeah, it is."
    new "بله، بله، مشخصه."

    # say L2883 sis
    old "Good."
    new "خوب."

    # say L2884 pla
    old "Yeah.. I'll see you later then."
    new "بله.. بعداً می‌بینیم."

    # say L2885 pla
    old "Bye [sis], thanks for the help."
    new "بای [sis]، ممنون از کمکت."

    # say L2909 pla
    old "I'm good, and listen I have some great news!"
    new "من خوبم، و داشتم خبر خوبی هست!"

    # say L2911 pla
    old "That contact I told you about got an interview for you!"
    new "آره، آن معرفی که به تو گفتم برای تو مصاحبه‌ای گرفت!"

    # say L2914 pla
    old "Yeah, it's to apply for a position as a model for a clothing brand that works mainly online."
    new "بله، برای اپلای به سمت مدل برای یک برنده لباسی که عمدتاً آنلاین فعالیت می‌کنه."

    # say L2915 pla
    old "It's not the biggest job in the world but..."
    new "این کار بزرگی نیست ولی..."

    # say L2919 pla
    old "It's my pleasure."
    new "خوشحالم که بتونم به تو کمک کنم."

    # say L2920 pla
    old "I'm happy to be able to help you."
    new "خوشحالم که بتونم به تو کمک کنم."

    # say L2921 pla
    old "I'll send you the details, don't forget to go, alright?'"
    new "من جزئیات رو برات می‌فرستم، فراموش نکن برو، خوب؟"

    # say L2923 pla
    old "Hey, don't thank me yet. Let's wait until you get the job."
    new "هی، هنوز ممنون نشین. بیاین ببینیم تا وقتی کار رو پیدا کردی."

    # say L2925 pla
    old "I'll come by later to see how everything went, alright?"
    new "بعداً می‌آیم تا ببینم همه چیز چطور بود، خوبه؟"

    # say L2945 bri
    old "You're taking too long, how many more times are you going to see this woman?"
    new "تو وقت زیادی می‌بری، هنوز چند بار دیگه این خانم رو می‌بینی؟"

    # say L2946 pla
    old "I already told you. Until I'm done helping her with everything I promised I would do."
    new "قبلاً به تو گفتم. تا زمانی که به همه چیزهایی که قول دادم به اون جون بریم، کمک کنم."

    # say L2947 pla
    old "What are you doing here anyway?"
    new "بیلی، تو اینجا چه کاری داری؟"

    # say L2948 bri
    old "I thought I told you, you take too long."
    new "فکر کردم به تو گفتم، خیلی طول می‌کشی."

    # say L2949 bri
    old "So, I came to help you deal with this quickly."
    new "پس من برای کمکت اومدم که این کار رو زودتر انجام بدی."

    # say L2950 pla
    old "Ok, thank you I guess."
    new "خوب، ممنونم حدس می‌زنم."

    # say L2951 pla
    old "But I think everything's going to go well, you know?"
    new "اما فکر می‌کنم همه چیز خوب پیش می‌رود، می‌دونی؟"

    # say L2952 pla
    old "Since I got her the interview, I'm sure that went well, and now she has good news."
    new "از بابت مصاحبه‌ای که برایش گرفتم، مطمئنم خوب رفته و حالا خبر خوبی داره."

    # say L2953 pla
    old "But let's go and talk to her."
    new "بیای دیگه و باهاش صحبت کنیم."

    # say L2963 pla
    old "Hey Barbie, good morning."
    new "هی Barbی، صبح بخیر."

    # say L2967 pla
    old "W- what's wrong Barbie?"
    new "باربی، چ-چیزی اتفاق افتاد؟"

    # say L2970 pla
    old "It didn't go well?"
    new "خوب نرفت؟"

    # say L2972 pla
    old "What happened?"
    new "چه اتفاقی افتاد؟"

    # say L2975 pla
    old "S- sure, no problem."
    new "بله، هیچ اشکالی نداره."

    # say L2976 pla
    old "I'll see you later then."
    new "بعداً می‌بینیم."

    # say L3000 pla
    old "Ok, so now will you tell me about what happened?"
    new "باشه، الان می‌تونی به من بگی اتفاق چی فرسود؟"

    # say L3001 pla
    old "How did the interview go?"
    new "مصاحبه چطور بود؟"

    # say L3007 pla
    old "Ok, that's good to hear."
    new "البته، خوشحالم که اینطور شده."

    # say L3008 pla
    old "But then what went wrong?"
    new "بعد از آن چه اشتباه افتاد؟"

    # say L3014 pla
    old "So, did he say anything to you about that?"
    new "پس، هیچی به تو نگفت؟"

    # say L3030 pla
    old "What the hell? Who does he think he is?!"
    new "چه خرابه؟ فکر می‌کنه چیه؟!"

    # say L3031 pla
    old "I'm sorry Barbie, I had no idea things would turn out that way."
    new "ببخشید باربی، هیچ فکری نداشتم که اینجوری می‌شه."

    # say L3032 pla
    old "I didn't expect that."
    new "من اینو منتظر نبودم."

    # say L3033 pla
    old "But I'll get you another interview in a better place."
    new "ولی به تو مصاحبه‌ای در جایی بهتر می‌دهم."

    # say L3034 pla
    old "And I'll make sure that this doesn't happen again."
    new "و اینطور نباشه دیگه."

    # say L3039 pla
    old "W- wait!"
    new "بی‌خیال!"

    # say L3040 pla
    old "I get it, you've had a bad streak with the auditions and interviews."
    new "فهمیدم، تو یه سری تجربه بد توی اودیشن‌ها و مصاحبه‌ها داشتی."

    # say L3041 pla
    old "But that doesn't mean that you should give up."
    new "اما این به معنای این نیست که باید از دست بیاندازی."

    # say L3042 pla
    old "Don't let a couple of bad experiences rob you of your dream."
    new "چند تجربه بد نباید رویات رو از تو بگیره."

    # say L3046 pla
    old "D- do you want to talk about it?"
    new "د- دوستت هست درباره‌ش حرف بزنی؟"

    # say L3050 pla
    old "Listen Barbie, what you have been going through with these... Bad experiences."
    new "باربی، اون تجربیات بدی که داشتی..."

    # say L3051 pla
    old "I can't imagine how frustrating it must be."
    new "من نمی‌تونم چقدر این موضوع خسته‌کننده براته رو تصور کنم."

    # say L3052 pla
    old "Especially if there are things from your past that are related to this. I think that causes you a lot of pain."
    new "به خصوص اگه چیزهایی از گذشته‌ت به این مربوط باشه. فکر کنم این باعث درد زیادی برایت می‌شه."

    # say L3056 pla
    old "I understand, and that's fair."
    new "من متوجهم، و این عادلانه است."

    # say L3057 pla
    old "But I also think you still shouldn't give up on your dream of becoming a star Barbie."
    new "اما من هم فکر می‌کنم نباید از رویا‌ت برای شدن ستاره باربی کنار بیاندازی."

    # say L3058 pla
    old "I've seen your passion for it. And I know how much of a hard worker you are."
    new "من شغفت تو رو برای این دیده‌ام. و می‌دونم چقدر کار سخت می‌کنی."

    # say L3059 pla
    old "If someone deserves a shot at something like that, it's you."
    new "اگه کسی حق داره فرصتی مثل این رو بگیره، تو هستی."

    # say L3064 pla
    old "Hmm, I see..."
    new "هم، می‌بینم..."

    # say L3065 pla
    old "Listen, you already told me that something's troubling you."
    new "بله، قبلاً به من گفتی که چیزی تو رو ناراحت می‌کنه."

    # say L3066 pla
    old "But you told me you don't want to talk about it."
    new "اما تو به من گفتی نمی‌خوای در موردش صحبت کنی."

    # say L3067 pla
    old "Which I understand."
    new "این رو می‌فهمم."

    # say L3068 pla
    old "But I think you should talk about it."
    new "اما فکر می‌کنم باید در موردش صحبت کنی."

    # say L3069 pla
    old "Maybe opening up about it would do you well."
    new "شاید باز کردن این موضوع برایت خوب باشه."

    # say L3071 pla
    old "I get it, it must be a painful memory, but you know, there's nothing to be afraid of."
    new "فهمیدم، باید یادآوری دردناکی باشه، اما می‌دونی، هیچ چیزی نیست که باید ازش مترسی."

    # say L3072 pla
    old "You can trust me with anything you want to share."
    new "می‌تونی به من هر چی می‌خوای بگی."

    # say L3073 pla
    old "No matter what it is, I want to support you and make sure that you feel safe and happy."
    new "باز هم چه باشد، می‌خوام تو رو حمایت کنم و اینو مطمئن شم که احساس امنیت و خوشحالی داشته باشی."

    # say L3074 pla
    old "I mean it Barbie, whatever it is."
    new "من جدی هستم باربی، هر چی باشه."

    # say L3076 pla
    old "That makes sense, but I'll be more than happy to listen to what you have to say."
    new "این معقوله، ولی خوشحالم که به تو گوش می‌دم."

    # say L3077 pla
    old "To listen to you."
    new "به تو گوش می‌دم."

    # say L3078 pla
    old "Maybe talking about it you can get rid of some of that pain, you know?"
    new "شاید با صحبت کردن می‌تونی برخی از آن درد رو ببری، میدونی؟"

    # say L3099 pla
    old "And... W- what happened?"
    new "و... چ- چه اتفاق افتاد؟"

    # say L3124 pla
    old "Listen Barbie, I know that what happened in your past was very painful."
    new "بله باربی، میدونم آنچه تو در گذشته تجربه کردی خیلی دردناک بود."

    # say L3126 pla
    old "And that we can't go back and changed it."
    new "و اینکه نمی‌تونیم برگرده و آن رو تغییر بدیم."

    # say L3128 pla
    old "But I don't think you're wrong for chasing your dreams."
    new "اما فکر نمی‌کنم اشتباهی باشه که به اهدافت دنبال کنی."

    # say L3130 pla
    old "Or that you have made any mistakes by choosing to chase your dreams."
    new "یا اینکه اشتباهی در انتخاب دنبال کردن رویایت خودت کرده‌ای."

    # say L3132 pla
    old "Yes it's true that you've been unlucky with how things have gone in the past."
    new "بله درسته که تو تا حالا شانس خوبی نداشتی."

    # say L3133 pla
    old "But I believe you still have a lot of chances for things to go your way."
    new "اما من باور دارم هنوز شانس‌های زیادی برای اینکه اوضاع به سمت تو برود وجود داره."

    # say L3135 pla
    old "You're a beautiful and hard-working woman."
    new "تو زنی زیبا و کارآمدی هستی."

    # say L3136 pla
    old "I'm sure if you keep trying, sooner or later you'll someday meet someone that will be different from the rest."
    new "مطمئنم اگه همچینواد ادامه بدی، زود یا دیر روزی کسی رو می‌بینی که از بقیه متفاوت باشه."

    # say L3139 pla
    old "Of course you will!"
    new "البته که همینطور خواهد بود!"

    # say L3141 pla
    old "You're diligent and capable."
    new "تو پرکوش و توانا هستی."

    # say L3142 pla
    old "And I'm completely sure that you will find very good fortune."
    new "و من کاملاً مطمئن هستم که شانس خوبی پیدا خواهی کرد."

    # say L3144 pla
    old "As I told you, if someone deserves good things coming their way, that is you."
    new "همونطور که بهت گفتم، اگه کسی قدرتش هست که خوبی‌ها رو جذب کنه، اون تو هستی."

    # say L3145 pla
    old "So, if you'll believe me, I would like to help you keep working towards achieving your dream."
    new "پس اگر به من باوری، می‌خوام کمکت کنم تا به سمت رویایت خودت پیش بری."

    # say L3160 pla
    old "I'm just happy that I get to be here for you Barbie."
    new "من فقط خوشحالم که برات اینجا هستم، باربی."

    # say L3161 pla
    old "About the other things, I'm just saying the truth every time we talk."
    new "درباره چیزهای دیگه، هر بار که با هم صحبت می‌کنیم من فقط حقیقت رو می‌گم."

    # say L3162 pla
    old "You're a capable and talented person."
    new "تو قدرتمند و مهارت‌داری."

    # say L3195 pla
    old "I- I'll do my best."
    new "من- من تلاش خواهم کرد."

    # say L3197 pla
    old "Really, the next one will be better."
    new "واقعاً، بعدی بهتر خواهد بود."

    # say L3199 pla
    old "I'm sure of it Barbie."
    new "مطمئنم باربی."

    # say L3203 pla
    old "I'm glad you feel that way."
    new "خوشحالم که اینطور فکر می‌کنی."

    # say L3204 pla
    old "Even though there have been a couple of inconveniences."
    new "البته، حتی با وجود چند مشکل کوچک."

    # say L3205 pla
    old "But I'm sure we'll get you a job that's good enough for you."
    new "اما مطمئنم شغل مناسبی برایت پیدا می‌کنیم."

    # say L3214 pla
    old "U- Uh, I- I mean."
    new "ا- اوه، منظورم اینه."

    # say L3223 pla
    old "Uh, s- sure, see you later."
    new "آره، حتماً، ببینم بعد."

    # say L3244 sis
    old "Hey [pla], good morning."
    new "هی ز[pla]، صبح بخیر."

    # say L3245 pla
    old "Hey [sis], good morning."
    new "هی [sis]، صبح بخیر."

    # say L3246 sis
    old "How are you today?"
    new "امروز حالت چطوره؟"

    # say L3248 pla
    old "I'm doing fine, but there's something we have to talk about."
    new "من خوب هستم، اما چیزی هست که باید در موردش صحبت کنیم."

    # say L3249 sis
    old "What is it?"
    new "چه کاری هست؟"

    # say L3250 pla
    old "Well, I don't know the full details."
    new "خب، جزئیات کامل رو نمی‌دونم."

    # say L3252 pla
    old "But as Barbie told me, the guy who interviewed her for the modeling job tried to sleep with her."
    new "اما همین‌جوری که باربی به من گفت، آدمی که برای شغل مدلینگ باهاش مصاحبه کرد، سعی کرد با او خواب بخورد."

    # say L3255 pla
    old "Yeah, he did. Apparently, he told her that there were a lot of good candidates for that job."
    new "بله، اونجور کرد. به نظر می‌رسه به او گفت که برای اون شغل کاندیداهای خوب زیادی هستند."

    # say L3257 pla
    old "So if she wanted the job, she would have to give him a {i}'payment'{/i} for it."
    new "پس اگه می‌خواست شغل رو بگیره، باید بهش یه {i}پرداخت{/i} بده."

    # say L3259 sis
    old "That pig!"
    new "این خوک!"

    # say L3261 sis
    old "I mean what the fuck! What's wrong with him?!"
    new "من قصه‌ای نمی‌فهمم! اونا چه مشکلی داره؟!"

    # say L3262 sis
    old "What a disgusting thing."
    new "چه چیزی خیلی خراب."

    # say L3264 sis
    old "Can you believe that bastard was trying to get me to model some clothes for his brand?"
    new "می‌تونی باور کنی اون خرایش می‌خواست از من برای برندش لباس مدل کنم؟"

    # say L3265 sis
    old "But I hadn't had the time to do it."
    new "ولی وقت نداشتم انجام بدم."

    # say L3267 sis
    old "That means that if I had been available he would probably have tried the same thing with me!"
    new "این بدان معناست که اگر من در دسترس بودم، احتمالاً همین کار رو با من امتحان می‌کرد!"

    # say L3269 sis
    old "And he had the gall to try and pull that with her?!"
    new "و اونا هم جرات کرد به اونجوری با او بیاد؟!"

    # say L3271 sis
    old "Sure, he probably realized that she needed that opportunity and decided to take advantage."
    new "بله، احتمالاً متوجه شد که او به این فرصت نیاز داره و تصمیم گرفت استفاده کنه."

    # say L3273 sis
    old "What a fucking coward!"
    new "چه کسی خرده چنین کاری رو می‌کنه!"

    # say L3274 pla
    old "Uhm... Yeah."
    new "اوه... بله."

    # say L3276 sis
    old "But don't worry [pla], I'm not going to let things stay like this."
    new "اما نگران نباش [pla]، من نمی‌خوام اینجوری بمونه."

    # say L3278 sis
    old "I'm actually in contact with a couple of brands that are working with that guy."
    new "در واقع با چند برند در ارتباط هستم که با آن مرد همکاری می‌کنند."

    # say L3280 sis
    old "But they won't be after I tell them what happened."
    new "اما بعد از اینکه بهشون می‌گم اتفاق چی فوت کرده، دیگه هیچکس نخواهند."

    # say L3281 sis
    old "I'll make everyone knows what that bastard tried to do."
    new "من همه رو مطلع می‌کنم از آنچه آن خرایی سعی کرد."

    # say L3282 sis
    old "That way that pig will learn how to treat women!"
    new "این جوری آن خوک می‌فهمه چطور با زنان رفتار کنی!"

    # say L3283 pla
    old "Uh- I- I see."
    new "اوه- من- من متوجه شدم."

    # say L3285 sis
    old "Tell Barbie sorry on my behalf."
    new "به باربی از جای من بپرداخت."

    # say L3286 sis
    old "I may not like her too much, but I would have never knowingly sent her to a place like that."
    new "من ممکن است خیلی دوستش نداشته باشم، اما هرگز آگاهانه او را به جایی مثل اون نمی‌فرستادم."

    # say L3288 sis
    old "And of course, I'll make her up for it."
    new "و البته، من این رو به او جبران خواهم کرد."

    # say L3289 sis
    old "So don't worry, I'll get her another interview."
    new "پس نگران نباش، من برایش مصاحبه‌ای دیگه در می‌آورم."

    # say L3291 sis
    old "And I'll make sure that this time is with a reputable place."
    new "و برات اطمینان می‌دم این بار با یک جای معتبره."

    # say L3292 pla
    old "That sounds great [sis], thank you!"
    new "این خوبه [sis]، ممنون!"

    # say L3294 sis
    old "Now, I'll talk to you later."
    new "الان، بعداً با تو صحبت می‌کنم."

    # say L3295 sis
    old "I have a couple of calls to make."
    new "من چند تماس دارم."

    # say L3296 pla
    old "Uh- S- sure, see you later."
    new "خب، بله، بعداً می‌بینیم."

    # say L3319 sis
    old "Good news, I brought something for you."
    new "خبر خوبی، چیزی برای تو آورده‌ام."

    # say L3320 pla
    old "Oh really? How come?"
    new "وای، واقعاً؟ چطور؟"

    # say L3322 sis
    old "Well, I got another interview for Barbie."
    new "خب، برای باربی مصاحبه‌ای دیگه گرفتم."

    # say L3324 pla
    old "That's great [sis]! Thank you."
    new "عالیه [sis]! ممنون."

    # say L3325 sis
    old "Don't worry about it. I'm happy to help her."
    new "نگران نباش. خوشحالم که به اون کمک کنم."

    # say L3326 sis
    old "And this time I made sure that the place where I'm sending her is quite reputable."
    new "و این بار مطمئن شدم که جایی که اون رو می‌فرستم خیلی معتبره."

    # say L3327 sis
    old "So you can be sure that nothing like what happened last time will happen again."
    new "پس می‌تونی اطمینان داشت که هیچی مثل آخرین بار پیش نمی‌یاد."

    # say L3328 pla
    old "That's awesome [sis]!"
    new "عالیه [sis]!"

    # say L3329 pla
    old "So, what you have in the box is related to that?"
    new "پس چیزی که تو توی جعبه داری با اون مربوطه؟"

    # say L3331 sis
    old "It is."
    new "بله."

    # say L3332 sis
    old "The place where Barbie's going is a lingerie company."
    new "محلی که باربی می‌رود یک شرکت لینجریه است."

    # say L3333 sis
    old "So, when I send them the pictures you had given me of Barbie, they thought she looked very good."
    new "پس وقتی عکس‌هایی که تو به من دادی از باربی رو به اونا فرستادم، فکر کردند که او خیلی خوب به نظر می‌رسه."

    # say L3334 sis
    old "But they said they wanted to see her posing in some lingerie or underwear."
    new "اما اونا گفتند می‌خواهند ببینند او با لینجری یا لباس زیر پوز می‌کنه."

    # say L3335 sis
    old "And I imagine you don't have a portfolio of pictures of her in lingerie, right?"
    new "و فکر کنم نداری از او عکس‌هایی با لینجری، درسته؟"

    # say L3337 pla
    old "Uh- n- no, I don't"
    new "نه، من ندارم"

    # say L3339 sis
    old "Well, that's why I took the liberty of getting some new lingerie that would fit her. You know, for you to take some pictures."
    new "خب، همین جوری برایش لینجری جدیدی خریدم که رویش بیاد. می‌دونی، تا تو عکس‌هایی ازش ببری."

    # say L3340 pla
    old "Oh wow [sis], t- that's awesome!"
    new "اوه وای [sis]، خوبه!"

    # say L3341 sis
    old "Well, I think it was the least I could do. You know?"
    new "خب، فکر کنم این کمترین چیزی بود که می‌تونستم بکنم. میدونی؟"

    # say L3343 sis
    old "So, take this. And talk to her to take the pictures as soon as you can."
    new "پس، اینو بگیر. و هر زودتر باهاش حرف بزن تا عکس‌ها رو بگیری."

    # say L3349 pla
    old "Alright, I'll talk to her as soon as I can."
    new "باشه، هر زودتر باهاش حرف می‌زنم."

    # say L3351 sis
    old "Alright. I'll be waiting for the pictures then."
    new "البته. منتظر عکس‌ها خواهم بود."

    # say L3352 sis
    old "By the way, you haven't forgotten about my 10 percent right?"
    new "باید نه، فراموش نکرده‌ام در مورد همون ده درصدت."

    # say L3353 pla
    old "No, no, I got you."
    new "نه، نه، من یادت رفته نیست."

    # say L3354 sis
    old "Alright, I'll see you later then."
    new "البته، تا بعداً."

    # say L3357 pla
    old "Sure, Bye."
    new "بله، خداحافظ."

    # say L3381 pla
    old "I'm fine."
    new "من خوبم."

    # say L3382 pla
    old "Actually I'm more than fine, I just got some good news."
    new "در واقع خیلی خوب هستم، خبر خوبی شنیدم."

    # say L3384 pla
    old "That contact I told you about got you an interview!"
    new "اون تماسی که بهت گفتم، برایت مصاحبه‌ای گرفت!"

    # say L3385 pla
    old "And don't worry, this time she ensured me that what happened last time wouldn't happen again."
    new "و نگران نباش، این بار او به من تضمین کرد که آنچه پیش اومد، دیگه تکرار نمی‌شه."

    # say L3390 pla
    old "Well, that's the thing, before they interview you. They said they would like to see a couple of pictures of you."
    new "خب، این همینه، قبل از مصاحبه گفتند می‌خوان چند عکس از تو ببینن."

    # say L3393 pla
    old "Yeah, and they really liked them."
    new "بله، و اونا خیلی خوششون اومده بود."

    # say L3394 pla
    old "But you see, this new place is a lingerie retailer."
    new "اما می‌بینی، این جای جدید فروشگاه لینجریه."

    # say L3396 pla
    old "So they said they'd be interested in seeing how you look in lingerie before you go."
    new "پس گفتند خواستن ببینن تو لینجری چطور می‌تونی بپوشی قبل از اون که بروی."

    # say L3397 pla
    old "So, my contact got some lingerie for you to try."
    new "پس، ارتباط من برایت لینجری‌ای آورد تا امتحان کنی."

    # say L3399 pla
    old "I was thinking that maybe after you're done with your shift you'd like to come with me to my house and you can try it on."
    new "من فکر می‌کنم شاید بعد از تموم شدن نوبت کاری تو بخوای با من بیایی به خونه من و اونجا آنها رو پوشونی."

    # say L3404 pla
    old "Great, then I'll wait until your shift is over and then we can come back to my house."
    new "عالی، پس منتظر می‌مونم تا شیفتت تمام بشه و بعد می‌تونیم برای خونه‌ام بیان."

    # say L3415 pla
    old "Alright, let's go then."
    new "باشه، برویم."

    # say L3428 pla
    old "Alright, this is the lingerie, why don't you change into it? And we'll do the pictures."
    new "بیا، این لینجریه، چرا نمی‌تونی توش پوشونی؟ بعد عکس‌هامون رو بگیریم."

    # say L3440 pla
    old "S- sorry, is not that I don't like it, I was just surprised because of how beautiful you look."
    new "ببخشید، نه اینجوری که نمی‌تونم بپوشم، فقط شوک شدم از زیباییت."

    # say L3441 pla
    old "That lingerie looks very good on you."
    new "این لینجری روی تو خیلی خوب جا می‌یاد."

    # say L3445 pla
    old "What? Of course not!"
    new "نه، البته نه!"

    # say L3446 pla
    old "You look just perfect!"
    new "تو فقط کاملی هستی!"

    # say L3447 pla
    old "You look very beautiful, I mean it."
    new "تو خیلی زیبایی، حرف‌هام رو بگیر."

    # say L3450 pla
    old "Why? You don't think the same?"
    new "چرا؟ تو همینطور فکر نمی‌کنی؟"

    # say L3454 pla
    old "You know, if you don't feel alright about this we don't have to do it."
    new "دیویس، اگه احساس خوبی نمی‌کنی از این، ما می‌تونیم انجام ندهیم."

    # say L3461 pla
    old "Come on, no one's going to think that."
    new "بیا، هیچ‌کس نمی‌فکری اینجوری."

    # say L3462 pla
    old "You are one of the most beautiful girls I know  Barbie."
    new "تو یکی از زیباترین دخترانی هستی که معرفی کردم، باربی."

    # say L3463 pla
    old "I'm sure that as soon as they see you they'll want to hire you."
    new "مطمئن هستم که همین جا که تو رو ببینن، می‌خوان ازت استخدام کنن."

    # say L3465 pla
    old "Of course I do."
    new "البته."

    # say L3480 pla
    old "Ok, the first picture is just going to be you standing there normally."
    new "باشه، عکس اول فقط باید ایستاده باشی."

    # say L3481 pla
    old "So don't move while I take the picture."
    new "پس جای خودت رو نتریدونه وقتی من عکس می‌برم."

    # say L3502 pla
    old "Alright, that was good."
    new "باشه، این هم خوب بود."

    # say L3503 pla
    old "So, for the second picture, how about you lay on your right side."
    new "برای عکس دوم، چطور اگه روی سمت راستت بخوابی."

    # say L3504 pla
    old "Open your body a little bit, and put your left leg up."
    new "بدنت رو یه کم باز کن و لگت چپتو بالا ببر."

    # say L3505 pla
    old "Then rest your left hand on your hip, and lift your torso up a little using your right arm."
    new "بعد دست چپت رو بر پرانتون بگذار و با دست راستت یه کم بدنت رو بلند کن."

    # say L3518 pla
    old "That's it, perfect!"
    new "این همین، عالی!"

    # say L3540 pla
    old "I do, you look wonderful"
    new "من انجام می‌دم، تو عالی به نظر می‌رسی"

    # say L3542 pla
    old "Alright, for the next one."
    new "باشه، برای بعدی."

    # say L3543 pla
    old "How about we show a little bit of how you look from behind?"
    new "بیای بیشتری از ظاهرت از پشت رو نشون بدی."

    # say L3545 pla
    old "Great, kneel with your back towards  me."
    new "عالی، با پشتت به سمت من نشست."

    # say L3546 pla
    old "While you rest your forearms on the bed."
    new "در حالی که بازوهایت روی تخت قرار بگیرند."

    # say L3547 pla
    old "And turn your head over your right shoulder while you look at me."
    new "و سرتو روی شانه‌ی راستت برگردان و به من نگاه کن."

    # say L3559 pla
    old "That's it! Perfect!"
    new "این هست! خوبه!"

    # say L3560 pla
    old "That's great Barbie!"
    new "عالی هستی باربی!"

    # say L3562 pla
    old "You look great Barbie!"
    new "تو خیلی زیبا دی Barbی!"

    # say L3563 pla
    old "{i}(Dang, she really does look amazing.){/i}"
    new "{i}(حتماً، او واقعاً خوب هم به نظر می‌رسد.){/i}"

    # say L3591 pla
    old "Alright, I think that's it."
    new "باشه، فکر کنم اینجاست."

    # say L3592 pla
    old "W- why don't you go change while I put the camera away?"
    new "ب- بیا تغییر کلیدت بکنی، من هم دوربین رو جا می‌ذارم."

    # say L3601 pla
    old "Uhh... w- well, y- you know."
    new "اوه... خب، می‌دونی."

    # say L3614 pla
    old "W- what are you doing?"
    new "و- و تو چه کاری داری؟"

    # say L3627 pla
    old "Uhh, I- I'm glad you liked it."
    new "اوه، خوشحالم که لذت برده‌ای."

    # say L3634 pla
    old "I'll let you know what they say about the pictures, alright?"
    new "من بهت می‌گم چی می‌گن در مورد عکس‌ها، خب؟"

    # say L3659 pla
    old "Why are you waking me up at this time?"
    new "چرا الان منو بیدار می‌کنی؟"

    # say L3661 bri
    old "Well, I have something to tell you."
    new "خب، چیزی برایت هست."

    # say L3664 bri
    old "Great news! The process of implantation of the magic power within Barbie is complete!"
    new "خبر خوب! فرایند نصب قدرت جادویی درون باربی تمام شده!"

    # say L3666 bri
    old "So we can now move into the next objective!"
    new "پس حالا می‌تونیم به هدف بعدی برسیم!"

    # say L3667 pla
    old "Implantation of the magic power? What do you mean?"
    new "نصب قدرت جادویی؟ من قصه‌ات رو نمی‌فهمم."

    # say L3668 bri
    old "Ugh, I see that you forgot about what we were trying to do here."
    new "اوه، می‌بینم فراموش کردی که اینجا چه کاری می‌خواستیم انجام بدیم."

    # say L3669 bri
    old "Did you forget that we're trying to get you to implant magic power into different women."
    new "فراموش کردی که می‌خوایم تو قدرت جادویی رو توی زنان مختلف قرار بدی."

    # say L3670 bri
    old "So that they can cultivate the magic power within their bodies?"
    new "تا آنها بتونن درون بدنشون قدرت جادویی رو پرورش بدند؟"

    # say L3671 pla
    old "Hmm... Yeah, right."
    new "Hmm... درسته، براحت."

    # say L3673 pla
    old "According to what you told me last time."
    new "بر اساس آنچه تو برام گفتی آخر بار."

    # say L3674 pla
    old "Does that mean that she's pregnant now?!"
    new "این بدان معناست که حالا بارداره؟!"

    # say L3676 bri
    old "Hmph, I guess that from your point of view that's how it looks."
    new "همف، حدس می‌زنم از نظر تو همینجوری به نظر می‌رسه."

    # say L3677 bri
    old "But not really."
    new "ولی واقعاً نه."

    # say L3679 bri
    old "She'll just look and feel as if she is, but she's not pregnant."
    new "او فقط به نظر می‌رسه و احساسش هم همینه، اما حامله نیست."

    # say L3680 bri
    old "So you don't have to worry, when we're done with the spell we'll just collect the power."
    new "پس نگران نباش، وقتی اسپل رو تمام کنیم فقط قدرت رو جمع می‌کنیم."

    # say L3682 bri
    old "And she'll just go back to normal."
    new "و او فقط به حالت عادی بر می‌گرده."

    # say L3684 pla
    old "When we're done with the spell?!"
    new "وقتی ما با تکلیف تمام شدیم؟!"

    # say L3686 pla
    old "So until we're not done with it she'll be pregnant?"
    new "پس تا زمانی که ما با آن کار نکردیم، او باردار خواهد ماند؟"

    # say L3687 pla
    old "That's not okay!"
    new "این قابل قبول نیست!"

    # say L3688 pla
    old "She just barely got a chance to work."
    new "او هاردی فرصتی برای کار کردن داشت."

    # say L3690 pla
    old "And if she's pregnant she won't even be able to work."
    new "و اگر باردار شد، حتی نمی‌تونه کار کنه."

    # say L3691 pla
    old "You'll have to reverse it."
    new "باید اون رو برگردانی."

    # say L3692 bri
    old "Reverse it?! Are you crazy?"
    new "باز کردن اون؟! دیوونه شدی؟"

    # say L3693 bri
    old "With all of the time and magic power that has gone into it?!"
    new "با همه وقت و توان سحری که توی اون گذاشته شده؟!"

    # say L3694 bri
    old "How can you even say such a thing?"
    new "چطور می‌تونی چیزی مثل این بگی؟"

    # say L3695 pla
    old "Because, as I told you! She can't be pregnant!"
    new "چون، همونطور که به تو گفتم! او نمی‌تونه باردار شه!"

    # say L3696 pla
    old "I understand that you want me to hurry up with the ritual."
    new "من می‌فهمم که می‌خوای از من سریع‌تر با مراسم پیش برم."

    # say L3697 pla
    old "And I promise you that if you do it I'll make sure to do what you need me to for the ritual to go well."
    new "و قول می‌دم اگه اینو بکنی، من حتماً هر چی لازم داری برای انجام مراسم رو انجام می‌دم."

    # say L3699 bri
    old "Ugh, you're so difficult to handle [pla]."
    new "اوه، تو خیلی سخت برای کار کردن هستی [pla]."

    # say L3701 bri
    old "Fine, I'll do it."
    new "باشه، انجام میدم."

    # say L3702 bri
    old "But I want you to start working on the next target right away!"
    new "ولی می‌خوام تو همین حالا روی هدف بعدی شروع کنی!"

    # say L3703 pla
    old "Sure... But just let me finish what I have to do with Barbie."
    new "بله... اما فقط برامون بده تا کارم رو با باربی تمام کنم."

    # say L3706 pla
    old "I just have to finish a couple of things with her, and I'll get into working in the person."
    new "باید چند کار با او تمام کنم، بعد به کار روی این شخص می‌پردازم."

    # say L3708 bri
    old "{b}*Sigh*{/b}."
    new "{b}*تنفر*{/b}."

    # say L3709 bri
    old "Alright, but remember what you promised me [pla]."
    new "باشه، ولی به قولت به یاد داشته باش [pla]."

    # say L3710 pla
    old "Sure, sure..."
    new "بله، بله..."

    # say L3733 pla
    old "I'm okay, but I imagine that not as well as you will."
    new "من خوبم، ولی فکر کنم تو بهتر از من خواهی بود."

    # say L3736 pla
    old "You bet!"
    new "بله، قطعاً!"

    # say L3737 pla
    old "I just got a text from the person who got you the interview for the modeling gig."
    new "من پیامی از آن شخص گرفتم که برایت مصاحبه شغلی مدل شدن را ترتیب داد."

    # say L3738 pla
    old "They said that they loved the pictures, and how you look with the lingerie on!"
    new "اونا گفتند عکس‌ها رو خیلی دوست داشتن و اینکه تو با لینجری چقدر خوب به نظر می‌رسی!"

    # say L3740 pla
    old "They said they wanted to meet with you to discuss hiring you as their model!"
    new "اونا گفتند می‌خوان با تو برای صحبت در مورد استخدامت به عنوان مدل ملاقات کنند!"

    # say L3747 pla
    old "Haha, I'm glad this makes you happy."
    new "حاحا، خوشحالم که این تو رو خوشحال کرده."

    # say L3751 pla
    old "Oh no, it isn't."
    new "نه، این جوری نیست."

    # say L3752 pla
    old "I've only made a couple of phone calls."
    new "من فقط چند تماس گوشی زدم."

    # say L3753 pla
    old "This is because of your effort."
    new "این به خاطر تلاشتوه."

    # say L3754 pla
    old "Although don't forget you still have to go to the interview."
    new "البته فراموش نکن هنوز باید به مصاحبه بری."

    # say L3755 pla
    old "But I'm sure everything's going to go well."
    new "اما مطمئنم همه چیز خوب می‌شه."

    # say L3771 pla
    old "W- w- what are you doing Barbie?"
    new "ب- ب- باربی، تو چ- چ- چه کاری انجام می‌دهی؟"

    # say L3772 pla
    old "Y- you can't do that here!"
    new "Y- تو نمی‌تونی اینجا این کار رو بکنی!"

    # say L3775 pla
    old "B- but, t- there are cameras!"
    new "B- ولی، ت- تو اینجا نمی‌تونی این کار رو بکنی!"

    # say L3776 pla
    old "O- or someone could walk through here!"
    new "ا- اما ممکنه کسی اینجا وارد بشه!"

    # say L3787 pla
    old "I can't believe you actually did that!"
    new "من نمی‌تونم باور کنم واقعاً اینو انجام دادی!"

    # say L3792 pla
    old "Well... Whatever."
    new "خب... هر چی باشه."

    # say L3793 pla
    old "Don't forget that you have to go to the interview, alright?"
    new "فراموش نکن که باید برای مصاحبه برو، خوب؟"

    # say L3796 pla
    old "It's alright, no problem."
    new "خوب، هیچ اشکالی نداره."

    # say L3798 pla
    old "I'll see you later so you can tell me how the interview went, alright?"
    new "بعداً می‌بینیم تا بگی چطور مصاحبهت افتاد، خوب؟"

    # say L3819 pla
    old "Hmm, who could it be?"
    new "Hmm، کی می‌تونه باشه؟"

    # say L3820 pla
    old "I better hurry up and open the door..."
    new "باید سریع برم در رو باز کنم..."

    # say L3826 pla
    old "Oh, hi Barbie, nice to see you here."
    new "اوه، سلام باربی، خوشحالم که اینجا دیدمت."

    # say L3829 pla
    old "You did?! That's awesome Barbie!"
    new "تو انجام دادی؟! خوبه باربی!"

    # say L3830 pla
    old "So I take it the interview went well, right?"
    new "پس فرض می‌کنم مصاحبه خوب بود، درسته؟"

    # say L3834 pla
    old "That's great, hey, let's come to my room."
    new "عالیه، بیا، بیای به اتوممنم."

    # say L3835 pla
    old "That way you can tell me everything."
    new "این جوری می‌تونی همه چیز رو به من بگی."

    # say L3851 pla
    old "That's so awesome Barbie, congrats!"
    new "این خیلی عالیه باربی، مبارک!"

    # say L3885 pla
    old "Well, I'm glad you're happy."
    new "خوشحالم که خوشحالی."

    # say L3888 pla
    old "You're still going to work?"
    new "هنوز می‌روی به کار؟"

    # say L3901 bri
    old "Alright! I hear all of that!"
    new "البته! همه اینا رو شنیدم!"

    # say L3902 bri
    old "She's happy, and you accomplished what you wanted."
    new "او خوشحال است و تو هم آنچه می‌خواستی را انجام دادی."

    # say L3903 bri
    old "That means we can get to my thing now, right?"
    new "این بدان معناست که الان می‌تونیم به کار من برسیم، درسته؟"

    # say L3917 mo1
    old "[pla], wake up!"
    new "[pla]، بیدار ش!"

    # say L3923 pla
    old "[mo1]? What's happening?"
    new "[mo1]؟ چه کاری اتفاق افتاده؟"

    # say L3924 mo1
    old "Well, you see, Barbie's in the livingroom, she's waiting there to talk to you."
    new "خب، ببین، باربی در اتاق نشیمنه، منتظرت هست تا با تو صحبت کنه."

    # say L3925 pla
    old "Ohh, sure, I'll be downstairs in a minute."
    new "اوه، حتماً، من یه لحظه بعد پایین می‌آیم."

    # say L3926 mo1
    old "Ok, by the way. she's pregnant..."
    new "البته، به هر حال. او بارداره..."

    # say L3927 mo1
    old "Do you know anything about that?"
    new "مادر: از اون هیچی نمی‌دونی؟"

    # say L3928 pla
    old "Me? No, nothing! I don't know what this is about..."
    new "من؟ نه، هیچی! نمی‌دونم این در مورد چیه..."

    # say L3929 pla
    old "But I'll go down and talk to her."
    new "ولی من برمی‌گردم و باهاش صحبت می‌کنم."

    # say L3930 mo1
    old "Okay honey."
    new "باشه عزیزم."

    # say L3936 pla
    old "B- Barbie! H- hi!"
    new "ب- باربی! ه- هی!"

    # say L3937 pla
    old "W- what's happening?"
    new "W- چه اتفاقی افتاده؟"

    # say L3945 pla
    old "I- I... W- what's this?"
    new "من... این چیه؟"

    # say L3946 pla
    old "Y- you're pregnant!"
    new "د- دی، بارداری!"

    # say L3954 pla
    old "H- hey, don't worry, we'll figure something out."
    new "ه- هی، نگران نباش، راه حل پیدا می‌کنیم."

    # say L3958 pla
    old "I know, I know."
    new "می‌دونم، می‌دونم."

    # say L3959 pla
    old "But I'm sure everything will be fine."
    new "اما مطمئن هستم همه چیز خوب خواهد بود."

    # say L3960 pla
    old "And I can promise you that I'll be here for you, no matter what. Alright?"
    new "و می‌تونم به تو ب قول بدم که همیشه برایت اینجا خواهم بود. درسته؟"

    # say L3962 pla
    old "Let's just wait for now, and give ourselves time to think about this."
    new "برای حالا بیاین صبر کنیم و وقت برای فکر کردن به این موضوع بدیم."

    # say L3969 pla
    old "Of course, I understand."
    new "البته، من متوجه هستم."

    # say L3971 pla
    old "But before we make any decision let's just make sure that you check with a doctor to see how you're doing."
    new "اما قبل از هر تصمیمی، بیایم ببینیم پزشک چطوری می‌گه."

    # say L3972 pla
    old "You know, you're physical state."
    new "می‌دونی، حالت فیزیکی."

    # say L3974 pla
    old "You know, just to make sure everything's fine with you."
    new "می‌دونی، فقط برای اینکه مطمئن شیم همه چیز با تو خوبه."

    # say L3978 pla
    old "I think it is."
    new "من فکر می‌کنم همه چیز خوبه."

    # say L3979 pla
    old "I know a lot is going through your head right now."
    new "می‌دونم الان خیلی چیز‌ها تو ذهنت پیش می‌ره."

    # say L3980 pla
    old "But precisely because of that, I think we shouldn't rush into anything."
    new "اما همین به خاطر هم، فکر می‌کنم نباید به هیچ چیز سرعت بدهیم."

    # say L3986 pla
    old "That's a great idea."
    new "این یک ایده خوبه."

    # say L3987 pla
    old "And keep me informed if you can, I'd like to know how you're doing."
    new "و اگر می‌تونی، من رو مطلع کن، می‌خوام بدونم حالت چطوره."

    # say L3990 pla
    old "Hey, I'm happy to help you."
    new "بله، خوشحالم که بتونم به تو کمک کنم."

    # say L4002 bri
    old "Hey [pla], why the long face?"
    new "هی ز[pla]، چرا چهرت طولانیه؟"

    # say L4003 pla
    old "You ask why?!"
    new "پرسی چرا؟!"

    # say L4004 pla
    old "Barbie just came here, she's pregnant!"
    new "باربی فقط اینجا رسید، حامله!"

    # say L4005 pla
    old "I thought you had stopped the spell!"
    new "من فکر می‌کردم تو این جادو رو متوقف کردی!"

    # say L4006 bri
    old "Well, I did stop it."
    new "خب، من هم اونو متوقف کردم."

    # say L4007 bri
    old "But the magic cultivation process had already started."
    new "اما فرآیند رشد جادویی قبلاً شروع شده بود."

    # say L4008 bri
    old "You should know by now that when it comes to magic, nothing is ever as simple as 'canceling' a spell."
    new "باید بدونی که وقتی در مورد جادو حرف می‌زنی، هیچ‌وقت همه‌چیز به سادگی قابل لغو نیست."

    # say L4009 bri
    old "It's not like flipping a switch."
    new "این مثل این نیست که یک دکمه رو بزنی."

    # say L4011 bri
    old "The magic power is already in cultivation inside of her."
    new "تو قدرت جادویی رو درونش تکثیر داده‌ای."

    # say L4012 bri
    old "Or in human words, she's already pregnant."
    new "یا با زبان انسان‌ها، او باردار است."

    # say L4014 bri
    old "Besides, the magic spell to direct the magic you implanted in her."
    new "البته، جادویی که برای هدایت قدرت جادویی که تو درونش گذاشتی است."

    # say L4015 bri
    old "And said magic developing within her are two different things."
    new "و آن جادوی در حال رشد درون او دو چیز متفاوت هستند."

    # say L4017 pla
    old "Then what's the point of even canceling the spell?"
    new "پس معنی‌ش اینه که حتی لغو جادویی هم فرقی نمی‌کنه؟"

    # say L4019 pla
    old "If she's still going to go through with it. We might as well have let her go through with it."
    new "اگر همچنان قصد انجامش رو داره، بهتر بود هم از اول بهش اجازه میدادیم."

    # say L4021 bri
    old "I wasn't finished!"
    new "من هنوز تمام نشدم!"

    # say L4023 bri
    old "If what you're describing was the case, I wouldn't have done anything."
    new "اگر همینطور بود، من هیچ کاری نمی‌کردم."

    # say L4024 bri
    old "Yes, she's still condensing magic within her."
    new "بله، او هنوز جادو را درون خود تراکم می‌دهد."

    # say L4026 bri
    old "But that doesn't mean that there's nothing we can do."
    new "اما این به معنای این نیست که هیچ کاری نمی‌توانیم انجام بدیم."

    # say L4028 bri
    old "Listen, even though this appears to be a normal human pregnancy, you must keep in mind that magic's involved."
    new "بله، حتی اگر به نظر برسه حاملگی عادی انسانیه، باید به ذهن داشت که جادو در این مورد نقش داره."

    # say L4029 bri
    old "I can't just make her pregnancy go away. But I can make it go a lot faster than it normally would."
    new "من نمی‌تونم این بارداری رو کاملاً برداشتم. اما می‌تونم آنقدر سریع‌ترش کنم که مثل عادی نباشه."

    # say L4031 pla
    old "W- what? So she'll have a baby soon?!"
    new "و- وای. پس او زودتر بچه خواهد داشت؟!"

    # say L4032 bri
    old "Hmph, no, she won't."
    new "همف، نه، او نخواهد داشت."

    # say L4033 pla
    old "Uhh... Alright? I'm a little confused."
    new "اوه... خب بله؟ من کمی گیج شدم."

    # say L4034 bri
    old "Well... Magic adheres to the natural laws of your world..."
    new "خب... جادو به قوانین طبیعی جهان تو متصل می‌شود..."

    # say L4035 bri
    old "And that's why, even though it may seem 'pregnant,' what it's actually gestating is magical power..."
    new "و برای همین، حتی اگر به نظر برسه که 'باردار' هست، در واقع چیزی که در حال رشد است قدرت جادوییه..."

    # say L4037 pla
    old "Ok, so there is not baby?"
    new "خب، پس اینجا بچه‌ای نیست؟"

    # say L4038 bri
    old "Well, technically, a baby could be born from this process since it's all magical power..."
    new "خب، فنیا، از این فرآیند می‌تونه یه بچه متولد بشه چون همه جادوییه..."

    # say L4039 bri
    old "However, that would only happen if we decide that a portion of the magical power she's gestating materializes and develops."
    new "البته، این فقط اتفاق می‌افتد اگر ما تصمیم بگیریم که بخشی از قدرت جادویی که او در حال حمل آن است، مادی شده و رشد کند."

    # say L4040 bri
    old "That way, a portion of the magical power would adapt to the woman's womb..."
    new "به این ترتیب، بخشی از انرژی جادویی به رحم زن سازگار می‌شود..."

    # say L4041 bri
    old "And, powered by the condensing magical energy, it would develop like a human baby."
    new "و با انرژی جادویی تراکم یافته، مثل یک بچه انسانی رشد می‌کنه."

    # say L4042 bri
    old "So by the time the magic is fully cultivated they both come out of the body together."
    new "پس وقتی جادو کاملاً رشد کنه، هر دو به همراه از بدن خارج می‌شن."

    # say L4044 bri
    old "But in this case things are going to be very different."
    new "اما در این مورد همه چیز خیلی متفاوت خواهد بود."

    # say L4045 bri
    old "Since it's going to be a lot faster than normal, only the magic will develop inside of her."
    new "چون خیلی سریع‌تر از معمول هست، فقط جادو در داخلش رشد خواهد کرد."

    # say L4046 bri
    old "So by the time she gives birth only the magic will be coming out of her."
    new "پس وقتی به دنیا می‌آید فقط جادو از او خارج می‌شود."

    # say L4047 pla
    old "Ok, ok... I think I understand."
    new "باشه، باشه... فکر کنم فهمیدم."

    # say L4049 pla
    old "But wait! What's going to happen when she goes to the doctor? Won't they realize there's something weird going on?"
    new "ولی بی‌چین! وقتی به دکتر می‌ره چه خواهد افتاد؟ آیا نمی‌فهمند که چیزی عجیب و غریب رخ داده؟"

    # say L4050 bri
    old "I can see why you would think that."
    new "می‌فهمم چرا اینجور فکر می‌کنی."

    # say L4052 bri
    old "But in human terms, she's still pregnant, even if it's just with magic."
    new "ولی از نظر انسانی، او هنوز باردار است، حتی اگر فقط با جادو باشد."

    # say L4054 bri
    old "When she goes to get checked with doctors and such, everything will appear to be normal."
    new "وقتی به پزشک می‌ره برای بررسی، همه چیز معمول به نظر می‌رسه."

    # say L4056 bri
    old "So everything should be ok."
    new "پس همه چیز باید خوب باشه."

    # say L4058 pla
    old "Alright, that's good to hear."
    new "البته، خوشحالم که اینطوره."

    # say L4060 pla
    old "So everything should be okay from here on out, right?"
    new "پس از این به بعد همه چیز خوب خواهد بود، درسته؟"

    # say L4062 bri
    old "Hmm, not entirely."
    new "Hmm، نه کاملاً."

    # say L4063 pla
    old "R- really?"
    new "وای، واقعاً؟"

    # say L4064 pla
    old "Is there something else?"
    new "مطمئنی هیچ چیز دیگه‌ای نیست؟"

    # say L4066 bri
    old "Well, what we're doing with this spell is trying to condense the magic energy needed to power up the portal to the magic world."
    new "خب، آنچه ما با این جادو انجام می‌دهیم این است که انرژی جادویی لازم برای فعال کردن دروازه به دنیای جادو را تراکم می‌دهیم."

    # say L4067 bri
    old "And we're doing it by condensing magic within the bodies of women."
    new "و ما این کار رو با تراکم جادو در بدن زنان انجام میدیم."

    # say L4068 pla
    old "Yeah, I get that."
    new "بله، اینو می‌فهمم."

    # say L4070 bri
    old "Well, the thing is that these women aren't natural magic wielders."
    new "خب، اینجاست که این زنان جادوگران طبیعی نیستند."

    # say L4071 bri
    old "Their bodies aren't able to condense magic at the same rate that the spell demands it."
    new "بدن‌شون نمی‌تونن جادو رو با همون سرعتی که تکلیف جادوگری می‌خواد، تراکم بدند."

    # say L4073 bri
    old "They would need your help with providing the magic they can't procure for themselves."
    new "آنها به تو نیاز دارن تا جادویی که خودشون نمی‌تونن به دست بیارن رو بهشون بده."

    # say L4075 bri
    old "So, under normal circumstances, Barbie would need you to help her by giving her magic."
    new "پس در شرایط عادی، باربی به تو نیاز داره که بهش جادو بده."

    # say L4076 bri
    old "But since this pregnancy will be so short, I don't think she'll need you to give her any condensed magic power."
    new "اما چون این بارداری خیلی کوتاهه، فکر نمی‌کنم باید تو بهش قدرت جادویی تراکم‌یافته بده."

    # say L4078 pla
    old "How would that work? The giving her magic part?"
    new "چطور این کار انجام می‌شه؟ بخش دادن جادو بهش؟"

    # say L4080 bri
    old "Oh, you know full well how that works, the same way you do it for me."
    new "اوه، تو خوب می‌دونی اینجوری کار می‌کنه، همون طوری که برای من انجام می‌دی."

    # say L4081 pla
    old "I- I see..."
    new "ب- بله..."

    # say L4083 bri
    old "But as I explained to you, given her particular conditions I can't be sure about what's about to happen with her."
    new "اما همانطور که به تو توضیح دادم، با توجه به شرایط خاصش نمی‌تونم از اونجایی که می‌افتد مطمئن باشم."

    # say L4084 bri
    old "So just be sure to be vigilant about what can happen to her. Just to make that she's fine."
    new "پس فقط مطمئن شو که به اتفاقاتی که می‌تونه برایش بیوفت توجه کنی. فقط برای اینکه مطمئن باشی که خوبه."

    # say L4086 pla
    old "I understand, alright, I'll be sure to do that."
    new "باشه، من فهمیدم، حتماً اینجوری خواهم کرد."

    # say L4087 pla
    old "But thanks anyway Brixxida, this gives me some peace of mind."
    new "ولی ممنون هر جا بودی، بریکسیدا، این به من آرامش می‌ده."

    # say L4088 bri
    old "Well, I'm just letting you know what happened."
    new "خب، فقط می‌خوام بگم چه اتفاقی پیش اومده."

    # say L4090 bri
    old "But don't forget that now you have to keep going with our plans."
    new "اما فراموش نکن که حالا باید با برنامه‌هامون ادامه بدی."

    # say L4091 bri
    old "I'm letting you off the hook with this one, but be sure to keep searching the next specimen."
    new "این بار از تو برمی‌آید، اما حتماً به دنبال نمونه بعدی بگرد."

    # say L4092 pla
    old "Yeah, alright."
    new "بله، خوب است."

    # say L4122 pla
    old "Oh, Barbie, hi!"
    new "اوه، باربی، سلام!"

    # say L4125 pla
    old "Hi, how are you?"
    new "سلام، چطوری؟"

    # say L4126 pla
    old "Is everything alright?"
    new "همه چیز خوبه؟"

    # say L4132 pla
    old "Uhmm... Are you alright?"
    new "اوه... حالت خوبه؟"

    # say L4134 pla
    old "Did you go to the doctor? Is everything okay?"
    new "به دکتر رفتی؟ همه چیز خوبه؟"

    # say L4137 pla
    old "Are you sure?"
    new "مطمئنی؟"

    # say L4141 pla
    old "Uhm... Sure, I don't see why not."
    new "اوه... حتماً، من هیچ دلیلی نمی‌بینم که نباشد."

    # say L4142 pla
    old "Let's go to my bedroom and we'll talk there."
    new "بیای به اتاق خواب من، اونجا صحبت می‌کنیم."

    # say L4148 pla
    old "Alright, do you want to tell me what's going on?"
    new "باشه، می‌خوای به من بگی چه خبری هست؟"

    # say L4149 pla
    old "Because I can tell that something's not right."
    new "چون می‌فهمم که چیزی درست نیست."

    # say L4158 pla
    old "So what's the problem?"
    new "پس مشکل چیه؟"

    # say L4162 pla
    old "Fatigue? Like you're tired?"
    new "خستگی؟ مثل اینکه خسته‌ای؟"

    # say L4168 pla
    old "How do you know that?"
    new "چطور می‌دونی؟"

    # say L4177 pla
    old "Hot?"
    new "گرم؟"

    # say L4181 pla
    old "Oh! I- I see."
    new "اوه! من- من متوجه شدم."

    # say L4187 bri
    old "This is it [pla]! This is what I told you about!"
    new "این هستش [pla]! این همون چیزیه که به تو گفتم."

    # say L4188 bri
    old "This fatigue she's talking about is her body manifesting its need for magic."
    new "این خستگی که در می‌گه، بدنش هست که نیاز به جادو رو نشون می‌ده."

    # say L4189 bri
    old "And the feeling of being {i}'horny'{/i} is her body telling her what she has to do to solve it."
    new "و احساس {i}آram {/i}ش بدنش بهش می‌گه که باید چی کنه تا این مشکل حل بشه."

    # say L4190 bri
    old "I wasn't expecting it to go this way, since the spell was canceled and everything."
    new "من منتظر نبودم اینجوری شه، چون تسلیمی لغو شده بود و همه."

    # say L4191 bri
    old "But what you have to do now is have sex with her so that she can feed off your magic!"
    new "اما الان باید تو با او جنسیت کنی تا از سحرتو تغذیه کنه!"

    # say L4195 pla
    old "W- what? N- no, of course not."
    new "و- وای! ن- نه، حتماً نه."

    # say L4197 pla
    old "Why would I think that there's anything weird about it?"
    new "چرا باید فکر کنم چیز عجیبی هست؟"

    # say L4199 pla
    old "I think that's very normal."
    new "من فکر می‌کنم این خیلی طبیعیه."

    # say L4200 pla
    old "After all, you're pregnant, I think it's pretty normal that you would have those feelings."
    new "در نهایت، تو حامله، فکر می‌کنم خیلی طبیعیه که این احساسات رو داشته باشی."

    # say L4203 pla
    old "What's wrong?"
    new "اوه، اومدی، چه خبر؟"

    # say L4213 pla
    old "Ohh, come on, what are you talking about?"
    new "اوه، بیای، چه حرفی می‌زنی؟"

    # say L4215 pla
    old "Yeah, it's true that you don't look like you usually do."
    new "بله، درسته که به نظرت مثل همیشه نیست."

    # say L4216 pla
    old "But that doesn't mean you look bad in any way."
    new "اما این به معنای این نیست که تو خوب نگاه نمی‌کنی."

    # say L4218 pla
    old "I mean, you look just as sexy as you always have."
    new "من قصد دارم بگم، تو همین الان هم مثل همیشه جذابی هستی."

    # say L4221 pla
    old "Of course I would!"
    new "البته که!"

    # say L4222 pla
    old "I'm surprised that you even feel like you'd have to ask me."
    new "متعجبم که حتی فکر می‌کنی باید از من بپرسی."

    # say L4223 pla
    old "You look just as beautiful as you always have."
    new "تو همیشه همینطور زیبا بودی."

    # say L4224 pla
    old "And I'll be more than happy to help you feel better."
    new "و خوشحالم که بهت کمک کنم تا حالت بهتر شه."

    # say L4229 pla
    old "Come on, don't say that."
    new "بیا، نگو اینجوری."

    # say L4230 pla
    old "You're just as beautiful as always."
    new "تو همیشه همینقدر زیبی."

    # say L4231 pla
    old "Let me show you."
    new "بیا، نشون بدم."

    # say L4257 pla
    old "I'm glad to be able to help you."
    new "خوشحالم که می‌تونم به تو کمک کنم."

    # say L4258 pla
    old "After all, you didn't get into this situation by yourself."
    new "در نهایت، تو خودت به این وضعیت وارد نشده‌ای."

    # say L4259 pla
    old "I figure this is the least that I can do."
    new "فکر می‌کنم این کمترین چیزیه که می‌تونم برایت بکنم."

    # say L4260 pla
    old "I'm glad it actually works."
    new "خوشحالم که واقعاً کار کرده."

    # say L4267 pla
    old "Sure, I'll be seeing you later."
    new "بله، بعداً می‌بینیم."

    # say L4274 bri
    old "Well done [pla]!"
    new "خوب انجام دادی [pla]!"

    # say L4275 bri
    old "With what you just did I'm sure that she'll be alright."
    new "با آنچه انجام دادی مطمئنم که او خوب است."

    # say L4277 pla
    old "Hmm, I guess that if she's going to be alright with just that, then that's fine."
    new "Hmm، اگه فقط با همین خوب می‌شه، خب خوبه."

    # say L4278 bri
    old "She will be. Don't worry, I'm sure that that's more than enough."
    new "نگران نباش، من مطمئنم که اونقدر کافیه."

    # say L4279 bri
    old "Which is great, because now you  can focus on what's next."
    new "این خوبه، زیرا حالا می‌توانی روی بعدی تمرکز کنی."

    # say L4281 pla
    old "However, this time I'll choose. We were lucky this time, but really 'impregnating' someone is not easy at all..."
    new "البته، این بار من انتخاب می‌کنم. بار اول خوشحالم شدیم، ولی واقعاً یک فرد رو باردار کردن خیلی آسون نیست..."

    # say L4283 bri
    old "Alright... But you can't take too long; we need to keep incubating more magical power for the portal..."
    new "البته... اما نمی‌تونی طول زیادی ببری؛ ما باید قدرت جادویی بیشتری برای دروازه تولید کنیم."

    # say L4285 bri
    old "Anyway, I'm gonna rest, I spend too much magic power with Barbie..."
    new "بازم، من قراره استراحت کنم، خیلی توان جادویی با Barbie صرف کردم..."

    # say L4286 pla
    old "Ok, see you later."
    new "باشه، ببینم بعداً."


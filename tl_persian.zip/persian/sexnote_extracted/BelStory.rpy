# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/BelStory.rpy
translate persian strings:

    # say L20 pla
    old "Hey guys, how are you?"
    new "سلام بچه‌ها، چطور هستین؟"

    # say L25 hin
    old "Hi [pla], good morning."
    new "سلام ز[pla]، صبح خوب."

    # say L26 mik
    old "Hi dude."
    new "سلام داداش."

    # say L27 bil
    old "Hey, what's up?"
    new "سلام، چطوری؟"

    # say L28 bel
    old "Hi [pla]."
    new "سلام ز[pla]."

    # say L30 pla
    old "What were you guys talking about?"
    new "ببینید، شما دو تا درباره چه چیزی صحبت می‌کردید؟"

    # say L34 bil
    old "Oh you know, just listening to Mike's dumb stuff."
    new "می‌دونی، فقط به گپ‌های خفن مایک گوش می‌دم."

    # say L38 mik
    old "Hey, what do you mean dumb stuff?"
    new "ببین، منظورت از چیزهای خفن چیه؟"

    # say L39 mik
    old "As I recall, you seemed to think it was very interesting."
    new "به خاطر دارم که تو به نظر می‌رسید خیلی جالب بود."

    # say L44 bel
    old "Well, it was only because there's nothing else going on this early in the morning."
    new "خب، فقط به خاطر این بود که هیچ کاری توی این وقت زودباز نداشتیم."

    # say L57 hin
    old "Hey guys, I think we should get going, classes are about to start."
    new "دستا، فکر می‌کنم باید بریم، کلاس‌ها قراره همین شروع بشه."

    # say L58 mik
    old "Yeah, we probably should."
    new "بله، احتمالاً باید بره."

    # say L75 bel
    old "[pla], wait."
    new "[pla]، صبر کن."

    # say L82 pla
    old "Yeah? What's up?"
    new "بله؟ چه کاری داری؟"

    # say L83 bel
    old "Uhm, the thing is... That there's something I need your help with."
    new "اوه، موضوعش اینه... که چیزی هست که به کمکت نیاز دارم."

    # say L85 pla
    old "Sure, what is it?"
    new "بله، چه کاری هست؟"

    # say L86 bel
    old "Hmm, I think it would be better if we talk about this somewhere else."
    new "Hmm، فکر می‌کنم بهتر باشه اینجا صحبت نکنیم."

    # say L88 bel
    old "Besides, there's something I have to show you."
    new "البته، چیزی هست که باید به تو نشون بدم."

    # say L89 bel
    old "So, how about you come to my house after classes."
    new "پس، چطور اگه بعد از کلاس‌ها به خونه‌ام بیایی."

    # say L91 pla
    old "Uh, yeah, sure..."
    new "بله، حتماً..."

    # say L100 luc
    old "Good morning Belle, [pla]."
    new "صبح بخیر بله، [pla]."

    # say L102 pla
    old "Godd morning Miss Lucy."
    new "صبح بخیر لوسی."

    # say L103 bel
    old "Good morning Miss Lucy."
    new "صبح بخیر خانم لوسی."

    # say L106 luc
    old "Guys, classes are about to start."
    new "دستا، کلاس‌ها خیلی زود شروع می‌شن."

    # say L107 luc
    old "It's not good that you two stay here talking in the hallway."
    new "خوب نیست که شما دو تا اینجا در راهرو حرف بزنید."

    # say L109 luc
    old "Good, now go to the classroom you two..."
    new "خوب، حالا شما دو تا بروید به کلاس..."

    # say L141 bel
    old "Ugh, that was eternal."
    new "اوه، این هیچ وقت نمی‌تونست پایان بیابه."

    # say L142 bel
    old "Miss Lucy just kept talking and talking."
    new "مس لوسی فقط حرف زد و حرف زد."

    # say L143 pla
    old "Tell me about it. I thought classes weren't going to end today."
    new "بله، همینجور. فکر کردم درس‌ها امروز هیچ وقت تمام نمی‌شدن."

    # say L144 bel
    old "Yeah, but anyway."
    new "بله، اما هر حالا."

    # say L145 bel
    old "Now that that is over, will you come with me to my house?"
    new "الان که این همه کار تمام شد، می‌خوای با من به خونه‌ام بیاد؟"

    # say L146 pla
    old "Uhh, sure."
    new "بله، می‌تونم."

    # say L147 bel
    old "Alright, then let's go!"
    new "خب، بیا برویم!"

    # say L173 pla
    old "What?! Oh."
    new "چه؟ اوه."

    # say L175 pla
    old "I'm just realizing that I have never visited your house before."
    new "من فقط متوجه شدم که هیچ وقت به خونه‌ات نرفتم."

    # say L177 bel
    old "Oh, I see."
    new "اوه، متوجه شدم."

    # say L179 bel
    old "Well, I try to avoid inviting people over because my mom tends to be intrusive and it annoys me."
    new "خب، من سعی می‌کنم افراد رو به خونه دعوت نکنم چون مامانم معمولاً مداخله‌گر است و این به من آزار می‌ده."

    # say L181 bel
    old "Although Mike has been here before."
    new "البته مایک قبلاً اینجا بوده."

    # say L183 bel
    old "I had to bring him when we were doing that team project."
    new "باید او رو همراه برمی‌آوردم وقتی که پروژه تیمی داشتیم."

    # say L185 bel
    old "And he met my mom..."
    new "و با مامانم آشنا شد..."

    # say L187 bel
    old "It wasn't any fun to see him constantly trying to hit on her..."
    new "دیدن اون همیشه سعی می‌کرد بهش لگه بزنه خوشحالم نبود..."

    # say L188 pla
    old "I can imagine him doing that."
    new "می‌تونم تصور کنم که اونجوری رفت."

    # say L189 bel
    old "It was so awkward."
    new "اینقدر ناامید کننده بود."

    # say L191 bel
    old "But anyway, what do you think about the house?"
    new "البته، اما بگو، تو در مورد خانه چه فکری داری؟"

    # say L193 pla
    old "Uh... It's very nice. I like the decoration a lot."
    new "آره... خیلی زیبا هست. خوشم اومده تزییناتش."

    # say L195 bel
    old "You do? My mom would be happy to hear that, she's really into interior design."
    new "تو هم؟ مامان خوشحال می‌شه اینجوری بشنید، او واقعاً به طراحی داخلی علاقه داره."

    # say L196 pla
    old "She is? Really?"
    new "وای، واقعاً؟"

    # say L198 bel
    old "Yep, she's a graphic designer, so, she's quite into decorating and stuff."
    new "بله، مامان من طراح گرافیک هست، پس خیلی به تزیین و اینجوری علاقه داره."

    # say L200 pla
    old "Hmm, I guess that makes a lot of sense."
    new "همم، فکر کنم این جا منطقیه."

    # say L202 bel
    old "So... Changing the subject."
    new "پس... موضوع رو عوض کنیم."

    # say L204 bel
    old "About... Uhhh, what I wanted to talk to you [pla]."
    new "درباره... اوه، چیزی که می‌خواستم با تو بگ [pla]."

    # say L205 pla
    old "Right, right, w- what is it?"
    new "بله، بله، و- و چه کاری هست؟"

    # say L206 bel
    old "Well, there's something I want to let you know about."
    new "خب، چیزی هست که می‌خوام بهت بگم."

    # say L208 bel
    old "Something I- I've been keeping hidden about myself."
    new "چیزی که از خودم پنهان می‌کردم."

    # say L209 pla
    old "Uhh... W- what is it?"
    new "اوه... ا- اون چیه؟"

    # say L210 bel
    old "Well, I- I think it's easier if I show you..."
    new "خب، فکر کنم بهتره بهت نشون بدم..."

    # say L213 bel
    old "This is it."
    new "این هست."

    # say L225 pla
    old "Oh wow, w- what is this?"
    new "اوه وای، این چیه؟"

    # say L235 bel
    old "Well, not exactly."
    new "خب، دقیقاً نه."

    # say L236 bel
    old "I'm a webcam model, it's a little different."
    new "من مدل وب‌کم هستم، کمی متفاوته."

    # say L240 bel
    old "This is something I've been doing for a while now."
    new "این کاری هست که از دیرباز می‌کردم."

    # say L241 bel
    old "I started by streaming video games, and I enjoyed it a lot."
    new "من از جریان پخش بازی‌های ویدیو شروع کردم و خیلی لذت بردم ازش."

    # say L243 bel
    old "Over time some of my followers started asking me about some..."
    new "در طول زمان بعضی از دنبال‌کنندگانم شروع کردند به من در مورد برخی چیزهای..."

    # say L244 bel
    old "More adult content."
    new "محتوای بزرگسالانه تر."

    # say L246 bel
    old "I started thinking about it. And decided I should give it a go."
    new "من شروع کردم به فکر کردن در مورد اون. و تصمیم گرفتم باید امتحانش کنم."

    # say L249 bel
    old "After all, I like being in front of the cameras, and I figured it would be alright as long as my face wasn't shown."
    new "در نهایت، دوست داشتم جلوی دوربین‌ها باشم، و فکر کردم اگه صورتم نشون داده نشه، مشکلی نداره."

    # say L252 bel
    old "From then on, I kept getting deeper and deeper into it."
    new "از آن پس، هر بار بیشتر و بیشتر به این کار وارد می‌شدم."

    # say L254 bel
    old "After all, I discovered I really enjoyed it."
    new "در نهایت، متوجه شدم واقعاً لذت می‌برم از این."

    # say L255 bel
    old "I've gotten a lot of experience doing this now."
    new "الان خیلی تجربه‌ی زیادی در این کار جمع کردم."

    # say L256 pla
    old "I- I guess I get it."
    new "من فهمیدم."

    # say L258 bel
    old "It's been good actually. I've even gotten to make some money off of it."
    new "در واقع خوب بوده. حتی از این کار پول کردم."

    # say L260 pla
    old "Oh! That sounds good."
    new "اوه! این خوبه."

    # say L262 pla
    old "But why are you suddenly bringing this up?"
    new "اما چرا الان این رو مطرح می‌کنی؟"

    # say L263 pla
    old "It's just that I imagine this is the type of thing you would want to keep secret, right?"
    new "فکر کنم این جوریه که تو می‌خوای اینو پوشش بدی، درسته؟"

    # say L265 bel
    old "I guess, so. Yeah."
    new "باید هست، بله."

    # say L266 bel
    old "But there's something happening, and I need some help with it."
    new "ولی چیزی اتفاق افتاده و به کمکت نیاز دارم."

    # say L267 bel
    old "And I think you're the one that could help me with it."
    new "و فکر می‌کنم تو هستی که می‌تونی به من کمک کنی."

    # say L269 pla
    old "M- me?!"
    new "من؟!"

    # say L271 bel
    old "You see, this is only my first year camming."
    new "ببین، این فقط سال اول من برای کام کردن هست."

    # say L273 bel
    old "But my results have been very good. I have received a lot of fan engagement."
    new "ولی نتایج من خیلی خوب بوده. خیلی از طرفدارانم با من تعامل کردن."

    # say L276 bel
    old "I even got nominated for an award!"
    new "حتی برای جایزه نامزد شدم!"

    # say L277 pla
    old "That's great Belle!"
    new "عالیه بله!"

    # say L278 pla
    old "Uh, I- I mean... I think so..."
    new "آره، منظورت رو متوجه شدم... من فکر می‌کنم همینطوره..."

    # say L280 bel
    old "Yeah, it is. It's a {b}'Female Revelation Streamer of the Year.'{/b}"
    new "بله، هست. این یک جایزه {b}'آفریننده ویدیویی زن سال'{/b} هست."

    # say L281 bel
    old "And I'm one of the forerunners for it!"
    new "و من یکی از رهبران اون هستم!"

    # say L282 pla
    old "I see, congrats Belle, that's awesome!"
    new "بله، مبارک Belle، خیلی عالیه!"

    # say L283 pla
    old "But all of that sounds very good."
    new "ولی همه اینا خیلی خوب به نظر می‌رسن."

    # say L284 pla
    old "I don't see what you could need my help with."
    new "من نمی‌فهمم چه کمکی از من می‌تونی برمی‌آیی."

    # say L286 bel
    old "You see, these awards are measured as a popularity contest."
    new "ببین، این جوایز بر اساس مسابقه‌ای از محبوبیت اندازه‌گیری می‌شنند."

    # say L288 bel
    old "So, the winner is decided by who gets the most fan votes and tips in their category by the end of the time period."
    new "پس، برنده ای که بیشترین رای و هدیه را در زمان مشخص شده در دسته خود دریافت کرده، می‌شود."

    # say L290 bel
    old "The number of votes and tips each person receives is put into a public chart, so, we know who's in the lead."
    new "تعداد رای‌ها و هدایایی که هر کس می‌گیره در یه جدول عمومی قرار می‌دهن، پس می‌دونیم کی جلوه."

    # say L291 bel
    old "Well, that's only until the final days of the contest."
    new "البته، این فقط تا روزهای نهایی مسابقه است."

    # say L292 bel
    old "Some days before it's over the results are hidden and the winner is announced at the end."
    new "چند روز قبل از پایان نتایج پنهان می‌شوند و برنده در آخر اعلام می‌شه."

    # say L294 pla
    old "I see."
    new "می‌بینم."

    # say L295 bel
    old "I've been doing pretty well on the polls."
    new "من در نظرسنجی‌ها خوب عمل کردم."

    # say L297 bel
    old "Since the beginning of the contest I have been at the top of the standings."
    new "از اول مسابقه من همیشه در جلو بودم."

    # say L298 bel
    old "So much so that I thought I was going to win it easily."
    new "به همین خاطر فکر می‌کردم راحت می‌برنم."

    # say L300 bel
    old "However, recently a new model has been getting all the attention."
    new "ولی اخیراً یک مدل جدید همه توجه رو به خودش جلب کرده."

    # say L301 bel
    old "There's this girl named Lana. She just appeared seemingly out of nowhere and overtook me."
    new "این دختری به نام لانا هست. او ناگهان پدیدار شده و من رو پشت سر گذاشته."

    # say L303 bel
    old "With the way things are going, she's going to run away with the lead, and beat me."
    new "با این وضعیت، او قطعاً جلو خواهد گرفت و من رو شکست خواهد داد."

    # say L305 pla
    old "Oh, I'm sorry Belle, it sucks that something like this is happening."
    new "اوه، ببخشید بله، خیلی بد هست که چیزی مثل این اتفاق می‌افته."

    # say L307 bel
    old "Oh! It really does! Especially because she's not getting the lead in the competition fairly!"
    new "اوه! واقعاً همینطوره! خصوصاً چون او جلوگیری رو به صورت عادلانه برنده نمی‌شه."

    # say L309 bel
    old "Well, I've been thinking about why this girl is so popular."
    new "خب، من داشتم فکر می‌کردم چرا این دختر همینقدر محبوبه."

    # say L311 bel
    old "And I figured it out."
    new "و من فهمیدم."

    # say L312 bel
    old "It's just because she's not doing the same things I and the other girls in the category are doing."
    new "البته، فقط به این دلیل هست که او همان کارهایی که من و دیگر دختران در این دسته‌بندی انجام می‌دهیم، نمی‌کند."

    # say L314 pla
    old "Isn't she doing livestreams like the others?"
    new "آیا او مثل دیگران استریم زنده می‌کنه؟"

    # say L316 bel
    old "Yes, but, as I told you, the category in which I'm competing is called ‘Female Revelation Streamer of the Year.'"
    new "بله، اما همانطور که به تو گفتم، دسته‌بندی‌ای که در آن شرکت می‌کنم «استریمر زن جدید سال» نام دارد."

    # say L317 bel
    old "It's a {i}single-person{/i} category."
    new "این یک دسته‌بندی {i}تک‌نفره{/i} است."

    # say L318 bel
    old "Otherwise couples or even groups could take part and compete in it."
    new "در غیر این صورت زوج‌ها یا حتی گروه‌ها می‌توانستند در آن شرکت کنند و رقابت کنند."

    # say L319 bel
    old "But they have their own category."
    new "اما برای آنها دسته‌بندی جداگانه وجود داره."

    # say L320 bel
    old "However, she is doing streams with a guy..."
    new "ولی او استریم‌هایش رو با یه مرد می‌کنه..."

    # say L322 bel
    old "Obviously, this type of content is much more appealing to the audience since it's literally a sex live show."
    new "البته، این نوع محتوا برای مخاطبان خیلی جذاب‌تره، چون مثل شوی زنده جنسی هست."

    # say L323 bel
    old "And this gives her a significant advantage over those of us who participate individually in our category..."
    new "و این برایش مزیت قابل توجهی در مقابل ما کسانی که به صورت انفرادی در دسته‌بندی خود شرکت می‌کنیم ایجاد می‌کنه..."

    # say L325 bel
    old "So she should be participating in another category, for example, {i}'Best Streamer couple of the Year'{/i}."
    new "پس باید در دسته‌بندی دیگری شرکت کنه، مثل {i}بهترین جفت استریمر سال{/i}."

    # say L326 pla
    old "I see, I suppose that makes sense."
    new "بله، فکر کنم منطقیه."

    # say L327 bel
    old "Of course, that makes sense! I even thought they would move her to a different category or suspend her for doing a different type of content..."
    new "البته، این معقوله! من حتی فکر کردم می‌خواهند او رو به دسته‌بندی دیگری منتقل کنند یا برای تولید محتوای متفاوتی موقتاً متوقف کنند..."

    # say L328 bel
    old "But apparently, there aren't any rules against what she is doing to compete in this category..."
    new "ولی به نظر می‌رسه هیچ قانونی علیه آنچه که اونجا می‌کنه برای شرکت در این دسته‌بندی وجود نداره..."

    # say L329 bel
    old "Since when she was nominated in the category, she was doing solo streams."
    new "از زمانی که در این دسته نامزد شد، او استریم‌های تک‌نفره می‌کرد."

    # say L330 bel
    old "But then, does that mean she can do whatever she wants and win?"
    new "ولی این بدان معناست که می‌تونه هر چی بیاد بکنه و برنده شه؟"

    # say L331 bel
    old "Taking advantage of doing things from other categories to get more attention?"
    new "از انجا که از دسته‌بندی‌های دیگر استفاده می‌کنه توجه بیشتری جلب می‌کنه؟"

    # say L332 pla
    old "Hmm, yes, I understand. If you look at it a certain way, it's like she's cheating."
    new "هم، بله، من متوجه شدم. اگه از یه جهت نگاه کنی، مثل اینه که داره یه نوع غش می‌کنه."

    # say L333 bel
    old "That's exactly what I think too! But the webcam platform doesn't seem to care..."
    new "این همینطوری که من هم فکر می‌کنم! اما به نظر می‌رسه پلتفرم وبکم هیچ اهمیتی نمی‌ده..."

    # say L334 bel
    old "After all, is not the same to see a couple fucking on screen, to just seeing somebody playing with a toy or something."
    new "در نهایت، دیدن یک جفت که در صفحه نمایش می‌باشند با دیدن کسی که فقط با یک اسباب‌بازی می‌کند، یکی نیست."

    # say L336 bel
    old "And the problem with that is that she's only doing it to win..."
    new "و مشکل اینجاست که او فقط برای برنده شدن این کار رو می‌کنه..."

    # say L337 bel
    old "Which means she's only interested in winning in this category now, by using tactics that of course gain her more popularity here."
    new "این بدان معناست که الان فقط به جایی که برنده شدن می‌خواد، با استراتژی‌هایی که البته اینجا محبوبیت بیشتری بهش می‌رسونه، در این دسته‌بندی می‌رها."

    # say L338 bel
    old "Because she knows she wouldn't win doing what we do, or doing what she's doing in a couples category!"
    new "چون می‌دونه با کاری که ما انجام می‌دیم یا با کاری که توی دسته‌بندی زوج‌ها می‌کنه، برننده نمی‌شه!"

    # say L342 bel
    old "Look, this is a recording from a recent streaming she did."
    new "ببین، این ضبطی از یک جریان اخیر که انجام داده است."

    # say L361 sis2
    old "I know this is what you guys have been waiting for."
    new "میدونم این همون چیزیه که شما منتظرش بودید."

    # say L362 sis2
    old "You all wanted to see me sucking a big cock didn't you?"
    new "می‌دونید همه شما می‌خواستید ببینید من چطور یه پیپ بزرگ می‌چرخونم، درسته؟"

    # say L382 bel
    old "Do you see? She's practically doing live sex!"
    new "می‌بینی؟ اونجا تقریباً جنس زنده می‌کنه!"

    # say L384 bel
    old "She shouldn't be in the 'Female Revelation Streamer' category!"
    new "باید در دسته‌ی «استریمر آشکارگر زن» قرار نگیره!"

    # say L386 pla
    old "I guess that her winning the contest by doing something that no one else is doing is unfair."
    new "باید بگم که برنده شدن اونا با کاری که هیچ کس نمی‌کنه، خیلی منصفانه نیست."

    # say L387 pla
    old "I get it, I get it."
    new "فهمیدم، فهمیدم."

    # say L388 pla
    old "And what are you planning to do about it?"
    new "و تو قراره چه کنی؟"

    # say L390 bel
    old "Well, to be honest [pla]..."
    new "البته، صادقانه بگم [pla]..."

    # say L394 bel
    old "I really like doing this, a lot."
    new "من واقعاً این کار رو خیلی دوست دارم."

    # say L396 bel
    old "I've worked so hard from the beginning."
    new "از اول خیلی سخت کار کردم."

    # say L398 bel
    old "And ever since I started I've put a lot of effort into being number one."
    new "و از همین اول تلاش زیادی کردم تا اول باشم."

    # say L399 bel
    old "In fact, until just a few days ago I was first in the rankings."
    new "در واقع، تا همین چند روز پیش من اول در رتبه‌بندی بودم."

    # say L400 bel
    old "So, I think I should be the one that wins that award!"
    new "پس فکر می‌کنم من باید آن جایزه رو برنده شم!"

    # say L401 bel
    old "Not some rando that just came out nowhere!"
    new "نه کسی از هیچ جا که ناگهان پدیدار شده!"

    # say L402 bel
    old "So, I've decided that I'm going to retake the lead in the contest."
    new "پس، من تصمیم گرفتم که دوباره جلو برم."

    # say L405 bel
    old "That's where I want you to help me."
    new "اینجا هست که می‌خوام تو به من کمک کنی."

    # say L406 pla
    old "Uhm... H- how?"
    new "اوه... چ- چطور؟"

    # say L409 bel
    old "I want to fight fire with fire!"
    new "من می‌خوام با آتش با آتش جنگ بکنم!"

    # say L410 bel
    old "I want to see if she will actually beat me if both of us are doing the same."
    new "می‌خوام ببینم اگه هر دو ما همین کار رو بکنیم، واقعاً منو می‌زنه یا نه."

    # say L414 pla
    old "You want to record yourself having sex on camera?!"
    new "می‌خوای خودت رو وقتی جنس می‌کنی ضبط کنی؟!"

    # say L416 bel
    old "W- Well... Technically we would be having s- sex live, but it would be recorded."
    new "خ- خب... فنیاً ما جنسی زنده می‌کردیم، اما ضبط می‌شد."

    # say L418 bel
    old "Well, yeah, that's why I need your help..."
    new "بله، همین جوری، برای اینکه نیاز به کمکت دارم..."

    # say L419 bel
    old "T- that way, I- I think I'll manage to get the votes to surpass Lana."
    new "ا- اونجوری، فکر کنم توانم آرا رو برای پیروزی بر لانا جمع کنم."

    # say L421 pla
    old "That's not the point..."
    new "این همین نیست، بیل."

    # say L422 pla
    old "I kinda get what you're saying, but, this is a little unexpected, you know?"
    new "ممنون از همین جا، ولی این کمی غیرمنتظره، می‌دونی؟"

    # say L424 bel
    old "I- I know it is. But listen, I've put a lot of effort into this."
    new "می‌دونم اینجوریه. ولی بگوش، من برای این خیلی تلاش کردم."

    # say L425 bel
    old "From streaming video games to getting into camming, and growing my fanbase."
    new "از استریمینگ بازی‌ها تا وارد شدن به کامینگ و افزایش مخاطبینم."

    # say L427 bel
    old "Losing is just not an option..."
    new "باختن هیچ گزینه‌ای نیست..."

    # say L429 bel
    old "So I need your help, please."
    new "پس لطفاً کمکت رو به من بده."

    # say L430 bel
    old "It will only be a couple of times, only until I can overtake her."
    new "فقط چند بار خواهد بود، فقط تا زمانی که بتونم از او پیش برسم."

    # say L432 pla
    old "I mean, I think I get it."
    new "من قصد دارم، فکر کنم متوجه شدم."

    # say L433 pla
    old "What I don't understand is why it has to be me."
    new "من نفهمیدم چرا حتماً من باشم."

    # say L434 pla
    old "Don't you know somebody that knows about this sort of thing?"
    new "می‌دونی کسی که از این جور چیزها بلد باشه؟"

    # say L435 pla
    old "You know... a professional?"
    new "می‌دونی... یه متخصص؟"

    # say L437 bel
    old "Actually, I don't know anybody... Any men, I mean."
    new "در واقع، هیچ‌کس نمی‌شناسم... منظورم هیچ مردی."

    # say L439 bel
    old "I've been doing everything by myself."
    new "من همه چیز رو خودم انجام میدم."

    # say L442 bel
    old "I haven't ever worked with anybody before, so I don't know any man inside this business that would do it."
    new "من هرگز با کسی همکاری نکردم، پس نمی‌دونم هیچ مردی توی این کار انجام میده."

    # say L444 bel
    old "But if I'm completely honest with you [pla], even if I knew a webcam actor or model I would still prefer to do it with you."
    new "اما اگر صادقانه با تو باشم [pla]، حتی اگر بازیگر وبکم یا مدلی رو بشناختم هم همچنان ترجیح میدم با تو انجام بدم."

    # say L446 pla
    old "What? R- Really?"
    new "چی؟ واقعاً؟"

    # say L448 bel
    old "Well, I don't want to do this with some unknown person. For me sex is a very intimate thing."
    new "خوب، من نمی‌خوام اینجوری با کسی ناشناخته بکنم. برای من جنس یه چیز خیلی نزدیکه."

    # say L450 bel
    old "I at least want it to be with someone I trust."
    new "باید حداقل با کسی باشه که بهش اعتماد دارم."

    # say L451 pla
    old "I- uh... I understand."
    new "من- اوه... من متوجه شدم."

    # say L453 pla
    old "But I'm don't know Belle. I don't think I want people watching me have sex on camera."
    new "ولی من نمی‌دونم Belle. فکر نمی‌کنم بخوام اینکه مردم به من در حال جنسیت کردن نگاه کنن."

    # say L455 pla
    old "Besides, and I know this is kind of obvious... That also means that you and I would have to have sex, right?"
    new "البته، و میدونم این به نظر احتمالی می‌تونه بیاد... این هم به این معناست که تو و من باید جنسی با هم داشته باشیم، درسته؟"

    # say L456 pla
    old "Are you ok with that?"
    new "تو با این راحتی هستی؟"

    # say L458 bel
    old "I- I do... As I told you [pla], I trust you."
    new "من- من همینجوری... مثل زمانی که به تو گفتم [pla]، من به تو اعتماد دارم."

    # say L460 bel
    old "Also, is not as if you and I have never done that sort of thing before, right?"
    new "همچنین، اینطور نیست که ما قبلاً همچین کاری نکرده باشیم، درسته؟"

    # say L461 bel
    old "This won't be too different from that."
    new "این خیلی متفاوت از آن نخواهد بود."

    # say L463 bel
    old "And about the whole appearing on camera thing, you don't have to worry about that."
    new "و در مورد اون جوری که توی کامرو پدیدار می‌شی، نباید نگران باشی."

    # say L465 bel
    old "I will focus the camera so that your face doesn't show in any way."
    new "من دوربین رو تنظیم می‌کنم تا صورتت هیچ جور نشون نده."

    # say L467 bel
    old "Please [pla], I want to win this."
    new "لطفاً [pla]، من می‌خوام برنون."

    # say L469 bel
    old "I know this is just what I need to win against Lana."
    new "میدونم این همون چیزیه که باید ببرم جلوی لانا."

    # say L476 pla
    old "I guess it's fine if it helps you..."
    new "بلاهایی، اگه به تو کمک می‌کنه خوبه..."

    # say L477 bel
    old "So, you'll do it?"
    new "پس تو اینجوری می‌کنی؟"

    # say L480 pla
    old "I can't believe it, but I will."
    new "من نمی‌تونم باور کنم، ولی می‌کنم."

    # say L482 bel
    old "Thanks a lot [pla]!"
    new "ممنون زیاد [pla]!"

    # say L483 bel
    old "So, I have to prepare everything on stream."
    new "پس باید همه چی رو برای استریم آماده کنم."

    # say L485 bel
    old "I have to let my fans know about it."
    new "باید فان‌هام رو از این موضوع آگاه کنم."

    # say L488 bel
    old "Let them know there's a surprise coming and stuff."
    new "باید بهشون بگم که مفاجآتی هست و اینجوری."

    # say L489 bel
    old "I'll let you know when we'll do it."
    new "من به تو اطلاع خواهم داد وقتی قراره انجام بدیم."

    # say L493 bel
    old "Thanks a lot [pla]."
    new "ممنون زیاد [pla]."

    # say L496 pla
    old "So... "
    new "پس..."

    # say L497 pla
    old "I think I'll see you later then."
    new "بelle، به نظر می‌رسه بعداً هم می‌بینیم."

    # say L499 bel
    old "Sure, I'll prepare everything and let you know when we're ready to stream."
    new "بله، همه چیز رو آماده می‌کنم و وقتی آماده شد برای استریمینگ ازت خبر می‌دم."

    # say L500 pla
    old "Alright, great!"
    new "البته، عالی!"

    # say L501 pla
    old "Bye Belle."
    new "بای بله."

    # say L502 bel
    old "Bye [pla], and thank you so much again."
    new "بای [pla]، و ممنونم خیلی ازت."

    # say L526 pla
    old "Hi Belle, good morning, how are you?"
    new "سلام بله، صبح بخیر، چطوری؟"

    # say L528 bel
    old "Listen [pla], my mother told me she won't be in the house this afternoon."
    new "بگوش [pla]، مامان به من گفت امروز بعد از ظهر در خونه نخواهد بود."

    # say L529 bel
    old "She has a meeting or something."
    new "مادرم یه اجلاس یا چیزی داره."

    # say L531 bel
    old "So, today can be the first day that you come and help me with my stream."
    new "پس امروز می‌تونی اولین بار بیاد و به من در استریم کمک کنی."

    # say L535 bel
    old "Plus, I think this is a good opportunity for you to make your first appearance on camera."
    new "البته، فکر می‌کنم این فرصت خوبی برای اولین حضورت در کامپیوتر باشه."

    # say L536 bel
    old "So that you can get a feel for it, and start getting used to beign on camera."
    new "تا بتونی احساسش بگیری و شروع کنی به آشنایی با کامرا."

    # say L538 pla
    old "O- ok sure, no problem."
    new "ب- بخشه، هیچ اشکالی ندارم."

    # say L539 pla
    old "L- lets do it."
    new "ب- بیایم انجام بدیم."

    # say L541 bel
    old "Ok, great!"
    new "اوه، عالی!"

    # say L542 bel
    old "Come to my house in the afternoon."
    new "بعد از ظهر به خونه‌ام بیا."

    # say L544 pla
    old "I thought I would go with you right after we finished classes."
    new "من فکر می‌کردم بعد از تمام شدن کلاس‌ها با تو برسم."

    # say L546 bel
    old "No, I will skip classes today. I need to go home and get everything ready for the stream. I just came to let you know."
    new "نه، امروز کلاس‌ها رو می‌پرم. باید برم خونه و همه چیز رو برای استریم آماده کنم. فقط برات اومدم بگم."

    # say L547 pla
    old "Alright, no problem."
    new "باشه، مشکلی نداره."

    # say L549 bel
    old "So, see you later at my house."
    new "پس، بعداً خونه‌ام رو بیای."

    # say L571 pla
    old "Ok, I think Belle must be waiting for me..."
    new "باشه، فکر کنم Belle منتظرم هست..."

    # say L572 pla
    old "Phew, I don't know how I always get myself into these things..."
    new "پوف، نمی‌دونم چطور همیشه خودمو به این جور چیزها وردم..."

    # say L593 ash
    old "Oh! Hello."
    new "اوه! سلام."

    # say L595 pla
    old "Uh... H- hi, g- good afternoon."
    new "اوه... س- سلام، ع- عصر خوب."

    # say L597 ash
    old "Good afternoon. Can I help you with something?"
    new "بعد از ظهر. می‌تونم به تو کمکی کنم؟"

    # say L599 pla
    old "I- uh... yes, I'm [pla], I'm a friend of Belle."
    new "ب- بله، من [pla] هستم، دوستی از Belle."

    # say L600 pla
    old "I- I came to do some... Uh, s- schoolwork with her."
    new "من- من برای انجام... آه، س- سرکارهای مدرسه‌ای با او اومدم."

    # say L602 ash
    old "Oh! Nice meeting you [pla]! My name is Ashley, I'm Belle's mother."
    new "اوه! خوشحالم که با تو آشنا شدم [pla]! من اسمم اشلی هستم، مامان بله هستم."

    # say L603 pla
    old "H- Hi..."
    new "ه- هی آشلی..."

    # say L606 pla
    old "Excuse me Mrs. Ashley..."
    new "ببخشید آشلی..."

    # say L608 ash
    old "Mrs. Ashley? Haha, oh dear no, just call me Ashley. I'm too young to have anyone call me Mrs."
    new "آشلی؟ هاها، خدا نا، فقط منو آشلی بخون. من خیلی جوانم تا کسی منو خانم بخون."

    # say L610 pla
    old "O- ok, A- Ashley. Is Belle around? She told me to come at this time."
    new "ا- اشلی. بله در این زمان باید اومده بودم. بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، بله، ب"

    # say L612 ash
    old "She is dear, she's in her bedroom."
    new "بله عزیزم، در اتاق خوابش هست."

    # say L613 ash
    old "I'll let her know you're here."
    new "من بهش می‌گم که اومدی."

    # say L615 pla
    old "T- thanks."
    new "ممنون."

    # say L625 bel
    old "[pla]! H- hi! I- I didn't notice you arrived! Sorry."
    new "[pla]! ه- هی! من متوجه نشدم که رسیده‌ای! معذرت."

    # say L627 bel
    old "Mom, why didn't you tell me a visit for me had arrived?"
    new "مامان، چرا نگفتی که یک بازدید برای من رسیده؟"

    # say L630 ash
    old "Well sweety, you didn't tell me you were expecting anyone."
    new "خوب عزیزم، تو به من نگفتی که منتظر کسی هستی."

    # say L633 ash
    old "But I was just about to come and tell you your friend had arrived."
    new "ولی همین جا بودم می‌خواستم بیام و به تو بگم دوستت رسیده."

    # say L635 bel
    old "I- I see...."
    new "من- من می‌بینم..."

    # say L636 bel
    old "Anyway mom, [pla] and I are going to be working in my room."
    new "بازهم، مامان، من و [pla] قراره در اتوم من کار کنیم."

    # say L639 bel
    old "So, it would be nice if you could avoid interrupting us."
    new "پس خوب باشه اگر مداخله نکنی."

    # say L641 ash
    old "Well, I guess I'll do my best not to bother you, sweetheart."
    new "ببین، سعی می‌کنم تا از آزاردهنتان پرهیز کنم، عزیزم."

    # say L644 bel
    old "Come on [pla], let's go."
    new "بیا [pla]، برویم."

    # say L658 pla
    old "Hey, what's up? I thought you said she wasn't going to be here today?"
    new "هی، چه خبر؟ فکر کردم می‌گفتی امروز نمی‌آیاد."

    # say L659 bel
    old "Yeah I know, sorry"
    new "بله، معذرت"

    # say L661 bel
    old "She just suddenly came back home and said she was going to work from home today."
    new "او به طور ناگهانی برگشت و گفت امروز از خونه کار می‌کنه."

    # say L662 bel
    old "I don't know why, I guess something happened at the office."
    new "نمیدونم چرا، به نظر میره چیزی تو اداره اتفاق افتاده."

    # say L663 pla
    old "Hmm ok, yeah, I understand."
    new "Hmm خب، بله، من متوجه شدم."

    # say L664 pla
    old "I suppose we're not streaming today then."
    new "باز هم نمی‌تونیم امروز استریم کنیم."

    # say L666 bel
    old "Yep, we can't do the stream with my mother here."
    new "بله، نمی‌تونیم با مامان اینجا استریم کنیم."

    # say L668 bel
    old "She could come in at any time."
    new "می‌تونه هر وقتی وارد بشه."

    # say L670 bel
    old "She'll be bringing some snacks, or knocking on the door to see how we're doing, or something."
    new "مادرم می‌تونه هر لحظه وارد بشه، یا سناک بیاره، یا برای دیدن اوضاع ما به در بزنه."

    # say L673 bel
    old "My mom's very controlling, and she'll want to know what we're doing here."
    new "مامانم خیلی کنترل‌کننده است و می‌خواهد بدوند اینجا چه کار می‌کنیم."

    # say L675 bel
    old "So, it's better if we don't risk being caught in the middle of it."
    new "پس بهتره اینکه خطر نبگیریم وسطش."

    # say L679 bel
    old "I'm sorry [pla]... that ruins our plans for today."
    new "متاسفم [pla]... این همه طرح ما رو برای امروز خراب می‌کنه."

    # say L680 bel
    old "I'm sorry to have you come here for nothing."
    new "متاسفم که تو را برای هیچی اینجا آورده‌ام."

    # say L682 pla
    old "Oh, don't worry. We can do it on any other day. I'll head back home then."
    new "اوه، نگران نباش. می‌تونیم هر روز دیگه‌ای انجام بدیم. من حالا بر می‌گردم."

    # say L684 bel
    old "Well, maybe you should stay for a little while."
    new "شاید باید یه کم بمانی."

    # say L685 bel
    old "After all, you just got here. My mom could get suspicious if you leave just after arriving."
    new "در نهایت، net فقط اومدی. مامان می‌تونه شک کنه اگه net بعد از ورودت بره."

    # say L687 pla
    old "Ok, so what are we going to do?"
    new "خب، پس ما چه کاری می‌کنیم؟"

    # say L689 bel
    old "I was thinking I could let you know a bit more about this whole camming thing, how it works and stuff."
    new "من فکر می‌کنم می‌تونم بیشترت در مورد این کار کم‌کاری آموزش بدم، چطور کار می‌کنه و همین‌جور."

    # say L690 pla
    old "Oh, ok sure."
    new "اوه، خوب حتماً."

    # say L692 bel
    old "So, the way the stream works is through a {i}'tips'{/i} system."
    new "پس، روش این است که از طریق سیستم {i}تیپ{/i} انجام می‌شه."

    # say L694 bel
    old "While we're doing it, that's the most important thing to keep in mind."
    new "در حالی که این کار رو انجام میدیم، این چیزیه که باید بهش توجه کرد."

    # say L696 bel
    old "And whatever I'm going to do, I do it live, instead of having it pre-recorded, like in porn."
    new "و هر کاری که من انجام می‌دم، زنده انجام می‌شه، نه مثل فیلم‌های پورنو که قبل از اون ضبط شدن."

    # say L697 bel
    old "Since everything is completely live, tips are very important."
    new "چون همه چیز کاملاً زنده انجام می‌شه، نکات خیلی مهم هستند."

    # say L698 pla
    old "Why?"
    new "چرا؟"

    # say L700 bel
    old "Well, because the livestream is a type of show."
    new "خب، چون استریم زنده نوعی شو هست."

    # say L701 bel
    old "Which means that my fans have to be engage and entertained."
    new "این به معنی اینه که مراکز من باید جذب و لذت ببرن."

    # say L703 bel
    old "And the only reliable way I can gauge if they really like it, is by seeing their tips."
    new "و تنها راه قابل اعتماد برای فهمیدن اینکه آیا واقعاً لذت می‌برند یا نه، این است که نکاتشون رو ببینم."

    # say L704 bel
    old "So, the whole objective of each time I'm on camera is to get them to tip."
    new "پس هدف من هر بار که روی دوربین هستم اینه که اونا رو به دادن نکات ترغیب کنم."

    # say L705 pla
    old "Uhh... I see."
    new "اوه... من متوجه شدم."

    # say L706 bel
    old "So, whenever the stream starts, I have to set up some {i}'goals'{/i}."
    new "پس هر بار که استریم شروع می‌شه، باید برخی {i}اهداف{/i} تعیین کنم."

    # say L708 bel
    old "Which is the number of tips I want my fans to give me before I do anything."
    new "این عدد تعداد نکاتیه که می‌خوام فالان‌هامون برام بزنن تا هر کاری بکنم."

    # say L709 bel
    old "If the audience matches the goals by tipping, I do what I promised for that goal, and move into the next one."
    new "اگر مخاطبان هدف رو با تیپ دادن به دست بیارن، من اون کاری که برای هدف قول دادم انجام میدم و به هدف بعدی میرم."

    # say L711 pla
    old "I think I get it."
    new "فکر کنم متوجه شدم."

    # say L712 pla
    old "So, whether we do something or not, depends on the audience?"
    new "پس، اینکه ما چیکار بکنیم یا نه، بستگی به مخاطبان داره؟"

    # say L713 bel
    old "That's right, we decide what to do, but we only do it if the goal is met."
    new "درست می‌فرمایی، ما تصمیم می‌گیریم چه کاری انجام بدیم، اما فقط وقتی هدف رسیده باشه، انجام می‌دهیم."

    # say L715 pla
    old "That sounds simple."
    new "این ساده به نظر می‌رسه."

    # say L717 bel
    old "Well, it's all about personality, and how much you connect with the audience, you know?"
    new "البته، همه‌چیز به شخصیت و ارتباطت با مخاطبان بستگی داره، می‌فهمی؟"

    # say L718 bel
    old "So it's important to talk to them, try and pay attention to their comments, and the demands they make."
    new "پس مهمه باهاشون صحبت کنی، سعی کنی به نظراتشون توجه کنی و درخواست‌هایشون رو بررسی کنی."

    # say L720 pla
    old "That makes sense."
    new "این جوری هست."

    # say L722 bel
    old "And as I told you before, you don't need to talk or interact with them."
    new "و همانطور که قبلاً به تو گفتم، نیازی نداری باهاشون صحبت کنی یا تعامل داشته باشی."

    # say L724 bel
    old "After all, my fans want to see me doing something with a... w- with a penis."
    new "در نهایت، مراقبانم می‌خواهند ببینند من چیزی با... با یک پوس انجام می‌دهم."

    # say L726 bel
    old "But they don't really want to get to know you."
    new "اما آنها واقعاً نمی‌خواهند با تو آشنا شوند."

    # say L728 bel
    old "T- the most important is for you to... have a b- boner during the show."
    new "ب- بیشترین مهم اینه که تو... یه سفتی در طول شو داشته باشی."

    # say L729 bel
    old "I- I'll take care of the rest."
    new "من بقیه‌اش رو می‌گیرم."

    # say L731 pla
    old "Well... I- I guess I can manage that."
    new "خب... فکر کنم بتونم اینجوری باشم."

    # say L742 ash
    old "Hey guys! How are you doing?"
    new "سلام دختران و پسران! چطور هستید؟"

    # say L744 bel
    old "Uhmm, we're doing fine mom."
    new "می‌تونیم خوب باشیم مامان."

    # say L745 bel
    old "But I would've appreciated it if you'd knocked on the door before entering."
    new "ولی خوشحالم که قبل از ورود به اتاق کلک کردی."

    # say L748 ash
    old "I'm sorry honey, but I just wanted to see if you needed anything."
    new "ببخشید عزیزم، فقط می‌خواستم ببینم آیا نیازی به چیزی داری."

    # say L750 ash
    old "Maybe you would like me to bring you some snacks?"
    new "شاید بخواهی تا برایت چیزی از خوراکی بیاورم؟"

    # say L752 bel
    old "I think we're fine mom, thank you."
    new "ممنون مامان، ولی فکر کنم ما خوبیم."

    # say L753 ash
    old "Ok sweety, I'll leave for now then."
    new "خوب عزیزم، حالا می‌روم."

    # say L754 ash
    old "But if you two need anything, just let me know."
    new "اما اگر شما دو تا به هیچی نیاز داشتین، فقط به من بگویین."

    # say L755 bel
    old "Yeah, right, thank you..."
    new "بله، درسته، ممنون..."

    # say L763 bel
    old "Sorry, she just came in unannounced."
    new "ببخشید، او فقط بدون اطلاع وارد شد."

    # say L765 pla
    old "It's ok, we kinda knew she was going to do that."
    new "خوبه، ما هم از قبل می‌دونستیم که اینجوری می‌کنه."

    # say L766 bel
    old "Yeah... but that's why we can't do anything whenever she's here."
    new "بله... اما همین جوری هر وقت که اونجا هست، ما نمی‌تونیم هیچ کاری بکنیم."

    # say L767 pla
    old "Y- yeah, I- I get it..."
    new "بله، من هم متوجه شدم..."

    # say L769 bel
    old "Well, anyway, t- there hasn't been enough time since you came here."
    new "البته، اما هر چه، زمان کافی از زمانی که اینجا آمدی گذشته نیست."

    # say L770 bel
    old "So, why don't I show you the webcam platform in the meantime?"
    new "پس چرا من در این میان به تو پلتفرم وب‌کم رو نشون نمی‌دم؟"

    # say L771 pla
    old "Yeah... sure."
    new "بله... البته."

    # say L780 bel
    old "Ok, this is my profile..."
    new "خب، این پروفایل من هست..."

    # say L792 bel
    old "Ok [pla], I think that should be enough time for my mom not to suspect anything."
    new "باشه [pla]، فکر کنم این مدت کافیه تا مامان هیچ شکی نداشته باشه."

    # say L793 bel
    old "I'll let you know when it's ok for you to come again."
    new "بales، وقتی بشه، می‌گم که بیا دوباره."

    # say L794 pla
    old "Yeah, sure, just tell me when and I'll come to help you."
    new "بله، حتماً، فقط وقتی بگو بیام، من برای کمکت می‌یوم."

    # say L796 pla
    old "You're welcome Belle, I'm happy to help you."
    new "خوشحالم که بتونم بهت کمک کنم، بله."

    # say L797 bel
    old "I hope next time we won't have any problems streaming."
    new "امیدوارم بار بعد هیچ مشکلی برای استریمینگ نداشته باشیم."

    # say L799 bel
    old "The voting period is closing soon, and we won't be able to do anything if we have to postpone it too much."
    new "دوره رای‌گیری زود به پایان می‌رسد، و اگر بخواهیم به طول بکشیم، هیچ کاری نمی‌توانیم انجام بدهیم."

    # say L801 pla
    old "I get it, but what happened today was just unexpected."
    new "فهمیدم، ولی امروز همه چیز غیرمنتظره بود."

    # say L802 pla
    old "I bet there won't be any problem going forward."
    new "بی‌نقضی احتمالاً هیچ مشکلی نخواهیم داشت."

    # say L804 bel
    old "Yeah, you're probably right."
    new "بله، احتمالاً درست می‌گویی."

    # say L805 pla
    old "So, listen... I guess I should get going, right?"
    new "بله، بله... به نظر می‌رسه باید برم، درسته؟"

    # say L807 bel
    old "Sure, I'll see you later [pla], thanks again for coming."
    new "بله، بعداً می‌بینیم [pla]، ممنونم از اینکه اومدی."

    # say L808 pla
    old "You're welcome, see you later Belle."
    new "خواهش می‌کنم، بعداً می‌بینیم Belle."

    # say L831 bel
    old "Hi [pla]!"
    new "سلام [pla]!"

    # say L832 pla
    old "Hi Belle."
    new "سلام Belle."

    # say L834 pla
    old "Uhm, I'm doing well, and you?"
    new "اوه، من خوب هستم، تو چطوری؟"

    # say L838 bel
    old "So listen, after you left, my mom said it was very nice to meet you."
    new "پس بگو، بعد از اینکه رفتی، مامان گفت خوشحالم که با تو آشنا شدم."

    # say L840 pla
    old "S- she did?"
    new "م- مطمئن هستی؟"

    # say L842 bel
    old "Yeah, she said that you seemed to be a good person."
    new "بله، او گفت که تو به نظر انسان خوبی می‌آیی."

    # say L844 pla
    old "I- I guess that's nice."
    new "من فکر می‌کنم این خوبه."

    # say L846 bel
    old "It is, when she met Mike she went on an on about how rude he was."
    new "وقتی با مایک آشنا شد، همینجوری در مورد خشنودی‌اش حرف زد."

    # say L848 bel
    old "So, I'm glad she liked you."
    new "پس خوشحالم که تو رو دوست داشت."

    # say L849 pla
    old "Uhh, w- well, that's great."
    new "اوه، خب، این خوبه."

    # say L851 bel
    old "Yeah, that may make things easier in the future."
    new "بله، این ممکن است مسائل آینده را راحت‌تر کنه."

    # say L852 bel
    old "But leaving that aside, my mom told me she won't be home this afternoon."
    new "اما این را گذاشته‌ایم، مامانم به من گفت که امروز بعد از ظهر خونه نیست."

    # say L854 bel
    old "So we can start streaming today!"
    new "پس می‌تونیم امروز شروع به استریم کنیم!"

    # say L856 pla
    old "Ok... that sounds alright."
    new "باشه... این هم خوب است."

    # say L858 bel
    old "Ok, let's go to my house after classes then."
    new "باشه، بعد از کلاس‌ها به خونه‌ام بیا."

    # say L887 bel
    old "Ok, let's go to my house then."
    new "باشه، بیای به خونه‌ام بعد از کلاس‌ها."

    # say L919 bel
    old "Alright, before we begin there's a couple of things we have to check."
    new "باشه، قبل از شروع چند تا چیزی باید بررسی کنیم."

    # say L920 pla
    old "Oh... Ok."
    new "اوه... خوب."

    # say L922 bel
    old "You remember what I told you about how it's important to talk to the audience, right?"
    new "ممنون که یادت هست که با حضار صحبت کردن مهمه، درسته؟"

    # say L925 bel
    old "You also remember that I told you I'm the one who's going to be talking to them, right?"
    new "همینطور به یاد داری که من هستم که با آنها صحبت می‌کنم، درسته؟"

    # say L926 pla
    old "Yeah, I do, no problem."
    new "بله، به خاطر دارم، هیچ مشکلی ندارم."

    # say L928 bel
    old "Ok, I already announced that I was going to have a big surprise in today's stream."
    new "خب، من قبلاً اعلام کردم که در جریان امروز مفاجأه بزرگی دارم."

    # say L929 bel
    old "So, I'll come in on stream and start the whole thing."
    new "پس من وارد استریم می‌شوم و همه چیز را شروع می‌کنم."

    # say L931 bel
    old "Talking to the audience, and when it's the right time, I'll tell you to come in."
    new "با شما صحبت می‌کنم و وقت مناسب بود، از شما می‌خواهم وارد شوید."

    # say L933 pla
    old "Ok, I understand."
    new "باشه، فهمیدم."

    # say L935 bel
    old "The camera will be pointing in my direction."
    new "کامره به طرف من خواهد نگاه کرد."

    # say L936 bel
    old "You'll wait out of frame while I start the stream, and when I tell you, you come in."
    new "تو از بیرون فریم منتظر می‌مانی تا من استریم رو شروع کنم، و وقتی به تو می‌گم، داخل می‌آیی."

    # say L938 bel
    old "By the way, you won't be naked from the beginning... J- just wearing your shorts will be ok."
    new "البته، از اول عریان نخواهی بود... فقط لباس زیرت رو پوشیدن کافیه."

    # say L940 pla
    old "Ok, I think I get it."
    new "باشه، فکر کنم متوجه شدم."

    # say L942 bel
    old "You know, [pla], I'm very thankful to you for doing this."
    new "می‌دونی، [pla]، خیلی ممنون ازت هستم که اینجوری کمک می‌کنی."

    # say L944 bel
    old "I know this is new for you, and you're probably not very comfortable with it."
    new "می‌دونم این برای تو جدیده و احتمالاً خیلی راحت نیستی."

    # say L945 bel
    old "So it means a lot to me that you're willing to help me this way."
    new "پس برایم خیلی مهمه که تمایل داری به این طوری به من کمک کنی."

    # say L950 pla
    old "I will admit I was very surprised when you asked me to do this."
    new "باید بگم خیلی تعجب کردم وقتی از من پرسیدی این کار رو بکنم."

    # say L952 pla
    old "But you're a very good friend, and if this is important for you, then I'm happy to help you."
    new "ولی تو دوست خوبی هستی و اگر این برایت مهمه، من خوشحالم که بهت کمک کنم."

    # say L955 bel
    old "Now, we should go to my room."
    new "الان، باید به اتاقم برویم."

    # say L976 bel
    old "Now, before we start, I have to change. Wait here a minute."
    new "الان، قبل از شروع، باید پوششمو عوض کنم. یه لحظه صبر کن."

    # say L994 bel
    old "What are you making that face for?"
    new "چرا این چهره رو می‌کنی؟"

    # say L997 pla
    old "Oh, n- nothing, you just..."
    new "اوه، نه چیزی، فقط..."

    # say L1001 pla
    old "I- I wasn't expecting it."
    new "من- من منتظر این نبودم."

    # say L1002 bel
    old "Well... thank you."
    new "خب... ممنون."

    # say L1003 bel
    old "So, I'll start with the stream, and let you know when to come into frame, ok?"
    new "پس من با استریم شروع می‌کنم و وقتی باید وارد تصویر بشی به تو می‌گم، خوبه؟"

    # say L1005 pla
    old "Right, sure."
    new "بله، حتماً."

    # say L1020 bel
    old "Ok guys!"
    new "اوه خوب، بچه‌ها!"

    # say L1021 bel
    old "Hello! Are you all ready for a new session?"
    new "سلام! آیا همه‌تون آماده‌این برای جلسه‌ی جدید؟"

    # say L1022 bel
    old "I've missed you guys!"
    new "من به شما همه خیلی خواستم!"

    # say L1023 bel
    old "Yes, I know I didn't stream the other day when I told you I would."
    new "بله، می‌دونم روزی که قول دادم استریم نکردم."

    # say L1024 bel
    old "But something came up, and it became impossible to start the stream."
    new "ولی چیزی پیش اومد و شروع استریم کردن غیرممکن شد."

    # say L1025 bel
    old "But I'm going to make it up to you guys!"
    new "اما من قرار هست اینو به شما جبران کنم!"

    # say L1026 bel
    old "As I promised you, I have a big surprise today!"
    new "همانطور که به شما قول دادم، امروز برای شما مفاجأه بزرگی دارم!"

    # say L1027 bel
    old "This is something a lot of you have been asking me about!"
    new "این چیزیه که خیلی از شما از من پرسیده‌اید!"

    # say L1028 bel
    old "So I decided to treat you!"
    new "پس تصمیم گرفتم تو را مورد توجه قرار بدم!"

    # say L1029 bel
    old "This is my first time doing something like this on camera. So I'm a little nervous."
    new "این اولین باره که چیزی مثل این رو در مقابل دوربین انجام میدم. پس کمی ناراحت هستم."

    # say L1030 bel
    old "But I bet that if you show me your support by tipping, I'll feel a lot better."
    new "اما اگر با نقد حمایت کنی، حس خوبی می‌کنم."

    # say L1031 bel
    old "Now, do you want to see the surprise I have in store for you?"
    new "الان، می‌خوای دید مفاجاتی که برایت آماده کردم؟"

    # say L1033 bel
    old "This person is a very good friend of mine. And he's very excited to be joining me here in the stream today!"
    new "این شخص دوست خوبی از من هست. و او خیلی خوشحاله که امروز در این جریان با من هست!"

    # say L1034 bel
    old "Say hi to him!"
    new "به او سلام بگو!"

    # say L1039 bel
    old "Everyone, my friend is here because I promised you that you would see me having some fun with a real dick!"
    new "همه، دوست من اینجا هست چون به شما قول دادم که ببینید من با یک ناخن خوب چطور لذت می‌برم!"

    # say L1040 bel
    old "And he came to help me with it."
    new "و او اومده به من کمک کنه."

    # say L1041 bel
    old "Why don't we see what he's hiding under these shorts then?"
    new "چرا نبی‌بینیم اون چه چیزی رو زیر لباس کوتونی پوشونده؟"

    # say L1049 bel
    old "Oh my god! Look at how big it is!"
    new "اوه خدا! نگاه کن چقدر بزرگه!"

    # say L1050 bel
    old "I bet you want to see me play with this big dick, right?"
    new "بسته‌ای هستی که ببینی این پیپ بزرگ رو بازی می‌کنم، درسته؟"

    # say L1051 bel
    old "You want me to care for it, and play with it, don't you?"
    new "می‌خوای از این مراقبت کنم و باش بازی کنم، نه؟"

    # say L1052 bel
    old "Let's not wait anymore for it then!"
    new "پس بیاین دیگه منتظر نباشیم"

    # say L1059 bel
    old "Oh! You have been waiting to see me play with your dick, haven't you?"
    new "اوه! اینجوری منتظر بودی تا من با نونت بازی کنم، هستی؟"

    # say L1060 bel
    old "I bet you love the way I stroke your big, thick, dick!"
    new "مطمئنم دوست داری راهی که با نون بزرگت و ضخیم بازی می‌کنم!"

    # say L1072 bel
    old "I knew you were going to love what I had in store for you!"
    new "میدونستم که خوشت میاد از چیزایی که برایت آماده کردم!"

    # say L1073 bel
    old "Thanks a lot for accomplishing the goals!"
    new "ممنون ازتون که اهداف رو تکمیل کردین!"

    # say L1074 bel
    old "You guys have made me very happy!"
    new "شماها منو خیلی خوشحال کردید!"

    # say L1075 bel
    old "Now, sadly is time for me to disconnect, but be sure I'll come back soon."
    new "البته، حالا متاسفانه وقت قطع ارتباط من رسیده، اما مطمئن باشید که زودی برگشتم."

    # say L1076 bel
    old "And, of course, my friend will be here, accompanying us once again."
    new "و البته، دوست من هم اینجا خواهد بود، دوباره همراه ما."

    # say L1077 bel
    old "Don't forget to subscribe to the stream!"
    new "فراموش نکنید که به استریم اشتراک بگذارید!"

    # say L1078 bel
    old "So you will get a notification the next time I'm online guys!"
    new "پس هر بار که آنلاینم اعلان دریافت می‌کنید بچه‌ها!"

    # say L1079 bel
    old "And of course, don't forget to check all my socials!"
    new "و البته، فراموش نکنید همه شبکه‌های اجتماعی من رو بررسی کنید!"

    # say L1080 bel
    old "Thanks a lot guys!"
    new "ممنونم بچه‌ها!"

    # say L1081 bel
    old "See you soon..."
    new "به زودی می‌بینیم..."

    # say L1091 bel
    old "It's amazing how many tips we got!"
    new "الان شگفت‌زده‌ام از تعداد نکاتی که گرفتم!"

    # say L1092 bel
    old "I already thought that we were going to do well because my fans had never seen me doing something like this."
    new "من قبلاً فکر می‌کردم خوب می‌کنیم چون طرفدارانم هیچ وقت من رو همچین کاری ندیده بودند."

    # say L1094 bel
    old "But this is far more than I expected!"
    new "اما این خیلی بیشتر از آنچه انتظار داشتم است!"

    # say L1095 bel
    old "They really came through with the tipping!"
    new "وای، واقعاً با این نکات آنها خوب کمک کردند!"

    # say L1096 bel
    old "We reached the goal in no time!"
    new "هدف رو تو زمان کوتاهی رسیدیم!"

    # say L1098 pla
    old "I'm very happy that it all came out better than you expected Belle."
    new "خوشحالم که همه بهتر از آنچه تو انتظار داشتی، پیش رفت بعل."

    # say L1100 pla
    old "That's very good."
    new "این خیلی خوبه."

    # say L1101 pla
    old "Do you think that with this you'll surpass Lana in the voting?"
    new "فکر می‌کنی با این لانا رو پیشی بگیری در رای‌گیری؟"

    # say L1102 bel
    old "It's hard to tell, I think I will."
    new "خیلی سخته، ولی فکر کنم بله."

    # say L1103 bel
    old "But only temporarily, with this type of thing you never know for certain who's going to win until the end."
    new "ولی فقط موقتی، با این نوع چیزها هرگز نمی‌تونی به حتم بگی کی برنده می‌شه تا آخر."

    # say L1105 pla
    old "Does that mean you're going to need my help on another occasion?"
    new "این بمعنی اینه که باید دوباره از من کمک بگیری؟"

    # say L1107 bel
    old "Oh, don't doubt it! This is only the first time you're appearing on camera with me."
    new "اوه، این را شک نکن! این فقط اولین باره که تو با من در تصویر ظاهر می‌شوی."

    # say L1109 bel
    old "And I'm very thankful for that [pla]."
    new "و برای این خوشحالم [pla]."

    # say L1111 pla
    old "Well, I'm happy to help."
    new "البته، خوشحالم که کمک می‌کنم."

    # say L1113 bel
    old "Thanks [pla]."
    new "ممنون [pla]."

    # say L1123 pla
    old "{i}W- what is she doing here?! Wasn't she going to be out today?!{/i}"
    new "{i}- اینجا چیکار می‌کنه؟ نبودی می‌گفت امروز خارج می‌شه؟!{/i}"

    # say L1125 bel
    old "{i}I don't know!{/i}"
    new "{i}من نمی‌دونم!{/i}"

    # say L1134 bel
    old "I'm here mom! I... I was just doing some schoolwork!"
    new "من اینجا هستم مامان! من... من فقط کار درسی داشتم!"

    # say L1135 ash
    old "I see honey, ok!"
    new "ببین هنری، خوب!"

    # say L1137 bel
    old "I think we better get dressed up and get out of here before she comes to check on me and sees us like this."
    new "باید پوشیمون رو تغییر بدیم و از اینجا بیرون بریم قبل از اینکه مامان بیاد برایم چک کنه و ما رو اینجور ببینه."

    # say L1138 pla
    old "Yeah, yeah, you're right."
    new "بله، بله، درست می‌گی‌ی."

    # say L1151 ash
    old "Oh [pla], hi, I didn't know you were here."
    new "اوه ز[pla]، سلام، نمی‌دونستم تو اینجا هستی."

    # say L1152 pla
    old "H- hi, uh... A- Ashley."
    new "ه- هی، اوه... آ- آشلی."

    # say L1154 ash
    old "It's good seeing you again dear."
    new "خوشحالم که دوباره دیدت، عزیزم."

    # say L1155 ash
    old "Are you guys working on that school work you told me about?"
    new "شما دارید روی آن تکلیف مدرسه کار می‌کنید که به من گفتی؟"

    # say L1157 pla
    old "Uh... y- yeah, t- that's right."
    new "آه... بله، همین‌جوری."

    # say L1160 bel
    old "What are you doing home mom? I thought you had that important meeting you had talked about."
    new "مامان، چطور اومدی خونه؟ فکر کردم اون جلسه مهمی داشتی که در موردش حرف زده بودی."

    # say L1163 ash
    old "Oh honey, you won't believe what just happened!"
    new "اوه عزیزم، نمی‌تونی باور کنی چه چیزی فقط اومد اتفاق بیفته!"

    # say L1166 ash
    old "Today was supposed to be my first planning meeting with my team."
    new "امروز باید اولین جلسه برنامه‌ریزی من با تیم بود."

    # say L1167 ash
    old "You know, so we could make a marketing plan to show our clients."
    new "می‌خواستیم برنامه‌ی بازاریابی برای مشتریانمون طراحی کنیم."

    # say L1170 ash
    old "But the web developer I had hired suddenly backed out of the deal!"
    new "اما توسعه‌دهنده وبی که استخدام کردم ناگهان از قرار خودش برداشت!"

    # say L1173 ash
    old "Apparently he got a better job offer, and decided to take it."
    new "به نظر می‌رسه پیشنهاد شغلی بهتری دریافت کرده و تصمیم گرفت به آن بپردازد."

    # say L1174 ash
    old "But he didn't even give me a heads up or anything, he just bailed without notice!"
    new "ولی هیچ اطلاعی به من نداد، فقط بدون هیچ اعلانی رفت!"

    # say L1176 ash
    old "What am I going to do now?"
    new "الان من چی کار می‌کنم؟"

    # say L1177 bel
    old "Can't you just replace him, mom? I'm sure there must be someone out there that you can hire."
    new "نمی‌تونی جایش رو بگیری، مامان؟ حتماً باید کسی هست که می‌تونی ازش استخدام کنی."

    # say L1179 ash
    old "If it was that easy I wouldn't have a problem."
    new "اگه اینقدر ساده بود مشکلم نبود."

    # say L1180 ash
    old "Getting that web developer wasn't easy."
    new "یافتن اون توسعه‌دهنده وب آسون نبود."

    # say L1182 ash
    old "You know my firm is only setting up here in town, so we can't actually offer anybody long-term contracts."
    new "می‌دونی شرکتمون هنوز جدید در شهر هست، پس نمی‌تونیم قرارداد بلندمدت به هیچ کس بدهیم."

    # say L1184 ash
    old "Finding somebody qualified that's willing to freelance for a while is very hard."
    new "یافتن کسی ماهر که تمایل داشته باشه برای مدتی آزادکار کار کنه خیلی سخته."

    # say L1185 ash
    old "But we already took the commission, and my bosses are expecting me to show them a marketing plan soon!"
    new "اما ما قبلاً هزینه را دریافت کردیم و رئیسان من منتظر هستند که به زودی یک طرح بازاریابی به آنها نشان بدهم!"

    # say L1187 ash
    old "Tell me dear, do you know of anybody that could help me?"
    new "بگو عزیزم، آیا کسی می‌شناسی که بتونه به من کمک کنه؟"

    # say L1188 bel
    old "Me? Why would I happen to know someone who is a web developer?"
    new "من؟ چرا باید شخصی که توسعه‌دهنده وب هست را بشنم؟"

    # say L1190 ash
    old "I don't know, maybe someone from your school?"
    new "نمی‌دونم، شاید کسی از مدرسه‌ت بشه کمک کرد؟"

    # say L1192 bel
    old "Well, I'm sorry to disappoint you, mom, but I don't know any web developers..."
    new "خب، متاسفم که این خبر رو به تو بدهم، مامان، ولی من هیچ توسعه‌دهنده وبی نمی‌شناسم..."

    # say L1194 ash
    old "I see... that's disappointing."
    new "می‌بینم... این خبر ناراحت کننده."

    # say L1207 bel
    old "MOM! What are you talking about? Don't rope him into this!"
    new "مامان! داری در مورد چی حرف می‌زنی؟ نباید اونو به این موضوع جذب کنی!"

    # say L1209 ash
    old "Well honey, I'm sorry if you don't like me asking your friend for help."
    new "خوب عزیزم، متاسفم اگر از اینکه از دوستت کمک می‌خواهم خوشحالم نیستی."

    # say L1212 ash
    old "But I'm in a very thought spot right now, I need whatever help I can get."
    new "اما الان من در موقعیت خیلی سختی هستم، هر نوع کمکی که بتوانم بگیرم، می‌خواهم."

    # say L1214 ash
    old "So, do you know of anybody that could help me [pla]?"
    new "پس، آیا کسی می‌شناسی که بتواند به من کمک کنه [pla]؟"

    # say L1217 pla
    old "Well... Actually, I- I think that... Maybe I could help"
    new "خب... در واقع، من- من فکر می‌کنم که... شاید بتونم کمکت کنم"

    # say L1219 ash
    old "Really? Are you a web developer?"
    new "وای، تو توسعه‌دهنده وب هستی؟"

    # say L1222 pla
    old "Well, I'm not a professional, but I have a little bit of experience."
    new "خب، من حرفه‌ای نیستم، اما تجربه کمی دارم."

    # say L1224 pla
    old "My [sisrel] has an online clothing store."
    new "مای ز[sisrel] یک فروشگاه لباس آنلاین داره."

    # say L1226 pla
    old "When she was getting started I was the one who set up the e-commerce for her."
    new "وقتی شروع کرد، من همین من بودم که فروشگاه آنلاینشو تنظیم کردم."

    # say L1227 pla
    old "And... I have been doing the maintenance ever since."
    new "و... از آن زمان هم همیشه من تعمیراتش رو انجام میدم."

    # say L1230 ash
    old "And you think you could help me with this?"
    new "و فکر می‌کنی می‌تونی به من کمک کنی؟"

    # say L1232 pla
    old "W- well, I think so, I would have to see first what it is that you need me to do, though."
    new "خب، فکر کنم بشه، ولی اول باید ببینم دقیقاً چه کاری از من می‌خوای."

    # say L1234 ash
    old "That's wonderful [pla]! Oh my God! I would love it if you could help me."
    new "این عالیه [pla]! خدا می‌دونم! خوشحالم اگه بتونی به من کمک کنی."

    # say L1236 ash
    old "Maybe asking you to do the whole website right now would be too much."
    new "شاید الان از تو خواستن که کل وب‌سایت رو انجام بدی زیاد باشه."

    # say L1238 ash
    old "But I think you could help me with the planning of it, while I find a web developer to hire."
    new "اما فکر می‌کنم می‌تونی به من در برنامه‌ریزیش کمک کنی، همین حالا که دنبال توسعه‌دهنده وبی می‌گردم."

    # say L1240 ash
    old "It would only be a few times that I would need your help with the planning."
    new "فقط چند بار به کمکت در برنامه‌ریزی نیاز دارم."

    # say L1242 pla
    old "Hmm... Sure, I think I could do that."
    new "Hmm... بله، فکر کنم بتونم این کار رو بکنم."

    # say L1244 ash
    old "That's great!"
    new "عالی است!"

    # say L1245 ash
    old "And don't worry, I'll make sure you get properly compensated for it. I can add the cost to the budget."
    new "و نگران نباش، مطمئن می‌شوم که به درستی هزینه‌ات را جبران کنم. می‌تونم هزینه رو به بودجه اضافه کنم."

    # say L1246 ash
    old "So, there shouldn't be any problem with your pay."
    new "پس، مشکلی برای حقوقت نباید باشه."

    # say L1248 pla
    old "I- I see... So, s- should I come to your office later?"
    new "ب-بینم... پس، ب-باید بعداً به دفترت برم؟"

    # say L1250 ash
    old "Actually, I'm not sure if that would be a good idea because I wouldn't want the firm's directors to know about this."
    new "در واقع، نمی‌دونم این خوبه یا نه، چون نمی‌خوام مدیران شرکت از این باخبر بشن."

    # say L1252 ash
    old "I think it's better if we just work here at home."
    new "فکر می‌کنم بهتره که فقط اینجا در خونه کار کنیم."

    # say L1257 ash
    old "You're really helping me with this [pla], a lot! You have no idea about how useful you're being!"
    new "تو واقعاً به من در این زمینه کمک زیادی می‌کنی [pla]! نمی‌دونی چقدر مفیدی هستی!"

    # say L1258 ash
    old "Now, I left some documents that you'll need in the office, I'll go and grab them."
    new "الان، من برخی اسنادی که بهش نیاز داری در دفتر گذاشتم، برم می‌روم و می‌آورم."

    # say L1259 ash
    old "But don't worry, we won't be starting right away, you can come back on another occasion and I'll let you know what the job is about."
    new "ولی نگران نباش، ما همین الان شروع نمی‌کنیم، می‌تونی دفعه‌ی بعد بیاد و من بهت می‌گم کار چیه."

    # say L1261 pla
    old "Alright, I'll be sure to do it."
    new "باشه، حتماً انجام می‌دم."

    # say L1262 ash
    old "Great, see you later then [pla]."
    new "عالی، تا بعدی می‌بینیم [pla]."

    # say L1270 bel
    old "I can't believe you're actually going to help her with that."
    new "من نمی‌تونم باور کنم واقعاً قراره بهش در این موضوع کمک کنی."

    # say L1272 bel
    old "Don't you think that's going to get in the way of us doing the stream?"
    new "آیا فکر می‌کنی این کار مانع بشه ما استریم رو انجام بدیم؟"

    # say L1274 pla
    old "In fact, I think it's convenient for us because since she needs me to work here, we'll know more accurately when she will be here and when she won't."
    new "در واقع فکر می‌کنم برای ما مفیده، چون از این جا می‌دونیم دقیق‌تر وقتی که اینجا هست و وقتی که نیست."

    # say L1277 bel
    old "But still, I'm sorry my mom is putting you up to this."
    new "ولی هنوز، خیلی متاسفم که مامان تو رو به این کار مجبور کرده."

    # say L1279 pla
    old "Don't worry about it, I'm happy to help."
    new "نگران نباش، خوشحالم که کمک می‌کنم."

    # say L1280 bel
    old "Yeah, I know."
    new "بله، می‌دونم."

    # say L1281 bel
    old "You're being very nice helping both my mom and me like this."
    new "تو خیلی لطف داری که هم مامانم و هم من رو اینجور کمک می‌کنی."

    # say L1282 bel
    old "That's very good of you [pla]."
    new "این برایت خیلی خوبه [pla]."

    # say L1284 pla
    old "Thanks for saying that."
    new "ممنون از این که اینجوری گفتی."

    # say L1291 pla
    old "Hey, so I think I should get going, after all, we just finished streaming, I bet you want to take a shower or something."
    new "بله، خب من فکر می‌کنم باید برسم، در نهایت فقط جلسه‌ی استریم ما تمام شد، حدس می‌زنم می‌خوای از حمام برم یا چیزی."

    # say L1293 bel
    old "Uhh, yeah, sure, I'll let you know when we have to stream the next time, thanks again [pla]."
    new "اوه، بله، حتماً، هنگامی که باید دوباره استریم کنیم اطلاع می‌دم، ممنون دوباره [pla]."

    # say L1295 pla
    old "Sure, see you later, bye."
    new "باشه، خداحافظ."

    # say L1325 bel
    old "Hi [pla]! I have great news!"
    new "سلام [pla]! خبر خوبی دارم!"

    # say L1328 bel
    old "The poll results from yesterday came out this morning!"
    new "نتایج رأی‌گیری دیروز امروز صبح منتشر شدند!"

    # say L1332 bel
    old "I'm number one now!"
    new "من الان شماره یک هستم!"

    # say L1334 pla
    old "That's great belle!"
    new "این خبر عالیه بل!"

    # say L1335 pla
    old "I'm very happy for you."
    new "خوشحالم برای تو، بله."

    # say L1337 bel
    old "Thanks, this is wonderful!"
    new "ممنون، این خیلی عالیه!"

    # say L1339 bel
    old "She's been appearing with a guy on stream for longer, so I didn't know if I would be able to catch her with just one stream."
    new "او از قبل با یه دستا در استریم ظاهر می‌شد، پس نمی‌دونستم آیا بتونم فقط با یه استریم او رو جذب کنم."

    # say L1341 bel
    old "But my fans really liked it!"
    new "ولی مراقبان واقعاً لذت بردن!"

    # say L1343 bel
    old "If we keep going like this, she won't have any chance of catching me!"
    new "اگه همچین جوری ادامه بده، هیچ شانسی برای اینکه من رو بگیره نداره!"

    # say L1345 pla
    old "That sounds great."
    new "این خوبه."

    # say L1348 pla
    old "So, when it's the next stream?"
    new "پس، وقت اجرای جریان بعدی چیه؟"

    # say L1349 bel
    old "Well, that's where we have a little bit of a problem."
    new "خب، اینجا که مشکل کوچیکی پیش آمده."

    # say L1350 pla
    old "Why? What happened?"
    new "چرا؟ چه اتفاقی افتاد؟"

    # say L1352 bel
    old "You see, I had already thought about what we're going to do next."
    new "ببین، من قبلاً فکر کرده بودم در مورد اینکه بعداً چه کاری بکنیم."

    # say L1353 bel
    old "My fans have been asking for me to do cosplay for a while, so I thought now it would be a good occasion."
    new "خواننده‌هایم از زمانی دنبال می‌آیند که من کسپلی کنم، پس فکر کردم حالا موقعیت خوبی برای این کار است."

    # say L1354 pla
    old "Cosplay?"
    new "کسپلی؟"

    # say L1356 bel
    old "Yes, we can't just repeat the same as last time."
    new "بله، نمی‌تونیم همون چیزی رو دوباره تکرار کنیم."

    # say L1357 bel
    old "If we just do the same thing over and over the audience will get bored."
    new "اگر همیشه همین کار رو تکرار کنیم مخاطبان خسته می‌شنند."

    # say L1358 bel
    old "We have to give them some variety."
    new "باید بهشون تنوعی بدیم."

    # say L1362 bel
    old "But you see, I don't know when the next stream will be."
    new "اما می‌بینی، من نمی‌دونم بعداً چه موقع استریم می‌کنیم."

    # say L1363 bel
    old "I already know what character I want to do."
    new "من قبلاً می‌دونم که کدام شخصیت رو می‌خوام انجام بدم."

    # say L1364 bel
    old "It's somewhat of an interesting character, and my fans seem to have a fixation for that type of girl."
    new "این نوع شخصیت جالبیه، و معجبانم به این نوع دختر علاقه‌مندند."

    # say L1365 bel
    old "So I wanted to please them, I even ordered for the cosplay to be delivered by express shipping."
    new "پس خواستم اونا رو خوشحال کنم، حتی برای لباس نقش‌آفرینی تحویل سریع سفارش دادم."

    # say L1367 bel
    old "But it turns out there was a mixup when I placed my order, when I bought it they had alredy sold it!"
    new "ولی اتفاقاً وقتی سفارش دادم اشتباهی پیش اومد، وقتی خریدم قبلاً فروخته بودن!"

    # say L1368 bel
    old "And they don't seem to have any more!"
    new "و به نظر می‌رسه هیچ‌کس دیگه‌ای ندارن!"

    # say L1370 bel
    old "I have been looking for that same cosplay in other websites, but I can't find it!"
    new "من هم در وب‌سایت‌های دیگه به دنبال اون لباس نقش‌آفرینی گشتم، ولی پیدا نکردم!"

    # say L1371 bel
    old "And I already promised the audience that's the character I was going to do."
    new "و من قبلاً به مخاطبان قول دادم که همین شخصیت رو می‌کنم."

    # say L1372 bel
    old "I guess we'll have to postpone it for another time."
    new "باید به بعدش تعلیق بدم."

    # say L1374 bel
    old "Besides, you also have to go help my mom with that website thing..."
    new "البته، تو هم باید بروی به مامان کمک کنی با آن سایت..."

    # say L1376 bel
    old "Ugh, this annoys me so much, Lana's going to overtake me again!"
    new "اوه، این خیلی مزخرفه، لانا دوباره جلوی من می‌رسه!"

    # say L1378 pla
    old "Hmm, I might be able to do something about that. My [sisRel] has her own clothing store."
    new "Hmm، ممکنه کمکی کنم. ز[sisRel] خودشو فروشگاه لباس داره."

    # say L1380 pla
    old "So, I think maybe she can find that cosplay for you in time for the next stream."
    new "پس فکر می‌کنم ممکنه باشه اون لباس کاراکتر رو برای تو پیدا کنه تا برای استریم بعدی آماده باشه."

    # say L1382 bel
    old "Really? Oh [pla] that would be great!"
    new "حقاً؟ اوه [pla] خوب می‌شه!"

    # say L1384 pla
    old "Well, it's not certain, I'll have to ask, but I think it's possible."
    new "خب، اینجوری مشخص نیست، باید بپرسم، ولی فکر کنم امکان‌پذیره."

    # say L1385 bel
    old "If you could, that would be wonderful."
    new "اگر بتونی، خیلی عالی می‌شه."

    # say L1386 pla
    old "I'll ask with my [sisRel] this afternoon, after classes."
    new "امروز بعد از کلاس‌ها با [sisRel] من پرسش می‌کنم."

    # say L1387 pla
    old "And I'll let you know."
    new "و به تو می‌گم."

    # say L1388 bel
    old "Sure, thanks a lot [pla]."
    new "بله، ممنون زیادی [pla]."

    # say L1391 pla
    old "For now let's go to class."
    new "برای حالا برویم به کلاس."

    # say L1412 pla
    old "Hi [sis], how are you?"
    new "سلام ز[sis]، چطوری؟"

    # say L1413 sis
    old "I'm doing pretty well, working on a new collection."
    new "من خوب هستم، روی مجموعه‌ای جدید کار می‌کنم."

    # say L1414 pla
    old "Uhh, so are you busy?"
    new "اوه، پس مشغولی؟"

    # say L1415 sis
    old "Uhh a little bit, Why? What do you need?"
    new "می‌تونم کمی مشغول باشم، چرا؟ چی می‌خوای؟"

    # say L1417 pla
    old "Well, I was wondering if you could help me with getting a cosplay."
    new "خب، فکر می‌کردم می‌تونی به من کمک کنی تا یه کاسپل بگیرم."

    # say L1418 sis
    old "A cosplay? I didn't know you were into that kind of stuff..."
    new "یک کاسپلی؟ نمی‌دونستم تو به این جور چیز‌ها علاقه داری..."

    # say L1421 sis
    old "Anyway, what kind of cosplay is it? Like a superhero or something?"
    new "بازی‌ای چه کیه؟ مثل یه سوپر هیرو یا چیزی؟"

    # say L1423 pla
    old "Uhh, it's actually a female cosplay, it's a famous character from a videogame."
    new "اوه، در واقع کاسپلای زنیه، یه شخصیت مشهور از یه بازی ویدیوییه."

    # say L1424 sis
    old "A female cosplay? Why do you need that?"
    new "کوسپلای زن؟ چرا به این نیاز داری؟"

    # say L1426 sis
    old "Don't tell me you're thinking of becoming a drag queen."
    new "نمی‌گویی قراره تا به یک دراگ کوئن تبدیل شی؟"

    # say L1428 pla
    old "W- what? Of course not!"
    new "و- وای! البته نه!"

    # say L1430 pla
    old "It's for a friend of mine that needs it."
    new "این برای یه دوستم هست که بهش نیاز داره."

    # say L1432 sis
    old "Oh! Is that so? And why are you getting it for her? Are you two doing something naughty?"
    new "اوه! همینه؟ و چرا برایش می‌گیری؟ آیا شما دو تا کار خلافی دارید؟"

    # say L1434 pla
    old "N- no, we're not, I'm just doing her a favor because she needs it. That's all."
    new "نه، ما نه، فقط به اون کمک می‌کنم چون نیاز داره. همین هست."

    # say L1436 sis
    old "Haha! Relax, I'm just messing with you."
    new "هahaha! آرامش بکن، فقط با تو مزح زدم."

    # say L1438 sis
    old "I don't mind what you're doing with your friend."
    new "من به چی که با دوستت می‌کنی اهمیت نمی‌ذaram."

    # say L1439 sis
    old "As long as you keep helping me with my business, you can do whatever you want."
    new "مادامی که به من در کسب و کارت کمک می‌کنی، می‌تونی هر کاری که می‌خوای بکنی."

    # say L1441 sis
    old "I'll get you the cosplay, it should be easy to get it here soon."
    new "من برایت لباس کاسپلی رو می‌آورم، باید زود اینجا باشه."

    # say L1442 pla
    old "Thanks a lot [sis]!"
    new "ممنون زیادی [sis]!"

    # say L1444 sis
    old "I'm happy to help."
    new "خوشحالم که کمکت کنم."

    # say L1445 sis
    old "I'll let you know when it's ready."
    new "وقتی آماده شد به تو می‌گم."

    # say L1469 ash
    old "Hello [pla]! How are you dear?"
    new "سلام ز[pla]! حالت چطوره عزیزم؟"

    # say L1470 pla
    old "Hi Mrs. Ash-"
    new "سلام آشلی، چطوری؟"

    # say L1472 ash
    old "Just Ashley dear, remember what I told you, no need for the Mrs."
    new "اشلی عزیزم، به خاطر داشتی آنچه به تو گفتم، نیازی به مادام نیست."

    # say L1473 pla
    old "Uhh... Right."
    new "اوه... درست است."

    # say L1474 pla
    old "Hi A- Ashley."
    new "سلام آ- آشلی."

    # say L1476 ash
    old "That's better."
    new "این بهتره."

    # say L1477 ash
    old "How have you been honey?"
    new "حالت چطوره عزیزم؟"

    # say L1479 ash
    old "Is school going well?"
    new "مدرسه خوب می‌ره؟"

    # say L1481 pla
    old "Uhh? Y- yeah. I- I have been studying a lot..."
    new "اوه؟ ه- همین‌جوری. م- من خیلی مطالعه کردم..."

    # say L1482 ash
    old "That's great dear."
    new "عالیه عزیزم."

    # say L1484 pla
    old "Uh... Listen, A- Ashley, about the w- website."
    new "اوه... اسمع، اشلی، در مورد سایت."

    # say L1486 ash
    old "Right! We should focus on that."
    new "بله! باید روی اون تمرکز کنیم."

    # say L1488 pla
    old "Sure ma'am. But I'm not entirely sure what it is that I will be doing."
    new "بله خانم. اما من کاملاً مطمئن نیستم که چه کاری باید انجام بدم."

    # say L1490 ash
    old "Well, before that, I would like to see the e-commerce site you told me you made for your [sisrel]."
    new "خب، قبل از همه، من می‌خوام سایت تجارت الکترونیکی رو ببینم که تو گفتی برای ز[sisrel] ساختی."

    # say L1491 ash
    old "To see what type of thing you've done before. Would you like to use my computer?"
    new "برای اینکه ببینم چه نوع کاری قبلاً انجام دادی. می‌خوای از کامپیوتر من استفاده کنی؟"

    # say L1493 pla
    old "Uh... Sure, no problem."
    new "آش، حتماً، هیچ اشکالی ندارم."

    # say L1503 pla
    old "So, this is the site where you can see the apparel that my [sisrel] sells."
    new "پس، این سایتیه که می‌تونی اشیای رو که ز[sisrel] فروش می‌کنه ببینی."

    # say L1504 pla
    old "And if you click here you can place an order."
    new "و اگر اینجا کلیک کنی، می‌تونی سفارش بدی."

    # say L1505 pla
    old "Then, it will take you to the payment portal. And there you can finalize the purchase."
    new "بعد از این به درگاه پرداخت هدایت می‌شی. و اونجا می‌تونی خریدت رو تمام کنی."

    # say L1507 ash
    old "You know [pla]? This is very good."
    new "دیتون می‌دونی [pla]؟ این خیلی خوبه."

    # say L1508 ash
    old "This is very high quality, even better than the work some of the developers I've worked with before."
    new "این خیلی با کیفیت بالا است، حتی بهتر از کار برخی از توسعه‌دهندگانی که قبلاً با آنها همکاری کردم."

    # say L1509 ash
    old "Actually, this is more than what I need you to do."
    new "این بیشتر از آنچه برام انجام بدی می‌تونی."

    # say L1512 ash
    old "After seeing this, I'm thinking that you could just take the full job of developing the website for the client."
    new "بعد از دیدن این، فکر می‌کنم می‌تونی فقط کار توسعه وب‌سایت برای مشتری رو بگیری."

    # say L1516 ash
    old "Come on, why are you surprised? You did a very good job with this website."
    new "بیا، چرا تعجب می‌کنی؟ تو با این وب‌سایت کار خوبی انجام دادی."

    # say L1518 ash
    old "And as I told you, this is even more than what I need to be done for the marketing campaign."
    new "و همانطور که به تو گفتم، این حتی بیشتر از آنچه برای کمپین بازاریابی لازم دارم است."

    # say L1519 ash
    old "You could just do the job by yourself."
    new "تو می‌تونی خودت این کار رو انجام بدی."

    # say L1521 ash
    old "And It would really help me, because I wouldn't have to look for someone to finish the project."
    new "و این برای من خیلی مفید می‌شه، چون نمی‌تونم به دنبال کسی برای تمام کردن پروژه بگردم."

    # say L1522 pla
    old "I mean, that's a very nice offer, uh... Ashley, b- but I'm not sure if I have the experience to do it."
    new "من قصدم اینه، پیشنهاد خیلی لطف داری، اشلی، اما مطمئن نیستم تجربه کافی برای انجام این کار رو دارم."

    # say L1523 pla
    old "It would be a lot of responsability."
    new "این خیلی مسئولیت زیادی هست."

    # say L1525 ash
    old "Don't worry about it, dear. I'll accompany you every time you work on it, so I'll tell you exactly what I need from you."
    new "با این نگرانی نباش، عزیزم. هر بار که رویش کار می‌کنی من همراه تو خواهم بود، پس دقیقاً می‌گم چه چیزی ازت نیاز دارم."

    # say L1529 pla
    old "Alright, if you think it's ok for me to do it, I guess I can take the job."
    new "البته، اگر تو فکر می‌کنی من می‌تونم این کار رو انجام بدم، حدس می‌زنم می‌تونم این کار رو بپذیرم."

    # say L1531 ash
    old "Great! That's just what I wanted to hear."
    new "عالی! همین حرفی بود که می‌خواستم بشنوم."

    # say L1533 pla
    old "Ok, but what exactly is the type of website that I'm going to be working on? Is it an e-commerce?"
    new "خب، ولی این وب‌سایت دقیقاً چه نوعی هست؟ آیا یک فروشگاه آنلاین هست؟"

    # say L1534 ash
    old "Not really, what I need you to make is one where we can show a lot of information about a business."
    new "نه، آنچه نیاز دارم تو بسازی، یک وب‌سایتی هست که بتوانیم اطلاعات زیادی در مورد یک کسب و کار نشون بدیم."

    # say L1535 ash
    old "The business in question is an organic coffee shop that's gotten very popular here in the city."
    new "بازار این کافه ارگانیکی هست که خیلی محبوب شده در شهر."

    # say L1536 ash
    old "And they're looking to expand their business by franchising outside of town."
    new "و آنها قصد دارن کسب و کار خود رو با افتتاح شعبه‌های جدید در شهرهای دیگر توسعه بدند."

    # say L1537 pla
    old "I see. So they hired you to do their marketing campaign?"
    new "من متوجه شدم. پس اونا تو رو استخدام کردن تا کمپین بازاریابیشون رو انجام بدی؟"

    # say L1539 ash
    old "Not me, my marketing firm. I'm just leading my team."
    new "نه من، شرکت تبلیغاتی من. من فقط تیم خودم رو رهبری می‌کنم."

    # say L1541 ash
    old "But, I still have the responsibility for the entire marketing plan."
    new "ولی هنوز مسئولیت کل طرح بازاریابی رو دارم."

    # say L1543 ash
    old "Because the clients already paid for the service, and I already received the budget."
    new "چون مشتریان قبلاً هزینه را پرداخت کرده‌اند و من هم قبلاً بودجه را دریافت کردم."

    # say L1545 ash
    old "That's why it's so bad that the web developer quit all of a sudden. Because he put me in a very difficult position."
    new "به همین خاطر بد است که توسعه‌دهنده وب از یک لحظه به بعد کار را ترک کرد. زیرا او منو به وضعیت بسیار سختی انداخت."

    # say L1547 pla
    old "I understand, I'm sorry that happened."
    new "من متوجه هستم، متاسفم که اینجوری شد."

    # say L1549 ash
    old "That's very nice of you dear, thank you."
    new "این خیلی لطف داری عزیزم، ممنون."

    # say L1550 ash
    old "Now, why don't we get started and I'll tell you what to do along the way?"
    new "الان، چرا ما شروع نکنیم و من در مسیرت هدایتت کنم؟"

    # say L1562 ash
    old "Ok, now please put the title in higher case."
    new "خب، حالا لطفاً عنوان رو با حروف بزرگ بنویس."

    # say L1564 ash
    old "That's it, perfect. Could you also make those pictures a little bigger?"
    new "این هم خوبه، کامل. می‌تونی عکس‌ها رو هم بیشتر بزرگ کنی؟"

    # say L1565 ash
    old "I want the raw coffee shots to be front and center."
    new "می‌خوام عکس‌های قهوه خام رو در مرکز قرار بدم."

    # say L1567 pla
    old "Ok, is that because of their brand?"
    new "بله، این به خاطر برندشون هست؟"

    # say L1569 ash
    old "That's right, they want to show themselves as an organic coffee business, that's a contrast to the bigger coffee chains you see everywhere."
    new "درست می‌فرمایی، آنها می‌خواهند خود را به عنوان یک کسب و کار قهوه ارگانیک نشان دهند، این یک تضاد با زنجیره‌های بزرگ قهوه است که همه جا می‌بینی."

    # say L1570 pla
    old "I see, I think I get it."
    new "می‌فهمم، فکر کنم درست گرفتم."

    # say L1574 ash
    old "Well, the whole point of marketing is developing and delivering the message the client wants to show."
    new "خب، هدف بازاریابی اینه که پیامی که مشتری می‌خواد نشون بده رو توسعه بدیم و ارائه کنیم."

    # say L1575 ash
    old "So, I really enjoy the process of using optics and messaging to find good ways to attract attention to our clients."
    new "پس من واقعاً لذت می‌برم از این کار، استفاده از تصویرسازی و پیام‌دهی برای یافتن راه‌های خوبی برای جلب توجه به مشتریانمون."

    # say L1576 pla
    old "That's really cool Ashley."
    new "ایشلی، این خیلی جالبه."

    # say L1577 ash
    old "Thanks dear..."
    new "ممنون عزیزم..."

    # say L1578 ash
    old "Now, let's keep going."
    new "الان، بیاین ادامه بدیم."

    # say L1590 ash
    old "Yes! That's exactly what I wanted!"
    new "بله! همین هست که می‌خواستم!"

    # say L1591 ash
    old "You're really good at this [pla], I can't believe you thought you wouldn't do it properly."
    new "تو واقعاً در این کار خوبی داری [pla]، نمی‌تونم باور کنم فکر کردی نمی‌تونی درست انجام بدی."

    # say L1593 pla
    old "T- Thank you, Ashley, I hope your bosses will like it too."
    new "ممنون، اشلی، امیدوارم رئیسانت هم خوشحال بشن."

    # say L1594 ash
    old "I'm sure they will, this is turning out better than what I expected."
    new "مطمئنم خواهند پسندید، این بهتر از آنچه منتظرش بودم شکل می‌گیره."

    # say L1595 ash
    old "Actually, I think you've done enough for today."
    new "در واقع فکر می‌کنم برای امروز کار کافی کردی."

    # say L1596 ash
    old "Why don't we stop and continue another day?"
    new "چرا ما امروز متوقف شویم و روز دیگر ادامه بدیم؟"

    # say L1605 ash
    old "You're very good at this [pla], I think that with your help we will have this ready in no time."
    new "تو خیلی خوب در این هستی [pla]، فکر می‌کنم با کمکت این کار رو زودتر از آنی که فکر می‌کردم تمام می‌شه."

    # say L1606 pla
    old "Thanks ma'am, I'm sure we will."
    new "ممنون مام، مطمئنم که خواهیم کرد."

    # say L1608 pla
    old "So, I- I guess I should leave for know."
    new "پس، من- من فکر کنم باید حالا برسم."

    # say L1610 ash
    old "Wait, before you go, I wanted to ask you about how much time you have available to work on this."
    new "پیش از برخاستن، می‌خواستم بپرسم چقدر وقت خالی برای کار روی این پروژه داری."

    # say L1612 ash
    old "You're a student after all. I wouldn't want to use all of your time."
    new "البته تو دانشجو هستی. نمی‌خوام تمام وقتت رو ببرم."

    # say L1613 ash
    old "But if I'm honest, I could use your help as often as possible."
    new "ولی اگر صادقانه باشم، می‌تونم هر وقت که بشه از کمکت استفاده کنم."

    # say L1615 ash
    old "So, it occurs to me that you could tell me when it works best for you."
    new "پس به ذهنم رسید که می‌تونی به من بگی وقتی که برایت مناسبه."

    # say L1616 ash
    old "For us to work on the website."
    new "برای اینکه ما روی وب‌سایت کار کنیم."

    # say L1619 pla
    old "I- I guess I could come... Maybe every other day and work with you?"
    new "من- من فکر کنم می‌تونم بیام... شاید هر روزه یکی با تو کار کنم؟"

    # say L1621 ash
    old "That's just perfect for me!"
    new "این برای من کاملاً مناسبه!"

    # say L1622 pla
    old "Great, that's good to hear."
    new "عالی، خوشحالم که اینجوری شد."

    # say L1623 pla
    old "Alright, it's getting a bit late, so,I think I'll go home now, Ashley."
    new "باشه، وقت شده کمی دیر، فکر کنم برم خونه، اشلی."

    # say L1625 ash
    old "Sure dear, thanks again for your great help."
    new "بله عزیزم، ممنون از کمکت بزرگ."

    # say L1626 pla
    old "You're welcome, see you later."
    new "خواهش می‌کنم، ببینم بعداً."

    # say L1628 ash
    old "See you honey."
    new "ببینم تو هنوز."

    # say L1649 pla
    old "Hey [sis]."
    new "سلام ز[sis]."

    # say L1651 sis
    old "Listen, your cosplay has arrived."
    new "بله، لباس کاستوم‌تون رسیده."

    # say L1653 pla
    old "Really? It arrived this quickly? That's great!"
    new "وای، واقعاً اینقدر سریع رسید؟ خوبه!"

    # say L1654 sis
    old "Well, I have a direct contact, and they always send it via express delivery."
    new "خب، من رابطه مستقیمی دارم و همیشه اونا ارسال سریع می‌کنن."

    # say L1655 pla
    old "Oh, that's great."
    new "اوه، خوبه."

    # say L1656 sis
    old "Come with me, the package is in my bedroom."
    new "بیا با من، بسته در اتاق خوابم است."

    # say L1657 pla
    old "Oh, right."
    new "اوه، درست است."

    # say L1672 sis
    old "Wait here."
    new "اینجا منتظر بمان."

    # say L1685 sis
    old "Here it is."
    new "اینجا هست."

    # say L1687 sis
    old "I ordered it directly from a producer."
    new "من اینو مستقیم از تولیدکننده سفارش دادم."

    # say L1689 sis
    old "I knew that you needed it quickly, right?"
    new "می‌دونستم که نیازت بهش زود بود، درسته؟"

    # say L1693 pla
    old "This is great, thanks a lot."
    new "این عالیه، ممنون می‌کنم."

    # say L1694 sis
    old "Don't worry about it, I'm happy to help you."
    new "نگران نباش، خوشحالم که به تو کمک کردم."

    # say L1695 sis
    old "I hope your friend likes it."
    new "امیدوارم دوستت خوشش بیاد."

    # say L1696 pla
    old "I'm sure she will, thanks [sis]."
    new "مطمئنم خوشش می‌آید، ممنون [sis]."

    # say L1709 pla
    old "Hi belle, good morning."
    new "سلام بله، صبح بخیر."

    # say L1710 bel
    old "Hi [pla], how are you today?"
    new "سلام ز[pla]، امروز چطوری؟"

    # say L1714 pla
    old "Hey, listen, I got your cosplay!"
    new "بله، بله، من لباس کاراکترتو گرفتم!"

    # say L1716 bel
    old "Really? That's wonderful [pla]!"
    new "وای، عالیه [pla]!"

    # say L1717 pla
    old "Yeah, I received it this morning. Is your mom going to be home this afternoon? If not, I can bring it to your house so you can try it on."
    new "بله، این صبح دریافت کردم. مامانتون این هنگام خانه‌اش هست؟ اگه نه، می‌تونم به خونه‌تو برم آن رو برات ببرم تا امتحانش کنی."

    # say L1719 bel
    old "She won't be, so we can stream today as well!"
    new "مادرم خونه نیست، پس می‌تونیم امروز هم استریم کنیم."

    # say L1721 pla
    old "You want to stream right away?"
    new "می‌خوای همین حالا استریم کنی؟"

    # say L1722 bel
    old "Of course, we have to."
    new "البته، باید انجام بدیم."

    # say L1724 bel
    old "Lana has been putting up a lot of new content, I can't let any more time pass by."
    new "لانا محتوای جدید زیادی قرار داده، نمی‌تونم هیچ وقتی دیگه از دست ببرم."

    # say L1726 pla
    old "Yeah, you're right, I'll bring the cosplay after classes. Ok?"
    new "بله، درست می‌فرمایی، بعد از کلاس‌ها لباس نقش‌بازی رو می‌آورم. خوب؟"

    # say L1727 bel
    old "Yeah, perfect."
    new "بله، عالی."

    # say L1753 bel
    old "Ok, so you'll pick up the cosplay at your house and I'll set up the stream. Ok?"
    new "باشه، پس توی خونت لباس نقش‌بازی رو می‌بری و من جریان رو تنظیم می‌کنم. باشه؟"

    # say L1754 pla
    old "Sure, I'll be there right away."
    new "بله، همین الان می‌رم."

    # say L1770 pla
    old "Hey Belle, here it is."
    new "بelle، این هست."

    # say L1775 bel
    old "Great! Let's go up to my room and I'll try it on."
    new "عالی! بیای بریم بالا و من اون رو می‌ذارم."

    # say L1796 bel
    old "Ok, I'll put it on."
    new "باشه، می‌ذارم."

    # say L1808 bel
    old "So, what do you think?"
    new "پس، چطور به نظر می‌رسه؟"

    # say L1810 pla
    old "You look great Belle!"
    new "تو خیلی خوب هستی بله!"

    # say L1811 pla
    old "It really fits you."
    new "این واقعاً به تو خوب می‌آید."

    # say L1812 bel
    old "I'm happy you like it."
    new "خوشحالم که لایقش هستی."

    # say L1813 bel
    old "Let's get started with the stream then."
    new "پس بیاییم شروع کنیم."

    # say L1828 bel
    old "Ok guys, it's time for another good time!"
    new "خب دوستان، وقت برای یک لحظه خوب است!"

    # say L1829 bel
    old "What do you think of the cosplay that I prepared for you?"
    new "چه فکر می‌کنی از کاستوم پلی که برایت آماده کردم؟"

    # say L1830 bel
    old "I know you have been waiting to see me like this, so be sure to enjoy!"
    new "میدونم منتظر بودی تا من اینجوری بیام، پس حتماً لذت ببر!"

    # say L1831 bel
    old "But that's not all."
    new "اما این همه نیست."

    # say L1832 bel
    old "Since you guys liked to see my friend so much last time, I brought him here again!"
    new "چون خوشحالم که دوست داشتین دوستم رو ببینید، دوباره اومده‌ست!"

    # say L1833 bel
    old "So say hi to him again!"
    new "پس دوباره بهش سلام بده!"

    # say L1839 bel
    old "Ok, guys, let's not waste any more time."
    new "بیاین دوستان، دیگه وقت نبردیم."

    # say L1840 bel
    old "I know you've been waiting for it, so let's get to it."
    new "میدونم منتظرش بودی، پس بیاین بهش برسیم."

    # say L1847 bel
    old "OH! God! This cock!"
    new "اوه خدا! این پیشوند!"

    # say L1848 bel
    old "I love it! It's just the best taste in the world!"
    new "عشقی بهش دارم! بهترین طعم در جهانه!"

    # say L1849 bel
    old "Your dick is so big guys!"
    new "پیشوند شما خیلی بزرگه بچه‌ها!"

    # say L1861 bel
    old "I'm happy you enjoyed the stream and my cosplay!"
    new "خوشحالم که از استریم و کاسپلای من لذت برده‌ای!"

    # say L1862 bel
    old "After all, I'm doing this for all of you!"
    new "در نهایت، این همه برای شماست!"

    # say L1863 bel
    old "I'll end the stream here for now."
    new "اون جا، برای حالا این جریان رو تمام می‌کنم."

    # say L1864 bel
    old "But be sure that I'll come back soon."
    new "اما مطمئن باشید که زودی برگرم."

    # say L1865 bel
    old "As always, remember to subscribe to the stream."
    new "همیشه مثل همین، به یاد داشته باشید که به استریم اشتراک بگذارید."

    # say L1866 bel
    old "And you’ll be notified every time I’m online!"
    new "و هر بار که آنلاین شدم اطلاع داده می‌شی!"

    # say L1867 bel
    old "And of course, remember to check out my social media links!"
    new "و البته، به یاد داشته باشید که به لینک‌های اجتماعی من نگاه کنید!"

    # say L1868 bel
    old "Thans for your support guys!"
    new "ممنون از حمایتتون بچه‌ها!"

    # say L1869 bel
    old "See you later, bye!"
    new "ببینم بعد، خداحافظ!"

    # say L1879 bel
    old "I'm sure that with this, Lana will not have a chance to catch me!"
    new "مطمئنم با این، لانا هیچ شانسی برای دستگیر کردن من نداره!"

    # say L1881 pla
    old "Awesome!"
    new "عالی!"

    # say L1883 pla
    old "After all you've worked really hard for this."
    new "البته، تو برای این کار واقعاً سخت کار کردی."

    # say L1887 pla
    old "I think I'll head back home before your mother arrives."
    new "فکر کنم برم خونه قبل از اینکه مامانت بیاد."

    # say L1888 bel
    old "Alright, I'll let you know how the voting goes tomorrow."
    new "البته، فردا از رای‌گیری خبر می‌دم."

    # say L1889 pla
    old "Sure, I'm sure it's going to go great."
    new "بله، مطمئنم خوب می‌رهد."

    # say L1906 pla
    old "Hi, Ashley, I'm fine thank you."
    new "سلام اشلی، خوبم ممنون."

    # say L1907 ash
    old "That's good, tell me, is there anything I can help you with?"
    new "این خوبه، بگو، آیا چیزی هست که بتونم به تو کمک کنم؟"

    # say L1915 pla
    old "Well, I was thinking that I could keep helping you with developing the website."
    new "خب، فکر می‌کنم می‌تونم به تو در توسعه وب‌سایت کمک کنم."

    # say L1916 ash
    old "That would be great [pla]!"
    new "این عالیه [pla]!"

    # say L1917 ash
    old "Ok, wait here a minute and I'll get everything ready."
    new "بیا، صبر کن یه لحظه و من همه چی رو آماده می‌کنم."

    # say L1926 pla
    old "Oh, not much, I was just passing by."
    new "اوه، خیلی کم، فقط داشتم اینجا می‌گذرم."

    # say L1929 ash
    old "Please remember to come work on the website project soon. The deadline is coming soon."
    new "لطفاً به زودی برای کار روی پروژه وب‌سایت بیا. مهلت به سر می‌آید."

    # say L1931 pla
    old "Sure, don't worry I'll keep that in mind."
    new "بله، نگران نباش، به ذهنم می‌آید."

    # say L1933 ash
    old "Thank you [pla], I'll see you later then."
    new "ممنون [pla]، بعداً می‌بینیم."

    # say L1947 ash
    old "Ok, so for today I want us to focus on a new part of the project."
    new "باشه، برای امروز می‌خوایم روی بخش جدیدی از پروژه تمرکز کنیم."

    # say L1948 pla
    old "Alright, what are we doing?"
    new "باشه، ما چه کاری می‌کنیم؟"

    # say L1950 ash
    old "Let's get started and I'll explain to you along the way."
    new "بیای شروع کنیم و در میان راه به تو توضیح می‌دم."

    # say L1967 ash
    old "Ok, Ok, I really like how this turned out."
    new "باشه، باشه، واقعاً خوشحالم که اینجوری شد."

    # say L1968 ash
    old "I think we can move on to the next category."
    new "فکر می‌کنم می‌تونیم به دسته‌بندی بعدی برویم."

    # say L1971 pla
    old "Really? Don't you want to use make any corrections?"
    new "حقاً؟ نمی‌خوای هیچ تغییری انجام بدی؟"

    # say L1973 ash
    old "Not right now, because I haven't  seen how it works with other areas of the website."
    new "البته، حالا نمی‌تونم چون هنوز ندیدم این کار چطور با بخش‌های دیگه سایت کار می‌کنه."

    # say L1975 ash
    old "So, let's shift our focus to those, and then we can make any pertinent corrections."
    new "پس بیاین تمرکزمون رو به اونا ببریم، بعد می‌تونیم اصلاحات لازم رو انجام بدیم."

    # say L1977 pla
    old "I see, ok, let's do that."
    new "باشه، اینجوری کنیم."

    # say L1983 ash
    old "Alright [pla], I think that was enough for today. I think we can continue this another time."
    new "باشه ز[pla]، فکر می‌کنم اینقدر برای امروز کافی بود. می‌تونیم بعداً ادامه بدیم."

    # say L1984 ash
    old "Once again, thanks a lot for your help."
    new "بار دیگه، ممنون از کمکت."

    # say L1985 pla
    old "You're welcome. My pleasure to help you."
    new "خواهش می‌کنم. لذت برده‌ام که به تو کمک کنم."

    # say L1986 ash
    old "Now, it's a little late, so why don't you go home and rest?"
    new "الان کمی دیره، برو خونه و استراحت کن."

    # say L1988 pla
    old "Yeah, you're right. See you later Ashley."
    new "بله، درست می‌گی، باید برم. دوباره ببینم، اشلی."

    # say L1989 ash
    old "See you later hon."
    new "ببینم بعد از هم دوباره. عزیزم."

    # say L2019 pla
    old "Hi Belle, how are you?"
    new "سلام بله، چطوری؟"

    # say L2021 pla
    old "What? What's with that expresion?"
    new "چیه؟ چرا این عبارت رو داری؟"

    # say L2022 pla
    old "Is there anything wrong?"
    new "چیزی اشتباهه؟"

    # say L2024 bel
    old "I guess you could say there is."
    new "می‌تونی بگی هست."

    # say L2025 bel
    old "I saw the latests results of the poll before I came."
    new "قبل از اینکه بیایم، نتایج جدید رای‌گیری رو دیدم."

    # say L2027 bel
    old "And Lana is still on top!"
    new "و لانا هنوز اول هست!"

    # say L2028 pla
    old "She is? But I thought you said that with what we did last time, there was no way she could catch you."
    new "او هست؟ ولی فکر کردم می‌گی‌ری که با آنچه که بار هم انجام دادیم، راهی برای اینکه او رو برسسی نبود."

    # say L2030 bel
    old "I know, but you just won't believe what that whore is doing now!"
    new "می‌دونم، ولی نمی‌تونی باور کنی اون مزدور الان چیکار می‌کنه!"

    # say L2032 bel
    old "She's doing anal!"
    new "او آنال می‌کنه!"

    # say L2033 bel
    old "I mean, can you believe it?!"
    new "من قصه‌ای نمی‌گم، می‌تونی باور کنی؟!"

    # say L2035 pla
    old "Uhmm, I mean... Is it weird for people to do webcamming?"
    new "می‌گم... اینکه افراد وب‌کم کنن، عجیب نیست؟"

    # say L2037 bel
    old "For a new model, of course it is... She just started streaming a few weeks ago!"
    new "برای یک مدل جدید، البته هست... او فقط چند هفته پیش شروع به استریم کردن کرد!"

    # say L2039 bel
    old "She hasn't built a fanbase or anything yet, she is crazy!"
    new "هنوز هیچ بازدیدکننده‌ای نساخته، خیلی جسور است!"

    # say L2041 bel
    old "Besides, you know what else she did?"
    new "البته، می‌دونی چی کار دیگری انجام داد؟"

    # say L2043 bel
    old "She just uploaded it as a video to her stream!"
    new "اونجا رو فقط به صورت ویدیو آپلود کرد!"

    # say L2045 bel
    old "Well, she didn't do it live; she just recorded it off-camera and then uploaded it as if it were live..."
    new "خب، اونجوری زنده نبود؛ فقط خارج از دوربین ضبط کرد و بعدش به عنوان زنده آپلود کرد..."

    # say L2048 bel
    old "I don't know for certain, but come on, you can tell she did."
    new "من حتماً نمی‌دونم، ولی بیای، می‌تونی فهمید که انجام داده."

    # say L2050 bel
    old "She's not interacting with her chat, answering questions, or anything."
    new "او با چت‌اش تعامل نداره، سؤالاتو جواب نمی‌ده، هیچ کاری نمی‌کنه."

    # say L2051 bel
    old "She's just doing it and that's it."
    new "بله، فقط اون کار رو می‌کنه و کلش."

    # say L2053 bel
    old "It's clear that it wasn't a live stream, that's for sure!"
    new "مشخصه که این جریان زنده نبود، این حتماً!"

    # say L2054 pla
    old "Ok, I get it, what are you going to do about it then?"
    new "خب، متوجه شدم، تو بعداً چه کاری می‌کنی؟"

    # say L2056 bel
    old "Isn't it obvious?"
    new "آشکار نیست؟"

    # say L2058 bel
    old "I'm going to match her!"
    new "من قصد دارم با او همتا شوم!"

    # say L2059 bel
    old "I'm not going to just sit down and wait for her to pass me in the rankings!"
    new "من نمی‌تونم فقط بنشینم و منتظر بقیه‌ی رتبه‌بندی باشم!"

    # say L2060 pla
    old "So... You're also doing anal too?"
    new "پس... تو هم این کار رو می‌کنی؟"

    # say L2062 bel
    old "Yes, why? Are you against doing it or something?"
    new "بله، چرا؟ مخالف این کار هستی؟"

    # say L2063 pla
    old "Uhh, no, no, nothing like that."
    new "نه، نه، هیچ جور نه."

    # say L2064 pla
    old "It's just surprising, that's all."
    new "البته، فقط متعجب شدم، همه‌چیز."

    # say L2066 bel
    old "It wasn't my plan, obviously."
    new "البته این برنامه من نبود."

    # say L2067 bel
    old "But after I saw Lana's {i}'Stream'{/i}..."
    new "ولی بعد از اینکه لانا روی {i}'Stream'{/i} دیدم..."

    # say L2068 bel
    old "I asked my followers if they would like to see me doing something similar."
    new "پرسیدم از فالوورهایم که آیا می‌خواهند چیز مشابهی رو ببینن."

    # say L2069 bel
    old "They said they'd totally love to see it."
    new "اونا گفتند حتماً دوست دارن ببینن."

    # say L2070 bel
    old "So that settles it, we're doing it!"
    new "پس اینجوری شد، ما این کار رو می‌کنیم!"

    # say L2071 bel
    old "I told them we had a surprise coming the next time you appeared on the stream with me."
    new "من بهشون گفتم که می‌خوایم هنگامی که دوباره تو با من در استریم ظاهر می‌شی، مفاجأه‌ای برایشون داشته باشیم."

    # say L2072 pla
    old "I see, w- well if you're ok with it, I- I guess it's fine."
    new "بله، اگر تو موافقت می‌کنی، حدس می‌زنم خوبه."

    # say L2074 bel
    old "Yeah, I know that the next time you come to my house you have to do that website thing with my mom."
    new "بله، میدونم که هر باری که به خونه‌ام می‌آیی باید با مامانم کار وب‌سایت رو انجام بدی."

    # say L2075 bel
    old "But perhaps we could do it afterwards."
    new "اما شاید بتوانیم بعداً انجام بدیم."

    # say L2077 pla
    old "Actually, it's going to be at least a couple of times that I come to your house and help your mom with the website."
    new "در واقع، حداقل چند بار باید به خونه‌ت برسم و به مامانت در مورد وب‌سایت کمک کنم."

    # say L2079 bel
    old "Really?!"
    new "حقاً؟!"

    # say L2080 bel
    old "But we're really short on time [pla]!"
    new "اما ما واقعاً وقت کمی داریم [pla]!"

    # say L2081 pla
    old "I know, I'm sorry, but apparently, she has to show some progress to her bosses in the next meeting."
    new "می‌دونم، ببخشید، ولی به نظر می‌رسه باید برای رئیس‌اش پیشرفتی نشون بده در اجلاس بعدی."

    # say L2082 pla
    old "So, I kinda have to help her with it."
    new "پس باید یه کمی بهش کمک کنم."

    # say L2084 bel
    old "Hmph OK, I guess that's fine."
    new "همف، خب، فکر کنم مشکلی نداره."

    # say L2085 bel
    old "I'll tell my fans to wait for a while before I show them the '{i}surprise{/i}' I'd promise them."
    new "من به معشوقانم می‌گم که یه لحظه صبر کنن تا من بهشون '{i}سرپرستی{/i}'ی که قول دادم رو نشون بدم."

    # say L2086 bel
    old "But after that we have to do it, ok?"
    new "ولی بعد از آن باید انجام بدیم، خوب؟"

    # say L2089 bel
    old "Ok, I guess we better go to classes for now."
    new "باشه، به نظر می‌رسه باید حالا بریم به کلاس."

    # say L2115 ash
    old "Thank you, dear. I'm very glad I've got to meet you, you know?"
    new "ممنون، عزیزم. خوشحالم که با تو آشنا شدم، می‌دونی؟"

    # say L2117 ash
    old "After all, Belle never introduces me to any of her friends."
    new "در نهایت، بله هیچ کدوم از دوستایش رو به من نمی‌شناسونه."

    # say L2118 ash
    old "That girl's so secretive now."
    new "اون دختر الان خیلی مخفی‌بازه."

    # say L2119 pla
    old "So... Aren't you and Belle close?"
    new "پس... شما و بل نزدیک نیستید؟"

    # say L2120 ash
    old "No, we're not."
    new "نه، ما نیستیم."

    # say L2121 ash
    old "We used to be very close before, but over the years she and I have distanced a lot."
    new "قبلاً خیلی نزدیک بودیم، اما طولانی است که ما از هم دور شده‌ایم."

    # say L2124 ash
    old "Yes, when Belle was growing up we were inseparable."
    new "بله، وقتی بل این رشد می‌کرد ما بدون هم نبودیم."

    # say L2126 ash
    old "I would never go anywhere without her, and you'd be hard-pressed to see one without the other."
    new "من هر جا می‌رفتم او هم با من می‌آمد، و خیلی سخت بود یکی رو بدون دیگری ببینی."

    # say L2129 ash
    old "But as time went by we began to distance."
    new "اما با گذشت زمان شروع کردیم از هم دور شویم."

    # say L2131 ash
    old "Now we barely even talk, and whenever we're together is like she's angry with me all the time."
    new "الان هر دو تا حتی حرف هم نمی‌زنیم، و هر باری که با هم هستیم، مثل اینه که با من خشم داره."

    # say L2133 pla
    old "I'm sorry, I didn't know things were like that between the two of you."
    new "من متاسفم، نمی‌دونستم بین شما دو تا این حالتی وجود داره."

    # say L2135 ash
    old "Yeah, but I blame myself."
    new "بله، ولی خودم رو محکوم می‌کنم."

    # say L2138 ash
    old "Well, I'm a single mother, and I had Belle when I was very young."
    new "خب، من مادر تک‌پرورنده هستم، و بله را وقتی خیلی جوان بودم داشتم."

    # say L2140 ash
    old "I decided that I would do everything I could to raise her properly."
    new "من تصمیم گرفتم هر چه بتوانم برای تربیت درستش انجام بدم."

    # say L2142 ash
    old "So, as she grew up, my focus was on my work."
    new "پس، هنگامی که بزرگ شد، تمرکز من بر کارم بود."

    # say L2144 ash
    old "Since I was always working, I never had any time for her or the things related to school."
    new "چون همیشه کار داشتم، وقتی برایش یا امور مدرسه‌اش نبود."

    # say L2146 ash
    old "Is not that I wasn't interested, is just that I was busy all the time."
    new "این نیست که من علاقه‌مند نبودم، فقط همیشه مشغول کار بودم."

    # say L2147 ash
    old "I sort of thought that as long as I was providing for her, things would be fine."
    new "فکر می‌کردم مادامی که برایش تهیه می‌کنم، همه چیز خوبه."

    # say L2149 ash
    old "But I didn't realize she was pulling away from me. Nowadays I never know what she's doing."
    new "ولی متوجه نشدم که از من دور می‌شه. الان هیچ وقت نمی‌دونم چه کاری می‌کنه."

    # say L2150 ash
    old "Her interests, or the things she's into..."
    new "علاقه‌هایش، یا چیزهایی که بهش علاقه داره..."

    # say L2152 ash
    old "It's a miracle I even know Hinn, and that's just because I came home one time while she was here."
    new "البته که می‌دونم هین، و این فقط چون یک بار خانه آمدم که او اینجا بود."

    # say L2154 ash
    old "Oh, and that other friend... Mike."
    new "و آن دوست دیگه... مایک."

    # say L2156 ash
    old "But I'd rather not to talk about him."
    new "ولی بهتره در موردش صحبت نکنم."

    # say L2158 pla
    old "I- I'm sorry about that M- Mrs... I- I mean A- Ashley."
    new "ببخشید در مورد آن م- مس... منظورم ا- آشلی."

    # say L2159 pla
    old "But I'm sure you and Belle will be fine."
    new "ولی مطمئنم تو و بله خوب می‌شونید."

    # say L2161 ash
    old "You think so?"
    new "فکر می‌کنی؟"

    # say L2163 pla
    old "For sure, after all, you say you've always been close."
    new "حتماً، در نهایت تو همیشه می‌گی که خیلی نزدیک هستید."

    # say L2164 pla
    old "I'm sure Belle's just..."
    new "مطمئنم بل بسیار..."

    # say L2165 pla
    old "Uhm... Worried about things from school and such."
    new "اوه... نگران مسائل مدرسه و چیزهایی مثل اون."

    # say L2167 ash
    old "I guess I'll have to take your word for it. After all, you may be more informed about what she's doing lately than me."
    new "باید اعتماد به نظر تو داشته باشم. در نهایت، شاید تو اطلاعات بیشتری در مورد اوضاع او داری."

    # say L2169 ash
    old "The good thing is that she doesn't seem to be doing anything weird or out of the ordinary."
    new "البته، خوشحالم که او هیچ کار عجیبی نمی‌کند یا از روتین خودش خارج نمی‌شود."

    # say L2170 ash
    old "She's just focused on school."
    new "اش فقط روی مدرسه تمرکز داره."

    # say L2173 ash
    old "Although I think it would be good if she went out a little bit more. She seems to expend most of her time on her computer."
    new "البته فکر می‌کنم خوب باشه اگه یه کم بیشتر خارج می‌شد. به نظر می‌رسه بیشتر وقتش رو صرف کامپیوتر می‌کنه."

    # say L2175 ash
    old "But I guess that's good, at least she's not doing anything bad."
    new "ولی حدس می‌زنم این خوبه، حداقل هیچ کار بدی نمی‌کنه."

    # say L2177 pla
    old "Uhh, sure..."
    new "آره، البته..."

    # say L2179 ash
    old "But anyway, enough of my lamenting, it's getting a little late [pla], and you've been here for a while."
    new "اما باید کمی ترک کنم، وقتش شده کمی دیر [pla]، و تو هم اینجا طول زیادی بودی."

    # say L2180 ash
    old "Why don't you go home for now? We can continue working some other time."
    new "چرا حالا نمی‌روی خونه؟ می‌تونیم بعداً ادامه بدیم."

    # say L2181 pla
    old "Oh! Sure!"
    new "اوه! البته!"

    # say L2187 pla
    old "I'll see you later then. Goodbye, Ashley."
    new "بعداً می‌بینیم. خداحافظ، آشلی."

    # say L2189 ash
    old "Goodbye hon, thanks for your help today."
    new "خداحافظ عزیزم، ممنون از کمکت امروز."

    # say L2190 ash
    old "And thank you, for listening to me."
    new "و ممنون ازت، که به من گوش کردی."

    # say L2192 pla
    old "Gladly, I'm happy to help you, and to talk to you."
    new "البته، خوشحالم که به تو کمک کردم و با تو صحبت کردم."

    # say L2194 ash
    old "That's very sweet."
    new "این خیلی شیرینه."

    # say L2199 pla
    old "I think I should get going then."
    new "باید برم."

    # say L2200 ash
    old "Yeah, yeah, sure. Bye."
    new "بله، بله، البته. خداحافظ."

    # say L2222 bel
    old "Hi [pla], how are you?"
    new "سلام ز[pla]، چطوری؟"

    # say L2224 bel
    old "Well, I wanted to discuss what we're going to do for our next stream together."
    new "خب، می‌خواستم بگم که برای استریم بعدیمون چه کاری انجام بدیم."

    # say L2228 bel
    old "Well, I know you had to help my mom with that website she's working on."
    new "خب، میدونم تو باید به مامانم کمک کنی با آن وب‌سایتی که داره ساخت."

    # say L2230 bel
    old "But I think today you're supposed to be free, right?"
    new "ولی فکر کنم امروز باید آزاد باشی، درسته؟"

    # say L2231 bel
    old "So, do you think you could come to my house today?"
    new "پس فکر می‌کنی می‌تونی امروز به خونه من بیایی؟"

    # say L2233 bel
    old "Great! So let's go after classes."
    new "عالی! پس بعد از کلاس‌ها برویم."

    # say L2259 bel
    old "Ok, let's go."
    new "باشه، برویم."

    # say L2260 pla
    old "Right, let's do it."
    new "بله، بیایم این کار رو بکنیم."

    # say L2273 bel
    old "Alright, let's do this!"
    new "باشه، بیای این کار رو بکنیم!"

    # say L2274 pla
    old "Wait, before we start."
    new "پیش از شروع، یه لحظه."

    # say L2275 pla
    old "Are you sure you want to do this?"
    new "مطمئنی می‌خوای اینو بکنی؟"

    # say L2276 pla
    old "I know it's not that big a deal to some people, but  you would be doing it for the first time."
    new "میدونم برای بعضی‌ها این خیلی مهم نیست، ولی تو اینجوری برای اولین بار هست."

    # say L2277 bel
    old "I am, listen [pla], I've worked very hard for this."
    new "بله، بزن [pla]، من برای این خیلی سخت کار کردم."

    # say L2279 bel
    old "Winning this award means a lot to me."
    new "برای من برنده شدن این جایزه خیلی مهمه."

    # say L2280 bel
    old "And I'm not backing down because of Lana suddenly coming into the scene."
    new "و من نمی‌پیچم فقط برای اینکه لانا ناگهان وارد صحنه شده."

    # say L2282 bel
    old "So yeah, I'm sure!"
    new "پس بله، من مطمئن هستم!"

    # say L2283 pla
    old "Ok, if you're this determined, let's do it."
    new "اوه، اگر همینقدر مصممی هستی، بیایم انجام بدیم."

    # say L2285 bel
    old "Yeah! Let's do it!"
    new "بله! بیاییم این کار را انجام بدیم!"

    # say L2298 bel
    old "Hello again guys!"
    new "سلام دوباره بچه‌ها!"

    # say L2299 bel
    old "I'm very happy to see you all again!"
    new "خوشحالم که دوباره همه شما رو می‌بینم!"

    # say L2300 bel
    old "And I have very good news, everybody!"
    new "و خبر خوبی برای همه دارم!"

    # say L2301 bel
    old "Remember the other surprise I'd talked to you about?!"
    new "به یاد داری مفاجأه دیگری که بهت گفتم؟!"

    # say L2302 bel
    old "Well, it's happening today!"
    new "خب، امروز همین می‌افتد!"

    # say L2303 bel
    old "I know this is something you've been dying to see!"
    new "میدونم این چیزیه که خیلی می‌خواستی ببینی!"

    # say L2304 bel
    old "And I know you will love it!"
    new "و میدونم دوستت خواهد آمد!"

    # say L2305 bel
    old "So, say hello again to my friend, and let's get to it!"
    new "پس، دوباره به دوست من سلام بگو، و بیاین شروع کنیم!"

    # say L2310 bel
    old "Remember guys, just as always! Today's surprise can only come if you guys reach our goal."
    new "به یاد داشته باشید، همچون همیشه! هدف ما برای امروز باید رسیده باشد تا مفاجآت اتفاق بیفتد."

    # say L2311 bel
    old "But I'm sure you'll reach it!"
    new "ولی مطمئنم که به هدف خواهید رسید!"

    # say L2318 bel
    old "For today we're going to need it well lubricated, isn't that right, guys?"
    new "برای امروز باید خوب روغن داده بشه، درسته، دوستان؟"

    # say L2319 bel
    old "So I'll take care of doing a good job with my mouth to get it ready for what comes next."
    new "پس من با دهانم این کار رو خوب انجام می‌دم تا برای مرحله بعد آماده باشه."

    # say L2320 bel
    old "My God! What a great cock!"
    new "الله دست! چه ذکر خوبی!"

    # say L2321 bel
    old "Right guys?!"
    new "درسته، جون‌ها؟!"

    # say L2322 bel
    old "I bet you can't wait to see me being ravaged by it."
    new "مطمئنم شما منتظر نمی‌شید ببینید من چطور توسط اون درد می‌دم."

    # say L2323 bel
    old "Just be sure to get to the goal guys!"
    new "مطمئن شوید به هدف برسید، دudes!"

    # say L2336 pla
    old "Uh- I- uh..."
    new "اوه- من- اوه..."

    # say L2337 pla
    old "I came to do something with Belle."
    new "من برای کاری با بل آمدم."

    # say L2339 pla
    old "Some... Uh- school work..."
    new "بعضی... اوه- کار مدرسه..."

    # say L2341 ash
    old "Ok, I see, but where is Belle?"
    new "خب، می‌فهمم، اما بله کجاست؟"

    # say L2343 pla
    old "She... Uh- she went out for a while."
    new "او... اوه- او یه لحظه خارج شده."

    # say L2344 pla
    old "She said something about picking up a thing at Hinn's house."
    new "او گفت که می‌خواست چیزی رو از خونه هین بیاره."

    # say L2346 ash
    old "I had to pop home to get some documents for work, and I wanted to talk with her."
    new "باید به خونه رفتم تا چند سند برای کار ببرم، و می‌خواستم با او صحبت کنم."

    # say L2347 ash
    old "Well, it's good to see you anyway."
    new "البته خوشحالم که تو رو دیدم."

    # say L2348 ash
    old "I'll go back to the office, please tell Belle to give me a call when she gets back."
    new "باید برگرم به دفتر، لطفاً بگوی به بل که وقتی برگشت به من تماس ببره."

    # say L2349 ash
    old "See you later [pla]."
    new "به بعد می‌بینیم [pla]."

    # say L2350 pla
    old "Sure, see you later ma'am."
    new "بله، بعداً می‌بینیم."

    # say L2362 pla
    old "{i}What the fuck just happened...{/i}"
    new "{i}بیا بگو چه خبر بود...{/i}"

    # say L2363 bel
    old "{i}Holy shit, I know... Anyway, let's just keep going with the stream... Shhh...{/i}"
    new "{i}شوک دادم، می‌دونم... بیای، بیای، بیای، همینجور ادامه بدیم به پخش زنده... شه...{/i}"

    # say L2364 bel
    old "Sorry, guys! I'm sorry for that little interruption... You know, this can happen when you're doing it live..."
    new "ببخشید، جون‌ها! عذرخواهم از این توقف کوچک... می‌دونید، اینجوری می‌شه وقتی زنده می‌کنی..."

    # say L2365 bel
    old "Anyways, let's continue with the show!"
    new "بیایم ادامه بدیم به شو"

    # say L2366 bel
    old "But now we can resume with what we were doing, and you know what that means."
    new "البته، حالا می‌تونیم ادامه بدیم به کاری که قبلاً انجام می‌دادیم، و می‌دونی این چه معنی داره."

    # say L2368 bel
    old "No, she won't be joining us or anything."
    new "نه، او نمی‌آید و نه چیزی."

    # say L2369 bel
    old "That was just an unplanned thing."
    new "این فقط یه چیز ناپیش‌بینی شده بود."

    # say L2370 bel
    old "But don't worry, we're not stopping here."
    new "اما نگران نباش، ما اینجا متوقف نمی‌شویم."

    # say L2371 bel
    old "Let's keep going!"
    new "بیای برویم!"

    # say L2388 bel
    old "Wow, that was close!"
    new "واو، این خیلی نزدیک بود!"

    # say L2389 pla
    old "Really close."
    new "وای، خیلی نزدیک بود."

    # say L2390 pla
    old "That really scared me."
    new "من واقعاً وحشتم."

    # say L2391 bel
    old "It's good that she didn't see us doing anything."
    new "خوشحالم که او هیچی رو ندید."

    # say L2393 bel
    old "I can't imagine how we would explain the whole situation to her."
    new "نمی‌تونم بیان کنم چطور این وضعیت رو بهش توضیح میدادیم."

    # say L2394 pla
    old "Yeah, tell me about it."
    new "بله، درست می‌فرمایی."

    # say L2395 bel
    old "Well, we should get back to the stream before the fans get impatient."
    new "باید برگردیم به جریان قبل از اینکه طرفداران خسته شوند."

    # say L2408 bel
    old "Hngh! Oh yes!"
    new "اوه بله!"

    # say L2409 bel
    old "This is what you've all been waiting for isn't it?"
    new "این همون چیزیه که همه منتظرش بودن، درسته؟"

    # say L2410 bel
    old "Well, you earned it!"
    new "خب، این را کسب کردی!"

    # say L2411 bel
    old "So, be sure to enjoy it!"
    new "پس حتماً ازش لذت ببر!"

    # say L2424 bel
    old "Guys! I'm so glad you liked it!"
    new "دستا شما! خوشحالم که لذت برده‌اید!"

    # say L2425 bel
    old "You keep making all of this possible."
    new "شما همیشه این همه چیز رو ممکن می‌کنی."

    # say L2426 bel
    old "Witout your support this just wouldn't be possible."
    new "بدون حمایت شما این هیچ وقت ممکن نبود."

    # say L2427 bel
    old "So, it makes me very happy to do this kind of thing for you."
    new "پس، این کار برای تو انجام دادن منو خیلی خوشحال می‌کنه."

    # say L2428 bel
    old "Ok guys, I have to leave for now."
    new "بچه‌ها، باید حالا برسم."

    # say L2429 bel
    old "But be sure that I'll be back soon with another stream."
    new "اما مطمئن باشید که زودی با استریم جدیدی بر می‌گردم."

    # say L2430 bel
    old "I wonder what surprise I'll have for you then?"
    new "می‌خوام ببینم چه مفاجاتی برای شما در این جا خواهم داشت."

    # say L2431 bel
    old "As always remember to subscribe so you will get notified of the next stream!"
    new "همیشه به یاد داشته باش تا اشتراک بگیری تا از استریم بعدی مطلع شی!"

    # say L2432 bel
    old "And remember to follow me on all my socials."
    new "و به یاد داشته باش که من رو در همه شبکه‌های اجتماعی دنبال کنی."

    # say L2433 bel
    old "So you won't miss any updates!"
    new "پس هیچ آپدیتی نمی‌گذرن!"

    # say L2434 bel
    old "Until next time, see you guys! Love you!"
    new "تا دفعه بعد، خداحافظ همه! دوستت دارم!"

    # say L2443 bel
    old "That came out really well [pla]!"
    new "این خیلی خوب شد [pla]!"

    # say L2444 bel
    old "They matched the goal so quickly!"
    new "هدف رو به سرعت رسیدند!"

    # say L2445 bel
    old "I'm sure I'll overtake Lana in no time!"
    new "مطمئنم زودی لانا رو پشت سر می‌ذارم!"

    # say L2446 bel
    old "And this time I'm certain the first spot in the rankings is mine for sure!"
    new "و این بار مطمئنم رتبه اول را به دست می‌آورم."

    # say L2448 pla
    old "That's great to hear Belle, I'm sure you'll get it."
    new "این خبر خوبه بل، مطمئنم که می‌تونی به اون برسی."

    # say L2450 pla
    old "Although I hope your fans weren't bothered by your mom coming in midstream."
    new "البته امیدوارم طرفدارانت از آمدن مامانتون در وسط خنده‌ناک نشدن."

    # say L2452 pla
    old "That really scared me, I thought she was going to see us."
    new "این واقعاً مرا می‌ترسوند، فکر کردم می‌تونست مامان ما رو ببینه."

    # say L2454 bel
    old "Yeah, me too, I'm sorry that happened, by the way."
    new "بله، من هم همینجور. معذرت که اینطور شد."

    # say L2455 bel
    old "She just had to come in at the most inopportune time."
    new "او فقط باید دقیقاً در بدترین زمان وارد شود."

    # say L2456 bel
    old "But don't worry, the fans weren't too bothered by her intrusion."
    new "اما نگران نباش، تماشاگران خیلی از ورودش ناراحت نبودند."

    # say L2458 bel
    old "Yeah... they were writing how thrilling it was."
    new "بله... آنها نوشته بودند چقدر تحریک‌کننده بود."

    # say L2460 bel
    old "So many of them were even writing how hot it would be to see my mom fuck with us."
    new "بسیاری از آنها حتی نوشته بودند چقدر خوب است که مامانم با ما سکس کند."

    # say L2462 bel
    old "But leaving that aside, everything went better than I expected."
    new "اما اونو جا به جا کنیم، همه چیز بهتر از آنچه انتظار داشتم پیش رفت."

    # say L2464 bel
    old "Thanks a lot [pla], this wouldn't have been possible without you."
    new "ممنون زیادی [pla]، بدون تو این جور نمی‌شد."

    # say L2466 pla
    old "Don't even mention it, I'm happy I can help you."
    new "بله، هیچ کاری نداره، خوشحالم که بتونم به تو کمک کنم."

    # say L2467 pla
    old "I know how much this means to you."
    new "می‌دونم این چقدر برای تو مهمه."

    # say L2469 bel
    old "But even still, is not as if this is just nothing."
    new "ولی همچنان، این مثل هیچ نیست."

    # say L2471 bel
    old "After all, we're... Getting closer."
    new "در نهایت، ما... نزدیک‌تر می‌شیم."

    # say L2473 pla
    old "Yeah... We are."
    new "بله... ما هستیم."

    # say L2479 pla
    old "Well, I think I should leave for now."
    new "خب، فکر کنم باید حالا برسم."

    # say L2481 bel
    old "Right, for sure! I think I better get dressed and call my mom before she goes crazy because I haven't talked to her."
    new "بله، حتماً! بهتره لباس بذارم و با مامان تماس بگیرم قبل از اینکه خیلی ناراحت بشه."

    # say L2482 bel
    old "Once again [pla], thanks."
    new "بار دیگر [pla]، ممنون."

    # say L2483 bel
    old "You're doing so much for me, I can't thank you enough."
    new "تو خیلی کمک می‌کنی، نمی‌تونم ممنونیت رو بیان کنم."

    # say L2484 pla
    old "Don't worry, I'm just happy I can help you Belle, with anything you need."
    new "نگران نباش، خوشحالم که بتونم به تو کمک کنم بله، هر چی بهت لازم بود."

    # say L2485 pla
    old "I'll leave for now, see you later."
    new "من حالا می‌روم، بعداً می‌بینیم."

    # say L2507 pla
    old "Hi Ashley, I came to help you with the website."
    new "سلام آشلی، اومدم تا به تو در وب‌سایت کمک کنم."

    # say L2508 ash
    old "Oh, is good that you're here I need your help with something right now."
    new "اوه، خوشحالم که اینجا هستی، الان به چیزی نیاز دارم که تو کمک کنی."

    # say L2510 ash
    old "Well, I was thinking about the design of the banners that we're making for the coffee shop."
    new "خب، من در مورد طراحی بنرهایی که برای کافی‌شاپ می‌سازیم فکر می‌کردم."

    # say L2511 ash
    old "And I remembered some banners that we had made before but never got around to releasing."
    new "و به یاد آوردم که چند بنر قبلاً طراحی کردیم ولی هیچ وقت منتشر نکردیم."

    # say L2512 ash
    old "I think we'll be able to reuse some of those ready-made designs to add them to the website."
    new "فکر می‌کنم بتونیم برخی از طرح‌های آماده شده رو دوباره استفاده کنیم و به وب‌سایت اضافه کنیم."

    # say L2513 ash
    old "I remembered that I saved those designs on an old flash drive, and I placed it up there on the shelves."
    new "به یاد آوردم که اون طرح‌ها رو توی یه فلاش درایو قدیمی ذخیره کردم و بالای رف قرار دادم."

    # say L2514 ash
    old "But it's a bit too high for me to reach by myself without risking falling over."
    new "اما برای من خیلی بالاست تا بدون خطر افتادن بهش برسی."

    # say L2515 ash
    old "So, I need you to help me stay stable on the ladder while I look for it."
    new "پس، لازم دارم که تو به من کمک کنی تا روی لadder قایم بمونم و جستجو کنم."

    # say L2517 pla
    old "Uhh, s- sure, no problem."
    new "آره، حتماً، هیچ اشکالی نداره."

    # say L2518 ash
    old "Thank you, hun."
    new "ممنون، عزیزم."

    # say L2523 pla
    old "Are you okay there? Can you reach it?"
    new "آشلی، حالت خوبه؟ می‌تونی بهش برسی؟"

    # say L2524 ash
    old "Yeah, I'm close. Just a little more and I'll grab it."
    new "بله، نزدیک هستم. فقط کمی بیشتر و می‌گیرمش."

    # say L2525 pla
    old "{i}(... Damn, I hadn't thought about it, but Ashley's really hot.){/i}"
    new "{i}(شیطان! من به این فکر نکرده بودم، اما آشلی واقعاً گرم است.){/i}"

    # say L2528 pla
    old "{i}(Maybe it is because she's so young, but wow, her body's amazing!){/i}"
    new "{i}(شاید به خاطر جوان بودنش، اما وای، بدن‌ش واقعاً شگفت‌انگیزه!){/i}"

    # say L2532 ash
    old "[pla]? Is everything alright?"
    new "[pla] همه چیز خوبه؟"

    # say L2533 pla
    old "Uh, yeah, yeah... Why do you ask?"
    new "آره، آره... چرا می‌پرسی؟"

    # say L2534 ash
    old "Well, you moved suddenly, so I was wondering if I made you lose your balance."
    new "خب، چون با همین جابجا شدی، فکر کردم شاید تعادلت رو از دست دادی."

    # say L2535 pla
    old "No, no, Uhh, nothing happened, it's ok."
    new "نه، نه، هی، هیچی پیش نیومده، خوبه."

    # say L2536 ash
    old "Uh, ok... sure."
    new "اوه، خوب... بله."

    # say L2537 pla
    old "{i}(Shit! I better calm down before I get a boner.){/i}"
    new "{i}(شیطان! باید آرام شوم قبل از اینکه سفت بشم.){/i}"

    # say L2538 ash
    old "Ok, I think I've got them, I'm coming down."
    new "باشه، فکر کنم اونا رو گرفتم، می‌آیم پایین."

    # say L2539 pla
    old "Oh, alright."
    new "اوه، خوب."

    # say L2547 pla
    old "Ughh, damn, that was painful."
    new "اوه، شیطون، این خیلی درد داشت."

    # say L2549 pla
    old "{i}(Oh wow, it's Ashley's ass!){/i}"
    new "{i}(اوه وای، این دم شوندهٔ آشلیه!){/i}"

    # say L2551 ash
    old "Ouch, that really hurt."
    new "ای، این واقعاً درد کرد."

    # say L2552 ash
    old "I'm sorry [pla], I don't know what happened, are you okay?"
    new "متاسفم [pla]، نمی‌دونم چه اتفاقی افتاد، حالت خوبه؟"

    # say L2556 pla
    old "Y- yeah, I- I am. I'm sorry, I think I was the one who slipped."
    new "B- بله، من هستم. خواهش می‌کنم، فکر کنم من بودم که اشتباه کردم."

    # say L2560 pla
    old "Uh... A- Ashley? Can you please move?"
    new "اوه... اشلی؟ لطفاً جابجا شو."

    # say L2561 ash
    old "Uh, I- I..."
    new "اوه، من- من..."

    # say L2563 ash
    old "Is just that you have a..."
    new "فقط اینجاست که تو..."

    # say L2574 pla
    old "I- I uh... I'm sorry Ashley, it wasn't my intention..."
    new "من- من... معذرت آشلی، قصد نداشتم..."

    # say L2575 pla
    old "I- its just that..."
    new "من- فقط اینجاست که..."

    # say L2576 ash
    old "It's fine, it's fine."
    new "خوبه، خوبه."

    # say L2578 ash
    old "You're a young man after all. It's perfectly understandable that this happens."
    new "تو هنوز جوانی. کاملاً طبیعیه که اینجوری شده."

    # say L2579 ash
    old "I fell on you and... M- my butt landed on your face..."
    new "من روی تو فروریختم و... و... اردگم روی چهرت خیس شد..."

    # say L2580 ash
    old "So, I think I understand that you would get a..."
    new "پس، فکر می‌کنم متوجه شدم که تو اینجا..."

    # say L2598 pla
    old "Uhh... T- thank you... for understanding."
    new "اوه... ممنونم... که متوجه شدی."

    # say L2599 ash
    old "Hmm... Sure, i- it's very normal."
    new "هم... البته، خیلی طبیعی است."

    # say L2604 pla
    old "Uhh, s- should we get to working on the website then?"
    new "اوه، ب- باید به سایت کاری کنیم الان؟"

    # say L2606 ash
    old "I- I don't think that's a good idea right now [pla]."
    new "ا- این الان خوب نیست ز[pla]."

    # say L2607 ash
    old "B- because I have to bring the banners to my team in the office, so they can use them to design the new ones."
    new "B- چون باید بنر‌ها رو به تیم من در اداره ببرم، تا بتونن برای طراحی نسخه‌های جدید ازشون استفاده کنن."

    # say L2609 pla
    old "Oh... Alright."
    new "اوه... خب."

    # say L2611 pla
    old "I- I think I'll leave for now, see you later."
    new "ب- باید حالا برسم، بعداً می‌تونیم دوباره ببینیم."

    # say L2612 ash
    old "Y- yeah... S- see you later hon."
    new "ب- بله... ب- بعداً می‌بینیم عزیزم."

    # say L2618 ash
    old "Wow, he really has it very big c-... Now I understand why Belle likes him so much..."
    new "وای، واقعاً خیلی بزرگه... حالا متوجه شدم چرا Belle همچین علاقه‌ای بهش داره..."

    # say L2638 pla
    old "Hey Belle, good morning, how are you?"
    new "سلام Belle، صبح بخیر، چطوری؟"

    # say L2640 bel
    old "To be honest, I'm quite upset..."
    new "صusch، من خیلی ناراحتم..."

    # say L2641 pla
    old "Why? What happened now?"
    new "چرا؟ الان چه اتفاقی افتاد؟"

    # say L2643 bel
    old "Well, it's that bitch Lana."
    new "خب، اون مالیح لانا."

    # say L2645 bel
    old "You won't believe what she pulled now!"
    new "باورت نمی‌شه این بار چه کاری کرده!"

    # say L2646 pla
    old "W- what? Why?!"
    new "و- وای؟ چرا؟!"

    # say L2647 pla
    old "I thought that you had surpassed her with what we did last time."
    new "فکر می‌کردم تو با آنچه که ما آخر بار انجام دادیم از او پیشی گرفته‌ای."

    # say L2649 bel
    old "And we did!"
    new "و ما هم انجام دادیم!"

    # say L2651 bel
    old "After our last streaming session I went up on the charts by a lot."
    new "بعد از آخرین جلسه‌ی استریم، رتبه‌ام خیلی بالا رفت."

    # say L2653 bel
    old "So, I guess Lana felt desperate or something."
    new "پس فکر کنم لانا ناامید شده بود یا چیزی."

    # say L2654 bel
    old "Because then she came out and did a threesome!"
    new "چون بعد از آن، او بیرون آمد و یک سه‌تایی انجام داد!"

    # say L2655 pla
    old "A threesome?"
    new "سه‌نفره؟"

    # say L2657 bel
    old "Yeah, she just did it out of nowhere."
    new "بله، اونجوری خودش انجام داد."

    # say L2659 bel
    old "You know what really triggers me? She didn't even do it with another cam streamer or anything!"
    new "می‌دونی چی واقعاً منو تحریک می‌کنه؟ هیچ جور با یه استریمر دیگه انجام نداده، حتی!"

    # say L2661 bel
    old "But of course she didn't, she doesn't know anybody in this business."
    new "البته که نه، او هیچ‌کس در این حرفه رو نمی‌شناسه."

    # say L2663 bel
    old "I bet she just paid some amateur pornstar to do it with her, that whore!"
    new "حتماً اون جوری کرده، اون شور!"

    # say L2664 pla
    old "OK, what is your plan then?"
    new "خب، پلن تو چیه؟"

    # say L2666 bel
    old "What do you mean what is my plan? I'm going to answer her the same way of course?"
    new "من قصه‌ای رو می‌گم؟ همینجوری بهش جواب می‌دم طبیعتاً."

    # say L2667 pla
    old "Uhh, really? Are you sure?"
    new "اوه، واقعاً؟ مطمئنی؟"

    # say L2669 bel
    old "Of course I'm sure [pla], I've done too much to win this contest."
    new "بله مطمئنم [pla]، خیلی کار کردم تا این مسابقه رو ببرم."

    # say L2670 bel
    old "I've been working hard to get every vote I've received."
    new "من سخت کار کردم تا هر رایی که گرفتم به دست آورم."

    # say L2671 bel
    old "I've augmented the number of times I stream weekly. I roped you into this."
    new "تعداد بارهایی که هفته‌ای استریم می‌کنم افزایش یافته. تو رو هم به این واداشتم."

    # say L2673 bel
    old "I even let you fuck me in the ass!"
    new "حتی به تو اجازه دادم از پشت بکنی!"

    # say L2675 bel
    old "I've worked hard for this, and I'm not going to let some newcomer take it away."
    new "من برای این سخت کار کردم و نمی‌تونم بیاد یک جدیدونه این رو از دست من ببره."

    # say L2676 pla
    old "Well, I don't know what to tell you."
    new "خب، نمی‌دونم چی بگم."

    # say L2677 bel
    old "You don't have to say anything, all I need is for you to be willing to help me when I need it."
    new "تو نیازی به هیچ چیزی نداری، فقط باید آماده باشی که وقتی ازت کمک می‌خواهم، به من کمک کنی."

    # say L2679 pla
    old "Of course! You know I'll help you with anything I can."
    new "البته! می‌دونی من برای هر چی که بتونم بهت کمک می‌کنم."

    # say L2681 bel
    old "Thanks [pla], I'm glad I can count on you."
    new "ممنون [pla]، خوشحالم که می‌تونم بر تو اعتماد کنم."

    # say L2682 bel
    old "Also, I already have someone in mind who can help us with the threesome."
    new "همچنین، من قبلاً کسی رو در نظر دارم که می‌تونه به ما در مورد سه‌تایی کمک کنه."

    # say L2683 bel
    old "I'll have to contact her and see when she would be available to arrange everything for the stream."
    new "باید با او تماس بگیرم و ببینم چه زمانی می‌تونه برای انجام همه چیز برای استریم آماده باشه."

    # say L2684 bel
    old "Meanwhile, you have to work with my mom the next time you come home, right?"
    new "بینی، هر باری که خانه می‌آیی باید با مامانم همکاری کنی، درسته؟"

    # say L2686 pla
    old "Uhh, yeah, we are still working on the website, there are still several things left to finish."
    new "اوه، بله، هنوز روی وب‌سایت کار می‌کنیم، چند کار هم هست که باید تمام شه."

    # say L2688 bel
    old "Ok, so while you do that I'll talk with my friend and see if she can help us."
    new "باشه، من همینجوری با دوستم صحبت می‌کنم و می‌بینم که چطور می‌تونه به ما کمک کنه."

    # say L2689 bel
    old "I'll let you know as soon as we can do it."
    new "من همین جا به تو اطلاع می‌دم هر وقت بتونیم انجام بدیم."

    # say L2691 pla
    old "Uhh, alright."
    new "اوه، خوب."

    # say L2693 bel
    old "Great, then see you later [pla]."
    new "عالی، پس بعداً می‌بینیم [pla]."

    # say L2695 pla
    old "See you Belle."
    new "بای بله."

    # say L2707 pla
    old "Well, I was thinking I could keep helping you develop the website."
    new "خب، من فکر می‌کردم می‌تونم به تو کمک کنم تا وب‌سایت رو توسعه بدی."

    # say L2708 ash
    old "Hmm... There might be a problem with that [pla]."
    new "Hmm... ممکنه مشکلی با این باشه [pla]."

    # say L2709 pla
    old "Hmm, what is it?"
    new "Hmm، چه مشکلی هست؟"

    # say L2711 ash
    old "Well, my laptop isn't working right now."
    new "خب، لپ‌تاپ من الان کار نمی‌کنه."

    # say L2712 ash
    old "I was... Uh, u- using it the other day, looking for some... References."
    new "من... اوه، ی- یه روزه استفاده می‌کردم، جستجوی برخی... منابع می‌کردم."

    # say L2713 ash
    old "But it suddenly stopped working."
    new "ولی اونجور ناگهان خراب شد."

    # say L2715 ash
    old "I can turn it on now, it will even power up normally."
    new "الان می‌تونم روشنش کنم، حتی به طور عادی خواهد روشن شد."

    # say L2716 ash
    old "But after that, it doesn't work."
    new "ولی بعد از آن، کار نمی‌کنه."

    # say L2717 pla
    old "What do you mean? The screen just stays black?"
    new "من قصه‌تو نمی‌فهمم. صفحه فقط سیاه می‌مونه؟"

    # say L2718 ash
    old "No, it's not that. Once it's fully turned on, you simply can't do anything with it."
    new "نه، این جور نیست. بعد از اینکه کاملاً روشن می‌شه، نمی‌تونی هیچ کاری باش کنی."

    # say L2720 ash
    old "If you click on something, multiple windows open up, and when you attempt to use the web browser, numerous tabs start to open up."
    new "اگر روی چیزی کلیک کنی، پنجره‌های زیادی باز می‌شن، و وقتی می‌خوای از مرورگ وب استفاده کنی، تب‌های زیادی شروع می‌کنن باز می‌شن."

    # say L2721 ash
    old "And you can't close them down or do anything about it."
    new "و نمی‌تونی هیچ کاری باشون بکنی."

    # say L2722 pla
    old "Hmm, that sounds like an adware."
    new "هم، این به نظر می‌تونه یه نرم‌افزار تبلیغاتی باشه."

    # say L2724 pla
    old "But don't worry, I think I can fix it."
    new "ولی نگران نباش، فکر کنم می‌تونم این مشکل رو حل کنم."

    # say L2727 pla
    old "Yeah, all I have to do is run an antivirus through it, and it should be completely fine."
    new "بله، فقط باید آنتی‌ویروس رو اجرا کنم، بعداً حتماً خوب می‌شه."

    # say L2728 ash
    old "That sounds great! Alright, let's do it."
    new "این خوبه! بیا، بزنیم."

    # say L2743 ash
    old "There, that's what happens as soon as you try to use it."
    new "اینجا، همین اتفاق می‌افتد وقتی می‌خوای ازش استفاده کنی."

    # say L2744 pla
    old "Hmm, yeah, I see what you mean."
    new "هم، بله، من هم می‌فهمم."

    # say L2745 pla
    old "Yeah, this appears to be an adware virus. But don't worry, it can be easily fixed."
    new "بله، این به نظر می‌رسد ویروس تبلیغاتی باشه. ولی نگران نباش، رفعش خیلی آسانه."

    # say L2746 pla
    old "I just have to run the antivirus, and it will take care of cleaning up all those annoying ads."
    new "من فقط باید آنتی‌ویروس رو اجرا کنم، و اون وقت همه آگهی‌های مزخرف رو پاک می‌کنه."

    # say L2747 pla
    old "It should start to work quickly."
    new "باید سریع شروع به کار کنه."

    # say L2754 pla
    old "See? It's already starting to work."
    new "ببین؟ قطعاً شروع کرده به کار کردن."

    # say L2760 pla
    old "Ok, now it's searching for viruses and malicious content."
    new "باشه، حالا داشته به دنبال ویروس‌ها و محتوای خلاف قانون می‌گرده."

    # say L2761 pla
    old "As soon as it's done with the scanning, it will start deleting all the damaged files and threats to the system."
    new "بازرسی تمام شد، الان همه فایل‌های خراب و تهدیدات سیستم رو حذف می‌کنه."

    # say L2762 ash
    old "Wow, you're very good with computers [pla]."
    new "واو، تو خیلی خوب با کامپیوتر کار می‌کنی [pla]."

    # say L2763 pla
    old "Well, it's not as difficult as it seems, heh."
    new "خب، اینقدر سخت نیست، هه."

    # say L2769 pla
    old "Ok, it's almost done, it shouldn't take much longer."
    new "باشه، تقریباً تمام شده، زیاد طول نمی‌کشه."

    # say L2770 ash
    old "Wow, I didn't know it was so fast. I thought I would have to take it for maintenance and it would take days."
    new "واو، نمی‌دونستم اینقدر زوده. فکر کردم باید برای تعمیر ببرم و روزها طول بکشه."

    # say L2777 pla
    old "Okay, we're done. The viruses that were affecting your computer should have been eliminated by now."
    new "خب، تمام شد. ویروس‌هایی که کامپیوترت رو مورد حمله قرار دادن باید از بین برده شدن."

    # say L2778 ash
    old "Great, thank you!"
    new "عالی، ممنون!"

    # say L2779 pla
    old "Just let me refresh it and we'll see..."
    new "فقط بیای من دوباره بروزرسانی کنم و ببینیم..."

    # say L2786 pla
    old "Now, all of those ads and windows that it opened previously should start closing down."
    new "الان، همه آن تبلیغات و پنجره‌هایی که قبلاً باز شده بودند باید شروع به بسته شدن کنند."

    # say L2790 pla
    old "Oh! there's a webpage from your previous session."
    new "اوه! صفحه‌ای از جلسه قبلت باز هست."

    # say L2791 pla
    old "Hmm, let's see, what does it say?"
    new "ببینم، چه می‌گه؟"

    # say L2795 pla
    old "Sneaky Stepmom Fucks Step Daugther's Boyfri-..."
    new "مامان خیانتگر فرزندخوانده‌اش رو با دوست پسرش..."

    # say L2797 ash
    old "Oh! T- that's..."
    new "اوه! آ- آن..."

    # say L2798 ash
    old "I- I Uh- I- I'm sorry [pla]! I don't know what that's doing in there."
    new "ا- اوه- ا- اسف ز[pla]! نمی‌دونم اونجا چی کار می‌کنه."

    # say L2799 ash
    old "M- maybe the virus s- send us to that website!"
    new "M- شاید ویروس ما رو به اون سایت فرستاده!"

    # say L2800 pla
    old "Uhm... Yeah, that's probably what happened."
    new "اوه... بله، احتمالاً همینطور شده."

    # say L2801 ash
    old "W- well, let's just close it. And keep checking if the pc is fine."
    new "ب- بیای، بگذار ببندیم. و همچین چک کنیم کامپیوتر خوبه."

    # say L2809 pla
    old "Okay, I think the computer is good to go."
    new "باشه، فکر کنم کامپیوتر خوبه."

    # say L2810 pla
    old "Now it shouldn't be a problem to continue with the work."
    new "البته، حالا باید مشکلی برای ادامه کار نباشد."

    # say L2812 ash
    old "Ohh, t- thank you [pla]."
    new "اوه، ممنون [pla]."

    # say L2813 ash
    old "I- It's great that you managed to get it working again."
    new "خوشحالم که تونستی دوباره اینجا رو راه‌اندازی کنی."

    # say L2816 ash
    old "And I'm sorry about that website that you saw."
    new "و متاسفم از آن وب‌سایت که دیدی."

    # say L2817 ash
    old "I don't know how that got in there."
    new "نمی‌دونم اونجور شده که وارد بشه."

    # say L2819 pla
    old "Uhh sure... I'm just glad I can be of help."
    new "اوه بله... خوشحالم که می‌تونم کمکت کنم."

    # say L2821 ash
    old "That's very nice of you."
    new "خیلی ممنون ازت"

    # say L2827 ash
    old "Uhh, I guess we should continue working, right?"
    new "اوه، فکر کنم باید ادامه کار رو بدهیم، درسته؟"

    # say L2828 pla
    old "Oh, sure, we should get to that."
    new "بله، البته باید به اون برسیم."

    # say L2887 pla
    old "Hey Belle, how are you?"
    new "هی Belle، چطوری؟"

    # say L2888 bel
    old "Actually, I'm doing great, you know? I have very good news!"
    new "در واقع خوب هستم، می‌دونی؟ خبر خوبی دارم!"

    # say L2891 bel
    old "Remember what I told you before? What we needed to do for the next stream?"
    new "به خاطر داری چی به تو گفتم؟ آن کاری که باید برای استریم بعدی انجام بدیم؟"

    # say L2893 pla
    old "Uhh, yeah, I do."
    new "بله، به یاد دارم."

    # say L2895 bel
    old "Well, I got the girl we needed for the stream!"
    new "خب، دختری که برای استریم نیاز داشتیم رو پیدا کردم!"

    # say L2897 pla
    old "T- that's great."
    new "ب-ه، خوبه."

    # say L2898 bel
    old "Yeah, she's an amazing streamer."
    new "بله، او یک استریمر عالیه."

    # say L2899 bel
    old "So, get ready because today we're going to do the stream!"
    new "پس آماده شو، زیرا امروز ما استریم می‌کنیم!"

    # say L2901 pla
    old "A- alright, so, are we going to your house after class ends?"
    new "بale، پس، بعد از پایان کلاس به خونت می‌رسیم؟"

    # say L2903 bel
    old "Uhh, actually, I will skip classes today."
    new "اوه، در واقع، من امروز کلاس رو می‌برم."

    # say L2905 bel
    old "I have to go to the girl's house now to pick her up and take her to my house."
    new "من باید الان به خونه دختر برسم تا اون رو ببرم به خونه من."

    # say L2906 bel
    old "And then I'll set up the stream and make sure that everything's ready."
    new "بعد از اون، استریم رو تنظیم می‌کنم و مطمئن می‌شوم همه چیز آماده باشه."

    # say L2909 bel
    old "So, don't worry, you go to class and we'll meet at my house when you're done."
    new "پس نگران نباش، تو به کلاس برو و وقتی تمام شدی به خونه من می‌آیی."

    # say L2914 bel
    old "You'll see, with this, I will definitely surpass Lana in the rankings for good."
    new "ببین، با این، قطعاً لانا رو توی رتبه‌بندی بازمی‌زنم."

    # say L2917 bel
    old "Thanks, [pla]. Now, I'll leave, and we'll meet at my house in the afternoon."
    new "ممنون، [pla]. حالا من می‌روم و ما بعد از ظهر در خونه‌ام می‌شویم."

    # say L2938 pla
    old "Ok, I guess  I'll go to Belle's house now."
    new "باشه، به نظر می‌رسه الان می‌رمش به خونه بله."

    # say L2939 pla
    old "That's weird, I'm going to Belle's house to have a... Threesome, and with a girl I don't know..."
    new "این عجیبه، من می‌روم به خونه بله برای... یک سه‌نفره، و با یه دختری که نمی‌شناسم..."

    # say L2940 pla
    old "This definitely escalated quickly..."
    new "این قطعاً سریع تبدیل به چیزی غیرمنتظره شد..."

    # say L2941 pla
    old "Well, anyway, I better go quickly. I don't want to be late for Belle's stream.."
    new "بازهم، بهتره سریع برسم. نمی‌خوام برای استریم بله تأخیر کنم."

    # say L2958 bel
    old "Hi [pla], thanks for coming."
    new "سلام ز[pla]، ممنونم که اومدی."

    # say L2959 bel
    old "So, this is my friend Amorette, she will be joining us for today's stream."
    new "پس، این هم دوست من آمورت، او برای استریم امروز با ما هست."

    # say L2960 pla
    old "Oh... U- uhm... Hi!"
    new "اوه... ا- اوه... سلام!"

    # say L2962 amo
    old "Hi! Nice meeting you!"
    new "سلام! خوشحالم که با تو آشنا شدم!"

    # say L2964 amo
    old "So this is the guy you've been streaming with lately, Belle!"
    new "پس این همون دستاوردی هست که بله اخیراً باشون استریم می‌کرد!"

    # say L2965 amo
    old "I can't believe I'm actually meeting you! You know, I'm a big fan of yours."
    new "باورم نمی‌شه واقعاً تو رو می‌بینم! می‌دونی، من یکی از طرفدارانت."

    # say L2966 pla
    old "My fan? Really?"
    new "Fan من؟ واقعاً؟"

    # say L2968 amo
    old "Of course I follow Belle's stream because she's one of the best-ranked streamers."
    new "البته من استریم بله رو دنبال می‌کنم چون او یکی از بهترین استریمرهاست."

    # say L2970 amo
    old "And lately her content has been great, especially the one she's doing with you."
    new "و اخیراً محتوایش عالی بوده، خصوصاً آن چیزی که با تو می‌کنه."

    # say L2971 amo
    old "So, I'm also a fan of yours."
    new "پس من هم از طرفدارانت."

    # say L2974 amo
    old "But how couldn't I be? After all, you have that amazing cannon in between your legs."
    new "ولی چطور نمی‌تونستم؟ در نهایت تو آن مدفع عالی رو بین لگنت داری."

    # say L2976 amo
    old "With how long and thick it is... I know my views would skyrocket if I ever have you in one of my streams."
    new "با اون طول و ضخامتش... می‌دونم بازدید‌هایم بالا می‌ره اگه تو رو توی یکی از استریم‌هام نشون بدم."

    # say L2977 pla
    old "I- Uh- Well... I- I don't know what to say..."
    new "من- اوه- خب... من- من نمی‌دونم چی بگم..."

    # say L2979 amo
    old "Oh! Look at that reaction! It's so cute, hahaha."
    new "اوه! نگاه کن به این واکنش! خیلی لطیفه، هahaha."

    # say L2985 bel
    old "Ok guys, everything's already set up, so we're ready to go."
    new "اوه، خوب، همه چیز قبلاً آماده شده، پس می‌تونیم شروع کنیم."

    # say L2986 bel
    old "At first I'll be alone on camera, I'll introduce you and then you can come in Amorette."
    new "اول من تنهایی در برابر دوربین خواهم بود، تو رو معرفی می‌کنم و بعد می‌تونی وارد شی، عموrette."

    # say L2987 bel
    old "After that I'll bring you in [pla], and we can get started."
    new "بعد از آن تو رو می‌آورم [pla] و می‌تونیم شروع کنیم."

    # say L2992 bel
    old "Great, then let's do it."
    new "عالی، پس بیایم انجام بدیم."

    # say L3009 bel
    old "Hey guys! It's great to see you all again!"
    new "سلام همه! خوشحالم که دوباره همه رو می‌بینم!"

    # say L3010 bel
    old "I've been waiting for today's show more than ever!"
    new "من از همه جا منتظر این نمایش بودم!"

    # say L3011 bel
    old "Because I have yet another great surprise for you guys!"
    new "چون برای شما همه یک مفاجأه خوب دیگه دارم!"

    # say L3012 bel
    old "This is something you have been asking me about! And it's finally time for you guys to enjoy it."
    new "این چیزیه که شما از من پرسیده بودید! و الان وقت آن رسیده که شما از اون لذت ببرید."

    # say L3013 bel
    old "So, today I have with me a friend that's going to help us."
    new "پس، امروز یک دوست با من هست که می‌خواهد به ما کمک کند."

    # say L3014 bel
    old "I know you all know her because she's very popular, so please give a warm welcome to my friend Amorette!"
    new "میدونم همه شما ازش آشنایی دارید چون خیلی مشهوره، پس لطفاً به دوست من آمورت خوش آمد بگویید!"

    # say L3019 amo
    old "Hi guys! How are you?!"
    new "سلام همه! چطور هستی؟!"

    # say L3020 amo
    old "It's so nice to be here!"
    new "خوشحالم که اینجا هستم!"

    # say L3021 amo
    old "Oh, some of you know me from my stream?"
    new "اوه، بعضی از شما ممکن است از استریم من بشناسید؟"

    # say L3022 amo
    old "It's great to see you!"
    new "خوشحالم که تو رو می‌بینم!"

    # say L3023 amo
    old "I hope we'll have a very good time together today guys!"
    new "امیدوارم امروز وقت خوبی با هم بگذرانیم دوستان!"

    # say L3025 bel
    old "And of course, my friend from before is also here to help us!"
    new "و البته، دوستم از قبل هم اینجا هست تا به ما کمک کنه!"

    # say L3030 bel
    old "Well guys, it's time for me to tell you about the surprise I'd planned for you."
    new "خب بچه‌ها، الان وقتش رسیده تا به شما در مورد مفاجاتی که برای شما آماده کرده‌ام بگم."

    # say L3032 bel
    old "And it's that today we're having a threesome!"
    new "و این هم اینجاست که امروز ما سه‌نفره می‌شویم!"

    # say L3034 bel
    old "It's great right?"
    new "عالی نیست؟"

    # say L3035 amo
    old "Yey!"
    new "آهای!"

    # say L3037 bel
    old "Oh! We've all been waiting for this! Let's not delay it anymore!"
    new "اوه! همه ما منتظر این بودیم! بیایید دیگه تأخیر ندهیم!"

    # say L3038 bel
    old "So, remember to tip so that we can reach the goal!"
    new "پس، به خاطر داشت تا به هدف برسیم، باید نکات بدیم!"

    # say L3045 amo
    old "Oh wow, just look at that dick guys!"
    new "وای، فقط به اون نی خوب نگاه کنید دستا!"

    # say L3046 amo
    old "I saw it before on screen, but it's so much bigger in person!"
    new "قبلش روی صفحه نمایش دیدم، اما در واقع خیلی بزرگ‌تره!"

    # say L3047 bel
    old "It's great isn't it?"
    new "عالی نیست؟"

    # say L3064 bel
    old "Thanks guys, you are the best fans in the world!"
    new "ممنون دستانتون، شما بهترین طرفداران جهان هستید!"

    # say L3065 bel
    old "I'm very happy and proud of you!"
    new "من خیلی خوشحالم و افتخارم از شما!"

    # say L3066 bel
    old "I hope you enjoyed this threesome as much as we did."
    new "امیدوارم این سه‌نفره رو مثل ما لذت برده باشید."

    # say L3068 amo
    old "Belle is right guys!"
    new "بله، بله، بله! بله درست می‌گه دختران!"

    # say L3069 amo
    old "That was so hot!"
    new "این خیلی گرم بود!"

    # say L3072 amo
    old "You guys have been so nice!"
    new "شما دو تا خیلی لطف دارید!"

    # say L3074 amo
    old "It makes me think of coming back to stream with Belle again..."
    new "این به من ایده می‌ده که دوباره با بل بیایم جریان باشیم..."

    # say L3076 bel
    old "I know if Amorette comes back to stream with us, we will all enjoy it!"
    new "می‌دونم اگه آمورت با ما برگرده تا استریم کنه، همه ما لذت می‌بریم!"

    # say L3078 bel
    old "And of course, my friend here will be back as well!"
    new "و البته، دوست من هم بر می‌گرده!"

    # say L3080 bel
    old "Well, guys, that's all for today."
    new "خب، بچه‌ها، این همه برای امروز."

    # say L3081 bel
    old "Remember to subscribe to my profile and follow me on my social networks!"
    new "به یاد داشته باشید که به پروفایلم اشتراک بگیرید و من رو در شبکه‌های اجتماعی دنبال کنید!"

    # say L3082 bel
    old "And remember to follow Amorette as well."
    new "و همین‌طور به آمورت هم دقت کنید."

    # say L3083 bel
    old "She does some amazing things in her stream guys!"
    new "او در استریم‌اش چیزهای شگفت‌انگیزی می‌کنه دوستان!"

    # say L3085 amo
    old "Thanks for the warm reception guys!"
    new "ممنون از استقبال گرمتون بچه‌ها!"

    # say L3086 amo
    old "And thank you for having me Belle."
    new "و ممنونم که من رو دعوت کردی بله."

    # say L3087 amo
    old "See you later guys!"
    new "ببینم شما بعداً!"

    # say L3088 bel
    old "Bye guys!"
    new "بای دستاوردگان!"

    # say L3107 bel
    old "They really reached the goal in no time!"
    new "وای، واقعاً هدف رو تو زمان کوتاهی رسیدن!"

    # say L3108 bel
    old "Thanks a lot guys! I'm amazed it all went this well. And it's all thanks to you!"
    new "ممنون از همه شما! خیلی تعجب کردم که همه چیز اینقدر خوب پیش رفت. و همه این به خاطر شماست!"

    # say L3109 amo
    old "You're welcome Belle."
    new "خواهش می‌کنم بله."

    # say L3110 amo
    old "I'm very happy to help, and this is also good for my own stream."
    new "خوشحالم که کمک کردم، و این برای استریم من هم خوبه."

    # say L3111 amo
    old "It's great that you managed to reach the goal."
    new "خوشحالم که تونستی هدفت رو برسونی."

    # say L3112 amo
    old "And I love that I was able to meet you [pla]."
    new "و خوشحالم که تونستم تو رو ببینم [pla]."

    # say L3113 amo
    old "You definitely have to come to do one of my streams with me one of these days."
    new "حتماً باید یک روز به یکی از استریم‌هام بیایی."

    # say L3114 amo
    old "Just you and me, I'm sure you'll enjoy it."
    new "فقط تو و من، مطمئنم که لذت می‌بری."

    # say L3115 pla
    old "Uhh... Sure."
    new "اوه... حتماً."

    # say L3116 bel
    old "Ok, that's great."
    new "اوه، خوبه."

    # say L3117 bel
    old "Guys, my mom's coming home soon."
    new "بچه‌ها، مامان همین جا می‌رسه."

    # say L3118 bel
    old "So it would be better if you go."
    new "پس بهتره که بروی."

    # say L3121 amo
    old "Thanks again for having me Belle."
    new "ممنونم که منو دعوت کردی بله"

    # say L3122 amo
    old "I'll see you later."
    new "بعداً می‌بینیم."

    # say L3123 bel
    old "Sure, thanks for helping me."
    new "البته، ممنون از کمکت."

    # say L3131 pla
    old "I guess I'll see you later then."
    new "بعداً می‌بینیم."

    # say L3132 bel
    old "Of course, thank you, [pla]."
    new "البته، ممنونم، [pla]."

    # say L3133 bel
    old "I'm sure that with this, I can surpass Lana in the voting."
    new "با این مطمئنم می‌تونم لانا رو در رای‌گیری شکست بدم."

    # say L3134 bel
    old "And it's all because of you."
    new "و همه این‌ها به خاطر توست."

    # say L3135 pla
    old "Don't mention it, I know you've worked hard for it, so you deserve to win it."
    new "بگو نه، میدونم خیلی سخت کار کردی و به این دست آوردی، پس این جایگیری رو کاملاً مرتضایت هست."

    # say L3136 pla
    old "And I'm sure you will."
    new "و مطمئن هستم که تو خواهی."

    # say L3137 bel
    old "Thank you so much, [pla]!"
    new "ممنونم خیلی، [pla]!"

    # say L3138 pla
    old "Alright, I'll get going then. See you later."
    new "باشه، من هم می‌رم. بعداً می‌بینیم."

    # say L3154 pla
    old "Ok! I think I managed to finish it all."
    new "اوه! فکر کنم همه‌ش رو تمام کردم."

    # say L3156 ash
    old "That's great [pla]!"
    new "عالیه [pla]!"

    # say L3157 ash
    old "Can you show me?"
    new "می‌تونی به من نشون بدی؟"

    # say L3161 pla
    old "Here, this is the homepage, in here I just left information about the business."
    new "اینجا، این صفحه اصلیه، تو اینجا فقط اطلاعاتی در مورد کسب و کار گذاشتم."

    # say L3162 pla
    old "Their history and stuff."
    new "تاریخشون و اینا."

    # say L3164 pla
    old "If you press here it will take you to the menu."
    new "اگر اینجا بزنی، به منو می‌رسی."

    # say L3166 pla
    old "If you wish to make an order to pick up in advance, you can place it here."
    new "اگه می‌خوای سفارشت رو قبل از وقت برداشت درج کنی، می‌تونی اینجا بزاری."

    # say L3167 pla
    old "There's also an option for you to customize your order."
    new "همچنین می‌تونی سفارشتو شخصی‌سازی کنی."

    # say L3168 ash
    old "Oh! I see!"
    new "اوه! من می‌بینم!"

    # say L3170 pla
    old "Yeah, you can even select the coffee by level of roasting."
    new "بله، می‌تونی حتی درجه‌ی پختگی قهوه رو انتخاب کنی."

    # say L3171 pla
    old "Or you can even select the region where it comes from."
    new "یا می‌تونی منطقه‌ای که از آن آمده رو انتخاب کنی."

    # say L3173 ash
    old "This is really good work [pla]."
    new "این واقعاً کار خوبیه [pla]."

    # say L3174 ash
    old "This is better than what I have seen some professional web developers do."
    new "این بهتره از آنچه برخی توسعه‌دهندگان وب حرفه‌ای می‌کنن."

    # say L3176 ash
    old "I know you're not looking for a job right now."
    new "میدونم الان تو به دنبال شغلی نیستی."

    # say L3177 ash
    old "Because you have to do things with school and stuff."
    new "چون باید اشغالات مدرسه رو داری."

    # say L3179 ash
    old "But if you ever want to get into web developing, just let me know."
    new "اما اگر هر وقت خواستی به توسعه وب وارد شی، فقط به من بگو."

    # say L3180 ash
    old "I'm sure I'll be able to get you something good."
    new "مطمئنم چیز خوبی برایت پیدا می‌کنم."

    # say L3182 ash
    old "Also, if I ever need your help, I'll let you know."
    new "البته، اگر وقتی به کمکت نیاز داشتم، ازت می‌پرسم."

    # say L3184 ash
    old "Maybe you can give me a hand with something."
    new "شاید بتونی به من کمکی کنی."

    # say L3185 pla
    old "For sure! If I can help you with anything, just tell me, I'll do my best to help you any time I can."
    new "بله! اگر بتونم به تو کمک کنم، فقط به من بگو، همیشه آماده‌ام که به تو کمک کنم."

    # say L3191 pla
    old "I guess I'll leave for now Ashley. But I guess I'll see you later."
    new "باید حالا برسم آشلی. ولی احتمالاً بعداً دوباره می‌بینیم هم."

    # say L3196 ash
    old "Wait [pla]."
    new "پیش نرو [pla]."

    # say L3198 pla
    old "Yes ma'am?"
    new "بله خانم؟"

    # say L3199 ash
    old "Before you leave, I just wanted to take a second to thank you for all the help you've given me these days."
    new "قبل از برخاستن، فقط می‌خواستم یه لحظه بگذaram تا از کمک‌هایی که این روزها به من کردی، سپاس ببرم."

    # say L3201 ash
    old "I was in a very difficult situation, and with your help, I was able to solve it even better than I expected."
    new "من در موقعیت خیلی سختی بودم و با کمکت بیشتر از آنچه انتظار داشتم، توانستم اون رو حل کنم."

    # say L3202 pla
    old "I just wanted to help you, I'm happy I was able to do something."
    new "من فقط می‌خواستم به تو کمک کنم، خوشحالم که تونستم چیزی انجام بدم."

    # say L3203 ash
    old "And you really did, you're welcome here at our home any time you need."
    new "و تو هم واقعاً انجام دادی، خوشحالم که همیشه خوش آمدی به خانه‌مون."

    # say L3205 ash
    old "So thanks again [pla], I hope I'll see you again soon."
    new "پس ممنون دوباره [pla]، امیدوارم زودی دوباره ببینم تو."

    # say L3207 pla
    old "Sure ma'am, I'm sure we'll see each other soon."
    new "البته خانم، مطمئن هستم که زودی دوباره دیده‌ایم."

    # say L3208 pla
    old "Bye for now then."
    new "پس خداحافظ برای حالا."

    # say L3209 ash
    old "Bye [pla]."
    new "خداحافظ [pla]."

    # say L3230 pla
    old "Why do you look so down?"
    new "چرا به نظر می‌رسی اینقدر ناراحتی؟"

    # say L3232 bel
    old "Nothing bad, I'm just a little nervous."
    new "هیچ خبر بدی نیست، فقط کمی نگران هستم."

    # say L3236 bel
    old "Well, the results of the voting are coming out today."
    new "خب، نتایج رأی‌گیری امروز منتشر می‌شود."

    # say L3238 pla
    old "Already? It didn't take any time."
    new "البته. هیچ زمان طول نبرده."

    # say L3240 bel
    old "The contest was a bit longer. It's just that when we started streaming, we were already close to the deadline."
    new "مسابقه طولانی‌تر بود. فقط وقتی شروع به استریم کردیم، به مرز آستانه رسیده بودیم."

    # say L3242 pla
    old "Well, I hope that all the streaming we did helped you win."
    new "البته، امیدوارم همه آن استریم‌هایی که انجام دادیم به تو کمک کرده باشه."

    # say L3244 bel
    old "I don't know, I checked the voting before I went out today. Me and Lana were neck and neck."
    new "نمیدونم، رای‌گیری رو قبل از خروج امروز بررسی کردم. من و لانا هم‌تراز بودیم."

    # say L3245 bel
    old "I haven't seen anything else, I'll check it as soon as I get home."
    new "هیچ چیز دیگه ندیدم، همین الان که خونه برگشتم می‌چک کنم."

    # say L3246 bel
    old "So, I wanted to know if you want to accompany me this afternoon to check the results."
    new "پس، می‌خواستم بدونم آیا می‌خوای امسال همراه من بری برای چک کردن نتایج."

    # say L3248 pla
    old "Sure, I'll come with you."
    new "بله، همراهت می‌روم."

    # say L3249 bel
    old "Thank you [pla]. We can go to my house right after classes and check it."
    new "ممنون [pla]. می‌تونیم بعد از کلاس‌ها به خونه‌ام بریم و اونجا بررسی کنیم."

    # say L3250 pla
    old "For sure, let's go to class for now, and I'll come to your house with you when we're done."
    new "بله، حالا برویم به کلاس و بعد از پایانشون به خونه‌ت می‌رسم."

    # say L3281 bel
    old "I can't wait to see the results, but I'm also so nervous!"
    new "نمی‌تونم منتظر بقیه شمایی که نتایج رو ببینم، ولی همینجور ناراحت هم هستم!"

    # say L3282 pla
    old "Don't worry, everything will be fine. Let's get going so we can see the results at your place."
    new "نگران نباش، همه چیز خوب می‌شه. بیای برویم تا نتایج رو توی خونت ببینیم."

    # say L3283 bel
    old "Yes, yes, you're right... Let's go. I'll feel calmer there."
    new "بله، بله، درست می‌گی‌ی... برویم. اونجا آرام‌تر می‌شم."

    # say L3296 bel
    old "Ok, let's check how this all turned out."
    new "باشه، بیای ببینیم این همه چطور شده."

    # say L3302 pla
    old "You did?!"
    new "تو انجام دادی؟!"

    # say L3303 pla
    old "That's great Belle! Congrats!"
    new "عالیه بله! مبارک!"

    # say L3305 bel
    old "Thank you so much [pla]!"
    new "ممنونم خیلی [pla]!"

    # say L3307 bel
    old "This is all thanks to you!"
    new "این همه بخاطر توست!"

    # say L3308 pla
    old "What?! This is all because of you! You're the one that has been doing all the hard work."
    new "وای! همه اینا به خاطر توست! تو هستی که تمام کار سخت رو انجام دادی."

    # say L3309 pla
    old "Really Belle, congrats, you deserve this."
    new "حق باهاته بل، مبارک، این همه به تو برمی‌گردد."

    # say L3311 bel
    old "Well, it was impossible without you."
    new "البته، بدون تو امکان‌پذیر نبود."

    # say L3312 bel
    old "I have no way of repaying you [pla], this is just so great."
    new "من راهی برای تشکر از تو [pla] ندارم، این فقط خیلی عالیه."

    # say L3314 pla
    old "Really Belle, congratulations, you deserve that victory. And I'm happy I was able to help you. It makes me very happy."
    new "وای Belle، مبارکه، این پیروزی رو خوب کسب کردی. خوشحالم که بتونستم به تو کمک کنم. این برایم خیلی خوشحال کننده است."

    # say L3329 bel
    old "What do you mean by 'what's going on here?' And why are you barging into my room as if it's yours?"
    new "می‌خوای چی بگی با همین؟ و چرا مثل این می‌آیی اتاق من رو بیاد زنی که اونجوری خودت صاحبش می‌دانی؟"

    # say L3335 ash
    old "What the hell is happening?!"
    new "اوه، اینجا چه خبری هست؟!"

    # say L3337 bel
    old "Woah, woah, woah, where did you get that from?!"
    new "وای، وای، وای، اینو از کجا آوردی؟!"

    # say L3340 ash
    old "A coworker showed it to me! He caught his son using his credit card to send money to you on this website."
    new "یک همکار به من نشون داد! پسرش با کارت اعتباری پول به تو در این سایت فرستاده بود."

    # say L3342 ash
    old "He recognized you and decided to ask me if this was you!"
    new "او تو رو تشخیص داد و تصمیم گرفت از من بپرسه این آیا تو هستی!"

    # say L3344 ash
    old "Oh my gosh Belle! What the hell are you doing?"
    new "اوه خدای من بله! تو در حال انجام چه کاری هستی؟"

    # say L3346 ash
    old "Why are you asking for money from strangers on the internet?"
    new "چرا از افراد ناشناخته در اینترنت می‌خوای پول بگیری؟"

    # say L3348 ash
    old "If you needed money you could've told me!"
    new "اگه نیاز به پول داشتی می‌تونستی به من بگی!"

    # say L3350 ash
    old "And doing it this way! Oh my god!"
    new "و اینجوری! خدای من!"

    # say L3352 bel
    old "Wait a minute, what do you mean by {i}'doing it this way{/i}'?"
    new "بی‌پناه، منظورت از {i}این‌جوری انجام دادنش{/i} چیه؟"

    # say L3354 bel
    old "First of all, I'll let you know I'm not doing it for the money!"
    new "اول اینکه باید بدونی من برای پول این کار رو نمی‌کنم!"

    # say L3357 bel
    old "I'm doing it because I like it."
    new "من این کار رو می‌کنم چون دوست دارم."

    # say L3360 bel
    old "But even if I was doing it for money. What's wrong with me doing something like that?"
    new "اما حتی اگر برای پول انجام میدادم. این که من چیزی مثل این انجام بدم چه مشکلی داره؟"

    # say L3362 bel
    old "You're the one who's always telling me that I should just live my sexuality any way I can."
    new "تو همیشه می‌گی برام باید جنسیتمو مثلی که می‌خوام زندگی کنم."

    # say L3364 bel
    old "And that I shouldn't care about what people have to say about me."
    new "و اینکه من نباید نظرات مردم رو مهم بگیرم."

    # say L3367 ash
    old "That isn't the problem here!"
    new "این هم مشکل نیست!"

    # say L3369 ash
    old "You know that I'm just taking over my new role in the company!"
    new "می‌دونی که من در حال برآورده کردن نقش جدیدم تو شرکت هستم!"

    # say L3371 ash
    old "Imagine how I felt when my coworker told me his son is stealing money from him to give to my daughter for being naked online!"
    new "تخیل کن چطور احساس کردم وقتی همکارم به من گفت پسرش پول ازش می‌چرخوند تا به دخترم بده برای اینکه عریان تو اینترنت باشه!"

    # say L3372 ash
    old "This could bring problems to my image as the branch director of the company. The executives could fire me!"
    new "این می‌تونه به تصویرم به عنوان مدیر شعبه شرکت آسیب برسونه. اجرایی‌ها ممکنه من رو اخراج کنن!"

    # say L3374 bel
    old "And what do you want me to do? To not do it just because those assholes at your job might think bad about it?"
    new "و من باید چه کنم؟ فقط برای اینکه آن خراها در کار شما ممکن است بد بگن، نکنم؟"

    # say L3377 bel
    old "I'm sorry but I'm not doing that."
    new "ببخشید ولی من این کار رو نمی‌کنم."

    # say L3379 ash
    old "Oh my gosh could you be any more selfish?!"
    new "اوه خدای من، می‌تونی خودت رو همینجوری خودخواهان بیاندازی؟!"

    # say L3380 pla
    old "Ok, ok, why don't you two try to talk about this in a calmer way?"
    new "باشه، باشه، چرا دو تونه اینجوری با هم صحبت کنید که آرام‌تر باشه؟"

    # say L3381 pla
    old "Before either of you says anything that you may regret."
    new "قبل از اینکه هر یک از شما چیزی بگویید که ممکن است پشیمان شوید."

    # say L3385 ash
    old "I was thinking about who's the person in the video with Belle! It's you isn't it?"
    new "من فکر می‌کردم که شخصی در ویدیو با بل هستی! تو هستی نه؟"

    # say L3387 ash
    old "I'm so stupid!"
    new "من احمق هستم!"

    # say L3389 ash
    old "Here I was thinking that you were just a good friend of Belle!"
    new "من اینجا بودم فکر می‌کردم تو فقط دوست خوبی از بل هستی!"

    # say L3390 ash
    old "Someone whom I could trust, and here doing this!"
    new "کسی که می‌تونستم بهش اعتماد کنم، و الان اینجوری!"

    # say L3391 ash
    old "And in my house, of all places!"
    new "و در خونه‌ام هم، از همه جا!"

    # say L3393 bel
    old "Wait a minute! Don't involve him in this!"
    new "بی‌پناه! اینو بهش متصل نکن!"

    # say L3394 bel
    old "He was just helping me, and it's something that I wanted to do and there's nothing wrong with it!"
    new "او فقط به من کمک می‌کرد و این کاری بود که من می‌خواستم انجام بدم و هیچ اشکالی در اون نیست!"

    # say L3396 ash
    old "Oh yeah? Well, I'm sorry you want to do it so badly because you're about to stop!"
    new "اوه همین‌جوری؟ خب، متاسفم که اینقدر می‌خوای انجام بدی، چون الان قراره توقف بدهی!"

    # say L3397 ash
    old "I already told you, the people at my company are not okay with this!"
    new "من قبلاً به تو گفتم، مردم شرکتم با این موافقت ندارن!"

    # say L3399 ash
    old "So, unless whatever money you're making with that is enough for you to pay for everything around here!"
    new "پس، مگر پولی که از اونجوری می‌بری برای همه چیزهای اینجا کافیه!"

    # say L3400 ash
    old "You're about to stop with this weird little hobby of yours!"
    new "تو قراره این هواپردازی کوچیکت رو ترک کنی!"

    # say L3402 bel
    old "You have to be kidding me!"
    new "باید شوخی کنی!"

    # say L3403 bel
    old "Well I'm sorry, but I'm not going to stop doing anything! And if you don't like me doing it in your house then I guess I can leave!"
    new "خب ببخشید، ولی من نمی‌تونم هیچ کاری رو توقف بدم! و اگه خوشت نیومه که من این کار رو توی خونت انجام بدم، حدس می‌زنم باید برسم!"

    # say L3405 ash
    old "Then I guess you can!"
    new "پس می‌تونی!"

    # say L3407 bel
    old "I'll do it then!"
    new "من انجام می‌دم!"

    # say L3415 pla
    old "Wait! Belle!"
    new "بیل!"

    # say L3419 pla
    old "I- uh..."
    new "من- اوه..."

    # say L3420 pla
    old "I- I'm sorry!"
    new "من- من عذرخواهم!"

    # say L3445 bel
    old "Hey, I guess I'm doing ok."
    new "بله، به نظر می‌رسه که حالت خوبه."

    # say L3447 bel
    old "I left my mom's house, so at least she's not annoying me or anything."
    new "من از خونه مامانم بیرون آمدم، پس حداقل او دیگه منو آزار نمی‌ده."

    # say L3448 pla
    old "W- what? You actually left your home?"
    new "و- وای، واقعاً از خونه‌ت بیرون آمدی؟"

    # say L3450 bel
    old "I did, what else was I supposed to do?"
    new "بله، من اینجوری کنم چه برامون باقی مونده؟"

    # say L3451 bel
    old "I'm not going to stop streaming just to give her the pleasure."
    new "من نمی‌تونم فقط برای اینکه اونا خوشحال شه، استریم رو متوقف کنم."

    # say L3452 bel
    old "This is too important for me, no matter what she says."
    new "این برای من خیلی مهمه، بی‌اهمیه اینکه او چه می‌گه."

    # say L3454 pla
    old "I see, I'm sorry Belle; I feel like I caused this."
    new "بelle، من متوجه هستم؛ خودت را متأسف می‌کنم؛ به نظر می‌رسد این اتفاق برای من افتاده."

    # say L3455 bel
    old "Don't worry, this isn't your fault. It was bound to happen sooner or later."
    new "نگران نباش، این اشتباه تو نیست. قرار بود به زودی یا دیر اتفاق بیفتد."

    # say L3456 pla
    old "I guess."
    new "خوب."

    # say L3457 pla
    old "So, where are you staying now?"
    new "پس، حالا تو کجایی مونده؟"

    # say L3459 bel
    old "I'm staying at Amorette's apartment."
    new "من توی آپارتمان آمورت هستم."

    # say L3460 bel
    old "It's really nice because she has an entire room where we can stream."
    new "این خیلی خوبه، چون او یک اتاق کامل برای استریمینگ داره."

    # say L3461 bel
    old "By the way, she says that you're welcome to come to visit anytime you want."
    new "البته، او می‌گه که تو هر وقت خواستی می‌تونی بیاد ملاقاتش کنی."

    # say L3462 pla
    old "I see... Well, thank you I guess."
    new "ممنونم، حدس می‌زنم."

    # say L3463 pla
    old "Leaving aside her offer."
    new "پیشنهادش رو یاد بگیریم."

    # say L3465 pla
    old "I hope things will be fixed between you and your mom soon."
    new "امیدوارم بین تو و مامانتون زودی همه چی جا افتاده بشه."

    # say L3467 bel
    old "Thanks... But I wouldn't count on it."
    new "ممنون... ولی نمی‌تونم روی این بحساب بیارم."

    # say L3468 bel
    old "Listen, I have a couple of things to do now, so I'll see you later, ok?"
    new "بگوش، الان چند کار دارم، پس بعداً می‌تونیم ببینیم، خوبه؟"

    # say L3469 pla
    old "Yeah, see you."
    new "بله، بعداً می‌بینیم."

    # say L3475 pla
    old "Damn, things between them really went out of whack."
    new "حالتون واقعاً خراب شد، همه چیز بین اونا خارج از کنترل رفت."

    # say L3476 pla
    old "Maybe I could do something to help them."
    new "شاید بتونم چیزی بکنم تا بهشون کمک کنم."


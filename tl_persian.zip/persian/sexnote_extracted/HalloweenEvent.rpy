# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/HalloweenEvent.rpy
translate persian strings:

    # say L10 pla
    old "Uhh, I didn't sleep well last night... I should drink a cup of water... "
    new "اوه، فکر کنم شب گذشته خوب خواب نبردم... باید یه لیوان آب بخورم..."

    # say L25 mo1
    old "Oh, hi honey, good morning!"
    new "اوه، سلام عزیزم، صبح بخیر!"

    # say L26 pla
    old "Uhh, good morning..."
    new "اوه، صبح بخیر..."

    # say L27 mo1
    old "Do you have everything ready for tonight?"
    new "آماده‌ات برای امسال رو داری؟"

    # say L28 pla
    old "T- onight?"
    new "ش- شب؟"

    # say L29 mo1
    old "The halloween party is tonight... Don't you have your costume already?"
    new "جشن هالووین امروز شب است... لباس ماسک خودت رو قبلاً آماده نکردی؟"

    # say L30 pla
    old "Ohh... Right, I completely forget about that... Ehmm no, actually I don't have a costume yet..."
    new "اوه... درسته، کاملاً فراموش کرده بودم... اهمم نه، در واقع هنوز لباس ندارم..."

    # say L31 mo1
    old "Oh, don't worry, Talk with [sis], she was the one who got us our costumes, she could have one for you too."
    new "اوه، نگران نباش، با [sis] صحبت کن، او همون بود که لباس‌های ما رو آورد، ممکنه برایت هم یکی داشته باشه."

    # say L32 pla
    old "Oh, great, I'm going to talk with her. Thank you!"
    new "اوه، عالی، من هم باهاش حرف می‌زنم. ممنون!"

    # say L33 mo1
    old "You are welcome honey."
    new "خواهش می‌کنم عزیزم."

    # say L48 pla
    old "Ohhh... Wow..."
    new "اوه... وایی..."

    # say L52 sis
    old "Ohh, hey [pla]! How do I look with this costume?"
    new "اوه، سلام [pla]! با این لباس چطور به نظر می‌رسم؟"

    # say L54 sis
    old "Where is your [mo1rel]?"
    new "چه جای [mo1rel]؟"

    # say L56 sis
    old "Where is [mo1]?"
    new "[mo1] کجاست؟"

    # say L57 pla
    old "Hmm she is in the kitchen... Why?"
    new "همم، توی آشپزخانه هست... چرا؟"

    # say L58 sis
    old "Perfect. Do you wanna see the fun thing about this costume?"
    new "پرفکت. می‌خوای ببینی چیز جالب این لباسه؟"

    # say L59 pla
    old "The fun... Thing? What do you mean?"
    new "چیز خنده‌دار... چی؟ منظورت چیه؟"

    # say L60 sis
    old "Hahaha, you are going to love it!"
    new "حاحاحا، اینو دوست خواهی داشت!"

    # say L61 pla
    old "Hmm a- alright..."
    new "Hmm خب..."

    # say L62 sis
    old "Well, I chose this costume for just one reason, it has a tail. Do you see it?"
    new "خب، من این لباس رو فقط به یه دلیل انتخاب کردم، دم داره. می‌بینی؟"

    # say L63 pla
    old "Hmm... Yes."
    new "Hmm... بله."

    # say L64 sis
    old "Ok, now I'm going to take it out."
    new "خب، حالا من اونو بیرون می‌برم."

    # say L65 pla
    old "You are going to wha-"
    new "می‌خوای چی کار کنی-"

    # say L72 sis
    old "I wanted something like this from a long time ago... Did you know I have never try anal sex?"
    new "از زمانی که این را می‌خواستم... می‌دونی هیچ وقت سکس آنال نکرده‌ام؟"

    # say L77 sis
    old "Well I wanna change that today... I want you to fuck my ass..."
    new "خب من می‌خوام امروز این رو تغییر بدم... می‌خوام تو خرونشو بزنی..."

    # say L88 sis
    old "Uhhh [pla], do it gently... Is my first time..."
    new "اوه ز[pla]، لطفاً آرام‌آرام... این اولین بارم..."

    # say L102 sis
    old "Wow, it was better than I thought, and your big cock didn't hurt me at all..."
    new "واو، بهتر از آنچه فکر می‌کردم بود و لولت بزرگت هیچ جور درد نداد..."

    # say L103 pla
    old "I did it gently..."
    new "من آرام‌آرام انجام دادم..."

    # say L104 sis
    old "Definitely we need to repeat it."
    new "حتماً باید این رو تکرار کنیم."

    # say L105 pla
    old "Uhh... O- ok."
    new "اوه... او- اونه."

    # say L106 sis
    old "Anyway, I have work, see you later [pla]."
    new "بازهم، من کار دارم، بعداً می‌بینیم [pla]."

    # say L107 pla
    old "Wait... Hmm I came, because I need a halloween costume."
    new "بیا... نه، همینجوری اومدم، چون لباس هالووینی رو نیاز داشتم."

    # say L108 sis
    old "Ohh, your costume? Is in your bedroom."
    new "اوه، لباس تو تو اتاق خوابت هست."

    # say L109 pla
    old "Oh really?"
    new "اوه واقعاً؟"

    # say L110 sis
    old "Yes, I left it there a few minutes ago."
    new "بله، چند دقیقه پیش آن را اونجا گذاشتم."

    # say L111 pla
    old "Ohh, thank you so much."
    new "اوه، ممنونم خیلی."

    # say L112 sis
    old "You're welcome. You will like that costume, it's perfect for you."
    new "خواهش می‌کنم. اون لباس را می‌پسندی، برایت کاملاً مناسبه."

    # say L113 pla
    old "Hmm... Alright."
    new "Hmm... خب."

    # say L126 pla
    old "Uhh, yes."
    new "اوه، بله."

    # say L127 mo1
    old "Hmm could you please come for a minute?"
    new "می‌تونی لطفاً یه دقیقه بیاد؟"

    # say L137 pla
    old "Ohhh wow!"
    new "اوه وای!"

    # say L138 mo1
    old "I'm sorry... Is just that this costume is a bit hard to dress up... Could you please help me with that?"
    new "ببخشید... فقط این لباس کمی سخت برای پوشیدن است... می‌تونی به من کمک کنی؟"

    # say L139 pla
    old "Uhh... S- sure."
    new "اوه... ح- حتماً."

    # say L140 mo1
    old "Thank you. You are a sweetheart!"
    new "ممنون. تو یک عزیزم!"

    # say L141 pla
    old "Ok... Let's see..."
    new "خب... بیایم ببینیم..."

    # say L146 pla
    old "Well, I think is done..."
    new "خب، فکر کنم تمام شده..."

    # say L151 mo1
    old "Oh, it's perfect just like in the box picture!"
    new "اوه، این هم مثل عکس جعبه کامله!"

    # say L152 mo1
    old "Oh, wait... It doesn't cover up my nipples at all..."
    new "اوه، بی‌چین... هیچ جور نمی‌تونه نیم‌تنه‌ام رو پوشونه."

    # say L155 mo1
    old "Maybe it is a bit small for me...  What do you think [pla]?"
    new "شاید برای من کمی کوچک باشه... تو چه می‌گی [pla]؟"

    # say L161 pla
    old "(Oh God, I just had sex! How can I get this horny again?..."
    new "اوه خدا، من همین الان جنس کردم! چطور می‌تونم دوباره اینقدر خیال‌پرداز شوم؟"

    # say L163 mo1
    old "[pla]? Are you-... Oh, you got hard-"
    new "[pla]؟ تو-... اوه، سخت شدی-"

    # say L164 pla
    old "Sorry... I didn't mean to-"
    new "ببخشید... من قصد نداشتم-"

    # say L165 mo1
    old "Oh, honey don't worry... You got hard for my tits?"
    new "اوه، عزیزم نگران نباش... تو برای سینام سخت شدی؟"

    # say L168 mo1
    old "Ok, what about if I help you with them?"
    new "خوب، چطور اگر من به تو با اونها کمک کنم؟"

    # say L170 mo1
    old "Get naked and let me return you the help."
    new "بله، خودت را عریان کن و بگذار من به تو کمک کنم."

    # say L178 mo1
    old "Do you like my boobs honey?"
    new "حلاوت سینام رو دوست داری عزیزم؟"

    # say L179 pla
    old "Uhh.... Y- yes... I love your boobs."
    new "اوه.... ب- بله... من عاشق سینات تو هستم."

    # say L180 mo1
    old "Then fuck them!"
    new "پس از آنها بفرمای!"

    # say L196 mo1
    old "Do you feel better now honey?"
    new "الان حس می‌کنی بهتر شدی عزیزم؟"

    # say L197 pla
    old "Y- yes... Thank you."
    new "بله... ممنون."

    # say L198 mo1
    old "No, thanks to you for your help with this costume. By the way did you talk with [sis]?"
    new "نه، ممنون از کمکت با این لباس. بین‌ها با [sis] حرف زدی؟"

    # say L199 pla
    old "Uhh... W- with [sis]..."
    new "اوه... با [sis]..."

    # say L200 mo1
    old "Yes, about your costume."
    new "بله، درباره لباست."

    # say L201 pla
    old "Ohhh the costume, right... Yes, I have it in my bedroom, I need to try it"
    new "اوه لباس، درسته... بله، توی اتاق خوابم هست، باید آن را امتحان کنم"

    # say L202 mo1
    old "Oh great, then go, if you need any help just let me know. Now I'm going to clean this mess."
    new "عالی، برو، اگر نیاز به کمکی داشتی فقط به من بگو. حالا من می‌روم این درهم‌دستی رو تمیز کنم."

    # say L203 pla
    old "Alright, Thank you."
    new "البته، ممنون."

    # say L208 pla
    old "(Alright, I should try the costume.)"
    new "باشه، باید لباس ماسک رو امتحان کنم."

    # say L213 pla
    old "Hmm, it looks a bit weird... What is this? Maybe I'm doing something wrong, I better ask [sis]."
    new "Hmm، به نظر یه جور عجیب می‌رسه... این چیه؟ شاید چیزی اشتباه کردم، بهتره از [sis] بپرسم."

    # say L229 pla
    old "Hey, I was looking for you."
    new "سلام، داشتم به تو می‌گردم."

    # say L230 sis
    old "Oh, you have your costume! You look great!"
    new "اوه، لباس نمایشیت رو داری! خیلی خوب هستی!"

    # say L231 pla
    old "Thank you, but I was wondering what is t-"
    new "ممنون، ولی می‌خواستم بدونم چه کاری هست..."

    # say L232 sis
    old "Hmm your costume is not ready..."
    new "همم، لباس تو هنوز آماده نیست..."

    # say L234 sis
    old "You need to get hard to fill the snake."
    new "تو باید سخت شوی تا مار رو پر کنی."

    # say L235 pla
    old "F- fill the snake? "
    new "ف- پر کردن مار؟"

    # say L236 sis
    old "You always have to be that slow?"
    new "همیشه باید اینقدر آهسته باشی؟"

    # say L238 sis
    old "Alright, let me give you a blowjob to make you hard-"
    new "باشه، بیای اجازه بدم بهت جنسی کنم تا سخت بشی-"

    # say L245 mo1
    old "Hi guys, what are you doing?"
    new "سلام، چه کار می‌کنید؟"

    # say L247 pla
    old "(Oh shit...)"
    new "اوه شیطون..."

    # say L248 sis
    old "Well, [pla] needs help with his costume..."
    new "خوب، ز[pla] نیاز به کمک برای لباسش داره..."

    # say L249 mo1
    old "Oh really, what does he need?"
    new "اوه واقعاً، چه کاری بهش لازم است؟"

    # say L250 sis
    old "He needs to get hard to fill his costume."
    new "او باید سخت شه تا لباسش رو پر کنه."

    # say L253 mo1
    old "Oh, the snake will become to anaconda?"
    new "اوه، مار به آناکوندا تبدیل می‌شه؟"

    # say L255 pla
    old "(What the hell!?)"
    new "چه خبر!؟"

    # say L256 sis
    old "Exactly! I was thinking in a blowjob. What do you think?"
    new "دقیق هست! من فکر می‌کردم به یک جنسی. تو چه فکر می‌کنی؟"

    # say L258 mo1
    old "What about a double blowjob, I think that would make him hard for all night!"
    new "دیوبل جنسی چطور؟ فکر کنم این به او برای تمام شب سخت می‌کنه!"

    # say L260 pla
    old "(WHAT THE FUCK IS GOING ON?!)"
    new "چه خبری اینجا رخ می‌دهد؟!"

    # say L261 sis
    old "Great idea!"
    new "ایده خوبی!"

    # say L265 pla
    old "Uhh...  W- what is happening?"
    new "اوه... چ- چه کاری انجام می‌شود؟"

    # say L266 mo1
    old "Hahaha, let's show him what is happening [sis]..."
    new "حاحاحا، بیایید بهش نشون بدیم چه کاری انجام شده ز[sis]..."

    # say L291 pla
    old "OHHHH SHITT...."
    new "اوه شیطان..."

    # say L293 mo2
    old "I- I REALLY CAN BELIEVE IT..."
    new "من- من واقعاً باور می‌کنم..."

    # say L294 pla
    old "(OH GOD I'M DEAD.)"
    new "اوه خدا، من مرده‌ام."

    # say L295 mo2
    old "I can't believe all of you started the party without me..."
    new "نمی‌تونم باور کنم همه شما بدون من مهمانی رو شروع کردید..."

    # say L296 pla
    old "WHAAAAATTT...."
    new "واییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییییی"

    # say L297 mo1
    old "There is more for you too..."
    new "برای تو هم بیشتری هست..."

    # say L299 sis
    old "We will give you the best spot."
    new "ما بهت بهترین جایگاه رو میدیم."

    # say L301 mo2
    old "And what are we waiting for? Let's enjoy!"
    new "و منتظر چی هستیم؟ بیایید لذت ببریم!"

    # say L314 mo1
    old "This is just a halloween party..."
    new "این فقط یک جشن هالووین است..."

    # say L315 sis
    old "Don't you want to join us?"
    new "می‌خواهی با ما هم شرکت کنی؟"

    # say L316 mo2
    old "You can't lose this chance..."
    new "شанс خودت رو از دست نده..."

    # say L317 pla
    old "... What the hell... Let's do it!"
    new "... چه کاری... بیایید انجام بدیم!"

    # say L326 pla
    old "Oh God... I can't anymore"
    new "اوه خداوند... دیگه نمی‌تونم"

    # say L330 sis
    old "Hey [pla], we want to keep fucking."
    new "هی ز[pla]، ما می‌خوایم ادامه بدهیم."

    # say L331 pla
    old "Hmm... I- I just can't... I'm really tired..."
    new "همم... من- من فقط نمی‌تونم... خیلی خسته‌ام..."

    # say L332 mo1
    old "Oh no honey, you don't understand."
    new "اوه نه عزیزم، تو متوجه نشده‌ای."

    # say L333 mo2
    old "You fucked us, now is our turn to fuck you."
    new "تو ما رو فریب دادی، حالا دوره ما برای فریب دادنت."

    # say L339 sis
    old "We want to fuck you..."
    new "ما می‌خوایم تو رو بکنیم..."

    # say L340 mo1
    old "Just like you did..."
    new "مثل آنچه تو انجام دادی..."

    # say L341 mo2
    old "We are going to drill you."
    new "ما قصد داریم تو رو بکنیم."

    # say L350 pla
    old "Wow... It was just a nightmare... Thank God."
    new "وای… فقط یه کابوس بود… خواهشکردم."

    # say L351 pla
    old "Hmm... Actually it wasn't a nightmare at all..."
    new "Hmm... در واقع هیچ کابوسی نبود..."


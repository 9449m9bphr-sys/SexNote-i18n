# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/shiAnimations.rpy
translate persian strings:

    # say L45 pla
    old "And... Who are you?"
    new "و... تو کی هستی؟"

    # say L47 dev
    old "Wow, can you see me? So it was true. Interesting... "
    new "واو، می‌تونی من رو ببینی؟ پس اینجوری درست بود. جالب..."

    # say L50 dev
    old "You are the human with Agamoto's Eye?"
    new "تو انسانی هستی که چشم آگاموتو رو داری؟"

    # say L51 pla
    old "Yes... and you... are you a... shinigami?"
    new "بله... و تو... شینیگامی هستی؟"

    # say L53 dev
    old "Yes! This is the first time I've met a human."
    new "بله! این اولین باره که با انسان آشنا می‌شوم."

    # say L54 pla
    old "Ok... So, do you know the shinigami of the other night?"
    new "خب... پس تو می‌دونی شینیگامی آن شب رو؟"

    # say L56 dev
    old "You mean Mildret?"
    new "من می‌خوایم به میلدرت اشاره کنم؟"

    # say L57 pla
    old "I don't know her name, but she also sucked up my magical power..."
    new "من اسمش رو نمی‌دونم، اما او هم قدرت جادویی من رو خورده..."

    # say L59 dev
    old "Yes, then you talk about Mildret  hehehe."
    new "بله، بعدش درباره میلدرت حرف می‌زنی هههه."

    # say L60 pla
    old "Are there more shinigami, besides Mildret and... you?"
    new "آیا شینیگامی‌های دیگری هست، غیر از میلدرت و... تو؟"

    # say L62 dev
    old "Yes we are only three and I am Devonne. Nice to meet you!"
    new "بله، ما فقط سه تا هستیم و من دیون هستم. خوشحالم که با تو آشنا شدم!"

    # say L63 pla
    old "Nice... to... meet... you. My name is [pla]..."
    new "خوشحالم... که... آشنا شدم. نامم [pla]..."

    # say L65 dev
    old "Wow, [pla]? What strange names humans have... hahaha."
    new "واو، [pla]؟ نام‌های عجیبی هستند انسان‌ها... هاهاها."

    # say L66 pla
    old "You're not mad at me?"
    new "تو از من خشمانت نیست؟"

    # say L68 dev
    old "Me? No... Why would I be?"
    new "من؟ نه... چرا باید خشمانت باشم؟"

    # say L69 pla
    old "Because Mildret accused me of stealing magical power..."
    new "چون میلدرت منو متهم کرد که توان جادویی رو پیچونده‌ام..."

    # say L71 dev
    old "Ohhh you mean that... Well, there has been someone who has been gathering the magical power in this area and we think it's you... Is it you?"
    new "اوه آره منظورت اینه... خب، داریم فکر می‌کنیم کسی قدرت جادویی رو تو این منطقه جمع کرده و فکر می‌کنم تو هستی... آیا تو هستی؟"

    # say L72 pla
    old "Well, yes... But..."
    new "خب، بله... اما..."

    # say L74 dev
    old "Ohhh... Then it's true, You are the thief... And you were starting to like me... I better go before you take away the little I recovered..."
    new "اوه... پس این جوریه، تو حقاً دزدی... و تو شروع کردی به دوست داشتن من... بهتره قبل از اینکه همه چیز رو بگیری، برم..."

    # say L77 pla
    old "No,wait!"
    new "نه، بیا بیشتر!"

    # say L78 pla
    old "Hmm... Again... And they are three huh?"
    new "Hmm... دوباره... و این بار سه تا هستند."

    # say L98 pla
    old "So, did you get enought magic power?"
    new "پس، به قدر کافی توان جادویی گرفتی؟"

    # say L100 dev
    old "Yeay! Thank you so much..."
    new "耶！非常感谢你..."

    # say L101 pla
    old "Don't worry, I just wanna help you..."
    new "نگران نباش، فقط می‌خوام به تو کمک کنم..."

    # say L103 dev
    old "You are the best!"
    new "تو بهترین هستی!"

    # say L105 dev
    old "Well I have to go... Goodbye, [pla]"
    new "خوب من باید برسم... خداحافظ، [pla]"

    # say L171 pla
    old "I hoped you wouldn't steal more magical power..."
    new "امیدوار بودم تو دیگه قدرت جادویی نمی‌سرقت..."

    # say L173 dev
    old "You destroyed the magical world!!!"
    new "تو جهان جادویی رو نابود کردی!!!"

    # say L176 dev
    old "You are the worst being in the universe!..."
    new "تو بدترین موجود در کیهان هستی!"

    # say L177 pla
    old "I don't understand... Why do you say that?..."
    new "من نمی‌فهمم... چرا اینجوری می‌گی؟"

    # say L179 dev
    old "You have already done a lot of damage, and now you want to make us disappear by talking away the magical power... Leave us alone, once and for all..."
    new "تو قبلاً خیلی آسیب وارد کردی، و حالا می‌خوای با حرف زدن قدرت جادویی رو برداری و ما رو از بین ببری... برامون رها باش، یه بار برای همیشه..."

    # say L182 pla
    old "... What the hell?..."
    new "چه خرابی؟"

    # say L272 dev
    old "Oh boy, there is nothing more fun than sharing magical power."
    new "اوه بچه، هیچ کاری سرگرم‌تر از اشتراک قدرت جادویی نیست."

    # say L274 pla
    old "I'm glad you feel good, you can still count on receiving magical power when you need me, you can go when you want it..."
    new "خوشحالم که حس خوبی داری، هنوز می‌تونی وقتی به من نیاز داری قدرت جادویی رو دریافت کنی، می‌تونی برو وقتی می‌خوای..."

    # say L276 dev
    old "Do not hesitate..."
    new "با تردید نکن..."

    # say L278 pla
    old "Well, I must go now, I'm glad I closed the deal and finished everything in good terms..."
    new "خب، باید حالا برسم، خوشحالم که توافق را بستم و همه چیز رو به خوبی تمام کردم..."

    # say L280 dev
    old "[pla], take care of Brixxida, she's not what she seems..."
    new "[pla]، به بریکسیدا نگاهت باش، او همچون ظاهرش نیست..."

    # say L282 pla
    old "Yes, I'll be careful..."
    new "بله، مراقب خودت با..."

    # say L284 dev
    old "Okay..."
    new "اوه..."

    # say L306 dev
    old "Yeay! really fun... right?..."
    new "耶！真的很好玩……对吧？…"

    # say L308 pla
    old "Haha right, it was fun."
    new "هahaha درسته، خوشحالم بود."

    # say L310 dev
    old "Ok, I'm going to collect more magic power to do it again..."
    new "خب، من می‌خوام توانایی جادویی بیشتری جمع کنم تا دوباره انجام بدم..."

    # say L312 pla
    old "Just take it easy... Ok?"
    new "بی‌نگران... خوب؟"

    # say L314 dev
    old "Ok, ok..."
    new "باشه، باشه..."

    # say L421 pla
    old "(Perfect, I must use Sauron's mouth) {b}Sauron's mouth!{/b}"
    new "پرفکت، باید از دهان ساورون استفاده کنم {b}دهان ساورون!{/b}"

    # say L422 pla
    old "Tell me your name shinigami!"
    new "اسمتو بگو شینیگامی!"

    # say L424 gom
    old "My name is Gomory..."
    new "اسم من گوموری است..."

    # say L426 pla
    old "Hmmm... Do you know Devonne and... Mildret? "
    new "همم... آیا دوون و میلدرت رو می‌شناسی؟"

    # say L428 gom
    old "Yes, they are two allied shinigamis..."
    new "بله، آنها دو شینیگامی همکار هستند."

    # say L430 pla
    old "Why are you stealing magic power from me?"
    new "چرا از من قدرت جادویی می‌چرایی؟"

    # say L432 gom
    old "You have been collecting magical power from this area, which has left us with few reserves... and soon we'll not enough to exist."
    new "تو از این منطقه قدرت جادویی جمع کرده‌ای که برای ما باقی نمونده چندان کمی هست... و به زودی برای وجود کافی نخواهد بود."

    # say L434 gom
    old "I should go... I've said enough..."
    new "باید برم... کافیه گفتم..."

    # say L435 pla
    old "No, no, wait! I didn't know I was taking magic power from you..."
    new "نه، نه، بیا بیا! نمی‌دونستم از تو قدرت جادویی می‌برم..."

    # say L438 gom
    old "Well, actually, it is not the magic power from us. It's just that there is less and less in the area."
    new "در واقع، این قدرت جادویی از ما نیست. فقط در منطقه کمتر و کمتر شده."

    # say L439 gom
    old "I think we will soon cease to exist because there will be no more..."
    new "فکر می‌کنم زودی خواهیم از بین رفت چون قدرت جادویی دیگر وجود نخواهد داشت..."

    # say L442 gom
    old "And you do not need the magic power to exist..."
    new "و تو نیازی به قدرت جادویی برای وجود نداری..."

    # say L445 pla
    old "Ohhh... I understand perfectly... I didn't know... I mean, I knew it, but I didn't know you existed..."
    new "اوه... من کاملاً متوجه شدم... نمی‌دونستم... منظورم اینه که می‌دونستم، اما نمی‌دونستم تو وجود داری..."

    # say L447 gom
    old "Well, you already know... It is not something that makes much difference. At some point all the magical power will end and we will disappear..."
    new "خب، تو قبلاً می‌دونی... این چیزی نیست که خیلی تفاوت بکنه. در نهایت تمام قدرت جادویی تمام می‌شه و ما ناپدید می‌شیم..."

    # say L448 pla
    old "What about the 'Chosen One'? Who will rebuild the magical world? "
    new "و اون «انتخاب شده»؟ کی جهان جادویی رو دوباره سازه؟"

    # say L450 gom
    old "It's a myth... No one really thinks that will happen since years have passed... Anyway... I'm leaving..."
    new "این یک افسانه است... هیچ‌کس واقعاً نمی‌فکری که این اتفاق بیفتد چون سال‌ها گذشته... هر حال... من می‌روم..."

    # say L453 pla
    old "But... Hmm... Now I understand... I have to talk with Brixxida"
    new "ولی... هم... حالا فهمیدم... باید با بریکسیدا صحبت کنم"

    # say L473 pla
    old "Well, did you get enough magic power?"
    new "خب، آیا قدرت جادویی کافی رو به دست آوردی؟"

    # say L475 gom
    old "Yes, I have enough for now..."
    new "بله، برای حالا کافیه..."

    # say L476 pla
    old "Ok, you can come anytime if you need more..."
    new "باشه، اگر نیاز به بیشتری داشتی هر وقت می‌تونی بیاد..."

    # say L478 gom
    old "Ok, thanks. I have to go."
    new "باشه، ممنون. باید برسم."

    # say L543 gom
    old "Damn, you left me with too little energy..."
    new "لعنتی، تو مرا با انرژی خیلی کم گذاشتی..."

    # say L547 pla
    old "Answer me, why do you say that I destroyed the magical world?"
    new "پاسخ بده، چرا می‌گی من نابود کردم جهان جادویی؟"

    # say L549 gom
    old "You are the owner of the SexNote, who destroyed the magical world..."
    new "تو صاحب SexNote هستی، تو جهان جادویی رو نابود کردی..."

    # say L552 pla
    old "What? But I didn't..."
    new "چه؟ ولی من نه..."

    # say L554 pla
    old "How was the magical world destroyed? "
    new "چطور جهان جادویی نابود شد؟"

    # say L556 gom
    old "A powefull being who possessed the SexNote, performed a forbidden spell that caused the magical world to collapse..."
    new "یک موجود قدرتمند که صندلی سکس نوت رو در اختیار داشت، یه جادوی ممنوعه انجام داد که باعث شد جهان جادویی ور بیفتاد..."

    # say L559 pla
    old "What the fuck?..."
    new "چه فکر می‌کنی؟"

    # say L564 bri
    old "Thieves!! Stop stealing the magic power!"
    new "دزد‌ها!! متوقف شید از سرقت انرژی جادویی!"

    # say L567 gom
    old "We have little magic energy left for Mildret and me... Don't attack us anymore..."
    new "برای میلدرت و من مقدار کمی انرژی جادویی باقی مونده... دیگه ما رو حمله نکن..."

    # say L569 bri
    old "You must die! I will finish you!"
    new "باید بمیری! من قطع می‌کنم!"

    # say L573 pla
    old "What are you doing!?"
    new "تو چه کاری می‌کنی!؟"

    # say L575 bri
    old "I'm trying to make them not bother you again..."
    new "من سعی می‌کنم آنها دیگر به تو آزار ندهند..."

    # say L577 pla
    old "I was getting information... You chased her away..."
    new "من اطلاعات می‌گرفتم... تو اونا رو می‌راندی..."

    # say L579 bri
    old "Sorry, I am upset about the magical power that was stolen from us..."
    new "ببخشید، از دست ما توانایی جادویی گرفته شده..."

    # say L581 pla
    old "But... Why did you do that?"
    new "ولی... چرا اینجوری کردی؟"

    # say L583 pla
    old "Anyway, just let's go home..."
    new "بیای دیگه برویم خونه..."

    # say L585 bri
    old "Ok..."
    new "باشه..."

    # say L590 pla
    old "Hmm... Things are very suspicious... I'll have to talk to Brixxida to clarify everything..."
    new "Hmm... حالتون خیلی مشکوکه... باید با بریکسیدا صحبت کنم تا همه چی رو مشخص کنم..."

    # say L608 gom
    old "Well I hope this little help you, to improve your skills..."
    new "امیدوارم این کمک کوچک به تو برای بهبود مهارت‌هات مفید باشه."

    # say L610 pla
    old "Thank you, I really appreciate all your help."
    new "ممنون، واقعاً از همه کمک‌هایت بسیار خوشحالم."

    # say L612 gom
    old "You're welcome, we count on you to save the magical world."
    new "خواهش می‌کنم، ما بر تو برای نجات جهان جادویی اعتماد داریم."

    # say L614 pla
    old "I'll take care of fixing everything, I promise..."
    new "من قول می‌دم همه چی رو اصلاح می‌کنم..."

    # say L616 gom
    old "Thank you."
    new "ممنون."

    # say L676 pla
    old "What the fuck? Who are you? And What was that?!"
    new "چه فکر می‌کنی؟ تو کی هستی؟ و اون چی بود؟!"

    # say L678 mil
    old "What? Can you see me?"
    new "چه؟ می‌تونی منو ببینی؟"

    # say L679 pla
    old "Yes! Of course, I can see you..."
    new "بله! البته می‌تونم تو رو ببینم..."

    # say L681 mil
    old "How the fuck can you see me? You are a simple human... "
    new "چطور می‌تونی منو ببینی؟ تو فقط یه انسان ساده‌ای هستی..."

    # say L682 pla
    old "Uhh no... I think it's because I have Agamoto's eyes."
    new "نه نه... فکر کنم به خاطر اینه که چشم‌های آگاموتو دارم."

    # say L684 mil
    old "What?! You have Agamoto's eyes?"
    new "چه کاری؟! چشم‌های آگاموتو رو داری؟"

    # say L685 pla
    old "Ehh yeah... But who are you?"
    new "اوه آره... ولی تو کی هستی؟"

    # say L687 mil
    old "Sooo... it's you who's been stealing the magic power?!"
    new "پس... تو هستی که قدرت جادویی رو می‌سرقی؟!"

    # say L688 pla
    old "What? Stealing magic power?"
    new "چه؟ قدرت جادویی رو می‌چرخونی؟"

    # say L690 mil
    old "Look, I'll only warn you this once... If you keep stealing the magic power I will be forced to take extreme measures..."
    new "بگو، فقط یک بار هشدارت می‌دم... اگه همچنان قدرت جادویی رو می‌سرقت، مجبور می‌شم اقدامات شدیدی بکنم..."

    # say L691 pla
    old "Extreme measures?"
    new "اقدامات شدید؟"

    # say L693 mil
    old "This is not a children's game... You better stop stealing the magical power."
    new "این بازی کودکانه نیست... بهتره دیگه از قدرت جادویی سرقت نکنی."

    # say L696 pla
    old "But- wait... What?"
    new "ولی- صبر کن... چی؟"

    # say L697 pla
    old "Hmm... Will have to talk to Brixxida tomorrow..."
    new "باید فردا با بریکسیدا صحبت کنم..."

    # say L723 pla
    old "Well, did you get enough?"
    new "خب، خوب شد؟"

    # say L725 mil
    old "Yes, thank you for everything..."
    new "بله، ممنون از همه چیز..."

    # say L726 pla
    old "No problem. You can come back anytime if you need more..."
    new "هیچ اشکالی. هر وقت نیاز داشتی می‌تونی برگردی..."

    # say L728 mil
    old "We just need a little to not disappear..."
    new "ما فقط نیاز داریم کمی بمانیم تا نپردازیم..."

    # say L730 mil
    old "Anyway I will let you keep sleeping... Bye..."
    new "بازهم خوب، بگذارم خوابت رو ادامه بدی... خداحافظ..."

    # say L798 mil
    old "Don't you see? You're a thief... And now you steal directly."
    new "می‌بینی؟ تو دزدی... و حالا مستقیماً دزدی می‌کنی."

    # say L800 pla
    old "I'm not... I'm only recovering what you took away from me, Nothing more."
    new "من نیستم... من فقط آنچه از من گرفتی را بازمی‌گردانم، هیچ چیز بیشتر نیست."

    # say L802 mil
    old "You have been taking away all the energy in these past few days..."
    new "تو در این چند روز همه انرژی رو پرتونده بودی..."

    # say L804 mil
    old "You don't need it to exist..."
    new "تو برای وجود نیازی به اون نداری..."

    # say L806 pla
    old "I am the chosen one, I will be able to restore the magical world..."
    new "من انتخاب شده‌ام، می‌توانم جهان سحر را بازسازی کنم..."

    # say L808 mil
    old "You are a simple human, you cannot do anything for the magical world..."
    new "تو فقط یک انسان ساده‌ای هستی، برای جهان جادویی هیچ کاری نمی‌تونی انجام بده..."

    # say L810 pla
    old "I am the owner of the SexNote!..."
    new "من صاحب SexNote هستم!"

    # say L812 mil
    old "You... have... the... SexNote?..."
    new "تو... SexNote رو... داری؟..."

    # say L814 pla
    old "That's right... I will rebuild the magical world..."
    new "درست است... من جهان جادویی رو دوباره سازنم."

    # say L820 pla
    old "Wait... Hmm..."
    new "بیا...Hmm..."

    # say L840 mil
    old "Ok, I think is enought for now, right?..."
    new "خب، فکر کنم برای حالا کافیه، درسته؟"

    # say L842 pla
    old "Well, yes, thank you... But if you have little just left tell me."
    new "بله، ممنون... اما اگر هنوز کمی باقی مونده، به من بگو."

    # say L844 mil
    old "Don't worry I'm good for now..."
    new "نگران نباش، حالا خوبم..."

    # say L846 mil
    old "Now let me rest and recover some magic power..."
    new "الان برام فرصت بده تا یه کمی قدرت جادویی برگردونم..."

    # say L848 pla
    old "Ok, see you..."
    new "باشه، ببینم..."


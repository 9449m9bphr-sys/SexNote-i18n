# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mechanics/Navigation.rpy
translate persian strings:

    # say L361 pla
    old "I shouldn't for now."
    new "من الان نباید"

    # say L372 pla
    old "I shouldn't for now"
    new "من الان نباید"

    # say L417 pla
    old "I shouldn't now"
    new "من الان نباید"

    # say L953 pla
    old "The school is closed. I should just go home."
    new "مدرسه بسته هست. باید برم خونه."

    # say L1248 pla
    old "I shouldn't enter right now. I don't have any appointments..."
    new "من الان نباید وارد بشم. هیچ نوبتی هم ندارم..."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/MiaStory.rpy
translate persian strings:

    # say L11 mia
    old "Hmph, I see you're late again [pla], you never learn, do you?"
    new "همف، می‌بینم دوباره دیر رسیدی [pla]، هرگز یاد نمی‌گیری، نه؟"

    # say L12 mia
    old "Although that's not really a surprise, you're always doing this kinda stuff."
    new "البته، این خیلی شگفت‌انگیز نیست، همیشه اینجوری عمل می‌کنی."

    # say L13 pla
    old "Uhh... Good morning, Miss Mia."
    new "اوه... صبح بخیر، خانم میا."

    # say L14 mia
    old "I'm sorry? Don't think that you can be a wise ass with me young man, and get in the classroom already! We're about to start."
    new "متأسفم؟ نباید فکر کنی که می‌تونی با من جوان خودت باشی، و همین حالا وارد کلاس شو! قراره همین الان شروع کنیم."

    # say L15 mia
    old "Don't you see there are some students that DO care about studying?"
    new "آیا نمی‌بینی که بعضی دانش‌آموز‌ها واقعاً به تحصیل اهمیت می‌دهند؟"

    # say L23 pla
    old "(What the hell got into her?)"
    new "می‌دونی اونجا چه اتفاقی افتاد؟"

    # say L24 pla
    old "(Gosh, this is gonna be a looong day)"
    new "(ای مرگ، این روز طولانی می‌شه)"

    # say L29 mia
    old "As you can see, establishing a single reason for the start of world war I is nearly impossible."
    new "همانطور که می‌بینید، تعیین یک دلیل منحصر به فرد برای شروع جنگ جهانی اول تقریباً غیرممکن است."

    # say L30 mia
    old "Certainly the detonating event was the killing of Archduke Franz Ferdinand."
    new "البته رویداد انفجاری، قتل ارشدوق فرانتس فردیناند بود."

    # say L31 mia
    old "But as I explained already, this was merely a consequence of the authoritarian rule..."
    new "اما همانطور که قبلاً توضیح دادم، این فقط نتیجه حکومت استبدادی بود..."

    # say L34 pla
    old "(Geez this is boring... What do I need to know any of this stuff for?)"
    new "وای این خسته‌کننده... این همه چیز برایم چه کاری داره؟"

    # say L54 pla
    old "(Isn't she wearing underwear?)"
    new "(آیا او لباس زیر پوشیده؟)"

    # say L62 mia
    old "As I was saying, what's most important to remember when examining the causes of the war..."
    new "همانطور که می‌گفتم، مهم‌ترین نکته‌ای که باید در بررسی علل جنگ به خاطر سپرده شود این است که..."

    # say L63 mia
    old "It's that the political climate of Europe was tremendously charged..."
    new "این اهمیت داره که اوضاع سیاسی اروپا خیلی تنش‌زا بود..."

    # say L67 pla
    old "{i}Hey Mike, dude! Did you see that?! {/i}"
    new "{i}هی مایک، بروز! دیدی اون رو؟! {/i}"

    # say L68 mik
    old "{i}U-uh? Are you talking to me? Did Ms. Mia ask a question?{/i}"
    new "{i}اوه؟ از من حرف می‌زنی؟ آیا خانم میا سؤالی پرسید؟{/i}"

    # say L69 pla
    old "{i}What? No dude! You didn't see that?{/i}"
    new "{i}چه؟ نه داداش! تو ندیدی؟{/i}"

    # say L70 mik
    old "{i}See what?{/i}"
    new "{i}چه چیزی؟{/i}"

    # say L71 pla
    old "{i}Nevermind...{/i}"
    new "{i}بیا بیشتر نگو...{/i}"

    # say L72 pla
    old "(Was I the only one that saw that?)"
    new "من مطمئنم من تنها نفری بودم که آن را دیدم."

    # say L73 pla
    old "(I'm sure I saw she wasn't wearing any panties.)"
    new "مطمئنم دیدم که پانتی‌اش رو نپوشیده."

    # say L75 mia
    old "Ok guys, that's today's class, remember I'm going to need you to write a three-page report on the causes of world war I for the next class."
    new "خب بچه‌ها، این جلسه خاتمه شد، به یاد داشته باشید که برای جلسه بعدی باید یک گزارش سه صفحه‌ای درباره علل جنگ جهانی اول بنویسید."

    # say L76 mia
    old "And [pla], remember to be on time for next time!"
    new "و [pla]، به خاطر داشته باشید برای جلسه بعدی زود بیایید!"

    # say L98 mia
    old "Hmm, late again! You just never learn, do you [pla]?"
    new "Hmm، دوباره دیر! هیچ وقت نمی‌آموزی، درسته [pla]؟"

    # say L99 pla
    old "Hi Miss Mia, were you waiting for me? I mean, I'm just on time."
    new "سلام خانم میا، آیا منتظر من بودی؟ منظورم اینه که من فقط به موقع هستم."

    # say L100 mia
    old "Just on time to interrupt the class by entering late!"
    new "همیشه همینجوری می‌رسی تا کلاس شروع شده باشه!"

    # say L101 mia
    old "I'm telling you, you better straighten up!"
    new "من به شما می‌گم، بهتره خودتان رو اصلاح کنید!"

    # say L110 dir
    old "Oh! Mia, good morning."
    new "اوه! میا، صبح بخیر."

    # say L111 mia
    old "Good Morning ma'am, how are you today?"
    new "صبح بخیر خانم، امیدوارم امروز حالت خوب باشد."

    # say L112 dir
    old "I'm pretty good, thank you, just checking up on things before I go to my office to start the day."
    new "من خوبم، ممنون، فقط قبل از رفتن به دفتر برای شروع روز، چیزهایی را بررسی می‌کنم."

    # say L113 dir
    old "By the way, don't you think it's about time for you to start with your class?"
    new "البته، نمی‌تونم بگم که فکر کنم الان وقت کلاس شده، می‌تونی براش یه لحظه صبر کنی؟"

    # say L115 mia
    old "You're right, sorry ma'am, I was just waiting for this student, he needs a little extra attention."
    new "بله، درست می‌فرمایید، عذرخواهم، فقط منتظر این دانشجو بودم، او به یکم توجه بیشتر نیاز دارد."

    # say L117 mia
    old "This is [pla]."
    new "این [pla] است."

    # say L118 pla
    old "Good morning ma'am.."
    new "صبح بخیر خانم."

    # say L120 dir
    old "Ah, this is the student you told me about."
    new "آه، این همان دانش‌آموزی است که درباره‌اش به من گفتی."

    # say L122 dir
    old "Well [pla], given what Mia has told me about you, I don't think it's very good that you're arriving this late to class."
    new "خب [pla]، با توجه به آنچه میا در مورد تو به من گفت، فکر نمی‌کنم خوب باشه که اینقدر دیر به کلاس بیایی."

    # say L123 pla
    old "You're right ma'am, I'm sorry."
    new "حق با شماست، خانم، معذرت می‌خوام."

    # say L124 dir
    old "Trust me, you don't want to see your classmates move on and you being stuck here."
    new "باور کن، نمی‌خوای ببینی همکلاس‌ت به جلو برند و تو اینجا خیس بمانی."

    # say L125 dir
    old "So, make sure you buckle down and start studying seriously."
    new "پس حتماً جدی شو و شروع به مطالعه کن."

    # say L126 dir
    old "Otherwise you'll have to come here and take extra classes during your Holidays."
    new "در غیر این صورت باید در طول تعطیلاتت اینجا بیایی و کلاس‌های اضافی بگیری."

    # say L127 pla
    old "You're right, ma'am."
    new "درست می‌فرمایید، خانم."

    # say L128 dir
    old "Just keep it in mind. Mia already has an eye on you, be thankful that your teacher cares so much."
    new "فکر کن بهش. میا قبلاً چشمتو بر تو انداخته، ممنون باش که معلمانت به همین میزان نگران تو هست."

    # say L129 pla
    old "Hmm... Yes ma'am."
    new "Hmm... بله خانم"

    # say L130 dir
    old "Good boy."
    new "خوب پسر."

    # say L131 dir
    old "Now Mia, I think it's time for you to start your class."
    new "الان میا، فکر می‌کنم وقت شروع کلاس‌ت رسیده."

    # say L132 mia
    old "Yes ma'am, I'm about to."
    new "بله خانم، همین الان می‌شروعم."

    # say L133 mia
    old "Have a very good day ma'am."
    new "روز خوبی داشته باشید خانم."

    # say L134 dir
    old "You too dear."
    new "تو هم عزیزم."

    # say L142 mia
    old "You see? That's your second warning about your studies. You better listen!"
    new "دیدی؟ این دومین هشدارت در مورد تحصیلاتت. بهتره بشنو!"

    # say L143 mia
    old "And come in!"
    new "و داخل شوید!"

    # say L149 mia
    old "Ok guys, we'll continue with the world war one chapter."
    new "بچه‌ها، ما ادامه می‌دهیم به فصل جنگ جهانی اول."

    # say L150 mia
    old "This time we'll talk about Africa and the Ottoman Empire during this period of time."
    new "این بار درباره آفریقا و امپراتوری عثمانی در این دوره صحبت خواهیم کرد."

    # say L156 mia
    old "Is it me or is it really hot today? I think I need to get a bit more comfortable."
    new "آیا منم هستم یا امروز واقعاً گرم است؟ فکر می‌کنم باید یک کم راحت‌تر شوم."

    # say L160 pla
    old "(What the fuck?! She's not wearing a bra!)"
    new "وای، این چه خبریه؟! او هیچ برا نمی‌پوشه!"

    # say L161 pla
    old "(What's happening with her?)"
    new "(اینجا چه اتفاقی می‌افتد؟)"

    # say L169 mia
    old "Phew, too much better, ok, let's continue with the subject..."
    new "پوف، خیلی بهتر، خب، بیاین به موضوع ادامه بدیم..."

    # say L176 mia
    old "Is there something you want to share with the class? Or can I continue with the class."
    new "آیا چیزی هست که بخواهی با کلاس به اشتراک بگذاری؟ یا می‌توانم ادامه بدم؟"

    # say L177 mik
    old "U- uh, sorry Miss Mia."
    new "ببخشید معلم میا."

    # say L178 pla
    old "Yeah, sorry."
    new "بله، معذرت."

    # say L179 mia
    old "Honestly, I would hope that you of all people should be the one paying the most attention [pla]."
    new "صراحیت بگم، امیدوارم شما از همه، بیشتر توجه می‌کردید [pla]."

    # say L180 mia
    old "Let me remind you that your grades have been terrible."
    new "بگذار به تو یادآور شوم که نمراتت خیلی بد بوده."

    # say L181 mia
    old "I imagine that paper you had to write must be excellent, right?"
    new "من فکر می‌کنم آن مقاله‌ای که باید نوشته باشی باید عالی باشه، درسته؟"

    # say L182 pla
    old "I said I was sorry..."
    new "من هم پوزدم..."

    # say L183 mia
    old "Hmph, you better be."
    new "همف، باید خوب باشه."

    # say L184 mia
    old "I'm sorry class, let's just continue, I know some of you actually want to learn."
    new "ببخشید کلاس، بیایید ادامه بدیم، می‌دونم بعضی از شما واقعاً می‌خواهند یاد بگیرند."

    # say L191 mik
    old "Dude! [pla], did you notice?!"
    new "دیوونه‌ای! [pla]، متوجه شدی؟!"

    # say L192 mik
    old "You could see her nipples! It was the best class ever!"
    new "می‌تونستی نیپل‌هایش رو ببینی! بهترین جلسه همیشه بود!"

    # say L193 pla
    old "Yeah, that was weird."
    new "بله، خیلی عجیب بود."

    # say L202 mik
    old "Hey Belle, did you see that?"
    new "بله، بله، دیدم. می‌تونی این رو هم به لیست موتیvasاتون برای رفتن به کلاس اضافه کنی؟"

    # say L203 mik
    old "Now we have a new motivation to come to class!"
    new "الان دلیل جدیدی برای اومدن به کلاس داریم!"

    # say L205 bel
    old "Yes, I noticed that Miss Mia wasn't wearing a bra... I assume that's what you mean?"
    new "بله، متوجه شدم که میس میا هیچ برا نداشت... فکر کنم این همینه که منظورت بود؟"

    # say L206 pla
    old "That was weird, and it's not the first time, last class I also noticed something."
    new "این عجیب بود و اولین بار نیست، در آخرین جلسه هم چیزی متوجه شدم."

    # say L207 bel
    old "Yeah, I also saw that."
    new "بله، من هم اون رو دیدم."

    # say L210 mik
    old "What? Last class?"
    new "چه؟ درس قبلی؟"

    # say L211 mik
    old "I didn't see anything."
    new "من هیچ چیزی ندیدم."

    # say L212 mik
    old "What was it? What was it?"
    new "چی بود؟ چی بود؟"

    # say L215 bel
    old "There's something odd about Ms. Mia's behavior lately."
    new "اخیراً رفتار میس میا عجیب است."

    # say L216 pla
    old "I know what you mean."
    new "من هم همین جور می‌فکرم."

    # say L217 pla
    old "But I guess that's none of our concern."
    new "اما فکر کنم این جوری هم از کار ما نیست."

    # say L220 bel
    old "By the way, I'm going over to Billie's to hang out."
    new "باید برم به خونه بیلی برای گپ زدن."

    # say L221 bel
    old "You guys wanna come?"
    new "بیایید هم بیایید؟"

    # say L224 pla
    old "I would love to."
    new "من خوشحالم که بروم، ولی..."

    # say L225 pla
    old "But I have to get working on the next project, otherwise Ms. Mia will never get off my back."
    new "ولی باید روی پروژه بعدی کار کنم، در غیر این صورت خانم میا هیچ وقت از بالایم پایین نمی‌یاد."

    # say L226 bel
    old "She really doesn't like you, does she?"
    new "وای، واقعاً خوشت نیومده، همینطور نیست؟"

    # say L227 pla
    old "Ha, that's saying little."
    new "ها، این هم خیلی کم‌تر نیست."

    # say L229 pla
    old "Oh, damn, I just realized, I forgot my notes in the classroom."
    new "او، شیطون، فهمیدم، نوت‌هام رو تو کلاس چپ کردم."

    # say L230 pla
    old "I have to go back and grab them. See you later guys!"
    new "باید برگشتم و اونا رو ببرم. ببینیم بعداً چه خبره!"

    # say L239 mik
    old "So, where are we going Belle?"
    new "پس، ما به کجا می‌رویم بِل؟"

    # say L251 mia
    old "Yeah, yeah, I did what you asked!! Okay?!"
    new "بله، بله، اونی که خواستی انجام دادم!! خب؟!"

    # say L252 mia
    old "Yeah, but I won't be doing that shit again!"
    new "بله، اما من دوباره این کار رو نمی‌کنم!"

    # say L253 mia
    old "This was so embarrassing. You went way overboard with this!"
    new "این خیلی خجولانه بود. تو اینجا خیلی دور رفتی!"

    # say L254 mia
    old "And I'm telling you now, I'm not doing anything more in public!"
    new "و الان بهت می‌گم، هیچ کار دیگه در جای عمومی نمی‌کنم!"

    # say L259 mia
    old "What...?!"
    new "چه؟!"

    # say L260 mia
    old "Ugh, great, just what I needed!"
    new "اوه، عالی، همین که لازم داشتم!"

    # say L262 pla
    old "Um, sorry, I just came back to pick up my notes, I'm leaving now."
    new "ببخشید، فقط برای گرفتن یادداشت‌هام برمی‌گشتم، حالا می‌روم."

    # say L269 mia
    old "Uh? What? Him?"
    new "آه؟ چی؟ او؟"

    # say L270 mia
    old "He's nobody, just another one of my stupid students."
    new "او هیچ‌کسی نیست، فقط یکی از دانش‌آموزان خفنم."

    # say L271 mia
    old "Nah, he just came in, he heard nothing."
    new "نه، فقط وارد شده، هیچ چیز نشنیده."

    # say L272 mia
    old "What does his name have to do with anything?"
    new "اسمش با همه این چیزها چه ربطی داره؟"

    # say L273 mia
    old "Yeah, I don't like him, so what?"
    new "بله، من نمی‌تونم باش رو بپسندم، چه کار داری؟"

    # say L274 mia
    old "What? Listen, that doesn't have anything to do with our conversation."
    new "میا: چه کاری؟ بگو، این با صحبت‌هایمون هیچ ربطی نداره."

    # say L275 mia
    old "The point is that I'm not doing anything else, so you better stop harassing me, you got that?!"
    new "نکته اینه که من هیچ کار دیگه‌ای نمی‌کنم، پس بهتره متوقف شی، درست می‌شنوی؟"

    # say L279 mia
    old "Ughh..."
    new "اوه..."

    # say L284 pla
    old "Hmm, I guess Mike and Belle already left."
    new "Hmm، به نظر می‌رسه مایک و بل قبلاً رفته‌ان."

    # say L285 pla
    old "(But what the hell was that phone call about? That was so weird.)"
    new "ولی اون تماس گوشی درباره چی بود؟ خیلی عجیب بود."

    # say L286 pla
    old "(Although I guess it's not my business.)"
    new "البته فکر کنم این کار من نیست."

    # say L301 mia
    old "All right guys, today we'll talk about American development during the period from 1925 to 1938, the period between the two world wars..."
    new "بچه‌ها، امروز درباره توسعه آمریکا در دوره ۱۹۲۵ تا ۱۹۳۸، دوره بین دو جنگ جهانی صحبت خواهیم کرد..."

    # say L302 pla
    old "(God this is so fucking boring.)"
    new "خدا این همه خسته‌کننده و سردرگم‌کننده است."

    # say L304 pla
    old "(What?)"
    new "(چه؟)"

    # say L305 pla
    old "(Is she looking at me?)"
    new "(آیا او به من نگاه می‌کنه؟)"

    # say L306 mia
    old "The European crisis allowed the emergence of powerful industrialists, like Rockefeller and Ford."
    new "بحران اروپا زمینه را برای ظهور صنعتمداران قدرتمند مانند راکفلر و فورد فراهم کرد."

    # say L307 pla
    old "(Why does she look so angry?)"
    new "چرا به نظر می‌رسه خیلی خشمگین است؟"

    # say L313 mia
    old "Ok, guys, that's it for today, for the next class I'll need you to read about the treaty of Versailles."
    new "بچه‌ها، این همه برای امروز، برای جلسه بعد باید در مورد معاهده ورسای خواندید."

    # say L319 mik
    old "Aw, dude, that was so dull!"
    new "اوه، دوست من، این همینا خسته‌کننده بود!"

    # say L320 mik
    old "I'm exhausted, can't wait for lunch."
    new "من خسته‌ام، نمی‌تونم صبر کنم تا نهار بخورم."

    # say L330 mia
    old "Hey [pla], I'm going to need you to stay."
    new "هی ز[pla]، من نیاز دارم تو بمانی."

    # say L332 mik
    old "Uh-oh, you're in trouble dude. I think I better get going home."
    new "او-او، تو مشکل داری بچه. فکر کنم بهتره من برم خانه."

    # say L334 mik
    old "Good luck dude."
    new "بازم همیشه شاد باش، دوست من."

    # say L336 pla
    old "See you dude."
    new "ببینم برات خوب بشه دوست من."

    # say L343 pla
    old "If this is about the project I-"
    new "اگه این در مورد پروژه هست من-"

    # say L344 mia
    old "Oh shut up! Just shut up! Who cares about that stupid project?!"
    new "بسته شو! فقط بسته شو! چه کسی به اون پروژه احمق میدی؟!"

    # say L345 pla
    old "Uh w-what? But you said..."
    new "اوه چ-چه؟ اما تو گفتی..."

    # say L346 mia
    old "So, it was you, wasn't it?!"
    new "پس تو بودی، نه؟!"

    # say L347 mia
    old "I see, of course, he had someone on the inside."
    new "می‌بینم، البته، او کسی در داخل داشت."

    # say L348 mia
    old "You're the bastard that's been verifying that I do his stupid challenges. I should've known."
    new "تو هستی اون خر که همیشه می‌رسی تا بررسی کنی من آن چالش‌های احمقانه‌اش رو انجام داده‌ام. باید از اول متوجه بودم."

    # say L349 pla
    old "Uhmm, what? What are you talking about?"
    new "اوه، چه کاری؟ درباره چه چیزی حرف می‌زنی؟"

    # say L351 mia
    old "Well, I'll let you know I'm tired of this bullshit! You better not think you'll keep getting away with this disgusting behavior."
    new "خب، باید بدانی که از این همه خسته شده‌ام! بهتر است نفکر کنی که می‌توانی همیشه از این رفتار بده‌ناک بیرون آیی."

    # say L352 mia
    old "I was so stupid not to realize it was you, of course, you were the clear option."
    new "من احمق بودم که متوجه نشدم این تو هستی، البته تو گزینه مشخصی بودی."

    # say L353 mia
    old "I should've known from the beginning. It was obvious."
    new "باید از اول متوجه بودم. اینقدر مشخص بود."

    # say L354 pla
    old "Excuse me, I don't know what you're accusing me of, but I haven't done anything."
    new "ببخشید، نمی‌دونم از چی متهم می‌کنی، ولی هیچ کاری نکردم."

    # say L355 mia
    old "Will you stop playing dumb already?!!! You know very well what I'm talking about!"
    new "آیا قراره همینطور بازی غافل بازی کنی؟!!! تو خوب می‌دونی در مورد چی حرف می‌زنم!"

    # say L356 mia
    old "Or are you telling me you haven't been following that bastard Denzel's orders to spy on me?"
    new "یا می‌خوای بگی نه از دستورات آن خرا Denzel برای جاسوسی روی من پیروی نکردی؟"

    # say L357 pla
    old "Denzel? What the-"
    new "دنزل؟ چه کاری-"

    # say L358 mia
    old "Or that you just happened to come into the classroom just as I was reporting to him?!"
    new "یا اینکه صدف به تصادف وارد کلاس شدی همان موقع که من به او گزارش می‌دادم؟!"

    # say L359 mia
    old "I know you're a bastard, but spare me your stupid lies!"
    new "می‌دونم تو یه بچه خرابی هستی، ولی از دروغ‌های بی‌هیچ‌پیچت خودت صرف نظر کن!"

    # say L360 pla
    old "I already told you I don't know what you're talking about!"
    new "من قبلاً به تو گفتم نمی‌دونم در مورد چی حرف می‌زی!"

    # say L361 mia
    old "Ugh, whatever, let's just get this over with."
    new "اوه، هر چه بود، بیاییم این را تمام کنیم."

    # say L369 pla
    old "Woah! Woah! What do you think you're doing?"
    new "وای! وای! فکر می‌کنی چیکار می‌کنی؟"

    # say L370 mia
    old "Will you stop pretending you don't know what's going on?!!"
    new "می‌تونی برای همیشه نبازی کنی که نمی‌دونی چه قصه‌ای داره؟!!"

    # say L371 mia
    old "How can you keep acting like this after all that you've made me do?!"
    new "بعد از همه چیزی که من برایت انجام دادم، چطور می‌تونی هنوز هم این طور باشی؟"

    # say L372 mia
    old "At least pretend you have some decency, will you?!"
    new "حداقل بروز خودت رو نشون بده، بخواهی یا نخواهی؟!"

    # say L373 pla
    old "I-I don't... W- what do you mean?"
    new "من من... چ-چه قراره بگم؟"

    # say L374 pla
    old "I already told you, I have no idea what you're talking about."
    new "من قبلاً به تو گفتم، نمی‌دونم اصلاً در مورد چی حرف می‌زی."

    # say L375 mia
    old "Yeah right... As if I'll believe anything you say."
    new "بله همین‌جوری... مثل اینکه من به هیچی از حرف‌هایت باور می‌کنم."

    # say L376 mia
    old "But I'll give you what you want, you sick freak."
    new "ولی بهت میدم آنچه می‌خوای، تو خودتو بیمار."

    # say L385 mia
    old "Listen, I've had enough of your bullshit for one day."
    new "بله، خوب، برای امروز از دروغ‌هایت خسته شدم."

    # say L386 mia
    old "I already sent that asshole the picture. Just leave me alone."
    new "من قبلاً عکس رو به آن خر فرستادم. فقط برام آرام بده."

    # say L393 pla
    old "What the fuck?!"
    new "چه فکر می‌کنی؟!"

    # say L415 mia
    old "Of course, your little accomplice would come!"
    new "البته، همکار کوچکت اینجا آمد!"

    # say L416 mia
    old "What are you two, sick freaks, planning now?"
    new "شما دو تا حالا چه برنامه‌های خرابی دارید؟"

    # say L417 pla
    old "W- what? I... What are you talking about?"
    new "و- وای، من... تو درباره چی حرف می‌زی؟"

    # say L418 pla
    old "I just came early for class!"
    new "من فقط برای کلاس زود آمدم!"

    # say L419 mia
    old "Ugh! Denzel, could you tell your little minion to stop acting?"
    new "اوه! دنزل، می‌تونی به این کودک خودت بگی که توقف کنه؟"

    # say L421 den
    old "Well, Miss Mia, I must say this is the first time I've seen your student."
    new "خانم میا، باید بگم این اولین بار هست می‌بینم دانش‌آموز شما."

    # say L422 den
    old "I don't even know his name."
    new "من حتی نامش رو نمی‌دونم."

    # say L423 mia
    old "What?! What do you mean?"
    new "چه؟! منظورت چیه؟"

    # say L425 den
    old "Well, I don't think you even have enough in that empty head of yours to remember."
    new "خب، فکر نمی‌کنم تو حتی ذهن خالیت رو داری تا به یاد بیاری."

    # say L426 den
    old "But while you were my teacher, you made my life miserable, absolutely horrible."
    new "اما وقتی تو معلم من بودی، زندگی من رو می‌کردی خیلی بد، واقعاً وحشتناک."

    # say L427 den
    old "And from what I can see, that's something you're still doing..."
    new "و از آنچه می‌بینم، همچنان این کار را انجام می‌دهی..."

    # say L429 den
    old "Well, I've noticed you always pick on a poor and innocent guy from your classes to torment."
    new "خب، من متوجه شدم همیشه یک نفر بیچاره و بی‌گناه رو از کلاس‌ات برای آزار و ناراحتی انتخاب می‌کنی."

    # say L430 den
    old "Tremendously immature of you, I must say, someone would think a teacher would be a little bit more... nuanced."
    new "باید بگم خیلی نارسایی از تو، فکر می‌کنم یک معلم باید کمی بیشتر... ریاضی باشه."

    # say L431 den
    old "So, the other day, after listening to your answer when we were talking and you got interrupted by him."
    new "پس، روزی، بعد از شنیدن جوابت وقتی با هم صحبت می‌کردیم و او آن را قطع کرد."

    # say L432 den
    old "It came to my mind, why not give the young guy a chance to take some revenge on his horrible teacher?"
    new "به ذهنم رسید که چرا ندهیم به جوان این فرصت را که برای انتقام از معلم خودش که واقعاً بد بود؟"

    # say L433 mia
    old "... The fuck?"
    new "... فکر کنم خر دیوونه؟"

    # say L434 pla
    old "W-w-what the hell is happening? What are you guys talking about?"
    new "وَوَ چه خبری اومد؟ شما دو تا درباره چی می‌گپید؟"

    # say L436 den
    old "Oh, how rude of me, I went into a monologue without even introducing myself. Apologies buddy."
    new "اوه، خیلی بی‌احترامی از من، بدون اینکه حتی خودم را به تو معرفی کنم، حرف زدم. عذرخواهم، دوست من."

    # say L437 den
    old "My name is Denzel, and just like you, I was once a victim of this so-called teacher's horrible personality."
    new "اسم من دنسل هست و مثل تو، من هم یک بار قربانی شخصیت خراب این معلم‌های نامناسب شدم."

    # say L439 den
    old "She used to be my teacher, and she made my life miserable too."
    new "او قبلاً معلم من بود و همچون تو زندگی من رو نابامزج کرده بود."

    # say L441 den
    old "I never forgave her, but I didn't actually have any way to get back at her for anything."
    new "من هرگز اون رو ببخشیدم، اما در واقع هیچ راهی برای انتقام نداشتم."

    # say L442 den
    old "That is, until recently, when I learned a couple of things from her past that she would prefer to have hidden."
    new "البته، تا زمانی که اخیراً چند چیز از گذشته‌اش که بهتر بود مخفی مونده بود، فهمیدم."

    # say L443 mia
    old "No! Don't say anything about that! Please, I'm already doing whatever you ask me."
    new "نه! در مورد اون هیچ جور حرف نزن! لطفاً، من حالا هر چی می‌خوای از من می‌کنم."

    # say L445 pla
    old "W-what are you talking about?"
    new "و-و در مورد چه چیزی حرف می‌زنی؟"

    # say L447 den
    old "Go ahead Mia, tell your favorite student all about your past..."
    new "بپرس میا، همه چیز رو به دانش‌آموز مورد علاقه‌ات بگو..."

    # say L448 mia
    old "Please... No..."
    new "لطفاً... نه..."

    # say L450 den
    old "I mean, there's nothing to feel ashamed about, is there?"
    new "من قصد دارم بگم که هیچ چیزی برای خجالت نداشتن نیست، درسته؟"

    # say L455 den
    old "That's right! Can you believe it? She's always so self-righteous, always taking her anger out on other people."
    new "درسته! می‌تونی باور کنی؟ همیشه اینجوریه، همیشه خودش رو درست می‌بینه و غضبشو روی دیگران می‌ریزم."

    # say L456 den
    old "She's offensive, arrogant, and demanding, when she used to be just a whore!"
    new "او توهین‌آمیز، خودپرست و درخواستیه، در حالی که قبلاً فقط یک راه‌انداز بود!"

    # say L458 den
    old "Anyway, she got out of that, but I found out and got proof that she used to be a pornstar."
    new "باز هم از اون بیرون خر جویی کرد، ولی من پیدا کردم و اثبات کردم که قبلاً ستاره پورنو بود."

    # say L459 den
    old "And if she doesn't want to be fired, and get her life ruined,  she'll have to do as I say."
    new "و اگر نخواست اونجا افتاده باشه و زندگیش خراب شه، باید هر چی من می‌گم بکنه."

    # say L460 den
    old "Or I'll out her as the whore she is, and her life here will be over."
    new "یا من اون رو به عنوان مالیکه‌ای که هست خواهم فاش کرد، و زندگی‌اش اینجا تمام خواهد شد."

    # say L461 mia
    old "You fucking bastard!"
    new "شما خوبه بیچ!"

    # say L463 den
    old "Oh, call me what you want, that only makes it better when I punish you."
    new "اوه، هر چی بخوای بگی، فقط وقتی که تو رو مجازات می‌کنم بهتر می‌شه."

    # say L466 den
    old "By the way... I think it's about time for your next punishment."
    new "باید بگم... فکر کنم وقت مجازات بعدیت رسیده."

    # say L467 den
    old "Oh, sorry, we're calling them challenges. Right?"
    new "اوه، معذرت، ما اینا را چالش‌ها می‌نامیم. درسته؟"

    # say L468 mia
    old "Challenge? Punishment?!"
    new "چالش؟ مجازات؟!"

    # say L469 mia
    old "This is blackmail! And abuse!"
    new "این ابتزاز است! و سوء استفاده!"

    # say L470 den
    old "Call it whatever you want, but you have to do it."
    new "بگو هر چی می‌خوای، اما باید این کار رو انجام بدی."

    # say L471 den
    old "And seeing as your favorite student's here, why don't we have you give him a little bit of attention?"
    new "و چون دانش‌آموز مورد علاقه‌ت اینجا هست، چرا نمی‌دهی بهش کمی توجه؟"

    # say L473 den
    old "Give him a blowjob."
    new "بهش جنس شفاهی بده."

    # say L474 mia
    old "What?! You must be kidding me! A blowjob?!"
    new "آهای! حتماً شوخی می‌کنی! جنس شفاهی؟!"

    # say L475 mia
    old "This is going way too far!"
    new "این خیلی دور رفته!"

    # say L476 mia
    old "Didn't you have enough with your pictures and stuff?"
    new "آنه، از عکس‌ها و چیزهایت خسته نشدم؟"

    # say L477 den
    old "Oh, I really enjoyed those, but that's not what I want right now."
    new "اوه، واقعاً لذت بردم از آنها، اما الان این همچین چیزی نیست که می‌خوام."

    # say L478 den
    old "I already told you what to do, take out his dick and suck it!"
    new "من قبلاً به تو گفتم چه کاری باید بکنی، پیشون رو بیرون بیار و اونو خور!"

    # say L479 den
    old "Otherwise I suppose tomorrow the school principal will receive a mail with an interesting video."
    new "در غیر این صورت فکر می‌کنم رئیس مدرسه فردا یک ایمیل با ویدیوی جالب دریافت خواهد کرد."

    # say L492 mia
    old "You sick freak..."
    new "تو خودت بیماری..."

    # say L493 mia
    old "I'll do it, ok? Just don't spread anything, ok?"
    new "من انجام می‌دم، خب؟ فقط هیچ چی نپخش، خب؟"

    # say L496 mia
    old "Ugh, come here [pla]... I'll do this quickly."
    new "اوه، بیا اینجا [pla]... من اینو سریع انجام می‌دم."

    # say L498 pla
    old "Y- you can't be serious."
    new "می‌تونی جدی باشی؟"

    # say L499 mia
    old "Well, what do you think stupid?!"
    new "خب، چه فکر می‌کنی احمق؟!"

    # say L500 mia
    old "I wouldn't joke about this shit."
    new "من در این مورد شوخی نمی‌کنم."

    # say L501 pla
    old "I- I'm sorry Miss Mia, but I don't have anything to do with this. I should just leave."
    new "می‌بینم، خانم میا، اما من هیچ سر و تهی در این موضوع ندارم. باید بروم."

    # say L508 den
    old "Well, I guess you could just leave. But if you do, I'll just leak the information I have about her."
    new "خب، می‌تونی هم بروی. ولی اگه بروی، من اطلاعاتی که دارم رو منتشر می‌کنم."

    # say L509 den
    old "That's also an option by the way."
    new "البته، این هم یک گزینه است."

    # say L511 den
    old "After all, she's also been cruel to you all this time, you may as well just let her suffer with this."
    new "در نهایت، او هم این طولانی‌ها خشن به تو بوده، می‌تونی هم اجازه بدی این مشکل رو برخورد کنه."

    # say L513 den
    old "Tell you what, maybe you'll change your mind if you see her beg for it. How about it?"
    new "بگو چطور، شاید اگه ببینی او توی این وضعیت درخواست کنه، نظرت عوض بشه. چطور؟"

    # say L515 den
    old "Go ahead Mia, beg him to let you suck his dick, remember what's at stake here for you."
    new "بیا میا، تو خواهش کن ازش بیاید نونشو بکشی، به خاطر همین خطر برایت وجود داره."

    # say L517 mia
    old "Listen, [pla] I don't want this to happen any more than you do."
    new "بله، [pla] من هم مثل تو نمی‌خوام اینجوری شه."

    # say L518 den
    old "Ha! What a weird way to beg! heh."
    new "ها! چه طرز عجیبی برای خواهش کردن! هه."

    # say L519 mia
    old "But if we don't do this, he'll just release his disgusting pictures and videos of me."
    new "اما اگر این کار رو نکنیم، فقط عکس‌ها و فیلم‌های نفرت‌برانگیزش از من منتشر می‌شه."

    # say L520 mia
    old "Please, please, please help me out."
    new "لطفاً، لطفاً، لطفاً به من کمک کن."

    # say L521 mia
    old "After my life went to shit because of what happened before, it's taken me so much work to create something here."
    new "بعد از اینکه زندگی من به هم ریخت به خاطر آن حادثه، خیلی زحمت کردم تا اینجا چیزی ایجاد کنم."

    # say L522 den
    old "Aww, you're breaking my heart."
    new "اوه، قلبم می‌شکه."

    # say L523 mia
    old "Fuck you."
    new "بپرداز به خودت."

    # say L524 pla
    old "Hmm, ok, I'll do it."
    new "Hmm، خب، انجام میدم."

    # say L526 den
    old "You will, Ha! I knew it, you also want to get revenge on her, right?"
    new "بله، ها! میدونستم، تو هم می‌خوای انتقام بگیری، درسته؟"

    # say L527 pla
    old "No!"
    new "نه!"

    # say L528 pla
    old "I'll do it just to help her, I don't want revenge on anyone."
    new "من فقط برای کمک به اش این کار رو می‌کنم، انتقام از هیچ‌کس نمی‌خوام."

    # say L529 den
    old "Heh, whatever you say, kid."
    new "هه، هر چی می‌گی، بچه."

    # say L531 den
    old "All right Mia, it's time to do what you do best!"
    new "باشه میا، الان وقتش رسید که بهترین کارتو انجام بدی!"

    # say L542 mia
    old "(I can't believe I'm actually doing this, and to [pla] of all people!)"
    new "نمی‌تونم باور کنم واقعاً این کار رو انجام می‌دم، و همین حالا برای [pla]."

    # say L543 den
    old "I bet you actually wanted this, even if you left the porn business."
    new "حتماً اینو می‌خواستی، حتی اگر از تجارت پورنو خارج شدی."

    # say L544 den
    old "After all you're just a whore."
    new "در نهایت تو فقط یک سرکاری هستی."

    # say L546 mia
    old "Whatever you say, but remember, you won't get away with this for long."
    new "هر چه بخوای، اما به خاطر بده، نمی‌تونی طولانی‌تر از این از این بیرون برم."

    # say L547 den
    old "Heh, we'll see."
    new "هه، ببینیم."

    # say L557 mia
    old "Woah, what the fuck?!"
    new "واو، این چه خرابیه؟!"

    # say L559 mia
    old "What are you doing? What did you take that picture for?"
    new "تو چه کاری می‌کنی؟ اون عکس رو چرا گرفتی؟"

    # say L560 den
    old "Don't worry about it, that's just to..."
    new "نگران نباش، این فقط برای..."

    # say L561 den
    old "Let's say, commemorate the occasion."
    new "بگذاریم این را به یاد بماند."

    # say L563 den
    old "Anyway, I think I should just leave."
    new "بازهم، فکر کنم باید برسم."

    # say L564 den
    old "Well done [pla], I bet you liked that."
    new "خوب انجام دادی [pla]، حتماً لذت برده بودی."

    # say L566 den
    old "Until we see each other again, bye."
    new "تا زمانی که دوباره هم می‌بینیم، خداحافظ."

    # say L577 pla
    old "U-uh, Miss Mia, I- I think..."
    new "آ-آخه، خانم میا، من فکر می‌کنم..."

    # say L578 mia
    old "I don't want to talk, or anything. Bye."
    new "من نمی‌خوام صحبت کنم، یا هیچ. خداحافظ."

    # say L586 pla
    old "Damn."
    new "لعنتی."

    # say L587 pla
    old "(What did I get myself into now?)"
    new "الان خودم چه کاری انجام دادم؟"

    # say L606 pla
    old "Eh, ehem."
    new "اوه، اهمم."

    # say L611 pla
    old "Hi Miss Mia, good morning."
    new "سلام خانم میا، صبح بخیر."

    # say L612 mia
    old "G-good morning."
    new "صبح بخیر."

    # say L613 mia
    old "I see you're early today, congratulations."
    new "می‌بینم امروز زود آمده‌ای، مبارک."

    # say L614 mia
    old "The class doesn't start yet, so take a seat and wait for your classmates."
    new "کلاس هنوز شروع نشده، پس جلو خودت بنشین و منتظر همکلاس‌هایت باش."

    # say L618 pla
    old "Hmm, actually, I was kinda hoping we could talk."
    new "Hmm، در واقع امیدوار بودم بتونیم صحبت کنیم."

    # say L619 pla
    old "You know, about what happened last time..."
    new "می‌دونی، در مورد اون چیزی که برات اتفاق افتاد..."

    # say L622 mia
    old "Listen, we don't have anything to talk about."
    new "بگوش، ما هیچ چیزی برای صحبت نداریم."

    # say L623 mia
    old "I'm really sorry that you saw yourself being dragged into it, and I thank you for helping me."
    new "ممنونم که کمکت کردی، ولی خیلی متاسفم که تو هم به این مشکل متورط شدی."

    # say L624 mia
    old "But that's all I will say about that issue."
    new "اما این همه‌یی هست که در مورد این موضوع می‌گویم."

    # say L625 mia
    old "Which, by the way, it's my own business, so I would appreciate it if you didn't interfere."
    new "البته، این کار من خودم هست، پس خوشحال می‌شوم اگر از مداخله پرهیز کنید."

    # say L626 pla
    old "What? You can't be talking seriously."
    new "می‌تونی جدی باشی؟"

    # say L627 pla
    old "Listen, what happened yesterday wasn't ok, and you can't let him keep forcing you into that kind of stuff."
    new "بله، چیزی که دیروز اتفاق افتاد خوب نبود و نمی‌توانی به او اجازه بدی که همچین چیزهایی رو به تو انجام بده."

    # say L628 pla
    old "It's just not right, you have to do something..."
    new "این فقط درست نیست، باید چیزی انجام بدی..."

    # say L629 mia
    old "And you think I don't know that?!"
    new "و تو فکر می‌کنی من این رو نمی‌دونم؟!"

    # say L630 mia
    old "Of course it's not right! But I can't do anything, I've racked my brain to come up with a satisfying solution. But nothing."
    new "البته اشتباهه! ولی من هیچ کاری نمی‌تونم بکنم، تمام ذهنم رو خالی کردم تا راه‌حلی رضایت‌بخش پیدا کنم. ولی هیچ."

    # say L631 mia
    old "Otherwise, I wouldn't be stuck following his orders! Don't treat me like an idiot!"
    new "در غیر این صورت، من اینجوری به دستوراتش پیروی نمی‌کردم! نباید من رو مثل احمق در نظر بگیری!"

    # say L633 pla
    old "I know you're not dumb, but that's why I wanted to talk to you because I think maybe I could help you."
    new "می‌دونم خفنی نیستی، ولی همین‌جوری می‌خواستم با تو صحبت کنم چون فکر می‌کنم شاید بتونم بهت کمک کنم."

    # say L635 pla
    old "Listen, I just don't think it's right that he keeps pushing you around like that."
    new "بله، من فقط فکر می‌کنم درست نیست که همیشه تو رو راهنمایی کنه."

    # say L636 pla
    old "I want to do something to help you."
    new "من می‌خوام چیزی بکنم تا به تو کمک کنم."

    # say L637 pla
    old "I think it's the best thing that I can do. If you'll let me."
    new "من فکر می‌کنم این بهترین چیزیه که می‌تونم بکنم. اگه برام اجازه بدی."

    # say L639 mia
    old "Hmm... I guess you're right."
    new "Hmm... به نظر می‌رسه درسته."

    # say L640 mia
    old "Listen, Denzel, is a previous student of mine, that apparently recent me from when I was his teacher."
    new "دنسل، دانش‌آموز پیشین من است، که به نظر می‌رسد اخیراً به یاد من آمده است، زمانی که معلم او بودم."

    # say L641 mia
    old "And he's decided to get back at me by threatening to release some footage that he found from when I was..."
    new "و او تصمیم گرفته به من انتقام بگیره تا با تهدید افشاگری برخی فیلم‌هایی که پیدا کرده از زمانی که من..."

    # say L642 mia
    old "From when I was..."
    new "از وقتی که من..."

    # say L643 mia
    old "Ugh! It's even hard to talk about it!"
    new "آه! حتی برای صحبت درباره‌اش سخته!"

    # say L644 mia
    old "From when I was a pornstar, ok?"
    new "از زمانی که اکترباز بودم، خب؟"

    # say L646 mia
    old "That was a long time ago, I was just fresh out of high school, and didn't have any money to pay for college."
    new "این هم زمانی دور بود، تازه از مدرسه فارغ‌التحصیل شده بودم و پولی برای هزینه دانشگاه نداشتم."

    # say L647 mia
    old "Somebody had talked to me about how much money you could make in little time working on porn."
    new "کسی به من گفت که می‌تونی در زمان کوتاهی پول زیادی کسب کنی اگه توی فیلم‌های پورنو کار کنی."

    # say L648 mia
    old "I was young, so I didn't really think it through, and just decided to do it."
    new "من جوان بودم، پس واقعاً این موضوع رو خوب فکر نکردم و فقط تصمیم گرفتم انجام بدم."

    # say L649 mia
    old "But I regret it so much, it didn't bring anything good to my life. That period gave me very low self-esteem."
    new "اما خیلی پछمان دارم، هیچ چیز خوبی به زندگی من نیاورد. آن دوره اعتماد به نفسم رو خیلی کم کرد."

    # say L650 mia
    old "Besides, it caused me depression and anxiety that lasted for a very long time."
    new "البته، این موضوع باعث افسردگی و اضطرابی شد که طولانی طول کشید."

    # say L654 mia
    old "At the end I decided I couldn't take it anymore, so I just got away from it, and did everything I could to conceal that part of my past."
    new "در نهایت تصمیم گرفتم نمی‌توانم این وضعیت را تحمل کنم، پس از آن دور شدم و همه چیز را کردم تا این بخش از گذشته‌ام را پنهان کنم."

    # say L655 mia
    old "Finally things worked out, but I had to change my entire life, move city, change name, everything. Just to get away from it."
    new "در نهایت همه چیز درست شد، اما باید تمام زندگی‌ام رو تغییر بدم، شهر رو ترک کنم، اسمم رو عوض کنم، همه چیز. فقط برای دور شدن از آن."

    # say L656 mia
    old "You can imagine then how hard it is for me to see that material is still out there, and somebody could see it."
    new "می‌توانی فهمید که برای من چقدر سخت است که بدانم این مواد هنوز در دسترس هستند و ممکن است کسی آن‌ها را ببیند."

    # say L657 pla
    old "I mean, I get that. But what do you mean 'Still out there'?"
    new "من می‌فهمم. اما وقتی می‌گی‌ی «هنوز خارج هستن»، منظورت چیه؟"

    # say L658 pla
    old "I imagine that whatever you filmed before would just be on the internet, right?"
    new "من فکر می‌کنم هر چیزی که قبلاً فیلم کردی فقط در اینترنت باشه، درسته؟"

    # say L659 pla
    old "Why is it weird that Denzel has pictures and videos of you?"
    new "چرا عجیب است که دنزل عکس‌ها و ویدیوهایت رو داره؟"

    # say L660 mia
    old "Because..."
    new "چون..."

    # say L661 mia
    old "Even though I was working hard, I never actually left college, so when I got out of porn, I wanted to work on what I had studied."
    new "اگرچه سخت کار می‌کردم، اما هیچ وقت از دانشگاه فارغ‌التحصیل نشدم، پس وقتی از فیلم‌های عاشقانه خارج شدم، می‌خواستم روی آنچه مطالعه کرده بودم کار کنم."

    # say L662 mia
    old "It may be because I was so young, but I didn't think my previous job was going to be an issue."
    new "شاید به خاطر جوان بودنم، ولی فکر نمی‌کردم که شغل قبلی من مشکلی بسازه."

    # say L663 mia
    old "Nobody wanted to hire, a lot of parents, teachers, and principals at schools had seen my work."
    new "هیچ کس نمی‌خواست استخدام کنه، خیلی از والدین، معلمان، و مدیران مدارس کار من رو دیده بودند."

    # say L664 mia
    old "Ugh, they believed it was inappropriate for me to teach the children..."
    new "اوه، فکر می‌کردند برای تدریس به کودکان مناسب نیست."

    # say L665 mia
    old "I suppose it wasn't to jack up to my face."
    new "به نظر می‌رسه اونا با حالت من همخوانی نداشتن."

    # say L666 mia
    old "Anyway, I decided that since I wasn't working in that industry any longer I didn't want my videos and pictures out there."
    new "به هر حال، تصمیم گرفتم از آنجا که دیگر در اون صنعت کار نمی‌کردم، نمی‌خواستم ویدیوهایم و عکس‌هام خارج باشن."

    # say L667 mia
    old "So, I sued my previous producer, and I managed to get everything taken down."
    new "پس من بر ضد تولیدکننده قبلی‌ام شکایت کردم و توانستم همه چیز رو پاک کنم."

    # say L668 pla
    old "Wow, that's amazing."
    new "واو، این خیلی عالیه."

    # say L670 mia
    old "But it didn't really fix things where I lived, in the end, I had to move... several times."
    new "اما اونجور نتونستم مشکلات رو تو جایی که زندگی می‌کردم حل کنم، در نهایت باید چند بار برمی‌آمد."

    # say L671 mia
    old "A lot of people in different places knew who I was. Finally, I came to this place, where nobody seems to know me."
    new "البته، خیلی از مردم در جاهای مختلف می‌دونستن من کی هستم. در نهایت، به اینجا آمدیم که هیچ‌کس به نظر نمی‌رسه می‌دونه من کی هستم."

    # say L672 pla
    old "I understand, so you don't want people finding out about it."
    new "من متوجه شدم، پس نمی‌خوای این جا هم مردم ازش بشنوند."

    # say L674 mia
    old "Of course not, it's taken me a lot of work to build a life for myself here."
    new "البته نه، خیلی زحمت کشیدم تا زندگی‌ای برای خودم اینجا ساخته باشم."

    # say L676 pla
    old "I see, but how did he manage to get that material of you if it was all taken down?"
    new "من متوجه شدم، اما چطور موفق شد آن مطالب را پیدا کند در حالی که همه چیز پاک شده؟"

    # say L677 mia
    old "Honestly I have no idea, I've looked for hours on end for traces of my material."
    new "صراحیت بگم، هیچ ایده‌ای ندارم. ساعت‌ها به دنبال اثراتی از مطالب من جستجو کردم."

    # say L678 mia
    old "And I haven't been able to find anything, at all. So, it's a mystery to me that he was able to put his hands on it."
    new "و هیچ چیزی پیدا نکردم، حتی یک چیزی. پس برای من مرموز است که او بتواند به آن دست پیدا کند."

    # say L679 mia
    old "And now he's using it to blackmail me, either I do what he demands, or he takes it to the principal and outs me in front of everybody."
    new "و حالا اون از این برای ابتزاز من استفاده می‌کنه، یا من می‌تونم آنچه می‌خواد رو بکنم، یا اون به مدیر می‌ره و من رو در مقابل همه معلوم می‌کنه."

    # say L680 mia
    old "After all this work! You have no idea how hard it's been for me to rebuild my life!"
    new "بعد از همه این تلاش! تو نمی‌دونی چقدر سخت بود برای من که زندگیم رو دوباره سازگار کنم!"

    # say L682 mia
    old "How much I enjoy teaching! Instead of...!"
    new "چقدر لذت بردم از تدریس! به جای اینکه...!"

    # say L683 mia
    old "Instead of letting random actors do what they wanted to me on camera!"
    new "به جای اینکه بازیگران تصادفی برایم روی دوربین هatever کنند!"

    # say L685 mia
    old "What's worse about it, is that ever since he began blackmailing me, I've given him more content to use."
    new "باز اینجاست، از آن زمان که شروع کرد به تهدیدم، من محتوای بیشتری برای استفاده او ایجاد کردم."

    # say L686 mia
    old "Being that desperate I've been following his orders, and he has a lot of stuff of me doing inappropriate things at school."
    new "به این حد نیازمند شده‌ام که دستوراتش را انجام می‌دهم، و او خیلی چیزهای نامناسبی از من در مدرسه دارد."

    # say L687 mia
    old "Like that picture he took of us..."
    new "مثل آن عکسی که از ما گرفت..."

    # say L689 pla
    old "Listen, Ms. Mia, we'll do everything we can to stop him."
    new "بله، خانم میا، ما همه کارهایی که می‌تونیم برای متوقف کردن اون کار می‌کنیم."

    # say L691 mia
    old "Oh really? How?"
    new "اوه واقعاً؟ چطور؟"

    # say L692 pla
    old "Uh... I don't really know yet, but there must be a way."
    new "اوه... هنوز واقعاً نمی‌دونم، ولی حتماً راهی هست."

    # say L694 pla
    old "Maybe we can hack his computer, or follow him and steal it from him."
    new "شاید بتونیم کامپیوترش رو هک کنیم، یا پیشش بریم و ازش بگیریم."

    # say L695 pla
    old "Or maybe there's something we can use against him, like his place of work, or something like..."
    new "یا شاید چیزی هست که می‌تونیم براش استفاده کنیم، مثل جای کارش یا چیزی مثل این..."

    # say L696 mia
    old "Ok, enough! Who do you think you're talking to? Don't you think I already thought about every way I could handle this?"
    new "خوب، کافیه! فکر می‌کنی به کی حرف می‌زنی؟ آیا فکر نکردی که من هر راه ممکن برای این موضوع رو قبلاً بررسی کردم؟"

    # say L697 mia
    old "All of these suggestions of yours are very nice, but they amount to nothing."
    new "همه این پیشنهاداتت خوب هستن، ولی هیچ کاری نمی‌کنن."

    # say L698 mia
    old "So, I think it's better if we no longer talk about it, I'll deal with Denzel by myself."
    new "پس فکر می‌کنم بهتره دیگه در مورد این موضوع صحبت نکنیم، من خودم با دنزل برخورد می‌کنم."

    # say L699 pla
    old "What? B-but Miss Mia, I really want to help you, and..."
    new "چه؟ اما مس میا، من واقعاً می‌خوام به تو کمک کنم، و..."

    # say L700 mia
    old "That's very sweet, but there's nothing you can do for me [pla]."
    new "این خیلی شیرین است، اما هیچ کاری برای من نمی‌توانی انجام دهی [pla]."

    # say L701 pla
    old "But."
    new "اما."

    # say L702 mia
    old "Class Is about to start, your classmates will arrive soon and I don't want them catch us talking about this. So drop it!"
    new "کلاس قراره زود هم شروع بشه، همکلاسی‌هایت زود می‌رسن و نمی‌خوام اینجا با هم درباره این موضوع صحبت کنیم. پس این حرف رو بگذار!"

    # say L722 pla
    old "Fine."
    new "خوب."

    # say L734 mia
    old "Ok, from today on we'll talk about Latin American political history in the twentieth century."
    new "خب، از امروز به بعد درباره تاریخ سیاسی آمریکای لاتین در قرن بیستم صحبت خواهیم کرد."

    # say L735 mia
    old "And we'll start with the Cuban coup d'etat..."
    new "و ما با انقلاب کوبا شروع خواهیم کرد..."

    # say L741 mia
    old "Ok, that's all for today, I hope you took proper notes of the class."
    new "خوب، این همه برای امروز، امیدوارم نت‌های کلاس رو خوب گرفتید."

    # say L742 mia
    old "Remember to practice the subject at home, the test is very close, so don't relax too much and forget to study."
    new "به خاطر سپرده که موضوع رو در خونه تمرین کنید، امتحان خیلی نزدیکه، پس خیلی آرام نگیرید و فراموش نکنید مطالعه کنید."

    # say L743 mia
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term tests."
    new "می‌دونم به نظر می‌رسه کار زیادیه، اما اگه می‌خوای قبل از امتحان‌های پایان ترم همه دروست رو خوب یاد بگیری، باید این کار رو بکنی."

    # say L745 mik
    old "See you at the next class guys."
    new "به بعد در کلاس می‌بینم شما."

    # say L769 pla
    old "Oh! It's you."
    new "اوه! شما هستید."

    # say L772 den
    old "I came to see you, we need to talk."
    new "من برای دیدنت اومدم، باید باهم صحبت کنیم."

    # say L773 pla
    old "Do we?"
    new "نه، در مورد چی؟"

    # say L774 pla
    old "About what?"
    new "در مورد چی؟"

    # say L775 den
    old "About Mia, of course, I want you to work with me."
    new "البته در مورد میا، می‌خوام تو با من همکاری کنی."

    # say L776 pla
    old "You what?"
    new "تو چی می‌گی؟"

    # say L777 den
    old "Yeah dude, listen, she has no way to get out of this."
    new "بله داداش، بگو، او هیچ راهی برای خروج از این وضعیت نداره."

    # say L778 den
    old "I have all the information, and the videos and pictures. We can both use it to get revenge on her."
    new "من همه اطلاعات رو دارم، و فیلم‌ها و عکس‌ها رو هم. می‌تونیم هر دو ازش انتقام بگیریم."

    # say L779 pla
    old "Come on, revenge? Really?"
    new "بیا، انتقام؟ واقعاً؟"

    # say L781 den
    old "Listen, I know she's been terrible to you, right?"
    new "می‌شنوم، می‌دونم که به تو خیلی بد رفت، درسته؟"

    # say L782 den
    old "If we both work together, we can make that little bitch pay for everything she's done to us."
    new "اگه هر دو با هم کار کنیم، می‌تونیم اون خرک کوچیک رو برای همه چیزهایی که به ما کرده، بپرسیم."

    # say L783 den
    old "Besides, imagine all the things you can get her to do to you, just by telling her you'll release the pictures."
    new "البته، فکر کن به همه چیزهایی که می‌تونی ازش ببری، فقط با اینکه بهش بگی عکس‌ها رو منتشر می‌کنی."

    # say L784 den
    old "We'll make sure that she pays like the little slut she is."
    new "ما از اون خرک کوچیک که هستش، مطمئن می‌شیم که پرداخته."

    # say L785 den
    old "What do you say, huh?"
    new "بگو تو، ها؟"

    # say L786 pla
    old "What's wrong with you dude?! Revenge?! Make her pay? Slut?"
    new "تو چه مشکلی داری برو؟ انتقام؟ بپردازی؟ سکسی؟"

    # say L787 pla
    old "Are you really that twisted? The fuck?! This is a person's life you're talking about!"
    new "تو واقعاً همینقدر خرابی؟ فکر کنی این زندگی انسانیه که دربارهش حرف می‌زنی؟"

    # say L789 pla
    old "You would destroy her life just because she was a little mean to you?"
    new "تو می‌خوای زندگی‌اش رو خراب کنی فقط چون یه کم بد با تو بود؟"

    # say L790 pla
    old "There's something seriously wrong with you dude..."
    new "دستت خرابه شده براش، دیو..."

    # say L791 den
    old "Oh, so that's how it is, I thought you would understand, but it turns out you're just one of those moralist idiots."
    new "او، پس اینجوری هست، فکر کردم می‌فهمی، ولی به نظر می‌رسه تو فقط یکی از اونای اخلاق‌پژوه هستی."

    # say L792 pla
    old "I'm an molarist idiot? You're the one who thinks he can destroy someone's life and get away with it."
    new "من یک اخلاق‌پرست احمق هستم؟ تو هستی که فکر می‌کنی می‌تونی زندگی کسی رو نابود کنی و از آن بگذری."

    # say L793 den
    old "Don't give me that bullshit! Listen pal, Mia's just a simple whore who enjoys making others suffer."
    new "به من این بکلاه‌پوشی رو نده! بگو داداش، میا فقط یه دختر ساده‌ی رنگرزه که لذت می‌بره از آزار دادن به دیگران."

    # say L794 den
    old "What's wrong with making her pay for all of the bad shit she does?"
    new "می‌خوای چه چیزی اشتباه رو بپرداخت؟"

    # say L795 den
    old "After all, it's just giving her a taste of her own medicine."
    new "در نهایت، فقط به اون می‌دم چه طعمی که به دیگران می‌ده."

    # say L796 pla
    old "What's wrong with you? I won't do anything like that, you asshole."
    new "چه کاری داری؟ من هیچ کاری اینجوری نمی‌کنم، خر دیوانه."

    # say L797 pla
    old "It's true that Mia has a bad temper and a strong character, but not enough for you to justify destroying her life."
    new "درسته که میا خشمگین و قوی‌الشخصیته، اما نه به اندازه‌ای که تو بتونی اینطور به زندگی‌اش حمله کنی."

    # say L798 pla
    old "You're just hung up on some shit that happened a long time ago and you haven't been able to let it go."
    new "تو فقط به یه چیزی که از طولانی پیشه اتفاق افتاده خورده‌ای و نتونستی اونو از ذهنت برمونی."

    # say L800 den
    old "You're even more fucking stupid than I thought!"
    new "تو حتی احمق‌تر از آنچه فکر می‌کردم هستی!"

    # say L801 den
    old "But it's ok dude, you'll understand, after all, I can still punish Mia by myself."
    new "ولی برات خوبه بچه، متوجه می‌شی، در نهایت من همچنان می‌تونم خودم میا رو مجازات کنم."

    # say L803 pla
    old "Whatever you say dude, I don't want anything to do with you or your sick plans."
    new "باید بگم چه کاری می‌خوای، من هیچ ربطی به تو یا برناماهای خیلی بدتو نمی‌خوام."

    # say L804 den
    old "Yeah well, remember this, I'll take my revenge on Mia, and one way or another you'll have to do with it."
    new "بله، حتماً به خاطر بسپار، من انتقامم را از میا بگیرم و به هر نحوی که باشه، تو باید با این موضوع سروکار داشته باشی."

    # say L815 pla
    old "Wow, what is wrong with that guy?"
    new "وای، اون جونقی چی داره؟"

    # say L823 pla
    old "Oh, hey Belle, morning."
    new "اوه، سلام بله، صبح خوب."

    # say L824 bel
    old "Hey, who was that guy that was talking with you at the entrance? He looked like he was angry, were you arguing?"
    new "هی، آن دسته مردی که با تو در ورودی صحبت می‌کرد چه کسی بود؟ به نظر می‌رسید خشمگین بود، آیا با هم مناقشه داشتید؟"

    # say L825 pla
    old "Oh, him? He's just some guy I know, don't worry about it."
    new "اوه، اون؟ فقط یه نفریه که معرفی کردم، نگران نباش."

    # say L827 bel
    old "Hmm, I thought that maybe he has something to do with Ms. Mia."
    new "Hmm، فکر کردم شاید ارتباطی با خانم میا داشته."

    # say L828 pla
    old "W-why do you think that?"
    new "چرا فکر می‌کنی اینجوری؟"

    # say L829 pla
    old "Did you hear anything?"
    new "چی شنیدی؟"

    # say L831 bel
    old "Well, it's just that lately, I've seen you talking with Ms. Mia, so I figured that maybe he had something to do with it."
    new "خب، فقط اینجوریه که اخیراً دیدم تو با خانم میا صحبت می‌کنی، پس فکر کردم شاید او با این موضوع سر و کار داشته باشه."

    # say L833 pla
    old "Uhhh, no, no, he has nothing to do with it."
    new "اوه، نه، نه، او هیچ ربطی به این نداره."

    # say L834 pla
    old "I've just been talking to Ms. Mia about my grades, you know she's always harping on me."
    new "من فقط با خانم میا در مورد نمراتم صحبت می‌کنم، می‌دونی همیشه روی من تأکید می‌کنه."

    # say L836 bel
    old "Oh, I see, I guess you do need to pay attention to your grades."
    new "اوه، من متوجه شدم، به نظر می‌رسد باید به نمراتت توجه کنی."

    # say L846 mia
    old "Hey, it's time for classes, so come in!"
    new "بیایید وارد شوید، وقت کلاس هست."

    # say L851 mia
    old "Ok guys, it's time to start preparing for the midterm test, so today we'll do a couple of mock tests to help you get ready for it."
    new "بچه‌ها، وقت آماده شدن برای امتحان نیمه‌ساله رسیده، پس امروز چند تست آزمایشی خواهیم داشت تا به شما کمک کنم برای آن آماده شوید."

    # say L856 mia
    old "So, I hope you found the excersises useful, remember to practice again at home, the test is very close, so don't relax too much and forget to study."
    new "پس، امیدوارم تمرین‌ها برای شما مفید بوده باشد، به خاطر داشته باشید که در خانه هم دوباره تمرین کنید، آزمون خیلی نزدیک است، پس خیلی آرام نشینید و فراموش نکنید که مطالعه کنید."

    # say L892 mia
    old "[pla], wait a minute, I'll need you stay, we need to talk about your grades."
    new "[pla]، یه لحظه، باید بمونی، باید در مورد نمراتت صحبت کنیم."

    # say L907 mia
    old "What the fuck did you do?!! You idiot! I told you to stay out of it!"
    new "اوه شیطان، تو چه کاری کردی؟!! احمق! من بهت گفتم از این کار خارج بمونی!"

    # say L909 mia
    old "Denzel called me and was very fucking angry! He said you were gonna pay him for saying what you said!"
    new "دنزل به من تلفن کرد و خیلی خشمگین بود! گفت می‌خواهی برای اون حرفی که زدی بهش پول بدهی!"

    # say L910 mia
    old "What did you do?!"
    new "تو چه کاری کردی؟!"

    # say L911 pla
    old "Nothing, nothing! I swear to God! He's the one that came to talk to me this morning, when I was arriving at school!"
    new "هیچی، هیچی! قسمت خدا! او بود که امروز صبح با من صحبت کرد، وقتی به مدرسه می‌رسیدم!"

    # say L912 pla
    old "He wanted me to allie with him and help him mess with you."
    new "او می‌خواست من با او همکاری کنم و به تو آزار بدهم."

    # say L913 pla
    old "But I told him no, that I wasn't gonna be part of it."
    new "ولی بهش گفتم نه، نمی‌خوام توی این کار باشم."

    # say L914 mia
    old "Oh FUCK! Why did you have to get involved with this!"
    new "او فکر کنم! چرا باید تو در این جوری کارها دخل داشتی!"

    # say L915 mia
    old "This has nothing to do with you!"
    new "این هیچ ربطی به تو نداره!"

    # say L916 mia
    old "Because of what you told him he's now fucking angry!"
    new "به خاطر آنچه بهش گفتی حالا خشمگین شده!"

    # say L917 mia
    old "Listen to me [pla], stay out of this, okay?! This has absolutely nothing to do with you!"
    new "بگو به من [pla]، از این خارج بمان، بله؟! این هیچ ربطی به تو نداره!"

    # say L918 mia
    old "Don't talk to that guy, don't make contact. Nothing!"
    new "با آن دستگاه صحبت نکن، تماس نگیر. هیچ!"

    # say L919 mia
    old "Do you get it?!"
    new "فهمیدی؟!"

    # say L920 pla
    old "Whatever you say, but that guy is the one that came to me, and you know he's insane."
    new "همونی که می‌گی، اما اون دستاورد به من رسید و می‌دونی که دیوانه هست."

    # say L936 den
    old "I came to visit, I had to see my favorite teacher."
    new "من برای ملاقات اومدم، باید معلم مورد علاقه‌ام رو ببینم."

    # say L938 den
    old "And look at that! My good friend [pla] is here as well!"
    new "و ببین این! دوست خوبم [pla] هم اینجا است!"

    # say L939 den
    old "Good, good, just what I was expecting."
    new "خوب، خوب، همینطوری که منتظرش بودم."

    # say L942 pla
    old "Dude, don't you have anything else to do besides stalking Ms. Mia all day?"
    new "دستا، آیا هیچ کار دیگری برای انجام نداری جز دنبال کردن خانم میا طول روز؟"

    # say L943 den
    old "Heh, you shouldn't worry that much about what I do to fill my time."
    new "هه، نباید اینقدر نگران کارهایی که برای پر کردن وقتم انجام می‌دم باشی."

    # say L944 den
    old "It's more interesting what you're about to do!"
    new "این که تو قراره انجام بدی جالب‌تره!"

    # say L945 den
    old "After all, I think it's about time that you two start."
    new "در نهایت، فکر می‌کنم وقت خوبیه که شما دو تا شروع کنید."

    # say L947 den
    old "'Ms.' Mia, you haven't told him about the new challenge?"
    new "خانم میا، شما به او در مورد چالش‌های جدید هنوز نگفتی؟"

    # say L949 mia
    old "Don't even think about Denzel."
    new "حتی به دنزل فکر نکن."

    # say L950 mia
    old "It's not happening! No way in hell!"
    new "اینجوری نمی‌شه! هیچ راهی در جهنم هم نیست!"

    # say L951 den
    old "Well, that surprises me, I guess that you don't mind then about the school principal receiving an interesting mail, do you?"
    new "خب، این برای من مفاجا است، حدس می‌زنم شما به این نمی‌امیدوارید که مدرک‌دار به سر مدرسه یک ایمیل جالب برسد، درست است؟"

    # say L953 pla
    old "Wait, what's happening? What did you ask this time."
    new "پیش، چه کاری انجام شده؟ این بار چه خواسته‌ای داشتی."

    # say L955 den
    old "Tell him, Mia."
    new "بهش بگو، میا."

    # say L956 mia
    old "{i}*Sigh*{/i} The thing is, this sick bastard wants us to have sex."
    new "{i}*نفس کشیدن*{/i} خب، این بیمار جنسی می‌خواد باهام جنس کنیم."

    # say L957 pla
    old "What?! What the fuck?!"
    new "چه خبری؟ چه جوری اینجاست؟!"

    # say L958 pla
    old "There's something seriously wrong with you pal! That's way too far! I'm going to the police!"
    new "بچه‌مان، تو خیلی اشتباه کردی! این خیلی دور رفت! من به پلیس می‌رم!"

    # say L959 den
    old "HA! Do it! Fine by me!"
    new "حاه! انجام بده! برای من همین خوبه!"

    # say L960 den
    old "I mean, sure, maybe I'll get trial for blackmail, nothing severe 'cause you don't have any evidence..."
    new "منظورم اینه، شاید برای ابتزاز محاکمه بشم، ولی هیچ چی جدی نیست چون تو هیچ اثباتی نداری..."

    # say L962 den
    old "But what's gonna happen when they review the photos and videos I got from you, what do you think will happen then, eh [pla]?"
    new "ولی وقتی عکس‌ها و فیلم‌هایی که از تو گرفتم رو بررسی کنند، فکر می‌کنی چه می‌شه، ه؟ [pla]"

    # say L963 den
    old "All of that is gonna come out to the public, and everyone will know Mia used to be a pornstar."
    new "همه اینا به عمومیت خواهند رسید و همه می‌دانند میا قبلاً بازیگر فیلم‌های سکس بود."

    # say L964 den
    old "But that's not the worst part."
    new "اما این هنوز بدترین قسمت نیست."

    # say L965 den
    old "What will really make people angry is the fact that she's fucking her students."
    new "چیزی که مردم رو واقعاً خشمگین خواهد کرد اینه که او با دانش‌آموزانش می‌بازد."

    # say L966 den
    old "Imagine what will happen then, hahaha."
    new "پیش‌بینی کن چه اتفاقی می‌افتد، هاهاها."

    # say L967 pla
    old "W-what?! Fucking her student? The hell are you talking about?"
    new "و-وای! با دانش‌آموزش جنس می‌کنه؟ تو چه حرفی می‌زنی؟"

    # say L968 den
    old "I suppose you remember that picture I took of you the other day."
    new "فکر کنم به آن عکسی که از تو گرفتم به یاد داری."

    # say L969 den
    old "Come on, everybody will believe that you two have been fucking anyway."
    new "بیا، همه می‌گن شما دو تا با هم سکس می‌کنید."

    # say L970 den
    old "I'll just make it a reality."
    new "من فقط اون رو واقعی می‌کنم."

    # say L971 pla
    old "You're sick dude!"
    new "تو خیلی بیماری داداش!"

    # say L972 mia
    old "Wait [pla], stop... just stop."
    new "پیش ز[pla]، متوقف شو... فقط متوقف شو."

    # say L973 mia
    old "{i}*Sigh*{/i} All right Denzel, you win... We'll do it."
    new "{i}*تنفس*{/i} بخشه دنزل، تو برنده شدی... انجام میدیم."

    # say L974 pla
    old "You can't be serious!"
    new "می‌تونی جدی باشی؟"

    # say L975 pla
    old "You can't let this guy get away with something like that! We have to go to the police!"
    new "نمی‌تونی این جوری به این مرد اجازه بدی! باید به پلیس بریم!"

    # say L976 mia
    old "And then what?! You heard him! If we go to the police my life will be ruined!"
    new "بعد از اون چه؟ شنیدی چه گفت! اگه به پلیس بریم، زندگی من خراب می‌شه!"

    # say L977 mia
    old "Besides, with the other photos that he has, he could also drag you down with me!"
    new "البته، با عکس‌های دیگری که دارد، می‌تواند تو رو هم با من درگیر کنه!"

    # say L978 pla
    old "Hmph!"
    new "همف!"

    # say L980 mia
    old "Look, I don't want this, but I really need your help. Please [pla]."
    new "ببین، من نمی‌خوام اما واقعاً به کمکت نیاز دارم. لطفاً [pla]."

    # say L981 pla
    old "{i}*Sigh*{/i} Ok, I guess we have to."
    new "{i}*تنفر*{/i} خب، به نظر می‌رسه باید انجام بدیم."

    # say L983 mia
    old "Ok, Denzel, we'll do it."
    new "خب، دنزل، اینجوری کنیم."

    # say L984 den
    old "Fantastic! I knew you guys would come around!"
    new "عالی! میدونستم شما دو تا به این جهت خواهید آمد!"

    # say L985 den
    old "Ok, let's get to it!"
    new "باشه، بیایید شروع کنیم!"

    # say L986 mia
    old "What? Here? Now?"
    new "چه؟ اینجا؟ حالا؟"

    # say L987 den
    old "What would be better?"
    new "چه جایی بهتری می‌تونه باشه؟"

    # say L988 den
    old "It's ok, I don't think the janitor will come anytime soon. So nobody will notice us."
    new "خوبه، فکر نمی‌کنم پاک‌کننده زودتر بیاد. پس هیچ‌کس ما رو متوجه نمی‌شه."

    # say L989 pla
    old "Wait, 'us'? Does that mean you're gonna be here while we do it?"
    new "بیا، «ما»؟ این به معنی اینه که تو هم اینجا خواهی بود وقتی ما انجام میدیم؟"

    # say L991 den
    old "Of course I'm serious! What else am I going to do?"
    new "البته جدی هستم! چه کار دیگری می‌تونم بکنم؟"

    # say L992 den
    old "Besides, you can't be angry about it Mia, you're used to fucking in front of other people, right? This should be easy for you."
    new "البته، نمی‌تونی از این خیال بد بکنی میا، تو خودت همیشه تو جلوی دیگران سکس می‌کردی، درسته؟ این برایت خیلی آسون باید باشه."

    # say L993 den
    old "Just close your eyes and imagine it's the good old days. You whore."
    new "بستن چشماتو و فکر کن همین روزهای خوب قدیمی هست. شما میل‌جو."

    # say L994 den
    old "Oh, by the way, remember to take your tits out. You've been keeping them hidden, and I think it's time for you to let them out."
    new "او، بینهایت، به خاطر داشته باش تا سیناتو بیرون بیاری. از کی به اینجا پوشیدیشون، فکر می‌کنم وقت برای اینه که آنها رو آزاد کنی."

    # say L995 mia
    old "You're fucking pathetic."
    new "تو خیلی بی‌ارزشی هستی."

    # say L996 den
    old "Hehehe, sure, sure."
    new "هههه، البته، البته."

    # say L1005 den
    old "I bet you're happy getting drilled by that cock."
    new "حتماً تو خوشحالی که از اون ناخودآگاه لذت می‌بری."

    # say L1006 mia
    old "Ugh, whatever dude."
    new "اوه، هر چی دل تو خوش می‌کنه، جان."

    # say L1007 mia
    old "We're only doing this because you're forcing us, you ass."
    new "ما فقط اینجوری می‌کنیم چون تو ما رو مجبور می‌کنی، تو خر."

    # say L1008 den
    old "You know, you're making me sound like the bad guy, but I'm sure you're enjoying this."
    new "می‌دونی، تو منو مثل بدگی می‌تونی بگیری، اما مطمئن هستم که اینو لذت می‌بری."

    # say L1009 den
    old "You may fool yourself and others with this whole 'teacher' thing, but I know that you're really a whore."
    new "شاید خودت و دیگران رو با این حالت «معلم» فریب دی دی، ولی من می‌دونم که تو در واقع یه زن سخت‌پوستی هستی."

    # say L1010 mia
    old "You're sick."
    new "تو بیماری."

    # say L1011 den
    old "Hahaha, you keep fucking like the bitch you are."
    new "هahaha، همچون ماده‌ای که هستی ادامه می‌دهی به فک‌کردن."

    # say L1023 mia
    old "Oh come on!"
    new "اوه بیای بیای!"

    # say L1025 pla
    old "Come on dude!"
    new "بیا داداش!"

    # say L1026 den
    old "Oh, I'm sorry, I interrupted you guys when you were having such a sweet time together."
    new "اوه، معذرت، من شما رو وقتی که با هم زمان شیرینی داشتید قطع کردم."

    # say L1028 den
    old "I'm so rude."
    new "من خیلی بی‌آداب هستم."

    # say L1029 den
    old "But you see, now I have actual evidence that you guys fucked!"
    new "ولی ببین، حالا مدرک واقعی دارم که شما دو تا با هم سکس کردید!"

    # say L1030 den
    old "I guess that means that I now have two bitches instead of just one. Am I right?"
    new "بگو براتون الان دو تا خانم دارم به جای یکی. درسته؟"

    # say L1031 den
    old "Hahahahahahahaha."
    new "هahahaahaha."

    # say L1032 den
    old "I told you you were going to be a part of this [pla]."
    new "من به تو گفتم که قسمتی از این می‌شوی [pla]."

    # say L1033 mia
    old "You're really twisted."
    new "شما واقعاً خیلی پیچیده هستید."

    # say L1034 den
    old "I think I should get going, but don't worry guys, I'll be seeing you soon."
    new "فکر می‌کنم باید برسم، ولی نگران نباشید دوستان، زودی دوباره می‌بینیم هم."

    # say L1039 pla
    old "There's something seriously wrong with that guy's head."
    new "آره، با اون دستا به چیزی جدی مشکل داره."

    # say L1041 mia
    old "{i}*Sigh*{/i} Whatever. For now, let's just get dressed."
    new "{i}*تنفر*{/i} خب. برای حالا، بیایید فقط لباسمون رو بپوشیم."

    # say L1047 pla
    old "Listen, Ms. Mia, I know that what just happened's disheartening, but I'm sure there must be something we can do."
    new "بله، خانم میا، می‌دونم این حالت ناراحت کننده، ولی حتماً باید راهی برای حلش پیدا کنیم."

    # say L1048 pla
    old "We can't just give in to what that maniac wants."
    new "ما نمی‌تونیم به آنهایی که اون دیوانه می‌خواد، خودمون رو بدم."

    # say L1049 mia
    old "No, there isn't anything, he's already got us."
    new "نه، هیچ کاری نیست، او قبلاً ما را در دست خودش گرفته است."

    # say L1050 mia
    old "It's just as he says, we're his bitches."
    new "همانطور که او می‌گه، ما خرگوش‌هایش هستیم."

    # say L1051 mia
    old "Let's just leave it at that."
    new "بیاین همین جا خاتمه بدهیم."

    # say L1056 pla
    old "Damn it, there has to be something I can do, I'm sure of it."
    new "لعنتی، باید چیزی که بتوانم انجام بدم وجود داشته باشه، مطمئنم."

    # say L1077 mia
    old "Oh, thanks God, I found you! Please come here for a minute."
    new "اوه، ممنون از خدا، تو رو پیدا کردم! لطفاً یه لحظه اینجا بیا."

    # say L1084 mia
    old "Listen, I have to tell you something."
    new "بگو، باید چیزی به شما بگم."

    # say L1085 mia
    old "Denzel called me, he gave us another 'challenge'."
    new "دنزل به من تلفن کرد، او دوباره یه چالش جدید به ما داد."

    # say L1086 pla
    old "What? Are you for real?"
    new "چه؟ واقعاً؟"

    # say L1087 pla
    old "What does he want now?"
    new "الان چی می‌خواد؟"

    # say L1088 mia
    old "Well, every time he's given me a new 'challenge' to do, they have been getting riskier and riskier."
    new "خب، هر بار که به من یک چالش جدید داده، خطر آن‌ها بیشتر شده."

    # say L1089 mia
    old "This time is the same, he wants us to... Have sex in the school bathroom."
    new "این بار هم همینه، می‌خواد ما... جنس در آشپزخانه مدرسه داشته باشیم."

    # say L1091 pla
    old "Woah! Really? But that's way too risky!"
    new "واو! واقعاً؟ اما این خیلی خطرناکه!"

    # say L1092 pla
    old "I mean, last time everyone had already gone home. What will happen if someone sees us?"
    new "من قصه‌ای را می‌گویم، آخرین بار همه به خونه رفته بودن. اگه کسی ما رو ببینه چه می‌شه؟"

    # say L1093 mia
    old "I already thought of that, that's why I'm telling you now because everyone else is in their classrooms."
    new "من قبلاً به این فکر کردم، همین جوش بهت می‌گم چون همه‌ی دیگران توی کلاس‌هاشون هستند."

    # say L1094 mia
    old "If we do it now nobody should see us."
    new "اگر الان انجام بدیم هیچ‌کس نباید ما رو ببینه."

    # say L1096 pla
    old "So we should go have sex in the bathroom now?"
    new "پس باید الان برویم توی حمام جنس کنیم؟"

    # say L1097 mia
    old "That's right, he said I have to do a video call... for him to see us."
    new "درسته، او گفت باید تماس ویدیویی بکنم... تا بتواند ما را ببیند."

    # say L1098 pla
    old "Jesus! What the hell is wrong with that freak?!"
    new "جسوس! اون دیوانه چه مشکلی داره؟!"

    # say L1099 pla
    old "No way we're doing that."
    new "نه، این کار رو نمی‌کنیم."

    # say L1100 mia
    old "Not this again..."
    new "once more... این هم دوباره..."

    # say L1101 mia
    old "[pla], this is really difficult for me, you know? You know all the stuff he has of us."
    new "[pla]، این برای من واقعاً سخته، میدونی؟ میدونی همه چیزهایی که از ما داره."

    # say L1102 mia
    old "Please don't make me beg you again, I really need you to help me."
    new "لطفاً دوباره مرا به تو خواهان نکن، واقعاً به کمکت نیاز دارم."

    # say L1103 pla
    old "Hmm, yeah, you're right."
    new "Hmm، بله، درست می‌گی‌ی."

    # say L1104 pla
    old "{i}*Sigh*{/i} Ok, let's go then."
    new "{i}*تنفر*{/i} خب، برویم."

    # say L1111 pla
    old "I know I keep putting too many hurdles, but are you sure about this?"
    new "می‌دونم همیشه موانع زیادی می‌گذaram، اما تو در مورد این مطمئنی؟"

    # say L1112 mia
    old "As I already told you, we don't have any other choice."
    new "همانطور که قبلاً بهت گفتم، ما هیچ انتخاب دیگه‌ای نداریم."

    # say L1113 pla
    old "Hmph, yeah, yeah, you're right."
    new "هم، بله، بله، درست می‌گی‌ی."

    # say L1115 mia
    old "Ok, let's call this asshole."
    new "خب، بیایید این خرایش رو تماس بزنیم."

    # narrator L1116 
    old "... Ringing ..."
    new "... در حال زنگ زدن..."

    # say L1117 den
    old "Hello! Wow, you guys are early!"
    new "سلام! وای، شماها زود آمده‌اید!"

    # say L1118 den
    old "This is the perfect location, isn't it Mia?"
    new "این مکان کامل است، نه میا؟"

    # say L1119 den
    old "A dirty little place for a dirty little whore. Hahaha."
    new "یک جای خرد و خراب برای یک شور و خراب. هاهاها."

    # say L1121 den
    old "What about you [pla]? Aren't you happy you get to fuck your dear teacher again?"
    new "تو هم [pla] خوشحال نیستی که دوباره معلم عزیزم رو می‌بینی؟"

    # say L1122 pla
    old "Fuck you dude! Don't think you can keep getting away with this for too long."
    new "بیا تو را بزن! نباید فکر کنی می‌تونی همیشه از این بیرون بیاد."

    # say L1123 den
    old "Hahaha, whatever, let's just get started with this."
    new "هahasahaha، بله بله، بیایید شروع کنیم."

    # say L1124 den
    old "Oh! And remember to take your tits out Mia, I'm recording this, so I want it to be good quality."
    new "اوه! و به یاد داشت میا، سینات رو بیرون بیار، من اینو ضبط می‌کنم، می‌خوام کیفیت خوبی باشه."

    # say L1134 den
    old "Oh yeah, just like that, nice."
    new "اوه بله، همینطور، خوب."

    # say L1141 bel
    old "My gosh, I hate P.E. so much! I'm so sweaty!"
    new "من خدا، این ورزش روحی هم دوست ندارم! خیلی تعریق کردم!"

    # say L1145 bil
    old "Ugh, I know, like, look at my makeup!"
    new "اوه، می‌دونی، نگاه کن به مک‌آپم!"

    # say L1146 bil
    old "Now I'm gonna have to re-do it all over again!"
    new "الان باید همه‌ش رو دوباره انجام بدم!"

    # say L1147 bel
    old "Hey, by the way, had you noticed how Mia is acting lately?"
    new "بیل، بله، خودت هم دیدی اخیراً میا چطور رفتار می‌کنه؟"

    # say L1148 bil
    old "Oh my god yeah! She's acting like a whore, flashing off in front of the whole classroom!"
    new "اوه خدا ها بله! اونجور که یک شوهره‌شوهره عمل می‌کنه، جلوی همه در کلاس نشون می‌ده!"

    # say L1152 bil
    old "What was that?"
    new "چه بود؟"

    # say L1153 bel
    old "Like... a voice?"
    new "مثل... یه صدایی؟"

    # say L1159 bel
    old "Hmm, it's nothing, maybe somebody spoke in the hall."
    new "Hmm، هیچی، شاید کسی در راهرو حرف زده بود."

    # say L1160 bil
    old "Yeah, you're right."
    new "بله، درست می‌گی‌ری."

    # say L1161 bel
    old "Ok, I'm ready."
    new "باشه، آماده‌ام."

    # say L1162 bil
    old "Yeah, me too, let's go. Anyway, as I was telling you, what the fuck is wrong with Mia?"
    new "بله، من هم. برویم. به هر حال، همانطور که به تو می‌گفتم، میا چه مشکلی داره؟"

    # say L1167 pla
    old "Ok, ok, they are gone."
    new "باشه، باشه، رفتند."

    # say L1168 den
    old "Ha! What's the matter Mia? Afraid of getting caught?"
    new "ها! میا، چه کاری داری؟ از دستگیر شدن ترس داری؟"

    # say L1169 den
    old "But I know you like people seeing your pussy! What's the big deal?"
    new "ولی می‌دونم دوست داری افراد پوسی‌ت رو ببینن! مشکلش چیه؟"

    # say L1173 mia
    old "Ugh, let's just get this over with [pla]."
    new "اوه، بیایید این را تمام کنیم [pla]."

    # say L1182 pla
    old "Fuck, this is getting more and more risky!"
    new "این هر بار خطرناک‌تر می‌شه!"

    # say L1183 pla
    old "At the end it won't matter if he tells on us or not!"
    new "در آخر، مهم نیست اگه او به ما گزارش بده یا نه!"

    # say L1184 pla
    old "People will end up catching us anyway!"
    new "در نهایت ما هر طور خواهیم افتاد!"

    # say L1186 pla
    old "We have to do something."
    new "باید چیزی انجام بدیم."

    # say L1188 mia
    old "I'm also not happy with this. And It's already started to affect me, I can't even sleep well."
    new "من هم از این خوشحال نیستم. و این قسمت شروع کرده تا بر من تأثیر بگذارد، حتی نمی‌توانم خوب بخوابم."

    # say L1189 mia
    old "I'm starting to get severe anxiety again, and the nightmares have come back. But what can I do?"
    new "می‌تونم دیگه اضطراب شدید درمی‌یاد و کابوس‌ها هم برگشته‌ان. ولی من چه کنم؟"

    # say L1190 mia
    old "We can't just go to the police! I don't want to lose my life! And now he has stuff that's even worse!"
    new "ما نمی‌تونیم فقط به پلیس بریم! نمی‌خوام زندگیم رو از دست بدم! و حالا هم چیزهایی هست که حتی بدتر هستند!"

    # say L1191 pla
    old "I know this is hard, but there must be a solution."
    new "می‌دونم این سخته، ولی حتماً راه حلی هست."

    # say L1192 mia
    old "Well, if there is one I don't know what it may be."
    new "اگر راهی هست من نمی‌دونم چی می‌تونه باشه."

    # say L1193 mia
    old "Let's just let's get out of here before someone comes again."
    new "بیایید بیرون بریم قبل از این که دوباره کسی بیاد."

    # say L1198 pla
    old "(She's feeling really bad, I'm sorry for her.)"
    new "من برایش خیلی آسیب دیده است، خودت هم مرا ببخش."

    # say L1199 pla
    old "I bet there's something else I could do..."
    new "حتماً چیز دیگه‌ای هم می‌تونم بکنم..."

    # say L1200 pla
    old "Hmmm... But I do have the SexNote..."
    new "همم... ولی من SexNote دارم..."

    # say L1219 pla
    old "Hey Linett. How are you?"
    new "هی لینت. چطوری؟"

    # say L1220 lin
    old "Oh, [pla] I'm fine, thanks for asking, what about you?"
    new "اوه، [pla] من خوبم، ممنون از نگرانیت، تو چطوری؟"

    # say L1221 pla
    old "Hmm, a little bit worried actually, I have a small problem that I would like you to help me with."
    new "هم، یه کم نگران هستم در واقع، یه مشکل کوچیکی دارم که خواستم ازت کمک بگیرم."

    # say L1222 lin
    old "Oh, interesting."
    new "اوه، جالب."

    # say L1224 pla
    old "Well, I know a person that's being blackmailed."
    new "خب، می‌دونم یه نفری رو تشنیده کردن."

    # say L1226 lin
    old "Blackmailed? What is that?"
    new "تشنیده شدن؟ این چیه؟"

    # say L1227 lin
    old "I've never heard of it, is it some type of tradition between humans?"
    new "هیچ وقت از این شنیده‌ام، آیا این نوعی سنت بین انسان‌هاست؟"

    # say L1229 pla
    old "Uhh, somebody being blackmailed means that somebody else is threatening them with something that they care about."
    new "اوه، وقتی کسی را تشنیده می‌کنند، به این معناست که آن شخص با چیزی که برایش مهم است تهدید می‌کنند."

    # say L1230 pla
    old "That can be anything, something that belongs to them, or something they want."
    new "این هر چیزی می‌تونه باشه، چیزی که بهش متعلقه یا چیزی که می‌خواد."

    # say L1231 pla
    old "And if you don't do what that person wants, they'll punish you with what they have against you."
    new "و اگر تو آنچه را که اون شخص می‌خواهد نکنی، اون با آنچه را که در برابر تو دارد تو رو مجازات می‌کنه."

    # say L1232 lin
    old "Wow, that sounds horrible! You humans really are something else!"
    new "واو، این خیلی بد به نظر می‌رسه! شما انسان‌ها واقعاً چیزهایی هستید!"

    # say L1233 lin
    old "The type of things you do to each other is always surprising."
    new "حالتون همیشه متعجب کنن."

    # say L1234 pla
    old "Yeah, well, this person I know is going through that. So, I'm trying to help her."
    new "بله، این شخصی که می‌شناسم در حال عبور از اون مشکل هست. پس من سعی می‌کنم بهش کمک کنم."

    # say L1235 lin
    old "That's very good, you should do that."
    new "این خیلی خوبه، باید اینجوری کنی."

    # say L1239 lin
    old "Well, I'm glad I was able to help you [pla]."
    new "خوشحالم که بتونستم به تو کمک کنم [pla]."

    # say L1242 pla
    old "That wasn't the point."
    new "این همین نبود."

    # say L1243 lin
    old "Oh, ok, so what is it?"
    new "اوه، خب، پس چیه؟"

    # say L1245 pla
    old "Uhhh, I'll tell you the story, this person we're talking about is my teacher."
    new "اوه، خب، من داستان رو می‌گم، این شخصی که در موردش صحبت می‌کنیم معلم من هست."

    # say L1246 pla
    old "The thing is that some guy found some 'information' about her that she doesn't want anyone to see."
    new "البته، یه نفر اطلاعاتی در موردش پیدا کرده که نمی‌خواد هیچ کس ببینه."

    # say L1247 pla
    old "But there's no way of stopping him from putting it out there. At least not through anything we can do."
    new "اما راهی برای متوقف کردنش نیست. حداقل با هیچ کاری که ما می‌تونیم انجام بدیم."

    # say L1249 pla
    old "So, I was thinking that maybe there's a way to do it through the SexNote."
    new "پس فکر کردم شاید راهی هست که از طریق SexNote این کار رو انجام بدیم."

    # say L1250 lin
    old "What kind of information is this?"
    new "این اطلاعات چه نوعی هستند؟"

    # say L1251 pla
    old "It's videos and pictures, they must be safe in his computer or something."
    new "این ویدیوها و عکس‌ها هستند، باید در کامپیوترش یا چیزی مثل اون جا امن باشن."

    # say L1253 lin
    old "Well, don't you think it would just be easier if you steal his computer and delete that?"
    new "خب، آیا فکر نمی‌کنی اینجوری راحت‌تر باشه که کامپیوترش رو بیاری و اونا رو حذف کنی؟"

    # say L1255 pla
    old "I don't think that would do anything, he wouldn't be that stupid not to make any copies of it."
    new "فکر نمی‌کنم این کار هیچ کاری بکنه، او قطعاً نسخه‌ای از آن ساخته باشه."

    # say L1256 pla
    old "Besides, he also remembers it all, if he just tells the police or the press or anyone what he knows, they could find something."
    new "البته، او همه چیز رو به خاطر داره، اگه فقط به پلیس یا رسانه‌ها یا هر کسی اطلاعاتش رو بگه، می‌تونن چیزی پیدا کنن."

    # say L1257 lin
    old "Hmm, I see what you mean."
    new "هم، من متوجه شدم."

    # say L1258 lin
    old "So basically, what you want is a spell that'll change reality."
    new "پس در واقع، تو می‌خوای یه جادویی باشه که واقعیت رو تغییر بده."

    # say L1259 pla
    old "U-uh, w-what? I-I don't think..."
    new "ا-ا، چ-چه؟ من-من فکر نمی‌کنم..."

    # say L1261 lin
    old "Well, that's what you need, isn't it?"
    new "خب، این همینه چیزی که نیاز داری، درسته؟"

    # say L1262 lin
    old "I mean, you need every version of this information to disappear."
    new "من می‌گم، همه نسخه‌های این اطلاعات رو باید از بین ببری."

    # say L1263 lin
    old "That includes his memories, so that he won't go around telling it to people."
    new "این شامل خاطراتش هم هست، تا نتونه به مردم بگه."

    # say L1264 lin
    old "That's a very high requirement for a spell [pla]."
    new "این برای یک جادویی خیلی درخواست بالاست [pla]."

    # say L1266 lin
    old "But... There's a way..."
    new "ولی... راهی هست..."

    # say L1268 lin
    old "Something like that, there's a way to erase stuff magically... or at least their 'presence'."
    new "چیزی مثل این، راهی برای حذف چیزهایی به صورت جادویی وجود داره... یا حداقل حضورشون."

    # say L1270 pla
    old "'Presence'? W- what do you mean?"
    new "«حضور»؟ م- منظورت چیه؟"

    # say L1272 lin
    old "I mean just that, you humans live in a world full of traces, all of your technology is marked with traces of who you are."
    new "من همین رو می‌گم، شما انسان‌ها در جهانی زندگی می‌کنید که پر از نشان‌هاست، تمام تکنولوژی‌هایت با نشان‌های شخصیت تو پر شده."

    # say L1273 lin
    old "Like those pictures that you take of each other and then you can save or send."
    new "مثل آن عکس‌هایی که از هم می‌برید و بعد می‌تونید ذخیره کنید یا بفرستید."

    # say L1274 lin
    old "But also memories, whatever traces left by time in the mind of someone else. That's also a 'presence'."
    new "اما همچنین خاطرات، هر چه‌ای که زمان در ذهن کسی دیگر باقی می‌گذارد. این هم یک «حضور» است."

    # say L1275 lin
    old "All of that can be gone. With a big spell."
    new "همه اون‌ها می‌تونن بره. با یه جادوی بزرگ."

    # say L1276 lin
    old "I suppose that's what you mean when you say you want me to help you."
    new "بگویم این همینه که وقتی می‌گیه می‌خوای از من کمک بگیری."

    # say L1277 pla
    old "Uhh, I mean, I think I do, but I'm not sure. I- I don't really understand all what you said."
    new "ممنون، منظورم اینه که باید کمکت کنم، ولی هنوز نمی‌فهمم همه چیزی که گفتی."

    # say L1278 lin
    old "What I said is that I can use a spell that can erase all information about her, that's what you are asking me, right?"
    new "من گفتم که می‌تونم با یه جادو همه اطلاعاتش رو پاک کنم، اینجوری می‌خوای، درسته؟"

    # say L1279 pla
    old "Yes! That's exactly what I need..."
    new "بله! همین هست که می‌خوام..."

    # say L1280 pla
    old "And if you have another spell for the bad guy, you know, something to make him forget all about her."
    new "و اگر توری جادویی دیگه‌ای برای بدگuy هست، مثلاً چیزی که بشه همه یادش رو از او پاک کرد."

    # say L1282 lin
    old "Yeah, with the same spell the bad human doing the 'blackmail' thing, he won't even remember her."
    new "بله، با همین تکنیک، آدم بدی که این کار «تشدید» رو می‌کنه، حتی یادی از او نخواهد داشت."

    # say L1283 lin
    old "Everything about her would be forgotten."
    new "همه چیز در مورد او فراموش می‌شود."

    # say L1284 lin
    old "If he can't remember anything about her, and all the information he has is also gone. That would solve your problem, would it not?"
    new "اگر هیچ چیز از او را به یاد نداشته باشد و تمام اطلاعاتش هم از بین برود، مشکلت حل می‌شود، درسته؟"

    # say L1285 pla
    old "Wow! Yeah, that's perfect!"
    new "واو! بله، این کامله!"

    # say L1286 lin
    old "All right, this spell is somewhat difficult to execute, but is possible."
    new "باشه، این جادو کمی سخت برای انجام است، اما امکان‌پذیر است."

    # say L1288 pla
    old "Ok, what do I need?"
    new "باشه، چه چیزی به من لازم است؟"

    # say L1290 lin
    old "Hmm, to be honest, you're still not very good with magic..."
    new "هم، صادقانه بگم، هنوز خیلی خوب با جادو نیستی..."

    # say L1291 lin
    old "So, I'll have to prepare a lot of things beforehand to make it easier for you to use that spell."
    new "پس باید قبل از همه چیز چیزهای زیادی رو آماده کنم تا برایت راحت‌تر باشه این جادو رو استفاده کنی."

    # say L1292 pla
    old "Oh, it can't be done today? I mean, I have a bit of an urgency with this..."
    new "اوه، امروز نمی‌تونه انجام شه؟ منظورم اینه که برای این کار یه تاشویی دارم..."

    # say L1293 lin
    old "No, I'll need a couple of days to get everything ready, we can't afford any mistakes with this."
    new "نه، باید چند روز وقت بدهم تا همه چیز رو آماده کنم، نمی‌تونیم با این کار اشتباهی بکنیم."

    # say L1294 pla
    old "Hmm, I guess that's fine if there's no way to do it now."
    new "خوب، اگه الان امکانش نداره، باید صبر کنم."

    # say L1295 pla
    old "Thanks for your help Linnet, I'm counting on you."
    new "ممنون از کمکت لینت، به تو اعتماد دارم."

    # say L1296 lin
    old "I'll do my best to help you, don't worry."
    new "من تلاش خواهم کرد بهت کمک کنم، نگران نباش."

    # say L1304 pla
    old "I knew it, magic should be useful for something."
    new "میدونستم، جادو باید برای چیزی مفید باشه."

    # say L1305 pla
    old "With this I'm sure I'll be able to help Ms. Mia."
    new "با این مطمئنم که بتونم به خانم میا کمک کنم."

    # say L1328 mia
    old "[pla]... I'm gonna need you to come to the classroom with me."
    new "[pla]... لطفاً با من به کلاس بیای."

    # say L1329 pla
    old "Oh, not Denzel again, come on. What does he want now?"
    new "او، دوباره دنزل، بیای لبیا. الان از ما چی می‌خواد؟"

    # say L1330 mia
    old "Just come with me."
    new "بیا با من بیای."

    # say L1345 mia
    old "Denzel said he wanted to talk to both of us, let me call him and I'll put the call on speaker."
    new "دنسل گفت می‌خواست با هر دوی ما صحبت کنه، بیای برامون تماس ببرم و مکالمه رو به صورت گروهی بزنم."

    # say L1350 mia
    old "Denzel, hi."
    new "دنسل، سلام."

    # say L1351 den
    old "Hi there Ms. Mia! How are you? Is my good friend [pla] over there?"
    new "سلام خانم میا! حالتون چطوره؟ دوست خوب من [pla] اینجا هست؟"

    # say L1352 pla
    old "I'm here."
    new "من اینجا هستم."

    # say L1354 den
    old "Excellent, excellent! Ok, guys, I've been thinking, and I came to a conclusion."
    new "عالی، عالی! خب، بچه‌ها، من فکر کردم و به نتیجه‌ای رسیدم."

    # say L1356 den
    old "Well, I've decided that it's time for you two to take your relationship to the next level."
    new "خب، فکر کردم که وقتش رسیده تا شما دو تا رابطتون رو به مرحله بعد ببرید."

    # say L1357 den
    old "Given that you already consummated your teacher-student love."
    new "با توجه به اینکه رابطۀ معلم و دانش‌آموز رو قرار دادید."

    # say L1359 den
    old "I think you need to take the next step?"
    new "من فکر می‌کنم باید مرحله بعدی رو بردارید؟"

    # say L1360 pla
    old "The next step? We already had sex, what do you even mean?"
    new "مرحله بعد؟ ما قبلاً جنس کرده‌ایم، تو حرفی از چی می‌زنی؟"

    # say L1361 pla
    old "Stop beating around the bush and tell us already!"
    new "بگو حالا و خبرمون بده!"

    # say L1362 den
    old "Easy there buddy! Trust me, you'll like what I have in store for you guys today."
    new "آرام باش دوست من! بگو بهت اعتماد دارم، خوشت می‌آید آنچه برای شما در نظر دارم امروز."

    # say L1365 den
    old "Well, I want you to fuck Mia in the ass. It's time she gets her ass fucked."
    new "خب، می‌خوام تو میا رو از پشت بزنی. وقتش رسیده که میا این کار رو بکنه."

    # say L1367 pla
    old "W-what?!"
    new "و-وای!"

    # say L1368 mia
    old "I-I can't do that, I've never done it before! Not even when I was a porn actress!"
    new "من نمی‌تونم این کار رو بکنم، هیچ وقت انجام نداده‌ام! حتی وقتی بازیگر پورنو بودم هم نه!"

    # say L1369 den
    old "Well, I guess there's a first time for everything, am I right?"
    new "خب، حدس می‌زنم برای هر چیزی اول باری وجود داره، درسته؟"

    # say L1370 den
    old "Of course you'll do it on video call with me so that I can record it."
    new "البته که این رو توی تماس ویدیویی با من انجام می‌دی تا بتونم ضبط کنم."

    # say L1371 den
    old "We wouldn't want to waste that good material right?"
    new "می‌خوایم اون محتوای خوب رو ضایع نکنیم، درسته؟"

    # say L1372 pla
    old "You're crazy if you think we'll do this!"
    new "تو دیوانه‌ای اگر فکر می‌کنی ما اینو بکنیم!"

    # say L1374 pla
    old "This is way too much! We're not doing anything!"
    new "این خیلی زیاده! ما هیچ کاری نمی‌کنیم!"

    # say L1376 den
    old "Aww, this again dude?"
    new "اوه، دوباره این هست داداش؟"

    # say L1377 den
    old "Come on [pla], don't you ever get bored of this routine? It really annoys me that you say no to everything I tell you to do."
    new "بیا ز[pla]، آیا هیچ وقت از این روتین خسته نمی‌شوی؟ واقعاً به من بی‌پایان می‌آید که به هر چیزی که می‌گم نه می‌گی."

    # say L1378 den
    old "Only to then turn around and do it anyway."
    new "بعد از همه اینا هم همین کار رو انجام می‌دهی."

    # say L1379 den
    old "It really tests my patience, so shut up and do it!"
    new "این حقیقت صبرم رو می‌آزمایه، پس بسته شو و انجام بده!"

    # say L1380 pla
    old "We're not doing anything!"
    new "ما هیچ کاری نمی‌کنیم!"

    # say L1381 mia
    old "W- wait [pla]!"
    new "ب- بیا [pla]!"

    # say L1382 mia
    old "You know we have to do it. We have no choice."
    new "می‌دونیم باید این کار رو بکنیم. هیچ انتخابی نداریم."

    # say L1383 mia
    old "If what he has on us comes out we'll both be ruined!"
    new "اگر اون چیزی که از ما داره بیرون بیاد، هر دو ما خراب می‌شیم!"

    # say L1384 pla
    old "No! Think about it!"
    new "نه! فکر کن!"

    # say L1385 pla
    old "What is it going to be next time?! He already made us do all those things! Next time he'll make us fuck in the principals office!"
    new "بعداً چه خواهد بود؟! او قبلاً ما رو به همه آن کارها ترغیب کرده! بعداً ما رو مجبور به سکس در دفتر رئیس مدرسه خواهد کرد!"

    # say L1386 mia
    old "But we have to!"
    new "اما ما باید!"

    # say L1387 pla
    old "No we don't, and I won't do anything!"
    new "نه ما نمی‌تونیم و من هم هیچ کاری نمی‌کنم!"

    # say L1388 den
    old "That so? Well, then I guess you leave me no choice."
    new "این همچین؟ خب، پس به نظر می‌رسه انتخابت رو برای من تنظیم کردی."

    # say L1389 den
    old "I suppose this was gonna happen anyway, I was already getting bored with you two."
    new "به نظر می‌رسه اینجوری هم می‌شده، من قبلاً از شما دو تا خسته شده بودم."

    # say L1390 mia
    old "Wait! Wait! Give us a minute, I can convince him!"
    new "انتظار کن! یک دقیقه بده، من می‌تونم او رو قانع کنم!"

    # say L1391 den
    old "You already heard him Mia, he's not gonna do anything."
    new "میا، تو قبلاً شنیدی چه گفت، او هیچ کاری نمی‌کنه."

    # say L1392 den
    old "So, I guess he's fine with me sending the information out."
    new "پس فکر کنم او با ارسال اطلاعات توسط من موافقت دارد."

    # say L1393 den
    old "And that's what I will do, I'll send it straight to your school's principal."
    new "و این هم کاری است که خواهم کرد، اطلاعات رو مستقیم به رئیس مدرسه‌ت می‌فرستم."

    # say L1394 den
    old "I'll be eager to see how things pan out for you 'Ms.' Mia."
    new "من خوشحالم که ببینم چطور برایت پیش می‌رود، میا."

    # say L1395 mia
    old "No, please don't' do this!"
    new "نه، لطفاً این کار را نکنید!"

    # say L1396 den
    old "I have to say it was an honor to be a student of Mia the pornstar."
    new "باید بگم که افتخار داشتم دانش‌آموز میا پورن‌استار بودم."

    # say L1397 den
    old "I bet that when things blow out, you'll get that job back in no time."
    new "مطمئنم وقتی همه چیز از بین برود، شغلت رو دوباره به سرعت بدست بیاوردی."

    # say L1399 den
    old "And [pla], you see what you fucking did? I hope you're happy with that!"
    new "و [pla]، می‌بینی چه کاری انجام دادی؟ امیدوارم از این خوشحال باشی!"

    # say L1400 mia
    old "Wait... Hello? Denzel?? Hello?"
    new "انتظار دارم... دنزل؟؟ سلام؟"

    # say L1401 mia
    old "Oh, no, no, no, no, no!"
    new "اوه، نه، نه، نه، نه، نه!"

    # say L1404 mia
    old "What the fuck you did [pla]! I have to call him again..."
    new "اوه، شیطون، تو چه کاری کردی [pla]! باید دوباره بهش تلفن کنم..."

    # narrator L1406 
    old "... Ringing... {w} Ringing..."
    new "... در حال زنگ زدن... {w} در حال زنگ زدن..."

    # say L1408 mia
    old "FUCK! HE DOESN'T ANSWER!"
    new "فکر کنم! او پاسخ نمی‌ده!"

    # say L1411 mia
    old "Oh my gosh! Why did you do that? You idiot!!"
    new "اوه خداوند! چرا این کار رو انجام دادی؟ احمق!!"

    # say L1412 mia
    old "Don't you care what will happen to you?! Or me?!"
    new "آیا نگران نیستی اتفاقاتی که برایت خواهد افتاد؟ یا برای من؟!"

    # say L1413 mia
    old "You said you wanted to help me, and this is what you do?!!"
    new "تو گفتی می‌خواهی به من کمک کنی، و این کاری که می‌کنی اینه؟!!"

    # say L1414 mia
    old "You fucking asshole! What are we going to do now?!"
    new "شما خر شیطانی! حالا چه کاری می‌کنیم؟!"

    # say L1415 pla
    old "You know he was going to do this sooner or later. He's that type of bastard."
    new "دیویس، می‌دونی اون جور کسی هست. قرار بود همین طور بکنه."

    # say L1416 mia
    old "Well, he did it now! So what are we going to do?!"
    new "خب، الان انجامش داد! پس ما حالا چه کاری می‌کنیم؟!"

    # say L1417 pla
    old "Calm down, listen, look, he kept talking about a mail."
    new "آرام شو، گوش کن، ببین، او همیشه درباره یک ایمیل حرف می‌زد."

    # say L1418 pla
    old "Which means he's gonna have to send it through some physical means, a cd or a usb."
    new "این بدان معناست که باید اون رو از طریق چیزی مادی مثل دی‌وی‌دی یا یو‌اس‌بی بفرسته."

    # say L1419 mia
    old "So?!"
    new "پس؟!"

    # say L1420 pla
    old "So, all we have to do is intercept it before it arrives. Even if it's an express delivery, that's going to take a little while."
    new "پس همه چیزی که باید بکنیم اینه که قبل از رسیدنش، آن رو مسدود کنیم. حتی اگه ارسال سریع باشه، همچین کاری مدتی طول می‌کشه."

    # say L1421 mia
    old "And then what? Even if we stop that, he still has copies!"
    new "بعد از این چه؟ حتی اگر اونو متوقف کنیم، هنوز کپی‌های دیگه‌اش هست!"

    # say L1422 mia
    old "He could just send it to the police! Or the news! Or somewhere else!"
    new "می‌تونه به پلیس بفرسته! یا به خبرنگاران! یا جای دیگه!"

    # say L1423 mia
    old "Then what?!"
    new "بعد از این چه؟!"

    # say L1424 pla
    old "Ha, I've got a way to deal with that."
    new "حاحا، من راهی برای این مشکل دارم."

    # say L1425 pla
    old "Listen, I'm going to need you to trust me on this, ok?"
    new "بگوش، باید برای این کار به من اعتماد کنی، خوبه؟"

    # say L1426 pla
    old "If everything goes according to my plan, not only will everything remain a secret, you'll never have to worry about it ever again."
    new "اگر همه چیز مثل طرح من اتفاق بیفتد، نه فقط همه چیز مخفی می‌مونه، بلکه هیچ وقت نگرانش نمی‌تونی باشی."

    # say L1428 mia
    old "What are you going to do?"
    new "چه کاری می‌کنی؟"

    # say L1429 pla
    old "That... I can't tell you, but trust me, everything's going to be alright."
    new "این... نمی‌تونم به تو بگم، ولی باور کن، همه چیز خوب می‌شه."

    # say L1430 pla
    old "All I have to do is go check if everything's ready."
    new "من فقط باید بررسی کنم همه چیز آماده است."

    # say L1432 mia
    old "What are you talking about? You're not making any sense!"
    new "درباره چی حرف می‌زنی؟ هیچ معنایی نداره!"

    # say L1433 pla
    old "I know you don't get it right now, but you'll see... Please just trust me."
    new "می‌دونم الان متوجه نیستی، ولی ببینی... لطفاً فقط به من اعتماد کن."

    # say L1434 mia
    old "I guess I have no choice..."
    new "باید اعتماد به من کنی، اما خوب، به نظر می‌رسه گزینه‌ام نیست..."

    # say L1435 pla
    old "For now, we have to deal with what Denzel's about to send to the school principal."
    new "برای حالا، باید با آنچه دنزل به سرپرست مدرسه می‌فرسته، سروکار داشته باشیم."

    # say L1436 pla
    old "That's the priority."
    new "این اولویتمونه."

    # say L1437 mia
    old "What do you propose then?"
    new "پس شما چه پیشنهادی دارید؟"

    # say L1438 pla
    old "I think we're gonna have to steal it."
    new "من فکر می‌کنم باید اون رو پیکربندی کنیم."

    # say L1439 pla
    old "For now just stay here and check if a delivery guy comes, I'll go to my house to check on things."
    new "برای حالا فقط اینجا بمان و ببین آیا کسی برای تحویل آمده، من می‌روم به خونه‌ام برای بررسی."

    # say L1441 mia
    old "Again, what are you talking about?!"
    new "once more، تو درباره چی حرف می‌زنی؟!"

    # say L1442 pla
    old "As I said, you'll understand later."
    new "همانطور که گفتم، بعداً متوجه می‌شوی."

    # say L1443 pla
    old "But I really have to rush home, will you stay here and check if anything arrives?"
    new "اما واقعاً باید به سرعت برم خونه، می‌تونی اینجا بمونی و ببینی چیزی می‌رسه؟"

    # say L1444 mia
    old "Yes, fine, I'll be here. You better know what you're doing."
    new "بله، خوب، من اینجا می‌مونم. باید مطمئن باشی که می‌دونی چی می‌کنی."

    # say L1446 pla
    old "I really think I do. I'll be back soon."
    new "من واقعاً فکر می‌کنم همینطوره. زود بر می‌گردم."

    # say L1451 mia
    old "I can't believe it, now everything depends on him..."
    new "باورم نمی‌شه حالا همه چیز به او بستگی داره..."

    # say L1457 pla
    old "Hey! Linnet!"
    new "اوه، لینت!"

    # say L1458 lin
    old "Oh, hi [pla]."
    new "اوه، سلام [pla]."

    # say L1459 pla
    old "I'm going to need that spell of yours right now."
    new "من الان به سحرتو نیاز دارم."

    # say L1460 pla
    old "Do you think we can use it?"
    new "فکر می‌کنی می‌تونیم ازش استفاده کنیم؟"

    # say L1462 lin
    old "No, we can't, this is a process [pla], and we can't just force it out. Sorry."
    new "نه، نمی‌تونیم، این یه فرایند [pla]ه و نمی‌تونیم فقط اون رو اجباری کنیم. ببخشید."

    # say L1463 pla
    old "Oh really?! Fuck I really need it now..."
    new "اوه واقعاً؟! خدایی من واقعاً الان نیاز دارم..."

    # say L1464 pla
    old "When do you think we'll be able to do it?"
    new "فکر کنم چه زمانی بتونیم این کار رو بکنیم؟"

    # say L1465 lin
    old "Well, if I'm quick with this, tomorrow, I'll need another day."
    new "خب، اگر سریع باشم، فردا، ولی باید یک روز دیگه وقت بدهم."

    # say L1467 pla
    old "Hmm... Are you sure it'll be ready tomorrow?"
    new "Hmm... مطمئنی فردا آماده می‌شه؟"

    # say L1468 lin
    old "Yeah, it'll be difficult, but I can make it."
    new "بله، سخت خواهد بود، اما می‌تونم انجام بدم."

    # say L1469 pla
    old "Ok, then I guess we'll have to find a way to make it tomorrow."
    new "باشه، پس باید راهی پیدا کنیم که فردا آماده شه."

    # say L1470 pla
    old "Please help me with that, I really need it as soon as possible."
    new "لین، لطفاً به من در این بخش کمک کن، واقعاً بهش نیاز دارم و هر چه زودتر."

    # say L1471 lin
    old "Ok then I will continue working on the spell."
    new "خب، من ادامه می‌دم کار روی جادوی."

    # say L1483 mia
    old "Hey, what happened? I have been waiting for you... Did you get what you need? Is everything solved?"
    new "اوه، چه اتفاقی افتاد؟ منتظرت در اینجا بودم... چیزی که نیاز داشتی را پیدا کردی؟ همه چیز حل شده؟"

    # say L1484 pla
    old "Hmm, n-not really."
    new "Hmm، نه واقعاً."

    # say L1485 pla
    old "It's almost ready, but it's still going to take a little while."
    new "تقریباً آماده شده، اما هنوز یه کم وقت می‌بره."

    # say L1486 pla
    old "At least until tomorrow."
    new "حداقل تا فردا."

    # say L1487 mia
    old "I still don't understand, what's going to take until tomorrow?"
    new "من هنوز متوجه نشدم، چه چیزی تا فردا طول می‌کشد؟"

    # say L1489 pla
    old "Just trust me. After tomorrow everything will be solved."
    new "فقط به من اعتماد کن. بعد از فردا همه چیز حل می‌شه."

    # say L1491 mia
    old "Are you going to kill Denzel?"
    new "آیا قصد داری دنزل رو بکشی؟"

    # say L1492 pla
    old "What?! No! How can you think something like that?"
    new "چه!؟ نه! چطور می‌تونی چیزی مثل این فکر کنی؟"

    # say L1494 pla
    old "Just relax. You'll get it tomorrow.."
    new "فقط آرامش کن. فردا می‌گیری."

    # say L1495 pla
    old "But we're gonna have to deal with the delivery."
    new "ولی باید با ارسال سروکار داشته باشیم."

    # say L1496 pla
    old "We have to find a way to steal away what Denzel sent today."
    new "باید راهی پیدا کنیم که آنچه دنزل امروز فرستاده رو پنهان کنیم."

    # say L1497 pla
    old "So that the principal won't see them."
    new "پس اینجوری مدیر مدرسه نمی‌بینه."

    # say L1498 mia
    old "Well, she's already gone home. So even if it arrives today, she won't see it until tomorrow."
    new "خب، او قبلاً به خونه رفته. پس حتی اگر امروز برسه، تا فردا نمی‌تونه ببینه."

    # say L1499 pla
    old "Ok, so I suppose we'll have to steal it tomorrow before she sees it."
    new "باشه، پس فکر کنم باید فردا قبل از اینکه ببینه، آن رو مخفی کنیم."

    # say L1500 pla
    old "We'll have to arrive very early. Before she does."
    new "باید خیلی زود برسیم. قبل از اون که اونجا برسه."

    # say L1501 pla
    old "After that everything will be fine."
    new "بعد از آن همه چی خوب می‌شه."

    # say L1503 mia
    old "It will? But what are you going to do?"
    new "اینطور خواهد بود؟ اما تو قراره چی کنی؟"

    # say L1504 pla
    old "I just can't tell you."
    new "من فقط نمی‌تونم به تو بگم."

    # say L1506 mia
    old "Damn, ok, whatever. You better make whatever you do really work..."
    new "لعنتی، خب، هر چی. باید کاری که می‌کنی واقعاً جایی برسونه..."

    # say L1507 pla
    old "Don't worry."
    new "نگران نباش."

    # say L1508 mia
    old "So, we'll meet here tomorrow?"
    new "پس، فردا اینجا می‌بیایی؟"

    # say L1510 pla
    old "Yeah, before classes."
    new "بله، قبل از کلاس‌ها."

    # say L1511 mia
    old "Ok, that's it then. Don't be late."
    new "خوب، اینجاست. دیر نباش."

    # say L1512 pla
    old "Of course not."
    new "البته نه."

    # say L1513 mia
    old "All right, see you tomorrow then."
    new "البته، فردا می‌بینیم."

    # say L1514 pla
    old "Ok, don't worry tomorrow this will all be over."
    new "باشه، نگران نباش، فردا همه اینا تمام می‌شه."

    # say L1533 pla
    old "Hi, Ms. Mia."
    new "سلام، خانم میا."

    # say L1534 mia
    old "At this point I think just Mia's fine."
    new "در این مرحله فکر می‌کنم فقط میا خوبه."

    # say L1536 mia
    old "Ok, so I came in very early to check that the coast is clear."
    new "خوب، من خیلی زود اومدم تا بررسی کنم همه خالیه."

    # say L1537 mia
    old "Nobody's around."
    new "هیچ‌کس اینجا نیست."

    # say L1538 pla
    old "That's perfect, so we should be able to get it with no problem."
    new "این خوبه، پس باید بتوانیم بدون هیچ مشکلی این کار رو انجام بدیم."

    # say L1539 mia
    old "Ok, let's go, we need to check out the principal's office."
    new "باشه، برویم، باید ادارهٔ مدرسه رو بررسی کنیم."

    # say L1554 pla
    old "Have you found anything?"
    new "چیزی پیدا کردی؟"

    # say L1555 mia
    old "Nothing, everything look's fine."
    new "هیچی، همه چیز خوب به نظر می‌رسه."

    # say L1556 pla
    old "Hmm, there must be something."
    new "Hmm، باید چیزی باشه."

    # say L1566 pla
    old "Ah, that must be it."
    new "آره، احتمالاً همینه."

    # say L1568 pla
    old "Why else would there be a CD on her desk?"
    new "چرا همینجوری یه دی‌سی روی میزش قرار داره؟"

    # say L1569 mia
    old "Yeah, you're probably right. It must've arrived during the evening and the janitor put it here."
    new "بله، احتمالاً درست می‌گویی. باید روی آمده باشه و پرتقال‌کشش اینجا گذاشته باشه."

    # say L1572 mia
    old "Ok, so what do we do now?"
    new "خب، الان ما چه کاری می‌کنیم؟"

    # say L1573 pla
    old "What we have to do is just..."
    new "باید فقط..."

    # say L1575 mia
    old "Wait! I just heard something! I think someone's coming."
    new "بیا! چیزی شنیدم! فکر کنم کسی می‌آید."

    # say L1576 mia
    old "Quick get in that closet."
    new "سریع وارد آن لباسشویی شو."

    # say L1588 pla
    old "What are we going to do?"
    new "ما چه کاری باید بکنیم؟"

    # say L1589 mia
    old "Shhhh, someone's coming, they'll hear us."
    new "شhhh، کسی می‌آید، ما را می‌شنوند."

    # say L1597 dir
    old "Ok, I see some correspondence arrived yesterday. What do we have here?"
    new "باشه، می‌بینم چند نامه دیروز رسیده. اینجا چه خبری هست؟"

    # say L1600 dir
    old "Oh! Not the auditing process again!"
    new "اوه! دوباره فرآیند بررسی نباشد!"

    # say L1603 dir
    old "The day just started and it's already ruined, everytime they do it we have to jump through so many hurdles."
    new "روز فقط شروع شده و قدرت رو از دست داده، هر بار که این کارو می‌کنن باید از تعداد زیادی موانع عبور کنیم."

    # say L1608 dir
    old "{i}*Sigh*{/i} I guess there's nothing to do, I'll just deal with it."
    new "{i}*تنفر*{/i} به نظر می‌رسه هیچ کاری نداره، باید با این مشکل برخورد کنم."

    # say L1609 dir
    old "But first..."
    new "ولی اول..."

    # say L1615 dir
    old "Nothing wrong with dealing with some stress early before work."
    new "هیچ اشکالی نداره که قبل از کار یه کم استرس رو بردارم."

    # say L1616 dir
    old "I don't usually do this here at the office, but what the hell."
    new "معمولاً اینجوری کار نمی‌کنم، ولی چه خوبه."

    # say L1617 dir
    old "It's been quite a while, I think it will be fun."
    new "از دیرباز است، فکر کنم خوشحال می‌شوم."

    # say L1620 mia
    old "What the hell? Do you actually have a boner right now?"
    new "چه خبر؟ حالا اینجوری شدی که هیچ وقت نمی‌تونی جلوی من سخت بشی؟"

    # say L1621 pla
    old "S- sorry, I just can't help it."
    new "ببخشید، من فقط نمی‌تونم کنترلش کنم."

    # say L1622 pla
    old "It's not my intention."
    new "من قصد ندارم."

    # say L1623 mia
    old "Ugh, you're incredible, I can't believe you."
    new "اوه، شما واقعاً عالی هستید، باور نمی‌کنم."

    # say L1633 dir
    old "Mmm, oh yeah, this is just what I needed."
    new "ممنون، این همینه که لازم داشتم."

    # say L1634 dir
    old "Oh! It's so good!"
    new "اوه! خیلی خوبه!"

    # say L1635 dir
    old "That's it, yeah, yeah."
    new "آره، همینه، همینه."

    # say L1638 pla
    old "Wow, she is..."
    new "وای، او..."

    # say L1639 mia
    old "Shhh..."
    new "شhhh..."

    # say L1646 pla
    old "W-what are you doing?"
    new "و-و تو چه کاری می‌کنی؟"

    # say L1647 mia
    old "Shhh, be quiet, she'll find us if you keep talking."
    new "ش ه، بی‌صدا باش، اگه هنوز حرف بزنی، ما رو پیدا می‌کنه."

    # say L1648 pla
    old "But you're- ..."
    new "ولی تو..."

    # say L1649 mia
    old "Shhh, just shut up!"
    new "ش ه، فقط بسش کن!"

    # say L1657 dir
    old "Fantastic!"
    new "عالی!"

    # say L1658 dir
    old "But I better go check on things around the school before the students arrive."
    new "اما بهتره قبل از رسیدن دانش‌آموزان، امور مدرسه رو بررسی کنم."

    # say L1667 mia
    old "Mmm! Oh! Oh yeah!"
    new "می‌آه! اوه! اوه بله!"

    # say L1669 pla
    old "Hmm, M-Mia, the principal just left."
    new "هم، م-میا، رئیس مدرسه همین الان رفت."

    # say L1670 pla
    old "I think we better get out of here before she or anybody else comes back."
    new "فکر کنم بهتره قبل از اینکه او یا هر کس دیگری برگرده، از اینجا بیرون برویم."

    # say L1671 mia
    old "Uh, what? Oh yeah!"
    new "آه، چی؟ اوه، بله!"

    # say L1672 mia
    old "You're right, l- let's get out of here."
    new "درست می‌فرمایید، بیایید از اینجا برویم."

    # say L1684 mia
    old "Ok, we have to go then, we can't keep wasting any more time here."
    new "خب، باید برویم، نمی‌تونیم دیگه وقت بیشتری اینجا بگذرونیم."

    # say L1685 pla
    old "Yeah, I guess you're right, don't forget to bring the CD."
    new "بله، احتمالاً درست می‌گی‌ی، فراموش نکن دیسک رو ببری."

    # say L1707 mia
    old "Phew, it's good that we made it."
    new "پوف، خوشحالم که تونستیم برسیم."

    # say L1708 mia
    old "I can't believe we almost got caught. Hehe, right?"
    new "نمی‌تونم باور کنم تقریباً گرفتار شدیم. هاها، درسته؟"

    # say L1709 pla
    old "Eh, yeah, you're right haha, that was close, phew!"
    new "آره، هاها، درست می‌گی، این خیلی نزدیک بود، پوف!"

    # say L1711 mia
    old "What now then?"
    new "الان چه کاری باید بکنیم؟"

    # say L1713 pla
    old "Well, we're relieved, but we're not sure if this really is what we were looking for."
    new "خب، آرام شدیم، اما نمی‌دونیم این واقعاً همون چیزی بود که دنبالش می‌رفتیم."

    # say L1714 pla
    old "So we better check in the computer to see if it is."
    new "پس بهتره در کامپیوتر بررسی کنیم که این هست یا نه."

    # say L1716 mia
    old "Yeah, you're right, we should check."
    new "بله، درست می‌فرمایید، باید بررسی کنیم."

    # say L1722 pla
    old "That's very weird, there only seems to be a single video."
    new "این خیلی عجیب است، فقط یک ویدیو وجود دارد."

    # say L1723 pla
    old "Nothing else."
    new "هیچ چیز دیگری نیست."

    # say L1724 mia
    old "Well, open it, we need to see if it is."
    new "خب، باز کن، باید ببینیم اینه یا نه."

    # say L1734 pla
    old "Woah! I wasn't expecting that."
    new "واو! این رو منتظر نبودم."

    # say L1735 mia
    old "Oh my god! It is."
    new "اوه خداوند! هست."

    # say L1736 mia
    old "I can't believe he actually found something."
    new "باورم نمی‌شه که واقعاً چیزی پیدا کرده."

    # say L1737 mia
    old "It seems the producers didn't get rid of everything as I wanted them to."
    new "به نظر می‌رسد تولیدکنندگان همه چیز را مثل آنچه من می‌خواستم حذف نکرده‌اند."

    # say L1738 mia
    old "How did Denzel get his hands on this?"
    new "دنسل چطور به این چیز دست یافته؟"

    # say L1753 dir
    old "I need to see you both in my office."
    new "من باید هر دو شما رو به دفترم بیارم."

    # say L1754 dir
    old "So come to my office as soon as you're done working on whatever it is you're working on that computer."
    new "پس بیایید به دفتر من بیایید هر کی کار خودتون رو روی اون کامپیوتر تمام کردین."

    # say L1761 mia
    old "W-what? Why does she want to see us there?"
    new "و-وای، چرا می‌خواد ما رو ببینه؟"

    # say L1763 mia
    old "Oh no, she found out we were there, or maybe Denzel sent her another thing!"
    new "اوه نه، احتمالاً فهمیده که ما آنجا بودیم، یا شاید دنزل بهش چیز دیگه‌ای فرستاده!"

    # say L1765 pla
    old "Calm down, calm down, there's no reason why she would know we were in her office."
    new "آرام شو، آرام شو، هیچ دلیلی نداره که بدونه ما تو اداره‌اش بودیم."

    # say L1766 pla
    old "And why would Denzel send her another CD?"
    new "و چرا دنزل باید بهش دیسک دیگه‌ای بفرسته؟"

    # say L1767 mia
    old "Then what do you think she wants to talk to us about?"
    new "بعد از همه اینا، فکر می‌کنی در مورد چه چیزی می‌خواهد با ما صحبت کند؟"

    # say L1768 pla
    old "I guess we have to talk to her."
    new "باید باهاش صحبت کنیم."

    # say L1770 mia
    old "{i}*Sigh*{/i} Ok, let's go then, I guess we'll have to see."
    new "{i}*تنفر*{/i} خب، برویم، به نظر می‌رسه باید ببینیم."

    # say L1777 mia
    old "Why aren't you walking?"
    new "چرا در حال حرکت نیستی؟"

    # say L1778 pla
    old "Hmm, the thing is, I-I kinda can't right now."
    new "Hmm، مسئله اینه که من-من حالا نمی‌تونم."

    # say L1779 mia
    old "Why not?"
    new "چرا نمی‌تونی؟"

    # say L1780 pla
    old "Uhhh...I just need a few minutes... I mean after I watched your video."
    new "اوه... من فقط چند دقیقه وقت می‌خوام... منظورم اینه که بعد از اون ویدیویت که دیدم."

    # say L1784 mia
    old "You're really unbelievable, you know?! I can't believe you actually got a boner from that!"
    new "شما واقعاً غیرقابل باور هستید، می‌دونید؟! نمی‌تونم باور کنم از آن ویدیو خودتون سخت شدین!"

    # say L1785 pla
    old "Well, I'm still a man, you know? It's not like I want to go around with a boner."
    new "خب، هنوز مرد هستم، می‌دونی؟ نمی‌خوام همه جا با این مشکل باشم."

    # say L1786 mia
    old "Ugh, shut up. Just get rid of it, will you?"
    new "اوه، بس کن. فقط ازش خلاص شو، خوبه؟"

    # say L1787 pla
    old "Get rid of it? How?"
    new "بگو تو چطور باید ازش خلاص شم؟"

    # say L1788 mia
    old "How do you think genius? Jerk off!"
    new "چطور می‌تونی فکر کنی، بیا بره!"

    # say L1789 mia
    old "And do it quickly the principal is waiting for us."
    new "و سریع هم انجام بده، دیر نکن، رئیس مدرسه منتظرمونه."

    # say L1790 pla
    old "I don't think that will work, I mean, I'm very nervous, and I just don't have my mind in it."
    new "من فکر می‌کنم این کار جواب نمی‌دهد، من خیلی ناراحت هستم و ذهنم برای این کار آماده نیست."

    # say L1791 mia
    old "I just can't believe this."
    new "باورم نمی‌شه."

    # say L1792 mia
    old "Ughh... We have to do it now before he comes back..."
    new "اوه... باید الان انجام بدیم قبل از اینکه برگرده..."

    # say L1793 pla
    old "Just give me a couple of minutes..."
    new "بده بیشونه دقیقه..."

    # say L1794 mia
    old "Hmm, you know what, I'll do it then."
    new "خوب، می‌دونی چی، من انجام می‌دم."

    # say L1804 mia
    old "What do you think genius? I'm making you cum."
    new "ببین چه خلاقیتی دارم؟ من می‌تونم تو رو به عجایب برسونم."

    # say L1805 mia
    old "We can't take too much time, the principal is waiting for us."
    new "ما نمی‌تونیم زیاد وقت ببریم، رئیس‌المدرسه منتظرمون هست."

    # say L1806 mia
    old "And since you can't do it yourself, I guess I'll have to do it for you."
    new "و چون تو خودت نتونی این کار رو بکنی، به نظر می‌رسه باید من برایت انجام بدم."

    # say L1808 mia
    old "Come on [pla], it's not something we haven't done before, just focus on finishing quickly."
    new "بیا ز[pla]، این چیزیه که قبلاً هم انجام دادیم، فقط تمرکز کن تا سریع تمام شه."

    # say L1825 dir
    old "You took a while to come..."
    new "تو زمانی طول کشیدی تا بیایی..."

    # say L1826 mia
    old "Ah, yeah, sorry. We didn't mean to."
    new "آه، بله، معذرت. ما قصد نداشتیم طول بکشیم."

    # say L1827 mia
    old "It's just that the... thing we were doing took a little longer than expected."
    new "البته، فقط اون کاری که داشتیم انجام می‌دادیم یک کم طول‌تر شد."

    # say L1830 dir
    old "Ok, listen up. Mia, last week you gave me a report..."
    new "بales، بگوش. میا، هفته گذشته گزارشی به من دادی..."

    # say L1832 dir
    old "In which [pla] appeared as someone to pay attention to because he wasn't performing up to the standards of the school. Right?"
    new "در آن گزارش، [pla] به عنوان کسی توجه کرده شد چون عملکردش با استانداردهای مدرسه سازگار نبود. درسته؟"

    # say L1834 mia
    old "Y-yeah, that's right. Is there a problem with it ma'am?"
    new "بله، درست است. آیا مشکلی با اون هست خانم؟"

    # say L1835 dir
    old "Not per se, after all, there's nothing unusual about a student needing to improve his grades."
    new "خیر، خاصاً مشکلی نداره. در نهایت، هیچ چیز عجیبی در این نیست که یک دانش‌آموز نیاز به بهبود نمره‌اش داشته باشه."

    # say L1836 dir
    old "The problem is that this morning I received a letter informing me we're about to be audited by the superintendent."
    new "مشکل اینجاست که این صبح نامه‌ای دریافت کردم که ما مجبوریم بررسی شدن توسط مدیر عامل را بپذیریم."

    # say L1838 dir
    old "And it would be very good for us if we don't have a student about to be expelled due to his poor performance."
    new "و برای ما خیلی خوب خواهد بود اگر دانش‌آموزی به خاطر عملکرد ضعیفش در معرض اخراج نباشد."

    # say L1840 dir
    old "So, Mia, I normally wouldn't do this, but I need you to start helping him personally with his studies."
    new "پس، میا، معمولاً اینجوری نمی‌کردم، اما باید شخصاً به مطالعه‌اش کمک کنی."

    # say L1842 mia
    old "Sorry? Do you want me to tutor him? Personally?"
    new "می‌تونید توضیح بدین؟ می‌خواهید من شخصاً به او آموزش بدم؟"

    # say L1843 dir
    old "Exactly, think of it as extra classes for him. It must be done."
    new "دقیقاً، به عنوان کلاس‌های اضافی برایش فکر کن. باید انجام شه."

    # say L1844 dir
    old "We can't have any bad marks for the school qualification."
    new "ما نمی‌توانیم در ارزیابی مدرسه هیچ نمره ضعیفی داشته باشیم."

    # say L1845 mia
    old "I see, great."
    new "می‌بینم، عالی."

    # say L1846 dir
    old "Great?"
    new "عالی؟"

    # say L1847 mia
    old "Uh, I mean, I think it's great that we can get a good score just by doing that."
    new "می‌گم، منظورم اینه که خوبه که ما فقط با این کار می‌تونیم نمره خوبی بگیریم."

    # say L1849 mia
    old "Actually ma'am, [pla]'s notes have been getting a lot better recently."
    new "در واقع خانم، توضیحات [pla] اخیراً خیلی بهتر شده‌اند."

    # say L1851 mia
    old "I'm sure that his grades will be on par with everyone else's when the auditing starts."
    new "مطمئن هستم که نمره‌اش وقتی بررسی شروع می‌شه با نمره‌های دیگران همخوانی خواهد داشت."

    # say L1852 dir
    old "Well, that's great to hear. I trust you have this Mia."
    new "البته، خوشحالم که اینطور شنیدم. من بر تو اعتماد دارم میا."

    # say L1853 dir
    old "Now, I'm very busy, so you two can go back to class."
    new "الان، من خیلی مشغول هستم، پس شما دو تا می‌تونید برگردید به کلاس."

    # say L1854 mia
    old "Sure ma'am. Thank you."
    new "بله خانم، ممنونم."

    # say L1868 mia
    old "{i}*Sigh*{/i} Oh my god, that was very close."
    new "{i}*نفس کشیدن*{/i} خدایا، این خیلی نزدیک بود."

    # say L1869 mia
    old "I thought we were done for. I was sure she had received another copy of the video from Denzel or something."
    new "فکر کردم تمام شده‌ایم. مطمئن بودم او از دنزل یا چیزی مشابه دیگری کپی ویدیو دریافت کرده."

    # say L1870 pla
    old "Yeah, me too, I'm glad we managed to avoid the trouble."
    new "بله، من هم همین جوری فکر می‌کردم، خوشحالم که تونستیم از مشکل بیرون بیایم."

    # say L1871 mia
    old "Well, that was just the start of it, we still have to deal with Denzel."
    new "خب، این فقط شروع بود، هنوز باید با دنزل برخورد کنیم."

    # say L1872 mia
    old "Which by the way, you still haven't told me anything about how you plan on doing that."
    new "البته، هنوز هم به من نگفتی که قصد داری چطور با دنزل برخورد کنی."

    # say L1873 pla
    old "It's ok, it should be ready by now, I think I just have to go handle that."
    new "خوبه، باید آماده باشه، فکر کنم فقط برم و اونو حل کنم."

    # say L1874 mia
    old "Ready? What do you mean by that?"
    new "آماده؟ منظورت از این چیه؟"

    # say L1875 pla
    old "Don't think too much about it."
    new "فکر زیادی نکن."

    # say L1876 pla
    old "You just have to know that by this afternoon not only will we have dealt with Denzel."
    new "باید بدونی که تا این‌روز بامید؛ ما نه تنها با دنزل برخورد خواهیم کرد."

    # say L1877 pla
    old "There's going to be no way of him or anyone else using anything from your past to try and hurt you."
    new "نگران نباش، هیچ کس نخواهد توانست از گذشته‌ات برای آسیب دادن به تو استفاده کند."

    # say L1878 mia
    old "You make it sound so easy."
    new "اینقدر آسان به نظر نمی‌رسه."

    # say L1879 mia
    old "But you seem to be very confident about this. So, I'll trust you."
    new "ولی شما اینقدر اعتماد دارید. پس به شما اعتماد می‌کنم."

    # say L1881 mia
    old "But wait, will you look for me to tell me if whatever it is you plan on doing works?"
    new "ولی بی‌چین، آیا می‌خوای بیایی بگی به من که هر چی قصد داری انجام بدی، کار کرده؟"

    # say L1883 pla
    old "Sure, you just focus on getting rid of that CD with your video on it."
    new "بله، تو فقط تمرکز کن روی اینکه آن سی‌دی رو که ویدیویت رویش هست برداری."

    # say L1884 pla
    old "And I'll handle the rest."
    new "و من بقیه‌اش رو می‌برم."

    # say L1885 mia
    old "Ok, whatever you say."
    new "باشه، هر چه می‌گی."

    # say L1886 pla
    old "Thank you, I have to go, I'll see you later."
    new "ممنون، باید برسم، بعداً می‌بینیم."

    # say L1906 pla
    old "Hey! Hey! Linett! Are you ready?"
    new "هی! هی! لینت! آماده‌ای؟"

    # say L1907 pla
    old "I need to know if the spell's ready to be used!"
    new "من باید بدونم اسپل آماده‌هست تا استفاده کنم!"

    # say L1908 lin
    old "Hi [pla]! Yeah, you're right on time, I just finished it."
    new "سلام ز[pla]! بله، تو دقیقاً در زمان درست اومدی، همین حالا تمام شد."

    # say L1909 lin
    old "The spell's ready, so we can now use the SexNote to conjure it."
    new "حک�م آماده‌ست، پس حالا می‌تونیم از SexNote استفاده کنیم تا آن رو فراخوانی کنیم."

    # say L1911 pla
    old "That's great, so what do we do?"
    new "عالی، پس الان چه کاری باید بکنیم؟"

    # say L1913 lin
    old "The hard work was already done by me, by focusing the magic power on the person you told me about."
    new "کار سخت قبلاً توسط من انجام شده، با تمرکز قدرت جادویی روی آن شخصی که به من گفتی."

    # say L1914 lin
    old "And limiting the reach of the spell."
    new "و محدود کردن دامنه تأثیر تکلیف."

    # say L1915 lin
    old "All you have to do is read it from the SexNote, and it will be cast."
    new "تو فقط باید از SexNote بخونی، و آنقدر."

    # say L1916 pla
    old "Ok, that's very simple, can we do it now?"
    new "باشه، این خیلی ساده است، می‌تونیم الان انجام بدیم؟"

    # say L1917 lin
    old "Sure, it should have already appeared in the SexNote, so you just have to read it, and that's it."
    new "بله، قطعاً در SexNote ظاهر شده است، پس فقط باید آن را بخوانی و این کار تمام است."

    # say L1920 pla
    old "You're right! Is there!"
    new "درستی! هست!"

    # say L1921 pla
    old "So, all I have to do is read it?"
    new "پس من فقط باید اون رو بخونم؟"

    # say L1922 lin
    old "That's it."
    new "همینه."

    # say L1923 pla
    old "Ok, here it goes."
    new "باشه، حالا شروع می‌کنم."

    # say L1926 pla
    old "Elementum recolligo Huic Commodo locus mihi vestri vox."
    new "الان، اینجا می‌تونم صدایت رو بشنوم."

    # say L1927 pla
    old "Venire ventus venire, sinere solus sentire relaxari."
    new "بیا باد بیا، بگذار تنها حس آرامش رو بکنی."

    # say L1930 lin
    old "I-I think it's starting to take effect!"
    new "فکر می‌کنم شروع کرده تاثیر بگذارد!"

    # say L1931 pla
    old "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"
    new "دیگه یه نظریه به من برسون، من می‌گم این خیالات از دوران واسطه هستند!"

    # say L1932 pla
    old "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"
    new "من ذهنم رو آزاد می‌کنم، من می‌گم این خیالات رو بشنو، ذهنم که می‌ریزه میا!"

    # say L1955 pla
    old "What's happening?!!"
    new "اونجا چه قصه‌ای داره؟!!"

    # say L1961 pla
    old "Where am I?! What's this place?!"
    new "من کجا هستم؟! اینجا چیه؟!"

    # say L1962 pla
    old "What the hell?! What's this?"
    new "چه هرگیز! این چیه؟"

    # say L1963 pla
    old "Where are we Linett?"
    new "لینت، ما کجا هستیم؟"

    # say L1964 lin
    old "Hmmm, it seems something went awry with the spell..."
    new "Hmm، به نظر می‌رسه جادو اشتباه کار کرده..."

    # say L1965 pla
    old "What?! Can we fix it? What happened and where are we?!"
    new "چه؟! می‌تونیم اینو اصلاح کنیم؟ چه اتفاقی افتاده و ما کجاییم؟!"

    # say L1966 lin
    old "I don't know, I think we'll just have to wait."
    new "نمی‌دونم، به نظر می‌رسه باید منتظر بیشتر شیم."

    # say L1967 pla
    old "W- what?..."
    new "و- وای!..."

    # say L1972 lin
    old "Oh wow, you look like another person now!"
    new "اوه وای، الان مثل شخصیت دیگه‌ای به نظر می‌رسی!"

    # say L1977 pla2
    old "The fuck is happening Linett?!"
    new "لینت، این چه خرابیه؟!"

    # say L1978 lin
    old "Well, I told you, something went awry, apparently the energy is fluctuating..."
    new "خب، به تو گفتم، چیزی اشتباه شده، به نظر می‌رسه انرژی در حال نوسانه..."

    # say L1980 pla2
    old "I don't know what that means!"
    new "من نمی‌دونم این یعنی چی!"

    # say L1986 pla
    old "Wait, we're back to normal."
    new "بیا، دوباره به نرمال برگشته‌ایم."

    # say L1987 pla
    old "What was that all about Linett? Was there something wrong with the spell?"
    new "این همه چی بود لینت؟ آیا مشکلی با جادو بود؟"

    # say L1989 lin
    old "It could be, but I don't think so. I think it has more to do with all of the power that it takes to call the spell."
    new "می‌تونه همین باشه، ولی فکر کنم اینجوری نیست. فکر کنم بیشتر به خاطر تمام انرژی‌ایه که برای فراخوانی جادو لازم است."

    # say L1990 lin
    old "All of that energy must've caused a tear in our reality that connected us to another one."
    new "همه آن انرژی شاید اینجاست که در واقعیت ما یک شکاف ایجاد کرده و ما را به واقعیت دیگری متصل کرده."

    # say L1991 lin
    old "The energy probably began to flow into the tear, and that made things begin switching places between the two realities."
    new "انرژی احتمالاً شروع کرد به جریان وارد شدن به آن شکاف و این باعث شد چیزهایی شروع کنند به جابجایی بین دو واقعیت."

    # say L1993 pla
    old "Uh, sure..."
    new "آره، مطمئنم..."

    # say L1994 pla
    old "But what does that mean? Is everything alright?"
    new "ولی این یعنی چی؟ همه چیز خوبه؟"

    # say L1996 lin
    old "There shouldn't be any problem, things must've stabilized after you finished the spell."
    new "باید هیچ مشکلی نباشه، حتماً بعد از اینکه جادو رو تمام کردی، همه چیز سالم شده."

    # say L1997 lin
    old "The person you wanted to be forgotten is no longer in the mind of the bad human."
    new "شخصی که می‌خواستی فراموش شه، دیگه در ذهن آدم بد وجود نداره."

    # say L1998 lin
    old "Also, every single trace of her presence has been removed."
    new "همچنین، هر اثری از حضور او کاملاً حذف شده است."

    # say L1999 pla
    old "Does that mean no more videos or pictures of anything?"
    new "این بدان معناست که هیچ ویدیو یا عکسی از هیچ چیز وجود نداره؟"

    # say L2001 lin
    old "Everything has been removed [pla]."
    new "همه چیز حذف شده [pla]."

    # say L2003 pla
    old "Great! That's awesome, thanks Linett!"
    new "عالی! خوشحالم، ممنون Linett!"

    # say L2004 lin
    old "I'm happy to help you [pla], after all, you've done a lot for me and the other shinigamis."
    new "خوشحالم که به تو کمک کردم [pla]، در نهایت تو خیلی برای من و سایر شینیگامی‌ها کار کردی."

    # say L2005 pla
    old "I'll go and talk to Mia right now!"
    new "من الان می‌روم و با میا صحبت می‌کنم!"

    # say L2018 pla
    old "Mia! Hey! It's done!"
    new "میا! هی! تمام شد!"

    # say L2020 mia
    old "What are you talking about? What's done?"
    new "درباره چی حرف می‌زنی؟ چه کاری تمام شده؟"

    # say L2021 pla
    old "You just have to know that I already took care of your problem with Denzel."
    new "باید بدونی من قبلاً مشکلت رو با دنزل حل کردم."

    # say L2022 pla
    old "He won't bother you any longer, there are no more videos or pictures or anything!"
    new "او دیگر تو رو آزار نخواهد داد، هیچ ویدیو یا عکسی هم نیست!"

    # say L2023 mia
    old "Uh- I mean, I think that's good, but what about him? He can just go to the press and talk about me."
    new "اوه، منظورم اینه که خوبه، ولی در مورد او چطور؟ می‌تونه به رسانه‌ها برگرده و در مورد من صحبت کنه."

    # say L2024 pla
    old "Don't worry about that either, he won't even remember you, trust me."
    new "نگران اون هم نباش، حتی به تو یاد نخواهد داشت، بیشتر بگو به من."

    # say L2025 mia
    old "What do you mean he won't even remember me?"
    new "منظورت اینه که او حتی به من یاد نخواهد داشت؟"

    # say L2026 pla
    old "You know what? Let's check it, why don't you call him?"
    new "می‌دونی چی؟ بیا بزن تلفن بهش، ببین چطور می‌شه."

    # say L2027 mia
    old "Now I really think you have gone insane. Call him?"
    new "الان واقعاً فکر می‌کنم دیوانه شده‌ای. ازش تماس بگیرم؟"

    # say L2028 pla
    old "Just trust me, everything will be fine."
    new "بسیار می‌تونی به من اعتماد کنی، همه چی خوب می‌شه."

    # say L2030 mia
    old "I guess we can try."
    new "باید امتحان کنیم."

    # say L2034 pla
    old "Yeah, don't worry."
    new "بله، نگران نباش."

    # say L2038 den
    old "Hello, who is this? I don't recognize the number."
    new "سلام، این کی است؟ شماره را نمی‌شناسم."

    # say L2039 mia
    old "Wh-?!"
    new "وای؟!"

    # say L2040 mia
    old "Denzel? It's me, Mia... Uhh... from the school...."
    new "دنزل؟ من میا هستم... اوه... از مدرسه...."

    # say L2041 den
    old "Listen, I don't know who you are, if you think you can scam me you better think twice!"
    new "بله، من نمی‌دونم تو کی هستی، اگه فکر می‌کنی می‌تونی منو به دروغ ببری، بهتره دو بار فکر کنی!"

    # say L2042 mia
    old "What? No! I mean..."
    new "چه؟ نه! من می‌گم..."

    # say L2044 mia
    old "Hello? Helloo?..."
    new "سلام؟ سلام؟..."

    # say L2045 mia
    old "He hung up, he said he didn't know who I was..."
    new "او قطع کرد، گفت نمی‌دونه من کی هستم..."

    # say L2047 pla
    old "See?"
    new "ببین؟"

    # say L2048 mia
    old "What did you do?"
    new "تو چه کردی؟"

    # say L2049 pla
    old "I'm sorry but I can't tell you that, all that matters is that with that your problem should be taken care of."
    new "ببخشید اما نمی‌تونم بهت بگم، مهم اینه که با این کار مشکلت باید حل شده باشه."

    # say L2051 mia
    old "I mean, I guess it is, but this is very odd."
    new "من قصه‌ای نمی‌فهمم، اما بله، به نظر می‌رسد که مشکل حل شده."

    # say L2053 pla
    old "Listen, all you have to do is trust me, ok?"
    new "بگوش، فقط باید به من اعتماد کنی، خوبه؟"

    # say L2054 pla
    old "If you think it'll make you feel any safer, why don't we both go tomorrow to the principal's office again?"
    new "اگر فکر می‌کنی این بهت آرامش بیشتری بده، چرا هر دوی ما فردا دوباره به دفتر رئیس مدرسه برویم؟"

    # say L2055 pla
    old "That way we can check if everything will be in order."
    new "اینطور می‌شه تا اطمینان حاصل کنیم همه چی به درستی انجام شده."

    # say L2058 mia
    old "Ok, let's do as you say."
    new "باشه، همین کار رو بکنیم."

    # say L2059 pla
    old "Great, then I'll see you tomorrow."
    new "عالی، پس فردا می‌بینیم."

    # say L2068 mia
    old "I don't know what you did, but thank you."
    new "نمی‌دونم چه کاری کردی، ولی ممنون."

    # say L2094 pla
    old "Oh, Belle, hi!"
    new "اوه، بله، سلام!"

    # say L2095 pla
    old "What are you doing here so early?"
    new "چه کاری اینجا هستی زودتر از وقت؟"

    # say L2097 bel
    old "Hi [pla] good morning."
    new "سلام ز[pla] خوش صبح."

    # say L2098 bel
    old "I just came because Miss Lucy asked me, I'm helping her with a group project."
    new "من فقط برای این جا آمدم که میس لوسی از من خواستم، من بهش در پروژه‌ای گروهی کمک می‌کنم."

    # say L2099 pla
    old "Miss Lucy? Who's that? Like a new teacher?"
    new "میس لوسی؟ این کیه؟ مثل یه معلم جدید؟"

    # say L2100 bel
    old "What? Are you messing with me? Of course, you know Ms Lucy, our teacher."
    new "چه؟ می‌خواهی با من بازی کنی؟ حتماً می‌شناسی خانم لوسی، معلممون."

    # say L2101 pla
    old "Who?!"
    new "چه کی؟!"

    # say L2103 bel
    old "I mean, I know you two don't like each other [pla] but this is a little childish for you."
    new "من قصد دارم بگم که میدونم شما دو تاشون به هم خوشحال نیستن [pla] اما این برای تو کمی کودکانه است."

    # say L2104 pla
    old "What? I really don't know who she is!"
    new "چه کاری؟ واقعاً نمی‌دونم کی هست."

    # say L2105 pla
    old "I have no idea what you're talking about."
    new "من هیچ ایده‌ای ندارم که در مورد چی صحبت می‌کنی."

    # say L2115 luc
    old "Hi Belle, how are you today sweetheart?"
    new "سلام بعل، امروز چطوری عزیزم؟"

    # say L2117 luc
    old "Hmph, what are you doing here so early [pla]? I hope you're not planning anything stupid."
    new "همف، تو اینجا چی کار داری از زودی [pla]؟ امیدوارم برنامه خوبی نداشته باشی."

    # say L2118 luc
    old "I also hope you won't corrupt Belle, your are bad influence!"
    new "امیدوارم تو Belle رو فاسد نکنی، تو تأثیر منفی داری!"

    # say L2120 luc
    old "And you Belle, you need better friends."
    new "و تو بله، نیازت به دوستان بهتری هست."

    # say L2122 pla
    old "... (What the fuck?)"
    new "چه فکری؟"

    # say L2123 luc
    old "Well, see you later in class. Belle, come with me."
    new "خب، ببینم بعداً در کلاس. بله، با من بیا."

    # say L2124 bel
    old "Sorry [pla], see you later!"
    new "ببخشید [pla]، بعداً می‌بینیم!"

    # say L2133 pla
    old "What te fuck? What is happening?"
    new "چه خبره؟ چه جوری؟"

    # say L2140 mia
    old "[pla]! What the hell did you do?!"
    new "[pla]! تو چه کاری انجام دادی؟!"

    # say L2142 pla
    old "I mean, as I said, I thought I had fixed the issue. Did Denzel contact you again?"
    new "من همینجوری، همانطور که گفتم، فکر می‌کردم مشکل رو حل کرده‌ام. دنزل با تو دوباره تماس گرفت؟"

    # say L2143 mia
    old "No! Not that."
    new "نه! نه آن."

    # say L2144 mia
    old "Nobody remembers who I am!"
    new "هیچ‌کس به یاد نداره من کی هستم!"

    # say L2147 mia
    old "That's right! When I woke up I wasn't in any of the pictures on my wall!"
    new "درست است! وقتی بیدار شدم، در هیچ عکسی روی دیوار نبودم!"

    # say L2148 mia
    old "Even the doorman here didn't want to let me in! He asked if I was someone's parent!"
    new "حتی داربند هم نمی‌خواست مرا داخل کند! پرسید ایا من والد کسی هستم!"

    # say L2149 mia
    old "There's even another teacher giving my class! I already looked at the lists, I don't appear in any of them!"
    new "حتی معلم دیگری هم درس من رو می‌ده! قطعاً لیست‌ها رو بررسی کردم، اسم من توی هیچی نیست!"

    # say L2150 mia
    old "It's like if I didn't ever exist, What did you do [pla]? And how did you do it?!"
    new "به نظر می‌رسه من هیچ وقت وجود نداشتم، تو چه کاری کردی [pla]؟ و چطور این کار رو انجام دادی؟"

    # say L2152 pla
    old "What? But that's... that's..."
    new "چه؟ اما اون... اون..."

    # say L2153 mia
    old "You know what? Denzel didn't ruin my life, but you did!"
    new "می‌دونی چی؟ دنزل زندگی من رو نباخت، اما تو خراب کردی!"

    # say L2154 mia
    old "I don't know how you did it, but you blew it! I shouldn't have trusted you!"
    new "نمی‌دونم چطور اینجوری شد، ولی تو همه چی رو خراب کردی! نباید بهت اعتماد کردم!"

    # say L2160 pla
    old "What the- "
    new "می‌دونی چی؟ دنزل زندگی من رو نباخت، اما تو بردی!"

    # say L2168 mik
    old "Whoah [pla], Who's that babe?"
    new "وای ز[pla]، اون دختر چقدر خوبه!"

    # say L2169 mik
    old "She's super hot!"
    new "او خیلی گرم است!"

    # say L2170 mik
    old "Although she's a little too old for you."
    new "البته که برای تو کمی پیرتره."

    # say L2171 mik
    old "You dog, did you get a sugar mommy somewhere?"
    new "دستت در گردن، مامان شکری پیدا کردی؟"

    # say L2173 pla
    old "Don't you know who she is? That's Ms. Mia, our history teacher!"
    new "می‌دونی کی هست؟ اون خانم میا، معلم تاریخمونه!"

    # say L2174 mik
    old "Well, I had never seen her before."
    new "البته، هیچ وقت اون رو ندیده بودم."

    # say L2175 mik
    old "But if that babe's gonna be our teacher I wouldn't mind paying a little more attention in class."
    new "ولی اگه اون لولو معلممون بشه، من هیچ اشکالی ندارم که کمی بیشتر توجه کنم."

    # say L2176 mik
    old "She's looks super hot, like a pornstar!"
    new "او خیلی جذابه، مثل یه ستاره پورنو!"

    # say L2184 pla
    old "Linett, what the hell happened?! The spell went wrong!"
    new "لینت، این جوری چه اتفاقی افتاد؟！-spell-ی خراب شد!"

    # say L2185 lin
    old "What? Did that guy appear again?"
    new "چه؟ آن مرد دوباره پدیدار شد؟"

    # say L2186 pla
    old "No! That's not it! He doesn't remember her!"
    new "نه! این جور نیست! او به یادش نمی‌آید!"

    # say L2187 lin
    old "Oh."
    new "اوه."

    # say L2188 lin
    old "Then what's the problem?"
    new "بعدش چیه؟"

    # say L2189 pla
    old "That no one does! Not a single person knows who she is!"
    new "هیچ کس نمی‌دونه! حتی یه نفر هم نمی‌دونه که اون جان کیه!"

    # say L2190 lin
    old "Well... yeah."
    new "خب... بله."

    # say L2192 pla
    old "What? What do you mean..."
    new "چه؟ منظورت چیه..."

    # say L2193 lin
    old "I told you, didn't I? 'Every trace of her presence will be gone.' All of it [pla]."
    new "من به تو گفتم، نه؟ «هر اثری از حضورش خواهد رفت.» همه چیز [pla]."

    # say L2196 pla
    old "Wait, this can't happen, we need to revert this, how do we do it?"
    new "بیا، این نمی‌تونه بیفته، باید اینو برگردونیم، چطور می‌تونیم اینو انجام بدیم؟"

    # say L2197 lin
    old "I don't know, I don't even think it's possible."
    new "نمی‌دونم، حتی فکر نمی‌کنم امکان‌پذیر باشه."

    # say L2198 pla
    old "Holly shit..."
    new "هالی شیت..."

    # say L2214 pla
    old "Eh... What's happening?"
    new "اوه... اینجا چه اتفاقی افتاده؟"

    # say L2221 pla
    old "Where am I? Who are you?"
    new "من کجا هستم؟ تو کی هستی؟"

    # say L2222 pla2
    old "What the fuck? Who are you? And what are you doing in my bedroom?"
    new "چه خبره؟ تو کی هستی؟ و تو در اتاق خواب من چه کار می‌کنی؟"

    # say L2228 lin
    old "[pla], listen things are alot worse than I thought."
    new "[pla]، بگویی اوضاع خیلی بدتر از آنچه فکر می‌کردم هست."

    # say L2229 pla2
    old "Who the hell are you?!"
    new "تو کی هستی؟!"

    # say L2230 pla2
    old "And why are you naked?"
    new "و چرا خالی‌پوشی؟"

    # say L2231 lin
    old "Nevermind that... Listen [pla] the tear between realities that we oppenned with our spell was a lot bigger than I thought it would be."
    new "فکر کنم این مهم نیست... گوش ده [pla] شکاف بین دو جهان که با تکنیک ما باز شده خیلی بزرگ‌تر از آن چیزی است که فکر می‌کردم باشد."

    # say L2232 pla
    old "What? So? What does that mean?"
    new "چه کاری؟ چه خبر؟ این یعنی چی؟"

    # say L2233 lin
    old "It means that both realities are about to collapse on each other!"
    new "این بدان معناست که هر دو واقعیت در حال سقوط بر روی هم هستند!"

    # say L2235 pla
    old "Collapse? You mean like everything will be destroyed?"
    new "انهدام؟ می‌خوای بگی همه چیز تخریب می‌شه؟"

    # say L2237 lin
    old "No, fortunately I was able to find the disturbance early, I think I can fix it."
    new "نه، خوشحالم که تونستم این اختلال رو زودتر پیدا کنم، فکر کنم می‌تونم اصلاحش کنم."

    # say L2238 lin
    old "And I'll do that right now."
    new "و الان همین کار رو انجام می‌دم."

    # say L2239 lin
    old "I'm just not sure if I'll make it on time, but I have to try..."
    new "مطمئن نیستم در زمان خواهم رسید، اما باید بپردازم..."

    # say L2240 pla2
    old "Wow, this is a very trippy dream."
    new "واو، این رویا خیلی عجیب است."

    # say L2249 pla
    old "Where I am? What is this???"
    new "من کجاهم؟ این چیه؟؟؟"

    # say L2253 pla
    old "Is he the guy I saw a few moments ago?"
    new "آیا اون مردی که چند لحظه پیش دیدم هست؟"

    # say L2257 pla
    old "Is this a Dream or I'm going crazy?"
    new "این رویا هست یا من دیوانه شدم؟"

    # say L2261 pla
    old "Oh God, this is making me dizzy..."
    new "اوه خدا، این به من گیج کننده می‌کنه..."

    # say L2278 pla
    old "What the fuck was that? Was it all a dream?"
    new "این چی بود؟ همه اینا رویا بود؟"

    # say L2292 mia
    old "All right class, it's time to start."
    new "بفرما کلاس، الان وقت شروع است."

    # say L2293 mia
    old "Today we'll start a new subject, so, take out your textbooks and open them in the next chapter."
    new "امروز درس جدیدی را شروع می‌کنیم، پس کتاب‌هایتان را بیرون بیاورید و به فصل بعدی باز کنید."

    # say L2294 mia
    old "This will also be at the end of term test, so be sure to take good notes."
    new "این موضوع هم در امتحان پای ترم خواهد بود، پس حتماً یادداشت‌های خوب بگیرید."

    # say L2295 mia
    old "Belle?"
    new "بلل؟"

    # say L2298 mia
    old "Please read the first page of the chapter."
    new "لطفاً صفحه اول فصل را بخوانید."


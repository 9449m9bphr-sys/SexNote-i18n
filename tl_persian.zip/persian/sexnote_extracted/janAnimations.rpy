# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/janAnimations.rpy
translate persian strings:

    # say L37 pla
    old "(Oh shit, I'm dead.)"
    new "اوه شیطون، من مردهام."

    # say L47 pla
    old "Wow! Are they... Having sex?"
    new "وای! آیا آنها... در حال جفت‌گیری هستند؟"

    # say L95 pla
    old "I should leave... I don't want to get caught peeping."
    new "باید برسم... نمی‌خوام بگیرن با نگاه زدن."

    # say L144 pla
    old "(Damn, she's so tight! Oh shit! I feel like... I am going to...)"
    new "لعنتی، تو خیلی تنگی! اوه شیطان! می‌تونم بگم... من در حال اوج‌رسانی هستم."

    # say L148 mo2
    old "Fuck, baby. This new strap-on has a good lubrication system. It feels like a real cumshot... And it's so warm."
    new "فکر کنم، عزیزم. این استروپ-ان جدید سیستم لیبریشن خوبی داره. مثل یک جریان واقعی هست... و همچنین خیلی گرم."

    # say L149 mo2
    old "Mmm. Let me rest a little..."
    new "ممنون. بیای بیشتر استراحت کنم..."

    # say L150 pla
    old "(Alright. I should get out of here.)"
    new "باشه. باید از اینجا برم."

    # say L165 pla
    old "(She's so tight! Oh shit, I feel like... I am going to...)"
    new "(او همچین محکمیه! اوه شیطون، حس می‌کنم... من قراره...)"

    # say L169 mo2
    old "Mmm, still so good... Let me rest up, baby..."
    new "ممنون، هنوز هم خوبه... بیا بیشتر استراحت کن، عزیزم..."

    # say L170 pla
    old "(Ok, I should get out...)"
    new "باشه، باید برم..."

    # say L188 mo2
    old "So nice to see like a little rat on the floor..."
    new "خوشحالم که مثل یه موش کوچیک روی زمین می‌بینم..."

    # say L190 mo2
    old "Are getting horny again?"
    new "دوباره هورنی می‌شی؟"

    # say L191 mo2
    old "You're so gross... Getting horny just by sucking my foot."
    new "تو خیلی خردلعله‌یی... فقط با شیر کردن پایم هورنی می‌شی."

    # say L195 mo2
    old "Yeah! This is what you like..."
    new "بله! این همینه که دوست داری..."

    # say L197 mo2
    old "I see you want more and more... You are a disgusting needy bastard."
    new "می‌بینم خواسته‌هایت هر بار بیشتر می‌شه... تو یه بچه نیازمند و خیلی خردلعله‌ای هستی."

    # say L202 mo2
    old "That's what you deserve for being a fucking pervert!"
    new "این همینه که برای اینکه یک خودسرتی هستی دریافت می‌کنی!"

    # say L204 mo2
    old "I'm going to make you suck my foot! Every day you little rat!"
    new "من قراره هر روز پاشونتو به تو بدهم! تو خر کوچولو!"

    # say L228 mo2
    old "That's it. Enough!"
    new "خوب، کافیه."

    # say L230 mo2
    old "Fuck! This is gross... Now I have my foot full of your disgusting slime."
    new "لعنتی! این خیلی خیزناکه... حالا پاشونم پر از لیزت خیزناک شده."

    # say L231 mo2
    old "I hope you've learned your lesson and don't go back to being perverted with your disgusting hardon."
    new "امیدوارم درس خودت رو یاد گرفتی و دیگه به رفتار هیجان‌زده و با آن چیز خیلی خیزناک‌ات بر نگردی."

    # say L232 mo2
    old "I need to clean myself from all this bullcrap..."
    new "من باید از همه این ترشی خودم را تمیز کنم..."

    # say L245 mo2
    old "Is this what you like, you little pervert? Do you like that your boss treats you like a cockroach?"
    new "این همچین چیزی است که دوست داری، تو خردلولو؟ آیا دوست داری که رئیس‌ت به تو مثل حشره برسونه؟"

    # say L246 mo2
    old "Does that turn you on, you fucking bastard?"
    new "این تو رو خوشحال می‌کنه، شما خوب زنده‌بازی؟"

    # say L253 mo2
    old "I ASKED YOU. ANSWER YOUR BOSS!"
    new "من سوالم رو پرسیدم. جواب بدین به رئیسم!"

    # say L254 pla
    old "Y- yes."
    new "بله."

    # say L255 mo2
    old "Ohh poor baby, he thinks I'm doing this to please him..."
    new "اوه بچه گریه کننده، فکر می‌کنه من اینجوری می‌کنم تا او راضی شه..."

    # say L259 mo2
    old "I'm doing this to torture you ..."
    new "من این کار رو برای اذیت کردن تو می‌کنم..."

    # say L260 mo2
    old "Because a pervert like you only thinks with the cock!"
    new "چون یک پرتوب مثل تو فقط با لولو فکر می‌کنی!"

    # say L261 mo2
    old "So, I won't make you cum until you get humillied, and accept you are a cockroach and I am your master."
    new "پس، من تا زمانی که مذhoresه شدی و پذیرفتی که یک مورچه‌ای هستی و من مالکت هستم، نخواهم اجازه داد که به تو رسیدن."

    # say L263 mo2
    old "I'm gonna make you my bitch [pla]."
    new "من قراره تو رو به زن خودمو تبدیل کنم [pla]."

    # say L286 mo2
    old "Ohh, are you close?"
    new "اوه، نزدیکی؟"

    # say L289 mo2
    old "Well, I'm not gonna let you cum."
    new "خب، من نمی‌خوام تو بیایی."

    # say L293 mo2
    old "If you want to cum, you have to beg for it."
    new "اگر می‌خوای بیایی، باید برایش درخواست کنی."

    # say L294 pla
    old "W- What?"
    new "و- وای، چه کاری می‌کنی؟"

    # say L295 mo2
    old "Yes! Beg for it!"
    new "بله! لطفاً برایش درخواست کن!"

    # say L296 pla
    old "P- please... L- let me cum..."
    new "لطفاً... برام بیا..."

    # say L297 mo2
    old "Do you realize how pathetic that sounds?"
    new "می‌دونی این چقدر خرده‌ای شنیده می‌شه؟"

    # say L298 mo2
    old "You are a cockroach, a disgusting and perverted cockroach ... What are you?"
    new "تو یک خرچنگ، یک خرچنگ خیلی خیلی خلاف‌آموزی هستی... تو چی هستی؟"

    # say L299 pla
    old "I- I am a... D- disgusting and p- perverted... Cockroach."
    new "من... من یک... خرچنگ و پرتلاش... خرچنگ هستم."

    # say L303 mo2
    old "And who am I?"
    new "و من کی هستم؟"

    # say L304 pla
    old "Uhh... Y- you are m- my boss..."
    new "اوه... شما م- مربی من هستید..."

    # say L305 mo2
    old "I AM YOUR MASTER!"
    new "من مالک شما هستم!"

    # say L306 pla
    old "Uhh... My master, y- you are m- my master."
    new "اوه... مالک من، شما... شما مالک من هستید."

    # say L307 mo2
    old "That sounds much better."
    new "این بهتر است."

    # say L311 mo2
    old "I guess you are finally learning."
    new "به نظر می‌رسه در نهایت یاد می‌گیری."

    # say L312 pla
    old "Ahh..."
    new "اوه..."

    # say L313 mo2
    old "Oh, are you close again?"
    new "اوه، دوباره نزدیک شدی؟"

    # say L314 mo2
    old "It would be a shame if I stop again, isn't it?"
    new "البته، اگر دوباره متوقف شوم، خیلی شرمنده‌کننده خواهد بود، نیست؟"

    # say L315 pla
    old "No, please... Don't stop... It hurts."
    new "نه، لطفاً... متوقف نشو... درد می‌کنه."

    # say L316 mo2
    old "Then beg your master!"
    new "پس لطفاً از مالک خود درخواست کن!"

    # say L317 pla
    old "Please, master... Please let me cum... I- I'm your... Slave!"
    new "لطفاً، مالک... لطفاً برام بیای... من- من خادم تو هستم!"

    # say L318 mo2
    old "Yes, you are..."
    new "بله، تو هستی..."

    # say L319 pla
    old "Ahhhh!"
    new "اااه!"

    # say L324 mo2
    old "Ughh gross..."
    new "اوه، خیزناک..."

    # say L325 mo2
    old "I guess you are learning some respect here, aren't you?"
    new "باید در اینجا یاد بگیری احترام نشون بدی، نیست؟"

    # say L327 mo2
    old "Now, clean this, it's disgusting."
    new "الان اینو تمیز کن، خیلی خیزناکه."

    # say L340 mo2
    old "Ohh yeah, just like that little bitch."
    new "اوه بله، مثل همون خرکچه کوچک."

    # say L342 mo2
    old "Keep licking it."
    new "ادامه بده، لیس کن."

    # say L346 mo2
    old "Wow, you are not completely useless after all."
    new "وای، نهایتاً کاری مفید انجام می‌دهی."

    # say L347 mo2
    old "Ahh, finally you are doing a good job."
    new "اوه، در نهایت کار خوبی انجام می‌دهی."

    # say L348 mo2
    old "I see you love licking and kissing my pussy..."
    new "می‌بینم دوست داری لیس و بوس کنی پوسی من..."

    # say L353 mo2
    old "Ahh! Wow!"
    new "آه! وای!"

    # say L354 mo2
    old "Oh yeah, keep going little bitch!"
    new "آره، ادامه بده کوچولوی من!"

    # say L356 mo2
    old "I'm your master and you gotta lick me until I tell you to stop."
    new "من مالکت هستم و باید تا زمانی که من بگم متوقف نشوی."

    # say L379 mo2
    old "Don't stop, don't stop, you fucking bastard..."
    new "توقف نکن، توقف نکن، شما خوبه بچه خربه..."

    # say L381 mo2
    old "Oh gosh! Ahhhhh! Fuck!"
    new "اوه خدا! آهههه! شیطون!"

    # say L390 mo2
    old "Ahh, that wasn't bad, you are finally good at something."
    new "اوه، این بد نبود، در نهایت تو در چیزی خوب شدی."

    # say L391 pla
    old "T- Thank-"
    new "ت- تشکر-"

    # say L392 mo2
    old "Anyway, get out, I have to work."
    new "باز هم، برو بیرون، باید کار کنم."

    # say L397 mo2
    old "Uhhh, I think you are improving."
    new "اوه، فکر کنم در حال بهبود هستی."

    # say L398 mo2
    old "Maybe I could reward you for doing a good job, maybe that way you will stop being a stupid useless at everything else."
    new "شاید بتونم بهت جایزه بدم برای اینکه کار خوبی کردی، شاید اینجوری دیگه احمق و بی‌فایده در همه چیز نباشی."

    # say L399 pla
    old "W- what do you mean?"
    new "م- منظورت چیه؟"

    # say L400 mo2
    old "I'm tough but fair, and you have pleased me these last two times."
    new "من سختگیر هستم اما عادلانه، و تو در این دو بار خوشحال کننده بودی."

    # say L401 mo2
    old "Now it's time for a reward for this little pervert. Now take out your pants."
    new "الان وقت جایزه برای این خردکرده کوچکه. حالا شلوارتو بیرون بیاور."

    # say L402 pla
    old "Y- yes master."
    new "بله، معلم."

    # say L409 mo2
    old "What are you waiting for? I'm not going to do it for you, if you want to cum you will have to do it yourself, idiot."
    new "چه منتظری؟ من برایت انجام نمی‌دهم، اگر می‌خوای خودت باید انجام بدی، بی‌حوصله."

    # say L410 pla
    old "Uhh... R- right, sorry."
    new "اوه... راستی، معذرت."

    # say L422 mo2
    old "Hahaha, you look like a poor animal begging to cum with my foot."
    new "هahaha، به نظرت می‌رسه مثل حیوانی بیچاره‌ای که می‌خواد با پاشونم خودت را برسونی."

    # say L427 mo2
    old "Oh, you're getting more excited, just like a bitch in heat."
    new "اوه، خیلی خوشحال می‌شی، مثل سگی که به فوتونم علاقه داره."

    # say L429 mo2
    old "You are disgusting."
    new "تو خیلی خسته‌کننده هستی."

    # say L433 mo2
    old "I see you're speeding up, Are you getting close?"
    new "می‌بینم سرعتت بالا رفته، نزدیک شدی؟"

    # say L434 pla
    old "Y- yes..."
    new "بله..."

    # say L435 mo2
    old "Don't you dare come on my foot, because I kill you."
    new "دیوونه نشو، روی پای من خروجی بدی، چون اگه اینجوری کنی، من تو رو می‌کشم."

    # say L459 mo2
    old "Ohh, your cock is about to explode but you cannot cum because I haven't said you can do so..."
    new "اوه، لولت می‌خواهه منفجر بشه اما نمی‌تونی جیز کنی چون من اجازه ندادم..."

    # say L460 mo2
    old "Poor boy can't cum because I won't let you do it. Unless you beg for it."
    new "بچه گریه‌کن، نمی‌تونی خروجی بدی چون من اجازه ندادم. مگر اینکه برای این کار تو خواهی خواست."

    # say L461 pla
    old "... P- please master... L- let me cum."
    new "... لطفاً ماستر... ب- بگذار من جیز کنم."

    # say L462 mo2
    old "Hmm, I'm not sure... you should give it a better try."
    new "Hmm، نمی‌دونم... باید تلاشت رو بهتر کنی."

    # say L463 pla
    old "I- I- I am your bitch... Just a cockroach, and you are my master, p- please let this cockroach c- cum..."
    new "من- من- من خانم شما هستم... فقط یک مورچه، و شما مالک من هستید، لطفاً این مورچه رو بیاید..."

    # say L464 mo2
    old "Hmm, why do I have to be so merciful? Alright, stop moving, I'm gonna help you out."
    new "Hmm، چرا باید اینقدر مهربان باشم؟ خب، جنب نکن، من قرار هستم بهت کمک کنم."

    # say L474 mo2
    old "One more time you see who is the Master..."
    new "بیش از این ببینی که کی ماستر هست..."

    # say L475 pla
    old "Y- Yes-"
    new "بله-"

    # say L476 mo2
    old "You're shit... Don't talk if I don't tell you so..."
    new "شما خاکستر هستید... اگر من نگم، حرف نزن..."

    # say L477 pla
    old "S- sorr-"
    new "ب- ببخشید"

    # say L478 mo2
    old "Shut up!"
    new "بی‌صدا شو!"

    # say L482 mo2
    old "Yeahh! I like when you don't talk and only listen to your master."
    new "بلهه! من دوست دارم وقتی حرف نمی‌زنی و فقط به سرپرستت گوش می‌دهی."

    # say L484 mo2
    old "Fucking pervert!"
    new "مادر جن: فکر کنم تو خودت یک پرتلاشی هستی!"

    # say L486 mo2
    old "Shut up and follow my words... You won't talk if your master wants silence..."
    new "بست و به سخن‌های من اطاعت کن... اگر سرپرستت صمت رو می‌خواد، تو حرف نمی‌زنی..."

    # say L490 mo2
    old "Oh look at you so vulnerable and needy."
    new "اوه، نگاهت به تو چقدر آرام‌ناپذیر و نیازمند است."

    # say L491 mo2
    old "Are you getting close? Because you look awful."
    new "آره، نزدیک شدی؟ چون حالت وحشتناکه."

    # say L492 pla
    old "Y- yes, master."
    new "بله، ماستر."

    # say L493 mo2
    old "Alright, don't cum until I tell you."
    new "خوب، تا زمانی که من اجازه ندهم، نباید خودت را آرام دهی."

    # say L494 pla
    old "Uhh, Y- yes, m- master."
    new "اوه، بله، ماستر."

    # say L517 mo2
    old "Ask for permission if you want to cum."
    new "اگر می‌خوای جیز کنی، از من اجازه بخواه."

    # say L519 mo2
    old "Yes! Ask your Master for permission."
    new "بله! از ماستر خودت اجازه بخواه."

    # say L520 pla
    old "I need to cum... N- now, please."
    new "من باید جلو ببرم... الان، لطفاً."

    # say L521 pla
    old "M- Maste-"
    new "م- ماستر..."

    # say L522 mo2
    old "You'll come whenever I want, not when you need to..."
    new "تو هر وقت که من بخوام می‌آیی، نه وقتی تو نیاز داری..."

    # say L523 mo2
    old "Say that you're my little bitch... Say it and I'll make you cum, maybe... Who knows if I'll change my mind."
    new "بگو که تو خرچنگم هستی... بگو و شاید تو رو بیاورم، می‌دونی؟ شاید خودمو تغییر بدم."

    # say L525 pla
    old "I- I'm your L- little B- bitch."
    new "من- من خرچنگ کوچیکت."

    # say L526 pla
    old "Let me cum, please..."
    new "بیا برام خودت را آرام بده، لطفاً..."

    # say L532 mo2
    old "Uhh... Gross."
    new "اوه... خیلی خشن است."

    # say L544 mo2
    old "At least you're getting better on this."
    new "البته شما در این زمینه بهتر شده‌اید."

    # say L545 mo2
    old "Oh yeah, keep licking it."
    new "بله، ادامه بده."

    # say L547 mo2
    old "Uhh this position is pretty good!"
    new "اوه این وضعیت واقعاً خوبه!"

    # say L551 mo2
    old "Do you like it? Having your master pussy on your face?"
    new "می‌پسندی؟ وقتی مادربزرگت روی صورتت باشه؟"

    # say L553 mo2
    old "Good boy, keep doing it, and I might reward you."
    new "خوب، ادامه بده، ممکن است تو رو جایزه بدم."

    # say L557 mo2
    old "Ahh! Yess!"
    new "آه! بله!"

    # say L558 mo2
    old "Oh yeah, keep going, keep going!"
    new "اوه بله، ادامه بده، ادامه بده!"

    # say L584 mo2
    old "You're my bitch... Keep doing it."
    new "تو خر دیوگه... ادامه بده."

    # say L586 mo2
    old "Oh gosh! Ahhhh! Fuck!"
    new "اوه خدا! آه! فکر کنم می‌میرم!"

    # say L593 mo2
    old "You're a bad employee but since you've done well today, I'm gonna give you something."
    new "تو یک کارمند بدی هستی اما چون امروز خوب کار کردی، من چیزی به تو میدم."

    # say L598 mo2
    old "However, you will keep licking and you will make me cum again."
    new "ولی شما باید ادامه بدهید و من رو دوباره برسانید."

    # say L611 mo2
    old "Wow, you are definitely enjoying your master's pussy, right?"
    new "واو، قطعاً از کس مامانت لذت می‌بری، همینطور؟"

    # say L612 pla
    old "Uhh I-"
    new "اوه من-"

    # say L613 mo2
    old "Don't ever stop licking, or I'll rip your cock off!"
    new "هرگز متوقف نشو، در غیر این صورت خروجیتو بریدم!"

    # say L618 mo2
    old "Look how much you enjoy it... Uhh? your little bastard."
    new "ببین چقدر لذت می‌بری... اوه؟ پسرک خردمند."

    # say L619 mo2
    old "You are really a pervert, is this what you wanted? Uh?"
    new "وای، واقعاً یک پرتلاشی هستی، اینجوری می‌خواستی؟ اوه؟"

    # say L621 mo2
    old "Just keep going."
    new "ادامه بده، لطفاً."

    # say L625 mo2
    old "Oh yeah, keep going, make me cum again!"
    new "اوه بله، ادامه بده، دوباره من رو به عجولی برانگیز!"

    # say L626 mo2
    old "Don't stop, don't stop, you little bastard."
    new "توقف نکن، توقف نکن، تو خردلرو کوچیک."

    # say L650 pla
    old "Ohhhh... F- Fuckk!"
    new "اوههه... ف- فک کن!"

    # say L656 mo2
    old "Okay, I'm done here, I hope you don't screw it up again at work. Otherwise, next time it will be worse."
    new "خوب، من اینجا تمام شدم، امیدوارم دیگر در کار اشتباه نکنی. در غیر این صورت، بار بعد بدتر خواهد بود."

    # say L657 mo2
    old "Get dressed and leave, I can't waste any more time with you."
    new "پوشون و برو، نمی‌تونم وقت بیشتری رو با تو ببرم."

    # say L665 mo2
    old "Uhh that was good..."
    new "اوه، آن خوب بود..."

    # say L666 pla
    old "Alright, I'm gonna get dressed."
    new "باشه، من هم می‌خوام لباس بذارم."

    # say L667 mo2
    old "Oh gosh, I want a little more."
    new "اوه خدا، می‌خوام کمی بیشتر."

    # say L669 mo2
    old "Shut up and keep licking. I'm going to try something different."
    new "بست و ادامه بده لیس کردن. من می‌خوام چیزی متفاوت امتحان کنم."

    # say L677 pla
    old "Oh wow! What the fuck!"
    new "اوه وای! چه شیطونی!"

    # say L678 mo2
    old "Don't even think about saying or doing something, keep quiet, and don't stop licking."
    new "حتی فکر هم نکنی چیزی بگویی یا انجام بدی، ساکت باش و لیس کردن رو متوقف نکن."

    # say L687 mo2
    old "This is what you always wanted, isn't it?"
    new "این همیشه آنچه می‌خواستی بود، نیست؟"

    # say L689 mo2
    old "Getting your naughty and disgusting cock sucked."
    new "کلاهیت و خوبیت رو شیر کردن."

    # say L693 mo2
    old "Do you like it? Uh? Do you like your master sucking your cock?"
    new "می‌پسندی؟ هه؟ می‌پسندی که مامان شما رو می‌شیره؟"

    # say L695 mo2
    old "Of course you do, look how excited and horny you are."
    new "البته، ببین چقدر خشنود و خیلی خیالی شده‌ای."

    # say L699 mo2
    old "Ohh, yeah, keep going, keep licking my pussy, you little pervert."
    new "اوه، بله، ادامه بده، لب‌هام رو لیس کن، تو خودت یه کوچولو خلافکاری."

    # say L700 mo2
    old "Are you going to remain useless, good for nothing? Are you going to keep doing it so that I continue to punish you?"
    new "آیا قراره همیشه بی‌فایده و بی‌کاربرد باشی؟ آیا قراره این کار رو ادامه بدهی تا من ادامه بدم تو رو مجازات کنم؟"

    # say L701 mo2
    old "You're my bitch, [pla] never forget about it."
    new "تو خر زن منی هستی، [pla] هیچ وقت اینو فراموش نکن."

    # say L724 mo2
    old "Ohh, yeah, don't stop, don't stop!"
    new "اوه، بله، متوقف نشو، متوقف نشو!"

    # say L725 pla
    old "I- I'm cumming!"
    new "من- من می‌آیم!"

    # say L726 mo2
    old "Ahhh I- I'm cumming to!"
    new "اوه آره من- من هم می‌آیم!"

    # say L733 mo2
    old "Ughhh, gross..."
    new "اوه، خیلی خیزناکه..."

    # say L734 mo2
    old "I better go clean this up, it's disgusting... "
    new "بهتر است این رو تمیز کنم، خیلی خیزناکه..."

    # say L745 mo2
    old "I'm your boss and your Master."
    new "من رئیس و ماستر شما هستم."

    # say L746 mo2
    old "And you're shit... And you do what I say."
    new "و تو شیط... و می‌کنی هر چی من می‌گم."

    # say L747 mo2
    old "Got it?"
    new "فهمیدی؟"

    # say L749 mo2
    old "You belong to me and I do whatever I fucking want with you."
    new "تو متعلق به من هستی و من هر چی خواستم با تو انجام می‌دم."

    # say L753 mo2
    old "Yeahh! This is what you like..."
    new "بلهه! این همینه که دوست داری..."

    # say L755 mo2
    old "Fucking pervert! Fucking slave... Useless bitch."
    new "مادرت: خودت را پرترب! خودت را برده... بی‌فاید زن."

    # say L757 mo2
    old "Your cock is really hard but I won't make you cum yet... Not if you are so eagered. You don't deserve to cum now."
    new "پوسی تو خیلی سخته ولی هنوز نمی‌تونی اوج ببری... اگه همچین عجله‌ای داری. حالا نمی‌تونی اوج ببری."

    # say L761 mo2
    old "You are about to explode! isn't it? Fuck you!"
    new "تو در حال خروج هستی! نیست؟ فک کن!"

    # say L763 mo2
    old "Say who is your Master?"
    new "ماستر کیست؟ بگو!"

    # say L765 mo2
    old "Say it out loud NOW!"
    new "الان هم بگو!"

    # say L766 mo2
    old "If you wanna cum, you'll need to say it!"
    new "اگه می‌خوای خروجی بگیری، باید اون رو بگی!"

    # say L767 pla
    old "Y- You... You're my Master."
    new "تو... تو صاحب منی هستی."

    # say L768 mo2
    old "You want to cum... Poor boy can't come because I won't let him do it."
    new "تو می‌خوای جوش برسی... فقیر پسر نمی‌تونه بیاد چون من نمی‌دم."

    # say L791 mo2
    old "If you want to come, you have to beg for it again."
    new "اگه می‌خوای بیاد، باید دوباره درخواست کنی."

    # say L792 pla
    old "A- again..."
    new "ب- بار دیگه..."

    # say L793 mo2
    old "Yes! Beg for it! You have to learn little bitch."
    new "بله! درخواست کن! باید یاد بگیری، کثیف کودک."

    # say L794 pla
    old "P- please, I- I need to cum... I really need it... N- now."
    new "لطفاً، من نیاز دارم بیایم... واقعاً نیاز دارم... الان."

    # say L795 mo2
    old "You'll cum whenever I want not when you need to..."
    new "تو هر وقت که من بخوام خواهی رسید، نه وقتی که تو نیاز داری..."

    # say L796 mo2
    old "Say that you're my bitch... Say it and I'll let you cum."
    new "بگو که تو خانم من هستی... بگو و برات اجازه می‌دم بیاید."

    # say L798 pla
    old "I'm your b- bitch, master..."
    new "من خانمت، ماستر..."

    # say L805 mo2
    old "I didn't expect this to happen but I'll do it..."
    new "من این را منتظر نبودم اما انجام می‌دهم..."

    # say L806 mo2
    old "I've tried to show you who is the Master here but you still refuse to believe..."
    new "من سعی کردم به شما نشون بدم که اینجا ماستر من هستم، اما هنوز باور نمی‌کنید..."

    # say L807 mo2
    old "We cannot keep going in the same way... Now you'll know who is the master and who is the slave."
    new "ما نمی‌توانیم همین طور ادامه بدیم... حالا می‌فهمی کی ماستر و کی برده است."

    # say L809 mo2
    old "I'm your fucking Master and you're my slave, you listen and do as I say..."
    new "من ماستر شما هستم و تو برده منی، باید به من گوش بدی و هر چی می‌گم انجام بدی..."

    # say L810 mo2
    old "This is not a game! I'm gonna fuck you if I want, you do as I tell you..."
    new "این بازی نیست! من اگر بخواهم تو رو می‌کنم، تو هم هر چی می‌گم انجام بدی..."

    # say L811 pla
    old "W- what-"
    new "و- وای، چه کاری می‌کنی؟"

    # say L827 mo2
    old "Little bastard, useless and needy..."
    new "بچه خر، بیکار و نیازمند..."

    # say L829 mo2
    old "I'm your Master and I want you to say it more often."
    new "من معلمتو هستم و می‌خوام بیشتر این جملو بگی."

    # say L830 pla
    old "M- Mas-"
    new "م- ماستر-"

    # say L831 mo2
    old "I don't hear you!"
    new "من صدایت رو نمی‌شنم!"

    # say L832 mo2
    old "Say it! Who is your Master?"
    new "بگو! ماسترت کیه؟"

    # say L833 pla
    old "Y- You..."
    new "تو..."

    # say L838 mo2
    old "Seems that the slave is doing okay..."
    new "به نظر می‌رسه که بردگ خوب است..."

    # say L840 mo2
    old "Are you enjoying this? Who told you to enjoy this... You're just a fucking slave..."
    new "این رو لذت می‌بری؟ چه کسی گفته برات لذت ببری... تو فقط یه بردگی هستی..."

    # say L842 mo2
    old "You're almost nonexistent... Without me, you're nothing. Without your Master, you're nothing."
    new "تقریباً وجود نداری... بدون من هیچی نیستی. بدون ماسترتو هیچی نیستی."

    # say L843 mo2
    old "I'll make you suffer, motherfucker!"
    new "من باعث می‌شوم درد بخوری، مادرکش!"

    # say L848 mo2
    old "You are about to explode! isn't it? Fucking idiot!"
    new "شما در حال خروج از خود هستید! نیست؟ احمق زدن!"

    # say L850 mo2
    old "I'm fucking you, little bastard."
    new "من تو رو می‌بوم، بچه خرده."

    # say L851 mo2
    old "Now you are my bitch, I'm fucking my little bitch."
    new "حالا تو خر مامانی هستی، من تو رو می‌بوم، خر کوچولو."

    # menu L872 
    old "Change perspective"
    new "دیدگاه را تغییر دهید"

    # say L882 mo2
    old "Ohh yeahh, can you feel how hard I'm fucking you?"
    new "اوه آره، می‌تونی احساس کنی چقدر سخت تو رو می‌بوم؟"

    # say L883 pla
    old "Ahhh... I- I-"
    new "آه... من- من-"

    # say L884 mo2
    old "Yes, I'm cuming on you fucking bastard"
    new "بله، من روی تو آمدم، شما قلیل کسالت زده"

    # say L893 mo2
    old "All right, I already made you my bitch!"
    new "باشه، قبلاً تو رو به بیچ تبدیل کردم!"

    # say L894 mo2
    old "Never ever, try to rebel against me, I am your master."
    new "هرگز، سعی نکن بر خلاف من قیام کنی، من اصل تو هستم."

    # say L909 mo1
    old "Oh, yes [mo2]! I missed you so much..."
    new "اوه، بله [mo2]! خیلی ازت می‌چکارم..."

    # say L910 mo2
    old "Uhh... You are fucking hot babe..."
    new "اوه... تو خیلی جذابی عزیزم..."

    # say L911 mo1
    old "This feels so nice... Oh my God!"
    new "این حس خوبه... اوه خداوند!"

    # say L915 mo2
    old "Ahhh, don't stop baby, don't stop!"
    new "اوه، نتونفر بچه، نتونفر!"

    # say L916 mo1
    old "Oh yes! I have been waiting a lot for this!"
    new "اوه بله! این طولانی منتظر بودم."

    # say L917 mo1
    old "I love you [mo2], I love you so much!"
    new "منت عشقم [mo2]، خیلی خیلی دوستت دارم."

    # say L918 mo2
    old "I love you too. You are my girl."
    new "من هم دوستت دارم. تو دختر منی."

    # say L919 pla
    old "(What the fuck, she doesn't sound like the [mo2] I know...)"
    new "اوه، این صدای تو مثل [mo2] که من می‌شناسم نیست..."

    # say L923 mo2
    old "Oh yeah, just like that babe, Just like that!"
    new "اوه بله، همینطور عزیزم، همینطور!"

    # say L924 mo1
    old "Ahhh, Ahhh! I love you."
    new "اوه، اوه! من عاشق‌ام."

    # say L925 mo2
    old "Keep going, keep going!"
    new "ادامه بده، ادامه بده!"

    # say L926 mo1
    old "Oh my God, I'm so fucking horny!"
    new "اوه خدا، من واقعاً خیلی خیال‌پرداز هستم!"

    # say L950 mo2
    old "Yes, Yes, cum for me baby!"
    new "بله، بله، برای من خروجی بده!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/SisStory.rpy
translate persian strings:

    # say L9 sis
    old "Hey [pla], I heard [mo1] and [mo2] arguing about you last night."
    new "هی ز[pla]، دیشب شنیدم [mo1] و [mo2] در موردت با هم مناقشه می‌کردند."

    # say L10 sis
    old "Do you know what happened?"
    new "می‌دونی چه اتفاقی افتاد؟"

    # say L11 pla
    old "About me? Oh, fuck... "
    new "درباره من؟ اوه، شیطون..."

    # say L12 sis
    old "What? Do you know what it was about?"
    new "چه کاری؟ می‌دونی اون به چه بود؟"

    # say L13 pla
    old "No, no I don't know. I, uh... I have to go."
    new "نه، نه من نمی‌دونم. من، اوه... باید برم."

    # say L18 sis
    old "Wait, don't leave yet! I kinda need your help... "
    new "بیا، هنوز برپا نشو! من یه کمکتو لازم دارم..."

    # say L22 sis
    old "Well, you know all the nerdy shit, right?"
    new "خب، تو همه اون چیزهای نردی رو می‌دونی، درسته؟"

    # say L23 pla
    old "... What are you trying to say?"
    new "می‌خوای چی بگی؟"

    # say L24 sis
    old "What I mean is, do you know how to make a website?"
    new "من قصد این هستم که بپرسم که آیا می‌دونی چطور وب‌سایت بسازی؟"

    # say L25 pla
    old "Well, yes, I know how to do it."
    new "بله، می‌دونم چطور انجام بدم."

    # say L26 sis
    old "See, that's nerdy shit... "
    new "ببین، این کارهای گیکی هستند..."

    # say L27 pla
    old "Come out with it. What do you need?"
    new "بیا بگو. چه کاری می‌خوای؟"

    # say L28 sis
    old "Haha. Ok, just come to my room in the afternoon and I will explain everything..."
    new "هahas. خب، فقط بعد از ظهر به اتوممن بیا و همه چی رو توضیح می‌دم..."

    # say L60 pla
    old "Oh, shit..."
    new "اوه، شیطون..."

    # say L64 sis
    old "(GOD that's his... It's huge...)"
    new "الهی، اون هم... خیلی بزرگه..."

    # say L70 pla
    old "No... It's... Not... What... It seems..."
    new "نه... این... نیست... مثل... آنچه به نظر می‌رسه..."

    # say L87 pla
    old "Oh shit, did she see you?"
    new "اوه شیطون، آیا تو را دید؟"

    # say L89 bri
    old "Of course not. No one but you can see me..."
    new "البته نه. هیچ‌کس جز تو نمی‌تونه منو ببینه..."

    # say L91 pla
    old "Yeah... But she saw me... Like this... Fuck..."
    new "بله... اما او من رو دید... همین‌طور... شیطون..."

    # say L93 pla
    old "Now what? It doesn't go down..."
    new "الان چه کار کنم؟ این چیز پایین نمی‌رود..."

    # say L95 bri
    old "Well, I think that interrupting the process of transferring magic power so abruptly was not a good thing..."
    new "خب، فکر می‌کنم قطع کردن فرآیند انتقال توان جادویی به طور ناگهانی خوب نبوده..."

    # say L97 pla
    old "So, now what do I do to get this thing down?"
    new "پس الان من چه کاری باید بکنم تا این چیز پایین بیاد؟"

    # say L99 bri
    old "Well... It would be best to wait for your body to process all the magical power it received for the first time."
    new "خب... بهتره تا بدن تو همه انرژی جادویی که برای اولین بار دریافت کرد رو پردازش کنه صبر کنی."

    # say L101 pla
    old "Okay. It's probably best to go to my room before someone else comes in and sees me with this..."
    new "باشه. بهتره قبل از اینکه کسی بیاد و من رو با این شرایط ببینه، به اتاقم برسم."

    # say L103 bri
    old "Ok, I'll rest and try to recover some magical energy."
    new "باشه، استراحت می‌کنم و سعی می‌کنم برخی از انرژی جادویی رو بازیابی کنم."

    # say L130 pla
    old "Oh... Hi, [sis]... "
    new "اوه... سلام، ز[sis]..."

    # say L131 sis
    old "I've been waiting for you. Let's jump right into it, shall we?"
    new "من منتظرت بودم. بیای، همین حالا شروع کنیم، خوبه؟"

    # say L132 pla
    old "... Sure, I guess."
    new "بله، حدس می‌زنم."

    # say L134 sis
    old "Now, pay attention... As you know, I have been selling clothes to friends and acquaintances."
    new "الان، توجهت رو به من بده... همانطور که می‌دونی، من لباس به دوستا و آشنایا می‌فروشم."

    # say L135 sis
    old "But now I want to sell them on the internet! That's why I need you to help me make a website."
    new "اما حالا می‌خوام اونا رو توی اینترنت بفروشم! همین جوری که نیاز دارم تو به من کمک کنی یه وب‌سایت بسازی."

    # say L136 pla
    old "Well, I've never done a storefront site before... But it should be easy enough."
    new "خب، هیچ وقت سایت فروشگاهی ساخته‌ام... اما باید آسون باشه."

    # say L137 sis
    old "Perfect! Good nerd! Because I will need it ready for next week. I have a lot of items to post."
    new "عالی! خوب نerd! چون باید تا هفته بعد آماده باشه. من مورد زیادی برای قرار دادن دارم."

    # say L138 pla
    old "What? That's gonna be pretty hard to make it that fast, [sis]."
    new "چه؟ این کار خیلی سخته تا هفته بعد آماده شه، [sis]."

    # say L139 pla
    old "Making a good website takes time. You'd have to work on it for days, sometimes weeks. And then it could be buggy and-."
    new "ساختن یک وب‌سایت خوب وقت می‌بره. باید روزها، گاهی هفته‌ها رو رویش کار کرد. بعد هم ممکنه باگ داشته باشه و-"

    # say L140 sis
    old "Oh, come on, [pla]! You're a nerd. King nerd, in fact. I trust you can whip my site up in no time."
    new "آه، بیا، [pla]! تو یه نردی. در واقع، پادشاه نردها. من باورم دارم تو بتونی وب‌سایتم رو توی هیچ وقت آماده کنی."

    # say L141 pla
    old "It's just not as simple as you think. Actually, I'm going to need you to work closely with me to tell me how you want it designed."
    new "این همچون اونقدر ساده نیست که فکرش کنی. در واقع، باید با من همکاری کنی و به من بگویی چطور می‌خوای طراحی بشه."

    # say L142 sis
    old "Alright, but how long will this take? And I'm not trying to just get this for free. I'm willing to pay a small fee for your help."
    new "البته، اما این چقدر طول می‌کشه؟ و من نمی‌خوام فقط رایگان بگیرم. آماده‌ام هزینه کوچیکی برای کمکت بپردازم."

    # say L143 pla
    old "Really? Hmmm... Maybe we can work in the afternoons and see how far we can go with it."
    new "حقاً؟ هم‌هم‌هم... شاید بتوانیم بعد از ظهر کار کنیم و ببینیم چقدر پیش می‌رود."

    # say L144 sis
    old "That's the spirit, little dude. And hey, if it all works out well, I could share some of the profits."
    new "این همون جویاییه، جون پسر. و اگه همه چی خوب پیش برود، می‌تونم سودشو با تو تقسیم کنم."

    # say L145 pla
    old "Nice. Sounds good to me."
    new "عالی. برای من هم خوب است."

    # say L146 sis
    old "Perfect! Then I will wait for you in the afternoon in my room so we can start working. And don't have me waiting like you did yesterday."
    new "پرفکت! بعد از ظهر تو اتاق من منتظرت می‌مونم تا شروع کنیم. و مثل دیروز نباید من رو منتظر بگذاری."

    # say L147 pla
    old "Ok, I will see you in the afternoon to help you."
    new "باشه، بعد از ظهر می‌آم و بهت کمک می‌کنم."

    # say L148 sis
    old "Thank you so much! By the way, what have you been doing in the garage?"
    new "ممنونم! بین هم اینجوری، تو در گاراژ چه کاری داشتی؟"

    # say L149 pla
    old "Well... Uhh... A school project... "
    new "خب... اوه... یه پروژه مدرسه..."

    # say L150 sis
    old "And what's so exciting in the project that's making your dick so hard?"
    new "و چه چیزی در این پروژه هیجان‌انگیزه که ناخودآگاهی شورت تو رو اینقدر بیرون می‌آره؟"

    # say L151 pla
    old "What? Uhh... I don't know... What are you're talking about... "
    new "چه؟ اوه... نمی‌دونم... داری چه حرفی می‌زنی..."

    # say L152 sis
    old "Haha. Yeah, right. You know I saw it?"
    new "هahaha. بله، همینه. میدونی من دیدمش؟"

    # say L154 sis
    old "Ok, ok, don't answer me. I was just being curious... If you need to go ahead with your project, do your thing."
    new "باشه، باشه، نگو. فقط خوشحالم که داشتم کنجکاو می‌شدم... اگه باید پروژه‌ت رو انجام بدی، برو پیش ببر."

    # say L155 sis
    old "Just don't forget me in the afternoons."
    new "فقط بعد از ظهر رو فراموش نکن."

    # say L185 sis
    old "Damn, it's late. I didn't realize how much time has passed."
    new "بازه، وقت پیش رفت. متوجه نشدم چقدر زمان گذشته."

    # say L189 pla
    old "Yup, we did a lot of work today."
    new "بله، امروز کار زیادی کردیم."

    # say L190 sis
    old "That's right, you deserve a break today. Thanks for your hard work."
    new "درست می‌فرمایی، امروز کار زیادی کردی. ممنون از تلاشت."

    # say L191 pla
    old "Ok, you are very welcome... See you later, good night."
    new "بله، خوشحالم که کمک کردم... ببینم چه وقتی، خوب بخوابید."

    # say L200 pla
    old "Yeah, but we are making so much progress."
    new "بله، اما ما پیشرفت زیادی داریم."

    # say L201 sis
    old "Right! I like this kind of work. You typing all of those codes and me saying what to do... "
    new "درسته! من این کار رو دوست دارم. تو همه اون کد‌ها رو تایپ می‌کنی و من می‌گم چه کاری باید بکنی..."

    # say L202 pla
    old "Yeah... That was really fun... "
    new "بله... اونقدر لذت‌بر بود..."

    # say L203 sis
    old "Oh, come on, it wasn't that bad and I will pay you... "
    new "بیا، نه اینقدر بد نبود و من هم به تو پول می‌دهم..."

    # say L204 pla
    old "You are right about that. We are a good team."
    new "درست می‌فرمایی. ما تیم خوبی هستیم."

    # say L205 sis
    old "That's better! Ok, let's link back up tomorrow to keep working!"
    new "عالی! خب، فردا دوباره همکاری کنیم."

    # say L206 pla
    old "Ok, see you later, [sis]. Have a good night."
    new "باشه، بعداً می‌بینیم، ز[sis]. شب خوبی داشته باش."

    # say L220 pla
    old "What the fuck! What is this?"
    new "چه فکر کنی! این چیه؟"

    # say L227 sis
    old "NOTHING... NOTHING! (Shit!) I THINK WE'RE DONE FOR TODAY!"
    new "هیچ... هیچ! (شیطون!) فکر کنم برای امروز کار ما تمام شده."

    # say L228 pla
    old "But... There is still so much to do."
    new "ولی... هنوز کار زیادی باقی مونده."

    # say L229 sis
    old "A Virus! My laptop has a virus and I need to fix it... Come tomorrow. Leave now."
    new "یک ویروس! لپ‌تاپ من ویروس داره و باید این مشکل رو حل کنم... فردا بیا. حالا برو."

    # say L230 pla
    old "... (Hmm, that was weird.)"
    new "Hmm، این عجیب بود."

    # say L247 pla
    old "I should check if [sis] needs help with the website."
    new "باید ببینم آیا [sis] به من برای وب‌سایت کمکی لازم داره."

    # say L256 pla
    old "Oh wow!"
    new "اوه وای!"

    # say L259 pla
    old "I- I'm sorry, I didn't k- know..."
    new "من- من خیال می‌کردم، نمی‌دونستم..."

    # say L260 sis
    old "Oh, come on... This isn't what you wanted to see?"
    new "اوه، بیای ببین... اینجوری نبود که می‌خواستی ببینی؟"

    # say L262 sis
    old "Turn around [pla], I want you to see me..."
    new "دیوونه نباش، بگرد [pla]، می‌خوام تو رو ببینم..."

    # say L265 sis
    old "Ohh... Look what we have here... You definitely have a huge cock..."
    new "اوه... ببینیم چه چیزی داریم... قطعاً یک نوزاد بزرگ داری..."

    # say L267 sis
    old "You have worked very, very hard for me, maybe you deserve a small reward."
    new "تو خیلی، خیلی سخت کار کردی برای من، شاید یه جایزه کوچیک هم بگیری."

    # say L269 sis
    old "Well I think you have something for me down there, maybe I should take care of it."
    new "خب فکر می‌کنم چیزی برای من در اونجا داری، شاید باید بهش مراقبت کنم."

    # say L271 sis
    old "I know you want to fuck me... I think I could let you fuck my mouth, would you like that?"
    new "میدونم می‌خوای با من جنس کنی... فکر کنم می‌تونم بگم تو دهانم رو جنس کنی، می‌خوای اینجوری کنی؟"

    # say L273 sis
    old "Yes, I'll let you fuck my mouth, with that huge cock..."
    new "بله، می‌تونی دهانم رو با اون نیم‌تنه بزرگ فوتون..."

    # say L274 sis
    old "Now, take out that cock and come here!"
    new "حالا، آن نیم‌تنه رو بیرون بیار و اینجا بیا!"

    # say L292 pla
    old "Wow! That was just a dream..."
    new "واو! این فقط یه رویا بود..."

    # say L293 pla
    old "I should definitely stop playing visual novels..."
    new "باید حتماً از بازی‌های تصویری خودداری کنم..."

    # say L294 pla
    old "Working with her so much is affecting me in some way."
    new "با هم کار کردن به من تاثیر می‌ذه."

    # say L325 pla
    old "Ufff finally... I think that's it, we are done."
    new "وفاتا... فکر کنم اینجاست، تمام شدیم."

    # say L326 sis
    old "Really? Finally? Excellent!!! So, how do we start selling products?"
    new "وای، وای؟ وای؟ عالی!!! پس، چطور شروع می‌کنیم فروش کالاها؟"

    # say L327 pla
    old "Hmm... I'm a bit tired because of all I have done, we can check tomorrow."
    new "Hmm... خسته‌ام از همه کاری که کردم، می‌تونیم فردا بررسی کنیم."

    # say L328 sis
    old "What?! I've been waiting for weeks! I need to sell my products as fast as I can, it will take just a moment and you're not going die for that... "
    new "چه خبر؟! هفته‌ها منتظر این بودم! باید محصولاتم رو سریع فروخته بشه، فقط یه لحظه طول می‌کشه و تو برای این مرده نمی‌شی..."

    # say L329 pla
    old "Ok, I will explain, pay attention to this."
    new "باشه، من توضیح می‌دم، به این توجه کن."

    # say L336 pla
    old "Oh, this is a very interesting part on web designing, I used javascript in order to make your webpage responsive, I apply the layouts and-"
    new "اوه، این بخش خیلی جالبی در طراحی وب هست، من از جاوااسکریپت استفاده کردم تا صفحه وبت را پاسخگو کنم، من الای‌ها رو تنظیم کردم و-"

    # say L337 sis
    old "Come On! straight to the point nerd! How do I upload the content?"
    new "بیا، به سرعت! خیلی تکنیکی می‌شی! چطور می‌تونم محتوایم رو آپلود کنم؟"

    # say L338 pla
    old "Ok, well, to upload the pics and info, you need to access with the admin account, open the products window and there you can upload, item by item... "
    new "خب، برای آپلود عکس‌ها و اطلاعات، باید با حساب مدیر وارد شی، پنجره محصولات رو باز کنی و اونجا می‌تونی یک به یک آپلود کنی..."

    # say L339 pla
    old "The description needs a title, detailed info of the product, the pics and finally the price, and there you go!"
    new "توضیحات نیاز به عنوان، اطلاعات جزیی محصول، عکس‌ها و در نهایت قیمت داره، و بعد از همه اینا، کار تمامه!"

    # say L340 sis
    old "Woow, amazing, let me try myself... "
    new "وای، عالی، بیایم من خودم امتحان کنم..."

    # say L344 pla
    old "Ok... "
    new "باشه..."

    # say L345 sis
    old "It's not as hard as you said, actually it's pretty simple... "
    new "این به نظر نمی‌آید به همان اندازه سخت باشه که گفتی، در واقع خیلی ساده است..."

    # say L346 pla
    old "Well, it's because the hardest part was done already with the coding... "
    new "خب، چون سخت‌ترین بخش قبلاً با کدنویسی انجام شده بود..."

    # say L347 sis
    old "Suuuuure. Now, how can an user make a purchase?"
    new "حتماً. حالا، یوزر چطور می‌تونه خرید کنه؟"

    # say L348 pla
    old "Well, everything is done thru the security framework-"
    new "همه چیز از طریق چارچوب امنیت انجام می‌شه-"

    # say L349 sis
    old "BORING! just tell me how I can see the money. "
    new "BORING! فقط به من بگو چطور می‌تونم پول رو ببینم."

    # say L350 pla
    old "Hmm ok. You need to go to the sales window, here you will see the customer info, products and money."
    new "Hmm خب. باید به پنجره فروش بروی، اینجا اطلاعات مشتری، محصولات و پول رو می‌بینی."

    # say L351 sis
    old "Wujuu! If you behave I think, there is an option to make you my partner."
    new "ووجو! اگه خوب رفتار کنی، فکر کنم می‌تونم تو رو هم شریک بکنم."

    # say L352 pla
    old "Yeah right. Well I think that's all for today, need anything else?"
    new "بله درسته. خب فکر کنم این همه برای امروزه، نیاز به چیز دیگه‌ای داری؟"

    # say L353 sis
    old "No, if I need something I'll reach out to you... You better not doing something weird... "
    new "نه، اگر نیازی پیش بیاد به تو تماس می‌گیرم... بهتره چیز عجیبی نکنی..."

    # say L355 sis
    old "Nevermind... I will be busy, doing my work, see you later... "
    new "بی‌خیال... من مشغول کارم، بعداً می‌بینیم..."

    # say L356 pla
    old "Hmm, Ok... (You are welcome, by the way... )"
    new "Hmm، خوب... (ممنون، اصلاً...)"

    # say L374 pla
    old "(Oh shit! My [sisrel] is taking a shower... )"
    new "اوه شیطون! ز[sisrel] در حال شوشرفتنه..."

    # say L375 pla
    old "(She's got such an amazing body... )"
    new "(این قدر بدنه خوبی داره... )"

    # say L387 pla
    old "(I should leave... I don't want to make her think I'm perverted.)"
    new "باید برسم... نمی‌خوام فکر کنه من خودکامه هستم."

    # say L391 pla
    old "(I should leave... I don't want to make her think I'm a pervert.)"
    new "باید برسم... نمی‌خوام فکر کنه من یه خودکامه هستم."

    # say L396 sis
    old "What the fuck! What are you doing, [pla]?"
    new "چه کاری می‌کنی، [pla]؟"

    # say L397 pla
    old "Sorry, I was-."
    new "ببخشید، من بودم-"

    # say L398 sis
    old "COME IN... AND CLOSE THE DOOR."
    new "بیا داخل... و در رو ببند."

    # say L399 pla
    old "(Shit!)"
    new "لُعنت!"

    # say L405 pla
    old "Look I... "
    new "ببین من..."

    # say L406 sis
    old "Shut up... You just saw me... Now it's my turn."
    new "بسته... تو فقط دیدی مرا... حالا دفعه من است."

    # say L407 pla
    old "(Gulp) What? What do you mean?"
    new "چه؟ منظورت چیه؟"

    # say L408 sis
    old "I mean, show me what you got in those shorts."
    new "من می‌خوام ببینم تو توی آن شورت‌هایت چه چیزی داری."

    # say L409 pla
    old "Whaat?... "
    new "چه؟..."

    # say L410 sis
    old "Well, if you don't show me, I'm going to scream and tell [mo1] and [mo2] you were peeping on me."
    new "اگه نمی‌تونی برام نشون بدی، من صدا می‌زمم و به ز[mo1] و ز[mo2] می‌گم که تو داشتی به من نگاه می‌کردی."

    # say L411 pla
    old "B- but... Why do you want to see me naked?"
    new "ب- بله... چرا می‌خوای از من بره نگاه کنی؟"

    # say L412 sis
    old "Is justice for a pervert... And I'm just curious about what I saw in the garage last time... So show me... Now!"
    new "این عدالت برای یک خودسر از دست من! و من فقط کنجکاو هستم از آن چیزی که توی گاراژ دیدم... پس برام نشون بده... حالا!"

    # say L413 pla
    old "Alright, alright... "
    new "باشه، باشه..."

    # say L421 sis
    old "(Mmm... It's bigger than some pornstars I use to see.)"
    new "ممنون... بزرگتر از بعضی ستارگان پورنی که می‌دیدم."

    # say L422 sis
    old "And... Why were you so excited at the garage?"
    new "و... چرا تو در گاراژ اونقدر خوشحال بودی؟"

    # say L423 pla
    old "Hmm... I- I don't know what you're talking about."
    new "Hmm... من- من نمی‌دونم در مورد چی حرف می‌زی."

    # say L424 sis
    old "Ugh. Ok, nevermind... I should go... "
    new "آه. خب، فراموش کن... من باید برسم..."

    # say L428 pla
    old "Wait... That's my? "
    new "بیا... این مال منه؟"

    # say L429 sis
    old "Bye... "
    new "بای‌ها..."

    # say L436 pla
    old "What the hell! She took my clothes!"
    new "چه هیولا! لباس‌هام رو برداشت!"

    # say L437 pla
    old "Oh shit! What do I do now?"
    new "اوه شیطون! حالا چی کار کنم؟"

    # say L438 pla
    old "I gotta get to my room really fast!"
    new "باید به اتاقم برم خیلی زود!"

    # say L443 pla
    old "Ok I don't see anyone nearby, now is my chance... "
    new "خب من هیچ کس نزدیک نمی‌بینم، حالا فرصتم است..."

    # say L453 mo2
    old "WHAT THE FUCK?!"
    new "چه خبره؟!"

    # say L454 pla
    old "(... Oh god..) Sorry... "
    new "(... اوه خداوند...) معذرت..."

    # say L465 mo2
    old "YOU ARE A FUCKING PERVERT AND AN EXHIBITIONIST!!!"
    new "تو یک پرتلاش و نمایش‌گر هستی!!!"

    # say L466 pla
    old "(Oh shit, oh shit. I almost died! Fuck!)"
    new "اوه شیطون، اوه شیطون. تقریباً مردم! لعنتی!"

    # say L467 pla
    old "It's probably best to stay here until tomorrow... "
    new "بهتر است اینجا بمانیم تا فردا..."

    # say L490 sis
    old "Well, I am kind of ok."
    new "خب، من به نظر می‌رسم خوب هستم."

    # say L491 pla
    old "Hmm... Is everything alright?"
    new "همم... همه چیز خوبه؟"

    # say L492 sis
    old "Not really, the website is not working and I don't know what's wrong."
    new "نه، واقعاً خوب نیست، وب‌سایت کار نمی‌کند و من نمی‌دونم مشکل از چیه."

    # say L493 pla
    old "Is not working? You wanna check it together to see what the problem could be?"
    new "کار نمی‌کنه؟ می‌خوای هم‌اونجا بررسی کنیم ببینیم مشکل از چیه؟"

    # say L494 sis
    old "Oh please, because I feel a bit down, you know."
    new "لطفاً، چون من یه کم خسته‌ام، می‌دونی."

    # say L495 pla
    old "Don't worry, we can find a solution."
    new "نگران نباش، می‌تونیم راه‌حلی پیدا کنیم."

    # say L502 pla
    old "I can see that your webpage has been visited several times, so there are actually people looking at it."
    new "من می‌تونم ببینم صفحه وبت رو چند بار باز شده، پس در واقع مردم بهش نگاه می‌کنن."

    # say L503 sis
    old "I think the clothes are nice, but do you think they're maybe too expensive?"
    new "فکر کنم لباس‌ها خوب هستن، ولی آیا فکر می‌کنی قیمت‌شون خیلی بالاست؟"

    # say L504 pla
    old "Hmmm, I think you have a good variety of prices, so I don't think that is the problem."
    new "Hmm، فکر کنم قیمت‌ها متنوع هستن، پس نمی‌تونم بگم این مشکل هست."

    # say L505 sis
    old "Could it be that the products aren't that nice?"
    new "ممکن است محصولات خیلی خوب نباشند؟"

    # say L506 pla
    old "I actually like them, I've seen you wearing some of the clothes, they look cool."
    new "من در واقع می‌پسندم، دیدم تو چند تا از لباس‌ها رو پوشیدی، خوب هستند."

    # say L507 sis
    old "Is the website running correctly?"
    new "وب‌سایت درست کار می‌کنه؟"

    # say L508 pla
    old "What do you mean? Sure! it works, I made it myself."
    new "من قصد چی هستی؟ حتماً، کار می‌کنه، خودم ساختم."

    # say L509 sis
    old "Let's try to make a purchase to see if the website is ok."
    new "بیای بیشتر بررسی کنیم تا ببینیم وب‌سایت خوب کار می‌کنه."

    # say L510 pla
    old "I did everything carefully... Hmm, but we can double check."
    new "من همه چیز رو با دقت انجام دادم...Hmm، ولی می‌تونیم دوباره بررسی کنیم."

    # say L511 sis
    old "Perfect, select that shirt, then those pants, add them to the shopping cart."
    new "عالی، آن پیراهن را انتخاب کن، بعد اون شلوارها رو، و به سبد خرید اضافه کن."

    # say L512 sis
    old "What's next?"
    new "بعدش چی؟"

    # say L513 pla
    old "The delivery info"
    new "اطلاعات تحویل"

    # say L514 sis
    old "Ok, let's use ours."
    new "باشه، بیایم از این استفاده کنیم."

    # say L515 pla
    old "Oh, payment options, let's put the card in."
    new "اوه، گزینه‌های پرداخت، بیای بگذاریم کارت رو."

    # say L517 pla
    old "Finally, summary cart."
    new "در نهایت، خلاصه سبد خرید."

    # say L518 pla
    old "Order went through successfully, the website works perfectly. That's not the problem."
    new "سفارش با موفقیت ثبت شد، وب‌سایت کاملاً خوب کار می‌کنه. این مشکل نیست."

    # say L519 sis
    old "Cancel the order."
    new "سفارش رو لغو کن"

    # say L520 sis
    old "I don't get it... What am I doing wrong?"
    new "من نمی‌فهمم... من چی اشتباه می‌کنم؟"

    # say L521 sis
    old "What do other people do to sell?"
    new "دیگران چه می‌کنن تا بفروشن؟"

    # say L522 pla
    old "Huh! that's brilliant."
    new "های! این خوبه."

    # say L523 sis
    old "Really? Wait... What's brilliant?"
    new "وای، حقاً؟ بیا... چه چیزی عالیه؟"

    # say L524 pla
    old "A very good idea could be to check how other people do it."
    new "ایده خوبی هست که ببینیم دیگران چطور این کار رو انجام میدن."

    # say L525 pla
    old "Let's compare ours with other websites, that way we can take some ideas too."
    new "بیاین مونو با سایت‌های دیگه مقایسه کنیم، همینطور می‌تونیم چند ایده هم بگیریم."

    # say L526 pla
    old "Let's check a big one like... Hmm I don't know, Calvin Klown."
    new "بیاین یکی بزرگ مثل... هم من نمی‌دونم، Calvin Klown رو بررسی کنیم."

    # say L527 sis
    old "Yeah, that could work."
    new "بله، این می‌تونه خوب باشه."

    # say L528 pla
    old "They are really good, this looks amazing."
    new "این‌ها واقعاً خوب هستند، این خیلی جالب به نظر می‌رسه."

    # say L529 sis
    old "Yeah, it's very depressing."
    new "بله، خیلی ناراحت کننده است."

    # say L531 sis
    old "Just look! They are just so gorgeous, mine doesn't look even close."
    new "ببین! اونا فقط خیلی زیبا هستن، می‌تونی بگی هیچ جور شبیه اونا نیست."

    # say L532 pla
    old "Well, it's not fair if you compare yourself with them, this is a worldwide fashion business!"
    new "خب، این منصفانه نیست اگر خودت رو با اونا مقایسه کنی، این یه کسب و کار مد جهانیه!"

    # say L533 pla
    old "Consider, that they invest millions on advertisement, Internet, TV characters, even music videos and artists."
    new "باید در نظر بگیری که اونا میلیون‌ها رو توی تبلیغات، اینترنت، شخصیت‌های تلویزیون، حتی ویدیوهای موسیقی و هنرمندان سرمایه گذاری می‌کنن."

    # say L534 sis
    old "Yeah, that's very impressive."
    new "بله، این خیلی مدرن است."

    # say L535 pla
    old "Alright, that was enough Calvin Klown for one day."
    new "خوب، اینقدر کالوین کلوون برای یک روز کافی بود."

    # say L541 pla
    old "Hmm... I have something in mind."
    new "Hmm... چیزی تو ذهنم هست."

    # say L542 pla
    old "Well, we could, and I am not sure... But try some options to show the clothes like they do."
    new "خب، می‌تونیم، ولی مطمئن نیستم... ولی می‌تونیم چند روش برای نمایش لباس‌ها مثل اونا امتحان کنیم."

    # say L543 sis
    old "You mean the way they use models and take the pics?"
    new "منظورت اینه که مثل آنها مدل‌ها رو بکنیم و عکس‌ها رو بگیریم؟"

    # say L544 pla
    old "Yes, it could look more... Interesting? I guess so?"
    new "بله، می‌تونه جالب‌تر بیاد... حدس می‌زنم همینطور؟"

    # say L545 pla
    old "We can give it a try, doing the pics instead of using the ones you're using."
    new "می‌تونیم امتحان کنیم، عکس‌ها رو خودمون ببریم به جای اونایی که استفاده می‌کنی."

    # say L546 sis
    old "Hmm but we'll need a model and we can't afford that... "
    new "همم اما ما به یک مدل نیاز داریم و نمی‌تونیم هزینه‌ش رو بپردازیم..."

    # say L547 sis
    old "Wait a minute... I could be the model, can't I?"
    new "یه لحظه... من خودم می‌تونم مدل باشم، نیست؟"

    # say L548 pla
    old "I considered that an option at first, but I saw there are some clothes where you would be almost naked."
    new "اول هم این راه رو فکر کردم، ولی دیدم بعضی لباس‌ها تقریباً عریانی هستند."

    # say L549 pla
    old "I mean some clothes are 'sexy' and a lot of people would watch them... Are you sure you are ok with that?"
    new "من قصد دارم بگم که بعضی لباس‌ها 'جذاب' هستن و خیلی مردم بهشون نگاه می‌کنن... مطمئنی با این حالت راحتی داری؟"

    # say L550 sis
    old "Actually, I like the idea... I think it's kind of exciting!"
    new "در واقع من دوست دارم این ایده رو... فکر می‌کنم هیجان‌انگیزه!"

    # say L551 pla
    old "Well, if you'd like we would have covered an important part of the problem and if you are the model that would be very useful to have a defined market image."
    new "خب، اگر خوایشی هستی بخش مهمی از مشکل رو حل می‌کنیم و اگر تو مدل باشی برای تعریف تصویر بازار خیلی مفید خواهد بود."

    # say L552 sis
    old "Ok, so, what do we need?"
    new "خب، پس، چه چیزی به ما لازم می‌شه؟"

    # say L553 pla
    old "We will for sure need a photographer."
    new "حتماً به یک عکاس نیاز خواهیم داشت."

    # say L554 sis
    old "Wait a minute! A photographer could be really expensive."
    new "بی‌چین! عکاس می‌تونه واقعاً گران باشه."

    # say L555 sis
    old "Why don't you take the pics instead?"
    new "چرا تو عکس‌ها رو بگیری؟"

    # say L556 pla
    old "Technically, I could but I have no camera."
    new "من فنیا می‌تونم اما دوربین ندارم."

    # say L557 sis
    old "I think I can handle that. But can you use a professional camera?"
    new "فکر می‌کنم بتونم این کار رو انجام بدم. ولی می‌تونی از دوربین حرف بزنی؟"

    # say L558 sis
    old "What I'm asking for of course a nerd knows."
    new "البته یک نرد اینقدر ساده رو می‌دونه."

    # say L560 sis
    old "That's great, so if you take the pictures, we can save a little without asking for the help of a photographer."
    new "عالی، پس اگر تو عکس‌ها رو بگیری، می‌تونیم بدون درخواست کمک یه عکاس، یه کم پول صرفه‌جویی کنیم."

    # say L561 sis
    old "So, I will use all my money to buy a lot of clothes, so we can take tons of pics."
    new "پس من تمام پولم رو برای خرید لباس‌ها می‌ذارم تا عکس‌های زیادی ببریم."

    # say L562 pla
    old "Wait what? No, no, no, calm down! It isn't convenient to use all the money you have."
    new "بیا چی؟ نه، نه، نه، آرام شو! خوب نیست که همه پولت رو ببری."

    # say L563 sis
    old "But we will need the clothes for the pics... "
    new "ولی برای عکس‌ها لازم هست که لباس‌ها رو بخریم..."

    # say L564 pla
    old "Yes, we do, however, we have to do some baby steps to check if it works."
    new "بله، اینجوری هست، ولی باید یه قدم به قدم بریم تا ببینیم کار می‌کنه یا نه."

    # say L565 pla
    old "If we can see some progress then you can invest more to see an improvement."
    new "اگر پیشرفتی ببینیم می‌تونی بیشتر سرمایه‌گذاری کنی تا بهبود ببینی."

    # say L566 sis
    old "Hmm... Yeah, I think you're right."
    new "Hmm... بله، فکر کنم همینطور هست."

    # say L567 sis
    old "Ok, I need time now, to get all of this ready. thanks for your help, I really appreciate it."
    new "باشه، الان وقت می‌خواهم برای آماده‌سازی همه اینا. ممنون از کمکت، واقعاً از این بابت قدردانی می‌کنم."

    # say L568 sis
    old "I will let you know as soon as I have everything ready."
    new "باشه، همینجوری، همینطور بهت اطلاع می‌دم که همه چیز آماده شده."

    # say L569 pla
    old "Cool, I'll see you then."
    new "خوب، تا وقتی می‌بینم."

    # say L589 sis
    old "[pla], where were you? I've been looking for you."
    new "[pla]، تو کجایی بودی؟ دنبالت می‌گردم بودم."

    # say L590 sis
    old "Let's go, the delivery has just arrived."
    new "بیای، تحویل فقط الان رسید."

    # say L591 sis
    old "You can't imagine how excited I am, I almost jumped from the window when I saw the driver."
    new "تو نمی‌تونی فکر کنی چقدر خوشحالم، وقتی راننده رو دیدم تقریباً از پنجره پریدم."

    # say L592 pla
    old "I can see that, you're all anxious to start."
    new "می‌تونم ببینم، خیلی صبر نمی‌کنی برای شروع."

    # say L593 sis
    old "Yes, we can't waste time, I have been waiting for this, the website needs this."
    new "بله، نمی‌تونیم وقت ببریم، اینجوری منتظر شدم، وب‌سایت به این نیاز داره."

    # say L594 sis
    old "Let's go to my bedroom."
    new "بیای به اتاق خوابم."

    # say L602 sis
    old "Give me a moment, I don't know where to start. "
    new "بیا یه لحظه، نمی‌دونم از کجا شروع کنم."

    # say L603 pla
    old "Ok, just calm down a bit."
    new "باشه، فقط یه کم آرام شو."

    # say L613 sis
    old "I'm pretty impatient we can start right away."
    new "من خیلی صبور نیستم، می‌تونیم همین حالا شروع کنیم."

    # say L614 sis
    old "This is for you."
    new "این برای توست."

    # say L619 pla
    old "Wow, this is huge, looks like a very good camera."
    new "واو، این خیلی بزرگه، به نظر می‌رسه یه دوربین خیلی خوبه."

    # say L620 sis
    old "I am sure you will figure out how it works."
    new "مطمئنم تو یاد می‌گیری این چطور کار می‌کنه."

    # say L621 sis
    old "Bear with me a moment while I get ready. You should try the cam in the meantime."
    new "برای یک لحظه صبر کن، من آماده می‌شوم. تو هم باید دوربین رو امتحان کنی در این میان."

    # say L622 pla
    old "Ok, Sure, I will start checking (It doesn't look so hard.)"
    new "باشه، حتماً شروع می‌کنم (به نظر نمی‌رسه خیلی سخت باشه.)"

    # say L628 pla
    old "(I think auto mode should work just fine to start, I'll give a further review later.)"
    new "من فکر می‌کنم حالت خودکار خوب کار می‌کنه، بعداً بررسی بیشتری می‌کنم."

    # say L629 pla
    old "(Let's check... She bought really nice clothes.)"
    new "بیاین بررسی کنیم... لباس‌های خوبی خریده."

    # say L636 pla
    old "(This is very short and tiny. How does she fit in?)"
    new "این خیلی کوتاه و کوچیکه. اونجوری چطور جا می‌شه؟"

    # say L642 pla
    old "(This is a great color for a pic, I think I have a couple of ideas.)"
    new "این رنگ برای عکس خوبه، فکر کنم چند ایده دارم."

    # say L648 pla
    old "(What is this?)"
    new "این چیه؟"

    # say L651 pla
    old "(Ohh... This is a...)"
    new "اوه... این یه..."

    # say L654 sis
    old "Wow,wow, wow. GET AWAY FROM MY STUFF... You little snoopy."
    new "وای، وای، وای. از چیزهای من دور برو... تو خیالی."

    # say L660 sis
    old "Where did you get it?"
    new "این رو از کجا آوردی؟"

    # say L661 sis
    old "I mean why are you looking through my stuff?"
    new "من قصه‌ای می‌خوام چرا تو در چیزهای من دنباله‌ات؟"

    # say L662 pla
    old " I... I- I just... "
    new "من... من... من فقط..."

    # say L663 sis
    old " I... I... I... What?"
    new "من... من... من... چه؟"

    # say L664 pla
    old "I was checking the clothes you bought, and it was just there."
    new "من فقط لباس‌هایی که خریدی رو بررسی می‌کردم، و اونجا بود."

    # say L665 pla
    old "I was not snooping, just checking the clothes and that appeared out nowhere."
    new "من هیچ جاسوسی نکردم، فقط لباس‌ها رو بررسی می‌کردم و اونجوری پدیدار شد."

    # say L666 sis
    old "THERE'S NO TIME TO WASTE, WE CAME TO WORK, LET'S GET STARTED."
    new "وقتی برای ضایع کردن نیست، اومدیم کار کنیم، بیاین شروع کنیم."

    # say L667 pla
    old "You're right, I'm sorry."
    new "درست می‌گویی، معذرت."

    # say L668 sis
    old "Alright, just get everything ready while I change."
    new "البته، فقط همه چیز رو آماده کن در حالی که من لباسم را عوض می‌کنم."

    # say L676 sis
    old "Well... How do I look?"
    new "خب... من اینجوری چطور به نظر می‌رسم؟"

    # say L677 pla
    old "Gulp... Y-you look ho- nice, you look pretty nice."
    new "گulp... تو خوب هستی، خیلی زیبا هستی."

    # say L678 sis
    old "Let's start, we have already wasted enough."
    new "بیای، قدر کافی وقت را از دست رفته."

    # say L693 pla
    old "Ok, let me try... I will stay here to catch you better, stay right there."
    new "باشه، بیای... من اینجا می‌مونم تا بهتر بتونم تو رو بگیرم، همینجا بمان."

    # say L700 pla
    old "(Oh shit.. It's not as easy as I thought...)"
    new "اوه شیطون... این به نظر نمی‌رسه آسون باشه."

    # say L702 pla
    old "Ehh... Just give me a second... I- I'm finding your best... Angle."
    new "اوه... فقط یه لحظه صبر کن... من- من بهترین زاویه‌ت رو پیدا می‌کنم."

    # say L703 pla
    old "(Shit! I must take the picture when it's fully focused...)"
    new "شیط! باید وقتی کاملاً تمرکز شده عکس بگیرم..."

    # say L741 pla
    old "Ehmm... Fine, we could check it at the end of the session..."
    new "اهم... خب، می‌تونیم آخر جلسه بررسیش کنیم."

    # say L742 sis
    old "You're right, sorry I'm just a bit anxious."
    new "درستی، معذرت، من فقط کمی ناراحت هستم."

    # say L743 pla
    old "Don't worry, relax a bit to look more natural."
    new "نگران نباش، یه کم آرام شو تا طبیعی‌تر به نظر بیان."

    # say L744 sis
    old "Okay, so for the next photo what should I do?"
    new "باشه، برای عکس بعدی چه کاری باید بکنم؟"

    # say L745 pla
    old "Hmm, I think we should take a picture from behind to show the back of the dress..."
    new "Hmm، فکر کنم باید عکسی از پشت ببریم تا پشت لباس رو نشون بده..."

    # say L746 sis
    old "Oh right! So what position should I take?"
    new "اوه درسته! پس چه وضعیتی باید بگیرم؟"

    # say L747 pla
    old "Hmm, I think we could use the bed, what about if you lean on the edge of the bed with you back pointing to me in a... Sexy way."
    new "می‌تونی روی اون لبه تخت بنشینی و به طرف من بیایی... به صورت جذاب."

    # say L748 sis
    old "Alright ..."
    new "البته..."

    # say L758 sis
    old "So, do I look good like this?"
    new "پس، من اینجوری خوب به نظر می‌رسم؟"

    # say L759 pla
    old "(Wow) Yeah... You look, great, let me focus on the camera ..."
    new "واو، بله... تو خیلی خوبت، بیای بگم چطور این دوربین رو تنظیم کنم..."

    # say L760 pla
    old "(Oh shit, I'm getting hard. She looks really hot.)"
    new "اوه شیطون، من سخت می‌شوم. تو خیلی جذابی."

    # say L792 pla
    old "(I hope she doesn't notice my hardon...)"
    new "امیدوارم متوجه شدن به سفتی من نشه..."

    # say L795 pla
    old "Ok... I- I think that's enough, for now."
    new "اوه... من فکر می‌کنم کافیه، برای حالا."

    # say L796 sis
    old "What? Just two pics? No, I actually have an idea for a next photo..."
    new "چه کاری؟ فقط دو عکس؟ نه، در واقع یه ایده برای عکس بعدی هم دارم..."

    # say L797 pla
    old "R- really? With a front and backside photo of the dress is not... Enough?"
    new "R- واقعاً؟ با عکس جلو و پشت لباس نمی‌شه... کافی؟"

    # say L798 sis
    old "(Why is he acting so strange.) No, let's take one last photo, ok?"
    new "(چرا همینجور رفتار می‌کنه.) نه، بیاین یه عکس آخر ببریم، خوبه؟"

    # say L800 sis
    old "Let me try something I saw."
    new "بیای چیزی که دیدم رو امتحان کنم."

    # say L813 sis
    old "(Is he ok?, he's walking different) Do you think this looks good?"
    new "(آیا او خوب است؟ او متفاوت مشی دارد) فکر می‌کنی این خوب به نظر می‌رسد؟"

    # say L814 pla
    old "(Shit... I'm so hard right now...)"
    new "شیط... الان خیلی سخت هستم..."

    # say L815 pla
    old "Y- yes, you look great..."
    new "بله، تو خیلی خوب هستی..."

    # say L816 sis
    old "(What he gots there? Ohh! He has a boner. How could I not realize it before?)"
    new "چیه اونجا؟ اوه! یه سفتی داره. چطور می‌تونستم قبلش متوجه نشوم؟"

    # say L817 sis
    old "(Well, I need to let him work, he is very focused, and don't want to make him feel uncomfortable.)"
    new "خب، من باید به او اجازه بدم کارش رو انجام بده، او خیلی متمرکزه و نمی‌خوام باعث ناراحتیش بشه."

    # say L851 sis
    old "Alright, I think that's enough for now..."
    new "البته، فکر کنم الان کافیه..."

    # say L852 pla
    old "Oh, great, so it's done then see you later..."
    new "اوه، عالی، پس تمام شده، ببینم بعداً..."

    # say L856 sis
    old "Wait a minute..."
    new "بیا یه لحظه..."

    # say L858 sis
    old "You said we could check the photos at the end of the session..."
    new "گفتی که می‌تونیم در انتهای جلسه عکس‌ها رو بررسی کنیم..."

    # say L860 pla
    old "You're right..."
    new "درست می‌فرمایی..."

    # say L863 pla
    old "Ok... L- let's see the photos..."
    new "بیا... ل- لبیاس عکس‌ها رو ببینیم..."

    # menu L883 
    old "Watch again"
    new "باز ببینم"

    # menu L887 
    old "Not Again"
    new "نه دوباره"

    # say L900 sis
    old "These photos are out of focus! They look really bad..."
    new "این عکس‌ها خارج از фOCUS هستند! خیلی بد به نظر می‌اند..."

    # say L901 pla
    old "I am sorry, I think I need to practice more."
    new "متاسفم، به نظر می‌رسه باید بیشتر تمرین کنم."

    # say L902 sis
    old "Oh no, this is not good, I wanted to have this material for the website really soon."
    new "اوه نه، این خوب نیست، من می‌خواستم این مطالب رو برای وب‌سایت به زودی آماده کنم."

    # say L903 pla
    old "I can make it better, just need some time."
    new "می‌تونم بهتر کنم، فقط یه کم وقت لازم دارم."

    # say L904 sis
    old "So you need time but a moment ago you were snooping through my personal stuff."
    new "پس تو نیاز به وقت داری اما یه لحظه پیش در چیزهای شخصی من داشتی جاسوسی می‌کردی."

    # say L905 sis
    old "I can't believe it."
    new "باورم نمی‌شه."

    # say L906 pla
    old "I'm sorry, I will practice more."
    new "من خودم هم تمرین خواهم کرد، ببخشید."

    # say L907 sis
    old "All right, take the cam with you, and next time you better do it right."
    new "باشه، دوربین رو با خودت ببر و بار بعد حتماً بهتر انجام بده."

    # say L931 sis
    old "Well, I am not surprised."
    new "خب، من شوک نیستم."

    # say L932 pla
    old "Why, don't you like them?"
    new "چرا، خوشت نمی‌آیند؟"

    # say L933 sis
    old "Yep, I look gorgeous, I mean what could I expect from the 'nerd'."
    new "بله، من خوش‌پوش هستم، منظورم اینه که از «نرد» چه انتظاری داشتم."

    # say L934 pla
    old "I just wanted to help you."
    new "من فقط می‌خواستم به تو کمک کنم."

    # say L935 sis
    old "You did well nerd."
    new "تو خوب کردی، نرد."

    # say L936 sis
    old "I didn't mean they are not good, don't take me the wrong way, I meant I knew it."
    new "من قصد نداشتم بگم خوب نیستن، اشتباه متوجه نشو، من می‌دونستم."

    # say L937 sis
    old "I appreciated it."
    new "ممنون ازت."

    # say L938 sis
    old "Time is money, let me upload this material, I need to sell."
    new "زمان پول هست، برام بگذار این ماده رو آپلود کنم، باید فروشم."

    # say L939 pla
    old "Ok, I guess I'm leaving then."
    new "باشه، به نظر می‌رسه من برم."

    # say L971 sis
    old "Ready to repeat the last photoshoot?"
    new "آماده‌ای برای تکرار آخرین جلسه عکس؟"

    # say L972 pla
    old "Yes, I practiced and I know I'll do better now..."
    new "بله، تمرین کردم و می‌دونم این بار بهتر خواهم کرد..."

    # say L973 sis
    old "You better do it right this time... Don't waste more time. Get ready while I get changed."
    new "باید این بار درستش کنی... وقت بیشتری ضایع نکن. همین حالا آماده شو، من هم برای تغییر لباس می‌روم."

    # say L978 sis
    old "Oh, by the way, do you need some help before we start?"
    new "البته، اگر نیاز داری قبل از شروع کمکت کنم، بگو."

    # say L984 pla
    old "Well... Ok."
    new "خب... خوب."

    # say L985 sis
    old "Hahaha, I'm going to make you cum fast..."
    new "خخخ، من قراره تو رو زود برسونم..."

    # say L995 sis
    old "I'm gonna get changed. You get the camera and stay ready."
    new "من برم تغییر لباس می‌کنم. تو دوربین رو آماده کن و منتظر باش."

    # say L1000 pla
    old "It's ok, I think I will be fine."
    new "خوب، فکر کنم خوب هستم."

    # say L1002 pla
    old "Yes, don't worry. I appreciate your help."
    new "بله، نگران نباش. ممنون از کمکت."

    # say L1003 sis
    old "Perfect! then let's go, we have so much to do!"
    new "عالی! پس برویم، کارهای زیادی داریم!"

    # say L1004 sis
    old "I am excited, I just want to upload the new pics to get more sales!"
    new "من خوشحالم، فقط می‌خوام عکس‌های جدید رو آپلود کنم تا فروش بیشتری داشته باشیم!"

    # say L1033 sis
    old "Alright, let's start! "
    new "باشه، بیایم شروع کنیم!"

    # say L1059 sis
    old "I already know all the positions. You just focus on taking good pictures this time..."
    new "من همه موقعیت‌ها رو بلدی. تو فقط این بار روی گرفتن عکس‌های خوب تمرکز کن."

    # say L1112 pla
    old "Ehmm... Done..."
    new "اوه... انجام شد."

    # say L1113 sis
    old "Alright, next one. You know what to do."
    new "خوب، بعدی. داری می‌دونی باید چی کنی."

    # say L1169 sis
    old "Very well, last one. I hope all the photos are perfect, right?"
    new "خوب، آخری. امیدوارم همه عکس‌ها کامل باشند، درسته؟"

    # say L1170 pla
    old "Yes, don't worry..."
    new "بله، نگران نباش..."

    # say L1223 sis
    old "Ok, let's see the new photos!"
    new "باشه، بیاین عکس‌های جدید رو ببینیم!"

    # say L1281 sis
    old "Really [pla]?! Again out of focus... I can't believe it..."
    new "وای ز[pla]؟! دوباره خارج از تمرکز... باور نمی‌کنم..."

    # say L1282 pla
    old "I-it wasn't my fault, I really tried to improve..."
    new "من قصد نداشتم، واقعاً سعی کردم بهتر کنم..."

    # say L1283 sis
    old "Well, it wasn't enough... And you are making me lose money!"
    new "خب، این کافی نبود... و تو داری مجبور می‌کنی من پول ببرم."

    # say L1284 sis
    old "Get out... Come back when you learn to use that damn camera..."
    new "برو بیرون... وقتی یاد گرفتی از اون دوربین شیطونی استفاده کنی بیا برگرد..."

    # say L1317 sis
    old "Well, finally! These photos are great."
    new "خب، در نهایت! این عکس‌ها عالی هستند."

    # say L1318 sis
    old "I hope next time we don't have to do the photoshoot twice again..."
    new "امیدوارم بار بعد نباید دوباره عکسبرداری کنیم..."

    # say L1319 pla
    old "Don't worry..."
    new "نگران نباش..."

    # say L1320 sis
    old "Hmm... Time is money, let me upload this material, I need to sell."
    new "Hmm... وقت از پول ساخته شده، باید این ماده رو آپلود کنم، من باید فروشم."

    # say L1321 pla
    old "Ok, leaving now."
    new "باشه، حالا می‌رم."

    # say L1395 pla
    old "(Holy shit! If I get caught she'll kill me!)"
    new "شیطان! اگه متوجه شه من رو می‌کشه!"

    # say L1398 sis
    old "Hey, big boy. Do you need some help?"
    new "هی، بزرگ‌پسر. نیاز به کمکی داری؟"

    # say L1407 pla
    old "Oh, god. Thanks. If she would have caught me, I'd be a goner."
    new "اوه خدا. ممنون. اگه او منو بگیره، من خلاص بودم."

    # say L1408 sis
    old "It's ok! you are saved now, just relax."
    new "باشه! حالا آرامش داشت، خلاصی."

    # say L1409 pla
    old "Yes, I appreciate it, you saved my ass."
    new "بله، ممنونم، تو من رو نجات دادی."

    # say L1410 sis
    old "I feel thankful too, last time you were great with the pics."
    new "من هم ممنونم، آخر بار عکس‌ها رو خیلی خوب گرفتی."

    # say L1411 sis
    old "Haven't given you a proper reward."
    new "هنوز به تو جایزه‌ای مناسب ندادم."

    # say L1412 pla
    old "Wh- What... Do you mean?"
    new "چ- چه قصه‌ای؟"

    # say L1413 sis
    old "What I mean is... Take off those pants and show me that dick."
    new "من قصد دارم بگم... لباس پایینتو ببرو و اون نیمرو به من نشون بده."

    # say L1414 pla
    old "Oh, come on, [sis]..."
    new "اوه، بیا ز[sis]..."

    # say L1415 sis
    old "Just do it... Your [mo2rel] is close. And you don't want me to call her..."
    new "بزن این کار رو... ز[mo2rel]ت نزدیکه. و نمی‌خوای من اونا رو صدا بزنم..."

    # say L1416 pla
    old "Really?… Ugh... Ok."
    new "وای، خوب… اوه… موافقم."

    # say L1423 sis
    old "I knew it! It's fucking huge..."
    new "میدونستم! خیلی بزرگه..."

    # say L1425 sis
    old "Just let me turn on the lights to get a better look at it."
    new "فقط بگذار من نور رو روشن کنم تا بهتر ببینمش."

    # say L1444 sis
    old "Hey buddy, guess what?"
    new "بچه خوب، حدس زدی؟"

    # say L1446 sis
    old "Your idea was a big noise, it pulled off selling!"
    new "ایده‌تو خیلی خوب بود، به فروش رسید!"

    # say L1448 sis
    old "Yep, come to my bedroom I need your help with something..."
    new "بله، بیا به اتاق خوابم، باید به چیزی کمکت کنم..."

    # say L1455 sis
    old "Well, besides the messages I have now. We actually got a new customer, she was pretty interested in the last pics we did, remember?"
    new "البته، علاوه بر پیام‌هایی که الان دارم. در واقع مشتری جدیدی به ما پیوست، او خیلی به آخرین عکس‌هایی که گرفتیم علاقه‌مند بود، به یاد داری؟"

    # say L1456 pla
    old "Yeah! I know which ones."
    new "بله! می‌دونم کدوم‌ها هستند."

    # say L1457 sis
    old "Anyway, I need your help now, we have several customers' messages."
    new "البته، حالا نیاز به کمکت دارم، چند پیام از مشتریان دریافت کرده‌ایم."

    # say L1458 sis
    old "I'll need to answer them as some of them are very potential purchases."
    new "باید به این پیام‌ها جواب بدم، چون بعضی از آنها خرید‌های خوبی هستند."

    # say L1459 sis
    old "Need you to take one package to a customer."
    new "باید یک بسته رو به یک مشتری ببری."

    # say L1460 pla
    old "You mean today?"
    new "منظورت الان هست؟"

    # say L1461 sis
    old "Oh no, I mean right now."
    new "نه، منظورم الان هست."

    # say L1462 pla
    old "I am kind of busy now."
    new "من الان یه کمی مشغول هستم."

    # say L1463 sis
    old "That's not a business wise decision."
    new "این تصمیم از نظر تجاری خوب نیست."

    # say L1465 sis
    old "You know this is not actually a favor, it's included in the money you are expecting."
    new "میدونی این واقعاً یه لطف نیست، این توی پولی که انتظار داری در می‌آد."

    # say L1466 pla
    old "Hmm... I know, but I can't do it right away... We never discussed these kind of things."
    new "Hmm... می‌دونم، ولی الان نمی‌تونم انجام بدم... هیچ وقت این جوری چیزی بین ما بررسی نشده."

    # say L1467 sis
    old "Yes, I know but we have to be committed to make this business grow."
    new "بله، می‌دونم، اما باید وفادار باشیم تا این کسب و کار رشد کنه."

    # say L1468 pla
    old "Come on, almost everybody knows about me here in town, it's not comfortable."
    new "بیا، تقریباً همه اینجا در شهر در مورد من مطلع هستن، راحت نیست."

    # say L1469 pla
    old "I don't want to be embarrassed delivering sexy panties to a classmate's mother."
    new "من نمی‌خوام خجولی لباس داخلی جنسی به مادر همکلاسی‌هام برسونم."

    # say L1470 sis
    old "Why would you be embarrassed, it isn't like you're the one wearing it."
    new "چرا خجول می‌شی، نه مثل اینکه تو هستی که پوشونی."

    # say L1471 sis
    old "Here is the thing, do you still wanna be helped like the other night?"
    new "این همینه، هنوز می‌خوای مثل آن شب کمکت کنم؟"

    # say L1472 sis
    old "So, think about the 'business', if you help me I'll help you. I think my help is amazing, don't you like it?"
    new "پس، در مورد کار فکر کن، اگر تو مرا کمک کنی من هم تو رو کمک می‌کنم. فکر می‌کنم کمک من عالیه، آیا می‌پسندی؟"

    # say L1473 pla
    old "Hmm... Fine, but don't take me wrong, It's for business!"
    new "Hmm... خوب، ولی اشتباه نگیر، این برای کاره!"

    # say L1474 sis
    old "Hehehe, yeah sure! The business..."
    new "خخخ، بله مطمئن! کاری..."

    # say L1475 sis
    old "You will find all the info you need on the package."
    new "همه اطلاعاتی که نیاز داری رو توی بسته پیدا می‌کنی."

    # say L1477 pla
    old "Hmm alright..."
    new "Hmm خب..."

    # say L1482 pla
    old "I think it's here... I hope it's not someone I know."
    new "فکر کنم اینجا هست... امیدوارم نباشه کسی که بشناخته‌ام."

    # say L1485 jon
    old "Yes, sir, how can I help you?"
    new "بله، آقای جونز، چطور می‌توانم به شما کمک کنم؟"

    # say L1486 pla
    old "(For real? Is she wearing this?)"
    new "وای، این لباس رو می‌پوشه؟"

    # say L1487 pla
    old "Hmmm, I think this package is for you."
    new "Hmmm، فکر کنم این بسته برای تو هست."

    # say L1488 jon
    old "(Wow! I know this young man, I met him in church.) "
    new "واو! این جوان را می‌شناسم، در کلیسا با او ملاقات کردم."

    # say L1489 jon
    old "For me?"
    new "برای من؟"

    # say L1490 pla
    old "Yes, we had your order record, let me confirm, it is the Ultra short skirt, marvelous night surprise dress."
    new "بله، رکورد سفارشت رو داشتیم، بیای ببین، لباس مدل روز، مفاجآت شب شگفت‌انگیز."

    # say L1491 jon
    old "... What? This must be a mistake."
    new "چه؟ این حتماً اشتباهی هست."

    # say L1492 pla
    old "(Of course is yours, who else could be, has your name on it.)"
    new "البته این مربوط به توست، چه کسی می‌تونست بود، اسم تو رو داره."

    # say L1493 pla
    old "It could be, however, you're Mrs. Jones, right?"
    new "می‌تونه باشه، ولی تو خانم جونز هستی، درسته؟"

    # say L1494 jon
    old "Yes, that's me..."
    new "بله، من هستم..."

    # say L1495 pla
    old "Well, we have all your information here, and the payment was done online... So..."
    new "خب، اطلاعاتت رو همه اینجا داریم، و پرداخت هم آنلاین انجام شده... پس..."

    # say L1496 jon
    old "(Hmm... I need to make up something, he knows me...)"
    new "خوب... باید چیزی بسازم، او از من آگاهه..."

    # say L1497 jon
    old "Oh! I remembered now, this is for my daughter, I forgot completely, hehehe."
    new "اوه! حالا به یادم اومد، این برای دخترم هست، کاملاً فراموش کرده بودم، هه هه هه."

    # say L1498 pla
    old "Hmm... It's ok, I understand, hope you daughter likes it."
    new "Hmm... خوبه، من متوجه شدم، امیدوارم دخترت هم لذت ببره."

    # say L1503 jon
    old "Ok... Thank you! Bye bye."
    new "خوب... ممنون! خداحافظ."

    # say L1511 pla
    old "It's done!"
    new "خوب شد!"

    # say L1512 sis
    old "Awesome, What happened? I wanna know everything."
    new "عالی، چه اتفاقی افتاد؟ من همه چیز رو می‌خوام بدونم."

    # say L1513 pla
    old "It was ok, gave her the package, that was it."
    new "خوب بود، بسته رو بهش دادم، همین بود."

    # say L1514 sis
    old "Was she excited about the purchase?"
    new "آیا از خرید خوشحال شد؟"

    # say L1515 pla
    old "Couldn't tell you, she was kind of reserved."
    new "نمی‌تونم بگم، چندان محتشم بود."

    # say L1516 sis
    old "Did you see if she liked it?"
    new "دیدی که لب خورده بود؟"

    # say L1517 pla
    old "No, I just gave her the package and she said thank you."
    new "نه، فقط بسته رو بهش دادم و ممنون شد."

    # say L1518 sis
    old "I need you to pay careful attention to those details in future deliveries. "
    new "باید در تحویل‌های بعدی به این جزئیات توجه کنی."

    # say L1519 pla
    old "What do you mean by future deliveries?"
    new "منظورت از تحویل‌های آینده چیه؟"

    # say L1520 sis
    old "I have more merchandise coming so get prepare for another photoshoot session. "
    new "من کالاهای بیشتری دارم که می‌آیند پس برای جلسه عکس‌برداری بعدی آماده شو."

    # say L1521 pla
    old "Hmm... All right."
    new "Hmm... خب."

    # say L1522 sis
    old "Now leave me alone. It's late and I have a lot to do... "
    new "حالا برو برام آرام بده. وقت شده و کار زیادی دارم..."

    # say L1544 sis
    old "Hey!, You won't believe the great news I have, I am so excited, this is working really well."
    new "ای، شنیدی؟ خبر خوبی دارم، هیجان زده‌ام، اینا واقعاً خوب می‌رود."

    # say L1545 sis
    old "We have a new customer, she ordered almost the entire website catalogue."
    new "ما مشتری جدیدی داریم، او تقریباً تمام کاتالوگ وب‌سایت رو سفارش داده."

    # say L1546 pla
    old "Wow, that's great!"
    new "واو، خوبه!"

    # say L1547 sis
    old "The order already went through, soooo... I need your help!"
    new "سفارش قطع نشده، پس... به من کمکت لازم است!"

    # say L1548 pla
    old "Let me guess, you want me to make the delivery?"
    new "بگو ببین، می‌خوای از من برم ارسال کنم؟"

    # say L1549 sis
    old "Yes, but if you go right now, you won't have to do it later, huh?"
    new "بله، اما اگه حالا بروی، بعدش نمی‌تونی بگی نکردم، هه؟"

    # say L1550 pla
    old "Well, it's still me doing the delivery!"
    new "خب، همچنان من هستم که این تحویل رو می‌دم!"

    # say L1551 sis
    old "I love how engaged you are, this is why we are growing and growing!"
    new "عشق کردن به این همتت، همین به ما کمک می‌کنه تا روز به روز بزرگتر شیم!"

    # say L1552 pla
    old "Hmm, alright, I'll do the damn delivery... "
    new "Hmm، خوب، انجام می‌دم این تحویل شیطون..."

    # say L1553 sis
    old "Hahaha remember is for the ‘business'."
    new "حاحاحا، به خاطر کسب و کار هست."

    # say L1555 sis
    old "Alright, let me know when it's done, see you later."
    new "ببین، وقتی تمام شد به من بگو، بعداً می‌بینیم."

    # say L1558 pla
    old "(Hmmm I hope it isn't anyone I know like last time.)"
    new "Hmm امیدوارم این بار کسی از آشنای من نباشد مثل آخرین بار."

    # say L1562 pla
    old "(Alright, is here...)"
    new "(ببین، اینجا هستم...)"

    # say L1564 ana
    old "Good morning, how can I help you?"
    new "صبح خیر، چطور می‌تونم به تو کمک کنم؟"

    # say L1567 pla
    old "G-good morning, Mrs. Anastasia? Here is your package!"
    new "صبح خوب، خانم آناستازیا؟ این بسته شماست!"

    # say L1568 ana
    old "Oh, Thank you so much! So? Are you the business guy behind this?"
    new "اوه، ممنونم! پس؟ آیا تو هستی مرد کسب و کار این؟"

    # say L1569 pla
    old "Oh no, this is my [sisrel] business, I'm just helping."
    new "نه، این کسب و کار [sisrel]ه، من فقط کمک می‌کنم."

    # say L1570 ana
    old "That's so sweet, She is very lucky to have a handsome young man like you helping."
    new "این خیلی شیرینه، او برای داشتن یک جوان و زیباپوش مثل تو خیلی شانس داره."

    # say L1571 pla
    old "Thanks... We are trying to get some extra income."
    new "ممنون... ما سعی می‌کنیم درآمد بیشتری بدست بیاوریم."

    # say L1574 ana
    old "I like your products, surely I will look forward to knowing more about you guys."
    new "محصولاتت رو دوست دارم، قطعاً منتظر می‌شوم که بیشتر با شما آشنا شوم."

    # say L1575 ana
    old "Specially you, sweety."
    new "به خصوص تو، عزیزم."

    # say L1576 pla
    old "Hmmm... T-thanks."
    new "Hmm... ممنون."

    # say L1577 ana
    old "My pleasure, see you later sweetheart..."
    new "لذت من بود، بعداً دوست من..."

    # say L1579 pla
    old "(What a nice lady.)"
    new "خوب، یه خانم خوشحال کننده بود."

    # say L1585 pla
    old "Well, I am back."
    new "خب، من برگشتم."

    # say L1586 sis
    old "How was it? I'm kind of busy, but let me know everything."
    new "چطور بود؟ من یه کم مشغولم، ولی همه چی رو به من بگو."

    # say L1587 pla
    old "She was very interested in the clothes."
    new "او خیلی به لباس‌ها علاقه داشت."

    # say L1588 sis
    old "Great, what did you tell her?"
    new "عالی، چه چیزهایی بهش گفتی؟"

    # say L1589 pla
    old "The common stuff, you know, I said hello, the information of the delivery."
    new "معمولی، می‌دونی، سلام گفتم، اطلاعات تحویل رو هم دادم."

    # say L1590 pla
    old "She mentioned she will order more."
    new "او گفت که بیشتر سفارش خواهد داد."

    # say L1591 sis
    old "Fantastic, I will need your help next time, so she feels engaged with the purchase."
    new "عالی، باید تو بعداً کمکم کنی تا از خریدش خوشحال بشه."

    # say L1592 sis
    old "Let me continue... I have more and more customers messaging."
    new "بیای دوباره... مشتری‌هام هر بار بیشتر می‌شوند."

    # say L1595 pla
    old "Sure, you are very welcome!"
    new "بله، خوشحالم که کمکت کردم!"

    # say L1615 sis
    old "You ready for the pics? I've been waiting for you."
    new "آماده‌ای برای عکس‌ها؟ منتظرت بودم."

    # say L1616 pla
    old "Oh right, I'm going for the camera, I'll see you in your bedroom."
    new "اوه درسته، من برای دوربین می‌روم، تو رو تو اتاق خوابت می‌بینم."

    # say L1624 pla
    old "(Holy shit!)"
    new "هیولایی!"

    # say L1625 sis
    old "Finally, I have good ideas for today's session."
    new "در نهایت، ایده‌های خوبی برای جلسه‌ی امروز دارم."

    # say L1626 sis
    old "What do you think? Do I look beautiful?"
    new "فکرت چیه؟ آیا من زیبا به نظر می‌رسم؟"

    # say L1627 pla
    old "Gulp... (Wow, she is really hot) I think you look very... N-nice."
    new "گلوله... (واو، واقعاً خوبه) فکر کنم خیلی... ن-نیکویی می‌تونی."

    # say L1628 sis
    old "Great... But, before we start do you think, you need any... Help?"
    new "عالی... اما قبل از شروع، فکر می‌کنی نیاز داری به هیچ... کمکی؟"

    # say L1629 pla
    old "What do you mean? I have the camera and everything..."
    new "من چی قصد داری؟ کامرا و همه چیز رو دارم..."

    # say L1630 sis
    old "I mean if you need to 'relax' before we start..."
    new "من قصد دارم بگم اگر قبل از شروع نیاز داری که آرام شوی..."

    # say L1631 pla
    old "I-I don't understand..."
    new "من-من نمی‌فهمم..."

    # say L1632 sis
    old "I mean, don't be flushed I know you got hard last time and is totally normal..."
    new "من قصد دارم بگم، نباید خجالت زدی، میدونم آخر هم سخت شدی و این کاملاً طبیعیه..."

    # say L1634 sis
    old "It's because of the clothes I'm wearing, I think it's fair, you know, you help me, I can help you too and I already did, didn't I?"
    new "این به خاطر لباس‌هامونه، فکر کنم عادلانه هست، می‌دونی، تو می‌تونی به من کمک کنی و من هم به تو کمک کردم، درسته؟"

    # say L1635 pla
    old "I'm not sure if it's okay..."
    new "مطمئن نیستم اگه خوبه..."

    # say L1636 sis
    old "Oh come on, you're not going to take good pictures if you're hard the whole session..."
    new "بیا بفرمای، نمی‌تونی عکس‌های خوب ببری اگه طولانی‌مدت سخت باشی..."

    # say L1637 sis
    old "It's because of business, remember?"
    new "به خاطر کاره، به یادت باشه."

    # say L1639 sis
    old "Great, take off your pants I'm going to suck you off..."
    new "عالی، لباس پایینتو ببردار من می‌خوام از تو بکشونم..."

    # say L1640 pla
    old "W-WHAT?! Are you going to suck-..."
    new "و-وای! می‌خوای از من..."

    # say L1641 sis
    old "Well... You did a great job with the deliveries, I think you deserve a reward, don't you think?"
    new "خب... تو خوب کار کردی با تحویل‌ها، فکر می‌کنم یه جایزه رو احقاقی کردی، نه؟"

    # say L1643 sis
    old "By the way, I'll have to take off my clothes, just to be sure I don't stain the clothes for the photos..."
    new "البته، باید لباس‌هام رو برمی‌دم، فقط برای اینکه مطمئن شم لباس‌ها برای عکس‌ها خراب نمی‌شن..."

    # say L1644 sis
    old "Does it bother you?"
    new "آیا این به تو اشکال می‌ده؟"

    # say L1646 sis
    old "Hahaha you will love it..."
    new "حاحاحا، خوشت می‌آید..."

    # say L1663 sis
    old "I hope you are relaxed now, so let's do it!"
    new "امیدوارم حالا آرام شده‌ای، پس بیایم انجام بدیم!"

    # say L1678 sis
    old "You think this way it looks good?"
    new "فکر می‌کنی اینجوری خوبه؟"

    # say L1679 pla
    old "Absolutely."
    new "حتماً."

    # say L1680 pla
    old "Let me be sure the skirt stands out. I will take a pic of entire clothes."
    new "بیای دیدن که لباس کوتاه به خوبی دیده می‌شه. من عکس کل لباست می‌برم."

    # say L1715 pla
    old "Yes, let's do the next one from another position."
    new "بله، بیای بگیریم از زاویه‌ای دیگر."

    # say L1716 sis
    old "Great! I saw one I want to try."
    new "عالی! یکی هست که می‌خوام امتحانش کنم."

    # say L1717 pla
    old "Sure, what do you have on mind?"
    new "بله، چه چیزی به ذهن تو برده؟"

    # say L1718 sis
    old "I want to take some pics on the bed."
    new "می‌خوام چند عکس روی تخت ببرم."

    # say L1719 pla
    old "Well, we haven't done anything like that before. Let's do it!"
    new "خب، قبلاً هیچی مثل این نکردیم. بیای بکنیم!"

    # say L1720 pla
    old "Lay down on the bed but leave the legs out of the bed so we can see your butt."
    new "روی تخت بخواب ولی پاشون رو از تخت بیرون بگذار تا پشتت بیاد بینی."

    # say L1721 sis
    old "Nicee."
    new "خوبه."

    # say L1731 sis
    old "I hope it looks sexy."
    new "امیدوارم جذاب بیاد."

    # say L1732 pla
    old "(Holy shit...) I-I am sure you're gonna love these."
    new "(شیطون...) مطمئنم که اینا رو دوست داری."

    # say L1733 pla
    old "But let me try to catch a bit more, your legs must look huge."
    new "ولی بیای بیشتری بگیرم، لابهلا این پاها باید خیلی بزرگ بیاندازند."

    # say L1759 pla
    old "I think I have it."
    new "فکر کنم گرفتم."

    # say L1768 pla
    old "Ok, for the next picture I need you to turn around please, I want to try an option like the last time but slightly different."
    new "باشه، برای عکس بعدی لطفاً بگردی، می‌خوام یه گزینه‌ای مثل آخر بپرزم اما کمی متفاوت."

    # say L1769 pla
    old "Do not look at the camera and try to lift a bit more your butt, hold your hair with one hand."
    new "به دور دوربین نگاه نکن و بیشتر پاشو بلند کن، با یه دست موت رو بگیر."

    # say L1770 sis
    old "Ohh, I like it!"
    new "اوه، خوشم اومده!"

    # say L1781 pla
    old "It's perfect."
    new "این هم کامل شد."

    # say L1806 pla
    old "Ok, I think we are done."
    new "باشه، فکر کنم تمام شد."

    # say L1814 sis
    old "Awesome!!! Let me see them!"
    new "عالی!!! برام نشون بده!"

    # say L1819 pla
    old "Ok... Gallery... Done"
    new "خب... گالری... تمام شد"

    # say L1854 pla
    old "I do not know what's happening today, these photos are not sharp enough."
    new "نمی‌دونم امروز چه کاری اومده، این عکس‌ها خوب نیستند."

    # say L1855 sis
    old "We will need to try again, this material is important. "
    new "باید دوباره امتحان کنیم، این ماده مهمه."

    # say L1856 pla
    old "Yes, I am sure we can make it a lot better."
    new "بله، مطمئنم می‌تونیم خیلی بهتر کنیم."

    # say L1857 pla
    old "I just need to practice more."
    new "من باید بیشتر تمرین کنم."

    # say L1858 sis
    old "I need you to put more effort, we can't keep wasting time like this."
    new "تو باید بیشتر تلاش کنی، نمی‌تونیم همینجوری وقت رو بیخیال کنیم."

    # say L1859 pla
    old "It won't happen again!"
    new "دیگه اینجوری نمی‌شه!"

    # say L1884 sis
    old "Wow, we're on fire!"
    new "وای، ما آتش داریم!"

    # say L1885 sis
    old "Look at me, so hot. I like your job and I'm not talking about the pics only."
    new "ببینم، خیلی داغ هستم. دوست دارم کارت رو می‌شناسم و من فقط در مورد عکس‌ها صحبت نمی‌کنم."

    # say L1886 pla
    old "We are doing a great job."
    new "ما کار خوبی انجام می‌دهیم."

    # say L1887 sis
    old "Yes, everyday I have more customers, you're a big help."
    new "بله، هر روز مشتری‌های بیشتری دارم، تو کمک زیادی می‌کنی."

    # say L1888 sis
    old "I will go ahead to upload this content on the website."
    new "من برم این محتوا رو توی وب‌سایت بارگذاری کنم."

    # say L1889 pla
    old "Ok, bye."
    new "باشه، خداحافظ."

    # say L1910 sis
    old "Hey, now that you are here, do you remember Mrs Anastasia? Well, she placed another order, it was mostly the last ones we took pics of!"
    new "ببین، حالا که تو اینجا هستی، به خاطر داری آناستازیا رو؟ خوب، او دوباره سفارش داده، بیشترش عکس‌های آخری بودن که گرفتیم!"

    # say L1911 sis
    old "Need you to be really nice with her, I'm sure, she will buy anything we post later!"
    new "باید باهاش خیلی خوش باشی، مطمئنم هر چی بعداً قراره بگذاریم، می‌خره!"

    # say L1912 sis
    old "So you better give her amazing customer service, don't want you to mess things up with her."
    new "پس بهتره خدمت بهش عالی باشه، نمی‌خوایم باهاش مشکلی بیفته."

    # say L1913 pla
    old "Ok... I'll go right away."
    new "باشه... همین الان می‌رم."

    # say L1914 sis
    old "Don't forget to be really kind, she is a very important client."
    new "فراموش نکن خیلی لطف داشته باش، او مشتری بسیار مهمی هست."

    # say L1916 pla
    old "Yes, yes, I know!"
    new "بله، بله، میدونم!"

    # say L1922 pla
    old "Good morning Mrs, I have another package for you!"
    new "صبح بخیر خانم، بسته‌ای دیگر برای شما دارم!"

    # say L1923 ana
    old "Oh, it's you again, you came really fast, Thank you very much!"
    new "اوه، دوباره تو هستی، خیلی زود آمدی، ممنون بسیار!"

    # say L1924 pla
    old "We really appreciate your purchase."
    new "ما واقعاً از خریدت ممنونیم."

    # say L1925 ana
    old "I do appreciate how much of a gentleman you are."
    new "من واقعاً از اینکه چقدر شما آقای شرافت هستید خوشحال می‌شوم."

    # say L1926 pla
    old "Hmmm, thank you... Uhh this is your package."
    new "Hmm، ممنون... اوه این بسته‌تو هست."

    # say L1927 ana
    old "Thank you sweety!"
    new "ممنون عزیزم!"

    # say L1932 ana
    old "You know what? you deserve a tip."
    new "می‌دونی چی؟ تو حق هدیه‌ای داری."

    # say L1933 pla
    old "Oh please don't worry..."
    new "لطفاً نگران نباش..."

    # say L1934 ana
    old "Give me just a second, your kindness deserves compensation."
    new "بیا یه لحظه صبر کن، لطفت جایزه دست کرد."

    # say L1935 pla
    old "It's not necessary, I am very glad to bring your package."
    new "الزامی نیست، خیلی خوشحالم که بسته‌تو آوردم."

    # say L1936 ana
    old "Do not dare to leave!"
    new "درباره رفتن از اینجا فکر نکن!"

    # say L1948 ana
    old "I beg your pardon... Can't find my purse."
    new "ببخشید... کیفم رو پیدا نکردم."

    # say L1949 pla
    old "Do not worry, it's not a problem."
    new "نگران نباش، مشکلی نداره."

    # say L1950 ana
    old "Oh no, you deserve it."
    new "اوه نه، تو این را ارزش داری."

    # say L1951 ana
    old "Let me see if I could have something here... Hope you like it."
    new "ببینم اگه چیزی اینجا دارم... امیدوارم لایقش باشه."

    # say L1953 pla
    old "(Wow) ..."
    new "واو..."

    # say L1954 ana
    old "(He's so shy... Hehehe, can't even speak.)"
    new "(تو همینجور خجالتی هستی... هههه، حتی نمی‌تونی حرف بزنی.)"

    # say L1955 pla
    old "Gulp, tha-... Thank you."
    new "گulp، tha-... ممنون."

    # say L1957 ana
    old "Hehehe, You are kind of tender."
    new "هههه، تو خیلی لطیفی."

    # say L1958 ana
    old "I hope I can see you next time, I'll have cash handy. Bye handsome!"
    new "امیدوارم برات وقت بعد هم ببینم، بارو پول هم خواهم آورد. بای حسون!"

    # say L1966 sis
    old "Was everything alright?"
    new "همه چیز خوب بود؟"

    # say L1967 pla
    old "Definitely, she is amazing!"
    new "حتماً، او عالیه!"

    # say L1968 sis
    old "(Amazing?) Hmm ok, thank you!"
    new "(عالی؟) هم‌اک، ممنون!"

    # say L1969 sis
    old "Does she like the products."
    new "آیا او محصولات رو دوست داره؟"

    # say L1970 pla
    old "She seemed to be very interested about the new products."
    new "به نظر می‌رسه به محصولات جدید خیلی علاقه‌مند بود."

    # say L1971 sis
    old "That's fascinating."
    new "این جالب است."

    # say L1972 sis
    old "Hope you are doing your part, so she definitely keeps her business with us."
    new "امیدوارم تو هم کارتو انجام بدی تا او قطعاً با ما همکاری کنه."

    # say L1974 sis
    old "Besides, I need you to get prepared, we have more products coming."
    new "البته، باید آماده شوی، ما محصولات بیشتری داریم."

    # say L1976 sis
    old "Yes, we need to work hard."
    new "بله، باید سخت کار کنیم."

    # say L1977 pla
    old "Uhh, let's see what happens."
    new "ببینیم چه می‌شه."

    # say L1978 sis
    old "You can be sure it's worth."
    new "می‌تونی مطمئن باشی، ارزشش هست."

    # say L2002 sis
    old "Come on [pla]! Time is money and you're late, let's go to the pool."
    new "بیا ز[pla]! وقت پوله و تو دیری، برویم به استخر."

    # say L2003 pla
    old "To the p-pool?"
    new "به استخر؟"

    # say L2004 sis
    old "Yep, the pool. Summer is coming, bikinis are amazing so I need all your effort today."
    new "بله، به استخر. تابستان آماده است، بیکینی‌ها عالی هستند پس امروز نیاز به تمام تلاشت دارم."

    # say L2005 sis
    old "We are selling new things and people are crazy with the new summer alternatives."
    new "ما چیزهای جدیدی می‌فروشیم و مردم از جایگزین‌های تابستانی خیلی خرسند شده‌اند."

    # say L2007 sis
    old "Do you need some help before we start?"
    new "قبل از شروع کمکی می‌خوای؟"

    # say L2009 sis
    old "I mean do you want me to suck your dick, because at the pool it's not that easy. "
    new "من قصد دارم اینجوری بگم که آیا می‌خوای اون جاش رو شیرت بدم، چون در بассین خیلی راحت نیست."

    # say L2010 sis
    old "And don't beat around the bush!"
    new "و نه بگویی اومدی!"

    # say L2016 pla
    old "I-I am not sure."
    new "من-من مطمئن نیستم."

    # say L2017 sis
    old "Do you want it or not?"
    new "می‌خوایش یا نه؟"

    # say L2019 sis
    old "We don't have time to lose I will take it as a yes..."
    new "ما وقت زیادی نداریم، پس باید بله بگی..."

    # say L2020 sis
    old "I'm going to make you cum fast..."
    new "من قراره تو رو زود سر خوش شو..."

    # say L2044 sis
    old "I hope you're better now, let's do it!"
    new "امیدوارم حالت بهتر شده باشه، بیای بزنیم!"

    # say L2052 sis
    old "Oh, I will love the pics today, look at the sun, the pool, everything in its right place."
    new "اوه، عکس‌های امروز رو دوست خواهم داشت، نگاه کن به آفتاب، به استخر، همه چیز در جای خودش."

    # say L2053 pla
    old "Yeah I couldn't ask for a better light and place."
    new "بله، نور و مکان بهتر از این نمی‌تونه باشه."

    # say L2054 sis
    old "Don't lose more time, let's start."
    new "بیشتر وقت رو از دست نده، بیاین شروع کنیم."

    # say L2055 pla
    old "You're right. Stay right there, let me start with a full body!"
    new "درست می‌فرمایی. اینجا بمان، بیایم از کل بدن شروع کنم!"

    # say L2056 sis
    old "Ok, I will stay like this."
    new "باشه، من همینجور می‌مونم."

    # say L2057 pla
    old "I think you should look to the right, to get a better perspective..."
    new "فکر می‌کنم باید به سمت راست نگاه کنی، برای یک زاویه بهتر..."

    # say L2058 sis
    old "Alright, you are the nerd..."
    new "البته، تو هستی نرد..."

    # say L2073 pla
    old "Wonderful, the light is perfect, your hair looks very bright."
    new "عالی، نور کاملاً مناسبه، موت خیلی روشن می‌تونه بیاد."

    # say L2074 sis
    old "Perfect, make sure I look sexy."
    new "عالی، حتماً باید جذاب بیام."

    # say L2102 pla
    old "Got it!"
    new "فهمیدم!"

    # say L2111 pla
    old "It would be more interesting if we take advantage of some elements of the place."
    new "این جالب‌تر می‌شد اگه از عناصر مکان استفاده کنیم."

    # say L2112 sis
    old "Hmmm, what do you think about the pool?"
    new "حتماً، اما درباره استخر چطور می‌تونیم استفاده کنیم؟"

    # say L2113 pla
    old "I don't think so, we need the clothes dry."
    new "من فکر نمی‌کنم، لازم هست لباس‌هامون خشک شن."

    # say L2114 pla
    old "You now what? Go to the chair, something casual, let's use those glasses you have."
    new "برو به صندلی، چیزی آرام، بیایم از آونگ‌هایت استفاده کنیم."

    # say L2115 sis
    old "Yes, just like that, that's perfect."
    new "بله، همینطور، این خیلی خوبه."

    # say L2126 pla
    old "Perfect, try to hold the glasses with your hands."
    new "عالی، سعی کن با دستت نظارات رو بگیری."

    # say L2127 sis
    old "Try to show my boobs a bit more, I want them to stand out."
    new "سعی کن بیشتر سینام رو نشون بده، می‌خوام برجسته باشن."

    # say L2128 pla
    old "I think this is the pic you're looking for."
    new "فکر کنم این عکسیه که دنبالش می‌گردی."

    # say L2153 pla
    old "Ok, next photo..."
    new "باشه، عکس بعدی..."

    # say L2161 pla
    old "I have a great idea, let's show a different emotion."
    new "ایده خوبی دارم، بیای حالت دیگه‌ای نشون بدیم."

    # say L2162 sis
    old "I am listening..."
    new "من گوش می‌دم..."

    # say L2163 pla
    old "Let's take advantage of the pool but I don't want the same poses we already tried before, I want to do something unexpected."
    new "بیای بیشتر از استخر استفاده کنیم، ولی نمی‌خوام همون پوز‌هایی که قبلاً امتحان کردیم رو بزنیم، می‌خوام چیزی غیرمنتظره بکنم."

    # say L2164 pla
    old "Hmm, turn around and try to look at me, but close your eyes..."
    new "هم، بگرد و سعی کن به من نگاه کنی، اما چشماتو ببند..."

    # say L2165 sis
    old "With my eyes closed? Alright, let me try it."
    new "با چشمان بسته؟ خب، بیایم امتحان کنم."

    # say L2176 pla
    old "keep that smile, do not change your face."
    new "با اون لبخند، صبر کن، چه خوبه."

    # say L2177 pla
    old "That's a plot twist."
    new "این یه تغییر داستانیه."

    # say L2178 pla
    old "I like it."
    new "من دوست دارم."

    # say L2202 pla
    old "Ok, I think that's it."
    new "باشه، فکر کنم اینجاست."

    # say L2214 pla
    old "Ok... Here they are."
    new "خب... اینا هستند."

    # say L2247 pla
    old "I don't know what's happening today, they are not sharp enough."
    new "نمی‌دونم امروز چه قدره، خیلی تیز نیستن."

    # say L2251 sis
    old "I need you to put more effort, we can't waste time like today."
    new "تو باید بیشتر تلاش کنی، نمی‌تونیم مثل امروز وقت رو ضایع کنیم."

    # say L2253 sis
    old "Hmm, look for me to repeat the sesion again..."
    new "Hmm، ببین برایم این جلسه رو دوباره تکرار کن..."

    # say L2276 sis
    old "I like them, but there's something not working."
    new "من دوستشون دارم، اما چیزی درست نیست."

    # say L2277 pla
    old "What's not working? I can check, so you like them more."
    new "چی کار نمی‌کنه؟ من می‌تونم بررسی کنم، براحتون بیشتر لذت ببرید."

    # say L2278 sis
    old "Oh no, it's not you, I need some sunbathing."
    new "نه، این مشکل از تو نیست، من نیاز به آفتاب‌زدن دارم."

    # say L2279 sis
    old "Don't you think so?"
    new "می‌thonی اینجوری نیست؟"

    # say L2280 pla
    old "I think you look great."
    new "من فکر می‌کنم تو خیلی خوب هستی."

    # say L2281 sis
    old "Hehehe of course... "
    new "هههه البته..."

    # say L2282 sis
    old "Anyway, I'm going work on the website, have a good one."
    new "بازم، من می‌روم کار وب‌سایت رو انجام بدم، خوب باشه."

    # say L2310 sis
    old "Glad that you came, quite on time to apply my sunscreen, can you help me?"
    new "خوشحالم که اومدی، همین الان وقت خوبی برای پاشیدن لوشن منه، می‌تونی به من کمک کنی؟"

    # say L2312 sis
    old "I can show you how to do it... Let's start with my boobs."
    new "می‌تونم بهت نشون بدم چطور انجام بده... بیای، از سینه‌هام شروع کنیم."

    # say L2313 pla
    old "Your... Wh- What?"
    new "تو... چ-چه؟"

    # say L2314 sis
    old "My boobs, I need to show the bikinis, so my boobs are important. And you see them all the time in the photoshoots."
    new "سینه‌هام، باید بیکینی‌ها رو نشون بدم، پس سینه‌هام مهم هستن. و تو همیشه اونا رو تو عکس‌برداری‌ها می‌بینی."

    # say L2315 pla
    old "Hmmm... Alright..."
    new "Hmm... خب..."

    # say L2319 pla
    old "Wow! What are you doing?"
    new "واو! تو چه کاری داری می‌کنی؟"

    # say L2320 sis
    old "Taking off my bra, you weren't pretending to tan my breasts with it on, did you?"
    new "پوسته سینه‌هام رو می‌برم، نمی‌تونستی با اون روی سینه‌هام خوردن آفتابو شب‌نامه می‌کردی، همین‌جوری؟"

    # say L2321 pla
    old "So you want me to apply the sunscreen like thi-"
    new "پس می‌خوای از من برم اینجوری زیت بزنم-"

    # say L2322 sis
    old "Oh, shut up... You and I both know you're dying to touch them..."
    new "اوه، بسش کن... تو و من هر دو می‌دونیم که خواستی لمسشون کنی..."

    # say L2323 sis
    old "And I just want a good massage and sunbathe to get a tan."
    new "من فقط می‌خوام مassage خوبی بگیرم و براون شم تا رنگم روشن بشه."

    # say L2325 sis
    old "So stop acting like an idiot and play with my babies..."
    new "پس بپرس احمق باش و با بچه‌های من بازی کن..."

    # say L2336 sis
    old "Do you want more, [pla]?"
    new "می‌خوای بیشتر هم، [pla]؟"

    # say L2338 sis
    old "Don't try to hide it from me... I know you're hard already."
    new "نترس از پیش من پوشانی... می‌دونم قطعاً سخت شده."

    # say L2339 pla
    old "I-I don't know what you mea-"
    new "من-من نمی‌دونم می‌خوای چی بگی-"

    # say L2340 sis
    old "Let me give you a clue... I've heard cum is a great treatment for the skin, so I wanted to test it on my boobs."
    new "بیای دهم بهت نکته‌ای بدم... شنیدم مایع منی برای پوست خوبه، پس می‌خواستم روی سینه‌هامون آزمایشش کنم."

    # say L2341 pla
    old "W-What!?... "
    new "W-چه!؟..."

    # say L2342 sis
    old "Shut up and come here..."
    new "بیا اینجا... بست و بیا..."

    # say L2358 sis
    old "Did you enjoy it?"
    new "لذت برده بودی؟"

    # say L2359 pla
    old "Yeah!"
    new "آره!"

    # say L2360 sis
    old "I would love to have this skin care therapy more often."
    new "من خوشحال می‌شوم که این درمان پوست رو بیشتر انجام بدم."

    # say L2361 sis
    old "I'll enjoy the sun, thank you."
    new "ممنون، خوشحالم که آفتاب می‌برم."

    # say L2362 pla
    old "You're welcome, see you later!"
    new "خواهش می‌کنم، ببینم بعداً!"

    # say L2385 sis
    old "Oh, you came at the right time."
    new "اوه، همینجوری وقت خوبی اومدی."

    # say L2387 sis
    old "Fortunately there is good news, I want to tell you something to cheer you up a bit."
    new "بازی خوبی هست، می‌خوام چیزی برات بگم که خوشحال بشی."

    # say L2389 sis
    old "The bikini session was great, Anastasia ordered again."
    new "سشن بیکینی عالی بود، آناستازیا دوباره سفارش داد."

    # say L2391 sis
    old "I need you to be nice with her again, so she feels comfortable."
    new "باید باهاش خوب رفتار کنی، تا احساس راحتی کنه."

    # say L2392 pla
    old "Ok, I will."
    new "باشه، من خواهم کرد."

    # say L2393 sis
    old "You already know her place, remember, that everything you do is really important."
    new "تو قرارش رو قبلاً می‌دونی، به خاطر بسپار، همه چیزی که می‌کنی واقعاً مهمه."

    # say L2401 pla
    old "Good morning Mrs."
    new "صبح بخیر خانم"

    # say L2402 ana
    old "Oh what a nice surprise, It's my favorite delivery boy!"
    new "اوه چه مفاجأه خوبی، این هم پیک مورد علاقه من!"

    # say L2403 pla
    old "Hehehe, Thank you, I am glad to see you too."
    new "هههه، ممنون، خوشحالم که تو رو هم می‌بینم."

    # say L2404 pla
    old "Here you are!"
    new "اینجا هست!"

    # say L2409 ana
    old "Thank you, you're so kind."
    new "ممنون، خیلی لطف داری."

    # say L2410 pla
    old "I hope you enjoy your purchase, have a nice day!"
    new "امیدوارم از خریدت لذت ببری، روز خوبی داشته باش!"

    # say L2411 ana
    old "Oh, are you planning on leaving already? Actually I was considering to ask you for a big favor and I have nobody else to help me."
    new "اوه، قراره حالا بری؟ در واقع من می‌خواستم ازت یه لطف بزرگ بخواهم و هیچ کس دیگه ندارم که بهم کمک کنه."

    # say L2412 ana
    old "I think since you're a man you could help me."
    new "فکر می‌کنم چون تو مردی می‌تونی به من کمک کنی."

    # say L2413 pla
    old "(I have to make her feel comfortable, she's our best client.)"
    new "من باید اینجا باقی بمانم تا تو راحت باشی، تو بهترین مشتریمون هستی."

    # say L2414 ana
    old "It won't take you too long, I promise."
    new "باز هم طول زیادی نمی‌بره، وعده میدم."

    # say L2415 pla
    old "Oh, sure, how can I help you?"
    new "البته، چطور می‌تونم به تو کمک کنم؟"

    # say L2416 ana
    old "Please come in."
    new "لطفاً بیای داخل."

    # say L2424 ana
    old "Just wait a second, I will be right back."
    new "لطفاً صبر کن، همین جا بر می‌گردم."

    # say L2438 pla
    old "(Wow, Wow!)"
    new "واو، واو!"

    # say L2439 ana
    old "I needed a second opinion, and I just thought you could help."
    new "من نیاز به نظر دومی داشتم، فکر کردم می‌تونی کمکت کنی."

    # say L2440 ana
    old "Please be honest, do you like it?"
    new "لطفاً صادق باش، آیا می‌پسندی؟"

    # say L2441 pla
    old "Gulp, You look..."
    new "آنا، تو... خوب، تو... شگفت‌انگیزی."

    # say L2443 pla
    old "No, no, no, of course not, You look... A-amazing."
    new "نه، نه، نه، البته نه، تو به نظر می‌رسی... ش-شگفت‌انگیز."

    # say L2445 pla
    old "Y-Yes... I- I am being really honest."
    new "بله... من واقعاً صادقانه هستم."

    # say L2448 pla
    old "(Oh shit... I'm getting hard.)"
    new "اوه شیطون... من سخت می‌شوم."

    # say L2449 ana
    old "Wow dear, what you got in there?"
    new "وای عزیزم، تو چه چیزی توی جیب داری؟"

    # say L2450 pla
    old "I'm sorry, I didn't mean to-"
    new "من خیالی نداشتم-"

    # say L2451 ana
    old "Ohh, You are very sweet, I apologize for this, I didn't mean to make you feel uncomfortable."
    new "اوه، تو خیلی شیرینی، معذرت می‌خوام، من قصد نداشتم برات ناراحت کنم."

    # say L2453 pla
    old "I-I am sorry, I-I... Just should leave."
    new "من-من خیلی متاسفم، من-من... باید برسم."

    # say L2454 ana
    old "Oh no, please let me apologize correctly, you can't leave like that."
    new "نه، لطفاً بگذار من صحیح عذرخواهی کنم، نمی‌توانی اینجوری بری."

    # say L2456 ana
    old "I think you deserve a bigger tip this time due to this big inconvenience."
    new "من فکر می‌کنم این بار باید پاداش بیشتری به تو بدهم به خاطر این مشکل بزرگ."

    # say L2459 ana
    old "How about if you just relax a little bit on the couch and let me fix this with my own hands. "
    new "بیا روی صندلی خیالت راحت کن و بگذار من با دست‌هام این مشکل رو حل کنم."

    # say L2466 ana
    old "Please, relax and let me compensate for the situation, just close your eyes and enjoy."
    new "لطفاً آرام شو و بگذار من این وضعیت رو جبران کنم، فقط چشماتو ببند و لذت ببر."

    # say L2478 ana
    old "I hope you liked it..."
    new "امیدوارم لذت برده باشی..."

    # say L2479 pla
    old "Uhh... Y-yes, thank you"
    new "اوه... بله، ممنونم"

    # say L2480 ana
    old "Alright sweetie, thanks for your help, it was very clear to me that this bikini suits me very well... I hope to see you in my next delivery."
    new "البته عزیزم، ممنون از کمکت، خیلی واضح بود برایم که این بیکینی روی من خیلی خوب جا می‌زنه... امیدوارم تو را در تحویل بعدی ببینم."

    # say L2481 pla
    old "(Wow, I'm starting to love this job)"
    new "واو، شروع کردم این کار رو دوست داشتن"

    # say L2482 pla
    old "Of course, I'll bring your next purchase."
    new "البته، خرید بعدیتو هم می‌آورم."

    # say L2483 ana
    old "That sounds great..."
    new "این خوبه..."

    # say L2492 sis
    old "Hey, you are back."
    new "سلام، برگشته‌ای."

    # say L2493 pla
    old "Yep."
    new "بله."

    # say L2494 sis
    old "So? Everything went alright?"
    new "پس؟ همه چیز خوب بود؟"

    # say L2495 pla
    old "It was... Wonderful."
    new "بود... عالی."

    # say L2496 sis
    old "(Wonderful?) Hmm, ok thanks for your help."
    new "(عالی؟) هم، ممنون از کمکت."

    # say L2497 sis
    old "Did she like it?"
    new "اونجا خوشش اومد؟"

    # say L2498 pla
    old "Yeah, she loved it."
    new "بله، عاشقش شد."

    # say L2499 sis
    old "How are you so sure about it?"
    new "چطور مطمئن هستی؟"

    # say L2500 pla
    old "Well... Is the second time she purchases, so she liked the first one."
    new "خب... این دومین باره که می‌خره، پس اولی رو دوست داشت."

    # say L2501 sis
    old "Ok... I'll let you know once we are ready for the next photography session."
    new "باشه... وقتی برای جلسه عکس بعدی آماده شدیم، اطلاع می‌دم."

    # say L2502 pla
    old "I'll look forward to it."
    new "من منتظرش می‌مونم."

    # say L2529 sis
    old "Uhh... I am so horny, I'll need more."
    new "اوه... من خیلی خواسته‌ام، بیشتر نیاز دارم."

    # say L2531 pla
    old "(Oh shit... She saw me!)"
    new "اوه شیطون... منو دیدی!"

    # say L2539 sis
    old "I know you have been there for a while."
    new "میدونم از کیه که اینجا بودی."

    # say L2540 pla
    old "Sorry... I-I was just-"
    new "ببخشید... من فقط-"

    # say L2541 sis
    old "It's ok dummy! I think it is time to get paid back."
    new "خوبه بچه! فکر کنم وقت برای پرداخت رسیده."

    # say L2543 sis
    old "I mean, I need you to pay me back, I know that you have more than enough to give."
    new "من قصدم اینه که تو باید به من بپردازی، میدونم که کافیت هست."

    # say L2545 sis
    old "Come here, let me suck that big dick."
    new "بیا اینجا، بیای اون جون رو خورد."

    # say L2550 sis
    old "Grab my head and fuck my mouth!"
    new "سرم رو بگیر و توی دهانم بکن!"

    # say L2560 sis
    old "Oh, shit. I can't handle it anymore... Want you to fuck me, I need you inside of me now."
    new "اوه، شیطون. دیگه نمی‌تونم تحمل کنم... می‌خوام تو بیا داخل من باشی، الان لازم دارم."

    # say L2562 sis
    old "Come here and fuck your [sisrel]... Fuck me hard [pla]!"
    new "اومو پیش من و بکن [sisrel]... بکنم روی من سخت [pla]!"

    # say L2578 sis
    old "Wow, you did great!"
    new "واو، عالی کردی!"

    # say L2580 sis
    old "Ugh, I got really tired, that was pretty intense."
    new "اوه، خیلی خسته شدم، این خیلی سخت بود."

    # say L2582 sis
    old "Anyway, I'm gonna need some of your skills tomorrow too."
    new "بازهم به تو نیاز دارم، فردا هم کاری برای من انجام بده."

    # say L2584 sis
    old "Hahaha, I'm talking about the photshoot, dummy. I'm preparing a new one, so, I count on you."
    new "هahaha، من در مورد فتوشات حرف می‌زنم، خیلی خنده‌دار. آماده‌سازی یکی جدید هستم، پس از تو اعتماد دارم."

    # say L2585 pla
    old "Sure, I'll be ready."
    new "بله، آماده‌ام."

    # say L2586 sis
    old "Now leave me alone. I just want to rest..."
    new "حالا برو برات. من فقط می‌خوام استراحت کنم..."

    # say L2587 pla
    old "Hmm, alright... See you later."
    new "Hmm، خوب... بعداً می‌بینیم."

    # say L2609 sis
    old "Hey, did you sleep well?"
    new "هی، خوب خوابیدی؟"

    # say L2610 pla
    old "Yeah, pretty well!"
    new "آره، خوب خوابیدم!"

    # say L2611 sis
    old "Good, that means we're gonna rock today!"
    new "خوبه، این بدان معناست که امروز ما خوب کار می‌کنیم!"

    # say L2644 sis
    old "I will be at the pool, don't be late."
    new "من در حوزه خواهم بود، دیر نباش."

    # say L2645 pla
    old "I'm going to pick up the camera and see you there."
    new "من می‌روم برای گرفتن دوربین و اونجا می‌تونیم هم بیوفتیم."

    # say L2652 sis
    old "This is the newest collection, what do you think?"
    new "این جدیدترین مجموعه است، چطور می‌تونی ازش نظر بدی؟"

    # say L2653 pla
    old "Really? It's pretty nice!"
    new "وای، خوبه!"

    # say L2654 pla
    old "I have some ideas for today."
    new "من برای امروز چند ایده دارم."

    # say L2655 sis
    old "Awesome, what are we waiting for?"
    new "عالی، منتظر چی هستیم؟"

    # say L2656 pla
    old "Ok, let's start with you standing up in front of the pool for a full body one."
    new "باشه، اول بایستی تو جلوی حوضچه بیایی تا یه عکس تمام بدن بگیرم."

    # say L2669 sis
    old "Ok, do I look good like this?"
    new "باشه، اینجوری خوب هستم؟"

    # say L2670 pla
    old "Yeah, keep your hand there, do not move... It looks more fancy."
    new "بله، دستت اونجا بگذار، حرکتی نکن... به نظر فرشته‌ای می‌رسه."

    # say L2706 pla
    old "Now I want try something special."
    new "الان می‌خوام چیزی خاص امتحان کنم."

    # say L2707 sis
    old "Tell me what to do."
    new "بگو چه کار باید بکنم."

    # say L2708 pla
    old "Please get on your knees, looking at me very very enticingly and to move your shoulders a bit ahead of your body..."
    new "لطفاً روی زانوهات نشست و به من خیلی خیلی جذاب نگاه کن و شانه‌هایت رو کمی جلوتر از بدنت حرکت ده..."

    # say L2719 sis
    old "Do you like it this way?"
    new "این جوری خوشت می‌آید؟"

    # say L2745 pla
    old "Oh boy, this is by far one of the best ones."
    new "اوه بچه، این حتماً یکی از بهترین‌هاست."

    # say L2753 pla
    old "Hmm I think would be great another one on the floor, but you turning around."
    new "همم، فکر کنم خوب باشه یکی دیگه روی زمین، ولی تو دور بگردی."

    # say L2754 sis
    old "Alright, but what kind of position should I do?"
    new "باشه، اما باید چه وضعیتی بگیرم؟"

    # say L2755 pla
    old "Let's see if we can make it a bit hotter..."
    new "ببینیم می‌تونیم یه کم داغ‌ترش کنیم..."

    # say L2756 pla
    old "Try to spread a bit your legs... And look at the camera. Also lift up your butt a bit more but try to keep your breast lower."
    new "پاشون رو یه کم باز کن... و به دوربین نگاه کن. همچنین پشتون رو بالا ببر اما سینو پایین نگه دار."

    # say L2757 sis
    old "Hmm, let me try."
    new "Hmm، بیایم بزنم امتحان کنم."

    # say L2768 pla
    old "Oh perfect! let me take the picture."
    new "اوه عالی! بیایم برات عکس ببرم."

    # say L2792 pla
    old "This looks amazing."
    new "این خیلی خوب به نظر می‌رسه."

    # say L2799 pla
    old "Ok, I really think we are done..."
    new "خب، فکر کنم واقعاً تمام شدیم..."

    # say L2801 sis
    old "Really? Yayyy! let me see them."
    new "واییی! واقعاً؟ برام نشون بده."

    # say L2802 pla
    old "Of course..."
    new "البته..."

    # say L2839 pla
    old "I do not know what's happening today, they are not sharp enough."
    new "نمی‌دونم امروز چه کاری دارم، خیلی تیز نیستن."

    # say L2857 pla
    old "Hmm, again with that..."
    new "هم، دوباره همین..."

    # say L2858 sis
    old "Hahaha, You did it well nerd."
    new "هahaha، خوب کار کردی، نرد."

    # say L2867 sis
    old "Anyway, I'm going to upload more material, I need to sell."
    new "بازهم، من می‌خوام محتوای جدید بارگذاری کنم، باید فروش بدم."

    # say L2869 sis
    old "Oh by the way... I'm considering bringing some sexy friends so we can make pics with new models."
    new "البته، به هر حال... دارم فکر می‌کنم برای آوردن بعضی دوستان جذاب تا عکس‌های جدید با مدل‌های جدید بگیریم."

    # say L2870 sis
    old "It would help us get everybody's attention and it means more sales, more money."
    new "این به ما کمک می‌کنه تا توجه همه رو جلب کنیم و به معنی فروش بیشتر و پول بیشتر هست."

    # say L2872 sis
    old "Sure, you are gonna like it!"
    new "بله، حتماً لذت می‌بری."

    # say L2873 sis
    old "Well time is money, see you around..."
    new "زمان پول هست، دیدنت خوب بود..."

    # say L2875 pla
    old "New models, uh?"
    new "مدل‌های جدید، هم؟"

    # say L2898 sis
    old "Well you're on time, wanna have fun? I need help with my sunscreen again."
    new "خب تو هم وقتت رو حساب می‌کنی، می‌خوای باهام لذت ببری؟ دستت به من کمک کن با خورشید آفتاب بزنیم."

    # say L2900 sis
    old "Let's start with my butt."
    new "بیای بزنیم از پشتونم شروع کنیم."

    # say L2904 sis
    old "I love the sun, it feels great and makes me look better, don't you think."
    new "من عاشق آفتاب هستم، احساس خوبی می‌ده و منو زیباتر می‌کنه، نمی‌تونی؟"

    # say L2906 sis
    old "Please pay attention, I need you to spread it aaaaall over my butt while giving a slow massage."
    new "لطفاً توجه کن، باید این رو همه جا روی پشتونم پخش کنی در حالی که ماساژ آرام آرام می‌دهی."

    # say L2924 sis
    old "You know what? Let's fuck right now!"
    new "می‌دونی چی؟ بیای حالا جنس کنیم!"

    # say L2925 pla
    old "Wha-? But... Someone could see us."
    new "وای؟ اما... ممکنه کسی ما رو ببینه."

    # say L2926 sis
    old "People are busy, nobody is gonna come, I already checked."
    new "مردم مشغول هستن، هیچ کس نمی‌تونه بیاد، من قبلاً بررسی کردم."

    # say L2927 sis
    old "Last time you weren't so worried about that!"
    new "آخر بار نگران اینجوری نبودی!"

    # say L2929 sis
    old "Don't worry about the people, think just about my ass"
    new "نگران افراد نباش، فقط به پشت من فکر کن"

    # say L2941 sis
    old "I really liked it, you are by far much better than my toy."
    new "وای، واقعاً لذت بردم، تو خیلی بهتر از بازی‌کنی هستی."

    # say L2942 sis
    old "It's like a super toy, delicious!"
    new "این مثل یه سوپر بازی‌آفرینه، لذت‌بخش!"

    # say L2943 sis
    old "Hope you liked it too, gonna take a shower."
    new "امیدوارم تو هم لذت برده باشی، من می‌روم دوش می‌کنم."

    # say L2944 sis
    old "Bye now."
    new "بای‌ها"

    # say L2968 pla
    old "Yep, how bout you?"
    new "بله، تو چطور بودی؟"

    # say L2969 sis
    old "Amazing, sun makes me feel good."
    new "عالی، خورشید برایم خوبه."

    # say L2970 sis
    old "I want to share some news to you."
    new "می‌خوام با تو خبری رو به اشتراک بذaram."

    # say L2972 sis
    old "Sure, meet me in my bedroom."
    new "بله، بیا به اتاق خوابم."

    # say L2973 pla
    old "Coming."
    new "می‌آیم."

    # say L2980 sis
    old "Well, being honest, the business is running pretty good."
    new "البته، صادقانه بگم که کسب و کار خوب پیش می‌رود."

    # say L2981 sis
    old "Part of this success has been your help with the website, the pics, and your effort."
    new "بخشی از این موفقیت بخاطر کمکت به وب‌سایت، عکس‌ها و تلاشت بود."

    # say L2982 sis
    old "I know you have been more than the 'nerd' with the website, but also the one who delivers, photographer, market couch, you name it."
    new "میدونم تو فقط نیستی نرده وب‌سایت، بلکه همینجوری عکاس، بازاریاب، و هر چیزی که به ذهنم میرسه."

    # say L2983 pla
    old "Well, that is not true, but thanks."
    new "خب، این درست نیست، ولی ممنون."

    # say L2984 sis
    old "I think it would be fair if we split the incomes instead of just giving you part of it, because you are more like my partner."
    new "فکر می‌کنم منصفانه باشه اگه درآمد رو تقسیم کنیم، چون تو مثل همکار منی."

    # say L2985 pla
    old "Wow... I am glad to hear that."
    new "واو... خوشحالم که اینجوری فکر می‌کنی."

    # say L2986 sis
    old "To be honest, there is more you should know."
    new "صusch: به صراحه، چیزهایی هست که باید بدونی."

    # say L2987 sis
    old "This is just part of the incomes, there is something you should be more excited about."
    new "این فقط بخشی از درآمدها هست، چیزی هست که باید خوشحال‌تر بشی."

    # say L2989 sis
    old "Lay on the bed, I will show you."
    new "روی تخت بخشوند، بهت نشون می‌دم."

    # say L2992 sis
    old "Let me give you something money can't buy."
    new "بیای دهم چیزی به تو که پول نمی‌تونه خرید."

    # say L3001 sis
    old "Ohh, I love this taste..."
    new "اوه، این طعم رو دوست دارم..."

    # say L3002 sis
    old "Now, let's fuck! I'm going to ride you..."
    new "حالا، بیای دیگه! من روی تو سوار می‌شوم..."

    # say L3015 sis
    old "That was intense... What a mess we've made."
    new "این خیلی شدید بود... چه همه‌ی این درگیری را ایجاد کردیم."

    # say L3022 pla
    old "Hell yeah."
    new "بله، حتماً."

    # say L3023 sis
    old "I think this is how a very successful partnership starts!"
    new "فکر می‌کنم اینجوری همکاری‌های موفق شروع می‌شنند!"

    # say L3024 sis
    old "I appreciate your hard work especially in this extra activity."
    new "من تلاشت رو در این فعالیت اضافی خیلی قدردانی می‌کنم."

    # say L3025 sis
    old "From now you can ask anything from me. I mean we are partners."
    new "از حالا می‌تونی از من هر چی بپرسی. منظورم اینه که ما شریک هستیم."

    # say L3027 sis
    old "I need a bit of rest... See you later [pla]"
    new "نیاز به استراحت کمی دارم... بعداً ببینیم [pla]"

    # say L3028 pla
    old "See you later [sis]."
    new "ببینم بعداً [sis]"

    # say L3029 sis
    old "I really love your cock, Nerd!"
    new "من واقعاً عاشق ناخن تو هستم، نرم‌افزار!"

    # say L3061 sis
    old "I asked you to come to my bedroom in the afternoons, dummy..."
    new "من ازت خواستم بعدازظهر به اتاق خوابم بیایی، احمق..."

    # say L3063 pla
    old "Oh, my bad. I will be in the garage studying then."
    new "اوه، اشتباه کردم. بعداً تو گراج مطالعه می‌کنم."

    # say L3068 sis
    old "Studying in the garage?... (Hmm, I wonder what he's really doing in there.)"
    new "در گاراژ مطالعه می‌کنی؟... (حتماً چیزی دیگه انجام می‌ده.)"

    # say L3098 pla
    old "Oh... sorry. I was just thinking of something..."
    new "اوه... معذرت. فقط به چیزی فکر می‌کردم..."


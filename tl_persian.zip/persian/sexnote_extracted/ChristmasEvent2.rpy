# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/ChristmasEvent2.rpy
translate persian strings:

    # say L7 pla
    old "Hmm, what is this?"
    new "Hmm، این چیه؟"

    # say L8 pla
    old "What's this feeling?"
    new "این احساس چیه؟"

    # say L9 pla
    old "I- I have a hard-on?!"
    new "من- من سخت شدم؟!"

    # say L22 pla
    old "Lydia?! W- what are you doing?"
    new "لیدیا؟! و- و تو چه کاری داری؟"

    # say L28 lyd
    old "Good morning hon! Great, you finally wake up!"
    new "صبح بخیر عزیزم! خوبه، بالاخره بیدار شدی!"

    # say L29 pla
    old "W- what's happenning? What's this?!"
    new "و- چه کاری انجام می‌دهی؟ این چیه؟!"

    # say L30 pla
    old "And what is that you're wearing?!"
    new "و این لباسی که پوشیدی چیه؟!"

    # say L34 lyd
    old "Do you like it? It's my Mrs. Claus outfit for the day!"
    new "می‌پسندی؟ این لباس مادام کلاوس برای امروزه!"

    # say L35 lyd
    old "You know, to get in the spirit of Christmas."
    new "می‌دونی، برای اون جویای کریسمس."

    # say L36 pla
    old "Whatever! What are you doing in my room, and giving me a blowjob?!"
    new "هر چی! تو توی اتاق من چی کار می‌کنی و می‌خوای به من جنسیتی بدهی؟!"

    # say L37 lyd
    old "Well, I came to spend Christmas with you guys."
    new "خب، اومدم برای اینکه کریسمس رو با شما بگذرانم."

    # say L38 lyd
    old "But when I arrived I saw that you were still sleeping."
    new "ولی وقتی رسیدم دیدم هنوز خوابیدی."

    # say L42 lyd
    old "Then I decided to wake you up in a special way!"
    new "بعدش فکر کردم باید تو رو به طور خاص بیدار کنم!"

    # say L43 lyd
    old "I guess you can say it is my early Christmas present to you!"
    new "می‌تونی بگی این هدیه زودرس کریسمس من برای تو هست!"

    # say L44 pla
    old "What are you talking about?!"
    new "pla: تو درباره چی حرف می‌زنی؟!"

    # say L45 pla
    old "Do you know what my [mo1rel]'s going to do if she sees what you're doing?!"
    new "می‌دونی اگه [mo1rel]ت ببینه این کارایی چی می‌کنه؟!"

    # say L46 pla
    old "What's gotten into you all of a sudden?"
    new "تو ناگهان چه اتفاقی بهت افتاد؟"

    # say L50 lyd
    old "Oh, don't say that."
    new "اوه، نگو اینجوری."

    # say L51 lyd
    old "Nothing got into me."
    new "هیچی وارد من نشده."

    # say L55 lyd
    old "I just wanted to start Christmas the right way."
    new "می‌خواستم جشن‌های کریسمس رو به درستی شروع کنم."

    # say L59 lyd
    old "I bet you can help me with that."
    new "مطمئنم تو می‌تونی به من کمک کنی."

    # say L63 lyd
    old "After all, you have something I want in me..."
    new "در نهایت، تو چیزی داری که من می‌خوام توی من باشه..."

    # say L64 pla
    old "W- what? You must be kidding me!"
    new "W- چه؟ حتماً مزح داری!"

    # say L68 lyd
    old "Don't be so shy baby"
    new "نباشی خجولانه بچه جون"

    # say L69 lyd
    old "After all, it's not like you haven't done it before."
    new "در نهایت، این جوری نیست که قبلاً انجام نداده‌ای."

    # say L73 lyd
    old "Besides, I can see very clearly that you want it."
    new "البته، من خیلی واضح می‌بینم که تو می‌خوای."

    # say L74 pla
    old "T- that's just because you woke me up that way!"
    new "آ- آنقدر فقط چون تو منو اینجوری بیدار کردی!"

    # say L75 pla
    old "It- it will go down in a minute."
    new "ای- این یک دقیقه پایین می‌ره."

    # say L79 lyd
    old "Oh, but I can't let that happen!"
    new "اوه، ولی نمی‌تونم این بیفتد!"

    # say L80 lyd
    old "I haven't had any breakfast yet, and I think I want some of your eggnog!"
    new "من هنوز هیچ صبحانه‌ای نخورده‌ام، و فکر می‌کنم می‌خواهم از آب مروارید تو برخوردم!"

    # say L87 lyd
    old "My god, I love the taste and smell of your dick!"
    new "الهی، عاشق طعم و بوی ناخن تو هستم!"

    # say L88 lyd
    old "I'm already so wet!"
    new "من قطعاً خیلی خیس شدم!"

    # say L89 lyd
    old "What a shame we don't have much time."
    new "این خیلی شرمنده‌کننده است که وقت زیادی نداریم."

    # say L90 lyd
    old "Otherwise I'd like to do something else..."
    new "در غیر این صورت می‌خواستم چیز دیگری انجام بدم..."

    # say L99 lyd
    old "Well, that was a great way to start the day, right [pla]?"
    new "البته، این بهترین راه برای شروع روز بود، درسته [pla]؟"

    # say L101 lyd
    old "I'll go say good morning to the rest of the family."
    new "من برم خوش‌صبح به بقیه خانواده بگم."

    # say L102 lyd
    old "So, you can get dressed in peace."
    new "پس، می‌تونی با آرامش لباست رو بذاری."

    # say L103 pla
    old "Uhh... sure."
    new "اوه... حتما."

    # say L113 pla
    old "W- what? What was that? What's happening?"
    new "و- وای، این چی بود؟ چه کاری انجام می‌دهی؟"

    # say L114 sis
    old "I was asking you if you had a minute, I have something to show you..."
    new "من از تو می‌پرسم آیا یه لحظه وقت داری، چیزی بهت نشون می‌دم..."

    # say L116 sis
    old "Excuse me?"
    new "ببخشید؟"

    # say L117 pla
    old "Uhh, nevermind... Uhh, what do you want to show me?"
    new "اوه، فراموش کن... اوه، چی می‌خوای به من نشون بدی؟"

    # say L119 sis
    old "Hmm, come to my bedroom with me."
    new "هم، با من به اتاق خوابم بیا."

    # say L120 pla
    old "Uh, sure."
    new "آره، البته."

    # say L137 sis
    old "So, I wanted to show you the new Christmas clothes that just arrived."
    new "پس، می‌خواستم به تو نشون بدم لباس‌های جدید کریسمسی که همین‌طور رسیدن."

    # say L138 sis
    old "They're for the shop."
    new "این‌ها برای فروشگاه هستند."

    # say L141 pla
    old "That's great [sis]."
    new "عالیه [sis]."

    # say L142 sis
    old "Do you want to see them?"
    new "می‌خوای ببینی؟"

    # say L145 sis
    old "Great! Just wait here."
    new "عالی! فقط اینجا صبر کن."

    # say L157 sis
    old "Ok, this is the first one, what do you think?"
    new "خب، این اولیه، چه نظری داری؟"

    # say L158 pla
    old "I think it's great, very festive, it suits you."
    new "من فکر می‌کنم عالیه، خیلی جشنی، برای تو مناسبه."

    # say L159 pla
    old "I'm sure it's going to sell great."
    new "مطمئنم خوب فروختن می‌شه."

    # say L160 sis
    old "That's just what I thought."
    new "این همینطور فکر کردم."

    # say L161 sis
    old "Let me show you the other one."
    new "بیای دیگری رو به تو نشون بدم."

    # say L177 sis
    old "So, what about this one?"
    new "پس این‌تای چطوره؟"

    # say L178 sis
    old "This one is my favorite."
    new "این‌تای مورد علاقه منه."

    # say L180 pla
    old "I- I mean, it looks great on you."
    new "من قصدم اینه که روی تو خوب بیاد."

    # say L181 pla
    old "I'm not sure this counts as an outfit per se."
    new "من نمی‌تونم این رو به حساب لباس بگیرم."

    # say L185 pla
    old "But maybe it will sell well as lingerie."
    new "اما شاید به عنوان لینجری خوب فروش بشه."

    # say L186 pla
    old "This one could also be good for the ladies that want to surprise their husbands and boyfriends."
    new "این هم برای خانم‌هایی که می‌خوان ازدواج‌شون رو شگفت‌زده کنن خوبه."

    # say L187 sis
    old "Yeah, and it's very comfortable too."
    new "بله، و خیلی راحت هم هست."

    # say L188 sis
    old "The fabric's very soft."
    new "این لباس خیلی نرمه."

    # say L201 pla
    old "Uhhh... What are we doing [sis]?"
    new "اوه... ما اینجا چه کاری داریم [sis]؟"

    # say L202 sis
    old "Oh well, I just want you to feel the fabric."
    new "البته، فقط می‌خوام احساس لایه رو به تو بدهم."

    # say L203 sis
    old "What do you think? Isn't it soft?"
    new "چه فکر می‌کنی؟ آیا نرم نیست؟"

    # say L204 pla
    old "I- I guess it is, yeah..."
    new "من فکر می‌کنم نعم،..."

    # say L206 sis
    old "But how much do you like it?"
    new "ولی چقدر دوست داری؟"

    # say L207 sis
    old "Let me see how you feel down here..."
    new "بیای دیدم اینجا چطور حس می‌کنی..."

    # say L213 pla
    old "W- What are you doing [sis]?!"
    new "W- چه کاری می‌کنی [sis]؟!"

    # say L214 sis
    old "I just wanted to see how much you like my outfit..."
    new "می‌خواستم ببینم چقدر از لباس من خوشت می‌آید..."

    # say L220 sis
    old "And oh my god! Look at that!"
    new "و خدا نگه دار! نگاه کن به اون!"

    # say L221 sis
    old "You clearly really like it!"
    new "مشخصاً خیلی دوستت داری!"

    # say L222 pla
    old "Uh... I- I mean."
    new "اوه... من- من می‌خواستم بگم."

    # say L223 sis
    old "It's ok [pla] I know you love it."
    new "خوبه [pla] می‌دونم دوستت داره."

    # say L224 sis
    old "Just look at that big cock!"
    new "ببین اون نیم‌پا بزرگ رو!"

    # say L225 sis
    old "What I could with it..."
    new "با اون چی می‌تونم کرد..."

    # say L239 sis
    old "I'm sure the clients will love this new line!"
    new "مطمئنم مشتری‌ها این خط جدید رو خیلی دوست خواهند داشت."

    # say L240 pla
    old "Umm, yeah, I guess they will."
    new "ممنون، بله، احتمالاً خوشحال می‌شوند."

    # say L241 pla
    old "Hey, listen [sis]... Do you feel well?"
    new "هی، گوش کن [sis]... حالت خوبه؟"

    # say L242 sis
    old "Me? I feel great!"
    new "من؟ من عالی هستم!"

    # say L246 sis
    old "Why do you ask?"
    new "چرا می‌پرسی؟"

    # say L247 pla
    old "No reason, it's just a strange feeling..."
    new "هیچ دلیلی، فقط حس عجیبی دارم..."

    # say L248 pla
    old "You know what? Forget it, it must be my imagination."
    new "می‌دونی چی؟ فراموش کن، حتماً تصوراتم هست."

    # say L250 sis
    old "Well, I have to work on some things for the website, you can leave now."
    new "خب، من باید برخی چیزهایی برای وب‌سایت انجام بدم، می‌تونی حالا برو."

    # say L252 pla
    old "Uhh, right..."
    new "اوه، درسته..."

    # say L262 pla
    old "Uhh... That was weird..."
    new "اوه... این عجیب بود..."

    # say L263 pla
    old "I still has that strange feeling... What was that?"
    new "هنوز هم اون حس عجیب رو دارم... این چی بود؟"

    # say L264 pla
    old "Anyway, I better go downstairs and see what happened with Lydia..."
    new "به هر حال، بهتره برم پایین ببینم لیدیا چطوره..."

    # say L286 mo1
    old "Ah! [pla] honey!"
    new "اوه! [pla] عزیزم!"

    # say L287 mo1
    old "You've arrived, wonderful!"
    new "آه! عزیزم، خوشحالم که رسیدی."

    # say L288 mo1
    old "We're opening our Christmas gifts, you're just in time."
    new "ما هدیه‌های کریسمس رو باز می‌کنیم، خوشحالم که همین الان رسیدی."

    # say L290 mo2
    old "It's your turn now [mo1], and this one's from me, why don't you open it?"
    new "الان دفعه تو هست [mo1]، این هدیه از منه، بیا بازش کن."

    # say L298 mo1
    old "Oh! Honey! Thank you!"
    new "اوه! عزیزم! ممنون!"

    # say L299 mo1
    old "I can't wait to see what it is!"
    new "نمی‌تونم منتظر بمونم ببینم چیه!"

    # say L306 mo1
    old "Oh my god [mo2]! This is just what I wanted!"
    new "اوه خدا ز[mo2]! این دقیقاً همینه که می‌خواستم!"

    # say L308 pla
    old "(Is that a bottle of lube?)"
    new "این یک فلک لب‌آماده است؟"

    # say L313 mo1
    old "Of course I do! This is my favorite brand!"
    new "البته! این برند مورد علاقه من هست."

    # say L314 mo2
    old "You know, this lube is very good because it enhance all sensations."
    new "میدونی این لب‌آماده خیلی خوبه چون همه حس‌ها رو تقویت می‌کنه."

    # say L315 pla
    old "(Holy shit, yes it is...)"
    new "(شیطانی، بله هست...)"

    # say L319 mo2
    old "So, when we use it you can feel even harder when you're getting railed."
    new "پس وقتی از اون استفاده می‌کنیم، حتی وقتی تو رو می‌کشند هم حس‌هایت قوی‌تر می‌شه."

    # say L320 pla
    old "(What the... Why are they talking like that in front of Lydia...)"
    new "چه خبر... چرا اینجوری با هم صحبت می‌کنند در برابر لیدیا..."

    # say L324 mo1
    old "Oh honey! That sounds fantastic! We have to use it as soon as we can!"
    new "اوه عزیزم! این خیلی عالی به نظر می‌رسه! باید همین حالا ازش استفاده کنیم."

    # say L325 mo2
    old "Off course! I really enjoy this one, is really warm..."
    new "البته! من واقعاً از این لذت می‌برم، خیلی گرم است..."

    # say L326 mo2
    old "We have to put it to the test to see if you like it."
    new "باید اینو آزمون کنیم تا ببینیم آیا لذت می‌بری ازش."

    # say L331 lyd
    old "Oh please, stop..."
    new "لطفاً، متوقف شو..."

    # say L337 lyd
    old "Come on [mo2], is this a gift for [mo1], or is it a gift for you?"
    new "بیای ز[mo2]، این هدیه برای [mo1]ه، یا برای خودت هست؟"

    # say L339 pla
    old "(What the...)"
    new "چه خبره..."

    # say L344 mo1
    old "There's no reason why it couldn't be for the both of us!"
    new "این هیچ دلیلی نداره که برای هر دو ما نباشه!"

    # say L345 mo1
    old "As long as we both enjoy it, who cares who it is for!"
    new "مادی: مادامی که ما هر دو لذت می‌بریم، مهم نیست برای چه کسیه!"

    # say L350 mo2
    old "That's right Lydia, relax."
    new "حق با تو است لیدیا، آرام شو."

    # say L356 mo2
    old "After all, I can fuck [mo1] with it, but she can also rail me later."
    new "در نهایت، می‌تونم با [mo1] سکس کنم، اما او هم بعداً می‌تونه منو بکنه."

    # say L357 lyd
    old "I guess you're right [mo1], [mo2]."
    new "باید همین‌طور باشه [mo1]، [mo2]."

    # say L358 lyd
    old "All gifts should be enjoyed equally."
    new "همه هدیه‌ها باید به طور مساوی لذت برده شوند."

    # say L359 lyd
    old "I think everybody should get to have a good time with these gifts."
    new "من فکر می‌کنم همه باید از این هدیه‌ها لذت ببرند."

    # say L360 mo1
    old "Oh, I agree with that."
    new "اوه، با این توافق می‌کنم."

    # say L362 pla
    old "Uhh... W- what is happening?"
    new "اوه... ا- اینجوری چه اتفاقی افتاده؟"

    # say L367 mo1
    old "Thinking about it... [pla], you haven't opened your presents yet."
    new "فکر می‌کنم... [pla]، هنوز هدیه‌ات رو باز نکردی."

    # say L368 pla
    old "M- me?"
    new "من؟"

    # say L370 pla
    old "I think I'm ok for now."
    new "فکر کنم الان خوبم."

    # say L371 pla
    old "I'll open my gifts later."
    new "بعداً هدیه‌هام رو باز می‌کنم."

    # say L372 lyd
    old "Don't be foolish sweetie! You have to open them right now!"
    new "حتماً حالا باید باز کنی، عزیزم!"

    # say L373 mo2
    old "Otherwise it is no fun."
    new "در غیر این صورت خوشحال نمی‌شوم."

    # say L374 mo1
    old "That's right [pla], come honey, open your presents."
    new "درست است [pla]، بیا عزیزم، هدیه‌هایت رو باز کن."

    # say L382 pla
    old "I- I'm not sure I should."
    new "من- من مطمئن نیستم باید این کار رو بکنم."

    # say L387 mo2
    old "Don't be a brag and do it!"
    new "نباشی خجسته و انجام بده!"

    # say L401 pla
    old "W- WHAT THA FUCK? THIS WEIRD THING AGAIN???"
    new "و- وای، چه خبره؟ این چیز عجیب دوباره؟؟؟"

    # say L402 mo1
    old "Oh, don't worry honey, this is just one of your Christmas gifts."
    new "اوه، نگران نباش عزیزم، این فقط یکی از هدیه‌های کریسمس توست."

    # say L403 mo1
    old "After all you have been such a good boy this year."
    new "البته تو این سال خوب رفتار کردی."

    # say L404 mo2
    old "And we have been such naughty girls."
    new "و ما هم دختران بد بودیم."

    # say L405 lyd
    old "So, just relax and let us take care of you for a chance."
    new "پس، فقط آرام شو و بگذار ما یک بار ازت مراقبت کنیم."

    # say L406 pla
    old "{i}(What the hell is happening with them?){/i}"
    new "{i}(این همه چی با اونا اتفاق می‌فته؟){/i}"

    # say L407 pla
    old "{i}(Lydia had already been acting weird since this morning.){/i}"
    new "{i}(لیدیا از این صبح خیلی عجیب رفتار می‌کرد.){/i}"

    # say L430 pla
    old "Woww... That thing again... I'm starting to feel dizzy..."
    new "وایی... اون چیز دوباره... من شروع می‌کنم گریه کنم..."

    # say L431 sis
    old "God [pla], you're so hard!"
    new "خدا ز[pla]، تو همینقدر سختی!"

    # say L432 pla
    old "(What the fuck?? Now is [sis] here too?)"
    new "چه خبره؟ حالا ز[sis] اینجا هم هست؟"

    # say L434 sis
    old "And your cock is so big!"
    new "و پیشنتون تو خیلی بزرگه!"

    # say L435 lyd
    old "And your tongue is so good baby!"
    new "و زبانت هم خیلی خوبه بیبی!"

    # say L438 pla
    old "{i}(When am I going to have another dream like this?){/i}"
    new "{i}(وقتی دیگه همچین رویا‌ای می‌تونم ببینم؟){/i}"

    # say L449 pla
    old "L- Linett, whoah! You're in my dream too?"
    new "لینت، وای! تو هم توی رویاام هستی؟"

    # say L450 pla
    old "Did you come to join in on the fun?"
    new "آیا برای شرکت در لذت‌آمیزی اینجا آمده‌ای؟"

    # say L451 pla
    old "I mean, I haven't done it with shinigamis and humans simultaneously."
    new "من قصد ندارم با شینیگامی‌ها و انسان‌ها همزمان این کار رو انجام دهم."

    # say L452 pla
    old "But it could be interesting! Hop in!"
    new "ولی می‌تونه جالب باشه! بیا وارد شو!"

    # say L453 lin
    old "What? What are you talking about?"
    new "چه چیزی رو می‌گی؟"

    # say L454 pla
    old "Oh come on, you don't have to act like you don't want it."
    new "بیا، نمی‌تونی مثل این باشی که نمی‌خوای."

    # say L455 pla
    old "This is a dream after all."
    new "این فقط یه رویا هست."

    # say L456 lin
    old "This isn't a dream you dumbass!"
    new "این هیچ رویا نیست تو احمق!"

    # say L457 pla
    old "W- What? What do you mean?"
    new "و- و چی؟ منظورت چیه؟"

    # say L458 lin
    old "As you heard, this isn't a dream!"
    new "همانطور که شنیدی، این هیچ رویا نیست!"

    # say L459 lin
    old "This is all real [pla]!"
    new "این همه واقعیه [pla]!"

    # say L460 lin
    old "Apparently the magic concentrating spell we did in the church."
    new "به نظر می‌رسه جادوی تمرکز که در کلیسا انجام دادیم."

    # say L464 lin
    old "Seems to have affected reality in a way we couldn't predict."
    new "به نظر می‌رسه این جادوی تمرکز که در کلیسا انجام دادیم، واقعیت رو به یه شکلی که پیش‌بینی نکردیم تاثیر داده."

    # say L465 lin
    old "The ritual was successful but it's now starting to gather magic from all around."
    new "مراسم موفق بود اما حالا شروع کرده به جمع‌آوری سحر از همه جا."

    # say L466 lin
    old "And given that most magic in this world is stored in human bodies, it's trying to force it out!"
    new "و با توجه به اینکه بیشتر جادو در این دنیا در بدن انسان‌ها ذخیره شده، الان سعی می‌کنه آن رو بیرون بکشانه!"

    # say L470 lin
    old "When that happens to human bodies they start to feel their life energy deplete."
    new "وقتی این اتفاق برای بدن‌های انسانی می‌افتد، آنها شروع می‌کنند به احساس تخلیه انرژی زندگی خود."

    # say L474 lin
    old "So, all the weird human behavior is caused because of the magic power..."
    new "پس همه رفتارهای عجیب انسان‌ها به خاطر قدرت جادویی هست..."

    # say L475 lin
    old "They're not really themselves, they're in a sort of magically unconscious state..."
    new "اونها واقعاً خودشون نیستن، در یه حالت بی‌آگاهی جادویی هستن..."

    # say L476 lin
    old "And if it isn't stopped now it will wreak havoc in this world."
    new "و اگر حالا متوقف نشود، آشوب زیادی در این جهان خواهد ایجاد کرد."

    # say L477 lin
    old "Although it already started. So, we have very little time."
    new "البته قبلا هم شروع شده بود. پس وقت ما خیلی کم است."

    # say L481 lin
    old "Truth be told, when we did the last ritual I noticed something was odd."
    new "صuschی، وقتی آخرین مراسم رو انجام دادیم، چیزی عجیب متوجه شدم."

    # say L482 lin
    old "I probably should've done something about it then."
    new "احتمالاً باید آن موقع کاری انجام می‌دادم."

    # say L483 lin
    old "But I didn't expect anything like this to happen."
    new "ولی من انتظار نداشتم چیزی مثل این بیفتد."

    # say L484 pla
    old "I- I- I'm not getting it at all..."
    new "من- من- من هیچی متوجه نشدم..."

    # say L488 lin
    old "What I'm telling you is that reality is starting to fragment!"
    new "من به تو می‌گم واقعیت شروع کرده به تکه‌تکه شدن!"

    # say L489 lin
    old "So, we have to hurry and do something about it!"
    new "پس باید سریع کار کنیم و راه‌حلی پیدا کنیم!"

    # say L493 lin
    old "The ritual we did was successful."
    new "مراسمی که انجام دادیم موفقیت‌آمیز بود."

    # say L494 lin
    old "The problem  is that there's not enough magic density in this world to just create a portal."
    new "مساله اینجاست که در این دنیا چگالی جادو کافی برای ایجاد یک دروازه نیست."

    # say L499 pla
    old "What can we do about it?"
    new "چه کاری می‌تونیم بکنیم؟"

    # say L503 lin
    old "I have a couple ideas."
    new "چند ایده دارم."

    # say L504 lin
    old "Honestly I don't know if what I'm thinking off will work."
    new "صراحیت بگم نمی‌دونم ایده‌هایی که به ذهنم می‌رسه خوب کار می‌کنه."

    # say L505 lin
    old "So, we'll have to try a couple of things to see what sticks."
    new "پس باید چند تا چیز رو امتحان کنیم تا ببینیم چه چیزی جا می‌یاد."

    # say L506 lin
    old "But whatever it is we do."
    new "اما هر چه انجام بدیم."

    # say L510 lin
    old "I'm sure we'll need the other three shinigami for it, so, let's go."
    new "مطمئنم برای این کار به سه شینیگامی دیگه نیاز داریم، پس برویم."

    # say L528 lin
    old "W- What? Who are you?!"
    new "و- چه کاری؟ تو کی هستی؟!"

    # say L529 bri
    old "What the fuck is going on here?!"
    new "این جوری چه خبری؟!"

    # say L530 lin
    old "Uh- Listen, I don't know who you are."
    new "بگو، من نمی‌دونم تو کی هستی."

    # say L535 lin
    old "I didn't even know there was another shinigami around."
    new "من حتی نمی‌دونستم شینیگامی دیگه‌ای هم وجود داره."

    # say L536 lin
    old "But nice to meet you... I guess. I'm Linnet."
    new "البته خوشحالم که با تو آشنا شدم... حدس می‌زنم. من لینت هستم."

    # say L540 lin
    old "Listen, right now there's no time for us to talk."
    new "بگوش، الان وقتی برای صحبت کردن نیست."

    # say L541 lin
    old "In case you haven't noticed, reality is tearing itself apart!"
    new "اگر توجه نکردی، واقعیت در حال تجزیه شدن است!"

    # say L542 lin
    old "Are you going to help us or not?!"
    new "می‌خوای به ما کمک کنی یا نه؟!"

    # say L543 bri
    old "Oh, I know full well who you are!"
    new "اوه، من کاملاً می‌دونم تو کی هستی!"

    # say L547 bri
    old "You're that idiot that keeps messing with the magic of this world!"
    new "تو همون احمقی هستی که همیشه با جادوی این دنیا بازی می‌کنی!"

    # say L553 bri
    old "Look at the mess you've made!"
    new "ببین این همه درگیری رو ایجاد کردی!"

    # say L558 bri
    old "Not to mention that you keep setting [pla] down the wrong path!"
    new "به نظرت همین جوری [pla] رو به سمت اشتباه هدایت می‌کنی!"

    # say L559 bri
    old "Don't you see you're screwing our only chance of fixing the magical world?"
    new "می‌بینی نمی‌کنی که در حال خراب کردن تنها شанс ما برای اصلاح جهان جادویی هستی؟"

    # say L563 bri
    old "I'M NOT GOING TO LET YOU CONTINUE RUINING EVERYTHING!"
    new "من نمی‌تونم بیام اجازه بدم تو همه چی رو خراب کنی!"

    # say L583 pla
    old "B- Brixxida! W- What are you doing? She's an ally!"
    new "ب- بریکسیدا! و- واقعاً چه کاری انجام می‌دهی؟ او همکار ماست!"

    # say L587 bri
    old "Oh! You shut up! Enough with the stupidities!"
    new "اوه! تو بس کن! خیلی از احمقی‌ها کرده‌ای!"

    # say L588 bri
    old "You've already ruined too many things."
    new "تو قبلاً خراب کردی چیزهای زیادی."

    # say L589 bri
    old "And I won't keep risking my life, this world, and the magic world."
    new "و من هم نمی‌تونم دیگه زندگیم، این جهان و جهان سحر را در خطر بذارم."

    # say L590 bri
    old "Because of the actions of a group of stupid inexperienced shinigamis."
    new "به خاطر اقدامات یک دسته شینیگامی غیرتجربه."

    # say L599 bri
    old "There, you take care of that."
    new "اونجا، تو اینو بردار."

    # say L600 bri
    old "Put her some place where she won't be a bother."
    new "اشون رو جایی بگذار که آزاردهن نشه."

    # say L601 bri
    old "And come with me [pla], I'll fix this quickly."
    new "بیا با من [pla]، خیلی زود این مشکل رو حل می‌کنم."

    # say L634 pla
    old "So, what are we doing here?"
    new "پس، ما اینجا چه کاری داریم؟"

    # say L635 pla
    old "I don't see anything wrong..."
    new "من هیچ مشکلی نمی‌بینم..."

    # say L636 bri
    old "Oh really? Use your Eye of Agamotto..."
    new "وای، واقعاً؟ از چشم آگاموتی استفاده کن..."

    # say L637 pla
    old "Uhh... Alright..."
    new "اوه... خب..."

    # say L647 pla
    old "Woah! What's this? What's happening?"
    new "واو! این چیه؟ چه کاری انجام شده؟"

    # say L648 bri
    old "This is what you and that idiot did!"
    new "این همینه که تو و آن احمق انجام دادید!"

    # say L652 bri
    old "What you're seeing is the result of a difficult spell being casted by an inexpert hand."
    new "این چیزی است که از یک جادوی سخت به دست یک ناچربان پیش آمده."

    # say L656 bri
    old "This is why you should've come to me with these things [pla]!"
    new "این به همین خاطر بود که باید این جوری به من مراجعه می‌کردی [pla]!"

    # say L657 bri
    old "But it's ok, I'm here now."
    new "ولی خوبه، حالا من اینجا هستم."

    # say L658 pla
    old "Ok, but what's your plan to fix all this?"
    new "باشه، ولی برنامه‌ت برای اصلاح همه این‌ها چیه؟"

    # say L659 bri
    old "Just watch."
    new "فقط ببین."

    # say L665 bri
    old "Now! Quick! We have to go to your house to stabilize it!"
    new "الان! سریع! باید به خونه تو بریم تا اینو ثابت کنیم!"

    # say L667 pla
    old "Woah, Woah! What do you mean?!"
    new "وای، وای! چه قصدی هست؟!"

    # say L668 pla
    old "Are you planning on putting that in my house?"
    new "می‌خوای اون چیز رو توی خونه‌ام بزاری؟"

    # say L669 bri
    old "Don't worry nothing will happen."
    new "نگران نباش، هیچ چیزی اتفاق نمی‌افتد."

    # say L670 bri
    old "Unlike your little friend, I know how to do things properly."
    new "برخلاف دوست کوچیکت، من می‌دونم چطور باید کار رو درست انجام بدم."

    # say L672 bri
    old "So, let's hurry and go to your house!"
    new "پس، بیای برهیم به خونت!"

    # say L674 pla
    old "R- Right!"
    new "ب-بله!"

    # say L680 pla
    old "So, what now?"
    new "پس حالا چه کاری می‌کنیم؟"

    # say L681 bri
    old "I'm going to invoke the portal here."
    new "من قصد دارم در اینجا دروازه‌ی بین‌العالم را فراخوانی کنم."

    # say L682 pla
    old "Oh wow..."
    new "اوه وای..."

    # say L702 bri
    old "{b}*Sigh*{/b} That was dangerous."
    new "{b}*تنفر*{/b} این خطرناک بود."

    # say L703 bri
    old "But at least we now have a portal."
    new "اما حداقل حالا یک دروازه داریم."

    # say L707 pla
    old "Uhh... So, does that mean that we can go to the magical world now?"
    new "اوه... پس این به معنای اینه که می‌تونیم به جهان سحرپرداز بریم؟"

    # say L709 bri
    old "Of course not. Going from one world to another is not that easy!"
    new "البته نه. از یک جهان به جهان دیگر رفتن اینقدر ساده نیست!"

    # say L710 bri
    old "To work, this portal needs a massive amount of magic to finish its development."
    new "برای اینکه این درب کار کنه، به مقدار زیادی جادو برای تکمیل توسعه‌اش نیاز داره."

    # say L711 bri
    old "What it was doing before was sucking all of the magic power around, without any control or direction."
    new "قبل از این همه توان جادویی رو به صورت نامنظم و بدون هدف جذب می‌کرد."

    # say L715 bri
    old "That could've ended the world."
    new "این می‌تونسته جهان رو تمام کنه."

    # say L719 bri
    old "I just stabilized it so that it wouldn't continue extracting magic from all around and destroy the world."
    new "من فقط آن را پایدار کردم تا ادامه ندهد در استخراج جادو از همه جا و جهان رو نابود کنه."

    # say L724 bri
    old "What we must do now is feed it magic power in a more controlled way."
    new "الان باید به صورت کنترل‌شده توان جادویی بهش بدهیم."

    # say L728 pla
    old "Uh... ok."
    new "اوه... خوب."

    # say L732 pla
    old "So, how do we feed it magic power now?"
    new "پس، الان چطور باید بهش توان جادویی بدهم؟"

    # say L736 bri
    old "Well, normally it would be just a simple issue of using the eye of Agamoto to stock up in magic power."
    new "خب، معمولاً فقط کافی بود از چشم آگاموتو برای ذخیره انرژی جادویی استفاده کنیم."

    # say L737 bri
    old "And then just release it in the portal."
    new "و بعدش فقط آن را در پرتال آزاد کن."

    # say L741 bri
    old "But now, due to you and your little friend messing up."
    new "اما حالا، به خاطر تو و دوستت کوچیک که اشتباه کردید."

    # say L742 bri
    old "It extracted a lot of free-flowing energy from the world."
    new "این انرژی را از جهان خارج کرد."

    # say L744 bri
    old "We can get it back, but it's going to take a longer time. And it will be a lot more dangerous."
    new "ما می‌تونیم اون رو برگردونیم، ولی وقت بیشتری می‌بره. و خطرش هم خیلی بیشتر خواهد بود."

    # say L748 bri
    old "All thanks to you and that stupid little shinigami with which you have been playing."
    new "همه این‌ها به خاطر تو و آن شینیگامی کوچک و بی‌فایده‌ای است که با او بازی می‌کردی."

    # say L749 pla
    old "I'm sorry Brixxida, all I wanted was to help, you know?"
    new "بrixxیدا، معذرت، من فقط می‌خواستم کمک کنم، می‌دونی؟"

    # say L753 bri
    old "Hmph."
    new "همف."

    # say L754 pla
    old "So, what can we do to make the portal work?"
    new "پس، چه کاری می‌تونیم بکنیم تا دروازه کار کنه؟"

    # say L755 bri
    old "Well, the only way is to seed the magic power..."
    new "البته، تنها راه اینه که توانایی جادویی رو بذر بکنیم..."

    # say L757 pla
    old "Seed the magic power? What's that?"
    new "توان سحر را بذر کنیم؟ این چیه؟"

    # say L758 bri
    old "It's a magic ritual we use to concentrate magic power."
    new "این یک مراسم جادوییه که برای متمرکز کردن توان جادویی استفاده می‌کنیم."

    # say L759 bri
    old "By incubating it inside the bodies of humans."
    new "با آن را در داخل بدن انسان‌ها تکثیر می‌کنیم."

    # say L760 bri
    old "The power grows and concentrates over time. Until it finally flows out and into the portal."
    new "توی زمان قدرت رشد می‌کنه و تمرکز می‌شه. تا اون موقعی که بالاخره خارج شه و وارد دروازه شه."

    # say L762 pla
    old "Ok, I think I get it. So, how do we do it?"
    new "باشه، فهمیدم. پس چطور باید این کار رو انجام بدیم؟"

    # say L763 bri
    old "There's only one real way to do it. You have to plan the seed inside the body."
    new "فقط راه واقعی برای انجام این کار وجود دارد. باید بذر را در داخل بدن برنامه‌ریزی کنی."

    # say L764 bri
    old "Once inside it gestates and grows, until it's time to come out."
    new "باز هم داخلش رشد می‌کنه تا وقتی برای خروج رسیده باشه."

    # say L766 pla
    old "Ok, but how do I do it?"
    new "باشه، ولی چطور باید این کار رو انجام بدم؟"

    # say L768 bri
    old "Well, you have to seed them the same way you gather and give magic power out."
    new "خب، باید مثل اینکه جادو رو جمع کنی و بدهی، آنها رو هم بذر بدی."

    # say L769 pla
    old "Woah! Woah! Woah! You mean I have to impregnate them?!"
    new "وای! وای! وای! منظورت اینه که باید آنها رو باردار کنم؟!"

    # say L771 bri
    old "In human terms, that's what it's called, yeah."
    new "در زبان انسان‌ها، همین اسم داره، بله."

    # say L773 pla
    old "What the fuck? Are you for real?"
    new "چه خبره؟ شما جدی می‌گی؟"

    # say L774 pla
    old "I'm way too young to have children!"
    new "من خیلی جوان هستم برای داشتن بچه!"

    # say L782 bri
    old "But don't worry, it's not the way you think."
    new "ولی نگران نباش، اینجوری فکر نکن."

    # say L784 bri
    old "During the growing period, the magic power will concentrate without a particular form."
    new "در دوره رشد، قدرت جادویی بدون شکل خاصی متمرکز خواهد شد."

    # say L787 bri
    old "And it will only change if, you decide it to be anything in particular."
    new "و فقط اگر تو تصمیم بگیری که هیچ شکل خاصی باشه، تغییر خواهد کرد."

    # say L789 bri
    old "It means that if you just take out all of the magic power from these women it will just be energy."
    new "این بدان معناست که اگر همه توان جادویی این زنان رو بیرون ببری، فقط انرژی خواهد بود."

    # say L790 bri
    old "Pure magic energy, without any form in particular."
    new "انرژی جادویی خالص، بدون هیچ شکل خاصی."

    # say L791 bri
    old "And it will only take the shape of a human infant if you decide that you will leave energy remains behind."
    new "و فقط اگر تصمیم بگیری که انرژی باقی مونده رو برگذاری، شکل یک نوزاد انسانی خواهد گرفت."

    # say L793 bri
    old "Otherwise there won't be any reproduction between you and the humans we use for this ritual."
    new "در غیر این صورت بین تو و انسان‌هایی که برای این مراسم استفاده می‌کنیم تولید مثلی نخواهد بود."

    # say L795 pla
    old "I- I see, I guess that's..."
    new "بگویم، حدس می‌زنم اینطوره..."

    # say L796 pla
    old "Fine, I guess?"
    new "باشه، حدس می‌زنم."

    # say L798 bri
    old "However, until the magic power is ready to be taken out of their bodies and we do it."
    new "البته، تا زمانی که قدرت جادویی آماده شده و ما آن را از بدن‌شان بیرون ببریم."

    # say L799 bri
    old "They will look like they are pregnant."
    new "آنها مثل باردار خواهند بود."

    # say L801 bri
    old "The entire process it's going to be very similar to the way you humans gestate your infants."
    new "کل فرآیند خیلی شبیه به نحوه‌ی حمل و زایمان شما انسان‌ها خواهد بود."

    # say L802 bri
    old "Is just that at the end of it, there won't necessary be another human."
    new "فقط اینجاست که در پایان، لزوماً انسان دیگری وجود نخواهد داشت."

    # say L803 bri
    old "So, their bodies will just go back to how they were before the ritual started."
    new "پس، بدنه‌هاشون فقط به همون حالت قبل از شروع مراسم بر می‌گردند."

    # say L805 pla
    old "I get it now."
    new "الان متوجه شدم."

    # say L806 bri
    old "Listen, I know you don't like it."
    new "بگوش، میدونم دوستت نداره."

    # say L807 bri
    old "But for now, that's the only way we have to power up the portal and return the magic world to what it was before."
    new "اما برای حالا، این تنها راهیه که می‌تونیم دروازه رو تقویت کنیم و جادوگری رو به همین شکل قبلی برگردانیم."

    # say L808 bri
    old "Not to mention avoiding the destruction of yours."
    new "البته، بدون اینکه جهان جادویی خراب شود."

    # say L809 pla
    old "I get it."
    new "فهمیدم."

    # say L810 pla
    old "If I have to do it, I guess there's no choice."
    new "اگه باید انجام بدم، حدس می‌زنم هیچ انتخابی ندارم."

    # say L811 bri
    old "By the way; from now on, I will be in charge of everything, you get that?"
    new "باید درک کردی از این به بعد من همه چی رو کنترل می‌کنم، چی؟"

    # say L815 bri
    old "No more running around like an idiot with you dumbass shinigami friends messing everything up!!"
    new "دیگه نمی‌تونم مثل احمق پیش و پیش برم و دوستات شینیگامی همه چی رو خراب کنن!!"

    # say L816 pla
    old "Uh. I- sure..."
    new "اوه. من- حتماً..."

    # say L817 bri
    old "Good, I'm glad you understand that."
    new "خوب، خوشحالم که فهمیدی."

    # say L819 bri
    old "Now, get ready, because there are a lot of things you will need to learn about all of this."
    new "حالا آماده شو، چون باید خیلی چیزهایی رو در مورد این همه چیز یاد بگیری."

    # say L820 pla
    old "Oh, man... Alright..."
    new "اوه، بچه‌من... خوب..."

    # say L828 pla
    old "I guess I'll leave you here for now..."
    new "من حدس می‌زنم حالا تو اینجا می‌مونی..."

    # say L829 pla
    old "I'm so sorry, about this Linnet."
    new "من خیلی متاسفم از این، لینت."

    # say L830 pla
    old "I promise that I will help you to get free from this."
    new "بله، قول می‌دم که به تو کمک کنم از اینجا آزاد شی."


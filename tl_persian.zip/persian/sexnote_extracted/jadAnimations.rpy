# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/jadAnimations.rpy
translate persian strings:

    # say L6 milJad
    old "I must say... Mmmm, the size of your dick never stops being surprising."
    new "باید بگم... مmmm، اندازه‌ی ناخودت هیچ وقت خیال‌کردن‌پرداز نیست."

    # say L7 milJad
    old "It’s impressive."
    new "البته، شگفت‌انگیز است."

    # say L8 milJad
    old "And this scent... I had never perceived it."
    new "و این بو... هرگز آن را حس نکرده بودم."

    # say L9 milJad
    old "It’s... nice."
    new "البته... خوبه."

    # say L13 milJad
    old "Are you enjoying this?"
    new "این رو لذت می‌بری؟"

    # say L14 milJad
    old "I ask because it’s important for you to cum."
    new "من اینجوری می‌پرسم چون برایت مهمه که برسی."

    # say L15 pla
    old "It feels good."
    new "احساسی خوبه."

    # say L16 milJad
    old "Mmmmm!"
    new "میل‌جاد: مممم!"

    # say L20 milJad
    old "This sensation! I’d never felt it before!"
    new "این احساس! هیچ وقت اینطور نبوده!"

    # say L21 milJad
    old "Ughh... It hurts, but it feels so good!"
    new "اوه... درد می‌کنه، ولی خیلی لذت‌بخشه!"

    # say L22 milJad
    old "I- I’m enjoying it!"
    new "من- من لذت می‌برم!"

    # say L45 pla
    old "I don’t think I will last longer!"
    new "فکر نمی‌کنم بتوانم طول بکشم!"

    # say L46 milJad
    old "It’s ok, cum for me!"
    new "خوبه، برای من بیا!"

    # say L47 milJad
    old "Slurrp!!"
    new "سلورپ!!"

    # say L48 milJad
    old "Cum! Give me the magic!"
    new "آهای! بده به من جادویت!"

    # say L54 mil
    old "That... that was unexpected."
    new "این... این غیرمنتظره بود."

    # say L55 pla
    old "Are you ok?"
    new "تو خوبی؟"

    # say L56 mil
    old "I’m fine."
    new "من خوبم."

    # say L57 mil
    old "It’s just that I wasn’t expecting that."
    new "فقط اینجاست که من انتظار نداشتم."

    # say L58 mil
    old "The act feels so different with a human body."
    new "این عمل با بدن انسانی خیلی متفاوت است."

    # say L59 mil
    old "And to be able to feel all that. Linett’s spell is very complete!"
    new "و تونستن همه اینا رو حس کنم. لینت حق باهاش داره، این呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟"

    # say L60 pla
    old "Ah... sure. Hey listen, I think we need to get going before we’re discovered here."
    new "آ... البته. چریس، باید بر می‌رسیم قبل از اینکه اینجا کشف بشیم."

    # say L61 pla
    old "I’ll clean Mrs. Jade, and then we take off. Ok?"
    new "من جدی را تمیز می‌کنم، بعد از هم می‌رویم. خوب؟"

    # say L75 jad
    old "(Mmm, it feels so nice...)"
    new "(مم، اینجوری خوب می‌تونم حس کنم...)"

    # say L76 jad
    old "(Uhh... A- am I moving? God, I- I can't control it... I hope [pla] doesn't notice.)"
    new "(اوه... آ- آیا من حرکت می‌کنم؟ خداوند، من- من نمی‌توانم کنترل کنم... امیدوارم [pla] متوجه نشده باشه.)"

    # say L77 pla
    old "(Wait, is she moving? What the-)"
    new "(بیا، آیا تو حرکت می‌کنی؟ چه کار-)"

    # say L81 pla
    old "(Wow... Yeah, she is definitely moving... Geez, and just in front of Hinn...)"
    new "واو... بله، قطعاً در حال حرکت است... خودت می‌بینی، همین جلوی هین..."

    # say L82 hin
    old "Hey, talking about dad, I saw he deleted the post about his marriage."
    new "بگو، درباره پاپا، دیدم پست ازدواجش رو حذف کرده."

    # say L83 hin
    old "Kinda late, we already saw it."
    new "متأخر شدی، ما قبلاش دیدیم."

    # say L84 jad
    old "Mmm... Yeah, he’s just like that."
    new "ممنون... آره، همینطور هست."

    # say L85 jad
    old "Not surprising..."
    new "متعجب نیستم..."

    # say L89 jad
    old "(Oh my God! I can't help myself anymore, this feels so fucking good.)"
    new "اوه خداوند! دیگه نمی‌تونم خودمو کنترل کنم، این حس خیلی خوبه."

    # say L90 jad
    old "Ahh! Ahh!"
    new "اوه! اوه!"

    # say L93 jad
    old "(Holy cow!) U- uh, nothing, I just hurt my toe."
    new "اوه خداوند! نه، هیچی، فقط انگشت پایم خورد."

    # say L94 jad
    old "A- accidentally."
    new "ا- اتفاقی."

    # say L95 hin
    old "Oh, you should be more careful."
    new "اوه، باید مراقبت بیشتری کنی."

    # say L96 jad
    old "Yes honey, hehe, how silly of me..."
    new "بله عزیزم، ههه، چقدر خنده‌دارم..."

    # say L121 jad
    old "Are you about to finish?"
    new "تو هم در حال تمام شدنی؟"

    # say L122 hin
    old "Yeah, I’m almost done."
    new "بله، تقریباً تمام شدم."

    # say L123 jad
    old "Me too..."
    new "من هم..."

    # say L130 hin
    old "Well, that was a relief, I’m sorry I interrupted your shower."
    new "خب، این راحت کننده بود، متاسفم که شورتت رو قطع کردم."

    # say L132 jad
    old "Don’t worry honey."
    new "نگران نباش عزیزم."

    # say L133 hin
    old "I have to get going, gotta get back to school."
    new "من باید برم، باید به مدرسه برگردم."

    # say L134 jad
    old "Sure honey."
    new "بله عزیزم."

    # say L137 jad
    old "(Oh my god! What did I just do?)"
    new "اوه خداوند! من چه کاری انجام دادم؟"

    # say L138 jad
    old "I- I think we should get out of this tub [pla]."
    new "باید از این حمام بیرون بیایم [pla]."

    # say L139 pla
    old "Uhh, right, right."
    new "آره، درسته، درسته."

    # say L152 jad
    old "Oh yeah, this feels so nice.."
    new "اوه بله، این خیلی خوبه.."

    # say L153 jad
    old "Mmm, I want that big hard cock inside of me!"
    new "ممن، من می‌خوام اون لوله بزرگ و سخت رو داخلم بیاد!"

    # say L154 jad
    old "I need it."
    new "من نیاز دارم."

    # say L158 jad
    old "Uhh, I- it’s the biggest cock I’ve seen!"
    new "اوه، اون- اون یه لوله بزرگترینیه که تا حالا دیدم!"

    # say L159 jad
    old "Oh God! I- I want to be fucked by him!"
    new "اوه خداوند! من- من می‌خوام ازش ناکاری شم!"

    # say L160 pla
    old "(She's thinking about someone she knows?)"
    new "(او درباره کسی که می‌شناسه فکر می‌کنه؟)"

    # say L164 jad
    old "Mmm... I want him to fuck me like he fucks Hinn!"
    new "ممن... من می‌خوام اون جوری با من بکنه مثل هین!"

    # say L165 pla
    old "(Woah! Woah! She's not thinking about me, right?!)"
    new "واو! واو! اونجور نمی‌تونه درباره من فکر کنه، درسته؟!"

    # say L166 jad
    old "Oh yes, yes, yes!!"
    new "اوه بله، بله، بله!!"

    # say L167 jad
    old "I want to feel that hard cock inside me!"
    new "من می‌خوام اون نیم‌پا سخت رو داخلم حس کنم!"

    # say L168 jad
    old "That young, thick, hard, cock!"
    new "آن نوزاد، ضخیم، سخت، نیم‌پا!"

    # say L191 jad
    old "AH! AH! Ohhh I'm cumming, I'm cumming!"
    new "آه! آه! اوه، من در حال خروج هستم، من در حال خروج هستم!"

    # say L192 jad
    old "YES! YES! YES! YES!"
    new "بله! بله! بله! بله!"

    # say L198 jad
    old "Phew, that felt so good."
    new "آه، این خیلی خوب بود."

    # say L199 jad
    old "I needed that."
    new "من اینو نیاز داشتم."

    # say L200 jad
    old "But, it’s still not the same as a dick."
    new "ولی هنوز هم مثل پوس نیست."

    # say L203 jad
    old "Wait, what was that sound?"
    new "پس، اون صدایی چی بود؟"

    # say L211 jad
    old "Mmmm, that was a huge cock!"
    new "ممنن، اون یک ناخنده عجیب بود!"

    # say L212 pla
    old "(Is she talking about my...)"
    new "(آیا درباره من می‌گه...)"

    # say L213 jad
    old "Oh god, it barely fit in my mouth, and it tasted so good..."
    new "اوه خدا، تقریباً تو دهانم جا نمی‌گرفت و طعمش خیلی خوب بود..."

    # say L217 jad
    old "Oh my God! I had never felt this before..."
    new "اوه خداوند! هیچ وقت این حس را تجربه نکرده بودم..."

    # say L218 jad
    old "Mmmm, I want that cock so badly..."
    new "ممم، من خیلی می‌خوام اون ناخن رو ببینم..."

    # say L223 jad
    old "Ahhh! Ahh! Ah!"
    new "اوه! اوه! اوه!"

    # say L224 jad
    old "I- I want your big dick inside me [pla]!"
    new "من- من می‌خوام ناخن بزرگتو داخلم باشه [pla]!"

    # say L225 jad
    old "I love you big cock!"
    new "من عاشق نوزک تو هستم!"

    # say L248 jad
    old "Ahh! Ahhh! I want you to fill me up!"
    new "اوه! اوه! می‌خوام تو من رو پر کنی!"

    # say L249 jad
    old "Yes! Yes! Oh, this is so good!"
    new "بله! بله! اوه، این خیلی خوبه!"

    # say L250 jad
    old "I- I’m cumming!"
    new "من- من آمدم!"

    # say L256 jad
    old "Phew... I bet that surprised you."
    new "پوف... حتماً شوکت کردم."

    # say L257 pla
    old "(Is she talking to me?)"
    new "(آیا به من می‌گپی؟)"

    # say L258 jad
    old "Sorry I couldn't help it, I've been a bit horny lately."
    new "متأسفم نتونستم خودمو کنترل کنم، اخیراً خیلی خوشحالم."

    # say L265 jad
    old "It’s ok, I knew you were there [pla], it’s just that I needed to loosen up a little bit before."
    new "باشه، می‌دونستم تو اینجا بودی [pla]، فقط باید یه کم آرام می‌شدم قبل از این."

    # say L266 pla
    old "Uhh... Before? Before what?"
    new "اوه... قبل؟ قبل از چی؟"

    # say L267 jad
    old "Before this."
    new "قبل از این."

    # say L288 whi
    old "I love how big is his cock, isn't it?"
    new "من عاشق این هستم که چقدر بزرگ است، نه؟"

    # say L289 whi
    old "Are you enjoying the view Jade?"
    new "آیا از منظر لذت می‌بری جید؟"

    # say L294 whi
    old "Mmm, yeah, have you ever seen a deep throat, Jade?"
    new "ممنون، جیید، دیده‌ای کسی چنین چیزی رو عمیق ورودی کرده؟"

    # say L295 whi
    old "Do you like what I'm doing with my mouth?"
    new "می‌پسندی این کاری که با دهانم انجام می‌دم؟"

    # say L300 whi
    old "What about if I get an oral creampie, would you like to see that jade?"
    new "اگر من جیزمه دهانی بگیرم، می‌خوای اینو ببینی جید؟"

    # say L301 jad
    old "Mmmm..."
    new "ممنون، ولی من این جوری حرف نمی‌زنم. اگر می‌خوای ادامه بدهیم، لطفاً موضوع رو تغییر بدی."

    # say L302 whi
    old "That's all what I need to know."
    new "این همه چیزیه که باید بدانم."

    # say L325 pla
    old "Mmmm, I- I think I'm about to-"
    new "ممم، من- من فکر می‌کنم در حال رسیدن هستم-"

    # say L326 whi
    old "Yes! Do it! Show Jade what she's been missing!"
    new "بله! انجام بده! به جید نشون بده چه چیزی رو از دست داده!"

    # say L327 whi
    old "You want it too, don't you Jade?"
    new "تو هم می‌خوای، درسته جید؟"

    # say L328 whi
    old "You also want him to push this big hard dick in you mouth?"
    new "آیا تو هم می‌خوای این پیپ بزرگ و سخت رو تو دهانت بیاندازند؟"

    # say L340 whi
    old "Mmm, are you ready for your turn?"
    new "می‌تونی برای نوبتت آماده شی؟"

    # say L342 whi
    old "Well? Do you want to try it, isn't it?"
    new "خب؟ می‌خوای امتحانش کنی، نیست؟"

    # say L343 jad
    old "Uhh, I- I do."
    new "اوه، من- من هم می‌خوام."

    # say L344 whi
    old "Good! I'm glad you're finally admitting it."
    new "خوب! خوشحالم که در نهایت اعتراف می‌کنی."

    # say L345 whi
    old "Great, now let's do it!"
    new "عالی، حالا بیایید انجام بدیم!"

    # say L354 whi
    old "That's it, girl, just relax, don’t think about anything else other than what you have in your mouth right now."
    new "بفرما، دختر، فقط آرام با، به هیچ چیزی غیر از چیزی که تو دهانت داری فکر نکن."

    # say L356 whi
    old "He must be enjoying this as hell, two sexy MILFS sucking his dick, that should be like heaven. Isn't it [pla]?"
    new "این حتماً برایش خیلی لذت‌بخش است، دو مامان جذاب که ناخودآگاه شصتشون رو می‌کشند، این مثل بهشت باید باشه. نیست [pla]؟"

    # say L357 pla
    old "Uhh... Mmmm, yeah..."
    new "اوه... مم، بله..."

    # say L358 whi
    old "Hehe, enjoy this huge cock Jade."
    new "هههه، از این نیم‌پاچه لذت ببر جید."

    # say L367 whi
    old "I bet you've been wanting to get his hot dick in your mouth for a while, haven't you?"
    new "حتماً از قبل می‌خواستی این لولای گرمش رو تو دهانت وارد کنی، همینطور نیست؟"

    # say L368 jad
    old "Mmmm!"
    new "ممنون، وایل! این واقعاً خوبه."

    # say L369 whi
    old "Hahaha, that's all the answer I needed."
    new "هahaha، این همه جوابی که نیاز داشتم بود."

    # say L373 whi
    old "I can tell you girl, this is about a hundred times better than your ex-husband's limp dick!"
    new "می‌تونم بگم جون، این صد برابر بهتره از نیم‌پرده‌ی همسرت قدیمی!"

    # say L374 jad
    old "Slrrrrp! Mmmm, yeah!"
    new "سللللپ! مم، بله!"

    # say L375 whi
    old "Mmmm, how sexy you look with a big cock in your mouth."
    new "ممنن، چقدر جنسی به نظر می‌رسی وقتی یه ذکر بزرگ تو دهانت هست."

    # say L379 whi
    old "Oh yeah baby! let's make him cum. You want him to cum in your mouth and taste that big load, right?"
    new "اوه بله بیبی! بیایید اون رو بیاورد. می‌خوای اون رو تو دهنت بیاورد و آن لخت خوب رو بخوری، درسته؟"

    # say L380 jad
    old "...Y- yes, I want it..."
    new "...بله، من می‌خواهم..."

    # say L381 whi
    old "You already heard it please, don't hold back and give us a huge cumshot."
    new "قبلاً شنیدی، لطفاً نگه نداشته و برای ما یک آبشار بده."

    # say L405 pla
    old "I- I think I’m about to...!"
    new "من فکر می‌کنم خیلی زود برمی‌آیم...!"

    # say L406 whi
    old "That’s it, cum for us baby!"
    new "بفرست برای ما عزیزم!"

    # say L407 whi
    old "I want you to cum in her mouth!"
    new "من می‌خوام تو دهانش بیایی!"

    # say L408 whi
    old "You are going to drink every single drop, Jade."
    new "تو هر قطره را خواهی گرفت، جید."

    # say L415 whi
    old "Ohh yeah, that was a huge load. Did you enjoy it Jade?"
    new "اوه بله، اونقدر زیاد بود. لذت برده بودی جید؟"

    # say L416 jad
    old "Uhh... Y- yes..."
    new "اوه... ب- بله..."

    # say L417 whi
    old "What did I tell you? This is a lot better than masturbating."
    new "من بهت چی گفتم؟ این خیلی بهتره از اینکه خودت کار کنی."

    # say L418 whi
    old "And with such a young gifted man, you didn’t know what you were missing on girl."
    new "و با چنین مرد جوان و موهبت‌داری، نمی‌دونستی چه چیزی رو از دست داده‌ای، دختر."

    # say L419 jad
    old "I- I suppose you’re right."
    new "ب- باید درست می‌گویی."

    # say L420 whi
    old "You know I’m right. Now let me help you clean up all this mess."
    new "میدونی من درست می‌گم. حالا بیا برام کمک کنم تا این همه خرابی رو تمیز کنیم."

    # say L432 pla
    old "Uhh, w- what is happening?"
    new "اوه، ا- اینجوری چه اتفاقی افتاد؟"

    # say L433 jad
    old "Well, you know what Mrs. White said last time."
    new "خب، می‌دونی خانم وایت آخرین بار چه گفت."

    # say L434 jad
    old "Maybe we should try to do some of this on our own."
    new "شاید باید برای خودمون کمی این کار رو انجام بدیم."

    # say L436 jad
    old "To be honest, I’ve been thinking about this way too much, it’s about time I do something about it."
    new "صusch، من از این موضوع خیلی فکر کردم، وقت شده که برایش کاری بکنم."

    # say L440 jad
    old "Hmph! Slrrrp!"
    new "همپ! سلرپ!"

    # say L441 jad
    old "I can kind of see why Hinn likes you so much."
    new "می‌فهمم چرا هین ازت خوشش می‌آید."

    # say L442 jad
    old "How could she not? With such an amazing cock!"
    new "چطور می‌تونه نه؟ با چنین ناخن خوبی!"

    # say L446 jad
    old "I love how hot your cock is?"
    new "عشق دارم چقدر گرم و خیسی که تویی؟"

    # say L447 jad
    old "Are you liking it, honey?"
    new "حلا، عزیزم، چقدر این کار رو دوست داری؟"

    # say L448 pla
    old "Mmm, yeah..."
    new "ممنون، جد. همینطور من هم لذت می‌برم، عزیزم."

    # say L449 jad
    old "Me too!"
    new "من هم!"

    # say L472 pla
    old "I- I think I’m about to cum!"
    new "من- من فکر می‌کنم همین جا خواهم آمد!"

    # say L473 jad
    old "It’s ok, you can cum in my mouth!"
    new "باشه، می‌تونی تو دهانم بیاد!"

    # say L474 jad
    old "I want to taste it again!"
    new "می‌خوام دوباره طعمش رو ببرم!"

    # say L481 jad
    old "Phew, that was really good [pla]."
    new "پوف، این واقعاً خوب بود [pla]."

    # say L494 jad
    old "OH MY GOD!! Oh wow!"
    new "اوه خداوند!! اوه وای!"

    # say L495 whi
    old "Hahaha, he’s huge isn’t he?"
    new "ههههه، خیلی بزرگه، همینطور نیست؟"

    # say L496 whi
    old "Just relax and enjoy it girl."
    new "فقط آرام شو و ازش لذت ببر دختر."

    # say L497 whi
    old "Not always can you enjoy something like this."
    new "همیشه نمی‌تونی از چیزایی مثل این لذت ببری."

    # say L501 jad
    old "Ah! Ah! I can’t! This is just too good!"
    new "آه! آه! نمی‌تونم! این خیلی خوبه!"

    # say L502 whi
    old "Yeah that’s right, take it all."
    new "بله، همین‌جوری، همه‌ش رو بگیر."

    # say L503 whi
    old "Ha! I bet that looser of your ex-husband never fucked you like this!"
    new "ها! حتماً آن خسته‌کار همسر پیشینت هیچ وقت تو رو اینجوری نمی‌زد!"

    # say L504 whi
    old "What do you say [pla]? How does it feel to have two MILFS like us just for you?"
    new "[pla]، چه می‌گی؟ این حس رو چطور تجربه می‌کنی که دو مادربزرگ مثل ما فقط برایت هستیم؟"

    # say L508 whi
    old "Did you ever feel anything like this before, Jade?"
    new "قبل هیچی مثل این حس نکردی، جید؟"

    # say L509 jad
    old "Ahh! Ahh! O- of course not!"
    new "آه! آه! ن-نه، هیچ وقت احساسی مثل این نداشتم!"

    # say L510 whi
    old "Hahaha, I love to see you like this!"
    new "حاحاحا، دوست دارم تو رو اینجور ببینم!"

    # say L511 whi
    old "Enjoy it girl, you deserve it!"
    new "لذت ببر دختر، تو این رو سربلند می‌آیی!"

    # say L534 whi
    old "Keep going [pla]!"
    new "ادامه بده [pla]!"

    # say L535 whi
    old "You’re about to make her cum!"
    new "تو در حال این هستی که اونجا به او می‌رسونی!"

    # say L536 whi
    old "Don’t stop! Don’t stop now!"
    new "توقف نکن! حالا توقف نکن!"

    # say L538 jad
    old "Ahhhh, Ahhhhh!"
    new "آه، آه!"

    # say L544 jad
    old "Oh my! That was great, really great."
    new "اوه، خیلی خوب بود، واقعاً خوب."

    # say L545 whi
    old "And look at that, he just came and he’s still hard!"
    new "ببین، فقط اومده و هنوز سخته!"

    # say L546 whi
    old "It must be great to be that young!"
    new "باید عالی باشه همینجور جوان بودن!"

    # say L547 whi
    old "But now it’s my turn."
    new "اما حالا دوره من است."

    # say L548 whi
    old "Come here [pla], I want you to fuck me hard."
    new "اونجا بیا [pla]، می‌خوام تو مرا سخت بکنی."

    # say L565 whi
    old "Nngh! Oh yeah, that’s it!"
    new "اوه بله، همینه!"

    # say L566 whi
    old "That’s just what I have been waiting for."
    new "این همین است که منتظرش بودم."

    # say L567 whi
    old "Uhhh, it just fills me up!"
    new "اوه، فقط من رو پر می‌کنه!"

    # say L571 whi
    old "Ah! Ah! Ah! It’s so big!"
    new "آه! آه! آه! اینقدر بزرگه!"

    # say L572 whi
    old "I want to keep being fucked by you everyday!"
    new "من می‌خواهم هر روز توسط تو ناکام شوم."

    # say L577 whi
    old "I- I never had any sex like this with my ex-husband either!"
    new "من- من هیچ جنسی مثل این با همسر پیشینم هم نداشتم!"

    # say L578 whi
    old "It’s unbelievable how good this is!"
    new "اینقدر خوب بودن این قابل باور نیست!"

    # say L579 whi
    old "Keep going [pla]! Keep pounding my pussy!"
    new "ادامه بده [pla]! از پوسی من خشک نشه!"

    # say L580 whi
    old "Yes! yes! yes!"
    new "بله! بله! بله!"

    # say L603 pla
    old "Mrs. White, I can’t hold it in any longer!"
    new "خانم واایت، دیگه نمی‌تونم خودمو کنترل کنم!"

    # say L604 whi
    old "Cum! Cum inside me!"
    new "بیا جوش! درون من جوش!"

    # say L605 whi
    old "Oh my God! I have missed this cock so much!"
    new "اوه خداوند! این ناخودآگاهی را خیلی دوست داشتم!"

    # say L606 whi
    old "I love being fucked by you!"
    new "من عاشق شدن از تو ناکارآمد می‌شوم!"

    # say L613 whi
    old "Well, I must say that was wonderful."
    new "باید بگم این خیلی عالی بود."

    # say L614 whi
    old "Just look at you Jade! You look so calm and relaxed now!"
    new "جید، نگاه کن به تو! حالا اینقدر آرام و راحت هستی!"

    # say L615 jad
    old "Yeah, I think you’re absolutely right!"
    new "بله، فکر می‌کنم کاملاً درست می‌گویی."

    # say L616 jad
    old "I can’t believe how relaxed I am!"
    new "نمی‌تونم باور کنم چقدر آرام هستم!"

    # say L617 jad
    old "I must say, I don’t even care about what’s happening with Hiashi right now. I hope he’s very happy with his new wife."
    new "باید بگم، حتی نگران هیاشی هم نیستم. امیدوارم با همسر جدیدش خیلی خوشحال باشه."

    # say L618 jad
    old "If she doesn’t cheat on him."
    new "اگر همسرش به او خیانت نکنه."

    # say L619 whi
    old "Hahahaha!"
    new "حاحاحا!"

    # say L620 jad
    old "Hahahaha."
    new "حاحاحا."

    # say L621 whi
    old "Well, I think we should better get dressed before your daughter gets home."
    new "خب، فکر کنم بهتره قبل از برگشتن دخترت پوشیدنشون بذاریم."

    # say L622 jad
    old "Right, right."
    new "بله، درست می‌گیه."

    # say L636 jad
    old "I- it's so big... Oh my God!"
    new "ا- اینقدر بزرگه... خدا نجات!"

    # say L637 jad
    old "Mmmm [pla]! I could get addicted to your cock!"
    new "ممنون ز[pla]! می‌تونم به ناخودآگاهی تو اعتیاد پیدا کنم!"

    # say L638 jad
    old "No wonder Hinn always wants to fuck with you!"
    new "البته هین همیشه می‌خواسته با تو جنس کنه!"

    # say L643 jad
    old "It’s so hot! So thick and hard!"
    new "آتشینه! خیلی ضخیم و سخته!"

    # say L644 jad
    old "I can’t resist it!"
    new "نمی‌تونم مقاومت کنم!"

    # say L648 jad
    old "Yes! Yes! Yes! Keep going!"
    new "بله! بله! بله! ادامه بده!"

    # say L649 jad
    old "Just like that!"
    new "همینطور!"

    # say L650 jad
    old "Fuck me, fuck me harder [pla]!"
    new "بزن بر من، بیشتر بزن [pla]!"

    # say L651 jad
    old "Ahhh! I love it!"
    new "اوه! عاشق اینم!"

    # say L674 jad
    old "I'm about to cum honey!"
    new "من همین جا می‌آیم حلوه!"

    # say L676 jad
    old "L- let's do it!"
    new "بیا، این کار رو بکنیم!"

    # say L677 jad
    old "Let's cum together!!"
    new "بیای بیا، هم‌زمان برسیم!"

    # say L685 jad
    old "Wow, that was wonderful honey."
    new "واو، این خیلی عالی بود حلوایی."

    # say L686 jad
    old "And the shower it’s also working perfectly."
    new "و دوش بر هم کاملاً خوب کار می‌کنه."

    # say L687 jad
    old "Oh my God! It's too late, Come on honey, let’s get dressed."
    new "اوه خداوند! وقتش خیلی دیره، بیا عزیزم، بیای لباس پوشیم."


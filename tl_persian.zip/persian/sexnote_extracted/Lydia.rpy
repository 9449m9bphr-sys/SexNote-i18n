# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Lydia.rpy
translate persian strings:

    # say L60 lyd
    old "No Anna, you can't live your life like this."
    new "نه آنا، نمی‌توانی اینجور زندگی کنی."

    # say L62 ann
    old "I'm already big enough to decide what I do with my life."
    new "من قطعاً بزرگ‌تر هستم تا درباره زندگی‌ام تصمیم بگیرم."

    # say L64 lyd
    old "Yes, but in recent weeks you have been drinking excessively and even using drugs!"
    new "بله، اما در هفته‌های اخیر خیلی آشامیدی و حتی مواد مخدر استفاده کردی!"

    # say L66 lyd
    old "I'm very worried about you, about your health, I know your father's loss was not easy, it hurts me a lot too-"
    new "من خیلی نگران تو هستم، نگران سلامتت، می‌دونم از برداشتن پدرت آسون نبوده، برای من هم خیلی دردناکه-"

    # say L68 ann
    old "it has nothing to do with it... I just want to enjoy my life, I don't want to live locked up and self-conscious like... You."
    new "این هیچ ربطی به آن نداره... من فقط می‌خوام زندگیم رو لذت ببرم، نمی‌خوام مثل تو خودمو قفل کنم و همیشه احساس خودآگاهی کنم."

    # say L76 ann
    old "Anyway... Don't wait for me tonight..."
    new "بازهم... امشب منتظرم نباش..."

    # say L80 lyd
    old "I'm sorry you heard that... Things have not been very easy for either of us."
    new "متاسفم که اینجور شنیدی... برای هیچ‌کدوم از ما روزهای خوبی نبوده."

    # say L82 pla
    old "I'm very sorry, I just came to accompany you a little..."
    new "خیلی متاسفم، فقط برای همراهیت یکم بیام..."

    # say L85 lyd
    old "Aww thank you very much pumpkin."
    new "اوه ممنون بسیار عزیزم."

    # say L87 lyd
    old "But you don't have to worry, I know you have your things to do, and at the moment I don't feel very well."
    new "اما نگران نباش، می‌دونم کارهایت هست و الان خوب حس نمی‌کنم."

    # say L89 pla
    old "Hmm, is it because of the discussion with Anna?"
    new "Hmm، آیا به خاطر صحبت با آننا هست؟"

    # say L91 lyd
    old "Yes honey, she was greatly affected by her father's death and has been... Quite bad lately."
    new "بله عزیزم، او خیلی تحت تأثیر مرگ پدرش قرار گرفته و اخیراً... خیلی بد است."

    # say L93 pla
    old "I understand, I can come another day if you want."
    new "فهمیدم، می‌تونم روز دیگه‌ای بیام اگه می‌خوای."

    # say L95 lyd
    old "You know what? Yes, come over the weekend and come with me to church, are you okay with that?"
    new "دیت روش؟ بله، هفته آینده بیا و همراه من به کلیسا برو، این جوری خوبه؟"

    # say L97 pla
    old "Perfect! I will come in the weekend."
    new "عالی! هفته آینده می‌آیم."

    # say L99 lyd
    old "Great, thank you for your visit and support honey, I really appreciate it."
    new "عالی، ممنون از میهمانی و حمایتت عزیزم، خیلی از این قدردانی می‌کنم."

    # say L101 pla
    old "Don't worry, I'm glad for helping you..."
    new "نگران نباش، خوشحالم که به تو کمک کردم..."

    # say L120 lyd
    old "Oh hi pumpkin, did you come to help me with the dating app?"
    new "اوه سلام عزیزم، آیا برای کمک به من با اپلیکیشن تاریخ‌برداری اومدی؟"

    # say L121 pla
    old "Uhh yeah, how's it going?"
    new "اوه بله، چطوری؟"

    # say L122 lyd
    old "Well, remember we have to do it in the afternoons, because Anna is here in the mornings..."
    new "خب، به خاطر داشتی که ما باید بعد از ظهر این کار رو انجام بدیم، چون آننا صبح‌ها اینجا هست..."

    # say L123 pla
    old "Ohh, you're right! I'm sorry, I totally forgot."
    new "اوه، درست می‌گی، معذرت، کاملاً فراموش کرده بودم."

    # say L124 lyd
    old "Don't worry pumpkin, just come back in a few hours."
    new "نگران نباش عزیزم، فقط چند ساعت بعد برگرد."

    # say L125 pla
    old "Alright, see you later then."
    new "باشه، بعداً می‌بینیم."

    # say L126 lyd
    old "See you later."
    new "ببینم بعداً."

    # say L135 lyd
    old "Hey pumpkin, did you come to accompany me to church?"
    new "سلام عزیزم، آیا برای همراه من به کلیسا اومدی؟"

    # say L137 pla
    old "Of course, are you ready?"
    new "البته، آماده‌ای؟"

    # say L139 lyd
    old "Sure, let's go!"
    new "بله، برویم!"

    # say L146 lyd
    old "Thank you so much for joining me to this mass in commemoration of my husband."
    new "ممنونم از اینکه همراه من به این مراسم خاکسپاری شوهرم آمده‌ای."

    # say L148 pla
    old "Don't worry, it's a pleasure to share with you."
    new "نگران نباش، لذت بردم که با تو هستم."

    # say L150 lyd
    old "Oh honey, you don't know how important is the support like yours right now."
    new "عزیزم، شما نمی‌دونید چقدر حمایت مثل شما الان برای من مهمه."

    # say L153 jon
    old "Hi Lydia, I'm so sorry for your husband, how have you been these past few week?"
    new "سلام لیدیا، برای شوهرت خیلی متاسفم، این چند هفته چطور بوده؟"

    # say L155 lyd
    old "Coping with patience, Mrs. Jones."
    new "با صبر مواجهه می‌کنم، خانم جونز."

    # say L157 jon
    old "Yes, I understand you perfectly, I also lost my husband 5 years ago."
    new "بله، من هم کاملاً متوجهت، من همسرم رو هم پنج سال پیش از دست دادم."

    # say L159 jon
    old "Do you know what helped me? Praying and approach to God."
    new "میدونی چی به من کمک کرد؟ دعا کردن و نزدیک شدن به خدا."

    # say L161 lyd
    old "Yes Mrs. Jones, that's the best."
    new "بله خانم جونز، این بهترین راه است."

    # say L164 jon
    old "I will continue coming to church everyday, giving my life to the lord."
    new "من هر روز به کلیسا خواهم آمد، زندگی‌ام را به خداوند سپرده خواهم کرد."

    # say L166 lyd
    old "Yes... He comforts us..."
    new "بله... او ما را آرام می‌دهد..."

    # say L168 jon
    old "There's nothing like being faithful to the Lord all your life, right Lydia?"
    new "هیچ چیز مثل این نیست که تمام عمرت به خداوند وفادار باشی، درسته لیدیا؟"

    # say L170 lyd
    old "Sure... Excuse me Mrs. Jones, I have to go, I hope to see you soon."
    new "البته... ببخشید خانم جونز، باید برسم، امیدوارم زود به یادت باشم."

    # say L172 jon
    old "Okay Lydia, remember that this is the house of God and here you will always be welcome."
    new "خوب لیدیا، به خاطر داشته باش که این خانه خداوند است و اینجا همیشه خوش آمدی."

    # say L174 lyd
    old "Let's go [pla]."
    new "بیایید برویم [pla]."

    # say L182 pla
    old "Are you feeling alright? You seem a little disturbed."
    new "حالت خوبه؟ نگاهت می‌تونه آشوبه."

    # say L184 lyd
    old "Did you hear what Mrs. Jones said?"
    new "آیا صدای خانم جونز رو شنیدی؟"

    # say L186 pla
    old "Yes, she is a very religious woman, will you accompany her to church?."
    new "بله، او زنی دینی است، آیا تو همراهش به کلیسا می‌روی؟"

    # say L188 lyd
    old "No, no, you don't understand..."
    new "نه، نه، تو نفهمی..."

    # say L190 lyd
    old "I've been thinking... After so many years, I have never lived my life..."
    new "من فکر کردم... بعد از همه این سال‌ها، هیچ وقت زندگی‌ام رو زندگی نکردم..."

    # say L194 lyd
    old "[pla], I've never lived, I've always been a homely woman, I haven't really felt happy."
    new "[pla]، هیچ وقت زندگی نکردم، همیشه زن خانه‌دار بودم، واقعاً خوشحالم نبودم."

    # say L196 lyd
    old "You know when you reach a certain age you start looking back and see what you've lived..."
    new "می‌دونی وقتی به سن خاصی می‌رسی شروع می‌کنی به عقب نگاه کردن و دیدن چه زندگی‌ای داشتی..."

    # say L198 lyd
    old "And after so many years I had conformed to what it should be like."
    new "و بعد از آن همه سال، من به آن شکل که باید باشه تطبیق یافتم."

    # say L200 lyd
    old "But after listening to Mrs. Jones... That's not what I want for my life."
    new "اما بعد از گوش دادن به خانم جونز... این نیست چیزی که من برای زندگی‌ام می‌خوام."

    # say L204 lyd
    old "I already gave my whole life to a man, now he isn't here anymore, I don't want to stay locked up in a church now either."
    new "من قبلاً تمام زندگی‌ام رو به یه مرد دادم، حالا که او دیگه نیست، نمی‌خوام دیگه هم در کلیسا قفل شدم."

    # say L208 lyd
    old "I don't want to be like Mrs Jones in 5 years, it's not what I want for my life..."
    new "من نمی‌خوام پنج سال دیگه مثل خانم جونز باشم، این همچین زندگی‌ای نیست که من بخوام..."

    # say L210 pla
    old "Then, what will you do?"
    new "پس، تو چه کاری می‌کنی؟"

    # say L212 lyd
    old "I think Anna is right... I have to start living my life, live new experiences."
    new "فکر می‌کنم آنا درست می‌گه... باید شروع کنم زندگیم رو زندگی کنم، تجربیات جدیدی ببینم."

    # say L214 lyd
    old "You know? I never had sex with any other man... I really don't know if I enjoyed sex at least!"
    new "دیتی میدونی؟ هیچ وقت با مرد دیگری جنس نکردم... واقعاً نمی‌دونم آیا از جنس لذت برده‌ام یا نه!"

    # say L218 lyd
    old "Today was a revelation for me... and I don't want to bother you anymore."
    new "امروز برای من آشکارا شد... و نمی‌خوام دیگه به تو اغراق بکنم."

    # say L220 lyd
    old "Thank you very much for your company, these days I will be thinking about what I should do with my life."
    new "ممنونم از همراهیت، در این روزها به فکر این می‌گردم که باید چه کنم با زندگی‌ام."

    # say L222 pla
    old "I understand, if you need anything just let me know..."
    new "من متوجه شدم، اگر نیازی به چیزی داشتی فقط به من بگو..."

    # say L224 lyd
    old "In fact I think if I'm going to need several things from you..."
    new "در واقع فکر می‌کنم اگه چند چیز از تو نیاز داشتم..."

    # say L228 lyd
    old "Never mind, see you later pumpkin."
    new "بیا بعداً عزیزم، خداحافظ."

    # say L243 lyd
    old "Hi Honey, remember that I need you to accompany me to the church the weekend."
    new "سلام عزیزم، به خاطر داشتی که هفته آینده باید مرا به کلیسا همراهی کنی."

    # say L245 pla
    old "Ohhh, of course, no problem, I'll be here on the weekend."
    new "اوه، البته، هیچ اشکالی ندارم، هفته آینده اینجا خواهم بود."

    # say L247 lyd
    old "Thank you very much pumpkin!"
    new "ممنونم عزیزم!"

    # say L254 lyd
    old "Hi Honey, do you need me?"
    new "سلام عزیزم، نیازی به من داری؟"

    # say L256 pla
    old "Oh no, sorry, I was just walking around."
    new "نه، معذرت، فقط داشتم دایره می‌دم."

    # say L258 lyd
    old "Ok, pumpkin"
    new "باشه، عزیزم"

    # say L286 pla
    old "Sorry, I was just walking around."
    new "ببخشید، فقط داشتم دایره می‌دم."


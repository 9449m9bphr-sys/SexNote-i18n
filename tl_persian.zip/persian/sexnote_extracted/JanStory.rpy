# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/JanStory.rpy
translate persian strings:

    # say L13 pla
    old "Ugh, finally at home."
    new "اوه، بالاخره خونه‌ام."

    # say L15 pla
    old "Hmm. What is that noise? It's coming from the living room..."
    new "هم. این صدایی از کجا می‌آیه؟ به نظر می‌تونه از اتاق نشیمن باشه..."

    # say L19 pla
    old "Woah! Are they... Having sex?"
    new "واو! آنها... در حال سکس هستند؟"

    # say L35 pla
    old "I... Am... Sorry... I... Just... Heard..."
    new "من... عذرخواهم... فقط... صدایی را شنیدم..."

    # say L37 mo2
    old "Weren't you supposed to come back at night?!"
    new "شما نباید بود تا شب برگردی؟!"

    # say L39 pla
    old "Yes, but my after school program was canceled..."
    new "بله، اما برنامه‌ی بعد از مدرسه من لغو شد..."

    # say L42 mo1
    old "[pla] is not what it looks like... We were just..."
    new "[pla] همینطور نیست... ما فقط..."

    # say L46 pla
    old "... I'm sorry... I..."
    new "... من خیال می‌کنم... من..."

    # say L84 pla
    old "I know they are married but... They should do that in their room..."
    new "من می‌دونم که ازدواج کردن، اما... باید اینا رو تو اتاق خودشون انجام بدند..."

    # say L85 pla
    old "Anyway, I have all day to relax..."
    new "بازهم، من تمام روز وقت دارم برای استراحت..."

    # say L96 mo1
    old "Listen, I want to talk to you about t- the living room"
    new "بگو، می‌خوام با تو در مورد اتاق نشیمن صحبت کنم"

    # say L98 pla
    old "Oh, I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "اوه، من متوجه شدم. فکر می‌کنم کاملاً عادی باشه... و تو هم [mo1rel] منی، نباید به من توضیح بدی."

    # say L100 mo1
    old "I'm glad to hear that. But... I want to apologize. We were a bit careless getting... Intimate in the living room."
    new "خوشحالم که اینجوری فکر می‌کنی. اما... باید عذرخواهی کنم. ما یک کم دقت نبودیم وقتی... در اتاق نشیمن خیلی نزدیک هم شدیم."

    # say L106 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey."
    new "خب، دیگه از شما آزار نمی‌برم. لطفاً خوب مطالعه کن، عزیزم."

    # say L107 mo1
    old "Oh, by the way, you haven't had breakfast, come downstairs and I'll make you breakfast!"
    new "اوه، بینهایت، هنوز نخورده‌ای، بیا پایین و من برایت سنا می‌کنم!"

    # say L108 pla
    old "Oh right, thank you [mo1rel]."
    new "اوه درسته، ممنون [mo1rel]."

    # say L126 pla
    old "(What the fuck!... what are they doing?)"
    new "چه خبره!... اونا چه کار می‌کنن؟"

    # say L132 pla
    old " (Shit!) Oh, no... Nuh uh... The door was open. I just didn't know someone was in here."
    new "(شیطون!) اوه، نه... نه نه... در بود باز. فقط نمی‌دونستم کسی توی اینجا هست."

    # say L133 mo1
    old "[pla], [mo2] and I were just giving each other a little hug, sweetie."
    new "[pla]، [mo2] و من فقط به هم یه آغوش می‌دادیم، عزیزم."

    # say L134 mo2
    old "See, I tried to tell you he is a damn pervert!... GO AWAY!"
    new "bebین، من هم خواستم به شما بگم اونا یه خیال‌پرداز خوبه!... برو بره!"

    # say L136 pla
    old "I wasn't... Nevermind... I'll go."
    new "من نبودم... بی‌خیال شو... من می‌روم."

    # say L158 mo1
    old "Oh hi [pla], I'm glad you're here, I wanted to talk to you too."
    new "اوه سلام [pla]، خوشحالم که اینجا هستی، می‌خواستم با تو هم صحبت کنم."

    # say L159 pla
    old "Ehm... Is something happening?"
    new "اهم... چیزی پیش آمده؟"

    # say L160 sis
    old "I don't know, I just arrived."
    new "من نمی‌دونم، همین حالا رسیدم."

    # say L164 mo1
    old "Hmm... Actually, yes... That's why I need to talk to you both."
    new "Hmm... در واقع، بله... همین جلبه من باید با شما دو نفر صحبت کنم."

    # say L166 mo1
    old "We are having some... Uhh, financial issues..."
    new "ما برخی... اوه، مشکلات مالی داریم..."

    # say L168 mo1
    old "Well, we don't have e- enough money to pay our obligations..."
    new "خب، پول کافی برای پرداخت تعهداتمون نداریم."

    # say L169 pla
    old "Ohh."
    new "اوه."

    # say L170 sis
    old "But why didn't you say anything before?"
    new "اما چرا قبلاً هیچ چیز نگفتی؟"

    # say L171 mo1
    old "Hmm, I didn't want you to worry about it... It's my obligation to provide for both of you... It's just that our current monetary situation is getting worse and..."
    new "Hmm، نمی‌خواستم ازت نگران شی... این وظیفه‌ی منه که برای هر دوی شما تامین کنم... فقط اوضاع مالی ما بدتر می‌شه و..."

    # say L173 mo1
    old "I- I have been looking at some options and I have applied for different jobs but even that seems to be difficult."
    new "من- من به چند گزینه نگاه کردم و برای شغل‌های مختلف درخواست دادم اما حتی این هم سخت به نظر می‌رسد."

    # say L175 mo1
    old "It's not that easy... Since I have been unemployed for so long, now it's much harder for me to find a job."
    new "اینقدر آسون نیست... از زمانی که بیکار شدم، الان برای من خیلی سخت‌تر شده که شغل پیدا کنم."

    # say L176 mo1
    old "I have already talked to my [mo1rel] and friends but no luck... Nothing yet and only God knows when I'll get something good enough."
    new "من قبلاً با ز[mo1rel] و دوستانم صحبت کردم اما هیچ پیشرفتی نداشت... هیچ چیز تا حالا و فقط خدا می‌دونه چه موقع چیزی خوب پیدا می‌کنم."

    # say L178 mo1
    old "[mo2] was very generous with us when we were together, she paid for almost everything since she has a high salary income."
    new "[mo2] وقتی با هم بودیم خیلی سخاوتمند بود، از آنجا که حقوق بالایی داشت، تقریباً همه چیز رو پرداخت می‌کرد."

    # say L179 mo1
    old "Now that she is gone and we are no longer together, we are facing many more issues. I didn't expect the situation to go this way..."
    new "الان که او رفت و دیگر با هم نیستیم، مشکلات خیلی بیشتر شده. این وضعیت رو همچین نمی‌تونستم پیش‌بینی کنم..."

    # say L180 pla
    old "You're not alone on this... Kyle and I will help you... Right?"
    new "تو در این مسیر تنها نیستی... من و کایل به تو کمک خواهیم کرد... درسته؟"

    # say L181 sis
    old "Yes, of course! I'm working and you know I can help, don't worry about it [mo1rel]."
    new "بله، البته! من در حال کار هستم و می‌دونی می‌تونم کمکت کنم، نگران نباش [mo1rel]."

    # say L182 mo1
    old "It's not that easy, I know you wanna help but we owe a lot of money... Argh! I- I don't know what to do."
    new "این همین آسون نیست، میدونم می‌خوای کمک کنی اما ما بدهکاری زیاد داریم... ارگه! من - من نمی‌دونم چی کار کنم."

    # say L183 mo1
    old "And [mo2] is gone, she is gone and I'm here..."
    new "و [mo2] رفته، او رفته و من اینجا هستم..."

    # say L184 pla
    old "We'll find the way to solve thi-"
    new "راهی برای حل این مشکل پیدا می‌کنیم-"

    # say L185 mo1
    old "I- I can't now, I better go to take some rest... I can't do this now... Sorry but I can't."
    new "من- من حالا نمی‌تونم، بهتره راه بردم و یه قلی خواب بگیرم... حالا این کار رو نمی‌تونم انجام بدم... معذرت ولی نمی‌تونم."

    # say L186 pla
    old "S- Sure [mo1rel], it's fine."
    new "ب-Bale [mo1rel]، مشکلی نداره."

    # say L194 pla
    old "It's the first time I see [mo1rel] this worried and sad, especially sad. We gotta do something to help."
    new "این اولین باره می‌بینم [mo1rel] اینقدر نگران و ناراحته، خصوصاً ناراحت. باید چیزی بکنیم تا کمکش کنیم."

    # say L195 sis
    old "Yeah! I didn't imagine seeing her like this. [pla] find a job and I'll do my part, I'll find a way to help as well, even if she says isn't enough."
    new "بله! هیچ وقت فکر نکردم اینجوریش ببینم. [pla] شغل پیدا کنم و من هم کار خودمو انجام می‌دم، راهی برای کمک پیدا می‌کنم، حتی اگه بگه که کافی نیست."

    # say L196 pla
    old "Sure! I'll start to look for something immediately... It's too sa-"
    new "بله! همین حالا شروع می‌کنم به جستجو... خیلی ناراحت‌کننده است-"

    # say L197 sis
    old "Yeah, yeah... I know it's sad but we gotta focus on finding a solution for this..."
    new "بله، بله... میدونم خیلی حالت رو بد می‌کنه اما باید روی پیدا کردن راه حل برای این مشکل تمرکز کنیم."

    # say L198 sis
    old "Tell me once you have found something..."
    new "بگو برام وقتی چیزی پیدا کردی..."

    # say L199 pla
    old "I will."
    new "بله، خواهم کرد."

    # say L200 sis
    old "Alright, See ya!"
    new "باشه، ببینم."

    # say L206 pla
    old "Shit! This is bad... I gotta find a job, my [mo1rel] is gonna get sick and depressed if we don't do something."
    new "شیطان! این بد است... باید شغلی پیدا کنم، اگر هیچ کاری نکنیم [mo1rel] می‌تونه بیمار و ناراحت بشه."

    # say L207 pla
    old "Argh! But where? Really, where can I find a job?"
    new "آره! اما کجا؟ واقعاً کجا می‌تونم کار پیدا کنم؟"

    # say L208 pla
    old "Maybe at the vet's store... Or with Dr. Johnson... I don't know!"
    new "شاید در دکترین حیوانات... یا با دکتر جانسون... نمی‌دونم!"

    # say L209 pla
    old "I know! With Lisa..."
    new "من می‌دونم! با لیزا..."

    # say L210 pla
    old "Or [mo2]... No! What am I thinking about!... [mo2], no!... She would kick out my ass."
    new "یا [mo2]... نه! من چی فکر می‌کنم!... [mo2]، نه!... او احتمالاً اینجا رو خواهد زد."

    # say L211 pla
    old "I shouldn't keep wasting my time... I'll go to all and see what I find, I need a job, I cannot let my [mo1rel] down... She needs me"
    new "نمی‌تونم وقت خودمو بیهوده بگذونم... برای همه می‌رمش و می‌بینم چی پیدا می‌کنم، نیاز دارم شغل پیدا کنم، نمی‌تونم [mo1rel] رو بیادم... او به من نیاز داره."

    # say L229 pla
    old "What a day! Argh! It seems to be impossible to find a job... Don't know what I'm gonna do"
    new "چه روزی! ارگ! به نظر می‌رسه پیدا کردن شغل غیرممکنه... نمی‌دونم چی کار کنم"

    # say L230 pla
    old "Maybe I should ask at schoo-"
    new "شاید باید از مدرسه بپرسم"

    # say L237 sis
    old "Hey [pla], we have to talk."
    new "هی ز[pla]، باید با تو صحبت کنم."

    # say L239 sis
    old "What happened? Why the sad face?"
    new "چه اتفاقی افتاد؟ چرا چهره‌ت ناراحت است؟"

    # say L240 pla
    old "Well, I was looking for any job opportunity the whole day but no luck, nobody wants to hire me."
    new "خب، همه روز خودم رو برای فرصت شغلی جستجو می‌کردم ولی هیچ کامربندی، هیچ کس نمی‌خواد من رو استخدام کنه."

    # say L241 sis
    old "That's bad... You know, [mo1rel] was crying a lot today, she is feeling like shit."
    new "این بد است... دانستی، ز[mo1rel] امروز خیلی گریه کرد، حالتش مثل شیطانه."

    # say L242 sis
    old "Argh! I can't see her like that... You have to find something, you really have to."
    new "آره! نمی‌تونم اونجور ببینمش... باید چیزی پیدا کنی، واقعاً باید."

    # say L243 pla
    old "Did she tell you anything? Did you talk to her?"
    new "اونجا هیچی نگفت؟ باهاش حرف زدی؟"

    # say L244 sis
    old "No, she doesn't want us to notice how she's feeling, I didn't say anything and that's why I'm telling you."
    new "نه، نمی‌خواد بفهمیم احساساتش چیه، هیچی نگفتم و به همین خاطر به تو می‌گم."

    # say L245 pla
    old "I'll find something, we can't let [mo1rel] down."
    new "من چیزی پیدا می‌کنم، نمی‌تونیم [mo1rel] رو بیاد بذاریم."

    # say L246 sis
    old "No, we can't. You find something tomorrow... Do your best, man! Do something about it because we have serious bullshit here."
    new "نه، نمی‌تونیم. چیزی فردا پیدا کنی... برو بهترین تلاش رو بکن، مرد! چیزی بکن چون اینجا مشکلات جدی داریم."

    # say L247 pla
    old "I know, I know..."
    new "می‌دونم، می‌دونم..."

    # say L248 sis
    old "Good, see you tomorrow then..."
    new "خوب، ببینم فردا..."

    # say L249 pla
    old "Bye..."
    new "بای بی..."

    # say L254 pla
    old "Oh my Gosh! Where am I going to find a job now?"
    new "اوه خدا! الان من جای کاری از کجا بیارم؟"

    # say L255 pla
    old "I already tried with the best options I had in mind... What abou-"
    new "من قبلاً بهترین گزینه‌هایی که به ذهنم می‌رسید رو امتحان کردم... در مورد -"

    # say L258 pla
    old "Fuck it! I'll do it, this is about my [mo1rel], I have to try at least... Tomorrow I'll see [mo2]."
    new "فکرشو بزن! انجام میدم، این در مورد ز[mo1rel] منه، باید حداقل سعی کنم... فردا [mo2] رو می‌بینم."

    # say L274 pla
    old "Hi Akita... I'm [pla]"
    new "سلام آکیتا... من ز[pla] هستم"

    # say L275 aki
    old "Oh! Hey, I remember you, yes... You're the handsome delivery guy..."
    new "اوه! سلام، من به تو خیال می‌کردم، بله... تو آن بارگیر خوش‌تیپی هستی..."

    # say L276 aki
    old "Tell me... What can I do for you?"
    new "بگو... من برایت چه کاری می‌تونم بکنم؟"

    # say L278 pla
    old "H- Handsome? Haha t- thanks."
    new "ح- حسن‌تیپ؟ هاها ممنون."

    # say L279 pla
    old "Actually I'm here looking for [mo2]."
    new "事实上，我是来找 [mo2] 的。"

    # say L297 mo2
    old "[pla]? What the heck are you doing here?"
    new "[pla]؟ قدرت اومدی اینجا چیکار می‌کنی؟"

    # say L298 pla
    old "H- Hi [mo2], I- I don't want to bother you but I have to talk to you, I- I need to tell you something."
    new "ه- هی [mo2]، من- من نمی‌خوام باعث اشکالت بشه ولی باید با تو صحبت کنم، باید چیزی به تو بگم."

    # say L299 mo2
    old "What do you want?"
    new "چه کاری می‌خواهی؟"

    # say L300 pla
    old "I see but I really need to ask you for a favor..."
    new "می‌بینم ولی واقعاً ازت یه لطفی خواستن..."

    # say L301 pla
    old "I need a job, I can do whatever you ask me to but I need to work. The situation at home is not ok and we all are worried."
    new "من نیاز به کار دارم، هر کاری که از من بخواهی می‌کنم ولی باید کار کنم. شرایط خانه خوب نیست و ما همه نگرانیم."

    # say L303 mo2
    old "So you come to my office and you pretend I give you a job? Why should I do that!?"
    new "پس شما به دفتر من می‌آیید و من باید به نظر برسانم که شما را استخدام کرده‌ام؟ چرا باید این کار را بکنم؟!"

    # say L304 pla
    old "[mo2], please! I know you don't like me but believe you're the last option I have, I don't know what else to do."
    new "[mo2]، لطفاً! میدونم دوستت نداری ولی باور کن آخرین گزینه‌ام هستی، نمی‌دونم باید چی کنم."

    # say L305 mo2
    old "Finally you got it! Yes, I don't like you and I won't hire you. Don't be stupid! Now go away! I don't want you here."
    new "اونجا رفتی! بله، من نمی‌تونم تو رو دوست بیام و همین طور نمی‌تونم تو رو استخدام کنم. نباشی غیرت! حالا برو بره! من نمی‌خوام تو اینجا باشی."

    # say L306 mo2
    old "Now that you all need me, you come here looking for me! Well, I don't care!"
    new "الان که همه به من نیاز دارید، اینجا آمده‌اید می‌خواهید من به شما کمک کنم! خب، من هیچ اهمیتی نمی‌دهم!"

    # say L308 mo2
    old "I said get out!"
    new "برو بره!"

    # say L317 pla
    old "Now where I'm going to find a job?"
    new "الان من کجا باید شغل پیدا کنم؟"

    # say L318 pla
    old "Wait, what is that sound? It comes from the livingroom..."
    new "منتظر بقیه، صدایی از اتاق نشیمن می‌آید..."

    # say L333 pla
    old "Oh, [mo1rel]? A- Are you fine?"
    new "اوه، ز[mo1rel]؟ آ- آیا حالت خوبه؟"

    # say L336 pla
    old "Are you crying? I don't want to see you like this [mo1rel]."
    new "آیا گریه می‌کنی؟ من نمی‌خوام تو رو اینجور ببینم [mo1rel]."

    # say L337 mo1
    old "I- I know honey but it's hard... I'm feeling so sad, so lonely, I- I."
    new "می‌دونم عزیزم ولی سخته... خیلی ناراحت و تنها هستم، من..."

    # say L338 pla
    old "[mo1rel], you're not alone, we're here for you. I promise you I'll find a job and everything will be fine."
    new "[mo1rel]، تو تنها نیستی، ما برایت هستیم. قول می‌دم که شغل پیدا می‌کنم و همه چیز خوب می‌شه."

    # say L339 mo1
    old "I'm sorry, it's just that it's a bunch of things, I would like to solve our monetary issues without putting pressure on you or your [sisrel]..."
    new "متأسفم، فقط اینجاست که چند تا مشکل هست، من می‌خواهم مشکلات مالیمون رو حل کنم بدون اینکه فشار بر تو یا [sisrel] بیاندازم..."

    # say L340 mo1
    old "And... I have to admit... I really miss her... It's been hard to be without her."
    new "و... باید بگم... خیلی ازش دلتنگی کردم... بدونش سخت بود."

    # say L341 pla
    old "No [mo1rel]! Don't worry for us, we are a family and we'll find a way to solve it:"
    new "نه [mo1rel]! نگران ما نباش، ما خانواده‌ایم و راهی برای حل این مشکل پیدا می‌کنیم:"

    # say L342 pla
    old "We'll do whatever it takes to make you feel better."
    new "ما هر کاری رو که لازم باشه برای اینکه تو خوب حس کنی، انجام می‌دیم."

    # say L343 mo1
    old "The only thing that would make me feel better is... Argh!"
    new "تنها چیزی که منو خوشحالم می‌کنه... آره!"

    # say L345 mo1
    old "This is hard, you know... It's really hard to feel so helpless, I feel my hands are tied and there is nothing I can do."
    new "این سخته، میدونی... خیلی سخته وقتی احساس بی‌کاری می‌کنم، مثل اینکه دست‌هام بسته شده و هیچ کاری نمی‌تونم بکنم."

    # say L346 pla
    old "I'm so so sorry."
    new "من خیلی خیلی متاسفم."

    # say L348 mo1
    old "I'll rest for now... I can barely talk..."
    new "باشم برای حالا... هر کلمه‌ای بیان می‌کنم با زور و بی‌نیرویی."

    # say L349 pla
    old "Yes [mo1], just go and try to rest. I'll take care of this."
    new "بله ز[mo1]، فقط برو و سعی کن استراحت کنی. من اینجا همه چی رو در نظر می‌گیرم."

    # say L350 mo1
    old "See you hun, thanks for being so good..."
    new "ببینم دوست من، ممنونم از خوبیت..."

    # say L355 pla
    old "My [mo1rel] doesn't deserve this, I'll insist to [mo2], she has to help me..."
    new "[mo1rel] این را نمی‌تونه تحمل کنه، من با [mo2] مذاکره خواهم کرد، او باید به من کمک کنه..."

    # say L356 pla
    old "It doesn't matter what I have to do to get that job... I don't want to see my [mo1rel] so depressed and worried."
    new "همه چیز اهمیتی نداره که برام باید چیکار کنم تا اون کار رو بگیرم... من نمی‌خوام ببینم [mo1rel] همینجور ناراحت و نگران باشه."

    # say L357 pla
    old "I wish I could help her to come back with [mo2], it is obvious how much she misses her..."
    new "من آرزو می‌کنم بتونم به تو کمک کنم تا با [mo2] برگردی، مشخصه چقدر از دستش دوست داری..."

    # say L374 mo2
    old "This is absurd! What happened to the delivery boy?"
    new "این غیرمنطقیه! پیشگام تحویل کجا رفت؟"

    # say L375 aki
    old "I- I'm calling him, but he doesn't answer."
    new "من- من بهش تلفن می‌کنم، اما جواب نمی‌ده."

    # say L376 mo2
    old "What? It's incredible how useless everyone in this company is... What am I paying these people for!?"
    new "چه؟ این شرکت چقدر بی‌کارا هست... من برای این‌ها به این مردم چه پول می‌دهم!؟"

    # say L377 mo2
    old "We should have sent those documents hours ago... "
    new "باید این اسناد رو ساعت‌ها پیش ارسال کردیم..."

    # say L383 pla
    old "[mo2]? Hi..."
    new "[mo2]؟ سلام..."

    # say L385 mo2
    old "Argh! Again you..."
    new "آره! دوباره تو..."

    # say L387 mo2
    old "Akita, I'm waiting for an answer, what happened to the delivery boy? Can we get another one? I need you to solve this fucking issue NOW!"
    new "اکیتا، منتظر جوابت هستم، پیشگام کجا رفت؟ می‌تونیم یکی دیگه بگیریم؟ لازم دارم این مشکل شیطون رو الان حل کنی!"

    # say L388 aki
    old "It would be hard to find another one right now, it's pretty late and the Mayor's office is waiting for those documents. I don't know  Mrs. [mo2]."
    new "البته پیدا کردن یکی دیگه الان سخته، وقت خیلی دیره و دفتر شهردار منتظر این اسناده. من نمی‌دونم خانم [mo2]."

    # say L389 mo2
    old "You don't kno-?"
    new "تو نمی‌دونی؟"

    # say L390 pla
    old "I- I could d- deliver t- those d- documents..."
    new "من- من می‌تونم آن- آن اسناد رو ب- ببرم..."

    # say L392 mo2
    old "Are you fucking kidding me!? You're an idiot, I won't trust you with those things, just get out, I told you I don't want you here..."
    new "آیا می‌خوای بازی کنی؟! تو احمقی، من بهت اعتماد ندارم، برو بیرون، بهت گفتم نمی‌خوام تو اینجا باشی..."

    # say L394 aki
    old "Mrs. [mo2]! That's actually a good idea and the only option we have if we want those documents to be delivered now."
    new "خانم [mo2]! این در واقع یک ایده خوبه و تنها گزینه‌ای هست که برای ارسال اون اسناد داریم."

    # say L396 mo2
    old "No and no! I don't want him to do anything... Akita, just find another way..."
    new "نه و نه! نمی‌خوام اون کار رو انجام بدی... آکیتا، راه دیگه‌ای پیدا کن..."

    # say L397 aki
    old "Uhh... I- I'm afraid there is no other way right now..."
    new "اوه... من- من امیدوارم راه دیگری باشد حالا..."

    # say L398 pla
    old "I'll do it! I can do it well, I promise, please [mo2]... It's just a little help."
    new "من انجام می‌دم! خوب انجام می‌دم، قول می‌دم، لطفاً [mo2]... فقط یه کمک کوچیکه."

    # say L400 mo2
    old "Argh! FINE! Go and deliver the documents NOW! If I get to know that you did something wrong, I'll fucking kill you."
    new "آره! خوب! حالا برو و اسناد رو تحویل بده! اگه بفهمم چیزی اشتباه کردی، قطعاً تو رو کشت می‌کنم."

    # say L406 aki
    old "[pla], You have to take the documents to the Mayor's office, please go as fast as you can."
    new "[pla]، باید اسناد رو به دفتر شهردار ببری، لطفاً سریع برو."

    # say L407 pla
    old "Alright, I'm going now..."
    new "باشه، حالا می‌رم..."

    # say L420 pla
    old "H- Hello?"
    new "ه- سلام؟"

    # say L421 sop
    old "Yes, pardon me?"
    new "بله، معذرت؟"

    # say L422 pla
    old "Oh hi! I'm [pla], I'm coming from [mo2]'s office..."
    new "اوه سلام! من [pla] هستم، از دفتر [mo2] آمده‌ام..."

    # say L423 sop
    old "Hello! I'm Amy, nice meeting you."
    new "سلام! من امی هستم، خوشحالم که با تو آشنا شدم."

    # say L424 sop
    old "Do you have the documents? Let me see them, please."
    new "آیا اسناد رو داری؟ لطفاً برام نشون بده."

    # say L426 pla
    old "Yes, here they are..."
    new "بله، اینا هستند..."

    # say L428 sop
    old "Perfect... You came just in time, we were waiting for them."
    new "عالی... همینجوری اومدی، منتظر اینا بودیم."

    # say L430 pla
    old "Well... Guess that's it... Thank you."
    new "خب... به نظر می‌تونه همه‌ش اینجوری باشه... ممنون."

    # say L436 sop
    old "Huh! One more thing! Tell [mo2] that everything is in order and that we'll call her back."
    new "هی! یه چیز دیگه! به [mo2] بگو همه چی درسته و ما بعداً بهش تلفن می‌کنیم."

    # say L437 pla
    old "Alright, have a nice day."
    new "باشه، روز خوبی داشته باش."

    # say L438 sop
    old "Bye! See ya."
    new "بای! ببینم."

    # say L440 pla
    old "Alright, I think that was easier than I expected. Now it's time to go back to [mo2]'s office."
    new "باید بگم این راحت‌تر از آنچه فکر می‌کردم بود. حالا وقت برای برگشت به دفتر ز[mo2] است."

    # say L460 pla
    old "H- Hello A- Akita..."
    new "ه- هی Akita..."

    # say L462 pla
    old "(I can't even focus...)"
    new "من حتی نمی‌تونم تمرکز کنم..."

    # say L463 pla
    old "Good... I delivered everything."
    new "خوب... همه چی رو تحویل دادم."

    # say L469 aki
    old "So apparently you did a good job..."
    new "پس به نظر می‌رسه کارت خوب بود..."

    # say L470 pla
    old "Y- Yeah... Well, I delivered the documents and the girl said it was fine and that it was in time, so I guess, yeah..."
    new "بله... خوب، اسناد رو تحویل دادم و دختر گفت خوبه و به موقع بود، پس فکر کنم، بله..."

    # say L471 aki
    old "I know, I know... And... Hmm."
    new "می‌دونم، می‌دونم... و... همین."

    # say L472 pla
    old "Yeah? What happened? Did I do anything wrong?"
    new "بله؟ چه کاری افتاد؟ من چیزی اشتباه کردم؟"

    # say L473 aki
    old "Well... Hmm, not here but... Did you notice what you have down there?"
    new "خب... نه، نه اینجا ولی... آیا توجه کردی به چیزی که پایین داری؟"

    # say L474 pla
    old "What? What do you mea-"
    new "چه؟ منظورت چیه؟"

    # say L476 pla
    old "Argh fuck! I- I don't kno- I- I h- have to go."
    new "آره شیطون! من- من نمی‌دونم- من- من باید برم."

    # say L493 mo2
    old "You better have done it right!"
    new "باید این کار رو درست انجام داده باشی!"

    # say L494 pla
    old "Y- yes [mo2], I- I did everything... S- She said she will call-"
    new "B- بله ز[mo2]، من- من همه چیز رو انجام دادم... او- او گفت که خواهد زنگ زد-"

    # say L495 mo2
    old "What's wrong with you? Why are you acting so weird?"
    new "چرا اینجوری رفتی؟ چه کاری داری؟"

    # say L496 pla
    old "M- me? Uhh, no... Nothing..."
    new "من؟ اوه، نه... هیچی..."

    # say L497 mo2
    old "What do you have on your hands? Why are you acting like a freak? You idiot! Tell me what have you done?"
    new "دستت چه چیزی رو داری؟ چرا مثل یه خر می‌رفتی؟ احمق! بگو چه کاری کردی؟"

    # say L500 mo2
    old "You're not gonna fool me... Let me see your hands now! What are you hiding?"
    new "تو نمی‌تونی من رو به دروغ بکشی... حالا دستت رو به من نشون بده! چی می‌پوشی؟"

    # say L502 mo2
    old "What the fuck!? You are a fucking pervert!"
    new "چه خربه‌ای!؟ تو یه پرتورت هستی!"

    # say L504 mo2
    old "Why do you have a fucking boner right now?"
    new "چرا الان شورتت خیس شده؟"

    # say L505 pla
    old "[mo2]... I- I c- can explai-"
    new "[mo2]... من- من می‌تونم توضیح بدم-"

    # say L506 mo2
    old "Explain what?"
    new "چه چیزی رو توضیح می‌دهی؟"

    # say L507 mo2
    old "That you got fucking horny and now you're having a BONER IN FRONT OF ME!?"
    new "که خودت خیلی خیال پر کردی و حالا یه سفتی توی جلوی من داری!؟"

    # say L508 pla
    old "N- not r- really..."
    new "نه، واقعاً نه..."

    # say L509 mo2
    old "Bullcrap!"
    new "بله، دروغ!"

    # say L511 mo2
    old "I've had a pretty shitty day and now this... BUT! You'll see... Little motherfucker... You'll see!"
    new "روز خوبی داشتم و حالا این... ولی! خواهی دید... مامان جون‌باز... خواهی دید!"

    # say L512 pla
    old "W- What? "
    new "و- وای؟"

    # say L513 mo2
    old "Get on the floor... NOW!"
    new "بر پا بیا... حالا!"

    # say L514 pla
    old "O- On t- the f- floor? W- why?"
    new "O- روی ز- زمین؟ چ- چرا؟"

    # say L515 mo2
    old "I've given you an order! Do it, you are a stupid pervert... Do what I'm telling you and do it now."
    new "من به تو دستور دادم! انجام بده، تو یه پرتوبی هستی... همین الان انجام بده چی می‌گم."

    # say L516 pla
    old "(Oh fuck!)"
    new "اوه شیطون!"

    # say L517 mo2
    old "Your knees on the floor NOW!"
    new "حالا زننت رو به زمین بزن!"

    # say L518 pla
    old "A- alright... Uhh."
    new "ا- خوب... اوه."

    # say L522 mo2
    old "I'll have fun with you... You get horny here... I give you shit!"
    new "من با تو لذت ببرم... تو اینجا خیلی خرس می‌شی... من تو رو می‌کنم!"

    # say L523 mo2
    old "You will suck my foot!"
    new "پایم رو شیر بکش!"

    # say L524 pla
    old "W- what!? Do you want me to suck you-"
    new "و- وای!؟ می‌خوای از من جاگیری کنم-"

    # say L525 mo2
    old "WHAT? WHY are you questioning me? I've just said, SUCK MY FOOT!"
    new "چه؟ چرا از من می‌پرسی؟ همین الان گفتم، پایم رو شیر بکش!"

    # say L543 mo2
    old "Go! Disappear from here... I don't want to see you."
    new "برو! از اینجا محو شو... من نمی‌خوام تو رو ببینم."

    # say L544 pla
    old "B- but what about the job? Can I c- come back?"
    new "ب- ب- اما کار چطور؟ می‌تونم برگردم؟"

    # say L545 mo2
    old "Yes, whatever... Just go away."
    new "بله، هر چه بخواهی... فقط برو."

    # say L546 pla
    old "S- So am I hired?"
    new "S- من استخدام شدم؟"

    # say L547 mo2
    old "Are you stupid or what? I just said YES! Now, GET OUT!"
    new "آیا احمقی هستی یا چه؟ من فقط گفتم بله! حالا، برو بیرون!"

    # say L552 pla
    old "Fuck! That was weird..."
    new "اوه، این خیلی عجیب بود..."

    # say L569 pla
    old "Oh, hi [mo1rel], how are you? A bit better?"
    new "اوه، سلام [mo1rel]، حالت چطوره؟ یه کم بهتر شدی؟"

    # say L570 mo1
    old "Hi honey, I'm ok... Not that good but I guess I'll be fine eventually..."
    new "سلام عزیزم، من خوبم... خیلی خوب نیستم ولی فکر کنم در نهایت بهتر می‌شوم."

    # say L571 mo1
    old "I'm still worried about our economic situation..."
    new "هنوز نگران وضعیت اقتصادی ما هستم..."

    # say L572 pla
    old "No [mo1rel]! You don't have to worry about it... I got a job and I'll be able to help you."
    new "نه ز[mo1rel]! نباید نگران باشی... من شغلی پیدا کردم و می‌تونم به تو کمک کنم."

    # say L573 mo1
    old "A job? How? Where are you working?"
    new "یک شغل؟ چطور؟ تو کجایی کار می‌کنی؟"

    # say L574 pla
    old "Hmm... I'm working in [mo2]'s office... Basically, I just started but yeah... It's good that I'll have some money to help..."
    new "هم... من توی اداره ز[mo2] کار می‌کنم... به طور کلی، همین الان شروع کردم ولی بله... خوبه که پولی برای کمک به تو خواهم داشت."

    # say L575 mo1
    old "[mo2]? Are you serious?"
    new "[mo2]؟ جدی می‌گی؟"

    # say L576 pla
    old "Yes, she gave me a chance to work for her..."
    new "بله، او به من فرصتی برای کار داد..."

    # say L578 mo1
    old "And... Is she fine? Hmm, has she asked for me or anything...?"
    new "و... حالت خوبه؟ هم، از من پرسیده یا چیزی...؟"

    # say L579 pla
    old "She's fine [mo1rel]... You know, I haven't really talked much to her..."
    new "خوبه [mo1rel]... می‌دونی، باهاش خیلی صحبت نکردم..."

    # say L580 mo1
    old "Ok... Yeah, I assume she's fine... Probably better than me..."
    new "باشه... بله، فکر کنم خوبه... احتمالاً بهتر از من..."

    # say L583 mo1
    old "Honey, go get some rest... I guess you've been tired since you started working..."
    new "حون، برو خواب بکن... فکر کنم از زمانی که شروع کردی کار می‌کنی خسته هستی..."

    # say L584 pla
    old "Kinda, today it's been a very long and hard day... I'm gonna head to my room."
    new "بله، امروز روز خسته‌کننده‌ای بود... من به اتاقم می‌روم."

    # say L585 mo1
    old "I imagine how hard it is working with her..."
    new "می‌فهمم چقدر سخته کار کردن با اون..."

    # say L586 pla
    old "(Well... It was hard, quite literally...)"
    new "خوب... سخت بود، حرف‌های من رو حرف‌های من بگیر."

    # say L587 pla
    old "If you need anything just tell me, ok? Love you [mo1rel]."
    new "اگه نیازت به هیچی هست فقط به من بگو، خب؟ دوستت دارم [mo1rel]."

    # say L589 mo1
    old "Bye honey, love you too."
    new "باید هنگام، من هم دوستت دارم."

    # say L595 pla
    old "Hmm, [mo1rel] is feeling really sad for [mo2]..."
    new "هم، [mo1rel] خیلی برای [mo2] ناراحت است..."

    # say L596 pla
    old "And the worst part is that she misses her a lot but [mo2] doesn't even ask for her."
    new "و بدترین بخش اینه که او خیلی بهش می‌افتد ولی [mo2] حتی برایش پرسش نمی‌کنه."

    # say L597 pla
    old "I should find the way to talk with [mo2] about my [mo1rel]... I'll see."
    new "باید راهی پیدا کنم تا با [mo2] در مورد [mo1rel] صحبت کنم... ببینم چطور."

    # say L603 pla
    old "Hey Kylee! What's up?"
    new "اوه کایلی! چطوری؟"

    # say L604 sis
    old "I'm great. What about You?"
    new "من خوبم. تو چطوری؟"

    # say L605 pla
    old "Well, I got a job!"
    new "خب، شغلی پیدا کردم!"

    # say L606 sis
    old "Cool, finally man! What's it about?"
    new "عالی، بالاخره! این بار در مورد چیه؟"

    # say L607 pla
    old "That's the not so cool part... I'm working with [mo2]..."
    new "این همون بخش خنده‌دارش... من با [mo2] کار می‌کنم..."

    # say L608 sis
    old "[mo2]? Really?... But that woman hates you..."
    new "[mo2]؟ واقعاً؟... اما اون بانو تو رو می‌نفرت."

    # say L609 sis
    old "What are you doing for her?"
    new "تو برایش چه کاری می‌کنی؟"

    # say L611 pla
    old "Hmm... Just l- like... delivery guy...."
    new "هم... فقط مثل... پیشگام..."

    # say L612 sis
    old "I see... Well you have talent for that, don't you? Hahaha. "
    new "می‌بینم... خوب تو برای این کار موهبت داری، ها ها ها."

    # say L613 pla
    old "Yeah, so funny... "
    new "بله، خیلی مضحک..."

    # say L614 sis
    old "At least you finally got a job."
    new "البته، حداقل حالا شغلی پیدا کردی."

    # say L615 pla
    old "Hmm, I know... I know..."
    new "Hmm، می‌دونم... می‌دونم..."

    # say L616 pla
    old "Today was a really weird day, I need some rest, see you."
    new "امروز روز عجیبی بود، نیاز به استراحت دارم، ببینم."

    # say L617 sis
    old "I believe you, Hahaha, see you."
    new "باورت می‌کنم، هاهاها، ببینم."

    # say L635 aki
    old "Hi [pla], how's it going?"
    new "سلام ز[pla]، چطوری؟"

    # say L636 pla
    old "Hello Akita, all good... Getting involved in the job."
    new "سلام آکیتا، خوب همه چی... در حال ورود به کار هستم."

    # say L637 aki
    old "Oh great, so are you ready to start with the new deliveries?"
    new "عالی، پس آماده‌ای برای شروع به تحویل‌های جدید؟"

    # say L638 pla
    old "Yeah, please explain to me what I have to do."
    new "بله، لطفاً به من توضیح بده چه کاری باید انجام بدم."

    # say L639 aki
    old "Well, it really is very simple, at the moment we must send correspondence from some projects to three specific places."
    new "خب، واقعاً خیلی ساده است، در حال حاضر باید مدارک برخی پروژه‌ها را به سه مکان خاص ارسال کنیم."

    # say L641 aki
    old "They all have a different format depending on where they should go."
    new "هر کدام دارای قالب متفاوتی هستند بسته به اینکه کجا باید برود."

    # say L642 aki
    old "For example, all mayoral documents have a red border."
    new "مثلاً، تمام اسناد شهرداری لبه قرمزی دارن."

    # say L643 aki
    old "While the documents that go to the bank are green."
    new "در حالی که اسنادی که به بانک می‌روند سبز هستند."

    # say L644 aki
    old "And finally the yellow documents for the factory."
    new "و در نهایت سند های زرد برای کارخانه."

    # say L646 pla
    old "Red, green and yellow, got it."
    new "قرمز، سبز و زرد، فهمیدم."

    # say L647 aki
    old "It shouldn't be difficult at all, you just need to send them quickly to reach all the deliveries of the day."
    new "این خیلی سخت نیست، فقط باید سریع بفرستی تا همه تحویلات روز انجام شنود."

    # say L648 aki
    old "Anyway if you need anything else just let me know."
    new "بازهم اگر نیازت به همکاری من بود، فقط به من بگو."

    # say L649 pla
    old "Alright, thank you."
    new "البته، ممنون."

    # say L650 aki
    old "So? Are you ready to start the deliveries?"
    new "پس؟ آماده‌ای برای شروع تحویل‌ها؟"

    # say L651 pla
    old "Sure! Let's do it."
    new "بله! بیای برویم."

    # say L662 mo2
    old "So do you think I'm paying to do a shitty job? Is that what you think?"
    new "پس فکر می‌کنی من برای انجام کار بد پول می‌دهم؟ این همینه که فکر می‌کنی؟"

    # say L663 pla
    old "No! No [mo2]! I'm sorry... I'm still learning but I promise I'll do it better."
    new "نه! نه [mo2]! خواهش می‌کنم... هنوز در حال یادگیری هستم ولی قول می‌دم بهتر انجام می‌دم."

    # say L664 mo2
    old "You're an idiot... I seriously doubt you'll do it better..."
    new "تو احمقی... من جدی هستم، شک دارم بتونی بهتر کنی..."

    # say L665 mo2
    old "I can let this go... You gotta learn a lesson out of this."
    new "می‌تونم اینو گذشته ببرم... باید از این درس بگیری."

    # say L666 pla
    old "A- A l- lesson? But I just started working with you..."
    new "یک درس؟ اما من همچون شروع کردم با تو کار می‌کنم..."

    # say L667 mo2
    old "And now you're questioning my decisions... You better change that fucking shitty behavior or you'll suffer in this office."
    new "و حالا شما سؤال می‌کنید درباره تصمیمات من... بهتر است این رفتار خیلی بد و فحش‌دهن رو تغییر بدید، در غیر این صورت در این دفتر مشکل خواهید داشت."

    # say L668 mo2
    old "Do you understand that?"
    new "آیا متوجه شدی؟"

    # say L670 mo2
    old "DO YOU? I'm asking..."
    new "آیا متوجه شدی؟ من از تو می‌پرسم..."

    # say L671 pla
    old "Y- Yeah... I do."
    new "ب- بله... من متوجه هستم."

    # say L672 mo2
    old "Good! Now get on the floor... You'll see what it's like not doing a good job for me..."
    new "خوب! حالا روی زمین بنشین... خواهی دید چطور هنگامی که برای من کار خوبی انجام نمی‌دهی است."

    # say L680 mo2
    old "I guess lastime wasn't enough for you... You deserve to be on the floor where you belong!"
    new "گویا آخرت برایت کافی نبود... شایسته‌ی این هستی که روی زمین بنشینی که جایت اینجاست!"

    # say L681 mo2
    old "You're my little bitch on the floor... Waiting for me to feed you."
    new "تو خرچنگ کوچولوم روی زمین... منتظر این هستی که من بهت غذا بدم."

    # say L683 mo2
    old "That's how you should be treated, like the cockroach that you are!"
    new "این همینه که باید درمانده بشی، مثل خرچنگی که هستی!"

    # say L687 mo2
    old "You got a hardon?! Ughh... That's disgusting!"
    new "تو یه سفتی گرفتی؟! اوه... این خیلی خیزناکه!"

    # say L691 mo2
    old "Alright, if this is what a pervert wants, maybe I should use other methods of punishment."
    new "البته، اگر این همچین چیزی را می‌خواهد، شاید باید روش‌های دیگری برای مجازات استفاده کنم."

    # say L692 mo2
    old "Let's see if this teaches you a lesson!"
    new "ببینیم این تو رو درس میده؟"

    # say L703 pla
    old "[mo2]? Hmm, I- I wanted to tell you something..."
    new "[mo2]؟ هم، من- من می‌خواستم چیزی به تو بگم..."

    # say L704 mo2
    old "Be quick and get out from here!"
    new "سریع شو و از اینجا برو!"

    # say L705 pla
    old "It's about my [mo1rel], you know she has been asking for you... I don't know if maybe you could call her or you know... Something."
    new "درباره ز[mo1rel]، می‌دونی که اونجوری از تو پرسیده... نمی‌دونم شاید بتونی باهاش تماس بگیری یا مثلاً... چیزی."

    # say L706 mo2
    old "Oh gosh! Really?"
    new "اوه خدا! واقعاً؟"

    # say L707 mo2
    old "I won't talk to her."
    new "من باهاش حرف نمی‌زنم."

    # say L708 mo2
    old "Now just get out idiot! I feel gross just by seeing you."
    new "بیرون برو احمق! فقط با دیدنت خودم خنده‌دار می‌شوم."

    # say L714 pla
    old "What am I doing?"
    new "من چیکار می‌کنم؟"

    # say L715 pla
    old "[mo2] is crazy... I can't keep doing whatever she wants."
    new "[mo2] دیوانه است... نمی‌تونم هر چی می‌خواد براتش انجام بدم."

    # say L716 pla
    old "Argh!"
    new "آره!"

    # say L732 pla
    old "Hello Akita, all good..."
    new "سلام آکیتا، همه خوبه..."

    # say L733 aki
    old "Great! You know what you've to do... So just let me know if you need help."
    new "عالی! میدونی چه کاری باید بکنی... پس فقط بگو اگر نیاز به کمکت داشتم."

    # say L738 pla
    old "I would like to know if all the documents that must be sent today are ready?"
    new "می‌خوام بدونم آیا همه اسنادی که باید امروز بفرستیم آماده‌ان؟"

    # say L739 aki
    old "Hmm, There are still several documents missing that [mo2] must sign, if you come in the afternoon I will have them ready for you."
    new "هم، هنوز چند مدرک برای امضای [mo2] مفقود هست، اگر بعد از ظهر بیایی، برایت آماده خواهند بود."

    # say L741 aki
    old "Great, see you later."
    new "عالی، تا بعداً."

    # say L746 aki
    old "Yes, I got all of them."
    new "بله، همه‌شون رو گرفتم."

    # say L747 pla
    old "Oh, perfect."
    new "اوه، عالی."

    # say L754 pla
    old "Could you please explain to me again the what I have to do."
    new "لطفاً دوباره به من توضیح بده چه کاری باید انجام بدم."

    # say L755 aki
    old "Sure, it's very simple, at the moment we must send correspondence from some projects to three specific places."
    new "بله، خیلی ساده است، الان ما باید اسناد برخی پروژه‌ها را به سه مکان خاص ارسال کنیم."

    # say L758 aki
    old "For example, all documents sent to the mayor or his office have a red frame."
    new "مثلاً، تمام اسنادی که به شهردار یا دفترش ارسال می‌شوند، یک چهارچوب قرمز دارن."

    # say L761 pla
    old "Red, green and yellow, got it, "
    new "قرمز، سبز و زرد، فهمیدم،"

    # say L804 aki
    old "Wow, You're good at this!"
    new "وای، تو اینجوری خوبی!"

    # say L805 pla
    old "Haha, thanks! I'm doing my best..."
    new "هه، ممنون! سعی می‌کنم بهترین کار رو بکنم..."

    # say L806 aki
    old "Good job, keep it up!"
    new "خوب انجام دادی، ادامه بده!"

    # say L807 pla
    old "I've to... You know how [mo2] is..."
    new "من باید... تو می‌دونی چطور [mo2] هست..."

    # say L808 aki
    old "Yeah, I totally understand."
    new "بله، کاملاً متوجه هستم."

    # say L809 pla
    old "Hey, do you know if I can talk to [mo2]?"
    new "هی، می‌دونی من می‌تونم با [mo2] صحبت کنم؟"

    # say L810 aki
    old "Uhh, well she is busy all the time, I don't think I will attend to you, unless it's to scold or punish you..."
    new "اوه، خب او همیشه مشغوله، فکر نمی‌کنم بهت وقت بده، مگر اینکه برای تنبیه یا مجازات باشه..."

    # say L811 pla
    old "Hmm, right... Ok, thank you Akita."
    new "Hmm، درسته... خب، ممنونم آکیتا."

    # say L812 aki
    old "Have a good day [pla]."
    new "روز خوبی داشته باش [pla]."

    # say L814 pla
    old "Hmm maybe, I shouldn't be so good at this, if I want to have the chance to speak with [mo2] whenever she calls me to her office..."
    new "ممکنه، شاید نباید اینقدر خوب باشم، اگر بخواهم وقتی که [mo2] منو به دفترش صدا می‌کنه، فرصت بگیرم باهاش صحبت کنم..."

    # say L815 pla
    old "Maybe if I do bad work, [mo2] will call me to break my balls and I'll get the chance to talk to her about [mo1rel]..."
    new "شاید اگه کار بدتری بکنم، [mo2] منو برمی‌گرده و من فرصت می‌تونم باهاش در مورد [mo1rel] صحبت کنم..."

    # say L816 pla
    old "Oh man, I'm sure I will regret this."
    new "اوه مرد، مطمئن هستم اینو خواهم پشیمان شد."

    # say L829 aki
    old "Hmm... Sorry [pla], I hope next time you can do it better."
    new "همم... ببخشید [pla]، امیدوارم بار بعد بهتر انجام بدی."

    # say L830 pla
    old "Argh! Yes... I'll be more focused next time, sorry."
    new "آره! بله... بعداً متمرکز‌تر می‌شوم، معذرت."

    # say L831 aki
    old "It's fine, just do your best because you know how [mo2] is, she'll give you shit if you keep failing."
    new "خوبه، فقط بهترین تلاشتو بکن چون می‌دونی چطور [mo2] هست، اگه همچون این شکسته بخوای، به تو زور خواهد داد."

    # say L834 pla
    old "Gulp, I guess it's time."
    new "بلع، به نظر می‌رسه وقت شده."

    # say L835 aki
    old "Good luck..."
    new "بخت ت رو می‌خوام..."

    # say L857 mo2
    old "I know you were stupid but I didn't imagine this much."
    new "میدونم تو خنده‌دار بودی اما همینقدر نمی‌تونستم فکر کنم."

    # say L858 pla
    old "Listen, I- I know I did wrong again but... I- I am sorry [mo2]."
    new "بله، من- من می‌دونم دوباره اشتباه کردم ولی... من- من خیلی متاسفم [mo2]."

    # say L859 pla
    old "I'll be more careful next time."
    new "بعداً مراقب‌تر خواهم بود."

    # say L860 mo2
    old "Yeah... Whatever... I don't care about the next time..."
    new "بله... هر چی... من در مورد بعدی نگران نیستم..."

    # say L861 mo2
    old "Now you gotta pay for this one."
    new "الان باید برای این هم پرداخت کنی."

    # say L862 pla
    old "A- Again?"
    new "دوباره؟"

    # say L863 mo2
    old "I have done some stuff wrong with you..."
    new "من با تو چند کار اشتباه کردم..."

    # say L864 mo2
    old "You shouldn't get so much pleasure for all mistakes you've done here..."
    new "شما نباید از همه اشتباهاتی که اینجا کردی اینقدر لذت ببرید..."

    # say L866 mo2
    old "You have been a lucky idiot!"
    new "شما یک احمق خوشبخت بودید!"

    # say L867 mo2
    old "But not anymore!"
    new "اما دیگر نه!"

    # say L869 mo2
    old "I should get something in return for hiring such a stupid person... And for still paying you."
    new "باید چیزی به جای استخدام چنین احمقی دریافت کنم... و همچنان پرداخت دستمزد به تو."

    # say L870 mo2
    old "You have been the worst employee I have ever had... The most useless person I have worked with. You're disgusting."
    new "شما بدترین کارمندی بودید که تا حالا داشتم... انسانی بی‌فایده‌تر از شما هم ندیدم. شما مخملی هستید."

    # say L872 mo2
    old "What kind of punishment should I give you this time?"
    new "این بار چه نوع مجازاتی باید به تو بدم؟"

    # say L873 mo2
    old "I definitely did wrong giving you pleasure, an idiot like you will only learn the hard way."
    new "حتماً اشتباه کردم وقتی لذتت رو به تو دادم، یه احمق مثل تو فقط با راه سخت یاد می‌گیره."

    # say L874 mo2
    old "Then perhaps the best thing is that this time you are the one who gives pleasure, like the useless little bitch you are."
    new "پس شاید بهترین چیز این باشه که این بار تو خودت لذت بدی، مثل همین خر مفیدی که هستی."

    # say L875 mo2
    old "I know! Come here!"
    new "می‌دونم! بیا اینجا!"

    # say L883 mo2
    old "You'll lick my pussy... Let's see if you can do it well or you're completely useless..."
    new "پوسی من رو لیس کنی... ببینی خوب انجام می‌دهی یا کاملاً بی‌فایدی هستی..."

    # say L884 pla
    old "W- WHAT? Y- Your puss-"
    new "W- چه کاری؟ Y- پوسی‌ت-"

    # say L885 mo2
    old "I don't understand why you keep talking... More licking and less talking. You're my bitch, remember?"
    new "نمی‌فهمم چرا همچنان حرف می‌زنی... بیشتر لیسکن و کمتر حرف بزن. به خاطر داشتی که تو خرای منی؟"

    # say L901 pla
    old "Well, it's about [mo1], she-"
    new "خب، این بار در مورد [mo1] هست، او-"

    # say L902 mo2
    old "Ohh come on, you again with that?"
    new "اوه بیای، دوباره این حرف رو می‌زنی؟"

    # say L903 mo2
    old "I don't care! Don't waste my time with this bullshit."
    new "من نمی‌خوام! این حرف‌ها رو وقت من رو ببرن."

    # say L904 mo2
    old "I'm not going to pay again for all of you leechers..."
    new "من نمی‌تونم دیگه برای همه شما لیچرها پول بدهم..."

    # say L905 pla
    old "No, isn't about paying-"
    new "نه، این به پول نمی‌باشد..."

    # say L906 mo2
    old "Just go away."
    new "برو بیرون"

    # say L912 pla
    old "Hmm, this is not working..."
    new "Hmm، این کار درست نیست..."

    # say L929 sis
    old "[pla], [mo1rel] has been locked in her room all day long."
    new "[pla]، [mo1rel] همه روز در اتاقش قفل شده است."

    # say L931 sis
    old "Yes... She's so depressed..."
    new "بله... او خیلی ناراحت است."

    # say L932 pla
    old "This is serious... I don't know, we gotta do something."
    new "این جدیه... نمی‌دونم، باید چی کنیم."

    # say L933 pla
    old "Today I told [mo2] about my [mo1rel] but you know how she is... She refuses to get in touch."
    new "امروز با [mo2] در مورد [mo1rel]م حرف زدم اما می‌دونی اونجوریه... هیچ جور نمی‌خواد تماس بگیره."

    # say L934 sis
    old "She's a proud motherfucker!"
    new "اون مادرشوهر خودش!"

    # say L936 pla
    old "I know... I will..."
    new "می‌دونم... من هم خواهم کرد."

    # say L937 pla
    old "Don't worry Kylee, we'll do something."
    new "نگران نباش کایلی، ما کاری می‌کنیم."

    # say L939 sis
    old "I hope we do... See you, then."
    new "امیدوارم بشه... ببینم تو."

    # say L945 pla
    old "I definitely have to keep trying to talk with [mo2]."
    new "حتماً باید تلاش کنم با [mo2] صحبت کنم."

    # say L962 mo2
    old "It really seems you're a big idiot! You keep making the same mistakes..."
    new "وای، به نظر می‌رسه تو خیلی احمقی! همیشه همین اشتباه‌ها رو تکرار می‌کنی..."

    # say L964 mo2
    old "I assume you're already imagining how you gonna pay for it..."
    new "فکر کنم حالا در حال تصور اینه که چطور باید برایش پرداخت کنی..."

    # say L965 pla
    old "(Oh God, Now what?)"
    new "اوه خدا، حالا چه کاری؟"

    # say L966 pla
    old "[mo2]... I'll try to improve, it's just that... I- I'm worried about other things and it's difficult to focus sometimes."
    new "[mo2]... سعی می‌کنم بهتر شم، فقط اینکه... من- من نگران چیزهای دیگه‌ام و گاهی‌ها سخته تمرکز کنم."

    # say L967 mo2
    old "I don't CARE! I don't care about your shitty life."
    new "من نمی‌خوام! من از زندگی خرابت نمی‌خوام."

    # say L969 mo2
    old "You'll need to focus on this NOW!"
    new "الان باید روی این تمرکز کنی!"

    # say L970 mo2
    old "Now you will do what I tell you to do! You'll do whatever I want! I'm your Master, I'm the one paying you and you'll follow my orders!"
    new "الان هر چی من می‌خوام انجام بدی! من ماسترت هستم، من هستم که پولت رو می‌دهم و تو باید دستورات من رو اجرا کنی!"

    # say L971 mo2
    old "Your job and what you do is shit! Now do what I tell you."
    new "کارت و هر چیزی که انجام میدی خاکستره! حالا باید اون چیزی رو که من میگم بکنی."

    # say L972 mo2
    old "Now is the time to pay back the money I'm paying you for all your shitty work."
    new "الان وقت برای پرداخت پولی است که به خاطر کارهای شما پرداخت می‌کنم."

    # say L979 mo2
    old "Come on, you already know what to do."
    new "بیا، تو قبلاً می‌دونی باید چی کنی."

    # say L980 pla
    old "Uhh... A- alright."
    new "اوه... خب بله."

    # say L994 pla
    old "I know you don't wanna hear about my [mo1rel] but... B- But she is not ok, she keeps crying for you..."
    new "می‌دونی نمی‌خوای از [mo1rel] من بشنید ولی... ولی او خوب نیست، همیشه برای تو گریه می‌کنه..."

    # say L995 pla
    old "I think she's getting depressed."
    new "فکر می‌کنم افسردگی شده."

    # say L996 pla
    old "Why don't you call her? Just to... Argh!"
    new "چرا نمی‌تونی بهش تلفن کنی؟ فقط برای... آره!"

    # say L998 mo2
    old "Crying? Is she that bad?"
    new "خوشکری؟ اینقدر بد است؟"

    # say L999 pla
    old "I'm not lying, she's feeling like shit."
    new "من دروغ نمی‌گم، او خیلی بد حالتونه."

    # say L1000 mo2
    old "I could visi-"
    new "من می‌تونم برم ببینم-"

    # say L1001 mo2
    old "No! Just stop with that bullshit... And get out..."
    new "نه! فقط این هرج و مرج رو توقف بده... و برو بیرون..."

    # say L1016 pla
    old "What the... W- what are you doing."
    new "چه کاری می‌کنی؟"

    # say L1019 mo2
    old "Well, I knew you wouldn't learn so I'll have to use more drastic methods."
    new "خب، میدونستم که نمی‌آموزی پس باید روش‌های سخت‌تری رو استفاده کنم."

    # say L1020 mo2
    old "So I'm going to give you a couple of new lessons, it seems that with you it will always have to be in the hard way."
    new "پس من چند درس جدید بهت می‌دم، به نظر می‌رسه با تو همیشه باید راه سخت رو بریم."

    # say L1027 mo2
    old "Alright, undress and lie on the floor."
    new "خوب، لباستو ببرد و روی زمین دراز بکش."

    # say L1028 pla
    old "B- but... I- I don't-"
    new "B- ب- ب- من- من نمی‌تونم-"

    # say L1029 mo2
    old "Are you questioning your master's orders?"
    new "آیا دستورات ماسترت رو سؤال می‌کنی؟"

    # say L1030 pla
    old "No, no, I'm sorry master."
    new "نه، نه، من عذرخواهم، ماستر."

    # say L1031 mo2
    old "That sounds a lot better."
    new "این به نظر خیلی بهتر می‌رسه."

    # say L1044 mo2
    old "Again? Let me guess, it's about [mo1], isn't it?"
    new "دوباره؟ بگو ببینم، احتمالاً درباره [mo1] هست، نه؟"

    # say L1045 pla
    old "Well, yes, she is-"
    new "بله، اوست-"

    # say L1046 mo2
    old "Not today, I really don't have time, I already wasted it all with you."
    new "امروز نه، واقعاً وقت ندارم، همه وقتمو با تو ضایع کردم."

    # say L1047 mo2
    old "Maybe if you do a good job I wouldn't have to waste time with you."
    new "شاید اگر کارت خوب بود نباید وقت رو با تو بگذونم."

    # say L1062 mo2
    old "What a surprise, again complaints about your work."
    new "چه مفاجا، دوباره شکایت از کار تو."

    # say L1063 pla
    old "Could we start, talking about [mo1]?"
    new "ممکنه شروع کنیم، در مورد [mo1] صحبت کنیم؟"

    # say L1064 mo2
    old "Do you pretend to be the one who gives the orders?"
    new "آیا می‌خواهی بازی کنی که تو دستور می‌دهی؟"

    # say L1065 pla
    old "No, I'm sorry, master."
    new "نه، معذرت، ماستر."

    # say L1066 mo2
    old "That sounds so much better."
    new "این به نظر خیلی بهتر می‌رسه."

    # say L1067 mo2
    old "Okay, let's not waste any more time, so get naked and lie down on the floor."
    new "باشه، بیایید وقت بیشتری ضایع نکنیم، پوششت رو بردار و روی زمین دراز بکش."

    # say L1068 pla
    old "Yes, master."
    new "بله، خانم."

    # say L1081 pla
    old "[mo2]... You can hate this... Torture me if you want... B- But my [mo1rel] is really bad, she's not even eating."
    new "[mo2]... می‌تونی اینو نفرت کنی... اگه می‌خوای برام زدن کن... اما [mo1rel] واقعاً بد هست، حتی غذا هم نمی‌خورد."

    # say L1083 pla
    old "Visit her, please... Make me work more if you want... But just visit her."
    new "لطفاً بهش برو... اگه می‌خوای من رو بیشتر کار دهم... ولی فقط بهش برو."

    # say L1084 mo2
    old "Argh! Ok... Let's imagine I'll go... When should I pass by."
    new "آره! خب... فرض کنیم می‌روم... باید چه زمانی از کنارش بگذرم؟"

    # say L1085 pla
    old "Really? Well... Let me check with her. [mo2], thanks! This will make her so happy."
    new "حقاً؟ خب... بیای دیدمش. [mo2]، ممنون! این خوشحالش می‌کنه."

    # say L1086 mo2
    old "Listen little bastard! I'll go just because I wanna see if she is really that bad, not because of you. Got it?"
    new "بچه خوب، من برای اینکه ببینم واقعاً بد هست یا نه می‌روم، نه برایت. درست می‌کنی؟"

    # say L1087 pla
    old "Yes, yes... T- Thanks anyway."
    new "بله، بله... ممنون همچنان."

    # say L1089 mo2
    old "Ask her when it's a good time to swing by and I'll be there..."
    new "بهش بپرس وقت خوبی برای مراجعه کردن هست تا من اونجا باشم..."

    # say L1090 mo2
    old "I hope you're not lying to me..."
    new "امیدوارم دروغ نگویی..."

    # say L1092 pla
    old "N- No."
    new "نه."

    # say L1093 mo2
    old "Fuck! I'll kill you if you're lying to me."
    new "شیطان! اگه دروغ می‌گی، قتلت می‌کنم."

    # say L1094 mo2
    old "Alright, go away. I have to work."
    new "خوب، برو برو. من باید کار کنم."

    # say L1096 pla
    old "(At least she'll see [mo1rel]... That's something.)"
    new "البته که او خواهد دید [mo1rel]... این هم چیزی است."

    # say L1115 pla
    old "Hi [mo1rel]! How are you?"
    new "سلام [mo1rel]! حالت چطوره؟"

    # say L1116 mo1
    old "Hi honey... I'm fine, and you?"
    new "سلام عزیزم... من خوبم، تو چطوری؟"

    # say L1117 pla
    old "Guess what?"
    new "بگو خب؟"

    # say L1118 mo1
    old "I don't know, what happened?"
    new "نمی‌دونم، چه خبری پیش اومده؟"

    # say L1119 pla
    old "[mo2] is coming to see you..."
    new "[mo2] می‌خواد از تو دیدن کنه..."

    # say L1120 mo1
    old "What? [mo2] wants to see me? When?"
    new "چه؟ [mo2] می‌خواهد از من ببیند؟ وقتش کیه؟"

    # say L1121 pla
    old "Well, I talked to her and she said she will come whenever you want..."
    new "خب، باهاش حرف زدم و گفت هر وقت تو خواستی بیاد..."

    # say L1122 mo1
    old "Oh God! That's great! Tell her to come tomorrow."
    new "اوه خداوند! این خوبه! بهش بگو فردا بیاد."

    # say L1123 mo1
    old "I'll have to wear something nice... Yes, tell her that tomorrow is fine and that I'll be waiting for her."
    new "باید لباس خوبی بپوشم... بله، بهش بگو که فردا خوبه و من منتظرش هستم."

    # say L1124 pla
    old "I'll... And I'm glad you're feeling better now."
    new "من... و خوشحالم که حالا بهتر هستی."

    # say L1125 mo1
    old "Thanks for doing this for me..."
    new "ممنونم که اینجوری برایم کار می‌کنی..."

    # say L1126 mo1
    old "Get some rest, honey... You've been working a lot."
    new "بگرد، عزیزم... تو خیلی کار کرده‌ای."

    # say L1127 pla
    old "Every day is harder, [mo1rel]... But it's fine as long as you're fine and less worried."
    new "هر روز سخت‌تر می‌شه، [mo1rel]... ولی خوبه طالما تو خوبی و کمتر نگرانی داری."

    # say L1128 pla
    old "I'm heading to my room... Love you [mo1rel]!"
    new "من به اتاقم می‌رم... دوستت دارم [mo1rel]!"

    # say L1147 mo2
    old "And here you are again... You are definitely a lost cause."
    new "و اینجا تو دوباره هستی... شما قطعاً یک امیدبخش نیستی."

    # say L1148 pla
    old "I know, I know, I'm sorry..."
    new "من می‌دونم، من می‌دونم، معذرت..."

    # say L1149 pla
    old "However, I actually wanted to talk about the visit- "
    new "ولی در واقع می‌خواستم در مورد بازدید حرف بزنم"

    # say L1150 mo2
    old "Shut up! I give a shit about what you want. I am your master and it's time for your punishment."
    new "بسته! من نمی‌دهم به این که تو چی می‌خوای. من مالکت هستم و الان وقت تعذیب‌ات رسیده."

    # say L1151 mo2
    old "Get on the floor... That's your place."
    new "بر پا نیستی... این جایت است."

    # say L1152 pla
    old "Come on, just a second. I don't want to do this."
    new "بیا، فقط یه لحظه. من نمی‌خوام این کار رو بکنم."

    # say L1153 mo2
    old "Get on the fucking floor now..."
    new "بر پا نشین حالا..."

    # say L1154 pla
    old "I- I'm not gonna do it... No, no more."
    new "من- من نمی‌خوام اینو بکنم... نه، دیگه نمی‌خوام."

    # say L1155 mo2
    old "I'm telling you to get on the fucking floor!"
    new "من به تو می‌گم روی زمین بنشین!"

    # say L1156 pla
    old "You can't keep doing this, it's humiliating for me."
    new "نمی‌تونی همینجوری ادامه بدهی، برای من مذلول‌کننده است."

    # say L1157 mo2
    old "WHAT!? What did you just say to me? Did you say NO to your Master?"
    new "چه!؟ به من چه گفتی؟ آیا به ماستر خودت نه گفتی؟"

    # say L1162 mo2
    old "Do you think you are better than me? I have kicked bigger butts than yours!"
    new "فکر می‌کنی خودت بهتر از من هستی؟ من پشت‌های بزرگ‌تر از تو رو شکسته‌ام!"

    # say L1163 mo2
    old "You're getting in real trouble with me! I'm commanding you, did you get that part?"
    new "با من مشکل جدی داری! من به تو دستور می‌دم، این قسمت رو درک کردی؟"

    # say L1165 mo2
    old "Don't you dare to say NO to me, you obey to whatever I say because I'm your fucking master and you're nothing..."
    new "نباشی تا به من نه بگی، تو باید به هر چیزی که من می‌گم اطاعت کنی چون من مالک شما هستم و تو هیچی نیستی..."

    # say L1166 mo2
    old "You're my little bitch, a cockroach, my slave..."
    new "تو همچون یک خرچنگ کوچکی برای من هستی، یک عامله، یک برده..."

    # say L1167 mo2
    old "This time you will really be punished, you must learn to obey your master."
    new "این بار واقعاً مجازاتت خواهد شد، باید بفهمی از حاکم خودت پیروی کنی."

    # say L1183 pla
    old "Master? May I ask you something?"
    new "استاد؟ می‌تونم ازت چیزی بپرسم؟"

    # say L1184 mo2
    old "Hmm... You're learning... You're starting to understand..."
    new "همم... در حال یادگیری هستی... شروع کردی درک کنی..."

    # say L1185 mo2
    old "It's good that you ask me... You don't do anything without my permission."
    new "خوبه که از من می‌پرسی... هیچ کاری بدون اجازه‌ی من نمی‌کنی."

    # say L1186 mo2
    old "Speak..."
    new "حرف بزن..."

    # say L1187 pla
    old "I spoke to my [mo1rel] and she said you can go and see her today... I- if you want..."
    new "به [mo1rel]م حرف زدم و او گفت می‌تونی امروز براش بره... اگه می‌خوای..."

    # say L1188 mo2
    old "Hmm... Fine... I'm going today... Just want to get it over with..."
    new "Hmm... خوب... امروز می‌روم... فقط می‌خوام این کار رو تمام کنم..."

    # say L1189 pla
    old "T- Thanks..."
    new "ممنون..."

    # say L1190 mo2
    old "Alright, now get out!"
    new "البته، حالا برو بیرون!"

    # say L1196 pla
    old "Oh God, what just happened... At least [mo1rel] will be happy today..."
    new "اوه خدا، چه کاری اتفاق افتاد... حداقل ز[mo1rel] امروز خوشحال می‌شه..."

    # say L1197 pla
    old "I can't keep working here, I need to get away from [mo2]'s office."
    new "نمی‌تونم دیگه اینجا کار کنم، باید از دفتر [mo2] دور بشم."

    # say L1214 mo1
    old "Hi honey, how do I look?"
    new "سلام عزیزم، من چطور به نظر می‌رسم؟"

    # say L1215 pla
    old "Wow, you look gorgeous!"
    new "واو، تو زیبایی!"

    # say L1216 mo1
    old "Oh, really? Thank you honey..."
    new "اوه، واقعاً؟ ممنون عزیزم..."

    # say L1217 mo1
    old "So? Do you have any news about [mo2]?"
    new "پس؟ خبری از [mo2] داری؟"

    # say L1218 pla
    old "Uhh, yes, [mo2] is coming today... If that's what you're asking..."
    new "آره، بله، [mo2] امروز می‌آید... اگه این هست که می‌پرسی..."

    # say L1219 mo1
    old "Great! I'm gonna get ready for her."
    new "عالی! من برایش آماده می‌شوم."

    # say L1220 pla
    old "I hope you enjoy seeing her... And if you need anything, just let me know, [mo1rel]..."
    new "امیدوارم لذت برده باشی از دیدنش... و اگر نیازی داشتی، فقط به من بگو، [mo1rel]..."

    # say L1221 pla
    old "Now I gotta go, I need to take a nap..."
    new "الان من باید برسم، باید خواب بیام..."

    # say L1222 mo1
    old "Sure, take care, honey."
    new "البته، مراقب خودت با، عزیزم."

    # say L1230 pla
    old "(Huh? What's that noise?)"
    new "هی؟ این صدای چیه؟"

    # say L1235 pla
    old "It's on my [mo1rel]'s bedroom..."
    new "این صدای اتاق خواب ز[mo1rel] هست..."

    # say L1242 pla
    old "Wow, they are having sex!"
    new "واو، دارن جنس می‌کنن!"

    # say L1243 pla
    old "Oh my God, I have never been so happy to see someone having sex!"
    new "اوه خدا، هیچ وقت خوشحالم تر از این نبودم که ببینم دو نفر جنس می‌کنن!"

    # say L1251 pla
    old "Fuck! This is great! I won't have to work for [mo2] anymore..."
    new "شیطان! این خوبه! دیگه نمی‌تونم برای [mo2] کار کنم..."

    # say L1252 pla
    old "They're back together, everything will be fine and I won't have to go back to her office."
    new "اونا دوباره با هم شدند، همه چی خوبه و من دیگه نمی‌تونم برگردم به اداره‌اش."

    # say L1270 pla
    old "From now on, I am free! I will no longer have to bear Jane's humiliations!"
    new "از این به بعد آزادم! دیگر نمی‌تونم تحمل کنم تحقیرهای جین!"

    # say L1281 pla
    old "H- Hey... [mo2], h- how are you?"
    new "ه- هی... [mo2]، ح- حالت چطوره؟"

    # say L1282 mo2
    old "Don't pretend to be a good guy... I know how shitty you're and how pervert you can be."
    new "نباشی خوب بازی کن... من میدونم چقدر بد و چقدر پرورتی می‌تونی باشی."

    # say L1284 mo2
    old "I have a business trip, but I'll see you in the office in a few weeks..."
    new "من سفر تجارتی دارم، اما چند هفته دیگه در دفترت می‌بینم..."

    # say L1285 pla
    old "B- But..."
    new "B- ب- اما..."

    # say L1286 mo2
    old "Excuse me!?"
    new "ببخشید!؟"

    # say L1287 mo2
    old "Did I hear a BUT?"
    new "آیا یک «اما» شنیدم؟"

    # say L1288 mo2
    old "I thought you had already learned how you have to talk to me..."
    new "فکر می‌کردم قبلاً یاد گرفتی که باید با من چطور صحبت کنی..."

    # say L1289 pla
    old "S- Sorry..."
    new "ببخشید..."

    # say L1291 pla
    old "Master... May I talk to you?"
    new "استاد... می‌تونم با شما صحبت کنم؟"

    # say L1292 mo2
    old "Now you can, slave."
    new "الان می‌تونی، برده."

    # say L1293 pla
    old "You said that we'll see each other in the office bu-"
    new "گفتی که در دفتر هم می‌بینیم، اما-"

    # say L1294 mo2
    old "Yes, I said it!"
    new "بله، من همین گفتم!"

    # say L1295 mo2
    old "You'll do whatever I want, nothing's gonna change..."
    new "تو هر چی من می‌خوام انجام می‌دی، هیچ چیز تغییر نمی‌کنه..."

    # say L1296 mo2
    old "Regardless of the situation between [mo1] and I, you'll keep obeying me... I'm your master and that won't change."
    new "با توجه به وضعیت بین [mo1] و من، شما همچنان به من اطاعت خواهید کرد... من مالک شما هستم و این تغییر نخواهد کرد."

    # say L1297 mo2
    old "Don't forget that... Now you are my bitch."
    new "فراموش نکن... حالا تو خر مال منی."

    # say L1299 pla
    old "Y- Yes..."
    new "بله..."

    # say L1301 pla
    old "Oh God... "
    new "اوه خداوند..."


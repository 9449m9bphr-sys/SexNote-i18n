# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/lydAnimations.rpy
translate persian strings:

    # say L6 lyd
    old "You definitely should make many young girls very happy."
    new "حتماً باید خیلی دختران جوان رو خوشحال کنی."

    # say L7 lyd
    old "It's so long and thick."
    new "اینقدر طولانی و ضخیم است."

    # say L8 lyd
    old "And rock solid too."
    new "و همچنین سخت و محکم است."

    # say L12 lyd
    old "Oh my god! You're getting even harder!"
    new "اوه خدا! هر بیشتر سخت می‌شی!"

    # say L13 lyd
    old "Your dick! It's so hard and hot in my hand!"
    new "لیدیا: نوکت! تو همینجور سخت و گرم تو دست من هستی!"

    # say L14 lyd
    old "That's it, let go! Just let me stroke it!"
    new "بزن، بیا! فقط بگذار من اینجوری آن را لمس کنم!"

    # say L18 lyd
    old "Do you like this? Do you like how I play with your dick?"
    new "این رو دوست داری؟ دوست داری من با نوکت بازی کنم؟"

    # say L20 lyd
    old "Is this dick that hard because of me? Do you think I'm sexy?"
    new "این پیپک از خاطر من اینقدر سخت شده؟ آیا فکر می‌کنی من جنسی هستم؟"

    # say L22 pla
    old "Y-yes, you are sexy!"
    new "بله، تو جنسی هستی!"

    # say L45 pla
    old "I- I think I'm about to!"
    new "من- من فکر کنم دارم می‌آیم!"

    # say L46 lyd
    old "Yes! cum!"
    new "بله! شوش!"

    # say L47 lyd
    old "I want to see you shoot all your hot stuff because of me!"
    new "من می‌خوام ببینم تو همه مایه گرمتو برای من پخش می‌کنی!"

    # say L63 lyd
    old "Oh yeah! It's just as I imagined."
    new "اوه بله! دقیقاً مثل آنچه تصور کرده بودم."

    # say L64 lyd
    old "It has an amazing taste!"
    new "این طعم شگفت‌انگیز است!"

    # say L65 lyd
    old "And it's so hot!"
    new "و هم اینقدر گرم است!"

    # say L69 lyd
    old "I don't think I've ever blown a dick this big, even in the past."
    new "فکر نمی‌کنم تا حالا شاخی اینقدر بزرگ نواخته باشم."

    # say L70 lyd
    old "I think this is the best dick I've seen."
    new "فکر کنم این بهترین شاخی که دیده‌ام."

    # say L71 lyd
    old "And it's also the biggest!"
    new "و همچنین بزرگ‌ترین هم هست!"

    # say L75 lyd
    old "Mmmm! Slrrp!"
    new "ممم! لرز!"

    # say L76 lyd
    old "Do you like my mouth?"
    new "آیا دوست داری دهانم رو؟"

    # say L77 lyd
    old "Do you like how I do it?!"
    new "آیا دوست داری که اینجوری انجام بدم؟!"

    # say L101 lyd
    old "I can feel how your dick twitches in my mouth!"
    new "می‌تونم احساس لرزش ناخن تو توی دهانم کنم!"

    # say L102 lyd
    old "Do it [pla]!"
    new "[pla] بکن!"

    # say L103 lyd
    old "Cum in my mouth young man!"
    new "در دهانم بیا جوان!"

    # say L104 pla
    old "O- ok!"
    new "ب-بله!"

    # say L111 lyd
    old "That was great. Young men really are something special."
    new "این عالی بود. جوان‌ها واقعاً چیزی خاص هستند."

    # say L112 lyd
    old "But you know [pla], I think you're extra special."
    new "اما می‌دونی [pla]، فکر کنم تو خیلی خاصی."

    # say L113 lyd
    old "I mean, even when I was young, I never saw a dick like yours before."
    new "من می‌گم، حتی وقتی جوان بودم هیچ ناخنده‌ای مثل تو ندیده بودم."

    # say L114 lyd
    old "It's amazing how big and hard it is."
    new "الان دیدم چقدر بزرگ و سخته."

    # say L115 lyd
    old "It makes me wonder..."
    new "این به من خاطر می‌آید که..."

    # say L116 pla
    old "Ok... I think I should get dressed again."
    new "بله... فکر کنم باید دوباره لباس بکنم."

    # say L117 lyd
    old "Yeah, you're right. It would be best."
    new "بله، درست می‌گی‌ی. بهتره اینجوری باشه."

    # say L129 lyd
    old "Nngh! Wow, it's so big."
    new "نه! وای، اینقدر بزرگه."

    # say L131 lyd
    old "Y- yes, it's just that it's been a while."
    new "بله، فقط اینکه از آخر مدت‌هاست."

    # say L132 lyd
    old "And you're so big!"
    new "و تو هم اینقدر بزرگی!"

    # say L136 lyd
    old "Ah! Ah! Yes! Yes!"
    new "آه! آه! بله! بله!"

    # say L137 lyd
    old "Your dick, it's so big, and so hot!"
    new "پیپی تو خیلی بزرگه و گرم است!"

    # say L138 lyd
    old "It's filling me up so hard!"
    new "این به من خیلی سخت پر می‌کنه!"

    # say L139 lyd
    old "L- let's do it a little faster!"
    new "ل- لب‌ها رو خیلی سریع‌تر بکنیم!"

    # say L143 lyd
    old "Yes! Just like that!"
    new "بله! همینطور!"

    # say L144 lyd
    old "Don't stop! Keep going!"
    new "توقف نکن! همینطور ادامه بده!"

    # say L145 lyd
    old "Nngh! Yes! YES!"
    new "نه! بله! بله!"

    # say L168 pla
    old "I- I think I can't hold it in longer!"
    new "من فکر می‌کنم نمی‌تونم دیگه خودمو کنترل کنم!"

    # say L169 lyd
    old "Don't! Don't hold it!"
    new "نگه نداشته باش! نگه نداشته باش!"

    # say L170 lyd
    old "You can do it! CUM INSIDE!"
    new "تو می‌تونی! تو رو درون بیا!"

    # say L176 lyd
    old "You know? I believe this might have worked, I feel so much better now, like a weight has been lifted off my shoulders."
    new "میدونی؟ من فکر می‌کنم این کار جایی رسیده، حالا خیلی بهتر هستم، مثل اینکه وزنی از کتفم برداشته شده."

    # say L177 pla
    old "I'm glad you feel like that. I hope this actually helped you."
    new "خوشحالم که اینجوری حس می‌کنی. امیدوارم واقعاً بهت کمک کرده باشه."

    # say L178 lyd
    old "I'm sure it did, thanks a lot [pla]!"
    new "مطمئنم که همین کار کرد، ممنونم خیلی [pla]!"

    # say L179 pla
    old "You're welcome, I'm happy to help."
    new "خواهش می‌کنم، خوشحالم که کمک کردم."

    # say L191 lyd
    old "I'm gonna use my tongue all over the tip of your cock."
    new "من قصد دارم زبانم رو همه جا روی سر ناخن تو ببرم."

    # say L194 pla
    old "Uhh, I love that sensation, babe."
    new "اوه، من عاشق این حس هستم، عزیزم."

    # say L198 lyd
    old "Mmmm... It tastes so good! I love it."
    new "ممنون، خوشمزه است! دوست دارم."

    # say L201 pla
    old "Oh yeah babe, I'll definitely love your mouth."
    new "اوه بابا، حتماً دهانت رو دوست خواهم داشت."

    # say L202 lyd
    old "Slrrrp! Uhh you have no idea!"
    new "سلرپ! اوه تو هیچ ایده‌ای نداری!"

    # say L209 pla
    old "You should have a lot of experience, don't you?"
    new "باید تجربه زیادی داشته باشی، نه؟"

    # say L210 lyd
    old "Mmmm, yeah baby, but not with huge cocks like yours."
    new "ممنون عزیزم، ولی با نیم‌تنه‌های بزرگ مثل تو تجربه نداشتم."

    # say L213 pla
    old "Oh yeah babe, you will really enjoy my huge cock!"
    new "اوه بابی، واقعاً لذت خواهی برد از نیم‌تنه بزرگ من!"

    # say L214 lyd
    old "Mmm, that's exactly what I'm expecting."
    new "ممنون، اما من منتظرم که با عضوی بزرگ مثل تو لذت ببرم."

    # say L239 pla
    old "Ohh babe, I'm about to cum."
    new "اوه بابی، من الان می‌آیم."

    # say L240 lyd
    old "Oh no, you don't. That's barely the beginning. You know what comes next."
    new "نه، نمی‌تونی اینجوری. این هم شروع هست. می‌دونی بعدش چه می‌شه."

    # say L241 pla
    old "(Oh God.)"
    new "اوه خدا."

    # say L244 pla
    old "Oh, I know what comes next, that's right, you want to put it all in your mouth, don't you?"
    new "اوه، من می‌دونم بعدش چیه، همینه، تو می‌خوای همه‌ش رو تو دهانت بیاری، درسته؟"

    # say L245 lyd
    old "Yes! I want to feel it all in my mouth."
    new "بله! می‌خوام همه‌ش رو توی دهانم بیاد."

    # say L252 lyd
    old "I love how big your cock is!"
    new "من عاشق اینم که پوسی تو چقدر بزرگه!"

    # say L255 pla
    old "Suck it! Put my cock in your mouth!"
    new "شوک کن! پوسی‌ام رو تو دهانت بگذار!"

    # say L263 lyd
    old "Mmm, I just love the taste of your cock!"
    new "ممنون، من فقط عاشق طعم خروجی تو هستم!"

    # say L265 lyd
    old "I love how big and hot it always gets!"
    new "عشق دارم اینقدر بزرگ و گرم همیشه بشه!"

    # say L268 pla
    old "Yeah! Tell me more!"
    new "بله! بیشتر بگو!"

    # say L272 lyd
    old "This is the best cock I've ever had!"
    new "این بهترین پیپیه که تا حالا داشتم!"

    # say L274 lyd
    old "Nngh! Mmmm! I want more and more of it!"
    new "نه! مmmm! من می‌خوام بیشتر و بیشتر از این!"

    # say L277 pla
    old "Oh yeah? You want me to fuck you with it?"
    new "اوه بله؟ می‌خوای با این ناخنم بفراموشی؟"

    # say L278 lyd
    old "Yes! I love how it feels inside!"
    new "بله! عاشقم احساسش درون من!"

    # say L284 pla
    old "Do you like how my dick fills your mouth?"
    new "می‌پسندی که ناخستیم دهانت رو پر می‌کنه؟"

    # say L285 lyd
    old "Slrrrp! I love it! I can't get enough of it!"
    new "سلرپ! عاشقش هستم! نمی‌تونم بدونش باشم!"

    # say L287 lyd
    old "Don't cum yet! I want you to keep pushing your cock in my mouth!"
    new "هنوز نه! من می‌خوام تو ادامه بده این کار!"

    # say L290 pla
    old "That's it! Gobble on my cock!"
    new "این هست! از خروش من لذت ببر!"

    # say L314 pla
    old "I'm about to cum baby! Tell me you want it in your mouth!"
    new "من همین جا می‌آیم بیبی! بگو می‌خوای تو دهانت بیاد!"

    # say L315 lyd
    old "Yes! Yes! Shoot it all in my mouth!"
    new "بله! بله! همه‌اش رو توی دهانم بیا!"

    # say L317 lyd
    old "Fill my mouth with your hot cum!"
    new "دهانم رو با گرمای سپرمه‌ت پر کن!"

    # say L325 pla
    old "Phew... This guy is writing again, he says 'Wow, that was so great!'"
    new "پوف... این بچه دوباره نوشته، می‌گه «واو، این واقعاً عالی بود!»"

    # say L326 lyd
    old "Hahaha, great? Don't you say?"
    new "هahaha، عالی؟ نمی‌گی بی‌چین؟"

    # say L327 lyd
    old "Tell him 'It really was, I can't wait for what's next.'"
    new "بهش بگو «واقعاً همچین بود، نمی‌تونم برای بعدی منتظر بیام.»"

    # say L331 pla
    old "He answered with 'Yeah, me neither, but that'll have to wait, I have to go work, I'm 30 minutes over my break! Talk to you later, bye!'"
    new "پاسخش این بود که «آره، من هم نه، ولی باید منتظر بقیه‌اش بمونم، باید برسم کار، ۳۰ دقیقه از وقت استراحتم گذشته! بعداً باهات صحبت می‌کنم، خداحافظ!»"

    # say L332 pla
    old "'But be sure I'm crazy to see you!'"
    new "اما مطمئن باش من دیوانه‌وار می‌خوام تو رو ببینم!"

    # say L333 lyd
    old "That's nice, I guess we'll talk later."
    new "این خوبه، حدس می‌زنم بعداً با هم صحبت می‌کنیم."

    # say L334 pla
    old "You don't want me to answer anything back?"
    new "می‌خوای جوابی به من بدی؟"

    # say L335 lyd
    old "There's no need, he'll talk to me later anyway."
    new "نیازی نیست، هر حال بعداً با من صحبت می‌کنه."

    # say L349 lyd
    old "Nngh! Oh yes! This is just what I've been wanting!"
    new "نه! اوه بله! همینه که می‌خواستم!"

    # say L350 lyd
    old "This long, thick hard cock of yours!"
    new "این لوله طولانی و ضخیم و سخت تو!"

    # say L351 lyd
    old "There's no other cock like it!"
    new "هیچ لوله‌ای مثل این نیست!"

    # say L355 lyd
    old "Y- your cock is the best!"
    new "Y- ناخنده تو بهترین هست!"

    # say L356 lyd
    old "I've never had any cock like this!"
    new "من هیچ ناخنده‌ای مثل این ندیده‌ام!"

    # say L357 lyd
    old "Yes, yes, fuck me more!"
    new "بله، بله، بیشتر با من بکن!"

    # say L361 lyd
    old "Ohh! I love how you push into my pussy!"
    new "اوه! عاشقم این‌که تو به مونی من می‌آیی!"

    # say L362 lyd
    old "I can't have enough of this hot cock!"
    new "نمی‌تونم از این نوک گرم کمتر بشه!"

    # say L363 lyd
    old "Fuck me! Fuck me more!"
    new "بزن بر من! بیشتر بزن!"

    # say L386 pla
    old "L- Lydia! I think I'm about to..."
    new "لیدیا! فکر کنم قراره خیلی زود..."

    # say L387 lyd
    old "Yes! Let it all out!"
    new "بله! همه‌اش رو بده!"

    # say L388 lyd
    old "Fill me with your hot cum!"
    new "من رو با سیاله گرم تو پر کن!"

    # say L394 lyd
    old "That was good!"
    new "عالی بود!"

    # say L395 lyd
    old "Just what I was expecting."
    new "همینطوری که انتظار داشتم."

    # say L397 pla
    old "Listen, I'm glad you're feeling better."
    new "بله، خوشحالم که حالت بهتر شده."

    # say L398 pla
    old "But, I think it's better if you just leave. Remember this isn't your house, someone could hear us."
    new "اما فکر می‌کنم بهتره فقط برو. به خاطر داشتی این خونه تو نیست، ممکنه کسی ما رو بشنونه."

    # say L399 lyd
    old "Leave? What are you talking about?"
    new "برو؟ درباره چی حرف می‌زنی؟"

    # say L400 lyd
    old "This is just the beginning!"
    new "این فقط شروعه!"

    # say L401 pla
    old "W- What? What else do you want to do?"
    new "و- و چه کاری دیگه می‌خوای بکنی؟"

    # say L402 lyd
    old "Ohh, it's something I wanted to try for the longest time."
    new "اوه، این چیزی هست که همیشه می‌خواستم امتحانش کنم."

    # say L403 lyd
    old "But my husband was too much of a prude for it."
    new "اما شوهرم خیلی خسته‌ساز بود برای این کار."

    # say L404 lyd
    old "Him and his stupid morale, always draggin me back!"
    new "او و اخلاق خفنه‌اش، همیشه منو به عقب می‌کشید!"

    # say L405 lyd
    old "So, now you're going to give me what I want..."
    new "پس حالا می‌دهی به من آنچه می‌خواهم..."

    # say L407 lyd
    old "Just come here and find out."
    new "بیا اینجا و ببین."

    # say L424 lyd
    old "It's ok if you start sl-"
    new "می‌تونی از این جا شروع کنی"

    # say L425 lyd
    old "AH! AAAH!"
    new "آه! آآاه!"

    # say L427 lyd
    old "Oh yes! This is what I wanted!"
    new "اوه بله! این همینه که می‌خواستم!"

    # say L428 lyd
    old "Mmm, nngh, it hurts a little, but is perfect!"
    new "مم، ننه، یه کم درد می‌کنه، اما خیلی خوبه!"

    # say L432 lyd
    old "Y- your dick is massive!"
    new "اوه، ناخواسته تو خیلی بزرگه!"

    # say L433 lyd
    old "It's stretching my ass so much!"
    new "اینقدر آسوم منو باز می‌کنه!"

    # say L434 pla
    old "S- should I stop?"
    new "ب- باید متوقف بشه؟"

    # say L435 lyd
    old "No! Don't you dare!"
    new "نه! حتماً متوقف نشو!"

    # say L436 lyd
    old "I'm loving this!"
    new "من اینو دوست دارم!"

    # say L440 lyd
    old "YES! YES! You fucking my ass with that big dick!"
    new "بله! بله! تو با اون لوله بزرگ منو از جلو تا پشت نiqué می‌کنی!"

    # say L441 lyd
    old "It's just what I wanted!"
    new "این همینه که می‌خواستم!"

    # say L442 lyd
    old "I'll never have enough of this dick!"
    new "هرگز از این لوله کافی نمی‌شوم!"

    # say L443 lyd
    old "I love it when you fuck me!"
    new "من عاشق اینم که تو مرا ناکارآگاهی کنی!"

    # say L466 lyd
    old "I can feel your dick twitching in my ass!"
    new "می‌تونم لولت رو توی مونم تکان می‌دونم!"

    # say L467 pla
    old "I- I'm about to finish!"
    new "من- من در حال آمدن هستم!"

    # say L468 lyd
    old "Do it! Finish in my ass!"
    new "بکن! توی مونم تمام شو!"


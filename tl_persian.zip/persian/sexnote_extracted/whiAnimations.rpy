# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/whiAnimations.rpy
translate persian strings:

    # say L6 whi
    old "Give me that big cock..."
    new "به من اون نیم‌تن بزرگ رو بده..."

    # say L8 whi
    old "Oh my, you've definitely grown a lot! "
    new "اوه، قطعاً خیلی رشد کرده‌ای!"

    # say L12 whi
    old "Uhh, it feels so warm and hard."
    new "اوه، احساسش گرم و سخت است."

    # say L14 pla
    old "Y- yes it feels nice too."
    new "بله، احساسش خوبه هم."

    # say L18 whi
    old "What about if you cum for mommy?"
    new "مama، اگه برای مامان خودت آمدی چطور می‌شد؟"

    # say L43 whi
    old "Mrs. W- white I- I-"
    new "خانم وایت من من"

    # say L44 whi
    old "Ohh, yeah baby..."
    new "اوه، بله عزیزم..."

    # say L45 whi
    old "Give it to mommy!"
    new "به مامان بده!"

    # say L53 whi
    old "I have to say, [pla], you have a wonderful cock."
    new "باید بگم، [pla]، شما عضو خیلی خوبی داری."

    # say L54 pla
    old "Uhh... T-thanks..."
    new "اوه... ممنون..."

    # say L64 pla
    old "Wow! Mrs. White, w- what are you doing?"
    new "واو! خانم وایت، ش- شما چه کاری انجام می‌دهید؟"

    # say L65 whi
    old "Just enjoy it baby... Mommy is gonna blow your mind..."
    new "فقط لذت ببر عزیزم... مامان مغزت رو خالی می‌کنه..."

    # say L66 pla
    old "(Holly shit!)"
    new "هالی شیت!"

    # say L70 whi
    old "Oh God, you got a huge cock..."
    new "اوه خدا، شما یک ناخن بزرگ داری..."

    # say L71 whi
    old "It hardly fits in my mouth."
    new "به سختی توی دهانم می‌ری."

    # say L76 whi
    old "Do you want to cum in my mouth?"
    new "می‌خوای توی دهانم بیاد؟"

    # say L78 whi
    old "I wanna taste it!"
    new "من می‌خوام اون رو بچارم!"

    # say L101 whi
    old "Oh yeah, cum for mommy!"
    new "اوه بله، برای مامان سیک کن!"

    # say L102 whi
    old "Give me all that cum baby."
    new "همه آن سیک رو به من بده عزیزم."

    # say L121 whi
    old "By the way, you haven't said anything about the food. Are you liking it?"
    new "البته، هنوز در مورد غذا هیچ نظری ندادی. آیا لذت می‌بری از آن؟"

    # say L122 pla
    old "Oh... yes ma'am, I- I like it... a lot."
    new "اوه... بله خانم، من- من خیلی دوستش دارم."

    # say L123 whi
    old "It makes me so happy to hear you say that."
    new "شما اینجوری گفتن خوشحالم."

    # say L124 whi
    old "I made everything with my... hands, after all."
    new "همه چیز را با... دست‌هام ساختم، در نهایت."

    # say L125 mik
    old "Yes, It's really good mom, thank you."
    new "بله، واقعاً خوبه مامان، ممنون."

    # say L130 whi
    old "I see you're enjoying it a lot, right [pla]?"
    new "می‌بینم خیلی لذت می‌بری، درسته [pla]؟"

    # say L131 pla
    old "Mmm... Y- yes ma'am, I- I like it a lot!"
    new "ممنون می‌خانم، خیلی لذت می‌برم ازش!"

    # say L132 whi
    old "Well, have as much as you like."
    new "خوب، هر قدر خواستی لذت ببر."

    # say L133 whi
    old "You can ask me for more whenever you want to."
    new "هر وقت خواستی از من بیشتر بخواه."

    # say L134 mik
    old "Yeah, I think I would like to repeat."
    new "بله، فکر کنم می‌خوام تکرار کنم."

    # say L155 whi
    old "Look at that [pla], you're almost done!"
    new "ببین اون [pla]، تقریباً تمام شده!"

    # say L156 whi
    old "Would you finish for me?"
    new "آیا برای من تمام می‌کنی؟"

    # say L157 pla
    old "Mmm... Yes Mrs. White..."
    new "ممنون می‌شوم خانم وایت..."

    # say L164 whi
    old "Well, it looks like you're done, did you enjoy it [pla]?"
    new "خوب، به نظر می‌رسه تمام شدی، لذت برده بودی [pla]؟"

    # say L165 pla
    old "Y- yes Mrs. White, it was very pleasing."
    new "بله خانم وایت، خیلی لذت برده‌ام."

    # say L166 mik
    old "What? But he hasn't finished his food... Why do you say he is done?"
    new "چه کاری؟ اما او غذایش رو تمام نکرده... چرا می‌گی هیچ کاری نداره؟"

    # say L167 whi
    old "Trust me honey, [pla] is completely satisfied."
    new "باور کن عزیزم، [pla] کاملاً راضی است."

    # say L168 whi
    old "Anyway, Mike, please take the dishes to the kitchen."
    new "مایک، لطفاً ظروف رو به آشپزخانه ببر."

    # say L169 mik
    old "Hmm, sure."
    new "Hmm، البته."

    # say L182 whi
    old "Mmm, yes, this big dick."
    new "می‌خواهم این پیپ بزرگ را در دهانم بگیرم."

    # say L183 whi
    old "It tastes so good in my mouth."
    new "این تو در دهانم خیلی خوشمزه است."

    # say L185 whi
    old "Just relax and enjoy it, like I'm enjoying it."
    new "فقط آرامش ببر و لذت ببر، مثل اینکه من لذت می‌برم."

    # say L189 whi
    old "God! I swear it's getting even bigger!"
    new "الله! قسمت می‌خورم که هر بار بزرگتر می‌شه!"

    # say L190 whi
    old "This is just what I wanted!"
    new "این همینه که می‌خواستم!"

    # say L191 whi
    old "Are you enjoying it [pla]?!"
    new "آیا از این لذت می‌بری [pla]؟!"

    # say L192 pla
    old "Y- Yes ma'am!"
    new "بله خانم!"

    # say L196 whi
    old "Yes! Shove that dick down my throat!!"
    new "بله! آن ناخودآگاهی را در حلق من وارد کن!!"

    # say L197 whi
    old "Push it!"
    new "بله! آن را وارد حلق من کن!"

    # say L198 whi
    old "Yes, fuck my mouth like that..."
    new "بله، مثل این جوری من را فک کن..."

    # say L199 whi
    old "Don't come yet! I want it a little longer!"
    new "هنوز نه! من می‌خوام کمی طولانی‌تر باشه!"

    # say L222 pla
    old "M- Mrs. White! I can't hold it anymore!"
    new "م- خانم وایت! دیگه نمی‌تونم تحمل کنم!"

    # say L223 whi
    old "Mmmm! It's ok, you can cum!"
    new "ممنون! می‌تونی بیایی!"

    # say L224 whi
    old "Cum for mommy!"
    new "برای مامان بیا!"

    # say L225 whi
    old "Give me all your load!"
    new "همه‌ی آن را به من بده!"

    # say L230 whi
    old "Mmm, I love your cum."
    new "ممنون، عشقم به آن."

    # say L231 whi
    old "It's like a very nice, hot, sweet treat!"
    new "این مثل یک لذت خوب، گرم و شیرین است!"

    # say L232 pla
    old "Mrs. White, I- I think we should get dressed."
    new "خانم واایت، من- من فکر می‌کنم باید لباس‌مون رو بپوشیم."

    # say L233 whi
    old "Oh no, what are you talking about?"
    new "اوه نه، درباره چی حرف می‌زنی؟"

    # say L234 whi
    old "We're only getting started, that was just the beginning."
    new "ما هنوز شروع نکرده‌ایم، این فقط آغاز بود."

    # say L235 whi
    old "Now it's time for the main course."
    new "الان وقت غذای اصلی است."

    # say L239 whi
    old "Oh fuck! He arrived already!"
    new "اوه شیطون! قرار بود بعد از همه چیز بیاد!"

    # say L240 pla
    old "Shit! He's gonna catch us! We better get dressed quickly."
    new "شیطون! اونجا می‌تونه ما رو ببینه! بهتره سریع لباس بذاریم."

    # say L242 whi
    old "I'm in here honey!"
    new "من اینجا هستم عزیزم!"

    # say L243 whi
    old "Just give me a second!"
    new "فقط یه لحظه بده!"

    # say L244 whi
    old "Hmm, this is annoying, he has to come back just when things are getting good!"
    new "این خیلی آزاردهنده است، او باید دقیقاً وقتی که همه چیز خوب می‌شود برگردد!"

    # say L245 pla
    old "We should just hurry up."
    new "باید سریع‌تر بشیم."

    # say L257 whi
    old "Mmm, look how hard it is."
    new "می‌بینی چقدر سخت است."

    # say L258 whi
    old "And you were pretending to be nervous."
    new "و تو هم در حال نمایش ناراحتی بودی."

    # say L260 whi
    old "Just relax, I'll make you cum before you know it."
    new "آرام باش، قبل از اینکه متوجه شی خواهی رسید."

    # say L264 pla
    old "M- Mrs. White... Mmm, Mike could come back a- any minute."
    new "م- خانم وایت... مم، مایک می‌تونه هر لحظه برگرده."

    # say L265 whi
    old "You're right, this is so naugthy!"
    new "درست می‌فرمایید، این خیلی ناشیمانه است!"

    # say L266 whi
    old "I love this adrenaline rush."
    new "من این هیجان را دوست دارم."

    # say L270 whi
    old "Mmm, yes, like that."
    new "می‌خوای اینجوری باشه."

    # say L271 whi
    old "Just enjoy it, I'll keep going."
    new "اشتیاقتو لذت ببر، من ادامه میدم."

    # say L272 whi
    old "I love how your cock twitches in my mouth."
    new "عشق‌من دست کم شما در دهان من لرزه می‌زنه."

    # say L295 whi
    old "I can feel you getting close!"
    new "می‌تونم احساس کنم تو نزدیک شدی!"

    # say L296 whi
    old "Do it, cum in my mouth!"
    new "بیا، تو در خوراکم بیای!"

    # say L297 whi
    old "I'll swallow it all!"
    new "من همه‌اش رو خواهم خورد!"

    # say L298 pla
    old "Ahhhh...."
    new "اوه..."

    # say L304 whi
    old "Oh, I loved that!"
    new "اوه، عاشق شدم!"

    # say L305 whi
    old "You were so excited, and you got soo hard!"
    new "تو خیلی هیجان زده بودی و خیلی سخت شدی!"

    # say L306 whi
    old "I think I'll do this again... "
    new "فکر کنم این رو دوباره انجام می‌دم..."

    # say L307 pla
    old "M- mrs. White, I think you should clean up before Mike comes back."
    new "م- خانم وایت، فکر کنم باید قبل از برگشت مایک تمیز کنی."

    # say L308 whi
    old "Sure, sure, it will be just a second."
    new "بله، بله، فقط یک لحظه خواهد بود."

    # say L317 whi
    old "Ah Yes! This big dick is just what I needed today."
    new "آه بله! این ناخنده بزرگ همینطوری که امروز نیاز داشتم."

    # say L318 whi
    old "I'll never get tired of the smell of your cock."
    new "من هرگز از بوی ناخنده‌ت خسته نمی‌شوم."

    # say L319 whi
    old "It's making me so wet!"
    new "این منو خیلی مرطوب می‌کنه!"

    # say L323 whi
    old "Mmm, yes, like that, enjoy it!"
    new "می‌تونی اینجوری ادامه بدهی، لذت می‌برم!"

    # say L324 whi
    old "Are you liking it you sweet boy?"
    new "آیا از این لذت می‌بری، حلوای من؟"

    # say L326 pla
    old "I-I am!."
    new "من-من هستم!"

    # say L330 whi
    old "Mmmm! Slrrp! This taste is the best!"
    new "ممم! سلرپ! این طعم بهترین هست!"

    # say L331 whi
    old "Your dick feels so hot inside my mouth!"
    new "پیشکش شما در دهان من خیلی گرم است!"

    # say L332 whi
    old "Do you like it [pla]?! Tell me!"
    new "آیا لذت می‌بری [pla]؟! به من بگو!"

    # say L333 pla
    old "Yes ma'am! I do!"
    new "بله خانم! من دوست دارم!"

    # say L356 whi
    old "Your dick! Is twitching!"
    new "پیکر تو! نه، بلکه ناخودآگاهی تو در حال لرزیدن است!"

    # say L357 whi
    old "I want you to cum! Do it!"
    new "من می‌خواهم تو جویی! انجام بده!"

    # say L358 pla
    old "I- I'm about to...!"
    new "من- من در حال رسیدن هستم...!"

    # say L359 whi
    old "Yes! Give me your cum!"
    new "بله! منو با سیالتو پر کن!"

    # say L364 whi
    old "Oh yes! It's always so good to have your dick in my mouth."
    new "اوه بله! همیشه خوشحالم وقتی ناخون تو توی دهانم هست."

    # say L365 whi
    old "I'll never get tired of it."
    new "من هرگز از این خسته نمی‌شوم."

    # say L366 pla
    old "Listen, Mrs. White, I think I just heard someone move outside."
    new "بگو خانم وایت، فکر کنم کسی بیرون حرکت کرده."

    # say L367 pla
    old "We should hurry up and..."
    new "باید سریع‌تر باشیم و..."

    # say L368 whi
    old "What are you talking about?"
    new "درباره چه چیزی حرف می‌زنی؟"

    # say L369 whi
    old "We're not done yet."
    new "هنوز تمام نشده است."

    # say L370 whi
    old "And last time we were interrupted when Mike got home."
    new "و آخر بار هم وقتی مایک به خونه آمد قطع شدیم."

    # say L371 whi
    old "So, you're not going anywhere. There's something else that I want right now!"
    new "پس، نمی‌روی جایی. چیزی هست که الان می‌خوام!"

    # say L387 whi
    old "Oh! Yes! That's it!"
    new "اوه! بله! همینه!"

    # say L388 whi
    old "I've been wanting for you to be inside me for a while!"
    new "می‌خواستم تو داخل من باشی، از همین اول!"

    # say L389 whi
    old "Yes! Like that, move a little faster."
    new "بله! همین‌جور، تندتر حرکت کن."

    # say L393 whi
    old "Oh boy, oh my sweet boy, yes, keep fucking me."
    new "اوه بچه عزیزم، بله، ادامه بده."

    # say L394 whi
    old "Oh yeah! Oh do you like how my pussy feels?"
    new "اوه بله! اوه آیا دوست داری که پوسی من همینطور حس می‌کنی؟"

    # say L395 pla
    old "Uhh yes, it feels amazing!"
    new "آره بله، خیلی عالی است!"

    # say L399 whi
    old "Ah! I love your dick!"
    new "آه! من عاشق ذکرتون هستم!"

    # say L400 whi
    old "Do you like that baby? Do you like how I fuck you?"
    new "آیا اینو دوست داری عزیزم؟ آیا دوست داری که من تو رو بکنم؟"

    # say L401 pla
    old "I- I think I'm about to finish!"
    new "من- من فکر کنم قراره تمام شم!"

    # say L402 whi
    old "Not yet, keep going baby boy!"
    new "هنوز نه، ادامه بده عزیزم!"

    # say L425 pla
    old "M- Mrs. White, I can't hold it anymore!"
    new "م- خانم وایت، دیگه نمی‌تونم تحمل کنم!"

    # say L426 whi
    old "It's ok, cum inside."
    new "خوبه، داخل من بیا."

    # say L427 whi
    old "Fill me up sweety!"
    new "حتماً بپرده برام عزیزم!"

    # say L433 whi
    old "Wow, that was great!"
    new "واو، این خیلی عالی بود!"

    # say L434 whi
    old "I'd been wanting to fuck you so bad."
    new "من از اول می‌خواستم تو رو بکنم، ولی هر بار که به تو نگاه می‌کردم، خیلی دوست داشتم با تو بخوابم."

    # say L435 whi
    old "And you were even better than I imagined you would be."
    new "و تو حتی بهتر از آن بودی که فکر می‌کردم باشی."

    # say L436 whi
    old "Did you like it too baby boy?"
    new "حبتون هم خوب بود نوزک؟"

    # say L437 pla
    old "Uh, yes, I really did."
    new "آره، واقعاً لذت بردم."

    # say L438 pla
    old "Listen Mrs. White I think it's better if I get dressed and leave."
    new "می‌شنم خانم وایت، فکر می‌کنم بهتره لباس بپوشم و برسم."

    # say L439 pla
    old "I've been here for a while and I don't want Mike to catch us."
    new "من اینجا هستم از کی به بعد و نمی‌خوام مایک ما رو ببینه."

    # say L440 whi
    old "Yeah, I think so too. It would be better."
    new "بله، من هم همین را می‌فکرم. بهتر است."

    # say L441 whi
    old "I'll see you and that big cock later."
    new "بعداً به تو و آن ناخن بزرگ خودت می‌آیم."

    # say L454 mik
    old "By the way, let me get back to what I was telling you before."
    new "باید به چیزی که قبلاً به تو می‌گفتم برگردم."

    # say L455 mik
    old "It was about Belle."
    new "مورد بله بود."

    # say L456 mik
    old "She wanted me to ask you if you could let us see the project you did with Hinn."
    new "او می‌خواست ازت بپرسم که آیا می‌تونی به ما پروژه‌ای که با هین انجام دادی نشون بدی."

    # say L457 mik
    old "It's for reference, we're very late with it, and she says that since it is my fault that we're late, I should ask you."
    new "این برای مرجع است، ما خیلی دیر هستیم و او می‌گه چون این اشتباه منه که دیر شده‌ایم، باید از تو بپرسم."

    # say L459 mik
    old "Woah, are you ok dude? You look kinda tense."
    new "وای، حالت خوبه داداش؟ به نظرت تنش داری."

    # say L460 pla
    old "Yeah... it's just... the sauce. I think it had something spicy in it."
    new "بله... فقط... صوص. فکر کنم چیزی تیز در اون بود."

    # say L461 mik
    old "Yeah, I think my mom put some chili in it, but it's very good anyway."
    new "بله، فکر کنم مامان چیلی قرار داده، ولی هر حال خوبه."

    # say L462 pla
    old "I- it is. Yeah she is really good..."
    new "بله، واقعاً خوب است."

    # say L463 pla
    old "Uhhh... You need the project? Sure."
    new "اوه... تو به پروژه نیاز داری؟ حتماً."

    # say L464 pla
    old "I- I have it on my... Mmmm... computer, I'll email it to you."
    new "من- من آن رو توی کامپیوترم دارم... مممم... به تو ایمیل می‌کنم."

    # say L465 mik
    old "Really? Thanks man you are the best."
    new "حقاً؟ ممنون بابا، تو بهترین هستی."

    # say L484 mik
    old "Oh, I forgot, Olivia told me she saw you the other day when she was leaving."
    new "اوه، من فراموش کردم، اولیویا به من گفت که روزی دیگه وقتی خارج می‌شد، تو رو دیده."

    # say L485 pla
    old "Uh?..."
    new "اوه؟..."

    # say L486 pla
    old "Oh yeah, I- I think we... crossed over... Ahh... on the way out."
    new "اوه بله، من فکر کنم ما... راه هم رفتیم... آه... وقت خروج."

    # say L487 mik
    old "Hmm... Yeah, that's what she told me. But dude, she was super angry about running into you."
    new "همم... بله، همینطور به من گفت. ولی برو، خیلی ناراحت بود از اینکه با تو برخورد کرد."

    # say L488 mik
    old "Please, don't tell anyone dude, or she won't talk to me anymore. Please?"
    new "لطفاً، به هیچ کس نگو، یا دیگه با من حرف نمی‌زنه. لطفاً؟"

    # say L489 pla
    old "S- Sure... no problem!"
    new "ب-Bale... هیچ اشکالی نداره!"

    # say L491 mik
    old "Thank you, you are a really good friend."
    new "ممنون، واقعاً دوست خوبی هستی."

    # say L510 mik
    old "Dude, you sure you are ok?"
    new "دود، مطمئنی که خوبی؟"

    # say L511 pla
    old "Mmm... Y- yeah... Ugh, sure... N- no problem."
    new "ممنون... ه- همین... اوه، حتماً... ن- نه مشکلی."

    # say L512 mik
    old "You should drink some water."
    new "باید آبی بنوشی."

    # say L514 pla
    old "Hmm, I'm definitely not the only one who will drink something."
    new "Hmm، من قطعاً تنها نیستم که چیزی می‌نوشم."

    # say L516 pla
    old "Oh... Never mind, it's just the spice talking here."
    new "اوه... فراموش کن، فقط این ادویه است که حرف می‌زنه."

    # say L554 mik
    old "Dude, I'm starting to get worried. You look like you're about to burts. Here, let me hand you..."
    new "دستا، من شروع کردم نگران باشم. به نظرت می‌رسه می‌تونی بپریشی. بیا، بگذار بهت بدهم..."

    # say L555 pla
    old "N- no... i- it's ok, I'm just feeling a little bad."
    new "ن- نه... ا- اینجوری خوب هست، فقط یه کم حس بد دارم."

    # say L556 pla
    old "Just give me a minute."
    new "بله، فقط یه لحظه بده به من."

    # say L557 mik
    old "Are you sure? I think you should relax and release everything."
    new "مطمئنی؟ فکر می‌کنم باید آرام شوی و همه چی رو رها کنی."

    # say L558 pla
    old "Ughh... That's exactly what I'm going to do..."
    new "اوه... همین کار رو می‌کنم."

    # say L578 whi
    old "Mmmm! It's so big, so thick and long!"
    new "میلیون! این خیلی بزرگ، خیلی ضخیم و طولانیه!"

    # say L579 whi
    old "I was waiting for this, baby boy!"
    new "من منتظر این بودم، عزیزم!"

    # say L580 whi
    old "That's it, fill me up!"
    new "پر کنید من رو!"

    # say L584 whi
    old "Ahhh! Mmmm!!"
    new "آه! مم!"

    # say L585 whi
    old "I love how hot your cock is in my pussy!"
    new "عشق‌من به این حرارت شما درون من!"

    # say L586 whi
    old "I can feel it filling me up!"
    new "می‌تونم احساس کنم تو من رو پر می‌کنی!"

    # say L587 whi
    old "It's so big and hot!"
    new "این هم بزرگ و گرمه!"

    # say L591 whi
    old "Oh god! This dick! I love it!"
    new "اوه خداوند! این پوس! من عاشقش هستم!"

    # say L592 whi
    old "MMMM! AAAAH! Yes! Yes!"
    new "MMMM! AAAAH! بله! بله!"

    # say L593 whi
    old "I love your cock sweetie!"
    new "من عاشق ناخن تو هستم حلوای من!"

    # say L594 whi
    old "I love to feel your cock inside me my baby boy!"
    new "من عاشق احساس پوس تو درون من هستم عزیزم!"

    # say L617 pla
    old "I-I'm about to finish Mrs. White!"
    new "من-من قراره خاتمه بیام خانم واایت!"

    # say L618 whi
    old "YES! YES! ME TOO!"
    new "بله! بله! من هم!"

    # say L619 whi
    old "Do it! Cum in my pussy!"
    new "بکن! تو را بپرداز!"

    # say L620 whi
    old "Do it my sweet baby!"
    new "بکن حلوای من عزیزم!"

    # say L624 whi
    old "Phew, that was amazing!"
    new "پوف، این خیلی عالی بود!"

    # say L625 pla
    old "Ohh yeah."
    new "اوه بله."

    # say L640 whi
    old "H- Hi son, I- I'm ok."
    new "سلام پسر، من خوبم."

    # say L641 whi
    old "I wasn't expecting you to come home so quickly."
    new "من منتظر نبودم که اینقدر زود برگردی."

    # say L643 mik
    old "Yeah, me either. But Olivia said she had to take care of some personal things."
    new "نه، من هم انتظار نداشتم. ولی اولیویا گفت که باید برخی مشکلات شخصی رو حل کنه."

    # say L644 mik
    old "So, I had to come early."
    new "پس باید زودتر اومدم."

    # say L645 whi
    old "Oh, I see, well..."
    new "اوه، من می‌فهمم، خب..."

    # say L646 whi
    old "Since you have some free time, why don't you go up to your room and play some video games?"
    new "چون وقت خالی داری، چرا نمی‌روی به اتاقت و بازی‌های ویدیویی بازی کنی؟"

    # say L647 whi
    old "Or just relax, you've been studying a lot these days, you deserve a break."
    new "یا فقط استراحت کن، اخیراً خیلی مطالعه کردی، یک استراحت کوچک را بهت می‌رسونه."

    # say L648 mik
    old "Sure, but first I'm going to grab a snack from the kitchen."
    new "بله، ولی اول یه نoshی از آشپزخانه می‌برم."

    # say L654 whi
    old "Wait!"
    new "صبر کن!"

    # say L655 mik
    old "What? What happens?"
    new "چه کاری؟ چه اتفاقی می‌افتد؟"

    # say L656 whi
    old "Ehhh... Just, I know you're tired."
    new "اوه... فقط، می‌دونم خسته‌ای."

    # say L657 whi
    old "So, why don't you just go up and I'll prepare and bring you some snacks?"
    new "پس چرا نمی‌روی بالا و من برایت سناک آماده می‌کنم و می‌آورم؟"

    # say L658 mik
    old "Wow, really?"
    new "واو، واقعاً؟"

    # say L659 whi
    old "Yeah sure, just go up and I'll be there in a bit."
    new "بله حتماً، فقط بالا برو و من هم کمی بعد می‌آیم."

    # say L660 mik
    old "Ok, thanks mom!"
    new "باشه، ممنون مامان!"

    # say L666 whi
    old "Phew, that was really close"
    new "آه، این خیلی نزدیک بود."

    # say L667 pla
    old "I knew he was going to catch us!"
    new "می‌دونستم می‌خواست ما رو بگیره!"

    # say L668 pla
    old "We should have gone to your room!"
    new "باید به اتاقت رفتیم!"

    # say L669 whi
    old "Calm down, he didn't see anything."
    new "آرام شو، هیچ چیزی ندید."

    # say L670 whi
    old "But we don't have time to talk about that."
    new "اما وقت برای صحبت درباره این نیست."

    # say L675 mik
    old "Mom! Do you think you could bring me a soda with the snacks?"
    new "مامان! فکر می‌کنی می‌تونی برایم یه نوشیدنی هم بیاری؟"

    # say L677 whi
    old "Now, quickly, leave!"
    new "الان، سریع، برو!"

    # say L678 pla
    old "Ok, ok, I'm going!"
    new "باشه، باشه، می‌روم!"

    # say L692 whi
    old "Ah! Ah! Ah! That's it sweety, fuck me just like that."
    new "آه! آه! آه! اینجاست عزیزم، همینطور مرا بگیر."

    # say L693 whi
    old "I- I can feel your entire dick! It's so long and thick!"
    new "من- من می‌تونم کل پیپت رو حس کنم! خیلی طولانی و ضخیم هست!"

    # say L694 whi
    old "Yes! This is just what I wanted!"
    new "بله! این دقیقاً همان چیزی است که می‌خواستم!"

    # say L698 whi
    old "Ah! It's so good!"
    new "آه! خیلی خوبه!"

    # say L699 whi
    old "Mmm I love your big cock!"
    new "ممم من عاشق ناخن بزرگت هستم!"

    # say L700 whi
    old "Ohh yeah, just like that baby!"
    new "اوه بله، همینطور!"

    # say L704 whi
    old "Fuck! YES! YES! FUCK ME MORE!"
    new "بیا! بله! بله! بیشتر از مرا بزن!"

    # say L705 whi
    old "Fuck me, fuck your mommy!"
    new "من رو بزن، مامانت رو بزن!"

    # say L706 whi
    old "Keep pounding me!"
    new "به من ادامه بده!"

    # say L729 whi
    old "I- I can feel you tensing up!"
    new "من- من احساس می‌کنم تو در حال تنیدن هستی!"

    # say L730 whi
    old "Do it! CUM! CUM INSIDE ME!"
    new "بکن! خروجی کن! خروجی کن درون من!"

    # say L731 pla
    old "Y-yes!"
    new "بله!"

    # say L732 whi
    old "Ahhh! This is the best cock I've ever had!"
    new "اوه! این بهترین نخنگ بود که تا حالا داشتم!"

    # say L738 whi
    old "That was very good sweety!"
    new "این خیلی خوب بود عزیزم!"

    # say L739 whi
    old "You keep doing it better and better. You just keep making me want that cock even more every time..."
    new "شما هر بار بهتر انجام میدی. هر بار بیشتر میخوام اون زنگی رو..."

    # say L740 pla
    old "I'm glad you liked it Mrs. White."
    new "خوشحالم که لذت برده‌ای خانم وایت."

    # say L741 whi
    old "I didn't just like it, I loved it!"
    new "من فقط دوست داشتم نه، عاشقش شدم!"

    # say L742 whi
    old "And I hope you know we'll be doing it again very soon."
    new "و امیدوارم بدانی که ما همین زودتر دوباره این کار را خواهیم کرد."


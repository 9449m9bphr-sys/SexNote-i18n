# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mechanics/Interface.rpy
translate persian strings:

    # say L7 pla
    old "I shouldn't, is weekend."
    new "نباید، هفته‌末尾的注释似乎被截断了。根据上下文，正确的翻译应该是："

    # say L412 bri
    old "This is not what it looks like..."
    new "این همینطور نیست که به نظر می‌رسه..."

    # say L413 bri
    old "This is not a real bug... However it looks like you are using a really old file save..."
    new "این خطا واقعی نیست... اما به نظر می‌رسد از یک فایل ذخیره بسیار قدیمی استفاده می‌کنی..."

    # say L414 bri
    old "That's not bad, however as you can see this game has really improved since last months..."
    new "این بد نیست، اما همانطور که می‌بینی این بازی از ماه‌های گذشته خیلی پیشرفت کرده است..."

    # say L415 bri
    old "And this version is only compatible with the two last updates 0.14.0 and 0.14.5."
    new "و این نسخه فقط با دو بروزرسانی آخر 0.14.0 و 0.14.5 سازگار است."

    # say L416 bri
    old "So, if you use an old save from old versions or an old save bugged it would probably cause bugs in this version..."
    new "پس اگر از ذخیره قدیمی از نسخه‌های قدیمی یا ذخیره خراب استفاده کنی، احتمالاً مشکلاتی در این نسخه ایجاد می‌کنه..."

    # say L417 bri
    old "And we don't want to ruin your experience... So, to avoid that, we suggest you try the 'Skip to new content' option."
    new "و ما نمی‌خوایم تجربه‌ت رو خراب کنیم... پس برای جلوگیری از این، پیشنهاد می‌کنیم از گزینه‌ی 'پرش به محتوای جدید' استفاده کنی."

    # say L418 bri
    old "So you can play a full version of the game with only the new content in this update."
    new "پس می‌تونی نسخه کامل بازی رو با فقط محتوای جدید این آپدیت بازی کنی."

    # say L419 bri
    old "You just have to play start, name your character and then click the 'Skip to new content' option!"
    new "تو فقط باید شروع بازی رو انجام بدی، نام شخصیتتو تعیین کنی و بعد گزینه‌ی 'پرش به محتوای جدید' رو کلیک کنی!"

    # say L420 bri
    old "And if you want to play an old game that you haven't played before, you can contact the developers on {a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}"
    new "و اگر می‌خوای یه بازی قدیمی رو که هنوز نبازی‌کردی بازی کنی، می‌تونی با توسعه‌دهن‌ها در ز{a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a} تماس بگیری."

    # say L421 bri
    old "They can give you all the support you need."
    new "می‌تونن بهت همه پشتیبانی لازم رو بدن."

    # say L422 bri
    old "All right, that's it."
    new "خوب، این همه."

    # say L423 bri
    old "See you soon, here on Sexnote."
    new "به زودی اینجا در Sexnote بهت می‌بینم."

    # say L713 pla
    old "I shouldn't go there right now."
    new "نباید الان برم آنجا."

    # say L731 pla
    old "It's too late... I shouldn't go there right now."
    new "الان خیلی دیره... نباید الان برم آنجا."

    # say L738 pla
    old "I'm already very tired, I should rest and continue tomorrow..."
    new "من قطعاً خیلی خسته‌ام، باید استراحت کنم و فردا ادامه بدم..."


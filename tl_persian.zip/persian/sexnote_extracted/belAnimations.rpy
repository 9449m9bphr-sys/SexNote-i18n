# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/belAnimations.rpy
translate persian strings:

    # say L6 bil
    old "All right, how is that [pla]? Do you like how Belle jerks off your cock?"
    new "باشه، اینجوری [pla] خوبه؟ دوست داری که Belle نوزه‌ت رو جوشونه؟"

    # say L7 pla
    old "Ohh yeah it feels really nice."
    new "اوه بله، خیلی خوبه."

    # say L12 bil
    old "Ugh! That's really a big dick... Have you seen one like that before Belle?"
    new "اوه! این واقعاً ناخنده بزرگیه... تو قبلاً چیزی مثل این دیده‌ای Belle؟"

    # say L13 bel
    old "N- no, I had never seen a cock this big."
    new "نه، هیچ وقت ندیده‌ام چنین پوس بزرگی."

    # say L14 bil
    old "He seems to like it like that, keep going."
    new "به نظر می‌تونه دوستش داره اینجوری باشه، ادامه بده."

    # say L18 bil
    old "Keep going Belle! Don't stop."
    new "بلا! ادامه بده، متوقف نشو."

    # say L19 bil
    old "Do you like that [pla]?"
    new "می‌پسندی اینجوری [pla]؟"

    # say L20 pla
    old "Mmmm... Y- yeah."
    new "ممنون... آره."

    # say L21 bel
    old "It's soo hard in my hand, right now!"
    new "در دست من الان خیلی سخته!"

    # say L44 pla
    old "I-I think I'm cuming!"
    new "فکر کنم هستم!"

    # say L45 bel
    old "Uhh?"
    new "اوه؟"

    # say L46 bil
    old "Yes! Cum [pla]!"
    new "بله! بیا [pla]!"

    # say L47 bil
    old "Cum in her face!"
    new "در صورتش بیا!"

    # say L48 pla
    old "Ughhhh!"
    new "اوه هییییی!"

    # say L54 bel
    old "Ughh... You gotta be more careful [pla], I'm all covered with cum now."
    new "اوه... باید مراقب‌تر بودی [pla]، حالا همه جاشم اسپرم پر شده."

    # say L55 pla
    old "S- sorry, I couldn't really help it."
    new "ب- ببخشید، واقعاً نتونستم خودمو کنترل کنم."

    # say L56 bil
    old "Hah! What's the matter Belle?"
    new "هه! چه کاری داری Belle؟"

    # say L57 bil
    old "Aren't you happy you gave him a good time."
    new "آهان، نمی‌تونم بگم خوشحالم که به او لحظات خوبی دادی."

    # say L58 bel
    old "Phew, yeah right! As if I wanted this sticky thing on me."
    new "پوف، ها ها! مثلاً من می‌خواستم این چیز لخت رویم باشه."

    # say L59 bel
    old "Wait a minute, I'll clean myself."
    new "بیل، یه لحظه صبر کن، من خودمو تمیز می‌کنم."

    # say L71 sis2
    old "Oh! Oh my gosh!"
    new "اوه! اوه خدا!*"

    # say L72 sis2
    old "This cock!"
    new "این نون!"

    # say L73 sis2
    old "It's so good!"
    new "این خیلی خوبه!"

    # say L77 sis2
    old "I love how deep into my throat it's going!"
    new "عشق کردم اینجوری عمیق به حلقم می‌رسه!"

    # say L78 sis2
    old "Oh! Yeah! Do you guys like this?"
    new "اوه! بله! شما هم اینجوری دوست دارید؟"

    # say L79 sis2
    old "Seeing this huge cock fill my mouth up?!"
    new "دیدن این ناخن بزرگ که دهانم رو پر می‌کنه؟!"

    # say L83 sis2
    old "Yes! Yes! Yes!"
    new "بله! بله! بله!"

    # say L84 sis2
    old "Oh my gosh this is the best taste ever!"
    new "اوه خدا، این بهترین طعم هست!"

    # say L85 sis2
    old "I can't get enough of this taste!"
    new "نمی‌تونم از این طعم خودم رو بردارم!"

    # say L108 sis2
    old "Oh my gosh!"
    new "اوه خدا!"

    # say L109 sis2
    old "He's about to fill my mouth with his cum!"
    new "او قراره دهانم رو با مایعتش پر کنه!"

    # say L110 sis2
    old "Do you want to see it?"
    new "می‌خوای ببینی؟"

    # say L117 sis2
    old "That was fantastic guys!"
    new "این خیلی عالی بود دستاوردانتون!"

    # say L118 sis2
    old "And it's all thanks to your tips!"
    new "و همه این بخاطر نکاتتون بود!"

    # say L119 sis2
    old "If you want to see me getting fucked in the future remember to subscribe to premium and keep tipping."
    new "اگه می‌خواین بعداً من رو ببینید چسبیده باشید به ابری و همیشه تیپ بدید."

    # say L120 sis2
    old "And of course, join my fan club so you can download the video of this streaming."
    new "و البته، عضو کلوب خونه‌ی من شو تا بتونی این ویدیو رو دانلود کنی."

    # say L132 bel
    old "What great dick this is"
    new "این نوس خوبیه"

    # say L133 bel
    old "I love the way it feels in my hand!"
    new "عشق کردم این حس در دستم!"

    # say L134 bel
    old "It's so big and so nice!"
    new "این خیلی بزرگ و خوبه!"

    # say L138 bel
    old "Do you like how I stroke it?"
    new "می‌پسندی اینجوری که من بهش لمس می‌کنم؟"

    # say L139 bel
    old "Do you like how I grab your big dick in my hand?"
    new "می‌پسندی که من پیپ بزرگت رو توی دستم بگیرم؟"

    # say L140 bel
    old "It's such a nice big cock!"
    new "این پیپ خوب و بزرگ هست!"

    # say L144 bel
    old "Oh my god!"
    new "اوه خدا!"

    # say L146 bel
    old "So big and hot!"
    new "چقدر بزرگ و گرمه!"

    # say L169 bel
    old "I can feel you're about to cum!"
    new "می‌تونم بفهمم تو خیلی زود می‌آیی!"

    # say L170 bel
    old "Your dick is twitching so hard in my hand!"
    new "پوسه‌ت تو در دست من همینجور لرز می‌کنه!"

    # say L171 bel
    old "Come! I want you to see you do it!"
    new "بیا! می‌خوام ببینم انجام می‌دی!"

    # say L177 bel
    old "That was sooo good!"
    new "این خیلی خوب بود!"

    # say L178 bel
    old "But that's not all we're doing today guys!"
    new "اما این همه کار ما امروز نیست، جون‌ها!"

    # say L179 bel
    old "Why don't I show you what I have next for you?"
    new "چرا من به شما نشون ندم چی بعدی قراره باشه؟"

    # say L194 bel
    old "Mmm! The taste of this big cock!"
    new "مم! طعم این نیم‌پا خوبه!"

    # say L195 bel
    old "It's so hot and thick!"
    new "اینقدر گرم و ضخیم است!"

    # say L196 bel
    old "You guys wanted this, didn't you?"
    new "شما‌ها اینو می‌خواستین، درسته؟"

    # say L206 bel
    old "Do you like how I stuff my mouth with your dick?"
    new "می‌پسندید می‌تونم دیکتون رو تو دهانم بگذارم؟"

    # say L207 bel
    old "I love it!"
    new "عشقی بهش دارم!"

    # say L211 bel
    old "I love how you're filling my mouth with your big cock!!"
    new "من عاشق هستم که تو با اون لولت بزرگ دهانم رو پر می‌کنی!!"

    # say L212 bel
    old "I can't get enough of it!"
    new "نمی‌تونم ازش خسته بشه!"

    # say L213 bel
    old "I love how it tastes!"
    new "عشق‌من این طعم رو!"

    # say L217 bel
    old "My god! This taste is so good!"
    new "اللهی! این طعم خیلی خوبه!"

    # say L218 bel
    old "I love how you're ravishing my mouth!"
    new "عشق‌من اینه که تو دهانم رو می‌گیری!"

    # say L219 bel
    old "I can't get enough of your dick guys!"
    new "من نمی‌تونم از ناخودت روی خیس کردن من با شما خسته بشه!"

    # say L242 bel
    old "You guys want to cum in my mouth?"
    new "ببینید شماها می‌خواهید توی دهانم خروجی بدید؟"

    # say L244 bel
    old "I want you to fill my throat with your hot load!"
    new "می‌خوام حلق من رو با خروجی گرم شما پر کنم!"

    # say L250 bel
    old "That was so good guys!"
    new "این خیلی خوب بود شما!"

    # say L251 bel
    old "This cum is so good!"
    new "این سپر خیلی خوبه!"

    # say L252 bel
    old "It's just the best taste in the world!"
    new "این بهترین طعم در جهان است!"

    # say L273 bel
    old "Mmm! oh my god! I can never get enough of this dick!"
    new "ممنن! خدا می‌دونه! هیچ وقت از این ناخن نمی‌تونم بیوفتم!"

    # say L274 bel
    old "This has to be the most amazing dick in the world!"
    new "این حتماً خوب‌ترین ناخن در جهان هست!"

    # say L275 bel
    old "I love how much it's filling my mouth!"
    new "عشق‌من اینقدر پر کردن دهانم رو دوست دارم!"

    # say L281 bel
    old "Do you guys like seeing me like this? Who would want to have me right in front of you like this?"
    new "آیا شما دوستان می‌پسندید که من اینجوری باشم؟ چه کسی نمی‌خواست به جای شما اینجا بودم؟"

    # say L282 bel
    old "Do you like the way this cock is filling in my entire mouth?!"
    new "آیا می‌پسندید که این ناخن به کل دهانم پر شده؟!"

    # say L283 bel
    old "Oh yes! I can feel it pushing all the way to my throat!"
    new "اوه بله! می‌تونم احساس کنم تا گلویم می‌رسه!"

    # say L290 bel
    old "Mmm! Oh my god guys look at this!"
    new "ممن! خدای من، نگاه کنید به این!"

    # say L291 bel
    old "This cock is just as hard as it was a minute ago!"
    new "این ناخن همین الان مثل قبل سخته!"

    # say L292 bel
    old "My god! It's so good!"
    new "الهی! خیلی خوبه!"

    # say L293 bel
    old "It doesn't matter what happens, it's always so great!!"
    new "باز هم اهمیتی نداره، همیشه خیلی خوبه!!"

    # say L294 bel
    old "I- Slrrp! I bet you guys like this don't you?"
    new "اوه! حتماً شما هم از این لذت می‌برید، درسته؟"

    # say L295 bel
    old "I- Mmm! I love it!"
    new "من - مم! عاشقش هستم!"

    # say L300 bel
    old "OH! Yes! This cock tastes so great!"
    new "اوه! بله! این نیمکت خیلی خوشمزه است!"

    # say L301 bel
    old "Slrrrp! Mmmm! I can't get enough of it!"
    new "سلرپ! مم! نمی‌تونم ازش خسته بشه!"

    # say L302 bel
    old "Oh God I love the way you're fucking my mouth!"
    new "اوه خدا من عاشق هستم که تو دهانم رو ناکردی!"

    # say L326 bel
    old "Oh god! I can feel you getting tense!"
    new "اوه خدا! می‌تونم حس کنم تو در حال تنگ شدنی هستی!"

    # say L327 bel
    old "You're about to cum, right guys?!"
    new "تو در حال خروج هستی، درسته دوستان؟!"

    # say L328 bel
    old "Do it! Don't hold it back!"
    new "بکن! نگه نداشته باش!"

    # say L329 bel
    old "Throw your cum in my throat!"
    new "مغزتو تو خوراکم بده!"

    # say L336 bel
    old "I'm so happy you liked it too!"
    new "خوشحالم که تو هم لذت برده بودی!"

    # say L337 bel
    old "Especially because we've managed to get to the goal!"
    new "به خصوص اینکه تونستیم به هدف برسیم!"

    # say L338 bel
    old "So now we can go ahead and I can show you!"
    new "پس حالا می‌تونیم بره و من بهت نشون بدم!"

    # say L339 bel
    old "Just give me a couple of minutes, we're going to get ready for what comes next."
    new "بیا، فقط یه لحظه صبر کن، ما باید برای بعدی آماده شیم."

    # say L340 bel
    old "Don't go anywhere because I know you're going to love it!"
    new "نرو هیچ جا، زیرا می‌دونم خوشت می‌آید!"

    # say L349 bel
    old "Oh! Yeah!"
    new "اوه! همینه!"

    # say L350 bel
    old "The feeling in my throath is so great!"
    new "احساسی توی گلویم خیلی خوبه!"

    # say L355 bel
    old "I like it so much!"
    new "من خیلی دوست دارم!"

    # say L356 bel
    old "Do you like to see me sucking cock guys?!"
    new "آیا دوست دارید ببینید من ناخن را شیر کنم، جون‌ها؟!"

    # say L361 bel
    old "Oh, yeah! Yeah!"
    new "اوه، بله! بله!"

    # say L362 bel
    old "Oh my god! This is so good!"
    new "اوه خداوند! این خیلی خوبه!"

    # say L363 bel
    old "I can't imagine a better tasting dick than this!"
    new "نمی‌تونم به لولی خوشمزه‌تر از این بیاندازم!"

    # say L386 bel
    old "Oh yeah!"
    new "اوه بله!"

    # say L387 bel
    old "I can feel your dick twitching."
    new "می‌تونم احساس نوسان شاختت بکنم."

    # say L388 bel
    old "I know you're about to come!"
    new "می‌دونم قراره خروجی بدی!"

    # say L389 bel
    old "Do it guys! Cum in my mouth!"
    new "بفرستید شما دوستان! در دهان من بیاید!"

    # say L394 bel
    old "That was lovely guys!"
    new "این عالی بود ولی ما اینجا متوقف نمی‌شیم!"

    # say L395 bel
    old "But we're not stopping here!"
    new "اما ما اینجا متوقف نمی‌شویم!"

    # say L396 bel
    old "Let's get to what you really want to see!"
    new "بیایید به چیزی که واقعاً می‌خواهید ببینید برسیم!"

    # say L410 bel
    old "Hngh!"
    new "اوه خدا! این حس خیلی خوبه!"

    # say L411 bel
    old "Oh god! This is so amazing!"
    new "اوه خدا! این خیلی عالیه!"

    # say L412 bel
    old "My god! This sensation is so good!"
    new "الهی! این حس خیلی خوبه!"

    # say L421 bel
    old "Oh my god! Oh my god!"
    new "اوه خدا! اوه خدا!"

    # say L423 bel
    old "I love the way you're making me feel!"
    new "من عاشق این حس هستم که تو می‌دی!"

    # say L427 bel
    old "I can't get enough of this dick!"
    new "نمی‌تونم از این ناخن‌دار خودم برم!"

    # say L428 bel
    old "My pussy feels so good!"
    new "میل من اینجوری خیلی خوب می‌حسنت!"

    # say L429 bel
    old "This dick is so hot! It's so good!"
    new "این ناخن‌دار از درد می‌آید! خیلی خوب است!"

    # say L433 bel
    old "Ugh! Oh yes! yes!"
    new "اوه بله! بله!"

    # say L434 bel
    old "I love the way this feels!"
    new "من عاشق این حس هستم!"

    # say L436 bel
    old "My pussy feels so great!"
    new "پوسی من اینقدر خوب احساس می‌کنه!"

    # say L459 bel
    old "I know you guys want to come inside of me!"
    new "میدونم شما دوست دارید درون من بیاید!"

    # say L460 bel
    old "Do it! Fill my pussy again with your hot load!"
    new "بکن! دوباره پوسی‌ام رو با سیال گرمتو پر کن!"

    # say L461 bel
    old "I want to feel that cum inside me!"
    new "می‌خوام اون سیالتو داخل من حس کنم!"

    # say L468 bel
    old "I knew you would like it!"
    new "می‌دونستم خوشت می‌آمد!"

    # say L480 bel
    old "Oh god!"
    new "اوه خدا!"

    # say L481 bel
    old "This cock was so impressive before"
    new "این ناخن قبلاً هم خیلی جالب بود"

    # say L482 bel
    old "But now that I have it on my ass!"
    new "ولی حالا که اون رو توی دمدم دارم!"

    # say L483 bel
    old "It's even better!"
    new "بله، حتی بهتره!"

    # say L487 bel
    old "God! It's so good!"
    new "الهی! خیلی خوبه!"

    # say L488 bel
    old "I love how hard you're fucking my ass guys!"
    new "من عاشق هستم که چقدر سخت می‌پردازید به پیشوندم!"

    # say L489 bel
    old "Mmm! Do you like the way you're stretching me?!"
    new "ممنن! آیا دوست دارید که من رو اینجوری گشودید؟!"

    # say L493 bel
    old "Oh! Oh! Yes!"
    new "اوه! اوه! بله!"

    # say L494 bel
    old "Yes! Keep fucking me like that!"
    new "بله! همین طور با من بکن!"

    # say L495 bel
    old "I love the way it's filling me!"
    new "من عاشق این حس هستم که من را پر می‌کند!"

    # say L496 bel
    old "It's just stretching my ass!"
    new "فقط داره اش می‌کشه!"

    # say L519 bel
    old "OH yes! I can feel it!"
    new "اوه بله! احساسش می‌کنم!"

    # say L520 bel
    old "You're about to cum aren't you?"
    new "می‌خوای اومی، هستی؟"

    # say L521 bel
    old "Do it! Cum!"
    new "بکن! اوم!"

    # say L522 bel
    old "Fill my ass with your hot cum!"
    new "مغزم را با سیال گرمتو پر کن!"

    # say L529 bel
    old "That was so awesome guys!"
    new "این خیلی عالی بود دستاوردانتون!"

    # say L530 bel
    old "I knew you guys would do great today!"
    new "میدونستم شما امروز عالی می‌کنید!"

    # say L531 bel
    old "And you didn't disappoint!"
    new "و تو هم نخیستی!"

    # say L543 amo
    old "Slrrp! Oh my god!"
    new "اوه خدا!"

    # say L544 amo
    old "What a great taste this dick has!"
    new "این نوک چقدر طعم خوبی داره!"

    # say L545 amo
    old "Mmm! It feels so amazing in my mouth!"
    new "مم! این حس در دهانم واقعاً شگفت‌انگیزه!"

    # say L549 bel
    old "Do you like seeing us taste dick guys?"
    new "می‌تونی دیدن ما چطور این نوک رو می‌چشتم؟"

    # say L550 bel
    old "It's so amazing to lick it!"
    new "لیس کردن اون خیلی لذت‌بخشه!"

    # say L551 bel
    old "I love how hot it is!"
    new "عشق دارم چقدر گرم است!"

    # say L555 amo
    old "Slrrp! Mmmm!"
    new "سلرپ! مم!"

    # say L556 amo
    old "This dick is so hard!"
    new "این نونو خیلی سخته!"

    # say L557 amo
    old "And the taste! So amazing!"
    new "و طعمش! خیلی عالیه!"

    # say L580 bel
    old "I can feel this dick twitching!"
    new "می‌تونم این نونو رو تریس کنم!"

    # say L581 bel
    old "You want to see him cum because of our tongues don't you?!"
    new "می‌خوای ببینی از خونه‌اش به دلیل زبانه‌هامون سیک می‌شه، درسته؟!"

    # say L582 amo
    old "Oh yes! I want to see that!"
    new "اوه بله! می‌خوام این رو ببینم!"

    # say L589 bel
    old "Oh my God guys! You're amazing!"
    new "اوه خداوند! شماها عالی هستید!"

    # say L590 bel
    old "You actually did it!"
    new "وای، واقعاً انجام دادی!"

    # say L591 bel
    old "You reached the goal!"
    new "تو به هدف رسیدی!"

    # say L592 bel
    old "And you know what that means."
    new "و میدونی این چه معنی داره."

    # say L594 amo
    old "This is what I was waiting for!"
    new "این همینه که منتظرش بودم!"

    # say L608 amo
    old "Mmm! Oh God yes! This is what I had been waiting for!"
    new "ممنون! اوه خدا بله! این همینه که منتظرش بودم!"

    # say L609 amo
    old "What an amazing cock!"
    new "چه نوس عالی!"

    # say L618 amo
    old "Oh yeah [pla]!"
    new "اوه بله [pla]!"

    # say L619 bel
    old "Do you like how he's stretching her pussy?"
    new "آیا دوست داری ببینی چطور پوسی‌اش رو می‌کشوند؟"

    # say L620 amo
    old "I love the way it feels!"
    new "من عاشق احساسش هستم!"

    # say L624 bel
    old "Do you like how he's fucking her guys?"
    new "تو دوست داری ببینی چطور او رو می‌پیچوند؟"

    # say L625 bel
    old "It's amazing isn't it?"
    new "البته شگفت‌انگیز است، نه؟"

    # say L626 amo
    old "Oh my God! This cock is so amazing!"
    new "اوه خدا! این نوسکه واقعاً شگفت‌انگیز است!"

    # say L630 amo
    old "Oh God! Oh yes!"
    new "اوه خدا! اوه بله!"

    # say L631 amo
    old "Yes! Yes! Keep stretching my pussy!"
    new "بله! بله! ادامه بده، خودم رو گسترش بده!"

    # say L632 amo
    old "What a great cock! It's so hard! And so big!"
    new "چه نوک عالی! خیلی سخته! و خیلی بزرگ!"

    # say L655 amo
    old "I- Ah! I can feel his dick twitching!"
    new "اوه! می‌تونم اون لوله‌اش ریزه بشه!"

    # say L656 bel
    old "Are you about to cum?! Do it!"
    new "آیا قراره خروجی بدی؟ بکن!"

    # say L657 bel
    old "Fill her up with your cum!"
    new "او را با سیالت پر کن!"

    # say L658 amo
    old "Yes! Oh yes! I want to feel it inside!"
    new "بله! اوه بله! می‌خوام داخلش حس کنم!"

    # say L665 amo
    old "That was wonderful guys!"
    new "این عالی بود دوستا!"

    # say L666 amo
    old "I felt so amazing!"
    new "احساسی عالی بود!"

    # say L667 amo
    old "To have my pussy stretched like that!"
    new "پوسی من به این شکل گشوده شد!"

    # say L668 amo
    old "But now it's time for Belle's turn."
    new "اما حالا وقت بله هست."

    # say L669 bel
    old "Alright! I was waiting for this too."
    new "البته! من هم منتظر این بودم."

    # say L682 amo
    old "Oh! That's fucking hot to see!"
    new "اوه! دیدنش خیلی تحریک کنندهه!"

    # say L683 amo
    old "How does it feel Belle?"
    new "بعل، این چطور می‌تونه حس شه؟"

    # say L692 bel
    old "Hmm! I love it!"
    new "Hmm! عاشقش هستم!"

    # say L693 bel
    old "I can never get enough of this dick!"
    new "من هیچ وقت از این ناخودآگاه نمی‌تونم خسته بشه!"

    # say L694 bel
    old "No matter how many times I have it!"
    new "همچین‌طور هر چند بار هم بگیرم!"

    # say L698 amo
    old "God that's just so good to see!"
    new "الهی، دیدنش همینجور خوبه!"

    # say L699 amo
    old "Look at how that dick comes in and out of your pussy!"
    new "ببین چطور آن نی داخل و خارج از میشتو می‌ریزه!"

    # say L704 bel
    old "OH! OH! God!"
    new "اوه! اوه! الهی!"

    # say L705 bel
    old "This dick! Is so good!"
    new "این نی! خیلی خوبه!"

    # say L706 bel
    old "I love it! It's so hot!"
    new "من عاشقش هستم! خیلی گرمه!"

    # say L707 bel
    old "Do you like fucking me guys?"
    new "آیا دوست دارید با من بزنان بزنید؟"

    # say L730 bel
    old "I- Oh! I can feel his dick twitching!"
    new "اوه! احساس می‌کنم ناخن او در حال تکان خوردن است!"

    # say L731 bel
    old "I feel it coming!"
    new "احساس می‌کنم آماده‌ام!"

    # say L732 amo
    old "Do it! Cum inside her! Fill her pussy!"
    new "بکن! تویش خروجی کن! پوسی‌اش رو پر کن!"

    # say L740 bel
    old "I'm so happy you reached the goal!"
    new "من خوشحالم که هدف به دست آوردی!"

    # say L741 bel
    old "You never disappoint me!"
    new "تو هیچ وقت منو tele نمی‌کنی!"

    # say L742 amo
    old "It really was great!"
    new "واقعاً عالی بود!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/BriStory.rpy
translate persian strings:

    # say L11 pla
    old "I can't believe they were getting freaky in the living room."
    new "باورم نمی‌شه که تو اتاق نشیمن جنس می‌کردند."

    # say L13 pla
    old "I know they are married but... they should do that in their room..."
    new "می‌دونم از هم زن و شوهر هستن ولی... باید اونجوری رویه رویه در اتاق خودشون..."

    # say L15 pla
    old "Anyway... let's take a look at this weird book."
    new "بیای ببینیم این کتاب عجیب چه چیزیه."

    # say L17 pla
    old "Let's see what it says..."
    new "ببینیم چه می‌گه..."

    # say L19 pla
    old "Expergiscimini defensoris librum... The hell does that mean? Did that airplane came from China?"
    new "بیدار شو از کتاب دفاع... این چه معنی داره؟ آیا هواپیما از چین آمده؟"

    # say L26 sap
    old "A TUTELA EXPERGISCIMINI!!!"
    new "ا توتلا اکسپرگیسیمنی!!!"

    # say L28 pla
    old "What the fuck! What is this?!"
    new "وای خدا! این چیه؟!"

    # say L29 sap
    old "Qui audet excitare me!"
    new "کی می‌تواند من را بیدار کند!"

    # say L30 pla
    old "Oh my God! Please don't hurt me. I'm too young to die."
    new "اوه خداوند! لطفاً منو آسونه کن. من هنوز جوانم برای مردن."

    # say L31 sap
    old "Latina loqui tibi."
    new "با تو لاتین حرف می‌زنم."

    # say L32 pla
    old "What?  I- I don't understand. Just please don't kill me... I didn't do anything... This thing just fell from an airplane..."
    new "چه؟ من- من نمی‌فهمم. لطفاً من رو نکشی... هیچ کاری نکردم... این چیز فقط از هواپیما فرود آمد..."

    # say L33 sap
    old "Huh? What fell from an airplane?"
    new "هuh؟ چیزی از هواپیما ریزش کرد؟"

    # say L34 pla
    old "What? Oh, um, yeah! The book... This book fell from an airplane."
    new "اوه، بله! این کتاب... این کتاب از هواپیما ریزش کرد."

    # say L35 sap
    old "Oooh, hehe. Let's start from the beginning, shall we?"
    new "اوه، ههه. بیایم از اول شروع کنیم، خوبه؟"

    # say L36 sap
    old "Nice to meet you!  My name is Brixxida."
    new "خوشحالم که با تو آشنا شدم! نامم بریکسیدا هست."

    # say L42 pla
    old "Bri... xxi... da? Da fuck? Do you speak English?"
    new "بری... کسی... دا؟ دیوونه‌ای؟ تو انگلیسی می‌تونی حرف بزنی؟"

    # say L43 bri
    old "Well, yes! I'm speaking it now. Hehe. I can actually speak all human languages..."
    new "خب، بله! الان هم به انگلیسی صحبت می‌کنم. ههه. در واقع می‌توانم تمام زبان‌های انسانی رو بپردازم..."

    # say L45 pla
    old "Human languages? That's a weird way to say it. What exactly are you?"
    new "زبان‌های انسانی؟ این یه راه عجیب برای گفتن هست. تو دقیقاً چی هستی؟"

    # say L46 bri
    old "I'm the protective shinigami of the book you have there."
    new "من حفظ‌کننده شینیگامی کتابی هستم که تو داری."

    # say L49 pla
    old "OH FUCK! A shinigami? Oh my God..."
    new "اوه فکر کنم! یک شینیگامی؟ خدای من..."

    # say L50 pla
    old "I'm so sorry, miss shinigami lady. I just found this on the ground and I picked it up. Brought it home. It looked cool."
    new "ببخشید، خانم شینیگامی. این رو فقط روی زمین پیدا کردم و برداشتم. به خونه آوردم. خیلی جالب به نظر می‌رسید."

    # say L52 pla
    old "I didn't mean to-"
    new "من قصد نداشتم-"

    # say L53 bri
    old "Calm down, human. Hehe. If you were the one who found and opened the book, it means that you are the 'chosen One'."
    new "آرام شو، انسان. ههه. اگه تو کتاب رو پیدا کردی و باز کردی، بعنوان \"انتخاب شده\" در نظر گرفته می‌شی."

    # say L55 pla
    old "Cho-sen-one?"
    new "چوسن‌ون؟"

    # say L56 bri
    old "That's right!  And now the book belongs to you. And that also means I now belong to you. Hehe"
    new "درست است! و حالا کتاب به تو متعلق شده. و این هم به این معنی است که من هم به تو متعلق شدم. ههه"

    # say L58 pla
    old "What? You belong to me?  That means you are not going to kill me?"
    new "چه؟ تو متعلق به منی؟ این به معنای اینه که قرار نیه منو بکشی؟"

    # say L59 bri
    old "No, of course not. Why would you think that?"
    new "نه، البته نه. چرا اینجور فکر می‌کنی؟"

    # say L61 pla
    old "Because you look like a monster about to devour me."
    new "چون به نظر می‌رسی مثل یه وحشی هستی که می‌خوای من رو بخوری."

    # say L62 bri
    old "Oh? Sorry about that."
    new "اوه؟ معذرت برای این."

    # say L68 bri
    old "...Is this form better? Hehe."
    new "این شکل بهتره؟ هه هه."

    # say L77 mo2
    old "Why are you making that face, [pla]?"
    new "چرا این چهره رو می‌کنی، [pla]؟"

    # say L79 pla
    old "[mo2]... It is not what it looks like… I can explain... she is... naked... but she is... a shinigami-"
    new "[mo2]... این همچین نیست… می‌تونم توضیح بدم... او... عریانه... ولی او... شینیگامیه-"

    # say L81 mo2
    old "What?! What are you talking about? Were you watching porn again?"
    new "چه؟! چه چیزی رو می‌گی؟ دوباره پورنو تماشا می‌کردی؟"

    # say L83 pla
    old "What? Porn... No. I was just-"
    new "چه؟ پورن... نه. من فقط-"

    # say L85 mo2
    old "Hmm... probably were. You fucking pervert... I'll just have your [mo1rel] talk to you about this."
    new "ممکنه... احتمالاً همین بود. تو خودت گیج کننده... براش [mo1rel] بگو این موضوع رو."

    # say L87 mo2
    old "Finish whatever you were doing."
    new "بگرد از کاری که در می‌آمدی."

    # say L94 pla
    old "What the hell? Didn't she see you?"
    new "چه خبره؟ آنوقت تو رو ندیده بود؟"

    # say L104 bri
    old "Only you can see or hear me... And she called you [pla]? Is that your name?"
    new "فقط تو می‌تونی منو ببینی یا بشنوی... و اونجا تو رو [pla] فرخواند؟ این اسمت هست؟"

    # say L105 pla
    old "Yes, that's my name. And-um, why are you naked???"
    new "بله، اون هم نام منه. و-هم، چرا خالی‌پوستی؟؟؟"

    # say L107 bri
    old "Oh, I'm sorry! Hehe. I took human form to be more familiar to you, but I forgot that humans cover their bodies with 'clothing'."
    new "اوه، معذرت! ههه. من شکل انسانی گرفتم تا برای تو آشنا‌تر باشم، ولی فراموش کردم که انسان‌ها بدن خودشون رو با لباس می‌پوشن."

    # say L113 pla
    old "Couldn't find anything that covers you a little bit more, huh? But at least nobody can see you. Now tell me again, who are you exactly?"
    new "نمی‌تونستی چیزی پیدا کنی که بیشترت پوشونه، همین؟ ولی حداقل هیچ‌کس نمی‌تونه تو رو ببینه. حالا دوباره بگو، دقیقاً تو کی هستی؟"

    # say L115 bri
    old "I am Brixxida! A shinigami. I can shift and adapt to the form of any species, although my true form is this... "
    new "من بریکسیدا هستم! یک شینیگامی. می‌توانم به شکل هر گونه‌ای تغییر کنم، اما شکل واقعی من این است..."

    # say L120 bri
    old "...I am now much smaller, but I like being this size. Much more comfortable. Hehe"
    new "...من حالا خیلی کوچک‌تر هستم، اما این اندازه خیلی راحت‌تر است. هه هه"

    # say L128 pla
    old "Ok, ok. I get it now. I'm going crazy. This isn't real. It's a dream! Yeah, that's it! It's a dream..."
    new "بی، بی. حالا فهمیدم. دیوانه شدم. این واقعی نیست. رویم خوابه! بله، همینه! رویم خوابه..."

    # say L130 pla
    old "I fell asleep in class and soon I'm going to wake up... hmmm... I am going to wake up now.... hmmm."
    new "من در کلاس خوابیدم و زود به محض این بیدار می‌شوم... هم‌هم... الان بیدار می‌شوم.... هم‌هم."

    # say L134 pla
    old "I'm trying to wake up from this dream."
    new "من سعی می‌کنم از این خواب بیدار شوم."

    # say L136 bri
    old "You look wide awake to me, [pla]."
    new "تو به نظر می‌رسی کاملاً بیداری، [pla]."

    # say L138 pla
    old "That's right!  I'm too tired, so I should rest. And tomorrow I will be back to normal."
    new "درست هست! خسته‌ام، پس باید استراحت کنم. و فردا به حالت عادی بر می‌گردم."

    # say L140 pla
    old "Yes, yes. I'm going to sleep... "
    new "بله، بله. من می‌روم بخوابم..."

    # say L142 bri
    old "Ok! Goodnight. Hehe."
    new "باشه! خوب شب. ههه."

    # say L148 pla
    old "Hmm... what a weird ass dream. I gotta lay off playing so many weird visual novels..."
    new "Hmm... آره، یه رویای خیلی عجیب بود. باید از بازی‌های بصری عجیب کم کنم..."

    # say L153 bri
    old "What are visual novels?"
    new "وای، چیزی به نام رمان‌های تصویری وجود داره؟"

    # say L156 pla
    old "Oh shit!  You... and you're naked again!"
    new "اوه شیطان! تو... و دوباره خالی‌البدی!"

    # say L158 bri
    old "Oh, my mistake.  I'm sorry. You humans are very dramatic about this... "
    new "اوه، اشتباهم. معذرت. شما انسان‌ها در مورد این موضوع خیلی دراماتیک هستید..."

    # say L164 pla
    old "Ok, ok. Just explain to me, Brixxida, why did the book fall from the sky?"
    new "باشه، باشه. فقط به من توضیح بده، بریکسیدا، چرا کتاب از آسمون پرید؟"

    # say L166 bri
    old "The book chooses you! Now you are part of a tradition of sorcerers that can use the book's magical powers."
    new "کتاب شما رو انتخاب کرده! حالا شما بخشی از سنت جادوگران هستید که می‌توانند از توانایی‌های جادویی کتاب استفاده کنند."

    # say L168 pla
    old "Magic powers, you say?...  The hell-?"
    new "تو قدرت‌های جادویی می‌گی؟... خداحافظی؟"

    # say L172 mo1
    old "[pla]?  Are you awake?  Who were you talking to?"
    new "[pla]؟ بیداری؟ با کی صحبت می‌کردی؟"

    # say L181 pla
    old "Me? Oh, hmmm, nobody... I'm, uhh... preparing a speech for a class project..."
    new "من؟ اوه، هم، هیچ‌کس... من، اوه... برای پروژه‌ای در کلاس سخنرانی آماده می‌کنم..."

    # say L183 mo1
    old "Very good, [pla]!"
    new "بسیار خوب، [pla]!"

    # say L185 mo1
    old "Listen, I want to talk to you about yesterday... About the living room."
    new "بله، می‌خوام در مورد دیروز با تو صحبت کنم... در مورد اتاق نشیمن."

    # say L187 pla
    old "Oh, [mo1], I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "اوه، [mo1]، من درک می‌کنم. فکر می‌کنم این برای یک زوج کاملاً عادی است... و تو هم [mo1rel] منی هستی، نباید به من توضیحاتی بدهی."

    # say L189 mo1
    old "I'm glad to hear that. But... I do want to apologize. We were a bit careless getting... Intimate in the living room."
    new "خوشحالم که اینجوری فکر می‌کنی. اما... من واقعاً باید عذرخواهی کنم. ما یک کم احتیاط نکردیم وقتی... در اتاق نشیمن زیاد با هم آشتی کردیم."

    # say L191 pla
    old "Don't worry about it. I actually think it's good that you keep the flame alive in your relationship over all these years."
    new "نگران نباش. در واقع خوشحالم که شما همچنان آتش عشق خود را در این سال‌ها زنده نگه دارید."

    # say L193 mo1
    old "Do you really think that? Thank you so much for being so understanding, [pla]!"
    new "ممنونم از درکت، [pla]! آیا واقعاً اینطور فکر می‌کنی؟"

    # say L195 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey, if you need me I will be in kitchen."
    new "خب، دیگه ازت سر نمی‌برم. لطفاً خوب مطالعه کن، عزیزم، اگه نیازت به من بود، در آشپزخانه هستم."

    # say L204 pla
    old "Didn't you say they can't hear you?"
    new "آره، اما من فکر می‌کردم نمی‌تونن به تو گوش بدند؟"

    # say L206 bri
    old "Nope! But they can hear you! Hehe."
    new "نه! اما می‌تونن حرفت رو بشنون! ههه."

    # say L208 pla
    old "Oh... Ok, that makes sense... but explain everything to me again."
    new "اوه... خوب، این جوری معقوله... ولی همه چی رو دوباره برای من توضیح بده."

    # say L210 bri
    old "What do you want to know, [pla]?"
    new "چه چیزی می‌خوای بفهمی، [pla]؟"

    # menu L220 
    old "Who are you?"
    new "تو کی هستی؟"

    # say L222 bri
    old "Again, I'm Brixxida, a shinigami. I am the protector of the book you found. Hehe."
    new "دوباره، من بریکسیدا هستم، یک شینیگامی. من محافظ کتابی هستم که پیدا کردی. ههه."

    # say L224 pla
    old "Ok. Now, where did you come from?"
    new "خب. حالا از کجا آمده‌ای؟"

    # say L226 bri
    old "I come from another dimension. There, magic and power were natural, but that world has been destroyed."
    new "از بعدی ابعاد آمدم. در آنجا جادو و قدرت طبیعی بودند، اما آن دنیا نابود شده."

    # say L228 pla
    old "So... you are a time traveler?"
    new "پس... تو یک سفرزمانی هستی؟"

    # say L230 bri
    old "What? No, no... I have been asleep for hundreds of years with a spell. But when you opened and read the book, I woke up."
    new "نه، نه... من صد ها سال با یک جایزه خوابیدم. ولی وقتی تو کتاب رو باز و خوندی، من بیدار شدم."

    # say L232 pla
    old "Ok, I think I'm starting to understand."
    new "باشه، فکر کنم شروع می‌کنم درک کنم."

    # menu L239 
    old "What's this book about?"
    new "این کتاب درباره چیه؟"

    # say L241 bri
    old "Well... this book contains all the knowledge of that magical world..."
    new "خب... این کتاب همه دانش آن جهان جادویی رو داره..."

    # say L243 pla
    old "Eww. So, it's like a history book?"
    new "وای. پس مثل کتاب تاریخیه؟"

    # say L245 bri
    old "No, silly. This book contains specific spells and mantras that enable impressive magic powers beyond human understanding."
    new "نه، خوشحال‌نکن. این کتاب حاوی جملات و منترهای خاصیه که قدرت‌های جادویی شگفت‌انگیزی رو فراتر از درک انسان‌ها فراهم می‌کنه."

    # say L247 pla
    old "Ok, I get that part."
    new "باشه، این قسمت رو متوجه شدم."

    # menu L254 
    old "Magic, you say?"
    new "سحر، می‌گی؟"

    # say L256 bri
    old "Yes! The magic is a natural power that was lost, but you can get it and actually improve it..."
    new "بله! جادو قدرت طبیعی‌ای است که از دست رفت، اما می‌توانی آن را به دست آوری و حتی بهبود بخشی."

    # say L258 pla
    old "Yeah, yeah. But... what can I do with magic?"
    new "بله، بله. اما... با جادو چه کاری می‌تونم بکنم؟"

    # say L260 bri
    old "Actually, there are no limits with magic! It is the most powerful force in the known universe..."
    new "در واقع، با جادو هیچ محدودیتی وجود نداره! این قدرتی است که در کیهان شناخته شده قوی‌ترین است..."

    # say L262 pla
    old "Really? Interesting..."
    new "وای، جالب است..."

    # say L264 bri
    old "What else do you want to know, [pla]?"
    new "چه چیز دیگری می‌خوای بدونی، [pla]؟"

    # menu L269 
    old "What do I have to do?"
    new "من چه کاری باید بکنم؟"

    # say L271 bri
    old "Well... you have to learn different spells and mantras to achieve powerful skills but... you will find everything in the book."
    new "خب... باید جادوی‌ها و منترهای مختلف رو یاد بگیری تا مهارت‌های قدرتمند به دست بیاری اما... همه چیز توی کتاب هست."

    # say L273 pla
    old "Imperium mens et feminam. What is that? Russian or some shit?"
    new "ایمپریوم منس ات فمینام. این چیه؟ لاتین یا چیزی؟"

    # say L275 bri
    old "Actually, Latin is the language in which it was written... But don't worry, my job is to help the Chosen One translate..."
    new "در واقع، این زبان لاتین است... اما نگران نباش، وظیفه‌ام اینه که به جان‌باز این ترجمه‌ها رو کمک کنم."

    # say L277 pla
    old "Do I have to learn a lot of information about spells and mantras?"
    new "من باید اطلاعات زیادی درباره جملات سحر و منترها یاد بگیرم؟"

    # say L279 bri
    old "That's right! Hehe. And gaining a lot of power!"
    new "درسته! ههه. و دریافت قدرت زیادی!"

    # say L281 pla
    old "Ok, I hope this is all worth it."
    new "باشه، امیدوارم این همه کار ارزشش باشه."

    # say L283 bri
    old "Alright, [pla]. What else do you want to know?"
    new "باشه، [pla]. همچین چیز دیگه‌ای می‌خوای بدونی؟"

    # say L290 bri
    old "That's the spirit!  So, look at the beginning of the book for an easy spell..."
    new "این همون جویاییه! پس، به اول کتاب نگاه کن برای یه جادوی ساده..."

    # say L292 pla
    old "Let's see here..."
    new "بیاین ببینم..."

    # say L295 pla
    old "Damn, forgot. Everyone can hear me in this room. I gotta look for a better place to do this..."
    new "لعنتی، فراموش کردم. همه می‌تونن اینجا صدایم رو بشنون. باید جای بهتری برای این کار پیدا کنم..."

    # say L297 pla
    old "Hmm, probably the garage. Noone can hear me in there. Could you go there with me, Brixxida?"
    new "ممکنه به گاراژ بریم؟ هیچ‌کس ما رو نمی‌شنونه اونجا. بیکسیدا، می‌تونی با من بیایی؟"

    # say L299 bri
    old "I will follow you wherever you tell me."
    new "من هر جایی که می‌گی برم، می‌روم."

    # say L301 pla
    old "Perfect! Let's do this in the garage."
    new "عالی! بیایم به گاراژ."

    # say L316 bri
    old "So? Are you ready to start?"
    new "پس؟ آماده‌ای شروع کنیم؟"

    # say L318 pla
    old "I should talk with my [mo1rel] before we begin."
    new "باید با [mo1rel] صحبت کنم قبل از شروع."

    # say L331 pla
    old "Alright, I spoke to my [mo1rel] and explained to her that I will be in here preparing my project."
    new "باشه، با [mo1rel] حرف زدم و بهش توضیح دادم که من اینجا خواهم بود برای آماده‌سازی پروژه‌ام."

    # say L333 pla
    old "So, how does all this work, Brixxida?"
    new "پس، این همه چطور کار می‌کنه، بریکسیدا؟"

    # say L338 bri
    old "Well, first you must understand the magical power..."
    new "خب، اول باید قدرت جادویی رو درک کنی..."

    # say L340 pla
    old "Magical power?"
    new "قدرت جادویی؟"

    # say L342 bri
    old "Yes, you must have the magical power to be able to do any spell..."
    new "بله، باید قدرت جادویی رو داشته باشی تا بتونی هر جادویی انجام بدی..."

    # say L344 pla
    old "I understand, but then how do I generate that magical power?"
    new "من متوجه شدم، اما چطور می‌تونم اون قدرت جادویی رو ایجاد کنم؟"

    # say L346 bri
    old "Well, magical power is an energy that was produced naturally in the magical world..."
    new "خوب، انرژی جادویی یک انرژی است که به طور طبیعی در دنیای جادویی تولید می‌شود..."

    # say L352 pla
    old "Even you?"
    new "حتی تو؟"

    # say L354 bri
    old "Yes... We feed on magical energy, when in the real world all the remaining energy has been used up, I will disappear..."
    new "بله... ما از انرژی جادویی تغذیه می‌کنیم، وقتی در دنیای واقعی تمام انرژی باقی‌مانده استفاده شود، من ناپدید خواهم شد..."

    # say L356 pla
    old "Wow... And how do we prevent magic energy from running out?"
    new "وای… چطور می‌تونیم جلوگیری کنیم تا انرژی جادویی نبیافتد؟"

    # say L358 bri
    old "The magical energy will continue to run out until there be a new being so powerful that it can restore the magical world and return everything to its natural balance..."
    new "انرژی جادویی تا زمانی که موجودی قدرتمند به وجود نیاید و بتواند دنیای جادویی را بازسازی کند و همه چیز را به تعادل طبیعی برگرداند، خواهد کاهش یافت..."

    # say L360 pla
    old "That powerful being is supposed to be... me?..."
    new "این موجود قدرتمند منظور شما هست... من؟..."

    # say L362 bri
    old "Yes.. You are the chosen one."
    new "بله.. تو انتخاب شده‌ای."

    # say L364 pla
    old "Hmm, it's a lot of responsibility..."
    new "Hmm، مسئولیت زیادی هست..."

    # say L366 bri
    old "Don't worry. I know we will make it!"
    new "نگران نباش. میدونم ما این کار رو می‌تونیم انجام بدهیم."

    # say L368 pla
    old "Okay, but then how can I make spells if I don't have magic energy?"
    new "باشه، ولی بعد چطور می‌تونم جادو بکنم اگه انرژی جادویی ندارم؟"

    # say L369 bri
    old "Well, let me think... It's really not difficult, The magic energy is in the air."
    new "خب، بیای ببینم... واقعاً سخت نیست، انرژی جادویی در هوا وجود داره."

    # say L370 bri
    old "I can see it. What you need to do is acquire a certain skill that allows you to see it too..."
    new "من آن رو می‌بینم. تو باید یک مهارت خاص یاد بگیری که به تو اجازه می‌دهد همچین چیزی رو ببینی..."

    # say L373 bri
    old "Agamoto's eye! With it, you can see all the particles of magical power and collect them..."
    new "چشم‌آگاموتو! با این توانایی، می‌توانی همه ذرات انرژی جادویی را ببینی و جمع کنی..."

    # say L375 pla
    old "Whose eye?"
    new "چشم کی؟"

    # say L377 bri
    old "Agamoto's eye, is a special ability of vision. It will allow you to see many things of the magical world and expand your vision in a way never seen before by humans..."
    new "چشم‌آگاموتو، یک توانایی خاص برای دیدن است. این توانایی به تو می‌دهد که بسیاری از چیزهای جادویی را ببینی و دیدت را به شکلی که هیچ انسانی قبلاً ندیده، گسترش دهی..."

    # say L379 pla
    old "Great. How do I get that ability then?"
    new "عالی. پس چطور می‌تونم اون توان رو به دست بیارم؟"

    # say L381 bri
    old "Ohhh... Well, heh... You'll need magical power... Hahaha."
    new "اوه... خب، هه... باید توانایی جادویی رو داشته باشی... هahaha."

    # say L383 pla
    old "Really?... So how can I get magic power? If I need magic power to get magic power..."
    new "وای، پس چطور می‌تونم قدرت جادویی رو به دست بیارم؟ اگه برای داشتن قدرت جادویی باید قدرت جادویی داشته باشم..."

    # say L385 bri
    old "Well, I think the easiest way is that I share you magic power!"
    new "خب، فکر کنم راه ساده‌تر اینه که من قدرت جادویی خودمو با تو به اشتراک بذaram!"

    # say L387 pla
    old "You share magic power with me?"
    new "تو قدرت جادویی رو با من به اشتراک می‌گذاری؟"

    # say L389 bri
    old "Yes! As I explained to you, all magical beings are constituted of magical power."
    new "بله! همانطور که به تو توضیح دادم، تمام موجودات جادویی از انرژی جادویی تشکیل شده‌اند."

    # say L390 bri
    old "In fact, we are like little magnets that we are gathering magical power constantly to live."
    new "در واقع، ما مثل مغناطیس‌های کوچکی هستیم که به طور مداوم انرژی جادویی را جمع می‌کنیم تا زنده بمانیم."

    # say L392 bri
    old "In the magical world it was totally normal to share our magical energy with others because there were lots..."
    new "در جهان سحر، کاملاً طبیعی بود که انرژی سحرمان را با دیگران به اشتراک بگذاریم، زیرا این انرژی خیلی زیاد بود..."

    # say L394 bri
    old "The problem is that in this world there is less and less, so if I share more than necessary, it could disappear forever."
    new "مشکل اینجاست که در این دنیا هر چه می‌گذرد کمتر و کمتر می‌شه، پس اگه بیش از حد به تو بدم، ممکنه برای همیشه از بین برود."

    # say L396 pla
    old "Wow, it looks dangerous... So what will we do?"
    new "واو، به نظر خطرناک می‌تونه بیاد... پس چه کاری می‌کنیم؟"

    # say L398 bri
    old "Bah, I'm going to share enough, and then you can return me some magical power so that nothing happens to me."
    new "با، من به اندازه کافی به اشتراک خواهم گذاشت، و بعد تو می‌تونی به من قدرت جادویی برگردانی تا هیچ چیز به من نبیفتد."

    # say L400 pla
    old "Okay, how do you share me then?"
    new "باشه، چطور می‌تونی به من بدی؟"

    # say L402 bri
    old "Hmm, let's see. Take off your pants and lie on the floor..."
    new "هم، ببین. پانتالونتو ببرد و روی زمین دراز کش..."

    # say L404 pla
    old "What... Why do I have to take off my pants?"
    new "چه... چرا باید پانتالونمو برم؟"

    # say L407 bri
    old "Oh, of course... You humans treat nudity as a taboo. Even though it's something natural..."
    new "البته... شما انسان‌ها عریانی رو ممنوع می‌دانید. حتی اگر این چیزی طبیعی باشه..."

    # say L408 bri
    old "Besides what we're going to do... How do you call it?... Uhh, sex!"
    new "البته، اما ما همچنین قراره... چطور می‌گیه؟... آه، جنس!"

    # say L410 pla
    old "What the fuck!? Are we going to have sex?"
    new "چه خبر!؟ قراره جنس کنیم؟"

    # say L412 bri
    old "Yes, it's super fun... I understand that you see it in a different way. But for us, this is simply a form of common energy exchange..."
    new "بله، این خیلی لذت‌بخش است... من می‌فهمم که تو از نگاه دیگری به این نگاه می‌کنی. اما برای ما، این فقط یک شکل از تبادل انرژی است..."

    # say L414 pla
    old "Are you saying that this is how you are going to share magical power?"
    new "می‌گیه اینجوری قدرت جادویی رو به من می‌دهی؟"

    # say L416 bri
    old "Exactly, the magic power resides in an inner gland, and the only way to transfer it is to excite it..."
    new "دقیقاً، قدرت جادویی در غده‌ای داخلی نشسته است و تنها راه انتقال آن این است که آن را تحریک کنیم..."

    # say L418 bri
    old "In my case, you must be inside me and you will receive my magic power!"
    new "در مورد من، تو باید داخل من باشی و اینجوری قدرت جادویی من رو دریافت می‌کنی!"

    # say L420 pla
    old "... And there is no other way. I'm not sure if it's a good idea..."
    new "و راه دیگری هم نیست. نمی‌دونم خوبه یا نه..."

    # say L422 bri
    old "Oh come on! You humans are very complicated, but you have to see it as a magical being..."
    new "اوه بیای! شما انسان‌ها خیلی پیچیده هستید، اما باید این رو به عنوان یک موجود جادویی ببینی..."

    # say L424 bri
    old "Think of sex as a way to feed yourself with magical energy... Is very natural."
    new "جنس رو به عنوان راهی برای تغذیه با انرژی جادویی ببین... خیلی طبیعیه."

    # say L426 pla
    old "Alright, let's do it then..."
    new "باشه، بیایم درست شه..."

    # say L429 bri
    old "Excellent! Take off your pants and get on the floor!"
    new "عالی! لباس پایینتو ببر و روی زمین بنشین!"

    # say L434 bri
    old "Wow, this is very good! I haven't done it for a long time..."
    new "واو، این خیلی خوبه! از طول وقت این کار رو نکرده بودم..."

    # say L442 pla
    old "Do you have some magic power to share with me?"
    new "آیا قدرت سحری داری که با من به اشتراک بگذاری؟"

    # say L444 bri
    old "Do you need more from me?"
    new "آیا از من بیشتری می‌خوای؟"

    # say L446 pla
    old "Well, only if you have some to share..."
    new "البته، فقط اگر تو هم قدرتی برای به اشتراک گذاشتن داشتی..."

    # say L448 bri
    old "Ok, but just because is really fun... hahaha"
    new "باشه، ولی فقط چون واقعاً لذت‌بخشه... هاهاها"

    # say L452 bri
    old "Take off your pants and lie on the floor..."
    new "پانتالونتو بردار و روی زمین بخواب..."

    # say L478 pla
    old "Wow, I've never slept that well."
    new "واو، هیچ وقت همین‌طور خوب نخوابیده‌ام."

    # say L480 bri
    old "I see that your body was able to completely assimilate magic. How do you feel?"
    new "می‌بینم که بدن تو توانست به طور کامل جادو رو جذب کنه. احساساتت چطوره؟"

    # say L482 pla
    old "I don't feel any different..."
    new "من هیچ تفاوتی حس نمی‌کنم..."

    # say L484 bri
    old "Well, the best thing to do is to use the magic energy that I gave you to acquire Agamoto's Eye before it runs out..."
    new "خوب، بهترین کار اینه که انرژی جادویی که به تو دادم رو برای گرفتن چشم آگاموتو استفاده کنی قبل از اینکه تمام شه..."

    # say L486 pla
    old "Does that mean that if I don't use the magic power it will run out?"
    new "این بمعنی اینه که اگر قدرت جادویی رو استفاده نکنم، خواهد تمام شد؟"

    # say L488 bri
    old "Yes, indeed. Every day you will have less magical power, which is why it is urgent that you acquire the skill."
    new "بله، همین‌طور. هر روز توانایی جادویی تو کمتر می‌شه، برای همین مهمه که زود این مهارت رو به دست بیاری."

    # say L490 pla
    old "Perfect, let's go to the garage to do it then..."
    new "عالی، برویم به گاراژ که انجام بدیم..."

    # say L496 pla
    old "So, what should I do?"
    new "پس، من چه کاری باید بکنم؟"

    # say L497 bri
    old "Well, actually, yesterday we couldn't finish our magic transfer..."
    new "خب، در واقع، دیروز ما نتونستیم انتقال جادو رو تمام کنیم..."

    # say L498 bri
    old "So, we should do it again, in order to you get completly charged with magic power."
    new "پس باید دوباره انجام بدیم تا تو کاملاً با قدرت جادویی شارژ بشی."

    # say L499 pla
    old "Hmm alright, but I'm not going to lay on the floor like last time, I don't want someone else to see me in that weird position..."
    new "Hmm خب، ولی من نمی‌خوام مثل بار اول روی زمین دراز کنم، نمی‌خوام دیگه کسی مرا توی همین وضع عجیب ببینه..."

    # say L500 bri
    old "All right!"
    new "باشه!"

    # say L513 pla
    old "All right. Now what should I do?"
    new "باشه. حالا من چی کنم؟"

    # say L515 bri
    old "First open your SexNote"
    new "اول SexNoteت رو باز کن"

    # say L525 bri
    old "Now check the first spell named 'Agamoto's eye' and activate it."
    new "حالا حکم اول را بررسی کن، آن حکمی که به نام «چشم آگاموتو» شناخته می‌شود، و آن را فعال کن."

    # say L526 pla
    old "Understood..."
    new "فهمیدم..."

    # say L539 pla
    old "I think it's done... But I don't feel anything different..."
    new "فکر کنم انجام شده... ولی هیچ تغییری حس نمی‌کنم..."

    # say L541 bri
    old "You must activate it, click on ability and look at the magic dimension!"
    new "باید اون رو فعال کنی، روی توانی کلیک کن و به بعد جادویی نگاه کن!"

    # say L568 pla
    old "Wow... It looks so... Magical?..."
    new "واو... به نظر می‌رسه خیلی... جادویی؟..."

    # say L569 bri
    old "Do you see those little colored spheres? That is magic power, it has become particles, you just have to pick it all up..."
    new "آیا آن حلقه‌های رنگی رو می‌بینی؟ این قدرت جادوییه، به ذرات تبدیل شده، فقط باید همه‌شون رو جمع کنی..."

    # say L570 bri
    old "And when you do it, just click the Agamoto's Eye to desactivate it and see the real world."
    new "و وقتی این کار رو انجام میدی، فقط چشم آگامتو رو کلیک کن تا آن را غیرفعال کنی و جهان واقعی رو ببینی."

    # say L579 pla
    old "Wow, it's easier than I expected..."
    new "واو، این ساده‌تر از آنچه فکر می‌کردم است..."

    # say L581 bri
    old "Of course, what did you expect? Having to memorize and recite strange meaningless words or make puzzles that never fit in  corners?"
    new "البته، چه کاری انتظار داشتی؟ آیا فکر می‌کردی باید کلمات عجیب و بی‌معنی رو حفظ و تکرار کنی یا پازل‌هایی که هیچ وقت در کنار هم جا نمی‌گیرند حل کنی؟"

    # say L583 pla
    old "What?..."
    new "چه؟"

    # say L585 bri
    old "Nevermind... It's simple, you just have to look for the spheres of magic power and that's it..."
    new "بی‌خیال... ساده است، فقط باید به دنبال کرهای توان جادویی بگردی و این همه..."

    # say L587 bri
    old "In fact... There is a spell you can use called Ayax's Hand"
    new "در واقع... یه جادویی هست که می‌تونی بکار ببری، اسمش دست ایاکس"

    # say L589 bri
    old "With this one your body will automatically begin to collect magic power everywhere you move, it's sorta like a magnet.."
    new "با این جادویی، بدن تو خود به خود شروع می‌کنه به جمع‌آوری توان جادویی هر جا که حرکت می‌کنی، مثل یه مغناطیس."

    # say L591 pla
    old "Yes, you're right, there are several more spells I saw in the SexNote, how can I activate them?"
    new "بله، درست می‌گی، چند تا جادوی دیگه هم توی SexNote دیدم، چطور می‌تونم اونا رو فعال کنم؟"

    # say L593 bri
    old "Very easy you only spend the magic power you have in them and so you can activate those spells, each one has three different levels of power."
    new "بسیار آسان، فقط باید قدرت جادویی خود را در آن‌ها صرف کنی و اینطور می‌توانی این تکنیک‌ها را فعال کنی، هر کدام سه سطح مختلف قدرت دارند."

    # say L595 bri
    old "For example, the higher the level of power you have with Agamoto's eye, the more spheres you will see and so you can collect more magical power!"
    new "مثلاً، هر چه سطح قدرت تو با چشم آگاموتو بالاتر باشه، تعداد کرهایی که می‌بینی بیشتر می‌شه و اینجوری می‌تونی قدرت جادویی بیشتری جمع کنی!"

    # say L597 pla
    old "Ohhh understood, and when I have collected all the magical power from a place?"
    new "اوه فهمیدم، و وقتی تمام توان جادویی رو از یک جایی جمع کردم؟"

    # say L599 bri
    old "Check this out, power spheres group everyday so keep an eye out and collect more magical power!"
    new "بیا ببین، کرهای توان هر روز جمع می‌شنن، پس چشمتو باز داشت و بیشتر توان جادویی جمع کن!"

    # say L602 bri
    old "Something important is that your body cannot store much magical power..."
    new "چیز مهمی اینه که بدن تو نمی‌تونه خیلی توان جادویی رو ذخیره کنه..."

    # say L603 bri
    old "For that you must use a spell, and thus increase the amount of power that you can store within yourself."
    new "برای این باید از جادو استفاده کنی و به همین ترتیب مقدار قدرتی که می‌توانی در خودت ذخیره کنی افزایش یابد."

    # say L605 pla
    old "Excellent, so I'm going to devote myself to collecting some magical power in the meantime..."
    new "عالی، پس من در این میان به جمع‌آوری برخی از قدرت سحر خواهم پرداخت..."

    # say L607 bri
    old "Perfect, now that you can do it... You could give me a little, remember that I need it to exist."
    new "عالی، حالا که می‌تونی این کار رو انجام بدی... می‌تونی یه کمی به من بدی، به خاطر داشتی که من برای وجود داشتن بهش نیاز دارم."

    # say L609 pla
    old "Ohh yes, I'm sorry, let me pick up some more magical power and I will give you later..."
    new "اوه بله، معذرت، بیایم یه کم جادوگری بیشتر جمع کنم و بعد به تو بدم..."

    # say L611 bri
    old "Oh, by the way! Keep in mind that using your Agamotto Eye spends some magical power and time."
    new "اوه، بقیه هم به یاد داشته باش! استفاده از چشم آگاموتو مقداری توان جادویی و وقت رو می‌بره."

    # say L615 bri
    old "Well, all magical skills, requires some magical power to be used..."
    new "خب، همه مهارت‌های جادویی، برای استفاده از آن‌ها نیاز به توان جادویی دارند..."

    # say L618 bri
    old "And when you are in the magic dimension time passes a little faster too."
    new "و وقتی تو در بعد سحر هستی، زمان یک کم سریع‌تر می‌گذره."

    # say L620 bri
    old "If you use only a couple of times, you will not see much difference but if you use them alot you will end the day very quickly."
    new "اگر فقط چند بار استفاده کنی، تفاوت زیادی نمی‌بینی اما اگر خیلی ازش استفاده کنی، روزت سریع تمام می‌شه."

    # say L622 pla
    old "Ohh ok, understood..."
    new "اوه خب، فهمیدم..."

    # say L624 bri
    old "It is indeed a good way to kill time if you have nothing to do at some point."
    new "البته، اگر هیچ کاری نداشته باشی، این روش خوبی برای گذراندن وقت است."

    # say L626 pla
    old "I guess you are right..."
    new "بی‌خیالی درستی داری..."

    # say L628 bri
    old "Ok, I'll be here if you need me."
    new "باشه، اگه نیازت به من بود، من اینجا هستم."

    # say L701 pla
    old "Hey Brixxida... I think I was visited by another shinigami, like you, yesterday."
    new "بrixxیدا... فکر کنم دیروز یه شینیگامی دیگه مثل تو به من دیدار کرد."

    # say L705 pla
    old "You are the only shinigami alive in the human world?"
    new "تو تنها شینیگامی زنده در جهان انسانی هستی؟"

    # say L707 bri
    old "I'm not sure, there are likely to be more, the magical world was very big..."
    new "مطمئن نیستم، احتمالاً دیگران هم هستند، جهان جادویی خیلی بزرگ بود..."

    # say L709 pla
    old "Well, one of them visited me last night and she was sucking my... She was stealing my magic power..."
    new "خب، یکی از آنها دیروز شب به من آمد و... قدرت جادویی من رو می‌برد..."

    # say L711 bri
    old "Wow... Really?"
    new "واو... واقعاً؟"

    # say L713 pla
    old "Who is she and why did she steal my magic power?"
    new "من نمی‌دونم اون کیه و چرا قدرت جادویی من رو گرفت؟"

    # say L715 bri
    old "I don't know, it's not like I knew all the magical beings..."
    new "نمی‌دونم، مثل اینکه من همه موجودات جادویی رو نمی‌شناسم..."

    # say L717 pla
    old "So what can we do?"
    new "پس الان چه کاری می‌تونیم بکنیم؟"

    # say L719 bri
    old "I don't think it will happen again, it's best we wait. If she steals from you again we'll have to defend ourselves..."
    new "فکر نمی‌کنم دوباره اتفاق بیفتد، بهتره منتظر بمانیم. اگه دوباره از تو سرقت کنه باید دفاع کنیم..."

    # say L721 pla
    old "What do you mean defend ourselves?"
    new "من قصد دفاع از خودمون رو چطور می‌تونم بفهمم؟"

    # say L723 bri
    old "Well, we would have to hunt her and take away her magical power instead..."
    new "خب، باید او را تعقیب کنیم و قدرت جادویی‌اش را از دستش بگیریم..."

    # say L725 pla
    old "All her magical power? That would make her disappear... wouldn't it?"
    new "همه قدرت جادویی‌اش؟ این به معنای اینه که او ناپدید می‌شه... نیست؟"

    # say L727 bri
    old "Well if she attack you again, we can't sit by while she keeps stealing our magical power! We must stop her somehow..."
    new "خب اگر او دوباره به تو حمله کند، نمی‌توانیم به آرامی بیشتر از قدرت جادویی ما بگیرد! باید به چه طوری او را متوقف کنیم..."

    # say L729 pla
    old "Hmmm... Ok, just let's wait and hopefully she won't  show up again."
    new "Hmm... خب، فقط بیایم بیشتر صبر کنیم و امیدوار باشیم دیگه نیومد."

    # say L731 bri
    old "Right... Don't worry, thought. Just keep improving with your skills..."
    new "درست... نگران نباش، فقط با مهارت‌هایت بهتر شو..."

    # say L745 pla
    old "Brixxida, last night another shinigami visited me!"
    new "بریکسیدا، فرداش یه شینیگامی دیگه به من آمد!"

    # say L747 bri
    old "Another? And did she steal more magic power from you?"
    new "دیگری؟ و آیا او از تو قدرت جادویی بیشتری گرفت؟"

    # say L749 pla
    old "Well... yes."
    new "خب... بله."

    # say L751 bri
    old "Damn! That can't keep happening! We must recover my magical power... I mean, our magical power..."
    new "لعنتی! این نمی‌تونه همیشه اینجوری باشه! باید قدرت جادویی من رو... منظورم قدرت جادویی ما رو بازپس‌گیری کنیم..."

    # say L753 pla
    old "And how do we do it?"
    new "و چطور این کار رو انجام بدیم؟"

    # say L755 bri
    old "We must go on the hunt... We will attack them so they don't bother us again..."
    new "باید شکار برداریم... ما بهشون حمله خواهیم کرد تا دیگه به ما اذیت نکنن..."

    # say L757 pla
    old "No, no, this time I was able to talk with her a little more..."
    new "نه، نه، این بار بتونستم باهاش کمی بیشتر صحبت کنم..."

    # say L758 pla
    old "In fact she didn't steal much magic from me... and I would like to understand the situation better..."
    new "در واقع زیاد جادویی از من نگرفت... و من می‌خواهم وضعیت رو بهتر بفهمم..."

    # say L760 bri
    old "They have stolen magical power. If it continues, we will be wasting valuable time that we must use to collect more magical power..."
    new "آنها قدرت جادویی رو از دست ما گرفته‌اند. اگر اینجوری ادامه پیدا کنه، وقت باهای ما رو که باید برای جمع‌آوری قدرت جادویی بیشتر استفاده کنیم، ضایع خواهد شد..."

    # say L762 pla
    old "Let me try one more time. When they return I will try to find out more and see if we can calm them down..."
    new "بگذار بار دیگه امتحان کنم. وقتی بر می‌گردند، می‌تونم بیشتر اطلاعات جمع کنم و ببینم می‌تونیم اونا رو آرامش بدیم یا نه..."

    # say L764 bri
    old "Hmm, if they steal your magic power again, we will have to defend ourselves, okay?"
    new "اگه دوباره سحرتو می‌روشن، باید دفاع کنیم، خب؟"

    # say L766 pla
    old "Okay. I will try to use Sauron's Mouth to find out more next time..."
    new "باشه. دفعه بعد سعی می‌کنم با استفاده از دهان سائورون بیشتر اطلاعات جمع کنم..."

    # say L768 bri
    old "Well, make sure you have the skill at the highest level to get as much information as possible."
    new "حتماً مهارت رو به بالاترین سطح برسون تا اطلاعات بیشتری بدست بیاری."

    # say L770 pla
    old "For sure..."
    new "حتماً..."

    # say L782 pla
    old "Well, things will be fine ..."
    new "خب، همه چیز خوب خواهد بود..."

    # say L784 bri
    old "You put a stop to the night robberies?"
    new "تو سرقت‌های شب رو متوقف کردی؟"

    # say L786 pla
    old "Well, Not really..."
    new "خب، نه واقعاً..."

    # say L788 bri
    old "Then we will have to fight back now..."
    new "پس حالا باید مقاومت کنیم..."

    # say L790 pla
    old "No, wait! The problem is that I have taken magical energy that they need to live..."
    new "نه، صبر کن! مشکل اینجاست که من انرژی جادویی رو گرفتم که برای زندگی‌شون لازم هست..."

    # say L792 bri
    old "You have taken magical energy that is scattered throughout the world. You have never attacked any of them..."
    new "تو انرژی جادویی رو که در سراسر دنیا پخش شده گرفتی. هیچ وقت به هیچ کدام از آنها حمله نکردی..."

    # say L794 pla
    old "But... I can generate magical power in other ways..."
    new "ولی... می‌تونم به روش‌های دیگه توانایی جادویی رو ایجاد کنم..."

    # say L796 bri
    old "You still don't have enough sexual activity with other women, to guarantee a constant production of magical energy."
    new "تو هنوز فعالیت جنسی کافی با زنان دیگر نداری، برای تضمین تولید مداوم انرژی جادویی."

    # say L798 pla
    old "I can do it and not affect them..."
    new "من می‌تونم این کار رو بکنم و آن‌ها رو آسون نکنم..."

    # say L800 bri
    old "You must think about the main goal and it is to be able to rebuild the magical world."
    new "باید به هدف اصلی فکر کنی و آن هم ساختن دوباره جهان جادویی است."

    # say L802 bri
    old "There are many magical beings that will disappear..."
    new "بسیاری از موجودات جادویی از بین خواهند رفت..."

    # say L803 bri
    old "And we can do nothing but work harder to rebuild everything as quickly as possible..."
    new "و ما هیچ کاری جز تلاش بیشتر برای سریع‌تر بازسازی همه چیز نمی‌توانیم انجام بدیم..."

    # say L805 pla
    old "Hmm... I guess you're right, but we don't have to attack them."
    new "Hmm... به نظر می‌رسه درست می‌گی، اما ما نمی‌تونیم بهشون حمله کنیم."

    # say L806 pla
    old "I will try to produce our own energy and little by little we can move forward with the spells..."
    new "من سعی می‌کنم انرژی خودمون رو تولید کنم و کم کم با جادویی‌ها پیش بریم..."

    # say L808 bri
    old "They will continue stealing your magical power if we do nothing."
    new "اگر هیچ کاری نکنیم، آنها ادامه خواهند داد تا توان جادویی تو را ربوده باشند."

    # say L809 bri
    old "We don't have to take away all the magical power, just enough to scare them and they won't look for you again..."
    new "ما نمی‌تونیم تمام توان جادویی رو ببریم، فقط کافیه که به اندازه‌ای باشه تا اونا وحشت بگیرن و دیگه بهت جویا نشن..."

    # say L811 pla
    old "Hmm that's fine... How do we do it?"
    new "Hmm خوبه... چطور این کار رو انجام می‌دیم؟"

    # say L813 bri
    old "I'll take care of tracking them and you'll do the attacking..."
    new "من مسئول پیگیری اونا خواهم بود و تو حمله کنی..."

    # say L815 pla
    old "Attack them?"
    new "آنها رو حمله کنم؟"

    # say L817 bri
    old "Yes, you will have to fuck them..."
    new "بله، باید با آنها جنس کنی..."

    # say L819 pla
    old "Hmmm... Ok."
    new "Hmm... خب."

    # say L821 bri
    old "Ok, give me a second. I'm going to use a special spell to detect nearby magical beings..."
    new "باشه، یه لحظه بده. من می‌خوام جادوی خاصی بکار ببرم تا موجودات جادویی نزدیک رو بشناسم..."

    # say L829 bri
    old "Done... I already identified where one of them are! She is in your classroom at school! Go there and fuck her..."
    new "بفرmars... قدمی روی یافتم! یکی از آنها در کلاس‌ت در مدرسه هست! برو اونجا و باهاش جنس کن..."

    # say L831 pla
    old "But... What if other people are there?"
    new "ولی... اگه مردم دیگه هم اونجا باشند؟"

    # say L833 bri
    old "Don't worry! When you are in the magical dimension with Agamoto's Eye nobody can see you..."
    new "نگران نباش! وقتی تو در بعد سحرآمیز با چشم اگاماتو هستی، هیچ‌کس نمی‌تونه تو رو ببینن..."

    # say L835 pla
    old "Ok, I'm going there then..."
    new "باشه، من می‌رم آنجا..."

    # say L837 bri
    old "Good luck! See you later..."
    new "بختر! بعداً می‌بینیم..."

    # say L843 pla
    old "(Well, she is supposed to be here...)"
    new "خب، باید اینجا باشه..."

    # say L845 pla
    old "(Let's use the Agamoto's Eye.)"
    new "بیایم از چشم آگاموتو استفاده کنیم."

    # say L852 mil
    old "What the fuck are you doing here?"
    new "اوه، تو اینجا چه کاری داری؟"

    # say L860 bri
    old "So, how did it go? Did you get magic power back?"
    new "پس، چطور شد؟ مجدداً قدرت جادویی‌ات برگشته؟"

    # say L862 pla
    old "Yes, I already recovered my magic power..."
    new "بله، قدرت جادویی‌ام رو قبلاً بازیابی کردم..."

    # say L864 bri
    old "Great... I don't think they will bother again after that..."
    new "عالی... فکر نمی‌کنم دیگه به ما اغتشاش بدهند..."

    # say L866 pla
    old "Hmm I don't know... We shall see."
    new "Hmm نمی‌دونم... ببینیم چه می‌شه."

    # say L878 pla
    old "Again, problems with these shinigamis, I think they've gone crazy..."
    new "once again، مشکلات با این شینیگامی‌ها، فکر کنم دیوانه شده‌اند..."

    # say L880 bri
    old "AGAIN? Okay let's finish them..."
    new "دوباره؟ خب بیاین اونا رو تمام کنیم..."

    # say L882 pla
    old "No, no... It's very strange. The one who I talked to yesterday was very kind and friendly after having accused me of destroying the magical world..."
    new "نه، نه... خیلی عجیب است. آن کسی که دیروز باهاش صحبت کردم خیلی مهربان و دوست‌داشتن بود بعد از اینکه من رو متهم کرده بود به تخریب جهان جادویی..."

    # say L884 bri
    old "What?... Ehh... They are totally crazy... It's best to make them disappear. We don't want to deal with them later..."
    new "چه کاری؟... اوه... هیچ شک ندارم که دیوانه‌اند... بهتر است اونا رو از بین ببریم. ما بعداً نمی‌خواهیم با آنها سر در بیاوریم..."

    # say L886 pla
    old "We'll let's try this... I will try to find the next shinigami and I will see what's happening..."
    new "بیاین بیایم اینو امتحان کنیم... من سعی می‌کنم شینیگامی بعدی رو پیدا کنم و ببینم چه خبری هست..."

    # say L888 bri
    old "But you should kill them! We've had enough..."
    new "ولی باید اونا رو بکشی! خیلی هم خسته شدیم..."

    # say L890 pla
    old "No, no. Let me handle this. I have an idea..."
    new "نه، نه. بگذار من اینو انجام بدم. یه ایده‌ام هست..."

    # say L892 bri
    old "Hmmm ok. I'm gonna use the spell again and I'll tell you where to find the next shinigami..."
    new "Hmmم خب. من دوباره از جادو استفاده می‌کنم و بهت می‌گم کجایی شینیگامی بعدی..."

    # say L900 bri
    old "Well, she is in fact in your friend Hinn's living room."
    new "خب، در واقع توی اتاق نشیمن هین هست."

    # say L902 pla
    old "Hmmm, alright... No problem."
    new "Hmm، خوب... مشکلی نداره."

    # say L904 bri
    old "But you should consider killing them. It can't waste more time..."
    new "اما باید در نظر بگیری که آنها را بکشی. نباید زمان بیشتری را از دست بدهی..."

    # say L906 pla
    old "I know what to do..."
    new "می‌دونم باید چی کنم..."

    # say L908 bri
    old "Hmm, Ok."
    new "Hmm، اوکی."

    # say L914 pla
    old "(Great, no one is in the livingroom...)"
    new "عالی، هیچ‌کس در اتاق نیست..."

    # say L919 pla
    old "Excellent! Just what I wanted..."
    new "عالی! همین بود که می‌خواستم..."

    # say L930 mil
    old "What? What are you doing?"
    new "چه کاری می‌کنی؟"

    # say L939 pla
    old "I have some questions to ask you..."
    new "من چند سوال برای تو دارم..."

    # say L941 bri
    old "Sure! Do you want to know more about spells?"
    new "بله! می‌خوای بیشتر در مورد جادو بدانی؟"

    # say L943 pla
    old "No, in fact, I want you to tell me who destroyed the magical world..."
    new "نه، در واقع می‌خوام بگی چه کسی جهان جادویی رو نابود کرده..."

    # say L946 bri
    old "Of course, the magical world was a wonderful place. Everyone lived in harmony..."
    new "البته، جهان جادویی مکانی شگفت‌انگیز بود. همه در هماهنگی زندگی می‌کردند..."

    # say L948 bri
    old "But a dark being, for unknown reasons, destroyed everything with a spell. When started to act it was too late because the being had too much power..."
    new "اما یک موجود تاریک، به دلایل ناشناخته، همه چیز را با یک جادویی نابود کرد. وقتی شروع کرد عمل کردن، خیلی دیر بود زیرا آن موجود قدرت زیادی داشت..."

    # say L950 pla
    old "And why did the shinigami tell me the person who destroyed the magical world was the SexNote owner?"
    new "و چرا شینیگامی به من گفت که نابودکننده جهان جادویی صاحب SexNote بود؟"

    # say L952 bri
    old "I don't know... It could have been the former owner of the SexNote or it could have been another SexNote..."
    new "نمیدونم... ممکنه صاحب قبلی SexNote بوده باشه یا ممکنه SexNote دیگه‌ای باشه..."

    # say L954 pla
    old "Is there more than one SexNote?"
    new "آیا سکس‌نوتهای بیشتری وجود داره؟"

    # say L957 bri
    old "It is not known for sure. Nobody knows. In fact, many ignore the real existence of a SexNote. It is something very secret because of the power it has..."
    new "مطمئن نیستم. هیچ‌کس نمی‌دونه. در واقع، بسیاری از مردم وجود واقعی SexNote رو نادیده می‌گیرن. این چیزی خیلی مخفیه چون قدرت زیادی داره..."

    # say L959 bri
    old "That's why you're the Chosen One to use it to repair all the damage..."
    new "این به همین خاطر تو انتخاب شدی تا با استفاده از این ابزار تمام آسیب‌ها رو تعمیر کنی..."

    # say L961 pla
    old "I understand... Still, you don't know anything about the previous owner of the SexNote or who destroyed the magical world?"
    new "فهمیدم... همچنان هیچ اطلاعی در مورد صاحب قبلی SexNote یا اونایی که جهان سحر رو نابود کردن نداری؟"

    # say L963 bri
    old "Correct, My mission was entrusted after the destruction of the magical world, to find a way to preserve the remaining magic of the universe..."
    new "درست است، مأموریت من بعد از تخریب جهان سحر، برای یافتن راهی برای حفظ سحر باقی‌مانده در کیهان بود..."

    # say L965 pla
    old "Got cha. Then everything is a silly misunderstanding... Help me look again for the shinigami to talk to them..."
    new "درست می‌فرمایی. پس همه چیز یه سوء تفاهم خنده‌داره... به من کمک کن دوباره به دنبال شینیگامی‌ها بریم تا باهاشون صحبت کنم..."

    # say L967 bri
    old "I don't think that is for the best. After what happened, it could be dangerous. It is best to leave it be as I doubt they'll look for you again..."
    new "فکر نمی‌کنم این بهتر باشه. بعد از همه چی که اتفاق افتاده، ممکنه خطرناک باشه. بهتره هیچی نکنیم، زیرا شک دارم که دوباره بهت جستجو کنن..."

    # say L969 pla
    old "But you heard them, they are running out of magic power..."
    new "اما شنیدی، قدرت جادوییشون کم شده..."

    # say L971 bri
    old "The magic power is scattered throughout the world, they just have to go to other places to collect. It is not as serious as they want you to think..."
    new "توپری از جهان پخش شده، فقط باید به جاهای دیگه برای جمع‌آوری بروند. اینقدر جدی نیست مثل آنچه می‌خواهند تفکرت باشه..."

    # say L973 pla
    old "Hmmm... Ok... I guess you're right"
    new "Hmm... خب... به نظر می‌رسه درست می‌گی‌ای"

    # say L975 pla
    old "Well, I'm going to keep improving my skills and collecting magical power."
    new "خب، من قصد دارم مهارت‌هام رو بهبود ببخشم و توانایی جادویی رو جمع کنم."

    # say L977 bri
    old "Great! See you later."
    new "عالی! بعداً ببینم."

    # say L983 pla
    old "(I still think there is something up with Brixxida. I should try to talk with those shinigamis again)"
    new "هنوز فکر می‌کنم مشکلی با بریکسیدا هست. باید دوباره با آن شینیگامی‌ها صحبت کنم."

    # say L985 pla
    old "(But, I can't ask Brixxida to look for them...)"
    new "(ولی نمی‌تونم از بریکسیدا بپرسم که برای من جستجو کنه...)"

    # say L987 pla
    old "(I will have to look for them by myself)"
    new "باید خودم به دنبالشون برسم"

    # say L989 pla
    old "Ok, I should look around to find them..."
    new "باشه، باید به دنبالشون برسم..."

    # menu L996 
    old "Talk with her"
    new "باهاش حرف بزن"

    # say L1010 pla
    old "Well, I already collected enough magic power, I think I can share some with you..."
    new "خب، من قدرت جادویی کافی رو جمع کردم، فکر کنم می‌تونم برای تو هم بریزم..."

    # say L1013 bri
    old "Yummy. I love to share the magic power. It's very fun!"
    new "لذت‌بخش. من عاشق اشتراک قدرت جادویی هستم. خیلی خوشحالم!"

    # menu L1022 
    old "Repeat"
    new "تکرار می‌کنم"

    # say L1033 pla
    old "Wait... What are you doing..."
    new "بی‌صبرانه منتظرم... چه کاری داری..."

    # say L1034 bri
    old "Duh. Receiving your magical power, this is how it is done..."
    new "دی. قدرت جادویی تو را دریافت می‌کنم، همین‌طور باید انجام شه..."

    # say L1035 pla
    old "But..."
    new "ولی..."

    # say L1036 bri
    old "You must stop being so dramatic with this. You have to be more professional and understand that this is the way it is done. So stop being so... Human..."
    new "باید اینقدر دراماتیک نباشی. باید حرف‌هایت رو حرف‌های حرفه‌ای‌تری بزنی و بفهمی که اینجوری هست. پس اینقدر... انسان‌باش نکن."


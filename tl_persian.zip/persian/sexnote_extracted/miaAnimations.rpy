# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/miaAnimations.rpy
translate persian strings:

    # say L6 devMia
    old "Mmm! Oh wow."
    new "مم! اوه وای."

    # say L7 devMia
    old "This is very different."
    new "این خیلی متفاوت است."

    # say L8 devMia
    old "Don’t stop."
    new "توقف نکن."

    # say L12 devMia
    old "I- I wasn’t expecting this. This sensation."
    new "من- من این را منتظر نبودم. این احساس."

    # say L14 devMia
    old "Oh, I’m more than ok."
    new "اوه، من خیلی خوب هستم."

    # say L15 devMia
    old "Do it faster."
    new "سریع‌تر بکن."

    # say L19 devMia
    old "AH, yes, like that, keep going!"
    new "آه، بله، همین‌جور، ادامه بده!"

    # say L20 pla
    old "I- feel..."
    new "من- احساس می‌کنم..."

    # say L21 devMia
    old "Don’t stop! KEEP GOING!"
    new "توقف نکن! ادامه بده!"

    # say L45 pla
    old "I think I can’t hold it back anymore!"
    new "فکر کنم نمی‌تونم دیگه خودمو کنترل کنم!"

    # say L46 devMia
    old "Let it go, cum inside me!"
    new "بیا، درون من خروجیت رو بده!"

    # say L47 devMia
    old "I want you to give that magic power!"
    new "من می‌خوام تو اون قدرت جادویی رو به من بدهی!"

    # say L48 devMia
    old "Oh yes!"
    new "اوه بله!"

    # say L54 dev
    old "Oh my! That was fantastic!"
    new "اوه خدا! این واقعاً شگفت‌انگیز بود!"

    # say L55 dev
    old "Linnet had told me about it, but this is just another level!"
    new "لینت به من گفته بود، اما این سطحی کاملاً متفاوت است!"

    # say L56 dev
    old "We have to try this again!"
    new "باید این رو دوباره امتحان کنیم!"

    # say L57 pla
    old "Are you insane?"
    new "تو دیوانه هستی؟"

    # say L58 pla
    old "We were already at risk doing it here, in the classroom."
    new "ما قبلاً در خطر بودیم وقتی اینجا، در کلاس، انجام میدادیم."

    # say L59 pla
    old "We need to leave before someone comes... But help me clean her first."
    new "باید برویم قبل از این که کسی بیاد... ولی اول به من کمک کن تمیزش کنم."

    # say L71 mia
    old "You say you don’t know what’s happening, yet you still have this boner."
    new "تو می‌گی نمی‌دونی چه قسمتی اتفاق می‌فته، ولی هنوز هم این سفتی داری."

    # say L72 pla
    old "W- well, t- that’s just because..."
    new "خب، اونجوری فقط چون..."

    # say L73 mia
    old "Spare me, will you?"
    new "لطفاً از این بپره."

    # say L74 mia
    old "I just need you to finish, I’ll go faster."
    new "من فقط نیاز دارم که این کار رو تمام کنی، من سریع‌تر می‌شوم."

    # say L78 mia
    old "You’re fucking disgusting for doing this, you know? To force me this way."
    new "می‌دونی که تو برای این کار خیلی خلافی هستی؟ می‌خوای من رو اینجوری مجبور کنی."

    # say L79 pla
    old "I- I already said I don’t know what are you talking abut."
    new "من قبلاً گفتم نمی‌دونم تو در می‌باری چه چیزی."

    # say L80 mia
    old "Sure... I guess this boner is just because I’m pretty, right? You are sick!"
    new "البته... حدس می‌زنم این سخت شدن فقط به خاطر زیبایی منه، درسته؟ تو بیماری!"

    # say L81 mia
    old "Will you just finish already?"
    new "بفرمایید خاتمه بدهید؟"

    # say L85 mia
    old "I just can’t believe you’d stood up this low."
    new "نمی‌تونم باور کنم اینقدر ما رو به پایین کشکردی."

    # say L86 mia
    old "I will never forgive this, and I’ll make sure you pay for this."
    new "من هرگز این رو مشمول نخواهم کرد و مطمئن می‌شوم که برای این پرداختی."

    # say L87 mia
    old "Don’t you think for a single second that you’ll pull this shit again."
    new "فکر نکن برای یک لحظه که دوباره این کار رو انجام می‌دهی."

    # say L110 pla
    old "M-Miss Mia, if you keep going, I-I’ll...!"
    new "میس میا، اگه هم اینجوری ادامه بدی، من...!"

    # say L111 mia
    old "Fucking finally!"
    new "اوه، در نهایت!"

    # say L112 mia
    old "Finish quickly will you? I don’t want to keep touching your dick."
    new "سریعتر تمامش کن، لطفاً. من نمی‌خوام دیگه به ناخودت لمس کنم."

    # say L117 mia
    old "Ughhh... This is so gross..."
    new "اوه... این خیلی خلافیه..."

    # say L118 mia
    old "Anyway, let's finish this shit."
    new "به هر حال، بیایم این کار را تمام کنیم."

    # say L119 pla
    old "W- What? Now what?"
    new "و- و چی؟ حالا چی؟"

    # say L124 pla
    old "What the hell was that?"
    new "چی بهش اومد این؟"

    # say L125 pla
    old "Why did you suddenly do that?"
    new "چرا اونجوری کردی؟"

    # say L126 mia
    old "I see you’re planning on keeping this up, huh?"
    new "بگو این کار را ادامه میدی، همه‌چی؟"

    # say L128 mia
    old "But I never thought you’d be the kind of disgusting cockroach that would do this type of shit."
    new "ولی هرگز فکر نکردم تو اون نوع کیسه‌پای خیزی باشی که این جور کارها رو انجام بدی."

    # say L140 den
    old "Yeah that’s right, get his dick in your mouth."
    new "بله درسته، اون نیت خوبتو تو دهان بیاورد."

    # say L141 den
    old "Like the whore you are."
    new "مثل مالکه‌ای که هستی."

    # say L142 mia
    old "S- shut up!"
    new "بسته بکن!"

    # say L146 den
    old "You must be enjoying this, aren’t you?"
    new "حتماً از این لذت می‌بری، هستی؟"

    # say L147 mia
    old "Pfff..."
    new "پف..."

    # say L148 den
    old "You little whore, look at how you do that."
    new "دیوونه نیستی، ببین چطور این کار رو می‌کنی."

    # say L149 den
    old "It must be your experience from all the cocks you’ve sucked."
    new "باید از تجربیاتت با همه ناخداهایی که لیسکری کردی، این‌جوری شده باشی."

    # say L153 den
    old "Tell me Mia, how much are you enjoying this?"
    new "میا، اینقدر لذت می‌بری از این؟"

    # say L154 mia
    old "Glurpp... F- fuck you!"
    new "Glurpp... ف- فکرت!"

    # say L155 den
    old "Ha, you’re gagging on cock and you’re telling me to shut up?"
    new "ها، تو از خوردنش خوشت می‌آید و می‌خوای از من بگی بسته شوم؟"

    # say L178 den
    old "I see you’re about to finish [pla], that’s good, that’s good."
    new "دیدم که قراره تمام شی [pla]، خوبه، خوبه."

    # say L179 den
    old "Why don’t you go ahead and cum in her mouth?"
    new "چرا نمی‌ری و تو دهانش بیا؟"

    # say L180 den
    old "Don't worry, she'll swallow it all, that's what she used to do."
    new "نگران نباش، او همه‌ش رو خواهد خورد، همین کاری که قبلاً می‌کرد."

    # say L181 den
    old "You better drink every drop Mia, that’s an order."
    new "mia، هر قطره‌اش رو بنوش، این دستوره."

    # say L187 pla
    old "Are you ok Miss Mia?"
    new "آقای میا، حالت خوب است؟"

    # say L189 mia
    old "Ohh, yes, I’m fine, just let me gather my bearings for a second."
    new "اوه، بله، خوبم، فقط یک لحظه برام وقت بده تا جمع‌جمع شوم."

    # say L190 pla
    old "I’m sorry, for finishing in your mout-... I mean for everything."
    new "متأسفم، برای اونجوری که تو دهنت تمام شدم... منظورم برای همه چیز."

    # say L193 mia
    old "That asshole is the one who made us do this."
    new "این خرایش همون است که ما رو به این کار زد."

    # say L211 mia
    old "Oh! Nghn!"
    new "اوه! نگه دار!"

    # say L212 den
    old "Ha, what’s the matter Ms? Is it too big for you?"
    new "ها، چه کاری داری مس؟ آیا برایت بزرگ هست؟"

    # say L213 den
    old "But you’re so experienced! Come on! I know you can take it all!"
    new "ولی تو تجربه‌ت خیلی زیاده! بیا! میدونم میتونی همه‌ش رو تحمل کنی!"

    # say L217 den
    old "Hey [pla]! You’re fucking your teacher that always tormented you!"
    new "هی ز[pla]! تو معلمتو که همیشه تو رو آزار میداد، فوتونی!"

    # say L218 den
    old "I bet it must feel really nice, huh?"
    new "حتماً خیلی لذت بر می‌ده، ها؟"

    # say L219 den
    old "I know you wanted to do this bro! She’s been messing with you after all."
    new "میدونم می‌خواستی اینو بکنی، برادر! در نهایت همیشه تو رو آزار داده."

    # say L220 den
    old "That’s it, fuck her like the whore she is!"
    new "بزن برایش مثل ماری که هست!"

    # say L224 den
    old "How do you feel Ms. Mia?"
    new "می‌تونی حس می‌کنی، خانم میا؟"

    # say L225 den
    old "I bet you like having his big cock inside!"
    new "حتماً لذت می‌بری از اون نوک بزرگش داخلت!"

    # say L226 den
    old "Just like the old days, huh?"
    new "مثل روزهای قدیمی، هuh؟"

    # say L227 mia
    old "S- Mmm! Shut up!"
    new "س- مم! بس کن!"

    # say L250 pla
    old "M-Miss Mia, I think - I think I’m..."
    new "میس میا، فکر می‌کنم - فکر می‌کنم من..."

    # say L251 den
    old "Yeah! That’s it [pla], fill her up!"
    new "بله! همینه [pla]، پر کن!"

    # say L257 pla
    old "A-are you ok Miss Mia?"
    new "آقای میا، حالتون چطوره؟"

    # say L258 pla
    old "I’m sorry."
    new "متأسفم."

    # say L260 mia
    old "It’s ok, you shouldn’t have to apologize."
    new "خوبه، نباید عذرخواهی کنی."

    # say L261 mia
    old "You’re also a victim here."
    new "شما هم قربانی هستید."

    # say L262 mia
    old "You’re actually a big help."
    new "شما در واقع کمک زیادی می‌کنید."

    # say L282 den
    old "Yeah, you probably missed that dick, didn’t you Mia?"
    new "بله، احتمالاً اون نیمرو رو خیلی دوست داشتی، همین‌جوری می‌تونم بگم میا؟"

    # say L284 den
    old "Answer me Mia!"
    new "پاسخ بده میا!"

    # say L285 mia
    old "Y- Nghn! Mmm! Y-Yeah I do!"
    new "Y- نگن! مم! Y-بله من همین‌جوری دوست دارم!"

    # say L289 den
    old "I bet you like fucking in the bathroom!"
    new "حتماً دوست داری توی حمام جنس کنی!"

    # say L290 den
    old "You like that you almost got caught, don’t you Mia?"
    new "می‌تونی بگی دوستت داره که تقریباً درگیر شدی، نه میا؟"

    # say L291 den
    old "Is exciting isn’t it?"
    new "الان هیجان‌آور نیست؟"

    # say L292 den
    old "I can’t hear you!"
    new "من نمی‌تونم تو رو بشنوم!"

    # say L293 mia
    old "Y-yes! Ah! Is... Ah! Very exciting!"
    new "بله! آه! خیلی هیجان‌انگیز است!"

    # say L316 den
    old "I see you’re about to finish [pla]."
    new "می‌بینم تو در حال رسیدن به اوج هستی [pla]."

    # say L317 den
    old "It’s ok dude, let it out!"
    new "بچه، خوبه، بیا بیرون بیا!"

    # say L318 den
    old "I want you to fill her pussy up!"
    new "من می‌خوام تو اونجا رو پر کنی!"

    # say L319 pla
    old "M-Miss Mia, I- I’m about to...!"
    new "میس میا، من در حال...!"

    # say L320 mia
    old "J-just do it!"
    new "ج-جرد بکن!"

    # say L325 den
    old "Well guys, I would say that was perfect! Don’t you agree?"
    new "خب جون‌ها، من می‌گم این کامل بود! شما هم موافقم؟"

    # say L326 den
    old "Hahahaha, you can really tell Mia has some experience in front of the camera."
    new "هahaha، واقعاً می‌شه فهمید میا تجربه زیادی در برابر دوربین داره."

    # say L327 den
    old "You too [pla], you’re a natural dude!"
    new "تو هم ز[pla]، تو خودت هم یه طبیعتی دی!"

    # say L328 den
    old "Well, I think I should just leave you two little lovebirds to comfort each other."
    new "خب، فکر کنم باید شما دو عشقمون رو به هم راحت کنید."

    # say L329 den
    old "But remember, all of this has been recorded, I don’t have to remind you what that means... Anyway, bye."
    new "ولی به خاطر داشته باش، همه اینا ضبط شده، نیازی ندارم بهت یادآوری کنم که این چه معنی داره... بای."

    # say L345 dir
    old "Oh yeah! That’s it!"
    new "آره! همینه!"

    # say L346 dir
    old "Yes! Yes! It’s so good!"
    new "بله! بله! خیلی خوبه!"

    # say L347 dir
    old "It’s even better than a real dick!"
    new "بله! بلی! حتی بهتر از یک نیم واقعیه!"

    # say L352 dir
    old "Ah! Ah! Yeah!"
    new "آه! آه! بله!"

    # say L353 dir
    old "That’s just what I wanted!"
    new "این همینه که می‌خواستم!"

    # say L354 dir
    old "YES!"
    new "بله!"

    # say L387 mia
    old "Mmm, it’s so hard"
    new "می‌آه، خیلی سخت است"

    # say L388 mia
    old "Oh! Mmm!"
    new "اوه! مم!"

    # say L389 pla
    old "M-Mia, lower your voice."
    new "میا، صدایت رو پایین ببر."

    # say L393 dir
    old "Oh, oh fuck yeah!"
    new "اوه، اوه بله!"

    # say L395 dir
    old "MMMM! FUCK YEAH!"
    new "MMMM! فکر کنم بله!"

    # say L399 dir
    old "Well, that just cheered me up!"
    new "خب، این هم منو خوشحال کرد!"

    # say L400 dir
    old "What a great way to start the day!"
    new "چه راه خوبی برای شروع روز!"

    # say L412 miavid
    old "Oh fuck, Ah!"
    new "اوه شیطون، آه!"

    # say L413 black1
    old "Yes, oh you look so fucking good."
    new "بله، اوه، تو خیلی زیبا به نظر می‌رسی."

    # say L414 miavid
    old "Mmmm! Ahhh! It's so big..."
    new "ممنن! اه! خیلی بزرگه..."

    # say L415 black1
    old "That’s what I wanna hear."
    new "این همینه که می‌خوام بشنوم."

    # say L416 black2
    old "Keep sucking bitch."
    new "ادامه بده بیچ."

    # say L418 pla
    old "You had to memorize these dialogues or..."
    new "باید این دیالوگ‌ها رو حفظ کردی یا..."

    # say L419 mia
    old "Uhh... Something like that... That’s how it usually is in that industry."
    new "اوه... چیزی مثل اون... همینجور معمولاً در اون صنعت هست."

    # say L420 mia
    old "Also my moans and everything, you have to pretend it all."
    new "همچنین صداهای من و همه چیز، باید همه چیز رو بازی کنی."

    # say L424 miavid
    old "Mmm! Slurp! Slurp!"
    new "میام: مم! لیز! لیز!"

    # say L425 black1
    old "Mmm yeah babe, it feels really nice..."
    new "می‌دونم حلیم، اون هم خیلی خوبه..."

    # say L426 miavid
    old "Oh, yeah!"
    new "اوه، بله!"

    # say L428 pla
    old "Did you guys ever improvised the lines or anything?"
    new "می‌تونستید وقتی خطوط رو اجرا می‌کردید، خودتون آنها رو تغییر می‌دادین یا چیزی؟"

    # say L429 mia
    old "Yeah, the only script we had was for the set ups, but most of the time we were improvising."
    new "بله، تنها اسکریپتی که داشتیم برای آماده‌سازی بود، اما بیشتر وقت‌ها در حال ایمپروویز بودیم."

    # say L430 pla
    old "Yeah, I could kinda tell."
    new "بله، من هم متوجه بودم."

    # say L434 black2
    old "Oh my gosh, I can feel it reaching your throat."
    new "اوه خدای من، می‌تونم حس کنم به گلوت می‌رسه."

    # say L435 miavid
    old "Mmmm... Yeah baby..."
    new "ممنن... بله عزیزم..."

    # say L436 black1
    old "That’s what you wanted bitch!"
    new "این همینه که می‌خواستی، خاکستری!"

    # say L437 miavid
    old "Yeah! Yeah!"
    new "آره! آره!"

    # say L438 miavid
    old "I love your big black cocks!"
    new "من عاشق پوس‌های بزرگ و سیاهتانتون هستم!"

    # say L440 pla
    old "You know... You were very good at this."
    new "دیویس، می‌دونی... تو توی این کار خیلی خوب بودی."

    # say L441 mia
    old "Ugh! Come on! Really [pla]?"
    new "اوه! بیا! واقعاً [pla]؟"

    # say L442 mia
    old "That’s what you have to say about it?"
    new "این همه برای این می‌گی؟"

    # say L443 pla
    old "Sorry, sorry, you’re right, that was out of line, I was just saying."
    new "ببخشید، ببخشید، درست می‌فرمایی، این جوری بودن نباید بود، فقط می‌خواستم بگم."

    # say L444 mia
    old "Yeah, yeah, I know what you mean..."
    new "بله، بله، من هم می‌دونم..."

    # menu L465 
    old "Skip"
    new "رد کردن"

    # say L466 mia
    old "Ok, that’s enough, there aren’t any more videos or anything else in the folder."
    new "خب، خوب است، هیچ ویدیو یا چیز دیگری در پوشه نیست."

    # say L467 mia
    old "So we don’t need to keep checking this out."
    new "پس نیازی نداریم دیگر اینجا را بررسی کنیم."

    # say L468 pla
    old "Yeah, you’re right."
    new "بله، درست می‌گی‌ی."

    # say L478 miavid
    old "I-It’s so fucking big!"
    new "اینقدر بزرگه!"

    # say L479 miavid
    old "I can’t handle it! AH!"
    new "من نمی‌تونم! اه!"

    # say L480 black1
    old "That’s right baby, take that big black cock!"
    new "درسته حلمو، اون لوله سیاه بزرگ رو بگیر!"

    # say L481 miavid
    old "AH! AH! AAAAH!"
    new "آه! آه! آآآاه!"

    # say L483 pla
    old "Well, they are very big."
    new "خب، خیلی بزرگ هستند."

    # say L484 mia
    old "Mmm, not the biggest ever."
    new "میام، نه بزرگ‌ترین‌ها هستند."

    # say L503 mia
    old "Just don’t take too much time."
    new "فقط زیاد وقت نبری."

    # say L504 mia
    old "We’re supposed to already be going to the principal's office."
    new "ما قرار است قبلاً به دفتر رئیس مدرسه برویم."

    # say L505 pla
    old "O-ok!"
    new "باشه!"

    # say L508 mia
    old "Hurry up!"
    new "سریع شو!"

    # say L509 pla
    old "I-I’m trying, but I can’t do it if you keep rushing me!"
    new "من سعی می‌کنم، ولی اگه همیشه عجله‌گرانه باشی، نمی‌تونم انجام بدم!"

    # say L510 mia
    old "Just let go and enjoy it."
    new "فقط رها کن و لذت ببر."

    # say L511 mia
    old "That way you’ll cum quickly."
    new "اینطور می‌تونی سریعتر لذت ببری."

    # say L512 mia
    old "I’ll go faster!"
    new "من سریع‌تر می‌شوم!"

    # say L517 mia
    old "That’s it, I can feel you getting harder."
    new "این‌هاست، می‌تونم احساس سخت شدن تو رو بگیرم."

    # say L518 mia
    old "There you go, just enjoy my mouth!"
    new "بیا، فقط لذت بردار از دهانم!"

    # say L519 pla
    old "I-I think it’s working."
    new "فکر کنم کار می‌کنه."

    # say L543 pla
    old "M-Mia I think I’m cuming!"
    new "میا، فکر کنم می‌آیم!"

    # say L544 mia
    old "Do it, quickly!"
    new "بیا، سریع!"

    # say L545 mia
    old "Finish!"
    new "پایان بده!"

    # say L551 mia
    old "I mean, did you have to finish all over me?"
    new "من قصدم این بود که تو روی من تمام شدی؟"

    # say L552 mia
    old "You covered me in cum!"
    new "تو مرا با سیاله پوشوندی!"

    # say L553 pla
    old "S-sorry, I couldn’t really control it."
    new "می‌تونی ببخشی، واقعاً خودمو کنترل نکردم."

    # say L554 mia
    old "Whatever, listen, I’ll get clean quickly and we’ll go to the principal’s office."
    new "باید برم تمیز بشم و بعد بریم به دفتر رئیس."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/momAnimations.rpy
translate persian strings:

    # say L7 mo1
    old "Oh yes, just like that. Does it feel nice hun?"
    new "او بله، همینطور. آیا خوشحال می‌شی، حلق؟"

    # say L8 pla
    old "Mmmm yeah, it feels really nice."
    new "ممنون، همینطور. احساس خوبی می‌کنه، حلق."

    # say L9 mo1
    old "Great, just relax and enjoy the... Uhmm massage."
    new "عالی، فقط آرام بگیر و از... اوه ماساژ لذت ببر."

    # say L13 mo1
    old "Let me do it a bit faster."
    new "بیای برای من یک کم سریع‌تر باش."

    # say L17 mo1
    old "Uhmm? does it hurt darling??"
    new "اوه؟ آیا درد می‌کنه عزیزم؟"

    # say L18 pla
    old "No, no, don't worry. It feels better."
    new "نه، نه، نگران نباش. بهتر می‌شه."

    # say L19 mo1
    old "Ohh, ok, I'm glad."
    new "اوه، خب، خوشحالم."

    # say L23 pla
    old "Hmm, [mo1rel]? Would you please do it faster?"
    new "هم، ز[mo1rel]؟ لطفاً سریع‌تر انجام بدی."

    # say L24 mo1
    old "Ohh, of course hun."
    new "اوه، البته عزیزم."

    # say L28 pla
    old "Ohhh yes, yes, just like this."
    new "اوه ها، بله، بله، دقیقاً مثل این."

    # say L29 mo1
    old "I can feel that body is tensing up. You can release your load whenever you want, darling."
    new "می‌تونم اون بدن رو تنیده می‌شناسم. می‌تونی هر وقت خواستی خودت رو رها کنی، عزیزم."

    # say L53 pla
    old "Mmmm, [mo1rel] I- I feel like I'm going to explode..."
    new "ممم، ز[mo1rel] من- من احساس می‌کنم مثل بمبی می‌افتم..."

    # say L54 mo1
    old "It's alright honey, just let it all go."
    new "خوبه عزیزم، فقط همه‌ش رو رها کن."

    # say L55 pla
    old "Ahhh... Ahhhh!"
    new "آه... آه..."

    # say L60 mo1
    old "Mmmm, good job honey. You did it just great."
    new "ممنون عزیزم. خوب انجام دادی، واقعاً خوب."

    # say L61 pla
    old "-Sigh- Thanks [mo1rel]."
    new "ممنون [mo1rel]."

    # say L66 mo1
    old "Okay, this will definitely help."
    new "خوب، این حتماً کمکت می‌کنه."

    # say L67 pla
    old "Thanks."
    new "ممنون."

    # say L68 mo1
    old "You are welcome honey, I hope you feel better now."
    new "خوشحالم عزیزم، امیدوارم حالا حالت بهتر شده باشه."

    # say L69 pla
    old "Yes, I do. although I'm feeling a bit tired."
    new "بله، همین‌طور است. اما یک کم خسته‌ام."

    # say L70 mo1
    old "Aww, don't worry hun, just rest a little."
    new "اوه، نگران نباش عزیزم، فقط یک کم استراحت کن."

    # say L72 mo1
    old "Oh, and remember, don't tell anyone. Especially [mo2]! She wouldn't understand and would kill us!"
    new "اوه، و به خاطر داشت، به هیچ کس نگو. خصوصاً [mo2]! او نمی‌فهمد و ما رو می‌کشت!"

    # say L73 pla
    old "Ok [mo1rel]."
    new "باشه [mo1rel]."

    # say L74 mo1
    old "You know you can always count on me."
    new "میدونی همیشه می‌تونی بر من اتکا کنی."

    # say L75 pla
    old "Yes, thank you [mo1rel]."
    new "بله، ممنون [mo1rel]."

    # say L76 mo1
    old "You are welcome. Well, if you need me, you know where to find me."
    new "خواهش می‌کنم. خب، اگر به من نیاز داشتی، می‌دونی کجایی می‌تونی منو پیدا کنی."

    # say L98 mo1
    old "Oh my God, I can't believe how big it is."
    new "اوه خدا، نمی‌تونم باور کنم چقدر بزرگه."

    # say L100 mo1
    old "Is the biggest I have ever seen."
    new "بزرگترینی که هرگز دیده‌ام."

    # say L105 mo1
    old "Do you like how I'm jerking you off?"
    new "می‌پسندی اینجوری که تو رو می‌بازم؟"

    # say L106 pla
    old "... Y- yes it feels nice."
    new "بله، خوب احساس می‌کنم."

    # say L107 mo1
    old "Mmm, your cock looks really tasty."
    new "می‌تونم بگم پوسیدنتون خیلی لذت‌بخش به نظر می‌رسه."

    # say L113 mo1
    old "Are you getting close?"
    new "آیا نزدیک شوی؟"

    # say L114 pla
    old "Uhh y- yes."
    new "آره، همین حالا."

    # say L115 mo1
    old "Would you like to cum for me?"
    new "می‌خوای برای من خروجی بدی؟"

    # say L155 pla
    old "Mmmm, [mo1rel] I- I gonna cum..."
    new "ممم، ز[mo1rel] من- من قراره خروجی بدم..."

    # say L156 mo1
    old "Oh yeah, cum for mommy."
    new "اوه بله، برای مامان برسو."

    # say L162 pla
    old "Ughh, that was so intense, [mo1rel]."
    new "اوه، این خیلی شدید بود، [mo1rel]."

    # say L163 mo1
    old "Mmmm, I'm glad you liked it..."
    new "ممنونم که لذت برده‌ای..."

    # say L164 mo1
    old "But... Now, let's finish watching this movie."
    new "اما... حالا بیاین این فیلم رو تمام ببینیم."

    # say L165 pla
    old "For sure."
    new "حتماً."

    # say L178 mo1
    old "Mmmm, it tastes really good."
    new "ممم، واقعاً خوب می‌چه."

    # say L179 mo1
    old "Does it feels better than my hand, isn't it?"
    new "آیا این بهتر از دست من است، نیست؟"

    # say L180 pla
    old "Uhhh, yeah."
    new "اوه، بله."

    # say L185 mo1
    old "Do you like to feel my warm and wet mouth?"
    new "آیا دوست داری احساس دهانم گرم و مرطوب را بکنی؟"

    # say L186 pla
    old "Ohhh, y- yes it feels amazing."
    new "اوه، بله، احساسش شگفت‌انگیز است."

    # say L187 mo1
    old "Then there is something that you are going to enjoy even more."
    new "پس چیزی هست که خوشت حتی بیشتر می‌آید."

    # say L192 mo1
    old "Mmmm, I love to suck your cock!"
    new "می‌خوام ناخون تو رو بیشتر بپسندم!"

    # say L193 mo1
    old "Would you like to cum in my mouth?"
    new "آیا می‌خوای تو دهانم بیایی؟"

    # say L194 pla
    old "Wow, can I?"
    new "واو، می‌تونم؟"

    # say L195 mo1
    old "Mmmm, please honey. I would love to taste all your load."
    new "ممم، لطفاً عزیزم. من خیلی می‌خواهم تمام آن را بچشتم."

    # say L234 pla
    old "Mmmm, [mo1rel], I feel like..."
    new "ممم، ز[mo1rel]، حس می‌کنم مثل..."

    # say L237 mo1
    old "Glurpp... Wow, it was a huge load."
    new "Glurpp... وای، این خیلی زیاد بود."

    # say L239 mo1
    old "Glup... Whew, I had to swallow a lot."
    new "گلوپ... وای، باید خیلی چیزی را بلعیدم."

    # say L243 pla
    old "It was AMAZING [mo1rel]."
    new "بود خیلی عالی [mo1rel]."

    # say L244 mo1
    old "Well, I'm glad you loved it..."
    new "البته، خوشحالم که لذت برده‌ای..."

    # say L245 mo1
    old "But now let's continue the movie."
    new "اما حالا بیاین فیلم رو ادامه بدیم."

    # say L267 pla
    old "Is this a dream?"
    new "این یه رویا هست؟"

    # say L268 pla
    old "Oh my gosh! My [mo1rel] it's fucking hot!"
    new "اوه خدا! ز[mo1rel] من همینجا آتش می‌خورم!"

    # say L273 pla
    old "Holly shit! Look at those tits bouncing!"
    new "هالی شیت! نگاه کن به اون سینه‌ها که می‌رقصن!"

    # say L274 pla
    old "This view is amazing."
    new "این منظره شگفت‌انگیز است."

    # say L303 pla
    old "Wow... That was a dream?"
    new "وای… آن رویا بود؟"

    # say L305 pla
    old "It was very strange because it felt very real..."
    new "بی‌نظیر بود زیرا خیلی واقعی به نظر می‌آمد..."

    # say L307 pla
    old "Anyway, I better go to sleep..."
    new "به هر حال، بهتره برم خواب بکنم..."

    # say L326 pla
    old "Mmmm, it feels really nice."
    new "ممنون، احساس خوبی داره."

    # say L327 mo1
    old "Sorry, did you say something?"
    new "ببخشید، چیزی گفتید؟"

    # say L328 pla
    old "Uhmm, no, no sorry."
    new "نه، نه، معذرت."

    # say L329 pla
    old "(Shit I better stay quiet)"
    new "شیطون، بهتره خیال کنم که هیچ چیز نگفتم"

    # say L369 mo1
    old "Wow honey, did you spill more sunscreen in my legs?"
    new "وای عزیزم، آیا دوباره خورشیدآب‌نورد رو بر لگه‌هام ریختی؟"

    # say L370 pla
    old "(Oh shit...) Yes, I spilled more to make sure, you don't get sunburned."
    new "(اوه شیطون...) بله، بیشتر رو برای این کردم که آفتاب سوختن نکنی."

    # say L373 mo1
    old "Aww, you are a sweetheart."
    new "اوه، تو خیلی لطف داری."

    # say L374 pla
    old "(Oh fuck that was close... Should I make another try?)"
    new "اوه خدای من این هم خیلی نزدیک بود... باید دوباره سعی کنم؟"

    # say L385 pla
    old "{b}Sauron's mouth:{/b} Now is your turn... Use your feet to massage me, ok?"
    new "{b}دستور ساورن:{/b} حالا دوباره تو هستی... با پاشون من رو ماساژ کن، خوبه؟"

    # say L393 pla
    old "(Holly shit! Is working.)"
    new "هالی شیطان! کار می‌کنه."

    # say L398 pla
    old "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (No, I shouldn't take risks.)"
    new "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (نه، نباید ریسک ببرم.)"

    # say L399 pla
    old "Well is done, I think you are perfect now."
    new "خوب، فکر کنم حالا کاملی هستی."

    # say L400 mo1
    old "Aww, thank you so much, see you later sweetheart."
    new "الا، ممنونم خیلی، بعداً دوست من ببینم."

    # say L445 pla
    old "Holy shit, I can't help it anymore..."
    new "هیلی شیط، دیگه نمی‌تونم تحمل کنم..."

    # say L496 mo1
    old "What the fuck?"
    new "چه کاری می‌کنی؟"

    # say L497 pla
    old "(Oh... Shit.)"
    new "اوه... شیط."

    # say L505 mo1
    old "What the fuck were you doing [pla]!?"
    new "تو چه کاری انجام می‌دادی [pla]!؟"

    # say L506 pla
    old "Sorry I... I..."
    new "ببخشید من... من..."

    # say L508 mo1
    old "You were rubbing your... With my ass?"
    new "تو داشتی... با پشت من می‌فرکتی؟"

    # say L512 mo1
    old "I can't believe it! What's wrong with you?"
    new "من نمی‌تونم باور کنم! تو چه مشکلی داری؟"

    # say L513 pla
    old "Sorry... It was not my intention..."
    new "ببخشید... من قصد نداشتم..."

    # say L515 mo1
    old "It wasn't your intention? What the fuck?..."
    new "این هم نبود هدفت؟ چه خرابه‌ای؟..."

    # say L516 mo1
    old "I... I'll clean it myself, I don't want to see you anymore..."
    new "من... من خودم اینو تمیز می‌کنم، دیگه نمی‌خوام تو رو ببینم."

    # say L519 pla
    old "Oh shit, I messed it up."
    new "اوه شیطون، این رو خراب کردم."

    # say L527 mo1
    old "Again?"
    new "دوباره؟"

    # say L533 mo1
    old "Oh honey again?"
    new "اوه عزیزم دوباره؟"

    # say L534 pla
    old "I'm sorry I couldn't resist, I can't control it"
    new "ببخشید نتونستم خودمو کنترل کنم، اینجوری نمی‌تونم کنترلش کنم"

    # say L536 mo1
    old "Mmm... It's alright, just please try not to rub your... against my ass, ok?"
    new "ممنون، فقط لطفاً سعی کن در برابر پشت من این کار رو نکنی، خب؟"

    # say L540 mo1
    old "If you need to release it, you can ask my help or do it by yourself."
    new "اگر نیاز داری آن را آزاد کنی، می‌توانی از من کمک بخواهی یا خودت انجام بدی."

    # say L542 pla
    old "You're right... It was not my intention..."
    new "درست می‌گی‌ی... من قصد نداشتم..."

    # say L544 mo1
    old "I know sweetheart don't worry..."
    new "میدونم عزیزم نگران نباش..."

    # say L546 mo1
    old "I'm going to clean myself."
    new "من برای تمیز شدن می‌روم."

    # say L562 mo1
    old "{i}Does it turn you on?{/i}"
    new "{i}این به تو خوشحالم می‌ده؟{/i}"

    # say L563 pla
    old "{i}W- what?{/i}"
    new "{i}W- چی؟{/i}"

    # say L564 mo1
    old "{i}Does it turn you on, doing it in front of [mo2]?{/i}"
    new "{i}آیا اینکه در مقابل [mo2] انجام می‌دهی، تو رو خشن می‌کنه؟{/i}"

    # say L571 pla
    old "{i}That's why we should stop.{/i}"
    new "{i}این به همین خاطر باید متوقف شویم.{/i}"

    # say L604 mo1
    old "{i}Cum quietly!{/i}"
    new "{i}آرام! {/i}"

    # say L608 mo1
    old "{i}Wow, you still hard... We will need to do something else, right?{/i}"
    new "{i}واو، هنوز سختی... باید چیز دیگه‌ای انجام بدیم، درسته؟{/i}"

    # say L612 mo1
    old "{i}You will love this...{/i}"
    new "{i}شما اینو دوست خواهید داشت...{/i}"

    # say L624 pla
    old "{i}Holy Shit!{/i}"
    new "{i}لایه شیطان!{/i}"

    # say L627 pla
    old "Uhhh... No, no, I- I'm just excited by the movie..."
    new "اوه... نه، نه، من- من فقط از فیلم خوشحالم..."

    # say L628 mo2
    old "Can't you see a movie quietly?"
    new "نمی‌تونی فیلم رو به آرامی ببینی؟"

    # say L629 pla
    old "Yes, yes I- I'm sorry."
    new "بله، بله من- من متاسفم."

    # say L631 mo1
    old "{i}Shhh, just relax and enjoy...{/i}"
    new "{i}ش ها، فقط آرام شو و لذت ببر...{/i}"

    # say L648 mo1
    old "{i}Do you realize I'm giving you a blowjob almost in front of [mo2]?{/i}"
    new "{i}آیا می‌دونی من تو رو تقریباً جلوی [mo2] می‌زنم؟{/i}"

    # say L649 pla
    old "{i}Yeah, that's crazy.{/i}"
    new "{i}آره، این خیلی عجیبه.{/i}"

    # say L650 mo1
    old "{i}Actually, is behind [mo2], and it sounds even naughtier... Hehehe.{/i}"
    new "{i}در واقع، پشت [mo2] هستیم، و این هم خیلی جسورانه‌تر می‌شنود... هه هه هه.{/i}"

    # say L651 pla
    old "{i}How much did you drink?{/i}"
    new "{i}چقدر خورده‌ای؟{/i}"

    # say L683 mo1
    old "{i}Wow it was a lot... Did you like it?{/i}"
    new "{i}واو خیلی بود... لذت برده بودی؟{/i}"

    # say L694 mo1
    old "Wow the movie was great, right [pla]?"
    new "فیلم عالی بود، درسته [pla]؟"

    # say L696 pla
    old "Oh yes, it was awesome."
    new "بله، خیلی عالی بود."

    # say L698 mo2
    old "I thought it was stupid... Anyway I'm going bed."
    new "من فکر می‌کردم خنده‌دار نبود... هر حال من می‌روم بخوابم."

    # say L701 mo1
    old "Yes, good night honey, sleep well."
    new "بله، شب خوبی بچه‌جان، خوب بخواب."

    # say L703 pla
    old "Good night"
    new "شب خوب باش، عزیزم"

    # say L718 mo1
    old "Do you like my tits, isn't it?"
    new "می‌پسندی سینام، درسته؟"

    # say L719 mo1
    old "Well, I think you deserve a great titjob."
    new "خب، فکر کنم این کار خوبی برایت باشه."

    # say L725 mo1
    old "How does it feel to have your [mo1rel] tits around your cock?"
    new "حاسه چطوره وقتی ز[mo1rel]تات رو دور ناخنات بچرخانی؟"

    # say L726 pla
    old "Uhh... It feels amazing!"
    new "اوه... احساسش شگفت‌انگیزه!"

    # say L727 mo1
    old "Mmmm, I'm enjoying it too."
    new "ممنون، من هم لذت می‌برم."

    # say L732 mo1
    old "Would you like to cum on my tits?"
    new "می‌خوای روی سینه‌هام بیا؟"

    # say L733 pla
    old "Oh yeah."
    new "اوه بله."

    # say L734 mo1
    old "So, cum on your [mo1rel]'s tits."
    new "پس، روی سینه‌های [mo1rel] خروجی بدی."

    # say L759 pla
    old "Ughhh... Ahhh!"
    new "اوه... اه!"

    # say L760 mo1
    old "Oh yes! Cum all over me!"
    new "اوه بله! روی من بیا!"

    # say L764 mo1
    old "Wow you came a lot..."
    new "واو، هیچ جوری هم نیومدی..."

    # say L765 mo1
    old "I'm glad you're still hard, because I need you inside of me now."
    new "خوشحالم که هنوز سختی، زیرا احتیاج دارم حالا توی من باشی."

    # say L767 mo1
    old "Come with me to the bed"
    new "بیا با من به تخت"

    # say L786 mo1
    old "Uhhh, yes, just like that."
    new "آه، بله، همینطور."

    # say L787 mo1
    old "I'm I can feel your cock inside me, and it feels amazing!"
    new "می‌تونم احساس کنم شما رو درونم، و این حس خیلی عالیه!"

    # say L792 mo1
    old "Mmmm, it feels so nice!"
    new "ممم، اینجوری خوب است!"

    # say L793 mo1
    old "Oh yeah, don't stop baby, don't stop!"
    new "اوه بله، ادامه بده عزیزم، ادامه بده!"

    # say L798 mo1
    old "Ahhh, ahhh, yeah fuck me, fuck me!"
    new "اوه، اوه، بله بگیرم، بگیرم!"

    # say L799 mo1
    old "Yess! Fuck your [mo1rel] harder!"
    new "بله! سخت‌تر به [mo1rel] بزن!"

    # say L800 mo1
    old "Mmmm... I'm getting close, don't stop."
    new "ممم... من به نوبت می‌رسم، متوقف نشو."

    # say L828 mo1
    old "God, that was awesome."
    new "الهی، این خیلی عالی بود."

    # say L835 mo1
    old "Let's rest a little."
    new "بیایم کمی استراحت کنیم."

    # say L845 mo1
    old "That was a fantastic night honey."
    new "این شب خیلی عالی بود عزیزم."

    # say L847 pla
    old "Yes, I really enjoyed it."
    new "بله، خیلی لذت بردم."

    # say L849 mo1
    old "Remember we must be careful, no one can know... Ok?"
    new "به یاد داشته باشیم باید مراقب باشیم، هیچ کس نمی‌تونه بدونه... خوبه؟"

    # say L851 pla
    old "Yes, don't worry."
    new "بله، نگران نباش."

    # say L853 mo1
    old "Go to your room quietly to avoid suspicion."
    new "بپرس از اتاق خودت به آرامی برای اینکه شک نیوفتد."

    # say L855 pla
    old "You're right! I will."
    new "درست می‌گویی! من می‌روم."

    # say L864 mo1
    old "Oh no... I'm sorry, I'm really sorry ..."
    new "اوه نه... معذرت، واقعاً معذرت می‌خواهم..."

    # say L866 pla
    old "What? Why?"
    new "چرا؟"

    # say L868 mo1
    old "For what happened last night, it was definitely very bad, I drank too much and-"
    new "برای آنچه دیروز شب اتفاق افتاد، قطعاً خیلی بد بود، خیلی زیاد مصرف کردم و-"

    # say L870 pla
    old "No, we both decided to do it, I also agreed."
    new "نه، ما هر دو تصمیم گرفتیم انجام بدیم، من هم موافقم."

    # say L873 mo1
    old "But I am your [mo1rel]."
    new "اما من مادرت هستم [mo1rel]."

    # say L875 pla
    old "(Hmmm... I could need a bit of help here ...)"
    new "Hmm... ممکنه کمی کمکی به من بکنی؟"

    # say L879 mo1
    old "Yes, we are both adults ..."
    new "بله، ما هر دو بزرگسالیم..."

    # say L881 mo1
    old "You know what, what the hell, I'm not going to keep worrying about [mo2]."
    new "می‌دونی چی، بی‌خیال، نمی‌تونم دیگه نگران این باشم [mo2]."

    # say L883 mo1
    old "If you're okay with this, I think I'm fine too, right?"
    new "اگر تو با این مشکلی نداری، فکر کنم من هم خوب هستم، درسته؟"

    # say L887 mo1
    old "Also yesterday I really enjoyed it and can't believe I haven't done it in so many years!"
    new "همچنین دیروز خیلی لذت بردم و نمی‌تونم بیاورم چرا اینقدر طول کشیده!"

    # say L889 pla
    old "I also enjoyed it a lot."
    new "من هم خیلی لذت بردم."

    # say L891 mo1
    old "Just be careful, I don't want anyone to notice, ok?"
    new "فقط مراقب باش، نمی‌خوام هیچ‌کس متوجه بشه، خب؟"

    # say L895 mo1
    old "Great honey, let's go, I have to prepare breakfast."
    new "عالی عزیزم، بیایید برویم، باید صبحانه رو آماده کنم."

    # say L902 pla
    old "Well, that was insane... I had sex with [mo1rel]..."
    new "خب، این جنون بود... من با [mo1rel] سکس کردم..."

    # say L904 pla
    old "Cool."
    new "خوب."

    # say L993 mo1
    old "Ahhhh... It's so big"
    new "اوه... اینقدر بزرگه"

    # say L994 mo1
    old "Mmmm, it feels amazing!"
    new "ممم، احساسش عالیه!"

    # say L999 mo1
    old "Uhhh yeah, baby I love your cock."
    new "اوه بله، عزیزم من عاشق ناخودت هستم."

    # say L1000 mo1
    old "Oh God, oh God! I'm so wet."
    new "اوه خدا، اوه خدا! من خیلی خیس شدم."

    # say L1005 mo1
    old "Yeah, yeah, I love having your cock inside me."
    new "بله، بله، عاشق هستم که پوسی تو رو داخل من داری"

    # say L1006 mo1
    old "Ohh yeah, just like this..."
    new "اوه بله، همینطور..."

    # say L1041 mo1
    old "Ahhh... Ahhh! I- I'm cumming!"
    new "آهه... آه! من- من در حال شیطون شدن هستم!"

    # say L1042 pla
    old "Ughhhh m- me too."
    new "اوه هم من هم."

    # say L1047 mo1
    old "Oh yes... It was really good."
    new "اوه بله... واقعاً خوب بود."

    # say L1048 mo1
    old "But I want more!"
    new "اما من می‌خواهم بیشتر!"

    # say L1067 mo1
    old "Ohhh God!"
    new "اوه خداوند!"

    # say L1068 mo1
    old "This is amazing!"
    new "این شگفت‌انگیز است!"

    # say L1073 mo1
    old "Uhh, I'll never get tired of this."
    new "اوه، هرگز از این خسته نمی‌شوم."

    # say L1074 mo1
    old "Mmmm, do you like your [mo1rel] riding you?"
    new "ممنن، آیا دوست داری ز[mo1rel]ت رو سوار کنی؟"

    # say L1075 pla
    old "Ohhh yes."
    new "اوه بله."

    # say L1080 mo1
    old "Yeah! Fuck me [pla], Fuck your [mo1rel]!"
    new "بله! زدنم [pla]، زد [mo1rel] تو!"

    # say L1081 mo1
    old "Ohhh my God!"
    new "اوه خدا!"

    # say L1107 mo1
    old "Mmmm, let me try something."
    new "ممم، بیایم چیزی امتحان کنیم."

    # say L1108 mo1
    old "I'm sure you will enjoy this."
    new "مطمئن هستم که این رو لذت می‌بری."

    # say L1116 mo1
    old "Uhhh this feels even better."
    new "اوه این حتی بهتر است."

    # say L1117 mo1
    old "Ohhh myy-"
    new "اوههه من-"

    # say L1122 mo1
    old "Mmmm, I learned this in college."
    new "ممم، این رو تو دانشگاه یاد گرفتم."

    # say L1123 mo1
    old "Do you like how I'm moving?"
    new "آه... مامان، حالتون رو دوست دارم؟"

    # say L1129 mo1
    old "Ahhh... Oh my God it feels so fucking goood!"
    new "اوه خدا، اینقدر خوب می‌تونه باشه!"

    # say L1130 mo1
    old "Yeah, yeah, I'm getting close!"
    new "بله، بله، من هم تقریباً رسیدم!"

    # say L1154 mo1
    old "Yeah yeah! Let's cum together!"
    new "بله بله! بیای با هم خروجی بگیریم!"

    # say L1156 mo1
    old "Yes, cum with mommy baby! Cum with me!"
    new "بله، با مامان خودت خروجی بگیر! با من خروجی بگیر!"

    # say L1160 mo1
    old "Holly shit, that was amazing!"
    new "هالی شیت، این خیلی عالی بود!"

    # say L1161 pla
    old "Pheww... Ohh yeah."
    new "پوف... اوه بله."

    # say L1176 mo1
    old "It's getting better and better!"
    new "این هر بار بهتر می‌شه!"

    # say L1177 mo1
    old "Ohh my God!"
    new "اوه خدا!"

    # say L1182 mo1
    old "It's so big! Oh God I feel it so deep!"
    new "این هم خیلی بزرگه! اوه خدا، اینقدر عمیق می‌کشیده!"

    # say L1183 mo1
    old "Oh yes, fuck me [pla], fuck me!"
    new "اوه بله، بگیرم [pla]، بگیرم!"

    # say L1188 mo1
    old "Oh yeah, faster, faster! Fuck me harder!"
    new "اوه بله، سریع‌تر، سریع‌تر! من رو سخت‌تر بفرک!"

    # say L1189 mo1
    old "Uhhh, yes, yes, fuck your mommy!"
    new "اوه، بله، بله، پسرم مامانتو بزن!"

    # say L1214 mo1
    old "Ohhhh m- my God! I'm cumming!"
    new "اوه خداوند! من در حال جیز کردن هستم!"

    # say L1215 pla
    old "Ughhh mee too!"
    new "اوه من هم!"

    # say L1220 mo1
    old "Wow it was a huge load"
    new "واو، اونقدر زیاد بود"

    # say L1221 mo1
    old "Mmmm, you cum all over me."
    new "ممن، تو همه روی من خروجی دادی."

    # say L1222 mo1
    old "Let's clean this up before someone comes."
    new "باید این رو پیش از اینکه کسی بیاد تمیز کنیم."


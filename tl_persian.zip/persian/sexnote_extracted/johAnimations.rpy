# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/johAnimations.rpy
translate persian strings:

    # say L6 joh
    old "Perfect, you are doing it so good, don't stop..."
    new "عالی، خیلی خوب انجام می‌دی، متوقف نشو..."

    # say L8 joh
    old "Please keep in mind the places where it's better to touch, where you can make your patient feel even more..."
    new "لطفاً به جای‌هایی که بهتر است لمس کنید توجه کنید، جایی که می‌توانید بیمارتان را حتی بیشتر حس کند..."

    # say L15 joh
    old "You are doing perfect, don't stop, it feels so good."
    new "تو خوبی، متوقف نشو، احساس خیلی خوبی می‌کنه."

    # say L16 pla
    old "Slurp... Slurp..."
    new "سلورپ... سلورپ..."

    # say L39 joh
    old "Ahh, I want you to do it faster!... Go as fast as you c- can."
    new "اوه، می‌خوام تو سریع‌تر کنی!... هر قدر زودتر بشه."

    # say L40 joh
    old "Yeah, Yeah, YEAH! keep moving... I- I am cuming! AHH!"
    new "بله، بله، بله! ادامه بده... من- من هستم که می‌آیم! آه!"

    # say L59 joh
    old "Please, just let me to enjoy your dick..."
    new "لطفاً، برام بگذار لذت ببرم از نیت تون..."

    # say L61 joh
    old "It's so hard... I just wanted to have it since I saw you fucking Angelina."
    new "اینقدر سخته... از زمانی که تو رو با آنجلینا می‌دیدم، فقط می‌خواستم اینو داشته باشم."

    # say L64 joh
    old "I want you to feel the tip of my tongue playing with the head of your dick..."
    new "می‌خوام احساس نوک زبانم رو که با سر ناخن تو بازی می‌کنه، برات برسونم..."

    # say L65 pla
    old "(Oh God...)"
    new "اوه خداوند..."

    # say L70 joh
    old "I'm really really wet right now... Do you like my mouth?"
    new "من الان واقعاً واقعاً مرطوب هستم... آیا دوست داری دهان من رو حس کنی؟"

    # say L71 pla
    old "Oh God, yes, it feels really good..."
    new "اوه خدا، بله، احساسش واقعاً خوبه..."

    # say L74 joh
    old "I need you to feel my mouth, to internalize the pleasure you are feeling, it's something you should handle. "
    new "من نیاز دارم احساس دهانم رو بکنی، لذتی که احساس می‌کنی رو درونی کنی، این چیزی هست که باید مدیریت کنی."

    # say L80 joh
    old "Who do you prefer to suck your cock?  Me... Slurp... Or... Slurp... Angelina?"
    new "کی رو ترجیح میدی که خروت رو شیر کنه؟ من... لک... یا... لک... آنژلینا؟"

    # say L82 joh
    old "Are you really considering it?"
    new "آیا واقعاً در حال بررسی این موضوع هستید؟"

    # say L85 joh
    old "Can you feel my tongue? Do you feel how wet it is now, feel the tip playing with your dick's head..."
    new "می‌تونی زبانم رو حس کنی؟ می‌تونی اون مرطوبی رو که الان داره روی سر ناخنات بازی می‌کنه حس کنی؟"

    # say L86 pla
    old "Yes, I- I can."
    new "بله، من- من می‌تونم."

    # say L106 joh
    old "I'm gonna show you WHO is the MASTER..."
    new "من قرار هست بهت نشون بدم که کی ماستر هست..."

    # say L110 joh
    old "I'm going to do it with all I have, so be ready."
    new "من همه توانم رو به کار می‌برم، پس آماده باش."

    # say L129 joh
    old "This is how a master do it..."
    new "این همین جوری که یک استاد انجام می‌دهد..."

    # say L130 pla
    old "Uhhh..."
    new "اوه..."

    # say L133 joh
    old "Stay focused, you can't cum."
    new "مرکز بمان، نمی‌تونی خروج کنی."

    # say L134 pla
    old "I won't."
    new "من نخواهم."

    # say L135 joh
    old "I hope so!"
    new "امیدوارم!"

    # say L139 joh
    old "So? What do you think now? Who is better?"
    new "پس؟ حالا چه فکری داری؟ کی بهتر است؟"

    # say L140 pla
    old "Ahh... Y- you... You are better..."
    new "اوه... ش- شما... شما بهتر هستید..."

    # say L141 joh
    old "That's what I wanted to ear..."
    new "این همینه که می‌خواستم بشنوم..."

    # say L144 joh
    old "I will speed up a bit, I know you will enjoy it."
    new "من کمی سرعت می‌افزایم، میدونم خوشت می‌آید."

    # say L152 joh
    old "I'm going to make you cum NOW!"
    new "من الان قصد دارم تو رو به عجولی برسونم!"

    # say L154 joh
    old "You are doing it better than I expected... But you can't against my full speed."
    new "شما این کار رو بهتر از آنچه انتظار داشتم انجام میدید... اما نمی‌تونید با سرعت کامل من مقایسه کنید."

    # say L157 pla
    old "AHH!"
    new "اوه!"

    # say L186 pla
    old "I- I think I'm going to-"
    new "من- من فکر می‌کنم خواهم-"

    # say L187 joh
    old "Oh, please let it go, spill it over my mouth..."
    new "لطفاً، بیا، بریز همه‌اش توی دهانم..."

    # say L188 pla
    old "A- are you sure?"
    new "آ- آیا مطمئنی؟"

    # say L189 joh
    old "Yess, I want to feel all you cum in my mouth, give it all to me!"
    new "بله، می‌خوام همه آب تو رو تو دهانم بیاد، همه‌ش رو به من بده!"

    # say L200 joh
    old "Definetly, I need to ride this cock, I want it all inside me, lie on the bed I need you to fuck me!"
    new "حتماً، من باید این ناخن را سوار کنم، می‌خواهم همه‌اش داخل من باشد، روی تخت بخه، باید تو را بفراموش کنم!"

    # say L202 joh
    old "I don't want any kids game, fuck me really HARD!"
    new "من نمی‌خوام بازی کودک باشه، من رو واقعاً سخت بکن!"

    # say L203 pla
    old "A- alright."
    new "ا- خوب."

    # say L219 joh
    old "Listen carefully, I want you to keep a regular rythm, and also an uniform strength..."
    new "دقت کن، می‌خوام حرکاتت منظم باشه و همچنین قدرتت یکسان باشه..."

    # say L220 joh
    old "You need to plan your movements, your energy, I will tell when you can do it faster."
    new "شما باید حرکات و انرژی خود را برنامه‌ریزی کنید، من به شما می‌گم وقتی می‌تونید سریع‌تر انجام بدی."

    # say L225 joh
    old "Ahh... I like it, keep it like that..."
    new "اوه... خوشحالم، همینطور ادامه بده..."

    # say L228 joh
    old "Oh, now faster, I'm very wet, do it harder."
    new "اوه، حالا سریع‌تر، خیلی مرطوب شده‌ام، سخت‌تر انجام بده."

    # say L229 pla
    old "O- ok."
    new "ب- بخایی."

    # say L249 joh
    old "POUND ME HARDER!"
    new "من رو سخت‌تر بزن!"

    # say L250 pla
    old "Huh..."
    new "اوه..."

    # say L271 joh
    old "Ahh, do it as hard as you have to, I want you to smash my pussy"
    new "اوه، هر قدر خواستی سخت انجام بده، می‌خوام پوسی‌ام رو شکن بزنی"

    # say L273 joh
    old "Oh yeah, don't stop, don't stop!"
    new "اوه بله، متوقف نشو، متوقف نشو!"

    # say L276 joh
    old "Show me how powerful your dick is, I want you to make cum!"
    new "به من نشون بده چقدر ناخودت قویه، می‌خوام از تو بیایم!"

    # say L278 pla
    old "Ughh... "
    new "اوه..."

    # say L307 joh
    old "Oh God! I'm cumming!! Ahhh! Ahhhh!"
    new "اوه خداوند! من در حال بیایم!! آهه! آهه!"

    # say L325 joh
    old "Yes, just like this baby..."
    new "بله، دقیقاً همینطور عزیزم..."

    # say L326 pla
    old "Gulp..."
    new "گلپ..."

    # say L330 joh
    old "Ahh! Your dick is so good..."
    new "اوه! ناخودآگاهی تو خیلی خوبه..."

    # say L331 pla
    old "Ah!"
    new "آه!"

    # say L332 joh
    old "SO GOOD!!!"
    new "خیلی خوب!!!"

    # say L335 joh
    old "Ohh yeahh, it's so big!"
    new "اوه بله، خیلی بزرگه!"

    # say L336 pla
    old "AH!"
    new "آه!"

    # say L337 joh
    old "HARDER, HARDER!"
    new "سخت‌تر، سخت‌تر!"

    # say L362 joh
    old "I'm gonna cum!!!"
    new "من الان می‌آیم!!!"

    # say L364 joh
    old "Let's cum together, DON'T STOP, DON'T STOP... AHHH!"
    new "بیایم هم‌همه، نesta توقف نکن، نesta توقف نکن... آه!"

    # say L365 pla
    old "Mmmm!! I- I'm coming..."
    new "ممنون!! من- من هم می‌آیم..."

    # say L371 joh
    old "Wow..."
    new "واو..."

    # say L383 joh
    old "Oh yeah, I'm going to show you how an expert fucks!"
    new "بله، من بهت نشون می‌دم که یه متخصص چطور می‌ریزه!"

    # say L384 pla
    old "Ughh, It feels amazing..."
    new "اوه، این حس واقعاً شگفت‌انگیز است..."

    # say L387 joh
    old "Mmmm... Riding you drives me crazy!"
    new "ممنون... سوار شدن بر تو من رو دیوانه می‌کنه!"

    # say L388 pla
    old "Oh yess... Please don't stop it... Ahh!"
    new "اوه بله... لطفاً متوقف نشو... آه!"

    # say L389 joh
    old "Yeah, you like it? Then I'm gonna fuck you harder!"
    new "بله، خوشت می‌آید؟ پس من شما رو سخت‌تر می‌بوم!"

    # say L393 joh
    old "Uhhh... You have really huge cock! I can't fit it all in my pussy."
    new "اوه... شما واقعاً پوسی بزرگی داری! نمی‌توانم همه‌اش رو توی مونیم جای دهم."

    # say L394 joh
    old "Fuck me! Fuck me! I want you to fill my cunt of cum."
    new "بگردم! بگردم! می‌خوام اسپرمتو توی میمه من پر کنی."

    # say L419 joh
    old "Yeeeeesss... Yesss... I- I'm cumming!!"
    new "آاااه... آااه... من- من می‌آیم!!"

    # say L420 pla
    old "Ahhhhh... Ughhh..."
    new "ااااا... اوه اوه..."

    # say L426 joh
    old "Ohh, yes, I feel it inside, that's delicious."
    new "اوه، بله، اونجور حس می‌کنم، این خوشمزه است."

    # say L427 joh
    old "Don't even think about stopping... I need more of your cock NOW!"
    new "حتی فکر هم برای متوقف شدن نکن... من الان نیاز دارم از ناخن تو بیشتر لذت ببرم."

    # say L442 joh
    old "Now softly... I wanna feel all your big cook..."
    new "الان به آرامی... می‌خوام همه ی کوک بزرگت رو حس کنم..."

    # say L443 joh
    old "Ohh yeahh... Just like that baby..."
    new "اوه آره... همینطور بچه..."

    # say L447 joh
    old "Do you like my big boobs? How do they bounce when you fuck me?"
    new "آیا از سینه‌های بزرگ من لذت می‌بری؟ وقتی تو مرا می‌پردازی، چطور می‌پریندند؟"

    # say L448 pla
    old "Yes, I love your tits!"
    new "بله، عاشق پستان‌ت هستم!"

    # say L449 joh
    old "Then, fuck me faster, with that huge cock!"
    new "پس، سریع‌تر باهام بپیچونی، با اون لوله بزرگت!"

    # say L453 joh
    old "Harder! Fuck me harder! I want you to make me cum as you did with Angelina!"
    new "سخت‌تر! من خواستم تو سخت‌تر باهام بپیچونی! می‌خوام تو باهام مثل آنجلینا بپیچونی تا من برسوم!"

    # say L455 joh
    old "OH GOD... I'M GONNA FUCK YOU EVERYDAY..."
    new "اوه خداوند... من هر روز تو رو می‌پیچم..."

    # say L479 pla
    old "I- I going to..."
    new "من- من می‌روم..."

    # say L480 joh
    old "Yes! Cum inside me!"
    new "بله! درون من بیای!"


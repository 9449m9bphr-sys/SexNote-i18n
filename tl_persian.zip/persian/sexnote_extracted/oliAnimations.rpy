# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/oliAnimations.rpy
translate persian strings:

    # say L6 aye
    old "Oh yeah, sis! Woohoo!"
    new "اوه بله، خواهر! وایی!"

    # say L7 aye
    old "I can tell how good you are at this!"
    new "می‌تونم ببینم چقدر خوبی تو این کار!"

    # say L8 aye
    old "Look at that huge cock filling your mouth!"
    new "ببین اون نیم‌پا رو تو دهانت پر می‌شه!"

    # say L12 aye
    old "I know you like it, sis!"
    new "میدونم دوستت داری، خواهر!"

    # say L13 aye
    old "With how big his cock is, I'd say you chose well!"
    new "با اون حجم شاخ، می‌تونم بگم انت خوب انتخاب کردی!"

    # say L14 aye
    old "Look at you go to town on that monster cock!"
    new "ببین چطور تو روی اون نیم‌پا کار می‌کنی!"

    # say L18 aye
    old "How about you, brother-in-law? Do you like it?"
    new "برایت چطوره، شوهر برادرم؟ می‌پسندی؟"

    # say L19 aye
    old "Come on, tell me! Don't leave me hanging!"
    new "بیا، بگو! نه بگذار من منتظر بمونم!"

    # say L20 oli
    old "Slrrp, j- just answer her!"
    new "سلرپ، ج- جواب بده بهش!"

    # say L22 aye
    old "Haha! Oh yeah!"
    new "هahaha! اوه بله!"

    # say L45 pla
    old "O- Olivia! I- I'm about to cum!"
    new "ا- اولیویا! من- من در حال خروج هستم!"

    # say L46 aye
    old "Yeah! Cum in her mouth! Come on!"
    new "بله! تو روی دهانش بیا! برو!"

    # say L47 aye
    old "I want to see that!"
    new "من می‌خوام ببینم!"

    # say L48 oli
    old "I- it's alright, just let it out!"
    new "اون- خوبه، فقط بیرون بیا!"

    # say L55 aye
    old "Oh my gosh look at how much you came!"
    new "اوه خدا، نگاه کن چقدر آمدی!"

    # say L56 aye
    old "That's amazing!"
    new "این واقعاً شگفت‌انگیز است!"

    # say L57 aye
    old "I have to say, sis, this guy may not look like much."
    new "باید بگم، خواهر، این جون به نظر خوب نمی‌آید."

    # say L58 aye
    old "But he is certainly well gifted."
    new "اما قطعاً هدیه‌های خوبی داره."

    # say L59 oli
    old "Oh shut up, just let me clean up and leave us alone."
    new "بسته شو، بیا برامون تمیز شو و برو."

    # say L71 oli
    old "Oh, wow... Your cock is getting even harder..."
    new "اوه، وای… ناخن تو حتی سخت‌تر می‌شه…"

    # say L72 oli
    old "It feels soft and warm though."
    new "البته نرم و گرم هست."

    # say L73 oli
    old "Does my hand feel good?"
    new "دست من خوب می‌آید؟"

    # say L74 pla
    old "Yes, it feels really nice..."
    new "بله، خیلی خوب می‌باشد..."

    # say L78 oli
    old "To be honest, it's the biggest I've ever seen..."
    new "صuschت، بزرگ‌ترین چیزی هست که تا حالا دیدم..."

    # say L80 oli
    old "I mean, it's pretty impresive..."
    new "من قصدم اینه، خیلی شگفت‌انگیز است..."

    # say L83 oli
    old "I'll do it a little faster..."
    new "می‌تونم یه کم سریع‌تر بکنم..."

    # say L84 oli
    old "Is that okay?"
    new "این جوری خوبه؟"

    # say L85 pla
    old "Uhh, s- sure..."
    new "اوه، ب-bالا..."

    # say L110 oli
    old "Ok, I think that's enough... I don't want you to waste your cum..."
    new "خب، فکر کنم کافیه... نمی‌خوام اسپرمتو بی‌فایده بشه..."

    # say L111 oli
    old "I mean, I need your sperm, you know the idea is to get pregnant..."
    new "من قصد دارم از اسپرمتویت استفاده کنم، می‌دونی هدف بارداری هست..."

    # say L112 pla
    old "Uhh, yeah, you're right..."
    new "اوه، بله، درست می‌گی‌ی..."

    # say L113 oli
    old "Alright, I'm going to take off my pants and get on the edge of the bed. I guess you know what to do..."
    new "البته، من پانتالونم رو می‌برم و روی لبه تخت می‌نشم. فکر کنم می‌دونی باید چی کنی..."

    # say L119 pla
    old "Uhh, yeah, of course..."
    new "اوه، بله، البته..."

    # say L136 oli
    old "Uhh, your cock is so big, so, I'm going to ask you to please be gentle..."
    new "اوه، ناخواسته تو خیلی بزرگه، پس می‌خوام ازت بخواهم لطفاً نرم باشی..."

    # say L137 pla
    old "Ohh, s- sure, don't worry."
    new "اوه، ح- حتماً، نگران نباش."

    # say L142 oli
    old "Hngh! Oh God!"
    new "هانگ! اوه خدا!"

    # say L143 oli
    old "It's even bigger than I thought!"
    new "بزرگتر از آنچه فکر می‌کردم!"

    # say L144 pla
    old "A- are you alright?"
    new "ا- حالت خوبه؟"

    # say L145 oli
    old "Y- yes, don't worry, don't stop..."
    new "بله، نگران نباش، ادامه بده..."

    # say L148 oli
    old "Come on, do it a little faster, I want you to cum inside me..."
    new "بیا، یک کم سریع‌تر انجام بده، می‌خوام تو داخل من بیاد..."

    # say L150 oli
    old "Mmm, it feels so deep... I've never felt anything like this before..."
    new "ممن، این هم خیلی عمیق می‌رسه... هیچ وقت چیزی مثل این نداشتم..."

    # say L151 oli
    old "Uhh... T- this is so good!"
    new "اوه... این خیلی خوبه!"

    # say L152 pla
    old "Ughh... Yes..."
    new "آه... بله..."

    # say L175 oli
    old "[pla] I- I'm about to finish!"
    new "[pla] من هم خیلی زود می‌رسم!"

    # say L176 pla
    old "M- me too! I'm about to cum!"
    new "M- من هم! من هم خیلی زود می‌روم!"

    # say L177 oli
    old "Y- yes! Yes! Cum inside me!"
    new "B- بله! بله! درون من بیا!"

    # say L183 oli
    old "W- woah!"
    new "و- وای!"

    # say L184 oli
    old "I- I wasn't expecting it to be that way."
    new "من- من منتظر نبودم اینجوری باشه."

    # say L185 oli
    old "I was a lot better than I thought!"
    new "من خیلی بهتر از آنچه فکر می‌کردم بود!"

    # say L186 oli
    old "Did you like it too [pla]?"
    new "تو هم لذت برده بودی [pla]؟"

    # say L187 pla
    old "Yeah, it was great."
    new "بله، خیلی خوب بود."

    # say L188 oli
    old "Alright, awesome!"
    new "البته، عالی بود!"

    # say L189 oli
    old "Now, let's get cleaned before my mom comes back and sees us."
    new "الان، باید پاک شیم قبل از اینکه مامان برگرده و ما رو ببینه."

    # say L201 oli
    old "Ohhh, yeah, I've missed this feeling..."
    new "اوه، بله، این حس رو خیلی دوست داشتم..."

    # say L202 bri
    old "[pla]! She's really liking this!"
    new "[pla]! وای، اونجور لذت می‌بره!"

    # say L203 bri
    old "I can see her emotions, she wants to get pregnant very badly!"
    new "من احساساتش رو می‌بینم، خیلی می‌خواد بچه بداره!"

    # say L207 oli
    old "Oh my God! Your cock is so big!"
    new "اوه خداوند! ناخن تو خیلی بزرگه!"

    # say L209 oli
    old "Yeah, yeah, just don't stop!"
    new "بله، بله، فقط متوقف نشو!"

    # say L212 oli
    old "Oh God yes!"
    new "اوه خداوند، بله!"

    # say L213 oli
    old "F- fuck me harder! Harder"
    new "بیا سخت‌تر! سخت‌تر"

    # say L215 oli
    old "Mmm... I love this!"
    new "ممنون... عاشق اینم!"

    # say L238 pla
    old "O- Olivia! I think I'm about to cum!"
    new "O- اولیویا! فکر کنم دارم می‌آیم!"

    # say L239 oli
    old "Y- yeah! D- do it!"
    new "B- بله! بکن!"

    # say L240 oli
    old "Fill me up with your cum!"
    new "مرا با سیالتو پر کن!"

    # say L241 oli
    old "Get me pregnant!"
    new "من رو باردار کن!"

    # say L247 oli
    old "God! That was fantastic [pla]!"
    new "الهی! این خیلی عالی بود [pla]!"

    # say L248 oli
    old "I can't believe how good it was!"
    new "باورم نمی‌شه چقدر خوب بود!"

    # say L249 oli
    old "I'm sure this time I'll be pregnant for real."
    new "حتماً این بار واقعاً باردار می‌شوم."

    # say L250 pla
    old "I hope so..."
    new "امیدوارم همین‌طور باشه..."

    # say L251 oli
    old "Alright, let's get up and get cleaned before my family comes back."
    new "بیای، بلند شو و قبل از برگشت خانواده‌ام تمیز شویم."

    # say L263 oli
    old "Ah! ah! I'm loving it!"
    new "آه! آه! عاشق این هستم!"

    # say L264 oli
    old "I've missed your dick so much [pla]!"
    new "اوه، نوزد تو رو خیلی دوست دارم [pla]!"

    # say L265 oli
    old "There's just nothing like it!"
    new "هیچ چیز مثل این نیست!"

    # say L269 oli
    old "D- do you like it [pla]?"
    new "د- دوست داری [pla]؟"

    # say L270 oli
    old "How it feels?"
    new "حاسه چطوره؟"

    # say L275 oli
    old "Oh god yes this is just what I've been missing!"
    new "اللهی بله، این دقیقاً همان چیزیه که از دست داده بودم!"

    # say L276 oli
    old "I can already start to feel myself getting better!"
    new "الی: قطعاً می‌تونم حس کنم که بهتر می‌شوم!"

    # say L277 oli
    old "This is unbelievable!"
    new "این واقعاً باورنکردنی است!"

    # say L300 oli
    old "Oh [pla]! I'm about to cum!"
    new "اوه ز[pla]! من در حال رسیدن به علیه‌ام هستم!"

    # say L302 oli
    old "G- great! Let's do it together!"
    new "عالی! بیایم همینجوری با هم!"

    # say L309 oli
    old "Oh God! That was so great!"
    new "اوه خدا! این هم خیلی خوب بود!"

    # say L310 oli
    old "I can't believe how good it felt [pla]!"
    new "نمی‌تونم باور کنم چقدر خوب بود [pla]!"

    # say L311 oli
    old "I think that's just what I needed!"
    new "فکر کنم این همون چیزی بود که بهش نیاز داشتم!"

    # say L312 pla
    old "I- I'm glad it helped you."
    new "من خوشحالم که به تو کمک کرد."

    # say L313 oli
    old "Did you like it too?"
    new "تو هم لذت برده بودی؟"

    # say L314 pla
    old "Oh yeah, it was very good."
    new "آره، خیلی خوب بود."

    # say L315 pla
    old "Now, how about we get up before your Mom comes back."
    new "الان، بیای بپردیم قبل از اینکه مامانت برگرده."

    # say L316 oli
    old "Sure!"
    new "بله!"

    # say L328 oli
    old "Oh god! Yes! Yes!"
    new "اوه خدا! بله! بله!"

    # say L329 oli
    old "Oh yes daddy! Fuck me just like that!"
    new "اوه بله پاپا! همینطور با من بکن!"

    # say L330 oli
    old "This is so amazing [pla]!"
    new "این خیلی عالیه [pla]!"

    # say L334 bri
    old "That's it [pla]!"
    new "بزن ادامه بده [pla]!"

    # say L336 bri
    old "Keep going! That's just what's needed for the spell!"
    new "ادامه بده! این همینه که برای جادو لازم هست!"

    # say L340 oli
    old "Oh God [pla]!"
    new "اوه خدا [pla]!"

    # say L341 oli
    old "Y- you're making me go insane!"
    new "د- داری منو دیوانه می‌کنی!"

    # say L342 oli
    old "This is so great!"
    new "این خیلی عالیه!"

    # say L367 oli
    old "Oh fuck yes! I want you to fill me up!"
    new "اوه بله! می‌خوام تو مرا پر کنی!"

    # say L369 bri
    old "You've already extracted the magic power! Let yourself go!"
    new "تو قدرت جادویی رو استخراج کردی! خودت رو رها کن!"

    # say L375 bri
    old "That was awesome [pla]!"
    new "این خیلی عالی بود [pla]!"

    # say L376 bri
    old "Just what we needed to end the ritual!"
    new "این همینه که برای پایان دادن به مراسم لازم بود!"

    # say L377 oli
    old "Oh God [pla] that felt so good!"
    new "اوه خدا ز[pla] این خیلی خوب بود!"

    # say L389 oli
    old "Oh god [pla]! The taste of your dick!"
    new "اوه خدا ز[pla]! طعم ناخن تو!"

    # say L390 oli
    old "This is such an amazing dick!"
    new "این ناخن واقعاً عالیه!"

    # say L391 oli
    old "It never disappoints me!"
    new "همیشه من را شگفت‌زده می‌کنی!"

    # say L397 oli
    old "I just love feeling it in my mouth!"
    new "من فقط دوست دارم احساسش رو توی دهانم کنم!"

    # say L401 oli
    old "I love it [pla]!"
    new "من عاشقش هستم [pla]!"

    # say L402 oli
    old "I love this dick!"
    new "من این ناخن را دوست دارم! ⇒ من این ناخن رو دوست دارم!"

    # say L403 oli
    old "I love it's taste and smell!"
    new "من عاشق طعم و بویش هستم!"

    # say L426 pla
    old "O- Olivia! I- ugh! I can't hold it in anymore!"
    new "ا- اولیویا! من- اوه! دیگه نمی‌تونم خودمو کنترل کنم!"

    # say L427 oli
    old "That's alright! I don't want you to!"
    new "باشه! من نمی‌خوام تو خودت رو کنترل کنی!"

    # say L428 oli
    old "You don't need to hold it in!"
    new "تو نباید خودت رو کنترل کنی!"

    # say L429 oli
    old "Let go and fill my mouth with your hot cum!"
    new "بیا و با گرما تو دهانم رو با خودت پر کن!"

    # say L436 oli
    old "Mmm! That's an amazing taste [pla]!"
    new "ممنن! این طعم عالیه [pla]!"

    # say L437 oli
    old "This is just wonderful!"
    new "این فقط عالیه!"

    # say L439 pla
    old "I- I'm glad you like it."
    new "خوشحالم که لذت برده‌ای."

    # say L440 oli
    old "Oh yeah, I love it!"
    new "اوه بله، عاشقش شدم!"

    # say L441 oli
    old "Now, I think we should get clean before my mom comes back and finds us like this."
    new "الان فکر می‌کنم باید پاک شویم قبل از اینکه مامان برگرده و ما رو اینجور ببینه."

    # say L442 pla
    old "Sure, sure!"
    new "بله، البته!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/LadStory.rpy
translate persian strings:

    # say L11 mo1
    old "Good morning honey."
    new "صبح بخیر عزیزم"

    # say L12 pla
    old "Oh! good morning [mo1rel]."
    new "اوه! صبح بخیر [mo1rel]."

    # say L13 mo1
    old "Did you have a good night?"
    new "شب خوبی داشتی؟"

    # say L14 pla
    old "Yeah, I did. And you?"
    new "بله، من هم خوب بودم. تو چطور بودی؟"

    # say L16 mo1
    old "I did hun, thank you."
    new "من هم خوب بودم، ممنون عزیزم."

    # say L17 pla
    old "Is there anything I can help you with [mo1rel]?"
    new "آیا چیزی هست که بتونم به تو کمک کنم [mo1rel]؟"

    # say L18 mo1
    old "Well, not really. I just wanted to see if you're doing anything with your friends for halloween."
    new "خیر، واقعاً نه. فقط می‌خواستم ببینم آیا برای هالووین با دوستانت کاری داری."

    # say L20 pla
    old "Oh that's right! It's today! I'd totally forgotten about it."
    new "اوه درسته! امروز هست! کاملاً فراموش کرده بودم."

    # say L21 pla
    old "That reminds me, I need to pick up my costume."
    new "این به من یادآور شد، باید لباس هالووینم رو برم بیاورد."

    # say L23 mo1
    old "Are you going to school in a costume?"
    new "تو قصد داری با لباس هالووین به مدرسه بری؟"

    # say L24 pla
    old "Yeah, me and my friends are dressing up for Halloween."
    new "بله، من و دوست‌هامون برای هالووین لباس‌ها رو گذاشته‌ایم."

    # say L25 mo1
    old "Really? Why? Are you having a party?"
    new "وای، چرا؟ همینجوری جشنی دارید؟"

    # say L26 pla
    old "No, no, nothing special like that. It's just that the school principal said all students get to wear costumes today."
    new "نه، نه، هیچ چیز خاصی نیست. فقط اینکه رئیس مدرسه گفت همه دانش‌آموزان می‌تونن امروز لباس‌های نمایشی بپوشن."

    # say L27 mo1
    old "Seriously? That's cool."
    new "وای، خوبه."

    # say L28 pla
    old "Yeah, it's nice we get to do this once in a while. Everyone's excited about it."
    new "بله، خوشحالم که گاهی اوقات بتونیم این کار رو بکنیم. همه خوشحال هستند."

    # say L29 mo1
    old "Well [pla], that sounds like a lot of fun. I'm happy you get to do that with your friends."
    new "خب [pla]، این به نظر می‌رسه خیلی خوشحالم که تو بتونی اینجوری با دوستات وقت بگذونی."

    # say L30 mo1
    old "After all, this is your last Halloween at school, where you still get to dress up, so make sure to enjoy it."
    new "البته، این آخرین هالووین توی مدرسه‌ت هست، جایی که هنوز می‌تونی لباس‌های خودت رو بپوشی، پس حتماً ازش لذت ببر."

    # say L31 pla
    old "Yeah, I'll do. We're competing about who has the worst costume."
    new "بله، انجام میدم. ما در مورد کی لباس بدتری داره رقابت می‌کنیم."

    # say L32 mo1
    old "And do you have one already?"
    new "و قطعیتی داری؟"

    # say L33 pla
    old "Yeah, I asked Kylee to get one for me. I should ask her if it's already arrived. Bye [mo1rel], see you later."
    new "بله، از کایلی پرسیدم تا یکی برایم بیاره. باید بپرسم آیا قبلاً رسیده. بای [mo1rel]، بعداً می‌بینیم."

    # say L34 mo1
    old "Bye honey, have a good day."
    new "بای عزیزم، روز خوبی داشته باش."

    # say L52 pla
    old "Hi [sis], good morning."
    new "سلام ز[sis]، صبح خوب."

    # say L53 sis
    old "Hi [pla], good morning. How are you?"
    new "سلام ز[pla]، صبح بخیر. چطوری؟"

    # say L54 pla
    old "I'm fine. Hey, I just remembered I asked you to get my costume for Halloween. Did it arrive?"
    new "من خوبم. سلام، همین جا به یاد آوردم که ازت پوشاک هالووینم رو پرسیدم. رسیده؟"

    # say L55 sis
    old "Yeah, it did. It came in with the last shipment of clothing for the store."
    new "بله، رسید. با آخرین محموله لباس‌های فروشگاه آمد."

    # say L57 pla
    old "Great! Where is it?"
    new "عالی! جایش کجاست؟"

    # say L59 sis
    old "Hmm... I haven't unpacked anything yet, so it must be in one of the boxes."
    new "همم... هنوز هیچ چیزی را باز نکردم، پس باید در یکی از جعبه‌ها باشد."

    # say L60 sis
    old "Just wait here a minute. I'll go get it for you."
    new "بیا اینجا صبر کن یه لحظه. من برایت می‌آورم."

    # say L72 sis
    old "Here you go."
    new "بفرمایید."

    # say L75 pla
    old "This is great! Thanks [sis]."
    new "عالیه! ممنون [sis]."

    # say L76 sis
    old "Well, you go try it on and let me know if it fits you, and you like it."
    new "ببین اگه مناسب تو باشه و خوشت بیاد، برو امتحانش کن."

    # say L77 pla
    old "Of course, by the way, how much do I owe you?"
    new "البته، باید هم بگم، چقدر به من بدهی؟"

    # say L78 sis
    old "Oh, don't worry about it..."
    new "اوه، نگرانش نباش..."

    # say L79 sis
    old "It's on the house."
    new "به تو رایگان است."

    # say L80 pla
    old "Oh really? Well... Thank you [sis]."
    new "اوه واقعاً؟ خب... ممنون [sis]."

    # say L82 sis
    old "Now leave, I have a lot of work to do."
    new "حالا برو، کار زیادی دارم."

    # say L83 pla
    old "Ok, I'll go try on the costume then. See you later [sis], thanks again."
    new "باشه، من می‌روم لباس را امتحان می‌کنم. بعداً می‌بینیم [sis]، ممنون دوباره."

    # say L84 sis
    old "You're welcome and enjoy it."
    new "خواهش می‌کنم و لذت ببر ازش."

    # say L102 pla
    old "Wow! This is so cool! [sis] has some really good products."
    new "واو! این خیلی عالیه! ز[sis] واقعاً محصولات خوبی داره."

    # say L103 pla
    old "I think I'll definitely blow their minds with this."
    new "فکر کنم حتماً ذهن‌شون رو برگردانم با این."

    # say L104 pla
    old "Now I'm ready for Halloween!"
    new "الان آماده‌ام برای هالووین!"

    # say L127 pla
    old "Hey guys, what 's up?"
    new "سلام جون‌ها، چطوری؟"

    # say L129 bel
    old "Whooa [pla]! What a costume!"
    new "وای ز[pla]! لباس پوشیدی عالیه!"

    # say L130 pla
    old "Cool, isn't it?"
    new "خوبه، نه؟"

    # say L131 bel
    old "It looks very good."
    new "حالت خوبه."

    # say L132 mik
    old "Yeah dude, really cool."
    new "بله داداش، واقعاً خوبه."

    # say L134 mik
    old "But to be honest, not as cool as mine."
    new "ولی صادقانه بگم، نه مثل من."

    # say L135 bel
    old "Really? And why is that?"
    new "وای، چرا همینجوری؟"

    # say L136 mik
    old "Because I'm Iron Man, I mean... Come on!"
    new "چون من آهن‌آرما هستم، منظورم... بیا!"

    # say L137 mik
    old "I'm the super rich, genius, chick magnet! No way Spiderman beats that."
    new "من خیلی ثروتمند، نابغه و مغناطیس دختران هستم! حتماً اسپایدرمن نمی‌تونه با این مقایسه شه."

    # say L139 pla
    old "It actually is a cool Iron Man costume... Even the goatee."
    new "این واقعاً لباس خوبی از آهنگر هست... حتی ریش هم داره."

    # say L141 bel
    old "Hmph, I guess."
    new "همف، حدس می‌زنم."

    # say L143 mik
    old "And you Belle? Are you like a type of rabbit?"
    new "و تو بله؟ یه نوع خرگوشی هستی؟"

    # say L144 bel
    old "Not a type of rabbit. I'm a bunny, the coolest one, Lola Bunny!"
    new "من نوع خرگوش نیستم. من خرگوش هستم، خنده‌دارترین، لولا خرگوش!"

    # say L145 pla
    old "Ohh right. I get it now."
    new "اوه درسته. حالا فهمیدم."

    # say L146 pla
    old "Cool costume, it looks really good on you."
    new "لباست خوبه، روی تو خیلی خوب می‌نشینه."

    # say L160 rub
    old "Oh my, Olivia, would you look at that? The loser club in their dumb costumes. Aren't they childish?"
    new "اوه، اولیویا، ببین! بازیکنان باشکوه خودشون رو با لباس‌های احمقانه‌شون نشون می‌دن. آیا نمی‌شن که مثل بچه‌ها هستن؟"

    # say L161 oli
    old "Yeah, always acting like little kids. Dumb, poor kids."
    new "بله، همیشه مثل بچه‌های کوچک رفتار می‌کنن. بچه‌های خرده، بچه‌های فقیر."

    # say L162 bel
    old "Don't you two airheads have anything better to do this early in the morning?"
    new "دوقلوی خر، این وقت زود رویش هیچ کار بهتری ندارید؟"

    # say L163 rub
    old "Better than showing you just how much of a dumbass you are? Don't think so."
    new "بهتر از اینکه نشون بدی چقدر احمقی هستی؟ فکر نکنم."

    # say L164 rub
    old "By the way, are you supposed to be Lola Bunny?"
    new "باید بگم، آیا قراره تو لولا بانی باشی؟"

    # say L165 bel
    old "Y-yeah, I am. Why?"
    new "بله، من هستم. چرا؟"

    # say L166 rub
    old "Dear, you should realize that with those ears, and that pig nose of yours, you're much more of a Piglet."
    new "حبیبی، باید متوجه باشی که با آن گوش‌هایت و آن بینی خوکی‌ات، بیشتر شبیه پیپلی هستی."

    # say L167 pla
    old "Hey! Don't you think that's too much?"
    new "هی! آیا فکر می‌کنی این کمی زیاده؟"

    # say L168 mik
    old "That's right. Shut up!"
    new "درست می‌فرمایید. بس کن!"

    # say L169 rub
    old "Wow Olivia, look who's defending Piglet! Spiderman the scrawny loser, and Iron fat."
    new "وای اولیویا، نگاه کن به کسی که پیگلت رو دفاع می‌کنه! اسپیدرمن خردلرز و آهن‌بازو چرب."

    # say L170 oli
    old "What's funny is that they're opposites. One is too slim to fill his Spiderman pajamas, and the other's too fat to fit into the costume."
    new "می‌تونی باور کنی که اونا مخالف هستن. یه‌تا خیلی نازکه برای پوشیدن لباس اسپایدرمن، و دیگه‌ی خیلی چربه برای پوشیدن لباس آهنین."

    # say L171 rub
    old "Hey Iron Man, don't you think it's ridiculous that your belly's rounder than your chest?"
    new "ایرون من، آیا نمی‌فکری که خنده‌داره شکمتو گردتر از سیناتوه؟"

    # say L172 oli
    old "Maybe we should call him barrel man."
    new "شاید باید اون رو مرد بشکه بگم."

    # say L179 hin
    old "Hey guys! What's up? It's everything ok?"
    new "سلام دخترها! چطور هستید؟ همه خوب هست؟"

    # say L183 oli
    old "Ohh wow. What a costume..."
    new "اوه وای. چه لباسی..."

    # say L184 rub
    old "My god! And what the hell are you wearing? You look like a WHORE."
    new "اللهی! و تو چه لباسی پوشونده‌ای؟ مثل یه زن‌بازی می‌تونی."

    # say L185 oli
    old "The stupid cow came dressed up like a bat-whore."
    new "این گاو خرده با لباسی مثل شور و بات آمده."

    # say L187 hin
    old "Hey! It's not a whore costume. I'm Morrigan from Darkstalkers. And for your information this took a lot of time to make..."
    new "هی! این لباس مسخره نیست. من موریگان از دارک استالکر هستم. و برای اطلاعاتت بگم این خیلی وقت برای ساختنش گذاشتم..."

    # say L188 rub
    old "Ughh nerd... I don't care..."
    new "اوه نرد... من نمی‌خوام..."

    # say L189 rub
    old "I am only surprised that the shy moron I see here every day would bring such a revealing costume."
    new "من فقط تعجب می‌کنم که آن بی‌پناه خجول که هر روز اینجا می‌بینم، لباسی اینقدر آشکار آورد."

    # say L190 oli
    old "Which by the way, it's disgusting."
    new "البته، این هم خیلی خوبه. باید بگم، این هم خیلی خیلی خسته‌کننده است."

    # say L191 rub
    old "I mean, you couldn't wear ANYTHING more revealing! My god! You should be ashamed!"
    new "من می‌گم، نمی‌تونی هیچ چیزی آب‌درآب‌تر از این بپوشی! خدا نگه دار! باید خجول باشی!"

    # say L192 hin
    old "W- what are you talking about? Your costume has also a cleavage..."
    new "و- و این حرفت چیه؟ لباس تو هم یه دیپ‌ونگه داره..."

    # say L193 rub
    old "WHAT? YOU'VE GOTTA BE KIDDING ME!"
    new "چه کاری؟ می‌خواهی جدی باشی؟"

    # say L194 rub
    old "We have decent classy costumes, there's nothing wrong with ours."
    new "ما لباس‌های محترمانه و شایسته داریم، هیچ مشکلی نداره."

    # say L195 rub
    old "In case you haven't noticed, Olivia and I are Disney princesses..."
    new "اگه توجه نکردی، اولیویا و من قهرمانان دیزنی هستیم..."

    # say L196 rub
    old "While you just came in a stupid costume from some nerd stuff."
    new "در حالی که تو فقط لباس خنده‌داری از چیزی نرد پوشیدی."

    # say L197 hin
    old "Well, I don't care, because I really have something to show and I feel comfortable with my body, unlike you two stupid bitches..."
    new "خب، من نگران نیستم، زیرا چیزی برای نشون دادن دارم و از بدنش خودم راحت می‌شم، برخلاف شما دو تا مغز خرده..."

    # say L198 rub
    old "W- what did you just say to me?! Olivia! Did you hear that?!!"
    new "و- و چه حرفی به من زدی؟! اولیویا! شنیدی؟!!"

    # say L199 oli
    old "I did Ruby! How dare you talk to us like that? You bat-whore!"
    new "روبی! چطور می‌تونی به ما اینجوری حرف بزنی؟ شما خرگوش‌پرنده!"

    # say L200 hin
    old "Shut up you two! You envious bitches!"
    new "بسته شوید شما دو تا! شما دو خربهٔ حسود!"

    # say L201 bel
    old "Ohhhh! What's the matter, girls? You can dish it, but you can't take it?"
    new "اوهههه! چه کاری دارید، دختران؟ می‌تونید بگید ولی نمی‌تونید ببرید؟"

    # say L202 pla
    old "H-Hey, Hinn, maybe it's best if we just leave, look, classes are about to start..."
    new "ه-هی، هین، شاید بهتر باشه اگه ما برهیم، ببین، کلاس‌ها خیلی زود شروع می‌شن..."

    # say L203 hin
    old "And why do we have to be the ones to leave?! These idiots are the ones who started."
    new "و چرا ما باید بریم؟！این احمق‌ها هستن که شروع کردن."

    # say L204 hin
    old "You two better get out here! I've had enough of your bullshit!"
    new "شما دو تا بهتره بروید! از این جور بی‌هیچ‌پیچ‌های شما خسته شدم!"

    # say L205 rub
    old "Ughh. We're leaving! But it's not because you tell us to, you little whore! I just don't want to keep wasting my time with you, dumbasses."
    new "اوه. ما می‌رویم! اما نه برای اینکه تو به ما فرمان می‌دی، شما خرکوچولو! من فقط نمی‌خوام وقتم رو با شما احمق‌ها بیشتر بگذونم."

    # say L206 rub
    old "Let 's go Olivia."
    new "بیا، Liv."

    # say L220 bel
    old "Wow! Hinn, what's happened to you? That was sooo awesome!"
    new "واو! هین، اتفاق چی زد به تو؟ اونقدر عالی بود!"

    # say L221 hin
    old "Hehe, you think so?"
    new "ههه، فکر می‌کنی همینطوره؟"

    # say L222 bel
    old "Hell yeah! I don't know what you've been doing, but you're so confident now. Just look at how you put those airheads in their place!"
    new "بله ها! نمی‌دونم چیکار کردی، ولی حالا اینقدر اعتماد به نفس داری. فقط ببین چطور اون دسته بی‌هیچ‌پیکر رو به جایشون گذاشتی!"

    # say L223 hin
    old "And... What do you think [pla]?"
    new "و... تو چه فکر می‌کنی [pla]؟"

    # say L224 pla
    old "I agree with Belle, you were totally awesome Hinn!"
    new "با Belle موافقم، تو کاملاً عالی بودی Hinn!"

    # say L225 hin
    old "Well, it's a relief to hear you guys say that... For a moment there I thought you may have thought ill of me."
    new "البته، خوشحالم که اینطور می‌گویید... برای یک لحظه فکر کردم شاید نظر بدی از من داشته باشید."

    # say L227 pla
    old "Aww, we wouldn't. And hey, for what it's worth, I think your costume is great."
    new "اوه، ما همچین چیزی فکر نمی‌کردیم. و بگو برای اینکه ارزشش رو دارم، فکر می‌کنم لباس تو عالیه."

    # say L228 bel
    old "Yeah Hinn, you look gorgeous, and I'm happy you're finally showing some skin, it was about time!"
    new "بله هین، تو خوش‌چهره‌یی هستی و خوشحالم که در نهایت یه کم پوستت نشون میدی، وقت خوبی بود!"

    # say L229 hin
    old "Sigh, stop it with that."
    new "خوب، دیگه اینجوری نکن."

    # say L230 mik
    old "Yeah Hinn, it really, really suits you."
    new "بله هین، واقعاً خوب به تو می‌آید."

    # say L231 mik
    old "And hey, I support you sharing your natural gifts with us. It's a really nice view."
    new "و بله، من حمایت می‌کنم از هدایت‌های طبیعی‌ات با ما به اشتراک بگذاری. واقعاً منظره‌ای خوبه."

    # say L233 bel
    old "Oh my gosh Mike, couldn't you be a little decent at least once?"
    new "اوه خدا مایک، یه بار هم نمی‌تونی محترمانه باشی؟"

    # say L234 mik
    old "What? What did I say? I was giving Hinn a compliment!"
    new "چه کار کردم؟ من فقط هین رو ستودم!"

    # say L235 bel
    old "Yeah right, sure you were..."
    new "بله، البته که همین طور بود..."

    # say L236 bel
    old "Anyway, we better get going. It's almost time for class."
    new "بفرمایید، بهتره حالا بریم. تقریباً وقت کلاس هست."

    # say L237 mik
    old "Huh? But we still have some time."
    new "اوه؟ اما هنوز وقت داریم."

    # say L239 bel
    old "I know, but you know Ms. Mia has her eyes on you because you keep skipping. So, let's go, come on!"
    new "می‌دونم، ولی می‌دونی مس میا چشم‌هایش رو به تو داره چون همیشه غایب می‌شی. پس بیای، برویم!"

    # say L250 hin
    old "W- was that true [pla]?"
    new "W- آن هم درست بود [pla]؟"

    # say L253 hin
    old "What you said about my costume, do you really like it?"
    new "این لباسی که پوشیدی، واقعاً دوست داری؟"

    # say L254 pla
    old "Of course! I like it a lot."
    new "البته! خیلی دوست دارم."

    # say L255 pla
    old "And to be honest... I think you're the only student who could pull it off."
    new "و صداقت بگم... فکر می‌کنم تو تنها دانش‌آموزی هستی که می‌تونی این لباس رو پوشونی."

    # say L256 hin
    old "Huh? You mean it?"
    new "حقاً؟ می‌گی‌ای جدی؟"

    # say L257 pla
    old "Yeah! Nobody else could wear that costume that well."
    new "بله! هیچ‌کس دیگه نمی‌تونست اون لباس رو به همین خوبی بپوشه."

    # say L260 hin
    old "Come with me for a moment [pla]..."
    new "بیا با من یه لحظه [pla]..."

    # say L262 pla
    old "Uhh, where are we going?"
    new "اوه، ما به کجا می‌رویم؟"

    # say L263 hin
    old "Just come."
    new "بیا فقط."

    # say L285 pla
    old "Hmm, Hinn, this is the girl's bathroom, I don't think it's ok for me to go in."
    new "هم، هین، این به سمت حمام دخترانه هست، فکر نمی‌کنم برا من درست باشه وارد شم."

    # say L286 pla
    old "Maybe it's better if I wait outside."
    new "شاید بهتر باشه بیرون منتظر بیام."

    # say L288 pla
    old "For you to use the bathroom..."
    new "برای اینکه توی دمتون برسی..."

    # say L289 hin
    old "Hahahaha. Don't be silly, I didn't bring you here for that."
    new "حاحاحا. نباید خنده‌دار باشی، من تو رو برای اون کار آوردم نه برای اینجا."

    # say L290 pla
    old "Uhh, you didn't? Then why?"
    new "اوه، نه؟ پس چرا؟"

    # say L292 hin
    old "You see, working with you and Dr. Johnson has really helped me get over my shyness, that's how I was able to stand up to those bullies."
    new "ببین، کار کردن با تو و دکتر جانسون واقعاً به من کمک کرد تا از خجالت بیرون بیام، همینجوری بتونم به آن بیگانه‌ها مقاومت کنم."

    # say L293 hin
    old "So, I thought maybe we could have a little session now. Besides, I want to thank you."
    new "پس فکر کردم شاید بتوانیم الان یک جلسه کوچک داشته باشیم. علاوه بر این، می‌خوام ازت تشکر کنم."

    # say L294 pla
    old "B- but here? What if someone sees us?"
    new "ب- اما اینجا؟ اگه کسی ما رو ببینه چه کاری کنیم؟"

    # say L295 hin
    old "Ohh, don't worry, I'm sure it's gonna be fine, classes are about to start, so there's nobody around."
    new "اوه، نگران نباش، مطمئنم همه خوب می‌شه، کلاس‌ها قراره شروع بشن، پس اینجا کسی نیست."

    # say L296 pla
    old "Well, if you say so... I guess it's ok then."
    new "اگه می‌گی برات خوبه... فکر کنم خوبه."

    # say L297 hin
    old "Yes, I'm sure nobody will see us."
    new "بله، مطمئن هستم که هیچ‌کس ما رو نمی‌بینه."

    # say L298 hin
    old "Come here, pull down your pants."
    new "اونجا بیا، شلوارتو بردار."

    # say L305 hin
    old "It's always amazing how big you are [pla]."
    new "البته همیشه شگفت‌زده‌ام از اینکه چقدر بزرگی [pla]."

    # say L306 pla
    old "I can believe we're doing it in the bathroom."
    new "نمی‌تونم باور کنم ما در حمام داریم انجام میداد."

    # say L308 hin
    old "I'm happy you're this hard because of me."
    new "خوشحالم که به خاطر من اینقدر سختی."

    # say L317 hin
    old "Look, it's almost time for class."
    new "ببین، تقریباً وقت کلاس شده."

    # say L318 hin
    old "I'll go ahead. Don't be late."
    new "من پیش می‌روم. دیر نشین."

    # say L327 pla
    old "Wow! I don't know what that was, but I sure like this new Hinn."
    new "واو! نمی‌دونم اون چی بود، ولی این هین جدید رو خیلی دوست دارم."

    # say L340 pla
    old "Ohh! Wow, Billie! What are you doing here?"
    new "اوه! وای، بیلی! تو اینجا چی کار داری؟"

    # say L342 bil
    old "Hey! What's up? I just transferred here. Today's my first day."
    new "اوه! چطوری؟ همینجا منتقل شدم. امروز روز اولم."

    # say L343 pla
    old "Ahh, I see. That's cool, what school did you transfer from?"
    new "اوه، من می‌بینم. خوبه، از کجا منتقل شدی؟"

    # say L344 bil
    old "From nowhere actually. All my life I've been home schooled, and that's fine, I guess. But you see, this is my last year..."
    new "در واقع از هیچ جایی نیستم. تمام زندگیم را در خانه تحصیل کرده‌ام و این هم خوب است، حدس می‌زنم. اما ببین، این آخرین سالم است..."

    # say L345 bil
    old "So, I wanted to have the school experience at least for senior year."
    new "پس، می‌خواستم تجربه مدرسه رو حداقل برای سال آخر داشته باشم."

    # say L346 pla
    old "Well, I think that's a great idea! I'm glad you get to live that at least once. And hey, welcome."
    new "خب، فکر کنم ایده خوبیه! خوشحالم که این تجربه رو حداقل یه بار داشته باشی. و ها، خوش آمدی."

    # say L348 bil
    old "It was a coincidence that my first day was Halloween. So, I had to come in costume. What do you think?"
    new "این صدفه بود که روز اولم هالووین بود. پس باید با لباس ماسکوم اومدم. نظرت چیه؟"

    # say L349 pla
    old "I think it's great, it's really good. You look just like the real Harley Quinn."
    new "من فکر می‌کنم عالیه، واقعاً خوبه. مثل هارلی کوین حقی به نظر می‌رسی."

    # say L350 bil
    old "Thanks, and hey, I think you also make for a very good Spiderman."
    new "ممنون، و بله، فکر می‌کنم تو هم یک اسپایدرمن خوبی هستی."

    # say L352 pla
    old "Thanks!"
    new "ممنون!"

    # say L353 bil
    old "By the way. Why were you leaving the girls bathroom?"
    new "باید بگم. چرا از توالت دختران خارج می‌شدی؟"

    # say L354 pla
    old "Ohh! Hmm, no reason."
    new "اوه! نه، هیچ دلیلی."

    # say L355 pla
    old "I guess, I- I just got confused."
    new "من فقط گم شدم."

    # say L357 bil
    old "Uhh... Sure..."
    new "اوه... البته..."

    # say L358 pla
    old "We better get going, the class has already started."
    new "باید برویم، جلسه قطعاً شروع شده."

    # say L364 mia
    old "Ok guys, let's start today's lesson. Now who can tell me where we left it last time?"
    new "خب بچه‌ها، بیایید درس امروز رو شروع کنیم. حالا کی می‌تونه به من بگه که ما آخرین بار کجا خاتمه دادیم؟"

    # say L379 pla
    old "Sorry ma'am! We came as quickly as we could."
    new "ببخشید خانم! ما تا حد ممکن سریع اومدیم."

    # say L380 mia
    old "Ugh! It's always the same with you [pla]! Would it kill you to act like a good student at least once?"
    new "آخه! همیشه همینجوری با تو [pla]! یه بار هم می‌تونی مثل یه دانش‌آموز خوب رفتار کنی؟"

    # say L381 pla
    old "I- I'm sorry Ms. Mia, it won't happen again, it's just that I met my friend in the hallway."
    new "ببخشید خانم میا، دیگه اینجوری نمی‌شه، فقط اینجوری شد که دوستم رو در راهرو دیدم."

    # say L382 mia
    old "Yeah right! Always excuses with you. Anyway, go sit down!"
    new "بله ها! همیشه عذردهی‌ها با تو. حالا برو جلو بنشین!"

    # say L389 mia
    old "Ok guys, before we begin, I have to introduce you to a new student."
    new "بچه‌ها، قبل از شروع، باید به شما یک دانش‌آموز جدید را معرفی کنم."

    # say L393 mia
    old "This is Billie, she's going to be accompanying us during this last year. Be sure to be nice to her."
    new "این بیلیه، او طول سال آخر با ما همراه خواهد بود. حتماً با او مهربان باشید."

    # say L394 bil
    old "Hi."
    new "سلام."

    # say L396 mia
    old "Take seat Billie, there's a spot for you there."
    new "بیلی، جا بنشین، جایی برایت هست."

    # say L401 mia
    old "Ok guys, as I was saying before being so rudely interrupted by [pla].  Who can tell me what we were talking about last class?"
    new "خب بچه‌ها، همانطور که می‌خواستم بگم قبل از اینکه [pla] به طور نااحترامی من را قطع کند. چه کسی می‌تونه به من بگه ما در آخرین جلسه درباره چه چیزی صحبت می‌کردیم؟"

    # say L409 mia
    old "Ok, that's it for today, don't forget to read up on the textbook before next class. It's better if you prepare your classes ahead."
    new "خوب، این همه برای امروز، فراموش نکنید قبل از کلاس بعد کتاب را مطالعه کنید. بهتر است کلاس‌هایتان را پیش از زمان آماده کنید."

    # say L423 bel
    old "Ok everybody, classes are over, and we have time. Why don't we go ask for some candy?"
    new "باشه همه، کلاس تمام شد و وقت داریم. چرا نمی‌رویم کندی بگیریم؟"

    # say L424 bil
    old "Ugh, candy? Are you serious? Don't you think we're a little too old for that?"
    new "او، کندی؟ جدی می‌گی؟ آیا فکر می‌کنی ما برای این کمی بزرگ هستیم؟"

    # say L425 bel
    old "Ohh, come on! This is our last year, so we won't be able to do it anymore."
    new "اوه، بیا! این آخرین سالمونه، پس دیگه نمی‌تونیم این کار رو بکنیم."

    # say L426 mik
    old "Yeah! Billie, trick or treating is super cool, we'll have a great time."
    new "بله! بیلی، گرفتن شکلات خیلی خفن است، ما وقت عالی خواهیم گذراند."

    # say L427 bil
    old "I don't think walking around, knocking on front doors is a ‘great time.'"
    new "من فکر نمی‌کنم راه رفتن و زنگ درب‌ها رو زدن یک «زمان خوب» باشه."

    # say L428 bil
    old "But whatever, if you all want to."
    new "ولی هر چی، اگه شما همه می‌خواهید."

    # say L430 pla
    old "I actually want too, it's a good way to spend the afternoon."
    new "من هم می‌خوام، راه خوبیه برای گذراندن عصر."

    # say L431 pla
    old "Besides, we get to use the costumes some more."
    new "البته، می‌تونیم لباس‌های ماسکره رو هم بپوشیم."

    # say L432 pla
    old "And what do you think Hinn?"
    new "و تو چه فکر می‌کنی، هین؟"

    # say L433 hin
    old "I think it's a nice idea. I wanna hang out some more."
    new "من فکر می‌کنم ایده خوبیه. می‌خوام بیشتر با هم وقت بگذرونیم."

    # say L434 hin
    old "And to be honest I also don't want to get out of my costume just yet."
    new "و صداقت بگم هنوز نمی‌خوام لباس من رو بگذارم."

    # say L435 bil
    old "Oh my god, you guys are so lame."
    new "اوه خدای من، شما دو تا خیلی بی‌چین هستید."

    # say L436 bil
    old "But fine, fine, if you want to do it, I'll do it too. This better be good."
    new "البته، البته، اگه می‌خواین انجام بدیم، من هم می‌کنم. امیدوارم خوب باشه."

    # say L453 mik
    old "That was so awesome! I can't believe they gave us this much candy at our age."
    new "این خیلی عالی بود! نمی‌تونم باور کنم به ما اینقدر شکلات دادن در این سن."

    # say L454 pla
    old "Definitely, a real success I'd say."
    new "حتماً، موفقیت واقعی بود."

    # say L455 bel
    old "You see? It was totally worth it. I knew it was gonna be this much fun. Right Billie?"
    new "ببین؟ همش ارزشش بود. می‌دونستم اینقدر خوشحالم کنم. درسته بیلی؟"

    # say L456 bil
    old "Yeah... I guess. It wasn't so bad after all."
    new "بله... حدس زدم. خوب نبود، اما اصلاً بد نبود."

    # say L457 hin
    old "It's still early, we could keep going if you want to."
    new "هنوز زود است، اگه می‌خوای می‌تونیم ادامه بدیم."

    # say L458 mik
    old "Nah, I don't think so. This is nice and all, but my feet hurt, I'm a little tired of carrying this heavy custume."
    new "نه، فکر نمی‌کنم. این خوبه و همه، ولی پاشونم درد می‌کشه، از این لباس سنگین خسته شدم."

    # say L459 pla
    old "Come on man, don't ruin the mood, you're the one who wanted to ask for candy in the first place."
    new "بیا برو، نباشی اجساد رو خراب کنی، تو خودت بودی که از اول می‌خواستی سوپرمارکت رو بپرسی."

    # say L460 bel
    old "Actually [pla], it annoys me to say this, but I think Mike may be right. We've been going for a while now, we should rest."
    new "در واقع [pla]، این جوری هم ناراحت می‌کنم، ولی فکر می‌کنم مایک درست می‌گه. از اول هم اینجا هستیم، باید استراحت کنیم."

    # say L461 bil
    old "Well, if that's the case, we should go to the beach then, it's very nearby and we could sit and rest there."
    new "اگر اینجوریه، باید به ساحل برویم، خیلی نزدیکه و می‌تونیم اونجا نشسته و استراحت کنیم."

    # say L462 pla
    old "Hmm, and what do you think, Hinn? Do you want to keep going?"
    new "هم، و تو چه فکر می‌کنی، هین؟ می‌خوای ادامه بدهیم؟"

    # say L463 hin
    old "Ohh, I'm fine. I only said it because I thought everyone else wanted to do it too, but if everyone it's ok with stopping here I'd agree."
    new "اوه، من خوبم. فقط گفتم چون فکر کردم همه می‌خواهند این کار رو انجام بدند، اما اگه برای همه خوب باشه اینجا متوقف شیم، من هم موافقم."

    # say L464 bel
    old "That settles it then, let's go to the beach."
    new "پس اینجوری، بیایم به ساحل برویم."

    # say L478 pla
    old "Well, this is nice. I thought there were going to be people here."
    new "خب، این خوبه. فکر کردم اینجا مردمی باشه."

    # say L479 hin
    old "Yeah, it's good that it is so quiet, this is a good place to rest."
    new "بله، خوشحالم که اینجا آرام است، جای خوبی برای استراحت است."

    # say L480 bel
    old "We should find a place to sit down."
    new "باید جایی پیدا کنیم که بنشینیم."

    # say L481 hin
    old "Can't we just sit here?"
    new "نمی‌تونیم اینجا بنشینیم؟"

    # say L482 bel
    old "I think we could sit a little bit closer to the sea."
    new "فکر می‌کنم می‌تونیم کمی نزدیک‌تر به دریا بنشینیم."

    # say L483 bil
    old "Let's just go to that spot over there"
    new "بیایم به اون جا برویم"

    # say L484 pla
    old "Yeah, that seems fine."
    new "بله، اینجوری خوب است."

    # say L498 bil
    old "Ok, since we're here. Why don't we make it a little bit more interesting than just sitting down doing nothing? Let's play truth or dare!"
    new "باشه، از آنجا که اینجا هستیم. چرا نه، بیایم یه کم جالب‌تر از این که فقط بنشینیم و هیچی نکنیم باشیم؟ بیایم بازی حقیقت یا ترس دادن بازی کنیم!"

    # say L499 hin
    old "Uhh, I'm sorry. Truth or what?"
    new "اوه، معذرت. حقیقت یا چه؟"

    # say L500 bil
    old "What? You don't know what truth or dare is?"
    new "چه؟ نمی‌دونی چیه حقیقت یا ترس؟"

    # say L501 mik
    old "Hey! I know what it is."
    new "اوه! من می‌دونم چیه."

    # say L502 pla
    old "Uhh, I think I know it, but I haven't played it."
    new "می‌دونم، اما هیچ بار نسبت به اون بازی نکردم."

    # say L503 pla
    old "Just so we're all on the same page, could you explain?"
    new "برای اینکه همه روی هم باشیم، می‌تونی توضیح بدی؟"

    # say L505 bil
    old "It's very simple: Each round, one of us chooses someone and asks them 'truth or dare'"
    new "بسیار ساده است: در هر دور، یکی از ما کسی را انتخاب می‌کند و ازش می‌پرسه «حقیقت یا تجربه»"

    # say L506 bil
    old "If the person chooses ‘truth' they have to answer whatever the other one asks. If they choose ‘dare', they have to do what the person tells them to."
    new "اگر شخص «حقیقت» رو انتخاب کنه، باید به هر چی که دیگری بپرسه جواب بده. اگر «چالش» رو انتخاب کنه، باید هر چی که شخص بهش بگه انجام بده."

    # say L507 pla
    old "All right..."
    new "باشه..."

    # say L508 bel
    old "You have to be really honest in answering or accomplishing the dare, otherwise, you must go and can't continue playing."
    new "باید واقعاً صادقانه جواب بدی یا تجربه را انجام بدی، در غیر این صورت باید بری و نتونی بازی رو ادامه بدهی."

    # say L509 bil
    old "Yeah, just like that, it's really fun. Come on, let's play!"
    new "بله، همینطور، واقعاً خوشحالم. بیا، بذار بازی کنیم!"

    # say L511 pla
    old "Hmm, I don't know Billie..."
    new "Hmm، نمی‌دونم بیلی..."

    # say L512 mik
    old "Oh no! We're not backing down from this, [pla]. Come on! It sounds like a lot of fun!"
    new "اوه نه! ما از این پشت نمی‌بریم، [pla]. بیا! به نظر می‌رسه خیلی خوشحالم!"

    # say L513 bel
    old "Yeah guys, let's do it. You never know, you may end up liking it."
    new "بچه‌ها، بیایید انجام بدیم. ممکنه خوشتون بیاد."

    # say L514 pla
    old "Ok, ok. If you guys really want to, let's do it."
    new "باشه، باشه. اگه شما ها واقعاً می‌خواهید، بیایید انجام بدیم."

    # say L516 mik
    old "Alright! Let's do it!"
    new "باشه! بیاین انجام بدیم."

    # say L517 bil
    old "Did you get it Hinn?"
    new "دستت در آمد هین؟"

    # say L519 hin
    old "Yeah, it's not that hard."
    new "بله، خیلی سخت نیست."

    # say L520 bel
    old "Ok, since you say you understood it Hinn. Let's start with you, truth or dare?"
    new "باشه، چون می‌گی هین. بیای برات شروع کنیم، حقیقی یا ترسناک؟"

    # say L521 hin
    old "Uhmm, truth."
    new "اوه، حقیقت."

    # say L523 bel
    old "Hmm, are you in love with anybody here?"
    new "هم، آیا عاشق کسی از اینجا هستی؟"

    # say L524 hin
    old "W- what? What kind of question is that?!"
    new "و- وای، این چه سؤالیه؟!"

    # say L525 bel
    old "Uhh, it's a valid question, and you have to answer it, those are the rules..."
    new "اوه، این سوال معتبره و باید بهش جواب بدی، این قوانین هستند..."

    # say L526 bil
    old "That's right, that's the game."
    new "درسته، این همین بازیه."

    # say L528 hin
    old "*Sigh* O- ok. Y- yes, I- I'm in love with someone who's here."
    new "*تنفس عمیق* خب، بله، من عاشق کسی هستم که اینجا است."

    # say L531 mik
    old "WHAT?! Who is it? Who is it?"
    new "چه؟ کی هست؟ کی هست؟"

    # say L532 pla
    old "Hey, hey! Not fair, dude, she already answered a question. You can't ask her anything else. Right Billie?"
    new "هی، هی! منصفانه نیست، برو، او قبلاً سؤالی جواب داده. بایلی، درسته؟"

    # say L534 bil
    old "Yeah, if you really wanna know that kind of stuff, you're gonna have to ask better questions."
    new "بله، اگه واقعاً می‌خوای این جوری چیزها رو بدونی، باید سؤال‌هایت رو بهتر بپرسی."

    # say L535 bil
    old "But come on, I think we should go for dares... It makes the game exciting!"
    new "ولی بیای، فکر کنم باید به چالش‌ها روی آوریم... اینجور بازی جذاب‌تر می‌شه."

    # say L536 bil
    old "Anyway, since you already spoke, why don't you ask the next question [pla]?"
    new "بیل: هر جا که، چون تو قبلاً صحبت کردی، چرا سؤال بعدی رو پرسنی [pla]؟"

    # say L537 pla
    old "Hmm, ok. Well then, Belle, truth or dare?"
    new "Hmm، اوکی. خب، بله، Belle، حقیقت یا چالش؟"

    # say L538 bel
    old "Truth."
    new "حقیقت."

    # say L539 bil
    old "Oh come on! Don't be pussies! Dares are way more fun!"
    new "اوه بیایید! نباید خرس‌تون باشید! چالش‌ها خیلی جالب‌تر هستند!"

    # say L540 pla
    old "Hmm... H- have you ever kissed a man before?"
    new "هم... ه- هلی، تا حالا با مرد قبلاً بوسه‌تی داده‌ای؟"

    # say L542 bil
    old "What kind of question is that? Are you serious? Oh my god, you're a bunch of wusses."
    new "چه سوالیه این؟ جدی می‌گی؟ خدا نگه دار، شما همه خرسیده‌ای."

    # say L547 bil
    old "I'll ask the question. Belle, have you ever taken naked pics?"
    new "من می‌پرسم. بل، قبلاً عکس‌های عریان خودت گرفته‌ای؟"

    # say L548 bel
    old "W- whoa. Don't you think that's a little too far?"
    new "و- وای. آیا فکر می‌کنی این کمی خیلی دوره؟"

    # say L550 bil
    old "No it's not and answer the question."
    new "نه، اصلاً دور نیست و بپاسخ."

    # say L551 mik
    old "Yeah Belle, those are the rules. You answer the question or leave!"
    new "بله بله، این قوانین هستن. تو باید سؤال رو بپاسخی یا برو بیرون!"

    # say L555 bel
    old "Ugh! Yeah fine, I've taken naked photos before."
    new "اوه! بله خوب، قبلاً عکس عریان گرفتم."

    # say L558 mik
    old "Whoa! Really?!"
    new "وای! واقعاً؟!"

    # say L561 bil
    old "Hehe, ok. Who 's next?"
    new "خخخ، خوب. بعد از من کیه؟"

    # say L562 mik
    old "Me, me, me! I'm next."
    new "من، من، من! من بعدی هستم."

    # say L563 mik
    old "Ok, Billie. Truth or dare?"
    new "باشه، بیلی. حقیقت یا تجربه؟"

    # say L564 bil
    old "Dare! Unlike you guys, I actually have some guts."
    new "چالش! برخلاف شماها، من واقعاً جرأت دارم."

    # say L568 mik
    old "Ok... Hmm... I dare you to... kiss Belle!"
    new "اوه... هم... من تجربه‌ت رو چالش می‌کنم که... بیل بوسه بده!"

    # say L570 bel
    old "What? But I'm not the one with the dare! It's Billie."
    new "چه کاری؟ ولی من نیستم که تجربه‌ای داشته باشم! این بیلی هست."

    # say L571 bil
    old "Well, yeah. But this kind of dares are valid too. After all, I'm the one that has to do it."
    new "بله، همینه. اما این نوع چالش‌ها هم معتبر هستن. در نهایت، من هستم که باید انجام بدم."

    # say L572 mik
    old "Yeah! Remember, you have to do it or you're out!"
    new "بله! به خاطر داشت، باید اینو انجام بدی، در غیر این صورت خارج می‌شی!"

    # say L573 bil
    old "Yeah whatever, I'll do it, it's no big deal."
    new "بله خب، انجام میدم، خیلی مهم نیست."

    # say L575 bil
    old "Come on, just help me with this... Otherwise I won't be able to continue playing..."
    new "بیا، فقط به من در این کمک کن... در غیر این صورت نمی‌تونم بازی رو ادامه بدم..."

    # say L577 bil
    old "Just come here, close your eyes and think of someone you like."
    new "بیا اینجا، چشاتو ببند و به کسی که دوست داری فکر کن."

    # say L578 bil
    old "I'm sure we both are gonna enjoy it."
    new "مطمئنم هر دو لذت می‌بریم."

    # say L590 hin
    old "Ok. Now it's my turn to have a go!"
    new "باشه. حالا منم دسته‌ام!"

    # say L592 hin
    old "Mike, truth or dare?"
    new "مایک، حقیقت یا تجربه؟"

    # say L593 mik
    old "Of course dare."
    new "البته چالش."

    # say L594 hin
    old "Well, I dare you to leave and go home."
    new "خوب، تجربه‌ای می‌دهم که بری و به خونه برگردی."

    # say L595 mik
    old "Uhh?..."
    new "اوه؟..."

    # say L596 bel
    old "Yeah! That's right, we all had to do our dares. You have to do the same."
    new "بله! همین‌جوری، ما همه باید چالش‌هامون رو انجام میدادیم. تو هم باید همین کار رو بکنی."

    # say L597 hin
    old "What is it Mike? You can't do it, uhh?"
    new "مایک، چیه؟ نمی‌تونی اینو انجام بدی، هه؟"

    # say L598 mik
    old "Of course I can do it! I'll show you!"
    new "البته می‌تونم انجام بدم! بهت نشون می‌دم!"

    # say L615 bil
    old "Yeah, I didn't think he would do it."
    new "بله، من هم فکر نکردم انجام بدی."

    # say L617 pla
    old "Hahaha, very good trick Hinn, well done."
    new "حاحاحا، ترک خوبی بود هین، خوب انجام دادی."

    # say L619 bel
    old "Ok, now that he's gone. It's my turn again. [pla] truth or dare?"
    new "خب، حالا که رفت. دوباره من دست من. [pla] حقیقت یا تجربه؟"

    # say L620 pla
    old "Hmm, truth."
    new "Hmm، حقیقت."

    # say L627 pla
    old "You know what? I- I choose dare."
    new "می‌دونی چی؟ من- من تجربه رو انتخاب می‌کنم."

    # say L628 bel
    old "What? No, you've got to answer the question."
    new "نه، باید به سؤال جواب بدی."

    # say L629 bil
    old "No, it's fine. In fact, from now on let's play only with 'dares', no more truths."
    new "نه، خوبه. در واقع از حالا به بعد فقط با چالش‌ها بازی کنیم، دیگه سؤالی نه."

    # say L630 bel
    old "Hmm, ok, if that's how it is. Then I dare you to take your penis out."
    new "Hmm، خب، اگر همینطوره. پس تو رو دارم تجربه می‌کنم که نیم‌تنه‌ات رو بیرون بیاری."

    # say L631 pla
    old "W- what? Why do I have to do that?"
    new "و- وای، چرا من باید این کار رو بکنم؟"

    # say L632 bel
    old "Well, you can either do that, or answer my question!"
    new "خب، می‌تونی هم این کار رو بکنی، یا سؤال من رو پاسخ بدی!"

    # say L634 pla
    old "Hmm, fine..."
    new "خوب، خیلی خب..."

    # say L643 bel
    old "(What a fucking big cock!)"
    new "چه کسی چقدر بزرگه!"

    # say L644 pla
    old "Ok, now it's done."
    new "باشه، حالا تمام شد."

    # say L651 bil
    old "It's my turn again. And Belle, since you already made [pla] show something..."
    new "الان دوباره من هستم. و بله، چون تو قبلاً از ز[pla] نشون دادی..."

    # say L652 bil
    old "Why don't you show something of your own as well? What about if you take your boobs out?"
    new "چرا تو هم چیزی نشون نمی‌دی؟ مثل اینکه سیناتو بیرون بیاری؟"

    # say L654 pla
    old "Hey, I already did it. You have to fulfill the dare."
    new "بله، من قبلاً انجام دادم. تو باید جرأت رو انجام بدی."

    # say L655 bel
    old "Fine. I'll do it."
    new "خوب، انجام میدم."

    # say L686 bel
    old "Ok, since I've done it... It's my turn, Billie! Show us your breasts too."
    new "باشه، از اونجایی که من انجام دادم... الان دوباره باید تو هم این کار رو بکنی، بیلی! سینات رو هم به ما نشون بده."

    # say L687 bil
    old "Ughh, so original..."
    new "اوه، خیلی خلاقانه..."

    # say L715 bil
    old "Then, since there's only one person here that hasn't shown anything. Hinn, I dare you to take your breast out too."
    new "پس، چون فقط یک نفر اینجا هیچ چیزی نشون نداده. هین، جرات می‌کنم تو هم سیناتو بیرون بیاری."

    # say L718 hin
    old "I- I... Uhh... I'm sorry guys, I- I can't do it."
    new "من- من... اوه... معذرت دوستان، من- من نمی‌تونم این کار رو بکنم."

    # say L730 pla
    old "Hinn wait!"
    new "هین، بیا!"

    # say L731 bel
    old "No! [pla], just let her go. I think we went a little too far, right now she's a little nervous. Just leave her alone for now."
    new "نه! [pla]، فقط بگذار برود. فکر می‌کنم ما کمی زیاد رفتیم، حالا کمی ناراحته. فقط حالا از او بگذار بره."

    # say L732 pla
    old "But... I think she needs company."
    new "ولی... فکر می‌کنم به همراهی نیاز داره."

    # say L733 bel
    old "Not right now, if you go after her you're just going to make her feel worse."
    new "البته حالا نه، اگه پشت سرش بری فقط بدتر می‌تونه حس کنه."

    # say L736 bel
    old "Trust me, it's better if you just let it be. You can talk to her later. Right Billie?"
    new "باور کن، بهتره اینجوری باشه. بعداً باهاش صحبت کنی. درسته بیلی؟"

    # say L737 bil
    old "Yeah, what she said."
    new "بله، همونطور که او گفت."

    # say L740 pla
    old "Hmm, all right."
    new "خوب، حس می‌کنم خوبه."

    # say L741 bil
    old "Well, I guess we can continue playing then."
    new "خوب، به نظر می‌رسه می‌تونیم ادامه بدهیم."

    # say L742 bel
    old "I agree, since we already started playing. I think it's the best we can do."
    new "من هم موافقم، چون قرار بود بازی رو شروع کنیم. فکر می‌کنم بهترین چیزی که می‌تونیم بکنیم اینه."

    # say L743 pla
    old "Yeah fine. Let's do it."
    new "بله خوبه. بیایم انجام بدیم."

    # say L744 bel
    old "Now, it's your turn to do a dare again [pla]."
    new "الان دوباره باید تو یه چالش بپذیری [pla]."

    # say L745 bel
    old "Why don't you suck Billie's boobs?"
    new "چرا نمی‌تونی بوسیدن سینه‌های بیلی رو انجام بدی؟"

    # say L746 pla
    old "Whoa! Really?"
    new "وای! واقعاً؟"

    # say L747 bil
    old "Well, a dare is a dare, so..."
    new "خب، چالش یه چالشه، پس..."

    # say L748 pla
    old "A- all right."
    new "ب- خوب، می‌تونم."

    # say L767 bil
    old "Hmm, this isn't going to stay like this."
    new "هم، اینجوری نمی‌مونه."

    # say L771 bel
    old "W- what? For real?!"
    new "و- وای، جدی می‌گی؟!"

    # say L773 bil
    old "That's right."
    new "بله، همینطور است."

    # say L774 bel
    old "Ughh, fine, let's do it."
    new "اوه، خوب، بیایم انجام بدیم."

    # say L780 bel
    old "My god [pla] your dick is huge! I can't believe you carry this around."
    new "الهی ز[pla] خودت بزرگ هست! نمی‌تونم باور کنم اینقدر این چیز رو با خودت حمل می‌کنی."

    # say L782 bil
    old "Come on, quit stalling and do it."
    new "بیا، دیگه توقف نکن و انجام بده."

    # say L783 bel
    old "Yeah, well, here I come."
    new "بله، خب، اینجا می‌آیم."

    # say L796 bel
    old "Ok, I did what you dared me too."
    new "باشه، آنچه شجاعتت برای انجامش داشتی رو انجام دادم."

    # say L797 bel
    old "But since you wanted to see that so badly, why don't you give [pla] a blowjob, Billie?"
    new "بیلی، از بابت اینکه خیلی می‌خواستی ببینی، چرا به [pla] جام دهی نمی‌کنی؟"

    # say L798 bil
    old "What's this, copying me again?"
    new "این چیه، دوباره مثل من می‌کنی؟"

    # say L799 bel
    old "What? After you made me do all of that, you can't do it?"
    new "چه کاری؟ بعد از همه آن‌ها که من انجام دادم، تو نمی‌تونی اینو بکنی؟"

    # say L800 bil
    old "Tsk, of course I can, come on [pla] let's do it!"
    new "تسک، حتماً می‌تونم، بیا [pla] بیای بیا!"

    # say L810 bil
    old "I still can't believe you pack this much."
    new "هنوز باور نمی‌کنم اینقدر داری."

    # say L811 bel
    old "Are you nervous?"
    new "متوتری؟"

    # say L812 bil
    old "Of course not. I was just saying."
    new "البته نه. فقط می‌گفتم."

    # say L828 bil
    old "Ok, this has been fun. But what do you say about taking this to the next level?"
    new "خب، اینا خوشحالم. ولی چطور می‌گیهیم این رو به مرحله بعد ببریم؟"

    # say L830 bel
    old "The next level? Hasn't this been enough?"
    new "مرحله بعدی؟ این هم کافی نبود؟"

    # say L831 bil
    old "No, I'm talking about something extreme, How about we go to the haunted house here in town?"
    new "نه، من در مورد چیزی شدید‌تر صحبت می‌کنم. چطور اگه به خانه ترسناک شهر برویم؟"

    # say L832 pla
    old "Haunted house?"
    new "خانه ترسناک؟"

    # say L833 bil
    old "Yeah that's right. There's a house in town with vampires. Why don't we go?"
    new "بله همینه. توونه یک خانه در شهر هست که وامپایرها توونه. چرا نمی‌رویم؟"

    # say L834 bel
    old "Ohh, you're talking about the old mansion."
    new "اوه، می‌گویی از آن خانه قدیمی."

    # say L836 pla
    old "B- but you said vampires. Which vampires?"
    new "ولی تو گفتی وامپایر. چه وامپایری؟"

    # say L838 bil
    old "There's a legend about that house, that says there are vampires in there."
    new "داستانی درباره اون خانه هست، می‌گن توی اون جا وامپایر هستند."

    # say L839 bil
    old "All its inhabitants are women, people say that they have been seen kidnapping men, to then suck all of their blood out."
    new "همه ساکنان آن خانه زن هستند، می‌گویند آنها مردان را ربوده و تمام خونشان را می‌کشوند."

    # say L840 bil
    old "And leave them completely dry."
    new "و آنها را کاملاً خشک می‌گذارند."

    # say L842 bil
    old "Besides, it is said that they are all very pale, and apparently they only go out at night. Never in the sunlight. Surely to pick up another victim."
    new "البته، می‌گن همه خیلی سفید پوست هستند و به نظر می‌رسه فقط شب‌ها بیرون می‌آیند. هرگز در نور خورشید نمی‌بینن. احتمالاً برای اینکه قربانی جدیدی بیابن."

    # say L843 bel
    old "Yeah, yeah, yeah. It's super creepy and spooky, let's go!"
    new "بله، بله، بله. خیلی ترسناک و وحشتناکه، برویم!"

    # say L844 pla
    old "Uhh... I- I'm not sure I want to go there."
    new "اوه... من نمی‌دونم می‌خوام اونجا برم."

    # say L845 bil
    old "Aww, are you that much of a wuss? Come on, have some guts."
    new "اوه، اینقدر خرسی هستی؟ بیا، شجاعتی داشته باش."

    # say L846 pla
    old "I'm not a wuss... Ok, let's do it then."
    new "من نه خرسی هستم... خب، بیا بزنیم."

    # say L855 bel
    old "Wow guys, this really feels sinister. It's quite terrifying."
    new "وای، جون‌ها، این واقعاً وحشتناک است. خیلی ترسناک است."

    # say L856 pla
    old "Y-y-yeah, this is very scary. Maybe we should head back."
    new "بله، این خیلی ترسناکه. شاید باید برگردیم."

    # say L857 bil
    old "What? No, we're not doing that. We've gotta keep playing. And it's your turn again [pla]."
    new "نه، ما این کار رو نمی‌کنیم. باید ادامه بدیم. و دوباره دورت هست [pla]."

    # say L858 bil
    old "And since you are spiderman... I dare you to climb up to the roof."
    new "و چون تو سپیدرمن هستی... جرات می‌کنم تا بالای دکه بری."

    # say L859 pla
    old "W-what? B-but..."
    new "چ-چه؟ اما..."

    # say L860 bil
    old "It's a dare, isn't it? We accomplished ours very well."
    new "این یه چالش نیست؟ ما هم خوب انجامش دادیم."

    # say L861 bil
    old "And you seemed to enjoy those a lot. Didn't you? it would be unfair if you chicken out now. Do it!"
    new "و تو به نظر می‌رسید خیلی لذت برده‌ای. نیست؟ این جوری از کارهایی که با همتون کردیم، فرار کردن احتمالاً غیرعادلانه است. بیا، انجام بده!"

    # say L862 pla
    old "Hmph, fine. I'll do it."
    new "هم، خوب. انجام میدم."

    # say L863 bil
    old "But use all the suit, even with the mask, just like spiderman."
    new "اما از لباس کامل استفاده کن، حتی با ماسک، مثل اسپایدرمن."

    # say L864 pla
    old "Really? Hmm, Alright."
    new "حقاً؟ هم، خوب."

    # say L870 bel
    old "That's it! Yes, you're doing well!"
    new "این هستش! بله، خوب کار می‌کنی!"

    # say L873 bil
    old "Keep going! You can't just stop halfway up! You have to make it to the roof!"
    new "ادامه بده! نمی‌تونی همین‌جوری نیمه‌راه توقف بدی! باید به سطح برسی!"

    # say L876 pla
    old "I know, ugh! I know!"
    new "می‌دونم، اوه! می‌دونم!"

    # say L882 pla
    old "Ok! I made it all the way up! Just wait there, I'm gonna go down again!"
    new "بله! من تا بالای همه رسیدم! فقط جا بنشین، دوباره پایین می‌آیم!"

    # say L883 bil
    old "Yeah sure! You made it, come down!"
    new "بله حتماً! خوب، بیا پایین!"

    # say L891 pla
    old "AAAAAAH!!"
    new "آاااه!!"

    # say L895 bil
    old "[pla]! [pla]! Can you hear us [pla]?! Talk to us!"
    new "[pla]! [pla]! می‌شنوی ما رو [pla]؟! باهام حرف بزن!"

    # say L896 bel
    old "We're going to get some help! Just hang in there!"
    new "ما کمکی می‌آوریم! فقط صبر کن!"

    # say L909 pla
    old "W- what is this? W- where I-?"
    new "W- این چیه؟ W- من کجاستم؟"

    # say L940 pla
    old "Ugh!! My god, what happened? Why does my head hurt so much?"
    new "اوه!! خداوند، چه چیزی اتفاق افتاد؟ چرا سرم آنقدر درد می‌کنه؟"

    # say L946 lad
    old "Oh, Hello! You're finally awake, I'm glad you woke up. I was thinking that if you didn't, I might have to call an ambulance."
    new "اوه، سلام! خوشحالم که از خواب بیدار شدی. فکر می‌کردم اگه نبیدار می‌شدی، مجبور می‌شدم اتومبیل اورژانس رو بگرم."

    # say L947 pla
    old "Whoa! Ah... W- where am I?"
    new "وای! اوه... و- واقعاً کجاهستم؟"

    # say L948 lad
    old "Calm down, this is my house. You fell in here yesterday while you were playing on our roof."
    new "آرام شو، این خانه من است. دیروز وقتی روی سقف بازی می‌کردی، وارد اینجا شدی."

    # say L949 pla
    old "Y- your house?"
    new "خانه‌ت؟"

    # say L950 lad
    old "Yes, that's right. Maybe you thought you actually were spiderman?"
    new "بله، همین‌طور. شاید فکر کردی واقعاً اسپایدرمن هستی؟"

    # say L952 pla
    old "Oh my God! It's morning already?!"
    new "اوه خداوند! قراره قراره صبح باشه؟!"

    # say L953 pla
    old "I- I have to go, [mo1rel] must be worried sick about me."
    new "من- من باید برسم، [mo1rel] حتماً خیلی نگران من شده."

    # say L954 lad
    old "Are you already leaving?"
    new "اینطور می‌خوای بری؟"

    # say L955 pla
    old "Y- yes, but don't worry, I promise I'll come back to fix your roof."
    new "بله، اما نگران نباش، قول می‌دم برای اصلاح سقفت بازم می‌گردم."

    # say L956 lad
    old "Ok, if you say so. Be careful though. You got a big hit there."
    new "باشه، اگهی می‌گی، ولی مراقب خودت با. ضربتی سخت برداشتی."

    # say L972 mo1
    old "Dear, you're home! Oh my god! You had me so worried. Where were you?!"
    new "عزیزم، تو خانه‌ای! خدا نجات داد! اینقدر نگرانت شدم. تو کجا بودی؟!"

    # say L973 pla
    old "S- sorry [mo1rel]. Me and my friends went trick or treating yesterday after school was over."
    new "ببخشید ز[mo1rel]. من و دوست‌هامون دیروز پس از پایان مدرسه به خانه‌های همسایگان رفتیم تا شیرینی بگیریم."

    # say L974 pla
    old "And after we were done Mike invited me to stay at his house."
    new "و بعد از اون کار مایک دعوت کرد من رو به خونه‌اش برم."

    # say L975 mo1
    old "That's not a problem. But why didn't you call to let us know where you were?!"
    new "این مشکلی نداره. ولی چرا نتونستی تلفن کنی تا بدونیم جایت کجاست؟!"

    # say L976 pla
    old "I- I guess I just lost track of time and then forgot about it. Sorry [mo1rel] I didn't mean to scare you."
    new "من- من حدس زدم فقط وقت رو از دست دادم و بعد فراموش کردم. ببخش [mo1rel] من قصد نداشتم ترسونم."

    # say L977 mo1
    old "Well you did! You're an adult, so you can do whatever you want, but at least call to let me know about this sort of thing."
    new "خب انجام دادی! تو بزرگ هستی، می‌تونی هر کاری که می‌خوای بکنی، اما حداقل بفرمای تلفنی بده و من رو مطلع کنی از این جور چیزها."

    # say L978 pla
    old "You're right, my bad."
    new "درست می‌فرمایی، اشتباه کردم."

    # say L979 mo1
    old "It's ok honey, I'm just happy to see you're safe."
    new "خب حلو، خوشحالم که دیدم امنیتت رو حفظ کردی."

    # say L980 pla
    old "Thanks [mo1rel]. By the way, I've gotta get ready for school."
    new "ممنون ز[mo1rel]. براش اینکه، باید آماده‌ی مدرسه بشم."

    # say L985 pla
    old "Ohh, what a crazy day yesterday was. I can't believe we did all that."
    new "اوه، چه روز خیلی پرروی دیروز بود. نمی‌تونم باور کنم همه اونا رو انجام دادیم."

    # say L986 pla
    old "I would like to rest a little bit more. But I guess I better get to school. I don't want to give Ms. Mia any more reasons to suspend me."
    new "می‌خواستم کمی بیشتر استراحت کنم. اما به نظر می‌رسه باید به مدرسه برسم. نمی‌خوام خانم میا دلیل بیشتری برای اخراج من پیدا کنه."

    # say L1113 pla
    old "Hey girls, how are you?"
    new "سلام دختران، چطور هستون؟"

    # say L1117 bil
    old "Are you really ok? We went asking for assistance but when we came back you weren't there."
    new "مطمئنی؟ ما برای کمک رفتیم ولی وقتی برگشتیم تو جایی نبودی."

    # say L1118 bil
    old "We were very worried because we didn't know where you went."
    new "ما خیلی نگران شدیم چون نمی‌دونستیم تو کجا رفتی."

    # say L1119 pla
    old "Yeah, sorry about that. But to be honest I don't know what happened either."
    new "بله، معذرت. ولی صدای حقیقی نمی‌دونم چه اتفاقی افتاد."

    # say L1120 pla
    old "All I remember was hitting the ground really hard, and you calling out for me. But then I passed out."
    new "من فقط به خاطر دارم که خیلی سخت به زمین خوردم و تو صدا می‌زدی برای من. ولی بعد از آن بی‌وعی شدم."

    # say L1121 pla
    old "I imagined it was the lady who moved me."
    new "فکر کردم خانمی بود که منو جابجا کرده."

    # say L1123 bil
    old "Lady? You're talking about the vampire?!"
    new "Lady؟ تو درباره آن وامپیر حرف می‌زنی؟!"

    # say L1124 pla
    old "Uhhh, I- I don't know, I just met her this morning when I woke up, apparently she took care of me."
    new "اوه، من- من نمی‌دونم، فقط امشب صبح وقتی بیدار شدم باهاش آشنا شدم، به نظر می‌رسه او مرا مراقبت کرده."

    # say L1125 bel
    old "Whoa! And how was it? Weren't you scared?"
    new "وای! و چطور بود؟ نترسیدی؟"

    # say L1126 pla
    old "Me? Not really? I was only surprised, because she wasn't angry. In fact, she was really nice to me."
    new "من؟ خیر، واقعاً نه. فقط تعجب کردم، چون او خشمگین نبود. در واقع، به من خیلی لطف داشت."

    # say L1127 pla
    old "I promised to come back later and fix the damage I did to her roof."
    new "بله، قول دادم بعداً برگردم و خرابی‌ای که به سقفش کردم را تعمیر کنم."

    # say L1128 bil
    old "Whoa! Well I guess it's better that way."
    new "وای! خب بهتره اینجوری."

    # say L1130 bel
    old "Yeah, after all, you did ruin her roof. So, it's better if you fix it."
    new "بله، در نهایت تو سقف خونه‌اش رو خراب کردی. پس بهتره که اینجوری باشه و تو آن را تعمیر کنی."

    # say L1132 bil
    old "Yeah, I think I went a little overboard with that last dare."
    new "بله، به نظر می‌رسه آخرین چالش رو خیلی جدی گرفتم."

    # say L1133 bil
    old "I promise I'll make it up to you next time we play. Right Belle?"
    new "بله، قول می‌دم بعداً وقتی دوباره بازی می‌کنیم جبران کنم. درسته بله؟"

    # say L1134 bel
    old "Yeah, for sure."
    new "بله، حتماً."

    # say L1135 pla
    old "Well, I didn't think I would want to play that again."
    new "خب، فکر نکردم بخواهم دوباره این بازی رو بازی کنم."

    # say L1136 pla
    old "But if it's going to be like you say, then count me in for next time."
    new "ولی اگه مثل همین باشه، من برای بار بعد هم شرکت می‌کنم."

    # say L1138 bel
    old "Well, we have classes now. See you later."
    new "خب، الان کلاس‌هامون هست. بعداً می‌بینیم."

    # say L1139 pla
    old "Alright, see you girls."
    new "باشه، بعداً می‌بینم دختران."

    # say L1156 hin
    old "G- good morning [pla]. How are you?"
    new "صبح بخیر [pla]. حالت چطوره؟"

    # say L1158 pla
    old "Hey Hinn. I'm fine, thank God I get to see you today."
    new "هین. خوبم، شکر خدا امروز می‌تونم تو رو ببینم."

    # say L1159 pla
    old "Hey, listen, I've been thinking, and I'm sorry about the way things ended up yesterday, me and the girls took it a little too far."
    new "بله، هین، من هم اینجوری فکر می‌کردم و برای نحوه پایان دادن به اوضاع دیروز عذرخواهم، من و دختران کمی خیلی دور رفتیم."

    # say L1161 hin
    old "It's ok, actually I wanted to say sorry to you."
    new "خوبه، در واقع من هم می‌خواستم از تو بپذیرم."

    # say L1162 hin
    old "To be honest, I'm still not used to being that open. It's ok when I'm with you and Dr. Johnson."
    new "صusch: به صراحه، هنوز آدم خودمو باز نمی‌کنم. وقتی با تو و دکتر جانسون هستم، خوبه."

    # say L1163 hin
    old "But if things turn sexual when there's other people around, and watching me, I just freeze."
    new "اما وقتی کار جنسی می‌شه و افراد دیگه هم حاضر هستن و به من نگاه می‌کنن، من فقط متوقف می‌شم."

    # say L1164 hin
    old "And yesterday things got a little too dense for my liking, so I couldn't handle it, and took off."
    new "و دیروز همه چیز خیلی گرم شد و من نتونستم تحمل کنم، پس رفتم."

    # say L1165 hin
    old "S- sorry for leaving like that, I hope I didn't ruin your night."
    new "ببخشید که اونجور برداشتم، امیدوارم شبتو خراب نکردم."

    # say L1166 pla
    old "No, not at all! You didn't ruin anything."
    new "نه، هیچ جور! تو هیچ چیز رو خراب نکردی."

    # say L1168 pla
    old "Yes, really. I'm just happy to see you're doing fine."
    new "بله، واقعاً. خوشحالم که می‌بینم حالت خوبه."

    # say L1169 hin
    old "Thank you [pla]."
    new "ممنون [pla]."

    # say L1170 hin
    old "But... honestly, I don't think I'm that well..."
    new "ولی... صادقانه، فکر نمی‌کنم اینقدر خوب باشم..."

    # say L1172 hin
    old "Well, I- I've been thinking... maybe I could talk with Dr. Johnson again, take a couple more lessons from her."
    new "البته، من- من فکر کردم... شاید بتوانم دوباره با دکتر جانسون صحبت کنم، ازش چند درس بیشتر بگیرم."

    # say L1173 pla
    old "Really? Do you feel you need it?"
    new "وای، مطمئنی؟ آیا فکر می‌کنی این به تو لازم هست؟"

    # say L1174 hin
    old "I do. I know she's already helped me a lot. But it can't hurt to keep working on things. There's always room for improvement"
    new "بله. میدونم قبلاً خیلی به من کمک کرده. اما هیچ جور ضرری نداره که بیشتر روی اینا کار کنم. همیشه جای بهبودی وجود داره."

    # say L1176 pla
    old "Hmm, well, if you think it's the best thing for you, I support you completely."
    new "Hmm، خب، اگر فکر می‌کنی برایت بهتره، من کاملاً حمایت می‌کنم."

    # say L1177 hin
    old "Thank you, your support does mean a lot to me. Also, would you come with me? To the sessions? I think it's easier with you there."
    new "ممنون، حمایت تو برای من خیلی مهمه. همچنین، آیا می‌تونی با من بیادی؟ به جلسات؟ فکر می‌کنم با وجود تو راحت‌تره."

    # say L1178 pla
    old "Of course I will, if you need me, I'm more than happy to help you."
    new "البته، اگر نیازت به من هست، خوشحال می‌شوم که بهت کمک کنم."

    # say L1179 hin
    old "Thanks again [pla] I knew I could count on you."
    new "ممنون دوباره [pla] می‌دونستم می‌تونم بر تو اعتماد کنم."

    # say L1181 pla
    old "Oh! Look at the time, I think we better get to class."
    new "اوه! نگاه کن به ساعت، فکر کنم بهتره که به کلاس بریم."

    # say L1182 hin
    old "Yeah, if not Ms. Mia will be angry."
    new "بله، اگر نه خانم میا خشمگین می‌شه."

    # say L1183 pla
    old "You are right. let's go."
    new "درست می‌فرمایی. برویم."

    # say L1198 pla
    old "Good morning ma'am, how are you?"
    new "صباح خیر خانم، حالتون چطوره؟"

    # say L1199 lad
    old "Ohh! This is a surprise... I didn't think you were gonna come back."
    new "اوه! این مفاجا است... فکر نکردم برمی‌آیی."

    # say L1200 pla
    old "No, I couldn't do that. I said I was gonna fix it, and that's what I'll do."
    new "نه، نمی‌تونستم اینجوری کنم. گفتم می‌خوام اصلاحش کنم، و همینجوری خواهم کرد."

    # say L1201 lad
    old "Well, isn't that nice?"
    new "البته، این خوبه."

    # say L1202 lad
    old "Truth be told, I had already prepared some tools to fix it myself. But if you're gonna do it I'll lend them to you."
    new "صداقت بگم، من قبلاً ابزارهایی برای اصلاحش آماده کرده بودم. اما اگر شما می‌خواهید انجام بدید، به شما اونا رو قرض می‌دم."

    # say L1203 pla
    old "Thank you ma'am. I promised it's going to be as good as new when I'm done."
    new "ممنون می‌خانم. قول میدم وقتی تمام شد مثل جدید باشه."

    # say L1204 lad
    old "That's really nice of you, thank you."
    new "این خیلی لطف دارید، ممنون."

    # say L1205 pla
    old "So, where are the tools and materials?"
    new "پس، ابزارها و مواد کجا هستن؟"

    # say L1206 lad
    old "Oh, they're in the next room, in the garage."
    new "اوه، توی اتاق بعدی هستن، توی گاراژ."

    # say L1207 lad
    old "The damage isn't that small, so it's going to take you a while to finish completely, you may have to come a couple more times."
    new "خسارت خیلی کوچک نیست، پس برای اتمام کامل کار وقت زیادی لازم است، شاید باید چند بار دیگر هم بیایید."

    # say L1209 pla
    old "That's fine, it was my fault, so it doesn't matter to me how much time it takes. I'll fix it completely."
    new "خوبه، این خرابی از برام بود، پس مهم نیست چقدر زمان ببره. من کاملاً اون رو اصلاح می‌کنم."

    # say L1210 pla
    old "And once again ma'am. I'm sorry for doing that."
    new "و دوباره خانم، متاسفم که اینجوری شد."

    # say L1211 lad
    old "It's ok, what's important it's that you came back, and by the way, I'm Alcina Dimitrescu."
    new "خوبه، مهم اینه که برگشته‌ای، و بین‌النهرین، من آلسینا دیمیترسکو هستم."

    # say L1212 pla
    old "Ohh sorry... I haven't told you my name. I'm [pla], nice to meet you."
    new "اوه خواهش می‌کنم... اسم من هنوز به تو نگفتم. من [pla] هستم، خوشحالم که با تو آشنا شدم."

    # say L1214 lad
    old "Oh don't worry, nice to meet you too [pla]..."
    new "اوه نگران نباش، خوشحالم که با تو آشنا شدم [pla]..."

    # say L1215 lad
    old "I'll be in the next room if you need me. I won't take more of your time and let you start your work..."
    new "اگر نیازی داشتی من در اتاق بعدی هستم. وقت بیشتری ازت نمی‌گیرم و اجازه می‌دم کارتو شروع کنی..."

    # say L1216 pla
    old "All right, thank you."
    new "البته، ممنون."

    # say L1227 lad
    old "Congratulations! You made a lot of progress today."
    new "تبریک! امروز پیشرفت زیادی کردی."

    # say L1228 lad
    old "You're very fast, and it's all very well done."
    new "شما خیلی سریع هستید و همه چیز خیلی خوب انجام شده."

    # say L1229 pla
    old "Thank you ma'am. I'm glad you like my progress."
    new "ممنون می‌خانم. خوشحالم که پیشرفت من را دوست دارید."

    # say L1230 pla
    old "I'm sure if I keep going at this pace it'll be ready very soon."
    new "البته، اگر این سرعت را حفظ کنم، زود خواهد بود آماده."

    # say L1231 lad
    old "Sure, I have no doubt about it. Very nice."
    new "البته، شکی در این ندارم. خیلی خوب."

    # say L1232 pla
    old "Thank you ma'am."
    new "ممنونم خانم"

    # say L1233 pla
    old "It's a little late, so I think I should be going home. But I'll come back soon."
    new "الان کمی دیره، پس فکر کنم باید برگردم. اما زودی می‌گردم."

    # say L1234 lad
    old "Oh yeah, don't worry, go home, I'll see you later then."
    new "البته، نگران نباش، برو خونه، بعداً دوباره می‌ایی."

    # say L1247 pla
    old "Hmm, this is harder than I expected."
    new "Hmm، این سخت‌تر از آنچه فکر می‌کردم است."

    # say L1248 pla
    old "Sorry for doing so little. But I'm sure next time I'll progress a lot more."
    new "ببخشید که کار کمی انجام دادم. ولی مطمئن هستم دفعه بعد پیشرفت بیشتری خواهم کرد."

    # say L1249 lad
    old "Well, you didn't do much today, but I understand, it's a big job after all. "
    new "خب، امروز خیلی کار نکردی، اما من درک می‌کنم، این کار بزرگی هست در نهایت."

    # say L1250 lad
    old "Don't worry about the progress, I know you'll make it."
    new "نگران پیشرفت نباش، مطمئن هستم که تو قدم خواهی برداشت."

    # say L1251 pla
    old "Yeah, thank you. I'll come back later and keep working on it."
    new "بله، ممنون. بعداً برگشتم و ادامه می‌دم."

    # say L1252 lad
    old "Yes, it's a little late, so you should go home and come another time."
    new "بله، الان کمی دیره، پس باید بروی خانه و بعداً بیایی."

    # say L1253 pla
    old "You are right. Thank you."
    new "درست می‌فرمایید. ممنون."

    # say L1263 pla
    old "Hmm, listen, ma'am before I leave, may I ask you something?"
    new "خانم، قبل از برخاست، می‌تونم یه سوال بپرسم؟"

    # say L1264 lad
    old "And what may that be?"
    new "و آن چه است؟"

    # say L1265 pla
    old "Well, I'm a little ashamed to admit this."
    new "خب، یک کم خجولانه‌ام که اینو بگم."

    # say L1266 pla
    old "But the reason I crashed into your living room the other day was because a couple of my friends dared me to climb your roof."
    new "اما دلیل اینکه روزی به اتاق نشیمن تو خوردم این بود که چند تا دوستم به من چالش زدند که روی خانه‌تو برم."

    # say L1268 lad
    old "And why did they do that?"
    new "و چرا اونا این کار رو ازت خواستن؟"

    # say L1269 pla
    old "Well... it's because there are some rumors about this house being haunted."
    new "خب... چون گفتن این خانه مسکونی هست."

    # say L1271 lad
    old "Haunted you say?"
    new "می‌گی‌ای مسکونی هست؟"

    # say L1272 pla
    old "Yeah... I mean, I don't believe them now, but that's what they say."
    new "بله... منظورم اینه که حالا من بهش باور ندارم، اما همین‌طور می‌گن."

    # say L1273 pla
    old "And, that's not all of it..."
    new "و این همه نیست..."

    # say L1274 lad
    old "It isn't?"
    new "نه؟"

    # say L1276 pla
    old "Well, apparently there's a story about a group of vampires living here..."
    new "به نظر می‌تونه داستی در مورد گروهی از وامپایر‌ها که اینجا زندگی می‌کنن وجود داشته باشه..."

    # say L1277 lad
    old "Is that so? And what do you think? Do I look like a vampire to you?"
    new "آره؟ و تو چه فکر می‌کنی؟ من مثل یک وامپایر به نظر می‌رسم؟"

    # say L1278 pla
    old "O- of course not. I just wanted to apologize for the reason I climbed your roof. Because the rumor isn't true, right?"
    new "البته نه. فقط می‌خواستم برای اینکه روی خانه‌ات رفتیم عذرخواهی کنم. چون این شایعه درست نیست، درسته؟"

    # say L1279 lad
    old "Hehe, of course not. Seriously, kids these days have some imagination."
    new "هه هه، البته نه. جدی، بچه‌ها امروزه خیال‌پردازی می‌کنند."

    # say L1280 lad
    old "But now it's not the time for that, it's very late and I think you need to go home."
    new "اما حالا وقت آن نیست، خیلی دیره و فکر می‌کنم باید به خونه بری."

    # say L1282 pla
    old "You're right, sorry for bothering you with all of this."
    new "درست می‌فرمایی، معذرت که با همه این چیزها توی راهت آمدم."

    # say L1283 pla
    old "And don't worry, I'll come soon to keep working on the roof."
    new "و نگران نباش، زودی می‌آیم تا کار سقف رو ادامه بدم."

    # say L1284 lad
    old "I really appreciate your help. Have a good night."
    new "ممنون از کمکت. شب خوبی داشته باش."

    # say L1301 pla
    old "Hello again lady Dimitrescu. How are you today?"
    new "سلام دوباره خانم دیمیترسکو. امیدوارم امروز حالت خوب باشه."

    # say L1302 lad
    old "Hello [pla], I'm fine. You've come to keep working on the roof?"
    new "سلام ز[pla]، خوبم. اومدی برای ادامه کار روی سقف؟"

    # say L1303 pla
    old "Yes ma'am. I'm going to get to it right away. So, I can finish it as soon as I can."
    new "بله خانم. همین الان شروع می‌کنم. تا بتونم سریع‌تر تمام بشه."

    # say L1304 lad
    old "Oh perfect. Well, I'll leave you to it. If you need me, I'm in the room next door."
    new "اوه عالی. خب، من شما رو به کار می‌گذaram. اگر نیاز به من داشتی، من در اتاق کنار هستم."

    # say L1310 pla
    old "Excuse ma'am, but before I go home, there's something else I'd like to ask you about."
    new "ببخشید خانم، ولی قبل از برگشتن به خونه، چیزی هست که می‌خوام از شما بپرسم."

    # say L1312 lad
    old "Perhaps another rumor?"
    new "شاید خبر دیگری؟"

    # say L1313 pla
    old "No, no. Nothing like that. It's just... After I fell and passed out. I remember waking up for a brief moment. "
    new "نه، نه. هیچ جور. فقط... بعد از اینکه افتادم و بی‌وعی شدم. به یاد دارم برای لحظه‌ای بیدار شدم."

    # say L1314 pla
    old "And I could swear I saw you with someone else, watching me."
    new "و می‌تونم قسمت که دیدم تو رو با کسی دیگه، به من نگاه می‌کردند."

    # say L1316 lad
    old "S- someone else, heh... What do you mean?"
    new "کسی دیگر، هه... منظورت چیه؟"

    # say L1317 pla
    old "Well, I saw two young ladies, they kinda looked like you. But I'm not sure..."
    new "خب، دو تا دختر جوان دیدم، مثل تو بودن. اما مطمئن نیستم..."

    # say L1318 lad
    old "Hmm, sorry [pla], but I was alone when I picked you up."
    new "Hmm، معذرت [pla]، اما وقتی تو رو برداشتم من تنها بودم."

    # say L1319 lad
    old "I think you must have seen some kind of hallucination or something."
    new "فکر می‌کنم باید گل‌بینی یا چیزی مشابه دیده‌ای."

    # say L1320 pla
    old "Are you sure? It felt so real..."
    new "مطمئنی؟ خیلی واقعی به نظر می‌رسید..."

    # say L1321 lad
    old "Yes I'm sure. Now, It's getting very late, so you should go home now."
    new "بله مطمئن هستم. حالا، خیلی دیر شده، پس باید بروی خانه."

    # say L1322 pla
    old "Hmm, ok. I think you're right. Bye ma'am."
    new "Hmm، اوکی. فکر کنم همین درسته. خداحافظ مادام."

    # say L1323 lad
    old "Have a good night, [pla]."
    new "شب خوبی داشته باشید، [pla]."

    # say L1338 pla
    old "Ok! That's it for today. It's almost done."
    new "باشه! امروز همه‌ش اینجاست. تقریباً تمام شده."

    # say L1339 lad
    old "Wow! Look at how much you have done already! I think you only need to come back one more time and you will have finished."
    new "واو! نگاه کن به همه کاری که انجام دادی! فکر کنم فقط یک بار دیگه باید برگردی و تمام خواهد شد."

    # say L1340 pla
    old "Thank you ma'am, I'm happy you like how the repairs are going, I also think I only need to come once more, and it'll be ready."
    new "ممنون می‌خانم، خوشحالم که اصلاحات رو دوست دارید. من هم فکر می‌کنم فقط یه بار دیگه باید بیام، بعد از آن آماده خواهد بود."

    # say L1341 lad
    old "I'm astounded at how fast you are, you're a very good worker."
    new "می‌تونم با سرعتت شگفت‌زده برم، تو کارگر خوبی هستی."

    # say L1342 pla
    old "Thank you very much!"
    new "بسیار ممنونم!"

    # say L1343 pla
    old "Well, I think I'll head home. I'll be sure to come back and finish."
    new "خب، فکر کنم برم خونه. حتماً برگشتم و تمامش کنم."

    # say L1348 lad
    old "Wait! [pla]"
    new "منتظر بمان! [pla]"

    # say L1351 pla
    old "Yes? Is there a problem?"
    new "بله؟ مشکلی هست؟"

    # say L1352 lad
    old "A problem? No, no, nothing like that, I just wanted to thank you once again for how well the repairs are going."
    new "مشکلی؟ نه، نه، هیچ مشکلی نداره، فقط می‌خواستم دوباره ازت تشکر کنم که تعمیرات خوب پیش می‌ره."

    # say L1353 lad
    old "Being completely honest, I didn't think you were actually going to do it. But I'm glad I was wrong."
    new "با صداقت کامل، فکر نمی‌کردم واقعاً این کار رو انجام بدی. ولی خوشحالم که اشتباهم بود."

    # say L1354 pla
    old "Well, it's not a problem at all. It was my fault that the roof broke in the first place, I feel like it's only fair that I handle the repairs."
    new "خب، هیچ مشکلی نداره. اصلاً اشتباه من بود که سقف شکست، برام عادلانه است که تعمیرات رو انجام بدم."

    # say L1356 lad
    old "Well, I'm happy that you're such an upstanding young man."
    new "خوشحالم که شما چنین جوان محترمانه‌ای هستید."

    # say L1357 lad
    old "And another thing..."
    new "و یک چیز دیگر..."

    # say L1358 pla
    old "Yes?"
    new "بله؟"

    # say L1359 lad
    old "It's about those rumors that you mentioned. The truth is I have actually heard of them as well."
    new "البته در مورد آن شایعاتی که اشاره کردی. در واقع من هم از آنها شنیده‌ام."

    # say L1360 pla
    old "You knew about them?"
    new "میدونستی در مورد اون ها؟"

    # say L1361 lad
    old "Of course I did. it's difficult not to notice when people look at me and murmur wherever I go."
    new "البته میدونستم. وقتی مردم به من نگاه می‌کنند و در پشت من گفتگو می‌کنند، خیلی سخته که متوجه نشدم."

    # say L1362 lad
    old "But some people are even worse, they come to my house and try to sneak in, or to get pics of the 'vampire lady'."
    new "ولی بعضی از مردم حتی بدتر هستند، به خانه‌ام می‌آیند و سعی می‌کنند وارد شوند یا عکس‌هایی از «خانم وامپیر» ببرند."

    # say L1363 lad
    old "It's really stressful, so I was a bit cautious of your intentions at first."
    new "واقعاً استرس‌زا هست، پس اول یه کم احتیاطی از قصدت داشتم."

    # say L1364 pla
    old "Ohh, I- I see, I'm sorry things are like that. It must be so awkward to have to deal with that all the time."
    new "اوه، من- من متوجه شدم، خیلی متاسفم که اینجوریه. باید خیلی سخت باشه که همیشه با این مشکلات روبرو باشی."

    # say L1366 lad
    old "Oh yeah, it's tremendously stressful... Actually, there is a reason why those rumours exist."
    new "اوه بله، این خیلی استرس‌زا است... در واقع، دلیلی هست که این شایعات وجود دارند."

    # say L1367 pla
    old "Uhh? What do you mean?"
    new "اوه؟ منظورت چیه؟"

    # say L1368 lad
    old "Well, as I said, I was a bit cautious of you, but I think you've managed to keep your word."
    new "خب، همانطور که گفتم، از شما کمی مترددم، اما به نظر می‌رسد که قول خودتون رو نگه داشتین."

    # say L1369 lad
    old "And I realize I haven't been completely honest with you..."
    new "و متوجه شدم که به تو کاملاً صادق نبودم..."

    # say L1370 lad
    old "So, let me tell you the truth; it would be good if at least one person in town knows things as they really are."
    new "پس بگذار برایت حقیقت رو بگم؛ خوبه که حداقل یک نفر در شهر همه چی رو مثل آنطور که هست بداند."

    # say L1373 lad
    old "I suffer from a rare condition in which my body is unable to produce a certain type of amino acid."
    new "من از یک بیماری نادر رنج می‌برم که در آن بدن من نمی‌تواند نوع خاصی از اسید آمینه تولید کند."

    # say L1374 lad
    old "Not all of them, but this particular one is very important. Do you know what that means [pla]?"
    new "همه آنها نه، اما این یکی خیلی مهم است. می‌دونی این چه معنا داره [pla]؟"

    # say L1375 pla
    old "Hmm, not really."
    new "Hmm، نه واقعاً."

    # say L1376 lad
    old "Haha, it means that I'm unable to produce and store a type of protein that the body needs to function properly."
    new "هahaha، این به معنای اینه که من نمی‌تونم یک نوع پروتئین رو که بدن برای کار کردن بهش نیاز داره تولید و ذخیره کنم."

    # say L1378 pla
    old "Ohh..."
    new "اوه..."

    # say L1379 lad
    old "As I said, it's not all of them, I'd be dead if it was like that. But this one is crucial nonetheless."
    new "همانطور که گفتم، همه آن‌ها نیستند، اگر اینجوری بودم مرده بودم. اما این یکی هم همچنان مهم است."

    # say L1380 lad
    old "Nor am I able to absorb it from the usual sources, like meat and vegetables."
    new "همچنین نمی‌توانم آن را از منابع معمولی مثل گوشت و سبزیجات جذب کنم."

    # say L1381 pla
    old "So, does that mean your health is in danger?"
    new "پس، این به معنی اینه که سلامتت خطر داره؟"

    # say L1382 lad
    old "Hmm kind of. My body it's very delicate to certain things. For example, I'm unable to go directly into the sunlight."
    new "همین‌جوری. بدن من برای برخی چیزها خیلی حساسه. مثلاً نمی‌تونم مستقیماً به نور خورشید برسم."

    # say L1383 lad
    old "If I did, I would start suffering from strong allergic reactions. So, every time I go outside it has to be during the nighttime."
    new "اگر اینجوری کنم، واکنش‌های آلرژیک شدیدی می‌یافتم. پس هر باری که برم خارج، باید در شب باشه."

    # say L1384 pla
    old "Ohh, so, is that why people think you're a vampire?"
    new "اوه، پس این به همین خاطر هست که مردم فکر می‌کنن تو وامپایری هستی؟"

    # say L1385 lad
    old "Well, that and my appearance, that's also the result of my disease."
    new "خب، این و همچنین مظهرم، این هم نتیجه بیماری من است."

    # say L1386 lad
    old "This amino acid helps with the creation of melanin, which is what gives colour to the skin."
    new "این امینو اسید به ساخت ملانین کمک می‌کنه، که این هم خودش باعث رنگ پوست می‌شه."

    # say L1387 lad
    old "So I'm very white, and my eyes are pale."
    new "پوستم خیلی سفیده و چشم‌هام هم روشن است."

    # say L1388 pla
    old "Oh, I get it now."
    new "اوه، حالا فهمیدم."

    # say L1389 lad
    old "Yeah, and I understand them, if somebody who looks like me it's only seen outside at night. And well... people talk..."
    new "بله، و من این را می‌فهمم، اگر کسی مثل من فقط شب‌ها بیرون بیاید. و خب... مردم حرف می‌زنن..."

    # say L1391 pla
    old "But, it's not fair, I mean, you can't judge people just because of their appearance."
    new "اما این عادلانه نیست، منظورم اینه که نمی‌تونی انسان‌ها رو فقط بر اساس ظاهرشون قضاوت کنی."

    # say L1392 lad
    old "Well, is not just that. The thing is, since I'm unable to produce this substance, I have to obtain it from a different source."
    new "خب، فقط این نیست. مشکل اینجاست که چون من نمی‌توانم این ماده را تولید کنم، باید از منبع دیگری آن را به دست آورم."

    # say L1393 pla
    old "But you said you couldn't get it from food either..."
    new "ولی تو گفتی نمی‌تونی از غذا هم بگیری..."

    # say L1394 lad
    old "That's right, I can't get it from food. But there's something else that can help me."
    new "درست است، از غذا هم نمی‌تونم بگیرم. اما چیز دیگه‌ای هست که می‌تونه بهم کمک کنه."

    # say L1395 lad
    old "You see, for whatever reason I can actually receive the proteins that I need from semen."
    new "ببین، به نظر می‌رسه من می‌تونم پروتئین‌هایی که بهش نیاز دارم رو از سمن دریافت کنم."

    # say L1397 lad
    old "So, I made a deal with some men from town that were willing to help me. That sustained me for a while..."
    new "پس من توافقی با برخی مردان از شهر که آماده کمک کردن به من بودند، بستم. این به من برای مدتی کمک کرد..."

    # say L1398 pla
    old "Ohh, I see..."
    new "اوه، من متوجه شدم..."

    # say L1399 lad
    old "But the problem is that for whatever reason, when I touch a man, it has a very strong effect on them."
    new "اما مشکل اینجاست که به نظر می‌رسد هر وقت من با مردی تماس می‌گیرم، تأثیر خیلی قوی‌ای بر او می‌گذرم."

    # say L1400 pla
    old "They caught the disease too?"
    new "آنها هم بیمار شدند؟"

    # say L1401 lad
    old "What? No, no, it's not that."
    new "نه، نه، اینجوری نیست."

    # say L1402 lad
    old "What I have is not contagious, but it does cause certain effects on men."
    new "آنچه دارم عفونت‌آور نیست، اما بر مردان تأثیرات خاصی دارد."

    # say L1404 lad
    old "So anytime one of them helped me. They would be very drained afterwards."
    new "هر باری که یکی از آنها به من کمک می‌کرد، بعداً خیلی خسته می‌شدند."

    # say L1405 lad
    old "They ended up looking pale and famished. That's probably where the vampire myth mostly comes from."
    new "آنها در نهایت سفید و گرسنگی‌زده به نظر می‌آمدند. احتمالاً این اصل افسانه وامپیر بیشتر از اینجا گرفته شده."

    # say L1406 pla
    old "Oh, I understand..."
    new "اوه، من درک کردم..."

    # say L1408 lad
    old "And as you know, there is a very large religious community in this town."
    new "و همانطور که می‌دانید، در این شهر جامعه دینی بسیار بزرگی وجود دارد."

    # say L1409 lad
    old "Many women got worried that I would hurt their husbands, and even worse, that I would steal them."
    new "بسیاری از زنان نگران شدند که من شوهرانشون رو آسیب ببینم، و حتی بدتر از اون، که من اونا رو ازشون بگیرم."

    # say L1410 lad
    old "And seeing how tired the men were after helping me, the rumors began to circulate."
    new "و با توجه به خستگی مردان بعد از کمک به من، شایعات شروع به پخش شدن کردند."

    # say L1411 pla
    old "I see, I think I now understand better where the legend comes from."
    new "من متوجه شدم، فکر کنم حالا بهتر درک کردم این افسانه از کجا آمده."

    # say L1412 pla
    old "But still, your disease is no reason for them to be talking that way about you."
    new "ولی هنوز، بیماری تو عذر برای این نیست که درباره تو اینطور حرف بزنند."

    # say L1413 pla
    old "I'm sorry ma'am, because not only do you have to take care of your condition. You also have to deal with the town's scorn."
    new "متأسفم خانم، زیرا غیر از اینکه شرایط خودتون رو مدیریت می‌کنید، همچنین با تحقیرهای شهرک نیز مواجه هستید."

    # say L1415 lad
    old "It's really nice of you to say that, thank you. But I'm used to it already."
    new "ممنون از لطفت، ولی من به آن عادت کرده‌ام."

    # say L1416 lad
    old "The only thing that really affects me is that I haven't been able to get the protein I need as of late."
    new "تنها چیزی که واقعاً برایم تأثیرگذار است این است که تا به حال نتوانسته‌ام پروتئین لازم را به دست آورم."

    # say L1417 pla
    old "Wait, so does that mean nobody is helping you right now? So, how do you meet your protein needs then?"
    new "پیش، منظورت اینه که هیچ‌کس الان بهت کمک نمی‌کنه؟ پس، چطور نیازت به پروتئین رو برطرف می‌کنی؟"

    # say L1418 lad
    old "Hmm, not really, it is true that nobody comes here anymore. "
    new "Hmm، درسته که هیچ‌کس اینجا نمی‌آید."

    # say L1419 lad
    old "But I have a deal with the hospital, having a certificate for my condition allows me to receive some semen supplies from them."
    new "اما من قراردادی با بیمارستان دارم، گواهی برای وضعیت خودم دارم و از آن‌ها برخی نمونه‌های سمن دریافت می‌کنم."

    # say L1420 lad
    old "It all comes from donation to the sperm bank of the hospital. They give them to me because it's for the treatment of a medical condition."
    new "همه این‌ها از اهدا به بانک سرم بیمارستان هست. آنها به من می‌دهند چون برای درمان یک وضعیت پزشکی است."

    # say L1422 pla
    old "Uhh, I see."
    new "اوه، من متوجه شدم."

    # say L1423 lad
    old "It's not perfect, but it kind of works."
    new "این کامل نیست، اما به نوعی کار می‌کنه."

    # say L1424 lad
    old "So, you see now? Why do people believe in that legend? And where did those rumours start?"
    new "پس حالا دیدی؟ چرا مردم به این افسانه باور دارن؟ و این شایعات از کجا شروع شده‌ان؟"

    # say L1425 pla
    old "Yeah, I can see it now, but I don't think it's fair!"
    new "بله، حالا می‌تونم ببینم، ولی فکر نمی‌کنم عادلانه باشه!"

    # say L1426 lad
    old "You're right, it isn't, but that's how things are."
    new "درست می‌فرمایید، این عادلانه نیست، اما همینطور است."

    # say L1427 lad
    old "And at least now you know the truth and are willing to talk to me."
    new "و حداقل حالا می‌دونی حقیقت چیه و آماده‌ی صحبت کردن با من هستی."

    # say L1428 pla
    old "Hmm, actually... I don't know if you're ok with me saying this."
    new "هم، در واقع... نمی‌دونم آیا این جوری می‌تونم با تو صحبت کنم."

    # say L1429 pla
    old "But I think I could do more than just listen to you."
    new "اما فکر می‌کنم می‌تونم بیشتر از فقط گوش دادن بهت کمک کنم."

    # say L1430 pla
    old "If you're ok with me doing it, I would like to help you."
    new "اگر تو با اینکه من انجام بدم موافقت داری، من می‌خوام بهت کمک کنم."

    # say L1432 pla
    old "I mean, you said that what you get from the hospital helps, but is not enough, right?"
    new "من قصد دارم، تو گفتی که آنچه از بیمارستان می‌آید کمک می‌کند، اما کافی نیست، درسته؟"

    # say L1433 pla
    old "So, I want to help you."
    new "پس من می‌خوام بهت کمک کنم."

    # say L1435 lad
    old "That's really nice of you to say, but I don't think you understand."
    new "این خیلی لطف داری، اما فکر نمی‌کنم متوجه باشی."

    # say L1437 lad
    old "I told you that the men who helped me were very drained after doing it."
    new "من بهت گفتم که مردهایی که به من کمک کردند بعد از اون کار خیلی خسته بودن."

    # say L1438 pla
    old "Uhh... I mean, I could just do it in a cup or something and give it to you, right?"
    new "اوه... منظورم اینه که می‌تونم تو یه لیوان بکنم یا چیزی و بهت بدم، درسته؟"

    # say L1439 lad
    old "Not really, you see, that's the problem with the sperm I get from the hospital."
    new "نه، می‌بینی، مشکل اسپرمی که از بیمارستان می‌گیرم همین است."

    # say L1440 lad
    old "I don't only get what I need from the semen, but also from the contact with the penis."
    new "من فقط از سرم نمی‌گیرم، بلکه از تماس با پنیس هم نیاز دارم."

    # say L1441 lad
    old "So if I only receive your semen, I won't be able to extract the necessary amount."
    new "پس اگر فقط اسپرمتو دریافت کنم، نمی‌تونم مقدار لازم رو استخراج کنم."

    # say L1443 pla
    old "Well, I still think we can maybe do a small test and see how we do."
    new "خب، من هنوز فکر می‌کنم می‌تونیم آزمایش کوچیکی بکنیم و ببینیم چطور می‌شه."

    # say L1444 lad
    old "I don't know. Are you sure?"
    new "نمیدونم. مطمئنی؟"

    # say L1445 pla
    old "Yeah, I think so. I really want to help you in any way I can."
    new "بله، من همینطور فکر می‌کنم. واقعاً می‌خوام تو رو به هر طریقی که می‌تونم کمک کنم."

    # say L1446 lad
    old "Good, then I guess we can try testing how it goes."
    new "خوب، پس به نظر می‌رسه می‌تونیم امتحان کنیم که چطور می‌شه."

    # say L1447 pla
    old "Great, so let's do it."
    new "عالی، پس بیایم این کار رو انجام بدیم."

    # say L1448 lad
    old "All right, then take out your pants."
    new "باشه، پس لباست رو ببردار."

    # say L1457 lad
    old "I must say I'm impressed young man."
    new "باید بگم شما را متأثر کرده‌ام جوان."

    # say L1458 lad
    old "You got one of the biggest penises I have ever seen."
    new "یکی از بزرگترین سیک‌هایی هست که تا حالا دیده‌ام."

    # say L1459 lad
    old "It's impressive."
    new "البته، این جالب است."

    # say L1460 pla
    old "Uhh... T- thank you ma'am... I guess."
    new "اوه... ممنون می‌شم، خانم... حدس می‌زنم."

    # say L1472 pla
    old "It's good that you can feel better ma'am. I'll do it again if you need me to."
    new "خوشحالم که حالت بهتر شده، خانم. اگر نیاز داشتی دوباره انجام می‌دم."

    # say L1473 lad
    old "Hmm, you seem to be very fine. Normally when I do this with a man, they look very tired afterwards. I wonder if it's because of your age."
    new "هم، به نظرت خوب هستی. معمولاً وقتی این کار رو با مردان می‌کنم، بعدش خیلی خسته می‌شوند. فکر می‌کنم احتمالاً به سبب سن تو باشه."

    # say L1475 pla
    old "I don't know what it may be. But I am a little tired. Maybe I should go home for today. But I'll come back to finish the roof."
    new "نمی‌دونم چیه. ولی خسته‌ام یه کم. شاید برا خونه برم امروز. ولی برای تمام کردن سقف برم باز."

    # say L1476 lad
    old "Ok, just remember to drink a lot of water, and eat as much as you can."
    new "خوب، فقط به خاطر داشته باش تا آب بخوری و هر چه می‌تونی بخور."

    # say L1477 lad
    old "You may not look tired, but I'm sure it must've had some effect on you. Be sure to rest."
    new "شاید خسته نباشید، اما مطمئناً برای شما تأثیری داشته است. حتماً خوب بخوابید."

    # say L1478 pla
    old "I'll do, don't worry. See you later Lady Dimitrescu."
    new "باشه، نگران نباش. ببینم بعداً خانم دیمیترسکو."

    # say L1496 pla
    old "Good morning Lady Dimitrescu! I've come to continue repairing the roof."
    new "صبح بخیر خانم دیمیترسکو! من برای ادامه تعمیرات سقف آمدم."

    # say L1497 lad
    old "Good morning."
    new "صبح بخیر."

    # say L1498 lad
    old "You know, I must say, you don't look very tired at all. Even though I'm certain I took a lot from you."
    new "می‌دونی، باید بگم، خسته به نظر نمی‌رسی هیچ. حتی با اینکه مطمئن هستم از تو خیلی چیزهایی برداشتم."

    # say L1500 pla
    old "(Hmm, I wonder if it's because of the magic power. Maybe it protected me from the effects.)"
    new "ممکن است به خاطر قدرت جادویی باشه. شاید این قدرت از تاثیرات محافظت کرده."

    # say L1501 pla
    old "I don't really know what to tell you, I actually don't feel bad at all."
    new "من واقعاً نمی‌دونم چی بگم، در واقع هیچ احساس بدی ندارم."

    # say L1502 lad
    old "This is a surprise. Are you sure you're ok to work on the roof today?"
    new "این مفاجا است. مطمئنی امروز حالت برای کار روی سقف خوب است؟"

    # say L1504 pla
    old "Yes, don't worry, I feel great, I'm going to get to it right away. So, I can finish it as soon as I can."
    new "بله، نگران نباش، حالت خوبه، همین حالا بهش می‌رسونم. پس، می‌تونم سریع‌ترش تمام کنم."

    # say L1517 lad
    old "This is great! You really did it! Thank you so much, it's fantastic that you put in all this effort. "
    new "عالیه! واقعاً این کار رو انجام دادی! خیلی ممنون، خوشحالم که همه این تلاش رو کردی."

    # say L1518 lad
    old "It looks even better than it was before."
    new "این حتی بهتر از قبل به نظر می‌رسد."

    # say L1519 pla
    old "I'm happy you like it ma'am. It makes all of that effort worth it."
    new "خوشحالم که لذت برده‌ای، خانم. همه این تلاش رو ارزش داد."

    # say L1520 lad
    old "I don't know how to repay you."
    new "نمی‌دونم چطور باید ازت تشکر کنم."

    # say L1521 pla
    old "Oh no, you don't need to pay me or anything. After all, I did the initial damage."
    new "اوه نه، نیازی به پرداخت هیچ چیزی نداری. در نهایت، من خودم آسیب را وارد کردم."

    # say L1522 lad
    old "Well, with this you have more than made up for it. Thanks again [pla]."
    new "با این کار بیش از حد جبران شده. ممنون دوباره [pla]."

    # say L1523 pla
    old "Once again, I'm sorry for damaging your roof, and thank you for your patience. This took a while, but you never got angry with me."
    new "بار دیگه، خیلی متاسفم که سقفت رو آسیب دادم، و ممنونم از صبرت. این کار طول زیادی کشید، اما تو هیچ وقت با من خشمگین نشدی."

    # say L1525 lad
    old "Ohh, I wouldn't get angry."
    new "اوه، من خشمگین نمی‌شدم."

    # say L1526 lad
    old "As I told you, at this point I'm used to people just trying to take a peek into my house, so I was just annoyed when it happened"
    new "همانطور که بهت گفتم، الان به این میزان عادت کردم که مردم فقط بخواهند به داخل خونه‌ام نگاه کنند، پس وقتی اتفاق می‌افتد فقط ناراحت می‌شوم."

    # say L1527 lad
    old "But you've proven to me that you're a stand up young man. I'm happy I got to meet you."
    new "ولی شما به من اثبات کردید که شما مرد جوانی محترمانه هستید. خوشحالم که با شما آشنا شدم."

    # say L1528 pla
    old "Thank you ma'am, if there's anything else I can do for you, please tell me. I'm more than happy to do it."
    new "ممنونم خانم، اگه هر کاری دیگه براش من می‌تونم انجام بدم، لطفاً بهم بگو. خوشحالم که برات کار کنم."

    # say L1529 lad
    old "Well... Now that you mention it, there might be..."
    new "خب... حالا که به این موضوع اشاره کردی، ممکن است..."

    # say L1530 pla
    old "Really? If that's the case, please tell me. I'll do my best to help you."
    new "حقاً؟ اگر اینجوریه، لطفاً به من بگو. من تلاش خواهم کرد که بهت کمک کنم."

    # say L1531 lad
    old "You see, since you don't seem to be at all affected about the help you already gave me. I was wondering if I can ask for your help again."
    new "می‌بینی، چون به کمکی که قبلاً به من کردی، خیلی تأثیر نکرده‌ای. فکر می‌کنم می‌تونم دوباره ازت کمک بخواهم."

    # say L1532 lad
    old "But this time it might be a little different."
    new "البته این بار ممکن است کمی متفاوت باشد."

    # say L1534 pla
    old "Different? How?"
    new "متفاوت؟ چطور؟"

    # say L1535 lad
    old "Let me explain, I can assimilate a lot through my digestive system, but the most efficient way of taking in the protein content is through my uterus."
    new "بگذارم توضیح بدم، من می‌توانم از طریق سیستم گوارش خودم آب و هوای زیادی را جذب کنم، اما روش موثرتر برای جذب محتوای پروتئین از طریق رحمم است."

    # say L1536 lad
    old "Because that way my body can absorb it better."
    new "چون اونجوری بدن من بهتر می‌تونه جذب کنه."

    # say L1537 pla
    old "Wow, does that mean you have to have sex with me?"
    new "واو، این به معنای اینه که باید جنسی با من کنی؟"

    # say L1538 lad
    old "Well, only if you are okay with that, of course."
    new "البته، فقط اگر تو موافقت می‌کنی."

    # say L1540 pla
    old "Hmm... Well, if that actually helps you, and it's better for you, sure."
    new "Hmm... خب، اگه واقعاً به تو کمک کنه و برایت بهتر باشه، البته."

    # say L1541 pla
    old "After all, I did promise I would help you. didn't I?"
    new "البته، من قول دادم که به تو کمک کنم. نیست؟"

    # say L1542 lad
    old "Perfect! Thank you so much!"
    new "عالی! خیلی ممنون!"

    # say L1543 lad
    old "Hmm, come with me to the stairs..."
    new "هم، با من به سرپای پله‌ها بیا..."

    # say L1559 lad
    old "That was fantastic, thank you! You have no idea how much you help me."
    new "این عالی بود، ممنون! نمی‌دونی چقدر به من کمک می‌کنی."

    # say L1560 pla
    old "I'm happy to help... and to be honest I enjoyed it too."
    new "خوشحالم که کمک کردم... و صدای صادقانه، خودم هم لذت بردم."

    # say L1561 lad
    old "It's very interesting that you don't get tired at all doing this with me."
    new "خیلی جالب است که تو با من این کار رو انجام میدی و خسته نمی‌شوی."

    # say L1562 lad
    old "Maybe that could be of help..."
    new "شاید این می‌تونه کمکت کنه..."

    # say L1563 pla
    old "Uhh, what do you mean?"
    new "اوه، منظورت چیه؟"

    # say L1564 lad
    old "Well, there's something I must let you know."
    new "خب، چیزی هست که باید به شما بگم."

    # say L1567 lad
    old "Do you remember what you told me about the night you fell in here? That you saw me with two other girls?"
    new "آیا به یاد داری چه گفتی درباره شبی که اینجا سقوط کردی؟ که دو دختر دیگر را با من دیده بودی؟"

    # say L1568 pla
    old "Yeah, the girls from my dream."
    new "بله، دخترانی که توی رویام دیدم."

    # say L1570 lad
    old "Well, actually they're my daughters. Or at least that's what I call them."
    new "در واقع، آنها دختران من هستند. یا حداقل اینطور می‌گویم."

    # say L1571 lad
    old "You see, years ago I found out I'm not the only person with my condition."
    new "ببین، سال‌ها پیش فهمیدم که من تنها شخص با این وضعیت نیستم."

    # say L1572 lad
    old "There are some other people, and I decided to help them. That's why I have this mansion, to receive people like me, and give them a hand."
    new "البته، افراد دیگری هم هستند و من تصمیم گرفتم کمکشون کنم. برای همین این خانه را دارم، تا افرادی مثل من رو می‌آورم و بهشون دست بدهم."

    # say L1573 pla
    old "Really? So, you live with several people here? I haven't seen them."
    new "وای، پس تو اینجا با چند نفر زندگی می‌کنی؟ من هیچ‌کس رو ندیدم."

    # say L1574 lad
    old "Right now it's only me and my two daughters. With the years some have come and go."
    new "البته، الان فقط من و دو دخترم هستیم. طولانی است که بعضی از آنها آمده‌اند و برخی رفته‌اند."

    # say L1575 lad
    old "We communicate with each other every time anyone finds anything that can help us."
    new "ما هر بار که کسی چیزی پیدا می‌کنه که می‌تونه به ما کمک کنه، با هم ارتباط برقرار می‌کنیم."

    # say L1576 pla
    old "Oh, it's a very nice gesture of you that you take people in and help them. You really are a good person."
    new "اوه، این خیلی احترام‌آوره که مردم رو می‌پذیری و بهشون کمک می‌کنی. واقعاً انسان خوبی هستی."

    # say L1578 lad
    old "Thank you, I'm glad you think that about me."
    new "ممنون، خوشحالم که اینطور در مورد من فکر می‌کنی."

    # say L1579 lad
    old "And yeah, we help each other cope with the condition. And since it's such a rare thing, it's really useful that we are all close to each other."
    new "و بله، ما به هم کمک می‌کنیم تا با این وضعیت زنده بمانیم. و چون این موضوع خیلی نادره، خوشحالم که ما همه به هم نزدیکیم."

    # say L1580 lad
    old "And you see, since you've now been able to help me twice, and don't seem to be affected..."
    new "و ببین، از آنجا که حالا دو بار به من کمک کردی و به نظر نمی‌رسه تحت تأثیر قرار گرفتی..."

    # say L1581 lad
    old "I was wondering if you could also help my two daughters."
    new "من داشتم فکر می‌کردم که آیا می‌توانی به دو دخترم هم کمک کنی."

    # say L1583 pla
    old "Oh! I see."
    new "اوه! من متوجه شدم."

    # say L1584 lad
    old "I would love it if you could. They could really use your help to improve their health."
    new "من خوشحال می‌شوم اگر بتونی. دخترهایم واقعاً به کمکت برای بهبود سلامتی‌شون نیاز دارن."

    # say L1585 pla
    old "Well, I think that if I really did help you treat your condition. I don't see why it couldn't do it for you daughters."
    new "خب، فکر می‌کنم اگه واقعاً به درمان شرایطت کمک کردم، چرا برای دختراتت هم نباید این کار رو انجام بدم؟"

    # say L1586 lad
    old "You're an angel. Then I'll talk to them, so that you can help them as soon as possible."
    new "تو یک فرشتگی هستی. بعد از این باهاشون حرف می‌زنم، تا بتونی بهشون کمک کنی هر چه زودتر."

    # say L1587 lad
    old "Is that ok with you?"
    new "آیا این برای شما مشکلی نداره؟"

    # say L1589 lad
    old "All right, have a good night [pla]."
    new "باشه، شب خوبی داشته باشید [pla]."

    # say L1590 pla
    old "Good night to you too, Lady Dimitrescu."
    new "شب خوبی به تو هم، لیدی دیمیترسکو."

    # say L1613 pla
    old "Good morning ma'am, I'm here to help you as we talked before."
    new "صبح بخیر خانم، من برای کمک به شما اینجا هستم مطابق با آنچه قبلاً صحبت کردیم."

    # say L1614 lad
    old "Good morning. I'm happy to see that you actually came."
    new "صبح بخیر. خوشحالم که واقعاً اومدید."

    # say L1615 lad
    old "Allow me to introduce you to my daughters. These are Bela and Daniela."
    new "این‌ها دختران من هستند. این‌ها بلای و دانیلا هستند."

    # say L1616 lad
    old "This is [pla] he's the one I've told you about and has come to help us with our condition."
    new "این [pla] است، او همان شخصی است که به تو در موردش گفتم و برای کمک به ما با شرایط ما آمده است."

    # say L1618 bela
    old "H- hi. I'm Bela, nice to meet you."
    new "ه- هی. من بلایم، خوشحالم که با شما آشنا شدم."

    # say L1620 dan
    old "Hello, I'm Daniela, mother has told us about you, and what you're able to do for us. Thank you very much for coming."
    new "سلام، من دانیلا هستم، مادر ما از شما حرف زده و از آنچه برای ما می‌توانید انجام بدید، خبر داده. ممنونم که اومدی."

    # say L1621 pla
    old "N- nice meeting you. I'm [pla], happy to be of help."
    new "خوشحالم که با تو آشنا شدم. من [pla] هستم، خوشحالم که بتونم کمکتون کنم."

    # say L1622 lad
    old "Well, now that the introductions are over, I think it's best if we start."
    new "خب، حالا که مقدمات تمام شد، فکر می‌کنم بهتر است شروع کنیم."

    # say L1623 pla
    old "Uhh... Right now? And just like that?"
    new "اوه... الان؟ و همین‌طور؟"

    # say L1624 lad
    old "Well, have in mind my daughters really needs it, and we use to do it in the past with other guys..."
    new "خب، بگیر این نکته رو در نظر که دختران من واقعاً به این نیاز دارن، و ما قبلاً با مردان دیگر هم این کار رو انجام دادیم..."

    # say L1625 lad
    old "So, don't worry, just relax, and let us do all for you."
    new "پس، نگران نباش، فقط آرام شو و بگذار ما همه چیز رو برایت انجام بدیم."

    # say L1633 lad
    old "Mmmm, look at that, you're already in the mood for it..."
    new "ممنون، ولی این جمله برای شخصیت Lady Dimitrescu مناسب نیست. او شخصیتی با قدرت و احترام است و این جمله با سبک صحبت او همخوانی ندارد. در عوض، می‌توانید از این جمله استفاده کنید:"

    # say L1634 dan
    old "Oh wow! Look at what you're packing there."
    new "اوه وای! نگاه کن به اون چیزی که تو داری."

    # say L1636 lad
    old "Daniela darling, please, you don't have to be this forward."
    new "دانیلا عزیزم، لطفاً، نمی‌تونی اینقدر صریح باشی."

    # say L1637 bela
    old "But mother, it is true that's an impressive size."
    new "اما مامان، این حجم واقعاً برجسته است."

    # say L1638 lad
    old "Hehe, we can't deny that..."
    new "خخخ، نمی‌تونیم اینو انکار کنیم..."

    # say L1639 lad
    old "But remember, we're doing this for a reason, so control yourselves."
    new "اما به خاطر داشته باشید، ما برای هدفی این کار رو انجام میدیم، پس خودتون رو کنترل کنید."

    # say L1640 dan
    old "Yes, mother."
    new "بله، مامان."

    # say L1642 lad
    old "Now, I think we've talked enough."
    new "خب، فکر کنم کافی صحبت کردیم."

    # say L1643 lad
    old "Are you ready [pla]?"
    new "آیا آماده هستی [pla]؟"

    # say L1662 lad
    old "By the way, how are you feeling [pla]?"
    new "البته، احساست چطوره [pla]؟"

    # say L1663 pla
    old "Well, to be honest I'm a little tired. But it's nothing a nap and some food won't fix. I'll be ok."
    new "البته، صادقانه بگم خسته‌ام. اما با یه خواب کوتاه و یه ناهار خوب، همه چی جای خودش می‌رسه. من خوبم."

    # say L1664 lad
    old "I must admit your endurance is astounding."
    new "باید بگم استقامتت شگفت‌انگیز است."

    # say L1665 lad
    old "But I'm happy you're fine."
    new "ولی خوشحالم که حالت خوبه."

    # say L1666 pla
    old "And I'm happy I can be of help to you all."
    new "و من خوشحالم که می‌توانم به شما همه کمک کنم."

    # say L1670 dan
    old "Honestly, our health had been going down due to not being able to get enough semen for all three of us."
    new "صراحیت بگم، سلامتی ما به دلیل نتوانستن برای همه سه ما سرم کافی در اختیار داشتن، پایین می‌آمد."

    # say L1671 dan
    old "And even if the hospital donated more, it's not the same thing as receiving it directly from a person."
    new "و حتی اگر بیمارستان بیشتر هدیه کند، همینطور نیست که از یک شخص مستقیماً دریافت کنیم."

    # say L1672 pla
    old "Hmm, does that mean that if no one else helps you, you'll be in trouble again?"
    new "هم، این به معنای اینه که اگر هیچ کس دیگه بهتون کمک نکنه، دوباره مشکل خواهید داشت؟"

    # say L1673 lad
    old "Sadly it does."
    new "متأسفانه همینطور است."

    # say L1674 pla
    old "Then I'll be sure to come back again and help you. I'll do it as many times as you need me to."
    new "البته، حتماً دوباره برگشتم و به تو کمک کردم. هر تعدادی که لازم باشه، من انجام میدم."

    # say L1676 lad
    old "Hmm are you sure? I understand that one time is something. But if you do too many times it might affect you."
    new "همم مطمئنی؟ فهمیدم که یک بار چیزی است. اما اگر بارها انجام بدی، ممکنه برایت تأثیر بگذارد."

    # say L1677 pla
    old "I think I could keep helping you some more, given that so far I haven't had any negative reaction."
    new "فکر کنم می‌تونم همچنان به تو کمک کنم، چون تا حالا هیچ واکنش منفی‌ای نداشتم."

    # say L1678 pla
    old "So you can count on me."
    new "پس می‌تونی به من اعتماد کنی."

    # say L1679 lad
    old "Aww, you're an angel. Well then, when we need it, we'll be sure to call you on."
    new "اوه، تو یک فرشتگی هستی. خب، وقتی نیاز داشتیم، حتماً ازت تماس می‌گیریم."

    # say L1697 pla
    old "Hi Lady Dimitrescu."
    new "سلام خانم دیمیترسکو"

    # say L1698 lad
    old "Oh, hi [pla], it's always nice to see you."
    new "اوه، سلام ز[pla]، همیشه خوشحالم که تو رو ببینم."

    # say L1699 lad
    old "How can I help you today?"
    new "امروز چطور می‌توانم به شما کمک کنم؟"

    # menu L1703 
    old "Help them again"
    new "دوباره به آنها کمک کنم"

    # say L1705 pla
    old "Well, I have been thinking about helping you again."
    new "خب، من فکر کردم ممکن است دوباره به تو کمک کنم."

    # say L1706 lad
    old "Oh, have you come help us with our protein needs?"
    new "او، آیا برای کمک به ما در نیازهای پروتئینی اومدی؟"

    # say L1707 pla
    old "That's right, I thought you might need it."
    new "درست است، فکر کردم ممکن است به آن نیاز داشته باشی."

    # say L1708 lad
    old "That's perfect, you came at just the right moment."
    new "این عالیه، همین الان اومدی."

    # say L1709 lad
    old "Let me call the girls."
    new "بگذار دختران رو فراخونم."

    # say L1728 bela
    old "Hi [pla]! How are you?"
    new "سلام ز[pla]! چطوری؟"

    # say L1729 pla
    old "I'm fine, thank you, I came to see if you needed my help today."
    new "من خوبم، ممنون. امروز اومدم ببینم آیا به کمک من نیاز داری."

    # say L1730 dan
    old "Yeah, mother told us."
    new "بله، مادر به ما گفت."

    # say L1764 pla
    old "What?! Oh no, sorry, I was just a little distracted."
    new "اوه نه، معذرت، فقط یه کم خیال پر کردم."

    # say L1766 lad
    old "Hmm, I see, well, be careful on the way back."
    new "البته، مراقب خودت با هنگام برگشت."

    # say L1767 pla
    old "Yes ma'am, bye."
    new "بله خانم، خداحافظ."

    # say L1770 pla
    old "Oh, sorry, I was just passing by."
    new "اوه، عذرخواهم، فقط از کنار می‌گذرم."

    # say L1771 lad
    old "Hmm, I see, well, make sure you come when you have some free time."
    new "البته، امیدوارم وقت خالی داشته باشی و بیایی."

    # say L1772 pla
    old "Yes ma'am, of course. See you later."
    new "بله خانم، البته. دوباره هم می‌بینیم."

    # say L1773 lad
    old "Bye, take care."
    new "خداحافظ، مراقب خودت با."


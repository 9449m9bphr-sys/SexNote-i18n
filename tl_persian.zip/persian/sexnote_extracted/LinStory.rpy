# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/LinStory.rpy
translate persian strings:

    # say L6 jon
    old "What was that?!"
    new "چه بود این؟!"

    # say L7 gra
    old "I have no idea... I'm as surprised as you're right now."
    new "من هیچ ایده‌ای ندارم... من هم مثل تو شوکه‌ام."

    # say L8 jon
    old "I've been here for many years and it's the first time I hear such strange noise."
    new "من سال‌ها اینجا هستم و برای اولین بار صدایی عجیب می‌شنوم."

    # say L15 jon
    old "God! Something strange is happening here... It's not normal for the lights to turn off and on by themselves all the time."
    new "خداوند! چیزی عجیب اینجا اتفاق می‌فته... نرمال نیست که نور خودش روشن و خاموش بشه همیشه."

    # say L16 gra
    old "I know... But... What could it be?"
    new "می‌دونم... ولی... چه چیزی می‌تونه باشه؟"

    # say L19 jon
    old "A ghost! An evil presence, what else could it be?!"
    new "یک جن! یک حضور شیطانی، چیز دیگری نمی‌تونه باشه!"

    # say L22 gra
    old "What!? Do you really think so?"
    new "چه!؟ واقعاً اینطور فکر می‌کنی؟"

    # say L23 jon
    old "Of course! I'm not joking... So why do you think this youth is so rotten and lost? It's the devil's work!"
    new "البته! من همیشه جدی هستم... پس چرا فکر می‌کنی این نوجوان اینقدر خراب و گم‌راه شده؟ این کار شیطان است!"

    # say L24 gra
    old "Yes Mrs. Jones, you're right, must be that. I don't think it's an electricity issue."
    new "بله خانم جونز، درست می‌فرمایید، حتماً اینجاست. فکر نمی‌کنم مشکل برق باشه."

    # say L26 gra
    old "We gotta do something! Fuck... Jesus Christ!"
    new "باید چیزی انجام بدیم! شیطون... عیسی مسیح!"

    # say L28 jon
    old "Sister Grace! Watch your mouth, please!"
    new "خواهر گریس! لطفاً زبان خودت رو در نظر بگیر!"

    # say L30 gra
    old "Sorry Mrs. Jones, but this situation gets on my nerves, it's a ghost or a devil. We must perform an exorcism!."
    new "ببخشید خانم جونز، اما این وضعیت رو خیلی تحریک می‌کنه، احتمالاً جن یا شیطانی هست. ما باید طرد جان انجام بدیم!"

    # say L31 jon
    old "We need the pries-"
    new "ما به روحانی نیاز داریم-"

    # say L32 pla
    old "(I should use the Agamoto's eye and check if I can see something...)"
    new "باید از چشم آگاموتو استفاده کنم و ببینم چیزی می‌تونم ببینم یا نه..."

    # say L39 pla
    old "(Oh no! It's not a ghost... It's a shinigami!)"
    new "(اوه نه! این یک روح نیست... این یک شینیگامی است!)"

    # say L40 pla
    old "(But... What happened to her!? Seems she is trapped or...)"
    new "ولی... به اون چه اتفاقی افتاده؟ به نظر می‌رسه فرورفته یا..."

    # say L41 pla
    old "(She looks like she's in pain... And why does she fly like that??!)"
    new "(به نظر می‌رسه درد داره... و چرا اینجوری پرواز می‌کنه؟!)"

    # say L42 pla
    old "(I gotta talk to this shinigami... This has something to do with the magic...)"
    new "من باید با این شینیگامی صحبت کنم... این به جادو مربوطه..."

    # say L45 pla
    old "Hello, Oh! Sorry... I didn't want to interrupt..."
    new "سلام، اوه! معذرت... من قصد نداشتم تا مداخله کنم..."

    # say L50 jon
    old "Oh! Hello [pla] don't worry, we were discussing something important but it's fine..."
    new "اوه! سلام [pla] نگران نباش، ما در حال بحث در مورد چیزی مهم بودیم اما خیلی مشکلی نداره..."

    # say L51 jon
    old "Let me introduce you to our Sister Grace, she is the nun of the church."
    new "آقایان و خانم‌ها، بگذارید شما را با خواهر گریس آشنا کنم، او راهب کلیسا هستند."

    # say L52 pla
    old "Hi, nice to meet you."
    new "سلام، خوشحالم که با شما آشنا شدم."

    # say L53 gra
    old "Hi [pla], nice to meet you to."
    new "سلام ز[pla]، خوشحالم که با شما آشنا شدم."

    # say L55 jon
    old "Hun, something terrible is happening here... We might have the presence of a ghost in the church! Can you believe it?"
    new "حون، چیزی وحشتناک اینجا اتفاق می‌فته... شاید هم روحی در کلیسا وجود داشته باشه! می‌تونی باور کنی؟"

    # say L56 gra
    old "Or a devil... Gosh darn I-!"
    new "یا شیطان... خدا نگه دار من-!"

    # say L58 jon
    old "Sister Grace, please!"
    new "خواهر گریس، لطفاً!"

    # say L60 pla
    old "Wait! Why do you think is a ghost?"
    new "پیش! چرا فکر می‌کنی جان‌باخته است؟"

    # say L62 jon
    old "There are strange noises, the lights turn off and on by themselves... And I'm a very spiritual person, if I'm telling you this is because it is what it is..."
    new "صداهای عجیبی هست، نورها خودشون روشن و خاموش می‌شن... و من انسانی روحی هستم، اگه به تو می‌گم اینجوری هست، چون همینه..."

    # say L63 pla
    old "I- I believe you... But what are you gonna do?"
    new "من- من باورت می‌کنم... اما تو چه کاری می‌خوای بکنی؟"

    # say L64 gra
    old "An exorcism!"
    new "یک تکثیر!"

    # say L66 pla
    old "An exorcism?"
    new "یک تکثیر؟"

    # say L67 pla
    old "(I have to talk to the girls... They should know what's happening.)"
    new "من باید با دختران صحبت کنم... آنها باید بدونند چه اتفاقی افتاده."

    # say L68 jon
    old "Hun, we don't want to scare you..."
    new "حون، ما نمی‌خوایم تو رو وحشیات بدهیم..."

    # say L69 pla
    old "No, I'm not... I gotta go now, I- I have some... Homework to do but I will pass by to see what happens."
    new "نه، من نه... باید حالا برسم، من- من چند تکلیف دارم ولی می‌خوام ببینم چه اتفاقی افتاده."

    # say L70 pla
    old "Perhaps I could help out... Dunno... It's very strange what's happening here."
    new "شاید بتونم کمکتون کنم... نمی‌دونم... اتفاقات عجیبی اینجا می‌افته."

    # say L71 jon
    old "Alright, please take care of yourself."
    new "البته، لطفاً مراقب خودت باش."

    # say L73 pla
    old "You too Mrs. Jones... Goodbye..."
    new "تو هم خانم جونز... خداحافظ..."

    # say L75 gra
    old "Bye [pla], may God take care of your soul."
    new "خداحافظ [pla]، خدا روحت رو حفظ کنه."

    # say L80 pla
    old "(What's happening here, this is weird, I gotta talk to the shinigamis.)"
    new "(اینجا چه قصه‌ای داره، این خیلی عجیبه، باید با شینیگامی‌ها صحبت کنم.)"

    # say L95 pla
    old "(Alright, I'm here... Fortunately there is no one here, I should use the Agamoto's eye and talk with them before someone comes.)"
    new "(بیایم، من اینجا هستم... خوشحالم که هیچ‌کس اینجا نیست، باید از چشم آگامو استفاده کنم و قبل از اینکه کسی بیاد با آنها صحبت کنم.)"

    # say L112 pla
    old "Hey girls, I gotta tell you something!"
    new "دستا، باید چیزی به تو بگم!"

    # say L128 mil
    old "Well, hello... We're actually fine and you?"
    new "خب، سلام... ما در واقع خوب هستیم، تو چطوری؟"

    # say L129 pla
    old "Opss! Sorry... Hi hi..."
    new "اوه! معذرت... سلام سلام..."

    # say L130 pla
    old "This is something important... I found a new Shinigami at the church..."
    new "این چیز مهمیه... یه شینیگامی جدید توی کلیسا پیدا کردم..."

    # say L131 pla
    old "I don't know what's happening but she's not fine for sure, she was flying around, looking drowsy..."
    new "نمیدونم چه قصه‌ایه ولی حتماً خوب نیست، اونجا پرواز می‌کرد، مثل اینکه خسته و خواب‌آلود بود..."

    # say L132 gom
    old "A new shinigami? And what do you mean by drowsy?"
    new "یک شینیگامی جدید؟ و منظورت از خسته چیه؟"

    # say L133 pla
    old "Hmm, like very weak... Dunno! Do you guys have any idea of what's happening there?"
    new "هم، مثل خیلی ضعیف... نمی‌دونم! شما‌ها ایده‌ای دارین که اونجا چه قصه‌ای هست؟"

    # say L135 mil
    old "What? What was she doing in there?"
    new "چه کاری اونجا انجام می‌داد؟"

    # say L136 pla
    old "Well, she was flying but it seemed she was stuck in there..."
    new "خب، او پرواز می‌کرد اما به نظر می‌رسید که در آنجا گیر افتاده‌است..."

    # say L138 mil
    old "Hmm, alright... I may know what's happening."
    new "Hmm، خوب... شاید بفهمم چه اتفاقی افتاده."

    # say L139 mil
    old "If what you said is happening, it might be that the shinigami is in trouble with her energy."
    new "اگر همینطوره، شاید شینیگامی با انرژی‌اش مشکل داره."

    # say L140 mil
    old "I mean, there is no much energy around and she must be stuck in there. When there is not enough energy, we suffer the consequences."
    new "من قصد دارم بگم که انرژی زیادی اطراف نیست و او ممکن است در آنجا گیر افتاده باشد. وقتی انرژی کافی نیست، ما با عواقب روبرو می‌شویم."

    # say L141 mil
    old "Most likely she has just a couple of..."
    new "احتمالاً فقط چند روز دیگه..."

    # say L143 pla
    old "A couple of? Of what?"
    new "چند تا؟ چند تا چی؟"

    # say L144 mil
    old "A couple of days left..."
    new "چند روز دیگه..."

    # say L145 gom
    old "This is so sad... We all will die..."
    new "این خیلی حزینه... ما همه خواهیم مرد..."

    # say L146 dev
    old "All this is bullshit..."
    new "همه این ها اشتباه است..."

    # say L147 mil
    old "Girls! Wait a sec... We can still do something, we have [pla] on our side, he's gonna help us."
    new "دختران! یه لحظه صبر کنید... هنوز می‌تونیم کاری بکنیم، ما [pla] رو از دست ما کمک می‌کنه، او به ما کمک می‌کنه."

    # say L148 gom
    old "But... But how? There is no more magic power around us... Tell me how?"
    new "ولی... ولی چطور؟ هیچ توانایی جادویی دیگر اطراف ما نیست... بگو چطور؟"

    # say L151 pla
    old "There has to be a way, just tell me what to do and I'll do it, we can't let her die."
    new "باید راهی هست، فقط به من بگو چه کنم، نمی‌تونیم به اون جان بگیم خداحافظی."

    # say L153 mil
    old "[pla] just go and check how is her... Try to share some of your magic power with her."
    new "[pla] برو و ببین اوضاعش چطوره... سعی کن برخی از توان خودتو با او به اشتراک بگذاری."

    # say L155 pla
    old "Sure, I'll... I'm so sorry all this is happening but don't worry, I'll help..."
    new "بله، من... خیلی متاسفم که همه اینا اتفاق می‌افتد ولی نگران نباش، من کمک می‌کنم..."

    # say L156 pla
    old " It's better if I go now... See you!"
    new "بهتره حالا برسم... دیدنت!"

    # say L159 dev
    old "Good luck... And see you."
    new "موفق باش... و دیدنت!"

    # say L160 mil
    old "[pla] take care and don't forget we count on you."
    new "[pla] مرا مهتمانه بود و فراموش نکن که ما بر تو تکیه داریم."

    # say L161 pla
    old "I know... I'll do my best!"
    new "می‌دونم... سعی می‌کنم بهترین کار رو بکنم!"

    # say L181 mor
    old "Alright, we are going to start the exorcism."
    new "باشه، الان شروع به تکثیر می‌کنیم."

    # say L188 mor
    old "Lord, please protect our church, protect us from these evil presences that surround us."
    new "ای پروردگار، لطفاً کلیسای ما را حفظ کن، ما را از این حضورهای شیطانی که دور ما هستند، محافظت کن."

    # say L191 jon
    old "Amen."
    new "آمین."

    # say L194 mor
    old "Our Father, who art in Heaven, hallowed be Thy name, Thy kingdom come..."
    new "پدر ما که در آسمان هستی، نام تو مقدس است، پادشاهی تو بیاید..."

    # say L195 mor
    old "Thy will be done, on earth as it is in Heaven. Give us this day our daily bread, and forgive us ou-"
    new "اینستادت بر ما، در زمین همانند آسمان. خوان به ما امروز نان روزمره‌مان، و ببخش به ما گناه‌مان،"

    # say L197 pla
    old "(There she is... Is the shinigami... She'll die if I don't do something!)"
    new "اونجاست... آن شینیگامی... اگه هیچی نکنم او می‌میرد!"

    # say L198 pla
    old "Huh,  w- what's happening? "
    new "ه ه- چه کاری اتفاق افتاد؟"

    # say L203 jon
    old "[pla]! Hi hun, is the ghost... The demon presence... It's taking over the church."
    new "[pla]! سلام عزیزم، این جن... حضور شیطان... در حال تسلط بر کلیساست."

    # say L204 gra
    old "Hi [pla], Mrs. Jones is right, the situation is getting worse."
    new "سلام [pla]، خانم جونز درست می‌گه، وضعیت بدتر شده."

    # say L207 pla
    old "What? Why do you think is a demon?"
    new "چرا فکر می‌کنی این یک شیطانه؟"

    # say L208 gra
    old "Because it is! What else could it be if not a demon, a ghost!?"
    new "چون هست! اگه جن نیست، چی می‌تونه باشه، یه آرامینگه؟"

    # say L209 jon
    old "It is hun... We know that, just look at the lights, everything is a mess here because of that."
    new "این هن... ما این رو می‌دونیم، فقط به نورها نگاه کن، همه چیز اینجا به خاطر اون در حال خرابیه."

    # say L210 pla
    old "(If I don't do something quickly, she will probably die.)"
    new "اگر سریع هیچ کاری نکنم، احتمالاً او مرد خواهد شد."

    # say L211 pla
    old "Ehmm... I'm sorry to contradict you but the presence we have right now in this church is not malignant at all, I'm sure of that."
    new "اهم... معذرت که با تو مخالفت می‌کنم اما وجودی که الان در این کلیسا هست خلاف آنچه می‌گویی نیست، از این مطمئن هستم."

    # say L212 gra
    old "What? What are you saying? If you're so sure, prove it!"
    new "چه کاری می‌گی؟ اگر هم اینقدر مطمئنی، ثابت کن!"

    # say L213 pla
    old "W- Well... I can do it! Take a look at the lights."
    new "ب-�ه... من می‌تونم اثبات کنم! به نورها نگاه کن."

    # say L214 pla
    old "I'll tell the spirit to move to the right and the lights on that side will start to fade, if this happens you'll see that this spirit has good intentions."
    new "روح! از من بپرس... می‌دونیم می‌تونیم به هم کمک کنیم، لطفاً به سمت راست حرکت کن و با خاموش شدن نورها به ما نشون بده که نیت خوبی داری..."

    # say L215 gra
    old "Hmm, let's see."
    new "Hmm، بیاین ببینیم."

    # say L217 pla
    old "Spirit! Listen to me... We know we can help you as you can help us as well, please move to the right side and let us know by using the lights..."
    new "روح! به من گوش کن... ما می‌دونیم می‌تونیم به تو کمک کنیم و تو هم به ما، لطفاً به سمت راست حرکت کن و با خاموش شدن چراغ‌ها به ما اطلاع بده..."

    # say L224 gra
    old "My God! He did it! The lights were fading..."
    new "الله می‌دونم! اونو کرد! نورها در حال خاموش شدن بودند..."

    # say L225 pla
    old "Spirit! Thanks! We saw it, you may now come back to your place."
    new "روح! ممنون! دیدیم، حالا می‌توانی برگردی به جایت."

    # say L230 jon
    old "[pla]! You were right... But how, how did you know it!?"
    new "[pla]! درست می‌گفتی... ولی چطور، چطور متوجه شدی!؟"

    # say L232 pla
    old "I simply knew it, I can feel the creature's energy and I know it's good... There is nothing bad within it."
    new "من ساده‌ترین راه را می‌دانستم، انرژی موجود را حس می‌کنم و می‌دانم خوب است... درونش هیچ چیز بدی نیست."

    # say L233 jon
    old "I'm surprised..."
    new "ممنونم، من هم شگفت‌زده‌ام..."

    # say L234 mor
    old "Son, we see you're right, this spirit actually listens to you and does accordingly but what does it want? What can we do?"
    new "پسر، می‌بینیم که درست می‌گویی، این روح واقعاً به تو گوش می‌دهد و بر اساس دستوراتت عمل می‌کند، اما اینجا چه می‌خواهد؟ ما چه کاری می‌توانیم انجام دهیم؟"

    # say L235 pla
    old "Well, I thin-"
    new "خب، من فکر می‌کنم-"

    # say L246 bil
    old "What's the fuss about? Granma what's happening here?"
    new "چه مشکلی هست؟ بابا چه اتفاقی افتاده؟"

    # say L251 jon
    old "Hi darling! It's a ghost-"
    new "سلام عزیزم! اینجا یه روح هست-"

    # say L252 bil
    old "Oh really! Shut up, please! You're talking nonsense."
    new "اوه واقعاً! لطفاً بس کن، حرف نonsensی می‌زنی."

    # say L253 gra
    old "It's true! There is an evil presence here..."
    new "درست است! اینجا حضوری شرور وجود دارد..."

    # say L255 bil
    old "Sister Grace I wasn't talking to you, please don't be rude... I can't deal with nosy people."
    new "خواهر گریس من با تو صحبت نمی‌کردم، لطفاً خشن نباش... من نمی‌توانم با افراد خیال‌پرداز کار کنم."

    # say L283 jon
    old "What's happening Billie? BILLIE!?"
    new "بیلی، چه کاری اتفاق افتاده؟ بیلی!؟"

    # say L291 jon
    old "Nooo! Billie, wake up!! What's happening!? Someone help me, please!"
    new "نوع! بیلی، بیدار شو!! چه کاری اتفاق پیش می‌یاد؟! لطفاً کسی به من کمک کن!"

    # say L292 gra
    old "Oh God, please help us."
    new "اوه خدا، لطفاً ما را نجات بده."

    # say L293 mor
    old "Calm down everybody...!"
    new "همه آرام شوید...!"

    # say L295 mor
    old "I believe in God, the Father Almighty, Creator of Heaven and earth; and in Jesus Christ, His only Son, Our Lord..."
    new "من به خداوند، پدر بزرگتوان، خالق آسمان و زمین؛ و به عیسی مسیح، تنها پسر او، پروردگار ما، باور دارم..."

    # say L298 gra
    old "Father Morgan?"
    new "آقای مورگان؟"

    # say L299 mor
    old "It's important to keep praying for Billie."
    new "مهمه برای بیلی دعا کنیم."

    # say L300 mor
    old "Let's pra-"
    new "بیایید دعا کنیم-"

    # say L301 gra
    old "Noo! Father Morgan, take her to the hospital with Mrs. Jones, I'll take care of the church..."
    new "نه! پدر مورگان، او را با خانم جونز به بیمارستان ببرید، من کلیسا را اداره می‌کنم..."

    # say L303 jon
    old "Yes, let's go now... She has to be checked by a doctor."
    new "بله، بیایید حالا برویم... او باید توسط یک دکتر بررسی شود."

    # say L309 mor
    old "Sister Grace, please take care of the church, call me if anything... Ok?"
    new "خواهر گریس، لطفاً کلیسا را اداره کن، اگر هر چیزی پیش آمد مرا تماس بده... خوب؟"

    # say L322 pla
    old "Wow that was... Weird..."
    new "واو، این خیلی عجیب بود..."

    # say L323 gra
    old "I hope Mrs. Jones's granddaughter is fine."
    new "امیدوارم نوه خانم جونز خوب باشه."

    # say L324 pla
    old "Yeah, me too."
    new "بله، من هم همین جور."

    # say L325 gra
    old "Wait a minute, the lights are not flashing! The ghost is gone!"
    new "بیا بیشتر، نورها در حال نوسان نیستند! روح رفته است!"

    # say L326 pla
    old "W- what? (Oh shit, what happened with the shinigami?)"
    new "و- وای؟ (اوه شیطون، با شینیگامی چه اتفاقی افتاد؟)"

    # say L327 pla
    old "You are right... I can't see anything either"
    new "درست می‌گویی... من هم هیچ چیز نمی‌بینم"

    # say L328 pla
    old "(Oh no... It means she... d- died.)"
    new "اوه نه... این بیان اینه که او... د- درگذشته."

    # say L329 gra
    old "And it was because of you! Thank you for your help."
    new "و این به خاطر تو بود! ممنون از کمکت."

    # say L330 pla
    old "Yeah... It was because of me... (It was my fault...)"
    new "بله... به خاطر من بود... (این اشتباه من بود...)"

    # say L331 gra
    old "I'm really impressed, don't know which kind of spiritual connection you have."
    new "واقعاً شگفت‌زده‌ام، نمی‌دونم چه نوع ارتباط روحی داری."

    # say L332 gra
    old "It was as if you were communicating with something higher... Something that we cannot see, something beyond our comprehension, perhaps divine."
    new "به نظر می‌رسید که با چیزی بالاتر ارتباط داشتی... چیزی که ما نمی‌توانیم ببینیم، چیزی فراتر از درک ما، شاید الهی."

    # say L333 pla
    old "Hmm yeah... Something like that"
    new "Hmm بله... چیزی مثل اون"

    # say L334 pla
    old "(Argh! I didn't save her... I'm completely useless...) "
    new "آرگه! من نتونستم کمکش کنم... من کاملاً بی‌فایده هستم..."

    # say L335 gra
    old "You're definitely closer to the divine spirit than even Father Morgan..."
    new "شما قطعاً نزدیک‌تر به روح الهی هستید از حتی پدر مورگان..."

    # say L336 pla
    old "I better go home, goodbye Sister Grace."
    new "بهتره برم خونه، خداحافظ خواهر گریس."

    # say L343 gra
    old "Wait [pla]!..."
    new "منتظر باش [pla]!"

    # say L364 mo1
    old "Good morning darling, someone is looking for you..."
    new "صبح بخیر عزیزم، کسی به دنبالت هست..."

    # say L365 pla
    old "Looking for me?... Who's that?"
    new "من رو می‌خواین؟... اونا کی هستن؟"

    # say L366 mo1
    old "Two women... An old lady and a nun, where do you know them from?"
    new "دو زن... یک مسنا و یک راهبه، از کجا می‌شناسی؟"

    # say L367 pla
    old "Ahh ok! Hmm... They're from the church, you know I have been there quite a few times..."
    new "اوه خب! هم... اونا از کلیسا هستن، می‌دونی من چند بار به اونجا رفتم..."

    # say L368 mo1
    old "I see... Well, they're waiting, go to see what they need, honey."
    new "می‌بینم... خب، اونا منتظر هستن، برو ببین چه کمکی می‌خوان، عزیزم."

    # say L369 pla
    old "Sure! Thanks [mo1]."
    new "بله! ممنون [mo1]."

    # say L376 jon
    old "Hi dear, I'm so sorry to bother you but you're the only one who can help us..."
    new "سلام عزیزم، خیلی متاسفم که بهت راهی دادیم ولی تو تنها کسی هستی که می‌تونی به ما کمک کنی..."

    # say L377 pla
    old "Hi Mrs. Jones... Hmm, me? Why? What happened?"
    new "سلام خانم جونز... هم، من؟ چرا؟ چه اتفاقی افتاده؟"

    # say L378 gra
    old "Hi [pla], well... As I told you in the church, you were a great help and we think you could do something for Billie."
    new "سلام ز[pla]، خب... همانطور که تو کلیسا بهت گفتم، تو کمک خوبی کردی و فکر می‌کنیم می‌تونی برای بیلی کاری انجام بدی."

    # say L381 jon
    old "I'm so worried for my granddaughter, I'm afraid I'll lose her... Please help me!"
    new "من برای نوه‌ام خیلی نگرانم، امیدوارم نباشم اشتباه کرده باشم... لطفاً به من کمک کنید!"

    # say L382 pla
    old "I'm so sorry to hear she's not ok... But I don't know how could I help... I'm not a doctor."
    new "متأسفم که می‌شنوم او خوب نیست... اما نمی‌دونم چطور می‌تونم کمک کنم... من پزشک نیستم."

    # say L383 gra
    old "Well, we think this case is more related on a spiritual level, and you showed divine talents, so we hope that you could help us."
    new "خب، ما فکر می‌کنیم این موضوع بیشتر روی سطح روحانی تأثیر داره و شما هم توانایی‌های الهی نشون داده‌اید، پس امیدواریم بتونید به ما کمک کنید."

    # say L384 pla
    old "And what about the Father Morgan?"
    new "و پدر مورگان چطور؟"

    # say L385 jon
    old "He already tried but didn't work and well... You're our only hope."
    new "او قبلاً امتحان کرد ولی کار نکرد و خب... شما آخرین امید ما هستید."

    # say L386 pla
    old "Alright, I'll try to help, but I'm not sure if I can-"
    new "باشه، سعی می‌کنم کمکتون کنم، اما نمی‌دونم بتونم یا نه-"

    # say L387 gra
    old "Thank you! We knew we can count on you."
    new "ممنون! ما می‌دونستیم می‌تونیم بر تو اتکا کنیم."

    # say L388 jon
    old "Come with us, we have no time to lose. "
    new "با ما بیایید، وقت زیادی نداریم."

    # say L401 jon
    old "[pla] look at her... She's suffering, please do something!"
    new "[pla] نگاه کن به اون... او درد داره، لطفاً چیزی بکن!"

    # say L402 pla
    old "Hmm let's see..."
    new "ببینیم..."

    # say L407 pla
    old "(What? The shinigami isn't dead? What's happening here!)"
    new "چه؟ شینیگامی مرده نیست؟ اینجا چه اتفاقی می‌افتد؟"

    # say L410 jon
    old "Oh my God! She is crying black tears..."
    new "اوه خداوند! او آشکهای سیاه می‌ریزه..."

    # say L412 gra
    old "Is there any way to help her [pla]?"
    new "آیا راهی برای کمک به او [pla] وجود دارد؟"

    # say L413 pla
    old "(What the fuck is this?)"
    new "این چه خرابیه؟"

    # say L414 gra
    old "[pla], are you fine? Are you in shock?"
    new "[pla]، حالت خوبه؟ شوک شده‌ای؟"

    # say L416 pla
    old "(I don't understand what's happening here. I have to talk with the shinigamis.)"
    new "من نمی‌فهمم اینجا چه اتفاقی می‌افته. باید با شینیگامی‌ها صحبت کنم."

    # say L417 pla
    old "Hmm... W- Well..."
    new "Hmm... خب..."

    # say L418 pla
    old "Hmm... I'll need to see her at night, right now I can't do anything but I'll come back later."
    new "Hmm... من باید شب‌ها با او برخورد کنم، الان هیچ کاری نمی‌تونم انجام بدم ولی بعداً برگشتم."

    # say L419 pla
    old "I need to... Prepare myself, if we do everything in the proper way, Billie will be fine soon."
    new "من باید... خودم رو آماده کنم، اگه همه چی به درستی انجام بشه، بیلی زودی خوب می‌شه."

    # say L420 jon
    old "I have no words to thank you for everything you have done for us, her life is on your hands [pla]."
    new "من کلماتی برای تشکر از همه چیزهایی که برای ما انجام داده‌ای ندارم، زندگی او در دست شماست [pla]."

    # say L421 pla
    old "(My God! I really gotta do something for her and the shinigami.)"
    new "الله! واقعاً باید برای او و شینیگامی کاری انجام بدم."

    # say L422 pla
    old "Don't worry Mrs. Jones, she'll be fine. I better go now but I'll see you later."
    new "نگران نباش خانم جونز، او خوب خواهد بود. بهتر است حالا برسم اما بعداً می‌بینیم."

    # say L423 pla
    old "See you later as well Sister Grace."
    new "تا بعداً هم می‌بینیم خواهر گریس."

    # say L425 gra
    old "Thanks! We'll be waiting for you."
    new "ممنون! منتظرت خواهیم بود."

    # say L426 jon
    old "Take care hun and thanks again."
    new "ممنون هن و دوباره مرا مراقبت کن."

    # say L449 pla
    old "I saw the shinigami! Apparently she's inside Billie's body. I saw her!"
    new "من شینیگامی رو دیدم! به نظر می‌تونه توی بدنه بیلی باشه. من دیدم!"

    # say L467 mil
    old "I'm surprised with your manners... Hi [pla]!"
    new "متعجب شدم از رفتارت... سلام ز[pla]!"

    # say L468 pla
    old "Hi hi! I know but this is important, I didn't expect to see her there..."
    new "سلام سلام! می‌دونم ولی این مهمه، نمی‌تونستم اونجا اون رو ببینم..."

    # say L469 mil
    old "Wait a sec! Who's Billie? What are you talking about?"
    new "بیا بیا! بیلی کیه؟ در می‌یاری چه حرفی؟"

    # say L470 pla
    old "Alright! Billie is a girl from the church and it seems the shinigami is inside of her, I have no idea how,.. You tell me!"
    new "باشه! بیلی دختری از کلیسا هست و به نظر می‌رسه شینیگامی داخلش هست، نمی‌دونم چطور،.. تو بگو!"

    # say L472 mil
    old "[pla], this is actually delicate, that shinigami is trapped in Billie's body, that happens when there is a lack of energy in the shinigami's body..."
    new "[pla]، این واقعاً حساسه، آن شینیگامی در بدنت بیلی گیر افتاده، این موقعیت وقتی انرژی در بدنش کم می‌شه اتفاق می‌افته..."

    # say L475 mil
    old "That shinigami is having serious problems and getting into a human's body was the only option she had..."
    new "آن شینیگامی مشکلات جدی داره و ورود به بدنه‌ی انسانی تنها گزینه‌ی او بود..."

    # say L476 gom
    old "She's struggling right now and the only way to get out of Billie's body is through an energy transfer since the body where she's now doesn't have any energy."
    new "اونجا دشواری داره و تنها راه خروج از بدنه بیلی انتقال انرژیه، چون بدنه‌ای که الان تویش هیچ انرژی نداره."

    # say L477 pla
    old "What? I thought she did possess her body... This makes more sense, that's why she's still there."
    new "چه؟ فکر کردم اونجا روحش رو داشته باشه... اینجوری منطقی‌تره، همین جلبه هنوز اونجا هست."

    # say L478 mil
    old "Yes, she can't get out by herself. Billie's body doesn't have enough energy and as I'm telling you.. The only way to help them is through a powerful load of energy."
    new "بله، او خودش نمی‌تونه بیرون بیاد. بدن بیلی انرژی کافی نداره و همونطور که بهت می‌گم... تنها راه کمک به اونا اینه که با یه بار انرژی قوی انجام بدیم."

    # say L479 gom
    old "Are you willing to do that for them?"
    new "آیا تمایل داری این کار رو برایشون انجام بدی؟"

    # say L481 pla
    old "Yes, of course... I don't want anybody to die. How can I perform that energy transfer?"
    new "بله، البته... من نمی‌خوام کسی بمیره. چطور می‌تونم اون انرژی رو منتقل کنم؟"

    # say L483 dev
    old "Come on! You already know how..."
    new "بیا! تو قبلاً می‌دونی..."

    # say L484 pla
    old "Well, the only way to get energy I know is through s- sex-... A- are you saying that I have to have sex with Billie?"
    new "خب، تنها راهی که من می‌دونم برای گرفتن انرژی از طریق جنس‌نشوندگی هست... آ- آیا می‌خوای بگی که من باید با بیلی جنس‌نشوندگی کنم؟"

    # say L485 mil
    old "You just said it... Yeah, it's the only way. Once the shinigami gets your energy, she'll be able to get out of Billie's body. There is no other way."
    new "تو هم خودت گفتی... بله، این تنها راهه. وقتی شینیگامی انرژی تو رو بگیره، بتونه از بدنه بیلی بیرون بیاد. هیچ راه دیگه‌ای نیست."

    # say L486 mil
    old "You're a young, strong and virile man. You're the only one able to help her."
    new "تو یک مرد جوان، قوی و پر انرژی هستی. تنها کسی که می‌تواند به او کمک کنه تو هستی."

    # say L487 pla
    old "I get it, I'll do whatever it takes to help her."
    new "فهمیدم، هر چی لازم باشه برای کمک بهش انجام می‌دم."

    # say L488 mil
    old "Get ready for it! You'll have to last much longer since it will not be easy but we know you can do it."
    new "آماده شو! باید طولانی‌تر صبر کنی چون آسون نیست ولی میدونیم تو می‌تونی این کار رو انجام بدی."

    # say L490 pla
    old "I'll do my best for her to come and come out... See you girls."
    new "من برای اون دختر خواهم زد و خواهم آمد... ببینم شما دختران."

    # say L492 mil
    old "See you [pla], we're counting on you."
    new "ببینیم [pla]، به تو اعتماد داریم."

    # say L494 gom
    old "Please take care, [pla]"
    new "لطفاً مرا در نظر بگیرید، [pla]"

    # say L514 pla
    old "Hello Mrs. Jones, Sister Grace..."
    new "سلام خانم جونز، خواهر گریس..."

    # say L515 jon
    old "Hi dear, we're so glad you're here... Let's start now. Tell us how to help you."
    new "سلام عزیزم، خوشحالم که اینجا هستی... بیاین شروع کنیم. بگو چطور می‌تونیم به تو کمک کنیم."

    # say L516 gra
    old "Dear [pla], we are at your service, just tell us how we help you."
    new "عزیز ز[pla]، ما در خدمت شما هستیم، فقط به ما بگویید چطور می‌توانیم به شما کمک کنیم."

    # say L517 jon
    old "We trust you and the gifts that the Lord has given you, please help my Billie."
    new "ما به شما و هدایایی که خداوند به شما داده است اعتماد داریم، لطفاً به بیلی کمک کنید."

    # say L518 pla
    old "(They can't be here... I gotta say something for them to go out...)"
    new "من نمی‌تونم اینجا باشند... باید چیزی بگم تا بروند."

    # say L519 jon
    old "Tell us! Tell us hun!"
    new "بگو! بگو عزیزم!"

    # say L523 jon
    old "Are you ok? What's happening? Why don't we start now?"
    new "حالت خوبه؟ چه اتفاقی افتاده؟ چرا ما الان شروع نکنیم؟"

    # say L524 pla
    old "Yes, n- no. I- I mean, I'll start now but you can't be here, this is an important ritual that I must do alone."
    new "بله، نه. منظورم اینه که الان شروع می‌کنم ولی تو نمی‌تونی اینجا باشی، این مراسم مهمیه که باید فقط من انجام بدم."

    # say L525 gra
    old "Alone? Why? We could assist you with our presence and prayers."
    new "تنهایی؟ چرا؟ ما می‌توانیم با حضور و دعا بهت کمک کنیم."

    # say L526 pla
    old "Hmm... Because, it's how it should be, could be dangerous for you."
    new "هم... چون همینطور باید باشه، ممکنه برایت خطرناک باشه."

    # say L527 pla
    old "I don't think you're prepared to see what I'll do..."
    new "فکر نمی‌کنم آماده باشی برای دیدن اون چیزی که من می‌کنم..."

    # say L528 pla
    old "Billie? Billie, do you hear me?"
    new "بیلی؟ بیلی، آیا می‌شنی منو؟"

    # say L530 lin
    old "Gulp... is tha-?"
    new "gulp... این-؟"

    # say L531 jon
    old "My Godness! Billie spoke! Let's get out of here. He knows what he's doing."
    new "الهی! بیلی صحبت کرد! بیایید از اینجا برویم. او می‌داند چه کاری می‌کند."

    # say L532 pla
    old "Please leave me alone with her, we can't waste more time."
    new "لطفاً ما رو به هم تنهایی بگذارید، نمی‌تونیم وقت بیشتری ببریم."

    # say L533 lin
    old "I- I n- need h- help."
    new "من- من ن- نیاز به کمک دارم."

    # say L534 gra
    old "Call us if you need anything, [pla]."
    new "اگر نیازی داشتی تماس بگیر، [pla]."

    # say L548 pla
    old "Alright, how I'm gonna do this?"
    new "باشه، اینو چطور باید انجام بدم؟"

    # say L549 pla
    old "Shinigami? Billie?"
    new "شینیگامی؟ بیلی؟"

    # say L551 lin
    old "Y- You're here! P- please help me to get out of her, I- I'm trapped."
    new "تو اینجا هستی! لطفاً کمک کن به من برای خروج، من گیر افتاده‌ام."

    # say L552 pla
    old "I know... You know the only way is through an energy transfer process, right?"
    new "می‌دونم... می‌دونی تنها راه اینجاست که از طریق یک فرایند انتقال انرژی بگذره، درسته؟"

    # say L553 lin
    old "Y- Yes, please hurry up! I- I'll die if we don't do it."
    new "ب- بله، لطفاً سریع‌تر بکن! من- من می‌میرم اگه اینجوری ادامه بده."

    # say L554 pla
    old "We'll need to have s- sex, well... You know it's how it's called."
    new "باید جنس کنیم، خب... می‌دونی اینجوری می‌گن."

    # say L556 lin
    old "Shoot! C- Can you simply do it!? I already know what you're saying. I need you to do it now!"
    new "بفرما! می‌تونی سریع‌تر بشه؟! من قبلاً می‌دونم چی می‌گی. حالا باید این کار رو بکنی!"

    # say L557 pla
    old "No! No, I was just saying..."
    new "نه! نه، من فقط می‌گفتم..."

    # say L558 pla
    old "But I shouldn't have sex with this girl, I don't even know her."
    new "ولی من نباید با این دختر جنسیتی داشته باشم، من حتی نمی‌شناسم."

    # say L564 lin
    old "W- what you are going to do is share a magical power with me the shinigami... Don't overthink it. "
    new "چ- چیزی که قراره انجام بدی اینه که قدرت جادویی‌ای رو با من شینیگامی به اشتراک بگذاری... نباید خیلی فکر کنی."

    # say L565 lin
    old "I need you to free me now... Do it..."
    new "من نیاز دارم الان از من آزاد کنی... انجام بده..."

    # say L595 jon
    old "My God! What's going on here? What did you do to Billie?"
    new "اللهی! اینجا چه اتفاقی افتاده؟ تو چه کاری به بیلی کردی؟"

    # say L597 pla
    old "(Oh no! Now what?!)"
    new "اوه نه! حالا چه کاری باید بکنم؟"

    # say L599 jon
    old "[pla]? Is this part of the ritual you had planned to perform? I don't understand..."
    new "[pla]؟ این بخشی از مراسمی است که قرار بود انجام بدی؟ من نمی‌فهمم..."

    # say L600 pla
    old "(Damn it! What should I say?)"
    new "لعنتی! باید چی بگم؟"

    # say L605 bil
    old "Grandma? Sister Grace? Where am I?... What happened?"
    new "بабا؟ خواهر گریس؟ من کجاییم؟... اتفاق چه چیزی افتاد؟"

    # say L606 bil
    old "Someone tell me what happened to me? Why am I naked and sweating?"
    new "لطفاً به من بگویید اتفاق چه چیزی به من افتاده؟ چرا من عریان و تعریق می‌کنم؟"

    # say L607 gra
    old "Well! She looks much better now..."
    new "خب! حالا بهتر به نظر می‌رسد..."

    # say L610 jon
    old "My God, thanks! She's back!"
    new "الهی، ممنون! او برگشته!"

    # say L611 bil
    old "Huhh, what is going on?"
    new "هه، اینجا چه اتفاقی افتاده؟"

    # say L612 gra
    old "We know you must be feeling so confused about everything..."
    new "ما می‌دونیم باید خیلی گیج باشی از همه چی..."

    # say L613 gra
    old "Your body was possessed by a spirit, but [pla] helped us perform a ritual and now you're back, you're fine now... "
    new "روح تو توسط یک جان تملک شده بود، اما [pla] به ما کمک کرد تا مراسمی انجام بدیم و حالا تو دوباره خوبی، همه چیز خوبه..."

    # say L614 bil
    old "What? My body... Possessed? What the fuck?"
    new "چه؟ بدنم... تملک شده؟ چه خرابی؟"

    # say L615 gra
    old "Yes, it happened while we all were at the church, we don't know why but what matters now is that you're fine."
    new "بله، این اتفاق وقتی که ما همه در کلیسا بودیم افتاد، ما نمی‌دونیم چرا اتفاق افتاده ولی اهمیتش الان اینه که تو خوبی."

    # say L618 gra
    old "I guess that what [pla] did was part of the ritual..."
    new "به نظر می‌رسه آنچه [pla] انجام داده بخشی از مراسم بوده..."

    # say L620 pla
    old "It was part of the ritual... It was the only way to help her out."
    new "این بخش از مراسم بود... تنها راه کمک به او این بود."

    # say L621 gra
    old "She seems to be totally fine now, I don't feel the spirit's presence anymore."
    new "او الان کاملاً خوب است، دیگر حضور روح را حس نمی‌کنم."

    # say L622 pla
    old "She's fine now, I've cleaned her body from the spirit's presence... Now she's fine and healthy."
    new "او حالا خوب است، جسمش را از حضور روح پاک کردم... حالا او سالم و خوشحال است."

    # say L624 jon
    old "Don't worry my love, you're fine now. You just need to rest..."
    new "نگران نباش عزیزم، حالا خوبی. فقط باید استراحت کنی..."

    # say L627 bil
    old "Huhh could you please let me go? I'm not breathing..."
    new "هuh، لطفاً برام جایی بده؟ من نفس نمی‌کشم..."

    # say L633 gra
    old "Ohh, sorry... It's just that we're so happy you're fine..."
    new "اوه، معذرت... فقط خوشحالم که حالت خوبه..."

    # say L634 gra
    old "Thanks [pla], you have been such a great help."
    new "ممنون [pla]، خیلی کمکت کردی."

    # say L637 jon
    old "Yeah, thanks hun, I'm so grateful with you, you're a saint. Definitely God is inside of you..."
    new "بله، ممنون عزیزم، ازت خیلی ممنونم، تو مثل یک فرشتگی هستی. قطعاً خدا تو رو درون خودش دارد..."

    # say L638 pla
    old "Don't worry, I just did what... God told me to do... I'll be here to help."
    new "نگران نباش، فقط انجام دادم آنچه... خداوند به من فرمان داد... من اینجا هستم تا کمکت کنم."

    # say L639 pla
    old "I should be going now... It's been a very demanding ritual and I need to get some rest."
    new "باید حالا برسم... مراسم خیلی خسته‌کننده بود و باید یه استراحت بکنم."

    # say L641 jon
    old "Sure hun! Take care and thanks again!"
    new "البته عزیزم! مراقب خودت با و ممنون از کمکت."

    # say L642 pla
    old "Mmm... Thanks, see you Mrs. Jones... Bye Sister Grace."
    new "ممنون، خداحافظ خانم جونز... خداحافظ خواهر گریس."

    # say L643 gra
    old "Bye dear [pla]"
    new "خداحافظ عزیزم [pla]"

    # say L655 bil
    old "What was that naked guy doing here?"
    new "آقای عریان اینجا چه کار می‌کرد؟"

    # say L672 pla
    old "How are you feeling? Are you ok?"
    new "حالت چطوره؟ خوبی؟"

    # say L674 pla
    old "You know what... There are more shinigamis like you, we can help you."
    new "می‌دونی... هستن شینیگامی‌های دیگه مثل تو، می‌تونیم بهت کمک کنیم."

    # say L675 lin
    old "Who are you? Why are you helping me?"
    new "تو کی هستی؟ چرا به من کمک می‌کنی؟"

    # say L676 pla
    old "Oh yes, sorry! I'm [pla], as I just told you... I know others like you."
    new "اوه بله، معذرت! من [pla] هستم، همانطور که به تو گفتم... من افرادی مثل تو را می‌شناسم."

    # say L677 lin
    old "I see... Nice to meet you [pla], I'm Linett and well..."
    new "ممنون... خوشحالم که با تو آشنا شدم [pla]، من لینت هستم و خب..."

    # say L678 lin
    old "I feel better now but still weak, I don't have enough energy yet."
    new "حالا خوبتر هستم اما هنوز ضعیف هستم، انرژی کافی ندارم."

    # say L680 pla
    old "Do you think we should continue with the energy transfer?"
    new "فکر می‌کنی باید انتقال انرژی رو ادامه بدیم؟"

    # say L682 lin
    old "Hmm, we definitely have to continue the energy transfer, everything you shared with me was just to get out of that girl's body."
    new "Hmm، حتماً باید ادامه بدهیم به انتقال انرژی، همه چیزی که با من به اشتراک گذاشتی فقط برای خروج از بدنت آن دختر بود."

    # say L683 pla
    old "Hmm ok, no problem, let's do it."
    new "Hmm خب، مشکلی نداره، بیاین انجام بدیم."

    # say L684 lin
    old "Great! It's better if I suck you cock first, that will give me initial energy so that later you continue with the whole transfer."
    new "عالی! بهتره اول نوزک تو رو بکشم، اینجوری انرژی اولیه‌ام رو بدست میارم تا بعدا تو ادامه بدهی به تبدیل کامل."

    # say L685 lin
    old "Are you fine with that?"
    new "آیا با این راحتی داری؟"

    # say L686 pla
    old "Yeah, I already told you I'm here to help and if I have to do that... I won't let you down."
    new "بله، قبلاً به تو گفتم که همینجا هستم تا کمک کنم و اگر باید این کار رو بکنم... نمی‌تونم تو رو خیابان بگذارم."

    # say L690 lin
    old "That's the attitude we need... One more thing, could you please turn on the lights, I prefer to watch what I'm doing..."
    new "این همین روحیه‌ایه که لازم داریم... یه چیز دیگه، می‌تونی لطفاً نور رو روشن کنی؟ من ترجیح میدم ببینم چی کار می‌کنم..."

    # say L691 pla
    old "Ehmm... Sure."
    new "اهم... حتماً."

    # say L704 pla
    old "So how are you now?"
    new "پس حالا حالت چطوره؟"

    # say L705 lin
    old "Totally fine... You really did excellent!"
    new "کاملاً خوبم... واقعاً عالی کار کردی!"

    # say L706 pla
    old "I'm glad you're fine now but... Are you gonna tell me what were you doing at the church? What was happening there?"
    new "خوشحالم که حالا خوبی اما... قراره به من بگی چه کاری تو کلیسا انجام میدادی؟ اونجا چه اتفاقی افتاده؟"

    # say L707 lin
    old "Yes, sure! Well... Hmm."
    new "بله، حتماً! خب...Hmm."

    # say L708 lin
    old "I was trying to do a small ritual to achieve a reception of energy, for this it was required to deliver a lot of energy and I thought that with me it would have been enough, but it wasn't."
    new "من سعی می‌کردم مراسم کوچکی برای دریافت انرژی انجام بدهم، برای این کار لازم بود انرژی زیادی تحویل بدم و فکر می‌کردم با من کافی باشه، اما نبود."

    # say L710 lin
    old "I tried to condense the magic power but since I didn't have enough energy, I got weak and got trapped in the church and later, in Billie's body."
    new "من سعی کردم تا قدرت جادویی رو متمرکز کنم، اما چون انرژی کافی نداشتم، ضعیف شدم و در کلیسا گیر افتادم و بعدش تو بدن بیلی گیر افتادم."

    # say L711 lin
    old "We have to restore the power generator through a magic ritual and we only have one chance."
    new "باید تولیدکننده انرژی رو از طریق یه مراسم جادویی بازسازی کنیم و فقط یه فرصت داریم."

    # say L712 pla
    old "So we gotta find the way to do it, tell me what to do and I'll do it... Now it's my responsibility as well."
    new "پس باید راهش رو پیدا کنیم، بگو چی کار کنم و من انجام میدم... حالا این هم مسئولیتمه."

    # say L714 lin
    old "Are you sure? Are you sure you wanna help? You'll have to do lots of things."
    new "مطمئنی؟ مطمئنی می‌خوای کمک کنی؟ باید کارهای زیادی انجام بدی."

    # say L715 pla
    old "Well, I've done some already and I'm willing to do more."
    new "خب، من قبلاً بعضی از کارها رو انجام دادم و آماده‌ام بیشتر هم کنم."

    # say L716 lin
    old "Ok... Well, the church is a special point and has an unique vibration that allows us to collect more energy."
    new "خب... خب، کلیسا نقطه‌ای خاصه و ارتعاش خاصی داره که می‌تونه به ما کمک کنه تا انرژی بیشتری جمع کنیم."

    # say L717 lin
    old "[pla], you gotta have sex with humans, so you will collect more energy and it should be done soon... We don't have much time."
    new "[pla]، باید با انسان‌ها جنسیت داشته باشی تا انرژی بیشتری جمع کنی و باید زودتر انجام بشه... وقت زیادی نداریم."

    # say L718 pla
    old "What? Why do I need to have sex with humans? I mean, I get that it's the way to transfer energy but... Why not with the shinigamis?"
    new "چه کاری؟ چرا باید با انسان‌ها جنسیت داشته باشم؟ منظورم اینه که می‌فهمم انتقال انرژی از این طریقه اما... چرا نه با شینیگامی‌ها؟"

    # say L719 lin
    old "It's dangerous, the shinigamis could get trapped... And you already know it's not easy to get out of a human's body. It's too risky at this point."
    new "خطرناکه، شینیگامی‌ها ممکنه گیر بیافتن... و تو قبلاً می‌دونی که از بدنش انسان خارج شدن آسون نیست. الان خیلی ریسک‌بره."

    # say L720 lin
    old "And on the other hand, we need people with a great concentration of power. You gotta look for at least two people who have this. Otherwise..."
    new "و از طرف دیگه، ما به افرادی با تمرکز قدرت بالا نیاز داریم. باید حداقل دو نفر با این شرط رو پیدا کنی. در غیر این صورت..."

    # say L721 lin
    old "It won't work..."
    new "نمی‌تونه کار کنه..."

    # say L722 pla
    old "Hmm... Ok, I get it..."
    new "Hmm... بله، متوجه شدم..."

    # say L723 pla
    old "(Actually I could try it with... The nun and Mrs. Jones would be perfect for that.)"
    new "در واقع می‌تونم با خواهر گریس و خانم جونز امتحان کنم. آنها برای این کار مناسب هستند."

    # say L724 lin
    old "Are you already thinking on someone?"
    new "البته، قراره به فردی فکر کنی؟"

    # say L726 pla
    old "Yeah, I do know two women... But It won't be easy... Sister Grace and Mrs. Jones, are part of the church's community and they liked me."
    new "بله، دو زن رو می‌شناسم... اما آسون نیست... خواهر گریس و مس جونز بخشی از جامعه کلیسا هستن و من رو دوست داشتن."

    # say L727 pla
    old "I'm not sure but I could definitely try..."
    new "من مطمئن نیستم اما قطعاً می‌تونم سعی کنم..."

    # say L729 lin
    old "That's great! Do it... We have to try because it's our last chance, otherwise we'll have to wait until next year."
    new "عالیه! انجام بد... باید سعی کنیم چون این آخرین فرصتمونه، در غیر این صورت باید تا سال بعد منتظر بمانیم."

    # say L730 lin
    old "The energy that will emerge in the church will only increase in this period of the year, that's why it's so important."
    new "انرژی‌ای که در کلیسا ظاهر می‌شه فقط توی این دوره سال افزایش می‌یابه، همین جا اهمیتش هست."

    # say L732 lin
    old "Now you know what we've to do... I'll get some rest and you should as well, you'll be very busy the next few days."
    new "حالا می‌دونی چه کاری باید بکنیم... من یه قدر خواب می‌کنم و تو هم باید اینجوری بکنی، چون روزهای بعدت خیلی مشغولی."

    # say L733 pla
    old "I can imagine... Ahh... I forgot to tell you, nice to meet you."
    new "می‌تونم بگم... اه... فراموش کردم بگم، خوش‌آمد."

    # say L734 lin
    old "After all we've done you say that... Haha, good night [pla]"
    new "بعد از همه این کارها می‌گی‌ای این... هاها، شب خوبی [pla]"

    # say L735 pla
    old "Good night, Linett."
    new "شب خوب باش، لینت."

    # menu L759 
    old "Ritual"
    new "مراسم"

    # say L761 lin
    old "[pla] how's it going? Are you ready for the ritual?"
    new "[pla] چطوری؟ آماده‌ی مراسم شدی؟"

    # say L762 pla
    old "I'm... I'm still preparing myself for it..."
    new "من... من هنوز برایش آماده نشدم..."

    # say L763 lin
    old "Great! If you need anything, just let me know..."
    new "عالی! اگه نیازت به هر چیزی بود، فقط به من بگو..."

    # say L764 pla
    old "Thanks, I'll... Now I should go..."
    new "ممنون، من باید برم..."

    # say L765 lin
    old "Alright, see you!"
    new "باشه، خداحافظ!"

    # menu L767 
    old "Share your magic power"
    new "تو قدرت جادوییت رو با من به اشتراک بگذار"

    # say L769 lin
    old "Hey [pla], how are you?"
    new "اوه [pla]، چطوری؟"

    # say L770 pla
    old "I'm totally fine, I was wondering if you need me to share some magic power with you?"
    new "من کاملاً خوبم، فقط فکر می‌کردم ممکنه نیاز داشتی از من قدرت جادویی به اشتراک بگیری؟"

    # say L771 lin
    old "You're such a kind man! Yes, I need some power... Please give it to me!"
    new "تو چنین آدم خوبی هستی! بله، به من قدرتی لازم است... لطفاً به من بده!"

    # menu L780 
    old "Ask for magic power"
    new "من به تو قدرت جادویی بدهم؟"

    # say L782 pla
    old "Hey, how are you?"
    new "سلام، چطوری؟"

    # say L783 lin
    old "Hey [pla], I'm fine... What can I do for you?"
    new "اها ز[pla]، خوبم... تو چی می‌خوای از من؟"

    # say L784 pla
    old "I need some magic power... Could you please share some with me?"
    new "من به یک قدرت جادویی نیاز دارم... می‌تونی یه کمی رو با من به اشتراک بذاری؟"

    # say L785 lin
    old "I can always share my power with you..."
    new "می‌تونم همیشه قدرتم رو با تو در میون بذaram..."

    # say L806 lin
    old "It was good as usual, I'm feeling much more energetic now."
    new "همیشه مثل همین خوب بوده، حالا انرژی‌ام خیلی بیشتر شده."

    # say L807 pla
    old "I'm glad I can always help!"
    new "خوشحالم که همیشه می‌تونم کمکت کنم!"

    # say L809 lin
    old "See you [pla]"
    new "ببینم تو [pla]"

    # say L820 pla
    old "Thanks Linett, that was very energizing!"
    new "ممنون لینت، این خیلی انرژی‌دهن بود!"

    # say L821 lin
    old "It was... I'm here whenever you need me"
    new "بود... هر وقت نیازت به من بود، من اینجا هستم"

    # say L822 pla
    old "Great! See you!"
    new "عالی! ببینم!"

    # say L836 lin
    old "Hey [pla]! Long time no see. How are you?"
    new "اوه ز[pla]! خیلی وقت ندیده‌تم. چطوری؟"

    # say L837 pla
    old "Woah! Linett! You scared me!"
    new "وای! لینت! از جاش شوکه شدم!"

    # say L838 pla
    old "What are you doing here?"
    new "تو اینجا چه کاری داری؟"

    # say L839 lin
    old "I have to talk with you. It's important."
    new "من باید با تو صحبت کنم. این مهم است."

    # say L840 lin
    old "So, I was waiting here for you to wake up."
    new "پس من اینجا منتظر بیدار شدن تو بودم."

    # say L842 pla
    old "Yeah well. That's a bit weird."
    new "بله خب. این کمی عجیب است."

    # say L843 pla
    old "But anyway, what did you wanna tell me?"
    new "اما باید، تو چی می‌خواستی به من بگی؟"

    # say L845 lin
    old "It's about the ritual we did in the church, do you remember?"
    new "این در مورد مراسمی است که در کلیسا انجام دادیم، بهش یادت می‌آید؟"

    # say L846 pla
    old "Yeah I do, what about it?"
    new "بله، به یاد دارم، چه خبری از اون؟"

    # say L847 lin
    old "Well, it's been a while since we tried it, and I think we should give it another go."
    new "خب، از آن موقع که اون کار رو انجام دادیم گذرنده شده، فکر می‌کنم باید دوباره امتحانش کنیم."

    # say L848 lin
    old "After all, we still need those portals to generate magic again. And we're nearing the time of year to do it."
    new "در نهایت، هنوز به درگاه‌ها نیاز داریم تا جادو رو دوباره ایجاد کنیم. و ما به زمان سالی که باید این کار رو انجام بدیم نزدیک شده‌ایم."

    # say L850 pla
    old "But it didn't work last time, right?"
    new "اما بار اول کار نکرد، درسته؟"

    # say L851 lin
    old "It didn't."
    new "نه، نشد."

    # say L852 lin
    old "And to be honest. I don't really know why..."
    new "و صداقت بگم. واقعاً نمی‌دونم چرا..."

    # say L853 lin
    old "I've been thinking about it, but I can't come up with a full explanation."
    new "من در موردش فکر کردم، اما نمی‌تونم توضیح کاملی بدهم."

    # say L855 pla
    old "And you still want to try again? I mean... If we don't know what went wrong last time."
    new "و هنوز می‌خوای دوباره امتحان کنیم؟ منظورم اینه... اگه ما ندیدیم چه خرابی پیش اومده بود."

    # say L856 pla
    old "How do we know this time it's going to work?"
    new "چطور می‌دونیم این بار کار می‌کنه؟"

    # say L858 lin
    old "About that, I said I didn't know but I do have some ideas as to what could make it work this time."
    new "در مورد این، گفتم نمی‌دونم ولی بعضی ایده‌ها دارم که می‌تونه این بار کار کنه."

    # say L859 lin
    old "An important part of what went wrong, is that we couldn't direct the magic power the way we needed it to go."
    new "بخش مهمی از اینکه چه چیزی اشتباه شده، این بود که ما نتونستیم توان جادویی رو به جایی که باید برود هدایت کنیم."

    # say L861 pla
    old "Direct? What do you mean?"
    new "راهنما کردن؟ منظورت چیه؟"

    # say L862 lin
    old "Well, as you can see when you use the agamoto's eye."
    new "خب، همانطور که می‌بینی وقتی از چشم آگامتو استفاده می‌کنی."

    # say L863 lin
    old "Magic power is, in essence, a series of particles that human bodies are able to absorb."
    new "توی اصل، قدرت جادویی مجموعه‌ای از ذرات هست که بدن انسان‌ها می‌تونن جذب کنن."

    # say L864 lin
    old "However, human bodies are not designed to use and direct these particles into a specific point."
    new "البته، بدن انسان برای استفاده و هدایت این ذرات به نقطه خاصی طراحی نشده است."

    # say L865 lin
    old "So we weren't able to condense the magic in the place we needed to."
    new "پس ما نتونستیم جادو رو تو جایی که لازم بود متمرکز کنیم."

    # say L867 pla
    old "But we did in the church, you said that was where it had to be."
    new "ولی در کلیسا انجام دادیم، گفتی که همینجا باید بود."

    # say L868 lin
    old "Yeah sure, but it couldn't be the whole church, it has to be a specific point where the breach can occur."
    new "بله، اما نمی‌تونه کل کلیسا باشه، باید نقطه‌ای خاص باشه که در آن شکستگی می‌افتد."

    # say L869 pla
    old "Hmm, ok. So what do we have to do this time to make it happen?"
    new "Hmm، اوکی. پس این بار باید چه کار کنیم تا اتفاق بیفتد؟"

    # say L871 lin
    old "To be honest, I'm not sure yet. I have to figure it out soon."
    new "صusch، هنوز مطمئن نیستم. باید زودتر این موضوع رو شکل بدم."

    # say L873 lin
    old "However, it is true that the magic power is running out."
    new "ولی درست است که قدرت جادویی در حال خروج از کار است."

    # say L874 lin
    old "That means we definitely have to do it again soon. And it has to be in the church."
    new "این بدان معناست که حتماً باید دوباره انجام بدیم و باید در کلیسا باشه."

    # say L876 lin
    old "So, while I figure it all out, you talk to the church people again, so we have access to it."
    new "پس، در حالی که من همه این‌ها رو حل می‌کنم، تو دوباره با مردم کلیسا صحبت کن، تا به داخلش دسترسی داشته باشیم."

    # say L877 pla
    old "Oh, damn, do we have to do it again with them?"
    new "اوه، لایه، ما باید دوباره با اونا انجام بدیم؟"

    # say L878 lin
    old "Not necessarily... Let me solve this first."
    new "لزوماً نه... بگذار اینو اول حل کنم."

    # say L879 lin
    old "For now just try and make sure we can use the church again when the moment comes, ok?"
    new "برای حالا فقط سعی کن به این طور باشیم که وقتی لحظه می‌رسه، دوباره از کلیسا استفاده کنیم، خوبه؟"

    # say L881 pla
    old "Sure, no problem, I'll handle it."
    new "بله، هیچ اشکالی نداره، من اینجوری می‌کنم."

    # say L883 lin
    old "Fine, then I'll keep in touch in case we need something else."
    new "البته، اگر نیاز به چیز دیگری داشتیم، تماس خواهم گرفت."

    # say L902 gra
    old "Oh my! What a wonderful surprise! Hello [pla]!"
    new "اوه، چه مفاجأه خوبی! سلام [pla]!"

    # say L903 pla
    old "Hello Sister Grace, nice seeing you again."
    new "سلام خواهر گریس، خوشحالم دوباره دیدت."

    # say L904 gra
    old "And what do I owe this nice surprise?"
    new "و این مفاجأه خوب برای چه است؟"

    # say L905 pla
    old "I just wanted to say hello. And see if you need help with anything."
    new "فقط می‌خواستم سلام بگم. و ببینم آیا به چیزی نیاز داری."

    # say L906 pla
    old "You know, with decorating and stuff. I have some free time, so I figured I could help you."
    new "می‌دونی، برای تزیین و اینا. وقت خالی دارم، پس فکر کردم می‌تونم به تو کمک کنم."

    # say L908 gra
    old "Oh lord! You're sent again from the heavens, this is perfect."
    new "اوه خداوند! دوباره از آسمان فرستاده شده‌ای، این کامله."

    # say L909 gra
    old "Just today we were going to start with the Christmas decorations. So you came at the right moment."
    new "امروز همین می‌خواستیم شروع به تزیینات کریسمس کنیم. پس در زمان مناسبی اومدی."

    # say L910 pla
    old "Oh really? That's perfect, I can help with whatever you need."
    new "اوه واقعاً؟ عالیه، می‌تونم تو هر کاری که لازم داری کمکت کنم."

    # say L911 gra
    old "Come with me, I'll show you."
    new "بیا با من، بهت نشون می‌دم."

    # say L918 jon
    old "[pla]! what a nice surprise!"
    new "[pla]! چه مفاجا عالی است!"

    # say L919 pla
    old "Hi Mrs. Jones."
    new "سلام خانم جونز."

    # say L920 jon
    old "Hello darling, it's good to see you. And may I ask what brings you here?"
    new "سلام عزیزم، خوشحالم که تو رو دیدم. می‌تونم بپرسم چه خبری هست؟"

    # say L921 pla
    old "I just came to see if I could help with the Christmas decorations."
    new "فقط برای دیدن اگه می‌تونم تو تزیینات کریسمس کمک کنم."

    # say L922 jon
    old "Oh! Well, that's very nice of you. And you came just in time, we were about to start."
    new "اوه! خوب، این خیلی لطف داری. و تو هم در زمان مناسبی اومدی، ما همین حالا می‌خواستیم شروع کنیم."

    # say L923 gra
    old "I was telling him just that, the Lord knew we needed his help and sent him to us."
    new "من همینجور به او می‌گفتم، خداوند می‌دانست که به کمکش نیاز داریم و او را برای ما فرستاد."

    # say L924 jon
    old "Well darling, let's not waste time, come with us, we'll show you what we need."
    new "خب عزیزم، بیای با ما، وقت رو تلف نکنیم، نشون می‌دهیم چه کاری باید انجام بدی."

    # say L926 gra
    old "We need your help with putting up the decorations for Christmas."
    new "ما به کمکت برای قرار دادن تزیینات کریسمس نیاز داریم."

    # say L927 jon
    old "The decorations have to be put on the benches and up in the ceiling."
    new "تزیین‌ها باید روی صندلی‌ها و بالای سقف قرار بگیرند."

    # say L928 jon
    old "It has to be ready before Christmas eve for the members of the congregation to enjoy."
    new "باید قبل از شب عید میلاد آماده شه تا اعضای جمعیت لذت ببرن."

    # say L929 pla
    old "Sure thing, no problem."
    new "بله، هیچ اشکالی نداره."

    # narrator L936 
    old "Click all the marked spaces in time to decorate the church."
    new "با همه فضاهای مشخص شده در زمان مناسب برای تزیین کلیسا کلیک کن."

    # say L952 pla
    old "Good morning Mrs. Jones, Sister Grace."
    new "صبح بخیر خانم جونز، خواهر گریس."

    # say L953 gra
    old "Hello [pla], what a blessing from the lord seeing you today."
    new "سلام ز[pla]، چه نعمة از خداوند که امروز شما را می‌بینم."

    # say L954 jon
    old "Hello darling, how are you?"
    new "سلام عزیزم، حالت چطوره؟"

    # say L955 pla
    old "I'm fine thank you, I came to help you with the decorations again."
    new "من خوبم ممنون، اومدم تا دوباره به تو در تزیینات کمک کنم."

    # say L956 gra
    old "Oh thank you so much, you're of such great help."
    new "اوه خیلی ممنون، شما خیلی کمک کننده هستید."

    # say L957 jon
    old "Sister Grace is right, it's nice that you came back today. Thank you darling."
    new "خواهر گریس درست می‌گه، خوشحالم که امروز برگشته‌ای. ممنون عزیزم."

    # say L958 pla
    old "It's no problem."
    new "خواهش می‌کنم."

    # say L959 pla
    old "I'll get to it then."
    new "من بهش می‌پردازم."

    # say L978 jon
    old "Oh darling! You're such a good worker."
    new "اوه عزیزم! تو یک کارگر خوبی هستی."

    # say L979 gra
    old "I'm sure if you keep going at this pace you'll have it ready in no time."
    new "اگر این سرعت رو حفظ کنی، قطعاً زودتر آماده خواهد شد."

    # say L981 jon
    old "Having you do all this work really helps us a lot."
    new "داشتن تو اینجا و انجام همه این کار‌ها برای ما خیلی مفید است."

    # say L982 gra
    old "I agree, the Lord graced us with this great help of yours."
    new "من هم موافقم، خداوند ما را با این کمک بزرگت مبارک ساخته است."

    # say L983 jon
    old "Now, I'm sure you have some other things to do. So we won't keep you here anymore."
    new "البته، مطمئن هستم که شما کارهای دیگری هم دارید. پس ما شما را اینجا نگه نخواهیم داشت."

    # say L984 jon
    old "But make sure to come back soon."
    new "اما حتماً زود بیایید."

    # say L986 pla
    old "Sure, I'll be back soon and keep helping you."
    new "البته، زودی بر می‌گردم و همچنان به تو کمک می‌کنم."

    # say L1023 jon
    old "Well... You didn't really do much today."
    new "خب... امروز خیلی کاری انجام ندادی."

    # say L1024 jon
    old "But it's ok, it's a delicate thing to do. I'm sure you'll get the hang of it soon."
    new "اما خوبه، این کار حساسه. مطمئنم زودی آشنا می‌شی."

    # say L1025 gra
    old "That's right, the lord will illuminate you and you'll get better at it. Don't worry."
    new "بله، خداوند شما را هدایت خواهد کرد و شما به تدریج بهتر می‌شوید. نگران نباشید."

    # say L1026 pla
    old "Yeah... Sure."
    new "بله... حتماً."

    # say L1027 pla
    old "I have a couple of things to do, so I think I'll get going, but I'll come back again and keep working."
    new "من چند کار دارم، پس فکر می‌کنم بروم، ولی دوباره می‌آیم و ادامه می‌دم."

    # say L1028 jon
    old "We know you will, don't worry."
    new "ما مطمئن هستیم که برمی‌گردی، نگران نباش."

    # say L1042 lin
    old "Hey [pla]. I figured out what the problem was."
    new "اوه ز[pla]. من فهمیدم مشکل چی بود."

    # say L1043 pla
    old "Huh? Problem? Good morning by the way."
    new "ه؟ مشکل؟ صبح بخیر هم."

    # say L1044 lin
    old "Yeah, the problem we had with the ritual last time, I figured out what it was."
    new "بله، مشکلی که توی مراسم قبلی داشتیم، فهمیدم چی بود."

    # say L1045 pla
    old "Oh right, right. I remember."
    new "اوه درست، درست. به یاد دارم."

    # say L1046 pla
    old "So? What was it?"
    new "پس؟ چه بود؟"

    # say L1048 lin
    old "Well, I figured out that the problem last time, was that we did it with human bodies that couldn't retain as much magic power."
    new "خب، من فهمیدم مشکل آخرین بار این بود که ما با بدنه‌های انسانی کار کردیم که قدرت جادویی را به اندازه کافی نمی‌تونستن نگه دارن."

    # say L1049 lin
    old "Well, two of them couldn't."
    new "خب، دو تای اونا نتونستن."

    # say L1050 pla
    old "What? What does that mean?"
    new "چه معنی داره؟"

    # say L1051 lin
    old "Unlike us, you humans get old as time passes."
    new "برخلاف ما، شما انسان‌ها با گذشت زمان می‌سنگینید."

    # say L1052 lin
    old "This means that the older you get, the less magic power you're able to retain."
    new "این به این معناست که هر چه سن تو بیشتر می‌شه، توانایی نگه‌داشتن قدرت جادویی کمتر می‌شه."

    # say L1053 lin
    old "I believe that's the mistake we made last time."
    new "من فکر می‌کنم این اشتباهی بود که بار قبل انجام دادیم."

    # say L1054 lin
    old "So this time it has to be done with young people. They should be able to retain the amount of magic we need."
    new "پس این بار باید با جوانان انجام شه. اونا باید توانایی نگه‌داشتن قدرت جادویی لازم رو داشته باشن."

    # say L1056 pla
    old "Three young girls... I mean, damn, that would be a bit difficult."
    new "سه دختر جوان... منظورم اینه، خوب، این کمی سخت می‌تونه باشه."

    # say L1057 pla
    old "Hmm... I suppose Billie would help again... and my only friends are Belle and Hinn..."
    new "Hmm... فکر کنم بیلی دوباره کمک کنه... و دوستایم هم فقط بل و هین هستند..."

    # say L1058 pla
    old "What should I say? {i}\"Hey, do you want to be in an orgy at the church?\"{/i} "
    new "باید چی بگم؟ {i}«سلام، می‌خوای توی ارگی در کلیسا شرکت کنی؟»{/i}"

    # say L1059 lin
    old "Well, you should definetly find a way... And I'm also working on the ritual..."
    new "باید حتماً راهی پیدا کنی... و من هم روی مراسم کار می‌کنم."

    # say L1060 lin
    old "Directing the magic power to a specific point isn't as easy as I thought."
    new "جهت‌دهی قدرت جادویی به یک نقطه خاص به اندازه‌ای که فکر می‌کردم آسان نیست."

    # say L1061 lin
    old "I still have to run some more tests."
    new "باید هنوز آزمایش‌های بیشتری انجام بدم."

    # say L1062 lin
    old "So you have time to figure it out."
    new "پس وقتت برای فهمیدنش داری"

    # say L1064 pla
    old "Ok, ok, I'll think about it."
    new "باشه، باشه، فکر می‌کنم."

    # say L1066 lin
    old "Ok, then keep working on the church, I'll contact you as soon as I know exactly what we need."
    new "باشه، بعداً روی کلیسا کار کن، من هم به محض اینکه دقیقاً می‌فهمم چی می‌خوایم، می‌پیوندم."

    # say L1067 pla
    old "Ok, see you later then."
    new "باشه، بعداً می‌بینیم."

    # say L1084 pla
    old "Oh, hi [sis], how are you doing?"
    new "اوه، سلام [sis]، چطوری؟"

    # say L1092 pla
    old "Oh, hi [sis], what are you doing up so late?"
    new "اوه، سلام [sis]، چرا اینقدر شب بیداری؟"

    # say L1094 linSis
    old "I did it [pla]! It worked!"
    new "من انجام دادم [pla]! کار کرد!"

    # say L1095 pla
    old "Huh? What do you mean it worked?"
    new "ه؟ منظورت از این که کار کرد چیه؟"

    # say L1096 pla
    old "Did you sell something expensive online?"
    new "تو چیزی گران‌قیمت رو آنلاین فروختی؟"

    # say L1098 linSis
    old "No, no, no, it's me Linett. Listen, use agamoto's eye."
    new "نه، نه، نه، من لینت هستم. بگوش، از چشم اگامو استفاده کن."

    # say L1100 linSis
    old "Just do it, use the agamoto's eye."
    new "بزن، از چشم آگاموتو استفاده کن."

    # say L1107 pla
    old "Wow! But, what the fuck? You're Linett? But... Why do you look like my [sisrel]?"
    new "واو! ولی چه خبره؟ تو لینت هستی؟ ولی... چرا مثل ز[sisrel]ت من به نظر می‌رسی؟"

    # say L1108 lin
    old "Yeah! Remember that I said I still had to test something? I managed to do again what I did with your friend last time!"
    new "بله! به خاطر داری که گفتم هنوز باید چیزی رو آزمون کنم؟ توانستم دوباره همان کاری رو که با دوستت انجام دادم، انجام بدم!"

    # say L1109 pla
    old "Wait what? What the fuck? You went into my [sisrel]'s body?"
    new "بیا چه کاری؟ تو داخل بدنه‌ی ز[sisrel] من رفتی؟"

    # say L1110 lin
    old "Yes! Yes! I did it. I managed to get insider her!"
    new "بله! بله! انجامش دادم. تونستم داخلش برسم!"

    # say L1111 pla
    old "Woah! That's insane. But wait, come with me for a moment, we can't keep talking here."
    new "وای! این جنون‌آوره. ولی بیا، برای لحظه‌ای با من بیای، نمی‌تونیم اینجا هم بگپ."

    # say L1117 pla
    old "Now, what the fuck are you doing in [sis]'s body?"
    new "حالا، تو در بدنت [sis] چه کاری می‌کنی؟"

    # say L1118 linSis
    old "Well, I figured out that doing this would be necessary for the ritual, so I decided to try to do it again."
    new "خب، فهمیدم که انجام این کار برای مراسم لازم است، پس تصمیم گرفتم دوباره امتحان کنم."

    # say L1119 linSis
    old "To see if I could do it better this time."
    new "برای دیدن اینکه این بار آیا می‌تونم بهتر انجام بدم."

    # say L1120 pla
    old "What do you mean to do it better?"
    new "تو چطور می‌خوایش بهتر انجام بدی؟"

    # say L1121 linSis
    old "Well, we don't usually get involved with humans."
    new "خب، ما معمولاً با انسان‌ها درگیر نمی‌شویم."

    # say L1122 linSis
    old "So, doing something like getting inside a person is a bit weird."
    new "پس، انجام چیزی مثل ورود به داخل فردی یه کم عجیب است."

    # say L1123 linSis
    old "I did it last time because, I was looking trying to survive by taking your friend as my host."
    new "من آخر بار این کار رو انجام دادم چون داشتم سعی می‌کردم با گرفتن دوستت به عنوان میزبان، زنده بمانم."

    # say L1124 linSis
    old "So, I was almost dead that time..."
    new "پس، آن موقع تقریباً مرده بودم..."

    # say L1125 pla
    old "Ok... But why did you do it again?"
    new "خب... ولی چرا دوباره این کار رو انجام دادی؟"

    # say L1127 linSis
    old "Well, I thought that if I did it at will, and at full strength, maybe it would be different."
    new "خب، فکر کردم اگه با همه توانم اینجوری انجام بدم، شاید متفاوت باشه."

    # say L1128 linSis
    old "That I could do it with a lot more control."
    new "اینطور فکر کردم که با کنترل بیشتری می‌تونم انجام بدم."

    # say L1129 linSis
    old "And it worked! See how well I can control her?! There's not even a little bit of interference."
    new "و کار کرد! ببین چقدر می‌تونم اون رو کنترل کنم؟ حتی هیچ اغتشاشی نیست؟"

    # say L1130 pla
    old "Yeah, yeah, congrats. But you have to get out of [sis]‘s body."
    new "بله، بله، مبارک. اما باید از بدنه‌ی [sis] بیرون بیایی."

    # say L1131 pla
    old "And you have to do it now!"
    new "و باید الان هم انجام بدی!"

    # say L1132 linSis
    old "Well, you see... We may have a little of a problem there."
    new "ببین، ممکنه کمی مشکلی پیش بیاد."

    # say L1133 pla
    old "What do you mean a problem?"
    new "چه مشکلی داریم؟"

    # say L1134 linSis
    old "Remember what you did last time to get me out of your friend's body?"
    new "به خاطر داری چه کاری کردی تا از بدنت دوستت بیرون بیام؟"

    # say L1136 pla
    old "Hmm, not really...  Why?"
    new "Hmm، خیلی به یاد نمی‌آورم... چرا؟"

    # say L1137 linSis
    old "The thing is that to be able to get out of your [sisrel] ‘s body I'm going to need a recharge of magical power."
    new "البته، برای اینکه بتوانم از بدنت [sisrel] بیرون بیام، نیاز به شارژ قدرت جادویی دارم."

    # say L1138 linSis
    old "That's the only way to undo my ‘possession'."
    new "این تنها راه برای لغو این ‘تسلط’ است."

    # say L1139 pla
    old "Oh fuck, so I have to have sex with you in [sis] ‘s body?"
    new "اوه شیطون، پس باید با تو در بدنت [sis] جنس کنم؟"

    # say L1140 linSis
    old "Yes, that's right. You got it. Come on, let's do it."
    new "بله، همینه. درست فهمیدی. بیا، بده کارش رو."

    # say L1141 pla
    old "W- wait a minute. What about [sis]? Won't she know about it? Isn't she going to feel anything?"
    new "ب- بیا یه لحظه. اینجوری [sis] چه خبرش؟ آیا او هیچ چیز رو نمی‌فهمد؟ آیا هیچ احساسی نمی‌کند؟"

    # say L1142 linSis
    old "No, she won't feel or remember anything."
    new "نه، هیچ احساسی نخواهد کرد و هیچ چیزی نخواهد یاد آورد."

    # say L1143 pla
    old "How do you know?"
    new "چطور می‌دونی؟"

    # say L1145 linSis
    old "Well, I did it with a different spell, one that grants me total control of this body."
    new "خب، من این کار رو با جادوی دیگری انجام دادم، یکی که به من کنترل کامل این بدن میده."

    # say L1146 linSis
    old "The host is unconscious. And she will be until I leave the body."
    new "میزبان بی‌آگاهی است. و تا زمانی که از بدنش برمی‌آزم، همچنان این حالت خواهد ماند."

    # say L1147 linSis
    old "Besides, this time I'm at full magic power, so I have no trouble controlling her completely."
    new "البته، این بار من قدرت جادوی کاملی دارم، پس هیچ مشکلی برای کنترل کامل او ندارم."

    # say L1148 pla
    old "I still don't get why you had to do this. I mean, what is all of this for?"
    new "هنوز هم متوجه نشدم چرا باید این کار رو انجام بدی. منظورت از همه اینا چیه؟"

    # say L1149 linSis
    old "This is for the ritual I mean, with all the control this method gives to me, I'll have no trouble directing the magic power."
    new "این برای مراسم هست، منظورم اینه که با همه کنترلی که این روش به من میده، هیچ مشکلی برای هدایت توان جادویی ندارم."

    # say L1150 pla
    old "Ohhh... I get it."
    new "اوه... متوجه شدم."

    # say L1151 linSis
    old "Now, give me the magic power I need to get out of this body."
    new "الان، به من قدرت جادویی رو بده که برای خروج از این بدن لازم دارم."

    # say L1165 pla
    old "Are you sure [sis] won't feel it?"
    new "مطمئنی [sis] احساسش نمی‌کنه؟"

    # say L1166 pla
    old "What if she wakes up during it?"
    new "اگه بیدار شه در همین میان چه کنم؟"

    # say L1167 linSis
    old "That's not possible, even after I get out, it's going to take a while before she wakes up."
    new "این امکان نداره، حتی بعد از اینکه برم، یه مدت طول می‌کشه تا بیدار بشه."

    # say L1168 pla
    old "Hmmm, ok."
    new "Hmm، خب."

    # say L1169 linSis
    old "Your cock is impressive, this size and thickness."
    new "پوس تو خوبه، این اندازه و این ضخامت."

    # say L1170 linSis
    old "No wonder you never have trouble supplying me with magic."
    new "البته، هیچ شگفتی نداره که تو هیچ وقت مشکل ارائه جادو به من نداشته باشی."

    # say L1171 pla
    old "We have to do this quick. Someone could hear us."
    new "باید سریع این کار رو انجام بدیم. ممکنه کسی ما رو بشنونه."

    # say L1172 linSis
    old "Oh, relax, remember you have to cum for me to come out of you [sisrel]‘s body."
    new "اوه، آرامش بکن، به خاطر داشتی که باید برای اینکه من از بدنت بیرون بیام، جیز کنی [sisrel]."

    # say L1173 linSis
    old "And you won't if you're not enjoying it."
    new "و تو اگه لذت نبری، منم نمی‌یوم."

    # say L1174 pla
    old "Ok, ok, I'll do it."
    new "باشه، باشه، انجام می‌دم."

    # say L1184 lin
    old "I might do it again just to experience that."
    new "می‌تونم دوباره هم بکنم تا اون تجربه رو بچسبونم."

    # say L1185 pla
    old "Haha, very funny."
    new "هahaha، خیلی مزح داری."

    # say L1186 pla
    old "We should go to my bedroom."
    new "باید به اتاق خواب من برویم."

    # say L1187 pla
    old "But first help me clean her and put her in bed."
    new "اول به من کمک کن تا اون رو تمیز کنم و اون رو به خواب اوندازم."

    # say L1188 pla
    old "She's not gonna wake up if we move her. Right?"
    new "اگر ما اون رو حرکت بدیم، نمی‌تونه بیدار بشه. درسته؟"

    # say L1189 lin
    old "No, she's passed out."
    new "نه، او بی‌وعی شده."

    # say L1190 lin
    old "And won't wake up for a while, so it's ok."
    new "و برای مدتی هم بیدار نمی‌شه، پس خوبه."

    # say L1196 lin
    old "This is perfect, now we can finally do the whole ritual succesfully!"
    new "این کامله، حالا می‌تونیم مراسم رو کاملاً انجام بدیم."

    # say L1197 pla
    old "That's good and all, but that experiment was a little too much."
    new "این خوبه، ولی آزمایش خیلی زیاد بود."

    # say L1198 lin
    old "Well, it worked and that's all that matters."
    new "خب، کار کرد و این همه چیز مهمه."

    # say L1199 lin
    old "What's most important right now is that there's another problem to solve."
    new "اهمیت بیشتر اینه که الان مشکل دیگه‌ای هست که باید حل شه."

    # say L1200 pla
    old "What another one? What else do we need?"
    new "چه چیز دیگری؟ همچنین چه کاری دیگری باید انجام بدیم؟"

    # say L1201 lin
    old "Well, we need the actual people."
    new "خب، ما به افراد واقعی نیاز داریم."

    # say L1202 lin
    old "Remember, I did this experiment because we need to control the magic in humans?"
    new "به خاطر داشتی، من این آزمایش رو انجام دادم چون باید جادو رو در انسان‌ها کنترل کنیم؟"

    # say L1204 pla
    old "Oh, you're right, I forgot."
    new "اوه، درست می‌گی، فراموش کردم."

    # say L1205 lin
    old "The problem is that we need three people, and I can't get inside all three of them."
    new "مشکل اینجاست که ما به سه نفر نیاز داریم و من نمی‌تونم توی هر سه باشم."

    # say L1206 pla
    old "Oh, actually, I hadn't told you, but I know three other shinigamis."
    new "اوه، در واقع من به تو نگفتم، اما سه شینیگامی دیگه می‌شناسم."

    # say L1207 pla
    old "Maybe we could explain the situation to them, and ask for their help."
    new "شاید بتونیم بهشون وضعیت رو توضیح بدیم و از کمکشون بخواهیم."

    # say L1208 lin
    old "Hmm... It could be, but I would need to train them to do it."
    new "Hmm... ممکنه باشه، اما باید آنها رو آموزش بدم تا بتونن این کار رو انجام بدن."

    # say L1209 pla
    old "I think it will be fine if we talk to them."
    new "فکر می‌کنم اگه باهاشون حرف بزنیم خوبه."

    # say L1210 lin
    old "Ok, so let's go, where are they?"
    new "باشه، برویم، اونا کجایی؟"

    # say L1212 pla
    old "Woah, you wanna go now?"
    new "وای، می‌خوای حالا برویم؟"

    # say L1213 pla
    old "Listen, it's pretty late and I haven't slept at all."
    new "بله، الان وقتش خیلی دیره و من هنوز خواب نگرفتم."

    # say L1214 pla
    old "What about if we go tomorrow morning?"
    new "پس فردا صبح برویم؟"

    # say L1216 lin
    old "Hmm, ok, I'll come here tomorrow morning then."
    new "Hmm، خوب، فردا صبح می‌آیم."

    # say L1217 pla
    old "Ok, see you tomorrow."
    new "باشه، ببینمت فردا."

    # say L1233 lin
    old "Hey, are you ready to go talk with the other shinigamies?"
    new "ای، آماده‌ای برای رفتن و صحبت کردن با شینیگامی‌های دیگه؟"

    # say L1234 pla
    old "What? Now? I just woke up!"
    new "چه کاری؟ حالا؟ هیچ وقت بیدار نشدم!"

    # say L1235 lin
    old "What!? Remember I have to teach them how to do the spell. It's not as simple as when you use magic."
    new "چه!؟ به خاطر داشتی که باید به آنها یاد بدهم جادو رو انجام بدند. این مثل وقتی تو جادو می‌کنی ساده نیست."

    # say L1236 lin
    old "It takes time to learn a spell, and we don't even know if they're going to say yes."
    new "یادگیری یک جادو زمان می‌بره، و حتی نمی‌دونیم آنها بپذیرن یا نه."

    # say L1237 lin
    old "So we have to go now!"
    new "پس باید حالا برویم!"

    # say L1238 pla
    old "Ok, ok, I get it."
    new "باشه، باشه، متوجه شدم."

    # say L1239 pla
    old "Let's go then."
    new "بیایم برویم"

    # say L1262 pla
    old "Hey girls."
    new "سلام دخترها."

    # say L1263 mil
    old "Hello."
    new "سلام."

    # say L1264 dev
    old "Oh! [pla] is here! Hiiii, it's been a while since I've seen you!"
    new "اوه! [pla] اینجا هست! هییی، از دیدنت طول کشیده!"

    # say L1265 gom
    old "Hello, how have you been?"
    new "سلام، چطوری؟"

    # say L1266 pla
    old "Fine, fine, thank you."
    new "خوب، ممنون."

    # say L1267 pla
    old "Hey, remember that a while ago, I told you about a shinigami that was inside one of my friends?"
    new "بله، به خاطر داری که یه وقتی پیش به تو گفتم در مورد یه شینیگامی که داخل یه دوستم بود؟"

    # say L1268 pla
    old "And I asked you for advice about what to do?"
    new "و ازت پرسیدم که باید چی کنم؟"

    # say L1270 mil
    old "Indeed, we remember, what about it?"
    new "بله، به خاطر دارم، در مورد چی می‌خوای بگی؟"

    # say L1271 pla
    old "Well, I wanted to introduce her to you, so I brought her with me."
    new "خب، می‌خواستم تو رو با او آشنا کنم، پس همراه من آوردمش."

    # say L1280 pla
    old "Everyone, this is Linett."
    new "همه، این لینت هست."

    # say L1281 lin
    old "Hello, nice meeting you."
    new "سلام، خوشحالم که با تو آشنا شدم."

    # say L1284 gom
    old "Umm... eh, hi."
    new "اوه... اه، سلام."

    # say L1285 lin
    old "I understand your surprise, I didn't expect to see other shinigamis in this town."
    new "من متوجه شوکت هستم، من هم انتظار نداشتم در این شهر شینیگامی دیگری ببینم."

    # say L1286 lin
    old "But I have to talk to you about something important."
    new "اما باید با تو در مورد چیزی مهم صحبت کنم."

    # say L1287 pla
    old "I think you should listen to her, it's about the magic power."
    new "فکر می‌کنم باید بهش گوش بدی، در مورد قدرت جادویی هست."

    # say L1290 mil
    old "The magic power? What about it?"
    new "توی قدرت جادویی چه خبری؟"

    # say L1291 dev
    old "I don't know about you. But if [pla] says it's ok, I'll listen."
    new "من نمی‌دونم تو چطوری. اما اگه [pla] می‌گه خوبه، من می‌شنوم."

    # say L1292 gom
    old "Hmm, this could be important."
    new "ممکنه مهم باشه."

    # say L1293 lin
    old "Some time ago I discovered that in this town's church used to be a place with a strong connection with the magic world."
    new "چند وقت پیش کشف کردم که در این شهر کلیسا مکانی بود که به دنیای جادویی ارتباط قوی داشت."

    # say L1294 mil
    old "So? What does it matter now that the magic world doesn't exist?"
    new "پس؟ الان که جهان جادویی وجود نداره، این چه کار داره؟"

    # say L1295 lin
    old "Well... That connection remains even if the magic world is gone."
    new "خب... این ارتباط همچنان وجود دارد حتی اگر جهان جادویی نباشد."

    # say L1296 dev
    old "Oh! Really?"
    new "اوه! واقعاً؟"

    # say L1297 gom
    old "And what does it mean?"
    new "و این چه معنی داره؟"

    # say L1298 lin
    old "It means that is a perfect place to set a magic power generating point."
    new "این به این معناست که جای مناسبی برای قرار دادن نقطه تولید انرژی جادویی است."

    # say L1299 gom
    old "Wow, really? That's amazing."
    new "واو، واقعاً؟ این خیلی عالیه."

    # say L1302 lin
    old "That's right, and me, along with [pla], did a ritual to trying to create that magic point."
    new "درست می‌فرمایید، من همراه با [pla] مراسمی برگزار کردیم تا آن نقطه جادویی را ایجاد کنیم."

    # say L1303 lin
    old "But it went wrong. However, I believe I've solved the issue and I would like to try again."
    new "ولی اشتباه شد. ولی من فکر می‌کنم مشکل رو حل کردم و می‌خوام دوباره امتحان کنم."

    # say L1305 pla
    old "Actually, that's why we came here today. We need your help with the ritual."
    new "در واقع، همین به خاطر این هست که امروز اینجا آمده‌ایم. به ما در مراسم کمک کن."

    # say L1306 mil
    old "Our help? We don't even know you... or your intentions..."
    new "کمکمون؟ ما حتی تو رو نمی‌شناسیم... یا نیت‌اتو..."

    # say L1307 gom
    old "She's right, this is the first time any of us has heard anything like this."
    new "درسته، این برای همه ما اولین باره."

    # say L1308 lin
    old "I know it sounds strange, this is actually new for me too."
    new "میدونم عجیب به نظر می‌رسه، این برای من هم جدیده."

    # say L1309 lin
    old "But we need to try it because the magic power is running out."
    new "اما ما باید اینو امتحان کنیم چون توانایی جادویی در حال کاهش هست."

    # say L1310 lin
    old "And if we don't do anything we're just going to die. I gain nothing by lying to you."
    new "و اگر هیچ کاری نکنیم فقط می‌میریم. از جمله‌ای دروغ نمی‌کنم."

    # say L1312 dev
    old "Ok and what do you propose we do?"
    new "باشه و تو پیشنهادت چیه؟"

    # say L1313 lin
    old "For starters, we're going to need three young humans. [pla] will handle that."
    new "ابتدا، ما به سه انسان جوان نیاز داریم. [pla] این کار را انجام می‌دهد."

    # say L1314 lin
    old "The idea is that we use them in a ritual in which we will create a breach point, and pour magic into it to force it to open."
    new "ایده اینه که ازشون توی یه مراسم استفاده کنیم که در اون یه نقطه شکاف ایجاد کنیم و سپس جادو رو توون بریزیم تا با زور باز بشه."

    # say L1316 gom
    old "I see, I get the idea."
    new "فهمیدم، ایده رو درک کردم."

    # say L1317 gom
    old "But I see some difficulties with the plan."
    new "اما مشکلاتی با این برنامه می‌بینم."

    # say L1319 mil
    old "For starters, humans can't control magic. And even if they could, how would we make them do that?"
    new "اول اینکه، انسان‌ها جادو رو نمی‌تونن کنترل کنن. و حتی اگه بتونن، چطور می‌تونیم اونا رو به این کار بیاندازیم؟"

    # say L1321 lin
    old "Well, the idea is that we're going to get inside them, and control the magic from within."
    new "خب، ایده اینه که ما داخلشون بیاییم و از داخل جادو رو کنترل کنیم."

    # say L1325 dev
    old "What? We're going to be trapped!"
    new "چه کاری؟ ما داخلشون خواهیم افتاد!"

    # say L1326 mil
    old "That's right, it's pretty weird to think doing that on purpose, is really dangerous."
    new "بله، فکر کردن این کار رو قصدی انجام بدیم خیلی عجیب و واقعاً خطرناکه."

    # say L1327 mil
    old "Isn't this just a trap to imprison us in human bodies?"
    new "این فقط یک فخ برای اسارت ما در بدنه‌های انسانی نیست؟"

    # say L1328 lin
    old "What!? What would I get from that?"
    new "چه کاری! از این کار چه سودی برایم هست؟"

    # say L1329 pla
    old "A- actually, we discovered that there is a way to do it safely."
    new "اصلًا، ما کشف کردیم که راهی هست که این کار رو به امنیت انجام بدیم."

    # say L1330 lin
    old "Exactly, I've been running some tests, and found a way in which it can be done."
    new "دقیقاً، من چند آزمایش انجام دادم و راهی پیدا کردم که بتوانیم این کار را انجام بدیم."

    # say L1331 lin
    old "I've created a spell with which we can get inside a human body and control it at will."
    new "من یک تکنیک جادویی ایجاد کردم که با آن می‌تونیم داخل بدن انسان وارد شیم و آن رو به سرور خود کنترل کنیم."

    # say L1332 lin
    old "And we can do it without being on the verge of death."
    new "و می‌تونیم این کار رو بدون اینکه به مرگ نزدیک باشیم انجام بدیم."

    # say L1333 gom
    old "I had never heard of something like that, are you sure about what you're saying?"
    new "هیچ وقت از چیزی مثل این شنیده بودم، مطمئنی از آنچه می‌گویی؟"

    # say L1334 pla
    old "She's telling the truth, I helped her."
    new "او حق باهاش داره، من بهش کمک کردم."

    # say L1335 lin
    old "If you'll let me show, I can teach you how to do it."
    new "اگر برات نشون بدم، می‌تونم یادت بدم چطور انجام بشه."

    # say L1337 mil
    old "I can't believe you're actually considering listening to this!"
    new "باورم نمی‌شه که واقعاً به این گوش می‌دهی!"

    # say L1339 gom
    old "Ok, we'll hear what you have to say, but if you don't convince us, we won't follow you."
    new "باشه، می‌شنوم چه می‌گی‌ی، اما اگر ما رو قانع نکنی، پیشات نمی‌رویم."

    # say L1340 lin
    old "Ok, I know after listening you will understand."
    new "باشه، میدونم بعد از شنیدن حرف‌هامون فهمی."

    # say L1341 lin
    old "But wait, before I start. Don't have to keep working in the church? Let me this to me and you keep working on the church."
    new "ولی بیا، قبل از شروع. نباید همچنان در کلیسا کار کنیم؟ برام اینو بده و شما همچنان روی کلیسا کار کنید."

    # say L1342 lin
    old "We are running out of time and need that place ready for the ritual."
    new "زمان ما کم شده و باید اون جا برای مراسم آماده باشه."

    # say L1344 pla
    old "Oh right."
    new "اوه درست است."

    # say L1345 pla
    old "Ok, ok I'll keep working on the church, while you explain everything to them. See you later guys."
    new "باشه، باشه من کار کلیسا رو ادامه میدم، تو هم همه چی رو بهشون توضیح بده. ببینم شما رو بعد."

    # say L1347 lin
    old "Great, we'll talk later at home."
    new "عالی، بعداً در خونه صحبت می‌کنیم."

    # say L1348 dev
    old "See you [pla]!"
    new "ببینم تو [pla]!"

    # say L1364 lin
    old "Hey there [pla]!"
    new "سلام [pla]!"

    # say L1365 pla
    old "Oh, hey, did you manage to convince them?"
    new "اوه، هی، تونستی بهشون قانع کنی؟"

    # say L1366 lin
    old "Yeah, I did, they didn't believe me at first."
    new "آره، موفق شدم، اول باورشون نبود."

    # say L1367 lin
    old "Especially that Mildret one. She was a lot of trouble."
    new "به ویژه آن میلدرت. او خیلی سردرگم کننده بود."

    # say L1368 lin
    old "But once I showed them the spell they understood."
    new "اما وقتی به آنها جادو را نشان دادم، متوجه شدند."

    # say L1370 pla
    old "You showed them? But how did you get out of the host?"
    new "تو بهشون نشون دادی؟ اما چطور از میزبان خارج شدی؟"

    # say L1372 lin
    old "I didn't perform it. I only told them how it was done."
    new "من اجرا نکردم. فقط بهشون گفتم چطور انجام می‌شه."

    # say L1373 lin
    old "All shinigami know and understand magic, so they knew I was telling them the truth."
    new "همه شینیگامی‌ها سحر رو می‌شناسن و می‌فهمن، پس بدونیدن که من بهشون حقیقت رو می‌گم."

    # say L1375 pla
    old "Oh, I see, nice."
    new "اوه، من متوجه شدم، خوبه."

    # say L1376 pla
    old "Everything's fine now, right? I mean, now you all know the spell."
    new "حالا همه چی خوبه، درسته؟ منظورم اینه که حالا همه شما جادو رو بلدید."

    # say L1377 pla
    old "And I'm taking care of the church, so we're almost ready."
    new "و من هم کلیسا رو می‌نویسم، پس تقریباً آماده‌ایم."

    # say L1378 lin
    old "Hmm, not really. It sounds ok, but it's a very complicated spell. And I merely explained it to them...."
    new "Hmm، نه واقعاً. به نظر خوب می‌رسه، اما این جادو بسیار پیچیده است. و من فقط به آنها توضیح دادم..."

    # say L1379 lin
    old "If we want to make sure that everything goes perfect the day of the ritual, they're going to need practice."
    new "اگر می‌خواهیم مطمئن شویم همه چیز در روز مراسم به درستی انجام بشه، باید تمرین کنند."

    # say L1381 pla
    old "Ok, so, what do you need me to do now?"
    new "باشه، پس حالا من چی کنم باید؟"

    # say L1382 lin
    old "For now it would be really good if you can decide on the three humans we're using for the ritual."
    new "الان خوب باشه اگه بتونی سه انسانی رو که برای مراسم می‌خوایم انتخاب کنی."

    # say L1383 lin
    old "You said you had some people in mind."
    new "تو خودت گفتی که چند نفر رو در نظر داری."

    # say L1385 pla
    old "Y- yeah I did. But I- I don't know..."
    new "ب- بله من همین‌طور فکر می‌کردم. اما من- من نمی‌دونم..."

    # say L1387 lin
    old "I already told you there's no need to worry."
    new "من قبلاً به تو گفتم نگران نباشی."

    # say L1388 lin
    old "Remember, they'll be unconscious during the ritual and after."
    new "به خاطر داشت، طی مراسم و بعدشون بی‌آگاه خواهند بود."

    # say L1389 lin
    old "And all the time we'll be controlling them."
    new "و تمام اون موقع ما کنترلشون رو خواهیم داشت."

    # say L1390 lin
    old "So, you shouldn't be this worried."
    new "پس، نباید اینقدر نگران باشی."

    # say L1391 pla
    old "Hmm ok, if that's how it is. Then, I guess I know who could work..."
    new "Hmm خب، اگه همینجوریه. بعد، فکر کنم می‌دونم چه کسی می‌تونه کار کنه..."

    # say L1392 lin
    old "Great, then tomorrow morning we'll go see the shinigamis again and would be perfect to test the spell with one of them."
    new "عالی، پس فردا صبح دوباره به شینیگامی‌ها می‌رویم و خوبه که با یکی از آنها جایگزینی را آزمایش کنیم."

    # say L1393 lin
    old "So that they can practice before the ritual."
    new "پس می‌تونن قبل از مراسم تمرین کنن."

    # say L1394 pla
    old "You mean with a human?"
    new "من قصد دارم با انسان آزمایش کنم؟"

    # say L1396 lin
    old "Yes [pla], we have to test the spell before the ritual with the girls."
    new "بله [pla]، ما باید قبل از مراسم جادویی با دختران آزمایش کنیم."

    # say L1397 lin
    old "We need to be sure everything is going to work."
    new "باید مطمئن شیم همه چیز درست کار می‌کنه."

    # say L1398 pla
    old "Hmm... I guess you are right..."
    new "Hmm... به نظر می‌رسه درست می‌گی‌ی..."

    # say L1399 lin
    old "All right, everything is done, you better go to sleep because we have a lot to do tomorrow."
    new "باشه، همه چیز تموم شده، بهتره که بخوابی چون فردا کار زیادی داریم."

    # say L1400 pla
    old "Ok, I'll see you tomorrow."
    new "باشه، فردا می‌بینم تو."

    # say L1417 lin
    old "Hey [pla], are you ready to go?"
    new "اوه ز[pla]، آماده‌ای برای رفتن؟"

    # say L1418 pla
    old "Oh, good morning, yeah sure, let's go."
    new "اوه، صبح بخیر، بله حتماً، برویم."

    # say L1433 pla
    old "Hey girls, good morning."
    new "سلام دختران، صبح بخیر"

    # say L1434 mil
    old "Hello again."
    new "سلام دوباره."

    # say L1435 gom
    old "Hi, how are you today?"
    new "سلام، امروز چطوری؟"

    # say L1436 dev
    old "Hiii, good seeing you again."
    new "هی، خوشحالم که دوباره دیدنت."

    # say L1437 lin
    old "Listen, [pla] and I talked last night about the humans that are taking part in the ritual."
    new "بلا، من و [pla] دیروز در مورد انسان‌هایی که در مراسم شرکت می‌کنند صحبت کردیم."

    # say L1438 lin
    old "And he's told me that he already has three people in mind for it."
    new "و او به من گفته که قراره سه نفر رو برای این کار انتخاب کنه."

    # say L1439 lin
    old "So we'll go and find them for you to practice the spell before the ritual."
    new "پس ما برایت می‌رویم و آنها رو پیدا می‌کنیم تا قبل از مراسم جادوی رو تمرین کنی."

    # say L1440 lin
    old "Just to make sure that you can handle the spell and control the host body."
    new "برای اینکه مطمئن شویم می‌تونی جادو رو کنترل کنی و بدنه میزبان رو هم در دست بگیری."

    # say L1442 dev
    old "What? Now?... B- but I'm not ready... What if I can't get out?"
    new "چه؟ حالا؟... اما من آماده نیستم... اگر نتوانم بیرون بیام چه می‌شه؟"

    # say L1443 lin
    old "Don't worry Devonne, We may practice more with you."
    new "نگران نباش دیون، می‌تونیم بیشتر با تو تمرین کنیم."

    # say L1444 lin
    old "Actually, I was thinking of starting with Gomory, I think she is ready."
    new "در واقع، من فکر می‌کنم با گوموری شروع کنیم، فکر می‌کنم آماده است."

    # say L1445 mil
    old "Ok, it sounds fine."
    new "باشه، خوب به نظر می‌رسه."

    # say L1446 gom
    old "Yeah, it would be good to try it now."
    new "بله، الان امتحانش کردن خوب می‌شه."

    # say L1448 lin
    old "So you and her go find her host, while I keep working with Mildret and Devonne."
    new "تو و او بروید میزبانش رو پیدا کنید، من هم با میلدرت و دیون وکار می‌کنم."

    # say L1449 pla
    old "Ok, so what's the idea? What should we do?"
    new "باشه، پس ایده چیه؟ باید چی کنیم؟"

    # say L1450 lin
    old "You just have to take her to where her host is."
    new "تو فقط باید اونجا بره که میزبانش هست."

    # say L1451 lin
    old "And see that everything goes well while she performs the spell."
    new "و ببین که همه چیز خوب پیش برود در حال انجام جادو."

    # say L1452 lin
    old "As long as you're with her there shouldn't be a problem."
    new "با تو همراهش نباید مشکلی پیش بیاد."

    # say L1453 pla
    old "Hmph, I see..."
    new "همف، متوجه شدم..."

    # say L1454 pla
    old "Ok, I get it. Then let's go to where she is. Come with me Gomory."
    new "باشه، فهمیدم. پس برویم جایی که هست. با من بیا، گوموری."

    # say L1463 gom
    old "Who is going to be my host?"
    new "چه کسی می‌تونه میزبان من باشه؟"

    # say L1464 pla
    old "She's a friend of mine, her name is Belle, I think we should try with her first."
    new "او دوست منه، اسمش بله، فکر کنم باید اول با او امتحان کنیم."

    # say L1478 pla
    old "Ok, we found her. What do you need to get in her body?"
    new "باشه، پیدا کردیم. برای ورود به بدنش چه کاری باید بکنیم؟"

    # say L1479 gom
    old "Not much really, all we need is for her to be relaxed for a moment, and I'll canalize the spell."
    new "خیلی چیزی نیست، فقط باید یه لحظه آرام باشه و من جادو رو هدایت می‌کنم."

    # say L1480 pla
    old "Hmm, ok, so it should be fine if we're just talking, right?"
    new "Hmm، خوب، پس اگه فقط حرف بزنیم هم باید مشکلی نداشته باشه، درسته؟"

    # say L1481 gom
    old "That's right, it doesn't take more than a few seconds."
    new "درسته، فقط چند ثانیه طول می‌کشه."

    # say L1482 pla
    old "Ok, I think I got it. I'll go there and talk to her for a moment, you wait here for a minute."
    new "باشه، فکر کنم گرفتم. من می‌رم اونجا و یه لحظه باهاش حرف می‌زنم، تو یه دقیقه اینجا صبر کن."

    # say L1483 pla
    old "Then you come close. And the person that you see me talking to it's who you do the spell on, ok?"
    new "بعد بیا نزدیک. و اون شخصی که می‌بینی من باهاش حرف می‌زنم، همونیه که باید جادو رو برایش بکنی، خوب؟"

    # say L1485 gom
    old "That's very simple, sounds good, let's do it."
    new "این خیلی ساده است، خوبه، بیایید انجام بدیم."

    # say L1486 pla
    old "Ok, I'll there then."
    new "باشه، من اونجا می‌مونم."

    # say L1502 bel
    old "Oh! [pla] Hi!"
    new "اوه! [pla] سلام!"

    # say L1504 pla
    old "I'm ok. Hey listen, I wanted to talk to you about something Miss Mia said in class."
    new "من خوبم. اسمع، می‌خواستم با تو در مورد چیزی که میس میا تو کلاس گفت صحبت کنم."

    # say L1505 bel
    old "Sure, tell me. What is it?"
    new "بله، بگو. چه کاریه؟"

    # say L1515 rub
    old "HA! Who do we have here? Piglet and the loser."
    new "ها! اینجا کی هست؟ خوکچه و لوسر."

    # say L1516 rub
    old "What happened to your ears Piglet? Afraid they were talking too much attention from that flat nose?"
    new "چه اتفاقی به گوشات افتاده، خوک‌کوچولو؟ می‌تونستی از همین جاش بی‌صدا مونی بودی؟"

    # say L1517 bel
    old "Oh for God's sake!"
    new "اوه خدای من!"

    # say L1518 bel
    old "Listen, dumbass, I'm not in the mood for your shit today! So fuck off!"
    new "بله، احمق، امروز خودت رو برای این جوری گپ‌هایت آماده نیستم! پس بره بگرد!"

    # say L1524 rub
    old "And what crawled up her that she's this angry?"
    new "و چه چیزی توی اون رفته که اینقدر خشمگین شده؟"

    # say L1526 rub
    old "Honestly, you can't say anything to people because they get their panties in a bunch."
    new "صراحیت بگم، نمی‌تونی هیچی به این مردم بگی چون همه خودشون رو تحریک می‌کنن."

    # say L1527 pla
    old "What are you talking about? You just insulted her!"
    new "تو در مورد چی حرف می‌زنی؟ تو فقط به اون توهین کردی!"

    # say L1528 pla
    old "Don't you ever get tired of talking like that to people?"
    new "می‌تونی هیچ وقت خسته نشی از این که به افراد همین طور حرف بزنی؟"

    # say L1529 rub
    old "What, who do you think you're talking to?"
    new "ببین، فکر می‌کنی به چه کسی حرف می‌زنی؟"

    # say L1530 rub
    old "Listen loser, I don't care what you have to say, so why don't you get lost?"
    new "بله، بی‌اهمیت، من نمی‌خوام گفتگو داشته باشم، برو بره!"

    # say L1531 pla
    old "Yeah, whatever, who would want to deal with you?"
    new "بله، هر کی، چه کسی می‌خواست با تو سروکار داشته باشه؟"

    # say L1538 pla
    old "Oh no!"
    new "اوه نه!"

    # say L1539 rub
    old "Yeah! You shouldn't have messed with me you little brat!"
    new "بله! نباید با من بازی کردی، تو خرک کوچیک!"

    # say L1540 pla
    old "Wait! Wait! Stop!"
    new "انتظار! انتظار! متوقف شو!"

    # say L1541 rub
    old "Stop? After you insulted me? You better be ready for what you have coming your way!"
    new "توقف؟ بعد از اینکه من رو توهین کردی؟ بهتره آماده باشی برای اون چیزی که به تو می‌آیه!"

    # say L1542 pla
    old "No, no, no, no, it's not her, it's not her."
    new "نه، نه، نه، نه، این نه او، این نه او."

    # say L1543 rub
    old "W- What??"
    new "و- وای؟؟"

    # say L1550 pla
    old "Ooh shit!"
    new "اوه شیطان!"

    # say L1551 pla
    old "Damn, what do I do now? This wasn't supposed to happen!"
    new "لعنتی، حالا چی کار کنم؟ این قرار نبود!"

    # say L1553 gomRub
    old "Hey, I did it! It worked! Linett is a genius!"
    new "اوه، انجامش دادم! کار کرد! لینت خلاقه!"

    # say L1554 pla
    old "Devonne? Is that you?"
    new "دوان؟ این تو هستی؟"

    # say L1555 gomRub
    old "It is! It worked! We did it [pla]!"
    new "بله! عمل کرد! ما انجام دادیم [pla]!"

    # say L1556 pla
    old "No, we didn't! You got the wrong person!"
    new "نه، انجام ندادیم! اشتباه کردی، شخص دیگه‌ای رو گرفتی!"

    # say L1557 pla
    old "It was supposed to be the other girl I was talking with!"
    new "باید دیگه دختری که باهاش صحبت می‌کردم بود!"

    # say L1558 gomRub
    old "Well, you should have said something, I did what you told me to."
    new "خب، باید چیزی می‌گفتی، من انجام دادم آنچه به من گفتی."

    # say L1559 gomRub
    old "I waited for a minute and get into the person I saw you talking with."
    new "من یک دقیقه منتظر موندم و به آدمی که دیدم تو باهاش صحبت می‌کردی وارد شدم."

    # say L1561 pla
    old "Well, the point is you're in the wrong body. You're gonna have to get out of there."
    new "خب، مهم اینه که تو در بدنتی هستی که نباید تو باشی. باید از اونجا بیرون بیایی."

    # say L1562 gomRub
    old "Ok, but you know what's the only possible one way."
    new "خب، اما می‌دونی راه یکتای ممکن چیه."

    # say L1563 pla
    old "Ohhh right... Oh my God... I have to do it with Ruby... Fuck!"
    new "اوه درسته... اوه خدا... باید با رووبی این کار رو بکنم... شیطون!"

    # say L1564 gomRub
    old "Well, it could be just a blowjob... it works too..."
    new "خب، می‌تونه فقط یه زدن بازی باشه... این هم کار می‌کنه..."

    # say L1565 pla
    old "I know, I know. Look, we can't do that here. So let's go somewhere else before anyone notices us speaking."
    new "می‌دونم، می‌دونم. ببین، نمی‌تونیم اینجا این کار رو بکنیم. بیای برهیم جای دیگه قبل از این که کسی ما رو متوجه بشه."

    # say L1574 oli
    old "Hey Ruby, so here this is where you've been. Hey listen, I've been thinking about our..."
    new "هی رابی، پس اینجا بودی. بگو، من در مورد ما فکر کردم..."

    # say L1576 oli
    old "And what do we have here? If it is the captain of the nerd club."
    new "و اینجا چه داریم؟ اگه کاپیتان باشگاه نردها هست."

    # say L1577 oli
    old "What are you doing here nerd? Looking for better company than your loser friends"
    new "تو اینجا چی کار داری نرد؟ دنبال دوستان بهتری از دوستانتون هستی؟"

    # say L1579 pla
    old "Yeah, sure... That's right, I'm trying to become friends with Ruby. Right, Ruby?"
    new "بله، حتماً... درسته، من سعی می‌کنم با روبی دوست شوم. درسته، روبی؟"

    # say L1586 gomRub
    old "Ohh... Yeah, that's right, he and I are very good friends heh."
    new "اوه... بله، همینه، ما خیلی دوست داریم همراه هم باشیم هه."

    # say L1587 pla
    old "(Oh my God...)"
    new "اوه خداوند..."

    # say L1588 oli
    old "W- what? What are you saying ruby?"
    new "W- چه؟ چه حرفی رو می‌زنی روبی؟"

    # say L1589 oli
    old "Do you feel ok? Did this nerd do anything to you?"
    new "حالت خوبه؟ این دسته‌ی نرم‌افزار چی کاری به تو کرده؟"

    # say L1590 pla
    old "Hey, I haven't done anything."
    new "من هیچ کاری نکردم."

    # say L1591 pla
    old "We're just talking about homework... S- she wants me to do her homework..."
    new "ما فقط در مورد تکلیف صحبت می‌کنیم... س- او می‌خواهد من تکلیف‌اش رو بکنم..."

    # say L1592 oli
    old "Is that true Ruby?"
    new "این درسته رووبی؟"

    # say L1594 gomRub
    old "Uhh, yes, yes! It's true, he's helping me with... Something."
    new "آره، آره! درسته، او به من در... چیزی کمک می‌کنه."

    # say L1595 pla
    old "Anyway, I think we need to go look for some books. You know, for that homework... We better leave."
    new "به هر حال، فکر کنم باید بریم جستجوی کتاب‌ها کنیم. می‌دونی، برای اون تکلیف... بهتره برهیم."

    # say L1596 gomRub
    old "Yeah! I think we need to leave."
    new "بله! فکر کنم باید بریم."

    # say L1601 gomRub
    old "Goodbye human friend! It was good to talk to you, I'll see you later."
    new "خداحافظ دوست من! خوشحالم که با تو صحبت کردم، بعداً می‌بینیم."

    # say L1622 pla
    old "Ok, I think we'll be safe here. It's almost class time, nobody's going to come."
    new "باشه، فکر کنم اینجا امن هستیم. تقریباً وقت کلاس شده، هیچ‌کس نمی‌آید."

    # say L1623 gomRub
    old "It's incredible, I have soo much control, I didn't know this was possible."
    new "البته، این شگفت‌انگیزه، من هیچ وقت نمی‌دونستم اینقدر کنترل دارم."

    # say L1624 pla
    old "So, you're feeling ok?"
    new "پس، حس خوبی داری؟"

    # say L1625 gomRub
    old "That's right! I feel in complete control, it's almost as if this was my real body."
    new "درست است! من احساس کامل کنترل می‌کنم، مثل اینه که این بدن واقعی من باشه."

    # say L1626 pla
    old "Ok, that's good. At least you didn't start twitching in the middle of the hallway, that would have given us up."
    new "خب، این خوبه. حداقل تو در میان راه نشروع به لرزیدن نکردی، این به ما خیلی کمک کرد."

    # say L1627 pla
    old "Which, by the way, you almost did when Olivia got there. Thank God she's not very smart."
    new "باز هم، وقتی اولیویا رسید تقریباً اینجوری شدی. خوشحالم که او خیلی هوشیار نیست."

    # say L1628 gomRub
    old "Oh yes, who was that girl? She was friendly!"
    new "اوه بله، آن دختر کی بود؟ خوشحال شدم که باهاش آشنا شدم!"

    # say L1629 pla
    old "Hmm, that's the last thing I would call her. She's the best friend of Ruby, the... Uhhh, owner of this body."
    new "هم، این آخرین چیزیه که من به او بگم. او بهترین دوست روییه، همچون... اوه، صاحب این بدن."

    # say L1631 gomRub
    old "So that could have been a lot closer..."
    new "پس این می‌تونست خیلی نزدیک‌تر باشه..."

    # say L1632 pla
    old "Well, this is the problem with using the wrong body."
    new "خب، این همین مشکل استفاده از بدنه‌ای غلطه."

    # say L1633 pla
    old "But anyway, can you leave that body before someone else notices how weird you're acting?"
    new "اما باید قبل از اینکه دیگران متوجه عجیب بودنت بشن، از اون بدنه بیرون بیادی."

    # say L1635 gomRub
    old "I want to get out, but I'm going to need your help."
    new "می‌خوام برم، ولی به کمکت نیاز دارم."

    # say L1637 pla
    old "Yeah, right, I remember..."
    new "بله، درسته، من هم به یاد دارم..."

    # say L1638 pla
    old "We need to do this quick."
    new "باید این رو سریع انجام بدیم."

    # say L1647 gomRub
    old "Ok, I've been waiting for this since I took over this body"
    new "باشه، از زمانی که این بدنه رو به دست گرفتم منتظر این بودم."

    # say L1649 gomRub
    old "Well, I knew we had to do this for me to leave my host's body."
    new "خب، می‌دونستم باید اینو بکنیم تا بتوانم از بدنه میزبانم بیرون بیام."

    # say L1650 gomRub
    old "And I've been wanting to taste this cock for a while."
    new "و من هم از دیرباز می‌خواستم این ناخن رو بخورم."

    # say L1651 pla
    old "Uh... yeah, sure, remember we can't take much time."
    new "آره، بله، به خاطر داشتیم که وقت زیادی نداریم."

    # say L1652 gomRub
    old "I know, I know, this will be quick."
    new "می‌دونم، می‌دونم، این خیلی طول نمی‌کشه."

    # say L1662 pla
    old "Are you ok? Did everything work?"
    new "حالت خوبه؟ همه چیز درست کار کرد؟"

    # say L1663 gom
    old "Oh yeah, I'm perfect, and she didn't feel anything."
    new "آره، من کاملم، و او هیچ چیز نحسه نکرد."

    # say L1664 pla
    old "Oh shit! That's right, if we don't clean her up, she's gonna wake up and realize what happened."
    new "اوه شیطون! درسته، اگه ما او رو تمیز نکنیم، او بیدار می‌شه و متوجه می‌شه چه چیزی اتفاق افتاده."

    # say L1665 pla
    old "Come, help me clean her up, bring her to the toilet and get out of here."
    new "بیا، کمک کن تا اونجا رو تمیز کنم، او رو به توالت ببریم و از اینجا برویم."

    # say L1677 pla
    old "Ok, now let's go. We have to tell the others about how this went."
    new "باشه، حالا برویم. باید با دیگران در مورد اینجوری بگپیم."

    # say L1695 rub
    old "Ugh, what happened?"
    new "اوه، چه کاری افتاد؟"

    # say L1696 rub
    old "I can't remember anything. Why am I in the school bathroom?"
    new "هیچ چیز رو به یاد نمی‌آورم. چرا من توی حمام مدرسه هستم؟"

    # say L1697 rub
    old "Ugh, did I fall asleep in the toilet?"
    new "اوه، آیا در توالت خوابیدم؟"

    # say L1698 rub
    old "And what is this taste in my mouth?"
    new "و این طعم توی دهانم چیه؟"

    # say L1699 rub
    old "It's like a salty smoothie. Ughh, disgusting."
    new "مثل یک شیرینی نمکی. اوه، خیلی خیزناک."

    # say L1700 rub
    old "And what is that smell? It smells like... dick?"
    new "و این بو چیه؟ مثل... ناخنگ می‌تونه باشه؟"

    # say L1701 rub
    old "I bet some loser was jerking off in the women's bathroom!"
    new "حتماً یک خاسه در آن سرویس به زنان جا خورده بود!"

    # say L1702 rub
    old "Pathetic, I bet it was one of those losers that hangs out with Piglet."
    new "بی‌اهمیت، حتماً یکی از آن خاسه‌هایی بود که با پیگلت همراه می‌شوند."

    # say L1703 rub
    old "I'll give them a piece of my mind next time I see them."
    new "بعداً وقتی اونا رو ببینم، باهاشون حساب خواهم کشید."

    # say L1737 lin
    old "Hey guys, how did it go?"
    new "دستا، چطور بود؟"

    # say L1738 pla
    old "Terrible! Gomory got in the wrong body, so we don't know if it's going to work with Belle."
    new "حالت بد! گوموری تو جسم اشتباه وارد شد، پس نمی‌دونیم این کار با بل خوب می‌شه یا نه."

    # say L1739 lin
    old "What? What happened?"
    new "چه اتفاقی افتاد؟"

    # say L1740 gom
    old "There was a confusion when I was about to perform the spell, and I accidentally jumped in the wrong person."
    new "وقتی می‌خواستم جادو رو انجام بدم اشتباهی پیش اومد و توی اون فرد اشتباه پریدم."

    # say L1741 gom
    old "So I ended up controlling her instead."
    new "پس من در نهایت کنترلش رو گرفتم."

    # say L1742 dev
    old "But did it work? I mean controling that body?"
    new "ولی کار کرد؟ منظورم کنترل آن بدن؟"

    # say L1743 gom
    old "It did! Perfectly! I had no trouble getting inside her. And once I did I had total control over her body."
    new "بله! کاملاً! هیچ مشکلی برای ورود به بدنش نداشتم. و وقتی داخلش شدم، کنترل کامل بدنش رو در دست داشتم."

    # say L1744 lin
    old "That's great! So we know you can do it too!"
    new "عالیه! پس می‌دونیم تو هم می‌تونی این کار رو بکنی!"

    # say L1745 pla
    old "Yeah well, we almost got caught though."
    new "بله، ولی تقریباً دستگیر شدیم."

    # say L1746 lin
    old "Oh, I think you're making too much fuzz."
    new "اوه، فکر کنم خیلی زیاد اهمیت میدی."

    # say L1747 lin
    old "What's important is that it can be replicated."
    new "مهم اینه که بتونیم دوباره انجام بدیم."

    # say L1748 pla
    old "Hmm I think so..."
    new "همم، من همینطور فکر می‌کنم..."

    # say L1749 lin
    old "Ok, we can say that was a success."
    new "باشه، می‌تونیم بگیم این موفقیتی بود."

    # say L1750 lin
    old "All right, then, we should keep training the spell with Devonne and Mildret, so they get ready for her practice."
    new "باشه، پس باید این تکنیک رو با دوون و میلدرت آموزش بدیم تا برای تمرین‌اش آماده شدن."

    # say L1751 lin
    old "You can go and keep working on the church meanwhile [pla]."
    new "تو می‌تونی بره و در کلیسا کارت رو ادامه بدهی [pla]."

    # say L1753 pla
    old "Alright, I'll keep working there."
    new "باشه، من اونجا خواهم کار کرد."

    # say L1754 lin
    old "Perfect, go do that, and I'll meet you whenever they are ready."
    new "عالی، برو انجام بده و من هر وقت آماده شدن با تو ملاقات می‌کنم."

    # say L1756 pla
    old "Bye girls, good luck with the training."
    new "بای دختران، موفق باشید در تمرین."

    # say L1757 dev
    old "Thank you, see you later."
    new "ممنون، بعداً می‌بینم."

    # say L1773 lin
    old "Hey [pla], good morning. Ready for the next practice with the shinigamis?"
    new "هی [pla]، صبح بخیر. آماده‌ای برای تمرین بعدی با شینیگامی‌ها؟"

    # say L1774 pla
    old "Hey Linet, yeah sure, I was thinking about what went wrong with Devonne."
    new "هی لینت، بله حتماً، من هم در حال فکر کردن بودم که چه چیزی اشتباه رفت با دوون."

    # say L1775 pla
    old "This time I have an idea to ensure it's done with the right person."
    new "این بار ایده‌ای دارم تا مطمئن شوم که با شخص درست کار می‌کنم."

    # say L1776 lin
    old "Sure, whatever you need. Let's go."
    new "بله، هر چی که لازم داری. برویم."

    # say L1803 dev
    old "Hii."
    new "سلام"

    # say L1804 gom
    old "Hi, good morning."
    new "سلام، صبح خوب."

    # say L1805 lin
    old "Ok, given the advances she made yesterday, I think Gomory is the one that should go with you today."
    new "با توجه به پیشرفت‌هایی که دیروز کرد، فکر می‌کنم گوموری باید امروز همراهت برود."

    # say L1806 lin
    old "I still have a couple of things to train with Mildret, but you two go ahead and practice."
    new "من هنوز چند کار با میلدرت دارم، اما شما دو تا بروید و تمرین کنید."

    # say L1807 lin
    old "And this time please try and do it in the right body [pla]. We don't want to call attention to ourselves."
    new "و این بار لطفاً سعی کنی در بدنتون درست انجام بدید [pla]. ما نمی‌خوایم توجهی به خودمون جلب کنیم."

    # say L1808 pla
    old "Yeah, sure, I'll be more careful."
    new "بله، حتماً، من مراقب خودم خواهم بود."

    # say L1809 pla
    old "Are you ready Devonne?"
    new "آماده‌ای دوون؟"

    # say L1810 dev
    old "I am."
    new "آماده‌ام."

    # say L1811 pla
    old "Ok, then let's go."
    new "خب، پس برویم."

    # say L1826 pla
    old "Ok, so, are you sure you're clear on the process?"
    new "خب، مطمئنی که همه را بلدی؟"

    # say L1827 dev
    old "I am, I know it completely."
    new "بله، من کاملاً آن را می‌دانم."

    # say L1828 pla
    old "Ok then, come on, let's find Billie."
    new "خب، بیای، بیلی رو پیدا کنیم."

    # say L1842 pla
    old "Ok, we found her."
    new "باشه، پیداش کردیم."

    # say L1843 pla
    old "Listen, to avoid confusion like what happened with Gomory."
    new "بله، بگوش، برای اینکه اشتباهاتی مثل آنچه با گوموری اتفاق افتاده، پیش نیاید."

    # say L1844 pla
    old "I'll go and talk to her, and convince her to go with me to the classroom."
    new "من می‌رم و باهاش حرف می‌زنم و متقاعدش می‌کنم که با من به کلاس بیاد."

    # say L1845 pla
    old "You wait here and when you see me going inside, you can go and get inside the body the girl who is with me at that moment."
    new "تو اینجا منتظر بمان و وقتی می‌بینی من داخل می‌روم، می‌تونی داخل بدنشون بره که همراه من هست در آن لحظه."

    # say L1846 pla
    old "Is everything clear?"
    new "همه چیز روشن هست؟"

    # say L1847 dev
    old "Yes, don't worry, that's very simple actually."
    new "بله، نگران نباش، در واقع خیلی ساده است."

    # say L1848 pla
    old "Ok, glad to hear that, let's do it then."
    new "خوشحالم که شنیدم، بیای بیای."

    # say L1859 pla
    old "Hey Billie, how are you?"
    new "هی بیلی، چطوری؟"

    # say L1860 bil
    old "Hey [pla], what's up?"
    new "اوه ز[pla]، چیه؟"

    # say L1861 pla
    old "Not much, I just wanted to ask you something."
    new "خوب نیست، فقط می‌خواستم چیزی از تو بپرسم."

    # say L1862 bil
    old "Oh yeah? What is it?"
    new "اوه آره؟ چیه؟"

    # say L1873 mia
    old "Honestly, you're such a bad student already and you still take the luxury of skipping classes."
    new "صراحیت بگم، شما اصلاً دانش‌آموز خوبی نیستید و هنوز هم لذت از کلاس‌ها می‌برید."

    # say L1874 pla
    old "Uh, Miss Mia, I- I can explain..."
    new "آخ، خانم میا، من- من می‌تونم توضیح بدم..."

    # say L1876 mia
    old "I don't need you to explain anything!"
    new "من نیازی به توضیحاتت ندارم!"

    # say L1877 mia
    old "A bad student is a bad student. That's it, but not only do you skip classes."
    new "یک دانش‌آموز بد همیشه دانش‌آموز بد است. اما شما فقط کلاس‌ها رو نمی‌بیاد."

    # say L1878 mia
    old "You're also here being a bad influence for Billie."
    new "شما هم اینجا هستید تا برای بیلی سوء تأثیر گذار باشید."

    # say L1879 mia
    old "I won't let you do that."
    new "من نمی‌تونم بگم تو اینجوری باشی."

    # say L1880 mia
    old "Come with me to the classroom!"
    new "بیا با من به کلاس!"

    # say L1881 pla
    old "W- Wha-?"
    new "و- وای، چی؟"

    # say L1882 pla
    old "B- but, I'm talking with Billie."
    new "B- ولی، من با بیلی صحبت می‌کنم."

    # say L1885 pla
    old "I- it's important..."
    new "مهمه..."

    # say L1886 mia
    old "Please, what could someone like you to tell her that's important."
    new "لطفاً، چه چیزی مهمی می‌تونی به اونا بگی."

    # say L1887 mia
    old "Now, don't make me repeat myself again, GO TO THE CLASSROOM NOW!"
    new "الان، نباید دوباره تکرار کنم، برو به کلاس الان!"

    # say L1894 bil
    old "Don't worry, we can talk later [pla]."
    new "نگران نباش، بعداً می‌تونیم صحبت کنیم [pla]."

    # say L1895 pla
    old "{alpha=0.8}{i}*Sigh*{/i}{/alpha} Oh fuck..."
    new "{alpha=0.8}{i}*Sigh*{/i}{/alpha} اوه شیطون..."

    # say L1914 mia
    old "Listen, I don't want you contaminating the minds of other students with your bad behaviour."
    new "بگوش، من نمی‌خوام رفتار بدتو باعث آلوده شدن ذهن سایر دانش‌آموزان بشه."

    # say L1915 mia
    old "Especially someone that just arrived at the school like Miss Billie."
    new "به ویژه کسی مثل میس بیلی که baru به مدرسه آمده."

    # say L1916 mia
    old "So you better stay away from here."
    new "پس بهتره از اینجا دور بمانی."

    # say L1923 pla
    old "No no no! Wait!"
    new "نه نه نه! صبر کن!"

    # say L1924 mia
    old "What did you just say to me?"
    new "می‌گفتی چه کاری به من کردی؟"

    # say L1926 mia
    old "Does that mean you're going to ignore what I told you?"
    new "آیا این به معنای اینه که می‌خوای از آنچه بهت گفتم صرف نظر کنی؟"

    # say L1928 pla
    old "No! she is not the girl!"
    new "نه! او دختر نیست!"

    # say L1929 mia
    old "DON'T THINK YOU CAN JUST DO WHAT YOU WANT!"
    new "فکر نکنی می‌تونی هر چی می‌خوای بکنی!"

    # say L1935 pla
    old "Oh fuck!"
    new "اوه شیطون!"

    # say L1937 devMia
    old "Wow! That was a lot easier than I thought it would be!"
    new "واو! این خیلی راحت‌تر از آنچه فکر می‌کردم بود!"

    # say L1938 devMia
    old "The sensations... are so weird! I feel... Heavy."
    new "احساسات... خیلی عجیب هستن! من... سنگین می‌ feeling."

    # say L1939 devMia
    old "But not in a bad way. You know?"
    new "اما نه به طور بد. می‌دونی؟"

    # say L1942 pla
    old "Yeah ok, cool."
    new "بله خوب، عالی."

    # say L1943 pla
    old "But listen, this wasn't supposed to happen."
    new "اما بگو، این قرار نبود بیفتد."

    # say L1945 devMia
    old "It wasn't?"
    new "نه؟"

    # say L1946 pla
    old "No, not at all. This is not the person that's going to be your host for the ritual."
    new "نه، هیچ. این نیست شخصی که قرار بود میزبان مراسم باشه."

    # say L1947 devMia
    old "Well, I did what you told me to. You're not very good at doing these plans you know?"
    new "خب، انجام دادم آنچه به من گفتی. تو خوب در برنامه‌ریزی این طرح‌ها نیستی، می‌دونی؟"

    # say L1949 pla
    old "God, why does this keep happening to me?!"
    new "خدا، چرا اینجوری همیشه به من می‌افتد؟!"

    # say L1950 pla
    old "Anyway, you have to get out of that body."
    new "بازهم، باید از اون بدنش بیرون بیاد."

    # say L1951 devMia
    old "I'll do it gladly."
    new "من خوشحالانه انجام می‌دم."

    # say L1952 devMia
    old "But, I would need your help..."
    new "ولی، به کمکت نیاز دارم..."

    # say L1953 pla
    old "Yeah, yeah I know..."
    new "بله، بله میدونم..."

    # say L1959 devMia
    old "Linett said that receiving magic feels a lot different in a human body."
    new "لینت گفت که دریافت جادو در بدن انسان خیلی متفاوت است."

    # say L1960 devMia
    old "Let's see if it's true."
    new "ببینیم درسته یا نه."

    # say L1961 pla
    old "Sure, but we better be quick."
    new "بله، ولی باید سریع باشیم."

    # say L1962 devMia
    old "Yeah, yeah."
    new "بله، بله."

    # say L1963 devMia
    old "Doing it with a human body, so exciting!"
    new "با بدنش انسانی، خیلی هیجان‌آوره!"

    # say L1964 devMia
    old "And i bet it's even going to be better with that big cock of yours."
    new "و براحت اون ناخودت بزرگت هم بهتر خواهد بود."

    # say L1965 devMia
    old "Now... let's try this."
    new "الان... بیای تو اینو امتحان کنیم."

    # say L1980 pla
    old "Now let's get out of here."
    new "حالا برویم از اینجا بیرون."

    # say L1981 pla
    old "We need to report back to Linett and the others."
    new "باید به لینت و دیگران گزارش بدیم."

    # say L1982 dev
    old "Sure, right behind you."
    new "بله، من هم خودم می‌آیم."

    # say L1999 mia
    old "Why was I on the floor?"
    new "چرا من روی زمین بودم؟"

    # say L2000 mia
    old "All I can remember is that I was talking and everything went black."
    new "فقط به یاد دارم که در حال صحبت بودم و بعد همه چیز تار شد."

    # say L2001 mia
    old "Ugh! Who was I talking with?"
    new "اوه! با چه کسی حرف می‌زدم؟"

    # say L2032 lin
    old "Hey guys! How did it go?"
    new "سلام همه! چطور بود؟"

    # say L2033 lin
    old "Did you manage to do it right this time?"
    new "این بار تونستی به درستی انجام بدی؟"

    # say L2034 pla
    old "Hmm, not exactly."
    new "هم، دقیقاً نه."

    # say L2035 lin
    old "What do you mean, the spell didn't work?"
    new "من قصدت رو نمی‌فهمم، می‌خوای بگی جادو کار نکرد؟"

    # say L2036 dev
    old "Oh, not that, it worked perfectly."
    new "اوه، نه، اون جوری نه، کاملاً کار کرد."

    # say L2037 pla
    old "It's just that she didn't go into the right body."
    new "فقط اینکه او به بدنش درست وارد نشده."

    # say L2038 lin
    old "Oh, again? You know [pla] you should really work on your plans."
    new "اوه، دوباره؟ می‌دونی [pla] باید واقعاً روی برنامه‌هات کار کنی."

    # say L2039 lin
    old "We don't want you to ruin it on the big day."
    new "ما نمی‌خوایم تو روز بزرگ همه چی رو خراب کنی."

    # say L2040 pla
    old "Yeah, sure."
    new "بله، البته."

    # say L2042 lin
    old "But other than that, how did it go? How did you feel?"
    new "اما غیر از اون، چطور بود؟ حس خوبی داشتی؟"

    # say L2044 dev
    old "It was amazing! You had told me it worked, but this was unexpected."
    new "عالی بود! تو به من گفتی که کار می‌کنه، اما این غیرمنتظره بود."

    # say L2045 dev
    old "Human bodies feel so different!"
    new "بدن‌های انسانی احساسات خیلی متفاوتی می‌دهند!"

    # say L2046 lin
    old "Well, if everything goes well, you'll have a chance soon."
    new "اگر همه چیز خوب پیش برود، زودی فرصتی برایت خواهد بود."

    # say L2047 lin
    old "As for you [pla], I still have some things to work out with Mildret, why don't you keep working on the church?"
    new "بازتو [pla]، هنوز چند کار با میلدرت دارم، چرا نمی‌تونی ادامه کار کلیسا رو بده؟"

    # say L2048 lin
    old "And I'll contact you when it's time for the next practice."
    new "و من هم وقتی وقت تمرین بعدی رسید، از تو خبر خواهم داد."

    # say L2050 pla
    old "Sure, then I'll see you later."
    new "بیا، بعداً می‌تونیم ببینیم."

    # say L2066 lin
    old "Hey [pla], today's the last practice day. I hope you're ready."
    new "اوه [pla]، امروز آخرین روز تمرینه. امیدوارم آماده باشی."

    # say L2067 pla
    old "Good morning Linett; yeah sure, I'm ready to do this."
    new "صبح بخیر لینت؛ بله، آماده‌ام برای این."

    # say L2068 lin
    old "Ok, let's go see the girls then..."
    new "خب، بیا برویم دختران رو ببینیم..."

    # say L2096 dev
    old "Hii, we're fine, how are you?"
    new "سلام، ما خوبیم، تو چطوری؟"

    # say L2097 pla
    old "I'm ok, thanks."
    new "من خوبم، ممنون."

    # say L2098 lin
    old "Today is the last practice day."
    new "امروز آخرین روز تمرین است."

    # say L2099 lin
    old "[pla] I've been working with Mildret on perfecting the spell, and she finally learned it."
    new "[pla] من با میلدرت کار کردم تا جادوی رو کامل کنم، و اون هم در نهایت یاد گرفت."

    # say L2100 lin
    old "So take her with you to where her host is and try it."
    new "پس ببر او رو به جایی که میزبانش هست و امتحان کن."

    # say L2102 pla
    old "Sure, no problem, are you ready Mildret?"
    new "بله، هیچ اشکالی ندارم، آماده‌ای میلدرت؟"

    # say L2104 lin
    old "Great, do ahead and let me know how everything goes."
    new "عالی، پیش رو برو و من از همه چیز خبر بگیرم."

    # say L2117 pla
    old "Ok, so the last two previous attempts have failed because of confusion and bad timing."
    new "باشه، پس دو تا تلاش قبلی به خاطر اشتباهات و زمان‌بندی بد ناموفق شدند."

    # say L2118 pla
    old "So this time, I brought a picture with me."
    new "پس این بار، عکسی هم با خودم آوردم."

    # say L2122 pla
    old "This is the person that you're gonna get inside."
    new "این همون شخصیه که باید داخلش بری."

    # say L2123 pla
    old "Make sure you memorize her face, so this time won't happen as before."
    new "حتماً چهره‌اش رو به خاطر بسپار تا این بار مثل قبل نباشه."

    # say L2128 mil
    old "Ok, I'll make sure to remember this face, where can we find her?"
    new "باشه، این چهره رو حتماً به خاطر بسپارم، اونجا کجاست؟"

    # say L2129 pla
    old "She should be at her house, let's go."
    new "باید در خونه‌اش باشه، بیای برو."

    # say L2141 jad
    old "Oh, hello [pla]. It's been quite a while, how are you?"
    new "اوه، سلام [pla]. از آخر هم گذشته، چطوری؟"

    # say L2142 pla
    old "I'm fine Mrs. Jade, thank you."
    new "من خوبم مس جد، ممنون."

    # say L2143 jad
    old "Are you here looking for Hinn?"
    new "آیا برای هین اینجا آمده‌ای؟"

    # say L2144 pla
    old "I am, I have to talk to her about our school project."
    new "بله، باید با او در مورد پروژه مدرسه صحبت کنم."

    # say L2145 jad
    old "Oh, but you see, she's not in at the moment."
    new "اوه، ولی می‌بینی، الان در خانه نیست."

    # say L2146 jad
    old "I think she went out with your friend Belle."
    new "فکر کنم با دوستت بِل خارج شده."

    # say L2147 jad
    old "If you want to, you can come back later when she arrives."
    new "اگر می‌خوای، می‌تونی بعداً وقتی اومد، برگردی."

    # say L2148 pla
    old "I guess I'll have to..."
    new "باید برگردم..."

    # say L2162 pla
    old "Nooo, not again! Damn it!"
    new "نه، دیگه نه! لعنتی!"

    # say L2163 milJad
    old "It worked! I can't believe Linett was right."
    new "کار کرد! نمی‌تونم باور کنم لینت درست گفت."

    # say L2164 pla
    old "Hmph, yeah fine, that's very good and all. But you're in the wrong body!"
    new "همف، بله خوبه، همه خوبه. ولی تو در بدنت اشتباه هستی!"

    # say L2165 milJad
    old "But I got in the body you told me to, I even had the picture and all."
    new "ولی من وارد بدنتی شدم که به من گفتی، حتی عکس هم داشتم."

    # say L2166 pla
    old "Well, that's not her. The body you got into it's her mother."
    new "خب، اون نیست. بدنتی که وارد شدی مادرش هست."

    # say L2167 milJad
    old "Well that's not my fault, they look identical!"
    new "خب این به من نسبت نمی‌ده، همه مثل هم هستند!"

    # say L2168 milJad
    old "I mean, all you humans are very similar to begin with, how was I supposed to know which is which?"
    new "من می‌گم، همه شما انسان‌ها از اول خیلی مشابه هستید، چطور می‌تونستم بدونم کدوم کدوم هستند؟"

    # say L2169 pla
    old "I can't believe this is happening again."
    new "باورم نمی‌شه این دوباره اتفاق می‌فته."

    # say L2170 pla
    old "Well anyway, let's get you out of that body quickly, I don't know when Hinn could come back home."
    new "خب هر حال، بیای بیرون از اون بدنش سریع، نمی‌دونم هن وقتی می‌تونه برگه بیاد."

    # say L2172 milJad
    old "Sure, we already tested that I can do the spell, and it works how intended, let's not delay this any longer."
    new "بله، قبلاً این تکنیک رو آزمون کردیم و میدونیم کار می‌کنه، بیای بیشتر تأخیر نکنیم."

    # say L2177 pla
    old "Uhh, A- Are you ok?"
    new "اوه، آ- آیا حالت خوبه؟"

    # say L2178 pla
    old "You seem a little weird."
    new "تو یه جوری به نظر می‌رسی."

    # say L2179 milJad
    old "Me? Weird? Don't be foolish."
    new "من؟ عجیب؟ بی‌خیال باش."

    # say L2180 milJad
    old "We do this often, why would I be weird about receiving magic in a human body?"
    new "ما این کار رو معمولاً می‌کنیم، چرا باید برای دریافت جادو در بدن انسان عجیب باشم؟"

    # say L2182 pla
    old "Eh, well... I didn't say anything about that."
    new "اوه، خب... من هیچ چیزی در مورد اون نگفتم."

    # say L2183 pla
    old "But sure."
    new "ولی حتماً."

    # say L2184 milJad
    old "You're talking too much."
    new "تو خیلی حرف می‌زنی."

    # say L2185 milJad
    old "Remember we can't waste any time on this."
    new "به خاطر داشت، نمی‌تونیم وقت ببریم."

    # say L2186 milJad
    old "Or the daughter of this body could come back and see us."
    new "یا دختر این بدن می‌تونه برگه بیاد و ما رو ببینه."

    # say L2187 pla
    old "You're right."
    new "درست می‌فرمایی."

    # say L2200 pla
    old "Ok, we are done here, let's go."
    new "باشه، اینجا کار ما تمام شد، برویم."

    # say L2218 jad
    old "How did I fall asleep?"
    new "من چطور خوابیدم؟"

    # say L2219 jad
    old "I can't even remember what I was doing..."
    new "من حتی نمی‌تونم بخوام چه کاری می‌کردم..."

    # say L2220 jad
    old "All I remember is I was talking to someone and then nothing."
    new "همه چیزی که به خاطر دارم اینه که با کسی صحبت می‌کردم و بعد هیچ."

    # say L2221 jad
    old "Who was I talking to?"
    new "با کی حرف می‌زدم؟"

    # say L2254 lin
    old "Well? How did it go? Did you manage to do it?"
    new "خب؟ چطور بود؟ تونستی انجام بدی؟"

    # say L2255 pla
    old "You could say that..."
    new "می‌تونی همین‌جوری بگی..."

    # say L2256 pla
    old "But... you see, something happened."
    new "اما... دیدی، چیزی اتفاق افتاد."

    # say L2257 pla
    old "And Mildret ended up in the wrong body again."
    new "و میلدرت دوباره توی بدنش اشتباه پایین آمد."

    # say L2259 lin
    old "Amazing, you officially suck at this."
    new "البته، تو رسمی در این کار شکست خورده‌ای."

    # say L2260 pla
    old "Hey! Those were accidents, it wasn't my fault."
    new "هی! اونا حادثه بودن، نه گناه من بود."

    # say L2262 lin
    old "It's ok, your ineptitude hasn't cost us anything."
    new "باشه، ناتوانی تو هنوز هیچ چیز رو از دست ما نبرده."

    # say L2263 lin
    old "But enough about you [pla]."
    new "اما خوب، کافیه در مورد تو حرف زد [pla]."

    # say L2264 lin
    old "I want to know how you felt, Mildret. What did you think of the spell?"
    new "می‌خوام بدونم احساست چی بود، میلدرت. از جادو چه فکری کردی؟"

    # say L2265 lin
    old "Was it too difficult?"
    new "آیا خیلی سخت بود؟"

    # say L2266 mil
    old "No, no, no, the opposite actually, it was very easy."
    new "نه، نه، نه، بالعکس، خیلی آسان بود."

    # say L2267 mil
    old "I must say I'm amazed at how good your spell is. The connection to the body is complete."
    new "باید بگم شگفت‌زده‌ام از خوبی جادویت. ارتباط با بدن کامل است."

    # say L2269 dev
    old "Oh, it feels delicious, doesn't it?"
    new "اوه، این حس خوشایند است، نه؟"

    # say L2270 mil
    old "Hmph, I wouldn't say that."
    new "همف، من همینجوری نمی‌گم."

    # say L2271 mil
    old "But it is true that the sensory experience is... Interesting."
    new "ولی درست است که تجربه حسی... جالب است."

    # say L2272 lin
    old "Well, what's important is that now all of you have gotten to test the spell and see that it works."
    new "البته، مهم اینه که حالا همه شما به تجربه این呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟呟"

    # say L2273 lin
    old "That will make things easier to handle the day of the ritual."
    new "این خواهی به ما کمک کنه روز مراسم کار رو بهتر اداره کنیم."

    # say L2274 lin
    old "That makes me feel sure that there won't be any problem the day of the ritual."
    new "این به من اطمینان میده که روز مراسم مشکلی پیش نمیاد."

    # say L2275 lin
    old "But we're not done. Now that you know how to control bodies, we have to work on directing magic power."
    new "اما کار ما تمام نیست. حالا که یاد گرفتی چطور بدنه‌ها رو کنترل کنی، باید روی هدایت توان جادویی کار کنیم."

    # say L2276 pla
    old "Hey, does that mean that my work here is done?"
    new "ای، این بمعنی هست که کار من اینجا تمام شده؟"

    # say L2277 lin
    old "It is, now we need you to focus on securing both the church and making sure the hosts are ready for the day of the ritual."
    new "البته، حالا باید تمرکزت رو بر امن کردن کلیسا و اطمینان از آمادگی میزبان‌ها برای روز مراسم قرار بدی."

    # say L2278 lin
    old "Make sure everything's in place for that day."
    new "مطمئن شو همه چیز برای آن روز آماده باشه."

    # say L2279 pla
    old "Sure, no problem, I'll go then."
    new "بله، هیچ اشکالی نداره، من می‌روم."

    # say L2302 jon
    old "Oh darling! I knew you'd do it."
    new "اوه عزیزم! می‌دونستم تو این کار رو انجام می‌دی."

    # say L2303 gra
    old "Just look at how beautiful the church looks! What a miracle!"
    new "بیاین ببینید چقدر کلیسا زیبا است! چه معجزه‌ای!"

    # say L2304 pla
    old "Thank you, I'm glad you like it."
    new "ممنون، خوشحالم که دوستش داری."

    # say L2305 jon
    old "Oh darling, we don't like it, we love it!"
    new "اوه عزیزم، ما دوستش نداریم، ما ازش خوشحالیم!"

    # say L2306 jon
    old "Who knows how much time it would've taken Sister Grace and I to finish it by ourselves."
    new "می‌دونی چقدر وقت می‌برد که خواهر گریس و من خودمون این کار رو تمام کنیم."

    # say L2307 gra
    old "That's right. You made it possible for this to be ready."
    new "درست می‌فرمایید. تو این امکان رو فراهم کردی."

    # say L2308 jon
    old "Well darling, I'm sure you must be very busy."
    new "خوب عزیزم، مطمئن هستم که شما باید خیلی مشغول باشید."

    # say L2309 jon
    old "And I'm sure you don't want to spend even one more hour of your time here."
    new "و مطمئن هستم که شما نمی‌خواهید حتی یک ساعت دیگر وقت خودتون رو اینجا بگذارید."

    # say L2311 pla
    old "Actually, I wanted to ask you something."
    new "در واقع، می‌خواستم چیزی ازت بپرسم."

    # say L2313 gra
    old "What would you like to know?"
    new "چه چیزی می‌خوای بفهمی؟"

    # say L2314 pla
    old "Well, the thing is that I'm doing this... Hmm, religious thing with a couple of my friends from school."
    new "خب، اونجوری که هست، من یه چیزی رو با چند تا دوستم از مدرسه انجام میدم... هم، یه چیز مذهبی."

    # say L2315 pla
    old "And I would like to know if I can use the church one of these days to have a little ritual."
    new "و من می‌خوام بدونم آیا می‌تونم یک روز از کلیسا استفاده کنم تا مراسم کوچیکی برگزار کنم."

    # say L2317 jon
    old "Ritual?"
    new "مراسم؟"

    # say L2318 pla
    old "Nothing bad."
    new "چیز بدی نیست."

    # say L2319 pla
    old "Just something like what happened last time, you know, to bring them to the lord."
    new "مثلاً مثل آنچه پیش اومد، میدونی، برای اینکه به خداوند برسونیم."

    # say L2321 gra
    old "Oh my god! That sounds wonderful!"
    new "اوه خداوند! این صدا عالی می‌ده!"

    # say L2322 jon
    old "I agree. It's so inspiring to see young people acting in such a way, looking for a connection with the lord. Simply great!"
    new "من هم موافقم. خیلی الهام بخش است که جوانان به این شکل رفتار کنند و به دنبال ارتباطی با خداوند باشند. واقعاً عالی است!"

    # say L2323 gra
    old "Say [pla], could we participate? Just like last time? I would like you to bring me closer to heaven again!"
    new "[pla]، می‌تونیم شرکت کنیم؟ مثل آخر هم؟ من می‌خوام دوباره توی آسمون برسم!"

    # say L2324 pla
    old "Uhh, I think not."
    new "اوه، فکر کنم نه."

    # say L2325 pla
    old "You see, you've already been blessed, the idea is to bring in new people, to receive the blessing."
    new "دیدی، تو قبلاً مورد برکت قرار گرفتی، ایده اینه که افراد جدیدی وارد شدن تا برکت دریافت کنن."

    # say L2327 gra
    old "Oh, really? I must say that's a little disappointing."
    new "اوه، واقعاً؟ باید بگم این کمی ناامید کننده است."

    # say L2329 jon
    old "No, no, sister, what [pla] says it's true."
    new "نه، نه، خواهر، آنچه [pla] می‌گه درسته."

    # say L2330 jon
    old "We must allow for other people to receive such a special blessing and be brought over to the community."
    new "باید به دیگران اجازه بدیم تا این برکت خاص را دریافت کنند و به جامعه وارد شوند."

    # say L2331 pla
    old "It's great that you understand."
    new "خوبه که متوجه شدی."

    # say L2332 pla
    old "So, I think we'll need the church for some days, so that the ritual can be properly done."
    new "پس فکر کنم باید کلیسا رو برای چند روز به ما بدهن، تا مراسم به درستی انجام بشه."

    # say L2333 pla
    old "I would love it if nobody came here, just so that we're not interrupted."
    new "البته، من خوشحال می‌شوم اگر هیچ‌کس نیومد، فقط برای اینکه ما قطع نشویم."

    # say L2335 jon
    old "Oh sure, no problem. We'll see to that, right Sister Grace?"
    new "البته، هیچ اشکالی نداره. ما این کار رو انجام می‌دهیم، درسته خواهر گریس؟"

    # say L2336 gra
    old "There will be no issue."
    new "مشکلی پیش نخواهد آمد."

    # say L2337 gra
    old "We trust you completely, so we'll do as you ask us."
    new "ما به شما اعتماد کامل داریم، پس همانطور که می‌خواهید انجام می‌دهیم."

    # say L2338 pla
    old "Thank you very much! You're of great help."
    new "ممنونم خیلی! تو خیلی کمکت کردی."

    # say L2339 jon
    old "Not at all darling, you're the one who is of great help, bringing people over to the community. What a good young man."
    new "البته عزیزم، تو هستی که کمک زیادی می‌کنی با آوردن مردم به جامعه. چه جوان خوبی."

    # say L2340 gra
    old "It's true, you are a true blessing from the lord."
    new "درست است، شما واقعاً برکت خدا هستید."

    # say L2341 pla
    old "Thank you, very much for saying that."
    new "ممنون از شما، خیلی مهربان هستید."

    # say L2342 pla
    old "I think I better get going then."
    new "به نظر می‌رسه باید برم."

    # say L2343 jon
    old "Good night [pla], and thanks again for all your help."
    new "شب خوب باشید [pla]، و مجدداً ممنون از همه کمک‌هایتون."

    # say L2344 gra
    old "Yes, thank you so much, God bless you."
    new "بله، ممنونم خیلی، خداوند شما را نگه دارد."

    # say L2363 pla
    old "Oh, hi, what's up?"
    new "اوه، سلام، چطوری؟"

    # say L2364 lin
    old "Nothing much, I just wanted to let you know that I talked to the girls."
    new "خوب، فقط می‌خواستم بگم که با دختران صحبت کردم."

    # say L2365 lin
    old "And I'm very happy with the results of the training, they're now ready to do the ritual."
    new "و خوشحالم که نتایج آموزش خوب بود، حالا آماده‌اند تا مراسم رو انجام بدند."

    # say L2367 lin
    old "It is, that's why I wanted to ask you, how are things going with the church?"
    new "این همینه، همین جا می‌خواستم ازت بپرسم، کار کلیسا چطوره؟"

    # say L2368 pla
    old "It's great, I asked them to let me use it, and they said it was ok, so we're all set."
    new "عالیه، ازشون پرسیدم تا برام استفاده کنم، و توافق کردند، پس همه چی آماده‌ست."

    # say L2369 lin
    old "Fantastic, and how are things going with the three humans we need? Did you convince them already?"
    new "عالی، و اوضاع با سه انسانی که نیاز داریم چطور هست؟ قبلاً متقاعدشون کردی؟"

    # say L2371 pla
    old "Uhh, not really, but I think I can convince them of it pretty soon."
    new "اوه، خیر، ولی فکر کنم می‌تونم به زودی متقاعدشون کنم."

    # say L2372 lin
    old "Please do it and remember, they won't notice the ritual at all, so you don't need to worry."
    new "لطفاً این کار رو بکن و به خاطر داشته باش، آنها هیچ احساسی از مراسم نخواهند کرد، پس نباید نگران باشی."

    # say L2373 pla
    old "Ok, I'll keep that in mind. And will talk to them as soon as I can."
    new "باشه، اینو به ذهنم می‌سپaram. و هر زودی باهاشون حرف می‌زنم."

    # say L2375 lin
    old "I'll leave it in your hands then."
    new "البته، به تو واگذار می‌کنم."

    # say L2384 pla
    old "Hmm, the day for the ritual is coming. I better hurry up and talk to the girls soon."
    new "هم، روز مراسم نزدیکه. باید سریع با دختران صحبت کنم."

    # say L2400 bel
    old "Hi [pla]! It's good to see you."
    new "سلام ز[pla]! خوشحالم که دیدت."

    # say L2401 bel
    old "Hey, listen, I'm glad we can talk. I wanted to tell you something."
    new "بله، خوشحالم که می‌تونیم صحبت کنیم. می‌خواستم چیزی به تو بگم."

    # say L2402 pla
    old "Sure, is everything ok?"
    new "بله، همه چیز خوبه."

    # say L2403 bel
    old "Yeah, yeah, everything's fine, it's nothing bad."
    new "بله، بله، همه چیز خوبه، هیچ اشکالی نداره."

    # say L2405 pla
    old "Oh, ok, what is it then?"
    new "اوه، خب، پس چه کاری داری؟"

    # say L2407 bel
    old "Well, it's about what happened the other day with that dumbass bimbo."
    new "خب، در مورد آن روز که همون دیوانه‌باز بیمبو بود."

    # say L2408 bel
    old "She made me angry and I took off and left you alone with her. So I wanted to say sorry."
    new "او منو خیلی ناراحت کرد و من رفتم و تو رو با اونجا چپ خورده گذاشتم. پس می‌خواستم بگم معذرت."

    # say L2410 pla
    old "That's all? Don't worry about it. I understand how irritating her comments can be."
    new "این همه؟ نگران نباش. من می‌فهمم که نظراتش چقدر آزاردهنده می‌تونه باشه."

    # say L2411 bel
    old "They really are and she just makes me so mad."
    new "وای، همینه و نظراتش فقط منو خیلی خسته می‌کنه."

    # say L2412 bel
    old "I hope nothing bad happened with her when I left."
    new "امیدوارم وقتی رفتم هیچ چیز بدی برایش اتفاق نیوفته باشه."

    # say L2413 pla
    old "Bad? Haha, no, of course not, what could happen between us? Nothing happened at all."
    new "بد؟ هاها، نه، البته نه، بین ما چه می‌تونسته بیوفته؟ هیچی پیش نیومده."

    # say L2414 bel
    old "Hmm, Okay..."
    new "Hmm، خب..."

    # say L2415 pla
    old "Well anyway, leaving that aside, there's something that I wanted to talk to you about."
    new "باز هم، اینو جا به جا کنیم، چیزی هست که می‌خواستم با تو صحبت کنم."

    # say L2419 pla
    old "Well, these past few days I've been helping decorate the church, for the holidays and stuff."
    new "خب، این روزهای گذشته من در حال کمک به تزیین کلیسا بودم، برای تعطیلات و همین جور چیزها."

    # say L2420 pla
    old "And the church actually looks really cool."
    new "و کلیسا واقعاً خوب به نظر می‌رسه."

    # say L2421 pla
    old "And it came to me that since we have some free time, why don't we have a little christmas celebration?"
    new "و به ذهنم رسید که چون وقت خالی داریم، چرا نه یه جشن کریسمس کوچیک برگزار کنیم؟"

    # say L2422 pla
    old "I thought it could be really cool if we played truth or dare like last time."
    new "فکر کردم خوب باشه مثل آخر هفته‌ی گذشته بازی حقیقی یا دار بازی کنیم."

    # say L2423 pla
    old "With me, Billie and Hinn by the way."
    new "با من، بیلی و هین هم هستیم."

    # say L2424 pla
    old "Not Mike, I know he can be a little annoying."
    new "مایک رو نه، می‌دونم می‌تونه کمی آزاردهنده باشه."

    # say L2425 bel
    old "Hmm, that sounds like fun. And I do like that Mike won't be there..."
    new "هم، این جالب می‌تونه باشه. و خوشحالم که مایک نخواهد بود..."

    # say L2426 pla
    old "Oh, by the way, I think it would be cool if we dressed up for christmas."
    new "باید بگم، خوب می‌تونیم برای کریسمس لباس‌های خوبی بپوشیم."

    # say L2428 bel
    old "That's actually nice."
    new "این واقعاً خوبه."

    # say L2429 bel
    old "Sure, why not? Count me in."
    new "بله، چرا نه؟ من هم شرکت می‌کنم."

    # say L2430 pla
    old "That's great Belle! So, how about we tomorrow night on the beach? Same spot as last time."
    new "عالیه بل! پس چطور اگر فردا شب روی ساحل بریم؟ همون جای قبلی."

    # say L2431 pla
    old "And from there we can go to the church."
    new "و از آنجا می‌تونیم به کلیسا برویم."

    # say L2451 pla
    old "Hey Billie, how are you doing?"
    new "هی بیلی، چطوری؟"

    # say L2452 bil
    old "Hey dude, what's up?"
    new "سلام داداش، چه خبر؟"

    # say L2453 pla
    old "Hey, I wanted to talk to you about something."
    new "بله، می‌خواستم با تو در مورد چیزی صحبت کنم."

    # say L2454 bil
    old "Sure, is it the same thing you wanted to say to me when Miss Mia dragged you away the other day?"
    new "بله، آیا همان چیزیه که وقتی میس میا تو رو برداشت، می‌خواستی به من بگی؟"

    # say L2455 pla
    old "Oh, yeah, actually it is. But thanks for reminding me that Miss Mia hates me."
    new "بله، درسته. ولی ممنون که بهم یادآوری کردی که میس میا منو نمی‌توسه."

    # say L2456 bil
    old "Hahahaha, dude, she really does. I don't know what you did to get on her bad side. But she has it in for you."
    new "هahaha، داداش، واقعاً همینه. نمی‌دونم چی کردی که اینجوری به تو خشم زد. ولی واقعاً به تو عصبانیه."

    # say L2457 pla
    old "She does, she really does."
    new "بله، واقعاً همینطوره."

    # say L2458 pla
    old "But anyway, that's not what I wanted to say."
    new "اما هر حال، این نیست که من می‌خواستم بگم."

    # say L2459 pla
    old "Listen, I've been thinking, and that game of truth or dare was actually pretty fun."
    new "بله، من هم همینجور فکر می‌کنم. اون بازی حق بازی یا ترسیم واقعاً خوشحالم بود."

    # say L2460 pla
    old "So I thought that since we're gonna have some free time soon. Maybe we could go for another round."
    new "پس فکر کردم چون قراره زودی وقت خالی داشته باشیم. شاید بتونیم دوباره یه دور بازی کنیم."

    # say L2461 bil
    old "Oh, I wasn't expecting you to say that."
    new "اوه، نمی‌تونستم بگم اینو می‌گی‌ی."

    # say L2462 bil
    old "I mean, sure, it could be fun, but I don't know."
    new "منظورم اینه، البته می‌تونه خوشحال کنن باشه، ولی نمی‌دونم."

    # say L2463 bil
    old "Sounds a little boring now."
    new "الان کمی خسته‌کننده شده."

    # say L2465 pla
    old "Oh, come on. Let's do it. Besides, I've been helping your grandma decorate the church."
    new "بله، بیا. بیایم انجام بدیم. همچون، من به گرمایت کمک کردم که کلیسا رو تزیین کنم."

    # say L2467 bil
    old "Yeah, she mentioned it."
    new "بله، او از آن حرف زد."

    # say L2468 pla
    old "Yeah and it actually looks great, so it came to my mind that we could have a little celebration there."
    new "بله و واقعاً خوب هم به نظر می‌رسه، پس به ذهنم رسید که می‌تونیم اونجا یه جشن کوچیک برگذاریم."

    # say L2469 pla
    old "And we can even wear holiday outfits."
    new "و می‌تونیم حتی لباس‌های تعطیلی بپوشیم."

    # say L2471 bil
    old "When you say that we celebrate there."
    new "وقتی می‌گی بیایم جشن بگیریم آنجا."

    # say L2472 bil
    old "I hope that doesn't means my grandma and the nun will be there. Right?"
    new "امیدوارم این به معنای این نیست که بابا من و زن کلیسایی هم اونجا باشند. درسته؟"

    # say L2473 pla
    old "No, not at all."
    new "نه، هیچ کاش."

    # say L2474 pla
    old "I talked to them and I got them to lend me the place for the night. So it will just be us."
    new "من باهاشون حرف زدم و به من اجازه دادن جایی رو برای شب به قرض بدهن. پس فقط ما خواهیم بود."

    # say L2476 bil
    old "Even with that, it doesn't sound like the coolest thing."
    new "حتی با این همه، به نظر نمی‌رسه خیلی خوب."

    # say L2477 pla
    old "It will be cool. And you kind of owe for what happened last time."
    new "خوب خواهد بود. و تو به خاطر آن بار بدهکاری هستی."

    # say L2478 pla
    old "Remember whose idea it was that I climbed that roof?"
    new "به خاطر داشتی که ایده شما بود که من روی آن سقف رفتم؟"

    # say L2479 bil
    old "Ugh, dude, come on! Don't bring that up now, lame."
    new "اوه، داداش، بیا! الان این رو به ذهن نیاور، خسته‌کننده."

    # say L2481 bil
    old "But it's true, I do owe you. And what the hell, it could be fun."
    new "ولی درسته، برات بدهکارم. و بیا، شاید خوشحالم بشه."

    # say L2482 bil
    old "But no Mike, ok? He's annoying."
    new "اما نه مایک، خوبه؟ او خسته‌کننده است."

    # say L2483 pla
    old "Thanks Billie! I'm sure we'll have a great time. Ok, so tomorrow night at the beach? We can go from there."
    new "ممنون بیلی! مطمئنم خوب می‌شه. بله، پس فردا شب روی ساحل؟ از آنجا شروع می‌کنیم."

    # say L2484 bil
    old "Yeah, whatever."
    new "بله، هر چی."

    # say L2486 pla
    old "Alright, see you tomorrow then."
    new "باشه، فردا می‌بینیم."

    # say L2515 hin
    old "I'm glad. My mother told me you came home the other day looking for me. I'm sorry we couldn't talk."
    new "خوشحالم. مامانم به من گفت که روزی پیش به خانه‌ام اومدی و به دنبال من بودی. متاسفم که نتونستیم با هم صحبت کنیم."

    # say L2516 pla
    old "Don't worry, it happens."
    new "نگران نباش، اینجوری می‌شه."

    # say L2517 hin
    old "Yeah, by the way, my mom wanted me to ask you if you remember anything strange happening."
    new "بله، به هر حال، مامانم می‌خواست از تو بپرسم که آیا چیز عجیبی به ذهن تو بر می‌گرده."

    # say L2518 pla
    old "Strange? Heh, Me? N- no, no, why?"
    new "عجیب؟ هه، من؟ ن-نه، نه، چرا؟"

    # say L2519 hin
    old "Well, she says that she remembers talking to you, but then she just woke up, apparently she fell asleep without knowing."
    new "خب، می‌گه که به یاد داره با تو صحبت کرده، ولی بعد از آن به نظر می‌رسه خوابیده بوده، بدون اینکه بفهمه."

    # say L2520 hin
    old "So she wanted me to ask you if you know anything about that."
    new "پس می‌خواست از تو بپرسم که آیا چیزی در مورد اون می‌دونی."

    # say L2521 pla
    old "Hmm, not really, after she told me you weren't there I just left."
    new "Hmm، نه واقعاً، بعد از اینکه به من گفتی تو نبودی، من فقط رفتم."

    # say L2522 pla
    old "Maybe she was tired and doesn't remember falling asleep."
    new "شاید خسته بوده و به خوابیدنش یاد نداشته."

    # say L2523 hin
    old "Yeah, that's what I told her."
    new "بله، همینطور برایش گفتم."

    # say L2524 hin
    old "But anyway, what did you want to talk to me about?"
    new "البته، اما هر حال، تو می‌خواستی با من چه حرفی بزنی؟"

    # say L2526 pla
    old "Oh right, I forgot."
    new "اوه درسته، فراموش کردم."

    # say L2527 pla
    old "Well, you see. I've been thinking that maybe we could get together with Billie and Belle."
    new "ببین، من فکر کردم شاید بتونیم با بیلی و بل هم جمع بشیم."

    # say L2528 pla
    old "And play another round of truth or dare with them. It was very fun last time and maybe it would be good to do it again."
    new "و با هم یه دور دیگه حقیقی یا ترسناک باهاشون بازی کنیم. بار اول خیلی خوشحال بودیم و شاید دوباره انجام بدیم خوب باشه."

    # say L2529 pla
    old "Especially since we have some free time coming up."
    new "به خصوص اینکه وقت خالی هم داریم."

    # say L2532 hin
    old "I don't know [pla]. I mean, it is fun. But you know how nervous I get in those kind situations."
    new "نمی‌دونم [pla]. بله، می‌تونه خوشحالم باشه، اما می‌دونی چقدر در این جور موقعیت‌ها ناراحت می‌شم."

    # say L2533 pla
    old "I know, I know. But that's in part why I propose it, I think it could be very helpful with your anxiety."
    new "می‌دونم، می‌دونم. ولی همین به همین خاطر پیشنهادش می‌کنم، فکر می‌کنم می‌تونه برای اضطرابت خیلی مفید باشه."

    # say L2534 pla
    old "I mean, you can practice a bit and of course stay with me and your friends in a safe place."
    new "من قصدم اینه که یه کم تمرین کنی و البته همیشه با من و دوستات در جایی امن باشی."

    # say L2536 hin
    old "You know what? You might be right. And I think I could also use the experience to deal with my anxiety."
    new "می‌دونی چی؟ ممکنه همینجوری درست باشه. و فکر می‌کنم می‌تونم از این تجربه برای مقابله با اضطرابم استفاده کنم."

    # say L2537 hin
    old "I- I'll do it."
    new "من- من انجام میدم."

    # say L2539 pla
    old "That's cool Hinn. I'm sure we'll have a good time."
    new "خوبه هین. مطمئنم وقت خوبی خواهیم گذروند."

    # say L2540 pla
    old "Oh, and I was thinking, maybe we could take the chance and dress up christmas themed, what do you think?."
    new "و بله، فکر می‌کنم می‌تونیم از فرصت استفاده کنیم و لباس‌های مرتبط با کریسمس بپوشیم، چه خبر می‌دهی؟"

    # say L2541 pla
    old "You know, because it's the holidays."
    new "می‌دونی، چون تعطیلات هست."

    # say L2542 hin
    old "That sounds great! Count me in."
    new "این خوبه! من هم می‌خوام شرکت کنم."

    # say L2543 pla
    old "I was thinking that we could meet at the beach tomorrow night."
    new "فکر می‌کنم می‌تونیم فردا شب به ساحل برویم."

    # say L2544 hin
    old "That sounds ok."
    new "این خوبه."

    # say L2545 pla
    old "See you later then."
    new "بعداً می‌بینیم."

    # say L2546 hin
    old "Sure, goodbye."
    new "بله، خداحافظ."

    # say L2569 pla
    old "Hi, you were waiting for me?"
    new "سلام، منتظر من بودی؟"

    # say L2570 lin
    old "I was, I wanted to tell the other three shinigami are ready for the ritual."
    new "بله، می‌خواستم بگم سه شینیگامی دیگه آماده مراسم هستند."

    # say L2571 pla
    old "I already spoke with my friends, they all said yes."
    new "من قبلاً با دوستام صحبت کردم، همه بله گفتند."

    # say L2572 lin
    old "That's perfect! Ok, so we're all set now."
    new "عالیه! خب، حالا همه آماده‌ایم."

    # say L2573 lin
    old "Get ready, we'll have a lot of work to do tomorrow. Be sure you get enough rest."
    new "آماده شو، فردا کار زیادی داریم. حتماً خوب بخواب."

    # say L2574 pla
    old "I'll make sure to get enough rest."
    new "باشه، حتماً خوب بخوابم."

    # say L2575 lin
    old "Ok then, I'll see you tomorrow."
    new "خب، فردا می‌تونم تو رو ببینم."

    # say L2593 pla
    old "Hey Linett, good morning."
    new "سلام لینت، صبح خوب."

    # say L2594 lin
    old "Are you ready for today?"
    new "آماده‌ای برای امروز؟"

    # say L2595 pla
    old "Yeah sure, I'm ready."
    new "بله حتماً، آماده‌ام."

    # say L2596 lin
    old "Ok then, so let's go talk to the others."
    new "خب، پس برویم با دیگران صحبت کنیم."

    # say L2629 lin
    old "Good morning, I hope you're all ready for the ritual today."
    new "صبح بخیر، امیدوارم همه آماده باشید برای مراسم امروز."

    # say L2630 gom
    old "Hello, yes, we are. We've been practicing so we're confident it's going to go well."
    new "سلام، بله، آماده‌ایم. تمرین کرده‌ایم پس اطمینان داریم خوب پیش می‌رود."

    # say L2631 mil
    old "Hello, I agree."
    new "سلام، من هم موافقم."

    # say L2632 dev
    old "Sure, we feel like we won't have any issues. Good morning [pla]."
    new "بله، حس می‌کنیم هیچ مشکلی نخواهیم داشت. صبح بخیر [pla]."

    # say L2634 lin
    old "Ok, it's good to hear you're confident. So, before we leave for the church, we should go over the plan."
    new "باشه، خوشحالم که اعتمادت رو داری. پس قبل از اینکه برای کلیسا برویم، باید برنامه رو مرور کنیم."

    # say L2635 lin
    old "[pla] has been working to have the place ready for us to use. So that won't be an issue."
    new "[pla] برای آماده‌سازی مکان کار کرده. پس این مشکلی نخواهد بود."

    # say L2636 dev
    old "That's great."
    new "عالی است."

    # say L2637 lin
    old "It is. The idea is that we'll go to the church and wait there."
    new "این همینه. ایده اینه که ما به کلیسا برویم و اونجا منتظر بمونیم."

    # say L2638 lin
    old "In the meantime [pla] will meet with the people that will be our hosts somewhere else and bring them over."
    new "در همین میان [pla] با مردمی که میزبان ما خواهند بود در جایی دیگر ملاقات خواهد کرد و آنها را اینجا می‌آورد."

    # say L2639 lin
    old "When they get to the church they'll come and you'll get inside them."
    new "وقتی به کلیسا برسن، اونجا می‌آین و تو داخلشون می‌شی."

    # say L2640 gom
    old "How will we know who's getting inside who?"
    new "چطور می‌فهمیم کی به کی داخل می‌شه؟"

    # say L2641 pla
    old "I was thinking about that, but honestly it doesn't really makes much of a difference."
    new "من همینجور فکر کردم، اما صراحی فرق خیلی زیادی نمی‌کنه."

    # say L2642 lin
    old "It would if you had run the practice with your actual hosts. But since you didn't, you can just get inside anybody."
    new "اگر با میزبان‌های واقعی تمرین می‌کردی، تفاوت می‌کرد. اما چون انجام ندادی، می‌تونی تو هر کسی بری."

    # say L2644 mil
    old "Ok, It sounds fairly easy."
    new "باشه، به نظر می‌تونه خیلی آسون باشه."

    # say L2645 lin
    old "It will be, after you get them we can start the ritual."
    new "بعد از اینکه آنها رو به دست بیاریم، می‌تونیم مراسم رو شروع کنیم."

    # say L2646 lin
    old "So while you channel magic power, I'll handle the union of all three sources into the breach point."
    new "پس در حالی که تو توانایی جادو را هدایت می‌کنی، من اتحاد سه منبع را به نقطه شکست می‌رسانم."

    # say L2647 lin
    old "If everything goes well, we should be able to create a magic generator point."
    new "اگر همه چیز خوب پیش برود، باید بتوانیم یک نقطه تولید جادو ایجاد کنیم."

    # say L2650 lin
    old "So, we better get to it. [pla] go ahead, and we'll meet back at the church."
    new "پس بهتره شروع کنیم. [pla] برو تو، ما دوباره در کلیسا می‌آیم."

    # say L2651 pla
    old "Ok, see you then."
    new "باشه، تا وقتی."

    # narrator L2654 
    old "Several hours later..."
    new "چند ساعت بعد..."

    # say L2669 pla
    old "Hey girls! Wow... You look stunning!"
    new "دیوونه‌ها! وای… شما خیلی زیبا هستید!"

    # say L2670 hin
    old "Y- You think so?"
    new "وای، می‌تونی اینجوری فکر کنی؟"

    # say L2671 pla
    old "I do. For starters, you look great as a reindeer."
    new "بله. اول از همه، تو به عنوان رنده‌ای عالی به نظر می‌رسی."

    # say L2672 pla
    old "And you Belle, that santa claus outfit really fits you. You look amazing."
    new "و تو بله، اون لباس سانتا کلاوس واقعاً به تو می‌آید. خوبت."

    # say L2673 pla
    old "And Billie, green really is your colour, I think it goes really well with your hair."
    new "و بیلی، سبز واقعاً رنگت هست، فکر می‌کنم خیلی با موت جور می‌شه."

    # say L2674 bil
    old "Well and where is this coming from?"
    new "و این از کجا آمده؟"

    # say L2675 bil
    old "It's odd to hear you being so flattering."
    new "بله، شنیدن این قدر تحسین از تو عجیب است."

    # say L2677 bel
    old "But he's right, we look great. Hahaha."
    new "ولی درسته، ما خوب می‌شیم. هahaha."

    # say L2679 bil
    old "And what about you? What happended with your outfit?"
    new "و تو چطور؟ لباس تو کجا رفت؟"

    # say L2680 pla
    old "Oh crap! I completely forgot… I was a bit busy with all the preparations"
    new "اوه شیطون! کاملاً فراموش کردم… من یه کم با همه آماده‌سازی‌ها مشغول بودم"

    # say L2682 bel
    old "That's not fair..."
    new "این عادلانه نیست..."

    # say L2683 bil
    old "Yeah, yeah whatever..."
    new "بله، بله هر چی..."

    # say L2684 bil
    old "Ok dude, let's start this!"
    new "بیل: خوب، برو، شروع کنیم!"

    # say L2697 bel
    old "Wow! [pla] look at this place! It's amazing!"
    new "واو! ز[pla] اینجا رو ببین! عالیه!"

    # say L2698 hin
    old "They're right, it looks very beautiful [pla]."
    new "حق باهاست، خیلی زیبا به نظر می‌رسد [pla]."

    # say L2699 pla
    old "Well thank you, I'm glad you girls like it."
    new "ممنون، خوشحالم که دوست داشتید."

    # say L2700 bil
    old "Ok, we should start playing, don't we."
    new "خب، باید شروع به بازی کنیم، نه؟"

    # say L2719 pla
    old "Yeah, it's time! Let's start."
    new "بله، وقت شده! بیا شروع کنیم."

    # say L2736 devBel
    old "Woah!"
    new "واو!"

    # say L2737 milBil
    old "That sensation, it's so strong."
    new "این احساس، خیلی قویه."

    # say L2738 pla
    old "Did it work?"
    new "کار کرد؟"

    # say L2740 gomHin
    old "It did, the spell went well."
    new "SPELL خوب کار کرد."

    # say L2755 lin
    old "Great, that was very good."
    new "عالی، این خیلی خوب بود."

    # say L2756 devBel
    old "Well, I wouldn't say it went that well. I mean, look at me! This body is so small."
    new "خب، من نمی‌تونم بگم که خوب رفته. منظورم اینه، نگاه کن به من! این بدنش خیلی کوچیکه."

    # say L2757 devBel
    old "I don't have any more curves! This isn't fair!"
    new "من هیچ منحنی دیگری ندارم! این عادلانه نیست!"

    # say L2758 gomHin
    old "I actually gained size. This girl has way more curves than I do."
    new "من در واقع اندازه گرفتم. این دختر خم‌و‌چنگ‌هایی داره که من ندارم."

    # say L2759 gomHin
    old "I think that the one that came up the better in that sense was Mildret."
    new "فکر می‌کنم از این جهت میلدرت بهتر خروجی داد."

    # say L2760 gomHin
    old "Your host has some real curves, it's amazing!"
    new "میزبانتون خم‌و‌چپ‌های واقعی داره، شگفت‌انگیزه!"

    # say L2761 milBil
    old "I suppose you could say that. She is really big."
    new "می‌تونی همین‌جوری بگی. واقعاً بزرگ هست."

    # say L2762 milBil
    old "I must say I'm surprised she can move around with these things. Specially since humans can't fly."
    new "باید بگم شگفت‌زده‌ام که با این چیزها بتونه حرکت کنه. خصوصاً با توجه به اینکه انسان‌ها نمی‌تونن پرواز کنن."

    # say L2763 gomHin
    old "They can't fly, but they have some sensory capabilities that are unique to them."
    new "نمی‌تونن پرواز کنن، اما حس‌هایی دارن که فقط برایشون هست."

    # say L2764 gomHin
    old "They have access to sensations that we don't."
    new "آنها به حس‌هایی دسترسی دارند که ما نداریم."

    # say L2765 devBel
    old "Oh, you don't have to tell me that. I've had it in my mind since before we made the spell."
    new "او، نیازی نیست به من بگی. از قبل این جادو رو ساختیم، من احساسش رو در ذهنم داشتم."

    # say L2766 lin
    old "I know what you mean, but please remember that's not the reason why we're doing this."
    new "من می‌فهمم چه می‌خوای بگی، اما لطفاً به یاد بیار که این نیست دلیلی که ما این کار رو می‌کنیم."

    # say L2767 gomHin
    old "I know, I know... But still, you can't deny that it's a very interesting experience."
    new "می‌دونم، می‌دونم... ولی همچین، نمی‌تونی اینو انکار کنی که این تجربه خیلی جالب هست."

    # say L2768 gomHin
    old "I mean, even Mildret's waiting for it. Right?"
    new "من قصد دارم، حتی میلدرت هم منتظر اینه. درسته؟"

    # say L2770 milBil
    old "Hmph, the only thing I'm waiting for is the magic we'll get once the ritual is over. Nothing else."
    new "همف، من فقط منتظر جادویی هستم که بعد از مراسم پیش می‌آید. هیچ چیز دیگر نیست."

    # say L2772 devBel
    old "Ha! Yeah right. I know you enjoyed your practice the other day."
    new "ها! همینطور. میدونم تو از تمرین‌هایت لذت برده بودی."

    # say L2773 milBil
    old "Oh, shut up!"
    new "اوه، بس کن!"

    # say L2774 lin
    old "Enough of that, remember we're doing a ritual. And it's better if we begin."
    new "بیا، کافیه از این حرف‌ها، به خاطر داشتی که مراسمی داریم. بهتره اگه شروع کنیم."

    # say L2775 lin
    old "[pla] are you ready?"
    new "[pla] آماده‌ای؟"

    # say L2776 pla
    old "I am, what do I have to do? How is the process?"
    new "آماده‌ام، من چه کاری باید بکنم؟ فرایند چطور هست؟"

    # say L2777 lin
    old "You just have to supply them with magic power so that they can  leave your friends bodies."
    new "تو فقط باید به آنها توانایی جادویی رو بده تا بتوانند از بدنه‌های دوستات بیرون بیان."

    # say L2778 lin
    old "The amount of magic that's actually needed to break the possession is really small."
    new "مقدار جادویی که برای شکستن تسلط لازم است خیلی کم است."

    # say L2780 pla
    old "I'm not sure I follow."
    new "من مطمئن نیستم که متوجه شدم."

    # say L2781 gomHin
    old "What she means is that in the process of pushing us out of these bodies."
    new "منظورش اینه که در فرآیند خارج شدن ما از این بدن‌ها."

    # say L2782 gomHin
    old "There's going to be an excess of magic that's being produced."
    new "مقدار زیادی جادو تولید خواهد شد."

    # say L2784 lin
    old "And that extra magic is the one I'll take and divert to the point where I'll open a breach."
    new "و آن جادوی اضافی رو من می‌گیرم و به نقطه‌ای هدایت می‌کنم که شکاف باز می‌شه."

    # say L2785 lin
    old "That will transform into the magic generation point."
    new "این به نکته تولید جادو تبدیل خواهد شد."

    # say L2787 gomHin
    old "Well, if you do then we better not delay this any longer."
    new "اگر اینجوری هست، بهتره دیگه تأخیر ندهیم."

    # say L2788 lin
    old "She's right. We better get started."
    new "درست می‌گه. بهتره شروع کنیم."

    # say L2790 devBel
    old "Yay!"
    new "عالی!"

    # say L2796 shiBel
    old "Alright, now it's time to you to give us that big cock!"
    new "باشه، حالا وقتت هست تا به ما اون نیم‌تن بزرگت بده!"

    # say L2797 shiHin
    old "My god, this cock of yours, I’ve always thought it’s very big for a human."
    new "الهی، این نیم‌تن تو، همیشه فکر می‌کردم برای انسان خیلی بزرگ باشه."

    # say L2798 shiHin
    old "But seeing it with human eyes... It’s something else."
    new "ولی دیدنش با چشمان انسان... چیزی دیگری هست."

    # say L2799 shiBel
    old "It’s true, I never thought I’d care about the size and girth."
    new "درسته، هرگز فکر نکردم به اندازه و عرض اهمیت بدم."

    # say L2800 shiBel
    old "But with this body..."
    new "اما با این بدن..."

    # say L2801 shiBel
    old "And I never noticed it before, but it has an amazing smell too."
    new "و قبل هیچ وقت توجه نکردم، اما بویش هم خیلی عالیه."

    # say L2802 shiBil
    old "I must admit that it is quite... Enticing."
    new "باید بگم که خیلی... جذاب است."

    # say L2803 shiBel
    old "Mmm! I bet you can’t wait either [pla]."
    new "ممنن! حتماً تو هم منتظری [pla]."

    # say L2805 shiHin
    old "Oh, don’t worry, we’ll make sure you enjoy the process."
    new "اوه، نگران نباش، ما قطعاً اینجا هستیم تا تو لذت ببری."

    # say L2826 gom
    old "It really was, I could feel the magic flowing through me, incredible!"
    new "واقعاً همچین بود، می‌تونستم جادگی رو درونم تجسّس کنم، شگفت‌انگیز بود!"

    # say L2827 lin
    old "That's because there was a lot of magic in the room."
    new "این به خاطر اینه که در اون اتاق جادوی زیادی بود."

    # say L2828 lin
    old "Enough to make the breach and create the portal."
    new "کافی بود برای ایجاد شکاف و دروازه."

    # say L2829 mil
    old "Does that mean that it worked?"
    new "این بدان معناست که کار کرده؟"

    # say L2830 lin
    old "Well, we did everything right. And I made sure to siphon the magic to where we needed it."
    new "خب، همه چیز رو درست انجام دادیم. و من مطمئن شدم که جادو رو به جایی که لازم بود منتقل کردم."

    # say L2831 lin
    old "But the portal takes some time to form."
    new "اما پورتال زمانی برای شکل گرفتن نیاز داره."

    # say L2832 lin
    old "So, we won't know for a while."
    new "پس، مدتی طول می‌کشه تا بفهمیم."

    # say L2833 mil
    old "Then, there's a chance we may have failed."
    new "پس احتمالش هست که ما شکسته باشیم."

    # say L2834 gom
    old "Well, if it did all we have to do is repeat the ritual."
    new "البته، اگر اتفاق افتاده باشه، ما فقط باید مراسم رو دوباره تکرار کنیم."

    # say L2835 dev
    old "That's not a problem, if anything happens it would be a good idea."
    new "این مشکلی نیست، اگر هم چیزی بیفتد، بهتره دوباره مراسم رو تکرار کنیم."

    # say L2836 lin
    old "I'm glad you're positive about it."
    new "خوشحالم که تو مثبتی در مورد این."

    # say L2837 lin
    old "For now let's just wait and see."
    new "برای حالا بیاین ببینیم چه می‌شه."

    # say L2838 pla
    old "Girls, I'm sorry to interrupt, but maybe you could help me clean up my friends."
    new "دختران، معذرت می‌کنم که مداخله می‌کنم، اما شاید بتونید به من کمک کنید که دوستام رو تمیز کنم."

    # say L2839 pla
    old "We have to make it look as if they were sleeping."
    new "باید به نظر برسه که آنها در حال خوابیدن هستند."

    # say L2841 dev
    old "Sure, let's do that."
    new "بله، بیایید این کار رو انجام بدیم."

    # say L2858 mil
    old "Done, now your friends are clean."
    new "انجام شد، حالا دوستاتون تمیز هستند."

    # say L2859 pla
    old "Thank you for your help girls."
    new "ممنون از کمکتون دختران."

    # say L2860 lin
    old "Listen, [pla] since the ritual is done, we have nothing else to do here tonight."
    new "بگوش، [pla] چون مراسم تمام شده، امشب هیچ کار دیگه‌ای برایمون نیست."

    # say L2861 lin
    old "We'll leave and pay attention to see if we feel any changes in the magic concentration in the air."
    new "ما بر می‌گردیم و توجه می‌کنیم که آیا تغییری در غلظت جادو در هوا احساس می‌کنیم یا نه."

    # say L2862 lin
    old "You make sure there's no problem here."
    new "تو مطمئن شو که اینجا مشکلی نیست."

    # say L2863 pla
    old "Alright, I'm gonna wait for my friends to wake up."
    new "باشه، من منتظر بیدار شدن دوستام می‌مونم."

    # say L2864 lin
    old "Hmm, given all the power that went through them, they won't wake up until the morning."
    new "هم، با توجه به همه انرژی که از طریقشون گذشت، تا صبح بیدار نمی‌شنند."

    # say L2865 pla
    old "Ohh man... Really?"
    new "اوه مرد... واقعاً؟"

    # say L2866 lin
    old "Yeap, I guess so."
    new "بله، به نظر می‌رسه همینطور."

    # say L2867 pla
    old "Well, I have no option... Otherwise, it would be really weird for them to wake up without me around."
    new "خب، من هیچ انتخابی ندارم... در غیر این صورت برایشون عجیب می‌تونه باشه که بدون من بیدار بشن."

    # say L2868 mil
    old "Yeah, you are right."
    new "بله، درست می‌گیه."

    # say L2869 lin
    old "Alright, that's all, it's time for us to leave. Let's go."
    new "باشه، این همه، الان وقت برای رفتنمونه. بیای."

    # say L2871 mil
    old "Thanks for... Everything."
    new "ممنونم... از همه."

    # say L2872 gom
    old "Good bye [pla]."
    new "خداحافظ [pla]."

    # say L3005 bel
    old "[pla]? What happened?"
    new "[pla]؟ چه کاری افتاد؟"

    # say L3006 hin
    old "I can't remember anything."
    new "من هیچ چیز رو به یاد نمی‌آورم."

    # say L3007 bil
    old "What the hell? We fell asleep?"
    new "چه خبره؟ ما خوابیدیم؟"

    # say L3008 pla
    old "I think we just fell asleep after playing."
    new "فکر کنم ما بعد از بازی خوابیدیم."

    # say L3009 pla
    old "I also just woke up."
    new "من هم همین جا بیدار شدم."

    # say L3010 bil
    old "We just fell asleep?"
    new "ما همین جا خوابیدیم؟"

    # say L3012 pla
    old "Uhh yeah, you know, it was pretty late."
    new "آره، می‌دونی، خیلی دیر بود."

    # say L3013 bel
    old "Hmm, I guess that makes sense. "
    new "Hmm، حدس می‌زنم اینجوری هست."

    # say L3014 pla
    old "Hey, I think it's better if we just go home, it's already morning, and someone may come."
    new "بله، بهتره که برمی‌ریم، الان صبح شده و ممکنه کسی بیاد."

    # say L3016 hin
    old "You're right, we shouldn't worry our parents."
    new "درست می‌فرمایی، ما نباید والدینمون را نگران کنیم."

    # say L3017 bel
    old "That's true, see you later then."
    new "درسته، بعداً می‌بینیم."

    # say L3019 bil
    old "I still don't get why I can't remember anything, but anyway, I guess I'll go home, later."
    new "هنوز هم متوجه نمی‌شم چرا هیچ چیز رو به یاد نمی‌آورم، ولی بله، فکر کنم برم خونه، بعداً."

    # say L3020 hin
    old "I think I'll also be on my way, bye [pla]."
    new "فکر کنم من هم برم، خداحافظ [pla]."

    # say L3021 pla
    old "Bye girls."
    new "بای دختران"

    # say L3027 lin
    old "Oh, you're finnally here."
    new "اوه، در نهایت اینجا هستی."

    # say L3029 lin
    old "Good morning, I'm glad you are fine. I just wanted to thank you for everything you did."
    new "صبح بخیر، خوشحالم که حالت خوبه. فقط می‌خواستم ازت برای همه چیزی که انجام دادی تشکر کنم."

    # say L3030 pla
    old "Oh, you don't have to thank me, I'm a Sexnote owner, that's my mission."
    new "اوه، نباید ممنونی، من صاحب سکس‌نوت هستم، این کار رو باید انجام بدم."

    # say L3031 lin
    old "That's right, however you have done a lot you didn't have to."
    new "درست است، اما تو خیلی کارهایی انجام دادی که نباید انجام میدادی."

    # say L3032 lin
    old "And everything was for us, to save and protect us."
    new "و همه چیز برای ما بود، برای نجات و محافظت از ما."

    # say L3034 lin
    old "All right. Now we just have to wait to see if everything worked..."
    new "باشه. حالا فقط باید ببینیم همه چی کار کرده یا نه..."

    # say L3035 pla
    old "How much would it takes?"
    new "چقدر زمان می‌بره؟"

    # say L3036 lin
    old "To be honest I don't know... It's the first time someone tries to create a magic generation point."
    new "صusch، من هم نمی‌دونم... این اولین باره که کسی سعی می‌کنه نقطه تولید جادویی بسازه."

    # say L3037 lin
    old "It could take, hours, days, weeks or months, the only thing we can do now is wait.."
    new "می‌تونه بیش از یه ساعت، یه روز، یه هفته یا یه ماه طول بکشه، الان همین جای ما هست که صبر کنیم."

    # say L3039 pla
    old "Oh, man... I was expecting a faster result."
    new "اوه، مرد… من منتظر نتیجه‌ای سریع‌تر بودم."

    # say L3040 lin
    old "Actually, I'm pretty sure, that is everthing worked, we could notice a change in the whole area, and it won't take long for sure."
    new "در واقع، من احتمال میدم اگه همه چیز درست کار کرده باشه، تغییری توی منطقه کلی مشاهده بشه و حتماً طول نمی‌کشه."

    # say L3042 lin
    old "Yeah, don't worry, this time we did it right. And all of this thanks to you."
    new "بله، نگران نباش، این بار همه چیز درست انجام شد. و همه این‌ها بخاطر تو بود."

    # say L3043 pla
    old "I'm glad to had helped."
    new "خوشحالم که کمک کردم."

    # say L3044 lin
    old "All right, I think you should rest. I can see you pretty tired."
    new "باشه، فکر کنم باید استراحت کنی. می‌بینم خیلی خسته‌ای."

    # say L3045 pla
    old "You're right, I did slept well last night... Thank you and see you later."
    new "درست می‌فرمایی، خوب خوابیدم شب گذشته... ممنون و دوباره ببینم."


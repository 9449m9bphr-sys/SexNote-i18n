# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Bathroom.rpy
translate persian strings:

    # menu L11 
    old "Look at her better"
    new "بیشتر بهش نگاه کن"

    # say L19 pla
    old "I should leave... I don't want to make her think I'm perverted."
    new "باید برسم... نمی‌خوام فکر کنه من پرتلاش هستم."


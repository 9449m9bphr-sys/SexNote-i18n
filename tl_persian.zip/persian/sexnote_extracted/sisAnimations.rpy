# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/sisAnimations.rpy
translate persian strings:

    # say L6 pla
    old "W- What are you doing?"
    new "و- و تو چه کاری داری؟"

    # say L7 sis
    old "What does it look like?"
    new "و چه می‌تونی بگی؟"

    # say L12 sis
    old "Hmm, your cock is so tasty!"
    new "هم، نوک تو خیلی لذت‌بخش است!"

    # say L13 sis
    old "Don't you like it?"
    new "می‌پسندی نه؟"

    # say L18 sis
    old "I can't believe you have such a big cock!"
    new "نمی‌تونم باور کنم تو چقدر بزرگی!"

    # say L43 pla
    old "Please, stop. You are... Gonna make me-"
    new "لطفاً، متوقف شو. تو... می‌خوای من-"

    # say L44 sis
    old "Cum? Oh please do it. I'm dying to see this monster cock cum all over..."
    new "لطفاً، بیا. من دیگه نمی‌تونم صبر کنم... این نیم‌پای بزرگ رو می‌خوام همه جا پاشون بیاد..."

    # say L50 sis
    old "Shit! That was so intense... Did you like it?"
    new "شیطان! اینقدر تنش بود... لذت برده بودی؟"

    # say L51 pla
    old "Ye... I- I have to go..."
    new "بله... من- من باید برم..."

    # say L58 pla
    old "What the fuck was that?"
    new "چه خربه بود این؟"

    # say L59 pla
    old "I better go to sleep now..."
    new "بهتره حالا برم خواب بکنم..."

    # say L74 pla
    old "Ready for a new day!..."
    new "آماده‌ام برای روز جدید!"

    # say L92 sis
    old "Hmm I love this taste."
    new "Hmm من این طعم رو دوست دارم."

    # say L93 sis
    old "Do you like how it feels inside my mouth?"
    new "آیا دوست داری احساسش رو توی دهان من بکنی؟"

    # say L97 sis
    old "It's fucking huge, I want to have it all inside, do you think I'm capable?"
    new "این خیلی بزرگه، می‌خوام همه‌ش رو داخلم بیارم، فکر می‌کنی قابلیت این کار رو دارم؟"

    # say L99 sis
    old "Oh my god, I can feel it reaching my throat."
    new "اوه خدا، می‌تونم حس کنم به گلوی من می‌رسه."

    # say L103 sis
    old "What about a deepthroat?"
    new "عمیق‌تر می‌تونی؟"

    # say L105 pla
    old "Oh my God!"
    new "اوه خدا!"

    # say L106 sis
    old "Oh my, I can feel every inch inside my mouth!"
    new "اوه، می‌تونم هر اینچ رو درون دهانم حس کنم!"

    # say L129 pla
    old "Ohhh, I- I!"
    new "اوه، من- من!"

    # say L134 sis
    old "Wow... That was massive, let me clean this mess... "
    new "واو... این خیلی بزرگ بود، بیایم این درهم و دسته رو تمیز کنیم..."

    # say L163 pla
    old "(Oh man in a second I will be hard...)"
    new "اوه بابا، الان دو ثانیه بعد سخت می‌شوم..."

    # say L166 sis
    old "Ohh, I love it ... My tits are very sensitive, I'm getting horny..."
    new "اوه، عاشقش شدم... پستان‌هام خیلی حساس هستن، خیلی خیلی خیالی می‌کنم..."

    # say L170 sis
    old "Ohh yeah, just like that... Don't stop baby..."
    new "اوه بله، همینطور... نتوقای عزیزم، ادامه بده..."

    # say L207 sis
    old "How does it feel in between these amazing boobs?"
    new "بین این سینه‌های شگفت‌انگیز چطور حس می‌کنی؟"

    # say L208 pla
    old "Ohh... It... Feels great."
    new "اوه... خیلی خوب است."

    # say L211 sis
    old "Ohh... It feels really good..."
    new "اوه... واقعاً خوب است..."

    # say L212 sis
    old "Do not try to stop, keep moving faster."
    new "دستت رو متوقف نکن، تاشون سریع‌تر بکن."

    # say L216 sis
    old "Oh yeah, fuck my tits! Harder, fuck them harder!"
    new "اوه بله، سیک پستان‌هام! سخت‌تر، سیکشون سخت‌تر!"

    # say L240 pla
    old "[sis], I'm going to..."
    new "[sis]، من قراره خیلی زود..."

    # say L241 sis
    old "Oh yeah, cum all over me!"
    new "اوه بله، روی من خروجی بده!"

    # say L259 pla
    old "Hey Ky-... (Wow!)"
    new "اوه کای… (واو!)"

    # say L260 pla
    old "Oh shit, she is playing with her dildo..."
    new "اوه شیطون، تو داری با دیلدویت بازی می‌کنی..."

    # say L261 pla
    old "I have to keep quiet so she doesn't notice me."
    new "من باید آرام بمانم تا متوجه نشود."

    # say L265 sis
    old "Mmm, it feels so good!"
    new "مم، اینجوری خیلی خوب است!"

    # say L266 sis
    old "My pussy wants a big, hard cock!"
    new "پوسی من می‌خواهد یک نیوک بزرگ و سخت!"

    # say L270 sis
    old "Oh yeah! it feels better than fingering!"
    new "اوه بله! این بهتر از لمس خودم هست."

    # say L271 sis
    old "I'm so fucking wet right now."
    new "من الان خیلی خیس هستم."

    # say L302 sis
    old "Ughhh I can't take it anymore, I want to feel my pussy fucked! "
    new "اوه، دیگه نمی‌تونم، می‌خوام احساس کنم پوسی خودمو بزنن!"

    # say L304 pla
    old "(Oh wow!)"
    new "اوه وای!"

    # say L305 sis
    old "Ohhh yeah!"
    new "اوه آره!"

    # say L309 sis
    old "Ahhh, yes! Right there."
    new "آه، بله! همین جا."

    # say L310 sis
    old "This is so fucking good!"
    new "این خیلی خوبه!"

    # say L314 sis
    old "Mmmm, I want to cum now!"
    new "ممم، من می‌خوام الان برسوم!"

    # say L343 sis
    old "Oh, yeah! Yeahh!!!"
    new "اوه، بله! بلهه!!!"

    # say L344 sis
    old "I'm cumming!"
    new "من برمی‌آیم!"

    # say L360 pla
    old "(Oh my god it's like my dream!)"
    new "اوه خدا، مثل رویاهام!"

    # say L361 sis
    old "Oh yeah, fuck my mouth [pla]."
    new "اوه بله، دهانم رو زدن [pla]."

    # say L364 sis
    old "Come on! I want you to fuck my throat harder!"
    new "بیا! می‌خوام تو خونه منو سخت‌تر بزنی!"

    # say L365 pla
    old "A- alright..."
    new "ا- خوب..."

    # say L370 sis
    old "I want to have it all inside my mouth."
    new "می‌خوام همه‌ش رو توی دهانم بذارم."

    # say L371 sis
    old "Harder [pla], fuck my mouth harder!"
    new "سخت‌تر ز[pla]، دهانم رو بزن!"

    # say L373 sis
    old "Hmmm!"
    new "Hmm!"

    # say L397 sis
    old "Don't stop, don't stop! Cum inside my throat!"
    new "توقف نکن، توقف نکن! تو داخل گلوی من بیا!"

    # say L414 sis
    old "Ohh! It's so big..."
    new "اوه! اینقدر بزرگ است..."

    # say L415 sis
    old "Your cock is so much better than my dildo."
    new "پوس تو خیلی بهتر از دیلدوی من است."

    # say L419 sis
    old "Come on, I want you harder, fuck me harder [pla]!"
    new "بیا، من می‌خوام سخت‌تر زنی، سخت‌تر زن [pla]!"

    # say L422 sis
    old "Do you like being inside your [sisrel]?"
    new "آیا دوست داری من داخل تو باشم [sisrel]؟"

    # say L426 sis
    old "Yeah! Yeah! Fuck me [pla], Fuck me!"
    new "بله! بله! فرما ز[pla]، فرما!"

    # say L428 sis
    old "Oh gosh! It's fucking huge!"
    new "اوه خدا! این واقعاً بزرگه!"

    # say L429 sis
    old "You're drilling me"
    new "تو داری من رو می‌زدی"

    # say L452 sis
    old "I'M GONNA... I'M GONNA-"
    new "من قراره... من قراره-"

    # say L453 sis
    old "OOOOOHHHH! YEAHHH..."
    new "اوه هااااا! آره..."

    # say L457 sis
    old "Fuck... It was really good..."
    new "فوک... واقعاً خوب بود..."

    # say L466 pla
    old "Ok... Let me try, like this?"
    new "باشه... بیایم، مثل این؟"

    # say L467 sis
    old "Just relax your hands and enjoy what you are doing, don't you like it?"
    new "دست‌هایت رو آرامش بده و از آنچه می‌کنی لذت ببر، نمی‌پسندی؟"

    # say L468 pla
    old "Gulp... Y-yes."
    new "گulp... ب-bale."

    # say L471 sis
    old "Yeah, you're doing great, very gentle."
    new "بله، خوب می‌کنی، خیلی نرم."

    # say L472 pla
    old "(This is delicious, she is so hot.)"
    new "این خوشمزه است، تو خیلی گرمی."

    # say L473 sis
    old "Do you like my ass?"
    new "می‌پسندی این پاشم؟"

    # say L478 sis
    old "Be creative, you can touch all you want! I like it."
    new "می‌تونی هر جایی رو لمس کنی! من دوست دارم."

    # say L479 sis
    old "Do it harder baby..."
    new "بیشتر انجام بده عزیزم..."

    # say L517 sis
    old "Ugghh... It feels great."
    new "آه... خیلی خوب احساسش می‌کنم."

    # say L518 sis
    old "Oh yeah... Fuck my pussy baby."
    new "اوه بله... پوسی‌مو بزن بچه."

    # say L522 sis
    old "Ohh yeah baby, don't stop."
    new "اوه بله بچه، متوقف نشو."

    # say L523 sis
    old "Yes! Yes! Just like that fuck me [pla]!"
    new "بله! بله! همینطور منو بزن [pla]!"

    # say L527 sis
    old "Ohhh, ohhh, I'm goona cum. Harder. Fuck me harder!"
    new "اوه، اوه، من هم قراره بیام. سخت‌تر. بیشتر بزن!"

    # say L551 sis
    old "OHH GOD, OHH GOD. I'M CUMMING!"
    new "اوه خدا، اوه خدا. من هم بیام!"

    # say L553 pla
    old "I- I'm cumming too!"
    new "من هم هستم!"

    # say L556 sis
    old "Oh yeah... I can feel it all inside me."
    new "اوه بله... همه‌ش رو داخلم می‌حسنم."

    # say L570 sis
    old "I love playing with your cock"
    new "من دوست دارم با نونت بازی کنم"

    # say L571 sis
    old "Enjoy the view..."
    new "لذت ببر از منظره..."

    # say L574 sis
    old "Do you like my throat?"
    new "آیا دوست داری گلوی من رو ببینی؟"

    # say L575 pla
    old "Oh yes..."
    new "اوه بله..."

    # say L576 sis
    old "Then, what are you waiting to fuck it?"
    new "پس، منتظر چی هستی تا آن رو بکنی؟"

    # say L580 sis
    old "Harder [pla], fuck your [sisrel] throat!"
    new "سخت‌تر [pla]، خر زندهتو [sisrel] در بیا!"

    # say L606 pla
    old "[sis] I'm going to-"
    new "[sis] من قراره-"

    # say L607 sis
    old "Cum in my mouth baby..."
    new "در دهانم بیا عزیزم..."

    # say L625 sis
    old "Ughh, is so big."
    new "اوه، خیلی بزرگه."

    # say L626 sis
    old "I love it!!!"
    new "عشقت به این!!!"

    # say L627 sis
    old "Ohhh nicee baby, yeah fuck your [sisrel]!"
    new "اوه خوبه بچه، بله بفرمای ز[sisrel]!"

    # say L630 sis
    old "Ohh I want you deep inside me..."
    new "اوه من می‌خوام تو رو عمیق داخل من داشته باشی..."

    # say L633 sis
    old "My pussy is gripping that fucking cock."
    new "پوسی من آن قلیق را محکم در خود نگه می‌کنه."

    # say L636 sis
    old "HARDER! FUCK ME HARDER BABY!"
    new "سخت‌تر! من رو سخت‌تر بکن بچه‌جان!"

    # say L638 sis
    old "OH GOD, OH GOD! I'M CUMING!"
    new "اوه خدا، اوه خدا! من جیز می‌زنم!"

    # say L661 pla
    old "I'm gonna-"
    new "من الان می‌گم-"

    # say L662 sis
    old "YES BABY CUM INSIDE ME!"
    new "بله بیبی، تو درون من جیز کن!"

    # say L707 sis
    old "Alright, now it's time to wake up."
    new "البته، حالا وقت بیدار شدن است."

    # say L709 sis
    old "This is a dream, dummy... "
    new "این یه رویا هست، بی‌حوصله..."

    # say L710 sis
    old "Did you really think that I would let you fuck my mouth?"
    new "واقعاً فکر کردی من بهت اجازه بدم دهانم رو بکنی؟"

    # say L712 sis
    old "Hahaha! Hahahaha!"
    new "هahaha! هahaha!"

    # say L721 linSis
    old "That’s right, just let me do the work."
    new "بله، همین‌جوری، فقط بگذار من کارش رو انجام بدم."

    # say L722 linSis
    old "Mmmm! It’s so big."
    new "ممنن! اینقدر بزرگه."

    # say L723 pla
    old "Do you feel ok? Has anything changed?"
    new "حالت خوبه؟ هیچ چیز تغییر کرده؟"

    # say L724 linSis
    old "I do, it feels so different, human bodies are more sensitive after all."
    new "بله، احساس می‌کنم، خیلی متفاوته، بدن انسان‌ها حساس‌تر هستند."

    # say L725 linSis
    old "But nothing has changed, no problem."
    new "اما هیچ چیز تغییر نکرده، هیچ مشکلی نداره."

    # say L729 linSis
    old "Oh, yes, like that."
    new "اوه، بله، همینطور."

    # say L730 linSis
    old "It feels soo great."
    new "این خیلی خوبه."

    # say L731 pla
    old "Do you feel any magic?"
    new "می‌تونی جادویی حس کنی؟"

    # say L732 linSis
    old "Not yet... Ah! keep going."
    new "هنوز نه... آه! ادامه بده."

    # say L733 linSis
    old "Maybe in a little. Mmmm."
    new "شاید یه کمی دیگه. ممم."

    # say L737 linSis
    old "AH, AH, YES!"
    new "آه، آه، بله!"

    # say L738 linSis
    old "N- now I feel it."
    new "اوه، حالا حس کردم."

    # say L739 linSis
    old "Don’t stop, keep going!"
    new "توقف نکن، ادامه بده!"

    # say L762 pla
    old "I- I can’t hold it anymore."
    new "من- من دیگه نمی‌تونم."

    # say L764 linSis
    old "Oh yes, do it!"
    new "اوه بله، انجام بده!"

    # say L766 linSis
    old "Ohh yeahh!"
    new "اوه همینه!"

    # say L772 lin
    old "Amazing, it’s incredible how much magic power you’re able to hold and release."
    new "الان، شگفت‌زده‌ام از قدرت جادویی که می‌تونی ذخیره کنی و رها کنی."

    # say L773 lin
    old "And doing it in a human body felt so different and good!"
    new "و انجامش در بدن انسانی هم خیلی متفاوت و خوب بود!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/BilStory.rpy
translate persian strings:

    # say L64 pla
    old "What's this? Doodles, messy scratches... hold up, are these lyrics?"
    new "این چیه؟ نقاشی‌هایی، خطوط پرتوزان... صبر کن، این‌ها آیا لی‌ریک‌ها هستند؟"

    # say L65 pla
    old "Music notes scribbled everywhere. 'Faded echoes, songs we lost...'"
    new "نوت‌های موسیقی همه جا پخش شده. «صداهای ناپیدا، آهنگ‌هایی که از دست دادیم...»"

    # say L69 pla
    old "Yeah, that's the right call."
    new "بله، همین هست."

    # say L144 pla
    old "Hold up, what’s this flyer on the floor?"
    new "توقف، این آگهی روی زمین چیه؟"

    # say L150 pla
    old "School’s doing a music contest? 'Sign up now'..."
    new "مدرسه مسابقه موسیقی می‌کنه؟ 'الان ثبت‌نام کنید'..."

    # say L339 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 percent yourself. Ready? Let’s make magic!"
    new "پس نفس بکش، لذت ببر و به یاد داشته باش: صحنه جایی است که می‌توانی صد درصد خودت باشی. آماده‌ای؟ بیاییم جاده‌ای ایجاد کنیم!"

    # say L415 bey
    old "Arielle and Kayla!"
    new "آریل و کیلا!"

    # say L425 bey
    old "Lord have mercy on my edges! Arielle, those whistle tones cleaner than my Sunday choir. Kayla, that belt could wake the dead."
    new "اللّه بر لبه‌هامون بخشنده باشه! آریل، این نت‌های بلند تر از صدای کور خودم هم تمیزتره. کیلا، این صدای قوی می‌تونه حتی مردها رو بیدار کنه."

    # say L474 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100 percent. Volume was whisper quiet, but somehow you filled the entire room."
    new "صدات مثل بادام زنده است، عباراتت قلب‌سوز است، صداقت احساسی ۱۰۰ درصد. صدایت همچون فلکر بود، اما با وجود آن، اتاق را پر کردی."

    # say L476 bey
    old "However, [pla]... sweetheart, you were a potted plant."
    new "ولی، ز[pla]... عزیزم، تو مثل گیاه در مخزن بودی."

    # say L478 bey
    old "Next time you move, you breathe with her, you support her. Deal?"
    new "بعداً وقتی حرکت می‌کنی، با او نفس بکشی، او را حمایت کنی. توپی؟"

    # say L496 bey
    old "Sharpay & Ryan: spectacle and precision. Arielle & Kayla: vocal olympics. Billie & [pla]: pure soul."
    new "شارپی و رایان: نمایش و دقت. آریل و کیلا: المپیاد صدا. بیلی و [pla]: روح خالص."

    # say L873 pla
    old "Watched like three tutorials last night. How hard can be?"
    new "دیروز سه آموزش رو دیدم. چقدر سخت می‌تونه باشه؟"

    # say L892 pla
    old "Let’s try again..."
    new "بیای دوباره سعی کنیم..."

    # say L905 pla
    old "One more time. Come on, [pla]."
    new "بار دیگه. برو، [pla]."

    # say L933 pla
    old "Okay... that almost sounded like music... right?"
    new "باشه... اونجوری تقریباً موسیقی می‌تونست بود... درسته؟"

    # say L934 pla
    old "Ugh, enough for today. Fingers are officially dead."
    new "اوه، خوب برای امروز کافیه. انگشت‌هام رسمی مرده."

    # say L1109 pla
    old "Wow... you're amazing."
    new "وای… تو عالی هستی."

    # say L1377 pla
    old "Still not perfect... but it sounded more like a song this time."
    new "هنوز کامل نیست... اما این بار بیشتر مثل یه آهنگ شد."

    # say L1551 pla
    old "T- they're so sensitive... I can feel them hardening more."
    new "اونا خیلی حساس هستن... می‌تونم حس کنم سخت‌تر می‌شنن."

    # say L1604 pla
    old "W- what do you have in mind?"
    new "W- چه چیزی به ذهن تو می‌رسه؟"

    # say L1613 bil
    old "And of course, I know you’re gonna need a little extra motivation..."
    new "و البته، می‌دونم که تو نیاز به تحریک کمی بیشتری داری..."

    # say L1623 bil
    old "Shh. Focus. This is practical training, remember?"
    new "ش. تمرکز کن. این تمرین عملیه، به خاطر داشته باش."

    # say L1624 pla
    old "O- Ok..."
    new "ب-اله..."

    # say L1625 bil
    old "Mmm... good. Feel how it responds under your fingers?"
    new "ممنون... خوب. حس کن چطور زیر انگشت‌هایت واکنش نشون می‌ده؟"

    # say L1626 pla
    old "It's... getting wetter already."
    new "البته... حالا مرطوب‌تر می‌شه."

    # say L1627 bil
    old "That's normal. Keep the rhythm steady. You're learning the technique."
    new "این طبیعیه. ریتم رو ثابت نگه دار. تکنیک رو یاد می‌گیری."

    # say L1632 bil
    old "Now increase the pressure a bit. Faster circles. Don't lose the rhythm."
    new "حالا فشار رو کمی افزایش بده. دایره‌ها رو سریع‌تر کن. ریتم رو از دست نده."

    # say L1634 bil
    old "Nngh— yes... that's it. You're doing well. Keep going."
    new "نه— بله... همینه. خوب می‌کنی. ادامه بده."

    # say L1639 bil
    old "Harder. Don't stop. Make me feel it."
    new "سخت‌تر. متوقف نشو. برام احساسش بده."

    # say L1640 pla
    old "[bil]... you're breathing heavier."
    new "[bil]... تنگی نفس می‌کنی."

    # say L1641 bil
    old "Fuck... just like that. Keep going. Don't you dare slow down."
    new "بیلی: زدن... همینطور. ادامه بده. نمی‌تونی آرامش بدی."

    # say L1646 bil
    old "Ngh- Stop, stop, stop..."
    new "نگه- ایست، ایست، ایست..."

    # say L1647 pla
    old "... Did I do something wrong?"
    new "... اشتباهی کردم؟"

    # say L1648 bil
    old "Mmm, no, no... actually you were doing it really well."
    new "ممنون، نه، نه... در واقع تو خیلی خوب انجام می‌دادی."

    # say L1649 bil
    old "But I want you to try something... Uhh, more advanced."
    new "اما من می‌خوام تو امتحان کنی چیزی... هم، پیشرفته‌تر."

    # say L1650 bil
    old "Now... use two fingers. Slide them in together. Start slow."
    new "الان... دو انگشتت رو بکار ببر. هم‌هم وارد کن. آرام شروع کن."

    # say L1652 pla
    old "Uhh... like this?"
    new "اوه... مثل این؟"

    # say L1653 bil
    old "Mmm, yeah, just like that..."
    new "می‌دونم، همینطور..."

    # say L1654 bil
    old "Curl them. Find the spot and start moving them slowly... let me feel it."
    new "پیچشون. جایی پیدا کن و شروع به حرکتشون آرام آرام کن... برام احساسش کنم."

    # say L1755 bil
    old "Ready for your advanced practice?"
    new "آماده‌ای برای تمرین پیشرفته؟"

    # say L1808 bil
    old "Finally. You're late."
    new "اخرالنها. دیر اومدی."

    # say L1809 pla
    old "I know, I know... I’m sorry."
    new "می‌دونم، می‌دونم... خواهش می‌کنم."

    # say L1810 bil
    old "We don’t have time for this. The teacher’s expecting us."
    new "وقت برای این نداریم. معلم منتظرمونه."

    # say L1813 pla
    old "Billie... Wait!"
    new "بیلی... صبر کن!"

    # say L1815 pla
    old "I- I don’t think I can do this."
    new "من فکر نمی‌کنم بتوانم اینو بکنم."

    # say L1816 bil
    old "Here we go again."
    new "بیا دوباره شروع کنیم."

    # say L1817 pla
    old "I mean it. I don’t feel ready. Not even close."
    new "من جدی هستم. حس نمی‌کنم آماده باشم. حتی نه."

    # say L1818 bil
    old "Come on! You’ve been practicing for days. You improved a ton."
    new "بیا! روزها تمرین کردی. خیلی بهتر شدی."

    # say L1819 pla
    old "Yeah, but only with you. Or at home. This is different. With the teacher... with pressure... I’m not ready."
    new "بله، ولی فقط با تو. یا در خونه. این جایی دیگه. با معلم... با فشار... من آماده نیستم."

    # say L1820 bil
    old "Relax, you don’t have to be perfect today."
    new "آرام، امروز نمی‌تونی کامل باشی."

    # say L1821 pla
    old "But I’m barely even good. What if I mess everything up?"
    new "ولی من حتی خوب هم نیستم. اگه همه چی رو اشتباه بکنم چیکار بکنم؟"

    # say L1822 bil
    old "Then you mess up. It happens."
    new "بعدش خراب می‌شه. اینجوری می‌شه."

    # say L1823 pla
    old "I don't know, Billie... maybe you should just do this one alone."
    new "نمی‌دونم، بیلی... شاید باید فقط تو اینو انجام بدی."

    # say L1824 bil
    old "Stop. You’re not backing out now."
    new "توقف. تو الان نمی‌تونی برگردونی."

    # say L1825 pla
    old "Billie... I really don’t think I can do this."
    new "بیلی... من واقعاً فکر نمی‌کنم بتونم اینو انجام بدم."

    # say L1826 bil
    old "Shut Up! I know you can. You’ve improved. A lot."
    new "بست! می‌دونم می‌تونی. تو پیشرفت کردی. خیلی."

    # say L1827 pla
    old "But what if I freeze? What if everything falls apart? What if—"
    new "ولی اگه یخ زنم؟ اگه همه چیز از دست بیافتد؟ اگه—"

    # say L1828 bil
    old "Okay, okay, breathe. You’re spiraling."
    new "باشه، باشه، نفس بکش. تو در حال گیج شدنی هستی."

    # say L1829 pla
    old "I- I don’t know... I feel like I’m gonna choke the moment she looks at me."
    new "من- من نمی‌دونم... حس می‌کنم وقتی به من نگاه کنه، تنگ نفس بشه."

    # say L1830 bil
    old "Look, standing here arguing isn’t helping either. Come with me."
    new "ببین، اینجا ایستادن و مناقشه کردن هم کمکی نمی‌کنه. بیا با من."

    # say L1831 pla
    old "What? W- where?"
    new "چی؟ ک- کجا؟"

    # say L1832 bil
    old "Somewhere quiet. You need to reset before we walk in there."
    new "مکان آرام. تو باید قبل از ورود آنجا بازنشسته شوی."

    # say L1855 pla
    old "The bathroom? [bil], what are we—"
    new "آشتوانه؟ ز[bil]، ما چه کاری—"

    # say L1856 bil
    old "Shh. Ok, i locked the door."
    new "ش ه. خب، من در رو بستم."

    # say L1857 pla
    old "Uhh, W- what? Why? We should be heading to class."
    new "اوه، چ- چه کاری؟ چرا؟ ما باید به کلاس بریم."

    # say L1858 bil
    old "Listen, you need to chill first. Watch."
    new "بیا، باید اول آرام شی. ببین."

    # say L1861 pla
    old "W- whoa! [bil]!"
    new "و- وای! [bil]!"

    # say L1862 bil
    old "There. Take a look."
    new "اینجا. ببین."

    # say L1863 pla
    old "I... Uh... they're... wow."
    new "من... اوه... آنها... وای."

    # say L1864 bil
    old "Heh. Does this help?"
    new "هه. این کمک می‌کنه؟"

    # say L1865 pla
    old "Kinda? But... this isn't about that."
    new "می‌تونه کمک کنه؟ اما... این به اون مربوط نیست."

    # say L1866 bil
    old "You can touch them if you want. Might relax you more."
    new "می‌تونی اگه بخوای بهشون لمس کنی. ممکنه تو رو آرامش بده."

    # say L1867 pla
    old "Hmm... to be honest, I don't think this is gonna help with the anxiety."
    new "Hmm... واقعاً فکر نمی‌کنم این اضطرابم رو کاهش بده."

    # say L1868 bil
    old "Really? Not even a little?"
    new "حقاً؟ حتی یه کم هم نمی‌تونه کمک کنه؟"

    # say L1869 pla
    old "I mean, I really like them, of course. But I'm still freaked about performing."
    new "من می‌گم، خیلی دوستشون دارم، البته. اما هنوز از اجرا نگرانم."

    # say L1870 bil
    old "Hmm. Okay, okay... Plan B then."
    new "Hmm. خب، خب... برنامه بی."

    # say L1871 pla
    old "Plan B?"
    new "پلن بی؟"

    # say L1872 bil
    old "Yeah. Something that always works."
    new "بله. چیزی که همیشه کار می‌کنه."

    # say L1879 pla
    old "Oh God, [bil]..."
    new "اوه خدا، [bil]..."

    # say L1880 bil
    old "Shh. Let me handle your stress."
    new "ش ها. بگذار من اضطرابت رو مدیریت کنم."

    # say L1881 pla
    old "This is crazy... but... don't stop."
    new "این جنونه... ولی... متوقف نشو."

    # say L1893 bil
    old "Told you. My methods are foolproof."
    new "بگفتم. روش‌های من همیشه کار می‌کنن."

    # say L1894 pla
    old "Phew... okay, nerves are gone. Mostly."
    new "پوف... خوب، اعصابم کمتر شد. بیشتر."

    # say L1895 bil
    old "Good. Now let's go before Bey bails on us."
    new "خوب. حالا برویم قبل از اینکه بی بی‌ها ما رو ترک کنند."

    # say L1896 pla
    old "Right. I'm ready now. I think."
    new "درست. حالا آماده‌ام. فکر کنم."

    # say L1897 bil
    old "You are. Come on."
    new "آماده‌ای. بیا."

    # say L1906 bey
    old "Oh! There you two are. I was about to leave."
    new "اوه! اینجا شما دو نفر هستید. من خواستم برم."

    # say L1907 bil
    old "Sorry. We had... a situation."
    new "ببخشید. ما... یک وضعیت داشتیم."

    # say L1909 bey
    old "A situation?"
    new "یک وضعیت؟"

    # say L1910 bil
    old "Stage panic. I had to calm him down with... a technique that always works."
    new "پنیک صحنه بود. باید با یک تکنیکی که همیشه کار می‌کنه، او رو آرام کردم."

    # say L1911 bey
    old "Oh! Well, whatever you did, I’m glad it helped. Next time, bring him here, I have plenty of ways to help with anxiety too."
    new "اوه! خب، هر چه کردی خوشحالم که کمک کرد. بار بعدش رو اینجا بیاور، من هم راه‌های زیادی برای کم کردن اضطراب دارم."

    # say L1912 bil
    old "Don’t worry. I have a method that works every time."
    new "نگران نباش. من روشی هستم که همیشه کار می‌کنه."

    # say L1914 bey
    old "Well, as long as he’s fine now."
    new "البته، مادامچه حالا خوبه."

    # say L1915 pla
    old "I... think so."
    new "من... فکر کنم همینطور."

    # say L1916 bey
    old "Good. Now tell me, how have you two been? Practicing together?"
    new "خوب. حالا بگو، شما دو تا چطور هستید؟ با هم تمرین می‌کنید؟"

    # say L1917 bil
    old "A lot. He’s been improving faster than I expected."
    new "خیلی. او سریعتر از آنچه منتظرش بودم پیشرفت کرده."

    # say L1918 bey
    old "Really? That’s wonderful."
    new "وای، خوبه."

    # say L1919 pla
    old "Uhh, actually, I’m still not that great."
    new "اوه، در واقع هنوز خیلی خوب نیستم."

    # say L1920 bey
    old "No one expects you to be. What matters is progress."
    new "هیچ‌کس ازت انتظار نمی‌ره. مهم اینه که پیشرفت کنی."

    # say L1921 bil
    old "He’s now supporting me with guitar for the performance."
    new "او حالا داره با گیتار منو در اجرای زنده حمایت می‌کنه."

    # say L1922 bey
    old "Ah! Excellent idea. Your voice with live accompaniment gives the duet a lot of potential."
    new "آه! ایده خوبیه. صدایت با همراهی زنده برای دوگانه امکان‌های زیادی می‌دهه."

    # say L1923 bil
    old "Yeah, that’s the plan."
    new "بله، همین طرحه."

    # say L1924 bey
    old "Alright then, let’s hear you. Perform as if it were the actual contest. After that, I’ll give you both feedback."
    new "خب، در اون صورت بیا، بگو. مثل اینکه واقعاً در مسابقه هستی. بعد از اون، من به هر دو تون بازخورد می‌دم."

    # say L1926 pla
    old "O-okay..."
    new "ب-b-b خوب..."

    # say L1927 pla
    old "({i}No pressure... no pressure...{/i})"
    new "{i}فشار نداره... فشار نداره...{/i}"

    # say L1936 bey
    old "Okay! Why don’t we do this like a mock presentation?"
    new "باشه! چرا ما این رو مثل یه ارائه آزمایشی انجام بدیم؟"

    # say L1938 bey
    old "Imagine you’re already on stage at the contest. Perform the piece you’ve been working on."
    new "به نظرت روی صحنه مسابقه هستی. قطعه‌ای که تمرین کردی رو اجرا کن."

    # say L1940 bil
    old "Don’t start panicking again. Just do what we’ve practiced."
    new "دیوونه نشین دوباره. فقط همون کاری که تمرین کردیم بکن."

    # say L1941 pla
    old "{i}Right... right.{/i}"
    new "{i}درست... درست.{/i}"

    # say L1975 bey
    old "Wow. That was genuinely impressive."
    new "واو. این واقعاً عالی بود."

    # say L1977 bey
    old "Absolutely. You two have grown a lot."
    new "حتماً. شما دو تا خیلی رشد کرده‌اید."

    # say L1978 bey
    old "[pla]... last time you barely moved. You were like a decorative tree."
    new "[pla]... آخرین بار که هارد می‌کردی، تقریباً حرکتی نمی‌کردی. مثل یه درخت زیوری بودی."

    # say L1979 pla
    old "Uhh... ok."
    new "اوه... خوب."

    # say L1980 bey
    old "This time you actually you played. And with feeling. I’m proud of that."
    new "این بار واقعاً بازی کردی. و با احساس. از این خوشحالم."

    # say L1981 bey
    old "You still get nervous, and it shows in your transitions. A few spots were shaky."
    new "هنوز ناراحتی داری و این در تغییراتت مشخص است. چند جا ناپایدار بود."

    # say L1983 bey
    old "It’s normal. With more practice you'll smooth it out. If you want, you can come to extra sessions with me. I can help strengthen your hand technique."
    new "این طبیعیه. با تمرین بیشتر این مشکلات رفع می‌شن. اگه خواستی می‌تونی جلسات اضافی با من بیاد. می‌تونم تکنیک دستت رو قوی‌تر کنم."

    # say L1984 bil
    old "No need. I’ve already got him on a very effective practice."
    new "نیازی ندارم. من قراره با او تمرین‌های خیلی موثری انجام بدم."

    # say L1985 bey
    old "Oh! Great. If it works, keep doing it. You two clearly connect well."
    new "اوه! عالی. اگر کار می‌کنه، همینجور ادامه بده. شما دو تا هم‌آهنگی خوبی دارید."

    # say L1986 bey
    old "Now, Billie. As always your voice is beautiful. Rich tone, controlled color, great emotional delivery."
    new "بیلی، همیشه صداتون زیباه. تون زنده، رنگ کنترل شده، و ارسال عاطفی خوبی داره."

    # say L1988 bey
    old "However, there’s room to grow. You rely a bit too much on natural skill."
    new "البته، اما هنوز جایی برای رشد وجود داره. شما کمی زیاد به توانایی‌های طبیعی خودت تکیه می‌کنی."

    # say L1989 bey
    old "We need to work on technique, breath support, especially sustaining phrases without losing power."
    new "بایلی، ما باید روی تکنیک، پشتیبانی نفس و به‌ویژه حفظ قدرت در طول عبارات کار کنیم."

    # say L1990 bey
    old "Your diaphragm engagement is good, but not consistent. With proper training, your projection and stability will improve a lot."
    new "انگام دیافراگمتو خوبه، ولی همیشه ثابت نیست. با آموزش مناسب، صداتو و پایداریت خیلی بهتر می‌شه."

    # say L1991 bil
    old "Oh, ok..."
    new "اوه، خب..."

    # say L1992 bey
    old "I’d love to train that with you. Come for vocal sessions, and we’ll shape your sound for the contest."
    new "می‌خوام اینو با تو آموزش بدم. بیا جلسات صدایی رو باهام بگذاریم، و صداتو برای مسابقه شکل بدیم."

    # say L1993 bey
    old "Just you and me. We’ll polish your technique and make sure you’re ready for the real contest."
    new "فقط تو و من. تکنیکت رو پاکیزه خواهیم کرد و مطمئن می‌شویم که برای مسابقه واقعی آماده باشی."

    # say L1994 bil
    old "Sounds good. I’m in."
    new "خوبه. من هم می‌آیم."

    # say L1995 bey
    old "Perfect. And [pla], keep practicing with Billie. You two work wonderfully together."
    new "عالی. و [pla]، با بیلی هم تمرین کن. شما دو تا با هم عالی هستید."

    # say L1996 pla
    old "We will."
    new "خواهیم کرد."

    # say L1997 bil
    old "Oh, trust me... We definitely will."
    new "بیا، باور کن... حتماً خواهیم کرد."

    # say L1998 bey
    old "You both have something special together."
    new "شما دو نفر با هم چیز خاصی دارید."

    # say L1999 bey
    old "Keep up the rhythm. I’ll call you both again for another evaluation soon."
    new "نوسان رو حفظ کنید. به زودی دوباره از شما هر دو برای ارزیابی بعدی خواهم خواست."

    # say L2000 bil
    old "Thank you for everything."
    new "ممنون از همه چیز."

    # say L2016 ari
    old "Well, well... look who actually survived a real practice session."
    new "خب خب... ببینم چه کسی واقعاً جلسه تمرین واقعی رو سالم گذرانده."

    # say L2017 tay
    old "We heard you two through the wall. That was... almost not terrible. Hahaha"
    new "دیوار از صدای شما دو تا سرباز شد. این هم خوب نبود، ولی تقریباً بد نبود. هahaha"

    # say L2019 bil
    old "Heh. Almost?"
    new "هه. تقریباً؟"

    # say L2020 ari
    old "Your breath control still wavers on the sustain, sweetie. Fix it or you’ll crack on stage."
    new "تنفس هنوز در حفظ تعادل نیست، عزیزم. این مشکل رو حل کن یا روی صحنه خواهی پرید."

    # say L2021 tay
    old "And you, [pla]... congrats on finally moving. You’re only half a statue now."
    new "و تو، [pla]... مبروک برای اینکه بالاخره حرکت کردی. حالا فقط نیمه‌آهنگی هستی."

    # say L2022 pla
    old "Thanks... I think?"
    new "ممنون... فکر کنم؟"

    # say L2023 bil
    old "Keep taking notes, girls. We’re just warming up."
    new "دست‌نوشته‌ها رو همچین ادامه بده، دختران. همین الان گرم شونده‌ایم."

    # say L2024 ari
    old "Please. Technique beats 'raw emotion' every single time."
    new "لطفاً. تکنیک همیشه احساسات خام رو شکست می‌ده."

    # say L2026 tay
    old "See you at the contest... try not to choke when it actually counts."
    new "در مسابقه بهت می‌بینم... حواست رو نگه داشت وقتی واقعاً مهمه."

    # say L2032 pla
    old "They’re still exactly the same, huh?"
    new "همه هنوز هم مثل همین هستند، دی؟"

    # say L2033 bil
    old "Perfect. Makes crushing them way more satisfying."
    new "پرفکت. شکستن اونا خیلی لذت‌بخش‌تره."

    # say L2040 bil
    old "Okay... I have to admit, that went better than I expected."
    new "باشه... باید بگم، این بهتر از آنچه منتظرش بودم شد."

    # say L2041 pla
    old "Way better. I didn’t completely freeze."
    new "خیلی بهتر. هیچ جور متوقف نشدم."

    # say L2042 bil
    old "Wow, what an achievement. Should we throw you a parade?"
    new "وای، چه دستاوردی. باید برایت جشن بگذاریم؟"

    # say L2043 pla
    old "Hey, for me that’s huge."
    new "بله، برای من این خیلی مهمه."

    # say L2044 bil
    old "Yeah... it kinda is."
    new "بله... همینطوره."

    # say L2045 pla
    old "Seriously, thanks for earlier. Uhh, you know."
    new "ممنونم، براتون خیلی مهم بود. اوه، می‌دونی."

    # say L2046 pla
    old "If you hadn’t helped me calm down, I would’ve messed everything up."
    new "اگه تو نمی‌تونستی من رو آرامش بدی، همه چی رو از دست بیرون می‌دادم."

    # say L2047 bil
    old "I know."
    new "من می‌دونم."

    # say L2048 bil
    old "You owe me one."
    new "باید به من بدهی."

    # say L2049 pla
    old "Actually, more than one. I mean it."
    new "در واقع بیش از یکی. من جدی هستم."

    # say L2050 bil
    old "Relax. You did the hard part. You didn’t run away."
    new "آرام. تو قسمت سخت رو انجام دادی. نگریستی گریختن."

    # say L2051 pla
    old "Heh, I almost did."
    new "حی، تقریباً گریختم."

    # say L2052 bil
    old "And I almost slapped you. Balance."
    new "و من هم تقریباً تو رو خوردم. تعادل."

    # say L2053 pla
    old "Still... I’m glad you didn’t let me quit."
    new "همه‌چی... خوشحالم که نتونستی اجازه بدی برم."

    # say L2054 bil
    old "Good. Because you’re way more useful when you don’t panic every five seconds."
    new "خوبه. چون وقتی هر پنج ثانیه از کنار می‌ری، خیلی کمکی نمی‌کنی."

    # say L2055 pla
    old "I’m working on that."
    new "من روی اون کار می‌کنم."

    # say L2056 bil
    old "And you’re getting better. With the guitar. With the nerves. With everything."
    new "و تو در حال بهتر شدنی هستی. با گیتار. با اعصاب. با همه چیز."

    # say L2057 pla
    old "You really think so?"
    new "وای، واقعاً همینطور فکر می‌کنی؟"

    # say L2058 bil
    old "Don’t get cocky. But yeah... you’re not useless anymore."
    new "نفرت نکن. ولی بله... دیگه بی‌فاید نیستی."

    # say L2059 pla
    old "Haha, that’s the nicest thing you’ve ever said to me."
    new "هه، این بهترین چیزیه که تا حالا به من گفتی."

    # say L2060 bil
    old "Don’t get used to it."
    new "بیا خوشحال نشی. اما همینه، نمی‌تونی بگی که بی‌فایدهی."

    # say L2061 pla
    old "So... what now?"
    new "پس... الان چه کاری می‌کنیم؟"

    # say L2062 bil
    old "Now we keep practicing. You, with the guitar. Me, with the teacher."
    new "الان ما تمرین می‌کنیم. تو با گیتار. من با معلم."

    # say L2063 bil
    old "And together... We make this thing actually work."
    new "و با هم... این کار رو واقعاً کار کنیم."

    # say L2064 pla
    old "Deal."
    new "توپرمیش."

    # say L2067 bil
    old "Alright, it’s getting late. Go home before you turn into a pumpkin."
    new "خوب، وقت شده. برو خونه قبل از اینکه به خربزه تبدیل بشی."

    # say L2068 pla
    old "Yeah, I should. But... thanks again. For everything."
    new "بله، باید برم. اما... ممنون دوباره. از همه."

    # say L2069 bil
    old "Yeah, yeah. Just don’t waste what we started."
    new "بله، بله. فقط این کار رو از دست نده."

    # say L2070 pla
    old "I won’t. I promise."
    new "من نمی‌کنم. وعده می‌دهم."

    # say L2072 pla
    old "See you soon."
    new "به زودی می‌بینم تو را."

    # say L2092 bil
    old "Finally. You're here."
    new "اینها. اینجا هستی."

    # say L2093 pla
    old "Yeah, your text said it was urgent. What's up?"
    new "بله، پیامتو گذاشتی که اونقدر ضروریه. چه خبر؟"

    # say L2094 bil
    old "Well, I've been in lessons with the teacher. It's going okay, but I need your help with something."
    new "خب، من درس‌ها رو با معلم داشتم. خوب می‌ری، ولی به چیزی نیاز دارم که باید بهم کمک کنی."

    # say L2095 pla
    old "Do you need my help?"
    new "می‌تونم کمکت کنم؟"

    # say L2096 bil
    old "Better talk in my room. Come on."
    new "بهتره در اتاقم صحبت کنیم. بیا."

    # say L2103 bil
    old "Alright, so, those vocal sessions with Bey were way tougher than I expected."
    new "البته، اون جلسات صدایی با بی هم خیلی سخت‌تر از آنچه فکر می‌کردم بودند."

    # say L2104 pla
    old "'Tougher' for you? Seriously?"
    new "برای تو سخت‌تر بود؟ جدی؟"

    # say L2105 bil
    old "Yeah, I mean, I have the talent, sure. But I haven't practiced consistently in years."
    new "بله، منظورم اینه که موهبتون رو دارم، البته. ولی سال‌ها هم نهاده‌ای پیوسته نکردم."

    # say L2106 bil
    old "I lost some edge on breath control, especially under pressure."
    new "من برخی از تسلط رو در کنترل نفس از دست دادم، خصوصاً وقتی تحت فشار هستم."

    # say L2107 bil
    old "Like, when nerves hit or heart rate spikes, my voice shakes. So, I can't sustain some notes without cracking."
    new "مثلاً وقتی عصبانی می‌شوم یا ضربان قلبم بالا می‌رود، صدایم لرزه. پس نمی‌توانم برخی نت‌ها را بدون خراب شدن حفظ کنم."

    # say L2108 pla
    old "That sounds rough. What does the teacher say?"
    new "این خوب نیست. معلم چه می‌گه؟"

    # say L2109 bil
    old "She's got me on diaphragmatic breathing deep belly breaths to stabilize. And box breathing: inhale four, hold four, exhale four, hold four."
    new "او منو برای تنفس از دیافراگم و تنفس عمیق شکمی آموزش می‌ده تا ثبات بیاورم. و تنفس مربع هم: خوردن چهار، نگه داشتن چهار، خروج چهار، نگه داشتن چهار."

    # say L2110 bil
    old "Helps calm the nervous system, reduces anxiety. But it's not enough for real stage stress."
    new "سیستم عصبی رو آرام می‌کنه، اضطراب رو کاهش می‌ده. ولی برای استرس صحنه کافی نیست."

    # say L2111 pla
    old "Stage stress? Like performance anxiety?"
    new "استرس صحنه؟ مثل اضطراب عملکرد؟"

    # say L2112 bil
    old "Exactly. Heart pounding, shallow breaths... Voice goes to shit. Need to practice holding technique when everything's agitated."
    new "دقیق هست. قلب تپ می‌کنه، نفس‌های کوتاه می‌شه... صدایم خراب می‌شه. باید تکنیک‌های نگه‌داشتن رو وقتی که همه چیز اضطراب‌ده هست، تمرین کنم."

    # say L2113 pla
    old "Ohh, like exercises while running or something?"
    new "اوه، مثل تمرین‌ها وقتی دو می‌دی؟"

    # say L2114 bil
    old "Hmm, kinda. I already tried that stuff. Jogging while singing, high-heart-rate drills... even picturing the crowd without freaking out."
    new "همم، نوعاً. اون جور چیزایی قبلاً امتحان کردم. در حال دویدن آواز خواندن، تمریناتی با ضربان قلب بالا... حتی تصور کردن جمع بدون اینکه پریشان شوم."

    # say L2115 bil
    old "Progress is slow. With the contest coming, traditional stuff won't cut it."
    new "پیشرفت آهسته است. با مسابقه که نزدیک شده، روش‌های سنتی کافی نیستند."

    # say L2116 pla
    old "Damn. So what's the plan?"
    new "شیطان! پس برنامه‌ت چیه؟"

    # say L2117 bil
    old "Well, I've been researching some non-traditional stuff. Found training under extreme stimulation to build resilience."
    new "خب، من چند روش غیر سنتی پیدا کردم. تمرین تحت تحریک شدید برای افزایش مقاومت."

    # say L2118 pla
    old "Like... What kind?"
    new "مثل... چه نوع؟"

    # say L2119 bil
    old "Ways to spike heart rate and nerves, but controlled. Make the body adapt to singing through it."
    new "روش‌هایی برای افزایش نرخ ضربان قلب و تحریک عصبی، اما تحت کنترل. بدن رو آماده کنم تا از طریق آن خواندن بیاموزم."

    # say L2121 bil
    old "Anyway, the thing is I need you, because I wanna practice vocals under some strong stimulation. You know, to simulate the pressure."
    new "البته، من نیاز دارم تو کمکت کنی، چون می‌خوام آواز خودمو تحت تحریک‌های قوی تمرین کنم. مثلاً برای شبیه‌سازی فشار."

    # say L2122 pla
    old "Strong stimulation? Like... Distracting you?"
    new "استیمیل قوی؟ مثل... اینکه توجهت رو پرتونی؟"

    # say L2123 bil
    old "Why do you have to be so slow sometimes?"
    new "چرا گاهی اوقات اینقدر آهسته هستی؟"

    # say L2124 pla
    old "Uh?"
    new "اوه؟"

    # say L2125 bil
    old "Listen, I need my heart racing and my body all tense while I'm practicing singing."
    new "بله، من نیاز دارم قلبم تپش بیشتر کنه و بدنم خیلی تنیده باشه وقتی آواز می‌خوانم."

    # say L2126 pla
    old "Still not following..."
    new "هنوز متوجه نشدم..."

    # say L2127 bil
    old "Ughh. I need you to stimulate me... sexually. While I sing."
    new "اوه. نیاز دارم تو مرا تحریک کنی... جنسی. وقتی من آواز می‌خوانم."

    # say L2128 pla
    old "Ohhhh..."
    new "اوه هه هه..."

    # say L2129 bil
    old "Yeah, it's not orthodox, but time's short. And hey, I've helped you with 'non-traditional' methods before."
    new "بله، این روش استاندارد نیست، ولی وقت کم است. و بله، قبلاً هم با روش‌های «غیر سنتی» به تو کمک کرده‌ام."

    # say L2130 bil
    old "You owe me a few, remember?"
    new "باید چند تا به من بدهی، یادت رفته؟"

    # say L2131 pla
    old "Well, that’s... fair, I guess."
    new "خب، این جوری منصفانه است، حدس می‌زنم."

    # say L2132 bil
    old "But, I mean, I’m not saying you’re obligated."
    new "اما من قصد ندارم بگم تو باید."

    # say L2133 bil
    old "I’m saying this could actually help me control my voice when everything inside me is going wild."
    new "من می‌گم این می‌تونه به من کمک کنه صدایم رو کنترل کنم وقتی همه چیز داخلم در حال خروج از کنترل هست."

    # say L2134 pla
    old "And you really think this will work?"
    new "و تو واقعاً فکر می‌کنی این کار خوبه؟"

    # say L2135 bil
    old "Well, I’m not doing it just for fun."
    new "خب، من فقط برای لذت نمی‌کنم."

    # say L2136 bil
    old "Okay, maybe a little."
    new "خب، شاید یه کم."

    # say L2137 pla
    old "Heh. Alright, if you’re serious, then... Yeah. I’ll help."
    new "هه. خوب، اگه جدی هستی، درسته... بله. کمکت می‌کنم."

    # say L2139 pla
    old "You helped me when I was stuck. If this is what you need, I’m in."
    new "تو وقتی گیر افتادی به من کمک کردی. اگه این همچین کاریه که می‌خوای، من هستم."

    # say L2141 bil
    old "If you’re going to help, we’ll treat this like real training."
    new "اگه قراره کمک کنی، اینو مثل تمرین واقعی در نظر بگیریم."

    # say L2142 pla
    old "Alright... So what exactly am I supposed to do?"
    new "باشه... پس من دقیقاً چی کاری باید بکنم؟"

    # say L2143 bil
    old "Ok, first, you follow my lead."
    new "اول، باید از من جلو بری."

    # say L2144 bil
    old "Second, you don’t overthink it."
    new "دوم، نفکر زیاد نکن."

    # say L2145 bil
    old "Third, remember the goal: I have to keep singing no matter what I’m feeling."
    new "سوم، هدف رو به یاد بدار: من باید بدون اینکه چه حسی داشته باشم، ادامه دهم خواندن."

    # say L2146 pla
    old "Got it. You sing, I... create the distraction."
    new "فهمیدم. تو خواندی، من... ایجاد تنش می‌کنم."

    # say L2147 bil
    old "Yeah. If we do this right, my voice should stays steady even when everything else is falling apart."
    new "بله. اگر این کار رو درست انجام بدیم، صدایم حتی وقتی همه چیز از هم می‌افتد، ثابت می‌مونه."

    # say L2148 pla
    old "Alright, I'm in. Just tell me exactly what you need, and I'll handle it."
    new "باشه، من هستم. فقط بگو دقیقاً چی کاری می‌خوای، من اون رو انجام می‌دم."

    # say L2149 bil
    old "Ok, first let me get ready..."
    new "باشه، اول باید آماده شم..."

    # say L2153 bil
    old "Do you like what you see? Heh?"
    new "می‌پسندی چه می‌بینی؟ هه؟"

    # say L2158 bil
    old "What about now?"
    new "الان چطور می‌بینی؟"

    # say L2159 pla
    old "Holy... fuck..."
    new "هیلی... شیطون..."

    # say L2160 bil
    old "No reason we both can't benefit from this 'practice', right?"
    new "هیچ دلیلی نداریم که هر دو از این «تمرین» بهره‌بردگی نکنیم، درسته؟"

    # say L2161 bil
    old "Heh. Still takes your breath away every time, huh?"
    new "هه. هر بار هم نفست رو می‌بره، هuh؟"

    # say L2162 bil
    old "Perfect. Means you're properly motivated."
    new "پرفکت. این به معنای اینه که خودتو به درستی انگیزه‌بخش کردی."

    # say L2163 bil
    old "Now that you're all fired up... let me get comfortable."
    new "الان که همه‌ت روشن شد... من راحت بشم."

    # say L2164 bil
    old "Now lie down on the floor before you pass out staring."
    new "الان روی زمین دراز شو قبل از اینکه با چشم‌های باز خودت رو از دست بدهی."

    # say L2165 pla
    old "Uhh, a- alright..."
    new "اوه، خب، ا- اونجوره..."

    # say L2169 bil
    old "Perfect."
    new "خوبه."

    # say L2173 bil
    old "Your job: stimulate me as hard as you can. Mine: keep breath controlled, sustain notes, hold pitch no matter what."
    new "وظیفه‌تو اینه که من رو به قدر ممکن سخت تحریک کنی. وظیفه‌من اینه که نفس رو در کنترل داشته باشم، نت‌ها رو حفظ کنم و صدایم رو ثابت نگه دارم، هر چه بیوفت."

    # say L2174 pla
    old "Got it. Let's do this."
    new "فهمیدم. بیای، انجام بدیم."

    # say L2186 bil
    old "Phew... that was intense."
    new "پوف... این خیلی شدید بود."

    # say L2187 pla
    old "Yeah... did it actually work?"
    new "بله... واقعاً کار کرد؟"

    # say L2188 bil
    old "Big time. I could feel the control improving even as everything else was going crazy."
    new "بله، خیلی خوب کار کرد. حتی وقتی همه چیز در حال خراب شدن بود، حس کردم کنترل بهبود پیدا می‌کنه."

    # say L2189 bil
    old "Voice held up better than I expected... but yeah, I'm definitely gonna need more of this."
    new "صدا بهتر از آنچه انتظار داشتم، پابرجا موند... ولی بله، قطعاً به بیشتری از این نیاز دارم."

    # say L2190 bil
    old "A lot more practice before the stage doesn't wreck me."
    new "حتماً باید خیلی بیشتر تمرین کنم تا صحنه‌ها من رو نابامان نکنند."

    # say L2191 pla
    old "Uhh, if you need it, I'm down to keep helping. Same way you've been helping me."
    new "اوه، اگه نیازت هست، من آماده‌ام کمکت کنم. مثل همین که تو هم به من کمک می‌کنی."

    # say L2192 pla
    old "You know... with the 'advanced practice' and all."
    new "می‌دونی... با همین «تمرین پیشرفته» و همه چیز."

    # say L2193 bil
    old "Oh, I get it."
    new "اوه، متوجه شدم."

    # say L2194 bil
    old "Heh. Tit for tat, huh? Fair enough."
    new "هه. چشم برای چشم، هuh؟ منصفانه."

    # say L2195 bil
    old "Deal. You keep me steady under pressure... I'll keep those fingers of yours 'motivated'."
    new "توافق. تو منو زیر فشار ثابت می‌سازی... من اون انگشت‌هایت رو انگیزه‌بخش می‌کنم."

    # say L2196 bil
    old "We're both getting better this way. Win-win."
    new "هر دو ما اینجوری بهتر می‌شیم. دو برابر."

    # say L2197 pla
    old "Exactly. Looking forward to it."
    new "دقیقاً. منتظرش هستم."

    # say L2198 bil
    old "Alright, perv. Now seriously, get out before grandma shows up and smells the trouble."
    new "باشه، خودسوز. حالا جدی شو، بیرون برو قبل از اینکه بابا می‌آید و مشکل رو حس کنه."

    # say L2199 pla
    old "On my way. See you soon... for more 'practice'."
    new "در مسیرم. تا زودی می‌بینیم... برای تمرین بیشتر."

    # say L2200 bil
    old "You better. Don't slack on that guitar either."
    new "باید همین‌طور باشی. گیتارت هم نفکر کن."

    # say L2201 pla
    old "Wouldn't dream of it."
    new "فکر نمی‌کنم بی‌انگیز باشم."

    # say L2220 bil
    old "Wow, you’re on time. That’s new."
    new "وای، خوبه که وقتی هستی. این جدیده."

    # say L2221 pla
    old "Yeah... I made sure to wake up early today. Been doing extra practice every day. Feeling ready for whatever comes today."
    new "بله... امروز قطعاً زودتر بیدار شدم. هر روز تمرین بیشتری می‌کنم. برای هر چیزی که امروز پیش می‌یاد آماده‌ام."

    # say L2222 bil
    old "Wow. Actual growth. Who would’ve thought?"
    new "واو. رشد واقعی. چه کسی فکر می‌کرد؟"

    # say L2223 bil
    old "So? No panic attack today?"
    new "پس؟ امروز هیچ حمله پانیکی نداری؟"

    # say L2224 pla
    old "A little butterflies, sure... but I'm fine. We've got this."
    new "بله، یه کم لوله‌ای هست... اما خوبم. ما اینو در اختیار داریم."

    # say L2225 bil
    old "Look at you. All grown up."
    new "bebین تو. کاملاً بزرگ شدی."

    # say L2226 pla
    old "Yeah. I trust what we’ve practiced."
    new "بله. من بر این اعتماد دارم که تمرین کرده‌ایم."

    # say L2227 bil
    old "Good. Because today is just about showing what we can already do."
    new "خوب. چون امروز فقط می‌خوایم نشون بدیم چی می‌تونیم بکنیم."

    # say L2228 bil
    old "No panic, no drama."
    new "نگرانی نداشته باش، هیچ درامایی نباشد."

    # say L2229 pla
    old "I'll try to keep the drama to a minimum."
    new "سعی می‌کنم تا درامایی رو به حداقل برسونم."

    # say L2230 bil
    old "Do that and I might even be proud of you."
    new "اگه اینجوری کنی، شاید حتی افتخارت بکنم."

    # say L2231 pla
    old "High honor."
    new "این افتخار بزرگی است."

    # say L2242 sha
    old "Darlings! Look who we found!"
    new "حبابی! ببینید چه کسی را پیدا کردیم!"

    # say L2243 rya
    old "We just finished our private session with Bey. Absolute perfection!"
    new "ما همین الان جلسه خصوصیمون با بی اتمام شد. کامل و بدون هیچ اشکالی!"

    # say L2244 sha
    old "The choreography, the lighting cues, the costume changes... we have a full Broadway production ready, honey!"
    new "شادی، نورپردازی، تغییر لباس‌ها... ما یک تئاتر برودوی کامل آماده‌یم، عزیزم!"

    # say L2245 rya
    old "Everything planned down to the last sparkle. The crowd is going to lose their minds!"
    new "هر چیزی تا آخرین برق جوش برنامه‌ریزی شده. مخاطبان خودشون رو از دست برمی‌دن!"

    # say L2247 bil
    old "Great for you."
    new "عالی برای تو."

    # say L2248 sha
    old "Oh, look at their little faces. So serious. So... scared."
    new "اوه، نگاه کن به چهره‌های کوچولویشون. خیلی جدی هستن. خیلی... وحشت زده."

    # say L2249 rya
    old "It’s adorable, really. Like two lost puppies trying to play with the big dogs."
    new "این خیلی لطیف است، واقعاً. مثل دو سگ کوچولو که می‌خواهند با سگ‌های بزرگ بازی کنند."

    # say L2250 sha
    old "You two still look like you’re auditioning for your very first school play."
    new "شما دو تا هنوز مثل این هستید که برای نخستین نمایش مدرسه آزمون داده‌اید."

    # say L2251 rya
    old "While we just delivered a show stopping number that will make people stand up and cheer."
    new "ما فقط یک شماره‌ی باورنکردنی ارائه کردیم که مردم برایش بلند می‌شوند و تشویق می‌کنند."

    # say L2252 bil
    old "Keep talking, Sparkle Twins."
    new "بگو بیشتر، دو تا ستاره کوچک."

    # say L2253 sha
    old "Cute. Very cute. The underdogs always have that fighting spirit."
    new "لطف داره. خیلی لطف داره. همیشه اون روح مبارزه رو دارن."

    # say L2254 rya
    old "Good luck in there, sweethearts. Try not to faint from all the pressure."
    new "شانس خوبی داشته باشید، عزیزم. سعی کنید از فشار زیاد نیندست."

    # say L2255 sha
    old "Ta-ta, lovebirds! The stage belongs to the stars... not the scared little duo."
    new "بای‌بای، عاشقانه‌ها! صحنه برای ستارگان است... نه برای جفت ترسناک کوچک."

    # say L2263 bil
    old "Ughh... I hate those two so much."
    new "اوه... من اون دو تا رو خیلی می‌نفرتم."

    # say L2264 pla
    old "They really know how to get under your skin..."
    new "وای، اونا واقعاً می‌دونن چطور باعث خستگی تو بشه..."

    # say L2265 bil
    old "Good. Let’s use that anger. Time to show Bey what we can really do."
    new "خوب. بیاین از اون خشم استفاده کنیم. وقت برای نشون دادن به بی همچه چی می‌تونیم انجام بدیم رسیده."

    # say L2274 bey
    old "There you are already! Early today, I wasn’t expecting you two so soon."
    new "اینجا هستید! امروز زود هست، منتظرتون نبودم."

    # say L2275 bil
    old "This time we didn't wanna show up late like last session."
    new "این بار نمی‌خواستیم مثل جلسه گذشته تأخیر کنیم."

    # say L2276 pla
    old "Yeah, sorry if we’re a little early this time."
    new "بله، اگه کمی زود هستیم، معذرت."

    # say L2277 bey
    old "That’s a good problem to have. Gives us extra time to really dig in."
    new "این مشکل خوبیه. وقت بیشتری برای ما می‌تونه درست کنه تا واقعاً عمیق شیم."

    # say L2278 bey
    old "So, this is our last tutoring session before the contest."
    new "پس، این آخرین جلسه‌ی آموزشیمون قبل از مسابقه هست."

    # say L2279 bey
    old "How are you both feeling?"
    new "حالتون چطوره؟"

    # say L2280 bil
    old "Ready."
    new "آماده."

    # say L2281 pla
    old "Nervous... but ready."
    new "نرسیده... ولی آماده."

    # say L2282 bey
    old "That’s exactly how you should feel."
    new "این همینه که باید حس کنی."

    # say L2283 bey
    old "Alright, let’s do this like before."
    new "بیای، مثل قبل انجام بدی."

    # say L2284 bey
    old "Perform as if you were already on stage at the contest."
    new "بیا، مثل اینکه قراره روی صحنه رقابت باشی، انجام بده."

    # say L2286 pla
    old "Alright... let’s go."
    new "باشه... برویم."

    # say L2319 bey
    old "Wow."
    new "واو."

    # say L2320 bil
    old "Is that a good ‘wow’ or...?"
    new "این یه «واو» خوبه یا...؟"

    # say L2321 bey
    old "Oh honey, it’s a ‘hell yes’ wow!"
    new "عسلانم، این یه «بله خدا» هست!"

    # say L2322 bey
    old "This is night and day from your audition. Completely different level."
    new "این از آزمون صدات کاملاً متفاوته. سطح کاملاً متفاوتیه."

    # say L2323 bey
    old "[pla], look at you!"
    new "[pla]، نگاهت به تو!"

    # say L2324 pla
    old "Me?"
    new "من؟"

    # say L2325 bey
    old "From that quiet little tree in the audition to actually carrying the whole song with her!"
    new "از آن درخت کوچک و خاموش در اودیشن تا حالا که واقعاً تمام آهنگ رو حمل و نقل می‌کنی!"

    # say L2326 bey
    old "Your chords are locking in perfectly now, your rhythm is steady, and you’re breathing with Billie like you were born to do this."
    new "حالا آهنگت به درستی قفل شده، ریتمت ثابت است، و مثل اینکه برای این متولد شده‌ای، با بیلی نفس می‌کشی."

    # say L2327 bey
    old "You’re not just following anymore... you’re complementing her. You’re making her voice shine even brighter."
    new "تو فقط دیگه دنبال کننده نیستی... تو همنواییش رو تقویت می‌کنی. صدایش رو حتی درخشان‌تر می‌کنی."

    # say L2328 pla
    old "For real? That actually worked?"
    new "وای، واقعاً کار کرد؟"

    # say L2329 bey
    old "Yes! You two are finally sounding like a real duo."
    new "بله! شما دو تا حالا مثل یک جفت واقعی هستید."

    # say L2330 bey
    old "And Billie... that breath control? Chef’s kiss."
    new "و بیلی... اون کنترل نفس؟ قبلاً بوسه شفیق."

    # say L2332 bey
    old "Absolutely. Way more power behind those soft notes. You’re letting that voice breathe."
    new "حتماً. صدایت الان قدرت بیشتری داره، حتی وقتی نوت‌های نرم رو می‌خونی. صداتت فرصت می‌ده تا تنفس کنه."

    # say L2333 bey
    old "Your breath support is stronger, and you’re keeping your tone stable even in longer phrases."
    new "تنفست قوی‌تر شده و حتی در عبارات طولانی‌تر نغشت را ثابت نگه می‌داری."

    # say L2334 bey
    old "You’re managing your diaphragm much more consciously now."
    new "حالا از دیافراگمت استفاده می‌کنی پیشرفته‌تر."

    # say L2335 bil
    old "That’s... really good to hear."
    new "این خبر خوبه."

    # say L2336 bey
    old "You both sound like a team now."
    new "حالا هر دو مثل یک تیم صدا می‌دهید."

    # say L2337 bey
    old "Not just two people doing their own thing, but one performance."
    new "نه فقط دو نفر که هر کدوم چیزی می‌کنن، بلکه یه اجرا در یه جا."

    # say L2338 bil
    old "That’s what we were aiming for."
    new "این همین هدفمون بود."

    # say L2340 bey
    old "Well, I think you’re ready for the contest."
    new "خب، فکر می‌کنم آماده‌ی مسابقه هستی."

    # say L2341 bil
    old "You mean... really ready?"
    new "منظورت اینه که واقعاً آماده‌ی؟"

    # say L2342 bey
    old "Yes. You should keep practicing, of course."
    new "بله. البته باید تمرینت رو ادامه بدهی."

    # say L2343 bey
    old "But now it’s about polishing, not fixing big problems."
    new "البته، حالا این درباره لمس جزئیات است، نه اصلاح مشکلات بزرگ."

    # say L2344 bey
    old "Also... don’t forget to rest."
    new "همچنین... فراموش نکن خودت رو استراحت بده."

    # say L2345 bey
    old "Overworking right before a performance can be just as bad as not practicing."
    new "قبل از اجرای برنامه کار کردن زیاد هم خیلی بد است مثل اینکه تمرین نکنی."

    # say L2347 pla
    old "We’ll be careful."
    new "ما مراقب خواهیم بود."

    # say L2348 bey
    old "And one more thing."
    new "و یه چیز دیگه."

    # say L2349 bey
    old "Start thinking about your stage look."
    new "بگشودن به شکل صحنه‌ای خودت فکر کن."

    # say L2350 bil
    old "O- Our look?"
    new "ا- لباس ما؟"

    # say L2351 bey
    old "Clothes, style, how you present yourselves."
    new "پوشش، سبک، طرز ارائه‌ی خودتون."

    # say L2352 bey
    old "Your music has a mood. Your image should match it."
    new "موسیقیتون مودی داره. تصویرتون هم باید با اون همخوانی کنه."

    # say L2353 pla
    old "Oh, That actually sounds fun."
    new "اوه، این واقعاً خوشحالم."

    # say L2355 bey
    old "I’ll be cheering for you both."
    new "من برای شما دو تا حماسه خواهم شد."

    # say L2356 bil
    old "Thank you. For everything."
    new "ممنون. از همه چیز."

    # say L2357 pla
    old "Yeah, thank you."
    new "بله، ممنون."

    # say L2379 bil
    old "Well... that timing was just perfect."
    new "خب... اون زمان خیلی مناسب بود."

    # say L2380 pla
    old "Yeah, that rain came out of nowhere."
    new "بله، اون باران از هیچ جا آمد."

    # say L2381 bil
    old "Tell me about it."
    new "بله، در موردش بگو."

    # say L2382 bil
    old "Anyway, go dry off in the bathroom, towel's there."
    new "باید بروی به سویالشو خشک شی، مندها آماده هست."

    # say L2383 bil
    old "I'm heading to my bedroom to change."
    new "من به اتاق خوابم می‌رم."

    # say L2385 bil
    old "Try not to flood the place."
    new "سعی کن جای خیس نشه."

    # say L2386 pla
    old "No promises."
    new "بله، ولی هیچ قولی نمی‌دهم."

    # say L2399 bil
    old "Hey, eyes up here, perv."
    new "اوه، چشم‌هات اینجا به بالا، خودداری‌کن."

    # say L2402 bil
    old "Heh, what? Rain made them look that good?"
    new "هه، چه کاری؟ باران اونقدر خوبشون رو نشون داد؟"

    # say L2403 pla
    old "Uhhh, well, I- I can literally see your nipples through the shirt..."
    new "اوه، خب، من- من می‌تونم نیپل‌ت رو از طریق پیراهن ببینم..."

    # say L2404 bil
    old "Haha, you’re practically drooling already... you're such a mess"
    new "هه، تو همین الان مثل یه بچه خرسیده شدی... اینقدر دردسر داری"

    # say L2406 bil
    old "Heh, wanna get a better view?"
    new "هه، می‌خوای نگاه بهتری بیاندازی؟"

    # say L2407 pla
    old "I— I- I- Uhhh... y- yea-"
    new "من— من— من— اوه... ب- بله-"

    # say L2412 bil
    old "There. Way better without anything in the way, right?"
    new "اوه، حالا بدون هیچ چیز مانع، خیلی بهتره، درسته؟"

    # say L2413 pla
    old "Holy shit, [bil]..."
    new "هیولایی، [bil]..."

    # say L2415 bil
    old "Heh, oh my gosh... look at you."
    new "هه، خدای من... نگاه کن به تو."

    # say L2416 bil
    old "Someone got rock hard just from staring at my tits."
    new "کسی فقط با نگاه کردن به سینام سخت شد."

    # say L2417 pla
    old "S- Sorry, I can't help it..."
    new "ب- ببخشید، نمی‌تونم خودمو کنترل کنم..."

    # say L2420 bil
    old "Obviously. I love how easily I can turn a perv like you into a complete mess."
    new "البته. دوست دارم ببینم چقدر راحت می‌تونم یه پرفروش مثل تو رو به همه این هرج و مرج تبدیل کنم."

    # say L2427 bil
    old "You know... good boys who practice as hard as you do deserve something special."
    new "میدونی... پسران خوبی که مثل تو تمرین می‌کنند چیز خاصی رو احقاق دارن."

    # say L2434 bil
    old "And you’ve been such a good boy lately..."
    new "و تو اخیراً خیلی خوب بودی..."

    # say L2435 pla
    old "Uhh..."
    new "اوه..."

    # say L2441 bil
    old "Yeah, so I think you’ve earned yourself a little prize."
    new "بله، پس فکر می‌کنم تو یه جایزه‌ی کوچیک کسب کردی."

    # say L2448 bil
    old "Mmm... feel that? Every single inch sliding in..."
    new "مم... احساس کن، هر اینچی در می‌آید..."

    # say L2449 pla
    old "God... you’re so fucking tight..."
    new "خدا... تو خیلی محکمی هستی..."

    # say L2450 bil
    old "Slow... nice and deep. Let me take control."
    new "آرام... خوب و عمیق. بگذار من کنترل رو بگیرم."

    # say L2459 pla
    old "({i}That was... intense. Too intense.{/i})"
    new "{i}این... شدید بود. خیلی شدید.B{/i}"

    # say L2460 bil
    old "You okay? You look like I just broke your brain."
    new "تو خوبی؟ به نظر می‌رسه مغزت ریخته."

    # say L2461 pla
    old "I... yeah. I’m good. Just... damn."
    new "من... بله. خوبم. فقط... لعنتی."

    # say L2462 bil
    old "Heh. 'Damn' is right. We both really needed that, didn’t we?"
    new "هه. «لعنتی» درسته. ما هر دو واقعاً به این نیاز داشتیم، نیست؟"

    # say L2463 pla
    old "Yeah... I think we did."
    new "بله... فکر کنم همینطور بود."

    # say L2465 pla
    old "But... it felt different this time..."
    new "ولی... این بار متفاوت بود..."

    # say L2467 pla
    old "I mean, when we were looking at each other... I could see it in your eyes. You were feeling it too."
    new "من قصدم اینه که وقتی به هم نگاه می‌کردیم... توی چشم‌هایت دیدم. تو هم احساسش می‌کردی."

    # say L2468 bil
    old "Uhh.. D- Don’t get all sappy on me now..."
    new "اوه.. ن- نباید همه این حس‌های شیرین رو بر من بیاندازی حالا..."

    # say L2470 bil
    old "Listen, it was just blowing off steam, okay? Don't start reading too much into it."
    new "بله، فقط برای آرام‌بخشی بود، خب؟ زیاد بهش فکر نکن."

    # say L2471 pla
    old "I guess, you're right, still... it felt really good."
    new "بیل، درست می‌گی، هنوز... ولی خیلی خوب احساس شد."

    # say L2472 bil
    old "Heh. Yeah... you weren’t half bad yourself."
    new "هه. بله... تو هم بد نبودی."

    # say L2473 bil
    old "Doesn’t mean I’m going soft on you though."
    new "البته، این به معنای نرم شدن من نیست."

    # say L2474 bil
    old "The contest is in a few days. We can’t afford to get distracted."
    new "مسابقه چند روز دیگه هست. نمی‌تونیم خودمون رو پرت کنیم."

    # say L2475 pla
    old "Right... back to serious practice."
    new "درست... برگشت به تمرین جدی."

    # say L2476 bil
    old "Exactly. Guitar for you, vocals for me. No slacking."
    new "دقیق. گیتار برای تو، آواز برای من. بدون تردد."

    # say L2479 bil
    old "But... if you need a little extra 'motivation' again... I guess I can make time."
    new "ولی... اگر به یک تحریک کمتر نیاز داشتی... فکر کنم وقت می‌تونم بذارم."

    # say L2480 pla
    old "I’ll take that."
    new "من اون رو می‌گیرم."

    # say L2481 bil
    old "Don’t get cocky. Next time I might make you work even harder for it."
    new "نفرت نکن. بار بعد ممکنه بیشتر تلاش کنی."

    # say L2482 pla
    old "Bring it."
    new "برingen آن را بیاور."

    # say L2484 bil
    old "Now seriously, we need to clean up before my grandma walks in and smells sex and rain in my room."
    new "الان جدی، باید قبل از اینکه بابام بیاد و بوی سکس و باران رو در اتومون ببینه، تمیز کنیم."

    # say L2485 pla
    old "Yeah... I’m moving."
    new "بله... من حرکت می‌کنم."

    # say L2486 bil
    old "And [pla]?"
    new "و [pla]؟"

    # say L2488 bil
    old "Uhh, nevermind... Just keep practicing like your life depends on it. I expect results."
    new "اوه، فراموش کن... فقط مثل اینکه زندگیت به این بستگی داره تمرین کن. ازت نتیجه می‌خوام."

    # say L2489 pla
    old "I will. Promise."
    new "بله، قول می‌دم."

    # say L2509 pla
    old "Yeah, you said you needed me for something. But... we've been practicing a lot lately, right?"
    new "بله، گفتی که برای چیزی به من نیاز داری. اما... اخیراً خیلی تمرین کرده‌ایم، درسته؟"

    # say L2510 bil
    old "Heh, yeah. But no, I don't need you for that today."
    new "هه، بله. اما نه، امروز برای اون کار نیازت ندارم."

    # say L2511 pla
    old "Wait, seriously? Not practice?"
    new "می‌گری جدیانه؟ نه تمرین؟"

    # say L2512 bil
    old "Nope. Today I need you for something else."
    new "نه. امروز برای چیز دیگه‌ای به تو نیاز دارم."

    # say L2514 bil
    old "I want to go buy some clothes. For the contest."
    new "می‌خوام برم لباس بخرم. برای مسابقه."

    # say L2515 pla
    old "Clothes? Like... an outfit?"
    new "پوشاک؟ مثل... لباس مسابقه؟"

    # say L2516 bil
    old "Exactly. I don't want to show up in my usual stuff."
    new "دقیقاً. نمی‌خوام با لباس‌های معمولی‌ام برم."

    # say L2517 bil
    old "Those other idiots are probably gonna be all glitter and sequins. I don't wanna look like I didn't even try."
    new "این دیگه‌ها احتمالاً همه جلوه و لکه خواهند بود. من نمی‌خوام بیادم مثل اینکه حتی تلاشی نکردم."

    # say L2518 pla
    old "Okay, that makes sense. Let's go then. I'll help you pick."
    new "باشه، این جوری هم منطقیه. بیا. من بهت کمک می‌کنم بپیکنی."

    # say L2519 bil
    old "Good. I already have a few ideas. Come on."
    new "خوب. چند ایده‌ام هست. بیا."

    # say L2525 bil
    old "Alright, there's this store I saw online. Not really my usual vibe, but they might have something that works for the stage."
    new "البته، یه فروشگاهی رو توی اینترنت دیدم. خیلی مثل سبکم نیست، ولی ممکنه چیزی پیدا کنیم که برای صحنه مناسب باشه."

    # say L2526 pla
    old "What exactly are you thinking?"
    new "بیل، دقیقاً چه چیزی در ذهن تو هست؟"

    # say L2527 bil
    old "Honestly? I don't know yet. I wanna look around, try a bunch of stuff, and see what feels right. Let's just go in."
    new "Honestly؟ هنوز نمی‌دونم. می‌خوام یه جور چیزهایی رو ببینم و بفهمم چه چیزی برای صحنه مناسبه. بیای بیشتر ببینیم."

    # say L2544 bil
    old "Hi. I'm performing in a music contest in a few days and I need an outfit that fits the stage."
    new "سلام. من در چند روز آینده در یک مسابقه موسیقی شرکت می‌کنم و به لباسی برای صحنه نیاز دارم."

    # say L2546 bil
    old "Hello?"
    new "سلام؟"

    # say L2547 lan
    old "Huh? Oh. Yeah, everything's for sale. Just browse and bring whatever you want to the counter when you're ready."
    new "اوه، بله. همه چیز برای فروش هست. فقط مرور کن و هر چیزی که می‌خوای رو به صورت بیاور وقتی آماده شدی."

    # say L2549 pla
    old "({i}Wow, helpful.{/i})"
    new "{i}الا، خیلی مفیدی.{/i}"

    # say L2550 bil
    old "Uh... okay?"
    new "اوه... خب."

    # say L2556 bil
    old "Hmm, whatever. Let's just look around."
    new "Hmm، هر چی. بیاین بگردیم."

    # say L2557 pla
    old "Yeah. What are you searching for exactly?"
    new "بله. دقیقاً چه چیزی رو می‌گردی؟"

    # say L2558 bil
    old "I'm not totally sure yet. I'll grab a few things, try them on, and you tell me what you think. Deal?"
    new "هیچ جور مطمئن نیستم. چند تا چیز می‌گیرم، می‌پرم و تو بگی چطور به نظرت می‌رسه. توافق؟"

    # say L2559 pla
    old "Deal. I'll be honest."
    new "توافق. صادق خواهم بود."

    # say L2560 bil
    old "You better be."
    new "باید صادق باشی."

    # say L2566 pla
    old "Ready?"
    new "آماده‌ای؟"

    # say L2568 bil
    old "Yeah. I grabbed a few options... even some wigs. Didn't expect that here."
    new "بله. چند تا گزینه برداشتم... حتی چند پارو هم. انتظار نداشتم اینجوری باشه."

    # say L2569 pla
    old "Wigs? For the contest?"
    new "پارو‌ها؟ برای مسابقه؟"

    # say L2570 bil
    old "I'm trying to switch up my whole look a bit. Not going full Sparkle Queen like the others, but... something different."
    new "من سعی می‌کنم ظاهرم رو کمی تغییر بدям. نمی‌خوام مثل دیگران کامل شاهکار شگفت‌انگیز باشم، اما... چیزی متفاوت."

    # say L2579 bil
    old "Okay, first one coming out."
    new "اولین یک خارج می‌شه."

    # say L2587 bil
    old "Okay... I was thinking something like what those empty headed girls would wear. Bright, short, cute. What do you think?"
    new "باشه... من فکر می‌کردم چیزی مثل لباس‌های آن دختران خالی سر می‌تونم بپوشم. رنگارنگ، کوتاه، لطیف. نظرت چیه؟"

    # say L2588 pla
    old "({i}Holy shit... she actually looks amazing in this. I wasn't expecting the pink to suit her this well.{/i})"
    new "{i}میلیون شیطان... تو واقعاً در این لباس عالی هستی. نمی‌تونستم بگم که رنگ روشن به تو اینقدر می‌ایده.{/i}"

    # menu L2591 
    old "Use Agamoto's eye"
    new "استفاده از چشم آگامتو"

    # say L2595 pla
    old "Uhh... Y- you look really good actually. The color pops and the skirt is beautiful... wait, and that hair? It's completely black now."
    new "اوه... واقعاً خوبت. رنگ رو نشون می‌ده و لباس کوتاه زیبا هست... بی‌خیال، و موهایت؟ حالا کاملاً سیاه شدن."

    # say L2605 bil
    old "It's a wig, obviously."
    new "البته پارویه است."

    # say L2606 bil
    old "My green hair would clash horribly with this pink. It'd look ridiculous, so I grabbed a black one to match the outfit."
    new "می‌دونی، موی سبزم با این رز خیلی بد جور می‌شد. خیلی خنده‌دار می‌تونست بود، پس یکی سیاه برداشتم تا با لباس همپوشانی داشته باشه."

    # say L2607 bil
    old "Uhh... So? What do you think overall? Do you like it?"
    new "اوه... خب؟ تو در مجموع چه فکری داری؟ می‌تونی اینو دوست ببری؟"

    # say L2608 pla
    old "Totally. It screams 'stage presence'."
    new "حتماً. این لباس صحنه‌ای رو به نمایش می‌ذاره."

    # say L2609 bil
    old "But... it's so pink. So girly. So... not me. Ugh, too cutesy. Nope."
    new "ولی... خیلی رزه. خیلی دخترانه. خیلی... نه، من نیستم. اوه، خیلی خنده‌دار. نه."

    # say L2610 pla
    old "({i}She looks killer though... but I get it.{/i})"
    new "{i}البته که خوب هست... ولی من متوجهت هستم.{/i}"

    # say L2611 bil
    old "Whatever. Next one."
    new "بیا، بعدی."

    # say L2624 bil
    old "Ok, now this one... more elegant, kinda bohemian, long flowy thing. Thoughts?"
    new "باشه، حالا این تا... اlegant‌تر، نوعی bohemian، لباسی طولانی و جریان‌دار. نظرت چیه؟"

    # say L2625 pla
    old "({i}Wow... she looks absolutely stunning. The long dress and blonde hair completely transform her vibe.{/i})"
    new "{i}واو... تو به طور کامل شگفت‌انگیزی به نظر می‌رسی. لباس بلند و موی زردتی کاملاً احساساتت رو تغییر می‌دهن.{/i}"

    # say L2632 pla
    old "Uhh... Damn, Billie... you look like a whole vibe. Sophisticated, mysterious... and that blonde hair? It's wild on you."
    new "بیلی... تو مثل یه ارتعاش کاملی هستی. پیچیده، مرموز... و اون موی زرد؟ روی تو خیلی جذابه."

    # say L2643 bil
    old "It doesn't look much like a wig, right? I picked one that blended in pretty well."
    new "می‌تونه واقعاً مثل پارو نباشه، درسته؟ انتخابی که انجام دادم خوب جا به جا رفت."

    # say L2644 pla
    old "Well, it looks a bit odd to me, but I think it's just because I know you."
    new "خب، به نظر می‌رسه کمی عجیب است، اما فکر کنم فقط به خاطر اینه که من تو رو می‌شناسم."

    # say L2645 pla
    old "It's like seeing a completely different person, you know?"
    new "مثل اینه که فردی کاملاً متفاوت رو می‌بینم، می‌دونی؟"

    # say L2646 bil
    old "A different person? Uhh, but do you think it could actually work for the contest?"
    new "یک شخصیت متفاوت؟ اوه، ولی فکر می‌کنی واقعاً برای مسابقه کار می‌کنه؟"

    # say L2647 pla
    old "I guess so. It's classy as hell. You'd definitely stand out for sure."
    new "بیلی، فکر کنم همینطور باشه. خیلی شیکه. قطعاً توجه همه رو جلب می‌کنی."

    # say L2648 bil
    old "Hmm, I don't know... I think it's too much. Way too much, you know?"
    new "Hmm، نمی‌دونم... فکر کنم خیلی زیاد باشه. خیلی خیلی زیاد، می‌فهمی؟"

    # say L2649 bil
    old "I feel like I'm playing dress up as some celebrity. This isn't me at all."
    new "احساس می‌کنم مثل یه ستاره سینما هستم. اصلاً این من نیست."

    # say L2650 bil
    old "Ughh, and no more wigs after this. They're boiling hot and I feel super fake wearing them."
    new "اوه، و بعد از این دیگه پارویی نمی‌تونم بذارم. خیلی گرم می‌شن و من باشون خیلی مصنوعی می‌تونم باشم."

    # say L2651 bil
    old "Alright, moving on."
    new "باشه، برویم جلو"

    # say L2665 bil
    old "Okay, this one's bolder. Short skirt, tight top... figured it might grab attention. Be honest."
    new "باشه، اینا جسورتره. لباس کوتاه، بلوز تنگ... فکر کردم می‌تونه توجه رو جلب کنه. صادق باش."

    # say L2666 pla
    old "({i}Holy fuck... her ass is completely exposed. That skirt is barely covering anything...{/i})"
    new "({i}خودت جان... پشتش کاملاً آشکاره. اون لباس کوتاه هیچ چیز رو پوشش نداده...{/i})"

    # say L2690 pla
    old "({i}Shit... no, not now! Why the hell am I getting hard right here in the middle of the store? This is so bad...{/i})"
    new "({i} شیطان... نه، الان نه! چرا خدا من اینجا در وسط فروشگاه سخت می‌شوم؟ این خیلی بد است... {/i})"

    # say L2691 bil
    old "So? What do you think?"
    new "پس؟ چه فکر می‌کنی؟"

    # say L2692 pla
    old "I- I... Uhh... That's... This one is really nic- ass..."
    new "من- من... اوه... این... این یکی واقعاً خوب- پاشونه..."

    # say L2695 bil
    old "Ohhh, look at that. Someone really liked what he saw."
    new "اوه، نگاه کن. کسی واقعاً لذت برده از آنچه دیده."

    # say L2696 bil
    old "You're already rock hard just from staring at my ass. How cute."
    new "تو قطعاً فقط با نگاه کردن به پاشم سخت شدی. چقدر لبخند بر لبانت."

    # say L2697 pla
    old "I- I can't help it... you look way too good like that."
    new "من- من نمی‌تونم... تو همینجوری خیلی خوبت."

    # say L2698 bil
    old "Mmm, really? Then don't just look."
    new "می‌تونی فقط نگاه نکنی."

    # say L2704 bil
    old "So, you really liked this outfit, huh? Why could that be?"
    new "پس، واقعاً این لباس رو دوست داشتی، ها؟ چرا اینجوری باشه؟"

    # say L2705 bil
    old "Do you like how your cock looks between my cheeks?"
    new "می‌پسندی که لوله‌تو بین پوسته‌های من باشه؟"

    # say L2707 bil
    old "Pull it out. I want to feel that warm big cock against my skin."
    new "بیرون بیا. می‌خوام اون لوله بزرگ و گرمتو روی پوستمو حس کنم."

    # say L2708 pla
    old "W- wait! Billie! We're in a fitting room... someone could walk in any second!"
    new "بیلی! صبر کن... ما توی اتاق سایز گیری هستیم... هر لحظه می‌تونه کسی وارد بشه!"

    # say L2709 bil
    old "Relax, dummy. That stupid salesgirl is still glued to her phone. No one's coming this way. We're basically alone."
    new "آرام، بی‌حوصله. اون دختر فروشنده هنوز به گوشی‌اش چسبیده. هیچ‌کس این طرف نمی‌آد. ما تقریباً تنها هستیم."

    # say L2710 bil
    old "Now take your cock out... or should I do it for you?"
    new "حالا نیم‌ت رو بیرون بیار... یا باید من این کار رو بکنم؟"

    # say L2714 bil
    old "Mmm... it feels warm... and so hard."
    new "مم... احساس گرمی می‌کنه... و همینجور سخت."

    # say L2716 bil
    old "That's what makes it fun."
    new "این همینه که خوشحالم."

    # say L2730 bil
    old "It's nice you like it so much..."
    new "خوشحالم که به همین اندازه لذت می‌بری..."

    # say L2732 bil
    old "Besides, this feels way too slutty for the stage. Like I'm selling my ass instead of my voice. Hard pass."
    new "البته، این خیلی خودسرانه برای صحنه است. مثل اینکه اسکلتم رو به جای صدتم می‌فروشم. هیچ."

    # say L2733 pla
    old "({i}She does look fire though... but yeah, she is right.{/i})"
    new "{i}البته که اونجور به نظر می‌رسه... ولی بله، درست می‌گه.{/i}"

    # say L2734 bil
    old "Next."
    new "بعدی."

    # say L2748 bil
    old "Last one. Casual but edgy. Urban, not too flashy. What do you say?"
    new "آخری. آرامشونه اما جسورانه. شهری، خیلی لامپ نباشه. چه خبر می‌گی؟"

    # say L2749 pla
    old "({i}Fuck... even in this one she looks incredible. Those tits in that blue bra...{/i})"
    new "{i}شیط... حتی تو این لباس هم خوبه. آن سیناهایش تو آن برا آبی...{/i}"

    # say L2773 pla
    old "({i}Nooo... not again! I just came all over her ass two minutes ago... What the hell is wrong with me?!{/i})"
    new "({i}نههه... دوباره نه! فقط دو دقیقه پیش روی پشتش خوردم... اینجوری من چه مشکلی دارم؟!{/i})"

    # say L2775 pla
    old "Uhh... yeah, this one is nice too..."
    new "اوه... بله، این هم خوبه..."

    # say L2776 bil
    old "What? Just that? Wait a second..."
    new "چه؟ فقط اونقدر؟ یه لحظه..."

    # say L2777 bil
    old "Are you serious right now?! You just blew a huge load on my ass and you're already rock hard again? Just from seeing me squeeze my tits?"
    new "می‌خواهی جدی باشی؟! تو فقط یه بار خیلی زیاد روی پشت من خروشوندی و حالا دوباره سخت شدی؟ فقط از اینکه داشتم سینه‌هام رو فشار میدادم؟"

    # say L2778 bil
    old "Damn... these really drive you crazy, huh?"
    new "لعنتی... اینا واقعاً تو رو دیوانه می‌کنن، ه؟"

    # say L2780 bil
    old "Mmm, greedy boy... still got more for me? Let me milk you dry."
    new "ممن، پسر خر… هنوز هم برای من چیزی داری؟ بیا بگذaram تو رو خالی کنم."

    # say L2781 bil
    old "Come here. Let me take care of that with my tits."
    new "بیا اینجا. بیام با پستان‌هام درستش کنم."

    # say L2796 bil
    old "Alright, this one isn't right either."
    new "البته، این هم درست نیست."

    # say L2797 pla
    old "What? W-why?"
    new "چه؟ چرا؟"

    # say L2798 bil
    old "Judging by the way you just got hard again... it doesn't make much difference from the last one."
    new "با توجه به اینکه دوباره سخت شدی... خیلی فرقی با آخری نمی‌کنه."

    # say L2799 pla
    old "Yeah... I guess you're right."
    new "بله... به نظر می‌رسه همینطوره."

    # say L2800 bil
    old "Hmm, whatever... I'm just gonna change back."
    new "هم، هر چی... من فقط قرار هستم برگردم."

    # say L2801 pla
    old "({i}I thought this would be easier...{/i})"
    new "{i} فکر کردم این راحت‌تر می‌بود... {/i}"

    # say L2809 bil
    old "Alright, let's go."
    new "باشه، برویم."

    # say L2815 pla
    old "W- What? so, none of them? You didn't like any?"
    new "W- چه؟ پس هیچ‌کدام؟ تو هیچ‌کدام رو دوست نداشتی؟"

    # say L2816 bil
    old "No. None of them feel right. All that color, glitter, fake glamour..."
    new "نه. هیچ‌کدام درست نیست. همه اون رنگ، تاب، جذابیت مصنوعی..."

    # say L2817 bil
    old "It's not me. I don't want to pretend to be someone I'm not just to compete with those idiots."
    new "این من نیست. نمی‌خوام برای رقابت با اون ابله‌ها شخصیتی که نیستم بازی کنم."

    # say L2818 pla
    old "({i}She's got a point. That's what makes her special.{/i})"
    new "{i}من همینجور فکر می‌کنم. این همینجوری هست که خاصه‌اش هست.{/i}"

    # say L2819 pla
    old "Okay, fair enough. So... sticking with your usual look for the contest?"
    new "باشه، منصفانه. پس... قصد داری برای مسابقه همین لباس رو بپوشی؟"

    # say L2820 bil
    old "For now, yeah. I'll keep thinking, but I'm not forcing something that doesn't feel like me. Thanks for coming with me though. Seriously."
    new "برای حالا، بله. فکر می‌کنم، اما نمی‌خوام چیزی رو اجباری کنم که مثل من نیست. ممنون که با من اومدی. جدی هستم."

    # say L2821 pla
    old "Anytime. I had fun watching you rock every single one, even if you hated them."
    new "هر زمان. لذت بردم از دیدن تو که همه رو شگفت‌زده کردی، حتی اگه خودت نپسندی."

    # say L2822 bil
    old "Heh. Flatterer. Come on, let's get out of here before I change my mind and buy the whole store."
    new "هه. خوب‌گو. بیا، برویم بیرون قبل از اینکه نظرم عوض بشه و همه چی رو بخرم."

    # say L2842 bil
    old "You made it."
    new "تو اینجوری رسیدی."

    # say L2843 pla
    old "Of course. You texted 'last practice' like it was serious."
    new "البته. تو پیام زدی «آخرین تمرین» مثل اونکه جدی بود."

    # say L2845 pla
    old "Uh... You okay?"
    new "اوه... حالت خوبه؟"

    # say L2846 bil
    old "Yeah, don't worry. Come in."
    new "بله، نگران نباش. بیا داخل."

    # say L2852 bil
    old "Tomorrow’s the contest."
    new "فردا مسابقه‌هاست."

    # say L2853 pla
    old "Yeah... kinda crazy, huh?"
    new "بله... یه جور خیلی دیوانه، ها؟"

    # say L2854 bil
    old "I never thought I’d stand on a stage again."
    new "هیچ وقت فکر نکردم دوباره روی صحنه ایستاده باشم."

    # say L2855 pla
    old "'Again'?"
    new "دیگه؟"

    # say L2856 bil
    old "I mean... after everything."
    new "من قصده‌ام... بعد از همه چیز."

    # say L2857 pla
    old "But you’re here."
    new "ولی تو اینجا هستی."

    # say L2858 bil
    old "Yeah. And that scares me more than the stage."
    new "بله. و این بیشتر از صحنه مرا ترسونه."

    # say L2860 bil
    old "Because the stage can’t leave."
    new "چون صحنه نمی‌تونه بره."

    # say L2861 pla
    old "You don’t have to carry everything alone, you know."
    new "می‌دونی، نمی‌تونی همه چی رو خودت ببری."

    # say L2863 bil
    old "Let’s run it once. Soft. No pressure."
    new "بیای یک بار اجراش کنیم. نرم. بدون فشار."

    # say L2903 pla
    old "That felt different."
    new "این حس متفاوت بود."

    # say L2904 bil
    old "It always does..."
    new "همیشه همینطور است..."

    # say L2907 bil
    old "Do you know why I really stopped singing?"
    new "می‌دونی چرا واقعاً خواندن رو توقف دادم؟"

    # say L2908 pla
    old "Uhh, your grandma told me some of it."
    new "بیل، بابا، نانی به من یه جوری از اون حرف زد."

    # say L2909 bil
    old "She tells the gentle version."
    new "او نسخه نرم‌ترش رو می‌گه."

    # say L2910 pla
    old "What’s the real one?"
    new "وای، واقعیش چیه؟"

    # say L2911 bil
    old "When they died... everyone said 'be strong’."
    new "وقتی مردند... همه می‌گفتند «قوی باش»."

    # say L2912 bil
    old "So I was."
    new "پس من همچین کاری کردم."

    # say L2913 bil
    old "I stopped crying. Stopped singing. Stopped needing."
    new "من دیگه نگریام. نخوندم. نیاز نداشتم."

    # say L2914 pla
    old "That’s not strength."
    new "این قوی بودن نیست."

    # say L2915 bil
    old "Well, it felt like survival."
    new "خب، این مثل زنده موندن بود."

    # say L2916 bil
    old "Every song sounded like them."
    new "هر آهنگ مثلشون می‌شنید."

    # say L2917 bil
    old "Every note felt like losing them again."
    new "هر نت مثل دوباره از دست دادنشون حس می‌شد."

    # say L2918 pla
    old "So you buried it."
    new "پس تو اونو دفن کردی."

    # say L2919 bil
    old "Yeah. And I buried part of me with it."
    new "بله. و بخشی از خودم رو هم مدفون کردم."

    # say L2921 bil
    old "But then you showed up. Loud. Stubborn. Impossible."
    new "ولی بعد تو رسیدی. بلند صدا. خردلرز. غیرممکن."

    # say L2922 pla
    old "I guess I have a talent for that."
    new "به نظر می‌تونه من همین تالنت رو داشتم."

    # say L2923 bil
    old "You dragged me back to something I was scared to touch."
    new "تو منو به چیزی برگردانی که از لمسش می‌ترسیدم."

    # say L2924 bil
    old "And now I’m scared of losing it again."
    new "و حالا از دست دادنش می‌ترسم."

    # say L2926 pla
    old "You won’t."
    new "تو نخواهی."

    # say L2927 bil
    old "You don’t know that."
    new "تو اینو نمی‌دونی."

    # say L2928 pla
    old "I know I’ll be with you."
    new "من می‌دونم با تو خواهم بود."

    # say L2929 bil
    old "You promise too easily."
    new "تو خیلی راحت قول می‌دهی."

    # say L2930 pla
    old "I don’t make promises I can’t keep."
    new "من قول نمی‌دم که نتونم نگه دارم."

    # say L2931 bil
    old "I don’t want to be alone tomorrow, [pla]."
    new "من فردا نمی‌خوام تنها باشم، [pla]."

    # say L2932 pla
    old "You won’t be."
    new "تو راه نخواهی."

    # say L2933 bil
    old "I mean... really alone."
    new "من می‌خوام... واقعاً تنها نباشم."

    # say L2937 pla
    old "Then don’t be."
    new "بعد نباش."

    # say L2938 bil
    old "You don’t run when things get heavy?"
    new "وقتی جدی می‌شه، تو نمی‌دوزی؟"

    # say L2939 pla
    old "I would never leave you."
    new "من هرگز تو را ترک نمی‌کنم."

    # say L2941 bil
    old "What if I break on stage?"
    new "اگر روی صحنه خراب شدم چه می‌شه؟"

    # say L2942 pla
    old "Then I’ll be right there, with you."
    new "بعداً هم همیشه با تو خواهم بود."

    # say L2943 bil
    old "What if I fail?"
    new "اگر شکست بخورم چه کنم؟"

    # say L2944 pla
    old "Then you still tried. And that already makes you brave."
    new "بعداً هم همچین که تلاش کردی. و این خودش تو رو جسور می‌کنه."

    # say L2945 bil
    old "I don’t want to have to hide anymore."
    new "من نمی‌خوام دیگه پوشش بدم."

    # say L2946 pla
    old "Then don’t."
    new "بعد ندا."

    # say L2947 bil
    old "I don’t know how to do this..."
    new "نمی‌دونم چطور باید اینو بکنم..."

    # say L2948 pla
    old "Don’t. Just be real."
    new "ندا. فقط واقعی باش."

    # say L2950 bil
    old "If this goes wrong tomorrow..."
    new "اگر فردا اشتباه شد..."

    # say L2951 pla
    old "It won’t erase everything we’ve done."
    new "این همه کاری که انجام دادیم رو نمی‌پاکنه."

    # say L2952 bil
    old "You’re not scared of me falling apart?"
    new "می‌تونی از من نگران نباشی که از هم پاشم؟"

    # say L2953 pla
    old "I’m scared of you thinking you have to."
    new "من از این نگرانم که فکر می‌کنی باید اینجوری باشی."

    # say L2960 bil
    old "I don’t know what this is..."
    new "نمی‌دونم این چیه..."

    # say L2961 pla
    old "Neither do I. But I know it’s real."
    new "من هم نمی‌دونم. ولی می‌دونم این واقیه."

    # say L2967 bil
    old "That... wasn’t in the plan."
    new "این... در برنامه قرار نداشت."

    # say L2968 pla
    old "Neither was any of this."
    new "هیچی از اینا هم در برنامه نبود."

    # say L2969 bil
    old "I don’t want this to be a mistake."
    new "من نمی‌خوام این یه اشتباه باشه."

    # say L2970 pla
    old "Then let it be a choice."
    new "پس این رو انتخاب کن."

    # say L2971 bil
    old "I think I want you... right now..."
    new "فکر کنم می‌خوام تو رو... الان..."

    # say L2986 pla
    old "Hey... whatever happens tomorrow..."
    new "بلا... هر چه فردا بیفتد..."

    # say L2987 pla
    old "I'm really glad you decided to do this. And I’m really proud of you."
    new "خوشحالم که این را تصمیم دادی. و خیلی افتخارت می‌کنم."

    # say L2989 bil
    old "Don’t make me all soft right now."
    new "نمی‌تونی الان منو نرم می‌کنی."

    # say L2990 bil
    old "But... thank you. For pushing me. For being here tonight."
    new "ولی... ممنون. برای اینکه منو تشویق کردی. برای اینکه امروز همینجا هستی."

    # say L2991 pla
    old "I’ll be right there with you on that stage."
    new "من هم با تو روی آن صحنه خواهم بود."

    # say L2992 bil
    old "You better not run away when I get nervous."
    new "باید نگری زمانی که من ناراحت شدم."

    # say L2994 pla
    old "Goodnight, Billie."
    new "شب خوب، بیلی."

    # say L2997 bil
    old "Goodnight... and [pla]?"
    new "شب خوب... و [pla]؟"

    # say L2999 pla
    old "Hmm?"
    new "Hmm؟"

    # say L3000 bil
    old "Wait... I almost forgot something."
    new "بیا... یه چیز رو فراموش کردم."

    # say L3005 bil
    old "Give me a second. Don’t move."
    new "یه لحظه بده. جابجا نشو."

    # say L3012 bil
    old "Here. I have something for you."
    new "اینجا. چیزی برایت دارم."

    # say L3015 pla
    old "A jacket?"
    new "یک جاکت؟"

    # say L3017 bil
    old "It’s my dad’s old one."
    new "این جکت پاپام است."

    # say L3018 pla
    old "Billie... I can’t take this."
    new "بیلی... من نمی‌تونم اینو بگیرم."

    # say L3019 bil
    old "Yes, you can. And you will."
    new "بله، می‌توانی. و همین‌طور خواهی کرد."

    # say L3020 bil
    old "No one else deserves to wear it more than you."
    new "هیچ‌کس از تو بیشتر احقاق پوشیدنش نداره."

    # say L3021 bil
    old "Besides, I can’t let you show up to the contest in that same old t-shirt and those ridiculous pink shorts again."
    new "البته، نمی‌تونم بیایی با همین تی‌شرت قدیمی و آن مورد شورت‌های روز رنگ دوباره به مسابقه بری."

    # say L3022 pla
    old "Hah... fair point."
    new "هه... نقطه خوبی."

    # say L3024 bil
    old "I’m serious. I want you to have it."
    new "من جدی هستم. می‌خوام تو اون رو بگیری."

    # say L3025 bil
    old "It feels right... you wearing it. It meant a lot to me."
    new "این حس خوبی داره... تو اون رو پوشیدی. برای من خیلی مهم بود."

    # say L3027 pla
    old "Then... thank you. I’ll take good care of it."
    new "پس... ممنون. خوبش را می‌رسانم."

    # say L3032 bil
    old "Mmm, looking good, handsome."
    new "ممنون، عزیزم. خوشحالم که لباست."

    # say L3033 pla
    old "Heh... you really think so?"
    new "هه... واقعاً فکر می‌کنی همینجوری هست؟"

    # say L3034 bil
    old "Well, not as good as it looked on him... but damn, it still looks good on you."
    new "خب، نه مثل وقتی رویش بود... اما خدای من، هنوز روی تو خوب می‌نشینه."

    # say L3036 bil
    old "Now go. Before I change my mind and drag you back to bed."
    new "بزن. قبل از اینکه نظرم عوض بشه و تو رو دوباره به بیت بکشونم."

    # say L3037 pla
    old "Whoa... you really have gotten bold tonight."
    new "وای… تو واقعاً این شب جرات کشی کردی."

    # say L3038 pla
    old "But yeah... we both need to rest. Big day tomorrow."
    new "ولی بله... ما هر دو باید استراحت کنیم. روز بزرگی فردا است."

    # say L3039 bil
    old "Go home. Sleep. And be ready."
    new "برو خونه. بخواب. و آماده باش."

    # say L3040 pla
    old "I will. See you tomorrow... on that stage."
    new "بله. فردا در آن صحنه می‌بینیم."

    # say L3041 bil
    old "See you tomorrow."
    new "ببینم فردا."

    # say L3061 pla
    old "Today’s the day..."
    new "امروز روز آن است..."

    # say L3062 pla
    old "The contest. Our contest."
    new "مسابقه. مسابقه‌مون."

    # say L3063 pla
    old "I feel... ready. For the first time in a long time."
    new "احساسی... آماده هستم. برای اولین بار پس از طولانی."

    # say L3072 pla
    old "This jacket... it feels like she’s with me already."
    new "این جاکت... مثل اینه که او قراره همینجا با من باشه."

    # say L3073 pla
    old "Alright. Let’s go win this thing."
    new "باشه. بیایم این برنده رو ببریم."

    # say L3081 pla
    old "I’m actually early for once."
    new "این بار واقعاً زود آمدم."

    # say L3082 pla
    old "Billie should be here any minute. She said she’d meet me right here."
    new "بیلی هر لحظه می‌تونه اینجا باشه. گفت اینجا می‌تونه منو ببینه."

    # say L3083 pla
    old "We’ve practiced so much... today’s gonna be good."
    new "ما خیلی تمرین کردیم... امروز خوب می‌شه."

    # say L3096 pla
    old "Okay... she’s still not here."
    new "باشه... هنوز اینجا نیست."

    # say L3097 pla
    old "Where is she? The contest is gonna start soon."
    new "او کجاست؟ مسابقه به زودی شروع می‌شه."

    # say L3098 pla
    old "She’s probably just running a little late. No big deal."
    new "احتمالاً تأخیر کمی داره. خیلی مهم نیست."

    # say L3111 ari
    old "Look who it is. The tree and his little jacket upgrade."
    new "ببینم کیه. درخت و جاکت کوچیکش جدید."

    # say L3112 tay
    old "Cute jacket, [pla]. Do you think that’s enough to impress anyone?"
    new "پوسته خوبی، [pla]. فکر می‌کنی این کافیه تا کسی رو شگفت‌زده کنی؟"

    # say L3113 ari
    old "Yeah, good luck trying not to be a statue again."
    new "بله، خوش حالم که دیگر آماره نباشی."

    # say L3114 pla
    old "Whatever. You two just worry about your own act."
    new "باید نگران اتفاقات خودتون باشید."

    # say L3115 ari
    old "We’re up soon. See you losers on stage."
    new "ما هم خیلی زود روی صحنه‌ایم. ببینیم شما دو تا چطور اجرا می‌کنید."

    # say L3126 pla
    old "They’re already heading in... the contest really is starting."
    new "اونا قدم زدند... مسابقه واقعاً شروع شده."

    # say L3138 pla
    old "Still no sign of her..."
    new "هنوز هیچ اثری ازش نیست..."

    # say L3139 pla
    old "Come on, Billie... you promised."
    new "بیلی، بیا... تو قول دادی."

    # say L3140 pla
    old "Screw it. I’m gonna check if the contest already started."
    new "بیا، بیشتر نمی‌تونم صبر کنم. برم می‌شوم ببینم مسابقه شروع شده یا نه."

    # say L3145 pla
    old "Oh no... fuck... the contest already started!"
    new "اوه نه... شیطون... مسابقه شروع شده!"

    # say L3146 pla
    old "Fuck, fuck, fuck... Billie still hasn’t arrived."
    new "لعنتی، لعنتی، لعنتی... بیلی هنوز نیومده."

    # say L3147 pla
    old "Why isn’t she here? What happened?"
    new "چرا اینجا نیست؟ چه اتفاقی افتاد؟"

    # say L3155 pla
    old "Should I run to her house? But what if she shows up and doesn’t see me?"
    new "باید به خونه‌اش برم؟ اما اگه اومد و من رو ندید؟"

    # say L3156 pla
    old "No... I have to wait here. She said she’d come. I know she’s coming."
    new "نه... باید اینجا منتظر بقیم. او گفت می‌آید. می‌دونم می‌آید."

    # say L3163 pla
    old "Billie! There you are! Finally!"
    new "بیلی! اینجایی! در نهایت!"

    # say L3164 pla
    old "Oh wow! You look... beautiful. Really. That outfit... wow."
    new "اوه وای! تو خیلی زیبایی... واقعاً. اون لباس... وای."

    # say L3166 bil
    old "[pla], I... I can’t do this."
    new "[pla]، من... من نمی‌تونم اینو بکنم."

    # say L3167 pla
    old "Hey, hey what’s wrong? Talk to me."
    new "بیلی، بیا بگو چه کاره؟ با من حرف بزن."

    # say L3168 bil
    old "My hands won’t stop shaking. I feel like I’m going to throw up."
    new "دست‌هام تر می‌شن و می‌تونم برم اینجا بیوفتم."

    # say L3169 bil
    old "Every time I close my eyes I hear their voices... my parents. And then I remember they’re gone."
    new "هر باری که چشمام رو می‌بندم صدایشون رو می‌شنوم... والدینم. بعد به یاد می‌آورم که نیستن."

    # say L3170 bil
    old "What if I open my mouth and nothing comes out? What if I break in front of everyone?"
    new "اگر دهانم رو باز کنم چیزی نمی‌تونم بگم. اگر جلو همه شکسته برم؟"

    # say L3171 pla
    old "Breathe. Look at me."
    new "نفس بکش. نگاه کن به من."

    # say L3172 bil
    old "I’m not ready. I thought I was, but I’m not."
    new "من آماده نیستم. فکر کردم آماده‌ام، ولی نیستم."

    # say L3173 pla
    old "Come with me. We’re going somewhere quieter."
    new "بیلی، با من بیا. می‌رویم جای آرام‌تری."

    # say L3185 pla
    old "Ok, just breathe with me, okay? In... and out."
    new "باشه، فقط با من نفس بکش، خب؟ وارد... و خارج."

    # say L3186 bil
    old "I can’t... my chest feels tight."
    new "نمی‌تونم... سینه‌ام تنگ شده."

    # say L3187 pla
    old "You’re safe. I’m right here."
    new "تو در امانی هستی. من اینجا هستم."

    # say L3188 bil
    old "It doesn’t feel safe... it feels like I’m about to lose everything again."
    new "این امن نیست... مثل اینه که دوباره همه چیز رو از دست بدهم."

    # say L3203 bil
    old "What if I freeze on stage... what if I open my mouth and nothing comes out..."
    new "اگر روی صحنه یخ زنم چه می‌شه... اگر دهانم رو باز کنم و هیچ چیزی نیومد چه می‌شه..."

    # say L3204 pla
    old "Billie, look at me. You’ve practiced this a thousand times."
    new "بیلی، نگاهت به من. تو این رو هزار بار تمرین کردی."

    # say L3205 bil
    old "Practicing is not the same as standing in front of everyone..."
    new "تمرین کردن همینجوری نیست که جلوی همه ایستاده باشی..."

    # say L3206 bil
    old "Every note is going to bring them back... and then they’ll disappear again..."
    new "هر نت می‌تونه باعث برگشون بیاد... بعد دوباره محو بشن..."

    # say L3212 pla
    old "Hey... hey, come here."
    new "بیا اینجا..."

    # say L3214 bil
    old "I can’t... I can’t do this..."
    new "من نمی‌تونم... نمی‌تونم اینو بکنم..."

    # say L3217 pla
    old "({i}Nothing I say is working... she’s spiraling hard.{/i})"
    new "{i}هیچ چیزی که می‌گم کار نمی‌کنه... او خیلی سریع پایین می‌ره {/i}"

    # say L3218 pla
    old "Wait! I have an idea!"
    new "پیش! ایده‌ای دارم!"

    # say L3229 pla
    old "I don’t want to get your dad’s jacket dirty."
    new "من نمی‌خوام جاکت پدرت خراب بشه."

    # say L3230 bil
    old "I don’t understand..."
    new "من نمی‌فهمم..."

    # say L3231 pla
    old "Well, I want you to take off your dress... and your underwear."
    new "خب، من می‌خوام لباست رو ببری... و لباس زیرت هم."

    # say L3232 bil
    old "W- what...?"
    new "و- وای...؟"

    # say L3233 pla
    old "Well, I’m using that technique you showed me once... the one that always works."
    new "خب، از آن تکنیک استفاده می‌کنم که یک بار به من نشون دادی... همونی که همیشه کار می‌کنه."

    # say L3234 pla
    old "It's called 'Plan B'"
    new "این روش «پلان ب» هست"

    # say L3235 bil
    old "I- I am not sur-"
    new "من- من مطمئن نیستم"

    # say L3236 pla
    old "You calmed me down the same way once. Let me do the same for you."
    new "تو هم یه بار اینجوری من رو آرامش دادی. بیای، من هم برای تو همین کار رو بکنم."

    # say L3237 bil
    old "This is insane..."
    new "این جنون است..."

    # say L3238 pla
    old "Come on. Take off your dress... and the underwear. Now."
    new "بیا. لباستو ببرد و زیر لباس هم. حالا."

    # say L3240 pla
    old "I’m not asking twice. Come on, take it all off."
    new "من دوباره پرسونم. بیا، همه رو ببرد."

    # say L3241 pla
    old "Sit on my face. Let me take care of you."
    new "بیا، روی چهره‌ام نشین. بگذار من بهت مراقبت کنم."

    # say L3249 bil
    old "You’re really doing this..."
    new "وای، واقعاً اینو می‌کنی..."

    # say L3250 bil
    old "Mmm... your tongue..."
    new "ممنون... زبان تو..."

    # say L3268 bil
    old "We’re late... but I think I can do this now."
    new "ما تأخیر داریم... ولی فکر کنم الان می‌تونم اینو بکنم."

    # say L3269 pla
    old "Then let’s go win this thing."
    new "پس بیایم این برنده شیم."

    # say L3273 bey
    old "Last call for Billie and [pla]!"
    new "آخرین صدا برای بیلی و [pla]!"

    # say L3283 pla
    old "We’re here! We’re coming!"
    new "ما اینجا هستیم! در حال آمدنیم!"

    # say L3285 pla
    old "Hey... look at me."
    new "ببین منو"

    # say L3286 pla
    old "You’ve got this. You’re not alone up there."
    new "تو قوی هستی. بالا نیستی تنهایی."

    # say L3287 pla
    old "Breathe with me, okay? In... and out."
    new "با من نفس بکش، خب؟ وارد... و خارج."

    # say L3288 bil
    old "Okay... T- thank you..."
    new "باشه... ممنون..."

    # say L3289 pla
    old "You’re the one with the voice. I’m just there to hold you steady."
    new "تو صدایت رو داری. من فقط برای این هستم که تو رو آرامش بدم."

    # say L3290 pla
    old "You ready?"
    new "آماده‌ای؟"

    # say L3291 bil
    old "No... but I’m doing it anyway."
    new "نه... ولی هر جوری انجام می‌دم."

    # say L3292 pla
    old "That's good, let´s go!"
    new "خوبه، برویم!"

    # say L3312 pla
    old "Do it for them."
    new "برایشون انجام بده."

    # say L3314 pla
    old "Do it for your mom... and your dad. They’d be so proud of you right now."
    new "برای مامان و پاپاتون انجام بده... اونا الان خیلی افتخارت می‌کردند."

    # say L3316 bil
    old "They would, wouldn’t they?"
    new "مama، همینطور پاپا... خیلی افتخارت می‌کردند، نه؟"

    # say L3317 bil
    old "Thank you... for reminding me why I’m here."
    new "ممنون... برای اینکه به من یادآور شدی چرا اینجا هستم."

    # say L3318 bil
    old "Let’s do this."
    new "بیای بذار بکنیم."

    # say L3319 pla
    old "Together."
    new "با هم"

    # say L3339 bey
    old "Wow... what a night."
    new "واو... چه شبی بود."

    # say L3340 bey
    old "First of all, thank you all for waiting so patiently... I know we made you sit through a lot today."
    new "اولاً، ممنون از همه‌تون که صبور بودید... می‌دونم امروز خیلی چیز‌هایی رو تحمل کردید."

    # say L3341 bey
    old "Because you didn’t just perform... you gave us a show we’re never going to forget."
    new "چون شما فقط اجرا نکردید... بلکه به ما نمایشی دادید که هرگز فراموش نخواهیم کرد."

    # say L3342 bey
    old "Every duo showed heart, talent, and courage."
    new "هر جفت قلب، موهبت و شجاعت نشون دادند."

    # say L3343 bey
    old "This wasn’t just a Music contest. This was a night full of real stories, real voices, and real passion."
    new "این فقط یک مسابقه موسیقی نبود. این شبی از داستان‌های واقعی، صداهای واقعی و عشق واقعی بود."

    # say L3344 bey
    old "The jury had an almost impossible job tonight."
    new "داوران امشب کاری تقریباً غیرممکن داشتند."

    # say L3345 bey
    old "They argued, they debated, they went back and forth... because every single performance deserved to be celebrated."
    new "آنها بحث کردند، مناظره کردند، پیش و پس بر می‌آمدند... زیرا هر عملکرد مستحق تجلیل بود."

    # say L3346 bey
    old "But after long deliberation... they finally made their decision."
    new "اما بعد از مذاکره‌های طولانی... در نهایت تصمیم خود را گرفتند."

    # say L3348 bey
    old "The winners of this year’s Music Contest are..."
    new "برندگان مسابقه موسیقی این سال..."

    # say L3356 bey
    old "Come on up here, you two! You earned this."
    new "بیا اینجا، شما دو تا! این رو کسب کردید."

    # say L3357 bey
    old "Get your prize and let everyone see the duo that stole the show tonight!"
    new "بیا جایزه‌تو بگیرید و بگذارید همه دو تایی که شب امروز رو غرق کردین رو ببینن"

    # say L3371 pla
    old "We... we actually did it."
    new "ما... ما واقعاً اینو انجام دادیم."

    # say L3372 bil
    old "I... I can’t believe it."
    new "من... من باور نمی‌کنم."

    # say L3373 pla
    old "We did it."
    new "ما انجام دادیم."

    # say L3374 bey
    old "Come on, darling... come and get your trophy."
    new "بیا، عزیزم... بیا و جایزت رو بگیر."

    # say L3377 pla
    old "Go ahead, this is your moment..."
    new "برو، این لحظه‌اته."

    # say L3393 bey
    old "Billie, honey... would you like to say a few words to the audience?"
    new "بیلی، عزیزم... آیا می‌خوای چند کلمه به مخاطبان بگی؟"

    # say L3395 bil
    old "I... no, I’m not good with words."
    new "من... نه، من با کلمات خوب نیستم."

    # say L3396 bil
    old "I don’t think I can..."
    new "من فکر نمی‌کنم بتونم..."

    # say L3397 pla
    old "Come on, Billie. Say something."
    new "بله، بیلی. بگو چیزی."

    # say L3398 pla
    old "They want to hear from you. You earned this moment."
    new "بیلی، اونا می‌خوان از تو بشنون. تو این لحظه رو به دست آوردی."

    # say L3401 bil
    old "Okay... just this once."
    new "باشه... فقط این بار."

    # say L3404 bil
    old "I... I didn’t think I’d ever sing again."
    new "من... من فکر نکردم هرگز دوباره خواهم خواند."

    # say L3405 bil
    old "For years I buried this part of me because every note reminded me of my parents."
    new "سال‌ها این بخش از من را مدفون کردم چون هر نت به من یادشون می‌آورد."

    # say L3406 bil
    old "They taught me to sing. They taught me to love music. And when I lost them... I lost that too."
    new "آنها به من آموزش دادند خواندن. آنها به من آموختند موسیقی رو دوست داشتن. و وقتی اونا رو از دست دادم... اون هم رو از دست دادم."

    # say L3408 bil
    old "But someone stubborn refused to let me hide forever."
    new "اما یکی خیلی خرس‌پرتون نگذاشت که همیشه پنهان بمانم."

    # say L3410 bil
    old "He dragged me back to the stage... even when I fought him every step of the way."
    new "او من رو به صحنه برگرداند... حتی وقتی من هر قدمی رو با او مبارزه می‌کردم."

    # say L3411 bil
    old "Come here, dummy."
    new "بیا اینجا، خنده‌دار."

    # say L3420 bil
    old "So tonight... this win isn’t just mine. It’s ours."
    new "پس امشب... این پیروزی فقط مال من نیست. مال ما هست."

    # say L3421 bil
    old "Mom... Dad... this one’s for you."
    new "مامان... پاپا... این برای شماست."

    # say L3437 bil
    old "I still can’t believe we actually won..."
    new "هنوز باور نمی‌کنم واقعاً برنده شدیم..."

    # say L3438 pla
    old "You were incredible up there. Everyone saw it."
    new "تو بالای صحنه عالی بودی. همه دیدند."

    # say L3439 bil
    old "I didn’t think I’d ever stand on a stage again... and now I’m holding a trophy."
    new "فکر نمی‌کردم هیچ وقت دیگه روی صحنه ایستاده باشم... و حالا یه جایزه در دست دارم."

    # say L3440 bil
    old "For a long time I told myself I was going to win just to look strong... I never really believed it."
    new "برای مدتی به خودم می‌گفتم که قراره برنم بیشتر برای اینکه قوی به نظر بیام... ولی هرگز واقعاً باور نکردم."

    # say L3441 pla
    old "But you did win. And it wasn’t fake. It was real."
    new "اما تو برنده شدی. و این برای نشون دادن قوی نبود. این واقعی بود."

    # say L3442 pla
    old "Your voice came straight from your heart. The others were all flash and technique... but you? You made people feel something."
    new "صدات از قلبتو بیرون آمد. دیگران همه فلش و تکنیک داشتن... اما تو؟ تو احساساتی توی مردم بزرگ کردی."

    # say L3444 pla
    old "I know so. That’s why you won. Not because of any outfit or trick... because it was you."
    new "می‌دونم. همین جوهرت بود که برنده شدی. نه به خاطر لباس یا تکنیک... بلکه به خاطر اینکه تو بودی."

    # say L3446 bil
    old "It’s weird... I spent years running from this, and now it feels like I finally got a piece of myself back."
    new "عجیبه... سال‌ها از این دوری می‌ریختم و حالا مثل اینه که بخشی از خودمو برگرداندم."

    # say L3447 pla
    old "You did. And I’m really proud of you."
    new "تو انجام دادی. و خیلی ازت متحسنم."

    # say L3448 bil
    old "I couldn’t have done any of this without you."
    new "من هیچ کدام از اینا رو بدون تو نمی‌تونستم انجام بدم."

    # say L3449 bil
    old "You pushed me when I wanted to hide. You stayed when I tried to push you away."
    new "تو وقتی می‌خواستم پنهان شم، مرا تشویق کردی. وقتی سعی کردم تو رو دور کنم، تو همراه من موندی."

    # say L3450 pla
    old "I wasn’t going anywhere."
    new "من هیچ جا نمی‌رفتم."

    # say L3451 bil
    old "I know... and that means more than you’ll ever understand."
    new "می‌دونم... و این بیشتر از هر چیزی که بتونی فهمیده باشی، اهمیت داره."

    # say L3452 bil
    old "Speaking of outfits... you never really said anything about this one."
    new "در مورد لباس‌ها... هیچ وقت در مورد این لباس نظرت رو نگفتی."

    # say L3453 bil
    old "What do you think? Be honest."
    new "چه فکر می‌کنی؟ صادقانه بگو."

    # say L3454 pla
    old "You look... stunning. It’s edgy, it’s dark, it’s completely you. No one else could pull it off like that."
    new "تو به نظر می‌رسی... شگفت‌انگیز. این لباس جسورانه است، تاریک است، کاملاً تویی. هیچ کس مثل تو نمی‌تونه اینجوری باشه."

    # say L3455 bil
    old "Heh... good answer."
    new "هه... جواب خوبی."

    # say L3456 bil
    old "I was nervous about wearing something so different... but the way you’re looking at me right now..."
    new "من نگران بودم چیزی متفاوت بپوشم... ولی طرز نگاهت به من الان..."

    # say L3457 bil
    old "Makes me want to give you a better view."
    new "نگاهت به من الان می‌خوام بهت نگاهی بهتر بدم."

    # say L3468 bil
    old "Tonight I want to celebrate... my way."
    new "امروز شب می‌خوام جشن بگیرم... به طرزی که من می‌خوام."

    # say L3477 bil
    old "You’ve been staring at my tits all night... time to give them some attention."
    new "تو همه شب به سینام خیره بودی... الان وقتیه که بهشون توجه کنی."

    # say L3486 bil
    old "Mmm... morning already?"
    new "ممنون... قدری زود هست، درسته؟"

    # say L3487 pla
    old "Yeah... I don’t want it to be."
    new "بله... نمی‌خوام باشه."

    # say L3488 bil
    old "Last night still feels like a dream."
    new "فکر می‌کنم هنوز روشن نشده. یعنی، شب گذشته مثل رویا به نظر می‌رسه."

    # say L3489 pla
    old "It wasn’t a dream. You won. We won."
    new "این هیچ رویا نبود. تو برنده شدی. ما برنده شدیم."

    # say L3490 bil
    old "And I didn’t completely fall apart... thanks to you."
    new "و من هم کاملاً از دست نرفتم... بخاطر تو."

    # say L3491 pla
    old "You didn’t need me to win. You just needed to remember who you are."
    new "تو نیازی به من برای برنده شدن نداشتی. فقط باید یادت می‌آمد که تو کی هستی."

    # say L3492 bil
    old "Still... having you there made it feel possible."
    new "البته... اما وجود تو آن را ممکن ساخت."

    # say L3494 bil
    old "I don’t usually do the whole ‘morning after’ thing."
    new "معمولاً من این جوری «صبح بعد» رو نمی‌کنم."

    # say L3495 pla
    old "Neither do I... but I’m really glad we did."
    new "من هم معمولاً اینجوری نیستم... ولی خوشحالم که اینجوری شد."

    # say L3496 bil
    old "Don’t get used to it, though. I’m still the same Billie."
    new "البته، ولی نباید بهش عادت کرد. هنوز هم همان بیلی هستم."

    # say L3497 pla
    old "Good. I like that Billie."
    new "خوب. من همچین بیلی‌ای دوست دارم."

    # say L3499 bil
    old "You should probably head home before your family starts asking questions."
    new "شاید بهتره قبل از اینکه خانوادت سؤالاتی بپرسن، به خونه بری."

    # say L3501 pla
    old "But last night... everything we did, everything we said..."
    new "اما شب گذشته... همه چیزی که انجام دادیم، همه چیزی که گفتیم..."

    # say L3502 pla
    old "It meant a lot to me."
    new "برای من خیلی مهم بود."

    # say L3504 bil
    old "It meant a lot to me too."
    new "من هم خیلی مهم بود."

    # say L3505 bil
    old "I’m not great at saying this stuff, but... thank you. For not giving up on me. For pushing me. For staying."
    new "من خوب در این جور چیزها قوی نیستم، اما... ممنونم. برای اینکه روی من تسلیم نشدی. برای اینکه منو تشویق کردی. برای اینکه موندی."

    # say L3508 bil
    old "Alright, we better get dressed."
    new "باشه، بهتره لباس پوشیم."

    # say L3515 pla
    old "I’ll see you at school later?"
    new "بعداً در مدرسه می‌بینیم؟"

    # say L3516 bil
    old "Yeah... I’ll be there."
    new "بله... من هم اونجا خواهم بود."

    # say L3517 bil
    old "And don’t be late, or I’ll drag you back here again."
    new "و دیر نباش، یا دوباره تو رو اینجا می‌آرم."

    # say L3518 pla
    old "Wouldn’t miss it."
    new "حتماً نمی‌گذaram."

    # say L3524 pla
    old "Take care of yourself, Billie."
    new "دقت کن به خودت، بیلی."

    # say L3525 bil
    old "You too."
    new "تو هم همین‌طور."

    # say L3530 bil
    old "({i}He really stayed... and I didn’t push him away.{/i})"
    new "{i}وایقی مونده... و منش رو نخاستم زیر چشمم.{/i}"

    # say L3531 bil
    old "I guess I know what it means..."
    new "بازی به نظر می‌رسه... منظورت رو متوجه شدم."

    # say L3551 pla
    old "Alright... time for some practice."
    new "باشه... الان وقت تمرین هست."

    # say L3553 pla
    old "It’s becoming part of the routine... and I actually look forward to it."
    new "این قسمتی از روتین شده... و من واقعاً منتظرش می‌شوم."

    # say L3574 pla
    old "Feels natural now... like the guitar is actually listening."
    new "الان طبیعی است... مثل اینکه گیتار واقعاً به من گوش می‌ده."

    # say L3605 pla
    old "Still a couple of rough spots... but overall it sounded solid."
    new "هنوز چند نقطه خشن داره... اما کل کار صدای خوبی داشت."

    # say L3607 pla
    old "It doesn’t feel like a chore anymore. It feels... right."
    new "بیشتر مثل کار سختی نیست. احساس می‌کنم... درسته."

    # say L3610 pla
    old "Tomorrow I’ll pick it up again... no pressure, just playing."
    new "فردا دوباره اون رو می‌برم... فشاری نداره، فقط بازی می‌کنم."

    # say L3651 pla
    old "Yeah... I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "بله... من خودم هم خیلی تمرین کردم، ولی وقتی با تو هستم، می‌تونم سریع‌تر پیشرفت کنم."

    # menu L3663 
    old "Rehearse the song together"
    new "همراهش آهنگ رو تمرین کنیم"

    # say L3665 pla
    old "I want to polish the chords even more, you know..."
    new "می‌خوام آکورد‌ها رو هم بیشتر تکمیل کنم، میدونی..."

    # say L3666 bil
    old "Heh. Going for the safe route first? Fine by me... for now."
    new "هه. اول می‌خوای راه آسون رو ببری؟ خوب، من هم موافقم... برای حالا."

    # say L3701 bil
    old "Hmm... your changes are actually smooth now. You’ve been practicing."
    new "هم... تغییراتت در واقع حالا هموار هستن. تو خیلی تمرین کردی."

    # say L3706 bil
    old "Still... I wouldn’t mind if you picked something a little more fun next time."
    new "البته... ولی من خوشحالم اگر چیزی کمی جالب‌تر انتخاب کنی بعداً."

    # menu L3708 
    old "Finger practice"
    new "تمرین انگشتان"

    # say L3743 pla
    old "They’re... so soft every time. I can feel them filling my hands."
    new "آنها... هر بار خیلی نرم هستند. می‌تونم احساس کنم توی دستم پر می‌شنن."

    # say L3744 bil
    old "Mmm... squeeze them slowly. Open and close your hands... just like that."
    new "می‌تونی آهستون به آهستون فشار بدی. دستت رو باز و ببند... همینطور."

    # say L3747 bil
    old "Nngh— yeah... a little harder now. Grip them properly."
    new "نه— بله... حالا یک کم سخت‌تر. اونا رو خوب بگیر."

    # say L3750 bil
    old "Fuck... keep that pace. Squeeze them like you mean it."
    new "بیل: فکر کنم... این سرعت رو حفظ کن. آره، همینطور فشار بدی."

    # say L3753 bil
    old "Now the nipples... grab them and pull... slow at first."
    new "حالا نیپل‌ها... اونا رو بگیر و بکش... اول آرام آرام."

    # say L3764 bil
    old "That’s it... stretch them gently."
    new "این‌جاست... آنها را به آرامی کشش."

    # say L3772 bil
    old "Fuck... faster. Pull them nice and firm. I love how confident your hands feel now."
    new "فکر کنم... سریع‌تر. با این قدر محکم بکش. عاشق‌ام این احساس اطمینان در دستت."

    # say L3777 bil
    old "Mmm... your touch is way more precise lately. You’ve improved a lot."
    new "ممنون... لمست اخیراً دقیق‌تر شده. خیلی پیشرفت کردی."

    # say L3779 bil
    old "Keep practicing that rhythm at home... or just come back whenever you want more of... this."
    new "در خونه این ریتم رو تمرین کن... یا فقط هر وقت می‌خوای بیشتر از... این، برگرد."

    # menu L3781 
    old "Advanced finger practice"
    new "تمرین انگشت پیشرفته"

    # say L3801 pla
    old "Uhh... I’ve been practicing the guitar a lot by myself lately."
    new "اوه... اخیراً خیلی تمرین گیتار می‌کنم."

    # say L3802 pla
    old "And I was thinking... maybe it would be good if I helped you with your practice too, you know?"
    new "و من فکر می‌کنم... شاید خوب باشه اگه من هم به تمریناتت کمک کنم، می‌فهمی؟"

    # say L3803 pla
    old "Like... helping you stay steady under pressure... like last time..."
    new "مثلاً... کمکت کنم تا زیر فشار هم مثل آخرین بار ثابت باشی..."

    # say L3804 bil
    old "Heh... look at you trying to be all subtle."
    new "هه... نگاهت به تو که می‌تونی همه چی رو پوشش بدی."

    # menu L3826 
    old "Get motivated"
    new "الهام بگیر"

    # say L3828 pla
    old "And sometimes I feel like I still need... a little extra motivation to keep improving."
    new "و بعضی مواقع حس می‌کنم هنوز به یه تحریک کوچیک نیاز دارم تا بهتر شوم."

    # say L3829 bil
    old "Heh... so that’s what this is really about."
    new "هه... پس این واقعاً درباره این هست."

    # say L3834 bil
    old "Just looking at them... does that help?"
    new "نگاه کردن به اونا... این کمک می‌کنه؟"

    # say L3836 pla
    old "Y-yeah... they look amazing but... I was thinking maybe something more... direct?"
    new "بله... لباس‌هایشون عالی هستن ولی... فکر می‌کنم شاید چیزی مستقیم‌تر کمک کنه؟"

    # say L3839 bil
    old "Heh... fine. I know exactly how to motivate you properly."
    new "هه... خوب. من دقیقاً می‌دونم چطور باید تو رو تحریک کنم."

    # say L3859 bil
    old "Phew... that’s enough for today."
    new "پوف... این قدر برای امروز کافیه."

    # say L3861 bil
    old "Hey... before you go."
    new "هی... قبل از برخاستن."

    # say L3865 bil
    old "It’s important... and I don’t want to go alone."
    new "این مهمه... و نمی‌خوام تنهایی برسم."

    # say L3875 bil
    old "Oh, by the way..."
    new "بیل: اوه، بین‌الناحیه..."

    # say L3887 bil
    old "Just text me. I’ll always make time... especially if you want the fun version."
    new "بله، فقط پیام بده. همیشه وقت می‌تونم بذارم... خصوصاً اگه نسخه سرگرمی‌آمیز رو بخوای."


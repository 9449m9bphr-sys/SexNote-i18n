# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Garage.rpy
translate persian strings:

    # say L23 pla
    old "Hello. I just came to know if you need more magic power?"
    new "سلام. فقط خواستم ببینم آیا نیازی به توان جادویی بیشتری داری؟"

    # say L25 mil
    old "I think I have enough. Thank you..."
    new "من فکر می‌کنم کافی دارم. ممنون..."

    # say L27 pla
    old "Oh come on. In our deal you were supposed to receive magical power from me, so don't worry."
    new "بیا بیا، تو توی قرار ما بودی قدرت جادویی از من بگیری، نگن جلو."

    # say L29 mil
    old "Hmm, okay, I'll visit you tonight to get a little more magic."
    new "Hmm، خوب، امشب می‌آیم تا یه کم جادوی بیشتر بگیرم."

    # say L31 pla
    old "Great, it's good for us to help each other..."
    new "عالی، خوشحالم که به هم کمک می‌کنیم..."

    # say L33 mil
    old "Ok, see you tonight."
    new "باشه، امیدوارم تو رو شب ببینم."

    # menu L43 
    old "Ask for Magic Power"
    new "بپرس از قدرت جادویی"

    # say L45 pla
    old "Hello! I wanted to know if you have any magic power to share with me. You know, to keep improving my skills..."
    new "سلام! می‌خواستم بدونم آیا قدرت جادویی‌ای برای به اشتراک گذاشتن با من داری. می‌دونی، برای اینکه مهارت‌هام رو همچنان بهبود ببخشم..."

    # say L49 mil
    old "Well, if you really need it I have some magic power for you."
    new "اگر واقعاً نیاز داری، برایت قدرت جادویی دارم."

    # say L51 pla
    old "Thank you. I really appreciate it."
    new "ممنون. خیلی از این قدردانی می‌کنم."

    # say L53 mil
    old "Don't mention it. This was part of our deal"
    new "خواهش می‌کنم. این بخشی از قرار ما بود."

    # say L57 mil
    old "Ok, I'm ready. Let's do it."
    new "خوب، آماده‌ام. بیایم انجام بدیم."

    # say L59 pla
    old "Alright, alright..."
    new "باشه، باشه..."

    # say L68 mil
    old "Sorry, but I don't have enough to share for now..."
    new "ببخشید، ولی الان ندارم چیزی برای تو."

    # say L70 pla
    old "Oh ok. No problem. I will come later."
    new "اوه خب. مشکلی نداره. بعداً می‌آیم."

    # say L72 mil
    old "Bye."
    new "باید"

    # say L96 pla
    old "Oh come on. In our deal you were supposed to get magical power from me, I'll take care of you."
    new "بیا بیا، تو توی قرار ما باید از من قدرت جادویی دریافت کنی، من هم می‌تونم بهت کمک کنم."

    # say L98 gom
    old "Mmm, okay. I'll visit you tonight to get a little more magic."
    new "ممنون، خب. امروز شام برات می‌آیم تا یه کم جادوی بیشتر بگیرم."

    # say L100 pla
    old "Great,I like helping you..."
    new "عالی، دوست دارم به تو کمک کنم..."

    # say L114 pla
    old "Hello! I wanted to know if you have any magic power to share with me You know, to keep improving my skills..."
    new "سلام! می‌خواستم بدونم آیا قدرت جادویی برای به اشتراک گذاشتن با من داری. می‌دونی، برای اینکه مهارت‌هام رو همچنان بهبود ببخشم..."

    # say L118 gom
    old "Yes I have some magic power to give you."
    new "بله، من برایت قدرت جادویی دارم."

    # say L120 pla
    old "Oh, sweet. Thank you!"
    new "اوه، عزیزم. ممنون!"

    # say L122 gom
    old "No problem, your progress benefits us all"
    new "هیچ اشکالی ندارم، پیشرفت تو به همه ما مفید است"

    # say L126 gom
    old "Are you ready?."
    new "آماده‌ای؟"

    # say L128 pla
    old "Yes! Let's get to it..."
    new "بله! بیایم شروع کنیم..."

    # say L140 pla
    old "Oh, ok. No worries. I will come later."
    new "اوه، خب. نگران نباش. من بعداً می‌آیم."

    # say L142 gom
    old "Buh bye."
    new "بای بای"

    # say L163 pla
    old "Hi there, I just came to know if you need more magic power?"
    new "سلام، فقط خواستم ببینم آیا نیاز به توان جادویی بیشتری داری؟"

    # say L165 dev
    old "Well, maybe I might need a little..."
    new "خب، شاید کمی نیاز داشته باشم..."

    # say L167 pla
    old "Great, in that case visit me tonight so I can give you some magical power..."
    new "عالی، در این صورت امشب به من بیا تا بتونم به تو قدرت جادویی بدم..."

    # say L169 dev
    old "With pleasure! I'll see you tonight..."
    new "با لذت! امشب می‌تونی به من بیا..."

    # say L181 pla
    old "Hey! I wanted to know if you have any magic power to share with me. I want to keep improving my skills..."
    new "هی! می‌خواستم بدونم آیا قدرت جادویی برای به اشتراک گذاشتن با من داری. می‌خوام مهارت‌هام رو همچون بیشتر بهبود بدم..."

    # say L184 dev
    old "Of course! I have plenty to share with you."
    new "البته! خیلی چیزهایی برای به اشتراک گذاشتن با تو دارم."

    # say L188 dev
    old "You can ask me whenever you want. Whenever I have enough I will give it to you..."
    new "می‌تونی هر وقت خواستی از من بپرسی. هر وقت کافی داشتم به تو می‌دم..."

    # say L190 pla
    old "Nice! Thank you."
    new "عالی! ممنون."

    # say L198 dev
    old "Hmmm... Unfortunately, I don't have enough right now..."
    new "همم... متاسفانه الان کافی ندارم..."

    # say L200 dev
    old "However, look for me in a couple of days and I will have accumulated more to give you..."
    new "البته، چند روز دیگر به من نگاه کن، بیشتری برای دادن به تو جمع کرده خواهم بود..."

    # say L202 dev
    old "Or... You could also share with me and I'll give it back to you, just for the fun of sharing... Hehe"
    new "یا... می‌تونی هم منو سهیم کنی و من برایت برگردونم، فقط برای لذت سهیم شدن... هه هه"

    # say L204 pla
    old "Oh, don't worry, it's really nothing urgent."
    new "اوه، نگران نباش، واقعاً اونقدر ضروری نیست."

    # say L206 dev
    old "Oh... Ok then."
    new "اوه... خب خوب."

    # menu L226 
    old "Magic Power"
    new "تویی قدرت جادویی چیه؟"

    # menu L230 
    old "What is the Magic Power?"
    new "چیزی که به اسم قدرت جادویی می‌شناسن، اون همچین چیه؟"

    # say L232 bri
    old "Well, Magical power is an energy that was produced naturally in the magical world..."
    new "خب، قدرت جادویی یک انرژی بود که به طور طبیعی در دنیای جادویی تولید می‌شد..."

    # say L234 bri
    old "After its destruction all that magical energy ended up in the human world, the problem is that now it does not reproduce anymore..."
    new "بعد از نابودی همه آن انرژی جادویی به دنیای انسانی رسید، مشکل اینجاست که حالا دیگر تولید نمی‌شود..."

    # say L236 bri
    old "Only the remains of great magical sources, and all magical beings that once existed will be extinguished forever..."
    new "فقط باقی‌مانده‌های منابع جادویی بزرگ و تمام موجودات جادویی که قبلاً وجود داشتند برای همیشه منقرض خواهند شد..."

    # say L238 pla
    old "Ok, I understand it better now."
    new "خب، حالا بهتر متوجه شدم."

    # say L240 bri
    old "Great! What else do you want to know?"
    new "عالی! هنوز چیز دیگری می‌خوای بدونی؟"

    # menu L247 
    old "How to get Magic Power?"
    new "چطور توانایی جادویی رو به دست بیارم؟"

    # say L249 bri
    old "You have in fact 4 ways..."
    new "در واقع ۴ راه داری..."

    # say L250 bri
    old "1. Picking up in each place with the agamoto's eye."
    new "۱. جمع‌آوری در هر مکان با چشم اگاماتو."

    # say L251 bri
    old "2. Using Ayax's hand and automatically picking up when moving between locations."
    new "۲. از دست آیاکس استفاده کن و خودت رو هنگام حرکت بین مکان‌ها جمع کن."

    # say L252 bri
    old "3. Having high levels of arousal caused by sexual activity with women."
    new "سطح‌های بالایی تحریک جنسی ناشی از فعالیت جنسی با زنان."

    # say L253 bri
    old "4. Ask me to share you with my magical power!"
    new "به من بپرس تا با قدرت جادویی‌ام با تو در اشتراک بگذارم!"

    # say L255 pla
    old "Ok, interesting..."
    new "خب، جالب است..."

    # say L257 bri
    old "My favorite is the last one, but only when you share with me yours too..."
    new "مورد عزیزم آخریه، ولی فقط وقتی تو هم با من در می‌آیی..."

    # say L259 pla
    old "Yes, I know..."
    new "بله، می‌دونم..."

    # say L261 bri
    old "Well, What else do you want to know?"
    new "خب، چیز دیگه‌ای می‌خوای بدونی؟"

    # menu L272 
    old "Spells"
    new "توپ‌ها"

    # menu L276 
    old "Agamoto's Eye"
    new "چشم آگامتو"

    # say L278 bri
    old "Agamoto was one of the most powerful magicians who specialized in ocular power."
    new "آگاماتو یکی از قدرتمندترین جادوگران بود که تخصصش در قدرت‌های چشمی بود."

    # say L280 bri
    old "They say that his power even came to see the soul and thoughts of any being."
    new "می‌گن که قدرتش حتی به جایی رسید که روح و افکار هر موجودی رو ببینه."

    # say L282 bri
    old "That is why Agamoto is a power of vision that allows you to see the dimension of the magical world and see beyond the objects of the real world."
    new "این به همین خاطر است که اگاموتو قدرتی برای دیدن است که به تو اجازه می‌دهد بعد از جهان سحر و فراتر از اشیاء دنیای واقعی نگاه کنی."

    # say L284 pla
    old "Wow Really?"
    new "واو، واقعاً؟"

    # say L286 bri
    old "Yes, you should try it, you could only see through easy things like clothes, try using it on someone to see through their clothes."
    new "بله، باید امتحانش کنی، فقط اشیای ساده مثل لباس‌ها رو ببینی، روی کسی استفاده کن تا از طریق لباس‌شون ببینی."

    # say L288 pla
    old "Ok ok, I'm going to try it..."
    new "باشه باشه، من می‌خوام امتحانش کنم..."

    # menu L297 
    old "Ayax's Hand"
    new "دست آیاکس"

    # say L299 bri
    old "Ayax was one of the greatest thief magicians in history."
    new "آیاکس یکی از بزرگترین دزد و جادوگر تاریخ بود."

    # say L301 bri
    old "He reached the point of being able to turn his body into a magnet for valuables."
    new "او به نکته‌ای رسید که می‌تونست بدنش رو به مغناطیسی برای ارزشمندی‌ها تبدیل کنه."

    # say L303 bri
    old "Ayax's hand is basically this power that he achieved, with which you can automatically attract the magical power of the area where you are."
    new "دست ایاکس اساساً قدرتی هست که به دست آورده، با اون می‌تونی به طور خودکار قدرت جادویی منطقه رو جذب کنی."

    # say L306 pla
    old "Wow, interesting..."
    new "واو، جالب..."

    # say L308 bri
    old "What else do you want to know?"
    new "بیشتر چی می‌خوای بدونی؟"

    # menu L316 
    old "Sauron's Mouth"
    new "من خودم ساورون رو نمی‌شناسم، اما به نظر می‌رسه دهانش تأثیر خیلی قوی داشته."

    # say L318 bri
    old "Sauron was one of the greatest political influencers in the magical world."
    new "سورون یکی از بزرگترین تأثیرگذاران سیاسی در جهان جادویی بود."

    # say L320 bri
    old "He managed to create a manipulative skill with his mouth with which he managed to influence everyone."
    new "او با دهانش مهارتی تحریک‌کننده ایجاد کرد که با آن می‌توانست همه را تحت تأثیر قرار دهد."

    # say L322 bri
    old "This is how the Sauron's Mouth was created, with it you can influence all kinds of beings..."
    new "این همین‌طور دهان ساورون ایجاد شد، با این دهان می‌توانی همه نوع موجودات را تحت تأثیر قرار بدی..."

    # say L324 pla
    old "Like some kind of mind control?"
    new "مثل نوعی کنترل ذهن؟"

    # say L326 bri
    old "What? Of course not, it is more an ability to influence or manipulate at certain levels, not to control the behavior."
    new "البته نه، این بیشتر یک توانایی برای تأثیر گذاری یا دستکاری در سطوح خاص است، نه کنترل رفتار."

    # say L328 bri
    old "In fact, using it does not always work and you should improve it to the fullest and have a good relationship with who you use to increase your chances..."
    new "در واقع، استفاده از آن همیشه کار نمی‌کند و باید آن را به حداکثر حد بهبود بدهی و رابطه خوبی با کسی که از او استفاده می‌کنی داشته باشی تا شانس‌هایت افزایش یابد..."

    # say L330 pla
    old "Ok, ok, understood."
    new "باشه، باشه، فهمیدم."

    # menu L339 
    old "Jamliz's Heart"
    new "قلب جملیز"

    # say L341 bri
    old "Jamliz sought for years to make a very powerful spell that he never achieved, since he always needed more magical power."
    new "جاملیز سال‌ها تلاش کرد تا جایزه‌ای بسیار قدرتمند ایجاد کند که هرگز نتوانست به آن دست یابد، زیرا همیشه به قدرت جادویی بیشتری نیاز داشت."

    # say L343 bri
    old "But, what he achieved was to increase the ability to store magical power in unthinkable amounts."
    new "اما آنچه به دست آورد، توانایی ذخیره قدرت جادویی به مقدار غیرقابل تصور را افزایش داد."

    # say L345 bri
    old "That's why the Jamliz's Heart is a skill that allows you to store more magical power in your body and thus make spells that require greater magical power."
    new "به همین خاطر قلب جملیز مهارتی است که به تو اجازه می‌دهد توانایی ذخیره توان جادویی در بدن خودت را افزایش بدی و در نتیجه توانایی انجام جادوهایی که نیاز به توان جادویی بیشتری دارند را داشته باشی."

    # say L347 pla
    old "Sounds pretty useful..."
    new "به نظر می‌تونه خیلی مفید باشه..."

    # menu L361 
    old "What I have to do?"
    new "من باید چی کنم؟"

    # say L363 bri
    old "The first thing you should do is improve your skills to the fullest. So obviously, you must get magical power."
    new "اولین کاری که باید بکنی اینه که مهارت‌هات رو به حداکثر برسونی. پس باید قدرت جادویی بدست بیاری."

    # say L365 bri
    old "But your main mission is to restore the magical world and with this shortage of magical power the only way is for you to generate it for yourself..."
    new "اما مأموریت اصلی تو بازگرداندن جهان سحرپرستیه و با این کمبود سحر، راه تنها برای تو اینه که خودت این قدرت رو تولید کنی..."

    # say L367 bri
    old "So you should seek to reach the highest level of sexual arousal. Experimenting with different women and situations to see what is most exciting for you..."
    new "پس باید به بالاترین سطح تحریک جنسی دست یابی. با آزمایش با زنان مختلف و وضعیت‌های متفاوت ببین چه چیزی برایت شگفت‌آورتر است..."

    # say L369 bri
    old "And have a lot of sex with many women to increase your power and gradually restore the power of the magical world!"
    new "و با بسیاری از زنان جنسیت کن تا توانایی خودت رو افزایش بدی و به تدریج قدرت دنیای جادویی رو بازگردانی کنی!"

    # say L371 pla
    old "You do know that is not that easy, right?"
    new "می‌دونی اینقدر آسونه نیست، درسته؟"

    # say L373 bri
    old "Don't worry. You can gradually acquire more skills that you can use in the real world to make things easier for you..."
    new "نگران نباش. می‌تونی تدریجا مهارت‌های بیشتری بدست بیاری که بتونی تو جهان واقعی استفاده کنی و کار رو برای خودت آسون‌تر کنی..."

    # say L375 bri
    old "For now you can progress little by little with some women and see if you can get very horny!"
    new "برای حالا می‌تونی با برخی زنان کم کم پیشرفت کنی و ببینی می‌تونی خیلی خیال‌پردازی کنی!"

    # say L377 pla
    old "Hmmm... Ok, I'll see how to do something about it."
    new "Hmm... بله، ببینم چطور می‌تونم کارشو انجام بدم."

    # say L416 pla
    old "I finally found you!"
    new "در نهایت تو را پیدا کردم!"

    # say L423 dev
    old "WHAT DO YOU WANT FROM US?"
    new "تو از ما چه می‌خوای؟"

    # say L425 pla
    old "I just want to talk..."
    new "من فقط می‌خوام صحبت کنم..."

    # say L428 gom
    old "Where is your shinigami friend?"
    new "شینیگامیت کجاست؟"

    # say L430 pla
    old "She is not here, I came alone... I just want to clarify that everything was a misunderstanding..."
    new "او اینجا نیست، من تنها آمدم... فقط می‌خوام بگم که همه یه سوء تفاهم بود..."

    # say L432 pla
    old "I did not destroy the magical world..."
    new "من جهان سحر را نابود نکردم..."

    # say L434 mil
    old "We know that, you didn't destroy the magical world..."
    new "ما این رو می‌دونیم، تو جهان سحرآمیز رو نابود نکردی..."

    # say L436 pla
    old "That's right!, I didn't..."
    new "درسته! من نه..."

    # say L440 pla
    old "What? No... I think you are confused "
    new "چه؟ نه... فکر کنم تو اشتباه می‌کنی"

    # say L442 mil
    old "Kid, we are over 300 years old, and you how many? 18? We know all from the magical and human world. "
    new "بچه، ما بیش از ۳۰۰ ساله‌ایم، تو چند ساله؟ ۱۸؟ ما همه چیز رو از جهان جادویی و انسانی می‌دونیم."

    # say L444 pla
    old "But... Brixxida knows nothing about the destruction of the magical world..."
    new "ولی... بریکسیدا هیچ چیزی در مورد تخریب جهان سحرآمیز نمی‌دونه..."

    # say L446 gom
    old "Doesn't know or doesn't want to tell you? Why do you think she needs you? "
    new "نمی‌دونه یا نمی‌خواد به تو بگه؟ چرا فکر می‌کنی به تو نیاز داره؟"

    # say L448 pla
    old "To restore the magical world?"
    new "برای بازگرداندن جهان سحر؟"

    # say L450 dev
    old "And if she wants to restore the magical world why is she alone? Why there are no more shinigamis with her, like us? "
    new "اگه می‌خواد جهان جادویی رو برگردونه چرا تنها هست؟ چرا هیچ شینیگامی دیگه باشون نیست، مثل ما؟"

    # say L452 pla
    old "Well, I don't know..."
    new "خب، من نمی‌دونم..."

    # say L454 mil
    old "Who you have by your side is probably one of the most powerful being in the universe and you don't know her real intentions, you must be very careful..."
    new "این که چه کسی کنار تو هست احتمالاً یکی از قدرتمندترین موجودات کیهونه و تو نمی‌دونی اهداف واقعیش چیه، باید خیلی محتاط باشی..."

    # say L456 pla
    old "But she has only helped me..."
    new "ولی او فقط به من کمک کرده..."

    # say L458 dev
    old "We don't know what she may want from you... But she was who destroy the magic world..."
    new "ما نمی‌دونیم از تو چه چیزی می‌خواد... ولی همین او بود که جهان سحر رو نابود کرد..."

    # say L460 pla
    old "And how do I know that it is not you who want to deceive me?"
    new "و چطور می‌دونم که تو نمی‌خوای از من بازی بگیری؟"

    # say L462 mil
    old "You don't have to believe us, we're not asking you anything, just let us try to survive, that's all..."
    new "باور ما رو نکن، هیچ چیز از تو نمی‌خوایم، فقط بیای و بگذاریم زنده بمانیم، همین هست..."

    # say L464 pla
    old "Ok, I want to propose something to you, I will be in charge of sharing magical power to all of you."
    new "باشه، من می‌خوام چیزی به تو پیشنهاد کنم، من مسئول تقسیم قدرت جادویی با همه شما خواهم بود."

    # say L466 pla
    old "I mean, you can come and collect magic power from me so you won't disappear..."
    new "من می‌تونم بگم، می‌تونی از من به سر میون بیاد و قدرت جادویی رو جمع کنی تا نمی‌چرخی..."

    # say L470 mil
    old "Thank you, but we don't need it..."
    new "ممنون، اما ما نیازی بهش نداریم..."

    # say L472 pla
    old "Oh come on, I have the SexNote, I have several skills that have allowed me to collect magical power quickly and efficiently."
    new "بیا بیا، من SexNote رو دارم، چند تا مهارت هم دارم که بهم کمک می‌کنه تا انرژی جادویی رو به سرعت و با کارایی جمع کنم."

    # say L474 pla
    old "And... I can also generate magical power by myself..."
    new "و... من هم می‌تونم خودم توان جادویی رو تولید کنم..."

    # say L476 pla
    old "And you have less and less magical power left..."
    new "و تو هم مگر قدرت جادوییت رو کمتر و کمتر می‌تونی تامین کنی..."

    # say L478 gom
    old "What do you want in return?"
    new "تو به جاش چه می‌خوای؟"

    # say L480 pla
    old "Nothing, I just want to help in whatever I can..."
    new "هیچی، فقط می‌خوام هر چه بتوانم کمک کنم..."

    # say L482 mil
    old "Will you still collect magical power from the whole area?"
    new "همچنان قدرت جادویی رو از سراسر منطقه جمع می‌کنی؟"

    # say L484 pla
    old "Well, with Ayax's Hand I automatically gather the magical power where I move..."
    new "خب، با دست آیاکس من خودکار جادویی رو جایی که حرکت می‌کنم جمع می‌کنم..."

    # say L486 pla
    old "But that's why whenever you need it you can go at night and suck up magical power from me..."
    new "ولی همین جلبه، هر وقت نیاز داری بیا شب‌ها و از من انرژی جادویی بگیر..."

    # say L488 dev
    old "Hmmm... Okay, but we'll just take what is necessary..."
    new "Hmm... خب، ولی فقط آنقدر که لازم داریم می‌گیریم..."

    # say L490 mil
    old "And we will return what we do not need, so you can look for us to receive magic power that we don't need..."
    new "و آنچه نیاز نداریم برگردانیم، پس می‌توانی از ما به جای آن قدرت جادویی که نیاز نداریم دریافت کنی..."

    # say L492 gom
    old "It really suits us that you rebuild the sources of magic power production..."
    new "این واقعاً برای ما مناسب است که شما منابع تولید قدرت جادویی را بازسازی کنی."

    # say L494 mil
    old "And that's why we will help you, so you you can find out about Brixxida's true intentions, and we will help you gather the magic power that remains."
    new "و برای همین ما به تو کمک می‌کنیم تا در مورد نیت‌های واقعی بریکسیدا اطلاعات جمع کنی و ما به تو در جمع‌آوری قدرت سحر باقی‌مانده کمک می‌کنیم."

    # say L496 pla
    old "Okay, I'll go as far as I can and find out if Brixxida really has bad intentions or not..."
    new "باشه، تا جایی که می‌تونم برای فهمیدن اینکه Brixxida واقعاً قصد بدی داره یا نه، تلاش می‌کنم..."

    # say L498 gom
    old "You must be careful, she is much smarter and more powerful than she seems..."
    new "باید محتاط باشی، او خیلی هوشمندتر و قدرتمندتر از آنچه به نظر می‌رسد..."

    # say L500 dev
    old "You must act without raising suspicion..."
    new "باید بدون اینکه شک برانگیزی کنی عمل کنی..."

    # say L502 mil
    old "And above all be careful that she does not find out about our deal..."
    new "و مهم‌تر از همه مراقب باش که او در مورد توافق ما مشکوک نشود..."

    # say L504 pla
    old "Okay, I'll keep that in mind... But then, where will I find all of you?"
    new "باشه، اینو در نظر می‌گیرم... ولی بعدش، شما رو از کجا باید پیدا کنم؟"

    # say L506 mil
    old "I will continue in the school zone..."
    new "من در منطقه مدرسه ادامه خواهم داد..."

    # say L508 gom
    old "I'll be in the house, where you found me..."
    new "من در خونه خواهم بود، جایی که من رو پیدا کردی..."

    # say L510 dev
    old "And you will find me here, that's how we split this little town..."
    new "و تو می‌تونی من رو اینجا پیدا کنی، همین‌طور تقسیم کردیم این شهر کوچیک..."

    # say L512 pla
    old "Perfect, if you need to collect more magical power, you know where to find me..."
    new "پرفکت، اگه نیاز به جمع‌آوری توان جادویی بیشتری داشتی، میدونی کجایی می‌تونی من رو پیدا کنی..."

    # say L514 mil
    old "Okay... I think it's all for now, so we will be leaving..."
    new "باشه... فکر کنم همه‌ی این‌جاست، پس ما می‌رویم..."

    # say L518 gom
    old "You know where to find me... we'll be seeing each other [pla]"
    new "میدونی کجایی می‌تونی منو پیدا کنی... به هم می‌بینیم [pla]"

    # say L523 dev
    old "Wait! before you go, I want to start our deal..."
    new "انتظار دارم! قبل از برخاستن، می‌خوام توکارمون رو شروع کنم..."

    # say L525 dev
    old "after all, I have collected the most magical power from you and have not returned any of it to you..."
    new "بعداً، من قدرت جادویی بیشتری از تو جمع کردم و هیچ‌کدام را به تو برگرداندم..."

    # say L527 pla
    old "No, no, it is not necessary..."
    new "نه، نه، لازم نیست..."

    # say L532 dev
    old "I see it as a way to close the deal and you have already received magical power from all but me..."
    new "من این رو به عنوان راهی برای تمام کردن معامله می‌بینم و تو قدرت جادویی از همه به جز من دریافت کردی..."

    # say L534 pla
    old "Hmm... alright, If it's fine for you."
    new "Hmm... خب، اگه برای تو مشکلی نداره."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/WhiStory.rpy
translate persian strings:

    # say L9 rub
    old "What the fuck? I just can't believe it!"
    new "چه خبره؟ نمی‌تونم باور کنم!"

    # say L10 oli
    old "Ruby please! Just listen to me."
    new "رubic لطفاً! فقط به من گوش کن."

    # say L11 rub
    old "Listen, to what?"
    new "بگو، به چی گوش می‌دم؟"

    # say L18 rub
    old "What explanation could you possibly have to go around making friends with that loser?!"
    new "چه توضیحی می‌تونی برای این بده که با آن ناکام دوست شدی؟!"

    # say L19 oli
    old "You don't understand, I need his help, my grades have been low."
    new "تو نفهمی، من به کمکش نیاز دارم، نمره‌هایم پایین بوده."

    # say L20 oli
    old "So, he's going to help me study for my tests. If he doesn't I'll fail my classes."
    new "پس، او می‌خواد به من در آمادگی امتحانات کمک کنه. اگه نکنه، از کلاس‌هام خارج می‌شم."

    # say L21 rub
    old "And? Who cares?! You can't just hang out with that disgusting nerd!"
    new "و؟ چه کاری! نمی‌تونی فقط با همین نرم‌السر وقت بگذونی!"

    # say L22 rub
    old "Listen, you better find another way other than spending time with that loser."
    new "بله، بهتره راه دیگه‌ای پیدا کنی جای گذراندن زمان با اون نابغه."

    # say L23 oli
    old "B- b- but..."
    new "ب- ب- ولی..."

    # say L27 rub
    old "Ugh, look at that, now the fucking nerds are even eavesdropping our conversations."
    new "آه، نگاه کن، حالا حتی این خرده‌های مطالعه‌کننده هم به گپ‌مون گوش می‌دن."

    # say L33 oli
    old "But Ruby! Wait!"
    new "ولی رووبی! صبر کن!"

    # say L48 pla
    old "Oh hey Mike, what's up?"
    new "اوه هی مایک، چطوری؟"

    # say L49 mik
    old "Hmph..."
    new "همف..."

    # say L62 bel
    old "Hmm, that was weird."
    new "Hmm، این خیلی عجیب بود."

    # say L63 pla
    old "Yeah, it was. What's up with him, is he angry about something?"
    new "بله، بود. اون چه کار داره، از چی خشم‌داره؟"

    # say L65 bel
    old "Well, now that you mention it. He's been acting odd recently."
    new "البته، حالا که می‌گی‌ای. اخیراً رفتارش عجیب بوده."

    # say L66 bel
    old "I don't really know why though."
    new "من واقعاً نمی‌دونم چرا."

    # say L68 pla
    old "Hmm, I see. I guess I'll have to speak with him."
    new "Hmm، من هم اینجور فکر می‌کنم. باید باشون صحبت کنم."

    # say L69 bel
    old "I think so. He'll probably tell you what's his deal."
    new "فکر کنم همین‌طوره. احتمالاً بهت می‌گه مشکلش چیه."

    # say L70 pla
    old "Yeah, well, see you later then."
    new "بale، خب، بعداً می‌بینیم."

    # say L90 whi
    old "Oh hi [pla]!"
    new "اوه سلام ز[pla]!"

    # say L91 whi
    old "Uhh, what a nice surprise...It's so good to see you, how are you?"
    new "اوه، چه مفاجأه خوبی... خوشحالم که دیدمت، حالت چطوره؟"

    # say L92 pla
    old "Hi Mrs. White, nice to see you."
    new "سلام خانم وایت، خوشحالم که دیدم."

    # say L93 pla
    old "Hey, I came looking for Mike, is he around? I wanted to talk to him."
    new "سلام خانم وایت، خوشحالم که دیدم. من برای مایک اومدم، اینجا هست؟ می‌خواستم باش حرف بزنم."

    # say L94 whi
    old "Hmm, well, he is here, but... I don't think he wants to see you."
    new "هم، خب، او اینجا هست، اما... فکر نمی‌کنم بخواهد تو رو ببینه."

    # say L95 pla
    old "Really, why?"
    new "وای، چرا؟"

    # say L96 whi
    old "Well, he's been a little... Uhh, unwell these past few days, so he doesn't really want to talk to anybody."
    new "خب، او این روزها کمی... اوه، خوب نیست، پس واقعاً به هیچ‌کس نمی‌خواهد صحبت کند."

    # say L98 pla
    old "Unwell? Is he ok?"
    new "متأثره؟ او خوب است؟"

    # say L100 whi
    old "He's fine, but... Uhh, not really in a good mood."
    new "او خوبه، اما... اوه، خیلی خوشحال نیست."

    # say L101 pla
    old "Hmm, is there something I can help with?"
    new "هم، چیزی هست که بتونم کمکت کنم؟"

    # say L103 whi
    old "Listen, he asked me not to tell anybody about this. But since you're one of his best friends I'll let you know."
    new "بگوش، او از من خواسته به هیچ‌کس در مورد این موضوع نگم. اما چون شما یکی از بهترین دوستانش هستی، بهت می‌گم."

    # say L105 whi
    old "The thing is, his birthday was a couple of days ago... and nobody seemed to remember."
    new "مهمانه، تولدش چند روز پیش بود... و هیچ‌کس به نظر نمی‌رسید به یاد آن فکر کرده باشد."

    # say L106 pla
    old "Ohhh, damn! I totally forgot about it. Shit!"
    new "اوه، لعنتی! کاملاً فراموش کردم. شیطون!"

    # say L107 whi
    old "Yes well, not one of his friends gave him a call, or even said happy birthday to him."
    new "بله، هیچ‌کدوم از دوستایش بهش تلفن نکردند، حتی خوش آمدگویی نکردند."

    # say L108 pla
    old "Damn it, of course, he's angry."
    new "لعنتی، البته، او خیلی خشمگین است."

    # say L109 whi
    old "The reason I tell you this is because Mike is always talking about you, he says you're his best friend."
    new "دلیل اینکه این رو بهت می‌گم اینه که مایک همیشه در موردت صحبت می‌کنه، می‌گه تو بهترین دوستشی."

    # say L112 whi
    old "He admires you a lot, you know..."
    new "او خیلی ازت قدردانی می‌کنه، میدونی..."

    # say L113 pla
    old "D- do you think he'll talk to me if I try?"
    new "د- فکر می‌کنی اگر من امتحان کنم با من حرف بزنه؟"

    # say L114 whi
    old "Hmm, I don't really know... But I guess you can try. I actually think it would be good for him."
    new "هم، واقعاً نمی‌دونم... اما فکر کنم می‌تونی تلاش کنی. در واقع فکر می‌کنم برایش خوب باشه."

    # say L115 whi
    old "He's been really depressed lately. So, it would be good if you could help him out with that."
    new "akhirاً خیلی ناراحت بوده. پس اگر بتونی بهش کمک کنی خوب می‌شه."

    # say L117 pla
    old "Sure, sure, don't worry, I'll do my best to fix this."
    new "بله، بله، نگران نباش، خواهم تلاش کردم این مشکل رو حل کنم."

    # say L118 whi
    old "Ok,  then he's in his room. Good luck."
    new "خب، اونجایی که هست، در اتاقش. موفق باشی."

    # say L133 mik
    old "Ugh, did my mom let you in?"
    new "آخه، مامانم تو رو وارد کرده؟"

    # say L134 pla
    old "Hey man, listen, I'm really sorry. I've been dealing with some stuff, so, I forgot about your birthday."
    new "بچه، بگوش، واقعاً متاسفم. چند تا مشکل داشتم، پس فراموش کردم تولدتو."

    # say L135 pla
    old "But I totally care about it, really."
    new "ولی من واقعاً بهش اهمیت میدم."

    # say L136 mik
    old "Oh yeah, you care?"
    new "اوه بله، تو هم خیلی بهش اهمیت میدی؟"

    # say L137 mik
    old "That's funny, you seem to care a lot more about the girls' birthdays..."
    new "می‌تونی خنده‌دار باشی، به نظر می‌رسه تو خیلی بیشتر از تولد دختر‌ها نگرانی داری..."

    # say L138 mik
    old "But I guess it's no surprise since I'm always the one who's left out..."
    new "ولی حدس می‌زنم شگفت‌زده نباشم، همیشه من هستم که از همه چیز خارج می‌شوم..."

    # say L139 pla
    old "Aww, come on dude, you know it's not like that."
    new "بیا بیا دوست من، می‌دونی اینجوری نیست."

    # say L140 pla
    old "It's just that recently I've been kinda busy."
    new "اخیراً من یه کم مشغول بودم."

    # say L141 mik
    old "Yeah, yeah, yeah, you're always busy. I get it, you're Mr. important."
    new "بله، بله، بله، تو همیشه مشغولی. چیزی متوجه شدم، خودت مهمی."

    # say L142 pla
    old "Hey Mike, come on man, listen to me."
    new "مایک، بیا بیا، بگوش به من."

    # say L143 mik
    old "No! You listen. It's just unbelievable man, like, wow."
    new "نه! تو بگوش. واقعاً باور نمی‌کنم، مثل اینکه وای."

    # say L144 mik
    old "You know, I've always been there for you when you needed it!"
    new "می‌دونی، همیشه وقتی نیازت بود من پشت تو بودم!"

    # say L146 pla
    old "I know dude, I'm sorry."
    new "می‌دونم داداش، ببخش."

    # say L148 mik
    old "You know what? It's ok, it's not like it's the first time anyway. So I'm used to it. I really don't have any friends."
    new "می‌دونی چی؟ خوبه، همینطور نیست که اولین باره. پس عادت کردم. واقعاً هم دوستی ندارم."

    # say L149 pla
    old "Hey don't say that, you know very well I'm your friend."
    new "بیا نگو اینجوری، خوب می‌دونی من دوستت هستم."

    # say L150 pla
    old "And what do you mean it's not the first time, it was just this year that I forgot your birthday."
    new "و منظورت از این نیست اولین باره چیه؟ همین سال که تولدتو فراموش کردم."

    # say L151 mik
    old "Oh shut up! I'm not talking about my birthday. Remember Halloween?"
    new "بسته شو! من درباره تولدمو نیستم. به هالوین یادت باشه؟"

    # say L152 mik
    old "When we were playing that game you guys made fun of me. And had me leave with that stupid challenge."
    new "وقتی آن بازی رو باز می‌کردیم شما همه به من خنده می‌زدید. و منو با آن چالش خنده‌دار مجبور کردید برم."

    # say L153 mik
    old "Of course, you didn't want me there."
    new "البته، نمی‌خواستی من اونجا باشم."

    # say L156 pla
    old "Listen dude..."
    new "بگو داداش..."

    # say L157 mik
    old "Shut up! Keep your excuses to yourself."
    new "بسته! عذرت‌هایت رو برای خودت بسپار."

    # say L158 mik
    old "And get the hell out of here. I'm busy."
    new "و بره از اینجا. من مشغولم."

    # say L159 pla
    old "Mike, please, calm down."
    new "مایک، لطفاً آرام شو."

    # say L160 pla
    old "Thinking about it, I can see your point, you're absolutely right."
    new "می‌تونم ببینم نکته‌تو، همش درست می‌گی."

    # say L161 pla
    old "I've been a really shitty friend."
    new "من واقعاً یه دوست خیلی بد بودم."

    # say L162 pla
    old "So... I'm really sorry bud, and I hope you can forgive me."
    new "پس... واقعاً متاسفم دوست من، امیدوارم بتوانی از من ببخشی."

    # say L163 mik
    old "Pfff! Get out of here!"
    new "پف! برو بره!"

    # say L164 mik
    old "Do you really think you can get out of this with a simple apology?"
    new "می‌خوای با یه عذرخواهی ساده از این بیرون بیادی؟"

    # say L165 pla
    old "Hmm... You're right... And I think I can do something to show you I'm your friend."
    new "Hmm... درست می‌گی‌ی... و فکر می‌کنم می‌تونم چیزی بکنم تا نشون بدم دوستت دارم."

    # say L166 pla
    old "And this is kinda risky, so I know you'll believe me once you see it."
    new "و این هم خطرناکه، پس می‌دونم یه بار که دیدی باورم می‌کنی."

    # say L169 pla
    old "Come with me for a second."
    new "بیا یه لحظه"

    # say L170 mik
    old "Where?"
    new "کجا؟"

    # say L171 pla
    old "I have to show you something."
    new "باید چیزی به تو نشون بدم."

    # say L172 pla
    old "Just shut up and come with me."
    new "بسته شو و با من بیا."

    # say L173 pla
    old "If afterwards you're still mad at me I'll leave you alone."
    new "اگه بعد از همه این‌ها هم هنوز به من خشمانت باشه، ازت خواهم گذاشت."

    # say L174 pla
    old "But this is worth it."
    new "اما این ارزشش رو داره."

    # say L176 mik
    old "Hmm, ok, let's go."
    new "Hmm، خوب، برویم."

    # say L192 mik
    old "What's this? Where are you taking me?"
    new "این چیه؟ تو منو کجا می‌بری؟"

    # say L193 pla
    old "It's ok dude. Just trust me, you'll like this."
    new "برو با آرامی داداش. فقط به من اعتماد کن، خوشت می‌آید."

    # say L218 mik
    old "What the fuck? This is my neighbor's house. What are we doing here?"
    new "اوه شیطون؟ این خانه همسایه‌امه. ما اینجا چی کار داریم؟"

    # say L219 pla
    old "Chill out dude. It's ok, I know her."
    new "آرام باش داداش. خوبه، من با اون آشنا هستم."

    # say L220 pla
    old "Just as I thought, If she's not here, that means she'll be probably with a customer upstairs."
    new "همانطور که فکر کردم، اگه اونجا نیست، باید احتمالاً با یه مشتری بالا باشه."

    # say L223 pla
    old "I think I can show you something worthwhile. Just hush and follow me."
    new "فکر کنم می‌تونم چیز خوبی بهت نشون بدم. فقط ساکت باش و پشت من بیا."

    # say L247 pla
    old "Great, they're in there."
    new "عالی، اونا توی اونجا هستند."

    # say L248 mik
    old "They? What's happening?"
    new "آنها؟ چه اتفاقی افتاده؟"

    # say L249 pla
    old "Listen man, this is something I'm doing only this one time."
    new "بفرما دوست من، این کار رو فقط این یک بار می‌کنم."

    # say L250 pla
    old "Take it as my birthday gift to you."
    new "بگیر این هدیه تولد من به تو"

    # say L251 pla
    old "Now come here and take a peek."
    new "بیا اینجا و یک نگاه بنداز."

    # say L260 mik
    old "Dude! Wow!"
    new "دود! وای!"

    # say L261 mik
    old "I would never have been able to see this through my telescope!"
    new "من هرگز نتونستم اینا رو با تلسکوپم ببینم!"

    # say L262 mik
    old "How did you know she does this kind of stuff?"
    new "تو چطور فهمیدی که اونجوری چیزهایی می‌کنه؟"

    # say L263 pla
    old "Just shut up and enjoy it."
    new "بسته بشه و لذت ببر ازش."

    # say L264 mik
    old "I will man, you're the best."
    new "بله برو، تو بهترین هستی."

    # say L274 mik
    old "Dude, that was the best birthday present ever!"
    new "دستت درد نکنه، این بهترین هدیه تولد بود."

    # say L275 pla
    old "Well, I'm glad you liked it."
    new "خوشحالم که لذت برده بودی."

    # say L276 pla
    old "I just wanted to say sorry again for being such a lousy friend."
    new "می‌خواستم دوباره بگم متأسفم برای اینکه یه دوست بد بودم."

    # say L277 pla
    old "And listen, man, I know you think you're all alone, but that's not true."
    new "و بگوش، دستا، میدونم فکر می‌کنی همه‌جا تنها هستی، ولی این جوری نیست."

    # say L278 pla
    old "I really do think of you as my best friend, and I'm sure the girls... Uhh, they find you as a good classmate..."
    new "من واقعاً تو رو بهترین دوستم می‌شناسم، و مطمئن هستم دختر‌ها... اوه، آنها هم تو رو به عنوان یه همکلاسی خوب می‌شناسن."

    # say L279 pla
    old "It's just that lately we all have been dealing with some stuff."
    new "البته، اخیراً همه ما با چیزهایی سر و کار داشتیم."

    # say L280 pla
    old "But I want you to know that I would never take you for granted."
    new "اما می‌خوام بدونی هرگز تو رو به سرعت نمی‌گیرم."

    # say L282 mik
    old "It's ok man, I was angry, but you've more than made up for it with that awesome gift."
    new "بفرمای، من خیلی خشمگین بودم، اما با همین هدیه عالی که دادی، خیلی خوشحالم."

    # say L283 mik
    old "It was so fucking rad."
    new "این هم خیلی راد بود."

    # say L284 pla
    old "Well I'm happy we're ok now. But I kinda have to leave."
    new "خوشحالم که حالا خوبیم. ولی باید برم."

    # say L285 pla
    old "I have to do a couple of things, but I'll swing by later."
    new "من چند کار دارم، ولی بعداً می‌آیم."

    # say L286 mik
    old "Wait, Dude!"
    new "بیا، داداش!"

    # say L288 mik
    old "Before you leave, there's something I have to ask you."
    new "قبل از بردن، چیزی هست که باید ازت بپرسم."

    # say L289 pla
    old "Hmm, sure, tell me."
    new "می‌تونی بگی، حتماً."

    # say L290 mik
    old "Hmm, the thing is... I don't really know how to say this..."
    new "هم، اونجوری که می‌گم... واقعاً نمی‌دونم چطور بگم..."

    # say L291 mik
    old "I'm gonna need you to help me study for a subject..."
    new "من نیاز دارم تو به من در یه درس کمک کنی..."

    # say L292 pla
    old "What? Haha! But you've never wanted to study with us before."
    new "چه؟ هاها! ولی تو هیچ وقت نمی‌خواستی با ما مطالعه کنی."

    # say L293 pla
    old "Why now all of a sudden?"
    new "الان چرا ناگهان؟"

    # say L295 mik
    old "It's because it's super lame."
    new "چون خیلی بی‌چینه."

    # say L296 mik
    old "But you see, this time is not really for me."
    new "اما ببین، این بار برای من خیلی مهم نیست."

    # say L297 mik
    old "I told Olivia I would help her with her studies, so I kinda have to learn the subject."
    new "من به اولیویا قول دادم که به درس‌اش کمک می‌کنم، پس باید یه کم این مبحث رو یاد بگیرم."

    # say L298 pla
    old "Oh, really? Hahahahahaha!"
    new "اوه، واقعاً؟ هahahaahaha!"

    # say L299 mik
    old "Dude! Don't laugh, this is important, ok?"
    new "دود! نخند، این مهمه، خب؟"

    # say L300 pla
    old "Heh, s- sure, sorry."
    new "هه، بله، معذرت."

    # say L302 mik
    old "Well anyway, the point is that I'm gonna need your help to learn the subjects."
    new "باز هم، مهم اینه که من به تو نیاز دارم تا درس‌ها رو یاد بگیرم."

    # say L303 mik
    old "'Cause you'll help me out, right? I mean, we're friends..."
    new "چون تو مرا کمک می‌کنی، درسته؟ بگو، ما دوست هستیم..."

    # say L304 pla
    old "*Sigh*"
    new "آه"

    # say L305 pla
    old "I mean, sure, if you really need it I'll help you out."
    new "می‌گم، حتماً، اگر واقعاً نیازت بهش هست من کمکت می‌کنم."

    # say L306 pla
    old "But dude, isn't she always super mean to us?"
    new "ولی دیو، نیست همیشه خیلی بد با ما؟"

    # say L307 pla
    old "You've heard the way she and Ruby talk to us."
    new "شما صدای حرف‌هایش و رووبی رو شنیدی."

    # say L308 pla
    old "Like... You know?"
    new "می‌دونی..."

    # say L309 mik
    old "I know, I know. But the thing is..."
    new "می‌دونم، می‌دونم. ولی چیزی هست که..."

    # say L310 mik
    old "I actually like that, a lot if I can be honest."
    new "من در واقع خوشم می‌آید، خیلی هم اگر بخواهم صادق باشم."

    # say L311 pla
    old "What? Are you for real right now?"
    new "می‌خوای همین حالا جدی باشی؟"

    # say L312 pla
    old "What could you possibly like about that?"
    new "تو از اون چی خوشت می‌آید؟"

    # say L313 mik
    old "To be honest, I don't know why, but I love it when girls are mean to me. It's so hot!"
    new "صusch، من هم نمی‌دونم چرا، ولی وقتی دخترها به من بد می‌شن، خیلی لذت می‌برم. خیلی گرم می‌شه!"

    # say L314 mik
    old "Mmm, even the other day when they were insulting us in the hallway."
    new "ممنون، حتی روزی که توی راهرو به ما توهین می‌کردند هم دوست داشتم."

    # say L315 mik
    old "Uhh man, I almost got a hard-on!"
    new "آدمم تقریباً سخت شد!"

    # say L317 pla
    old "Ok, I get it, you're a freak. But it's fine I guess."
    new "باشه، متوجه شدم، تو دیوانه‌ای. ولی خوب، فکر کنم مشکلی نداره."

    # say L318 pla
    old "Ok man, I guess I can help you, I'm not sure what you need exactly though."
    new "باشه داداش، فکر کنم می‌تونم کمکت کنم، ولی خودت هم نمی‌دونم دقیقاً چی می‌خوای."

    # say L319 mik
    old "Well, I have to give her classes on those subjects. So, something that will help me with that."
    new "خوب، من باید در اون موضوعات بهش کلاس بدم. پس چیزی که به من کمک کنه باشه."

    # say L320 pla
    old "Hmm, I think I know what we can do."
    new "Hmm، فکر کنم می‌دونم چی می‌تونیم بکنیم."

    # say L321 pla
    old "How about I give you the classes, and you just repeat them to Olivia?"
    new "می‌تونم من درس‌ها رو به تو بدم، و تو فقط همون‌ها رو به اولیویا تکرار کنی؟"

    # say L323 mik
    old "Ohh, that sounds perfect."
    new "اوه، این خیلی خوبه."

    # say L324 pla
    old "But, you're gonna have to pay a lot of attention to everything I tell you."
    new "ولی باید به همه چیزی که بهت می‌گم توجه زیادی بکنی."

    # say L325 pla
    old "After all it won't be useful if she asks you a question and you can't answer ir properly."
    new "در نهایت اگر او سؤالی از تو بپرسه و تو جواب درستشو نتونی بده، مفید نمی‌شه."

    # say L326 mik
    old "Sure, sure, sure. No problem man, I'm sure I'll learn it all."
    new "بله، بله، بله. هیچ اشکالی نداره، مطمئن هستم همه چی رو یاد می‌گیرم."

    # say L328 pla
    old "Well, with that sorted out, I'll go home. And we can meet after class to study."
    new "با این مشکل حل شدن، من برم خونه. و می‌تونیم بعد از کلاس برای مطالعه هم ملاقات کنیم."

    # say L330 mik
    old "No problem. Thank you so much dude! You're the best."
    new "هیچ اشکالی. ممنونم بسیار! خوبی تو."

    # say L332 pla
    old "Yeah, yeah, but don't be so quick to thank me. We don't know if this will work."
    new "بله، بله، ولی اینقدر سریع تشکر نکن. ما نمی‌دونیم این کار می‌کنه یا نه."

    # say L333 mik
    old "I'll do my best, I promise!"
    new "من تلاش خواهم کرد، قول می‌دهم!"

    # say L334 pla
    old "Alright, see you later."
    new "باشه، باید بعد می‌بینیم."

    # say L360 whi
    old "Hi [pla]! How are you? It's so nice to see you."
    new "سلام ز[pla]! چطوری؟ خوشحالم که شما رو دیدم."

    # say L361 pla
    old "Hi Mrs. White, nice seeing you too."
    new "سلام خانم وایت، خوشحالم که شما رو هم دیدم."

    # say L362 whi
    old "Let me tell you something. I don't know what you said to Mike."
    new "بگویم چیزی بهت. نمی‌دونم چی به مایک گفتی."

    # say L363 whi
    old "But since you two talked, he's been in a much better mood. Thank you so much for that."
    new "اما از وقتی شما دو تان صحبت کردید، او خوشحال‌تر شده. ممنونم از شما."

    # say L364 pla
    old "No problem, I'm happy we got to sort things out."
    new "نه مشکلی، خوشحالم که بتوانستیم مشکلاتمون رو حل کنیم."

    # say L365 whi
    old "You did a great job."
    new "خوب کار کردید."

    # say L366 whi
    old "So good that I've been thinking maybe I should give you a small reward."
    new "خوب همین‌جوری که فکر می‌کنم باید بهت جایزه کوچیکی بدم."

    # say L367 pla
    old "Oh, I appreciate it, but you really don't have to."
    new "البته ممنونم، ولی واقعاً لازم نیست."

    # say L368 pla
    old "I was just trying to be a good friend, and help him out."
    new "من فقط سعی داشتم یه دوست خوب باشم و بهش کمک کنم."

    # say L369 pla
    old "Also, I don't want it to be of any trouble."
    new "همچنین، نمی‌خوام مشکلی براتون بسازم."

    # say L370 whi
    old "Oh, but it's no trouble sweety, you've been very good to Mike."
    new "اوه، ولی هیچ اشکالی نداره عزیزم، تو برای مایک خیلی خوب بودی."

    # say L371 whi
    old "And I believe that deserves a good reward."
    new "و من فکر می‌کنم این باید جای یک پاداش خوب باشه."

    # say L372 pla
    old "Uhh, I'm very thankful Mrs. White, but I think I'm ok."
    new "اوه، خیلی ممنونم خانم وایت، اما فکر می‌کنم من خوب هستم."

    # say L373 pla
    old "And... uh, I kinda have to go study with Mike now, so..."
    new "و... اوه، باید حالا برای مطالعه با مایک برم، پس..."

    # say L374 whi
    old "Hmm, yeah, that's right, you two have to study. Go ahead."
    new "همم، بله، درست می‌فرمایید، شما و مایک باید مطالعه کنید. بروید."

    # say L375 whi
    old "In the meantime I'll think of something."
    new "در این میان من هم چیزی می‌فکرم."

    # say L376 whi
    old "And I'm sure you'll love it."
    new "و مطمئن هستم که دوستش خواهید داشت."

    # say L377 whi
    old "I see you later sweety."
    new "بعداً بهت می‌بینم عزیزم."

    # say L378 pla
    old "See you later Mrs. White."
    new "بعداً به شما می‌بینم خانم وایت."

    # say L389 mik
    old "Did you come to study?"
    new "تو اومدی برای مطالعه؟"

    # say L390 pla
    old "Yeah dude, I figured you'd want to start as soon as possible."
    new "بله داداش، فکر کردم می‌خوایی همین اول شروع کنی."

    # say L391 mik
    old "For sure, my first session with Olivia's coming soon."
    new "حتماً، اولین جلسه‌ام با اولیویا هم خیلی زوده."

    # say L392 mik
    old "And I don't know shit about the subject."
    new "و من هیچ چیز در مورد این موضوع نمی‌دونم."

    # say L393 pla
    old "Don't you say..."
    new "باید نگویی..."

    # say L394 pla
    old "But that's why I'm here, so let's get to it."
    new "ولی برای همین اینجا هستم، بیاین شروع کنیم."

    # say L396 mik
    old "Let's do it dude..."
    new "بیای بروش داداش..."

    # say L410 whi
    old "Oh, [pla]! Did you and Mike finish already? How did it go?"
    new "اوه، ز[pla]! شما و مایک تمام شدید؟ چطور بود؟"

    # say L411 pla
    old "That's right Mrs. White, we actually progressed quite a bit."
    new "بله خانم وایت، ما در واقع پیشرفت زیادی کردیم."

    # say L412 pla
    old "Mike has been putting in quite some effort to study, so he caught the lesson really quick."
    new "مایک واقعاً زیاد تلاش کرده برای مطالعه، پس درس رو خیلی سریع یاد گرفت."

    # say L414 whi
    old "But wait, leaving so soon?"
    new "ولی بی‌پرداز، الان می‌خوای بروی؟"

    # say L415 pla
    old "Well, yeah, since we're done, and it's getting kinda late."
    new "بله، خوب، چون تمام شد و کمی دیر شده."

    # say L416 pla
    old "I thought it would be better to go home."
    new "فکر کردم بهتر باشه برم خونه."

    # say L418 whi
    old "Oh no, no, no. I just finished making dinner. Stay and have dinner with us."
    new "اوه نه، نه، نه. همین حالا غذا رو آماده کردم. بمان و با ما غذا بخور."

    # say L420 pla
    old "Hmm, I don't know Mrs. White, I'm very thankful, but I don't want it to be of any trouble."
    new "Hmm، نمی‌دونم خانم وایت، خیلی ممنونم، ولی نمی‌خوام براتون سردرگمی بکنم."

    # say L421 whi
    old "Don't be silly"
    new "نه بیا، نباشی که خیالی نکنم"

    # say L422 whi
    old "It's only an extra plate, besides you must be tired from studying with Mike."
    new "فقط یک صفحه اضافی است، علاوه بر این شما حتماً از مطالعه با مایک خسته هستید."

    # say L423 whi
    old "And you've been so good, not only did you talk to Mike when he was angry."
    new "و تو هم خوب رفتی، نه فقط وقتی مایک خشمگین بود با او صحبت کردی."

    # say L424 whi
    old "You're also helping him study."
    new "همچنین به مطالعه‌اش هم کمک می‌کنی."

    # say L425 whi
    old "The least I can do is invite you to have some dinner with us."
    new "کمترین چیزی که می‌تونم بکنم اینه که شما رو دعوت کنم با ما غذا بخورید."

    # say L426 whi
    old "I can't just let you leave like that."
    new "نمی‌تونم بیاین بروی اینجوری."

    # say L433 mik
    old "Hey, mom, I'm hungry. It's dinner ready?"
    new "ماهان، من گرسنگم. شام آماده شده؟"

    # say L435 mik
    old "Oh [pla], you're still here?"
    new "اوه ز[pla]، هنوز اینجا هستی؟"

    # say L436 whi
    old "Dinner's ready honey, I was just telling your friend that he should stay for it."
    new "غذا آماده شده عزیزم، همینجوری به دوستت می‌گفتم که برای غذا بماند."

    # say L437 mik
    old "For sure dude! You should totally stay."
    new "حتماً بقیه! باید حتماً بمانی."

    # say L438 mik
    old "My mom makes the best pot roast you'll ever try, trust me you'll like it."
    new "مامان من بهترین گوساله پخته را می‌سازد، اعتماد داشته باشی، می‌پسندی."

    # say L439 whi
    old "Oh he's gonna love it."
    new "اوه، حتماً دوستش خواهد داشت."

    # say L441 pla
    old "All right, if you insist, I can't say no..."
    new "باشه، اگر می‌خواهی، نمی‌تونم بگم نه..."

    # say L442 pla
    old "Thanks a lot Mrs. White, I really appreciate it."
    new "ممنونم خانم وایت، واقعاً از این کار قدردانی می‌کنم."

    # say L443 mik
    old "Let's go then!"
    new "بیایید برویم!"

    # say L457 whi
    old "So tell me, how are your studies going? And your grades?"
    new "پس بگو، تحصیلاتت چطور هستند؟ و نمراتت چطور؟"

    # say L458 whi
    old "I hope everything's going well with your exams."
    new "امیدوارم امتحاناتت خوب پیش می‌رود."

    # say L459 mik
    old "Well, Belle and I are doing well on our end of term project."
    new "خب، من و بله در پروژه‌ی پایان ترم خوب پیشرفت کرده‌ایم."

    # say L460 mik
    old "She's really smart, and has helped me a lot with that."
    new "او واقعاً هوشیاره، و خیلی به من کمک کرده."

    # say L464 mik
    old "Oh right [pla], you did yours with Hin, right?"
    new "اوه درسته [pla]، تو هم پروژه‌ت رو با هین انجام دادی، درسته؟"

    # say L465 mik
    old "How did that go?"
    new "اونجوری که رفت؟"

    # say L467 pla
    old "Uhh... W- well, it went really... well."
    new "اوه... خب، واقعاً... خوب رفت."

    # say L468 pla
    old "Really well actually, Hin is a very good student, so we flew through it."
    new "وای، واقعاً خوب بود، هین یه دانش‌آموز خیلی خوبه، پس ما سریع اونجوری رد شدیم."

    # say L470 mik
    old "Uh, that makes sense, of course she would do a good job."
    new "آره، این جا منطقیه، البته که خوب کار کرده."

    # say L471 mik
    old "Specially since she's so into you."
    new "ویژه‌تر از همه، چون او به تو خیلی علاقه‌مند است."

    # say L474 mik
    old "Please dude, don't play fool, she's sooo got a thing for you."
    new "لطفاً داداش، نبازی باهام، او واقعاً به تو علاقه‌مند است."

    # say L475 pla
    old "I don't know what you're talking about, we're just friends..."
    new "من نمی‌دونم در مورد چی حرف می‌زنی، ما فقط دوست هستیم..."

    # say L476 whi
    old "Hinn is Jade's daugther, right? She's such a nice, smart girl."
    new "هین هم جدای دختر است، درسته؟ او دختر خوبی و هوشیاره."

    # say L477 whi
    old "Are you two dating?"
    new "شما دو تا با هم دوست هستید؟"

    # say L479 pla
    old "No, we're not. Mike's just messing with me."
    new "نه، ما همچین نیستیم. مایک فقط با من بازی می‌کنه."

    # say L480 mik
    old "Come on, she totally likes you..."
    new "بیا، او به تو خیلی علاقه داره..."

    # say L483 pla
    old "She's just a good friend. That's all there is to it."
    new "ما فقط دوست هستیم. هیچ چیز دیگر نیست."

    # say L485 whi
    old "Hmm, I see [pla] is a total succes with girls, isn't he?"
    new "هم، من می‌بینم ز[pla] با دختران خیلی موفقه، درسته؟"

    # say L486 mik
    old "Only Hin."
    new "فقط هین."

    # say L487 mik
    old "I don't know what she see's in you dude."
    new "من نمی‌دونم تو چی تو رو می‌بینه داداش."

    # say L489 whi
    old "Oh, but he's a total heartthrob."
    new "اوه، اما او کاملاً قلب‌زده‌کننده است."

    # say L490 whi
    old "Hin's very bright for liking you [pla]."
    new "هین برای دوست داشتن تو خیلی هوشمند است [pla]."

    # say L491 pla
    old "Uhhh, yeah... yeah she's really smart, but just a good friend."
    new "آره، همین‌جوری... اما فقط دوست خوبی هستیم."

    # say L493 whi
    old "I see, that's very good."
    new "می‌بینم، این خیلی خوب است."

    # say L494 whi
    old "By the way what are your projects about?"
    new "البته، پروژه‌هایت درباره چه چیزی هستند؟"

    # say L495 mik
    old "Ugh, some online content creation thing Belle said we should do."
    new "اوه، یه چیزی برای ایجاد محتوای آنلاین که بله گفت باید بکنیم."

    # say L496 mik
    old "It's a research project."
    new "این یک پروژه تحقیقی است."

    # say L497 mik
    old "She's very into those subjects."
    new "او خیلی به این موضوعات علاقه‌مند است."

    # say L498 whi
    old "And you [pla]? What are you and your friend Hin doing?"
    new "و شما [pla]؟ شما و دوستت هین چه کاری می‌کنید؟"

    # say L499 pla
    old "We... Uhh, we have a psychology project."
    new "ما... اوه، ما یه پروژه روانشناسی داریم."

    # say L500 pla
    old "About personal development and self confidence and stuff."
    new "درباره توسعه شخصی و اعتماد به نفس و چیزهایی مثل این."

    # say L502 whi
    old "Oh, I see, interesting."
    new "اوه، من می‌بینم، جالب است."

    # say L509 whi
    old "It sounds like a very, very HARD subject."
    new "به نظر می‌رسه موضوع خیلی، خیلی سختی هست."

    # say L510 pla
    old "I- it kind of is..."
    new "بله، نوعاً هست..."

    # say L529 whi
    old "I imagine you must be working very very... hard."
    new "من فکر می‌کنم شما باید خیلی خیلی... سخت کار می‌کنید."

    # say L531 mik
    old "Yes, we really are."
    new "بله، واقعاً هستیم."

    # say L544 pla
    old "The food was delicious Mrs. White, thanks a lot."
    new "غذا خیلی لذت‌بخش بود، ممنون می‌شوم، خانم وایت."

    # say L545 pla
    old "But it's getting kinda late. So, if you'll excuse me I should go home."
    new "اما الان وقتش شده. اگر اجازه بدید، من باید برگردم."

    # say L546 pla
    old "But I'll be back soon to keep studying, Mike."
    new "اما زودی برای ادامه تحصیل برمی‌گردم، مایک."

    # say L547 whi
    old "That's ok sweety, I'm glad to hear you liked dinner."
    new "خوبه عزیزم، خوشحالم که غذایم به تو پسندیده."

    # say L548 whi
    old "And I'm also glad you had a good time."
    new "و من هم خوشحالم که وقت خوبی گذراندی."

    # say L549 pla
    old "Yes, it was... very good. You've got marvelous hands Mrs. White... For the kitchen of course..."
    new "بله، خیلی خوب بود... دست‌های شما عالی هستن خانم وایت... البته برای آشپزخانه..."

    # say L550 whi
    old "You should stay for dinner more often.."
    new "شما باید بیشتر برای شام می‌ماندید."

    # say L551 whi
    old "So, you don't have to worry about coming here, and spending all the time you want."
    new "پس، نباید نگران آمدن اینجا باشید و همه وقتی که می‌خواهید بگذارید."

    # say L552 pla
    old "Thanks a lot Mrs. White, that's very kind of you."
    new "ممنونم خانم وایت، این خیلی لطف دارید."

    # say L553 whi
    old "I'm always happy to have some extra company here. And you know you're more than welcome."
    new "همیشه خوشحالم وقتی همراهی بیشتری اینجا دارم. و می‌دونی که خوشحال می‌شم ازت بپذیرم."

    # say L554 pla
    old "Uhh, sure, thank you."
    new "اوه، البته، ممنون."

    # say L555 pla
    old "I think I should go now."
    new "فکر می‌کنم باید حالا برسم."

    # say L557 whi
    old "Get home safe. See you later sweetie."
    new "بیا خونه ای برو با امنیت. ببینم بعداً عزیزم."

    # say L559 mik
    old "Later dude."
    new "بعداً برو دوست من."

    # say L560 pla
    old "Ok, bye..."
    new "باشه، خداحافظ..."

    # say L577 mik
    old "[pla] dude! Hi! What's up?"
    new "[pla] دود! سلام! چطوری؟"

    # say L578 mik
    old "Did you come to help me study?"
    new "آیا برای کمک به من مطالعه کنم اومدی؟"

    # say L579 pla
    old "Yeah dude, that's right."
    new "بله دوداش، همین جوری است."

    # say L580 mik
    old "Oh thank god, my next session with Olivia's coming soon."
    new "اوه خدا، جلسه بعدی من با اولیویا هم خیلی زوده."

    # say L581 mik
    old "And I was getting worried, because I'm not ready for her class."
    new "و خوشحالم که نگران نبودم، چون هنوز برای کلاسش آماده نیستم."

    # say L582 pla
    old "Well that's why I'm here. Are you ready to start?"
    new "خب برای همین اینجا هستم. آماده‌ای شروع کنیم؟"

    # say L583 mik
    old "Yeah I'm ready, let's do this!"
    new "بله آماده‌ام، بیای بزنیم!"

    # say L594 pla
    old "Wow! Dude! You got it right! I didn't know you were so good at this!"
    new "واو! داداش! درست اومدی! نمی‌دونستم اینقدر خوبی هستی!"

    # say L595 pla
    old "I mean, if you studied like that more often you'd have straight A's."
    new "منظورم اینه، اگه مثلاً همیشه همین طور مطالعه می‌کردی، نمراتت هم همیشه A می‌بود."

    # say L596 mik
    old "Hehe, thanks man, I've tried to pay attention to what you've taught me."
    new "ههه، ممنون داداش، من سعی کردم به آنچه تو یادم دادی توجه کنم."

    # say L597 mik
    old "So that I can teach it to Olivia."
    new "تا بتوانم به اولیویا بیاموزم."

    # say L598 pla
    old "Well I'm sure it's gonna go great if you keep going like that."
    new "حتماً خوب می‌ری اگه همچین جوری ادامه بدی."

    # say L599 pla
    old "So, listen dude, it's getting kinda late, so, I should go home."
    new "برو، شنیدی، الان وقتش شده، من باید برم خونه."

    # say L600 pla
    old "But I'll be back before your next session with Olivia."
    new "ولی قبل از جلسه بعدت با اولیویا بر می‌گردم."

    # say L602 mik
    old "Sure man, thanks a lot. See you later."
    new "بله دستت درد نکنه، ببینم بعد."

    # say L652 mik
    old "Damn, I'm sorry dude. I suck at this so much."
    new "ببخشید دوست من. من توی این کار خیلی بد هستم."

    # say L653 mik
    old "I think I'm just wasting your time."
    new "من فکر می‌کنم فقط وقتت رو از دست می‌برم."

    # say L654 pla
    old "Nah, it's ok, this isn't an easy topic anyway."
    new "نه، خوبه، این موضوع خودش سخته."

    # say L655 pla
    old "We still got some time before you have to teach Olivia. So let's just relax."
    new "هنوز وقتی هست تا باید اولیویا رو تدریس کنی. بیا بیشتر آرام شیم."

    # say L656 mik
    old "I can't relax dude! I told Olivia I was gonna teach her and I'm not ready."
    new "من نمی‌تونم آرام شم دیوونه! به اولیویا گفتم می‌خوام بهش بیاموزم و من آماده نیستم."

    # say L657 pla
    old "I know, man, I know."
    new "می‌دونم، دوست من، می‌دونم."

    # say L658 pla
    old "I'm sure you'll get it before the day."
    new "مطمئنم قبل از روز آماده می‌شی."

    # say L659 mik
    old "Hmm... You're probably right [pla], sorry I got a little anxious."
    new "Hmm... شاید هستی درست [pla]، ببخشید که یه کم ناراحت شدم."

    # say L660 mik
    old "Let's just try again, I'm sure I'll do better this time."
    new "بیای دوباره امتحان کنیم، مطمئنم این بار بهتر می‌کنم."

    # say L662 pla
    old "Nah, I don't think we should keep going today"
    new "نه، فکر کنم باید امروز متوقف شیم."

    # say L663 pla
    old "We're already tired, and just forcing this won't help."
    new "ما قطعاً خسته‌ایم، و اینجوری تلاش کردن هم کار نمی‌کنه."

    # say L664 pla
    old "Besides, it's kinda late, so I think I better go home for now."
    new "البته، وقت هم دیر شده، بهتره حالا برای خونه برم."

    # say L665 pla
    old "And we can pick it up another time."
    new "و می‌تونیم بعداً ادامه بدیم."

    # say L667 mik
    old "Sure, you're probably right."
    new "بله، احتمالاً درست می‌گویی."

    # say L686 whi
    old "Hello [pla] I'm so glad to see you."
    new "سلام ز[pla] خوشحالم که شما رو می‌بینم."

    # say L687 pla
    old "Hi Mrs. White, how are you?"
    new "سلام خانم وایت، حالتون چطوره؟"

    # say L688 whi
    old "I'm fine sweetie, and you?"
    new "من خوبم عزیزم، و شما چطورید؟"

    # say L690 whi
    old "Let me guess, you came to see Mike, right?"
    new "بگویم حدس بزنم، برای دیدن مایک اومدی، درسته؟"

    # say L691 pla
    old "That's right, we'd planned another study session for today."
    new "درسته، ما برای امروز جلسه مطالعه دیگری برنامه‌ریزی کردیم."

    # say L692 whi
    old "Well sweetie, I'm sorry to tell you he isn't here."
    new "خوب عزیزم، متاسفانه باید بهت بگم او اینجا نیست."

    # say L693 whi
    old "I don't know if he forgot to tell you, but he said he was meeting a girl to study."
    new "نمیدونم اگه بهت گفته بود، ولی گفت همکاری با یه دختر برای مطالعه داره."

    # say L694 pla
    old "Oh right! Damn, I totally forgot about that."
    new "اوه درسته! شیطون، کاملاً فراموش کردم."

    # say L695 pla
    old "He did say something about it."
    new "او همینطور گفته بود."

    # say L696 pla
    old "Well, I guess I'm gonna have to come back later. Please tell him I came by."
    new "ببخشید، به نظر می‌رسه باید بعداً برگردم. لطفاً بهش بگی من اومدم."

    # say L702 whi
    old "But, wait [pla]!"
    new "ولی، صبر کن [pla]!"

    # say L706 pla
    old "Y- yes?"
    new "بله؟"

    # say L707 whi
    old "Sweetie it would be a shame if you left just after getting here."
    new "حبیبی، خیال می‌کنم اگه همین الان بری، خیلی شرمنده می‌شوم."

    # say L708 whi
    old "Why don't you stay for a little while?"
    new "چرا نمی‌خوای یه کمی بمونی؟"

    # say L709 whi
    old "You can make me some company."
    new "می‌تونی با من همراهی کنی."

    # say L711 whi
    old "I actually was about to move around the furniture in my room."
    new "من در واقع قصد داشتم موبایل‌های اتاقم رو جابجا کنم."

    # say L712 whi
    old "I could use your help and I thought maybe a big and strong guy like you could help me out."
    new "می‌تونی به من کمک کنی و فکر کردم شاید یه مرد بزرگ و قوی مثل تو بتونه به من کمک کنه."

    # say L713 pla
    old "Heh, sure, I can help you out."
    new "حاه، البته، می‌تونم بهت کمک کنم."

    # say L715 whi
    old "Come on up, I'll show you what I need."
    new "بیای بالا، بهت نشون می‌دم چی می‌خوام."

    # say L726 pla
    old "Ok, Mrs. White, what do you want me to help you with?"
    new "باشه، خانم وایت، من چطور می‌تونم به شما کمک کنم؟"

    # say L733 pla
    old "Oh, wow!"
    new "اوه، وای!"

    # say L734 whi
    old "You see... I figured, since we're alone."
    new "ببین... فکر کردم چون تنها هستیم."

    # say L735 whi
    old "Why don't we have a little bit of fun?"
    new "چرا ما یه کمی لذت برداریم؟"

    # say L736 pla
    old "B- But, Mrs. White, what happens if Mike catches us?"
    new "اما، خانم وایت، اگه مایک ما رو ببینه چه می‌شه؟"

    # say L737 whi
    old "You worry too much."
    new "بیش از حد نگرانی می‌کنی."

    # say L738 whi
    old "He won't be home for a while, besides, this is my room. So he won't come in without knocking first."
    new "او برای مدتی خانه نخواهد بود، علاوه بر این این اتاق من هست. پس بدون اینکه ابتدا بزنن، داخل نمی‌شه."

    # say L739 whi
    old "We have time and privacy."
    new "ما وقت و حرمت خصوصی رو داریم."

    # say L740 whi
    old "So don't worry and let's just enjoy."
    new "پس نگران نباش و بیایم لذت ببریم."

    # say L741 pla
    old "I mean, I- I understand what you're saying, but I think it's too risky."
    new "من قصه‌اتو می‌فهمم، ولی فکر می‌کنم خیلی ریسک‌بر اینه."

    # say L742 whi
    old "Oh please, don't act like you don't want it."
    new "لطفاً، نباید بروی این که نمی‌خوای اینو."

    # say L743 whi
    old "I know you're turned on right now, so come here."
    new "میدونم الان خیالتو بر این چیزه، پس بیا اینجا."

    # say L745 whi
    old "You know, I know you enjoyed dinner last time."
    new "میدونم، میدونم شما از شام آخر لذت برده بودید."

    # say L746 whi
    old "But I'm still not satisfied."
    new "اما هنوز خوشحالم نیستم."

    # say L747 whi
    old "I want to taste something a little better."
    new "من می‌خواهم چیزی کمی بهتر رو بچشیدم."

    # say L754 whi
    old "Mmm, look at that big cock of yours."
    new "ممنون، نگاه کن به اون نوزک بزرگت."

    # say L755 whi
    old "I told you I knew you were getting turned on and very, very hard by the looks of it...."
    new "من بهت گفتم که میدونم تو خیلی خیلی سخت شده و به نظرت اینجوری میاد..."

    # say L757 whi
    old "I've been wanting to taste this big dick since last dinner."
    new "از اول شام، می‌خواستم این پیپ بزرگ رو بچُشم."

    # say L767 mik
    old "Dude, you were here?"
    new "دیو، تو اینجا بودی؟"

    # say L768 whi
    old "Yes, he came looking for you, but you weren't home, so I asked him to stay."
    new "بله، او برای دیدنت اینجا آمد، اما تو خانه نبودی، پس ازش درخواست کردم که منتظرت بماند."

    # say L770 mik
    old "Stay? What for?"
    new "میخواستی اینجا بمانی؟ برای چه؟"

    # say L771 pla
    old "Uhhh... W- well... you know..."
    new "اوه... ح- حسن... می‌دونی..."

    # say L772 whi
    old "Well, if you remember, there were some stuff in my room that I wanted to move to the attic."
    new "البته، اگر به یاد داری، چند چیز در اتاق من بود که می‌خواستم به سطح بالا ببرم."

    # say L773 whi
    old "And I've been telling you for a while to help me, but you haven't done anything."
    new "و من از یک مدت به تو می‌گفتم که به من کمک کنی، اما تو هیچ کاری نکردی."

    # say L774 whi
    old "So you're friend here was kind enough to help me. You could learn one or two things from him, you know young man?"
    new "پس دوستت اینجا خوشحال بود کمکم کنه. شاید ازش یک دو تا چیز بیاموزی، می‌دونی جوان؟"

    # say L775 mik
    old "Hmm, yeah, uh, I forgot about that stuff."
    new "هم، بله، اوه، من درباره اون چیزها فراموش کردم."

    # say L778 pla
    old "... No problem."
    new "هیچ مشکلی نداره."

    # say L779 whi
    old "Well, I have to clean up some things, and start making dinner. So I'll leave you two alone."
    new "خوب، باید چند جا را تمیز کنم و شروع به آماده‌سازی شام کنم. پس شما دو نفر را تنها می‌گذaram."

    # say L780 whi
    old "Thanks again for your help [pla]."
    new "ممنون از کمک شما [pla]."

    # say L781 pla
    old "Sure Mrs. White."
    new "البته خانم وایت."

    # say L788 mik
    old "Sorry you had to see that dude."
    new "متاسفم که این را دیدی بروتر."

    # say L789 mik
    old "My mom is very annoying, sometimes she won't stop nagging me."
    new "مما خیلی آزاردهنده است، گاهی هیچ وقت از ترکی نمی‌کند."

    # say L790 pla
    old "Don't worry about it... My mom's the same."
    new "باز هم نگران نباش... مامان من هم همینجوری."

    # say L791 mik
    old "Well anyway, come to my room, I have to tell you something."
    new "بازم، بیا اتاق من، باید چیزی به تو بگم."

    # say L800 mik
    old "Dudeee! Things went so well with Olivia!"
    new "دودد! همه چیز با اولیویا خوب پیش رفت!"

    # say L802 mik
    old "Yeah! She said I helped her a lot and that I'm a very good tutor."
    new "بله! او گفت که من بهش کمک زیادی کردم و من یک معلم خیلی خوب هستم."

    # say L803 mik
    old "And it's all thanks to you dude. Thank you!"
    new "و همه این به خاطر توه. ممنون!"

    # say L804 pla
    old "You're welcome man, I'm glad to be able to help."
    new "خواهش می‌کنم، خوشحالم که بتونم کمکت کنم."

    # say L805 pla
    old "So you're gonna keep seeing her?"
    new "پس قراره همچنان باهاش دیدار کنی؟"

    # say L806 mik
    old "Yeah, but she says she's going to come here next time."
    new "بله، اما می‌گه بعداً می‌آیه اینجا."

    # say L807 mik
    old "Because she says she's embarrassed to be seen with me, so it's better to come here instead."
    new "چون می‌گه خجله داره کنارم دیده بشه، پس بهتره اینجا بیاد."

    # say L808 pla
    old "Whoa! What?! That's awful!"
    new "وای! چه خبری؟ این خیلی بده!"

    # say L809 pla
    old "And you're ok with that?"
    new "و تو با این راحتی موافقت می‌کنی؟"

    # say L811 mik
    old "Sure, why wouldn't I be? That means she wants to spend time with me. right?"
    new "بله، چرا نباید همچین باشم؟ این به معنای اینه که می‌خواد وقت رو با من بگذونه. درسته؟"

    # say L814 pla
    old "I mean, that's one way to put it..."
    new "من قصه‌ای به همین ترتیب می‌گم..."

    # say L815 mik
    old "Come on man, she's gonna be here... in my room!"
    new "بیا برو، او اینجا می‌تونه بیاد... توی اتاق من!"

    # say L816 mik
    old "That's an opportunity to get closer with her!"
    new "این فرصتی برای نزدیک شدن به اش هست!"

    # say L817 mik
    old "And I don't really care what people think, you know? So what the hell."
    new "و من واقعاً نگران نظر دیگران نیستم، می‌دونی؟ براش چه کاری."

    # say L818 pla
    old "Well... as long as you're happy."
    new "خب... مادون اینکه خوشت می‌آید."

    # say L819 pla
    old "And you're positive about it. So, sure."
    new "و تو مطمئنی. خب، حتماً."

    # say L822 pla
    old "Listen man, I came to help you study, but it's kinda late."
    new "بفرما دستا، من برای کمک به تو برای مطالعه اومدم، ولی الان خیلی دیره."

    # say L823 pla
    old "So, what do you say if we leave it for next time."
    new "پس، چطور می‌گیه اگه برای بعد بگذرونیم."

    # say L824 pla
    old "Besides, you must be tired from studying with Olivia."
    new "البته، شاید اولیا خسته باشی از مطالعه با اولیویا."

    # say L825 mik
    old "Sure dude, to be honest I was afraid you were gonna say we had to study."
    new "بله دوست من، صادقانه بودم مطمئن می‌شدم می‌گیه باید مطالعه کنیم."

    # say L826 mik
    old "So I'm ok with doing it another time."
    new "پس خوشحالم که برات دیگه وقتی تعیین کنیم."

    # say L827 pla
    old "Cool, see you later then."
    new "ببین همینطور بعداً می‌بینیم."

    # say L829 mik
    old "Later bro."
    new "بعداً برادر"

    # say L848 whi
    old "Oh [pla] wait!"
    new "اوه ز[pla] بیا!"

    # say L849 pla
    old "Yes Mrs. White?"
    new "بله خانم وایت؟"

    # say L850 whi
    old "It's very late, so I figured you were gonna stay for dinner."
    new "این وقت خیلی دیره، فکر کردم می‌خواهی برای شام بمانی."

    # say L851 whi
    old "The food is served already, so you can't say no."
    new "غذا قراره سرو شده، پس نمی‌تونی نه بگی."

    # say L853 pla
    old "Oh, all right, thank you."
    new "البته، ممنون."

    # say L869 whi
    old "Do you like today's dinner?"
    new "آیا امروز شام را دوست دارید؟"

    # say L871 pla
    old "Yeah, it's very good Mrs. White, thanks a lot."
    new "بله، خیلی خوبه خانم وایت، ممنونم."

    # say L872 mik
    old "He's right mom, it's really good."
    new "درست می‌گه مامان، واقعاً خوبه."

    # say L874 mik
    old "Excuse me, let me go to the bathroom real quick."
    new "ببخشید، من یه لحظه به دامنه می‌رم."

    # say L888 pla
    old "Woah! What are you doing Mrs. White?"
    new "واو! خانم وایت، شما چه کاری انجام می‌دهید؟"

    # say L889 pla
    old "We're in the middle of dinner! Mike could come back at any second!"
    new "ما در وسط شام هستیم! مایک هر لحظه می‌تونه برگه بیاد!"

    # say L890 whi
    old "Oh relax, Mike always takes his time in the bathroom."
    new "اوه آرامش، مایک همیشه زمان زیادی در حمام می‌گذراند."

    # say L891 whi
    old "I don't know exactly what he does there, but he'll be there for a while."
    new "من دقیقاً نمی‌دونم اونجا چی می‌کنه، ولی مطمئن هستم که مدتی طول می‌کشه."

    # say L892 pla
    old "Still, we're in the dining room..."
    new "همه جا، ما در اتاق نشستنی هستیم..."

    # say L893 whi
    old "So? Nobody will see us, just enjoy it."
    new "پس؟ هیچ‌کس ما رو نمی‌بینه، فقط ازش لذت ببر."

    # say L909 pla
    old "Uhh, Mrs. White you have some... Uhh... In your face..."
    new "اوه، خانم وایت، چیزی... اوه... روی صورت شما داره..."

    # say L915 whi
    old "It's ok honey, [pla] and I had a chance to have a very nice conversation."
    new "خوب هنوز، عزیزم، من و [pla] فرصت خوبی برای صحبت کردن داشتیم."

    # say L917 whi
    old "Right, [pla]?"
    new "بله، [pla]؟"

    # say L918 mik
    old "Mom, why do you have so much mayo all over your face?"
    new "مامان، چرا مایونز خیلی زیاد روی صورتت هست؟"

    # say L919 whi
    old "Oh! Heh silly me. I just love the taste of it!"
    new "اوه! هه، خجالتم. من فقط عاشق طعمش هستم!"

    # say L926 mik
    old "I know mom, we all know you really like mayo"
    new "می‌دونم مامان، همه‌مون می‌دونیم که خیلی دوست داری مایونز بخوری"

    # say L927 whi
    old "Yeah, mayo. Of course..."
    new "بله، مایونز. البته..."

    # say L937 pla
    old "Once again, it was all very good Mrs. White."
    new "بار دیگر، همه خوب بود خانم وایت."

    # say L938 pla
    old "Thanks a lot!"
    new "ممنونم خانم وایت"

    # say L939 whi
    old "My pleasure sweety, it was good seeing you again."
    new "لذت‌بخش بود عزیزم، خوشحالم دوباره تو رو دیدم."

    # say L940 whi
    old "And as you could see, I also think everything was delicious..."
    new "و همانطور که دیدی، من هم فکر می‌کنم همه چیز خوشمزه بود..."

    # say L941 pla
    old "...Sure."
    new "...بله."

    # say L942 pla
    old "Mike, I think I'll head home dude, I'll come back another time to keep studying."
    new "مایک، فکر کنم برم خونه برم، بعداً می‌گیوم برگشتم تا ادامه بدم مطالعه."

    # say L943 mik
    old "Sure dude, have a good night."
    new "باز هم بیا، شب خوبی داشت."

    # say L944 whi
    old "And remember to come back soon... You're always welcome."
    new "و به خاطر داشته باش تا زودبین باشی... همیشه خوشحالم که اومدی."

    # say L945 pla
    old "Uuuh... thank you."
    new "اوه... ممنون."

    # say L963 pla
    old "Hi Mrs. White, is Mike around?"
    new "سلام خانم وایت، مایک در خونه هست؟"

    # say L964 whi
    old "Hi [pla] is good to see you sweetie."
    new "سلام [pla] خوشحالم که تو رو می‌بینم عزیزم."

    # say L965 whi
    old "Well, Mike is in the house. But I don't think he can see you right now."
    new "خوب، مایک در خانه است. اما فکر نمی‌کنم بتواند الان با تو صحبت کند."

    # say L966 pla
    old "What? Why not?"
    new "چرا نه؟"

    # say L967 whi
    old "Well, he's got some company."
    new "خب، مهمانی داره."

    # say L968 whi
    old "A girl came to see him, and they locked themselves in his room."
    new "دختری برای دیدن او آمد و آنها خودشان را در اتاقش بستند."

    # say L969 whi
    old "He told me that I shouldn't bother him or even knock on the door."
    new "او به من گفت که نباید او را آزار دهم یا حتی به در بزنم."

    # say L970 pla
    old "Ohh, that's right, he told me Olivia was gonna come today, I don't know how I forgot about it."
    new "اوه، درسته، او به من گفت که اولیویا امروز می‌آید، نمی‌دونم چطور فراموش کردم."

    # say L971 pla
    old "Ok, then I guess I'll come later, see you Mrs. White."
    new "خب، پس به نظر می‌رسه باید بعداً بیام، خداحافظ خانم وایت."

    # say L972 whi
    old "Wait a minute!"
    new "بی‌پاره!"

    # say L973 pla
    old "Uhh... yes?"
    new "اوه... بله؟"

    # say L974 whi
    old "How are you leaving after you just arrived? Don't be silly."
    new "چطور می‌خوای بعد از اینکه هم‌چین هم‌چین اومدی بروی؟ نباشی خنده‌دار."

    # say L975 whi
    old "You're going to help me move some other boxes in my room."
    new "شما می‌خواید به من کمک کنید که برخی جعبه‌های دیگه از اتاقمو ببریم."

    # say L976 pla
    old "What? What are you talking about? Mike's here!"
    new "چه کاری می‌تونی بگی؟ مایک اینجا هست!"

    # say L977 whi
    old "So? They just went up to his room a couple of minutes ago."
    new "پس؟ چند دقیقه پیش به اتاقش رفتند."

    # say L978 whi
    old "How long do you think the study session will last?"
    new "می‌تونی چقدر طول می‌دهی فکر کنی که جلسه مطالعه طول بکشه؟"

    # say L979 pla
    old "Well... It should take a while, because the subject is a little long."
    new "خب... باید مدتی طول بکشه، چون موضوع کمی طولانیه."

    # say L981 whi
    old "See? Nothing's going to happen."
    new "ببین؟ هیچ چیزی پیش نمی‌یاد."

    # say L982 whi
    old "Besides, if they finish early, all I have to do is tell him I'm in my room and don't want him to go in."
    new "البته، اگر زودتر تمام شدن، فقط باید بهش بگم که در اتاقم هستم و نمی‌خوام وارد بیاد."

    # say L983 pla
    old "Still, I don't think we..."
    new "همچین، من فکر نمی‌کنم ما باید..."

    # say L984 whi
    old "Enough talking, you worry too much. Just come with me to the room."
    new "باز کلام، خیلی نگرانی می‌کنی. فقط با من به اتاق بیا."

    # say L985 whi
    old "I know you'll love it."
    new "میدونم خوشت میاد."

    # say L997 pla
    old "(Oh man, I just fucked my best friend's mom... I can't believe I'm doing this to Mike.)"
    new "(ای مرد، فقط مامان بهترین دوستم رو فوت کردم... نمی‌تونم باور کنم این کار رو برای مایک انجام میدم.)"

    # say L998 pla
    old "(Jeez, honestly... I'm ok with helping Mike, but damn, this is getting dangerous.)"
    new "(Jeez، صداقتان... من برای کمک به مایک همراهانم هستم، ولی خدا، این خیلی خطرناک شده.)"

    # say L999 pla
    old "(I mean, I just can't even imagine what would happen if Mike caught us one day)"
    new "من هم نمی‌تونم بیاندازم اگه یک روز ما رو ببینه."

    # say L1006 oli
    old "Ah! W- What are you doing here?"
    new "اوه! خ- خوب، تو اینجا چه کاری داری؟"

    # say L1009 pla
    old "Uhh... Well, this is my friend's house."
    new "اوه... خب، این خانه دوست من هست."

    # say L1010 pla
    old "So, I came to see him."
    new "پس من برای دیدنش اومدم."

    # say L1011 pla
    old "And you? Did you come to study with him, right? "
    new "و تو؟ می‌آیی برای اینکه باشون هم کار بکنی، درسته؟"

    # say L1013 oli
    old "I... uhh..."
    new "من... اوه..."

    # say L1014 oli
    old "What do you care? I can come and go wherever I want."
    new "تو چه کاری داری؟ من می‌تونم هر جا برم که بخوام."

    # say L1015 oli
    old "And I'm leaving now!"
    new "و حالا می‌روم!"

    # say L1026 oli
    old "By the way! You better not tell anybody about me being here!"
    new "بینهایت! بهتره به هیچ‌کس در مورد اینکه من اینجا بودم نگویی!"

    # say L1027 oli
    old "Or you'll hear about me, you got that fucking nerd?"
    new "یا تو خبر من رو بشنیدی، فهمیدی نرد مالیده؟"

    # say L1028 pla
    old "Sure, sure whatever you say."
    new "بله، بله، هر چی می‌گی، می‌شنوم."

    # say L1044 mik
    old "Oh [pla], what's up man? I didn't know you were here."
    new "اوه ز[pla]، چطوری دوست من؟ نمی‌دونستم اینجا هستی."

    # say L1045 pla
    old "Uh, yeah, I came to see you."
    new "آره، بله، اومدم برات."

    # say L1046 pla
    old "I forgot that you were going to see Olivia today."
    new "من فراموش کرده بودم که امروز می‌خواستی با اولیویا برخورد کنی."

    # say L1047 pla
    old "By the way, how did it go?"
    new "باید بگم، چطور بود؟"

    # say L1049 mik
    old "Aww man! It was awesome!"
    new "اوه دست من! خیلی عالی بود!"

    # say L1050 mik
    old "She said I'm being very helpful."
    new "او گفت من خیلی کمک‌کننده هستم."

    # say L1051 mik
    old "I'm telling you [pla], I'm winning her over."
    new "من به تو می‌گم [pla]، من در حال فتحش هستم."

    # say L1053 mik
    old "But anyway, we can keep talking about it while we have dinner."
    new "اما هر حال، می‌تونیم در حال خوردن شام درباره اون حرف بزنیم."

    # say L1054 pla
    old "Uh what? Dinner? I- I don't think I can."
    new "اوه چی؟ شام؟ من- من فکر می‌کنم نمی‌تونم."

    # say L1055 mik
    old "Come on, you know it's no trouble. My mom will be happy to have you here."
    new "بیا، می‌دونی که هیچ مشکلی نداره. مامان خوشحالم میشه که تو اینجا باشی."

    # say L1056 pla
    old "I'm sure she will. But I promised my mother I would have dinner at our house tonight."
    new "مطمئن هستم که خوشحال می‌شه. اما به مامان قول دادم که امروز شام رو توی خونه ما بدم."

    # say L1057 pla
    old "I've been eating out too much, so I can't miss it tonight."
    new "من خیلی زیاد رستوران خورده‌ام، پس امروز نمی‌تونم اونجا رو بیام."

    # say L1059 mik
    old "Uhh, all right, next time then."
    new "اوه، خب، بار بعد پس."

    # say L1060 mik
    old "See you later then bud."
    new "بعداً می‌بینیم بابا."

    # say L1061 pla
    old "Sure man, see you."
    new "بله دوست من، بعداً می‌بینیم."

    # say L1079 whi
    old "Hi [pla] are you two done studying today?"
    new "سلام ز[pla]، شما دو تا امروز مطالعه‌تون رو تمام کردید؟"

    # say L1080 pla
    old "Yes Mrs. White, we just finished."
    new "بله خانم وایت، ما همین الان تمام شدیم."

    # say L1081 pla
    old "So I figured I should go."
    new "پس فکر کردم باید برگرم."

    # say L1082 whi
    old "Oh don't be silly!"
    new "اوه، نباید خنده‌دار باشی!"

    # say L1083 whi
    old "I already finished the dinner."
    new "من شام را قبلاً آماده کردم."

    # say L1084 whi
    old "And you know I want you to stay."
    new "و می‌دونی می‌خوام بمانی."

    # say L1086 pla
    old "L- Listen Mrs. White, I already told my mom I was going to have dinner with her and sh..."
    new "بگو خانم وایت، قبلاً به مامانم گفتم که با او شام می‌خورم و..."

    # say L1087 whi
    old "I'm sure your mother will understand that I invited you."
    new "مطمئن هستم مادرت فهمیده که من دعوت کردم."

    # say L1088 whi
    old "Come on. Let's have dinner."
    new "بیایید. بیایم عشام بخوریم."

    # say L1103 mik
    old "This is really good mom."
    new "این واقعاً خوبه مامان."

    # say L1104 mik
    old "I don't know what's happened, but you've been making some awesome food these days."
    new "نمی‌دونم چه اتفاقی افتاده، ولی اخیراً غذاهات خیلی خوب هستند."

    # say L1105 whi
    old "I don't know what you mean by that, my food is always delicious."
    new "من نمی‌دونم چی می‌خوای بگی، غذاهای من همیشه لذت‌بخش هستند."

    # say L1106 whi
    old "You're going to make your friend think that my cooking is usually bad."
    new "مایک، اینجوری دوستت فکر می‌کنه که غذاهای من معمولاً بد هستند."

    # say L1107 mik
    old "What? Of course not."
    new "چه؟ البته نه."

    # say L1108 mik
    old "All I'm saying is the meals are extra special these days."
    new "من فقط می‌گم که غذاهای این روزها خیلی خاص هستند."

    # say L1110 whi
    old "Well, I have to put in some effort, we've been having an extra special guest..."
    new "البته، باید تلاش کنم، چون مهمان خاصی داریم..."

    # say L1111 mik
    old "Ha! My mom likes you dude."
    new "ها! مامانم خوشت داره بچه."

    # say L1112 pla
    old "(You have no idea...)"
    new "فکر نمی‌کنی..."

    # say L1113 whi
    old "I'm just being nice to your friend."
    new "من فقط به دوستت لطف دارم."

    # say L1114 whi
    old "Are you enjoying it too [pla]?"
    new "آیا شما هم لذت می‌برید [pla]؟"

    # say L1117 pla
    old "I like it a lot. It's delicious, thank you."
    new "خیلی لذت می‌برم. خوشمزه است، ممنون."

    # say L1119 mik
    old "By the way [pla], Belle told me to ask you about th..."
    new "باید بگم [pla]، بله مرا از تو پرسید که در مورد..."

    # say L1123 mik
    old "Hold it right there, I'm gonna take this call."
    new "بیا بقیه، من این تماس رو می‌گیرم."

    # say L1130 pla
    old "Oh come on..."
    new "اوه بیای ببین..."

    # say L1139 pla
    old "W- What are you doing Mrs. White?"
    new "خانم وایت، شما چه کاری انجام می‌دهید؟"

    # say L1140 whi
    old "What? This is just like last time."
    new "این همینطور مثل آخر هفته است."

    # say L1141 whi
    old "You know he'll take a while."
    new "میدونی که او زمانی طول می‌کشه."

    # say L1142 whi
    old "So, we can have a little bit of fun."
    new "پس می‌تونیم یه کمی لذت ببریم."

    # say L1143 pla
    old "No, no, no. This isn't like last time. He only left to pick up a call."
    new "نه، نه، نه. این مثل آخرین بار نیست. فقط برای گرفتن تماسی رفت."

    # say L1144 pla
    old "Which means it won't be long."
    new "این به معنی اینه که طول نمی‌کشه."

    # say L1145 pla
    old "Mrs. White please stop!"
    new "خانم واایت لطفاً متوقف شوید!"

    # say L1146 whi
    old "Well, I could stop."
    new "خب، می‌تونم متوقف بشه."

    # say L1147 whi
    old "But this hard dick tells me you want me to do it anyway."
    new "ولی این ناخن سخت به من می‌گه که هر جوری می‌خوای اینجوری باشه."

    # say L1149 whi
    old "Just relax, it won't take long."
    new "آرام باش، طول نمی‌کشه."

    # say L1171 mik
    old "Where did my mom go?"
    new "مama کجا رفت؟"

    # say L1172 pla
    old "Uhhh... S- she went to the... bathroom. Yeah, she said she needed to go."
    new "اوه... م- مامان به... به توالت رفت. بله، گفت که باید برود."

    # say L1173 mik
    old "But I came from there, and I didn't see her enter."
    new "ولی از آنجا اومدم و ندیدم وارد شده."

    # say L1176 pla
    old "She... must be using the one in her bedroom."
    new "او... شاید از آن یکی در اتاق خوابش استفاده می‌کنه."

    # say L1177 pla
    old "I think she went upstairs."
    new "فکر کنم بالا رفته."

    # say L1178 mik
    old "Hmm."
    new "همم."

    # say L1180 mik
    old "Yeah you're right."
    new "بله، درست می‌گی."

    # say L1197 pla
    old "(Damn, I can't believe she actually gave me a blowjob and made me cum with Mike here!)"
    new "(شیطان! نمی‌تونم باور کنم واقعاً اونجا با مایک اینجوری جنسیتی شد!)"

    # say L1198 pla
    old "(I need to think about something or Mike will really catch us.)"
    new "(باید چیزی فکر کنم تا مایک ما رو واقعاً متوجه نشه.)"

    # say L1199 pla
    old "You know what Mike? I think I could really use a headache pill."
    new "مایک، می‌دونی چی؟ فکر کنم واقعاً نیاز دارم یه حبوبه سردرد ببرم."

    # say L1200 pla
    old "If you have anything here that I could take it would be good."
    new "اگر چیزی اینجا هست که بتوانم بگیرم خوب است."

    # say L1201 mik
    old "Hmm, let me check the cabinet in the bathroom."
    new "هم، بیایید از قفسه دستشویی بررسی کنم."

    # say L1209 whi
    old "A headache? That was a good idea."
    new "این درد سر؟ این یک ایده خوب بود."

    # say L1210 pla
    old "Why are you so chirpy? I told you he was going to come back!"
    new "چرا اینقدر خوشحالی؟ من بهت گفتم که می‌تونه برگرده!"

    # say L1211 whi
    old "Awww, my baby boy was scary, don't worry sweetie."
    new "اوه، پسر کوچیکم جان خیالی نکن، نگران نباش حلوایی."

    # say L1212 whi
    old "Next time I see you I'll give you something in return for this."
    new "بعداً وقتی دیدنت می‌دم چیزی به جای این بهت"

    # say L1213 pla
    old "Hmph, this isn't about that."
    new "هم، این به همین خاطر نیست."

    # say L1218 mik
    old "Sorry dude, we don't have anything like that."
    new "ببخشید داداش، ما هیچ چیزی مثل این نداریم."

    # say L1219 mik
    old "Mom, you're back."
    new "مامان، برگشته‌ای."

    # say L1221 mik
    old "I thought you had gone to sleep."
    new "فکر کردم خوابیدی."

    # say L1223 whi
    old "Oh no, it's just that I had to go to the bathroom. But I came back to finish my dinner."
    new "نه، فقط باید به توالت بردم. اما برگشتم تا غذایم رو تمام کنم."

    # say L1224 whi
    old "By the way, you should finish yours too, before it gets cold."
    new "البته، شما هم باید خودتون رو تمام کنید، قبل از اینکه سرد بشه."

    # say L1225 mik
    old "I know, I know, I was just getting a pill for [pla], where do we keep then?"
    new "می‌دونم، می‌دونم، همین جا بودم یه دارو برای [pla] می‌بردم، اون‌ها کجاست؟"

    # say L1227 pla
    old "You know what, dude?"
    new "دست من، دوست من"

    # say L1228 pla
    old "I don't think I'll need it, the headache is gone."
    new "من فکر نمی‌کنم نیاز به آن داشته باشم، سردرد برداشته."

    # say L1230 whi
    old "Yeah, all you needed was to relax and release everything as Mike said."
    new "بله، همه چیزی که نیاز داشتی این بود که مثل آنچه مایک گفت، آرام شوی و همه چیز را رها کنی."

    # say L1232 mik
    old "Yeah, that's what I sai-... Wait how do you know-"
    new "بله، همین حرف رو زدم... اما چطور می‌دونی-"

    # say L1233 whi
    old "Oh, honey, I'm really hungry and the food is gonna get cold. Why don't we finish this delicious dinner?"
    new "اوه عزیزم، من واقعاً گرسنه‌ام و غذا خیلی زود سرد می‌شود. چرا ما این شام لذت‌بخش رو تمام نکنیم؟"

    # say L1234 pla
    old "Yeah, dude, just enjoy the dinner."
    new "بله، جان، فقط از شام لذت ببر."

    # say L1242 pla
    old "As always Mrs. White, your food is always the best."
    new "همیشه مس خانم وایت، غذاهای شما همیشه بهترین هستند."

    # say L1244 whi
    old "It's very good that you always enjoy... Everything I give you sweety."
    new "خوشحالم که همیشه لذت می‌بری... از همه چیزی که بهت میدم عزیزم."

    # say L1245 whi
    old "It always makes me want to give you some more..."
    new "همیشه من رو ترغیب می‌کنی که بیشتر بهت بدم..."

    # say L1246 pla
    old "Uh... yeah, thank you."
    new "اوه... بله، ممنون."

    # say L1247 pla
    old "Well, it's very late, so I shold go now."
    new "خب، وقت خیلی دیره، پس باید برم."

    # say L1248 mik
    old "Sure man, no problem. Thanks for today."
    new "بله دوست من، هیچ اشکالی نداره. ممنون از امروز."

    # say L1267 pla
    old "Hi Mrs.White, how are you?"
    new "سلام خانم وایت، حالتون چطوره؟"

    # say L1268 whi
    old "Hi sweetie, I'm very well, thank you."
    new "سلام عزیزم، خیلی خوبم، ممنون."

    # say L1269 whi
    old "Let me guess, you came to study with Mike again."
    new "بگویم، اومدی دوباره با مایک مطالعه کنی."

    # say L1270 pla
    old "Yeah, is he here?"
    new "بله، اینجا هست؟"

    # say L1271 whi
    old "I'm sorry, but he isn't, he went out with that girl Olivia."
    new "متأسفم، اما او اینجا نیست، با آن دختر اولیویا بیرون رفت."

    # say L1273 pla
    old "Hmm... I see."
    new "Hmm... من متوجه شدم."

    # say L1274 pla
    old "I suppose I should come later then, right?"
    new "باید بعداً بیام، درسته؟"

    # say L1275 whi
    old "Oh, why do you ask that when you already know the answer?"
    new "اوه، چرا این سوال رو می‌پرسی وقتی قبلاً جوابشو می‌دونی؟"

    # say L1276 whi
    old "No my sweet boy, you're not going anywhere."
    new "نه عزیزم، تو هیچ جا نمی‌روی."

    # say L1277 whi
    old "We're going to finish what we started the other night at dinner."
    new "ما آن کاری که همون شب شام خوردن شروع کردیم رو تمام می‌کنیم."

    # say L1279 whi
    old "Come here sweetie, I want you right now."
    new "بیا اینجا عزیزم، الان می‌خوام تو رو."

    # say L1280 pla
    old "What? Here?"
    new "چه؟ اینجا؟"

    # say L1281 whi
    old "Sure! Why not? We're alone and Mike will take his time."
    new "البته! چرا نه؟ ما تنها هستیم و مایک وقت خودش را می‌برد."

    # say L1282 pla
    old "B- but... I- I mean, he could come back early... or he could"
    new "ب- بله... من- من می‌گم ممکنه زودتر برگرده... یا ممکنه"

    # say L1284 whi
    old "That's enough, Mike doesn't even suspect a thing and you're always worrying."
    new "کافیه، مایک حتی هیچ اشتباهی نداره و تو همیشه نگرانی."

    # say L1285 whi
    old "So stop thinking so much and just get naked."
    new "پس بپرداز به فکر کمتر و فقط عریان شو."

    # say L1286 whi
    old "I want that big cock now!"
    new "من الان می‌خوام اون لوله بزرگ رو!"

    # say L1295 whi
    old "Ah yes! Look at how hard you already are."
    new "آه بله! نگاه کن، قدری سفت شده‌ای."

    # say L1296 whi
    old "That big long dick."
    new "آن لوله بزرگ و طولانی."

    # say L1297 whi
    old "I want you to put in me."
    new "من می‌خوام تو رو توی من وارد کنی."

    # say L1298 whi
    old "I can't wait!"
    new "نمی‌تونم صبر کنم!"

    # say L1313 pla
    old "Hi Mrs. White. It's good seeing you again."
    new "سلام خانم وایت. خوشحالم که دوباره شما رو می‌بینم."

    # say L1314 whi
    old "Hi sweety, are you here to see Mike?"
    new "سلام عزیزم، آیا برای دیدن مایک اومدی؟"

    # say L1316 whi
    old "Well, I'm sorry to tell you that he's not available."
    new "خوب، متاسفانه باید بهت بگم که او در دسترس نیست."

    # say L1317 whi
    old "That girl Olivia came a while ago, and he was very clear that they shouldn't be interrupted."
    new "دختری اسمش اولیویا یه وقتی پیش اومده و او خیلی روشن کرد که نباید به توقف درآیند."

    # say L1320 whi
    old "But don't be sad, because you know what that means."
    new "اما نگران نباش، چون می‌دونی این چه معنی داره."

    # say L1321 whi
    old "It means you and I get to have some fun."
    new "این به معنای اینه که شما و من می‌تونیم یه لحظه خوشحالی بگذرونیم."

    # say L1322 pla
    old "What?! Are you kidding me?!!"
    new "چه!؟ می‌خوای با من مزح کنی؟!!"

    # say L1323 pla
    old "After what happened last time. You still want to do it?!"
    new "بعد از آنچه پیش اومد. هنوز می‌خوای اینو بکنیم؟!"

    # say L1324 whi
    old "Aww, my baby boy is worried."
    new "اوه، پسرک عزیزم نگرانی."

    # say L1325 whi
    old "Don't worry, this time we'll do it in my bedroom, so what happened last time won't happen again."
    new "نگران نباش، این بار در اتاق خواب من انجام می‌دهیم، پس آنچه پیش آمد، دوباره تکرار نمی‌شود."

    # say L1326 pla
    old "Hmm, but what happens if they finish before us and they hear us?"
    new "هم، اما اگر قبل از ما تمام شدن و صدایمون رو بشنوند چه می‌شه؟"

    # say L1327 pla
    old "I mean... How long have they been up there?"
    new "من قصدم... اونا چقدر زمان دارن اونجا؟"

    # say L1328 whi
    old "Hmm, to be honest I didn't really look at the clock."
    new "البته، صادقانه بگم ساعت رو خیلی نگاه نکردم."

    # say L1329 pla
    old "I don't think we should do anything without knowing how long they'll be there."
    new "من فکر می‌کنم باید هیچ کاری انجام ندهیم تا بدونیم چه مدت دیگه آنجا می‌مانن."

    # say L1331 whi
    old "You're thinking too much, just relax a little."
    new "فکر زیاد می‌کنی، فقط یه کم آرام باش."

    # say L1332 pla
    old "I can't, after what happened last time, we need to be sure... And I have an idea."
    new "من نمی‌تونم، بعد از آن چیزی که افتاد، ما باید مطمئن شیم... و یه ایده دارم."

    # say L1333 pla
    old "Let me go upstairs and check on them first."
    new "بیام من بالا برسم و ازشون بررسی کنم."

    # say L1334 whi
    old "Hmm, ok. Do that and let me know."
    new "Hmm، خوب. اینجوری کن و برام بگو."

    # say L1346 pla
    old "Damn, I didn't think Mike and Olivia were really going to do anything."
    new "داشتم فکر می‌کردم مایک و اولیویا واقعاً هیچی نمی‌کنن."

    # say L1347 pla
    old "Well, I guess all that work really paid off. I'm happy for him."
    new "خوب، به نظر می‌رسه همه آن تلاش‌ها به جای خودشون رسیده. برایش خوشحالم."

    # say L1356 whi
    old "So? What topic are they on?"
    new "پس؟ موضوعشون چیه؟"

    # say L1357 pla
    old "Hmm, let's just say they'll be busy for a while."
    new "هم، بگذار بگم که مدتی مشغول خواهند بود."

    # say L1358 pla
    old "So, I think we'll be fine."
    new "پس، فکر می‌کنم ما خوب هستیم."

    # say L1360 whi
    old "Really? Perfect! Let's go to my room then!"
    new "حقاً؟ عالی! بیایید به اتاق من برویم!"

    # say L1378 oli
    old "Whoa! Whoa! Whoa!"
    new "وای! وای! وای!"

    # say L1385 pla
    old "Fuck! She saw us, I have to go after her!"
    new "شیطان! او ما رو دید، باید پشت‌اش برسم!"

    # say L1397 pla
    old "Olivia! Wait!"
    new "اولیویا! صبر کن!"

    # say L1400 oli
    old "Dude! What the fuck!"
    new "دیوونه! چه کاری انجام دادی!"

    # say L1401 oli
    old "You're fucking your friend's mother?! What the fuck is wrong with you."
    new "تو دوستت مادر دوستت رو نیک می‌کنی؟ چه خرابی تو رو گرفته؟"

    # say L1403 pla
    old "It's not what you think! We're just..."
    new "این همچین نیست! ما فقط..."

    # say L1404 oli
    old "You're just what? I saw you dude!"
    new "تو فقط چی؟ من تو رو دیدم!"

    # say L1405 oli
    old "I saw your big coc-... your penis hanging out, and jizz everywhere."
    new "من دیدم آن چیز بزرگت... آن ناخنده را بیرون آمد و سپس جیز همه جا پخش شد."

    # say L1406 pla
    old "Ok, listen, I was doing that, but please you can't tell Mike."
    new "بله، بگوش، من همین کار رو می‌کردم، اما لطفاً به مایک نگو."

    # say L1407 pla
    old "Please! I'm begging you! He'll never forgive me!"
    new "لطفاً! خواهش می‌کنم! او هرگز منو ببخش نخواهد داد!"

    # say L1408 oli
    old "Well, maybe you should've thought about that before fucking his mom."
    new "خب، شاید باید قبل از اینکه با مامانش خودت رو لمس می‌کردی، به این فکر می‌کردی."

    # say L1409 pla
    old "Oh, come on! You wouldn't get anything by telling him that!"
    new "آه، بیا! با این کار هیچ چیز بدست نمی‌یابی!"

    # say L1410 oli
    old "Perhaps I would, who knows?"
    new "شاید هم بله، چه کار داری؟"

    # say L1411 oli
    old "I guess you would be willing to do anything in exchange for me not telling him anything, right?"
    new "بگو تو حتماً هر چیزی رو برای اینکه من بهش نگم بکنی، درسته؟"

    # say L1413 oli
    old "Right?!!!!"
    new "حق باهاتوست؟!!!!"

    # say L1414 pla
    old "I would, I would, I'd do anything, just please don't tell Mike."
    new "من همینجوری، هر چیزی می‌کنم، فقط لطفاً به مایک نگو."

    # say L1417 oli
    old "Listen, I'm leaving now, I can't waste my time on you."
    new "بله، من حالا می‌روم، نمی‌تونم وقتم رو برای تو بگذaram."

    # say L1418 oli
    old "I'm not going to tell him anything... For now."
    new "من هیچ چیزی بهش نمی‌گم... برای حالا."

    # say L1419 oli
    old "We'll see if that changes later."
    new "bebینیم بعداً چه می‌شود."

    # say L1425 pla
    old "Oh, gosh, I'm fucked.."
    new "اوه، خدا، من باز هم در حال شربت‌خوردن هستم."

    # say L1426 pla
    old "(Damn it! She just saw me fucking my best friends mom!)"
    new "لشیط! همین جا مادر دوست خودمو دید!"

    # say L1427 pla
    old "(I have to do something...)"
    new "باید چیزی انجام بدم..."

    # say L1428 pla
    old "(I have to try and convince her someway not to tell Mike.)"
    new "باید بیام اینجوریش راهی پیدا کنم که اونو متقاعد کنم به مایک نگه بیاد."

    # say L1435 mik
    old "Hey man, what's up?"
    new "سلام دیوید، چطوری؟"

    # say L1437 mik
    old "Did you run into Olivia again?"
    new "دیوید تو دوباره با اولیویا برخورد کردی؟"

    # say L1438 pla
    old "Uhh, yeah... Sorry dude."
    new "آره... ببخشید دوست من."

    # say L1439 mik
    old "It's ok dude."
    new "خوبه دوست من."

    # say L1440 mik
    old "I already talked to her about it."
    new "من قبلاً باهاش در موردش حرف زدم."

    # say L1441 mik
    old "I told her that you've been helping me. So don't worry, we're fine."
    new "من بهش گفتم که تو به من کمک می‌کنی. پس نگران نباش، ما خوبیم."

    # say L1442 pla
    old "I see... well, that's very cool dude."
    new "bebین... خوبه داداش."

    # say L1443 mik
    old "Yeah... I guess it is."
    new "بله... به نظر می‌رسه."

    # say L1444 pla
    old "Hey man, listen, today is a little late, so how about we study another time?"
    new "باید برات بگم، امروز خیلی دیره، پس چطور می‌تونیم بی‌قید و شرط همین حالا مطالعه کنیم؟"

    # say L1446 mik
    old "Actually, we don't have to do that for now."
    new "در واقع، الان لازم نیست این کار رو بکنیم."

    # say L1447 pla
    old "Really? Why?"
    new "وای، چرا؟"

    # say L1448 mik
    old "Olivia's going on a trip."
    new "اولیویا سفری داره."

    # say L1449 mik
    old "She's going to be out of time for a while."
    new "او برای مدتی زمان خارج خواهد بود."

    # say L1451 mik
    old "So I don't think you don't have to worry for now."
    new "پس فکر نمی‌کنم برا تو نگرانی باشه حالا."

    # say L1453 pla
    old "That's a relief, I gues..."
    new "این خبر آرام کننده است، حدس زدم..."

    # say L1455 pla
    old "I- I mean... I see... Um, sorry dude. That sucks."
    new "من- من قصدم... متوجه شدم... اوه، ببخشید برو. این خوب نیست."

    # say L1457 mik
    old "Are you kidding me? Dude, it has been awesome spending time with her."
    new "می‌خواهی با من شوخی کنی؟ برو، وقتی با اون جوری گذراندن خیلی عالی بود."

    # say L1458 mik
    old "And I know for a fact that she likes me."
    new "و من مطمئن هستم که او دوست داره از من."

    # say L1459 mik
    old "So, I'm sure I'll see her again when this is over."
    new "پس مطمئنم دوباره هم باهاش می‌بینم وقتی این همه پایان بشه."

    # say L1460 pla
    old "So am I..."
    new "من هم همینطور مطمئنم..."

    # say L1468 whi
    old "[pla]! Did you talk to her? What did she say?"
    new "[pla]! باهاش حرف زدی؟ چه گفت؟"

    # say L1469 pla
    old "Yeah, I did Mrs. White, and I know you're worried about that."
    new "بله، با خانم واایت حرف زدم، و می‌دونم نگران هستی."

    # say L1470 pla
    old "But she said she wasn't going to tell anything to him."
    new "اما او گفت که نمی‌خواهد هیچ چیزی به او بگوید."

    # say L1471 pla
    old "At least for now..."
    new "البته برای حالا..."

    # say L1472 whi
    old "I don't know, what if she tells him? He's going to kill me!"
    new "نمیدونم، اگه بهش بگه چی؟ قطعاً من رو می‌کشه!"

    # say L1473 pla
    old "Hey, it's ok, let me handle it. Ok?"
    new "بیا، راحت باش، بگذار من اینو انجام بدم. خوب؟"

    # say L1475 whi
    old "Ok, I trust you."
    new "باشه، به تو اعتماد دارم."

    # say L1477 pla
    old "Listen, it's very late already, and my mom wants me to eat with her."
    new "بله، الان خیلی دیره و مامان می‌خواد با من غذا بخوریم."

    # say L1478 pla
    old "So I'll be on my way home, and I'll see you later."
    new "پس من به خونه می‌روم و بعداً دوباره می‌بینیم."

    # say L1479 pla
    old "Just try not to worry too much and just let me handle this. Ok?"
    new "فقط نگران نباش و بگذار من این رو حل کنم. خوب؟"

    # say L1481 whi
    old "Ok, ok, I'll try not to think about it."
    new "باشه، باشه، سعی می‌کنم فکر نکنم."

    # say L1482 whi
    old "Bye. I'll see you later baby boy."
    new "بای. بعداً می‌تونیم دوباره ببینیم عزیزم."


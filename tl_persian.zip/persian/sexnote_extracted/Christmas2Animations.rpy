# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/Christmas2Animations.rpy
translate persian strings:

    # say L6 lyd
    old "God! Your cock's always so tasty!"
    new "خدا! همیشه ناخن تو خوش می‌آید!"

    # say L7 lyd
    old "Screw Christmas cookies, this is the treat I wanted!"
    new "بیا، فراموش کن کوکی‌های کریسمس، این همین هدیه‌ام!"

    # say L8 lyd
    old "I bet this is the best way you've ever woken up!"
    new "بیداهم این بهترین راه برای بیدار شدن تو هست!"

    # say L12 lyd
    old "Oh yes! I love the way it feels in my mouth!"
    new "اوه بله! عاشق این حس در دهانم هستم!"

    # say L13 lyd
    old "Do you like to stuff your dick in my mouth in the morning [pla]?"
    new "آیا دوست داری صبح هر روز پیپیتو تو دهانم بگذاری [pla]؟"

    # say L15 lyd
    old "Do you?!"
    new "تو؟!"

    # say L16 pla
    old "Y- yes!"
    new "ب-بله!"

    # say L20 lyd
    old "Oh! I love this!"
    new "اوه! من اینو دوست دارم!"

    # say L21 lyd
    old "Mmf! The taste!"
    new "مم! طعمش عالیه!"

    # menu L39 
    old "Keep going"
    new "ادامه بده"

    # say L44 pla
    old "Lydia! I- I think I'm about to cum!"
    new "لیدیا! من- من فکر کنم قراره بیوم!"

    # say L45 lyd
    old "Yes! Do it! Stuff my mouth with your hot cum!"
    new "بله! انجام بده! دهانم رو با مایه گرم تو پر کن!"

    # say L52 lyd
    old "Merry Christmas to me!"
    new "بله! انجام بده! با گرمی سپری از خودت به من بده! مerry Christmas to me!"

    # say L53 lyd
    old "That was wonderful [pla]!"
    new "این عالی بود [pla]!"

    # say L54 pla
    old "What the hell are you talking about?!"
    new "تو در مورد چه چیزی حرف می‌زنی؟!"

    # say L55 pla
    old "You shouldn't just come into my room and do something like that!"
    new "نباید به اتاق من بیایی و چیزی مثل این انجام بدی!"

    # say L56 pla
    old "What if somebody sees you?!"
    new "اگه کسی تو رو ببینه چه؟!"

    # say L57 lyd
    old "Oh! Relax! You're worrying too much."
    new "اوه! آرامش بده! خیلی نگرانی."

    # say L58 lyd
    old "Nobody saw anything."
    new "هیچ‌کس هیچ چیزی ندیدند."

    # say L59 lyd
    old "And I know you loved it."
    new "و میدونم خوشت اومده."

    # say L60 pla
    old "Hmm, well..."
    new "هم، خب..."

    # say L61 pla
    old "Whatever."
    new "بی‌نهایت."

    # say L73 sis
    old "Mmm! Oh my god! Your dick!"
    new "ممن! خدا می‌دونه! نوکت!"

    # say L74 sis
    old "It's great! I can feel its heat!"
    new "عالیه! گرماش رو می‌تونم حس کنم!"

    # say L75 sis
    old "And also, it's sooo long!"
    new "و همچنین، خیلی طولانی هست!"

    # say L79 sis
    old "What do you think [pla]? Don't you think this fabric's soft?"
    new "چه خبر [pla]؟ فکر نمی‌کنی این بافت نرمه؟"

    # say L80 pla
    old "It- it is... really soft!"
    new "آره... واقعاً نرمه!"

    # say L81 sis
    old "I know, right?"
    new "می‌دونی، همین‌جوری؟"

    # say L82 sis
    old "It's really good quality!"
    new "این واقعاً کیفیت خوبی داره!"

    # say L86 sis
    old "Ah! Ah! I love this!"
    new "آه! آه! من این رو دوست دارم!"

    # say L87 sis
    old "I can feel your dick rubbing my clit!"
    new "می‌تونم ناخن تو رو روی کلیت من حس کنم!"

    # say L88 sis
    old "And with this fabric, it feels so good!"
    new "با این بافت، احساسش خیلی خوبه!"

    # say L111 pla
    old "[sis]! I- I'm about to cum!"
    new "[sis]! من- من در حال خروج هستم!"

    # say L112 sis
    old "Do it, shoot it all out!"
    new "بکن، همه‌اش رو بیرون بیا!"

    # say L113 sis
    old "Don't worry about the costume!"
    new "نگران لباس نباش!"

    # say L114 sis
    old "This fabric is anti-fluid!"
    new "این بافت ضد سیاله!"

    # say L115 sis
    old "Shoot it all out!"
    new "همه‌ش رو بیرون بیاورد!"

    # say L123 sis
    old "Oh my god! Look at all that thick load coming of your dick."
    new "اوه خدا! نگاه کن به همه اون لیم که از پیپت می‌آد."

    # say L124 pla
    old "... Right."
    new "... درسته."

    # say L125 sis
    old "I just loved the way your dick rubbed againts my clit!"
    new "من فقط دوست داشتم که پیپت به کلیت من می‌خورد!"

    # say L126 sis
    old "It turned me on so much!"
    new "اینقدر خیال من رو جوش داد!"

    # say L127 sis
    old "Ok, I think these new outfits are ready to be posted!"
    new "خب، فکر کنم این لباس‌های جدید آماده‌ی قرار گرفتن هستند!"

    # say L139 mo2
    old "Oh yes! This lube is perfect!"
    new "اوه بله! این لب خیلی خوبه!"

    # say L140 mo1
    old "Just look at how your dick slides between our tits!"
    new "ببین چطور نیم‌تنه‌ات بین پستان‌هامون حرکت می‌کنه!"

    # say L141 lyd
    old "And it feels so hot!"
    new "و این حرارت خیلی خوب است!"

    # say L145 mo1
    old "Do you like how that feels [pla]?"
    new "آیا این حس را دوست داری [pla]؟"

    # say L146 pla
    old "I- I do! It's great!"
    new "من- من هم می‌پذیرم! خیلی خوبه!"

    # say L147 mo1
    old "That's great baby! I love that you love it!"
    new "عالیه بزرگی! خوشحالم که تو ازش لذت می‌بری!"

    # say L148 mo2
    old "Do it faster [pla]! Use that lube!"
    new "سریع‌تر بکن [pla]! از اون لب استفاده کن!"

    # say L152 lyd
    old "Oh! Yes! I love the way your cock bounces between our tits!"
    new "اوه! بله! عاشقم اینطور که نوزه‌ت بین پستان‌هامون پر می‌کنه!"

    # say L153 mo1
    old "My god [mo2]! This lube is fantastic!"
    new "الهی ز[mo2]! این لب واقعاً عالیه!"

    # say L154 mo2
    old "It feels great!"
    new "این حس خوب است!"

    # say L155 mo2
    old "How much do you like this [pla]?"
    new "اینقدر خوشت می‌آید [pla]؟"

    # say L156 mo2
    old "Tell us!"
    new "بگو!"

    # say L157 pla
    old "I- I love it!"
    new "من- من ازش خوشم می‌آید!"

    # say L181 pla
    old "I- I'm about to cum!"
    new "من- من قراره بیافzem!"

    # say L182 pla
    old "I can't hold it in anymore!"
    new "دیگه نمی‌تونم خودمو نگه دارم!"

    # say L183 mo1
    old "Do it honey!"
    new "بفرمای حلوایی!"

    # say L184 lyd
    old "Yes! Do it [pla]! Cum for us!"
    new "بله! انجام بده [pla]! برای ما خروجی داشته باش!"

    # say L185 mo2
    old "Make it a white Christmas for us [pla]!"
    new "برای ما یک کریسمس سفید بساز [pla]!"

    # say L194 mo1
    old "Oh that's just great! I love the way your cum tastes [pla]!"
    new "اوه این خیلی عالیه! من عاشق طعم سپرمتو هستم [pla]!"

    # say L195 mo2
    old "It's so thick and warm."
    new "این هم ضخیم و گرم است."

    # say L206 sis
    old "Uhgn! Oh my God [pla]!"
    new "اوه خدا ز[pla]!"

    # say L207 sis
    old "How are you this big!"
    new "چطور اینقدر بزرگ هستی!"

    # say L208 sis
    old "It feels even bigger than the way it looks!"
    new "این حتی بزرگتر از آنچه به نظر می‌رسد است!"

    # say L212 sis
    old "God! I love the way your dick feels me up!"
    new "خدا! دوست دارم احساس پوسیدن من با این نی باشه!"

    # say L213 sis
    old "It's so hot!"
    new "اوه، خیلی گرمه!"

    # say L215 sis
    old "Keep going [pla]! Don't stop!"
    new "ادامه بده [pla]! متوقف نشو!"

    # say L219 sis
    old "Oh my God! Oh my God!"
    new "اوه خداوند! اوه خداوند!"

    # say L220 sis
    old "Y- You're so hot [pla]!"
    new "تو خیلی داغی [pla]!"

    # say L221 sis
    old "This is the best Christmas gift ever!"
    new "این بهترین هدیه کریسمس هست!"

    # say L222 sis
    old "Oh my God! I love the way you fuck me!"
    new "اوه خداوند! من عاشق طرز دادنت به من هستم!"

    # say L245 pla
    old "[sis] I- I think I'm about to cum! I can't hold it back anymore!"
    new "[sis] من- من فکر کنم قراره بیافzem! دیگه نمی‌تونم خودمو کنترل کنم!"

    # say L246 sis
    old "Y- Yes! D- D- Do it!"
    new "بله! ب- ب- بکن!"

    # say L247 mo2
    old "Yes! Do it! Cum inside your [sisrel]! You little pervert!"
    new "بله! انجام بده! در داخل ز[sisrel] تو بیا! تو خیلی پرتربی!"

    # say L254 sis
    old "Oh wow! That was so good!"
    new "اوه وای! اینقدر خوب بود!"

    # say L255 sis
    old "Honestly [pla], your cock must be magical!"
    new "Honestly [pla]، حتماً ناخودآگاهی سختی جادویی داره!"

    # say L256 sis
    old "Because it's insane how crazy good it is!"
    new "چون واقعاً خیلی خوبه، مثل جادویی!"

    # say L258 sis
    old "Well, that was the best Christmas gift I think I could've asked for."
    new "خب، این بهترین هدیه کریسمسی بود که می‌تونستم درخواست کنم."

    # say L259 sis
    old "Even though I was such a naughty girl all year."
    new "البته، حتی با اینکه طول سال خوب نبودم."

    # say L274 mo2
    old "I bet you've been waiting to fuck me!"
    new "حتماً منتظر بودی با من جنس کنی!"

    # say L275 mo2
    old "Well, you finally get your gift!"
    new "خب، حالا هدیه‌اتو می‌گیری!"

    # say L276 mo2
    old "My pussy's been aching for a hard big cock!"
    new "پوسی من از اون جوری که به یک نیم‌سخت بزرگ نیاز داره درد می‌کنه!"

    # say L285 mo2
    old "Mmm! Oh yeah!"
    new "مم! اوه بله!"

    # say L286 mo2
    old "That's just the thing I wanted for Christmas!"
    new "این همین چیزی بود که برای کریسمس می‌خواستم!"

    # say L287 mo2
    old "So big!"
    new "اینقدر بزرگ!"

    # say L288 mo2
    old "The girth is just amazing!"
    new "قطرش واقعاً شگفت‌انگیزه!"

    # say L292 mo2
    old "I bet you like this, don't you?"
    new "حتماً اینو دوست داری، نه؟"

    # say L293 mo2
    old "You like fucking me like an animal?"
    new "مادرت مثل حیوان با من سکس می‌کنی، خوشت می‌آید؟"

    # say L294 mo2
    old "Tell me!"
    new "بگو!"

    # say L295 pla
    old "I- I do! I like it a lot!"
    new "من- من هم می‌پردم! خیلی دوست دارم!"

    # say L296 mo2
    old "Oh- OH! You little bastard!"
    new "اوه- اوه! تو خردلولوی کوچیک!"

    # say L300 mo2
    old "You little pathetic slave! The only good thing about you is that long cock!"
    new "تو خرکوچک بی‌ارزشی! تنها چیز خوب ازت اون نیم‌تن بلندت هست!"

    # say L301 mo2
    old "You hear me? You're worthless without it!"
    new "می‌شنوی؟ بدون اون هیچ ارزشی نداری!"

    # say L302 mo2
    old "Your cock and balls are only good for this!"
    new "پوس و بیل تو فقط برای این خوب هستند!"

    # say L303 mo2
    old "Keep going! Keep fucking me! You worthless slave!"
    new "ادامه بده! ادامه بده و منو بفرمای! تو عبود بی‌ارزشی!"

    # say L326 mo2
    old "I- AH! I can feel your cock twitching!"
    new "اوه! می‌تونم خودت ریز بشه!"

    # say L327 mo2
    old "Are you about to cum, you little pervert?!"
    new "آیا قراره خودت را بیاوردی، تو خیال‌پرداز کوچک؟!"

    # say L328 pla
    old "I- ugh! I am!"
    new "من- اوه! من هستم!"

    # say L329 mo2
    old "Do it! Fill me with your worthless cum!"
    new "بکن! با سیالت بی‌ارزش منو پر کن!"

    # say L337 mo1
    old "Wow [mo2], baby, that looked fantastic!"
    new "واو ز[mo2]، عزیزم، این خیلی خوب بود!"

    # say L338 mo2
    old "I guess it was good."
    new "به نظر می‌رسه خوب بود."

    # say L353 mo2
    old "I bet you're happy you get to fuck your [mo1rel] on Christmas day, you little pervert."
    new "حتماً خوشحالم که می‌تونی تو روز کریسمس با [mo1rel] تو زدن، تو خوبه کوچولو."

    # say L354 pla
    old "Y-yeah, sure."
    new "ب-bale، حتماً."

    # say L363 mo1
    old "Oh my god, honey!"
    new "اوه خدا، عزیزم!"

    # say L364 mo1
    old "Y- Your dick, is so big!"
    new "ی- پیپی تو خیلی بزرگه!"

    # say L365 mo1
    old "It's so hot! So thick!"
    new "اوه، آتشینه! خیلی ضخیمه!"

    # say L369 mo1
    old "Oh my god I love it!"
    new "اوه خدا، دوست دارم!"

    # say L370 mo1
    old "I love to feel you filling me up!"
    new "من دوست دارم حس کنم تو من رو پر می‌کنی!"

    # say L371 mo1
    old "D- Do you like it too [pla]?"
    new "د- تو هم دوست داری؟ [pla]"

    # say L372 pla
    old "I do! I like it!"
    new "من هم دوست دارم!"

    # say L373 mo1
    old "Oh then keep going, honey!"
    new "اوه پس ادامه بده، عزیزم!"

    # say L377 mo1
    old "Oh yes! Yes! YES!"
    new "اوه بله! بله! بله!"

    # say L378 mo1
    old "This is what I wanted!"
    new "این همینه که می‌خواستم!"

    # say L379 mo2
    old "I bet this makes a very merry Christmas for you, doesn't it [mo1]?"
    new "حتماً این برای تو یک کریسمس خوشحال‌بخش می‌شود، همینطور نیست [mo1]؟"

    # say L380 mo1
    old "It does! this is the best Christmas ever!"
    new "بله! این بهترین کریسمس همیشه است."

    # say L403 mo1
    old "I- I think I'm coming!"
    new "من- من فکر می‌کنم آمدم!"

    # say L404 mo1
    old "Come with me [pla]!"
    new "با من بیا [pla]!"

    # say L405 mo1
    old "L- Let's do it together!"
    new "L- بیای، همراه من بیای!"

    # say L406 pla
    old "Y- Yes!"
    new "B- بله!"

    # say L414 mo1
    old "Oh baby. That was the best Christmas gift ever!"
    new "اوه بچه عزیزم. این بهترین هدیه کریسمس بود!"

    # say L415 mo1
    old "It's amazing, I'm so satisfied!"
    new "الانه، واقعاً خیلی خوشحالم!"

    # say L416 lyd
    old "Isn't he just a wonderful young man?"
    new "آیا او فقط یک جوان عالی نیست؟"

    # say L417 mo1
    old "Your dick is so addicting!"
    new "لید: خوب، از صبح می‌خواستم با تو بفراموشی حلویی!"

    # say L432 lyd
    old "Well, I've been wanting to fuck you since the morning sweety!"
    new "خب، از صبح می‌خواستم با تو بفراموشی حلویی!"

    # say L433 lyd
    old "I couldn't keep waiting!"
    new "نمی‌تونستم بیشتر صبر کنم!"

    # say L442 lyd
    old "Oh! Uh! My God! It already feels amazing!"
    new "اوه! اوه! خداوند! قطعاً خیلی خوبه!"

    # say L443 lyd
    old "I- Mmm! I can't believe how big and hard you are!"
    new "من- مم! نمی‌تونم باور کنم چقدر بزرگ و سختی!"

    # say L444 lyd
    old "I- It's so amazing!"
    new "وای، خیلی عالیه!"

    # say L445 mo1
    old "It's incredible how much it fills you up, right?"
    new "الان می‌فهمی چقدر تو رو پر می‌کنه، درسته؟"

    # say L446 lyd
    old "It is!"
    new "البته!"

    # say L450 lyd
    old "I- I love your cock!"
    new "من- من عاشق ناخن تو هستم!"

    # say L451 mo2
    old "It seems you weren't a naughty girl this year Lydia."
    new "به نظر می‌رسه این سال خوب بودی لیدیا."

    # say L452 mo2
    old "Because look at the gift Santa brought you!"
    new "چون ببین به هدیه‌ای که سانتا به تو آورد!"

    # say L453 lyd
    old "Y- Yes! I love it!"
    new "بله! عاشقش شدم!"

    # say L457 lyd
    old "YES! YES! YES!"
    new "بله! بله! بله!"

    # say L458 lyd
    old "Keep going [pla]! Oh yes!"
    new "ادامه بده [pla]! اوه بله!"

    # say L459 lyd
    old "Oh! Ah! My God! I love it!"
    new "اوه! اه! خداوند! عاشق اینم!"

    # say L460 mo2
    old "That's it [pla]! Fuck her brains out!"
    new "آره [pla]! براش مغز بزن!"

    # say L483 lyd
    old "I feel you're close to cum!"
    new "احسas می‌کنم نزدیک هیجان‌دهنی هستی!"

    # say L484 lyd
    old "I want you to do it!"
    new "من می‌خوام تو این کار رو بکنی!"

    # say L485 lyd
    old "Fill me up with your hot cum!"
    new "من رو با آبکیس تو پر کن!"

    # say L495 lyd
    old "God! That was so good [pla]!"
    new "الهی! اینقدر خوب بود [pla]!"

    # say L496 lyd
    old "Your dick is so hot!"
    new "پوس تو خیلی گرمه!"

    # say L497 lyd
    old "You know, I think it would be easy to get addicted to it."
    new "می‌دونی، فکر کنم خیلی آسونه بهش اعتیاد پیدا کنم."

    # say L498 pla
    old "I- I see."
    new "من- من می‌بینم."


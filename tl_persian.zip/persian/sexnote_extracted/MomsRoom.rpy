# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/MomsRoom.rpy
translate persian strings:

    # say L22 pla
    old "(Let's try this again...)"
    new "بیای دوباره سعی کنیم..."

    # say L26 mo2
    old "Oh! Again, baby? You sure are horny these days."
    new "اوه! دوباره، عزیزم؟ این روزها واقعاً خیلی شهوت‌مندی."

    # say L28 mo2
    old "But I definitely do love it!"
    new "ولی حتماً دوست دارم!"

    # say L29 pla
    old "(Nice. She still thinks I'm my [mo1rel]!)"
    new "(خوبه. هنوز فکر می‌کنه من [mo1rel] هستم!)"

    # say L39 pla
    old "(I'll just do it very carefully...)"
    new "(من فقط بسیار محتاط انجام می‌دم...)"

    # say L50 pla
    old "(What if...)"
    new "(اگه...)"

    # say L51 pla
    old "(Oh no... She would kill me... But on the other hand... What if she doesn't notice...)"
    new "اوه نه... او من رو می‌کشد... اما از طرف دیگه... چطور می‌دونیم متوجه نمی‌شه..."

    # say L52 pla
    old "(Well... I think there is a chance and if it works I can keep doing it.)"
    new "خب... فکر کنم احتمالی هست و اگه کار کنه می‌تونم ادامه بدم."

    # say L53 pla
    old "(All I need to do is be really careful and I'll get out of this alive...)"
    new "من فقط باید خیلی مراقب باشم تا از این حالت زنده بیرون بیوم..."

    # say L55 pla
    old "(Oh man, I think I will regret this.)"
    new "اوه مرد، فکر کنم اینو تاسف خواهم داشت."

    # say L57 mo2
    old "Is that you, baby?"
    new "آره، تو هستی، عزیزم."

    # say L58 pla
    old "(OH SHIT! I'M DEAD MEAT!)"
    new "اوه شیطان! من مردم!"

    # say L59 mo2
    old "Mmm, is it my turn to be fucked?"
    new "می‌دونم، الان وقت من برای زدن جامه است؟"

    # say L60 pla
    old "(What the hell? She thinks I'm [mo1]! Score!)"
    new "چه خبر؟ فکر می‌کنه من [mo1] هستم! امتیاز!"

    # say L67 mo2
    old "Oh, I see. You don't want the kids to hear us. Ok, then fuck me quietly..."
    new "اوه، من متوجه شدم. نمی‌خوای بچه‌ها به صدای ما برسن. خب، بعدش به من به آرامی بکن..."

    # say L68 pla
    old "(Yup. I'm definitely the luckiest guy ever!)"
    new "بله. قطعاً من احتمالاً شادترین مرد جهان هستم!"

    # say L69 mo2
    old "Mmm, fuck! It feels bigger than usual. Are you using a new strap-on?"
    new "ممن، بزرگتر از همیشه است. آیا یک سرپین جدید استفاده می‌کنی؟"

    # say L71 mo2
    old "Fine. Be quiet, just please don't stop!"
    new "خوب. بی‌صدا باش، فقط لطفاً متوقف نشو!"

    # say L72 mo2
    old "(This is the best I've ever had!)"
    new "این بهترین چیزیه که تا حالا داشتم!"

    # say L81 pla
    old "(I will just do it carefully...)"
    new "(من فقط با دقت انجام می‌دم...)"

    # say L90 pla
    old "(Damn!... She's amazing but... I should leave. I don't want to wake her up.)"
    new "لعنتی... او شگفت‌انگیز است اما... باید برسم. نمی‌خوام تو رو بیدار کنم."

    # say L100 pla
    old "(Carefully...)"
    new "(با دقت...)"

    # say L104 pla
    old "(Fuck! She is almost naked! So sexy.)"
    new "(شیطان! تقریباً عریانه! خیلی جذابه.)"

    # say L105 pla
    old "(I should go, though. I don't want to wake her up.)"
    new "باید برسم، ولی نمی‌خوام اون رو بیدار کنم."

    # say L116 pla
    old "(She's sleeping? I shouldn't make any noise.)"
    new "(او خوابیده؟ نباید هیچ صدایی بکنم.)"

    # say L134 pla
    old "(Wait... What was that noise?)"
    new "(پیش... اون صدایی از کجا می‌ومد؟)"

    # say L137 pla
    old "It's coming from my [mo1rel]'s bedroom... I should go check it out."
    new "صدا از اتاق خواب [mo1rel] می‌آید... باید برم بررسی کنم."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/ayeAnimations.rpy
translate persian strings:

    # say L6 aye
    old "My god this dick is so big!"
    new "الهی این ناخن به همراه چقدر بزرگه! ⇒ اللهی این ناخن به همراه چقدر بزرگه!"

    # say L7 aye
    old "I noticed it the last time!"
    new "من هم آخر بار متوجه شدم!"

    # say L8 aye
    old "But having it in my mouth is just something else!"
    new "اما داشتنش توی دهانم چیزی دیگه است!"

    # say L12 aye
    old "I bet you've never gotten head like this before right?"
    new "حتماً قبلاً هیچ‌کس به تو اینجوری نکرده، درسته؟"

    # say L13 aye
    old "I know I'm so much better than my sister!"
    new "میدونم خیلی بهتر از خواهرم هستم!"

    # say L14 aye
    old "I'm sure there's no comparison!"
    new "مطمئنم هیچ مقایسه‌ای نداره!"

    # say L18 aye
    old "Is this good [pla]?!"
    new "این خوبه [pla]؟!"

    # say L19 pla
    old "Y- yeah, it is!"
    new "بله، خوبه!"

    # say L20 aye
    old "Slrrp! Mmm!"
    new "سلرب! مم!"

    # say L21 aye
    old "Of course it is! I'm so much better than Olivia!"
    new "البته هست! من خیلی بهتر از اولیویا هستم!"

    # say L44 aye
    old "I- I can feel like you're about to finish!"
    new "من- من می‌تونم بفهمم تو خیلی زود می‌رسی!"

    # say L45 pla
    old "Y- yeah! I am!"
    new "بله! من هستم!"

    # say L46 aye
    old "Do it! I want to get your cum in my mouth!"
    new "بکن! می‌خوام سیالتو تو دهانم بیوفتم!"

    # say L53 aye
    old "Look at how much you came!"
    new "ببین چقدر آمدی!"

    # say L54 aye
    old "You see? I told you I was way better than Olivia!"
    new "دیدی؟ خودت هم گفتی من از اولیویا خوبتر هستم!"

    # say L55 aye
    old "I bet you've never had anything like that before!"
    new "حتماً هیچ وقت چیزی مثل این ندیده‌ای!"

    # say L56 pla
    old "Yeah, yeah..."
    new "بله، بله..."

    # say L57 pla
    old "Listen, get up before your mother or your sister come here and see us like this."
    new "بفرم خیز قبل از اینکه مامان یا خواهرت بیادون و ما رو اینجور ببینن."

    # say L58 aye
    old "Ugh, you're such a prude."
    new "اوه، تو همینجوری خسته‌کننده هستی."


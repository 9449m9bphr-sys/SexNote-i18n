# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/OliHome.rpy
translate persian strings:

    # menu L12 
    old "Talk to her."
    new "باهاش حرف بزن"

    # say L89 oli
    old "Hmm, are we starting or what?"
    new "هم، ما شروع می‌کنیم یا چه؟"

    # say L90 pla
    old "Uhh... E- excuse me?"
    new "اوه... ع- عذرخواهی می‌کنم."

    # say L92 oli
    old "I'm asking you if we're going to study or something."
    new "من از تو می‌پرسم که آیا قراره مطالعه کنیم یا چیزی."

    # say L94 oli
    old "Because you just stayed there staring at me like a creep."
    new "چون تو فقط اونجا ایستادی و مثل یه خر به من نگاه می‌کردی."

    # say L96 pla
    old "S- sorry, I- I didn't notice I was doing it."
    new "ببخشید، من متوجه نشدم که اینجوری به تو نگاه می‌کنم."

    # say L97 pla
    old "I was just passing by and wanted to say hello."
    new "من فقط از کنار می‌گذرم و می‌خواستم سلام بزنم."

    # say L99 oli
    old "That's it? Alright."
    new "این همه؟ خب، می‌تونی بیاد."

    # say L101 oli
    old "But make sure to come back soon. We’ve got a lot to study."
    new "اما حتماً زودی برگرد. کارهای زیادی برای مطالعه داریم."

    # say L102 pla
    old "Sure, don't worry about it. I'll see you soon."
    new "بله، نگران نباش. زود بهت می‌بیام."

    # say L112 oli
    old "Hey, what's up? Did you come to study with me?"
    new "سلام، چطوری؟ اومدی با من مطالعه کنی؟"

    # say L114 pla
    old "Hey, oh no, I can't right now, I just wanted to say hi."
    new "هی، نه، الان نمی‌تونم، فقط می‌خواستم سلام بزنم."

    # say L116 oli
    old "Hmm, alright, but make sure you come back soon."
    new "Hmm، خوب، اما حتماً زود بر می‌گردی."

    # say L117 oli
    old "So we can hit the books together."
    new "پس می‌تونیم با هم درس بخونیم."

    # say L119 pla
    old "Sure thing."
    new "بله، حتماً."

    # say L165 vee
    old "Excuse me [pla], do you need anything?"
    new "ببخشید [pla]، نیازی به چیزی داری؟"

    # say L167 pla
    old "Uhmm, no, sorry ma'am, I- uh- I was just passing by."
    new "اوه، نه، ببخشید، من- اوه- فقط اینجا می‌گذرم."

    # say L169 vee
    old "I see... Well, I guess I'll see you around then."
    new "می‌بینم... خب، حدس می‌زنم دیگه دیده‌تم."

    # say L180 vee
    old "Hello [pla], how are you today?"
    new "سلام ز[pla]، امروز چطوری؟"

    # say L182 pla
    old "Hello Mrs. Priya, I'm fine, how about you?"
    new "سلام خانم پریا، من خوبم، تو چطوری؟"

    # say L184 vee
    old "I'm doing alright."
    new "من خوب هستم."

    # say L185 vee
    old "Tell me, do you need anything?"
    new "بگو، نیازت به چیزی هست؟"

    # say L186 pla
    old "Oh, not really. I just wanted to say hello."
    new "اوه، نه. فقط می‌خواستم سلام بگم."

    # say L188 vee
    old "I see, well, I guess I'll see you around then."
    new "ببینم، خب، حدس می‌زنم همینجوری دیگه می‌بینیم هم."

    # say L189 pla
    old "Sure thing ma'am, see you."
    new "البته، ببینم تو رو."


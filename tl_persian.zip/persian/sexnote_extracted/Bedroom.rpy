# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Bedroom.rpy
translate persian strings:

    # say L10 pla
    old "I should go to the garage to talk with Brixxida first..."
    new "باید به گاراژ برسم و با بریکسیدا صحبت کنم..."

    # say L22 pla
    old "Ah. I feel rested..."
    new "اح. حس می‌کنم نرم شدم..."

    # say L61 pla
    old "I should probably go talk to Billie..."
    new "باید احتمالاً بریم حرف با بیلی بزنم..."

    # menu L67 
    old "Sleep"
    new "خواب"

    # say L82 pla
    old "It's time to sleep..."
    new "الان وقت خوابه..."

    # say L321 pla
    old "Ready for a new day!"
    new "آماده‌ام برای روز جدید!"

    # say L323 pla
    old "Today is [mo1rel]'s medical appointment day, I should talk her."
    new "امروز روز مراجعه پزشکی [mo1rel]ه، باید باهاش صحبت کنم."

    # say L365 pla
    old "Wow... What's going on..."
    new "وای… چه خبره…"

    # say L383 pla
    old "Oh shit... Not again..."
    new "اوه شیطون... دوباره نه..."

    # say L400 pla
    old "What the hell!..."
    new "چه خبره!..."

    # say L416 pla
    old "Really? You again!?..."
    new "وای، دوباره تو هستی؟!"


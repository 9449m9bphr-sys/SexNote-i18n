# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/bilAnimations.rpy
translate persian strings:

    # say L6 lin
    old "Wow! I see you've a lot of energy repressed... Big and impressive."
    new "واو! می‌بینم انرژی زیادی داری سرکوب شده... بزرگ و ابر قدرتمند."

    # say L7 pla
    old "... I guess..."
    new "... من حدس می‌زنم..."

    # say L13 lin
    old "Ohh it tastes great! I really like it."
    new "اوه خوشمزه است! واقعاً دوست دارم."

    # say L19 lin
    old "Oh yeah... Give it to me... Give me all your load!"
    new "اوه بله... بده به من... بده تمام لیلتو به من!"

    # say L44 lin
    old "Ahhh... I'm feeling it on my mouth!"
    new "اوه... من این حس رو در دهانم می‌تونم بکنم!"

    # say L49 lin
    old "Hmmm, It was great... Now I need your dick inside, the energy transfer should be done now."
    new "Hmm، عالی بود... حالا نیاز دارم شما داخل من باشی، انتقال انرژی باید تمام شده باشه."

    # say L71 lin
    old "Oh yeah... I haven't felt this in a long time ..."
    new "اوه بله... این را از طولانی پیش حس نکرده بودم."

    # say L76 lin
    old "Wow is huge and is drilling this girl..."
    new "واو، همینطور بزرگه و این دختر رو در حال سوراخ کردن است..."

    # say L82 lin
    old "Ohhh yeahhh, harder, harder!"
    new "اوه همینه، سخت‌تر، سخت‌تر!"

    # say L83 lin
    old "Don't stop! Gimme more! I want it all!"
    new "توقف نکن! بیشتر بده! من می‌خوام همه‌ش رو!"

    # say L107 lin
    old "Ahhhhh.... Yeah!"
    new "اوه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه‌ه"

    # say L108 pla
    old "Wow... Ahhhhhhhh!"
    new "واو... آههههههه!"

    # say L113 pla
    old "Pfff... "
    new "پف..."

    # say L124 bel
    old "Hmm, Billie has really big boobs, isn't she [pla]?"
    new "هم، بیلی سینه‌های خیلی بزرگی داره، نیست [pla]؟"

    # say L125 pla
    old "Ohh yeah..."
    new "اوه بله..."

    # say L130 bel
    old "How does it feel to get your boobs sucked Billie?"
    new "بیلی، احساست چطوره وقتی سیناتو خوردن؟"

    # say L131 bil
    old "I'm not gonna lie, it feels pretty nice."
    new "من نمی‌تونم دروغ بگم، احساس خوبی داره."

    # say L137 bel
    old "Woahh, [pla] are you getting excited?"
    new "واو، [pla] آیا خوشحال می‌شی؟"

    # say L138 bil
    old "Mmm, I'm really enjoying it..."
    new "ممنون، لذت بردم..."

    # say L139 bel
    old "Mmm..."
    new "ممنون، لیزت بردم..."

    # say L162 bil
    old "All right, I think is enough."
    new "خوب، فکر کنم کافیه."

    # say L173 bel
    old "So Billie? Do you like that big dick in your mouth?"
    new "بلی، بیلی؟ آیا دوست داری اون نیم‌پا رو تو دهانت بیاد؟"

    # say L174 bil
    old "Mmmm."
    new "ممنون، بله. من لذت می‌برم."

    # say L175 bel
    old "Yeah, I bet you do. Just enjoy it."
    new "بله، حتماً. فقط لذت ببر ازش."

    # say L181 bel
    old "Keep going, you have to do it well. Are you enjoying it [pla]?"
    new "ادامه بده، باید خوب انجام بدی. لذت می‌بری [pla]؟"

    # say L182 pla
    old "Uhh... Mmm..."
    new "اوه... مم..."

    # say L183 bel
    old "He's enjoying it Billie!"
    new "او لذت می‌بره بیلی!"

    # say L184 bil
    old "Gulp."
    new "گلوله."

    # say L189 bil
    old "Slurrp, I- I can feel you getting even harder."
    new "سلورپ، من- من می‌تونم حس کنم تو حتی سخت‌تر می‌شی."

    # say L190 bel
    old "He's close Billie! Keep going!"
    new "او نزدیکه بیلی! ادامه بده!"

    # say L191 pla
    old "Ahhh, ahhhh!"
    new "اوه، اوه!"

    # say L215 bel
    old "That's it Billie! Just like that."
    new "بله بیلی! همینطور."

    # say L216 pla
    old "Ahh! I- I'm cumming!"
    new "اوه! من- من در حال خروج هستم!"

    # say L221 bil
    old "Ugh, duuude, you came all in my mouth!"
    new "اوه، دوست عزیزم، تو همه‌ش رو توی دهان من خرج کردی!"

    # say L222 bil
    old "And Belle had already told you to be careful!"
    new "و بله قبلا بهت گفته بودی دقت کنی!"

    # say L223 pla
    old "S- sorry, I couldn't stop myself."
    new "ب- ببخشید، خودم نتونستم متوقف بشه."

    # say L224 bel
    old "Yeah, he does come a lot, doesn't he?"
    new "بله، او خیلی می‌آید، همینطوره؟"

    # say L225 bil
    old "He does, anyway, help me clean myself."
    new "بله، هر جوری، به من کمک کن تا خودمو تمیز کنم."

    # say L226 pla
    old "S- sure..."
    new "بله... حتماً..."

    # say L239 pla
    old "Oh God... [bil]..."
    new "اوه خدا... [bil]..."

    # say L240 bil
    old "Mmm... you taste even better than I remembered."
    new "مم... طعم تو حتی بهتر از آنچه به یاد داشتم است."

    # say L241 pla
    old "This feels... insane."
    new "این حس... غیرمنطقی است."

    # say L242 bil
    old "Good. That's the point."
    new "خوب. همین جوری باید باشه."

    # say L247 bil
    old "A little faster now..."
    new "الان یک کم سریع‌تر..."

    # say L248 pla
    old "Yes... please... don't stop."
    new "بله... لطفاً... متوقف نشو."

    # say L249 bil
    old "Your cock's throbbing... love feeling you like this."
    new "پوس تو در حال تپش است... دوست دارم اینطور احساس کنم."

    # say L254 bil
    old "Harder... give me more."
    new "سخت‌تر... بیشتر بده به من."

    # say L255 pla
    old "[bil]... I'm close..."
    new "[bil]... من نزدیک هستم..."

    # say L256 bil
    old "Yeah? Cum for me. Fill my mouth."
    new "بله؟ برای من خروجی داشته باش. دهانم رو پر کن."

    # say L257 pla
    old "Oh fuck... yes!"
    new "اوه شیطون... بله!"

    # say L281 pla
    old "I- I'm cumming—!"
    new "من- من در حال خروجی داشتن هستم—!"

    # say L282 bil
    old "Mmm... give it all to me."
    new "ممنون... همه‌اش رو به من بده."

    # say L283 bil
    old "Every drop... that's it."
    new "هر قطره... همین‌طور."

    # say L290 pla
    old "That was... wow."
    new "این بود... وای."

    # say L291 bil
    old "Better?"
    new "بهتر شد؟"

    # say L292 pla
    old "Uhh, yeah, definetly, t- thank you..."
    new "اوه، بله، قطعاً، ممنون..."

    # say L293 bil
    old "Alright... we should clean up this mess before my grandma walks in."
    new "البته... باید این خرابی رو قبل از اینکه باباام وارد بشه تمیز کنیم."

    # say L294 pla
    old "Yeah... good idea."
    new "بله... خوبه."

    # say L306 pla
    old "Is this okay?"
    new "این جوری خوبه؟"

    # say L307 bil
    old "Oh god, yeah... you're doing it right. Keep the technique."
    new "اوه خدا، بله... تو درست انجام میدی. تکنیکت رو حفظ کن."

    # say L311 bil
    old "Faster now. Rub harder."
    new "سریع‌تر شو. بیشتر بفرک."

    # say L312 pla
    old "You're so tight..."
    new "تو خیلی تنگی..."

    # say L313 bil
    old "Deeper. D-don't stop-"
    new "عمیق‌تر. د-دستت رو متوقف نکن-"

    # say L317 bil
    old "Harder! I want to feel you deeper."
    new "سخت‌تر! می‌خوام عمیق‌تر احساست کنم."

    # say L318 pla
    old "[bil]... you're pulsing..."
    new "[bil]... تو در حال تپشی هستی..."

    # say L319 bil
    old "Yes! I'm close!"
    new "بله! من نزدیک هستم!"

    # say L320 pla
    old "Oh fuck..."
    new "اوه فک..."

    # say L344 bil
    old "Oh God... that's it."
    new "اوه خداوند... این هست."

    # say L350 pla
    old "That was... intense."
    new "این بود... شدید."

    # say L351 bil
    old "Phew... yeah, it was nice."
    new "پوف... بله، خوب بود."

    # say L352 bil
    old "Better fingers?"
    new "انگشت‌هایت بهتر شدند؟"

    # say L353 pla
    old "Way better. Like they woke up."
    new "خیلی بهتر. مثل اینکه بیدار شدن."

    # say L368 bil
    old "Mmm... feel better already?"
    new "ممنون... حالا خوبتر می‌تونم حس کنم؟"

    # say L369 pla
    old "Yeah... tension's melting away."
    new "بله... تنش در حال ذوب شدن."

    # say L373 bil
    old "Good. Deeper now."
    new "خوب. حالا عمیق‌تر."

    # say L374 pla
    old "Fuck... yes."
    new "بلا... بله."

    # say L378 bil
    old "Cum for me. Let it all out."
    new "برای من آمد. همه‌اش رو بیار بیرون."

    # say L379 pla
    old "I'm... close!"
    new "من... نزدیک هستم!"

    # say L402 pla
    old "Ahh— cumming!"
    new "اوه— آمدم!"

    # say L403 bil
    old "Mmm... that's it."
    new "ممنون... همینه."

    # say L410 pla
    old "Wow... that was... intense."
    new "واو... این خیلی... تیز بود."

    # say L411 bil
    old "Feeling better?"
    new "حالت بهتر شد؟"

    # say L426 bil
    old "{i}I used to float... above the ground...{/i}"
    new "{i} من قبلاً... بالای زمین شناور می‌شدم... {/i}"

    # say L427 pla
    old "You're already tensing up... feel that?"
    new "تو قفسه... اینو حس می‌کنی؟"

    # say L428 bil
    old "Mmm—keep it slow—notes steady... don't rush me yet..."
    new "مم— آرام باش— نت‌ها ثابت باش... هنوز از من پیش نبرو..."

    # say L432 bil
    old "{i}Now every step... just pulls me down...{/i}"
    new "{i} حالا هر قدم... فقط من رو پایین می‌بره... {/i}"

    # say L433 pla
    old "Heart's racing already, huh? Your voice is still holding strong."
    new "قلبت قلقله، ها؟ صدات هنوز قویه."

    # say L434 bil
    old "Yes—fuck—deeper now—everything I wanted... slips right through my hands..."
    new "بله—شیطون—عمیق‌تر حالا—همه چیزی که می‌خواستم... از دستم می‌ریزه..."

    # say L438 bil
    old "{i}And I’m still breathing... but I don’t... understand—{/i}"
    new "{i}و همچنان نفس می‌کشمش... اما نمی‌فهمم—{/i}"

    # say L439 bil
    old "{i}Ahh—fuck—keep going—don't stop—{/i}"
    new "{i}Ahh—بلا—ادامه بده—توقف نکن—{/i}"

    # say L440 pla
    old "You're pulsing around my fingers... you're so close, [bil]."
    new "تو در اطراف انگشت‌هایم تپش داری... خیلی نزدیکی، [bil]."

    # say L441 bil
    old "Harder—yes—right there—I'm—I'm gonna—"
    new "سخت‌تر—بله—همینجا—من—من قرارم—"

    # say L464 bil
    old "I-I'm—cumming—fuck—yes—!"
    new "من-من—آمدم—فوک—بله—!"

    # say L465 bil
    old "Nngh... holy shit..."
    new "Nngh... خدایی..."

    # say L472 bil
    old "Fuuck..."
    new "فوک..."

    # say L473 pla
    old "... Damn..."
    new "... شیطون..."

    # say L474 bil
    old "Okay... that... was something else."
    new "خب... اون... چیزی دیگر بود."

    # say L475 pla
    old "You... held it together. Mostly."
    new "تو... خودت رو کنترل کردی. بیشتر."

    # say L476 bil
    old "Mostly? I felt the slip at the peak... but I pulled it back. That's progress."
    new "بیشتر؟ من در بالای همه احساس کردم که از دست می‌رم... ولی بازم آمد. این پیشرفت است."

    # say L477 bil
    old "This method is insane... but it might just work."
    new "این روش دیوانه‌واره... اما شاید فقط کار کنه."

    # say L478 pla
    old "Yeah... insane in the best way."
    new "بله... دیوانه‌وار بهترین نوع."

    # say L490 bil
    old "Do you like when I ride you like this?"
    new "می‌پسندی وقتی من اینجوری روی تو سوار می‌شوم؟"

    # say L491 pla
    old "Fuck yes... you’re perfect..."
    new "بله، فکر کنم تو کاملی هستی..."

    # say L492 bil
    old "Good boy... keep looking at me."
    new "خوب پسر... ادامه بده نگاهت به من"

    # say L496 bil
    old "Faster now... bounce with me."
    new "سریع‌تر الان... با من نوس."

    # say L497 pla
    old "Bil... you’re gonna make me lose it..."
    new "بیل... تو می‌خوای از دست من ببری..."

    # say L498 bil
    old "Not yet. I want to feel you throb inside me."
    new "هنوز. من می‌خوام حس کنم تو درون من تپ می‌کنی."

    # say L502 bil
    old "Harder— give it to me—"
    new "سخت‌تر — بده به من —"

    # say L503 pla
    old "I’m so close..."
    new "من خیلی نزدیک هستم..."

    # say L504 bil
    old "Inside! Cum inside me-"
    new "داخل باش، درون من بیا-"

    # say L527 bil
    old "Yes— fill me up—!"
    new "بله— منو پر کن—!"

    # say L528 pla
    old "Ahh— fuck— cumming— !"
    new "اوه— فکر کنم— در حال خروج—!"

    # say L529 bil
    old "Nngh... that’s it... every drop..."
    new "ننه... اینجاست... هر قطره‌اش..."

    # say L536 bil
    old "Mmm... good boy. That felt so damn good."
    new "ممنون، حالم خوب شد. این هیچ جور هم مثل تمرین صدایی نبود، درسته؟"

    # say L537 pla
    old "That was... insane."
    new "این خیلی جذاب بود."

    # say L538 bil
    old "Heh. Way better than any vocal warm up, right?"
    new "هه. خیلی بهتر از هر گرم کردن صدا، درسته؟"

    # say L539 bil
    old "But we gotta stop... grandma could walk in any second."
    new "اما باید توقف کنیم... بابا می‌تونه هر لحظه وارد بیاد."

    # say L540 pla
    old "Right, right..."
    new "بله، درسته..."

    # say L553 bil
    old "Mmm... feel how soft and warm my ass is rubbing all over your hard cock?"
    new "ممن... حس کن چقدر پشم نرم و گرم روی ناخودت سخت می‌چرخه؟"

    # say L554 pla
    old "Fuck... Billie... that feels incredible..."
    new "فکر کنم... بیلی... این حس وحشیه..."

    # say L558 bil
    old "You're throbbing so much between my cheeks. My ass turns you on that bad, huh?"
    new "تو بین لوله‌هایم همچین تپ می‌کنی. پشت من به این حد خیال‌برانگیزه، ها؟"

    # say L559 pla
    old "Yes... don't stop..."
    new "بله... متوقف نشو..."

    # say L563 bil
    old "Do you like feeling my ass? Then cum for me. I want you to finish all over it."
    new "می‌پسندی احساس پشت من؟ پس برای من خروجی کن. می‌خوام تو رو همه جا روی پشت من تمام کنی."

    # say L564 pla
    old "Oh God, Billie, don't stop..."
    new "اوه خدا، بیلی، متوقف نشو..."

    # say L587 pla
    old "Ahh— fuck— I'm cumming—!"
    new "اوه— شیطان— من همین جا می‌آیم—!"

    # say L588 bil
    old "Mmm... yes, that's it. Cum all over my ass."
    new "ممنون... بله، همینه. روی می‌پوستم خودت راه بده."

    # say L594 bil
    old "Heh... look at the mess you made on me. Someone really liked this outfit."
    new "هه... نگاه کن به این همه خرابی که برایم ایجاد کردی. به نظر می‌رسه کسی واقعاً لباس من رو دوست داشت."

    # say L595 pla
    old "That was insane... we could've been caught..."
    new "این جوری خیلی بود... می‌تونستیم گرفتار بشیم..."

    # say L596 bil
    old "But we weren't. Now help me clean up before that lazy bitch looks up from her phone."
    new "اما ما نبودیم. حالا کمک کن براشون پاک کنم قبل از اینکه آن لازی بیچ چشاتون از گوشی برداره."

    # say L607 bil
    old "Mmm... feel how soft and warm they are wrapping all around your cock?"
    new "ممنون... حس کن چقدر نرم و گرم هستن که دور شفتتو محصور می‌کنن؟"

    # say L608 pla
    old "Fuck... Billie... your tits feel amazing..."
    new "فکر کنم... بیلی... سیناهات عالی هستند..."

    # say L612 bil
    old "You're throbbing so much between them. You love fucking my tits, don't you?"
    new "تو بینشون در حال تپش هستی. از سیک کردن سیناهایم لذت می‌بری، نیست؟"

    # say L617 bil
    old "That's it... fuck my tits harder. I want you to cum all over them."
    new "این‌هاش... سیک میلی رو بیشتر بزن. می‌خوام تو رو رویشون خالی کنی."

    # say L618 pla
    old "Billie... I'm gonna cum..."
    new "بیلی... من قراره بیافzem..."

    # say L619 bil
    old "Do it. Cover my tits. I want to feel your hot load on me."
    new "بیا. روی سینه‌هام بیا. می‌خوام احساس گرمای خروجی‌ت رو بکنم."

    # say L642 pla
    old "Ahh— fuck— I'm cumming!"
    new "اوه— شیطون— من بیافzem!"

    # say L643 bil
    old "Mmm... yes, give it to me. Cum all over my tits."
    new "ممن... بله، به من بده. روی سینه‌هام خروجی کن."

    # say L650 bil
    old "Heh... look at you. Made another mess on me."
    new "هه... نگاه کن به تو. دوباره برایم همه را خراب کردی."

    # say L651 bil
    old "Guess my tits are too much for you."
    new "گuess ممکنه بگم پستان‌هام برایت خیلی هستند."

    # say L652 bil
    old "It's nice you like them so much..."
    new "خوشحالم که اونقدر می‌پسندی..."

    # say L664 bil
    old "Mmm... slow... just like this... I want to feel every inch of you."
    new "ممنون... آرام... همینطور... می‌خوام هر اینچ از تو رو حس کنم."

    # say L665 pla
    old "You feel so good... so warm..."
    new "تو خیلی خوب احساس می‌کنی... خیلی گرمی..."

    # say L666 bil
    old "Mmm... deeper... I need you inside me... all of you."
    new "مم... عمیق‌تر... من نیاز دارم تو داخل من باشی... همه‌ت رو می‌خواهم."

    # say L670 bil
    old "Ahh... yes... right there..."
    new "اوه... بله... همینجور..."

    # say L671 pla
    old "Fuck... Billie... you’re perfect."
    new "بیلی... تو کاملی."

    # say L672 bil
    old "Don’t hold back... I want all of you tonight... I need this."
    new "دست بردار نکن... من امشب می‌خوام همه‌ت رو ببینم... اینو لازم دارم."

    # say L676 bil
    old "Harder... don’t stop... I want to feel you lose control..."
    new "سخت‌تر... متوقف نشو... می‌خوام حس کنم تو کنترلت رو از دست بده..."

    # say L677 pla
    old "I’m getting so close..."
    new "من خیلی نزدیک شدم..."

    # say L678 bil
    old "Inside me... cum inside me... I want to feel you let go completely."
    new "داخل من... درون من خروج کن... می‌خوام حس کنم تو کاملاً رها می‌شی."

    # say L701 pla
    old "Billie— I’m cumming—!"
    new "بیلی— من هستم—!"

    # say L702 bil
    old "Yes— fill me up... give me everything..."
    new "بله— از تو پر شوم... همه چیزت رو به من بده..."

    # say L708 bil
    old "Mmm... I can still feel you pulsing inside me..."
    new "ممنون... هنوز حس می‌کنم تو درون من تپ می‌کنی..."

    # say L709 pla
    old "That was... incredible."
    new "این بود... شگفت‌انگیز."

    # say L710 bil
    old "That wasn’t everything. Tonight I don’t want to stop until you’ve given me all of you."
    new "این همه نبود. امشب نمی‌خوام تا وقتی به من همه‌ت رو ندادی متوقف بشی."

    # say L711 bil
    old "Come here... don’t pull out yet."
    new "بیا اینجا... هنوز خارج نشو."

    # say L712 bil
    old "I want to feel you again... deeper this time."
    new "می‌خوام دوباره حس کنم... این بار عمیق‌تر."

    # say L728 bil
    old "Slow... just like that... I love feeling you fill me completely."
    new "آرام... همینطور... عاشقم وقتی احساس می‌کنم تو کاملاً منو پر می‌کنی."

    # say L729 pla
    old "God, Billie... you’re so tight... so warm..."
    new "بیلی... تو خیلی تنگی... خیلی گرمی..."

    # say L730 bil
    old "Mmm... keep your eyes on me... I know how much you love looking at my tits like this."
    new "ممن... چشماتو رو به من توندا بکن... میدونم چقدر دوست داری مثل این به سیناهام نگاه کنی."

    # say L731 bil
    old "Look at them bouncing for you... they’re all yours tonight."
    new "نگاه کن به اونا برای تو پر می‌شن... این شب همه شون توی دست تو هستند."

    # say L735 bil
    old "Ahh... yes... right there... harder now..."
    new "اوه... بله... همینجا... الان سخت‌تر..."

    # say L736 pla
    old "You feel amazing... I can’t get enough of you."
    new "تو عالی هستی... نمی‌تونم از تو خسته بشه."

    # say L737 bil
    old "Don’t hold back... I need you to lose yourself in me tonight."
    new "دست بردار... من لازم دارم امشب تو رو در من بگمینی."

    # say L741 bil
    old "Faster... fuck me harder... I want everything you have left."
    new "سریع‌تر... برام سخت‌تر بکن... من می‌خوام همه چیزی که داری رو به من بدی."

    # say L742 pla
    old "Billie... I’m so close again..."
    new "بیلی... دوباره خیلی نزدیک شدم..."

    # say L743 bil
    old "Then give it to me... cum inside me again... fill me up."
    new "پس بده به من... دوباره درون من خروجی کن... من رو پر کن."

    # say L767 bil
    old "Yes— deep inside... let go... I want to feel every drop."
    new "بله— عمیق داخل... رها کن... من می‌خوام هر قطره‌اش رو حس کنم."

    # say L773 bil
    old "Mmm... I feel you throbbing again... so warm..."
    new "ممن... احساس می‌کنم دوباره در حال تپش هستی... خیلی گرم..."

    # say L774 bil
    old "I don’t want this night to end..."
    new "من نمی‌خوام این شب تمام شه..."

    # say L775 pla
    old "Neither do I."
    new "من هم نمی‌خوام این شب تمام شه..."

    # say L776 bil
    old "But tomorrow is going to be a long day..."
    new "اما فردا روز طولانی‌ای پیش ماست..."

    # say L777 pla
    old "Yeah... I know."
    new "بله... می‌دونم."

    # say L778 bil
    old "I hate saying it, but we both need to rest."
    new "می‌خوام بگم ولی هر دومون باید استراحت کنیم."

    # say L779 pla
    old "You’re right, we better get dressed in case your grandma shows up."
    new "درست می‌فرمایی، بهتره لباس بگذونیم تا اگه بабاچه تو بیاد، آماده باشیم."

    # say L792 bil
    old "Ahh... just like that..."
    new "اوه... همینطور..."

    # say L793 pla
    old "Focus on my mouth... nothing else matters right now."
    new "دقت کن به دهتم... هیچ چیز دیگه مهم نیست الان."

    # say L797 bil
    old "Yes... right there... don’t stop..."
    new "بله... همینجا... متوقف نشو..."

    # say L798 pla
    old "You’re getting so wet... that’s it, let go."
    new "تو خیلی مرطوب می‌شی... اینجاست، رها کن."

    # say L802 bil
    old "Harder... use your tongue... I’m so close..."
    new "سخت‌تر... با زبانت استفاده کن... من خیلی نزدیک هستم..."

    # say L804 bil
    old "Ahh— I’m— I’m cumming—!"
    new "اوه— من— من آمدم—!"

    # say L832 bil
    old "Fuck... that actually worked..."
    new "فکر کنم واقعاً کار کرد..."

    # say L833 pla
    old "You look a lot calmer now."
    new "حالت خیلی بهتر شده."

    # say L834 bil
    old "I do... thank you. I really needed that."
    new "من همینطور... ممنونم. واقعاً این به من لازم بود."

    # say L835 pla
    old "I don’t want to freak you out, but the contest already started. We gotta get on stage."
    new "من نمی‌خوام تو رو ناراحت کنم، ولی مسابقه قراره شروع بشه. باید روی صحنه بریم."

    # say L836 bil
    old "Okay, okay... yeah, I feel way better now. Let’s go."
    new "باشه، باشه... همینطور، حالا خیلی بهتر احساس می‌کنم. برویم."

    # say L848 bil
    old "Mmm... feel how soft they are wrapping around you?"
    new "مم... حس کن چقدر نرم هستن دور تو؟"

    # say L849 pla
    old "Fuck... Billie... they feel perfect..."
    new "فکر کن... بیلی... اونا عالی هستند..."

    # say L853 bil
    old "You’re throbbing so much between them... you love fucking my tits, don’t you?"
    new "تو بین آنها همچین تپ می‌کنی... دوست داری پستان‌مو بکنی، نه؟"

    # say L854 pla
    old "Yes... don’t stop..."
    new "بله... متوقف نشو..."

    # say L858 bil
    old "Harder... fuck them... I want you to cum all over them."
    new "سخت‌تر... باهاشون بزن... می‌خوام رویشون خروجی بدی."

    # say L859 pla
    old "Billie... I’m so close..."
    new "بیلی... من خیلی نزدیک هستم..."

    # say L860 bil
    old "Then do it. Cover me."
    new "پس بکن. من رو پوش."

    # say L883 pla
    old "Ahh— fuck— I’m cumming—!"
    new "اوه— شیطون— من در حال خروج هستم—!"

    # say L884 bil
    old "Mmm... yes, give me every drop... paint them nice and white."
    new "ممن... بله، همه را به من بده... اونا رو خوب سفید کن."

    # say L891 bil
    old "Heh... look at the mess you made."
    new "هه... نگاه کن به همه این درهم‌دستی که ایجاد کردی."

    # say L893 bil
    old "We’re not done yet."
    new "هنوز تمام نشده."

    # say L894 bil
    old "Come here... I want you inside me again."
    new "بیا اینجا... می‌خوام دوباره توی من باشی."

    # say L906 bil
    old "Slow at first... I want to feel all of you."
    new "اول آرام... می‌خوام همه‌ت رو حس کنم."

    # say L916 bil
    old "Mmm... yes... just like that..."
    new "ممنون... بله... همینطور..."

    # say L917 pla
    old "You feel so good... so tight..."
    new "تو خیلی خوب احساس می‌کنی... خیلی تنگ..."

    # say L921 bil
    old "Harder... don’t hold back..."
    new "سخت‌تر... نگه نداشته باش..."

    # say L922 pla
    old "Billie... you’re perfect."
    new "بیلی... تو کاملی."

    # say L926 bil
    old "Fuck me... I want everything you have left..."
    new "بیلی: فوت می‌کنم... من می‌خوام همه چیزی که داری رو به من بدهی..."

    # say L927 pla
    old "I’m gonna cum again..."
    new "من دوباره خواهم آمد..."

    # say L928 bil
    old "Inside me... fill me up one more time."
    new "داخل من... بیا دوباره پر کن من رو."

    # say L952 bil
    old "Yes... give it all to me..."
    new "بله... همه‌اش رو به من بده..."

    # say L959 bil
    old "Mmm... I can feel you... so warm inside..."
    new "ممن... من حس می‌کنم تو... خیلی گرم درون من..."

    # say L960 pla
    old "I don’t think I can move..."
    new "فکر نمی‌کنم بتوانم حرکت کنم..."

    # say L961 bil
    old "Then don’t. Stay right here with me."
    new "بعدش نکن. همینجا با من بمان."

    # say L962 bil
    old "Tonight... everything feels right."
    new "امروز... همه چیز درسته."

    # say L963 pla
    old "We did it. Together."
    new "اونجوری. با هم."

    # say L964 bil
    old "Yeah... we really did."
    new "آره... واقعاً انجام دادیم."

    # say L978 bil
    old "Mmm... circle my clit first. Gentle, like I showed you."
    new "مم... اول دور کلیت من بچرخون. نرم، مثل آنگاه که به تو نشون دادم."

    # say L979 pla
    old "Like this?"
    new "مثل این؟"

    # say L980 bil
    old "Deeper. Slide one in and curl it. You already know the spot."
    new "عمیق‌تر. یکی رو داخل بیاور و خم کن. تو قبلاً میدونی جایش کجاست."

    # say L984 bil
    old "Add another—fuck—yes, right there. You’re getting so good at this."
    new "بیشتر—شیطون—بله، همینجا. تو اینجوری خیلی خوب شدی."

    # say L988 bil
    old "Harder, baby. Make me cum all over your hand."
    new "سخت‌تر، عزیزم. برام اوج برسون روی دستت."

    # say L1011 bil
    old "I’m—cumming—fuck—!"
    new "من—آمدم—شیطون—!"

    # say L1017 bil
    old "Shit... your fingers really kept perfect rhythm this time."
    new "شیط... این بار انگشتات واقعاً ریتم خوبی داشتند."

    # say L1018 bil
    old "You’re getting faster and way more precise every time. I can feel it."
    new "تو هر بار سریع‌تر و دقیق‌تر می‌شی. احساسش می‌کنم."

    # say L1019 bil
    old "This is exactly the kind of dexterity we need... both on stage and off it."
    new "این دقیقاً همان مهارتیه که بهش نیاز داریم... هم روی صحنه و هم خارج از آن."

    # say L1035 pla
    old "You’re already dripping..."
    new "تو قطعاً الان آب داری..."

    # say L1039 bil
    old "Deeper—fuck—keep the rhythm steady."
    new "عمیق‌تر—بلا—نوسان‌ها رو ثابت نگه دار."

    # say L1043 bil
    old "Faster—make me cum while I try to hold the note—ahh—!"
    new "سریع‌تر—بیا برام خروجی بده در حالی که من سعی می‌کنم نت رو نگه دارم—آه—!"

    # say L1066 bil
    old "I’m cumming—fuck—yes—!"
    new "من هستم—بلا—بله—!"

    # say L1073 bil
    old "Nngh... your tongue is getting way too good at this."
    new "ننه... زبان تو برای این کار خیلی خوب شده."

    # say L1074 bil
    old "You held me through it perfectly. That’s the kind of control I need."
    new "تو اینجا همه چی رو به درستی کنترل کردی. این همین کنترلیه که بهش نیاز دارم."

    # say L1075 bil
    old "Every time you do this my voice gets stronger under pressure... and I get to enjoy that mouth of yours."
    new "هر بار که اینجوری می‌کنی صدایم زیر فشار قوی‌تر می‌شه... و من می‌تونم اون دهان خوبت رو لذت ببرم."

    # say L1088 bil
    old "Mmm... look at you. Already so hard just from asking."
    new "ممنون... نگاه کن به من. قدرتت رو فقط از درخواست کردن پیدا می‌کنم."

    # say L1089 pla
    old "Billie... that feels so good..."
    new "بیلی... این خیلی خوب می‌تونه..."

    # say L1094 bil
    old "Deeper now... I want to feel every throb."
    new "عمیق‌تر حالا... می‌خوام هر تپش رو حس کنم."

    # say L1095 pla
    old "Fuck... you’re way too good at this."
    new "فکر کنم تو خیلی خوب در این کاری هستی."

    # say L1100 bil
    old "Don’t hold back. Cum for me. Let me give you the motivation you need."
    new "نگه نداشته باش. برای من خروجی شو. بیا برام انگیزه‌ت رو بده."

    # say L1101 pla
    old "I’m— I’m close...!"
    new "من— من نزدیک هستم...!"

    # say L1126 bil
    old "Mmm... every drop. Good boy."
    new "ممنون... هر قطره. خوبی تو."

    # say L1133 bil
    old "Heh... feeling more motivated already?"
    new "هه... قدرت خودتو دوباره پیدا کردی؟"

    # say L1134 bil
    old "Your confidence always shoots up after this. I can tell."
    new "این حالت همیشه اعتمادت رو بالا می‌بره. متوجه می‌شم."

    # say L1135 bil
    old "Come back whenever you need some real motivation again... I’ll be waiting."
    new "هر وقت نیاز داشتی به انگیزه‌ی واقعی دوباره بیا... منتظرت هستم."


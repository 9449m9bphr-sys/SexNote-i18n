# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/ladAnimations.rpy
translate persian strings:

    # say L6 lad
    old "I'm stimulating your testicles while I masturbate you so I can get the maximum amount of semen out."
    new "من در حال تحریک بیضه‌هایت هستم در حالی که تو را مasturbate می‌کنم تا بتوانم حداکثر مقدار سمن را بگیرم."

    # say L11 lad
    old "How is it? Do you feel ok?"
    new "حالت چطوره؟ خوب احساس می‌کنی؟"

    # say L12 pla
    old "Y- yes ma'am"
    new "بله خانم"

    # say L13 lad
    old "Just relax and let me do the job. I promise it won't feel bad."
    new "فقط آرام شو و بگذار من کار رو انجام بدم. قول میدم بد نمی‌تونه باشه."

    # say L17 pla
    old "O- ohhh! I- I think I'm getting close."
    new "ا- اوه! فکر کنم دارم نزدیک می‌شوم."

    # say L18 lad
    old "Yes! I can feel your body tensing up."
    new "بله! می‌تونم احساس کنم بدنت مشدود می‌شه."

    # say L19 lad
    old "Mmmm! It's so hard!"
    new "ممنن! خیلی سخته!"

    # say L42 pla
    old "Ma'am I-I think I'm cumming!"
    new "خانم من-من فکر کنم هستم!"

    # say L43 lad
    old "Yes! I want you to!!"
    new "بله! من می‌خوام تو همه‌ش رو بیاری خارج!"

    # say L44 lad
    old "Slurrp! That's it, let it all out!"
    new "سلور! اینجاست، همه‌اش بیرون بیا!"

    # say L50 lad
    old "That was impressive, you came a lot."
    new "این خیلی خوب بود، خیلی زیاد آمدی."

    # say L51 lad
    old "This will really help me a lot. I'm already starting to feel it's effects."
    new "این واقعاً به من کمک زیادی می‌کنه. حالا احساس تأثیرش رو می‌کنم."

    # say L52 pla
    old "Really? Already? Well, I'm happy it worked."
    new "وای، قطعاً؟ خوشحالم که کار کرده."

    # say L53 lad
    old "It really did. And I can't believe you came that much."
    new "واقعاً همینطور بود. و نمی‌تونم باور کنم اینقدر اومدی."

    # say L54 lad
    old "Although we made a bit of a mess."
    new "البته، اما یک کم هرج و مرج ایجاد کردیم."

    # say L55 pla
    old "Sorry, I sometimes can't control myself."
    new "ببخشید، گاهی خودمو در کنترل ندارم."

    # say L56 lad
    old "It's ok, you were helping me anyway. Just wait a second and I'll clean myself."
    new "خوبه، هر جا می‌تونستی کمک می‌کردی. فقط یه لحظه صبر کن تا خودمو تمیز کنم."

    # say L65 pla
    old "Wow!"
    new "واو!"

    # say L66 lad
    old "Just relax and enjoy it."
    new "فقط آرام شو و ازش لذت ببر."

    # say L67 pla
    old "Y- yes ma'am."
    new "بله، خانم"

    # say L71 lad
    old "Ahh! I-I feel like I'm getting better already"
    new "اوه! من- من مثل این بهتر می‌شم"

    # say L73 lad
    old "Oh yes! Just like this..."
    new "اوه بله! همینطور..."

    # say L74 lad
    old "Keep going! Don't stop!"
    new "ادامه بده! متوقف نشو!"

    # say L78 lad
    old "Yes! Yes! I can feel it!"
    new "بله! بله! من احساسش می‌کنم!"

    # say L79 lad
    old "This is amazing! Your dick fills me up completely!"
    new "این شگفت‌انگیزه! ناخودت را کاملاً پر می‌کنی."

    # say L80 lad
    old "Ahhh! Ohhhh!"
    new "آه! اوه!"

    # say L103 lad
    old "Cum, now! I want to feel your cum fill me up."
    new "بیا، حالا! می‌خوام حس کنم سیالت توی من پر می‌شه."

    # say L104 pla
    old "Y- yes! I'm about to!"
    new "ب-بله! همین الان!"

    # say L105 lad
    old "That's it! Yes!"
    new "آره! همینه!"

    # say L111 lad
    old "Phew! That was impressive [pla]. Not only are you that well endowed, you know how to use your penis."
    new "پوف! این خیلی عالی بود [pla]. نه فقط اینقدر بزرگ هستی، بلکه می‌دونی چطور از پوس خودت استفاده کنی."

    # say L112 lad
    old "It's fantastic!"
    new "الان عالیه!"

    # say L113 pla
    old "T- thank you Miss. I'm glad you liked it."
    new "ممنونم، خانم. خوشحالم که لذت برده‌اید."

    # say L114 pla
    old "And I hope I was of help."
    new "و امیدوارم کمکت کرده باشم."

    # say L115 lad
    old "Oh, I'm sure you were."
    new "البته، مطمئن هستم که کمکت کردی."

    # say L116 lad
    old "You came a great amount. I have no doubt I'll feel better with this."
    new "تو خیلی زیاد آمدی. شکی ندارم با این حالت بهتر می‌شوم."

    # say L117 lad
    old "Now, we better get dressed, it's late and you have to go home."
    new "الان بهتره لباس بگذونیم، وقت شده و باید به خونه بری."

    # say L118 pla
    old "Yes ma'am."
    new "بله خانم"

    # say L130 lad
    old "Just relax. And Iet us do the work."
    new "سکونت کن. و بگذار ما کار رو انجام بدیم."

    # say L131 lad
    old "We'll get you off in no time."
    new "ما همین الان شما رو خوشحال می‌کنیم."

    # say L133 pla
    old "Y- yes, I am."
    new "بله، من آرام هستم."

    # say L137 lad
    old "Your penis is always so impressive [pla]!"
    new "پنسر شما همیشه اینقدر عالیه [pla]!"

    # say L138 lad
    old "Mmm, and it has such a nice taste!"
    new "می‌تونم چه خوب طعمش رو ببرم!"

    # say L139 dan
    old "Slurrp! Your dick... it's so warm, and it feels so nice in my mouth."
    new "سلورپ! نونت... خیلی گرم و تو دهانم احساس خوبی می‌کنه."

    # say L140 bela
    old "I- it's so big..."
    new "اونقدر بزرگه..."

    # say L144 bela
    old "Your dick it's so amazing! I can feel it throbbing!"
    new "پیپی تو خیلی عالیه! می‌تونم تپشش رو حس کنم!"

    # say L145 lad
    old "Yes! just like this! it's so nice!"
    new "بله! همینطور! خیلی خوب است!"

    # say L146 dan
    old "It's so long! And so thick!"
    new "چقدر طولانیه! و همینطور چقدر ضخیم!"

    # say L147 lad
    old "I can feel it, you're getting close!"
    new "می‌تونم احساسش کنم، تو خیلی نزدیک شدی!"

    # say L170 pla
    old "I- I think I'm gonna...!"
    new "من- من فکر می‌کنم قراره...!"

    # say L171 bela
    old "Mmmm! Yes!"
    new "ممنون! بله!"

    # say L172 lad
    old "It's ok, do it. Cum for us!"
    new "خوبه، بیا. برای ما خروجی بده!"

    # say L177 lad
    old "That was amazing [pla]! How do you feel? I hope you're not too drained."
    new "این عالی بود [pla]! حس خوبی داری؟ امیدوارم خسته نباشی."

    # say L178 pla
    old "Not at all, I feel very well... I know I can keep going."
    new "هیچ، حالت خوبه... می‌دونم می‌تونم ادامه بدم."

    # say L179 bela
    old "Wow, Y- you're not tired? Amazing!"
    new "واو، ش- شما خسته نیستید؟ شگفت‌انگیز!"

    # say L180 dan
    old "Incredible, I'd never met anybody that wouldn't feel tired after getting a blowjob from one of us. Let alone three!"
    new "البته، هیچ وقت کسی رو ندیدم که بعد از شفته شدن توسط یکی از ما خسته نباشه. نه اینکه سه!"

    # say L181 lad
    old "I told you, this young man is the key for us to get better."
    new "من به تو گفتم، این جوان کلیدی برای ما برای بهتر شدن است."

    # say L182 lad
    old "And we're just getting started."
    new "و همین جا شروع کردیم."

    # say L194 lad
    old "My god! Look at this, you just came, and yet your cock is still rock hard."
    new "الهی! نگاه کن، تو همین الان اومدی و هنوز ناخودت سخته."

    # say L195 lad
    old "Amazing!"
    new "الانگه!"

    # say L196 dan
    old "Hurry up mother, I think you're wanting it."
    new "حسرت زده، سریع‌تر بیا، فکر کنم می‌خوای."

    # say L197 lad
    old "Mmm, I am darling, I am."
    new "ممنون، عزیزم، من هم هستم."

    # say L198 lad
    old "Now [pla], let's beginning."
    new "الان [pla]، بیایم شروع کنیم."

    # say L208 lad
    old "Uhhh... Your cock... It's so big!"
    new "اوه... ناخن تو... خیلی بزرگه!"

    # say L209 lad
    old "Mmm! It fills me up completely!"
    new "ممنون! اینجا مناسب است، کاملاً پر می‌شوم!"

    # say L210 bela
    old "Wow mother, he really is deep into you!"
    new "وای مامان، واقعاً عمیق در تو هست!"

    # say L214 bela
    old "Mmm, I can see you're enjoying it a lot!"
    new "ممنون، من می‌تونم ببینم تو خیلی لذت می‌بری!"

    # say L215 lad
    old "Ahh! Yes dear, It would be... Ahh! Impossible not to."
    new "آه! بله عزیزم، این... آه! غیرممکن است که لذت نبرم."

    # say L216 lad
    old "Oh yeah, just like this..."
    new "اوه بله، دقیقاً همینطور..."

    # say L220 lad
    old "Ohh! Oh my god!"
    new "اوه! خدا مرا!"

    # say L221 lad
    old "Ah, it feels so good!"
    new "اوه، این خیلی خوبه!"

    # say L222 lad
    old "Ahhh! I- I'm close! I can feel it!"
    new "اوه! من- من نزدیک هستم! احساس می‌کنم!"

    # say L223 pla
    old "Uhhhhh!"
    new "اوه!"

    # say L246 pla
    old "M- Ma'am! I think I'm cumming!"
    new "م- مادام! فکر کنم می‌آیم!"

    # say L247 lad
    old "Ah! Do it! I want you to! Cum!"
    new "آه! بکن! من می‌خوام تو بکنی!"

    # say L253 lad
    old "My god! That was impressive, you came so much."
    new "الهی! اینقدر شگفت‌انگیز بود، همین‌قدر آمدی."

    # say L255 pla
    old "Phew, glad I can help."
    new "پوف، خوشحالم که بتونم کمکت کنم."

    # say L256 lad
    old "But you know, I shouldn't keep you for myself..."
    new "اما می‌دونی، نباید تو رو فقط برای خودم نگه دارم..."

    # say L257 lad
    old "It's your turn Daniela..."
    new "دانیلا عزیزم، الان دوری است..."

    # say L270 dan
    old "I hope you're not tired from being with mother, because I've been waiting for this."
    new "امیدوارم خسته نباشی از مامان، زیرا من برای این منتظر بودم."

    # say L272 lad
    old "Daniela darling, I know our health is a little compromised."
    new "Daniela عزیزم، می‌دونم سلامتیمون کمی خرابه."

    # say L273 lad
    old "But there's no need to pressure him that much."
    new "اما لازم نیست اینقدر فشار بدی."

    # say L274 bela
    old "Haha, I don't think she meant it that way mother."
    new "هahaha، فکر نمی‌کنم بخواسته به این معنی باشه مادر."

    # say L287 dan
    old "Ok, here we go."
    new "باشه، حالا شروع می‌کنم."

    # say L288 dan
    old "Mmm! This cock, it's reaching all the way!"
    new "ممنن! این ناخن، همه‌جا رو می‌رسونه!"

    # say L289 bela
    old "Uhh, it looks amazing!"
    new "اوه، به نظر واقعاً عالی است!"

    # say L290 dan
    old "And it is! Mmm! So good."
    new "و هست! مم! خیلی خوب."

    # say L294 lad
    old "I can see that you're enjoying this [pla]."
    new "می‌بینم که از این لذت می‌برید [pla]."

    # say L295 pla
    old "Mmm... Y- yes ma'am"
    new "ممن... بله خانم"

    # say L296 bela
    old "Heh, Daniela is enjoying it too mother."
    new "هه، دانیلا هم لذت می‌بره مادر."

    # say L297 dan
    old "I- It's so thick, and I feel so warm inside."
    new "اینقدر ضخیم است و من از داخل گرم می‌شوم."

    # say L298 lad
    old "What about if you go a little faster [pla]?."
    new "اگه یه کم سریع‌تر بشی [pla]؟"

    # say L302 dan
    old "Oh, Oh god!"
    new "اوه، خدا!"

    # say L303 dan
    old "Yes! Yes! Like that! Pound me more!"
    new "بله! بله! همین‌طور! بیشتر به من ضربه بزن!"

    # say L304 pla
    old "Mmm, Ahhh!"
    new "ممن، آه!"

    # say L328 dan
    old "I can feel it! Your body it's tensing up!"
    new "می‌تونم احساسش کنم! بدن تو در حال تنیدن است!"

    # say L330 dan
    old "Yes! Cum! Cum inside me!"
    new "بله! درون من بیا!"

    # say L336 dan
    old "Wow, that was amazing."
    new "واو، این خیلی عالی بود."

    # say L337 bela
    old "Look how much you came. I can't believe it."
    new "ببین چقدر اومدی. باور نمی‌کنم."

    # say L338 lad
    old "You never cease to surprise me [pla]."
    new "هر زمان هم شگفت‌زده‌ام از تو [pla]."

    # say L339 bela
    old "I think it's my turn now mother."
    new "فکر می‌کنم الان نوبت من است، مادر."

    # say L351 bela
    old "Be gentle with me, ok?"
    new "با من نرم باش، خب؟"

    # say L352 bela
    old "I don't like it as rough as my sister."
    new "من مثل خواهرم خوشم نمی‌آید خشن باشی."

    # say L363 bela
    old "That's it, slowly. Mmm."
    new "این‌هاش، آرام. مم."

    # say L364 bela
    old "Ah! I can feel how you stretch me."
    new "اوه! می‌تونم حس کنم چطور منو گسترش می‌دی."

    # say L365 dan
    old "Yes sister, I felt it too. It's unbelievable."
    new "بله خواهر، من هم احساس کردم. شگفت‌انگیز است."

    # say L366 bela
    old "Y- You can do it, a little harder"
    new "بله، می‌تونی اینجوری بکنی، یه کم سخت‌تر"

    # say L370 dan
    old "You like that big cock sis?"
    new "این لولی کبودو می‌پسندی؟"

    # say L371 bela
    old "Ohh, yes, yes, just like that."
    new "اوه، بله، بله، دقیقاً همینطور."

    # say L372 lad
    old "That's it Bela, enjoy it darling."
    new "این هست Bela، لذت ببر عزیزم."

    # say L373 bela
    old "P- please, go a little faster."
    new "لطفاً، یک کم سریع‌تر برو."

    # say L377 bela
    old "Ah, Ahh, Ahhh!"
    new "آه، آهه، آهه!"

    # say L378 bela
    old "I- It's soooo fucking big!"
    new "ا- این خیلی بزرگه!"

    # say L379 bela
    old "It's warming me up inside!"
    new "این از داخل من رو گرم می‌کنه!"

    # say L403 bela
    old "Yes! Me too!"
    new "بله! من هم همینطور!"

    # say L404 pla
    old "Ughhh!"
    new "اوه!"

    # say L409 lad
    old "Amazing, you have such amazing endurance."
    new "الهی، قدرت تحمل شما واقعاً شگفت‌انگیز است."

    # say L410 dan
    old "And he still hard... "
    new "و هنوز سخت است..."

    # say L411 lad
    old "Hmm, do you think you could give us a little bit more?"
    new "هم، آیا فکر می‌کنی می‌تونی به ما کمی بیشتر بدهی؟"

    # say L412 pla
    old "Uhhh.... I- I think so."
    new "اوه... من- من فکر می‌کنم بله."

    # say L424 lad
    old "Mmmm, that was lovely [pla]."
    new "ممنون، این هم خوب بود [pla]."

    # say L425 pla
    old "T- Thanks ma'am."
    new "ممنون می‌خانم."

    # say L426 lad
    old "You managed to do it with all three of us."
    new "تو تونستی با همه سه ما این کار رو انجام بدی."

    # say L427 lad
    old "I think we can give you a little extra."
    new "فکر می‌کنم می‌تونیم بهت یه کمی بیشتر بدیم."

    # say L437 dan
    old "God! your cock still so hard."
    new "خدا! نوزکت هنوز اینقدر سخته."

    # say L438 lad
    old "I can see you still have some left in the tank. Give it to us."
    new "می‌تونم ببینم هنوز چیزی برای ما داری. بده به ما."

    # say L442 pla
    old "Ah... Ahh!"
    new "آه... آه!"

    # say L443 bela
    old "I love how big you are."
    new "من عاشق این هستم که چقدر بزرگی."

    # say L444 lad
    old "It's got such a nice smell."
    new "این بو خوبی داره."

    # say L445 dan
    old "Let's do it a faster mother."
    new "بیای دیگه سریع‌تر کنی."

    # say L449 lad
    old "Yes! That's it! I love seeing you enjoy it."
    new "بله! همینه! دوست دارم ببینم لذت می‌بری."

    # say L450 bela
    old "It's so warm, and it's getting harder."
    new "اینقدر گرم است و سخت‌تر می‌شود."

    # say L451 bela
    old "I think he's about to cum."
    new "فکر کنم او در حال خروج است."

    # say L474 pla
    old "I- I think I'm cumming!"
    new "من- من فکر می‌کنم خروج می‌کنم!"

    # say L475 lad
    old "Yes! Let it all out! Cum all over us!"
    new "بله! همه‌اش رو بیرون بیاور! بر ما تمام شو!"

    # say L482 dan
    old "Wow, that was really intense."
    new "واو، این واقعاً شدید بود."

    # say L483 pla
    old "Yes, it was. I think I'm finally feeling a little tired."
    new "بله، همین‌طور بود. فکر کنم الان کمی خسته شدم."

    # say L489 dan
    old "Hah! Just now? I did it only once with you, and I'm already tired!"
    new "هه! فقط حالا؟ من فقط یک بار با تو انجام دادم و قدری خسته شدم!"

    # say L490 lad
    old "Wow [pla], just wow! You really had sex with all three of us and are ok."
    new "واو [pla]، فقط واو! واقعاً با همه ما سکس کردی و هنوز خوبی."

    # say L491 pla
    old "Well, I wouldn't say I don't feel it. But I wanted to help."
    new "خب، نمی‌تونم بگم که هیچ احساسی ندارم. اما می‌خواستم کمکتون کنم."

    # say L492 lad
    old "And you did. Right girls?"
    new "و اینطور کردی. درسته دختران؟"

    # say L493 bela
    old "Yes, you really are a lifesaver."
    new "بله، واقعاً تو ما رو نجات دادی."

    # say L494 dan
    old "That's right, this is great for us."
    new "بله، این برای ما عالی است."

    # say L495 pla
    old "Thank you very much."
    new "ممنونم خیلی زیاد"

    # say L496 lad
    old "Well, why don't we get dressed? I think you probably need to rest at home [pla]."
    new "خب، چرا ما هم لباس بگذاریم؟ فکر می‌کنم شاید باید در خانه استراحت کنی [pla]."

    # say L513 lad
    old "How are you feeling girls?"
    new "دیوتن، حالتون چطوره؟"

    # say L514 bela
    old "I feel amazing, that was so good, and I feel myself getting better already!"
    new "حالم عالیه، اینقدر خوب بود و همین حالا حس می‌کنم بهتر می‌شوم!"

    # say L515 dan
    old "Yeah, me too. The amount of cum we were able to take is amazing."
    new "بله، من هم همینطور. مقدار سپرمی که تونستیم تحمل کنیم شگفت‌انگیز بود."

    # say L516 pla
    old "I'm happy I can be of help to you all."
    new "خوشحالم که بتونم به شما کمک کنم."

    # say L517 pla
    old "I think I should probably go home and rest."
    new "فکر می‌کنم باید برم خانه و استراحت کنم."

    # say L518 lad
    old "That's fine. But before you leave, allow us to thank you once again for everything you've done for us."
    new "البته. اما قبل از برخاستن، بگذارید دوباره از همه چیزهایی که برای ما انجام دادی، سپاس بگوییم."

    # say L519 bela
    old "T- that's right [pla] thank you very much."
    new "بله، درست است [pla] ممنونم خیلی."

    # say L520 dan
    old "Thank you [pla], please come soon again."
    new "ممنون [pla] لطفاً زود دوباره بیایید."

    # say L521 pla
    old "Sure, you can count on me."
    new "بله، می‌تونی به من اعتماد کنی."

    # say L522 lad
    old "Aww, you're an angel. Thank you so much."
    new "اوه، تو یک فرشته‌ای. ممنونم خیلی."


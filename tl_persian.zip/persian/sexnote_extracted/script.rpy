# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/System/script.rpy
translate persian strings:

    # say L562 ladGuide
    old "Go to Sleep."
    new "برو بخواب"

    # say L563 linGuide
    old "Go to sleep."
    new "برو بخواب."

    # say L565 belGuide
    old "Go to school in the morning."
    new "صبح زود به مدرسه برو."

    # say L566 barGuide
    old "Keep progressing with Brixxida."
    new "با بریکسیدا پیش برو"

    # say L568 bilGuide
    old "Keep progressing with other characters."
    new "با سایر شخصیت‌ها پیشرفت کن."

    # say L584 mom2Rel
    old "step mom"
    new "مادر نفرť"

    # say L700 sisGuide
    old "Meet her in the hallway."
    new "باهاش در راهرو ملاقات کن."

    # say L701 johGuide
    old "Keep progressing with Hinn."
    new "با هین پیش برو."

    # say L703 lydGuide
    old "Go to her house."
    new "به خونه‌اش برو."


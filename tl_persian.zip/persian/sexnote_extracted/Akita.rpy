# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Akita.rpy
translate persian strings:

    # menu L36 
    old "Talk to her"
    new "باهاش حرف بزن"

    # say L39 aki
    old "Hello, welcome to Jamliz Corporation! How can I help you?"
    new "سلام، خوش آمدید به شرکت جملیز! چطور می‌تونم به تو کمک کنم؟"

    # say L41 pla
    old "Hi, nice to meet you. My name is [pla]. I was sent by my [mo2rel], to give you these documents..."
    new "سلام، خوشحالم که با تو آشنا شدم. من [pla] هستم. [mo2rel] مرا فرستاده تا این اسناد رو به تو برسونم..."

    # say L44 aki
    old "Ohh right. She told me she was going to send a delivery boy with those documents. Perfect... Thank you very much!"
    new "اوه درسته. او به من گفت که یک پسر ارسالی با این اسناد می‌آید. عالی... ممنون بسیار!"

    # say L46 pla
    old "Delivery boy? Ok, well... I think that's it... right?"
    new "پسر ارسال؟ خب، خوب... فکر کنم همه چیز درسته... درسته؟"

    # say L48 aki
    old "Yes, and by the way, my name is Akita nice to meet you..."
    new "بله، و اصلاً من آکیتا هستم، خوشحالم که با تو آشنا شدم..."

    # say L50 pla
    old "Oh, yes, I'm [pla]. The pleasure is mine..."
    new "اوه، بله، من [pla] هستم. لذت برای من بود..."

    # say L52 aki
    old "Yes, yes you already told me... Hahaha."
    new "بله، بله تو قبلاً به من گفتی... هاهاها."

    # say L54 pla
    old "Oh... right, of course, my bad... Well, it was nice to meet you, see you later..."
    new "اوه... درسته، البته، عذرخواهم... خب، خوشحالم که با تو آشنا شدم، بعداً می‌بینیم..."

    # say L56 aki
    old "See you later, [pla]."
    new "ببینم بعداً، [pla]."

    # say L68 aki
    old "Oh, hi [pla], Mrs. [mo2] sent you with more documents or did you come to visit me?"
    new "اوه، سلام [pla]، خانم [mo2] تو رو با اسناد بیشتری فرستاده یا برای ملاقات من اومدی؟"

    # say L70 pla
    old "Well, Mr. [mo2] sent me..."
    new "البته، آقای [mo2] من رو فرستاده..."

    # say L73 aki
    old "Hahaha, I'm just messing with you, perfect... Thank you very much."
    new "حاحاحا، فقط با تو می‌خیلیم، عالی... ممنون ازت."

    # say L75 pla
    old "Well... You're welcome, see you later..."
    new "خوب... خواهش می‌کنم، دوست من، بای‌بای..."

    # say L77 aki
    old "Goodbye, handsome."
    new "خداحافظ، زیبا."

    # say L88 pla
    old "I shouldn't bother her. She's working."
    new "من نباید او رو آزار بدم. او کار داره."

    # menu L100 
    old "Use Agamoto Eye 1"
    new "با چشم Agamoto 1 استفاده کنم"

    # menu L104 
    old "Use Agamoto Eye 2"
    new "از چشم Agamoto 2 استفاده کن"

    # menu L108 
    old "Use Agamoto Eye 3"
    new "با چشم Agamoto 3 استفاده کنم"

    # say L115 pla
    old "No, no. Sorry. I was just walking around."
    new "نه، نه. معذرت. من فقط داشتم گشتم."

    # menu L117 
    old "Back"
    new "بازگشت"


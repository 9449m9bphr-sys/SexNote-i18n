# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/barAnimations.rpy
translate persian strings:

    # say L53 pla
    old "Uhmm... I- I don't think that was in the script Barbie."
    new "اوه... من فکر نمی‌کنم این تو اسکریپت باربی بوده."

    # say L112 pla
    old "B- barbie! I- I'm about to...!"
    new "ب- باربی! من- من در حال هستم...!"

    # say L123 pla
    old "Yeah... I'm glad."
    new "بله... خوشحالم."

    # say L124 pla
    old "But I wasn't expecting that."
    new "ولی من این را منتظر نبودم."

    # say L125 pla
    old "Maybe you should be careful when you drink..."
    new "شاید باید وقتی می‌نو خودت رو مراقبت کنی..."

    # say L153 pla
    old "I- I do!"
    new "من- من می‌کنم!"

    # say L176 pla
    old "B- barbie I- I can't hold it in anymore!"
    new "B- بربی من- من دیگه نمی‌تونم تحمل کنم!"

    # say L188 pla
    old "Uhmm, yeah... But we really can't right now."
    new "اوه، بله... اما الان واقعاً نمی‌تونیم."

    # say L189 pla
    old "So how about you get up? So I can get my pants up."
    new "پس چطور اگه بلند شی؟ تا من پانتومون رو بالا بیارم."

    # say L239 pla
    old "B- Barbie! I- I'm about to cum!"
    new "ب- باربی! من- من همین الان می‌آیم!"

    # say L409 joh
    old "[pla]? What are you doing here?"
    new "[pla]؟ شما اینجا چه کاری دارید؟"

    # say L410 joh
    old "Are you here to see somebody?"
    new "آیا برای دیدن کسی اینجا هستی؟"

    # say L411 joh
    old "Is Hinn with you?"
    new "آقای هین با شما هست؟"

    # say L413 pla
    old "D- Dr. Johnson! H- hi!"
    new "دکتر جانسون! س- سلام!"

    # say L414 pla
    old "N- no, I'm not here with anybody."
    new "ن- نه، من همراه کسی نیستم."

    # say L415 pla
    old "I- uh- Ugh-"
    new "ا- اوه- آخ-"

    # say L416 pla
    old "I'm here to deal with some things of my own!"
    new "من اینجا هستم تا چند کار خودم را انجام دهم!"

    # say L417 joh
    old "Why are you panting?"
    new "چرا نفس تیز می‌کشی؟"

    # say L419 joh
    old "I see you have your business in something here."
    new "می‌بینم کار خودت رو اینجا داری می‌کرد."

    # say L420 joh
    old "I- I'll let you be."
    new "من- من اجازه می‌دم بروی."

    # say L421 joh
    old "Have fun..."
    new "لذت ببرید..."

    # say L435 pla
    old "B- Barbie! You have to stop!"
    new "ب- باربی! باید متوقف شی!"

    # say L436 pla
    old "Someone already saw us!"
    new "کسی قبلاً ما رو دیده!"

    # say L472 pla
    old "What are you talking about!"
    new "تو در مورد چی حرف می‌زنی!"

    # say L473 pla
    old "I'm sure Dr. Johnson caught us!"
    new "مطمئنم دکتر جانسون ما رو دیده!"

    # say L474 pla
    old "What if she says something to the building administrators?!"
    new "اگه او چیزی به مدیران ساختمون بگه چه خواهد شد؟!"

    # say L594 pla
    old "Barbie I-!"
    new "باربی من!"

    # say L654 pla
    old "B- Barbie - I feel like I'm cumming!"
    new "B- باربی - حس می‌کنم می‌آیم!"

    # say L665 pla
    old "I- I'm glad you enjoyed it."
    new "خوشحالم که لذت برده‌ای."

    # say L666 pla
    old "But hey, what do you say we get up and get dressed?"
    new "ولی بیا، چطور می‌گی به این که بلند بشیم و لباس پوشیم؟"


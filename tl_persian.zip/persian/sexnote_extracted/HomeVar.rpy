# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/HomeVar.rpy
translate persian strings:

    # say L116 sis
    old "What do you want? I'm busy with the website..."
    new "چه کاری می‌خوای؟ من مشغول سایت هستم..."

    # say L117 pla
    old "Do you need some help?"
    new "می‌تونم کمکت کنم؟"

    # say L118 sis
    old "No, I need to be alone..."
    new "نه، باید تنها باشم..."

    # say L119 pla
    old "Ok... (What is wrong with her?)"
    new "باشه... (بچه، چه کاری داری؟)"

    # say L147 pla
    old "Hey [sis], I was thinking about repeat a photoshoot."
    new "هی [sis]، من فکر می‌کنم باید جلسه عکس رو دوباره بزنیم."

    # say L148 sis
    old "Do you want to repeat a photoshoot?"
    new "می‌خوای دوباره عکس ببریم؟"

    # say L149 pla
    old "Right, I think it would be useful to have more photos even with the same outfits..."
    new "بله، فکر می‌کنم داشتن عکس‌های بیشتر حتی با همان لباس‌ها مفید باشه."

    # say L150 sis
    old "Alright, you are the nerd here."
    new "البته، تو اینجا مغز هستی."

    # say L151 sis
    old "Which photoshoot should we repeat?"
    new "چه عکس‌برداری رو باید تکرار کنیم؟"

    # menu L154 
    old "The first one"
    new "اولی"

    # say L155 sis
    old "Good choice..."
    new "خوب انتخاب کردی..."

    # menu L161 
    old "The second one"
    new "دومی"

    # say L162 sis
    old "Hmm I really like that one..."
    new "همم، واقعاً اینو دوست دارم..."

    # menu L167 
    old "The third one"
    new "سومی"

    # say L168 sis
    old "Great, let's go to the pool..."
    new "عالی، بیایم به پول برویم..."

    # menu L174 
    old "The fourth one"
    new "چهارمی"

    # say L175 sis
    old "Oh, I love this photoshoot..."
    new "اوه، عاشق این فتوشاوت هستم..."

    # say L190 sis
    old "Are you ready to work on the website?"
    new "آماده‌ای برای کار روی وب‌سایت؟"

    # say L191 pla
    old "Yeah, I think so."
    new "بله، فکر کنم آماده‌ام."

    # say L192 sis
    old "So, what are we waiting for? Let's work!"
    new "پس، منتظر چی هستیم؟ بیاین کار کنیم!"

    # say L215 sis
    old "Mmm, what do we have here?"
    new "ممنون، اما من درخواست شما را درک نکردم. لطفاً مجدداً سوال خود را بپرسید تا بتوانم بهتر به شما کمک کنم."

    # say L216 pla
    old "(Gulp) Well..."
    new "(گریبان) خب..."

    # say L217 sis
    old "I already know... You want my help, right?"
    new "من قبلاً می‌دونم... می‌خوای از من کمک بگیری، درسته؟"

    # say L219 sis
    old "With all my pleasure! Hehe."
    new "با تمام خوشحالی! ههه."

    # say L253 sis
    old "Glad that you came, quite on time for applying the sunscreen, would you help me again?"
    new "خوشحالم که اومدی، همین الان وقت خوبی برای پاشون کردن لوشن است، دوباره به من کمک می‌کنی؟"

    # say L257 pla
    old "Hmm, Sure."
    new "Hmm، حتماً."

    # say L260 pla
    old "I can't right now..."
    new "الان نمی‌تونم..."

    # say L261 sis
    old "Oh, it's a shame, I was expecting a new skin care therapy..."
    new "او، خیلی جالب است، من منتظر یک درمان جدید پوست بودم..."

    # say L263 sis
    old "Alright, I will be here taking a sunbath if you change your mind..."
    new "البته، من اینجا هستم اگر نظرت عوض شد..."

    # say L274 sis
    old "Great, I wanted to have some fun today..."
    new "عالی، من هم می‌خواستم امروز لذت ببرم..."

    # say L285 sis
    old "So, what do you want to do today?"
    new "پس، امروز می‌خوای چی کنی؟"

    # menu L288 
    old "Boobs"
    new "سینه‌ات"

    # say L289 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your boobs..."
    new "Hmm فکر کنم برای عکس‌برداری بعدی خوب باشه تمرکز رو بر سینه‌ات بذاریم..."

    # say L290 sis
    old "I like that too... Al right, let's do it..."
    new "من هم دوست دارم... خب، بیایم انجام بدیم..."

    # say L302 sis
    old "Ready to fuck them?"
    new "آماده‌ام به اونا بکنم؟"

    # say L320 sis
    old "Uhhh, that's it. I love how much it is, let me spread it all over, I am ready to take a sunbath."
    new "اوه، همینه. عاشقم که چقدر هست، بیایم بریزم همه جا، آماده‌ام برای خوردن خورشید."

    # say L321 sis
    old "Thanks for your help again, [pla]"
    new "ممنون از کمکت دوباره، [pla]"

    # say L322 pla
    old "You are welcome, always trying to help."
    new "خواهش می‌کنم، همیشه سعی می‌کنم کمکت کنم."

    # say L323 sis
    old "Hahaha Sure."
    new "هahaha البته."

    # menu L333 
    old "Ass"
    new "من همیشه سعی می‌کنم کمک کنم."

    # say L334 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your ass..."
    new "همم فکر می‌کنم برای عکس‌برداری بعدی خوب باشه تمرکز رو بر این جا بذاریم..."

    # say L335 sis
    old "Oh yeah, let's focus on my ass..."
    new "اوه بله، بیایم روی پاشم تمرکز کنیم..."

    # say L342 sis
    old "You can touch all you want! I love it."
    new "تو می‌تونی همه‌ش رو لمس کنی! من عاشقش هستم."

    # say L349 sis
    old "Alright, now let's fuck!"
    new "خب، حالا بیایم با هم سکس کنیم!"

    # say L369 sis
    old "Uhhh, it was delicious..."
    new "اوه، خیلی لذت‌بخش بود..."


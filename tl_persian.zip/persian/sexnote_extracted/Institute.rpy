# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Institute.rpy
translate persian strings:

    # say L15 pla
    old "I should go to the garage to talk with Brixxida first."
    new "باید به گاراژ برسم و با بریکسیدا صحبت کنم."

    # say L53 hin
    old "Well, she is in the classroom right now. You should go and show her."
    new "خب، اون الان توی کلاس هست. باید بروی و بهش نشون بدی."

    # say L55 pla
    old "Ok. Doing it now."
    new "باشه، الان می‌رم."

    # say L174 pla
    old "Nothing much, it’s just that I haven’t seen you when I’ve gone to your home to do the repairs on the bathroom."
    new "چیز خاصی نیست، فقط اینکه هر بار که برای تعمیرات حمام به خونه‌ت رفتم، تو رو ندیدم."

    # say L175 hin
    old "Yeah, I’m sorry about that."
    new "بله، معذرت برای این."

    # say L176 hin
    old "This whole extracurricular work has been keeping me busy."
    new "این کارهای اضافی من رو مشغول کردن."

    # say L177 hin
    old "But it’s supposed to count for extra credit for college, so, I guess that’s alright."
    new "البته، این برای اعتبار اضافی در دانشگاه هست، پس حدس می‌زنم مشکلی نداره."

    # say L178 pla
    old "Of course, of course, I totally get it."
    new "البته، البته، کاملاً متوجهم."

    # say L179 hin
    old "I’ll make it up to you once I’m done with all of this."
    new "بازم جایی نمی‌خوره، هر کاری که برامون باقی مونده رو انجام میدم."

    # say L180 hin
    old "We’ll also have some time to ourselves once you’re done with the bathroom."
    new "وقتی از توالت بر می‌گردی، وقت خودمون رو هم می‌گذاریم."

    # say L181 pla
    old "Yeah, I guess I better hurry to finish with that. The sooner the better."
    new "بله، به نظر می‌رسه باید سریع‌تر این کار رو تمام کنم. هر چه زودتر بهتره."

    # say L182 hin
    old "It’s very kind of you to do that for us."
    new "خیلی مهربانی ازت که اینجوری برایمون کار می‌کنی."

    # say L183 pla
    old "No problem, it’s rather easy."
    new "هیچ اشکالی ندارم، خیلی آسانه."

    # say L184 pla
    old "By the way, I think I’ll go work on that right now."
    new "باید برم و الان روی اون کار بکنم."

    # say L185 pla
    old "See you later Hinn."
    new "بای هین"

    # say L187 hin
    old "Sure, see you later."
    new "بله، بعداً می‌بینیم."

    # say L203 pla
    old "Hey, Hinn"
    new "های، هین"

    # say L207 pla
    old "Do you have a therapy appointment today with Dr. Johnson?"
    new "امروز معاونت دکتر جانسون داری؟"

    # say L209 hin
    old "No, actually I think we should work on the class project today."
    new "نه، در واقع فکر می‌کنم باید امروز روی پروژه کلاس کار کنیم."

    # say L211 pla
    old "You are right, we have work to do."
    new "درست می‌فرمایی، باید کارمون رو انجام بدیم."

    # say L213 hin
    old "If we make a good progress I could set an appointment for tomorrow."
    new "اگر پیشرفت خوبی کنیم، می‌تونم برای فردا وقت بگذaram."

    # say L215 pla
    old "Always that responsible. That sounds good to me."
    new "همیشه همین مسئولانه. این برای من خوبه."

    # say L218 hin
    old "Hehehe... Great, see you in my house."
    new "هههه... عالی، بیا به خونه‌ام."

    # say L220 pla
    old "Perfect. See you then."
    new "عالی. تا وقتی."

    # say L250 bel
    old "Hey, [pla]!"
    new "هی، [pla]!"

    # say L252 pla
    old "Hi Bell."
    new "سلام بل."

    # say L254 bel
    old "Did you start to work on your project?"
    new "پروژه‌تو شروع کردی؟"

    # say L256 pla
    old "Well, I talked to Hinn, I think we're going to start this afternoon..."
    new "خب، با هین حرف زدم، فکر کنم امشب شروع می‌کنیم..."

    # say L258 bel
    old "Lucky you, I got paired with that asshole Mike this time. I don't know how everything is going to work out..."
    new "خوشحالم برای تو، این بار من با آن خر مایک جفت شدم. نمی‌دونم چطور همه چیز پیش می‌ره..."

    # say L260 pla
    old "Don't worry, Mike is good whenever he tries."
    new "نگران نباش، مایک هر وقت سعی می‌کنه خوبه."

    # say L262 bel
    old "Hmm... I sure hope so..."
    new "اوه... امیدوارم همین‌طور باشه."

    # say L264 pla
    old "Ok... Bell, I have to go to meet with Hinn. Bye."
    new "بلا، من باید برای ملاقات با هین برو. خداحافظ."

    # say L266 bel
    old "See you later, [pla]..."
    new "بای بعد، [pla]..."

    # say L274 bel
    old "Hey, [pla]! How did it go with your project?"
    new "اوه، [pla]! پروژه‌تو چطور شد؟"

    # say L276 pla
    old "Actually, great! Hinn is quite good and she has taught me a lot..."
    new "در واقع عالی بود! هین خوبه و ازش خیلی چیزهایی یاد گرفتم..."

    # say L278 bel
    old "Hmm... Right, Hinn is a pretty nerd... Mine is an ugly asshole..."
    new "همم... درسته، هین یه نرد خوبه... منم یه اسباب زشتی دارم..."

    # say L280 pla
    old "It can't be that bad ..."
    new "نمی‌تونه اونقدر بد باشه..."

    # say L282 bel
    old "It can't be that bad?... We went to my house to study and he tried to look in my underwear drawer... Three times!"
    new "نمی‌تونه اونقدر بد باشه؟... رفتیم به خونه من برای مطالعه و سعی کرد توی لب‌آویز مونده‌هام نگاه کنه... سه بار!"

    # say L284 pla
    old "Really?... Uhh weird..."
    new "وای، واقعاً؟... خیلی عجیب است..."

    # say L286 bel
    old "Tell me about it... I have to do everything by myself."
    new "بله، بگو... من باید همه چیز رو خودم انجام بدم."

    # say L288 pla
    old "Too bad... Fortunately, you are smart and you can actually do it alone. I really couldn't without help."
    new "ببخشید... خوشحالم که تو هوشیاری داری و می‌تونی این کار رو به تنهایی انجام بدی. من واقعاً بدون کمک نمی‌تونستم."

    # say L290 bel
    old "... Seriously, every time I see Mike, I just want to kill him..."
    new "... جدی هستی، هر بار که مایک رو می‌بینم، فقط می‌خوام اونو بکشم..."

    # say L292 pla
    old "Damn... Well, Bell, I have to go. I will see you later..."
    new "لعنتی... خب، بلم، باید برسم. بعداً می‌تونیم دوباره ببینیم..."

    # say L294 bel
    old "See you later, [pla]!"
    new "ببینم بعداً، [pla]!"

    # say L297 bel
    old "Hey, [pla]! How's it going?"
    new "سلام، [pla]! چطوری؟"

    # say L299 pla
    old "Hi Belle, I'm doing great!"
    new "سلام بله، خوبم!"

    # say L300 pla
    old "A little busy with school work and stuff, you know."
    new "مثلاً متأهل شدم به کار مدرسه و چیزهایی، میدونی."

    # say L302 bel
    old "Yeah, I get it."
    new "بله، متوجهم."

    # say L303 pla
    old "How about you?"
    new "تو چطوری؟"

    # say L305 bel
    old "Well, I guess I'm ok."
    new "خوب، فکر کنم من هم خوبم."

    # say L307 bel
    old "Lately my mom has been a little intense."
    new "اخیراً مامانم یه جور خیلی شدید شده."

    # say L308 bel
    old "She's always coming and going from home."
    new "همیشه از خونه می‌آیی و می‌رود."

    # say L310 bel
    old "And every time she's home she wants to see me or talk to me "
    new "و هر بار که در خونه است می‌خواهد از من ببیند یا با من صحبت کند"

    # say L312 pla
    old "Hmm... I can imagine how annoying it must be."
    new "همم... می‌تونم بفهمم چقدر خسته‌کننده باید باشه."

    # say L314 bel
    old "I guess I'll have to deal with it."
    new "باید با این مشکل برخورد کنم."

    # say L315 bel
    old "She's been handling a lot because of her job."
    new "اونجوری که از کارش سر در می‌آره."

    # say L316 bel
    old "So, I guess that when the whole thing is over she'll be right back to normal."
    new "پس فکر کنم وقتی همه چیز تمام شد، دوباره به حالت عادی بر می‌گرده."

    # say L317 pla
    old "Yeah, I'm sure she will."
    new "بله، احتمالاً همینجور خواهد شد."

    # say L318 pla
    old "Hey, I have to run, but I'll see you later."
    new "ببین، من باید برسم، ولی بعداً می‌تونیم هم ببینیم."

    # say L320 bel
    old "Sure, see you."
    new "بله، بعداً می‌بینیم."

    # say L323 pla
    old "Hi Belle, good morning."
    new "سلام بله، صبح خوب."

    # say L325 bel
    old "Hi [pla]..."
    new "سلام ز[pla]..."

    # say L326 bel
    old "How are you?"
    new "چطوری؟"

    # say L327 pla
    old "I'm ok, how are you doing?"
    new "من خوبم، تو چطوری؟"

    # say L329 bel
    old "Well, I'm fine I think."
    new "خوب، فکر کنم خوبم."

    # say L330 bel
    old "The situation has been tense with my mom since our fight."
    new "موقف بین من و مامان از بعد جدال خیلی تنیده است."

    # say L332 bel
    old "So we're not actually talking right now."
    new "پس الان واقعاً با هم صحبت نمی‌کنیم."

    # say L334 bel
    old "But other than that I'm doing well."
    new "اما غیر از اون همه، من خوب هستم."

    # say L335 bel
    old "Since I moved with Amorette, and I've been able to work from her home."
    new "از زمانی که با آمورت هستم، می‌تونم از خونه‌اش کار کنم."

    # say L337 bel
    old "So on that end, everything's fine."
    new "پس از این جهت، همه چیز خوبه."

    # say L339 pla
    old "Ok, I see, well, I guess that's fine."
    new "خب، من متوجه شدم، به نظر می‌رسه همه چیز خوبه."

    # say L340 pla
    old "As long as you're ok, I suppose everything's alright."
    new "اگه تو خوبی، فکر کنم همه چیز درسته."

    # say L342 bel
    old "Yeah."
    new "بله."

    # say L343 pla
    old "Alright, it was nice to see you. See you later, Belle."
    new "البته، خوشحالم که تو رو دیدم. بعداً می‌بینیم، Belle."

    # say L345 bel
    old "Sure. See you later, [pla]."
    new "البته. بعداً می‌بینیم، [pla]."

    # say L375 pla
    old "Uhh... Nothing. I was just heading out. Sorry."
    new "اوه... هیچ. فقط داشتم خارج می‌شدم. معذرت."

    # say L402 mia
    old "What do you want [pla]?"
    new "چه کاری می‌خواهی [pla]؟"

    # say L405 pla
    old "I... wanted to talk about the final project."
    new "من... می‌خواستم در مورد پروژه نهایی صحبت کنم."

    # say L406 mia
    old "Is it ready? Do you have any progress to show?"
    new "آماده شده؟ هیچ پیشرفتی برای نشون دادن نداری؟"

    # say L416 mia
    old "Wow, I can't believe it. You guys did it..."
    new "واو، باور نمی‌کنم. شما دوستان اینقدر کار کردید..."

    # say L418 pla
    old "And... How was it?"
    new "و... چطور بود؟"

    # say L420 mia
    old "Your project is... Good... I guess..."
    new "پروژه‌ات... خوبه... فکر کنم..."

    # say L435 mia
    old "You have completed a lot. I have to say I am surprised..."
    new "پروژه‌ات خوب است. باید بگم شگفت‌زده‌ام..."

    # say L437 mia
    old "By the way, I talked with your partner... And she said you have been working hard... I wasn't sure, but I have to believe her... Maybe I underestimated you, [pla]."
    new "البته، من با همکار تو صحبت کردم... و او گفت که تو خیلی سخت کار کردی... من مطمئن نبودم، اما باید به او باور شوم... شاید تو را زیر برداشتم، [pla]."

    # say L439 pla
    old "Thank you!"
    new "ممنون!"

    # say L441 mia
    old "Don't get too excited. You still have a lot of work to do before it is done."
    new "خوشحال نباش. هنوز کار زیادی باید انجام بدی تا تمام شه."

    # say L457 mia
    old "I can't believe you did something of this... I need to talk with your partner, tell her to come and talk with me... ALONE!"
    new "نمی‌تونم باور کنم که چیزی از این قبیل انجام دادی... باید با همسرت صحبت کنم، بهش بگو که بیاد و با من حرف بزنه... تنهایی!"

    # say L459 pla
    old "Hmm... Ok... I will tell her..."
    new "Hmm... خب... من بهش می‌گم..."

    # say L474 mia
    old "Ok, now this is getting really suspicious..."
    new "خب، حالا این خیلی مشکوک می‌شه..."

    # say L478 mia
    old "Anyway, I'm busy to worry about you..."
    new "به هر حال، من مشغول هستم تا نگران تو بشم..."

    # say L480 pla
    old "Hmmm ok."
    new "Hmmم احتمالاً بله."

    # say L494 mia
    old "Oh? Have you made more progress? Is your partner doing everything?"
    new "اوه؟ پیشرفت بیشتری کرده‌ای؟ همکارت همه کارها رو انجام میده؟"

    # say L496 pla
    old "What?! Of course not! This is all team work."
    new "چه خبر؟ حتماً نه! این همه کار تیمی است."

    # say L498 mia
    old "Hmm... You haven't screwed it up yet. I will keep waiting."
    new "همم... هنوز این کار رو خراب نکردی. من منتظر خواهم ماند."

    # say L511 mia
    old "Oh, you have started... But you still have a lot of work to do before you are done..."
    new "اوه، شروع کردی... اما هنوز کار زیادی برای تمام کردن داری..."

    # say L513 pla
    old "But?... How is it?"
    new "ولی؟... چطوره؟"

    # say L515 mia
    old "For now, it's ok. But I'm sure you will screw it up, sooner or later."
    new "تا حالا خوبه. ولی مطمئنم که زود یا دیر این کار رو خراب می‌کنی."

    # say L526 mia
    old "As I thought... then don't bother me. Talk to me when you've made some progress... if you even can, of course..."
    new "همانطور که فکر می‌کردم... پس از این به من تحریک نده. وقتی پیشرفتی کردی با من صحبت کن... اگر بتونی، البته..."

    # say L537 mia
    old "Yeah, yeah congratulations, your project was good, are you happy?"
    new "بله، بله تبریک، پروژه‌ت خوب بود، خوشحالم؟"

    # say L539 pla
    old "Thanks! see you!..."
    new "ممنون! ببینم!..."

    # menu L573 
    old "Start the Class"
    new "کلاس شروع می‌شه"

    # say L593 luc
    old "The class will start soon, [pla]."
    new "کلاس زود خواهد شروع شد، [pla]."

    # say L594 luc
    old "Just take a seat."
    new "لطفاً جای خودتون رو بگیرید."

    # say L595 pla
    old "... Uhhh sure."
    new "آره مطمئن."

    # say L755 mia
    old "Well, ladies and gentlemen. Please remember the final project you have to do..."
    new "خب، سایر آقایان و خانوم‌ها. لطفاً به یاد داشته باشید که پروژه نهایی‌تون رو باید انجام بدید..."

    # say L757 pla
    old "(Hmm... The final project... one of the hardest and boringest things ever!)"
    new "Hmm... پروژه نهایی... یکی از سخت‌ترین و خسته‌کننده‌ترین چیزهایی که هست!"

    # say L758 pla
    old "(I mean, research? Bibliographies? Theoretical framework?... All that work on stuff I'll never use...)"
    new "(منظورم اینه، تحقیق؟ منابع؟ چارچوب نظری؟... همه این کار برای چیزهایی که هرگز نمی‌کنم...)"

    # say L764 pla
    old "(I really want to graduate and be free from all of this crap…)"
    new "وای، واقعاً می‌خوام فارغ‌التحصیل شم و از همه این خرابی آزاد بشم…"

    # say L773 pla
    old "Where did it fall from?... An airplane?"
    new "از کجا فروریخت؟... از هواپیما؟"

    # say L777 pla
    old "Sorry, Mrs. Mia. I'm listening. I was just... looking through the window..."
    new "ببخشید، خانم میا. من گوش می‌دم. فقط... از پنجره داشتم نگاه می‌کردم..."

    # say L778 mia
    old "Oh really? Then please tell us all the project requirements that I just explained..."
    new "او واقعاً؟ پس لطفاً تمام مراحل پروژه را که به شما توضیح دادم، برای ما بگویید..."

    # say L789 pla
    old "Ughh... Finally free!..."
    new "اوه... در نهایت آزاد!"

    # say L791 pla
    old "(I don't know how I'm going to get that project done.)"
    new "نمی‌دونم چطور اون پروژه رو تمام می‌کنم."

    # say L798 bel
    old "Hey [pla]!"
    new "اوه ز[pla]!"

    # say L800 pla
    old "Hey, Bell! I wanted to ask you... if we... could work together in the class project?"
    new "بله، بله! می‌خواستم ازت بپرسم... آیا می‌تونیم همکاری کنیم توی پروژه کلاس؟"

    # say L802 bel
    old "You wasn't paying attention, huh?"
    new "تو هیچ وقت توجه نمی‌کردی، هه؟"

    # say L804 pla
    old "What?... What you mean?"
    new "چی؟... منظورت چیه؟"

    # say L806 bel
    old "This project is for couples and your partner is Hinn."
    new "این پروژه برای زوج‌هاست و همسرت هین هست."

    # say L808 pla
    old "Really? OK, thanks anyway."
    new "وای، واقعاً؟ خب، ممنون هر جا."

    # say L813 mik
    old "Heyyy guys! Did you notice  Mia`s neckline, every day she gets hotter and hotter."
    new "هییی دستا! می‌شنیدیم خط نگاه میا، هر روز داغ‌تر می‌شه."

    # say L816 bel
    old "Really Mike? She could be your mother ... "
    new "وای مایک؟ می‌تونه مادرت باشه..."

    # say L818 mik
    old "That makes it even more sexy. A hot ass milf teaches us. Sounds nice, aye, [pla]?"
    new "این هم خودش جالب تر می‌شه. یه مامان خوشکل ما رو می‌آموزه. خوبه، همینطور نیست، [pla]؟"

    # say L820 pla
    old "I only know that she hates my guts and each day it gets worse. I just hope I'm alive at the end of the school year."
    new "من فقط می‌دونم که او نفرت از من داره و هر روز بدتر می‌شه. امیدوارم تا پایان سال تحصیلی زنده باشم."

    # say L822 bel
    old "Well, I'm leaving. I have things to do. And I don't want to stay here and keep listening to Mike's perversions."
    new "خب، من می‌روم. کارهایی دارم. و نمی‌خوام اینجا بیشتر بمونم و به پرداختن‌های مایک گوش بدم."

    # say L824 pla
    old "Bye, Belle. See you around."
    new "بای، بله. دیدن خوشحالم."

    # say L831 mik
    old "Have you noticed how hot Belle is gettin'?"
    new "دیدی چقدر بله داغ می‌شه؟"

    # say L833 pla
    old "Dude... Damn, you should calm down a little."
    new "دود... باید کمی آرامش بیاری."

    # say L835 mik
    old "Why? Are you gay or something?"
    new "چرا؟ تو هم جنسی هستی؟"

    # say L837 pla
    old "Bye, Mike. I'll talk to you later"
    new "بای مایک. بعداً با تو صحبت می‌کنم"

    # say L839 mik
    old "So I'm right, huh? But she is hot, isn't she?"
    new "پس من درست حدس زدم، ها؟ اما او خوبه، نه؟"

    # say L856 pla
    old "Wait... Is this...?"
    new "پیش... این...؟"

    # say L858 pla
    old "The book that fell from the sky?"
    new "کتابی که از آسمون فرود آمد؟"

    # say L860 pla
    old "SexNote?  What could it be about?"
    new "سکس‌نوت؟ این درباره چی می‌تونه باشه؟"

    # say L862 pla
    old "Weeeell, finders-keepers. Hehe."
    new "خب، پیدا کردن، خودمون نگه دارن. هه هه."

    # say L864 pla
    old "Maybe I can think of something interesting to draw in it."
    new "شاید بتونم چیز جالبی برای رسمش فکر کنم."

    # say L883 mik
    old "Hey, wait! Before you go... I have something to show you that will surely blow your mind."
    new "هی، صبر کن! قبل از برود... چیزی هست که می‌خوام بهت نشون بدم و حتماً ذهنت رو خواهد زد."

    # say L885 pla
    old "Now what weird thing do you have in mind?"
    new "الان چه چیز عجیبی به ذهن تو برده؟"

    # say L887 mik
    old "Listen... Just go to my house and look for me in my room. I'll show you."
    new "بگو... فقط به خونه‌ام بیا و به اتاقم بگرد. بهت نشون می‌دم."

    # say L889 pla
    old "Hmm, alright... I will see you then."
    new "Hmm، خوب... من هم اومدم."

    # say L891 mik
    old "Seriously, [pla].I assure you it will be worth it!"
    new "serieously، [pla]. تو را مطمئن می‌کنم این جایی خواهد بود که باید ببینی!"

    # say L908 pla
    old "I shouldn't enter. This isn't my classroom."
    new "من نباید وارد شوم. این کلاس من نیست."


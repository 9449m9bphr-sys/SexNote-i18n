# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/anaAnimations.rpy
translate persian strings:

    # say L12 ana
    old "What a nice cock do you have..."
    new "چقدر خوب نیم‌تنی داری..."

    # say L16 ana
    old "Do you like it, Uh? Do you want it faster baby?"
    new "می‌پسندی این، هه؟ آیا می‌خوای سریع‌تر باشه، عزیزم؟"

    # say L20 ana
    old "Oh yeah baby, I wanna see that huge cock cumming..."
    new "اوه بله عزیزم، می‌خوام ببینم اون نیم‌تن بزرگ خروجی بده..."

    # say L45 pla
    old "Mrs Anastasia... I- going to-"
    new "آناستازیا... من- در حال-"

    # say L46 ana
    old "Oh yes, cum for mommy, give it to me..."
    new "اوه بله، برای مامان خروجی کن، به من بده..."

    # say L51 ana
    old "Wow that was a lot of cum..."
    new "واو، اونقدر سیک بود..."

    # say L60 ana
    old "Mmm, I love your huge cock!"
    new "ممنون، عزیزم، من عاشق پیشونت هستم!"

    # say L64 ana
    old "Do you like my mounth, baby?"
    new "آیا دوست داری از دهانم استفاده کنی، عزیزم؟"

    # say L68 ana
    old "Come on fuck my throat with your big cock!"
    new "بیا، با اون لولت بزرگ حلقمو خور!"

    # say L92 pla
    old "Anastasia I'm going to..."
    new "آناستازیا من قراره..."

    # say L93 ana
    old "Ohh yeah, cum all over my face!"
    new "اوه بله، روی صورتم برو!"

    # say L98 ana
    old "Uhhh warm and sweet..."
    new "اوه، گرم و شیرین..."

    # say L115 ana
    old "Ahhh, yeah baby fuck me, FUCK ME!"
    new "اوه، بله بچه، بگیرم، بگیرم!"

    # say L119 ana
    old "Oh god, Oh god, It feels great!"
    new "اوه خدا، اوه خدا، این حس عالیه!"

    # say L123 ana
    old "H- Harder... Fuck me harder!"
    new "س- سخت‌تر... بفرمای سخت‌تر!"

    # say L147 ana
    old "Ahhh I'm cumming!"
    new "اوه خدا! من در حال خروج هستم!"

    # say L148 pla
    old "I- I'm cumming too..."
    new "من هم هستم..."

    # say L169 ana
    old "Oh my God! This is amazing! Fuck me, Fuck me!"
    new "اوه خداوند! این شگفت‌انگیزه! بگریم منو، بگریم منو!"

    # say L173 ana
    old "AHHHH AHHHH, YEAH YEAH, HARDER BABY, HARDEER!"
    new "اااه اااه، بله بله، سخت‌تر بچه، سخت‌تر!"

    # say L177 ana
    old "OH MY GOD I LOVE YOUR COCK! GIMME MOREE!"
    new "اوه خدا! عاشق ناخودت هستم! بیشتر بده!"

    # say L212 ana
    old "Oh my god! I loved it..."
    new "اوه خدا! من دوست داشتم..."

    # say L213 pla
    old "I- I like it... too."
    new "من هم دوست دارم..."

    # say L216 ana
    old "Oh my god! You are amazing, I loved it..."
    new "اوه خدا! تو عالی هستی، من دوست داشتم..."

    # say L220 ana
    old "I loved it..."
    new "عاشقش شدم..."

    # say L229 ana
    old "Ohhh, your cock feels so nice!"
    new "اوه، ناخن تو خیلی خوب احساس می‌کنم!"

    # say L233 ana
    old "YEAH, BABY, FASTER, FASTER!"
    new "بله، عزیزم، سریع‌تر، سریع‌تر!"

    # say L237 ana
    old "OH MY FUCKING GOD! HARDER, FUCK ME HARDER!"
    new "اوه خدای من! سخت‌تر، بیا سخت‌تر به من بکن!"

    # say L275 lis
    old "Alright, take a few moments to settle into your position."
    new "باشه، چند لحظه برای تنظیم موقعیت خودت بگذران."

    # say L276 lis
    old "Bring your attention to your breath."
    new "توجهت رو به نفس‌ت ببر."

    # say L277 lis
    old "Focus on the air coming in and out."
    new "به هوا توجه کن، هنگامی که وارد و خارج می‌شود."

    # say L281 lis
    old "Notice the cool air entering your nostrils and the warm air leaving them."
    new "نگاه کن به هوای سرد که از بینی تو وارد می‌شه و هوای گرم که ازش بیرون می‌ره."

    # say L282 lis
    old "Without trying to change your breath, simply observe it."
    new "بدون تلاش برای تغییر نفس، فقط آن را مشاهده کن."

    # say L283 lis
    old "Let your body and mind relax."
    new "بدن و ذهنتو آرامش بده."

    # say L289 lis
    old "If your mind begins to wander, that's okay."
    new "اگر ذهن تو شروع به گردش کردن بکنه، این هم مشکلی نداره."

    # say L290 lis
    old "Let your body feel everything it needs to feel."
    new "بدنتو همه چیزی که باید حس کنه را حس کنه."

    # say L291 lis
    old "The sensation of my and [pla]'s hands going over your body."
    new "احساس دست‌های من و [pla] روی بدن تو."

    # say L296 lis
    old "Gently guide your focus back to the sensation of breathing."
    new "با آرامی توجهت رو به حس نفس‌کشی برگردان."

    # say L297 lis
    old "Allow yourself to be fully present with each breath."
    new "خودت رو به هر نفس کامل حاضر باش."

    # say L298 lis
    old "Finding calm and clarity in this simple act."
    new "این کار ساده ای آرامش و روشنایی می‌دهد."

    # say L303 ana
    old "Mmm, this feels great, guys."
    new "ممنون، این حس خوبی داره، دوست‌ها."

    # say L304 ana
    old "M-My body's feeling amazing!"
    new "بدن من واقعاً شگفت‌آور احساس می‌کنم!"

    # say L305 lis
    old "That's good, that's your body reacting to the energy flowing within you."
    new "این خوبه، این همون واکنش بدنت به انرژی که درون تو جریان داره."

    # say L306 lis
    old "As your chakras are being cleansed."
    new "با تمیز شدن چاکرت."

    # say L327 lis
    old "[pla], place yourself between her legs, and help her energy flow through a massage."
    new "[pla]، خودتو بین پایش قرار بده و با ماساژ به انرژی‌اش جریان پیدا کنه."

    # say L336 ana
    old "I... Oh my god!"
    new "اوه خدا!"

    # say L337 ana
    old "This feels incredible!"
    new "این حس شگفت‌انگیز است!"

    # say L338 ana
    old "I feel like I'm having an orgasm, Lisa!"
    new "احساسی مثل ارگاسم دارم، لیزا!"

    # say L339 lis
    old "Good! Enjoy that feeling!"
    new "خوب! از این حس لذت ببر!"

    # say L340 lis
    old "Let yourself fall deeply into it!"
    new "خودت رو عمیقاً به اون حس بسپار!"

    # say L347 ana
    old "Oh gosh! I can't believe it!"
    new "اوه خدا! باور نمی‌کنم!"

    # say L348 ana
    old "I actually had an orgasm that way."
    new "من در واقع به این طریق ارگاسم داشتم."

    # say L349 lis
    old "Of course, your body reacted positively to your Mudhalara chakra coming into balance."
    new "البته، بدن تو به تعادل رسیدن چاکرا مودهالارا واکنش مثبت نشون داد."

    # say L350 lis
    old "That is the beauty of a tantric process."
    new "این هم زیبایی فرآیند تانتراست."

    # say L351 ana
    old "I have to say it was amazing!"
    new "باید بگم شگفت‌زای بود!"

    # say L352 lis
    old "Haha, I'm glad you liked it."
    new "حاحا، خوشحالم که لذت برده‌ای."

    # say L353 lis
    old "I'll let you get up now."
    new "البته، حالا می‌تونی بلند بیانی."

    # say L361 ana
    old "Uhh, that was so good!"
    new "اوه، اینقدر خوب بود!"

    # say L362 ana
    old "I loved it!"
    new "عاشقش شدم!"

    # say L363 lis
    old "I see that your connection with yourself and the balance of your chakras is improving."
    new "می‌بینم ارتباطت با خودت و تعادل چاکرات بهتر شده."

    # say L364 lis
    old "I think that with this we can move on to the next exercise."
    new "فکر می‌کنم با این می‌تونیم به تمرین بعدی برویم."

    # say L365 ana
    old "Great!"
    new "عالی!"

    # say L387 lis
    old "Remember to focus on your breathing, Anastasia."
    new "دیگه نفست رو در نظر بگیر، آناستازیا."

    # say L388 lis
    old "Feel the air going in and out of your body."
    new "حاسه هوا رو وقتی وارد و خارج از بدنت می‌شه."

    # say L389 lis
    old "Let go of any thoughts or worries, allowing them to drift away with your breath."
    new "هر افکار یا نگرانی‌هایت رو بریز، بگذار با نفس‌هایت دور شوند."

    # say L393 lis
    old "Continue to focus on this flow of energy, allowing it to move freely and naturally."
    new "به این جریان انرژی تمرکز کن، بگذار آزاد و طبیعی حرکت کنه."

    # say L394 lis
    old "With each breath, feel more relaxed and centered."
    new "با هر نفس، حس کنی خیلی آرام‌تر و مرکزی‌تر می‌شوی."

    # say L395 lis
    old "Just breathe and let your energy flow in and out."
    new "تنها نفس بکش و بگذار انرژیت داخل و خارج حرکت کنه."

    # say L399 ana
    old "Mmm! This feels amazing, Lisa."
    new "ممنون، لیزا. این حس عالیه."

    # say L400 lis
    old "Yes! Focus on that sensation!"
    new "بله! روی اون حس تمرکز کن!"

    # say L401 lis
    old "Let your body guide you in what you need!"
    new "بدن تو را به آنچه نیاز داری هدایت کن!"

    # say L424 ana
    old "I'm about to... Cum Lisa!"
    new "من در حال... آمدن هستم لیزا!"

    # say L425 lis
    old "Yes! Yes! Let it all out!"
    new "بله! بله! همه‌اش رو بیرون بیا!"

    # say L426 lis
    old "Let everything flow out of you!"
    new "بله! بله! همه‌اش رو بیرون بیا!"

    # say L434 ana
    old "Oh that was so amazing!"
    new "اوه اونقدر عالی بود!"

    # say L435 ana
    old "It felt so good!"
    new "اینقدر خوب احساس شد!"

    # say L436 lis
    old "I'm glad you enjoyed it, that's your Mudhalara chakra coming into balance."
    new "خوشحالم که لذت برده‌ای، این به معنی اینه که چاکره مودالارا تو در حال تعادل پیدا کردن."

    # say L437 lis
    old "I belive we're on the right path."
    new "فکر کنم روی مسیر درست هستیم."

    # say L438 lis
    old "But now, let's get up, so that [pla] can also rest a little."
    new "اما حالا باید بلند شویم، تا [pla] هم یک کم استراحت کنه."

    # say L450 lis
    old "Relax, feel the depth of your energy."
    new "آرام، حس کن عمق انرژیت."

    # say L451 lis
    old "Feel how far it goes inside you."
    new "حس کن چقدر عمیق داخل تو می‌رسد."

    # say L452 lis
    old "And the connection [pla]'s helping you achieve."
    new "و ارتباط [pla] به تو کمک می‌کنه به این رسیدن."

    # say L456 lis
    old "Do you feel it, Anastasia?"
    new "آناستازیا، احساسش می‌کنی؟"

    # say L457 lis
    old "How deep inside you your energy goes?"
    new "انرژیت چقدر عمیق داخل تو می‌رود؟"

    # say L458 lis
    old "Do you feel it flowing?"
    new "آیا احساس جریانش می‌کنی؟"

    # say L459 ana
    old "Y-Yes I do."
    new "بله، من هم احساسش می‌کنم."

    # say L460 ana
    old "I can feel it very deep inside me!"
    new "من اون رو عمیقاً درونم حس می‌کنم!"

    # say L464 lis
    old "Do you feel your energy flowing inside, Anastasia?"
    new "آناستازیا، آیا حس می‌کنی انرژیتون درون تو جریان داره؟"

    # say L465 ana
    old "Oh yes! It's going so far inside me!"
    new "اوه بله! اونقدر عمیق داخل من می‌ریزه!"

    # say L466 ana
    old "I love how it feels!"
    new "عشق دارم این حس رو!"

    # say L489 ana
    old "Lisa! [pla]! I can't hold it in anymore!"
    new "لیزا! [pla]! دیگه نمی‌تونم خودمو کنترل کنم!"

    # say L490 lis
    old "Don't! Let yourself go!"
    new "دست بردار! خودت رو رها کن!"

    # say L491 lis
    old "Let it all out!"
    new "همه‌اش رو بیرون بیاورد!"

    # say L499 lis
    old "How do you feel, Anastasia?"
    new "حالت چطوره، آناستازیا؟"

    # say L500 ana
    old "I feel amazing!"
    new "من حس می‌کنم عالی هستم!"

    # say L501 lis
    old "Were you able to make an internal connection?"
    new "تو تونستی ارتباط داخلی برقرار کنی؟"

    # say L502 ana
    old "I can feel it all inside me."
    new "من همه چی رو درونم می‌حسم."

    # say L503 lis
    old "Wonderful! That was the objective of this!"
    new "عالی! این هدف ما بود."

    # say L504 ana
    old "Now, time to get up and get cleaned up."
    new "الان، وقت برای بلند شدن و تمیز شدن است."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mike.rpy
translate persian strings:

    # say L32 whi
    old "Mmm, hi, [pla]. Long time, no see! My, how you've grown!"
    new "می‌خواهم، سلام، [pla]. طولانی است که ندیده‌ام! خدا، چقدر رشد کرده‌ای!"

    # say L34 pla
    old "(Gulp) Hello, Mrs. White. Thank you."
    new "سلام، خانم وایت. ممنون."

    # say L37 whi
    old "I guess you came over to see Mike? What are you two planning on doing?"
    new "بگو میخواهی مایک رو ببینی؟ چه کاری قراره با هم بکنید؟"

    # say L39 pla
    old "Uhh... We... Nothing... Hehe."
    new "اوه... ما... هیچی... ههه."

    # say L44 mik
    old "Finally! You decided to come! Don't bother us, Mom. We gotta work on that dumb school project."
    new "اوه، بالاخره! خوشحالم که اومدی! ما رو آزار نده، مامان. باید روی همین پروژه مغفل مدرسه کار کنیم."

    # say L46 whi
    old "Ok. If you guys need anything, I'll be here."
    new "اوه. اگر شماها به هر چیزی نیاز داشتید، من اینجا هستم."

    # say L52 pla
    old "Alright, man. What's this great thing you just had to show me? "
    new "باشه، برو. این چیز عالی‌ای که باید به من نشون بدی چیه؟"

    # say L54 mik
    old "Well, you came just in time. Every day... at this minute... it begins."
    new "خب، تو دقیقاً در زمان مناسب اومدی. هر روز... در این دقیقه... شروع می‌شه."

    # say L56 pla
    old "What begins?"
    new "چه چیزی شروع می‌شه؟"

    # say L58 mik
    old "You'll see... Just wait."
    new "ببینی... فقط صبر کن."

    # say L61 pla
    old "The hell you doing, Mike?"
    new "تو چه کاری داری، مایک؟"

    # say L62 mik
    old "Let me enjoy for a sec. It'll be your turn in a bit."
    new "بیا برای یه لحظه لذت ببرم. بعد از یه کم دستت می‌شه."

    # say L67 mik
    old "Ok, here. Take this and peep what's out the front window? "
    new "ببین، اینو بگیر و ببین چی قدمت پنجره هست؟"

    # say L74 pla
    old "Oh shit!"
    new "اوه شیطون!"

    # say L75 mik
    old "She's hot, isn't she?"
    new "حوسنت، همینجوری نیست؟"

    # say L77 pla
    old "Damn. I think... I think, I've seen her before"
    new "شیطان. فکر می‌کنم... فکر می‌کنم قبلاً دیده‌ام."

    # say L78 mik
    old "Wait... Do you really know  that lady?"
    new "انتظار داری... واقعاً اون خانم رو بشناسی؟"

    # say L84 pla
    old " I think so but I'm not sure... I'd have to get a closer look."
    new "فکر کنم همینه اما مطمئن نیستم... باید نگاهی بهش بندازم."

    # say L87 mik
    old "Well ... I know something for sure... she is sexy as fuck! "
    new "خب... چیزی مطمئن هستم... اون جان خیلی لذت‌بخشه!"

    # say L89 pla
    old "(she really is...)"
    new "حق با تو است..."

    # say L91 pla
    old "(I think she is my [lisrel]) Mmm... Let me see her again ..."
    new "(فکر کنم او هم ز[lisrel]م است) ممم... بیایم دوباره بهش نگاه کنم..."

    # say L93 mik
    old "Haha. I knew you would like it."
    new "هahas. می‌دونستم خوشت می‌آید."

    # say L101 mik
    old "What? Is she getting naked? Give me those binoculars!"
    new "چه؟ اون جا خودش رو عریان می‌کنه؟ بده بینی‌نما رو!"

    # say L107 pla
    old "(Hmm... What am I going to do now? Can't let Mike see me like this.)"
    new "Hmm... حالا چی کار کنم؟ نمی‌تونم مایک رو اینجور ببینه."

    # say L109 pla
    old "(The only solution is to go to the bathroom and try to masturbate.)"
    new "(حل و فصل اینه که برم به دستشویی و بیارم خودمو لمس کنم.)"

    # say L111 pla
    old "Hmm... I need to use your bathroom, man. You keep watching her..."
    new "Hmm... من باید از دستشویی تو استفاده کنم، برو تو هم همینجور بهش نگاه کن..."

    # say L112 mik
    old "Ok. Suit yourself."
    new "باشه. خودت رو راحت کن."

    # say L117 pla
    old " Whoops. I'm sorry, ma'am. I thought there was no one-"
    new "اوه. معذرت، خانم. فکر کردم کسی نیست-"

    # say L118 whi
    old "Ohh, are you [pla]? Don't worry. Go on and use the toilet. I trust that you won't peep, right? "
    new "اوه، شما [pla] هستید؟ نگران نباشید. بروید و از دمتون برم آیند. مطمئن هستم که نمی‌خواهید جاسوس باشید، درسته؟"

    # say L120 pla
    old "No. Of course not, Mrs. White..."
    new "نه. البته نه، خانم وایت..."

    # say L121 whi
    old "Haha! I am just kidding. Do what you need to do, kid. I'll continue taking a shower, deal?"
    new "هه هه! من فقط مزح می‌کنم. برو کارت رو انجام بده، بچه. من ادامه می‌دم دوش می‌گیرم، ممنون؟"

    # say L122 pla
    old "Ok... (Hmm I have no option) "
    new "باشه... (Hmm من هیچ گزینه‌ای ندارم)"

    # say L129 whi
    old "(What is that noise? ...What is he doing?)"
    new "(این صدای چیه؟...ویلی چه کاری می‌کنه؟)"

    # say L133 whi
    old "(My word... He is hung!)"
    new "(البته... او خوب ساخته شده است!)"

    # say L139 whi
    old "(Mmm... I should just take my shower. I don't want him to see me peeping.)"
    new "ممنون... باید بریم دوش دارم. نمی‌خوام ببینه من نگاه می‌کنم."

    # say L143 pla
    old "Well, I managed to solve it, but I don't know for how long..."
    new "خب، تونستم حلش کنم، اما نمی‌دونم برای چه مدت..."

    # say L145 pla
    old "I better say goodbye to Mike and go home."
    new "بهتره با مایک خداحافظی کنم و برسم خونه."

    # say L156 pla
    old " Hey, Mike. I have to jet."
    new "مایک، باید برم."

    # say L157 mik
    old "Oh, ok.  If you want to check her out again, come tomorrow."
    new "اوه، خوب. اگه می‌خوای دوباره بهش نگاه بکنی، فردا بیا."

    # say L159 pla
    old "W-What?!"
    new "و-وای!"

    # say L160 mik
    old "Yeah. If you want to see my neighbor again, come tomorrow..."
    new "بله. اگه می‌خوای همسایه‌ام رو دوباره ببینی، فردا بیا..."

    # say L162 pla
    old " Ohh, right. (Whew.) The neighbor... Ok. See you later, dude."
    new "اوه، درسته. (وای.) همسایه... خوب. ببینم بعداً، دود."

    # say L182 mik
    old "Hey dude, you wanna see her again?"
    new "دود، می‌خوای دوباره ببینی؟"

    # say L185 pla
    old "Yeah, man. I want to check if I really know her."
    new "بله، بروتر. می‌خوام ببینم واقعاً اون رو شناخته‌ام یا نه."

    # say L187 mik
    old "Really? Ok, yeah, sure... Ok, it's your turn then..."
    new "وای، خوب، البته... خوب، الان دفعت تو هست..."

    # say L194 mik
    old "Remember, if she starts to undress you have to tell me..."
    new "به خاطر داشت، اگه شروع کرد لباستو برداره باید منو بگی..."

    # say L195 pla
    old "Alright..."
    new "باشه..."

    # say L197 pla
    old "(Hmm, really? Another hardon?) Mike, I need to use the bathroom. You wanna keep watching?"
    new "مایک، باید به دستشویی برسم. می‌خوای ادامه بدهیم؟"

    # say L198 mik
    old "Of course!... She's so hot."
    new "البته!... اونجوری خیلی جذابه."

    # say L212 mik
    old "You back, dude?... Check out this other position she's practicing..."
    new "باز هستی، دوست من؟... نگاه کن به این حرکت دیگه که تمرین می‌کنه..."

    # say L215 pla
    old "Really? Let me see. (Maybe now I can see her face and know if I can if i can recognize her.)"
    new "وای، واقعاً؟ بیا ببینم. شاید حالا صورتش رو هم ببینم و بفهمم می‌تونم اون رو بشناسم یا نه."

    # say L217 mik
    old "Yeah, sure... Here you go."
    new "بله، حتما... برات آماده‌ست."

    # say L227 pla
    old "(Hmm, really? An erection again?) Mike, I need to use your bathroom. You can have the binoculars back, bud."
    new "Hmm، واقعاً؟ دوباره شورش اومده؟ مایک، من باید به دستشویی برسم. می‌تونی بینی‌نما رو برگردانی، بابا."

    # say L228 mik
    old "Sweet!"
    new "عالی!"

    # say L241 mik
    old "[pla]! Come look, man! It's gotten sexier than ever!"
    new "[pla]! بیا ببین، دستا! خیلی جذاب‌تر شده!"

    # say L244 pla
    old "What the fuck..."
    new "چه فکر می‌کنی..."

    # say L251 mik
    old "She makes me so fuckin' hard. I really wanna fuck her..."
    new "او منو خیلی سخت می‌کنه. واقاً می‌خوام باهاش جنس کنم..."

    # say L253 pla
    old "(Aaaand, of course, another erection...) Yeah, Mike... this is awesome... You can keep watching..."
    new "(البته، دوباره یک ارگزیون...) بله، مایک... این خیلی عالیه... می‌تونی هم بیشتر ببینی..."

    # say L258 mik
    old "Perfect! Ohh man. Tonight, I'm going to jerk off just thinking about her... "
    new "پرفکت! اوه مرد. امشب فقط با فکر کردن بهش می‌خوام خودمو لمس کنم..."

    # say L259 pla
    old "...(This guy...)"
    new "(این دستا...)"

    # say L261 pla
    old "Mike, I need to use your bathroom, man..."
    new "مایک، باید از تویالتت استفاده کنم، بروther..."

    # say L262 mik
    old "Nice... take your time. My turn to enjoy the view."
    new "خوب... وقتت رو ببر. من هم فرصت می‌دم نگاه کنم."

    # say L275 mik
    old "Hey [pla], you wanna see her again?"
    new "هی ز[pla]، می‌خوای دوباره ببینی؟"

    # say L278 pla
    old "Well... Yes..."
    new "خب... بله..."

    # say L280 mik
    old "Ok, it's your turn then..."
    new "خب، الان دوباره تو هستی..."

    # menu L290 
    old "Position 1"
    new "پوزیشن ۱"

    # menu L295 
    old "Position 2"
    new "پوزیشن ۲"

    # menu L300 
    old "Position 3"
    new "پوزیشن ۳"

    # menu L305 
    old "Continue"
    new "ادامه"

    # say L312 pla
    old "(Aaaand, here it is, another erection...) Mike... I need to use your bathroom.... You can keep watching..."
    new "مایک... باید از تویالتت استفاده کنم... می‌تونی همچنان ببینی..."

    # say L313 mik
    old "Ok, man. It's my turn again..."
    new "باشه، برو توی حمام. من هم ادامه می‌دم..."

    # menu L324 
    old "Handjob"
    new "دست‌کار"

    # menu L326 
    old "Blowjob"
    new "دست‌کار"

    # say L342 whi
    old "Hi [pla]. If you're looking for Mike, he's in his room."
    new "سلام ز[pla]. اگه به دنبال مایکی هستی، او تو اتاقش هست."

    # say L344 pla
    old "Ok, thank you, Mrs. White."
    new "باشه، ممنون، خانم وایت."

    # say L353 whi
    old "Hey big boy... Don't you want to go to the bathroom again?"
    new "اوه پسر بزرگ... نمی‌خوای دوباره به توالت بری؟"

    # say L355 pla
    old "...I...Umm... What... do you mean?"
    new "من... اوم... چه... می‌خوای بگی؟"

    # say L357 whi
    old "I mean don't leave me waiting. I will be in there if you want to go at it again..."
    new "من قصد دارم که نگذارم منتظر بمانم. اگه می‌خوای دوباره انجام بدی، من داخل هستم..."

    # say L367 whi
    old "Hey, handsome... Are you looking for some help?"
    new "اوه، لبخند زن... آیا دنبال کمکی هستی؟"

    # say L369 pla
    old "Wh... Huh?... Nah, I was... Looking for Mike..."
    new "و... هی؟... نه، من... به دنبال مایک بودم..."

    # say L371 whi
    old "Ok, honey. Mmm, I will be in the bathroom waiting for you..."
    new "باشه، عزیزم. مم، من در حمام منتظرت می‌مونم..."

    # say L403 pla
    old "...Yeah, I'm looking for Mike, I... I will go to his bedroom, excuse me."
    new "بله، داشتم به دنبال مایک می‌گشتم، من... من می‌روم به اتاق خوابش، با عرض معذرت."

    # say L437 pla
    old "(Daaaamn!).... I'm sorry, ma'am. I'm leaving right now."
    new "(دیوونه!).... معذرت، خانم. من همین الان می‌روم."

    # say L439 whi
    old "Ohh. I'm sorry. Silly me, I forgot to close the curtains... Haha! But don't you worry. I know what you're going to do and maybe I can give you some... inspiration..."
    new "اوه. معذرت. خنده‌دارم، فراموش کردم پرده‌ها رو ببندم... هاها! ولی نگران نباش. من می‌دونم قراره چی کنی و شاید بتونم برایت یه‌چیزی از جور دیگه‌ی الهام ببرم..."

    # say L441 pla
    old "I... don't know... what you're talking about. (Gulp)"
    new "من... نمی‌دونم... تو چی می‌گیه. (گلو خشک شد)"

    # say L443 whi
    old "Ohh, come on... you're about to burst in those shorts of yours... Just let it out. Mmm, I wanna see it..."
    new "اوه، بیا... تو در اون شورت‌هایت خیلی تنگ شده‌ای... فقط بیاد بیار. مم، من می‌خوام ببینم..."

    # say L446 pla
    old "...O-Ok."
    new "...ب-بله."

    # say L449 whi
    old "That's right... Stroke that big cock for mommy..."
    new "درست است... آن پیپ بزرگت رو برای مامان بزن..."

    # say L455 whi
    old "Nice... Mmm, what a good load, [pla]..."
    new "خوب... مم، چقدر خوبه، [pla]..."

    # say L456 pla
    old "...That was intense..."
    new "...این خیلی شدید بود..."

    # say L457 whi
    old "Thank you, honey... I hope we have a bathroom rondevu again."
    new "ممنون، عزیزم... امیدوارم دوباره در توالت هم ملاقات کنیم."

    # say L459 pla
    old "I... I... have to go, Mrs. White."
    new "من... من... باید برسم، خانم وایت."

    # say L463 pla
    old "Whoa... That was crazy..."
    new "واو... این جنون بود..."

    # say L465 pla
    old "I better go home."
    new "بهتره برم خونه."

    # say L478 pla
    old "(Oh shit... Again).... I'm sorry, I'm leaving right now."
    new "او شیطون... دوباره... معذرت، الان می‌روم."

    # say L484 whi
    old "Ohh, come on... Just let it out. I wanna see it again..."
    new "اوه، بیای... فقط بیرون بیا. می‌خوام دوباره ببینم..."

    # say L498 whi
    old "Thank you, honey... I hope we have a bathroom rendezvous again."
    new "ممنون عزیزم... امیدوارم دوباره هم در توالت با هم برخورد کنیم."

    # say L519 whi
    old "Hey handsome, I was waiting for you."
    new "حالم خوبه، عزیزم، من منتظرت بودم."

    # say L523 whi
    old "Come on, don't be shy. Take that monster out and get to jerking..."
    new "بیا، نباش خجالتی. آن قایق را بیرون بیاور و شروع به نواختن کن..."

    # say L531 whi
    old "Would you mind if I give you a hand?"
    new "آیا اشکالی داری که من بهت کمک کنم؟"

    # say L532 pla
    old "(Is this really happening?) W- What?"
    new "این واقعاً اتفاق می‌فته؟ W- چی؟"

    # say L544 whi
    old "You can come whenever you want and, I'll give you a hand, my pleasure, okay?"
    new "می‌تونی هر وقتی خواستی بیاد و من بهت کمک می‌کنم، لذت‌بخش برایم، خب؟"

    # say L546 pla
    old "Yes, ma'am."
    new "بله، خانم."

    # say L547 whi
    old "Get out before Mike suspects anything..."
    new "بیرون برو قبل از اینکه مایک شک داشته باشه..."

    # say L549 pla
    old "Ok, Mrs. White... "
    new "باشه، خانم وایت..."

    # say L552 whi
    old "Hmm, what a big load..."
    new "هم، چقدر بزرگ است..."

    # say L555 pla
    old "Wow... She jerked me off..."
    new "واو... تو منو به هم ریختی..."

    # say L556 pla
    old "I should take my ass home."
    new "باید از اینجا برم."

    # say L581 whi
    old "Come on, Take off your pants. I have a little surprise for you..."
    new "بیا، لباس پایینت رو ببردار. برایت مفاجأه‌ای دارم..."

    # say L599 whi
    old "I will be waiting for you handsome..."
    new "من منتظرت می‌مونم شیرینم..."

    # say L607 whi
    old "Hmm, that tasted so good!"
    new "Hmm، اونقدر خوب طعم داشت!"

    # say L610 pla
    old "Wow... W- what just happened?"
    new "واو... چه چیزی هم اتفاق افتاد؟"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Basement.rpy
translate persian strings:

    # say L16 mo2
    old "So? Are you ready to do something useful with your life?"
    new "پس؟ آیا آماده‌ای برای انجام چیزی مفید در زندگیت هستی؟"

    # say L18 pla
    old "Umm..."
    new "اوم..."

    # say L20 mo2
    old "I don't feel comfortable with a young pervert around me, but your [mo1rel] asked me to do this for you..."
    new "من با وجود این که با یک جوان خودسرانه راحت نیستم، اما [mo1rel] درخواست کرده که برای تو این کار رو انجام بدم..."

    # say L24 mo2
    old "Which means that this is an opportunity for you to see how to make some money..."
    new "این به معنی اینه که فرصتی برایت پیش آمده تا بیاموزی چطور پول کسب کنی..."

    # say L26 pla
    old "Sweet! You're going to teach me?"
    new "حلوایی! می‌خوای به من یاد بدهی؟"

    # say L28 mo2
    old "Oh, hell no! I'm not your damn teacher. Just do what I tell you. And watch what I do, then maybe you will learn on your own..."
    new "او، حتماً نه! من معلمتو نیستم. فقط اونجور که من می‌گم کار کن. و ببین چطور من انجام میدم، شاید خودت یاد بگیری..."

    # say L30 pla
    old "Ok, ok... So what do you need me to do?"
    new "باشه، باشه... پس من چه کاری باید بکنم؟"

    # say L32 mo2
    old "First of all, I don't need you. I'm letting you work for me and learn."
    new "اول از همه، من نیازت ندارم. من اجازه میدم تو برای من کار کنی و یاد بگیری."

    # say L34 mo2
    old "Secondly, if you try to peep on me at work or do something perverted, I will fire your ass. Understood?"
    new "دوماً، اگر سعی کنی در کار به من نگاه کنی یا کاری خلاف انجام بدی، ازت کار برداشتم. فهمیدی؟"

    # say L35 pla
    old "(This is going to be harder than I thought.)"
    new "این خیلی سخت‌تر از آنچه فکر می‌کردم است."

    # say L37 pla
    old "Hey! I'm not a-"
    new "هی! من نه یک-"

    # say L39 mo2
    old "Shut up! Pervert!"
    new "بسته شو! خودکامه!"

    # say L41 pla
    old "...Ok. So, you are my boss now and I will respect you... Is that better?"
    new "...باشه. پس حالا تو رئیسم هستی و من بهت احترام می‌کنم... اینجوری بهتره؟"

    # say L43 mo2
    old "That's the respect you have to show me all the time, got it?. But enough talk, [pla]. Let's get to work!"
    new "این احترامی هست که همیشه باید به من نشون بدی، گرفتی؟ ولی خوب، ز[pla]. بیایید به کار بپردازیم!"

    # say L45 pla
    old "Nice. What do you need me to do?"
    new "خوب. من باید چه کاری بکنم؟"

    # say L47 mo2
    old "I need you to take these documents to my office and give them to the secretary. Then come back to me."
    new "من می‌خوام این اسناد رو به دفتر من ببری و به سرپرست بده. بعد برگشته بیا."

    # say L49 pla
    old "As you wish."
    new "همانطور که می‌خواهی."

    # say L64 pla
    old "Done! I already delivered the documents to Akita."
    new "انجام شد! قطعیت‌ها رو به آکیتا برسوندم."

    # say L66 mo2
    old "Well, was that very difficult?"
    new "خب، این کار خیلی سخت بود؟"

    # say L68 pla
    old "Hmm, not really..."
    new "Hmm، خیر، خیلی سخت نبود..."

    # say L70 mo2
    old "Alright. Look for me tomorrow to take a new delivery to Akita..."
    new "البته. فردا برای بردن تحویل جدید به آکیتا به من بگو..."

    # say L124 pla
    old "I must deliver the documents to Akita first."
    new "من باید اول اسناد رو به آکیتا ببرم."

    # say L131 mo2
    old "Are you ready to work today? I don't want any interruptions from you..."
    new "آماده هستی امروز کار کنی؟ نمی‌خوام ازت توقفی باشه..."

    # menu L134 
    old "Ready to work for you"
    new "آماده‌ام برای کار با شما"

    # say L138 mo2
    old "Ok then, You know what to do. Take these documents to my secretary, then come back to me..."
    new "البته، میدونی باید چی کنی. این اسناد رو به منشی من ببر، بعد برگرد به من..."

    # say L140 pla
    old "Of course, [mo2]!"
    new "البته، [mo2]!"

    # menu L150 
    old "Not now"
    new "البته، الان نه"

    # say L152 pla
    old "Actually, I have to do something first... I'll talk to you later."
    new "در واقع، اول باید کاری انجام بدم... بعداً با تو صحبت می‌کنم."

    # say L154 mo2
    old "Ugh. Ok, [pla]. Don't waste my time. Come talk to me when you're really ready"
    new "اوه. خب، ز[pla]. وقت من رو تلف نکن. وقتی واقعاً آماده شدی با من صحبت کن."

    # say L185 pla
    old "Uh... Nothing, I was just going to my bedroom, sorry."
    new "نه... هیچی، فقط می‌خواستم به اتاق خوابم برسم، معذرت."


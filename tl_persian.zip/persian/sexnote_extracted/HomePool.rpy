# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/HomePool.rpy
translate persian strings:

    # say L13 pla
    old "I should talk with Brixxida first."
    new "باید اول با بریکسیدا صحبت کنم."

    # say L37 pla
    old "No, no, sorry I was just walking around."
    new "نه، نه، معذرت، فقط داشتم پیاده می‌شدم."

    # say L55 ann
    old "[pla]... Are you trying to peek at me while I sunbathe?"
    new "[pla]... آیا داری می‌خواهی به من نگاه کنی هنگامی که خورشید می‌گیرم؟"

    # say L57 pla
    old "What? No, I wasn't-"
    new "نه، من نبودم-"

    # say L59 ann
    old "Uhm, you get very nervous, kid..."
    new "هم، تو خیلی ناراحت می‌شی، بچه..."

    # say L61 ann
    old "Is this what you want to see?"
    new "این همینه چیزی که می‌خوای ببینی؟"

    # say L66 ann
    old "Well, if that's what you want..."
    new "اگر این هست آنچه می‌خوای..."

    # say L68 ann
    old "Just don't bother me while I sunbathe, ok?"
    new "فقط وقتی خورشید می‌برم، مرا آزار نده، بله؟"

    # say L82 ann
    old "Didn't I tell you not to bother me? Don't keep bothering me."
    new "نمی‌گفتم که مرا آزار نده؟ نباید دیگر آزار دهی کنی."

    # say L84 pla
    old "Ok, sorry."
    new "باشه، معذرت."


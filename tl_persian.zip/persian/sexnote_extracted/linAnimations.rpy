# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/linAnimations.rpy
translate persian strings:

    # say L6 lin
    old "You're definitely very good at this, I can start to feel much more energy inside of me..."
    new "حتماً تو در این کار خیلی خوبی، می‌تونم انرژی بیشتری داخلم حس کنم..."

    # say L7 pla
    old "Hmm... T- Thanks."
    new "Hmm... ممنون."

    # say L11 lin
    old "Does it feels good, Huhh?"
    new "حالت خوبه، هه؟"

    # say L12 pla
    old "Y- yes... It feels great..."
    new "بله... خیلی خوبه..."

    # say L16 lin
    old "Come one, I want to suck every drop that comes out of you."
    new "بیا، من می‌خوام هر قطره‌ای که از تو بیرون می‌یاد رو جوشونم."

    # say L17 pla
    old "Oh God..."
    new "اوه خدا..."

    # say L41 lin
    old "Yes, yes! Give it to me!"
    new "بله، بله! به من بده!"

    # say L50 lin
    old "Alright, it's my time to ride you..."
    new "البته، الان وقت من برای سوار شدن تو روست..."

    # say L51 lin
    old "I want you to drill me, like you did with that girl."
    new "من می‌خوام تو مرا بزنی، مثل آن دختر."

    # say L67 lin
    old "Wow... You're so good at this."
    new "وای… تو توی این کار خیلی خوبی."

    # say L69 lin
    old "I love it! Don't stop... Don't Stop..."
    new "عشق کردم! متوقف نشو... متوقف نشو..."

    # say L73 lin
    old "Ahhh.... Ahhh...."
    new "اوه.... اوه...."

    # say L74 lin
    old "I can feel all your energy entering my body..."
    new "می‌تونم همه انرژیت رو توی بدنت حس کنم..."

    # say L79 lin
    old "Ahhhhh... I want more."
    new "اوه... می‌خوام بیشتر."

    # say L80 lin
    old "More give me more! Harder! HARDER!"
    new "بیشتر بده به من! سخت‌تر! سخت‌تر!"

    # say L104 lin
    old "Oh yeahh cum inside me! Give me all your load!"
    new "اوه بله هر جای تو رو توی من بده! همه آن رو به من بده!"

    # say L122 pla
    old "Wow... What are you doing? Why are you tying me up?"
    new "واو... تو چه کاری می‌کنی؟ چرا من رو بند می‌زنی؟"

    # say L123 lin
    old "I like to play a little while I share my energy with you."
    new "می‌پسوندم که هنگامی که انرژی‌هام با تو به اشتراک گذاشته می‌شه، یه بازی کوچیک باهام بزنی."

    # say L128 lin
    old "Ohhh, It's great to feel so much energy when I'm with you."
    new "اوه، خیلی خوب هست که وقتی با تو هستم اینقدر انرژی حس می‌کنم."

    # say L133 lin
    old "Yes! Yes! I can feel all your energy inside me!"
    new "بله! بله! من همه انرژیت رو داخلم می‌حسنم!"

    # say L134 lin
    old "Don't stop, don't stop!"
    new "توقف نکن، توقف نکن!"

    # say L162 lin
    old "Oh, that was fun, isn't?"
    new "اوه، این خوشحالم، نیست؟"


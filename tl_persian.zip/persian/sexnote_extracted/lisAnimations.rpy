# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/lisAnimations.rpy
translate persian strings:

    # say L6 lis
    old "Just relax and feel all my body, focus on the new sensations."
    new "هیچ نگرانی، فقط احساس تمام بدنم رو بکن، بر روی حس‌های جدید تمرکز کن."

    # say L10 lis
    old "Can you feel my breast over your back?"
    new "می‌تونی صدرم رو روی پشتت حس کنی؟"

    # say L11 pla
    old "Y- yeah..."
    new "ب-بله..."

    # say L15 lis
    old "I'm going to do it faster so you can feel more all my energy."
    new "من سریع‌تر می‌کنم تا بتوانی همه انرژی‌ام رو بیشتر حس کنی."

    # say L41 lis
    old "You are very connected with the moment and the environment, it means we can go beyond, you are ready for the next step."
    new "تو خیلی با لحظه و محیط همراهی می‌کنی، این به معنی اینه که می‌تونیم فراتر بریم، تو آماده‌ی مرحله‌ی بعدی هستی."

    # say L42 pla
    old "... Ok."
    new "... خوب."

    # say L47 lis
    old "Please lie down now on your back so we can expose the parts of your body that we need to balance the energy."
    new "لطفاً حالا روی پشت خودت بخوابی تا بخش‌هایی از بدنت که برای تعادل انرژی لازم هست، آشکار شوند."

    # say L50 lis
    old "We can heal your body together, we can heal each other, please follow my instructions so you can release all these negative experiences..."
    new "ما می‌توانیم بدن تو رو همراه هم درمان کنیم، می‌توانیم یکدیگر رو درمان کنیم، لطفاً دستورات من رو دنبال کن تا بتونی همه این تجربیات منفی رو آزاد کنی..."

    # say L51 lis
    old "Please lie down on your back, so we can take the negative energy out..."
    new "لطفاً روی پشت خود دراز کش، تا بتونیم این انرژی منفی رو ببریم بیرون..."

    # say L63 lis
    old "Ok, we are done now, let's do the next exercise..."
    new "خب، الان تمام شد، بیاییم تمرین بعدی رو انجام بدیم..."

    # say L73 lis
    old "Is it pleasant?"
    new "آیا خوشحالی؟"

    # say L74 pla
    old "Yes..."
    new "بله..."

    # say L78 lis
    old "Keep breathing, that is the key, your muscles must get extremely relaxed, my hands will clean the bad energies, let them do their job."
    new "ادامه دیشوند، این کلیده، عضلاتت باید خیلی آرام شن، دست‌هام انرژی‌های بد رو پاک می‌کنن، بهشون فرصت بده کارشون رو انجام بدند."

    # say L82 lis
    old "Please let yourself go, do not think about anything else, I will move faster so you can't release the tension, so you can let the chakra muladhara to be cleaned."
    new "لطفاً خودت رو بسپار، به هیچ چیز دیگه فکر نکن، من سریع‌تر حرکت می‌کنم تا تنش رو آزاد نکنی، تا چاکرا مولاذارا تمیز شه."

    # say L106 lis
    old "Do you feel the negative chakra leaving?"
    new "آیا احساس می‌کنی انرژی‌های منفی را ترک می‌کنند؟"

    # say L108 lis
    old "Let it out... Breath and let it out."
    new "بیرون بیا... نفس بکش و بیرون بیا."

    # say L113 pla
    old "Phew..."
    new "اف..."

    # say L114 lis
    old "Wow, that was wonderful, our job had abundant results."
    new "واو، این خیلی عالی بود، کار ما نتایج خوبی داشت."

    # say L129 lis
    old "Do you feel my boobs?"
    new "آیا احساس سینه‌های من می‌کنی؟"

    # say L133 lis
    old "Let it move... Feel me, I can see your body is doing it great..."
    new "برای جلو بیا... حس کن، می‌تونم ببینم بدنت خوب جاش رو انجام می‌ده..."

    # say L137 lis
    old "I can see it's hard to fight with your chakra muladhara but we can try harder than that, stay focused and just release the negative energy..."
    new "می‌تونم ببینم که با چاکرا ملادهارا مبارزت کردن خیلی سخته، اما می‌تونیم سعی کنیم سخت‌تر از این باشیم، تمرکز کن و فقط انرژی منفی رو رها کن..."

    # say L160 lis
    old "Yes, breath, and feel how your energy is moving...  I want you to let it go..."
    new "بله، نفس بکش و حس کن چطور انرژیت در حال حرکت است... من می‌خوام این انرژی رو رها کنی..."

    # say L166 lis
    old "Do you feel relieved?"
    new "آیا احساس راحتی می‌کنی؟"

    # say L168 lis
    old "Great, we will need to continue working on it but you are doing amazing."
    new "عالی، باید ادامه بدهیم ولی تو عالی کار می‌کنی."

    # say L233 lis
    old "Oh, yes... Just like that..."
    new "اوه، بله... همینطور..."

    # say L237 lis
    old "You really have a big cock... It feels... Good."
    new "تو واقعاً ناخن بزرگی داری... احساسش... خوبه."

    # say L241 lis
    old "Wow, uhhh, yes [pla] keep doing it..."
    new "واو، اوه، بله [pla] اینجوری هم بکن..."

    # say L264 pla
    old "Lisa, I'm goig to c- cum..."
    new "لیسا، من قراره خ- خروجی بدم..."

    # say L265 lis
    old "Oh, cum all over me."
    new "اوه، روی من خروجی بده."

    # say L289 lis
    old "Feel the fire of the universe with each kiss, you must know the universe is healing your body."
    new "با هر بوسه آتش جهان را حس کن، باید بدونی جهان بدن تو را در حال برتر کردن است."

    # say L290 pla
    old "Yeah, I can feel it."
    new "بله، من هم احساسش می‌کنم."

    # say L294 lis
    old "I will do it more intense so you feel the healing power of the universe at its fullest expression."
    new "من این رو شدید‌تر می‌کنم تا تو قدرت بخشایشی جهان رو به صورت کامل تجربه کنی."

    # say L298 lis
    old "I will take that energy out."
    new "من اون انرژی رو بیرون می‌برم."

    # say L321 pla
    old "I- I'm goin-"
    new "من- من در حال رفتن هستم"

    # say L322 lis
    old "Let it flow [pla], let it flow."
    new "بیا جریانش رو بده [pla]، بیا جریانش رو بده."

    # say L340 lis
    old "Oh [pla], what amazing energy you have."
    new "اوه ز[pla]، انرژی شگفت‌انگیزی داری."

    # say L344 lis
    old "Oh yes, I'm feeling the universe through you..."
    new "اوه بله، از طریق تو به کیهان متصل می‌شم..."

    # say L348 lis
    old "OH GOD, I NEED IT HARDER INSIDE OF ME!"
    new "اوه خدا، من نیاز دارم تو داخل من سخت‌تر باشی!"

    # say L371 lis
    old "Let all your energy cum inside me, I need to feel it."
    new "همه انرژیت رو داخل من بیا، نیاز دارم احساسش کنم."

    # say L391 mik
    old "Ohh man, look at that, this is so fucking hot!"
    new "اوه بابا، نگاه کن، این خیلی هیجان‌انگیزه!"

    # say L392 pla
    old "Hey, keep it down, they could hear you."
    new "هی، آرامش بده، می‌تونن بشنوند."

    # say L393 mik
    old "Alright, alright."
    new "باشه، باشه."

    # say L397 mik
    old "God damn it! This is getting me on!"
    new "لعنتی! این خیلی می‌کشه!"

    # say L398 pla
    old "Hey! Keep it down!"
    new "هی! آرامش بده!"

    # say L399 mik
    old "Listen, dude, do you think you could leave for a couple of minutes?"
    new "می‌شنو، دوست من، می‌تونی چند دقیقه بره؟"

    # say L400 pla
    old "What? Hell no! What the hell are you thinking?"
    new "چه؟ هیل نه! تو چه جوری فکر می‌کنی؟"

    # say L404 mik
    old "Oh they're going faster! This is fucking amazing."
    new "اوه آنها سریع‌تر می‌شوند! این واقعاً شگفت‌انگیزه."

    # say L405 pla
    old "I'm glad you like it man, but hey, we gotta go."
    new "خوشحالم که لذت می‌بری، ولی برو، باید بریم."

    # say L406 mik
    old "Ohhh no, please just a little more, I think they're about to finish."
    new "اوه نه، لطفاً فقط کمی بیشتر، فکر می‌کنم همین الان می‌خواهند تمام شوند."

    # say L407 pla
    old "Hmm, alright."
    new "Hmm، خوب."

    # say L430 mik
    old "Oh wow, that's the fucking best. I wasn't expecting that today."
    new "اوه وای، این بهترین چیزیه. امروز اصلاً انتظار نداشتم اینجوری باشه."

    # say L431 mik
    old "Thanks man."
    new "ممنون بابا."

    # say L432 pla
    old "No problem bro, but let's get out of here before they see us."
    new "هیچ اشکالی نداره برادر، ولی بیای بره قبل از اینکه ما رو ببینن."

    # say L444 lis
    old "Mmm, this is just what I needed."
    new "مم، این همینطوری که می‌خواستم."

    # say L448 pla
    old "{i}(What a weird position to do that.){/i}"
    new "{i}این وضعیت عجیبی برای این کاره.{/i}"

    # say L449 pla
    old "{i}(I guess it has to do with her whole yoga thing.){/i}"
    new "{i}(باید ارتباطش با یوگاش باشه.){/i}"

    # say L450 lis
    old "Oh yes! I can sense the energy moving!"
    new "اوه بله! من می‌تونم انرژی رو در حال جریان باشه حس کنم."

    # say L455 lis
    old "Oh! Oh, I can feel the energy flowing."
    new "اوه! اوه، من می‌تونم انرژی رو حس کنم."

    # say L457 lis
    old "Oh! Oh yeah!"
    new "اوه! اوه بله!"

    # say L481 lis
    old "Ah! Ah! That's right!"
    new "آه! آه! همینه!"

    # say L482 lis
    old "I can feel it! My Muladhara chakra is in full harmony!"
    new "احساسش می‌کنم! چاکرا مولادهارا من در هماهنگی کامل است!"

    # say L489 lis
    old "That was absolutely perfect!"
    new "این به طور کامل عالی بود!"

    # say L490 lis
    old "And just what I needed, what a wonderful thing."
    new "و همینطور، چیزی عالی برایم بود."

    # say L491 lis
    old "I can feel the energy flowing through my entire body."
    new "می‌تونم انرژی رو در تمام بدنم حس کنم."

    # say L492 lis
    old "I'm ready to continue my day now."
    new "الان آماده‌ام برای ادامه روزم."


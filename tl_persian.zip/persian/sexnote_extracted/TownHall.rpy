# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/TownHall.rpy
translate persian strings:

    # menu L10 
    old "Talk"
    new "صحبت"

    # say L11 sop
    old "Hello, Can I help you?"
    new "سلام، می‌تونم کمکت کنم؟"

    # say L12 pla
    old "Oh, no, sorry for bothering you."
    new "اوه، نه، معذرت برای آزاردهی تو."

    # say L37 sop
    old "Hmm, Can I help you?"
    new "Hmm، می‌تونم کمکت کنم؟"


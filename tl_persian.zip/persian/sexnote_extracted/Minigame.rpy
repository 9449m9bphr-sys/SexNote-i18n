# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mechanics/Minigame.rpy
translate persian strings:

    # narrator L270 
    old "Drag the documents that must be sent to the right destination, do it quickly to reach all the deliveries of the day."
    new "باید اسنادی که باید ارسال شوند رو به مقصد درست ببری، سریع کن تا همه ارسال‌های روزت تمام شود."

    # say L311 drag_name
    old "Town Hall"
    new "دفتر شهرداری"

    # narrator L396 
    old "To fix the roof you have to drag the tiles one by one to cover the damage."
    new "برای اصلاح سقف باید لوازم رو یکی یکی به جا ببری تا آسیب‌ها رو پوشش بده."

    # narrator L633 
    old "Open up the boxes two by two, and pair them up with the one equal to them."
    new "باکس‌ها رو دو تا دو تا باز کن و با همین برابرشون جفت بزن."

    # narrator L744 
    old "Try to select the profiles that are more akin to what Lydia wants. Swipe the correct ones right and the wrong ones left."
    new "سعی کن پروفایل‌هایی رو انتخاب کنی که بیشتر با تمایل لیدیا همخوانی دارن. پروفایل‌های درست رو به راست و غلط‌ها رو به چپ بکش."

    # narrator L746 
    old "Remember that these are some of the characteristics that Lydia doesn't like: white hair, red hair, old look and mustache."
    new "به خاطر داشت که این برخی از ویژگی‌هایی هستند که لیدیا نمی‌پسندد: موی سفید، موی قرمز، مظهر پیری و ریش."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/veeAnimations.rpy
translate persian strings:

    # say L6 vee
    old "Oh yeah! This is just magical!"
    new "اوه بله! این فقط جادوییه!"

    # say L7 vee
    old "I love that you're watching me, Daddy!"
    new "عشق دارم که تو به من نگاه می‌کنی، پاپا!"

    # say L8 vee
    old "I miss your dick so much!"
    new "من از دیکت تو خیلی می‌چرختم!"

    # say L12 vee
    old "Do you like to see me touching my pussy?"
    new "دaddy، دوست داری ببینی من لب‌هایم رو لمس می‌کنم؟"

    # say L13 vih
    old "Oh yeah baby! I love it!"
    new "اوه بله بیبی! عاشق اینم!"

    # say L14 vih
    old "I can't wait to fuck your pussy myself!"
    new "من نمی‌تونم منتظر بقای لمس پوسی تو باشم!"

    # say L18 vee
    old "Oh daddy! It feels as if you were here!"
    new "اوه پاپا! مثل اینه که تو اینجا هستی!"

    # say L19 vee
    old "I can't get enough of this!"
    new "نمی‌تونم از این خودمو بردارم!"

    # say L20 vee
    old "I want more and more!"
    new "بیشتر و بیشتر می‌خوام!"

    # say L43 vee
    old "I- I'm about to cum honey!"
    new "من- من هم خیلی زود می‌آیم عزیزم!"

    # say L44 vih
    old "Do it! I'm about to cum too!"
    new "بزن! من هم خیلی زود می‌آیم!"

    # say L45 vee
    old "Oh yeah! Let's do it together!"
    new "اوه بله! بیایم هم‌هم!"

    # say L52 vee
    old "Oh that was magical honey."
    new "اوه آن جادویی بود عزیزم."

    # say L53 vee
    old "I can't wait to see you again to feel you inside me."
    new "نمی‌تونم صبر کنم دوباره تو رو ببینم و احساست رو درونم بکنم."

    # say L54 vih
    old "Oh yeah, I can't wait to fuck you too."
    new "اوه بله، من هم نمی‌تونم صبر کنم تا تو رو بپوشم."

    # say L56 vee
    old "{i}(I- is that [pla]? What's he doing there?!!){/i}"
    new "{i}(اوه- این جون ز[pla]؟ اونجا چی کار می‌کنه؟!!){/i}"

    # say L57 vih
    old "Is everything alright? You just got quiet all of a sudden."
    new "همه چیز خوبه؟ چرا ناگهان ساکت شدی؟"

    # say L58 vee
    old "What?! Oh yeah!"
    new "چه؟! اوه آره!"

    # say L59 vee
    old "It's just that I think I heard some steps in the hallway."
    new "فقط اینجاست که فکر کردم صدای قدم در راهرو شنیدم."

    # say L60 vee
    old "Maybe we should end the call here honey, in case one of the girls comes in."
    new "شاید باید اینجا تماس رو قطع کنیم عزیزم، تا احتمال ورود یکی از دختران رو نداشته باشیم."

    # say L61 vih
    old "Hmph, yeah you're right."
    new "همف، بله درست می‌گی."

    # say L62 vih
    old "Talk to you later then."
    new "بعداً صحبت می‌کنیم"

    # say L63 vee
    old "Bye honey, I love you."
    new "بای عزیزم، منت دوست دارم."

    # say L64 vee
    old "Hey, you! I already saw you there peeping, come in here and close the door behind you!"
    new "اوه، تو! قبلاً دیدم که اینجا پنهانی بودی، بیا داخل بیا و در رو ببند."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/hinAnimations.rpy
translate persian strings:

    # say L6 joh
    old "Little by little, you start to increase the speed..."
    new "تدریجاً سرعت رو افزایش می‌دی..."

    # say L13 joh
    old "You can feel his body start to tense, warm up, that means he's close..."
    new "می‌تونی احساس بدنش کنی که شروع به تنیدن و گرم شدن می‌کنه، این به معنی اینه که او نزدیکه..."

    # say L38 joh
    old "Ready for the shot?"
    new "آماده‌ای برای شوت؟"

    # say L39 hin
    old "For what?"
    new "برای چه؟"

    # say L44 joh
    old "Wow! (Mmm)"
    new "واو! (مم)"

    # say L45 joh
    old "That's it! Did you like [pla]?"
    new "این هستش! از [pla] لذت برده‌ای؟"

    # say L47 joh
    old "Haha. And what about you, Hinn? How was it for you?"
    new "هahaha. و تو، هین؟ برایت چطور بود؟"

    # say L62 pla
    old "It was great."
    new "عالی بود."

    # say L104 joh
    old "Wow, I wasn't expecting it... That was a lot."
    new "واو، این را منتظر نبودم... این خیلی بود."

    # say L110 joh
    old "A lot of cum as always, yummy"
    new "هر همیشه همین مقدار سپری، لذت‌بخش."

    # say L120 joh
    old "Go slowly increasing speed with me."
    new "با من آرام‌آرام سرعت رو افزایش بده."

    # say L124 joh
    old "How does it feel [pla]?"
    new "حاسه‌ای چطور است [pla]؟"

    # say L125 pla
    old "It... feels, very good..."
    new "این... خیلی خوب است..."

    # say L129 joh
    old "How about if we make him cum Hinn?"
    new "آیا بیاییم هین را به اوج برده کنیم؟"

    # say L130 hin
    old "(Oh My... Yes!)"
    new "اوه خدا... بله!"

    # say L154 pla
    old "I- I'm going to..."
    new "من- من می‌خوام..."

    # say L155 joh
    old "Yes [pla], give us everything."
    new "بله [pla]، همه‌چیز را به ما بده."

    # say L163 joh
    old "Nice!"
    new "عالی!"

    # say L164 joh
    old "And it's still hard... Beautiful youth, I think we can continue with the next practice, what do you say Hinn?"
    new "و هنوز سخت است... جوان زیبا، فکر کنم می‌توانیم به تمرین بعدی ادامه بدیم، چطور می‌گیه Hinn؟"

    # say L174 joh
    old "Well, you already saw me do it, in the last session, so it's your turn."
    new "خب، قبلاً دیدی من این کار رو انجام دادم، در جلسه قبل، پس الان باید تو انجام بدی."

    # say L176 joh
    old "Don't worry I will help you."
    new "نگران نباش، من کمکت می‌کنم."

    # say L178 joh
    old "Remember to brush your hair very well and be careful with your teeth, ok?"
    new "به خوبی مویت رو برش نده و دندنتون با دقت پاک کن، خب؟"

    # say L182 joh
    old "Very well, go ahead you can do a little more..."
    new "خوب، برو ادامه بده، می‌تونی کمی بیشتر هم کنی..."

    # say L187 joh
    old "You feel it in your throat right? Well now take it out slowly."
    new "آیا اونو تو خورت حس می‌کنی؟ خب حالا آرام آرام بیرون بیاور."

    # say L196 joh
    old "Great! Now keep doing it."
    new "عالی! حالا ادامه بده."

    # say L202 joh
    old "All right honey, you're doing great."
    new "بفرمایید عزیزم، خوب انجام می‌دی."

    # say L204 pla
    old "Uh... It feels very... good."
    new "اوه... احساسش خیلی... خوبه."

    # say L212 pla
    old "I going to..."
    new "من قراره..."

    # say L222 joh
    old "And it's still hard... You know what to do Hinn... It's time to deepthroat!"
    new "و هنوز سخته... میدونی چی کار کنی هین... الان وقت آن است که عمیق‌تر بکشی!"

    # say L243 joh
    old "All right, how about we do it a little faster?"
    new "باشه، بیاین یه کم سریع‌تر انجام بدیم."

    # say L251 joh
    old "You have to learn to read your partner's expressions."
    new "باید بیاموزی تا عبارات همسرانت رو بخوانی."

    # say L252 joh
    old "Look how he starts to tense his legs, that means he is enjoying it, so, we have to do it a little faster."
    new "ببین چطور او شروع می‌کنه لگن‌اش رو تنیده، این به معنای اینه که لذت می‌بره، پس باید کمی سریع‌تر انجام بدیم."

    # say L276 joh
    old "All right, are you ready for the shot? Get it in your mouth, so, you don't make a mess here."
    new "باشه، آماده‌ای برای تزریق؟ تو دهنت بگیر، تا اینجا درگیر نشه."

    # say L277 hin
    old "What?"
    new "چه؟"

    # say L282 joh
    old "Great Hinn!"
    new "عالی هین!"

    # say L283 joh
    old "You did very well, right [pla]?"
    new "خوب کار کردی، درسته [pla]؟"

    # say L284 pla
    old "Uh?... Sorry what?"
    new "آه؟... معذرت چی؟"

    # say L285 joh
    old "Hahaha, let's let [pla] to recover while I help you clean up in the bathroom."
    new "حاحاحا، بیایید [pla] را بازیابی کند در حالی که من به شما کمک می‌کنم تا در حمام تمیز کنیم."

    # say L291 hin
    old "Of course."
    new "البته."

    # say L296 joh
    old "All right, Hinn!"
    new "باشه، هین!"

    # say L298 pla
    old "She did it awesome!"
    new "او خیلی خوب انجامش داد!"

    # say L299 joh
    old "Hahaha, you are improving Hinn."
    new "هahaha، شما در حال بهبود هستید، هین."

    # say L308 joh
    old "Wow, it looks like someone was practicing the lessons at home."
    new "به نظر می‌رسه کسی در خونه تمرین کرده."

    # say L312 joh
    old "All right, let's go a little faster."
    new "باشه، بیایید یک کم سریع‌تر برویم."

    # say L340 pla
    old "Girls, I think I'm going to..."
    new "دختران، فکر کنم من باید..."

    # say L358 joh
    old "Well, it's time to fuck!"
    new "خب، وقت آن رسیده که بزنیم!"

    # say L366 joh
    old "Let me lubricate it well before I start."
    new "بگذار قبل از شروع خوب آماده کنم."

    # say L413 joh
    old "Well I think that's enough, now you're going to penetrate Hinn..."
    new "خب فکر کنم کافیه، حالا شما باید هین را نفوذ کنید..."

    # say L414 pla
    old "Wow... Ok."
    new "واو... خب."

    # say L415 joh
    old "Slowly and carefully..."
    new "آرام و با دقت..."

    # say L421 joh
    old "Hinn you're going to enjoy the wonder of being a woman."
    new "هین، شما خوشحالم از شگفت‌انگیز بودن زن بودن تجربه خواهید کرد."

    # say L425 joh
    old "Ready for that big cock Hinn?"
    new "آماده‌ای برای آن نیم‌تنه بزرگ هین؟"

    # say L439 joh
    old "All right [pla], now let's go a little faster."
    new "باشه [pla]، حالا یه کم سریع‌تر برویم."

    # say L443 joh
    old "How you feeling Hinn?"
    new "حالت چطوره هین؟"

    # say L444 hin
    old "Oh... It feels.... Aghh... Aghhh..."
    new "اوه... احساس می‌کنم.... آه... آاه..."

    # say L445 joh
    old "That's what I thought..."
    new "این همینه که فکر می‌کردم..."

    # say L449 joh
    old "Fuck her harder, make her cum with you!"
    new "بیا، بیشتر باهاش بکن، با تو خودش برسه!"

    # say L472 joh
    old "Get it out, get it out, come in my mouth!"
    new "بیرون بیا، بیرون بیا، تو دهان من بیا!"

    # say L478 joh
    old "Ohh yeah, yummy...."
    new "اوه بله، لذت‌بخش..."

    # say L502 joh
    old "He is going to cum..."
    new "او قراره خروج کند..."

    # say L503 hin
    old "Then, let's do it faster..."
    new "پس بیاییم سریع‌تر انجام بدیم..."

    # say L504 joh
    old "Good girl."
    new "خوب، دختر خوب."

    # say L536 joh
    old "All right is time to fuck!"
    new "البته، الان وقت آن است که با هم بفرماییم!"

    # say L604 joh
    old "Very well [pla], you already know what to do..."
    new "خوب زن [pla]، تو قبلاً می‌دونی باید چی کنی..."

    # say L615 joh
    old "Do you like this [pla]? Do you like my tits on your face?"
    new "آیا اینو دوست داری [pla]؟ آیا دوست داری سینام رو روی چهرت بیاندازم؟"

    # say L616 pla
    old "(Hell yeah!)"
    new "بله، خیلی می‌پسندم!"

    # say L620 joh
    old "Yeah! yeah! Let's fuck Hinn harder!"
    new "بله! بله! بیایید هین رو سخت‌تر بفراموش کنیم!"

    # say L624 joh
    old "Are you enjoying it Hinn? Yes? Do you like [pla]'s cock?"
    new "آیا لذت می‌بری هین؟ بله؟ آیا از زنگ زدن [pla] لذت می‌بری؟"

    # say L625 hin
    old "Oh, yess... Aghhh... Aghhh..."
    new "اوه، بله... آه... آه..."

    # say L648 joh
    old "Are you going to cum [pla]? Oh yeah? Cum inside her..."
    new "آیا قراره بیایی [pla]؟ اوه بله؟ داخلش بیا..."

    # say L649 pla
    old "Ohh! Fuck yeahh..."
    new "اوه! خوب هست..."

    # say L655 joh
    old "Delicious!"
    new "لذت‌بخش!"

    # say L670 joh
    old "You are doing it great!"
    new "عالی می‌کنی، برو به جلو!"

    # say L671 joh
    old "Speed it up a little."
    new "می‌تونی یه کم سرعتش رو افزایش بدی؟"

    # say L675 joh
    old "Look at her [pla], she is enjoying your cock."
    new "نگاه کن به [pla] او، از لولت لذت می‌بره."

    # say L679 joh
    old "Are you cumming hin?"
    new "آیا تو در حال لذت بردن هستی؟"

    # say L680 hin
    old "Oh please, don't stop, do it faster! I'm going to cum!"
    new "لطفاً متوقف نشو، سریع‌تر انجام بده! من در حال رسیدن هستم!"

    # say L707 hin
    old "Wow... That was awesome..."
    new "واو... این خیلی عالی بود..."

    # say L714 joh
    old "Ohh, I think it's the perfect opportunity, for the last lesson."
    new "اوه، فکر کنم این فرصت مناسب برای آخرین درس است."

    # say L715 joh
    old "Get a good facial..."
    new "بیا، بگیر یک پوشش خوب..."

    # say L718 joh
    old "Now let's ger a good facial Hinn."
    new "الان بیایید یک پوشش خوب روی صورت بگیریم هین."

    # say L732 joh
    old "Look at her eyes [pla], she wants all your cum."
    new "نگاه کن به چشمش [pla]، می‌خواد تمام سپرمتو بگیره."

    # say L736 joh
    old "Does it feel good? Do you want to cum on that pretty face?"
    new "آیا خوب است؟ آیا می‌خواهی روی اون چهره زیبا خودت رو بی‌آفرینی؟"

    # say L740 joh
    old "Get ready for the shot honey, he is ready."
    new "آماده شو عزیزم، او آماده است."

    # say L763 joh
    old "Give it to her! Cum on Hinn face!"
    new "به او بده! روی چهره‌ی هین بیا!"

    # say L771 joh
    old "Ohh yes... Delicious..."
    new "اوه بله... لذت‌بخش..."

    # say L817 pla
    old "Wow Hinn, I'm going to..."
    new "واو هین، من قراره..."

    # say L822 pla
    old "Wow, that was awesome..."
    new "واو، این خیلی عالی بود..."

    # say L823 hin
    old "I didn't say it's over. You just enjoy..."
    new "من نگفتم تمام شده. فقط لذت ببر..."

    # say L826 pla
    old "... WOW!"
    new "... وای!"

    # say L864 pla
    old "Hinn, again I'm going to..."
    new "هین، دوباره من قراره..."

    # say L865 pla
    old "Aghhh..."
    new "اوه..."

    # say L872 hin
    old "That was fun..."
    new "این جالب بود."

    # say L873 pla
    old "That... Was... Surprising."
    new "این... مفاجا بود."

    # say L880 pla
    old "That was great."
    new "عالی بود."

    # say L889 hin
    old "It has a very nice smell."
    new "این رایحه خیلی خوبی داره."

    # say L890 hin
    old "Mmm, [pla] I really like your penis, it's soo nice."
    new "ممن، ز[pla] خیلی دوست دارم این نوزک تو رو، خیلی خوبه."

    # say L892 hin
    old "Just relax, I'll make you feel good."
    new "هین: آرام باش، من احساس خوبی برایت می‌سازم."

    # say L896 hin
    old "Slurrp, Yes, I see you like that."
    new "سلورپ، بله، می‌بینم خوشت می‌آید."

    # say L897 hin
    old "I love the taste of you dick! I love how it feels in my mouth!"
    new "عشق دارم به طعم ناخودت! عشق دارم که چطور تو رو در دهانت احساس می‌کنم!"

    # say L898 hin
    old "I'll do it a little bit faster."
    new "من این رو یه کم سریع‌تر می‌کنم."

    # say L903 bel
    old "(Hmm, they look like they're having fun. I better leave, I don't want them to know I saw them.)"
    new "Hmm، به نظر می‌رسه لذت می‌برن. بهتره برم، نمی‌خوام بدونن که دیدم."

    # say L905 bel
    old "For now..."
    new "برای حالا..."

    # say L913 hin
    old "Uhhh, I can feel how your body tense up!"
    new "اوه، می‌تونم احساس تنشوندگی بدن تو رو بکنم!"

    # say L914 pla
    old "H- Hinn. Mmm!"
    new "ه- هین. مم!"

    # say L915 hin
    old "Mmmm! Yes, Yes!"
    new "ممنن! آره، آره!"

    # say L938 pla
    old "H-Hinn, I c- can't hold back anymore."
    new "ه- هین، نمی‌تونم دیگه تحمل کنم."

    # say L939 hin
    old "F- Finish, cum in my mouth!"
    new "F- تمام شو، در دهانم بیا!"

    # say L940 hin
    old "I want you to!"
    new "من می‌خوام تو!"

    # say L941 pla
    old "Ughh, Y- YES!"
    new "اوه، بله!"

    # say L946 hin
    old "Phew! That was great. Did you like it [pla]?"
    new "پوف! این خیلی خوب بود. لذت برده بودی [pla]؟"

    # say L947 pla
    old "Y- yeah, I did, thank you Hinn."
    new "ب- بله، لذت بردم، ممنون هین."

    # say L948 hin
    old "Well, I'm glad you enjoyed it."
    new "البته خوشحالم که لذت برده‌ای."

    # say L949 hin
    old "Although now I'm covered with cum."
    new "البته حالا من پوشیده اسپرم شدم."

    # say L950 pla
    old "Sorry about that."
    new "متاسفم از این."

    # say L951 hin
    old "It's ok, I wanted to do that with you. Besides, we're in the bathroom."
    new "خوبه، من هم می‌خواستم اینجوری با تو باشم. بعلاوه، ما توی حمام هستیم."

    # say L952 hin
    old "Help me clean up."
    new "کمک کن به من تمیز شوم."

    # say L1070 hin
    old "Mmm! It's been a while..."
    new "ممنون! این طول مدت بود..."

    # say L1071 hin
    old "Ah! Oh yes! I've missed this..."
    new "آه! اوه بله! این رو خیلی دوست داشتم..."

    # say L1072 pla
    old "Ohh God!"
    new "اوه خداوند!"

    # say L1073 hin
    old "Ahh! It's so big! and It feels so good!"
    new "اوه! اینقدر بزرگه! و احساسش خیلی خوبه!"

    # say L1077 hin
    old "Ah! Ah! I love to feel you inside [pla]!"
    new "آه! آه! من عاشق احساس تو درون من هستم [pla]!"

    # say L1078 hin
    old "Y- your cock is just the best!"
    new "Y- نه، فقط پیپت تون بهترین هست!"

    # say L1080 hin
    old "I- I just love to have sex with you!"
    new "من- من فقط دوست دارم با تو جنس کنم!"

    # say L1084 hin
    old "AHH! AHH! YES! YES!"
    new "اوه! اوه! بله! بله!"

    # say L1085 hin
    old "I love the way you always make me feel!"
    new "من عاشق همین حسی هستم که تو همیشه برایم ایجاد می‌کنی!"

    # say L1086 hin
    old "I LOVE IT!"
    new "من عاشق این هستم!"

    # say L1087 hin
    old "I want to keep doing it with you!"
    new "من می‌خوام با تو ادامه بدم!"

    # say L1110 pla
    old "H- Hinn! I- I think I'm about to...!"
    new "ه- هین! من- من فکر کنم خیلی زود...!"

    # say L1111 hin
    old "Ohh, yes yes!"
    new "اوه، بله بله!"

    # say L1112 hin
    old "I want you to cum inside me!"
    new "من می‌خوام تو داخل من بیای."

    # say L1119 hin
    old "Wow... That felt great."
    new "واو... این خیلی خوب بود."

    # say L1120 hin
    old "Did you enjoy it too [pla]?"
    new "آفرین، تو هم لذت برده بودی [pla]؟"

    # say L1121 pla
    old "O- of course, it was really good."
    new "بله، خیلی خوب بود."

    # say L1130 jad
    old "What the hell is this?!!!"
    new "این چی هست؟!!!"

    # say L1131 jad
    old "Hinn! [pla]! What do you think you're doing?!"
    new "هین! [pla]! تو فکر می‌کنی چیکار می‌کنی؟!"

    # say L1141 hin
    old "Mmm! I just love the way your cock tastes."
    new "ممنون! من فقط عاشق طعم ناخن تو هستم."

    # say L1142 hin
    old "It really is great. I can't get over it."
    new "واقعاً عالیه. نمی‌تونم ازش خارج بشه."

    # say L1143 hin
    old "I love how it fills my mouth!"
    new "عشق‌من داره دهانم رو پر می‌کنه!"

    # say L1147 hin
    old "Are you enjoying it [pla]?"
    new "آیا لذت می‌بری [pla]؟"

    # say L1148 pla
    old "Ugh! Y- yes!"
    new "اوه! بله!"

    # say L1149 hin
    old "M- me too! I love your cock!"
    new "M- من هم! لولت رو دوست دارم!"

    # say L1150 hin
    old "I- it's so hot!"
    new "ا- اونقدر داغه!"

    # say L1158 jad
    old "Honestly, I swear I don't understand what's going on in that girl's head sometimes."
    new "Honestly، قسمت می‌خورم که گاهی اوقات نمی‌فهمم تو ذهن اون دختر چه چیزی می‌افتد."

    # say L1159 jad
    old "Where did she take off too? They're not in her room."
    new "اونجا کجا رفت؟ تو اتاقش هم نیستند."

    # say L1160 jad
    old "And would you look at that? She left the bathroom light on!"
    new "و ببین! نور توالت رو روشن گذاشته!"

    # say L1161 jad
    old "I swear to God..."
    new "بی‌خدا..."

    # say L1167 jad
    old "(Oh my God! What are they doing?! Again?!)"
    new "اوه خدا! اونا دوباره چی می‌کنن؟!"

    # say L1168 jad
    old "(And in the bathroom of all places! These kids don't understand what shame is!)"
    new "(و هم اینکه در حمام! این بچه‌ها نمی‌فهمن خجولی چیه!)"

    # say L1172 jad
    old "(And [pla]! My God! He's really big!)"
    new "و ز[pla]! خدا مرا! واقعاً بزرگه!"

    # say L1173 jad
    old "(I can't believe that young man is like that.... Amazing.)"
    new "نمی‌تونم باور کنم آن جوان همینجوریه... شگفت‌انگیز."

    # say L1174 jad
    old "(I- is Hinn really putting all that in her mouth?)"
    new "(آ- آیا هین واقعاً همه اونو توی دهانش می‌گذونه؟)"

    # say L1175 jad
    old "(I- I can't believe it.)"
    new "باورم نمی‌شه."

    # say L1182 hin
    old "Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"
    new "سللللپ! ممم! ب- بله! من- من عاشق ناخن تو هستم!"

    # say L1183 hin
    old "I- it barely fits in my mouth!"
    new "I- یه جایی که همین جا نمی‌تونه وارد شه!"

    # say L1184 hin
    old "It's so amazing!"
    new "این خیلی شگفت‌انگیزه!"

    # say L1185 jad
    old "(S- she's actually putting all of it in her mouth!)"
    new "(وای، واقعاً همه‌اش رو توی دهانش می‌گذونه!)"

    # say L1186 jad
    old "(I can't believe what I'm seeing!)"
    new "(نمی‌تونم باور کنم چی می‌بینم!)"

    # say L1187 jad
    old "(H- he's not going to cum in her mouth, right?)"
    new "(ح- حتماً نمی‌تونه تو دهانش بیاد، درسته؟)"

    # say L1210 pla
    old "H- Hinn... I- I think I'm about to!"
    new "ه- هین... من- من فکر کنم قراره بیوفتم!"

    # say L1211 hin
    old "YES! CUM IN MY MOUTH!"
    new "بله! توی دهانم بیا!"

    # say L1212 jad
    old "(I can't believe Hinn is saying that kind of stuff!)"
    new "نمی‌تونم باور کنم هین اون جور چیزها رو می‌گه!"

    # say L1213 jad
    old "(I- is he going to do it?)"
    new "(آیا- او این کار رو می‌کنه؟)"

    # say L1219 jad
    old "(My God, kids these days, honestly...)"
    new "خداوند، بچه‌های امروز، صادقانه..."

    # say L1220 jad
    old "(And they even say they're not a couple.)"
    new "و حتی می‌گن هم نیستن."

    # say L1221 jad
    old "(I guess this is alright. I won't say anything for now, but Hinn really needs to learn to do it in her bedroom.)"
    new "باید اینجوری باشه. حالا هیچی نمی‌گم، ولی هین واقعاً باید بیاموزه که این کار رو تو اتاق خوابش بکنه."

    # say L1233 hin
    old "Hngh!! Oh yes!"
    new "هانگ!! اوه بله!"

    # say L1234 hin
    old "That's what I've been waiting for!"
    new "این همینه که منتظرش بودم!"

    # say L1235 hin
    old "I just love how you fill me up!"
    new "من فقط دوست دارم که تو من رو پر کنی!"

    # say L1236 hin
    old "Oh! [pla]! Your cock is so big!"
    new "اوه! [pla]! ناخن تو خیلی بزرگه!"

    # say L1240 hin
    old "Are you enjoying it?"
    new "آیا لذت می‌بری؟"

    # say L1241 pla
    old "Mmm, y- yes!"
    new "ممنون، هن! بله، لذت می‌برم."

    # say L1242 hin
    old "I- I'm loving it!"
    new "من- من خیلی لذت می‌برم!"

    # say L1247 jad
    old "Uhh... What is that noise?"
    new "اوه... اون صدایی چیه؟"

    # say L1250 jad
    old "(I can't believe they're doing it again!)"
    new "باورم نمی‌شه دوباره هم این کار رو می‌کنن!"

    # say L1252 jad
    old "(But well, at least they're doing it privately.)"
    new "البته، حداقل این بار خصوصی هستند."

    # say L1253 jad
    old "Oh, my God! I- I can't help myself..."
    new "اوه، خداوند! من- من نمی‌توانم خودمو کنترل کنم..."

    # say L1260 hin
    old "D- do it faster [pla]!"
    new "D- سریع‌تر بکن [pla]!"

    # say L1263 jad
    old "(H- he's so big! I- I wonder how it must feel to be penetrated by him...)"
    new "اوه، اونقدر بزرگه! نمی‌دونم احساسش چطوره که توسطش نفوذ شدن..."

    # say L1265 hin
    old "AH! AH! AH! YES! YES!"
    new "آه! آه! آه! بله! بله!"

    # say L1266 hin
    old "I've been missing this so much!"
    new "این رو خیلی می‌خواستم!"

    # say L1267 jad
    old "(Mmmm, and she's taking all of it!)"
    new "ممنون، هر چیزی رو می‌گیری!"

    # say L1268 hin
    old "I love how you fuck me!"
    new "عشق دارم که چطور منو می‌بازی!"

    # say L1301 jad
    old "(H- he won't cum inside of her... Will he?)"
    new "Jad: (H- او داخلش نمی‌آید... نه؟)"

    # say L1302 hin
    old "I- I want you to cum inside!"
    new "من- من می‌خوام تو داخل من بیایی!"

    # say L1303 hin
    old "Let me get it all!"
    new "بگذار همه‌ش رو بگیرم!"

    # say L1304 pla
    old "Y- yes! I- I'm about to...!"
    new "بله! من همین الان در حال...!"

    # say L1310 jad
    old "(God! I can't believe I just watched them have sex!)"
    new "(خدا! نمی‌تونم باور کنم فقط داشتم به این همه چیز نگاه می‌کردم!)"

    # say L1311 jad
    old "(But this time they did it in Hinn's bedroom, I'm the one who shouldn't be here spying on them.)"
    new "(ولی این بارشون تو اتاق خواب هین انجام دادن، من هستم که نباید اینجا باشم و بهشون نگاه می‌کنم.)"

    # say L1316 hin
    old "That was so good [pla]."
    new "این هم خوب بود [pla]."

    # say L1317 hin
    old "It felt like an eternity since the last time we did it."
    new "این مثل این بود که از آخر باری که این کار رو انجام دادیم طول زیادی گذشته."

    # say L1318 pla
    old "Yeah..."
    new "بله..."

    # say L1319 hin
    old "By the way, it's getting kinda late, I guess my mom will be here any minute."
    new "البته، وقت خیلی دیر شده، احتمالاً مامان هم هر لحظه می‌تونه بیاد."

    # say L1320 pla
    old "You're right! I guess we better get dressed soon!"
    new "حق با توست! به نظر می‌رسه باید زودتر لباسمون رو بپوشیم."

    # say L1321 jad
    old "(I should leave before they find out I'm here.)"
    new "باید قبل از اینکه متوجه شدن من اینجا هستم برم."

    # say L1326 jad
    old "Oh God, what is happening to me?"
    new "اوه خدا، اینجوری به من چه اتفاقی می‌افته؟"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Church.rpy
translate persian strings:

    # say L44 pla
    old "She is praying, I shouldn't bother her."
    new "او در حال نماز است، نباید او را آزار دهم."

    # say L58 jon
    old "Oh, hi young man, are you the one who accompanied Lydia a few days ago?"
    new "اوه، سلام جوان، آیا شما همان نفری هستید که چند روز پیش با لیدیا همراه بودید؟"

    # say L60 pla
    old "Yes Mrs. Jones, my name is [pla], nice to meet you."
    new "بله خانم جونز، نامم [pla] هست، خوشحالم از آشنایی شما."

    # say L62 jon
    old "Excellent [pla], I think it's very good that you visit the church."
    new "عالی است ز[pla]، فکر می‌کنم خیلی خوب هست که به کلیسا می‌آیید."

    # say L64 jon
    old "Many young people should be like you."
    new "بسیاری از جوانان باید مثل شما باشند."

    # say L66 pla
    old "Oh no, I just-"
    new "نه، من فقط-"

    # say L68 jon
    old "Today all young people think about is sex, parties and devil things."
    new "امروز همه جوان‌ها فقط به سکس، مهمانی‌ها و چیزهای شیطونی فکر می‌کنند."

    # say L70 jon
    old "Did you know that sister Grace is organizing the church choir?"
    new "آیا می‌دونی خواهر گریس داره گروه خوانندگان کلیسا رو سازمان میده؟"

    # say L72 jon
    old "If you want I could introduce you, so you could continue on your way to the Lord."
    new "اگر می‌خوای می‌تونم تو رو بهش ببرم، تا راهت به خدا ادامه پیدا کنی."

    # say L74 pla
    old "Well, actually-"
    new "خب، در واقع-"

    # say L76 jon
    old "Perfect! I'll talk to sister Grace, she'll be very happy."
    new "عالی! با خواهر گریس صحبت می‌کنم، او خوشحال می‌شه."

    # say L78 pla
    old "Ok ..."
    new "باشه..."

    # say L90 jon
    old "Oh, hi [pla], how are you doing."
    new "اوه، سلام ز[pla]، حالت چطوره؟"

    # say L91 pla
    old "Hi, Mrs. Jones, I'm great thanks, what about you?"
    new "سلام خانم جونز، من خوبم ممنون، شما چطورید؟"

    # say L92 jon
    old "I'm fine, waiting for the next mass."
    new "من خوبم، منتظر مراسم بعدی هستم."

    # say L93 jon
    old "Do you need something hun?"
    new "خانم، چیزی می‌خوای؟"

    # say L117 jon
    old "Honey?"
    new "حبیب؟"

    # menu L119 
    old "Not now."
    new "الان نه."

    # say L122 pla
    old "Oh no, don't worry, I just wanted to say hi."
    new "اوه نه، نگران نباش، فقط می‌خواستم سلام بزنم."

    # say L123 jon
    old "Alright, thank you hun, see you later."
    new "البته، ممنونم عزیزم، باید برو. بعداً می‌بینیم."

    # say L124 pla
    old "Bye, Mrs. Jones."
    new "بای، خانم جونز."

    # say L181 pla
    old "(Wow!)"
    new "واو!"

    # say L182 pla
    old "(Sister Grace is really attractive...)"
    new "خواهر گریس واقعاً جذابه..."

    # say L183 pla
    old "(Should I use the Agamoto eye?)"
    new "باید از چشم‌های آگاموتو استفاده کنم؟"

    # menu L185 
    old "Yes"
    new "بله"

    # say L188 pla
    old "(Oh my...)"
    new "اوه خدا..."

    # menu L190 
    old "No"
    new "خیر"

    # say L193 pla
    old "(I better get back to work.)"
    new "بهتره برم کارمو ادامه بدم."

    # say L203 pla
    old "(Mrs. Jones's skirt went up quite a bit...)"
    new "(پوست مادام جونز خیلی بالا رفت...)"

    # say L221 gra
    old "Wow! I knew you would have been fast but I didn't expect that much."
    new "واو! می‌دونستم سریع هستی، ولی اینقدر نمی‌تونستم بگم."

    # say L222 pla
    old "Haha, thanks Sister Grace... I like to do things as fast as possible."
    new "هه، ممنون خواهر گریس... من دوست دارم همه چی رو به سرعت انجام بدم."

    # say L223 jon
    old "I wonder if you're that good at everything... Great job!"
    new "می‌خواهم ببینم آیا تو در همه چیز هم اینقدر خوبی... کار عالی کردی!"

    # say L224 jon
    old "Anyway, it's already very late, and I think we should all rest now, see you again tomorrow."
    new "البته، الان خیلی دیره و فکر می‌کنم همه ما باید حالا استراحت کنیم، دوباره به یادت باشیم."

    # say L225 gra
    old "Thank you, so much for your help Mrs. Jones and [pla]."
    new "ممنون از همکاری شما خانم جونز و [pla]."

    # say L226 pla
    old "Alright, see you tomorrow."
    new "باشه، دوباره به یادت باشیم فردا."

    # say L240 gra
    old "Oh, it's too late and we can't finish cleaning."
    new "اوه، الان خیلی دیره و نمی‌تونیم تمیزکاری رو تمام کنیم."

    # say L241 jon
    old "Well, today was a bit harder than usual..."
    new "خب، امروز کمی سخت‌تر از معمول بود..."

    # say L242 pla
    old "Don't worry, I can stay and finish the cleaning."
    new "نگران نباش، می‌تونم بمونم و تمیزکاری رو تمام کنم."

    # say L243 jon
    old "Oh no! It's fine, we'll finish tomorrow..."
    new "نه! هیچ اشکالی نداره، فردا تمام می‌شه..."

    # say L244 gra
    old "It's fine, just hurry a little more next time and we will make it."
    new "خوبه، فقط بار بعد کمی سریع‌تر باش تا بتونیم تمامش کنیم."

    # say L245 pla
    old "I guess the next time will be better."
    new "بازهای بعدی بهتر خواهد بود."

    # say L246 jon
    old "Sure, it will!, anyway see you again tomorrow."
    new "البته، بعداً هم بهتر خواهد بود؛ به هر حال، دوباره فردا می‌بینیم."


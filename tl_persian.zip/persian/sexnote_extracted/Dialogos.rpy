# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Dialogos.rpy
translate persian strings:

    # say L9 pla
    old "Another day..."
    new "باز هم یک روز..."

    # say L10 pla
    old "Let’s just get through classes and survive."
    new "باید فقط از کلاس‌ها عبور کنیم و زنده بمانیم."

    # say L11 pla
    old "Hope nothing weird happens today."
    new "امیدوارم امروز هیچ چیز عجیب بیفتد."

    # say L16 pla
    old "Hmm... What's that sound coming down the hall?"
    new "Hmm... آن صدایی از راهرو چیه؟"

    # say L18 pla
    old "({i}Sounds like music, but faint. Someone’s phone playing a song?{/i})"
    new "{i} مثل موسیقی، اما خیلی خفیف. شاید گوشی کسی آهنگ باز کرده؟ {/i}"

    # say L20 pla
    old "No way, it’s a voice. Singing softly... from the girls’ bathroom?"
    new "نه، این صداییه. با صدای نرم خواندن... از توالت دختران؟"

    # narrator L21 
    old "{i}And I’m still breathing... but I don’t understand...{/i}"
    new "{i}و من هنوز نفس می‌کشم... اما نمی‌فهمم...{/i}"

    # say L22 pla
    old "({i}That melody’s got so much heart. Who’s in there?{/i})"
    new "{i}این آهنگ همچین احساساتی داره. تو کی هستی؟{/i}"

    # say L26 pla
    old "Hey [bil]... that singing? Was that you?"
    new "هی [bil]... اون آواز خواندن؟ این تو بودی؟"

    # say L27 bil
    old "Heh, singing? Nah, probably just music from next classroom."
    new "هه، خواندن؟ نه، احتمالاً فقط موسیقی از کلاس جلو است."

    # say L28 pla
    old "Uhh, music? It sounded like someone singing, like right here."
    new "اوه، موسیقی؟ به نظر می‌رسید کسی اینجا آواز می‌خواند."

    # say L30 bil
    old "Or someone’s phone blasting some old track. This place is a noise fest."
    new "یا گوشی کسی که یک آهنگ قدیمی رو با حجم بالا پخش می‌کنه. اینجا همه جا صدایی هست."

    # say L31 pla
    old "({i}She’s dodging it hard. But that voice was totally hers.{/i})"
    new "{i} او هروقت داشت اجتناب می‌کرد. اما آن صدای قطعاً از او بود. {/i}"

    # say L32 pla
    old "Come on, [bil], it was too good to be just an echo."
    new "بیا، [bil]، این خیلی خوب بود تا فقط صدا باشه."

    # say L33 bil
    old "Too good? Dude, if I was singing, I’d be viral already. Blame the vents."
    new "خوب بود؟ داداش، اگه من آواز می‌زدم، قطعاً ویروسی می‌شدم. باید از تهویه‌هوا گناه کنم."

    # say L34 pla
    old "The vents? For real? It had this raw emotion..."
    new "ونت‌ها؟ واقعاً؟ اون حس خام و عاطفی رو داشت..."

    # say L35 bil
    old "Emotional vents, then. Case closed. Catch you later, [pla]."
    new "ونت‌های هیجانی، پس. پرونده بسته شد. بای، ز[pla]."

    # say L37 pla
    old "Whoa, her notebook just dropped."
    new "وای، دفترچه‌اش فقط پر افتاد."

    # say L39 pla
    old "What’s this? Doodles, messy scratches... hold up, are these lyrics?"
    new "این چیه؟ نقاشی‌ها، خطوط پرتوز... بی‌خیال، این‌ها آیا لی‌ریک‌ها هستند؟"

    # say L40 pla
    old "Music notes scribbled everywhere. ‘Faded echoes, songs we lost...’"
    new "نوت‌های موسیقی همه جا پخش شده. «صداهای ناپدید، آهنگ‌هایی که از دست دادیم...»"

    # say L42 pla
    old "Why deny it? Someone with this talent..."
    new "چرا انکار می‌کنی؟ کسی با این موهبت..."

    # say L44 pla
    old "Yeah, that’s the right call."
    new "بله، این تصمیم درسته."

    # say L50 jon
    old "Oh, [pla]! What a treat to see you, honey!"
    new "اوه، ز[pla]! چه خوشحالم که تو رو می‌بینم، عزیزم!"

    # say L51 pla
    old "Hey, Mrs. Jones. Sorry for dropping by unannounced."
    new "سلام خانم جونز. متاسفم که بدون اطلاع اومدم."

    # say L52 jon
    old "Nonsense, you’re always welcome. How’s school going?"
    new "با این همه گفتگو نیست، همیشه خوشحالم که می‌آیی. مدرسه چطور می‌ره؟"

    # say L53 pla
    old "It’s alright. Keeps me on my toes."
    new "خوبه. همیشه من رو مشغول می‌کنه."

    # say L54 jon
    old "Oh, you’re always so busy! [bil]’s out with friends, but what brings you by?"
    new "اوه، همیشه اینقدر مشغولی! [bil] با دوستایش خارج شده، ولی تو چرا اومدی؟"

    # say L55 pla
    old "Well, she dropped her notebook at school. Figured it’s important."
    new "خب، او دفترچه‌اش رو در مدرسه گذاشت. فکر کردم مهمه."

    # say L56 jon
    old "Let me see... Oh, these sketches and notes. Takes me way back."
    new "بیاین ببینم... اوه، این طرح‌ها و یادداشت‌ها. به روزهای قدیمی بر می‌گردونه."

    # say L57 pla
    old "Way back? To what, if it’s okay to ask?"
    new "باز می‌گرده؟ به چه زمانی، اگر می‌تونم بپرسم؟"

    # say L58 jon
    old "To when she was little. Her parents... they used to sing with her every night."
    new "به زمانی که کوچک بود. والدینش... هر شب با او آواز می‌خواندند."

    # say L60 pla
    old "I can imagine that. Must’ve been her whole world."
    new "می‌تونم بیاندازم. باید کل جهانش بوده."

    # say L61 jon
    old "It was. Her dad with his old guitar, her mom humming along. It lit her up."
    new "بله. پدرش با گیتار قدیمی‌اش و مادرش که همراه می‌خواند. این موضوع او را خوشحال می‌کرد."

    # say L62 pla
    old "({i}So that’s where her gift comes from.{/i})"
    new "{i}پس اینجا سرچشمه توانایی‌اش هست.{/i}"

    # say L63 pla
    old "I heard her today. It really hit me deep."
    new "امروز صدایش رو شنیدم. واقعاً برایم تأثیر گذاشت."

    # say L64 jon
    old "Oh really? You heard her singing today?"
    new "اوه واقعاً؟ امروز صدایش رو شنیدی؟"

    # say L65 jon
    old "Well, she used to sing all the time. It was such a lovely thing to hear... but after her parents passed, everything changed for her."
    new "خب، قبلاً همیشه آواز می‌زد. شنیدنش خیلی لذت‌بخش بود... اما بعد از اینکه والدینش را از دست داد، همه چیز برایش تغییر کرد."

    # say L66 pla
    old "Oh, I didn't know? I’m so sorry, Mrs. Jones. That sounds so tough."
    new "اوه، من نمی‌دونستم؟ خیلی متاسفم، خانم جونز. این خبر خیلی سخت به نظر می‌رسه."

    # say L67 jon
    old "It was a long time ago... A car accident. Took them both in an instant."
    new "این اتفاق از طولانی پیش بود... یک تصادف ماشین. هر دو را در لحظه گرفت."

    # say L68 pla
    old "({i}Gone just like that. No wonder it shook her.{/i})"
    new "{i} همینطور رفتند. خوبه که اینقدر برایش تأثیر گذاشته. {/i}"

    # say L69 pla
    old "That’s so sad. How did [bil] get through it?"
    new "این خیلی حزینه. جون چطور [bil] از این عبور کرد؟"

    # say L70 jon
    old "Faith carried us. But for her, singing turned into pain."
    new "ایمان ما را حامی شد. اما برای او، خواندن به درد تبدیل شد."

    # say L71 jon
    old "Every note brought their voices back. First happy, then just the hurt."
    new "هر نت صدای آنها را بر می‌گرداند. اول خوشحال، بعد فقط درد."

    # say L72 pla
    old "So it stopped being joy. More like ripping open old wounds?"
    new "پس خوشحالی برداشت. بیشتر مثل باز کردن زخم‌های قدیمی شد؟"

    # say L73 jon
    old "Exactly. She shut it down, like flipping a switch."
    new "ضبط کرد، مثل اینکه یک دکمه رو خاموش کرد."

    # say L74 pla
    old "({i}That cool act she pulls... it’s gotta be shielding all this.{/i})"
    new "{i}این سرماگیری که اجرا می‌کنه... حتماً همه این‌ها رو مخفی می‌کنه.{/i}"

    # say L75 pla
    old "I get why she’d hide something tied to them."
    new "من می‌فهمم چرا چیزی که به اونا مربوطه رو پوشش میده."

    # say L76 jon
    old "You see her heart, [pla]. Not many do."
    new "شما قلبش رو می‌بینی، [pla]. خیلی‌ها اینطور نیستند."

    # say L77 pla
    old "Just wish it didn’t weigh her down like that. Feels so unfair."
    new "می‌خواستم این همراهی‌اش رو برایش سبک‌تر کنم. اینجوری نظالم نیست."

    # say L78 jon
    old "Life’s not always kind, honey. But you’re sweet to care."
    new "زندگی همیشه لطف دادن نمی‌کنه، عزیزم. اما خوشحالم که اینقدر نگرانی."

    # say L79 pla
    old "I’ll leave the notebook. Tell her I didn’t snoop too much."
    new "دفتر رو می‌ذارم. به جین بگو من خیلی کنجکاو نبودم."

    # say L80 jon
    old "Of course, dear. Safe walk home now."
    new "البته، عزیزم. حالا مسیر خودت رو ایمن بگذران."

    # say L81 pla
    old "Thanks, Mrs. Jones. See you soon."
    new "ممنون، خانم جونز. تا زودی می‌بینیم."

    # say L87 pla
    old "Man... what a day."
    new "مرد... چه روزی بود."

    # say L88 pla
    old "So that’s why she acts like nothing touches her."
    new "پس همین‌جوری هست که هیچ چیز برایش تأثیر نمی‌گذره."

    # say L89 pla
    old "Losing both parents at once... and singing was the last thing connecting her to them."
    new "پدر و مادرش رو هم‌وقت از دست داده... و آواز خواندن آخرین چیزی بود که با اونا ارتباط داشت."

    # say L90 pla
    old "Now I get why she kept dodging the whole thing. Every note probably feels like losing them again."
    new "حالا متوجه شدم چرا همیشه از این موضوع پر هروپ می‌کرد. هر نت احتمالا مثل دوباره از دست دادن آنها است."

    # say L91 pla
    old "She’s not hiding because she’s shy. She’s hiding because it hurts too much to let it out."
    new "او پوشانده نیست چون خجالتیه. او پوشاندهه چون آنقدر درد داره که آن رو بیرون بیاوره."

    # say L92 pla
    old "That cool girl armor isn’t just attitude. It’s survival."
    new "این لباس قوی دختر خفن فقط نگرش نیست. این برای زنده ماندن است."

    # say L93 pla
    old "But that voice... It’s still in there. And it’s beautiful."
    new "اما آن صدایی... هنوز درونش هست. و زیبا است."

    # say L94 pla
    old "If there’s even a tiny chance something could help her feel that joy again... I have to try."
    new "اگه حتی امکان کوچکی هست که بشه به اون خوشحالی قبلیش برگرده... باید سعی کنم."

    # say L95 pla
    old "I don’t know how yet, but I’m not letting her carry this alone."
    new "هنوز نمی‌دونم چطور، ولی نمی‌تونم اجازه بدم این همه را فقط او ببرد."

    # say L105 pla
    old "Hold up, what’s this flyer on the wall?"
    new "توقف، این آگهی روی دیوار چیه؟"

    # say L107 pla
    old "School’s doing a music contest? Sign-ups are open..."
    new "مدرسه مسابقه موسیقی می‌کنه؟ ثبت‌نام باز هست..."

    # say L108 pla
    old "Wait. This is exactly what [bil] needs right now."
    new "این دقیقاً همان چیزیه که ز[bil] الان نیاز داره."

    # say L110 pla
    old "({i}She’s got the talent, she just doesn’t show it. This could pull her out of that shell.{/i})"
    new "{i}او با توانایی‌اش هم هست، فقط نمی‌تونه به خارج بیاد. این می‌تونه بهش کمک کنه که از اون پوسته بیرون بیاد.{/i}"

    # say L111 pla
    old "({i}She’s literally going to murder me for signing her up without asking.{/i})"
    new "({i}اوایی، اوون برای اینکه من بدون پرسیدن اسمش ثبت کردم، من رو می‌کشت. ولی خطرش ارزش داره، درسته؟{/i})"

    # say L113 pla
    old "Gotta do it."
    new "باید این کار رو بکنم."

    # say L119 pla
    old "Hi, are you Ms. Beylaine?"
    new "سلام، آیا شما خانم بیلین هستید؟"

    # say L120 bey
    old "That’s me, honey! Come in, come in."
    new "من هستم، عزیزم! بیا داخل، بیا داخل."

    # say L121 pla
    old "I saw the flyer about the music contest. Looks really cool."
    new "من آگهی مسابقه موسیقی رو دیدم. خیلی خوب به نظر می‌رسه."

    # say L122 bey
    old "Cool? Baby, it’s about to be everything."
    new "خوب؟ عزیزم، اینجا همه چیز خواهد بود."

    # say L123 pla
    old "I wanna sign up. Me and my friend [bil]."
    new "من می‌خوام ثبت‌نام کنم. من و دوستم [bil]."

    # say L124 bey
    old "Love the duo energy! Tell me about you two."
    new "دو تا همکاری خوب! بگو داستان شما دو تا چیه."

    # say L125 pla
    old "Well, she’s got an insane voice, but she keeps it hidden. I thought this might be good for her."
    new "خب، صدایش خیلی خوبه، اما همیشه آن رو پوشش میده. فکر کردم این برایش خوب باشه."

    # say L126 bey
    old "Hidden talent? That’s my favorite kind."
    new "talent مخفی؟ این جوری همچین چیزی رو دوست دارم."

    # say L127 bey
    old "What about you, handsome? What do you bring to the stage?"
    new "تو چطوری، زیبا؟ تو چه چیزی رو به صحنه می‌بری؟"

    # say L128 pla
    old "Uhh... honestly? Nothing. I can’t sing, can’t play. Zero."
    new "اوه... صادقانه؟ هیچ. نمی‌تونم آواز بزنم، نمی‌تونم بازی بزنم. صفر."

    # say L129 bey
    old "Zero today doesn’t mean zero tomorrow."
    new "امروز صفر بودن، فردا صفر نیست."

    # say L130 bey
    old "Don't worry, we’re doing practice sessions first. Technique, composition, stage fire. I pull the best out of everybody."
    new "نگران نباش، اول همه جا تمرین می‌کنیم. تکنیک، ساختار، حرارت صحنه. من از هر کس بهترین چیز رو بیرون می‌آورم."

    # say L131 pla
    old "So we get actual coaching before the contest?"
    new "پس قبل از مسابقه واقعی هم تمرین می‌کنیم؟"

    # say L132 bey
    old "Exactly. I don’t just throw y’all to the wolves. We build it together."
    new "دقیقاً. من هیچ کس رو به شرایط بد نمی‌اندازم. ما همه چیز رو با هم ساخته می‌کنیم."

    # say L133 pla
    old "Oh, that sounds perfect, actually."
    new "اوه، این واقعاً عالیه."

    # say L134 bey
    old "Ok, to start, I just need you to fill out a couple forms for you and your friend. After that, I’ll reach out to schedule the audition."
    new "باشه، برای شروع فقط باید چند فرم رو برای خودت و دوستت پر کنی. بعد از اون، من برای تعیین زمان آزمون صدا می‌گیرم."

    # say L135 pla
    old "Got it, thanks, Ms. Beylaine. This means a lot."
    new "باشه، ممنون، خانم بیلین. این برای من خیلی مهمه."

    # say L136 bey
    old "Call me Bey. And tell your friend: when she’s ready to own that stage, I got her."
    new "ممنون. منو بی‌خیال بگیر. و به دوستت بگو: وقتی آماده شد تا صحنه رو به دست ببره، من برایش هستم."

    # say L142 pla
    old "({i}Best idea I’ve ever had.{/i})"
    new "( {i}بهترین ایده‌ای که تا حالا داشتم.{/i})"

    # say L144 pla
    old "({i}She’s scary when she’s mad... but this is for her.{/i})"
    new "{i}وقتی خشم می‌کنه ترسناکه... اما این برایشه.{/i}"

    # say L154 pla
    old "Hey [bil]! You’re not gonna believe what I just did!"
    new "هی [bil]! نمی‌تونی باور کنی چی کار کردم!"

    # say L155 bil
    old "Hmm, what now?"
    new "هم، الان چه کاری کردی؟"

    # say L156 pla
    old "I signed us up for the music contest!"
    new "ما رو برای مسابقه موسیقی ثبت‌نام کردم!"

    # say L157 bil
    old "You... did what?"
    new "تو... چه کاری کردی؟"

    # say L158 pla
    old "Yeah! They’ve got coaching and everything. It’s perfect!"
    new "بله! هستن مربی‌ها و همه چیز. خوبه کامل!"

    # say L159 bil
    old "You signed me up. Without even asking."
    new "تو منو ثبت‌نام کردی. حتی پرسیدی هم نه."

    # say L160 pla
    old "I know, I know, it sounds crazy, but just hear me out—"
    new "می‌دونم، می‌دونم، به نظر می‌تونه عجیب بیاد، ولی فقط یه لحظه صبر کن و به من بگوش —"

    # say L161 bil
    old "No. You don’t get to decide that for me, [pla]."
    new "نه. تو نمی‌تونی اینو برای من تصمیم بگیری، [pla]."

    # say L162 pla
    old "No, no, it's just that you have this insane voice. Like, people need to hear it."
    new "نه، نه، فقط اینجاست که صدایت خیلی جنونیه. مثل اینکه، مردم باید اون رو بشنوند."

    # say L163 bil
    old "That’s not the point. It’s my thing, not yours."
    new "این مهم نیست. این چیز منه، نه تو."

    # say L164 pla
    old "Come on, it’s just a contest! You’d crush everyone."
    new "بیا، فقط یه مسابقه هست! تو همه رو شکست می‌دی."

    # say L165 bil
    old "Stop acting like you know what’s best for me."
    new "بیا، نباید مثل اینکه می‌دونی بهترین چی برای منه رفتار کنی."

    # say L166 pla
    old "I’m not! I just... saw the flyer and thought 'this is made for [bil]'."
    new "من نیستم! من فقط... آگهی رو دیدم و فکر کردم این برای [bil] ساخته شده."

    # say L167 bil
    old "Well, you thought wrong."
    new "خب، اشتباه فکر کردی."

    # say L170 pla
    old "Wait, your grandma told me how much you used to love singing with your parents—"
    new "بیل، صبر کن، بابا به من گفت چقدر دوست داشتی با والدینت آواز بزنی—"

    # say L174 pla
    old "I- I- I’m sorry!"
    new "من- من- من ببخشید!"

    # say L175 pla
    old "I- I didn’t mean it l- like that, I- I swear!"
    new "من- من قصد نداشتم اونجور بگم، و- و قسمت!"

    # say L176 bil
    old "You have no idea what you’re talking about."
    new "تو هیچ ایده‌ای نداری در مورد این که در مورد چه چیزی حرف می‌زنی."

    # say L177 pla
    old "I know! I messed up, okay? I’m really sorry."
    new "من می‌دونم! اشتباه کردم، خب؟ واقعاً متاسفم."

    # say L178 pla
    old "I just... I thought it would help. That’s all."
    new "من فقط... فکر کردم کمک می‌کنم. همین."

    # say L179 bil
    old "You don’t get to dig into my life like that!"
    new "تو حق نداری به زندگی من همچین ورودی‌ای کنی!"

    # say L180 pla
    old "You’re right. I overstepped. Big time."
    new "درست می‌فرمایی. خیلی خیال پردازی کردم."

    # say L182 pla
    old "I- I’m sorry, [bil]. Seriously."
    new "من- من خیلی متاسفم، ز[bil]. جدیان."

    # say L183 bil
    old "Tsk..."
    new "تک…"

    # say L185 bil
    old "Mind your own business, [pla]. This isn’t your thing to fix."
    new "بیاپرسی خودت، [pla]. این جوری نیست که تو بشه اصلاح کرد."

    # say L186 pla
    old "I get it. But your voice... it’s too good to stay hidden."
    new "فهمیدم. اما صدایت... خیلی خوبه تا پوشیده بمونه."

    # say L187 bil
    old "Why do you even care?"
    new "چرا هم اصلاً نگرانی؟"

    # say L188 pla
    old "Because I hate seeing you hold back something you’re amazing at."
    new "چون نمی‌تونم ببینم تو چیزی رو که خوبی در اون هستی مخفی کنی."

    # say L189 bil
    old "It’s not that simple."
    new "این به همین ساده نیست."

    # say L190 pla
    old "I know it’s not. But just one practice. One."
    new "می‌دونم ساده نیست. ولی فقط یه تمرین. یه بار."

    # say L191 bil
    old "You’re seriously not dropping this?"
    new "می‌خوای این رو هم نکنی؟"

    # say L192 pla
    old "I can’t. Not when I know how much talent you have."
    new "من نمی‌تونم. وقتی می‌دونم چقدر موهبت هست."

    # say L193 bil
    old "You’re impossible."
    new "تو غیرممکنی."

    # say L194 pla
    old "Please. One session. If it sucks, we never talk about it again."
    new "لطفاً. یک جلسه. اگر خوب نباشه، هیچ وقت دیگه بهش اشاره نکنیم."

    # say L196 bil
    old "You’re gonna keep bugging me until I say yes, aren’t you?"
    new "می‌خوای اینجوری تا زمانی که بگم بله، همینه، نیست؟"

    # say L197 pla
    old "Uhh... pretty much."
    new "اوه... تقریباً."

    # say L198 bil
    old "Ughh... fine. One practice. Just to shut you up."
    new "اوه... خوب. یه تمرین. فقط برای اینکه ببندی."

    # say L199 bil
    old "But that’s it. And after that, we’re done talking about it. Got it? End of discussion."
    new "ولی این آخرش. و بعد از اون، دیگه در موردش صحبت نمی‌کنم. گرفتی؟ پایان بحث."

    # say L200 pla
    old "Deal! Thank you!"
    new "توپ! ممنون!"

    # say L201 bil
    old "Don’t thank me yet."
    new "هنوز ممنون نشین."

    # say L202 bil
    old "And don’t you ever ever bring up my parents again. You hear me?"
    new "و هرگز هیچ وقت از والدینم نمی‌گذارم دوباره صحبت کنی. شنیدی؟"

    # say L203 pla
    old "Uhh, yeah, got it..."
    new "اوه، بله، فهمیدم..."

    # say L205 pla
    old "Phew.... Well, she didn’t kill me... I’ll call that a win."
    new "پوف…. خب، او من رو نکشت… این رو برنده می‌شناسم."

    # say L206 pla
    old "One practice. That’s all I needed."
    new "یه تمرین. همه چیزی که لازم داشتم."

    # say L216 pla
    old "The audition. The contest thing. Oh man, [bil] better not bail on me."
    new "آزمون. مسابقه. اوه خدایا، [bil] حتماً نباید من رو تنک کنه."

    # say L217 pla
    old "She said she’d show... right?"
    new "او گفت که نشون می‌ده... درسته؟"

    # say L218 pla
    old "I have zero clue what I’m doing up there, but it’s for her. Gotta move."
    new "من هیچ ایده‌ای ندارم بالا چیکار باید بکنم، ولی برای او هست. باید حرکت کنم."

    # say L224 pla
    old "There you are! Ready for this?"
    new "اینجا هستی! آماده این هستی؟"

    # say L225 bil
    old "Ready? I’m here because you wouldn’t shut up about it."
    new "آماده؟ من اینجا هستم چون تو در موردش خیلی حرف زدی."

    # say L226 pla
    old "Come on, it’s gonna be fine. Just one showcase."
    new "بیا، همه خوب می‌شه. فقط یه نمایش."

    # say L227 bil
    old "Yeah, yeah. Let’s get this over with so I can go back to my life."
    new "بله، بله. بیایم این را تمام کنیم تا بتوانم به زندگی‌ام برگردم."

    # say L228 pla
    old "You’re gonna kill it, [bil]. I know it."
    new "تو خوب می‌کنی، ز[bil]. میدونم."

    # say L229 bil
    old "Save the pep talk, [pla]. I’m doing this to make you stop bugging me, remember?"
    new "بلاهبلایی رو صرف کن، [pla]. من اینجوری می‌کنم تا تو دیگه به من زدگی نکنی، یادت هست؟"

    # say L230 pla
    old "Fair enough."
    new "باشه، من متوجه هستم."

    # say L231 pla
    old "({i}She’s trying to act like she doesn’t care... but she showed up.{/i})"
    new "{i} او سعی می‌کنه به نظر بی‌تفاوت بیاد... اما اومده‌ست. {/i}"

    # say L232 bil
    old "Whatever. Let's go I don't have all day."
    new "بیا برو، وقت همه رو ندارم."

    # say L233 pla
    old "Sure, let's go."
    new "بله، برویم."

    # say L240 bey
    old "I’m Beylaine, but you can call me Bey, and I’m the teacher who’s going to get you ready to take this year’s Music Contest crown."
    new "من بیلین هستم، اما می‌تونی مرا بی بگی. من معلمی هستم که قراره تو رو آماده کنم برای برنده شدن در مسابقه موسیقی این سال."

    # say L241 bey
    old "Look around you. Every single person in this room has fire inside them."
    new "حولت رو بگیر. هر فردی در این اتاق آتشی درون خود داره."

    # say L242 bey
    old "Some of you know it, some of you are scared of it, some of you are still hiding it. My job? Pull that fire out and turn it into a supernova."
    new "بعضی‌ها این آتش رو می‌شناسن، بعضی‌ها ازش می‌ترسن، بعضی‌ها هم هنوز ازش پنهانی دارن. وظیفه من؟ اون آتش رو بیرون بیارم وش به یه سوپرنوا تبدیل کنم."

    # say L244 bey
    old "From today until the final I’m your personal mentor, private feedback, whatever each of you needs to bring your absolute best act."
    new "از امروز تا آخر مسابقه من مربی شخصیتون هستم، بازخورد خصوصی، هر چی که هر کدوم از شما برای ارائه بهترین عمل خودتون نیاز دارید."

    # say L245 bey
    old "You’ll cry, you’ll laugh, you’ll hate me on Tuesdays and love me on Fridays, but by the final show you’ll thank me when the entire school is screaming your names."
    new "شما گریه خواهید کرد، خنده خواهید زد، در یکشنباهای هفته مرا می‌ترسید و در جمعه‌ها از من پرسته خواهید شد، اما در نهایت، وقتی کل مدرسه نام‌های شما را صدا می‌زنند، از من تشکر خواهید کرد."

    # say L246 bey
    old "I'll be here for everything you need, we’re talking vocal technique, stage command, songwriting, harmonies, emotional truth, the whole package."
    new "من برای همه چیزی که نیاز داری اینجا هستم، از تکنیک صدایی، حکمروایی روی صحنه، نوشتار آهنگ، هماهنگی، حقیقت عاطفی، همه چیز."

    # say L248 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 % yourself. Ready? Let’s make magic!"
    new "پس نفس بکش، لذت ببر و به یاد داشته باش: صحنه جایی است که می‌توانی ۱۰۰٪ خودت باشی. آماده‌ای؟ بیایم جاده‌ای ایجاد کنیم!"

    # say L252 sha
    old "Hit it, darling!"
    new "برو، عزیزم!"

    # say L253 rya
    old "Let’s give them a show they’ll never forget!"
    new "بیای، بهشون نشون بدیم شوی که هیچ وقت فراموش نمی‌کنند!"

    # say L257 rya
    old "{i}Spotlights on us, no time to lose!{/i}"
    new "{i}نورهای صحنه روی ما، وقتی برای ضایع کردن نیست!{/i}"

    # say L267 bey
    old "Y’all just brought Broadway to this classroom! Energy off the charts, synchronization tighter than my ponytail, costume game insane."
    new "شما همه فقط برودوی رو به این کلاس آوردید! انرژی بالای حد، هماهنگی محکم‌تر از گرد کشتم، لباس‌پوشی هم خیلی خوب."

    # say L268 bey
    old "My only note: sometimes less is more. When every second is maximum sparkle, there’s nowhere left to go for the big moments. Save some glitter for the finale, babies. Otherwise? Flawless."
    new "تنها نکته من اینه: گاهی کمتر بودن بیشتره. وقتی هر لحظه تا حد اوج برق می‌زنه، برای لحظه‌های بزرگ جایی برای پیشرفت نمی‌مونه. برای نهایی چند ذره راکت بذارید، بچه‌ها. در غیر این صورت؟ بدون هیچ اشکال."

    # say L272 ari
    old "Let’s remind them why we’re here."
    new "بیایید به یاد ببریم چرا اینجا هستیم."

    # say L273 tay
    old "Exactly."
    new "دقیقاً."

    # say L276 ari
    old "{i}I’m feeling dangerous, feeling so brand new{/i}"
    new "{i}من احساس خطرناکی می‌کنم، احساس جدید و تازه {/i}"

    # say L277 tay
    old "{i}Shaking off the dust, ready for round two{/i}"
    new "{i}پوست خودمو لرزانده، آماده برای دور دوم{/i}"

    # say L278 ari
    old "{i}High notes climbing, watch me touch the sky{/i}"
    new "{i}نوت‌ها بالا می‌رود، ببینید من به آسمان می‌رسم{/i}"

    # say L279 tay
    old "{i}Beat drops heavy, no more asking why!{/i}"
    new "{i}آهنگ سنگین می‌افتد، دیگر سؤال نمی‌پرسیم چرا!{/i}"

    # say L287 bey
    old "Lord have mercy on my edges! Ariana, those whistle tones cleaner than my Sunday choir. Taylor, that belt could wake the dead."
    new "اللّه بر لبه‌هامون بخشنده باشه! آریانا، این نت‌های بلند تر از صدای کور خودم هستن. تیلور، این صدای قوی می‌تونه مرده رو هم بیدار کنه."

    # say L288 bey
    old "Pitch perfect, breath control insane, harmony game lethal."
    new "پیچ خیلی دقیق، کنترل نفس شگفت‌انگیز، بازی هارمونی مرگبار."

    # say L289 bey
    old "My tiny note: sometimes perfection can feel safe. Next time risk a little crack, a little rawness. Vulnerability wins hearts. But technically? Untouchable."
    new "نوت کوچک من: گاهی اوقات کمال می‌تونه احساس امنیت بده. بار بعد یه خونه شکست و یه خونه خامی ریسک کن. آسیب‌پذیری قلب‌ها رو می‌بره. ولی تکنیکاً؟ بدون مقایسه."

    # say L293 pla
    old "Uhh... W- we didn’t really get a chance to rehearse..."
    new "اوه... ما وقت کافی برای تمرین نداشتیم..."

    # say L294 bil
    old "Ugh, just give me the mic."
    new "اوه، فقط میکروفن رو به من بده."

    # say L308 bey
    old "Oh my gosh, Billie... honey. That wasn’t singing. That was bleeding through music."
    new "اوه خدا، بیلی... عزیزم. این آواز نبود. این خونریزی از موسیقی بود."

    # say L309 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100%. Volume was whisper quiet, but somehow you filled the entire room."
    new "نغمه‌ات مثل بادام زرد است، عبارت‌گذاری‌ات قلب‌سوز است، و صداقت احساسی‌ات ۱۰۰٪. صدایت هرچند نرم بود، ولی به طوری تمام اتاق را پر کرد."

    # say L310 bey
    old "Stage presence was nonexistent, lighting was wrong for that mood, and [pla]... sweetheart, you were a potted plant."
    new "حضور صحنه وجود نداشت، نور برای اون حالت اشتباه بود، و ز[pla]... عزیزم، تو مثل گیاه در قفس بودی."

    # say L311 bey
    old "But the voice? The voice is once in a generation. We’re going to protect it, grow it, and teach it to roar when it needs to roar."
    new "اما صدایت؟ صدایت هر نسل یکباره است. ما قصد داریم آن را محافظت کنیم، رشد دهیم و یاد بدهیم وقتی لازم باشد، برآید."

    # say L312 bey
    old "[pla], next time you move, you breathe with her, you support her. Deal?"
    new "[pla]، بار بعد وقتی حرکت می‌کنی، با او نفس می‌کشی، او را حمایت می‌کنی. توافق کردی؟"

    # say L313 pla
    old "Uhh... Y- yeah sure."
    new "آره... بله، حتماً."

    # say L319 bey
    old "Well, I have goosebumps from head to toe. Three completely different universes in one room."
    new "خب، از سر تا پا خالی از لرز نیستم. سه جهان کاملاً متفاوت در یک اتاق."

    # say L320 bey
    old "Sharpay & Ryan: spectacle and precision. Ariana & Taylor: vocal olympics. Billie & [pla]: pure soul."
    new "شارپای و رایان: نمایش و دقت. آریانا و تیلور: المپیاد صدایی. بیلی و [pla]: روح خالص."

    # say L321 bey
    old "Next sessions we start real work: breathing, dynamics, choreography, song choice, storytellin, everyone gets one-on-one time with me."
    new "در جلسات بعدی شروع می‌کنیم به کار واقعی: تنفس، دینامیک، رقص، انتخاب آهنگ، روایت داستان؛ هر کدوم از شما وقت خودتان با من در می‌گذرت."

    # say L322 bey
    old "Because every single one of you can win this thing. I’m not here to pick favorites; I’m here to make favorites out of all of you."
    new "چون هر یک از شما می‌تونه برنده بشه. من اینجا نیومده‌ام تا علاقه‌مندی بکنم؛ من اینجا هستم تا همه شما رو به علاقه‌مندی‌های من تبدیل کنم."

    # say L323 bey
    old "Go home, rest those voices, dream big, and come back hungry. See you at the next session!"
    new "به خونه برو، صدایت رو استراحت بد، بزرگ بکنیم، و با هیجان برگرد. تا جلسه بعد می‌بینم!"

    # say L327 pla
    old "Wow, Billie, did you hear everything she was saying about your voice?"
    new "بیلی، شنیدی همه چیزی که در مورد صداتون گفت؟"

    # say L328 bil
    old "Yeah, yeah, Anyway. I did the one practice. We’re done."
    new "بله، بله، هر حال. من یک تمرین انجام دادم. تمام شد."

    # say L329 pla
    old "W- what? Are you serius? You were unbelievable—"
    new "و- وای، جدی می‌گی؟ شما باورنکردنی بودی—"

    # say L333 sha
    old "Unbelievable is right. Unbelievably depressing."
    new "حالم خوبه، خیلی خوبه. خیلی ناامید کننده بود."

    # say L335 sha
    old "What was that, a lullaby for the dead?"
    new "این چی بود، آهنگ خاکسپاری برای مردها؟"

    # say L339 sha
    old "Volume exists for a reason, sweetie. The back row couldn’t hear a thing."
    new "صدا وجود داره برای یه دلیل، عزیزم. ردیف آخر هیچی نشنیدن."

    # say L341 ari
    old "Oh, wait, is this the girl who whispered her whole song? Heh"
    new "او، بی‌خیال، این همون دختریه که کل آهنگش رو به صورت فیس‌فیس گفت؟ هه"

    # say L343 tay
    old "I thought someone forgot to plug in the mic, hahaha."
    new "فکر کردم کسی میکروفون رو متصل نکرده، هahaha."

    # say L344 sha
    old "Exactly. Bedroom sad girl vibes don’t win contests, sweetie."
    new "دقیق هست. احساسات اتاق خواب تون رو در مسابقات برنده نمی‌کنه، عزیزم."

    # say L345 ari
    old "We’re trying to make people dance, not cry."
    new "ما سعی داریم مردم رو رقص بزنند، نه گریه کنند."

    # say L346 tay
    old "Yeah, save the therapy session for TikTok."
    new "بله، جلسه درمان رو برای تیک‌توک بقیه بذار."

    # say L347 pla
    old "Hey, that’s enough—"
    new "هی، کافیه —"

    # say L349 sha
    old "Oh, and her backup tree finally speaks!"
    new "اوه، و درخت امدادی‌اش هم بالاخره حرف زد!"

    # say L351 ari
    old "What did you contribute, [pla]? Standing there like a scared statue?"
    new "تو چه کاری کردی، [pla]؟ مثل آماره‌ای وحشتناک ایستادی؟"

    # say L352 tay
    old "Cute support system. Zero talent, zero movement."
    new "حتماً سیستم پشتیبان لطیف. صفر توانایی، صفر حرکت."

    # say L353 sha
    old "Maybe both of you should just quit now."
    new "شاید هر دو باید الان خودتون رو از بازی ببرید."

    # say L357 pla
    old "Hey, we are not-"
    new "بله، ما نه-"

    # say L361 bil
    old "You know what’s funny?"
    new "می‌دونی چی خنده‌داره؟"

    # say L362 bil
    old "You three spend twenty minutes jumping and screaming so hard nobody can even remember the melody."
    new "شما سه تا بیست دقیقه پریده و صدایتان به حدی بلند است که هیچ‌کس حتی آهنگ رو به یاد نمی‌آره."

    # say L363 bil
    old "But sure, tell me my quiet voice is the problem."
    new "البته، بگو که این صدای آرام من مشکل است."

    # say L364 bil
    old "And [pla] standing still? At least he’s not faking it with glitter and fake smiles."
    new "و [pla] ایستادن جا؟ حداقل او با لکه‌ها و لبخند‌های نمایشی دروغ نمی‌گوید."

    # say L368 bil
    old "It’s kinda cute how you go all out screaming and dancing just to get a little attention."
    new "خوشحالم که تو همه جا صدا می‌زنی و رقص می‌کنی تا یه کمی توجه بگیری."

    # say L369 bil
    old "But volume isn’t talent, sweetie, glitter isn’t personality..."
    new "ولی صدای بلند مهارت نیست، عزیزم، لکه‌ها شخصیتت رو نمی‌پوشونن..."

    # say L370 bil
    old "And sequins don’t hide the fact you’re all noise and no soul."
    new "و لیوی‌ها نمی‌تونن این حقیقت رو پوشونن که تو همه‌ش صدای بلندیه و روحی نداری."

    # say L371 bil
    old "See you in the final, girls."
    new "در فینال می‌بینیم، دختران."

    # say L372 bil
    old "Try not to choke when someone actually feels something."
    new "سعی کن نخوری وقتی کسی واقعاً احساس می‌کنه."

    # say L377 pla
    old "And that's how it's done."
    new "و اینجاست که انجام می‌شه."

    # say L383 pla
    old "Hey Billie, wait!"
    new "بیلی، بیا!"

    # say L386 pla
    old "Are you okay?"
    new "تو خوبی؟"

    # say L387 bil
    old "Yeah, that was nothing. They’re just a bunch of idiots."
    new "بله، هیچی نبود. فقط یه دسته احمق هستند."

    # say L388 pla
    old "Yeah, you’re right. But the way you shut them down? Damn, that was epic. I’ll never forget their faces haha."
    new "بله، درست می‌فرمایی. ولی راهی که اونا رو خشک کردی؟ شیطان، اینجوری بود. هرگز چهره‌هایشون رو فراموش نمی‌کنم هاها."

    # say L389 pla
    old "And what was that about seeing them in the finals? I thought you were dropping out after the audition... like you said."
    new "و اون بخشی که می‌گفتی می‌تونی هم در فاینال‌هاشون رو ببینی؟ فکر کردم می‌خواهی بعد از آزمون صدایت رو برداری... مثل همین که گفتی."

    # say L390 bil
    old "Drop out?"
    new "برو خارج شوم؟"

    # say L391 bil
    old "Please. After that little circus?"
    new "لطفاً. بعد از آن سیرکوس کوچک؟"

    # say L392 bil
    old "I’m not giving them the satisfaction."
    new "من نمی‌دم اونا راضی شن."

    # say L393 pla
    old "So you’re staying?"
    new "پس می‌مونی؟"

    # say L394 bil
    old "Yeah, I’m staying."
    new "بله، من می‌مانم."

    # say L395 bil
    old "And we’re winning."
    new "و ما پیروز هستیم."

    # say L396 pla
    old "Wait, for real?"
    new "وای، واقعاً؟"

    # say L397 bil
    old "Dead serious. You wanted me in this mess? Congratulations."
    new "حتماً جدی هستم. خواستی من رو تو این مشکل وارد کنم؟ مبروک."

    # say L398 bil
    old "Now we’re doing it my way. Every day. No excuses."
    new "الان همه چیز به سبک من انجام می‌شه. هر روز. بدون هیچ عذردهی."

    # say L399 bil
    old "Come to my place so we can start rehearsing and get ready."
    new "به خونه‌ام بیا تا شروع به تمرین کنیم و آماده شویم."

    # say L400 pla
    old "Of course I will!"
    new "البته خواهم آمد!"

    # say L401 bil
    old "Alright. I’ll see you later, then."
    new "البته. تا بعداً."

    # say L402 pla
    old "S- sure, see you later."
    new "بله، بعداً می‌بینیم."

    # say L404 pla
    old "({i}Holy crap... she’s actually doing it.{/i})"
    new "{i}خودش را از دست بده... واقعاً اونجوری هست.{/i}"

    # say L405 pla
    old "I seriously did not think she was gonna say yes."
    new "من واقعاً فکر نکردم می‌تونه بله بگه."

    # say L406 pla
    old "Like... damn, she walked out of here looking way more motivated than I expected."
    new "مثلا... خودش رو اینقدر انگیزه‌دار نشون ندادم، فکر کنم."

    # say L407 pla
    old "Heh, I guess I owe part of that to those bullies running their mouths earlier."
    new "حاه، به نظر می‌رسه بخشی از اون رو باید به اون دسته خرابکار که قبلش دهانشون باز می‌کردند بدهم."

    # say L408 pla
    old "If they hadn’t pushed her buttons, she’d never have agreed that fast."
    new "اگه آنها اعصابش رو نزدند، هیچ وقت به همین سرعت توافق نمی‌کرد."

    # say L409 pla
    old "Phew... okay... okay, that’s one problem solved."
    new "پوف... خب... خب، این یه مشکل حل شد."

    # say L411 pla
    old "What the hell am I supposed to do in a music contest when I know absolutely nothing about music?"
    new "من باید چی کنم تو مسابقه موسیقی وقتی که از موسیقی هیچ چی نمی‌دونم؟"

    # say L412 pla
    old "Oh man... this is gonna be a disaster."
    new "اوه مرد... این خراب خواهد شد."

    # say L413 pla
    old "({i}Yeah... I’m so screwed.{/i})"
    new "{i}بله... من واقعاً در مشکل هستم.{/i}"

    # say L422 bil
    old "Took you long enough."
    new "دیر شدی."

    # say L423 pla
    old "Hey, sorry. Got caught up with stuff."
    new "بله، معذرت. خیلی مشغول بودم."

    # say L424 bil
    old "Whatever. Come in, grandma’s out."
    new "بیا بیرون، بابا نیست."

    # say L425 pla
    old "O- ok..."
    new "ا- اوه..."

    # say L429 bil
    old "Alright, Before we dive in, what do you know about music?"
    new "باشه، قبل از اینکه شروع کنیم، در مورد موسیقی چه می‌دونی؟"

    # say L430 pla
    old "Uhh... I can tell when a song’s good?"
    new "اوه... می‌تونم بفهمم وقتی یه آهنگ خوبه."

    # say L431 bil
    old "That’s it? No instruments? No singing lessons?"
    new "این همه؟ هیچ ابزاری نداری؟ هیچ درس خواندی نیست؟"

    # say L432 pla
    old "Uhh nope. Closest I got was humming in the shower."
    new "نه، همین. نزدیک‌ترین چیزی که به این رسیدم، آواز در دوش دادن بود."

    # say L433 bil
    old "Hmph, great start."
    new "همف، عالی شروع."

    # say L434 bil
    old "Okay. We’re trying everything today. Voice, rhythm, keys. See what sticks to your zero skills."
    new "باشه. امروز همه چی رو می‌سازیم. صدایت، ریتمت، نوت‌های موسیقی. ببینیم چه چیزی به مهارت‌های صفرت بچسب."

    # say L435 pla
    old "Everything?"
    new "همه چیز؟"

    # say L436 bil
    old "Yes, we’re gonna find something you don’t completely suck at."
    new "بله، چیزی می‌پیدیم که تو کمی خوب باشی."

    # say L437 bil
    old "I’m your coach now. And it’s gonna be brutal, because we’re winning this thing."
    new "من حالا مربوطت هستم. و خیلی سخت خواهد بود، چون ما این را برنده می‌شویم."

    # say L438 bil
    old "No mercy, no excuses. You wanted me in? Now you’re in all the way."
    new "بی‌رحمی، بدون عذرخواهی. خواستی من رو وارد کنی؟ حالا همه‌ش رو بپذیر."

    # say L439 pla
    old "No pressure then."
    new "فشاری نیست."

    # say L440 bil
    old "All the pressure. We’re winning this, so get ready to sweat."
    new "همه فشار. ما این را برنده می‌شویم، پس آماده شو برای تعریق."

    # say L441 pla
    old "*Gulp*..."
    new "*گلوله*..."

    # say L445 bil
    old "Ok, voice first. Easiest to test."
    new "با صدایت شروع کنیم. این روش آزمون ساده‌ترین هست."

    # say L446 bil
    old "Repeat after me, same melody."
    new "بعد از من تکرار کن، همین ملودی."

    # say L451 bil
    old "Your turn."
    new "توی نوبتت."

    # say L455 bil
    old "Jesus Christ. Were you aiming for every wrong note?"
    new "بیل: عیسی مسیح. آیا قصد داشتی همه نت‌ها رو اشتباه بزنی؟"

    # say L456 pla
    old "I told you I can’t sing..."
    new "من به تو گفتم که نمی‌تونم خونم..."

    # say L457 bil
    old "Come on, try again. Feel the words."
    new "دوباره سعی کن. احساس کلمات رو بکن."

    # say L460 bil
    old "Hmm, that wasn’t singing, that was a hate crime against music."
    new "هم، این هم خواندن نبود، این یه جرم نفرت علیه موسیقی بود."

    # say L461 pla
    old "I’ve never had lessons, okay?"
    new "من هیچ درسی نگرفتم، خب؟"

    # say L462 bil
    old "Noted. Voice is a disaster. Moving on."
    new "بیان شد. صدایت یک بلاییه. برویم جلو."

    # say L466 bil
    old "Keyboard. C major scale. Slow and clean."
    new "پیانو. مقیاس دو گام بزرگ. آهسته و بدون خطای."

    # say L467 pla
    old "I think I can do piano... kind of."
    new "فکر کنم می‌تونم پیانو بزنم... نوعاً."

    # say L470 bil
    old "Great! You just played a car alarm."
    new "عالی! تو فقط صدای آلارم خودرو رو باز کردی."

    # say L471 pla
    old "My fingers won’t cooperate."
    new "انگشت‌هام همکاری نمی‌کنند."

    # say L472 bil
    old "Your fingers have the coordination of drunk spaghetti."
    new "انگشتاتون مثل سپاگتی خورده شده هستند."

    # say L473 pla
    old "I’ve never touched a piano in my life..."
    new "من توی زندگی خودم هیچ وقت پیانو نزدم..."

    # say L474 bil
    old "Clearly, try again."
    new "بیشتر آزمایش کن، مشخصاً."

    # say L477 bil
    old "Wrong finger. Index, not pinky."
    new "اشتباه، انگشت شست، نه انگشت کوچک."

    # say L478 pla
    old "Sorry, I guess I don’t have much finger dexterity."
    new "بیل، به نظر می‌رسه انگشت‌هام خیلی روان نیستند."

    # say L479 bil
    old "Oh? No practice with the fingers, huh?"
    new "اوه؟ هیچ تمرینی با انگشت‌ها نداری، هم؟"

    # say L480 pla
    old "Hey!"
    new "هی!"

    # say L481 bil
    old "Just saying. You’ve got zero practice to do... in a lot of areas."
    new "می‌گم. تو در بسیاری از زمینه‌ها هیچ تمرینی نداری..."

    # say L482 pla
    old "This is humiliating."
    new "این خجسته‌کننده است."

    # say L483 bil
    old "You´re right. Keyboard out. Next one."
    new "درست می‌گویی. کیبورد رو بیرون. بعدی."

    # say L487 bil
    old "Ok, let's try with congas. Hands only. Feel the groove."
    new "با کنگاها امتحان کنیم. فقط دست‌ها. ریتم رو حس کن."

    # say L488 bil
    old "Four simple beats. One-two-three-four. Like a heartbeat."
    new "چهار ضرب ساده. یک-دو-سه-چهار. مثل ضربان قلب."

    # say L489 pla
    old "I got this."
    new "من اینو در می‌یابم."

    # say L493 bil
    old "You're rushing a little... No problem. Try again."
    new "تو کمی سریع هستی... مشکلی نداره. دوباره امتحان کن."

    # say L494 pla
    old "Uhh ok..."
    new "اوه خب..."

    # say L497 bil
    old "Hmm, you’re dragging a little now."
    new "هم، حالا کمی آهسته‌تر می‌شوی."

    # say L498 bil
    old "All good, here we go."
    new "خوب، برویم."

    # say L501 bil
    old "No, not quite my tempo."
    new "نه، همین همه نیست."

    # say L502 pla
    old "What does that even—"
    new "این چه معنی داره—"

    # say L507 pla
    old "Uhh... I... I d- don’t kn-"
    new "اوه... من... من ن- نمی‌دونم"

    # say L508 bil
    old "Tell me are you a rusher, are you a dragger, or are you going to be ON MY FUCKING TIME!?"
    new "بگو، تو یه سریع‌کاری هستی، یه کش‌کشی، یا می‌خوای روی زمانِ خونه‌مو باشی؟!"

    # say L509 pla
    old "W- what?!"
    new "W- چه؟!"

    # say L510 bil
    old "Ugh... Nevermind. Mostly. Rhythm is dead."
    new "اوه... فراموش کن. بیشتر. ریتم مرده."

    # say L515 pla
    old "This is pointless. I suck at everything."
    new "این هیچ جوره. من تو همه چیز خوب نیستم."

    # say L516 pla
    old "I’m just gonna embarrass you in front of the whole school."
    new "من فقط می‌خوام تو رو جلوی همه مدرسه خجستون بکنم."

    # say L518 pla
    old "I’m dragging you down. You saw those girls. They’re pros."
    new "من تو رو پایین می‌برم. دیدی آن دختران. اونا حرفه‌ای هستن."

    # say L519 pla
    old "I’m the weak link. Maybe you should just go solo."
    new "من ضعیف‌ترین پیوند هستم. شاید باید فقط خودت بری."

    # say L520 bil
    old "Are you quitting on me right now?"
    new "حالا تو از من کنار می‌ری؟"

    # say L521 pla
    old "I’m just being realistic."
    new "من فقط واقعیت رو می‌گم."

    # say L522 pla
    old "I don’t want to be the reason you lose."
    new "من نمی‌خوام دلیل شکستت باشم."

    # say L523 bil
    old "You’re the reason I’m even doing this."
    new "تو دلیل هستی که من اصلاً این کار رو انجام می‌دم."

    # say L524 bil
    old "You pushed me. Remember? 'You’ve got talent, don’t hide it.' Ring a bell?"
    new "تو مرا تحریک کردی. به یاد داری؟ «تالنت داری، نه پوشش بدده.» آیا این جمله آشنا به نظر می‌آید؟"

    # say L525 bil
    old "So no. You don’t get to bail when it’s your turn."
    new "پس نه. تو نمی‌تونی وقتی دورت رسید، از کار بیرون بری."

    # say L526 pla
    old "That’s different. You’re actually good."
    new "این جوری هست. تو واقعاً خوبی."

    # say L527 bil
    old "I wasn’t always. And I’m not doing this alone."
    new "همیشه خوب نبودم. و من تنها این کار رو نمی‌کنم."

    # say L528 pla
    old "But I’m useless."
    new "ولی من بی‌فایده هستم."

    # say L529 bil
    old "You’re not useless. You’re untrained. And I’m fixing that."
    new "تو بی‌فایده نیستی. تو تربیت نشستی. و من این مشکل رو حل می‌کنم."

    # say L530 pla
    old "This is gonna be tough... I mean, I basically suck at everything."
    new "این خیلی سخت می‌شه... منظورم اینه که من در همه چیز ضعیفم."

    # say L531 bil
    old "Hmm, maybe not at everything. Wait here."
    new "ممکنه همه چیز رو نباشی. صبر کن همینجا."

    # say L535 bil
    old "This was my dad’s."
    new "این از پاپا بود."

    # say L536 pla
    old "Whoa..."
    new "وای..."

    # say L537 bil
    old "He taught me my first chords on this."
    new "او این رو به من یاد داد."

    # say L539 bil
    old "Now it’s yours to borrow."
    new "الان این به تو قرض داده شده."

    # say L540 pla
    old "Ohh.. I- I’ll be careful."
    new "اوه.. من- من مراقب خواهم بود."

    # say L541 bil
    old "You better. If you break it, I break you."
    new "باید مراقب باشی. اگر شکستی، من تو رو شکستم."

    # say L542 pla
    old "Noted."
    new "درست شد."

    # say L543 bil
    old "We’ll start with three chords. Easiest thing in the world."
    new "ما با سه آکورد شروع می‌کنیم. ساده‌ترین چیز در دنیا."

    # say L544 bil
    old "You’re gonna learn them. Even if I have to sit on you."
    new "تو می‌خوای اینا رو یاد بگیری. حتی اگه بخوام روی تو بنشینم."

    # say L545 pla
    old "That’s... motivational?"
    new "این... انگیزه‌بخش است؟"

    # say L546 bil
    old "Damn right it is."
    new "بله، قطعاً همینه."

    # say L548 bil
    old "Alright. Before we even start real lessons, you need to get familiar with that guitar."
    new "البته. قبل از شروع دروس واقعی، باید با اون گیتار آشنا بشی."

    # say L549 pla
    old "Yeah, I figured. But, what should I actually do with it?"
    new "بله، این هم فکر کردم. ولی، واقعاً چی کاری باش باید بکنم؟"

    # say L550 bil
    old "Well, familiarize yourself with the strings, stop poking the guitar like it’s a wild animal."
    new "خب، با تارهای گیتار آشنا شو، نباید مثل این باشه که گیتار رو مثل حیوان وحشی می‌پوکی."

    # say L551 bil
    old "And please! Use your fingers. Right now they move like you borrowed them from a mannequin."
    new "و لطفاً! از انگشت‌هایت استفاده کن. الان همچون اینه که اونا رو از یک مانکن قرض گرفتی."

    # say L552 pla
    old "Come on, they’re not that bad..."
    new "بیا، خیلی بد نیستند..."

    # say L553 bil
    old "Relly? You need agility. Flexibility. Some kind of life in those fingers."
    new "حقاً؟ تو نیاز به سرعت و انعطاف‌پذیری داری. باید اون انگشت‌هایت رو زنده کرد."

    # say L554 pla
    old "Okay, so... practice the strings? Just messing around with them?"
    new "باشه، پس... رشته‌ها رو تمرین کنم؟ فقط باهاشون بازی کنم؟"

    # say L555 bil
    old "Exactly. Touch them, get used to the tension, the spacing, the feel."
    new "دقیقاً. لمس کن، با تنش و فاصله‌اش آشنا شو، حسش رو بفهم."

    # say L556 bil
    old "Learn what each string does when you press it... without crying."
    new "بیا یاد بگیری که هر تار چه کاری می‌کنه وقتی رویش فشار می‌دهی... بدون اینکه گریه کنی."

    # say L557 pla
    old "Well, I can do that."
    new "خب، می‌تونم اینجوری بکنم."

    # say L558 bil
    old "Good. Because in your current state, I can’t teach you anything yet."
    new "خوب. چون در حالت فعلی، هیچ چیز به تو نمی‌تونم یاد بدم."

    # say L559 pla
    old "That bad, huh?"
    new "اینقدر بد هست، ه؟"

    # say L560 bil
    old "Let’s just say your dexterity is... nonexistent."
    new "بگذار بگم دستت... هیچی نداره."

    # say L561 bil
    old "Which tells me you haven’t used those fingers for anything interesting."
    new "این به من می‌گه که اون انگشت‌هایت هیچ کار جالبی نکرده‌ان."

    # say L562 pla
    old "H- hey..."
    new "ب- بله..."

    # say L563 bil
    old "Point is: practice. Move your fingers up and down the strings. Build some coordination."
    new "نکته اینه: تمرین. انگشتاتو روی تارها بالا و پایین حرکت بد. هماهنگی بساز."

    # say L564 pla
    old "Alright. I’ll work on that."
    new "باشه. روی اون کار می‌کنم."

    # say L565 bil
    old "And once your hands stop embarrassing me, come back."
    new "و وقتی دست‌هایت دیگر خجستن‌باز نباشند، بیا برگرد."

    # say L566 pla
    old "Ok, ok, got it."
    new "باشه، باشه، فهمیدم."

    # say L567 bil
    old "Good. But for today, we’re done."
    new "خوب. ولی برای امروز، تمام شد."

    # say L568 pla
    old "Already?"
    new "الان؟"

    # say L569 bil
    old "Yeah. You should leave before my grandma shows up."
    new "بله. باید قبل از اینکه باباهم بیاد بری."

    # say L570 pla
    old "W-what? Why?"
    new "و-و چرا؟"

    # say L571 bil
    old "I don’t want her finding me here with all these instruments and with you."
    new "من نمی‌خوام بابام اینجا منو ببینه با همه این سازها و تو."

    # say L572 bil
    old "She’ll think I’m getting back into music."
    new "فکر می‌کنه من دوباره به موسیقی برگشتم."

    # say L573 pla
    old "But... what’s wrong with that?"
    new "ولی... اینجاش مشکلی هست؟"

    # say L574 bil
    old "Not your problem. Don’t dig into it."
    new "این مشکل تو نیست. بهش خیال نکن."

    # say L575 pla
    old "Alright... Alright."
    new "باشه... باشه."

    # say L576 bil
    old "So practice. When you're actually ready, come find me."
    new "پس تمرین کن. وقتی واقعاً آماده شدی، بیا به من بگو."

    # say L577 pla
    old "I will. I’ll get better and I’ll be back soon."
    new "بله. من بهتر می‌شوم و زود بر می‌گردم."

    # say L587 pla
    old "It’s really late now, I should leave guitar practice for tomorrow."
    new "الان واقعاً دیره، باید تمرین گیتار رو برای فردا بگذaram."

    # say L590 pla
    old "I’d better let my fingers rest a bit, or they’re gonna start bleeding..."
    new "بهتره انگشت‌هام یه کم استراحت کنن، نمی‌تونن دیگه خونه شن!"

    # say L594 pla
    old "Okay... here we go. First time ever touching a real guitar."
    new "باشه... بیایم. اولین بار که یه گیتار واقعی رو لمس می‌کنم."

    # say L595 pla
    old "This thing’s heavier than it looks."
    new "این چیز سنگین‌تر از آنچه به نظر می‌رسد."

    # say L596 pla
    old "And it smells like old wood... it’s nice though."
    new "و خوشبوی چوب قدیمی داره... ولی خوبه."

    # say L597 pla
    old "Alright... let’s see if those YouTube videos helped at all."
    new "باشه... ببینیم آن ویدیوهای یوتیوب کمکی کردن یا نه."

    # say L598 pla
    old "Watched like three tutorials last night. How hard can open chords be?"
    new "دیروز حدود سه آموزش دیدم. چقدر دشوار می‌تونه بازی با آکورد باشه؟"

    # say L604 pla
    old "Ow! That buzzed like a dying bee."
    new "اوه! اون مثل زنگ زدن حشره‌ای بود."

    # say L605 pla
    old "Strings hurt more than I expected."
    new "ریسمان‌ها بیشتر از آنچه فکر می‌کردم درد می‌کنند."

    # say L606 pla
    old "Let’s try again... second fret, second string... mute the others..."
    new "بیاین دوباره... فریت دوم، رشته دوم... بقیاش رو خاموش کن."

    # say L609 pla
    old "Why do my fingers feel like drunk spaghetti? It´s just like [bil] said."
    new "چرا انگشت‌هام مثل سپاگتی خورده شده‌اند؟ مثل همون چیزی که [bil] گفت."

    # say L610 pla
    old "One chord. ONE chord. Come on, [pla]."
    new "یک آکورد. یک آکورد. بیا، [pla]."

    # say L615 pla
    old "I’m literally the worst guitarist in history. Zero dexterity."
    new "من واقعاً بدترین گیتارباز تاریخ هستم. هیچ لطافتی ندارم."

    # say L616 pla
    old "She’s gonna murder me if I don’t improve."
    new "اگر نبامزلم، او من رو می‌کشد."

    # say L617 pla
    old "({i}But I’m not quitting. Not after she trusted me with this guitar.{/i})"
    new "{i}ولی من نمی‌برم. پس از اینکه اعتمادش رو به من قرار داده برای این گیتار، نمی‌تونم برم. {/i}"

    # say L618 pla
    old "I have to keep practicing."
    new "باید تمرین بیشتر کنم."

    # say L622 pla
    old "Okay... that one almost sounded like an actual chord."
    new "باشه... اون تا تقریباً مثل یه آکورد واقعی بود."

    # say L623 pla
    old "Progress! Tiny, painful progress."
    new "پیشرفت! پیشرفت کوچک و دردناک."

    # say L624 pla
    old "Enough for today. Fingers are officially dead."
    new "برای امروز کافیه. انگشت‌هام رسمی مرده."

    # say L625 pla
    old "Tomorrow I’ll be slightly less terrible."
    new "فردا کمی کمتر بد خواهم بود."

    # say L636 pla
    old "Okay, even if it’s tough, I’ve gotta keep practicing. I need to get better at guitar or Billie’s gonna kill me."
    new "باشه، حتی اگه سخت باشه، باید تمرین بکنم. باید بهتر شم در گیتار، نه بیلی منو خواهد کشت."

    # say L637 pla
    old "My fingers are still sore from last time. Awesome."
    new "انگشت‌هام هنوز از آخر هفته درد می‌کنه. عالی."

    # say L638 pla
    old "Sigh... let’s try this again."
    new "آه... بیایم دوباره امتحان کنیم."

    # say L644 pla
    old "Still buzzing on the high E. Damn it!"
    new "هنوز از هیجان E خیلی خسته‌ام. شیطون!"

    # say L645 pla
    old "Left hand cramps, right hand can’t keep time."
    new "دست چپم خشک شده، دست راستم نمی‌تونه ریتم رو نگه داره."

    # say L646 pla
    old "Come on, come on, again."
    new "بیا، بیا، دوباره."

    # say L649 pla
    old "Rhythm’s all over the place. Why can’t I get this?"
    new "ریتمم همه جا پخش شده. چرا نمی‌تونم اینو بگیرم؟"

    # say L650 pla
    old "I thought I’d be better by now. This is torture."
    new "فکر می‌کردم الان بهتر باشم. این می‌ره خودکشی."

    # say L652 pla
    old "Hmm, one more run through. Clean changes or bust."
    new "هم، یک بار دیگه. تغییرات تمیز یا خداحافظی."

    # say L657 pla
    old "Nope. Still sounds like crap."
    new "نه. هنوز مثل زباله شنیده می‌شود."

    # say L658 pla
    old "Fingers raw, brain fried, and zero improvement."
    new "انگشت‌هام خاموش، مغزم خشک، و هیچ بهبودی."

    # say L659 pla
    old "That’s it for now. Can’t force it."
    new "برای حالا کافیه. نمی‌تونم اجباری کنم."

    # say L660 pla
    old "Tomorrow. Maybe it’ll click tomorrow."
    new "فردا. شاید فردا هم بر می‌خوره."

    # say L671 pla
    old "I’m not getting anywhere on my own. This isn’t working."
    new "من به تنهایی جلو نمی‌رم. این کار کار نمی‌کنه."

    # say L672 pla
    old "({i}I need help. [bil]’s the only one who can teach me.{/i})"
    new "{i} من نیاز به کمک دارم. [bil] تنها کسی هست که می‌تونه منو آموزه. {/i}"

    # say L673 pla
    old "Time to text her. Can’t stay stuck forever."
    new "بهتره پیام بفرستم. نمی‌تونم همیشه گیر کرده باشم."

    # say L674 pla
    old "That’s it for today. Tomorrow, I’m going to her."
    new "امروز همینه. فردا می‌روم به تو."

    # say L683 bil
    old "Hey, you look like someone kicked your puppy."
    new "هی، به نظرت می‌رسه کسی سگ تو رو ضربه زده."

    # say L685 bil
    old "You texted like the world was ending. What's up?"
    new "پیامتو مثل این بود که جهان به پایان رسیده. چه خبر؟"

    # say L686 pla
    old "It's the guitar. I tried... really tried."
    new "گیتاره. سعی کردم... واقعاً سعی کردم."

    # say L687 bil
    old "And?"
    new "و؟"

    # say L688 pla
    old "Nothing. Fingers won't move right, everything buzzes. I'm stuck."
    new "هیچ. انگشت‌هام درست حرکت نمی‌کنن، همه چیز صدای خراش می‌ده. گیر افتادم."

    # say L689 bil
    old "Stuck over just a couple of days? That’s dramatic."
    new "چند روزه خیس شدی؟ این دراماتیک است."

    # say L690 pla
    old "I'm serious. YouTube videos, hours... still crap."
    new "من جدی هستم. ویدیوهای یوتیوب، ساعت‌ها... همچنان خراب."

    # say L691 bil
    old "Okay, okay. Let's fix it. Room. Now."
    new "باشه، باشه. بیای ببینیم چطور این مشکل رو حل کنیم. اتاق. حالا."

    # say L695 bil
    old "Okay, spill. What exactly did you try?"
    new "باشه، بگو. دقیقاً چه چیزی رو امتحان کردی؟"

    # say L696 pla
    old "Well, I watched videos, did the finger positions, strummed, practiced for hours... and still nothing."
    new "خب، ویدیوهایش رو دیدم، موقعیت‌های انگشت‌ها رو انجام دادم، تراپ زدم، ساعت‌ها تمرین کردم... همچنان هیچی."

    # say L697 bil
    old "Okay, relax. You’re not hopeless, just untrained."
    new "باشه، آرامش بده. تو نه امیدبازی، فقط نیاز به آموزش داری."

    # say L698 pla
    old "Hmm, I feel hopeless."
    new "هم، احساس ناامیدی می‌کنم."

    # say L699 bil
    old "Well, it does at first. That's normal. We'll figure it out."
    new "البته، اولین بار همیشه اینطور می‌تونه باشه. این طبیعیه. ما حلش می‌کنیم."

    # say L700 pla
    old "Really?"
    new "وای، واقعاً؟"

    # say L701 bil
    old "Yeah. I'm your coach. Brutal, but we'll get you there."
    new "بله. من مربوطت هستم. سخت، ولی به هدف خواهی رسید."

    # say L702 bil
    old "First, let me show you how it's done. Watch."
    new "اول ببین چجوری انجام می‌شه. نگاه کن."

    # say L709 pla
    old "Holy... you're amazing."
    new "هیولایی... تو عالی هستی."

    # say L710 pla
    old "It looks so easy when you do it."
    new "وقتی تو انجام میدی به نظر خیلی آسون میاد."

    # say L711 bil
    old "It’s just practice. Your turn."
    new "فقط تمرینه. حالا تو."

    # say L715 pla
    old "Uhh, like... this?"
    new "اوه، مثل... این؟"

    # say L718 bil
    old "Buzzing. Press harder on the strings."
    new "پیش زد. روی تارها فشار بیشتر بده."

    # say L719 pla
    old "Ow... got it."
    new "اوه... گرفتم."

    # say L723 bil
    old "Better. Still ugly, but better."
    new "بهتر. هنوز خشن، اما بهتر."

    # say L724 bil
    old "Try shifting your hand a bit. Find a spot that actually sounds alive."
    new "دستت رو کمی جابه‌جا کن. جایی پیدا کن که واقعاً زنده باشه."

    # say L725 pla
    old "Switching... crap."
    new "تغییر می‌کنم... شیطان."

    # say L729 bil
    old "Slow. Don't rush the change."
    new "آرام. تغییر رو آرام آرام انجام بده."

    # say L730 pla
    old "It's like my fingers hate me."
    new "انگشت‌هام از من نفرت دارن."

    # say L731 bil
    old "They're lazy. Make 'em work."
    new "لیزی هستن. بیا، کارشون رو انجام بده."

    # say L732 pla
    old "Like this...."
    new "مثل این..."

    # say L735 bil
    old "No, you're not covering the strings properly."
    new "نه، تو ریسمان‌ها رو درست پوشونی."

    # say L736 bil
    old "Closer. But your fingers are stiff as boards."
    new "نزدیک‌تر. اما انگشت‌هایت مثل تخته‌های خشک هستند."

    # say L737 pla
    old "Yeah... no dexterity."
    new "بله... هیچ تحرکی ندارم."

    # say L738 bil
    old "Reset your hand. Try the last position. Light touch, then press."
    new "دستت رو باز کن. آخرین موقعیت رو امتحان کن. لمس لطیف، بعد فشار بده."

    # say L739 pla
    old "Uhh okay..."
    new "اوه خب..."

    # say L743 pla
    old "I- I can't. This is stupid."
    new "من- من نمی‌تونم. این خیلی حماقت‌آمیزه."

    # say L747 pla
    old "You're wasting your time with me."
    new "وقتت رو با من تلف می‌کنی."

    # say L748 pla
    old "You know what? I should probably go."
    new "من احتمالاً باید برسم."

    # say L751 bil
    old "No."
    new "نه."

    # say L754 pla
    old "B- but-"
    new "ب- ولی"

    # say L760 bil
    old "You're frustrated. I get it."
    new "تو ناراحتی. من می‌فهمم."

    # say L761 pla
    old "I suck. Completely."
    new "من خوب نیستم. کاملاً."

    # say L762 bil
    old "You don't suck. It's hard. Not everyone even tries."
    new "تو خوب نیستی. سخته. همه هم اصلاً امتحان نمی‌کنند."

    # say L763 pla
    old "I know... but I’m failing so bad."
    new "می‌دونم... ولی خیلی بد شکست می‌خورم."

    # say L764 bil
    old "Trying and failing is braver than not trying at all."
    new "تلاش کردن و شکست خوردن جراتانه‌تر از هیچ تلاشی نکردن است."

    # say L765 pla
    old "Feels like I'm just letting you down."
    new "می‌تونم فقط تو رو بخیبانم."

    # say L766 bil
    old "You’re not. You’re working hard, and that means a lot."
    new "تو نیستی. تو سخت کار می‌کنی و این خیلی مهمه."

    # say L767 pla
    old "But I have no talents. Zero. I'm good at... existing?"
    new "ولی من هیچ توانایی ندارم. صفر. من فقط در... زنده موندن خوبم؟"

    # say L768 bil
    old "What do you mean you have no talents? Now you’re just being an idiot, you’ve got plenty."
    new "من قصه‌ای نمی‌خوام که موهبت نداری. حالا فقط داری حماقت می‌کنی، موهبتهایت خیلی هست."

    # say L769 bil
    old "You're friendly. Always helping everyone, even when it's inconvenient."
    new "تو دوست‌داشتنی هستی. همیشه به همه کمک می‌کنی، حتی وقتی سخته."

    # say L770 pla
    old "I guess..."
    new "بیل، من حدس می‌زنم..."

    # say L771 bil
    old "Stubborn too. Look at this, we wouldn’t even be in this mess if you hadn’t pushed and pushed, even when I almost hit you."
    new "استقامت‌دار هم هستی. ببین اینجا، اصلاً اگه تو نمی‌زدی و نمی‌کشیدی، حتی وقتی من تقریباً تو رو ضربه زدم، ما اصلاً تو این مشکل نمی‌بودیم."

    # say L772 pla
    old "Yeah, but that backfired."
    new "بله، اما این بازم برگشت."

    # say L773 bil
    old "It didn't. It got us here."
    new "نه، این ما رو به اینجا برده."

    # say L774 bil
    old "And you're funny. That dying cat voice? Gold."
    new "و تو خنده‌داری. آن صدای گربه‌ای می‌میره، طلایی."

    # say L775 pla
    old "Those aren’t really talen-"
    new "این‌ها واقعاً مهارت‌هایی نیستند که..."

    # say L777 bil
    old "Also... you’re kinda cute, in that awkward, pushy way."
    new "همچنین... تو به نوعی لطیفی هستی، اون طوری ناامید و پیش‌بر."

    # say L778 pla
    old "A-are you serious?"
    new "می‌گی‌ی؟ جدی هستی؟"

    # say L779 bil
    old "And now that I think about it... you’ve got a huge talent down there, huh..."
    new "و حالا که فکر می‌کنم... تو خوب تalent داری، همینجوری..."

    # say L781 bil
    old "Well... I mean, you do have talents after all. You see it now?"
    new "خب... منظورم اینه که تو هم توانایی‌هایت رو داری. حالا دیدی؟"

    # say L782 pla
    old "Uhh... I guess, but what about the guitar?"
    new "اوه... بله، اما گیتار چطور؟"

    # say L783 bil
    old "Well, guitar's just one more to unlock. But those fingers... they really need waking up."
    new "خب، گیتار فقط یکی دیگه برای باز کردنه. ولی اون انگشت‌ها... واقاً نیاز به بیدار شدن دارن."

    # say L785 pla
    old "Yeah, I know... but how am I supposed to do that?"
    new "بله، می‌دونم... ولی من چجوری باید این کار رو بکنم؟"

    # say L787 bil
    old "You know what, I have an idea."
    new "دیوید، من یه ایده دارم."

    # say L789 pla
    old "W- whaat a- are you d- doing?"
    new "و- وایی ا- اینجا چ- چه کاری می‌کنی؟"

    # say L791 bil
    old "Well, I think you need some extra motivation with those sausage fingers, you know?"
    new "خب، فکر می‌کنم نیازی به تحریک بیشتری برای اون انگشت‌های سوسیسی‌ت داری، می‌فهمی؟"

    # say L794 pla
    old "Hey, what the Fuc-!"
    new "هی، چه کاری داری؟!"

    # say L795 bil
    old "Shh. Focus on your fingers. Feel the touch."
    new "ش ه. روی انگشت‌هایت تمرکز کن. لمسش رو حس کن."

    # say L796 pla
    old "[bil]... this is..."
    new "[bil]... این هست..."

    # say L797 bil
    old "Relax... Focus on the task. Circle gently, don't rush it."
    new "آرام... روی کار تمرکز کن. به آرامی دور بزن، اعجال نکن."

    # say L800 bil
    old "Mmm... that's better. How do they feel to you, [pla]? Soft enough for your liking?"
    new "ممنون... اینجوری بهتره. برای تو چطور هستن، [pla]؟ آیا نرم کافی هستن؟"

    # say L801 pla
    old "They're... so soft, [bil]. It feels amazing."
    new "آنها... خیلی نرم هستن، [bil]. احساسش عالیه."

    # say L802 bil
    old "Heh, good answer. Now, add a bit more pressure. Let's see if you can actually handle the real thing."
    new "هه، جواب خوبی. حالا، فشارش رو کمی بیشتر کن. ببینی در واقع می‌تونی با چیز واقعی هم برخورد کنی یا نه."

    # say L803 pla
    old "O- okay."
    new "ب-آره."

    # say L805 pla
    old "Like this? Am I doing it right?"
    new "مثه این؟ درست انجام میدم؟"

    # say L806 bil
    old "Nngh—yeah. Exactly like that..."
    new "نه—بله. دقیقاً همین‌جور..."

    # say L807 bil
    old "See? you're learning."
    new "ببین؟ یادت می‌آید."

    # say L809 bil
    old "Mmm, nice. Now pick up the pace. Let’s see if you can keep your finesse while speeding up."
    new "ممنون، خوبه. حالا سرعت رو بالا ببر. ببینی می‌تونی همچین سرعتی با دقت ادامه بدی یا نه."

    # say L811 bil
    old "Tell me how they feel right now."
    new "بگو چطور هستن الان."

    # say L813 pla
    old "Hot... heavy... and every time I squeeze they bounce a little. It's insane."
    new "گرم... سنگین... و هر باری که فشار می‌دم یک کم جابجا می‌شن. خودت نمی‌تونی باور کنی."

    # say L814 bil
    old "Good feedback. Noted."
    new "بازخورد خوب. ثبت شد."

    # say L815 bil
    old "Keep going. Feel the rhythm."
    new "ادامه بده. ریتم رو حس کن."

    # say L816 pla
    old "I... I feel something."
    new "من... من چیزی حس می‌کنم."

    # say L817 bil
    old "Yeah, I noticed. Looks like your other talent’s waking up, huh?"
    new "بله، من هم متوجه شدم. به نظر می‌رسد که موهبت دیگر هم بیدار شده، همین‌جوری؟"

    # say L819 pla
    old "Oh shit... sorry!"
    new "اوه شیطون... معذرت!"

    # say L820 bil
    old "Oh, come on, you're literally groping my tits..."
    new "بیا، تو واقعاً دست‌هایت رو بر سینه‌هام می‌گذونی..."

    # say L822 bil
    old "You know what? Come here, let me show you one of my hidden talents too..."
    new "می‌دونی چی؟ بیا، برات یکی از هنرهای پنهانم رو نشون بدم..."

    # say L823 bil
    old "This throat does more than just sing, you know?"
    new "این حلقه فقط برای خواندن نیست، می‌دونی؟"

    # say L828 pla
    old "Hooooly shit!"
    new "هولی شیت!"

    # say L829 bil
    old "So... you like my other talent too, huh?"
    new "پس... تو هم این توانایی دیگه رو دوست داری، همین‌جور؟"

    # say L830 pla
    old "Oh, yeah, it feels so good..."
    new "بله، خیلی خوبه..."

    # say L831 bil
    old "Mmm... I’ve missed this since that stupid spin-the-bottle game."
    new "ممنون... اینو از آن بازی سخن‌پردازی چرخه‌ای می‌گذارست."

    # say L832 pla
    old "You... you have?"
    new "تو... تو هم داشتی؟"

    # say L833 bil
    old "Shut up. Let me show you my real talent."
    new "بیل: بس کن. بیای برات نشون بدم تalent واقعی من چیه."

    # say L861 bil
    old "So... I guess we made some progress today."
    new "پس... به نظر می‌رسه امروز پیشرفتی کردیم."

    # say L862 pla
    old "Oh yeah, a lot."
    new "بله، خیلی."

    # say L864 bil
    old "I meant with the guitar."
    new "من قصد داشتم درباره گیتار بگم."

    # say L865 pla
    old "Oh, right. Yes. That too."
    new "اوه، درسته. بله. آن هم."

    # say L866 bil
    old "And from what I see, you definitely have plenty of motivation now."
    new "و از آنچه می‌بینم، الان قطعاً انگیزه زیادی داری."

    # say L867 pla
    old "Oh, that’s for sure."
    new "بله، قطعاً."

    # say L868 bil
    old "Good. Because that whole quit-the-contest nonsense better be gone."
    new "خوب. چون اون حرف‌های خروج از مسابقه باید همین الان برداشته شده باشن."

    # say L869 pla
    old "Of course. I’m not quitting."
    new "البته. من نمی‌خوام بیوفم."

    # say L870 bil
    old "Perfect. Then keep practicing at home like you’ve been doing."
    new "البته. بعد هم مثل همیشه در خونه تمرین کن."

    # say L871 bil
    old "Your fingers still need work... a lot of work."
    new "انگشتانت هنوز نیاز به تمرین داره... خیلی تمرین."

    # say L872 pla
    old "I’ll practice every day. I actually want to improve."
    new "من هر روز تمرین می‌کنم. واقعاً می‌خوام بهتر شم."

    # say L873 bil
    old "Hmm. And if you need something, just tell me."
    new "Hmm. اگر نیازت به چیزی بود، فقط به من بگو."

    # say L874 pla
    old "I will. Thanks... seriously."
    new "بله، ممنون... جدیان."

    # say L875 bil
    old "Alright. Let’s leave it here for today."
    new "البته. برای امروز همین باشه."

    # say L876 bil
    old "Go home before my grandma shows up."
    new "بزن خانه برو قبل از اینکه بабا جان بیاد."

    # say L877 pla
    old "Yeah, I should. I’ll come back soon."
    new "بله، باید برم. زودی بر می‌گردم."

    # say L878 bil
    old "You better."
    new "باید برو."

    # say L889 pla
    old "Okay... it’s still hard, but I can’t skip practice now."
    new "باشه... هنوز سخته، ولی نمی‌تونم تمرین رو بگذaram."

    # say L890 pla
    old "I’m not great yet, but I’m not totally hopeless either."
    new "هنوز خوب نیستم، اما هیچ جور بی‌امید نیستم هم."

    # say L891 pla
    old "Alright. Let’s see if I can do this a little better today."
    new "باشه. ببینم امروز بتونم این کار رو بهتر کنم."

    # say L898 pla
    old "Hey... that one didn’t buzz as bad."
    new "هی… اون تاش خوب نبود، ولی بد هم نبود."

    # say L899 pla
    old "Still not perfect... but it sounded more like a chord this time."
    new "هنوز کامل نیست... اما این بار مثل آکوردی شد."

    # say L900 pla
    old "Hand’s tired, but it’s moving better."
    new "دست خسته شده، اما بهتر حرکت می‌کنه."

    # say L901 pla
    old "Ok, again. Same thing."
    new "بیا، دوباره. همین کار رو بکن."

    # say L905 pla
    old "Rhythm’s still messy... but I didn’t completely lose it."
    new "ریتم هنوز درهم‌ریخته... اما کاملاً از دست نرفته."

    # say L906 pla
    old "I can actually feel where I mess up now."
    new "الان واقعاً می‌تونم جایی که اشتباه می‌کنم رو حس کنم."

    # say L907 pla
    old "({i}Okay... that’s something. I didn’t feel that before.{/i})"
    new "{i}خب... این هم چیزی است. قبلاً این حس رو نداشتم.{/i}"

    # say L908 pla
    old "One more time. Let’s make it cleaner."
    new "بیا دوباره. بیایم این بار بهتر کنیم."

    # say L914 pla
    old "Still rough... but not total garbage."
    new "هنوز خشن... اما نه همینجور بد."

    # say L915 pla
    old "That sounded... closer."
    new "این بهتر شد... نزدیک‌تر."

    # say L916 pla
    old "Yeah. Not there yet, but it’s moving."
    new "بله. هنوز رسیده نیست، اما در حال حرکت است."

    # say L917 pla
    old "Enough for today. Don’t want to ruin what I actually did right."
    new "برای امروز کافیه. نمی‌خوام آنچه درست کردم رو خراب کنم."

    # say L918 pla
    old "Tomorrow... let’s see if it gets even better."
    new "فردا... ببینیم آیا هنوز بهتر می‌شه."

    # say L931 bil
    old "Oh, look who showed up."
    new "اوه، نگاه کن کی اومده."

    # say L932 pla
    old "Yeah, I wanted to practice with you again."
    new "بله، می‌خواستم دوباره با تو تمرین کنم."

    # say L933 bil
    old "Right, you texted about that. How's it going?"
    new "بله، تو درباره این پیام دادی. حالا چطوره؟"

    # say L934 pla
    old "Uhh, better than before... kinda."
    new "اوه، بهتر از قبل... نوعاً."

    # say L935 bil
    old "Oh really? Hah. I need to see that to believe it."
    new "اوه واقعاً؟ ها. من باید ببینم تا باور کنم."

    # say L936 bil
    old "Come on. Let’s go to my room and talk properly."
    new "بیا. برویم به اتاقم و صحبت کنیم به درستی."

    # say L939 bil
    old "Okay, spill. What did you do these days?"
    new "بیا، بگو. این روزها چه کردی؟"

    # say L940 pla
    old "Honestly... a lot. I practiced every day. My fingers feel way more alive now."
    new "Honestly... خیلی. هر روز تمرین می‌کردم. انگشت‌هام الان خیلی زنده‌تر احساس می‌کنم."

    # say L941 bil
    old "Good. About time they woke up from the dead."
    new "خوب. وقت خوبی هست که از مردگان بیدار شدن."

    # say L942 pla
    old "Yeah, but... I feel like I hit a wall again."
    new "بله، اما... به نظر می‌رسه دوباره به دیوار خوردم."

    # say L943 bil
    old "Hmm. Typical. Let me see. Take the guitar."
    new "Hmm. معمولیه. بیا، برام گیتار رو بده."

    # say L949 pla
    old "Alright... here goes."
    new "البته... حالا می‌تونم شروع کنم."

    # say L953 bil
    old "Huh... pressure’s steadier. The tone’s still messy, but at least you’re not fighting the guitar anymore."
    new "هی… فشار ثابت‌تره. صدای هنوز درهم‌پرده، ولی حداقل تو دیگه با گیتار جنگ نمی‌کنی."

    # say L954 pla
    old "Yeah, I feel more control. I can switch positions smoother now."
    new "بله، حس می‌کنم بیشتر کنترل دارم. می‌توانم موقعیت‌ها رو به سادگی تر جابجا کنم."

    # say L955 bil
    old "Still too slow. But hey, your hand is finally acting like it belongs to a living person."
    new "هنوز خیلی آهسته. ولی بله، دستت بالاخره مثل دست انسان زنده به نظر می‌رسه."

    # say L956 bil
    old "Not bad. Your fingers actually woke up this time."
    new "حالت بد نیست. این بار انگشتات واقعاً بیدار شدند."

    # say L957 pla
    old "Yeah, but that’s the problem. I think I hit my limit again. I can’t push past this alone."
    new "بله، اما همین هست مشکلش. فکر کنم دوباره به مرز خودم رسیدم. نمی‌تونم تنها از این مرز عبور کنم."

    # say L960 pla
    old "Honestly... I was hoping you could help me practice again."
    new "Honestly... فکر کردم می‌تونی به من کمک کنی تا دوباره تمرین کنم."

    # say L961 bil
    old "Huh?"
    new "ه؟"

    # say L962 bil
    old "So that’s why you came back. You want more 'practice'."
    new "پس همینجور برگشته‌ای. می‌خوای دوباره تمرین کنی."

    # say L963 pla
    old "Exactly. Something a bit more advanced. Something that forces my fingers to—"
    new "دقیق هست. چیزی که یک قدر پیشرفته‌تر باشه. چیزی که انگشت‌هایم رو مجبور کنه—"

    # say L964 bil
    old "Oh, I see where this is going."
    new "اوه، متوجه شدم کجایی می‌ری."

    # say L965 bil
    old "Yeah, sure. More 'advanced practice', right?"
    new "بله، البته. تمرین پیشرفته‌تر، درسته؟"

    # say L966 pla
    old "Exactly! I need something beyond the basics. I’m not improving anymore."
    new "دقیق هست! نیاز دارم به چیزی فراتر از مبانی. دیگه پیشرفت نمی‌کنم."

    # say L967 bil
    old "Alright, alright, I get it. No need to act innocent."
    new "باشه، باشه، فهمیدم. نیازی نیست بروی نایو بازی کنی."

    # say L969 bil
    old "Come on, don’t be shy. I know what you’re actually here for."
    new "بیا، نباش خجالتی. میدونم واقعاً برای چی اومدی."

    # say L971 pla
    old "No, no, that’s not—"
    new "نه، نه، این جوری نیست—"

    # say L972 bil
    old "Stop overthinking. You came to practice."
    new "توقف از فکر کردن زیاد. اومدی برای تمرین."

    # say L973 bil
    old "So let’s practice."
    new "پس بیاین تمرین کنیم."

    # say L976 bil
    old "There. Full palms first. feel how soft they are when you take your time."
    new "اونجا. اول دست‌هایت رو با نرمی بگذون. ببین چقدر نرم هستن وقتی صبر می‌کنی."

    # say L978 bil
    old "Keep that rhythm. Don't rush the ‘practice’."
    new "این ریتم رو حفظ کن. به تمرین عجله نکن."

    # say L979 pla
    old "Fuck... [bil], they feel unreal."
    new "فوک... [bil]، اونقدر نرم هستن."

    # say L980 bil
    old "Limited edition, baby."
    new "نسخه محدود، عزیزم."

    # say L981 bil
    old "Come on, a little more pressure. You know what I like."
    new "بیا، فشار کمی بیشتر. می‌دونی من چی می‌خوام."

    # say L983 pla
    old "L-like... this?"
    new "مثلاً... اینجوری؟"

    # say L984 bil
    old "Yes... perfect. You're doing better than I expected."
    new "بله... کامل. تو بهتر از آنچه انتظار داشتم انجام می‌دهی."

    # say L985 pla
    old "Your nipples... they're getting hard. Does that mean I'm doing good?"
    new "نیپ هایت... سخت می‌شوند. این به معنی اینه که خوب کار می‌کنم؟"

    # say L986 bil
    old "Means you’re not completely hopeless. Keep going."
    new "باید بگم تو خیلی بد نیستی. ادامه بده."

    # say L987 bil
    old "Okay, new part. First time for this one."
    new "باشه، بخش جدید. اولین بار برای این کار."

    # say L988 bil
    old "Nipples only. Start super gentle... just the tips of your fingers."
    new "نیپل‌ها فقط. خیلی نرم شروع کن... فقط نوک انگشت‌هایت رو بکار ببر."

    # say L990 pla
    old "T-they're so sensitive... I can feel them hardening more."
    new "م-m-می‌تونی خیلی حساس هستن... حس می‌کنم سخت‌تر می‌شنن."

    # say L991 bil
    old "Good. Now a little harder. Build it up, don't rush."
    new "خوب. حالا یک کم سخت‌تر. آرام آرام افزایش بده، نبگرد."

    # say L992 pla
    old "A-are you sure?"
    new "مطمئنی؟"

    # say L993 bil
    old "Harder, [pla]. Don’t be scared. Make me feel it."
    new "سخت‌تر، [pla]. نباید ترسی داشته باشی. منو احساس کن."

    # say L995 pla
    old "L-like this? God, you're starting to breathe heavier..."
    new "مثلاً اینجوری؟ خدا، نفست شروع کردی تیزتر شدن..."

    # say L996 bil
    old "Yes—fuck—keep going. Harder now, make it count."
    new "بله—شیطون—ادامه بده. الان سخت‌تر، برام احساسش بده."

    # say L997 bil
    old "({i}Fuck... he’s careful but he’s getting it...{/i})"
    new "{i}شیطون... او مرا می‌رساند اما مرا محافظت می‌کند...{/i}"

    # say L998 pla
    old "I- I don’t want to hurt you..."
    new "من- من نمی‌خوام تو رو آسونم..."

    # say L999 bil
    old "You won’t. Trust me. Slowly harder each time."
    new "تو نخواهی. به من اعتماد کن. هر بار کمی سریع‌تر و سخت‌تر."

    # say L1001 bil
    old "({i}Shit, for a first-timer...{/i})"
    new "{i} شیطون، برای یک اول‌تیمر... {/i}"

    # say L1002 pla
    old "I-I can feel you tensing... come for me, [bil]?"
    new "من-من حس می‌کنم تو تنیده می‌شی... برای من بیا، [bil]؟"

    # say L1003 bil
    old "Harder—now—ahh—fuck—yes—!"
    new "سخت‌تر— الان— اوه— فک— بله—!"

    # say L1005 bil
    old "Okay... that was more than enough warm up for your fingers."
    new "باشه... این برای گرم کردن انگشت‌هایت کافی بود."

    # say L1006 pla
    old "Y- yeah... definitely intense."
    new "بله... قطعاً شدید بود."

    # say L1008 bil
    old "So? Feeling more agile now?"
    new "پس؟ حالا سریع‌تر حس می‌کنی؟"

    # say L1009 pla
    old "Honestly... a little. But... I don’t think that alone will fix everything."
    new "Honestly... یه کم. ولی... فکر نمی‌کنم فقط این کار همه چیز رو حل کنه."

    # say L1010 bil
    old "Oh, really?"
    new "اوه، واقعاً؟"

    # say L1011 pla
    old "Yeah. I mean... thanks for the help, seriously, but I don’t think that kind of practice is enough to improve my speed or accuracy."
    new "بله. منظورم اینه... ممنونم برای کمکت، جدی هستم، ولی فکر نمی‌کنم این نوع تمرین کافی باشه تا سرعت و دقت من بهبود بیابه."

    # say L1012 bil
    old "Huh."
    new "هuh."

    # say L1013 bil
    old "So what, now you want something even more advanced?"
    new "پس چه کاری، حالا می‌خوای چیزی پیشرفته‌تر؟"

    # say L1014 pla
    old "Well— I mean— I just—"
    new "خب— من قصد نداشتم— من فقط—"

    # say L1015 bil
    old "No. No, no, no. Don’t even think I’m giving you a blowjob every time you struggle with a chord."
    new "نه. نه، نه، نه. حتی فکر نکن هر بار که با یه آکورد سختی داری من به تو جنسی کنم."

    # say L1016 pla
    old "Wait— what? No! That’s not what I meant!"
    new "پیش— چی؟ نه! این جوری منظورم نبود!"

    # say L1017 bil
    old "Good. Because I’m not doing that every time you show up."
    new "خوب. چون هر بار که اومی من این کار رو نمی‌کنم."

    # say L1018 pla
    old "N- no! I swear I wasn’t asking for that!"
    new "ن- نه! قسمت نمی‌خورم که من همچین چیزی رو نمی‌خواستم!"

    # say L1019 bil
    old "Then what were you asking for?"
    new "پس تو برای چی می‌خواستی؟"

    # say L1020 pla
    old "I just... genuinely need help finding a better exercise. Something real. Something useful for my fingers."
    new "من فقط... واقعاً به دنبال یک تمرین بهتر هستم. چیزی واقعی. چیزی مفید برای انگشت‌هام."

    # say L1021 bil
    old "So you’re... actually serious."
    new "پس تو... واقعاً جدی هستی."

    # say L1022 pla
    old "Yes. I figured you’d know something. A technique, an exercise, something."
    new "بله. فکر کردم می‌دونی چیزی. یه تکنیک، یه تمرین، هر چیزی."

    # say L1023 pla
    old "Exactly, that’s what I’m looking for."
    new "دقیقاً، همین هست که دنبالش می‌گردم."

    # say L1024 bil
    old "Okay, okay, Hmm, then let me think."
    new "باشه، باشه،Hmm، بیاین فکر کنم."

    # say L1025 bil
    old "Hmm... something advanced for finger dexterity... something that forces your hand to adapt..."
    new "Hmm... چیزی پیشرفته برای حس و توانایی انگشت‌ها... چیزی که دستت رو مجبور به تطبیق کنه..."

    # say L1026 pla
    old "Yeah. Exactly."
    new "بله. دقیقاً."

    # say L1028 bil
    old "Oh..."
    new "اوه..."

    # say L1029 bil
    old "...I have an idea."
    new "...من یه ایده دارم."

    # say L1030 pla
    old "You do? What is it?"
    new "تو هم چنین ایده‌ای داری؟ چیه؟"

    # say L1031 bil
    old "You’ll see. Just stay there."
    new "ببینی. فقط جایت باش."

    # say L1033 pla
    old "So... what do you have in mind?"
    new "پس... تو چه کاری به ذهن‌ت آورده؟"

    # say L1034 bil
    old "Something advance. Trust me."
    new "چیزی پیشرفته. به من اعتماد داشت."

    # say L1036 pla
    old "W- what are you doing?!"
    new "ب- ب- بچه‌ها، تو چه کاری می‌کنی؟!"

    # say L1037 bil
    old "Relax. This is the training. Just extreme level."
    new "آرام باش. این تمرینه. فقط سطح پیشرفته."

    # say L1040 bil
    old "Now... use those fingers. Start slow."
    new "الان... اون انگشت‌ها رو بکار ببر. آرام شروع کن."

    # say L1042 bil
    old "Shh. Focus. Circle the clit gently."
    new "ش ه. تمرکز کن. با لطف دور کلیتوریس رو بچرخون."

    # say L1046 bil
    old "Mmm... good. Now slide one in."
    new "ممنون... حالا یکی رو بیاورد."

    # say L1047 pla
    old "Like... this?"
    new "مثل این؟"

    # say L1048 bil
    old "Yes... curl it. Find the spot."
    new "بله... آن را خم کن. جای خوبی پیدا کن."

    # say L1050 bil
    old "Faster now. Add another finger."
    new "سریع‌تر. انگشت دیگری هم اضافه کن."

    # say L1052 pla
    old "[bil]... you're squeezing..."
    new "[bil]... تو داری فشار می‌دهی..."

    # say L1053 bil
    old "That's it. Rub harder."
    new "این هست. سریع‌تر بفرک."

    # say L1054 pla
    old "Fuck... you're dripping."
    new "فکر کنم تو داری خیس می‌شی."

    # say L1055 bil
    old "Deeper. Don't stop."
    new "عمیق‌تر. متوقف نشو."

    # say L1057 bil
    old "Harder... make me cum."
    new "سخت‌تر... برام سر بزن."

    # say L1060 pla
    old "Oh fuck... cum for me."
    new "اوه خدای من... برای من خروجی بده."

    # say L1063 pla
    old "Yes... feel it all."
    new "بله... همه‌اش رو حس کن."

    # say L1064 bil
    old "Oh god... that's it."
    new "اوه خدای من... همینه."

    # say L1072 bil
    old "Alright, THAT was definetly an advance training..."
    new "البته، اونا حتماً آموزش پیشرفته بود."

    # say L1073 pla
    old "Y-yeah... that was... a lot."
    new "بله... خیلی بود."

    # say L1074 bil
    old "But hey, your fingers definitely kept up this time."
    new "ولی هی، این بار انگشت‌هات قطعاً همراه بود."

    # say L1075 pla
    old "I did feel a big difference. Seriously."
    new "اونجا هم خیلی تفاوت حس کردم. جدی."

    # say L1076 bil
    old "Good. Then keep practicing at home. Use what you learned today."
    new "خوب. بعداً در خونه تمرین کن. از آنچه امروز یاد گرفتی استفاده کن."

    # say L1077 bil
    old "If you get stuck again, come back. We’ll figure something out."
    new "اگر دوباره گیر افتادی، بیا. راه حلی پیدا می‌کنیم."

    # say L1078 pla
    old "I will. Thanks... for everything."
    new "بله، ممنون... از همه چیز."

    # say L1079 bil
    old "Alright, event’s over. Go home before my grandma arrives."
    new "البته، رویداد تمام شد. برو خونه قبل از اینکه بابا من برسه."

    # say L1091 bil
    old "Finally. Took you long enough."
    new "نهایی. وقتت خیلی طول کشید."

    # say L1092 pla
    old "You texted me. Said it was important."
    new "تو پیام دادی. گفتی مهمه."

    # say L1093 bil
    old "Yeah. Because it is. The teacher called me."
    new "بله. چون مهمه. معلم به من تماس داد."

    # say L1094 pla
    old "Wait... what? Already?"
    new "بیلی، صبر کن... چه کاری؟ قبلاً؟"

    # say L1095 bil
    old "She wants to schedule our supervised practice."
    new "می‌خواد زمانهای تمرین نظارت‌شدهمون رو تعیین کنه."

    # say L1096 pla
    old "Like... with her? Watching me? Listening to me?"
    new "مثل... با او؟ از من نگاه می‌کنه؟ به من گوش می‌ده؟"

    # say L1097 bil
    old "Mhm. Exactly that."
    new "مهمون. دقیقاً همین کار."

    # say L1098 pla
    old "Oh man... I’m not ready for that."
    new "اوه مرد... من برای این آماده نیستم."

    # say L1099 bil
    old "That’s why I told you to come."
    new "برای همین تو رو خواستم بیا."

    # say L1100 bil
    old "We need to polish you up before she sees anything."
    new "باید تو رو قبل از اینکه او هر چیزی ببینه، آماده کنم."

    # say L1101 pla
    old "I don’t know if I can—"
    new "نمی‌دونم اگه بتونم—"

    # say L1102 bil
    old "Stop. You’re doing it. We’re doing it. End of story."
    new "توقف. تو اینجوری هستی. ما اینجوری هستیم. داستان تمام شد."

    # say L1103 bil
    old "Come on. Room. We’ll talk there."
    new "بیا. اتاق. اونجا حرف می‌زنیم."

    # say L1108 bil
    old "Alright. Tell me. How’ve you been since last time?"
    new "باشه. بگو. از آخر بار چطور بودی؟"

    # say L1109 pla
    old "Honestly? Way better. After all that... 'advanced practice'... I definitely improved."
    new "صراحیت؟ خیلی بهتر. بعد از همه آن... تمرین‌های پیشرفته... قطعاً بهبود یافتم."

    # say L1110 bil
    old "Oh, I bet you did."
    new "او، قطعاً."

    # say L1112 bil
    old "Yeah, yeah. Show me."
    new "بله، بله. به من نشون بده."

    # say L1116 pla
    old "Okay... here goes."
    new "باشه... حالا می‌تونی ببینی."

    # say L1118 bil
    old "Huh. Look at that."
    new "هی. نگاه کن."

    # say L1119 bil
    old "Hand’s lighter. Movement’s cleaner. You’re not strangling the strings anymore."
    new "دست خفیف‌تره. حرکت هم پاک‌تره. دیگه ریسمان‌ها رو سفت نمی‌کنی."

    # say L1120 pla
    old "Yeah, I feel the difference. And switching positions isn’t torture now."
    new "بله، تفاوت رو می‌تونم حس کنم. و جابجایی هم دیگه آسیب‌دهنی نیست."

    # say L1121 bil
    old "Well, seems last session really loosened you up."
    new "خب، به نظر می‌رسه جلسه گذشته واقعاً تو رو رها کرده."

    # say L1122 pla
    old "I... guess so."
    new "من... به نظر می‌رسه همینطور است."

    # say L1123 bil
    old "Still not perfect. You need a final push if you want to stand in front of a teacher."
    new "هنوز کامل نیست. اگه می‌خوای جلوی معلم بایستی، نیاز به یه ضربه نهایی داری."

    # say L1124 pla
    old "You really think I need more?"
    new "بلیلی... من نمی‌دونم. فکر کنم قدم‌های خوبی برداشتم."

    # say L1125 bil
    old "Oh, absolutely. A little more ‘advanced training’ won’t hurt."
    new "اوه، حتماً. یه کم تمرین «پیشرفته‌تر» هم نمی‌تونه آسون باشه."

    # say L1126 pla
    old "Billie... I don’t know. I think I’ve improved a lot already."
    new "بیلی... نمی‌دونم. فکر کنم قدم‌های خوبی برداشتم."

    # say L1127 bil
    old "You did. But if you want her to take you seriously, you need your fingers sharp."
    new "تو اینجوری کردی. ولی اگر می‌خوای ازت جدی بگیره، لازم داری که انگشتات رو تیز کنی."

    # say L1128 bil
    old "And we both know exactly what helped last time."
    new "و هر دو می‌دونیم دقیقاً چه چیزی کمک کرد."

    # say L1129 pla
    old "B- Billie, I—"
    new "بیلی، من—"

    # say L1130 bil
    old "Save it. We’re not wasting time. The supervised practice is soon."
    new "بیا، نباشیم. وقت ما کم است. تمرین نظارت شده زود هست."

    # say L1131 bil
    old "So let's get you ready properly."
    new "پس بیای برات آماده کنیم به درستی."

    # say L1143 bil
    old "Okay... damn. You’ve definitely improved again."
    new "باشه... شیطون. قطعاً دوباره پیشرفت کرده‌ای."

    # say L1145 bil
    old "Yeah. I can feel it. Your fingers are way more confident now."
    new "بله. احساس می‌کنم. انگشت‌هایت الان خیلی مطمئن‌تر هستند."

    # say L1146 pla
    old "I... still don’t know if I’m ready for the teacher, though."
    new "من... هنوز نمی‌دونم آماده معلم شدم یا نه."

    # say L1147 bil
    old "Relax."
    new "آرام باش."

    # say L1148 bil
    old "You’re not being tested for the contest yet. This is just to show progress."
    new "هنوز برای مسابقه آزمون نمی‌گیری. این فقط برای نشان دادن پیشرفتت است."

    # say L1149 pla
    old "Right... progress."
    new "درست... پیشرفت."

    # say L1150 bil
    old "She’ll give us feedback. Then we adjust. Simple."
    new "او به ما بازخورد می‌ده. بعد ما تنظیم می‌کنیم. ساده است."

    # say L1151 pla
    old "Okay... I guess that makes sense."
    new "باشه... فکر کنم منطقیه."

    # say L1152 bil
    old "Good. Then keep practicing at home. A lot."
    new "خوب. بعدش در خونه تمرین کن. خیلی."

    # say L1153 bil
    old "Don’t make me regret putting in all this effort."
    new "نگذاشته باش تا من همه این تلاش رو پشیمان بشه."

    # say L1154 pla
    old "I won’t. I’ll practice."
    new "من نخواهم. تمرین خواهم کرد."

    # say L1155 bil
    old "Alright... I’m done. Literally done. And I’m getting sleepy."
    new "البته... من تمامش کردم. واقعاً تمام شدم. و خسته‌ام، خوابیدم می‌خوام."

    # say L1156 pla
    old "Sleepy?"
    new "خسته شدی؟"

    # say L1157 bil
    old "Yeah. ‘Advanced training’ is exhausting, in case you didn’t notice."
    new "بله. «آموزش پیشرفته» خسته‌کننده است، اگر توجه نکردی."

    # say L1158 pla
    old "R-right... sorry."
    new "بله... معذرت."

    # say L1159 bil
    old "Go home. Practice. And don’t come back useless."
    new "برو خونه. تمرین کن. و دیگه بیهوده نباش."

    # say L1160 pla
    old "I’ll do my best. I’ll see you soon."
    new "من تلاش می‌کنم. به زودی دوباره می‌بینم تو."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mall.rpy
translate persian strings:

    # say L30 roo
    old "Hey buddy, how are you doing?"
    new "سلام دوست من، چطوری؟"

    # say L31 pla
    old "Wow!!!"
    new "وای!!!"

    # say L32 roo
    old "Oh! No worries at all, she is harmless, actually the only way to be attacked by them is that they feel threatened, it's ok, touch her."
    new "اوه! هیچ نگرانی نداشته باش، اون خطرناک نیست، در واقع تنها وقتی می‌تونن به تو حمله کنن وقتی تهدید شدن. راحت باش، لمسشو کن."

    # say L33 pla
    old "No, no...  It's fine thank you."
    new "نه، نه... خوبه، ممنون."

    # say L35 roo
    old "Hehehe! It's ok, the first time is kind of impressive... Her name is Gorgo, I really love her, it's my pet."
    new "هههه! راستش برای اولین بار می‌تونه متعجب‌کننده باشه... اسمش گورگو هست، خیلی دوستش دارم، این هم حیوان خانگی‌ام."

    # say L36 pla
    old "I can see it..."
    new "می‌تونم ببینم..."

    # say L37 roo
    old "Do you like snakes? Would you like to adopt one?"
    new "می‌تونی مار رو دوست داشته باشی؟ می‌خوای یکی رو ادوبت کنی؟"

    # say L38 pla
    old "Oh no, no thank you... Hmm I'm more a cat person... You know..."
    new "نه، نه ممنون... همین که من بیشتر گربه‌ها رو دوست دارم... می‌دونی..."

    # say L39 roo
    old "Oh, they are beautiful too, here you can find anything you need related with any pet... You know their food, cat litter or any toy you want for them to play with."
    new "اوه، اونا هم زیبا هستن، اینجا می‌تونی هر چی که برای هر حیوان خانگی نیاز داری پیدا کنی... مثل غذاشون، شن گربه یا هر بازی‌آلاتی که براتون می‌خواین باهاشون باzen."

    # say L40 pla
    old "Alright, thank you, I've never been to this place before! It 's amazing..."
    new "البته، ممنون، هیچ وقت اینجا نیومده بودم! خیلی عالیه..."

    # say L42 roo
    old "Yes, I just opened a couple of months ago, so that's probably  why you haven't seen it before..."
    new "بله، من فقط چند ماه پیش باز شدم، پس احتمالاً به همین خاطر قبلاً ندیده‌ای..."

    # say L43 roo
    old "You can come at any time, this place is a free space for animals and earth care, you can find anything and help with everything to save this beautiful world..."
    new "می‌تونی هر وقت بیادی، این جا فضای آزاد برای حیوانات و مراقبت از زمینه، می‌تونی هر چیزی پیدا کنی و به همه چیزی کمک کنی تا این دنیای زیبا رو نجات بدی..."

    # say L44 pla
    old "Oh, it's very nice to see this kind of place."
    new "اوه، خوشحالم که این جور مکانی رو می‌بینم."

    # say L45 roo
    old "Anytime you want to come we are here for you, ok? What's your name buddy?"
    new "هر وقت بخوای بیا ما اینجا برایت هستیم، خوبه؟ نامتو چیه دوستمند؟"

    # say L46 pla
    old "I'm [pla] nice to meet you."
    new "من [pla] خوشحالم که با تو آشنا شدم."

    # say L47 roo
    old "It's a pleasure [pla], I'm Roonie, I love the energy I can feel from people, yours is quite special keep that feeling, we need more people like you."
    new "خوشحالم [pla]، من روئونی هستم، انرژی‌ای که از مردم می‌آید رو دوست دارم، انرژی تو خیلی خاصه، این حس رو حفظ کن، ما به افراد مثل تو نیاز داریم."

    # say L48 pla
    old "Ok... Thank you..."
    new "باشه... ممنون..."

    # say L49 roo
    old "It was nice to meet you! Have a peaceful day!"
    new "خوشحالم که با تو آشنا شدم! روز خوبی داشته باش!"

    # say L50 pla
    old "Thanks, see you!"
    new "ممنون، بای!"

    # say L64 roo
    old "Hey buddy, how are you?"
    new "سلام دوست من، چطوری؟"

    # say L65 pla
    old "I'm fine, thank you."
    new "من خوبم، ممنون."

    # say L66 roo
    old "It's nice to see you here, very nice and positive energy you are spreading today."
    new "خوشحالم که تو رو اینجا می‌بینم، انرژی خوبی تو رو احساس می‌کنم."

    # say L67 pla
    old "... Thank you."
    new "ممنون."

    # say L68 roo
    old "What do you need today, I'm here to help you."
    new "امروز چه کاری داری؟ من اینجا هستم تا به تو کمک کنم."

    # say L69 pla
    old "Oh, I was just passing by."
    new "اوه، فقط گذر می‌کردم."

    # say L71 roo
    old "Ok, Remember if you find any homeless animal you can bring it here, so we can help, I know this world is very mean to them..."
    new "باشه، به خاطر داشتی اگر هیچ حیوان خانه‌ناپذیری پیدا کردی می‌تونی اونجا بیاری، تا ما کمک کنیم، می‌دونم این جهان برایشون خیلی بدیه..."

    # say L72 pla
    old "I will do!"
    new "بله، حتماً!"

    # say L73 roo
    old "Count on you buddy to make a more beautiful world for them."
    new "می‌تونم بر تو به این جهت اعتماد کنم که جهان زیباتری برایشون بسازی."

    # say L74 pla
    old "Sure... I need to leave."
    new "بله... باید برسم."

    # say L75 roo
    old "I know, busy day, isn't it?"
    new "می‌دونم، روز پرکاری داری، همینطور نیست؟"

    # say L76 pla
    old "Kind of..."
    new "به نظر می‌رسه..."

    # say L77 roo
    old "Thank you for stopping by to say hi."
    new "ممنونم که وقت گذاشتی سلام بگویی."

    # say L78 pla
    old "Don't mention it."
    new "خواهش می‌کنم."

    # say L80 pla
    old "You too, bye!"
    new "تو هم، خداحافظ!"

    # say L93 pla
    old "Hey! How are you?"
    new "سلام! حالت چطوره؟"

    # say L94 roo
    old "Hey my man, nice seeing you again! I'm pretty fine, what about you?"
    new "سلام داداش، خوشحالم دوباره دیدنت. من خوبم، تو چطوری؟"

    # say L95 pla
    old "I'm glad... Well, Hmm, I'm ok."
    new "خوشحالم... خب، هم، من خوبم."

    # say L96 roo
    old "Cool man! Is there anything I can do for you?"
    new "خوب، آدم! چیزی هست که بتونم برایت انجام بدم؟"

    # say L97 pla
    old "Hmm, actually yes... I- I w- wanted to ask you for a j- job? I thought you maybe had something for me."
    new "Hmm، در واقع بله... من- من می‌خواستم از تو بپرسم که آیا شغلی برایم داری؟ فکر کردم شاید چیزی برایم داری."

    # say L98 roo
    old "Really? [pla] you put me in a complicated situation. I would like to help you but now it's impossible. I don't have much resources right now and Angelina is pregnant."
    new "حقاً؟ [pla] تو منو به موقعیت پیچیده‌ای انداختی. می‌خواستم به تو کمک کنم ولی الان امکان‌پذیر نیست. حالا من زیاد منابعی ندارم و آنجلینا هم باردار شده."

    # say L99 pla
    old "Pregnant? Oh right! Uhh...  Congrats Ronnie, t- that's... great."
    new "حمله؟ اوه درسته! همینجوری... مبارکه رونی، این... خوبه."

    # say L100 pla
    old "I'm sorry I bothered you, I understand you can't help me now. I should go now... I have things to do but thanks..."
    new "ممنونم که وقتت رو گذاشتم، می‌فهمم حالا نمی‌تونی به من کمک کنی. باید برم... کارهایی هست که باید انجام بدم ولی ممنون."

    # say L101 roo
    old "No, no, it's fine, sorry I couldn't help, but you don't have to go, stay and let's chit-chat."
    new "نه، نه، خوبه، معذرت که نتونستم کمکت کنم، ولی نمی‌تونی برو، بمون و بیایم حرف بزنیم."

    # say L103 pla
    old "Oh n- no, thanks but I really need to go now. See you!"
    new "اوه نه، ممنون اما واقعاً باید برم. خداحافظ!"

    # say L104 roo
    old "Have a nice one! Take care [pla]."
    new "باید برو! موفق باش [pla]."


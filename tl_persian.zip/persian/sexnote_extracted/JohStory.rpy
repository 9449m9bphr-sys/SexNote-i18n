# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/JohStory.rpy
translate persian strings:

    # say L6 joh
    old "Oh, hi [pla], I‘m glad you came. Are you ready to start?"
    new "اوه، سلام [pla]، خوشحالم که اومدی. آماده‌ای شروع کنیم؟"

    # say L7 pla
    old "Uhh... Hi, yes, sure."
    new "اوه... سلام، بله، البته."

    # say L8 joh
    old "Ok, as we discussed last time, I'll need your help with some of my patients."
    new "خب، همانطور که بار قبل صحبت کردیم، به کمکت برای برخی از بیمارانم نیاز دارم."

    # say L9 joh
    old "However, you will need a bit of instruction to gain more experience and do a better job."
    new "البته، اما شما نیاز به یک مقدار آموزش دارید تا تجربه بیشتری کسب کنید و کار بهتری انجام دهید."

    # say L10 pla
    old "Hmm, ‘Instruction'? What do you mean?"
    new "Hmm، آموزش؟ منظورت چیه؟"

    # say L11 joh
    old "Just think about it like a class made just for you, I'll provide you with the proper training and tell you what to do."
    new "فکر کن بهش مثل یک کلاس خصوصی برایت، من آموزش‌های لازم رو بهت میدم و میگم باید چی کنی."

    # say L12 pla
    old "Hmm, ok..."
    new "Hmm، خوب..."

    # say L14 joh
    old "Ok, to start you need to know I assist some patients who have, most of the time, some... Hmm, ‘sexual difficulties'..."
    new "خب، برای شروع باید بدانی که من به برخی بیماران کمک می‌کنم که اغلب...Hmm، مشکلات جنسی دارند..."

    # say L15 joh
    old "Some of them are married women that don't enjoy their sexuality, this brings a lot of problems to their lives."
    new "برخی از آنها زنان متاهل هستند که لذت جنسی را نمی‌برند، این موضوع برای زندگی آنها خیلی مشکلات ایجاد می‌کند."

    # say L16 pla
    old "Hmm, I see."
    new "ممنون، متوجه شدم."

    # say L17 joh
    old "In other words, I help them to discover and enjoy their sexuality and have more pleasant moments with their partners."
    new "به عبارت دیگر، من به آنها کمک می‌کنم تا جنسیت خود را کشف کنند و لحظات خوش‌تری با همسران خود بگذرانند."

    # say L18 pla
    old "Ok, I got it, but... What do I have to do?"
    new "باشه، فهمیدم، اما... من چه کاری باید بکنم؟"

    # say L19 joh
    old "Well, I know you can support me to achieve success in a lot of patients' treatment like you did with Hinn."
    new "خب، میدونم می‌تونی به من کمک کنی تا موفقیت داشته باشم در درمان بسیاری از بیماران مثل هین."

    # say L20 pla
    old "L- like I did with... H- Hinn?"
    new "مثلا مثلی که با... ه- هین کردی؟"

    # say L21 joh
    old "It's ok, I am pretty conscious about the process we will need to go through so you can do it well."
    new "باشه، من در مورد مراحلی که باید طی کنیم خیلی آگاه هستم تا بتونی این کار رو خوب انجام بدی."

    # say L23 joh
    old "Don't worry, we will have some lessons to teach you."
    new "نگران نباش، درس‌هایی برای آموزشت خواهیم داد."

    # say L24 joh
    old "Also, I'll be with you at all times, you just have to follow the instructions, okay?"
    new "همچنین من همیشه با تو خواهم بود، فقط باید دستورالعمل‌ها را انجام بدی، درسته؟"

    # say L25 pla
    old "Hmm, got it."
    new "ممنون، فهمیدم."

    # say L26 joh
    old "I really want you to perform the best way possible and I will ensure you develop the skills you need."
    new "من واقعاً می‌خوام تا بهترین عمل رو انجام بدی و من اطمینان می‌دم که مهارت‌های لازم رو یاد بگیری."

    # say L27 joh
    old "So, let's not waste any more time and let's go to the practice room!"
    new "پس، بیایید زمان بیشتری را ضایع نکنیم و به اتاق تمرین برویم!"

    # say L34 joh
    old "Well, to start, do you remember that Hinn learned how to please a man? Well, now is your turn!"
    new "خب، برای شروع، آیا به خاطر داری که هین چطور یک مرد را خوشحال کرد؟ حالا دو نوبت توست!"

    # say L36 joh
    old "What I meant [pla] is, I'll teach you how to fuck like a pro..."
    new "من قصد داشتم بگم [pla] من می‌خوام یادت بدم چطور مثل حرفه‌ای بفرمایی..."

    # say L38 joh
    old "At this point I think you must take it more natural since I've already sucked your cock several times so just relax."
    new "در این مرحله فکر می‌کنم باید بیشتر طبیعی باشی چون من قبلاً چند بار ناخودآگاهت رو شیر کردم، پس فقط آرام باش."

    # say L40 joh
    old "We are going to start with some oral sex, I want you to show me those skills, so I can be sure my patients are going be satisfied."
    new "ما از جنس شفاهی شروع می‌کنیم، می‌خوام ببینم اون مهارت‌هایت رو نشون بدی تا مطمئن شم بیمارانم راضی می‌شنن."

    # say L41 pla
    old "W- what? Do you mean you want me to give you... O- oral sex?"
    new "و- وای، منظورت اینه که من باید بهت... ا- آروال سکس بدم؟"

    # say L42 joh
    old "Yes, remember, just relax and follow my instructions."
    new "بله، به یاد داشته باش، فقط آرام شو و دستورات من را انجام بده."

    # say L43 joh
    old "We are learning and this is part of your process, so, come here and get on your knees."
    new "ما در حال یادگیری هستیم و این بخشی از فرآیند شماست، پس بیا اینجا بیای و روی زانوهات نشین."

    # say L52 joh
    old "I can assure you this lesson is going to be useful for you."
    new "مطمئن هستم این درس برایت مفید خواهد بود."

    # say L53 joh
    old "And it will be necessary for my patients, and of course, should be amusing for both of us, so, let's start."
    new "و این برای بیماران من ضروری خواهد بود، و البته باید برای هر دو ما سرگرم‌کننده باشد، پس بیایید شروع کنیم."

    # say L56 joh
    old "I want you to kiss me, like if that were my mouth, move your tongue carefully, slowly..."
    new "می‌خواهم تو مرا بوسی، مثل اینکه آن جا دهان من است، زبانت را با دقت و آرام آرام حرکت ده..."

    # say L69 joh
    old "Just like that, try to keep it wet, and slowly move your tongue a bit faster..."
    new "همینطور، سعی کن اون رو مرطوب نگه داری و زبانتو به آرامی یه کم سریع‌تر حرکت بدی..."

    # say L71 joh
    old "Keep doing it like that... Ahh."
    new "به همین شکل ادامه بده... آه."

    # narrator L95 
    old "Try Again"
    new "دوباره امتحان کن"

    # narrator L97 
    old "Next Round"
    new "دور بعدی"

    # say L109 joh
    old "Oh careful!"
    new "اوه دقت کن!"

    # say L111 joh
    old "Ouch!"
    new "اوه!"

    # say L113 joh
    old "NO! NO! STOP!"
    new "نه! نه! متوقف شو!"

    # say L119 pla
    old "Did I do something wrong?"
    new "من چیزی اشتباه کردم؟"

    # say L120 joh
    old "Hmm, I think you could do it a lot better..."
    new "Hmm، فکر می‌کنم می‌تونی خیلی بهتر این کار رو انجام بدی."

    # say L121 joh
    old "Softer, the idea is to make the patient experience a lot of pleasure and not the opposite, but we can work on that."
    new "نرم‌تر، هدف اینه که بیمار لذت زیادی تجربه کنه و نه عکس آن، اما می‌تونیم روی این کار کنیم."

    # say L122 pla
    old "Hmm... Ok."
    new "Hmm... بله."

    # say L123 joh
    old "Listen, that is something normal, we can always improve our abilities, don't feel bad about this particular moment where it was not as expected, it's ok."
    new "بگو، این چیزی عادیه، می‌تونیم همیشه توانایی‌هامون رو بهتر کنیم، نباید از این لحظه خاص که مثل انتظار نبود، بد حس شی، همه چیز خوبه."

    # say L126 joh
    old "Unfortunately, our time is up. I think you need to learn a couple of things more before continuing."
    new "متأسفانه وقت ما تمام شد. فکر می‌کنم باید چند نکته دیگه رو یاد بگیری قبل از ادامه."

    # say L129 joh
    old "Perfect, see you later [pla]."
    new "خوب، دوست دارم بعداً بهت ببینم [pla]."

    # say L130 pla
    old "See you too, bye!"
    new "به شما هم، خداحافظ!"

    # say L144 joh
    old "Congratulations, you definitely have what it takes, so, we can do a perfect team."
    new "تبریک می‌گم، قطعاً شرایط رو داری، پس می‌تونیم تیم خوبی باشیم."

    # say L145 joh
    old "I can see you have other talents and they are pretty valuable."
    new "می‌بینم تالنت‌های دیگری هم داری و اونا هم خیلی ارزشمند هستند."

    # say L147 joh
    old "Yes, I'm very satisfied, you did just fine."
    new "بله، خیلی راضی هستم، خوب کار کردی."

    # say L148 pla
    old "I am glad you liked it."
    new "خوشحالم که لذت برده‌ای."

    # say L149 joh
    old "It can be better but I am proud of you, I can count on you to make the best for my patients."
    new "می‌تواند بهتر باشد اما از تو خوشحال می‌شوم، برای بیماران من بهتربینی می‌کنم."

    # say L150 joh
    old "The great news is that these lessons are going to be quite fascinating for me."
    new "خبر خوب اینه که این جلسات برای من خیلی جالب هستند."

    # say L159 joh
    old "I think that's all, you need to rest a bit, I am exhausted but I have some patients I have scheduled."
    new "من فکر می‌کنم این همه است، باید یک کم استراحت کنی، من خسته‌ام اما برخی بیماران را برنامه‌ریزی کرده‌ام."

    # say L160 pla
    old "Ok, thank you."
    new "خوب، ممنون."

    # say L161 joh
    old "It was a pleasure... I hope you're on time tomorrow."
    new "خوشحالم... امیدوارم فردا روی وقت باشی."

    # say L163 joh
    old "I'll be waiting for you, there are some lessons we need to have go through."
    new "من منتظرت خواهم بود، درس‌هایی هستند که باید بررسی کنیم."

    # say L165 joh
    old "Perfect, see you tomorrow."
    new "البته، تا فردا."

    # say L181 joh
    old "Hi [pla], glad to see you. There's no time to lose, let's go to the room."
    new "سلام ز[pla]، خوشحالم که دیدمت. وقت کمی برای این هست، بیایید به اتاق برویم."

    # say L182 pla
    old "Uhhh... Ok!"
    new "اوه... خوب!"

    # say L188 joh
    old "We need to repeat the session we were practising last time, I need you to finish it successfully."
    new "ما باید جلسه‌ای که در آخرین بار تمرین می‌کردیم را تکرار کنیم، من نیاز دارم تا با موفقیت به پایان برسانی."

    # say L190 joh
    old "I have to budget my time because I have a couple of patients coming earlier, so please help me to finish on time."
    new "من باید وقتم رو برنامه‌ریزی کنم چون چند بیمار قبل از شما می‌آیند، پس لطفاً به من کمک کنید تا در زمان مقرر تمام شود."

    # say L192 joh
    old "Let's start, you already know how to do it, so please do your best."
    new "بیایید شروع کنیم، تو قبلاً می‌دونی چطور انجام بدی، پس لطفاً تلاشت رو به حداکثر برسون."

    # say L193 pla
    old "Uhh, Ok..."
    new "اوه، خب..."

    # say L207 joh
    old "Keep doing it like that... Ahh..."
    new "به همین شکل ادامه بده... آه..."

    # say L262 joh
    old "Welcome [pla], I'm happy to have you here, we have a lot of things to work on."
    new "خوش آمدید [pla]، خوشحالم که شما اینجا هستید، ما کارهای زیادی برای انجام داریم."

    # say L263 pla
    old "Hi... Uhh, ok, ok, I- I am ready."
    new "سلام... اوه، خب، خب، من- من آماده‌ام."

    # say L264 joh
    old "Wonderful! Today we have a new goal I want you to work on."
    new "عالی است! امروز هدف جدیدی برای شما در نظر گرفته‌ام که می‌خواهم روی آن کار کنید."

    # say L265 pla
    old "Ok, what is it?"
    new "باشه، چیه؟"

    # say L266 joh
    old "I think it's something kind of new for you but I can walk you through it. It's related to self-mastery."
    new "فکر می‌کنم برایت چیز جدیدی هست، اما می‌تونم تو راهنمایی کنم. این مربوط به تسلط بر خودت هست."

    # say L268 pla
    old "'Self-mastery'?"
    new "«تسلط بر خود»؟"

    # say L269 joh
    old "Yeah, let me explain it to you, most of the time our desires or emotions can be really difficult to control..."
    new "بله، بگذار برایت توضیح بدم، اغلب شوکه‌ها یا احساسات ما خیلی سخت کنترل می‌شوند..."

    # say L270 joh
    old "Once you can defeat them, you will be strong enough to act without their control."
    new "بازهایی را شکستی، قوی‌تر خواهی شد تا بدون کنترل آن‌ها عمل کنی."

    # say L271 joh
    old "The most visible aspect of this exercise will be that you can last longer during any kind of sexual interaction."
    new "جان: مهم‌ترین جنبه این تمرین این خواهد بود که شما می‌توانید طولانی‌تر در هر نوع تعامل جنسی پایدار باشید."

    # say L272 pla
    old "Hmm interesting..."
    new "Hmm جالب است..."

    # say L273 joh
    old "Talking about our sexual performance, we need to be sure we can control our body to react the exact way we want..."
    new "در مورد عملکرد جنسی ما، باید مطمئن شویم که می‌توانیم بدنمان دقیقاً مثل آنچه می‌خواهیم واکنش نشان دهد."

    # say L274 joh
    old "That way we can guarantee your sexual partner reaches the orgasm before you do."
    new "به این ترتیب می‌توانیم اطمینان حاصل کنیم همسر جنسی شما قبل از شما به عجوله برسد."

    # say L277 joh
    old "That's cool, so today we are going to see if your performance can be mastered without cumming."
    new "این خوبه، پس امروز می‌بینیم آیا می‌توانی عملکردت را بدون جیز کردن در اختیارت بگیری."

    # say L278 joh
    old "Or we will need to work on it harder so you can perform better with the patients."
    new "یا باید سخت‌تر کار کنیم تا بتونی بهتر با بیماران عمل کنی."

    # say L279 pla
    old "Ok, and how are we going to verify that?"
    new "باشه، و ما چطور می‌تونیم اینو تایید کنیم؟"

    # say L280 joh
    old "That's an interesting part, I want you to relax and just be yourself, I will do the rest of the job, let's go to the room."
    new "این بخش جالب است، می‌خواهم ازت بخواهم آرام شوی و خودت باشی، من بقیه کار را انجام می‌دهم، بیایید به اتاق برویم."

    # say L281 pla
    old "Uhh... Ok."
    new "اوه... باشه."

    # say L287 joh
    old "Please take off your pants, so we can start..."
    new "لطفاً شلوارتو ببرد، تا بشه شروع کرد..."

    # say L289 joh
    old "I want to test how long you can last, so, get ready because I will use my mouth, I will give you the best blowjob of your entire life."
    new "می‌خوام ببینم چه مدت می‌تونی ادامه بدهی، پس آماده شو، چون من قصد دارم از دهانم استفاده کنم، من بهت بهترین بلیو جابی می‌دم که تو توی تمام عمرت تجربه کردی."

    # say L291 joh
    old "So, come on, take off your pants, I'm going to make myself comfortable too."
    new "پس، بیا، شلوارتو ببرد، من هم آماده می‌شوم."

    # say L316 pla
    old "WOW!"
    new "واو!"

    # say L317 joh
    old "I am glad you like them because I want you to look at them carefully."
    new "خوشحالم که لذت برده‌ای، زیرا می‌خواهم به آن‌ها دقت کنی."

    # say L318 joh
    old "I need you to be very stimulated to test your endurance."
    new "من نیاز دارم تا شما خیلی تحریک شوید تا تحمل خودتون رو آزمون کنیم."

    # say L320 joh
    old "The idea is that, even though all sensorial stimulation you feel, you can control your body and don't cum."
    new "ایده اینه که، حتی با همه تحریکات حسی که می‌تونی احساس کنی، بدنت رو کنترل کنی و نبیا جیز کنی."

    # say L321 pla
    old "Are you serious?"
    new "می‌فرمایید جدی هستید؟"

    # say L322 joh
    old "Absolutely, under any circumstance you must not cum, until I say you can, ok?"
    new "حتماً، در هر شرایطی نباید جیز کنی، تا من اجازه بدم، خوب؟"

    # say L323 pla
    old "Hmm ok..."
    new "Hmm خب..."

    # say L368 joh
    old "Ok now it comes the hard part, I will suck your entire dick, are you ready?"
    new "خب حالا بخش سخت‌تر اومده، من کل نیتت رو خواهم کشید، آماده‌ای؟"

    # say L374 pla
    old "(Oh God, it feels so good...)"
    new "اوه خدا، این هم خیلی خوب است..."

    # say L379 pla
    old "Dr. Johnson I- I- ... Ughhhh..."
    new "دکتر جانسون من- من-... اوه..."

    # say L386 joh
    old "OH NO! You came before!"
    new "اوه نه! شما قبل از وقت رسیدید!"

    # say L392 pla
    old "I- I am... Sorry..."
    new "من- من... معذرت..."

    # say L393 joh
    old "It's ok, it's something we knew could happen so calm down, what a mess you did..."
    new "باشه، این چیزی بود که می‌دونستیم می‌تونست بیوفت، هیچ جور نگران نباش، ولی خوب خراب کردی..."

    # say L394 pla
    old "I'm sorry, it was my fault."
    new "متأسفم، این اشتباه من بود."

    # say L395 joh
    old "It's ok, it wasn't that bad, the thing is that we now need to have this in mind to make sure you can control yourself."
    new "باشه، خیلی بد نبود، اما مهم اینه که حالا باید این رو در نظر بگیریم تا بتونی خودت رو کنترل کنی."

    # say L396 joh
    old "We can't have this mess with a patient..."
    new "ما نمی‌توانیم این خرابی رو با بیمار داشته باشیم..."

    # say L398 pla
    old "How can I do it better?"
    new "من چطور می‌تونم بهتر این کار رو انجام بدم؟"

    # say L400 joh
    old "I will help you, don't worry."
    new "من به شما کمک می‌کنم، نگران نباشید."

    # say L402 joh
    old "But, I am running out of time, the patients are about to arrive and I need to clean this mess..."
    new "اما وقت من کم می‌شه، بیماران هم خیلی زود می‌رسن و من باید این درگیری رو تمیز کنم..."

    # say L403 joh
    old "I hope you be on time tomorrow, We need to correct this behavior."
    new "امیدوارم فردا به موقع بیایی، ما باید این رفتار رو اصلاح کنیم."

    # say L404 pla
    old "I am very sorry to disappoint you."
    new "خیلی متاسفم که شما را ناامید کردم."

    # say L405 joh
    old "There is nothing we can't improve, I'm sure next time it will be different."
    new "چیزی که نتوانیم بهبود بیاوریم وجود نداره، مطمئن هستم بار بعد متفاوت خواهد بود."

    # say L406 joh
    old "I think that's all, you need to rest a bit, I have some patients scheduled, so, see you later."
    new "فکر کنم این همه است، باید یکم استراحت کنی، من چند بیمار تعیین وقت شده دارم، پس، دوباره ببینیم."

    # say L409 joh
    old "We will need to repeat this exercise, I'll be waiting for you."
    new "این تمرین را باید تکرار کنیم، منتظرت می‌مانم."

    # say L410 pla
    old "Ok, see you later..."
    new "باشه، بعداً می‌بینیم..."

    # say L425 joh
    old "Oh great! That was good, you have surprised me! What a huge load, it's delicious."
    new "اوه عالی! خوب بود، شما من رو شگفت‌زده کردی! چقدر بار سنگینی، لذت‌بخش است."

    # say L427 joh
    old "Congratulations, I can see that you havea lot more control of body."
    new "تبریک می‌کنم، می‌بینم که از بدن خود کنترل بیشتری داری."

    # say L432 joh
    old "All right, I'm gonna clean this mess. My next patient is about to arrive... I hope you be on time tomorrow."
    new "باشه، من این درهم‌پاره رو تمیز می‌کنم. بیمار بعدی من هم خیلی زود می‌رسه... امیدوارم فردا به موقع بیایی."

    # say L435 joh
    old "Ok, there are some lessons we need to have to go through."
    new "خوب، درس‌هایی هستند که باید بگذریم."

    # say L436 pla
    old "Got it, see you tomorrow then."
    new "باشه، ببینم فردا."

    # say L452 pla
    old "Fine! Thanks for asking, hope you are doing good too."
    new "خوبه! ممنون که پرسیدی، امیدوارم حالت هم خوب باشه."

    # say L453 joh
    old "Oh absolutely! But I can tell you it will be better just in a moment, Are you ready?"
    new "البته! اما می‌تونم بگم که فقط یه لحظه دیگه بهتر می‌شه، آماده هستی؟"

    # say L454 pla
    old "Ready? For what?"
    new "آماده؟ برای چه؟"

    # say L456 joh
    old "Well, today we will continue your process to make you able to control yourself, the main focus for today will be performance."
    new "خب، امروز ما به ادامه فرآیند کنترل خودتان خواهیم پرداخت، تمرکز اصلی برای امروز عملکرد خواهد بود."

    # say L457 pla
    old "Performance?"
    new "پرفورمانس؟"

    # say L458 joh
    old "Yes, we need to test your capabilities to accomplish the tasks that you will have..."
    new "بله، ما باید توانایی‌های شما را برای انجام وظایفی که خواهید داشت آزمایش کنیم..."

    # say L459 joh
    old "So, you need to work not only on the time you can last, but the quality of that time."
    new "پس، شما باید نه تنها مدت زمانی که می‌توانید ادامه دهید رو بهبود ببخشید، بلکه کیفیت آن زمان هم مهم است."

    # say L460 pla
    old "Oh... I understand."
    new "اوه... من درک کردم."

    # say L462 joh
    old "Today we have a very nice exercise, so I hope you put all your effort to make a successful session."
    new "امروز تمرین خیلی خوبی داریم، پس امیدوارم تمام تلاشتو بکنی برای یک جلسه موفق."

    # say L463 joh
    old "Remember, focus on the rhythm and performance."
    new "به یاد داشته باش، روی ریتم و اجرا تمرکز کن."

    # say L464 pla
    old "Uhh, ok."
    new "آره، خوب."

    # say L465 joh
    old "So, let's go, we will have sex now."
    new "پس بیایید، حالا جنس خواهیم کرد."

    # say L466 pla
    old "I will hav-... W- wait, what? Sex?"
    new "من خواهم-... چ- چه کاری؟ جنس؟"

    # say L467 joh
    old "Of course, that is how we can practice, besides, I need to test the quality of my assistant."
    new "البته، این روش برای تمرین است و همچنین من باید کیفیت کاری کمک‌کننده‌ام را بررسی کنم."

    # say L469 joh
    old "Great, let's get started, first we need to go to the practice room."
    new "عالی، بیایید شروع کنیم، اول باید به اتاق تمرین برویم."

    # say L476 joh
    old "From this particular exercise and on, we will need to guarantee your partner reaches the orgasm, that is the key."
    new "از این تمرین به بعد، باید اطمینان حاصل کنیم همسر شما به عرضه می‌رسد، این همین کلید است."

    # say L477 pla
    old "Ok, I will focus on that."
    new "باشه، بر این متمرکز می‌شم."

    # say L478 joh
    old "But, anyways remember to enjoy what you are doing, let's get prepared. Take off your clothes."
    new "البته، ولی به هر حال از آنچه انجام می‌دهی لذت ببر، بیایید آماده شویم. لباس‌هات رو ببرد."

    # say L482 joh
    old "Perfect, now that you are ready let's fuck!"
    new "عالی، حالا که آماده شدی بیایید بگشتم!"

    # say L538 pla
    old "Ohhh... Ohhh... I- I-"
    new "اوه... اوه... من- من-"

    # say L552 joh
    old "Huh, you finished quite earlier..."
    new "اوه، شما خیلی زود تمام شدید..."

    # say L553 joh
    old "I know you are doing a great effort, but I need you to take control of yourself and wait for the right moment."
    new "میدونم تو تلاش زیادی می‌کنی، اما باید خودت رو کنترل کنی و منتظر لحظه مناسب باشی."

    # say L554 pla
    old "I- I'm trying to focus-"
    new "من- من سعی می‌کنم تمرکز کنم"

    # say L556 joh
    old "I know, we only need to work harder. "
    new "می‌دونم، فقط باید سخت‌تر کار کنیم."

    # say L557 joh
    old "I think you need to do some workout, so, you can keep your body up until I reach the orgasm."
    new "من فکر می‌کنم باید تمرین بیشتری انجام بدی، تا بتوانی بدنت را تا زمانی که من به عرضه‌گری می‌رسم، حفظ کنی."

    # say L559 pla
    old "I will improve, I think I was tired because of the rhythm."
    new "من بهتر خواهم شد، فکر کنم از ریتم خسته شده‌ام."

    # say L560 joh
    old "Sure you will improve, that's why we are doing this together, so you can develop all the skills you have."
    new "حتماً بهتر می‌شی، همین جوری که با هم این کار رو انجام میدیم، تا بتونی همه مهارت‌هایت رو توسعه بدی."

    # say L562 joh
    old "Don't mention it, let's clean this mess, I have to continue working..."
    new "بگو نه، بیاین این همه را تمیز کنیم، من باید ادامه کارم رو بزنم..."

    # say L577 joh
    old "I'm very impressed, you are quite awesome at this, let me tell you the exercise was a complete success."
    new "من خیلی متأثر شدم، تو در این کار خیلی خوبی هستی، بگذار بگم تمرین کاملاً موفق بود."

    # say L578 pla
    old "T- thanks... I did all that I could."
    new "ممنون... همه چیزی که می‌تونستم رو انجام دادم."

    # say L579 joh
    old "Hahaha good job kid, you are doing the exercises very consciously."
    new "حاحاحا خوب کار کردی بچه، تو این تمرین‌ها رو بسیار آگاهانه انجام می‌دی."

    # say L581 joh
    old "Keep working, the benefits will be incredible and remember the benefits won't be only yours..."
    new "ادامه بده، مزایایش خیلی خوب هست و بخاطر داشته باش مزایا فقط برایت نیستند..."

    # say L582 joh
    old "It was a very productive session, so, I hope next time we keep the level as high as today."
    new "این جلسه خیلی مثمر بود، پس امیدوارم بار بعد هم همین سطح رو حفظ کنیم."

    # say L583 pla
    old "Sure, I will keep working hard."
    new "بله، خواهم تلاش کرد سخت کار کنم."

    # say L585 joh
    old "Yes... really Hard."
    new "بله... واقعاً سخت."

    # say L601 joh
    old "Oh, you are here! Quite on time."
    new "اوه، اینجا هستی! خیلی به موقع."

    # say L602 pla
    old "Yes, I came a bit earlier."
    new "بله، کمی زودتر اومدم."

    # say L603 joh
    old "That's perfect, we have a lot to work on."
    new "عالی، خیلی کاری داریم."

    # say L604 pla
    old "Ok, I am ready."
    new "باشه، آماده‌ام."

    # say L605 joh
    old "Great, today we will work on your strength, the power given on every sexual encounter."
    new "عالی، امروز بر روی قدرت شما کار خواهیم کرد، قدرتی که در هر تماس جنسی به شما داده می‌شود."

    # say L606 pla
    old "Hmm... Strength? What do you mean?"
    new "Hmm... قدرت؟ منظورت چیه؟"

    # say L607 joh
    old "Sex requires a lot of power if you really want to satisfy, I need you to start doing the process beyond the limits."
    new "جنس برای اینکه واقعاً رضایت بخش باشه، خیلی زور لازم داره. من نیاز دارم شروع کنی به فرآیندی فراتر از حدود."

    # say L609 pla
    old "Wow, And how can I achieve that?"
    new "وای، من چطور می‌تونم این هدف رو برسم؟"

    # say L610 joh
    old "Well, I need you to focus because you are going to use your dick quite differently."
    new "خب، باید تمرکز کنی زیرا شما باید ناخودت رو به طور کاملاً متفاوتی استفاده کنی."

    # say L611 joh
    old "You must control your body so you can give a hardcore sex experience."
    new "شما باید بدن خود را کنترل کنید تا تجربه جنسی سختی ارائه دهید."

    # say L612 pla
    old "Hmm, ok."
    new "Hmm، خوب."

    # say L613 joh
    old "Let's go ahead to the practice room, I can't wait to get fucke- ... I mean to start the new exercise..."
    new "بیایید به اتاق تمرین برویم، نمی‌توانم صبر کنم که شروع به... منظورم این است که تمرین جدید را شروع کنیم."

    # say L620 joh
    old "Ok, previous lesson was focused on endurance and lasting as much as I wanted."
    new "البته، درس قبل بر تمرکز و تحمل برای ادامه به مدت زمان مورد نظر من بود."

    # say L621 joh
    old "This time I need you to keep this in mind, I want you to be hardcore hitting my pussy really hard."
    new "این بار می‌خوام این حساب رو در نظر بگیری، می‌خوام تو خیلی سخت و شدید به میانه‌ام ضربه بزنی."

    # say L623 joh
    old "Let's do it, please take off your clothes and get ready."
    new "بیایید انجام بدیم، لطفاً لباست رو بردار و آماده شو."

    # say L682 pla
    old "Oh God! This is too much!"
    new "اوه خدا! این خیلی زیاده!"

    # say L695 pla
    old "Did I cum quick, right?"
    new "من زود خوردم، درسته؟"

    # say L696 joh
    old "Not just that... I'm afraid you are not strong enough, you need to hit harder, some girls will like to be pounded really hard."
    new "نه فقط این... باید قوی‌تر باشی، باید سخت‌تر ضربه بزنی، بعضی دخترها می‌خواهند واقعاً سخت زده شوند."

    # say L698 joh
    old "[pla], we need to satisfy certain preferences..."
    new "[pla]، ما باید تمایلات خاصی را راضی کنیم..."

    # say L699 joh
    old "This is not a regular sexual encounter you will find really demanding girls that want something harder, and you need to provide that."
    new "این فقط یک ملاقات جنسی ساده نیست، شما با دخترانی که نیازهای خاصی دارند روبرو هستید، آنها می‌خواهند چیزی سخت‌تر از این تجربه کنند و شما باید این نیازها را برآورده کنید."

    # say L700 pla
    old "You are right, I'm sorry.."
    new "درست می‌فرمایید، معذرت."

    # say L701 joh
    old "Don't worry I know you can learn... But today I need to get ready for my next patient, so next time we will practice this lesson again."
    new "نگران نباش، میدونم میتونی یاد بگیری... اما امروز باید برای بیمار بعدیم آماده شم، پس در جلسه بعد این درس رو دوباره تمرین می‌کنیم."

    # say L703 joh
    old "See you later kido."
    new "تا بعداً بچه."

    # say L704 pla
    old "See you doctor."
    new "تا بعداً دکتر"

    # say L718 joh
    old "You are doing great! Congratulations for this improvement, you definitely approved, my patients will love you."
    new "شما خوب عمل می‌کنید! تبریک می‌گم برای این پیشرفت، قطعاً پیش‌بردید، بیماران من شما رو دوست خواهند داشت."

    # say L719 pla
    old "Thank you, I appreciate it."
    new "ممنون، خوشحال می‌شوم."

    # say L720 joh
    old "The process has been successful, I want you to keep working..."
    new "پروسس موفق بود، می‌خوام ادامه کارتو بدهی..."

    # say L723 joh
    old "I guess in the mornings we can continue with these lessons, because I want to... Hmm, help you practice more..."
    new "به نظر می‌رسه صبح‌ها می‌تونیم این درس‌ها رو ادامه بدهیم، چون می‌خوام... هم، تو رو بیشتر تمرین کنی..."

    # say L724 pla
    old "Oh, ok that sounds good to me..."
    new "اوه، خوب، این برای من هم خوب است..."

    # say L725 joh
    old "Perfect, I'm looking forward to seeing your progress, there are many things we can improve."
    new "عالی، منتظر پیشرفتت هستم، خیلی چیزهایی هست که می‌تونیم بهتر کنیم."

    # say L726 pla
    old "I appreciate your help."
    new "ممنون از کمکتان"

    # say L727 joh
    old "In our next session we will have a patient to put what we have learned into practice."
    new "در جلسه بعد ما یک بیمار خواهیم داشت تا آنچه یاد گرفته‌ایم را به کار ببریم."

    # say L729 joh
    old "Don't worry, I will walk you through so we can do an outstanding job."
    new "نگران نباش، من هدایتت می‌کنم تا کار برجسته‌ای انجام بدیم."

    # say L733 joh
    old "All right, I need you to leave so I can get ready for my next patient, thanks for your great job, it was remarkable."
    new "باشه، لطفاً برو تا بتوانم برای بیمار بعدی آماده شوم، ممنون از کار عالیت، واقعاً برجسته بود."

    # say L737 pla
    old "Bye!"
    new "باید!"

    # say L747 joh
    old "(I can't believe myself, that dick is driving me so crazy...)"
    new "من خودم رو نمی‌تونم باور کنم، اون لوله‌اش منو خیلی دیوانه می‌کنه..."

    # say L761 joh
    old "Oh, [pla], I'm glad you came early, there's something I needed to talk to you about before we start."
    new "اوه، [pla]، خوشحالم که زود آمدی، چیزی هست که باید قبل از شروع با تو صحبت کنم."

    # say L763 joh
    old "Well, today we're going to work with Angelina, she is a patient who doesn't enjoy having sex."
    new "خب، امروز با آنجلینا کار می‌کنیم، او بیماری است که از داشتن جنس لذت نمی‌برد."

    # say L764 joh
    old "I have tried with several exercises, but she is kind of stuck in the process..."
    new "من چند تمرین انجام دادم، اما او نوعاً در فرآیند گیر افتاده..."

    # say L765 joh
    old "Also, her marriage is in danger, because she doesn't want to have sex with her husband."
    new "همچنین ازدواج او در خطر است، زیرا او نمی‌خواهد با شوهرش جنسیت داشته باشد."

    # say L767 pla
    old "Oh, that's really bad."
    new "اوه، این واقعاً بد است."

    # say L768 joh
    old "Yes, so we need to have noticeable progress as soon as possible, and we are going to achieve that with your help."
    new "بله، پس ما باید سریع پیشرفت قابل توجهی داشته باشیم و با کمک شما این کار را انجام خواهیم داد."

    # say L769 pla
    old "With m- my... Help?"
    new "با کمک من؟"

    # say L770 joh
    old "Well, with the training you've been through we can help..."
    new "با تربیتی که دیده‌ای، ما می‌توانیم کمک کنیم..."

    # say L771 joh
    old "We will need to apply all the concepts that we have worked on so that she can discover how pleasurable sex is."
    new "ما باید تمام مفاهیمی که بررسی کرده‌ایم را اعمال کنیم تا او بتواند لذت جنسی را کشف کند."

    # say L774 joh
    old "Then everything she learns here, she can put into practice with her husband, and our treatment will be successful."
    new "پس همه چیزی که اینجا یاد می‌گیرد، می‌تواند با شوهرش به کار ببرد و درمان ما موفق خواهد بود."

    # say L775 pla
    old "Ohhh, that makes sense..."
    new "اوه، این معقوله..."

    # say L776 joh
    old "Ok, so, please stay in the practice room and I will let you know when to come in to get involved with the session."
    new "خب، لطفاً در اتاق تمرین بمانید و من به شما خواهم گفت وقتی باید برای شرکت در جلسه وارد شوید."

    # say L778 joh
    old "I will need you to be ready, I mean to have your cock prepared when I call you."
    new "باید آماده باشی، منظورم اینه که وقتی من تماس می‌دم، ناخن تو باید آماده باشه."

    # say L781 joh
    old "Remember to stay focused on her pleasure, you'll have to practice everything we've learned, once Angelina is ready I'll let you know."
    new "به خاطر داشته باش روی لذت او تمرکز کن، باید همه چیزی رو که یاد گرفتیم تمرین کنی، وقتی آنجلینا آماده شد ازت خبر خواهم داد."

    # say L783 joh
    old "Ok, now go to the practice room, she could arrive at any time."
    new "خب، حالا برو به اتاق تمرین، ممکنه هر لحظه برسه."

    # say L796 joh
    old "Welcome Angelina, it's pretty nice to have you here again."
    new "خوشحالم که دوباره اینجا هستی، آنجلینا."

    # say L797 ang
    old "Thank you doctor Johnson is good to see you again."
    new "ممنون، خوشحالم که دوباره شما رو می‌بینم، دکتر جانسون."

    # say L798 joh
    old "I'm very happy to hear that, how is it going?"
    new "خوشحالم که اینجایی، آنجلینا. چطوری؟"

    # say L799 ang
    old "Everything is fine I guess, except for what you already know."
    new "همه چیز خوبه فکر کنم، فقط جز آنچه که شما قبلاً می‌دانید."

    # say L800 joh
    old "Tell me about that please, did you see any improvement since the last session?"
    new "لطفاً در مورد آن بگویی، از آخرین جلسه به بعد بهبودی دیده‌ای؟"

    # say L801 ang
    old "Hmm... Well, I'm doing the things that you told me to, but I'm not really comfortable when I'm doing it..."
    new "هم... خب، من کارهایی که به من گفتی رو انجام میدم، ولی وقتی اون کارها رو می‌کنم واقعاً راحت نیستم..."

    # say L802 ang
    old "I have tried all the ways but it feels really disgusting."
    new "من همه راه‌ها رو امتحان کردم ولی واقعاً خیلی نفرت‌برانگیز است."

    # say L803 joh
    old "No worries darling, I understand and it's totally ok, it's part of the expectations we had set previously, so it's ok to feel that way..."
    new "با اطمینان، عزیزم، من درک می‌کنم و کاملاً طبیعی است، این بخشی از آنچه قبلاً مورد انتظار ما بود، پس حس کردن این احساسات کاملاً معمول است..."

    # say L805 ang
    old "You are the only person I feel free to share this with."
    new "تو تنها شخصی هستی که با تو این موضوع را آزاد می‌حسنم بگم."

    # say L806 joh
    old "And I'm here for you, and I'll see to it that we get through this problem once and for all."
    new "و من برای تو هستم، و این مشکل رو به هر قیمتی حل خواهم کرد."

    # say L807 ang
    old "I really appreciate that, because I have nothing else to do and..."
    new "ممنونم، زیرا هیچ کار دیگری ندارم و..."

    # say L810 joh
    old "And? Is it everything ok Angelina?"
    new "و؟ همه چیز خوبه، آنجلینا؟"

    # say L811 ang
    old "I think it is not."
    new "من فکر می‌کنم نه."

    # say L812 joh
    old "Is there something else you think I need to know?"
    new "آیا چیزی هست که برایت مهم است و من باید بدونم؟"

    # say L813 ang
    old "Well, lately we have been fighting a lot because of that."
    new "خوب، اخیراً به خاطر این موضوع بین ما جدال زیادی پیش آمده."

    # say L815 joh
    old "Oh, darling, I understand how hard it must be, it's not your fault of course."
    new "عزیزم، من می‌فهمم چقدر سخت است، البته این گناه تو نیست."

    # say L816 ang
    old "I'd love to think it's not my fault, but I know it is, it's me not working the way it should."
    new "من خوشحالم که فکر کنم این اشتباه من نیست، اما می‌دونم این اشتباه منه، من هستم که مثل باید کار نمی‌کنم."

    # say L817 joh
    old "Honey, I know how you feel, but I've seen the progress from a different perspective and I can assure you that you've been doing your best."
    new "حبیبی، من می‌دونم احساست چیه، ولی از زاویه‌ی دیگه‌ای پیشرفتت رو دیدم و می‌تونم تضمین کنم که تو بهترین‌ت رو انجام دادی."

    # say L819 ang
    old "I'm not sure about that..."
    new "مطمئن نیستم..."

    # say L820 joh
    old "Angelina remember we talked about it at the beginning."
    new "Angelina، به خاطر داشتی که اولین بار صحبت کردیم در مورد این."

    # say L821 joh
    old "Some treatments may take longer than expected and the results won't be seen in the short term, you have to be patient."
    new "برخی درمان‌ها ممکن است طولانی‌تر از حد انتظار طول بکشند و نتایج آن‌ها در کوتاه مدت مشاهده نخواهند شد، باید صبور باشی."

    # say L822 ang
    old "I know, I know, you are right-"
    new "می‌دونم، می‌دونم، درست می‌گیه-"

    # say L823 joh
    old "This is one of the stages we can be on, the treatment is working..."
    new "این یکی از مراحلی است که می‌توانیم در آن باشیم، درمان کار می‌کند..."

    # say L824 joh
    old "We need to keep calm and keep working. I know today's session will show some improvements."
    new "ما باید آرامش داشته باشیم و ادامه بدهیم. مطمئن هستم که جلسه امروز بهبودهایی نشون خواهد داد."

    # say L826 joh
    old "I am sure of it."
    new "من مطمئن هستم."

    # say L827 ang
    old "Oh, great please, I need to get this resolved as soon as possible."
    new "اوه، خوب لطفاً، من باید این مشکل رو هر چه زودتر حل کنم."

    # say L828 joh
    old "Ok, so let's get started. We don't have time to lose."
    new "باشه، بیاین شروع کنیم. وقت زیادی نداریم."

    # say L829 ang
    old "Perfect! Thank you."
    new "عالی! ممنون."

    # say L830 joh
    old "Okay, let's start with the previous exercise, remember? The one with the dildo?"
    new "باشه، بیاییم از تمرین قبلی شروع کنیم، همونی که با دیلدو انجام می‌دی، می‌تونی به خاطر بیاری؟"

    # say L831 ang
    old "Hmm, I'm not sure, I mean, it's quite different when I do it with a dildo than it is with a real one, you know?"
    new "Hmm، من اطمینان ندارم، منظورم اینه که وقتی با دیلدو انجام میدم با یک واقعی خیلی متفاوته، میدونی؟"

    # say L832 joh
    old "Of course, and that is why today we are going to do the exercise bandaged."
    new "البته، و برای همین امروز ما تمرین را با بانداج انجام می‌دهیم."

    # say L833 joh
    old "I want you to focus on the sensations, your caresses, and your mouth."
    new "می‌خوام تمرکزت رو بر احساساتت، لمساتت و دهانت قرار بدی."

    # say L834 ang
    old "Hmm ok, that sounds interesting..."
    new "Hmm خب، این جالب به نظر می‌رسه..."

    # say L835 joh
    old "It is, and today I bring you a new toy, this one is particularly realistic, and this would help us take big steps in treatment..."
    new "بله، و امروز برایت یک اسباب بازی جدید آورده‌ام، این تا حد زیادی واقعی است و می‌تواند ما را درمان به جلو بردارد..."

    # say L836 ang
    old "Huh! That sounds really nice."
    new "اوه! این خیلی خوب به نظر می‌رسه."

    # say L837 joh
    old "Ok, let's get comfortable, and start with the session."
    new "باشه، بیای برای جلسه آماده شویم."

    # say L849 joh
    old "I want you to play with it, rediscover its shape, I want you to immerse yourself in it, discover the textures, the flavors, the sensations."
    new "می‌خوام تو باش باش، شکلش رو دوباره کشف کنی، می‌خوام تو درونش غوطه‌ور بشی، متنها، طعوم، احساسات رو کشف کنی."

    # say L851 joh
    old "Remember that the main objective is to replicate this moment with your husband, try to enjoy it, and focus on pleasure."
    new "به یاد داشته باشید که هدف اصلی این است که این لحظه را با شوهرتان تکرار کنید، سعی کنید لذت ببرید و بر لذت تمرکز کنید."

    # say L852 joh
    old "Keep in mind, his pleasure will also be your satisfaction."
    new "به یاد داشته باش، لذت او هم خوشحالی تو خواهد بود."

    # say L854 joh
    old "Is it good?"
    new "خوبه؟"

    # say L855 ang
    old "Yes."
    new "بله."

    # say L856 joh
    old "Use your whole mouth, your lips, moistened enough that you can move them freely and seductively."
    new "با کل دهانت استفاده کن، لب‌هایت را خیس کن تا بتوانی آنها را آزاد و جذاب حرکت دهی."

    # say L857 ang
    old "I- I think I like it... a bit."
    new "من- من فکر می‌کنم دوست دارم... یه کم."

    # say L858 joh
    old "That is perfect, now let's move on."
    new "این کامل است، حالا بیایید به مرحله بعد برویم."

    # say L865 pla
    old "(Oh God...){i} I- I'm coming.{/i}"
    new "(اوه خداوند...) {i} من- من می‌آیم.{/i}"

    # say L869 joh
    old "Ok, please hold on, here is the new toy. We are going to do the same process we were doing with the previous one."
    new "خوب، لطفاً صبر کنید، این اسباب بازی جدید است. ما همان فرآیندی را که با اسباب بازی قبلی انجام دادیم، ادامه خواهیم داد."

    # say L875 joh
    old "Enjoy this new toy I have for you, the exercise will be better, and you will find it almost real, so please let me know what you think."
    new "لطفاً از این اسباب‌بازی جدید که برایت آورده‌ام لذت ببری، تمرین بهتر خواهد بود و تقریباً واقعی به نظر می‌رسد، پس لطفاً نظراتت را به من بگو."

    # say L877 ang
    old "Oh yes, this texture is really different... Something tasty, warm and the texture is flexible."
    new "اوه بله، این بافت واقعاً متفاوت است... چیزی خوشمزه، گرم و بافت انعطاف‌پذیر."

    # say L878 joh
    old "I'm glad you like it, please do it like we have learned."
    new "خوشحالم که لذت بر می‌آوری، لطفاً مثل آنچه یاد گرفتیم انجام بده."

    # say L888 joh
    old "Yeah, please enjoy it, let's do the exercise, imagine it's natural, think he needs to feel really pleased..."
    new "بله، لطفاً ازش لذت ببر، تمرین رو انجام بده، فکر کن طبیعیه، فکر کن او واقعاً خوشحالمونه..."

    # say L889 joh
    old "Remember to change the rhythm and to use the fluids to make it easier."
    new "به یاد داشته باش تا ریتم رو تغییر بدی و از مایعات برای راحت‌تر کردن استفاده کنی."

    # say L891 joh
    old "Do you think the bandage on your eyes is helping?"
    new "فکر می‌کنی بندای چشم به تو کمک می‌کنه؟"

    # say L892 ang
    old "Absolutely, I'm just thinking on what you are saying and focus on the exercise and the sensations."
    new "حتماً، فقط به آنچه می‌گویی فکر می‌کنم و بر تمرین و احساسات تمرکز می‌کنم."

    # say L893 joh
    old "Perfect, I knew it was going to work..."
    new "عالی، میدونستم که خوب می‌تونی این کار رو انجام بدی..."

    # say L894 ang
    old "This one is pretty nice, it tastes really good."
    new "این خیلی خوبه، طعمش واقعاً خوبه."

    # say L895 joh
    old "That's great, I want you to enjoy it, try a little harder, and think of it as a real one."
    new "عالی است، می‌خواهم لذت ببری، سعی کن بیشتر تلاش کنی و این را مثل یک واقعی در نظر بگیری."

    # say L908 joh
    old "Angelina, relax. This is part of the treatment."
    new "آنجلینا، آرامش کن. این بخشی از درمان هست."

    # say L910 ang
    old "What?! B- But- Who is he? D- Did I sucked his- ? Why didn't you tell me?"
    new "چه کاری؟! اما- اما- او کی هست؟ آ- آیا من- من- من آن- آن- آن را خورده‌ام؟ چرا به من گفتین نمی‌شد؟"

    # say L911 joh
    old "He is one of my assistants and is specifically trained for this."
    new "او یکی از کمک‌کاران من است و برای این کار آموزش داده شده است."

    # say L912 joh
    old "This was necessary, we were stuck for weeks, you needed a shock therapy to progress."
    new "این لازم بود، ما هفته‌ها گیر کرده بودیم، تو نیاز به درمان صدمه‌آمیز داشتی."

    # say L913 ang
    old "What? B- but... I- I cheated on my husband because of you!"
    new "چه؟ اما... من... من برای تو با شوهرم خیانت کردم!"

    # say L914 joh
    old "Again, calm down Angelina..."
    new "دوباره آرام شو Angelina..."

    # say L915 joh
    old "This wasn't cheating, everything was done professionally, in a controlled environment and under my supervision."
    new "این خیانت نبود، همه چیز به صورت حرفه‌ای، در محیط کنترل شده و تحت نظارت من انجام شد."

    # say L917 ang
    old "B- but I sucked another guy's cock and I don't even know him! I can't understand, I didn't want to do this to my husband..."
    new "ولی من لولی یک مرد دیگه رو خوردم و حتی اونو نمی‌شناسم! نمی‌تونم فهمم، من نمی‌خواستم همچین چیزی رو برای شوهرم بکنم..."

    # say L918 joh
    old "Listen Angelina, this is part of the treatment, we have been going through a long process."
    new "انجلا، این بخشی از درمان است، ما طولانی‌ای روندی را طی کرده‌ایم."

    # say L919 joh
    old "And this was a great step, and it's the right one to solve your problem."
    new "و این یک قدم عالی بود، و این همان راه حل صحیح برای مشکلت است."

    # say L920 ang
    old "I- I just-"
    new "من- من فقط-"

    # say L921 joh
    old "Do you realize the results of this session?"
    new "آیا نتایج این جلسه را متوجه شدی؟"

    # say L922 joh
    old "You did great, you were very confident, you enjoyed the session, everything went just as planned."
    new "تو عالی بودی، خیلی اعتماد به نفس داشتی، جلسه را لذت برده بودی، همه چیز دقیقاً مثل برنامه اتفاق افتاد."

    # say L923 ang
    old "B- but... I- I- ... and He... Who is-"
    new "ب- ب-... و او... کی هست-"

    # say L924 joh
    old "Don't worry, [pla] is a very well-trained member of my team."
    new "نگران نباش، [pla] یک عضو خیلی آموزش دیده تیم من است."

    # say L925 joh
    old "He has been prepared by me and has followed the treatments of another patient, he is very professional and trustworthy."
    new "او توسط من آماده شده و درمان‌های یک بیمار دیگر را دنبال کرده، او خیلی حرفه‌ای و اعتماد‌برانگیز است."

    # say L928 ang
    old "I'm sorry, but I can't accept this, I feel like I'm betraying my husband..."
    new "متأسفم، اما نمی‌توانم این را قبول کنم، حس می‌کنم همسرم را خیانت می‌کنم..."

    # say L929 ang
    old "I think there was a misunderstanding about this... I need to go."
    new "من فکر می‌کنم اینجا سوء تفاهمی پیش آمده... من باید برسم."

    # say L937 pla
    old "Wow, she has left!"
    new "wow، او رفت!"

    # say L938 joh
    old "It's okay, she has a lot of emotions to think about."
    new "خوب است، او باید احساسات زیادی را بررسی کند."

    # say L939 joh
    old "So she's going to need some time to process what happened and understand what was necessary within his process."
    new "پس او به یک دور زمانی نیاز دارد تا اتفاقات رخ داده را پردازش کند و لزوم آن در فرآیند او را درک کند."

    # say L941 joh
    old "Absolutely! That's what is called 'shock therapy'."
    new "البته! این به آن چیزی می‌گویند که «درمان صدمه‌آمیز» است."

    # say L942 pla
    old "But, looks like she feels pretty bad."
    new "ولی به نظر می‌رسه خیلی بد حس می‌کنه."

    # say L944 joh
    old "Well, it is something that needs to happen."
    new "البته، این چیزی است که باید اتفاق بیفتد."

    # say L945 joh
    old "She is dealing with changing the most ingrained ideas about her sexuality and the way she expresses her love, so she needs time."
    new "او در حال برخورد با تغییرات عمیق‌ترین ایده‌هایش درباره جنسیت خود و نحوه بیان عشقش است، پس به او وقت لازم بدهیم."

    # say L947 joh
    old "The only thing we can do is wait until she internalizes these new emotions and figure out how to deal with them."
    new "تنها چیزی که می‌توانیم انجام بدیم این است که منتظر بمانیم تا او این احساسات جدید را درونی کند و بفهمد چطور با آنها برخورد کند."

    # say L948 pla
    old "I understand."
    new "من درک کردم."

    # say L949 joh
    old "I appreciate your commitment, you did an amazing job today."
    new "ممنونم از تعهد شما، امروز کار عالی کردید."

    # say L950 joh
    old "I'm sorry, but I have to go, another patient should be here in a few minutes."
    new "متاسفم، اما باید برسم، بیمار دیگری باید در چند دقیقه بعد برسد."

    # say L951 pla
    old "Oh ok... But when should I come again?"
    new "اوه خب... ولی من باید چه زمانی دوباره بیام؟"

    # say L952 joh
    old "Once Angelina books her next session I will let you know, for now you can come in the morning to continue training."
    new "باز هم وقتی آنجلینا جلسه بعد رو رزرو کرد، اطلاع می‌دهم. برای الان می‌تونی صبح بیاد برای ادامه تمرین."

    # say L954 joh
    old "Thank you and see you later [pla]."
    new "ممنون و تا بعدی می‌بینیم [pla]."

    # say L955 pla
    old "Ok, see you doctor."
    new "باشه، تا بعد دکتر."

    # say L973 roo
    old "No Angelina, I can't tolerate this anymore!"
    new "نگاه نکنم، آنجلینا، دیگه نمی‌تونم اینو تحمل کنم!"

    # say L974 ang
    old "I'm doing all what I can, just to make you happy."
    new "من همه چیز رو انجام می‌دم تا تو خوشحال شی."

    # say L975 roo
    old "I don't see the effort you make, and I'm tired of waiting so long for you."
    new "من تلاشت رو نمی‌بینم و از این طولانی منتظر شدن خسته شدم."

    # say L976 ang
    old "Why are you such a prick? You can't see how much I love you..."
    new "چرا اینقدر خسته‌کننی هستی؟ نمی‌تونی ببینی چقدر دوستت دارم..."

    # say L977 roo
    old "I know that but I need a real woman, not a beautiful doll beside me..."
    new "من این رو می‌دونم ولی من به یه زن واقعی نیاز دارم، نه یه عروسک زیبا کنارم..."

    # say L978 roo
    old "I have been really patient... But I can't wait anymore... Look for me when you are ready to have sex like a normal person."
    new "من واقعاً صبور بودم... اما دیگر نمی‌توانم منتظر بمانم... وقتی آماده‌ی جنس مثل یک انسان عادی شدی، به من نگاه کن."

    # say L979 ang
    old "Come on darling... Please, you know this is hard for me..."
    new "بیا لب زن... لطفاً، می‌دونی این برای من سخته..."

    # say L980 roo
    old "Are you serious? Listen 5 months without sex I- I... You know what? I will not discuss it anymore, see you later at home..."
    new "می‌خواهی جدی باشی؟ بگوش ۵ ماه بدون سکس من- من... دیگه نمی‌خواهم در این مورد صحبت کنم، بعداً خونه ببین‌ت..."

    # say L987 ang
    old "Wait! Roonnie- !"
    new "بیا! روونی-"

    # say L994 pla
    old "I'm sorry..."
    new "من خودم هم آسونم..."

    # say L999 ang
    old "It's ok, welcom-"
    new "خوبه، خوشحالم که..."

    # say L1000 ang
    old "(WHAT IS HE DOING HERE?.)"
    new "اوه، اینجا چه کاری داره؟"

    # say L1001 pla
    old "Huh, t- thank you."
    new "هی، ممنون."

    # say L1002 ang
    old "N- nice to see you again... Ehh-"
    new "خوشحالم که دوباره دیدت می‌کنم... اوه-"

    # say L1004 ang
    old "Yes, the doctor Johnson's... assistant, right?"
    new "بله، کمک‌کننده دکتر جانسون هستی، درسته؟"

    # say L1006 pla
    old "Right, is Roonnie your husband?"
    new "بله، رونی همسرتون هست؟"

    # say L1008 ang
    old "Hmm it seems like not for long... Anyway, how are you?"
    new "Hmm به نظر می‌رسه نه برای طول زمان... بقیه‌اش چطوری؟"

    # say L1010 pla
    old "I'm fine, thanks for asking..."
    new "من خوبم، ممنون از سؤالت..."

    # say L1011 ang
    old "Great, and what are you doing here?"
    new "عالی، تو اینجا چه کاری داری؟"

    # say L1012 pla
    old "I'm sorry, I was not aware you were here-"
    new "ببخشید، نمی‌دونستم تو اینجا هستی-"

    # say L1013 ang
    old "Oh no don't worry, actually, I'm sorry that you had to listen to all of... This."
    new "اوه نه، نگران نباش، در واقع من هستم که متاسفم که باید به همه این‌ها گوش کردی."

    # say L1014 pla
    old "Oh no, it wasn't my intention, I- I didn't know-"
    new "نه، من قصد نداشتم، من- من نمی‌دونستم-"

    # say L1015 ang
    old "Never mind, though, I've been thinking about last time and wanted to apologize for the incident in Dr. Johnson's office."
    new "نه، ولی من از آن بار فکر کرده‌ام و می‌خواستم برای اتفاقی که در دفتر دکتر جانسون افتاد، عذرخواهی کنم."

    # say L1016 pla
    old "Oh, no worries about that, I'm sorry about you and husband, I know it's something hard to deal with."
    new "اوه، نگرانی نداشته باش، من هم برای تو و شوهرت عذرخواهم، می‌دونم این موضوع سختی برای توست."

    # say L1017 ang
    old "Yes, he is lovely but he is also tired, he is right about what he says, I can't satisfy his needs..."
    new "بله، او عزیزم ولی خسته است، در مورد آنچه می‌گوید درست است، نمی‌توانم نیازهایش را برآورده کنم..."

    # say L1019 ang
    old "I'm sorry to tell you all this, I don't even know you..."
    new "متاسفم این همه چیز رو به تو بگم، حتی نمی‌دونم تو رو..."

    # say L1020 pla
    old "It's ok, don't worry."
    new "باشه، نگران نباش."

    # say L1021 ang
    old "I appreciate that... And I still embarrassed about the last time-"
    new "ممنونم... هنوز خجالت‌زده‌ام از آخر بار-"

    # say L1022 pla
    old "Oh please forget it, it's not important."
    new "لطفاً فراموش کن، اهمیتی نداره."

    # say L1023 ang
    old "It is, I was disrespectful to both of you and left the place without any explanation, and it's not your fault of course."
    new "بله، من به هر دوی شما نااحترام کردم و بدون هیچ توضیحی از جایی رفتم، و البته این اشتباه شما نیست."

    # say L1025 ang
    old "I felt like I was betraying my husband, I had never cheated on him and I really love him..."
    new "احساسی داشتم که به شوهرم غدر می‌کنم، هیچ وقت برایش غیبت نکرده‌ام و واقعاً ازش دوست دارم..."

    # say L1026 ang
    old "I still don't know why doctor Johnson did something like that."
    new "هنوز هم نمی‌دونم چرا دکتر جانسون چیزی اینجوری کرد."

    # say L1027 pla
    old "I understand your point, I can't say too much because I was part of the session but..."
    new "من درکت رو می‌فهمم، نمی‌تونم خیلی زیاد بگم چون من هم بخشی از آن جلسه بودم..."

    # say L1028 pla
    old "I know she is quite good at what she does, I have seen the progress of other patients."
    new "می‌دونم او خیلی خوبه توی کارش، دیدم پیشرفت بیماران دیگه."

    # say L1031 pla
    old "Yes, that is why I met her, because one of my friends needed help."
    new "بله، همین جلایی بود که با او آشنا شدم، چون یکی از دوست‌هام نیاز به کمکش داشت."

    # say L1032 pla
    old "And it was a very surprising thing to see how she changed and how positive it was for her."
    new "و خیلی شگفت‌زده شدم وقتی دیدم چطور تغییر کرد و این تغییر برایش چقدر مثبت بود."

    # say L1033 ang
    old "Hmm, I don't know..."
    new "Hmm، نمی‌دونم..."

    # say L1034 pla
    old "I know, at the beginning I was sceptical..."
    new "می‌دونم، اول خیلی شک‌کار بودم..."

    # say L1035 pla
    old "But later on, my friend was improving so much that I had to be honest and recognize how amazing she did it with her treatment."
    new "اما بعداً، دوستم به حدی بهتر شد که باید صادق باشم و بپذیرم چقدر عالی با درمانش کار کرد."

    # say L1036 ang
    old "I think I am sceptical now..."
    new "فکر کنم الان شک‌کار هستم..."

    # say L1037 pla
    old "It is pretty normal, your process is not easy and these experiences are new for everyone."
    new "این خیلی طبیعیه، فرآیند تو سخته و این تجربیات برای همه جدیده."

    # say L1038 pla
    old "However, if she dares to try this method, it is because she knows you well enough."
    new "البته، اگر او به این روش جرات کرد، به خاطر این است که تو را خوب می‌شناسد."

    # say L1040 pla
    old "I must confess that I was a bit nervous, but we were in a very professional environment."
    new "باید بگم که یه کم نگران بودم، اما ما در محیطی خیلی حرفه‌ای بودیم."

    # say L1041 pla
    old "Everything was planned to make sure that you could overcome your fear."
    new "همه چیز طراحی شده بود تا مطمئن شوم تو بتونی از ترس خودت پیروز شی."

    # say L1042 ang
    old "Hmm, I thinnk you are right, maybe I overreacted that day, my marriage needs whatever effort I can make."
    new "هم، فکر کنم همینطوره، شاید آن روز واکنش بیش از حدی دادم، ازدواج من به هر تلاوتی که می‌توانم نیاز داره."

    # say L1043 pla
    old "I know you were confused but I am sure doctor Johnson is expecting to see you again no matter what happens before."
    new "میدونم تو حیرت‌زده بودی اما مطمئنم دکتر جانسون منتظرت هست، بی‌تفکیک از این که قبل از اون چه اتفاقی بیفتد."

    # say L1044 ang
    old "I owe her an apology, but yes I need to solve this problem as soon as possible."
    new "من باید از او عذرخواهی کنم، اما بله، باید این مشکل رو هر چه زودتر حل کنم."

    # say L1045 pla
    old "She will be very happy to see you and the most important thing you can continue the process you are in, you need to trust her."
    new "او خوشحال می‌شه از دیدنت و مهم‌ترین چیز اینه که تو باید اعتماد بهش داشته باشی، فرآیندی که شروع کردی رو باید ادامه بدی."

    # say L1046 ang
    old "You're right, I need this now more than ever, my husband is about to dump me, so I'll do whatever it takes."
    new "درست می‌فرمایی، الان بیش از همیشه به این نیاز دارم، شوهرم قراره من رو ترک کنه، پس هر چه باید بکنم انجام می‌دم."

    # say L1047 pla
    old "Don't worry, visit doctor Johnson, she will help you."
    new "نگران نباش، به دکتر جانسون برو، او بهت کمک خواهد کرد."

    # say L1048 ang
    old "Hmm alright, I will do an appointment,  I think I need to continue with my treatment, thank you so much for your words."
    new "Hmm خب، من یک نوبت می‌گیرم، فکر می‌کنم باید درمانم رو ادامه بدم، ممنونم از کلماتت."

    # say L1049 pla
    old "You are welcome,I hope things improve soon."
    new "خواهش می‌کنم، امیدوارم زودباد باشه."

    # say L1050 ang
    old "I appreciate it."
    new "ممنونم."

    # say L1051 pla
    old "Good bye."
    new "خداحافظ."

    # say L1052 ang
    old "Bye Bye."
    new "خداحافظ."

    # say L1076 joh
    old "Welcome back Angelina, I am very happy to have you here again."
    new "خوش آمدی آنجلینا، خیلی خوشحالم که دوباره اینجا هستی."

    # say L1077 ang
    old "Hi doctor, I'm terribly sorry for my behavior last time..."
    new "سلام دکتر، برای رفتار خودم آخر بار خیلی متاسفم..."

    # say L1078 joh
    old "Listen, the past is just a page we can't see anymore. Now tell me, how is everything going?"
    new "بگو، گذشته فقط صفحه‌ای است که دیگر نمی‌توانیم ببینیم. حالا بگو، همه چیز چطوره؟"

    # say L1079 ang
    old "I need your help, my husband will dump me anytime because of my problem and I don't know what to do."
    new "دکتر، من به شما نیاز دارم، همسرم هر لحظه ممکنه از من جدا شه به خاطر مشکلم و من نمی‌دونم چی کنم."

    # say L1080 joh
    old "Hmm, okay, we have to think carefully because we'll need something that will deliver immediate results."
    new "Hmm، باید دقت کنیم زیرا باید چیزی پیدا کنیم که نتایج سریعی بده."

    # say L1091 joh
    old "Oh, [pla], welcome, I'm glad to see you here."
    new "اوه، ز[pla]، خوش آمدید، خوشحالم که شما اینجا هستید."

    # say L1092 pla
    old "Hello Dr. Johnson, hi Angelina."
    new "سلام دکتر جانسون، سلام آنژلینا."

    # say L1095 joh
    old "Well, now that [pla] is here, I have an idea to go ahead with the treatment."
    new "خب، حالا که [pla] اینجا است، من یه ایده برای ادامه درمان دارم."

    # say L1096 joh
    old "But how do you feel about what happened last time with [pla]?"
    new "اما تو از آن چه که بار قبل با [pla] اتفاق افتاد چطور احساس می‌کنی؟"

    # say L1097 ang
    old "Hmm, I had a chance to talk to him and now I feel much better."
    new "هم، من فرصت حرف زدن با او رو داشتم و حالا حس خوبتری دارم."

    # say L1098 joh
    old "Oh really? Well, that makes things a lot easier for us."
    new "اوه واقعاً؟ خب، این برای ما کار راحت‌تر می‌کنه."

    # say L1099 joh
    old "All right, then, today we are going to continue the treatment."
    new "البته، امروز ما به درمان خود ادامه می‌دهیم."

    # say L1100 joh
    old "So, [pla] remember that we will need to apply all the concepts you have learned."
    new "پس، [pla] به یاد داشته باشی که ما باید تمام مفاهیمی که یاد گرفتی را اعمال کنیم."

    # say L1102 joh
    old "But before we start I want you to help her to get relaxed a bit so please give her a massage."
    new "اما قبل از شروع می‌خواهم کمی به آرامش برسی، پس لطفاً ماساژشو بده."

    # say L1104 joh
    old "Also, Angelina, I want you to become more familiar with the image of your husband."
    new "همچنین، آنجلینا، می‌خواهم تو با تصویر شوهرت آشنا‌تر شوی."

    # say L1105 joh
    old "So, [pla] will help us with that, he will play the role of your husband."
    new "پس، [pla] به ما در این کار کمک خواهد کرد، او نقش شوهرت را ایفا خواهد کرد."

    # say L1107 joh
    old "We will start with a basic exercise, this will prepare your mind and body, then we will have the real session."
    new "ما با یک تمرین ابتدایی شروع می‌کنیم، این برای آماده‌سازی ذهن و بدن توست، سپس جلسه واقعی را برگزار می‌کنیم."

    # say L1108 joh
    old "So, let's begin, please take off your shirt."
    new "پس، بیایید شروع کنیم، لطفاً پیجامات رو ببرد."

    # say L1109 ang
    old "But... I- I'm not wearing a bra..."
    new "ولی... من- من هیچ برا نمی‌پوشم..."

    # say L1110 joh
    old "I know that darling."
    new "میدونم عزیزم."

    # say L1111 ang
    old "So, do you mean stay topless?"
    new "پس، منظورت اینه که بدون پیراهن بمونم؟"

    # say L1112 joh
    old "That's correct, he will give you a little breasts massage, so, you can relax and get in the mood for the next exercise."
    new "درست است، او به تو مassage کوچکی در سینه می‌دهد، پس می‌توانی آرام شو و برای تمرین بعدی آماده شوی."

    # say L1115 ang
    old "I- I am not... Sure about it..."
    new "من- من در مورد این اطمینان ندارم..."

    # say L1116 joh
    old "Oh, darling, don't worry, we're already working on that, right? You shouldn't feel insecure about your body..."
    new "اوه، عزیزم، نگران نباش، ما قبلاً روی این کار کار کرده‌ایم، درسته؟ نباید از بدن خودت ناامن باشی..."

    # say L1117 ang
    old "I know, but... Having a man in the room makes this a little more difficult..."
    new "میدونم، اما... وجود مرد در اتاق این کار رو کمی سخت‌تر می‌کنه..."

    # say L1119 joh
    old "I know you had a tough adolescence, your body grew fast and you didn't feel comfortable about it..."
    new "میدونم تو دوران نوجوانی سختی داشتی، بدن تو به سرعت رشد کرد و تو راحت نبودی..."

    # say L1120 joh
    old "But, you already know that your body is beautiful, all men love it, your husband loves it, right?"
    new "ولی تو قبلاً می‌دونی که بدن تو زیباست، همه مردان دوستش دارن، شوهرت هم دوستش داره، درسته؟"

    # say L1121 ang
    old "Yes, but he doesn't care..."
    new "بله، اما او نمی‌گیرد..."

    # say L1123 joh
    old "Of course not, you are very hot, you are incredible, what do you think [pla]? You like them? Those are bigger than mine, aren't they?"
    new "البته نه، تو خیلی جذابی، تو عالی هستی، فکر می‌کنی [pla]؟ می‌پسندی؟ اونا بزرگتر از من هستن، درسته؟"

    # say L1125 pla
    old "... Y- yes... I think you have a hug-... Beautiful boobs..."
    new "... ب-بله... فکر می‌کنم داری چ-... چشم‌پوش‌های زیبا..."

    # say L1127 joh
    old "Honey, I can tell you that I have not seen a more beautiful breast."
    new "حبیبی، می‌تونم بهت بگم که زیباتر از این سینه هیچی ندیده‌ام."

    # say L1128 ang
    old "It's the first time someone tells me that..."
    new "این اولین باره کسی به من اینجوری می‌گه..."

    # say L1129 joh
    old "It's not going to be the last time. I'm sure, now please get comfortable because our session about to begins."
    new "این آخرین بار نیست. اطمینان دارم، حالا لطفاً راحت شوید زیرا جلسه‌مان قرار است شروع شود."

    # say L1130 joh
    old "I told you and I want you to enjoy it a lot... [pla], please!"
    new "من به شما گفتم و می‌خواهم خیلی لذت ببرید... [pla]، لطفاً!"

    # say L1131 pla
    old "Of course!"
    new "البته!"

    # say L1132 ang
    old "Thank... You..."
    new "ممنون... شما..."

    # say L1133 joh
    old "Alright, let's take out those big babies..."
    new "خوب، بیایید این بچه‌های بزرگ رو بیرون ببریم..."

    # say L1139 joh
    old "Ohhh, they are really beautiful... Don't you think [pla]?"
    new "اوه، واقعاً زیبا هستند... تو هم همینطور فکر می‌کنی [pla]؟"

    # say L1141 joh
    old "Hahaha, you see Angelina, now he is speechless... Come on, [pla] please have a seat, and you Angelina, have a seat over his lap."
    new "حاحاحا، می‌بینی آنجلینا، حالا او بی‌صدا شده... بیا، [pla] لطفاً جای خودت بنشین، و تو آنجلینا، روی کمرش بنشین."

    # say L1151 joh
    old "Ok, [pla] to start, do it gently..."
    new "باشه، [pla] برای شروع، لطفاً آرام‌آرام انجام بدی..."

    # say L1152 pla
    old "Ok, like this?"
    new "بله، مثل این؟"

    # say L1153 joh
    old "Yeah, how do you feel Angelina?"
    new "بله، انجلینا، احساست چطوره؟"

    # say L1154 ang
    old "I- It's ok... I'm fine..."
    new "خوبه... من خوبم..."

    # say L1165 ang
    old "Next exercise?"
    new "بعد تمرین بعدی؟"

    # say L1166 joh
    old "It's ok, You just follow [pla], he will walk you through. Now please take off your clothes."
    new "خوبه، فقط به [pla] دنباله بده، او راهنمایت می‌شه. حالا لطفاً لباسات رو ببرد."

    # say L1167 ang
    old "Do you want me to take off everything?"
    new "می‌خوای من همه لباسام رو ببرم؟"

    # say L1169 joh
    old "Yes, please, and then lie on the bed..."
    new "بله، لطفاً، و بعد روی تخت بخواب..."

    # say L1170 ang
    old "... Hmm alright."
    new "حسناً، خوب."

    # say L1172 joh
    old "Ohh, look at that, you so thick girl... Ok [pla], now is your turn."
    new "اوه، نگاه کن، چقدر ضخیمی داری دختر... خب [pla]، حالا نوبت تو هست."

    # say L1173 pla
    old "My... T- turn? What do you mean?"
    new "من... تورم؟ منظورت چیه؟"

    # say L1174 joh
    old "I'm sorry, I meant it's your turn to please Angelina. Now give oral sex to her."
    new "ببخشید، من قصد داشتم بگم حالا نوبت شماست برای لذت‌بخشی آنجلینا. حالا جنس شفاهی به او بده."

    # say L1175 ang
    old "O- oral sex?"
    new "ا- ارگازم شفاهی؟"

    # say L1177 joh
    old "Ok, Angelina, please remember this is part of the treatment for you, and your marriage."
    new "خوب، آنجلینا، لطفاً به یاد داشته باش این بخشی از درمان برای تو و ازدواجت است."

    # say L1178 ang
    old "You are right, I'm sorry."
    new "درست می‌فرمایید، متاسفم."

    # say L1179 joh
    old "It's ok, let's move on, [pla] do your job, please."
    new "خوب، بیایید ادامه بدیم، [pla] لطفاً کارتو انجام بده."

    # say L1189 joh
    old "Close your eyes Angelina, focus on the sensations, and enjoy the experience."
    new "چشم‌هایت رو ببند Angelina، بر روی احساسات تمرکز کن و از تجربه لذت ببر."

    # say L1190 ang
    old "I will try..."
    new "سعی می‌کنم..."

    # say L1199 joh
    old "Keep focused [pla], use your tongue like we have learned."
    new "مرکز توجهت رو حفظ کن [pla]، مثل آنچه یاد گرفتیم با زبانت کار کن."

    # say L1211 ang
    old "Wow, you can't imagine how happy I feel."
    new "وای، نمی‌تونی تصور کنی چقدر خوشحالم."

    # say L1213 joh
    old "Well, that's fantastic because it means the process is working out."
    new "البته، این خبر خوب است زیرا نشان می‌دهد که فرآیند کار می‌کند."

    # say L1214 joh
    old "If you feel more confident to have sexual interactions, it means you are ready to try this with your husband with no fears."
    new "اگر احساس اطمینان بیشتری برای تعاملات جنسی داری، این بدان معناست که آماده‌ی امتحان این موضوع با شوهرت با هیچ ترسی هستی."

    # say L1216 joh
    old "Great, so let's get dressed and go to the therapy bedroom."
    new "عالی، پس بیایید لباس بگذاریم و برویم به اتاق خواب درمان."

    # say L1217 ang
    old "Ok!"
    new "باشه!"

    # say L1226 joh
    old "Ok, it was everything for today, but we need to continue working pretty hard."
    new "خوب، امروز همه چیز خاتمه یافت، اما ما باید خیلی سخت کار کنیم."

    # say L1227 joh
    old "Next session is really important, so, guys please get ready and see you soon."
    new "جلسه بعدی خیلی مهم است، پس لطفاً آماده شوید و تا زودی می‌بینم شما."

    # say L1229 ang
    old "Oh thank you, I will be here on time, bye bye!"
    new "ممنون، من هم زودتر اینجا خواهم بود، خداحافظ!"

    # say L1230 pla
    old "Good bye!"
    new "خداحافظ!"

    # say L1245 joh
    old "Hi Angelina, how is everything going?"
    new "سلام آنجلینا، همه چیز خوب است؟"

    # say L1246 ang
    old "Wonderful! I applied what we did with my husband and he was really happy, now I just want to learn more."
    new "عالی! آنچه با شوهرم انجام دادیم را اعمال کردم و او خیلی خوشحال شد، حالا فقط می‌خواهم بیشتر یاد بگیرم."

    # say L1247 joh
    old "And you will, our session today is aimed at helping you do more exercises with your husband."
    new "و خواهی، جلسه ما امروز هدفش این است که بهت کمک کنم تمرین‌های بیشتری با شوهرت انجام بدی."

    # say L1248 ang
    old "Sounds great!"
    new "عالی است!"

    # say L1258 pla
    old "Hi, how are you doing?"
    new "سلام، چطوری؟"

    # say L1259 ang
    old "Hi [pla], I'm doing amazing."
    new "سلام [pla]، من واقعاً خوب هستم."

    # say L1260 joh
    old "Welcome [pla], good to see you again, are you ready to start the new session?"
    new "خوش آمدی [pla]، خوشحالم که دوباره اینجا هستی، آماده شروع جلسه جدید هستی؟"

    # say L1261 pla
    old "Yes, I am ready."
    new "بله، آماده‌ام."

    # say L1265 joh
    old "Ok, Angelina, this time we are going to practice a fellation, this time with no fears and doing your best, ok?"
    new "خوب، آنجلینا، این بار ما تمرین زدن شادی مرد رو خواهیم کرد، این بار بدون هیچ ترسی و با تمام تلاشتت، خب؟"

    # say L1266 ang
    old "Oh... I had to... S- suck his cock?"
    new "اوه... من باید... س- سیک او رو بکنم؟"

    # say L1268 joh
    old "Of course, last time you received all the pleasure, today we will make sure that you are able to provide it too."
    new "البته، بار قبل تو تمام لذت را تجربه کردی، امروز قرار است این بار تو بتوانی آن را هم به دیگران بدهی."

    # say L1269 joh
    old "So that we can guarantee that your husband will also be satisfied."
    new "پس ما می‌توانیم اطمینان حاصل کنیم که شوهرت هم راضی شود."

    # say L1271 ang
    old "Hmm, I guess you are right..."
    new "Hmm، به نظر می‌رسه درست می‌گویی..."

    # say L1272 joh
    old "Great, just remember what we had practiced before with the dildo, and by the way you already sucked his cock before, so don't worry."
    new "عالی، فقط به خاطر داشته باش چیزی که قبلاً با دیلدو تمرین کردیم، و اصلاً نگران نباش، قبلاً نیم‌شون رو خورده‌ای."

    # say L1274 joh
    old "Ok, our time is short we need to work, so, let's start. [pla], take off your pants and Angelina, please start the fellation."
    new "باشه، وقت ما کوتاهه، باید شروع کنیم. [pla]، لباس پایینتو ببر و آنجلینا، لطفاً شروع به فلیشن کن."

    # say L1286 ang
    old "Hmm... "
    new "Hmm..."

    # say L1288 joh
    old "Please enjoy it Angelina, try to focus only on what you feel, like last time, don't think about [pla], just enjoy what you can feel."
    new "لطفاً از این لذت برخوردار شو Angelina، فقط به آنچه احساس می‌کنی تمرکز کن، مثل آخرین بار، درباره [pla] فکر نکن، فقط آنچه احساس می‌کنی را برخوردار شو."

    # say L1300 joh
    old "Alright, now let's continue with the next exercise."
    new "البته، حالا بیایید به تمرین بعدی برویم."

    # say L1303 ang
    old "NEXT EXERCISE?"
    new "وای، تمرین بعدی؟"

    # say L1305 joh
    old "Of course, you're the one asking for faster improvement, aren't you?"
    new "البته، تو هستی که درخواست تسریع در بهبود رو کردی، نه؟"

    # say L1306 joh
    old "Also, we need you to be able to have sex with your husband as soon as possible, so your marriage can be saved."
    new "همچنین، باید بتونی با زوجت جنس کنی تا ازدواجتو نجات بدهی."

    # say L1307 ang
    old "Hmm, you're right..."
    new "هم، درست می‌فرمایید..."

    # say L1308 joh
    old "Alright, let's go to the bedroom, so you can have sex with [pla]."
    new "باشه، بیایید به اتاق خواب بریم تا تو بتونی با [pla] جنس کنی."

    # say L1310 ang
    old "Sex?"
    new "جنس؟"

    # say L1311 joh
    old "Oh, relax, you are going to love it."
    new "اوه، آرامش بگیر، حتماً دوست خواهی داشت."

    # say L1318 joh
    old "Alright, [pla] I need you to remember your trainin."
    new "باشه، [pla] باید به یادت باشه تمریناتت رو."

    # say L1319 joh
    old "You're going to have sex but you can't stop until she has reached the orgasm."
    new "شما جنس خواهید کرد اما نمی‌توانید تا زمانی که او به ارگاسم رسیده، متوقف شوید."

    # say L1323 joh
    old "Angelina, I need you to understand this, in your treatment, there is no way to learn about sex without having sex."
    new "آنجلینا، باید این را درک کنی، در درمانت، راهی برای یادگیری جنسی بدون داشتن رابطه جنسی وجود نداره."

    # say L1324 joh
    old "That is why we are here in a safe therapy so that you learn to enjoy it."
    new "این به همین خاطر هستیم اینجا در یک درمان ایمن تا بیاموزی لذت بردن از آن."

    # say L1325 ang
    old "... Ok, thank you doctor Johnson."
    new "... خب، ممنونم دکتر جانسون."

    # say L1326 joh
    old "Alright, please, both get naked and let's start."
    new "خوب، لطفاً هر دو عریان شوید و بیایید شروع کنیم."

    # say L1352 ang
    old "Wow, that was really good, I thank you so much doctor Johnson."
    new "واو، این واقعاً خوب بود، ممنونم از شما دکتر جانسون."

    # say L1353 joh
    old "You still have a lot to learn, but now you are open to new experiences, and [pla] you did an outstanding job."
    new "هنوز خیلی چیزهایی باید یاد بگیری، اما حالا برای تجربیات جدید آماده‌ای و [pla] کار عالی کردی."

    # say L1355 ang
    old "Yes, you [pla], you made me feel things I've never felt before with any man."
    new "بله، شما [pla]، شما منو احساساتی داشتن دادید که هیچ مردی قبلاً نداده بود."

    # say L1356 pla
    old "... I- I'm glad everything turned out okay..."
    new "... من- من خوشحالم که همه چیز خوب پایان یافت..."

    # say L1358 joh
    old "Alright, get dressed and let's go to the therapy room, I have a new patient in a few minutes."
    new "خوب، لباست رو بپوش و بیا به اتاق درمان، چند دقیقه دیگه بیمار جدیدی دارم."

    # say L1368 joh
    old "Alright, please apply these exercises with your husband."
    new "البته، لطفاً این تمرین‌ها را با شوهرتان انجام دهید."

    # say L1369 joh
    old "Focus on enjoying, but don't push it, as you will see the changes gradually."
    new "به لذت تمرکز کن، اما فشار نده، تغییرات رو به تدریج خواهی دید."

    # say L1370 ang
    old "Ok, I will have that in mind."
    new "خوب، این موضوع را در نظر خواهم گرفت."

    # say L1371 joh
    old "I'm glad to see you happy, I can't wait to hear how it went with your husband."
    new "خوشحالم که خوشحالی می‌بینم، نمی‌توانم صبر کنم تا بشنوم چطور با شوهرت پیش رفت."

    # say L1372 ang
    old "Yes, I am a little anxious to try it as soon as possible."
    new "بله، من کمی نگران هستم تا زودتر امتحانش کنم."

    # say L1373 joh
    old "Okay, then don't waste any more time and go home. See you at the next session, darling."
    new "خوب، پس وقت بیشتری را تلف نکن و برو خانه. تا جلسه بعد می‌بینم، عزیزم."

    # say L1374 ang
    old "Alright, thank you so much!"
    new "البته، ممنونم خیلی."

    # say L1375 joh
    old "See you. And please, have fun!"
    new "ببینم. و لطفاً لذت ببر!"

    # say L1385 joh
    old "That was a significant step with her therapy."
    new "این مرحله مهمی برای درمان او بود."

    # say L1387 joh
    old "And you, Congratulations on such a fantastic performance, I can see that my lessons were very helpful, maybe better than I thought."
    new "و شما، مبارک با، این عملکرد فوق العاده را داشتی. می‌بینم درس‌های من برایت خیلی مفید بود، شاید حتی بیشتر از آنچه فکر می‌کردم."

    # say L1388 pla
    old "Thank you, I appreciate all your patient with me."
    new "ممنون، خوشحالم از صبرتان با من."

    # say L1389 joh
    old "You are welcome. Anyway, I have to get ready for my next patient, so, see you at the next session."
    new "خواهش می‌کنم. هر حال، باید برای بیمار بعدی آماده شوم، پس تا جلسه بعد می‌بینیم."

    # say L1390 pla
    old "Sure, good bye Dr. Johnson."
    new "البته، خداحافظ دکتر جانسون."

    # say L1406 joh
    old "Welcome Angelina, how is everything going?"
    new "خوش آمدی آنژلینا، همه چیز خوب است؟"

    # say L1407 ang
    old "I couldn't be happier."
    new "من هیچ وقت اینقدر خوشحال نبوده‌ام."

    # say L1408 joh
    old "So, were you able to do the exercises with your husband without problems? "
    new "پس، تونستی این تمرین‌ها رو با شوهرت بدون مشکل انجام بدی؟"

    # say L1409 ang
    old "That's right! And my husband is really happy, your work is incredible!"
    new "بله! و شوهرم خیلی خوشحال است، کار شما واقعاً شگفت‌انگیز است!"

    # say L1410 joh
    old "I'm so happy to hear that! I've prepared a new lesson today, you'll love it..."
    new "خوشحالم که اینطور شنیدم! امروز درس جدیدی آماده کردم، حتماً دوستش خواهی داشت..."

    # say L1421 joh
    old "Welcome [pla], we are happy to have you here."
    new "خوش آمدید [pla]، خوشحالم که شما اینجا هستید."

    # say L1422 pla
    old "Hello!"
    new "سلام!"

    # say L1423 ang
    old "Hi, [pla]!!"
    new "سلام، [pla]!!"

    # say L1425 joh
    old "Well guys, now [pla] is here, there's no time to lose, so, let's go to the room."
    new "خب بچه‌ها، حالا که [pla] اینجا هست، وقت کمی برای تردد نیست، بیایید به اتاق برویم."

    # say L1426 ang
    old "Perfect!"
    new "عالی!"

    # say L1434 joh
    old "According to the advances that you mentioned that sex with your husband is reaching... Let's practice again with a sexual exercise."
    new "بر اساس پیشرفت‌هایی که اشاره کردی، جنس با شوهرت به مرحله‌ای رسیده است... بیای، دوباره با یک تمرین جنسی تمرین کنیم."

    # say L1436 joh
    old "But, before we start, I want you to practice oral sex, that will drive your husband crazy."
    new "البته، قبل از شروع، می‌خوام تو تمرین جنسی شفاهی رو انجام بدی، این کار همسرت رو خیلی دیوانه می‌کنه."

    # say L1437 ang
    old "Got it! I want to make sure I'm doing this the right way for my husband."
    new "فهمیدم! می‌خوام مطمئن شم که این کار رو به درستی برای شوهرم انجام میدم."

    # say L1454 joh
    old "Now that we are ready, I have a special task for you Angelina."
    new "الان که آماده‌ایم، برایت یک وظیفه خاص دارم Angelina."

    # say L1455 ang
    old "Ok, I'm ready for whatever you want."
    new "خوب، برای هر چی که می‌خوای آماده‌ام."

    # say L1456 joh
    old "I love that enthusiasm! I want you to take the lead and fuck him wild, I want you to be the one to say what to do."
    new "من هم عاشق این انگیزه‌اتم! می‌خوام تو رهبر باشی و با او جنسی خیلی شگفت‌زایی داشته باشی، می‌خوام تو باشی که بگی چه کاری باید انجام بدی."

    # say L1457 joh
    old "So, I want you to get on him and take the rhythm and intensity, I want you to take an active role in sex..."
    new "پس من می‌خوام تو رویش بنشینی و ریتم و شدت رو هدایت کنی، می‌خوام تو نقش فعالی در سکس بازی کنی..."

    # say L1459 ang
    old "Hmm... I- I will try, get ready [pla]."
    new "Hmm... من- من سعی می‌کنم، آماده شو [pla]."

    # say L1476 ang
    old "You are the most amazing therapist I've ever had."
    new "شما بهترین معالج روانی هستید که تا حالا داشتم."

    # say L1477 joh
    old "I appreciate all the effort you did, I know it was not easy but now you can see the results."
    new "من از تمام تلاش‌هایت قدردانی می‌کنم، می‌دونم آسون نبود ولی حالا می‌تونی نتایجش رو ببینی."

    # say L1478 ang
    old "Doctor, I have, no words to say how much I thank you for all the knowledge and patience you invested..."
    new "دکتر، من کلماتی ندارم برای اینکه شما را برای تمام دانش و صبری که سرمایه‌گذاری کردید، تشکر کنم..."

    # say L1480 ang
    old "And I thank you too [pla], you really help me with your... Abilities."
    new "و من هم سپاسگزارم [pla]، شما واقعاً با توانایی‌هایت به من کمک کردی."

    # say L1481 pla
    old "It's a pleasure, I'm glad to have helped you."
    new "لذت‌بخش بود، خوشحالم که تونستم به تو کمک کنم."

    # say L1483 joh
    old "Ok, it's time guys, get dressed and let's go to the therapy bedroom..."
    new "خب، وقت شده دوستان، لباس‌تون رو بپوشید و بیایید به اتاق خواب درمانی برویم..."

    # say L1494 joh
    old "Ok, today we finished our team practice sessions. Angelina, you and I will continue the process together with therapy."
    new "خب، امروز جلسات تمرینی ما تمام شد. آنجلینا، شما و من با درمان ادامه خواهیم داد."

    # say L1495 ang
    old "Oh... So, there are no more sessions with [pla]?"
    new "اوه... پس هیچ جلسه‌ای با [pla] دیگه نیست؟"

    # say L1497 joh
    old "No, he did his job and now we can continue with therapy. Now is the moment to put all of this in practice with your husband."
    new "نه، او کارش رو انجام داد و حالا می‌تونیم با تراپی ادامه بدیم. الان وقت برای اینه که همه اینا رو با شوهرت به کار ببری."

    # say L1498 ang
    old "Oh, alright..."
    new "اوه، خوب است..."

    # say L1499 joh
    old "Remember we have other things to work on together. If we see we would need [pla]'s help again, I would bring him to therapy."
    new "به خاطر داشته باش همچنان چیزهای دیگری هست که باید باهم رویش کار کنیم. اگر فکر کنم دوباره به کمک [pla] نیاز داریم، او را دوباره به درمان می‌آورم."

    # say L1501 ang
    old "Oh, great, I'm glad to hear that. Anyway, I can't describe how happy I am and how happy I will make my husband..."
    new "البته، خوشحالم که اینجوری شنیدم. هر جا، نمی‌تونم بگم چقدر خوشحالم و چقدر خوشحال خودم رو به شوهرم می‌کنم..."

    # say L1502 ang
    old "I will practice a lot with him! Thank you doctor Johnson, I will call you to make a new appointment."
    new "من خواهم تمرین زد! ممنونم دکتر جانسون، برای وقت بعدی تماس خواهم گرفت."

    # say L1503 joh
    old "Ok, please have fun, it was nice to walk you through this process."
    new "خوب، لطفاً لذت ببرید، خوشحالم که این فرآیند را برای شما هدایت کردم."

    # say L1506 pla
    old "Uhh... Goodbye Angelina."
    new "اوه... خداحافظ آنجلینا."

    # say L1514 joh
    old "Well, [pla], I really appreciate your job, you did amazing, every single session, I'm very proud of you."
    new "خب، [pla]، واقعاً از کارت ممنونم، تو در هر جلسه‌ای عالی بودی، خیلی ازت خرسندم."

    # say L1515 pla
    old "Oh, t- thank you, I just followed all your instructions."
    new "اوه، ممنونم، من فقط همه دستورات شما رو دنبال کردم."

    # say L1516 joh
    old "I know. By the way,  I want to have another session, just for you and me..."
    new "میدونم. بین هم، من می‌خوام جلسه‌ای دیگه داشته باشیم، فقط تو و من..."

    # say L1517 joh
    old "But I have another patient coming, it's too late to cancel it..."
    new "اما دارم بیمار دیگری می‌آید، الان لغو کردنش خیلی دیر شده..."

    # say L1518 pla
    old "Another session, what do you mean?"
    new "دستور جلسه دیگری، چه می‌خوای بگی؟"

    # say L1520 joh
    old "Hmm, I mean I need to check something, so let's call it another lesson..."
    new "هم، منظورم اینه که باید چیزی رو بررسی کنم، پس بیایید این رو یه جلسه دیگه بگذاریم..."

    # say L1521 pla
    old "... Hmm ok, sure."
    new "خوب، مطمئن هستم."

    # say L1522 joh
    old "I know next session is going to be pretty fun, so please sleep well."
    new "میدونم جلسه بعد خیلی لذت بخش خواهد بود، پس لطفاً خوب بخواب."

    # say L1524 joh
    old "I am considering giving you a prize before we start another treatment, just because you were amazing with Angelina..."
    new "من در نظر دار قبل از شروع درمان بعدی بهت جایزه‌ای بدم، فقط برای اینکه با آنجلینا عالی عمل کردی..."

    # say L1526 joh
    old "Just come see me tomorrow and don't be late."
    new "فقط فردا بیا و دیر نشو."

    # say L1527 pla
    old "Alright, I will be here."
    new "البته، من اینجا خواهم بود."

    # say L1528 joh
    old "Great, see you!"
    new "عالی، تا دیدن."

    # say L1543 joh
    old "Hi, I was waiting for you desperately."
    new "سلام، منتظرت بسیار بودم."

    # say L1544 pla
    old "Good morning, thank you I tried to be on time-"
    new "صبح بخیر، ممنون. سعی کردم به موقع باشم-"

    # say L1545 joh
    old "You are, don't worry! It's just that I don't want to talk."
    new "شما هستید، نگران نباشید! فقط اینه که من نمی‌خوام صحبت کنم."

    # say L1546 pla
    old "Uhh, w- wha-?"
    new "اوه، و- وای؟"

    # say L1548 joh
    old "Let's go to the room, there is no time to lose."
    new "بیایید به اتاق برویم، وقت زیادی نداریم."

    # say L1555 joh
    old "Well, I want to fuck you right now, no lessons, no patients just hard sex."
    new "خب، من می‌خوام حالا با تو بزنم، بدون درس، بدون بیمار، فقط جنس سخت."

    # say L1557 joh
    old "Why don't you make yourself comfortable and let me suck your dick?"
    new "چرا نخود راحت شوی و بگذار من نوزه‌ت رو بکشونم؟"

    # say L1580 joh
    old "Yummy!"
    new "می‌تونم بگم خوشمزه!"

    # say L1587 joh
    old "It's delicious, do you like the way I suck it?"
    new "لذت‌بخش است، آیا روش من در کشیدنش به تو می‌پسندی؟"

    # say L1598 joh
    old "Wow, I needed that session. You can't imagine how hot it was, you did amazing."
    new "واو، این جلسه رو نیاز داشتم. نمی‌تونی تصور کنی چقدر گرم بود، شما عالی کار کردی."

    # say L1599 pla
    old "I did my best."
    new "من بهترین تلاشم رو کردم."

    # say L1600 joh
    old "Absolutely, you fucked me as I needed to.  I think I need a little more, though..."
    new "حتماً، تو همینطوری با من سکس کردی که لازم داشتم. ولی فکر کنم کمی بیشتر نیاز دارم..."

    # say L1601 joh
    old "Just keeps coming over sometimes just to... You know, have some fun lessons."
    new "مگه گاهی اوقات فقط برای... معلم بازی خوشحالم، بیای زودتر."

    # say L1603 joh
    old "Perfect, and when I need your help again with another patient, I'll let you know."
    new "البته، و وقتی به کمکت با بیمار دیگری نیاز داشتم، ازت خبر می‌دهم."

    # say L1605 joh
    old "Ok, now I have to get ready for the session with my next patient, see you soon [pla]."
    new "باشه، حالا باید برای جلسه با بیمار بعدی آماده شوم، زودی می‌بینیم [pla]."

    # say L1606 pla
    old "Got it. See you, doctor Johnson."
    new "باشه. ببینم، دکتر جانسون."

    # say L1629 pla
    old "Oh, wow."
    new "اوه، وای."

    # say L1630 roo
    old "Hey buddy! What's up?"
    new "سلام دوست من! چه خبر؟"

    # say L1632 pla
    old "H- Hi."
    new "ه- هی، رابین."

    # say L1633 ang
    old "Hey [pla], how are you doing?"
    new "هی [pla]، چطوری؟"

    # say L1634 roo
    old "Oh, so you guys know each other?"
    new "اوه، پس شما دو تا هم می‌شناسید؟"

    # say L1636 pla
    old "Uhh... W- well- "
    new "اوه... خب- خب-"

    # say L1638 ang
    old "Yes! He is the assistant of doctor Johnson... He helped us with... With the treatment..."
    new "بله! او دکتر جانسون هست... او به ما در... در درمان کمک کرد..."

    # say L1639 roo
    old "Wow, you are quite young, I didn't know you had such wonderful therapy abilities. You must know buddy, you saved my marriage!"
    new "واو، تو خیلی جوانی، نمی‌دونستم این قدر توانایی درمانی داری. باید بدونی دوست من، تو ازدواج من رو نجات دادی!"

    # say L1641 roo
    old "You don't know how important was this, I feel so thankful that I hope you go to the store so I can give an enormous discount."
    new "تو نمی‌دونی اینقدر مهم بود، خیلی ممنونم و امیدوارم بروی به دوکان تا بتونم تخفیف بزرگی بهت بدم."

    # say L1642 pla
    old "Oh, thanks."
    new "اوه، ممنون."

    # say L1643 roo
    old "I have no words to tell how I appreciate what you did for me, look Angelina is pregnant and we are very happy about it."
    new "من هیچ کلمه‌ای ندارم تا بگویم چقدر از آنچه برای من انجام دادی ممنونم، ببین آنجلینا حامله شده و ما خیلی خوشحال هستیم."

    # say L1646 roo
    old "I know the universe will reward you for this magnificent help and-"
    new "می‌دونم جهان به خاطر این کمک عظیم به تو پاداش خواهد داد و-"

    # say L1647 ang
    old "We really appreciate your help. Darling we need to go, I want to get some fresh air."
    new "ما واقعاً از کمکت ممنونیم. عزیزم باید بریم، می‌خوام هوا خورم."

    # say L1648 pla
    old "Oh sure, it was nice to see that you guys are happy."
    new "البته، خوشحالم که ببینم شما دو تا خوشحال هستید."

    # say L1649 roo
    old "We are very happy to see you too, now excuse us, we have to go."
    new "ما هم خوشحالم که تو رو دیدیم، حالا ببخشید، باید بریم."

    # say L1650 pla
    old "... Sure."
    new "... البته."

    # say L1651 ang
    old "Have a nice day [pla]!"
    new "روز خوبی داشته باش [pla]!"

    # say L1652 roo
    old "Yes buddy! Have a great day."
    new "بله دوست من! روز عالی داشته باش."

    # say L1653 pla
    old "See you!"
    new "ببینم!"

    # say L1658 pla
    old "Wow... So, she is pregnant..."
    new "واو... پس، او بارداره..."

    # say L1674 pla
    old "Hi Dr. Johnson, how are you?"
    new "سلام دکتر جانسون، حالت چطوره؟"

    # say L1675 joh
    old "Hi [pla], I'm excellent, thanks for asking. What about yourself, young man?"
    new "سلام [pla]، من عالی هستم، ممنون از سؤالت. خودت چطوری، جوان؟"

    # say L1676 pla
    old "I'm good, thanks! And hmm, I would like to talk about s- something with you, it would take just a couple of minutes."
    new "من خوبم، ممنون! و اوه، می‌خواستم در مورد چیزی با شما صحبت کنم، فقط چند دقیقه طول می‌کشه."

    # say L1677 joh
    old "Sure, what is it about?"
    new "البته، درباره چه موضوعی می‌خواهی صحبت کنیم؟"

    # say L1678 pla
    old "I wouldn't like to bother you but I'm f- facing a tough situation now and I'm l- looking for a job."
    new "من نمی‌خوام به شما آزار بدم ولی حالا مشکلی سخت دارم و در حال جستجوی کار هستم."

    # say L1679 pla
    old "You know I'm a hard worker and I would do whatever you assign to me."
    new "می‌دونی من کارگر سختی هستم و هر کاری که بهم بدهی انجام می‌دم."

    # say L1681 joh
    old "I see, but... I can't offer you anything right now."
    new "من می‌بینم، اما... همین حالا هیچ چیزی برای شما ندارم."

    # say L1682 joh
    old "I don't have any patients for you at the moment..."
    new "من در حال حاضر هیچ بیماری برای شما ندارم..."

    # say L1684 pla
    old "R- really? I had some hopes on you."
    new "وای، واقعاً؟ من برایت امیدوار بودم."

    # say L1685 pla
    old "Maybe if you think of somethin-"
    new "شاید اگر فکر کنی..."

    # say L1686 joh
    old "[pla], I really don't have anything since I don't have many patients now, however, if I get to need you, I'll reach you out."
    new "[pla]، واقعاً هیچ چیزی ندارم زیرا امروز بیمار زیادی ندارم، اما اگر به شما نیاز داشتم، از شما خبر خواهم داد."

    # say L1688 joh
    old "You have been very well trained and you were exceptional at your duties with the last patient."
    new "شما آموزش خوبی داده شدید و در وظایف خود با بیمار قبلی فوق‌العاده بودید."

    # say L1689 joh
    old "I'll call you when I need you..."
    new "وقتی نیاز داشتم ازت تماس می‌گیرم..."

    # say L1691 pla
    old "I see... Hmm, alright... I'll keep looking for it. Thanks Dr. Johnson, I appreciate your time."
    new "ببینم... هم، خوب... من همچنان به دنبالش می‌گردم. ممنون دکتر جانسون، وقت شما رو قدرت می‌کنم."

    # say L1692 pla
    old "Goodbye and keep me posted in case you have jobs for me, I would appreciate it."
    new "خداحافظ و اگر کاری برای من داشتید، لطفاً مرا مطلع کنید، ممنون می‌شوم."

    # say L1693 joh
    old "Sure I will, have a nice day."
    new "البته، روز خوبی داشته باشید."


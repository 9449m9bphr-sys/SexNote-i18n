# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/angAnimations.rpy
translate persian strings:

    # say L51 joh
    old "Are you enjoying it, honey?"
    new "آیا لذت می‌بری، عزیزم؟"

    # say L52 ang
    old "Mmm, yes, this one is giving me a pretty warm and wet sensation."
    new "آره، این یک احساس گرم و مرطوب خوبی به من میده."

    # say L53 joh
    old "Okay, you're doing a great job, now try to do it a little faster."
    new "خب، خوب کار می‌کنی، حالا سعی کن یه کم سریع‌تر انجام بدی."

    # say L59 joh
    old "Oh yeah, just like that honey, don't stop, you are gonna make him cum soon..."
    new "اوه بله، همینطور عزیزم، نتوق نکن، قراره زودی بریزه..."

    # say L61 ang
    old "Slurp, slurp."
    new "سلرب، سلرب."

    # say L84 joh
    old "Ok, you've had enough, you can cum now [pla]."
    new "خوب، حالا کافیه، می‌تونی الان بیایی [pla]."

    # say L85 ang
    old "W- what?"
    new "و- وای، این چیه؟"

    # say L86 pla
    old "Ughhh..."
    new "اوه..."

    # say L90 ang
    old "Huh, what is this?"
    new "اوه، این چیه؟"

    # say L95 ang
    old "WHAT THE FUCK!"
    new "چه خبره!"

    # say L96 ang
    old "WHO THE HELL ARE YOU?!!"
    new "تو کی هستی؟!!"

    # say L110 joh
    old "Ok [pla], I need you to show her your tricky fingers..."
    new "خب ز[pla]، باید دست خوبت رو به کار ببری..."

    # say L111 joh
    old "More speed and a bit of more pressure, she needs to enjoy more, to get hornier."
    new "بیشتر سرعت و فشار کمی بیشتر، او باید بیشتر لذت ببرد، بیشتر خیال‌پردازی کند."

    # say L113 ang
    old "Uhh... It f- feels nice..."
    new "اوه... احساس خوبی داره..."

    # say L114 joh
    old "Yes, just like that, [pla]."
    new "بله، همینطور، [pla]."

    # say L118 joh
    old "[pla], I want you to be tough now, press them hardly, feel them, touch them all."
    new "[pla]، من می‌خوام الان سخت باشی، فشارشون بده، حسشون کن، همه جا رو لمس کن."

    # say L119 pla
    old "Ok."
    new "باشه."

    # say L120 joh
    old "Do you like it Angelina?"
    new "دکتر جانسون: آنجلینا، اینو دوست داری؟"

    # say L121 ang
    old "... Y- yes."
    new "بله."

    # say L145 joh
    old "Perfect, now that we feel a bit more confident with each other let's move to the other exercise, in this case in the practice bedroom."
    new "عالی، حالا که با هم مطمئن‌تر شده‌ایم، بیایید به تمرین بعدی برویم، این بار در اتاق خواب تمرین کنیم."

    # say L158 joh
    old "Do you like it?"
    new "می‌پسندی؟"

    # say L159 ang
    old "Yes, it feels a bit... Nice."
    new "بله، احساس می‌کنم یه کم... خوب است."

    # say L160 joh
    old "You needed a better trained person to start enjoying it, let's make it more interesting, [pla], I want you to do it faster."
    new "نیاز داشتی به کسی با تربیت بهتر برای شروع لذت بردن، بیایید جالب‌ترش کنیم، [pla]، می‌خوام سریع‌تر انجام بدی."

    # say L162 joh
    old "How do you feel now?"
    new "اوه، حالا چطور احساس می‌کنی؟"

    # say L163 ang
    old "Ahh! I- I am... Starting to feel... n- nice."
    new "اوه! من- من... شروع کردم... خوب احساس می‌کنم."

    # say L167 joh
    old "Ok, [pla], I want you to make her cum, do your thing!"
    new "باشه، [pla]، من می‌خوام تو اونجا رو به خوشی برسونی، کارتو بکن!"

    # say L168 ang
    old "Ohhh...  Don't stop, ahh! Nngh!"
    new "اوه... متوقف نشو، اه! ننه!"

    # say L191 ang
    old "Oh God! OH GOD! I feel like I'm going to... EXPLODE!"
    new "اوه خدا! اوه خدا! حس می‌کنم من منفجر می‌شوم!"

    # say L196 joh
    old "Wonderful!"
    new "عالی!"

    # say L197 ang
    old "Oh God... I had never felt this before..."
    new "اوه خداوند... هیچ وقت این حس را تجربه نکرده بودم."

    # say L209 joh
    old "So, what do you feel Angelina?"
    new "پس، چه احساسی داری، Angelina؟"

    # say L210 ang
    old "Hmm, It's really hard and tasteful."
    new "Hmm، خیلی سخت و لذت‌بخش است."

    # say L211 joh
    old "That's perfect, how are you feeling, [pla]?"
    new "این عالیه، حس خودت چطوره، [pla]؟"

    # say L213 ang
    old "Hmm... Slurp, slurp."
    new "Hmm... لیل، لیل."

    # say L214 joh
    old "Right, that's the best answer. Just enjoy it guys."
    new "درسته، این بهترین جوابه. فقط لذت ببرید، بچه‌ها."

    # say L218 joh
    old "You think you can hold on a bit more [pla]?"
    new "فکر می‌کنی می‌تونی یه کمی بیشتر صبر کنی [pla]؟"

    # say L220 joh
    old "Perfect, now Angelina, I want you to give him all you have, I want you to make him cum."
    new "پرفکت، الان آنجلینا، من می‌خوام تو همه‌ت رو بهش بدی، می‌خوام توش رو برسونی."

    # say L221 ang
    old "Mmm, ok."
    new "ممنون، خوب."

    # say L245 joh
    old "Don't stop now, he is almost done, he will cum any time, so, keep moving your head."
    new "اکنون متوقف نشو، او تقریباً تمام شده، هر لحظه می‌آید، پس سرتو حرکت ده."

    # say L246 ang
    old "Slurp, slurp...!"
    new "سلورپ، سلورپ...!"

    # say L247 pla
    old "Ahh!"
    new "اوه!"

    # say L253 ang
    old "Wow, that's a lot of cum, I think I did it."
    new "واو، این همه مایع، فکر کنم انجامش دادم."

    # say L254 joh
    old "You did amazing!"
    new "عالی کردی!"

    # say L265 joh
    old "[pla], since Angelina is not so experienced I need you to be as gentle as you can be, she can't do it like me, so pease start softly."
    new "دکتر جانسون: [pla]، چون آنجلینا خیلی تجربه نداره، لطفاً همینجور نرم و آرام باشی، او مثل من نمی‌تونه، پس لطفاً از اول نرم شروع کن."

    # say L266 pla
    old "Sure, I'll try my best."
    new "بله، تلاش خواهم کرد."

    # say L270 ang
    old "Mmm it hurts a bit... But it also feels good..."
    new "ممنون... یه کم درد می‌کنه... ولی همینطور خوشحالم..."

    # say L271 joh
    old "Told you. [pla] please, speed it up a bit, I want you to make her scream a bit, you already know how to do it."
    new "بگذارم بگویم. [pla] لطفاً یک کم سرعتش رو افزایش بده، می‌خواهم صدای او رو بشنوم، تو قبلاً می‌دونی چطور باید انجام بدی."

    # say L276 joh
    old "Are you satisfied Angelina?"
    new "آیا راضی هستی، آنجلینا؟"

    # say L277 ang
    old "Ohhh... Yess..."
    new "اوه... بله..."

    # say L278 joh
    old "And we've got even more to go, so [pla], give her more!"
    new "و هنوز بیشتری برای انجام داریم، پس [pla]، بیشتر به او بده!"

    # say L279 pla
    old "Got it."
    new "فهمیدم."

    # say L281 ang
    old "HOLLY SHIT! AHHH!"
    new "هالی شیت! اوه!"

    # say L304 joh
    old "Don't stop, she's about to cum!"
    new "توقف نکن، او در حال علیه آمدن است!"

    # say L305 ang
    old "NNGH!"
    new "ننه!"

    # say L306 joh
    old "[pla], finish with her!"
    new "[pla]، با او تمام شو!"

    # say L307 ang
    old "I feel like an explosion inside just like the other day, I- I... AHH!"
    new "احساسی مثل انفجار درون من هست، مثل روزی که بود، من- من... آااه!"

    # say L321 joh
    old "That's impressive, you are doing it really really good, do you like it [pla]?"
    new "این عالی است، واقعاً واقعاً خوب انجام می‌دهی، آیا دوست داری [pla]؟"

    # say L322 pla
    old "Absolutely!"
    new "حتماً!"

    # say L323 pla
    old "(She's getting really good at it.)"
    new "او واقعاً خوب شده است."

    # say L325 joh
    old "I'm glad to see you feel more confident with your partner."
    new "خوشحالم که می‌بینم با همسرت اعتمادت بیشتر شده."

    # say L328 joh
    old "That's great, don't stop, remember is your husband pleasure what we are talking about."
    new "عالی است، ادامه بده، به خاطر داشته باش که لذت شوهرت هدفمون است."

    # say L331 joh
    old "Now suck it faster, show me those blowjob skills."
    new "الان سریع‌تر خوردن، به من نشون بده این مهارت‌هایت."

    # say L333 pla
    old "Woow!"
    new "ووو!"

    # say L337 joh
    old "Wow, I can see it's getting closer, do it faster, you want him to cum, don't you?"
    new "واو، می‌تونم ببینم که نزدیک‌تر شده، سریع‌تر انجام بده، می‌خوای اونو برسونی، هست؟"

    # say L338 ang
    old "Yes!"
    new "بله!"

    # say L339 joh
    old "So, do it as fast as you can... make him cum in your throat!"
    new "پس، سریع‌تر انجام بده... بیا در خورت به او برسون."

    # say L363 pla
    old "Ahh yes! Take it."
    new "آه ها، بله! بگیر."

    # say L370 joh
    old "Wonderful, did you like it Angelina?"
    new "عالی، آنجلینا، لذت برده بودی؟"

    # say L372 joh
    old "That's my girl."
    new "این دختر من است."

    # say L383 joh
    old "Oh yeah, ride him Angelina, jump on him and fuck him."
    new "بله، همینجوری انجام بده Angelina، رویش بنشین و باشون جنس کن."

    # say L384 ang
    old "I didn't know riding was so intense, this is definitely the position I like the most."
    new "نمی‌دونستم سوار شدن اینقدر تاثیرگذاره، این حتماً وضعیت مورد علاقه‌امه."

    # say L385 pla
    old "(Oh wow, she moves really good, I like it.)"
    new "اوه وای، حرکت‌هایش واقعاً خوبه، خوشم می‌آید."

    # say L388 ang
    old "Oh God! I don't want to stop, we should do this for a week..."
    new "اوه خداوند! من نمی‌خوام توقف بدم، باید این کار رو یک هفته انجام بدیم..."

    # say L389 pla
    old "I like it too."
    new "من هم دوست دارم."

    # say L390 joh
    old "Fuck him Angelina, fuck [pla] hard!"
    new "دکتر جانسون: فکر کن Angelina، بزن [pla] رو سخت!"

    # say L392 ang
    old "Ahhh..."
    new "اوه..."

    # say L396 ang
    old "Ahhh... Your dick is so hard that I want to hit it faster."
    new "اوه... نهاد تو خیلی سخته که می‌خوام بهش بزنم تندتر."

    # say L397 joh
    old "Fuck him harder, just as you want!"
    new "اشتیاقت رو به او نشون بده، همونطور که می‌خوای!"

    # say L422 ang
    old "Ahh! This is really delicious, I don't want to stop."
    new "اوه! این واقعاً لذت‌بخش است، نمی‌خوام متوقف بشه."

    # say L423 ang
    old "I really love this, I want to feel you cuming."
    new "من واقعاً اینو دوست دارم، می‌خوام حس کنم تو خروجی دیی."

    # say L424 pla
    old "I- I can't hold it anymore."
    new "من- من دیگه نمی‌تونم تحمل کنم."

    # say L430 ang
    old "Mmm, I- I want more... May I have another round?"
    new "ممنون، من- من می‌خوام بیشتر... می‌تونم دفعه دیگه‌ای بگیرم؟"

    # say L431 joh
    old "Wow girl, you're insatiable... Well, if [pla] says she can go on, that's fine with me, we still have time."
    new "واو دختر، تو غیرقابل اشباعی هستی... خب، اگر [pla] بگه که می‌تونه ادامه بده، با من هم مشکلی نداره، هنوز وقت داریم."

    # say L432 pla
    old "Uhh... Yes, I guess..."
    new "اوه... بله، حدس می‌زنم..."

    # say L433 ang
    old "Ok, now you fuck me, I want you to make me cum again."
    new "خب، حالا تو باید منو بزنه، می‌خوام دوباره برسم."

    # say L434 pla
    old "A- Alright..."
    new "ا- خوب..."

    # say L452 ang
    old "Oh yes, just like that. I have to say my husband is not as big as you."
    new "اوه بله، همینطور. باید بگم شوهرم مثل تو بزرگ نیست."

    # say L453 ang
    old "Your huge cock makes me feel so much more!"
    new "پوسی تو خیلی بزرگه و این حس رو به من میده!"

    # say L457 ang
    old "Mmmm, it feels really nice, but I want more!"
    new "ممنون، اما من می‌خوام بیشتر!"

    # say L458 ang
    old "Give me more of your cock. I want you to fuck me harder!"
    new "بیشتر از خودت به من بده. می‌خوام سخت‌تر باهام بکنی!"

    # say L461 ang
    old "Uhhhh... Holly Shit! This is soo good."
    new "اوه هولی شیت! این خیلی خوبه."

    # say L464 ang
    old "Don't stop baby, keep fucking me hard!"
    new "بچه، ادامه بده! من می‌خوام سخت‌تر باهام بکنی!"

    # say L465 ang
    old "I want you to make me cum! Please [pla], make cum!"
    new "من می‌خوام تو مرا به عجولان برسونی! لطفاً [pla]، من رو به عجولان برسون!"

    # say L467 ang
    old "Ahhh! Ahhh! Oh my God!"
    new "اوه! اوه! خداوند!"

    # say L490 pla
    old "(Uhh... Doctor Johnson has been a bit quiet, that's weird)"
    new "اوه... دکتر جانسون یه کم خیلی ساکته، این عجیبه."

    # say L497 ang
    old "Yes! Yes! I- I cumming again! Ahhh!"
    new "بله! بله! من- من دوباره می‌آیم! آه!"

    # say L501 ang
    old "Mmmm, it was so good."
    new "ممنون، خیلی خوب بود."

    # say L502 joh
    old "Great job guys, I can tell you that the sessions have been very efficient..."
    new "بازی خوبی بود، می‌توانم بگم که جلسات بسیار موثر بودند..."

    # say L503 joh
    old "Angelina as you can see you will be very happy with your husband!"
    new "آنجلینا، همانطور که می‌بینی، از شوهرت خوشحال خواهی شد!"

    # say L515 ang
    old "Mmm... Oh God, this feeling..."
    new "ممنون... اوه خدا، این احساس..."

    # say L516 ang
    old "And the size of your cock!"
    new "و اندازه ناخودت!"

    # say L517 ang
    old "It brings so much back!"
    new "این همه چیز رو بر می‌گردونه!"

    # say L521 ang
    old "I haven't felt this way in forever!"
    new "من این حس رو از خیلی وقت نداشتم!"

    # say L522 ang
    old "I've missed feeling this way!"
    new "من این حس رو خیلی دوست داشتم!"

    # say L523 ang
    old "Slrrp! It's been so long!"
    new "Slrrp! طولانی بود!"

    # say L527 ang
    old "This is nothing like my husband!"
    new "این هیچ شباهتی به شوهرم نداره!"

    # say L528 ang
    old "I love how good it tastes!"
    new "عشقم که چقدر خوب می‌چرخه!"

    # say L529 ang
    old "Oh it makes me feel so good!"
    new "اوه این مرا خیلی خوب می‌کنه!"

    # say L552 pla
    old "Angelina! I-I can't hold it in anymore!"
    new "آنجلینا! من-من دیگه نمی‌تونم تحمل کنم!"

    # say L553 ang
    old "Oh yes! I want you to let it out!"
    new "اوه بله! می‌خوام تو اینو بیرون بیاری!"

    # say L554 ang
    old "Let me taste it!"
    new "بگذار بیایم از اون طعم ببرم!"

    # say L562 ang
    old "Mmm that felt so good."
    new "ممنون، همینطور خوب بود."

    # say L563 ang
    old "It was amazing."
    new "البته، عالی بود."

    # say L564 pla
    old "Uh, yeah, I guess so."
    new "آره، حدس زدم."

    # say L565 pla
    old "But hey, let’s get up and clean this up before Lisa walks in and sees us."
    new "اما بیا، باید بلند شیم و اینجا رو تمیز کنیم قبل از اینکه لیزا بیاد و ما رو ببینه."

    # say L566 ang
    old "Sure, sure."
    new "بله، البته."

    # say L574 pla
    old "How are you feeling Angelina?"
    new "حالت چطوره آنجلینا؟"

    # say L575 ang
    old "Great! That was fantastic! I want more!"
    new "عالی! اونقدر خوب بود! می‌خوام بیشتر!"

    # say L576 pla
    old "Hmm, yeah sure."
    new "Hmm، بله مطمئنا."

    # say L582 ang
    old "Mmm! Oh yes!"
    new "ممنون! آه بله!"

    # say L583 ang
    old "Oh God! this feels amazing!"
    new "اوه خداوند! این حس عالی است!"

    # say L584 ang
    old "Oh [pla], this is just what I wanted!"
    new "اوه ز[pla]، این دقیقاً همینه که می‌خواستم!"

    # say L596 ang
    old "Oh God [pla] I love it!"
    new "اوه خدا ز[pla]، من عاشق اینم!"

    # say L597 ang
    old "This is so good!"
    new "این خیلی خوبه!"

    # say L601 ang
    old "My God [pla], I love the way you're doing it!"
    new "ای زنگی [pla]، من عاشق طرزی هستم که اینو انجام میدی!"

    # say L602 ang
    old "This is amazing [pla]!"
    new "این خیلی عالیه [pla]!"

    # say L606 ang
    old "Oh yes! Ah! AH!"
    new "اوه بله! آه! آه!"

    # say L630 ang
    old "Oh [pla]!"
    new "اوه [pla]!"

    # say L638 pla
    old "How do you feel?"
    new "حالت چطوره؟"

    # say L639 ang
    old "I feel amazing [pla]!"
    new "احساسی عالی هستم [pla]!"

    # say L640 ang
    old "That's the best sex I've ever had!"
    new "این بهترین جنسیتی بود که تا حالا تجربه کردم!"

    # say L641 pla
    old "Heh, that's good to hear."
    new "هه، خوشحالم که همینطور فکر می‌کنی."

    # say L651 ang
    old "Great! That was fantastic! I want more, please!"
    new "عالی! این خیلی خوب بود! لطفاً بیشتر بده!"

    # say L652 pla
    old "Yeah, that’s what I thought..."
    new "بله، همین طور فکر می‌کردم..."

    # say L671 ang
    old "Ohhh, yeah... it feels so deep..."
    new "اوه، بله... احساسش خیلی عمیقه..."

    # say L672 ang
    old "Mmm, this is the best!"
    new "ممن، این بهترین هست!"

    # say L676 ang
    old "Oh God, oh God! It's amazing."
    new "اوه خدا، اوه خدا! واقعاً عالیه."

    # say L677 ang
    old "It feels so good..."
    new "این خیلی خوب است..."

    # say L680 ang
    old "Ohh fuck, yes, yes, faster, faster [pla]..."
    new "اوه خدای من، بله، بله، سریع‌تر، سریع‌تر [pla]..."

    # say L682 ang
    old "Mmm, that's right, don't stop [pla], don't stop!"
    new "ممنون، اینجوری، نتوقف [pla]، نتوقف!"

    # say L706 ang
    old "Oh my God! Yes, yes!"
    new "اوه خدا! بله، بله!"

    # say L707 ang
    old "[pla], I'm about to cum, don't stop, give me more, give me more!"
    new "[pla]، من همین جا می‌آیم، نتوقف، بیشتر بد به من، بیشتر!"

    # say L711 ang
    old "Ohhh that was amazing... Oh my God."
    new "اوه آنقدر عالی بود... اوه خدا."

    # say L712 ang
    old "[pla], you really have no idea how wonderful that was."
    new "[pla]، تو واقعاً نمی‌دونی چقدر این خوب بود."

    # say L713 pla
    old "You're feeling better now, right?"
    new "حالت بهتر شد، درسته؟"

    # say L714 ang
    old "Ohh, you have no idea."
    new "اوه، تو هیچ ایده‌ای نداری."

    # say L715 pla
    old "I'm glad, but, let’s get up and clean this up before Lisa walks in and sees us."
    new "خوشحالم، ولی باید بلند شویم و این رو تمیز کنیم قبل از اینکه لیزا وارد شده و ما رو ببینه."


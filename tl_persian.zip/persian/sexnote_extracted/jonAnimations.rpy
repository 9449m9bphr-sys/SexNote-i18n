# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/jonAnimations.rpy
translate persian strings:

    # say L6 jon
    old "It barely fits in my mouth... My god! You really have something big here."
    new "به سختی توی دهانم می‌ره... خداوند! واقعاً چیز بزرگی داری اینجا."

    # say L10 jon
    old "It's a massive cock, just like my husband's dick."
    new "این یک خروک بزرگ است، مثل خروک شوهرم."

    # say L11 pla
    old "(Wow! I can see she has some good experience at this...)"
    new "واو! می‌تونم ببینم تو تجربه خوبی تو این کار داری..."

    # say L15 jon
    old "It's so big and Mmmm... So good..."
    new "اینقدر بزرگ است و ممم... خیلی خوب است..."

    # say L39 pla
    old "Mrs. Jones I'm cum-"
    new "خانم جونز، من در حال خروج هستم..."

    # say L40 jon
    old "Oh Yes! Give me your sacred cum..."
    new "اوه بله! منو با این مبارکه‌ات پر کن..."

    # say L42 jon
    old "Ahhhhhhhhh!"
    new "اااااااااا!"

    # say L48 jon
    old "Oh my God, I really need to feel your divine presense inside me..."
    new "اوه خدا، واقعاً نیاز دارم احساس حضور الهی تو درون من باشم..."

    # say L50 jon
    old "Come to my bedroom..."
    new "به اتاق خوابم بیا..."

    # say L64 pla
    old "I- I'm doing it right?"
    new "من- من درست انجام می‌دم؟"

    # say L65 jon
    old "My pussy is speaking for me... Just feel how wet it's for you."
    new "پوسی من برایت صحبت می‌کنه... فقط حس کن چقدر برایت مرطوب شده."

    # say L69 jon
    old "I haven't felt like this in years !!"
    new "سال‌ها این حس رو نداشتم!!"

    # say L70 jon
    old "Being with a young and vigorous man like you, has no comparison."
    new "با یک مرد جوان و سرشار از انرژی مثل شما، هیچ مقایسه‌ای نداره."

    # say L74 pla
    old "Oh god! Oh God!"
    new "اوه خداوند! اوه خداوند!"

    # say L75 jon
    old "You'll make me come so badly!"
    new "تو می‌تونی من رو خیلی بد بیاوردی!"

    # say L98 pla
    old "I- I'm cumming-"
    new "من- من هم می‌آیم-"

    # say L99 jon
    old "Ohhh mee too!!!"
    new "اوه من هم!!!"

    # say L103 jon
    old "Wow, that was great... We should, get dressed before Billie arrives."
    new "واو، این خیلی عالی بود... باید پیش از آمدن بیلی لباس‌مون رو بذاریم."

    # say L116 jon
    old "Oh yeah! Fuck my mouth you little boy!"
    new "اوه بله! لب خری تو رو بزنم، پسر کوچیک!"

    # say L117 pla
    old "Oh God!"
    new "اوه خداوند!"

    # say L121 jon
    old "It's so good to have it inside my mouth... I can feel your veins pumping..."
    new "اینقدر خوبه که تو دهانم هست... می‌تونم شریان‌هایت رو تپش می‌دن..."

    # say L122 pla
    old "Ahhhhhhh! You're so good..."
    new "ااااااا! تو خیلی خوبی..."

    # say L126 jon
    old "Yes! Faster! Faster I want you to cum on my mouth!"
    new "بله! سریع‌تر! سریع‌تر می‌خوام تو رو توی دهانم بیاورد!"

    # say L150 jon
    old "Ohh... I can feel your body tensing!"
    new "اوه... من احساس تنگ شدن بدنتون می‌کنم!"

    # say L151 jon
    old "Fill my mouth with your cum!"
    new "دست من رو با خودت پر کن!"

    # say L162 jon
    old "I'm so wet... But today I want you to fuck my ass..."
    new "من خیلی مرطوب هستم... اما امروز می‌خوام شوندت رو توییم بزنی..."

    # say L163 pla
    old "... W- what?"
    new "... و- وای؟"

    # say L164 jon
    old "I just want to remember the good times with my husband ..."
    new "من فقط می‌خوام خاطرات خوب رو با شوهرم به یاد بیارم..."

    # say L182 jon
    old "Oh God, it's so big it hurts!"
    new "اوه خدا، اینقدر بزرگه که درد می‌کنه!"

    # say L183 pla
    old "Do you want me to stop?"
    new "می‌خوای من متوقف بشه؟"

    # say L184 jon
    old "Ohh no, please don't stop, I want you to fuck my ass just like my husband used to do..."
    new "اوه نه، لطفاً متوقف نشو، من می‌خوام مثل همسرمون همچین کاری با این جای من بکنی..."

    # say L187 jon
    old "Faster! I want you to fuck me harder!"
    new "سریع‌تر! می‌خوام بیشتر با من بکنی!"

    # say L193 jon
    old "Oh yes! Just like that! Don't stop, don't stop!!"
    new "اوه بله! همینطور! نتوقوف، نتوقوف!!"

    # say L194 jon
    old "It hurts, but it feels so good!"
    new "درد می‌کنه، ولی خیلی خوب احساس می‌کنم!"

    # say L217 jon
    old "Oh yeah, fill my ass with your cum!"
    new "اوه بله، لولم رو با اسپرمتو تو پر کن!"

    # say L220 jon
    old "Oh God, you are definitely better than my husband..."
    new "اوه خدا، قطعاً بهتر از شوهرم هستی..."

    # say L234 bil
    old "Wow, it's bigger than I remember..."
    new "واو، بزرگتر از همین جا که به یاد داشتم..."

    # say L235 jon
    old "Ahhhh! So nice."
    new "آهههه! خیلی خوب."

    # say L236 gra
    old "My goddess!"
    new "الهه من!"

    # say L240 jon
    old "Let me give you a hand with this..."
    new "بیا، برام این کار رو کمک کنم..."

    # say L243 bil
    old "Oh, it looks so hot!"
    new "اوه، به نظر می‌رسه خیلی گرم باشه!"

    # say L247 bil
    old "Yeah! get that cock ready to fuck us!"
    new "بله! آماده کن اون ناخودت برای سکس با ما!"

    # say L248 jon
    old "Oh, Billie, please watch your mouth..."
    new "بیلی، لطفاً دقت کن به حرف‌هایت..."

    # say L271 jon
    old "Alright, I guess it's time to start, sister Grace is waiting hun!"
    new "باشه، به نظر می‌رسه وقت شروع هست، خواهر گریس منتظرمونه عزیزم!"

    # say L282 gra
    old "Oh my God! It feels amazing inside of me!"
    new "اوه خداوند! این حس واقعاً شگفت‌انگیزه!"

    # say L283 bil
    old "I have a great view of your pussy being fucked sister Grace..."
    new "من منظره خوبی از پوسی تو که فوت می‌شه دارم، خواهر گریس..."

    # say L285 jon
    old "Billie!"
    new "بیلی!"

    # say L289 gra
    old "My body and soul really needed this ritual."
    new "بدن و روح من واقعاً به این مراسم نیاز داشتند."

    # say L290 gra
    old "Ahhh!"
    new "آه!"

    # say L291 jon
    old "More... More..."
    new "بیشتر... بیشتر..."

    # say L292 bil
    old "If I had known about these rituals I would have become a nun too!"
    new "اگه می‌دونستم این مراسم‌ها هستن، من هم می‌شدم راهبه!"

    # say L296 gra
    old "Oh! My dear... You'll make me cum with so much g- grace..."
    new "اوه! عزیزم... با همین زیادی رحمت، من خواهم آمد..."

    # say L297 gra
    old "Ahhh! I'm about t-"
    new "اوه! من در حال آمدن هستم..."

    # say L298 bil
    old "Fuck! This is so damn good!"
    new "لُعنت! این خیلی خوبه!"

    # say L322 jon
    old "So good, my God!"
    new "الهی، خیلی خوبه!"

    # say L323 pla
    old "Fuck! I'm cuming!"
    new "اوه خدا! من هم در حال جیز کردن هستم!"

    # say L324 gra
    old "Me too... Ahhh!"
    new "من هم... آه!"

    # say L333 bil
    old "Wow, that was intense..."
    new "واو، این خیلی تیز بود..."

    # say L334 gra
    old "My God! Thanks for this..."
    new "الله! ممنون از این..."

    # say L335 jon
    old "[pla], you're my holy savior...  Take me!"
    new "[pla]، شما منقذ مقدس من هستید... برام بیای!"

    # say L336 pla
    old "(This is h- heaven... Shit!)"
    new "این ه- آسمانه... شیطون!"

    # say L341 bil
    old "Do you like what you see?"
    new "می‌پسندی چه چیزی را می‌بینی؟"

    # say L343 jon
    old "Come on hun, it's time to give me some blessed cock."
    new "بیا عزیزم، الان وقت دادن به من این قطعه مبارکه است."

    # say L344 gra
    old "Oh yeah, guide Mrs. Jones, just like you did with me."
    new "اوه بله، هدایت مس جونز رو، مثل همین که با من کردی."

    # say L359 bil
    old "Do you feel 'God's presence' right now?"
    new "الان احساس حضور خدا را می‌کنی؟"

    # say L360 jon
    old "Oh yes, I feel it... Very deep inside."
    new "بله، من احساسش می‌کنم... خیلی عمیق درونم."

    # say L361 gra
    old "I feel too so much of your divine presence, my heavenly God!"
    new "من هم احساس حضور الهی شما را می‌کنم، خداوند سماوی من!"

    # say L366 jon
    old "My God! It feels amazing!"
    new "الهی! احساسش شگفت‌انگیز است!"

    # say L367 bil
    old "Oh yes, fuck my granny, just like you fucked me!"
    new "اوه بله، بابا رو فک کن، مثل همین که من رو فک کردی!"

    # say L369 gra
    old "[pla], my spiritual guide, you're the best..."
    new "[pla]، راهنمای معنوی من، تو بهترین هستی..."

    # say L373 bil
    old "This is the best religion ever!"
    new "این بهترین دین هست!"

    # say L374 jon
    old "Oh, you have no idea!"
    new "اوه، تو هیچ ایده‌ای نداری!"

    # say L375 jon
    old "I'm touching God right now... This is so good..."
    new "من الان به خدا لمس می‌کنم... این خیلی خوبه..."

    # say L399 pla
    old "I- I'm cuming again..."
    new "من- من دوباره می‌آیم..."

    # say L400 jon
    old "Ahhhhhh!"
    new "آههههه!"

    # say L401 bil
    old "Yeesss!"
    new "بله!"

    # say L402 gra
    old "We need your cum, right now! We to purify ourselves."
    new "ما به سیال تو نیاز داریم، الان! ما باید خودمون رو پاک کنیم."

    # say L411 bil
    old "Oh, oh, it's my turn! It's my turn!"
    new "اوه، اوه، الان دفعه منه! الان دفعه منه!"

    # say L412 jon
    old "I'm sorry, my dear, But you must stay a virgin until marriage."
    new "ببخشید، عزیزم، اما تو باید تا ازدواج بکنی، بکنار بمانی."

    # say L413 bil
    old "W- what the fuck!? But you already had sex with him!"
    new "و- وای، این چه خرابیه!؟ ولی تو قبلاً با او جنسیتی داشتی!"

    # say L414 jon
    old "Yes, my dear, I'm a widow..."
    new "بله، عزیزم، من بیوه هستم..."

    # say L415 gra
    old "Don't worry Mrs. Jones I have an idea..."
    new "نگران نباشید خانم جونز، من ایده‌ای دارم..."

    # say L429 pla
    old "Wow! it feels great."
    new "واو! این حس خوبه."

    # say L430 bil
    old "Ohhh yeahh, Fuck! This is good!... Thanks sister."
    new "اوه همینه، شیطون! این خوبه!... ممنون خواهر."

    # say L431 gra
    old "Enjoy it honey..."
    new "لذت ببر عزیزم..."

    # say L432 gra
    old "You are welcome, we all can get closer to God with [pla]'s help."
    new "خواهش می‌کنم، ما همه می‌توانیم با کمک [pla] نزدیک‌تر به خدا شویم."

    # say L435 bil
    old "Faster, I need it fater!"
    new "سریع‌تر، من نیاز دارم تا سریع‌تر باشد!"

    # say L438 jon
    old "We need you to do more..."
    new "ما به تو نیاز داریم که بیشتر کار کنی..."

    # say L439 bil
    old "The three of us need to get enough of you... Please, keep going!"
    new "ما سه تا نیاز داریم که از تو خیلی بیشتر برسم... لطفاً ادامه بده!"

    # say L440 gra
    old "Don't stop!"
    new "توقف نکن!"

    # say L444 bil
    old "Yeah, yeah, yeah... Just like this!"
    new "بله، بله، بله... همینطور!"

    # say L445 jon
    old "Oh God! Woww!"
    new "اوه خدا! وایی!"

    # say L446 gra
    old "Ahhh! Your cock is so damn good!"
    new "اوه! ناخودآگاهت خیلی خوبه!"

    # say L447 gra
    old "I mean... So divine and big... Ahhh!"
    new "من قصده دارم... خدایی و بزرگ... آه!"

    # say L475 gra
    old "I feel your sacred milk..."
    new "اوه، من آب شیر مقدس تو را حس می‌کنم..."

    # say L476 bil
    old "Hmm, big load! Ahhh"
    new "هم، بار بزرگ! آه ها"

    # say L477 jon
    old "This is more than enough for the three of us... But we want more..."
    new "این برای سه تا ما کافیه... ولی ما می‌خوایم بیشتر باشه..."

    # say L498 bil
    old "Your cock is so big and good!"
    new "پوسی تو خیلی بزرگ و خوبه!"

    # say L499 gra
    old "Yeah... This is what my soul was asking for..."
    new "بله... این همان چیزی بود که روح من از آن درخواست کرده بود..."

    # say L505 gra
    old "Uhhh... It's a divine cock... So good..."
    new "اوه... این نیم‌پا خداییه... خیلی خوبه..."

    # say L506 bil
    old "I wanna taste you more and more!"
    new "من می‌خوام تو رو بیشتر و بیشتر بچُشم!"

    # say L510 bil
    old "Fuck her... She needs more [pla], she wants more of your-"
    new "فکر کنم باید بیشتر [pla] به او بدهی... او می‌خواهد بیشتر از شما..."

    # say L511 gra
    old "Of your massive and saint cock..."
    new "از آن عصا مقدس و بزرگت..."

    # say L512 bil
    old "Fuck, I need it too.."
    new "بیلی: من هم نیاز دارم.."

    # say L535 bil
    old "We want your cum in our mouths..."
    new "ما می‌خوایم سپرمون رو توی دهانمون..."

    # say L536 jon
    old "Oh yes hun, give it to us!"
    new "اوه بله عزیزم، به ما بده!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/HalloweenAnimations.rpy
translate persian strings:

    # say L5 sis
    old "I'm ready... Do your thing and put it in..."
    new "آماده‌ام... کارتو انجام بده و داخلش بیا..."

    # say L6 pla
    old "Alright."
    new "باشه."

    # say L12 sis
    old "Oh God... It feels really nice... Your cock feels really nice in my ass..."
    new "اوه خدا... احساسش واقعاً خوبه... نوک تو توی دمدم احساسش واقعاً خوبه..."

    # say L13 pla
    old "Uhh it feels.... Tight..."
    new "اوه اونجوره... تنگه..."

    # say L18 sis
    old "Ohh yesss... Keep doing it... Fuck my ass [pla]... Fuck my ass!"
    new "اوه بله... ادامه بده... زنده‌بازم رو بکش [pla]... زنده‌بازم رو بکش!"

    # say L19 pla
    old "Ahhh... Ahhhh..."
    new "اوه... اوه..."

    # say L43 sis
    old "Ohh God! I'm coming... I'm coming!!!"
    new "اوه خدا! من در حال آمدن هستم... من در حال آمدن هستم!!!"

    # say L44 pla
    old "Ahhh...."
    new "اوه...."

    # say L59 mo1
    old "Does it feel nice baby?"
    new "حلاوه می‌تونه؟"

    # say L60 pla
    old "It feels amazing, please don't stop!"
    new "این حس عالیه، لطفاً متوقف نشو!"

    # say L65 mo1
    old "Oh yes! Oh yes! Fuck my tits baby!"
    new "اوه بله! اوه بله! بیا بفرمای بر سینه‌هام!"

    # say L66 pla
    old "Ahh... Ahhh"
    new "آه... آه..."

    # say L70 mo1
    old "Fuck my tits harder [pla]! I want you to cum on my tits baby."
    new "بیا زودتر به سینه‌هام بزن [pla]! می‌خوام روی سینه‌هام خروجی بدی عزیزم."

    # say L71 pla
    old "Uhhhh..."
    new "اوه..."

    # say L95 pla
    old "I- I am going to... Ahhh"
    new "من- من قراره... آه"

    # say L96 mo1
    old "Cum on my tits honey!"
    new "برای مامان عزیزم، روی سیناهام بیا!"

    # say L111 sis
    old "Did you have a double blowjob before [pla]?"
    new "قبل از [pla] دوباره زبان زدن کرده بودی؟"

    # say L113 mo1
    old "Enjoy it baby!"
    new "لذت ببر عزیزم!"

    # say L118 mo1
    old "What does it feel like to have your [mo1rel] and [sisrel] sucking your dick?"
    new "[mo1rel] و [sisrel] شما رو چطور می‌کشند؟"

    # say L119 pla
    old "(OH MY GOD I CAN'T BELIEVE IT.)"
    new "اوه خدا، باورم نمی‌کنم."

    # say L120 sis
    old "It's probably his darkest fantasy..."
    new "احتمالاً این خیال تاریک‌ترین خیالش هست..."

    # say L125 mo1
    old "And what about if you cum for us?"
    new "و اگر تو برای ما خودت رو بیاوردی؟"

    # say L127 sis
    old "Yes! Let's make him cum!"
    new "بله! بیایید اون رو به عجولان برسونیم!"

    # say L151 pla
    old "Oh my... I- I am going to... "
    new "اوه خدای من... من- من قرار هستم..."

    # say L152 mo1
    old "Don't stop [sis]."
    new "توقف نکن [sis]."

    # say L167 mo2
    old "What a HUGE cock [pla]!"
    new "چه نوزک بزرگی [pla]!"

    # say L169 mo1
    old "Does it taste great, isn't?"
    new "آره، خوشمزه است، همینطور نیست؟"

    # say L170 mo2
    old "Oh yeah..."
    new "اوه بله..."

    # say L174 mo2
    old "Oh god I can't ever think about being fucked by this cock..."
    new "اوه خدا من هیچ وقت نمی‌تونم به این ناخن فکر کنم..."

    # say L175 sis
    old "Is fucking amazing... You should try it."
    new "این خیلی عالیه... باید امتحانش کنی."

    # say L176 mo2
    old "Definetely I will..."
    new "حتماً خواهم انجام داد..."

    # say L182 mo2
    old "Enought waste of time, I want to fuck! Let's make him cum."
    new "کافیه وقت ببریم، می‌خوام جنس کنم! بیایید بیاوندش."

    # say L184 sis
    old "Yes! Let's make him cum again!"
    new "بله! بیایید دوباره اون رو به عجولان برسانیم."

    # say L209 mo2
    old "Yeesss..."
    new "بله..."

    # say L213 pla
    old "Alright... What the fuck is happening here?"
    new "باشه... اینجا خوب چه قصه‌ای داره؟"

    # say L224 mo2
    old "Oh God! It's fucking huge..."
    new "اوه خدا! این واقعاً بزرگه..."

    # say L225 mo1
    old "Does it hurt [mo2]?"
    new "آیا درد می‌کنه [mo2]؟"

    # say L226 mo2
    old "A little bit, but it feels so good..."
    new "مادر: یه کم، ولی احساسش خیلی خوبه..."

    # say L231 mo2
    old "Oh my fucking God, he is drilling me!"
    new "او خداوند من، او داره منو سوراخ می‌کنه!"

    # say L232 mo2
    old "Don't stop, fuck me harder [pla]!"
    new "توقف نکن، سخت‌تر بکار بر [pla]!"

    # say L237 mo2
    old "Oh yessss! Harder, Fuck me harder baby!"
    new "اوه بلهههه! سخت‌تر، بفرمای سخت‌تر بچه‌جان!"

    # say L261 mo2
    old "Ahhhhh Ahhh, I'm cumming!"
    new "اوه، من در حال آمدن هستم!"

    # say L265 mo1
    old "Well, it's my turn now..."
    new "خب، حالا دوباره من دست کارم می‌زنم..."

    # say L267 mo2
    old "I will bring one of our toys..."
    new "من یکی از اسباب‌بازی‌های ما رو می‌آورم..."

    # say L283 mo2
    old "We haven't tried anal sex in a long time... How does it feel to be completely filled?"
    new "ما از جنس آنال طول زیادی استفاده نکرده‌ایم... احساس کامل پر شدن چطوره؟"

    # say L284 mo1
    old "Ohhhhh God, this is like a double penetration! It's to much..."
    new "اوه خدا، این مثل نفوذ دوگانه است! خیلی زیاده..."

    # say L289 mo1
    old "OHHH WOW! I can't handle this!"
    new "اوه وای! نمی‌تونم این رو تحمل کنم!"

    # say L290 mo1
    old "Ahhh Ahhhh!"
    new "آه آه!"

    # say L294 mo2
    old "Let's fuck her harder [pla], let's fuck your [mo1rel] hard!"
    new "بیای بیشتر با او زدن [pla]، بیای بیشتر با تو زدن [mo1rel]!"

    # say L298 mo1
    old "Oh oh yeeesss! I have never feel something like this!"
    new "اوه اوه بله! هیچ وقت چیزی مثل این نfeltم!"

    # say L321 mo1
    old "I- I... Ahhhhh I- am... Cumming!"
    new "من... آه آه آه... من... در حال خروج هستم!"

    # say L326 pla
    old "Holy shit... I'm fucking dry."
    new "شیطانی... من خشک شدم."

    # say L327 sis
    old "Oh no... I have been waiting my turn."
    new "اوه نه... من منتظر بودم نوبت من برسه."

    # say L345 mo1
    old "Honey, let him rest a bit, I'm going to help him get ready to fuck you too."
    new "حون، بیای بیشک همه‌ی اونو بگذار، من می‌خوام بهش کمک کنم تا برای فک کردن تو آماده بشه."

    # say L346 sis
    old "Hmmm Alright."
    new "خوب، همین‌جوری."

    # say L350 sis
    old "Now! I want it now!"
    new "الان! من الان می‌خوام!"

    # say L351 mo1
    old "Oh, honey just let me enjoy it a little bit more..."
    new "اوه، عزیزم، فقط بیای یه کم دیگه لذت ببر..."

    # say L352 sis
    old "Hmmm..."
    new "همم..."

    # say L377 sis
    old "NOW!"
    new "الان!"

    # say L378 mo2
    old "Let her fuck [pla], she wants to enjoy too, don't be selfish..."
    new "بیا بگیر [pla]، او هم می‌خواهد لذت ببرد، خودت خشنود نباش..."

    # say L379 mo1
    old "Alright... It's your turn [sis], enjoy it "
    new "البته... حالا دورت هست [sis]، لذت ببر"

    # say L391 sis
    old "Ohhhh yeahh, this is what I'm talking about..."
    new "اوه همینه، این همینه که من می‌گم..."

    # say L392 mo1
    old "Does it feel good honey?"
    new "حلاوه، این خوب است؟"

    # say L393 sis
    old "It feels great, I never get tired of this..."
    new "این خیلی خوب است، هرگز از این خسته نمی‌شوم..."

    # say L397 sis
    old "Fuck me harder! I want you to make me cum like you did with [mo1rel]..."
    new "بیا بیشتر بزن! می‌خوام مثل همون زمانی که با [mo1rel] بودی، من رو به عجایب برسونی..."

    # say L400 sis
    old "Ohh yeah, just like that, don't stop baby."
    new "اوه بله، همینطور، نتوقف بیبی."

    # say L404 mo2
    old "You are definetly a little pervert [pla], aren't you? You already fucked me, your [mo1rel] and now you are fucking your [sisrel]."
    new "تو قطعاً یه کودک خوب‌ناکامی هستی [pla]، نیست؟ قبلاً منو، [mo1rel] رو و حالا هم [sisrel] رو می‌پرداختی."

    # say L405 mo1
    old "Oh god, but it feels really good."
    new "اوه خدا، ولی واقعاً خوب است."

    # say L406 sis
    old "Yes! He is making me cum!"
    new "بله! او منو می‌آرده!"

    # say L430 sis
    old "Yesss Yesss... I'm cumming!!!"
    new "بله بله... من آمدم!!!"

    # say L431 sis
    old "Ahhhhhh..."
    new "آه آه آه..."

    # say L432 mo1
    old "I want it on my mouth."
    new "من می‌خوام روی دهانم بیاد."


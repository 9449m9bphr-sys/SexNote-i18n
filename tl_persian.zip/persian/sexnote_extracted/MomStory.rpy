# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/MomStory.rpy
translate persian strings:

    # say L11 mo1
    old "Hi honey! Your breakfast is ready!"
    new "سلام عزیزم! صبحانه‌ت آماده شده."

    # say L12 pla
    old "Thank you [mo1rel]."
    new "ممنون [mo1rel]."

    # say L16 mo1
    old "[pla], I wanted to talk to you..."
    new "[pla]، می‌خواستم با تو صحبت کنم..."

    # say L19 mo1
    old "I was thinking of a way to improve your relationship with your [mo2rel]."
    new "من به فکر یه راه برای بهبود رابطت با [mo2rel] بودم."

    # say L21 mo1
    old "Well, I think if you spend some time with her, it could help her get to know you."
    new "خوب، فکر می‌کنم اگه وقتی باهاش بگذرو، می‌تونه بهش کمک کنه تا تو رو بهتر بشناخته."

    # say L22 mo1
    old "You know she's pretty stressed. But only because she's not around enough since she's always working."
    new "میدونی که او خیلی استرس داره. فقط چون زیاد وقت نداره، همیشه کار داره."

    # say L25 mo1
    old "Just try, please? Could you?... For me?"
    new "لطفاً سعی کن، می‌تونی؟... برای من؟"

    # say L26 pla
    old "Uhmm... Fine."
    new "اوه... خوب."

    # say L27 mo1
    old "Great, It's very simple. She needs some help for her job. She's thought about hiring an assistant..."
    new "عالی، خیلی ساده است. او برای کارش به کمکی نیاز دارد. فکر کرده تا یک دستیار استخدام کند..."

    # say L28 mo1
    old "So, I asked her to let you work for her. And of course she will reward you for all your help."
    new "پس از او خواستم که تو رو استخدام کنه. و البته برای همه کمک‌هایت به تو جایزه می‌ده."

    # say L30 pla
    old "Alright, alright. I'll help her then..."
    new "باشه، باشه. من بهش کمک می‌کنم..."

    # say L35 mo2
    old "Do you have the receipt of-"
    new "آیا فیش خریدت رو داری-"

    # say L38 mo2
    old "Oh, there you are..."
    new "اوه، اینجا هستی..."

    # say L39 pla
    old "Good morning, [mo2]. How are you today so far?"
    new "صبح بخیر، [mo2]. امروز تا حالا چطور بودی؟"

    # say L41 mo2
    old "Busy... Did you talk with him. Huh?"
    new "مشغول هستم... با او حرف زدی؟ هه؟"

    # say L42 mo1
    old "Yes, I just did. And you have nothing to worry about."
    new "بله، همین الان با او صحبت کردم. و شما هیچ نگرانی ندارید."

    # say L43 mo2
    old "... He's still a pervert."
    new "همچنان یک پرترب می‌باشد."

    # say L44 pla
    old "I'm not a-"
    new "من یک خودسر نیستم-"

    # say L45 mo1
    old "He is just a teenager. No need to be rude. Everything is okay."
    new "او فقط یک نوجوان است. لازم نیست بد بگویی. همه چیز خوب است."

    # say L46 mo2
    old "Hmm... If you say so..."
    new "Hmm... اگه می‌گی، خب..."

    # say L47 mo2
    old "I will be doing some calls, [pla]. Look for me when you are ready."
    new "من چند تا تماس خواهم زد، [pla]. وقتی آماده شدی، به من بگو."

    # say L51 pla
    old "Ok. (Geez)"
    new "باشه. (حیف)"

    # say L52 mo1
    old "Anyway, did you want to talk about something?"
    new "بازی، می‌خواستی در مورد چیزی صحبت کنی؟"

    # say L79 pla
    old "(W- what is she doing?)"
    new "(و- و اون چه کاری داره؟)"

    # say L80 mo1
    old "Ohh, sorry I'm trying to apply some sunscreen on my butt, hehehe."
    new "اوه، معذرت من داشتم روی پشتم کرم آفتاب‌زدن می‌زدم، هههه."

    # say L86 mo1
    old "Hi honey, are you coming to hang out in the pool?"
    new "سلام عزیزم، می‌خوای بیایی تو حوضچه باهام بازی کنی؟"

    # say L88 pla
    old "No, I don't want to swim today."
    new "نه، امروز نمی‌خوام شنا بزنم."

    # say L90 mo1
    old "Really? It's a shame on this beautiful day."
    new "حقاً؟ این برای این روز زیبا خیلی شرمنده‌انگیز است."

    # say L92 mo1
    old "Why don't you help me then to apply some sunscreen on my back?"
    new "پس چرا به من کمک نمی‌کنی تا کرم آفتاب‌سوزی رو به پشتم بزنم؟"

    # say L97 pla
    old "Oh, okay."
    new "اوه، خوب."

    # say L99 mo1
    old "Thanks sweetheart."
    new "ممنون عزیزم."

    # say L105 pla
    old "I'm sorry I have some things to do."
    new "ببخشید، من چند کاری دارم."

    # say L107 mo1
    old "Oh, don't worry honey, go and do what you have to do."
    new "اوه، نگران نباش عزیزم، برو و کارهات رو انجام بده."

    # say L109 pla
    old "Ok. See you later."
    new "باشه. بعداً می‌بینیم."

    # say L119 mo1
    old "Be sure to cover the entire back."
    new "حتماً کل پشتت رو پوشش بدی."

    # say L120 pla
    old "I will, don't worry."
    new "باشه، نگران نباش."

    # say L137 pla
    old "I think that's it with your back, would you need anything else?"
    new "فکر کنم پشتتو تمام شده، نیازی به چیز دیگه‌ای داری؟"

    # say L141 pla
    old "Okay, no problem."
    new "باشه، هیچ اشکالی ندارم."

    # say L156 pla
    old "Hmm, there still some areas that I think might need some Sunscreen."
    new "Hmm، هنوز برخی مناطق هست که فکر کنم نیاز به آفتاب‌زدگی دارن."

    # say L175 pla
    old "(Should I try to go further?)"
    new "باید بیشتر برسم؟"

    # say L178 pla
    old "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} (I think is a good moment to try the Sauron's Mouth.)"
    new "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} فکر می‌کنم الان زمان خوبیه تا سعی کنم سائورن‌های دهان رو انجام بدم."

    # say L179 pla
    old "{b}Sauron's mouth:{/b} [mo1rel], I'll give you a foot massage again, you just stay calm."
    new "{b}دست ساورون:{/b} [mo1rel]، دیوونه نباش، فقط آرام باش. من دوباره پاشون رو می‌فرستم."

    # say L181 pla
    old "(I think it works... Let's see.)"
    new "فکر کنم کار می‌کنه... بیاین ببینیم."

    # say L191 pla
    old "Well it's done. I think you are perfect now."
    new "خب انجام شد. فکر کنم حالا تو کاملی."

    # say L202 pla
    old "Ok... (Maybe next time.)"
    new "باشه... (شاید بعداً.)"

    # say L233 mo1
    old "Hey, [pla], I wanted to ask if you could come with me to the doctor's office."
    new "هی، [pla]، می‌خواستم بپرسم آیا می‌تونی با من به کلینیک بیایی."

    # say L235 pla
    old "What! Why? Did something happen to you? Are you sick?"
    new "چه کاری! چرا؟ اتفاقی به تو افتاده؟ بیمار شدی؟"

    # say L237 mo1
    old "No, no, it's nothing bad. It's just a routine check up."
    new "نه، نه، هیچ چیز بدی نیست. فقط یک بررسی روتین است."

    # say L239 pla
    old "Oh, ok. Sure no problem"
    new "اوه، خوب. حتماً مشکلی نداره"

    # say L241 mo1
    old "Perfect! Wait for me while I get changed, okay?"
    new "عالی! منتظرم باش تا لباسم رو عوض کنم، خوبه؟"

    # say L245 mo1
    old "Thank you, baby."
    new "ممنون، عزیزم."

    # say L259 mo1
    old "I'm ready! How do I look?"
    new "آماده‌ام! من اینجوری چطور به نظر می‌رسم؟"

    # say L261 pla
    old "You look... (So hot) V- Very nice [mo1rel]."
    new "تو خیلی... (خیلی گرم) خوب هستی [mo1rel]."

    # say L263 mo1
    old "Aww, thanks, honey... Ok, let's head to the doctor's office."
    new "اوه، ممنون عزیزم... خب، بیایید به کلینیک پزشک بریم."

    # say L270 pla
    old "Ok, we're here. What's the appointment about, [mo1rel]?"
    new "باشه، اینجا هستیم. ملاقات برای چیه، [mo1rel]؟"

    # say L272 mo1
    old "Oh... It's called a mammogram. It's to make sure there's no problem with my boobies. Hehe."
    new "اوه... این به نام ماموگرام هست. برای اینه که ببینن با سینام مشکلی نیست. ههه."

    # say L274 pla
    old "Oh... ok, I understand... And what should we do?"
    new "اوه... خب، متوجه شدم... باید چه کاری بکنیم؟"

    # say L276 mo1
    old "Well, it's time for the appointment! So we should go to nurse Mary's office right now."
    new "خب، وقت آن رسیده که برای ملاقات برویم! پس باید حالا به دفتر پرستار مری برویم."

    # say L278 pla
    old "Ok, Come on..."
    new "باشه، بیا..."

    # say L286 mo1
    old "Good morning..."
    new "صبح بخیر..."

    # say L289 mar
    old "Hello, How have you been? Long-time, no see."
    new "سلام، چطوری؟ طولانی است که ندیده‌ام."

    # say L291 mar
    old "Ohh, and who is this handsome young man? Are you trying out young meat? "
    new "اوه، و این جوان زیبا کیه؟ می‌خوای از جوان‌ترین‌ها استفاده کنی؟"

    # say L296 mo1
    old "Oh Mary. Haha. Don't be silly, I'm his [mo1rel], he's just joining me for my appointment."
    new "اوه مری. هاها. نباید خنده‌دار باشی، او [mo1rel] من هست، فقط برای نوبت من همراه من آمده."

    # say L298 mar
    old "Oh, I see. Right... talking about the test... I have some bad news... The technical machine to do the mammogram is broken at the moment."
    new "اوه، من متوجه شدم. درست... در مورد آزمون... خبر بدی دارم... ماشین تکنیکال برای انجام ماموگرافی الان خراب است."

    # say L300 mar
    old "So we will have to do it in the old fashioned way... So I get to give you a good massage on those babies ..."
    new "پس باید به روش قدیمی انجام بدیم... پس من باید اونجا رو برایت مassage بدم..."

    # say L302 mo1
    old "Hehehe. It's fine Mary, as you wish..."
    new "هههه. خوبه مری، همچون آنچه می‌خواهی..."

    # say L304 mar
    old "Well now, Sue, take off your clothes..."
    new "خب الان، سو، لباسب خودت رو ببرد..."

    # say L306 pla
    old "... (Oh crap)"
    new "اوه خدا"

    # say L308 pla
    old "Ehh ... Well ... I'll just head on out, to give you guys some privacy."
    new "اوه... خب... من بهتره برم، تا شما صمیمی باشید."

    # say L310 mar
    old "Hey! Wait there. What a shy one you have here. Don't worry, sugar. This is nothing you haven't seen before."
    new "هی! جا بزن. چقدر خجالتی هستی. نگران نباش، عزیزم. این هیچیزی نیست که قبلاً ندیده باشی."

    # say L312 mar
    old "Besides, she won't get naked. Haha. Don't worry. This is very professional."
    new "البته، او عریان نمی‌شود. هاها. نگران نباش. این خیلی حرفه‌ایه."

    # say L314 pla
    old "Oh. Ok, then..."
    new "اوه. خب، درسته..."

    # say L320 mar
    old "Let's see those babies!... I'm going to massage them gently. Tell me, how does it feel?"
    new "بیاین ببینم اون نوزک‌ها رو!... من می‌خوام با آرامش ماساژشون بدم. بگو، احساسش چطوره؟"

    # say L321 mar
    old "Wow, I didn't remember them being so big... Lucky you!"
    new "واو، نمی‌تونستم به یاد بیارم اینقدر بزرگ هستن... شما خوشحال شدی!"

    # say L323 pla
    old "... (This is...)"
    new "این همینه..."

    # say L324 mar
    old "Do you feel any pain?"
    new "آیا دردی داری؟"

    # say L326 mo1
    old "No, not at all. In fact, it feels very... good..."
    new "نه، هیچ دردی ندارم. در واقع، احساس خیلی... خوبی می‌کنم..."

    # say L327 mar
    old "Hmm... Honestly, I haven't done this manually for a long time. I can't feel anything... I'm going to do it a little harder, ok?"
    new "هم... صادقانه، این کار رو دستی از طولانی‌ترین زمانی که به خاطر دارم نکرده‌ام. هیچ چیز حس نمی‌کنم... قصد دارم کمی سخت‌تر انجام بدم، خوبه؟"

    # say L331 mar
    old "Well, that's it for now..."
    new "خب، اینقدر برای حالا کافی است..."

    # say L335 mar
    old "I still couldn't feel anything..."
    new "همچنان هیچ احساسی ندارم..."

    # say L337 mar
    old "So, I would like you to come again. We can do the test again and be more thorough. How does Monday sound?"
    new "پس من می‌خواهم ازت بخواهم دوباره بیایی. می‌تونیم دوباره آزمون رو بکنیم و دقیق‌تر باشیم. یکشنبه چطور به نظرت می‌رسه؟"

    # say L339 mo1
    old "Monday is perfect."
    new "دوشنبه خوبه."

    # say L341 mar
    old "Ok, then Thursday, we will try again. It was really nice to see you again!"
    new "خوب، پس همین جمعه دوباره امتحان می‌کنیم. خوشحالم که دوباره با تو دیده‌ام!"

    # say L343 mo1
    old "Likewise, Mary."
    new "همچنین برای من هم خوشحالم که دوباره ازت دیدم، مری."

    # say L345 mar
    old "See you later, young man..."
    new "تا بعداً، جوان..."

    # say L347 pla
    old "...See you later..."
    new "تا بعداً..."

    # say L367 mo1
    old "Hi, honey! Do you want to join me?"
    new "سلام، عزیزم! می‌خوای با من هم بیایی؟"

    # say L377 pla
    old "I am sorry, [mo1rel]. I'm a little tired. I'm gonna go to sleep."
    new "ببخشید، ز[mo1rel]. خسته‌ام. می‌روم بخوابم."

    # say L379 mo1
    old "Don't worry, honey. Go to sleep. I will watch a movie then head out myself."
    new "نگران نباش، عزیزم. برو خواب. من یه فیلم می‌بینم بعد خودم هم می‌رم."

    # say L381 pla
    old "Ok. Good night."
    new "باشه. شب خوب باش."

    # say L383 mo1
    old "Sweet dreams, dear."
    new "خواب خوش، عزیزم."

    # menu L390 
    old "Sure"
    new "مطمئنم"

    # say L394 pla
    old "Are you sure, I think you drank a lot and should rest..."
    new "مطمئنی؟ فکر کنم خیلی نوشیدی و باید استراحت کنی..."

    # say L396 mo1
    old "Awww, don't worry honey... I'm fine, I just want to relax a little..."
    new "اوه، نگران نباش عزیزم... من خوبم، فقط می‌خوام کمی آرام بگیرم..."

    # say L398 mo1
    old "I also like your company and your big-"
    new "من هم دوست دارم با تو باشم و این سرپای بزرگت-"

    # say L402 mo1
    old "Your big... Heart is what I meant. Oh, come on, don't leave me alone, I want some company, please?"
    new "حتماً، بزرگ... قلبت همین جوری بزرگ است. آه، بیا، نمی‌تونم تنها بمونم، لطفاً همراه من باش؟"

    # say L406 mo1
    old "Great, you are the best!"
    new "عالی، تو بهترینی هستی!"

    # say L408 mo1
    old "But this time I choose the movie"
    new "البته، این بار من فیلم رو انتخاب می‌کنم"

    # say L419 mo1
    old "Great, honey! What movie would you like to watch?"
    new "عالی، عزیزم! چه فیلمی می‌خوای ببینی؟"

    # menu L422 
    old "Romance"
    new "رومانسی"

    # say L425 mo1
    old "Ohh, I love these kind of movies!"
    new "اوه، این جور فیلم‌ها رو خیلی دوست دارم!"

    # say L427 pla
    old "Great, let's enjoy it!"
    new "عالی، بیاین لذت ببریم!"

    # menu L436 
    old "Action"
    new "اکشن"

    # say L439 mo1
    old "This is your favorite type of movie, isn't it?"
    new "این همین نوع فیلم مورد علاقه‌ت است، نه؟"

    # say L441 pla
    old "Yup, but if you want, we can watch something else..."
    new "بله، اما اگه می‌خوای، می‌تونیم چیز دیگه‌ای ببینیم..."

    # say L443 mo1
    old "Ohh no, don't worry honey. I'm happy to spend time with you."
    new "اوه نه، نگران نباش عزیزم. من خوشحالم که وقت رو با تو می‌گذونم."

    # menu L451 
    old "Horror"
    new "هرروز"

    # say L454 mo1
    old "Are you sure? I don't want you to have any nightmares."
    new "مطمئنی؟ نمی‌خوام تو خواب بدی داشته باشی."

    # say L456 pla
    old "Hahaha. I can handle it, [mo1rel]."
    new "حاحاحا. من این رو می‌تونم تحمل کنم، ز[mo1rel]."

    # say L467 mo1
    old "Wait... Before we start, let me get a glass of wine. I want to relax a little and enjoy the movie."
    new "بیای، قبل از شروع یه لیوان شراب بیاورم. می‌خوام کمی آرام شم و فیلم رو لذت ببرم."

    # say L469 pla
    old "Ok. No problem. (Hmm.)"
    new "باشه. هیچ اشکالی ندارم. ( Hmm. )"

    # say L471 mo1
    old "Thanks, honey!"
    new "ممنون، عزیزم!"

    # say L479 mo1
    old "Perfect! A movie night and a good glass of wine. What a great combination. Do you want a bit of wine, too, sugar?"
    new "عالی! شب فیلم و لیوان خوب شراب. ترکیبی عالی. آیا می‌خوای هم یه کم شراب بخوری، حلوایی؟"

    # say L481 pla
    old "I'm fine for now."
    new "من الان خوبم."

    # say L483 mo1
    old "Ok, honey. Let's start the movie"
    new "خوب، عزیزم. بیایید فیلم رو شروع کنیم"

    # say L512 mo1
    old "Wow, this movie is great, isn't it, honey?"
    new "این فیلم عالیه، هیچ، عسلی؟"

    # say L513 pla
    old "Yeah, is pretty awesome-"
    new "بله، خیلی عالیه-"

    # say L521 mo1
    old "Hmm, it looks like you are ready for the best moment of movie night..."
    new "Hmm، به نظر می‌رسه آماده‌ی بهترین لحظه‌ی شب فیلم هستی..."

    # say L522 pla
    old "... W- what do you mean..."
    new "... و- و منظورت چیه..."

    # say L523 mo1
    old "What I mean is... Take that big buddy of yours out..."
    new "من قصد دارم بگم... آن دوست خوبت رو بیرون ببر..."

    # say L527 mo1
    old "Mmm, nice!... What do you want today, baby?"
    new "ممنون، عزیزم... امروز چی می‌خوای؟"

    # say L531 mo1
    old "Good choice! Let [mo1rel] handle this beast."
    new "انتخاب خوبی! بیا، بذار [mo1rel] این وحشی رو دربیاره."

    # say L540 mo1
    old "You really like this, huh?..."
    new "این رو خیلی دوست داری، همه‌چی؟..."

    # say L550 mo1
    old "You read my mind..."
    new "دلم رو خواندی..."

    # say L581 mo1
    old "Hmmm, honey? This movie is exciting you that much?"
    new "همم، عزیزم؟ این فیلم همین‌قدر تو رو هیجان‌زده می‌کنه؟"

    # say L582 pla
    old "I'm sorry, [mo1rel]. I can't handle it. I honestly didn't mean to..."
    new "ببخشید، [mo1rel]. نمی‌تونم اینجوری باشم. واقعاً هم نمی‌خواستم..."

    # say L583 mo1
    old "It's ok. Don't you worry. Let me give you a hand with that. I don't want you to be like this the whole movie."
    new "باشه. نگران نباش. بیای براحت کمک کنم. نمی‌خوام طول فیلم اینجوری باشی."

    # say L603 mo1
    old "Hmm, honey? Are you getting hard again?"
    new "هم، عزیزم؟ دوباره سخت می‌شی؟"

    # say L604 pla
    old "Sorry [mo1rel], I didn't mean to..."
    new "ببخش [mo1rel]، من قصد نداشتم..."

    # say L605 mo1
    old "It's ok. actually I wanted to try something a bit different this time..."
    new "باشه. در واقع این بار می‌خواستم چیزی متفاوت تر امتحان کنم..."

    # say L607 mo1
    old "Don't worry honey, you are going to love it."
    new "نگران نباش عزیزم، تو اینو دوست خواهی داشت."

    # say L618 mo1
    old "The movie was great!"
    new "فیلم عالی بود!"

    # say L620 pla
    old "Yeah, I didn't expect that ending at all..."
    new "بله، هیچ وقت انتظار نداشتم این پایان رو ببینم..."

    # say L622 mo1
    old "Thanks for spending time with me, [pla]."
    new "ممنونم که وقت رو با من گذراندی، [pla]."

    # say L624 pla
    old "You don't have to thank me, [mo1rel]. I enjoy your company!"
    new "ممنون نباشی، [mo1rel]. لذت برداشتم از همراهیت!"

    # say L626 mo1
    old "Aww, that makes me happy. If you want to watch another movie, come to see me tomorrow night."
    new "اوه، این خوشحالم می‌کنه. اگه می‌خوای فیلم دیگه‌ای ببینی، فردا شب به من بیا."

    # say L627 mo1
    old "I know we will have a good time together."
    new "مطمئنم که خوشحالیم با هم."

    # say L628 pla
    old "You can count on it!"
    new "می‌تونی رویش حساب کرد!"

    # say L630 mo1
    old "Ok, dear. Let's go to sleep."
    new "خوب، عزیزم. بیایید بخوابیم."

    # say L632 pla
    old "Alright, [mo1rel]. Good night."
    new "باشه، ز[mo1rel]. شب خوب."

    # say L634 mo1
    old "Sweet dreams, honey..."
    new "حالم خوب باشد، عسلیزم..."

    # say L650 mo1
    old "[pla]... I- I'm so sorry... I don't know what came over me... I'm your [mo1rel]! I shouldn't have... It must have been all the wine I drank..."
    new "[pla]... من- من خیلی متاسفم... نمی‌دونم چه چیزی رو بر من آمد... من مادرت هستم [mo1rel]! نباید اینجوری کردم... شاید به سبب شرابی بود که خوردم..."

    # say L652 pla
    old "Uhh, there's nothing wrong with that, you're just helping me... Also, I really enjoyed it a lot..."
    new "اوه، هیچ اشکالی نداره، فقط به من کمک می‌کنی... همچنین، واقعاً خیلی لذت بردم..."

    # say L654 mo1
    old "Do you really think that?  "
    new "وای، واقعاً اینطور فکر می‌کنی؟"

    # say L655 mo1
    old "Well... I haven't done that for years and I was trying to make you feel better. So, yeah, maybe there's nothing wrong with that."
    new "خب... من سال‌ها این کار رو نکرده بودم و فقط می‌خواستم تو رو خوشحالم کنم. پس بله، شاید هیچ اشکالی نداره."

    # say L657 pla
    old "Yeah, also, you're taking care of me so I can release all my repression. and I really appreciate it."
    new "بله، همچنین تو در حال مرا مراقبت می‌کنی تا من همه فشارهایم رو آزاد کنم. و خیلی از این بابت ممنونم."

    # say L659 mo1
    old "Awww, of course, honey. You always make me feel better... Now let's clean this up... And remember, don't to tell anyone."
    new "البته، عزیزم. همیشه تو مرا خوشحالم می‌کنی... حالا این رو تمیز کنیم... و به یاد داشته باش، به هیچ‌کس نگو."

    # say L661 pla
    old "Don't worry, I won't."
    new "نگران نباش، من نمی‌گم."

    # say L663 mo1
    old "That's a good boy. Let's go to bed."
    new "خوب، بچه خوبی. برو بخواب."

    # say L665 pla
    old "Ok, [mo1rel]. Good night."
    new "باشه، [mo1rel]. شب خوب."

    # say L666 mo1
    old "Good night, honey. Sleep well."
    new "شب خوبی، عزیزم. خوب بخواب."

    # say L678 mo1
    old "That movie was great!"
    new "این فیلم عالی بود!"

    # say L680 pla
    old "Yeah, it was fun..."
    new "بله، لذت بردم..."

    # say L682 mo1
    old "You know what? We could continue this upstairs."
    new "میدونی چی؟ می‌تونیم اینو به بالای پله‌ها ادامه بدیم."

    # menu L685 
    old "Hell yeah"
    new "بله، قطعاً"

    # say L687 pla
    old "Oh really?, Well what are we waiting for?"
    new "وای، واقعاً؟ خب منتظر چی هستیم؟"

    # say L688 mo1
    old "That's what I thought."
    new "این همینه فکر می‌کردم."

    # menu L692 
    old "Not tonight"
    new "امروز نه"

    # say L694 mo1
    old "Ok honey, anyway if you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "خوب عزیزم، هر جا می‌خوای فیلم دیگه‌ای ببینی، فردا به من بیا. می‌دونم با هم وقت خوبی رو می‌گذرونیم..."

    # say L698 mo1
    old "Ok, honey. Let's go to sleep."
    new "باشه، عزیزم. بیای بخواب."

    # say L702 mo1
    old "Sweet dreams, honey. Sleep well."
    new "حالم خوب باشه، عزیزم. خوب بخواب."

    # say L719 mo1
    old "Thanks for spending time with me, baby."
    new "ممنونم که وقت رو با من گذراندی، عزیزم."

    # say L721 pla
    old "You don't have to thank me [mo1rel]. I really enjoy it!"
    new "ممنون نباشی [mo1rel]. خوشحالم که اینجوری می‌گذرانیم وقت."

    # say L723 mo1
    old "I'm glad to hear that. If you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "خوشحالم که اینجوری می‌گی. اگه می‌خوای فیلم دیگه‌ای ببینیم، فردا بیا به من. می‌دونم با هم وقت خوبی رو می‌گذرونیم..."

    # say L743 mo1
    old "Looks like someone is really happy for the movie..."
    new "به نظر می‌رسه کسی خیلی خوشحاله از فیلم..."

    # say L745 mo1
    old "You know what? I want to have sex here..."
    new "میدونی چی؟ می‌خوام جنس کنم اینجا..."

    # say L747 pla
    old "... Are you sure?"
    new "مطمئنی؟"

    # say L748 mo1
    old "What is the difference, we already had sex..."
    new "تفاوتی نداره، قبلا هم جنس کردیم..."

    # say L772 mo1
    old "Good morning [pla]."
    new "صبح بخیر [pla]."

    # say L774 pla
    old "Good morning [mo1rel]."
    new "صبح بخیر [mo1rel]."

    # say L776 mo1
    old "I wanted to talk to you about yesterday ..."
    new "می‌خواستم در مورد دیروز با تو صحبت کنم..."

    # say L778 pla
    old "I- I'm really sorry... It wasn't-"
    new "من- من واقعاً متاسفم... اینطور نبود-"

    # say L780 mo1
    old "No, I want to apologize for the way I treated you ..."
    new "نه، من می‌خوام برای نحوه رفتارم با تو عذرخواهی کنم..."

    # say L782 pla
    old "You want to... Apologize?"
    new "می‌خوای... عذرخواهی کنی؟"

    # say L784 mo1
    old "Yes, I think I was very rude with you, but please understand, it was a bit shocking for me..."
    new "بله، فکر می‌کنم با تو خیلی بد رفتار کردم، اما لطفاً درک کن، برای من هم کمی شوک‌آور بود..."

    # say L788 mo1
    old "I mean, I don't want you to think that I judge you, I know you're going through a lot."
    new "من قصد ندارم که فکر کنی من تو رو سنجیده‌ام، می‌دونم تو خیلی مشکلاتی داری."

    # say L790 mo1
    old "And I know this is hard for you, so I want you to know that I'm not mad at you."
    new "و می‌دونم این برایت سخته، پس می‌خوام بدونی من بهت خیال نکردم."

    # say L793 mo1
    old "Yes, In fact I think it was some kind of my fault..."
    new "بله، در واقع فکر می‌کنم این به جزای خودم هست..."

    # say L794 pla
    old "Your fault? W- what do you mean?"
    new "خطای تو؟ چ- چی می‌خوای بگی؟"

    # say L796 mo1
    old "I think I should have helped you more."
    new "فکر می‌کنم باید بیشتر به تو کمک می‌کردم."

    # say L797 mo1
    old "I mean, [mo2] is a bit strict, she didn't want me to talk to you about, you know... Sexual things."
    new "من قصد دارم بگم که [mo2] یه جور سختگیره، نمی‌خواست با تو در مورد، میدونی... چیزهای جنسی صحبت کنم."

    # say L799 mo1
    old "And now you're a bit repressed, that's why your hormones are making you lose your mind."
    new "و حالا کمی سرکوب شده‌ای، برای همین هورمون‌هایت باعث می‌شنن روح تو رو بگیرن."

    # say L800 mo1
    old "And do things that... You shouldn't do."
    new "و چیزهایی که... نباید انجام بدی."

    # say L801 pla
    old "I- it was not my intention."
    new "من قصد نداشتم."

    # say L802 mo1
    old "I know honey... I know this can be difficult for you, but if you can't control yourself in front of your [mo1rel]... It really worries me."
    new "میدونم عزیزم... میدونم این برایت سخت میتونه باشه، ولی اگه نتونی خودت رو جلوی ز[mo1rel]ت کنترل کنی... واقاً نگران می‌شم."

    # say L803 pla
    old "I won't do it again, I promise."
    new "دیگه اینجوری نمی‌کنم، وعدهت میدم."

    # say L804 mo1
    old "Actually, what worries me is that you get to do it at school or in front of any other girl."
    new "در واقع، آنچه من را نگران می‌کند این است که تو این کار رو در مدرسه یا جلوی هر دختر دیگری انجام بدی."

    # say L805 pla
    old "W- what? I- I won't-"
    new "و- و چه؟ من- من نمی‌کنم-"

    # say L806 mo1
    old "It's not under your control, you already show me that."
    new "این تحت کنترل تو نیست، قبلا به من اینو نشون دادی."

    # say L807 pla
    old "I- I'm sorry-"
    new "من- من عذرخواهم."

    # say L808 mo1
    old "And it's my fault. I should have helped you before, now you are facing troubles because of my irresponsibility."
    new "و این اشتباه من است. باید قبلاً بهت کمک می‌کردم، حالا به خاطر عدم مسئولیت من با مشکلاتی روبرو شدی."

    # say L810 mo1
    old "And I have been thinking about it a lot and... I think I have to help you to... Release your, uhm... S- stress."
    new "و من هم خیلی فکر کردم و... فکر می‌کنم باید به تو کمک کنم تا... استرست رو، اوه... رها کنی."

    # say L811 pla
    old "Uhh, w- what do you mean?"
    new "اوه، م- منظورت چیه؟"

    # say L812 mo1
    old "Hmm you know honey... I'll help you with your... Ahem, load release."
    new "همم، می‌دونی عزیزم... من بهت کمک می‌کنم با آهوم، بارتو رها کنی."

    # say L814 pla
    old "No, [mo1rel], don't worry I can do it by myself..."
    new "نه، ز[mo1rel]، نگران نباش، من خودم می‌تونم این کار رو انجام بدم..."

    # say L815 mo1
    old "Sorry honey, but apparently you haven't done very well so far."
    new "ببخشید عزیزم، اما به نظر می‌رسد تا حالا خوب نتونستی."

    # say L817 mo1
    old "I know it won't be comfortable for any of us, but I need to make sure you get it right."
    new "میدونم برای هیچ‌کدوم از ما راحت نیست، ولی باید مطمئن شم که درست انجام میدی."

    # say L818 mo1
    old "I don't want you to keep repressing yourself and that it leads you to do worse things."
    new "من نمی‌خوام تو خودت رو فشار بدی و این باعث بشه که چیزهای بدتری انجام بدی."

    # say L819 pla
    old "Are you right this is the only way?"
    new "آیا این تنها راه است؟"

    # say L821 mo1
    old "Well, the thing is, I don't want [mo2] to realize it, that would really make things more difficult."
    new "خب، اونجوری هست که من نمی‌خوام [mo2] اینو متوجه بشه، این خیلی مسائل رو سخت‌تر می‌کنه."

    # say L822 mo1
    old "So the best way is to do it here alone and keep everything between you and me."
    new "پس بهترین راه اینه که اینجا تنها انجام بدیم و همه چیز رو بین تو و من نگه داریم."

    # say L824 mo1
    old "Please [pla] don't make it more difficult than it already is."
    new "لطفاً [pla] این رو بیشتر سخت نکن."

    # say L826 mo1
    old "I will help you with a handjo-... Hmm with a massage, to help you relax and release your... Load and that's it."
    new "من بهت کمک می‌کنم با ماساژ، تا از خودت آرام شی و آزاد شی... بارتو و این همه."

    # say L827 mo1
    old "Just think of it as some kind of sex ed class."
    new "فقط این رو مثل یه کلاس آموزش جنسی بگیر."

    # say L828 pla
    old "Sex ed class... Uhmm, alright."
    new "کلاس آموزش جنسی... اوه، خب، می‌تونم."

    # say L830 mo1
    old "Thanks honey."
    new "ممنون عزیزم."

    # say L831 mo1
    old "Alright, come and sit on the bed and leave it all to me."
    new "بیا و روی تخت بنشین و همه چیز را به من بسپار."

    # say L852 pla
    old "What the fuck is going on???"
    new "اون جوری که می‌گی، چه خبره؟؟"

    # say L872 pla
    old "What were those yells?? It's coming from the house's entrance."
    new "این صدای فریاد از چه جاییه؟ از ورودی خونه می‌آیه."

    # say L874 pla
    old "I better go check it out."
    new "بهتره برم بررسی کنم."

    # say L882 mo2
    old "I'm tired of this, I'm the only one who works in this house..."
    new "من از این خسته‌ام، من تنها کسی هستم که در این خانه کار می‌کنم..."

    # say L884 mo1
    old "But honey..."
    new "ولی عزیزم..."

    # say L886 mo2
    old "It makes no sense to keep providing for three good for nothing bums!"
    new "این معقول نیست که برای سه کسی که هیچ کاری نمی‌کنند تامین کنم!"

    # say L888 mo1
    old "But we are a family."
    new "اما ما خانواده‌ای هستیم."

    # say L890 mo2
    old "No, you are leeches who want to live at my expense."
    new "نه، شما پارازیت‌هایی هستید که می‌خواهید از خرج من زندگی کنید."

    # say L894 mo2
    old "Besides, now your drinking wine every night and getting drunk. Don't you feel ashamed?!"
    new "البته، حالا هر شب شامو می‌نوشی و مشروی می‌شوی. نمی‌تونی خجسته باشی؟"

    # say L896 mo1
    old "I'm not getting drunk..."
    new "من مشروی نمی‌شوم..."

    # say L898 mo2
    old "You know what, I'm going to the office ... There is no point in continuing to argue"
    new "می‌دونی چی، من به دفتر می‌رم... هیچ جور معنایی نداره که این بحث رو ادامه بدم"

    # say L906 pla
    old "Hi [mo1rel], what happened?"
    new "سلام ز[mo1rel]، چه اتفاقی افتاد؟"

    # say L908 mo1
    old "Hi honey, don't worry... Just a little discussion."
    new "سلام عزیزم، نگران نباش... فقط یه بحث کوچیک داشتم."

    # say L912 mo1
    old "Oh yes, I'm fine, don't worry, I'll be in my room, ok?"
    new "بله، من خوبم، نگران نباش، من به اتاقم می‌رم، خب؟"

    # say L936 pla
    old "Oh, come on, are they arguing again?"
    new "او، بیای، دوباره دارن با هم مناقشه می‌کنن؟"

    # say L938 pla
    old "I better go and make sure what's happening now."
    new "بهتر است برم و ببینم حالا چه اتفاقی افتاده."

    # say L944 mo2
    old "Seriously, were you drinking yesterday again?"
    new "seriously، دیروز دوباره نوشیدی؟"

    # say L946 mo1
    old "I'm sorry, but I was feeling bad..."
    new "متأسفم، ولی حس خوبی نداشتم..."

    # say L948 mo2
    old "You are a sick alcoholic."
    new "تو یک الکل‌گیر بیماری."

    # say L950 mo1
    old "NO!"
    new "نه!"

    # say L954 mo1
    old "I'm not an alcoholic and I'm tired of your offenses and your aggressiveness!"
    new "من الکل‌گیر نیستم و از توهایات و خشونت‌هایت خسته شدم!"

    # say L956 mo2
    old "Well, I'm tired of living with good for nothings..."
    new "خب، من خسته‌ام از زندگی با بی‌فایده‌ها..."

    # say L958 mo2
    old "Actually, I'm leaving this house, I'm not going to keep paying everything for all of you anymore."
    new "در واقع من از این خانه برمی‌آم، دیگه نمی‌خوام برای همه شما همه چیز رو بپردازم."

    # say L966 pla
    old "Uhmm, [mo1rel] are you alright?"
    new "اوه، [mo1rel] حالت خوبه؟"

    # say L968 mo1
    old "No, not really."
    new "نه، خیلی خوب نیستم."

    # say L970 pla
    old "I'm so sorry [mo1rel]"
    new "من خیلی متاسفم [mo1rel]"

    # say L972 mo1
    old "Don't worry, I think it's for the best anyway."
    new "نگران نباش، فکر کنم هر چه باشد بهتر است."

    # say L974 pla
    old "I didn't know you were having these problems."
    new "من نمی‌دونستم تو این مشکلات رو داشتی."

    # say L976 mo1
    old "Always, from the beginning of the relationship, we are very different and as much as we try..."
    new "همیشه، از آغاز رابطه، ما خیلی متفاوت بودیم و هر قدر تلاش کنیم..."

    # say L978 mo1
    old "I think we are simply not compatible."
    new "من فکر می‌کنم سادا به هم سازگار نیستیم."

    # say L980 pla
    old "Do you need anything?"
    new "نیازت به چیزی هست؟"

    # say L982 mo1
    old "No, thanks, I just want to be alone."
    new "نه، ممنون، فقط می‌خوام تنها باشم."

    # say L1008 pla
    old "I wanted to ask you again about your doctor's appointment..."
    new "می‌خواستم دوباره ازت بپرسم در مورد نوبت دکترت..."

    # say L1010 mo1
    old "Oh, I had forgotten, can you go with me?"
    new "اوه، فراموش کرده بودم، می‌تونی با من بیایی؟"

    # say L1012 pla
    old "Yes, that's why I was looking for you..."
    new "بله، همین به خاطری بود که دنبال تو بودم..."

    # say L1014 mo1
    old "Perfect! Wait for me at the entrance while I get changed and come out, okay?"
    new "عالی! در ورودی منتظرم باش تا لباسم را عوض کنم و بیرون بیایم، خوبه؟"

    # say L1016 pla
    old "Ok, I'll wait for you then..."
    new "باشه، منتظرت می‌مونم..."

    # say L1028 mo1
    old "Ok, I'm ready. Let's go to the hospital..."
    new "خوب، آماده‌ام. بیایم به بیمارستان..."

    # say L1046 mo1
    old "Hi, sweetie! What are you up to?"
    new "سلام، عزیزم! چه کاری داری؟"

    # say L1048 pla
    old "Hey, [mo1rel]. I'm good."
    new "سلام، [mo1rel]. خوبم."

    # say L1050 mo1
    old "Did you want to talk about something?"
    new "می‌خواستی در مورد چیزی صحبت کنیم؟"

    # say L1096 pla
    old "As you know, I'm preparing a speech for class."
    new "همانطور که می‌دونی، من در حال آماده‌سازی سخنرانی برای کلاس هستم."

    # say L1098 mo1
    old "Yes! I'm proud of you for studying so hard, dear!"
    new "بله! خوشحالم که به تحصیلاتت اهمیت می‌دهی، عزیزم."

    # say L1100 pla
    old "Yeah… Well, I don't want to bother anyone, so I will be studying in the garage instead of my room."
    new "بله… خب، نمی‌خوام به کسی اغراق کنم، پس به جای اتاقم در گاراژ مطالعه می‌کنم."

    # say L1102 mo1
    old "Aww, that's very considerate of you. Thank you."
    new "اوه، این خیلی لطف داری. ممنون."

    # say L1104 pla
    old "So, I will be heading to the garage to study now."
    new "پس من الان می‌روم به گاراژ تا مطالعه کنم."

    # say L1106 mo1
    old "Ok, sweetie. Do you want to talk about anything else?"
    new "باشه، عزیزم. می‌خوای در مورد چیزی دیگه صحبت کنی؟"

    # say L1117 pla
    old "Yes, I wanted to ask you again about doctor's appointment..."
    new "بله، می‌خواستم دوباره ازت بپرسم در مورد نوبت دکتر..."

    # say L1119 mo1
    old "Sure, honey. The appointment is next Thursday... Only look for me in the morning to go to the hospital, okay?"
    new "البته، عزیزم. نوبت برای هفته بعد، چهارشنبه... فقط صبح بیا به من بگو تا برویم به بیمارستان، خوب؟"

    # say L1121 pla
    old "Oh, right. Then I'll look for you then."
    new "اوه، درسته. پس همون موقع بهت می‌گردم."

    # say L1123 mo1
    old "Okay, sweetie, do you want to talk about anything else?"
    new "خوب، عزیزم، می‌خوای در مورد چیز دیگه‌ای صحبت کنی؟"

    # say L1131 mo1
    old "Sure, honey. The appointment is next Monday... Only look for me in the morning to go to the hospital, okay?"
    new "البته، عزیزم. نوبت برای هفته آینده است... فقط صبح بیای تا برویم به بیمارستان، خوبه؟"

    # say L1143 pla
    old "Yes, I wanted to ask you again about doctor appointment..."
    new "بله، می‌خواستم دوباره ازت بپرسم در مورد نوبت دکتر..."

    # say L1145 mo1
    old "It's today, Can you go with me?"
    new "امروزه، می‌تونی با من بیایی؟"

    # say L1174 mo1
    old "By the way, please remember to visit my mom, remember that next week marks a month of my father's death..."
    new "باید به مامان من بروی، هفته بعد یک ماه از مرگ پدرم می‌شه..."

    # say L1176 pla
    old "Oh, has it been a month?"
    new "اوه، یک ماه شده؟"

    # say L1178 mo1
    old "Yes, and it would be a great gesture if you could visit her, now that she is a widow, she needs some company."
    new "بله، و اگر بتونی به او برو، حالا که بیوه شده، به همراهی نیاز داره."

    # say L1180 pla
    old "Perfect, I'll go visit her..."
    new "عالی، برم می‌روم به دیدنش..."

    # say L1182 mo1
    old "Before you go, [mo2] talked to me... And, I want you to know that watching porn is perfectly normal."
    new "قبل از رفتن، [mo2] با من حرف زد... و می‌خوام بدونی که دیدن فیلم‌های سکس کاملاً عادیه."

    # say L1185 mo1
    old "You are at the age of exploring your body, stimulations and physical sensations..."
    new "تو همین حالا در سن کشف بدن، تحریک‌ها و احساسات جسمی هستی..."

    # say L1186 pla
    old "What?... I wasn't-"
    new "چه؟... من نبودم-"

    # say L1188 mo1
    old "Don't worry, honey. Nobody is judging you. You have urges, and it is important for you to release them... It is very healthy."
    new "حالم راحت باش، عزیزم. هیچ‌کس تو رو قضاوت نمی‌کنه. تو تحرک‌هایی داری و مهمه که اونا رو آزاد کنی... این خیلی سلامتی است."

    # say L1192 mo1
    old "I just want you to know that if you have any questions or need help, please ask me."
    new "می‌خوام بدونی اگه سؤالی داری یا نیاز به کمکی هست، از من بپرس."

    # say L1194 mo1
    old "I will be in the pool if you need me."
    new "اگر نیاز داشتی من در استخر هستم."

    # say L1196 pla
    old "Ok, [mo1rel]. Thanks."
    new "باشه، [mo1rel]. ممنون."

    # say L1209 mo1
    old "Alright, sweetie. I will be here if you need me..."
    new "البته، عزیزم. اگر نیازت به من بود، اینجا هستم..."

    # say L1221 mo1
    old "Would you like a-"
    new "می‌خوای یک-"

    # say L1224 mo1
    old "What the... Oh [mo2] you scared me ..."
    new "اوه ز[mo2] من را به درد آوردی..."

    # say L1225 mo1
    old "We... We were watching a movie, do you... Want to join?"
    new "ما... ما فیلم می‌دیدیم، می‌خوای... با ما هم بیایی؟"

    # say L1226 mo2
    old "No, I don't want to join, but the Wi-Fi is better here and I.. need to download some files."
    new "نه، نمی‌خوام بیوم، ولی سیگنال وای‌فای اینجا بهتره و من... باید چند فایل دانلود کنم."

    # say L1227 mo2
    old "You keep watching your stupid movie, I'll be busy."
    new "تو همچین فیلم احمقانه‌ات رو ببین، من مشغول هستم."

    # say L1228 mo1
    old "Oh, ok we won't bother you."
    new "اوه، خب ما تو را آزار نخواهیم داد."

    # say L1234 mo1
    old "{i}Lower your voice. We don't want to be caught{/i}"
    new "{i}صداتو کم کن. نمی‌خوایم بگیرن {/i}"

    # say L1240 mo1
    old "{i}That's why it gets so exciting...{/i}"
    new "{i}این به همین خاطر هیجان‌انگیز است...{/i}"

    # say L1254 pla
    old "Shit, she's not doing well. It's best to take her to her room so she can rest."
    new "شیطون، او خوب نیست. بهتره اون رو به اتاقش ببریم تا بتوانه استراحت کنه."

    # say L1260 mo1
    old "Thank you honey for bringing me here, excuse me for being like this..."
    new "ممنون عزیزم که منو اینجا آوردی، معذرت می‌خوام برای اینکه اینجوری هستم..."

    # say L1262 mo1
    old "I think I drank a little more... "
    new "فکر کنم بیشتر از حد معمول خوردم..."

    # say L1264 mo1
    old "But you know, the break up with [mo2] has affected me a little."
    new "اما میدونی، گسستن با [mo2] برایم کمی تأثیر گذاشته."

    # say L1266 pla
    old "Don't worry, it's no problem, just try to rest..."
    new "نگران نباش، مشکلی نداره، فقط سعی کن خواب ببری..."

    # say L1274 mo1
    old "Could you sleep with me?... I don't want to sleep alone in such a cold bed."
    new "می‌تونی جنب من بخوابی؟... من نمی‌خوام توی این تخت سرد تنها بخوابم."

    # say L1276 pla
    old "Yes, don't worry I'll sleep with you ..."
    new "بله، نگران نباش، من جنب تو خوابم..."

    # say L1278 mo1
    old "Oh, thank you very much, excuse me for bothering you so much..."
    new "اوه، خیلی ممنونم، معذرت می‌خواهم به خاطر اینکه شما را به همراه خودم آوردم..."

    # say L1282 mo1
    old "Could you please come to bed after turning on the light? Everything is dark."
    new "لطفاً بعد از روشن کردن نور به بیت بیا، همه جا تاریکه."

    # say L1290 mo1
    old "Thank you so much for all your support, I really appreciate it,"
    new "ممنونم از همه حمایت‌هایت، خیلی ازش قدردانی می‌کنم،"

    # say L1292 mo1
    old "This break up has been very hard..."
    new "این شکست خانوادگی برایم خیلی سخت بوده..."

    # say L1294 mo1
    old "But you've been there for me..."
    new "ولی تو همیشه برای من اینجا بودی..."

    # say L1296 mo1
    old "You are so handsome, did you know?"
    new "تو خیلی جذابی، می‌دونستی؟"

    # say L1298 mo1
    old "You've made me feel things I haven't felt in a long time..."
    new "تو مرا احساساتی را تجربه کردن داده‌ای که طولانی‌زمانی نداشتم..."

    # say L1300 mo1
    old "The last time I was with a man was so many years ago..."
    new "آخرین باری که با مردی هم بودم از آن زمان خیلی طول کشیده..."

    # say L1304 mo1
    old "But, he wasn't as big as you."
    new "اما او به اندازه تو بزرگ نبود."

    # say L1308 mo1
    old "Look at this size, I think if I had met a man with something like that..."
    new "ببین این اندازه، فکر می‌کنم اگر با مردی با چیزی مثل این آشنا شده بودم..."

    # say L1309 mo1
    old "Probably never would have been with a woman."
    new "احتمالاً هرگز با زنی همراه نشدم."

    # say L1310 mo1
    old "You have been so good to me."
    new "شما برای من خیلی خوب بودید."

    # say L1311 mo1
    old "I just want to reward you a little for that ..."
    new "من فقط می‌خوام برای اون کمی جایزه بدم بهت..."

    # say L1312 mo1
    old "You know what, get on the edge of the bed, I will give you a good gift."
    new "دیت رو به لبه تخت بیا، هدیه خوبی بهت می‌دم."

    # say L1333 pla
    old "(Wow...)"
    new "(واو...)"

    # say L1334 pla
    old "(Sorry but I have to do it...)"
    new "(ببخه، ولی باید اینجوری بکنم...)"

    # say L1336 mo1
    old "Hi honey..."
    new "سلام عزیزم..."

    # say L1339 mo1
    old "Wow, what are you doing?"
    new "واو، تو چه کاری انجام می‌دی؟"

    # say L1342 mo1
    old "We shouldn't do it here honey... Your [sisrel] could caught us."
    new "ما نباید اینجا این کار رو بکنیم عزیزم... ممکنه [sisrel] ما رو ببینه."

    # say L1362 mo1
    old "Oh honey, do you need me?"
    new "اوه عزیزم، آیا نیازی به من داری؟"

    # say L1364 pla
    old "No, I was just walking around."
    new "نه، فقط داشتم دور می‌چرخیدم."

    # say L1366 mo1
    old "Ok, Ill be here if you need me."
    new "باشه، اگه نیازت به من بود، من اینجا هستم."

    # say L1377 mo1
    old "Wow that was pretty intense."
    new "واو، این خیلی شدید بود."

    # say L1381 mo1
    old "Next time, just make sure nobody is at home, ok?"
    new "بعداً فقط مطمئن شو کسی در خونه نباشه، خوب؟"


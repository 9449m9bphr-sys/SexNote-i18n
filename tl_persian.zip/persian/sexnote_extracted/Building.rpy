# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Building.rpy
translate persian strings:

    # say L96 pla
    old "Uhh... Yes..."
    new "اوه... بله..."

    # say L99 pla
    old "Ohh, alright, don't worry I will come tomorrow. Thank you."
    new "اوه، خوب، نگران نباش، فردا می‌آیم. ممنون."

    # say L132 pla
    old "Good morning Barbie..."
    new "صبح بخیر باربی..."

    # say L141 pla
    old "Good afternoon Barbie..."
    new "سلام باربی..."

    # say L145 pla
    old "I'm [pla]... I was wondering if I can find a Therapist in this business center."
    new "من [pla]... داشتم فکر می‌کردم آیا می‌تونم یه روان‌شناس رو توی این مرکز تجاری پیدا کنم."

    # say L150 pla
    old "Wow great, Can I go to talk with her?"
    new "واو عالی، می‌تونم باهاش صحبت کنم؟"

    # say L155 pla
    old "Hmmm, actually is for a friend of mine, but thanks that's all that I needed it."
    new "Hmm، در واقع برای یه دوست من هست، ولی ممنون، این همه که لازم داشتم."

    # say L160 pla
    old "Thank you..."
    new "ممنون..."

    # say L164 pla
    old "Now I can talk with Mrs. Jade."
    new "الان می‌تونم با خانم جید صحبت کنم."

    # say L196 pla
    old "I was wondering if Dr. Johnson is in her office."
    new "می‌خواستم بدونم آیا دکتر جانسون در دفترش هست."

    # say L200 pla
    old "Great, thanks"
    new "عالی، ممنون"

    # say L217 joh
    old "Hey [pla], did you make an appointment?"
    new "اوه ز[pla]، شما رزرو کرده‌اید؟"

    # say L218 pla
    old "Oh, no, I'm sorry, I just-"
    new "اوه، نه، معذرت، من فقط-"

    # say L219 joh
    old "Don't worry if you need anything just let me know."
    new "اگر نیازی به چیزی داری فقط به من بگو."

    # say L220 pla
    old "Ok, Thanks."
    new "باشه، ممنون."

    # say L248 pla
    old "No, no, sorry I was just looking for Hinn. I have to go."
    new "نه، نه، عذرخواهم، فقط دنبال هین بودم. باید برسم."

    # say L255 joh
    old "Hi [pla], welcome back."
    new "سلام ز[pla]، خوشحالم که برگشته‌ای."

    # say L256 pla
    old "Hi doctor Johnson, I'm here because you mentioned we could repeat some lessons..."
    new "دکتر جانسون، سلام. من اینجا هستم چون شما گفتید می‌تونیم بعضی دروس رو دوباره تکرار کنیم..."

    # say L257 joh
    old "That's great! So, what lesson you want to practice?"
    new "عالی است! پس درسی که می‌خوای تمرین کنی چیه؟"

    # menu L262 
    old "Lesson 1"
    new "درس اول"

    # say L264 joh
    old "Great choice. Let's go to the  practice room..."
    new "خوب انتخاب کردی. بیایم به اتاق تمرین برویم..."

    # say L277 joh
    old "Just like that, try to keep it wet, and slowly move a bit faster..."
    new "مثل این، سعی کن مرطوبش بی‌خیال باشی و به تدریج سرعتت رو افزایش بدی..."

    # say L278 joh
    old "Keep doing it like that... Ahh"
    new "به همین شکل ادامه بده... آه"

    # say L279 pla
    old "O- ok"
    new "ب- خوب"

    # menu L283 
    old "Lesson 2"
    new "درس 2"

    # say L305 joh
    old "Let's do it!"
    new "بیایید این کار رو انجام بدیم!"

    # menu L314 
    old "Lesson 3"
    new "درس ۳"

    # menu L332 
    old "Lesson 4"
    new "درس ۴"

    # say L358 joh
    old "You did it wonderful, I'm glad to have you here again..."
    new "شما عالی انجام دادید، خوشحالم که دوباره اینجا هستید..."

    # say L359 pla
    old "Definitely, I will pass by more often."
    new "حتماً، بیشتر اینجا می‌آیم."

    # say L360 joh
    old "It would be the best thing to do, we can enjoy a lot."
    new "این بهترین کار است، می‌توانیم خیلی لذت ببریم."

    # say L361 pla
    old "I don't doubt it."
    new "من به آن شک ندارم."

    # say L362 joh
    old "Hope to see you soon."
    new "امیدوارم زود به یادت بیام."

    # say L363 pla
    old "Thank you, have a great day."
    new "ممنون، روز خوبی داشته باشید."

    # say L364 joh
    old "Bye bye!"
    new "خداحافظ!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/OliStory.rpy
translate persian strings:

    # say L8 oli
    old "Did you see my notes report?!"
    new "دیدی گزارش یادداشت‌هام؟!"

    # say L12 oli
    old "You're a fucking moron!"
    new "تو یه احمق خری هستی!"

    # say L14 oli
    old "{i}'Oh yeah, I know all the topics, I'll for sure help you get better...'{/i}"
    new "{i} البته، همه موضوعات رو می‌دونم، حتماً بهت کمک می‌کنم تا بهتر شی... {/i}"

    # say L16 oli
    old "{b}*Sigh*{/b} Honestly..."
    new "{b}*تنفس*{/b} صداقتن..."

    # say L23 mik
    old "B- but, I- I really did teach you what was needed for the exam... I mean, I did well..."
    new "ولی، من واقعاً به تو آموختم همه چیزی که برای امتحان لازم بود... منظورم اینه که خوب کار کردم..."

    # say L24 oli
    old "Are you suggesting that I'm dumb? Or that it was my fault?"
    new "آیا می‌خوای بگی من خفه هستم؟ یا اینکه اشتباه من بود؟"

    # say L25 mik
    old "No, no, what I'm saying is that..."
    new "نه، نه، من قصد دارم بگم که..."

    # say L44 oli
    old "You assured me that if I spent time with you and let you do 'that' to me..."
    new "تو مطمئن کردی اگر وقت رو با تو بگذونم و بگذارم تو اون کار رو به من بکنی..."

    # say L47 oli
    old "... You were going to help me pass the exams."
    new "... تو قول دادی که اگر وقت رو با تو بگذونم و بهت اجازه بدم اون کار رو برایم انجام بدی، به من کمک کنی تا امتحان‌ها رو بگذونم."

    # say L48 oli
    old "But I ended up failing anyway!"
    new "ولی باز هم نمره نگرفتم!"

    # say L51 oli
    old "If you didn't actually understand the subjects, you could've just told me that..."
    new "اگه واقعاً درس‌ها رو نفهمیدی، می‌تونستی از اول به من بگی..."

    # say L52 oli
    old "That way I wouldn't have wasted my time with you."
    new "آنطور نبودم وقت من رو با تو ضایع می‌کردم."

    # say L53 mik
    old "But I don't know what happened, I explained it to you just like [pla] did with m-..."
    new "ولی من نمی‌دونم چه اتفاقی افتاد، من همونطور که [pla] با تو کرد، به تو توضیح دادم..."

    # say L56 oli
    old "What? [pla]? What does he have to do with all this?"
    new "چه کاری؟ [pla]؟ این همه چیز با او چه ربطی داره؟"

    # say L58 mik
    old "N- nothing, nothing, I meant that I also helped him and he had a good result on the exam..."
    new "N- هیچی، هیچی، منظورم این بود که من هم بهش کمک کردم و او نتیجه خوبی در امتحان گرفت..."

    # say L60 mik
    old "Maybe you just didn't understand the topics I explained well."
    new "شاید تو فقط موضوعاتی که من توضیح دادم رو خوب متوجه نشده‌ای."

    # say L79 pla
    old "Hey man... That sounded rough. What's going on?"
    new "دستت درد نکنه مرد... اینجوری خوب نیومده. چه خبره؟"

    # say L81 mik
    old "Apparently, she did really poorly on the last set of exams we took."
    new "به نظر می‌رسه توی امتحانات آخر خیلی بد عمل کرده."

    # say L83 mik
    old "And now she's blaming me!"
    new "و حالا همه گناه‌ها رو بر من می‌گذونه!"

    # say L84 mik
    old "Like it's my fault..."
    new "مثل اینکه من گناه کردم..."

    # say L86 pla
    old "Well, you did promise her you'd help her with her exams."
    new "خب، تو قول دادی که بهش در مورد امتحان‌اش کمک می‌کنی."

    # say L87 pla
    old "But you didn't really follow through..."
    new "ولی تو واقعاً پشت سر نگه نداشتی..."

    # say L89 mik
    old "W- well, t- that's just because..."
    new "ب- ه، فقط چون..."

    # say L91 mik
    old "I don't know, man, I really helped her!"
    new "من نمی‌دونم، بابا، من واقعاً بهش کمک کردم!"

    # say L92 mik
    old "I- I mean, I even got good grades, man!"
    new "من می‌گم، من حتی نمره خوبی گرفتم، بابا!"

    # say L93 pla
    old "Well, yeah, but it doesn't matter how well you did."
    new "بله، ولی مهم نیست چقدر خوب کار کردی."

    # say L94 pla
    old "What matters is that she didn't do well."
    new "مهم اینه که او خوب نکرد."

    # say L96 pla
    old "I think you just didn't know how to explain the subjects to her."
    new "من فکر می‌کنم تو فقط نتونستی مطالب رو به درستی برایش توضیح بدی."

    # say L97 mik
    old "Alright! You don't have to repeat what she said!"
    new "باشه! نیازی نیست تکرار کنی چیزی که اون گفت."

    # say L99 mik
    old "Besides, I don't think you get to say anything to me, this is your fault after all."
    new "البته، من فکر نمی‌کنم تو حق داشتی به من هیچ چیزی بگی، این اصلاً خطای تو بود."

    # say L100 pla
    old "Excuse me? What's that supposed to mean?"
    new "ببخشید؟ این چه معنی داره؟"

    # say L101 mik
    old "What I said! You were supposed to explain the subjects to me so that I could help Olivia!"
    new "این همین! تو بودی که باید موضوعات رو به من توضیح بدی تا بتونم به اولیویا کمک کنم!"

    # say L103 mik
    old "But look at the results she got."
    new "اما نتایجش رو ببین."

    # say L105 pla
    old "That has nothing to do with me!"
    new "این به من هیچ ربطی نداره!"

    # say L106 pla
    old "If she didn't learn anything, it's just because you're such a shit teacher!"
    new "اگه هیچ چیز نیومده، فقط چون تو یه معلم خیلی بدی هستی!"

    # say L108 pla
    old "Maybe you should've taught her properly instead of spending your time staring at her tits."
    new "شاید باید به جای اینکه وقتت رو صرف دیدن سینه‌اش می‌کردی، به درستی بهش آموزش می‌دادی."

    # say L110 mik
    old "Yeah well, whatever the reason is, she's super angry with me now."
    new "بله، هر همین دلیلی الان خیلی به من خشم داره."

    # say L112 mik
    old "If she fails the coming exams, that's going to really suck, man."
    new "اگه در امتحانات بعدی باز موفق نشه، واقعاً بد است، بچه."

    # say L113 pla
    old "Well, it would be bad, but she'll have other chances to pass."
    new "البته بد خواهد بود، اما فرصت‌های دیگری هم برای او وجود دارد."

    # say L115 mik
    old "What? That's not what I mean, dude."
    new "چه؟ من قصد این نیست که بگم، داداش."

    # say L117 mik
    old "If she fails, she'll just blame me, and I won't be able to move forward with her."
    new "اگر او نمره نده، فقط من رو محکوم خواهد کرد و من نمی‌تونم با او جلو بردم."

    # say L119 mik
    old "I'm so close to hooking up with her, dude, so close."
    new "من خیلی نزدیک هستم تا باهاش رابطه داشته باشم، داداش، خیلی نزدیک."

    # say L120 mik
    old "She was just about to let me hit it, and now this."
    new "او همین جا بود می‌خواست اجازه بدهم بزنم، و حالا این."

    # say L121 pla
    old "... Sure, dude."
    new "مطمئنی، دوستا."

    # say L126 pla
    old "Hey, come on, let's go to class."
    new "بیا، برویم به کلاس."

    # say L127 pla
    old "You can keep worrying about this later."
    new "می‌تونی بعداً نگران این باشی."

    # say L129 mik
    old "Yeah... Okay."
    new "بله... خوب."

    # say L160 oli
    old "Hey [pla]! Wait!"
    new "هی ز[pla]! صبر کن!"

    # say L171 pla
    old "Uh, yeah? Do you need something?"
    new "آره؟ نیازی به چی داری؟"

    # say L174 oli
    old "Yeah, I need to talk to you about something."
    new "بله، باید با تو در مورد چیزی صحبت کنم."

    # say L175 pla
    old "Uh... Alright, what is it?"
    new "اوه... خب، چیه؟"

    # say L177 oli
    old "Well, as you probably already know."
    new "خب، احتمالاً هم خودت دیده‌ای."

    # say L179 oli
    old "I've been having some problems with my grades lately."
    new "akhirاً، نمره‌هایم مشکل داره."

    # say L180 pla
    old "Hmph, I mean... I haven't really paid attention to what you've been doing or anything..."
    new "همف، منظورم... من واقعاً به کاری که می‌کنی توجه نکردم یا هیچ..."

    # say L182 oli
    old "Oh please, don't pretend you haven't talked with that dumbass Mike."
    new "لطفاً، نباید بازی بزنی که با آن احمق مایک صحبت نکرده‌ای."

    # say L183 oli
    old "I know he told you about him giving me lessons in the subjects I'm failing, so don't play dumb."
    new "می‌دونم مایک بهت گفت که درس‌هایی که نمره‌ام ضعیفه رو به من می‌ده، پس نباید بازی بزنی."

    # say L185 pla
    old "Well, he did mention something about that."
    new "خب، او در مورد اون یه چیزی گفت."

    # say L186 pla
    old "But what about it?"
    new "ولی در موردش چه؟"

    # say L188 oli
    old "The thing is, I haven't really learned much of anything."
    new "البته، هیچ چیز خاصی نیومده."

    # say L189 oli
    old "Because he's so fucking bad at teaching!"
    new "چون او خیلی بد در تدریس هست!"

    # say L191 oli
    old "But on the last exams, I did notice his grades got better."
    new "ولی در آخرین امتحانات متوجه شدم نمره‌اش بهتر شده."

    # say L193 oli
    old "I thought that was strange, very strange."
    new "فکر کردم عجیب است، خیلی عجیب."

    # say L195 oli
    old "While spending time with him, I realized he's not the brightest guy."
    new "در زمان معاونت باش، متوجه شدم که او خیلی هوشمند نیست."

    # say L197 oli
    old "Actually, he's a fucking idiot!"
    new "در واقع، او یه احمق خرده است!"

    # say L199 pla
    old "Okay, okay, but what does this have to do with me?"
    new "باشه، باشه، اما این به من چه ربطی داره؟"

    # say L201 oli
    old "As I told you, spending time with your friend made me realize he's a fucking idiot."
    new "همونطور که به تو گفتم، وقتی با دوستت زمان می‌گذروندم متوجه شدم که اون یه احمق خرده است."

    # say L203 oli
    old "It just didn't make sense to me that he would suddenly make such an improvement in his grades."
    new "من متوجه نشدم چطور به ناگهان نمره‌اش بهتر شد."

    # say L205 oli
    old "So, I met him under the pretense that it was a date."
    new "پس، من با او ملاقات کردم با حجت اینکه یه رendezvous بود."

    # say L207 oli
    old "And I pushed him until he spilled the beans about how he'd suddenly managed to get good grades in the exams."
    new "و من او رو تا جایی فشار دادم که درباره اینکه چطور به نمره‌های خوبی رسیده، حقیقت رو بگه."

    # say L209 oli
    old "After a while, he confessed that he wasn't any good at studying."
    new "بعد از یکی، پشیمان شد و گفت که خوب در مطالعه نبود."

    # say L211 oli
    old "But that it was thanks to YOU that he was able to get better grades."
    new "ولی بخاطر تو بود که او می‌تونست نمره‌های بهتری بگیره."

    # say L212 pla
    old "T- that's what he told you?"
    new "می‌گه اونجوری؟"

    # say L213 oli
    old "He did! And I should've known from the start that his grades didn't get better because of him!"
    new "اونجوری! و از اول باید می‌دونستم که نمره‌اش بهتر نشده به خاطر خودش!"

    # say L215 oli
    old "But anyway, that's not what I care about."
    new "ولی هر حال، این جوری که من نگران هستم نیست."

    # say L217 oli
    old "Because I'm still stuck with my bad grades."
    new "چون هنوز من با نمره‌های بد خودم گیر دارم."

    # say L219 oli
    old "I got to thinking about it."
    new "من فکر کردم در موردش."

    # say L225 oli
    old "Well, if you were able to teach that dumbass Mike enough to get good scores on the exams."
    new "خب، اگر بتونی آن دماغ خالی مایک رو به اندازه‌ای یاد بده که در امتحانات نمره خوبی بگیره."

    # say L227 oli
    old "You should be more than capable of bringing me to the top of the class."
    new "باید قطعاً بتونی من رو بهترین دانشجوی کلاس تبدیل کنی."

    # say L229 pla
    old "Yeah, I mean, thanks for the compliment."
    new "بله، منظورم همینه، ممنون از تحسینت."

    # say L231 pla
    old "But, why would I do that?"
    new "ولی، چرا باید این کار رو بکنم؟"

    # say L235 pla
    old "In case you don't remember, every time you and Ruby are around."
    new "در صورتی که نمی‌تونی به یاد بیاری، هر بار که تو و رووبی توی اینجا هستید."

    # say L236 pla
    old "You attack and bully my friends and me. The only thing you know how to do is be rude to us."
    new "تو همیشه به من و دوستایم حمله می‌کنی و ما رو تهدید می‌کنی. تنها چیزی که می‌دونی اینه که به ما بد رفتاری کنی."

    # say L238 pla
    old "Especially towards Belle and Hinn."
    new "به خصوص به سمت بل و هین."

    # say L240 pla
    old "So no, I think I'll pass."
    new "پس نه، فکر می‌کنم از این بگذرم."

    # say L245 oli
    old "So that's how it is... Either way, you HAVE to help me whether you like it or not."
    new "پس اینجوری هست... هر طوری، باید به من کمک کنی، بخواهی یا نخواهی."

    # say L247 pla
    old "And why would that be?"
    new "و چرا باید اینجوری باشه؟"

    # say L249 oli
    old "I'll tell you why."
    new "من بهت می‌گم چرا."

    # say L253 oli
    old "You better help me, or I'll spill what I know."
    new "باید به من کمک کنی، در غیر این صورت همه می‌شنوند آنچه می‌دونم."

    # say L254 oli
    old "And everyone will know just what kind of guy you are and the stuff you’re up to."
    new "و همه خواهند دانست چه نوع مردی هستی و چه کارهایی انجام می‌دهی."

    # say L265 pla
    old "But I want to make something clear."
    new "ولی من می‌خوام یه چیز رو مشخص کنم."

    # say L267 pla
    old "If I do this, you can't bring it up ever again, no matter what."
    new "اگر اینو انجام بدم، نمی‌تونی هیچ وقت دوباره بهش اشاره کنی، بی‌تفکیر."

    # say L269 pla
    old "SO, after I'm done helping you, you can't tell anyone about it!"
    new "پس، بعد از اینکه به تو کمک کردم، نمی‌تونی به هیچ کس در موردش حرف بزنی!"

    # say L271 pla
    old "Are we clear?"
    new "آیا روشن است؟"

    # say L272 oli
    old "Sure, I don't care about you or what you're doing."
    new "بله، من نمی‌خوام از تو یا اونی که می‌کنی خبر داشته باشم."

    # say L273 oli
    old "So I won't tell anyone."
    new "پس من به هیچ‌کس نمی‌گم."

    # say L275 oli
    old "But that's only if I do well on the exams."
    new "ولی این فقط اگر در امتحان‌ها خوب نمره بگیرم."

    # say L277 oli
    old "So you better outdo Mike, for your own sake."
    new "پس باید از مایک بهتر عمل کنی، برای خودت."

    # say L280 pla
    old "Hmph, sure."
    new "هم، البته."

    # say L282 pla
    old "So... Should I go to your house?"
    new "پس... من باید به خونه تو برم؟"

    # say L283 oli
    old "No, today's not a good day."
    new "نه، امروز روز خوبی نیست."

    # say L285 oli
    old "There are a couple of things I have to deal with at home."
    new "چند کاری هست که باید در خونه انجام بدم."

    # say L286 oli
    old "Just keep your schedule open for now, and I'll let you know when we can start."
    new "برای حالا برنامه‌تو باز هات، بعداً وقتی می‌تونیم شروع کنیم خبرت می‌دم."

    # say L287 pla
    old "Hmm, alright..."
    new "Hmm، خوب..."

    # say L289 oli
    old "Ok, see you later then. Bye."
    new "باشه، بعداً می‌بینیم. خداحافظ."

    # say L297 pla
    old "{b}*Sigh*{/b} This is something I wasn't expecting."
    new "{b}*تنفر*{/b} این چیزی بود که منتظرش نبودم."

    # say L298 pla
    old "What a fucking situation this is..."
    new "این وضعیت خیلی خرابه..."

    # say L301 pla
    old "{b}*Sigh*{/b} I guess I'll head home."
    new "{b}*تنفر*{/b} باید به خونه برگرم."

    # say L313 pla
    old "Oh, h- hi dude, what's up?"
    new "اوه، سلام داداش، چه خبر؟"

    # say L315 mik
    old "I'm alright, but hey, don't dodge the question."
    new "من خوبم، ولی برو، سؤال رو پاسخ بدی."

    # say L317 mik
    old "What were you doing talking to my girl?"
    new "تو چه کاری با دختر من داشتی؟"

    # say L319 mik
    old "Are you trying to snatch her from me?"
    new "می‌خوای از من دستش ببری؟"

    # say L320 pla
    old "{i}(Snatch her from him? So... He still thinks he has a chance with her? Is he serious?){/i}"
    new "{i}(از او پیش من برمی‌آید؟ پس... هنوز فکر می‌کنه شانسی باهاش داره؟ جدیه؟){/i}"

    # say L321 pla
    old "It's not what you think, dude. She was just asking me for my notes from class."
    new "این همچین چیزی نیست، داداش. فقط از من نوت‌های کلاس رو می‌خواست."

    # say L324 pla
    old "Well, I think she just wants to do some extra studying, and she asked for my notes."
    new "خوب، فکر کنم فقط می‌خواسته مطالعه بیشتر کنه و از من نوت‌هام رو خواست."

    # say L326 mik
    old "And why your notes? She could've asked for mine..."
    new "و چرا نوت‌های تو؟ می‌تونست از من بپرسه..."

    # say L327 pla
    old "Your notes? Do you even have any notes?"
    new "نوتات تو؟ هیچ نوتی هم نداری؟"

    # say L329 pla
    old "Did you even bring a notebook today?"
    new "امروز دفترچه آوردی؟"

    # say L331 mik
    old "Well, I- I didn't."
    new "خب، من- من نه."

    # say L332 mik
    old "I understand, dude, but still, I hope you're not thinking of using this to take my girl away from me!"
    new "دست کم، برو تو، اما هنوز امیدوارم نمی‌خوایی با این کار دختر من رو از من ببری!"

    # say L333 pla
    old "Don't worry, dude..."
    new "دستت درد نکنه، داداش..."

    # say L334 pla
    old "I assure you that's not on my mind."
    new "مطمئن باش این جوری چیزی تو ذهنم نیست."

    # say L336 mik
    old "Alright, I'll believe you."
    new "باشه، می‌تونم بیورم."

    # say L337 mik
    old "We're pretty close, you know?"
    new "ما خیلی نزدیک هستیم، می‌دونی؟"

    # say L338 mik
    old "In no time she'll be mine, don't doubt it."
    new "به زودی مال من می‌شه، شک نکن."

    # say L339 pla
    old "Sure dude, no doubt..."
    new "بله دوست من، هیچ شکی..."

    # say L345 pla
    old "Anyway, I have to go home now, are you leaving too?"
    new "باید برم خونه، تو هم می‌روی؟"

    # say L347 mik
    old "Yeah sure, let's go."
    new "بله حتماً، برویم."

    # say L375 pla
    old "Oh, damn, I'm really late. Has the class already ended?"
    new "اوه، لعنتی، واقعاً دیر شدم. آیا کلاس قبلاً تمام شده؟"

    # say L395 rub
    old "Oh, look who decided to show up. Class ended a while ago, dumbass."
    new "او، نگاه کن کیم رسید. کلاس از همین جا خاتمه یافته، احمق."

    # say L396 pla
    old "Oh crap, I totally lost track of time..."
    new "اوه، خداحافظی، کاملاً زمان رو از دست دادم..."

    # say L397 rub
    old "Really? I hadn't noticed. It's not like anyone wants to see your ugly face around here."
    new "وای، هنوز متوجه نشده‌ی؟ مثل این نیست که کسی خوشحال باشه که چهره‌ی ناخوشایندتو ببینه."

    # say L398 pla
    old "{b}*Sigh*{/b} Really? Do you want to do this now?"
    new "{b}*تنفر*{/b} واقعاً؟ الان می‌خوای اینجوری باهام صحبت کنی؟"

    # say L399 rub
    old "What? Not feeling brave without your little friends around?"
    new "چه کاری؟ بدون دوستات کوچک جرات نمی‌آیی؟"

    # say L401 pla
    old "You know? I don't have time to deal with you right now."
    new "دیویدی، الان وقت من برای تو نیست."

    # say L411 rub
    old "Can you believe that loser?"
    new "می‌تونی باور کنی اون ناکار؟"

    # say L412 oli
    old "Yeah... What an idiot."
    new "بله... چه احمقی."

    # say L413 oli
    old "Hey, listen, I think we'll have to cancel our plans for today."
    new "بله، ولی برات بگم، فکر کنم باید برنامه‌هایمون برای امروز رو لغو کنیم."

    # say L416 rub
    old "I thought you wanted to meet those cute guys today."
    new "فکر کنم تو می‌خواستی اون دستا دوستای لطیف رو امروز ببینی."

    # say L418 oli
    old "I do! I really do."
    new "من همینجوری می‌خوام! واقعاً می‌خوام."

    # say L419 oli
    old "But I just remembered my mom needs me to help her with some stuff at home."
    new "ولی به یاد آوردم مامان می‌خواد کمکش کنم با چیزایی تو خونه."

    # say L420 oli
    old "So I have to go home early."
    new "پس باید زودتر به خونه برگردم."

    # say L422 rub
    old "Hmm, alright, I guess that's okay."
    new "خوب، فکر کنم همین جوری هم می‌تونه باشه."

    # say L423 rub
    old "I guess I'll be hanging out with the guys by myself."
    new "با پسران هم خواهم موند."

    # say L424 oli
    old "Sure, but next time I'll definitely be going out with you guys."
    new "البته، ولی بعداً حتماً با شما هم می‌رویم."

    # say L426 rub
    old "Alright, I guess that's fine."
    new "البته، فکر کنم همین خوبه."

    # say L446 pla
    old "Yeah?"
    new "آره؟"

    # say L448 oli
    old "Listen, I was thinking today could be a good day for you to come over."
    new "بله، فکر کردم امروز می‌تونی بیاد."

    # say L449 oli
    old "So we can start studying."
    new "پس می‌تونیم شروع به مطالعه کنیم."

    # say L450 pla
    old "W- what... Now?"
    new "و- وای... حالا؟"

    # say L452 oli
    old "Yes, why? I told you to clear your schedule."
    new "بله، چرا؟ من به تو گفتم برنامه‌تو خالی کنی."

    # say L453 pla
    old "No, no, you just caught me off guard."
    new "نه، نه، فقط شوک شدم."

    # say L454 oli
    old "Well, you don't have to come if you don't want to."
    new "خب، اگر نمی‌خوای بیایی، نمی‌آیی."

    # say L456 oli
    old "That is, if you don't care about everyone knowing you're fucking Mike's mom."
    new "یعنی اگر نمی‌خوای همه بدونن که تو با مامان مایک سکس می‌کنی."

    # say L457 pla
    old "{i}(Damn... She's got some attitude.){/i}"
    new "{i}(شیطون... این دختر خیلی جرات داره.){/i}"

    # say L458 pla
    old "{b}*Sigh*{/b} Alright, let's go to your house."
    new "{b}*تنفر*{/b} خب، بیایم به خونه تو بریم."

    # say L481 oli
    old "Oh, m- mom, you're here."
    new "اوه، م- مامان، تو اینجا هستی."

    # say L483 oli
    old "I- I thought you were going to be out this afternoon."
    new "فکر می‌کردم امروز بیرون باشی."

    # say L484 vee
    old "That was the plan, but the appointment got canceled, so I just came back home."
    new "این برنامه بود، اما نوبت ملاقات لغو شد، پس فقط برگشتم خانه."

    # say L486 vee
    old "But anyway honey, who's your friend here? Aren't you going to introduce me to him?"
    new "ولی هر جا، عزیزم، این دوستت کیه؟ نمی‌خوای به منش رسم کنی؟"

    # say L488 oli
    old "Well... Yeah."
    new "خب... بله."

    # say L489 oli
    old "His name is [pla], he's a friend from school."
    new "اسمش [pla] هست، دوستی از مدرسه."

    # say L494 oli
    old "[pla], this is my mother, her name's Priya."
    new "[pla]، این مادرم هست، اسمش پریا."

    # say L498 pla
    old "Hello Mrs. Priya, nice to meet you."
    new "سلام خانم پریا، خوشحالم که با شما آشنا شدم."

    # say L500 vee
    old "Nice to meet you too, [pla]."
    new "خوشحالم که شما را هم می‌شناسم، [pla]."

    # say L502 oli
    old "[pla]'s going to help me study some topics for school."
    new "[pla] می‌خواد به من کمک کنه تا مبحث‌هایی رو برای مدرسه بیانم."

    # say L504 oli
    old "You know, some exams are coming up, and I want to do well."
    new "می‌دونی، امتحان‌ها دارن به سر می‌بیاد و من می‌خوام خوب بزنم."

    # say L507 oli
    old "And [pla] here is a great student. He always gets top grades."
    new "و [pla] اینجا یه دانش‌آموز عالیه. همیشه نمره‌های بالایی می‌گیره."

    # say L509 oli
    old "So I asked him to help me."
    new "پس ازش خواستم کمکم کنه."

    # say L510 vee
    old "Oh, that's so good to hear, honey!"
    new "اوه، خوشحالم که اینجوری شد، حلو!"

    # say L513 vee
    old "I'm so glad you're finally taking your studies seriously."
    new "خوشحالم که در نهایت به مطالعاتت جدی می‌شی."

    # say L514 vee
    old "Your father's going to be very pleased if you do well in school, you know that."
    new "پدرت اگر در مدرسه خوب عمل کنی، خوشحال می‌شه، می‌دونی."

    # say L517 oli
    old "Yeah, yeah, I know what he wants..."
    new "بله، بله، می‌دونم چی می‌خواد..."

    # say L519 vee
    old "Honey, don't take that attitude."
    new "حبیبی، این نگرش رو نگیر."

    # say L522 vee
    old "I know your father can be hard to deal with sometimes."
    new "می‌دونم پدرت گاهی سخت می‌تونه باشه."

    # say L525 vee
    old "But you have to understand that he just wants what's best for you."
    new "اما باید فهمیدی که او فقط می‌خواهد بهترین چیز برایت باشه."

    # say L527 vee
    old "As do I."
    new "من هم همینطور."

    # say L529 vee
    old "So, I'm very happy to see you making an effort to improve your grades."
    new "پس خوشحالم که می‌بینم تلاش می‌کنی نمراتت رو بهتر کنی."

    # say L530 oli
    old "Yeah... Thank you."
    new "بله... ممنون."

    # say L535 oli
    old "Hey mom, [pla] and I are going to study in my room, alright?"
    new "مامان، من و [pla] می‌خوایم تو اتوممن بیاییم و مطالعه کنیم، خوبه؟"

    # say L537 vee
    old "Sure thing, sweetie."
    new "بله، حلوایی."

    # say L550 oli
    old "I'm sorry you had to see that."
    new "متاسفم که این را دیدی."

    # say L552 oli
    old "I wasn't expecting my mom to be here."
    new "من منتظر نبودم مامانم اینجا باشه."

    # say L554 pla
    old "It's okay."
    new "خوبه، نگران نباش."

    # say L556 pla
    old "You don't have to apologize."
    new "تعریف نکنی."

    # say L559 oli
    old "Anyway, I guess it's a good thing she met you right away."
    new "البته، به نظر می‌رسه خوشحالم که از اول با تو آشنا شده."

    # say L561 oli
    old "That will make things easier in the future."
    new "این به آینده کمک خواهد کرد."

    # say L564 oli
    old "So, should we get to it?"
    new "پس باید شروع کنیم؟"

    # say L574 pla
    old "Okay, let's start with this topic."
    new "باشه، بیاین از این موضوع شروع کنیم."

    # say L575 pla
    old "And we'll work our way to the others. Alright?"
    new "و به سایرین هم خواهیم رسید. خوبه؟"

    # say L577 oli
    old "Uhh... Sure, whatever you say."
    new "اوه... البته، هر چه می‌گی."

    # say L585 pla
    old "See? This is the right way to prove that result."
    new "ببین؟ این راه درسته برای اثبات اون نتیجه."

    # say L587 oli
    old "I see, that makes a lot of sense."
    new "می‌تونی اینجوری ثابت کنی، خوبه."

    # say L589 pla
    old "Alright, I think we can move on to the next topic!"
    new "باشه، فکر کنم می‌تونیم به موضوع بعدی برویم!"

    # say L595 pla
    old "I never could have guessed you'd be so good at this, you know?"
    new "می‌تونستی هیچ وقت نگه کنم تو اینجور خوبی باشی، میدونی؟"

    # say L597 oli
    old "I know, everyone assumes that just because I'm pretty and popular, I'm just an airhead..."
    new "می‌دونم، همه فکر می‌کنن فقط چون خوب و مشهورم، یه احمق بی‌هیچ‌چیز هستم..."

    # say L599 oli
    old "But everyone is wrong, I'm not dumb at all..."
    new "ولی همه اشتباه می‌کنن، من خیلی دلم نیست..."

    # say L601 oli
    old "Even if it doesn't look like it, I do pay attention, just to what really interests me."
    new "حتی اگر به نظر نرسه، من هم دقت می‌کنم، فقط به چیزهایی که واقعاً برایم جالب هست."

    # say L602 pla
    old "Uhh... What do you mean?"
    new "اوه... منظورت چیه؟"

    # say L604 oli
    old "Well, I want to be a fashion designer, and for that, I don't need to memorize differential calculus formulas, you know what I mean?"
    new "خب، من می‌خوام طراح لباس شم، و برای این کار نیازی ندارم فرمول‌های حساب دیفرانسیل رو حفظ کنم، می‌فهمی؟"

    # say L606 pla
    old "Hmm, so why do you want to improve your grades now?"
    new "هم، پس چرا الان می‌خوای امتیازاتت رو بهتر کنی؟"

    # say L607 pla
    old "Is it because of what you were talking to your mom about your dad?"
    new "این به خاطر همون چیزیه که با مامانت در مورد پاپات حرف زدی؟"

    # say L609 oli
    old "Hmm, well, yeah... Something like that."
    new "هم، بله، درسته... چیزی مثل اون."

    # say L611 oli
    old "But wait!"
    new "ولی صبر کن!"

    # say L613 oli
    old "What does this have to do with you?"
    new "این به تو چه ربطی داره؟"

    # say L615 oli
    old "How about we stop with the questions and get back to studying?"
    new "بیای بپرسیم بعداً و به مطالعه برگردیم؟"

    # say L617 pla
    old "Hmm, yeah right, let's keep going."
    new "Hmm، بله درسته، بیایم ادامه بدیم."

    # say L627 pla
    old "Alright, it was just our first session, but we got a lot done."
    new "البته، فقط جلسه اول بود، اما خیلی کار کردیم."

    # say L628 pla
    old "We're very short on time."
    new "ما وقت خیلی کمی داریم."

    # say L630 pla
    old "But I think at this pace, we should be able to cover everything we need to before the exams."
    new "اما فکر می‌کنم با این سرعت، باید بتوانیم قبل از امتحان‌ها همه چیزی رو پوشش بدیم."

    # say L640 aye
    old "Hey sis, can I borrow your blue dress today for a- "
    new "هی سیس، می‌تونم لباس آبی تو رو امروز قرض بگیرم؟"

    # say L642 aye
    old "Oh, I didn't know you had company..."
    new "اوه، نمی‌دونستم مهمان داری..."

    # say L643 aye
    old "What were you two doing in here? Does Dad know you're bringing boys into your room?"
    new "شما دو تا اینجا چه کاری داشتید؟ پدر می‌دونه که تو پسرها رو به اتومون می‌آری؟"

    # say L645 oli
    old "We were studying... And it's none of your business..."
    new "ما مطالعه می‌کردیم... و این هیچ کار تو نیست..."

    # say L646 aye
    old "Oh Olivia, where are your manners? You should introduce us."
    new "اولیویا، ادبیت کجایی رفت؟ باید ما رو به هم معرفی کنی."

    # say L647 aye
    old "Hi, my name is Ayeshaa, nice to meet you."
    new "سلام، من اسمم آیشآ هست، خوشحالم که با تو آشنا شدم."

    # say L649 pla
    old "Uhh, hi, nice to meet you too, my name's [pla]."
    new "اوه، سلام، خوشحالم که با تو آشنا شدم، اسم من [pla] هست."

    # say L652 oli
    old "Alright, alright, what have I told you about coming into my room unannounced?"
    new "بیای، بیای، من تو رو چه چیزی گفتم که بدون اجازه وارد اتاقم شدی؟"

    # say L654 aye
    old "I just wanted to see if you could let me borrow the dress—"
    new "می‌خواستم ببینم می‌تونی اون لباس رو به من بدهی یا نه—"

    # say L656 oli
    old "No, you can't borrow my blue dress."
    new "نه، نمی‌تونی لباس آبی‌ام رو قرض بگیری."

    # say L658 oli
    old "Now get the hell out of here."
    new "حالا برو از اینجا بیرون."

    # say L660 aye
    old "Ugh, why do you always have to have that nasty attitude?!"
    new "اوه، چرا همیشه این حالت بد رفتار رو داری؟!"

    # say L663 aye
    old "You know what? I actually hope you screw up your grades..."
    new "دیوونه، می‌خوام ببینم چطور امتیازاتت رو خراب می‌کنی..."

    # say L666 aye
    old "So dad will take you to India with him!"
    new "پس بابا تو رو با خودش به هند می‌بره!"

    # say L668 aye
    old "Maybe then you'll learn some humility."
    new "شاید پس از اون یاد بگیری تواضع داشته باش."

    # say L670 aye
    old "Alright, alright!"
    new "باشه، باشه!"

    # say L671 aye
    old "Bye, cutie."
    new "بای، لولو."

    # say L672 pla
    old "B- bye..."
    new "بای..."

    # say L679 oli
    old "I'm sorry about that."
    new "متاسفم از خاطر این."

    # say L681 oli
    old "She's just a brat, and my mom always lets her get away with everything, that's why she acts like that."
    new "او فقط یه بچه خرابه، و مامان هم همیشه بهش اجازه میده هر چی که بخواد بکنه، برای همین همینجور رفتار می‌کنه."

    # say L683 pla
    old "Uhh... S- sure, no problem."
    new "اوه... بله، مشکلی نداره."

    # say L684 pla
    old "Uhmm, by the way, w- what she said about you going to India..."
    new "اوه، بله، اما... اون جا که در مورد رفتنت به هند حرف زد..."

    # say L686 oli
    old "I told you! I'm not talking about that!"
    new "من به تو گفتم! من در مورد اون حرف نمی‌زنم!"

    # say L690 oli
    old "Anyway, I think we were done studying for today, right?"
    new "به هر حال، فکر کنم برای امروز مطالعه کافی کردیم، درسته؟"

    # say L692 pla
    old "Uhh, yeah, we made good progress today, but we still have more to do. You need to get a high grade to boost your average..."
    new "اوه، بله، امروز پیشرفت خوبی کردیم، ولی هنوز کار بیشتری داریم. باید نمره بالایی بگیری تا میانگینت بالا برود..."

    # say L693 pla
    old "I know you're worried, but I think we can handle it."
    new "میدونم نگرانی، ولی فکر کنم بتونیم این کار رو انجام بدیم."

    # say L695 oli
    old "If you say so..."
    new "اگه تو همین‌جوری فکر می‌کنی..."

    # say L697 pla
    old "Alright, I think I have to go. So, are afternoons good for you to keep studying?"
    new "باشه، فکر کنم باید برسم. پس، بعد از ظهر برای ادامه تحصیل خوبه؟"

    # say L699 oli
    old "Right, make sure to come by my house in the afternoons. Don't miss it, or you know what will happen..."
    new "درست، حتماً بعد از ظهر به خونه‌ام بیا. نباید اینو از دست بدهی، یا می‌دونی چه خواهد افتاد..."

    # say L700 pla
    old "Yeah, sure, you don't have to remind me."
    new "بله، حتماً، نیازی به یادآوری ندارم."

    # say L701 pla
    old "Anyway, see you later."
    new "بای، بعداً می‌بینیم."

    # say L703 oli
    old "Ok, see you."
    new "باشه، دیوونه، بعداً می‌بینیم."

    # say L721 oli
    old "Hey, I was waiting for you. You’re here to help me study, right?"
    new "سلام، منتظرت بودم. برای کمک به من در مطالعه اومدی، همینجوری؟"

    # say L722 pla
    old "Yeah, I'm here to keep working on the stuff we still need to cover."
    new "بله، همینجوری اومدم تا کارهایی که هنوز پوشش ندادیم رو ادامه بدیم."

    # say L724 oli
    old "Great! I was getting worried you might take too long to come back."
    new "عالی! نگران می‌شدم که ممکن است زودتر نمی‌گردی."

    # say L726 oli
    old "Let's not waste any time and get started."
    new "بیای زمانی رو هدر ندهیم و شروع کنیم."

    # say L727 pla
    old "Alright, let's continue where we left off last time."
    new "باشه، بیای از جایی که رها شدیم ادامه بدیم."

    # say L729 oli
    old "Sure, let's do it."
    new "بله، بیای بکنیم."

    # say L758 pla
    old "Alright, I think that's enough for today."
    new "باشه، فکر کنم برای امروز کافیه."

    # say L759 pla
    old "We still have some other things to cover, but I'll be back soon so we can continue with what's left."
    new "ما هنوز چیزهای دیگه‌ای برای بحث داریم، اما زود بر می‌گردم تا ادامه بدیم."

    # say L760 pla
    old "And then we can move on to the next topic."
    new "و بعد می‌تونیم به موضوع بعدی برسیم."

    # say L762 oli
    old "Alright, sure, thanks for coming."
    new "البته، ممنون از اینکه اومدی."

    # say L763 oli
    old "I'll see you soon."
    new "به زودی می‌بینم تو را"

    # say L795 vee
    old "Hi [pla]! Good morning!"
    new "سلام ز[pla]! صبح خوب!"

    # say L796 pla
    old "Hi Mrs. Priya, how are you today?"
    new "سلام خانم پریا، امروز چطوری؟"

    # say L798 vee
    old "I'm doing alright sweetheart."
    new "من خوب هستم عزیزم."

    # say L799 vee
    old "Honey, did you come to see Olivia?"
    new "حباب، آیا برای دیدن اولیویا اومدی؟"

    # say L800 vee
    old "Because right now it's time for school."
    new "چون الان وقت مدرسه هست."

    # say L802 vee
    old "Shouldn't you be there?"
    new "نباشی اونجا؟"

    # say L803 pla
    old "Oh, yeah, Mrs. Priya, I just have the day off school to run a couple of errands."
    new "اوه، بله، خانم پریا، من فقط امروز تعطیل مدرسه هستم تا چند کار انجام بدم."

    # say L804 pla
    old "And I wanted to say hi."
    new "و می‌خواستم سلام بزنم."

    # say L805 vee
    old "I see, I'm glad to see you dear."
    new "ببینم، خوشحالم که تو رو می‌بینم عزیزم."

    # say L806 vee
    old "I'll be sure to tell Olivia you stopped by."
    new "حتماً به اولیویا می‌گم که اومدی."

    # say L808 pla
    old "Alright, thanks ma'am."
    new "البته، ممنون می‌شم."

    # say L811 vee
    old "Hello, [pla]!"
    new "سلام، [pla]!"

    # say L812 pla
    old "Hi, Mrs. Priya!"
    new "سلام، خانم پریا!"

    # say L814 vee
    old "It's good to see you, dear. How are you today?"
    new "خوشحالم که تو رو می‌بینم، عزیزم. امروز چطوری؟"

    # say L816 pla
    old "I'm fine, Mrs. Priya, and you?"
    new "من خوبم، خانم پریا، و تو چطوری؟"

    # say L818 vee
    old "I'm doing alright, dear. Keeping busy as usual, thanks for asking."
    new "من خوب هستم، عزیزم. همیشه مشغول هستم، ممنون از اینکه پرسیدی."

    # say L819 vee
    old "Tell me, did you come to see Olivia?"
    new "بگو، برای دیدن اولیویا اومدی؟"

    # say L823 vee
    old "Great! She's in her bedroom right now, dear."
    new "عالی! او الان توی اتاق خوابش هست، عزیزم."

    # say L824 vee
    old "Don't mind me, you can go right in."
    new "بیای تو، می‌تونی همین حالا داخل شی."

    # say L826 pla
    old "Thanks, Mrs. Priya. I'll catch up with you later."
    new "ممنون، خانم پریا. بعداً با تو صحبت می‌کنم."

    # say L828 vee
    old "That's alright, dear. Nice seeing you."
    new "خوبه، عزیزم. خوشحالم که ازت دیدم."

    # say L829 vee
    old "And if you kids need anything, just let me know."
    new "و اگر بچه‌ها به هر چیزی نیاز داشتید، فقط به من بگویید."

    # say L840 pla
    old "Alright, that's it, that's the right method."
    new "البته، این همینه، این روش درسته."

    # say L842 pla
    old "Great, you got it!"
    new "عالی، درست آوردی!"

    # say L844 pla
    old "You know, we're making very good progress."
    new "می‌دونی، پیشرفت خوبی داریم."

    # say L846 pla
    old "At this rate we'll manage to go over every topic before the exams."
    new "با این سرعت قبل از امتحانات به همه موضوعات خواهیم رسید."

    # say L847 oli
    old "Yeah, ok... Great."
    new "بله، خوب... عالی."

    # say L849 pla
    old "That doesn't seem like you're too sure about it."
    new "به نظر می‌رسه اینجوری اعتماد زیادی نداری."

    # say L856 oli
    old "I just feel like this isn't working [pla]."
    new "من فقط حس می‌کنم این کار درست نیست [pla]."

    # say L858 oli
    old "You just said that you think we'll be able to tackle every topic before the exams."
    new "تو همین الان گفتی که فکر می‌کنی قبل از امتحانات بتونیم همه موضوعات رو پوشش بدیم."

    # say L860 oli
    old "But how well am I really going to do in them?"
    new "ولی واقعاً چقدر خوب در امتحانات می‌تونم برم؟"

    # say L861 oli
    old "With so little time, there's only so much I can learn."
    new "با این زمان کم، فقط مقداری چیز می‌تونم یاد بگیرم."

    # say L863 pla
    old "Come on, don't be so negative."
    new "بیای، منفی نباش."

    # say L865 pla
    old "I know what you mean. But it's worth giving it a shot."
    new "من می‌فهمم. ولی امتحان کردن ارزشش هست."

    # say L866 oli
    old "I know it is."
    new "می‌دونم."

    # say L868 oli
    old "It's just that when I see how much more we have to study."
    new "فقط وقتی می‌بینم چقدر بیشتر باید مطالعه کنیم."

    # say L869 oli
    old "And the time that's left before the exams."
    new "و زمانی که تا امتحانات باقی مونده."

    # say L873 oli
    old "That was just a huge waste of time!"
    new "این فقط وقت برای هدر رفتن بود!"

    # say L874 pla
    old "Hey, hey, come on."
    new "بیا، بیا، آرام شو."

    # say L875 pla
    old "I understand how you feel, but let's not get discouraged."
    new "من می‌فهمم احساست چه هست، ولی نباید خسته شویم."

    # say L877 pla
    old "I'm sure you'll do well in these exams."
    new "مطمئنم تو در این امتحان‌ها خوب عمل می‌کنی."

    # say L879 pla
    old "I mean... Yeah, it would be very difficult to get perfect scores."
    new "من قصدم... بله، برای اینکه نمرات کامل بگیری خیلی سخته."

    # say L880 pla
    old "But I'm sure that if we keep studying at this pace, and with a little luck."
    new "اما مطمئنم که اگر با این سرعت خوندن ادامه بدیم، و با یه کم شانس."

    # say L882 pla
    old "You'll get grades that are good enough for you to pass all the subjects."
    new "تو در نهایت نمراتی خواهی گرفت که برای پاس کردن همه دروس کافی باشه."

    # say L883 oli
    old "But that's the problem! I can't just get {i}‘passing grades'{/i}."
    new "ولی این همین مشکل است! من نمی‌تونم فقط {i}«نمرات قابل قبول»{/i} بگیرم."

    # say L885 oli
    old "If I don't get maximum grades, it won't be good enough!"
    new "اگر نمره‌های بالاترین رو نگیرم، خوب نیست!"

    # say L887 pla
    old "Uh, ok?"
    new "اوه، خب."

    # say L889 pla
    old "But why, though?"
    new "ولی چرا؟"

    # say L890 pla
    old "I mean, I understand that studying and grades are important."
    new "من می‌فهمم که تحصیل و نمره مهم هست."

    # say L892 pla
    old "But why is it so important to get the maximum grades?"
    new "ولی چرا اینقدر مهمه تا بهترین نمرات رو بگیرم؟"

    # say L900 oli
    old "I didn't want to tell you about this, but I guess it's better if you understand the full picture."
    new "من نمی‌خواستم اینو به تو بگم، ولی بهتره که تو همه چی رو بدونی."

    # say L902 oli
    old "Listen, if I don't get maximum or top grades by the end of the term, I'll be sent to India to live with my dad."
    new "بله، اگر تا پای ترم نمرات بالایی نگیرم، باید برای زندگی با پدرم به هند برسم."

    # say L905 oli
    old "Well, you know my parents are from India, right?"
    new "خب، می‌دونی والدین من از هند هستن، درسته؟"

    # say L906 pla
    old "Hmm, yeah sure..."
    new "هم، بله مطمئن هستم..."

    # say L908 oli
    old "See, my father is still living there. He comes here often, but his business is located there."
    new "ببین، پدرم هنوز آنجا زندگی می‌کنه. اونجا کارش هست، اما معمولاً اینجا می‌آد."

    # say L909 oli
    old "While we stay here with my mother."
    new "در حالی که ما اینجا با مادرم می‌مانیم."

    # say L913 oli
    old "Well, my dad's a very traditional guy."
    new "پدرم مرد بسیار سنتیه."

    # say L915 oli
    old "He cares a lot about upholding tradition and customs."
    new "او خیلی مهم می‌ده به نگهداری از سنت‌ها و عادات."

    # say L917 oli
    old "And since I'm the oldest daughter, he wants me to take part in a lot of those traditions."
    new "و چون من بزرگترین دختر هستم، می‌خواهد من در بسیاری از آن سنت‌ها شرکت کنم."

    # say L921 oli
    old "Without consulting me or letting me know about it!"
    new "بدون اینکه با من مشورت کنه یا از من خبر بده!"

    # say L922 pla
    old "Uh, I- I see."
    new "اوه، من- من متوجه شدم."

    # say L925 pla
    old "B- but, don’t you think if you talked to him, he’d understand you’re not in love with the guy he wants you to marry?"
    new "B- بله، ولی فکر نمی‌کنی اگه باشون حرف بزنی، متوجه می‌شنن که تو عاشق آدمی که می‌خواین تو باشی نیستی؟"

    # say L927 oli
    old "{b}*Sigh*{/b} Come on, be realistic."
    new "{b}*تنفس*{/b} بیای، واقعی باش."

    # say L929 oli
    old "Love has nothing to do with it [pla]."
    new "عشق هیچ ربطی به این نداره [pla]."

    # say L931 oli
    old "The guy he engaged me to is the heir to a very successful company."
    new "مردی که به من تعهد داده، جانشین یک شرکت بسیار موفق است."

    # say L932 oli
    old "He knows that by getting me married to him, he would get a big opportunity to do business."
    new "او می‌دونه که با ازدواج من ازش، فرصت خوبی برای کسب و کار پیدا می‌کنه."

    # say L934 oli
    old "He thinks that since I'm the oldest daughter, it is my duty to the family to go through with his plan!"
    new "او فکر می‌کنه چون من بزرگترین دختر خانواده هستم، وظیفه‌ام اینه که به طرحش راه بدم!"

    # say L935 pla
    old "B- but, isn't there anything that you can do?"
    new "ولی، آیا هیچ چیزی نمی‌تونی انجام بدی؟"

    # say L937 oli
    old "Well, that's why I need to get good grades."
    new "خب، همین جویاییه که نمره‌های خوبی بگیرم."

    # say L939 oli
    old "My mom's a little more open-minded than my dad. She knows I don't want to live my life that way."
    new "مامانم کمی بازتر از بابامه. او می‌دونه من نمی‌خوام اون طور زندگی کنم."

    # say L941 oli
    old "She's been supporting me, and interceding on my behalf with my dad."
    new "مادرم منو حمایت می‌کنه و برایم با پدرم مذاکره می‌کنه."

    # say L943 oli
    old "That's been a huge problem between them, they've been fighting over it."
    new "این موضوع خیلی مشکل بین اونا ایجاد کرده، همیشه به خاطرش با هم دعوا می‌کنن."

    # say L945 oli
    old "But my mom finally convinced him to let me off the hook if I get good grades by the end of the term."
    new "اما مامانم در نهایت تونست پدرم رو قانع کنه که اگه تا پای ترم نمرات خوبی بگیرم، از من بپره."

    # say L946 oli
    old "That's why I'm so desperate to get the highest scores! Because I really have to!"
    new "برای همین هستم خیلی متعهد برای گرفتن بالاترین نمرات! چون واقعاً باید اینجوری کنم!"

    # say L948 pla
    old "I- I see. I understand."
    new "می‌بینم. فهمیدم."

    # say L949 pla
    old "I didn't know how important the exam results would be for you."
    new "نمیدونستم نتایج امتحان برای تو اینقدر مهم هست."

    # say L951 pla
    old "I'm not sure, but I think we can make it so that you'll be able to get the top grades."
    new "من مطمئن نیستم، ولی فکر می‌کنم می‌تونیم اینجوری کار کنیم که تو بتونی بهترین نمره‌ها رو بگیری."

    # say L953 oli
    old "Do you really mean it?"
    new "می‌تونی واقعاً اینو جدی بگی؟"

    # say L955 oli
    old "I know there's too little time to do this."
    new "میدونم وقت کمی هست برای این کار."

    # say L956 pla
    old "But I know we can make it, come on let's keep going!"
    new "ولی میدونم می‌تونیم اینو انجام بدیم، بیا بیاییم ادامه بدیم!"

    # say L958 oli
    old "Okay, okay."
    new "باشه، باشه."

    # say L968 pla
    old "I think that's enough for today, but I'll be back soon so we can keep going."
    new "فکر کنم برای امروز کافیه، ولی زود بر می‌گردم تا ادامه بدیم."

    # say L969 pla
    old "Don't worry, we'll get this done before you know it."
    new "نگران نباش، قبل از اینکه متوجه بشی این کار تمام می‌شه."

    # say L973 oli
    old "You know [pla], I'm not sure about this."
    new "دیوید، من در مورد این هیچ اطمینانی ندارم [pla]."

    # say L975 oli
    old "But if you say we can make it, I'll believe you."
    new "ولی اگر می‌گی بشه، من باورت می‌کنم."

    # say L977 oli
    old "Thanks for the help [pla]."
    new "ممنون از کمکت [pla]."

    # say L979 pla
    old "No problem, I'm happy to help."
    new "هیچ اشکالی ندارم، خوشحالم که کمک کردم."

    # say L980 pla
    old "I'll go for now, but I'll see you later."
    new "من حالا می‌روم، ولی بعداً می‌بینیم هم."

    # say L1005 vee
    old "Yeah, that's right. Your aunt Fatima said she'd be sending Devika here to spend some time with us."
    new "بله، همینطوره. خاله فاطمه گفت که دویکا رو می‌فرسته تا یه دوره با ما بیاد."

    # say L1008 vee
    old "Oh honey, don't make that face."
    new "عسلان جون، این چهره رو نکن."

    # say L1011 oli
    old "I just don't know if she should come here."
    new "من فقط نمی‌دونم اگه اومد به اینجا خوبه."

    # say L1014 oli
    old "Where is she going to sleep?"
    new "او کجا می‌خوابد؟"

    # say L1016 vee
    old "You don't need to worry about that."
    new "نگران اون نباش."

    # say L1018 vee
    old "Besides, I know you like your cousin. You two used to be very close!"
    new "البته، میدونم تو خواهرت رو دوست داری. شما دو تا قبلاً خیلی نزدیک بودید!"

    # say L1019 oli
    old "Hmm, that was a long time ago."
    new "هم، این طولانی پیش بود."

    # say L1021 oli
    old "But I guess it's alright if she comes here. I like Aunty Fatima, so it shouldn't be too much of a problem."
    new "ولی حدس می‌زنم اگه اونجا بیاد خوبه. من خاله فاطمه رو دوست دارم، پس مشکل زیادی نمی‌تونه باشه."

    # say L1027 pla
    old "Uh, s- sorry for interrupting."
    new "اوه، خواهش می‌کنم، من قصد نداشتم تا مداخله کنم."

    # say L1030 pla
    old "Hi Olivia, I came to continue our study sessions."
    new "سلام اولیویا، اومدم تا جلسات مطالعه‌مون رو ادامه بدم."

    # say L1032 oli
    old "[pla], I'm so glad you're here! I was just waiting for you!"
    new "[pla]، خوشحالم که اینجا هستی! منتظرت بودم."

    # say L1033 pla
    old "Uh... You were?"
    new "آ... تو واقعاً منتظر من بودی؟"

    # say L1034 pla
    old "W- well, here I am, I guess."
    new "ب- خوب، اینجا هستم، حدس می‌زنم."

    # say L1035 oli
    old "Yeah, I was just waiting for you to make our announcement."
    new "بله، من فقط منتظر بودم تا تو اعلامیه‌مون رو بدهی."

    # say L1037 pla
    old "O- our announcement? What do you-"
    new "ا- اعلامیه ما؟ تو درباره چه چیزی حرف می‌زنی؟"

    # say L1043 oli
    old "Mom, there's something that [pla] and I have been wanting to tell you."
    new "مامان، چیزی هست که ز[pla] و من می‌خوایم به تو بگیم."

    # say L1044 oli
    old "And we decided this is the right time to do it."
    new "و ما تصمیم گرفتیم الان وقت مناسب برای اینه."

    # say L1046 vee
    old "Hmm, o-kay? What is it?"
    new "هم، اوکی؟ چیه؟"

    # say L1048 oli
    old "Well, you see, the truth is that [pla] isn't actually my friend."
    new "خب، می‌دونی، حقیقت اینه که ز[pla] در واقع دوست من نیست."

    # say L1050 oli
    old "Actually, it would be more accurate to say that he's not only my friend."
    new "در واقع، درست‌تر است بگم که او فقط دوست من نیست."

    # say L1055 oli
    old "What you just heard, Mom. [pla] and I have been dating for a while now."
    new "مامان، اونی که شنیدی، ز[pla] و من از یه مدت هستیم با هم دیت می‌کنیم."

    # say L1057 vee
    old "I'm sorry, and why hadn't I heard about this until now?"
    new "متأسفم، و چرا تا حالا از این خبر ندادی؟"

    # say L1059 oli
    old "Because I just wanted to be sure about what he and I feel, and of our relationship."
    new "چون می‌خواستم مطمئن شم احساساتمون چطوره و رابطه‌ی ما چه جوریه."

    # say L1062 oli
    old "Also, I knew that you and Dad wouldn't have approved."
    new "همچنین، می‌دانستم تو و پاپا موافقت نمی‌کردید."

    # say L1064 vee
    old "Oh, you think so?"
    new "اوه، فکر می‌کنی همینطوره؟"

    # say L1067 vee
    old "Not only are you dating someone without our approval."
    new "نه فقط تو با کسی رابطه داری که ما اجازه ندادیم."

    # say L1069 vee
    old "Now you also come and tell me like this?"
    new "الان هم می‌آیی و به من اینجوری می‌گی؟"

    # say L1072 vee
    old "You know full well that this is not how we do things, Olivia!"
    new "میدونی کاملاً اینجوری کار نمی‌کنیم، Olivia!"

    # say L1074 vee
    old "I can't even imagine the face Vihaan's going to make when he finds out about this."
    new "نمی‌تونم حتی بیافکنم چه چهره‌ای Vihaan وقتی این‌ها رو می‌فهمه."

    # say L1075 oli
    old "That's precisely why I'm telling you this right now."
    new "این همین‌جوری است که من الان این‌ها رو به تو می‌گم."

    # say L1078 oli
    old "Mom, [pla] and I are in love."
    new "مامان، ز[pla] و من عاشق هم هستیم."

    # say L1081 oli
    old "But I know that if I tell Dad about this, he'll never approve of us."
    new "اما می‌دونم اگه به پاپا بگم، هیچ وقت موافقت نمی‌کنه."

    # say L1082 oli
    old "So I need your help to convince him that this is okay."
    new "پس نیاز دارم کمکت رو ببرم تا او راضی شه که این خوبه."

    # say L1085 vee
    old "It's not that simple, honey. You know I have no problem with you having a boyfriend."
    new "این همین ساده نیست، عزیزم. می‌دونی من مشکلی با این ندارم که تو دوست داری."

    # say L1088 vee
    old "But Vihaan is a lot more traditional than me."
    new "ولی ویهاان خیلی سنتی‌تر از منه."

    # say L1089 vee
    old "And he won't be pleased with this at all."
    new "ویهاان خوشحال نخواهد شد از این."

    # say L1092 oli
    old "I know that, Mom, but I don't want to go along with Dad's plan."
    new "مam، این رو می‌دونم، ولی من نمی‌خوام با طرح پدر همکاری کنم."

    # say L1093 oli
    old "You know what he wants..."
    new "می‌دونی چی می‌خواد..."

    # say L1096 oli
    old "If it was up to him, I would already be wedded to that guy he wants me to marry."
    new "اگه به او بود، قرار بود از قبل با آن مردی که می‌خواد من باش ازدواج کرده بودم."

    # say L1099 oli
    old "But I don't want to live my life like that, Mom!"
    new "ولی من نمی‌خوام زندگی‌ام رو اینجور بگذونم، مامان!"

    # say L1102 oli
    old "I don't care about that guy I don't know."
    new "من به آن مردی که نمی‌شناسم اهمیتی نمی‌دهم."

    # say L1105 oli
    old "He's not what I want for my life."
    new "او همچین نیست که من برای زندگی‌ام بخوام."

    # say L1107 oli
    old "[pla] is the one I'm in love with!"
    new "[pla] اون جوونی که دوستش دارم هست!"

    # say L1110 oli
    old "I need your help to convince Dad, please Mom."
    new "لطفاً مامان، کمکت به من لازمه تا پاپا رو قانع کنم."

    # say L1118 vee
    old "Alright, I can see you're serious about this."
    new "باشه، می‌تونم ببینم این موضوع برایت جدیه."

    # say L1119 oli
    old "That means you'll help me?"
    new "این بعنی که کمکت به من می‌کنی؟"

    # say L1121 vee
    old "Well, what choice do I have?"
    new "خب، چه انتخابی دارم؟"

    # say L1123 vee
    old "You're putting me in a tough spot right now, honey."
    new "حالم رو الان خیلی سخت می‌کنی، عزیزم."

    # say L1126 vee
    old "But I wouldn't want to force your hand."
    new "ولی من نمی‌خوام تو رو زور بدم."

    # say L1129 vee
    old "And to be honest, I'm not too keen on this whole arranged marriage situation."
    new "و صداقت بگم، خیلی خوشم نمی‌آید این موضوع ازدواج تعهدی."

    # say L1132 vee
    old "So I'll help you with your father for now."
    new "پس حالا به تو در مورد پدرت کمک می‌کنم."

    # say L1134 oli
    old "That's great, Mom, thank you!"
    new "عالیه، مامان، ممنون!"

    # say L1137 vee
    old "Yeah well, that's only if you get good grades, you know."
    new "بله، البته اگر نمرات خوبی بگیری، میدونی."

    # say L1138 vee
    old "Remember, that's a deal we already made with your father, so don't disappoint us."
    new "به خاطر داشت، این توافقیه که قبلاً با پاپا درست کردیم، پس ما رو نخیاب."

    # say L1140 oli
    old "Don't worry, I promise you I'm working very hard."
    new "نگران نباش، قول می‌دم خیلی سخت می‌کنم."

    # say L1142 oli
    old "Come on [pla], let's get to studying."
    new "بیا ز[pla]، بیایم به مطالعه بپردازیم."

    # say L1151 pla
    old "Uh, I- Uh... S- see to you later, Mrs. Priya."
    new "اوه، من- اوه... خب، بای‌بای، خانم پریا."

    # say L1161 oli
    old "Ok, that went well."
    new "خب، اینجوری خوب بود."

    # say L1164 pla
    old "Would you mind telling me what this business of us dating is about?"
    new "می‌تونی به من بگی این حرف‌ها در مورد رابطه‌مون چی بودن؟"

    # say L1165 oli
    old "Well, you heard me talking to my mom."
    new "خب، شنیدی من با مامانم چه حرفی زدم."

    # say L1167 oli
    old "Listen, after the last time you came here, I got to thinking about how much work is still left to do."
    new "بله، بعد از آخرین باری که اینجا اومدی، فکر کردم که هنوز کار زیادی برای تمام کردن داریم."

    # say L1169 oli
    old "And I got worried about the possibility of not finishing it."
    new "و نگران شدم از اینکه ممکنه نتونیم اون رو تمام کنیم."

    # say L1171 oli
    old "So I figured I needed a contingency plan in case my grades don't turn out to be good."
    new "پس فکر کردم باید یه برنامه جایگزین داشته باشم اگر نمره‌هام خوب نیوم."

    # say L1172 pla
    old "So you came up with the idea of us dating? How is that going to help?"
    new "پس تو ایده‌ی دوست‌داشتنمون رو پیشنهاد کردی؟ این چطور کمک می‌کنه؟"

    # say L1174 oli
    old "Think about it [pla], if I can convince my Dad that I'm in love with you."
    new "فکر کن [pla]، اگه بتونم پدرم رو قانع کنم که عاشق تو هستم."

    # say L1176 oli
    old "And that things are serious enough for me to consider marrying you."
    new "و اینکه اوضاع جدی هست تا من در نظر داشتم با تو ازدواج کنم."

    # say L1178 oli
    old "Maybe he'll give up on trying to push me into that marriage."
    new "شاید پدرم از تلاش برای اینکه من را به این ازدواج مجبور کند، خسته شود."

    # say L1180 oli
    old "I'm sorry, is this a problem for you?"
    new "ببخشید، این برای تو مشکلی هست؟"

    # say L1182 pla
    old "No, not really. I promised to help you with this, and I get what you're doing."
    new "نه، خیر. قول دادم که بهت کمک کنم و متوجه هستم که چیکار می‌کنی."

    # say L1183 pla
    old "So it's alright, I'll help you with it."
    new "پس خوبه، من بهت کمک می‌کنم."

    # say L1184 oli
    old "Thanks [pla], you have no idea how much I appreciate you saying that."
    new "ممنون [pla]، نمی‌دونی چقدر از این که اینا رو گفتی خوشحالم."

    # say L1185 pla
    old "I'm happy to help you."
    new "خوشحالم که به تو کمک کنم."

    # say L1186 pla
    old "Now, let's get to studying, to ensure that you don't need your contingency plan."
    new "خب، حالا بیای بیشتر بخونیم تا نیازت به طرح احتیاطیت نباشه."

    # say L1196 oli
    old "Ugh! This is pointless!"
    new "اوه! این هیچ کاربردی نداره!"

    # say L1197 pla
    old "W-what? What do you mean?"
    new "و-وای! منظورت چیه؟"

    # say L1199 oli
    old "I'm talking about this whole studying for exams thing!"
    new "من در مورد این کل موضوع آماده‌سازی امتحان‌ها حرف می‌زنم!"

    # say L1200 oli
    old "It's pointless!"
    new "این کار هیچ فایده‌ای نداره!"

    # say L1201 pla
    old "W- why do you say that?"
    new "چرا اینجوری می‌گی‌ی؟"

    # say L1203 oli
    old "Think about it, [pla]..."
    new "فکر کن، [pla]..."

    # say L1204 oli
    old "Look at how much I still have to do!"
    new "ببین چقدر کار هنوز دارم!"

    # say L1206 oli
    old "There are so many topics!"
    new "مباحث زیادی هست!"

    # say L1207 oli
    old "There's no way I can cram all of this into my head before the exams!"
    new "حتماً نمی‌تونم همه این چیزها رو قبل از امتحانات به ذهنم بیاندازم!"

    # say L1220 aye
    old "Oh! Olivia is with her boyfriend in her room again?"
    new "اوه! اولیویا دوباره با دوست پسرش توی اتاقش هست؟"

    # say L1221 aye
    old "I wonder what they talk about when they're alone..."
    new "می‌پرسم چه حرف‌هایی می‌زنن وقتی تنها هستن..."

    # say L1222 aye
    old "Or maybe they're doing some dirty stuff?"
    new "شاید کارهای خوبی هستند که می‌کنن؟"

    # say L1228 aye
    old "I guess a little eavesdropping won't hurt."
    new "باید یه کم شنود کنم، خیلی خراب نمی‌شه."

    # say L1235 pla
    old "I can see why you're worried."
    new "می‌فهمم چرا نگرانی."

    # say L1237 pla
    old "But you still have to try."
    new "اما هنوز باید تلاش کنی."

    # say L1238 pla
    old "Look at how much work you've put in already."
    new "ببین چقدر تلاش کردی تا حالا."

    # say L1240 pla
    old "You can't give up now."
    new "نمی‌تونی الان صبر کنی."

    # say L1242 oli
    old "I know I've put in a lot of work, [pla]."
    new "میدونم خیلی کار کردم، [pla]."

    # say L1244 oli
    old "But come on, there's no way I'm going to be able to learn all of this before the exams."
    new "ولی بیا، راهی نیست که بتونم همه اینا رو قبل از امتحان‌ها یاد بگیرم."

    # say L1247 aye
    old "{i}(She seems to be struggling.){/i}"
    new "{i}(به نظر می‌رسه مشکل داره.){/i}"

    # say L1250 aye
    old "{i}(She'll finally get what she deserves!){/i}"
    new "{i}(در نهایت به حقش خواهد رسید!){/i}"

    # say L1252 pla
    old "I get it, I know you're stressed and frustrated."
    new "فهمیدم، می‌دونم استرس داری و ناراحتی."

    # say L1254 pla
    old "But come on, you can't give up."
    new "ولی بیا، نمی‌تونی اینجوری بی‌امید شی."

    # say L1256 oli
    old "I don't know, I think we should make another plan."
    new "نمی‌دونم، فکر کنم باید برنامه‌ی جدیدی بزنیم."

    # say L1260 aye
    old "{i}(W-what? What is she talking about?){/i}"
    new "{i}(ب-ببخشید؟ درباره چی حرف می‌زنی؟){/i}"

    # say L1261 aye
    old "{i}(He's not her boyfriend?){/i}"
    new "{i}(او دوست پسرش نیست؟){/i}"

    # say L1274 aye
    old "Hey sis! How are you?"
    new "اها خواهر! چطوری؟"

    # say L1275 oli
    old "{b}*Sigh*{/b} What do you want?"
    new "{b}*تنفه*{/b} چه کاری می‌خوای؟"

    # say L1276 aye
    old "Oh, not much."
    new "اوه، خیلی چیزی نیست."

    # say L1277 aye
    old "I was just walking down the hallway a minute ago."
    new "من فقط یه لحظه پیش در راهرو قدم می‌زدم."

    # say L1280 aye
    old "And I accidentally overheard something about [pla] here not being your boyfriend."
    new "و من به طور اتفاقی چیزی در مورد اینکه ز[pla] دوستت نیست شنیدم."

    # say L1281 aye
    old "I wonder what that's about?"
    new "من خیال می‌کنم این درباره چه چیزی است؟"

    # say L1283 oli
    old "I- I don't know what you're talking about."
    new "من- من نمی‌دونم در مورد چی حرف می‌زنی."

    # say L1284 aye
    old "Oh yeah, I bet you don't."
    new "اوه بله، مطمئن هستم که نمی‌دونی."

    # say L1287 aye
    old "You know, dad's going to be very displeased about this."
    new "پدر از این خیلی ناراحت خواهد شد."

    # say L1289 aye
    old "I can already imagine his face when I tell him that you're apparently faking having a boyfriend."
    new "می‌تونم حالا صورت پدر رو وقتی بهش می‌گم که به نظر می‌رسه تو دوست پسر فرضی داری، تصور کنم."

    # say L1291 aye
    old "I can't wait."
    new "نمی‌تونم صبر کنم."

    # say L1293 oli
    old "W-wait! You don't understand."
    new "بی‌پای! تو هیچ جور نفهمیده‌ای."

    # say L1294 oli
    old "I think you misheard us or something."
    new "فکر کنم اشتباه شنیدی یا چیزی."

    # say L1296 aye
    old "Oh no, don't give me that. I didn't mishear anything!"
    new "نه، این بازی را با من نکن. هیچ چیزی ناشنیده‌ام!"

    # say L1299 aye
    old "You know, I thought it was strange."
    new "می‌دونی، فکر کردم عجیبه."

    # say L1300 aye
    old "When you suddenly brought a boyfriend home."
    new "وقتی ناگهان یه دوست پسر به خونه آوردی."

    # say L1303 aye
    old "And not only that, from one moment to the next, you decided to start studying."
    new "و نه تنها این، از یک لحظه به بعد تصمیم گرفتی که شروع به مطالعه کنی."

    # say L1305 aye
    old "When I had never seen you take your studies seriously."
    new "وقتی هرگز جدی به مطالعه‌ات نگیردی."

    # say L1307 aye
    old "I see now that this is just a ploy to avoid going to India with dad, isn't it?"
    new "حالا متوجه شدم که این فقط یه تکنیکه برای اینکه نبری هم پدرت به هند، نیست؟"

    # say L1311 oli
    old "Ugh, shut up! This has nothing to do with that!"
    new "اوه، بسش کن! این هیچ ربطی به اون نداره!"

    # say L1314 oli
    old "Now get out of my room before I throw you out!"
    new "بیرون برو از این اتاق قبل از اینکه تو رو بیرون بیاندازم!"

    # say L1316 aye
    old "Oh, I'll get out of here!"
    new "اوه، من از اینجا برمی‌روم!"

    # say L1319 aye
    old "And I'll go call Dad right away!"
    new "و من هم الان می‌رمش و پاپا رو می‌تماسنم!"

    # say L1320 aye
    old "With all the work Dad's doing to grant you a future!"
    new "با همه کارهایی که پاپا برای اینکه آینده‌ات رو بهت بده کرده!"

    # say L1323 aye
    old "And this is how you decide to repay him, by lying to him!"
    new "و اینجاست که می‌خوای این طور بهش بپرداختی، با دروغ زدن بهش!"

    # say L1325 aye
    old "I can't wait to let him know how bad his favorite daughter really is!"
    new "نمی‌تونم صبر کنم تا ازش بگم چقدر دختر مورد عزت پدرت بد هستی!"

    # say L1336 aye
    old "Yes? What do you want?"
    new "بله؟ چی می‌خوای؟"

    # say L1343 oli
    old "{b}*Sigh*{/b} If I prove to you that he's my boyfriend, will you shut up and not talk to Dad?"
    new "{b}*تنفر*{/b} اگه به من ثابت کنی که همسرم هست، آیا خاموش می‌شی و با پاپا صحبت نمی‌کنی؟"

    # say L1344 aye
    old "Hmm... Maybe, if you can convince me, of course."
    new "Hmm... شاید، اگر بتونی مرا قانع کنی، البته."

    # say L1345 oli
    old "I swear to God, one day."
    new "قسمت خدا، یک روز."

    # say L1349 oli
    old "Here I come, [pla]..."
    new "اینجا هستم، [pla]..."

    # say L1363 oli
    old "There, are you happy?"
    new "اولیویا: خوب، حالت خوبه؟"

    # say L1365 aye
    old "What? Happy?"
    new "چه؟ خوشحالم؟"

    # say L1370 aye
    old "I could kiss him right now too."
    new "من الان هم می‌تونم بوسه‌اش بدم."

    # say L1372 aye
    old "That doesn't prove anything!"
    new "این هیچ چیز را ثابت نمی‌کنه!"

    # say L1374 oli
    old "What are you insinuating?"
    new "تو چه چیزی رو داری نشون می‌دهی؟"

    # say L1376 aye
    old "Come on sis, prove to me that you're really a couple."
    new "بیا خواهر، به من ثابت کن که واقعاً جفت هستید."

    # say L1378 oli
    old "What do you mean by that?"
    new "من قصه‌ای از این جوری می‌فهمم؟"

    # say L1379 aye
    old "Oh come on! I knew you were dumb, but I didn't think this much."
    new "اوه بیا! می‌دونستم خر دی، ولی اینقدر نمی‌تونستم فکر کنم."

    # say L1384 oli
    old "W- what? What are you talking about? Do you think I just go around doing that?"
    new "و- وای! از چی حرف می‌زنی؟ فکر می‌کنی من همه جا اینجوری می‌کنم؟"

    # say L1385 oli
    old "I don't do that sort of thing!"
    new "من این جوری کار نمی‌کنم!"

    # say L1388 aye
    old "Don't treat me like I'm stupid!"
    new "من رو مثل ابله نگیر!"

    # say L1389 aye
    old "Maybe Mom and Dad are willing to buy your {i}‘nice girl'{/i} act..."
    new "شاید مامان و پاپا آماده‌ی بازی‌ت به عنوان یه دختر {i}خوب{/i} باشند..."

    # say L1390 aye
    old "But I know who you really are!"
    new "اما من می‌دونم تو واقعاً چه کسی هستی!"

    # say L1393 pla
    old "H- hey, hey! L- let's not get carried away, girls."
    new "ه- هی، هی! ل- لبیک، دختران."

    # say L1397 oli
    old "Stay out of this!"
    new "از این بیرون بمان!"

    # say L1403 oli
    old "Listen, you little bitch."
    new "بگو، تو خر کوچولو."

    # say L1405 oli
    old "First, be very careful about who you're calling a whore."
    new "اول، بسیار مراقب باش که به چه کسی می‌گویی شوری."

    # say L1407 oli
    old "Second, there must be something really wrong with your head if you want to see me fuck this guy in front of you."
    new "دوم، باید مشکل جدی‌ای توی سرت باشه اگه می‌خوای ببینی من این مرد رو جلوت فک کنم."

    # say L1410 oli
    old "And if you think I'll let you watch that."
    new "و اگر فکر می‌کنی برات اجازه میدم اینجوری ببینی."

    # say L1411 oli
    old "So why don't you get the hell out of here?!"
    new "پس چرا نمی‌روی از اینجا بیرون؟!"

    # say L1414 aye
    old "Oh, I can leave, I told you I have no problem with that."
    new "اوه، می‌تونم برسم، بهت گفتم هیچ مشکلی ندارم با این."

    # say L1416 aye
    old "But you know what I'll do right away!"
    new "اما می‌دونی همین حالا چی می‌کنم!"

    # say L1419 aye
    old "Because I don't have any proof that this guy is your real boyfriend."
    new "چون من هیچ اثباتی ندارم که این جونون واقعاً دوستت هست."

    # say L1422 aye
    old "Thinking about it, right now it must be early morning in India."
    new "البته، الان باید صبح باشه در هند."

    # say L1423 aye
    old "Daddy must be waiting for me to send him his good morning message."
    new "پاپا باید منتظر پیام صبح خوشام باشه."

    # say L1424 aye
    old "I'm sure he'll appreciate the extra news!"
    new "مطمئنم خبر اضافی را خوشحال می‌شود."

    # say L1430 oli
    old "{i}({b}*Sigh*{/b} I can't believe this...){/i}"
    new "{i}({b}*تنفر*{/b} نمی‌تونم باور کنم...){/i}"

    # say L1431 oli
    old "Listen you..."
    new "بگو تو..."

    # say L1433 oli
    old "I'm NOT going to have sex with this guy in front of you."
    new "من نمی‌خوام جنس با این دستا در برابر تو بکنم."

    # say L1434 oli
    old "But if I do something sexual with him..."
    new "ولی اگر با او کار جنسی کنم..."

    # say L1437 oli
    old "Will you stop saying he's not my boyfriend and leave us alone?"
    new "می‌تونی بگی نیست دوست من و ما رو تنهایی بگذاری؟"

    # say L1438 aye
    old "Hmm, I don't know, that really depends on you."
    new "Hmm، نمی‌دونم، این واقعاً به تو بستگی داره."

    # say L1441 aye
    old "It has to look real, sis."
    new "باید واقعی به نظر برسه، خواهر."

    # say L1442 oli
    old "I get it..."
    new "فهمیدم..."

    # say L1445 oli
    old "I will do this then."
    new "من اینو می‌کنم."

    # say L1450 oli
    old "The only reason I'm going along with this sick game of yours."
    new "من تنها دلیلی که در این بازی خیال‌پردازت همراهی می‌کنم"

    # say L1453 oli
    old "Is because I don't have any other way of proving to you that this guy and I have a relationship."
    new "چون هیچ راه دیگه‌ای برای اثبات رابطتمون به تو ندارم."

    # say L1455 oli
    old "But this is the last time I'll let you push me into something like this."
    new "ولی این آخرین باره که تو مرا به چیزی مثل این می‌رسونی."

    # say L1458 oli
    old "If you ever try this again, I don't care what you have to say to anyone, I'll fucking make you pay!"
    new "اگه هر بار دوباره این کار رو انجام بدی، نمی‌تونی بگی چی به هیچ کس، من خودت رو به جایی می‌برم که نپرسی!"

    # say L1460 aye
    old "Very clear, sis, but I don't see you proving anything, so why don't you get to it?"
    new "خیلی روشن، خواهر، ولی نمی‌بینم چطور اثبات می‌کنی، پس چرا نمی‌روی و انجام بدی؟"

    # say L1461 aye
    old "And remember, make it convincing."
    new "و به خاطر داشت، قانع‌کننده باشه."

    # say L1466 pla
    old "W- woah! Woah! Is this for real? Do you want to do this in front of her?"
    new "وای! وای! این جدیه؟ می‌خوای اینجوری جلویش بکنی؟"

    # say L1468 oli
    old "Do you get the situation, [pla]? Do you know how serious it is?"
    new "متوجه شرایط هستی، [pla]؟ می‌دونی چقدر جدی هست؟"

    # say L1469 oli
    old "Of course I'm being serious..."
    new "بله، من جدی هستم..."

    # say L1484 aye
    old "Oh gosh! You're actually doing it!"
    new "اوه خدا! واقعاً اینو می‌کنی!"

    # say L1485 aye
    old "This is for real! I can't believe it!"
    new "این واقعیه! باور نمی‌کنم!"

    # say L1496 aye
    old "I have to say, sis, that was quite the spectacle."
    new "باید بگم، خواهر، این هم یک نمایش عالی بود."

    # say L1497 oli
    old "Are you satisfied?"
    new "خوشحالم که لبایز شد؟"

    # say L1498 aye
    old "Oh! Of course, I am!"
    new "اوه! البته، من خوشحالم!"

    # say L1499 aye
    old "I can tell how much you liked it!"
    new "می‌تونی بفهمی چقدر لذت بردم!"

    # say L1502 aye
    old "You can just tell how much love there is between the two of you!"
    new "می‌تونی ببینی چقدر عشقی بین ما دو تا وجود داره!"

    # say L1504 oli
    old "Alright, you have what you wanted. Now get the hell out of here!"
    new "خوب، چیزی که می‌خواستی رو گرفتی. حالا از اینجا برو!"

    # say L1506 oli
    old "And remember what I told you."
    new "و به خاطر داشت چی به تو گفتم."

    # say L1508 oli
    old "I won't allow this to happen a second time, now get the hell out of my room, you bitch!"
    new "من نمی‌تونم اینجوری دوباره بیفتم، حالا برو بیرون از اتاق من، شما مالخور!"

    # say L1510 aye
    old "Oh, I'm leaving alright."
    new "اوه، خوب می‌روم."

    # say L1511 aye
    old "But I can't wait to see you again soon, [pla]."
    new "ولی نمی‌تونم بیشتر صبر کنم تا دوباره تو رو ببینم، [pla]."

    # say L1512 oli
    old "Out!"
    new "بیرون!"

    # say L1521 pla
    old "Uhmm... A- are you alright?"
    new "اوه... آ- آیا حالت خوبه؟"

    # say L1523 oli
    old "Shut up, [pla]."
    new "بست ز[pla]."

    # say L1524 oli
    old "We still have a lot of ground to cover."
    new "هنوز خیلی جا داریم برای پوشش."

    # say L1525 oli
    old "And not a lot of time, so let's just get back to studying."
    new "و زمان زیادی هم نداریم، پس بیای تو دوباره به مطالعه برسیم."

    # say L1526 pla
    old "R- right."
    new "ب-له."

    # say L1545 pla
    old "I guess I'll go home for now. And I'll come back later."
    new "باید حالا برای خونه برم. بعداً می‌گردم."

    # say L1548 oli
    old "But before you leave, I want to make something clear."
    new "اما قبل از برخاستن، باید چیزی رو مشخص کنم."

    # say L1550 oli
    old "What just happened here was just a one-time thing, alright?"
    new "این که اینجا اتفاق افتاد فقط یک باره بود، درسته؟"

    # say L1552 oli
    old "Don't get any ideas about it happening again."
    new "ایده‌ای برای اینکه دوباره بیفتد نداشته باش."

    # say L1555 pla
    old "S-sure, of course."
    new "ب-bale، حتما."

    # say L1557 oli
    old "Alright, then I'll see you later."
    new "البته، بعداً می‌بینیم."

    # say L1558 pla
    old "Sure, bye."
    new "بله، خداحافظ."

    # say L1574 pla
    old "Alright, we somehow managed to cover everything."
    new "باشه، به نظر می‌رسه همه چی رو پوشش دادیم."

    # say L1575 pla
    old "It might not have been too thorough."
    new "شاید خیلی جامع نبود."

    # say L1576 pla
    old "But I'm sure you know enough now to shoot for the highest grades."
    new "اما مطمئنم حالا میدونی هر چی برای گرفتن بهترین نمره لازمه."

    # say L1581 pla
    old "I'm sure you'll do great."
    new "مطمئنم که خوب انجام می‌دهی."

    # say L1583 pla
    old "Just remember, all you have to do is stay calm while you're answering the questions."
    new "فقط به خاطر داشت، همه چیزی که باید بکنی اینه که در حال پاسخ به سؤالات آرام باشی."

    # say L1585 pla
    old "As long as you don't worry too much, you should be fine to answer everything."
    new "مادون نگرانی زیادی نکنی، باید بتونی به همه سؤالات جواب بده."

    # say L1589 oli
    old "I'll do my best to answer everything as well as I can!"
    new "من تلاش می‌کنم به همه سؤالات به بهترین نحو جواب بدم!"

    # say L1591 oli
    old "I'm so thankful for your help!"
    new "من خیلی ممنونم از کمکت!"

    # say L1593 oli
    old "Without you, I couldn't have gone through all those topics."
    new "بدون تو، نمی‌تونستم همه این موضوعات رو پشت سر بگذارم."

    # say L1594 oli
    old "Really, thank you so much."
    new "واقعاً، ممنونم ازت."

    # say L1596 pla
    old "It's alright, I'm glad I was able to help you."
    new "خواهش می‌کنم، خوشحالم که بتونستم به تو کمک کنم."

    # say L1598 pla
    old "And I'm sure you'll do great on the exam."
    new "و مطمئن هستم که تو در امتحان خوب عمل می‌کنی."

    # say L1600 pla
    old "So, I'll leave for now, and I'll see you later."
    new "پس من حالا می‌روم، بعداً می‌بینیم."

    # say L1602 oli
    old "Alright, I'll be sure to let you know how I do in the exams."
    new "البته، من حتماً به تو می‌گم که امتحانم چطور بود."

    # say L1630 pla
    old "Hmm, I just remembered, I need to check my exam results when I get home."
    new "Hmm، به خاطر افتادم، باید نتایج امتحانم رو وقتی به خونه برگشتم بررسی کنم."

    # say L1637 pla
    old "Oh! Hey Olivia."
    new "اوه! هی Olivia."

    # say L1638 oli
    old "Hey, [pla]..."
    new "سلام، [pla]..."

    # say L1640 pla
    old "How did you do on the exams? Have you checked the results yet?"
    new "اولیویا، امتحاناتت چطور بود؟ نتایج رو بررسی کردی؟"

    # say L1642 pla
    old "How do you think you did on them?"
    new "فکر می‌کنی چطور امتحان دادی؟"

    # say L1644 oli
    old "Well, about that, do you think you could come with me to my house?"
    new "خب، در مورد این، فکر می‌کنی می‌تونی با من به خونه‌ام بیایی؟"

    # say L1645 pla
    old "Uh, s-sure. Is there anything wrong?"
    new "ح-حتماً. مشکلی پیش آمده؟"

    # say L1647 oli
    old "You have no idea... But I'll tell you at my house."
    new "هیچ ایده‌ای نداری... ولی تو خونه‌ام بهت می‌گم."

    # say L1648 oli
    old "Come on, let's go."
    new "بیا، برویم."

    # say L1673 vee
    old "Yeah, yeah, I know."
    new "بله، بله، می‌دونم."

    # say L1676 vee
    old "Oh my god, Vihaan! I said I got it!"
    new "اوه خدا، ویهاان! من گفتم گرفتم!"

    # say L1682 vee
    old "What do you mean my fault?"
    new "می‌خوای چی بگی اشتباه من هست؟"

    # say L1684 vee
    old "Maybe if you were here too..."
    new "شاید اگه تو هم اینجا بودی..."

    # say L1687 vee
    old "Yeah, I know..."
    new "بله، می‌دونم..."

    # say L1692 vee
    old "You know, this really isn't as bad as you're making it out to be."
    new "می‌دونی، این خیلی بد نیست مثل اینکه می‌گیه."

    # say L1693 vee
    old "Well, because this isn't the end of the world."
    new "خب، زیرا این آخر جهان نیست."

    # say L1697 vee
    old "She can always try again..."
    new "می‌تونه همیشه دوباره امتحان کنه..."

    # say L1698 vee
    old "Oh! I know full well what you think about that!"
    new "اوه! من کاملاً می‌دونم تو در مورد این چه فکری داری."

    # say L1702 vee
    old "But that's beside the point."
    new "اما اون موضوع نیست."

    # say L1712 vee
    old "And what do you propose we do about her boyfriend?"
    new "و تو پیشنهادت چیه برای دوست پسرش؟"

    # say L1716 vee
    old "Of course it's important, Vihaan!"
    new "البته مهمه، ویهاان!"

    # say L1721 vee
    old "What do you mean why?"
    new "چرا می‌گی برات؟"

    # say L1725 vee
    old "Because her feelings are important!"
    new "چون احساساتش مهم هستند!"

    # say L1729 vee
    old "I know that."
    new "می‌دونم."

    # say L1734 vee
    old "No, he's not rich."
    new "نه، او ثروتمند نیست."

    # say L1735 vee
    old "But I think that's beside the..."
    new "ولی فکر کنم این جا مهم نیست..."

    # say L1739 vee
    old "Hmm, yeah that's true."
    new "هم، بله این جوری هست."

    # say L1744 vee
    old "{b}*Sigh*{/b} Yeah, you're very right."
    new "{b}*تنفر*{/b} بله، همینجوری."

    # say L1745 vee
    old "Yeah, I guess I'll talk to her."
    new "باید باهاش صحبت کنم."

    # say L1746 vee
    old "Yes, you're right."
    new "بله، درست می‌گویی."

    # say L1748 vee
    old "You should talk to her as well."
    new "تو هم باهاش صحبت کن."

    # say L1749 vee
    old "Yeah, talk to you later then."
    new "باید بعداً با تو صحبت کنم."

    # say L1753 vee
    old "So, I guess you got what your father said in that conversation."
    new "پس فکر کنم پیام پدرت رو توی اون صحبت درک کردی."

    # say L1754 oli
    old "Yeah, I can figure."
    new "بله، متوجه شدم."

    # say L1756 aye
    old "Oh! You're in trouble!"
    new "اوه! تو مشکل داری!"

    # say L1760 aye
    old "What's the matter, sis?"
    new "چه مشکلی داری، خواهر؟"

    # say L1761 aye
    old "Is the favorite daughter not living up to expectations?"
    new "پسر عزیزم، آیا دختر مورد علاقه ما دیگر انتظارات ما رو نمی‌سازه؟"

    # say L1764 oli
    old "Why don't you shut your mouth before I shut it for you?"
    new "چرا دهنت رو بستنی قبل از اینکه من برایت ببندم؟"

    # say L1765 vee
    old "OK! That's enough."
    new "باشه! خیلی هم کافیه."

    # say L1766 vee
    old "Listen, Olivia, I don't like the attitude your father's taking on this."
    new "ولیویا، من نمی‌پسندم رفتار پدرت در این موضوع."

    # say L1767 vee
    old "But you were aware of what he wanted you to do."
    new "اما تو از آنچه او می‌خواست ازت انجام بشه آگاه بودی."

    # say L1768 vee
    old "And the only way that you could stop him from sending you to India was by getting good grades."
    new "و تنها راه برای اینکه پدرت تو رو به هند نفرستاده باشه، این بوده که نمره‌های خوبی بگیری."

    # say L1770 vee
    old "I know, I know, this isn't fair."
    new "می‌دونم، می‌دونم، این عادلانه نیست."

    # say L1771 vee
    old "But it is the way things are."
    new "اما این همین است که اتفاق می‌افتد."

    # say L1774 aye
    old "Because you're too stupid."
    new "چون تو خیلی غبی هستی."

    # say L1775 vee
    old "The point is that your dad decided that he's not going to wait for you to finish the school year."
    new "نکته اینه که پاپا تصمیم گرفت نمی‌تونه بیشتر صبر کنه تا تو سال تحصیلی رو تمام کنی."

    # say L1778 vee
    old "He told me that he wants you to start organizing your things."
    new "او به من گفت که می‌خواهد شروع کنی به مرتب‌کردن چیز‌هایت."

    # say L1782 vee
    old "After the next batch of exams, you're transferring to a school in India."
    new "بعد از آزمون‌های بعدی، تو به مدرسه‌ای در هند منتقل می‌شی."

    # say L1785 oli
    old "But that's not fair! He doesn't get to decide that for me!"
    new "ولی این عادلانه نیست! او حق نداره اینو برای من تصمیم بگیره!"

    # say L1786 vee
    old "Well, apparently he does."
    new "خب، به نظر می‌رسه همینطور است."

    # say L1790 vee
    old "And honestly, Olivia, you should've known this was going to happen."
    new "و صداقت بگم، اولیویا، باید می‌دونستی اینجوری می‌شه."

    # say L1791 vee
    old "I'm sorry, honey, but at this point, there's not a lot more that I can do for you."
    new "ببخشید، عزیزم، اما در این مرحله نمی‌تونم برات کار زیادی بکنم."

    # say L1792 aye
    old "It looks like you're taking a plane to our motherland, sis! Hahaha!"
    new "به نظر می‌رسه باید با هواپیما به وطنمون بری، خواهرت! هاهاها!"

    # say L1797 vee
    old "You shouldn't be gloating too much, young lady."
    new "نباید خیلی خوشحال باشی، دختر جوان."

    # say L1799 vee
    old "With the way your grades are going, you'll be joining your sister."
    new "با این نمرات، خواهی با خواهرت همراه شد."

    # say L1805 vee
    old "You heard me, your father wasn't only talking about Olivia."
    new "شوستی، پدرت فقط در مورد اولیویا نبود."

    # say L1806 vee
    old "And your grades aren't much better than hers."
    new "و نمراتت هم خیلی بهتر از نمراتش نیست."

    # say L1807 aye
    old "But, I mean... Mom!"
    new "اما من قصه‌ای نمی‌گم... مامان!"

    # say L1810 vee
    old "We'll talk about this later, I have to run some errands."
    new "بعداً درباره این صحبت می‌کنیم، باید کارهایی رو انجام بدم."

    # say L1814 vee
    old "Listen, honey, I'm sorry about this, but I guess that's just how it is."
    new "بچه عزیزم، خیلی متاسفم اما به نظر می‌رسه همینطور هست."

    # say L1820 aye
    old "Wait, Mom, let me go with you! We still need to talk about Dad!"
    new "پیش برو، مامان، بیا من هم با تو برسم! هنوز باید درباره پاپا صحبت کنیم."

    # say L1829 oli
    old "I imagine you can guess what happened..."
    new "فکر کنم بتوانی حدس بزنی چه اتفاقی افتاده..."

    # say L1830 pla
    old "I think so... The exams didn't go well?"
    new "فکر کنم همینه... امتحانات خوب نرفتند؟"

    # say L1832 oli
    old "They didn't."
    new "نگه نداشتند."

    # say L1833 pla
    old "But you studied so hard."
    new "ولی تو خیلی سخت مطالعه کردی."

    # say L1835 oli
    old "I did, and you did a great job teaching me [pla]."
    new "من هم اینجوری کردم و تو هم خوب آموزش دادی من [pla]."

    # say L1836 oli
    old "But when I was taking the exams, I couldn't focus."
    new "ولی وقتی امتحان می‌دادم، نمی‌تونستم تمرکز کنم."

    # say L1838 oli
    old "I just kept thinking about how important it was to get top marks."
    new "فقط به اهمیت گرفتن نمره‌های بالا فکر می‌کردم."

    # say L1840 oli
    old "And the more I thought about it, the more scared I got."
    new "و هر چه بیشتر در مورد اون فکر می‌کردم، بیشتر می‌ترسیدم."

    # say L1842 oli
    old "In the end, I couldn't answer anything correctly."
    new "در نهایت، هیچ پاسخ درستی ندادم."

    # say L1844 pla
    old "I mean, I get it."
    new "من می‌فهمم."

    # say L1846 pla
    old "With that much pressure, it would be hard to do well."
    new "با اون همه فشار، سخته خوب کار کنی."

    # say L1847 pla
    old "I'm sorry, Olivia."
    new "من خواهش می‌کنم، Olivia."

    # say L1848 oli
    old "Well, it happens. Nothing I can do about it."
    new "خب، اینجوری شد. هیچ کاری نمی‌تونم بکنم."

    # say L1849 oli
    old "But that doesn't mean I won't deal with this."
    new "اما این به معنای این نیست که من با این موضوع برخورد نخواهم کرد."

    # say L1850 pla
    old "Oh... Okay, what do you have in mind?"
    new "اوه... خب، چه کاری به ذهن تو رسیده؟"

    # say L1852 oli
    old "Well, this is going to surprise you."
    new "خب، این چیزی هست که شوکت می‌کنه."

    # say L1854 oli
    old "But I don't have an easy way to say this."
    new "ولی راه آسانی برای این ندارم."

    # say L1858 pla
    old "W- WHAT?! What are you talking about?!"
    new "و- وای! در مورد چی حرف می‌زنی؟!"

    # say L1860 oli
    old "You heard me, I'm going to get pregnant."
    new "من قراره باردار شم."

    # say L1861 pla
    old "Yeah, that doesn't explain anything."
    new "بله، این هیچ چیز رو توضیح نمی‌ده."

    # say L1863 pla
    old "I'm sorry, like an actual pregnancy?"
    new "ببخشید، مثل یه بارداری واقعی؟"

    # say L1864 pla
    old "Or are you talking about pretending to be pregnant?"
    new "یا می‌خوای از حامله شدن بازی کنی؟"

    # say L1865 oli
    old "No, I mean literally pregnant."
    new "نه، من واقعاً باردار می‌شوم."

    # say L1866 pla
    old "W- what? B- but why?"
    new "و- وای! ب- ولی چرا؟"

    # say L1868 oli
    old "Because it's the only way to change my circumstances."
    new "چون این تنها راه برای تغییر شرایط منه."

    # say L1870 pla
    old "That's putting it mildly!"
    new "این هم خیلی ملایم گفتن!"

    # say L1872 pla
    old "Is this what you want? To be a mother?"
    new "این همینه که می‌خوای؟ مادر شدن؟"

    # say L1874 oli
    old "I don't."
    new "من نمی‌خوام."

    # say L1875 oli
    old "Or at least not yet."
    new "یا حداقل هنوز نمی‌خوام."

    # say L1877 pla
    old "Then why do you want to get pregnant?"
    new "پس چرا می‌خوای باردار شی؟"

    # say L1879 oli
    old "Getting pregnant doesn't automatically mean I have to be a mother [pla]!"
    new "حمل شدن به معنای این نیست که باید مادر بشم [pla]!"

    # say L1881 oli
    old "I don't plan on carrying the pregnancy to term."
    new "من قصد ندارم بارداری رو تا پایان بردم."

    # say L1883 oli
    old "I just want to get rid of this whole {i}'arranged marriage'{/i} thing."
    new "من فقط می‌خوام از همه این زنگ‌زدگی‌های {i}آرایش شده‌ی ازدواج{/i} بره‌ام."

    # say L1884 pla
    old "And how would that work?"
    new "و این چطور کار می‌کنه؟"

    # say L1886 oli
    old "In our culture, when a woman is arranged to marry, she's expected to be virtuous."
    new "در فرهنگ ما، وقتی یک دختر برای ازدواج تعهدی می‌شود، از او انتظار می‌رود که محترمانه باشد."

    # say L1888 oli
    old "Nowadays, there's no way to ensure that the girl is a virgin."
    new "امروزه راهی برای اطمینان حاصل کردن از اینکه دختر بکار نیومده هست، وجود نداره."

    # say L1889 oli
    old "So that tends to be overlooked."
    new "پس این مورد معمولاً نادیده گرفته می‌شود."

    # say L1891 oli
    old "But a pregnancy is a very different thing."
    new "ولی بارداری چیزی خیلی متفاوته."

    # say L1893 oli
    old "The family of the guy my dad chose for me is very illustrious and traditional."
    new "پدرم برایم شوهری انتخاب کرده که خانواده‌اش بسیار مشهور و سنتی هستند."

    # say L1895 oli
    old "If they find out I'm pregnant, they'll cancel it immediately."
    new "اگر بفهمند من باردار شده‌ام، فوراً آن را لغو می‌کنند."

    # say L1897 oli
    old "And better yet, once the word spreads, it'll be impossible for my father to arrange another marriage for me."
    new "و بهتر از همه، وقتی خبر پخش شد، برای پدرم غیرممکن خواهد بود که دوباره ازدواج من را تنظیم کند."

    # say L1898 pla
    old "You seem very certain this will work."
    new "مطمئن به نظر می‌رسه که این کار کار می‌کنه."

    # say L1900 oli
    old "Well, because I've seen something like it."
    new "خب، چون من چیزی مشابه این رو دیده‌ام."

    # say L1902 oli
    old "I have this cousin who was in a similar situation a couple of years ago."
    new "من یه خواهر برادری دارم که چند سال پیش در موقعیت مشابهی بود."

    # say L1903 oli
    old "The difference is that she actually wanted to get married."
    new "تفاوت اینجاست که او واقعاً می‌خواست ازدواج کنه."

    # say L1905 oli
    old "The guy my uncle selected for her is a doctor who lives in Delhi."
    new "پسری که عموی من برایش انتخاب کرده بود دکتری بود و در دهلی زندگی می‌کرد."

    # say L1906 oli
    old "So on paper, she had the perfect deal."
    new "پس روی کاغذ، او توافق کاملی داشت."

    # say L1909 oli
    old "The problem came when she went to a party and hooked up with some guy."
    new "مساله وقتی پیش اومد که او به یه جشن رفت و با یه مردی رابطه برقرار کرد."

    # say L1910 oli
    old "That's not a big deal, but she wasn't careful and ended up getting pregnant."
    new "این خیلی مهم نیست، ولی او مراقبت کافی نکرد و در نتیجه باردار شد."

    # say L1911 oli
    old "She tried to keep it under wraps while she dealt with it."
    new "او سعی کرد این موضوع رو پوشش بده و اون رو حل کنه."

    # say L1913 oli
    old "But that kind of thing is almost impossible to keep hidden in a place like Delhi, to be honest."
    new "ولی اون جوری چیزی در جایی مثل دهلی تقریباً غیرممکنه هست که پوشش داده بشه، صداقت بگم."

    # say L1915 oli
    old "So, her marriage was canceled almost immediately, there was nothing she could do."
    new "پس از آن، ازدواجش تقریباً همینطور لغو شد، هیچ کاری نمی‌تونست کنه."

    # say L1917 oli
    old "Moreover, she hasn't been able to get a single meeting to arrange a marriage."
    new "البته، او حتی جلسه‌ای برای تعیین ازدواج نتونسته به ترتیب بذاره."

    # say L1918 oli
    old "Much less a fiancé."
    new "بله، حتی نامزدی هم نداره."

    # say L1919 pla
    old "Wow, is it really like that?"
    new "وای، واقعاً همینجوری؟"

    # say L1921 oli
    old "Of course it is."
    new "البته همینطور است."

    # say L1923 oli
    old "It's not good to say, but once a woman gets pregnant, she's no longer seen as virtuous."
    new "گفتن این خوب نیست، ولی وقتی زن باردار می‌شود، دیگر به عنوان محترم دیده نمی‌شود."

    # say L1925 oli
    old "Rather as {i}'damaged goods.'{/i} Ugh!"
    new "بله، به عنوان {i}کالای خراب شده.{/i} اوه!"

    # say L1927 oli
    old "But yeah... That's why I believe my idea will work."
    new "ولی بله... همین جوری فکر می‌کنم ایده‌ام کار می‌کنه."

    # say L1929 pla
    old "Still, it sounds so drastic."
    new "همچنان، این به نظر می‌رسه خیلی شدید."

    # say L1931 pla
    old "Don't you think there's anything less... extreme you could do?"
    new "می‌تونی چیزی کم‌تر شدید بکنی؟"

    # say L1932 pla
    old "How about taking other exams?"
    new "دیگه امتحان‌هایی بده؟"

    # say L1934 oli
    old "What will that do? You already heard my mother, my dad won't even let me finish the year."
    new "این چه کاری می‌کنه؟ تو قبلاً صدای مادرم رو شنیدی، پدرم حتی نمی‌تونم سال رو تمام کنم."

    # say L1936 oli
    old "And to be honest [pla], I don't think that was ever a real option."
    new "و صداقت بگم [pla]، هرگز این یه گزینه واقعی نبود."

    # say L1938 oli
    old "I think he was just entertaining my mom, but his real plan has always been to get me married to someone in India."
    new "فکر می‌کنم فقط مادرم رو خوشحال می‌کرد، اما برنامه واقعی پدرم همیشه ازدواج من با کسی در هند بوده."

    # say L1940 oli
    old "But that's not what I want for myself [pla]!"
    new "اما این همچین چیزی نیست که من برای خودم بخوام [pla]!"

    # say L1941 oli
    old "Life in an arranged marriage is restrictive."
    new "زندگی در ازدواج آرایشی محدود است."

    # say L1943 oli
    old "You're not your own person; everything you want to do or have has to come through your husband."
    new "تو خودت نیستی؛ هر چی می‌خوای بکنی یا داشته باشی باید از طریق شوهرت بیاد."

    # say L1944 oli
    old "Any social life you might want or access depends on him."
    new "هر گونه زندگی اجتماعی که می‌خوای یا دسترسی بهش داشته باشی، بستگی بهش داره."

    # say L1946 oli
    old "In the best case, the guy will be understanding and permissive. And you can imagine how it is at the worst."
    new "در بهترین حالت، مرد فهمیده و مجازات نمی‌دهه. و می‌تونی فکر کنی چطور در بدترین حالت."

    # say L1948 oli
    old "I don't want that for myself! Why do I have to marry some guy I don't know just so my dad can make money from it?!"
    new "من نمی‌خوام اینجوری باشم! چرا باید با یه مردی که نمی‌شناسم ازدواج کنم تا پدرم ازش پول ببره؟!"

    # say L1949 oli
    old "So, if I have to get pregnant to stop myself from being married to some guy I don't know, I'll gladly do it."
    new "پس اگه باید باردار شم تا از این ازدواج با یه نفر ناشناخته جلوگیری کنم، خوشحالانه این کار رو می‌کنم."

    # say L1951 pla
    old "I see, but are you sure you can do this?"
    new "ببین، اما مطمئنی که می‌تونی این کار رو بکنی؟"

    # say L1953 pla
    old "I mean, interrupting a pregnancy's not easy."
    new "من قصد دارم بگم، قطع بارداری آسون نیست."

    # say L1957 oli
    old "Well, abortion is legal and pretty common these days."
    new "خب، سقط جنین امروزه قانونی و خیلی رایجه."

    # say L1959 oli
    old "I know a girl who got one."
    new "من یه دختر می‌شناسم که سقط جنین کرده."

    # say L1962 oli
    old "Yeah, she's a friend of Ruby."
    new "بله، او دوستی از روบی هست."

    # say L1964 oli
    old "She got pregnant from a one-night stand with her ex-boyfriend."
    new "او از یک شب با دوست پسر سابق خود باردار شد."

    # say L1965 oli
    old "But she went to the hospital to get an abortion, and it went very well. You know?"
    new "ولی او به بیمارستان رفت تا سقط جنین کند، و همه خوب پیش رفت. میدونی؟"

    # say L1966 pla
    old "I see... I think I get it."
    new "می‌بینم... فکر کنم متوجه شدم."

    # say L1967 oli
    old "That's right, so you see it now, it's not a bad plan."
    new "درسته، پس حالا می‌بینی، این برنامه بد نیست."

    # say L1971 pla
    old "{i}(And she did tell me that I had to get as many women as I could pregnant.){/i}"
    new "{i}(و او به من گفت که باید هر چه بیشتر زن رو باردار کنم.){/i}"

    # say L1973 pla
    old "No, it isn't a bad plan."
    new "نه، این یه برنامه بد نیست."

    # say L1975 oli
    old "And... That's more or less where you come in."
    new "و... اینجاست که تو وارد می‌شی."

    # say L1976 oli
    old "Listen [pla], our original deal is already fulfilled."
    new "بگوش [pla]، قرار اولیه ما قبلاً انجام شده."

    # say L1978 oli
    old "I didn't pass my exams, but you still helped me the best way you could."
    new "من امتحاناتم رو نگذوندم، اما تو بهترین طریقی که می‌تونستی به من کمک کردی."

    # say L1979 oli
    old "So I wouldn't tell you that you have to get me pregnant."
    new "پس من نمی‌گم باید برام بچه بیاری."

    # say L1981 oli
    old "But if I'm honest, it's hard for me to think of a better person to ask."
    new "ولی اگر صادقانه باشم، سخته برایم کسی بهتر از تو رو برای این کار به ذهن بیاندازم."

    # say L1982 oli
    old "You know my situation in a way that I couldn't explain to anyone else."
    new "تو می‌دونی وضعیت من رو به چجوری نمی‌تونم برای هیچ‌کس دیگه توضیح بدم."

    # say L1984 oli
    old "And you wouldn't have to worry about it, all I need is your seed."
    new "و تو نباید نگرانش باشی، فقط به بذرتو نیاز دارم."

    # say L1985 oli
    old "And I would take care of everything regarding the pregnancy and the interruption."
    new "و من همه چیز مربوط به بارداری و قطع‌کاری را بر عهده می‌گیرم."

    # say L1987 oli
    old "But I would understand if you didn't want to do it."
    new "اما من درک می‌کنم اگر نخواستی این کار رو انجام بدی."

    # say L1989 pla
    old "Actually, I was thinking that I wanted to help you with it."
    new "در واقع من فکر می‌کردم که می‌خوام توی این کار بهت کمک کنم."

    # say L1991 pla
    old "What you say is true. I am fully aware of your situation, both with your parents."
    new "این حرفت درسته. من کاملاً آگاهم از وضعیتت، هم با والدینت."

    # say L1993 pla
    old "And what you're doing to try and deal with it."
    new "و همین‌طور از چیزی که برای مقابله باش انجام می‌دی مطلع هستم."

    # say L1994 pla
    old "So I agree that I'm probably the best person to help you with this."
    new "پس موافقم که احتمالاً من بهترین شخص هستم که بتونم بهت کمک کنم."

    # say L1996 pla
    old "Also, I'm really against what your parents are putting you through, you know?"
    new "همچنین، خیلی مخالف هستم با آنچه والدینت به تو می‌کنند، می‌دونی؟"

    # say L1998 pla
    old "I don't think it's fair at all that you have to live your life the way they want you to."
    new "من فکر نمی‌کنم عادلانه باشه که تو باید زندگیت رو مثل آنچه اونا می‌خواهند بزنی."

    # say L1999 pla
    old "So I'll help you get out of it."
    new "پس من بهت کمک می‌کنم تا از این وضعیت خارج شی."

    # say L2003 oli
    old "OK, let's go to my room."
    new "باشه، بیای به اتاقم."

    # say L2004 pla
    old "W- what? Do it now?"
    new "و- وای، حالا؟"

    # say L2005 oli
    old "Yeah, of course. I don't think there's a better time for it."
    new "بله، البته. فکر نمی‌کنم زمان بهتری برای این باشه."

    # say L2006 oli
    old "My mom will be out with Ayesha running errands until late."
    new "مامانم تا شام با آیشا برای کارهای خانه خارج خواهد بود."

    # say L2008 oli
    old "And we don't have much time. I need to get pregnant soon."
    new "و وقت زیادی نداریم. باید زودتر باردار شوم."

    # say L2009 oli
    old "So we should do it now."
    new "پس باید الان انجام بدیم."

    # say L2026 oli
    old "Ok, so... Uhh, let's do it..."
    new "خب، پس... اوه، بیا بذار بکنم..."

    # say L2027 pla
    old "Uhh... Yeah, yeah..."
    new "اوه... بله، بله..."

    # say L2028 oli
    old "Well... Uhh, where do we start? I mean, I know how to do it, but... Uhhh you get what I mean..."
    new "خب... اوه، از کجا شروع کنیم؟ من می‌دونم چطور باید انجام بشه، ولی... اوه، می‌فهمی مثلاً..."

    # say L2030 pla
    old "Uhh... Well, I think, we should... Uhh..."
    new "اوه... خب، فکر کنم باید... اوه..."

    # say L2032 oli
    old "You know what, this is silly, we don't have time for this. After all, I've already sucked your cock..."
    new "دیوید، این خنده‌داره، وقت ما رو نمی‌تونیم بگذرونیم اینجوری. در نهایت، من قبلاً نی تو رو شصت کردم..."

    # say L2034 oli
    old "Alright, I'll start, after all, I'm the one who needs your help with this."
    new "باشه، من شروع می‌کنم، هر جوری من هستم که از تو کمک می‌خوام."

    # say L2043 oli
    old "Does this feel good?"
    new "این خوبه؟"

    # say L2044 pla
    old "U- uh, yeah..."
    new "اوه، بله..."

    # say L2045 oli
    old "I have to say, you have a big... dick..."
    new "باید بگم، تو یه... ناخن بزرگی داری..."

    # say L2046 pla
    old "Uhh, thanks..."
    new "اوه، ممنون..."

    # say L2055 oli
    old "Alright! That was great [pla]!"
    new "البته! اون هم خوب بود [pla]!"

    # say L2056 oli
    old "It may be too soon to know if I'm pregnant yet, but I'll take a test as soon as I can and let you know."
    new "ممکنه هنوز زود باشه تا بدونیم اگه باردار شدم، ولی هر چه زودتر آزمون می‌گیرم و به تو می‌گم."

    # say L2058 pla
    old "Alright, that sounds good."
    new "البته، این خوبه."

    # say L2060 oli
    old "Thanks again for helping me [pla]."
    new "ممنونم دوباره که به من کمک کردی [pla]."

    # say L2062 pla
    old "It's alright, I'm happy to help."
    new "باشه، خوشحالم که کمکت کنم."

    # say L2064 oli
    old "Anyway, I think you should get going before my mom gets back."
    new "بازهم، فکر می‌کنم باید بروی قبل از اینکه مامان برگرده."

    # say L2065 pla
    old "Oh! Right, sure, I'll see you later."
    new "اوه! درسته، البته، ببینم بعداً."

    # say L2068 oli
    old "And hey, thank you again."
    new "و بله، ممنون دوباره."

    # say L2092 pla
    old "Hey! Brixxida! I have some very good news for you!"
    new "هی! بریکسیدا! خبر خوبی برایت دارم!"

    # say L2095 pla
    old "Well, I made an advancement in our plans!"
    new "خب، پیشرفتی در برنامه‌مون کردم!"

    # say L2098 pla
    old "Our plan of getting women pregnant."
    new "بریکسیدا، برنامه‌ی بارداری زنان رو پیش برده‌ام."

    # say L2099 pla
    old "You know, so we can use their magical power to feed the portal to the magic world."
    new "می‌دونی، تا بتونیم از قدرت جادوییشون برای تغذیه دروازه به دنیای جادو استفاده کنیم."

    # say L2101 bri
    old "Okay? How did you make this {i}'advancement?'{/i}"
    new "باشه؟ چطور این پیشرفت رو ایجاد کردی {i}'پیشرفت؟'{/i}"

    # say L2103 pla
    old "Well, I have this friend from school who asked me for some help studying."
    new "خب، من یه دوست دارم از مدرسه که از من پرسید به او در درس کمک کنم."

    # say L2105 pla
    old "As we studied, we got closer, and I got to know her."
    new "در هنگام مطالعه، به هم نزدیک شدیم و او رو بهتر شناختم."

    # say L2106 pla
    old "It turns out that her problems were a lot bigger than just school."
    new "مشکلاتش بزرگتر از مدرسه بودند."

    # say L2108 pla
    old "And that the only way out of them was to get pregnant."
    new "و اینکه تنها راه خروج از مشکلاتش همین بود، باردار شدن."

    # say L2110 bri
    old "So... You're telling me that you got this woman pregnant?"
    new "پس... می‌گیه این دختر رو باردار کردی؟"

    # say L2112 pla
    old "I did!"
    new "من انجام دادم!"

    # say L2113 pla
    old "Or at least I think I did, she told me she was going to take a pregnancy test."
    new "یا حداقل من اینجور فکر می‌کنم، او به من گفت که قراره یه تست بارداری ببره."

    # say L2117 bri
    old "You heard me!"
    new "من به تو گفتم!"

    # say L2118 bri
    old "Did you forget what I told you last time?"
    new "آیا فراموش کردی چیزی که به تو گفتم آخر؟"

    # say L2119 pla
    old "Uhmm- We need the magic?"
    new "اوه- ما به جادو نیاز داریم؟"

    # say L2121 bri
    old "No! You idiot!"
    new "نه! دیوانه‌تو!"

    # say L2123 bri
    old "What I told you is that I had to be there when you have sex with the girl!"
    new "من به تو گفتم که باید حاضر باشم وقتی تو با دختر می‌پزیری!"

    # say L2126 bri
    old "Ugh, try to pay attention when I speak to you."
    new "اوه، وقتی با تو صحبت می‌کنم تلاش کن توجه کنی."

    # say L2127 bri
    old "Listen, it's not just about you getting her pregnant and that's it."
    new "بگو، این فقط درباره این نیست که تو اون رو باردار کنی و تمام شه."

    # say L2128 bri
    old "I have to be there to perform a ritual while it's happening."
    new "من باید در همان زمان مراسم رو انجام بدم."

    # say L2131 bri
    old "Of course! Otherwise, it would just be a regular pregnancy."
    new "البته! در غیر این صورت فقط یک بارداری معمولی خواهد بود."

    # say L2132 bri
    old "That's why it's so bad that you just went ahead and tried to get her pregnant!"
    new "این به همین خاطر هست که اینقدر بد بود تو فقط رفته و سعی کردی براش باردار شه!"

    # say L2133 bri
    old "Because if she is, then we will have lost the chance of getting a girl pregnant."
    new "چون اگه هست، شانس ما برای باردار کردن یه دختر از دستمون بره."

    # say L2135 bri
    old "And we'll have to look for another person."
    new "و باید به دنبال کسی دیگری بریم."

    # say L2140 pla
    old "If that's true, why weren't you there when I had sex with Barbie and got her pregnant?"
    new "اگر اینجوریه، چرا تو وقتی من با باربی سکس کردم و باردارش کردم، جایی نبودی؟"

    # say L2142 bri
    old "Who says that I wasn't?"
    new "چه کسی می‌گه من نبودم؟"

    # say L2145 bri
    old "Think about it [pla], where did you do it with Barbie the first time?"
    new "فکر کن [pla]، اولین بار تو با باربی کجا انجام دادی؟"

    # say L2146 pla
    old "Uhm, we did it here."
    new "هم، ما اینجا انجام دادیم."

    # say L2148 bri
    old "Exactly, and this is where I spend most of my time."
    new "دقیقاً، و اینجا بیشتر وقت رو می‌گذونم."

    # say L2149 bri
    old "I'm either at the garage, taking care of the portal."
    new "می‌تونم هم در گاراژ باشم، در حال مراقبت از دروازه."

    # say L2150 bri
    old "Or I'm here resting."
    new "یا اینجا هستم و استراحت می‌کنم."

    # say L2151 bri
    old "So last time, when you arrived with Barbie, I was able to initiate the spell when you two started to have sex."
    new "پس آخر بار، وقتی تو با باربی اومدی، من بتونم جادو رو شروع کنم وقتی شما دو تا شروع کردید به سکس کردن."

    # say L2152 bri
    old "Otherwise it would've been wasted."
    new "در غیر این صورت ضایع می‌شد."

    # say L2154 bri
    old "Yeah... Luckily that time we were fine."
    new "بله... خوشحالم که آن بار همه چیز درست بود."

    # say L2155 bri
    old "But I'm not omnipresent [pla]."
    new "اما من همه‌جا نیستم [pla]."

    # say L2156 bri
    old "Now there's a chance that girl is pregnant and we may have lost our next chance."
    new "البته حالا احتمال داره آن دختر باردار شده باشه و شاید فرصت بعدیمون رو از دست دادیم."

    # say L2157 pla
    old "I- I'm sorry Brixxida, I should have talked it over with you before I had sex with her."
    new "بریکسیدا، من- من خیلی متاسفم، باید قبل از اینکه با او جنسیت کردم با تو صحبت کردم."

    # say L2158 pla
    old "But I mean, there's still a chance that she's not pregnant."
    new "ولی منظورم اینه که هنوز امکان داره باردار نباشه."

    # say L2160 bri
    old "Hmph, for your sake, we better hope she isn't."
    new "همف، برای خوبی تو، بهتره امیدوار باشیم که حامله نشده باشه."

    # say L2162 bri
    old "Now, in order for this to not happen again."
    new "الان، برای اینکه این جوری دوباره نشه."

    # say L2163 bri
    old "I think I should teach you a summoning spell."
    new "فکر می‌کنم باید به تو جادوی فراخوانی یاد بدم."

    # say L2164 bri
    old "So that this doesn't happen again."
    new "تا اینجوری دوباره نباشد."

    # say L2166 pla
    old "S- summoning spell?!"
    new "س- جادوی فراخوانی؟!"

    # say L2167 bri
    old "Right, this isn't the most complicated spell, so you should be able to master it easily."
    new "درست است، این جادوی پیچیده‌ای نیست، پس باید بتونی به راحتی آن را یاد بگیری."

    # say L2168 bri
    old "And it's good that you know it."
    new "و خوشحالم که این رو بلدی."

    # say L2169 bri
    old "So that you can call on me whenever you see yourself in a situation where you think we can start the ritual with someone."
    new "تا وقتی که به یادت بری اگر فکر کردی می‌تونیم با کسی مراسم رو شروع کنیم، می‌تونی به من تماس بگیری."

    # say L2170 pla
    old "I see... Alright, so how does this spell work?"
    new "می‌بینم... خوب، این جادویی چطور کار می‌کنه؟"

    # say L2171 bri
    old "I'll tell you, get your SexNote out."
    new "بیا، SexNoteتو بیرون بیاور."

    # say L2175 bri
    old "Alright, I'll explain everything to you, pay attention."
    new "باشه، همه چی رو به تو توضیح می‌دم، دقت کن."

    # say L2184 bri
    old "Alright, that should be enough for now."
    new "البته، اینقدر برای حالا کافی است."

    # say L2185 bri
    old "With that, you should be able to do the spell properly without needing any kind of help from my end."
    new "با این، باید بتونی جادو رو بدون هیچ راهنمایی از من درست انجام بدی."

    # say L2187 pla
    old "I got it, I'll keep that in mind."
    new "فهمیدم، به خاطر می‌سپارم."

    # say L2190 pla
    old "By the way, since you say it isn't a normal pregnancy."
    new "با هر حال، چون می‌گی‌ی این بارداری عادی نیست."

    # say L2192 pla
    old "How is a magical pregnancy different from a normal one?"
    new "حمل جادویی از حمل عادی چطور متفاوت است؟"

    # say L2195 bri
    old "Listen, in general, she'll have more or less the same experience she would if this was a normal, human pregnancy."
    new "بله، به طور کلی، او تجربه‌ای مشابه با هر بارداری عادی انسانی خواهد داشت."

    # say L2196 bri
    old "But there will be two big differences."
    new "اما دو تفاوت بزرگ خواهد بود."

    # say L2197 bri
    old "The first one is that it's going to be a lot faster than it would normally be."
    new "اول اینه که خیلی سریع‌تر از معمول پیش می‌رود."

    # say L2198 bri
    old "Since she'll be concentrating magic power within her."
    new "چون او قدرت جادویی رو درون خود متمرکز می‌کنه."

    # say L2199 bri
    old "It's different from woman to woman, but it should be about a third of the time."
    new "البته از زن به زن متفاوت است، اما باید حدود سوم زمان معمول باشد."

    # say L2201 bri
    old "Maybe even a fourth, who knows."
    new "شاید حتی یک چهارم هم باشد، کی می‌دونه."

    # say L2204 bri
    old "Well, if you're going to be a father or not depends on whether or not she'll have the {i}'baby'{/i}."
    new "خب، اینکه تو پدر می‌شی یا نه بستگی به این داره که آیا او ز{i}بچه{/i}‌اش رو می‌آره یا نه."

    # say L2206 bri
    old "Either way, it doesn't make a difference for us."
    new "هر دوی ما فرقی نمی‌کنه."

    # say L2207 pla
    old "It doesn't?"
    new "نه؟"

    # say L2208 pla
    old "That's good to hear."
    new "خوشحالم که اینجوری شنیدم."

    # say L2210 bri
    old "Yeah, what we're doing is using the pregnancy to concentrate the magic in her body."
    new "بله، آنچه که انجام می‌دهیم این است که بارداری را برای تمرکز جادو در بدن او استفاده می‌کنیم."

    # say L2212 bri
    old "The baby itself is not actually important to our plans."
    new "خود بچه برای برنامه‌های ما اهمیت واقعی نداره."

    # say L2214 bri
    old "So, when the moment comes to harvest the magic, it can be done either by the baby being born."
    new "پس وقتی لحظه برداشت جادو می‌رسه، می‌تونه هم با تولد بچه انجام بشه."

    # say L2215 bri
    old "Or by the pregnancy being interrupted."
    new "یا با قطع شدن بارداری."

    # say L2217 bri
    old "It doesn't matter, as long as I can harvest the magic growing within her."
    new "هم اهمیتی نداره، مادامی که بتونم جادگی رو که درونش رشد می‌کنه برداشتم."

    # say L2220 bri
    old "By the way, there's another small difference with a normal pregnancy you have to look out for."
    new "البته، همینطور یه تفاوت کوچیکی هست که باید بهش توجه کنی."

    # say L2222 bri
    old "This pregnancy will come with the added need for magic power within her system."
    new "این بارداری با نیاز اضافی به توان سحر درون او همراه خواهد بود."

    # say L2224 bri
    old "As the baby grows in her womb, she'll naturally absorb it from the environment."
    new "با رشد جنین در رحم، او به طور طبیعی آن را از محیط جذب خواهد کرد."

    # say L2225 bri
    old "But you can expect that she'll still feel the need for sex. Much like how us shinigami need it from you."
    new "اما می‌تونی انتظار داشته باشی که هنوز به جنس نیاز داشته باشه. مثل ما شینیگامی که از تو نیاز داریم."

    # say L2227 bri
    old "You'll probably have to have sex with her once in a while during her pregnancy."
    new "باید احتمالاً گاهی هم در دوران بارداری باهاش جنسیت داشته باشی."

    # say L2228 bri
    old "So that's a very good thing for you."
    new "پس این برای تو خیلی خوبه."

    # say L2232 pla
    old "I understand, and I'm sorry I didn't let you know about it before doing it."
    new "من متوجه شدم، و ببخشید که قبل از انجامش تو را آگاه نکردم."

    # say L2233 pla
    old "I'll talk to her, and I'll let you know how things evolve."
    new "باهاش حرف بزنم و اطلاعات جدید رو بهت می‌دم."

    # say L2234 bri
    old "Alright, I'll be waiting for the news."
    new "باشه، منتظر خبرت می‌مونم."

    # say L2254 pla
    old "Hey Olivia, I came to-"
    new "اولیویا، اومدم تا-"

    # say L2256 oli
    old "I can't believe this! I just can't believe it!"
    new "باورم نمی‌شه! واقعاً باورم نمی‌شه!"

    # say L2258 vee
    old "I'm sorry honey, but this is not my fault."
    new "ببخشید عزیزم، اما این گناه من نیست."

    # say L2260 oli
    old "And is it my fault?"
    new "و این هم گناهم؟"

    # say L2261 vee
    old "Well, who else?"
    new "خب، چه کسی دیگر؟"

    # say L2262 oli
    old "Oh my God, I can't believe you're saying that!"
    new "اوه خدای من، نمی‌تونم باور کنم تو اینجوری می‌گی!"

    # say L2263 oli
    old "You know what this means, right?!"
    new "می‌دونی این یعنی چی، هست؟!"

    # say L2265 oli
    old "He already decided on the date of the marriage!"
    new "او قبلاً تاریخ عروسی رو تعیین کرده!"

    # say L2267 oli
    old "He can't do that! How can you just let him decide that by himself!"
    new "او نمی‌تونه اینجوری بکنه! چطور می‌تونی بهش بگی که خودش اینو تصمیم بده؟"

    # say L2269 vee
    old "This isn't my fault, Olivia!"
    new "این گناه من نیست، اولیویا!"

    # say L2270 vee
    old "I tried to help you, you know that."
    new "من سعی کردم کمکت کنم، میدونی."

    # say L2273 vee
    old "But you didn't do your part!"
    new "ولی تو خودت نکردی!"

    # say L2274 vee
    old "You knew what your father's expectations were."
    new "تو میدونستی انتظارات پاپا چی بود."

    # say L2277 vee
    old "But instead of studying to improve your grades, you decided to waste time."
    new "به جای اینکه برای بهبود نمراتت مطالعه کنی، تصمیم گرفتی وقتت رو ضایع کنی."

    # say L2278 vee
    old "What do you expect me to do for you then?"
    new "بعد از همه اینا، انتظارت از من چیه؟"

    # say L2279 vee
    old "It was up to you, and you didn't do what you had to."
    new "بوده‌ت تو، و تو انجام ندادی آنچه باید می‌کردی."

    # say L2282 oli
    old "And that means that I have to be sent away to be married to some stranger?!"
    new "و این بدان معناست که من باید برای ازدواج با یه ناشناسی دور از خانه برم؟!"

    # say L2283 oli
    old "That's my punishment for doing badly in algebra?!"
    new "این هم جایزه‌ام برای اینکه در جبر ضعیف بودم؟!"

    # say L2284 oli
    old "I can't believe you, Mom! With all that you kept talking about how you don't agree with what Dad wants to do!"
    new "من باور نمی‌کنم، مامان! با همه آن چیزهایی که همیشه می‌گفتی که با آنچه پاپا می‌خواد توافق نداری!"

    # say L2287 vee
    old "I don't agree with it! But you know that your father's word is law!"
    new "من با این توافق ندارم! اما می‌دونی که حکم پدر قانونه!"

    # say L2290 vee
    old "If you wanted to get out of it so badly, all you had to do was study."
    new "اگه همچین خواستی بیرون بری، کافی بود مطالعه می‌کردی."

    # say L2292 vee
    old "Now it's too late to cry over spilled milk."
    new "حالا خیلی دیره تا برای آبی که ریختی ناله کنی."

    # say L2294 vee
    old "You should've thought about that before wasting your time with the likes of Ruby."
    new "باید اینجوری فکر کردی قبل از اینکه وقتت رو با نفرات مثل رووبی بگذونی."

    # say L2297 vee
    old "I'm sorry honey, but this is just how it is."
    new "ببخشید عزیزم، اما همین طور هست."

    # say L2298 vee
    old "And you'll have to learn to live with it."
    new "و باید با این زندگی کنی."

    # say L2299 oli
    old "Yeah... I don't think I will."
    new "بله... فکر نمی‌کنم."

    # say L2301 oli
    old "I don't think I'll have to learn to live with it."
    new "فکر نمی‌کنم باید با این زندگی کنم."

    # say L2302 oli
    old "I won't do what dad wants me to."
    new "من نمی‌خوام آنچه پاپا می‌خواد بکنم."

    # say L2303 vee
    old "Olivia, be reasonable, how are you planning to go against your father's wishes?"
    new "اولیویا، منطقی باش، چطور می‌خوای بر خلاف آرزوی پدرت عمل کنی؟"

    # say L2305 oli
    old "I don't plan on doing anything."
    new "من هیچ کاری برنامه ندارم."

    # say L2308 oli
    old "Especially because I already did it."
    new "به خصوص اینکه قبلاً انجامش دادم."

    # say L2309 vee
    old "Okay now you're just being cryptic, what are you talking about?"
    new "خب حالا فقط داری معما می‌زنی، درباره چی حرف می‌زنی؟"

    # say L2313 vee
    old "W- what?! P- pregnant?! What do you mean?!"
    new "و- وای! ب- باردار؟! چه قصه؟!"

    # say L2316 vee
    old "When did this happen?!"
    new "وقتی این اتفاق افتاد؟!"

    # say L2318 oli
    old "Well, I only found out last week, but I wouldn't know exactly when I got pregnant."
    new "خب، هفته گذشته فهمیدم، اما دقیقاً چه زمانی باردار شدم نمی‌دونم."

    # say L2321 oli
    old "But that's how things are, Mom. I wanted to be sure before letting you know, but the situation calls for me to let you know."
    new "ولی همینجوری هست، مامان. می‌خواستم مطمئن شوم قبل از اینکه به تو بگم، ولی شرایط اجازه نداد."

    # say L2322 vee
    old "And you think this is the best moment to bring that out?!"
    new "و تو فکر می‌کنی این بهترین لحظه برای اینه؟!"

    # say L2325 vee
    old "If you already knew, you should've let us know sooner!"
    new "اگر قبلاً می‌دونستی، باید زودتر ما رو مطلع می‌کردی!"

    # say L2327 vee
    old "Do you have any idea about what this means?!"
    new "آیا هیچ ایده‌ای داری این چه معنا داره؟!"

    # say L2328 vee
    old "Do you know how your dad will react?!"
    new "می‌دونی پدرت چطور واکنش نشون می‌ده؟!"

    # say L2330 oli
    old "I don't know, but he won't be able to send me to India like this."
    new "نمیدونم، ولی پاپا نمی‌تونه منو به هند بفرسته اینجوری."

    # say L2333 vee
    old "And you think things are just going to be alright?!"
    new "و تو فکر می‌کنی همه چیز خوب می‌شه؟!"

    # say L2335 vee
    old "Your father will come here and kill [pla]!"
    new "پدرت خواهد اومد و [pla] رو می‌کشد!"

    # say L2338 vee
    old "I can't believe this from you, Olivia! Not only did you get pregnant, but you also hid it!"
    new "نمی‌تونم اینو از تو باور کنم، اولیویا! نه فقط باردار شدی، بلکه اینو هم پوشش دادی!"

    # say L2340 oli
    old "But you guys were pushing me so hard into it! I just didn't know how to!"
    new "ولی شماها مرا خیلی زور می‌زدید! من فقط نمی‌دانستم چطور باید بکنم!"

    # say L2341 vee
    old "No! I don't want to hear anything from you!"
    new "نه! نمی‌خوام از تو هیچ چی بشنوم!"

    # say L2343 vee
    old "You have no idea about what this that you're doing means."
    new "تو هیچ ایده‌ای نداری که این کاری که می‌کنی چه معنا داره."

    # say L2344 vee
    old "So I won't listen to you and I won't talk to you about it for now!"
    new "پس من به تو نمی‌گوشم و الان در مورد این با تو صحبت نمی‌کنم!"

    # say L2345 oli
    old "What? B- but!"
    new "چه؟ ب- ب- اما!"

    # say L2346 oli
    old "Ughh...!"
    new "اوه...!"

    # say L2353 pla
    old "I- Uh... E- excuse me!"
    new "ا- اوه... ب- ببخشید!"

    # say L2363 pla
    old "Hey."
    new "هی."

    # say L2366 pla
    old "Sooo... I guess you're pregnant?"
    new "پس... به نظر می‌رسه بارداری؟"

    # say L2368 oli
    old "Of course I'm not."
    new "البته نه."

    # say L2370 oli
    old "We only did it once, it can happen but we weren't lucky."
    new "ما فقط یک بار انجام دادیم، می‌تونسته بود اما شانس‌مون نبود."

    # say L2372 oli
    old "I only said that to my mom to get both her and my dad off my back."
    new "من فقط اونجوری به مامانم گفتم تا هم اونو هم بابام رو از پشت من ببرن."

    # say L2373 oli
    old "But now I have to be pregnant for real!"
    new "ولی حالا باید واقعاً باردار شم!"

    # say L2375 oli
    old "And it can't take too long."
    new "و نباید طول بکشه."

    # say L2376 oli
    old "Because they'll want to check soon for it."
    new "چون زودتر می‌خواهند بررسی کنند."

    # say L2379 pla
    old "So, s- should we do it now?"
    new "پس، باید الان انجام بدیم؟"

    # say L2382 oli
    old "Of course not!"
    new "البته نه!"

    # say L2384 oli
    old "My mom said she didn't want to talk to me for now."
    new "مama مامانم گفت که الان نمی‌خواد با من صحبت کنه."

    # say L2386 oli
    old "But be sure that she's going to barge in here any minute now."
    new "اما مطمئن باش که هر لحظه می‌تونه اینجا وارد بشه."

    # say L2388 oli
    old "Actually, I think it would be better if you leave for now."
    new "در واقع، فکر می‌کنم بهتر باشه حالا بری."

    # say L2390 oli
    old "Just to avoid an awkward situation."
    new "برای اینکه موقعیت ناخوشایندی پیش نیاد."

    # say L2391 pla
    old "Oh yeah, sure, we can talk later."
    new "اوه بله، حتماً، می‌تونیم بعداً صحبت کنیم."

    # say L2394 oli
    old "Sure, see you..."
    new "بله، ببینم..."

    # say L2422 oli
    old "Oh! [pla]!"
    new "اوه! [pla]!"

    # say L2423 oli
    old "I was just thinking that I have to talk to you."
    new "من همین جوری فکر می‌کردم باید با تو صحبت کنم."

    # say L2427 pla
    old "How did everything turn out after I left your home?"
    new "بعد از اونکه از خونت رفتی، همه چی چطور شد؟"

    # say L2428 oli
    old "Ugh, you have no idea."
    new "اوه، تو هیچ ایده‌ای نداری."

    # say L2430 oli
    old "My mom called my dad and told him everything."
    new "مامان پاپا رو تماس زد و همه چیز رو بهش گفت."

    # say L2432 oli
    old "He got incredibly angry and started screaming about honor and responsibility."
    new "او خیلی خشمگین شد و شروع کرد درباره افتخار و مسئولیت صدا بزنه."

    # say L2434 oli
    old "I'm glad it was only over the phone, I can't imagine what he would've done if I had been in front of him."
    new "خوشحالم که فقط با گوشی بود، نمی‌تونم تصور کنم اگه من جلویش بودم چه کاری می‌کرد."

    # say L2435 pla
    old "It got that bad, huh?"
    new "اینقدر بد بود، ه؟"

    # say L2437 pla
    old "I guess he's that worried about you then."
    new "باید نگران تو باشه، بچه."

    # say L2438 oli
    old "I don't think it has anything to do with me."
    new "من فکر نمی‌کنم این با من هیچ ربطی داشته باشه."

    # say L2440 oli
    old "He's just angry about having to call off the engagement."
    new "او فقط خسته از لغو خطبه است."

    # say L2441 pla
    old "Really?! That's what bothers him?"
    new "وای، واقعاً؟! این هم چیزی که او را ناراحت می‌کنه؟"

    # say L2443 oli
    old "It is, it's just an integral part of our culture [pla]."
    new "بله، این فقط بخشی از فرهنگ ماست [pla]."

    # say L2445 oli
    old "In India, an arranged marriage is something to be taken seriously."
    new "در هند، ازدواج آرایشی چیزی است که باید جدی گرفته شود."

    # say L2446 oli
    old "Because it's a promise of uniting families."
    new "چون این وعده‌ای برای اتحاد خانواده‌هاست."

    # say L2448 oli
    old "Now my dad has to go to his friend's house and explain to him why I can't get married."
    new "الان پاپا باید بره به خونه دوستش و بهش بگه چرا من نمی‌تونم ازدواج کنم."

    # say L2449 pla
    old "I see, I guess honor's very important there."
    new "می‌بینم، به نظر می‌رسه افتخار برایشون خیلی مهمه."

    # say L2451 oli
    old "It is, but if I'm honest with you, it has nothing to do with that."
    new "بله، اما صادقانه بگم، هیچ ربطی به اون نداره."

    # say L2454 oli
    old "He's just angry about losing this business."
    new "او فقط خیال می‌کنه از دست دادن این کسب و کارش خیالش می‌شود."

    # say L2456 oli
    old "Yeah, those marriages are very honorable and whatever."
    new "بله، این ازایهای خیلی افتخار‌آور هستند و همه چیز."

    # say L2458 oli
    old "But what he cares about are the business opportunities he could get by marrying his daughters to rich men."
    new "اما مهم‌تر اینه که او به دنبال فرصت‌های تجارتی است که می‌تونه با ازدواج دختر‌هاش با مردان ثروتمند بدست بیاورد."

    # say L2461 oli
    old "But it doesn't matter now."
    new "اما الان مهم نیست."

    # say L2463 oli
    old "Once the news that I'm pregnant starts spreading around, nobody will want to marry me."
    new "بازی این خبر پخش شد، هیچ‌کس نمی‌خواد با من ازدواج کنه."

    # say L2464 oli
    old "And Dad will have to leave that alone."
    new "و پاپا باید این موضوع رو گذاشته باشه."

    # say L2465 pla
    old "Ok, so it's all done, right?"
    new "باشه، پس همه چی تمام شده، درسته؟"

    # say L2469 oli
    old "Yeah, he has to get off my back, but that only means that I HAVE to get pregnant."
    new "بله، او باید از روی من برسه، اما این فقط به معنی اینه که من باید باردار شوم."

    # say L2471 oli
    old "And that's where you come in."
    new "و اینجا تو نقش خودت رو بازی می‌کنی."

    # say L2473 oli
    old "I wanted to ask you if you can come to my house with me."
    new "می‌خواستم ازت بپرسم که می‌تونی با من به خونه بیادی؟"

    # say L2474 oli
    old "My mom's going to be out with my sister running some errands."
    new "مامانم با خواهرم برای انجام کارهایی بیرون می‌ره."

    # say L2475 oli
    old "Which means I'll have the house to myself for some hours."
    new "این بدان معناست که من برای چند ساعت خانه رو به تنهایی خواهم داشت."

    # say L2477 oli
    old "That's an opportunity that we can't let pass."
    new "این فرصتیه که نمی‌تونیم از دستش بره."

    # say L2478 oli
    old "So, can you come with me to my house?"
    new "پس، می‌تونی با من به خونه‌ام بیایی؟"

    # say L2481 oli
    old "Alright! Let's not waste any time and go then."
    new "باشه! بیاین همین حالا برویم."

    # say L2502 oli
    old "Alright, are you ready for it?"
    new "خب، آماده‌ای برای این؟"

    # say L2505 oli
    old "Ok, give me a second to freshen up, and we'll do it."
    new "باشه، یه لحظه بده تا خودمو آماده کنم، بعد انجام میدیم."

    # say L2512 pla
    old "Ok, I guess now's the time to call Brixxida."
    new "باشه، به نظر می‌رسه الان وقتش هست تا بریکسیدا رو تماس ببرم."

    # say L2525 bri
    old "Wow! What's this?"
    new "واو! این چیه؟"

    # say L2527 pla
    old "Hey, this girl and I are about to start having sex."
    new "بri، این دختر و من قراره حالا جنس کنیم."

    # say L2529 pla
    old "So I summoned you to make sure everything goes well."
    new "پس تو رو فراخواندم تا مطمئن شم همه چی خوب پیش بری."

    # say L2530 bri
    old "I see, good, that's good."
    new "می‌بینم، خوب، اینجوری خوبه."

    # say L2538 oli
    old "Hey, are you ready?"
    new "سلام، آماده‌ای؟"

    # say L2539 pla
    old "Sure, sure, let's do it."
    new "بله، خوب، بیایم."

    # say L2540 oli
    old "Ok, just remember to be gentle... I'm still not used to your big cock."
    new "خب، فقط به خاطر داشته باش که نرم باش... هنوز به آن چیز بزرگت عادت نکرده‌ام."

    # say L2541 pla
    old "Sure, of course..."
    new "بله، البته..."

    # say L2559 oli
    old "I'm sure that this time it worked."
    new "مطمئنم این بار کار کرد."

    # say L2561 pla
    old "Yeah, I'm sure it did."
    new "بله، مطمئنم که انجام شد."

    # say L2562 pla
    old "At least this way you can get your family off your back a little."
    new "البته اینجوری می‌تونی یه کم از پشت سر خانوادت بره."

    # say L2565 oli
    old "Yeah, well, I wouldn't be so sure about that."
    new "بله، ولی اینجوری مطمئن نیستم."

    # say L2566 oli
    old "But let's see how everything goes."
    new "ولی بیاین ببینیم همه چیطور می‌شه."

    # say L2567 oli
    old "But now, I think you better leave before my mom comes back and sees us like this."
    new "اما حالا، بهتره قبل از برگشت مامان و دیدن ما اینجوری بروی."

    # say L2568 oli
    old "That shouldn't be a problem if we're supposed to be dating."
    new "اگه ما قراره دوست باشیم، این مشکلی نباید بشه."

    # say L2569 oli
    old "But let's not push our luck."
    new "اما بیاین شانسمون رو کش نکنیم."

    # say L2570 pla
    old "Sure, I understand. I'll leave, but I'll check on you later to see how you're doing."
    new "بله، من متوجهم. می‌روم، ولی بعداً برای دیدن حالت از تو خبر می‌گیرم."

    # say L2572 oli
    old "Thank you [pla], for everything."
    new "ممنونم [pla]، برای همه چیز."

    # say L2574 pla
    old "Alright, I'll see you later."
    new "باشه، بعداً بهت خبر می‌دم."

    # say L2591 bri
    old "I'm sure that this is going to work!"
    new "مطمئنم این کار خوب می‌شود!"

    # say L2592 bri
    old "Well done!"
    new "عالی کردی!"

    # say L2593 pla
    old "Thank you, I'm glad you're satisfied with the results."
    new "ممنون، خوشحالم که با نتایج راضی هستی."

    # say L2595 bri
    old "Of course I am."
    new "البته خوشحالم."

    # say L2596 bri
    old "And now we can move on to the next target!"
    new "و حالا می‌تونیم به هدف بعدی برویم!"

    # say L2597 pla
    old "Don't we have to make sure that everything's alright with Olivia before doing that?"
    new "باید اولاً مطمئن شیم که هر چیزی برای اولیویا خوبه، بعد این کار رو انجام بدیم."

    # say L2598 bri
    old "Oh don't worry, I'm sure that everything's going to be alright!"
    new "اوه نگران نباش، مطمئنم همه چیز خوب می‌شه!"

    # say L2599 bri
    old "There's no doubt about it."
    new "حتماً همه چیز خوب است."

    # say L2601 pla
    old "I guess I'll get to looking for new girls."
    new "باید به دنبال دختران جدید برم."

    # say L2602 pla
    old "I'll let you know what I find."
    new "ببینم چه چیزی پیدا می‌کنم، بعد بهت می‌گم."

    # say L2604 bri
    old "Great! I'll be waiting."
    new "عالی! منتظرم."

    # say L2605 bri
    old "Once again, well done [pla]."
    new "باز هم، خوب کردی [pla]."

    # say L2625 pla
    old "Hey Olivia, how are you?"
    new "اولیویا، حالت چطوره؟"

    # say L2628 oli
    old "I'm doing fine."
    new "من خوب هستم."

    # say L2629 oli
    old "Although I have to say it's been difficult to deal with my family these last few days."
    new "البته، اما روزهای گذشته با خانواده‌ام سخت بود."

    # say L2630 pla
    old "It has?"
    new "حقاً؟"

    # say L2632 oli
    old "Yeah, I got a pregnancy test done."
    new "بله، آزمون بارداری انجام دادم."

    # say L2633 oli
    old "My dad and mom wanted to make sure that I actually was pregnant and I wasn't just lying to get out of the marriage."
    new "پدرم و مادرم می‌خواستن اطمینان پیدا کنن که واقعاً باردار هستم و من فقط برای این نیستم که از ازدواج بیرون بیوم."

    # say L2634 oli
    old "So, they took me to an ob-gyn and asked them to do the test."
    new "پس، پدرم و مادرم منو به پزشک زنان برده و ازش خواستن آزمون رو برام انجام بدند."

    # say L2635 pla
    old "And? What did it say?"
    new "و؟ نتیجه چی بود؟"

    # say L2637 oli
    old "It came out positive!"
    new "مثبت بود!"

    # say L2638 oli
    old "It's good that I got pregnant when I did, because otherwise who knows what would've happened."
    new "خوشحالم که باردار شدم، چون در غیر این صورت کی می‌دونست چه می‌شد."

    # say L2639 oli
    old "I would probably be on a plane on my way to India right now."
    new "احتمالاً الان روی هواپیما برای رفتن به هند بودم."

    # say L2640 pla
    old "Well, I guess it's a good thing that you're pregnant then."
    new "خب، به نظر می‌رسه خوبه که باردار شدی."

    # say L2641 pla
    old "Does that mean that your parents are going to back off now?"
    new "این بدان معناست که والدینت حالا کمتر فشار می‌دهن؟"

    # say L2642 oli
    old "Well, not really, if anything I think they'll just get even more intense."
    new "خب، نه، احتمالاً حتی شدید‌تر خواهند شد."

    # say L2644 oli
    old "My dad's incredibly furious right now."
    new "پدرم الان خیلی خشمگین است."

    # say L2645 oli
    old "You should've seen him, talking about how his good name is being dragged through the mud."
    new "باید اون رو دیدی، درباره اینکه اسم خوبش رو تو خاک می‌کشند می‌گفت."

    # say L2646 oli
    old "They also told me to let you know that you should get ready for a marriage."
    new "همچنین به تو گفتند که باید آماده‌ی ازدواج بشی."

    # say L2647 oli
    old "Because there's no way that I'm having a bastard child."
    new "چون هیچ راهی ندارم که بچه‌ای غیر از شادی نداشته باشم."

    # say L2649 pla
    old "W- what? M- marriage?"
    new "و- وای؟ از- ازدواج؟"

    # say L2650 pla
    old "B- but I thought you said that wasn't going to happen."
    new "B- ولی فکر می‌کردم می‌گی‌ای اینجوری نمی‌شه."

    # say L2652 oli
    old "And it probably won't, because I won't let it come to that."
    new "و احتمالاً هم نخواهد افتاد، زیرا من نمی‌گذaram به این جهت برود."

    # say L2654 oli
    old "Besides, remember that the plan is to interrupt the pregnancy before it gets to term."
    new "البته، به خاطر داشته باش که برنامه ما قطع بارداری قبل از رسیدن به مرحله تولد است."

    # say L2656 oli
    old "So there is some pressure because of it."
    new "پس بر این اساس فشاری هست."

    # say L2658 oli
    old "But I don't think my mom's going to consult you about wedding plans anytime soon."
    new "ولی فکر نمی‌کنم مامانم قراره ازت در مورد برنامه‌های عروسی مشورت بکنه."

    # say L2659 pla
    old "I see... I guess that's a little reassuring."
    new "می‌بینم... به نظر می‌رسه کمی آرام‌بخش هست."

    # say L2660 oli
    old "But anyway, that's not what's most important."
    new "ولی هر حال، این مهم‌ترین چیز نیست."

    # say L2665 oli
    old "What's most important is what I'm going to do next after this pregnancy."
    new "مهم‌تر اینه که بعد از این بارداری من چیکار می‌کنم."

    # say L2667 pla
    old "Are you planning something else?"
    new "دیگه چی برنامه‌های دیگه‌ت؟"

    # say L2668 oli
    old "Of course, my plan is not to be a young mom."
    new "البته، من قصد ندارم یک مامان جوان باشم."

    # say L2670 oli
    old "And I didn't get pregnant just to get out of an arranged marriage."
    new "و من هم برای این نیستم که از یک ازدواج قراردادی بیرون بیام."

    # say L2671 oli
    old "This whole situation is just to buy some time for me to start doing some things that I want to do."
    new "این وضعیت همه فقط برای اینه که وقت بیشتری برای انجام کارهایی که می‌خوام بکنم، بدست بیارم."

    # say L2673 oli
    old "I decided that I want to get into college."
    new "من تصمیم گرفتم که وارد دانشگاه شوم."

    # say L2675 oli
    old "I need to get on my mother's good side, and to establish a future for myself."
    new "من باید خوب با مامانم رابطه برقرار کنم و آینده‌ای برای خودم تعیین کنم."

    # say L2677 pla
    old "That sounds great Olivia, it sounds like a great plan."
    new "ایولیویا، این خوبه، به نظر می‌رسه برنامه خوبی هست."

    # say L2679 oli
    old "Yeah, but listen..."
    new "بله، ولی بگو..."

    # say L2681 oli
    old "I don't really know how to ask you this."
    new "من واقعاً نمی‌دونم چطور از تو این سوال رو بپرسم."

    # say L2683 oli
    old "But I was wondering if you could help me study for the college entrance exams."
    new "ولی داشتم فکر می‌کردم می‌تونی به من کمک کنی برای آماده شدن امتحانات ورودی دانشگاه."

    # say L2685 oli
    old "I know that I've already asked way too much of you, more than what would be reasonable."
    new "می‌دونم قبلاً ازت خواسته‌هام بیشتر از حد منطقی بود."

    # say L2687 oli
    old "But the truth is that you're a very good teacher, and I think that to get into college I will really need your help."
    new "ولی حقیقت اینه که تو معلم خوبی هستی و فکر می‌کنم برای ورود به دانشگاه به راهنمایی‌ت نیاز دارم."

    # say L2689 oli
    old "I would understand it if you don't want to do it."
    new "اگر نمی‌خوای انجام بدی، من درک می‌کنم."

    # say L2690 oli
    old "But if you will, that would be the greatest thing."
    new "ولی اگر بخوای، این بهترین چیزی هست."

    # say L2692 pla
    old "Oh yeah for sure, I'll help you."
    new "بله حتماً، من به تو کمک می‌کنم."

    # say L2693 pla
    old "Of course, I don't have a problem with doing that."
    new "البته، من مشکلی برای انجام این کار ندارم."

    # say L2694 pla
    old "And I think you need it, that would help you to get out from under your parents."
    new "و فکر می‌کنم نیازت به این هست، این به تو کمک می‌کنه تا از زیر والدینت بیرون بیایی."

    # say L2695 pla
    old "So I'll be more than happy to help you study."
    new "پس خوشحال می‌شوم که به تو کمک کنم درس بخونی."

    # say L2697 oli
    old "Oh god [pla] you have no idea how good it is to hear that! Thank you so much!"
    new "اوه خدا ز[pla] می‌دونی چقدر خوشحالم اینو بشنوم! ممنون می‌شوم."

    # say L2698 pla
    old "Glad to help you."
    new "خوشحالم که به تو کمک کنم."

    # say L2700 pla
    old "Hmm, so I guess we should get going to your house then?"
    new "Hmm، پس فکر می‌کنم باید به خونه‌ت بریم؟"

    # say L2701 oli
    old "No, I don't think right now would be a good idea."
    new "نه، فکر کنم الان وقت خوبی نیست."

    # say L2703 oli
    old "I have to gather some more information about college admission exams and such."
    new "من باید اطلاعات بیشتری در مورد امتحانات پذیرش دانشگاه جمع کنم."

    # say L2704 oli
    old "But as soon as I have it I'll let you know."
    new "اما همین جا که اطلاعات رو جمع کردم، به تو می‌گم."

    # say L2706 pla
    old "Alright, I'll be waiting."
    new "باشه، منتظرت می‌مونم."

    # say L2707 pla
    old "I guess I'll see you later."
    new "ببینیم بعداً هم ببینیم."

    # say L2725 pla
    old "Hey Olivia."
    new "اولیویا، سلام."

    # say L2726 oli
    old "Hey [pla]! How are you doing?"
    new "سلام [pla]! حالت چطوره؟"

    # say L2727 pla
    old "I'm alright, and you?"
    new "من خوبم، تو چطوری؟"

    # say L2729 oli
    old "I'm doing well, actually I'm glad that I caught you here."
    new "من خوب هستم، در واقع خوشحالم که تو رو اینجا پیدا کردم."

    # say L2730 oli
    old "I got to checking the information that I told you about."
    new "من اطلاعاتی که به تو گفتم را بررسی کردم."

    # say L2731 oli
    old "So I was wondering if you could come with me to my house so that we can start studying today."
    new "پس فکر می‌کنم اگه بتونی با من به خونه‌ام بیادی، ما می‌تونیم امروز شروع به مطالعه کنیم."

    # say L2733 pla
    old "Sure, I'll gladly come with you to study."
    new "بله، خوشحال می‌شوم همراهت بریم و مطالعه کنیم."

    # say L2734 oli
    old "Great! Let's go then."
    new "عالی! برویم."

    # say L2748 oli
    old "Alright, I think we should get to it, right?"
    new "باشه، فکر کنم باید شروع کنیم، درسته؟"

    # say L2759 pla
    old "Alright, so what are we going to study?"
    new "باشه، پس ما چه چیزی رو می‌خوایم بخونیم؟"

    # say L2761 oli
    old "We're going to be covering the entrance exam for the design school."
    new "ما قراره درباره آزمون ورودی مدرسه طراحی صحبت کنیم."

    # say L2762 oli
    old "It came to my mind that maybe there could be a couple of previous exams online that I could use to study."
    new "به ذهنم رسید که شاید چند امتحان قدیمی از آنلاین پیدا کنم تا برای آزمون مدرسه طراحی مطالعه کنم."

    # say L2764 pla
    old "Hmm, so you want to study design..."
    new "هم، پس می‌خوای در مورد طراحی مطالعه کنی..."

    # say L2765 pla
    old "I mean, do you think I would be the best person to help you with it?"
    new "من قصدم اینه که فکر می‌کنم من بهترین نفر برای کمک به تو هستم؟"

    # say L2767 pla
    old "I don't know anything about the subject, to be honest."
    new "من صادقانه هیچ چیز در مورد اون موضوع نمی‌دونم."

    # say L2768 oli
    old "That's alright, you don't actually have to know."
    new "باشه، در واقع نیازی به دانستن نیست."

    # say L2769 oli
    old "The college I'm applying to has a fundamental curriculum that every student must complete."
    new "دانشگاهی که بهش اپلای می‌کنم برنامه‌ی اصلی داره که همه دانشجوها باید اون رو تکمیل کنند."

    # say L2771 oli
    old "And it's very heavy on chemistry, math, and sciences."
    new "و خیلی روی شیمی، ریاضی و علوم تمرکز داره."

    # say L2772 oli
    old "So it's alright if that's what we study. Because those topics are going to be the focus of the admission exam."
    new "پس خوبه اگر اینا رو مطالعه کنیم. چون این موضوعات همین جا در امتحان قبولی مهم هستند."

    # say L2774 pla
    old "Oh, I see, alright, let's get to it then."
    new "اوه، متوجه شدم، خب بیاین شروع کنیم."

    # say L2785 pla
    old "Uhmm, not much, it's just that you're taking very well to this."
    new "اوه، خوبه، فقط اینجاست که تو این مباحث رو خیلی خوب یاد می‌گیری."

    # say L2786 pla
    old "But before, you were struggling so much to learn the school topics."
    new "ولی قبل از این، تو خیلی سخت برای یادگیری موضوعات مدرسه تلاش می‌کردی."

    # say L2788 oli
    old "Well, as I told you before, I'm not dumb."
    new "خب، همانطور که قبلاً به تو گفتم، من خنده‌دار نیستم."

    # say L2789 oli
    old "It's just that the school topics are so much more boring to me."
    new "البته، موضوعات مدرسه برای من خیلی ممکنه سرکش‌کننده باشن."

    # say L2790 oli
    old "They're not interesting in any way."
    new "هیچ جور جالب نیستند."

    # say L2791 oli
    old "I mean, these are most of the same topics."
    new "من قصدم اینه که بگم اینا بیشتر همون موضوعات هستند."

    # say L2793 oli
    old "But I'm studying them to get into college and do something that I actually want to do."
    new "ولی من برای ورود به دانشگاه و انجام چیزی که واقعاً می‌خوام اینا رو مطالعه می‌کنم."

    # say L2796 oli
    old "It also has to do with the fact that I kinda know I have to push myself through this."
    new "این هم به این دلیل است که می‌دونم باید خودمو از این طریق بگذونم."

    # say L2797 oli
    old "With how far I've come already, it would be a real shame if I gave up now."
    new "با همه‌ی آنچه تا حالا پیش برده، خیلی شرمنده‌کننده خواهد بود اگر الان بیوفتم."

    # say L2799 pla
    old "I see, that actually makes a lot of sense."
    new "من متوجه شدم، این واقعاً منطقیه."

    # say L2800 oli
    old "Come on, let's keep going."
    new "بیای، بیشتر هم برویم."

    # say L2808 pla
    old "Alright, I think that should be enough for today."
    new "باشه، فکر کنم اینقدر برای امروز کافیه."

    # say L2810 oli
    old "Really? Already?"
    new "وای، قطعاً؟ همین الان؟"

    # say L2812 pla
    old "Yeah sure, this was just an introductory session."
    new "بله، این فقط جلسه‌ای مقدماتی بود."

    # say L2813 pla
    old "So we should stop before we get too tired."
    new "پس باید قبل از اینکه خسته شویم متوقف شیم."

    # say L2814 oli
    old "Hmm, yeah I guess you're right."
    new "Hmm، بله فکر کنم همین جوری هست."

    # say L2823 pla
    old "Alright, that was very good."
    new "باشه، این هم خیلی خوب بود."

    # say L2824 pla
    old "If we keep going like that, I'm sure you'll ace that entrance exam."
    new "اگه همینجور ادامه بدیم، مطمئنم توی امتحان ورودی خوب نمره می‌گیری."

    # say L2826 oli
    old "For everything, you know?"
    new "برای همه چیز، می‌دونی؟"

    # say L2827 oli
    old "I have been coming up with these crazy plans, and you've kept supporting me."
    new "من این همه طرح‌های خیال‌پردازی کردم و تو همیشه منو حمایت کردی."

    # say L2828 oli
    old "Thanks a lot."
    new "ممنونم."

    # say L2830 pla
    old "So, I guess I should get going, but I'll come back soon so that we can keep studying."
    new "پس فکر کنم باید برم، اما زودی بر می‌گردم تا بتوانیم همچنان مطالعه کنیم."

    # say L2831 pla
    old "And of course, to check on the pregnancy."
    new "و البته برای بررسی بارداری هم."

    # say L2832 oli
    old "Sure thing [pla], thanks a lot."
    new "بله، البته [pla]، ممنونم."

    # say L2850 oli
    old "Hey [pla]! Did you come to study again?"
    new "هی [pla]! دوباره برای مطالعه اومدی؟"

    # say L2851 pla
    old "Yeah, I figured that it's time for another session."
    new "بله، فکر کردم وقت برای جلسه‌ای دیگه رسیده."

    # say L2852 oli
    old "Great, let's get to it then."
    new "عالی، بیاین شروع کنیم."

    # say L2853 pla
    old "Alright, where did we leave off last time?"
    new "باشه، بار هم از کجا رها شدیم؟"

    # say L2854 oli
    old "I think it was this topic here..."
    new "فکر کنم این موضوع بود..."

    # say L2856 pla
    old "Oh yeah! For sure!"
    new "اوه بله! قطعاً!"

    # say L2858 pla
    old "Alright, let's continue from there then."
    new "باشه، بیاین از همین جا ادامه بدیم."

    # say L2895 pla
    old "Alright, that was a good session."
    new "باشه، این جلسه خوب بود."

    # say L2896 pla
    old "Just a couple more and I know you'll have what it takes to ace those exams."
    new "چند تای دیگه و می‌دونم تو قدرتی برای اینکه امتحاناتت رو با علامت خوب بگیری داری."

    # say L2898 oli
    old "Thanks a lot [pla]..."
    new "ممنون زیادی [pla]..."

    # say L2899 oli
    old "For everything."
    new "برای همه چیز."

    # say L2901 pla
    old "Hey, my pleasure."
    new "بله، لذت من بود."

    # say L2902 pla
    old "I have to leave for now, but I'll come back to see you soon, alright?"
    new "باید حالا برسم، ولی زودی برای دیدنت بازم می‌گردم، خوبه؟"

    # say L2903 oli
    old "Sure, no problem, see you."
    new "بله، هیچ اشکالی نداره، تا زودی می‌بینیم."

    # say L2944 pla
    old "Hi Mrs. Priya, how are you?"
    new "سلام خانم پریا، حالت چطوره؟"

    # say L2946 vee
    old "Are you here looking for Olivia?"
    new "اینجا برای اولیویا هستی؟"

    # say L2947 pla
    old "Uhh, yeah, I was kinda hoping to catch her here."
    new "آره، من همینجوری امیدوار بودم که اونجا باشه."

    # say L2948 vee
    old "Well, no, she's at school."
    new "خب، نه، او تو مدرسه هست."

    # say L2949 vee
    old "And you should be there too, you know?"
    new "و تو هم باید اونجا باشی، می‌دونی؟"

    # say L2950 pla
    old "Uh, yeah, yeah, you're probably right."
    new "بله، بله، احتمالاً همینطوره."

    # say L2951 pla
    old "I'll come by later then."
    new "بعداً می‌آیم."

    # say L2953 vee
    old "Sure, I'll let her know you stopped by."
    new "بله، من به او می‌گم که تو اومدی."

    # say L2956 pla
    old "Hi, Mrs. Priya, how are you?"
    new "سلام، خانم پریا، حالت چطوره؟"

    # say L2958 vee
    old "Hello, [pla]. I'm doing fine, and you?"
    new "سلام، [pla]. من خوبم، تو چطوری؟"

    # say L2960 pla
    old "I'm alright, thank you."
    new "من خوب هستم، ممنون."

    # say L2962 vee
    old "That's good to hear..."
    new "خوشحالم که اینجوری هستی..."

    # say L2964 vee
    old "So tell me, did you come looking for Olivia?"
    new "پس بگو، آیا برای یافتن اولیویا اینجا آمده‌ای؟"

    # say L2966 pla
    old "That's right. Is she here?"
    new "بله. اونجا هست؟"

    # say L2968 vee
    old "Great... Yes, she's in her room."
    new "عالی... بله، او در اتاقش هست."

    # say L2970 vee
    old "You can go in, go ahead, don't mind me."
    new "بیا وارد شو، برو، نگران من نباش."

    # say L2971 pla
    old "Uh... S- sure, thank you."
    new "آ... بله، ممنون."

    # say L2973 pla
    old "I guess I'll see you around, Mrs. Priya."
    new "باید برم، خداحافظ، پریا."

    # say L2974 vee
    old "Yes, of course. Good afternoon, [pla]."
    new "بله، البته. عصر خوبی، [pla]."

    # say L2984 pla
    old "Alright, that's good. I think we can move on to something else."
    new "باشه، این خوبه. فکر کنم می‌تونیم به چیز دیگه‌ای برسیم."

    # say L2985 oli
    old "Ok, that sounds good."
    new "باشه، این خوبه."

    # say L2988 vee
    old "Olivia, are you there? I'm coming in!"
    new "اولیویا، تو اینجا هستی؟ من داخل می‌یام!"

    # say L2999 vee
    old "Oh [pla], hi... So you were here too."
    new "اوه ز[pla]، سلام... پس تو هم اینجا بودی."

    # say L3000 pla
    old "H- hi Mrs. Priya."
    new "ه- هی خانم پریا."

    # say L3002 oli
    old "We were just studying, Mom, nothing else."
    new "ما فقط در حال مطالعه بودیم، مامان، هیچ چیز دیگه نیست."

    # say L3004 vee
    old "Yeah well, I hope it's going better than last time you two studied."
    new "البته، امیدوارم این بار بهتر از آخرین بار که مطالعه می‌کردید، باشه."

    # say L3007 oli
    old "Anyway, what do you want?"
    new "باز هم چی می‌خوای؟"

    # say L3009 vee
    old "What do you mean by that? Did you forget that we have a phone call with your father to talk about your pregnancy?"
    new "من قصد چی رو داری؟ آیا فراموش کردی که ما با پاپات گوشی داریم تا در مورد بارداریت صحبت کنیم؟"

    # say L3012 vee
    old "And before you ask, no, we cannot reschedule, you know how Vihaan is about his time."
    new "و قبل از اینکه بپرسی، نه، نمی‌توانیم برنامه را تغییر بدیم، می‌دونی Vihaan در مورد وقتش چقدر محکم است."

    # say L3013 oli
    old "Oh shoot! I forgot about it!"
    new "اوه شیطون! فراموش کردم!"

    # say L3017 oli
    old "Listen [pla], I'm going to have to step out for a while, this call with my dad is very important."
    new "بگوش [pla]، باید یه کمی بیرون برسم، این تماس با پاپا خیلی مهمه."

    # say L3018 oli
    old "But please don't leave."
    new "ولی لطفاً نرو."

    # say L3020 oli
    old "This isn't going to take too much time. And we have a lot more to cover in today's session."
    new "این طول نمی‌کشه. و ما هنوز باید امروز خیلی چیزهایی رو بررسی کنیم."

    # say L3022 oli
    old "So, I'll talk to my dad, and I'll come back so that we can keep studying."
    new "پس من با پاپا صحبت می‌کنم و برای اینکه بیشتر بیام و به مطالعه برسیم."

    # say L3023 pla
    old "Oh, a- alright, sure, no problem."
    new "اوه، خب، البته، هیچ اشکالی نداره."

    # say L3025 vee
    old "Come on, we have to go call him now."
    new "بیا، باید حالا ازش تماس بگیریم."

    # say L3029 oli
    old "Alright, alright, let's go."
    new "باشه، باشه، برویم."

    # say L3041 pla
    old "Hmm, I mean, I guess I'll just sit here and wait for her to come back."
    new "خوب، یعنی، فکر کنم فقط اینجا بنشینم و منتظر بازمونم."

    # say L3049 aye
    old "Hey brother-in-law! How are you?"
    new "اوه برادر زنده! چطوری؟"

    # say L3050 pla
    old "Uhmm, hi... I'm doing fine."
    new "اوه، سلام... خوبم."

    # say L3059 aye
    old "But what are you doing here all alone?"
    new "اما تو اینجا تنهایی چه کاری داری؟"

    # say L3061 pla
    old "Oh, I was helping your sister study."
    new "اوه، من در حال کمک به خواهرت برای مطالعه بودم."

    # say L3063 pla
    old "And you know, spending time with her and checking that the pregnancy is going well."
    new "و میدونی، وقت باهاش می‌گذونم و مطمئن می‌شوم حاملگی‌اش خوب هست."

    # say L3065 pla
    old "But she had to step out with your mom for a call they had scheduled with your dad."
    new "اما او باید با مامانت برای تماسی که با پاپات برنامه‌ریزی شده بود، خارج شود."

    # say L3066 pla
    old "So I'm just waiting here for her to come back."
    new "پس من فقط اینجا منتظرش هستم تا برگرده."

    # say L3068 aye
    old "I see, hmm, that's interesting, I guess."
    new "می‌بینم، هم، این جالب است، حدس می‌زنم."

    # say L3070 aye
    old "Do you like spending time with her?"
    new "تو دوست داری باهاش وقت بگذاری؟"

    # say L3071 pla
    old "Uh, I mean, y- yeah sure."
    new "نه، منظورم اینه، بله."

    # say L3072 aye
    old "I see, I see."
    new "می‌بینم، می‌بینم."

    # say L3074 aye
    old "And you like to do it even though she's just a fat cow?"
    new "و تو هنوز دوست داری با اون بیقاب بکنی، حتی با وجود اینکه فقط یه گاو چربه؟"

    # say L3075 pla
    old "W- what? What are you talking about?"
    new "W- چه؟ چه چیزی رو می‌گی؟"

    # say L3077 aye
    old "Nothing much, I was just wondering if you still like to spend time with her."
    new "چیز خاصی نه، فقط می‌خواستم بدونم هنوز دوست داری باهاش وقت ببری."

    # say L3078 aye
    old "Because she no longer looks as beautiful as she did before."
    new "چون دیگه مثل قبل زیبا نیست."

    # say L3080 aye
    old "You know, she's been getting fatter and fatter."
    new "دیویس، می‌دونی، او هر روز چاق‌تر می‌شه."

    # say L3082 aye
    old "I can't imagine that's attractive in any way."
    new "نمی‌تونم بیاندازم این چطور جذاب می‌تونه باشه."

    # say L3084 pla
    old "Uhmm, to be honest with you that's not even something I had considered."
    new "می‌گم، این هم چیزی بود که من حتی به ذهنم نیومده بود."

    # say L3086 pla
    old "I mean, she just looks a little bit bigger because of the pregnancy."
    new "من قصد دارم بگم که فقط به خاطر بارداری یه کم بزرگتر به نظر می‌رسه."

    # say L3088 pla
    old "But that's completely normal, right?"
    new "ولی این کاملاً عادیه، درسته؟"

    # say L3090 aye
    old "Yeah, yeah, as I was saying, she's a fat cow."
    new "بله، بله، همانطور که می‌گم، او یه گاو چربه."

    # say L3092 aye
    old "But anyway, that's not important right now."
    new "اما هر حال، این الان مهم نیست."

    # say L3093 aye
    old "You know? I've been thinking a lot about you recently."
    new "دیت می‌دونی؟ اخیراً خیلی به تو فکر کردم."

    # say L3094 pla
    old "Y- you have? H- how come?"
    new "ب- بله؟ چ- چرا؟"

    # say L3095 aye
    old "I just think it's very unfortunate that you had to fall in love with the worst part of our family."
    new "متأسفم که باید عاشق بدترین بخش خانواده‌مون شده‌ای."

    # say L3097 aye
    old "I mean sure, my sister's pretty."
    new "من قصد دارم بگم، البته خواهرم زیباست."

    # say L3099 aye
    old "But you know that she doesn't care about you, not really, right?"
    new "اما می‌دونی که او واقعاً به تو علاقه نداره، درسته؟"

    # say L3101 aye
    old "She's just using you to get out of going to India."
    new "او فقط از تو استفاده می‌کنه تا از رفتن به هند بیرون بیاد."

    # say L3102 aye
    old "I'm sorry it has to be like that."
    new "متاسفم که اینجوری باشه."

    # say L3103 pla
    old "Uh- I uh-"
    new "اوه- من اوه-"

    # say L3104 pla
    old "I'm not sure I know what you're talking about..."
    new "من نمی‌دونم در مورد چی حرف می‌زی..."

    # say L3106 aye
    old "Yeah right, of course you don't!"
    new "بله، البته نمی‌دونی!"

    # say L3107 aye
    old "But anyway, it's a shame that she's not only using you, but that you also have to have sex with her."
    new "البته، خیلی هم شرمنده‌کننده است که او نه فقط از تو استفاده می‌کنه، بلکه تو هم باید با او جنسیت داشته باشی."

    # say L3108 aye
    old "With how bad she is, it surprises me that you're that much into her."
    new "با اینقدر بد بودنش، شگفت‌زده‌ام که تو اینقدر بهش علاقه‌مندی."

    # say L3109 pla
    old "Uh... W- what do you mean?"
    new "اوه... تو چه مقصودی داری؟"

    # say L3110 aye
    old "Oh come on [pla]!"
    new "اوه بیا [pla]!"

    # say L3112 aye
    old "You know my sister's nothing special in bed."
    new "تو می‌دونی خواهرم توی اون کار خاصی نیست."

    # say L3113 aye
    old "It only took me the other day to be sure that she's not any good with sex stuff."
    new "فقط چند روز پیش متوجه شدم که توی اون کارها خوب نیست."

    # say L3115 aye
    old "She was sucking your dick without any interest in doing it."
    new "او با هیچ علاقه‌ای به شما نپوسید."

    # say L3116 aye
    old "Which is a shame because that big dick of yours deserves better."
    new "این خیلی بدبختانه است، زیرا آن دیک بزرگت بهتری از این می‌zasht."

    # say L3123 aye
    old "I mean, it's such an amazing dick. So big and so thick."
    new "من قصه رو می‌گم، اون یک دیک شگفت‌انگیزه. خیلی بزرگ و خیلی ضخیم."

    # say L3125 aye
    old "My sister's just wasting it with that sloppy technique of hers."
    new "خواهرت با اون تکنیک خرابش فقط وقتت رو می‌بره."

    # say L3126 aye
    old "And in bed..."
    new "و توی خواب..."

    # say L3128 aye
    old "I bet she's just a dead fish, she probably isn't anything special there."
    new "حتماً او فقط مثل ماهی مرده است، احتمالاً در اونجا هیچ چیز خاصی نیست."

    # say L3134 aye
    old "I was thinking that it would do you well to have a small tasting of what you've been missing..."
    new "فکر می‌کنم این به تو خوب می‌کنه که یه کمی از آنچه از دستت رفته تجربه کنی..."

    # say L3135 pla
    old "Uh, I uh..."
    new "اوه، من..."

    # say L3136 pla
    old "I- think you shouldn't be here..."
    new "فکر می‌کنم نباید اینجا باشی..."

    # say L3137 pla
    old "Y- your sister could think the wrong thing."
    new "Y- خواهرت می‌تونه چیز اشتباهی فکر کنه."

    # say L3139 aye
    old "And what would that be?"
    new "و اون چی می‌تونه باشه؟"

    # say L3145 pla
    old "Y- you know... L- like."
    new "د- دیلم... م- مثل."

    # say L3146 aye
    old "Come on brother-in-law, I know you'll love it."
    new "بیا برادر، میدونم دوستت خواهد اومد."

    # say L3156 pla
    old "W- what are you doing?!!"
    new "W- تو چه کاری می‌کنی؟!!"

    # say L3157 aye
    old "Come on! I know you'll love this!"
    new "بیا! میدونم اینو دوست خواهی داشت."

    # say L3158 pla
    old "W- what if your sister or your mom comes in here?!"
    new "و- اگه خواهرت یا مامانت داخل بیاد چیکار می‌کنیم؟!"

    # say L3159 aye
    old "Ugh, relax, nothing will happen!"
    new "آه، آرامش بکن، هیچ چیزی پیش نمی‌یاد!"

    # say L3170 aye
    old "I'm sure you've never had anything like it."
    new "مطمئن هستم تو هیچ چیزی مثل این نداشته‌ای."

    # say L3172 aye
    old "Now you can see what you're missing by doing it with my sister."
    new "حالا می‌تونی ببینی چه چیزی رو با خواهرم از دست دادی."

    # say L3173 aye
    old "It's a shame that you have to endure something like that."
    new "این جوری برایت خیلی بد است که چنین چیزی را تحمل کنی."

    # say L3175 aye
    old "But you never know, maybe you and I can have another one of these sessions sometime."
    new "اما می‌دونی، شاید تو و من بتوانیم یه جلسه‌ی دیگه‌ای مثل این داشته باشیم."

    # say L3176 aye
    old "Or maybe we could do something else."
    new "یا شاید می‌تونیم چیز دیگه‌ای بکنیم."

    # say L3177 pla
    old "Yeah... That's great."
    new "بله... خوبه."

    # say L3179 pla
    old "But it might be better if you leave for now, you know?"
    new "اما شاید بهتر باشه حالا بری، دی؟"

    # say L3180 aye
    old "Sure, I guess I will."
    new "بله، حدس می‌زنم برم."

    # say L3181 aye
    old "But I'll be seeing you later."
    new "ولی بعداً می‌بینی."

    # say L3188 pla
    old "God... She is something else."
    new "خدا... او واقعاً متفاوت است."

    # say L3189 pla
    old "Is everyone in this family so brazen?"
    new "آیا همه افراد این خانواده همین‌طور سرپا هستند؟"

    # say L3190 pla
    old "I'm just glad nobody saw us."
    new "خوشحالم که هیچ‌کس ما رو ندید."

    # say L3203 oli
    old "Hey [pla], I'm sorry I kept you waiting for so long."
    new "اولیویا: هی [pla]، معذرت که طولانی منتظرت موندم."

    # say L3205 pla
    old "Hey, it's alright, no problem."
    new "بله، خوبه، مشکلی نداره."

    # say L3206 pla
    old "I imagine you had a lot to talk with your dad, didn't you?"
    new "باید با پاپت خیلی حرف زدی، همینطور نه؟"

    # say L3208 oli
    old "Oh yeah, a lot, he just kept going and going."
    new "بله، خیلی، فقط هم ادامه می‌داد."

    # say L3210 pla
    old "I understand. Are you ready to get back to studying?"
    new "فهمیدم. آماده‌ای برای ادامه تحصیل؟"

    # say L3212 oli
    old "You know what? I think we should stop for the day."
    new "می‌دونی چی؟ فکر می‌کنم باید برای امروز متوقف شیم."

    # say L3213 oli
    old "I just had a very bad conversation with my Dad and mom and I don't feel like studying at the moment."
    new "من همین الان یک تماس خیلی بد با پاپا و مامان داشتم و حالا تمایلی به مطالعه ندارم."

    # say L3214 oli
    old "I think I just want to rest a little bit."
    new "من فکر می‌کنم فقط می‌خوام یه کم استراحت کنم."

    # say L3215 pla
    old "Oh! Sure, sure, no problem."
    new "اوه! البته، البته، هیچ اشکالی نداره."

    # say L3248 pla
    old "Hey Oli, how are you?"
    new "اولی، حالت چطوره؟"

    # say L3252 pla
    old "I'm doing fine, I came for us to continue studying. Are you ready?"
    new "من خوب هستم، برای این آمدم که ما ادامه تحصیل بدیم. آماده‌ای؟"

    # say L3253 oli
    old "You know? I don't think I am."
    new "دلم می‌خواد بگم، فکر نمی‌کنم آماده باشم."

    # say L3254 oli
    old "I've been feeling really bad all day."
    new "من امروز همه روز خیلی بد حس می‌کنم."

    # say L3255 oli
    old "You know, things from the pregnancy."
    new "میدونی، از بابت بارداری."

    # say L3256 oli
    old "So I think I'll just lay down for a while."
    new "پس فکر کنم یه کم بخوابم."

    # say L3257 oli
    old "I'm sorry that you came all the way here for nothing."
    new "متاسفم که این همه راه را برای هیچ چیزی طی کردی."

    # say L3259 pla
    old "It's alright, I understand."
    new "خوبه، من درک می‌کنم."

    # say L3260 pla
    old "You're pregnant, it's only natural that the body would feel that way."
    new "باز هم، حامله بودن طبیعیه که بدنت اینجور حس کنه."

    # say L3261 pla
    old "The best thing would be for you to rest, and we can see each other later."
    new "بهترین چیز اینه که تو خوابی، بعداً هم می‌تونیم به هم برسیم."

    # say L3263 oli
    old "Sure [pla], see you later."
    new "بله [pla]، بعداً می‌بینیم."

    # say L3293 pla
    old "Hmm, you know, I think I need to use the bathroom."
    new "Hmm، می‌دونی، فکر کنم باید به توالت برسم."

    # say L3294 oli
    old "Oh, sure!"
    new "اوه، البته!"

    # say L3295 oli
    old "No problem, it's down the hallway."
    new "بی‌چین، پایین راهرو هست."

    # say L3296 pla
    old "Alright, I'll be back in a minute."
    new "باشه، یه لحظه‌ای بر می‌گردم."

    # say L3305 pla
    old "Hmm, there's a weird sound coming from that room, what's going on in there?"
    new "هم، از اون اتاق صدای عجیبی می‌آیه، توی اونجا چه کاری می‌کنن؟"

    # say L3306 pla
    old "I don't think there's any harm in checking, right?"
    new "فکر نمی‌کنم خطری باشه بررسی کنم، درسته؟"

    # say L3316 pla
    old "{i}(And she's masturbating!){/i}"
    new "{i}(و او در حال استمناء است!){/i}"

    # say L3319 vee
    old "Oh yes! Yes, do you like what you're seeing honey?"
    new "اوه بله! بله، آیا از آنچه می‌بینی لذت می‌بری عزیزم؟"

    # say L3320 vih
    old "Of course I do! I love what I'm seeing!"
    new "البته که می‌پسندم! از آنچه می‌بینم لذت می‌برم!"

    # say L3330 vee
    old "What the fuck is wrong with you?"
    new "چه مشکلی داری؟"

    # say L3332 vee
    old "How long were you there just peeping on me?"
    new "تو چقدر اونجا بودی فقط به من نگاه می‌کردی؟"

    # say L3334 vee
    old "You are my daughter's fiancé! Have you no shame at all?!"
    new "تو عروس دخترم هستی! هیچ شرمندگی نداری؟!"

    # say L3335 pla
    old "I- I'm so sorry Mrs. Priya!"
    new "من- من خیلی متاسفم خانم پریا!"

    # say L3337 pla
    old "But I swear to god that it wasn't my intention to break your privacy."
    new "ولی قسمت خدا می‌خورم که هدفم اصلاً نبود که حرمتت رو نقض کنم."

    # say L3339 pla
    old "I was just coming back from the bathroom when I heard some weird noise coming from the bedroom."
    new "من فقط از توالت بر می‌گشتم که صدای عجیبی از اتاق خواب شنیدم."

    # say L3341 pla
    old "I just wanted to make sure that there wasn't anything wrong in here."
    new "می‌خواستم فقط ببینم اینجا هیچ مشکلی نیست."

    # say L3342 pla
    old "And I accidentally saw you..."
    new "و بی‌ادا دیدم..."

    # say L3344 pla
    old "I thought about leaving, but I didn't want to make any noise that could alert you to my presence."
    new "فکر کردم برم، اما نمی‌خواستم هیچ صدایی بکنم که می‌تونه توجهت رو جلب کنه."

    # say L3345 pla
    old "But I swear to god this was just a big misunderstanding ma'am."
    new "اما قسمت خدا این فقط سوء تفاهمی بود."

    # say L3347 vee
    old "I mean, I want to believe you but..."
    new "من می‌خوام باور کنم ولی..."

    # say L3353 vee
    old "{i}(How big is he?!){/i}"
    new "{i}(چقدر بزرگ است؟!){/i}"

    # say L3354 vee
    old "{i}(He must be at least twice as big as Vihaan!){/i}"
    new "{i}(حتماً دو برابر ویهاان هست!){/i}"

    # say L3356 pla
    old "Uhmm, ma'am? Is everything alright?"
    new "اهم، خانم؟ همه چیز خوبه؟"

    # say L3358 vee
    old "What? Oh yeah..."
    new "چه؟ اوه بله..."

    # say L3360 vee
    old "Listen [pla], I'll believe you for now."
    new "بگو [pla]، برای حالا به تو باور می‌کنم."

    # say L3362 vee
    old "But it still isn't alright that you were just spying on me like that."
    new "ولی هنوز درست نیست که فقط به من نظارت می‌کردی."

    # say L3364 vee
    old "Next time knock or something, so that I can at least be prepared."
    new "بعداً حتماً بزن یا چیزی بگو، تا بتوانم آماده شوم."

    # say L3365 pla
    old "Yeah, you're right, I'm sorry."
    new "بله، درست می‌فرمایی، معذرت."

    # say L3367 vee
    old "Now, my daughter will think something's happening if you take that long to come back from the bathroom."
    new "الان، دخترم فکر می‌کنه چیزی اتفاق افتاده اگه طولانی وقت برای برگشتن از توالت بگذری."

    # say L3368 vee
    old "So go back already."
    new "پس برو."

    # say L3369 pla
    old "Uh... S- sure, excuse me."
    new "ببخشید، می‌رم."

    # say L3375 vee
    old "That was a very unpleasant surprise."
    new "این یک مفاجأه خیلی ناخوشایند بود."

    # say L3376 vee
    old "But I guess I'll believe him."
    new "ولی به نظر می‌رسه من باید بهش ایمان کنم."

    # say L3377 vee
    old "But I wasn't expecting him to have such a huge boner from seeing me."
    new "اما من منتظر نبودم که از دیدن من چنین شوری داشته باشه."

    # say L3378 vee
    old "Is that what Olivia is enjoying?"
    new "این همین هست که اولیویا لذت می‌بره؟"

    # say L3379 vee
    old "Meanwhile all I have is my fingers and a laptop..."
    new "در حالی که من فقط انگشت‌ها و یک لپ‌تاپ دارم..."

    # say L3384 pla
    old "Damn! I wasn't expecting that!"
    new "لعنتی! اینو منتظر نبودم."

    # say L3385 pla
    old "I guess I'm lucky that she didn't get angrier with me."
    new "باید خوشحالم که با من غیظ نکرد."

    # say L3386 pla
    old "Next time I should just keep walking and mind my own business."
    new "بعداً باید فقط جلو برسم و به کار خودم ادامه بدم."

    # say L3399 oli
    old "Hey, what took you so long? Are you alright?"
    new "اولیویا: هی، چرا طول زیادی طول کشیدی؟ حالت خوبه؟"

    # say L3400 pla
    old "Me? O- oh yeah."
    new "من؟ اوه بله."

    # say L3401 pla
    old "I - I think I just ate something bad."
    new "من - فکر کنم چیز بدی خوردم."

    # say L3402 pla
    old "But I'm alright now."
    new "ولی حالا خوبم."

    # say L3404 oli
    old "Well, let's keep studying."
    new "خب، بیایم هم اینجا بخونیم."

    # say L3405 oli
    old "We have a lot more to do. Come on."
    new "باید هنوز کار زیادی انجام بدیم. بیا."

    # say L3428 pla
    old "Oh! Hi Olivia, how are you today?"
    new "اوه! سلام اولیویا، امروز چطوری؟"

    # say L3430 oli
    old "I'm doing fine, and you? How are you?"
    new "من خوب هستم، و تو؟ حالت چطوره؟"

    # say L3432 pla
    old "Oh I'm alright, you know, not much is happening."
    new "اوه خوبم، می‌دونی، خیلی چیزی پیش نمی‌یاد."

    # say L3433 pla
    old "How are you handling the pregnancy? Is everything alright?"
    new "حالت با حامل شدن چطوره؟ همه چیز خوبه؟"

    # say L3435 oli
    old "Oh yeah, for the most part it is."
    new "بله، بیشتر همه خوبه."

    # say L3436 oli
    old "My mom's still in a bad mood, but I think she'll come around."
    new "مامان هنوز خسته است، اما فکر کنم به تدریج بهتر می‌شه."

    # say L3437 oli
    old "The other thing is that I've been feeling somewhat bad because of nausea and stuff."
    new "دیگری هم اینه که من به خاطر تهوع و چیزهایی مثل خستگی خوب حس نمی‌کنم."

    # say L3438 oli
    old "You have seen it, how I get, I start to feel bad and my head hurts and stuff."
    new "دیدی، اینجوری می‌شوم، بد حس می‌کنم و سرم درد می‌کنه و همین‌جور."

    # say L3439 pla
    old "Yeah, I know, I'm sorry about that."
    new "بله، می‌دونم، متاسفم از این به خاطر."

    # say L3440 pla
    old "I hope that as the pregnancy goes the symptoms will start to decrease."
    new "امیدوارم با پیشرفت بارداری علائم کمتر شوند."

    # say L3442 oli
    old "Yeah, me too. But I mean is not as if I'm not managing to..."
    new "بله، من هم همین رو می‌خوام. ولی منظورم این نیست که من نتونم مدیریت کنم..."

    # say L3450 rub
    old "Hey you idiot! What do you think you're doing bothering her this early in the morning?"
    new "هی خودت! فکر می‌کنی چیکاری هستی اینطور زود صبح به او آزار می‌دهی؟"

    # say L3453 rub
    old "What? Did you think that just because Olivia's pregnant now you could just start harassing her like it was nothing?"
    new "چه کاری؟ فکر کردی چون اولیویا بچه‌دار شده، می‌تونی مثل هیچی نباشه بهش تحریم کنی؟"

    # say L3456 rub
    old "Well think again buddy, because I'm not gonna let you bother her anymore!"
    new "خب دوست عزیزم، من نمی‌تونم دیگه به این کار تحمل کنم!"

    # say L3459 rub
    old "Actually, why don't you get out of here before I call the teachers of you for harassing Olivia?"
    new "در واقع، چرا نمی‌روی از اینجا بیرون تا من معلم‌ها رو به خاطر آزاردهن Olivia تماس بگیرم؟"

    # say L3461 pla
    old "Hey! I'm not harassing anybody!"
    new "هی! من هیچ کس رو آزار نمی‌دم!"

    # say L3463 rub
    old "Get out of here or I'll call the teachers!"
    new "بیرون برو یا معلم‌ها رو می‌گم!"

    # say L3464 rub
    old "We'll see who they believe more..."
    new "ببینیم کی رو بیشتر باور می‌کنند..."

    # say L3465 pla
    old "Jeez, I'm leaving then."
    new "بی‌خیال، من می‌روم."

    # say L3471 rub
    old "Hpmh finally that stalker left."
    new "اوه، در نهایت آن دنبال‌کننده رفت."

    # say L3472 rub
    old "How are you? Are you alright?"
    new "حالت چطوره؟ خوب هستی؟"

    # say L3474 oli
    old "H- hi, I'm doing well, and you?"
    new "ه- سلام، خوبم، تو چطوری؟"

    # say L3476 rub
    old "Well, I'm alright, you know. There's nothing much going on in my life."
    new "خب، من خوبم، میدونی. توی زندگی من هیچ چیز خاصی پیش نیومده."

    # say L3477 rub
    old "Unlike you..."
    new "برخلاف تو..."

    # say L3479 rub
    old "I can't believe you didn't tell me about this before."
    new "من نمی‌تونم باور کنم تو قبل از این به من نگفتی."

    # say L3481 rub
    old "I'm only finding out because of your belly."
    new "من فقط به خاطر بطنت متوجه شدم."

    # say L3482 rub
    old "Why didn't you let me know before?"
    new "چرا قبلاً به من نگفتی؟"

    # say L3484 oli
    old "W- well, the truth is that even though I found out early, I wasn't really sure about who to tell."
    new "خب، حقیقت اینه که هرچند زودتر فهمیدم، واقعاً مطمئن نبودم باید با کی صحبت کنم."

    # say L3485 rub
    old "Why not? Is everything alright?"
    new "چرا نه؟ همه چیز خوبه؟"

    # say L3486 oli
    old "Uhmm, I guess it is."
    new "اوه، فکر کنم همه چیز خوبه."

    # say L3487 oli
    old "I've just been dealing with my parents. You know how they are."
    new "من فقط با پدر و مادرم مشغول هستم. می‌دونی اونا چطور هستن."

    # say L3489 rub
    old "Hmph, yeah, I have an idea."
    new "همف، بله، حدس می‌زنم."

    # say L3491 rub
    old "And what does the father say? Is he helping you?"
    new "و پدر چه می‌گه؟ آیا به تو کمک می‌کنه؟"

    # say L3493 oli
    old "Hmm, w- well... W- we're actually not in contact."
    new "هم، و- و... واقعاً ما در ارتباط نیستیم."

    # say L3495 rub
    old "What? Is that scumbag not planning on answering for what he did?"
    new "چه؟ آن خرا برای اون کاری که کرده پاسخ نمی‌ده؟"

    # say L3496 rub
    old "Tell me who he is! I'll make him answer!"
    new "بگو چه کسی هست! من اون رو مجبور می‌کنم جواب بده!"

    # say L3497 oli
    old "N- no, it's nothing like what you're imagining."
    new "نه، هیچی مثل آنچه تو فکر می‌کنی نیست."

    # say L3498 oli
    old "Is not that he doesn't want to answer for it, is just that..."
    new "نه اینجوری که نخواد پاسخ بده، فقط اینجوریه که..."

    # say L3499 oli
    old "I don't know who he is."
    new "من نمی‌دونم او کیه."

    # say L3500 rub
    old "How come?"
    new "چرا؟"

    # say L3501 oli
    old "Well, it happened at this party."
    new "خب، اینجوری شد در همین جشن."

    # say L3502 oli
    old "I didn't measure my drinks and got drunk."
    new "من شماره نوشیدنی‌هام رو درست نمی‌گرفتم و خودم مست شدم."

    # say L3503 oli
    old "And there was this very tall guy that I thought was cute."
    new "و اونجا یه مرد خیلی بلندی بود که خوب به نظر می‌رسید."

    # say L3505 oli
    old "I decided to approach him and we ended up spending the night together."
    new "من تصمیم گرفتم به سوی او برسم و ما در نهایت شب را با هم گذراندیم."

    # say L3507 oli
    old "But I never asked him his name or where he goes to school or anything."
    new "ولی هیچ وقت نپرسیدم اسمش چیه یا اون کدام مدرسه می‌ره یا چیزی."

    # say L3509 oli
    old "To be honest, I barely remember his face."
    new "صusch، صورتش رو هم یادم نمی‌آد."

    # say L3511 oli
    old "So you see, there's not much use in worrying about the father."
    new "پس می‌بینی، نگران پدرش هم خوبی نداره."

    # say L3513 rub
    old "Hmph, I guess you're right."
    new "همف، به نظر می‌رسه درست می‌گی."

    # say L3516 rub
    old "But it doesn't matter, you don't need that deadbeat to answer for anything."
    new "اما مهم نیست، نیازی نداری اون پدر بی‌پناه برای هیچی جواب بده."

    # say L3518 rub
    old "You have your family and you have me, that's all you need."
    new "تو خانوادت رو داری و من هم هستم، این همه کافیه."

    # say L3519 oli
    old "Thanks Ruby, I know I can always count on you."
    new "ممنون روبی، می‌دونم همیشه می‌تونم بر تو اعتماد کنم."

    # say L3521 oli
    old "But to be honest, I don't know yet if I'll be keeping it you know?"
    new "ولی صداقت بگم، هنوز نمی‌دونم آیا این بچه رو می‌خوام یا نه، می‌فهمی؟"

    # say L3522 oli
    old "Having a baby is a lot of work, so I'm still figuring out if I'll actually be a mother."
    new "داشتن بچه کار خیلی سختیه، پس هنوز مشخص نیست که واقعاً مادر می‌شوم یا نه."

    # say L3524 rub
    old "I see, I understand... That makes a lot of sense."
    new "می‌فهمم، من هم اینجوری فکر می‌کنم... کاملاً معقوله."

    # say L3525 rub
    old "And if you decide not to have it, what are you going to do about it?"
    new "و اگر تصمیم بگیری نداشته باشی، چه کاری می‌کنی؟"

    # say L3527 oli
    old "Well, I was thinking that I could just go to the same doctor your friend went to that other time."
    new "خب، فکر می‌کردم می‌تونم به همون دکتری برم که دوستت آن موقع رفت."

    # say L3528 oli
    old "They did a very good job the last time, didn't they?"
    new "پیش‌تر خوب کار کردند، درسته؟"

    # say L3529 oli
    old "I think I could go to them."
    new "فکر می‌کنم می‌تونم بهشون برسم."

    # say L3531 rub
    old "I see, I understand... Well, I agree."
    new "می‌فهمم، می‌دونم... خب، من هم موافقم."

    # say L3532 rub
    old "You know I'll help you no matter what, right?"
    new "میدونی همیشه کمکت می‌کنم، درسته؟"

    # say L3533 rub
    old "Whatever you choose to do, I'm here for you."
    new "هر چی انتخاب کنی، من برایت هستم."

    # say L3534 oli
    old "I know that thanks."
    new "ممنون، می‌دونم."

    # say L3535 rub
    old "Hey, what do you say we skip classes for today?"
    new "بیا، بگذار برای امروز کلاس‌ها رو بی‌اهمیت بکنیم."

    # say L3536 rub
    old "Come on, let's go to the mall and have some ice cream."
    new "بیای، برویم به مال و یه آیس کریم بخوریم."

    # say L3537 oli
    old "Haha, alright let's do it."
    new "هه، خب بیا برویم."

    # say L3557 mik
    old "Dude! I'm so angry!"
    new "دود! من خیلی خشمگین هستم!"

    # say L3558 pla
    old "H- huh? W- what's up?"
    new "ه- ها؟ چ- چه خبر؟"

    # say L3560 mik
    old "{i}'What's up?'{/i} Are you serious?"
    new "{i}'چیکار داری؟'{/i} جدی می‌گی؟"

    # say L3561 mik
    old "Olivia's pregnant man!"
    new "اولیویا بارداره دیدا!"

    # say L3562 pla
    old "Y- yeah, s- she is, so?"
    new "ب- بله، هست، پس؟"

    # say L3563 mik
    old "So? Don't you see what's wrong with that?"
    new "پس؟ نمی‌بینی چه مشکلی داره؟"

    # say L3565 mik
    old "I can't believe this treason!"
    new "نمی‌تونم این خیانت رو باور کنم!"

    # say L3566 pla
    old "H- hey man, c- calm down..."
    new "ه- هی مان، ح- حالت رو کنترل کن..."

    # say L3568 mik
    old "What do you mean calm down? Would you be able to if you were in my shoes?"
    new "منظورت از آرام شدن چیه؟ تو جای من بودی می‌تونستی آرام می‌شدی؟"

    # say L3569 pla
    old "I know man, this doesn't look good."
    new "دلم می‌فهمه دوست من، اما این خوب به نظر نمی‌رسه."

    # say L3570 pla
    old "B- but I can explain, I swear."
    new "ب- ولی می‌تونم توضیح بدم، قسمت می‌خورم."

    # say L3572 mik
    old "Explain? You know who the guy is?"
    new "توضیح؟ می‌دونی آدمایی کیه؟"

    # say L3573 pla
    old "Uhmm... What?"
    new "اوه... چی؟"

    # say L3575 mik
    old "Yeah, do you know who the guy that got Olivia pregnant is?"
    new "بله، می‌دونی چه کسی اولیویا رو باردار کرده؟"

    # say L3577 pla
    old "Oh! S- so you don't know who the father is."
    new "اوه! پس تو نمی‌دونی پدر کیه."

    # say L3579 mik
    old "Of course I don't, there are some rumors that it might be some jock in the football team."
    new "البته نمی‌دونم، شایعاتی هست که ممکنه یکی از بازیکنان تیم فوتبال باشه."

    # say L3581 mik
    old "But nobody knows."
    new "اما هیچ‌کس نمی‌دونه."

    # say L3583 mik
    old "But since you say you can explain, I imagine you know who it is, don't you?"
    new "اما چون می‌گی بی‌تو خودت می‌دونی که چه کسی هست، نه؟"

    # say L3584 pla
    old "Uh... N- no, I- I don't know who the guy is."
    new "اوه... ن- نه، من- من نمی‌دونم اون جونی کیه."

    # say L3585 mik
    old "Then what did you mean by that?"
    new "بعد از همه اینا، منظورت چی بود؟"

    # say L3587 pla
    old "Uhmm... I just thought you were going to get into an argument with Olivia or something."
    new "اوه... فقط فکر کردم می‌خواهی با اولیویا دعوا کنی یا چیزی."

    # say L3588 pla
    old "And I figured I had to stop you."
    new "و فکر کردم باید تو رو متوقف کنم."

    # say L3590 mik
    old "What? Because she's pregnant?"
    new "چه؟ چون بارداره؟"

    # say L3591 mik
    old "No man, not at all."
    new "نه داداش، هیچ."

    # say L3593 mik
    old "I'm hurt by her betrayal that's for certain!"
    new "من از خیانتش آسیب دیده‌ام، این برای مطمئن!"

    # say L3595 mik
    old "But there's no way that I would ever be angry or fight with my beloved Olivia."
    new "ولی هیچ راهی ندارم که به عزیزم اولیویا خشمگین شوم یا با او جنگ برسم."

    # say L3597 mik
    old "I love her too much for it."
    new "من بهش خیلی بیشتر عشق دارم."

    # say L3598 pla
    old "Is that so?"
    new "اینطوره؟"

    # say L3599 mik
    old "Of course, it doesn't matter what she did to me."
    new "البته، مهم نیست چه کاری به من کرد."

    # say L3601 mik
    old "But that son of a bitch that got her pregnant, he's a different story."
    new "اما آن خرایی که باعث بارداری‌اش شد، داستان دیگری هست."

    # say L3603 mik
    old "When I catch the guy I swear to god that I'll make him pay for getting with my woman!"
    new "وقتی آن راپور رو پیدا کنم قسمت می‌خورم که از اون بابت رابطه‌اش با زن من پرداختن خواهم کرد!"

    # say L3604 mik
    old "And with how close I was to scoring with her."
    new "و با همه این که من به دردشوندن باهاش خیلی نزدیک بودم."

    # say L3606 pla
    old "Yeah, I understand buddy."
    new "بله، من متوجه هستم دوست من."

    # say L3607 pla
    old "Must be rough."
    new "باید سخت باشه."

    # say L3609 mik
    old "It's alright dude, nothing I can do about it."
    new "ببین دوست من، هیچ کاری در این مورد نمی‌تونم بکنم."

    # say L3610 mik
    old "But anyway this doesn't mean that I won't be there for her anyway."
    new "اما هر حال این نمی‌تونه بی‌معنی باشه که من برایش نباشم."

    # say L3613 mik
    old "Think about it dude, if no one knows who the father is it means he's a bum or a deadbeat."
    new "بپنداش برو، اگه هیچ‌کس ندیده چه کسی پدره، بمعنیه که اون نفر یا بی‌کاره یا ناخوشگواره."

    # say L3614 mik
    old "Which means my poor Olivia is having to go at this by herself."
    new "این بدان معناست که اولیویا من باید خودش این کار رو انجام بده."

    # say L3616 mik
    old "But she won't have to worry about anything man!"
    new "اما او نباید نگران هیچ چیزی باشه دستت!"

    # say L3618 mik
    old "I'll step up! I'll answer for everything the kid needs."
    new "من پیش خواهم رفت! برای هر چیزی که کودک نیاز داره پاسخ خواهم داد."

    # say L3620 mik
    old "I'll even give him my last name so that they'll know I'm their father."
    new "من حتی نام خانوادگیم رو بهش میدم تا بدونن من پدرشون هستم."

    # say L3621 pla
    old "Oh, I mean, that's great man."
    new "اوه، منظورم اینه، خوبه برو."

    # say L3623 pla
    old "But what does Olivia think about your noble intentions? Have you talked to her?"
    new "ولی اولیویا چه فکری در مورد نیت‌های شرافت‌آمیزت داره؟ باهاش صحبت کردی؟"

    # say L3624 mik
    old "Hmm, no, not really. I haven't been able to talk to her."
    new "Hmm، نه، واقعاً نه. هنوز نتونستم باهاش صحبت کنم."

    # say L3625 mik
    old "But I will, don't doubt dude!"
    new "ولی خواهم، نگران نباش دوست من!"

    # say L3627 pla
    old "I'm sure you will bro, I'm sure you will."
    new "مطمئنم که خواهی بروتر، مطمئنم که خواهی."

    # say L3636 luc
    old "[pla], Mike, class is about to start, why haven't you taken your seats?"
    new "[pla]، مایک، کلاس خیلی زود شروع می‌شه، چرا هنوز ننشستید؟"

    # say L3637 pla
    old "Sorry ma'am."
    new "ببخشید خانم"

    # say L3645 luc
    old "This will also be at the end of term exam, so be sure to take good notes."
    new "این هم در امتحان پای ترم خواهد بود، پس حتماً توجه کنید تا خوب یادداشت بگیرید."

    # say L3656 luc
    old "Remember to practice the subject at home, the exam is very close, so don't relax too much and forget to study."
    new "به خاطر داشته باش در خونه موضوع رو تمرین کنی، امتحان خیلی نزدیکه، پس خیالت راحت نکن و فراموش نکن مطالعه کنی."

    # say L3657 luc
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term exams."
    new "میدونم به نظر میاد کار زیادی هست، اما باید اینا رو بکنی اگه میخوای قبل از امتحان‌های پایان ترم همه دروست رو خوب یاد بگیری."

    # say L3667 pla
    old "Hmph, that was a surprise."
    new "هم، این جا شوک‌آور بود."

    # say L3668 pla
    old "I thought Mike had figured out it was me who got Olivia pregnant."
    new "فکر می‌کردم مایک فهمیده باشه من هستم که اولیویا رو باردار کردم."

    # say L3669 pla
    old "Thinking about it, now I have two things to keep hidden from him."
    new "فکر می‌کنم الان دو چیز برای پنهان کردن ازش دارم."

    # say L3670 pla
    old "Ugh, this is so awkward."
    new "اوه، این خیلی ناراحت کننده."

    # say L3684 oli
    old "Hey [pla], did you come to study again?"
    new "هی ز[pla]، دوباره برای مطالعه اومدی؟"

    # say L3686 pla
    old "Yeah, we've been advancing well lately, I figured we could have another study session."
    new "بله، اخیراً پیشرفت خوبی داشتیم، فکر کردم می‌تونیم دوباره جلسه مطالعه‌ای داشته باشیم."

    # say L3687 oli
    old "Hmm, that's a good idea."
    new "Hmm، این یک ایده خوبه."

    # say L3688 oli
    old "But... To be honest I'm not sure I'm up to it right now."
    new "ولی... صداقتان با من، من الان احتمالاً آماده نیستم."

    # say L3689 pla
    old "Are you feeling bad again because of the pregnancy?"
    new "دیوونه، دیگه از بارداری خسته شده‌ای؟"

    # say L3690 oli
    old "No, it's not that."
    new "نه، این به خاطر آن نیست."

    # say L3691 oli
    old "Or rather, I think it is..."
    new "یا بهتر بگم، فکر می‌کنم همینه..."

    # say L3692 oli
    old "I just don't think I can study right now [pla]."
    new "من فقط فکر می‌کنم الان نمی‌تونم مطالعه کنم [pla]."

    # say L3694 pla
    old "I see, I understand."
    new "من متوجه شدم، فهمیدم."

    # say L3695 pla
    old "Is there anything I can do to help you?"
    new "می‌تونم چیزی بی‌کنم که بهت کمک کنم؟"

    # say L3696 pla
    old "Could I get you something for the discomfort you're feeling?"
    new "می‌تونم چیزی برای راحت کردن اون دردی که داری حس می‌کنی برات بیارم؟"

    # say L3699 oli
    old "I mean, I'm not in pain or anything like that."
    new "من قصد ندارم بگم که درد دارم یا چیزی مثل اون."

    # say L3701 pla
    old "I'm asking you in case there's anything I could do to help."
    new "من از تو می‌پرسم تا ببینم می‌تونم چطور کمکت کنم."

    # say L3703 oli
    old "I don't know [pla]..."
    new "نمی‌دونم [pla]..."

    # say L3704 oli
    old "It's just a little embarrassing, you know?"
    new "می‌دونی، فقط کمی خجالت‌آوره."

    # say L3705 pla
    old "Is it? Why? What's happening?"
    new "اینطوره؟ چرا؟ چه اتفاقی افتاده؟"

    # say L3710 oli
    old "{b}*Sigh*{/b} I guess there's no harm in telling you."
    new "{b}*نفس کشیدن*{/b} فکر کنم برات گفتن مشکلی نداره."

    # say L3711 oli
    old "You know, ever since I got pregnant I've been feeling this kind of..."
    new "دیوید، از زمانی که باردار شدم همیشه این حسی داشتم..."

    # say L3712 oli
    old "Tiredness? Fatigue?"
    new "خستگی؟ آن قدر خسته شدن؟"

    # say L3713 oli
    old "It's hard to explain, but since the pregnancy started that's how I've been feeling."
    new "توضیحش سخته، اما از زمانی که باردار شدم همین حس رو داشتم."

    # say L3715 pla
    old "{i}(That's similar to what Brixxida told me was going to happen.){/i}"
    new "{i}(این مثل چیزیه که بریکسیدا به من گفت می‌شه اتفاق بیفتد.){/i}"

    # say L3717 oli
    old "I went to the doctor and asked if that's a normal thing to happen."
    new "من به دکتر رفتم و پرسیدم این چیزی طبیعیه."

    # say L3718 oli
    old "They said that it's uncommon, but I might be experiencing some sort of chronic fatigue because of the pregnancy."
    new "اونا گفتن این خیلی معمول نیست، ولی ممکنه به خاطر بارداری خستگی مزمنی داشته باشی."

    # say L3719 oli
    old "But they ran several tests and concluded that I'm in good health."
    new "ولی آزمایش‌های زیادی انجام دادن و نتیجه گرفتن که من سلامتی هستم."

    # say L3721 pla
    old "Alright, and is it that fatigue the reason why you don't feel like studying?"
    new "خب، اون خستگی همینه که تو نمی‌خوای مطالعه کنی؟"

    # say L3723 oli
    old "Not really..."
    new "نه، واقعاً..."

    # say L3724 oli
    old "I think it's related, but it's so hard to explain..."
    new "فکر کنم مرتبط باشه، اما خیلی سخته توضیح بدی..."

    # say L3725 pla
    old "I think you can explain it to me. No problem."
    new "من فکر می‌کنم بتونی به من توضیح بدی. هیچ اشکالی نداره."

    # say L3726 oli
    old "Hmm, you think so?"
    new "Hmm، فکر می‌کنی همینطور باشه؟"

    # say L3727 oli
    old "Ok, well..."
    new "خب، خب..."

    # say L3728 oli
    old "The thing that has me feeling bad is this weird..."
    new "چیزی که منو ناراحت می‌کنه این حس عجیب و غریبیه که از زمان بارداری دارم..."

    # say L3730 oli
    old "H- horniness that I've been feeling ever since I got pregnant."
    new "ح- حس جنسی که از زمان بارداری دارم."

    # say L3731 pla
    old "O- oh! I- I see..."
    new "ا- اوه! م- متوجه شدم..."

    # say L3733 oli
    old "Y- yeah... And it's a very weird type of being horny."
    new "ب- بله... و این نوع خیلی عجیبی از حس جنسی است."

    # say L3734 oli
    old "At first I thought it was just because of the hormones."
    new "اول فکر کردم فقط به خاطر هورمون‌هاست."

    # say L3735 oli
    old "But as that fatigue that I told you about has kept growing, so has this weird feeling of horniness."
    new "ولی همون خستگی که بهت گفتم هر چه افزایش پیدا کرد، این حس عجیب جنسی هم رو به رشد بود."

    # say L3736 oli
    old "And lately sex is the only thing that I've been able to think about, you know?"
    new "و اخیراً جنس تنها چیزیه که می‌تونم بهش فکر کنم، می‌دونی؟"

    # say L3737 pla
    old "I think I understand."
    new "فکر کنم متوجه شدم."

    # say L3738 pla
    old "But if that's the case, why didn't you tell me about it before?"
    new "ولی اگر اینجوریه، چرا قبلا به من نگفتی؟"

    # say L3739 pla
    old "I mean... It's not as if we don't know each other."
    new "من قصدم... مثل این نیست که ما از هم نمی‌شناسیم."

    # say L3740 pla
    old "I could've helped you with it."
    new "می‌تونستم بهت کمک کنم."

    # say L3742 oli
    old "I don't know [pla], you've already done so much for me."
    new "نمی‌دونم [pla]، قبلاً خیلی کمک به من کردی."

    # say L3744 oli
    old "And it's not as if we're a couple, this whole pregnancy thing is just you helping me with a problem that I have."
    new "و این هم نیست که ما جفت هستیم، این حامل شدن فقط برای حل مشکل منه که تو کمک می‌کنی."

    # say L3746 oli
    old "I wouldn't even know how to bring up the subject."
    new "من حتی نمی‌دونم چطور این موضوع رو مطرح کنم."

    # say L3747 pla
    old "Hey, I get that, but come on, if it's something that you need, I'll be more than happy to help you."
    new "بله، من اینو می‌فهمم، ولی بیا، اگه چیزی هست که نیازت بهش هست، خوشحال می‌شوم که بهت کمک کنم."

    # say L3748 pla
    old "So... i- if you think you could use my help, maybe I can do something for you."
    new "پس... اگه فکر می‌کنی می‌تونم بهت کمک کنم، شاید بتونم چیزی برایت انجام بدم."

    # say L3750 oli
    old "Ok, m- maybe we can give it a go then..."
    new "خب، شاید بتونیم امتحانش بکنیم..."

    # say L3759 oli
    old "Ngnh! Oh god! This is amazing!"
    new "اوه خدا! این واقعاً شگفت‌انگیزه!"

    # say L3760 oli
    old "This big dick is just so great!"
    new "این لوله بزرگ فقط خیلی عالیه!"

    # say L3761 oli
    old "Oh [pla]! I can't believe how good it feels!"
    new "اوه ز[pla]! نمی‌تونم باور کنم چقدر خوب احساس می‌کنم!"

    # say L3770 oli
    old "Oh God [pla]! That feels so much better!"
    new "اوه خدا ز[pla]! این خیلی بهتر احساس می‌کنه."

    # say L3771 oli
    old "I don't know why, but it's as if that tiredness had just left my body all of a sudden."
    new "نمی‌دونم چرا، ولی مثل اینه که خستگی از بدنم رفت."

    # say L3772 oli
    old "If I had known before that it was going to be that way, I would've told you about this sooner."
    new "اگه قبل از این می‌دونستم همینجوری می‌شه، قبلاً ازت هم اینجوری می‌گفتم."

    # say L3773 pla
    old "I'm very happy that you feel better."
    new "خوشحالم که حالت بهتر شده."

    # say L3774 pla
    old "That was the whole point, it's good that this worked."
    new "این همین هدف بود، خوشحالم که این کار کار کرد."

    # say L3776 oli
    old "You're the best, [pla]. Thank you so much."
    new "تو بهترینی، [pla]. ممنونم خیلی."

    # say L3777 oli
    old "I don't think we'll be able to get to study right now."
    new "فکر نمی‌کنم الان بتونیم مطالعه کنیم."

    # say L3778 oli
    old "But I think we can do it later."
    new "ولی فکر کنم بعداً بتونیم انجام بدیم."

    # say L3779 oli
    old "For now, thank you so much for the help [pla]."
    new "برای حالا، ممنونم خیلی از کمکت [pla]."

    # say L3781 pla
    old "My pleasure, after all, we're in this together."
    new "خوشحالم، در نهایت ما با هم هستیم."

    # say L3782 pla
    old "I guess I'll get going to my house and I'll see you later, alright?"
    new "باید برم خونه و بعداً می‌تونیم دوباره ببینیم، درسته؟"

    # say L3812 pla
    old "Oh! Hey Olivia, how are you?"
    new "اوه! هی Olivia، حالت چطوره؟"

    # say L3814 oli
    old "Hey [pla], well you know..."
    new "اوه [pla]، خب میدونی..."

    # say L3816 pla
    old "What? Did something happen?"
    new "چه کاری داری؟ اتفاقی افتاد؟"

    # say L3818 oli
    old "I mean, my family's still a little annoying."
    new "من قصه‌اش اینه، خانواده‌ام هنوز یه کم ناراحت‌کننده هستند."

    # say L3820 oli
    old "It's been a little hard, you know, all this with my dad and mom..."
    new "می‌دونی، یه کم سخت بوده، همه اینا با پاپا و ماما..."

    # say L3821 oli
    old "And with my body getting fatter and fatter..."
    new "و با بدنشون که هر روز چاق‌تر می‌شه..."

    # say L3823 pla
    old "You know... This makes me feel kinda guilty."
    new "دیوید... اینجوری من هم یه حس گناه‌آمیزی می‌کنم."

    # say L3825 pla
    old "Well... I mean, it is kinda my fault that you're in this situation."
    new "خب... منظورم اینه که به نظر می‌رسه این وضعیت رو من باعث شدم."

    # say L3827 pla
    old "And I don't only mean the pregnancy."
    new "و من فقط به بارداری اشاره نمی‌کنم."

    # say L3829 pla
    old "But also what's happening with your family."
    new "ولی همچنین آنچه که با خانوادت می‌افتد."

    # say L3830 pla
    old "I can't avoid thinking that this is my responsibility."
    new "نمی‌تونم فکر نکنم این وظیفه‌ام هست."

    # say L3832 oli
    old "I understand why you would feel that way."
    new "من می‌فهمم چرا اینطور حس می‌کنی."

    # say L3833 oli
    old "I get what you're saying [pla]."
    new "من متوجه هستم چه می‌گی [pla]."

    # say L3835 oli
    old "But I don't think you should feel any guilt for it."
    new "ولی فکر نمی‌کنم باید از این بخاطر گناهکار باشی."

    # say L3837 oli
    old "After all, I was the one that came up with this idea."
    new "در نهایت، من همین ایده رو خودم پیشنهاد کردم."

    # say L3839 oli
    old "Not to mention I'm the one who dragged you into this whole situation."
    new "البته، من همینجور تو رو به این موقعیت کشوندم."

    # say L3840 pla
    old "Well, yeah, but still, you're the one bearing all the weight of this whole thing."
    new "بله، ولی همچنان تو هستی که تمام وزن این موضوع رو بر دوش گذاشته‌ای."

    # say L3841 pla
    old "Both figuratively and literally."
    new "هر جا که نگاه کنم، هم مجازی و هم واقعی."

    # say L3843 oli
    old "Yeah, but is something that was needed."
    new "بله، اما این چیزی بود که لازم بود."

    # say L3844 oli
    old "So don't beat yourself up too much for putting me in this state."
    new "پس خودت رو خیلی نبزن برای اینکه من رو به این حالت انداختی."

    # say L3846 oli
    old "Besides, it's not as if we didn't both enjoy it, right?"
    new "البته، نه مثل اینکه ما هر دو لذت نبرده باشیم، درسته؟"

    # say L3847 pla
    old "Well, yeah, we did."
    new "بله، درسته، ما هر دو لذت برداشتیم."

    # say L3848 oli
    old "There you go. So don't beat yourself up over it. There's no problem."
    new "ببین، پس از همه اینا نباید خودت رو بی‌انگیز کنی. هیچ مشکلی نداره."

    # say L3849 pla
    old "I guess so."
    new "باید هست."

    # say L3850 pla
    old "But still, I'd like it if you could feel a little bit more comfortable."
    new "ولی همچین، خوشحالم که تو بتونی یه کم راحت‌تر باشی."

    # say L3852 oli
    old "Oh, I think there's something that you could do to help me with that."
    new "اوه، فکر کنم چیزی هست که می‌تونی برای کمک به من انجام بدی."

    # say L3854 oli
    old "Come on, don't think too much about me being uncomfortable."
    new "بیا، خیلی به اینکه من ناراحت هستم فکر نکن."

    # say L3857 oli
    old "Now, let's go to my house."
    new "بیای، برویم به خونه من."

    # say L3858 oli
    old "The entrance exams are coming, so I want to study a little more."
    new "امتحان‌های ورودی قراره، می‌خوام کمی بیشتر بخونم."

    # say L3876 mik
    old "W- w- what was that?! W- what did I just hear?!"
    new "W- w- چه چیزی بود؟! W- چه چیزی رو همین الان شنیدم؟!"

    # say L3877 mik
    old "[pla]?! H- he got my girl pregnant?!"
    new "[pla]؟! ه- همون دخترم رو باردار کرد؟!"

    # say L3878 mik
    old "N- no way! I- it can't be..."
    new "N- نه! نمی‌تونه باشه..."

    # say L3879 mik
    old "No! H- he wouldn't do that!"
    new "نه! ه- هیچ‌وقت این کار رو نمی‌کرد!"

    # say L3880 mik
    old "With my girl?! What the hell?!"
    new "با دخترم؟! چه خبری؟!"

    # say L3898 pla
    old "Oh! Brixxida, hi."
    new "اوه! بریکسیدا، سلام."

    # say L3900 bri
    old "Hey, good morning."
    new "سلام، صبح بخیر."

    # say L3901 pla
    old "What are you doing here in my room so early?"
    new "تو اینجای اتوم من چی کار داری؟"

    # say L3902 bri
    old "Well, I was about to wake you up actually.."
    new "خب، در واقع قرار بود تو رو بیدار کنم."

    # say L3903 pla
    old "Oh! How come?"
    new "اوه! چرا؟"

    # say L3905 bri
    old "Well, how long has it been since you implanted the magic in that girl?"
    new "خب، چقدر وقت گذشته از زمانی که به آن دختر جادو دادی؟"

    # say L3906 bri
    old "And you haven't given me any update on how things are going with her."
    new "و تو هنوز به من هیچ آپدیتی در مورد اوضاع با او ندادی."

    # say L3907 pla
    old "Uh, well, there haven't been any new updates."
    new "خب، خب، هیچ اطلاعات جدیدی نیست."

    # say L3908 pla
    old "The only thing that's happened is what you told me."
    new "تنها چیزی که اتفاق افتاده همون چیزیه که به من گفتی."

    # say L3909 pla
    old "She's been feeling a little tired, so she asked me to have sex with her."
    new "او یه کم خسته بود، پس از من خواست که باهاش جنس کنم."

    # say L3910 bri
    old "And that's it? How's her pregnancy going?"
    new "و این همه؟ حملش چطور می‌ره؟"

    # say L3911 pla
    old "How's it going?"
    new "چطور می‌ره؟"

    # say L3912 pla
    old "Uhmm, it's very advanced, I would say."
    new "اوه، خیلی پیش رفته، می‌گم."

    # say L3913 pla
    old "Just as you told me, her belly grew so quickly."
    new "همانطور که تو گفتی، شکم او خیلی سریع بزرگ شد."

    # say L3914 pla
    old "You would think she's going to give birth any time now."
    new "فکر می‌کنی هر لحظه می‌تونه بچه رو بده."

    # say L3916 bri
    old "That's exactly what I mean you dimwit!!"
    new "این همینه که من می‌گم تو احمق!!"

    # say L3917 pla
    old "W- why are you angry?"
    new "چرا خیالت می‌کنی من دارم خیال می‌کنم؟"

    # say L3919 bri
    old "Why do you think?"
    new "چرا فکر می‌کنی؟"

    # say L3920 bri
    old "I told you [pla]! This isn't a normal human pregnancy!"
    new "من به تو گفتم [pla]! این حاملگی عادی انسانی نیست!"

    # say L3922 bri
    old "Any moment now she could give birth! And we haven't made the closing ritual for the spell!"
    new "هر لحظه می‌تونه بچه رو بزاره! و ما مراسم خاتمه جادو رو هنوز انجام ندادیم!"

    # say L3923 pla
    old "What are you talking about? Closing ritual?"
    new "درباره چی حرف می‌زنی؟ مراسم خاتمه؟"

    # say L3924 bri
    old "Yes [pla]! A closing ritual."
    new "بله [pla]! مراسم خاتمه."

    # say L3926 bri
    old "In the same way that I had to be there for the implantation of the magic."
    new "همانطور که باید برای جادوی زدن تو وجود داشتم."

    # say L3930 pla
    old "E- extraction? What are you talking about?"
    new "E- استخراج؟ تو در می‌گی چی؟"

    # say L3931 pla
    old "You never told me about any kind of extraction!"
    new "هیچ وقت از هیچ استخراجی به من نگفتی!"

    # say L3933 pla
    old "Where was all of this with Barbie?"
    new "این همه چیز با باربی کجاست؟"

    # say L3934 bri
    old "Well, for your information, we were never even close to finishing anything with Barbie because you decided to interrupt the spell!"
    new "خب، برای اطلاعاتت، ما حتی نزدیک به تمام کردن هیچ چیزی با باربی نبودیم، چون تو تصمیم گرفتی تا جادو رو قطع کنی!"

    # say L3936 bri
    old "Besides, I decided to modify the spell after your stupid tantrum last time with Barbie."
    new "البته، بعد از اون خروش خیلی بی‌هیچ‌پویایت تون با باربی، من تصمیم گرفتم جادو رو تغییر بدم."

    # say L3939 pla
    old "Uh, o- ok? But I don't get it, why?"
    new "اوه، اوکی؟ ولی من نمی‌فهمم، چرا؟"

    # say L3940 bri
    old "As I told you, after what happened last time with Barbie, I gave it a thought and decided the best thing to do was modify the spell."
    new "همانطور که به تو گفتم، بعد از آن مشکلی که با باربی پیش اومد، فکر کردم و تصمیم گرفتم بهترین کار اینه که جادوی رو تغییر بدیم."

    # say L3941 bri
    old "This is because last time we ended up losing a lot of magic power."
    new "این به خاطر اینه که آخر هم زمانی که باربی رو داشتیم، خیلی از توان سحرمون از دستمون رفت."

    # say L3943 bri
    old "You see, the way it should work is that the condensation spell is over at the same time that the pregnancy is."
    new "ببین، روش اینجاست که تحریک بارداری و جادوی تراکم همزمان تمام شنده باشند."

    # say L3945 bri
    old "But I realized that this approach only works if we let things come to term naturally."
    new "اما متوجه شدم این روش فقط وقتی کار می‌کنه که اجازه بدیم همه چی به طبیعت تمام بشه."

    # say L3947 bri
    old "But if it's something like what happened with Barbie were to happen again."
    new "اما اگر چیزی مثل آنچه با باربی اتفاق افتاد دوباره بیفتد."

    # say L3948 bri
    old "We would end up losing all of the already cultivated magic power."
    new "ما احتمالاً تمام قدرت جادویی که تا حالا کاشتیم را از دست می‌دهیم."

    # say L3951 pla
    old "But how did you solve it then?"
    new "ولی چطور اون موقع حلش کردی؟"

    # say L3953 bri
    old "I did it by making a change to the way the spell works."
    new "من اینجوری انجام دادم، با تغییر در نحوه کار جادو."

    # say L3955 bri
    old "Instead of letting it end by itself, we're directly extracting the magic power from the girl."
    new "به جای اینکه خودش تمام شه، ما مستقیماً توان جادویی رو از دختر استخراج می‌کنیم."

    # say L3957 bri
    old "This way it affords me a lot more control over the magic, and the moment it's extracted."
    new "این روش به من اجازه می‌دهه که روی جادو و لحظه استخراج آن کنترل بیشتری داشته باشم."

    # say L3958 bri
    old "So, even if something similar to what happened last time with Barbie were to happen again."
    new "پس، حتی اگر چیزی مشابه آنچه با باربی اتفاق افتاد، دوباره بیفتد."

    # say L3960 bri
    old "We could simply cancel the cultivation process and we wouldn't lose anything."
    new "می‌تونیم مراحل کاشت رو فقط لغو کنیم و هیچ چیز از دست ما نره."

    # say L3962 pla
    old "That's awesome Brixxida! And it's very reassuring!"
    new "عالیه بریکسیدا! و خیلی آرام‌بخش هست."

    # say L3964 bri
    old "Yeah, it's very good."
    new "بله، خیلی خوب است."

    # say L3966 bri
    old "But there's a condition to the spell in this new form: there HAS to be an extraction."
    new "ولی شرطی برای این تکنیک در شکل جدید وجود داره: باید استخراج انجام بشه."

    # say L3968 bri
    old "There's no point if we don't do it and the pregnancy just ends without us doing the extraction! We will lose all the magic!!"
    new "اگه اینجوری باشه و ما انجام ندهیم، بارداری فقط خاتمه می‌یابه و هیچ جادویی نمی‌مونه! ما همه جادو رو از دست می‌دهیم!!"

    # say L3969 pla
    old "I- I'm sorry Brixxida, I didn't know."
    new "بri: ببخشید بریکسیدا، من نمی‌دونستم."

    # say L3970 bri
    old "Hmph, as long as you understand."
    new "همف، مادون فهمیدی."

    # say L3972 bri
    old "But then you have to remember, sooner rather than later, we need to extract the magic power from her."
    new "اما باید به یاد داشته باشی، بهتر است زودتر از کلا، ما باید قدرت جادویی از او بیرون بیاوریم."

    # say L3973 bri
    old "Otherwise, she'll have a human with a magic supercharge."
    new "در غیر این صورت، او یک انسان با توان خارق‌العاده جادویی خواهد شد."

    # say L3974 bri
    old "And honestly, I don't know what that means in the long term."
    new "و صداقت بگم، من نمی‌دونم این در مدت طولانی چه معنی داره."

    # say L3979 bri
    old "By the way, [pla], there's something else you should know."
    new "باید چیزی دیگه‌ای هم بدونی، ز[pla]."

    # say L3981 bri
    old "Before we do the magic extraction, she has to decide if she wants to be a mother or not."
    new "قبل از انجام استخراج جادویی، باید تصمیم بده که می‌خواه مادر شه یا نه."

    # say L3984 bri
    old "This is because when we extract the magic power, I need to know if I'll take it all or just a small part."
    new "این به این دلیل است که وقتی قدرت جادویی رو استخراج می‌کنم، باید بدونم آیا همه‌ش رو بگیرم یا فقط بخش کوچکی."

    # say L3985 pla
    old "What happens either way?"
    new "هر دو طرف چه می‌شه؟"

    # say L3987 bri
    old "Well, if she decides not to go through with the whole process, I'll extract all the magic power from her."
    new "البته، اگر او تصمیم بگیرد کل فرآیند را انجام ندهد، من تمام توان جادویی را از او استخراج خواهم کرد."

    # say L3989 bri
    old "And her pregnancy will be reversed."
    new "و حاملگی‌اش معکوس خواهد شد."

    # say L3991 bri
    old "So in the end, it'll be like she was never pregnant."
    new "در نهایت، مثل این خواهد بود که هیچ وقت باردار نبوده."

    # say L3993 bri
    old "On the other hand, if she decides to go through the whole process."
    new "از طرف دیگر، اگر او تصمیم بگیره کل فرآیند رو طی کنه."

    # say L3995 bri
    old "I'll take most of it, but I'll leave a small amount of power, so a life will be created."
    new "بیشترش رو خواهم گرفت، اما مقدار کوچکی از توان را خواهم گذاشت تا زندگی‌ای ایجاد شود."

    # say L3996 pla
    old "I see... So that's how it is."
    new "می‌بینم... پس اینجوری هست."

    # say L3997 pla
    old "Alright, I'll be sure to talk to her about it."
    new "باشه، حتماً باهاش حرف می‌زنم."

    # say L3999 bri
    old "Good, make sure you do that."
    new "خوب، حتماً این کار رو انجام بده."

    # say L4000 pla
    old "Yeah, I'll do it and let you know."
    new "بله، انجام میدم و بهت خبر میدم."

    # say L4014 pla
    old "Alright! That's it!"
    new "باشه! این همه!"

    # say L4015 pla
    old "I think that's all the subjects we needed to study for the entrance exam."
    new "فکر کنم همه مباحثی که باید برای امتحان ورودی مطالعه کردیم رو پوشش دادیم."

    # say L4017 pla
    old "I think with that, you should ace the exam!"
    new "با این، باید امتحان رو با عالی بگذاری!"

    # say L4019 oli
    old "Oh my god! Thank you so much, [pla]!"
    new "اوه خداوند! ممنونم زیاد، [pla]!"

    # say L4021 oli
    old "At first, I couldn't believe we would ever manage to cover everything."
    new "اول باورم نمی‌کرد که بتونیم همه چی رو پوشش بدیم."

    # say L4023 oli
    old "But we did it!"
    new "ولی انجام دادیم!"

    # say L4025 oli
    old "I can't believe it, this is the best thing ever, [pla]!"
    new "باورم نمی‌شه، این بهترین چیزیه که هرگز اتفاق پیش آمد، [pla]!"

    # say L4027 pla
    old "Yeah, for a moment there, I also thought we wouldn't have time to cover everything."
    new "بله، برای لحظه‌ای هم من فکر کردم وقت کافی برای پوشش همه چیز نخواهیم داشت."

    # say L4028 pla
    old "But you've been so disciplined, Olivia. It's amazing how much effort you've put in such a short time."
    new "ولی تو خیلی انضباط‌دار بودی، اولیویا. شگفت‌زده‌ام که چقدر تلاش کردی در این مدت کوتاه."

    # say L4029 pla
    old "This is definitely all because of your hard work."
    new "این حتماً همه به خاطر تلاشت است."

    # say L4031 oli
    old "Still, you've been an amazing teacher, [pla]."
    new "همچین، تو یک معلم عالی بودی، [pla]."

    # say L4032 oli
    old "Thinking about it, we had a very rocky start."
    new "وقتی بهش فکر می‌کنم، شروعمون خیلی سخت بود."

    # say L4034 oli
    old "With me blackmailing you with what I saw you do at Mike's house."
    new "با من که تو رو به خاطر آنچه در خونه مایک دیدم، تحت فشار قرار دادم."

    # say L4035 oli
    old "I'm sorry about that, by the way."
    new "با این حال، برای همین عذرخواهم."

    # say L4037 pla
    old "I mean, it's alright, given the situation you were in."
    new "من قصه رو می‌فهمم، اما خوب، شرایطت رو در نظر می‌گیرم."

    # say L4039 pla
    old "I'm not saying it's okay, but I understand you were in a desperate position."
    new "من نمی‌گم خوبه، اما می‌فهمم تو در موقعیتی دشوار بودی."

    # say L4041 pla
    old "But it's alright."
    new "ولی خوبه."

    # say L4045 oli
    old "Thank you for your understanding."
    new "ممنون از درکت"

    # say L4047 oli
    old "And for being so helpful."
    new "و برای اینکه همچین کمکی کردی."

    # say L4048 oli
    old "I came up with such a crazy idea, and you decided to help me with it."
    new "من چنین ایده‌ی خرده‌ای رو آوردم و تو تصمیم گرفتی به من کمک کنی."

    # say L4050 oli
    old "And on top of that, you even took time to explain all these topics to me."
    new "و بالا بر این، حتی وقت خودت رو صرف توضیح همه این موضوعات به من کردی."

    # say L4053 oli
    old "I don't know how to show my gratitude."
    new "نمی‌دونم چطور ممنونیتمو نشون بدم."

    # say L4055 oli
    old "But I can think of a couple of ways."
    new "ولی چند راه برای این می‌تونم فکر کنم."

    # say L4056 oli
    old "You know, I've been feeling a little tired lately."
    new "می‌دونی، اخیرا خسته‌ام."

    # say L4057 pla
    old "Y- you are?"
    new "Y- تو هستی؟"

    # say L4059 oli
    old "Yeah, I'm not feeling my best lately."
    new "بله، اخیراً خیلی خوب حس نمی‌کنم."

    # say L4060 oli
    old "I was thinking maybe you could help me a bit with that."
    new "می‌تونی کمی به من کمک کنی؟"

    # say L4061 oli
    old "And at the same time, maybe I can show my thanks for everything you've done for me."
    new "و همینطور، شاید بتونم برای همه چیزی که برایم انجام دادی، تشکرتو نشون بدم."

    # say L4063 pla
    old "Uh, y- yeah sure, I don't see why not."
    new "بله، حتماً، من هم مشکلی نمی‌بینم."

    # say L4065 oli
    old "Great! Give me a second to go to the bathroom, and I'll be right back."
    new "عالی! یه لحظه بده تا به توالت برسم، همین جا برمی‌گردم."

    # say L4066 oli
    old "Don't worry, you won't have to wait long."
    new "نگران نباش، طول نمی‌کشه."

    # say L4068 pla
    old "Oh right! By the way."
    new "اوه درست! باید چیزی ازت بپرسم."

    # say L4069 pla
    old "I wanted to ask you something."
    new "می‌خواستم چیزی ازت بپرسم."

    # say L4070 pla
    old "Maybe this isn't what you expect right now."
    new "شاید این همین الان انتظارت نباشه."

    # say L4072 pla
    old "But I was thinking we still haven't talked about your decision regarding your pregnancy."
    new "اما من فکر می‌کردم هنوز در مورد تصمیمتو درباره بارداری صحبت نکرده‌ایم."

    # say L4074 pla
    old "D- don't get me wrong, I'm not trying to convince you of anything."
    new "د- اشتباه فهم نکن، من نمی‌خوام تو رو به هیچ چیزی قانع کنم."

    # say L4076 pla
    old "I just want to know where you stand on it, you know?"
    new "می‌خوام بدونم تو در مورد این موضوع چه وضعیتی داری، می‌فهمی؟"

    # say L4077 pla
    old "Just because I worry about you."
    new "ممنون که نگران من هستی."

    # say L4079 oli
    old "Well... I have to say I originally thought about waiting for the entrance exam results."
    new "خب... باید بگم اول به فکر این بودم که منتظر نتیجه آزمون ورودی بمونم."

    # say L4080 oli
    old "You know, because I wanted to know if I got into college."
    new "می‌دونی، چون می‌خواستم بدونم دانشگاه من رو پذیرش کرده یا نه."

    # say L4081 oli
    old "But I thought about it and understood what I want."
    new "ولی فکر کردم و فهمیدم چه چیزی رو می‌خوام."

    # menu L4084 
    old "Extract the whole magic power."
    new "من قصد دارم تمام توان جادویی رو استخراج کنم."

    # say L4087 oli
    old "I've decided that I don't want to be a mother."
    new "من تصمیم گرفتم که نمی‌خوام مادر شم."

    # say L4089 oli
    old "I- it's just that it wasn't my original plan, you know?"
    new "می‌دونی، این هیچ وقت برنامه‌ی اصلی من نبود."

    # say L4091 oli
    old "When I got myself into this situation, it was only to get my parents off my back."
    new "وقتی خودم رو به این وضعیت انداختم، فقط برای این بود که والدینم رو آرام کنم."

    # say L4093 oli
    old "But I have to say, I've never considered being a mother so young."
    new "ولی باید بگم، هرگز فکر نکردم توی این سن مادر شوم."

    # say L4094 oli
    old "There are still so many things I want to do, and being a mother would get in the way of all that."
    new "هنوز هم چیزهای زیادی برای انجام دادن دارم و مادر شدن می‌تونه به همه اونا مانع بشه."

    # say L4096 oli
    old "Besides, I would be dragging you into this situation too."
    new "البته، من شما رو هم به این وضعیت وارد می‌کردم."

    # say L4098 oli
    old "You've done a lot for me, [pla], but I can't ask any more from you."
    new "تو قطعی خیلی چیزهایی برای من انجام دادی، [pla]، اما نمی‌تونم از تو بیشتر بخواهم."

    # say L4100 oli
    old "So I think it's better if I just leave things as they are."
    new "پس فکر می‌کنم بهتره همه چی رو همینجور بگذaram."

    # say L4102 pla
    old "You know? I completely understand what you mean."
    new "pla: می‌دونی؟ کاملاً متوجه هستم."

    # say L4103 pla
    old "I'm happy you're thinking about your future."
    new "خوشحالم که در مورد آینده‌ت فکر می‌کنی."

    # say L4104 pla
    old "And hey, thanks for trusting me."
    new "و هی، ممنونم که به من اعتماد کردی."

    # say L4106 oli
    old "I'm glad you've been my partner through this whole process, [pla]. Thank you so much."
    new "خوشحالم که تو همراه من در این کل فرآیند بودی، [pla]. ممنونم خیلی."

    # menu L4110 
    old "Extract most of the magic power but leave a small part."
    new "بیشتر قدرت جادو را استخراج کن اما بخش کوچکی از آن را باقی بگذار."

    # say L4112 oli
    old "Well, I don't know how to tell you this."
    new "خب، نمی‌دونم چطور بگم این جوری به تو."

    # say L4114 oli
    old "But I decided that I want to be a mother."
    new "ولی من تصمیم گرفتم که می‌خوام مادر شم."

    # say L4116 oli
    old "I- I don't mean that I want to make you a father or anything, [pla]!"
    new "من- من قصد ندارم بگم که می‌خوام تو رو پدر بکنم یا همچین چیزی، [pla]!"

    # say L4118 oli
    old "It's just that I've been thinking, and I think I want to give it a go."
    new "فقط اینجاست که من فکر کردم و فکر می‌کنم می‌خوام امتحانش بکنم."

    # say L4120 oli
    old "Ever since this happened, I've been feeling better and better about the possibility of being a mother."
    new "از زمانی که این اتفاق افتاد، حس خوب‌تری برای اینکه مادر بشم دارم."

    # say L4121 pla
    old "And you decided that you want to do it?"
    new "و تو تصمیم گرفتی که این کار رو بکنی؟"

    # say L4122 oli
    old "Well, yeah."
    new "بله، همینطور."

    # say L4124 oli
    old "I've been thinking about it and I think it's possible."
    new "من در موردش فکر کردم و فکر می‌کنم امکان‌پذیره."

    # say L4126 oli
    old "Lately, my father has come around to the idea of me being a mom."
    new "اخیراً پدرم روی ایده‌ی اینکه من مامان شوم، مداراست."

    # say L4128 oli
    old "And my mom's pretty excited about it too."
    new "و مامان هم خیلی خوشحال شده."

    # say L4130 oli
    old "So I figured I could try it."
    new "پس فکر کردم می‌تونم امتحانش کنم."

    # say L4132 oli
    old "B- but I'm not trying to make you a father!"
    new "ولی من نمی‌خوام تو رو پدر کنم!"

    # say L4134 oli
    old "I don't expect you to get involved or anything."
    new "من از تو نمی‌خواهم در این جوری چیزها وارد شی."

    # say L4135 oli
    old "It's just what I want to do, [pla]."
    new "این فقط چیزی است که من می‌خوام انجام بدم، [pla]."

    # say L4137 pla
    old "It's alright, I understand. And I would never try to convince you otherwise."
    new "باشه، من متوجهم. و هرگز نمی‌خواستم تو رو قانع کنم که اینجوری نکنی."

    # say L4138 pla
    old "I just wanted to know what your plans were."
    new "می‌خواستم بدونم برنامه‌ت چیه."

    # say L4140 pla
    old "And I'm happy you're in a position where you can decide this."
    new "و خوشحالم که تو در موقعیتی هستی که بتوانی این را تصمیم بگیری."

    # say L4141 pla
    old "I'll help you in any way you need me to."
    new "من به تو در هر راهی که نیاز داری کمک می‌کنم."

    # say L4146 oli
    old "Thanks for all your support, [pla]!"
    new "ممنون از همه حمایتت، [pla]!"

    # say L4147 oli
    old "Listen, I have to go to the bathroom."
    new "بله، باید برم به توالت."

    # say L4148 oli
    old "But when I come back, I want to see you ready."
    new "ولی وقتی برگشتم، می‌خوام ببینم آماده‌ای."

    # say L4154 pla
    old "Ok, I should take this chance to bring Brixxida here!"
    new "باشه، باید این فرصت رو برای آوردن بریکسیدا اینجا استفاده کنم!"

    # say L4164 bri
    old "What do you need?"
    new "چه کاری از من می‌خوای؟"

    # say L4165 bri
    old "That really surprised me."
    new "این واقعاً مرا شگفت‌زده کرد."

    # say L4166 pla
    old "Well, I think now's the perfect time for you to end the spell."
    new "خب، فکر می‌کنم الان وقت مناسب برای خاتمه دادن به جادو تو هست."

    # say L4167 bri
    old "That's just perfect. Well done calling me here, [pla]!"
    new "این فقط عالیه. خوب کار کردی که من رو اینجا فراخواندی، [pla]!"

    # say L4175 oli
    old "Alright, let's do this."
    new "باشه، بیا این کار رو بکنیم."

    # say L4178 oli
    old "Come on, I want you to fuck me right now."
    new "بیا، من می‌خوام الان همینجا باهام جنس کنی."

    # say L4179 pla
    old "S- sure, right away!"
    new "ب-bالا، همین حالا!"

    # say L4189 oli
    old "Oh God yes! That's just what I've been missing, [pla]!"
    new "اوه خدا بله! این همینه که من از دست داده بودم، [pla]!"

    # say L4190 bri
    old "Oh yeah, [pla]! That's just what I wanted!"
    new "اوه بله، [pla]! همین بود که می‌خواستم!"

    # say L4191 oli
    old "This feels so amazing!"
    new "این حس خیلی عالیه!"

    # say L4201 oli
    old "That was sooo good, [pla]!"
    new "این خیلی خوب بود، [pla]!"

    # say L4202 oli
    old "Just like always, that dick of yours never disappoints."
    new "همیشه همینطور، آن قلی زنده‌ت هر بار خیالی نمی‌کنه."

    # say L4203 pla
    old "I'm glad you liked it."
    new "خوشحالم که لذت برده‌ای."

    # say L4206 oli
    old "Well, mostly, yeah."
    new "خب، بیشتر همینه، بله."

    # say L4207 oli
    old "But you know? I still feel a little bit tired."
    new "اما می‌دونی؟ هنوز یه کم خسته‌ام."

    # say L4208 oli
    old "And I feel like I haven't thanked you enough for everything."
    new "و همین‌طور می‌تونم بگم که هنوز به تو برای همه چیز کافی تشکر نکردم."

    # say L4209 oli
    old "So I have another thing for you. Come here."
    new "پس من هم چیزی برای تو دارم. بیا اینجا."

    # say L4218 oli
    old "Slrrp! Oh yeah!"
    new "سلرب! اوه بله!"

    # say L4219 oli
    old "Hmm! I wanted to taste this dick again!"
    new "هم! می‌خواستم این ناخن رو دوباره بچُشم!"

    # say L4220 oli
    old "Just relax and enjoy it [pla]!"
    new "فقط آرامش ببر و لذت ببر [pla]!"

    # say L4232 oli
    old "Alright! I think that does it!"
    new "البته! به نظر می‌رسه کارش تمام شده!"

    # say L4233 oli
    old "I hope you liked my way of saying thanks to you, [pla]!"
    new "امیدوارم روش من برای تشکر ازت خوشت آمده باشه، [pla]!"

    # say L4235 pla
    old "Yeah, I think it was great!"
    new "بله، فکر کنم عالی بود!"

    # say L4237 oli
    old "I'm glad. Thanks again for everything, [pla]."
    new "خوشحالم. ممنونم از همه‌ت، [pla]."

    # say L4239 oli
    old "I'm sure I'm going to do great on those exams."
    new "مطمئنم در این امتحانات خوب می‌کنم."

    # say L4240 pla
    old "I'm completely sure of it."
    new "من کاملاً مطمئنم."

    # say L4242 pla
    old "You've worked very hard to get a good result."
    new "تو خیلی سخت کار کردی تا نتیجه خوبی بگیری."

    # say L4243 pla
    old "There's no doubt that you'll ace it."
    new "اشتباهی نیست، حتماً این آزمون رو با علامت عالی می‌گیری."

    # say L4245 oli
    old "Thanks, [pla]. Your support means everything to me."
    new "ممنون، [pla]. حمایتتو برای من اهمیت زیادی داره."

    # say L4247 pla
    old "Hey, I think I should be going home, right?"
    new "باید برم خانه، درسته؟"

    # say L4248 pla
    old "So you'll have time to rest properly."
    new "پس تو وقت خواهی داشت تا به درستی استراحت کنی."

    # say L4250 oli
    old "Sure, thanks again, [pla]."
    new "بله، ممنونم دوباره، [pla]."

    # say L4252 pla
    old "You're welcome, Olivia."
    new "خواهش می‌کنم، اولیویا."

    # say L4264 pla
    old "Okay, I think that settles everything with the spell, right?"
    new "باشه، فکر کنم همه چیز در مورد جادو حل شده، درسته؟"

    # say L4266 bri
    old "That's right. Now that we stopped the spell, she'll return to normal soon."
    new "درسته. حالا که تاثیر جادویی خاتمه پیدا کرد، او به سرعت به حالت عادی بر می‌گردد."

    # say L4267 bri
    old "And don't worry about her health; she'll be completely fine."
    new "و نگران سلامتش نباش؛ کاملاً خوب خواهد شد."

    # say L4268 bri
    old "So it should be all good."
    new "پس همه خوبه."

    # say L4272 bri
    old "Now, we can't extract the magic power from you yet."
    new "البته، الان نمی‌توانیم قدرت جادویی رو از تو بیرون بیاوریم."

    # say L4273 bri
    old "Because we need a little bit of time for the magic you extracted from her to settle within you."
    new "چون باید یه لحظه وقت بدیم تا جادویی که ازش بیرون آوردی توی تو استقرار پیدا کنه."

    # say L4292 pla
    old "Hmm? Hello?"
    new "Hmm؟ سلام؟"

    # say L4293 pla
    old "Yes, this is him speaking."
    new "بله، این من هست."

    # say L4294 pla
    old "W- what?! N- now?!"
    new "و- وای! ه- حالا؟!"

    # say L4295 pla
    old "I- I'll be there right away!"
    new "من الان همینجا می‌رسنم!"

    # say L4300 pla
    old "I can't believe Olivia's already in the hospital!"
    new "باورم نمی‌شه که اولیویا قبلاً تو بیمارستانه!"

    # say L4301 pla
    old "I better hurry!"
    new "باید سریع‌تر برم!"

    # say L4314 pla
    old "I- I can't believe you're already here!"
    new "من- من باور نمی‌کنم حالا اینجایی!"

    # say L4316 oli
    old "Me too, but my obgyn decided that now was the best time."
    new "من هم، اما پزشک زایمان و ناباروری من فکر کرد الان بهترین وقت هست."

    # say L4318 oli
    old "So you know, I guess it's fine."
    new "پس میدونی، به نظر می‌رسه خوبه."

    # say L4320 pla
    old "And how do you feel? Are you ready?"
    new "و احساست چطوره؟ آماده‌ای؟"

    # say L4322 oli
    old "I am, thank you, [pla]."
    new "من هستم، ممنونم، [pla]."

    # say L4323 oli
    old "And hey, don't worry too much about me."
    new "و نگران من نباش خیلی."

    # say L4324 oli
    old "I'm sure of my decision."
    new "مطمئن هستم از تصمیم خودم."

    # say L4325 oli
    old "And my mom and sister are already here to help with everything, so don't worry, alright?"
    new "و مامان و خواهرم قراره اینجا باشن تا به همه چی کمک کنن، پس نگران نباش، درسته؟"

    # say L4327 pla
    old "Alright, sure."
    new "باشه، حتماً."

    # say L4334 vee
    old "Honey, the nurse says they have to move you into the operating room."
    new "حبیب، پرستار می‌گه باید تو رو به اتاق عمل ببرن."

    # say L4336 oli
    old "Sure, mom, no problem."
    new "بله، مامان، هیچ اشکالی ندارم."

    # say L4337 oli
    old "Alright, [pla], wish me luck."
    new "باشه، [pla]، بخت خوایی."

    # say L4338 pla
    old "Good luck, I know you've got this."
    new "بخت خوایی، میدونم تو قدرت داری."

    # say L4348 pla
    old "Alright, that was rather fast."
    new "البته، این خیلی سریع بود."

    # say L4350 oli
    old "I'm doing okay."
    new "من خوب هستم."

    # say L4352 oli
    old "Really, [pla], I'm completely fine with this."
    new "حقیقتاً، [pla]، من با این حالت کاملاً خوبم."

    # say L4354 oli
    old "I was a little worried that my mom was going to be all annoying about it."
    new "من قبلاً نگران بودم مامان خیلی ناراحت شه از این موضوع."

    # say L4356 oli
    old "But she seems to be completely okay with all of this, so there's no problem really."
    new "ولی به نظر می‌رسه مامان کاملاً با همه اینا موافقت می‌کنه، پس واقعاً مشکلی نداره."

    # say L4358 pla
    old "That sounds alright."
    new "این خوبه."

    # say L4365 mar
    old "I'm sorry to bother you, sir, but it's time for the patient to rest."
    new "متأسفم که شما را آزار دادم، اما وقت است بیمار خواب ببرد."

    # say L4367 pla
    old "Alright, I guess I'll see you later then."
    new "باشه، حدس می‌زنم بعداً می‌بینیم."

    # say L4369 oli
    old "Sure, and hey, [pla], thanks again."
    new "بله، و هی، [pla]، ممنونم دوباره."

    # say L4371 oli
    old "This big shift in my life wouldn't have been possible without you."
    new "این تغییر بزرگ در زندگی من بدون تو امکان‌پذیر نبود."

    # say L4373 oli
    old "I hope we'll continue being friends."
    new "امیدوارم همیشه دوست باشیم."

    # say L4375 oli
    old "And hey, come see me whenever you want. We don't have to stop having fun after this."
    new "و بله، هر وقت خواستی بیا ببینم. ما می‌تونیم بعد از این هم لذت ببریم."

    # say L4376 pla
    old "Sure, I'll do it."
    new "بله، انجام میدم."

    # say L4385 pla
    old "Hey, how do you feel?"
    new "سلام، حس می‌کنی چطوری؟"

    # say L4387 oli
    old "I'm doing alright, it was a lot easier than I expected, you know?"
    new "من خوب هستم، خیلی ساده‌تر از آنچه فکر می‌کردم بود، می‌دونی؟"

    # say L4388 pla
    old "It was?"
    new "وای، واقعاً؟"

    # say L4390 oli
    old "Yeah, it was. The doctor really helped me."
    new "بله، همین‌طور بود. دکتر واقعاً به من کمک کرد."

    # say L4391 oli
    old "So I didn't feel a lot of pain."
    new "پس خیلی درد نکشید."

    # say L4392 pla
    old "That sounds great, Olivia. That's awesome."
    new "ایولیویا، این خبر عالیه. خوشحالم."

    # say L4399 mar
    old "Would the new parents like to meet their newborn son?"
    new "آیا والدین جدید می‌خواهند پسر نو‌زاد خود را ببینند؟"

    # say L4402 oli
    old "But I think I'm a little too tired to hold him right now."
    new "ولی فکر کنم خیلی خسته‌ام تا الانش بگیرم."

    # say L4403 oli
    old "But why don't you do it, [pla]?"
    new "اما چرا تو انجام بدی، [pla]؟"

    # say L4419 oli
    old "How about you, [pla]?"
    new "تو چطوری، [pla]؟"

    # say L4422 pla
    old "I'm actually alright, you know?"
    new "من در واقع خوب هستم، میدونی؟"

    # say L4424 pla
    old "I have to say, I never expected to be a father so soon."
    new "باید بگم، هرگز منتظر نبودم اینقدر زود پدر شم."

    # say L4426 pla
    old "But I can't say that I feel bad about any of this."
    new "اما نمی‌تونم بگم که از هیچ بخشی ناراحتم."

    # say L4428 pla
    old "I never expected to have all these feelings within me."
    new "من هرگز انتظار نداشتم این همه احساس درون من باشه."

    # say L4430 pla
    old "But I think it's great, really."
    new "ولی فکر کنم عالیه، واقعاً."

    # say L4432 oli
    old "I'm so glad you feel that way, [pla]."
    new "خوشحالم که اینطور می‌تونی حس کنی، [pla]."

    # say L4433 oli
    old "And by the way, you don't need to worry about anything related to money, you know?"
    new "و بقیه، نباید نگران هیچ چیز مربوط به پول باشی، دی."

    # say L4435 oli
    old "My dad said he's moving here to be closer to his grandson."
    new "پدرم گفت که برای نزدیک شدن به نوه‌اش اینجا می‌آید."

    # say L4437 oli
    old "So I don't think you'll need to worry about that."
    new "پس فکر نمی‌کنم نگران اون باشی."

    # say L4439 pla
    old "I see, well, that's good."
    new "ببین، خوبه."

    # say L4441 oli
    old "And by the way, we can still keep in touch."
    new "و بعلاوه، هنوز می‌تونیم با هم در ارتباط باشیم."

    # say L4442 oli
    old "I'll be expecting some of your visits in the future."
    new "من منتظر بازدیدهایت در آینده خواهم بود."

    # say L4443 pla
    old "A- and I'll be sure to visit you."
    new "و من هم مطمئن می‌شوم که به تو می‌آیم."

    # say L4450 mar
    old "I'm sorry, sir, but the mother needs to rest."
    new "ببخشید، آقایان، اما مادر باید استراحت کنه."

    # say L4451 mar
    old "And visiting hours are almost over."
    new "و ساعت زیارت هم تقریباً تمام شده."

    # say L4453 pla
    old "No problem, I'll leave right now."
    new "باشه، الان می‌روم."

    # say L4456 oli
    old "Sure, and [pla], thanks again. For everything."
    new "بله، و [pla]، ممنون دوباره. از همه."

    # say L4468 bri
    old "Alright, [pla]! You are just on time!"
    new "البته، [pla]! خوشحالم که هم زمان شدی."

    # say L4469 bri
    old "We have to unload the magic from the spell into the magic portal."
    new "باید جادو رو از تلسم به پورتال جادویی منتقل کنیم."

    # say L4471 pla
    old "Oh right, okay, how do we do that?"
    new "اوه درسته، خب چطور باید این کار رو انجام بدیم؟"

    # say L4472 bri
    old "Oh, that's the best part. Come with me."
    new "اوه، این قسمت بهترین هست. با من بیا."

    # say L4478 bri
    old "Alright, here we are, I've prepared the portal to receive the magic power you collected from Olivia."
    new "البته، اینجا هستیم، من دروازه‌ای آماده کردم تا قدرت جادویی که از اولیویا جمع کردی را دریافت کند."

    # say L4479 bri
    old "Now, drop your pants."
    new "الان، لباس پایینتو بردار."

    # say L4480 pla
    old "Oh! So that's how it's done..."
    new "اوه! پس اینجوری هست..."

    # say L4481 bri
    old "Of course! Were you expecting anything else? Come on, let me help you."
    new "البته! آیا انتظار می‌ری چیز دیگه‌ای باشه؟ بیا، بگذار من به تو کمک کنم."

    # say L4490 bri
    old "That's it, [pla]!"
    new "آره، ز[pla]!"

    # say L4491 bri
    old "Just relax and let me do the work."
    new "فقط آرام شو و بگذار من کار رو انجام بدم."

    # say L4492 bri
    old "You just need to focus on enjoying it."
    new "تو فقط باید لذت بردن رو تمرکز کنی."

    # say L4501 bri
    old "Wonderful, [pla]!"
    new "عالی، [pla]!"

    # say L4502 bri
    old "This is the best first experience we could've hoped for."
    new "این بهترین تجربه اولیه‌ای بود که می‌تونستیم امیدوار باشیم."

    # say L4503 bri
    old "But now, don't forget that we need to keep looking for other subjects."
    new "اما حالا، فراموش نکن که باید به دنبال موضوعات دیگر هم بگردیم."

    # say L4504 pla
    old "Hmph, yeah sure."
    new "هم، البته."

    # say L4520 vee
    old "Hi, [pla], how are you doing?"
    new "سلام، [pla]، حالت چطوره؟"

    # say L4522 pla
    old "Hi, Mrs. Priya. I'm doing alright, and you?"
    new "سلام، خانم پریا. من خوب هستم، تو چطوری؟"

    # say L4524 vee
    old "I'm alright, honey."
    new "من خوبم، عزیزم."

    # say L4525 vee
    old "A little busy, but that's normal."
    new "من کمی مشغول هستم، ولی این طبیعی است."

    # say L4529 vee
    old "And tell me, what brings you here today, honey?"
    new "و بگو، امروز چه خبری داری، عزیزم؟"

    # say L4530 pla
    old "Well, not much. I was just passing by and wanted to say hello."
    new "خب، خیلی چیزی نیست. فقط می‌گذرم و می‌خواستم سلام بگم."

    # say L4532 vee
    old "Oh dear, aren't you sweet."
    new "اوه عزیزم، چقدر شیرینی."

    # say L4534 vee
    old "It's good to see you."
    new "خوشحالم که تو رو دیدم."

    # say L4535 vee
    old "Be sure to come back soon, dear."
    new "حتماً زودی بیا، عزیزم."

    # say L4537 vee
    old "With all the help you've given Olivia, you're always more than welcome."
    new "با همه کمکی که به اولیویا دادی، همیشه خوشحال می‌شوم که بیایی."

    # say L4538 pla
    old "Thanks a lot, ma'am."
    new "ممنونم، عزیزم."

    # say L4541 vee
    old "See you, honey."
    new "ببینم تو، عزیزم."

    # say L4545 vee
    old "Hello, [pla]! It's so good to see you. How are you?"
    new "سلام، [pla]! خوشحالم که تو رو دیدم. چطوری؟"

    # say L4548 vee
    old "I'm okay, dear."
    new "من خوبم، عزیزم."

    # say L4550 vee
    old "I've been a little busy ever since the baby came, you know."
    new "از زمانی که بچه آمد، یه کم مشغول شدم، میدونی."

    # say L4552 vee
    old "But he's such a bundle of joy that he's made everything so cheerful around here!"
    new "ولی او چنین بسته‌ای از خوشحالی است که همه چیز رو خوشحال کرده!"

    # say L4554 pla
    old "That's very good to hear, Mrs. Priya."
    new "خوشحالم که اینطور می‌شنوم، خانم پریا."

    # say L4555 vee
    old "Tell me, honey, what brings you here today?"
    new "بگو، عزیزم، امروز چه خبری داری؟"

    # say L4557 pla
    old "Oh, I just wanted to say hello."
    new "اوه، فقط می‌خواستم سلام بزنم."

    # say L4559 pla
    old "See how you're doing and stuff."
    new "ببینم اوضاعت چطوره و اینجوری."

    # say L4561 vee
    old "Aren't you sweet?"
    new "تو همیشه همینطور لطف داری، حلوایی."

    # say L4563 vee
    old "Well, as you can see, we're doing more than alright."
    new "خب، همچون می‌بینی، ما خیلی بیشتر از خوب هستیم."

    # say L4565 vee
    old "It's a shame the baby's sleeping now, otherwise you could see him."
    new "البته، شرمنده که بچه الان خوابیده، در غیر این صورت می‌تونستیش ببینی."

    # say L4567 vee
    old "But maybe some other time."
    new "اما شاید بار بعد."

    # say L4570 pla
    old "Well, it was good seeing you, Mrs. Priya. I'll be sure to come back later."
    new "البته، خوشحالم که تو رو دیدم، خانم پریا. حتماً بعداً بر می‌گردم."

    # say L4572 vee
    old "Sure, dear, you're welcome anytime."
    new "البته، عزیزم، هر وقت خواستی بیا."

    # say L4574 vee
    old "Nice seeing you."
    new "خوشحالم که تو رو دیدم."

    # say L4576 pla
    old "Thanks, ma'am."
    new "ممنون، عزیزم."


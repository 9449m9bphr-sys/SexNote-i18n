# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/HinnHome.rpy
translate persian strings:

    # say L20 pla
    old "I should find a therapist and talk with Mrs. Jade first."
    new "باید یک مشاور پیدا کنم و با خانم جید صحبت کنم."

    # say L26 pla
    old "I should talk with Mrs. Jade first."
    new "باید اول با خانم جید صحبت کنم."

    # say L32 pla
    old "I should talk with Dr. Johnson first."
    new "باید اول با دکتر جانسون صحبت کنم."

    # say L91 pla
    old "Hey Hinn!"
    new "هی هین!"

    # say L93 hin
    old "Hi [pla], how are you doing?"
    new "سلام [pla]، حالت چطوره؟"

    # say L95 pla
    old "Great and you?"
    new "عالی و تو چطوری؟"

    # say L97 hin
    old "I'm fine. I wanted to ask you if you've shown our progress to Mrs. Mia?"
    new "من خوبم. می‌خواستم بپرسم آیا پیشرفتمون رو به خانم میا نشون دادی؟"

    # say L99 pla
    old "Oh sorry. I haven't yet."
    new "اوه ببخشید. هنوز نشون ندادم."

    # say L101 hin
    old "Well, we should do it before continuing."
    new "خب، باید قبل از ادامه این کار رو بکنیم."

    # say L103 pla
    old "Ok, doing it now."
    new "باشه، الان انجام میدم."

    # say L112 hin
    old "Hi, [pla]..."
    new "سلام، [pla]..."

    # say L114 pla
    old "Hey, Hinn... I wanted to talk about yesterday."
    new "های، هین... من می‌خواستم درباره دیروز با تو صحبت کنم."

    # say L116 hin
    old "Oh... Listen... I'm so sorry. I shouldn't have got you into all this. It's my fault..."
    new "او... شنید... خیلی متاسفم. نباید تو رو به همه اینا ورود کردم. این اشتباه من بود..."

    # say L118 pla
    old "No, no, I agreed to help, in fact I think it was... fun."
    new "نه، نه، من هم موافقت کردم، در واقع فکر می‌کنم... خوشحال بودم."

    # say L122 pla
    old "Yes, I liked helping. Also, I think your mom did everything with good intentions."
    new "بله، لذت بردم از کمک کردن. همچنین فکر می‌کنم مامانت همه چیز رو با نیت خوب انجام داده."

    # say L124 hin
    old "Hmm... Maybe in her own way. But you're probably right."
    new "Hmm... شاید به طوری. اما احتمالاً همینطوری."

    # say L126 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is that you feel good about yourself."
    new "من واقعاً فکر می‌کنم هر لباسی که انتخاب می‌کنی خوب بهت می‌رسه، مهم‌ترین چیز اینه که تو خودت راضی باشی."

    # say L129 hin
    old "Thank you, [pla]. (He's so sweet.) I really appreciate it..."
    new "ممنون، [pla]. (وای، اینجوری شیرینه.) واقعاً ازش ممنونم..."

    # say L131 pla
    old "My pleasure... Well, should we continue with the class project?"
    new "لذت من بود... خب، باید ادامه‌ی پروژه‌ی کلاس رو بدیم؟"

    # say L134 hin
    old "Yes, lets do it."
    new "بله، بیای بذار بکنیم."

    # say L136 pla
    old "Great."
    new "عالی."

    # say L154 pla
    old "Wow Hinn, you changed your outfit..."
    new "واو هین، لباست عوض شد..."

    # say L156 hin
    old "Well... I wanted to try something new... What do you think?"
    new "خب... می‌خواستم چیز جدیدی امتحان کنم... نظرت چیه؟"

    # say L158 pla
    old "You look great."
    new "تو خیلی خوب هستی."

    # say L162 pla
    old "Yes, but the most important thing is how do you feel?"
    new "بله، اما مهم‌ترین چیز اینه که تو چطور احساس می‌کنی؟"

    # say L165 hin
    old "Hmmm, I feel comfortable, the sessions with Dr. Johnson worked."
    new "همم، حس می‌کنم راحت هستم، جلسات با دکتر جانسون کار کرد."

    # say L169 hin
    old "Actually, we have a new session today."
    new "در واقع، امروز جلسه جدیدی داریم."

    # say L171 pla
    old "Oh perfect, are you ready?"
    new "اوه عالی، آماده‌ای؟"

    # say L173 hin
    old "Yes, let's go."
    new "بله، برویم."

    # say L189 hin
    old "I'm fine, thanks."
    new "من خوبم، ممنون."

    # say L191 pla
    old "I was wondering if you have a scheduled a new session with Dr. Johnson."
    new "من داشتم فکر می‌کردم که آیا جلسه جدیدی با دکتر جانسون رزرو کردی؟"

    # say L193 hin
    old "Yes, tomorrow morning don't worry."
    new "بله، فردا صبح نگران نباش."

    # say L195 pla
    old "Oh great, see you tomorrow then."
    new "عالی، فردا می‌بینیم."

    # say L200 hin
    old "Wait..."
    new "هین: صبر کن..."

    # say L202 hin
    old "We could... Practice again... If you want."
    new "می‌تونیم... دوباره تمرین کنیم... اگه بخوای."

    # say L207 pla
    old "Sounds great."
    new "این خوبه."

    # say L209 hin
    old "Nice."
    new "خوب."

    # say L216 pla
    old "That sounds great, but I can't right now."
    new "این خوبه، ولی الان نمی‌تونم."

    # say L218 hin
    old "Oh don't worry, see you tomorrow then."
    new "اوه نگران نباش، فردا می‌بینیم."

    # say L220 pla
    old "Great, see you."
    new "عالی، می‌بینیم."

    # say L227 hin
    old "Great!."
    new "عالی!"

    # say L245 pla
    old "I was wondering if you you have a scheduled a new sesión with Dr. Johnson."
    new "من خواستم ببینم آیا شما جلسه جدیدی با دکتر جانسون رزرو کرده‌ای."

    # say L251 hin
    old "See you."
    new "ببینم."

    # say L296 pla
    old "No, no, sorry I was just walking around. I have to go."
    new "نه، نه، معذرت، فقط داشتم دایره می‌دم. باید برسم."

    # say L313 pla
    old "Hey, Hinn."
    new "سلام، هین."

    # say L315 hin
    old "Hi [pla], Are you ready to start?"
    new "سلام ز[pla]، آماده‌ای شروع کنیم؟"

    # say L319 pla
    old "Yes, I'm ready. Let's get to it."
    new "بله، آماده‌ام. بیای بیشتر."

    # menu L324 
    old "Not"
    new "نه"

    # say L326 pla
    old "Actually, I come to tell you I can't work with you today."
    new "در واقع، من برای این هستم که بگم امروز نمی‌تونم با تو کار کنم."

    # say L328 hin
    old "Oh, ok, don't worry we could work tomorrow on the class project."
    new "اوه، خب، نگران نباش، فردا روی پروژه کلاس کار می‌کنیم."

    # say L330 pla
    old "Of course, tomorrow we will be working hard!"
    new "البته، فردا خواهیم سخت کار کرد!"

    # say L332 hin
    old "Hehehe great, see you."
    new "خخخ عالی، ببینم تو."

    # say L334 pla
    old "See you Hinn."
    new "ببینم هین."

    # say L363 pla
    old "Damn, are we done? Really?"
    new "بچه، خیلی هم خوب، خیلی هم خوب. اینجوری تمام شد؟ واقاً؟"

    # say L365 hin
    old "Yup... Looks like that's everything..."
    new "بله... به نظر می‌رسه همه چیز انجام شده..."

    # say L367 pla
    old "Hinn? You look sad. You ok?"
    new "هین؟ تو خوشحالم نیستی. حالت خوبه؟"

    # say L369 hin
    old "Yeah, I'm fine... I'm happy we finally finished this project..."
    new "بله، خوبم... خوشحالم که در نهایت این پروژه رو تمام کردیم..."

    # say L371 pla
    old "Really?..."
    new "حقاً؟..."

    # say L373 hin
    old "Yes, it's nothing. Don't worry. Just give the final project to Mrs. Mia tomorrow and let me know what she says. Ok?"
    new "بله، هیچی. نگران نباش. فقط پروژه نهایی رو به خانم میا دادن و به من بگو چه می‌گه. خوب؟"

    # say L375 pla
    old "Alright, Hinn. No problem."
    new "باشه، هین. مشکلی نداره."

    # say L377 hin
    old "See you tomorrow, [pla]."
    new "ببینم دیروز، [pla]."

    # say L380 pla
    old "See you tomorrow, Hinn."
    new "ببینم تو روز بعد هم اینجا باشی، هین."

    # say L396 pla
    old "Well, we made a lot of progress!"
    new "بله، خیلی پیشرفت کردیم!"

    # say L398 hin
    old "Yes, it's a little late. We should continue tomorrow."
    new "بله، الان کمی دیره. باید فردا ادامه بدیم."

    # say L400 pla
    old "Ok, see you tomorrow, Hinn. Have a good night."
    new "باشه، ببینم چه کاری می‌کنم. خوب بخواب، هین."

    # say L402 hin
    old "By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "باید به خانم میا پیشرفتمون رو نشون بده، بیاین ببینه چقدر پیش رفته‌ایم. ببین هم‌دی."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/JonStory.rpy
translate persian strings:

    # say L6 bil
    old "Oh... hey."
    new "اوه... سلام."

    # say L7 pla
    old "... Uhh hi."
    new "... اوه سلام."

    # say L8 bil
    old "This is a bit awkward... Do you need something?"
    new "این کمی ناراحت کننده است... چیزی می‌خوای؟"

    # say L33 bil
    old "Weird."
    new "عجیب."

    # say L39 pla
    old "Oh, no, no sorry, I was just looking for Mrs. Jones."
    new "نه، نه، معذرت، فقط دنبال خانم جونز بودم."

    # say L41 pla
    old "... Alright, see you."
    new "باشه، می‌بینم."

    # say L53 pla
    old "Hi everybody, how are you doing?"
    new "سلام همه، چطور هستید؟"

    # say L54 gra
    old "Hi [pla], God be with you!"
    new "سلام ز[pla]، خدا با تو باشد!"

    # say L55 jon
    old "Hi [pla] so happy to see you! We were talking about you..."
    new "سلام ز[pla]، خوشحالم که دیدمت! ما در موردت صحبت می‌کردیم..."

    # say L56 gra
    old "In fact, we were talking about you with Father Morgan as well."
    new "در واقع، ما با پدر مورگان هم در موردت صحبت می‌کردیم."

    # say L57 pla
    old "Oh! Really? What were you saying about me? Am I in trouble?"
    new "اوه! واقعاً؟ درباره من چه می‌گفتید؟ آیا مشکلی برایم پیش آمده؟"

    # say L58 jon
    old "Noo! It's the opposite, we are so grateful for what you've done for us."
    new "نه! همین عکس است، ما بسیار ممنون از آنچه برای ما انجام داده‌اید."

    # say L59 jon
    old "Billie is feeling good now and we can feel our church is a peaceful place again, all thanks to you."
    new "بیلی حالا حالت خوبه و ما می‌تونیم احساس کنیم کلیسای ما دوباره جای آرامش‌بخشیه، همه این‌ها بخاطر توه."

    # say L60 pla
    old "Well... I-I just did what God told me to do... It was actually him, not me."
    new "خب... من فقط آنچه را که خداوند به من فرمان داد انجام دادم... در واقع او بود، نه من."

    # say L62 gra
    old "And that's why we want you to be part of our community, we want you to join our activities."
    new "و برای همین می‌خواهیم شما را در جامعه‌مان داشته باشیم، می‌خواهیم در فعالیت‌های ما شرکت کنی."

    # say L63 jon
    old "We saw how God works through your hands, you've shown us that you're like a saint."
    new "ما دیدیم چطور خداوند از طریق دست‌هایت کار می‌کند، نشان دادی که مثل یک قدیس هستی."

    # say L64 gra
    old "Join us, please! It would be our pleasure to have you here."
    new "لطفاً با ما همراه شوید! خوشحال می‌شویم که شما در اینجا باشید."

    # say L65 pla
    old "(Yes! This is the perfect chance to get closer to them...)"
    new "بله! این فرصت خوبیه تا بهشون نزدیک شم..."

    # say L66 pla
    old "I'm so glad to hear that, of course I will be more than happy to be here helping and being part of the community."
    new "خوشحالم که اینجوری فکر می‌کنید، البته خوشحال می‌شوم که اینجا باشم و به جامعه کمک کنم."

    # say L67 pla
    old "I can start whenever you want... Just tell me what to do."
    new "می‌تونم هر وقتی که می‌خوای شروع کنم... فقط بگو برام چی کار کنم."

    # say L69 jon
    old "Oh really hun, that's great!"
    new "اوه وای عزیزم، این خیلی خوبه!"

    # say L70 gra
    old "Well, our main interest is to attract more young people to the community."
    new "خب، علاقه‌ماند ما اینه که جوان‌ترین‌ها رو به جامعه جذب کنیم."

    # say L72 jon
    old "That's why we believe that you are the best to help us and with your example and attitude we believe that we will be able to attract many young people."
    new "به همین خاطر فکر می‌کنیم شما بهترین نفر برای کمک به ما هستید و با مثال و رفتار خودتون مطمئن هستیم بسیار جوان‌ترین‌ها را به جامعه جذب کنیم."

    # say L73 gra
    old "Even get to have altar girls in the church!"
    new "حتی دختران مذبح در کلیسا داشته باشیم!"

    # say L74 pla
    old "Wow, that's sounds good, so what do you want me to do?"
    new "واو، این خوبه، پس می‌خواین از من چه کاری بکنم؟"

    # say L75 gra
    old "Well, we have to wait a bit for that. Father Morgan is a bit busy these days and we can't start without him."
    new "خب، باید کمی صبر کنیم. پدر مورگان این روزها خیلی مشغوله و بدون او نمی‌تونیم شروع کنیم."

    # say L76 jon
    old "However, we still need help in other activities. And a young hand would be very useful."
    new "البته، ما هنوز در فعالیت‌های دیگر به کمک نیاز داریم. و یک دست جوان بسیار مفید خواهد بود."

    # say L77 jon
    old "For example, cleaning the church after every mass is very tiring for just the two of us."
    new "مثلاً، تمیز کردن کلیسا بعد از هر مراسم برای فقط دو نفر خیلی خسته‌کننده است."

    # say L80 gra
    old "Perfect! So, you can come every afternoon to help us with the cleaning, the three of us can finish in a jiffy."
    new "عالی! پس می‌تونی هر عصر بیاد کمک ما کنی تا سه ما این کار رو به سرعت تمام کنیم."

    # say L82 jon
    old "Great, then why don't we start tomorrow, okay?"
    new "عالی، پس چرا از فردا شروع نکنیم، خوبه؟"

    # say L83 pla
    old "Alright! So I'll be back tomorrow."
    new "باشه! پس فردا می‌گردم."

    # say L84 jon
    old "Thank you so much hun, see you tomorrow!"
    new "ممنونم عزیزم، فردا می‌بینیم."

    # say L85 gra
    old "Bye [pla]"
    new "بای [pla]"

    # say L86 pla
    old "S-see you Mrs. Jones and sister Grace."
    new "bebem خانم جونز و خواهر گریس."

    # say L102 gra
    old "Oh, hi [pla], you came just in time!"
    new "اوه، سلام [pla]، همینطور وقت خوبی اومدی!"

    # say L103 pla
    old "Hi, well, I don't want to leave all the work to just the two of you."
    new "سلام، خب، نمی‌خوام همه کار رو فقط به شما دو تا بذارم."

    # say L104 jon
    old "Oh thank you honey, you are so kind."
    new "اوه ممنون عزیزم، خیلی لطف داری."

    # say L105 gra
    old "Ok, let me explain you, it's simple, we just have to clean up the church a bit... As you can see, it's a mess!"
    new "خب، براتون توضیح می‌دم، خیلی ساده هست، ما فقط باید کلیسا رو یه کم تمیز کنیم... می‌بینید، اینجا همه جا درهم و برهم هست!"

    # say L106 gra
    old "[pla], pick up papers if you see them on the floor... You know, make the place pretty."
    new "[pla]، اگر کاغذی روی زمین دیدی، بردار... می‌دونی، جایی خوب کن."

    # say L108 jon
    old "And pick up what shouldn't be in the church right now... All those stuff."
    new "و چیزهایی که نباید الان در کلیسا باشند رو هم بردار... همه اون جور چیزها."

    # say L110 jon
    old "This will be too easy for you, cleaning won't be an issue..."
    new "این برای تو خیلی آسان خواهد بود، تمیز کردن مشکلی نمی‌سازه..."

    # say L111 pla
    old "Don't worry, I wanna be as quick as possible."
    new "نگران نباش، من می‌خوام سریع‌ترین باشم."

    # say L112 gra
    old "So, hurry up hun, hahaha."
    new "پس، حواست باشه عزیزم، هاهاها."

    # say L124 gra
    old "Oh, hi [pla], How are you today?"
    new "اوه، سلام ز[pla]، امروز چطوری؟"

    # say L125 pla
    old "Hi sister Grace, I'm pretty good, thanks for asking."
    new "سلام خواهر گریس، خوبم، ممنون که پرسیدی."

    # say L126 jon
    old "Great Hun, are you ready to start with cleaning?"
    new "عالی عزیزم، آماده‌ای برای شروع پاک‌سازی؟"

    # say L127 pla
    old "Sure, I'm ready to start."
    new "بله، آماده‌ام برای شروع."

    # say L128 gra
    old "Perfect, let's start to clean the church."
    new "عالی، بیایید شروع به تمیز کردن کلیسا کنیم."

    # say L139 jon
    old "Hi [pla], you came early, I'm waiting for sister Grace, she is with Father Morgan."
    new "سلام ز[pla]، اینقدر زود آمدی، منتظر خواهر گریس هستم، او با پدر مورگان است."

    # say L140 pla
    old "Oh, don't worry. I can accompany you in the meantime."
    new "اوه، نگران نباش. من می‌تونم تو این مدت با تو باشم."

    # say L141 jon
    old "Oh, thanks hun... I really appreciate your help on this."
    new "اوه، ممنون عزیزم... واقعاً از کمکت قدردانی می‌کنم."

    # say L142 jon
    old "I'm old and you know... I'm not as flexible as I was before."
    new "من قدیمی هستم و می‌دونی... قبلاً انعطاف‌پذیرتر بودم."

    # say L143 pla
    old "Hmm... I'm sorry to hear that... I think you're still young, though."
    new "همم... متاسفم که اینجوری شده... ولی فکر می‌کنم هنوز جوانی."

    # say L144 jon
    old "You know, when I look at you... I see a very kind person, you're really nice, dear."
    new "می‌دونی، وقتی به تو نگاه می‌کنم... انسان خوبی رو می‌بینم، واقعاً لطف داری، عزیزم."

    # say L145 pla
    old "Haha, thanks Mrs. Jones!"
    new "هه، ممنون می‌تونم بگم خانم جونز!"

    # say L146 jon
    old "You're like an angel... Sent by God!"
    new "شما مثل یک فرشتگی هستید... از خدا فرستاده شده‌اید!"

    # say L148 pla
    old "That's very nice of you but I'm just a normal guy..."
    new "این خیلی لطف داری اما من فقط یه مرد عادی هستم..."

    # say L149 jon
    old "You know dear... It's like destiny, I think you're here for a reason.."
    new "جان عزیزم... مثل قدرت آسمانی هست، فکر می‌کنم تو اینجا برای یک دلیل خاص هستی."

    # say L150 pla
    old "Ehm... Really?"
    new "اوه... واقعاً؟"

    # say L152 jon
    old "I've seen what you've done and well... Yeah! I think so..."
    new "من دیدم چه کارهایی انجام دادی و خب... بله! فکر می‌کنم همین‌طور است."

    # say L153 jon
    old "You're very spiritual and you remind me of..."
    new "شما خیلی معنوی هستید و به من از... به یاد می‌آورید."

    # say L154 pla
    old "Remind you of? W- Who?"
    new "به یادت می‌آوری؟ و- و کی؟"

    # say L156 jon
    old "You remind me of my husband. When he was alive, he was so kind and strong, just like you."
    new "شما به مرد من یادآور می‌شید. وقتی زنده بود، خیلی مهربان و قوی بود، مثل شما."

    # say L157 jon
    old "He was amazing, I truly miss him."
    new "او عالی بود، واقعاً او را می‌فوتم."

    # say L165 gra
    old "Hey [pla], I didn't know you were here... I see you're very committed to our community. How are you?"
    new "اوه ز[pla]، نمی‌دونستم اینجا هستی... می‌بینم به جامعه‌مون خیلی وفاداری. حالت چطوره؟"

    # say L166 pla
    old "I'm fine... And you?"
    new "من خوبم... تو چطوری؟"

    # say L168 gra
    old "All good!"
    new "خوب هستم!"

    # say L169 gra
    old "Great! Mrs. Jones? We need to start cleaning, this is really a mess!"
    new "عالی! خانم جونز؟ باید شروع به تمیز کردن کنیم، اینجا واقعاً درهم و برهم است!"

    # say L170 jon
    old "Yeah, sure sister Grace..."
    new "بله، البته خواهر گریس..."

    # say L171 gra
    old "Let's get this done! We have many things to do."
    new "بیایید این کار رو تمام کنیم! کارهای زیادی داریم."

    # say L172 pla
    old "(I have to find the way to get closer to Mrs. Jones...)"
    new "من باید راهی پیدا کنم تا نزدیک‌تر به خانم جونز بشم..."

    # say L173 gra
    old "[pla]? Are you with us?"
    new "[pla]؟ شما با ما هستید؟"

    # say L174 pla
    old "Yeah... Yeah, sure... Let's do it."
    new "بله... بله، حتماً... بیایید انجام بدیم."

    # say L188 jon
    old "Wow! That was a hard job! I'm exhausted..."
    new "واو! این کار خیلی سخت بود! من خسته‌ام..."

    # say L189 gra
    old "It was a lot, yeah... "
    new "بله، خیلی کار بود..."

    # say L191 jon
    old "sister Grace, I'm gonna go now..."
    new "خواهر گریس، من الان می‌روم..."

    # say L192 gra
    old "Oh, do you have to leave early today?"
    new "اوه، باید امروز زودتر بری؟"

    # say L193 jon
    old "Yes, I think it would be nice to spend some time with Billie too, I'll go to see her."
    new "بله، فکر می‌کنم خوب باشه که یه وقت با بیلی هم بگذرونم، می‌روم برای دیدنش."

    # say L194 gra
    old "Ahh! Of course, Mrs. Jones... Have fun with your granddaughter. I'll be in good hands with [pla] here."
    new "اوه! البته، خانم جونز... با بیلی هم لذت ببر. من با [pla] اینجا خوب می‌مونم."

    # say L195 jon
    old "You'll, see you sister Grace..."
    new "خداحافظ، خواهر گریس..."

    # say L197 jon
    old "See you [pla]."
    new "به زودی می‌بینم [pla]."

    # say L198 pla
    old "Bye Mrs. Jones, take care."
    new "خداحافظ خانم جونز، مراقب خودتان با."

    # say L204 gra
    old "You did a great job today [pla]."
    new "امروز کار خوبی انجام دادی [pla]."

    # say L205 pla
    old "Thanks, we all worked really hard."
    new "ممنون، همه ما خیلی سخت کار کردیم."

    # say L207 gra
    old "I've noticed how spiritual and good you're... I'm a bit embarrased to ask you this but..."
    new "من توجه کردم چقدر معنوی و خوبی... اما یه کم خجالت می‌کنم بپرسم ازت..."

    # say L208 gra
    old "But... I would like to ask for your help."
    new "اما... من می‌خوام از شما درخواست کنم کمک کنید."

    # say L210 pla
    old "My help? Sure, tell me sister Grace. What can I do for you?"
    new "کمک من؟ البته، بگو خواهر گریس. من برایت چه کاری می‌تونم بکنم؟"

    # say L211 gra
    old "W- well... I wanna clean my spirit and my soul... I've been working on this with Father Morgan..."
    new "خب... می‌خوام روح و روانم رو تمیز کنم... اینجوری با پدر مورگان کار می‌کنم..."

    # say L212 gra
    old "But to be honest I think you're much more spiritual than him, perhaps you could help me more..."
    new "اما صادقانه بگم فکر می‌کنم تو خیلی معنوی‌تر از او هستی، شاید بتونی به من کمک بیشتری کنی..."

    # say L214 pla
    old "(I think see where this is going...)"
    new "فکر کنم متوجه هستم که اینجا چه جوری می‌روی..."

    # say L215 gra
    old "I mean, you did the exorcism... You helped Billie and you're nice with everyone. I can feel your energy is different."
    new "من قصد دارم، تو اکسورسیزم رو انجام دادی... تو به بیلی کمک کردی و با همه خوب رفتار می‌کنی. من می‌تونم انرژیت رو حس کنم و متفاوته."

    # say L216 gra
    old "It's divine and sacred."
    new "این مقدس و مبارک است."

    # say L217 pla
    old "I'm glad you think that of me and if you truly believe I could help you out, I'll do it..."
    new "خوشحالم که اینطور فکر می‌کنی و اگر واقعاً باور داری که می‌تونم بهت کمک کنم، من هم این کار رو می‌کنم..."

    # say L218 gra
    old "I feel a bit embarrassed, I'll do what I believe is good and saint, and I'm thinking of you as a blessed man..."
    new "من کمی خجالت زده‌ام، من آنچه را که خوب و مقدس می‌دانم انجام می‌دهم و شما را به عنوان یک مرد مبارک می‌شناسم..."

    # say L219 gra
    old "I'll be honest with you... Since I saw you performing the ritual with Billie, I have been constantly thinking of you."
    new "من با شما صادقانه خواهم بود... از زمانی که شما مراسم رو با بیلی انجام دادید، همیشه در حال فکر کردن به شما بودم."

    # say L223 gra
    old "I feel like you can help me as you helped her. You saved her and you could save me too."
    new "من احساس می‌کنم می‌توانی مثل همین که به او کمک کردی، به من هم کمک کنی. تو او را نجات دادی و می‌توانی من را هم نجات بدی."

    # say L224 pla
    old "(Wow) O- ok..."
    new "واو، اوکی..."

    # say L225 gra
    old "I need to cleanse my soul."
    new "من باید روحمو تمیز کنم."

    # say L226 gra
    old "I would need to go down on you."
    new "من باید روی تو بیوفتم."

    # say L228 pla
    old "W-What? D-down?"
    new "W- چه؟ D- پایین؟"

    # say L229 gra
    old "I have to pray in a different way."
    new "من باید به شکل دیگری نماز بخوانم."

    # say L231 pla
    old "A- Are y- you s- sure about that?"
    new "آ- آیا تو م- مطمئن هستی در مورد این؟"

    # say L232 gra
    old "You helped Billie and everytime I'm next to you, I can feel your divine and strong energy."
    new "شما به بیلی کمک کردی و هر بار که کنارت می‌دم، انرژی الهی و قوی تو را می‌حسم."

    # say L233 gra
    old "W- Would you please... L- let me suck your... D- dick?"
    new "لطفاً... ب-�گذارم خ-خیالتو ببرم؟"

    # say L235 pla
    old "(This is really in line with the plan, I should do whatever it takes.)"
    new "این واقعاً با برنامه همخوانی داره، باید هر چه لازم باشه انجام بدم."

    # say L236 pla
    old "S- sister Grace... I'll always do what is required to help you and to help the church's community."
    new "خواهر گریس... من همیشه آماده‌ام برای کمکت و کمک جامعه کلیسا."

    # say L237 gra
    old "I will really appreciate your help."
    new "اونقدر از کمکت ممنون می‌شم."

    # say L251 gra
    old "Wow, I do feel much better now, kinda renewed. I'm your faithful devotee."
    new "البته، حالا خیلی بهتر هستم، مثل آدم جدیدی. من وفادار به تو هستم."

    # say L252 gra
    old "I would do everything for you as you have done everything for our community."
    new "من برایت هر کاری می‌کنم، مثل اینکه تو برای جامعه‌مان همه چیز را انجام دادی."

    # say L253 pla
    old "(Oh hell! She really liked it.)"
    new "اوه خدا! واقعاً لذت برده."

    # say L254 pla
    old "You don't have to... I'm glad to help sister Grace..."
    new "تو نمی‌تونی... خوشحالم که کمک کردم، خواهر گریس..."

    # say L256 gra
    old "And you're so humble..."
    new "و تو هم خیلی متواضعی..."

    # say L257 gra
    old "I feel a bit embarrassed now, I've kept you here for quite a long time. I'm sure you have to rest."
    new "الان خجول می‌شوم، طول زمانی تو رو اینجا نگه داشتم. مطمئن هستم که باید استراحت کنی."

    # say L259 pla
    old "Actually, yes, I do but it's fine."
    new "در واقع، بله، ولی مشکلی نداره."

    # say L260 gra
    old "Thank you so much."
    new "بسیار ممنون."

    # say L261 pla
    old "Hmm ok... I- I think should go..."
    new "Hmm خب... من- من فکر کنم باید برسم..."

    # say L262 gra
    old "Yeah, of course, I have to go as well, see you [pla]."
    new "بله، البته، من هم باید برسم، دوباره ببینیم [pla]."

    # say L263 pla
    old "See you sister Grace."
    new "دوباره ببینیم، خواهر گریس."

    # say L280 jon
    old "I'm more tired than last time... And my back is killing me."
    new "من خسته‌تر از آخر بار هستم... و پشتم خیلی درد می‌کند."

    # say L281 gra
    old "Ohh, I'm so sorry Mrs. Jones... [pla] could you please take Mrs. Jones to her house?"
    new "اوه، خیلی متاسفم خانم جونز... [pla] آیا می‌توانید خانم جونز را به خانه‌اش ببرید؟"

    # say L282 pla
    old "Of course, I'll be happy to do it."
    new "البته، خوشحال می‌شوم این کار رو بکنم."

    # say L283 jon
    old "Oh no, it's not necessary, don't worry..."
    new "اوه نه، لازم نیست، نگران نباشید..."

    # say L284 gra
    old "Mrs Jones, I inssist... [pla], she lives pretty close to the church."
    new "خانم جونز، من حتماً می‌خواهم... [pla]، او خیلی نزدیک به کلیسا زندگی می‌کند."

    # say L285 pla
    old "Alright, I will go with you Mrs. Jones, it's not a problem."
    new "البته، من همراهت می‌کنم خانم جونز، مشکلی نداره."

    # say L286 jon
    old "Hmm alright, but just this time."
    new "البته، ولی فقط این بار."

    # say L287 pla
    old "Sure, don't worry."
    new "باشه، نگران نباش."

    # say L288 gra
    old "Ok guys, see you tomorrow. Hope you get better, Mrs. Jones."
    new "خب بچه‌ها، به یاد داشته باشید فردا هم می‌آیم. امیدوارم بهبود یابید، خانم جونز."

    # say L289 jon
    old "Thank you honey."
    new "ممنون عزیزم."

    # say L295 jon
    old "I'm so glad you could come with me."
    new "خوشحالم که با من آمدید."

    # say L296 pla
    old "My pleasure Mrs. Jones."
    new "لذت من است خانم جونز."

    # say L297 jon
    old "Come inside with me... Let me give you something to drink."
    new "بیایید داخل بیایید... بیایید من به شما چیزی برای نوشیدن دهم."

    # say L298 pla
    old "Hmm... Yes, why not?"
    new "خوب... بله، چرا نه؟"

    # say L304 jon
    old "By the way, I'm still surprised at how similar you're to my husband when he was young."
    new "البته، هنوز هم تعجب می‌کنم از شباهت شما به همسرم وقت جوانی."

    # say L305 pla
    old "Oh, really? I imagine how great he was."
    new "اوه، واقعاً؟ من فکر می‌کنم چقدر عالی بود."

    # say L306 jon
    old "He was... So strong and manly."
    new "او بود... خیلی قوی و مردانه."

    # say L307 jon
    old "Just like you..."
    new "مثل تو..."

    # say L310 jon
    old "Hmm... I don't wanna put you in an uncomfortable position... Tell me more about yourself, we haven't talked about your spiritual development."
    new "همم... من نمی‌خوام تو رو به موقعیتی ناراحت کنم... بیشتر در مورد خودت به من بگو، ما هنوز در مورد رشد معنویت تو صحبت نکرده‌ایم."

    # say L311 pla
    old "(Actually, there is no a spiritual development...)"
    new "در واقع، هیچ تکامل روحانی ندارم..."

    # say L312 pla
    old "Ahhh! Well... It started- hmm, one day when I was walking and... Suddenly I felt the light, like a warm light all around my arms... Yeah, it was something like that."
    new "اوه! خب... اینجور شروع شد- هم، یک روز که داشتم قدم می‌زدم و... ناگهان احساس نور کردم، مثل یه نور گرم حول دستام... بله، تقریباً همینطور بود."

    # say L315 jon
    old "I asked because I want you to be my spiritual guide, I want to feel the grace of God within me. "
    new "من پرسیدم چون می‌خوام راهنمای روحیتی باشی، می‌خوام لطف خدا را درونم بیابم."

    # say L316 pla
    old "Your spiritual guide? Ok, but how do you think I could help you?"
    new "راهنمای روحیتی؟ خب، ولی فکر می‌کنی چطور می‌تونم به تو کمک کنم؟"

    # say L318 jon
    old "Well... The first time I saw you, I felt really impressed by your beauty. You're extremely handsome."
    new "خب... وقتی اولین بار شما رو دیدم، واقعاً از زیبایی شما تاثیر گرفتم. شما خیلی هانسوم هستید."

    # say L319 jon
    old "And as I told you the other day... You remind me of my great husband."
    new "و همانطور که به شما گفتم... شما به من خاطر آقای من به یاد می‌آید."

    # say L322 jon
    old "You know, when I look at you... I see that you could be my savior as he was years ago."
    new "میدونید، وقتی به شما نگاه می‌کنم... می‌بینم که می‌تونید مثل او سال‌ها پیش، نجات‌دهنده‌ام باشید."

    # say L323 pla
    old "Y- your savior? What do you mean Mrs. Jones?"
    new "خانم جونز، نجات‌دهنده‌ام؟ منظورت چیه؟"

    # say L324 jon
    old "Well, I know I look old but I have the needs of a young woman."
    new "خب، میدونم به نظر می‌رسم قدیمی هستم اما نیازهای یک زن جوان دارم."

    # say L325 pla
    old "Needs? Which type of needs?"
    new "نیاز؟ چه نوع نیاز؟"

    # say L326 jon
    old "Don't you imagine which needs I have? It's really easy to guess, I'm a widow."
    new "آیا به نظرت نمی‌رسه که چه نیازهایی دارم؟ حدس زدن اونقدر سخت نیست، من بیوه هستم."

    # say L327 pla
    old "I- I... Don't k- know if I- I am thinking wrong..."
    new "من- من... نمی‌دونم اگه من- من اشتباه فکر می‌کنم..."

    # say L328 jon
    old "I need a man in my life, I need to feel some adrenaline and you're like send by God... You're beautiful on the inside and outside."
    new "من نیاز به مردی در زندگیم دارم، نیاز دارم هیجان بکنم و تو مثل ارسال شده از خدا هستی... تو زیبا هستی از داخل و بیرون."

    # say L330 jon
    old "You're like a saint man and I believe in you since you helped Billie... I truly believe you can guide my spiritual journey."
    new "شما مثل یک قدیس هستید و از زمانی که به بیلی کمک کردید، در شما باور دارم... من واقعاً معتقدم که می‌توانید سفر روحی من را هدایت کنید."

    # say L331 pla
    old "What? Me?"
    new "چه؟ من؟"

    # say L332 jon
    old "Yes, you! I saw how you cured my granddaughter and I am not planning to let you go."
    new "بله، شما! من دیدم چطور نوه‌ام رو درمان کردی و قصد ندارم شما رو از دست بدهم."

    # say L333 jon
    old "Not without a taste of what is divine... I want you to be my holy savior until I feel what Billie felt."
    new "بدون اینکه طعم الهی را ببینی... می‌خواهم تو تا زمانی که همچون بیلی حس کنم، نجات‌دهنِ مقدس من باشی."

    # say L335 pla
    old "I- I don't know what to say... I mean, you're such a beautiful woman but... I don't know..."
    new "من- من نمی‌دونم چی بگم... منظورم اینه، تو یه زن خوشگلی هستی ولی... من نمی‌دونم..."

    # say L336 jon
    old "You already have the answer... Follow the will of God, you know this is the right thing to do, handsome."
    new "شما قبلاً جواب رو دارید... ارادة خدا را دنبال کنید، می‌دونید این راه درسته، زیبا."

    # say L337 pla
    old "(Ok, I think this can help me to do the ritual.)"
    new "باشه، فکر کنم این می‌تونه بهم کمک کنه تا مراسم رو انجام بدم."

    # say L338 pla
    old "Yes, if that is what you need, I'll do what is required. I'll follow God's will."
    new "بله، اگر این هستاند آنچه نیاز داری، من انجام می‌دهم. من به مشیت خدا پیروی می‌کنم."

    # say L339 jon
    old "I have no doubts... You were sent to clean my sins like I used to do with my husband..."
    new "من شکی ندارم... تو برای پاک کردن گناهان من ارسال شده‌ای مثل همین کاری که با شوهرم می‌کردم..."

    # say L340 pla
    old "What would you like to do that reminds you of him?"
    new "می‌خوای چی کنی که بهش یادت بیاره؟"

    # say L341 jon
    old "Well, I would love to start by putting your dick inside my mouth and then brushing it with my sinful lips..."
    new "خوب، من عاشق می‌شوم اگر از این جا شروع کنم با گذاشتن ناخن تو در دهانم و بعد آن را با لب‌های گناهکارم پاک کنم..."

    # say L342 pla
    old "... I guess God will be happy with that..."
    new "... حدس می‌زنم خدا از این خوشحال می‌شه..."

    # say L344 jon
    old "I want to have your sacred presence on my lips and keep the taste on my tongue..."
    new "می‌خواهم حضور مقدس شما روی لب‌هایم باشد و طعم آن را بر زبانم نگه دارم..."

    # say L345 pla
    old "(Maybe this is getting a bit out of hand?)"
    new "شاید این کمی از دست کنترل خارج شده؟"

    # say L360 jon
    old "That was incredible, you're a divine presence in my life and well..."
    new "این عالی بود، شما یک حضور الهی در زندگی من هستید و خب..."

    # say L361 jon
    old "I do feel so renewed and younger now."
    new "البته، حالا احساس تازگی و جوانی می‌کنم."

    # say L362 pla
    old "Hmm... I just did what God told me to do... It was my pleasure to help you."
    new "هم... من فقط آنچه را که خداوند به من فرمان داد انجام دادم... لذت بردم که به تو کمک کنم."

    # say L363 jon
    old "Did you enjoy it? Isn't?"
    new "آیا لذت برده بودی؟ نه؟"

    # say L365 jon
    old "Oh no hun! I'm sorry, I know this is just part of your holy duty... I shouldn't ask those things."
    new "اوه نه عزیزم! معذرت می‌خوام، میدونم این فقط بخشی از وظیفه‌ت مذهبیه... من نباید اینجوری سؤالات بپرسم."

    # say L366 pla
    old "Y- Yes Mrs. Jones, it's m- my d- duty."
    new "بله خانم جونز، این وظیفه‌ام است."

    # say L367 pla
    old "I should go now... It's getting late."
    new "باید حالا برسم... وقت پیش می‌ری."

    # say L369 jon
    old "Go with God, handsome... And thanks again. I'll be eager for more."
    new "با خدا برو، لبخندان... و مجدداً ممنون. منتظر این هستم که دوباره بیایی."

    # say L370 pla
    old "S- sure, goodbye Mrs. Jones."
    new "بله، خداحافظ مس جونز."

    # say L386 gra
    old "It was nice, now the church looks much better."
    new "خوش بود، حالا کلیسا خیلی بهتر به نظر می‌رسد."

    # say L387 pla
    old "It looks better now..."
    new "البته، الان بهتر به نظر می‌رسه..."

    # say L389 jon
    old "It's tiring to clean... "
    new "پاک کردن خسته‌کننده است..."

    # say L390 jon
    old "I'll see tomorrow... I gotta go now."
    new "فردا می‌بینم... حالا باید برسم."

    # say L391 pla
    old "See you Mrs. Jones..."
    new "ببینم شما، خانم جونز..."

    # say L392 gra
    old "Take care, dear."
    new "مراقب خودت باش، عزیزم."

    # say L399 gra
    old "I'm glad it's just the two of us now."
    new "خوشحالم که الان فقط ما دو تا هستیم."

    # say L400 pla
    old "Hmm... Yeah, it's nice."
    new "Hmm... بله، خوبه."

    # say L401 gra
    old "[pla] I have to tell you something."
    new "[pla] باید چیزی بهت بگم."

    # say L403 gra
    old "I think shouldn't feel so good when I'm with you... I should pay with pain, I should suffer..."
    new "فکر می‌کنم نباید وقتی با تو هستم اینقدر خوشحالم... باید با درد پرداخت کنم، باید تحمل کنم..."

    # say L406 gra
    old "I have never felt so much grace within me, my body feels renewed."
    new "هیچ وقت اینقدر نعمت درون من حس نکرده‌ام، بدنم احساس تجدید نیرو می‌کند."

    # say L407 gra
    old "But I'm not sure if that is ok... A spiritual journey requires suffering and I do not feel that it's fair just to feel pleasure and purification through you."
    new "اما مطمئن نیستم این درسته... سفر روحی نیاز به رنج دارد و من نمی‌تونم فقط لذت و تازشوندگی رو از طریق تو ببرم."

    # say L408 gra
    old "I need you to punish me, I have to do penance..."
    new "من نیاز دارم تا تو مرا مجازات کنی، من باید کفایر کنم..."

    # say L409 pla
    old "W-what?"
    new "و-وای، چه کاری می‌گی؟"

    # say L410 gra
    old "Yes, I know is what God wants and I know that with pain I will purify my soul..."
    new "بله، می‌دونم این همچین چیزی است که خدا می‌خواد و می‌دونم با درد روحم رو پاک می‌کنم..."

    # say L412 gra
    old "But I need you to guide and help me... Since you have given me so much purification, you should be the one punishing and showing me the way..."
    new "اما من به راهنمایی و کمک شما نیاز دارم... چون شما به من تهذیب زیادی داده‌اید، شما باید کسی باشید که مرا مجازات کنید و راه را برایم نشان دهید..."

    # say L414 pla
    old "A- alright... B- but, h- how?"
    new "ا- خب... ب- ولی، چ- چطور؟"

    # say L415 gra
    old "You're like my master. I need you to see me as your sinful slave who needs to come out of the dark side."
    new "شما مثل معلم من هستید. باید من رو به عنوان یک برده گناهکار ببینید که باید از طرف تاریک بیرون بیوم."

    # say L417 gra
    old "As I get naked, I know that God will enlighten you and act through you for your guidance."
    new "وقتی عریان می‌شوم، می‌دانم خداوند شما را هدایت خواهد کرد و از طریق شما برای هدایت شما عمل خواهد کرد."

    # say L419 gra
    old "He'll tell you what to do..."
    new "او به شما خواهد گفت چه کاری باید انجام بدید..."

    # say L420 gra
    old "Please! The pain and pleasure will go away but my submission and loyalty to you will remain eternally in my soul... I need it."
    new "لطفاً! درد و لذت خواهد گذشت اما تسلیمی و وفاداری من به تو برای همیشه در روح من باقی خواهد ماند... من به این نیاز دارم."

    # say L421 pla
    old "If that's what you need, I'll do it."
    new "اگر این هستن چیزی که نیاز داری، من انجام می‌دم."

    # say L435 gra
    old "I would like to thank you... You can't imagine how important this was to me."
    new "می‌خواهم از شما تشکر کنم... نمی‌توانید بفهمید اینقدر برایم مهم بوده."

    # say L436 pla
    old "I- I am glad, sister Grace."
    new "من- من خوشحالم، خواهر گریس."

    # say L437 pla
    old "I should go now, I have to be home soon..."
    new "باید برم، زودی باید خونه باشم..."

    # say L439 gra
    old "Alright! I have to go as well. I'll be thinking of your great and massive..."
    new "البته! من هم باید برسم. به روح و جان شما فکر خواهم کرد..."

    # say L440 gra
    old "... Spirit and soul."
    new "... روح و جان تو را خواهم داشت."

    # say L456 lin
    old "hi [pla], how are you?"
    new "سلام ز[pla]، چطوری؟"

    # say L457 pla
    old "Hey! I'm fine... What about you?"
    new "اوه! خوبم... تو چطوری؟"

    # say L458 lin
    old "I'm a bit worried [pla], you know we don't have much time to perform the ritual, you gotta hurry up!"
    new "من نگرانم ز[pla]، میدونی وقت خیلی کمی برای انجام مراسم باقی مونده، باید سریع‌تر کار کنی!"

    # say L459 pla
    old "I'm working on it, you don't need to worry about it, I'll do it and everything will be fine."
    new "من رویش کار می‌کنم، نباید نگران باشی، انجام میدم و همه چیز خوب میشه."

    # say L460 lin
    old "Alright! I just wanna make sure you have everything ready because we're running out of time..."
    new "البته! فقط می‌خوام مطمئن شم همه چیزت آماده باشه چون وقت ما کم می‌شه..."

    # say L462 pla
    old "Hmm, okay, I'll have to rush the plans ... "
    new "Hmm، خوب، باید برنامه‌ها رو تسریع کنم..."

    # say L463 lin
    old "Great, and who will be with you in the ritual? Which humans?"
    new "عالی، و کی با تو در مراسم خواهند بود؟ کدام انسان‌ها؟"

    # say L464 pla
    old "Mrs. Jones and the sister Grace, they both have a lot of accumulated energy."
    new "خانم جونز و خواهر گریس، هر دو انرژی زیادی جمع کرده‌اند."

    # say L465 lin
    old "Do they know what they have to do?"
    new "آیا اونا می‌دونن باید چیکار بکنن؟"

    # say L467 pla
    old "Well, not yet... But they'll do it, I have been working on getting closer to them and it's going better than I expected."
    new "خب، هنوز نه... اما انجام می‌دن، من کاری کردم تا بهشون نزدیک شم و بهتر از انتظارم پیش رفت."

    # say L468 lin
    old "Ok, I don't wanna put more pressure on you but we have to... We do need that energy to perform the ritual."
    new "باشه، من نمی‌خوام فشار بیشتری بر تو بذaram اما باید... ما به همین انرژی نیاز داریم تا مراسم رو انجام بدیم."

    # say L470 pla
    old "I know! In fact, I'm going to talk to them and get everything ready..."
    new "می‌دونم! در واقع می‌خوام باهاشون حرف بزنم و همه چی رو آماده کنم..."

    # say L472 lin
    old "Ok, since you have everything almost ready for the ritual... I wanna share some energy with you."
    new "باشه، چون همه چیز تقریباً برای مراسم آماده شده... می‌خوام با تو انرژی به اشتراک بگذaram."

    # say L474 pla
    old "S- Sure... Let's do it!"
    new "ب-Bale... بیایم!"

    # say L475 lin
    old "All right, get naked and lie on the bed... "
    new "باشه، خودتو عریان کن و روی تخت بخواب..."

    # say L489 lin
    old "It's done, go and prepare everything for the ritual! "
    new "بفرما همه چیز رو برای مراسم آماده کن!"

    # say L490 pla
    old "Got it, thanks, see you!"
    new "باشه، ممنون، ببینم!"

    # say L491 lin
    old "See ya..."
    new "ببینم..."

    # say L492 lin
    old "The best of luck!!! I'm so excited for you..."
    new "موفق باشی!!! خیلی خوشحالم برایت..."

    # say L507 pla
    old "Hi sister Grace, I'm ready to start cleaning..."
    new "سلام خواهر گریس، آماده‌ام برای شروع پاک کردن..."

    # say L508 gra
    old "It's so nice to see you, hi [pla]... Actually we don't have to clean today..."
    new "خوشحالم که تو رو می‌بینم، سلام [pla]... در واقع امروز نمی‌خوایم تمیز کنیم..."

    # say L510 gra
    old "We have some issues now..."
    new "الان مشکلاتی داریم..."

    # say L511 gra
    old "[pla]... Your help it's been exceptional, I'm so grateful with you."
    new "[pla]... کمکت فوق‌العاده بود، ازت خیلی ممنونم."

    # say L513 pla
    old "It's what God wants me to do... I could help even more if needed."
    new "این همینه که خدا از من می‌خواد... اگه لازم بود می‌تونم بیشتر کمک کنم."

    # say L515 gra
    old "Well... Now that you mentioned it, I need you to do something..."
    new "خب... حالا که اینجوری گفتی، باید چیزی ازت بخواهم..."

    # say L516 pla
    old "(Not punishment, please!)"
    new "(لطفاً جریمه نباشه!)"

    # say L517 pla
    old "Hmm, tell me sister Grace, what can I do for you?"
    new "همم، بگو خواهر گریس، من برای تو چه کاری می‌تونم بکنم؟"

    # say L518 gra
    old "Mrs. Jones is feeling a bit sick but I can't go to see her...  I can't leave the church right now. Would you please stop by her house to see how she's doing?"
    new "خانم جونز خیلی خوب نیست اما من نمی‌توانم برای دیدنش بروم... نمی‌توانم الان از کلیسا بیرون بیام. آیا لطفاً به خانه‌اش بروی تا ببینی حالتش چطوره؟"

    # say L519 pla
    old "I'm so sorry she's sick... I'll go right now."
    new "متأسفم که بیماره... الان می‌روم."

    # say L520 gra
    old "Thanks dear [pla]... Call me if you need anything, alright!"
    new "ممنون عزیزم [pla]... اگر نیازی داشتی به من تماس بگیر، خوبه!"

    # say L524 pla
    old "(I hope she's not that sick... I'll need her for the ritual)"
    new "امیدوارم خیلی بیمار نباشه... برای مراسم بهش نیاز دارم."

    # say L525 pla
    old "(Hmm... Actually, before I go... I should definitely talk to the nun about the ritual...)"
    new "( Hmm... در واقع، قبل از برود... باید حتماً با زن راهب درباره مراسم صحبت کنم... )"

    # say L529 pla
    old "Sister Grace? Sorry! Hmm... I wanna tell you something before I go..."
    new "خواهر گریس؟ معذرت! هم... من قبلاً از رفتنم باید چیزی به تو بگم..."

    # say L530 gra
    old "Yeah? Tell me [pla]... What's that?"
    new "بله؟ بگو [pla]... چه کاری هست؟"

    # say L531 pla
    old "You said you were my faithful devotee and you would always be loyal to me, right?"
    new "تو گفتی که به من وفاداری و همیشه به من وفا خواهی داشت، درسته؟"

    # say L532 gra
    old "Yes, of course. After all you've done to me and for me, I would do anything for you."
    new "بله، البته. با توجه به همه چیزهایی که برای من انجام دادی و به من کردی، برای تو هر کاری می‌کنم."

    # say L533 pla
    old "Well... I have to do a spiritual ritual, it's very important and it has to be done here at the church... And I would like you to help me to perform it."
    new "خب... من باید یک مراسم روحانی انجام بدم، این خیلی مهمه و باید اینجا توی کلیسا انجام بشه... و من می‌خوام تو به من کمک کنی تا این مراسم رو انجام بدهم."

    # say L534 gra
    old "Yes, I'm not even gonna question you about it, as a submissive being to your will, I will always be at your service."
    new "بله، حتی سؤالی ازت نمی‌پرسم، به عنوان یک موجود تابع ارادتت، همیشه در خدمتتو هستم."

    # say L535 pla
    old "Well! That's great, thanks! I knew I could count on you."
    new "خوب! عالیه، ممنون! می‌دونستم می‌تونم رو تو به حساب بیارم."

    # say L536 pla
    old "I need you to make sure the church is empty at night, we can't allow sinful people to be here..."
    new "من نیاز دارم تا مطمئن شی که کلیسا شب‌ها خالی باشه، نمی‌تونیم اجازه بدیم افراد گناهکار اینجا باشند..."

    # say L538 gra
    old "I'm always obedient to God and to you."
    new "همیشه برای خدا و شما اطاعت می‌کنم."

    # say L539 pla
    old "Hmm by the way... We won't be alone, one more person will join us, you already know her and I'm sure you'll do great during the ritual."
    new "همم بای‌التوانای... ما تنها نخواهیم بود، یک نفر دیگر هم به ما می‌پیوندد، تو قبلاً اون رو شناخته‌ای و مطمئن باش که تو در مراسم خوب عمل خواهی کرد."

    # say L540 gra
    old "One more person? Who?"
    new "یک نفر دیگر؟ کی؟"

    # say L541 pla
    old "Trust me... You know I'm the hand of God."
    new "باور داشته باش... می‌دونی من دست خدا هستم."

    # say L542 gra
    old "I'm so sorry!"
    new "من خیلی متاسفم!"

    # say L543 pla
    old "Just make sure the place is ready..."
    new "فقط اطمینان حاصل کن که جای خوبی آماده باشه..."

    # say L545 gra
    old "I'll do everything to please you."
    new "من همه‌چیز رو برای خوشحال کردن شما انجام می‌دم."

    # say L547 pla
    old "You're great! I'll go now since we need to know how Mrs. Jones is..."
    new "تو عالی هستی! من حالا می‌روم چون باید بفهمم خانم جونز چطوره..."

    # say L548 gra
    old "Go with God..."
    new "با خدا..."

    # say L553 pla
    old "Hello? Mrs. Jones? "
    new "سلام؟ خانم جونز؟"

    # say L555 pla
    old "Are you here?"
    new "pla: خانم جونز؟ شما اینجا هستید؟"

    # say L556 jon
    old "Dear? [pla]?"
    new "عزیزم؟ [pla]؟"

    # say L557 jon
    old "Come here, handsome..."
    new "بیا اینجا، لبخندان..."

    # say L565 jon
    old "Hi dear, I was waiting for you..."
    new "سلام عزیزم، منتظرت بودم..."

    # say L567 pla
    old "Wow! Mrs. Jones what are you wearing?"
    new "واو! خانم جونز، لباس چی قشنگی پوشیدی؟"

    # say L576 jon
    old "I'm so happy you're here... How are you, handsome?"
    new "خوشحالم که اینجا هستی... حالت چطوره، عزیزم؟"

    # say L577 pla
    old "H- hi Mrs. Jones, I'm fine... But tell me how are you feeling?"
    new "ه- هی خانم جونز، من خوبم... ولی بگو چطور حس می‌کنی؟"

    # say L578 pla
    old "The sister Grace told me you have been quite sick..."
    new "خواهر گریس به من گفت که اخیراً بسیار بیمار بودی..."

    # say L579 pla
    old "But you look d- different..."
    new "اما تو به نظر می‌رسی متفاوتی..."

    # say L581 jon
    old "I'm fine as you can see... Maybe a bit hot ..."
    new "من خوب هستم، معلومه... شاید یه کم گرم باشم..."

    # say L583 jon
    old "You should enjoy what you're seeing right now... As much as I'm enjoying having you here."
    new "شما باید از آنچه الان می‌بینید لذت ببرید... همان‌طور که من از حضور شما لذت می‌برم."

    # say L585 pla
    old "M- mrs. Jones, why are you wearing that?"
    new "م- خانم جونز، چرا این لباس رو پوشیدی؟"

    # say L586 jon
    old "Well, You were the one bringing me this dress time ago... You made me remember my younger years with my husband..."
    new "خب، شما همان نفری بودید که این لباس رو به من آوردید... شما مرا به سال‌های جوانی‌ام با شوهرم یادآور کردید..."

    # say L587 jon
    old "I used to wear a similar dress to this one and my husband used to devore me with his hands..."
    new "من قبلاً لباس مشابه این رو می‌پوشیدم و شوهرم معمولاً با دست‌هایش من رو می‌خورد..."

    # say L588 jon
    old "We liked rough sex... You know..."
    new "ما دوست داشتیم جنس خشن داشته باشیم... می‌دونی..."

    # say L589 pla
    old "(W- What?)"
    new "(و- وای!)"

    # say L590 jon
    old "I forgot you're a bit shy sometimes... But perhaps you forgot I'm not and I want to have you now!"
    new "من فراموش کردم که گاهی خجالتی هستی... اما شاید فراموش کرده‌ای که من خجالتی نیستم و می‌خواهم حالا تو رو داشته باشم!"

    # say L593 jon
    old "I'll take the initiative... I know you like when your cock is between my lips."
    new "من اولین قدم رو بردارم... میدونم وقتی نوکت بین لبام باشه، خوشت میاد."

    # say L594 jon
    old "And I know you're getting hard as fuck right now... Just let me take off your pants, handsome."
    new "و می‌دونم الان سخت شده‌ای مثل هر بار... فقط بپوش رویت، عزیزم."

    # say L608 jon
    old "I'm feeling much better now... I should say thank you..."
    new "حالا خیلی بهتر هستم... باید ممنون بگم..."

    # say L609 pla
    old "(Hmm sure...) I hope you're much better now."
    new "امیدوارم حالت الان خوبتر باشه."

    # say L610 jon
    old "Totally hun... Thanks for passing by..."
    new "البته عزیزم... ممنونم که اومدی..."

    # say L611 pla
    old "Hmm... Mrs. Jones, I actually wanted to ask you a favor..."
    new "هم... خانم جونز، در واقع می‌خواستم ازت یه لطفی بخواهم..."

    # say L613 jon
    old "A favor? Sure, anything for you, love..."
    new "یک لطف؟ البته، هر چیزی برایت، عزیزم..."

    # say L614 pla
    old "I'll have to perform a ritual at the church to clean the energies..."
    new "باید یک مراسم در کلیسا برگزار کنم تا انرژی‌ها رو تمیز کنم..."

    # say L615 pla
    old "And since we're closer now and you know that I've such a spiritual development, I would like you to be part of that ritual."
    new "و چون الان نزدیک‌تر شده‌ایم و می‌دونی روحانیت من چقدر پیشرفت کرده، می‌خوام تو هم بخشی از این مراسم باشی."

    # say L616 pla
    old "Sister Grace would be there, you and me... Would you help me? "
    new "خواهر گریس هم اونجا خواهد بود، تو و من... آیا می‌تونی به من کمک کنی؟"

    # say L618 jon
    old "You've done so much for me, hun... I already told you, I would do whatever you ask me to do. You can count on me for it."
    new "شما به من کمک زیادی کردی، عزیزم... قبلاً بهت گفتم، هر چی می‌خوای از من بکنم، می‌کنم. می‌تونی روی من حساب کنی."

    # say L619 pla
    old "Thanks Mrs. Jones, I didn't expect less from you..."
    new "ممنون، خانم جونز، ازت کمتر نمی‌تونستم ب expected..."

    # say L620 pla
    old "I'll see at the church, now I should go..."
    new "من به کلیسا می‌روم، حالا باید برسم..."

    # say L621 jon
    old "See you there, handsome."
    new "تا آنجا ببینیم، لبخند."

    # say L637 pla
    old "Ok... Today is the ritual day!"
    new "خب... امروز روز مراسم است!"

    # say L638 lin
    old "And you'll be great, we count on you..."
    new "و تو هم عالی خواهی بود، ما بر تو اعتماد داریم..."

    # say L639 pla
    old "I know Linett, I've everything ready and well... It'll be fine."
    new "میدونم لینت، همه چی رو آماده کردم و خب... خوب میشه."

    # say L640 lin
    old "[pla] make sure you have sex with both, the nun and the older woman, it's extremely important to get energy from both. I'll be there with you..."
    new "[pla] مطمئن شو با هر دو، راهبه و زن بزرگسال، جنس کنی، از هر دو انرژی گرفتن خیلی مهمه. من هم با تو خواهم بود..."

    # say L641 pla
    old "Great! I didn't know you were coming with me..."
    new "عالی! نمی‌دونستم تو هم با من می‌آیی..."

    # say L643 pla
    old "Ohh! Ok..."
    new "اوه! خوب..."

    # say L644 lin
    old "So are you ready... We gotta start the ritual now."
    new "پس آماده‌ای... باید الان مراسم رو شروع کنیم."

    # say L645 pla
    old "Yeah... Let's do it!"
    new "بله... بیایم بزنیم!"

    # say L651 pla
    old "Oh, they are back there..."
    new "او، اونا اینجا هستن..."

    # say L652 pla
    old "Great! It's time to start the ritual."
    new "عالی! الان وقت شروع مراسم است."

    # say L662 pla
    old "Mrs. Jones, sister Grace... Hi, I'm glad you both are here..."
    new "خانم جونز، خواهر گریس... سلام، خوشحالم که هر دو اینجا هستید..."

    # say L663 jon
    old "Good night hun."
    new "شب خوبی عزیزم."

    # say L664 gra
    old "Hi [pla], it's a pleasure to be here with you."
    new "سلام [pla]، خوشحالم که اینجا با شما هستم."

    # say L671 pla
    old "Billie? W- What are you doing here?"
    new "بیلی؟ و- وای، تو اینجا چه کاری داری؟"

    # say L672 jon
    old "Oh, I invited her... As you said you are going to clean the bad energies I thought it would be a great idea to invite Billie..."
    new "اوه، من اش را دعوت کردم... چون گفتی می‌خواهی انرژی‌های منفی را پاک کنی فکر کردم ایده خوبی باشه که بیلی رو هم دعوت کنم..."

    # say L673 pla
    old "W- what? B- but she doesn't know what we are going to have se- ... An important ritual..."
    new "و- چه؟ اما او نمی‌دونه ما قراره چه کار کنیم... یعنی مراسم مهمی..."

    # say L674 jon
    old "Oh, don't worry hun, I already explained it to her, she was really worried about her sexorcis-... I mean exorcism."
    new "اوه، نگران نباش عزیزم، من قبلاً به او توضیح دادم، واقعاً نگران بود از سکسورسیسم‌اش... منظورم اکسورسیسم."

    # say L675 bil
    old "I wanted to come... I never thought that I could be religious having sex."
    new "می‌خواستم بیام... هرگز فکر نکردم می‌تونم با دینی جنسیت کنم."

    # say L676 bil
    old "And I wanna thank you for what you did for me as well..."
    new "و می‌خوام ازت بخونم برای آنچه برای من انجام دادی..."

    # say L677 pla
    old "Hmm alright... I- I see..."
    new "Hmm خب... من- من می‌بینم..."

    # say L679 pla
    old "(Oh shit, she is right.)"
    new "اوه شیطون، درست می‌گه."

    # say L680 pla
    old "Well ladies, this is a spiritual ritual in which we all will do a transfer of spirituality among us..."
    new "خب جون‌ها، این یک مراسم روحانیه که ما همه باید روحیت رو بین هم منتقل کنیم..."

    # say L681 pla
    old "I've noticed how spiritual you all are and that's why I've chosen you for this."
    new "من توجه کردم چقدر معنوی هستید و برای این دلیل شما را برگزیدم."

    # say L682 pla
    old "We'll have to open our hearts to God and give to each other what's required..."
    new "باید قلب‌هامون رو به خدا باز کنیم و به هم آنچه لازم است بدهیم..."

    # say L683 jon
    old "I can't wait to do it... You have all of me for this..."
    new "نمی‌تونم منتظر این باشم... برای این کار همه‌ی من به شما می‌دهم..."

    # say L684 gra
    old "I agree with Mrs. Jones..."
    new "من با خانم جونز موافقم..."

    # say L685 pla
    old "The better we do it, the better our lives will be in the eyes of God..."
    new "هر چه بهتر انجام بدیم، زندگیمون در چشم‌های خدا بهتر خواهد بود..."

    # say L686 pla
    old "Put all your faith on me and I'll guide through the ritual, it's all about spirituality and love."
    new "همه ایمانتو رو به من بگذار، من راهنمایت می‌شوم در مراسم، این همه درباره روحیت و عشق است."

    # say L687 bil
    old "Can't we just start?"
    new "نمی‌تونیم شروع کنیم؟"

    # say L688 pla
    old "Right, can you turn on the lights before we start?"
    new "بله، می‌تونی قبل از شروع نور رو روشن کنی؟"

    # say L696 bil
    old "Let's start with the sex!"
    new "بیایید با سکس شروع کنیم!"

    # say L697 gra
    old "Ahhh."
    new "آه."

    # say L698 jon
    old "Oh dear please calm down..."
    new "اوه عزیزم لطفاً آرام شو..."

    # say L711 lin
    old "Good job! Now it's my turn!"
    new "عالی! حالا من!"

    # say L734 pla
    old "W- Well... Thank you... It was an excellent ritual, you all did good and I'm very thankful..."
    new "خوب... ممنون... مراسم عالی بود، همه شما خوب کار کردید و من خیلی ممنونم..."

    # say L735 jon
    old "I'm happy we got to help you and you helped us during this ritual..."
    new "خوشحالم که بتونیم بهت کمک کردیم و تو هم به ما کمک کردی در این مراسم..."

    # say L736 bil
    old "It was cool..."
    new "خوب بود..."

    # say L737 gra
    old "I feel totally new... Totally different, thanks so much [pla]..."
    new "احساس کاملاً جدید دارم... کاملاً متفاوت، ممنونم خیلی [pla]..."

    # say L739 pla
    old "I have to go now... "
    new "من الان باید برسم..."

    # say L741 gra
    old "See you [pla], I need some rest after this..."
    new "ببینم [pla]، بعد از این نیاز به استراحت دارم..."

    # say L742 jon
    old "Goodbye, dear... See you!"
    new "خداحافظ، عزیزم... دوباره ببینم!"

    # say L748 pla
    old "Linett!?..."
    new "لینت؟..."

    # say L749 lin
    old "Hi... How are you feeling?"
    new "سلام... حالت چطوره؟"

    # say L750 pla
    old "I'm happy, we did it!"
    new "خوشحالم، انجامش دادیم!"

    # say L751 lin
    old "Well... It didn't work..."
    new "خب... کار نکرد..."

    # say L752 pla
    old "What? Why? What happened?"
    new "چه کاری؟ چرا؟ چه اتفاقی افتاد؟"

    # say L753 lin
    old "It simply didn't work... It happens sometimes, it's a complex ritual and well... This time it didn't work..."
    new "این بار هم کار نکرد... گاهی اوقات اینجور می‌شه، مراسم پیچیده‌است و خب... این بار کار نکرد..."

    # say L754 pla
    old "Really? Now what?"
    new "وای، خوب حالا چه کاری باید کنیم؟"

    # say L755 lin
    old "There is nothing we can do now... We have to wait until christmas, there is no other way..."
    new "الان هیچ کاری نمی‌تونیم بکنیم... باید صبر کنیم تا کریسمس، راه دیگه‌ای نداریم..."

    # say L756 lin
    old "During christmas there is a load of human energy all around and that's the only chance we will have..."
    new "در کریسمس انرژی انسانی زیادی در همه جا وجود داره و این تنها فرصت ماست..."

    # say L757 lin
    old "For now there is nothing we can do..."
    new "برای حالا هیچ کاری نمی‌تونیم بکنیم..."

    # say L759 pla
    old "I see... We'll try for Christmas..."
    new "می‌بینم... برای کریسمس تلاش می‌کنیم..."


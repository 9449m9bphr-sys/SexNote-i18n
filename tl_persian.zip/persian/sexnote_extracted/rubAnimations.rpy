# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/rubAnimations.rpy
translate persian strings:

    # say L6 gomRub
    old "Mmm, I love how it tastes."
    new "ممنون، عاشق هستم که چطور طعم می‌دهد."

    # say L7 gomRub
    old "Your dick is so big."
    new "پیپی تو خیلی بزرگه."

    # say L8 gomRub
    old "And you’re so hard."
    new "و تو هم خیلی سختی."

    # say L12 gomRub
    old "Sluurp! Are you enjoying it?"
    new "سلورپ! لذت می‌بری؟"

    # say L13 pla
    old "Mmm...  I guess. it’s a bit weird with Ruby’s body though."
    new "ممنون... گuess. ولی با بدنش رویی یه کم عجیبه."

    # say L14 gomRub
    old "Your dick, it’s twitching."
    new "پیپی تو، در حال لرزیدن است."

    # say L15 gomRub
    old "Mmm! And it’s so tasty, I love it!"
    new "مم! و اینقدر لذت‌بخشه، عاشقش شدم!"

    # say L19 gomRub
    old "Yes, Yes! I love this feeling in my mouth!"
    new "بله، بله! این احساس در دهانم رو خیلی دوست دارم!"

    # say L20 gomRub
    old "I can feel your body tensing up!"
    new "می‌تونم احساس کنم بدنت خیس می‌شه!"

    # say L21 pla
    old "T- This is, aaah!"
    new "B- این، آااه!"

    # say L45 gomRub
    old "Yes! Yes! Do it!"
    new "بله! بله! انجام بده!"

    # say L46 gomRub
    old "Give me that magic power!"
    new "به من اون قدرت جادویی رو بده!"

    # say L52 gom
    old "Oh wow! You’d given me magic before, but this is way different!"
    new "اوه وای! قبلاً به من جادو دادی، اما این خیلی متفاوته!"

    # say L53 gom
    old "Human bodies are amazing. It feels so different."
    new "بدن‌های انسانی شگفت‌انگیز هستند. احساساتش خیلی متفاوت است."

    # say L54 gom
    old "It didn’t feel bad before, it’s just so... weird!"
    new "قبل هم بد نبود، فقط خیلی... عجیب است!"

    # say L55 pla
    old "Hmm... Yeah, sure."
    new "Hmm... بله، مطمئنی."


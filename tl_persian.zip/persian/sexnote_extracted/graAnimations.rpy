# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/graAnimations.rpy
translate persian strings:

    # say L6 gra
    old "I feel I'm in heaven just by touching it! Oh my Father, I'm so grateful."
    new "با لمسش می‌تونم بگم که من بهشت هستم! ای پدرم، خیلی ممنونم."

    # say L7 pla
    old "(My God!...)"
    new "الهی!..."

    # say L12 gra
    old "The feeling of your big grace on my hands, it's so pure."
    new "احساسی که از لمس این بزرگی در دست‌هام می‌آید، خالص است."

    # say L17 gra
    old "My heavenly God!... It's so... S- So great and big, divine!"
    new "اللهم!... این خیلی... س- سویی و بزرگ است، الهی!"

    # say L41 gra
    old "I feel that grace is going to come in my fac- Ahhhhhh!!!"
    new "احسas می‌کنم این لطف در حال ورود به صورتم است- آههههه!!!"

    # say L58 gra
    old "Your divine phallus is precious, just by seeing it I can feel the glory in him."
    new "فал ایلاهی شما ارزشمند است، فقط با دیدن آن می‌توانم عظمت او را حس کنم."

    # say L59 pla
    old "(Wow is s- she... S- sucking it...)"
    new "واو، آن قدر... س- سوس می‌کنه..."

    # say L63 gra
    old "Your divine phallus tastes like heaven... Oh my Father, I'm so grateful."
    new "فалوس الهی شما مثل بهشت طعم دارد... اوه پدرم، من خیلی ممنون هستم."

    # say L67 gra
    old "My soul is silent and my door is open for you, I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "روح من ساکت است و در من برای تو باز است، نیاز دارم آب مقدس تو را در دهانم بیاورم، اخیراً خیلی چیزهای غلط گفتم و باید آنها را پاک کنم."

    # say L68 gra
    old "I wanna feel it in my tongue... My tongue is thirsty of you..."
    new "می‌خوام احساسش رو تو زبانم بکنم... زبانم از تو عطش‌کرده..."

    # say L91 gra
    old "I feel that grace is going to come... To come in my lips!!!"
    new "احسas می‌کنم نعمتی در آمده... در لب‌هایم!!!"

    # say L95 gra
    old "Ahhhhhhhh!!"
    new "اااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااااا"

    # say L96 gra
    old "(My Godness!... This is heaven, divine!)"
    new "الهی!... این بهشت است، الهی!"

    # say L108 pla
    old "(Wow is s- she... S- sucking it again...)"
    new "واو، او... او دوباره در حال شیرجه دادن است..."

    # say L116 gra
    old "I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "من به آب مقدس تو در دهانم نیاز دارم، اخیراً خیلی چیزهای غلط گفته‌ام و باید آنها را تمیز کنم."

    # say L147 gra
    old "Oh father, my soul is silent and my door is open for you, I need you inside of me cleaning my impure soul."
    new "اوه پدر، روح من سکوت دارد و در من برای شما باز است، نیاز دارم شما داخل من برای تمیز کردن روح نجس من باشید."

    # say L148 pla
    old "Does she wants me to f- fuck... her?"
    new "آیا او می‌خواهد من... با او بگردم؟"

    # say L167 gra
    old "Ohhh father, I can feel your grace inside me!"
    new "اوه پدر، می‌تونم احساس نعمت شما درون من کنم!"

    # say L168 gra
    old "And it feels sooo goood!"
    new "و این هم خیلی خوب است!"

    # say L169 pla
    old "(Ohh yeah...)"
    new "اوه بله..."

    # say L173 gra
    old "Yes, father! Please clean all my sins harder!"
    new "بله، پدر! لطفاً گناه‌هایم را سخت‌تر پاک کن!"

    # say L174 gra
    old "Ohhh God! Oh God!"
    new "اوه خداوند! اوه خدا!"

    # say L178 gra
    old "Ahhh Ahhh father. Yes, give me more! MORE!"
    new "اوه اوه پدر. بله، بیشتر بده به من! بیشتر!"

    # say L201 gra
    old "(My heavenly God!... I'm seeing the heaven!)"
    new "الهای من!... من به سما دارم می‌رسم!"

    # say L202 gra
    old "I feel that grace is going to come... To come insid- Ahhhhhh!!!"
    new "احسas می‌کنم نعمة در حال رسیدن است... در داخل- آههههه!!!"

    # say L219 gra
    old "My heavenly God, it's so big."
    new "الهای من، اینقدر بزرگ است."

    # say L224 gra
    old "Oh God! It tastes like heaven..."
    new "اوه خداوند! این مثل بهشت می‌آید..."

    # say L228 gra
    old "I need to purify my soul with your holy milk."
    new "من باید روحم را با شیر مقدس شما تمیز کنم."

    # say L251 pla
    old "Sister Grace... I- I-"
    new "خواهر گریس... من- من-"

    # say L252 gra
    old "Oh yeah! I want to feel that grace in my mouth-"
    new "اوه بله! می‌خواهم این لطف را در دهانم حس کنم-"

    # say L268 gra
    old "Ahhhhhh!!! I can feel the greatness of your body inside me..."
    new "اوه!!!!! من می‌تونم عظمت بدنتون رو داخلم حس کنم..."

    # say L273 gra
    old "I wanted this so badly... There is no pain I can't bear for God."
    new "این را خیلی می‌خواستم... هیچ دردی برای خدا نمی‌توانم تحمل کنم."

    # say L274 gra
    old "Harder! Harder! I want you to make me feel more pain!"
    new "سخت‌تر! سخت‌تر! می‌خوام درد بیشتری بکنم!"

    # say L279 gra
    old "Ahhhhhh! Ahhhhh! Ahhh!"
    new "آههههه! آهههه! آهه!"

    # say L280 gra
    old "My soul needs as much forgiveness as my body needs punishment."
    new "روح من به همان اندازه که بدنم به مجازات نیاز دارد، به عفو نیاز دارد."


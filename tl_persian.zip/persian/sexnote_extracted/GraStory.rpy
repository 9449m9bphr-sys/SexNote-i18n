# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/GraStory.rpy
translate persian strings:

    # say L5 pla
    old "(God! I hope everybody is sleeping already... I gotta whisper to her...)"
    new "الله! امیدوارم همه خوابیدن... باید بهش سری به گوش بزنم..."

    # say L6 pla
    old "{i}Psst psst psst, Hey... I'm [pla], I know you are in trouble... I can help you! Where are you?{/i}"
    new "{i}پس پس پس، هی... من [pla] هستم، می‌دونم تو مشکل داری... می‌تونم بهت کمک کنم! تو کجایی؟{/i}"

    # say L7 pla
    old "{i}You can trust me... Just let me see you, I came here to help you.{/i}"
    new "{i}می‌تونی به من اعتماد کنی... فقط برام نشونت بده، من برای کمکت اومدم.{/i}"

    # say L9 gra
    old "Hello! Who's there?"
    new "سلام! چه کسی اینجا هست؟"

    # say L11 gra
    old "If you come to steal, you are in the wrong place... Don't you see this is God's house?!"
    new "اگر برای دزدی آمده‌ای، جای اشتباهی انتخاب کردی... نمی‌بینی این خانه خداوند است؟!"

    # say L13 pla
    old "(Holy shit! The nun heard me... I need to hide.)"
    new "شیطان! نونوس خورده‌ام... باید پنهان شوم."

    # say L22 gra
    old "(But... I don't see anybody... God! Maybe it is Father Morgan...)"
    new "(ولی... هیچ کس نمی‌بینم... خداوند! شاید پدر مورگان باشه...)"

    # say L28 gra
    old "Father Morgan? It is you? I'm sorry, I thought it was somebody else, a thief... I didn't know you would have been here so late."
    new "آقای مورگان؟ شما هستید؟ معذرت، فکر کردم کسی دیگری است، یک دزد... نمی‌دانستم شما اینقدر تار در اینجا خواهید بود."

    # say L37 pla
    old "(Holy fuck!! She also entered the confessional.)"
    new "اوه خداوند!! او هم به داخل اعترافخانه وارد شده."

    # say L40 gra
    old "Father? Are you upset? I'm sorry if I disturbed you with my shouting."
    new "پدر؟ آیا ناراحت هستید؟ اگر با صدایم آزار دادم، معذرت می‌خواهم."

    # say L41 gra
    old "I see what you're thinking... I have done wrong again and I must clean up that offense I have committed, that's why you're so quiet."
    new "می‌بینم چه فکری می‌کنی... دوباره گناه کرده‌ام و باید این گناه را پاک کنم، همین جاست که آرام هستی."

    # say L43 gra
    old "No father Morgan... You don't have to say a word."
    new "نه پدر مورگان... شما نیازی به گفتن هیچ کلمه‌ای ندارید."

    # say L44 gra
    old "You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "میدونی کاملاً وفادار به ارادة خدا هستم، برات اجازه میدم دوباره من رو هدایت کنی تا بد فکرهایم رو از بدنم پاک کنم."

    # say L45 gra
    old "Thoughts that I had a few minutes ago."
    new "افکاری که چند دقیقه پیش داشتم."

    # say L46 pla
    old "(What? What's she talking about?!)"
    new "(چه؟ درباره چه چیزی حرف می‌زنه؟!)"

    # say L47 pla
    old "(What's happening with her-)"
    new "(اونجا چه اتفاقی می‌افته-)"

    # say L48 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I'm giving you my spirit through my body, Father."
    new "ایمان به خدا معنی آن است که از هیچ چیز نترسی و شما راهنمای من هستید، به من کمک کنید تا این روح گناهکار را تمیز کنم. از طریق بدنم روحم را به شما می‌دهم، پدر."

    # say L49 pla
    old "(I- is she talking about... s- sex?)"
    new "من- او از... س- سکس حرف می‌زنه؟"

    # say L50 gra
    old "I'm ready to receive your sacred water, your purifying milk... It's my mission to reach divinity through you, let me try it one more time."
    new "آماده‌ام برای دریافت آب مقدس شما، شیر تطهیر‌کننده‌ی شما... وظیفه‌ی من این است که از طریق شما به الهیت برسانم، بیایید دوباره امتحان کنیم."

    # say L51 pla
    old "(Oh shit!... This is so wrong...)"
    new "اوه شیطون!... این همه اشتباهه..."

    # say L52 gra
    old "I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Tell me something or show me your help, please!"
    new "من از شما درخواست می‌کنم که به من کمک کنید، من روی لبه تاریکی بودم و شما نور را به من نشان دادید... پدر مورگان؟ لطفاً چیزی بگویید یا کمک خود را به من نشان دهید!"

    # say L54 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, Father."
    new "من می‌خواهم خداوند ما خوشحال باشد، هیچ چیز بهتر یا زیباتر از این نیست و من از طریق شما او را خوشحال خواهم کرد، پدر."

    # say L55 pla
    old "(My God! Alright, I gotta do this. If I don't, she'll suspect and see that I'm not the Father Morgan.)"
    new "خداوندم! خب، باید اینو بکنم. اگه نکنم، شک می‌کنه و می‌بینه که من واقعاً Father Morgan نیستم."

    # say L76 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. One more time, you've shown me how big and great you're, I feel your grace."
    new "پدر مورگان عزیزم، کلماتی برای ابراز شکرتو ندارم. دوباره هم به من نشان دادی چقدر بزرگ و عظیمی هستی، احساس نعمتت را می‌کنم."

    # say L77 gra
    old "I will go to pray for you and for your great and powerful divine tool."
    new "من برای شما و برای ابزار الهی و قدرتمند شما به نماز خواهم رفت."

    # say L79 gra
    old "Good night Father Morgan, I'll be eager to see you again."
    new "خوب شام، پدر مورگان، منتظر می‌شوم تا دوباره شما را ببینم."

    # say L93 pla
    old "(What a night!...)"
    new "چه شبی!..."

    # say L94 pla
    old "(Argh! The shinigami... Shit! I couldn't find her! But I can't risk myself, perhaps the nun or the priest could come back...)"
    new "(آرگه! شینیگامی... شیطون! نتونستم اش رو پیدا کنم! اما نمی‌تونم خودمو در معرض خطر قرار بدم، شاید راهبه یا کشیش برگشته...)"

    # say L95 pla
    old "(I better come back another day...)"
    new "بهتره روز دیگه برگردم..."

    # say L108 pla
    old "(I hope the Sister Grace doesn't not appear tonight...)"
    new "امیدوارم خواهر گریس امشب ظاهر نشود..."

    # say L110 pla
    old "{i}You can trust me... I came here to help you, let me see where you are.{/i}"
    new "{i}می‌تونی به من اعتماد کنی... من برای کمکت اومدم، بیا ببینم جایت کجاست.{/i}"

    # say L112 gra
    old "Hello! F- Father Morgan?"
    new "سلام! آقای مورگان؟"

    # say L114 gra
    old "Is it you again?..."
    new "once more؟..."

    # say L116 pla
    old "(Oh no! She's back... Damn it!)"
    new "اوه نه! دوباره اومده... لعنتی!"

    # say L126 gra
    old "Father Morgan? I was eager to see you again..."
    new "پدر مورگان؟ خوشحالم که دوباره از شما دیده‌ام..."

    # say L135 gra
    old "Father? I'm sorry for bothering you again but I still need some help, my sins keep disturbing my soul."
    new "پدر؟ خواهش می‌کنم برای دوباره آمدم عذرخواهی کنم، اما هنوز به کمک شما نیاز دارم، گناهانم همچنان روحمو آزار می‌دهند."

    # say L136 gra
    old "I need to continue with the penance."
    new "من باید توبه‌ام را ادامه بدم."

    # say L140 gra
    old "No father Morgan... You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "پدر مورگان... می‌دونید من کاملاً وفادار به ارادة خداوند هستم، من دوباره اجازه می‌دهم تا شما بدنم رو از این فکرهای بد پاک کنید."

    # say L141 gra
    old "Thoughts that I had today, again..."
    new "افکاری که امروز داشتم، دوباره..."

    # say L142 pla
    old "(I guess I already know what she wants...)"
    new "به نظر می‌رسه قبلاً می‌دونم تو چی می‌خوای..."

    # say L143 pla
    old "(But what's happening with her, why to do this?)"
    new "(ولی اینجوری چه اتفاقی بهش افتاده، چرا این کار رو می‌کنه؟)"

    # say L144 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "ایمان به خدا معنی آن است که نباید ترسید و شما راهنمای من هستید، لطفاً به من کمک کنید تا این روح گناهکار را تمیز کنم. از طریق بدنم روحم را به شما می‌دهم، پدر."

    # say L145 pla
    old "(Well, I gotta do it... Otherwise she'll realized I'm not the Father Morgan)"
    new "خب، باید این کار رو بکنم... در غیر این صورت متوجه می‌شه من پدر مورگان نیستم"

    # say L146 gra
    old "Yes, I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Show me your help, please!"
    new "بله، از شما درخواست کمک می‌کنم، بر سر تاریکی بودم و شما نور را به من نشان دادید... پدر مورگان؟ لطفاً کمک خود را به من نشان دهید!"

    # say L148 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, my greatest Father."
    new "می‌خواهم خداوند ما خوشحال شود، هیچ چیز بهتر و زیباتر از این نیست و من از طریق شما، پدر بزرگترین خودم، او را خوشحال خواهم کرد."

    # say L149 gra
    old "My soul is open to be purified, as opened as my mouth right now..."
    new "روح من آماده است برای تصفیه شدن، مثل اینکه دهانم الان باز است..."

    # say L150 pla
    old "(Oh God!)"
    new "اوه خداوند!"

    # say L166 gra
    old "My great Father Morgan, you have no idea how grateful I'm. One more time, you've shown me how big and great you're, I can taste your grace."
    new "پدر بزرگ مورگان، شما هیچ ایده‌ای ندارید که چقدر ممنونم. دوباره، به من نشان دادید چقدر بزرگ و عظیم هستید، می‌توانم لطف شما را می‌چشتم."

    # say L169 gra
    old "Good night Father Morgan, I'll be needing more of your sacred assistance to purify my existence in this world."
    new "شب خوب باشید پدر مورگان، به زودی برای تصفیه وجودم در این دنیا به کمک مقدس شما نیاز خواهم داشت."

    # say L183 pla
    old "(Damn it! I couldn't find the shinigami tonight either... I better come back another day... This is to risky, the nun could come back...)"
    new "(لعنتی! امشب هم نتونستم شینیگامی رو پیدا کنم... بهتره دیگه روزی دیگه بیام... این خیلی خطرناکه، ممکنه راهبه برگرده...)"

    # say L196 pla
    old "(God! This is my last chance to find the shinigami, I gotta find her tonight.)"
    new "(بلاهای خدا! این آخرین فرصتم برای پیدا کردن شینیگامیه، باید امشب او رو پیدا کنم.)"

    # say L197 pla
    old "{i}Psst psst psst, Hi... I'm [pla], a friend of shinigamis... I know you are in trouble, please show up!{/i}"
    new "{i}پس پس پس، سلام... من [pla] هستم، دوستی از شینیگامی‌ها... می‌دونم تو مشکل داری، لطفاً پدیدت شو!{/i}"

    # say L200 gra
    old "Father Morgan... I'm so glad you're here."
    new "آقای مورگان... خوشحالم که اینجا هستید."

    # say L203 pla
    old "(Argh! No... No again!!!)"
    new "آخه! نه... دوباره نه!!!"

    # say L213 gra
    old "I was waiting for you, my holy savior."
    new "من منتظر شما بودم، نجات‌دهنده مقدس."

    # say L221 gra
    old "Father Morgan? How should we start tonight? Just tell me..."
    new "پدر مورگان؟ ما امروز چطور شروع کنیم؟ فقط به من بگو..."

    # say L222 pla
    old "(Holy fuck!! She'll catch me this time...)"
    new "(خودا جان!! این بار مرا می‌گیره...)"

    # say L223 gra
    old "Father? I already know you don't like to talk much when you're praying and well... I know what my soul needs this time. "
    new "پدر؟ من قبلاً می‌دونم وقتی در حال نماز هستید خیلی حرف نمی‌زنید و خب... این بار می‌دونم روح من چه نیازی داره."

    # say L227 gra
    old "Thoughts that I have had since long time ago."
    new "افکاری که از زمان‌های دور داشتم."

    # say L229 gra
    old "Having faith in your God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "ایمان به خداوند معنی‌اش اینه که نباید ترسید و شما راهنمای من هستید، کمک کنید این روح گناهکار رو تمیز کنم. روحم را از طریق بدنم به شما می‌دهم، پدر."

    # say L230 pla
    old "(Shit!... I gotta do it again.)"
    new "شیطون!... باید دوباره انجام بدم."

    # say L248 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're, I feel your grace inside."
    new "پدر عظیم مورگان، کلماتی برای بیان شکرتو ندارم. نشون دادی چقدر بزرگ و عظیمی هستی، احساس نعمتت رو درونم می‌کنم."

    # say L251 gra
    old "Good night Father Morgan, I can't wait to feel you inside of me again."
    new "خوب شام، پدر مورگان، نمی‌توانم صبر کنم تا دوباره احساست درون من را بیامزم."

    # say L266 pla
    old "(Damn it! This is becoming more and more complicated.)"
    new "لعنتی! این هر بار پیچیده‌تر می‌شه."

    # say L281 pla
    old "Hmm looks like no one is around."
    new "Hmm به نظر می‌رسه هیچ‌کس اینجا نیست."

    # say L282 pla
    old "Maybe the nun will come later... I better go to wait at the confessional."
    new "شاید مادام راهبه بعداً بیایه... بهتره من برم منتظر بقلم در محل اعتراف."

    # say L292 gra
    old "Father Morgan? You're already here, right?"
    new "آقای مورگان؟ شما قبلاً اینجا هستید، درسته؟"

    # say L301 gra
    old "Thank God! So, how should we start tonight Father? Just tell me..."
    new "الهی! پس، ما امشب چطور شروع کنیم، پدر؟ فقط به من بگو..."

    # say L308 gra
    old "No,  you know what? It is better to trust in divine providence and may the Lord be the one to guide the forgiveness of my sins tonight."
    new "نه، می‌دونی چی؟ به تقدیر الهی اعتماد کنیم و خداوند هدایت‌کننده بخشایش گناه‌های من در این شب باشد."

    # menu L327 
    old "Sex"
    new "جنس"

    # say L342 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're."
    new "پدر بزرگ مورگان، کلماتی برای ابراز شکرتو خالی نیست. شما به من نشان دادید چقدر بزرگ و عظیم هستید."

    # say L354 pla
    old "(It's too late, I better go to sleep...)"
    new "وقت شد، بهتره برم خواب بکنم..."

    # say L367 pla
    old "Hi sister Grace, I'm fine and you?"
    new "سلام خواهر گریس، من خوبم و تو چطوری؟"

    # say L368 gra
    old "I'm blessed thank God... Tell me, how can I help you?"
    new "الهی خدا ممنونم... بگو، چطور می‌تونم به تو کمک کنم؟"

    # say L393 gra
    old "[pla], are you ok?"
    new "[pla]، حالت خوبه؟"

    # say L398 pla
    old "Oh don't worry, I'm just checking if everything is okay."
    new "اوه نگران نباش، فقط می‌خوام ببینم همه چی خوبه."

    # say L399 gra
    old "Oh right, thank you so much for all your help."
    new "البته، ممنونم از همه کمکت."

    # say L400 pla
    old "You are welcome, see you later."
    new "خواهش می‌کنم، ببینم بعداً."

    # say L401 gra
    old "God be with you."
    new "خدا با تو باشد."


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/briAnimations.rpy
translate persian strings:

    # say L6 bri
    old "Holy shit! You really have a big cock!"
    new "هیولایی! واقعاً ناخنده‌ای بزرگی داری!"

    # say L7 bri
    old "That makes it even better to share my power with you!"
    new "این هم خوب‌تر می‌شه تا قدرت من رو با تو به اشتراک بذaram!"

    # say L11 bri
    old "Do you feel how your body receive my magical power within you?"
    new "آیا احساس می‌کنی چطور بدنت قدرت جادویی من رو در خودت می‌پذیره؟"

    # say L12 pla
    old "Ah?... Yes, yes... That's what I'm feeling..."
    new "آه؟... بله، بله... همین هست که می‌تونم حس کنم..."

    # say L16 bri
    old "Let's do it faster so you get more power!"
    new "بیای، سریع‌تر کنیم تا تو قدرت بیشتری دریافت کنی!"

    # say L17 pla
    old "Oh! Wow..."
    new "اوه! وای..."

    # say L45 bri
    old "Do you feel it? Do you feel all the power within me?"
    new "آیا احساسش می‌کنی؟ آیا احساس تمام قدرتی که درون من هست می‌کنی؟"

    # say L46 pla
    old "Yes, yes... I actually think I'm going to..."
    new "بله، بله... فکر کنم من در حال شدن..."

    # say L51 bri
    old "Well that is enough for now..."
    new "خب این برای حالا کافی است..."

    # say L52 bri
    old "Now you have more magic power."
    new "حالا تو قدرت جادویی بیشتری داری."

    # say L59 bri
    old "If you need more just let me collect some magic power for a couple of days..."
    new "اگر نیاز داری فقط به من بگو تا برای چند روز قدرت جادویی جمع کنم..."

    # say L61 bri
    old "Or you could share more with me for me to give you back just for fun."
    new "یا می‌تونی بیشتری با من به اشتراک بذاری تا من برایت برگردونم فقط برای لذت."

    # say L63 pla
    old "Actually that's a good idea, I'll keep that in mind..."
    new "در واقع این یه ایده خوبه، به ذهنم می‌رسونم..."

    # say L65 pla
    old "Great..."
    new "عالی..."

    # say L86 bri
    old "Uhh, it's definitely huge!"
    new "اوه، قطعاً بزرگه!"

    # say L87 bri
    old "You'll be definitely be one of the best Sexnote owners..."
    new "حتماً یکی از بهترین صاحبان سکس‌نوت خواهی بود..."

    # say L91 bri
    old "Ohh yeah, just like that! Oh gosh it feels amazing!"
    new "اوه بله، همینطور! اوه خدا، احساسش شگفت‌انگیز است!"

    # say L92 bri
    old "Mmm, are you enjoying the magic transfer?"
    new "ممن، آیا از انتقال جادویی لذت می‌بری؟"

    # say L96 bri
    old "I want more! Give me all you have!"
    new "بیشتر می‌خوام! همه‌ی تو رو به من بده!"

    # say L98 bri
    old "Oh yeah, don't stop, don't stop! Get all my power!"
    new "اوه بله، متوقف نشو، متوقف نشو! همه توانم رو بگیر!"

    # say L122 pla
    old "I- I cumming!"
    new "من- من می‌آیم!"

    # say L123 bri
    old "Ohhh yesss!"
    new "اوه بله!"

    # say L125 bri
    old "Phew! That was AWESOME!"
    new "پوف! این واقعاً عالی بود!"

    # say L126 bri
    old "I really missed this."
    new "این رو واقعاً خیلی دوست داشتم."

    # say L169 pla
    old "Oh fuck... I'm going to..."
    new "اوه شیطون... من قرار هست برم..."

    # say L176 bri
    old "I love to do this..."
    new "من دوست دارم این کار رو بکنم..."

    # say L177 pla
    old "Did you get good magic power?"
    new "بیلی، آیا سحر قوی‌ای گرفتی؟"

    # say L178 bri
    old "Yes, but you can always give me more if you want..."
    new "بله، اما اگر می‌خوای می‌تونی بیشتر به من بدی..."

    # say L179 pla
    old "Not now, I Need to use it to improve my skills first."
    new "الان نه، باید اول این قدر توانایی رو برای بهبود مهارت‌هام استفاده کنم."

    # say L180 bri
    old "You are right..."
    new "درست می‌گویی..."

    # say L184 bri
    old "By the way, I could help you too when you get an boner."
    new "البته، می‌تونم به تو هم کمک کنم وقتی اربازت شد."

    # say L186 pla
    old "Now that you mention it, I have a question... If I ever get to do something like this with a woman... Will I lose magical power?"
    new "البته، این سوال رو هم داشتم... اگه وقتی با یه زن چیزی مثل این انجام بدم... قدرت جادوییم رو از دست بدم؟"

    # say L188 bri
    old "To do what, have some sexual activity?"
    new "برای انجام چه کاری، فعالیت جنسی؟"

    # say L190 pla
    old "Ehh... Well, yes..."
    new "اوه... خب، بله..."

    # say L192 bri
    old "Don't worry! In fact, you should do it. "
    new "نگران نباش! در واقع باید این کار رو بکنی."

    # say L194 pla
    old "What do you mean?"
    new "من قصدت رو نمی‌فهمم."

    # say L196 bri
    old "Humans have a very particular phenomenon, when they have some high sexual excitation they generate magical power..."
    new "افراد یک پدیده خاص دارن، وقتی تحریک جنسی بالایی دارن، قدرت جادویی تولید می‌کنن..."

    # say L198 bri
    old "That magic power usually disappear quickly because there is nobody enabled to store that energy..."
    new "این توانایی جادویی معمولاً سریع از بین می‌رود زیرا هیچ‌کس برای ذخیره این انرژی آماده نیست..."

    # say L200 bri
    old "But you can, so, any kind of sexual activity will help you generate magical power and the more intense or higher sexual excitation the more magical power you will receive..."
    new "اما تو می‌تونی، پس هر نوع فعالیت جنسی به تو کمک می‌کنه تا قدرت جادویی بسازی و هر چه این فعالیت شدید‌تر یا جنسی‌تر باشه، قدرت جادویی بیشتری به تو می‌رسه..."

    # say L202 bri
    old "That is why within your objectives as a chosen, you must have a lot of sex, only then can you restore the magical world and regenerate the sources of magical power..."
    new "این به همین خاطر است که به عنوان انتخاب شده، باید خیلی سکس کنی، فقط اینجوری می‌توانی جهان جادویی رو بازسازی کنی و منابع جادویی رو تجدید نوسازی کنی..."

    # say L204 pla
    old "What the Fuck? You didn't tell me that..."
    new "چه فکر می‌کنی؟ تو اینو به من نگفتی..."

    # say L206 bri
    old "I'm telling you right now... It's that there are many things and I don't remember them all..."
    new "من الان به تو می‌گم... چیزهای زیادی هست و من همه‌شون رو به یاد نمی‌آورم..."

    # say L208 pla
    old "So I have to have a lot of sex to receive magical power?"
    new "پس باید خیلی جنس کنم تا قدرت جادویی دریافت کنم؟"

    # say L210 bri
    old "Actually, You must seek to reach the maximum of sexual arousal, so you must experiment a lot to see what is the most exciting for you..."
    new "در واقع، باید به حداکثر افتراش جنسی دست پیدا کنی، پس باید خیلی آزمایش کنی تا بفهمی چه چیزی برایت شگفت‌انگیز‌ترین هست..."

    # say L212 pla
    old "Hmmm... Ok, I'll see how to do something about it"
    new "Hmm... خب، ببینم چطور این کار رو انجام میدم"

    # say L234 pla
    old "It was great..."
    new "عالی بود..."

    # say L235 bri
    old "Yes, it was really fun... I want to do it again."
    new "بله، واقعاً لذت برده بودم... می‌خوام دوباره انجام بدیم."

    # say L236 pla
    old "Maybe later when I get more Magic Power..."
    new "شاید بعداً وقتی قدرت جادویی‌ام بیشتر شده..."

    # say L255 bri
    old "There you go [pla]."
    new "ببین [pla]."

    # say L256 bri
    old "Let yourself enjoy this."
    new "بیای از این لذت ببر."

    # say L257 bri
    old "It's very important that you relax."
    new "باید خیلی آرام باشی."

    # say L261 bri
    old "Are you liking this [pla]?"
    new "این [pla] رو لذت می‌بری؟"

    # say L263 bri
    old "Good! That's the most important part!"
    new "عالی! این مهم‌ترین بخش هست!"

    # say L268 bri
    old "I've always thought this [pla]! But as a human, your cock is very impressive!"
    new "همیشه اینجور فکر می‌کردم [pla]! ولی به عنوان انسان، ناخن تو خیلی جالب است!"

    # say L269 bri
    old "It's incredible that is rock hard!"
    new "البته که سنگینه!"

    # say L292 pla
    old "I- I feel like I'm about to cum Brixxida!"
    new "من- من حس می‌کنم الان همینجوری می‌تونم خروجی بدم بریکسیدا!"

    # say L293 bri
    old "Yeah! That's good! Do it!"
    new "بله! خوبه! انجام بده!"

    # say L294 bri
    old "Cum! I want you to shoot everything into the portal!"
    new "بیا! می‌خوام همه‌اش رو توی دروازه بی‌افزایی!"

    # say L300 bri
    old "That's perfect [pla]!"
    new "عالیه [pla]!"

    # say L301 bri
    old "Look at that! I can already tell that the portal is starting to charge!"
    new "ببین! قطعاً می‌تونم بگم پرتال شروع به شارژ کردن کرده."


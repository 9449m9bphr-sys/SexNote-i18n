# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Eventos Default.rpy
translate persian strings:

    # say L9 pla
    old "Alright… time for some practice."
    new "باشه… الان وقت تمرین هست."

    # say L10 pla
    old "Feels good to just sit down and play now."
    new "خوشحالم که فقط بنشینم و بازی کنم حالا."

    # say L11 pla
    old "It’s becoming part of the routine… and I actually look forward to it."
    new "این قسمت از روتین شده… و من واقعاً منتظرش می‌شوم."

    # say L17 pla
    old "That one came out clean."
    new "این بار خالی آمد."

    # say L18 pla
    old "The chords are flowing better every day."
    new "هر روز آهنگ‌ها بهتر جریان می‌یابن."

    # say L19 pla
    old "Hand still gets tired, but it doesn’t fight me anymore."
    new "دست هنوز خسته می‌شه، ولی دیگه با من جنگ نمی‌کنه."

    # say L20 pla
    old "Feels natural now… like the guitar is actually listening."
    new "الان طبیعی است… مثل اینکه گیتار واقعاً به من گوش می‌کنه."

    # say L23 pla
    old "Rhythm’s locking in nicely."
    new "ریتم خوب جا می‌یابه."

    # say L24 pla
    old "I can feel the music instead of just chasing the notes."
    new "من می‌تونم موسیقی رو حس کنم، نه فقط نت‌ها رو تعقیب کنم."

    # say L26 pla
    old "One more run-through. Let’s make it feel even smoother."
    new "بیای دوباره امتحان کنیم. بیایم همه‌ش رو هموارتر کنیم."

    # say L30 pla
    old "Still a couple of rough spots… but overall it sounded solid."
    new "هنوز چند نقص داره… اما کل کار خوب آمد."

    # say L31 pla
    old "I’m really starting to enjoy this."
    new "من واقعاً شروع کردم از این لذت ببرم."

    # say L32 pla
    old "It doesn’t feel like a chore anymore. It feels… right."
    new "بیشتر مثل یک وظیفه نیست. احساس می‌کنم… درسته."

    # say L33 pla
    old "Who knew picking up the guitar would end up being something I actually look forward to?"
    new "چه کسی فکر می‌کرد بازی گیتار به چیزی تبدیل بشه که واقعاً منتظرش هستم؟"

    # say L34 pla
    old "That’s enough for today. Fingers are happy."
    new "برای امروز کافیه. انگشت‌هام خوشحالم."

    # say L35 pla
    old "Tomorrow I’ll pick it up again… no pressure, just playing."
    new "فردا دوباره بهش برم… فشار نداره، فقط بازی می‌کنم."

    # say L44 bil
    old "There you are."
    new "اینجا هستی."

    # say L45 pla
    old "Hey Billie."
    new "هی بیلی."

    # say L46 bil
    old "Heh. Back again already?"
    new "هه. دوباره برگشته‌ای؟"

    # say L47 bil
    old "The guitar at home not doing it for you anymore?"
    new "گیتار خونه دیگه برای تو کار نمی‌کنه؟"

    # say L48 pla
    old "Yeah… I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "بله… من خیلی زمان به تنهایی تمرین می‌کنم، اما حس می‌کنم وقتی با تو هستم سریع‌تر پیشرفت می‌کنم."

    # say L49 bil
    old "Of course you do."
    new "البته."

    # say L50 bil
    old "Heh. Come on. Let’s take this to my room."
    new "هه. بیا. بیایم اینو به اتاق من ببریم."

    # say L54 bil
    old "Alright, we're here."
    new "البته، اینجا هستیم."

    # say L55 bil
    old "So... what are we practicing today?"
    new "پس... امروز چه چیزی رو تمرین می‌کنیم؟"

    # say L66 pla
    old "Uhh, I would say let’s just rehearse the song together today."
    new "بیل، من می‌گم بیاین امروز هم صدای آهنگ رو مرور کنیم."

    # say L67 pla
    old "I want to polish the chords even more, youb know..."
    new "من می‌خوام آکورد‌ها رو هم بیشتر تکمیل کنم، میدونی..."

    # say L68 bil
    old "Heh. Going for the safe route first? Fine by me… for now."
    new "هه. اول مسیر ایمن رو می‌روی؟ خوب، برای حالا می‌تونم بپذیرم."

    # say L69 bil
    old "Grab the guitar. Show me what you’ve been working on."
    new "گیتار رو بگیر. به من نشون بده چه کاری انجام دادی."

    # say L74 bil
    old "{i}I used to float above the ground…{/i}"
    new "{i}قبلاً من بالای زمین در ایران می‌پریدم…{/i}"

    # say L75 pla
    old "{i}Now every step just pulls me down…{/i}"
    new "{i} حالا هر قدم فقط من رو پایین می‌کشه… {/i}"

    # say L79 bil
    old "Hmm… your changes are actually smooth now. You’ve been practicing."
    new "هم… تغییراتتو الان خیلی هموار شدن. تمرین کرده‌ای."

    # say L80 bil
    old "We’re starting to sound like we really belong together on stage."
    new "شروع می‌کنیم مثل اینکه واقعاً روی صحنه با هم جا به جا می‌ایستیم."

    # say L81 bil
    old "Not bad at all. You’re actually carrying your part."
    new "حتماً بد نیست. تو در واقع نقشتو بازی می‌کنی."

    # say L82 pla
    old "Yeah, it feels good."
    new "بله، حس خوبی داره."

    # say L83 bil
    old "See? When we rehearse like this, we both get better together."
    new "ببین؟ وقتی همینجور تمرین می‌کنیم، هر دو ما با هم بهتر می‌شویم."

    # say L84 bil
    old "Still… I wouldn’t mind if you picked something a little more fun next time."
    new "البته… ولی فکر نمی‌کنم برات مشکلی باشه چیزی کمی جالب‌تر رو بعداً انتخاب کنی."

    # say L87 pla
    old "Uhh, I- I think my fingers could use some... practice."
    new "بله، اونجوری که منظورت رو متوجه شدم، انگشت‌هامون هم به تمرین نیاز دارن."

    # say L88 pla
    old "You know what I mean?"
    new "می‌دونی منظورم چیه؟"

    # say L89 bil
    old "Heh. There it is. I was hoping you’d go for this."
    new "هه. اینجاست. امیدوار بودم تو این راه رو بگیری."

    # say L90 bil
    old "Good choice. I like when you get straight to it."
    new "خوب انتخاب کردی. وقتی مستقیم می‌شی خوشحالم."

    # say L92 bil
    old "Come here, let’s make ourselves comfortable."
    new "بیا اینجا، بیایم راحت بشیم."

    # say L94 bil
    old "This is what you wanted, huh?"
    new "این همینه که می‌خواستی، درسته؟"

    # say L95 pla
    old "*Gulp*"
    new "*گلوله*"

    # say L96 bil
    old "They’re all yours today."
    new "امروز همه‌شون برای تو هستند."

    # say L98 bil
    old "Hands on them. You already know exactly how I like it."
    new "دستت رو رویشون بگذون. تو قبلاً می‌دونی دقیقاً چطور دوست دارم."

    # say L102 pla
    old "They’re… so soft every time. I can feel them filling my hands."
    new "آنها… هر بار خیلی نرم هستند. می‌تونم احساس کنم توی دستام پر می‌شن."

    # say L103 bil
    old "Mmm… squeeze them slowly. Open and close your hands… just like that."
    new "می‌تونی آهستون به آهستون فشار بدی. دستت رو باز و ببند… همینطور."

    # say L105 bil
    old "Nngh— yeah… a little harder now. Grip them properly."
    new "نه— بله… الان یک کم سخت‌تر. اونا رو خوب بگیر."

    # say L107 bil
    old "Fuck… keep that pace. Squeeze them like you mean it."
    new "بیل: فکر کن… این سرعت رو حفظ کن. آنها رو مثل اینکه می‌خوای فشار بده."

    # say L110 bil
    old "Now the nipples… grab them and pull… slow at first."
    new "حالا نیپل‌ها… بگیر و بکش… اول آرام آرام."

    # say L112 bil
    old "That’s it… stretch them gently."
    new "این‌جاست… آنها را به آرامی کشش."

    # say L114 bil
    old "Mmm—harder. Tug them a little more. You’re getting really good at this."
    new "ممن—سخت‌تر. آنها را کمی بیشتر کش. تو این کار رو واقعاً خوب یاد گرفتی."

    # say L116 bil
    old "Fuck… faster. Pull them nice and firm. I love how confident your hands feel now."
    new "فکر کنم… سریع‌تر. با این قدر محکم کششون. عاشق هستم که دست‌هایت الان اینقدر اطمینان دارن."

    # say L118 bil
    old "Mmm… your touch is way more precise lately. You’ve improved a lot."
    new "مم… لمس تو اخیراً خیلی دقیق‌تر شده. تو خیلی پیشرفت کردی."

    # say L119 bil
    old "Your fingers are definitely improving. They feel so much more alive and sure of themselves."
    new "انگشت‌هایت قطعاً بهتر شده‌ان. احساس زنده و اطمینان‌بخشی دارند."

    # say L120 bil
    old "Keep practicing that rhythm at home… or just come back whenever you want more of... this."
    new "در خانه این ریتم رو تمرین کن… یا فقط هر وقت می‌خوای بیشتر از… این… بیا برگرد."

    # say L124 pla
    old "Uhh, actually I was wondering if we could try the... 'advanced practice' today..."
    new "اوه، در واقع داشتم فکر می‌کردم اگه می‌تونیم امروز... تمرین پیشرفته رو امتحان کنیم."

    # say L125 bil
    old "Heh. Straight to my favorite part. I was really hoping you’d pick this one."
    new "هه. مستقیماً به بخش مورد علاقه‌ام. واقعاً امیدوار بودم این رو انتخاب کنی."

    # say L126 bil
    old "You know I like when you get straight to the fun stuff."
    new "می‌دونی وقتی مستقیماً به قسمت خوشحالم می‌رسی، خیلی لذت می‌برم."

    # say L128 bil
    old "Get ready. I’m getting on top."
    new "آماده شو. من بالایت می‌رم."

    # say L130 bil
    old "I know how much you like to see them, so why don’t we make it more enjoyable for both of us?"
    new "می‌دونم چقدر دوست داری اونا رو ببینی، پس چرا ما برای هر دوی ما لذت‌بخش‌تر کنیم؟"

    # say L133 bil
    old "Now use those fingers right. Show me what you’ve learned."
    new "الان انگشت‌هایت رو درست استفاده کن. به من نشون بده چه چیزی یاد گرفتی."

    # say L135 bil
    old "Mmm… circle my clit first. Gentle, like I showed you."
    new "ممنون… اول لب‌هایم رو لمس کن، مثل همین. آرام، مثلی که من نشون دادم."

    # say L145 bil
    old "Shit… your fingers really kept perfect rhythm this time."
    new "شیط… این بار انگشت‌هایت واقعاً ریتم درست رو نگه داشتند."

    # say L147 bil
    old "This is exactly the kind of dexterity we need… both on stage and off it."
    new "این دقیقاً همان مهارتیه که نیاز داریم… هم روی صحنه و هم خارج از آن."

    # say L151 pla
    old "Uhh… I’ve been practicing the guitar a lot by myself lately."
    new "اوه… اخیراً خیلی تمرین گیتار کردم."

    # say L152 pla
    old "And I was thinking… maybe it would be good if I helped you with your practice too, you know?"
    new "و من فکر می‌کنم… شاید خوب باشه اگه من هم به تمریناتت کمک کنم، می‌فهمی؟"

    # say L153 pla
    old "Like… helping you stay steady under pressure… like last time…"
    new "مثلاً… بهت کمک کنم تا زیر فشار هم مثل آخرین بار ثابت بمونی…"

    # say L154 bil
    old "Heh… look at you trying to be all subtle."
    new "هه… نگاهت به تو که می‌تونی همه چی رو پوشش بدی."

    # say L155 bil
    old "You’ve been practicing hard, huh? And now you want to 'help' me with my vocal training."
    new "تو خیلی تمرین کردی، هuh؟ حالا می‌خوای به من در تمرین صدایم کمک کنی."

    # say L156 bil
    old "Cute. Real cute."
    new "لطف داری. واقعاً لطف داری."

    # say L157 bil
    old "I know exactly what you mean, dummy."
    new "من دقیقاً می‌دونم می‌خوای چی، خرس."

    # say L158 bil
    old "Lie down. Time to put that tongue to good use."
    new "بیشینه. الان وقت است زبانت رو به کار ببری."

    # say L161 bil
    old "Tongue out. Keep me steady while I lose it."
    new "زبان رو بیرون بیا. من رو همچین که از دست می‌افتم، ثابت نگه دار."

    # say L164 pla
    old "You’re already dripping…"
    new "تو قبلاً در حال ریزشی…"

    # say L172 bil
    old "Nngh… your tongue is getting way too good at this."
    new "ننه… زبانت برای این کار خیلی خوب شده."

    # say L174 bil
    old "Every time you do this my voice gets stronger under pressure… and I get to enjoy that mouth of yours."
    new "هر بار که اینجوری می‌کنی صدتم زیر فشار قوی‌تر می‌شه… و من فرصت می‌دم تا اون دهان خوبتو لذت ببرم."

    # say L178 pla
    old "And sometimes I feel like I still need… a little extra motivation to keep improving."
    new "و بعضی مواقع حس می‌کنم هنوز به یه تشویق کوچیک نیاز دارم تا بهتر شوم."

    # say L179 bil
    old "Heh… so that’s what this is really about."
    new "هه… پس این همه برای این بود."

    # say L180 bil
    old "All that solo practice and you still need me to give you a little push, huh?"
    new "همه اون تمرین در تنهایی و هنوز به من نیاز داری که یه کمی تشویقت کنم، هه؟"

    # say L182 bil
    old "Would this be enough motivation for you?"
    new "این می‌تونه تحریک کافی برایت باشه؟"

    # say L183 bil
    old "Just looking at them… does that help?"
    new "فقط نگاه کردن به اونا… این کمک می‌کنه؟"

    # say L185 pla
    old "Y-yeah… they look amazing but… I was thinking maybe something more… direct?"
    new "بله… لباس‌هایشون عالی هستن ولی… فکر می‌کنم چیزی مستقیم‌تر می‌تونه کمک کنه؟"

    # say L186 bil
    old "Oh? Not satisfied with just the view?"
    new "اوه؟ از فقط نگاه کردن راضی نیستی؟"

    # say L187 bil
    old "Greedy today, aren’t you?"
    new "امروز خیلی طمعانی هستی، نه؟"

    # say L188 bil
    old "Heh… fine. I know exactly how to motivate you properly."
    new "هه… خوب. من دقیقاً می‌دونم چطور باید تو رو تحریک کنم."

    # say L191 bil
    old "Let me take care of that motivation the right way."
    new "بیات، من این انگیزش رو به درستی حل می‌کنم."

    # say L192 bil
    old "Eyes on me the whole time."
    new "چشم‌هایت رو بر من قرار بده کل وقت."

    # say L194 bil
    old "Mmm… look at you. Already so hard just from asking."
    new "ممنون… نگاهت به من. قدرتت از فقط درخواستم هم اینقدر بالا رفت."

    # say L195 pla
    old "Billie… that feels so good…"
    new "بیلی… این خیلی خوب می‌تونه باشه…"

    # say L197 bil
    old "Deeper now… I want to feel every throb."
    new "عمیق‌تر حالا… می‌خوام هر ضربه‌ای رو حس کنم."

    # say L198 pla
    old "Fuck… you’re way too good at this."
    new "فکر کنم تو خیلی خوب در این کاری هستی."

    # say L201 pla
    old "I’m— I’m close…!"
    new "من— من نزدیک هستم…!"

    # say L204 bil
    old "Mmm… every drop. Good boy."
    new "ممنون… هر قطره. خوبی تو."

    # say L206 bil
    old "Heh… feeling more motivated already?"
    new "هه… قدرت خودتو دوباره پیدا کردی؟"

    # say L208 bil
    old "Come back whenever you need some real motivation again… I’ll be waiting."
    new "هر زمان که به موتیویشن واقعی نیاز داشتی بیا برگرد… من منتظرت هستم."

    # say L212 bil
    old "Phew, well, that’s enough for today."
    new "پوف، خب، این قدر برای امروز کافی است."

    # say L213 bil
    old "You can come back whenever you need more 'practice'."
    new "می‌تونی هر وقت که نیاز به تمرین بیشتری داشتی برگردی."

    # say L214 bil
    old "Just text me. I’ll always make time… especially if you want the fun version."
    new "متن برام بفرست. همیشه وقت می‌تونم بذارم… خصوصاً اگه نسخه لذت‌بخش رو بخوای."

    # say L215 pla
    old "I’ll be back soon."
    new "به زودی برگشتم."

    # say L216 bil
    old "You better. Now get out before grandma walks in."
    new "باید بیاد. حالا برو قبل از اینکه بابا وارد بشه."

    # say L223 bil
    old "Phew… that’s enough for today."
    new "پوف… این قدر برای امروز کافیه."

    # say L224 bil
    old "Not bad. You’re actually starting to sound like you belong up there with me."
    new "نه بد. در واقع شروع کردی مثل اینکه بالای همه قرار بگیری."

    # say L225 bil
    old "Oh, by the way…"
    new "البته، به همین ترتیب…"

    # say L226 bil
    old "Tomorrow we have a practice with Bey. Don’t slack off tonight."
    new "فردا تمرینی با بی داریم. امشب خسته نباشی."

    # say L227 bil
    old "Get some rest, warm up your fingers, and meet me at school. We’re doing a full run-through with her watching."
    new "بیشتر خواب، انگشتاتو گرم کن و به مدرسه بیا. ما همه چی رو با او اجرا می‌کنیم."

    # say L228 pla
    old "Got it. I’ll be there."
    new "باشه. من اونجا خواهم بود."

    # say L229 bil
    old "You better. Don’t make me drag you out of bed."
    new "باید بیایی. نمی‌خوام بیاد برم تا تو رو از تخت بلند کنم."

    # say L236 bil
    old "You’re getting better every time. I can feel it."
    new "هر بار بهتر می‌شی. احساس می‌کنم."

    # say L237 bil
    old "Hey… before you go."
    new "ببین... قبل از اینکه بروی."

    # say L238 bil
    old "I need a favor. Free up your afternoon tomorrow and come over."
    new "لطفاً یک لطفی برای من انجام بده. فردا بعد از ظهر وقت خودت رو آزاد کن و بیا."

    # say L239 pla
    old "Sure, what for?"
    new "بله، برای چی؟"

    # say L240 bil
    old "Just come. I need you to accompany me somewhere. No questions."
    new "فقط بیا. باید تو رو همراه من بریم جایی. سؤالی پرس نه."

    # say L241 bil
    old "It’s important… and I don’t want to go alone."
    new "این مهمه... و من نمی‌خوام تنها برسم."

    # say L242 pla
    old "A- alright. I’ll be here."
    new "ا- خوب. من اینجا هستم."

    # say L243 bil
    old "Good. Don’t be late. Now get out before grandma walks in."
    new "خوب. دیر نشین. حالا برو قبل از اینکه بабا وارد بشه."


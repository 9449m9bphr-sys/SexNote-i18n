# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/LisStory.rpy
translate persian strings:

    # say L9 mo2
    old "No! You are my sister, but it doesn't mean I will give you money for every stupid scheme you can think of. I have my own responsibilities..."
    new "نه! تو خواهرم هستی، اما این به معنای این نیست که باید برای هر طرح خفنی که به ذهنت می‌رسه پول بدهم. من هم مسئولیت‌هایم رو دارم..."

    # say L10 lis
    old "But, I'm not asking you to give me money. Just lend me some or invest in my plan. This time what I have planned is sure to work..."
    new "اما، من ازت نمی‌خوام پول بدهی. فقط به من قرض بده یا توی برنامه‌ی من سرمایه‌گذاری کن. این بار همچین چیزی هست که مطمئن هستم کار خواهد کرد..."

    # say L11 mo2
    old "Really, Lisa? Do you think that a simple yoga academy is a million-dollar venture? "
    new "لیزا، می‌تونی واقعاً فکر کنی که یک آکادمی یوگا ساده میلیون‌دلاریه؟"

    # say L12 lis
    old "Well, maybe not a million, but I know it will help me pay off the debts I owe you."
    new "البته میلیون نه، اما می‌دونم که به من کمک می‌کنه بدهی‌هام رو به تو پرداخت کنم."

    # say L13 mo2
    old "You know what? I already gave too much of you. Get that money from some other sucker."
    new "دیت روش، من قبلاً خیلی از تو دادم. این پول رو از کسی دیگه بگیر."

    # say L17 lis
    old "But... but..."
    new "ولی... ولی..."

    # say L21 lis
    old "Oh... Hi there, [pla]. I'm sorry you had to hear all that... My sister is kind of a bitch sometimes..."
    new "اوه... سلام، [pla]. متاسفم که همه این‌ها رو شنیدی... خواهرم گاهی خیلی بدجور می‌شه..."

    # say L22 pla
    old "Oh yeah... I know what you mean..."
    new "اوه بله... من هم می‌دونم..."

    # say L23 lis
    old "Well, that won't stop me! I'm going to build my own yoga academy, with or without her help..."
    new "خب، این نمی‌تونه منو متوقف کنه! من قراره آکادمی یوگا خودمو بسازم، با یا بدون کمکش..."

    # say L24 pla
    old "That seems like a good idea..."
    new "این به نظر یک ایده خوب می‌آید..."

    # say L25 lis
    old "Thank you, [pla]! You are always a charm... Well, I have to go. If you need me, you can look for me at my house..."
    new "ممنون، [pla]! همیشه لطف داری... خب، باید برسم. اگه نیازت به من بود، می‌تونی به خونه‌ام بیایی..."

    # say L26 pla
    old "Ok [lis]! See you later..."
    new "باشه [lis]! دیده‌ت می‌شود..."

    # say L42 lis
    old "Hey, [pla], how are you doing?"
    new "سلام، [pla]، چطوری؟"

    # say L43 pla
    old "Hi, I am fine."
    new "سلام، من خوبم."

    # say L44 pla
    old "You sure? I mean... I hope you're better."
    new "مطمئنی؟ منظورم... امیدوارم حالت بهتر باشه."

    # say L45 lis
    old "Oh I see, you mean about me and my sister..."
    new "اوه، من متوجه شدم، می‌خوای در مورد من و خواهرم بگپ..."

    # say L46 pla
    old "Hmm... Yeah."
    new "همم... بله."

    # say L47 lis
    old "You know my inner peace remains the same... I understand that she has her own business. I think that's the way the universe tells me I need to try by my own, because I know..."
    new "میدونم آرامش داخلی من همچنان همینه... فهمیدم که او کار خودش رو داره. فکر کنم این راهیه که جهان به من میگه باید خودم تلاش کنم، زیرا میدونم..."

    # say L48 lis
    old "I feel great things are coming, and I think this is the moment I can show the world what I am made of, and I know this is a dream today but it will soon be real."
    new "احساسی دارم که چیزهای عالی رو آماده‌ام، و فکر می‌کنم این لحظه‌ای است که می‌توانم به دنیا نشون بدم از چه سیالی ساخته شده‌ام، و می‌دونم این امروز یه رویا هست ولی زودی واقعی خواهد شد."

    # say L49 lis
    old "If fate puts a dream in your heart is because it's meant to be."
    new "اگر تقدیر رویا را در قلب تو قرار می‌دهد، این به معنای آن است که برای این است."

    # say L52 lis
    old "It's ok, you should to learn a little more, why not learn meditation with me."
    new "خوبه، باید یه کم بیشتر یاد بگیری، چرا نمی‌یادی مدیتیشن رو با من بیاموزی؟"

    # say L53 lis
    old "You need to learn to find the perfect balance in your body and soul so you can be one with yourself along with the universe, to better feel and understand your purpose and of life itself."
    new "تو باید بیاموزی تا تعادل کامل بین بدنت و جانت رو پیدا کنی، تا بتونی با خودت و کیهان هماهنگ باشی و هدفت و معنای زندگی رو بهتر بفهمی."

    # say L54 pla
    old "Hmm...  s- sure."
    new "Hmm... خب، حتماً."

    # say L55 lis
    old "You know what, I will go today and check the options at the mall to see if I could run my own yoga academy from there, I will find the perfect place and fill out all the paperwork."
    new "می‌دونی چی، امروز می‌رم و گزینه‌ها رو توی مال بررسی می‌کنم تا ببینم می‌تونم از اونجا آکادمی یوگا خودمو راه‌اندازی کنم، جای مناسب پیدا می‌کنم و همه مدارک رو تکمیل می‌کنم."

    # say L57 lis
    old "Yeah, but there is so much work to do, you know... The place, the rent, the equipment, the ambience, everything must flow with the same energy."
    new "بله، اما کار زیادی هست، می‌دونی... مکان، اجاره، تجهیزات، جو، همه چی باید با هم هماهنگ باشه."

    # say L58 lis
    old "Once I get all the info, I will have an idea about the budget."
    new "بازهای اطلاعات رو گرفتم، در مورد بودجه ایده خواهم داشت."

    # say L59 pla
    old "Hope you get all the info you need, good luck!"
    new "امیدوارم همه اطلاعاتی که نیاز داری رو بدست بیاری، خوش حالم!"

    # say L77 pla
    old "Hi, Lisa, how are you?"
    new "سلام لیزا، چطوری؟"

    # say L78 lis
    old "Oh no [pla], I think I need to reconsider my entire project."
    new "اوه نه [pla]، فکر می‌کنم باید کل پروژه‌ام رو بازبینی کنم."

    # say L80 lis
    old "Well, [pla], I went to the mall, had a hard time finding the manager, but think it was just fate trying to save me from that pain."
    new "خوب، [pla]، من به مال رفتم، با پیدا کردن مدیر مشکل داشتم، ولی فکر می‌کنم این فقط تقدیر بود که می‌خواست از آن دردسر منو نجات بده."

    # say L81 lis
    old "I mean the rent for just a very small place was huge, something really out of my league, the requirements to rent the place are quite stressful."
    new "من قصد دارم بگم اجاره یک جای خیلی کوچک هم خیلی زیاد بود، خیلی خارج از محدوده‌ی من، شرایط اجاره‌گیری هم خیلی استرس‌زا بود."

    # say L82 lis
    old "I'm so frustrated, I- I need to think of a different project..."
    new "من خیلی ناراحتم، من- من باید پروژه‌ای دیگه در نظر بگیرم..."

    # say L83 lis
    old "But the worst part of that day was when I discovered THERE WAS a yoga academy, as if that wasn't enough it was also really close to the place I was looking at..."
    new "اما بخش بدتر اون روز وقتی متوجه شدم که یک آکادمی یوگا هست، و مثل این نبودن کافی، همچنین خیلی نزدیک به جایی بود که داشتم بهش نگاه می‌کردم..."

    # say L84 pla
    old "Wait what? So you will have to compete."
    new "منتظر بقیه‌ی حرفت. پس باید با آنها رقابت کنی."

    # say L85 lis
    old "Well, that academy was bigger than what I was thinking, I think they have been there for a while because there was a lot of people, it was so amazing, the place was radiant and beautiful..."
    new "خب، آن آکادمی بزرگتر از آنچه من فکر می‌کردم بود، به نظر می‌رسد که از زمانی است که آنجا هستند زیرا مردم زیادی داشت، خیلی شگفت‌انگیز بود، جایی روزگار و زیبا..."

    # say L87 lis
    old "Yeah, I immediately thought to myself I could be better than any of their instructors but clearly I can't compete with that company..."
    new "بله، فوراً به خودم فکر کردم که می‌تونم بهتر از هیچ یک از معلمانون باشم ولی مشخصاً نمی‌تونم با اون شرکت رقابت کنم..."

    # say L88 pla
    old "I understand..."
    new "من متوجه هستم..."

    # say L89 lis
    old "Yeah, I think I need to be humble and to accept fate as it is..."
    new "بله، فکر می‌کنم باید درست باشم و با آنچه است راضی شوم..."

    # say L90 pla
    old "But... There has to be something you can do..."
    new "ولی... حتماً چیزی هست که می‌تونی انجام بدی..."

    # say L91 lis
    old "What are my options? There's nothing I can do."
    new "چه گزینه‌هایی دارم؟ هیچ کاری نمی‌تونم بکنم."

    # say L92 pla
    old "I mean, you can check different places, not just the mall."
    new "من قصدم اینه که جای‌های مختلفی بررسی کنی، نه فقط مال."

    # say L93 lis
    old "Hmm I don't know, I just need time to focus on a different idea."
    new "Hmm نمی‌دونم، فقط وقتی می‌خوام روی یه ایده جدید تمرکز کنم نیاز دارم."

    # say L94 pla
    old "Sorry to hear you so frustrated, but you know what? You can count on me."
    new "متأسفم که اینقدر ناراحتی، ولی می‌دونی چی؟ می‌تونی بر من اتکا کنی."

    # say L95 lis
    old "Oh that's very sweet of you."
    new "این خیلی شیرین از تو است."

    # say L96 pla
    old "I know you can get a yoga academy like you want, we just need to look for alternatives."
    new "می‌دونم می‌تونی اکادمی یوگا رو مثل همچه خواستی درست کنی، فقط باید جایگزین‌ها رو پیدا کنیم."

    # say L97 lis
    old "I'll think about it, thanks for being so supporting, I appreciate your time."
    new "من در موردش فکر می‌کنم، ممنون از حمایتت، وقتت رو قدرت می‌دم."

    # say L98 pla
    old "It's ok, I just hope I can help."
    new "خوبه، فقط امیدوارم بتونم کمکت کنم."

    # say L116 pla
    old "Hi, how-"
    new "سلام، چطوری-"

    # say L117 lis
    old "Hey! I needed to talk to you, I have great news!"
    new "اوه! باید با تو صحبت کردم، خبر خوبی دارم!"

    # say L118 pla
    old "Wow, I can see you're feeling better now..."
    new "واو، می‌تونم ببینم حالت بهتر شده..."

    # say L120 lis
    old "I really am, last time we talked I was very down, but I started my daily meditation practice. While breathing I discovered some light within the darkness..."
    new "بله، واقعاً هستم. آخرین بار که باهم صحبت کردیم، خیلی ناراحت بودم، اما شروع به تمرین مداوم مراقبت کردم. در حال نفس‌کشی، برخی نورهایی را در تاریکی پیدا کردم..."

    # say L122 lis
    old "While I was doing this yoga position to relax, I thought I was doing something wrong, then I corrected the position, I still wasn't sure what exactly was wrong..."
    new "در حالی که این وضعیت یوگا رو برای آرامش انجام می‌دادم، فکر کردم چیزی اشتباه می‌کنم، بعد موقعیت رو اصلاح کردم، هنوز هم مطمئن نبودم دقیقاً چه اشتباهی داشتم..."

    # say L123 lis
    old "So I slightly moved my arms and legs to get the perfect position, I know it sounds a bit silly but, when I corrected the position, it felt like my body was in a different place..."
    new "پس کمی دست‌ها و پاها رو جابجا کردم تا موقعیت درست باشه، می‌دونم خیلی سخن‌پرداز می‌تونه به نظر برسه، ولی وقتی موقعیت رو اصلاح کردم، مثل این بود که بدنم تو جایی دیگه قرار گرفته."

    # say L125 lis
    old "I mean, sometimes meditation is not about knowing the Asanas but how you connect in the moment and the environment..."
    new "من قصد دارم بگم که گاهی مدیتیشن نه درباره دانستن آساناهاست، بلکه درباره این است که چطور در لحظه و محیط خود را متصل می‌کنی..."

    # say L126 lis
    old "It's not about how you follow the rules but how you connect your body and soul through exercise, do you understand?"
    new "این درباره این نیست که قوانین رو دنبال کنی بلکه اینجاست که از طریق تمرین جسم و روحتو به هم متصل کنی، متوجه شدی؟"

    # say L127 pla
    old "Hmm... I think so."
    new "هم... فکر کنم همینه."

    # say L128 lis
    old "That was my reflection, I'm not a regular Yoga instructor, I mean this academy at the mall can have 10 teachers but I am no a regular teacher, yoga and meditation is part of my life..."
    new "این نظر من بود، من مربی یوگا معمولی نیستم، منظورم اینه که این آکادمی در مال می‌تونه ۱۰ مربی داشته باشه اما من مربی معمولی نیستم، یوگا و مدیتیشن بخشی از زندگی من هست..."

    # say L130 lis
    old "For me, yoga is not just about the equipment or space, I don't need that so I can perform a good pranayama, those are things for a comfortable service experience."
    new "برای من یوگا فقط مربوط به تجهیزات یا فضای خاصی نیست، من نیازی به اونا برای انجام یک پرانایاما خوب ندارم، اینا برای تجربه راحت‌تر خدمات هستند."

    # say L131 lis
    old "My personal experience can't be beat because it's actually richer than any other yoga experience, I'm not selling a product! I'm sharing my own experience..."
    new "تجربه شخصی من هیچ تجربه یوگا دیگری رو نمی‌تونه شکسته کنه، زیرا واقعاً غنی‌تر از همه هست، من محصولی رو فروختن نمی‌خوام! من تجربه خودمو به اشتراک می‌ذaram..."

    # say L132 pla
    old "Very interesting."
    new "خیلی جالب است."

    # say L133 lis
    old "And you were right..."
    new "و تو درست می‌گفتی..."

    # say L135 lis
    old "Yes! About the mall, my business can be run in a totally different place... In fact... I think... Since I don't need any special place, I can just have it at my own HOUSE."
    new "بله! درباره مال، کسب و کار من می‌تونه تو جایی کاملاً متفاوت اداره بشه... در واقع... فکر می‌کنم... چون نیازی به هیچ جای خاصی ندارم، می‌تونم فقط اون رو تو خانه‌ی خودم داشته باشم."

    # say L136 pla
    old "That would be very convenient."
    new "این خیلی راحت‌تر می‌شه."

    # say L137 lis
    old "Here, my customers can experience a very close yoga training, focus on the intimate learning, no distractions, no rules, only the yoga experience I provide."
    new "اینجا مشتریان می‌تونن تجربه یوگا خیلی نزدیک رو ببینن، روی یادگیری شخصی تمرکز کنن، بدون هیچ اغتشاشی، بدون قوانین، فقط تجربه یوگایی که من ارائه می‌دم."

    # say L139 lis
    old "Well, I will need to check how to obtain the necessary business permits and licenses."
    new "البته، باید بررسی کنم چطور می‌تونم اجازه‌نامه‌ها و مجوزهای لازم رو به دست بیارم."

    # say L140 pla
    old "I am sure that won't be any trouble."
    new "مطمئن هستم این مشکلی نداره."

    # say L141 lis
    old "Thank you for listening to me and giving me the support, I needed I appreciate it."
    new "ممنونم که به من گوش کردی و حمایت کردی، لازم داشتم این حمایت رو."

    # say L142 pla
    old "I actually did nothi-"
    new "من در واقع هیچ کاری نکردم-"

    # say L143 lis
    old "Oh, by the way, let me show you some ideas I have for the yoga room."
    new "البته، بیا براتون نشون بدم چند ایده‌ای که برای اتاق یوگا دارم."

    # say L145 lis
    old "Please come, I'm sure you are going to like it too, I wasn't aware my house was so perfect for this."
    new "لطفاً بیا، مطمئن هستم که تو هم خوشحال می‌شی، من فکر نمی‌کردم خونه‌ام برای اینقدر مناسب باشه."

    # say L146 pla
    old "Is it?"
    new "وای، هست؟"

    # say L147 lis
    old "Yes, the second floor is big and a good area I can take advantage of."
    new "بله، طبقه دوم بزرگ است و من می‌توانم از آن بهره‌برداری کنم."

    # say L155 pla
    old "Hmm, this room is pretty big."
    new "این اتاق خیلی بزرگه."

    # say L157 lis
    old "You see it? It is so private, very intimate, and full of silence, this place is perfect... I did not realize it was that big until I took out all the stuff... What do you think?"
    new "دیدی؟ اینجا خیلی خصوصی، محرمانه و پر از سکوت است، این مکان کامله... من تا وقتی همه چیز رو بیرون بردم متوجه نبودم اینقدر بزرگه... نظرت چیه؟"

    # say L158 pla
    old "It is very nice and peaceful."
    new "این جا خیلی خوب و آرام است."

    # say L159 lis
    old "Actually, it's going to be better, you know music, fragrances, all that it takes to meditate and find your inner peace."
    new "در واقع، اینجا خوبتر می‌شه، موسیقی، عطرها، همه چیزی که برای مeditation و پیدا کردن آرامش داخلی لازم است."

    # say L160 pla
    old "Wow, you have your business almost running. If you need something, you can count on me anytime."
    new "واو، کسب و کارت تقریباً در حال اجراست. اگر نیازی به چیزی داری، همیشه می‌تونی بر من حساب کنی."

    # say L161 lis
    old "You're really sweet... I think I am ok-"
    new "تو خیلی لطف داری... فکر کنم من خوب هستم-"

    # say L162 lis
    old "Wait, you know what?..."
    new "بیا، یه چیزی به ذهنم رسید..."

    # say L163 lis
    old "I was wondering yesterday, how a customer would feel, you know the place... The energy... I just want to have an idea how they could feel."
    new "دیروز فکر می‌کردم، یه مشتری چطور می‌تونه حس کنه، مثلاً جایی که... انرژی‌اش... من فقط می‌خوام بدونم اونا چطور می‌تونن حس کنن."

    # say L164 lis
    old "Would you like to help me? You just need to be like my ‘instructor' I will tell you step by step what to do... What do you think?"
    new "می‌تونی به من کمک کنی؟ فقط باید مثل معلم من باشی، من بهت مرحله به مرحله می‌گم باید چی کنی... فکر کی می‌کنی چطور باشه؟"

    # say L165 pla
    old "Hmm, I can help you sure..."
    new "ممنون، می‌تونم بهت کمک کنم..."

    # say L166 lis
    old "Thank you, I will walk you through every single step so you can learn too."
    new "ممنون، من هر مرحله رو به تو توضیح می‌دم تا تو هم یاد بگیری."

    # say L167 lis
    old "Let's do a couple of regular exercises."
    new "بیایم چند تمرین معمولی انجام بدیم."

    # say L172 lis
    old "First we will try something casual, this position is called ‘Utkatasana', it's quite focused on breathing and your legs so since you will be the trainer..."
    new "اول چیزی آسان‌تر امتحان می‌کنیم، این وضعیت به نام «اوتکاتاسانا» هست، خیلی روی تنفس و پایانت تمرکز داره پس چون تو مربی هستی..."

    # say L173 lis
    old "I will do the position so please follow me, don't do the position with me but control the position from the back, helping me to keep my balance, you got it?"
    new "من این وضعیت رو انجام می‌دم پس لطفاً از پشت من هدایت کن، به من کمک کن تا تعادل بگیرم، متوجه شدی؟"

    # say L176 lis
    old "Ok... Here we go, please put your hands on my waist."
    new "باشه... حالا لطفاً دست‌هایت رو روی کمرم بگذار."

    # say L183 lis
    old "Like I said follow my movement, I will go down..."
    new "مثل همین جوری حرکت من رو دنبال کن، من پایین می‌روم..."

    # say L189 pla
    old "Sure..."
    new "بیای..."

    # say L192 lis
    old "You're keeping cool good, let's go up... Perfect."
    new "تو خوب آرام می‌مانی، بیای بالا برویم... عالی."

    # say L199 lis
    old "Well, I can feel it positive, I can breathe perfectly, the light is quite good, do you feel comfortable?"
    new "خب، من احساس مثبت می‌کنم، نفس می‌کشم کاملاً خوب، نور هم خیلی خوبه، تو حس خوبی داری؟"

    # say L200 pla
    old "Yes, I feel nice."
    new "بله، حس خوبی دارم."

    # say L201 lis
    old "Well, that was very productive, I feel relaxed, don't forget to keep breathing."
    new "خب، این خیلی مفید بود، من آرام هستم، فراموش نکن تن دیش."

    # say L202 pla
    old "Sure, I'm focused."
    new "بله، من تمرکز دارم."

    # say L203 lis
    old "That's perfect, let's try a different pose..."
    new "عالیه، بیایم همین حالا یک وضعیت دیگه امتحان کنیم..."

    # say L210 lis
    old "Next one will be totally different it's on the floor, its name is ‘Upward Facing Dog', for this position your help is very important..."
    new "بعدی کاملاً متفاوت است، روی زمین انجام می‌شود، اسمش «Upward Facing Dog» است، برای این وضعیت کمک تو بسیار مهم است..."

    # say L211 lis
    old "Because you will help me with the effort applied to my back, so I'll lie down looking up, if you want to be more comfortable, please get on your needs."
    new "چون تو باید به من در تلاوتی که روی پشتم انجام می‌دهی کمک کنی، پس من روی زمین خواهم دراز کشید و به سمت بالا نگاه خواهم کرد، اگر می‌خوای راحت‌تر باشی، لطفاً روی نیش‌هایت بنشین."

    # say L218 lis
    old "I really like this position, I can feel a lot of energies running through me."
    new "این وضعیت رو خیلی دوست دارم، می‌تونم انرژی زیادی رو درونم حس کنم."

    # say L219 lis
    old "Ahh it's so relieving, please push a bit towards my shoulders."
    new "اوه اینقدر آرام‌بخش است، لطفاً یک کم به سمت شانه‌هایم فشار بده."

    # say L232 lis
    old "Oh yeah, like that, this is very relaxing for me."
    new "اوه بله، همینطور، این برای من خیلی آرام‌بخش است."

    # say L233 pla
    old "(She looks very enticing... I need to focus.)"
    new "(او خیلی جذاب است... باید تمرکز کنم.)"

    # say L241 pla
    old "(Oh shit... I'm getting hard... Oh, please not now...)"
    new "(اوه شیطون... من سخت می‌شوم... اوه، لطفاً الان نه...)"

    # say L248 lis
    old "You are doing amazing."
    new "تو عالی هستی."

    # say L250 lis
    old "I think this place is incredible to do this... I can't wait to bring the candles, the music... It'll be so perfect!"
    new "من فکر می‌کنم این جا برای این کار شگفت‌انگیزه... نمی‌تونم صبر کنم که شمع‌ها رو و موسیقی رو بیارم... خواهیم خیلی خوب بود!"

    # say L251 lis
    old "Alright, we need to continue... Listen, the next position is amazing, it's one of the most interesting and very easy to learn."
    new "باشه، باید ادامه بدیم... گوش کن، موقعیت بعدی عالیه، یکی از جالب‌ترین‌هاست و خیلی آسان برای یادگیری."

    # say L257 lis
    old "This asana sequence is called ‘Extended Puppy Pose', it's really relaxing, so please pay attention..."
    new "این توالی آسانا به نام «پوز شیرکوچه‌ای گسترش‌یافته» شناخته می‌شود، واقعاً آرام‌بخش است، پس لطفاً دقت کن..."

    # say L259 pla
    old "W- what do you need me to do?"
    new "ب- باید چیکار بکنم؟"

    # say L260 pla
    old "(I need to control myself or she will notice my hardon.)"
    new "من باید خودم رو کنترل کنم، در غیر این صورت او سختی من رو متوجه می‌شه."

    # say L261 lis
    old "Well... For this position the hips and legs are very important, so I will need you to push them, so I can stretch my back to the fullest..."
    new "خب... برای این موقعیت، کمر و پاها خیلی مهم هستن، پس باید تو اونا رو پیش ببری تا من بتونم پشتمو کاملاً کشوندم."

    # say L262 lis
    old "Please hold my waist behind me and help me keep my balance."
    new "لطفاً پشت من را از پایین نگه دار و به من در نگه داشتن تعادل کمک کن."

    # say L264 pla
    old "(I hope she doesn't notice it.."
    new "امیدوارم متوجه نشده باشه..."

    # say L271 lis
    old "Please try to rest your waist with mine, control your breathing too."
    new "لطفاً کمرت رو با من مجاور قرار بده، نفس‌ت رو هم کنترل کن."

    # say L281 lis
    old "I need to feel you firmly so I can rest my back and relax my body."
    new "من نیاز دارم تو رو محکم بحسنم تا بتوانم پشتمو استراحت دهم و بدنم را آرام کنم."

    # say L282 pla
    old "(Oh It feels so delicious.)"
    new "اوه این حس خیلی لذت‌بخش است."

    # say L284 lis
    old "Can push me harder, that way both of us will be able to the do exercise more intensely."
    new "می‌تونی به من فشار بیشتری بدی، اینجوری هر دو ما می‌تونیم تمرین رو شدید‌تر انجام بدیم."

    # say L292 lis
    old "Yes, just like that."
    new "بله، همینطور."

    # say L294 lis
    old "That was perfect... I think we are done!"
    new "این هم کامل بود... فکر کنم تمام شدیم!"

    # say L297 lis
    old "I like your enthusiasm but I think you can stop now."
    new "من هیجان‌ت رو دوست دارم ولی فکر کنم می‌تونی حالا متوقف شی."

    # say L303 pla
    old "OH!? Yes, I am sorry, I was... I... Was quite focused on the position."
    new "اوه! بله، معذرت، من... من خیلی روی اون موقعیت تمرکز کردم."

    # say L314 lis
    old "Oh that's fantastic, I'm sorry to interrupt you."
    new "اوه این عالیه، معذرت که قاطع تو شدم."

    # say L315 pla
    old "(Phew, thank god, she didn't notice.)"
    new "پوف، خوشحالم که متوجه نشده."

    # say L316 pla
    old "Oh no, it's ok no worries."
    new "نه، هیچ اشکالی نداره."

    # say L317 lis
    old "Amazing, you did a wonderful job, I appreciate your commitment."
    new "عالی، کار عالی کردی، خوشحالم از تعهدت."

    # say L318 pla
    old "No problem..."
    new "هیچ اشکالی نداره..."

    # say L319 lis
    old "I'm very surprised how our chakras get together so well... I am sure that is going to be the feeling I have with my customers."
    new "متعجبم از اینکه چاکرهامون هم‌خواندن به هم اینقدر خوبه... مطمئنم این حسی هست که با مشتریانم هم خواهم داشت."

    # say L320 lis
    old "I'll let you rest, thank you so much for your help, I will keep meditating a little longer."
    new "من به تو اجازه می‌دم استراحت کنی، خیلی ممنون از کمکت، من هنوز مدتی دیگه می‌خوام مدیت کنم."

    # say L321 lis
    old "If you want to learn more, I could give you a few more lessons."
    new "اگر می‌خوای بیشتر بیاموزی، می‌تونم چند درس دیگه بهت بدم."

    # say L322 pla
    old "... Alright... I'm gonna leave you, so you can practice more."
    new "... خب... من از تو برمی‌گردم، تا بیشتر تمرین کنی."

    # say L323 lis
    old "Thank you honey, see you later."
    new "ممنون عزیزم، بعداً می‌بینیم."

    # say L324 pla
    old "Have a good one."
    new "باز هم موفق باشی، عزیزم."

    # say L328 pla
    old "(That was close... I think she didn't realize...)"
    new "خوشحالم که متوجه نشد... به نظر می‌رسه نشناخته است..."

    # say L348 pla
    old "Oh, hi Lisa, what a surprise! Did you come to talk with [mo2]?"
    new "اوه، سلام لیزا، چه مفاجا! آیا برای صحبت با [mo2] اومدی؟"

    # say L349 lis
    old "Oh no, don't worry, I am fine, I just came because I... Wanted to talk to you."
    new "نه، نگران نباش، من خوبم، فقط برای این اومدم که... می‌خواستم با تو حرف بزنم."

    # say L350 pla
    old "With me? Ok..."
    new "با من؟ خب..."

    # say L352 lis
    old "I have already had some customers; they are really happy with how we do things."
    new "من قبلاً مشتری‌هایی داشتم؛ واقعاً خوشحال هستند از نحوه کار ما."

    # say L353 pla
    old "Oh... That's amazing."
    new "اوه... این خیلی عالیه."

    # say L354 lis
    old "Yes, but this is just the beginning, better things are coming."
    new "بله، اما این فقط شروع است، چیزهای بهتری در انتظار ما هستند."

    # say L355 pla
    old "I am glad that you are very positive."
    new "خوشحالم که تو خیلی مثبتی."

    # say L356 lis
    old "I am just thankful for everything the universe is preparing for me."
    new "من فقط ممنونم از همه چیزی که جهان برای من آماده کرده."

    # say L357 lis
    old "Actually, I need to ask you something, I don't want to do this but you're the one who would understand what I need."
    new "در واقع، باید چیزی از تو بپرسم، نمی‌خوام این کار رو بکنم ولی تو هستی که می‌فهمی اون چیزی که لازم دارم."

    # say L358 pla
    old "Hmm... What is this about?"
    new "Hmm... این درباره چیه؟"

    # say L359 lis
    old "Like I said the business is taking shape, I already have some customers, however I am very busy lately with paperwork to get the final license and all of that... You know..."
    new "مثل همینجوری که گفتم کار خوبی شکل می‌گیره، مشتری‌هایی هم دارم، ولی اخیراً خیلی با کارهای اداری مشغول هستم تا مجوز نهایی رو بگیرم و همه چیز... میدونی..."

    # say L360 lis
    old "The thing is I have a new customer in the afternoon coming, she is very very enthusiastic and is quite interested on the yoga program."
    new "مهم‌ترین چیز اینه که مشتری جدیدی در بعد از ظهر دارم، او خیلی خیلی هیجانیه و به برنامه یوگا علاقه زیادی داره."

    # say L362 lis
    old "Yeah, she paid for the entire course and I'm already planning her sessions."
    new "بله، او برای کل دوره پرداخت کرده و من قراره جلساتش رو برنامه‌ریزی کنم."

    # say L363 lis
    old "However the time frame she said she is available is exactly the same time I have a very important appointment..."
    new "ولی زمانی که او گفت در اختیار داره دقیقاً همون وقت هست که من یه نوبت خیلی مهم دارم..."

    # say L364 lis
    old "It's an interview to verify the information to approve the business. I already have all the documentation needed to legally open it..."
    new "این مصاحبه برای تأیید اطلاعات و تصویب کسب و کار است. من قبلاً تمام مدارک لازم برای افتتاح قانونی آن را دارم..."

    # say L365 lis
    old "But this is a temporary one, this interview  gives me the approval so... I do need your help now... If you can cover me, so I can attend it."
    new "اما این موقتیه، این مصاحبه موافقت‌نامه می‌ده به من... پس الان به کمکت نیاز دارم... اگه بتونی جای من رو بپوشی تا برم شرکت کنم."

    # say L366 pla
    old "Well... I think I can... But-"
    new "خب... فکر کنم بشه... اما-"

    # say L367 lis
    old "Amazing! that is fantastic. The entire universe is making it possible once again, did you know you are being an instrument of the universe?"
    new "الان! این خیلی عالیه. تمام جهان دوباره این امکان رو می‌سازه، می‌دونی که تو ابزاری از جهان هستی؟"

    # say L368 pla
    old "M- me... ?"
    new "من...؟"

    # say L369 lis
    old "Of course! I am very grateful... You cannot not imagine how important this is for me. You only need to help me with this session..."
    new "البته! خیلی ممنونم... تو نمی‌تونی فهمونی اینقدر مهمه برای من. فقط باید به من در این جلسه کمک کنی..."

    # say L370 lis
    old "Since you have already done the basic yoga training with me you are the only one that can cover me, it's going to be the same routine."
    new "چون قبلاً آموزش یوگا اولیه رو با من گذراندی، تنها کسی هستی که می‌تونی جای من رو بگیری، همون روتین قبلی خواهد بود."

    # say L371 lis
    old "I know you are very intuitive and can do the session like we did before, I already checked with the customer and she is ok with that."
    new "میدونم تو خیلی شهودی هستی و میتونی جلسه رو مثل قبل انجام بدی، قبلاً با مشتری هم صحبت کردم و او موافقت کرد."

    # say L373 lis
    old "Please reach me at home later, I am very sorry we won't have enough time to plan it but I am sure you will do great."
    new "لطفاً بعداً به خونه‌ام برس، خیلی متاسفم وقت کافی برای برنامه‌ریزی نداریم ولی مطمئنم که خوب انجام می‌دهی."

    # say L374 pla
    old "Hmm ok, I'll be there on time."
    new "خوب، من هم اومم درست موقع."

    # say L375 lis
    old "Thank you so much... See you then."
    new "ممنونم... تا وقتی."

    # say L376 pla
    old "No problem, bye."
    new "هیچ اشکالی، خداحافظ."

    # say L393 pla
    old "(Oh my god, is Anastasia, What is she doing here.)"
    new "اوه خدا، این آناستازیا هست، اینجا چه کاری داره؟"

    # say L395 lis
    old "Oh, hey [pla]! thank so much for coming."
    new "اوه، سلام [pla]! خیلی ممنونم که اومدی."

    # say L398 lis
    old "Oh, I am sorry, let me introduce you guys properly... [pla], this is Anastasia... Anastasia, this is  [pla]."
    new "اوه، معذرت، باید شما رو به هم رسمی معرفی کنم... [pla]، این است آناستازیا... آناستازیا، این است [pla]."

    # say L399 ana
    old "Thank you Lisa, It's nice to see you again [pla]!"
    new "ممنون لیزا، خوشحالم که دوباره تو رو می‌بینم [pla]!"

    # say L400 pla
    old "G- good to see you too."
    new "خوشحالم که تو رو هم دوباره می‌بینم."

    # say L402 lis
    old "Oh... So do you guys already know each other?"
    new "اوه... پس شما دو تاشون قبلاً می‌شناسید؟"

    # say L403 ana
    old "Hehehe, Yes, we know each other pretty well, right [pla]?"
    new "هههه، بله، ما هم خوب از هم می‌دونیم، درسته [pla]؟"

    # say L405 lis
    old "Oh really? Please tell me... Once you guys arrived I just felt like fate was planning this meeting."
    new "او واقعاً؟ لطفاً بگو... وقتی شما دو تا اومدید حس کردم مثل اینه که قدرت می‌خواست این جلسه رو برنامه‌ریزی کنه."

    # say L406 pla
    old "Well, she has bought some products... From [sis]'s website."
    new "خب، او برخی محصولات خریده... از وب‌سایت [sis]."

    # say L407 ana
    old "Yeah, I met him as the delivery guy, I was surprised by his manners and because he is very intelligent with pretty huge talent..."
    new "بله، من با او به عنوان مرسوله‌دهن آشنا شدم، از رفتارش تعجب کردم و چون او خیلی هوشمند است و دارای توانایی‌های زیادی است..."

    # say L409 lis
    old "I am very glad to hear that you understand each other, I will try to be back as soon as possible, in the meantime [pla] will help you with the first session Anastasia."
    new "خوشحالم که می‌شنوم توها با هم متوجه هستید، سعی می‌کنم زودتر برگردم، در این میان [pla] به تو در جلسه اول کمک کنه، آناستازیا."

    # say L410 ana
    old "Oh, that's very interesting, don't you think [pla]?"
    new "اوه، این خیلی جالب است، آیا تو هم اینطور فکر می‌کنی [pla]؟"

    # say L412 pla
    old "Y- yes... Very interesting..."
    new "بله... خیلی جالب است..."

    # say L414 lis
    old "I‘ve got the feeling this session will be really nice. Well guys, please enjoy the session, I will be back as soon as possible."
    new "احساسی دارم این جلسه خیلی خوب خواهد بود. خب بچه‌ها، لطفاً از جلسه لذت ببرید، من هر قدر زودتر بر می‌گردم."

    # say L415 ana
    old "Bye bye Lisa."
    new "بای بای لیسا."

    # say L424 ana
    old "Finally we are alone. I am  very ready for the class."
    new "اینبار فقط ما هستیم. خیلی آماده‌ام برای این جلسه."

    # say L425 pla
    old "Well... Yes, I- I thank you for coming today, we did prepare a very great Yoga session for you."
    new "خب... بله، من- من ممنونم که امروز اومدی، ما واقعاً یک جلسه یوگا عالی برایت آماده کرده‌ایم."

    # say L426 ana
    old "Oh, I like that, I wasn't expecting to have a very handsome trainer, it's going to be really fun."
    new "اوه، اینو دوست دارم، منتظر نبودم یک مربی خوش‌تیپ داشته باشم، خیلی خوشحالم."

    # say L428 pla
    old "Why don't we go to the yoga room where it's more comfortable for the session."
    new "بیای به اتاق یوگا که آماده‌تر برای جلسه‌مون هست."

    # say L437 pla
    old "This is going to be our yoga room, we hope you enjoy not only the lesson but also the finer details for this experience."
    new "این اتاق یوگا ما خواهد بود، امیدواریم نه فقط درس بلکه جزئیات لطیف این تجربه را هم لذت ببری."

    # say L438 ana
    old "It's beautiful, smells very nice."
    new "خوبه، خوشبو هم هست."

    # say L439 pla
    old "Every detail has been thought out to make your experience better."
    new "هر جزئیاتی برای اینکه تجربه‌ت بهتر باشه فکر شده."

    # say L440 ana
    old "You guys are doing it very well."
    new "شماها این کار رو خیلی خوب انجام میدید."

    # say L441 pla
    old "Now, let's start with the lesson, so you can get to relax a bit more."
    new "خب، حالا با شروع درس شروع می‌کنیم تا بتونی بیشتر آرامش پیدا کنی."

    # say L447 pla
    old "Alright, for the first position I will be behind you to help you keep your body balanced, and that way we can do the exercise properly."
    new "باشه، برای اولین وضعیت من پشت تو خواهم بود تا کمکت کنم بدنت را تعادل بدی و اینجوری می‌تونیم تمرین رو درست انجام بدیم."

    # say L448 ana
    old "That's perfect."
    new "این خیلی خوبه."

    # say L449 pla
    old "We will start straight up and then we will go down keeping the straight position and correct breathing."
    new "اول مستقیم می‌مانیم و بعد با حفظ وضعیت مستقیم و تنفس صحیح پایین می‌رویم."

    # say L460 pla
    old "Try to keep your thoughts focus on the exercise."
    new "سعی کن فکرت رو روی تمرین متمرکز کنی، کریس."

    # say L461 pla
    old "(Her butt is really big, I need to think of something different. She's so hot...)"
    new "بازونش واقعاً بزرگه، باید به چیز دیگه فکر کنم. خیلی جذابه..."

    # say L462 ana
    old "Am I doing it right?"
    new "من درست انجام می‌دم؟"

    # say L463 pla
    old "Yes... Delicious."
    new "بله... لذت‌بخش."

    # say L466 pla
    old "I- mean... Correct, yes, you are doing it correctly."
    new "من قصدم... درسته، بله، تو این کار رو درست انجام میدی."

    # say L467 ana
    old "Oh, thank you."
    new "اوه، ممنون."

    # say L468 pla
    old "Do you feel relaxed?"
    new "آنا، حس می‌کنی آرام شدی؟"

    # say L469 ana
    old "Yes, I like it."
    new "بله، لذت بردم."

    # say L470 pla
    old "It was good, we are going to stop now and continue with the following, did you like it?"
    new "خوب بود، الان قراره متوقف شیم و به مرحله بعدی برویم، لذت برده بودی؟"

    # say L471 ana
    old "It was nice."
    new "خوب بود."

    # say L477 pla
    old "I hope you feel calmer now... So, our next position will help with the balance of our energies..."
    new "امیدوارم حالا آرام‌تر باشی... پس، موقعیت بعدی به تعادل انرژی‌هامون کمک خواهد کرد..."

    # say L478 pla
    old "I'll need you to lie down on your stomach, first we will stretch your legs and back, raising your head up, later you will let it down to breathe again."
    new "اول باید روی شکم خودت بخوابی، بعد ما می‌تونیم پاها و پشتت رو کشش بدیم، سرتو بالا ببری و بعد دوباره برای نفس کشیدن پایین بیاری."

    # say L480 pla
    old "This position is quite demanding, I will be there to make sure you can focus more and make the most out of it."
    new "این وضعیت خیلی متقاضی است، من اینجا هستم تا بتوانی بیشتر تمرکز کنی و از اون بهره‌برداری کنی."

    # say L481 ana
    old "Sounds good!"
    new "خوبه!"

    # say L487 pla
    old "First relax and breathe while lying down in that position."
    new "اول آرام شو و در این وضعیت تنفس کن."

    # say L488 ana
    old "Hmm it feels good."
    new "Hmm حس خوبی داره."

    # say L489 pla
    old "Now you are going to stretch your arms and I'm going to press your shoulders back so you can tense your muscles, and tilt your head back."
    new "حالا تو باید دست‌هات را بکشی و من شانه‌هات رو برمی‌گردم تا عضلاتت تنیده شن و سرتو به پشت ببری."

    # say L503 pla
    old "(Wow... I can see her boobs!)"
    new "واو... می‌تونم سینه‌هایش رو ببینم!"

    # say L504 pla
    old "(Oh no... I am getting a hardon again. Shit... I should act normal so she doesn't notice.)"
    new "(اوه نه... دوباره سخت شدم. شیطون... باید طبیعی باشم تا متوجه نشود.)"

    # say L512 ana
    old "So... Like this?"
    new "پس... مثل این؟"

    # say L515 ana
    old "Are you getting distracted?"
    new "تو می‌خوای پرتوجه شی؟"

    # say L517 pla
    old "Oh no... I am ok... Let's breath a bit more."
    new "نه نه... من خوبم... بیای بیشتر نفس بکشیم."

    # say L523 ana
    old "OH WOW!"
    new "اوه وای!"

    # say L524 pla
    old "(Dammit she noticed it.)"
    new "لعنتی، متوجه شد."

    # say L525 ana
    old "I thought you were a bit distracted but now I know you brought a bit of company, I think one of your muscles needs to relax a bit too..."
    new "فکر کردم خیالی پرتوجه هستی، اما حالا متوجه شدم همراهی کوچیکی هم داری، به نظر می‌رسه یکی از عضلاتت هم باید آرام بگیره..."

    # say L526 pla
    old "I- am very sorry, please do not take me wrong way, I am... I am just very nervous."
    new "من- خیلی متاسفم، لطفاً اشتباه نفرمایی، من... من فقط خیلی ناراحت هستم."

    # say L529 ana
    old "It's totally ok, I feel very flattered and I like it... The effort makes you feel a bit stressed, I think since you are helping, I should help you too, so you can feel better."
    new "خیلی مشکلی نداره، خیلی لبخند می‌زنم و دوست دارم... تلاشت باعث استرس می‌شه، فکر می‌کنم چون تو کمک می‌کنی، من هم باید کمکت کنم تا حالت بهتر شه."

    # say L530 pla
    old "W- What? Oh no, of course not.. I think this is moment to finish the session."
    new "و- وای! نه، البته نه.. فکر کنم این لحظه برای خاتمه دادن جلسه باشه."

    # say L531 ana
    old "I know you want it... I remember last time you enjoyed it with my hands, probably this time we can try with... I don't know, maybe my mouth?"
    new "می‌دونم می‌خوای... همینجوری رو به خاطر می‌آورم که آخرین بار لذت برداشتی از دست‌های من، شاید این بار بتونیم با... نمی‌دونم، شاید با دهانم امتحان کنیم؟"

    # say L532 pla
    old "... (What the fuck!)"
    new "چه خبره!"

    # say L533 ana
    old "Why don't you relax a bit, let me check it out on my own, I know you will like it... Let's open this sweet gift."
    new "چرا نه آرامش بیشتری ببری، بگذار من خودم بررسی کنم، میدونم دوستت خواهد اومد... بیای بزنیم این هدیه شیرین رو باز کنیم."

    # say L541 ana
    old "Wow, it's huge, things are getting better since last time, looks very tasty... Do you mind if I give it a taste?"
    new "واو، خیلی بزرگه، از آخر بار بهتر شده، خیلی لذت‌بخش می‌تونه باشه... آیا مخالف هستی که من یه ذوقش ببرم؟"

    # say L543 ana
    old "Let me take care of this now!"
    new "بگذار من الان اینو انجام بدم!"

    # say L555 ana
    old "Did you like it?  You are not the only expert here, I am quite ready for this kind of 'exercises', how would you rate my performance?"
    new "می‌پسندید؟ شما تنها خبره نیستید، من هم برای این نوع تمرین‌ها آماده‌ام، عملکرد من چقدر می‌دهی؟"

    # say L568 lis
    old "Hey guys, I'm finally here, did you guys finish already?"
    new "دستا، من در نهایت اینجا هستم، شماها قبلاً تمام شدید؟"

    # say L569 pla
    old "(Oh god, for a few minutes early and she could have discovered us...)"
    new "او خدا، چند دقیقه زودتر بود و می‌تونست به ما برسه..."

    # say L570 ana
    old "Yes, it was very good. [pla] is the most wonderful partner I could ask for..."
    new "بله، خیلی خوب بود. [pla] بهترین همکاری که می‌تونستم درخواست کنم..."

    # say L571 ana
    old "He is very pleasant even though some positions got very hard, I like it too much!"
    new "او حتی با اینکه بعضی وضعیت‌ها خیلی سخت بودن هم خوشحالم، من هم خیلی لذت بردم!"

    # say L572 lis
    old "Aww, that's dazzling... I appreciate your words."
    new "اوه، این خیلی جالب است... من از کلماتت ممنونم."

    # say L574 ana
    old "For sure, I know I will be coming very often, I didn't know it was so amusing, very ‘delicious', I was fully satisfied."
    new "حتماً، می‌دونم خیلی مکرراً می‌آیم، نمی‌تونستم بفهمم اینقدر لذت‌بخش هست، خیلی «لذیذ» بود، کاملاً راضی شدم."

    # say L575 lis
    old "Sounds terrific... Wait, what's that on your face?"
    new "صدا می‌کنه عالی... اما چیزی روی چهرت داره، چیه؟"

    # say L577 ana
    old "Oh, what's that? Ahh, It must be sweat, you know this is kind of new for me-"
    new "اوه، اون چیه؟ اه، باید عرق باشه، می‌دونی این برای من جدیده-"

    # say L578 lis
    old "Yeah, right."
    new "بله، البته."

    # say L579 ana
    old "But no worries, I will clean it in a moment, thank you."
    new "ولی نگران نباش، الان خودم اینو تمیز می‌کنم، ممنون."

    # say L582 ana
    old "Thank you very much Lisa, once again, today's session was amazing, and [pla], this definitely be repeated, I need more... I mean sessions like this one."
    new "ممنون می‌لیسا، دوباره، جلسه‌ی امروز عالی بود و [pla]، قطعاً این تکرار می‌شه، من نیاز دارم به... منظورم جلسات مثل این."

    # say L583 pla
    old "... Y- yes, see you later..."
    new "... ب-بله، بعداً می‌بینیم..."

    # say L584 lis
    old "Bye bye, Anastasia."
    new "بای بای، آناستازیا."

    # say L594 lis
    old "I really wanted to thank you, I know you weren't prepared enough but you actually did incredible, I am very embarrassed because it was all of the sudden for you to do it."
    new "من واقعاً می‌خواستم ازت تشکر کنم، می‌دونم آماده نبودی ولی واقعاً شگفت‌انگیز عمل کردی، خیلی خجالت‌زده‌ام چون برای تو همه اینا ناگهانی بود."

    # say L595 pla
    old "No problem, I am happy to be of help."
    new "هیچ اشکالی، خوشحالم که کمکتون کردم."

    # say L596 lis
    old "I just want you to know that you're fantastic, you accomplished to do the session without the proper training..."
    new "می‌خوام بدانی که تو عالی هستی، تونستی جلسه رو بدون آمادگی کافی انجام بدی..."

    # say L597 lis
    old "I can see a great talent in you, I'm willing to teach you if want to know more, I hope I will not bother you again."
    new "من توانایت رو می‌بینم، خوشحال می‌شوم اگه بخوای بیشتر یاد بگیری، امیدوارم دیگه آزار ندم."

    # say L598 pla
    old "Thank you very much, and don't worry you can ask me if you need more help."
    new "ممنونم خیلی، و نگران نباش اگه نیاز به کمکی داشتی می‌تونی از من بپرسی."

    # say L599 lis
    old "Thank you honey, I appreciate your kindness."
    new "ممنون عزیزم، لطفت رو قدر می‌کنم."

    # say L619 lis
    old "Hi, [pla], how are you?"
    new "سلام، [pla]، حالت چطوره؟"

    # say L620 pla
    old "I am fine, thank you. How about you?"
    new "من خوبم، ممنون. تو چطوری؟"

    # say L621 lis
    old "I am well, actually I'm kind of concerned..."
    new "من خوبم، در واقع یه نگرانی هم دارم..."

    # say L622 pla
    old "Why is that?"
    new "چرا؟"

    # say L623 lis
    old "To be honest, I think you're better than what I thought, Anastasia was really pleased with your job last time, so she wants to continue the program with you..."
    new "صusch، می‌تونم صusch بگم که فکر می‌کنم تو بهتری هستی از آنچه فکر می‌کردم، آناستازیا واقعاً خوشحال شد از کاری که انجام دادی آخر هفته، پس می‌خواد برنامه رو با تو ادامه بده..."

    # say L624 pla
    old "A- Anastasia?"
    new "ا- آناستازیا؟"

    # say L625 lis
    old "Yes, however, my concern is... I didn't want to ask you again, however since Anastasia is asking for you, I want her to have the best experience..."
    new "بله، اما نگرانی من اینه... نمی‌خواستم دوباره ازت بپرسم، اما چون آناستازیا درخواستت رو داده، می‌خوام تجربه‌اش بهتر باشه..."

    # say L626 lis
    old "Of course the decision hasn't been made yet, I explained to her I needed to discuss it with you first, before I could say yes or no, so I just wanted to let you know."
    new "البته هنوز هیچ تصمیمی گرفته نشده، من به او توضیح دادم که باید ابتدا با تو صحبت کنم تا بتوانم بله یا خیر بگویم، پس فقط می‌خواستم ازت بگم."

    # say L628 lis
    old "Last time you helped me but since this is going to be a more frequent assistances, I am thinking you can be part of the business and you will have an income..."
    new "آخرین بار کمکت کردی ولی چون این بار کمک‌های مداومی هست، فکر می‌کنم می‌تونی بخشی از کسب و کار باشی و درآمدی داشته باشی..."

    # say L629 lis
    old "It will also bring positive things to your life, making it part of this new way of living. You know the more that you feel the universe the better you can share with others."
    new "این هم چیزهای مثبتی برای زندگی تو خواهد داشت، این رو به این روش جدید زندگی وارد می‌کنم. می‌دونی هر چه بیشتر با جهان ارتباط داشته باشی، بتونی بیشتر با دیگران در اشتراک بذاری."

    # say L630 lis
    old "I will give you the proper training, so you'll have the knowledge you need, we can make the business grow together, I know other customers will love your job too."
    new "من به تو آموزش لازم رو خواهم داد، تا دانش لازم رو بدست بیاری، می‌تونیم با هم کسب و کار رو رشد بدیم، مطمئن هستم مشتری‌های دیگه هم کارتو دوست خواهند داشت."

    # say L631 pla
    old "I appreciate you considering me as an option, I will gladly help you."
    new "ممنونم که من رو به عنوان گزینه‌ای در نظر گرفتی، خوشحال می‌شم کمکت کنم."

    # say L632 lis
    old "Oh [pla], you are very kind, I have no words on how I appreciate your help, I will do everything I can so you can learn more."
    new "اوه [pla]، خیلی مهربانی داری، هیچ کلمه‌ای برای اینکه چقدر از کمکت ممنونم نمی‌تونم بیابم، همه چیز رو خواهم کرد تا بتونی بیشتر یاد بگیری."

    # say L633 pla
    old "Don't worry, I'm glad to help."
    new "نگران نباش، خوشحالم که کمکت کنم."

    # say L634 lis
    old "Actually, are you too busy right now?"
    new "در واقع، الان خیلی مشغولی؟"

    # say L635 pla
    old "You mean now? I think I can stay for a while, why do you ask?"
    new "منظورت الان هست؟ فکر کنم می‌تونم یه کم بمانم، چرا اینجوری می‌پرسی؟"

    # say L636 lis
    old "It's because we can go ahead with a practice today the next session you will have with Anastasia."
    new "چون می‌تونیم امروز تمرین کنیم، جلسه بعدیت با آناستازیا خوب می‌شه."

    # say L637 pla
    old "Oh, I see, sounds good."
    new "اوه، متوجه شدم، خوب است."

    # say L638 lis
    old "Perfect, let's go."
    new "عالی، برویم."

    # say L646 lis
    old "Now let's get ready to start, please remember to control your breathing so we can make the most out of the exercise."
    new "حالا باید آماده شویم برای شروع، لطفاً نفس‌ت رو کنترل کن تا از تمرین بهتر استفاده کنیم."

    # say L648 lis
    old "Since the previous positions  you worked with her were more aimed to release stress and anxiety, this time we will get more into the yoga world, so you can discover more sensations."
    new "از آنجا که وضعیت‌های قبلی که با او کار کردی بیشتر برای از بین بردن استرس و نگرانی بودند، این بار بیشتر به دنیای یوگا خواهیم پرداخت تا بتوانی احساسات بیشتری را کشف کنی."

    # say L650 lis
    old "The first position we will work on is extremely demanding, you need to be very careful so you can give the right directions..."
    new "اولین وضعیتی که خواهیم کار کرد بسیار چالش‌برانگیز است، باید بسیار مراقب باشی تا راهنمایی‌های درست را بدهی..."

    # say L651 lis
    old "Depending on you the customer can feel more energy coming thru."
    new "بسته به تو مشتری می‌تونه انرژی بیشتری بیاورد."

    # say L652 pla
    old "Ok, what... Do I need to do?"
    new "باشه، من چه کاری باید بکنم؟"

    # say L653 lis
    old "For the position, we will focus on the back, You will make sure I can get the perfect position, I will be on my hands and feet, looking straight."
    new "برای موقعیت، ما روی پشت تمرکز خواهیم کرد، تو باید اطمینان حاصل کنی که من موقعیت درستی داشته باشم، من روی دست‌ها و پاهایم خواهم بود، مستقیم به جلو نگاه می‌کنم."

    # say L654 lis
    old "You need to help stretch the back by applying some pressure on the hips, Initially the weight of the body will be on the arms..."
    new "تو باید با اعمال فشار روی کمر، کمک کنی تا پشت خوب بکشیده بشه، اول وزن بدن روی دست‌ها خواهد بود."

    # say L655 lis
    old "After some seconds we will need to change and apply it to the legs, you need to help the customer lift the hips and now firmly apply pressure with your pelvis."
    new "بعد از چند ثانیه باید تغییر دهیم و فشار روی پاها اعمال کنیم، باید به مشتری کمک کنی که کمرش رو بلند ببره و حالا با لگن خودت به محکمی فشار بزن."

    # say L664 lis
    old "We will need to repeat that movement several times, watch your breathing and making sure the position is being done properly. Got it?"
    new "باید این حرکت رو چند بار تکرار کنیم، نفست رو در نظر بگیر و مطمئن شو که موقعیت درست انجام می‌شه. گرفتی؟"

    # say L666 lis
    old "Perfect, let's try it."
    new "عالی، بیاین امتحانش کنیم."

    # say L673 lis
    old "That's it... You are doing it right."
    new "این هستش... تو درست انجام میدی."

    # say L674 pla
    old "(Oh god this is quite enticing, I will need to touch her butt to grab her hips...)"
    new "اوه خدا، این خیلی جالب است، باید پوزه‌اش رو لمس کنم تا کمرش رو گرفته باشم..."

    # say L675 lis
    old "Don't forget to hold the hips firmly, the muscle must be exercised."
    new "فراموش نکن هیپ‌ها رو محکم بگیر، عضله باید تمرین شه."

    # say L676 pla
    old "(If I do it any harder, I'll touch her pussy.)"
    new "اگر هم سخت‌تر انجام بدم، پوسی‌اش رو لمس می‌کنم."

    # say L677 pla
    old "Don't worry... I will do it."
    new "نگران نباش... من انجام میدم."

    # say L678 lis
    old "Perfect, that will help us to ensure the customer is getting the right position."
    new "عالی، این به ما کمک می‌کنه تا مشتری موقعیت درست رو بگیره."

    # say L679 lis
    old "That was very good, you are doing good. Now let's move to the second position."
    new "این خیلی خوب بود، خوب کار می‌کنی. حالا بیایید به موقعیت دوم برویم."

    # say L685 pla
    old "Good! What's up with this one?"
    new "خوب! این یکی چطوره؟"

    # say L686 lis
    old "As you can imagine, we need to increase the difficulty, for the next position your help is essential, I will relax my entire body, you will hold my hips..."
    new "همانطور که می‌فهمی، باید سطح دشواری رو افزایش بدیم، برای موقعیت بعدی کمکت ضروریه، من تمام بدنم رو آرام میدم، تو باید کمرم رو نگه داری..."

    # say L687 lis
    old "The first step will be to carry my body weight, you can support yourself with your pelvis, however I understand that could be very tiring, that is why we'll have some tiny breaks."
    new "مرحله اول برداشتن وزن بدن من خواهد بود، می‌توانی از باسنگت استفاده کنی، اما می‌فهمم این کار خیلی خسته‌کننده باشه، همین جوش ما توقفات کوچکی خواهیم داشت."

    # say L688 lis
    old "Since you are using your pelvis, the breaks moment will be to relax your pelvis and let the weight remain on the customers arms and your legs."
    new "چون از باسنگت استفاده می‌کنی، لحظات استراحت برای آرام‌دادن باسنگت هست، وزن رو روی بازوهای مشتری و پاشونت بگذار."

    # say L689 pla
    old "Ok, sounds a bit difficult."
    new "باشه، به نظر می‌رسه کمی سخته."

    # say L690 lis
    old "Not really... However, that is why you need to keep breathing and stay focused so you can use your strength smartly and make the exercise enjoyable for you too."
    new "واقعاً سخت نیست... اما برای همین باید تنفست رو حفظ کنی و تمرکزت رو حفظ کنی تا بتونی به درستی از قدرتت استفاده کنی و تمرین برای خودت هم لذت‌بخش باشه."

    # say L692 lis
    old "Let's do it! Now that you have the idea."
    new "بیای، الان که ایده‌ت رو داری."

    # say L693 pla
    old "Sure, go ahead."
    new "بله، برو پیش."

    # say L699 lis
    old "Use your chakras to control your breathing that is the key for a position like this."
    new "با چاکرتون تنفست رو کنترل کن، این برای این وضعیت مهمه."

    # say L708 pla
    old "Sure, I am breathing deeply and consciously."
    new "بله، من عمیقاً و آگاهانه نفس می‌کشوم."

    # say L709 lis
    old "I am very satisfied to hear that, try to use all your energy."
    new "خوشحالم که اینجوری می‌شنوم، سعی کن همه انرژیت رو استفاده کنی."

    # say L710 pla
    old "(This feels very delectable, she's rubbing my cock... I'm getting hard now...)"
    new "این حس خیلی لذت‌بخش است، تو داری سفتی من رو ماساژ می‌کنی... الان خیلی سفت شدم..."

    # say L713 lis
    old "You need to focus too, so the exercise can be effective."
    new "تو هم باید تمرکز کنی، تا تمرین اثر بذاره."

    # say L715 lis
    old "Keep doing that for a while with your customer, we will stop for now so we can continue with our next position, I can see you learn very fast."
    new "بهتره اینجوری برای یه لحظه با مشتریت ادامه بدی، ما الان متوقف می‌شیم تا به حرکت بعدی برسیم، می‌بینم خیلی سریع یاد می‌گیری."

    # say L716 pla
    old "(Oh, thanks god!)..."
    new "اوه، ممنون از خدا!"

    # say L722 pla
    old "(I don't know if I will be able to hide my boner this time.)"
    new "(نمیدونم این بار میتونم شورتم رو پوشش بدم یا نه.)"

    # say L723 lis
    old "The last position is quite interesting, is related with the energies we have accumulated in the back, we will need to ignite them so we can release more of our chakra's potential..."
    new "پوزیشن آخر خیلی جالب است، مربوط به انرژی‌هایی است که در پشت تو تجمع یافته‌اند، باید آن‌ها را روشن کنیم تا بتوانیم از توان بالاتر چاکرا استفاده کنیم."

    # say L724 lis
    old "Since they are located in your back right before the gluteus,the position is aimed to get those points. Your customer will probably need you to get in that position."
    new "چون این نقاط در پشت تو، دقیقاً قبل از عضلات لوله‌ای قرار دارن، موقعیت برای رسیدن به اونجا طراحی شده. مشتریت احتمالاً نیاز داره که تو این موقعیت رو بگیری."

    # say L725 lis
    old "I will lie down on my shoulders, but I will hold my waist with my hands, my arms are going to be the main support."
    new "من روی شانه‌هایم خواهم افتاد، اما با دستام کمرم رو خواهم گرفت، بازوها اصل حامی خواهند بود."

    # say L727 lis
    old "You will keep balance of the body as well as the pressure needed in two different points, the legs and back of the customer."
    new "تو هم باید تعادل بدن رو حفظ کنی و فشار لازم رو در دو نقطه مختلف، پاها و پشت مشتری، وارد کنی."

    # say L728 lis
    old "Let's start the position so you can have a better idea..."
    new "بیایید موقعیت رو شروع کنیم تا بتونی بهتر درک کنی..."

    # say L729 pla
    old "(This position looks demanding so I will stay focused, I need to breath and to think something different.)"
    new "این وضعیت به نظر خسته‌کننده می‌تونه باشه، پس من تمرکز می‌کنم، باید نفس بکشم و به چیزی دیگه فکر کنم."

    # say L730 pla
    old "Perfect, I am ready."
    new "عالی، آماده‌ام."

    # say L731 lis
    old "Perfect here we go..."
    new "خوب، حالا شروع می‌کنیم..."

    # say L738 pla
    old "(Oh no, this position is making me feel very horny, I am sure she will notice pretty soon.)"
    new "اوه نه، این وضعیت من رو خیلی خیال‌پرداز می‌کنه، مطمئن هستم زودی متوجه می‌شه."

    # say L739 lis
    old "Are you breathing properly, remember this is important for you to be able to assist your customer."
    new "دیویز خوبی داری؟ به یاد داشته باش این برای اینه که بتونی مشتریت رو کمک کنی."

    # say L740 pla
    old "Hmm... Sure, yes."
    new "Hmm... بله، همینطور."

    # say L743 lis
    old "I can see you are quite motivated with this asana, you will need to control your energies so you can decide how to express or attract with your body."
    new "می‌تونم ببینم تو از این آسانا خوشحالی، باید انرژی‌ات رو کنترل کنی تا بتونی تصمیم بگیری چطور با بدنت عبارت یا جذب کنی."

    # say L745 lis
    old "Alright, I think we are done..."
    new "باشه، فکر کنم تمام شد..."

    # say L757 lis
    old "OH MY GOD!"
    new "اوه خدا!"

    # say L769 pla
    old "I- I'm sorry, I'm so sorry these positions are really enticing... A- and I can't help it."
    new "من- من خیلی متاسفم، این وضعیت‌ها واقعاً جذاب هستند... و- و نمی‌تونم خودمو کنترل کنم."

    # say L770 lis
    old "Don't worry, it's natural, I just got surprised by the... Size..."
    new "نگران نباش، طبیعیه، فقط از... اندازه... شوکه شدم."

    # say L772 lis
    old "Well, this happened because your chakras are unbalanced."
    new "خب، این اتفاق بر اثر عدم تعادل چاکراتون پیش اومده."

    # say L773 pla
    old "My cha- kras?"
    new "چاکرهایم؟"

    # say L774 lis
    old "Yes, I think you need to reharmonize your chakra ‘Muladhara', this is the sexual chakra and is clearly unbalanced in you."
    new "بله، فکر می‌کنم باید چاکرت «مولادهارا» را دوباره هماهنگ کنی. این چاکر جنسی است و در تو مشخصاً ناهمبسته است."

    # say L775 lis
    old "But, don't worry, once you harmonize your chakra Muladhara, you will be more stable, and you will be able to prevent these unexpected body reactions."
    new "اما نگران نباش، وقتی چاکرت مولاذرای را هماهنگ کنی، پایدارتر خواهی شد و می‌توانی این واکنش‌های ناگهانی بدن را جلوگیری کنی."

    # say L777 lis
    old "I think you need to work on that, we can do some tantric rituals so you can restore your chakras to their natural energy."
    new "فکر می‌کنم باید روی این کار کنی، می‌تونیم چند مراسم تانتری انجام بدیم تا انرژی طبیعی چاکرتون برگرده."

    # say L778 pla
    old "A tantric what?"
    new "ریتوال‌های تانتریک چی؟"

    # say L779 lis
    old "Tantric rituals, it's a very spiritual technique where we clean your chakras. I think we should do it tonight."
    new "ریتول‌های تانتریک، این یک تکنیک خیلی روحانیه که توی اون می‌تونیم چاکرتون تمیز کنیم. فکر کنم باید امشب انجام بدیم."

    # say L780 pla
    old "T- tonight?"
    new "T- امشب؟"

    # say L781 lis
    old "Yes, I need to prepare a few things for the ritual, And you need to balance your chakras before your next yoga session with Anastasia."
    new "بله، باید چند چیز برای مراسم آماده کنم، و تو باید قبل از یوگا بعدیت با آناستازیا، چاکراتون را تعادل بدی."

    # say L782 lis
    old "We don't want you to have this kind of... Reactions with her, don't we?"
    new "ما نمی‌خوایم تو این جوری... واکنش‌ها داشته باشی، همینطور نیست؟"

    # say L783 pla
    old "Hmm... No, no, of course not... No."
    new "Hmm... نه، نه، البته نه... نه."

    # say L784 lis
    old "Ok, then I'll make the preparations for our tantric ritual."
    new "خب، پس من آماده‌سازی‌های مراسم تانتریک رو انجام می‌دم."

    # say L786 lis
    old "It was nice to practice with you today! See you later."
    new "خوشحالم که امروز با تو تمرین کردم! بی‌نهایت."

    # say L787 pla
    old "See you then."
    new "ببینم تو وقتی هم می‌آی."

    # say L806 pla
    old "Wow... W- what are you... W- wearing?"
    new "واو... ا- این لباس چ- چطور پوشیدی؟"

    # say L807 lis
    old "Oh, hi, [pla], glad to see you... These collars you see are some elements that make part of the ritual we will do tonight; they will help to keep the balance of your chakras."
    new "اوه، سلام، [pla]، خوشحالم که تو رو می‌بینم... این گردن‌بند‌ها که می‌بینی جزء عناصری هستن که در مراسمی که امشب می‌کنیم نقش دارن؛ آنها به حفظ تعادل چاکره‌هایت کمک می‌کنن."

    # say L808 lis
    old "Let's go to the room so I can explain everything to you..."
    new "بیای به اتاق تا همه چیز رو به تو توضیح بدم..."

    # say L817 lis
    old "Everything is set in this room so we can cleanse those energies and balance your chakras..."
    new "همه چیز در این اتاق آماده شده تا بتونیم این انرژی‌ها رو تمیز کنیم و چاکرتون رو تعادل بدیم..."

    # say L818 lis
    old "I hope you can take advantage of the lights, the fragrances, as well as the location, we are about to do a very important ritual, so every single detail must help us get in the mood."
    new "امیدوارم از نورها، عطرها و مکان استفاده کنی، ما در حال انجام یک مراسم بسیار مهم هستیم، پس هر جزئیت باید به ما کمک کند که حالتون رو درست درآوریم."

    # say L819 lis
    old "Please I need you to open your mind so the exercises we do tonight will be more effective..."
    new "لطفاً ذهنت رو باز کن تا تمرین‌هایی که امشب انجام می‌دیم موثرتر باشن..."

    # say L820 lis
    old "Some of the exercises of the ritual will have a lot of contact so please let the massages follow its course, it is a very spiritual process."
    new "برخی از تمرین‌های مراسم شامل تماس زیادی خواهد بود، پس لطفاً مساج‌ها را به راحتی بپذیر، این یک فرآیند روحانی بسیار مهم است."

    # say L821 pla
    old "M- massages?"
    new "م- ماساژ‌ها؟"

    # say L822 lis
    old "We need to compenetrate each other today so I can balance right your chakras."
    new "امروز باید با هم درهم‌تنی کنیم تا من بتونم چاکرات رو تعادل بدم."

    # say L824 lis
    old "I did some meditation today so the massages can be very deep and productive for you so please merge with me to have a great experience."
    new "امروز مدیتیشن کردم تا ماساژ‌ها برای تو خیلی عمیق و مفید باشند، پس لطفاً با من ادغام شو تا تجربه‌ای عالی داشته باشی."

    # say L826 lis
    old "It's a very beautiful way to perceive what surrounds you, so you need to express according to the energies that you will be able to recognize... Let's start."
    new "این روش خوبی برای درک محیط اطرافت است، پس باید بر اساس انرژی‌هایی که می‌توانی تشخیص بدی، آن را بیان کنی... بیایید شروع کنیم."

    # say L828 lis
    old "First, I need you to undress so we can uncover our energies."
    new "اول، لازم دارم تو لباست رو برداری تا بتونیم انرژی‌هامون رو آشکار کنیم."

    # say L829 pla
    old "U- undress?"
    new "خوب، خودت رو لباس برداری؟"

    # say L830 lis
    old "Yes, please don't take it the wrong way, this is a very pure experience so I need you to undress not only the clothes but also your mind and soul."
    new "بله، لطفاً اشتباه نفهم بگیر، این تجربه خیلی محض است و من نیاز دارم که نه فقط لباس‌ت رو برداری، بلکه ذهن و روحت رو هم آزاد کنی."

    # say L831 lis
    old "Keep in mind your body is something beautiful and it doesn't make you feel embarrassed, it's natural as universe is and we are going beyond to see how to control its energy."
    new "به یاد داشته باش که بدن تو چیزی زیبا است و نباید از آن خجولانه شوی، این طبیعی است مثل جهان و ما در حال بررسی چگونگی کنترل انرژی آن هستیم."

    # say L838 lis
    old "Let's keep working on our breathing, remember the pranayama, we need to concentrate so you can open your senses, that is the main purpose of this exercise today."
    new "بیایید روی تنفس ما ادامه بدیم، به یاد داشته باش پرانایاما، ما باید تمرکز کنیم تا حواست را باز کنی، این هدف اصلی این تمرین امروز است."

    # say L839 pla
    old "Hmm, sure..."
    new "Hmm، مطمئنم..."

    # say L840 lis
    old "I need you to concentrate, smell the candles, the ambience we have for this moment, do you feel the fragrance?"
    new "باید تمرکز کنی، بوی شمع‌ها را حس کن، جوی که برای این لحظه آماده کرده‌ایم، آیا بوی آن‌ها را می‌آید؟"

    # say L841 pla
    old "Yes, it smells nice."
    new "بله، خوشبو است."

    # say L842 lis
    old "Great!, now please lie down with your stomach on the floor, then relax, I will do the massage, you will feel my body helping yours to open your senses."
    new "عالی، حالا لطفاً روی زمین با شکمتو بخواب، بعد آرامش ببر، من مassage می‌کنم، حس می‌کنی بدنم به تو کمک می‌کنه تا حواس‌تو باز کنی."

    # say L851 lis
    old "let me start with your shoulders, so you can feel more."
    new "بگذار از شانه‌هایت شروع کنم، تا بیشتر حس کنی."

    # say L853 lis
    old "Please hold your breath a bit more, so we can intensify the fragrance and focus your thoughts."
    new "لطفاً نفستو کمی بیشتر بگیر، تا بوی ملایم‌تر شه و فکرت متمرکز‌تر بشه."

    # say L857 lis
    old "Good, do you feel my touch, my skin... How do you feel?"
    new "خوب، آیا لمس من، پوست من را می‌حسی... احساس چه خوبی داری؟"

    # say L858 pla
    old "It's very soft."
    new "خیلی نرم است."

    # say L859 lis
    old "That's perfect, you are doing good."
    new "عالی، خوب کار می‌کنی."

    # say L873 lis
    old "Let me touch your skin now so we can release the pressure, breath with me, it's just one pace, don't stop..."
    new "بگذار من پوست تو رو لمس کنم تا فشار رها شه، با من نفس بکش، فقط یه قدمه، متوقف نشو..."

    # say L875 lis
    old "Feel free to express and feel everything your body wants to feel at this moment, I will control everything so you can go freely wherever your mind wants."
    new "در این لحظه، هر چه بدن تو می‌خواهد را بیان و حس کن، من همه چیز را کنترل می‌کنم تا ذهن تو به جایی که می‌خواهد برود، برو."

    # say L876 lis
    old "Try harder to focus, it's just this moment, there is nothing else to think about, but the sensations, can you smell it?"
    new "سعی کن تمرکزت رو بیشتر کنی، فقط این لحظه وجود داره، هیچ چیز دیگه برای فکر کردن نیست، فقط احساسات، می‌تونی بویش رو حس کنی؟"

    # say L877 pla
    old "Yes, I can."
    new "بله، می‌تونم."

    # say L888 pla
    old "I feel amazing, I appreciate your time and effort to help me."
    new "احساسی عالی هست، ممنونم از وقت و تلاشت که به من کمک می‌کنی."

    # say L889 lis
    old "Oh no, it's no trouble, I'm just an instrument from the universe to help you with your energies."
    new "نه، هیچ اشکالی نداره، من فقط ابزاری از جهان برای کمک به تو هستم."

    # say L890 lis
    old "Just relax and please keep learning so you can apply all your knowledge to the sessions with your customers. I am sure now you won't have these issues with Anastasia."
    new "فقط آرام شو و لطفاً ادامه ده یادگیری تا بتونی همه دانشتو به جلسات با مشتریانت اعمال کنی. مطمئنم حالا این مشکلات رو با آناستازیا نداری."

    # say L891 lis
    old "I can also feel a different aura on you now, I can feel your spirit is more calmed."
    new "الان می‌تونم ارگان متفاوتی رو ازت حس کنم، می‌دونم روحت آرام‌تر شده."

    # say L892 pla
    old "Thank you for all that you have done."
    new "ممنون از همه چیزی که برای من انجام دادی."

    # say L893 lis
    old "It's something I enjoy, please have some rest."
    new "این چیزی است که لذت می‌برم ازش، لطفاً خودتو استراحت ده."

    # say L894 pla
    old "I'll do it, have a great one too."
    new "من هم اینجوری می‌کنم، خوب باشی."

    # say L895 lis
    old "Good night, [pla]."
    new "شب خوبی، [pla]."

    # say L916 lis
    old "Welcome [pla], we were waiting for you."
    new "خوش آمدی [pla]، ما منتظرت بودیم."

    # say L917 pla
    old "Hi, I am sorry if I'm late."
    new "سلام، اگه دیر شدم معذرت."

    # say L918 lis
    old "Oh don't worry, you are just on time."
    new "اوه نگران نباش، تو فقط به موقع هستی."

    # say L919 lis
    old "How do you feel today, are you ready to have the second session with Anastasia?"
    new "امروز حس خوبی داری؟ آماده‌ی جلسه‌ی دوم با آناستازیا هستی؟"

    # say L920 pla
    old "Yes, I've been thinking about it."
    new "بله، در موردش فکر کرده‌ام."

    # say L921 lis
    old "Perfect, Well guys I am glad to see you both, I know you are working hard and improving!"
    new "عالی، خوشحالم که هر دو را می‌بینم، می‌دونم سخت کار می‌کنید و پیشرفت می‌کنید!"

    # say L922 lis
    old "How about you Anastasia, how do you feel today?"
    new "آناستازیا، امروز حالت چطوره؟"

    # say L923 ana
    old "I am quite happy with my trainer because he has HUGE talent, I am prepared today. [pla], is it going to be HARDER than last time?"
    new "من خیلی خوشحالم از مربی‌ام، چون توانایی‌های بزرگی داره، امروز آماده هستم. [pla]، این بار سخت‌تر می‌شه؟"

    # say L925 pla
    old "I- I'm sure this is going to... to be a good session."
    new "من- من مطمئن هستم این جلسه... جلسه خوبی می‌شه."

    # say L926 lis
    old "Perfect, I will leave you guys alone so you can do the session with no inconveniences. I will be here to give you proper privacy."
    new "عالی، من شما رو تنهایی می‌ذارم تا جلسه‌تون بدون هیچ اشکالی انجام بشه. من اینجا خواهم بود تا به شما حفظ حریم خصوصی بدم."

    # say L927 lis
    old "The room is already prepared."
    new "اتاق قبلاً آماده شده."

    # say L929 lis
    old "Anastasia I hope you enjoy your session you will be in good hands."
    new "آناستازیا، امیدوارم جلسه‌ت رو لذت‌بخش بگذاری، تو در دست‌های خوبی هستی."

    # say L931 ana
    old "Yes, I'm pretty sure he's really good with his hands, I'll enjoy the session."
    new "بله، احتمالاً او با دست‌هایش خوبه، جلسه‌ام لذت‌بخش خواهد بود."

    # say L932 lis
    old "Aww, I love that energy, please work hard... See you guys."
    new "اوه، من این انرژی رو دوست دارم، لطفاً سخت کار کنید... ببینیم چطور می‌شه."

    # say L933 pla
    old "... See you."
    new "ببینم."

    # say L947 pla
    old "Well, Today we will continue the meditation process, remem-"
    new "خب، امروز ما ادامه مراحل مدیتیشن رو خواهیم داد، به خاطر داشته باش-"

    # say L948 ana
    old "I wanted to- sorry to interrupt you..."
    new "می‌خواستم- معذرت که قطع تو کردم..."

    # say L949 pla
    old "Oh, it's ok, tell me."
    new "اوه، برات مشکلی نیست، بگو."

    # say L950 ana
    old "It is just that... I wanted to try something different today, you know."
    new "این فقط اینه... می‌خواستم امروز چیزی جدید امتحان کنم، می‌دونی."

    # say L951 pla
    old "Hmm... What did you have in mind?"
    new "Hmm... چی به ذهنت رسید؟"

    # say L952 ana
    old "Well being honest, I was kind of distracted, I was not able to forget about your cock... And I want you to fuck me with that big hard cock."
    new "البته صادقانه، من یه کم پرتلاش بودم، نتونستم از نوکت فراموش شم... و می‌خوام تو با اون نوک بزرگ و سختت باهام جنس کنی."

    # say L953 pla
    old "(WHAT THE FUCK!)"
    new "وای، این چه خبریه!"

    # say L954 pla
    old "WHAT? B- but, we need to have a yoga session..."
    new "چه؟ ب- بله، اما ما باید جلسه یوگا داشته باشیم..."

    # say L955 ana
    old "The truth is I am very horny today, I came considering to have sex with you..."
    new "حقیقت اینه که امروز خیلی خواسته‌ی جنسی دارم، فکر کردم بیام جنس با تو بکنم..."

    # say L961 ana
    old "Oh, it seems like you're getting ready... Why don't you get these pants off?"
    new "اوه، به نظر می‌رسه آماده شده‌ای... چرا این شلوارها رو بر نداشته‌ای؟"

    # say L962 pla
    old "I- it's not-"
    new "من- من نیستم-"

    # say L963 ana
    old "Don't be shy, I know both of us will feel very good after that, I am just a bit thirsty, can I get a taste?"
    new "نرم باش، می‌دونم هر دو ما بعد از اون خیلی خوب می‌تونیم بیوفتیم، فقط یه کم عطش دارم، می‌تونم یه ذره طعم ببرم؟"

    # say L973 ana
    old "Oh, yeah, this is what I'm talking about..."
    new "اوه، بله، همین هست که من بهش اشاره می‌کنم..."

    # say L987 ana
    old "That was delicious, but now I want you to fuck me!"
    new "این خوشمزه بود، اما حالا می‌خوام تو باهام بزنی!"

    # say L988 pla
    old "W- what? Oh, no Lisa is downstairs she could-"
    new "و- وای، نه لیزا پایین هست، ممکنه-"

    # say L989 ana
    old "Maybe you need a bit of motivation... You want to see them again, don't you?"
    new "شاید نیاز به تشویقی داری... می‌خوای دوباره ببینی، هست؟"

    # say L1002 ana
    old "Now, let's fuck!"
    new "الان، بیای بزنیم!"

    # say L1015 ana
    old "You were amazing, I loved this session, I need this kind of session more often."
    new "تو عالی بودی، این جلسه رو خیلی دوست داشتم، این جور جلسه رو بیشتر هم می‌خوام."

    # say L1017 ana
    old "I can keep this a secret if you are afraid of your boss, she doesn't need to know our particular sessions, besides she doesn't have the big talent you have."
    new "من می‌تونم اینو جمع کنم اگه از رئیستنت متحیری هستی، او نباید بدونه جلسات خاصمون، علاوه بر اون، او تالنت بزرگی مثل تو نداره."

    # say L1018 ana
    old "I am considering you can get a tip later, for your hard work..."
    new "من فکر می‌کنم بتونی بعداً هدیه‌ای بگیری برای تلاشت..."

    # say L1019 pla
    old "... I- I think we shouldn't-"
    new "... من- من فکر می‌کنم نباید-"

    # say L1020 ana
    old "Do not worry honey, this was your best yoga session ever."
    new "نگران نباش عزیزم، این بهترین جلسه یوگا تو بود."

    # say L1032 lis
    old "Hi guys, congratulations I can see you are sweating, that means you had a very hard job today."
    new "سلام جون‌ها، تبریک می‌گم، می‌بینم عرق می‌ریزید، این به معنای اینه که امروز کار سختی داشتید."

    # say L1033 ana
    old "Yes, [pla] took a lot out of me today."
    new "بله، [pla] خیلی از من برداشت."

    # say L1035 lis
    old "He is improving every day; I can tell you he's putting in a big effort."
    new "او هر روز بهتر می‌شه؛ می‌تونم بگم تلاش زیادی می‌کنه."

    # say L1036 ana
    old "I can see that, I hope we can meet again later, the sooner the better."
    new "این رو می‌بینم، امیدوارم بتوانیم بعداً هم دوباره بیوفتم، هر چه زودتر بهتر است."

    # say L1037 lis
    old "Oh sure, I have your appointment already set. Don't worry, we will be waiting for you."
    new "البته، قرار ملاقاتت قرار هست. نگران نباش، منتظرت هستیم."

    # say L1038 ana
    old "Perfect, thank you for the session today... And thank you very much for your hard, hard work [pla], I really enjoy it."
    new "عالی، ممنون از جلسه امروز... و ممنون از تلاش‌های سختت [pla]، واقعاً لذت بردم."

    # say L1042 lis
    old "Bye Anastasia, have a great day!"
    new "بای آناستازیا، روز خوبی داشته باش!"

    # say L1052 lis
    old "I am very satisfied with your job, I wanted you to know that I am considering to introduce you to other customers, I think you are so easy going, that people will just connect with you."
    new "خوشحالم از کارتو، می‌خواستم بدونی که فکر می‌کنم برای مشتریان دیگه هم تو رو معرفی کنم، فکر می‌کنم انسان‌ها خیلی راحت با تو هم‌آهنگ می‌شوند."

    # say L1053 pla
    old "O- other customers, I- I don't know-"
    new "دیگر مشتریان، من- من نمی‌دونم-"

    # say L1054 lis
    old "You can help other people, your energy will just bring you what you need, you only need to keep on working hard..."
    new "تو می‌تونی به افراد دیگه کمک کنی، انرژیت هم خودت رو به جایی می‌بره که نیاز داری، فقط باید سخت کار باشی..."

    # say L1055 pla
    old "Hmm if you say so..."
    new "اگه می‌گی برات، خب..."

    # say L1056 lis
    old "Oh, by the way, remember we will have tomorrow a new ritual, the tantric massages need to be continued so we can balance your chakras."
    new "البته، به یاد داشته باش که فردا مراسم جدیدی خواهیم داشت، ماساژ‌های تانتری باید ادامه پیدا کنند تا چاکرهایت متوازن شوند."

    # say L1058 lis
    old "Amazing, thank you for today, please get some rest."
    new "عالی، ممنون از امروز، لطفاً خوب بخواب."

    # say L1059 lis
    old "See you later [pla]!"
    new "bebem بعداً [pla]!"

    # say L1078 lis
    old "Hi [pla], nice to see you again!"
    new "سلام [pla]، خوشحالم که دوباره دیدمت."

    # say L1079 pla
    old "Hello, Thank you."
    new "سلام، ممنون."

    # say L1080 lis
    old "I am very happy because you are very committed with this extra training."
    new "خوشحالم زیرا تو خیلی متعهد به این آموزش اضافی هستی."

    # say L1081 pla
    old "I appreciate you are taking the time to teach me."
    new "من قدردانی می‌کنم وقت خودت رو صرف آموزش من می‌کنی."

    # say L1082 lis
    old "Any time, you are helping a lot with my business, I will do my best so you can be as good as me."
    new "هر زمانی، تو خیلی به کسب و کار من کمک می‌کنی، من تلاش خواهم کرد تا همانقدر خوب باشی که من هستم."

    # say L1083 pla
    old "Hmm, that is very nice of you."
    new "Hmm، خیلی لطف داری."

    # say L1084 lis
    old "Let's go to the room so we can start the tantric session."
    new "بیای به اتاق برویم تا جلسه تانترا رو شروع کنیم."

    # say L1092 lis
    old "Have you seen any improvement thanks to last session?"
    new "آیا از آخرین جلسه بهبودی دیدی؟"

    # say L1093 pla
    old "Yes... I can feel in a better mood."
    new "بله... حس می‌کنم خوشحال‌تر شدم."

    # say L1094 lis
    old "Good, you will see better results."
    new "خوب، نتایج بهتری خواهی دید."

    # say L1095 lis
    old "Today we need to improve a lot because you need to be able to balance your chakra muladhara as soon as possible, that way you can offer a more delightful experience."
    new "امروز باید خیلی پیشرفت کنیم زیرا تو باید بتونی چاکرا مولاذرارا به سرعت تعادل بدی، اینجوری می‌تونی تجربه‌ای لذت‌بخش‌تر ارائه بدی."

    # say L1096 lis
    old "Please get comfortable, you know we need to open our mind, just relax because this is not any casual meeting, your body is more than flesh, blood and energy..."
    new "لطفاً راحت شو، می‌دونی باید ذهنمون رو باز کنیم، فقط آرام باش چون این هیچ ملاقات عادی‌ای نیست، بدن تو بیشتر از لحم و خون و انرژی است..."

    # say L1097 lis
    old "So, there's nothing to feel shy about, please undress."
    new "پس، هیچ دلیلی برای خجولی نیست، لطفاً لباس‌ت را بگشای."

    # say L1103 lis
    old "Perfect, so today we need to increase the perception of our senses, you must feel more, once you connect your sexual chakra, we will start with the massage."
    new "عالی، امروز باید احساساتمان رو بیشتر تجربه کنیم، باید بیشتر حس کنی، وقتی چاکرا جنسیتی خودت رو متصل می‌کنی، ما با ماساژ شروع می‌کنیم."

    # say L1104 lis
    old "The idea is to recognize some feelings that only you can see, some situations that are deep inside, no one will be able to get there... Do not forget to feel the energy..."
    new "هدف این است که برخی احساساتی را که فقط تو می‌توانی ببینی، برخی موقعیت‌هایی که عمیق درون تو هستند، بشناسی، هیچ‌کس نمی‌تواند به آنجا برسد... فراموش نکن که انرژی را حس کنی..."

    # say L1112 lis
    old "While feeling my body on your skin please bring that healing energy in and allow it to wash through your body and mind."
    new "در حالی که احساس بدن من روی پوست تو هست، لطفاً آن انرژی شفا دهنده را درون خودت بیاور و بگذار از بدن و ذهن تو عبور کند."

    # say L1114 lis
    old "Let your skin merge with mine, feel my fragrance, connect your senses with mine."
    new "پوستت رو با پوستم ترکیب کن، عطرم رو حس کن، حواستو با حواس من هم‌پیوند کن."

    # say L1124 pla
    old "So, are you going to use your hands like last time?"
    new "پس، این بار مثل آخر دست‌هات رو استفاده می‌کنی؟"

    # say L1125 lis
    old "No, we need to do better than last time, this time I want you to be able to experience a more intense moment, so I think my breast is going to be perfect."
    new "نه، باید این بار بهتر از قبل باشیم، من می‌خوام تا بتونی لحظه‌ای شدید‌تر تجربه کنی، پس فکر می‌کنم سینه‌ام خوب باشه."

    # say L1126 pla
    old "Y- your breast? ..."
    new "Y- سینه‌ات؟..."

    # say L1127 lis
    old "Yes, remember this is not a sexual act, this a spiritual ritual to connect together and cleanse your chakras."
    new "بله، به یاد داشته باش این عمل جنسی نیست، این یک مراسم روحانی برای همپیوند و تمیز کردن چاکره‌هایت است."

    # say L1128 lis
    old "Don't get distracted, keep focused so we can do the session and control your breathing."
    new "دستت از پرتلاش نبری، تمرکز کن تا بتونیم جلسه رو انجام بدیم و تنفست رو کنترل کنی."

    # say L1129 pla
    old "... O- ok."
    new "ب-له."

    # say L1137 lis
    old "Just relax your body it is a part of the universe, where I can move freely and that way we can take it out..."
    new "فقط بدنت رو آرامش بده، این بخشی از جهان است که من می‌تونم آزاد حرکت کنم و اینجوری می‌تونیم آن رو بیرون ببریم..."

    # say L1146 lis
    old "I can see your energy is more stable now, I am really proud of the effort you are putting in."
    new "می‌تونم ببینم انرژیت الان پایدار‌تر شده، واقعاً از تلاشت خوشحالم."

    # say L1147 lis
    old "I think we have just one lesson left, according to the progress I have seen, this chakra muladhara is not so strong now, you are getting the balance you need."
    new "فکر می‌کنم فقط یک جلسه دیگه داریم، بر اساس پیشرفتی که دیدم، این چاکرا مولادهارا خیلی قوی نیست الان، تو در حال یافتن تعادل لازم هستی."

    # say L1148 lis
    old "There are still more things to learn, see you next time, you need to get some rest, don't forget tomorrow's lesson with Anastasia."
    new "هنوز چیزهای بیشتری برای یادگیری داری، دوباره می‌بینم، باید خودت را استراحت بدی، فراموش نکن درس فردا با آناستازیا."

    # say L1149 pla
    old "Sure, I'll be here... Thank you, bye."
    new "بله، من اینجا خواهم بود... ممنون، خداحافظ."

    # say L1169 lis
    old "Hi Anastasia, welcome to your yoga session once again, I hope you are ready for the routine today."
    new "سلام آناستازیا، خوشحالم که دوباره به جلسه یوگا خودت رسیدی، امیدوارم برای روتین امروز آماده باشی."

    # say L1170 ana
    old "Hi Lisa, you are right I came prepared, this time I want to give my best and I hope [pla] brings a harder... Activity today."
    new "سلام لیسا، درست می‌فرمایی، آماده‌ام این بار بهترین را ارائه بدم و امیدوارم ز[pla] فعالیت سخت‌تری برای ما در نظر داشته باشد."

    # say L1177 pla
    old "Hi... Am I late?"
    new "سلام... من دیر نیومدم؟"

    # say L1179 lis
    old "Oh no, it's perfect timing, Anastasia was telling me she came prepared today..."
    new "نه، وقت خوبی هست، آناستازیا به من می‌گفت که امروز آماده آمده..."

    # say L1180 lis
    old "I am very happy that your training has become something personal, it means that you guys are feeling connected through these exercises."
    new "خوشحالم که آموزش‌تون به چیزی شخصی تبدیل شده، این به معنای اینه که شماها از طریق این تمرین‌ها به هم متصل شدن."

    # say L1181 lis
    old "I am so proud that you guys are improving together, I will leave you alone so you can do your routine, in case you need me, please let me know."
    new "خوشحالم که شما دو تا همراه هر روز بهتر می‌شوید، من از راه می‌روم تا بتونید روتین خودتون رو انجام بدید، اگر به من نیاز داشتید، لطفاً بهم بگید."

    # say L1182 pla
    old "Sure, I will let you know in case we need you, let's go to the room to start the lesson."
    new "بله، اگر نیاز داشتیم ازت خبر می‌دهم، برویم به اتاق برای شروع درس."

    # say L1190 pla
    old "Well, we have a very-"
    new "خب، ما خیلی-"

    # say L1191 ana
    old "I needed this urgently, so let's get straight to it..."
    new "این رو فوری نیاز داشتم، پس بیای بلافاصله شروع کنیم..."

    # say L1212 ana
    old "I want MORE! I want you to be rude... Fuck me harder PLEASE!"
    new "بیشتر می‌خوام! می‌خوام خشن باشی... سخت‌تر با من بکن لطفاً!"

    # say L1226 ana
    old "Oh, you've accomplished it, this was by far better than last time."
    new "اوه، تو این رو انجام دادی، این بار خیلی بهتر از بار قبل بود."

    # say L1227 ana
    old "Could you make it better next time? I wanna see that!"
    new "آیا می‌تونی بعدی رو بهتر کنی؟ من می‌خوام ببینم!"

    # say L1228 pla
    old "N- next time?"
    new "N- بعداً؟"

    # say L1229 ana
    old "I am really happy for every penny I have spent here; I will speak highly of you with some friends, they will love you..."
    new "من واقعاً خوشحالم که هر سنتی رو اینجا صرف کردم؛ من با برخی دوستانم در موردت صحبت خواهم کرد، آنها هم دوستت خواهند داشت..."

    # say L1231 ana
    old "Alright, thanks for everything it's time to go."
    new "البته، ممنون از همه چیز، الان وقت برای رفتن است."

    # say L1241 pla
    old "Oh Lisa, h- how are you?"
    new "اوه لیزا، ه- چطوری؟"

    # say L1242 lis
    old "I can see the 'Lesson' has finished."
    new "می‌تونم ببینم درس تمام شده."

    # say L1247 lis
    old "I want to congratulate you guys for the effort you are doing on every lesson, I can see every time is better, did you like it Anastasia."
    new "می‌خوام تون رو برای تلاشی که تو هر جلسه می‌کنید تبریک بگم، هر بار بهتر می‌شه، آناستازیا، خوشت اومده؟"

    # say L1248 ana
    old "It was the best session ever; I am considering opening my schedule so we can make my sessions more frequent."
    new "این جلسه عالی‌ترین جلسه بود؛ فکر می‌کنم برنامه‌ی من رو باز کنم تا جلسات من مداوم‌تر شوند."

    # say L1249 lis
    old "Of course we could discuss it later, you can have as many sessions as you need..."
    new "البته می‌تونیم بعداً در موردش صحبت کنیم، می‌تونی هر تعداد جلسه‌ای که نیاز داری داشته باشی..."

    # say L1250 ana
    old "Fascinating! Next meeting we will check that."
    new "عالی است! در جلسه بعد این موضوع را بررسی خواهیم کرد."

    # say L1251 lis
    old "Hope you get some rest Anastasia, see you on next appointment."
    new "امیدوارم خوب بخوابی آناستازیا، تا ملاقات بعدی مون."

    # say L1252 ana
    old "Oh thank you, I will, see you next time."
    new "البته، ممنونم، تا زمانی دیگر."

    # say L1253 ana
    old "Everything was amazing, thank you [pla]."
    new "همه چیز عالی بود، ممنون [pla]."

    # say L1254 pla
    old "No problem, see you next session."
    new "هیچ اشکالی، تا جلسه بعد."

    # say L1263 lis
    old "Are you leaving too?"
    new "تو هم می‌روی؟"

    # say L1264 pla
    old "I guess so... ?"
    new "باید من هم بروم...؟"

    # say L1265 lis
    old "I need to talk to you about something before you leave."
    new "من باید قبل از رفتن تو با تو صحبت کنم."

    # say L1266 pla
    old "Hmm, sure... What is it?"
    new "Hmm، حتما... چیه؟"

    # say L1267 lis
    old "I think it's not acceptable... I know you are not doing the routine we have been preparing..."
    new "من فکر می‌کنم قابل قبول نیست... می‌دونم تو روتینی که ما آماده کردیم رو انجام ندادی..."

    # say L1269 lis
    old "I assume the previous routines were not done either, am I right?"
    new "فکر کنم روتین‌های قبلی هم انجام نشده‌اند، درست می‌گم؟"

    # say L1270 pla
    old "(Oh shit... Did she noticed we were having SEX)"
    new "اوه شیطون... آیا تو متوجه شدی ما جنس می‌کردیم؟"

    # say L1271 pla
    old "W- what are you... T- talking about?"
    new "W- چه چیزی... T- در می‌آیی؟"

    # say L1272 lis
    old "Do not try to hide it, do you think I didn't hear her moaning?"
    new "پوشاندن نکن، فکر می‌کنی من صدای آوازهایش رو نشنیدم؟"

    # say L1273 pla
    old "I- I don't know what-"
    new "من نمی‌دونم چه چیزی..."

    # say L1274 lis
    old "[pla], I heard what you were doing, and I can swear, it was not a yoga routine, you both were having sex!"
    new "[pla]، صدای او رو شنیدم و می‌تونم قسم بدم، این یوگا نبود، هر دو جنسیتی داشتید!"

    # say L1275 pla
    old "(Oh God, she's going to kill me.)"
    new "اوه خدا، او من رو می‌خواهد بکشد."

    # say L1276 pla
    old "I- I am very sorry, it wasn't my inte-"
    new "من- من خیلی متاسفم، این جوری برنیا-"

    # say L1277 lis
    old "Do you know what really pisses me off?"
    new "می‌دونی چیون خیلی به من اذیت می‌کنه؟"

    # say L1279 lis
    old "I mean I don't care if you are having sex or not, you can connect with anybody and share your energy, sex is beautiful and good way to connect together."
    new "من قصد ندارم که اگه جنس می‌کنی یا نه، مال من باشه. می‌تونی با هر کسی ارتباط برقرار کنی و انرژیت رو باشون به اشتراک بذاری، جنس زیبا و راه خوبی برای هم‌پوشانی هست."

    # say L1280 lis
    old "But you should be applying the meditation and yoga experience with the client. This is not what I'm selling..."
    new "ولی باید تجربه مدیتیشن و یوگا رو با مشتری اعمال کنی. این همچین چیزی نیست که من به فروش می‌ذارم..."

    # say L1281 pla
    old "I'm so sorry..."
    new "من خیلی متاسفم..."

    # say L1282 lis
    old "[pla], I think you have too many things to learn still, in this process... If someone is really learning to connect his body and soul, it means we are doing the process fine..."
    new "[pla]، فکر می‌کنم هنوز چیزهای زیادی برای یادگیری در این فرآیند داری... اگر کسی واقعاً در حال یادگیری اتصال بدن و روح خود است، بدان معناست که ما فرآیند را درست انجام می‌دهیم..."

    # say L1283 lis
    old "Anastasia is not doing it, she has been distracted, I mean my academy is not about other things different from the energy, meditation and yoga..."
    new "آناستازیا این کار رو نمی‌کنه، خیال‌پردازی کرده، منظورم اینه که آکادمی من درباره چیزهایی غیر از انرژی، مدیتیشن و یوگا نیست..."

    # say L1284 lis
    old "She is not getting that here. I'm not doing this for money or business, it's about fate and helping others to connect with the universe."
    new "او اینجا اینو نمی‌گیره. من این رو برای پول یا کسب و کار نمی‌کنم، این درباره تقدیر و کمک به دیگران برای اتصال با جهان هست."

    # say L1285 lis
    old "Can you understand what I am saying?"
    new "می‌تونی اینا رو بفهمی؟"

    # say L1287 pla
    old "I apologize if I disappointed you, I know you probably don't want me to be here anymore, I understand, just let me tell you it wasn't on purpose."
    new "متأسفم اگر ناامید کردم، می‌دونم شاید دیگه نمی‌خوای همینجا باشم، متوجه می‌شوم، فقط بگم که این به طور عمد نبود."

    # say L1288 lis
    old "What are you talking about? I do want you to be here."
    new "تو درباره چی حرف می‌زنی؟ من می‌خوام تو اینجا باشی."

    # say L1289 pla
    old "(Wait, what? Is she upset or not)"
    new "بی‌خیال، چی؟ آره خیالتو می‌رسه یا نه؟"

    # say L1290 lis
    old "I just need you to help me by doing the things right, I thought that you were learning with the sessions you are doing with me, am I wasting my time?"
    new "من فقط نیاز دارم که تو با انجام کارها به درستی به من کمک کنی، فکر کردم تو با جلساتی که با من داری انجام میداد، یاد می‌گرفتی، آیا وقت من رو ضایع می‌کنی؟"

    # say L1291 pla
    old "... No, of course not, I'm sorry..."
    new "نه، البته نه، من عذرخواهم..."

    # say L1292 lis
    old "I mean, you already know about this, you started a process, you should apply it to every activity you perform in your life... Even if it is sex... Yoga is deeply connected with sex."
    new "من قصد دارم بگم تو از قبل در مورد این مسائل آگاهی داری، فرآیندی شروع کردی و باید این دانش رو به همه فعالیت‌های زندگیت اعمال کنی... حتی اگر فعالیت جنسی باشه... یوگا با جنسیت عمیقاً پیوند داره."

    # say L1293 lis
    old "We definitely need to discuss this more... Wait a minute..."
    new "حتماً باید بیشتر در این مورد صحبت کنیم... یه لحظه صبر کن."

    # say L1295 lis
    old "I think... That could work! if she is into you because of the sex, you guys can actually do a great job if you apply the yoga knowledge to the sex experience..."
    new "من فکر می‌کنم... می‌تونه خوب باشه! اگه او به خاطر جنس با تو علاقه‌مند باشه، شما دو تا می‌تونید با استفاده از دانش یوگا، تجربه جنس رو خیلی بهتر کنید..."

    # say L1297 lis
    old "Actually if she is interested in you because of the sex, the yoga can make that experience richer than you both can imagine, she won't ever let you go."
    new "در واقع اگر او به خاطر جنس علاقه‌مند به تو باشه، یوگا می‌تونه اون تجربه رو غنی‌تر از آنچه هر دو می‌تونید تصور کنید بیاره، او هیچ وقت تو رو نمی‌ذاره بری."

    # say L1298 lis
    old "[pla], I need you to get ready, tomorrow you will have the most important lesson of your life, I'll wait for you, I will get ready too, to teach you very well."
    new "[pla]، باید آماده شی، فردا درس مهم‌ترین زندگیت رو خواهی داشت، منتظرت می‌مونم، من هم آماده می‌شوم تا بهت خوب یاد بدم."

    # say L1299 pla
    old "Hmm... O- ok?"
    new "Hmm... او- اوه؟"

    # say L1302 pla
    old "(I don't get it, but I feel better to knowing she is not as mad as I thought she would be.)"
    new "فکر کنم نمی‌فهمم، اما خوشحالم که معلومه تو هیچقدر به اندازه‌ی آنچه فکر می‌کردم غصب نیستی."

    # say L1320 lis
    old "Hi, I am glad you came."
    new "سلام، خوشحالم که اومدی."

    # say L1321 pla
    old "Hello, thanks for this new opportunity."
    new "سلام، ممنون از این فرصت جدید."

    # say L1322 lis
    old "I didn't mean to be mad at you yesterday, it's just that... This is very important for me,  this is my destiny..."
    new "من قصد نداشتم دیروز به تو خشمگین باشم، فقط اینکه... این برای من بسیار مهم است، این مقصد من است..."

    # say L1323 pla
    old "I... Understand..."
    new "من... متوجه شدم..."

    # say L1324 lis
    old "That's not important... Not anymore, it was a new opportunity, the universe showed me there are different ways to reach the goal I am pursuing."
    new "این مهم نیست... نه الان، این یه فرصت جدید بود، جهان به من نشون داد راه‌های مختلفی برای رسیدن به هدفم وجود داره."

    # say L1325 lis
    old "Let's go to the room."
    new "بیای به اتاق."

    # say L1334 lis
    old "You see, Yoga is like a language, it helps you to understand the world and its people, we are all energy and love, that is why we need to balance our spirit so we can merge..."
    new "دیدی، یوگا مثل یک زبانه، به تو کمک می‌کنه تا جهان و انسان‌ها رو بهتر بفهمی، ما همه انرژی و عشقیم، برای همین باید روحمون رو تعادل بدیم تا بتونیم با هم ادغام شیم..."

    # say L1335 lis
    old "That's why it is not weird that you can connect with another person so easily, that your bodies want to share their energies and eventually become one..."
    new "به همین خاطر عجیب نیست که بتونی به راحتی با انسان دیگری ارتباط برقرار کنی، که بدن‌هایت بخواهند انرژی‌هایشون رو با هم به اشتراک بذارن و در نهایت یکی شن."

    # say L1337 lis
    old "I meant what I told you, you started the process, you should apply it on every activities you perform in your life... Even if it's sex...."
    new "من جدی بودم، تو این فرآیند رو شروع کردی، باید همه فعالیت‌های زندگیت رو با این رویکرد انجام بدی... حتی اگه جنس باشه..."

    # say L1338 lis
    old "That's why I decided to prepare this lesson, it's really important because this way you will realize how everything is connected by energies."
    new "به همین خاطر تصمیم گرفتم این درس رو آماده کنم، خیلی مهمه چون اینجور می‌فهمی همه چیز با انرژی‌ها به هم متصله."

    # say L1339 lis
    old "You see, if you do some research you will find a very big part of yoga focuses on postures, you can find them according to your body type, the benefits it can give..."
    new "دیدی، اگر تحقیق کنی می‌بینی بخش زیادی از یوگا روی وضعیت‌های بدنی تمرکز داره، می‌تونی بر اساس ساختار بدنت اونا رو پیدا کنی، مزایایی که می‌دهن..."

    # say L1340 lis
    old "I have a complete library if you want, but if I asked you 'what is sex about' what would you say?"
    new "من یک کتابخانه کامل دارم اگر می‌خوای، ولی اگر از تو بپرسم «جنس چیه؟» چی می‌گی؟"

    # say L1341 pla
    old "I think... Positions?"
    new "من فکر می‌کنم... وضعیت‌ها؟"

    # say L1342 lis
    old "That's what everyone gets wrong... sex is bigger than the position you choose, as is Yoga, bigger than a posture to meditate or meditation its itself."
    new "این همچین چیزیه که همه اشتباه می‌کنن... سکس بزرگتر از وضعیتیه که انتخاب می‌کنی، مثل یوگا که بزرگتر از یک وضعیت برای مeditation یا خود meditation است."

    # say L1343 lis
    old "However both have that in common, the posture, so this is how you are going to apply all the yoga knowledge you have on this important activity..."
    new "البته هر دو این مشترکی دارند، پوزیشن، پس اینجاست که شما تمام دانش یوگا‌ی خود را در این فعالیت مهم به کار می‌برید..."

    # say L1344 lis
    old "Let's start."
    new "بیاین شروع کنیم."

    # say L1348 pla
    old "Wait, what are you doing?"
    new "منتظر بقیه‌ی کارتو بودم، اما الان چی می‌کنی؟"

    # say L1349 lis
    old "What do you think I'm doing? We are here to learn about Yoga and sex, to see how they are meant to be... So you should get naked too..."
    new "فکر می‌کنی من چیکار می‌کنم؟ ما اینجا هستیم تا درباره یوگا و سکس یاد بگیریم، ببینیم چطور باید با هم باشند... پس تو هم باید خالی شی..."

    # say L1350 pla
    old "... Alright."
    new "... خوب."

    # say L1355 lis
    old "Now, let's start properly. I will lie down but I need you to get on your knees and hold my legs... Please relax yourself so you can feel it too."
    new "الان، بیایم درست شروع کنیم. من روی زمین می‌لیgam اما نیاز دارم تو روی زانوهات نشینی و پای من رو بگیری... لطفاً خودت را آرام کن تا هم تو احساس کنی."

    # say L1366 lis
    old "Excellent, this is very interesting position, Do you like it?"
    new "عالی، این موقعیت خیلی جالب است، آیا می‌پسندی؟"

    # say L1367 pla
    old "... Yes."
    new "بله."

    # say L1368 lis
    old "This is a very intimate way to share your energy, as you could see, it was quite demanding but very rewarding."
    new "این روش خیلی شخصی برای اشتراک انرژیتونه، همچون دیدی، خیلی درخواست‌بر بود ولی خیلی پاداش‌ده."

    # say L1369 lis
    old "So, let's start, move your hips and let me suck your penis."
    new "پس، بیا حوضه‌ات رو حرکت بده و بگذار من نوزه‌ت رو بکشم."

    # say L1370 pla
    old "(Oh god, yes!)"
    new "اوه خدا، بله!"

    # say L1372 lis
    old "I know, maybe this position is not going to be the very first option to propose, but you will estimate the proper moment to help a client..."
    new "می‌دونم، شاید این وضعیت اولین گزینه پیشنهادی نباشه، ولی تو باید لحظه مناسب رو برای کمک به مشتری تشخیص بدی..."

    # say L1373 lis
    old "I hope you can start to tell apart sex and a real connection with a person thru Yoga?"
    new "امیدوارم بتونی تفاوت جنس و ارتباط واقعی رو در یوگا تشخیص بدی."

    # say L1387 lis
    old "Do realize how much energy you let out by using the proper technique? I mean using these yoga positions in some sexual practices?"
    new "می‌فهمی چقدر انرژی با استفاده از تکنیک صحیح رها می‌کنی؟ منظورم اینه که از این وضعیت‌های یوگا در برخی عملکرد‌های جنسی استفاده کنی؟"

    # say L1389 lis
    old "I'm glad you can realize how different it is."
    new "خوشحالم که متوجه شدی چقدر متفاوت هست."

    # say L1390 lis
    old "Now, let's try another option, this can be easier for any of your customers but a bit more demanding for you, however I know you can do it."
    new "الان، بیایید گزینه‌ی دیگری رو امتحان کنیم، این برای هر یک از مشتری‌هایت می‌تونه آسون‌تر باشه اما برای تو کمی بیشتر تلاش می‌خواد، ولی من میدونم که می‌تونی انجام بدی."

    # say L1392 lis
    old "This position implies a lot more effort on your end, even though your partner may be experienced, almost the other person's weight will rely on your body."
    new "این وضعیت خیلی تلاش بیشتری از تو می‌طلبد، حتی اگر همسرت تجربه داشته باشد، وزن تقریباً تمام شخص دیگر روی بدن تو خواهد بود."

    # say L1393 lis
    old "There are different conditions that can make it easier or not, however I think, Anastasia, will need more of your assistance because of her height."
    new "شرایط مختلفی وجود داره که می‌تونه این کار رو آسون‌تر یا سخت‌تر بیاره، ولی فکر می‌کنم آناستازیا به خاطر قدش نیاز به کمک بیشتری ازت داره."

    # say L1394 lis
    old "This time, I will hold my right leg up, and support a bit on my arms, I will need you to help me keep my balance and also to guide the entire movement, follow your intuition."
    new "این بار، پای راستم رو بالا می‌برم و کمی روی دستام ارتباط دارم، باید تو به من کمک کنی تا تعادل بگیرم و همچنین حرکت کل رو هدایت کنی، بر اساس حدس خودت عمل کن."

    # say L1407 lis
    old "Wow, that was quite good, I'm exhausting, how did you feel?"
    new "واو، این خوب بود، من خسته‌ام، تو چطور احساس کردی؟"

    # say L1408 pla
    old "It was... Quite interesting."
    new "بود... خیلی جالب."

    # say L1409 lis
    old "Right? I felt so much of me and you at the same time, it was like embracing life, I can see your progress, how calm you can perform and still communicate."
    new "درسته؟ من هم احساسش کردم، مثل اینکه ما دو تا با هم درگیر شدیم، مثل آغوش دادن به زندگی بود، پیشرفتت رو می‌بینم، چقدر آرام و همچنان ارتباط برقرار می‌کنی."

    # say L1410 lis
    old "The tantric massages gave you an impressive control over your chakras, you looked more than focused."
    new "مساژ‌های تانتریک به تو کنترل شگفت‌انگیزی بر چاکرهایت داد، به نظر می‌رسید بیش از حد متمرکز باشی."

    # say L1411 lis
    old "Remember this is a training, from now on, you must use these positions, actually, try it in the next session, do it at the end of the session you have been doing."
    new "به خاطر داشت، این یک تمرینه، از حالا به بعد باید این وضعیت‌ها رو استفاده کنی، در واقع، توی جلسه بعدی امتحانش کن، اون هم در آخر جلسه‌ای که داشتی."

    # say L1412 lis
    old "Try to introduce it carefully so she can receive it positively, and the results can be more productive."
    new "با دقت معرفیش کن تا مثبت بپذیره و نتایج بهتر باشه."

    # say L1413 pla
    old "(Is she really asking me to do that)"
    new "می‌خواهه واقعاً از من بخواهم این کار رو بکنم؟"

    # say L1415 lis
    old "Yes, That way she will not only enjoy your lesson but also learn what she wanted to."
    new "بله، اینجوری او نه تنها از درستو لذت می‌بره بلکه آموزشی هم که می‌خواست رو یاد می‌گیره."

    # say L1417 lis
    old "Please, be on time tomorrow!"
    new "لطفاً فردا به موقع بیا!"

    # say L1418 pla
    old "Not a problem! See you then."
    new "نه مشکلی! تا وقت اونجوری."

    # say L1439 ana
    old "So, how are you today?"
    new "پس، امروز چطوری؟"

    # say L1440 lis
    old "I am very well, thanks for asking, it's nice to see you again."
    new "من خیلی خوب هستم، ممنون از سؤالت، خوشحالم دوباره تو رو دیدم."

    # say L1441 ana
    old "Thank you, I came today with my best mood..."
    new "ممنون، امروز با بهترین خودم آمدم..."

    # say L1442 lis
    old "That's terrific, I am sure today's lesson will change your perception of the previous ones, we planned a very great session that you will find useful."
    new "این خیلی عالیه، مطمئنم درس امروز نگاهت به درس‌های قبلی رو تغییر می‌ده، ما جلسه‌ای خیلی خوب برنامه‌ریزی کردیم که برایت مفید خواهد بود."

    # say L1448 ana
    old "Ok, thank you... Every day I can learn something new... Hi [pla], nice to see you again."
    new "باشه، ممنون... هر روز می‌تونم چیز جدیدی بیاموزم... سلام ز[pla]، خوشحالم که دوباره دیدمت."

    # say L1451 pla
    old "Hello guys..."
    new "سلام دوستان..."

    # say L1454 lis
    old "Please, enjoy yourselves... The yoga room is already prepared for your session."
    new "لطفاً لذت ببرید... اتاق یوگا برای جلسه‌ی شما آماده است."

    # say L1455 pla
    old "Thank you Lisa, Anastasia please come in."
    new "ممنون Lisa، Anastasia لطفا بیا داخل."

    # say L1456 ana
    old "Sure, I can't wait."
    new "بله، منتظر این جلسه بودم."

    # say L1464 ana
    old "I need to confess that I did not study for today's lesson, so... Professor are you going to punish me?"
    new "من باید بگم که برای درس امروز مطالعه نکردم، پس... آقای استاد می‌خوای مرا مجازات کنی؟"

    # say L1465 pla
    old "... I- (I should be confident, that's what Lisa expect from me.)"
    new "من باید اعتماد به نفس داشته باشم، همینطوری لیزا از من انتظار داره."

    # say L1466 ana
    old "What about if we just improvise?"
    new "می‌تونیم فقط ایمپروویز کنیم؟"

    # say L1480 ana
    old "Are you going to fuck me harder today?"
    new "امروز می‌خوای منو سخت‌تر بکنی؟"

    # say L1487 ana
    old "Oh yeah baby, Fuck me like that again."
    new "اوه بله بیبی، دوباره مثل اونجور بمن سکس کن."

    # say L1496 pla
    old "There is something new I want you to try."
    new "چیز جدیدی هست که می‌خوام امتحانش کنیم."

    # say L1497 ana
    old "Wow, I can see you don't need to rest young man, I am anxious to try it even if I feel a bit tired."
    new "واو، می‌بینم نیازی به استراحت نداری، جوان. من هم اگر یک کم خسته باشم، خیلی صبر نمی‌کنم تا امتحانش کنم."

    # say L1498 pla
    old "We still have a lot to learn."
    new "هنوز چیز‌های زیادی برای یادگیری داریم."

    # say L1499 ana
    old "Sign me up."
    new "من رو ثبت‌نام کن."

    # say L1500 pla
    old "I will need you to relax your body so I can take your legs, I will hold them with my hands, but I will need you to hold me firmly with your hands."
    new "باید بدنت رو آرامش بدی تا بتوانم پاشون رو بگیرم، من با دستام اونا رو نگه می‌دارم، اما باید تو با دستات من رو محکم نگه داری."

    # say L1501 ana
    old "I will do anything you ask of me."
    new "من هر چیزی رو که از من بخواهی انجام می‌دم."

    # say L1502 pla
    old "Alright... Let's start."
    new "باشه... بیاین شروع کنیم."

    # say L1509 ana
    old "Oh, wow you are getting creative!"
    new "اوه، وای، تو خلاقیتت رو بالا می‌بری!"

    # say L1519 ana
    old "Oh my god, that was unbelievable, I am so astonished! Is this the exercise Lisa mentioned you were preparing lately?"
    new "اوه خدا، این باورنکردنی بود، هیچ وقت همچین چیزی ندیده‌ام! این همان تمرینیه که لیزا گفتی تو در حال آماده‌سازی‌اش هستی؟"

    # say L1521 ana
    old "So does she know? Wow, You guys don't stop surprising me."
    new "پس او می‌دونه؟ وای، شماها هیچ وقت از تعجب من بیرون نمی‌آیید."

    # say L1523 ana
    old "Let me ask you something, because this has blown my mind... Does Lisa offer these lessons with more than one instructor? I mean a team session with her would be pretty interesting..."
    new "بپرس ازت چیزی، چون این به ذهنم زد... لیزا این درس‌ها رو با بیش از یک مربی ارائه می‌ده؟ منظورم اینه که جلسه‌ای تیمی با او خیلی جالب می‌تونه بود..."

    # say L1524 pla
    old "I- I'm not sure, I think I will need to ask her."
    new "من- من مطمئن نیستم، فکر کنم باید ازش بپرسم."

    # say L1525 ana
    old "Alright, I have to go, let's get dressed."
    new "خوب، باید برسم، بیای لباسمون رو بگذاریم."

    # say L1540 lis
    old "So guys, how was the session today?"
    new "پسران و دختران، جلسه امروز چطور بود؟"

    # say L1542 ana
    old "Lisa, I think this has been the most incredible Yoga experience I have had in my entire life. I love your work, and of course your... Teamwork."
    new "لیزا، فکر می‌کنم این بهترین تجربه یوگا در تمام زندگی من بوده. کارت رو دوست دارم، و البته همکاریت‌ها رو هم."

    # say L1543 ana
    old "Some friends are very interested in coming, I have persuaded them because of my experience, so hope you are ready for them."
    new "برخی دوستان خیلی علاقه‌مند هستن که بیان بیاین، من قانع کردمشون بر اساس تجربیاتم، پس امیدوارم آماده باشین."

    # say L1544 lis
    old "I appreciate you sharing your experience with your friends. I am sure you will learn more, do not doubt we will do our best to surprise you and your friends every time."
    new "ممنونم که تجربه‌تو با دوستات هم در میان گذاشتی. حتماً چیزهای جدیدی خواهی یاد گرفت، نباید شک کنی که ما همیشه تلاش می‌کنیم تا تو و دوستات رو هر بار شگفت‌زده کنیم."

    # say L1545 ana
    old "Love you guys, see you next time."
    new "دوستتون دارم، ببینم شما بعداً."

    # say L1546 lis
    old "Sure, I have already scheduled your next appointment so I will be calling you."
    new "البته، قرار ملاقات بعدیت رو قرار دادم، پس از تلفنتم."

    # say L1547 ana
    old "Perfect, I will look forward to."
    new "عالی، منتظرش می‌شوم."

    # say L1548 lis
    old "Nice to have you here, bye bye!"
    new "خوشحالم که اینجا بودی، خداحافظ!"

    # say L1549 ana
    old "See you next time."
    new "تا دفعه بعد می‌بینیم."

    # say L1559 lis
    old "Did you feel it?"
    new "احساش کردی؟"

    # say L1560 pla
    old "Yes... I- I did."
    new "بله... من- من احساس کردم."

    # say L1561 lis
    old "This is what we need to share with others, once you understand the language of the universe, you can translate to others, I am very proud that you are improving."
    new "این همان چیزی است که باید با دیگران به اشتراک بگذاریم، وقتی زبان جهان را درک کنی، می‌توانی به دیگران ترجمه کنی، خیلی خوشحالم که تو پیشرفت می‌کنی."

    # say L1563 lis
    old "I know you are quite good however remember this is a process... we need to continue working... So... we need to continue working on your chakra."
    new "میدونم خوبی هستی اما بخاطر بدار این یه فرآیند هست... باید ادامه بدهیم... پس... باید روی چاکرت ادامه بدیم."

    # say L1565 lis
    old "I'll be waiting for you tomorrow night, those tantric sessions need to continue, as you saw today, you will become a very great Yoga instructor, so don't stop."
    new "فقط صبر کن، من فردا شب منتظرت هستم، این جلسات تانترا باید ادامه داشته باشن، مثل آنچه امروز دیدی، تو می‌تونی یه مربی یوگا عالی بشی، پس نباید متوقف شی."

    # say L1587 lis
    old "Hello, I was waiting for you."
    new "سلام، منتظرت بودم."

    # say L1588 pla
    old "Hi Lisa..."
    new "سلام لیزا..."

    # say L1589 lis
    old "I was very excited because with this session we concluded this chapter with your chakras, remember the process is to find the perfect balance is not something we can call finished."
    new "من خیلی خوشحالم زیرا با این جلسه فصلی از چاکراهایت تمام شد، به یاد داشته باش که یافتن تعادل کامل چیزی است که نمی‌توانیم به آن پایان دهیم."

    # say L1590 pla
    old "I understand, I will continue working on it."
    new "من درک کردم، ادامه خواهم داد."

    # say L1591 lis
    old "Actually, I wanted you to know that we can still work again on this, since this is a very good exercise for us both you can count on me to help you."
    new "در واقع می‌خواستم بدانی که هنوز می‌توانیم روی این کار بیشتر کار کنیم، چون این یک تمرین خیلی خوب برای هر دو ما است و می‌توانی بر من حساب بگذاری که به تو کمک می‌کنم."

    # say L1592 pla
    old "I really... Appreciate everything you do for me."
    new "من واقعاً... از همه چیزی که برای من می‌کنی ممنونم."

    # say L1593 lis
    old "It's my way to say thank you, I want to thank you for your hard work."
    new "این راه من برای تشکر ازت هست، می‌خوام از تلاش‌های سختت تشکر کنم."

    # say L1594 lis
    old "Let's go to the room to start the session..."
    new "بیای به اتاق بریم شروع کنیم..."

    # say L1602 lis
    old "Regular sex is about exploring and feeling pleasure desperately... The tantric experience is different, it's about the energy and sensations you can have with your partner."
    new "جنس عادی درباره اکتشاف و تجربه لذت به شکل دست‌کاره است... تجربه تانتری متفاوت است، این درباره انرژی و احساساتی است که می‌توانی با همسر خود تجربه کنی."

    # say L1603 lis
    old "Sex consists of penetration and cumming, that takes out part of the connection, tantric sex otherwise means eye contacting, touching, breathing, to hear the noises."
    new "جنس شامل نفوذ و شیطون شدن است، این بخشی از ارتباط رو می‌بره، جنس تانتریک همینطور نیست، این درباره تماس چشمی، لمس، نفس‌کشی و شنیدن صداهاست."

    # say L1605 lis
    old "That is why we start with the massage, so we can open our senses, open ourselves to the other."
    new "به همین خاطر با ماساژ شروع می‌کنیم، تا حواسمون باز شده و به دیگر هم باز شویم."

    # say L1606 lis
    old "Please lie down to start the massage..."
    new "لطفاً برای شروع ماساژ خواب بخور."

    # say L1621 lis
    old "We will need to work harder today so let me start with some lubrication, the universe it self is all about love, so nothing better than kisses to start, to help you expel the negative chakra."
    new "امروز باید سخت‌تر کار کنیم، پس اجازه بده من با گلوله‌های گلیدن شروع کنم. خود جهان هم همه‌اش درباره عشق است، پس هیچ چیز بهتر از بوسه‌ها برای شروع نیست، تا به تو کمک کنه تا انرژی منفی رو از بدن خارج کنی."

    # say L1623 lis
    old "Just relax, remember to release the tension so you can do the exercise effectively."
    new "فقط آرام شو، به یاد داشته باش تنش رو رها کن تا بتونی تمرین رو به درستی انجام بدی."

    # say L1639 pla
    old "That was great... I felt really good... Are we done?"
    new "عالی بود... خیلی خوب حس کردم... ما تمام شدیم؟"

    # say L1640 lis
    old "Of course not, since the main purpose is to finally connect deeply with yourself, there is a lot more to learn. I have a very special exercise for you to conclude this chakra training."
    new "البته نه، هدف اصلی اینه که با خودت عمیق‌تر متصل بشی، هنوز چیز‌های زیادی برای یادگیری داریم. من یک تمرین خیلی خاص برایت دارم که با این آموزش چاکرا به پایان برسه."

    # say L1641 lis
    old "I will need you to lie down again so I can do the movements needed."
    new "باید دوباره خوابشی تا من حرکات لازم رو انجام بدم."

    # say L1642 lis
    old "Let me show you how it works..."
    new "بیای ببین چطور کار می‌کنه..."

    # say L1648 lis
    old "Feel all inside me."
    new "حاسه می‌کنم همه‌ت داخل من است."

    # say L1649 lis
    old "I'm feeling all of you."
    new "من همه‌ت رو حس می‌کنم."

    # say L1659 lis
    old "To be honest, I feel you're shining lately, these exercises have brought you wellness to your spirit and I can perceive it, I hope you can see the changes too."
    new "برات صادقانه، احساس می‌کنم اخیراً درخشی داری، این تمرین‌ها روح‌ت رو خوشحال کردن و من اینو می‌فهمم، امیدوارم تو هم تغییرات رو ببینی."

    # say L1660 pla
    old "For sure, I think I feel much better now."
    new "حتماً، فکر می‌کنم حالا خیلی بهتر حس می‌کنم."

    # say L1661 lis
    old "Remember that it is really important to continue this training, if you want to reach out to me any night, so we can work on your chakra training..."
    new "به خاطر داشت، ادامه این تمرین‌ها واقعاً مهمه، اگه بخوای هر شبی به من تماس بگیری، می‌تونیم روی آموزش چاکرتون کار کنیم..."

    # say L1662 lis
    old "You know it helps you to stay more balanced and focused in your chakras... I'll have nights free so we can repeat the tantric ritual anytime you need."
    new "میدونی این به تو کمک می‌کنه تا متعادل‌تر و متمرکز‌تر باشی در چاکرتون... من شب‌های خالی دارم، پس هر وقت نیاز داشتی می‌تونیم مراسم تانتری رو تکرار کنیم."

    # say L1663 lis
    old "I think, now that you have balanced your energies, and your chakra muladhara has been controlled, you can even lead the tantric sessions with some of our customers."
    new "فکر می‌کنم حالا که انرژی‌هات را تعادل دادی و چاکرا مولاذارا را کنترل کردی، می‌توانی حتی جلسات تانتریک با برخی از مشتری‌های ما را هدایت کنی."

    # say L1664 lis
    old "I'm sure the universe has great things for you, you already know you can count on me."
    new "مطمئنم جهان چیزهای خوبی برای تو در نظر داره، تو قطعاً می‌دونی می‌تونی به من اعتماد کنی."

    # say L1665 pla
    old "I appreciate that."
    new "ممنونم."

    # say L1666 lis
    old "Don’t forget you can keep up the yoga sessions with Anastasia in the afternoons, whenever you’ve got time!"
    new "فراموش نکن که می‌تونی بعد از ظهر با آناستازیا جلسات یوگا رو ادامه بدهی، هر وقت وقتت باشه!"

    # say L1667 lis
    old "Your lessons have evolved now that you are better balanced and applying your yoga knowledge to the sex connection..."
    new "درس‌هایت الان که تعادلت بهتر شده و دانش یوگات رو به ارتباط جنسی اعمال می‌کنی، تکامل یافته‌اند."

    # say L1668 lis
    old "If you feel you need to review the previous trainings we have done, any morning I'll be working on that so you prepare better always to help your customers."
    new "اگر احساس می‌کنی باید تمرین‌های قبلی رو مرور کنی، هر صبح من در اون کار مشغول هستم تا همیشه بهتر برای کمک به مشتری‌هات آماده باشی."

    # say L1670 lis
    old "I am happy to hear that... We need to rest now, have a good night [pla]."
    new "خوشحالم که می‌شنوم... حالا باید استراحت کنیم، شب خوبی داشته باش [pla]."

    # say L1671 pla
    old "Ok, good night Lisa!"
    new "باشه، شب خوبی لیزا!"

    # say L1695 pla
    old "Hey Lisa! It's so nice to see you, how are you?"
    new "هی لیزا! خوشحالم که دیدمت، حالت چطوره؟"

    # say L1696 lis
    old "Hi dear! I'm very good, and you?"
    new "سلام عزیزم! من خیلی خوب هستم، تو چطوری؟"

    # say L1697 pla
    old "I'm not so fine, we're having some financial issues..."
    new "من خوب نیستم، مشکلات مالی داریم..."

    # say L1698 lis
    old "Really? I'm so sorry... How could I help you?"
    new "وای، خیلی متاسفم... چطور می‌تونم به تو کمک کنم؟"

    # say L1699 pla
    old "Actually, that's why I'm here. I thought maybe you needed someone to help you out with your business, I really need to find a job."
    new "در واقع، همین جهت هستم. فکر کردم شاید نیاز به کسی برای کمک به کارتو داری، من واقعاً نیاز دارم شغل پیدا کنم."

    # say L1701 pla
    old "I could work on anything... Doesn't matter what it's."
    new "من می‌تونم روی هر چی کار کنم... مهم نیست چیه."

    # say L1702 lis
    old "Sadly, I can't hire you. I don't really need help right now."
    new "متأسفانه نمی‌توانم تو رو استخدام کنم. حالا واقعاً کمکی نیاز ندارم."

    # say L1703 lis
    old "I haven't had much sales lately... I'm barely doing some Yoga classes for a few people."
    new "اخیراً فروش خوبی نداشتم... فقط چند جلسه یوگا برای چند نفر انجام می‌دم."

    # say L1704 lis
    old "However, I'm planning on improving my sales by implementing some new marketing strategies and I might need you sometime soon."
    new "ولی من برنامه دارم با اجرای استراتژی‌های بازاریابی جدید فروش رو بهبود ببخشم و ممکنه زودی به تو نیاز داشته باشم."

    # say L1706 lis
    old "But not really right now..."
    new "اما الان خیر..."

    # say L1708 lis
    old "Sorry about that..."
    new "متاسفم..."

    # say L1709 pla
    old "No, it's ok. Not your fault, I gotta keep looking... I guess."
    new "نه، مشکلی نداره. این جایت نیست، من باید همچنان جستجو کنم... حدس می‌زنم."

    # say L1710 lis
    old "You'll find something good."
    new "چیز خوبی پیدا می‌کنی."

    # say L1711 pla
    old "Hmm, I hope. Thanks anyway, it's always nice to see you."
    new "Hmm، امیدوارم. هر طور هم ممنون، همیشه خوشحالم که تو رو ببینم."

    # say L1712 lis
    old "I say the same... I'm glad you came to visit."
    new "من هم همین جور می‌گم... خوشحالم که اومدی."

    # say L1714 pla
    old "I should go, I really have to find a job, see you Lisa."
    new "باید برم، واقعاً باید شغلی پیدا کنم، دیدنت خوشحالم لیزا."

    # say L1737 pla
    old "Hmm, this is weird, she should be here at this time of day."
    new "Hmm، این خیلی عجیبه، او باید در این وقت روز اینجا بود."

    # say L1738 pla
    old "Lisa! Are you here?"
    new "لیزا! تو اینجا هستی؟"

    # say L1739 pla
    old "So odd, where is she?"
    new "عجیب است، او کجا است؟"

    # say L1754 pla
    old "What is that noise? I guess she's in the yoga room."
    new "این صدای چیه؟ حدس می‌زنم تو اتاق یوگا هستی."

    # say L1767 pla
    old "{i}(That's- Umm... Quite an interesting position.){/i}"
    new "{i}(این- اوه... وضعیت خیلی جالبی هست.){/i}"

    # say L1783 lis
    old "Oh, [pla], I didn't realize you were around."
    new "اوه، [pla]، نمی‌دونستم تو اینجا هستی."

    # say L1784 lis
    old "I'm sorry for not noticing before."
    new "متاسفم که قبلا متوجه نشدم."

    # say L1786 pla
    old "I- I'm sorry, Lisa! I- I didn't mean to spy on you."
    new "من- من عذرخواهم، لیزا! من- من قصد نداشتم به تو نگاه کنم."

    # say L1788 lis
    old "It's quite alright, I didn't realize I left the door open."
    new "البته، من هم نفهمیده بودم در را باز گذاشتم."

    # say L1789 lis
    old "Besides, all I was doing was resonating my Muladhara chakra with the energy of the universe."
    new "البته، من فقط در حال هماهنگی چاکرا مولادهارا با انرژی جهان بودم."

    # say L1790 lis
    old "There's nothing to hide about that. So you don't need to worry about anything."
    new "هیچ جور نیازی به نگرانی نداری، هیچ چیزی برای پنهان کردن نیست."

    # say L1794 lis
    old "So, what brings you here?"
    new "پس، چه کاری اینجا داری؟"

    # say L1796 pla
    old "Uhmm, w- well, I just wanted to see how you're doing."
    new "می‌خواستم ببینم حالت چطوره."

    # say L1797 pla
    old "You know, to check how everything's going."
    new "می‌خواستم ببینم همه چیز چطوره."

    # say L1799 lis
    old "Well, I've been a little stressed, you know, this whole business thing is a little tiring."
    new "خب، یه کم استرس داشتم، می‌دونی، این کار یه کم خسته‌کننده."

    # say L1800 lis
    old "But that's precisely why I was just realigning my energy with the universe."
    new "اما همین به خاطر هست که من فقط در حال هماهنگ کردن انرژی‌ام با یهان بودم."

    # say L1801 lis
    old "After stimulating my Muladhara chakra, I feel like I've been relieved of all stress now."
    new "بعد از تحریک چاکرا مولادهارا، حس می‌کنم همه استرس‌هام برداشته شده."

    # say L1805 pla
    old "Is it that effective?"
    new "اینقدر موثره؟"

    # say L1807 lis
    old "Of course it is! The Muladhara chakra is the second of the body and the one that regulates our sacred sexual energy."
    new "البته! چاکرا مولادهارا دومین چاکرا از بدن است و آن که انرژی جنسی مقدس ما را تنظیم می‌کند."

    # say L1808 lis
    old "It may have looked like I was just masturbating, but it's a lot more than that."
    new "شاید به نظر می‌رسید فقط در حال استمناء هستم، اما این خیلی بیشتر از اونه."

    # say L1809 lis
    old "The Muladhara regulates our self-esteem."
    new "چاکرا مولادهارا هم خودت را ارزشمند می‌کند."

    # say L1810 lis
    old "By properly stimulating it you can improve your mood because your energy's in line with the rest of the universe."
    new "با تحریک درست اونجا می‌تونی خودت رو بهتر حس کنی، چون انرژیت با بقیه جهان هماهنگ می‌شه."

    # say L1812 pla
    old "Uh... I- I see."
    new "اوه... من- من متوجه شدم."

    # say L1813 pla
    old "So, this {i}'Proper stimulation'{/i}, is that why you were upside down?"
    new "پس این {i}«تحلیل مناسب»{/i}، برای همین بود که بالعکس بودی؟"

    # say L1815 lis
    old "Yes, that's right."
    new "بله، همین‌طور است."

    # say L1816 lis
    old "By taking that position, I was letting my energy flow outwards from my head."
    new "با این وضعیت، من انرژی خودم رو از سر به بیرون رها می‌کردم."

    # say L1817 lis
    old "And replenishing my Muladhara chakra with positive energy coming from the top."
    new "و با انرژی مثبتی که از بالا می‌آید، چاکرا مولاذرایم را تغذیه می‌کنم."

    # say L1818 lis
    old "It's tremendously effective [pla], I highly recommend it to you."
    new "این خیلی موثره [pla]، به تو توصیه می‌کنم."

    # say L1820 pla
    old "Y- you do?"
    new "B-بله، تو انجام می‌دهی؟"

    # say L1822 lis
    old "Oh yeah, it's somewhat difficult to do."
    new "اوه بله، انجامش کمی سخته."

    # say L1823 lis
    old "But I'm sure I can guide you towards a path of proper alignment with the universe."
    new "اما مطمئن هستم می‌تونم تو رو به راهی برای هماهنگی درست با جهان هدایت کنم."

    # say L1825 pla
    old "Uh, I- I guess I'll think about it."
    new "من فکر می‌کنم در موردش فکر کنم."

    # say L1826 lis
    old "Oh, by the way, I was hoping you'd come, seems like the energies drew you here. It's so beautiful when the universe conspires in your favor."
    new "البته، به نظر می‌رسه انرژی‌ها تو رو اینجا جلب کردن. وقتی که جهان برایت همکاری می‌کنه، خیلی زیباست."

    # say L1827 pla
    old "Oh, do you need me for something?"
    new "اوه، می‌خوای از من چیزی بگیری؟"

    # say L1828 lis
    old "Yeah, but let me get dressed and comfy. Meet me downstairs and we'll chat for a bit."
    new "بله، ولی بیای لباستو بپوشم و راحت شوم. به پایین بیا، یه کم با هم صحبت می‌کنیم."

    # say L1829 pla
    old "Uh, yeah, sure. I'll be waiting downstairs."
    new "بله، حتماً. من پایین منتظرت می‌مونم."

    # say L1840 lis
    old "I'm ready, thanks for waiting. I'm really glad you came today."
    new "آماده‌ام، ممنون که منتظرم موندی. خوشحالم که امروز اومدی."

    # say L1841 pla
    old "Uh, sure. So, what did you want to talk about?"
    new "آره، البته. پس، می‌خوای در مورد چی صحبت کنیم؟"

    # say L1843 lis
    old "Well, you see, I need to ask a favor of you."
    new "خب، می‌بینی، از تو یه لطفی خواستن می‌تونم."

    # say L1845 pla
    old "Really? What is it?"
    new "وای، چه کاری؟"

    # say L1847 lis
    old "It's about this client that I have, I've been working with her for a while."
    new "مربوط به این مشتریه که باهاش کار می‌کنم، مدتی هست که باهاش کار می‌کنم."

    # say L1848 lis
    old "I would like you to be her instructor during her next class, instead of me."
    new "من می‌خوام تو در جلسه بعدش به جای من مربی‌اش باشی."

    # say L1850 pla
    old "Oh! Are you busy again? Sure, I'll cover you."
    new "اوه! دوباره مشغولی؟ حس خوب، من جایت رو می‌گیرم."

    # say L1851 lis
    old "No, it's nothing like that. I don't have anything else to do during that session."
    new "نه، هیچ جور نیست. من در آن جلسه هیچ کار دیگری ندارم."

    # say L1853 pla
    old "So what is it?"
    new "پس چیه؟"

    # say L1854 lis
    old "Well, she's come to every appointment without fail, she also does every yoga pose correctly."
    new "خب، او بدون اشکال به همه جلسات آمده، همچنین هر پوزیسیون یوگا را درست انجام می‌دهد."

    # say L1856 lis
    old "But in spite of that, I would say she's not actually doing well."
    new "اما با این حال، من می‌گم واقعاً خوب نیست."

    # say L1857 pla
    old "She isn't?"
    new "نه؟"

    # say L1859 lis
    old "Yeah, I'm not feeling her energy flowing the way it should."
    new "بله، من حس نمی‌کنم انرژی‌اش به درستی جریان داشته باشه."

    # say L1861 lis
    old "It's hard to explain, but even though she's been progressing in terms of flexibility and poses."
    new "توضیحش سخته، اما با وجود اینکه او پیشرفت کرده در مورد انعطاف‌پذیری و وضعیت‌ها."

    # say L1863 lis
    old "I still feel like she needs something else in order to thrive."
    new "همچنان حس می‌کنم برای رشدش به چیزی دیگر نیاز داره."

    # say L1864 pla
    old "And you think that {i}'something else'{/i} has to do with me?"
    new "و فکر می‌کنی آن {i}چیز دیگر{/i} با من ربط داره؟"

    # say L1865 lis
    old "Yes, that's correct."
    new "بله، همینطور است."

    # say L1867 lis
    old "I think that maybe your masculine energy will be able to unearth whatever's stopping her from progressing."
    new "فکر می‌کنم شاید انرژی مردانه تو بتونه هر چیزی که از پیشرفت او باز می‌هیه، بیرون بیاره."

    # say L1869 lis
    old "After all, you already helped Anastasia in a very effective way."
    new "البته، تو قبلاً به آناستازیا کمک کردی و این کار خیلی موثر بود."

    # say L1870 lis
    old "So I thought that it would be worth it to give it a go with this girl as well."
    new "پس فکر کردم برای این دختر هم امتحان کنم."

    # say L1872 pla
    old "Uh, well, if you say so, sure."
    new "اوه، خب، اگه می‌گی، البته."

    # say L1873 pla
    old "I'll be happy to help you."
    new "خوشحالم که به تو کمک کنم."

    # say L1875 lis
    old "That's great! I'll let her know about it and I'll see you in the afternoon then."
    new "عالیه! ازش خبر می‌دم و بعد از ظهر می‌بینیم."

    # say L1877 pla
    old "Sure, no problem, I'll see you later."
    new "بله، هیچ اشکالی نداره، بعداً می‌بینیم."

    # say L1902 pla
    old "Hi Lisa, I came for the class you told me about-"
    new "سلام لیزا، برای کلاسی که به من گفتی اومدم-"

    # say L1906 pla
    old "{i}(Is that Angelina? What's she doing here?){/i}"
    new "{i}(این آنجلینا هست؟ اینجا چه کاری داره؟){/i}"

    # say L1908 lis
    old "Hello [pla], you arrived just in time, this is Angelina, the client that you'll be helping today."
    new "سلام ز[pla]، خوشحالم که همین الان رسیدی، این آنجلینا هست، مشتری‌ای که امروز بهش کمک می‌کنی."

    # say L1910 pla
    old "Uh, yeah... Hi A- Angelina, nice to meet you."
    new "آره، بله... سلام آنجلینا، خوشحالم که با تو آشنا شدم."

    # say L1912 ang
    old "Uh, yeah, hi to you too... Nice meeting you."
    new "بله، سلام... خوشحالم که با تو آشنا شدم."

    # say L1913 lis
    old "So, as I told you a moment ago, [pla] will be taking over your class today."
    new "پس، همانطور که یه لحظه پیش به تو گفتم، ز[pla] امروز کلاس تو رو می‌گیره."

    # say L1915 lis
    old "Uhh, Angelina?"
    new "اوه، آنجلینا؟"

    # say L1917 ang
    old "Y- yes, of course. Please, continue."
    new "بله، البته. لطفاً ادامه بده."

    # say L1919 lis
    old "Okay, as I was saying earlier, he has been helping me recently by giving classes to some of my clients."
    new "خب، همانطور که قبلاً می‌گفتم، اخیراً به من کمک کرده است با تدریس به برخی از مشتریان من."

    # say L1921 lis
    old "You don't have to worry about anything, he's very knowledgeable and he has a spectacular energy."
    new "نگران هیچ چیز نباشی، او خیلی دانش‌آموخته است و انرژی فوق‌العاده‌ای دارد."

    # say L1924 lis
    old "So, I'm sure he'll be capable of helping you in the way you need."
    new "پس مطمئن باش، او قطعاً خواهد توانست به شکلی که نیاز داری به تو کمک کند."

    # say L1926 ang
    old "I- I see, well... I'll be in his care then."
    new "ببین، خب... من در مراقبت‌اش خواهم بود."

    # say L1928 lis
    old "Let's go to the yoga studio so you two can start your class."
    new "بیایم به استودیو یوگا برویم تا شما دو تا کلاس خودتون رو شروع کنید."

    # say L1938 lis
    old "I'll leave you two alone so you can start with the session, I hope you enjoy it, Angelina."
    new "من شما رو به همراه یکدیگر می‌گذaram تا جلسه‌تون شروع بشه، امیدوارم لذت ببری، آنجلینا."

    # say L1939 ang
    old "W- well, thank you."
    new "خ- خب، ممنون."

    # say L1941 pla
    old "We'll see you later."
    new "بعداً می‌بینیم."

    # say L1950 pla
    old "Uhh, alright, so..."
    new "اوه، خب، منو..."

    # say L1956 pla
    old "I- I guess we better get started with the class."
    new "باید شروع به کلاس کنیم."

    # say L1958 ang
    old "Wait a minute."
    new "یه لحظه."

    # say L1960 ang
    old "Can you please tell me what you're doing here? I thought you were supposed to be Dr. Johnson's assistant."
    new "لطفاً بگو چه کاری اینجا می‌کنی؟ فکر کردم باید ساعد Dr. Johnson باشی."

    # say L1961 ang
    old "How come I'm running into you here? And you're teaching yoga?"
    new "چرا همینجا با تو مواجه شدم؟ و تو یوگا می‌آموزی؟"

    # say L1963 ang
    old "What's next? Will you be my waiter if I go to a restaurant?"
    new "بعدش چی؟ اگه به رستوران برسم، می‌تونی پیشکار من باشی؟"

    # say L1964 pla
    old "Hmm, I can see why this would surprise you, but believe me, it was a surprise for me too."
    new "هم، می‌تونم بفهمم چرا اینجوری شوک شدی، ولی باور کن برای من هم مفاجا بود."

    # say L1966 pla
    old "But it's nothing like what you're imagining."
    new "اما این هیچ شباهتی به آن چیزی نداره که تو فکر می‌کنی."

    # say L1968 pla
    old "I'm related to Lisa, she's my [mom2Rel]'s younger sister."
    new "من با لیزا قریبی هستم، او خواهر کوچکتر [mom2Rel] من است."

    # say L1970 pla
    old "And since she started the studio I've been giving her a hand with some particular clients."
    new "و از زمانی که او استودیو رو شروع کرد، من بهش در مورد برخی مشتریان خاص کمک می‌کنم."

    # say L1971 pla
    old "But I swear that I didn't know that you were the client I was supposed to help with the class today."
    new "ولی قسمت می‌خورم که نمی‌دونستم تو همین مشتری بودی که من باید امروز در کلاس بهش کمک کنم."

    # say L1973 pla
    old "She just came to my house asking me for a hand with a client, and that's it."
    new "او فقط به خونه‌ام اومد و از من پرسه کمکی کنه با یه مشتری، و همینه."

    # say L1975 ang
    old "I don't know."
    new "نمی‌دونم."

    # say L1977 ang
    old "It's just so weird that I keep running into you."
    new "البته، خیلی عجیب است که همیشه با تو مواجه می‌شوم."

    # say L1978 pla
    old "I know, trust me, it's very weird for me too."
    new "بله، باور کن، برای من هم خیلی عجیب است."

    # say L1979 pla
    old "But if you let me, I'll be more than happy to help you with the class."
    new "اما اگر برام اجازه بدی، خوشحالم که بهت در درس کمک کنم."

    # say L1981 ang
    old "I guess that if Lisa says it's alright, I have no reason to not believe what you're saying."
    new "البته، اگر لیزا می‌گه خوبه، من هیچ دلیلی ندارم تا نباور باشم چیزی که می‌گی."

    # say L1982 ang
    old "So I guess I'll do it."
    new "پس فکر کنم اینجوری می‌کنم."

    # say L1984 pla
    old "Great! And hey, how's Roonie doing?"
    new "عالی! و بگو، روونی چطوره؟"

    # say L1986 pla
    old "I bet he must be happy about the baby."
    new "حتماً خوشحاله از بچه."

    # say L1987 ang
    old "Uhm, yeah... He's doing alright."
    new "اوه، بله... او خوب است."

    # say L1988 pla
    old "I see, good, good. A- and how's the pregnancy been treating you?"
    new "بینی، خوب، خوب. و- و حامل بودن برای تو چطوره؟"

    # say L1990 ang
    old "I've been alright... I think"
    new "من خوب هستم... فکر کنم"

    # say L1991 ang
    old "The doctor told me that I should try to stay active during my pregnancy."
    new "پزشک به من گفت که باید در حین بارداری فعال باشم."

    # say L1992 ang
    old "That's why I'm taking yoga lessons, I was told it's one of the best things that you could do as a pregnant woman."
    new "به همین خاطر درس یوگا می‌گیرم، به من گفتند این یکی از بهترین کارهاییه که می‌تونی به عنوان یه زن باردار انجام بدی."

    # say L1993 pla
    old "Oh yeah?"
    new "اوه آره؟"

    # say L1995 ang
    old "Yes, it's supposed to improve sleep by reducing stress, and also helping relieve anxiety."
    new "بله، می‌گن که خواب رو با کاهش استرس بهتر می‌کنه، همچنین به کاهش اضطراب هم کمک می‌کنه."

    # say L1996 ang
    old "And apparently it helps to strengthen the muscles needed for childbirth."
    new "و به نظر می‌تونه به تقویت عضلات لازم برای زایمان هم کمک کنه."

    # say L1997 ang
    old "And the flexibility of course."
    new "و البته انعطاف‌پذیری هم."

    # say L1998 ang
    old "So that's why I'm doing yoga."
    new "پس همین‌جوری هست که من یوگا می‌کنم."

    # say L1999 pla
    old "I see, that all makes a lot of sense."
    new "می‌بینم، همه اینا خیلی منطقی هستند."

    # say L2007 pla
    old "Uhmm, w- well, what do you say we get started with the session."
    new "اوه، خب، چطور می‌گیم شروع به جلسه کنیم."

    # say L2011 pla
    old "Alright, let's start with the first asana."
    new "باشه، بیایید از اولین آسانا شروع کنیم."

    # say L2012 pla
    old "This first one's called Setu Bandha."
    new "این اولی به نام ستوبند هست."

    # say L2013 ang
    old "Ok? Is it too hard?"
    new "باشه؟ خیلی سخته؟"

    # say L2014 ang
    old "I mean, I ask because I'm pregnant."
    new "من می‌گم، چون باردارم."

    # say L2016 pla
    old "Nah, it's not too hard."
    new "نه، خیلی سخت نیست."

    # say L2017 pla
    old "Sure it can be a little challenging."
    new "البته می‌تونه یه کم چالش‌برانگیز باشه."

    # say L2018 pla
    old "But don't worry, I'll be there helping you during it."
    new "اما نگران نباش، من همینجا هستم تا بهت کمک کنم."

    # say L2020 ang
    old "Ok, how do I do it?"
    new "باشه، من چطور باید این کار رو انجام بدم؟"

    # say L2022 pla
    old "It's simple, just lay on your back with your knees up and your heels towards your butt."
    new "این ساده است، فقط روی پشت خودت بخواب و زانو‌هات رو بالا ببر و پاشون به سمت پاشون بکش."

    # say L2023 pla
    old "And then just push through the soles of your feet and lift your hips up, like making an arch."
    new "بعد از این فقط با نوک پایت فشار بده و باسن رو بلند کن، مثل اینکه یه قوس می‌سازی."

    # say L2024 ang
    old "Hmm, ok, I guess I get it."
    new "Hmm، اوکی، فکر کنم متوجه شدم."

    # say L2030 pla
    old "Yeah, you're doing it well, but you're a little tense through the shoulders."
    new "بله، خوب انجام می‌دی، ولی شانه‌هایت کمی تنیده."

    # say L2031 pla
    old "Try to relax a little bit more."
    new "می‌تونی یه کم بیشتر آرام شی."

    # say L2032 ang
    old "O- Ok."
    new "ب-له."

    # say L2039 pla
    old "{i}(Hmm, I see what Lisa was telling me, she's doing the position right.){/i}"
    new "{i}(حالم می‌یاد چیزی که لیزا به من گفت، موقعیت رو درست انجام می‌ده.){/i}"

    # say L2040 pla
    old "{i}(But I can see that she's very tense.){/i}"
    new "{i}(ولی می‌تونم ببینم که خیلی تنیده هست.){/i}"

    # say L2042 pla
    old "Ok, that's very good, now let's move into the next one."
    new "باشه، این خوب بود، حالا بیای ببینیم موقعیت بعدی چطوره."

    # say L2043 ang
    old "O-ok."
    new "ا-ا باشه."

    # say L2051 pla
    old "Alright, that was a good start."
    new "البته، این یک شروع خوب بود."

    # say L2052 pla
    old "So I guess we can move into the next position."
    new "پس فکر کنم می‌تونیم به وضعیت بعدی برویم."

    # say L2053 pla
    old "This one's called Balasana."
    new "این حالت به نام بالاسانا است."

    # say L2054 pla
    old "It's even easier than the previous one, but it's very good to stretch the shoulders and back."
    new "این حتی ساده‌تر از قبلیه، ولی برای کشش شانه‌ها و پشت خیلی خوبه."

    # say L2055 ang
    old "I see, how do I do it?"
    new "می‌بینم، من چطور باید انجام بدم؟"

    # say L2057 pla
    old "It's simple, you're going to start in a tabletop pose."
    new "این ساده است، تو باید از پوزیسیون چهارپا شروع کنی."

    # say L2058 pla
    old "From there, just move your hips back and down while you leave your hands where they are."
    new "از اونجا، فقط با پایین و عقب حرکت کن، در حالی که دست‌هات جای خودشون باشه."

    # say L2059 pla
    old "That will give you a proper stretch through your shoulders and back."
    new "این به شانه‌ت و پشتت خوبه، اینجوری کشش می‌دونه."

    # say L2061 ang
    old "Hmm, ok, I think I can do that."
    new "Hmm، خوب، فکر کنم بتونم اینجوری بکنم."

    # say L2063 pla
    old "Yeah, and I'll be there to help you, so don't worry."
    new "بله، من همینجا هستم تا به تو کمک کنم، نگران نباش."

    # say L2065 ang
    old "Ok, let's try it."
    new "باشه، بیاین امتحان کنیم."

    # say L2068 ang
    old "Am I doing this right?"
    new "من اینو درست انجام می‌دم؟"

    # say L2071 pla
    old "Yeah, that's alright, but try to let go a little bit more."
    new "بله، خوبه، ولی بیشتر رها کن."

    # say L2072 ang
    old "A-alright."
    new "ب-bالا."

    # say L2080 ang
    old "{i}(What's this I'm starting to feel?){/i}"
    new "{i}(این چیه که شروع کردم حس کردن؟){/i}"

    # say L2081 pla
    old "{i}(What the hell? She's even more tense than before!){/i}"
    new "{i}(حیف! او حتی تنیده‌تر از قبله!){/i}"

    # say L2082 pla
    old "{i}(Why is she so stiff?){/i}"
    new "{i}(چرا اینقدر سخته؟){/i}"

    # say L2085 pla
    old "Ok, I think that's enough of this position, we can move on to the next one."
    new "باشه، فکر کنم این وضعیت کافیه، می‌تونیم به مرحله بعد بریم."

    # say L2093 pla
    old "Ok, you're doing well so far."
    new "خوب، تا حالا خوب کار کردی."

    # say L2094 pla
    old "But I think you're still a little tense. So I want us to change into a more relaxed position."
    new "ولی فکر می‌کنم هنوز یه کم تنیدی هستی. پس می‌خوام ما جابجا بشیم به یه وضعیت آرام‌تر."

    # say L2095 pla
    old "The idea for this next position is for you to relax and let go."
    new "ایده این موقعیت بعدی اینه که تو آرام شی و خودتو رها کنی."

    # say L2097 ang
    old "L-let myself go?"
    new "خودتو رها کنم؟"

    # say L2098 pla
    old "That's right, I want you to relax and just let your energy flow through the position."
    new "درست است، می‌خوام تو آرام شی و انرژیت رو در این وضعیت جریان بدهی."

    # say L2100 pla
    old "I can see that you have an energy block."
    new "می‌تونم ببینم که تو یه مسدودیت انرژی داری."

    # say L2102 pla
    old "If you keep going that way you won't be able to feel the energy flow through you."
    new "اگر همچین ادامه بدهی، نمی‌تونی انرژی رو در خودت حس کنی."

    # say L2104 ang
    old "I-I see, I think I get it."
    new "من متوجه شدم، بله."

    # say L2106 pla
    old "Ok, so be sure to just relax."
    new "باشه، پس فقط آرام شو."

    # say L2107 pla
    old "This next one's called Upavistha Konasana."
    new "این حرکت بعدی اسمش اپاویستا کوناساناه."

    # say L2108 pla
    old "Except that it's a modified version."
    new "البته، اما این یک نسخه اصلاح شده است."

    # say L2109 ang
    old "Modified? Will it be too hard?"
    new "تغییر یافته؟ خیلی سخت خواهد بود؟"

    # say L2110 pla
    old "Not at all, don't worry."
    new "البته نه، نگران نباش."

    # say L2112 pla
    old "It involves a forward fold while you push your legs outwards and reach for your ankles."
    new "این حرکت شامل تکان به جلو در حالی است که پاها رو به بیرون می‌اندازی و به پاشون خودت می‌رسونی."

    # say L2113 pla
    old "But I will be helping you, so you won't have to make much effort."
    new "اما من به تو کمک می‌کنم، پس نباید زیاد تلاش کنی."

    # say L2114 pla
    old "I'll help you by opening your legs with mine, and I'll pull you forward, so you just focus on the stretch through your groin and lower back."
    new "من با پایم کمک می‌کنم تا پاشو باز کنم و تو رو جلو بکشم، پس فقط روی اینکه گردن پاشو و پشت پایینت را کشش بدی تمرکز کن."

    # say L2116 ang
    old "Hmm, it sounds hard, but I'll trust you."
    new "Hmm، به نظر سخت می‌تونه باشه، اما به تو اعتماد می‌کنم."

    # say L2119 pla
    old "Alright, you're doing ok."
    new "باشه، خوبی."

    # say L2122 pla
    old "But try to let yourself go a little bit more. Ok?"
    new "اما سعی کن یک کم بیشتر خودت رو رها کنی. خوب؟"

    # say L2130 ang
    old "{i}(W- what is this I'm feeling again?){/i}"
    new "{i}(این حسی که دوباره احساس می‌کنم چیه؟){/i}"

    # say L2131 ang
    old "{i}(T-this... Is like what I felt that time.){/i}"
    new "{i}(این... مثل آن موقعیت هست.){/i}"

    # say L2132 pla
    old "{i}(W-what?! S-she's even more tense than before!){/i}"
    new "{i}(و-وای! س-سونی حتی تنیده‌تر از قبله!){/i}"

    # say L2134 pla
    old "Alright, I think that's enough for this position."
    new "باشه، فکر کنم این وضعیت کافی بود."

    # say L2142 pla
    old "Ok, I think that's enough for today."
    new "باشه، فکر کنم امروز کافیه."

    # say L2143 pla
    old "How did you feel?"
    new "حالت چطور بود؟"

    # say L2145 ang
    old "I- Uhmm... I think I felt alright."
    new "اوه... فکر کنم حس خوبی داشتم."

    # say L2146 ang
    old "I feel my body a lot more loose now."
    new "حالا بدنم خیلی راحت‌تر احساس می‌کنم."

    # say L2148 pla
    old "Hmph, well, as long as you don't feel bad, I guess that's ok."
    new "همف، خب، مادون بد حس نکنی، حدس می‌زنم اینجوری هم خوبه."

    # say L2149 pla
    old "Why don't we go down and let Lisa know that we're done?"
    new "بیای ببینیم لیزا رو بگم که تمام شدیم."

    # say L2167 lis
    old "Hello guys, are you done with the class?"
    new "سلام دوستان، کلاس تمام شد؟"

    # say L2171 lis
    old "Alright, and how did it go? How are you feeling right now Angelina?"
    new "البته، چطور انجام شد؟ حالا چطور احساس می‌کنی آنجلینا؟"

    # say L2173 ang
    old "It was good... Yeah, it was a good class."
    new "خوب بود... بله، کلاس خوبی بود."

    # say L2174 ang
    old "[pla] helped me through every position, and they weren't too difficult."
    new "[pla] همه حرکات رو به من نشون داد و خیلی سخت نبودند."

    # say L2176 lis
    old "I'm happy to hear that. [pla] knows very well what he's doing, so I was sure that it would be a good class."
    new "خوشحالم که اینجور شنیدم. [pla] خوب می‌دونه چی کار می‌کنه، پس مطمئنم بود که کلاس خوبی باشه."

    # say L2177 ang
    old "It was."
    new "بله، خوشحالم که اینجوری بود."

    # say L2178 ang
    old "I’m afraid it’s getting quite late, I must be going now."
    new "می‌تونم بگم وقت خیلی دیر شده، باید حالا برسم."

    # say L2180 ang
    old "Thanks a lot for the class [pla]."
    new "ممنون از کلاس [pla]."

    # say L2181 pla
    old "You are welcome."
    new "خواهش می‌کنم، لیزا. باید حالا برسم."

    # say L2184 ang
    old "Goodbye, Lisa. I’ll see you at the next class."
    new "خداحافظ، لیزا. دوباره هم می‌بینیم."

    # say L2185 lis
    old "See you next class, sweetheart. Take care."
    new "تا بعدی می‌بینم، عزیزم. مراقب خودت با."

    # say L2197 lis
    old "So? What did you think? How did it go?"
    new "پس؟ چه خبر بود؟ چطور اتفاق افتاد؟"

    # say L2198 pla
    old "Hmm, in general, I would say it was alright."
    new "خوب، به طور کلی می‌تونم بگم خوب بود."

    # say L2199 pla
    old "But I can see what you mean about her having some sort of energetic block."
    new "ولی من متوجه می‌شوم که تو می‌گیه اونجا یه بلوک انرژی داره."

    # say L2201 pla
    old "I felt that she was very tense in all the positions we did."
    new "احساسی داشتم که او همه وضعیت‌هایی که انجام دادیم، خیلی تنیدی بود."

    # say L2202 lis
    old "I see, so her energy's still blocked inside her."
    new "می‌بینم، پس انرژی‌اش هنوز درونش بسته است."

    # say L2204 pla
    old "Well, maybe that has to do with the fact that she's pregnant?"
    new "البته، شاید این به این برسونه که او بارداره."

    # say L2205 pla
    old "By the way, I would've liked to have known that before."
    new "باید اینجوری را قبلاً می‌دونستم."

    # say L2207 lis
    old "Oh, I failed to mention that, I'm sorry."
    new "اوه، اینو نگفتم، معذرت."

    # say L2208 lis
    old "But I don't think it makes such a difference."
    new "ولی فکر نمی‌کنم این خیلی تفاوت بکنه."

    # say L2209 lis
    old "What I've been feeling she lacks is that masculine energy I told you about."
    new "آن چیزی که من احساس می‌کنم در او نیست، آن انرژی مردانه‌ای است که به تو گفتم."

    # say L2210 lis
    old "So I think that it was still beneficial for her to have that session with you."
    new "پس فکر می‌کنم همچنان مفید بوده باشه که اون جلسه رو با تو داشته."

    # say L2212 pla
    old "I see, well, I sure hope that it actually helped her because she was just so tense during the session."
    new "باید امیدوار بودم که واقعاً به تو کمک کرده باشه، چون توی جلسه خیلی تنیده بودی."

    # say L2214 lis
    old "Her next session's with me, so I'll see how her energy's changed. I'll let you know how she's doing."
    new "جلسه بعدی او با من هست، پس خواهم دید انرژی‌اش چطور تغییر کرده. اطلاع می‌دم که چطور است."

    # say L2217 lis
    old "Before you head out, there's something I'd like to discuss with you."
    new "قبل از برخاستن، چیزی هست که می‌خوام با تو بحث کنم."

    # say L2218 pla
    old "Uh, sure. What's on your mind?"
    new "آره، حتماً. چه کاری به ذهنت رسیده؟"

    # say L2219 lis
    old "Well, recently, I've been doing very well."
    new "خوب، اخیراً وضعیتم خیلی خوب است."

    # say L2220 lis
    old "I've gotten a good number of new clients, and they seem to be very happy with my classes."
    new "من مشتریان جدید زیادی پیدا کردم، و به نظر می‌رسه از کلاس‌هام خوشحال‌اند."

    # say L2221 lis
    old "I'm very happy with how things have been going lately."
    new "خوشحالم که اوضاع خوب هستند."

    # say L2223 pla
    old "That sounds great! Congrats, Lisa!"
    new "این خوبه! مبارک، لیزا!"

    # say L2224 lis
    old "Thanks, [pla]."
    new "ممنون، [pla]."

    # say L2225 lis
    old "But you see, some of my students are actually becoming very advanced in yoga."
    new "اما می‌بینی، بعضی از دانش‌آموز‌هامون در یوگا واقعاً پیشرفت زیادی کردن."

    # say L2226 lis
    old "So, I'm pondering what else I can offer my clients in the way of spiritual guidance and development."
    new "پس در حال فکر کردن هستم که چه چیز دیگری می‌توانم برای مشتریانم در زمینه راهنمایی و رشد معنوی ارائه کنم."

    # say L2230 lis
    old "Especially because my work goes beyond just yoga and meditation, you have seen it."
    new "به خصوص اینکه کار من فراتر از یوگا و مدیتیشن است، شما دیده‌اید."

    # say L2231 lis
    old "Rather than just a yoga guru, I want to be known as a complete spiritual wellness guide."
    new "به جای اینکه فقط یک مربی یوگا باشم، می‌خواهم به عنوان یک راهنما کامل برای سلامت روحی شناخته شوم."

    # say L2232 lis
    old "So that my students can progress in whatever way they feel benefits them the most."
    new "توسط این، دانشجویان من می‌توانند در هر روشی که برایشون مفیدتر است، پیشرفت کنند."

    # say L2233 pla
    old "Ok, that sounds like a very good idea."
    new "باشه، این یه ایده خوبه."

    # say L2235 lis
    old "Thanks, [pla]. So I came up with the idea of adding classes in mindfulness, transcendental meditation."
    new "ممنون، [pla]. پس ایده‌ی من این بود که درس‌هایی در مورد آگاهی و مدیتیشن تراش‌پا را اضافه کنم."

    # say L2236 lis
    old "As well as Tai Chi, Reiki, and Tantric sex."
    new "همچنین تای چی، رایکی و جنس تانتریک."

    # say L2237 lis
    old "And different healing treatments, like Chakra Healing, Acupuncture, Sound Healing, and herbal medicines."
    new "و درمان‌های مختلفی مثل درمان چاکرا، نålبرد و درمان صوتی و داروهای گیاهی."

    # say L2238 pla
    old "I- I see, that's a lot."
    new "من متوجه شدم، این همه چیز."

    # say L2240 pla
    old "So you want to expand your portfolio, right?"
    new "پس می‌خوای به پروژه‌ات افزوده کنی، دیگه؟"

    # say L2242 lis
    old "Hmm... Yeah, to put it in simpler terms."
    new "Hmm... بله، به طور ساده‌تر بگویم."

    # say L2244 lis
    old "Of course, I intend to implement this gradually. I’d like to conduct a few tests before applying it to additional clients."
    new "البته، من قصد دارم این را تدریجی انجام بدم. چند آزمایش می‌خوام بکنم قبل از اینکه برای مشتریان بیشتری استفاده کنم."

    # say L2245 pla
    old "That makes sense, so, Do you already have a plan for how to begin?"
    new "این منطقیه، پس، قراره از کجا شروع کنی؟"

    # say L2247 lis
    old "Well, I have this client that's been working with me for a while."
    new "خب، من یک مشتری دارم که از زمانی با من همکاری می‌کنه."

    # say L2249 lis
    old "And she has in fact asked me several times about the possibility of having tantric sex sessions."
    new "و در واقع چند بار از من پرسیده که آیا می‌توانیم جلسات جنسی تانتریک برگزار کنیم."

    # say L2250 pla
    old "I see, well, that makes a lot of sense, and if she wants to do it, I think it's a great idea."
    new "باید همینطور باشه، اگه او خواست، من هم فکر می‌کنم ایده خوبیه."

    # say L2252 lis
    old "Yes, and you see, this client's Anastasia."
    new "بله، و می‌بینی، این مشتری آناستازیا هست."

    # say L2254 pla
    old "Oh, I see, I think she did mention that."
    new "او، من متوجه شدم، فکر کنم همینجوری هم گفت."

    # say L2256 lis
    old "Yeah, and given that she's relatively advanced in her yoga journey, I think this would be a good moment to introduce her to more advanced concepts."
    new "بله، و با توجه به اینکه او در مسیر یوگا پیشرفت زیادی کرده، فکر می‌کنم این زمان مناسبی برای معرفی مفاهیم پیشرفته‌تر است."

    # say L2257 lis
    old "Especially tantric sex, I think it would be good for her to follow that practice."
    new "به ویشه جنس تانتریک، فکر می‌کنم برایش خوب است که این را دنبال کند."

    # say L2258 lis
    old "After all, the benefits are great, I think it would really help her with reducing stress and improving her relaxation."
    new "در نهایت، مزایایش زیاد هست، فکر می‌کنم واقعاً به کاهش استرس و بهبود آرامش‌اش کمک می‌کنه."

    # say L2260 lis
    old "Which will help her with her sleep."
    new "این به خوابش کمک خواهد کرد."

    # say L2262 lis
    old "Not to mention her sexual satisfaction, which I believe is clear to the both of us she needs to improve on."
    new "البته، رضایت جنسی او هم که برای هر دو ما واضح است که باید بهبود یابد."

    # say L2264 lis
    old "But more importantly, her personal and spiritual growth, tantra will help her with it, and I believe she'll benefit greatly from it."
    new "اما مهمتر از همه، رشد شخصی و روحی او، تانترا بهش کمک خواهد کرد و فکر می‌کنم از این کار سود زیادی خواهد برد."

    # say L2265 pla
    old "All of that sounds great, I'm sure you'll have a great time teaching her."
    new "همه اینا عالی به نظر می‌رسه، مطمئنم تو خوشحال می‌شی."

    # say L2267 lis
    old "Well, since you mentioned it, that's where you come in."
    new "خب، چون به این موضوع اشاره کردی، اینجا تو نقش داری."

    # say L2269 lis
    old "Anastasia asked me if it would be possible for you to accompany us during the tantric sex sessions."
    new "آناستازیا از من پرسید که آیا ممکنه تو هم در جلسات سکس تانتریک با ما همراه باشی."

    # say L2270 pla
    old "M-Me? Do you need me to be there?"
    new "من؟ می‌خوای من هم حاضر باشم؟"

    # say L2271 pla
    old "I mean, with your experience, I don't see why I would need to be there. Don't you just do that directly?"
    new "من قصد دارم با تجربه‌ات، نمی‌فهمم چرا باید من هم حاضر باشم. تو این کار رو مستقیم نمی‌کنی؟"

    # say L2273 lis
    old "Of course I can teach her everything, but the reason I want you to go there is to be my assistant."
    new "البته می‌تونم همه چیز رو بهش یاد بدم، ولی دلیلی که می‌خوام تو هم بیایی اینه که به عنوان کمک‌کننده‌ام باشی."

    # say L2275 pla
    old "Your assistant?"
    new "مساعدتت؟"

    # say L2277 lis
    old "Yeah, that's right, but not in the way that you may think of."
    new "بله، همینه، اما نه به ترتیبی که شاید فکر می‌کنی."

    # say L2278 lis
    old "What I need from you is that you play the role of an intermediary between Anastasia and me."
    new "آنچه از تو می‌خواهم اینه که نقش میانجی بین آناستازیا و من رو بازی کنی."

    # say L2280 pla
    old "I-I'm not sure I get what you're saying."
    new "من-من مطمئن نیستم که منظورت رو درک کردم."

    # say L2282 lis
    old "Think about it [pla], you've already worked with Anastasia in the past, so she's comfortable with you in that sense."
    new "فکر کن [pla]، تو قبلاً با آناستازیا همکاری کردی، پس از این نظر او با تو راحت است."

    # say L2283 lis
    old "So, when I'm doing the sessions with her, your role will be to help her feel more relaxed and comfortable."
    new "پس وقتی من جلسات رو باش انجام میدم، نقش تو اینه که بهش کمک کنی آرام‌تر و راحت‌تر بشه."

    # say L2284 lis
    old "So that the session can flow smoothly and without any problems."
    new "تا جلسه بدون هیچ مشکلی و به صورت روان انجام شه."

    # say L2286 pla
    old "Hmm, I see, that makes quite a lot of sense."
    new "هم، من متوجه شدم، این کاملاً معقول است."

    # say L2288 pla
    old "But hey, you and I are still working on my own tantric session."
    new "اما هی، تو و من هنوز روی سشن تانتریک من کار می‌کنیم."

    # say L2289 pla
    old "Are you sure it will be a good idea for me to be there? Wouldn't it be better if it's just the two of you?"
    new "مطمئنی که حضور من خوبه؟ آیا بهتر نیست فقط شما دو تایتان باشید؟"

    # say L2290 lis
    old "Well, at the beginning I did think it strange when she asked for it."
    new "البته در ابتدا وقتی از این خواست، عجیب به نظر می‌رسید."

    # say L2291 lis
    old "But it makes a lot of sense since you've already helped her with her chakra balancing in the past."
    new "اما این معنی داره، چون قبلاً تو به او در توازن چاکرایش کمک کردی."

    # say L2293 lis
    old "In addition, I believe it would be good practice for you, it would be a good way for you to work with other clients in the future. If the opportunity arises of course."
    new "البته، فکر می‌کنم برای تو تمرین خوبی باشه، راه خوبی برای کار با مشتریان بعدی هم باشه. البته اگه فرصت پیش بیاد."

    # say L2295 lis
    old "But of course, it all depends on you, if you feel the universe is guiding you towards a teaching role."
    new "البته، همه چیز از خودت بستگی داره، اگر حس کنی که جهان تو رو به نقش معلم هدایت می‌کنه."

    # say L2297 lis
    old "If you don't feel like it, there's no problem, I'll understand."
    new "اگر حس نمی‌کنی، هیچ مشکلی نداره، من درک می‌کنم."

    # say L2299 pla
    old "Oh, no, no, there's no problem with it. I'll do it, with the way you explain it, it makes a lot of sense."
    new "اوه، نه، هیچ اشکالی نداره. من انجام میدم، با طرز توضیحاتت، خیلی معقول به نظر میرسه."

    # say L2301 lis
    old "Excellent [pla]! Thank you very much! I know it's going to be great."
    new "عالی [pla]! ممنون خیلی. میدونم خوب میشه."

    # say L2302 lis
    old "I’ve scheduled an appointment for tomorrow evening, would you happen to be available?"
    new "من برای فردا شب وقت تعیین کردم، شاید وقت داری؟"

    # say L2304 pla
    old "Uhh, I think so."
    new "آره، فکر کنم هستم."

    # say L2306 lis
    old "Wonderful, I'll get everything ready, and I'll see you later."
    new "عالی، همه چی رو آماده می‌کنم، بعداً می‌بینیم."

    # say L2308 pla
    old "Sure, goodbye then."
    new "بله، خداحافظ."

    # say L2335 pla
    old "Anastasia, hi. You're already here, great."
    new "آناستازیا، سلام. قشنگه که قبلاً اومدی."

    # say L2338 ana
    old "Yeah, I just arrived, Lisa wasn't here so I decided to wait a while."
    new "بله، همین جا رسیدم، لیزا اینجا نبود پس تصمیم گرفتم یه کم صبر کنم."

    # say L2340 pla
    old "Oh, she's probably already up in the yoga room waiting for us."
    new "اوه، احتمالاً بالای اتاق یوگا منتظرمونه."

    # say L2344 pla
    old "Sure, let's go up."
    new "بله، برویم بالا."

    # say L2369 ana
    old "Oh! Hi Lisa, [pla] and I ran into each other in your living room and..."
    new "اوه! سلام لیزا، [pla] و من در اتاق نشیمن تو با هم برخورد کردیم و..."

    # say L2373 lis
    old "Hmm, Anastasia are you alright?"
    new "هم، آناستازیا، حالت خوبه؟"

    # say L2374 ana
    old "Yeah, sorry, sorry."
    new "بله، معذرت، معذرت."

    # say L2376 ana
    old "It's just that the outfit you're wearing... It surprised me."
    new "البته، فقط به خاطر لباسی که پوشیده‌ای... من را شوک داد."

    # say L2379 lis
    old "I see, that's understandable, but these collars are necessary for what we're about to do."
    new "می‌فهمم، این قابل درکه، اما این گردن‌بند‌ها برای کاری که می‌خوایم انجام بدیم ضروری هستند."

    # say L2380 lis
    old "They're an important element that will help to keep the balance of your chakras."
    new "آنها عنصر مهمی هستند که به توازن چاکره‌هایت کمک می‌کنند."

    # say L2382 ana
    old "I-I see."
    new "م-Mی‌بینم."

    # say L2384 lis
    old "Yes, because you see, this is a physical process, so the idea is to be fully in contact with our energies."
    new "بله، زیرا این یک فرآیند فیزیکی است، پس هدف این است که کاملاً با انرژی‌هایمان در ارتباط باشیم."

    # say L2385 lis
    old "So we need to get rid of everything that could get in the way of that connection. Of course, our clothes are part of that."
    new "پس باید هر چیزی که می‌تونه این ارتباط رو مختل کنه رو برداشتیم. البته لباس‌هامون هم بخشی از اونه."

    # say L2386 ana
    old "D-Does that mean that I will be naked too?"
    new "آ-آیا این به معنی اینه که من هم باید عریان باشم؟"

    # say L2388 lis
    old "Of course, but don't worry about it, this is a spiritual process, and both [pla] and I are very professional about it."
    new "البته، ولی نگران نباش، این یک فرآیند روحی است و هم [pla] و هم من در این زمینه خیلی حرفه‌ای هستیم."

    # say L2390 ana
    old "I-I see, I understand."
    new "م-Mی‌بینم، متوجه شدم."

    # say L2392 lis
    old "Good, then let's get started. Why don't you go ahead into the yoga room and get ready?"
    new "خوب، پس شروع کنیم. چرا نمی‌روی به اتاق یوگا و آماده شی؟"

    # say L2393 lis
    old "[pla] and I will go in a minute."
    new "[pla] و من یه لحظه بعد می‌رویم."

    # say L2394 ana
    old "Sure, I'll do that. So, I have to get naked in there?"
    new "بله، من اینجوری می‌کنم. پس باید توی اونجا خالی شم؟"

    # say L2396 lis
    old "Yes, the idea is that you'll be ready for when [pla] and I come in."
    new "بله، ایده اینه که وقتی ما و [pla] داخل می‌شویم، تو آماده باشی."

    # say L2398 ana
    old "I see, I'll do it then."
    new "می‌فهمم، انجام می‌دم."

    # say L2404 lis
    old "Alright, you know what the idea is, right? You'll support me during the session, and you'll also be without any clothes."
    new "البته، میدونی ایده چیه، در طول جلسه مرا حمایت می‌کنی و همچنین بدون لباس خواهی بود."

    # say L2406 pla
    old "Yeah sure, no problem."
    new "بله حتماً، هیچ مشکلی ندارم."

    # say L2408 lis
    old "However, for this session onwards, I prepared a special outfit for you."
    new "البته، اما برای این جلسه به بعد، لباس خاصی برای تو آماده کردم."

    # say L2409 pla
    old "A- a special outfit?"
    new "یه لباس خاص؟"

    # say L2411 lis
    old "Yes, up until now I've been guiding you in this development journey."
    new "بله، تا حالا من تو را در این سفر رشد هدایت می‌کردم."

    # say L2412 lis
    old "But today you will be the one taking the position of the guide. From now on, you'll be a Yogi."
    new "اما امروز تو خودت راهنما خواهی بود. از حالا به بعد یوگی خواهی شد."

    # say L2415 lis
    old "A yogi, that's the title that a yoga instructor receives when they're guiding somebody."
    new "یوگی، این عنوانی است که مربی یوگا وقتی کسی را هدایت می‌کند دریافت می‌کند."

    # say L2416 lis
    old "You're not a guru, like I am, but I think it's appropriate that I call you a Yogi, especially because you've already guided Anastasia on the right path."
    new "تو یک گورو مثل من نیستی، اما فکر می‌کنم مناسبه که تو رو یوگی بخونم، خصوصاً چون تو قبلاً آناستازیا رو به راه درست هدایت کردی."

    # say L2417 lis
    old "That's why I prepared a special outfit for you. You being on another level needs to be reflected in what you're wearing."
    new "به همین خاطر لباس خاصی برایت آماده کردم. اینکه تو روی سطح بالاتری هستی باید در لباست نشون بده."

    # say L2418 lis
    old "That and because they're needed to protect and balance your energy."
    new "و این برای محافظت و توازن انرژی تو ضروری هست."

    # say L2419 pla
    old "I-I see, thank you, Lisa."
    new "ب-bبینم، ممنونم، لیزا."

    # say L2421 lis
    old "You're more than welcome. Now go and get changed. Anastasia is waiting for us."
    new "خواهش می‌کنم. حالا برو و لباست را عوض کن. آناستازیا منتظر ما هست."

    # say L2422 lis
    old "You'll find what you have to wear on the bed."
    new "پوششی که باید بپوشی روی تخت قرار دادم."

    # say L2441 pla
    old "S- so, I wasn't sure if I was putting it on correctly, but I saw some instructions over the bed."
    new "ب-b من مطمئن نبودم اینو درست گذاشتم، ولی روی تخت دیدم چند دستورالعمل بود."

    # say L2442 pla
    old "What do you think? Does it fit me properly?"
    new "چی می‌گی؟ آیا روی من خوب نشسته؟"

    # say L2443 lis
    old "It does, you look great, like a proper yogi."
    new "بله، خیلی خوب می‌شین، مثل یک یوگا‌گر اصیل."

    # say L2444 lis
    old "Let's go in, Anastasia's waiting for us."
    new "بیای بیرون، آناستازیا منتظرمون هست."

    # say L2473 pla
    old "{i}(I sometimes forget that Anastasia's so hot.){/i}"
    new "{i} بعضی مواقع فراموش می‌کنم که آناستازیا چقدر خوبه. {/i}"

    # say L2478 ana
    old "You look like a proper shaman now."
    new "حالا مثل یک شامان واقعی به نظر می‌رسی."

    # say L2481 lis
    old "Hahaha, what [pla]'s wearing is actually a very important part of the tantra ritual that we're going to be performing with you."
    new "هahaha، لباسی که [pla] پوشیده واقعاً بخش مهمی از مراسم تانترا هست که قراره با تو انجام بدیم."

    # say L2482 lis
    old "Because the idea is that this is as good an experience for you as we can make it."
    new "چون هدف اینه که این تجربه بهترین حالت برای تو باشه."

    # say L2483 lis
    old "So, are you ready to start?"
    new "پس، آماده‌ای برای شروع؟"

    # say L2485 ana
    old "Oh yeah, for sure, I've been waiting for this."
    new "بله، حتماً، از این بابت منتظر بودم."

    # say L2486 ana
    old "I'm a little nervous."
    new "من یکم ناراحت هستم."

    # say L2487 ana
    old "But once we start, I'm sure I'll feel a lot better."
    new "اما وقتی شروع کنیم، مطمئنم حس خوبی خواهم داشت."

    # say L2491 lis
    old "Listen, Anastasia, I understand the type of situation this is, and how arousing it potentially is."
    new "اناستازیا، من می‌فهمم این چه موقعیتیه و چقدر تحریک‌کننده می‌تونه باشه."

    # say L2493 lis
    old "But it's important that you keep in mind that this is not for the sake of having sex."
    new "اما مهم اینه که به ذهن داشته باشی این برای جنس نیست."

    # say L2495 lis
    old "The most important part of this whole process is to learn to control those sexual impulses that sometimes take hold of us."
    new "بخش مهم‌ترین این کل فرآیند یادگیری کنترل آن تحریک‌های جنسی است که گاهی ما را در اختیار خود می‌گیرند."

    # say L2497 lis
    old "So my focus for you during this whole process is that you are able to balance your chakras and put your energy in order."
    new "پس تمرکز من برایت در طول این فرآیند اینه که بتونی چاکرات رو تعادل بدی و انرژیت رو مرتب کنی."

    # say L2499 ana
    old "Hmm, yeah, I guess you're right, but does that mean that we won't be having sex?"
    new "Hmm، بله، حدس می‌زنم درست می‌گویی، اما این به معنای اینه که ما جنس نخواهیم کرد؟"

    # say L2501 lis
    old "In the most strict sense of the word, no."
    new "در معنای دقیق کلمه، نه."

    # say L2502 lis
    old "We will come to it when the time comes, but what's most important is that you are able to relax."
    new "وقتی زمان برسه خواهیم رسید، اما مهم‌ترین چیز اینه که تو بتونی آرام شی."

    # say L2503 lis
    old "To control your sexual energy and come to internal balance with your energy and chakras."
    new "توی کنترل انرژی جنسی خودت باش و به تعادل داخلی با انرژیت و چاکرات برس."

    # say L2505 lis
    old "Now, let's get started so that you can see how this process feels."
    new "حالا، بیای بگذاریم شروع کنیم تا ببینی این فرآیند چطور احساس می‌کنی."

    # say L2507 ana
    old "O-Okay, sure."
    new "باشه، حتماً."

    # say L2508 lis
    old "So, before we start with the first session, I want you to keep in mind that you need to focus on your breathing and relaxing your body."
    new "پس، قبل از شروع جلسه اول، می‌خوام تا به ذهنت برسونی که باید روی نفس‌ت تمرکز کنی و بدنت رو آرامش بدی."

    # say L2509 lis
    old "Let yourself go and listen to my instructions while you keep your breathing constant."
    new "خودت رو رها کن و به دستورات من گوش بده در حالی که نفست رو ثابت نگه می‌داری."

    # say L2529 lis
    old "I want to congratulate you, Anastasia."
    new "می‌خوام تبریکت بکنم، آناستازیا."

    # say L2530 lis
    old "The fact that you were able to truly connect with yourself by doing this therapy."
    new "اینکه بتونی با خودت واقعاً ارتباط برقرار کنی با این درمان."

    # say L2531 ana
    old "I was surprised by how good it feels, I wasn't expecting it. Thank you so much, Lisa! And you too, [pla]."
    new "متعجب شدم از اینکه چقدر خوب احساس شد، منتظر این نبودم. ممنونم خیلی، لیزا! و تو هم، [pla]."

    # say L2532 lis
    old "I'm glad I'm able to help you."
    new "خوشحالم که می‌تونم به تو کمک کنم."

    # say L2533 lis
    old "But there still remains much to be done."
    new "ولی هنوز کار زیادی باقی مونده."

    # say L2534 lis
    old "So we will continue during the next session, ok?"
    new "پس در جلسه بعد ادامه میدیم، خوبه؟"

    # say L2536 ana
    old "Oh, we're done? I thought that maybe we could do some more..."
    new "اوه، خاتمه پیدا کرد؟ فکر کردم می‌تونیم کمی بیشتر هم انجام بدیم..."

    # say L2538 lis
    old "I understand that you may feel like it, but we're doing this little by little."
    new "فهمیدم که احتمالاً احساس می‌کنی اینجوری باشه، ولی ما این کار رو کم کم می‌کنیم."

    # say L2539 lis
    old "Besides, you may not feel like it now, but you need to rest before you can do more. Believe me, you'll feel it later."
    new "البته، حالا ممکن است خواسته نباشی، اما باید قبل از اینکه بیشتر کار کنی، استراحت کنی. باور کن، بعداً احساسش می‌کنی."

    # say L2541 ana
    old "Hmm, ok, I get it."
    new "Hmm، خوب، متوجه شدم."

    # say L2543 lis
    old "Yes, by the way, it's getting a little late."
    new "بله، اصلاً وقتش هم پیش می‌رود."

    # say L2544 lis
    old "It's better if we get changed and ready for you to return home."
    new "بهتره که لباسمون رو عوض کنیم و آماده برگشتن به خونه شویم."

    # say L2551 lis
    old "Well, I would say that was a very good first session. I'm glad with the progress you made today, Anastasia."
    new "البته، می‌تونم بگم این جلسه اول خیلی خوب بود. خوشحالم که امروز پیشرفت کردی، آناستازیا."

    # say L2553 ana
    old "Thank you very much, Lisa. I wasn't expecting it to be that good, but it was amazing."
    new "ممنونم، لیزا. انتظار نداشتم اینقدر خوب باشه، ولی واقعاً شگفت‌انگیز بود."

    # say L2554 ana
    old "And of course, thanks to you too, [pla]. With you here, I was able to feel so much more comfortable."
    new "و البته ممنون از تو هم، [pla]. با تو اینجا، خیلی راحت‌تر حس کردم."

    # say L2557 lis
    old "She's right, [pla]. You being here really brings our energies to a state of balance. Thanks a lot."
    new "درست می‌گه، [pla]. حضورت واقعاً انرژی‌هامون رو به تعادل می‌بره. ممنون ازت."

    # say L2558 pla
    old "Oh, well, I'm happy to help."
    new "البته، خوشحالم که کمک کردم."

    # say L2560 ana
    old "Anyway, it's getting a bit late, so I should head out. I can’t wait for the next tantric class."
    new "البته، وقت شده کمی دیر، باید برسم. نمی‌تونم صبر کنم تا کلاس تانتری بعدی."

    # say L2561 lis
    old "Goodbye, darling, see you at the next yoga session this afternoon."
    new "خداحافظ، عزیزم، ببینم تو رو در جلسه یوگا بعدی."

    # say L2562 pla
    old "Good night, have a great evening."
    new "شب خوبی داشته باش، عصر خوبی بگذران."

    # say L2564 ana
    old "Oh, of course I'll have a wonderful night. Thanks again, you two."
    new "البته شب خوبی خواهم داشت. ممنون از شما دو تا."

    # say L2574 lis
    old "Oh [pla], I think it was a total success, I could feel our energies connecting and merging during the tantric exercise."
    new "اوه [pla]، فکر کنم کاملاً موفق بود، می‌تونستم انرژی‌هامون به هم متصل و ترکیب شدن رو حس کنم در طی تمرین تانترا."

    # say L2575 lis
    old "I definitely believe the universe is opening a door for my business. It's calling me to guide more clients spiritually. Did you feel it too?"
    new "من قطعاً معتقدم جهان در حال باز کردن یک در برای کسب و کار من است. این به من فراخوان می‌دهد تا بیشتر مشتریان را روحانی هدایت کنم. تو هم احساس کردی؟"

    # say L2577 pla
    old "Uhh, y- yeah, I totally felt it, that energy was... Definitely something."
    new "اوه، بله، همه‌ش رو حس کردم، آن انرژی واقعاً چیزی بود."

    # say L2578 lis
    old "Right? It was almost a religious experience."
    new "درسته؟ تقریباً تجربه‌ای مذهبی بود."

    # say L2579 lis
    old "Oh wow, look at the time, it's really late."
    new "اوه وای، نگاه کن به ساعت، واقعاً خیلی دیر شده."

    # say L2580 lis
    old "Ugh, I wanted to talk to you about Angelina, but I think we'll leave that for another day."
    new "اوه، می‌خواستم با تو در مورد آنجلینا صحبت کنم، اما به نظر می‌رسد باید این رو برای روز دیگر بگذاریم."

    # say L2581 lis
    old "Could you swing by in the afternoon so we can talk? It won't take long."
    new "می‌تونی بعد از ظهر بیادی تا حرف بزنیم؟ طول نمی‌کشه."

    # say L2582 pla
    old "Uhh, yeah, sure. No problem."
    new "آره، حتماً. مشکلی نداره."

    # say L2583 lis
    old "Perfect. Let's leave it here so you can get some rest. You've helped me a lot today, [pla]. Thanks."
    new "عالی. بیا اینجا تا بتوانی راحت شوی. امروز خیلی به من کمک کردی، [pla]. ممنون."

    # say L2601 pla
    old "Hi Lisa, how are you?"
    new "سلام لیزا، حالت چطوره؟"

    # say L2603 lis
    old "Hey, my energy’s flowing beautifully today, how about you?"
    new "سلام، انرژی من امروز خوب جریان داره، تو چطوری؟"

    # say L2604 pla
    old "I'm fine... Thanks for asking."
    new "من خوبم... ممنون که پرسیدی."

    # say L2605 pla
    old "I came about that thing you mentioned, you wanted to talk about Angelina."
    new "من برای همون چیزی که گفتی اومدم، می‌خواستی در مورد آنجلینا صحبت کنیم."

    # say L2606 lis
    old "Oh, yes, of course. Thanks for coming."
    new "بله، البته. ممنون که اومدی."

    # say L2607 lis
    old "Well, I had a session with her, and she asked me if you could be the teacher in her next class."
    new "خب، من جلسه‌ای با او داشتم و از من پرسید که آیا تو می‌تونی در کلاس بعدی‌اش معلم باشی."

    # say L2609 pla
    old "She did?!"
    new "او همین‌جوری کرد؟!"

    # say L2611 lis
    old "Uhh, yes, why are you so surprised?"
    new "اوه، بله، چرا اینقدر شوکه شدی؟"

    # say L2613 pla
    old "Well, I just wasn't expecting that."
    new "خب، من فقط انتظار نداشتم اینجوری باشه."

    # say L2614 pla
    old "Because last time she almost looked uncomfortable during the class."
    new "چون آخر بار تقریباً ناراحت به نظر می‌آمد در کلاس."

    # say L2615 pla
    old "So it's kind of a surprise that you tell me she wants another class with me."
    new "پس مفاجاً هست که می‌گی‌ی این بار هم می‌خواد با من کلاس بگذرونه."

    # say L2617 lis
    old "Well, she had another class with me after yours."
    new "خب، او بعد از کلاس تو هم دوباره با من کلاس داشت."

    # say L2618 lis
    old "And yes, I've noticed that her energy seems stuck. Her Muladhara chakra is completely out of balance."
    new "و بله، متوجه شدم که انرژی‌اش گیر زده. چاکرای مولاذارایش کاملاً از توازن خارج شده."

    # say L2619 lis
    old "And it's affecting the flow of prana through her nadis. There might be a deep-rooted samskara causing this blockage."
    new "و این مشکل جریان پرانا در ندی‌هاش رو تاثیر می‌ذه. ممکنه سامسکارای عمیقی باعث این مسدودی شده باشه."

    # say L2620 lis
    old "But after her class with you, I've noticed her blockage has started to dissipate."
    new "ولی بعد از کلاسش با تو، دیدم مسدودیت‌اش شروع کرده به حل شدن."

    # say L2622 pla
    old "For real?"
    new "وای، همینجوری؟"

    # say L2624 lis
    old "Yes, I've noticed that after her session with you, her energy has started to flow a lot better inside her."
    new "بله، بعد از جلسه‌اش با تو، انرژی‌اش داخل خودش بهتر شروع به جریان کردن کرده."

    # say L2626 pla
    old "Hmm, I have to say, that's a surprise."
    new "هم، باید بگم، این برایم مفاجا است."

    # say L2627 pla
    old "But if you say that it's alright, and she actually requested another session with me, then I guess it's alright."
    new "البته، اگر تو می‌گیه که خوبه و او هم درخواست کرد که دوباره با من جلسه داشته باشه، پس فکر کنم خوبه."

    # say L2629 lis
    old "It is, if she wants to see you again, it means you did a very good job."
    new "اگر می‌خواهد دوباره تو رو ببینه، باید کارت خوب بوده باشه."

    # say L2631 pla
    old "Uhh, alright..."
    new "اوه، خوب..."

    # say L2633 lis
    old "So, can I count on you for the next session with Angelina?"
    new "پس، می‌تونم برای جلسه بعدی با آنژلینا به تو اعتماد کنم؟"

    # say L2635 pla
    old "Sure, sure, no problem."
    new "بله، حتماً، هیچ اشکالی ندارم."

    # say L2637 lis
    old "That's wonderful [pla], thanks a lot."
    new "عالیه [pla]، ممنون زیادی."

    # say L2638 lis
    old "I'll go ahead and schedule Angelina's next yoga session."
    new "من الان جلسه یوگا بعدی آنجلس رو برنامه می‌ذارم."

    # say L2639 lis
    old "So, as you know, I'll see you this afternoon for your next yoga class."
    new "پس، همانطور که می‌دونی، امروز بعد از ظهر برای کلاس یوگا بعدی تو می‌ام."

    # say L2641 pla
    old "Sure, count on it."
    new "بله، می‌تونی روی من حساب کنی."

    # say L2642 lis
    old "Thank you so much [pla], the universe has great things in store for you!"
    new "ممنون زیادی [pla]، جهان برایت چیزهای خوبی در نظر داره."

    # say L2643 pla
    old "Heh, thanks. Well, I guess I'll see you later. Bye."
    new "هه، ممنون. خب، به نظر می‌رسه بعداً می‌بینیم. بای."

    # say L2644 lis
    old "Goodbye [pla], take care."
    new "خداحافظ [pla]، مراقب خودت با."

    # say L2671 lis
    old "Oh, hi [pla]! it's good to see you."
    new "اوه، سلام [pla]! خوشحالم که دوباره دیدمت."

    # say L2674 pla
    old "Hi, have you been waiting too long for me?"
    new "سلام، خیلی وقت برای من منتظر نبودی؟"

    # say L2676 lis
    old "Not at all, Angelina just arrived a couple of minutes ago."
    new "البته، آنجلینا فقط چند دقیقه پیش رسید."

    # say L2677 lis
    old "So you're just in time for the class."
    new "پس تو هم زمان کلاس رو از دست ندادی."

    # say L2678 lis
    old "But it's better if you don't lose time."
    new "اما بهتره وقتت رو از دست ندهی."

    # say L2680 lis
    old "So why don't you two go upstairs to the yoga room?"
    new "پس چرا دو نفرتون نمی‌روین به بالا به اتاق یوگا؟"

    # say L2682 pla
    old "Sure, we'll see you later then."
    new "بله، بعداً می‌بینیم."

    # say L2692 pla
    old "Alright, I guess that if you're feeling alright, we can get started with the session."
    new "باشه، اگه حالت خوبه، می‌تونیم جلسه رو شروع کنیم."

    # say L2694 ang
    old "S- sure, let's do it."
    new "ب-له، بیاییم انجام بدیم."

    # say L2695 pla
    old "{i}(Hmm, she's still feeling uncomfortable? It's a surprise that she wanted another session.){/i}"
    new "{i}(حالم خوبه، اما به نظر می‌رسه هنوز آسون نیست؟ شگفت‌زده‌ام که می‌خواسته دوباره جلسه داشته باشه.){/i}"

    # say L2696 pla
    old "{i}(I guess she'll relax when we start with the asanas.){/i}"
    new "{i}(به نظر می‌رسه وقتی با آساناها شروع کنیم آرام می‌شه.){/i}"

    # say L2697 pla
    old "Okay, let's get started with the first position then."
    new "باشه، بیای بریم به اولین وضعیت."

    # say L2706 ang
    old "{i}(I didn't notice before, but this is a very comfortable position.){/i}"
    new "{i}(قبلش متوجه نشده بودم، اما این وضعیت خیلی راحت است.){/i}"

    # say L2707 pla
    old "Ok, I see you're doing a little better than last time."
    new "باشه، می‌بینم این بار بهتر از قبل هستی."

    # say L2708 ang
    old "T-Thank you."
    new "ممنون."

    # say L2709 pla
    old "That's it, you're doing very well."
    new "این هست، خوب کار می‌کنی."

    # say L2710 pla
    old "{i}(Well, her movement's a lot more smooth.){/i}"
    new "{i}(حالتون خیلی هموار تر شده.){/i}"

    # say L2711 pla
    old "{i}(That's very good, she's very focused.){/i}"
    new "{i}(این خیلی خوبه، او خیلی متمرکزه.){/i}"

    # say L2712 pla
    old "You're doing very, very well."
    new "خیلی خوب می‌کنی."

    # say L2714 pla
    old "Remember to keep focusing on your breathing and how your muscles feel."
    new "به تمرکز بر تنفست و احساس عضلاتت دقت کن."

    # say L2715 pla
    old "Excellent, I think we can stop there."
    new "عالی، فکر کنم می‌تونیم اینجا متوقف شیم."

    # say L2726 pla
    old "Alright! That was an excellent start!"
    new "البته! این شروع عالی بود."

    # say L2727 pla
    old "I can tell that you're doing so much better than last time."
    new "می‌تونم ببینم که این بار خیلی بهتر از آخرین بار هستی."

    # say L2728 pla
    old "Are you feeling better than during the last session?"
    new "آیا احساس می‌کنی خودت از جلسه قبل بهتره؟"

    # say L2730 ang
    old "T-Thank you [pla]."
    new "ممنون [pla]."

    # say L2731 ang
    old "Yeah, I'm feeling a little better than before."
    new "بله، حس می‌کنم کمی بهتر از قبل هستم."

    # say L2739 pla
    old "Okay, that's very good."
    new "باشه، این خیلی خوبه."

    # say L2740 pla
    old "{i}(She's doing a lot better, great!){i}"
    new "{i}(او خیلی بهتر شده، عالی!){i}"

    # say L2741 pla
    old "Very good Angelina! I can see that you're a lot more relaxed!"
    new "عالی آنجلینا! می‌بینم که خیلی آرام‌تر شده‌ای!"

    # say L2744 pla
    old "{i}(And the way she's pushing it against me...){/i}"
    new "{i}(و روشون که به من فشار می‌ده... ){/i}"

    # say L2756 ang
    old "I'm still doing well [pla]?"
    new "من هنوز خوب هستم [pla]؟"

    # say L2757 pla
    old "Y- yeah, you are, w- why don't we move on to the next position?"
    new "ب- بله، خوبی، چ- چرا ما به موقعیت بعدی برویم؟"

    # say L2758 pla
    old "Ok, you're doing amazing."
    new "بله، تو عالی هستی."

    # say L2759 pla
    old "Now, I think we can move on to the third position."
    new "الان، فکر می‌کنم می‌تونیم به موقعیت سوم برویم."

    # say L2761 ang
    old "Oh yeah, sure."
    new "اوه بله، حتماً."

    # say L2770 pla
    old "{i}(Damn, this position’s even worse.){/i}"
    new "{i}(این وضعیت حتی بدتره.){/i}"

    # say L2771 pla
    old "Uhh, just keep your eyes closed... t- to feel the energy better..."
    new "اوه، فقط چشماتو ببند... تا انرژی رو بهتر حس کنی..."

    # say L2774 ang
    old "Hmm, this feels very good [pla]."
    new "هم، این خیلی خوبه [pla]."

    # say L2775 pla
    old "T- that's very good, well done."
    new "ت- این خیلی خوبه، خوب کردی."

    # say L2776 pla
    old "Remember to keep breathing."
    new "به خاطر داشت تا تن نگیری."

    # say L2777 pla
    old "{i}(She's finally feeling comfortable, I wouldn't want to make her feel awkward.){/i}"
    new "{i}(این جا راحت شده، نمی‌خوام احساس ناراحتی بده بهش.){/i}"

    # say L2778 ang
    old "Am I doing it alright [pla]?"
    new "من اینجوری درست انجام میدم [pla]؟"

    # say L2779 pla
    old "Y-yes! You're doing great!"
    new "بله! خوب می‌کنی!"

    # say L2783 ang
    old "{i}(W- what? Is that his? Oh my...){/i}"
    new "{i}(ا- این چیه؟ آره این هم خودش؟ وای...){/i}"

    # say L2786 ang
    old "{i}(I did feel something during the last position, but I thought it was just his arm.){/i}"
    new "{i}(حاسه کردم چیزی رو توی موقعیت قبلی، ولی فکر کردم فقط بازویش بوده.){/i}"

    # say L2788 ang
    old "{i}(B-But I feel so good right, now, I wouldn't want to stop.){/i}"
    new "{i}(ولی حالا احساس خوبی می‌کنم، نمی‌خوام متوقف شم.){/i}"

    # say L2789 ang
    old "{i}(I feel better than I've felt in a while.){/i}"
    new "{i}(حاسه‌ی خوب‌تر از همیشه دارم.){/i}"

    # say L2790 ang
    old "{i}(I haven't felt this way since my therapy sessions with Dr. Johnson...){/i}"
    new "{i}از زمان جلسات درمانی من با دکتر جانسون هیچ وقت اینطور حس نکرده‌ام...{/i}"

    # say L2791 pla
    old "Ok, I think we can stop for now Angelina."
    new "باشه، فکر کنم می‌تونیم الان متوقف شیم Angelina."

    # say L2792 ang
    old "Do we have to? I think this is really helping me."
    new "باید متوقف بشیم؟ من فکر می‌کنم این واقعاً به من کمک می‌کنه."

    # say L2793 ang
    old "I'm enjoying it a lot."
    new "من خیلی لذت می‌برم."

    # say L2794 pla
    old "Uhh, o- ok, I guess we can keep going for a while."
    new "اوه، اوکی، به نظر می‌رسه می‌تونیم یه کم بیشتر ادامه بدیم."

    # say L2795 pla
    old "{i}(Well, at least she doesn't seem to have noticed my boner. So I guess it's alright.){/i}"
    new "{i}(البته، حداقل به نظر نمی‌رسه که شورتم رو دیده. پس احتمالاً خوبه.){/i}"

    # say L2798 ang
    old "I should just do it!"
    new "باید اینجوری بکنم!"

    # say L2805 pla
    old "Angelina? W-what are you doing?"
    new "آنجلینا؟ و-و چه کاری داری می‌کنی؟"

    # say L2807 ang
    old "Well, I noticed your boner."
    new "خب، لاحظ کردم که تو سخت شده‌ای."

    # say L2808 ang
    old "And I thought I should give you a hand with it."
    new "و فکر کردم باید به تو کمک کنم."

    # say L2809 pla
    old "B-But..."
    new "B-بیا، فقط بگذار من این کار رو بکنم."

    # say L2810 ang
    old "Oh come on, just let me do this."
    new "بیا، فقط بگذار من اینو بکنم."

    # say L2811 ang
    old "I want to do it, and it's not like we haven't done it before!"
    new "من می‌خوام انجام بدم، و نه مثل اینکه قبلاً انجام نداده‌ایم!"

    # say L2828 pla
    old "Uhmm, hey, are you alright?"
    new "اوه، سلام، حالت خوبه؟"

    # say L2829 pla
    old "Would you mind telling me what that was?"
    new "می‌تونی به من بگی اون چی بود؟"

    # say L2830 ang
    old "I'm sorry [pla], I suppose you weren't expecting that."
    new "متاسفم [pla]، به نظر می‌رسد انتظار نداشتی این رو."

    # say L2831 ang
    old "I- I didn't mean to surprise you that way."
    new "من- من قصد نداشتم اینجوری تو رو شگفت‌زده کنم."

    # say L2832 pla
    old "Hey, it's alright... I think."
    new "ببخشید، هیچ اشکالی نداره... فکر کنم."

    # say L2833 pla
    old "It's just that you caught me off guard."
    new "فقط اینجاست که تو منو شگفت‌زده کردی."

    # say L2835 ang
    old "Again, I'm sorry about that."
    new "دوباره، معذرت از خاطر اون."

    # say L2836 ang
    old "The thing is that I've been so frustrated lately that when I noticed you had an erection I just let myself go."
    new "البته، اخیراً خیلی ناراحت بودم و وقتی متوجه شدم تو عصبی شده‌ای، فقط خودمو رها کردم."

    # say L2837 pla
    old "Oh yeah? Why are you so frustrated?"
    new "اوه همینجور؟ چرا اینقدر ناراحتی؟"

    # say L2839 ang
    old "Well, I- I haven't been having sex with my husband lately."
    new "خب، من- من اخیراً با شوهرم جنسیت نداشتم."

    # say L2840 pla
    old "You haven't? But I thought that the sessions with Dr. Johnson..."
    new "نه؟ ولی فکر می‌کردم جلسات با دکتر جانسون..."

    # say L2842 ang
    old "They did help..."
    new "آنها کمک کردند..."

    # say L2844 ang
    old "After we were done, I did become more open in that regard. I'm now able to perform my duties as a wife."
    new "بعد از اون جلسات، من در این زمینه بازتر شدم. حالا می‌تونم وظایفم رو به عنوان همسر انجام بدم."

    # say L2846 ang
    old "But I would be lying if I said that I enjoy it."
    new "اما دروغ می‌گم اگر بگم لذت بردم."

    # say L2848 ang
    old "To be honest, I haven't enjoyed sex since I was with you and Dr. Johnson."
    new "صusch: صusch باحقیقت، از زمانی که با تو و دکتر جانسون بودم، لذت بردن از جنسیت رو نداشتم."

    # say L2850 ang
    old "When I got pregnant I got this huge boost in my libido."
    new "وقتی باردار شدم، لیبیدویم خیلی افزایش پیدا کرد."

    # say L2851 ang
    old "I was hoping that it would improve things in bed with my husband."
    new "امیدوار بودم این به رابطه جنسی من با شوهرم کمک کنه."

    # say L2852 pla
    old "And did it help?"
    new "و این بهت کمک کرد؟"

    # say L2854 ang
    old "Not at all, I just don't desire him. So I'm just left feeling frustrated."
    new "هیچ، من فقط به او علاقه‌مند نیستم. پس فقط خسته و ناراحت می‌مانم."

    # say L2855 ang
    old "I guess that's why I reacted that way when I noticed that you had that boner."
    new "باید به همین دلیل همینجور واکنش نشون دادم وقتی متوجه شدم تو اون جوری خیال می‌کنی."

    # say L2856 ang
    old "I'm sorry [pla]."
    new "متاسفم [pla]."

    # say L2858 pla
    old "Nah, it's alright, don't worry."
    new "نه، خوبه، نگران نباش."

    # say L2859 pla
    old "You just caught me by surprise, but it's no problem really."
    new "تو فقط منو شوک زدی، ولی واقعاً مشکلی نداره."

    # say L2860 pla
    old "But you know, I think there might be something that I can do for you."
    new "اما می‌دونی، فکر کنم چیزی هست که می‌تونم برایت بکنم."

    # say L2862 ang
    old "There is?!"
    new "حقاً؟!"

    # say L2864 pla
    old "Sure! Yoga's not just about positions."
    new "بله! یوگا فقط درباره وضعیت‌ها نیست."

    # say L2865 pla
    old "It's about improving your relationship with yourself by helping you balance your energy and your chakras."
    new "این درباره بهبود رابطت با خودت است، با کمک به توازن انرژیت و چاکرات."

    # say L2866 pla
    old "I already helped you once before, I don't see why not help you again."
    new "قبلاً هم به تو کمک کردم، نمی‌دونم چرا الان نباید کمکت کنم."

    # say L2867 pla
    old "So for the next session, I think we'll focus on that."
    new "پس برای جلسه بعدی، فکر می‌کنم روی این موضوع تمرکز کنیم."

    # say L2869 ang
    old "Oh that sounds amazing [pla]! Thank you so much!"
    new "اوه این عالی است [pla]! ممنونم خیلی زیاد."

    # say L2872 pla
    old "But for now I think we should get going, so Lisa won't worry about this taking too long."
    new "اما الان فکر می‌کنم باید برگردیم، تا لیزا نگران اینکه طول می‌کشه نشه."

    # say L2890 lis
    old "Well, how do you feel, Angelina?"
    new "خب، احساس چه چیزی می‌کنی، آنجلینا؟"

    # say L2891 ang
    old "I feel great! Thanks, Lisa!"
    new "حالت خوبه! ممنون، لیزا!"

    # say L2892 lis
    old "I can see that, I'm glad to see evidence of the positive effect yoga's having on you."
    new "این رو می‌تونم ببینم، خوشحالم که نتیجه مثبت یوگا رو در تو می‌بینم."

    # say L2893 lis
    old "It also makes me happy to see that [pla]'s been a proper guide for you on this yoga journey."
    new "دیدن اینکه [pla] روی این مسیر یوگا راهنمای مناسبی برایت بوده، خوشحالم."

    # say L2895 ang
    old "He really has been, and I can't wait for my next class."
    new "او واقعاً همچین بوده، و منتظر کلاس بعدیم."

    # say L2897 lis
    old "Well, I'll schedule it right away."
    new "خب، همین حالا برنامه‌اش می‌ذارم."

    # say L2899 ang
    old "Thank you, and thank you, [pla]."
    new "ممنونم، و ممنون، [pla]."

    # say L2901 pla
    old "You're welcome, I'll see you next time."
    new "خواهش می‌کنم، دوباره هم می‌بینیم."

    # say L2905 lis
    old "Goodbye, and until next time."
    new "خداحافظ، تا دفعه بعد."

    # say L2920 lis
    old "Okay, so, tell me how did you feel her energy today?"
    new "خب، بگو، امروز انرژی‌اش چطور به تو نشون داد؟"

    # say L2921 pla
    old "Well, honestly, I saw that she was doing the exercises better."
    new "البته، صادقانه بگم که دیدم امروز تمرین‌ها رو بهتر انجام می‌ده."

    # say L2922 lis
    old "Really? In my last session with her, I felt her so much more connected."
    new "وای، در جلسه آخر من با او احساس ارتباط بیشتری داشتم."

    # say L2923 lis
    old "Definitely, a masculine energy was just what her chakras needed to let go."
    new "حتماً، انرژی مردانه دقیقاً آنچه بود که چاکرهایش برای رها شدن نیاز داشتند."

    # say L2925 pla
    old "Yeah, she really let herself go..."
    new "بله، او واقعاً خودش رو رها کرد..."

    # say L2926 lis
    old "Excellent, [pla], fate truly gifted me by bringing you into my path."
    new "عالی، [pla]، تقدیر واقعاً با آوردن تو به راهم هدیه‌ام کرده."

    # say L2929 lis
    old "By the way, I wanted to ask how your evenings look for scheduling the next tantric session with Anastasia?"
    new "باید بپرسم که شام‌هایت چطور هستن برای برنامه‌ریزی جلسه تانتری بعدی با آناستازیا؟"

    # say L2930 pla
    old "Hmm, fine, I don't think I’ll have any problem coming at night."
    new "Hmm، خوب، فکر نمی‌کنم مشکلی برای اومدن توی شب داشته باشم."

    # say L2931 lis
    old "Excellent! See how the universe puts everything in its place?"
    new "عالی! ببین چطور جهان همه چیز رو جای خودش می‌ذاره؟"

    # say L2932 lis
    old "I'll talk to Anastasia and set up an appointment for the next tantric session. We'll be expecting you at night as always."
    new "من با آناستازیا صحبت خواهم کرد و برای جلسه تانتری بعدی وقت تعیین می‌کنم. همیشه مثل همیشه، ما از شام بیرون را منتظرتیم."

    # say L2934 pla
    old "Sure, count me in."
    new "بله، من هم حاضرم."

    # say L2935 lis
    old "Wonderful, I'll get everything ready, and I'll see you then."
    new "عالی، همه چیز رو آماده می‌کنم و دیگه تا وقتی که می‌آیی، منتظرت می‌مونم."

    # say L2964 pla
    old "Hmm, this is odd, there's no one here."
    new "Hmm، این عجیبه، هیچ‌کس اینجا نیست."

    # say L2965 pla
    old "Anastasia hasn't arrived? Maybe she's running late?"
    new "آناستازیا هنوز نیومده؟ شاید دیر می‌شه."

    # say L2966 pla
    old "I'll take a look upstairs, maybe they're already in the yoga room."
    new "من بالا می‌روم، شاید قبلاً تو اتاق یوگا رسیده باشند."

    # say L2987 pla
    old "Oh! You're both here already, did I arrive too late?"
    new "اوه! شما دو تا قبلاً اینجا هستید، من خیلی دیر رسیدم؟"

    # say L2989 lis
    old "Hi [pla], good evening."
    new "سلام ز[pla]، عصر خوبی."

    # say L2990 lis
    old "No, it's alright, Anastasia just got here early, so we got ready and were just chatting."
    new "نه، هیچ اشکالی نداره، آناستازیا فقط زودتر رسیده بود، پس آماده شدیم و فقط گپ می‌زدیم."

    # say L2992 lis
    old "But you're not late or anything."
    new "اما تو دیر نیستی یا هیچ."

    # say L2993 pla
    old "I see, that's good to hear."
    new "خوشحالم که اینجوری شنیدم."

    # say L2995 lis
    old "Yeah, but now that you're here, we can begin. Why don't you go and get changed?"
    new "بله، اما حالا که اومدی، می‌تونیم شروع کنیم. چرا نمی‌روی و لباست عوض کنی؟"

    # say L3018 pla
    old "Alright, I'm ready."
    new "باشه، آماده‌ام."

    # say L3020 lis
    old "Excellent."
    new "عالی."

    # say L3023 lis
    old "Ok, are you ready to start, Anastasia?"
    new "خب، آناستازیا، آماده‌ای شروع کنیم؟"

    # say L3025 ana
    old "Oh yeah, I'm more than ready!"
    new "اوه بله، خیلی آماده‌ام!"

    # say L3026 ana
    old "After last time, I've been waiting for this."
    new "بعد از آخرین بار، منتظر این بودم."

    # say L3028 ana
    old "I can't wait to have another orgasm like last time. I want to cum."
    new "نمی‌تونم منتظر بقیه بیام، مثل آخر هم می‌خوام لذت ببرم. می‌خوام جیزه بدم."

    # say L3030 lis
    old "Well, I'm glad you're this excited for the session."
    new "البته خوشحالم که اینقدر برای جلسه آماده‌ای."

    # say L3032 lis
    old "But remember, what's most important is that you're able to connect with yourself and feel the energy flow through you."
    new "اما به خاطر داشت، مهم‌ترین چیز اینه که تو بتونی با خودت همبستگی برقرار کنی و حس کنی انرژی از تو عبور می‌کنه."

    # say L3034 ana
    old "Of course, of course."
    new "البته، البته."

    # say L3035 ana
    old "I haven't forgotten what you taught me last time."
    new "من فراموش نکردم آنچه تو برام آموختی آخر بار."

    # say L3037 lis
    old "Good, then we can begin."
    new "خوب، پس می‌تونیم شروع کنیم."

    # say L3039 lis
    old "Are you ready too, [pla]?"
    new "آماده هستی هم، ز[pla]؟"

    # say L3040 pla
    old "Oh yeah, for sure."
    new "آره، حتماً."

    # say L3041 lis
    old "Great, let's begin then."
    new "عالی، بیاییم شروع کنیم."

    # say L3059 lis
    old "So, how was it, Anastasia? Did you enjoy the process?"
    new "پس، چطور بود، آناستازیا؟ از فرآیند لذت برده‌ای؟"

    # say L3061 ana
    old "Oh yeah! I loved it! It was amazing!"
    new "اوه بله! عاشقش شدم! خیلی خوب بود!"

    # say L3063 ana
    old "It felt amazing, just like last time. I loved it!"
    new "احساسی عالی بود، مثل همیشه. عاشقش شدم!"

    # say L3065 lis
    old "I'm glad to hear that. It's a testament to the work being done to help you bring your chakras and energies into balance."
    new "خوشحالم که اینجوری می‌گی. این نشان می‌ده که کارهایی که برای هماهنگی چاکرات و انرژی‌هات انجام می‌شود، موثر هستند."

    # say L3066 lis
    old "And I can see that you're doing very well, right [pla]?"
    new "و می‌تونم ببینم که خوب حالت هست، درسته [pla]؟"

    # say L3068 pla
    old "Oh yeah, you're doing great."
    new "اوه بله، تو خوب داری."

    # say L3069 pla
    old "I can tell by your good mood that your Muladhara chakra is already getting balanced."
    new "مود خوبت می‌تونم ببینم که چاکرا مولاذرا تو قطعاً در حال تعادل شدن هست."

    # say L3070 lis
    old "[pla]'s right, your energy is flowing so much better through your body."
    new "[pla] درست می‌گه، انرژیت تو خیلی بهتر در بدنت جریان داره."

    # say L3072 ana
    old "Thank you guys, I'm very happy to hear that."
    new "ممنون از شما، خوشحالم که اینجوری می‌گویید."

    # say L3073 ana
    old "But, I was wondering if maybe we could do a little bit more."
    new "اما من فکر می‌کنم می‌تونیم کمی بیشتر هم انجام بدیم."

    # say L3074 ana
    old "Y-You know, s-since you say I'm doing so well."
    new "میدونید، چون می‌گیه من اینقدر خوب هستم."

    # say L3075 ana
    old "I would like to know if we can keep going."
    new "من می‌خوام بدونم می‌تونیم ادامه بدیم."

    # say L3076 ana
    old "Maybe we could do another exercise?"
    new "شاید می‌تونیم تمرین دیگه‌ای بکنیم؟"

    # say L3077 ana
    old "That's only if you think it's alright!"
    new "البته، اگر تو فکر می‌کنی خوبه!"

    # say L3079 lis
    old "Actually, I was about to tell you just that."
    new "در واقع همین جا می‌خواستم به تو بگم."

    # say L3081 lis
    old "You've done very well during this first stage of the process of chakra balancing."
    new "تو در این مرحله اولیه توازن چاکراها رو خیلی خوب انجام دادی."

    # say L3083 lis
    old "So I believe you're ready to try something new."
    new "پس فکر می‌کنم آماده‌ی چیز جدیدی هستی."

    # say L3084 ana
    old "Really? Great! What will we be doing? I can't wait."
    new "وای، عالیه! چه کاری خواهیم کرد؟ منتظرش هستم."

    # say L3086 lis
    old "Well, the goal with what we've been doing so far is getting you to connect with yourself."
    new "خب، هدف از آنچه تا حالا انجام دادیم این بود که تو با خودت همبستگی برقرار کنی."

    # say L3087 lis
    old "So that you could feel the flow of energy in your body."
    new "تا بتوانی جریان انرژی در بدن خود را حس کنی."

    # say L3088 lis
    old "Now, it's time to create a connection with the outside, and for that, [pla] will be helping us in this new practice."
    new "الان وقتش رسید تا ارتباطی با بیرون برقرار کنیم، و برای این کار، [pla] در این تمرین جدید به ما کمک خواهد کرد."

    # say L3089 pla
    old "Alright, what are we going to do?"
    new "باشه، الان چه کاری می‌کنیم؟"

    # say L3091 lis
    old "We're engaging in a posture where the goal is for the three of us to create an energetic chain."
    new "ما در یک وضعیت شرکت می‌کنیم که هدف آن ایجاد زنجیره انرژی بین ما سه نفر است."

    # say L3092 lis
    old "The point of that is that we're able to unite our energies."
    new "هدف این همین است که ما بتوانیم انرژی‌هامون رو با هم ترکیب کنیم."

    # say L3093 lis
    old "And you can allow yourself to release what's pent up inside of you, Anastasia."
    new "و تو می‌تونی اجازه بدی چیزی که تویوند تو هست، آزاد شه، آناستازیا."

    # say L3094 ana
    old "Okay, that sounds interesting."
    new "باشه، این جالب به نظر می‌رسه."

    # say L3095 ana
    old "I bet that's going to feel even better than the massage."
    new "حتماً این احساس بهتر از ماساژ خواهد بود."

    # say L3096 lis
    old "Sure, it might."
    new "بله، ممکنه."

    # say L3097 lis
    old "But you have to remember that whatever sexual pleasure you get from this is only secondary to the actual goal of getting your chakras in proper balance."
    new "اما باید به یاد داشته باشی که لذت جنسی که از این می‌بری فقط دوم به هدف اصلی، یعنی توازن چاکره‌هات، است."

    # say L3099 ana
    old "Of course, of course, I haven't forgotten."
    new "البته، البته، فراموش نکرده‌ام."

    # say L3101 lis
    old "Alright, it's time to start."
    new "خوب، الان وقت شروع است."

    # say L3110 ana
    old "I- Is this okay? Am I positioned properly?"
    new "من- اینجوری خوبه؟ من درست جاشونده‌ام؟"

    # say L3111 lis
    old "You are, that's just perfect."
    new "تو همینجوری هستی، فقط عالیه."

    # say L3112 lis
    old "How are you [pla]? Is this comfortable for you?"
    new "حالت چطوره [pla]؟ این برایت راحته؟"

    # say L3113 pla
    old "Y- yeah! No problem!"
    new "ب-بله! هیچ اشکالی نداره!"

    # say L3114 lis
    old "Good, then we're going to start moving slowly."
    new "خوب، پس شروع می‌کنیم به آرامی."

    # say L3128 lis
    old "Ok, I would like to ask if you have any comments on how this process is going."
    new "خب، من می‌خوام بپرسم که آیا نظری در مورد این فرآیند داری؟"

    # say L3130 ana
    old "The only thing I have to say is that it's been amazing!"
    new "تنها چیزی که می‌تونم بگم اینه که شگفت‌انگیز بود!"

    # say L3131 ana
    old "It's just as good as I wanted it to be."
    new "همینقدر خوب هست، مثل آنچه می‌خواستم."

    # say L3132 ana
    old "Although, I still would love to do something a little... Harder with [pla]."
    new "البته، هنوز هم دوست دارم چیزی کمی... سخت‌تر با [pla] انجام بدم."

    # say L3133 lis
    old "All in good time."
    new "با همه این‌ها، وقت مناسب خواهد آمد."

    # say L3134 lis
    old "But I'm glad to hear that you're satisfied with the way this has been working."
    new "البته، خوشحالم که شنیدم تو راضی هستی از نحوه کار این."

    # say L3135 lis
    old "What do you say we get dressed and come down?"
    new "بیایید لباس بگذاریم و بیاییم پایین."

    # say L3145 lis
    old "Alright, I will be seeing you both for the next session."
    new "خوب، من در جلسه بعدی شما رو می‌بینم."

    # say L3147 ana
    old "Sure, but before I leave, I want to thank you, Lisa."
    new "البته، ولی قبل از برخاستن می‌خوام ازت تشکر کنم، لیزا."

    # say L3150 ana
    old "At first, I was only interested in having sex with you guys."
    new "در ابتدا فقط به جنس با شما علاقه داشتم."

    # say L3153 ana
    old "But doing this has been an eye-opening experience for me."
    new "اما انجام این کار برایم تجربه‌ای چشم‌گشا بود."

    # say L3154 ana
    old "This has completely changed my perspective about what pleasure and enjoyment are."
    new "این به من کاملاً دیدگاه جدیدی درباره لذت و لذت بردن داد."

    # say L3156 lis
    old "I'm glad you feel this way about what we've been doing. That's the main goal of this."
    new "خوشحالم که اینطور می‌تونی احساس کنی در مورد چیزهایی که انجام دادیم. این هدف اصلیمون بود."

    # say L3157 ana
    old "Thanks a lot, Lisa, and also you, [pla]. I can't wait for the next session."
    new "ممنونم، لیسا، و هم تو، [pla]. نمی‌تونم منتظر جلسه بعدی بیام."

    # say L3159 lis
    old "Very well. We’ll schedule it after our next yoga session."
    new "بسیار خوب. ما آن را بعد از جلسه یوگا بعدی برنامه‌ریزی خواهیم کرد."

    # say L3173 lis
    old "So, how did you find today's session? Did you feel all that energy and balance between the three of you?"
    new "پس، امروز جلسه چطور بود؟ آیا همه آن انرژی و تعادل بین سه‌تونو حس کردی؟"

    # say L3174 pla
    old "Hmm, yeah, I definitely felt it a lot."
    new "Hmm، بله، حتماً احساسش کردم."

    # say L3175 lis
    old "It's amazing. And did you hear what she said about the whole process?"
    new "الان، شنیدی چی‌ها در مورد کل فرآیند گفت؟"

    # say L3176 lis
    old "I really feel like I'm an instrument of the universe, balancing and transmitting energy to all my clients."
    new "حاسس می‌کنم مثل یه ابزار از جهان هستم، انرژی رو به همه مشتری‌هام متوازن می‌کنم و منتقل می‌کنم."

    # say L3177 pla
    old "Yes, you’ve truly helped all the women you’ve worked with."
    new "بله، واقعاً همه زنانی که با تو کار کردی رو کمک کردی."

    # say L3178 lis
    old "Thank you for your words. By the way, I wanted to talk to you about Angelina."
    new "ممنون از کلماتت. به هر حال، می‌خواستم با تو در مورد آنجلینا صحبت کنم."

    # say L3179 pla
    old "Uhh, sure, tell me..."
    new "اوه، البته، بگو..."

    # say L3180 lis
    old "Well, I had a yoga session with Angelina, and I have to tell you that I've seen an impressive improvement in her condition."
    new "خب، من یک جلسه یوگا با آنجلینا داشتم و باید به تو بگم که بهبود قابل توجهی در وضعیت او مشاهده کردم."

    # say L3181 lis
    old "The problems with her Muladhara chakra seem to be getting resolved."
    new "مشکلاتش با چاکرای مولاذارا به نظر می‌رسه حل می‌شنن."

    # say L3182 lis
    old "She's still not entirely ok, but I can feel her prana flowing better within her body."
    new "او هنوز کاملاً خوب نیست، اما می‌تونم حس کنم پرانایش در بدن‌ش بهتر جریان داره."

    # say L3183 lis
    old "Her energy is a lot more balanced, and I can see her being more receptive to the flow of energy among her chakras."
    new "انرژی‌اش خیلی بیشتر تعادل پیدا کرده و می‌تونم ببینم که برای جریان انرژی بین چاکرای‌اش آماده‌تر شده."

    # say L3184 lis
    old "I must start recommending you to my other clients that may have some problems with their energy flow."
    new "باید شروع کنم تا تو رو به مشتریان دیگه‌ام که مشکل انرژی دارن توصیه کنم."

    # say L3185 lis
    old "You've done so much by helping first Anastasia, and then Angelina."
    new "تو قدرت زیادی داشتی با کمک به اول آناستازیا و بعد آنجلینا."

    # say L3186 lis
    old "You've done an excellent job [pla], congratulations."
    new "تو کار عالی کردی [pla]، مبارک."

    # say L3187 pla
    old "W-well, thank you."
    new "خوب، ممنون."

    # say L3189 lis
    old "The last thing is that she asked me if there was a possibility of you giving her another class."
    new "آخرین چیز اینه که از من پرسید اگه امکانش هست تو دوباره بهش کلاس بدی."

    # say L3191 pla
    old "Sure! If our sessions together are working, then I'm more than happy to do it. No problem."
    new "بله! اگر جلساتمون با هم خوب هستن، خوشحالم که این کار رو بکنم. مشکلی نداره."

    # say L3193 lis
    old "Excellent, I'm glad you're willing to accept because I believe she still needs it."
    new "عالی، خوشحالم که تمایل داری قبول کنی چون فکر می‌کنم هنوز بهش نیاز داره."

    # say L3194 lis
    old "So thank you [pla]."
    new "پس ممنون [pla]."

    # say L3196 pla
    old "You're welcome, you know I'm more than happy to help you."
    new "خواهش می‌کنم، می‌دونی خوشحالم که بتونم بهت کمک کنم."

    # say L3198 lis
    old "Thanks a lot [pla], I'll see you later then."
    new "ممنون زیادی [pla]، بعداً می‌بینیم."

    # say L3227 pla
    old "Hey Lisa, hi Angelina, how are you?"
    new "سلام لیزا، سلام آنجلینا، حالتون چطوره؟"

    # say L3229 lis
    old "Hello [pla], good afternoon."
    new "سلام [pla]، عصر خوبی."

    # say L3230 ang
    old "Hi, [pla], nice to see you again"
    new "سلام، [pla]، خوشحالم که دوباره تو رو می‌بینم"

    # say L3233 lis
    old "Are you ready for your next session?"
    new "آیا برای جلسه بعدی آماده‌ای؟"

    # say L3235 pla
    old "Yeah, sure, I'm ready."
    new "بله، حتماً، آماده‌ام."

    # say L3237 lis
    old "Great, I've already talked with Angelina and she's ready too. So let's go to the yoga room then."
    new "عالی، قبلاً با آنجلینا هم صحبت کردم و او هم آماده است. پس بیایید به اتاق یوگا برویم."

    # say L3241 lis
    old "Well, I'll let you guys be, I hope you enjoy today's session as well Angelina."
    new "خب، من شما رو ترک می‌کنم، امیدوارم امروز هم جلسه‌تون خوب باشه، آنجلینا."

    # say L3243 ang
    old "Thank you, Lisa."
    new "ممنون، لیزا."

    # say L3245 pla
    old "See you, Lisa."
    new "بای، لیزا."

    # say L3254 pla
    old "So, how are you?"
    new "پس، حالت چطوره؟"

    # say L3256 ang
    old "I'm feeling alright."
    new "حالم خوبه."

    # say L3257 ang
    old "But this whole deal with the pregnancy hormones has me going through the roof."
    new "ولی این همه چیز به خاطر هورمون‌های بارداری من رو به راستی دیوانه می‌کنه."

    # say L3259 ang
    old "The doctor explained to me that it's perfectly normal."
    new "پزشک به من توضیح داد که این کاملاً طبیعیه."

    # say L3261 ang
    old "But I'm not sure about that, because I wasn't feeling this way before, it's just since I saw you that I started feeling this weird way."
    new "ولی اینجوری فکر نمی‌کنم، چون قبلاً هیچ اینجور حس نمی‌کردم، فقط از وقتی تو رو دیدم این حس عجیب شروع شد."

    # say L3265 ang
    old "Yeah, but he said that as soon as the baby's born, everything should be fine."
    new "بله، اما او گفت که همین زمانی که بچه متولد شد، همه چیز باید خوب باشه."

    # say L3267 ang
    old "So, keeping that in mind... I wanted to ask a favor of you [pla]."
    new "پس با این حال... می‌خواستم ازت یه لطفی بخواهم [pla]."

    # say L3269 ang
    old "Do you think you would be willing to help me again with these... needs that I have?"
    new "فکر می‌کنی می‌تونی دوباره به من در این... نیازهایم کمک کنی؟"

    # say L3271 ang
    old "I- It would just be the one time, I swear."
    new "البته، فقط یک باره، قسمت می‌خورم."

    # say L3273 ang
    old "It's just that I'm feeling this enormous tension as of late, and I really need to deal with it."
    new "اونجوری که اخیراً احساس تنش بسیار زیادی دارم و واقعاً باید با این مشکل برخورد کنم."

    # say L3274 ang
    old "And I think you're the only one who can really help me with it."
    new "و فکر می‌کنم تو تنها کسی هستی که می‌تونی به من کمک کنی."

    # say L3276 pla
    old "Uhh, I don't know... Lisa's downstairs and could come by any moment."
    new "اوه، نمی‌دونم... لیزا پایینه و می‌تونه هر لحظه بیاد."

    # say L3277 pla
    old "Also, you're pregnant, I don't know how safe this is."
    new "همچنین، تو حامله‌ای، نمی‌دونم این چقدر امنه."

    # say L3278 ang
    old "Don't worry about that, it's nothing dangerous. I already checked with my doctor. It'll just be quick, I promise I won't make much noise."
    new "نگران اون نباش، خطری نداره. قبلاً با پزشکم هم سر این موضوع صحبت کردم. فقط یه لحظه طول می‌کشه، قول میدم صدای زیادی نمی‌زنم."

    # say L3279 pla
    old "But what about the yoga class..."
    new "ولی درباره کلاس یوگا چطور..."

    # say L3280 ang
    old "Look, I signed up for the class with Lisa because I felt so repressed, just like when I studied with Dr. Johnson."
    new "ببین، من برای اون کلاس با لیزا ثبت‌نام کردم چون احساس کیفیت‌زندگی‌من کاهش پیدا کرده بود، مثل وقتی با دکتر جانسون مطالعه می‌کردم."

    # say L3281 ang
    old "And being pregnant, I wanted to try something different... But I ended up finding you again, and well, my hormones went wild and they're practically shouting for it."
    new "و با حامل شدن، می‌خواستم چیز جدیدی امتحان کنم... اما در نهایت تو رو دوباره پیدا کردم و خوب، هورمون‌هامون واگرفت و مثل این هستن که صدا می‌زنن برایش."

    # say L3283 ang
    old "This would really help me more than a yoga class, and I think you know that."
    new "این برای من بیشتر از یک کلاس یوگا کمک می‌کنه، و فکر کنم می‌دونی."

    # say L3284 pla
    old "{b}*Sigh*{/b}, alright, but only this once, and then we'll go back to yoga classes like before."
    new "{b}*تنفر*{/b}، خوب، ولی فقط این بار، بعدش برگردیم به کلاس‌های یوگا مثل قبل."

    # say L3285 ang
    old "Yes, yes, go ahead, my body is craving it and I think you'll enjoy it too, really."
    new "بله، بله، برو پیش، بدنم به این نیاز داره و فکر می‌کنم تو هم لذت می‌بری، واقعاً."

    # say L3286 pla
    old "Hmm... Alright..."
    new "Hmm... خب..."

    # say L3287 ang
    old "Ok, lie back and let me enjoy suking that big cock of yours."
    new "اوه، بخه بنشین و بگذار لذت بردن از آن سیخ بزرگ تو رو ببرم."

    # say L3297 ang
    old "Mmm! I have been waiting for this since last time!"
    new "ممنن! از آخر بار منتظر این بودم!"

    # say L3298 ang
    old "I can't have enough of this!"
    new "نمی‌تونم از این خسته شم!"

    # say L3309 ang
    old "That felt wonderful [pla]!"
    new "این حس عالی بود [pla]!"

    # say L3311 pla
    old "Well, I'm glad that you're feeling better, that was the whole point of this."
    new "البته، خوشحالم که حالت بهتر شده، این همین بود که من قصد داشتم."

    # say L3313 ang
    old "Thank you [pla], I also think that once the baby's born I'll feel a lot better."
    new "ممنون [pla]، من هم فکر می‌کنم بعد از تولد بچه حالت خوب‌تر می‌شه."

    # say L3315 pla
    old "I'm sure you will."
    new "حتماً همینطور خواهد شد."

    # say L3316 pla
    old "Remember, if you really want a YOGA class, you can talk to Lisa."
    new "به خاطر بسپار، اگر واقعاً می‌خوای کلاس یوگا بره، می‌تونی با لیزا صحبت کنی."

    # say L3318 ang
    old "Thank you [pla], I'll keep it in mind, and of course, if I ever need it, I'll let Lisa know."
    new "ممنون [pla]، به ذهنم می‌آید و البته اگر وقتی نیاز داشتم، به لیسا می‌گویم."

    # say L3319 ang
    old "And I hope she'll tell you."
    new "و امیدوارم به تو بگه."

    # say L3322 ang
    old "Great! But for now, it's getting late, so I think I'll head home."
    new "عالی! ولی الان وقت شده، پس فکر می‌کنم برم خانه."

    # say L3323 ang
    old "But once again, thank you [pla], for all your help. This has been great."
    new "اما دوباره، ممنونم [pla]، از همه کمکت. این خیلی عالی بود."

    # say L3338 lis
    old "Are you guys done?"
    new "آیا شما دو نفر تمام شدید؟"

    # say L3340 ang
    old "We are. It was great, Lisa."
    new "بله، تمام شد. عالی بود، لیزا."

    # say L3341 lis
    old "I can see that, it seems the yoga really worked on you, Angelina."
    new "این رو می‌تونم ببینم، به نظر می‌رسه یوگا واقعاً برایت کار کرده، آنجلینا."

    # say L3343 lis
    old "I can see your energy flowing a lot better within you."
    new "می‌تونم ببینم انرژیت تو خیلی بهتر جریان داره."

    # say L3344 lis
    old "Very good, [pla], you've done a good job."
    new "خوبه، [pla]، کار خوبی انجام دادی."

    # say L3346 ang
    old "He has been a very good teacher."
    new "او معلم خوبی بود."

    # say L3348 lis
    old "I can see that."
    new "می‌تونم ببینم."

    # say L3349 lis
    old "I hope you'll keep coming to classes after this, Angelina."
    new "امیدوارم بعد از این هم به جلسات بیایی، آنجلینا."

    # say L3351 ang
    old "I will, I'll keep coming even after the baby's born."
    new "من همینجور خواهم بود، حتی پس از تولد بچه هم خواهم آمد."

    # say L3352 lis
    old "That's wonderful news."
    new "این خبر عالی است."

    # say L3354 ang
    old "Thank you, both of you."
    new "ممنون، هر دو."

    # say L3355 ang
    old "I'll go home now."
    new "من حالا برم خونه."

    # say L3356 ang
    old "But I'll come back soon for my next class."
    new "اما زودی برای کلاس بعدی برمی‌گردم."

    # say L3357 lis
    old "Of course, see you soon."
    new "البته، تا زودی می‌بینیم."

    # say L3372 lis
    old "She's definitely looking much better, [pla]. You did a great job with her today."
    new "حتماً بهتر شده، [pla]. امروز کار خوبی با او انجام دادی."

    # say L3373 pla
    old "Uh, yeah, it was an excellent session. She really enjoyed it."
    new "بله، جلسه خوبی بود. او واقعاً لذت برده بود."

    # say L3374 lis
    old "Awesome! You’ve learned how to transmit that energy well. I truly feel you’ll become a great instrument for the universe."
    new "عالی! خوب آموختی اون انرژی رو چطور منتقل کنی. واقعاً حس می‌کنم تو به یک ابزار عالی برای جهان تبدیل می‌شی."

    # say L3375 lis
    old "Speaking of which, I’m scheduling a new tantric session with Angelina. Could you come by one evening soon?"
    new "می‌تونی یه شام贝 همینجوری بیایی؟ من یه جلسه تانتریک جدید با آنژلینا برنامه‌ریزی کردم."

    # say L3376 pla
    old "Uh, sure, no problem."
    new "بله، حتماً، مشکلی نداره."

    # say L3403 pla
    old "Hmm, they're not here again."
    new "هم، آنها دوباره اینجا نیستند."

    # say L3404 pla
    old "Well, I imagine that just means that they're already up in the yoga room."
    new "خوب، احتمالاً قبلاً به اتاق یوگا رفته‌اند."

    # say L3425 lis
    old "Hello [pla], I'm glad you arrived."
    new "سلام ز[pla]، خوشحالم که رسیدی."

    # say L3427 pla
    old "Hey, were you waiting too long for me?"
    new "سلام، خیلی طول نکشیدی مرا منتظر بمانی؟"

    # say L3429 lis
    old "No, Anastasia arrived not too long ago, and we just got ready. Why don't you get changed so we can start?"
    new "نه، آناستازیا خیلی طول نکشید و ما فقط آماده شدیم. چرا نمی‌تونی جایت رو عوض کنی تا شروع کنیم؟"

    # say L3454 lis
    old "Great, then we can start with the session."
    new "عالی، پس می‌تونیم جلسه رو شروع کنیم."

    # say L3456 ana
    old "Lisa told me that we would be trying something new today."
    new "لیسا به من گفت که امروز چیز جدیدی امتحان می‌کنیم."

    # say L3457 ana
    old "I can't wait to see what we'll do."
    new "نمی‌تونم صبر کنم ببینم چه کاری می‌کنیم."

    # say L3460 lis
    old "Of course, but remember that before anything else you have to connect with yourself."
    new "البته، اما به یاد داشته باش قبل از هر چیزی باید با خودت ارتباط برقرار کنی."

    # say L3461 lis
    old "And focus on the balance of your chakras."
    new "و روی توازن چاکره‌هایت تمرکز کن."

    # say L3464 ana
    old "It's just that I'm very excited to see what's coming."
    new "البته، فقط خوشحالم که ببینم چه چیزی پیش می‌آید."

    # say L3466 lis
    old "Let's begin then, so you can see how it is."
    new "بیاین شروع کنیم، تا ببینی چطور هست."

    # say L3484 lis
    old "Well done Anastasia, I can see by how well you're doing that these sessions have been very effective for you."
    new "خوب انجام دادی آناستازیا، می‌تونم ببینم که این جلسات برایت خیلی موثر بوده."

    # say L3485 lis
    old "How do you feel about what we've been doing?"
    new "احساسی چطور هست در مورد اونچه که انجام میدیم؟"

    # say L3487 ana
    old "I feel great! I no longer feel any nervousness or anxiety about what we're doing."
    new "احساسی عالی دارم! دیگه هیچ اضطراب یا ترسی از آنچه می‌کنیم ندارم."

    # say L3488 ana
    old "And it's all thanks to you both, [pla] and Lisa. Thank you."
    new "و همه این به خاطر شما دو تا، [pla] و لیزا. ممنون."

    # say L3490 pla
    old "Hey, I'm happy to help."
    new "اوه، خوشحالم که بتونم کمکت کنم."

    # say L3491 lis
    old "It makes me happy to see that you're doing so well."
    new "بینهایت خوشحالم که می‌بینم شرایطت خوبه."

    # say L3492 lis
    old "And I believe you're ready for the next stage."
    new "و من باور دارم تو برای مرحله بعد آماده‌ای."

    # say L3493 ana
    old "Alright, great! I trust that you know what's best."
    new "البته، عالی! من باور دارم تو می‌دونی چی بهتره."

    # say L3495 lis
    old "Now, for this next exercise, the idea is that you finish the internal connection with yourself."
    new "الان، برای این تمرین بعدی، هدف اینه که تو ارتباط داخلی خودت رو تمام کنی."

    # say L3496 lis
    old "The first one we made was to help you relax and understand yourself on a deeper level."
    new "اولین ارتباطی که برقرار کردیم برای این بود که آرام شوی و خودت رو به صورت عمیق‌تر درک کنی."

    # say L3497 lis
    old "The second one was focused on you learning to let your energy flow freely in and out of you."
    new "دومی رو برای این بود که بیاموزی انرژیت رو آزاد بیابی و بیرون بیاندازی."

    # say L3498 lis
    old "This last one is about you using what you have learned to forge a new connection with your inner being."
    new "این آخری درباره استفاده از آنچه یاد گرفتی برای ایجاد ارتباط جدیدی با ذات خودت است."

    # say L3499 lis
    old "For this, [pla] will be playing an important role, but what's most important is that you focus on yourself, okay?"
    new "برای این، نقش [pla] مهم است، اما مهم‌تر اینه که روی خودت تمرکز کنی، درسته؟"

    # say L3501 ana
    old "Sure! I get it!"
    new "بله! متوجه شدم!"

    # say L3503 lis
    old "Alright, let's get started."
    new "باشه، بیاین شروع کنیم."

    # say L3511 lis
    old "Ok, are you ready?"
    new "خب، آماده‌ای؟"

    # say L3512 ana
    old "Yes, I am, I feel like I can do this now."
    new "بله، آماده‌ام، احساس می‌کنم الان می‌تونم این کار رو انجام بدم."

    # say L3513 lis
    old "Remember to keep your breathing stable."
    new "نفست رو ثابت نگه دار."

    # say L3514 lis
    old "Focus on yourself, what you're feeling deep inside."
    new "به خودت تمرکز کن، احساساتت رو از درون بیاور."

    # say L3515 lis
    old "On the balance of your chakras."
    new "بر توازن چاکرت تمرکز کن."

    # say L3529 lis
    old "Well done, Anastasia. I can clearly see a change in you from the time we started this process to now."
    new "خوب انجام دادی، آناستازیا. تغییر شما از زمانی که این فرآیند را شروع کردیم تا حالا واضح است."

    # say L3530 lis
    old "Your chakras are much more balanced now, and I can feel all the positive energy coming from you."
    new "چاکرات الان بسیار متعادل‌تر هستند و من همه انرژی مثبتی که از تو سر می‌آید را می‌بینم."

    # say L3532 ana
    old "Thank you, Lisa, and thank you, [pla]."
    new "ممنونم، لیزا، و ممنونم، [pla]."

    # say L3535 ana
    old "Because of this great help from you two, my perspective on sex has completely changed."
    new "به خاطر این کمک بزرگ شما دو تا، نگاه من به جنس کاملاً تغییر کرد."

    # say L3536 ana
    old "I'll be sure to apply this to my own life in the future."
    new "حتماً این رو در زندگی خودم هم به کار می‌برم."

    # say L3537 lis
    old "Excellent! Because that's exactly what this is about!"
    new "عالی! زیرا این دقیقاً همین است که به آن اشاره داریم."

    # say L3538 lis
    old "As I already explained to [pla], this is something that you can live in every area of your life."
    new "همانطور که به [pla] توضیح دادم، این چیزی است که می‌توانی در هر بخشی از زندگیت اجرا کنی."

    # say L3539 lis
    old "It's not just about sex, but about how you project your energy daily, and it makes me happy that you understood that."
    new "این فقط درباره جنس نیست، بلکه درباره اینه که چطور انرژیت رو هر روز پخش می‌کنی، و خوشحالم که این رو فهمیدی."

    # say L3541 ana
    old "Thank you, Lisa, I'll be sure to remember that."
    new "ممنون، لیزا، حتماً اینو به یاد خواهم گذاشت."

    # say L3542 ana
    old "Really, what I got from these sessions is more than what I was expecting."
    new "واقعاً، از این جلسات چیزی به دست آوردم که بیشتر از آنچه انتظار داشتم است."

    # say L3544 lis
    old "I'm happy that's how you feel, but this isn't a finished process."
    new "خوشحالم که اینطور می‌تونی، ولی این فرآیند تمام نشده."

    # say L3545 lis
    old "It's important that you keep practicing these teachings in the future."
    new "اهمیتش اینه که تو این تدریس‌ها رو در آینده ادامه بده."

    # say L3547 ana
    old "I'll be sure to do that."
    new "حتماً این کار رو انجام می‌دم."

    # say L3548 lis
    old "Great! Now, it's late, so let's get changed so that you two can go home."
    new "عالی! حالا وقت شده تا پوششمون رو عوض کنیم تا بتوانید بروید."

    # say L3558 lis
    old "Alright, that's it for now, but remember, we will see each other soon, okay? Both for your regular yoga classes, and for tantric sesions."
    new "البته، این برای حالا آخرش، ولی به خاطر داشته باش، ما به زودی دوباره می‌بینیم، خوبه؟ هم برای کلاس‌های یوگا معمولی، و هم برای جلسات تانترا."

    # say L3560 ana
    old "Sure, I'll be seeing you soon."
    new "بله، تا زودی می‌بینیم."

    # say L3561 ana
    old "Thanks again to both of you, see you."
    new "ممنون از هر دو، دیدنتون خوشحالم."

    # say L3562 pla
    old "Happy to help, see you later."
    new "خوشحالم که کمک کردم، دوست دارم بعداً هم ببینم."

    # say L3574 lis
    old "Okay, I think this first step of adding other areas besides yoga to my classes was a total success."
    new "باشه، فکر می‌کنم این اولین قدم برای اضافه کردن زمینه‌های دیگر به کلاس‌هام موفقیت‌آمیز بود."

    # say L3575 pla
    old "Yeah, I think it would go really well if you offered it to more of your clients."
    new "بله، فکر کنم اگه به بیشتر مشتریاتت پیشنهاد کنی خوب می‌شود."

    # say L3576 lis
    old "Wow [pla], I feel so excited about this path the universe is taking me on."
    new "واو [pla]، احساس خوشحالی می‌کنم از این مسیری که جهان برایم پیش روست."

    # say L3577 lis
    old "I believe we can do great things to help a lot of people."
    new "من معتقدم می‌تونیم کارهای عالی انجام بدیم تا به زیادی از مردم کمک کنیم."

    # say L3578 pla
    old "I'm sure of it."
    new "من هم ازش مطمئنم."

    # say L3579 lis
    old "I’ll follow the natural flow of destiny, I’ll take it step by step; I don’t want things to get out of hand."
    new "من با جریان طبیعی قدرت تاکید می‌کنم، هر مرحله را به تدریج طی می‌کنم؛ نمی‌خوام اوضاع از دست بیافتد."

    # say L3580 lis
    old "I hope you can keep helping me, there are many clients who would really benefit from your energy and vitality."
    new "امیدوارم بتونی همچین کمکی به من بکنی، خیلی از مشتریان می‌تونن از انرژی و زنده‌بودنت بهره‌بر بگیرن."

    # say L3581 pla
    old "Of course, count on me whenever you need."
    new "البته، هر وقت نیاز داشتی به من بگو."

    # say L3582 lis
    old "Aww, you’ve been such a wonderful gift from the universe to me."
    new "اوه، تو هدیه‌ای شگفت‌انگیز از جهان برای من بودی."

    # say L3583 lis
    old "Oh, speaking of that, I didn’t think it was necessary, but Angelina asked again for you to accompany her in a new class."
    new "اوه، در مورد این، من فکر نکردم لازم باشه، اما آنجلینا دوباره از تو خواست تا همراهش توی یه کلاس جدید باشی."

    # say L3584 pla
    old "Hmm, yeah, I figured that would happen."
    new "Hmm، بله، فکر کردم اینجوری می‌شه."

    # say L3585 lis
    old "You’ve done so much good for that girl, the difference is noticeable. She looks radiant, smiling, with such special energy."
    new "تو همچین خوبی‌ها زیادی برای اون دختر کردی، تفاوت مشهوده. اونجور لامپ روشن، لبخند داره، انرژی خاصی داره."

    # say L3586 lis
    old "Does it sound good if I schedule you with her for a session in the afternoon?"
    new "آیا خوب است اگر توی بعد از ظهر تو را برای جلسه‌ای با او رزرو کنم؟"

    # say L3587 pla
    old "Yes, go ahead, no problem. I’ll talk to her about what she really wants to focus on."
    new "بله، برو پیش رو، هیچ مشکلی ندارم. باهاش حرف بزنم که واقعاً چه چیزی می‌خواد تمرکز کنه."

    # say L3588 lis
    old "Sounds great, you’re a real guru! I’ll schedule the appointment with her and we’ll see each other then for your next session with her."
    new "عالی است، تو واقعاً اساتیدی هستی! من موعد رو با او تعیین می‌کنم و در جلسه بعدی تو با او دیدار می‌کنی."

    # say L3589 pla
    old "Okay, thanks Lisa, we’ll meet then for Angelina’s next session. Have a good night."
    new "باشه، ممنون لیزا، وقتی برای جلسه بعد آنجلینا رو می‌بینیم. شب خوبی داشته باش."

    # say L3590 lis
    old "Rest well [pla], take care."
    new "بخوبی بخاطر باش [pla]، مراقب خودت با."

    # say L3617 lis
    old "Oh, hey [pla], you’re just in time, Angelina just arrived too."
    new "اوه، سلام [pla]، خوشحالم که هم زمان رسیدی، آنژلینا هم net رسیده."

    # say L3618 ang
    old "Hi [pla], great to see you again."
    new "سلام [pla]، خوشحالم که دوباره دیدمت."

    # say L3619 pla
    old "Hey Angelina, how are you?"
    new "اوه، سلام Angelina، چطوری؟"

    # say L3620 ang
    old "Excited for the new yoga class."
    new "خوشحالم برای کلاس یوگا جدید."

    # say L3621 pla
    old "Uh, heh, yeah, I can imagine..."
    new "آره، هه، بله، می‌تونم خوشحالیت رو تصور کنم..."

    # say L3623 lis
    old "Well, I see you’re both eager for the class, so why not head upstairs and enjoy it?"
    new "خب، می‌بینم هر دوی شما برای کلاس خوشحال هستید، پس چرا نرویم بالا و ازش لذت ببریم؟"

    # say L3624 ang
    old "Sounds perfect, I’m excited, let’s go [pla]."
    new "این هم کامل، خوشحالم، برویم [pla]."

    # say L3625 pla
    old "{b}*Sigh*{/b}, Sure, let’s go."
    new "{b}*تنفث*{/b}، بله، برویم."

    # say L3633 pla
    old "Okay, okay, what did we talk last time?"
    new "باشه، باشه، بیای، ببین ما آخر بار در مورد چی حرف زدیم؟"

    # say L3634 pla
    old "Because I don’t think you came just to practice yoga exercises, right?"
    new "چون فکر نمی‌کنم فقط برای تمرین یوگا اومدی، درسته؟"

    # say L3635 ang
    old "Look, I know, but seriously my body is going crazy, you don’t understand."
    new "ببین، می‌دونم، ولی جدی هستم، بدنم خیلی خراب شده، تو نمی‌فهمی."

    # say L3636 ang
    old "Being pregnant turns me into a teenager full of hormones."
    new "حمل کردن من رو مثل یک نوجوان پر از هورمون‌ها می‌کنه."

    # say L3637 ang
    old "And after weeks of sexual frustration, seeing you again reactivated so many things in me that I’d only felt during therapy with Dr. Johnson."
    new "و بعد از هفته‌ها از خستگی جنسی، دیدنت دوباره همه چیزهایی رو در من فعال کرد که فقط درمان با دکتر جانسون حس کرده بودم."

    # say L3639 ang
    old "Honestly, if it weren’t so necessary for me right now, I wouldn’t bother you."
    new "صراحیت، اگر اینقدر برایم ضروری نبود، تو رو آزار نمی‌دادم."

    # say L3640 pla
    old "{b}*Sigh*{/b}, Okay, let’s do it if it makes you feel better."
    new "{b}*تنفس*{/b}، خب، اگه این به تو خوشحالی می‌ده، بیایید انجام بدیم."

    # say L3641 ang
    old "I appreciate it [pla], I’ll make sure you enjoy it."
    new "ممنونم [pla]، حتماً ازت لذت ببری."

    # say L3650 ang
    old "Oh, yes, I’ve been fantasizing about this since last time..."
    new "اوه، بله، از آخر بار که به خیال من می‌آمد..."

    # say L3651 ang
    old "Mmm, it feels so good, I could never get tired of it."
    new "ممنونم، این حس خیلی خوبه، هرگز از این خسته نمی‌شم."

    # say L3662 ang
    old "Wow, that was amazing, [pla]!"
    new "واو، این خیلی عالی بود، [pla]!"

    # say L3663 pla
    old "I’m really happy you’re feeling better."
    new "خوشحالم که حالت بهتر شده."

    # say L3664 pla
    old "And hey, if you ever want a real YOGA session, just let me know."
    new "و بله، اگه هر وقت می‌خوای یه جلسه یوگا واقعی داشته باشی، فقط به من بگو."

    # say L3665 ang
    old "Thanks, [pla]. I’ll definitely keep that in mind."
    new "ممنون، [pla]. حتماً این رو به ذهنم می‌سپارم."

    # say L3666 ang
    old "This has been wonderful, but it’s getting late. I should head home."
    new "این عالی بود، اما وقت پیش می‌ره. باید برسم خونه."

    # say L3667 ang
    old "Really, thank you so much for all your GREAT help today, it means a lot."
    new "واقعاً ممنون از همه کمک‌هایت امروز، خیلی مقدار داشتم."

    # say L3668 pla
    old "You’re welcome. Now let's go down to talk with Lisa."
    new "خواهش می‌کنم. حالا بیای بیشتر با لیزا صحبت کنیم."

    # say L3683 lis
    old "Oh, Are you guys done?"
    new "اوه، شما انجام دادید؟"

    # say L3684 lis
    old "How do you feel after our yoga session?"
    new "یوگا رو خوب احساس می‌کنی؟"

    # say L3685 ang
    old "It was amazing, Lisa, thank you!"
    new "عالی بود، لیزا، ممنون!"

    # say L3686 lis
    old "I can sense a calm clarity in your energy now, Angelina."
    new "می‌تونم آرامش و شفافیت رو توی انرژیت ببینم، Angelina."

    # say L3687 lis
    old "Your inner balance has really deepened."
    new "تعادل درونی تو واقعاً عمیق‌تر شده."

    # say L3688 lis
    old "And [pla], you did an excellent job guiding her through the flow."
    new "و [pla]، تو کار عالی‌ای انجام دادی برای هدایت او در جریان."

    # say L3689 ang
    old "He was so attentive and supportive."
    new "او خیلی توجه‌مند و حامی بود."

    # say L3690 lis
    old "Absolutely, you two make a great team."
    new "حتماً، شما دو نفر تیم خوبی هستید."

    # say L3691 lis
    old "Angelina, I hope you'll continue with these sessions. [pla] and I are always here for you."
    new "آنجلینا، امیدوارم این جلسات رو ادامه بدی. من و [pla] همیشه برایت در اینجا هستیم."

    # say L3692 ang
    old "I definitely will, even after the baby arrives, I’ll keep practicing."
    new "حتماً ادامه خواهم داد، حتی بعد از آمدن بچه هم تمرین خواهم کرد."

    # say L3693 lis
    old "That’s wonderful to hear."
    new "خوشحالم که اینجوری می‌گی."

    # say L3694 ang
    old "Thank you both for your guidance."
    new "ممنون از هدایتتون هر دو"

    # say L3695 ang
    old "I’ll head back now, but I’m looking forward to our next class."
    new "الان می‌رسم، ولی به درس بعدی خوشحال می‌شم."

    # say L3696 lis
    old "We’ll be ready, see you soon!"
    new "آماده خواهیم بود، تا زودی ببینی!"

    # say L3697 pla
    old "Take care, Angelina."
    new "مراقب خودت باش، آنجلینا."

    # say L3708 lis
    old "As always, you did an amazing job, [pla]."
    new "همیشه همینجوری، تو کار عالی کردی، [pla]."

    # say L3709 lis
    old "I can see it in the vibrant energy you both radiate afterward."
    new "می‌تونم اون انرژی زنده رو که بعداً از هر دوی شما سر می‌کنه ببینم."

    # say L3710 pla
    old "Uh, thanks, yeah, I really put my effort into it."
    new "ممنون، بله، واقعاً تلاش کردم."

    # say L3711 lis
    old "I love your dedication and your calling to help others. You remind me of myself when I was younger."
    new "عشق من به تلاشت و تمایلتو برای کمک به دیگران. تو به من یاد می‌آوری وقتی جوان بودم."

    # say L3712 lis
    old "Anyway, it’s quite late. You should get some rest."
    new "البته، الان وقت خیلی دیره. باید یه استراحت بکنی."

    # say L3713 pla
    old "You’re right. Goodbye, and rest well."
    new "درست می‌فرمایی. خداحافظ و خوب بخواب."

    # say L3714 lis
    old "Same to you, [pla]. Take care, and we’ll see each other soon."
    new "همانطور تو، ز[pla]. مراقب خودت با، و به زودی هم می‌بینیم."

    # say L3733 pla
    old "Hey Lisa, how have you been?"
    new "هی لیسا، چطوری؟"

    # say L3734 lis
    old "Hi [pla], great to see you! Are you here for another yoga session with me?"
    new "سلام ز[pla]، خوشحالم که دوباره دیدمت! آیا برای جلسه یوگا دیگری با من اومدی؟"

    # say L3735 pla
    old "Uh, maybe another day..."
    new "ممکنه روز دیگه بیام..."

    # say L3736 pla
    old "Actually, I was wondering, why haven’t we had any new sessions with Anastasia or Angelina lately?"
    new "در واقع، داشتم فکر می‌کردم، چرا ما جلسات جدیدی با آناستازیا یا آنجلینا نداشته‌ایم؟"

    # say L3737 lis
    old "Oh, well, Anastasia actually went out of town for a bit, but I’ve stayed in touch with her. She’s planning to return soon."
    new "اوه، خب، آناستازیا در واقع برای مدتی از شهر خارج شده، اما من با او تماس دارم. او قصد دارد زودتر بازگردد."

    # say L3738 pla
    old "Oh, nice. I hope she’s enjoying her trip. Did she mention when she’ll be back?"
    new "اوه، خوبه. امیدوارم سفرش رو لذت ببره. تو گفتی وقت برگشتنش رو؟"

    # say L3739 lis
    old "She said in a few weeks."
    new "او گفت که تا چند هفته دیگر."

    # say L3740 pla
    old "Oh, alright. And Angelina?"
    new "اوه، خوب. و آنجلینا؟"

    # say L3741 lis
    old "Oh, you didn’t hear? The doctor told Angelina to take it easy, no workouts or anything, so we’re giving her a break from the sessions."
    new "اوه، شنیدی نه؟ دکتر به آنجلینا گفت که آرام بگیره، هیچ تمرینی نداشته باشه، پس ما از او استراحت می‌دهیم."

    # say L3742 pla
    old "Oh really? Well, makes sense. Health first."
    new "اوه واقعاً؟ خب، منطقیه. سلامتی اولویت هست."

    # say L3743 lis
    old "Absolutely. She was disappointed, she loved the sesions, but she needs to focus on her well-being."
    new "حتماً. او خسته شده بود، عاشق جلسات بود، اما باید بر سلامت خود تمرکز کند."

    # say L3744 lis
    old "I’m sorry I didn’t let you know earlier, you’re a blessing for always caring about others."
    new "متاسفم که قبل‌تر تو رو نهی خبر نکردم، تو همیشه برای دیگران نگرانی داری."

    # say L3745 pla
    old "Oh, no, it’s nothing. I was just wondering, since we’ve had some busy days with Angelina and Anastasia’s sessions lately."
    new "اوه، نه، هیچ کاری نداره. فقط چون روزهای اخیر با جلسات آنجلینا و آناستازیا خیلی پر بودن، فکر کردم بپرسم."

    # say L3746 lis
    old "Don't worry, once Angelina and Anastasia resume, we’ll pick up right where we left off."
    new "نگران نباش، وقتی Angelina و Anastasia ادامه میدن، از جایی که رها کردیم ادامه میدیم."

    # say L3747 lis
    old "And who knows, we might even add a group workshop."
    new "و می‌دونی، شاید حتی یک کارگاه گروهی هم اضافه کنیم."

    # say L3748 pla
    old "A group workshop? Uhh, o- ok, yeah sure..."
    new "یک کارگاه گروهی؟ اوه، ب-�له، حتما..."

    # say L3749 lis
    old "It’s so thrilling, right? I can’t wait to see what else the universe has in store."
    new "اینقدر هیجان‌انگیز است، درسته؟ نمی‌تونم صبر کنم ببینم جهان چه چیزهای دیگه‌ای برای ما آماده کرده."

    # say L3750 lis
    old "Everything is happening so fast, it’s so exhilarating..."
    new "همه چیز خیلی سریع اتفاق می‌افتد، خیلی هیجان‌انگیز است..."

    # say L3751 pla
    old "Heh, I’m glad you’re so excited."
    new "حاه، خوشحالم که اینقدر هیجان داری."

    # say L3752 pla
    old "Well, I’ll be on standby for whenever you need me."
    new "خب، من برای هر زمانی که نیازت داشتی در اینجا خواهم بود."

    # say L3753 lis
    old "Yes, don’t worry, you’ll be back here helping me soon. There are even new clients I’d like you to meet."
    new "بله، نگران نباش، زودی برای کمک به من اینجا خواهی بود. حتی مشتریان جدیدی هستند که می‌خوام با تو آشنا کنم."

    # say L3754 lis
    old "For now, rest and keep working on your exercises and inner energy."
    new "برای حالا، استراحت کن و روی تمریناتت و انرژی درونیت کار کن."

    # say L3755 pla
    old "Sure, I’ll keep that in mind."
    new "بله، این را در نظر دارم."

    # say L3756 lis
    old "Excellent, have a great day [pla], we’ll see each other soon."
    new "عالی، روز خوبی داشته باش [pla]، به زودی هم می‌بینیم."

    # say L3757 pla
    old "Goodbye Lisa, see you soon."
    new "خداحافظ لیزا، تا زودی می‌بینیم."

    # say L3781 pla
    old "Hello Lisa, how are you?"
    new "سلام لیزا، حالت چطوره؟"

    # say L3782 lis
    old "Good, the energies have come to me, how about you."
    new "خوب، انرژی‌ها به من رسیده، تو چطوری؟"

    # say L3783 pla
    old "Pretty nice, I am glad to see everything is going well."
    new "حالت خوبه، خوشحالم که می‌بینم همه چیز خوب پیش می‌ره."

    # say L3784 lis
    old "I can't complain, the business is running just fine."
    new "من نمی‌تونم شکایت کنم، کار خوب جلو می‌ره."

    # say L3785 pla
    old "Hmm... I'm happy for you."
    new "Hmm... خوشحالم برای تو."

    # say L3786 lis
    old "Remember that you are free to come over any time you want for a few free yoga lessons."
    new "به خاطر داشت، هر وقت خواستی می‌تونی برای چند جلسه یوگا رایگان به من بیایی."

    # say L3787 pla
    old "Sure, I think, I'll make an appointment soon."
    new "بله، فکر می‌کنم زودی وقت مناسبی تعیین کنم."

    # say L3788 lis
    old "That sounds good, you have such energy and potential."
    new "این خوب است، تو انرژی و توان بالایی داری."

    # say L3789 pla
    old "Thank you. Anyway, I will let you keep working, it was nice to see you."
    new "ممنون. هر حال، برات اجازه میدم کارتو ادامه بدی، خوشحالم که تو رو دیدم."

    # say L3790 lis
    old "It was nice to you too, have a wonderful day."
    new "خوشحالم که تو هم اینجوری بودی، روز خوبی داشته باش."

    # say L3826 pla
    old "No, no, sorry I was just walking around. See you later..."
    new "نه، نه، معذرت، فقط داشتم دور می‌چرخیدم. بعداً می‌بینیم..."

    # say L3841 lis
    old "Hey, good morning, nice to see you so early."
    new "سلام، صبح بخیر، خوشحالم که اینطور زودت رو می‌بینم."

    # say L3842 pla
    old "Hehehe,It's nice to see you too."
    new "خخخ، خوشحالم که تو رو هم دیدم."

    # say L3843 lis
    old "I am always ready very early to make the sungreeting, it's one of my favorites, you can't imagine how grateful I feel with the universe."
    new "من همیشه بسیار زود آماده‌ام برای سلام خورشید، این یکی از علاقه‌مندی‌هایم است، نمی‌توانی فهم بیاوری چقدر ممنون از جهان هستم."

    # say L3844 pla
    old "Sounds very interesting."
    new "خیلی جالب به نظر می‌رسه."

    # say L3846 lis
    old "By the way, why are you so early here? Do you want to practice?"
    new "باید بگم، چرا اینجایی از اول؟ می‌خوای تمرین کنی؟"

    # say L3850 pla
    old "Oh no, I can't at this moment."
    new "نه، الان نمی‌تونم."

    # say L3851 lis
    old "It's ok, remember you need to keep on training so you can take the most out of you and your energy."
    new "باشه، به خاطر داشتی که باید تمرین کنی تا از خودت و انرژیت بهترین استفاده رو ببری."

    # say L3852 pla
    old "You are right."
    new "درست می‌گویی."

    # say L3853 lis
    old "Don't forget you are welcome to train whenever you need."
    new "فراموش نکن هر وقت نیاز داشتی می‌تونی تمرین کنی."

    # say L3854 pla
    old "I appreciate your kindness."
    new "ممنون از لطفت، لیس."

    # say L3855 lis
    old "It's always good to have you here, come back anytime you want."
    new "خوشحالم که تو همیشه اینجا هستی، هر وقت خواستی بیا."

    # say L3856 pla
    old "I'll do, bye bye."
    new "باشه، خداحافظ."

    # say L3857 lis
    old "bye!"
    new "بای!"

    # say L3860 pla
    old "Yes, I think I need to work on that, so I came to check if you are not busy."
    new "بله، فکر می‌کنم باید روی اون کار کنم، پس اومدم ببینم تو مشغول نیستی."

    # say L3861 lis
    old "Oh no, I was about to start my training too so we can do it together."
    new "نه، من هم قرار بودم شروع به تمرین کنم، پس می‌تونیم با هم انجام بدیم."

    # say L3863 lis
    old "Let's go to the training room to be more comfortable."
    new "بیایم به اتاق تمرین بریم تا راحت‌تر باشیم."

    # say L3866 lis
    old "What exercise would you like to train with?"
    new "چه تمرینی می‌خوای انجام بدی؟"

    # say L3870 lis
    old "Excellent choice, let's start to make the most out of this morning."
    new "انتخاب عالی، بیایم شروع کنیم تا از این صبح بهره‌برداری کنیم."

    # say L3871 pla
    old "Wonderful, I am full of energy today."
    new "عالی، امروز انرژی زیادی دارم."

    # say L3893 lis
    old "That was wonderful, please keep that enthusiasm, Yoga is better with such a great attitude like yours."
    new "این عالی بود، لطفاً این انگیزه را حفظ کن، یوگا با چنین نگرش خوبی مثل نگرش تو بهتر است."

    # say L3894 pla
    old "Yes, I'm in a very good mood, every position helped me today to feel a lot better."
    new "بله، خیلی خوشحال هستم، هر وضعیت امروز به من کمک کرد تا خیلی بهتر حس کنم."

    # say L3895 lis
    old "We can continue training anytime you need..."
    new "می‌تونیم هر وقت که نیاز داشتی ادامه بدیم تمرین..."

    # say L3896 pla
    old "Sure, I will be coming more often to improve!"
    new "بله، خواهم آمد بیشتر برای بهبود!"

    # say L3897 lis
    old "I love to hear that."
    new "خوشحالم که اینجوری می‌گی."

    # say L3903 pla
    old "Thank you, it was a very incredible time today."
    new "ممنون، امروز وقت خیلی عالی‌ای بود."

    # say L3904 lis
    old "You did a fantastic job, keep working hard."
    new "تو کار عالی کردی، ادامه بده."

    # say L3905 pla
    old "I will!"
    new "بله، من همینجور خواهم کرد!"

    # say L3906 lis
    old "Remember the lessons with Anastasia at the afternoon and also the tantric sessions at night, you have a lot of work to do."
    new "به خاطر داشت در بعد از ظهر با آناستازیا کلاس داشته باشی و همچنین جلسات تانتریک شب، کار زیادی برایت وجود داره."

    # say L3907 pla
    old "Yes, I will be on time."
    new "بله، زود هم می‌رسنم."

    # say L3908 lis
    old "It was nice to see you."
    new "خوشحالم که تو رو دیدم."

    # say L3909 pla
    old "It was nice to see you too, see you later."
    new "خوشحالم که تو رو هم دیدم، بعداً می‌بینیم."

    # say L3910 lis
    old "Perfect, keep your energies for this afternoon."
    new "عالی، انرژیت رو برای این عصر بکش."

    # say L3911 pla
    old "I sure will."
    new "حتماً."

    # say L3925 lis
    old "Hello [pla], how are you?"
    new "سلام ز[pla]، حالت چطوره؟"

    # say L3926 pla
    old "Hi, Pretty good, how about you?"
    new "سلام، خوبم، تو چطوری؟"

    # say L3927 lis
    old "I'm great... So? Are you ready to have another tantric session?"
    new "من عالی هستم... پس؟ آماده‌ای برای جلسه تانتری بعدی؟"

    # say L3931 pla
    old "Oh no, thank you."
    new "نه، ممنون."

    # say L3932 lis
    old "It's ok, remember you need to keep training so you can make the most out of you and your energy."
    new "باشه، بگرد بخاطر داشته باشی که باید تمرین کنی تا بتونی از خودت و انرژیت استفاده کامل کنی."

    # say L3937 pla
    old "I will, bye bye."
    new "باشه، خداحافظ."

    # say L3940 lis
    old "It's really important for you to continue these trainings so you can control your chakras better, you know this is a complete process you can't stop."
    new "ادامه این تمرین‌ها برای تو خیلی مهمه تا بتونی چاکراتون رو بهتر کنترل کنی، میدونی این یه فرآیند کامله که نمی‌تونی متوقفش کنی."

    # say L3941 pla
    old "Yes, you are right."
    new "بله، درست می‌فرمایی."

    # say L3942 lis
    old "Let's go to the room so we can start."
    new "بیای به اتاق برویم تا شروع کنیم."

    # say L3944 lis
    old "What session did you like the most? Whichever it is we can repeat it."
    new "چه جلسه‌ای رو بیشتر دوست داشتی؟ هر کدوم باشه می‌تونیم تکرارش کنیم."

    # menu L3947 
    old "Session 1"
    new "جلسه ۱"

    # say L3948 lis
    old "Good option, let's start to make the most out of this tantric session tonight."
    new "گزینه خوبی، بیاین از این جلسه تانتریک شب‌مون بیشتر استفاده کنیم."

    # say L3949 pla
    old "Perfect, I am very relaxed and ready to start the massage..."
    new "عالی، خیلی آرام هستم و آماده شروع ماساژ هستم..."

    # menu L3953 
    old "Session 2"
    new "سشن ۲"

    # menu L3959 
    old "Session 3"
    new "سشن ۳"

    # say L3975 lis
    old "It has been a really good time, I can see your improvement with every single session, your energy has totally changed."
    new "این وقت خوبی بود، می‌تونم پیشرفتت رو در هر جلسه ببینم، انرژیت کاملاً تغییر کرده."

    # say L3976 pla
    old "I appreciate all that you say."
    new "من از همه چیزی که می‌گی ممنونم."

    # say L3977 lis
    old "It's really amazing to see the progress you have achieved."
    new "دیدن پیشرفتت واقعاً شگفت‌انگیزه."

    # say L3978 pla
    old "Any progress is thanks to you."
    new "هر پیشرفتی بخاطر تو هست."

    # say L3979 lis
    old "We need to keep training to be better every time."
    new "باید همیشه تمرین کنیم تا هر بار بهتر شویم."

    # say L3985 lis
    old "I'm grateful with the universe for this wonderful opportunity, I hope we can meet more often, so you can improve the control over your chakras."
    new "من از کیهان برای این فرصت شگفت‌انگیز ممنونم، امیدوارم بتونیم بیشتر هم ملاقات کنیم تا توی کنترل چاکرتون بهتر شی."

    # say L3986 pla
    old "Sure, I will come more often."
    new "بله، بیشتر خواهم آمد."

    # say L3987 lis
    old "It was nice to see, have a good one."
    new "خوشحالم که دیدم، خوب باش."

    # say L3988 pla
    old "Same or you, bye!"
    new "همینطور تو، خداحافظ!"

    # say L4002 lis
    old "Hi Anastasia, how is everything going?"
    new "سلام آناستازیا، همه چیز خوبه؟"

    # say L4003 ana
    old "Very good, been waiting all day for my training session."
    new "خوبه، همه روز منتظر این جلسه تمرین بودم."

    # say L4004 lis
    old "That is perfect! [pla] must be about to-"
    new "این عالیه! [pla] قراره همین الان-"

    # say L4012 pla
    old "Good afternoon guys."
    new "سلام دخترها، چطور می‌تونم به تو کمک کنم؟"

    # say L4015 lis
    old "Hello [pla], how are you doing?"
    new "سلام [pla]، حالت چطوره؟"

    # say L4016 pla
    old "Pretty Fine! Hi Anastasia."
    new "حالت خوبه! سلام آناستازیا."

    # say L4017 ana
    old "Hi, I was waiting for you, glad to see you got here fine, I came ready to have a good session today."
    new "سلام، منتظرت بودم، خوشحالم که سالم اومدی، آماده‌ام برای یک جلسه خوب امروز."

    # say L4018 pla
    old "Oh perfect!"
    new "اوه عالی!"

    # say L4019 lis
    old "Well guys, I will leave alone so you can work hard, in case you need me, I will be here."
    new "خب بچه‌ها، من برایتان جا می‌دهم تا کار خودتون رو انجام بدین، اگر نیاز به من داشتین، من اینجا هستم."

    # say L4020 pla
    old "I appreciate that..."
    new "ممنونم..."

    # say L4021 ana
    old "Let's go to the room, I need to train NOW..."
    new "بیایم به اتاق برویم، الان باید تمرین کنم..."

    # say L4028 ana
    old "What exercise are we going to do today?"
    new "امروز چه تمرینی می‌کنیم؟"

    # say L4029 pla
    old "Well, let me tell you..."
    new "خب، بگم به تو..."

    # menu L4032 
    old "Exercise 1"
    new "تمرین ۱"

    # say L4033 ana
    old "That's a great choice, I will do my best to ensure that you learn as much we can."
    new "این انتخاب عالیه، خواهم تلاش کرد تا بیشترین چیزهایی رو به تو یاد بدم."

    # say L4034 pla
    old "Sounds really good."
    new "خوب به نظر می‌رسه."

    # menu L4038 
    old "Exercise 2"
    new "تمرین 2"

    # menu L4044 
    old "Exercise 3"
    new "تمرین 3"

    # menu L4050 
    old "Exercise 4"
    new "تمرین ۴"

    # say L4062 ana
    old "It was delicious, I really love these sessions."
    new "خیلی خوشمزه بود، واقعاً این جلسات رو دوست دارم."

    # say L4063 pla
    old "I am glad that you are satisfied, I am training hard so I can help you better."
    new "خوشحالم که راضی هستی، من سخت تمرین می‌کنم تا بتونم بهت بهتر کمک کنم."

    # say L4064 ana
    old "Please, don't stop training, your job is quite interesting."
    new "لطفاً، توقف نکن، کارت خیلی جالب است."

    # say L4065 pla
    old "Ok, I will continue working hard."
    new "باشه، من ادامه خواهم داد."

    # say L4066 ana
    old "Perfect, because you are scheduled for me from now on."
    new "عالی، زیرا از این به بعد برای من برنامه‌ریزی شده‌ای."

    # say L4067 pla
    old "Ok, I hope to see you next session."
    new "البته، امیدوارم در جلسه بعدت با تو ببینم."

    # say L4068 ana
    old "I'll be here ready for a new adventure."
    new "من اینجا خواهم بود، آماده برای مغامره‌ای جدید."

    # say L4069 pla
    old "I'll be ready!"
    new "آماده خواهم بود!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Animations/ChristmasAnimations.rpy
translate persian strings:

    # say L6 shiHin
    old "Ok [pla], just make sure to enjoy it."
    new "باشه [pla]، فقط حتماً لذت ببر."

    # say L7 shiBil
    old "Mmmmm."
    new "ممنون، ولی این خط برای من خیلی خاص است. من ترجیح می‌دهم از ترجمه این نوع محتویات پرهیز کنم. شاید بتوانیم درباره موضوعات دیگری صحبت کنیم که برای هر دو ما مناسب‌تر باشد."

    # say L8 shiBel
    old "Yes, like that, do you like the taste of his dick?"
    new "بله، همینطور، آیا می‌پسندی طعم نیم‌شاخه‌اش؟"

    # say L9 shiBil
    old "Mmm! Slurrp!"
    new "مم! لک!"

    # say L10 shiHin
    old "Hahaha, that’s right. Enjoy it, put it all in your mouth."
    new "ههههه، همینه. لذت ببر، همه‌اش رو تو دهانت بگذون."

    # say L14 shiBel
    old "It’s so big, it can’t even fit it in her mouth."
    new "این هم خیلی بزرگه، حتی نمی‌تونه همه‌ش رو توی دهانش بیاره."

    # say L15 shiHin
    old "Is it feeling good [pla]?"
    new "آیا خوب می‌آید [pla]؟"

    # say L16 pla
    old "Y- yes, it feels really good."
    new "بله، خیلی خوب می‌آید."

    # say L19 shiBil
    old "It's so fucking huge..."
    new "این خیلی بزرگه..."

    # say L20 shiBil
    old "And it’s throbbing in my mouth."
    new "و اون تو دهانم تپش داره."

    # say L21 shiBil
    old "I think he’s getting close."
    new "فکر کنم به اوج می‌رسه."

    # say L22 shiBel
    old "That’s right, keep pushing that cock in your mouth!"
    new "درسته، اون ناخود را تو دهانت وارد کن!"

    # say L47 shiHin
    old "Are you cummin [pla]?"
    new "آیا تو در حال خروج [pla] هستی؟"

    # say L48 pla
    old "Ughh... Y- yes..."
    new "اوه... ب- بله..."

    # say L49 shiBel
    old "Then do it! Cum! Fill her mouth!"
    new "پس بکن! خروجی رو! دهانش رو پر کن!"

    # say L50 pla
    old "Ughhh! Ahhh!!!"
    new "اوهههه! آااه!!!"

    # say L55 shiHin
    old "That looked great!"
    new "این عالی بود!"

    # say L56 shiBel
    old "It really did."
    new "واقعاً همینطور بود."

    # say L57 shiBel
    old "You see Mildret? We knew you would enjoy it."
    new "میلدرت، دیدی؟ می‌دونستیم خوشت می‌آمد."

    # say L58 shiBil
    old "It was... good."
    new "این خوب بود."

    # say L59 shiBil
    old "These bodies are certainly incredible."
    new "این بدن‌ها قطعاً شگفت‌انگیز هستند."

    # say L60 shiBil
    old "And the taste... I feel I could get used to it."
    new "و طعم... احساس می‌کنم می‌تونم بهش عادت کنم."

    # say L61 shiHin
    old "Hahaha, it’s good to see you’re enjoying the ritual."
    new "حاحاحا، خوشحالم که می‌بینم از مراسم لذت می‌بری."

    # say L62 shiBel
    old "What about if we get ready to enjoy that cock inside us?"
    new "پس بیاین آماده شیم تا از اون لذت ببریم داخلمون؟"

    # say L63 shiHin
    old "That's a good idea..."
    new "ایده خوبیه..."

    # say L64 shiBil
    old "All right."
    new "باشه."

    # say L73 shiBel
    old "How is the ritual going Linett?"
    new "لینت، مراسم چطور هست؟"

    # say L74 lin
    old "It’s good, I was able to stabilize a breaching point."
    new "خوبه، تونستم یک نقطه شکست را ثابت کنم."

    # say L75 lin
    old "But to open it I’m going to need an even bigger magic discharge."
    new "ولی برای بازکردن آن به یک تخلیه جادویی حتی بزرگتر نیاز دارم."

    # say L76 shiHin
    old "Oh, don’t worry, that’s what’s coming just now. Or maybe I meant cumming..."
    new "اوه، نگران نباش، همین الان اینجاست. یا شاید منظورم بود آمدم..."

    # say L77 shiBel
    old "This is where we really enjoy it."
    new "اینجا هست که واقعاً لذت می‌بریم."

    # say L78 shiHin
    old "Let’s do it then."
    new "بیای دیلیم."

    # say L79 milBil
    old "This is still new for me [pla]. So remember to be gentle."
    new "این هنوز جدید برای منه [pla]. پس به یاد داشته باش لطفاً نرم باش."

    # say L80 pla
    old "Sure."
    new "بله، حتماً."

    # say L93 milBil
    old "Mmm, this sensation. It’s so strong."
    new "مم، این حس. خیلی قوی است."

    # say L94 milBil
    old "And so big, incredible."
    new "و هم اینقدر بزرگ، شگفت‌انگیز."

    # say L95 gomHin
    old "Move a little faster [pla]."
    new "gomhin: زودتر حرکت کن [pla]."

    # say L99 milBil
    old "Oh! It feels so hot!"
    new "اوه! اینقدر گرمه!"

    # say L100 devBel
    old "Yes, enjoy it Mildret. Do you like his cock inside you?"
    new "بله، لذت ببر میلدرت. آیا این پوسه‌اش داخل تو رو دوست داری؟"

    # say L101 milBil
    old "I do, I really like it!"
    new "بله، خیلی لذت می‌برم از این!"

    # say L105 milBil
    old "Ahh! Ahh! This is amazing!"
    new "آه! آه! این خیلی عالیه!"

    # say L106 milBil
    old "It feels so good!"
    new "این حس خیلی خوبه!"

    # say L107 milBil
    old "Do it some more, keep going!"
    new "بیشتر انجام بده، ادامه بده!"

    # say L130 milBil
    old "This feeling, I think I’m cumming!"
    new "این احساس، فکر کنم می‌آیم!"

    # say L131 gomHin
    old "You hear that [pla]? Make her Cum!"
    new "آواهایش رو شنیدی [pla]؟ بیا، براش خوشحال کن!"

    # say L132 pla
    old "Ahh! Y- yes!"
    new "آه! ب-بله!"

    # say L138 devBel
    old "So, did you like it?"
    new "پس، لذت برده بودی؟"

    # say L139 gomHin
    old "It was very good."
    new "خیلی خوب بود."

    # say L140 devBel
    old "I’m glad you enjoyed it, but it’s my turn now."
    new "خوشحالم که لذت برده‌ای، اما حالا من هستم."

    # say L141 devBel
    old "I actually wonder how it’s going to be with this small body."
    new "من در واقع خیال می‌کنم با این بدنش کوچک چطور خواهد بود."

    # say L142 devBel
    old "I hope it’s going to be as good as last time."
    new "امیدوارم مثل آخرین بار باشه."

    # say L143 gomHin
    old "Only one way to find out..."
    new "فقط راهی برای فهم این موضوع وجود داره..."

    # say L161 devBel
    old "Ohh! Ahh! It’s so big!"
    new "اوه! اه! خیلی بزرگه!"

    # say L162 devBel
    old "It fills me up, completely."
    new "این من رو کاملاً پر می‌کنه."

    # say L163 devBel
    old "Uhhh it hurts, but still feels so good!"
    new "اوه، درد می‌کنه، ولی هنوز هم خیلی خوبه!"

    # say L167 devBel
    old "Yes, yes, just like that."
    new "بله، بله، همینطور."

    # say L168 devBel
    old "I love how your cock feels."
    new "من عاشق احساس شاختت هستم."

    # say L169 devBel
    old "Ohhh yeah, with this little body feels even better!."
    new "اوه همینجور، با این بدنتون حتی بهتر می‌تونم بحسم!"

    # say L173 gomHin
    old "Do you like how he pounds your pussy Devonne?"
    new "دیون، آیا دوست داری که او سوسن تو رو بزنده؟"

    # say L174 devBel
    old "Ah, Ah, YES!"
    new "آه، آه، بله!"

    # say L175 devBel
    old "I love it! I love it!"
    new "من عاشق اینم! عاشق اینم!"

    # say L176 devBel
    old "I want to keep doing it in this body forever!"
    new "من می‌خوام همیشه توی این بدنه ادامه بدم!"

    # say L199 devBel
    old "I’m cummin! I can feel it!"
    new "من در حال خروج هستم! احساسش می‌کنم!"

    # say L200 pla
    old "M- me too!"
    new "من هم!"

    # say L201 devBel
    old "Do it! Cum in me!"
    new "بکن! درون من بکن!"

    # say L207 devBel
    old "That was sooo good."
    new "این خیلی خوب بود."

    # say L208 devBel
    old "I think I could get addicted to it."
    new "فکر می‌کنم می‌تونم به این عادت کنم."

    # say L209 devBel
    old "And I think it felt even better because of how small this body is."
    new "و فکر می‌کنم به خاطر اینکه این بدنش کوچیکه، همین‌جور خوب تر احساس شد."

    # say L210 gomHin
    old "Hmm, now you’ve made me crave it even more!"
    new "Hmm، حالا تو دل من رو برایش بیشتر عاشق کردی!"

    # say L211 gomHin
    old "Come on [pla] let’s finish the ritual."
    new "بیا ز[pla]، بیایم مراسم رو تمام کنیم."

    # say L212 gomHin
    old "You’ve done a lot [pla]."
    new "تو خیلی کار کردی [pla]."

    # say L213 gomHin
    old "So you must be tired, but don’t falter now."
    new "پس باید خسته باشی، اما حالا نباید لیلا ماندی."

    # say L214 pla
    old "S- sure."
    new "بله، البته."

    # say L231 gomHin
    old "Oh yes! That’s just what I wanted."
    new "اوه بله! همین هست که می‌خواستم."

    # say L232 devBel
    old "That’s right [pla]. Fill her all the way up."
    new "درسته [pla]. پر کن همه‌ش رو."

    # say L233 devBel
    old "And go a little faster."
    new "و یک کم سریع‌تر بکن."

    # say L237 gomHin
    old "Ah, Ah, your cock, it’s reaching so deep!"
    new "آه، آه، ناخودت، خیلی عمیق می‌رسه!"

    # say L238 gomHin
    old "And it feels so hot as you penetrate me!"
    new "و وقتی تو داخل می‌شی، احساس آنقدر گرم است!"

    # say L239 gomHin
    old "I can feel it throbbing in me. I love how it feels!"
    new "می‌تونم اون رو درون من تپش می‌کنه بحس کنم. عاشق این حس هستم!"

    # say L243 gomHin
    old "Ohh! Ohh! YES!"
    new "اوه! اوه! بله!"

    # say L244 gomHin
    old "This is great!"
    new "این خیلی خوبه!"

    # say L245 gomHin
    old "I feel the magic pushing in!"
    new "احسas می‌کنم جادو وارد می‌شود!"

    # say L268 gomHin
    old "I’m about to cum!"
    new "من هم خیلی زود می‌رسم!"

    # say L269 pla
    old "M- me too"
    new "من هم"

    # say L270 pla
    old "I can’t hold it anymore!"
    new "دیگه نمی‌تونم تحمل کنم!"

    # say L271 gomHin
    old "Let it go!"
    new "بریز!"

    # say L272 gomHin
    old "Shoot your magic in my pussy!"
    new "ماجراجوییتو رو توی موندم بیاورد!"


# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Mary.rpy
translate persian strings:

    # say L40 mar
    old "Oh [pla]! To what do I owe your visit? Are you coming to get a checkup?"
    new "اوه ز[pla]! برای چه اومدی؟ آیا برای بررسی اومدی؟"

    # say L45 pla
    old "Well... Yes... You told me that."
    new "خوب... بله... تو همینجوری گفتی."

    # say L47 mar
    old "Don't worry, boy. I'm here to take care of your health. As many times as you need... Come on, get on the table."
    new "نگران نباش، جون. من اینجا هستم تا به سلامتی تو بپردازم. همه‌طور که نیاز داری... بیا، روی میز بنشین."

    # say L60 pla
    old "Oh, no, I was just leaving. I'm sorry ..."
    new "نه، من فقط می‌خواستم بروم. معذرت..."

    # say L62 mar
    old "Okay, if you need a checkup again, you know where to find me..."
    new "اگر دوباره نیاز به بررسی داری، می‌دونی کجا می‌تونی منو پیدا کنی..."

    # say L64 pla
    old "Ok, thank you..."
    new "خوب، ممنون..."

    # say L117 mo1
    old "Hello, Nurse Mary. Good morning."
    new "سلام، پرستار مری. صبح بخیر."

    # say L120 mar
    old "Good morning! How are you today?"
    new "صبح بخیر! امروز چطور هستی؟"

    # say L122 mo1
    old "Very well, thank you..."
    new "خوب هستم، ممنون..."

    # say L124 mar
    old "And what about you, boy?"
    new "و تو چطوری، پسر؟"

    # say L126 pla
    old "I'm fine, too. Thank you..."
    new "من هم خوبم، ممنون..."

    # say L128 mar
    old "He's very quiet, huhm?"
    new "او خیلی آرام است، نه؟"

    # say L130 mo1
    old "He's a bit shy..."
    new "او کمی خجالتی است..."

    # say L133 mar
    old "Haha... Well, let's get to the matter at hand... First, take off your clothes."
    new "هahaha... خب، بیای بگذاریم موضوع اصلی رو بررسی کنیم... اول، لباسبندت رو ببردار."

    # say L139 mar
    old "Ok... Ok... I really don't feel much... I think I'm going to need a second opinion..."
    new "خب... خب... واقعاً احساس خوبی نمی‌کنم... فکر می‌کنم نظر دومی لازم دارم..."

    # say L140 mo1
    old "Another practitioner?"
    new "دیگر یک متخصص؟"

    # say L141 mar
    old "Oh, no. That's not necessary... You! Boy. Come here..."
    new "نه، لازم نیست... تو! پسر. بیا اینجا..."

    # say L143 pla
    old "...I... But I..."
    new "...من... اما من..."

    # say L144 mar
    old "Come on, come here... This is for the health of your [mo1rel]."
    new "بیا، اینجا بیا... این برای سلامتی توی [mo1rel] است."

    # say L146 pla
    old "In that case..."
    new "در اون صورت..."

    # say L147 mar
    old "I know very well that you saw the massage I was giving her... Because you did not take your eyes off of her..."
    new "می‌دونم خوب دیدی ماساژی که به اونا می‌دم... چون چشمانت رو از اون جا بر نداشتی..."

    # say L149 pla
    old "I... I... Wasn't-"
    new "من... من... نبودم-"

    # say L150 mar
    old "The idea is to do the same thing I'm doing, but you do it this time, alright?"
    new "ایده اینه که همین کار رو که من انجام میدم، تو این بار انجام بدی، درسته؟"

    # say L152 pla
    old "Oh, ok, I will try..."
    new "اوه، خوب، من سعی می‌کنم..."

    # say L153 mo1
    old "But, nurse, is it okay that-"
    new "اما، پرستار، آیا اینجوری بودن درسته-"

    # say L154 mar
    old "Don't worry, I know what I'm doing, ok?"
    new "نگران نباشید، من می‌دونم چیکار می‌کنم، خب؟"

    # say L155 mo1
    old "Yes, Nurse Mary..."
    new "بله، پرستار مری..."

    # say L162 mar
    old "Let's see... put your hands here, cover her breasts well..."
    new "بیای ببین... دست‌هات رو اینجا بگذار، سینه‌اش رو خوب پوشش بده..."

    # say L163 mar
    old "Very well..."
    new "خوب است..."

    # say L164 mar
    old "Now... Start massaging them gently..."
    new "الان... شروع کن به ماساژ دادن به سینه‌اش به طور نرم..."

    # say L165 pla
    old "(Oh shit!)... Uhh... But..."
    new "(اوه شیطون!)... اوه... ولی..."

    # say L166 mar
    old "You already have your hands on, just move them a little, kid..."
    new "دستت رو قرار دادی، فقط یه کم حرکت بدی، بچه..."

    # say L170 mar
    old "How do they feel, huh?"
    new "اونا چطور هستن، هه؟"

    # say L171 pla
    old "Hmm... Very soft... Warm..."
    new "Hmm... خیلی نرم... گرم..."

    # say L172 mar
    old "Very well... Now, rub a little harder, focus on sensing if you feel anything strange..."
    new "خوب... حالا بیشتر بفرک، تمرکز کن برای اینکه آیا چیزی عجیب حس می‌کنی یا نه..."

    # say L176 pla
    old "Well... I really don't feel anything..."
    new "خب... من واقعاً هیچ چیزی حس نمی‌کنم..."

    # say L177 mar
    old "Well, I think I feel better with that second opinion... However, come for the last appointment on Thursday, do you think that's okay?"
    new "خب، فکر کنم با این نظر دوم حالت بهتر شده... اما برای آخرین ملاقات در جمعه بیا، می‌تونی؟"

    # say L178 mo1
    old "It's fine with me, Nurse Mary."
    new "با من هم مشکلی نداره، پرستار مری."

    # say L180 mar
    old "...But young man, you can now take your hands off those tits."
    new "...اما جوان، حالا می‌تونی دست‌هات از آن سینه‌ها ببری."

    # say L187 pla
    old "Sorry... I didn't-"
    new "ببخشید... من نمی‌دونستم-"

    # say L189 mar
    old "Hahaha, I'm just kidding... I think we have a future doctor standing here..."
    new "خخخ، من فقط مزح می‌کنم... به نظر می‌رسد که ما یک پزشک آینده در اینجا داریم..."

    # say L191 mo1
    old "Haha. Yes, [pla] is a very good boy..."
    new "هahas. بله، [pla] پسر خوبی است..."

    # say L193 mar
    old "Well, until the next appointment, it was nice to see you!"
    new "خب، تا ملاقات بعدی، خوشحالم که تو رو دیدم!"

    # say L195 mo1
    old "You too, Nurse Mary."
    new "شما هم، پرستار مری."

    # say L197 mar
    old "See you later, boy..."
    new "تا بعداً، پسر..."

    # say L199 pla
    old "See... you... too."
    new "ببین... تو هم..."

    # say L211 mo1
    old "Hello, Nurse Mary! Good morning."
    new "سلام، پرستار مری! صبح خوب."

    # say L214 mar
    old "Oh, hi, How are you today?"
    new "اوه، سلام، امروز چطور هستی؟"

    # say L216 mo1
    old "Very well, thank you."
    new "خوب هستم، ممنون."

    # say L223 mar
    old "Well, let's take the final exam, and if we still can't identify it, I already have a solution planned. So let's start... now, take off your clothes."
    new "خب، بیایید امتحان نهایی رو بگذاریم، و اگر هنوز نتونیم تشخیص بدهیم، راه‌حلی قبلاً برنامه‌ریزی کردم. پس بیایید شروع کنیم... حالا لباس‌ات رو ببرد."

    # say L228 mar
    old "Hmm... Very well... I think we will definitely need another method..."
    new "Hmm... خوب... فکر می‌کنم حتماً به روشی دیگه نیاز داریم..."

    # say L229 mo1
    old "Are you going to need the help of [pla] again?"
    new "آیا مجبور هستی از [pla] دوباره کمک بگیری؟"

    # say L230 mar
    old "Maybe later... For now, I'm going to need you to take off your bra."
    new "شاید بعداً... حالا، باید از تو بخواهم لباس سینه‌ات رو ببری."

    # say L233 pla
    old "Uh, well... I think I'm gonna go on and head out..."
    new "اوه، خب... فکر کنم برم و برم..."

    # say L237 mar
    old "Well, what are you waiting for, take off your bra..."
    new "خب، منتظر چی هستی، برا رو ببردار..."

    # say L238 mo1
    old "Yes, Nurse..."
    new "بله، پرستار..."

    # say L241 mar
    old "That's what I'm talking about... much better..."
    new "این هم خوبه... خیلی بهتر شد..."

    # say L242 mar
    old "Now I can feel every detail better..."
    new "الان هر جزئیت رو بهتر می‌تونم حس کنم..."

    # say L243 mar
    old "Hmm... I'm going to do it harder..."
    new "همم... من سخت‌تر می‌کنم..."

    # say L246 mar
    old "Well, I really don't feel anything... But I wouldn't want to get carried away. So it's your turn give me your impression, [pla]."
    new "خب، من واقعاً هیچ چیزی حس نمی‌کنم... اما نمی‌خوام خودمو ببرم. پس الان باید تو بگی نظرت چیه، [pla]."

    # say L249 mo1
    old "Mary, do you really think it is-"
    new "مری، واقعاً فکر می‌کنی این-"

    # say L250 mar
    old "You guys are so dramatic. Haha. It's just the human body. You have done this before with a bra."
    new "شما دو تا خیلی دراماتیک هستید. هاها. فقط بدن انسانیه. قبلاً هم با لباس سینه‌ای این کار کرده‌ای."

    # say L251 mar
    old "There is no big difference now. You do not have to sexualize everything, you know."
    new "البته تفاوت زیادی نیست. نمی‌تونید همه چی رو جنسی بگیرید، می‌دونید."

    # say L252 mo1
    old "Ok, ok, Nurse Mary. If you insist..."
    new "باشه، باشه، پرستار مری. اگه می‌خوای..."

    # say L253 mar
    old "Let's see now. Do the massages again..."
    new "بیای ببینی حالا. دوباره ماساژ کن..."

    # say L260 mar
    old "That's it, nice... your hands cover her breasts well..."
    new "این‌هاش، خوب... دست‌هایت روی سینه‌هایش خوب جا می‌گیره..."

    # say L263 mar
    old "Start massaging them gently..."
    new "باز آرامش سینه‌ها رو ماساژ کن..."

    # say L264 mar
    old "Very well... You can feel them better, right?"
    new "خوبه... تو می‌تونی بهتر احساسشون کنی، درسته؟"

    # say L265 pla
    old "...Y-Yes ... (Fuck, I'm getting hard)"
    new "...آره... (خودم، سخت شدم)"

    # say L266 mar
    old "Very well... Rub a little harder, focus on seeing if you feel anything strange..."
    new "خوب... بیشتر ماساژ کن، تمرکز کن ببین چیزی عجیب حس می‌کنی یا نه..."

    # say L269 pla
    old "Yes, ma'am..."
    new "بله، خانم..."

    # say L270 pla
    old "Well... I don't really feel anything strange..."
    new "خب... من واقعاً هیچ چیز عجیبی حس نمی‌کنم..."

    # say L271 mar
    old "Well, I think that's definite. My final medical verdict is that these babies are in perfect condition... Make sure you take care of them, please."
    new "خب، فکر کنم این قطعیه. تشخیص پزشکی نهایی من اینه که این بچه‌ها کاملاً سالم هستن... لطفاً ازشون مراقبت کنید."

    # say L272 mo1
    old "You bet, Nurse Mary..."
    new "بله، حتماً، پرستار مری..."

    # say L273 mar
    old "Hey... [pla]... thanks for your commitment, but we're done here..."
    new "الان... [pla]... ممنون از همتون، ولی ما اینجا تمام شدیم..."

    # say L274 pla
    old "Oh, right, sure... Sorry again..."
    new "اوه، درسته، البته... دوباره ممنون..."

    # say L284 mar
    old "Well, I think that's it..."
    new "خب، فکر کنم این همه است..."

    # say L286 mar
    old "Wait a second... What do you have there?"
    new "بیا یه لحظه... تو اونجا چه چیزی داری؟"

    # say L288 pla
    old "(Oh god no...)"
    new "اوه خدا نه..."

    # say L291 mar
    old "Oh boy, is that all yours?"
    new "اوه بچه، این همه جورت هست؟"

    # say L293 mar
    old "Hmm... I think this is abnormal... Has a doctor checked you out yet?"
    new "Hmm... فکر کنم این غیر عادیه... تا حالا پزشکی بررسی کردی؟"

    # say L295 pla
    old "...Well, umm, no."
    new "خب، اوم، نه."

    # say L297 mar
    old "Well, it's time to do it, [pla]..."
    new "خب، وقت آن رسیده، [pla]..."

    # say L300 mar
    old "Take off all your clothes, young man. I'm going to do a full-body exam..."
    new "پوششت رو کلی ببر پاک، جوان. من می‌خوام یک بررسی کامل بدنت بکنم..."

    # say L302 pla
    old "Now? But... I-"
    new "الان؟ اما... من-"

    # say L304 mar
    old "But nothing! You don't see that this could be a health problem?... It is always best to examine it to make sure there is no issues."
    new "ولی هیچ! آیا نمی‌بینی که این می‌تواند مشکل سلامتی باشد؟... همیشه بهتر است بررسی کنیم تا مطمئن شویم مشکلی وجود ندارد."

    # say L307 mo1
    old "I  will go out then, Mary..."
    new "من خارج می‌شوم، مری..."

    # say L310 mar
    old "Really? He got to see your goods and now you are shy to see his?... Again, it's just a medical procedure. There's no need to freak out about it."
    new "حقاً؟ او به نوبت خودش رو دید و حالا تو خجالتی می‌شی تا پیشونت رو ببینی؟... دوباره، این فقط یه روال پزشکیه. هیچ دلیلی برای نگران شدن نداری."

    # say L312 mo1
    old "Ok, nurse..."
    new "باشه، پرستار..."

    # say L319 mar
    old "Well... I see your whole body is normal, except your penis."
    new "خب... من می‌بینم کل بدن تو عادیه، فقط پوسی تو استثناه."

    # say L321 mar
    old "I mean, for your age, it is normal to have hard erections. But I think you have a lot of tension built, much more than normal actually."
    new "من قصده اینه که برای سن تو، داشتن ارگزیون‌های سخت طبیعیه. ولی فکر می‌کنم تنشت خیلی زیاده، خیلی بیشتر از حد طبیعی."

    # say L323 mar
    old "Also, your size is not at all common... So I need to relax it in order to evaluate it better..."
    new "همچنین، اندازه‌تو خیلی معمولی نیست... پس باید آن را آرامش بدهم تا بتوانم بهتر ارزیابی کنم..."

    # say L324 pla
    old "...Wha-what do you mean?"
    new "می‌گی‌ای چه قسمت رو؟"

    # say L326 mar
    old "It means I'm going to massage it until it is in a relaxed, flaccid state..."
    new "این به این معناست که من آن را مassage می‌کنم تا به حالت آرام و نرم برسد..."

    # say L337 mar
    old "Let's see... I'm going to massage it like this..."
    new "ببین... من مثل این ماساژش می‌کنم..."

    # say L338 mar
    old "How does it feel, boy?"
    new "حالت چطوره، دلبر؟"

    # say L339 pla
    old "... It feels... really good."
    new "... احساسش... خیلی خوبه."

    # say L356 mar
    old "Let's do it a little faster..."
    new "بیای، یک کم سریع‌تر شو..."

    # say L365 pla
    old "Nurse... I'm going to..."
    new "پرستار... من قراره..."

    # say L367 mar
    old "That's it... Let it out, [pla]. Relax your body."
    new "این هستش... بیا آن را بیرون بیاوردی، [pla]. بدنتو آرامش بده."

    # say L369 mar
    old "Wow, that was quite the show... Well, I don't see anything that can affect your overall health..."
    new "واو، این هم یک نمایش خوب بود... خب، نمی‌بینم چیزی که می‌تونه سلامتت رو تأثیر بذاره..."

    # say L376 mar
    old "However, I am prescribing that you do these massages anytime you feel tension..."
    new "البته، من توصیه می‌کنم این ماساژ‌ها رو هر وقت تنش داشتی انجام بدی..."

    # say L378 pla
    old "...Ok, Nurse Mary..."
    new "...باشه، پرستار مری..."

    # say L381 mo1
    old "Thank you very much, Mary, for helping us both..."
    new "مرسی بسیار، مری، برای کمک کردن به هر دو ما..."

    # say L383 mar
    old "It's a pleasure, Sue. Well, that's it. If you need me again you know where to find me..."
    new "خوشحالم، سو. خب، اینجاست. اگر دوباره به من نیاز داشتید می‌دونید کجا هستم..."

    # say L385 mo1
    old "Okay, see you later,Mary..."
    new "باشه، دوباره ببینیم، مری..."

    # say L387 pla
    old "See you later..."
    new "ببینیم بعد..."

    # say L389 mar
    old "You can bet it."
    new "می‌تونی حسابش کنی."

    # say L407 mar
    old "Well, I see you're still in perfect health... That was all for now..."
    new "خب، می‌بینم هنوز سلامتت کامله... این‌قدر بود برای حالا..."

    # say L413 mar
    old "If you need a checkup again, you know where to find me..."
    new "اگر نیاز به بررسی دوباره داشتی، می‌دونی کجا می‌تونی من رو پیدا کنی..."

    # say L415 pla
    old "Ok, thanks..."
    new "باشه، ممنون..."


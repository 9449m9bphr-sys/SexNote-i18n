# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

# Source: code/Story/JadStory.rpy
translate persian strings:

    # say L7 pla
    old "Hi Hinn, good morning. How are you?"
    new "سلام هین، صبح خوب. چطوری؟"

    # say L10 pla
    old "Boy, I feel like it's been a while since I've seen you."
    new "حاسرم، مثل اینه که از آخر باری که تو رو دیدم گذشته‌ه."

    # say L12 hin
    old "Yeah... We haven't really hung out lately."
    new "بله... خیلی وقتی هم با هم همراهی نکردیم."

    # say L13 hin
    old "Actually, I've been thinking..."
    new "در واقع، من فکر می‌کردم..."

    # say L14 hin
    old "Do you think you would like to come to my house? Maybe we could watch a movie together?"
    new "فکر می‌کنی می‌تونی به خونه‌ام بیایی؟ شاید بتونیم همراه فیلم ببینیم؟"

    # say L15 hin
    old "I- if you want to... Of course."
    new "اگر می‌خوای... البته."

    # say L16 pla
    old "Of course, that would be nice."
    new "البته، خوب می‌شه."

    # say L17 hin
    old "Really? That's great!"
    new "وای، خوبه!"

    # say L18 hin
    old "Well, since we're done with school for the day. Would you like to go now?"
    new "خب، از آنجا که برای امروز مدرسه تمام شده. می‌خوای حالا برویم؟"

    # say L19 pla
    old "Sure, that sounds great."
    new "بله، این خوبه."

    # say L33 pla
    old "Ok, so, what movie do you think you would like to watch?"
    new "خب، پس، فیلمی که می‌خوای ببینی چیه؟"

    # say L34 hin
    old "Well, I've been wanting to watch this new movie called 'Lusted Note.'"
    new "خب، من می‌خوام این فیلم جدید به نام «Lusted Note» رو ببینم."

    # say L35 pla
    old "Uhh, ok... What's it about?"
    new "اوه، خب... درباره چیه؟"

    # say L36 hin
    old "It's a romance movie about a stepbrother and stepsister who fall in love."
    new "این فیلم عاشقانه‌ای درباره یک برادر و خواهر ناتنیه که به هم عاشق می‌شنن."

    # say L37 hin
    old "It's been all the rage lately, everyone says it's so good! And the lead actress is really good, I'm her fan!"
    new "akhirاً همه ازش حرف می‌زنن، می‌گن خیلی خوبه! و بازیگر اصلی هم خیلی خوبه، من فانش هستم."

    # say L38 pla
    old "Well, sounds interesting, let's watch it."
    new "خب، جالب به نظر می‌رسه، بیایم ببینیم."

    # say L54 pla
    old "Wow this movie is actually really good."
    new "این فیلم واقعاً خوبه."

    # say L55 hin
    old "Yeah, it's great."
    new "بله، عالیه."

    # say L56 hin
    old "I really like their love story, it's so beautiful."
    new "من واقعاً داستان عشقشون رو دوست دارم، خیلی زیباست."

    # say L57 hin
    old "You know, I'm very happy you decided to come, today."
    new "دلم خوش می‌شه که امروز تصمیم دادی بیایی."

    # say L58 hin
    old "I thought maybe, you wouldn't want to come."
    new "فکر کردم شاید نمی‌خوای اومدی."

    # say L61 pla
    old "What? Why would you think that?"
    new "چرا فکر می‌کردی من نمی‌خوام بیام؟"

    # say L62 hin
    old "Well, it's just that you're such a popular guy, you know..."
    new "خب، فقط اینه که تو یه مرد محبوبی هستی، می‌دونی..."

    # say L63 pla
    old "Popular? Me??"
    new "پرطرفدار؟ من؟"

    # say L64 pla
    old "Come on... There's no way you think I'm popular."
    new "بیا بیا... نمی‌تونی فکر کنی من محبوب هستم."

    # say L65 hin
    old "Well, you seem to get along quite well with a lot of people."
    new "خب، به نظر می‌رسه تو با خیلی از مردم خوب رابطه داری."

    # say L66 hin
    old "You know... You get along so well with Belle and Billie."
    new "می‌دونی... تو با Belle و Billie خیلی خوب رابطه داری."

    # say L70 pla
    old "Well, you know... They're my friends too."
    new "خب، می‌دونی... آنها هم دوستای من هستند."

    # say L71 pla
    old "And I really like hanging out with them."
    new "و من واقعاً لذت می‌برم وقتی باهاشون هستم."

    # say L72 pla
    old "But that doesn't mean I wouldn't want to hang out with you. Or that I would be too busy."
    new "اما این به معنای این نیست که نمی‌خواهم با تو وقت بگذaram. یا اینکه خیلی مشغول باشم."

    # say L73 pla
    old "I really enjoy spending time with you Hinn."
    new "من واقعاً لذت می‌برم از زمانی که با تو می‌گذرانم هین."

    # say L78 hin
    old "Thank you [pla], I really like spending time with you too."
    new "ممنون [pla]، من هم خوشحالم که وقت با تو می‌گذرونم."

    # say L92 hin
    old "You know, my mom won't come home for a while."
    new "دیت، مامان خیلی زود نمی‌تونه بیاد."

    # say L93 pla
    old "Oh!"
    new "اوه!"

    # say L94 hin
    old "So... If you want, we could... You know..."
    new "پس... اگه می‌خوای، می‌تونیم... توش می‌دونی..."

    # say L95 pla
    old "Uhh... Should we go up to your bedroom?"
    new "اوه... باید برویم بالا به اتاق خوابت؟"

    # say L97 hin
    old "Haha, there's no need."
    new "هه، لازم نیست."

    # say L98 hin
    old "She'll take a while, so, we can just do it here."
    new "او، خوب، او وقت زیادی می‌بره، پس می‌تونیم اینجا هم انجام بدیم."

    # say L117 jad
    old "Well?!"
    new "خب؟!"

    # say L118 jad
    old "Aren't you going to say anything?"
    new "نمی‌خوای چیزی بگی؟"

    # say L122 hin
    old "Wait a minute! What are you doing home so early?! You told me you were going to be late today!"
    new "یه لحظه! چطور اینقدر زود خانه آمدی؟! تو به من گفتی امروز دیر می‌تونی بیادی!"

    # say L123 jad
    old "I decided to come home early today."
    new "من تصمیم گرفتم امروز زودتر بیام خانه."

    # say L124 jad
    old "But I see now this is why you kept asking me what I was going to be doing today..."
    new "ولی حالا می‌بینم این بود دلیل اینکه می‌پرسیدی امروز چی می‌کنم..."

    # say L125 jad
    old "This is incredible..."
    new "این واقعاً شگفت‌انگیز است..."

    # say L127 hin
    old "We weren't doing anything wrong you know."
    new "ما هیچ چیز اشتباهی نمی‌کردیم، می‌دونی."

    # say L128 jad
    old "I didn't say you were!"
    new "من نگفتم اشتباهی می‌کنید!"

    # say L129 jad
    old "Listen Hinn, [pla], I understand you two are adults now, I'm not bothered by you having sex or anything."
    new "هین، ز[pla]، من متوجه هستم که شما دو تا بزرگ شده‌اید، اصلاً از اینکه جنس می‌کنید نگران نیستم."

    # say L130 jad
    old "But if you're going to have sex, please do it in a private place!"
    new "اما اگر قراره جنس کنید، لطفاً اونجای خصوصی بکنید!"

    # say L131 jad
    old "Just look at the way you two are right now!"
    new "ببینید حالا شما دو تا چطور هستید!"

    # say L132 jad
    old "Just standing there completely naked!"
    new "فقط اینجا ایستاده هستید کاملاً عریان!"

    # say L140 jad
    old "(Whoah, h-he's so big!)"
    new "واو، ه-هیچی هم اینقدر بزرگ نبود!"

    # say L141 jad
    old "You have to think about other people, you know..."
    new "باید به دیگران هم فکر کنی، می‌دونی..."

    # say L142 hin
    old "We just didn't know you were coming home so soon..."
    new "ما فقط نمی‌دونستیم تو اینقدر زود خانه می‌آیی..."

    # say L143 jad
    old "Listen, I know you guys are young and full of hormones..."
    new "بگوش، می‌دونم شما دو تا جوان هستید و هورمون‌هایتون بالاست..."

    # say L146 jad
    old "But this is the living room! I usually watch tv on that couch!"
    new "ولی این اتاق نشیمنه! معمولاً روی آن مبله تلویزیون می‌بینم!"

    # say L147 jad
    old "Besides, I could've come home with company..."
    new "البته، می‌تونستم همراه با کسی خانه بیام..."

    # say L148 jad
    old "Imagine what would have happened if someone saw you and your boyfriend having sex on the couch Hinn."
    new "تخیل کن اگر کسی شما رو و دوستت در حال سکس بر روی آن مبله دیده بود هین."

    # say L151 hin
    old "B- boyfriend? (Gosh! Mom why can't you shut up...)"
    new "ب- دوست پسر؟ (ای وای! مامان چرا نمی‌تونی خشکی بدهی...)"

    # say L152 hin
    old "Uhh... W- We are not a... C- couple... (Not yet, THANKS MOM!)"
    new "اوه... ما هنوز... ج- جفت نیستیم... (هنوز، ممنون مام!)"

    # say L153 hin
    old "We still being... Uhh, just friends."
    new "ما هنوز... اوه، فقط دوست‌ها هستیم."

    # say L157 jad
    old "E- excuse me?"
    new "ب- ببخشید؟"

    # say L158 jad
    old "B- but you two were just..."
    new "B- ولی شما دو تا... اه، فقط دوست بودید."

    # say L159 hin
    old "Mom please, this is not your business!"
    new "مامان لطفاً، این کار تو نیست!"

    # say L161 jad
    old "Well, I guess that's just how you do things these days..."
    new "خب، به نظر می‌رسه اینجوری هست که امروزه کارها انجام می‌شنند..."

    # say L162 jad
    old "I get it, young people are a little more open nowadays, as long as your kids are safe... I guess it's alright."
    new "فهمیدم، جوان‌ها این روزها کمی بازتر هستن، مادون اینکه بچه‌ات امن باشن... به نظر می‌رسه مشکلی نداره."

    # say L163 jad
    old "But that's not the point, the point is that you should be more careful with these things."
    new "اما این نه، مهم اینه که تو با این جور چیزها بیشتر مراقب باشی."

    # say L164 jad
    old "If you're going to be having sex, do it in your bedroom."
    new "اگه قراره جنس کنی، تو اتاق خوابت انجام بده."

    # say L165 jad
    old "It doesn't matter if I'm not home, try to be a little respectful, will you?"
    new "اهمیتی نداره من خونه نباشم، حداقل یه کم احترامی داشته باش، می‌تونی؟"

    # say L167 hin
    old "Oh my gosh! It was an accident!"
    new "اوه خدا! این یه اتفاق بود!"

    # say L168 hin
    old "Ugh, I don't want to talk about this anymore. Come on [pla], let's go to my bedroom!"
    new "اوه، نمی‌خوام دیگه در این مورد صحبت کنم. بیا [pla]، برویم به اتاق خواب من!"

    # say L175 pla
    old "Sorry, Mrs. Jade."
    new "ببخشید، خانم جید."

    # say L185 jad
    old "(God, he really has a huge...)"
    new "خدا، واقعاً بزرگه..."

    # say L202 hin
    old "Listen [pla], I'm sorry about that, I didn't expect her to come home so early."
    new "بگوش [pla]، معذرت از این موضوع، نمی‌تونستم حدس بزنم اونجور زود برمی‌گرده."

    # say L203 hin
    old "I'm also sorry about what she said. She can be a drag sometimes."
    new "من هم برای آنچه گفت اشتباه می‌تونم ببخشم. بعضی مواقع می‌تونه خسته‌کننده باشه."

    # say L205 pla
    old "It's ok. Besides, I sort of think that she's  right."
    new "خوبه. همچین، من هم فکر می‌کنم که درست می‌گه."

    # say L208 pla
    old "Yeah, I mean, we did it in the living room."
    new "بله، منظورم اینه که ما در اتاق نشیمن کردیم."

    # say L209 pla
    old "In a way, we're lucky she wasn't even angrier."
    new "به نظر می‌رسه شانس داریم که او حتی خیلی غصب نکرد."

    # say L211 hin
    old "{b}*Sigh*{/b} Yeah, I guess you're right."
    new "{b}*تنفث*{/b} بله، حدس می‌زنم درست می‌گویی."

    # say L212 hin
    old "I suppose next time we'll just have to be more careful."
    new "باید دفعه‌ی بعد دقت‌تر عمل کنیم."

    # say L214 hin
    old "I guess you have to go, right?"
    new "باید بری، درسته؟"

    # say L215 pla
    old "Yeah, I better go home, but, maybe we can finish the movie some other time."
    new "بله، بهتره برم خونه، اما شاید بشه دفعه‌ی بعد فیلم رو تمام کرد."

    # say L217 hin
    old "Yeah, that would be great!"
    new "بله، خوب هست."

    # say L219 hin
    old "Alright, see you later [pla]."
    new "باشه، بعداً می‌بینیم [pla]."

    # say L238 pla
    old "Hi Hinn, I'm great. And you? How are things with your mom?"
    new "سلام هین، من خوبم. تو چطوری؟ مامانتون چطور هست؟"

    # say L239 hin
    old "Oh, it's fine, she wasn't really all that angry."
    new "او، خوبه، خیلی خشمگین نبود."

    # say L240 pla
    old "I see, that's good I guess."
    new "بینی، این خوبه حدس می‌زدم."

    # say L241 hin
    old "On that note, I was thinking..."
    new "در این مورد، من فکر می‌کنم..."

    # say L242 hin
    old "You know, since last time we couldn't actually finish the movie, what do you think if you come over and we finish it?"
    new "می‌دونی، از آخر باری که نتونستیم فیلم رو تمام کنیم، چطور می‌شه اگه بیایی به خونه من و ما آن رو تمام کنیم؟"

    # say L244 pla
    old "Huh? Come over? To your house?"
    new "هی؟ بیای اینجا؟ به خونت؟"

    # say L246 hin
    old "Yeah, of course."
    new "بله، البته."

    # say L247 hin
    old "Is there a problem?"
    new "مشکلی هست؟"

    # say L248 pla
    old "No, no problem. I'm just not sure about it, you know?"
    new "نه، مشکلی نداره. فقط من در موردش مطمئن نیستم، می‌فهمی؟"

    # say L249 pla
    old "What if your mother doesn't like that I go there?"
    new "اگه مامانتون خوشش نمیاد که من اونجا برسم، چی کنم؟"

    # say L250 hin
    old "Don't be silly, I told you, she's not angry."
    new "بیا باش، به تو گفتم، خودش غصب نداره."

    # say L251 hin
    old "We just need to be careful and nothing will happen."
    new "ما فقط باید مراقب باشیم و هیچ چیزی اتفاق نمی‌افتد."

    # say L253 pla
    old "Hmm, I guess you're right."
    new "Hmm، به نظر می‌رسه درست می‌گی."

    # say L254 pla
    old "Ok, I'm in."
    new "باشه، من همراهتم."

    # say L283 jad
    old "Oh, hi [pla]! I didn't know you were here!"
    new "اوه، سلام ز[pla]! نمی‌دونستم تو اینجا هستی!"

    # say L286 pla
    old "Hi Mrs. Jade, how are you? I was just watching a movie with Hinn."
    new "سلام خانم جد، حالتون چطوره؟ من همینجوری با هین فیلم می‌دیدم."

    # say L288 jad
    old "Well, it's good to see you again..."
    new "البته خوشحالم که دوباره ازت دیدم..."

    # say L296 jad
    old "So, what are you watching?"
    new "پس، چه فیلمی می‌بینید؟"

    # say L300 whi
    old "Phew, I definitely should take some extra parking lessons, heh."
    new "پوف، قطعاً باید درس پارک کردن بیشتری بگیرم، ها."

    # say L304 whi
    old "Oh, hi kids! How are you?"
    new "اوه، سلام بچه‌ها! چطور هستید؟"

    # say L314 whi
    old "Oh, it's been a while [pla]..."
    new "اوه، از آن زمان که دیده‌ایم می‌گذرد [pla]..."

    # say L315 pla
    old "Hi Mrs. White... Nice to see you..."
    new "سلام خانم وایت... خوشحالم که شما رو دیدم..."

    # say L317 hin
    old "Hello Mrs. White, how are you?"
    new "سلام خانم وایت، حالتون چطوره؟"

    # say L318 whi
    old "I'm very good darling. I have to say I love your new outfit, it suits you much better than that old jumper you used before."
    new "من خیلی خوب هستم عزیزم. باید بگم که لباس جدیدت رو خیلی دوست دارم، برایت خیلی بهتر از آن پولوی قدیمی است."

    # say L319 whi
    old "I have to say [pla], you're also very good-looking."
    new "باید بگم [pla]، تو هم خیلی زیبا هستی."

    # say L320 whi
    old "These kids just get so big from one moment to another, right Jade?"
    new "این بچه‌ها از لحظه‌ای به لحظه‌ای بزرگ می‌شن، درسته جید؟"

    # say L321 jad
    old "You're right, it's amazing..."
    new "حق با توست، شگفت‌انگیز است..."

    # say L323 hin
    old "So, you two were out together?"
    new "پس شما دو نفر با هم بیرون بودید؟"

    # say L324 jad
    old "Yeah, that's right, Mrs. White was helping me with some shores."
    new "بله، همینطوره، خانم وایت به من کمک می‌کرد با برخی کارها."

    # say L325 jad
    old "And I told her to come to hang out with me."
    new "و بهش گفتم بیا با من همراه باشه."

    # say L326 jad
    old "We hadn't spoken in a while."
    new "ما از طولی با هم صحبت نکرده بودیم."

    # say L327 hin
    old "Oh, ok. That's great."
    new "اوه، خوبه. خوشحالم."

    # narrator L331 
    old "{b}*PHONE RINGING*{/b}"
    new "{b}*گوشی زنگ زنده*{/b}"

    # say L333 jad
    old "Uhh, the phone is ringing. I'll be right back."
    new "اوه، گوشی در حال زنگ زدن است. همینجا منتظر باشم."

    # say L338 whi
    old "So, you two were watching a movie?"
    new "پس، شما دو تا فیلم می‌دیدید؟"

    # say L339 pla
    old "Yeah... that's right."
    new "آره... همینه."

    # say L340 whi
    old "Well? Was it good?"
    new "خب؟ خوب بود؟"

    # say L341 hin
    old "Umm, yeah, I guess..."
    new "اوه، بله، فکر کنم..."

    # say L342 hin
    old "I think we're going to keep watching it, so, if you don't mind"
    new "فکر کنم ما هنوز ادامه می‌دهیم تماشایش، پس اگر مخالفتی نداری"

    # say L343 whi
    old "Oh well, I'll watch it with you then."
    new "البته، من هم با شما می‌بینم."

    # say L356 jad
    old "I can't believe you! I just simply can't"
    new "نمی‌تونم باور کنم! خودت رو نمی‌تونم باور کنم!"

    # say L357 jad
    old "Why don't you take..."
    new "چرا نمی‌گیری..."

    # say L358 jad
    old "No! I did not say that!"
    new "نه! من اینطوری نگفتم!"

    # say L364 jad
    old "It's always the same with you Hiashi!"
    new "همیشه همینه تو هیاشی!"

    # say L370 jad
    old "It's almost as if you don't care about your daughter's well-being."
    new "به نظر می‌رسه تو خیلی اهمیتی به رفاه دخترت نمی‌دهی."

    # say L371 jad
    old "My God!!"
    new "الله!!"

    # say L372 jad
    old "No, NO! YOU listen to me! You have to figure out something and fulfill your responsibility or I'm taking action."
    new "نه، نه! تو به من گوش کن! باید راهی پیدا کنی و مسئولیتت رو برآورده کنی، در غیر این صورت من اقدام می‌کنم."

    # say L383 jad
    old "Ok, I'm here again."
    new "خب، دوباره اینجا هستم."

    # say L393 whi
    old "Are you ok? What happened?"
    new "حالت خوبه؟ چه اتفاقی افتاد؟"

    # say L394 jad
    old "Uhh, please don't tell me you heard everything I said..."
    new "اوه، لطفاً بگو نگوشته‌ای همه چیزی که گفتم..."

    # say L395 whi
    old "You weren't very quiet, to be honest..."
    new "صusch، برات صادقانه بگم، خیلی آرام نبودی..."

    # say L397 jad
    old "{b}*Sigh*{/b}... I'm very sorry, it wasn't my intention."
    new "{b}*تنفس*{/b}... خیلی متاسفم، این جور نبود هدفم."

    # say L399 jad
    old "Let's just pretend it never happened, and enjoy the movie."
    new "بیای دیگه اینجا هیچی نبوده باشه و فیلم رو لذت ببریم."

    # say L413 whi
    old "Well, that was very good!"
    new "خب، این خیلی خوب بود!"

    # say L414 hin
    old "It really was."
    new "واقعاً بود."

    # say L416 whi
    old "I think I'll watch it in full when I get home. Don't you think it was great Jade?"
    new "فکر کنم وقتی به خونه برگشتم اینو کامل ببینم. جد، نگاهت خوب نبود؟"

    # say L419 jad
    old "What? Oh, yeah... Very good."
    new "چه؟ اوه، بله... خیلی خوب بود."

    # say L421 whi
    old "Ok, tell me, what is it?"
    new "بیا، بگو، چیه؟"

    # say L423 whi
    old "Come on, don't play dumb with me."
    new "بیا، با من نمی‌تونی بازی احمق باشی."

    # say L424 whi
    old "What did Hiashi say this time?"
    new "این بار هیاشی چه گفت؟"

    # say L425 jad
    old "Honestly, I don't want to talk about this, especially not in front of the kids."
    new "Honestly، من نمی‌خوام در مورد این حرف بزنم، خصوصاً جلوی بچه‌ها."

    # say L426 whi
    old "Oh come on, they're adults now. Nothing bad will happen to them."
    new "بیای بگو، الان بزرگ شدن. هیچ چیز بدی بهشون نمی‌افتد."

    # say L427 whi
    old "Just spit it out, if you don't talk about it you'll be in a bad mood all week."
    new "بگو براش، اگه در موردش حرف نزنی هفته‌ها خسته خواهی بود."

    # say L429 jad
    old "That was Hiashi, saying, once again! That he can't pay my alimony this month."
    new "این هیاشی بود، دوباره! می‌گفت این ماه نمی‌تونه هزینه مراقبت من رو بپرداخت."

    # say L430 jad
    old "That's four months in a row! That irresponsible bum!"
    new "این چهار ماه پشت سر هم هست! اون بی‌پناهه بی‌مسولیت!"

    # say L431 jad
    old "And it's not as if things are any easy around here, he should know how the economy is around here."
    new "و اینجا هم سختی‌ها کم نیست، باید بدونه اقتصاد چطوره."

    # say L432 whi
    old "That's Hiashi for you, always the same guy..."
    new "این هیاشی همیشه همینطور است، همیشه همان آدم..."

    # say L434 whi
    old "I bet he's still seeing that 19-year-old bimbo isn't he?"
    new "مطمئنم هنوز هم با آن دختر ۱۹ ساله مدل می‌بینه، نه؟"

    # say L435 jad
    old "Yes, he is! God! That's what bothers me! He doesn't have enough money to help his daughter!"
    new "بله، هست! خدا! اینجاست که من را ناراحت می‌کند! او پول کافی برای کمک به دخترش ندارد!"

    # say L437 jad
    old "But he can go around buying expensive clothes and vacations for some hussy that could be his grandchild!"
    new "ولی می‌تونه برای یه خانمی که می‌تونه نوه‌اش باشه لباس‌های گران و سفرهای گران بخره!"

    # say L439 jad
    old "I'm sorry Hinn, sweety, I wouldn't want to talk to you about your father like that."
    new "هین، عزیزم، من نمی‌خواستم درباره پدرت به این طریق صحبت کنم."

    # say L442 hin
    old "Hmph, whatever, not like any of this is new to me."
    new "همف، هر چی باشه، این همه چیز برای من جدید نیست."

    # say L443 hin
    old "But I would've liked to have a calm movie night."
    new "ولی دوست داشتم شب فیلم‌دیدار آرام باشه."

    # say L444 hin
    old "Come on [pla] let's get out of here."
    new "بیا [pla] برویم از اینجا خارج شویم."

    # say L457 hin
    old "Listen, I'm sorry for what happened."
    new "بله، من برای این که اتفاق افتاده عذرخواهم."

    # say L458 hin
    old "God! My mom ruins everything!"
    new "خدا! مامان همه چی رو خراب می‌کنه!"

    # say L459 pla
    old "No, no, don't worry. That's ok, I understand."
    new "نه، نه، نگران نباش. خوبه، من درک می‌کنم."

    # say L460 pla
    old "I get it, this type of thing can stress anybody."
    new "فهمیدم، این جوری چیزی می‌تونه هر کسی رو استرس‌ده بکنه."

    # say L462 hin
    old "You know, you're always very sweet."
    new "می‌دونی، همیشه خیلی لطف داری."

    # say L464 hin
    old "Yes, and it deserves a reward..."
    new "بله، و این به یک جایزه خاص ارزش داره..."

    # say L484 pla
    old "What are we doing here?"
    new "ما اینجا چه کاری می‌کنیم؟"

    # say L485 hin
    old "Well, we needed privacy to give you a special reward."
    new "خب، ما به خصوص برای اینکه به تو جایزه‌ای ویژه بدهیم نیاز به حریم خصوصی داشتیم."

    # say L488 pla
    old "Whoah! What are you doing?"
    new "وای! تو چه کاری می‌کنی؟"

    # say L489 hin
    old "I told you, I'm giving you a reward."
    new "من به تو گفتم، جایزه‌ای بهت می‌دم."

    # say L490 hin
    old "I was thinking that we could finish what we started the other night."
    new "من فکر می‌کردم می‌تونیم همون کاری که آن شب شروع کردیم رو تمام کنیم."

    # say L491 hin
    old "But my mom and Mrs. White got home when I wasn't expecting it."
    new "اما مامان و خانم وایت وقتی من منتظرشون نبودم، به خونه رسیدن."

    # say L492 hin
    old "So, I'll just give  you a little something before you go home."
    new "پس، قبل از رفتن یه چیز کوچیک به تو میدم."

    # say L494 pla
    old "{b}*Glup*{/b}"
    new "{b}*گلو خوردن*{/b}"

    # say L510 whi
    old "Hey, what are you doing there?"
    new "اوه، تو اینجا چه کاری داری؟"

    # say L512 jad
    old "What?! Oh, my God! You surprised me!"
    new "چه؟! اوه، خداوند! من شوک شدم!"

    # say L513 whi
    old "Well, you were taking your sweet time and you left the stove on... Do you want me to finish dinner for you?"
    new "خب، تو وقت خیلی زیادی برای این کار گذاشتی و گاز رو روشن گذاشتی... می‌خوای من جای تو غذا رو آماده کنم؟"

    # say L514 jad
    old "No, no, I just got distracted by... Something."
    new "نه، نه، فقط گرفتم خیال منصرف شدم از... چیزی."

    # say L516 whi
    old "Right... Is there anything in the bathroom?"
    new "البته... توی حمام هم چیزی نیست؟"

    # say L518 jad
    old "Nothing! Nothing! I was just looking for Hinn, but she isn't there."
    new "هیچی! هیچی! فقط دنبال هین می‌گشتم، اما او اونجا نیست."

    # say L519 whi
    old "Ok, sure."
    new "باشه، حتماً."

    # say L520 jad
    old "Anyway, let's go, help me with the mac and cheese."
    new "بیای، کمکت کن به من با ماک و کیس."

    # say L538 hin
    old "That was very good."
    new "این خیلی خوب بود."

    # say L539 pla
    old "Yeah, it was, I wasn't expecting it though."
    new "بله، خوب بود، اما منتظرش نبودم."

    # say L540 hin
    old "Well, I wanted to make it up to you for the interruption last time, you know."
    new "البته، می‌خواستم برای قطع شدن بار قبل جبران کنم، می‌دونی."

    # say L541 pla
    old "Yeah, I think I get it."
    new "بله، فکر کنم متوجه شدم."

    # say L542 pla
    old "Anyway, I think, I shoould go home."
    new "بازم، فکر کنم باید برم خونه."

    # say L543 hin
    old "Hmm, yeah you are right."
    new "Hmm، بله تو درست می‌گی."

    # say L544 hin
    old "Listen, I'm really sorry about today, with my mom yelling all the movie and everything."
    new "بله، واقعاً برای امروز خیلی متاسفم، با همه آن صداهای مامان و همه چیز."

    # say L545 hin
    old "It ruined the movie afternoon."
    new "این همه‌ی بعد از ظهر فیلم رو خراب کرد."

    # say L546 pla
    old "Oh come on, I still had a great time."
    new "بیا، هنوز وقت خوبی گذرونده."

    # say L547 pla
    old "If you'd like, maybe we could watch another movie some other day."
    new "اگر می‌خوای، شاید بتونیم روزی دیگه فیلم دیگه‌ای ببینیم."

    # say L549 pla
    old "Let's do it then."
    new "بیای دیگه."

    # say L551 pla
    old "Alright, so, I better go now."
    new "باشه، پس من بهتره حالا برسم."

    # say L552 hin
    old "Oh, right. Have a good night [pla]."
    new "اوه، درسته. شب خوبی داشته باشی [pla]."

    # say L553 pla
    old "Thank you, I really enjoyed the day. See you soon Hinn."
    new "ممنون، روز خوبی بود. دیگه می‌بینیم هین."

    # say L572 hin
    old "I'm great actually, my mom and I talked, and we're both feeling a lot better."
    new "من در واقع خوب هستم، مامانم و من با هم صحبت کردیم و هر دو ما حالا خیلی بهتر احساس می‌کنیم."

    # say L573 pla
    old "That's good, it's great that you can talk about those things."
    new "خوشحالم که بتونیم در مورد این جور چیزها با هم صحبت کنیم."

    # say L574 pla
    old "It's a shame about the movie tho, though I suppose that still annoys you a little bit..."
    new "البته، ولی خیلی هم شرمنده‌کننده نیست که فیلم رو ندیدیم، اما فکر کنم هنوز هم یه جوره خیالت می‌کنه..."

    # say L575 hin
    old "Well, about that..."
    new "خب، در مورد اون..."

    # say L577 hin
    old "Do you think you would like to go to my house again?"
    new "فکر می‌کنی دوباره به خونه‌ام بیایی؟"

    # say L578 hin
    old "There's another movie that I would like to watch with you..."
    new "فیلم دیگه‌ای هست که می‌خوام با تو ببینم..."

    # say L580 pla
    old "Hmm... Yeah, sure, I don't see why not."
    new "Hmm... بله، حتماً، چرا نه."

    # say L581 hin
    old "Hey, that's great."
    new "عالی، خوشحالم."

    # say L582 hin
    old "And listen, this time my mom will be leaving for some event dinner she was invited to."
    new "و بگوش، این بار مامان برای یه عشایی که دعوت شده بره."

    # say L583 hin
    old "So, maybe we can finish the movie... And something else."
    new "پس شاید بتونیم فیلم رو تمام کنیم... و چیز دیگه‌ای هم."

    # say L584 pla
    old "Oh, sure."
    new "اوه، حتماً."

    # say L585 pla
    old "Sounds good."
    new "خوب می‌شنه."

    # say L587 hin
    old "Great! So, let's go."
    new "عالی! پس برویم."

    # say L617 jad
    old "God dammit!"
    new "لعنتی!"

    # say L618 hin
    old "Ugh! What now?!"
    new "اوه! حالا چه؟!"

    # say L629 jad
    old "Oh! Hi [pla]!"
    new "اوه! سلام ز[pla]!"

    # say L633 jad
    old "I didn't know you were here honey!"
    new "نمی‌دونستم اینجا هستی عزیزم!"

    # say L636 jad
    old "Are you having a good time?"
    new "تو خوشحالی؟"

    # say L637 pla
    old "Hello Mrs. Jade, I was just watching a movie with Hinn."
    new "سلام خانم جد، من همینجوری با هین فیلم می‌دیدم."

    # say L639 jad
    old "I'm glad honey."
    new "خوشحالم حلوی من."

    # say L640 hin
    old "What happened now mom?"
    new "الان چه اتفاقی افتاد مامان؟"

    # say L641 hin
    old "Why did you scream and come out running in a towel?"
    new "مامان، چرا صدا زدی و با مندیل بخاری خارج شدی؟"

    # say L642 jad
    old "Well, I was taking a shower to get ready for that dinner I told you about."
    new "خب، من دوش می‌زدم تا برای آن شامی که به تو گفتم آماده بشم."

    # say L643 jad
    old "But, then my shower suddenly exploded!"
    new "ولی، بعد شورتم ناگهان منفجر شد!"

    # say L644 jad
    old "Now there's a lot of water running out of the piping."
    new "الان آب زیادی از لوله‌ها خارج می‌شه."

    # say L646 hin
    old "So? Just call a plumber to fix it."
    new "پس؟ فقط یک آبکاری بخون تا این مشکل رو حل کنه."

    # say L647 jad
    old "Well, young lady, in case you haven't been paying attention lately. We're not exactly swimming in money right now."
    new "خب، جونگیر جوان، اگر توجه نکردی، حالا پول خیلی زیادی نداریم."

    # say L648 jad
    old "Since your father hasn't been paying my alimony, I've been having to take care of things."
    new "از آنجایی که پدرت حق تعلیق من رو پرداخته نیست، من باید خودم این مشکلات رو حل کنم."

    # say L649 jad
    old "Right now I just can't afford to have somebody come and redo the entire bathroom tubing."
    new "الان من هیچ امکانی ندارم که کسی بیاد و تمام لوله‌های حمام رو جدید کنه."

    # say L651 hin
    old "Oh great!"
    new "اوه خوب!"

    # say L652 pla
    old "Uh, I think that maybe I could do something about that."
    new "من فکر می‌کنم شاید بتونم چیزی انجام بدم."

    # say L653 jad
    old "Really? You know how to fix that type of thing?"
    new "وای، می‌دونی این جوری چطور اصلاح می‌شه؟"

    # say L654 pla
    old "I mean, I'd have to take a look, but maybe I can do something."
    new "منظورم اینه، باید یه نگاهی بیاندازم، ولی شاید بتونم چیزی بکنم."

    # say L655 hin
    old "Oh great, another fantastic movie night..."
    new "اوه خوب، یه شب فیلم‌دیداری دیگه..."

    # say L661 pla
    old "Ok, ok, I see what happened, there was a rusty pipe, and it broke."
    new "باشه، باشه، فهمیدم، یک لوله خوردگی داشت و شکست."

    # say L663 pla
    old "I should be able to fix that."
    new "باید بتونم اینو اصلاح کنم."

    # say L664 jad
    old "Really? You think so?"
    new "وای، واقعاً؟ فکر می‌کنی بتونی این مشکل رو حل کنی؟"

    # say L665 pla
    old "Well, it's going to take a while, because I'll have to change the whole piping for the bathroom."
    new "خب، این کار وقت خواهد برد، چون باید تمام لوله‌های سرویس بهداشتی رو عوض کنم."

    # say L666 pla
    old "And that means breaking some of the wall and the floor."
    new "و این به معنای شکستن برخی از دیوار و زمینه."

    # say L667 pla
    old "But it shouldn't be too much of a problem."
    new "اما نباید مشکل زیادی باشه."

    # say L668 pla
    old "I actually have some experience doing house repairs and stuff."
    new "من در واقع تجربه‌ای تو اصلاحات خانه و اینا دارم."

    # say L669 jad
    old "You do? Did you have a part-time job doing that?"
    new "تو هم؟ نه، این کار رو به صورت شغل جانبی انجام می‌دیدی؟"

    # say L671 pla
    old "I guess you could call it a summer job."
    new "می‌تونی اینجوری بهش بگی کار تابستانی."

    # say L673 jad
    old "I see, well, I guess the only thing I can say is. When do you start?"
    new "ببین، خب، تنها چیزی که می‌تونم بگم اینه. وقت شروعت کیه؟"

    # say L675 pla
    old "Well, I would need to get some materials. But overall it shouldn't be too expensive."
    new "خب، باید چند تا مواد لازم رو بخرم. اما کلش خیلی گران نمی‌شه."

    # say L676 pla
    old "It's not too late, so, I should be able to make it to the hardware store."
    new "از دست نره، پس باید بتوانم به فروشگاه لوازم آریام برسم."

    # say L678 jad
    old "Oh, but you shouldn't spend your own money on that honey."
    new "اوه، ولی نباید خودت پول بذاری عزیزم."

    # say L679 pla
    old "Well, I'll just buy some things, and if you want me to, I'll just hand you the receipt the next time I'm here."
    new "خب، چند چیز می‌خرم، و اگر می‌خوای، برات رسید رو بعداً می‌دم."

    # say L680 jad
    old "That would be really nice of you."
    new "این برای من خیلی لطف داره."

    # say L681 pla
    old "Don't worry, this won't be expensive at all."
    new "نگران نباش، این خیلی گران نمی‌شه."

    # say L682 jad
    old "That's a relief to hear."
    new "این خبر خوب است."

    # say L683 pla
    old "Alright, I better go now, before they close."
    new "باشه، باید برم، قبل از اینکه ببندن."

    # say L684 jad
    old "Thank you [pla], I really appreciate it."
    new "ممنون [pla]، خیلی از این بابت قدردانی می‌کنم."

    # say L685 pla
    old "Oh, it's nothing, don't worry. But, I better hurry up, it's getting a bit late."
    new "اوه، هیچی، نگران نباش. اما باید سریع‌تر حرکت کنم، یه کم دیر شده."

    # say L706 hin
    old "So? How bad it is?"
    new "پس؟ چقدر بد هست؟"

    # say L707 pla
    old "Well, not that bad, but it will definitely take a few days of work."
    new "خب، خیلی بد نیست، اما حتماً چند روز کار می‌بره."

    # say L708 hin
    old "Oh [pla], that sounds like a lot of work, you don't have to do it."
    new "اوه ز[pla]، این به نظر می‌رسه کار زیادی هست، تو نمی‌تونی این رو انجام بدی."

    # say L709 pla
    old "Oh, don't worry. It won't be nothing, and I will be here visiting you more often."
    new "اوه، نگران نباش. خیلی سخت نیست و من اینجا خواهم بود تا بیشتر به تو بیام."

    # say L712 hin
    old "Hmm, I really can't belive you mom..."
    new "هم، واقعاً نمی‌تونم باور کنم مامان..."

    # say L713 hin
    old "Anyway, so, let's finish the movie."
    new "بیا، بیا، بیایم فیلم رو تمام کنیم."

    # say L714 pla
    old "Uhh, actually... I have to try and get to the hardware store before they close."
    new "اوه، در واقع... باید قبل از بستن فروشگاه سخت‌افزاری برم."

    # say L728 jad
    old "I'm sorry [pla], it wasn't my intention to ruin your movie afternoon."
    new "متاسفم [pla]، من قصد نداشتم بعد از ظهر فیلمت رو خراب کنم."

    # say L729 pla
    old "It's ok, I get why she's angry. No problem, besides, you didn't know this was going to happen."
    new "باشه، من متوجه هستم چرا زداست خیال شده. هیچ اشکالی نداره، علاوه بر این، تو نمی‌دونستی اینجوری می‌شه."

    # say L732 pla
    old "No problem."
    new "هیچ اشکالی نداره."

    # say L733 pla
    old "Now, I better leave before they close the hardware store."
    new "الان بهتره قبل از اینکه فروشگاه سخت‌افزار ببندن برم."

    # say L734 jad
    old "Sure, thanks again, honey."
    new "بله، ممنونم دوست من."

    # say L750 pla
    old "Hi Hinn."
    new "سلام هین."

    # say L753 hin
    old "I'm fine, I guess..."
    new "من خوب هستم، حدس می‌زنم..."

    # say L754 hin
    old "Listen [pla], I wanted to apologize about the way I acted yesterday."
    new "بگوش ز[pla]، می‌خواستم برای رفتارم دیروز عذرخواهی کنم."

    # say L758 hin
    old "Is just that things haven't been great at home this past few days."
    new "فقط اینجاست که چند روز گذشته خانه خوب نبوده."

    # say L759 hin
    old "Mom has been stressed a lot, which means I've been stressed even more."
    new "مامان خیلی استرس داره، پس من هم بیشتر استرس زده شدم."

    # say L760 hin
    old "And I thought that maybe you and I could relax a little bit."
    new "و فکر کردم شاید ما دو تا بتونیم کمی آرام بگیریم."

    # say L762 hin
    old "But everytime we tried we kept being interrupted."
    new "هر بار که سعی کردیم، مدام قاطع می‌شدن."

    # say L763 hin
    old "And it's just frustrating."
    new "و این فقط مiskننده است."

    # say L764 pla
    old "It's ok, I know how important our movie times are to you."
    new "باشه، میدونم چقدر مهم هستن وقت‌های فیلم‌دیداری برایت."

    # say L765 pla
    old "I completely get it, don't worry."
    new "من کاملاً متوجه هستم، نگران نباش."

    # say L766 hin
    old "Thank you, [pla]!"
    new "ممنون، [pla]!"

    # say L767 pla
    old "By the way, I was thinking maybe I could drop by your house this afternoon."
    new "باید بگم، فکر می‌کنم می‌تونم امروز بعد از ظهر به خونه‌ت برم."

    # say L768 pla
    old "And start working on the repairs for the bathroom."
    new "و شروع کنم به تعمیرات حمام."

    # say L769 pla
    old "Maybe we could even finish that movie we started last time."
    new "شاید بتونیم اون فیلمی که آخر هفته شروع کردیم رو هم تمام کنیم."

    # say L770 hin
    old "Oh, sorry [pla], actually, I'll be staying late here in school for some days."
    new "اوه، معذرت [pla]، در واقع برای چند روز اینجا در مدرسه خواهم ماند."

    # say L771 hin
    old "I have some extracurricular activities. Helping the teacher and stuff."
    new "من چند فعالیت خارج از برنامه دارم. به معلم کمک می‌کنم و این‌جوری."

    # say L773 hin
    old "But, my mom will be there. So, why don't you go and start working on the repairs?"
    new "اما مامانم خواهد بود. پس چرا نمی‌روی و شروع به تعمیرات می‌کنی؟"

    # say L774 hin
    old "That way it won't take you that long, and we can have time to..."
    new "اینطور نمی‌بره زود، و وقتی برایمون باقی می‌مونه..."

    # say L775 hin
    old "Finish the movie when I'm done with my stuff here."
    new "وقتی کارمو انجام دادم، ما می‌تونیم فیلم رو تمام کنیم."

    # say L777 pla
    old "That's a good idea."
    new "ایده خوبیه."

    # say L778 pla
    old "Ok, sure, I'll go there and get started on the repairs."
    new "باشه، حتماً می‌رم و شروع به تعمیرات می‌کنم."

    # say L779 hin
    old "Alright, then see you soon. And sorry about my mom once again."
    new "باشه، پس تا زودی. و دوباره عذرخواهم از خاطر مامانم."

    # say L780 pla
    old "Hey, don't worry, everything will be alright. See you later."
    new "هین، نگران نباش، همه چیز خوب می‌شه. بی‌نهایت."

    # say L796 pla
    old "Good morning, Mrs. Jade."
    new "صبح بخیر، خانم جد."

    # say L797 jad
    old "Oh, Hi [pla]! Hi, how are you?"
    new "اوه، سلام [pla]! سلام، خوب هستی؟"

    # say L798 pla
    old "Fine, thank you."
    new "خوبم، ممنون."

    # say L799 jad
    old "How did it go? Were you able to get all the things you need for the repair?"
    new "چطور بود؟ تونستی همه چیزهایی که برای تعمیر لازم داری رو بیاری؟"

    # say L800 pla
    old "Yes, I got everything without problems, and it was even cheaper than I expected."
    new "بله، همه چیز رو بدون هیچ مشکلی گرفتم، حتی کمتر از اونچه فکر می‌کردم پول کردم."

    # say L801 jad
    old "Oh, thank God! Alright, then I will let you work, if you need something, please just let me know."
    new "اوه، خدا را شکر! خب، من اجازه می‌دم که کارتو انجام بدی، اگه نیاز به چیزی داشتی، لطفاً به من بگو."

    # say L803 pla
    old "Alright, I'll get to it."
    new "باشه، می‌رسونم."

    # say L812 pla
    old "Hi Mrs. Jade, how are you?"
    new "سلام خانم جد، حالتون چطوره؟"

    # say L813 jad
    old "[pla]! Hi, how are you?"
    new "[pla]! سلام، حالت چطوره؟"

    # say L816 jad
    old "Did you come to work in the bathroom?"
    new "آیا برای کار در حمام اومدی؟"

    # say L818 pla
    old "Yes, there is still work to be done."
    new "بله، هنوز کاری برای انجام داریم."

    # say L819 jad
    old "Oh, thank you darling. Well, you know where the materials are, I won't bother you."
    new "اوه، ممنون عزیزم. خب، میدونی جای مواد کجا هست، من نمی‌خوام تو رو آزار بدم."

    # say L821 pla
    old "Sure, I'll get to it."
    new "بله، می‌رسونم."

    # say L827 pla
    old "There's some work to do here. But, I know what I have to do, so, it should be easy."
    new "اینجا کاری هست. ولی، می‌دونم باید چی کنم، پس باید آسون باشه."

    # say L828 pla
    old "Well, I guess I'll get to it."
    new "ببینم این کار رو انجام بدم."

    # say L829 pla
    old "I'll try and finish this quickly."
    new "سعی می‌کنم این رو سریع تمام کنم."

    # say L872 pla
    old "Phew, I got a lot done today."
    new "پوف، امروز کار زیادی انجام دادم."

    # say L873 pla
    old "Although, I still have quite a bit to do, anyway, at least this is something."
    new "البته، هنوز کار زیادی دارم، اما حداقل اینقدر کار کردم."

    # say L874 pla
    old "It's kinda late, so, let's call it a day."
    new "الان خیلی دیره، پس بیایم امروز همین باشه."

    # say L895 pla
    old "But, she knew I was here, just next to her bedroom..."
    new "ولی، او می‌دونست من اینجا هستم، جلوی اتاق خوابش..."

    # say L911 jad
    old "It's getting a bit late [pla], I think we just better call it a day."
    new "وقت شد کمی دیر [pla]، فکر کنم بهتره کار رو به اتمام برسونیم."

    # say L913 pla
    old "That's right Mrs. Jade, I'm actually happy with it, I got quite a bit done today."
    new "درست می‌فرمایید خانم جد، من هم خوشحالم، امروز کار زیادی انجام دادم."

    # say L914 pla
    old "But you are right, it's kinda late now, I better come back and continue another time."
    new "ولی تو درست می‌گی، الان خیلی دیره، بهتره دوباره بیام و ادامه بدم."

    # say L915 jad
    old "Well, it's great that you had progressed a lot, thanks, honey."
    new "البته خوشحالم که پیشرفت زیادی کردی، ممنون، عزیزم."

    # say L916 jad
    old "You have no idea of how helpful you are."
    new "تو هیچ ایده‌ای نداری که چقدر مفیدی."

    # say L917 pla
    old "My pleasure."
    new "خوشحالم که کمک کردم."

    # say L918 jad
    old "You're so sweet."
    new "تو خیلی شیرینی."

    # say L919 jad
    old "By the way, don't forget to bring me the bill for the materials, so, that I can reimburse you."
    new "باید فاکتور مواد رو به من بیاری تا بتونم هزینه رو به تو برگردونم."

    # say L920 pla
    old "Sure thing. Well, good night Mrs. Jade."
    new "بله خب، شب خوبی خانم جد."

    # say L921 jad
    old "Good night honey."
    new "شب خوب عزیزم"

    # say L958 hin
    old "Hi [pla], you came to help mom with the bathroom?"
    new "سلام ز[pla]، اومدی تا به مامان کمک کنی با حمام؟"

    # say L960 pla
    old "I wasn't expecting to see you here. I thought you had that extra work with the teacher."
    new "من منتظر نبودم که تو اینجا باشی. فکر کردم کار اضافی با معلم داری."

    # say L962 hin
    old "Well, I did, but the teacher had something important to do."
    new "بله، اما معلم کار مهمی داشت."

    # say L963 hin
    old "So, I'm free today."
    new "پس، امروز آزادم."

    # say L964 pla
    old "Oh, cool."
    new "اوه، خوبه."

    # say L965 hin
    old "Yeah, it is, and my mom is  not here, and she'll be out for a while... You know what this means, right?"
    new "بله، هستم، و مامان هم اینجا نیست، و برای مدتی خارج خواهد بود... می‌دونی این چه معنا داره، درسته؟"

    # say L966 pla
    old "Uhh, you want to finish the movie?"
    new "اوه، می‌خوای فیلم رو تمام کنیم؟"

    # say L967 hin
    old "Hahaha, no you dummy."
    new "هahaha، نه تو خنده‌دار."

    # say L968 hin
    old "I mean that we're finally alone."
    new "من قصد دارم بگم که حالا انفرادی هستیم."

    # say L974 hin
    old "We have some privacy to be a little... Intimate."
    new "ما می‌تونیم یه کم... نزدیک‌تر باشیم."

    # say L975 pla
    old "Oh... A- alright."
    new "اوه... خب بله."

    # say L976 hin
    old "So, what do you say? We should go up to my bedroom."
    new "پس، چه می‌گی؟ باید بالا بریم به اتاق خوابم."

    # say L977 pla
    old "Uhh... Are you sure about this? I mean what if your mom comes home and sees us again?"
    new "اوه... مطمئنی از این؟ منظورم اگه مامانت بیاید و دوباره ما رو ببینه؟"

    # say L979 hin
    old "Relax, she won't be home for a while. Besides, you heard what she told us, she's ok with us doing it."
    new "آرام، او برای مدتی خانه نمی‌آید. علاوه بر این، شنیدی چه به ما گفت، با ما کردن مشکلی نداره."

    # say L980 hin
    old "And we'll be in my bedroom."
    new "و ما در اتاق خواب من خواهیم بود."

    # say L981 pla
    old "I- I guess you're right."
    new "من فکر می‌کنم درست می‌گویی."

    # say L983 hin
    old "Stop worrying, just come with me."
    new "نگران نباش، فقط با من بیا."

    # say L991 hin
    old "I've been waiting for this for a while."
    new "من از طول همیشه منتظر این بودم."

    # say L992 hin
    old "Every time we've tried to do it we've been getting interrupted."
    new "هر بار که می‌خواستیم انجام بدیم قطع می‌شدن."

    # say L993 hin
    old "I was thinking we were never going to have a chance to do it again."
    new "فکر می‌کردم هیچ وقت فرصت نخواهیم داشت این کار رو بکنیم."

    # say L994 pla
    old "Well, we're finally alone."
    new "خب، حالا اونجا هستیم."

    # say L995 hin
    old "Yeah, so, let's don't waste more time. I want to feel you inside."
    new "بله، پس بیاین زمان بیشتری ضایع نکنیم. می‌خوام تو رو داخل خودم حس کنم."

    # say L1009 hin
    old "Well, I'm very happy we finally got to do it without being interrupted."
    new "البته خوشحالم که در نهایت بدون قطع شدن این کار رو انجام بدیم."

    # say L1010 pla
    old "Yeah, me too..."
    new "بله، من هم همین‌جور حس می‌کنم..."

    # say L1011 hin
    old "Are you going home now?"
    new "تو الان خانه می‌روی؟"

    # say L1012 pla
    old "I think I'll go take a look at the bathroom before your mom gets home."
    new "فکر کنم برم یه نگاهی به توالت باندازم قبل از اینکه مامانت بیاد."

    # say L1013 hin
    old "Ok, then I guess I'll just stay here and organize my bedroom."
    new "خب، در اون صورت من اینجا می‌مونم و اتاق خوابم رو مرتب می‌کنم."

    # say L1025 pla
    old "Oh! Hi Mrs. Jade."
    new "اوه! سلام خانم جید."

    # say L1026 pla
    old "I didn't know you were home already."
    new "نفهمیدم قبلاً خانه بودی."

    # say L1028 jad
    old "Hi [pla], I- I just arrived."
    new "سلام [pla]، من- من net وارد شدم."

    # say L1029 jad
    old "Did you come to check on the bathroom?"
    new "آیا برای بررسی حمام اومدی؟"

    # say L1030 pla
    old "Uhh... I did, yeah, then I ran into Hinn, and we started talking."
    new "اوه... بله، بعد از آن با هین مواجه شدم و شروع به صحبت کردیم."

    # say L1031 jad
    old "Oh, that's ok."
    new "اوه، خوبه."

    # say L1032 jad
    old "Actually, [pla], it's getting kind of late, and I'm sure you must be tired from working so... Hard."
    new "در واقع، [pla]، وقت شد خیلی دیره و مطمئن هستم تو خسته باشی از کار... سخت."

    # say L1034 jad
    old "Why don't you go home for now? And just come back another time?"
    new "چرا حالا نمی‌روی خونه؟ و بعداً می‌آیی؟"

    # say L1036 pla
    old "Are you sure? I'm not really all that tired, I could just work a little on the bathroom and..."
    new "مطمئنی؟ من خیلی خسته نیستم، می‌تونم یه کم کار توی حمام بکنم و..."

    # say L1037 jad
    old "I'm sure. I think I would like to go to bed early today, so, it's fine if you take a day free."
    new "مطمئنم. فکر کنم امروز می‌خواهم زودتر بخوابم، پس، اگه تو هم روزی آزاد بگیری خوبه."

    # say L1038 pla
    old "Uh, ok, sure."
    new "اوه، خوب، مطمئن."

    # say L1039 pla
    old "Then I guess I'll leave for today."
    new "پس فکر کنم برای امروز برم."

    # say L1040 jad
    old "Sure honey, see you later."
    new "بله عزیزم، بیای بعد دیدنش کنی."

    # say L1056 pla
    old "Oh, hi Hinn! I didn't think I'd see you here. I thought you were going to be in school."
    new "اوه، سلام هین! فکر نکردم تو رو اینجا ببینم. فکر کردم تو می‌خواهی به مدرسه بری."

    # say L1057 hin
    old "Hi [pla], I only popped in to grab a couple of books, I'm on my way back."
    new "سلام ز[pla]، فقط برای گرفتن چند کتاب اومدم، حالا می‌رم."

    # say L1059 pla
    old "Uhh, yeah."
    new "اوه، بله."

    # say L1060 hin
    old "Well, my mom's not home right now, but you can go ahead and get started."
    new "خب، مامان من الان خونه نیست، اما می‌تونی شروع کنی."

    # say L1061 hin
    old "She'll be here in no time."
    new "حتماً زود بر می‌گرده."

    # say L1063 hin
    old "Good, that way you'll finish quickly."
    new "خوب، اینجوری سریعتر تمام می‌شه."

    # say L1064 hin
    old "So, that we'll have time to ourselves again."
    new "پس، وقت خودمون رو دوباره پیدا می‌کنیم."

    # say L1066 hin
    old "Well, I gotta run, bye [pla]."
    new "خب، باید برسم، خداحافظ [pla]."

    # say L1067 pla
    old "See you Hinn!"
    new "ببینم هین!"

    # say L1085 pla
    old "Oh! Wow!"
    new "او! وای!"

    # say L1090 jad
    old "Oh God! [pla]! W- What are you doing here?"
    new "اوه خدا! [pla]! ب- چه کاری اینجا می‌کنی؟"

    # say L1097 pla
    old "I- I came to work on the bathroom."
    new "من- من برای کار روی سرویس آمدم."

    # say L1098 pla
    old "I didn't know you were here Mrs. Jade."
    new "من نمی‌دونستم تو اینجا هستی خانم جید."

    # say L1099 jad
    old "Uhh... I- it's fine, I suppose Hinn let you in while I wasn't in here, right?"
    new "اوه... خب، فرض کنم مشکلی نداره، حین احتمالاً تو راهنمایی کرد که بیایی، درسته؟"

    # say L1100 pla
    old "Y- yeah, yeah, that's what happened..."
    new "بله، بله، همین طور شد..."

    # say L1101 jad
    old "I'm sorry it's my fault, I didn't know you were already here. You just startled me, that's all."
    new "متأسفم، این اشتباه منه، نمی‌دونستم تو قبلاً اینجا هستی. فقط شوکت کردم، همه چیز."

    # say L1108 pla
    old "I- I think I should leave now."
    new "باید حالا برم."

    # say L1110 jad
    old "Yeah, you probably should."
    new "بله، احتمالاً باید بری."

    # say L1111 pla
    old "R- Right... See you later Mrs. Jade."
    new "ر- راست... باید برم. خداحافظ مس جد."

    # say L1133 jad
    old "The gaul off the man!!!"
    new "این مرد واقعاً جرات داره!!!"

    # say L1134 hin
    old "I know, I know!! You don't need to keep telling me about it!"
    new "می‌دونم، می‌دونم!! نیازی نیست همچین چیزی رو به من بگی!"

    # say L1135 jad
    old "I just can't believe your father sometimes!!!"
    new "من فقط نمی‌تونم باور کنم گاهی‌ها پاپت!!!"

    # say L1136 jad
    old "So, this is why he never had any money and he kept coming up with excuses when it came to paying the alimony!"
    new "پس این برای همین هیچ وقت پول نداشت و همیشه عذر کشیدن می‌کرد وقتی باید پول تعلیق مادرت رو پرداخت می‌کرد!"

    # say L1137 hin
    old "I know mom, I know, but again, I have nothing to do with it!!"
    new "مam، می‌دونم، ولی دوباره، من هیچ سر و تهی به این موضوع ندارم!!"

    # say L1138 jad
    old "I didn't say you had to."
    new "من نگفتم باید کردی."

    # say L1143 jad
    old "{b}*Sigh*{/b} I'm sorry Hinn, honey, I shouldn't be screaming like this."
    new "{b}*تنفر*{/b} خوشحالم هین، عزیزم، نباید اینجوری صدا بزنم."

    # say L1144 jad
    old "But I just can't believe how brazen your father is!!!"
    new "ولی نمی‌تونم باور کنم چقدر جسور پدرت هست!!!"

    # say L1145 jad
    old "Not only does he take his little girlfriend on some expensive vacation."
    new "نه فقط اونو با دوست کوچیکش برای تفریح گران‌قیمتی می‌بره."

    # say L1146 jad
    old "But he's also asking her to marry him?!!!"
    new "ولی او هم از او می‌پرسه تا باش ازدواج کنه؟!!!"

    # say L1147 jad
    old "I mean! GOD!!"
    new "منظورم! خدای من!!"

    # say L1148 hin
    old "Oh, [pla]! H- Hi, I didn't notice when you came in."
    new "اوه، [pla]! ه- هی، من متوجه نشدم وقتی وارد شدی."

    # say L1152 jad
    old "[pla], H- Hi honey."
    new "[pla]، ه- هی عزیزم."

    # say L1153 pla
    old "H- hi Mrs. Jade, I came to work in the bathroom, is everything ok?"
    new "ه- سلام خانم جد، من برای کار در حمام اومدم، همه چیز خوبه؟"

    # say L1154 jad
    old "Well, not really."
    new "خوب، واقعاً نه."

    # say L1155 jad
    old "I- I think I need to let my head cool down a bit. I'll just leave you two alone so you can talk."
    new "من فکر می‌کنم باید یه کم سرمو خنک کنم. من فقط شما رو به حال خودتون بگذارم تا با هم حرف بزنید."

    # say L1165 hin
    old "Sorry you had to see that."
    new "متاسفم که این را دیدی."

    # say L1167 pla
    old "It's ok. So, I take it your father has been giving you some trouble?"
    new "خوبه. پس به نظر می‌رسه پدرت با تو مشکل داره؟"

    # say L1168 hin
    old "Hmph, you can say that twice."
    new "همف، می‌تونی دو بار هم بگی."

    # say L1169 hin
    old "Listen [pla], we're very thankful that you're taking the time to come work on the bathroom repairs."
    new "بله، ز[pla]، ما خیلی ممنونیم که وقت خودتو صرف کردی تا اینجا بیایی و کار تعمیرات حمام رو انجام بدی."

    # say L1170 hin
    old "But I don't think today's a good day. With my father acting like an idiot my mom's not in a very good mood."
    new "اما فکر نمی‌کنم امروز خوب باشه. با اینکه پدرم مثل احمق رفتار می‌کنه، مامانم هم خوشحال نیست."

    # say L1171 hin
    old "And I don't feel good either. Do you think you could come another time?"
    new "و من هم حالت خوبی ندارم. فکر می‌کنی می‌تونی زمان دیگه‌ای بیادی؟"

    # say L1172 pla
    old "Of course, of course. Hey, don't worry about it, this is completely understandable."
    new "البته، البته. هی، نگران نباش، این کاملاً قابل فهمه."

    # say L1173 pla
    old "It's fine. I'll just leave, so, the two of you can rest, and I'll come back some other day."
    new "خوبه. من فقط می‌روم، تا شما دو تا بتونید استراحت کنید، و روز دیگه‌ای می‌گردم."

    # say L1174 hin
    old "Thank you, I'm glad you understand."
    new "ممنون، خوشحالم که متوجه شدی."

    # say L1176 pla
    old "Alright, then see you later."
    new "باشه، پس دیگه می‌بینیم."

    # say L1177 hin
    old "See you [pla], thank you again."
    new "ببینم [pla]، ممنونم دوباره."

    # say L1195 pla
    old "Oh! dammit, the pipe got broken again, and now my pants are all wet."
    new "اوه! شیطون، لوله دوباره پاره شد و حالا مونیم همه مرطوب شده."

    # say L1203 jad
    old "[pla]! Is everything ok?! I heard a loud noise."
    new "[pla]! حالت خوبه؟! صدای بلندی شنیدم."

    # say L1205 pla
    old "Yeah, yeah, don't worry. Is just that one of the pipes broke and I got spilled with water. But I'm ok."
    new "بله، بله، نگران نباش. فقط یکی از لوله‌ها شکسته شده و من با آب خورده‌ام. اما من خوبم."

    # say L1206 jad
    old "Oh, ok, that's somewhat of a relief."
    new "اوه، خب، این مقدار آرامش برایم هست."

    # say L1207 jad
    old "Come with me, let's go to the other bathroom, so, you can towel dry."
    new "بیا با من، برویم به حمام دیگه، تا خشک بشی."

    # say L1208 pla
    old "Oh, don't worry, I'm fine really."
    new "اوه، نگران نباش، واقعاً خوبم."

    # say L1209 jad
    old "Don't be silly, you don't want to catch a cold. Come with me."
    new "بیا با من، نمی‌خوای برمی‌آیی. بیا با من."

    # say L1222 jad
    old "Okay, let me give you a hand with that."
    new "بیا، بگذار به تو کمک کنم."

    # say L1240 pla
    old "Uhh, I- I'm sorry Mrs. Jade, I don't know what to say. It's just that..."
    new "اوه، من- من متوجه نشدم خانم جد، نمی‌دونم چی بگم. فقط اینه که..."

    # say L1241 jad
    old "It's ok, it's ok, don't worry. You're a young man, after all."
    new "خوبه، خوبه، نگران نباش. اصلاً تو جوانی هستی."

    # say L1243 jad
    old "I- I'll take it as a compliment."
    new "من این را به عنوان تقدیر می‌پذیرم."

    # say L1245 pla
    old "S- sure, t- thank you."
    new "ب-بله، ممنون."

    # say L1246 jad
    old "Now, why don't you take those pants off? So, I'll throw them in the dryer."
    new "الان، چرا اون شلوارتو ببری؟ منشون به ماشین لباسشویی می‌دم."

    # say L1248 pla
    old "Uhh... Alright."
    new "اوه... خب."

    # say L1254 jad
    old "(What?! He's not wearing anything!!)"
    new "(چه؟! هیچ پوشاکی نداره!!)"

    # say L1255 jad
    old "(Does he just go outside without underwear on?)"
    new "(آیا او فقط بدون لباس داخلی به بیرون می‌رود؟)"

    # say L1256 jad
    old "(But I must say, it's so... big! Is that what my daughters been putting in her?)"
    new "(ولی باید بگم، اینقدر... بزرگه! این همچین چیزی رو توی خودت گذاشتی؟)"

    # say L1257 pla
    old "Uhh... Mrs. Jade?"
    new "اوه... خانم جاد؟"

    # say L1262 jad
    old "What? Oh, right!"
    new "چه کاری؟ اوه، درسته!"

    # say L1263 jad
    old "Just wait here, I'm going to put this on the dryer and see if there's a pajama bottom or something that you can use."
    new "اونجا صبر کن، اینو به خشک‌کن می‌برم و می‌بینم پای جامه یا چیزی برایت پیدا می‌کنم."

    # say L1280 jad
    old "Uhh... H- hi honey! How did school go?"
    new "اوه... سلام حبیب! مدرسه چطور بود؟"

    # say L1281 hin
    old "Fine. Hey mom, are you going to be there much longer?"
    new "خوب. مامان، هنوز طول می‌کشی؟"

    # say L1282 hin
    old "I kinda need to use the bathroom."
    new "من یه کمی به توالت نیاز دارم."

    # say L1288 jad
    old "Uhhh! I'll be here for a while, honey."
    new "اوه! من اینجا می‌مونم، عزیزم."

    # say L1289 jad
    old "I- I'm taking a shower and.... Uhh, I just got in. Sorry honey."
    new "من- من دوش می‌برم و... اوه، همین الان وارد شدم. ببخشید عزیزم."

    # say L1290 hin
    old "Oh, but I only need to use the toilet, so, it should be fine."
    new "اوه، ولی من فقط می‌خوام از توالت استفاده کنم، پس، باید خوب باشه."

    # say L1291 jad
    old "Uhh... Uhhh..."
    new "اوه... اوه..."

    # say L1296 jad
    old "{i}If she sees you here she'll flip her mind.{/i}"
    new "{i}اگه اونجا رو ببینه، خودش را هیجان‌زده می‌شه.{/i}"

    # say L1297 jad
    old "{i}And with how difficult it's been to deal with her lately.{/i}"
    new "{i}و با توجه به اینکه اخیراً با او کار کردن خیلی سخت بوده.{/i}"

    # say L1298 jad
    old "{i}We need to hide you!{/i}"
    new "{i} ما باید تو رو پوشونیم! {/i}"

    # say L1299 jad
    old "{i}Especially because you're naked from the waist down!{/i}"
    new "{i}به خصوص اینکه تو از نیمه پایین برهنه هستی!{/i}"

    # say L1304 jad
    old "Uhh, yeah, yeah, j- just give a sec, honey."
    new "اوه، بله، بله، ج- جوون بده یه لحظه، عزیزم."

    # say L1305 hin
    old "Ughh, come on mom, you can just keep taking your shower."
    new "اوه، بیا مامان، می‌تونی دوشت رو ادامه بدی."

    # say L1306 jad
    old "J- just give me a second!"
    new "ج- جوون بده یه لحظه!"

    # say L1309 jad
    old "{i}Come with me! Hurry up!{/i}"
    new "{i}با من بیا! هریک!{/i}"

    # say L1322 jad
    old "Ok, you can come in!"
    new "باشه، می‌تونی داخل بیایی!"

    # say L1330 hin
    old "Mom, didn't [pla] come today?"
    new "مامان، [pla] امروز نیومده؟"

    # say L1331 jad
    old "Uhh... N- no, he didn't. I guess he must be very busy with school."
    new "اوه... ن- نه، نیومده. باید خیلی مشغول مدرسه باشه."

    # say L1332 hin
    old "Hmm, that makes sense."
    new "Hmm، اینجوری هم منطقی است."

    # say L1333 jad
    old "He's very busy, so, we should just let him come when he can find the time."
    new "او خیلی مشغوله، پس باید بیاد وقتی بتونه."

    # say L1335 jad
    old "(Wait... What is this I'm feeling... Is [pla]'s cock between my legs?)"
    new "(انتظار... این حس چیه... آره، شاید ناخن [pla] بین لب‌هایم باشه؟)"

    # say L1339 jad
    old "(Holy cow! It's huge!)"
    new "(بازی خورده! این هم چقدر بزرگه!)"

    # say L1340 jad
    old "(And still hard... Oh my God...)"
    new "(و هنوز سخت... اوه خدا...)"

    # say L1342 jad
    old "Uhh, w- what? With Hiashi?"
    new "اوه، چ- چه کار؟ با هیاشی؟"

    # say L1343 jad
    old "I- I haven't."
    new "من- من نه."

    # say L1344 jad
    old "(Mmm... Damn, I feel so horny all of a sudden… I haven't been in an intimate situation like this in years...)"
    new "ممنون… شیطون، اینجوری خیلی خیال پر می‌کنم… سال‌ها هیچ موقعی مثل این نبوده."

    # say L1345 jad
    old "I- I called him but he didn't answer."
    new "من- من بهش تلفن کردم ولی جواب نداد."

    # say L1356 jad
    old "Listen, I think it's best if you leave now. Here are your pants."
    new "بله، بهتره حالا بری. این لباساتو برات آماده کردم."

    # say L1362 jad
    old "I'm sorry, I wasn't able to dry them for you."
    new "متاسفم، نتونستم براتون خشک کنم."

    # say L1363 jad
    old "But Hinn might come back, and this situation is already difficult to explain."
    new "اما هین ممکن است برگرده و این وضعیت قابل توضیح نیست."

    # say L1364 pla
    old "It's ok, I'll just go straight home."
    new "باشه، من مستقیم به خونه می‌رم."

    # say L1365 jad
    old "Yeah, that's the best idea."
    new "بله، این بهترین راه حله."

    # say L1366 pla
    old "Ok, see you another time Mrs. Jade. I'll come back later to keep working on the repairs"
    new "باشه، دیدنت خوشحالم جد. بعداً برای ادامه تعمیرات می‌آیم."

    # say L1385 jad
    old "That's good."
    new "این خوبه."

    # say L1386 jad
    old "Listen, I'm glad you came."
    new "بله، خوشحالم که اومدی."

    # say L1387 pla
    old "Uhh, really? Why?"
    new "وای، واقعاً؟ چرا؟"

    # say L1388 jad
    old "Well, I wanted to talk to you. About what happened last time."
    new "خب، می‌خواستم با تو صحبت کنم. در مورد آن چیزی که آخر هفته بود."

    # say L1391 pla
    old "Uh... sure."
    new "اوه... البته."

    # say L1393 jad
    old "I'm so sorry [pla], I don't know what got into me."
    new "من خیلی متاسفم [pla]، نمی‌دونم چه یه من اومد."

    # say L1394 jad
    old "It's just that I've been so stressed out about so many things."
    new "فقط اینه که از خیلی چیزها استرس دارم."

    # say L1396 jad
    old "You know, dealing with my husband's behavior, and Hinn's not been easy either."
    new "می‌دونی، با رفتار شوهرم مشغول هستم، و هین هم آسون نیست."

    # say L1398 jad
    old "So, I'm sorry, very, very sorry."
    new "پس، معذرت، خیلی، خیلی معذرت."

    # say L1399 pla
    old "I- it's ok, Mrs. Jade. Really, don't worry."
    new "خوشحالم، خانم جد. واقعاً نگران نباشی."

    # say L1400 pla
    old "I understand, it was an accident. It's fine."
    new "فهمیدم، اتفاقی بود. خوبه."

    # say L1402 pla
    old "Yes, I know that you and Hinn are going through a lot lately."
    new "بله، میدونم که تو و هین اخیراً خیلی مشکلاتی داشتین."

    # say L1403 pla
    old "Uhh, and yesterday, it was mostly a misunderstanding that escalated quickly."
    new "اوه، و دیروز، بیشتر اشتباه فهمی بود که به سرعت پیش رفت."

    # say L1404 jad
    old "Oh, thank you [pla]! Thanks for understanding, you're such a good young man."
    new "اوه، ممنون [pla]! ممنون که فهمیدی، تو یه جوان خوبی هستی."

    # say L1405 pla
    old "Thanks for saying that Mrs. Jade."
    new "ممنون از اینکه اینجوری گفتی خانم جد."

    # say L1407 pla
    old "So, I'll just go to work in the bathroom. I think it shouldn't be long before I finish."
    new "پس من فقط برم به دوش برسم. فکر کنم زیاد طول نمی‌کشه تا تمام بشه."

    # say L1408 jad
    old "Sure, sure, also, thanks a lot for doing that."
    new "بله، البته، همچنین ممنون از این که این کار را انجام می‌دهی."

    # say L1409 pla
    old "It's not a problem."
    new "مشکلی نداره."

    # say L1423 pla
    old "Hi! Hello? Hinn? Mrs. Jade?"
    new "سلام! هیلو؟ هین؟ خانم جد؟"

    # say L1424 pla
    old "That's weird, they're usually here in the afternoon."
    new "عجیبه، معمولاً اینجا هستن در بعد از ظهر."

    # say L1425 pla
    old "Hello?!"
    new "سلام؟!"

    # say L1433 pla
    old "Hinn? Mrs. Jade? Anyone here?"
    new "هین؟ خانم جد؟ کسی اینجا هست؟"

    # say L1434 pla
    old "This is odd."
    new "این عجیبه."

    # say L1435 pla
    old "I guess they went out."
    new "باید برونشون رفته باشند."

    # say L1436 pla
    old "I suppose there's no problem if I go up and work on the bathroom."
    new "باید مشکلی نباشه اگر بالا برسم و به سرویس کار کنم."

    # say L1459 jad
    old "Oh my God! [pla]! W- what are you doing there?!"
    new "اوه خدا! [pla]! چ- چه کاری اینجا می‌کنی؟!"

    # say L1460 pla
    old "S- sorry! I didn't see anything, I was looking for you and I just opened the door."
    new "ب- ببخشید! هیچ چیز ندیدم، فقط دنبال تو بودم و در رو بی‌تفکر باز کردم."

    # say L1461 pla
    old "I was going to work in the bathroom, but, I think I should just leave."
    new "من می‌خواستم توی حمام کار کنم، اما فکر کنم باید برم."

    # say L1469 jad
    old "Uhh, this is my fault, I'd forgotten you were coming today."
    new "اوه، این اشتباه منه، فراموش کرده بودم امروز می‌آیی."

    # say L1470 jad
    old "So, I'll just dress up and you can get to work on the repairs."
    new "پس من فقط لباس می‌کنم و تو می‌تونی به تعمیرات بپردازی."

    # say L1471 jad
    old "Can we just pretend this never happened?"
    new "می‌تونیم بگیم هیچی پیش نیومده؟"

    # say L1472 pla
    old "Uhhh, sure."
    new "اوه، البته."

    # say L1480 jad
    old "(My God, he has another boner, and it's so big.)"
    new "خداوند، دوباره سفت شده و اینقدر بزرگ است."

    # say L1481 pla
    old "I- I think I'll start working on the bathroom, then."
    new "من- من فکر می‌کنم شروع به کار در حمام کنم."

    # say L1482 jad
    old "R- right, right. Well, you know where everything is."
    new "R- راستی، راستی. خب، میدونی همه چی کجاست."

    # say L1492 pla
    old "Wow, that was crazy..."
    new "واو، این جنون بود..."

    # say L1493 pla
    old "Thank God, she is very calm and reasonable."
    new "الهی، او خیلی آرام و منطقی است."

    # say L1494 pla
    old "Anyway, I better finish this as soon as possible."
    new "بازهم، بهتره این رو هر چه زودتر تمام کنم."

    # say L1507 pla
    old "Oh, hi Mrs. Jade, yeah, I'm done for today."
    new "اوه، سلام خانم جید، بله، امروز تمام شد."

    # say L1508 pla
    old "It's almost done, I don't think it will be too long until I'm finished with the repairs."
    new "تقریباً تمام شده، فکر نمی‌کنم طول بکشه تا این کار اصلاحی تمام بشه."

    # say L1509 jad
    old "That's great honey, thank you."
    new "عالیه عزیزم، ممنون."

    # say L1510 jad
    old "And listen, about what you saw me doing today."
    new "و بگوش، در مورد آنچه امروز دیدی."

    # say L1511 jad
    old "I'm sorry, I wouldn't have wanted you to see that. It must've been very awkward."
    new "ببخشید، نمی‌خواستم تو اینجوری ببینی. حتماً برایت خیلی ناخوشحالم بود."

    # say L1513 pla
    old "No, no, I'm the one who should be apologizing, this is your house after all."
    new "نه، نه، من هستم که باید عذرخواهی کنم، این خونه تو هست."

    # say L1514 pla
    old "I shouldn't have come into your bedroom without knocking."
    new "من نباید بدون زنگ زدن وارد اتاق خوابت شدم."

    # say L1515 jad
    old "Well, anyway, I'm sorry you had to see that."
    new "البته، معذرت که باید این را دیده‌ای."

    # say L1516 jad
    old "I'm sure it must not be enjoyable to see an older woman in those... Circumstances."
    new "مطمئن هستم که برای تو لذت‌بخش نبوده که یک زن بزرگسال را در این... شرایط ببینی."

    # say L1518 pla
    old "Ohh, of course not, you're a very beautiful woman."
    new "اوه، البته نه، تو خیلی زن زیبا هستی."

    # say L1520 pla
    old "I- I mean...!"
    new "من- من می‌خواستم بگم...!"

    # say L1521 jad
    old "I get it, I get it, thank you [pla]."
    new "فهمیدم، فهمیدم، ممنون [pla]."

    # say L1523 pla
    old "Oh, ok."
    new "اوه، خب."

    # say L1524 pla
    old "Well, I think I should get going."
    new "باید برم."

    # say L1525 jad
    old "Yeah, it's getting a little late."
    new "بله، وقت کمی دیر شده."

    # say L1526 pla
    old "Have a good night Mrs. Jade."
    new "شب خوبی بخیر خانم جد."

    # say L1527 jad
    old "You too darling."
    new "شما هم شب خوبی داشته باش عزیزم."

    # say L1546 pla
    old "Oh, hi Mrs. Jade, Mrs. White."
    new "اوه، سلام خانم جید، خانم وایت."

    # say L1551 whi
    old "Well hello there [pla]. Tell me jade? What is this fine young man doing here?"
    new "خب سلام ز[pla]. جد، بگو این جوان خوب اینجا چه کاری داره؟"

    # say L1552 jad
    old "Well, do you remember I told you there was some damage in my bathroom?"
    new "البته، به یاد دارید که به شما گفتم خرابی‌هایی در حمام من وجود داره؟"

    # say L1553 whi
    old "Uh huh."
    new "آره."

    # say L1554 jad
    old "Well, I'll have you know that [pla] here was kind enough to volunteer to help me do the repairs."
    new "می‌دونی [pla] اینجا خوشحال شد که به من کمک کنه تا تعمیرات رو انجام بدم."

    # say L1556 jad
    old "He did. You know that with everything that's been going on with Hiashi things have been a little tight around here."
    new "او انجام داد. می‌دونی با همه چیزایی که با هیاشی اتفاق پیش اومده، اوضاع اینجا یه جور خیلی تنگ شده."

    # say L1557 whi
    old "Uhmm."
    new "اوه."

    # say L1558 jad
    old "Well, I couldn't really afford for a plumber to do it, but [pla] has been  perfect."
    new "خب، نمی‌تونستم هزینه یک آبکار رو بپردازم، اما [pla] خیلی خوب کار کرد."

    # say L1559 jad
    old "He's such a fine young man."
    new "او چنین جوان خوبی است."

    # say L1561 whi
    old "Oh, you don't have to tell me too much about it."
    new "اوه، لازم نیست خیلی در موردش صحبت کنید."

    # say L1563 whi
    old "I know full well what a helpful capable young man [pla] is. He actually helped me with something in the past."
    new "من خوب می‌دونم چقدر [pla] جوان کمک‌گر و توانا هست. واقعاً در گذشته به من کمک کرده."

    # say L1564 pla
    old "Uh... I think I'll go work in the bathroom for now."
    new "اوه... فکر کنم الان بروم توی حمام کار کنم."

    # say L1565 jad
    old "Sure honey, you know where everything is."
    new "البته عزیزم، میدونی همه چیجوری هست."

    # say L1566 pla
    old "With your permission, see you later, Mrs. White and Mrs Jade."
    new "با اجازه شما، تا بعد می‌بینم، خانم وایت و جد."

    # say L1576 whi
    old "So, tell me, what came of that whole business with Hiashi? Did you get him to pay your alimony?"
    new "پس، بگو، اون کار با هیاشی چطور شد؟ آیا او هزینه‌های طلاقت رو پرداخت؟"

    # say L1577 jad
    old "Ha! Not only he didn't pay, but he also took that little bimbo he calls his girlfriend on vacation."
    new "هه! نه فقط پول نداد، بلکه آن دختر کوچولویی که دوستش می‌خواند هم برای تفریح برد."

    # say L1578 whi
    old "No way!"
    new "نه، می‌تونی باور کنی!"

    # say L1579 whi
    old "You're joking."
    new "نه، می‌تونی باور کنی! تو دیویزیونی!"

    # say L1581 jad
    old "I wish, but that's not all of it. Apparently, while they were there."
    new "دلم می‌خواست، اما همه‌ی اون نیست. به نظر می‌رسه وقتی اونجا بودن."

    # say L1582 jad
    old "He asked her to marry him!"
    new "او ازش پرسه شد!"

    # say L1583 whi
    old "Oh my God! I can't believe it!"
    new "اوه خداوند! باورم نمی‌شه!"

    # say L1584 whi
    old "I remember he was a pig, but I didn't know just how low he could sink."
    new "به خاطر دارم که او یک خوک بود، اما نمی‌دونستم چقدر پایین می‌تونه بره."

    # say L1585 jad
    old "Ugh, Tell me about it!"
    new "اوه، در موردش بگو!"

    # say L1586 jad
    old "After he posted the photos with the engagement ring, he realized that they were public, so, he took them down."
    new "بعد از اینکه عکس‌هایی با حلقه زنا زدگی را آپلود کرد، متوجه شد که آن‌ها عمومی هستند، پس، آن‌ها را حذف کرد."

    # say L1587 jad
    old "But by that point, it was already too late. We had already seen them."
    new "اما آن موقع قطعاً خیلی دیر بود. ما قبلاً آن عکس‌ها رو دیده بودیم."

    # say L1588 whi
    old "I just can't believe how irresponsible that man is."
    new "من فقط نمی‌تونم باور کنم اون آدم چقدر بی‌پرواست."

    # say L1589 jad
    old "{b}*Sigh*{/b} In a way, I can't either, I mean, ever since we broke up I never had any hopes that he would be exemplary."
    new "{b}*تنفر*{/b} به نوعی من هم نمی‌تونم، منظورم اینه که از وقتی با هم فرقه شدیم هیچ امیدی نداشتم که او مثال‌زای باشه."

    # say L1590 jad
    old "But I didn't want to believe he would stand this low. It's always the same disappointing story when it comes to him."
    new "ولی نمی‌خواستم باور کنم او اینقدر پایین ایستاده باشه. همیشه همین داستان ناامید کننده‌اش هست وقتی در موردش حرف می‌زنم."

    # say L1591 jad
    old "And that's not all, I've been having terrible migraines, and insomnia because of it."
    new "و این همه نیست، مغزم خیلی درد می‌کنه و به خاطر این نمی‌تونم خواب بیافتم."

    # say L1592 jad
    old "Not to mention that Hinn's been a real handful as of late. I swear to God, I don't even know how to talk to her anymore."
    new "البته که هین هم اخیراً خیلی سردرگرم کننده بوده. قسمت خدا، حتی نمی‌دونم چطور باهاش صحبت کنم."

    # say L1593 jad
    old "The whole thing has culminated in me being in constant panic and with my emotions all over the place!"
    new "همه این‌ها من رو به همراه ترس دائمی و احساسات پرتوزا گذاشته‌اند!"

    # say L1594 jad
    old "I've been thinking that maybe I should go to a psychiatrist. Maybe I have some sort of anxiety, you know?"
    new "من فکر می‌کنم شاید باید به روان‌پزشک برسم. شاید اضطرابی دارم، می‌دونی؟"

    # say L1595 whi
    old "Well... I guess you could call it that..."
    new "خب... می‌تونی اینجوری بگی..."

    # say L1596 jad
    old "Well, duh, that's the name of it. What else could it be?"
    new "خب، این هم اسمش هست. چیز دیگه‌ای می‌تونه باشه؟"

    # say L1597 whi
    old "For one thing, a lack of sex."
    new "یعنی برای مثال، نبود جنس."

    # say L1599 jad
    old "A what?!"
    new "یه چی؟!"

    # say L1600 whi
    old "You heard me, it sounds to me that what you have is a typical case of not fucking."
    new "شو دیگه، منو شنیدی، به نظر می‌رسه که تو مورد نمونه‌ای از عدم فک‌کردن هستی."

    # say L1602 whi
    old "Hey, I've been there myself, so, I know the symptoms."
    new "Jad، خودم هم اینجا بودم، پس علائم رو می‌شناسم."

    # say L1603 whi
    old "You've been under a lot of stress lately, all of that accumulates in your body."
    new "تو اخیراً خیلی استرس داشتی، همه این‌ها در بدنت تجمع می‌کنند."

    # say L1604 whi
    old "And since you're not sexually active with anybody you just get anxious."
    new "و چون جنسیتی با هیچ‌کس فعالیت نمی‌کنی، فقط ناراحت می‌شی."

    # say L1606 jad
    old "Oh, come on! Be serious please..."
    new "اوه، لطفاً جدی باش!"

    # say L1608 whi
    old "I am!"
    new "من جدی هستم!"

    # say L1609 whi
    old "Listen, you're not having sex, but you still need to do it."
    new "بله، شنیدی؟ تو جنس نمی‌کنی، اما همچنان باید این کار رو انجام بدی."

    # say L1610 whi
    old "Add to that all of the other problems that you have to deal with."
    new "به همه مشکلات دیگه که باید باهاشون سر کار داری اضافه کن."

    # say L1611 whi
    old "And you're a ticking time bomb!"
    new "و تو یک بمب زمانی هستی!"

    # say L1612 whi
    old "You're repressed Jade, and believe me, that's not good for you."
    new "تو خودت رو فشار میدی جدی، و باور کن، این برایت خوب نیست."

    # say L1613 whi
    old "It's clear to me that what you need is a good fucking. That'll help you."
    new "به نظر من تو نیاز داری خوب جنس کنی. این کار به تو کمک می‌کنه."

    # say L1614 jad
    old "Hahaha, yeah right. Who am I going to do it with?"
    new "هahaha، همینه. من با کی می‌تونم این کار رو بکنم؟"

    # say L1615 jad
    old "I'm an old divorced woman."
    new "من یک زن طلاق شده هستم."

    # say L1616 jad
    old "Who's going to want to be with me?"
    new "چه کسی می‌خواست با من باشه؟"

    # say L1617 whi
    old "Oh! You know you're pretty. Any man would give an arm and a leg to have a chance to jump into your bed."
    new "اوه! می‌دونی خوشوندی. هر مردی خوشحال می‌شه که فرصتی برای رفتن به کنار تخت تو پیدا کنه."

    # say L1618 jad
    old "Yeah right."
    new "نه، درست نیست."

    # say L1620 whi
    old "Listen, girl, I'm not saying it just to mess with you. You need physical intimacy, it's good for you."
    new "بگوش، من فقط برای خوشحال کردنت اینجوری نمی‌گم. نیازت به ارتباط جسمی هست، برایت خوبه."

    # say L1621 whi
    old "If you don't do something about it you'll just start getting depressed and maybe even having anxiety attacks!"
    new "اگر هیچ کاری در این مورد نکنی، شاید خسته و ناراحت بشی و حتی ممکنه حملات اضطراب هم داشته باشی."

    # say L1622 whi
    old "You need to release all of those things you're holding in."
    new "تو باید همه اون چیزهایی که تو داری درونت نگه می‌داشته‌ای رو آزاد کنی."

    # say L1624 jad
    old "Hmm, maybe you're right..."
    new "ممکن است همین درست باشه..."

    # say L1626 jad
    old "But even so? Who would I even be intimate with?"
    new "ولی حتی اگه هم، من با چه کسی می‌تونم اینجوری باشم؟"

    # say L1640 pla
    old "Ok Mrs. Jade, I've  finished for today."
    new "خوب خانم جد، برای امروز تمام شده."

    # say L1642 jad
    old "Thank you, honey, you were done very quickly!"
    new "ممنون، عزیزم، خیلی سریع تمام شدی!"

    # say L1643 pla
    old "Yeah, I would've liked to do some more, but sadly I'm busy with some school work, so, I'm gonna have to go for today."
    new "بله، می‌خواستم کار بیشتری انجام بدم، ولی متاسفانه باید به کار مدرسه بپردازم، پس امروز باید برسم."

    # say L1644 jad
    old "That's ok honey, see you another time."
    new "باشه عزیزم، دیگه ببینم چه زمانی دیگه."

    # say L1645 whi
    old "By the way [pla], you should come to my house one of these days."
    new "البته، باید یک روز به خونه من بیایی [pla]."

    # say L1646 whi
    old "I can think of one or two things you could help me fix."
    new "می‌تونی یک دو تا چیز رو که نیاز به اصلاح دارن به من کمک کنی."

    # say L1647 pla
    old "Yeah, haha... Maybe I'll go later."
    new "بله، هاها... شاید بعداً برم."

    # say L1648 pla
    old "Well, hope to see you soon. Bye."
    new "البته، امیدوارم زودی ببینمت. خداحافظ."

    # say L1650 jad
    old "Bye honey."
    new "بای عزیزم"

    # say L1652 whi
    old "See you later sweetie."
    new "تا بعداً عزیزم."

    # say L1661 jad
    old "So, what were we talking about?"
    new "پس، در مورد چه چیزی صحبت می‌کردیم؟"

    # say L1662 whi
    old "We were saying that you need to fuck!"
    new "ما می‌گفتیم که تو باید جنس کنی!"

    # say L1663 jad
    old "Ah, right, that..."
    new "اوه، درسته، اون..."

    # say L1664 jad
    old "But you know, it's not as if I'm not doing anything, I masturbate often, and I feel like that's good."
    new "اما می‌دونی، من هم کاری نمی‌کنم، زیاد خودمو لمس می‌کنم و فکر می‌کنم این خوبه."

    # say L1665 whi
    old "That won't be enough. Believe me, I have some experience with this."
    new "این کافی نیست. باور کن، تجربه‌های من در این زمینه خیلی هست."

    # say L1666 whi
    old "What you need is a big, hard cock to ravage you."
    new "تو نیاز داری به یه ذکر بزرگ و سخت که تو رو بزنه."

    # say L1668 jad
    old "So classy..."
    new "خیلی شیک..."

    # say L1670 jad
    old "But then again, who's it going to be? I don't know anybody, and I'm too busy, and frankly tired, to go out looking for dates."
    new "اما بگو، چه کسی هست؟ من هیچ کس رو نمی‌شناسم و خیلی مشغول هستم، صداقت بگم خسته هم هستم تا برای رنده‌ها برم خارج."

    # say L1672 whi
    old "Also, not just anybody can do it. It has to be someone that can rock you."
    new "همچنین، هر کسی نمی‌تونه این کار رو بکنه. باید کسی باشه که بتونه تو رو شگفت‌زده کنه."

    # say L1676 whi
    old "Well, I'll tell you what, I think I know just the right guy to do it!"
    new "خب، به تو می‌گم، فکر می‌کنم اون آدم رو بلدی که می‌تونه این کار رو انجام بده!"

    # say L1677 jad
    old "You do? Do we have any common friends that I don't know about?"
    new "تو همچین کسی رو می‌شناسی؟ آیا ما دوست مشترکی داریم که من نمی‌دونم؟"

    # say L1680 whi
    old "Listen, what you don't need is some old guy who's just going to get tired after a couple of pumps."
    new "بله، چیزی که نیاز نداری اینه که یه آقا قدیمی باشه که چند ضربه داده بعد خسته بشه."

    # say L1681 whi
    old "You need a young, healthy stallion that's going to pump you full, and it's going to make you scream with his big dick."
    new "تو نیاز داری به یه جوان سرشار از سلامتی که بتونه تو رو پر کنه و با لوله بزرگش باعث صدای صدا بریزی."

    # say L1682 jad
    old "Hahaha, what are you saying?"
    new "هahaha، تو چه حرفی می‌زنی؟"

    # say L1683 jad
    old "Ok, let's say that's what I need. Where am I going to find this young stallion that's going to do that to me?"
    new "خب، فرض کنیم این هسته چیزی که بهش نیاز دارم. اما این جوان سرشار رو کجایی می‌پیدم که این کار رو برایم انجام بده؟"

    # say L1684 whi
    old "Baby, you've already met him!"
    new "حبیبی، تو قبلا باشون آشنا شدی!"

    # say L1686 jad
    old "I have?"
    new "من دارم؟"

    # say L1687 whi
    old "Well of course! He's always here at your house!"
    new "البته! همیشه توی خونت هست!"

    # say L1689 jad
    old "What? You mean [pla]?!! What are you talking about?!"
    new "چه؟ منظورت [pla] هست؟!! چه حرفی می‌زنی؟"

    # say L1690 whi
    old "What? What's so odd about that?"
    new "چه چیزی عجیبی داری می‌گی؟"

    # say L1691 whi
    old "He's young, he's healthy, he's a very good kid."
    new "او جوان است، سالم است، و یک بچه خوب است."

    # say L1692 whi
    old "And he has some experience."
    new "و تجربه هم داره."

    # say L1693 whi
    old "He's just what you need!"
    new "او دقیقاً همان چیزیه که تو نیاز داری!"

    # say L1694 jad
    old "Yeah right! As if!"
    new "بله ها! مثلاً!"

    # say L1696 whi
    old "Oh my God! Why not?!"
    new "اوه خداوند! چرا نه؟!"

    # say L1697 jad
    old "Well, for one thing, he's actually having sex with my daughter!"
    new "خب، اول اینکه، او واقعاً با دخترم سکس می‌کنه!"

    # say L1698 whi
    old "So, are they officially dating?"
    new "پس، آیا اونها رسمی همراه هستن؟"

    # say L1699 jad
    old "Well, it's complicated, it's one of those new things the kids are doing these days."
    new "خب، پیچیده است، این یکی از آن چیزهای جدیدی است که بچه‌ها امروزه می‌کنند."

    # say L1700 jad
    old "You know, having sex without an official relationship... I honestly don't understand."
    new "می‌دونی، جنس کردن بدون رابطه رسمی... صد در صد نمی‌فهمم."

    # say L1701 whi
    old "Then there's no problem!"
    new "پس مشکلی نداره!"

    # say L1702 whi
    old "Of course you couldn't tell Hinn, but that's not too much of a big deal."
    new "البته نمی‌تونستی به هین بگی، اما این خیلی مهم نیست."

    # say L1703 jad
    old "That's not all of it!"
    new "این همه نیست!"

    # say L1704 whi
    old "It isn't? What else then?"
    new "نه؟ پس چه چیز دیگری هست؟"

    # say L1705 jad
    old "He's too young..."
    new "او خیلی جوان است..."

    # say L1706 jad
    old "He could be my son!"
    new "می‌تونه پسرم باشه!"

    # say L1707 whi
    old "Oh please! So what? Why do you think Hiashi is dating that nineteen-year-old hussy?"
    new "لطفاً! این چه بحثیه؟ چرا فکر می‌کنی هیاشی با آن دختر نوزاد نوزاد نوزده ساله رابطه داره؟"

    # say L1709 whi
    old "It's because the sex it's really, really good, and she helps him feel good."
    new "چون جنس واقعاً، واقعاً خوبه و اونجور که او رو خوشحال می‌کنه."

    # say L1710 whi
    old "Also, you can use this as a chance to get back at that pig of your ex-husband's for what he's doing."
    new "همچنین، می‌توانی از این فرصت برای پاسخ دادن به آن خوک همسرت قدیمی استفاده کنی که حالا چه کاری می‌کنه."

    # say L1711 jad
    old "Hmm, I don't know... That would be really inappropriate."
    new "هم، نمی‌دونم... این خیلی نامناسب هست."

    # say L1712 whi
    old "Oh! Stop acting as if I'm saying something crazy."
    new "اوه! بپرس از خودت چرا مثل اینکه چیزی جنونی می‌گم رفتی."

    # say L1713 jad
    old "Aren't you?"
    new "نه تو؟"

    # say L1714 whi
    old "Please! With all of the time that he's been in here."
    new "لطفاً! با توجه به زمان زیادی که او اینجا بوده."

    # say L1716 whi
    old "Can you honestly tell me that you've never thought about having your way with him?"
    new "می‌تونی صادقانه به من بگی هیچ وقت فکر نکردی که با او چیزی انجام بدی؟"

    # say L1717 whi
    old "Or him having his way with you. Whichever way you prefer."
    new "یا او با تو. هر کدام رو انتخاب کنی."

    # say L1718 jad
    old "Uhhh."
    new "اوه."

    # say L1720 whi
    old "Wait! Wait a minute!"
    new "بی‌چین! بی‌چین یک لحظه!"

    # say L1721 whi
    old "Don't tell me you already did something with him!"
    new "نگو برام قبلاً چیزی باش انجام دادی!"

    # say L1722 jad
    old "No, no, no, no!"
    new "نه، نه، نه، نه!"

    # say L1723 jad
    old "Nothing like what you're thinking."
    new "نه، هیچی مثلی که تو فکر می‌کنی نیست."

    # say L1725 whi
    old "But you did do something didn't you?"
    new "ولی تو چیزی انجام دادی، درسته؟"

    # say L1726 jad
    old "You're unbelievable."
    new "تو غیر قابل باوری هستی."

    # say L1727 jad
    old "Ok, the other day as he was doing something in the bathroom one of the pipes broke, and his pants got wet."
    new "خب، روزی روزگاری وقتی در حمام کاری می‌کرد یکی از لوله‌ها شکست و لباس‌هایش خیس شدند."

    # say L1731 jad
    old "So, I told him that maybe he should take them off just so that I could throw them in the dryer."
    new "پس، بهش گفتم شاید باید اون لباس‌ها رو ببرم خشک کنم."

    # say L1732 whi
    old "I like where this is going."
    new "می‌پسندم که اینجوری پیش می‌رود."

    # say L1734 jad
    old "Well, the thing is that... For some reason, he had a boner, and wasn't wearing drawls."
    new "خب، اونجوری بود که... برای همین، شورت‌اش رو پوشیده نبود و یک سفتی داشت."

    # say L1736 whi
    old "Oh my God and you saw his boner?!"
    new "اوه خدا و تو دیدی سفتیش رو؟!"

    # say L1737 whi
    old "Hahaha, this is great! It was huge wasn't it?"
    new "هahaha، این خیلی خوبه! بزرگ بود نه؟"

    # say L1738 jad
    old "You're terrible, you know that?"
    new "تو خیلی بدی، میدونی؟"

    # say L1739 jad
    old "... But yes, he was very big. Like, very, very big."
    new "ولی بله، او خیلی بزرگ بود. مثل اینکه خیلی، خیلی بزرگ بود."

    # say L1740 jad
    old "But that's it, nothing else happened."
    new "اما این همه، هیچ چیز دیگه پیش نیومد."

    # say L1741 jad
    old "At all..."
    new "البته، هیچ چیز دیگه پیش نیومده."

    # say L1742 whi
    old "It doesn't matter, this is great!"
    new "این مهم نیست، این خیلی خوبه!"

    # say L1745 whi
    old "Don't you see? He got a boner because of you! He already thinks you're hot!"
    new "می‌بینی؟ او به خاطر تو سخت شد! قبلاً فکر می‌کنه تو خوبی!"

    # say L1746 whi
    old "But that kid's too timid to do anything, he won't make a move unless he thinks you want it too."
    new "اما اون بچه خیلی ترسناکه، مگه می‌تونه هیچ کاری بکنه مگه فکر کنه تو هم می‌خوای."

    # say L1747 whi
    old "But that's not a problem, I can deal with that."
    new "اما این مشکلی نیست، من می‌تونم با این کار برخورد کنم."

    # say L1748 jad
    old "Wait! What are you going to do?!"
    new "بیا! قراره چی کنی؟!"

    # say L1750 whi
    old "Don't worry, I won't do anything you don't want."
    new "نگران نباش، هیچ کاری که تو نخوای نمی‌کنم."

    # say L1751 jad
    old "Wait, don't do anything dumb."
    new "بیا، هیچ کار احمقانه‌ای نکن."

    # say L1752 whi
    old "Me? I'll just take care of this for you, that's all."
    new "من؟ من فقط اینو برایت حل می‌کنم، همین."

    # say L1753 whi
    old "And I better leave before you change your mind."
    new "و بهتر است قبل از اینکه نظرت عوض شود، بروم."

    # say L1769 jad
    old "Oh my God, what did I get myself into?"
    new "اوه خدا، من چه کاری انجام دادم؟"

    # say L1790 pla
    old "Hi [mo1]."
    new "سلام ز[mo1]."

    # say L1791 mo1
    old "Sweetie, Mrs. White's outside, she says she has something to talk to you about."
    new "حباب، خانم وایت بیرون است، می‌گه چیزی برای صحبت با تو داره."

    # say L1792 pla
    old "She wants to talk to me?"
    new "می‌خواد با من حرف بزنه؟"

    # say L1793 mo1
    old "Yes, she says it's something about your friend Mike."
    new "بله، می‌گه در مورد دوستت مایک هست."

    # say L1794 pla
    old "I see, well, I'll be right out."
    new "ببینم، خب، من الان بیرون می‌آیم."

    # say L1795 mo1
    old "Ok, honey."
    new "باشه، عزیزم."

    # say L1805 pla
    old "Hi Mrs. White, is everything alright with Mike?"
    new "سلام خانم وایت، همه چیز با مایک خوبه؟"

    # say L1806 whi
    old "Hi honey, yeah, yeah, don't worry. It's just that I need you to come with me to my house for a second."
    new "سلام عزیزم، بله، بله، نگران نباش. فقط باید یه لحظه به خونه من بیایی."

    # say L1807 whi
    old "There's something I want you to talk about with Mike."
    new "چیزی هست که می‌خوام با مایک صحبت کنم."

    # say L1808 pla
    old "Me? Is it something serious?"
    new "من؟ این جدیه؟"

    # say L1809 whi
    old "Not really, but it's more of a guy thing, so, I think it would be better if he hears it from another man."
    new "خیر، اما این موضوع بیشتر مربوط به مردان است، پس فکر می‌کنم بهتر باشد از یک مرد بشنود."

    # say L1810 pla
    old "Oh, ok, I guess that's fine. Sure, I'll come with you."
    new "اوه، خوب، فکر کنم مشکلی نداره. بله، من همراهت می‌رم."

    # say L1817 pla
    old "So, it's Mike in his bedroom?"
    new "پس مایک در اتاق خوابش؟"

    # say L1818 whi
    old "No, actually, I must admit I lied to you, he's not in the house, and he won't be for a while."
    new "نه، در واقع باید بگم که به تو دروغ زدم، او در خانه نیست و برای مدتی هم نخواهد بود."

    # say L1819 pla
    old "Then how am I supposed to talk to him?"
    new "پس من چطور باید با او حرف بزنم؟"

    # say L1820 whi
    old "Well, to be honest with you [pla], I don't actually want you to talk to Mike."
    new "البته، صادقانه بگم [pla]، در واقع من نمی‌خوام تو با مایک صحبت کنی."

    # say L1821 pla
    old "You don't?"
    new "نه؟"

    # say L1822 whi
    old "No, the person I want you to help is a friend of mine, who needs something from you."
    new "نه، اون کسی که می‌خوام تو بهش کمک کنی، دوست منه، ازت چیزی نیاز داره."

    # say L1823 pla
    old "Who is it?"
    new "چه کسی هست؟"

    # say L1824 whi
    old "Well honey, it's Jade, there's something that she needs from you."
    new "خوب عزیزم، اون جدیه، چیزی هست که ازت نیاز داره."

    # say L1825 pla
    old "Did anything happen to her?"
    new "به اون چیزی پیش اومده؟"

    # say L1827 whi
    old "Not yet."
    new "هنوز نه."

    # say L1828 pla
    old "I have to tell you, Mrs. White, you're not really making a lot of sense here, you know?"
    new "باید بهت بگم، خانم وایت، اینجا واقعاً منطقی نیستی، می‌دونی؟"

    # say L1829 whi
    old "That's because I haven't really told you anything."
    new "این به خاطر اینه که هنوز بهت هیچ چیزی نگفتم."

    # say L1830 whi
    old "Listen [pla], the thing I want you to do, is to have sex with Jade."
    new "بگوش [pla]، آنچه می‌خوام ازت بکنی، جد بازی کردن با جدی."

    # say L1831 pla
    old "What?!"
    new "چه؟!"

    # say L1832 whi
    old "Just as you hear it, you are going to help Jade by fucking her."
    new "همانطور که شنیدی، قراره جد به کمکت بیاید با فکر کردن در مورد او."

    # say L1833 pla
    old "Why would I do that?"
    new "چرا باید این کار رو بکنم؟"

    # say L1835 whi
    old "Well, there's a lot to explain, but basically, Jade's been under a lot of pressure."
    new "خب، خیلی چیزهایی برای توضیح دادن هست، اما به طور خلاصه، جید تحت فشار زیادی بوده."

    # say L1836 whi
    old "She wouldn't admit it, but she's repressed. So, she really needs to release that, you know what I mean?"
    new "او اعتراف نمی‌کرد، اما فشار زیادی داشت. پس، به نظر می‌رسد که نیاز دارد این فشار رو رها کنه، می‌فهمی چی می‌گم؟"

    # say L1837 whi
    old "And since I know how gifted you are in that regard, I thought that you're the right person to help her."
    new "و چون میدونم تو در این زمینه موهبت داری، فکر کردم تو همینجوری بتونی به جید کمک کنی."

    # say L1838 pla
    old "This is crazy Mrs. White, I mean, how do we even know that Mrs. Jade would want to do anything with me?"
    new "این خیلی عجیب است، خانم جیت، منظورم اینه که چطور می‌دونیم خانم جید خواسته با من هیچ کاری بکنه؟"

    # say L1839 whi
    old "Oh, don't you play dumb with me!"
    new "اوه، نباید با من احمق بازی کنی!"

    # say L1840 whi
    old "I already know you two have done a couple of things already."
    new "من قبلاً می‌دونم شما دو تا چند بار با هم کار کرده‌ای."

    # say L1842 whi
    old "So, listen carefully, this is what's going to happen..."
    new "پس، به خوبی گوش کن، این همینطور خواهد بود..."

    # say L1853 jad
    old "Hey, where have you been?"
    new "هی، تو کجایی بودی؟"

    # say L1854 whi
    old "I was just having a little word with [pla], you know, getting him onboard and what not."
    new "من فقط یه کمی با [pla] صحبت کردم، می‌دونی، برای اینکه او رو متقاعد کنم و همچین."

    # say L1855 jad
    old "Oh my God! Did you actually bring him here?"
    new "اوه خداوند! تو واقعاً اونو اینجا آوردی؟"

    # say L1856 jad
    old "I can't believe I let you talk me into doing something this crazy!"
    new "نمی‌تونم باور کنم اجازه دادم تو مرا برای کاری اینقدر جنون‌آمیز قانع کنی!"

    # say L1857 whi
    old "Well, he's already here, so, no turning back now."
    new "خب، اونجا هست، پس حالا نمی‌تونیم برگردیم."

    # say L1859 whi
    old "Listen, I already talked to him, so, you don't need to worry about anything other than enjoying yourself."
    new "بگوش، من قبلاً با او صحبت کردم، پس نباید نگران هیچ چیزی غیر از لذت بردن باشی."

    # say L1860 whi
    old "I don't want you thinking about anything stressful, or about your daughter."
    new "من نمی‌خوام فکری به چیزهای استرس‌زا یا دخترت بکنی."

    # say L1861 whi
    old "I especially don't want you thinking about that asshole Hiashi!"
    new "به خصوص نمی‌خوام فکر کنی به آن خرا هیاشی!"

    # say L1862 whi
    old "All you need to do is focus on your own pleasure. Ok?"
    new "همه چیزی که باید انجام بدی اینه که روی لذت خودت تمرکز کنی. خوب؟"

    # say L1865 whi
    old "Good, then I'll tell [pla] to come in."
    new "خوب، بعدش به [pla] می‌گم بیاد داخل."

    # say L1867 whi
    old "Hey [pla]! You can come in now honey!"
    new "هی ز[pla]! حالا می‌تونی بیادون عزیزم!"

    # say L1874 pla
    old "H- hi Mrs. Jade..."
    new "ه- هی خانم جد..."

    # say L1875 jad
    old "H- hi [pla]."
    new "ه- هی ز[pla]"

    # say L1876 whi
    old "Oh! What is this tension? You have to loosen up!"
    new "اوه! این تنش چیه؟ باید آرام‌تر بشی!"

    # say L1877 whi
    old "Well, I think this might help a little."
    new "خب، فکر کنم این کمی کمک کنه."

    # say L1881 whi
    old "Look at that, isn't that just an amazing dick?"
    new "نگاه کن، آیا این نیم‌شاخه‌ای شگفت‌انگیز نیست؟"

    # say L1882 whi
    old "I bet he's even bigger than you remember isn't Jade?"
    new "مطمئنم بزرگتر از همین که به یاد داشتی هست، نیست جید؟"

    # say L1883 jad
    old "W- well..."
    new "خوب..."

    # say L1884 whi
    old "And it's so thick, hot, and hard..."
    new "و اونقدر ضخیم، گرم و سخت است..."

    # say L1894 whi
    old "Hmph, slrrrrp!"
    new "همف، لرز لرز لرز!"

    # say L1895 whi
    old "My God [pla] you really have the best tasting dick in the world."
    new "الهی [pla] شما واقعاً بهترین خروجی لذت‌بخش جهان هست."

    # say L1896 whi
    old "It's so great!"
    new "اینقدر عالیه!"

    # say L1897 whi
    old "I could suck it all day!"
    new "من می‌تونم همه روز از اون لذت ببرم!"

    # say L1898 whi
    old "I bet you want to have a taste too, don't you Jade?"
    new "حتماً می‌خوای خودت هم چشمند شی، نه جید؟"

    # say L1899 whi
    old "It's great, believe me!"
    new "عالی است، باور کن!"

    # say L1900 whi
    old "But he's mine first!"
    new "ولی اول من هستم!"

    # say L1910 whi
    old "I hope this has helped you take some tension off."
    new "امیدوارم این به شما کمک کرده باشه تنش رو کم کنه."

    # say L1911 whi
    old "Now that we've broken the ice, you can do it at her house."
    new "البته، حالا که یخشو شکستیم، می‌تونی این کار رو توی خونه‌اش انجام بدی."

    # say L1915 whi
    old "Oh come on, Is that a problem?"
    new "آهای بیا، این مشکلی نیست؟"

    # say L1917 whi
    old "Come on, you both enjoyed it and it's a win win."
    new "بیای، هر دو لذت برده و این برای همه خوب است."

    # say L1920 whi
    old "You [pla], did you like to had your dick sucked by a hot MILF as Jade?"
    new "آقای [pla]، آیا لذت برداشتی که یک مادر خانواده گرم مثل جید به سر می‌آورد؟"

    # say L1922 pla
    old "Uhh, y- yes..."
    new "اوه، ب- بله..."

    # say L1923 whi
    old "And you Jade? Did you enjoyed with a real big cock in your mouth?"
    new "و تو جید؟ آیا لذت برداشتی وقتی یک پیپی واقعاً بزرگ تو دهانت بود؟"

    # say L1925 whi
    old "Well that's it, enjoy it together and don't make a fuss about it."
    new "خب اینجاست، همراه هم لذت ببرید و درباره‌ش زیاد خیال نکنید."

    # say L1926 whi
    old "Sadly, I won't be able to be there with you guys every time you fool around, but Jade still needs some stress relief."
    new "متأسفانه نمی‌تونم هر بار که شماها با هم بازی می‌کنید با شما هستم، اما جید هنوز به یک راه برای رفع استرس نیاز داره."

    # say L1927 whi
    old "So, I trust that you'll give it to her whenever she needs it."
    new "پس امیدوارم هر وقت نیاز داشت بهش بدهی."

    # say L1930 whi
    old "Now, Mike's about to come home, so, sadly we'll have to see each other again another time."
    new "الان مایک قراره به خونه برگرده، پس متاسفانه باید دوباره هم به هم برسیم."

    # say L1931 whi
    old "But I've enjoyed a lot this little meeting."
    new "اما این ملاقات کوچک خیلی لذت‌بخش بود."

    # say L1932 pla
    old "I guess I have to get going too."
    new "باید من هم بروم"

    # say L1934 jad
    old "Y- yeah, uhh, me too. But before we leave."
    new "بله، اوه، من هم برم. اما قبل از رفتن."

    # say L1937 jad
    old "Uhh... T- thank you [pla]."
    new "اوه... ممنون [pla]."

    # say L1939 pla
    old "Uhmm... Sure, no problem."
    new "اوه... البته، مشکلی نداره."

    # say L1940 pla
    old "I'm happy I'm able to help you Mrs. Jade."
    new "خوشحالم که می‌تونم بهت کمک کنم خانم جید."

    # say L1941 whi
    old "That's great, alright, see you later guys."
    new "خوب، خوشحالم، ببینیم بعداً چطور هستید."

    # say L1958 jad
    old "Wow, that was nice, isn't it?"
    new "واو، این خوب بود، هستش؟"

    # say L1959 pla
    old "Phew, I wasn't expecting that to be honest.."
    new "پوف، صداقت بگم، این را منتظر نبودم."

    # say L1960 jad
    old "Heh, well, I figured that if I was going to do it, I should just go ahead and try."
    new "هه، بله، فکر کردم اگه قراره این کار رو بکنم، باید همین الان امتحانش کنم."

    # say L1961 jad
    old "I'm glad you did seem to enjoy it."
    new "خوشحالم که به نظر می‌رسه لذت برده‌ای."

    # say L1963 jad
    old "I've been thinking a lot about what Mrs. White said, and..."
    new "من خیلی فکر کردم در مورد آنچه مسز وایت گفت و..."

    # say L1964 jad
    old "I think she's right, I need to relax a bit more."
    new "من فکر می‌کنم درست می‌گه، باید کمی آرام‌تر باشم."

    # say L1965 jad
    old "So, I'm happy I took the leap."
    new "پس خوشحالم که این قدم رو زدم."

    # say L1967 pla
    old "Well, I'm happy I can be of help to you."
    new "خوشحالم که می‌تونم بهت کمک کنم."

    # say L1968 jad
    old "You're a lot more than that honey."
    new "تو خیلی بیشتر از این هستی عزیزم."

    # say L1969 jad
    old "About what just happened, you can think of it as your reward for all of the hard work you've been doing lately."
    new "در مورد اونی که اتفاق افتاد، می‌تونی بهش بعنوان جایزه‌ای برای تمام کار سختی که اخیراً انجام دادی، نگاه کنی."

    # say L1971 jad
    old "Well, now, if you'll excuse me, I think I'll lay down for a bit, honey."
    new "خب، اگر اجازه بدی، فکر کنم یه کم بخوابم، عزیزم."

    # say L1972 pla
    old "Sure, I'll see you later."
    new "بله، بعداً می‌بینیم."

    # say L1973 jad
    old "Sure, good bye."
    new "البته، خداحافظ."

    # say L1982 pla
    old "I can't believe that actually happened."
    new "باورم نمی‌شه که واقعاً اینجوری پیش اومده."

    # say L1983 pla
    old "Oh God, how do I always get into this."
    new "اوه خدا، چطور همیشه من اینجوری وارد این موقعیت‌ها می‌شوم."

    # say L2001 pla
    old "Hi? Mrs. Jade? Hinn? I came to work in the bathroom!"
    new "سلام؟ خانم جد؟ هین؟ من برای کار به دوربین آمدیم!"

    # say L2002 pla
    old "Mrs. Jade?"
    new "خانم جید؟"

    # say L2012 pla
    old "Uhh, This feels like Deja Vu..."
    new "اوه، این مثل دیده‌ی قدیمیه..."

    # say L2013 pla
    old "Hmm, I don't like where this is going..."
    new "Hmm، نمی‌تونم جایی که اینجوری می‌ره رو خوشم بیاد..."

    # say L2022 pla
    old "O- oh! Mrs. Jade, Mrs. White, you're here... Hi."
    new "ا- اوه! خانم جد، خانم وایت، شما اینجا هستید... سلام."

    # say L2024 jad
    old "Nevermind that [pla], we've been waiting for you."
    new "با این همه اشتباهی نیست [pla]، ما منتظرت بودیم."

    # say L2025 pla
    old "W- waiting?"
    new "پ- پیش زد؟"

    # say L2026 whi
    old "Well sweetie, Jade was thinking maybe it was time to get drilled by your huge cock."
    new "خب عزیزم، جد فکر می‌کرد شاید وقت آن هست که با ناخن بزرگت خورده بشی."

    # say L2027 pla
    old "... (Holly Shit...)"
    new "هالی شیت..."

    # say L2028 whi
    old "So, I thought I should be here to give her a little nudge forward."
    new "پس فکر کردم باید اینجا باشم تا به او کمی سوی پیش برسم."

    # say L2030 jad
    old "Now honey, don't just stand there looking lost."
    new "حالا عزیزم، نباید فقط اینجا بایستی باشی و گم شده به نظر بیایی."

    # say L2031 whi
    old "Come here and fuck us [pla]!"
    new "اونجا بیا و ما رو بکن [pla]!"

    # say L2046 whi
    old "Ok, I'm glad I was able to be of help to you Jade."
    new "خوب، خوشحالم که بتونستم بهت کمک کنم جید."

    # say L2047 whi
    old "I suppose the next time you two won't need my assistance."
    new "بگویم بعد از همه این‌ها، بار بعد شما دو نفر احتمالاً نیازی به کمک من ندارید."

    # say L2048 whi
    old "But, don't be selfish, you can always invite me to spend a sexy afternoon like today."
    new "اما، خودت را خودخواهان نکن، همیشه می‌تونی دعوت کنی من رو برای گذراندن یک بامداد جنسی مثل امروز."

    # say L2049 jad
    old "For sure I will."
    new "حتماً."

    # say L2050 whi
    old "Nice! So, I guess it's ok if I leave for now."
    new "خوب! پس فکر کنم می‌تونم حالا برسم."

    # say L2051 jad
    old "Ok, but again, thank you so much for all your help."
    new "باشه، ولی دوباره ممنون از همه کمکت."

    # say L2052 jad
    old "You were completely right about everything."
    new "تو کاملاً درست می‌گفتی در مورد همه چیز."

    # say L2053 whi
    old "Well, I'm always right, girl, you know that."
    new "خب، من همیشه درست می‌گم، دختر، این رو می‌دونی."

    # say L2054 whi
    old "I'll be seeing you later [pla]."
    new "بعداً می‌بینیم هم [pla]."

    # say L2060 jad
    old "Well, I guess it's too late for you to work on the bathroom now."
    new "خب، فکر کنم الان برای تعمیرات حمام کمی دیره."

    # say L2061 jad
    old "And you must be very tired anyway, so, I suppose we'll see each other another time."
    new "و باید خسته باشی، پس فکر کنم دیگه وقتی دیگه هم می‌بینیم."

    # say L2062 pla
    old "Yeah, don't worry. I'll be back soon..."
    new "بله، نگران نباش. زودی بر می‌گردم..."

    # say L2063 pla
    old "See you later Mrs. Jade."
    new "به بعد می‌بینیم خانم جد."

    # say L2064 jad
    old "See you later honey."
    new "تا بعداً عزیزم."

    # say L2078 pla
    old "Ok! That's it! I think I'm done!"
    new "خب! فکر کنم تمام شده!"

    # say L2079 pla
    old "Finally."
    new "نهایتاً."

    # say L2080 pla
    old "I think I should go tell Mrs. Jade."
    new "باید بروم به خانم جد بگم."

    # say L2088 pla
    old "Alright Mrs. Jade, I finished fixing the shower."
    new "باشه خانم جد، شور آب رو تعمیر کردم."

    # say L2090 pla
    old "You can now use it as before, it should be completely fine."
    new "البته، حالا می‌تونی مثل قبل ازش استفاده کنی، باید کاملاً خوب باشه."

    # say L2091 jad
    old "Really? That's very good."
    new "وای، خیلی خوبه."

    # say L2092 pla
    old "Yeah, why don't you come with me so you can see it?"
    new "بله، چرا نمی‌آیی با من تا ببینی؟"

    # say L2102 pla
    old "You see? It's fine now."
    new "دیدی؟ حالا خوبه."

    # say L2104 jad
    old "Thanks great! Thank you so much [pla]!"
    new "ممنون، خیلی ممنون [pla]!"

    # say L2108 pla
    old "W- what? What are you doing Mrs. Jade?"
    new "و- وای، خانم جد، شما چه کاری انجام می‌دهید؟"

    # say L2111 jad
    old "Well, since the shower's now working, I figured I should give it a try, don't you think?"
    new "خب، از آنجا که دوش بر اینجا کار می‌کنه، فکر کردم باید امتحانش بکنم، نه؟"

    # say L2113 jad
    old "And since you've been working so hard, you should also try it, so you can relax a little bit after all of that hard work."
    new "و چون تو خیلی سخت کار کردی، باید این فرصت رو برای آرامیدن استفاده کنی، بعد از همه اون کار سخت."

    # say L2114 jad
    old "So, now you and I are going to take a shower together."
    new "پس حالا تو و من هم باید دوش بگیریم."

    # say L2115 jad
    old "Now take off your clothes and get in the shower [pla]."
    new "حالا لباسات رو ببرو و بیا توی دوش [pla]."

    # say L2128 jad
    old "Ok, honey, I guess that's it with the bathroom."
    new "باشه، عزیزم، فکر کنم اینجاست کار توالت."

    # say L2129 jad
    old "Thanks a lot for what you did."
    new "ممنون از همه چیزی که برایم انجام دادی."

    # say L2130 jad
    old "I don't know how much it would've cost to fix it if I had contacted a plumber."
    new "نمی‌دونم چقدر هزینه می‌کرد اگه یه آبکاری تماس می‌گرفتم."

    # say L2131 pla
    old "No problem Mrs. Jade, I'm happy to help."
    new "خوشحالم که کمک کردم، خانم جید."

    # say L2132 jad
    old "Oh, you did a lot more than that."
    new "اوه، تو خیلی بیشتر از اون کار کردی."

    # say L2133 jad
    old "And I hope you know I expect to see you around here soon."
    new "و امیدوارم بدانی که منتظرم هستم تا زودی دوباره بیایی."

    # say L2134 jad
    old "Please remember to come and pay me a visit once in a while."
    new "لطفاً به یاد داشته باش که گاهی‌ها بیای و منو دیدن."

    # say L2135 jad
    old "I know you'll enjoy it."
    new "میدونم لذت می‌بری."

    # say L2136 pla
    old "Sure, I'll come by soon."
    new "بله، زودی می‌آم."

    # say L2137 jad
    old "That's good honey, very good."
    new "خوبه عزیزم، خیلی خوبه."

    # say L2138 jad
    old "I suppose you have to go?"
    new "باید بری؟"

    # say L2140 pla
    old "Yeah, it's a little bit late, and I'm really tired..."
    new "بله، وقت شده کمی دیره و من واقعاً خسته‌ام..."

    # say L2141 jad
    old "Oh yeah, honey, you deserve a good rest."
    new "اوه بله، عزیزم، تو به یک خواب خوب نیاز داری."

    # say L2142 pla
    old "Yeah, I will sleep like a baby tonight."
    new "بله، امشب مثل بچه خواهم خوابید."

    # say L2144 pla
    old "Alright, have a good night Mrs. Jade."
    new "باش خوب، شب خوبی بذار مس جد."

    # say L2145 jad
    old "Have a good night, honey."
    new "شب خوبی ببری، عزیزم."

    # say L2162 pla
    old "Oh, hi Hinn."
    new "اوه، سلام هین."

    # say L2163 pla
    old "How are you? How have your extra classes been going?"
    new "چطوری؟ درس‌های اضافیت چطور می‌رسونی؟"

    # say L2166 hin
    old "Hey, I wanted to thank you for all the hard work you did at my house with fixing the shower and stuff."
    new "بله، می‌خواستم ازت تشکر کنم برای همه تلاشت که در خانه‌ام با دوش و چیزهای دیگه کردی."

    # say L2168 pla
    old "Oh, my pleasure. I'm glad I was able to help you."
    new "اوه، لذت من بود. خوشحالم که بتونستم به تو کمک کنم."

    # say L2169 hin
    old "Yeah well, I still wanted to thank you personally, because I bet my mom didn't even say thank you, did she?"
    new "بله، ولی هنوز می‌خواستم شخصاً ازت تشکر کنم، چون مطمئن هستم مامان حتی نگفت ممنون، نه؟"

    # say L2170 pla
    old "Uhh... She did, she did."
    new "اوه... نه، نه."

    # say L2171 pla
    old "She was actually very, very grateful."
    new "او در واقع خیلی، خیلی ممنون بود."

    # say L2173 hin
    old "She was? Well, that's a surprise."
    new "او بود؟ خب، این مفاجا است."

    # say L2174 hin
    old "I'm glad she did."
    new "خوشحالم که اینجوری شد."

    # say L2175 hin
    old "But don't think I forgot to give you my own thank you."
    new "اما فکر نکن من فراموش کردم ازت تشکر کنم."

    # say L2177 hin
    old "I'll be busy a couple more days with my extracurricular activities."
    new "چند روز دیگه مشغله‌ام با فعالیت‌های اضافی‌ام هست."

    # say L2178 hin
    old "But as soon as I'm free I'll give you something to really say thanks."
    new "اما همینطور که آزاد شدم، چیزی برای واقعاً تشکر ازت می‌دهم."

    # say L2179 hin
    old "Well, I don't have much more time, so, I have to leave, see you later [pla]."
    new "خب، وقت زیادی ندارم، پس باید برسم، بعداً می‌بینیم [pla]."

    # say L2191 hin
    old "By the way, I almost forgot to tell you. "
    new "باید به تو بگم چیزی رو هم فراموش کردم."

    # say L2192 hin
    old "My mom asked me to tell you that there are a couple more things in the house that need fixing."
    new "مادرم از من پرسید که چند چیز دیگه توی خونه نیاز به تعمیر داره."

    # say L2193 hin
    old "And wanted to know if you could come and help us with that."
    new "و می‌خواست بدونه اگه می‌تونی بیاد و به ما کمک کنی."

    # say L2194 hin
    old "Which is terrible of her to ask after all you already did. So, if you can't do it just tell me and I'll set her straight."
    new "این برایت خیلی دردسر است، پس اگر نمی‌توانی انجام بدی فقط به من بگو تا من مامانم رو راست بگذارم."

    # say L2195 pla
    old "Uhh, yeah, actually it's fine, I kinda have an idea of what she wants me to do, so, don't worry, it's fine."
    new "اوه، بله، در واقع خوبه، من نوعی ایده‌ای دارم که می‌خواد از من چه کاری بکنم، پس نگران نباش، خوبه."

    # say L2196 hin
    old "It is? Well, I'm glad it doesn't bother you."
    new "اینطوره؟ خب، خوشحالم که این برایت مشکل نمی‌سازه."

    # say L2197 hin
    old "Thanks a lot [pla], I'll see you later."
    new "ممنون [pla]، بعداً می‌بینیم."

    # say L2216 pla
    old "Hi Mrs. Jade."
    new "سلام خانم جد."

    # say L2217 jad
    old "Hi honey, tell me, do you need anything?"
    new "سلام عزیزم، بگو ببینم، نیازت به چیه؟"

    # say L2222 pla
    old "I should find a therapist first."
    new "اول باید یک روان‌شناس پیدا کنم."

    # say L2234 jad
    old "Hey [pla], don't you have to be at school?"
    new "هی [pla]، نباید تو مدرسه باشی؟"

    # say L2236 pla
    old "Right, I was just looking for Hinn."
    new "درسته، فقط داشتم جای هین رو می‌خوندم."

    # say L2238 jad
    old "Hinn? She is already at school... Don't be late, [pla]... "
    new "هین؟ او قبلاً به مدرسه رفته... نباشی دیر، [pla]..."

    # say L2240 pla
    old "You're right. Sorry. I better go now..."
    new "درست می‌گی‌ی. ببخشید. بهتره حالا برسم..."

    # say L2242 jad
    old "...(Hmm.)"
    new "( Hmm. )"

    # say L2276 jad
    old "What? But right now it's school time!"
    new "چه کاری؟ اما الان وقت مدرسه هست!"

    # say L2277 jad
    old "It's very sweet of you to come here to help, but I don't want you missing any classes because of me."
    new "خیلی شیرین ازت هست که اینجا بیایی کمک کنی، ولی نمی‌خوام به خاطر من هیچ کلاسی رو ببری."

    # say L2278 jad
    old "You should go to school, I'll be here in the afternoon, so you can come and do the bathroom then."
    new "باید به مدرسه بروی، من بعد از ظهر اینجا خواهم بود، پس می‌تونی بعداً بیاد و کارتو در حمام انجام بدی."

    # say L2279 pla
    old "Yeah, I think you're right."
    new "بله، فکر کنم درست هستی."

    # say L2280 pla
    old "I'll come here later then."
    new "بعداً می‌آیم."


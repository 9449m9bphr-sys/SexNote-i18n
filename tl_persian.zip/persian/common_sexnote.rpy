# SexNote persian — Qwen2.5-72B AWQ context ±2 + logic review (Farsi RTL)
# Do not edit English sources
# Format: translate persian strings:  (old/new) — required for Ren'Py overlay
# Display: config.rtl=True in 000_sexnote_language.rpy; store LOGICAL order here.
# Font: SEXNOTE_FONT_FA

translate persian strings:

    old "History"
    new "تاریخچه"

    old "Auto"
    new "خودکار"

    old "Save"
    new "ذخیره"

    old "Q.Save"
    new "ذ.سریع"

    old "Q.Load"
    new "ب.سریع"

    old "Prefs"
    new "تنظیمات"

    old "Start"
    new "شروع"

    old "Load"
    new "بارگذاری"

    old "Preferences"
    new "تنظیمات"

    old "Gallery"
    new "گالری"

    old "End Replay"
    new "پایان بازپخش"

    old "Main Menu"
    new "منوی اصلی"

    old "About"
    new "درباره"

    old "Help"
    new "راهنما"

    old "Quit"
    new "خروج"

    old "Return"
    new "بازگشت"

    old "Version [config.version!t]"
    new "نسخه [config.version!t]"

    old "If you liked and want to support us and check the new updates:"
    new "اگر دوست داشتی و می‌خواهی ما رو حمایت کنی و آپدیت‌های جدید رو ببینی:"

    old "{size=+10}{color=#a6ecff}{b}THANKS TO OURS PATRONS!:{/b}{/color}{/size}"
    new "{size=+10}{color=#a6ecff}{b}ممنون از حامیان ما:{/b}{/color}{/size}"

    old "{color=#16a5cc}{b}Wizards:{/b}{/color}#, A AA, A Guy named Stefan, aaron strunk, Adarran, Adesh Korada, Alduin Thuri, Alex, Alex Lee, Alexander Lopez, Andrew Alexander, Andrew steffen, andrew tozer, anon, Anthony, Arsene, Arthur Coudert, avekfh, Avery Darby, Avman72, BeerBellyBro, Ben Fraser, Berry, Blacklight0425, Blubber Duck, BohemianRabbit, Branchman41, Braulio Gallegos-Gonzalez, Brian Jones, C Aagesen, Caleb Grant, Caleb Robertsjones, Carlos G Diaz, Catelusul Ham Ham, Chance Medlin, Chance Rodriguez, Chaotic Zaros, Chazardzard, Chephyy, Christopher, Cody Knochelmann, Collin Shields, CurseKeem, Dagger, Damonte Ransey, Darius Patton, Darrius Wade, Derrick Johnson, Dino Torres, Dj Happg, DJNipTwist, Doc Pan As, Doc854, Doctor Giraffe, dragon hunter, Draven x, El Rando Salvo, Elias, Elias Ritter, Emmanuel Abel, Eric, Ethan, Ethan Blessemaille, Fjallar Otterson, Franklin Snyder, Fredrik, Gaming Account, Gareth Whitlow, Geoff, Gin, Grimm, Halic1108, Harry Hunsberger, Harvey Mountford, Herb665, ingerbr, iron Kill, Isaiah Coleman, Isaiah Pacheco, Iseedeadllamas, Ivan Flores, Jack Fair, jackson lynch, James, jayden weatherford, Jesus Fregozo, Jetendra Lalchan, Joe Gehling, Joel Harper, John Fugate, John T, Johnathan Balfour, Jordan L, Jorgito Breton, Joseph P Hawley, Joseph Righter, Josh Dischinger, junangulas, Justin, Justin Smith, Justin Spahn, JustThatGuy, KaiserRob, kazuo kenshin, ken smith, Kieran Coles, lmninja64, Logan Cooper, Lord Eagle, Lucas Hogh-Janovsky, MajehEX, Marco Scherer, matt congrove, Matt Richardson, Matthew Ober, Maxx, Mickel Rateliff, MLordBoss97, mole man, Mungan, Nathan Cochran, NerdyCaveman, Nick Moore, Nobody, NU, OffbeatLemon137, Omar, Omnibreed001, ouweseun, Patricio Pulgar, Patrick Bertin, Patrick Tanner, philip carter, Pierson trueblood, PutasBoy, Quinton Woods, R4ttenf4enger, Rail Meiko, Ray Smith, Rey Mitchell, Richard Roche, Rick Stout, Rob Banks, Rob Willard, Robert Duplessis, Roul Druck, Rust, RwEd ForTheWin, Saggy Sauce, Samic, ScarlettAurora, Shane Antonacci, SpookyMan, ssbn571 ., Stoven, Tena Fich, Thana.N.Ye, TheLoneKek, Thereader, Titan91, Toot Poot, Tummetott, Tyren Gray, UUVG, Victor Saganoff, Wezz, William, Willim Ortega, Yang Eric, zac, Zlaire Asberry, عبدالعزيز وارد, ・ひで・, 恭郡 何, 김종근 김, "
    new "{color=#16a5cc}{b}Wizards:{/b}{/color}#، A AA، A Guy named Stefan، aaron strunk، Adarran، Adesh Korada، Alduin Thuri، Alex، Alex Lee، Alexander Lopez، Andrew Alexander، Andrew steffen، andrew tozer، anon، Anthony، Arsene، Arthur Coudert، avekfh، Avery Darby، Avman72، BeerBellyBro، Ben Fraser، Berry، Blacklight0425، Blubber Duck، BohemianRabbit، Branchman41، Braulio Gallegos-Gonzalez، Brian Jones، C Aagesen، Caleb Grant، Caleb Robertsjones، Carlos G Diaz، Catelusul Ham Ham، Chance Medlin، Chance Rodriguez، Chaotic Zaros، Chazardzard، Chephyy، Christopher، Cody Knochelmann، Collin Shields، CurseKeem، Dagger، Damonte Ransey، Darius Patton، Darrius Wade، Derrick Johnson، Dino Torres، Dj Happg، DJNipTwist، Doc Pan As، Doc854، Doctor Giraffe، dragon hunter، Draven x، El Rando Salvo، Elias، Elias Ritter، Emmanuel Abel، Eric، Ethan، Ethan Blessemaille، Fj"

    old "{color=#16a5cc}{b}Conjurers:{/b}{/color} Andrea, anthony, bophades96, Caboose-1, Christopher Martin, Corbin Hubble, Curtis S, Death Angel, Deiondre Tracey, Dick, DRatt7288, EmbraceAbundance, Erik Piehl, Fabio Giusti, Flame S0lider, Florian Game, goonmaster6969, Henry Coleman, Indy Duffy, Jace Tangler, james jordan, Jan Tallardt, Jim Max, John Tyler, Keith Alexander, Kevin, Kuba Kluszczynski, Lauritsbb, Lhurlu, loiq fortin, Lurtz111, Manna Moth, marc witten, mark rodriguez, Matisse Vobaure, Matthew Myers, Max, michael finch, miloarty, Murphy Wakefield, Nathaniel Brooks, Nova, Oz, Paris, Petzy33, Pimmel Warze, PrDauny21, Ramz, Raptor2283, Ronnie S, , SAITAMA CAPA, Scott Liebenow, Sebastian Lopez, SetforDark, Shadow Blackheart, SkullKidDanzen, Sou11ess19, sumu black, Tapelesslion Gaming, Tobias, Tom Schubert, torsten kristensen, Tyler M., uchihazelda, ViolentBone, Whyze, William Walker, บิ มา กายโรสแมรี่."
    new "{color=#16a5cc}{b}ساحران:{/b}{/color} آندره، انتونی، بوفادس96، کابوس-1، کریستوفر مارتین، کوربین هابل، کرتیس سی، دث آنجل، دئوندرا تریسی، دیک، درات7288، امbraceآبundance، اریک پیل، فابیو جیوستی، فلیم سولدر، فلوریان گیم، گونمستر6969، هنری کولمن، ایندی دافی، جیس تانگلر، جیمز جردن، یان تالاردت، جیم ماکس، جان تایلر، کیث الکساندر، کوین، کوبا کلوشچینسکی، لوریتسبی، لهرلو، لویک فورتن، لرتز111، مانا موث، مارک ویتن، مارک رودریگز، ماتیس ووبور"

    old "Page {}"
    new "صفحه {}"

    old "Automatic saves"
    new "ذخیره خودکار"

    old "Quick saves"
    new "ذخیره سریع"

    old "empty slot"
    new "سلول خالی"

    old "Display"
    new "نمایش"

    old "Window"
    new "پنجره"

    old "Fullscreen"
    new "تمام‌صفحه"

    old "Rollback Side"
    new "بازگشت جانبی"

    old "Disable"
    new "غیرفعال کن"

    old "Left"
    new "چپ"

    old "Right"
    new "راست"

    old "Unseen Text"
    new "متن نامعلوم"

    old "After Choices"
    new "بعد از انتخاب‌ها"

    old "Transitions"
    new "انتقال‌ها"

    old "Language"
    new "زبان"

    old "English"
    new "انگلیسی"

    old "Text Speed"
    new "سرعت متن"

    old "Auto-Forward Time"
    new "زمان خودکار پیش‌برد"

    old "Music Volume"
    new "صدای موسیقی"

    old "Sound Volume"
    new "صدای جلوه‌ها"

    old "Test"
    new "آزمایش"

    old "Voice Volume"
    new "صدای گفتار"

    old "Mute All"
    new "صدا رو خاموش کن"

    old "The dialogue history is empty."
    new "تاریخ گفتگو خالی است"

    old "Keyboard"
    new "کیبورد"

    old "Mouse"
    new "ماوس"

    old "Gamepad"
    new "کنترلر"

    old "Enter"
    new "وارد شدن"

    old "Advances dialogue and activates the interface."
    new "پیشبر گفتگو و فعال کردن رابطه کاربری"

    old "Space"
    new "فضای بازی را پیش برود بدون انتخاب گزینه‌ها."

    old "Advances dialogue without selecting choices."
    new "پیشبر گفتگو بدون انتخاب گزینه‌ها"

    old "Arrow Keys"
    new "پیکان‌ها"

    old "Navigate the interface."
    new "در رابط کار کن."

    old "Escape"
    new "خروج"

    old "Accesses the game menu."
    new "منوی بازی را باز می‌کنم"

    old "Ctrl"
    new "کنترل"

    old "Skips dialogue while held down."
    new "حاکم بر پرش حرف زدن در هنگام نگه‌داشتن"

    old "Tab"
    new "تب"

    old "Toggles dialogue skipping."
    new "پرش حرف زدن را فعال/غیرفعال می‌کند"

    old "Page Up"
    new "صفحه بالا"

    old "Rolls back to earlier dialogue."
    new "بازگشت به گفتگوهای اولی"

    old "Page Down"
    new "صفحه رو به جلو ببر"

    old "Rolls forward to later dialogue."
    new "به جلو برود به گفتگوهای بعدی"

    old "Hides the user interface."
    new "UI را مخفی می‌کنم"

    old "Takes a screenshot."
    new "تصویر اسکرین ببرد"

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "اسیستان را فعال/غیرفعال کن {a=https://www.renpy.org/l/voicing}خودخوان {/a}"

    old "Left Click"
    new "کلیک چپ"

    old "Middle Click"
    new "کلیک میانی"

    old "Right Click"
    new "کلیک راست"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "چرخه موس رو بالا بریز"

    old "Mouse Wheel Down"
    new "چرخه موس رو پایین ببر"

    old "Right Trigger\nA/Bottom Button"
    new "دکمه راست"

    old "Left Trigger\nLeft Shoulder"
    new "ترگر چپ، شانه چپ"

    old "Right Shoulder"
    new "شانه راست"

    old "D-Pad, Sticks"
    new "د-پد، استیک‌ها"

    old "Start, Guide"
    new "شروع، راهنما"

    old "Y/Top Button"
    new "Y/دکمه بالایی"

    old "Calibrate"
    new "کالیبر کن"

    old "Skipping"
    new "پرش کردم"

    old "Menu"
    new "منو"

    old "Mrs Mia"
    new "خانم میا"

    old "Developer"
    new "توسعه‌دهنده"


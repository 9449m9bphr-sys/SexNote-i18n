# SexNote auto bootstrap — chinese
init python:
    try:
        renpy.config.known_languages.add("chinese")
    except Exception:
        pass

translate chinese python:
    gui.text_font = SEXNOTE_FONT_SC
    gui.name_text_font = SEXNOTE_FONT_SC
    gui.interface_text_font = SEXNOTE_FONT_SC
    gui.button_text_font = SEXNOTE_FONT_SC
    gui.choice_button_text_font = SEXNOTE_FONT_SC
    _sn_say_size = 30 if renpy.variant("small") else 34
    gui.text_size = _sn_say_size
    gui.textbox_height = 400 if renpy.variant("small") else 340
    style.say_dialogue.line_spacing = 6
    style.say_dialogue.size = _sn_say_size

translate chinese style say_dialogue:
    layout "subtitle"
    font SEXNOTE_FONT_SC

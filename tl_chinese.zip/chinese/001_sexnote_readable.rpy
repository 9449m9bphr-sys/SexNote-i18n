translate chinese style say_dialogue:
    line_spacing 6
    outlines [ (2, "#000000B0", 0, 0) ]

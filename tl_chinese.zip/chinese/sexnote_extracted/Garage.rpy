# auto-tl Qwen Colab

translate chinese chinese_3256651_0:
    old "Hello. I just came to know if you need more magic power?"
    new "喂，我只是来看看你是否需要更多的魔法力量？"

translate chinese chinese_1362500_1:
    old "I think I have enough. Thank you..."
    new "我觉得够了。谢谢你..."

translate chinese chinese_8987454_2:
    old "Oh come on. In our deal you were supposed to receive magical power from me, so don't worry."
    new "哦，别这样了。按照我们的约定，你应该从我这里获得魔法力量，所以不用担心。"

translate chinese chinese_5986360_3:
    old "Hmm, okay, I'll visit you tonight to get a little more magic."
    new "嗯，好吧，我今晚来找你再多要点魔法。"

translate chinese chinese_7565352_4:
    old "Great, it's good for us to help each other..."
    new "很好，互相帮助对我们有好处……"

translate chinese chinese_0533972_5:
    old "Ok, see you tonight."
    new "好的，今晚见。"

translate chinese chinese_6968102_6:
    old "Ask for Magic Power"
    new "询问魔力"

translate chinese chinese_9164075_7:
    old "Hello! I wanted to know if you have any magic power to share with me. You know, to keep improving my skills..."
    new "喂！我想知道你有没有什么魔法力量可以分享给我。你知道的，为了不断提升我的技能……"

translate chinese chinese_1147162_8:
    old "Well, if you really need it I have some magic power for you."
    new "好吧，如果你真的需要，我有一些魔法力量给你。"

translate chinese chinese_4082738_9:
    old "Thank you. I really appreciate it."
    new "谢谢你，真的非常感激。"

translate chinese chinese_2812346_10:
    old "Don't mention it. This was part of our deal"
    new "别提了。这本来就是我们的约定。"

translate chinese chinese_3019100_11:
    old "Ok, I'm ready. Let's do it."
    new "好了，我准备好了。咱们开始吧。"

translate chinese chinese_7700874_12:
    old "Alright, alright..."
    new "好吧，好吧……"

translate chinese chinese_4557536_13:
    old "Sorry, but I don't have enough to share for now..."
    new "对不起，我现在没什么可以分享的……"

translate chinese chinese_9287938_14:
    old "Oh ok. No problem. I will come later."
    new "哦，好的。没问题，我晚点再来。"

translate chinese chinese_4921389_15:
    old "Bye."
    new "再见。"

translate chinese chinese_4152742_16:
    old "Oh come on. In our deal you were supposed to get magical power from me, I'll take care of you."
    new "哦，别这样了。按照我们的约定，你应该从我这里获得魔法力量，我会照顾你的。"

translate chinese chinese_0341067_17:
    old "Mmm, okay. I'll visit you tonight to get a little more magic."
    new "嗯，好吧。我今晚过来再吸点魔力。"

translate chinese chinese_7048287_18:
    old "Great,I like helping you..."
    new "太好了，我喜欢帮助你……"

translate chinese chinese_2129189_19:
    old "Hello! I wanted to know if you have any magic power to share with me You know, to keep improving my skills..."
    new "喂！我想知道你有没有什么魔法力量可以分享给我，你知道的，为了不断提高我的技能……"

translate chinese chinese_9374419_20:
    old "Yes I have some magic power to give you."
    new "是的，我有一些魔力可以给你。"

translate chinese chinese_7014668_21:
    old "Oh, sweet. Thank you!"
    new "哦，太好了，谢谢！"

translate chinese chinese_6394889_22:
    old "No problem, your progress benefits us all"
    new "没问题，你的进步对我们所有人都有好处"

translate chinese chinese_4025042_23:
    old "Are you ready?."
    new "准备好了吗？"

translate chinese chinese_3079138_24:
    old "Yes! Let's get to it..."
    new "好！开始吧..."

translate chinese chinese_2063054_25:
    old "Oh, ok. No worries. I will come later."
    new "哦，好的。不用担心，我晚点再来。"

translate chinese chinese_9551901_26:
    old "Buh bye."
    new "拜拜。"

translate chinese chinese_2666249_27:
    old "Hi there, I just came to know if you need more magic power?"
    new "嗨，我只是来看看你是否需要更多的魔法力量？"

translate chinese chinese_3912582_28:
    old "Well, maybe I might need a little..."
    new "嗯，也许我需要一点点..."

translate chinese chinese_6965028_29:
    old "Great, in that case visit me tonight so I can give you some magical power..."
    new "好的，那今晚来我这，我给你一些魔力..."

translate chinese chinese_4182147_30:
    old "With pleasure! I'll see you tonight..."
    new "很乐意！今晚见..."

translate chinese chinese_4039470_31:
    old "Hey! I wanted to know if you have any magic power to share with me. I want to keep improving my skills..."
    new "喂！我想知道你有没有什么魔法力量可以分享给我。我想继续提升我的技能……"

translate chinese chinese_1387988_32:
    old "Of course! I have plenty to share with you."
    new "当然了！我有很多要和你分享的。"

translate chinese chinese_9862745_33:
    old "You can ask me whenever you want. Whenever I have enough I will give it to you..."
    new "你可以随时问我。等我够了就会给你……"

translate chinese chinese_6731564_34:
    old "Nice! Thank you."
    new "不错！谢谢。"

translate chinese chinese_2290208_35:
    old "Hmmm... Unfortunately, I don't have enough right now..."
    new "嗯……可惜我现在不够……"

translate chinese chinese_2150193_36:
    old "However, look for me in a couple of days and I will have accumulated more to give you..."
    new "不过，过几天再找我，我会积累更多东西给你……"

translate chinese chinese_9852829_37:
    old "Or... You could also share with me and I'll give it back to you, just for the fun of sharing... Hehe"
    new "或者……你可以先分享给我，然后我再还给你，就当是图个乐呵分享一下……嘿嘿"

translate chinese chinese_2605162_38:
    old "Oh, don't worry, it's really nothing urgent."
    new "哦，别担心，真的不急。"

translate chinese chinese_0901399_39:
    old "Oh... Ok then."
    new "哦……好吧。"

translate chinese chinese_0127258_40:
    old "Magic Power"
    new "魔法力量"

translate chinese chinese_9703995_41:
    old "What is the Magic Power?"
    new "什么是魔力？"

translate chinese chinese_1562659_42:
    old "Well, Magical power is an energy that was produced naturally in the magical world..."
    new "好吧，魔法力量是在魔法世界中自然产生的能量……"

translate chinese chinese_8970735_43:
    old "After its destruction all that magical energy ended up in the human world, the problem is that now it does not reproduce anymore..."
    new "在它被摧毁后，所有的魔法能量都进入了人间界，问题是现在它不再再生了……"

translate chinese chinese_0946802_44:
    old "Only the remains of great magical sources, and all magical beings that once existed will be extinguished forever..."
    new "只剩下伟大的魔法源头的遗迹，所有曾经存在的魔法生物都将永远消失……"

translate chinese chinese_8555500_45:
    old "Ok, I understand it better now."
    new "好的，我现在明白多了。"

translate chinese chinese_9703609_46:
    old "Great! What else do you want to know?"
    new "太好了！你还想知道什么？"

translate chinese chinese_8007788_47:
    old "How to get Magic Power?"
    new "如何获得魔法力量？"

translate chinese chinese_4794671_48:
    old "You have in fact 4 ways..."
    new "你实际上有四种方法……"

translate chinese chinese_4227418_49:
    old "1. Picking up in each place with the agamoto's eye."
    new "1. 用阿戈多莫之眼在每个地方继续进行。"

translate chinese chinese_9354680_50:
    old "2. Using Ayax's hand and automatically picking up when moving between locations."
    new "2. 使用艾雅克的手，并在移动地点时自动拾取。"

translate chinese chinese_2029846_51:
    old "3. Having high levels of arousal caused by sexual activity with women."
    new "3. 与女性进行性活动引起的高度兴奋。"

translate chinese chinese_3072691_52:
    old "4. Ask me to share you with my magical power!"
    new "4. 让我分享我的魔法力量给你！"

translate chinese chinese_2730603_53:
    old "Ok, interesting..."
    new "好吧，挺有意思的……"

translate chinese chinese_2920565_54:
    old "My favorite is the last one, but only when you share with me yours too..."
    new "我最喜欢最后一个，但只有当你也告诉我你的时候才行……"

translate chinese chinese_2922134_55:
    old "Yes, I know..."
    new "是的，我知道……"

translate chinese chinese_6662240_56:
    old "Well, What else do you want to know?"
    new "那你还想知道什么？"

translate chinese chinese_1228202_57:
    old "Spells"
    new "法术"

translate chinese chinese_2219410_58:
    old "Agamoto's Eye"
    new "阿伽摩之眼"

translate chinese chinese_6922507_59:
    old "Agamoto was one of the most powerful magicians who specialized in ocular power."
    new "阿伽默托是专精于眼力的最强大的魔术师之一。"

translate chinese chinese_1560737_60:
    old "They say that his power even came to see the soul and thoughts of any being."
    new "他们说他的力量甚至能窥见任何生物的灵魂和思想。"

translate chinese chinese_5170172_61:
    old "That is why Agamoto is a power of vision that allows you to see the dimension of the magical world and see beyond the objects of the real world."
    new "这就是为什么阿加莫托之眼能让你除了看到魔法世界的维度之外，还能透视现实世界中的物体。"

translate chinese chinese_7915517_62:
    old "Wow Really?"
    new "真的吗？"

translate chinese chinese_2558666_63:
    old "Yes, you should try it, you could only see through easy things like clothes, try using it on someone to see through their clothes."
    new "是的，你应该试试，只能看到像衣服这样的简单东西，试着对别人用，看看穿在他们身上的衣服。"

translate chinese chinese_2779167_64:
    old "Ok ok, I'm going to try it..."
    new "好好吧，我试试看..."

translate chinese chinese_1121574_65:
    old "Ayax's Hand"
    new "艾雅克之手"

translate chinese chinese_4354989_66:
    old "Ayax was one of the greatest thief magicians in history."
    new "艾雅克斯是历史上最伟大的盗贼魔术师之一。"

translate chinese chinese_7884356_67:
    old "He reached the point of being able to turn his body into a magnet for valuables."
    new "他到了能把身体变成吸财磁铁的地步。"

translate chinese chinese_5322894_68:
    old "Ayax's hand is basically this power that he achieved, with which you can automatically attract the magical power of the area where you are."
    new "艾雅克斯的手基本上就是他所达到的能力，可以自动吸引所在区域的魔法力量。"

translate chinese chinese_4619119_69:
    old "Wow, interesting..."
    new "wow，真有趣..."

translate chinese chinese_7910219_70:
    old "What else do you want to know?"
    new "你还想知道什么？"

translate chinese chinese_8334837_71:
    old "Sauron's Mouth"
    new "索隆之口"

translate chinese chinese_7094108_72:
    old "Sauron was one of the greatest political influencers in the magical world."
    new "索伦是魔法世界中最具影响力的政客之一。"

translate chinese chinese_2668329_73:
    old "He managed to create a manipulative skill with his mouth with which he managed to influence everyone."
    new "他竟然用嘴巴搞出了一套操纵技巧，把所有人都影响了。"

translate chinese chinese_9111421_74:
    old "This is how the Sauron's Mouth was created, with it you can influence all kinds of beings..."
    new "这就是索伦之口的由来，有了它你可以影响各种生物..."

translate chinese chinese_0373150_75:
    old "Like some kind of mind control?"
    new "像是某种精神控制？"

translate chinese chinese_1002485_76:
    old "What? Of course not, it is more an ability to influence or manipulate at certain levels, not to control the behavior."
    new "什么？当然不是，这更多是一种在某些层面上的影响或操纵能力，而不是控制行为。"

translate chinese chinese_8469538_77:
    old "In fact, using it does not always work and you should improve it to the fullest and have a good relationship with who you use to increase your chances..."
    new "事实上，使用它并不总是有效，你应该尽可能地改进它，并与你使用的人建立良好的关系，以增加成功的机会……"

translate chinese chinese_1376051_78:
    old "Ok, ok, understood."
    new "好，好，知道了。"

translate chinese chinese_1356742_79:
    old "Jamliz's Heart"
    new "贾姆利兹之心"

translate chinese chinese_9545257_80:
    old "Jamliz sought for years to make a very powerful spell that he never achieved, since he always needed more magical power."
    new "贾姆利兹多年来一直在寻找一种非常强大的魔法，但他从未成功过，因为他总是需要更多的魔力。"

translate chinese chinese_0957662_81:
    old "But, what he achieved was to increase the ability to store magical power in unthinkable amounts."
    new "但是，他达到的效果是在难以想象的程度上增加了储存魔力的能力。"

translate chinese chinese_4211493_82:
    old "That's why the Jamliz's Heart is a skill that allows you to store more magical power in your body and thus make spells that require greater magical power."
    new "这就是为什么“贾姆利兹之心”这个技能能让你体内储存更多的魔法力量，从而施放需要更大魔法力量的法术。"

translate chinese chinese_3413287_83:
    old "Sounds pretty useful..."
    new "听起来挺有用的……"

translate chinese chinese_2107091_84:
    old "What I have to do?"
    new "我该做什么？"

translate chinese chinese_4633282_85:
    old "The first thing you should do is improve your skills to the fullest. So obviously, you must get magical power."
    new "你应该首先尽全力提升自己的技能。所以很明显，你必须获得魔法力量。"

translate chinese chinese_1684652_86:
    old "But your main mission is to restore the magical world and with this shortage of magical power the only way is for you to generate it for yourself..."
    new "但你的主要任务是恢复魔法世界，而在这个魔法力量短缺的情况下，唯一的方法就是你自己生成它..."

translate chinese chinese_6123573_87:
    old "So you should seek to reach the highest level of sexual arousal. Experimenting with different women and situations to see what is most exciting for you..."
    new "所以你应该追求最高的性兴奋程度。尝试不同的女人和情境，看看什么最能让你兴奋……"

translate chinese chinese_6953452_88:
    old "And have a lot of sex with many women to increase your power and gradually restore the power of the magical world!"
    new "然后和很多女人发生关系来提升你的力量，逐渐恢复魔法世界的力量！"

translate chinese chinese_7101636_89:
    old "You do know that is not that easy, right?"
    new "你该知道这没那么简单吧？"

translate chinese chinese_1826579_90:
    old "Don't worry. You can gradually acquire more skills that you can use in the real world to make things easier for you..."
    new "别担心。你可以逐渐掌握更多能在现实世界中使用的技能，让你的生活变得更轻松……"

translate chinese chinese_1332138_91:
    old "For now you can progress little by little with some women and see if you can get very horny!"
    new "现在你可以一点点地和一些女生进展，看看能不能让你非常兴奋！"

translate chinese chinese_4133531_92:
    old "Hmmm... Ok, I'll see how to do something about it."
    new "嗯……好吧，我会看看怎么处理。"

translate chinese chinese_4934806_93:
    old "I finally found you!"
    new "我终于找到你了！"

translate chinese chinese_6540089_94:
    old "WHAT DO YOU WANT FROM US?"
    new "你们想要我们怎么办？"

translate chinese chinese_9155480_95:
    old "I just want to talk..."
    new "我只是想谈谈..."

translate chinese chinese_3591952_96:
    old "Where is your shinigami friend?"
    new "你的死神朋友在哪里？"

translate chinese chinese_7486579_97:
    old "She is not here, I came alone... I just want to clarify that everything was a misunderstanding..."
    new "她不在这里，我是独自来的……我只是想澄清一切只是误会……"

translate chinese chinese_3349674_98:
    old "I did not destroy the magical world..."
    new "我没有摧毁魔法世界……"

translate chinese chinese_2445172_99:
    old "We know that, you didn't destroy the magical world..."
    new "我们知道，你并没有摧毁魔法世界……"

translate chinese chinese_3402244_100:
    old "That's right!, I didn't..."
    new "没错，我还没..."

translate chinese chinese_8928491_101:
    old "What? No... I think you are confused "
    new "什么？不……我觉得你搞错了"

translate chinese chinese_3542636_102:
    old "Kid, we are over 300 years old, and you how many? 18? We know all from the magical and human world. "
    new "孩子，我们已经三百多岁了，你呢？才18？我们魔法世界和人间的事情都知道。"

translate chinese chinese_9762520_103:
    old "But... Brixxida knows nothing about the destruction of the magical world..."
    new "但是……布里克西达对魔法世界的毁灭一无所知……"

translate chinese chinese_1423693_104:
    old "Doesn't know or doesn't want to tell you? Why do you think she needs you? "
    new "是不知道还是不想告诉你？你认为她为什么需要你？"

translate chinese chinese_6901452_105:
    old "To restore the magical world?"
    new "为了恢复魔法世界？"

translate chinese chinese_2672410_106:
    old "And if she wants to restore the magical world why is she alone? Why there are no more shinigamis with her, like us? "
    new "那如果她想恢复魔法世界，为什么她会一个人呢？为什么没有更多的死神像我们这样和她在一起？"

translate chinese chinese_3469584_107:
    old "Well, I don't know..."
    new "嗯，我不太知道……"

translate chinese chinese_6718883_108:
    old "Who you have by your side is probably one of the most powerful being in the universe and you don't know her real intentions, you must be very careful..."
    new "你身边的人可能是宇宙中最强大的存在之一，而你却不知道她的真正意图，你必须非常小心……"

translate chinese chinese_5731320_109:
    old "But she has only helped me..."
    new "但她只是帮助了我..."

translate chinese chinese_2240405_110:
    old "We don't know what she may want from you... But she was who destroy the magic world..."
    new "我们不知道她想从你这里得到什么……但她就是摧毁魔法世界的人……"

translate chinese chinese_9621566_111:
    old "And how do I know that it is not you who want to deceive me?"
    new "那我怎么知道不是你想骗我呢？"

translate chinese chinese_6827571_112:
    old "You don't have to believe us, we're not asking you anything, just let us try to survive, that's all..."
    new "你不用相信我们，我们也没要求你做什么，就让我们试试活下去而已……"

translate chinese chinese_3068627_113:
    old "Ok, I want to propose something to you, I will be in charge of sharing magical power to all of you."
    new "好的，我想向你们提议一件事，我将负责为大家分配魔力。"

translate chinese chinese_8255598_114:
    old "I mean, you can come and collect magic power from me so you won't disappear..."
    new "我的意思是，你可以来从我这里收集魔力，这样你就不会消失了……"

translate chinese chinese_9275424_115:
    old "Thank you, but we don't need it..."
    new "谢谢，但我们不需要……"

translate chinese chinese_7545351_116:
    old "Oh come on, I have the SexNote, I have several skills that have allowed me to collect magical power quickly and efficiently."
    new "哦拜托，我有SexNote，有几个技能让我能快速高效地收集魔法力量。"

translate chinese chinese_5677374_117:
    old "And... I can also generate magical power by myself..."
    new "而且……我还能自己产生魔力……"

translate chinese chinese_4949802_118:
    old "And you have less and less magical power left..."
    new "而你的魔法力量也越来越少了……"

translate chinese chinese_5665033_119:
    old "What do you want in return?"
    new "你想要什么回报？"

translate chinese chinese_3319345_120:
    old "Nothing, I just want to help in whatever I can..."
    new "没什么，我只是想尽我所能帮忙……"

translate chinese chinese_8907111_121:
    old "Will you still collect magical power from the whole area?"
    new "你还会从整个区域收集魔法力量吗？"

translate chinese chinese_0998680_122:
    old "Well, with Ayax's Hand I automatically gather the magical power where I move..."
    new "嗯，有了艾雅克之手，我就能自动收集移动到的地方的魔力……"

translate chinese chinese_1996955_123:
    old "But that's why whenever you need it you can go at night and suck up magical power from me..."
    new "但正因为这样，每次你需要的时候，晚上都可以来吸取我的魔法力量..."

translate chinese chinese_5522052_124:
    old "Hmmm... Okay, but we'll just take what is necessary..."
    new "嗯……好吧，但我们就拿必要的东西……"

translate chinese chinese_2001053_125:
    old "And we will return what we do not need, so you can look for us to receive magic power that we don't need..."
    new "而我们会归还不需要的东西，所以你可以来找我们接收我们不需要的魔力……"

translate chinese chinese_0582763_126:
    old "It really suits us that you rebuild the sources of magic power production..."
    new "你重建魔法能源产地真的挺适合你的..."

translate chinese chinese_8000927_127:
    old "And that's why we will help you, so you you can find out about Brixxida's true intentions, and we will help you gather the magic power that remains."
    new "所以我们会帮助你，让你查明Brixxida的真实意图，并且我们会帮你收集剩余的魔力。"

translate chinese chinese_8943650_128:
    old "Okay, I'll go as far as I can and find out if Brixxida really has bad intentions or not..."
    new "好吧，我会尽量查清楚布里克西达是不是真的有不良企图……"

translate chinese chinese_9749009_129:
    old "You must be careful, she is much smarter and more powerful than she seems..."
    new "你得小心，她比表面上看起来聪明得多也强大得多……"

translate chinese chinese_2003495_130:
    old "You must act without raising suspicion..."
    new "你必须不动声色地行动……"

translate chinese chinese_1009565_131:
    old "And above all be careful that she does not find out about our deal..."
    new "最重要的是小心别让她发现我们的交易……"

translate chinese chinese_5115755_132:
    old "Okay, I'll keep that in mind... But then, where will I find all of you?"
    new "好吧，我会记住的……但是，那我到哪里去找你们呢？"

translate chinese chinese_7307652_133:
    old "I will continue in the school zone..."
    new "我将继续在学校区域..."

translate chinese chinese_6872359_134:
    old "I'll be in the house, where you found me..."
    new "我在屋子里，你找到我的地方……"

translate chinese chinese_6554706_135:
    old "And you will find me here, that's how we split this little town..."
    new "而你会在这里找到我，这就是我们划分这个小镇的方式……"

translate chinese chinese_9219298_136:
    old "Perfect, if you need to collect more magical power, you know where to find me..."
    new "完美，如果你需要收集更多魔力，知道在哪里能找到我……"

translate chinese chinese_7506340_137:
    old "Okay... I think it's all for now, so we will be leaving..."
    new "好吧……我觉得就这些了，我们就先离开了……"

translate chinese chinese_6154950_138:
    old "You know where to find me... we'll be seeing each other [pla]"
    new "你知道在哪里能找到我……我们会再见的 [pla]"

translate chinese chinese_1001107_139:
    old "Wait! before you go, I want to start our deal..."
    new "等一下！在你走之前，我想开始我们的交易……"

translate chinese chinese_6303691_140:
    old "after all, I have collected the most magical power from you and have not returned any of it to you..."
    new "毕竟，我从你这里收集了最多的魔力，却一点都没还给你……"

translate chinese chinese_0620827_141:
    old "No, no, it is not necessary..."
    new "不用，不用，真的不需要……"

translate chinese chinese_0938172_142:
    old "I see it as a way to close the deal and you have already received magical power from all but me..."
    new "我认为这是个收尾的方式，而且你已经从除了我之外的所有人那里获得了魔力……"

translate chinese chinese_2804888_143:
    old "Hmm... alright, If it's fine for you."
    new "嗯……好吧，如果你觉得没问题的话。"

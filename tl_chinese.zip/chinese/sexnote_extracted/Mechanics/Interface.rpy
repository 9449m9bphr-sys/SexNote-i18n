# auto-tl Qwen Colab

translate chinese chinese_9729126_0:
    old "I shouldn't, is weekend."
    new "我不应该，今天是周末。"

translate chinese chinese_5992917_1:
    old "This is not what it looks like..."
    new "这不像你看到的那样……"

translate chinese chinese_1130362_2:
    old "This is not a real bug... However it looks like you are using a really old file save..."
    new "这并不是真正的错误……不过看起来你在使用一个非常旧的存档文件……"

translate chinese chinese_4415345_3:
    old "That's not bad, however as you can see this game has really improved since last months..."
    new "这还不错，不过你看这个游戏自从上个月以来真的进步了很多……"

translate chinese chinese_6349944_4:
    old "And this version is only compatible with the two last updates 0.14.0 and 0.14.5."
    new "而且这个版本只兼容最后两个更新 0.14.0 和 0.14.5。"

translate chinese chinese_8274106_5:
    old "So, if you use an old save from old versions or an old save bugged it would probably cause bugs in this version..."
    new "所以，如果你用旧版本的存档或者一个有bug的旧存档，可能会导致这个版本出现bug..."

translate chinese chinese_3224336_6:
    old "And we don't want to ruin your experience... So, to avoid that, we suggest you try the 'Skip to new content' option."
    new "我们不想破坏你的体验……所以为了避免这种情况，建议你尝试使用“跳到新内容”选项。"

translate chinese chinese_3195083_7:
    old "So you can play a full version of the game with only the new content in this update."
    new "所以你可以只用这个更新中的新内容玩完整版的游戏。"

translate chinese chinese_3308531_8:
    old "You just have to play start, name your character and then click the 'Skip to new content' option!"
    new "你只需要开始游戏，给角色起个名字，然后点击“跳转到新内容”选项就行了！"

translate chinese chinese_5538338_9:
    old "And if you want to play an old game that you haven't played before, you can contact the developers on {a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}"
    new "如果你想要玩一款之前没玩过的老游戏，你可以联系开发者，联系方式在{a=https://www.patreon.com/sexnote}{b}Patreon{/b}{/a}"

translate chinese chinese_2476886_10:
    old "They can give you all the support you need."
    new "他们可以给你所需要的所有支持。"

translate chinese chinese_8970129_11:
    old "All right, that's it."
    new "好吧，就这样吧。"

translate chinese chinese_3564192_12:
    old "See you soon, here on Sexnote."
    new "很快再见，在Sexnote上见。"

translate chinese chinese_7599227_13:
    old "I shouldn't go there right now."
    new "我现在不该去那儿。"

translate chinese chinese_9733455_14:
    old "It's too late... I shouldn't go there right now."
    new "太晚了……我现在不应该去那里。"

translate chinese chinese_6032873_15:
    old "I'm already very tired, I should rest and continue tomorrow..."
    new "我已经很累了，应该休息一下，明天再继续……"

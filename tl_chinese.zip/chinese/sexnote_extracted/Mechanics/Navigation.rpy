# auto-tl Qwen Colab

translate chinese chinese_8433632_0:
    old "I shouldn't for now."
    new "我现在不应该这么做。"

translate chinese chinese_2443016_1:
    old "I shouldn't for now"
    new "我现在不应该这么做"

translate chinese chinese_4230540_2:
    old "I shouldn't now"
    new "我现在不该这样"

translate chinese chinese_1633278_3:
    old "The school is closed. I should just go home."
    new "学校关门了，我还是回家吧。"

translate chinese chinese_4507507_4:
    old "I shouldn't enter right now. I don't have any appointments..."
    new "我现在不应该进去，我没有预约……"

# auto-tl Qwen Colab

translate chinese chinese_6211269_0:
    old "Drag the documents that must be sent to the right destination, do it quickly to reach all the deliveries of the day."
    new "把必须发送的文件拖到正确的位置，快点做才能完成当天的所有配送。"

translate chinese chinese_9952921_1:
    old "Town Hall"
    new "市政厅"

translate chinese chinese_7335599_2:
    old "To fix the roof you have to drag the tiles one by one to cover the damage."
    new "修屋顶得一块块拖瓦片来覆盖损坏的地方。"

translate chinese chinese_1433223_3:
    old "Open up the boxes two by two, and pair them up with the one equal to them."
    new "两个两个地打开箱子，然后把它们与相等的一个配对。"

translate chinese chinese_7875637_4:
    old "Try to select the profiles that are more akin to what Lydia wants. Swipe the correct ones right and the wrong ones left."
    new "试着选择更符合莉迪亚喜好的档案。把正确的向右滑，错误的向左滑。"

translate chinese chinese_9934979_5:
    old "Remember that these are some of the characteristics that Lydia doesn't like: white hair, red hair, old look and mustache."
    new "记得莉迪亚不喜欢这些特征：白发、红发、老气和胡子。"

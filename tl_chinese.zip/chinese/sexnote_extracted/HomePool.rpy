# auto-tl Qwen Colab

translate chinese chinese_8659722_0:
    old "I should talk with Brixxida first."
    new "我应该先和Brixxida谈谈。"

translate chinese chinese_8654705_1:
    old "No, no, sorry I was just walking around."
    new "不，不，对不起，我刚才只是在走来走去。"

translate chinese chinese_0828971_2:
    old "[pla]... Are you trying to peek at me while I sunbathe?"
    new "[pla]... 你在晒日光浴的时候偷看我吗？"

translate chinese chinese_2591813_3:
    old "What? No, I wasn't-"
    new "什么？不，我还没——"

translate chinese chinese_0751157_4:
    old "Uhm, you get very nervous, kid..."
    new "嗯，你紧张得要命，小子……"

translate chinese chinese_5458231_5:
    old "Is this what you want to see?"
    new "这就是你想看到的吗？"

translate chinese chinese_2193965_6:
    old "Well, if that's what you want..."
    new "好吧，如果你愿意的话..."

translate chinese chinese_6527589_7:
    old "Just don't bother me while I sunbathe, ok?"
    new "就在我还日光浴的时候别烦我，好吗？"

translate chinese chinese_0964156_8:
    old "Didn't I tell you not to bother me? Don't keep bothering me."
    new "我不是告诉你别烦我了吗？别再烦我了。"

translate chinese chinese_7486612_9:
    old "Ok, sorry."
    new "好的，对不起。"

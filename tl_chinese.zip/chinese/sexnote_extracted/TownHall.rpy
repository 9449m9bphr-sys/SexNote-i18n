# auto-tl Qwen Colab

translate chinese chinese_3012491_0:
    old "Talk"
    new "说话"

translate chinese chinese_7219094_1:
    old "Hello, Can I help you?"
    new "你好，需要帮忙吗？"

translate chinese chinese_4955199_2:
    old "Oh, no, sorry for bothering you."
    new "哦，不好意思打扰你了。"

translate chinese chinese_2839111_3:
    old "Hmm, Can I help you?"
    new "嗯，需要帮忙吗？"

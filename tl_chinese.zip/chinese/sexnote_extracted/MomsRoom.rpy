# auto-tl Qwen Colab

translate chinese chinese_1950809_0:
    old "(Let's try this again...)"
    new "(我们再试一次...)"

translate chinese chinese_6809742_1:
    old "Oh! Again, baby? You sure are horny these days."
    new "哦！又来啊，宝贝？你这几天真是精力旺盛啊。"

translate chinese chinese_4477889_2:
    old "But I definitely do love it!"
    new "但我确实很喜欢它！"

translate chinese chinese_2026485_3:
    old "(Nice. She still thinks I'm my [mo1rel]!)"
    new "（真好。她还以为我是我的[mo1rel]呢！）"

translate chinese chinese_4805030_4:
    old "(I'll just do it very carefully...)"
    new "（我得非常小心地来做……）"

translate chinese chinese_7067071_5:
    old "(What if...)"
    new "（如果……）"

translate chinese chinese_2393335_6:
    old "(Oh no... She would kill me... But on the other hand... What if she doesn't notice...)"
    new "（哦不……她会杀了我的……但另一方面……如果她没注意到呢……）"

translate chinese chinese_0548817_7:
    old "(Well... I think there is a chance and if it works I can keep doing it.)"
    new "（嗯……我觉得有机会，如果成功了我就可以继续这么做了。）"

translate chinese chinese_7780612_8:
    old "(All I need to do is be really careful and I'll get out of this alive...)"
    new "（我只要非常小心就能平安脱身了……）"

translate chinese chinese_2513921_9:
    old "(Oh man, I think I will regret this.)"
    new "（天啊，我觉得我会后悔的。）"

translate chinese chinese_5687944_10:
    old "Is that you, baby?"
    new "是你吗，宝贝？"

translate chinese chinese_8687719_11:
    old "(OH SHIT! I'M DEAD MEAT!)"
    new "（哦shit！这下死定了！）"

translate chinese chinese_1735005_12:
    old "Mmm, is it my turn to be fucked?"
    new "嗯，轮到我被操了吗？"

translate chinese chinese_1892712_13:
    old "(What the hell? She thinks I'm [mo1]! Score!)"
    new "（什么情况？她以为我是[mo1]！赚到了！）"

translate chinese chinese_9627529_14:
    old "Oh, I see. You don't want the kids to hear us. Ok, then fuck me quietly..."
    new "哦，我明白了。你不想让孩子们听到。好吧，那就悄悄地干我吧……"

translate chinese chinese_5967967_15:
    old "(Yup. I'm definitely the luckiest guy ever!)"
    new "（没错。我绝对是世界上最幸运的家伙！）"

translate chinese chinese_4175994_16:
    old "Mmm, fuck! It feels bigger than usual. Are you using a new strap-on?"
    new "嗯，操！感觉比平时大。你换新的 strapon 了？"

translate chinese chinese_2032767_17:
    old "Fine. Be quiet, just please don't stop!"
    new "好吧。安静点，但别停下来！"

translate chinese chinese_8377514_18:
    old "(This is the best I've ever had!)"
    new "（这是我经历过的最好的！）"

translate chinese chinese_9135986_19:
    old "(I will just do it carefully...)"
    new "（我小心一点做就行了……）"

translate chinese chinese_2201716_20:
    old "(Damn!... She's amazing but... I should leave. I don't want to wake her up.)"
    new "（该死！……她真棒，但……我还是走吧。我不想把她弄醒。）"

translate chinese chinese_7306517_21:
    old "(Carefully...)"
    new "（小心翼翼地...）"

translate chinese chinese_9789872_22:
    old "(Fuck! She is almost naked! So sexy.)"
    new "（妈的！她几乎裸体了！真性感。）"

translate chinese chinese_3591010_23:
    old "(I should go, though. I don't want to wake her up.)"
    new "（我还是走吧，不想把她吵醒。）"

translate chinese chinese_9475411_24:
    old "(She's sleeping? I shouldn't make any noise.)"
    new "（她在睡觉？我最好不要出声。）"

translate chinese chinese_3706641_25:
    old "(Wait... What was that noise?)"
    new "（等一下……那是什么声音？）"

translate chinese chinese_5933011_26:
    old "It's coming from my [mo1rel]'s bedroom... I should go check it out."
    new "是从我的[mo1rel]的卧室传来的……我应该去看看。"

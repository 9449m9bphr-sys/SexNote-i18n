# auto-tl Qwen Colab

translate chinese chinese_0495889_0:
    old "I should find a therapist and talk with Mrs. Jade first."
    new "我应该先找个治疗师，然后和玉夫人谈谈。"

translate chinese chinese_0731605_1:
    old "I should talk with Mrs. Jade first."
    new "我应该先和玉夫人谈谈。"

translate chinese chinese_9823677_2:
    old "I should talk with Dr. Johnson first."
    new "我应该先和约翰逊博士谈谈。"

translate chinese chinese_9378082_3:
    old "Hey Hinn!"
    new "嘿，Hinn！"

translate chinese chinese_1235838_4:
    old "Hi [pla], how are you doing?"
    new "嗨 [pla]，最近怎么样？"

translate chinese chinese_0859596_5:
    old "Great and you?"
    new "很好，你呢？"

translate chinese chinese_5140233_6:
    old "I'm fine. I wanted to ask you if you've shown our progress to Mrs. Mia?"
    new "我挺好的。我想问问你有没有把我们的进度展示给米娅夫人看？"

translate chinese chinese_1465227_7:
    old "Oh sorry. I haven't yet."
    new "哦，对不起，我还没呢。"

translate chinese chinese_0540414_8:
    old "Well, we should do it before continuing."
    new "嗯，我们在继续之前应该先做这件事。"

translate chinese chinese_0518358_9:
    old "Ok, doing it now."
    new "好的，现在就做。"

translate chinese chinese_6790263_10:
    old "Hi, [pla]..."
    new "喂，[pla]..."

translate chinese chinese_2777031_11:
    old "Hey, Hinn... I wanted to talk about yesterday."
    new "嘿，Hinn... 我想谈谈昨天的事。"

translate chinese chinese_8861993_12:
    old "Oh... Listen... I'm so sorry. I shouldn't have got you into all this. It's my fault..."
    new "哦……听着……我真的对不起。我不应该把你卷进来的。这是我的错……"

translate chinese chinese_7892371_13:
    old "No, no, I agreed to help, in fact I think it was... fun."
    new "不，不，我同意帮忙，事实上我觉得这挺…好玩的。"

translate chinese chinese_0141852_14:
    old "Yes, I liked helping. Also, I think your mom did everything with good intentions."
    new "是的，我喜欢帮忙。而且，我觉得你妈妈一切都是出于好意。"

translate chinese chinese_8525806_15:
    old "Hmm... Maybe in her own way. But you're probably right."
    new "嗯……也许是以她自己的方式。但你可能是对的。"

translate chinese chinese_9311176_16:
    old "I really think you look good with any clothes you decide to wear, the most important thing is that you feel good about yourself."
    new "我真的觉得你穿任何衣服都好看，最重要的是你自己感觉舒服。"

translate chinese chinese_9699788_17:
    old "Thank you, [pla]. (He's so sweet.) I really appreciate it..."
    new "谢谢你，[pla]。（他真甜。）我真的很感激..."

translate chinese chinese_1402696_18:
    old "My pleasure... Well, should we continue with the class project?"
    new "我的荣幸……好吧，我们继续上课的项目吗？"

translate chinese chinese_6197062_19:
    old "Yes, lets do it."
    new "好的，我们开始吧。"

translate chinese chinese_5343503_20:
    old "Great."
    new "太好了。"

translate chinese chinese_2327676_21:
    old "Wow Hinn, you changed your outfit..."
    new "wow Hinn，你换衣服了..."

translate chinese chinese_1529639_22:
    old "Well... I wanted to try something new... What do you think?"
    new "嗯……我想尝试些新的东西……你觉得怎么样？"

translate chinese chinese_8088566_23:
    old "You look great."
    new "你看起来很棒。"

translate chinese chinese_9716478_24:
    old "Yes, but the most important thing is how do you feel?"
    new "是的，但最重要的是你感觉如何？"

translate chinese chinese_3847787_25:
    old "Hmmm, I feel comfortable, the sessions with Dr. Johnson worked."
    new "嗯，我觉得很舒服，和约翰逊博士的疗程有效。"

translate chinese chinese_8105496_26:
    old "Actually, we have a new session today."
    new "实际上，今天我们有一个新的环节。"

translate chinese chinese_1758373_27:
    old "Oh perfect, are you ready?"
    new "哦，太好了，你准备好了吗？"

translate chinese chinese_2888859_28:
    old "Yes, let's go."
    new "好的，我们走吧。"

translate chinese chinese_7833293_29:
    old "I'm fine, thanks."
    new "我挺好的，谢谢。"

translate chinese chinese_9306254_30:
    old "I was wondering if you have a scheduled a new session with Dr. Johnson."
    new "我想知道你是否已经预约了与约翰逊博士的新疗程。"

translate chinese chinese_0559891_31:
    old "Yes, tomorrow morning don't worry."
    new "好的，明天早上，不用担心。"

translate chinese chinese_1536884_32:
    old "Oh great, see you tomorrow then."
    new "哦，那明天见吧。"

translate chinese chinese_7293215_33:
    old "Wait..."
    new "等一下……"

translate chinese chinese_9245810_34:
    old "We could... Practice again... If you want."
    new "我们可以……再练习一次……如果你愿意的话。"

translate chinese chinese_3326372_35:
    old "Sounds great."
    new "听起来不错。"

translate chinese chinese_2299316_36:
    old "Nice."
    new "不错。"

translate chinese chinese_8892797_37:
    old "That sounds great, but I can't right now."
    new "听起来不错，但我现在不行。"

translate chinese chinese_3917765_38:
    old "Oh don't worry, see you tomorrow then."
    new "哦别担心，那明天见。"

translate chinese chinese_4026919_39:
    old "Great, see you."
    new "好的，再见。"

translate chinese chinese_1592228_40:
    old "Great!."
    new "太好了！"

translate chinese chinese_4984225_41:
    old "I was wondering if you you have a scheduled a new sesión with Dr. Johnson."
    new "我想知道你是否已经预约了与约翰逊博士的新疗程。"

translate chinese chinese_7903801_42:
    old "See you."
    new "再见。"

translate chinese chinese_1676051_43:
    old "No, no, sorry I was just walking around. I have to go."
    new "不，不，对不起我只是在四处走走。我得走了。"

translate chinese chinese_3841247_44:
    old "[pla]?..."
    new "[pla]？..."

translate chinese chinese_7904839_45:
    old "Hey, Hinn."
    new "嘿，Hinn。"

translate chinese chinese_0052539_46:
    old "Hi [pla], Are you ready to start?"
    new "你好[pla]，准备好了吗？"

translate chinese chinese_6378337_47:
    old "Yes, I'm ready. Let's get to it."
    new "好的，我准备好了。开始吧。"

translate chinese chinese_5840501_48:
    old "Not"
    new "不"

translate chinese chinese_5594014_49:
    old "Actually, I come to tell you I can't work with you today."
    new "其实，我是来告诉你我今天不能和你一起工作。"

translate chinese chinese_1557581_50:
    old "Oh, ok, don't worry we could work tomorrow on the class project."
    new "哦，好的，别担心，我们可以明天再做班级项目。"

translate chinese chinese_2743602_51:
    old "Of course, tomorrow we will be working hard!"
    new "当然了，明天我们就得努力工作了！"

translate chinese chinese_8259306_52:
    old "Hehehe great, see you."
    new "嘿嘿嘿，太好了，再见。"

translate chinese chinese_6935047_53:
    old "See you Hinn."
    new "再见，Hinn。"

translate chinese chinese_0797859_54:
    old "Damn, are we done? Really?"
    new "妈的，完了？真的吗？"

translate chinese chinese_8666887_55:
    old "Yup... Looks like that's everything..."
    new "嗯……看来就这些了……"

translate chinese chinese_1367418_56:
    old "Hinn? You look sad. You ok?"
    new "希恩？你看起来很难过，没事吧？"

translate chinese chinese_5596694_57:
    old "Yeah, I'm fine... I'm happy we finally finished this project..."
    new "嗯，我挺好的……终于把这个项目完成了，感觉很开心……"

translate chinese chinese_6098813_58:
    old "Really?..."
    new "真的吗？..."

translate chinese chinese_7064374_59:
    old "Yes, it's nothing. Don't worry. Just give the final project to Mrs. Mia tomorrow and let me know what she says. Ok?"
    new "嗯，没什么的。别担心。明天把最终项目交给米娅老师，然后告诉我她怎么说。好吗？"

translate chinese chinese_2699295_60:
    old "Alright, Hinn. No problem."
    new "好吧，希恩。没问题。"

translate chinese chinese_4719551_61:
    old "See you tomorrow, [pla]."
    new "明天见，[pla]。"

translate chinese chinese_9387337_62:
    old "See you tomorrow, Hinn."
    new "明天见，Hinn。"

translate chinese chinese_3001273_63:
    old "Well, we made a lot of progress!"
    new "嗯，我们进步很大！"

translate chinese chinese_1331235_64:
    old "Yes, it's a little late. We should continue tomorrow."
    new "是的，有点晚了。我们明天继续吧。"

translate chinese chinese_7189841_65:
    old "Ok, see you tomorrow, Hinn. Have a good night."
    new "好，明天见，Hinn。晚安。"

translate chinese chinese_7937420_66:
    old "By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "对了，记得向米娅夫人展示我们的进度，让她知道我们已经走了多远。明天见。"

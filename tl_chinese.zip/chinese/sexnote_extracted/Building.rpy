# auto-tl Qwen Colab

translate chinese chinese_2802922_0:
    old "Uhh... Yes..."
    new "呃……是的……"

translate chinese chinese_9657330_1:
    old "Ohh, alright, don't worry I will come tomorrow. Thank you."
    new "哦，好吧，别担心，我明天会来的。谢谢。"

translate chinese chinese_8876363_2:
    old "Good morning Barbie..."
    new "早上好，芭比..."

translate chinese chinese_8370854_3:
    old "Good afternoon Barbie..."
    new "下午好，芭比..."

translate chinese chinese_3568445_4:
    old "I'm [pla]... I was wondering if I can find a Therapist in this business center."
    new "我是[pla]……我想知道在这个商务中心能否找到一位治疗师。"

translate chinese chinese_8996076_5:
    old "Wow great, Can I go to talk with her?"
    new "太好了，我可以去和她谈谈吗？"

translate chinese chinese_3565181_6:
    old "Hmmm, actually is for a friend of mine, but thanks that's all that I needed it."
    new "嗯，其实是给我朋友的，不过谢谢，这就是我需要的。"

translate chinese chinese_9146687_7:
    old "Thank you..."
    new "谢谢你……"

translate chinese chinese_3815381_8:
    old "Now I can talk with Mrs. Jade."
    new "现在我可以和 jade 夫人说话了。"

translate chinese chinese_1855289_9:
    old "I was wondering if Dr. Johnson is in her office."
    new "我在想约翰逊博士是否在办公室里。"

translate chinese chinese_9973764_10:
    old "Great, thanks"
    new "太好了，谢谢"

translate chinese chinese_6394175_11:
    old "Hey [pla], did you make an appointment?"
    new "嘿[pla]，你预约了吗？"

translate chinese chinese_4710128_12:
    old "Oh, no, I'm sorry, I just-"
    new "哦，不，对不起，我只是-"

translate chinese chinese_8713625_13:
    old "Don't worry if you need anything just let me know."
    new "别担心，你需要什么就告诉我。"

translate chinese chinese_9026487_14:
    old "Ok, Thanks."
    new "好的，谢谢。"

translate chinese chinese_3436320_15:
    old "No, no, sorry I was just looking for Hinn. I have to go."
    new "不，不，对不起我只是在找Hinn。我得走了。"

translate chinese chinese_7958285_16:
    old "Hi [pla], welcome back."
    new "你好 [pla]，欢迎回来。"

translate chinese chinese_1798277_17:
    old "Hi doctor Johnson, I'm here because you mentioned we could repeat some lessons..."
    new "乔翰森医生，我来了，因为你提到我们可以重复一些课程……"

translate chinese chinese_4565856_18:
    old "That's great! So, what lesson you want to practice?"
    new "太好了！那你想练习哪一课？"

translate chinese chinese_3894445_19:
    old "Lesson 1"
    new "第一课"

translate chinese chinese_5342947_20:
    old "Great choice. Let's go to the  practice room..."
    new "好选择。我们去练习室吧……"

translate chinese chinese_7279220_21:
    old "Just like that, try to keep it wet, and slowly move a bit faster..."
    new "就这样，保持湿润，然后慢慢加快一点速度……"

translate chinese chinese_0119464_22:
    old "Keep doing it like that... Ahh"
    new "继续这样……啊hh"

translate chinese chinese_9156149_23:
    old "O- ok"
    new "好...好"

translate chinese chinese_3409452_24:
    old "Lesson 2"
    new "第二课"

translate chinese chinese_8279673_25:
    old "Let's do it!"
    new "干吧！"

translate chinese chinese_4806273_26:
    old "Lesson 3"
    new "第三课"

translate chinese chinese_1665424_27:
    old "Lesson 4"
    new "第四课"

translate chinese chinese_0369946_28:
    old "You did it wonderful, I'm glad to have you here again..."
    new "你做得很好，真高兴你又回来了……"

translate chinese chinese_3153954_29:
    old "Definitely, I will pass by more often."
    new "肯定会的，我会常来。"

translate chinese chinese_8917927_30:
    old "It would be the best thing to do, we can enjoy a lot."
    new "这么做最好了，我们可以享受很多。"

translate chinese chinese_6080843_31:
    old "I don't doubt it."
    new "我可不信。"

translate chinese chinese_1856325_32:
    old "Hope to see you soon."
    new "希望很快能见到你。"

translate chinese chinese_3333063_33:
    old "Thank you, have a great day."
    new "谢谢，祝你一天愉快。"

translate chinese chinese_1997163_34:
    old "Bye bye!"
    new "拜拜！"

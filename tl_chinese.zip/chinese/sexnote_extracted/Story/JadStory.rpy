# auto-tl Qwen Colab

translate chinese chinese_2919556_0:
    old "Hi Hinn, good morning. How are you?"
    new "嗨，Hinn，早上好。你怎么样？"

translate chinese chinese_7984872_1:
    old "Boy, I feel like it's been a while since I've seen you."
    new "真觉得好一阵子没见到你了。"

translate chinese chinese_0070758_2:
    old "Yeah... We haven't really hung out lately."
    new "嗯……我们最近确实没怎么一起玩。"

translate chinese chinese_5397041_3:
    old "Actually, I've been thinking..."
    new "其实，我一直在想..."

translate chinese chinese_1028026_4:
    old "Do you think you would like to come to my house? Maybe we could watch a movie together?"
    new "你觉得来我家怎么样？ maybe我们一起看部电影？"

translate chinese chinese_3857843_5:
    old "I- if you want to... Of course."
    new "我—如果你想要的话……当然。"

translate chinese chinese_5694181_6:
    old "Of course, that would be nice."
    new "当然，那会很好。"

translate chinese chinese_5459749_7:
    old "Really? That's great!"
    new "真的吗？太好了！"

translate chinese chinese_8204547_8:
    old "Well, since we're done with school for the day. Would you like to go now?"
    new "好吧，既然今天放学了，你现在想去吗？"

translate chinese chinese_6794537_9:
    old "Sure, that sounds great."
    new "行，听起来不错。"

translate chinese chinese_2288519_10:
    old "Ok, so, what movie do you think you would like to watch?"
    new "好吧，你觉得你想看什么电影？"

translate chinese chinese_6975826_11:
    old "Well, I've been wanting to watch this new movie called 'Lusted Note.'"
    new "嗯，我一直想看一部新电影叫《欲望笔记》。"

translate chinese chinese_1371683_12:
    old "Uhh, ok... What's it about?"
    new "呃，好……是关于什么的？"

translate chinese chinese_8038492_13:
    old "It's a romance movie about a stepbrother and stepsister who fall in love."
    new "这是一部关于继兄妹坠入爱河的浪漫电影。"

translate chinese chinese_7925203_14:
    old "It's been all the rage lately, everyone says it's so good! And the lead actress is really good, I'm her fan!"
    new "最近超火的，大家都说很好看！而且女主角演技很棒，我是她的粉丝！"

translate chinese chinese_7982774_15:
    old "Well, sounds interesting, let's watch it."
    new "嗯，听起来挺有意思的，咱们看看吧。"

translate chinese chinese_7430852_16:
    old "Wow this movie is actually really good."
    new "哇，这部电影真的很好看。"

translate chinese chinese_0297536_17:
    old "Yeah, it's great."
    new "是的，太棒了。"

translate chinese chinese_2735940_18:
    old "I really like their love story, it's so beautiful."
    new "我真的喜欢他们的爱情故事，太美了。"

translate chinese chinese_7336632_19:
    old "You know, I'm very happy you decided to come, today."
    new "你知道吗，今天你决定来，我非常高兴。"

translate chinese chinese_8468828_20:
    old "I thought maybe, you wouldn't want to come."
    new "我还以为你可能不想来呢。"

translate chinese chinese_9997096_21:
    old "What? Why would you think that?"
    new "什么？你为什么这么想？"

translate chinese chinese_5667057_22:
    old "Well, it's just that you're such a popular guy, you know..."
    new "嗯，就是因为你这么受欢迎嘛，你知道的……"

translate chinese chinese_1621443_23:
    old "Popular? Me??"
    new "受欢迎？我？？"

translate chinese chinese_6558881_24:
    old "Come on... There's no way you think I'm popular."
    new "拜托……你不会真的觉得我受欢迎吧。"

translate chinese chinese_2477941_25:
    old "Well, you seem to get along quite well with a lot of people."
    new "嗯，你看起来和很多人都处得很好。"

translate chinese chinese_6202022_26:
    old "You know... You get along so well with Belle and Billie."
    new "你知道吗……你和贝拉还有比莉相处得那么好。"

translate chinese chinese_3015929_27:
    old "Well, you know... They're my friends too."
    new "嗯，你也知道……他们也是我的朋友。"

translate chinese chinese_4718790_28:
    old "And I really like hanging out with them."
    new "而且我真的喜欢和他们在一起。"

translate chinese chinese_3478997_29:
    old "But that doesn't mean I wouldn't want to hang out with you. Or that I would be too busy."
    new "但这不意味着我不想和你出去玩。或者我太忙了。"

translate chinese chinese_1398867_30:
    old "I really enjoy spending time with you Hinn."
    new "我真的非常喜欢和你在一起，Hinn。"

translate chinese chinese_0301707_31:
    old "Thank you [pla], I really like spending time with you too."
    new "谢谢你[pla]，我也真的很喜欢和你在一起。"

translate chinese chinese_5746153_32:
    old "You know, my mom won't come home for a while."
    new "你知道吗，我妈妈还要过一阵子才回家。"

translate chinese chinese_9689770_33:
    old "Oh!"
    new "哦！"

translate chinese chinese_0234922_34:
    old "So... If you want, we could... You know..."
    new "所以……如果你想的话，我们可以……你知道的……"

translate chinese chinese_8119916_35:
    old "Uhh... Should we go up to your bedroom?"
    new "呃……我们去你的卧室吧？"

translate chinese chinese_7291824_36:
    old "Haha, there's no need."
    new "哈哈，不用了。"

translate chinese chinese_5985466_37:
    old "She'll take a while, so, we can just do it here."
    new "她还得一会儿，我们就在这里做吧。"

translate chinese chinese_9950357_38:
    old "Well?!"
    new "喂！"

translate chinese chinese_4102549_39:
    old "Aren't you going to say anything?"
    new "你不打算说点什么吗？"

translate chinese chinese_4191078_40:
    old "Wait a minute! What are you doing home so early?! You told me you were going to be late today!"
    new "等一下！你怎么这么早回家？！你刚才还说今天会晚回来的！"

translate chinese chinese_0456145_41:
    old "I decided to come home early today."
    new "我今天决定早点回家。"

translate chinese chinese_0226254_42:
    old "But I see now this is why you kept asking me what I was going to be doing today..."
    new "但现在我明白了，这就是为什么你一直问我今天要做什么……"

translate chinese chinese_5335185_43:
    old "This is incredible..."
    new "这太不可思议了……"

translate chinese chinese_4815564_44:
    old "We weren't doing anything wrong you know."
    new "我们什么都没做错你知道。"

translate chinese chinese_9151101_45:
    old "I didn't say you were!"
    new "我没说你是！"

translate chinese chinese_0520223_46:
    old "Listen Hinn, [pla], I understand you two are adults now, I'm not bothered by you having sex or anything."
    new "听好了，Hinn，[pla]，我知道你们现在是大人了，我不会介意你们发生性关系的。"

translate chinese chinese_7801834_47:
    old "But if you're going to have sex, please do it in a private place!"
    new "但是如果你要发生关系，请找个私人的地方好吗！"

translate chinese chinese_1821513_48:
    old "Just look at the way you two are right now!"
    new "看看你们俩现在这模样！"

translate chinese chinese_9479311_49:
    old "Just standing there completely naked!"
    new "就那样完全裸体站在那里！"

translate chinese chinese_5400671_50:
    old "(Whoah, h-he's so big!)"
    new "（天啊，他好大！）"

translate chinese chinese_3753128_51:
    old "You have to think about other people, you know..."
    new "你也得想想别人的感受啊……"

translate chinese chinese_6583785_52:
    old "We just didn't know you were coming home so soon..."
    new "我们只是没想到你会这么快回家……"

translate chinese chinese_4391697_53:
    old "Listen, I know you guys are young and full of hormones..."
    new "听着，我知道你们还年轻，荷尔蒙旺盛……"

translate chinese chinese_3871503_54:
    old "But this is the living room! I usually watch tv on that couch!"
    new "但这可是客厅啊！我通常就在那沙发上看电视！"

translate chinese chinese_9218993_55:
    old "Besides, I could've come home with company..."
    new "再说，我本来可以带人回家的……"

translate chinese chinese_8406673_56:
    old "Imagine what would have happened if someone saw you and your boyfriend having sex on the couch Hinn."
    new "想想看，如果有人看到你和你男朋友在沙发上做爱会怎么样。"

translate chinese chinese_2859630_57:
    old "B- boyfriend? (Gosh! Mom why can't you shut up...)"
    new "男- 朋友？（天啊！妈妈你能不能别说了...）"

translate chinese chinese_9456199_58:
    old "Uhh... W- We are not a... C- couple... (Not yet, THANKS MOM!)"
    new "呃……我们不……不是……情侣……（还没呢，谢谢老妈！）"

translate chinese chinese_6662379_59:
    old "We still being... Uhh, just friends."
    new "我们还是...嗯，只是朋友。"

translate chinese chinese_9967652_60:
    old "E- excuse me?"
    new "什、什么？"

translate chinese chinese_7289907_61:
    old "B- but you two were just..."
    new "你你们刚才不是..."

translate chinese chinese_9011119_62:
    old "Mom please, this is not your business!"
    new "妈妈拜托，这不关你的事！"

translate chinese chinese_8071937_63:
    old "Well, I guess that's just how you do things these days..."
    new "嗯，我想现在大家都是这么做的吧……"

translate chinese chinese_2413675_64:
    old "I get it, young people are a little more open nowadays, as long as your kids are safe... I guess it's alright."
    new "我懂了，现在年轻人开放一点，只要你的孩子安全……我想也行吧。"

translate chinese chinese_6132161_65:
    old "But that's not the point, the point is that you should be more careful with these things."
    new "但重点不是这个，重点是你应该更小心这些事情。"

translate chinese chinese_1397768_66:
    old "If you're going to be having sex, do it in your bedroom."
    new "要是你要做那种事，去卧室里做。"

translate chinese chinese_6470314_67:
    old "It doesn't matter if I'm not home, try to be a little respectful, will you?"
    new "我不在家也一样，能不能有点尊重？"

translate chinese chinese_4005487_68:
    old "Oh my gosh! It was an accident!"
    new "天啊！那是意外！"

translate chinese chinese_4339547_69:
    old "Ugh, I don't want to talk about this anymore. Come on [pla], let's go to my bedroom!"
    new "哎，我不想再谈这个了。来吧[pla]，我们去我的卧室！"

translate chinese chinese_8671483_70:
    old "Sorry, Mrs. Jade."
    new "对不起， jade太太。"

translate chinese chinese_1925099_71:
    old "(God, he really has a huge...)"
    new "（天啊，他真的很大……）"

translate chinese chinese_0350827_72:
    old "Listen [pla], I'm sorry about that, I didn't expect her to come home so early."
    new "听好了[pla]，我很抱歉，没想到她会这么早回家。"

translate chinese chinese_2713609_73:
    old "I'm also sorry about what she said. She can be a drag sometimes."
    new "我也为她说的话道歉。她有时候确实挺烦的。"

translate chinese chinese_5248966_74:
    old "It's ok. Besides, I sort of think that she's  right."
    new "没关系。而且，我有点觉得她是对的。"

translate chinese chinese_6054174_75:
    old "Yeah, I mean, we did it in the living room."
    new "是啊，我的意思是我们确实在客厅做了。"

translate chinese chinese_7284163_76:
    old "In a way, we're lucky she wasn't even angrier."
    new "说起来，我们还挺幸运的，她甚至还没更生气。"

translate chinese chinese_7800111_77:
    old "{b}*Sigh*{/b} Yeah, I guess you're right."
    new "{b}*叹气*{/b} 嗯，我想你是对的。"

translate chinese chinese_3596267_78:
    old "I suppose next time we'll just have to be more careful."
    new "我想下次我们得小心点了。"

translate chinese chinese_0660347_79:
    old "I guess you have to go, right?"
    new "我猜你得走了，是吧？"

translate chinese chinese_5518308_80:
    old "Yeah, I better go home, but, maybe we can finish the movie some other time."
    new "嗯，我还是回家吧，不过也许下次我们可以把电影看完。"

translate chinese chinese_6887936_81:
    old "Yeah, that would be great!"
    new "是的，那太好了！"

translate chinese chinese_7177180_82:
    old "Alright, see you later [pla]."
    new "好了，再见[pla]。"

translate chinese chinese_6365068_83:
    old "Hi Hinn, I'm great. And you? How are things with your mom?"
    new "嗨，Hinn，我很好。你呢？你妈妈那边怎么样？"

translate chinese chinese_5538198_84:
    old "Oh, it's fine, she wasn't really all that angry."
    new "哦，没事，她其实没那么生气。"

translate chinese chinese_0582692_85:
    old "I see, that's good I guess."
    new "我明白了，这大概不错。"

translate chinese chinese_4512637_86:
    old "On that note, I was thinking..."
    new "说到这个，我在想..."

translate chinese chinese_9608399_87:
    old "You know, since last time we couldn't actually finish the movie, what do you think if you come over and we finish it?"
    new "你知道吗，上次我们电影都没看完，要不你来我家，我们一起把它看完吧？"

translate chinese chinese_6241863_88:
    old "Huh? Come over? To your house?"
    new "huh? 过来？去你家？"

translate chinese chinese_2128895_89:
    old "Yeah, of course."
    new "当然了。"

translate chinese chinese_3261015_90:
    old "Is there a problem?"
    new "有什么问题吗？"

translate chinese chinese_3568909_91:
    old "No, no problem. I'm just not sure about it, you know?"
    new "不，没问题。我只是不太确定，你知道的？"

translate chinese chinese_0606378_92:
    old "What if your mother doesn't like that I go there?"
    new "如果你妈妈不喜欢我去那里怎么办？"

translate chinese chinese_8167934_93:
    old "Don't be silly, I told you, she's not angry."
    new "别傻了，我跟你说过了，她不生气。"

translate chinese chinese_7036038_94:
    old "We just need to be careful and nothing will happen."
    new "我们只要小心一点就不会出事。"

translate chinese chinese_8018432_95:
    old "Hmm, I guess you're right."
    new "嗯，我想你是对的。"

translate chinese chinese_5204936_96:
    old "Ok, I'm in."
    new "好，我同意。"

translate chinese chinese_1569723_97:
    old "Oh, hi [pla]! I didn't know you were here!"
    new "哦，嗨，[pla]！我不知道你在这里！"

translate chinese chinese_3941508_98:
    old "Hi Mrs. Jade, how are you? I was just watching a movie with Hinn."
    new "嗨， jade 夫人，你好吗？我刚才和 Hinn 在看电影。"

translate chinese chinese_1684772_99:
    old "Well, it's good to see you again..."
    new "嗯，再次见到你真好……"

translate chinese chinese_0379089_100:
    old "So, what are you watching?"
    new "所以，你在看什么？"

translate chinese chinese_1951459_101:
    old "Phew, I definitely should take some extra parking lessons, heh."
    new "呼，我肯定得多上几节停车课，嘿嘿。"

translate chinese chinese_3474354_102:
    old "Oh, hi kids! How are you?"
    new "哦，孩子们好呀！你们怎么样？"

translate chinese chinese_6166715_103:
    old "Oh, it's been a while [pla]..."
    new "哦，很久不见了[pla]..."

translate chinese chinese_7789626_104:
    old "Hi Mrs. White... Nice to see you..."
    new "嗨，怀特夫人……见到你真好……"

translate chinese chinese_2634471_105:
    old "Hello Mrs. White, how are you?"
    new "白太太，您好吗？"

translate chinese chinese_6392478_106:
    old "I'm very good darling. I have to say I love your new outfit, it suits you much better than that old jumper you used before."
    new "我很好，亲爱的。不得不说，我喜欢你新买的衣服，比以前那件旧毛衣更适合你。"

translate chinese chinese_3420121_107:
    old "I have to say [pla], you're also very good-looking."
    new "我得说，[pla]，你也长得很好看。"

translate chinese chinese_6254493_108:
    old "These kids just get so big from one moment to another, right Jade?"
    new "这些孩子一下子就长大了，对吧， Jade？"

translate chinese chinese_8469882_109:
    old "You're right, it's amazing..."
    new "你说得对，真不可思议..."

translate chinese chinese_5536317_110:
    old "So, you two were out together?"
    new "所以你们俩一起去的？"

translate chinese chinese_1449278_111:
    old "Yeah, that's right, Mrs. White was helping me with some shores."
    new "对，怀特夫人帮我处理一些事情。"

translate chinese chinese_2016240_112:
    old "And I told her to come to hang out with me."
    new "然后我让她过来陪我玩。"

translate chinese chinese_0584652_113:
    old "We hadn't spoken in a while."
    new "我们有一阵子没说话了。"

translate chinese chinese_9021882_114:
    old "Oh, ok. That's great."
    new "哦，好的。那太好了。"

translate chinese chinese_2494676_115:
    old "{b}*PHONE RINGING*{/b}"
    new "{b}*电话铃声*{/b}"

translate chinese chinese_9036383_116:
    old "Uhh, the phone is ringing. I'll be right back."
    new "嗯，电话响了。我马上回来。"

translate chinese chinese_8715657_117:
    old "So, you two were watching a movie?"
    new "所以，你们俩在看电影吗？"

translate chinese chinese_6655267_118:
    old "Yeah... that's right."
    new "嗯……对了。"

translate chinese chinese_8146240_119:
    old "Well? Was it good?"
    new "怎么样？好不好？"

translate chinese chinese_2466039_120:
    old "Umm, yeah, I guess..."
    new "嗯，好吧，我想……"

translate chinese chinese_3475810_121:
    old "I think we're going to keep watching it, so, if you don't mind"
    new "我觉得我们会继续看下去，如果你不介意的话"

translate chinese chinese_0000700_122:
    old "Oh well, I'll watch it with you then."
    new "哦，那我陪你一起看吧。"

translate chinese chinese_1406890_123:
    old "I can't believe you! I just simply can't"
    new "真不敢相信你！我简直无法相信"

translate chinese chinese_6694484_124:
    old "Why don't you take..."
    new "你为什么不拿……"

translate chinese chinese_6967304_125:
    old "No! I did not say that!"
    new "不！我没这么说！"

translate chinese chinese_7779936_126:
    old "It's always the same with you Hiashi!"
    new "你这招每次都一样，日向！"

translate chinese chinese_3947330_127:
    old "It's almost as if you don't care about your daughter's well-being."
    new "简直就像你不在乎你女儿的福祉一样。"

translate chinese chinese_4495961_128:
    old "My God!!"
    new "天啊！！"

translate chinese chinese_0114517_129:
    old "No, NO! YOU listen to me! You have to figure out something and fulfill your responsibility or I'm taking action."
    new "不，不要！你给我听好了！你得想个办法负起责任来，不然我就采取行动了。"

translate chinese chinese_9820773_130:
    old "Ok, I'm here again."
    new "好的，我又来了。"

translate chinese chinese_5973354_131:
    old "Are you ok? What happened?"
    new "你还好吗？发生了什么事？"

translate chinese chinese_9422108_132:
    old "Uhh, please don't tell me you heard everything I said..."
    new "呃，别告诉我你听到了我说的所有话……"

translate chinese chinese_1557276_133:
    old "You weren't very quiet, to be honest..."
    new "说实话，你可不太安静……"

translate chinese chinese_2062828_134:
    old "{b}*Sigh*{/b}... I'm very sorry, it wasn't my intention."
    new "{b}*叹气*{/b}……非常抱歉，那不是我的本意。"

translate chinese chinese_2966453_135:
    old "Let's just pretend it never happened, and enjoy the movie."
    new "我们就当这件事没发生过，好好享受电影吧。"

translate chinese chinese_9399267_136:
    old "Well, that was very good!"
    new "嗯，这真是非常好！"

translate chinese chinese_4703505_137:
    old "It really was."
    new "确实如此。"

translate chinese chinese_4341015_138:
    old "I think I'll watch it in full when I get home. Don't you think it was great Jade?"
    new "我想回家再好好看一遍。你觉得Jade不错吧？"

translate chinese chinese_6463182_139:
    old "What? Oh, yeah... Very good."
    new "什么？哦，对了……很好。"

translate chinese chinese_5158049_140:
    old "Ok, tell me, what is it?"
    new "好，你说，是什么？"

translate chinese chinese_8961574_141:
    old "Come on, don't play dumb with me."
    new "别装傻了。"

translate chinese chinese_3192355_142:
    old "What did Hiashi say this time?"
    new "这次辉夜说了什么？"

translate chinese chinese_8619315_143:
    old "Honestly, I don't want to talk about this, especially not in front of the kids."
    new "说实话，我真不想谈这个，尤其是当着孩子的面。"

translate chinese chinese_2663550_144:
    old "Oh come on, they're adults now. Nothing bad will happen to them."
    new "哦，拜托，他们现在是大人了。不会出什么事的。"

translate chinese chinese_9195194_145:
    old "Just spit it out, if you don't talk about it you'll be in a bad mood all week."
    new "干脆说出来吧，如果你不谈谈这事，你这一整周都会心情不好的。"

translate chinese chinese_7033850_146:
    old "That was Hiashi, saying, once again! That he can't pay my alimony this month."
    new "那是Hiashi又说这个月他不能支付我的赡养费。"

translate chinese chinese_9776617_147:
    old "That's four months in a row! That irresponsible bum!"
    new "都连续四个月了！那个不负责任的混蛋！"

translate chinese chinese_4452102_148:
    old "And it's not as if things are any easy around here, he should know how the economy is around here."
    new "而且这里的情况也不容易，他应该知道这里的经济状况。"

translate chinese chinese_9024986_149:
    old "That's Hiashi for you, always the same guy..."
    new "这就是Hiashi，永远不变的样子..."

translate chinese chinese_7618127_150:
    old "I bet he's still seeing that 19-year-old bimbo isn't he?"
    new "我打赌他还在跟那个19岁的傻瓜在一起吧？"

translate chinese chinese_1048298_151:
    old "Yes, he is! God! That's what bothers me! He doesn't have enough money to help his daughter!"
    new "是的，他就是那样！天啊！这正是让我烦恼的地方！他没有足够的钱来帮助他的女儿！"

translate chinese chinese_5733711_152:
    old "But he can go around buying expensive clothes and vacations for some hussy that could be his grandchild!"
    new "但他可以去买昂贵的衣服和度假送给某个可能比他还大的情妇！"

translate chinese chinese_6910936_153:
    old "I'm sorry Hinn, sweety, I wouldn't want to talk to you about your father like that."
    new "对不起，希恩，甜心，我不愿意那样跟你谈论你的父亲。"

translate chinese chinese_6805083_154:
    old "Hmph, whatever, not like any of this is new to me."
    new "哼，随便吧，这些对我来说都不是新鲜事。"

translate chinese chinese_1508948_155:
    old "But I would've liked to have a calm movie night."
    new "但我本来想有个平静的电影之夜的。"

translate chinese chinese_5866382_156:
    old "Come on [pla] let's get out of here."
    new "来吧[pla]，我们离开这里。"

translate chinese chinese_7770471_157:
    old "Listen, I'm sorry for what happened."
    new "听着，我为发生的事道歉。"

translate chinese chinese_6093858_158:
    old "God! My mom ruins everything!"
    new "天啊！我妈妈什么都搞砸了！"

translate chinese chinese_8124037_159:
    old "No, no, don't worry. That's ok, I understand."
    new "不用不用，别担心。这样就行了，我明白。"

translate chinese chinese_3356142_160:
    old "I get it, this type of thing can stress anybody."
    new "我明白，这种事情谁都会感到压力。"

translate chinese chinese_2141104_161:
    old "You know, you're always very sweet."
    new "你知道吗，你总是很甜。"

translate chinese chinese_2359509_162:
    old "Yes, and it deserves a reward..."
    new "是的，这值得奖励……"

translate chinese chinese_6668500_163:
    old "What are we doing here?"
    new "我们在这里干什么？"

translate chinese chinese_2639061_164:
    old "Well, we needed privacy to give you a special reward."
    new "嗯，我们需要一点隐私来给你一个特别的奖励。"

translate chinese chinese_8138736_165:
    old "Whoah! What are you doing?"
    new "谁啊！你在干什么？"

translate chinese chinese_0499503_166:
    old "I told you, I'm giving you a reward."
    new "我跟你说过了，我要给你奖励。"

translate chinese chinese_0475318_167:
    old "I was thinking that we could finish what we started the other night."
    new "我在想我们能不能把上次晚上开始的事情做完。"

translate chinese chinese_7737426_168:
    old "But my mom and Mrs. White got home when I wasn't expecting it."
    new "但是妈妈和怀特太太在我没想到的时候回来了。"

translate chinese chinese_0506057_169:
    old "So, I'll just give  you a little something before you go home."
    new "所以，在你回家之前，我给你一点小东西。"

translate chinese chinese_4232230_170:
    old "{b}*Glup*{/b}"
    new "{b}*咕嘟*{/b}"

translate chinese chinese_2064458_171:
    old "Hey, what are you doing there?"
    new "喂，你在那儿干什么？"

translate chinese chinese_2860285_172:
    old "What?! Oh, my God! You surprised me!"
    new "什么?! 哦，天哪！你吓到我了！"

translate chinese chinese_9494874_173:
    old "Well, you were taking your sweet time and you left the stove on... Do you want me to finish dinner for you?"
    new "好吧，你磨磨蹭蹭的，还把炉子开着……你要我帮你做完晚饭吗？"

translate chinese chinese_2486639_174:
    old "No, no, I just got distracted by... Something."
    new "不，不，我只是被……什么分心了。"

translate chinese chinese_4908618_175:
    old "Right... Is there anything in the bathroom?"
    new "好吧……浴室里有什么吗？"

translate chinese chinese_4273717_176:
    old "Nothing! Nothing! I was just looking for Hinn, but she isn't there."
    new "没什么！没什么！我只是在找Hinn，但她不在那里。"

translate chinese chinese_2877631_177:
    old "Ok, sure."
    new "好的，行。"

translate chinese chinese_1548624_178:
    old "Anyway, let's go, help me with the mac and cheese."
    new "总之，走吧，帮我弄通心粉和奶酪。"

translate chinese chinese_9607095_179:
    old "That was very good."
    new "那非常好。"

translate chinese chinese_6001671_180:
    old "Yeah, it was, I wasn't expecting it though."
    new "是的，不过我没想到会这样。"

translate chinese chinese_5646286_181:
    old "Well, I wanted to make it up to you for the interruption last time, you know."
    new "嗯，我上次打断了你，这次想补偿一下你，你知道的。"

translate chinese chinese_3056574_182:
    old "Yeah, I think I get it."
    new "嗯，我觉得我明白了。"

translate chinese chinese_5773221_183:
    old "Anyway, I think, I shoould go home."
    new "总之，我觉得我应该回家了。"

translate chinese chinese_3932279_184:
    old "Hmm, yeah you are right."
    new "嗯，你说得对。"

translate chinese chinese_2827882_185:
    old "Listen, I'm really sorry about today, with my mom yelling all the movie and everything."
    new "听着，我真的很抱歉今天我妈妈一直在电影里大喊大叫的。"

translate chinese chinese_1525349_186:
    old "It ruined the movie afternoon."
    new "这毁了我们的电影下午时光。"

translate chinese chinese_0234948_187:
    old "Oh come on, I still had a great time."
    new "哦，别这样，我玩得还是挺开心的。"

translate chinese chinese_9650933_188:
    old "If you'd like, maybe we could watch another movie some other day."
    new "如果你愿意，也许我们可以改天再看一部电影。"

translate chinese chinese_7677921_189:
    old "Let's do it then."
    new "那我们就干吧。"

translate chinese chinese_0807063_190:
    old "Alright, so, I better go now."
    new "好吧，我还是走吧。"

translate chinese chinese_6328312_191:
    old "Oh, right. Have a good night [pla]."
    new "哦，对了。晚安[pla]。"

translate chinese chinese_7815654_192:
    old "Thank you, I really enjoyed the day. See you soon Hinn."
    new "谢谢你，今天玩得很开心。很快再见，Hinn。"

translate chinese chinese_9520755_193:
    old "I'm great actually, my mom and I talked, and we're both feeling a lot better."
    new "其实我挺好的，我和妈妈谈过了，我们都感觉好多了。"

translate chinese chinese_7236238_194:
    old "That's good, it's great that you can talk about those things."
    new "很好，你能说出那些事情很不错。"

translate chinese chinese_8096444_195:
    old "It's a shame about the movie tho, though I suppose that still annoys you a little bit..."
    new "不过那部电影真是可惜了，虽然这可能还是有点让你生气……"

translate chinese chinese_1369111_196:
    old "Well, about that..."
    new "嗯，关于这个……"

translate chinese chinese_6867241_197:
    old "Do you think you would like to go to my house again?"
    new "你觉得还会想再去我家吗？"

translate chinese chinese_3637603_198:
    old "There's another movie that I would like to watch with you..."
    new "还有一部电影我想和你一起看……"

translate chinese chinese_2014849_199:
    old "Hmm... Yeah, sure, I don't see why not."
    new "嗯……好吧，我没问题。"

translate chinese chinese_0487334_200:
    old "Hey, that's great."
    new "嘿，那太好了。"

translate chinese chinese_4952026_201:
    old "And listen, this time my mom will be leaving for some event dinner she was invited to."
    new "而且听着，这次我妈妈会被邀请去参加一个晚宴活动。"

translate chinese chinese_9653166_202:
    old "So, maybe we can finish the movie... And something else."
    new "所以，也许我们可以看完电影……再做点别的。"

translate chinese chinese_7895273_203:
    old "Oh, sure."
    new "哦，当然。"

translate chinese chinese_3501909_204:
    old "Sounds good."
    new "听起来不错。"

translate chinese chinese_6051845_205:
    old "Great! So, let's go."
    new "太好了，那我们走吧。"

translate chinese chinese_2881045_206:
    old "God dammit!"
    new "该死！"

translate chinese chinese_5511099_207:
    old "Ugh! What now?!"
    new "哎呀！现在又怎么了？！"

translate chinese chinese_1379494_208:
    old "Oh! Hi [pla]!"
    new "哦！嗨，[pla]！"

translate chinese chinese_2754345_209:
    old "I didn't know you were here honey!"
    new "亲爱的，我不知道你在这里！"

translate chinese chinese_5859188_210:
    old "Are you having a good time?"
    new "玩得开心吗？"

translate chinese chinese_0204617_211:
    old "Hello Mrs. Jade, I was just watching a movie with Hinn."
    new "喂， jade 夫人，我刚才和 Hinn 在看电影。"

translate chinese chinese_7653240_212:
    old "I'm glad honey."
    new "我很高兴，宝贝。"

translate chinese chinese_0407546_213:
    old "What happened now mom?"
    new "妈妈，这次又怎么了？"

translate chinese chinese_9699467_214:
    old "Why did you scream and come out running in a towel?"
    new "你为什么尖叫着穿着浴巾跑出来？"

translate chinese chinese_3354819_215:
    old "Well, I was taking a shower to get ready for that dinner I told you about."
    new "嗯，我正在洗澡，为那个我告诉过你的晚餐做准备。"

translate chinese chinese_8250035_216:
    old "But, then my shower suddenly exploded!"
    new "但是，我的淋浴突然爆炸了！"

translate chinese chinese_3039425_217:
    old "Now there's a lot of water running out of the piping."
    new "现在管道里流出很多水。"

translate chinese chinese_9125178_218:
    old "So? Just call a plumber to fix it."
    new "那怎么办？叫个 plumber 来修就行了。"

translate chinese chinese_3554285_219:
    old "Well, young lady, in case you haven't been paying attention lately. We're not exactly swimming in money right now."
    new "好吧，小姐，如果你最近没注意的话，我们现在可不是手头宽裕。"

translate chinese chinese_8802542_220:
    old "Since your father hasn't been paying my alimony, I've been having to take care of things."
    new "因为你爸爸没给我赡养费，我只好自己处理一切。"

translate chinese chinese_9817799_221:
    old "Right now I just can't afford to have somebody come and redo the entire bathroom tubing."
    new "现在我真的负担不起有人来重新做整个浴室的管道。"

translate chinese chinese_0374196_222:
    old "Oh great!"
    new "哦，太好了！"

translate chinese chinese_3727038_223:
    old "Uh, I think that maybe I could do something about that."
    new "嗯，我觉得我可能能做点什么。"

translate chinese chinese_5169887_224:
    old "Really? You know how to fix that type of thing?"
    new "真的吗？你知道怎么修那种东西？"

translate chinese chinese_9862595_225:
    old "I mean, I'd have to take a look, but maybe I can do something."
    new "我的意思是，我得看看情况，但也许我能做点什么。"

translate chinese chinese_7875366_226:
    old "Oh great, another fantastic movie night..."
    new "哦，真好，又一个精彩的电影之夜……"

translate chinese chinese_0136330_227:
    old "Ok, ok, I see what happened, there was a rusty pipe, and it broke."
    new "好吧，好吧，我知道发生了什么，有一根生锈的管子，然后它断了。"

translate chinese chinese_1927773_228:
    old "I should be able to fix that."
    new "这个我应该能搞定。"

translate chinese chinese_8933821_229:
    old "Really? You think so?"
    new "真的吗？你觉得是这样？"

translate chinese chinese_8972821_230:
    old "Well, it's going to take a while, because I'll have to change the whole piping for the bathroom."
    new "嗯，这得花些时间，因为我得把整个浴室的管道都换掉。"

translate chinese chinese_0991939_231:
    old "And that means breaking some of the wall and the floor."
    new "那就意味着要砸烂一些墙和地板。"

translate chinese chinese_1247370_232:
    old "But it shouldn't be too much of a problem."
    new "但问题应该不大。"

translate chinese chinese_1772195_233:
    old "I actually have some experience doing house repairs and stuff."
    new "我实际上有一些修房子的经验。"

translate chinese chinese_4889137_234:
    old "You do? Did you have a part-time job doing that?"
    new "你有吗？你是做兼职做的吗？"

translate chinese chinese_1093610_235:
    old "I guess you could call it a summer job."
    new "我想你可以称之为暑期工。"

translate chinese chinese_9556538_236:
    old "I see, well, I guess the only thing I can say is. When do you start?"
    new "我明白了，嗯，我想我唯一能说的是，你什么时候开始？"

translate chinese chinese_8788882_237:
    old "Well, I would need to get some materials. But overall it shouldn't be too expensive."
    new "嗯，我需要一些材料。但总体来说不应该太贵。"

translate chinese chinese_0880501_238:
    old "It's not too late, so, I should be able to make it to the hardware store."
    new "还不算太晚，我应该能赶到五金店。"

translate chinese chinese_6128668_239:
    old "Oh, but you shouldn't spend your own money on that honey."
    new "哦，但是你不应该用自己的钱买那个蜂蜜。"

translate chinese chinese_4186725_240:
    old "Well, I'll just buy some things, and if you want me to, I'll just hand you the receipt the next time I'm here."
    new "好吧，我就买东西，如果你要的话，下次来的时候我把收据给你。"

translate chinese chinese_2992999_241:
    old "That would be really nice of you."
    new "你真是个好人。"

translate chinese chinese_3646758_242:
    old "Don't worry, this won't be expensive at all."
    new "放心，这完全不贵。"

translate chinese chinese_4236529_243:
    old "That's a relief to hear."
    new "听到这个放心多了。"

translate chinese chinese_1990797_244:
    old "Alright, I better go now, before they close."
    new "好吧，我最好现在就走，不然就关门了。"

translate chinese chinese_8859976_245:
    old "Thank you [pla], I really appreciate it."
    new "谢谢你[pla]，我真的很感激。"

translate chinese chinese_7532721_246:
    old "Oh, it's nothing, don't worry. But, I better hurry up, it's getting a bit late."
    new "哦，没什么，别担心。不过，我得赶紧了，有点晚了。"

translate chinese chinese_2912105_247:
    old "So? How bad it is?"
    new "所以呢？有多严重？"

translate chinese chinese_0786152_248:
    old "Well, not that bad, but it will definitely take a few days of work."
    new "嗯，还不算太糟，但肯定得花几天时间来处理。"

translate chinese chinese_4777538_249:
    old "Oh [pla], that sounds like a lot of work, you don't have to do it."
    new "哦 [pla]，听起来好麻烦，你不用做的。"

translate chinese chinese_5629981_250:
    old "Oh, don't worry. It won't be nothing, and I will be here visiting you more often."
    new "哦，别担心。不会什么都没有的，我会经常来看你。"

translate chinese chinese_7015364_251:
    old "Hmm, I really can't belive you mom..."
    new "嗯，我真的不敢相信你，妈妈..."

translate chinese chinese_1115601_252:
    old "Anyway, so, let's finish the movie."
    new "总之，我们还是把电影看完吧。"

translate chinese chinese_2535377_253:
    old "Uhh, actually... I have to try and get to the hardware store before they close."
    new "呃，实际上……我得在他们关门之前去趟五金店。"

translate chinese chinese_6348257_254:
    old "I'm sorry [pla], it wasn't my intention to ruin your movie afternoon."
    new "对不起[pla]，我不是故意破坏你的电影下午时光的。"

translate chinese chinese_6289321_255:
    old "It's ok, I get why she's angry. No problem, besides, you didn't know this was going to happen."
    new "没事，我明白她为什么生气。没关系，反正你也不知道会发生这种事。"

translate chinese chinese_3410771_256:
    old "No problem."
    new "没问题。"

translate chinese chinese_5020668_257:
    old "Now, I better leave before they close the hardware store."
    new "现在，我最好在五金店关门前提前离开。"

translate chinese chinese_9789587_258:
    old "Sure, thanks again, honey."
    new "好的，再次谢谢你，亲爱的。"

translate chinese chinese_9867032_259:
    old "Hi Hinn."
    new "嗨，Hinn。"

translate chinese chinese_5976648_260:
    old "I'm fine, I guess..."
    new "我猜我还好……"

translate chinese chinese_2121643_261:
    old "Listen [pla], I wanted to apologize about the way I acted yesterday."
    new "听吧，[pla]，我想要为昨天的行为道歉。"

translate chinese chinese_3770606_262:
    old "Is just that things haven't been great at home this past few days."
    new "就是这几天家里情况不太好。"

translate chinese chinese_4174100_263:
    old "Mom has been stressed a lot, which means I've been stressed even more."
    new "妈妈压力很大，这意味着我压力更大了。"

translate chinese chinese_2134530_264:
    old "And I thought that maybe you and I could relax a little bit."
    new "我还以为我们可以放松一下呢。"

translate chinese chinese_1587298_265:
    old "But everytime we tried we kept being interrupted."
    new "但每次我们尝试都被人打断。"

translate chinese chinese_9949420_266:
    old "And it's just frustrating."
    new "这真是让人 frustrat-ing。"

translate chinese chinese_7364942_267:
    old "It's ok, I know how important our movie times are to you."
    new "没关系，我知道看电影对你来说很重要。"

translate chinese chinese_1760486_268:
    old "I completely get it, don't worry."
    new "我完全明白，别担心。"

translate chinese chinese_8703447_269:
    old "Thank you, [pla]!"
    new "谢谢你，[pla]！"

translate chinese chinese_7457148_270:
    old "By the way, I was thinking maybe I could drop by your house this afternoon."
    new "对了，我在想也许今天下午可以去你家一趟。"

translate chinese chinese_5226072_271:
    old "And start working on the repairs for the bathroom."
    new "然后开始修理浴室。"

translate chinese chinese_3092090_272:
    old "Maybe we could even finish that movie we started last time."
    new "也许我们可以把上次开始看的那部电影看完。"

translate chinese chinese_6156317_273:
    old "Oh, sorry [pla], actually, I'll be staying late here in school for some days."
    new "哦，对不起[pla]，实际上，我得在学校多待几天。"

translate chinese chinese_8471671_274:
    old "I have some extracurricular activities. Helping the teacher and stuff."
    new "我有些课外活动，帮老师忙之类的。"

translate chinese chinese_4523317_275:
    old "But, my mom will be there. So, why don't you go and start working on the repairs?"
    new "但是，我妈妈会在那里。所以，你为什么不开始修理工作呢？"

translate chinese chinese_8831056_276:
    old "That way it won't take you that long, and we can have time to..."
    new "这样就不会花你太长时间，然后我们还可以有时间……"

translate chinese chinese_1522200_277:
    old "Finish the movie when I'm done with my stuff here."
    new "我这儿完了之后把电影看完。"

translate chinese chinese_6674030_278:
    old "That's a good idea."
    new "这是个好主意。"

translate chinese chinese_5584988_279:
    old "Ok, sure, I'll go there and get started on the repairs."
    new "好的，没问题，我去那边开始修理。"

translate chinese chinese_8043521_280:
    old "Alright, then see you soon. And sorry about my mom once again."
    new "好吧，那很快见。再说一声对不起我妈妈。"

translate chinese chinese_9684953_281:
    old "Hey, don't worry, everything will be alright. See you later."
    new "嘿，别担心，一切都会好起来的。回头见。"

translate chinese chinese_1457636_282:
    old "Good morning, Mrs. Jade."
    new "早上好， jade 夫人。"

translate chinese chinese_5477328_283:
    old "Oh, Hi [pla]! Hi, how are you?"
    new "哦，嗨[pla]！你好吗？"

translate chinese chinese_3166639_284:
    old "Fine, thank you."
    new "好吧，谢谢。"

translate chinese chinese_0541559_285:
    old "How did it go? Were you able to get all the things you need for the repair?"
    new "怎么样了？你拿到所有需要的修理零件了吗？"

translate chinese chinese_7617314_286:
    old "Yes, I got everything without problems, and it was even cheaper than I expected."
    new "是的，我顺利搞到了一切，而且比预期的还要便宜。"

translate chinese chinese_9789988_287:
    old "Oh, thank God! Alright, then I will let you work, if you need something, please just let me know."
    new "哦，谢天谢地！好吧，那我就让你工作了，如果你需要什么，请告诉我。"

translate chinese chinese_8420009_288:
    old "Alright, I'll get to it."
    new "好吧，我这就去。"

translate chinese chinese_8919907_289:
    old "Hi Mrs. Jade, how are you?"
    new "嗨， jade 夫人，你好吗？"

translate chinese chinese_9377008_290:
    old "[pla]! Hi, how are you?"
    new "[pla]！嗨，你好吗？"

translate chinese chinese_8412867_291:
    old "Did you come to work in the bathroom?"
    new "你是来厕所工作的吗？"

translate chinese chinese_1492342_292:
    old "Yes, there is still work to be done."
    new "是的，还有很多工作要做。"

translate chinese chinese_0309887_293:
    old "Oh, thank you darling. Well, you know where the materials are, I won't bother you."
    new "哦，谢谢你亲爱的。好吧，你知道材料在哪里，我就不打扰你了。"

translate chinese chinese_9620934_294:
    old "Sure, I'll get to it."
    new "行，我这就去。"

translate chinese chinese_0170184_295:
    old "There's some work to do here. But, I know what I have to do, so, it should be easy."
    new "这里有些工作要做。但是，我知道我该做什么，所以应该很简单。"

translate chinese chinese_3802906_296:
    old "Well, I guess I'll get to it."
    new "好吧，我想我该开始了。"

translate chinese chinese_8397881_297:
    old "I'll try and finish this quickly."
    new "我会尽量快点搞定的。"

translate chinese chinese_0974372_298:
    old "Phew, I got a lot done today."
    new "呼，今天干了不少活。"

translate chinese chinese_3869299_299:
    old "Although, I still have quite a bit to do, anyway, at least this is something."
    new "虽然我还有很多事情要做，不过至少这算个开始。"

translate chinese chinese_6732966_300:
    old "It's kinda late, so, let's call it a day."
    new "都挺晚了，咱们今天就到这里吧。"

translate chinese chinese_7876117_301:
    old "But, she knew I was here, just next to her bedroom..."
    new "但是，她知道我就在她卧室旁边……"

translate chinese chinese_2246036_302:
    old "It's getting a bit late [pla], I think we just better call it a day."
    new "时间有点晚了[pla]，我想我们还是早点结束吧。"

translate chinese chinese_6940438_303:
    old "That's right Mrs. Jade, I'm actually happy with it, I got quite a bit done today."
    new "没错， jade太太，我其实挺高兴的，今天干了不少活。"

translate chinese chinese_2253723_304:
    old "But you are right, it's kinda late now, I better come back and continue another time."
    new "但是你说得对，现在确实有点晚了，我最好改天再来继续。"

translate chinese chinese_4003936_305:
    old "Well, it's great that you had progressed a lot, thanks, honey."
    new "嗯，你进步这么多真好，谢谢啦，亲爱的。"

translate chinese chinese_4403302_306:
    old "You have no idea of how helpful you are."
    new "你根本不知道你有多帮倒忙。"

translate chinese chinese_6483466_307:
    old "My pleasure."
    new "我的荣幸。"

translate chinese chinese_4860637_308:
    old "You're so sweet."
    new "你真甜。"

translate chinese chinese_8285949_309:
    old "By the way, don't forget to bring me the bill for the materials, so, that I can reimburse you."
    new "对了，别忘了把材料费的账单给我，我好报销你。"

translate chinese chinese_5197247_310:
    old "Sure thing. Well, good night Mrs. Jade."
    new "没问题。好了，晚安， jade 夫人。"

translate chinese chinese_0244880_311:
    old "Good night honey."
    new "晚安，亲爱的。"

translate chinese chinese_7527880_312:
    old "Hi [pla], you came to help mom with the bathroom?"
    new "嗨 [pla]，你是来帮妈妈收拾浴室的吗？"

translate chinese chinese_8578961_313:
    old "I wasn't expecting to see you here. I thought you had that extra work with the teacher."
    new "我没想到会在这里见到你，我还以为你跟老师有额外的工作呢。"

translate chinese chinese_3324856_314:
    old "Well, I did, but the teacher had something important to do."
    new "嗯，我是去了，但老师有重要的事要处理。"

translate chinese chinese_7365596_315:
    old "So, I'm free today."
    new "所以，我今天有空。"

translate chinese chinese_9718298_316:
    old "Oh, cool."
    new "哦，挺酷的。"

translate chinese chinese_6090110_317:
    old "Yeah, it is, and my mom is  not here, and she'll be out for a while... You know what this means, right?"
    new "是啊，我妈妈不在，而且她还会出去一段时间……你知道这意味着什么吧？"

translate chinese chinese_8239950_318:
    old "Uhh, you want to finish the movie?"
    new "呃，你想把电影看完吗？"

translate chinese chinese_5474859_319:
    old "Hahaha, no you dummy."
    new "哈哈，你傻瓜。"

translate chinese chinese_6213471_320:
    old "I mean that we're finally alone."
    new "我的意思是，我们终于单独在一起了。"

translate chinese chinese_2384907_321:
    old "We have some privacy to be a little... Intimate."
    new "我们有点隐私，可以稍微……亲密一下。"

translate chinese chinese_7556900_322:
    old "Oh... A- alright."
    new "哦……好吧。"

translate chinese chinese_7387326_323:
    old "So, what do you say? We should go up to my bedroom."
    new "那么，你怎么说？我们上去我的卧室吧。"

translate chinese chinese_9287344_324:
    old "Uhh... Are you sure about this? I mean what if your mom comes home and sees us again?"
    new "呃……你确定要这么做吗？我是说，如果你妈妈回家又看到我们怎么办？"

translate chinese chinese_4296741_325:
    old "Relax, she won't be home for a while. Besides, you heard what she told us, she's ok with us doing it."
    new "放松点，她一时半会儿回不来。再说，你听她说的，她同意我们这么做。"

translate chinese chinese_1709106_326:
    old "And we'll be in my bedroom."
    new "然后我们就去我的卧室。"

translate chinese chinese_1920456_327:
    old "I- I guess you're right."
    new "我——我想你是对的。"

translate chinese chinese_0019312_328:
    old "Stop worrying, just come with me."
    new "别担心，跟我来就行了。"

translate chinese chinese_3231761_329:
    old "I've been waiting for this for a while."
    new "我等这一刻已经很久了。"

translate chinese chinese_7272733_330:
    old "Every time we've tried to do it we've been getting interrupted."
    new "每次我们尝试的时候都会被干扰。"

translate chinese chinese_9729458_331:
    old "I was thinking we were never going to have a chance to do it again."
    new "我在想我们可能再也不会有这样的机会了。"

translate chinese chinese_3800858_332:
    old "Well, we're finally alone."
    new "好了，我们终于单独了。"

translate chinese chinese_7511923_333:
    old "Yeah, so, let's don't waste more time. I want to feel you inside."
    new "好吧，别浪费时间了。我想感受你的存在。"

translate chinese chinese_1285692_334:
    old "Well, I'm very happy we finally got to do it without being interrupted."
    new "嗯，我很高兴我们终于能不做被中断了。"

translate chinese chinese_1225374_335:
    old "Yeah, me too..."
    new "嗯，我也是……"

translate chinese chinese_8458958_336:
    old "Are you going home now?"
    new "你现在回家吗？"

translate chinese chinese_4121215_337:
    old "I think I'll go take a look at the bathroom before your mom gets home."
    new "我想在你妈妈回来之前去厕所看看。"

translate chinese chinese_9577133_338:
    old "Ok, then I guess I'll just stay here and organize my bedroom."
    new "好吧，那我就待在这里整理我的卧室吧。"

translate chinese chinese_8701758_339:
    old "Oh! Hi Mrs. Jade."
    new "哦！嗨， jade 夫人。"

translate chinese chinese_3012450_340:
    old "I didn't know you were home already."
    new "我不知道你已经回家了。"

translate chinese chinese_1286406_341:
    old "Hi [pla], I- I just arrived."
    new "嗨 [pla]，我刚到。"

translate chinese chinese_3921092_342:
    old "Did you come to check on the bathroom?"
    new "你是来检查洗手间的吗？"

translate chinese chinese_1801974_343:
    old "Uhh... I did, yeah, then I ran into Hinn, and we started talking."
    new "呃……我确实去了，然后遇到了赫因，我们就聊了起来。"

translate chinese chinese_7996382_344:
    old "Oh, that's ok."
    new "哦，那没事。"

translate chinese chinese_7915453_345:
    old "Actually, [pla], it's getting kind of late, and I'm sure you must be tired from working so... Hard."
    new "实际上，[pla]，已经挺晚了，你肯定工作得很辛苦……很辛苦。"

translate chinese chinese_3829466_346:
    old "Why don't you go home for now? And just come back another time?"
    new "你先回家吧？然后改天再来？"

translate chinese chinese_2637403_347:
    old "Are you sure? I'm not really all that tired, I could just work a little on the bathroom and..."
    new "你确定吗？我其实不太累，我可以先稍微整理一下浴室……"

translate chinese chinese_8080121_348:
    old "I'm sure. I think I would like to go to bed early today, so, it's fine if you take a day free."
    new "我确定。我觉得今天想早些睡觉，所以你请一天假也没关系。"

translate chinese chinese_7153487_349:
    old "Uh, ok, sure."
    new "哦，好的，行吧。"

translate chinese chinese_6173147_350:
    old "Then I guess I'll leave for today."
    new "那我今天就先离开了。"

translate chinese chinese_0189718_351:
    old "Sure honey, see you later."
    new "好的亲爱的，待会儿见。"

translate chinese chinese_4184793_352:
    old "Oh, hi Hinn! I didn't think I'd see you here. I thought you were going to be in school."
    new "哦，嗨，Hinn！没想到会在这里见到你。我还以为你还在上学呢。"

translate chinese chinese_6459649_353:
    old "Hi [pla], I only popped in to grab a couple of books, I'm on my way back."
    new "嗨 [pla]，我只是进来拿几本书，正准备回去。"

translate chinese chinese_8456284_354:
    old "Uhh, yeah."
    new "呃，是的。"

translate chinese chinese_4908697_355:
    old "Well, my mom's not home right now, but you can go ahead and get started."
    new "嗯，我妈妈现在不在家，但你可以先开始。"

translate chinese chinese_4487675_356:
    old "She'll be here in no time."
    new "她很快就到了。"

translate chinese chinese_8980228_357:
    old "Good, that way you'll finish quickly."
    new "好的，这样你会很快完成的。"

translate chinese chinese_4100412_358:
    old "So, that we'll have time to ourselves again."
    new "这样我们又能有自己的时间了。"

translate chinese chinese_1750078_359:
    old "Well, I gotta run, bye [pla]."
    new "好吧，我得走了，再见[pla]。"

translate chinese chinese_4699444_360:
    old "See you Hinn!"
    new "再见希恩！"

translate chinese chinese_3174960_361:
    old "Oh! Wow!"
    new "哦！哇！"

translate chinese chinese_5572410_362:
    old "Oh God! [pla]! W- What are you doing here?"
    new "哦天啊！[pla]！你在这里干什么？"

translate chinese chinese_9714032_363:
    old "I- I came to work on the bathroom."
    new "我，我是来修浴室的。"

translate chinese chinese_2925579_364:
    old "I didn't know you were here Mrs. Jade."
    new "我不知道你在这里， jade 夫人。"

translate chinese chinese_8191903_365:
    old "Uhh... I- it's fine, I suppose Hinn let you in while I wasn't in here, right?"
    new "呃……我——没关系吧，应该是我在外面的时候Hinn让你进来的吧？"

translate chinese chinese_4419616_366:
    old "Y- yeah, yeah, that's what happened..."
    new "嗯，嗯，就是那样发生的..."

translate chinese chinese_4535431_367:
    old "I'm sorry it's my fault, I didn't know you were already here. You just startled me, that's all."
    new "对不起，是我的错，我不知道你已经在这里了。我只是被吓了一跳而已。"

translate chinese chinese_4748123_368:
    old "I- I think I should leave now."
    new "我—我觉得我现在应该走了。"

translate chinese chinese_8556426_369:
    old "Yeah, you probably should."
    new "嗯，你probably应该这样。  \n\n(Note: I've kept \"probably\" in English as per the instruction to keep Latin names and phrases unchanged. If it needs to be translated, please let me know.)"

translate chinese chinese_9341428_370:
    old "R- Right... See you later Mrs. Jade."
    new "R- 好的... 翡翠女士，再见。"

translate chinese chinese_5447216_371:
    old "The gaul off the man!!!"
    new "这家伙的胆子也太大了！！！"

translate chinese chinese_8131123_372:
    old "I know, I know!! You don't need to keep telling me about it!"
    new "我知道了，我知道了！你不用一直提醒我！"

translate chinese chinese_0365859_373:
    old "I just can't believe your father sometimes!!!"
    new "我有时候真不敢相信你的爸爸！！！"

translate chinese chinese_5439584_374:
    old "So, this is why he never had any money and he kept coming up with excuses when it came to paying the alimony!"
    new "原来如此，这就是他为什么从来没钱，每次谈到抚养费都找借口的原因！"

translate chinese chinese_5817799_375:
    old "I know mom, I know, but again, I have nothing to do with it!!"
    new "我知道妈妈，我知道，但是这次我真的没参与！！"

translate chinese chinese_8049467_376:
    old "I didn't say you had to."
    new "我没说你非得这么做。"

translate chinese chinese_1847316_377:
    old "{b}*Sigh*{/b} I'm sorry Hinn, honey, I shouldn't be screaming like this."
    new "{b}*叹气*{/b} 对不起，hin，亲爱的，我不应该这样尖叫的。"

translate chinese chinese_9274050_378:
    old "But I just can't believe how brazen your father is!!!"
    new "但我真的不敢相信你爸爸这么嚣张！！！"

translate chinese chinese_6522668_379:
    old "Not only does he take his little girlfriend on some expensive vacation."
    new "他不仅带他的小女友去了一些昂贵的度假胜地。"

translate chinese chinese_8126886_380:
    old "But he's also asking her to marry him?!!!"
    new "但他也在求婚？！！"

translate chinese chinese_3150326_381:
    old "I mean! GOD!!"
    new "我靠！天啊！！"

translate chinese chinese_5226567_382:
    old "Oh, [pla]! H- Hi, I didn't notice when you came in."
    new "哦，[pla]！你进来我都没注意到。"

translate chinese chinese_0934827_383:
    old "[pla], H- Hi honey."
    new "[pla]，亲，你好。"

translate chinese chinese_2635759_384:
    old "H- hi Mrs. Jade, I came to work in the bathroom, is everything ok?"
    new "嗨， jade 夫人，我来浴室工作了，一切都好吗？"

translate chinese chinese_4225417_385:
    old "Well, not really."
    new "嗯，也说不上。"

translate chinese chinese_3772681_386:
    old "I- I think I need to let my head cool down a bit. I'll just leave you two alone so you can talk."
    new "我……我觉得我需要冷静一下。我就先离开，让你们俩好好谈谈。"

translate chinese chinese_2341766_387:
    old "Sorry you had to see that."
    new "对不起让你看到了那幕。"

translate chinese chinese_3739034_388:
    old "It's ok. So, I take it your father has been giving you some trouble?"
    new "没关系。所以，我猜你爸爸给你添了一些麻烦？"

translate chinese chinese_5412750_389:
    old "Hmph, you can say that twice."
    new "哼，这话可说得没错。"

translate chinese chinese_5251008_390:
    old "Listen [pla], we're very thankful that you're taking the time to come work on the bathroom repairs."
    new "听好了[pla]，我们非常感谢你能抽空来修理浴室。"

translate chinese chinese_9422690_391:
    old "But I don't think today's a good day. With my father acting like an idiot my mom's not in a very good mood."
    new "但是我觉得今天不太合适。我爸爸像个白痴一样闹腾，我妈妈心情不太好。"

translate chinese chinese_4074007_392:
    old "And I don't feel good either. Do you think you could come another time?"
    new "我也不舒服，你觉得能不能改个时间再来？"

translate chinese chinese_6908447_393:
    old "Of course, of course. Hey, don't worry about it, this is completely understandable."
    new "当然，当然。嘿，别担心，这完全能理解。"

translate chinese chinese_2558934_394:
    old "It's fine. I'll just leave, so, the two of you can rest, and I'll come back some other day."
    new "没关系，我就先走了，你们俩好好休息，我改天再来。"

translate chinese chinese_1974200_395:
    old "Thank you, I'm glad you understand."
    new "谢谢，很高兴你能理解。"

translate chinese chinese_0789893_396:
    old "Alright, then see you later."
    new "好吧，那回头见。"

translate chinese chinese_7136236_397:
    old "See you [pla], thank you again."
    new "再见[pla]，再次感谢。"

translate chinese chinese_6663391_398:
    old "Oh! dammit, the pipe got broken again, and now my pants are all wet."
    new "哦！该死，管道又坏了，现在我的裤子都湿了。"

translate chinese chinese_5442064_399:
    old "[pla]! Is everything ok?! I heard a loud noise."
    new "[pla]！没事吧？！我听到很大一声响。"

translate chinese chinese_2120010_400:
    old "Yeah, yeah, don't worry. Is just that one of the pipes broke and I got spilled with water. But I'm ok."
    new "好吧好吧，别担心。就是其中一个水管坏了，我被水溅到了。但我没事。"

translate chinese chinese_0039280_401:
    old "Oh, ok, that's somewhat of a relief."
    new "哦，这样就好多了。"

translate chinese chinese_9363557_402:
    old "Come with me, let's go to the other bathroom, so, you can towel dry."
    new "跟我来，我们去另一个洗手间，你可以用浴巾擦干。"

translate chinese chinese_3547664_403:
    old "Oh, don't worry, I'm fine really."
    new "哦，别担心，我真的没事。"

translate chinese chinese_1143300_404:
    old "Don't be silly, you don't want to catch a cold. Come with me."
    new "别傻了，你不想感冒吧。跟我来。"

translate chinese chinese_4325473_405:
    old "Okay, let me give you a hand with that."
    new "好吧，让我来帮你一下。"

translate chinese chinese_7485738_406:
    old "Uhh, I- I'm sorry Mrs. Jade, I don't know what to say. It's just that..."
    new "呃，我……对不起， jade 夫人，我不知道该说什么。就是觉得……"

translate chinese chinese_4663490_407:
    old "It's ok, it's ok, don't worry. You're a young man, after all."
    new "没事没事，别担心。你畢竟是個小伙子。"

translate chinese chinese_9990003_408:
    old "I- I'll take it as a compliment."
    new "我——我就当这是夸我了。"

translate chinese chinese_8970709_409:
    old "S- sure, t- thank you."
    new "好……谢谢。"

translate chinese chinese_1018608_410:
    old "Now, why don't you take those pants off? So, I'll throw them in the dryer."
    new "现在，为什么不把那条裤子脱下来呢？我帮你扔到烘干机里。"

translate chinese chinese_9678365_411:
    old "Uhh... Alright."
    new "呃……好吧。"

translate chinese chinese_7036276_412:
    old "(What?! He's not wearing anything!!)"
    new "（什么?! 他什么都没穿!!）"

translate chinese chinese_5112421_413:
    old "(Does he just go outside without underwear on?)"
    new "（他不会是光着屁股出去的吧？）"

translate chinese chinese_1547174_414:
    old "(But I must say, it's so... big! Is that what my daughters been putting in her?)"
    new "（但是不得不说，它真的很大！难道我女儿塞的就是这个？）"

translate chinese chinese_1771330_415:
    old "Uhh... Mrs. Jade?"
    new "呃…… jade太太？"

translate chinese chinese_2355698_416:
    old "What? Oh, right!"
    new "什么？哦，对了！"

translate chinese chinese_9036473_417:
    old "Just wait here, I'm going to put this on the dryer and see if there's a pajama bottom or something that you can use."
    new "你就在这等着，我去把这东西放进烘干机，看看有没有睡裤什么的你能穿的。"

translate chinese chinese_7244764_418:
    old "{i}OH MY GOD, HINN IS HERE!{/i}"
    new "{i}天啊，_HINT_在这里！{/i}"

translate chinese chinese_3663155_419:
    old "Uhh... H- hi honey! How did school go?"
    new "呃……嗨宝贝！学校怎么样？"

translate chinese chinese_3887143_420:
    old "Fine. Hey mom, are you going to be there much longer?"
    new "好吧。妈，你还要很久吗？"

translate chinese chinese_4195030_421:
    old "I kinda need to use the bathroom."
    new "我有点想去厕所。"

translate chinese chinese_1946618_422:
    old "{i}OH, NO, NO, NO... SHE CAN'T SEE US LIKE THIS...{/i}"
    new "哦不，不，不……她不能看到我们这个样子……"

translate chinese chinese_7835038_423:
    old "Uhhh! I'll be here for a while, honey."
    new "呃！我会在这里待一会儿，亲爱的。"

translate chinese chinese_9794416_424:
    old "I- I'm taking a shower and.... Uhh, I just got in. Sorry honey."
    new "我—我在洗澡，然后……嗯，刚到家。对不起亲爱的。"

translate chinese chinese_4027280_425:
    old "Oh, but I only need to use the toilet, so, it should be fine."
    new "哦，我只是要去厕所，应该没问题吧。"

translate chinese chinese_8026516_426:
    old "Uhh... Uhhh..."
    new "呃……呃……"

translate chinese chinese_2052803_427:
    old "{i}Shut! What are we going to do?!!{/i}"
    new "{i}闭嘴！我们该怎么办！！{/i}"

translate chinese chinese_1930718_428:
    old "{i}If she sees you here she'll flip her mind.{/i}"
    new "{i}如果让她看到你在这里，她会疯掉的。{/i}"

translate chinese chinese_2714298_429:
    old "{i}And with how difficult it's been to deal with her lately.{/i}"
    new "最近和她相处真是困难重重。"

translate chinese chinese_0679762_430:
    old "{i}We need to hide you!{/i}"
    new "{i}我们需要藏起来！{/i}"

translate chinese chinese_5967535_431:
    old "{i}Especially because you're naked from the waist down!{/i}"
    new "{i}特别是你下半身赤裸的情况下！{/i}"

translate chinese chinese_6538351_432:
    old "{i}I don't really know where I could hide Mrs. Jade.{/i}"
    new "{i}我真的不知道能在哪里藏起玉夫人。{/i}"

translate chinese chinese_9949995_433:
    old "Uhh, yeah, yeah, j- just give a sec, honey."
    new "嗯，好，好，等一下，宝贝。"

translate chinese chinese_5416675_434:
    old "Ughh, come on mom, you can just keep taking your shower."
    new "哎呀，妈妈，你就继续洗澡吧。"

translate chinese chinese_7307879_435:
    old "J- just give me a second!"
    new "just 给我一秒！"

translate chinese chinese_2735990_436:
    old "{i}Come with me! Hurry up!{/i}"
    new "{i}跟我来！快点！{/i}"

translate chinese chinese_2682626_437:
    old "Ok, you can come in!"
    new "好了，你可以进来了！"

translate chinese chinese_3334387_438:
    old "Mom, didn't [pla] come today?"
    new "妈妈，[pla]今天没来吗？"

translate chinese chinese_8458222_439:
    old "Uhh... N- no, he didn't. I guess he must be very busy with school."
    new "呃……不，他没来。我想他可能学习很忙吧。"

translate chinese chinese_3832882_440:
    old "Hmm, that makes sense."
    new "嗯，说得有道理。"

translate chinese chinese_0139907_441:
    old "He's very busy, so, we should just let him come when he can find the time."
    new "他很忙，所以我们还是等他有时间再来吧。"

translate chinese chinese_1950294_442:
    old "(Wait... What is this I'm feeling... Is [pla]'s cock between my legs?)"
    new "（等一下……这是什么感觉……[pla]的棒子在我腿间吗？）"

translate chinese chinese_1183596_443:
    old "(Holy cow! It's huge!)"
    new "（天啊！好大！）"

translate chinese chinese_9980054_444:
    old "(And still hard... Oh my God...)"
    new "（而且还是硬的……天啊……）"

translate chinese chinese_6452869_445:
    old "Uhh, w- what? With Hiashi?"
    new "呃，什、什么？和Hiashi？"

translate chinese chinese_1556433_446:
    old "I- I haven't."
    new "我——我没。"

translate chinese chinese_5785131_447:
    old "(Mmm... Damn, I feel so horny all of a sudden… I haven't been in an intimate situation like this in years...)"
    new "（嗯……见鬼，我突然好想……好几年没遇到这样的亲密情况了……)"

translate chinese chinese_2531721_448:
    old "I- I called him but he didn't answer."
    new "我给他打了电话但他没接。"

translate chinese chinese_5271636_449:
    old "Listen, I think it's best if you leave now. Here are your pants."
    new "听着，我觉得你现在离开最好。你的裤子在这里。"

translate chinese chinese_3244406_450:
    old "I'm sorry, I wasn't able to dry them for you."
    new "对不起，我没有帮你把它们晾干。"

translate chinese chinese_4907876_451:
    old "But Hinn might come back, and this situation is already difficult to explain."
    new "但是Hinn可能会回来，这种情况已经很难解释了。"

translate chinese chinese_2339716_452:
    old "It's ok, I'll just go straight home."
    new "没关系，我就直接回家吧。"

translate chinese chinese_1803895_453:
    old "Yeah, that's the best idea."
    new "嗯，那是个好主意。"

translate chinese chinese_3905152_454:
    old "Ok, see you another time Mrs. Jade. I'll come back later to keep working on the repairs"
    new "好的，下次见，玉女士。我回头再来继续修理。"

translate chinese chinese_8076455_455:
    old "That's good."
    new "那就好。"

translate chinese chinese_2579303_456:
    old "Listen, I'm glad you came."
    new "听着，我很高兴你来了。"

translate chinese chinese_8600173_457:
    old "Uhh, really? Why?"
    new "呃，真的吗？为什么？"

translate chinese chinese_7632522_458:
    old "Well, I wanted to talk to you. About what happened last time."
    new "嗯，我想和你谈谈上次发生的事。"

translate chinese chinese_2996318_459:
    old "Uh... sure."
    new "呃……好吧。"

translate chinese chinese_4740569_460:
    old "I'm so sorry [pla], I don't know what got into me."
    new "我真的对不起[pla]，我不知道我这是怎么了。"

translate chinese chinese_6834086_461:
    old "It's just that I've been so stressed out about so many things."
    new "只是最近压力太大了，事情太多。"

translate chinese chinese_5341967_462:
    old "You know, dealing with my husband's behavior, and Hinn's not been easy either."
    new "你知道的，应付我丈夫的行为就已经够难了，希恩也没好到哪里去。"

translate chinese chinese_4040506_463:
    old "So, I'm sorry, very, very sorry."
    new "所以，我很抱歉，非常非常抱歉。"

translate chinese chinese_6937906_464:
    old "I- it's ok, Mrs. Jade. Really, don't worry."
    new "我——没事的， jade 夫人。真的不用担心。"

translate chinese chinese_9981709_465:
    old "I understand, it was an accident. It's fine."
    new "我明白，那是一场意外。没事的。"

translate chinese chinese_7256864_466:
    old "Yes, I know that you and Hinn are going through a lot lately."
    new "是的，我知道你和Hinn最近经历了很多。"

translate chinese chinese_6347693_467:
    old "Uhh, and yesterday, it was mostly a misunderstanding that escalated quickly."
    new "嗯，昨天 mostly 是一个迅速升级的误会。"

translate chinese chinese_0282858_468:
    old "Oh, thank you [pla]! Thanks for understanding, you're such a good young man."
    new "哦，谢谢你[pla]！能理解我真是太好了，你真是个好人。"

translate chinese chinese_7035777_469:
    old "Thanks for saying that Mrs. Jade."
    new "谢谢你这么说， jade太太。"

translate chinese chinese_4062524_470:
    old "So, I'll just go to work in the bathroom. I think it shouldn't be long before I finish."
    new "所以我就在浴室里搞定吧。我想应该很快就能完事。"

translate chinese chinese_9612328_471:
    old "Sure, sure, also, thanks a lot for doing that."
    new "好吧好吧，还有，谢谢你这么做。"

translate chinese chinese_9671111_472:
    old "It's not a problem."
    new "这没问题。"

translate chinese chinese_2162387_473:
    old "Hi! Hello? Hinn? Mrs. Jade?"
    new "喂！有人吗？瑾？翡翠夫人？"

translate chinese chinese_6381507_474:
    old "That's weird, they're usually here in the afternoon."
    new "挺奇怪的，他们通常下午都在这里的。"

translate chinese chinese_0291321_475:
    old "Hello?!"
    new "喂？！"

translate chinese chinese_0137003_476:
    old "Hinn? Mrs. Jade? Anyone here?"
    new "hinne？ jade夫人？有人在吗？"

translate chinese chinese_1284152_477:
    old "This is odd."
    new "这很奇怪。"

translate chinese chinese_8051647_478:
    old "I guess they went out."
    new "我想他们出去了。"

translate chinese chinese_6520182_479:
    old "I suppose there's no problem if I go up and work on the bathroom."
    new "我想上去搞卫生应该没问题吧。"

translate chinese chinese_4170399_480:
    old "Oh my God! [pla]! W- what are you doing there?!"
    new "天啊！[pla]！你在那里干什么？！"

translate chinese chinese_1512305_481:
    old "S- sorry! I didn't see anything, I was looking for you and I just opened the door."
    new "对不起！我没看到任何东西，我只是来找你，然后就开门了。"

translate chinese chinese_5045295_482:
    old "I was going to work in the bathroom, but, I think I should just leave."
    new "我本来打算在卫生间里解决的，但我觉得我还是走吧。"

translate chinese chinese_2866575_483:
    old "Uhh, this is my fault, I'd forgotten you were coming today."
    new "呃，这是我的错，我忘了你今天会来。"

translate chinese chinese_9612357_484:
    old "So, I'll just dress up and you can get to work on the repairs."
    new "所以，我就穿好衣服，你可以开始修理了。"

translate chinese chinese_9214579_485:
    old "Can we just pretend this never happened?"
    new "我们能不能假装这件事从来没有发生过？"

translate chinese chinese_0079609_486:
    old "Uhhh, sure."
    new "呃，好吧。"

translate chinese chinese_0439878_487:
    old "(My God, he has another boner, and it's so big.)"
    new "（天啊，他又硬了，而且这么大。）"

translate chinese chinese_3955295_488:
    old "I- I think I'll start working on the bathroom, then."
    new "我—我想我还是开始装修浴室吧。"

translate chinese chinese_5981806_489:
    old "R- right, right. Well, you know where everything is."
    new "嗯，对对。反正你知道东西放在哪儿。"

translate chinese chinese_6809900_490:
    old "Wow, that was crazy..."
    new "哇，那真是太疯狂了……"

translate chinese chinese_9765658_491:
    old "Thank God, she is very calm and reasonable."
    new "谢天谢地，她很冷静也很理智。"

translate chinese chinese_0449193_492:
    old "Anyway, I better finish this as soon as possible."
    new "总之，我还是尽快搞定这件事吧。"

translate chinese chinese_2829558_493:
    old "Oh, hi Mrs. Jade, yeah, I'm done for today."
    new "哦，嗨， jade 夫人，是的，我今天完了。"

translate chinese chinese_8529689_494:
    old "It's almost done, I don't think it will be too long until I'm finished with the repairs."
    new "快好了，我觉得修理完应该不会太久。"

translate chinese chinese_4902584_495:
    old "That's great honey, thank you."
    new "太好了，宝贝，谢谢你。"

translate chinese chinese_8954727_496:
    old "And listen, about what you saw me doing today."
    new "还有，关于今天你看到我的那些事。"

translate chinese chinese_9158098_497:
    old "I'm sorry, I wouldn't have wanted you to see that. It must've been very awkward."
    new "对不起，我不希望你看那个。肯定很尴尬。"

translate chinese chinese_6629385_498:
    old "No, no, I'm the one who should be apologizing, this is your house after all."
    new "不不，应该道歉的是我，毕竟这是你的家。"

translate chinese chinese_6354610_499:
    old "I shouldn't have come into your bedroom without knocking."
    new "我本不该不敲门就进你的卧室。"

translate chinese chinese_8302426_500:
    old "Well, anyway, I'm sorry you had to see that."
    new "好吧，总之，不好意思让你看到那个。"

translate chinese chinese_0373452_501:
    old "I'm sure it must not be enjoyable to see an older woman in those... Circumstances."
    new "看到一个年纪大些的女人处在那种……情况下，肯定也不好受吧。"

translate chinese chinese_4163332_502:
    old "Ohh, of course not, you're a very beautiful woman."
    new "哦，当然了，你是个非常美丽的女人。"

translate chinese chinese_4348670_503:
    old "I- I mean...!"
    new "我——我的意思是...!"

translate chinese chinese_8927616_504:
    old "I get it, I get it, thank you [pla]."
    new "我知道了，知道了，谢谢你[pla]。"

translate chinese chinese_6381531_505:
    old "Oh, ok."
    new "哦，好的。"

translate chinese chinese_7507535_506:
    old "Well, I think I should get going."
    new "嗯，我想我该走了。"

translate chinese chinese_2725012_507:
    old "Yeah, it's getting a little late."
    new "是啊，有点晚了。"

translate chinese chinese_4222263_508:
    old "Have a good night Mrs. Jade."
    new "晚安， jade太太。"

translate chinese chinese_8138049_509:
    old "You too darling."
    new "你也是，亲爱的。"

translate chinese chinese_2601084_510:
    old "Oh, hi Mrs. Jade, Mrs. White."
    new "哦，嗨， jade太太，white太太。"

translate chinese chinese_3046581_511:
    old "Well hello there [pla]. Tell me jade? What is this fine young man doing here?"
    new "喂，[pla]。告诉我，翡翠？这个帅气的年轻人来这里干什么？"

translate chinese chinese_5200617_512:
    old "Well, do you remember I told you there was some damage in my bathroom?"
    new "嗯，你还记得我跟你说过我的浴室有些损坏吗？"

translate chinese chinese_3197971_513:
    old "Uh huh."
    new "嗯哼。"

translate chinese chinese_1127194_514:
    old "Well, I'll have you know that [pla] here was kind enough to volunteer to help me do the repairs."
    new "好吧，我要说的是，这里的[pla]自告奋勇要帮我修理。"

translate chinese chinese_8751596_515:
    old "He did. You know that with everything that's been going on with Hiashi things have been a little tight around here."
    new "他确实这么做了。你知道的，自从Hiashi的事情发生后，这里的情况一直有点紧张。"

translate chinese chinese_4426991_516:
    old "Uhmm."
    new "嗯。"

translate chinese chinese_3326607_517:
    old "Well, I couldn't really afford for a plumber to do it, but [pla] has been  perfect."
    new "嗯，我请不起水管工来做这件事，但[pla]做得完美无缺。"

translate chinese chinese_9234567_518:
    old "He's such a fine young man."
    new "他真是个不错的小伙子。"

translate chinese chinese_9617236_519:
    old "Oh, you don't have to tell me too much about it."
    new "哦，你不用说得太多。"

translate chinese chinese_8600085_520:
    old "I know full well what a helpful capable young man [pla] is. He actually helped me with something in the past."
    new "我清楚地知道[pla]是个多么能干又有帮助的年轻人。他过去确实帮过我一些事情。"

translate chinese chinese_6755927_521:
    old "Uh... I think I'll go work in the bathroom for now."
    new "呃……我想我还是去洗手间工作吧。"

translate chinese chinese_2147569_522:
    old "Sure honey, you know where everything is."
    new "当然了，亲爱的，你知道一切都在哪里。"

translate chinese chinese_3758071_523:
    old "With your permission, see you later, Mrs. White and Mrs Jade."
    new "如果您允许的话，再见了，怀特夫人和玉夫人。"

translate chinese chinese_4999325_524:
    old "So, tell me, what came of that whole business with Hiashi? Did you get him to pay your alimony?"
    new "所以，告诉我，和Hiashi那件事最后怎么样了？你让他支付赡养费了吗？"

translate chinese chinese_0709989_525:
    old "Ha! Not only he didn't pay, but he also took that little bimbo he calls his girlfriend on vacation."
    new "哈！不仅他没付钱，还带着他那个小女友去度假了。"

translate chinese chinese_2027489_526:
    old "No way!"
    new "不可能！"

translate chinese chinese_5954272_527:
    old "You're joking."
    new "你在开玩笑吧。"

translate chinese chinese_2784987_528:
    old "I wish, but that's not all of it. Apparently, while they were there."
    new "要是这样就好了，但还不止这些。看来他们在那里的时候。"

translate chinese chinese_5982800_529:
    old "He asked her to marry him!"
    new "他向她求婚了！"

translate chinese chinese_1611324_530:
    old "Oh my God! I can't believe it!"
    new "天啊！我不敢相信！"

translate chinese chinese_7007166_531:
    old "I remember he was a pig, but I didn't know just how low he could sink."
    new "我记得他以前就是个猪狗不如的家伙，但没想到他会这么烂。"

translate chinese chinese_5848797_532:
    old "Ugh, Tell me about it!"
    new "哎，说起来真是这样！"

translate chinese chinese_0961224_533:
    old "After he posted the photos with the engagement ring, he realized that they were public, so, he took them down."
    new "他在发了订婚戒指的照片后才发现那些照片是公开的，所以他就删了。"

translate chinese chinese_0350549_534:
    old "But by that point, it was already too late. We had already seen them."
    new "但到了那一步，就已经太晚了。我们已经看到他们了。"

translate chinese chinese_6195455_535:
    old "I just can't believe how irresponsible that man is."
    new "真不敢相信那个男人怎么这么不负责任。"

translate chinese chinese_5852502_536:
    old "{b}*Sigh*{/b} In a way, I can't either, I mean, ever since we broke up I never had any hopes that he would be exemplary."
    new "{b}*叹气*{/b} 说起来，我也不太敢相信，自从我们分手后，我就没抱任何希望他会变得很好。"

translate chinese chinese_6531453_537:
    old "But I didn't want to believe he would stand this low. It's always the same disappointing story when it comes to him."
    new "但我没想到他会这么没底线。每次都是同样的令人失望的故事。"

translate chinese chinese_3044513_538:
    old "And that's not all, I've been having terrible migraines, and insomnia because of it."
    new "而且这还不是全部，我一直在头痛，还因此失眠了。"

translate chinese chinese_8552933_539:
    old "Not to mention that Hinn's been a real handful as of late. I swear to God, I don't even know how to talk to her anymore."
    new "更别提希恩最近真是让人头疼。我发誓，我现在都不知道该怎么跟她说话了。"

translate chinese chinese_6902944_540:
    old "The whole thing has culminated in me being in constant panic and with my emotions all over the place!"
    new "这一切导致我一直处于恐慌状态，情绪也失控了！"

translate chinese chinese_8405212_541:
    old "I've been thinking that maybe I should go to a psychiatrist. Maybe I have some sort of anxiety, you know?"
    new "我一直在想，也许我应该去看心理医生。可能我有什么焦虑症，你知道的？"

translate chinese chinese_9838454_542:
    old "Well... I guess you could call it that..."
    new "嗯……大概可以这么说吧……"

translate chinese chinese_1142770_543:
    old "Well, duh, that's the name of it. What else could it be?"
    new "当然了，这就是它的名字。还能是什么？"

translate chinese chinese_8906235_544:
    old "For one thing, a lack of sex."
    new "怎么说呢，就是缺那事儿。"

translate chinese chinese_3286743_545:
    old "A what?!"
    new "什么鬼！？"

translate chinese chinese_9437328_546:
    old "You heard me, it sounds to me that what you have is a typical case of not fucking."
    new "你听我说，听起来你这是典型的没做爱。"

translate chinese chinese_1294821_547:
    old "Hey, I've been there myself, so, I know the symptoms."
    new "嘿，我自己也经历过，所以我知道那些症状。"

translate chinese chinese_7442457_548:
    old "You've been under a lot of stress lately, all of that accumulates in your body."
    new "你最近压力很大，这些都积压在身体里了。"

translate chinese chinese_7307543_549:
    old "And since you're not sexually active with anybody you just get anxious."
    new "因为你现在没人搞你就焦虑了。"

translate chinese chinese_3654310_550:
    old "Oh, come on! Be serious please..."
    new "哦，拜托！认真点行不行..."

translate chinese chinese_5446431_551:
    old "I am!"
    new "我是！"

translate chinese chinese_6236157_552:
    old "Listen, you're not having sex, but you still need to do it."
    new "听着，你不做爱，但还是得做这件事。"

translate chinese chinese_3824903_553:
    old "Add to that all of the other problems that you have to deal with."
    new "再加上你得处理的所有其他问题。"

translate chinese chinese_4644194_554:
    old "And you're a ticking time bomb!"
    new "而你就是一个定时炸弹！"

translate chinese chinese_1949098_555:
    old "You're repressed Jade, and believe me, that's not good for you."
    new "你太压抑了，玉，相信我，这对你没什么好处。"

translate chinese chinese_8004341_556:
    old "It's clear to me that what you need is a good fucking. That'll help you."
    new "我明白你需要的是好好干一场。这会对你有好处的。"

translate chinese chinese_8542261_557:
    old "Hahaha, yeah right. Who am I going to do it with?"
    new "哈哈，是啊。我还能和谁做呢？"

translate chinese chinese_8872971_558:
    old "I'm an old divorced woman."
    new "我是个离过婚的老女人。"

translate chinese chinese_6976298_559:
    old "Who's going to want to be with me?"
    new "谁会想和我在一起呢？"

translate chinese chinese_0503537_560:
    old "Oh! You know you're pretty. Any man would give an arm and a leg to have a chance to jump into your bed."
    new "哦！你知道你很漂亮。任何一个男人都愿意付出一切代价来有机会跳上你的床。"

translate chinese chinese_5120345_561:
    old "Yeah right."
    new "说得倒轻松。"

translate chinese chinese_2696970_562:
    old "Listen, girl, I'm not saying it just to mess with you. You need physical intimacy, it's good for you."
    new "听着，姑娘，我说这话可不是为了逗你。你需要身体上的亲密接触，这对你有好处。"

translate chinese chinese_7141540_563:
    old "If you don't do something about it you'll just start getting depressed and maybe even having anxiety attacks!"
    new "如果你不采取行动，你只会开始变得抑郁，甚至可能会出现焦虑发作！"

translate chinese chinese_9164167_564:
    old "You need to release all of those things you're holding in."
    new "你需要释放内心所有的那些东西。"

translate chinese chinese_6963151_565:
    old "Hmm, maybe you're right..."
    new "嗯，也许你说得对……"

translate chinese chinese_9138298_566:
    old "But even so? Who would I even be intimate with?"
    new "但是就算这样？我又能和谁亲密呢？"

translate chinese chinese_9520741_567:
    old "Ok Mrs. Jade, I've  finished for today."
    new "好了， jade 女士，我今天完成了。"

translate chinese chinese_1015318_568:
    old "Thank you, honey, you were done very quickly!"
    new "谢谢你，宝贝，你做得很快！"

translate chinese chinese_3653976_569:
    old "Yeah, I would've liked to do some more, but sadly I'm busy with some school work, so, I'm gonna have to go for today."
    new "是啊，我还想多做一会儿，但可惜我得忙着做作业，所以今天就先这样吧。"

translate chinese chinese_2841936_570:
    old "That's ok honey, see you another time."
    new "没关系宝贝，下次见。"

translate chinese chinese_7147061_571:
    old "By the way [pla], you should come to my house one of these days."
    new "对了，[pla]，你哪天来我家玩吧。"

translate chinese chinese_4540862_572:
    old "I can think of one or two things you could help me fix."
    new "我倒是想得起一两件你能帮我解决的事。"

translate chinese chinese_3409804_573:
    old "Yeah, haha... Maybe I'll go later."
    new "嗯，哈哈……也许我晚点再去吧。"

translate chinese chinese_6574031_574:
    old "Well, hope to see you soon. Bye."
    new "好吧，希望很快能见到你。再见。"

translate chinese chinese_0957403_575:
    old "Bye honey."
    new "拜拜甜心。"

translate chinese chinese_7840007_576:
    old "See you later sweetie."
    new "一会儿见甜心。"

translate chinese chinese_8859340_577:
    old "So, what were we talking about?"
    new "所以，我们在聊什么来着？"

translate chinese chinese_4165937_578:
    old "We were saying that you need to fuck!"
    new "我们刚才说你需要去爽一下！"

translate chinese chinese_8732572_579:
    old "Ah, right, that..."
    new "啊，对了，那个……"

translate chinese chinese_6622288_580:
    old "But you know, it's not as if I'm not doing anything, I masturbate often, and I feel like that's good."
    new "但是你知道，我也不是什么都不做，我经常自慰，感觉这样挺好的。"

translate chinese chinese_7163617_581:
    old "That won't be enough. Believe me, I have some experience with this."
    new "那不够的。相信我，我对这个有点经验。"

translate chinese chinese_6719828_582:
    old "What you need is a big, hard cock to ravage you."
    new "你需要的是一个大而硬的家伙来征服你。"

translate chinese chinese_1991068_583:
    old "So classy..."
    new "真有品位……"

translate chinese chinese_8950600_584:
    old "But then again, who's it going to be? I don't know anybody, and I'm too busy, and frankly tired, to go out looking for dates."
    new "但话说回来，会是谁呢？我根本不认识什么人，而且我也太忙了，坦白说也太累了，没空出去找对象。"

translate chinese chinese_8774075_585:
    old "Also, not just anybody can do it. It has to be someone that can rock you."
    new "而且，不是随便什么人都行的。那个人必须能让你心动。"

translate chinese chinese_3075889_586:
    old "Well, I'll tell you what, I think I know just the right guy to do it!"
    new "好吧，我告诉你，我觉得我知道正好合适的人选！"

translate chinese chinese_8226012_587:
    old "You do? Do we have any common friends that I don't know about?"
    new "你有吗？我们有没有什么共同的朋友我不知道的？"

translate chinese chinese_3316633_588:
    old "Listen, what you don't need is some old guy who's just going to get tired after a couple of pumps."
    new "听着，你不需要的是那种泵几下就累的老家伙。"

translate chinese chinese_1442786_589:
    old "You need a young, healthy stallion that's going to pump you full, and it's going to make you scream with his big dick."
    new "你需要一个年轻健康的公马，他会用他那大棒子把你填满，让你尖叫。"

translate chinese chinese_1949463_590:
    old "Hahaha, what are you saying?"
    new "哈哈，你说什么呢？"

translate chinese chinese_7891070_591:
    old "Ok, let's say that's what I need. Where am I going to find this young stallion that's going to do that to me?"
    new "好吧，就算这是我需要的。那我上哪儿去找这样一匹小公马来对我这样做呢？"

translate chinese chinese_5867741_592:
    old "Baby, you've already met him!"
    new "宝贝，你已经见过他了！"

translate chinese chinese_9526962_593:
    old "I have?"
    new "我有吗？"

translate chinese chinese_0375462_594:
    old "Well of course! He's always here at your house!"
    new "那当然了！他总是待在你家！"

translate chinese chinese_7462806_595:
    old "What? You mean [pla]?!! What are you talking about?!"
    new "什么？你是说[pla]？！你在说什么？！"

translate chinese chinese_5242522_596:
    old "What? What's so odd about that?"
    new "什么？那有什么奇怪的？"

translate chinese chinese_6373799_597:
    old "He's young, he's healthy, he's a very good kid."
    new "他年轻，健康，是个非常好的孩子。"

translate chinese chinese_2742062_598:
    old "And he has some experience."
    new "而且他有些经验。"

translate chinese chinese_6606700_599:
    old "He's just what you need!"
    new "他正是你需要的！"

translate chinese chinese_7698585_600:
    old "Yeah right! As if!"
    new "说得倒轻松！别开玩笑了！"

translate chinese chinese_2554288_601:
    old "Oh my God! Why not?!"
    new "天啊！为什么不行！"

translate chinese chinese_9372583_602:
    old "Well, for one thing, he's actually having sex with my daughter!"
    new "怎么说呢，他竟然在跟我女儿发生关系！"

translate chinese chinese_8810986_603:
    old "So, are they officially dating?"
    new "所以，他们正式交往了吗？"

translate chinese chinese_3837602_604:
    old "Well, it's complicated, it's one of those new things the kids are doing these days."
    new "嗯，这挺复杂的，是现在孩子们流行的新鲜事之一。"

translate chinese chinese_5160362_605:
    old "You know, having sex without an official relationship... I honestly don't understand."
    new "你知道吗，没有正式关系就发生性关系……我真心不懂。"

translate chinese chinese_3128430_606:
    old "Then there's no problem!"
    new "那就没问题了！"

translate chinese chinese_0567275_607:
    old "Of course you couldn't tell Hinn, but that's not too much of a big deal."
    new "当然你不能告诉hin，但这也不是什么大不了的事。"

translate chinese chinese_5302146_608:
    old "That's not all of it!"
    new "这还不是全部！"

translate chinese chinese_4215530_609:
    old "It isn't? What else then?"
    new "不是吗？那还有什么？"

translate chinese chinese_5800387_610:
    old "He's too young..."
    new "他太年轻了……"

translate chinese chinese_8282219_611:
    old "He could be my son!"
    new "他都快能当我儿子了！"

translate chinese chinese_2061727_612:
    old "Oh please! So what? Why do you think Hiashi is dating that nineteen-year-old hussy?"
    new "哦请！那又怎样？你觉得日ashi为什么會跟那个十九岁的骚女人交往？"

translate chinese chinese_9263554_613:
    old "It's because the sex it's really, really good, and she helps him feel good."
    new "是因为那性爱真的很棒，而且她帮他获得了很好的体验。"

translate chinese chinese_2126567_614:
    old "Also, you can use this as a chance to get back at that pig of your ex-husband's for what he's doing."
    new "而且，你也可以借此机会报复那个混账前夫。"

translate chinese chinese_5708398_615:
    old "Hmm, I don't know... That would be really inappropriate."
    new "嗯，我不知道……那样真的很不妥。"

translate chinese chinese_9182353_616:
    old "Oh! Stop acting as if I'm saying something crazy."
    new "哦！别装作我说了什么疯狂的话。"

translate chinese chinese_3066934_617:
    old "Aren't you?"
    new "你不也是吗？"

translate chinese chinese_7339203_618:
    old "Please! With all of the time that he's been in here."
    new "求你了！他在这里待了那么久。"

translate chinese chinese_1702188_619:
    old "Can you honestly tell me that you've never thought about having your way with him?"
    new "你真能告诉我你从没想过要占有他吗？"

translate chinese chinese_2363954_620:
    old "Or him having his way with you. Whichever way you prefer."
    new "或者他占你便宜。看你喜欢哪种说法了。"

translate chinese chinese_2657170_621:
    old "Uhhh."
    new "呃呃呃。"

translate chinese chinese_6451322_622:
    old "Wait! Wait a minute!"
    new "等一下！等一下！"

translate chinese chinese_7720248_623:
    old "Don't tell me you already did something with him!"
    new "别告诉我你已经和他做什么了！"

translate chinese chinese_7456045_624:
    old "No, no, no, no!"
    new "不，不，不，不！"

translate chinese chinese_2910471_625:
    old "Nothing like what you're thinking."
    new "完全不是你想的那样。"

translate chinese chinese_2710301_626:
    old "But you did do something didn't you?"
    new "但是你确实做了些什么吧？"

translate chinese chinese_5622645_627:
    old "You're unbelievable."
    new "你真是不可思议。"

translate chinese chinese_9320737_628:
    old "Ok, the other day as he was doing something in the bathroom one of the pipes broke, and his pants got wet."
    new "好的，那天他在浴室里做事的时候，有一根管子破了，他的裤子湿了。"

translate chinese chinese_0915542_629:
    old "So, I told him that maybe he should take them off just so that I could throw them in the dryer."
    new "所以我就跟他说，也许他可以把它们脱下来，让我把它们放进烘干机里。"

translate chinese chinese_6161792_630:
    old "I like where this is going."
    new "我喜欢这个发展方向。"

translate chinese chinese_3542767_631:
    old "Well, the thing is that... For some reason, he had a boner, and wasn't wearing drawls."
    new "好吧，问题是……不知怎么的，他硬了，而且没穿内裤。"

translate chinese chinese_9155540_632:
    old "Oh my God and you saw his boner?!"
    new "天啊，你还看到他的硬起来了？！"

translate chinese chinese_9770639_633:
    old "Hahaha, this is great! It was huge wasn't it?"
    new "哈哈哈哈哈，太棒了！那可是很大吧？"

translate chinese chinese_7617967_634:
    old "You're terrible, you know that?"
    new "你真是糟糕透了，这你知道吗？"

translate chinese chinese_6626974_635:
    old "... But yes, he was very big. Like, very, very big."
    new "……但没错，他确实很大。非常、非常大。"

translate chinese chinese_9527563_636:
    old "But that's it, nothing else happened."
    new "但是就这样，没发生其他事情。"

translate chinese chinese_6680551_637:
    old "At all..."
    new "一点也没有..."

translate chinese chinese_4031097_638:
    old "It doesn't matter, this is great!"
    new "没关系，这太棒了！"

translate chinese chinese_4248083_639:
    old "Don't you see? He got a boner because of you! He already thinks you're hot!"
    new "你看不出来吗？他硬起来是因为你！他已经觉得你很辣了！"

translate chinese chinese_7476127_640:
    old "But that kid's too timid to do anything, he won't make a move unless he thinks you want it too."
    new "但那小子太胆小了，除非他认为你也愿意，否则他不会采取行动的。"

translate chinese chinese_0962278_641:
    old "But that's not a problem, I can deal with that."
    new "但这不是问题，我能应付。"

translate chinese chinese_1183771_642:
    old "Wait! What are you going to do?!"
    new "等一下！你要干什么？！"

translate chinese chinese_8219987_643:
    old "Don't worry, I won't do anything you don't want."
    new "放心，我不会做你不想做的事的。"

translate chinese chinese_2881219_644:
    old "Wait, don't do anything dumb."
    new "等一下，别做傻事。"

translate chinese chinese_6201665_645:
    old "Me? I'll just take care of this for you, that's all."
    new "我？我就帮你处理一下这个，就这么简单。"

translate chinese chinese_8669178_646:
    old "And I better leave before you change your mind."
    new "我还是在你改变主意前离开比较好。"

translate chinese chinese_6003628_647:
    old "Oh my God, what did I get myself into?"
    new "天啊，我这是闯进什么乱子了？"

translate chinese chinese_7669343_648:
    old "Hi [mo1]."
    new "你好[mo1]。"

translate chinese chinese_8982653_649:
    old "Sweetie, Mrs. White's outside, she says she has something to talk to you about."
    new "甜心，怀特夫人在外面，她说有事要和你谈谈。"

translate chinese chinese_6252780_650:
    old "She wants to talk to me?"
    new "她想和我谈谈？"

translate chinese chinese_0531307_651:
    old "Yes, she says it's something about your friend Mike."
    new "是的，她说这和你的朋友迈克有关。"

translate chinese chinese_7143717_652:
    old "I see, well, I'll be right out."
    new "我明白了，那我马上就出来。"

translate chinese chinese_1651974_653:
    old "Ok, honey."
    new "好啦，亲爱的。"

translate chinese chinese_6479599_654:
    old "Hi Mrs. White, is everything alright with Mike?"
    new "白太太，迈克一切都好吗？"

translate chinese chinese_9616124_655:
    old "Hi honey, yeah, yeah, don't worry. It's just that I need you to come with me to my house for a second."
    new "亲爱的，别担心，就是需要你来我家一趟。"

translate chinese chinese_3927084_656:
    old "There's something I want you to talk about with Mike."
    new "有一件事我想让你和迈克谈谈。"

translate chinese chinese_6363046_657:
    old "Me? Is it something serious?"
    new "我？是有什么严重的事吗？"

translate chinese chinese_7500013_658:
    old "Not really, but it's more of a guy thing, so, I think it would be better if he hears it from another man."
    new "不是特别在意，但这更像是男人之间的话题，所以我觉得还是让他从另一个男人那里听到比较好。"

translate chinese chinese_4750907_659:
    old "Oh, ok, I guess that's fine. Sure, I'll come with you."
    new "哦，好吧，我想这样也行。好的，我跟你一起去。"

translate chinese chinese_5951089_660:
    old "So, it's Mike in his bedroom?"
    new "所以，是迈克在他的卧室里？"

translate chinese chinese_2357720_661:
    old "No, actually, I must admit I lied to you, he's not in the house, and he won't be for a while."
    new "不，其实我必须承认我骗了你，他不在家里，短时间内也不会回来。"

translate chinese chinese_2698882_662:
    old "Then how am I supposed to talk to him?"
    new "那我该怎么跟他说话？"

translate chinese chinese_6524282_663:
    old "Well, to be honest with you [pla], I don't actually want you to talk to Mike."
    new "好吧，老实说，[pla]，我其实不想让你去跟迈克说话。"

translate chinese chinese_9789726_664:
    old "You don't?"
    new "你不想？"

translate chinese chinese_1786547_665:
    old "No, the person I want you to help is a friend of mine, who needs something from you."
    new "不，我想让你帮忙的人是我的朋友，她需要你的帮助。"

translate chinese chinese_6700972_666:
    old "Who is it?"
    new "是谁？"

translate chinese chinese_4210657_667:
    old "Well honey, it's Jade, there's something that she needs from you."
    new "亲爱的，是 jade，她有些东西需要从你这里得到。"

translate chinese chinese_8865853_668:
    old "Did anything happen to her?"
    new "她出什么事了吗？"

translate chinese chinese_2206300_669:
    old "Not yet."
    new "还不到时候。"

translate chinese chinese_5245115_670:
    old "I have to tell you, Mrs. White, you're not really making a lot of sense here, you know?"
    new "我得告诉你，怀特夫人，你这么说有点不太通吧？"

translate chinese chinese_0118616_671:
    old "That's because I haven't really told you anything."
    new "那是因为我还没告诉你任何事情。"

translate chinese chinese_1228893_672:
    old "Listen [pla], the thing I want you to do, is to have sex with Jade."
    new "听着[pla]，我要你做的事情是和 Jade 发生关系。"

translate chinese chinese_5565062_673:
    old "What?!"
    new "什么?!"

translate chinese chinese_7168117_674:
    old "Just as you hear it, you are going to help Jade by fucking her."
    new "就像你听到的，你要帮 Jade 的方式就是和她发生关系。"

translate chinese chinese_2838002_675:
    old "Why would I do that?"
    new "我为什么要那样做？"

translate chinese chinese_5171445_676:
    old "Well, there's a lot to explain, but basically, Jade's been under a lot of pressure."
    new "嗯，有很多要解释的，但基本上， jade 面临很大压力。"

translate chinese chinese_0449761_677:
    old "She wouldn't admit it, but she's repressed. So, she really needs to release that, you know what I mean?"
    new "她自己不会承认，但她很压抑。所以，她真的需要释放一下，你知道我的意思吧？"

translate chinese chinese_5486996_678:
    old "And since I know how gifted you are in that regard, I thought that you're the right person to help her."
    new "而且我知道你在这方面很有天赋，所以我觉得你是帮助她的合适人选。"

translate chinese chinese_6380977_679:
    old "This is crazy Mrs. White, I mean, how do we even know that Mrs. Jade would want to do anything with me?"
    new "这太疯狂了，怀特太太，我的意思是，我们怎么知道 jade 太太会想和我有任何瓜葛？"

translate chinese chinese_1075344_680:
    old "Oh, don't you play dumb with me!"
    new "哦，别跟我装傻！"

translate chinese chinese_4909985_681:
    old "I already know you two have done a couple of things already."
    new "我早就知道你们俩已经做过一些事情了。"

translate chinese chinese_9221624_682:
    old "So, listen carefully, this is what's going to happen..."
    new "所以，听好了，接下来会发生这样的事情..."

translate chinese chinese_2182356_683:
    old "Hey, where have you been?"
    new "嘿，你去哪儿了？"

translate chinese chinese_9393532_684:
    old "I was just having a little word with [pla], you know, getting him onboard and what not."
    new "我刚才只是和[pla]聊了聊，你知道的，就是让他配合一下。"

translate chinese chinese_9511162_685:
    old "Oh my God! Did you actually bring him here?"
    new "天啊！你真的把他带到这里来了？"

translate chinese chinese_2837195_686:
    old "I can't believe I let you talk me into doing something this crazy!"
    new "真不敢相信我让你说服我去干这么疯狂的事！"

translate chinese chinese_4896689_687:
    old "Well, he's already here, so, no turning back now."
    new "反正他已经来了，现在也没办法回头了。"

translate chinese chinese_0347941_688:
    old "Listen, I already talked to him, so, you don't need to worry about anything other than enjoying yourself."
    new "听着，我已经跟他谈过了，所以你只需要尽情享受就行了，不用操心其他事。"

translate chinese chinese_0185862_689:
    old "I don't want you thinking about anything stressful, or about your daughter."
    new "我不希望你去想任何让你压力大的事情，或者想着你的女儿。"

translate chinese chinese_3886268_690:
    old "I especially don't want you thinking about that asshole Hiashi!"
    new "我尤其不想让你想到那个混蛋Hiashi！"

translate chinese chinese_1951410_691:
    old "All you need to do is focus on your own pleasure. Ok?"
    new "你只需要专注于自己的快感。好吗？"

translate chinese chinese_1904725_692:
    old "Good, then I'll tell [pla] to come in."
    new "好的，那我就让[pla]进来。"

translate chinese chinese_1937230_693:
    old "Hey [pla]! You can come in now honey!"
    new "嘿[pla]！你可以进来了宝贝！"

translate chinese chinese_4032187_694:
    old "H- hi Mrs. Jade..."
    new "嗨... jade太太..."

translate chinese chinese_7039118_695:
    old "H- hi [pla]."
    new "嗨，[pla]。"

translate chinese chinese_4692680_696:
    old "Oh! What is this tension? You have to loosen up!"
    new "哦！这是什么紧张感？你得放松点！"

translate chinese chinese_1220802_697:
    old "Well, I think this might help a little."
    new "嗯，我觉得这可能会有点帮助。"

translate chinese chinese_6838649_698:
    old "Look at that, isn't that just an amazing dick?"
    new "看看那个，那不是棒极了么？"

translate chinese chinese_1618167_699:
    old "I bet he's even bigger than you remember isn't Jade?"
    new "我敢打赌，他甚至比你记得的还要大，不是吗， jade？"

translate chinese chinese_8231452_700:
    old "W- well..."
    new "嗯……"

translate chinese chinese_4864457_701:
    old "And it's so thick, hot, and hard..."
    new "而且它那么浓稠、火热、坚硬……"

translate chinese chinese_4770490_702:
    old "Hmph, slrrrrp!"
    new "哼，吸溜！"

translate chinese chinese_8248105_703:
    old "My God [pla] you really have the best tasting dick in the world."
    new "我的天 [pla] 你的鸡巴真是全世界最好吃的。"

translate chinese chinese_2642125_704:
    old "It's so great!"
    new "太棒了！"

translate chinese chinese_8283522_705:
    old "I could suck it all day!"
    new "我可以整天都这样！"

translate chinese chinese_8375351_706:
    old "I bet you want to have a taste too, don't you Jade?"
    new "我打赌你也很想尝一下，对吧， Jade？"

translate chinese chinese_3125861_707:
    old "It's great, believe me!"
    new "真的很棒，相信我！"

translate chinese chinese_5605553_708:
    old "But he's mine first!"
    new "但他本来就是我的！"

translate chinese chinese_1155227_709:
    old "I hope this has helped you take some tension off."
    new "希望这能帮你缓解一些紧张。"

translate chinese chinese_4105189_710:
    old "Now that we've broken the ice, you can do it at her house."
    new "既然已经破冰了，你可以在她家里进行。"

translate chinese chinese_3990597_711:
    old "Oh come on, Is that a problem?"
    new "哦，拜托，这有问题吗？"

translate chinese chinese_7306735_712:
    old "Come on, you both enjoyed it and it's a win win."
    new "得了，你们俩都挺享受的，这对你俩都有好处。"

translate chinese chinese_3307953_713:
    old "You [pla], did you like to had your dick sucked by a hot MILF as Jade?"
    new "你[pla]，喜欢被像 Jade 这样的热辣 MILF 吸过吗？"

translate chinese chinese_2369184_714:
    old "Uhh, y- yes..."
    new "呃，是的……"

translate chinese chinese_1106981_715:
    old "And you Jade? Did you enjoyed with a real big cock in your mouth?"
    new "那你呢， Jade？你觉得用真家伙在嘴里感觉如何？"

translate chinese chinese_5366663_716:
    old "Well that's it, enjoy it together and don't make a fuss about it."
    new "好吧，一起享受吧，别大惊小怪的。"

translate chinese chinese_0145742_717:
    old "Sadly, I won't be able to be there with you guys every time you fool around, but Jade still needs some stress relief."
    new "遗憾的是，我不能每次你们玩乐的时候都陪在你们身边，但 jade 还是需要一些减压的方式。"

translate chinese chinese_1491602_718:
    old "So, I trust that you'll give it to her whenever she needs it."
    new "所以，我相信你会在她需要的时候给她的。"

translate chinese chinese_4021492_719:
    old "Now, Mike's about to come home, so, sadly we'll have to see each other again another time."
    new "现在迈克快回家了，所以我们下次再见面吧。"

translate chinese chinese_3874281_720:
    old "But I've enjoyed a lot this little meeting."
    new "但是我很享受这次小聚。"

translate chinese chinese_8517740_721:
    old "I guess I have to get going too."
    new "我想我也得走了。"

translate chinese chinese_4192782_722:
    old "Y- yeah, uhh, me too. But before we leave."
    new "嗯， uh，我也是。但在我们离开之前。"

translate chinese chinese_2329819_723:
    old "Uhh... T- thank you [pla]."
    new "呃……谢谢[pla]。"

translate chinese chinese_1108053_724:
    old "Uhmm... Sure, no problem."
    new "嗯……好啊，没问题。"

translate chinese chinese_7245570_725:
    old "I'm happy I'm able to help you Mrs. Jade."
    new "我很高兴能帮上忙， jade太太。"

translate chinese chinese_9991584_726:
    old "That's great, alright, see you later guys."
    new "那太好了，回头见。"

translate chinese chinese_9213035_727:
    old "Wow, that was nice, isn't it?"
    new "哇，那感觉真不错，是不是？"

translate chinese chinese_5559513_728:
    old "Phew, I wasn't expecting that to be honest.."
    new "呼，说实话，我没想到会这样。"

translate chinese chinese_5969217_729:
    old "Heh, well, I figured that if I was going to do it, I should just go ahead and try."
    new "嘿嘿，我想如果我要做的话，干脆就试试吧。"

translate chinese chinese_3620663_730:
    old "I'm glad you did seem to enjoy it."
    new "很高兴你似乎很享受。"

translate chinese chinese_5680217_731:
    old "I've been thinking a lot about what Mrs. White said, and..."
    new "我一直在想怀特太太说的话，而且..."

translate chinese chinese_0087711_732:
    old "I think she's right, I need to relax a bit more."
    new "我觉得她说得对，我需要放松一点。"

translate chinese chinese_8010500_733:
    old "So, I'm happy I took the leap."
    new "所以，我很高兴我迈出了这一步。"

translate chinese chinese_0061975_734:
    old "Well, I'm happy I can be of help to you."
    new "嗯，能帮到你我也很开心。"

translate chinese chinese_6090952_735:
    old "You're a lot more than that honey."
    new "你可不止这些甜心。"

translate chinese chinese_7435052_736:
    old "About what just happened, you can think of it as your reward for all of the hard work you've been doing lately."
    new "关于刚才发生的事，你可以把它当作对你最近辛苦工作的奖励。"

translate chinese chinese_1598976_737:
    old "Well, now, if you'll excuse me, I think I'll lay down for a bit, honey."
    new "好吧，亲爱的，我想我得躺一会儿了。"

translate chinese chinese_7092614_738:
    old "Sure, I'll see you later."
    new "好的，待会儿见。"

translate chinese chinese_1053458_739:
    old "Sure, good bye."
    new "行吧，再见。"

translate chinese chinese_0374618_740:
    old "I can't believe that actually happened."
    new "真不敢相信那真的发生了。"

translate chinese chinese_6531694_741:
    old "Oh God, how do I always get into this."
    new "哦上帝，我怎么总是陷入这种境地。"

translate chinese chinese_0876167_742:
    old "Hi? Mrs. Jade? Hinn? I came to work in the bathroom!"
    new "喂？玉太太？hin？我来浴室工作了！"

translate chinese chinese_8375821_743:
    old "Mrs. Jade?"
    new "jade太太？"

translate chinese chinese_2750480_744:
    old "Uhh, This feels like Deja Vu..."
    new "呃，这感觉像是 Déjà Vu……"

translate chinese chinese_2956027_745:
    old "Hmm, I don't like where this is going..."
    new "嗯，我觉得这事不太妙……"

translate chinese chinese_5512121_746:
    old "O- oh! Mrs. Jade, Mrs. White, you're here... Hi."
    new "哦！翡翠太太，怀特太太，你们来了……嗨。"

translate chinese chinese_4885084_747:
    old "Nevermind that [pla], we've been waiting for you."
    new "别管那个[pla]了，我们一直在等你。"

translate chinese chinese_8758434_748:
    old "W- waiting?"
    new "等、等着？"

translate chinese chinese_3591924_749:
    old "Well sweetie, Jade was thinking maybe it was time to get drilled by your huge cock."
    new "好吧，甜心， jade 想也许是你用大 cock 钻她的时候了。"

translate chinese chinese_2009981_750:
    old "... (Holly Shit...)"
    new "...（天呐...）"

translate chinese chinese_2825817_751:
    old "So, I thought I should be here to give her a little nudge forward."
    new "所以，我觉得我应该在这里给她一点鼓励。"

translate chinese chinese_6656009_752:
    old "Now honey, don't just stand there looking lost."
    new "现在亲爱的，不要站在那里一副茫然的样子。"

translate chinese chinese_0661706_753:
    old "Come here and fuck us [pla]!"
    new "过来操我们 [pla]！"

translate chinese chinese_9916092_754:
    old "Ok, I'm glad I was able to be of help to you Jade."
    new "好吧，我很高兴能帮到你， Jade。"

translate chinese chinese_3329047_755:
    old "I suppose the next time you two won't need my assistance."
    new "我想下次你们两个就不用我帮忙了。"

translate chinese chinese_6337175_756:
    old "But, don't be selfish, you can always invite me to spend a sexy afternoon like today."
    new "但是，别那么自私嘛，你可以随时邀请我度过像今天这样的性感下午。"

translate chinese chinese_2765924_757:
    old "For sure I will."
    new "肯定的。"

translate chinese chinese_0823072_758:
    old "Nice! So, I guess it's ok if I leave for now."
    new "不错！那我想我现在离开也没问题吧。"

translate chinese chinese_7517076_759:
    old "Ok, but again, thank you so much for all your help."
    new "好的，但还是要非常感谢你的帮助。"

translate chinese chinese_8647320_760:
    old "You were completely right about everything."
    new "你说的一切都完全正确。"

translate chinese chinese_9494061_761:
    old "Well, I'm always right, girl, you know that."
    new "好吧，我总是对的，你知道的。"

translate chinese chinese_1950935_762:
    old "I'll be seeing you later [pla]."
    new "待会儿见，[pla]。"

translate chinese chinese_6496639_763:
    old "Well, I guess it's too late for you to work on the bathroom now."
    new "嗯，我想你现在再装修浴室就太晚了。"

translate chinese chinese_8393974_764:
    old "And you must be very tired anyway, so, I suppose we'll see each other another time."
    new "而且你肯定也很累了，所以我想我们下次再见面吧。"

translate chinese chinese_4575612_765:
    old "Yeah, don't worry. I'll be back soon..."
    new "嗯，别担心，我很快就会回来的..."

translate chinese chinese_4460419_766:
    old "See you later Mrs. Jade."
    new "再见了， jade 夫人。"

translate chinese chinese_0494414_767:
    old "See you later honey."
    new "一会儿见宝贝。"

translate chinese chinese_4550994_768:
    old "Ok! That's it! I think I'm done!"
    new "好！够了！我觉得我受够了！"

translate chinese chinese_9345751_769:
    old "Finally."
    new "终于。"

translate chinese chinese_4992524_770:
    old "I think I should go tell Mrs. Jade."
    new "我觉得应该去告诉 jade 夫人。"

translate chinese chinese_3094525_771:
    old "Alright Mrs. Jade, I finished fixing the shower."
    new "好了， jade 夫人，我修好淋浴了。"

translate chinese chinese_7135736_772:
    old "You can now use it as before, it should be completely fine."
    new "你现在可以像以前一样使用它了，应该完全没有问题。"

translate chinese chinese_5384473_773:
    old "Really? That's very good."
    new "真的吗？那很好。"

translate chinese chinese_2027747_774:
    old "Yeah, why don't you come with me so you can see it?"
    new "好吧，你为什么不跟我一起来看看呢？"

translate chinese chinese_6187489_775:
    old "You see? It's fine now."
    new "你看？现在没事了。"

translate chinese chinese_0895913_776:
    old "Thanks great! Thank you so much [pla]!"
    new "太好了，谢谢你[pla]！"

translate chinese chinese_4353778_777:
    old "W- what? What are you doing Mrs. Jade?"
    new "什、什么？ jade 夫人你在干什么？"

translate chinese chinese_5544333_778:
    old "Well, since the shower's now working, I figured I should give it a try, don't you think?"
    new "反正现在淋浴能用了，我觉得应该试试，你觉得呢？"

translate chinese chinese_0290911_779:
    old "And since you've been working so hard, you should also try it, so you can relax a little bit after all of that hard work."
    new "因为你这么努力工作了，也应该试试，这样辛苦过后可以稍微放松一下。"

translate chinese chinese_5784020_780:
    old "So, now you and I are going to take a shower together."
    new "所以，现在你要和我一起洗澡了。"

translate chinese chinese_2008820_781:
    old "Now take off your clothes and get in the shower [pla]."
    new "现在脱掉衣服，去洗澡吧[pla]。"

translate chinese chinese_8304382_782:
    old "Ok, honey, I guess that's it with the bathroom."
    new "好吧，宝贝，我想浴室的事就到这里了。"

translate chinese chinese_2770999_783:
    old "Thanks a lot for what you did."
    new "非常感谢你的帮忙。"

translate chinese chinese_9004649_784:
    old "I don't know how much it would've cost to fix it if I had contacted a plumber."
    new "我不知道如果找 plumber 来修要花多少钱。"

translate chinese chinese_6690464_785:
    old "No problem Mrs. Jade, I'm happy to help."
    new "没问题， jade太太，我很乐意帮忙。"

translate chinese chinese_8382977_786:
    old "Oh, you did a lot more than that."
    new "哦，你可不止做了这些。"

translate chinese chinese_7583435_787:
    old "And I hope you know I expect to see you around here soon."
    new "而且我希望你知道我期待很快再见到你。"

translate chinese chinese_5154825_788:
    old "Please remember to come and pay me a visit once in a while."
    new "请记得偶尔过来找我玩。"

translate chinese chinese_3184477_789:
    old "I know you'll enjoy it."
    new "我知道你会喜欢的。"

translate chinese chinese_5236023_790:
    old "Sure, I'll come by soon."
    new "好的，我很快过来。"

translate chinese chinese_6488475_791:
    old "That's good honey, very good."
    new "很好宝贝，非常好。"

translate chinese chinese_5358698_792:
    old "I suppose you have to go?"
    new "你得走了吗？"

translate chinese chinese_3151192_793:
    old "Yeah, it's a little bit late, and I'm really tired..."
    new "是啊，有点晚了，我也真的很累..."

translate chinese chinese_3972286_794:
    old "Oh yeah, honey, you deserve a good rest."
    new "哦 yeah，宝贝，你值得好好休息一下。"

translate chinese chinese_4578727_795:
    old "Yeah, I will sleep like a baby tonight."
    new "是啊，今晚我可以睡个婴儿觉了。"

translate chinese chinese_1035722_796:
    old "Alright, have a good night Mrs. Jade."
    new "好吧，翡翠女士晚安。"

translate chinese chinese_7604719_797:
    old "Have a good night, honey."
    new "晚安，亲爱的。"

translate chinese chinese_4075271_798:
    old "Oh, hi Hinn."
    new "哦，嗨，Hinn。"

translate chinese chinese_6301431_799:
    old "How are you? How have your extra classes been going?"
    new "你怎么样了？那些额外的课程进展如何？"

translate chinese chinese_9474887_800:
    old "Hey, I wanted to thank you for all the hard work you did at my house with fixing the shower and stuff."
    new "嘿，我想感谢你在我家修理淋浴等事情上所做的努力。"

translate chinese chinese_5867557_801:
    old "Oh, my pleasure. I'm glad I was able to help you."
    new "哦，我很乐意。能帮到你我很高兴。"

translate chinese chinese_6631623_802:
    old "Yeah well, I still wanted to thank you personally, because I bet my mom didn't even say thank you, did she?"
    new "好吧，我还是想亲自谢谢你，因为我觉得我妈妈连谢谢都没说吧？"

translate chinese chinese_5345413_803:
    old "Uhh... She did, she did."
    new "呃……她确实做了。"

translate chinese chinese_2643623_804:
    old "She was actually very, very grateful."
    new "她实际上非常非常感激。"

translate chinese chinese_8242459_805:
    old "She was? Well, that's a surprise."
    new "她是吗？那真是意外。"

translate chinese chinese_9165026_806:
    old "I'm glad she did."
    new "我很高兴她那样做了。"

translate chinese chinese_7937287_807:
    old "But don't think I forgot to give you my own thank you."
    new "但别以为我忘了给你道谢。"

translate chinese chinese_2258245_808:
    old "I'll be busy a couple more days with my extracurricular activities."
    new "我还要忙上几天，因为有一些课外活动。"

translate chinese chinese_5612927_809:
    old "But as soon as I'm free I'll give you something to really say thanks."
    new "但是等我有空了，我会给你一样东西以表感谢的。"

translate chinese chinese_1620145_810:
    old "Well, I don't have much more time, so, I have to leave, see you later [pla]."
    new "好吧，我没多少时间了，所以得走了，再见[pla]。"

translate chinese chinese_0640560_811:
    old "By the way, I almost forgot to tell you. "
    new "对了，差点忘了告诉你。"

translate chinese chinese_8243607_812:
    old "My mom asked me to tell you that there are a couple more things in the house that need fixing."
    new "我妈妈让我告诉你，家里还有几样东西需要修理。"

translate chinese chinese_8454795_813:
    old "And wanted to know if you could come and help us with that."
    new "而且想知道你能不能来帮我们一下。"

translate chinese chinese_2908896_814:
    old "Which is terrible of her to ask after all you already did. So, if you can't do it just tell me and I'll set her straight."
    new "这真是太过分了，你都做了那么多。所以，如果你做不到就告诉我，我来跟她算账。"

translate chinese chinese_2131380_815:
    old "Uhh, yeah, actually it's fine, I kinda have an idea of what she wants me to do, so, don't worry, it's fine."
    new "呃，是的，实际上没事，我大概知道她想让我做什么，所以不用担心，没事的。"

translate chinese chinese_0892248_816:
    old "It is? Well, I'm glad it doesn't bother you."
    new "是吗？那我就放心了。"

translate chinese chinese_0587711_817:
    old "Thanks a lot [pla], I'll see you later."
    new "谢谢你[pla]，回头见。"

translate chinese chinese_6951642_818:
    old "Hi Mrs. Jade."
    new "嗨， jade 夫人。"

translate chinese chinese_6229138_819:
    old "Hi honey, tell me, do you need anything?"
    new "亲爱的，告诉我，你需要什么吗？"

translate chinese chinese_5119579_820:
    old "I should find a therapist first."
    new "我应该先找个心理治疗师。"

translate chinese chinese_8950852_821:
    old "Hey [pla], don't you have to be at school?"
    new "嘿[pla]，你不去学校吗？"

translate chinese chinese_5791556_822:
    old "Right, I was just looking for Hinn."
    new "好的，我刚才只是在找希恩。"

translate chinese chinese_2614922_823:
    old "Hinn? She is already at school... Don't be late, [pla]... "
    new "辉音？她已经去学校了……不要迟到，[pla]……"

translate chinese chinese_8589075_824:
    old "You're right. Sorry. I better go now..."
    new "你说得对。对不起，我最好现在就走..."

translate chinese chinese_1318541_825:
    old "...(Hmm.)"
    new "...(嗯。)"

translate chinese chinese_5561329_826:
    old "What? But right now it's school time!"
    new "什么？但现在是上课时间啊！"

translate chinese chinese_2564244_827:
    old "It's very sweet of you to come here to help, but I don't want you missing any classes because of me."
    new "你特地过来帮忙真的很贴心，但我可不想因为我自己让你旷课。"

translate chinese chinese_4601868_828:
    old "You should go to school, I'll be here in the afternoon, so you can come and do the bathroom then."
    new "你应该去上学，我下午在这里，你可以到时候过来用浴室。"

translate chinese chinese_5480973_829:
    old "Yeah, I think you're right."
    new "是的，我觉得你说得对。"

translate chinese chinese_1118560_830:
    old "I'll come here later then."
    new "那我晚点再来吧。"

# auto-tl Qwen Colab

translate chinese chinese_6262817_0:
    old "No! You are my sister, but it doesn't mean I will give you money for every stupid scheme you can think of. I have my own responsibilities..."
    new "不行！你是我的妹妹，但这不代表你可以想出什么愚蠢的计划我就给你钱。我也有自己的责任……"

translate chinese chinese_3784609_1:
    old "But, I'm not asking you to give me money. Just lend me some or invest in my plan. This time what I have planned is sure to work..."
    new "但是，我并不是要你给我钱。只是借一点或者投资我的计划。这次我策划的肯定能成功..."

translate chinese chinese_7134178_2:
    old "Really, Lisa? Do you think that a simple yoga academy is a million-dollar venture? "
    new "真的，丽莎？你认为一个简单的瑜伽学院就能值一百万美元吗？"

translate chinese chinese_9690906_3:
    old "Well, maybe not a million, but I know it will help me pay off the debts I owe you."
    new "好吧，也许不是一百万，但我知道这会帮助我还清欠你的债。"

translate chinese chinese_4361041_4:
    old "You know what? I already gave too much of you. Get that money from some other sucker."
    new "你知道吗？我已经给你太多了。去从别的傻瓜那儿弄钱吧。"

translate chinese chinese_6108340_5:
    old "But... but..."
    new "但是……但是……"

translate chinese chinese_5773797_6:
    old "Oh... Hi there, [pla]. I'm sorry you had to hear all that... My sister is kind of a bitch sometimes..."
    new "哦……嗨，[pla]。对不起让你听到那些……我姐姐有时候挺讨厌的……"

translate chinese chinese_4245524_7:
    old "Oh yeah... I know what you mean..."
    new "哦 yeah... 我明白你的意思..."

translate chinese chinese_0178339_8:
    old "Well, that won't stop me! I'm going to build my own yoga academy, with or without her help..."
    new "好吧，那也阻止不了我！我要自己建一个瑜伽学院，有没有她的帮助都行..."

translate chinese chinese_6316487_9:
    old "That seems like a good idea..."
    new "那听起来像是个好主意……"

translate chinese chinese_6835526_10:
    old "Thank you, [pla]! You are always a charm... Well, I have to go. If you need me, you can look for me at my house..."
    new "谢谢你，[pla]！你总是那么迷人……好吧，我得走了。如果你需要我，可以去我家找我……"

translate chinese chinese_5490831_11:
    old "Ok [lis]! See you later..."
    new "好的[lis]！回头见..."

translate chinese chinese_4082180_12:
    old "Hey, [pla], how are you doing?"
    new "嘿，[pla]，最近怎么样？"

translate chinese chinese_5607302_13:
    old "Hi, I am fine."
    new "嗨，我很好。"

translate chinese chinese_1004001_14:
    old "You sure? I mean... I hope you're better."
    new "你确定吗？我的意思是……希望你会好起来。"

translate chinese chinese_9282924_15:
    old "Oh I see, you mean about me and my sister..."
    new "哦，我明白了，你是说我和我妹妹的事……"

translate chinese chinese_8078091_16:
    old "Hmm... Yeah."
    new "嗯……是的。"

translate chinese chinese_7476121_17:
    old "You know my inner peace remains the same... I understand that she has her own business. I think that's the way the universe tells me I need to try by my own, because I know..."
    new "你知道我的内心依然如故……我明白她有自己的事情。我觉得这是宇宙在告诉我需要自己去尝试，因为我知道……"

translate chinese chinese_6947641_18:
    old "I feel great things are coming, and I think this is the moment I can show the world what I am made of, and I know this is a dream today but it will soon be real."
    new "我觉得好事即将来临，我认为现在是向世界展示我的时刻了，我知道今天这只是一个梦想，但很快就会成真。"

translate chinese chinese_4329854_19:
    old "If fate puts a dream in your heart is because it's meant to be."
    new "如果命运在你心中种下了一个梦想，那是因为它注定会发生。"

translate chinese chinese_3396814_20:
    old "It's ok, you should to learn a little more, why not learn meditation with me."
    new "没关系，你应该多学一点，为什么不跟我一起学冥想呢。"

translate chinese chinese_4051118_21:
    old "You need to learn to find the perfect balance in your body and soul so you can be one with yourself along with the universe, to better feel and understand your purpose and of life itself."
    new "你需要学会在身体和灵魂之间找到完美的平衡，这样才能与自己和宇宙融为一体，更好地感受和理解你的使命和生命的意义。"

translate chinese chinese_2577949_22:
    old "Hmm...  s- sure."
    new "嗯……好啦。"

translate chinese chinese_1252174_23:
    old "You know what, I will go today and check the options at the mall to see if I could run my own yoga academy from there, I will find the perfect place and fill out all the paperwork."
    new "你知道吗，我今天就去商场看看有没有合适的地点，看看能不能在那里开自己的瑜伽学院，找到完美的地方后就把所有文件都填好。"

translate chinese chinese_7523881_24:
    old "Yeah, but there is so much work to do, you know... The place, the rent, the equipment, the ambience, everything must flow with the same energy."
    new "是啊，但是要做的工作太多了，你知道的……这个地方、租金、设备、氛围，一切都必须充满同样的能量。"

translate chinese chinese_8107946_25:
    old "Once I get all the info, I will have an idea about the budget."
    new "等我拿到所有信息，就能有个预算的概念了。"

translate chinese chinese_9667606_26:
    old "Hope you get all the info you need, good luck!"
    new "希望你能得到所有需要的信息，祝你好运！"

translate chinese chinese_0389334_27:
    old "Hi, Lisa, how are you?"
    new "嗨，丽莎，你好吗？"

translate chinese chinese_3895292_28:
    old "Oh no [pla], I think I need to reconsider my entire project."
    new "哦不 [pla]，我觉得我需要重新考虑整个项目。"

translate chinese chinese_4383665_29:
    old "Well, [pla], I went to the mall, had a hard time finding the manager, but think it was just fate trying to save me from that pain."
    new "好吧，[pla]，我去商场了，找经理找了好一阵，但我觉得这可能是命运在试图拯救我不受那份痛苦。"

translate chinese chinese_8439361_30:
    old "I mean the rent for just a very small place was huge, something really out of my league, the requirements to rent the place are quite stressful."
    new "我的意思是，就连租个小地方的租金都高得离谱，完全超出了我的能力范围，租房的要求也让我压力山大。"

translate chinese chinese_2224213_31:
    old "I'm so frustrated, I- I need to think of a different project..."
    new "我真是 frustratated，我——我需要想个不同的项目……"

translate chinese chinese_7202046_32:
    old "But the worst part of that day was when I discovered THERE WAS a yoga academy, as if that wasn't enough it was also really close to the place I was looking at..."
    new "但那天最糟糕的部分是，我发现那里确实有一家瑜伽学院，而且就在我看中的地方附近……"

translate chinese chinese_6458769_33:
    old "Wait what? So you will have to compete."
    new "等下什么？所以你得参加竞争？"

translate chinese chinese_1227551_34:
    old "Well, that academy was bigger than what I was thinking, I think they have been there for a while because there was a lot of people, it was so amazing, the place was radiant and beautiful..."
    new "嗯，那个学院比我想象的要大得多，我觉得他们在那里待了一段时间，因为人很多，真是太棒了，那地方光彩照人，美丽极了……"

translate chinese chinese_6744084_35:
    old "Yeah, I immediately thought to myself I could be better than any of their instructors but clearly I can't compete with that company..."
    new "是的，我立刻心想我可以比他们的任何教练都强，但显然我没法和那家公司竞争……"

translate chinese chinese_4814533_36:
    old "I understand..."
    new "我明白……"

translate chinese chinese_6558751_37:
    old "Yeah, I think I need to be humble and to accept fate as it is..."
    new "是的，我觉得我需要谦卑一点，接受现实..."

translate chinese chinese_5472791_38:
    old "But... There has to be something you can do..."
    new "但是……你总得做些什么……"

translate chinese chinese_2392387_39:
    old "What are my options? There's nothing I can do."
    new "我有什么选择？我什么也做不了。"

translate chinese chinese_1799255_40:
    old "I mean, you can check different places, not just the mall."
    new "我的意思是，你可以去不同的地方看看，不只是商场。"

translate chinese chinese_3915956_41:
    old "Hmm I don't know, I just need time to focus on a different idea."
    new "嗯，我不知道，我只是需要时间专注于一个不同的想法。"

translate chinese chinese_7121642_42:
    old "Sorry to hear you so frustrated, but you know what? You can count on me."
    new "听到你这么沮丧我很难过，但是你知道吗？你可以依赖我。"

translate chinese chinese_0233173_43:
    old "Oh that's very sweet of you."
    new "哦，你真甜。"

translate chinese chinese_2671777_44:
    old "I know you can get a yoga academy like you want, we just need to look for alternatives."
    new "我知道你能上你想去的瑜伽学院，我们只需要找找其他选择就行了。"

translate chinese chinese_4400114_45:
    old "I'll think about it, thanks for being so supporting, I appreciate your time."
    new "我会考虑的，感谢你的支持，我很珍惜你的时间。"

translate chinese chinese_2824892_46:
    old "It's ok, I just hope I can help."
    new "没关系，我只希望我能帮上忙。"

translate chinese chinese_3252298_47:
    old "Hi, how-"
    new "喂，怎么了—"

translate chinese chinese_2089580_48:
    old "Hey! I needed to talk to you, I have great news!"
    new "喂！我需要和你说件事，我有个好消息！"

translate chinese chinese_8750462_49:
    old "Wow, I can see you're feeling better now..."
    new "wow, 看起来你现在感觉好多了..."

translate chinese chinese_0529195_50:
    old "I really am, last time we talked I was very down, but I started my daily meditation practice. While breathing I discovered some light within the darkness..."
    new "我真的有，上次我们聊天的时候我心情很低落，但我开始每天冥想。在呼吸中，我在黑暗中发现了一些光明……"

translate chinese chinese_6087405_51:
    old "While I was doing this yoga position to relax, I thought I was doing something wrong, then I corrected the position, I still wasn't sure what exactly was wrong..."
    new "我在做这个瑜伽姿势来放松的时候，总觉得哪里不对劲，然后调整了姿势，还是不确定到底哪里出了问题……"

translate chinese chinese_2408882_52:
    old "So I slightly moved my arms and legs to get the perfect position, I know it sounds a bit silly but, when I corrected the position, it felt like my body was in a different place..."
    new "所以我稍微动了动四肢，找到了一个完美的姿势。我知道这听起来有点傻，但当我调整好姿势时，感觉我的身体好像在另一个地方……"

translate chinese chinese_4848706_53:
    old "I mean, sometimes meditation is not about knowing the Asanas but how you connect in the moment and the environment..."
    new "我的意思是，有时候冥想不在于你知道多少体式，而在于你如何在那一刻与环境连接……"

translate chinese chinese_2749240_54:
    old "It's not about how you follow the rules but how you connect your body and soul through exercise, do you understand?"
    new "这不在于你怎么遵守规则，而在于你怎么通过锻炼将身心连接起来，你明白吗？"

translate chinese chinese_5420534_55:
    old "Hmm... I think so."
    new "嗯……我觉得是的。"

translate chinese chinese_8580035_56:
    old "That was my reflection, I'm not a regular Yoga instructor, I mean this academy at the mall can have 10 teachers but I am no a regular teacher, yoga and meditation is part of my life..."
    new "那只是我的一面，我不是普通的瑜伽教练，我是说这家商场里的瑜伽馆可能有十个老师，但我不普通，瑜伽和冥想是我生活的一部分……"

translate chinese chinese_9032541_57:
    old "For me, yoga is not just about the equipment or space, I don't need that so I can perform a good pranayama, those are things for a comfortable service experience."
    new "对我来说，瑜伽不仅仅是关于设备或空间的，我不需要那些也能做好调息法，那些只是为了舒适的体验服务。"

translate chinese chinese_5514632_58:
    old "My personal experience can't be beat because it's actually richer than any other yoga experience, I'm not selling a product! I'm sharing my own experience..."
    new "我的个人经验是无与伦比的，因为它比我所知道的任何其他瑜伽体验都要丰富。我不是在推销产品，我只是分享我自己的经历……"

translate chinese chinese_2247341_59:
    old "Very interesting."
    new "非常有趣。"

translate chinese chinese_9784839_60:
    old "And you were right..."
    new "而且你说得对..."

translate chinese chinese_6727095_61:
    old "Yes! About the mall, my business can be run in a totally different place... In fact... I think... Since I don't need any special place, I can just have it at my own HOUSE."
    new "没错！关于商场的事，我的生意完全可以换个地方进行……事实上……我觉得……既然不需要特别的地方，直接在家里做就行了。"

translate chinese chinese_7767524_62:
    old "That would be very convenient."
    new "那可就太方便了。"

translate chinese chinese_6735335_63:
    old "Here, my customers can experience a very close yoga training, focus on the intimate learning, no distractions, no rules, only the yoga experience I provide."
    new "在这里，我的顾客可以体验非常亲密的瑜伽训练，专注于亲密学习，没有干扰，没有规矩，只有我提供的瑜伽体验。"

translate chinese chinese_7650635_64:
    old "Well, I will need to check how to obtain the necessary business permits and licenses."
    new "嗯，我需要查一下如何办理所需的营业执照和许可证。"

translate chinese chinese_0795958_65:
    old "I am sure that won't be any trouble."
    new "我敢肯定这不会有任何麻烦。"

translate chinese chinese_8202447_66:
    old "Thank you for listening to me and giving me the support, I needed I appreciate it."
    new "谢谢你听我说，给我需要的支持，我真的很感激。"

translate chinese chinese_5580612_67:
    old "I actually did nothi-"
    new "我其实什么都没做-"

translate chinese chinese_7843026_68:
    old "Oh, by the way, let me show you some ideas I have for the yoga room."
    new "哦，对了，让我给你看看我为瑜伽室想的一些点子。"

translate chinese chinese_8629995_69:
    old "Please come, I'm sure you are going to like it too, I wasn't aware my house was so perfect for this."
    new "请来吧，我相信你也一定会喜欢的，我也没想到我家这么适合这个。"

translate chinese chinese_1153138_70:
    old "Is it?"
    new "是吗？"

translate chinese chinese_3891246_71:
    old "Yes, the second floor is big and a good area I can take advantage of."
    new "是的，二楼很大，是个我可以利用的好地方。"

translate chinese chinese_6714441_72:
    old "Hmm, this room is pretty big."
    new "嗯，这个房间挺大的。"

translate chinese chinese_9504775_73:
    old "You see it? It is so private, very intimate, and full of silence, this place is perfect... I did not realize it was that big until I took out all the stuff... What do you think?"
    new "你看出来了吗？这里私密又充满亲密感，非常安静，这个地方完美……直到我把所有东西都拿出来我才意识到它这么大……你觉得呢？"

translate chinese chinese_2226772_74:
    old "It is very nice and peaceful."
    new "这里很安静也很舒服。"

translate chinese chinese_7527848_75:
    old "Actually, it's going to be better, you know music, fragrances, all that it takes to meditate and find your inner peace."
    new "实际上会更好，你知道的，音乐、香氛，所有这些都能帮助冥想，找到内心的平静。"

translate chinese chinese_6848354_76:
    old "Wow, you have your business almost running. If you need something, you can count on me anytime."
    new "wow, 你的生意都快搞定了。如果你需要什么，随时可以找我。"

translate chinese chinese_7617114_77:
    old "You're really sweet... I think I am ok-"
    new "你真甜……我觉得我没事了-"

translate chinese chinese_0480351_78:
    old "Wait, you know what?..."
    new "等一下，你知道吗？..."

translate chinese chinese_1940901_79:
    old "I was wondering yesterday, how a customer would feel, you know the place... The energy... I just want to have an idea how they could feel."
    new "我昨天在想，顾客会有什么感觉，你知道的，那个地方……那种氛围……我只是想知道他们会有什么感受。"

translate chinese chinese_7559226_80:
    old "Would you like to help me? You just need to be like my ‘instructor' I will tell you step by step what to do... What do you think?"
    new "你想帮我吗？你就像是我的“指导老师”一样，我会一步步告诉你该怎么做……你觉得怎么样？"

translate chinese chinese_4562093_81:
    old "Hmm, I can help you sure..."
    new "嗯，我可以帮你当然..."

translate chinese chinese_3560055_82:
    old "Thank you, I will walk you through every single step so you can learn too."
    new "谢谢，我会一步步教你，让你也能学会。"

translate chinese chinese_6436085_83:
    old "Let's do a couple of regular exercises."
    new "我们来做几个常规运动吧。"

translate chinese chinese_6287984_84:
    old "First we will try something casual, this position is called ‘Utkatasana', it's quite focused on breathing and your legs so since you will be the trainer..."
    new "我们先来点轻松的，这个姿势叫做“椅式”，主要注重呼吸和腿部的力量，因为你将是教练……"

translate chinese chinese_1520856_85:
    old "I will do the position so please follow me, don't do the position with me but control the position from the back, helping me to keep my balance, you got it?"
    new "我来摆姿势，请跟着我，不要和我一起摆姿势，而是从后面控制姿势，帮我保持平衡，明白了吗？"

translate chinese chinese_2530193_86:
    old "Ok... Here we go, please put your hands on my waist."
    new "好……开始了，请把手放在我的腰上。"

translate chinese chinese_8406950_87:
    old "Like I said follow my movement, I will go down..."
    new "就像我说的，跟着我的动作，我会往下…"

translate chinese chinese_7915605_88:
    old "Sure..."
    new "好吧……"

translate chinese chinese_1553771_89:
    old "You're keeping cool good, let's go up... Perfect."
    new "你冷静得很不错，我们上去吧……完美。"

translate chinese chinese_7011117_90:
    old "Well, I can feel it positive, I can breathe perfectly, the light is quite good, do you feel comfortable?"
    new "嗯，我能感觉到很正面，呼吸也很顺畅，光线也很好，你觉得舒服吗？"

translate chinese chinese_4215932_91:
    old "Yes, I feel nice."
    new "是的，我觉得很好。"

translate chinese chinese_2940009_92:
    old "Well, that was very productive, I feel relaxed, don't forget to keep breathing."
    new "嗯，这很有效，我觉得放松多了，别忘了保持呼吸。"

translate chinese chinese_6256490_93:
    old "Sure, I'm focused."
    new "当然，我很有焦点。"

translate chinese chinese_3601962_94:
    old "That's perfect, let's try a different pose..."
    new "perfect，我们试试不同的姿势..."

translate chinese chinese_4212246_95:
    old "Next one will be totally different it's on the floor, its name is ‘Upward Facing Dog', for this position your help is very important..."
    new "下一个完全不一样，它在地上，名字叫‘上犬式’，这个姿势你的帮助非常重要……"

translate chinese chinese_1169472_96:
    old "Because you will help me with the effort applied to my back, so I'll lie down looking up, if you want to be more comfortable, please get on your needs."
    new "因为你将会帮我支撑背部，所以我躺着仰望，如果你想更舒服一点，请按你的需要来。"

translate chinese chinese_8112081_97:
    old "I really like this position, I can feel a lot of energies running through me."
    new "我真的很喜欢这个姿势，能感觉到有很多能量在我体内流动。"

translate chinese chinese_6031331_98:
    old "Ahh it's so relieving, please push a bit towards my shoulders."
    new "啊，好舒服，请往我的肩膀那边按按。"

translate chinese chinese_1068610_99:
    old "Oh yeah, like that, this is very relaxing for me."
    new "哦 yeah，就是这样，这对我来说很放松。"

translate chinese chinese_4416953_100:
    old "(She looks very enticing... I need to focus.)"
    new "（她看起来非常诱人……我得集中注意力。）"

translate chinese chinese_7810486_101:
    old "(Oh shit... I'm getting hard... Oh, please not now...)"
    new "（哦shit……我硬了……哦，求你了不要这个时候……）"

translate chinese chinese_5180514_102:
    old "You are doing amazing."
    new "你做得很好。"

translate chinese chinese_8897104_103:
    old "I think this place is incredible to do this... I can't wait to bring the candles, the music... It'll be so perfect!"
    new "我觉得这里太棒了，做这些事...我都等不及要带蜡烛和音乐过来了...一切都会完美的！"

translate chinese chinese_9702145_104:
    old "Alright, we need to continue... Listen, the next position is amazing, it's one of the most interesting and very easy to learn."
    new "好吧，我们需要继续……听我说，下一个姿势棒极了，非常有趣而且很容易上手。"

translate chinese chinese_5650888_105:
    old "This asana sequence is called ‘Extended Puppy Pose', it's really relaxing, so please pay attention..."
    new "这个体式序列叫做“延长小狗式”，真的很放松，请注意……"

translate chinese chinese_0653958_106:
    old "W- what do you need me to do?"
    new "你、你需要我做什么？"

translate chinese chinese_2512060_107:
    old "(I need to control myself or she will notice my hardon.)"
    new "（我得控制住自己，不然她会注意到我硬了。）"

translate chinese chinese_9554726_108:
    old "Well... For this position the hips and legs are very important, so I will need you to push them, so I can stretch my back to the fullest..."
    new "嗯……对于这个姿势，臀部和腿部很重要，所以我需要你推它们，这样我才能把背部完全展开……"

translate chinese chinese_3847089_109:
    old "Please hold my waist behind me and help me keep my balance."
    new "请从后面抱住我的腰，帮我保持平衡。"

translate chinese chinese_8038001_110:
    old "(I hope she doesn't notice it.."
    new "（希望她没注意到……)"

translate chinese chinese_4080980_111:
    old "Please try to rest your waist with mine, control your breathing too."
    new "请试着用我的腰支撑你的腰部，同时控制好呼吸。"

translate chinese chinese_5229563_112:
    old "I need to feel you firmly so I can rest my back and relax my body."
    new "我需要紧贴你的身体，这样我才能放松背部和全身。"

translate chinese chinese_7978511_113:
    old "(Oh It feels so delicious.)"
    new "（哦，感觉真美妙。）"

translate chinese chinese_2968300_114:
    old "Can push me harder, that way both of us will be able to the do exercise more intensely."
    new "可以再用力推我一下，这样我们俩都能更剧烈地锻炼。"

translate chinese chinese_5256106_115:
    old "Yes, just like that."
    new "对，就是这样。"

translate chinese chinese_4913474_116:
    old "That was perfect... I think we are done!"
    new "太完美了……我想我们搞定了！"

translate chinese chinese_7829647_117:
    old "I like your enthusiasm but I think you can stop now."
    new "我喜欢你的热情，但我觉得你可以停下来了。"

translate chinese chinese_5699138_118:
    old "OH!? Yes, I am sorry, I was... I... Was quite focused on the position."
    new "噢！？是的，对不起，我刚才……我……挺专注于那个姿势的。"

translate chinese chinese_9041022_119:
    old "Oh that's fantastic, I'm sorry to interrupt you."
    new "哦，太好了，打扰你了，真抱歉。"

translate chinese chinese_4218465_120:
    old "(Phew, thank god, she didn't notice.)"
    new "（虚惊一场，还好她没发现。）"

translate chinese chinese_3303160_121:
    old "Oh no, it's ok no worries."
    new "哦不，没关系，别担心。"

translate chinese chinese_0008942_122:
    old "Amazing, you did a wonderful job, I appreciate your commitment."
    new "太棒了，你干得非常出色，我真的很欣赏你的投入。"

translate chinese chinese_0656279_123:
    old "No problem..."
    new "没问题……"

translate chinese chinese_6694392_124:
    old "I'm very surprised how our chakras get together so well... I am sure that is going to be the feeling I have with my customers."
    new "我非常惊讶我们的气场这么合拍……我确信和我的客户也会有这种感觉。"

translate chinese chinese_0026380_125:
    old "I'll let you rest, thank you so much for your help, I will keep meditating a little longer."
    new "我让你休息一下，谢谢你帮忙，我再继续冥想一会儿。"

translate chinese chinese_6263698_126:
    old "If you want to learn more, I could give you a few more lessons."
    new "如果你想了解更多，我可以再给你上几节课。"

translate chinese chinese_0992405_127:
    old "... Alright... I'm gonna leave you, so you can practice more."
    new "……好吧……我要先走了，让你再多练习一下。"

translate chinese chinese_0109041_128:
    old "Thank you honey, see you later."
    new "谢谢你宝贝，待会儿见。"

translate chinese chinese_0403604_129:
    old "Have a good one."
    new "玩得开心点。"

translate chinese chinese_4208137_130:
    old "(That was close... I think she didn't realize...)"
    new "（好险……我觉得她没意识到……）"

translate chinese chinese_0486619_131:
    old "Oh, hi Lisa, what a surprise! Did you come to talk with [mo2]?"
    new "哦，丽莎，真是意外啊！你是来找[mo2]聊天的吗？"

translate chinese chinese_5399998_132:
    old "Oh no, don't worry, I am fine, I just came because I... Wanted to talk to you."
    new "哦不，别担心，我没事，我来是因为我……想和你谈谈。"

translate chinese chinese_1390811_133:
    old "With me? Ok..."
    new "和我一起？好……"

translate chinese chinese_1503907_134:
    old "[pla] the universe is doing its thing, everything going pretty well and guess what?"
    new "[pla] 宇宙自有其运行方式，一切都很顺利，猜猜怎么着？"

translate chinese chinese_3661550_135:
    old "I have already had some customers; they are really happy with how we do things."
    new "我已经有一些客户了，他们对我们做事的方式非常满意。"

translate chinese chinese_7884419_136:
    old "Oh... That's amazing."
    new "哦……真厉害。"

translate chinese chinese_3802333_137:
    old "Yes, but this is just the beginning, better things are coming."
    new "是的，但这只是开始，更好的还在后面。"

translate chinese chinese_4216899_138:
    old "I am glad that you are very positive."
    new "我很高兴你这么乐观。"

translate chinese chinese_1311081_139:
    old "I am just thankful for everything the universe is preparing for me."
    new "我只感谢宇宙为我准备的一切。"

translate chinese chinese_2233901_140:
    old "Actually, I need to ask you something, I don't want to do this but you're the one who would understand what I need."
    new "其实我有件事想问你，我不想这么做，但你知道我需要什么。"

translate chinese chinese_9826000_141:
    old "Hmm... What is this about?"
    new "嗯……这是关于什么的？"

translate chinese chinese_1232606_142:
    old "Like I said the business is taking shape, I already have some customers, however I am very busy lately with paperwork to get the final license and all of that... You know..."
    new "就像我说的，生意正在走上正轨，我已经有一些客户了，不过最近忙于办理最终许可证等各种文件……你知道的……"

translate chinese chinese_9208182_143:
    old "The thing is I have a new customer in the afternoon coming, she is very very enthusiastic and is quite interested on the yoga program."
    new "问题是下午有个新客户要来，她对瑜伽课程非常感兴趣。"

translate chinese chinese_2250444_144:
    old "Yeah, she paid for the entire course and I'm already planning her sessions."
    new "是的，她付了整个课程的费用，我还在为她安排课程呢。"

translate chinese chinese_9316103_145:
    old "However the time frame she said she is available is exactly the same time I have a very important appointment..."
    new "然而，她说有空的时间正好和我有一个非常重要的约会时间冲突……"

translate chinese chinese_0848028_146:
    old "It's an interview to verify the information to approve the business. I already have all the documentation needed to legally open it..."
    new "这是个核实信息以批准业务的面试。我已经有所有合法开业所需的文件……"

translate chinese chinese_7286675_147:
    old "But this is a temporary one, this interview  gives me the approval so... I do need your help now... If you can cover me, so I can attend it."
    new "但这只是一个临时的，这次采访给了我批准……所以我现在确实需要你的帮助……如果你能帮我一把，我就去参加。"

translate chinese chinese_8254761_148:
    old "Well... I think I can... But-"
    new "嗯……我觉得我可以……但是-"

translate chinese chinese_8903225_149:
    old "Amazing! that is fantastic. The entire universe is making it possible once again, did you know you are being an instrument of the universe?"
    new "太棒了！这真是太好了。整个宇宙再次让它成为可能，你知道你正在成为宇宙的工具吗？"

translate chinese chinese_9881018_150:
    old "M- me... ?"
    new "我... ?"

translate chinese chinese_9530440_151:
    old "Of course! I am very grateful... You cannot not imagine how important this is for me. You only need to help me with this session..."
    new "当然！我非常感激……你无法想象这对我来说有多重要。你只需要帮我完成这个环节……"

translate chinese chinese_9469704_152:
    old "Since you have already done the basic yoga training with me you are the only one that can cover me, it's going to be the same routine."
    new "因为你已经跟我做过基础瑜伽训练了，只有你能帮我，就按之前的流程来。"

translate chinese chinese_0087335_153:
    old "I know you are very intuitive and can do the session like we did before, I already checked with the customer and she is ok with that."
    new "我知道你很敏感，可以像以前那样进行这次环节，我已经和客户确认过了，她同意这样。"

translate chinese chinese_5316640_154:
    old "Please reach me at home later, I am very sorry we won't have enough time to plan it but I am sure you will do great."
    new "请晚点家里联系我，很抱歉我们时间不够详谈，但我相信你会做得很好的。"

translate chinese chinese_1784608_155:
    old "Hmm ok, I'll be there on time."
    new "嗯好，我会准时到的。"

translate chinese chinese_2689578_156:
    old "Thank you so much... See you then."
    new "真是太感谢了……到时候见。"

translate chinese chinese_9153045_157:
    old "No problem, bye."
    new "没问题，再见。"

translate chinese chinese_6229476_158:
    old "(Oh my god, is Anastasia, What is she doing here.)"
    new "（天啊，是阿纳斯塔西娅，她怎么会在这里。）"

translate chinese chinese_5448145_159:
    old "Oh, hey [pla]! thank so much for coming."
    new "哦，嘿[pla]！谢谢你来了。"

translate chinese chinese_2150415_160:
    old "Oh, I am sorry, let me introduce you guys properly... [pla], this is Anastasia... Anastasia, this is  [pla]."
    new "哦，对不起，让我给你们正式介绍一下……[pla]，这是阿纳斯塔西娅……阿纳斯塔西娅，这是[pla]。"

translate chinese chinese_0047201_161:
    old "Thank you Lisa, It's nice to see you again [pla]!"
    new "谢谢你，丽莎，再次见到你真好[pla]！"

translate chinese chinese_1123978_162:
    old "G- good to see you too."
    new "也、也很高兴见到你。"

translate chinese chinese_2588567_163:
    old "Oh... So do you guys already know each other?"
    new "哦……所以你们已经认识了？"

translate chinese chinese_0618930_164:
    old "Hehehe, Yes, we know each other pretty well, right [pla]?"
    new "嘿嘿嘿，是啊，我们互相都挺了解的，对吧[pla]？"

translate chinese chinese_8020046_165:
    old "Oh really? Please tell me... Once you guys arrived I just felt like fate was planning this meeting."
    new "哦真的吗？请告诉我……你们一来我就觉得这是命运安排的相遇。"

translate chinese chinese_0708647_166:
    old "Well, she has bought some products... From [sis]'s website."
    new "好吧，她确实从[sis]的网站上买了一些产品。"

translate chinese chinese_3378124_167:
    old "Yeah, I met him as the delivery guy, I was surprised by his manners and because he is very intelligent with pretty huge talent..."
    new "是啊，我遇到他是因为他来送快递，他的礼貌让我很惊讶，而且他还非常聪明，才华横溢……"

translate chinese chinese_7362771_168:
    old "I am very glad to hear that you understand each other, I will try to be back as soon as possible, in the meantime [pla] will help you with the first session Anastasia."
    new "我很高兴听到你们能互相理解，我会尽量尽快回来，在这之前，[pla]会帮助你进行第一次课程，阿纳斯塔西娅。"

translate chinese chinese_6908105_169:
    old "Oh, that's very interesting, don't you think [pla]?"
    new "哦，这很有趣，你不这么认为吗，[pla]？"

translate chinese chinese_0162244_170:
    old "Y- yes... Very interesting..."
    new "是的……很有趣……"

translate chinese chinese_7533418_171:
    old "I‘ve got the feeling this session will be really nice. Well guys, please enjoy the session, I will be back as soon as possible."
    new "我感觉这次会很愉快。好吧，大家请享受这个过程，我会尽快回来的。"

translate chinese chinese_3219853_172:
    old "Bye bye Lisa."
    new "拜拜丽莎。"

translate chinese chinese_1339438_173:
    old "Finally we are alone. I am  very ready for the class."
    new "终于我们单独了。我准备得很充分。"

translate chinese chinese_9218621_174:
    old "Well... Yes, I- I thank you for coming today, we did prepare a very great Yoga session for you."
    new "嗯……是的，我——我要感谢你今天来，我们确实为你准备了一节很棒的瑜伽课程。"

translate chinese chinese_3911038_175:
    old "Oh, I like that, I wasn't expecting to have a very handsome trainer, it's going to be really fun."
    new "哦，我喜欢这样，没想到会有一个这么帅气的教练，这肯定会很有趣。"

translate chinese chinese_4839073_176:
    old "Why don't we go to the yoga room where it's more comfortable for the session."
    new "我们去瑜伽室吧，那里更舒服些。"

translate chinese chinese_5850123_177:
    old "This is going to be our yoga room, we hope you enjoy not only the lesson but also the finer details for this experience."
    new "这个将是我们的瑜伽室，希望你能不仅享受课程，还能欣赏这次体验的每一个细节。"

translate chinese chinese_2273726_178:
    old "It's beautiful, smells very nice."
    new "真漂亮，气味也很宜人。"

translate chinese chinese_6114458_179:
    old "Every detail has been thought out to make your experience better."
    new "每个细节都经过精心设计，以提升你的体验。"

translate chinese chinese_7546998_180:
    old "You guys are doing it very well."
    new "你们做得很好。"

translate chinese chinese_4121814_181:
    old "Now, let's start with the lesson, so you can get to relax a bit more."
    new "好了，我们现在开始上课，这样你可以稍微放松一点。"

translate chinese chinese_1278091_182:
    old "Alright, for the first position I will be behind you to help you keep your body balanced, and that way we can do the exercise properly."
    new "好吧，第一个姿势我会从后面帮你保持身体平衡，这样我们可以正确地完成这个动作。"

translate chinese chinese_5712278_183:
    old "That's perfect."
    new "那正好。"

translate chinese chinese_3948108_184:
    old "We will start straight up and then we will go down keeping the straight position and correct breathing."
    new "我们会先保持直立姿势，然后保持这个姿势向下移动，同时注意呼吸要正确。"

translate chinese chinese_3766188_185:
    old "Try to keep your thoughts focus on the exercise."
    new "尽量让你的思绪集中在练习上。"

translate chinese chinese_9729110_186:
    old "(Her butt is really big, I need to think of something different. She's so hot...)"
    new "（她的屁股真大，我得想想别的，她太辣了...）"

translate chinese chinese_7277392_187:
    old "Am I doing it right?"
    new "我这样做对吗？"

translate chinese chinese_5502970_188:
    old "Yes... Delicious."
    new "是的……美味极了。"

translate chinese chinese_1232929_189:
    old "I- mean... Correct, yes, you are doing it correctly."
    new "我——的意思是……对，没错，你做得对。"

translate chinese chinese_0370263_190:
    old "Oh, thank you."
    new "哦，谢谢。"

translate chinese chinese_7880658_191:
    old "Do you feel relaxed?"
    new "你觉得放松了吗？"

translate chinese chinese_1557980_192:
    old "Yes, I like it."
    new "是的，我喜欢。"

translate chinese chinese_6100568_193:
    old "It was good, we are going to stop now and continue with the following, did you like it?"
    new "挺好的，我们现在停下来，接下来继续，你觉得怎么样？"

translate chinese chinese_2612274_194:
    old "It was nice."
    new "挺不错的。"

translate chinese chinese_0528251_195:
    old "I hope you feel calmer now... So, our next position will help with the balance of our energies..."
    new "希望你现在感觉平静些了……所以，我们的下一个姿势有助于平衡我们的能量……"

translate chinese chinese_3984647_196:
    old "I'll need you to lie down on your stomach, first we will stretch your legs and back, raising your head up, later you will let it down to breathe again."
    new "你需要先趴下来，我们先拉伸你的腿和背部，把头抬起来，然后再放下让你呼吸。"

translate chinese chinese_6635897_197:
    old "This position is quite demanding, I will be there to make sure you can focus more and make the most out of it."
    new "这个职位要求很高，我会在那里确保你能更好地集中精力，充分发挥。"

translate chinese chinese_9017932_198:
    old "Sounds good!"
    new "听起来不错！"

translate chinese chinese_6653679_199:
    old "First relax and breathe while lying down in that position."
    new "先放松，保持那个姿势躺下呼吸。"

translate chinese chinese_4067079_200:
    old "Hmm it feels good."
    new "嗯，感觉真好。"

translate chinese chinese_0403839_201:
    old "Now you are going to stretch your arms and I'm going to press your shoulders back so you can tense your muscles, and tilt your head back."
    new "现在你要伸展双臂，我来按你的肩膀往后压，让你的肌肉紧绷，然后把头往后仰。"

translate chinese chinese_7363020_202:
    old "(Wow... I can see her boobs!)"
    new "（哇……我能看见她的胸部！）"

translate chinese chinese_2383971_203:
    old "(Oh no... I am getting a hardon again. Shit... I should act normal so she doesn't notice.)"
    new "（哦不……我又硬了。shit……我得装作正常点，别让她发现。）"

translate chinese chinese_7815846_204:
    old "So... Like this?"
    new "所以……是这样吗？"

translate chinese chinese_2205745_205:
    old "Are you getting distracted?"
    new "你分心了？"

translate chinese chinese_0618318_206:
    old "Oh no... I am ok... Let's breath a bit more."
    new "哦不……我没事……咱们再缓一会儿。"

translate chinese chinese_2745506_207:
    old "OH WOW!"
    new "哦 wow！"

translate chinese chinese_4796214_208:
    old "(Dammit she noticed it.)"
    new "（该死，她注意到了。）"

translate chinese chinese_2155507_209:
    old "I thought you were a bit distracted but now I know you brought a bit of company, I think one of your muscles needs to relax a bit too..."
    new "我还以为你只是有点心不在焉，但现在我知道你带来了点伴儿，我觉得你得放松一下某块肌肉了……"

translate chinese chinese_9084122_210:
    old "I- am very sorry, please do not take me wrong way, I am... I am just very nervous."
    new "我……非常抱歉，不要误会我，我……我只是很紧张。"

translate chinese chinese_7258043_211:
    old "It's totally ok, I feel very flattered and I like it... The effort makes you feel a bit stressed, I think since you are helping, I should help you too, so you can feel better."
    new "完全没问题，我感到很受宠若惊，我也喜欢这样……你的努力让我觉得有点紧张，我觉得既然你在帮忙，我也应该帮你一下，让你感觉好一点。"

translate chinese chinese_9699042_212:
    old "W- What? Oh no, of course not.. I think this is moment to finish the session."
    new "什、什么？哦不，当然不是……我觉得这个时候应该结束这次会话了。"

translate chinese chinese_0013373_213:
    old "I know you want it... I remember last time you enjoyed it with my hands, probably this time we can try with... I don't know, maybe my mouth?"
    new "我知道你想要的……上次你很享受我的手，这次我们可以试试用……我不知道，也许用我的嘴？"

translate chinese chinese_6094035_214:
    old "... (What the fuck!)"
    new "... （什么鬼！）"

translate chinese chinese_9196864_215:
    old "Why don't you relax a bit, let me check it out on my own, I know you will like it... Let's open this sweet gift."
    new "你放松一点吧，让我自己看看，我知道你会喜欢的……我们来打开这个甜蜜的礼物。"

translate chinese chinese_8642378_216:
    old "Wow, it's huge, things are getting better since last time, looks very tasty... Do you mind if I give it a taste?"
    new "哇，好大，比上次好多了，看起来很美味……我可以尝一下吗？"

translate chinese chinese_8665845_217:
    old "Let me take care of this now!"
    new "让我现在就处理这件事！"

translate chinese chinese_2478678_218:
    old "Did you like it?  You are not the only expert here, I am quite ready for this kind of 'exercises', how would you rate my performance?"
    new "你喜欢吗？你不是这里唯一的专家，我对这种“练习”也挺有准备的，你觉得我的表现如何？"

translate chinese chinese_3092661_219:
    old "Hey guys, I'm finally here, did you guys finish already?"
    new "嘿，我终于来了，你们搞定了吗？"

translate chinese chinese_0312818_220:
    old "(Oh god, for a few minutes early and she could have discovered us...)"
    new "（天啊，早几分钟她就能发现我们了……）"

translate chinese chinese_1545384_221:
    old "Yes, it was very good. [pla] is the most wonderful partner I could ask for..."
    new "是的，非常好。[pla]是我能求得的最佳伴侣……"

translate chinese chinese_9063099_222:
    old "He is very pleasant even though some positions got very hard, I like it too much!"
    new "他很愉快，虽然有些姿势很难，但我太喜欢了！"

translate chinese chinese_3245139_223:
    old "Aww, that's dazzling... I appreciate your words."
    new "哎呀，真迷人……你的言辞我心领了。"

translate chinese chinese_1838688_224:
    old "For sure, I know I will be coming very often, I didn't know it was so amusing, very ‘delicious', I was fully satisfied."
    new "肯定的，我知道我会经常来的，没想到这么有趣，非常“美味”，我完全满意了。"

translate chinese chinese_8839853_225:
    old "Sounds terrific... Wait, what's that on your face?"
    new "听起来不错……等等，你脸上那是什么？"

translate chinese chinese_9700970_226:
    old "Oh, what's that? Ahh, It must be sweat, you know this is kind of new for me-"
    new "哦，那是什么？啊，肯定是汗，你知道这对我来说有点新奇——"

translate chinese chinese_7151417_227:
    old "Yeah, right."
    new "是啊，没错。"

translate chinese chinese_2344741_228:
    old "But no worries, I will clean it in a moment, thank you."
    new "不过不用担心，我一会儿就打扫，谢谢。"

translate chinese chinese_7312409_229:
    old "Thank you very much Lisa, once again, today's session was amazing, and [pla], this definitely be repeated, I need more... I mean sessions like this one."
    new "非常感谢你，丽莎，今天的环节真是太棒了，而且[pla]，这样的体验绝对要再来一次，我需要更多……我是说这样的环节。"

translate chinese chinese_8662470_230:
    old "... Y- yes, see you later..."
    new "...是的，再见..."

translate chinese chinese_1080871_231:
    old "Bye bye, Anastasia."
    new "再见了，阿纳斯塔西娅。"

translate chinese chinese_3753850_232:
    old "I really wanted to thank you, I know you weren't prepared enough but you actually did incredible, I am very embarrassed because it was all of the sudden for you to do it."
    new "我真的想谢谢你，我知道你准备得不够充分，但你实际上做得非常棒，我感到很尴尬，因为这一切对你来说太突然了。"

translate chinese chinese_7922295_233:
    old "No problem, I am happy to be of help."
    new "没问题，我很乐意帮忙。"

translate chinese chinese_7603656_234:
    old "I just want you to know that you're fantastic, you accomplished to do the session without the proper training..."
    new "我只是想让你知道，你真的很棒，你在没有适当训练的情况下完成了那次训练……"

translate chinese chinese_3612809_235:
    old "I can see a great talent in you, I'm willing to teach you if want to know more, I hope I will not bother you again."
    new "我看出你很有天赋，如果你愿意学更多，我可以教你，希望以后不再打扰你。"

translate chinese chinese_0543537_236:
    old "Thank you very much, and don't worry you can ask me if you need more help."
    new "非常感谢，不用 worry，如果你还需要帮助可以问我。"

translate chinese chinese_4241882_237:
    old "Thank you honey, I appreciate your kindness."
    new "谢谢你宝贝，我很感激你的善良。"

translate chinese chinese_4607801_238:
    old "Hi, [pla], how are you?"
    new "嗨，[pla]，你好吗？"

translate chinese chinese_1572257_239:
    old "I am fine, thank you. How about you?"
    new "我很好，谢谢。你呢？"

translate chinese chinese_2005789_240:
    old "I am well, actually I'm kind of concerned..."
    new "我挺好的，不过有点担心……"

translate chinese chinese_1541527_241:
    old "Why is that?"
    new "为什么呢？"

translate chinese chinese_8742743_242:
    old "To be honest, I think you're better than what I thought, Anastasia was really pleased with your job last time, so she wants to continue the program with you..."
    new "说实话，我觉得你比我想象中的要好，上次Anastasia对你的工作非常满意，所以她想继续和你进行这个项目..."

translate chinese chinese_0546678_243:
    old "A- Anastasia?"
    new "安-安娜斯塔西娅？"

translate chinese chinese_5114121_244:
    old "Yes, however, my concern is... I didn't want to ask you again, however since Anastasia is asking for you, I want her to have the best experience..."
    new "是的，不过我的顾虑是……我不想再问你了，但是既然阿纳斯塔西娅在找你，我希望她能有最好的体验……"

translate chinese chinese_6741230_245:
    old "Of course the decision hasn't been made yet, I explained to her I needed to discuss it with you first, before I could say yes or no, so I just wanted to let you know."
    new "当然还没决定，我跟她解释说需要先跟你商量一下，才能给出答复，所以就想提前跟你说一声。"

translate chinese chinese_9469159_246:
    old "Last time you helped me but since this is going to be a more frequent assistances, I am thinking you can be part of the business and you will have an income..."
    new "上次你帮了我，但既然这会变成更频繁的帮助，我想你可以成为公司的一员，会有收入的……"

translate chinese chinese_9062148_247:
    old "It will also bring positive things to your life, making it part of this new way of living. You know the more that you feel the universe the better you can share with others."
    new "这也会给你的生活带来积极的影响，成为这种新生活方式的一部分。你知道的，你越是感受宇宙，就越能与他人分享。"

translate chinese chinese_6769717_248:
    old "I will give you the proper training, so you'll have the knowledge you need, we can make the business grow together, I know other customers will love your job too."
    new "我会给你正规的培训，让你掌握所需的知识，我们可以一起把生意做大，我知道其他客户也会喜欢你的工作的。"

translate chinese chinese_6037109_249:
    old "I appreciate you considering me as an option, I will gladly help you."
    new "感谢你把我当作一个选项，我乐意帮忙。"

translate chinese chinese_4456409_250:
    old "Oh [pla], you are very kind, I have no words on how I appreciate your help, I will do everything I can so you can learn more."
    new "哦 [pla]，你真是太好了，我不知道该怎么表达我对你的帮助的感激之情，我会尽我所能让你学到更多。"

translate chinese chinese_9048369_251:
    old "Don't worry, I'm glad to help."
    new "别担心，我很乐意帮忙。"

translate chinese chinese_6786123_252:
    old "Actually, are you too busy right now?"
    new "actually, 你现在太忙了？"

translate chinese chinese_8037279_253:
    old "You mean now? I think I can stay for a while, why do you ask?"
    new "你是说现在吗？我觉得我可以待一会儿，为什么问这个？"

translate chinese chinese_6138089_254:
    old "It's because we can go ahead with a practice today the next session you will have with Anastasia."
    new "是因为在下一次和阿纳斯塔西娅的课程中，你可以进行一次实战练习。"

translate chinese chinese_3620230_255:
    old "Oh, I see, sounds good."
    new "哦，我明白了，听起来不错。"

translate chinese chinese_4161971_256:
    old "Perfect, let's go."
    new "完美，走吧。"

translate chinese chinese_1263581_257:
    old "Now let's get ready to start, please remember to control your breathing so we can make the most out of the exercise."
    new "现在准备开始吧，请记得控制好呼吸，这样才能更好地完成锻炼。"

translate chinese chinese_7787432_258:
    old "Since the previous positions  you worked with her were more aimed to release stress and anxiety, this time we will get more into the yoga world, so you can discover more sensations."
    new "因为你之前和她一起做的姿势更多是为了缓解压力和焦虑，这次我们会更深入瑜伽的世界，让你能发现更多的感觉。"

translate chinese chinese_0305059_259:
    old "The first position we will work on is extremely demanding, you need to be very careful so you can give the right directions..."
    new "我们首先要进行的姿势要求非常高，你需要非常小心，才能给出正确的指导……"

translate chinese chinese_4346480_260:
    old "Depending on you the customer can feel more energy coming thru."
    new "这取决于你，顾客会感到更多的能量传递过来。"

translate chinese chinese_9466738_261:
    old "Ok, what... Do I need to do?"
    new "好，什么……我需要做些什么？"

translate chinese chinese_4028728_262:
    old "For the position, we will focus on the back, You will make sure I can get the perfect position, I will be on my hands and feet, looking straight."
    new "对于姿势，我们会专注于背面，你要确保我能摆出完美的姿势，我会手脚着地，正面朝前。"

translate chinese chinese_5897463_263:
    old "You need to help stretch the back by applying some pressure on the hips, Initially the weight of the body will be on the arms..."
    new "你需要通过在髋部施加一些压力来帮助拉伸背部，最初身体的重量会落在手臂上……"

translate chinese chinese_6086569_264:
    old "After some seconds we will need to change and apply it to the legs, you need to help the customer lift the hips and now firmly apply pressure with your pelvis."
    new "几秒钟后我们需要给腿部换药并涂抹，你需要帮助顾客抬起臀部，现在用你的骨盆部位坚定地施加压力。"

translate chinese chinese_7605512_265:
    old "We will need to repeat that movement several times, watch your breathing and making sure the position is being done properly. Got it?"
    new "我们需要重复那个动作几次，注意呼吸，确保姿势正确。明白了吗？"

translate chinese chinese_8586141_266:
    old "Perfect, let's try it."
    new "完美，咱们试试吧。"

translate chinese chinese_8046165_267:
    old "That's it... You are doing it right."
    new "就是这么回事……你做得对。"

translate chinese chinese_9471080_268:
    old "(Oh god this is quite enticing, I will need to touch her butt to grab her hips...)"
    new "（天啊，这真的很诱人，我需要摸她的屁股来抓住她的腰……）"

translate chinese chinese_6481300_269:
    old "Don't forget to hold the hips firmly, the muscle must be exercised."
    new "别忘了紧抱她的臀部，肌肉得锻炼。"

translate chinese chinese_4313567_270:
    old "(If I do it any harder, I'll touch her pussy.)"
    new "（再用力一点我就碰到她的下体了。）"

translate chinese chinese_9837267_271:
    old "Don't worry... I will do it."
    new "别担心……我会做的。"

translate chinese chinese_9259955_272:
    old "Perfect, that will help us to ensure the customer is getting the right position."
    new "完美，这将帮助我们确保客户得到正确的姿势。"

translate chinese chinese_6885089_273:
    old "That was very good, you are doing good. Now let's move to the second position."
    new "非常好，你做得很好。现在让我们换到第二个姿势。"

translate chinese chinese_4295910_274:
    old "Good! What's up with this one?"
    new "好！这个是怎么回事？"

translate chinese chinese_5400589_275:
    old "As you can imagine, we need to increase the difficulty, for the next position your help is essential, I will relax my entire body, you will hold my hips..."
    new "想必你也明白，我们需要增加难度，接下来的位置你的帮助至关重要，我会全身放松，你抱住我的臀部……"

translate chinese chinese_8305985_276:
    old "The first step will be to carry my body weight, you can support yourself with your pelvis, however I understand that could be very tiring, that is why we'll have some tiny breaks."
    new "第一步是承受我的体重，你可以用骨盆支撑自己，不过我明白这可能会非常累人，所以我们会有一些小休息。"

translate chinese chinese_9178089_277:
    old "Since you are using your pelvis, the breaks moment will be to relax your pelvis and let the weight remain on the customers arms and your legs."
    new "因为你用了骨盆，所以在间歇的时候要放松骨盆，让体重靠在顾客的手臂和你的腿上。"

translate chinese chinese_9292380_278:
    old "Ok, sounds a bit difficult."
    new "好吧，听起来有点难。"

translate chinese chinese_2815476_279:
    old "Not really... However, that is why you need to keep breathing and stay focused so you can use your strength smartly and make the exercise enjoyable for you too."
    new "不太……不过，这就是为什么你需要保持呼吸，集中注意力，这样你可以聪明地使用你的力量，让锻炼也变得有趣。"

translate chinese chinese_6904421_280:
    old "Let's do it! Now that you have the idea."
    new "干吧！既然你已经有想法了。"

translate chinese chinese_9150565_281:
    old "Sure, go ahead."
    new "行，你来吧。"

translate chinese chinese_2683645_282:
    old "Use your chakras to control your breathing that is the key for a position like this."
    new "用你的脉轮控制呼吸，这是这个姿势的关键。"

translate chinese chinese_6706287_283:
    old "Sure, I am breathing deeply and consciously."
    new "好吧，我正在深呼吸并保持清醒。"

translate chinese chinese_4926881_284:
    old "I am very satisfied to hear that, try to use all your energy."
    new "听到这个我很满意，尽量用尽你的所有力气。"

translate chinese chinese_1994975_285:
    old "(This feels very delectable, she's rubbing my cock... I'm getting hard now...)"
    new "(这感觉很美妙，她在揉我的鸡巴……我现在硬了……)"

translate chinese chinese_5062599_286:
    old "You need to focus too, so the exercise can be effective."
    new "你也需要集中注意力，这样练习才能有效。"

translate chinese chinese_4773970_287:
    old "Keep doing that for a while with your customer, we will stop for now so we can continue with our next position, I can see you learn very fast."
    new "继续这样为客户服务一会儿，我们现在停下来，接下来换下一个姿势，我看你学得很快。"

translate chinese chinese_9008214_288:
    old "(Oh, thanks god!)..."
    new "（哦，谢天谢地！）..."

translate chinese chinese_8482694_289:
    old "(I don't know if I will be able to hide my boner this time.)"
    new "（我不知道这次是否能隐藏起我的勃起。）"

translate chinese chinese_3343396_290:
    old "The last position is quite interesting, is related with the energies we have accumulated in the back, we will need to ignite them so we can release more of our chakra's potential..."
    new "最后一个姿势相当有趣，与我们背部积累的能量有关，我们需要点燃它们，以便释放更多查克拉的潜力……"

translate chinese chinese_3839382_291:
    old "Since they are located in your back right before the gluteus,the position is aimed to get those points. Your customer will probably need you to get in that position."
    new "因为它们位于你的臀部上方，这个姿势就是为了刺激那些点。你的顾客可能需要你摆出那个姿势。"

translate chinese chinese_5810316_292:
    old "I will lie down on my shoulders, but I will hold my waist with my hands, my arms are going to be the main support."
    new "我会躺在肩膀上，但用手抱住腰部，我的手臂将会是主要支撑。"

translate chinese chinese_5627410_293:
    old "You will keep balance of the body as well as the pressure needed in two different points, the legs and back of the customer."
    new "你需要保持身体的平衡，并在两个不同的点上施加所需的压力，即客户的腿和背部。"

translate chinese chinese_5382792_294:
    old "Let's start the position so you can have a better idea..."
    new "咱们先摆个姿势，让你有个更好的想法……"

translate chinese chinese_9103506_295:
    old "(This position looks demanding so I will stay focused, I need to breath and to think something different.)"
    new "（这个姿势看起来很吃力，我得集中注意力，需要深呼吸并想想别的事情。）"

translate chinese chinese_8685596_296:
    old "Perfect, I am ready."
    new "完美，我准备好了。"

translate chinese chinese_7702482_297:
    old "Perfect here we go..."
    new "完美，来了..."

translate chinese chinese_5766030_298:
    old "(Oh no, this position is making me feel very horny, I am sure she will notice pretty soon.)"
    new "（哦不，这个姿势让我感觉很兴奋，我敢肯定她很快就会注意到的。）"

translate chinese chinese_8622743_299:
    old "Are you breathing properly, remember this is important for you to be able to assist your customer."
    new "你呼吸正常吗？记住，这对你能协助顾客很重要。"

translate chinese chinese_1471388_300:
    old "Hmm... Sure, yes."
    new "嗯……好啊，可以。"

translate chinese chinese_0224656_301:
    old "I can see you are quite motivated with this asana, you will need to control your energies so you can decide how to express or attract with your body."
    new "我看得出来你对这个体式很有动力，你需要控制自己的能量，这样才能决定如何用身体来表达或吸引。"

translate chinese chinese_2852799_302:
    old "Alright, I think we are done..."
    new "好吧，我觉得我们差不多了……"

translate chinese chinese_7586001_303:
    old "OH MY GOD!"
    new "天啊！"

translate chinese chinese_9961366_304:
    old "I- I'm sorry, I'm so sorry these positions are really enticing... A- and I can't help it."
    new "我……对不起，这些姿势真的太诱人了……我控制不住。"

translate chinese chinese_2591936_305:
    old "Don't worry, it's natural, I just got surprised by the... Size..."
    new "别担心，这是正常的，我只是被...大小...惊到了..."

translate chinese chinese_1240065_306:
    old "Well, this happened because your chakras are unbalanced."
    new "好吧，这是因为你的查克拉不平衡。"

translate chinese chinese_2269950_307:
    old "My cha- kras?"
    new "我的cha- kras？"

translate chinese chinese_6845316_308:
    old "Yes, I think you need to reharmonize your chakra ‘Muladhara', this is the sexual chakra and is clearly unbalanced in you."
    new "是的，我觉得你需要重新调整你的脉轮‘ Muladhara’，这是性脉轮，显然你在这一方面不平衡。"

translate chinese chinese_5305306_309:
    old "But, don't worry, once you harmonize your chakra Muladhara, you will be more stable, and you will be able to prevent these unexpected body reactions."
    new "但是不用担心，一旦你调和了你的脉轮穆拉达拉，你会变得更加稳定，就能防止这些意外的身体反应了。"

translate chinese chinese_6564318_310:
    old "I think you need to work on that, we can do some tantric rituals so you can restore your chakras to their natural energy."
    new "我觉得你需要在这方面多下点功夫，我们可以做一些 tantra 仪式来恢复你的脉轮能量。"

translate chinese chinese_6959292_311:
    old "A tantric what?"
    new "什么是 tantra？"

translate chinese chinese_5692180_312:
    old "Tantric rituals, it's a very spiritual technique where we clean your chakras. I think we should do it tonight."
    new "tantra仪式，这是一种非常精神层面的技术，可以清理你的脉轮。我觉得我们今晚就做吧。"

translate chinese chinese_0171427_313:
    old "T- tonight?"
    new "今、今晚？"

translate chinese chinese_8159059_314:
    old "Yes, I need to prepare a few things for the ritual, And you need to balance your chakras before your next yoga session with Anastasia."
    new "好的，我需要为仪式准备几样东西，而且在你下次和阿纳斯塔西娅的瑜伽课程前，你需要平衡你的脉轮。"

translate chinese chinese_9060803_315:
    old "We don't want you to have this kind of... Reactions with her, don't we?"
    new "我们不希望你对她有这样的……反应，对吧？"

translate chinese chinese_4054718_316:
    old "Hmm... No, no, of course not... No."
    new "嗯……不，不，当然不是……不是。"

translate chinese chinese_5249018_317:
    old "Ok, then I'll make the preparations for our tantric ritual."
    new "好的，那我就准备我们的 tantra 仪式。"

translate chinese chinese_9164655_318:
    old "It was nice to practice with you today! See you later."
    new "今天和你一起练习很开心！回头见。"

translate chinese chinese_0302411_319:
    old "See you then."
    new "到时候见。"

translate chinese chinese_9048002_320:
    old "Wow... W- what are you... W- wearing?"
    new "哇……你穿的……是什么？"

translate chinese chinese_2378418_321:
    old "Oh, hi, [pla], glad to see you... These collars you see are some elements that make part of the ritual we will do tonight; they will help to keep the balance of your chakras."
    new "哦，你好，[pla]，见到你很高兴……你看到的这些项圈是我们今晚仪式的一部分；它们有助于保持你的脉轮平衡。"

translate chinese chinese_6066895_322:
    old "Let's go to the room so I can explain everything to you..."
    new "我们去房间吧，我详细解释给你听..."

translate chinese chinese_2601144_323:
    old "Everything is set in this room so we can cleanse those energies and balance your chakras..."
    new "这个房间里的一切都布置好了，以便净化那些能量并平衡你的脉轮……"

translate chinese chinese_4782835_324:
    old "I hope you can take advantage of the lights, the fragrances, as well as the location, we are about to do a very important ritual, so every single detail must help us get in the mood."
    new "我希望你能利用灯光、香气以及这个地方，我们即将进行一个非常重要的仪式，所以每一个细节都必须帮助我们进入状态。"

translate chinese chinese_2300291_325:
    old "Please I need you to open your mind so the exercises we do tonight will be more effective..."
    new "拜托了，我需要你放开思想，这样我们今晚做的练习才会更有效……"

translate chinese chinese_3430362_326:
    old "Some of the exercises of the ritual will have a lot of contact so please let the massages follow its course, it is a very spiritual process."
    new "一些仪式中的练习会有很多身体接触，请让按摩自然进行，这是一个非常精神的过程。"

translate chinese chinese_6243686_327:
    old "M- massages?"
    new "按摩？"

translate chinese chinese_3257993_328:
    old "We need to compenetrate each other today so I can balance right your chakras."
    new "今天我们得互相融合一下，好让你的脉轮达到平衡。"

translate chinese chinese_2505018_329:
    old "I did some meditation today so the massages can be very deep and productive for you so please merge with me to have a great experience."
    new "我今天做了些冥想，所以按摩可以非常深入有效，请和我融为一体，享受这段美好时光。"

translate chinese chinese_0021977_330:
    old "It's a very beautiful way to perceive what surrounds you, so you need to express according to the energies that you will be able to recognize... Let's start."
    new "这是一种非常美丽的感知周围事物的方式，所以你需要根据你能识别的能量来表达……我们开始吧。"

translate chinese chinese_5672825_331:
    old "First, I need you to undress so we can uncover our energies."
    new "首先，你需要脱衣服，这样我们才能释放能量。"

translate chinese chinese_3770459_332:
    old "U- undress?"
    new "脱-脱衣服？"

translate chinese chinese_5143888_333:
    old "Yes, please don't take it the wrong way, this is a very pure experience so I need you to undress not only the clothes but also your mind and soul."
    new "好的，别误会，这是一次非常纯洁的体验，所以你需要脱掉的不仅是衣服，还有你的思想和灵魂。"

translate chinese chinese_6520312_334:
    old "Keep in mind your body is something beautiful and it doesn't make you feel embarrassed, it's natural as universe is and we are going beyond to see how to control its energy."
    new "记住，你的身体是美丽的，它不会让你感到尴尬，它是自然的，就像宇宙一样，我们正在超越界限，去探索如何控制它的能量。"

translate chinese chinese_1251394_335:
    old "Let's keep working on our breathing, remember the pranayama, we need to concentrate so you can open your senses, that is the main purpose of this exercise today."
    new "我们继续练习呼吸吧，记得要用调息法，我们需要集中注意力，让你的感官打开，这是今天练习的主要目的。"

translate chinese chinese_6899869_336:
    old "Hmm, sure..."
    new "嗯，好吧……"

translate chinese chinese_7546922_337:
    old "I need you to concentrate, smell the candles, the ambience we have for this moment, do you feel the fragrance?"
    new "我需要你集中精神，闻一闻这些蜡烛，感受这一刻的氛围，你能闻到香味吗？"

translate chinese chinese_3457316_338:
    old "Yes, it smells nice."
    new "是的，闻起来不错。"

translate chinese chinese_3600808_339:
    old "Great!, now please lie down with your stomach on the floor, then relax, I will do the massage, you will feel my body helping yours to open your senses."
    new "太好了！请趴下来，肚子贴着地面，放松身体，我会帮你按摩的，你会感觉到我的身体帮助你的感官打开。"

translate chinese chinese_6479160_340:
    old "let me start with your shoulders, so you can feel more."
    new "我先从你的肩膀开始，让你感受更多。"

translate chinese chinese_1325162_341:
    old "Please hold your breath a bit more, so we can intensify the fragrance and focus your thoughts."
    new "请再屏住呼吸一会儿，这样可以增强香气，让你更加专注。"

translate chinese chinese_9849678_342:
    old "Good, do you feel my touch, my skin... How do you feel?"
    new "好，你能感觉到我的触摸，我的皮肤……你觉得怎么样？"

translate chinese chinese_8459589_343:
    old "It's very soft."
    new "很软。"

translate chinese chinese_9759065_344:
    old "That's perfect, you are doing good."
    new "perfect完美，你做得很好。"

translate chinese chinese_3065964_345:
    old "Let me touch your skin now so we can release the pressure, breath with me, it's just one pace, don't stop..."
    new "让我现在触摸你的皮肤，我们可以释放压力，跟我一起呼吸，就一步，不要停..."

translate chinese chinese_6472143_346:
    old "Feel free to express and feel everything your body wants to feel at this moment, I will control everything so you can go freely wherever your mind wants."
    new "随意表达并感受身体此刻想感受到的一切，我会掌控一切，让你随心所欲地去任何你想去的地方。"

translate chinese chinese_8445679_347:
    old "Try harder to focus, it's just this moment, there is nothing else to think about, but the sensations, can you smell it?"
    new "努力集中注意力，就在这片刻，没什么好想的，只有这些感觉，你能闻到吗？"

translate chinese chinese_6977769_348:
    old "Yes, I can."
    new "可以，我能做到。"

translate chinese chinese_5134048_349:
    old "I feel amazing, I appreciate your time and effort to help me."
    new "我感觉太棒了，真的很感谢你花时间和精力帮助我。"

translate chinese chinese_2501830_350:
    old "Oh no, it's no trouble, I'm just an instrument from the universe to help you with your energies."
    new "哦不，没关系，我只是宇宙中帮助你调节能量的工具而已。"

translate chinese chinese_3415373_351:
    old "Just relax and please keep learning so you can apply all your knowledge to the sessions with your customers. I am sure now you won't have these issues with Anastasia."
    new "放松点，继续学习吧，这样你就能把所有知识应用到和客户的会话中了。我相信你现在不会再和安纳斯塔西娅遇到这些问题了。"

translate chinese chinese_2003043_352:
    old "I can also feel a different aura on you now, I can feel your spirit is more calmed."
    new "我现在也能感受到你身上的不同气息，感觉你的精神更加平静了。"

translate chinese chinese_7403707_353:
    old "Thank you for all that you have done."
    new "感谢你做的一切。"

translate chinese chinese_1086171_354:
    old "It's something I enjoy, please have some rest."
    new "这是我喜欢的东西，请你休息一下。"

translate chinese chinese_7296599_355:
    old "I'll do it, have a great one too."
    new "我来吧，你也玩得开心点。"

translate chinese chinese_7594032_356:
    old "Good night, [pla]."
    new "晚安，[pla]。"

translate chinese chinese_6383982_357:
    old "Good night."
    new "晚安。"

translate chinese chinese_5393502_358:
    old "Welcome [pla], we were waiting for you."
    new "欢迎[pla]，我们在等你。"

translate chinese chinese_8572401_359:
    old "Hi, I am sorry if I'm late."
    new "嗨，对不起我可能晚了。"

translate chinese chinese_2734232_360:
    old "Oh don't worry, you are just on time."
    new "哦，别担心，你正好赶上了。"

translate chinese chinese_4966326_361:
    old "How do you feel today, are you ready to have the second session with Anastasia?"
    new "今天感觉怎么样，准备好和阿纳斯塔西娅进行第二次会面了吗？"

translate chinese chinese_3822352_362:
    old "Yes, I've been thinking about it."
    new "是的，我一直在考虑这件事。"

translate chinese chinese_7102902_363:
    old "Perfect, Well guys I am glad to see you both, I know you are working hard and improving!"
    new "完美，见到你们两个我非常高兴，我知道你们都在努力进步！"

translate chinese chinese_3945209_364:
    old "How about you Anastasia, how do you feel today?"
    new "安娜斯塔西娅，你今天感觉怎么样？"

translate chinese chinese_4677629_365:
    old "I am quite happy with my trainer because he has HUGE talent, I am prepared today. [pla], is it going to be HARDER than last time?"
    new "我对我的训练师很满意，因为他有巨大的天赋，我今天已经准备好了。[pla]，会比上次更猛吗？"

translate chinese chinese_6948363_366:
    old "I- I'm sure this is going to... to be a good session."
    new "我我确信这这会是一次很好的环节。"

translate chinese chinese_2125119_367:
    old "Perfect, I will leave you guys alone so you can do the session with no inconveniences. I will be here to give you proper privacy."
    new "完美，我就不管你们了，这样你们可以毫无顾忌地进行。我会给你们足够的隐私。"

translate chinese chinese_5918577_368:
    old "The room is already prepared."
    new "房间已经准备好了。"

translate chinese chinese_1713962_369:
    old "Anastasia I hope you enjoy your session you will be in good hands."
    new "阿纳斯塔西娅，希望你能享受这次体验，你会得到很好的照顾。"

translate chinese chinese_0621132_370:
    old "Yes, I'm pretty sure he's really good with his hands, I'll enjoy the session."
    new "是的，我敢肯定他手法很好，我会享受这个过程的。"

translate chinese chinese_9865341_371:
    old "Aww, I love that energy, please work hard... See you guys."
    new "哎呀，我喜欢这种活力，请加油……大家再见。"

translate chinese chinese_6524941_372:
    old "... See you."
    new "...再见。"

translate chinese chinese_8168044_373:
    old "Well, Today we will continue the meditation process, remem-"
    new "好吧，今天我们将继续冥想过程，记着-"

translate chinese chinese_2543619_374:
    old "I wanted to- sorry to interrupt you..."
    new "我想——对不起，打断你了……"

translate chinese chinese_9472327_375:
    old "Oh, it's ok, tell me."
    new "哦，没事，告诉我吧。"

translate chinese chinese_8502855_376:
    old "It is just that... I wanted to try something different today, you know."
    new "就是觉得……今天想试试不一样的，你知道的。"

translate chinese chinese_5122125_377:
    old "Hmm... What did you have in mind?"
    new "嗯……你有什么想法？"

translate chinese chinese_0578731_378:
    old "Well being honest, I was kind of distracted, I was not able to forget about your cock... And I want you to fuck me with that big hard cock."
    new "说实话，我有点分心，忘不了你的那个东西……我想让你用那个大硬东西狠狠地弄我。"

translate chinese chinese_4342425_379:
    old "(WHAT THE FUCK!)"
    new "（妈的！）"

translate chinese chinese_2148547_380:
    old "WHAT? B- but, we need to have a yoga session..."
    new "什么？但……我们需要做瑜伽……"

translate chinese chinese_8098405_381:
    old "The truth is I am very horny today, I came considering to have sex with you..."
    new "说实话，我今天特别想入非非，来的时候就在想和你做爱的事……"

translate chinese chinese_2266861_382:
    old "Oh, it seems like you're getting ready... Why don't you get these pants off?"
    new "哦，看来你准备好了……把这些裤子脱掉怎么样？"

translate chinese chinese_9648715_383:
    old "I- it's not-"
    new "我—不是—"

translate chinese chinese_2819268_384:
    old "Don't be shy, I know both of us will feel very good after that, I am just a bit thirsty, can I get a taste?"
    new "别害羞，我知道我们俩事后都会感觉很好的，我只是有点渴，能让我尝一下吗？"

translate chinese chinese_5532192_385:
    old "Oh, yeah, this is what I'm talking about..."
    new "哦，对了，这就是我说的..."

translate chinese chinese_7555615_386:
    old "That was delicious, but now I want you to fuck me!"
    new "那真好吃，但现在我要你操我！"

translate chinese chinese_4075862_387:
    old "W- what? Oh, no Lisa is downstairs she could-"
    new "什、什么？哦，不对，丽莎在楼下，她可能——"

translate chinese chinese_5884291_388:
    old "Maybe you need a bit of motivation... You want to see them again, don't you?"
    new "maybe你需要一点动力……你想再见到他们，对吧？"

translate chinese chinese_7462295_389:
    old "Now, let's fuck!"
    new "现在，让我们干吧！"

translate chinese chinese_7289992_390:
    old "You were amazing, I loved this session, I need this kind of session more often."
    new "你太棒了，我非常喜欢这次的环节，我需要更多这样的环节。"

translate chinese chinese_1727522_391:
    old "I can keep this a secret if you are afraid of your boss, she doesn't need to know our particular sessions, besides she doesn't have the big talent you have."
    new "如果你怕老板的话，我可以保守这个秘密，她不需要知道我们的特别时段，再说她也没有你的那种天赋。"

translate chinese chinese_9936325_392:
    old "I am considering you can get a tip later, for your hard work..."
    new "我在考虑你可以稍后得到一些小费，作为你的努力工作..."

translate chinese chinese_5377997_393:
    old "... I- I think we shouldn't-"
    new "……我- 我觉得我们不應該-"

translate chinese chinese_4788348_394:
    old "Do not worry honey, this was your best yoga session ever."
    new "别担心宝贝，这是你做瑜伽做得最好的一次了。"

translate chinese chinese_8587654_395:
    old "Hi guys, congratulations I can see you are sweating, that means you had a very hard job today."
    new "大家好，恭喜你们，我看到你们在出汗，这意味着你们今天工作很辛苦。"

translate chinese chinese_5401333_396:
    old "Yes, [pla] took a lot out of me today."
    new "是的，[pla]今天让我筋疲力尽。"

translate chinese chinese_9743908_397:
    old "He is improving every day; I can tell you he's putting in a big effort."
    new "他每天都在进步，我能看出来他在努力。"

translate chinese chinese_3262979_398:
    old "I can see that, I hope we can meet again later, the sooner the better."
    new "我明白，希望我们能再见面，越快越好。"

translate chinese chinese_9209292_399:
    old "Oh sure, I have your appointment already set. Don't worry, we will be waiting for you."
    new "哦，好的，你的预约已经安排好了。放心吧，我们会等你的。"

translate chinese chinese_0512769_400:
    old "Perfect, thank you for the session today... And thank you very much for your hard, hard work [pla], I really enjoy it."
    new "完美，感谢你今天的配合……非常感谢你的努力工作[pla]，我真的很享受。"

translate chinese chinese_9804614_401:
    old "Bye Anastasia, have a great day!"
    new "再见安纳斯塔西娅，祝你今天愉快！"

translate chinese chinese_4016935_402:
    old "I am very satisfied with your job, I wanted you to know that I am considering to introduce you to other customers, I think you are so easy going, that people will just connect with you."
    new "我对你的工作非常满意，我想让你知道我正在考虑把你介绍给其他客户，我觉得你很容易相处，人们会很容易和你建立联系。"

translate chinese chinese_0473306_403:
    old "O- other customers, I- I don't know-"
    new "有-其他顾客，我-我不知道-"

translate chinese chinese_4469251_404:
    old "You can help other people, your energy will just bring you what you need, you only need to keep on working hard..."
    new "你可以帮助别人，你的精力会带给你所需的一切，你只需要继续努力工作..."

translate chinese chinese_9859821_405:
    old "Hmm if you say so..."
    new "嗯，如果你这么说的话……"

translate chinese chinese_6046846_406:
    old "Oh, by the way, remember we will have tomorrow a new ritual, the tantric massages need to be continued so we can balance your chakras."
    new "哦，对了，记得明天有个新的仪式，需要继续做 tantra 按摩来平衡你的脉轮。"

translate chinese chinese_3925191_407:
    old "Amazing, thank you for today, please get some rest."
    new "真棒，感谢今天的陪伴，请好好休息。"

translate chinese chinese_6819632_408:
    old "See you later [pla]!"
    new "再见 [pla]！"

translate chinese chinese_9822808_409:
    old "Hi [pla], nice to see you again!"
    new "你好[pla]，又见到你真好！"

translate chinese chinese_7247452_410:
    old "Hello, Thank you."
    new "你好，谢谢。"

translate chinese chinese_7268456_411:
    old "I am very happy because you are very committed with this extra training."
    new "我非常高兴，因为你对这个额外训练非常投入。"

translate chinese chinese_0144714_412:
    old "I appreciate you are taking the time to teach me."
    new "我感激你花时间教我。"

translate chinese chinese_0461719_413:
    old "Any time, you are helping a lot with my business, I will do my best so you can be as good as me."
    new "任何时候，你对我生意的帮助都很大，我会尽全力让你也能变得像我一样出色。"

translate chinese chinese_9696867_414:
    old "Hmm, that is very nice of you."
    new "嗯，你真好。"

translate chinese chinese_1326218_415:
    old "Let's go to the room so we can start the tantric session."
    new "我们去房间开始 tantra 课程吧。"

translate chinese chinese_9531734_416:
    old "Have you seen any improvement thanks to last session?"
    new "上一次之后你有什么进步吗？"

translate chinese chinese_8920510_417:
    old "Yes... I can feel in a better mood."
    new "是的……我觉得心情好多了。"

translate chinese chinese_2274737_418:
    old "Good, you will see better results."
    new "好的，你会看到更好的效果。"

translate chinese chinese_0124608_419:
    old "Today we need to improve a lot because you need to be able to balance your chakra muladhara as soon as possible, that way you can offer a more delightful experience."
    new "今天我们得大幅进步，因为你需要尽快平衡你的查克拉根基脉轮，这样你可以提供更愉悦的体验。"

translate chinese chinese_6318657_420:
    old "Please get comfortable, you know we need to open our mind, just relax because this is not any casual meeting, your body is more than flesh, blood and energy..."
    new "请放松一点，你知道我们需要敞开心扉，因为这可不是普通的见面，你的身体不仅仅是血肉和能量……"

translate chinese chinese_0749239_421:
    old "So, there's nothing to feel shy about, please undress."
    new "所以，没什么好害羞的，请脱衣服吧。"

translate chinese chinese_7999490_422:
    old "Perfect, so today we need to increase the perception of our senses, you must feel more, once you connect your sexual chakra, we will start with the massage."
    new "完美，所以今天我们需要增强感官的感知，你必须感受更多，一旦你的性脉轮连接上，我们就从按摩开始。"

translate chinese chinese_1257718_423:
    old "The idea is to recognize some feelings that only you can see, some situations that are deep inside, no one will be able to get there... Do not forget to feel the energy..."
    new "这个想法是去认识一些只有你能看到的感觉，一些深藏在里面的情况，没有人能到达那里……不要忘了感受那种能量……"

translate chinese chinese_4601767_424:
    old "While feeling my body on your skin please bring that healing energy in and allow it to wash through your body and mind."
    new "感受我的身体贴着你的皮肤，把那种治愈的能量带进来，让它洗过你的身心。"

translate chinese chinese_1927127_425:
    old "Let your skin merge with mine, feel my fragrance, connect your senses with mine."
    new "让你的皮肤与我融为一体，感受我的香气，让我们的感官相连。"

translate chinese chinese_8344761_426:
    old "So, are you going to use your hands like last time?"
    new "所以，你这次也要用手吗？"

translate chinese chinese_2626829_427:
    old "No, we need to do better than last time, this time I want you to be able to experience a more intense moment, so I think my breast is going to be perfect."
    new "不，这次我们要做得比上次好，这次我想让你体验更强烈的感觉，所以我觉得我的胸部会很完美。"

translate chinese chinese_7427865_428:
    old "Y- your breast? ..."
    new "你、你的胸部？ ..."

translate chinese chinese_3900090_429:
    old "Yes, remember this is not a sexual act, this a spiritual ritual to connect together and cleanse your chakras."
    new "没错，记住这并不是性行为，这是一个精神仪式，用来连接彼此并净化你的脉轮。"

translate chinese chinese_8589722_430:
    old "Don't get distracted, keep focused so we can do the session and control your breathing."
    new "别分心，保持专注，这样我们才能进行这次训练并控制好呼吸。"

translate chinese chinese_1659050_431:
    old "... O- ok."
    new "... 好吧。"

translate chinese chinese_3379374_432:
    old "Just relax your body it is a part of the universe, where I can move freely and that way we can take it out..."
    new "放松身体，你是宇宙的一部分，在那里我可以自由移动，这样我们就可以进行下去了……"

translate chinese chinese_5127746_433:
    old "I can see your energy is more stable now, I am really proud of the effort you are putting in."
    new "我能看出你的状态现在更稳定了，我真的很为你付出的努力感到骄傲。"

translate chinese chinese_0764596_434:
    old "I think we have just one lesson left, according to the progress I have seen, this chakra muladhara is not so strong now, you are getting the balance you need."
    new "我觉得我们只剩下一节课了，根据我看到的进度，这个脉轮现在不是很强，你正在获得你需要的平衡。"

translate chinese chinese_9273771_435:
    old "There are still more things to learn, see you next time, you need to get some rest, don't forget tomorrow's lesson with Anastasia."
    new "还有很多东西要学，下次见，你需要休息一下，别忘了明天和阿纳斯塔西娅的课。"

translate chinese chinese_8998153_436:
    old "Sure, I'll be here... Thank you, bye."
    new "好吧，我就在这……谢谢，再见。"

translate chinese chinese_2718901_437:
    old "Hi Anastasia, welcome to your yoga session once again, I hope you are ready for the routine today."
    new "嗨，阿纳斯塔西娅，欢迎再次参加你的瑜伽课程，希望你今天准备好做常规练习了。"

translate chinese chinese_6602204_438:
    old "Hi Lisa, you are right I came prepared, this time I want to give my best and I hope [pla] brings a harder... Activity today."
    new "嗨，丽莎，你说得对，这次我有备而来，我想全力以赴，希望[pla]能带来更刺激的……活动。"

translate chinese chinese_8692036_439:
    old "Hi... Am I late?"
    new "嗨……我晚了吗？"

translate chinese chinese_8614385_440:
    old "Oh no, it's perfect timing, Anastasia was telling me she came prepared today..."
    new "哦不，时机正好，安纳斯塔西娅告诉我她今天有备而来……"

translate chinese chinese_1123762_441:
    old "I am very happy that your training has become something personal, it means that you guys are feeling connected through these exercises."
    new "我很高兴你的训练变得如此个人化，这意味着你们通过这些练习产生了连接。"

translate chinese chinese_0021675_442:
    old "I am so proud that you guys are improving together, I will leave you alone so you can do your routine, in case you need me, please let me know."
    new "我为你们能一起进步感到骄傲，我会给你们空间做你们的日常训练，如果需要我的话请告诉我。"

translate chinese chinese_3206520_443:
    old "Sure, I will let you know in case we need you, let's go to the room to start the lesson."
    new "好的，有需要我会通知你的，我们去房间开始上课吧。"

translate chinese chinese_8565424_444:
    old "Well, we have a very-"
    new "嗯，我们有一个非常-"

translate chinese chinese_6378198_445:
    old "I needed this urgently, so let's get straight to it..."
    new "这事很急，我们就直入正题吧……"

translate chinese chinese_9968678_446:
    old "I want MORE! I want you to be rude... Fuck me harder PLEASE!"
    new "我要更多！我要你粗鲁一点……拜托再用力点！"

translate chinese chinese_4819557_447:
    old "Oh, you've accomplished it, this was by far better than last time."
    new "哦，你做到了，这比上次好太多了。"

translate chinese chinese_1049006_448:
    old "Could you make it better next time? I wanna see that!"
    new "下次能不能做得好一点？我想看看！"

translate chinese chinese_6979450_449:
    old "N- next time?"
    new "下、下次？"

translate chinese chinese_4061896_450:
    old "I am really happy for every penny I have spent here; I will speak highly of you with some friends, they will love you..."
    new "我真的很庆幸在这里花的每一分钱；我会向一些朋友大力推荐你，他们一定会喜欢你的..."

translate chinese chinese_5075012_451:
    old "Alright, thanks for everything it's time to go."
    new "好吧，谢谢一切，时候不早了。"

translate chinese chinese_2590302_452:
    old "Oh Lisa, h- how are you?"
    new "哦，丽莎，你过得怎么样？"

translate chinese chinese_0742243_453:
    old "I can see the 'Lesson' has finished."
    new "我看得出来‘课程’已经结束了。"

translate chinese chinese_7786764_454:
    old "I want to congratulate you guys for the effort you are doing on every lesson, I can see every time is better, did you like it Anastasia."
    new "我想祝贺你们在每节课上的努力，我每次都能看出你们的进步，安纳斯塔西娅，你喜欢吗？"

translate chinese chinese_2376249_455:
    old "It was the best session ever; I am considering opening my schedule so we can make my sessions more frequent."
    new "这是有史以来最好的一次，我在考虑调整我的日程，让我们能更频繁地见面。"

translate chinese chinese_0322076_456:
    old "Of course we could discuss it later, you can have as many sessions as you need..."
    new "当然可以等会再讨论，你可以有任意多的次数……"

translate chinese chinese_9713278_457:
    old "Fascinating! Next meeting we will check that."
    new "真有趣！下次见面我们就检查那个。"

translate chinese chinese_7198946_458:
    old "Hope you get some rest Anastasia, see you on next appointment."
    new "希望你好好休息一下，安娜斯塔西娅，下次再见。"

translate chinese chinese_9687216_459:
    old "Oh thank you, I will, see you next time."
    new "哦，谢谢你，下次见。"

translate chinese chinese_9337361_460:
    old "Everything was amazing, thank you [pla]."
    new "一切都太棒了，谢谢你[pla]。"

translate chinese chinese_4377348_461:
    old "No problem, see you next session."
    new "没问题，下次见。"

translate chinese chinese_1926430_462:
    old "Are you leaving too?"
    new "你也要走吗？"

translate chinese chinese_5393730_463:
    old "I guess so... ?"
    new "我猜是这样的... ?"

translate chinese chinese_5828440_464:
    old "I need to talk to you about something before you leave."
    new "在你走之前，我有件事需要和你谈谈。"

translate chinese chinese_3087881_465:
    old "Hmm, sure... What is it?"
    new "嗯，好吧……是什么？"

translate chinese chinese_0815951_466:
    old "I think it's not acceptable... I know you are not doing the routine we have been preparing..."
    new "我觉得这不可接受……我知道你没有按照我们准备的流程来……"

translate chinese chinese_1434263_467:
    old "I assume the previous routines were not done either, am I right?"
    new "我猜之前的例行公事也没做，对吧？"

translate chinese chinese_5370396_468:
    old "(Oh shit... Did she noticed we were having SEX)"
    new "（哦shit... 她注意到我们在做爱了吗）"

translate chinese chinese_5217948_469:
    old "W- what are you... T- talking about?"
    new "你... 在说什么？"

translate chinese chinese_8756819_470:
    old "Do not try to hide it, do you think I didn't hear her moaning?"
    new "别想隐瞒，你以为我没听见她的呻吟吗？"

translate chinese chinese_8379452_471:
    old "I- I don't know what-"
    new "我- 我不知道什么-"

translate chinese chinese_8926229_472:
    old "[pla], I heard what you were doing, and I can swear, it was not a yoga routine, you both were having sex!"
    new "[pla]，我听到你们在里面的声音了，绝对不是在练瑜伽，你们是在做爱！"

translate chinese chinese_0248392_473:
    old "(Oh God, she's going to kill me.)"
    new "（天啊，她要杀了我。）"

translate chinese chinese_9918095_474:
    old "I- I am very sorry, it wasn't my inte-"
    new "我我非常抱歉，这并不是我的本意"

translate chinese chinese_9809858_475:
    old "Do you know what really pisses me off?"
    new "你知道什么真的让我生气吗？"

translate chinese chinese_4749317_476:
    old "I mean I don't care if you are having sex or not, you can connect with anybody and share your energy, sex is beautiful and good way to connect together."
    new "我的意思是，我不管你是不是在做爱，你可以和任何人连接分享你的能量，性是美好的，是连接彼此的好方式。"

translate chinese chinese_8216557_477:
    old "But you should be applying the meditation and yoga experience with the client. This is not what I'm selling..."
    new "但是你应该把冥想和瑜伽的经验用在客户身上。这可不是我推销的东西……"

translate chinese chinese_4297223_478:
    old "I'm so sorry..."
    new "真的很抱歉..."

translate chinese chinese_6321295_479:
    old "[pla], I think you have too many things to learn still, in this process... If someone is really learning to connect his body and soul, it means we are doing the process fine..."
    new "[pla]，我觉得你还有很多东西要学……如果有人真的在学习如何将身心连接起来，那就说明我们在过程中做得不错……"

translate chinese chinese_5990758_480:
    old "Anastasia is not doing it, she has been distracted, I mean my academy is not about other things different from the energy, meditation and yoga..."
    new "安娜斯塔西娅没有这么做，她分心了，我的意思是，我的学院不涉及其他事情，只专注于能量、冥想和瑜伽……"

translate chinese chinese_0182715_481:
    old "She is not getting that here. I'm not doing this for money or business, it's about fate and helping others to connect with the universe."
    new "她在这里得不到这个。我这不是为了钱或生意，这是关于命运，帮助别人与宇宙连接。"

translate chinese chinese_7549852_482:
    old "Can you understand what I am saying?"
    new "你能听懂我在说什么吗？"

translate chinese chinese_0211509_483:
    old "I apologize if I disappointed you, I know you probably don't want me to be here anymore, I understand, just let me tell you it wasn't on purpose."
    new "如果我让你失望了，我道歉。我知道你可能不想让我再在这里了，我理解，只是让我告诉你这并不是故意的。"

translate chinese chinese_9057424_484:
    old "What are you talking about? I do want you to be here."
    new "你在说什么？我确实希望你在这里。"

translate chinese chinese_1662857_485:
    old "(Wait, what? Is she upset or not)"
    new "（等下，什么情况？她生气了吗）"

translate chinese chinese_7801072_486:
    old "I just need you to help me by doing the things right, I thought that you were learning with the sessions you are doing with me, am I wasting my time?"
    new "我只需要你按照正确的方法帮我。我以为通过和我的训练，你已经在学习了，难道我在浪费时间吗？"

translate chinese chinese_9083179_487:
    old "... No, of course not, I'm sorry..."
    new "……不，当然不是，对不起……"

translate chinese chinese_4507436_488:
    old "I mean, you already know about this, you started a process, you should apply it to every activity you perform in your life... Even if it is sex... Yoga is deeply connected with sex."
    new "我的意思是，你已经知道这个了，你开始了一个过程，你应该把它应用到生活中每一件事上……即使那是性……瑜伽和性息息相关。"

translate chinese chinese_2987635_489:
    old "We definitely need to discuss this more... Wait a minute..."
    new "我们肯定需要再谈谈这个……等一下……"

translate chinese chinese_5411083_490:
    old "I think... That could work! if she is into you because of the sex, you guys can actually do a great job if you apply the yoga knowledge to the sex experience..."
    new "我觉得……那样行得通！如果她是因为性而对你感兴趣，你们可以把瑜伽知识应用到性爱体验中，实际上能做得很好……"

translate chinese chinese_2269280_491:
    old "Actually if she is interested in you because of the sex, the yoga can make that experience richer than you both can imagine, she won't ever let you go."
    new "实际上，如果她是因为性对你感兴趣，瑜伽可以让这种体验比你们想象的还要丰富，她永远不会让你离开的。"

translate chinese chinese_2079760_492:
    old "[pla], I need you to get ready, tomorrow you will have the most important lesson of your life, I'll wait for you, I will get ready too, to teach you very well."
    new "[pla]，你需要准备好，明天你将会有生命中最重要的一课，我会等你，我也会做好准备，好好教你。"

translate chinese chinese_9059551_493:
    old "Hmm... O- ok?"
    new "嗯……好？"

translate chinese chinese_4647767_494:
    old "(I don't get it, but I feel better to knowing she is not as mad as I thought she would be.)"
    new "(我不太明白，但知道她没有我想的那么生气，我感觉好多了。)"

translate chinese chinese_0006443_495:
    old "Hi, I am glad you came."
    new "嗨，很高兴你能来。"

translate chinese chinese_8865184_496:
    old "Hello, thanks for this new opportunity."
    new "你好，感谢这个新的机会。"

translate chinese chinese_5084611_497:
    old "I didn't mean to be mad at you yesterday, it's just that... This is very important for me,  this is my destiny..."
    new "我昨天不是故意生你的气，只是……这个对我来说非常重要，这是我的命运……"

translate chinese chinese_8925207_498:
    old "I... Understand..."
    new "我……明白……"

translate chinese chinese_6601200_499:
    old "That's not important... Not anymore, it was a new opportunity, the universe showed me there are different ways to reach the goal I am pursuing."
    new "那已经不重要了……现在是一个新的机会，宇宙告诉我，达到我追求的目标有其他方法。"

translate chinese chinese_8126664_500:
    old "Let's go to the room."
    new "我们去房间吧。"

translate chinese chinese_2073937_501:
    old "You see, Yoga is like a language, it helps you to understand the world and its people, we are all energy and love, that is why we need to balance our spirit so we can merge..."
    new "你看，瑜伽就像一种语言，它帮助你理解世界和人们，我们都是能量和爱，这就是为什么我们需要平衡我们的精神，以便我们可以融合..."

translate chinese chinese_4486592_502:
    old "That's why it is not weird that you can connect with another person so easily, that your bodies want to share their energies and eventually become one..."
    new "这就是为什么你能如此轻易地与另一个人产生联系，你们的身体渴望分享彼此的能量，最终合二为一……"

translate chinese chinese_7062764_503:
    old "I meant what I told you, you started the process, you should apply it on every activities you perform in your life... Even if it's sex...."
    new "我说的话是认真的，你开始了这个过程，就应该把它应用到生活中每一件事上……甚至包括性……"

translate chinese chinese_5291775_504:
    old "That's why I decided to prepare this lesson, it's really important because this way you will realize how everything is connected by energies."
    new "这就是为什么我决定准备这节课，因为这真的很重要，你会意识到一切是如何通过能量相互连接的。"

translate chinese chinese_9065544_505:
    old "You see, if you do some research you will find a very big part of yoga focuses on postures, you can find them according to your body type, the benefits it can give..."
    new "你看，如果你做些研究就会发现瑜伽很大一部分是关于体式的，你可以根据自己的体型找到适合的体式，以及它能带来的好处……"

translate chinese chinese_0816020_506:
    old "I have a complete library if you want, but if I asked you 'what is sex about' what would you say?"
    new "我有一整套藏书，但如果你问我“性是什么”，你会怎么说？"

translate chinese chinese_3131372_507:
    old "I think... Positions?"
    new "我猜……姿势？"

translate chinese chinese_7870419_508:
    old "That's what everyone gets wrong... sex is bigger than the position you choose, as is Yoga, bigger than a posture to meditate or meditation its itself."
    new "这就是大家搞错的地方……性不仅仅是你选择的姿势，瑜伽也不仅仅是冥想的姿势或冥想本身。"

translate chinese chinese_9793789_509:
    old "However both have that in common, the posture, so this is how you are going to apply all the yoga knowledge you have on this important activity..."
    new "不过两者都有这个共同点，姿势。所以你会把你所有的瑜伽知识应用到这项重要的活动上……"

translate chinese chinese_9669756_510:
    old "Let's start."
    new "开始吧。"

translate chinese chinese_0476114_511:
    old "Wait, what are you doing?"
    new "等一下，你在干什么？"

translate chinese chinese_4313769_512:
    old "What do you think I'm doing? We are here to learn about Yoga and sex, to see how they are meant to be... So you should get naked too..."
    new "你以为我在干什么？我们来这里是为了学习瑜伽和性爱，看看它们应该如何结合……所以你也该脱光……"

translate chinese chinese_8839797_513:
    old "... Alright."
    new "...好吧。"

translate chinese chinese_7326326_514:
    old "Now, let's start properly. I will lie down but I need you to get on your knees and hold my legs... Please relax yourself so you can feel it too."
    new "好了，现在正式开始。我会躺下，但你需要跪下来抱着我的腿……请放松自己，这样你也能感受到。"

translate chinese chinese_8738312_515:
    old "Excellent, this is very interesting position, Do you like it?"
    new "太好了，这个姿势很有趣，你喜欢吗？"

translate chinese chinese_8295701_516:
    old "... Yes."
    new "...是的。"

translate chinese chinese_8644303_517:
    old "This is a very intimate way to share your energy, as you could see, it was quite demanding but very rewarding."
    new "这是一种非常亲密的方式来分享你的能量，正如你所见，这虽然要求很高，但回报也非常丰厚。"

translate chinese chinese_5896162_518:
    old "So, let's start, move your hips and let me suck your penis."
    new "好吧，开始吧，摇晃你的臀部，让我来吸你的丁丁。"

translate chinese chinese_5679430_519:
    old "(Oh god, yes!)"
    new "（哦天哪，是的！）"

translate chinese chinese_0020967_520:
    old "I know, maybe this position is not going to be the very first option to propose, but you will estimate the proper moment to help a client..."
    new "我知道，也许这个职位不是第一个提议的选择，但你会找到合适的时机去帮助客户……"

translate chinese chinese_2334343_521:
    old "I hope you can start to tell apart sex and a real connection with a person thru Yoga?"
    new "我希望你能通过瑜伽开始区分性爱和与人的真实连接？"

translate chinese chinese_5265049_522:
    old "Do realize how much energy you let out by using the proper technique? I mean using these yoga positions in some sexual practices?"
    new "你知道使用正确技巧会释放多少能量吗？我是说在一些性实践中使用这些瑜伽姿势？"

translate chinese chinese_1704135_523:
    old "I'm glad you can realize how different it is."
    new "我很高兴你能意识到这一点的不同。"

translate chinese chinese_3654480_524:
    old "Now, let's try another option, this can be easier for any of your customers but a bit more demanding for you, however I know you can do it."
    new "好了，让我们试试另一个选项，这可能会对你的一些客户更容易一些，但对你来说要求会高一点，不过我知道你能行的。"

translate chinese chinese_0379749_525:
    old "This position implies a lot more effort on your end, even though your partner may be experienced, almost the other person's weight will rely on your body."
    new "这个姿势需要你付出更多的努力，即使你的伴侣很有经验，对方的大部分重量也会压在你身上。"

translate chinese chinese_7732501_526:
    old "There are different conditions that can make it easier or not, however I think, Anastasia, will need more of your assistance because of her height."
    new "有不同的条件可以使其更容易或更难，不过我认为，因为安纳斯塔西娅的身高，她可能需要更多的帮助。"

translate chinese chinese_9986374_527:
    old "This time, I will hold my right leg up, and support a bit on my arms, I will need you to help me keep my balance and also to guide the entire movement, follow your intuition."
    new "这次我把右腿抬起来，用手臂稍微支撑一下，你需要帮我保持平衡并引导整个动作，跟着你的直觉来。"

translate chinese chinese_1025369_528:
    old "Wow, that was quite good, I'm exhausting, how did you feel?"
    new "哇，那真是不错，我累坏了，你觉得呢？"

translate chinese chinese_4054338_529:
    old "It was... Quite interesting."
    new "那……相当有趣。"

translate chinese chinese_2269190_530:
    old "Right? I felt so much of me and you at the same time, it was like embracing life, I can see your progress, how calm you can perform and still communicate."
    new "对吧？我感觉我和你同时存在，就像拥抱生活一样，我能看到你的进步，你能在保持冷静的同时表现并交流。"

translate chinese chinese_4086696_531:
    old "The tantric massages gave you an impressive control over your chakras, you looked more than focused."
    new "那些 tantra 按摩让你对脉轮有了惊人的控制力，你看起来非常专注。"

translate chinese chinese_3804261_532:
    old "Remember this is a training, from now on, you must use these positions, actually, try it in the next session, do it at the end of the session you have been doing."
    new "记住这是训练，从现在开始，你必须使用这些姿势，实际上，在下一次训练中尝试一下，在你之前的训练结束时做一下。"

translate chinese chinese_6818369_533:
    old "Try to introduce it carefully so she can receive it positively, and the results can be more productive."
    new "试着小心引入，让她能积极接受，这样效果会更好。"

translate chinese chinese_0958701_534:
    old "(Is she really asking me to do that)"
    new "（她真的在让我做这个吗）"

translate chinese chinese_4889613_535:
    old "Yes, That way she will not only enjoy your lesson but also learn what she wanted to."
    new "是的，这样她不仅会享受你的课程，还能学到她想学的东西。"

translate chinese chinese_0036826_536:
    old "Please, be on time tomorrow!"
    new "拜托，明天准时一点！"

translate chinese chinese_5027933_537:
    old "Not a problem! See you then."
    new "没问题！到时候见。"

translate chinese chinese_1622637_538:
    old "So, how are you today?"
    new "所以，你今天怎么样？"

translate chinese chinese_8905291_539:
    old "I am very well, thanks for asking, it's nice to see you again."
    new "我很好，谢谢关心，很高兴再次见到你。"

translate chinese chinese_1736680_540:
    old "Thank you, I came today with my best mood..."
    new "谢谢，我今天可是带着最好的心情来的..."

translate chinese chinese_2944116_541:
    old "That's terrific, I am sure today's lesson will change your perception of the previous ones, we planned a very great session that you will find useful."
    new "太好了，我相信今天的课程会改变你对之前课程的看法，我们计划了一个非常有用的环节。"

translate chinese chinese_6992574_542:
    old "Ok, thank you... Every day I can learn something new... Hi [pla], nice to see you again."
    new "好的，谢谢……每天都能学到新东西……你好 [pla]，再次见到你真好。"

translate chinese chinese_8247791_543:
    old "Hello guys..."
    new "大家好……"

translate chinese chinese_9986169_544:
    old "Please, enjoy yourselves... The yoga room is already prepared for your session."
    new "请尽情享受……瑜伽室已经为你们准备好了。"

translate chinese chinese_5918944_545:
    old "Thank you Lisa, Anastasia please come in."
    new "谢谢丽莎，阿纳斯塔西娅请进。"

translate chinese chinese_0416414_546:
    old "Sure, I can't wait."
    new "行吧，我迫不及待了。"

translate chinese chinese_0015507_547:
    old "I need to confess that I did not study for today's lesson, so... Professor are you going to punish me?"
    new "我需要坦白，今天的内容我完全没有复习，所以……教授你会惩罚我吗？"

translate chinese chinese_9247905_548:
    old "... I- (I should be confident, that's what Lisa expect from me.)"
    new "……我—（我应该自信一点，这是莉萨对我的期望。）"

translate chinese chinese_2325489_549:
    old "What about if we just improvise?"
    new "要不我们即兴来吧？"

translate chinese chinese_0910415_550:
    old "Are you going to fuck me harder today?"
    new "今天你要更猛烈地干我吗？"

translate chinese chinese_4663243_551:
    old "Oh yeah baby, Fuck me like that again."
    new "哦 yeah 宝贝，再那样干我一次。"

translate chinese chinese_5489694_552:
    old "There is something new I want you to try."
    new "我有个新的东西想让你试试。"

translate chinese chinese_6479350_553:
    old "Wow, I can see you don't need to rest young man, I am anxious to try it even if I feel a bit tired."
    new "哇，看来你不需要休息啊，年轻人。我虽然有点累，但还是很想试试。"

translate chinese chinese_9814951_554:
    old "We still have a lot to learn."
    new "我们还有很多要学。"

translate chinese chinese_1674384_555:
    old "Sign me up."
    new "算我一个。"

translate chinese chinese_4483431_556:
    old "I will need you to relax your body so I can take your legs, I will hold them with my hands, but I will need you to hold me firmly with your hands."
    new "我需要你放松身体，让我来抬你的腿，我会用手托住它们，但你需要用双手紧紧抱住我。"

translate chinese chinese_5800805_557:
    old "I will do anything you ask of me."
    new "我会答应你任何要求。"

translate chinese chinese_4689281_558:
    old "Alright... Let's start."
    new "好吧……让我们开始吧。"

translate chinese chinese_0749301_559:
    old "Oh, wow you are getting creative!"
    new "哦，哇，你真是越来越有创意了！"

translate chinese chinese_9339857_560:
    old "Oh my god, that was unbelievable, I am so astonished! Is this the exercise Lisa mentioned you were preparing lately?"
    new "天啊，这太不可思议了，我简直惊呆了！这就是丽莎提到你最近准备的训练吗？"

translate chinese chinese_3309134_561:
    old "So does she know? Wow, You guys don't stop surprising me."
    new "那她知道吗？ wow，你们真是一直让我惊讶。"

translate chinese chinese_9113963_562:
    old "Let me ask you something, because this has blown my mind... Does Lisa offer these lessons with more than one instructor? I mean a team session with her would be pretty interesting..."
    new "我想问你个事，因为这事真的让我很惊讶……丽莎会提供不止一个导师的课程吗？我是说，和她一起的团队课程应该挺有意思的……"

translate chinese chinese_9728639_563:
    old "I- I'm not sure, I think I will need to ask her."
    new "我——我不太确定，我觉得我需要问她一下。"

translate chinese chinese_5284505_564:
    old "Alright, I have to go, let's get dressed."
    new "好了，我得走了，我们穿衣服吧。"

translate chinese chinese_3924958_565:
    old "So guys, how was the session today?"
    new "喂， guys，今天的表现怎么样？"

translate chinese chinese_5027406_566:
    old "Lisa, I think this has been the most incredible Yoga experience I have had in my entire life. I love your work, and of course your... Teamwork."
    new "丽莎，我觉得这是我这辈子最棒的瑜伽体验了。我喜欢你的教学，当然还有你的……团队合作。"

translate chinese chinese_7423844_567:
    old "Some friends are very interested in coming, I have persuaded them because of my experience, so hope you are ready for them."
    new "有些朋友对来这儿很感兴趣，我用我的经验说服了他们，所以希望你能做好准备迎接他们。"

translate chinese chinese_7661413_568:
    old "I appreciate you sharing your experience with your friends. I am sure you will learn more, do not doubt we will do our best to surprise you and your friends every time."
    new "感谢你和朋友们分享你的经历。我相信你会学到更多，不用怀疑，我们会尽力每次给你和你的朋友带来惊喜。"

translate chinese chinese_1429017_569:
    old "Love you guys, see you next time."
    new "爱你们，下次见。"

translate chinese chinese_5459717_570:
    old "Sure, I have already scheduled your next appointment so I will be calling you."
    new "好的，我已经帮你预约了下次的会面，到时候我会联系你。"

translate chinese chinese_7241379_571:
    old "Perfect, I will look forward to."
    new "完美，我期待着。"

translate chinese chinese_8777512_572:
    old "Nice to have you here, bye bye!"
    new "欢迎你的到来，拜拜！"

translate chinese chinese_2574896_573:
    old "See you next time."
    new "下次见。"

translate chinese chinese_8018562_574:
    old "Did you feel it?"
    new "你感觉到了吗？"

translate chinese chinese_5084356_575:
    old "Yes... I- I did."
    new "是的……我——我做了。"

translate chinese chinese_8923516_576:
    old "This is what we need to share with others, once you understand the language of the universe, you can translate to others, I am very proud that you are improving."
    new "这是我们需要与他人分享的东西，一旦你理解了宇宙的语言，就能向他人翻译出来，我很为你进步感到骄傲。"

translate chinese chinese_7657236_577:
    old "I know you are quite good however remember this is a process... we need to continue working... So... we need to continue working on your chakra."
    new "我知道你挺厉害的，不过记住这是一步步来的……我们需要继续努力……所以……我们需要继续练习你的查克拉。"

translate chinese chinese_6553810_578:
    old "I'll be waiting for you tomorrow night, those tantric sessions need to continue, as you saw today, you will become a very great Yoga instructor, so don't stop."
    new "我明天晚上等你，那些 tantra 课程需要继续，就像你今天看到的，你会成为一个非常棒的瑜伽导师，所以不要停下来。"

translate chinese chinese_4775871_579:
    old "Hello, I was waiting for you."
    new "你好，我在等你。"

translate chinese chinese_6068219_580:
    old "Hi Lisa..."
    new "嗨，丽莎..."

translate chinese chinese_5356326_581:
    old "I was very excited because with this session we concluded this chapter with your chakras, remember the process is to find the perfect balance is not something we can call finished."
    new "我非常兴奋，因为通过这次疗程，我们结束了你的脉轮这一章，记得找到完美的平衡不是一蹴而就的事情。"

translate chinese chinese_0224193_582:
    old "I understand, I will continue working on it."
    new "我明白，我会继续做的。"

translate chinese chinese_2013049_583:
    old "Actually, I wanted you to know that we can still work again on this, since this is a very good exercise for us both you can count on me to help you."
    new "其实，我想让你知道我们可以继续这个项目，因为这对我们都是一次很好的锻炼，你可以指望我帮你。"

translate chinese chinese_1274761_584:
    old "I really... Appreciate everything you do for me."
    new "我真的很...感激你为我做的一切。"

translate chinese chinese_1226391_585:
    old "It's my way to say thank you, I want to thank you for your hard work."
    new "这是我表达感谢的方式，我想感谢你的辛勤工作。"

translate chinese chinese_6290620_586:
    old "Let's go to the room to start the session..."
    new "我们去房间开始吧……"

translate chinese chinese_1235186_587:
    old "Regular sex is about exploring and feeling pleasure desperately... The tantric experience is different, it's about the energy and sensations you can have with your partner."
    new "普通的性爱是关于探索和尽情享受快感……而 tantra 体验不同，它关乎你和伴侣之间能产生的能量和感觉。"

translate chinese chinese_1158244_588:
    old "Sex consists of penetration and cumming, that takes out part of the connection, tantric sex otherwise means eye contacting, touching, breathing, to hear the noises."
    new "性爱包括插入和射精，这会减少一部分连接，而 tantra 性爱则意味着眼神交流、触摸、呼吸，听到彼此的声音。"

translate chinese chinese_0232807_589:
    old "That is why we start with the massage, so we can open our senses, open ourselves to the other."
    new "这就是为什么我们要从按摩开始，这样可以打开我们的感官，让我们彼此更加开放。"

translate chinese chinese_3395376_590:
    old "Please lie down to start the massage..."
    new "请躺下开始按摩..."

translate chinese chinese_7203503_591:
    old "We will need to work harder today so let me start with some lubrication, the universe it self is all about love, so nothing better than kisses to start, to help you expel the negative chakra."
    new "今天我们得更努力一点，让我先来润滑一下吧，宇宙本身都是关于爱的，所以没什么比吻更好的开始了，帮助你排出负面气场。"

translate chinese chinese_8283808_592:
    old "Just relax, remember to release the tension so you can do the exercise effectively."
    new "放松点，记得释放紧张情绪，这样才能有效做练习。"

translate chinese chinese_0423175_593:
    old "That was great... I felt really good... Are we done?"
    new "太棒了……感觉真好……完事了吗？"

translate chinese chinese_6353252_594:
    old "Of course not, since the main purpose is to finally connect deeply with yourself, there is a lot more to learn. I have a very special exercise for you to conclude this chakra training."
    new "当然不是，既然主要目的是最终与自己深处连接，还有很多东西要学习。我有一个非常特别的练习来结束这次脉轮训练。"

translate chinese chinese_7908211_595:
    old "I will need you to lie down again so I can do the movements needed."
    new "我需要你再躺下来，这样我才能做必要的动作。"

translate chinese chinese_0702843_596:
    old "Let me show you how it works..."
    new "让我来给你演示一下怎么用..."

translate chinese chinese_8854482_597:
    old "Feel all inside me."
    new "感受我所有的感觉。"

translate chinese chinese_5928368_598:
    old "I'm feeling all of you."
    new "我感受到了你们的所有情绪。"

translate chinese chinese_5379829_599:
    old "To be honest, I feel you're shining lately, these exercises have brought you wellness to your spirit and I can perceive it, I hope you can see the changes too."
    new "说实话，我感觉你最近状态很好，这些锻炼给你带来了精神上的愉悦，我能感受到，希望你自己也能看到这些变化。"

translate chinese chinese_6699218_600:
    old "For sure, I think I feel much better now."
    new "肯定的，我觉得现在好多了。"

translate chinese chinese_1726875_601:
    old "Remember that it is really important to continue this training, if you want to reach out to me any night, so we can work on your chakra training..."
    new "记得继续训练很重要，如果你想晚上找我训练查克拉的话……"

translate chinese chinese_2408411_602:
    old "You know it helps you to stay more balanced and focused in your chakras... I'll have nights free so we can repeat the tantric ritual anytime you need."
    new "你知道这有助于你的脉轮保持更平衡和专注……我会留出晚上，这样我们可以随时重复 tantra 仪式。"

translate chinese chinese_1367784_603:
    old "I think, now that you have balanced your energies, and your chakra muladhara has been controlled, you can even lead the tantric sessions with some of our customers."
    new "我觉得你现在平衡了能量，而且你的脉轮已经被控制住了，甚至可以带领一些客户的 tantra 课程了。"

translate chinese chinese_0417636_604:
    old "I'm sure the universe has great things for you, you already know you can count on me."
    new "我相信宇宙会给你带来美好的事物，你知道你可以依赖我。"

translate chinese chinese_4531795_605:
    old "I appreciate that."
    new "我明白你的意思。"

translate chinese chinese_4746809_606:
    old "Don’t forget you can keep up the yoga sessions with Anastasia in the afternoons, whenever you’ve got time!"
    new "别忘了你可以和安娜斯塔西娅在下午继续练瑜伽，有空的时候哦！"

translate chinese chinese_6965874_607:
    old "Your lessons have evolved now that you are better balanced and applying your yoga knowledge to the sex connection..."
    new "你的课程现在已经进化了，因为你现在更加平衡，并将瑜伽知识应用到了性爱之中……"

translate chinese chinese_6631691_608:
    old "If you feel you need to review the previous trainings we have done, any morning I'll be working on that so you prepare better always to help your customers."
    new "如果你觉得需要复习我们之前做的训练，任何早上我都会准备那些内容，让你能更好地帮助客户。"

translate chinese chinese_1257510_609:
    old "I am happy to hear that... We need to rest now, have a good night [pla]."
    new "听到这个我很高兴……我们现在需要休息了，晚安[pla]。"

translate chinese chinese_7981381_610:
    old "Ok, good night Lisa!"
    new "好，晚安丽莎！"

translate chinese chinese_4611488_611:
    old "Hey Lisa! It's so nice to see you, how are you?"
    new "嘿，丽莎！见到你真好，最近怎么样？"

translate chinese chinese_4766772_612:
    old "Hi dear! I'm very good, and you?"
    new "亲爱的，我很好，你呢？"

translate chinese chinese_0217574_613:
    old "I'm not so fine, we're having some financial issues..."
    new "我过得不太好吧，我们有些经济问题……"

translate chinese chinese_4410993_614:
    old "Really? I'm so sorry... How could I help you?"
    new "真的吗？真抱歉……我怎么帮你？"

translate chinese chinese_9820797_615:
    old "Actually, that's why I'm here. I thought maybe you needed someone to help you out with your business, I really need to find a job."
    new "实际上，我就是为此来的。我想也许你需要人手帮你打理生意，我真的需要找份工作。"

translate chinese chinese_4698785_616:
    old "I could work on anything... Doesn't matter what it's."
    new "我可以做任何事情……什么都可以。"

translate chinese chinese_7818249_617:
    old "Sadly, I can't hire you. I don't really need help right now."
    new "遗憾的是，我不能雇用你。我现在真的不需要帮助。"

translate chinese chinese_6008151_618:
    old "I haven't had much sales lately... I'm barely doing some Yoga classes for a few people."
    new "我最近生意不太好……基本上就是给几个人上瑜伽课。"

translate chinese chinese_2544669_619:
    old "However, I'm planning on improving my sales by implementing some new marketing strategies and I might need you sometime soon."
    new "不过，我打算通过实施一些新的营销策略来提高销售额，可能很快就需要你的帮助了。"

translate chinese chinese_2995199_620:
    old "But not really right now..."
    new "但是现在不太行..."

translate chinese chinese_0580515_621:
    old "Sorry about that..."
    new "对不起……"

translate chinese chinese_8502636_622:
    old "No, it's ok. Not your fault, I gotta keep looking... I guess."
    new "不，没关系。不是你的错，我得继续找……我想是的。"

translate chinese chinese_0192425_623:
    old "You'll find something good."
    new "你会找到好东西的。"

translate chinese chinese_7465497_624:
    old "Hmm, I hope. Thanks anyway, it's always nice to see you."
    new "嗯，希望如此。不管怎样，见到你总是很高兴。"

translate chinese chinese_6352184_625:
    old "I say the same... I'm glad you came to visit."
    new "我也一样……很高兴你能来拜访。"

translate chinese chinese_6668246_626:
    old "I should go, I really have to find a job, see you Lisa."
    new "我得走了，我真的得去找份工作，再见丽莎。"

translate chinese chinese_1741312_627:
    old "Hmm, this is weird, she should be here at this time of day."
    new "嗯，这挺奇怪的，她这个时候应该在这里的。"

translate chinese chinese_2313500_628:
    old "Lisa! Are you here?"
    new "丽莎！你在吗？"

translate chinese chinese_7219965_629:
    old "So odd, where is she?"
    new "真奇怪，她在哪里？"

translate chinese chinese_7442485_630:
    old "What is that noise? I guess she's in the yoga room."
    new "那是什么声音？估计她在瑜伽室里。"

translate chinese chinese_4702216_631:
    old "{i}(I- I wasn't expecting that.){/i}"
    new "{i}（我没想到会这样。）{/i}"

translate chinese chinese_9289785_632:
    old "{i}(That's- Umm... Quite an interesting position.){/i}"
    new "{i}（那个——嗯……真是个有趣的位置。）{/i}"

translate chinese chinese_4769411_633:
    old "Oh, [pla], I didn't realize you were around."
    new "哦，[pla]，我不知道你在这里。"

translate chinese chinese_6432532_634:
    old "I'm sorry for not noticing before."
    new "对不起，之前没注意到。"

translate chinese chinese_0867451_635:
    old "I- I'm sorry, Lisa! I- I didn't mean to spy on you."
    new "我、我对不起你，丽莎！我、我真的不是故意偷看的。"

translate chinese chinese_1271507_636:
    old "It's quite alright, I didn't realize I left the door open."
    new "没关系，我没意识到门是开着的。"

translate chinese chinese_9288643_637:
    old "Besides, all I was doing was resonating my Muladhara chakra with the energy of the universe."
    new "再说，我刚才只是在让我的根基脉轮与宇宙能量产生共鸣。"

translate chinese chinese_6485707_638:
    old "There's nothing to hide about that. So you don't need to worry about anything."
    new "那没什么好隐瞒的。所以你不用担心任何事情。"

translate chinese chinese_7583576_639:
    old "So, what brings you here?"
    new "那么，是什么让你来的呢？"

translate chinese chinese_4877703_640:
    old "Uhmm, w- well, I just wanted to see how you're doing."
    new "嗯，我就是想看看你怎么样了。"

translate chinese chinese_1988726_641:
    old "You know, to check how everything's going."
    new "你知道的，就是来看看一切都怎么样了。"

translate chinese chinese_5514703_642:
    old "Well, I've been a little stressed, you know, this whole business thing is a little tiring."
    new "嗯，我有点紧张，你知道的，这整件事有点累人。"

translate chinese chinese_6814756_643:
    old "But that's precisely why I was just realigning my energy with the universe."
    new "但恰恰就是因为这个，我才刚刚重新调整了我的能量与宇宙的和谐。"

translate chinese chinese_1973909_644:
    old "After stimulating my Muladhara chakra, I feel like I've been relieved of all stress now."
    new "刺激了根轮脉轮之后，我觉得所有的压力都消失了。"

translate chinese chinese_7487769_645:
    old "Is it that effective?"
    new "真的那么有效？"

translate chinese chinese_8211489_646:
    old "{i}(I mean, it just looked like she was just jacking off to me.){/i}"
    new "{i}（我的意思是，那看起来就像她在对我自渎。){/i}"

translate chinese chinese_5418622_647:
    old "Of course it is! The Muladhara chakra is the second of the body and the one that regulates our sacred sexual energy."
    new "当然了！Muladhara脉轮是身体的第二个脉轮，负责调节我们的神圣性能量。"

translate chinese chinese_3042661_648:
    old "It may have looked like I was just masturbating, but it's a lot more than that."
    new "虽然看起来我只是在自渎，但其实远不止这些。"

translate chinese chinese_6545173_649:
    old "The Muladhara regulates our self-esteem."
    new "Muladhara 脉轮调节我们的自尊心。"

translate chinese chinese_0271705_650:
    old "By properly stimulating it you can improve your mood because your energy's in line with the rest of the universe."
    new "通过适当刺激，你可以改善心情，因为你的能量会与整个宇宙同步。"

translate chinese chinese_7310872_651:
    old "Uh... I- I see."
    new "哦……我明白了。"

translate chinese chinese_7458228_652:
    old "So, this {i}'Proper stimulation'{/i}, is that why you were upside down?"
    new "所以，这个“适当的刺激”，就是你倒着的原因吗？"

translate chinese chinese_1285502_653:
    old "Yes, that's right."
    new "对，就是这样。"

translate chinese chinese_3870149_654:
    old "By taking that position, I was letting my energy flow outwards from my head."
    new "通过那个姿势，我让能量从我的头部向外流动。"

translate chinese chinese_9297632_655:
    old "And replenishing my Muladhara chakra with positive energy coming from the top."
    new "并通过来自顶部的正能量来补充我的根基脉轮。"

translate chinese chinese_1171867_656:
    old "It's tremendously effective [pla], I highly recommend it to you."
    new "这效果超赞的[pla]，我强烈推荐给你。"

translate chinese chinese_2538131_657:
    old "Y- you do?"
    new "你真的？"

translate chinese chinese_5197603_658:
    old "Oh yeah, it's somewhat difficult to do."
    new "哦 yeah，有点难做。"

translate chinese chinese_4966407_659:
    old "But I'm sure I can guide you towards a path of proper alignment with the universe."
    new "但我肯定我能引导你走向与宇宙和谐一致的道路。"

translate chinese chinese_4905746_660:
    old "Uh, I- I guess I'll think about it."
    new "呃，我—我猜我会考虑一下。"

translate chinese chinese_4765759_661:
    old "Oh, by the way, I was hoping you'd come, seems like the energies drew you here. It's so beautiful when the universe conspires in your favor."
    new "哦，对了，我本来希望你会来的，看来是命运把你带到这里。当宇宙为你而合谋时，真是太美妙了。"

translate chinese chinese_2330760_662:
    old "Oh, do you need me for something?"
    new "哦，你需要我做什么吗？"

translate chinese chinese_5995131_663:
    old "Yeah, but let me get dressed and comfy. Meet me downstairs and we'll chat for a bit."
    new "好的，但让我先穿好衣服，舒服一点。下来找我，我们聊一会儿。"

translate chinese chinese_0223690_664:
    old "Uh, yeah, sure. I'll be waiting downstairs."
    new "嗯，好的。我在楼下等你。"

translate chinese chinese_5202440_665:
    old "I'm ready, thanks for waiting. I'm really glad you came today."
    new "我准备好了，谢谢你的等待。真的很高兴你今天来了。"

translate chinese chinese_2546374_666:
    old "Uh, sure. So, what did you want to talk about?"
    new "嗯，好啊。那你想聊些什么？"

translate chinese chinese_5385873_667:
    old "Well, you see, I need to ask a favor of you."
    new "嗯，是这样的，我需要请你帮忙。"

translate chinese chinese_9368068_668:
    old "Really? What is it?"
    new "真的吗？是什么？"

translate chinese chinese_1763726_669:
    old "It's about this client that I have, I've been working with her for a while."
    new "是关于我的一个客户，我跟她合作了一段时间。"

translate chinese chinese_1283572_670:
    old "I would like you to be her instructor during her next class, instead of me."
    new "我希望你能代替我在下一节课当她的指导老师。"

translate chinese chinese_9427710_671:
    old "Oh! Are you busy again? Sure, I'll cover you."
    new "哦！你又忙吗？好的，我会帮你应付的。"

translate chinese chinese_5125009_672:
    old "No, it's nothing like that. I don't have anything else to do during that session."
    new "不，不是那样的。那个时间段我没什么别的事情要做。"

translate chinese chinese_2540901_673:
    old "So what is it?"
    new "那是什么？"

translate chinese chinese_2479354_674:
    old "Well, she's come to every appointment without fail, she also does every yoga pose correctly."
    new "好吧，她每次预约都准时来，瑜伽动作也做得非常标准。"

translate chinese chinese_7150727_675:
    old "But in spite of that, I would say she's not actually doing well."
    new "但是尽管如此，我觉得她实际上并不好。"

translate chinese chinese_1507906_676:
    old "She isn't?"
    new "她不是吗？"

translate chinese chinese_5798076_677:
    old "Yeah, I'm not feeling her energy flowing the way it should."
    new "是啊，我觉得她的气场不太对劲。"

translate chinese chinese_8830378_678:
    old "It's hard to explain, but even though she's been progressing in terms of flexibility and poses."
    new "这很难解释，但尽管她在柔韧性和姿势方面有所进步。"

translate chinese chinese_6802606_679:
    old "I still feel like she needs something else in order to thrive."
    new "我还是觉得她还需要一些其他的东西才能真正好起来。"

translate chinese chinese_3580954_680:
    old "And you think that {i}'something else'{/i} has to do with me?"
    new "而且你认为{i}“其他什么事”{/i}和我有关？"

translate chinese chinese_0202080_681:
    old "Yes, that's correct."
    new "是的，没错。"

translate chinese chinese_3066200_682:
    old "I think that maybe your masculine energy will be able to unearth whatever's stopping her from progressing."
    new "我觉得也许你的男子气概能揭开阻碍她前进的原因。"

translate chinese chinese_4326769_683:
    old "After all, you already helped Anastasia in a very effective way."
    new "毕竟，你已经以非常有效的方式帮助了阿纳斯塔西娅。"

translate chinese chinese_5701639_684:
    old "So I thought that it would be worth it to give it a go with this girl as well."
    new "所以我想试试和这个女孩也在一起看看值不值得。"

translate chinese chinese_7447285_685:
    old "Uh, well, if you say so, sure."
    new "嗯，好吧，如果你这么说的话，行吧。"

translate chinese chinese_4180000_686:
    old "I'll be happy to help you."
    new "我很乐意帮你。"

translate chinese chinese_8227539_687:
    old "That's great! I'll let her know about it and I'll see you in the afternoon then."
    new "太好了！我会告诉她这件事，然后下午见。"

translate chinese chinese_3851956_688:
    old "Sure, no problem, I'll see you later."
    new "好的，没问题，待会儿见。"

translate chinese chinese_4657411_689:
    old "Hi Lisa, I came for the class you told me about-"
    new "嗨，丽莎，我来上你告诉我的那个班的课了——"

translate chinese chinese_5846325_690:
    old "{i}(Is that Angelina? What's she doing here?){/i}"
    new "{i}（那是安吉丽娜吗？她来这里干什么？){/i}"

translate chinese chinese_1826208_691:
    old "{i}(Oh my God! That's [pla]! W- what is he doing here?!){/i}"
    new "{i}(天啊！那是[pla]！他来这里干什么？!){/i}"

translate chinese chinese_2404477_692:
    old "Hello [pla], you arrived just in time, this is Angelina, the client that you'll be helping today."
    new "你好[pla]，你来的正是时候，这是Angelina，今天你要帮忙的客户。"

translate chinese chinese_7328331_693:
    old "Uh, yeah... Hi A- Angelina, nice to meet you."
    new "呃，嗯……嗨，A-安吉丽娜，很高兴见到你。"

translate chinese chinese_7092865_694:
    old "Uh, yeah, hi to you too... Nice meeting you."
    new "呃，是啊，也见到你了……很高兴见到你。"

translate chinese chinese_8442067_695:
    old "So, as I told you a moment ago, [pla] will be taking over your class today."
    new "所以，就像我刚才告诉你的，[pla]今天会代你们的课。"

translate chinese chinese_6758931_696:
    old "Uhh, Angelina?"
    new "呃，安吉丽娜？"

translate chinese chinese_9688521_697:
    old "Y- yes, of course. Please, continue."
    new "是的，当然。请继续。"

translate chinese chinese_1148894_698:
    old "Okay, as I was saying earlier, he has been helping me recently by giving classes to some of my clients."
    new "好的，就像我刚才说的，他最近一直在帮我，给我的一些客户上课。"

translate chinese chinese_6433572_699:
    old "You don't have to worry about anything, he's very knowledgeable and he has a spectacular energy."
    new "你不用担心，他知识渊博，而且精力充沛。"

translate chinese chinese_0729001_700:
    old "So, I'm sure he'll be capable of helping you in the way you need."
    new "所以，我相信他一定能以你需要的方式帮助你。"

translate chinese chinese_8188527_701:
    old "I- I see, well... I'll be in his care then."
    new "我……明白了，那我就交给他了。"

translate chinese chinese_8370663_702:
    old "Let's go to the yoga studio so you two can start your class."
    new "我们去瑜伽馆吧，你们可以开始上课了。"

translate chinese chinese_3256723_703:
    old "I'll leave you two alone so you can start with the session, I hope you enjoy it, Angelina."
    new "我先让你们俩单独待着开始吧，希望你们玩得开心，安吉丽娜。"

translate chinese chinese_4601999_704:
    old "W- well, thank you."
    new "嗯，谢谢。"

translate chinese chinese_9912648_705:
    old "We'll see you later."
    new "待会儿见。"

translate chinese chinese_5871802_706:
    old "Uhh, alright, so..."
    new "呃，好吧，那么……"

translate chinese chinese_9799037_707:
    old "I- I guess we better get started with the class."
    new "我— 我猜我们还是开始上课吧。"

translate chinese chinese_5874115_708:
    old "Wait a minute."
    new "等一下。"

translate chinese chinese_8354843_709:
    old "Can you please tell me what you're doing here? I thought you were supposed to be Dr. Johnson's assistant."
    new "你能告诉我你在这里干什么吗？我以为你是约翰逊博士的助手。"

translate chinese chinese_2727122_710:
    old "How come I'm running into you here? And you're teaching yoga?"
    new "我怎么会在这里遇到你？而且你还在教瑜伽？"

translate chinese chinese_7662440_711:
    old "What's next? Will you be my waiter if I go to a restaurant?"
    new "接下来呢？如果我去餐馆你会当我的服务员吗？"

translate chinese chinese_8541962_712:
    old "Hmm, I can see why this would surprise you, but believe me, it was a surprise for me too."
    new "嗯，我能理解这会让你惊讶，但相信我，我也很惊讶。"

translate chinese chinese_5972911_713:
    old "But it's nothing like what you're imagining."
    new "但根本不像你想的那样。"

translate chinese chinese_0215038_714:
    old "I'm related to Lisa, she's my [mom2Rel]'s younger sister."
    new "我和丽莎有关系，她是我的[mom2Rel]的妹妹。"

translate chinese chinese_7424202_715:
    old "And since she started the studio I've been giving her a hand with some particular clients."
    new "自从她开了工作室，我就帮她处理一些特别的客户。"

translate chinese chinese_3074884_716:
    old "But I swear that I didn't know that you were the client I was supposed to help with the class today."
    new "但我发誓我真的不知道你就是我今天应该帮忙的那个客户。"

translate chinese chinese_8564769_717:
    old "She just came to my house asking me for a hand with a client, and that's it."
    new "她就是来我家找我帮忙处理一个客户的事，就这么简单。"

translate chinese chinese_5191572_718:
    old "I don't know."
    new "我不知道。"

translate chinese chinese_3181380_719:
    old "It's just so weird that I keep running into you."
    new "真奇怪，我老是遇到你。"

translate chinese chinese_8296152_720:
    old "I know, trust me, it's very weird for me too."
    new "我知道，相信我，对我来说也很奇怪。"

translate chinese chinese_6984791_721:
    old "But if you let me, I'll be more than happy to help you with the class."
    new "但如果你让我帮忙，我很乐意帮你搞定这门课。"

translate chinese chinese_0677314_722:
    old "I guess that if Lisa says it's alright, I have no reason to not believe what you're saying."
    new "我想如果丽莎说没问题，我就没有理由不相信你说的话。"

translate chinese chinese_3804271_723:
    old "So I guess I'll do it."
    new "那我猜我就做了吧。"

translate chinese chinese_0523215_724:
    old "Great! And hey, how's Roonie doing?"
    new "太好了！对了，鲁尼怎么样？"

translate chinese chinese_3237581_725:
    old "I bet he must be happy about the baby."
    new "我敢说他肯定为这个孩子高兴。"

translate chinese chinese_1632876_726:
    old "Uhm, yeah... He's doing alright."
    new "嗯，还好吧……他挺好的。"

translate chinese chinese_7023078_727:
    old "I see, good, good. A- and how's the pregnancy been treating you?"
    new "我明白了，很好，很好。那怀孕情况怎么样？"

translate chinese chinese_2102136_728:
    old "I've been alright... I think"
    new "我过得还行……我想。"

translate chinese chinese_4794131_729:
    old "The doctor told me that I should try to stay active during my pregnancy."
    new "医生告诉我怀孕期间应该尽量保持活跃。"

translate chinese chinese_6317072_730:
    old "That's why I'm taking yoga lessons, I was told it's one of the best things that you could do as a pregnant woman."
    new "这就是为什么我要去上瑜伽课，听说怀孕期间做瑜伽是最好的事情之一。"

translate chinese chinese_0635022_731:
    old "Oh yeah?"
    new "哦是吗？"

translate chinese chinese_4935961_732:
    old "Yes, it's supposed to improve sleep by reducing stress, and also helping relieve anxiety."
    new "是的，它应该能通过减轻压力来改善睡眠，还能帮助缓解焦虑。"

translate chinese chinese_7440696_733:
    old "And apparently it helps to strengthen the muscles needed for childbirth."
    new "而且这显然有助于增强分娩所需的肌肉。"

translate chinese chinese_4225137_734:
    old "And the flexibility of course."
    new "当然还有灵活性。"

translate chinese chinese_8163653_735:
    old "So that's why I'm doing yoga."
    new "所以我就在做瑜伽。"

translate chinese chinese_3788072_736:
    old "I see, that all makes a lot of sense."
    new "我明白了，这说得通。"

translate chinese chinese_8974966_737:
    old "Uhmm, w- well, what do you say we get started with the session."
    new "嗯，那个，我们开始吧。"

translate chinese chinese_3661045_738:
    old "Alright, let's start with the first asana."
    new "好吧，我们从第一个体式开始。"

translate chinese chinese_3341775_739:
    old "This first one's called Setu Bandha."
    new "这个第一个叫做Setu Bandha。"

translate chinese chinese_9834199_740:
    old "Ok? Is it too hard?"
    new "好吧？是不是太难了？"

translate chinese chinese_7299344_741:
    old "I mean, I ask because I'm pregnant."
    new "我是说，我问是因为我怀孕了。"

translate chinese chinese_2016743_742:
    old "Nah, it's not too hard."
    new "哎，没那么难。"

translate chinese chinese_3483431_743:
    old "Sure it can be a little challenging."
    new "确实可能会有点挑战。"

translate chinese chinese_4288748_744:
    old "But don't worry, I'll be there helping you during it."
    new "但别担心，我会在那里帮你一起应对的。"

translate chinese chinese_0207472_745:
    old "Ok, how do I do it?"
    new "好的，我该怎么操作？"

translate chinese chinese_0728933_746:
    old "It's simple, just lay on your back with your knees up and your heels towards your butt."
    new "很简单，仰面躺下，膝盖弯曲，脚跟朝向屁股。"

translate chinese chinese_7244241_747:
    old "And then just push through the soles of your feet and lift your hips up, like making an arch."
    new "然后用力从脚底往上推，抬起臀部，就像做一个拱形一样。"

translate chinese chinese_2948035_748:
    old "Hmm, ok, I guess I get it."
    new "嗯，好吧，我大概明白了。"

translate chinese chinese_8526071_749:
    old "Yeah, you're doing it well, but you're a little tense through the shoulders."
    new "嗯，你做得不错，但肩膀有点紧张。"

translate chinese chinese_0033026_750:
    old "Try to relax a little bit more."
    new "试着再放松一点。"

translate chinese chinese_7443454_751:
    old "O- Ok."
    new "好。"

translate chinese chinese_4508299_752:
    old "{i}(Hmm, I see what Lisa was telling me, she's doing the position right.){/i}"
    new "{i}（嗯，我明白丽莎跟我说的了，她的姿势是对的。）{/i}"

translate chinese chinese_4670432_753:
    old "{i}(But I can see that she's very tense.){/i}"
    new "({i}不过我能看出她很紧张。{/i})"

translate chinese chinese_7715649_754:
    old "{i}(Maybe we can change to another position and see how she does.){/i}"
    new "{i}(也许我们可以换一个姿势看看她的反应。){/i}"

translate chinese chinese_8565527_755:
    old "Ok, that's very good, now let's move into the next one."
    new "好的，非常好，现在让我们进行下一个。"

translate chinese chinese_9351930_756:
    old "O-ok."
    new "好、好。"

translate chinese chinese_1793904_757:
    old "Alright, that was a good start."
    new "好吧，这算是个不错的开始。"

translate chinese chinese_2463411_758:
    old "So I guess we can move into the next position."
    new "那我们就进入下一个姿势吧。"

translate chinese chinese_4449830_759:
    old "This one's called Balasana."
    new "这个叫做吉祥式。"

translate chinese chinese_0890699_760:
    old "It's even easier than the previous one, but it's very good to stretch the shoulders and back."
    new "这比之前的还要简单，但对拉伸肩膀和背部非常好。"

translate chinese chinese_9130738_761:
    old "I see, how do I do it?"
    new "我明白了，怎么操作？"

translate chinese chinese_6784057_762:
    old "It's simple, you're going to start in a tabletop pose."
    new "很简单，你先从桌面上的姿势开始。"

translate chinese chinese_5443123_763:
    old "From there, just move your hips back and down while you leave your hands where they are."
    new "从那里开始，只需将臀部向后下方移动，同时保持双手不动。"

translate chinese chinese_7033841_764:
    old "That will give you a proper stretch through your shoulders and back."
    new "这样可以好好拉伸你的肩膀和背部。"

translate chinese chinese_9467001_765:
    old "Hmm, ok, I think I can do that."
    new "嗯，好的，我想我可以做到。"

translate chinese chinese_7518242_766:
    old "Yeah, and I'll be there to help you, so don't worry."
    new "嗯，我会在那里帮你，所以不用担心。"

translate chinese chinese_4287461_767:
    old "Ok, let's try it."
    new "好吧，咱们试试吧。"

translate chinese chinese_5245787_768:
    old "Am I doing this right?"
    new "我这样做对吗？"

translate chinese chinese_6976154_769:
    old "Yeah, that's alright, but try to let go a little bit more."
    new "嗯，这样挺好的，但试着再放松一点。"

translate chinese chinese_6912590_770:
    old "A-alright."
    new "好，好吧。"

translate chinese chinese_8251328_771:
    old "{i}(Hmm, he's closer than before.){/i}"
    new "{i}（嗯，他比之前更近了。）{/i}"

translate chinese chinese_7628320_772:
    old "{i}(What's this I'm starting to feel?){/i}"
    new "{i}(我开始感觉到的是什么？){/i}"

translate chinese chinese_2832416_773:
    old "{i}(What the hell? She's even more tense than before!){/i}"
    new "{i}(怎么回事？她比之前更紧张了！){/i}"

translate chinese chinese_9127145_774:
    old "{i}(Why is she so stiff?){/i}"
    new "{i}（为什么她这么僵硬？）{/i}"

translate chinese chinese_6558521_775:
    old "{i}(I think we'll have to move on to the next position.){/i}"
    new "{i}（我想我们得移到下一个位置了。）{/i}"

translate chinese chinese_7683923_776:
    old "{i}(Maybe something a bit more relaxed.){/i}"
    new "{i}(也许稍微放松一点。){/i}"

translate chinese chinese_6057112_777:
    old "Ok, I think that's enough of this position, we can move on to the next one."
    new "好了，我觉得这个姿势差不多了，我们可以换下一个了。"

translate chinese chinese_0659504_778:
    old "Ok, you're doing well so far."
    new "好，你到目前为止做得不错。"

translate chinese chinese_1043216_779:
    old "But I think you're still a little tense. So I want us to change into a more relaxed position."
    new "但我觉得你还是有点紧张。所以我想换个更放松的姿势。"

translate chinese chinese_6906815_780:
    old "The idea for this next position is for you to relax and let go."
    new "这个下一个姿势的想法是让你放松并放开。"

translate chinese chinese_6469407_781:
    old "L-let myself go?"
    new "让、让自己放纵一下？"

translate chinese chinese_6331610_782:
    old "That's right, I want you to relax and just let your energy flow through the position."
    new "没错，我想让你放松，让能量自然流动。"

translate chinese chinese_0372838_783:
    old "I can see that you have an energy block."
    new "我看得出来你有能量块。"

translate chinese chinese_5568258_784:
    old "If you keep going that way you won't be able to feel the energy flow through you."
    new "如果你继续那样做，就感受不到能量流过身体了。"

translate chinese chinese_1894091_785:
    old "I-I see, I think I get it."
    new "我，我明白了，我想我懂了。"

translate chinese chinese_2513260_786:
    old "Ok, so be sure to just relax."
    new "好吧，所以一定要放松。"

translate chinese chinese_9971099_787:
    old "This next one's called Upavistha Konasana."
    new "下一个叫做宽角坐姿。"

translate chinese chinese_7720178_788:
    old "Except that it's a modified version."
    new "不过这是个修改版。"

translate chinese chinese_1794485_789:
    old "Modified? Will it be too hard?"
    new "改过吗？会不会太硬了？"

translate chinese chinese_2608794_790:
    old "Not at all, don't worry."
    new "根本不用担心。"

translate chinese chinese_8868134_791:
    old "It involves a forward fold while you push your legs outwards and reach for your ankles."
    new "这个动作需要向前折叠，同时向外推腿并尝试触碰脚踝。"

translate chinese chinese_6686709_792:
    old "But I will be helping you, so you won't have to make much effort."
    new "但我會幫你的，所以你不用太費力。"

translate chinese chinese_8187595_793:
    old "I'll help you by opening your legs with mine, and I'll pull you forward, so you just focus on the stretch through your groin and lower back."
    new "我用腿帮你分开腿，然后拉你往前，你就专注于从胯部到下背部的拉伸就行了。"

translate chinese chinese_3823849_794:
    old "Hmm, it sounds hard, but I'll trust you."
    new "嗯，听起来很难，但我相信你。"

translate chinese chinese_6192628_795:
    old "Alright, you're doing ok."
    new "好吧，你做得不错。"

translate chinese chinese_7856985_796:
    old "But try to let yourself go a little bit more. Ok?"
    new "但试着再放纵一点自己好吗？"

translate chinese chinese_2223846_797:
    old "{i}(W- what is this I'm feeling again?){/i}"
    new "{i}（这又是怎么回事？）{/i}"

translate chinese chinese_1409994_798:
    old "{i}(T-this... Is like what I felt that time.){/i}"
    new "{i}(这……就像那次我感受到的一样。){/i}"

translate chinese chinese_1102464_799:
    old "{i}(W-what?! S-she's even more tense than before!){/i}"
    new "({i}什么?! 她比之前还要紧张！{/i})"

translate chinese chinese_2429859_800:
    old "{i}(Hmph, I guess this isn't working.){/i}"
    new "{i}（哼，看来这不管用。){/i}"

translate chinese chinese_6958247_801:
    old "Alright, I think that's enough for this position."
    new "好吧，我觉得这个姿势差不多够了。"

translate chinese chinese_7201679_802:
    old "Ok, I think that's enough for today."
    new "好吧，今天就到这儿吧。"

translate chinese chinese_3998054_803:
    old "How did you feel?"
    new "你感觉怎么样？"

translate chinese chinese_8570234_804:
    old "I- Uhmm... I think I felt alright."
    new "我—嗯……我觉得还好。"

translate chinese chinese_8543582_805:
    old "I feel my body a lot more loose now."
    new "我现在觉得身体放松多了。"

translate chinese chinese_1741605_806:
    old "Hmph, well, as long as you don't feel bad, I guess that's ok."
    new "哼，好吧，只要你自己不觉得难受，那就算了。"

translate chinese chinese_7451568_807:
    old "Why don't we go down and let Lisa know that we're done?"
    new "要不我们下去告诉丽莎我们已经好了？"

translate chinese chinese_1365139_808:
    old "Hello guys, are you done with the class?"
    new "大家好，课上完了吗？"

translate chinese chinese_5098969_809:
    old "Alright, and how did it go? How are you feeling right now Angelina?"
    new "好了，结果怎么样？你现在感觉如何，安吉丽娜？"

translate chinese chinese_8709819_810:
    old "It was good... Yeah, it was a good class."
    new "挺好的……是的，这节课挺不错。"

translate chinese chinese_1334399_811:
    old "[pla] helped me through every position, and they weren't too difficult."
    new "[pla] 在每个姿势上都帮了我，而且它们并不是太难。"

translate chinese chinese_6025181_812:
    old "I'm happy to hear that. [pla] knows very well what he's doing, so I was sure that it would be a good class."
    new "听到这个我很高兴。[pla]很清楚自己在做什么，所以我确信这会是一堂好课。"

translate chinese chinese_2558023_813:
    old "It was."
    new "是的。"

translate chinese chinese_7604207_814:
    old "I’m afraid it’s getting quite late, I must be going now."
    new "恐怕已经很晚了，我得走了。"

translate chinese chinese_1888027_815:
    old "Thanks a lot for the class [pla]."
    new "非常感谢[pla]这节课。"

translate chinese chinese_2572566_816:
    old "You are welcome."
    new "不客气。"

translate chinese chinese_6546032_817:
    old "Goodbye, Lisa. I’ll see you at the next class."
    new "再见，丽莎。下次课见。"

translate chinese chinese_9486610_818:
    old "See you next class, sweetheart. Take care."
    new "下次课见，甜心。照顾好自己。"

translate chinese chinese_8192076_819:
    old "So? What did you think? How did it go?"
    new "怎么样？你觉得呢？进展如何？"

translate chinese chinese_7880419_820:
    old "Hmm, in general, I would say it was alright."
    new "嗯，总的来说，还可以吧。"

translate chinese chinese_1582777_821:
    old "But I can see what you mean about her having some sort of energetic block."
    new "但是我能理解你说的她有些能量堵塞的问题。"

translate chinese chinese_0775970_822:
    old "I felt that she was very tense in all the positions we did."
    new "我觉得我们在所有姿势下她都很紧张。"

translate chinese chinese_5936791_823:
    old "I see, so her energy's still blocked inside her."
    new "我明白了，所以她的能量还是被困在里面。"

translate chinese chinese_6186894_824:
    old "Well, maybe that has to do with the fact that she's pregnant?"
    new "嗯，也许这和她怀孕有关？"

translate chinese chinese_2398731_825:
    old "By the way, I would've liked to have known that before."
    new "对了，我之前要是知道就好了。"

translate chinese chinese_5676717_826:
    old "Oh, I failed to mention that, I'm sorry."
    new "哦，我忘了提了，对不起。"

translate chinese chinese_9094791_827:
    old "But I don't think it makes such a difference."
    new "但是我觉得这没什么太大区别。"

translate chinese chinese_1490107_828:
    old "What I've been feeling she lacks is that masculine energy I told you about."
    new "我觉得她缺少的就是我之前提到的那种阳刚之气。"

translate chinese chinese_7170177_829:
    old "So I think that it was still beneficial for her to have that session with you."
    new "所以我觉得她和你那次交流还是有好处的。"

translate chinese chinese_5083327_830:
    old "I see, well, I sure hope that it actually helped her because she was just so tense during the session."
    new "我明白了，希望真的帮到她，因为她刚才那会儿紧张得要命。"

translate chinese chinese_7527873_831:
    old "Her next session's with me, so I'll see how her energy's changed. I'll let you know how she's doing."
    new "她的下次预约是我的，我会看看她的状态有没有变化。有什么情况我会告诉你。"

translate chinese chinese_6310993_832:
    old "Before you head out, there's something I'd like to discuss with you."
    new "出门前，有件事我想和你谈谈。"

translate chinese chinese_2853100_833:
    old "Uh, sure. What's on your mind?"
    new "嗯，好啊。你在想什么？"

translate chinese chinese_2782990_834:
    old "Well, recently, I've been doing very well."
    new "嗯，最近我过得很好。"

translate chinese chinese_5574651_835:
    old "I've gotten a good number of new clients, and they seem to be very happy with my classes."
    new "我新招了不少客户，他们似乎对我的课程很满意。"

translate chinese chinese_8130497_836:
    old "I'm very happy with how things have been going lately."
    new "我最近觉得很开心。"

translate chinese chinese_6516221_837:
    old "That sounds great! Congrats, Lisa!"
    new "听起来真不错！恭喜你，丽莎！"

translate chinese chinese_1169504_838:
    old "Thanks, [pla]."
    new "谢谢，[pla]。"

translate chinese chinese_9390208_839:
    old "But you see, some of my students are actually becoming very advanced in yoga."
    new "但是你看，有些学生实际上在瑜伽方面进步很大。"

translate chinese chinese_8312420_840:
    old "So, I'm pondering what else I can offer my clients in the way of spiritual guidance and development."
    new "所以，我在考虑还能为客户提供哪些精神指导和发展方面的服务。"

translate chinese chinese_7052980_841:
    old "Especially because my work goes beyond just yoga and meditation, you have seen it."
    new "特别是我的工作不仅仅限于瑜伽和冥想，你都看过了。"

translate chinese chinese_1535920_842:
    old "Rather than just a yoga guru, I want to be known as a complete spiritual wellness guide."
    new "我不仅仅想成为一个瑜伽导师，还想成为一个全方位的精神健康指导。"

translate chinese chinese_0011639_843:
    old "So that my students can progress in whatever way they feel benefits them the most."
    new "这样我的学生就能以他们认为最有益的方式来进步。"

translate chinese chinese_2004354_844:
    old "Ok, that sounds like a very good idea."
    new "好的，这听起来是个非常好的主意。"

translate chinese chinese_1216735_845:
    old "Thanks, [pla]. So I came up with the idea of adding classes in mindfulness, transcendental meditation."
    new "谢谢，[pla]。所以我想到可以增加一些正念和超脱冥想的课程。"

translate chinese chinese_0484152_846:
    old "As well as Tai Chi, Reiki, and Tantric sex."
    new "包括太极、灵气疗法和 tantra 性爱。"

translate chinese chinese_2944393_847:
    old "And different healing treatments, like Chakra Healing, Acupuncture, Sound Healing, and herbal medicines."
    new "还有不同的治疗方法，比如查克拉治愈、针灸、声音治疗和草药药物。"

translate chinese chinese_0776019_848:
    old "I- I see, that's a lot."
    new "我明白了，这挺多的。"

translate chinese chinese_7457948_849:
    old "So you want to expand your portfolio, right?"
    new "所以你是想扩展你的投资组合，对吧？"

translate chinese chinese_2479967_850:
    old "Hmm... Yeah, to put it in simpler terms."
    new "嗯……对，用更简单的话说。"

translate chinese chinese_2812689_851:
    old "Of course, I intend to implement this gradually. I’d like to conduct a few tests before applying it to additional clients."
    new "当然，我打算逐步实施。在应用到其他客户之前，我想先进行一些测试。"

translate chinese chinese_2285655_852:
    old "That makes sense, so, Do you already have a plan for how to begin?"
    new "说得通，那你觉得你已经有开始的计划了吗？"

translate chinese chinese_2196264_853:
    old "Well, I have this client that's been working with me for a while."
    new "嗯，我有个客户已经合作一段时间了。"

translate chinese chinese_7387961_854:
    old "And she has in fact asked me several times about the possibility of having tantric sex sessions."
    new "而且她事实上好几次问我能不能进行 tantra 性爱 session。"

translate chinese chinese_3884358_855:
    old "I see, well, that makes a lot of sense, and if she wants to do it, I think it's a great idea."
    new "我明白了，嗯，这说得通，如果她想做的话，我觉得这是个好主意。"

translate chinese chinese_6248409_856:
    old "Yes, and you see, this client's Anastasia."
    new "是的，而且你看，这个客户是阿纳斯塔西娅。"

translate chinese chinese_1254903_857:
    old "Oh, I see, I think she did mention that."
    new "哦，我明白了，我想她确实提过。"

translate chinese chinese_6998743_858:
    old "Yeah, and given that she's relatively advanced in her yoga journey, I think this would be a good moment to introduce her to more advanced concepts."
    new "没错，鉴于她在瑜伽之旅中已经相对进步了，我觉得现在是时候向她介绍一些更高级的概念了。"

translate chinese chinese_8131231_859:
    old "Especially tantric sex, I think it would be good for her to follow that practice."
    new "特别是 tantra 性爱，我觉得她试试会不错。"

translate chinese chinese_0155439_860:
    old "After all, the benefits are great, I think it would really help her with reducing stress and improving her relaxation."
    new "毕竟，好处很大，我觉得这真的能帮助她减压和放松。"

translate chinese chinese_2645561_861:
    old "Which will help her with her sleep."
    new "这会帮助她睡眠。"

translate chinese chinese_1999304_862:
    old "Not to mention her sexual satisfaction, which I believe is clear to the both of us she needs to improve on."
    new "更不用说她的性满足感了，这一点我相信我们俩都清楚需要提高。"

translate chinese chinese_8060920_863:
    old "But more importantly, her personal and spiritual growth, tantra will help her with it, and I believe she'll benefit greatly from it."
    new "但更重要的是，她的个人和精神成长， tantra会帮助她，我相信她会从中受益良多。"

translate chinese chinese_8882951_864:
    old "All of that sounds great, I'm sure you'll have a great time teaching her."
    new "听起来都很好，我相信你会教得很愉快的。"

translate chinese chinese_4070019_865:
    old "Well, since you mentioned it, that's where you come in."
    new "好吧，既然你提到了，那你就要出场了。"

translate chinese chinese_7817996_866:
    old "Anastasia asked me if it would be possible for you to accompany us during the tantric sex sessions."
    new "阿纳斯塔西娅问我，你是否可以陪我们一起参加 tantra 玩乐。"

translate chinese chinese_7516242_867:
    old "M-Me? Do you need me to be there?"
    new "我我？你需要我在那里吗？"

translate chinese chinese_8294886_868:
    old "I mean, with your experience, I don't see why I would need to be there. Don't you just do that directly?"
    new "我的意思是，以你的经验，我觉得我不用在场也能行吧。你不能直接搞定吗？"

translate chinese chinese_7136971_869:
    old "Of course I can teach her everything, but the reason I want you to go there is to be my assistant."
    new "当然我可以教她一切，但我让你去那里的原因是当我的助手。"

translate chinese chinese_5594329_870:
    old "Your assistant?"
    new "你的助手？"

translate chinese chinese_2238805_871:
    old "Yeah, that's right, but not in the way that you may think of."
    new "没错，就是那样，但不是你想的那样。"

translate chinese chinese_7012277_872:
    old "What I need from you is that you play the role of an intermediary between Anastasia and me."
    new "我需要你在我和阿纳斯塔西娅之间充当中间人。"

translate chinese chinese_9734080_873:
    old "I-I'm not sure I get what you're saying."
    new "我还不太明白你的意思。"

translate chinese chinese_9605149_874:
    old "Think about it [pla], you've already worked with Anastasia in the past, so she's comfortable with you in that sense."
    new "想想吧，[pla]，你以前就和阿纳斯塔西娅合作过，所以她在那方面对你很放心。"

translate chinese chinese_0529344_875:
    old "So, when I'm doing the sessions with her, your role will be to help her feel more relaxed and comfortable."
    new "所以，当我跟她进行这些环节时，你的角色就是帮助她感到更放松和自在。"

translate chinese chinese_2224482_876:
    old "So that the session can flow smoothly and without any problems."
    new "以便 session 能够顺利进行，没有任何问题。"

translate chinese chinese_9700563_877:
    old "Hmm, I see, that makes quite a lot of sense."
    new "嗯，我明白了，这说得通。"

translate chinese chinese_8408911_878:
    old "But hey, you and I are still working on my own tantric session."
    new "不过话说回来，你和我还在进行我的 tantra 课程呢。"

translate chinese chinese_9981717_879:
    old "Are you sure it will be a good idea for me to be there? Wouldn't it be better if it's just the two of you?"
    new "你确定我去了会比较好吗？就你们俩会不会更好？"

translate chinese chinese_8163643_880:
    old "Well, at the beginning I did think it strange when she asked for it."
    new "嗯，一开始她要的时候，我还觉得挺奇怪的。"

translate chinese chinese_1739291_881:
    old "But it makes a lot of sense since you've already helped her with her chakra balancing in the past."
    new "但这说得通，因为你过去已经帮她平衡过查克拉了。"

translate chinese chinese_0804617_882:
    old "In addition, I believe it would be good practice for you, it would be a good way for you to work with other clients in the future. If the opportunity arises of course."
    new "此外，我认为这对你来说是个很好的练习，也是将来与其他客户合作的好方式。当然，如果有这样的机会的话。"

translate chinese chinese_7668081_883:
    old "But of course, it all depends on you, if you feel the universe is guiding you towards a teaching role."
    new "当然，这都取决于你，如果你觉得宇宙在引导你走向一个教学的角色。"

translate chinese chinese_8384146_884:
    old "If you don't feel like it, there's no problem, I'll understand."
    new "如果你不想的话也没关系，我理解。"

translate chinese chinese_0644702_885:
    old "Oh, no, no, there's no problem with it. I'll do it, with the way you explain it, it makes a lot of sense."
    new "哦，不不，没问题的。我会做的，你这么一解释，我觉得很有道理。"

translate chinese chinese_2882610_886:
    old "Excellent [pla]! Thank you very much! I know it's going to be great."
    new "太棒了[pla]！非常感谢！我知道一定会很精彩的。"

translate chinese chinese_8414566_887:
    old "I’ve scheduled an appointment for tomorrow evening, would you happen to be available?"
    new "我预约了明天晚上，你有空吗？"

translate chinese chinese_9889584_888:
    old "Uhh, I think so."
    new "嗯，我想是的。"

translate chinese chinese_6950483_889:
    old "Wonderful, I'll get everything ready, and I'll see you later."
    new "太好了，我会把一切都准备好的，待会儿见。"

translate chinese chinese_9216309_890:
    old "Sure, goodbye then."
    new "好吧，那再见了。"

translate chinese chinese_4263264_891:
    old "Anastasia, hi. You're already here, great."
    new "安纳斯塔西娅，嗨。你已经在了，太好了。"

translate chinese chinese_3928184_892:
    old "Yeah, I just arrived, Lisa wasn't here so I decided to wait a while."
    new "是的，我刚到，丽莎不在，所以我决定等一会儿。"

translate chinese chinese_8390074_893:
    old "Oh, she's probably already up in the yoga room waiting for us."
    new "哦，她可能已经在瑜伽室等我们了。"

translate chinese chinese_3601016_894:
    old "Sure, let's go up."
    new "行，上去吧。"

translate chinese chinese_2514380_895:
    old "Oh! Hi Lisa, [pla] and I ran into each other in your living room and..."
    new "哦！丽莎，我和[pla]在你客厅里碰到了……"

translate chinese chinese_4315554_896:
    old "Hmm, Anastasia are you alright?"
    new "嗯，安娜斯塔西娅，你还好吗？"

translate chinese chinese_3837372_897:
    old "Yeah, sorry, sorry."
    new "嗯，对不起，对不起。"

translate chinese chinese_9668690_898:
    old "It's just that the outfit you're wearing... It surprised me."
    new "只是你穿的这套衣服……让我有点意外。"

translate chinese chinese_5033664_899:
    old "I see, that's understandable, but these collars are necessary for what we're about to do."
    new "我明白了，这我能理解，但这些项圈是我们即将要做的事情所需要的。"

translate chinese chinese_4908341_900:
    old "They're an important element that will help to keep the balance of your chakras."
    new "它们是重要元素，有助于保持你的脉轮平衡。"

translate chinese chinese_1736627_901:
    old "I-I see."
    new "我明白了。"

translate chinese chinese_8265155_902:
    old "Yes, because you see, this is a physical process, so the idea is to be fully in contact with our energies."
    new "是的，因为你看，这是一个物理过程，所以想法是要完全接触我们的能量。"

translate chinese chinese_5607111_903:
    old "So we need to get rid of everything that could get in the way of that connection. Of course, our clothes are part of that."
    new "所以我们需要清除一切可能妨碍这种连接的东西。当然，我们的衣服也是其中之一。"

translate chinese chinese_8721147_904:
    old "D-Does that mean that I will be naked too?"
    new "那、那意思是我也会裸体吗？"

translate chinese chinese_6695100_905:
    old "Of course, but don't worry about it, this is a spiritual process, and both [pla] and I are very professional about it."
    new "当然，但别担心，这只是一个精神过程，[pla]和我都很专业。"

translate chinese chinese_8408073_906:
    old "I-I see, I understand."
    new "我懂了，我明白。"

translate chinese chinese_7586343_907:
    old "Good, then let's get started. Why don't you go ahead into the yoga room and get ready?"
    new "好的，那我们就开始吧。你先去瑜伽室准备一下怎么样？"

translate chinese chinese_7769148_908:
    old "[pla] and I will go in a minute."
    new "[pla]和我一会儿就进去。"

translate chinese chinese_0971446_909:
    old "Sure, I'll do that. So, I have to get naked in there?"
    new "行吧，我会这么做的。所以，我得在里面脱光吗？"

translate chinese chinese_2550807_910:
    old "Yes, the idea is that you'll be ready for when [pla] and I come in."
    new "是的，想法是你能在[pla]和我来的时候准备好。"

translate chinese chinese_1559663_911:
    old "I see, I'll do it then."
    new "我明白了，那我来吧。"

translate chinese chinese_7629463_912:
    old "Alright, you know what the idea is, right? You'll support me during the session, and you'll also be without any clothes."
    new "好了，你知道我的意思吧？你在过程中支持我，而且你也不会穿衣服。"

translate chinese chinese_2512379_913:
    old "Yeah sure, no problem."
    new "行吧，没问题。"

translate chinese chinese_1781347_914:
    old "However, for this session onwards, I prepared a special outfit for you."
    new "不过，从这次开始，我为你准备了一套特别的服装。"

translate chinese chinese_1543510_915:
    old "A- a special outfit?"
    new "特、特制的服装？"

translate chinese chinese_7486101_916:
    old "Yes, up until now I've been guiding you in this development journey."
    new "是的，到目前为止我一直在这个开发旅程中指导你。"

translate chinese chinese_1706350_917:
    old "But today you will be the one taking the position of the guide. From now on, you'll be a Yogi."
    new "但是今天你将成为引导者。从现在开始，你将是一名瑜伽师。"

translate chinese chinese_1888866_918:
    old "A yogi, that's the title that a yoga instructor receives when they're guiding somebody."
    new "瑜伽教练在指导别人时被称为瑜伽师。"

translate chinese chinese_2745665_919:
    old "You're not a guru, like I am, but I think it's appropriate that I call you a Yogi, especially because you've already guided Anastasia on the right path."
    new "你不是像我这样的大师，但我认为叫我你瑜伽士很合适，尤其是因为你已经引导阿纳斯塔西娅走上了正轨。"

translate chinese chinese_5134104_920:
    old "That's why I prepared a special outfit for you. You being on another level needs to be reflected in what you're wearing."
    new "那就是为什么我为你准备了一套特别的服装。你的与众不同需要体现在你的穿着上。"

translate chinese chinese_2712615_921:
    old "That and because they're needed to protect and balance your energy."
    new "还有因为它们需要保护和平衡你的能量。"

translate chinese chinese_8042326_922:
    old "I-I see, thank you, Lisa."
    new "我明白了，谢谢你，丽莎。"

translate chinese chinese_6454472_923:
    old "You're more than welcome. Now go and get changed. Anastasia is waiting for us."
    new "别客气。现在去换衣服吧，阿纳斯塔西娅正在等我们。"

translate chinese chinese_0553387_924:
    old "You'll find what you have to wear on the bed."
    new "你得穿的衣服在床上。"

translate chinese chinese_6491926_925:
    old "S- so, I wasn't sure if I was putting it on correctly, but I saw some instructions over the bed."
    new "所...所以，我不确定自己是不是正确佩戴了，但我看到床头有一些说明。"

translate chinese chinese_8490507_926:
    old "What do you think? Does it fit me properly?"
    new "你觉得呢？合身吗？"

translate chinese chinese_8031978_927:
    old "It does, you look great, like a proper yogi."
    new "是的，你看起来很棒，像个真正的瑜伽行者。"

translate chinese chinese_7539622_928:
    old "Let's go in, Anastasia's waiting for us."
    new "进去吧，阿纳斯塔西娅在等我们。"

translate chinese chinese_5946838_929:
    old "{i}(Oh, wow, she's just naked there.){/i}"
    new "{i}（哦，天啊，她竟然光着。）{/i}"

translate chinese chinese_2487022_930:
    old "{i}(I sometimes forget that Anastasia's so hot.){/i}"
    new "{i}（有时我忘了阿纳斯塔西娅竟然这么性感。）{/i}"

translate chinese chinese_8790111_931:
    old "[pla]! Wow! What an outfit."
    new "[pla]！哇哦！这身打扮真棒。"

translate chinese chinese_5884453_932:
    old "You look like a proper shaman now."
    new "你现在看起来像个正宗的萨满了。"

translate chinese chinese_1458997_933:
    old "Hahaha, what [pla]'s wearing is actually a very important part of the tantra ritual that we're going to be performing with you."
    new "哈哈，[pla]穿的这个其实是我们要和你一起进行的 tantra 仪式中非常重要的一部分。"

translate chinese chinese_4709035_934:
    old "Because the idea is that this is as good an experience for you as we can make it."
    new "因为我们的想法是，这将是你所能获得的最佳体验。"

translate chinese chinese_6234824_935:
    old "So, are you ready to start?"
    new "那么，准备好了开始吗？"

translate chinese chinese_9539199_936:
    old "Oh yeah, for sure, I've been waiting for this."
    new "哦 yeah，当然，我一直在等这个。"

translate chinese chinese_3351306_937:
    old "I'm a little nervous."
    new "我有点紧张。"

translate chinese chinese_5247785_938:
    old "But once we start, I'm sure I'll feel a lot better."
    new "但一旦开始了，我肯定会觉得好很多。"

translate chinese chinese_0674277_939:
    old "Listen, Anastasia, I understand the type of situation this is, and how arousing it potentially is."
    new "听着，阿纳斯塔西娅，我明白这种情况有多刺激。"

translate chinese chinese_7797524_940:
    old "But it's important that you keep in mind that this is not for the sake of having sex."
    new "但是重要的是你要记住，这并不是为了发生性关系。"

translate chinese chinese_5863351_941:
    old "The most important part of this whole process is to learn to control those sexual impulses that sometimes take hold of us."
    new "整个过程中最重要的一部分是学会控制那些有时会控制我们的性冲动。"

translate chinese chinese_8392339_942:
    old "So my focus for you during this whole process is that you are able to balance your chakras and put your energy in order."
    new "所以在这个过程中，我的重点是让你能够平衡你的脉轮，整理好你的能量。"

translate chinese chinese_5347008_943:
    old "Hmm, yeah, I guess you're right, but does that mean that we won't be having sex?"
    new "嗯，好吧，我想你是对的，但这是不是意味着我们不会发生性关系了？"

translate chinese chinese_7632364_944:
    old "In the most strict sense of the word, no."
    new "从最严格的意义上来说，不是。"

translate chinese chinese_3864894_945:
    old "We will come to it when the time comes, but what's most important is that you are able to relax."
    new "到时候我们会谈到的，但最重要的是你能放松。"

translate chinese chinese_0521455_946:
    old "To control your sexual energy and come to internal balance with your energy and chakras."
    new "控制你的性能量，让你的能量和脉轮达到内在平衡。"

translate chinese chinese_4183642_947:
    old "Now, let's get started so that you can see how this process feels."
    new "好了，我们现在开始，让你感受一下这个过程。"

translate chinese chinese_0940634_948:
    old "O-Okay, sure."
    new "好，好的。"

translate chinese chinese_9606771_949:
    old "So, before we start with the first session, I want you to keep in mind that you need to focus on your breathing and relaxing your body."
    new "所以，在我们开始第一个疗程之前，我希望你能记住要专注于呼吸并放松身体。"

translate chinese chinese_5080475_950:
    old "Let yourself go and listen to my instructions while you keep your breathing constant."
    new "放松点，保持呼吸平稳，听我的指示。"

translate chinese chinese_4251146_951:
    old "I want to congratulate you, Anastasia."
    new "我想祝贺你，阿纳斯塔西娅。"

translate chinese chinese_8305964_952:
    old "The fact that you were able to truly connect with yourself by doing this therapy."
    new "你通过这种疗法真正与自己连接上了这一事实。"

translate chinese chinese_2826521_953:
    old "I was surprised by how good it feels, I wasn't expecting it. Thank you so much, Lisa! And you too, [pla]."
    new "我没想到会这么舒服，真的很惊喜。谢谢你，丽莎！也谢谢你，[pla]。"

translate chinese chinese_7502034_954:
    old "I'm glad I'm able to help you."
    new "我很高兴能帮到你。"

translate chinese chinese_9302551_955:
    old "But there still remains much to be done."
    new "但还有很多事情需要做。"

translate chinese chinese_0553503_956:
    old "So we will continue during the next session, ok?"
    new "所以我们下次继续，好吗？"

translate chinese chinese_7843373_957:
    old "Oh, we're done? I thought that maybe we could do some more..."
    new "哦，结束了？我还以为我们可以再来一些……"

translate chinese chinese_6301954_958:
    old "I understand that you may feel like it, but we're doing this little by little."
    new "我明白你可能有这样的感觉，但我们得慢慢来。"

translate chinese chinese_9430161_959:
    old "Besides, you may not feel like it now, but you need to rest before you can do more. Believe me, you'll feel it later."
    new "再说，你现在可能不觉得，但你得先休息一下才能做得更多。相信我，你会后来觉得的。"

translate chinese chinese_0298033_960:
    old "Hmm, ok, I get it."
    new "嗯，好吧，我明白了。"

translate chinese chinese_4350239_961:
    old "Yes, by the way, it's getting a little late."
    new "对了，话说现在已经有点晚了。"

translate chinese chinese_6711899_962:
    old "It's better if we get changed and ready for you to return home."
    new "还是换身衣服，准备送你回家吧。"

translate chinese chinese_2568700_963:
    old "Well, I would say that was a very good first session. I'm glad with the progress you made today, Anastasia."
    new "嗯，我想说这第一次挺不错的。我很高兴你今天取得的进步，阿纳斯塔西娅。"

translate chinese chinese_9085362_964:
    old "Thank you very much, Lisa. I wasn't expecting it to be that good, but it was amazing."
    new "非常感谢你，丽莎。我没想到会那么好，真是棒极了。"

translate chinese chinese_7134962_965:
    old "And of course, thanks to you too, [pla]. With you here, I was able to feel so much more comfortable."
    new "当然了，也要谢谢你，[pla]。有你在，我感觉舒服多了。"

translate chinese chinese_9012315_966:
    old "She's right, [pla]. You being here really brings our energies to a state of balance. Thanks a lot."
    new "她说得对，[pla]。你在这里真的让我们的情绪达到了平衡。谢谢你。"

translate chinese chinese_4708249_967:
    old "Oh, well, I'm happy to help."
    new "哦，好吧，我很乐意帮忙。"

translate chinese chinese_6366346_968:
    old "Anyway, it's getting a bit late, so I should head out. I can’t wait for the next tantric class."
    new "反正也挺晚了，我得走了。真期待下次的 tantra 课程。"

translate chinese chinese_7230690_969:
    old "Goodbye, darling, see you at the next yoga session this afternoon."
    new "再见，亲爱的，今天下午的瑜伽课见。"

translate chinese chinese_1522999_970:
    old "Good night, have a great evening."
    new "晚安，祝你有个美好的夜晚。"

translate chinese chinese_4447504_971:
    old "Oh, of course I'll have a wonderful night. Thanks again, you two."
    new "哦，当然我会度过一个美好的夜晚。再次感谢你们两个。"

translate chinese chinese_2608831_972:
    old "Oh [pla], I think it was a total success, I could feel our energies connecting and merging during the tantric exercise."
    new "哦 [pla]，我觉得完全成功了，我在 tantra 练习中能感受到我们的能量连接和融合。"

translate chinese chinese_6847442_973:
    old "I definitely believe the universe is opening a door for my business. It's calling me to guide more clients spiritually. Did you feel it too?"
    new "我确实认为宇宙在为我的生意打开一扇门。它在召唤我去引导更多的客户走向精神上的指引。你也感觉到了吗？"

translate chinese chinese_4927255_974:
    old "Uhh, y- yeah, I totally felt it, that energy was... Definitely something."
    new "呃，嗯，我确实感觉到了，那种能量……绝对不简单。"

translate chinese chinese_5284478_975:
    old "Right? It was almost a religious experience."
    new "对吧？那几乎是一次宗教体验。"

translate chinese chinese_4785835_976:
    old "Oh wow, look at the time, it's really late."
    new "哦 wow，看看时间，真的好晚了。"

translate chinese chinese_2646051_977:
    old "Ugh, I wanted to talk to you about Angelina, but I think we'll leave that for another day."
    new "唉，我想和你谈谈安吉莉娜，但我觉得我们还是留到另一天再说吧。"

translate chinese chinese_2082858_978:
    old "Could you swing by in the afternoon so we can talk? It won't take long."
    new "你能下午过来咱们谈谈吗？不会花很长时间的。"

translate chinese chinese_6677127_979:
    old "Uhh, yeah, sure. No problem."
    new "呃，好的，没问题。"

translate chinese chinese_0867323_980:
    old "Perfect. Let's leave it here so you can get some rest. You've helped me a lot today, [pla]. Thanks."
    new "完美。我们就说到这儿吧，你也可以休息一下。今天你帮了我很多，[pla]。谢谢。"

translate chinese chinese_1328676_981:
    old "Hi Lisa, how are you?"
    new "嗨，丽莎，你好吗？"

translate chinese chinese_2127298_982:
    old "Hey, my energy’s flowing beautifully today, how about you?"
    new "嘿，我今天感觉精力充沛，你呢？"

translate chinese chinese_5488318_983:
    old "I'm fine... Thanks for asking."
    new "我没事……谢谢关心。"

translate chinese chinese_0666096_984:
    old "I came about that thing you mentioned, you wanted to talk about Angelina."
    new "我来是关于你提到的那件事，你想谈谈安吉丽娜。"

translate chinese chinese_2316614_985:
    old "Oh, yes, of course. Thanks for coming."
    new "哦，是的，当然了。感谢你能来。"

translate chinese chinese_4126375_986:
    old "Well, I had a session with her, and she asked me if you could be the teacher in her next class."
    new "嗯，我和她聊过一次，她问我你能不能做她下次课的老师。"

translate chinese chinese_8187965_987:
    old "She did?!"
    new "她做了？！"

translate chinese chinese_0142069_988:
    old "Uhh, yes, why are you so surprised?"
    new "呃，是啊，你为什么这么惊讶？"

translate chinese chinese_8970424_989:
    old "Well, I just wasn't expecting that."
    new "嗯，这真是出乎意料。"

translate chinese chinese_1616836_990:
    old "Because last time she almost looked uncomfortable during the class."
    new "因为上次她在课堂上几乎看起来有些不自在。"

translate chinese chinese_0786612_991:
    old "So it's kind of a surprise that you tell me she wants another class with me."
    new "所以挺意外的，你告诉我她还想再上我的课。"

translate chinese chinese_0129438_992:
    old "Well, she had another class with me after yours."
    new "嗯，她下节课还和我有一堂课。"

translate chinese chinese_1810624_993:
    old "And yes, I've noticed that her energy seems stuck. Her Muladhara chakra is completely out of balance."
    new "而且我注意到她的能量似乎停滞了。她的根基脉轮完全失衡。"

translate chinese chinese_5262146_994:
    old "And it's affecting the flow of prana through her nadis. There might be a deep-rooted samskara causing this blockage."
    new "这影响了她脉轮中的灵能量流动。可能有一个深层次的业力导致了这种阻塞。"

translate chinese chinese_2773271_995:
    old "But after her class with you, I've noticed her blockage has started to dissipate."
    new "但是上过你的课后，我注意到她的障碍开始消散了。"

translate chinese chinese_7571323_996:
    old "For real?"
    new "真的吗？"

translate chinese chinese_5379668_997:
    old "Yes, I've noticed that after her session with you, her energy has started to flow a lot better inside her."
    new "是的，我注意到在和你进行了那次session之后，她的能量流动好多了。"

translate chinese chinese_8894702_998:
    old "Hmm, I have to say, that's a surprise."
    new "嗯，我得说，这真是出乎意料。"

translate chinese chinese_1572788_999:
    old "But if you say that it's alright, and she actually requested another session with me, then I guess it's alright."
    new "但是如果你说没关系，而且她actually请求再和我进行一次session，那我就猜猜看，应该没关系吧。"

translate chinese chinese_5443634_1000:
    old "It is, if she wants to see you again, it means you did a very good job."
    new "如果是这样的话，如果她还想再见到你，那就说明你做得很好。"

translate chinese chinese_9571923_1001:
    old "Uhh, alright..."
    new "呃，好吧……"

translate chinese chinese_4339843_1002:
    old "So, can I count on you for the next session with Angelina?"
    new "所以，我可以指望你参加下次和Angelina的活动吗？"

translate chinese chinese_2500806_1003:
    old "Sure, sure, no problem."
    new "行吧，没问题。"

translate chinese chinese_8349729_1004:
    old "That's wonderful [pla], thanks a lot."
    new "太好了，[pla]，谢谢你。"

translate chinese chinese_4520693_1005:
    old "I'll go ahead and schedule Angelina's next yoga session."
    new "我先帮安吉丽娜预约下一个瑜伽课程吧。"

translate chinese chinese_1845443_1006:
    old "So, as you know, I'll see you this afternoon for your next yoga class."
    new "所以，你知道的，今天下午见，你的下一节瑜伽课。"

translate chinese chinese_2328724_1007:
    old "Sure, count on it."
    new "行，算我一个。"

translate chinese chinese_5573322_1008:
    old "Thank you so much [pla], the universe has great things in store for you!"
    new "谢谢你啊[pla]，宇宙中有很多美好的事物等着你呢！"

translate chinese chinese_5025734_1009:
    old "Heh, thanks. Well, I guess I'll see you later. Bye."
    new "嘿嘿，谢谢。嗯，我想我一会儿见吧。拜拜。"

translate chinese chinese_8654560_1010:
    old "Goodbye [pla], take care."
    new "再见[pla]，保重。"

translate chinese chinese_3774280_1011:
    old "Oh, hi [pla]! it's good to see you."
    new "哦，嗨，[pla]！见到你真好。"

translate chinese chinese_2681454_1012:
    old "Hi, have you been waiting too long for me?"
    new "喂，你等我等很久了吗？"

translate chinese chinese_7954049_1013:
    old "Not at all, Angelina just arrived a couple of minutes ago."
    new "根本不是，Angelina刚才才到几分钟。"

translate chinese chinese_6293311_1014:
    old "So you're just in time for the class."
    new "你刚好赶上课。"

translate chinese chinese_7567785_1015:
    old "But it's better if you don't lose time."
    new "不过最好不要浪费时间。"

translate chinese chinese_0139848_1016:
    old "So why don't you two go upstairs to the yoga room?"
    new "那你们俩为什么不上去到瑜伽室呢？"

translate chinese chinese_8252874_1017:
    old "Sure, we'll see you later then."
    new "好吧，那一会儿见。"

translate chinese chinese_6201506_1018:
    old "Alright, I guess that if you're feeling alright, we can get started with the session."
    new "好吧，如果你觉得没问题，我们就开始吧。"

translate chinese chinese_1735026_1019:
    old "S- sure, let's do it."
    new "好嘛，我们就这么做吧。"

translate chinese chinese_6740005_1020:
    old "{i}(Hmm, she's still feeling uncomfortable? It's a surprise that she wanted another session.){/i}"
    new "{i}（嗯，她还是觉得不舒服吗？没想到她还想再来一次。）{/i}"

translate chinese chinese_6872440_1021:
    old "{i}(I guess she'll relax when we start with the asanas.){/i}"
    new "{i}（我想等我们开始做瑜伽姿势时，她就会放松了。){/i}"

translate chinese chinese_2540760_1022:
    old "Okay, let's get started with the first position then."
    new "好的，那我们就从第一个姿势开始吧。"

translate chinese chinese_4003722_1023:
    old "{i}(Hmm, this feels alright.){/i}"
    new "{i}（嗯，这个感觉还不错。）{/i}"

translate chinese chinese_7481257_1024:
    old "{i}(I didn't notice before, but this is a very comfortable position.){/i}"
    new "{i}（之前没注意到，这个姿势很舒服。）{/i}"

translate chinese chinese_7501529_1025:
    old "Ok, I see you're doing a little better than last time."
    new "好的，我看到你这次比上次好一点了。"

translate chinese chinese_8052830_1026:
    old "T-Thank you."
    new "谢谢你。"

translate chinese chinese_6855834_1027:
    old "That's it, you're doing very well."
    new "就是这样，你做得很好。"

translate chinese chinese_9089299_1028:
    old "{i}(Well, her movement's a lot more smooth.){/i}"
    new "{i}（嗯，她的动作流畅多了。）{/i}"

translate chinese chinese_9566460_1029:
    old "{i}(That's very good, she's very focused.){/i}"
    new "{i}（非常好，她非常专注。）{/i}"

translate chinese chinese_8977931_1030:
    old "You're doing very, very well."
    new "你做得非常好。"

translate chinese chinese_4977295_1031:
    old "Remember to keep focusing on your breathing and how your muscles feel."
    new "记得集中注意力在你的呼吸和肌肉的感觉上。"

translate chinese chinese_8108853_1032:
    old "Excellent, I think we can stop there."
    new "很好，我觉得我们可以到这里为止了。"

translate chinese chinese_4448125_1033:
    old "Alright! That was an excellent start!"
    new "好啦！这开头真是太棒了！"

translate chinese chinese_6840769_1034:
    old "I can tell that you're doing so much better than last time."
    new "我能看出来你这次比上次好多了。"

translate chinese chinese_5863889_1035:
    old "Are you feeling better than during the last session?"
    new "你感觉比上次好些了吗？"

translate chinese chinese_3993869_1036:
    old "T-Thank you [pla]."
    new "谢谢你，[pla]。"

translate chinese chinese_3178182_1037:
    old "Yeah, I'm feeling a little better than before."
    new "是的，我现在感觉比之前好一点了。"

translate chinese chinese_9054716_1038:
    old "Okay, that's very good."
    new "好吧，这很好。"

translate chinese chinese_6223587_1039:
    old "{i}(She's doing a lot better, great!){i}"
    new "{i}(她好多了，棒极了！){i}"

translate chinese chinese_1023377_1040:
    old "Very good Angelina! I can see that you're a lot more relaxed!"
    new "非常好，安吉丽娜！我能看出你放松多了！"

translate chinese chinese_4889414_1041:
    old "{i}(Dang, I hadn't focused on it, because she's pregnant. But Angelina has a really great ass.){/i}"
    new "{i}(哎呀，我都没注意到，因为她怀孕了。但安吉丽娜的屁股真的很好看。){/i}"

translate chinese chinese_7281573_1042:
    old "{i}(And the way she's pushing it against me...){/i}"
    new "{i}（还有她这样顶着我……）{/i}"

translate chinese chinese_2665482_1043:
    old "{i}(Oh shit! I can't believe this is happening now!){/i}"
    new "噢shit！真不敢相信现在会发生这种事！"

translate chinese chinese_9582845_1044:
    old "{i}(Damn! But I don't think she's noticed yet, I better don't say anything to her about it.){/i}"
    new "{i}(该死！不过我觉得她还没发现，我还是不要跟她提这件事。){/i}"

translate chinese chinese_6408651_1045:
    old "{i}(Let's hope she doesn't notice.){/i}"
    new "{i}（希望她没注意到。){/i}"

translate chinese chinese_2876375_1046:
    old "I'm still doing well [pla]?"
    new "我还在做得很好的[pla]？"

translate chinese chinese_0098166_1047:
    old "Y- yeah, you are, w- why don't we move on to the next position?"
    new "嗯，你是的，那为什么不换个姿势继续呢？"

translate chinese chinese_2223977_1048:
    old "Ok, you're doing amazing."
    new "好，你做得很好。"

translate chinese chinese_6484538_1049:
    old "Now, I think we can move on to the third position."
    new "现在，我想我们可以进行到第三个姿势了。"

translate chinese chinese_3196192_1050:
    old "Oh yeah, sure."
    new "哦，是吗。"

translate chinese chinese_8720674_1051:
    old "{i}(Damn, this position’s even worse.){/i}"
    new "{i}(该死，这个姿势更糟糕。){/i}"

translate chinese chinese_3538208_1052:
    old "Uhh, just keep your eyes closed... t- to feel the energy better..."
    new "呃，就闭着眼...能更好地感受能量..."

translate chinese chinese_8460972_1053:
    old "{i}(I hope she doesn't notice.){/i}"
    new "{i}（希望她没注意到。）{/i}"

translate chinese chinese_6123486_1054:
    old "Hmm, this feels very good [pla]."
    new "嗯，这个感觉真好[pla]。"

translate chinese chinese_7388299_1055:
    old "T- that's very good, well done."
    new "那、那非常好，做得不错。"

translate chinese chinese_4511502_1056:
    old "Remember to keep breathing."
    new "记得呼吸。"

translate chinese chinese_9369842_1057:
    old "{i}(She's finally feeling comfortable, I wouldn't want to make her feel awkward.){/i}"
    new "{i}（她终于放松了，我不想让她感到尴尬。）{/i}"

translate chinese chinese_2894985_1058:
    old "Am I doing it alright [pla]?"
    new "我做得怎么样，[pla]？"

translate chinese chinese_0072478_1059:
    old "Y-yes! You're doing great!"
    new "是的！你做得很好！"

translate chinese chinese_4071741_1060:
    old "{i}(Huh? What did I just touch with my head?){/i}"
    new "{i}（咦？我刚用头碰到了什么？）{/i}"

translate chinese chinese_0229746_1061:
    old "{i}(W- what? Is that his? Oh my...){/i}"
    new "({i}啊——什么？那是他的？天啊……{/i})"

translate chinese chinese_5823030_1062:
    old "{i}(I did feel something during the last position, but I thought it was just his arm.){/i}"
    new "{i}（在上一个姿势时我确实感觉到了什么，但以为只是他的手臂而已。）{/i}"

translate chinese chinese_5130469_1063:
    old "{i}(Maybe I should tell him about it?){/i}"
    new "{i}(也许我应该告诉他这件事？){/i}"

translate chinese chinese_8435176_1064:
    old "{i}(B-But I feel so good right, now, I wouldn't want to stop.){/i}"
    new "({i}但是我现在感觉这么好，不想停下来。{/i})"

translate chinese chinese_5592768_1065:
    old "{i}(I feel better than I've felt in a while.){/i}"
    new "{i}(我觉得比很久以来都要好。){/i}"

translate chinese chinese_4505501_1066:
    old "{i}(I haven't felt this way since my therapy sessions with Dr. Johnson...){/i}"
    new "{i}（我上次有这种感觉还是和约翰逊医生做心理治疗的时候……){/i}"

translate chinese chinese_7607972_1067:
    old "Ok, I think we can stop for now Angelina."
    new "好吧，我觉得我们可以先停下来了，安吉丽娜。"

translate chinese chinese_1663502_1068:
    old "Do we have to? I think this is really helping me."
    new "我们非做不可吗？我觉得这真的对我有帮助。"

translate chinese chinese_9271855_1069:
    old "I'm enjoying it a lot."
    new "我非常喜欢这样。"

translate chinese chinese_3716495_1070:
    old "Uhh, o- ok, I guess we can keep going for a while."
    new "呃，好吧，我想我们可以再继续一会儿。"

translate chinese chinese_7432848_1071:
    old "{i}(Well, at least she doesn't seem to have noticed my boner. So I guess it's alright.){/i}"
    new "{i}（还好，至少她好像没注意到我的勃起。所以应该没事。）{/i}"

translate chinese chinese_3083122_1072:
    old "{i}(Hmm, I'm feeling so hot right now, but I want more.){/i}"
    new "{i}(嗯，我现在感觉好热，但还想更多。){/i}"

translate chinese chinese_2391416_1073:
    old "{i}(Like how I felt while we were doing those sessions with Dr. Johnson...){/i}"
    new "{i}（就像我们在约翰逊博士那里做那些疗程时的感觉一样...）{/i}"

translate chinese chinese_7061702_1074:
    old "I should just do it!"
    new "我就这么做吧！"

translate chinese chinese_2488030_1075:
    old "Angelina? W-what are you doing?"
    new "安吉丽娜？你你在干什么？"

translate chinese chinese_2735470_1076:
    old "Well, I noticed your boner."
    new "嗯，我注意到了你的勃起。"

translate chinese chinese_5452265_1077:
    old "And I thought I should give you a hand with it."
    new "我以为我应该帮你一下。"

translate chinese chinese_9425416_1078:
    old "B-But..."
    new "B-但是..."

translate chinese chinese_4735428_1079:
    old "Oh come on, just let me do this."
    new "哦，拜托，就让我做这件事吧。"

translate chinese chinese_7936982_1080:
    old "I want to do it, and it's not like we haven't done it before!"
    new "我想做，而且这也不是我们第一次做了！"

translate chinese chinese_7179305_1081:
    old "Uhmm, hey, are you alright?"
    new "嗯，嘿，你还好吗？"

translate chinese chinese_3269396_1082:
    old "Would you mind telling me what that was?"
    new "你能告诉我那是什么吗？"

translate chinese chinese_0175168_1083:
    old "I'm sorry [pla], I suppose you weren't expecting that."
    new "对不起 [pla]，我想你没料到这一点。"

translate chinese chinese_6720535_1084:
    old "I- I didn't mean to surprise you that way."
    new "我——我不是故意要吓你一跳的。"

translate chinese chinese_4485105_1085:
    old "Hey, it's alright... I think."
    new "嘿，没事吧……我想。"

translate chinese chinese_2314661_1086:
    old "It's just that you caught me off guard."
    new "只是你把我吓到了。"

translate chinese chinese_7621650_1087:
    old "Again, I'm sorry about that."
    new "再说一声，真的很抱歉。"

translate chinese chinese_4055137_1088:
    old "The thing is that I've been so frustrated lately that when I noticed you had an erection I just let myself go."
    new "其实我最近很烦躁，注意到你硬了就控制不住自己了。"

translate chinese chinese_9887289_1089:
    old "Oh yeah? Why are you so frustrated?"
    new "哦是吗？为什么你这么烦躁？"

translate chinese chinese_1971252_1090:
    old "Well, I- I haven't been having sex with my husband lately."
    new "嗯，我最近没和我老公做爱。"

translate chinese chinese_2433722_1091:
    old "You haven't? But I thought that the sessions with Dr. Johnson..."
    new "你还没？可是我以为和约翰逊博士的疗程……"

translate chinese chinese_5999246_1092:
    old "They did help..."
    new "他们确实帮了忙……"

translate chinese chinese_9795800_1093:
    old "After we were done, I did become more open in that regard. I'm now able to perform my duties as a wife."
    new "事后，我在那方面确实变得开朗多了。现在我能履行妻子的职责了。"

translate chinese chinese_0102937_1094:
    old "But I would be lying if I said that I enjoy it."
    new "但如果说我喜欢这样，那我就是在撒谎。"

translate chinese chinese_0825160_1095:
    old "To be honest, I haven't enjoyed sex since I was with you and Dr. Johnson."
    new "说实话，自从和你还有约翰逊医生在一起后，我就没再享受过性生活。"

translate chinese chinese_3635924_1096:
    old "When I got pregnant I got this huge boost in my libido."
    new "怀孕后我的性欲猛增。"

translate chinese chinese_7278483_1097:
    old "I was hoping that it would improve things in bed with my husband."
    new "我本以为这能改善我和丈夫的床上生活。"

translate chinese chinese_9869742_1098:
    old "And did it help?"
    new "那这样有用吗？"

translate chinese chinese_4137988_1099:
    old "Not at all, I just don't desire him. So I'm just left feeling frustrated."
    new "根本不是，我就是对他没感觉。所以就只能感到沮丧了。"

translate chinese chinese_7090039_1100:
    old "I guess that's why I reacted that way when I noticed that you had that boner."
    new "我想这就是为什么我注意到你硬了的时候会有那样的反应。"

translate chinese chinese_1660040_1101:
    old "I'm sorry [pla]."
    new "对不起，[pla]。"

translate chinese chinese_2538467_1102:
    old "Nah, it's alright, don't worry."
    new "算了，没事的，别担心。"

translate chinese chinese_9539474_1103:
    old "You just caught me by surprise, but it's no problem really."
    new "你只是把我吓了一跳，但实际上没什么问题。"

translate chinese chinese_5108077_1104:
    old "But you know, I think there might be something that I can do for you."
    new "不过你知道吗，我觉得我可能能为你做些什么。"

translate chinese chinese_5468768_1105:
    old "There is?!"
    new "真的有？！"

translate chinese chinese_9934742_1106:
    old "Sure! Yoga's not just about positions."
    new "当然！瑜伽不光是关于姿势的。"

translate chinese chinese_3478912_1107:
    old "It's about improving your relationship with yourself by helping you balance your energy and your chakras."
    new "这是关于通过帮助你平衡能量和脉轮来改善你与自己的关系。"

translate chinese chinese_1295400_1108:
    old "I already helped you once before, I don't see why not help you again."
    new "我之前已经帮过你一次了，再帮你一次也没什么。"

translate chinese chinese_4950818_1109:
    old "So for the next session, I think we'll focus on that."
    new "所以下次我们就集中讨论那个吧。"

translate chinese chinese_9339365_1110:
    old "Oh that sounds amazing [pla]! Thank you so much!"
    new "哦，听起来太棒了[pla]！太谢谢你了！"

translate chinese chinese_2682466_1111:
    old "But for now I think we should get going, so Lisa won't worry about this taking too long."
    new "不过现在我觉得我们应该出发了，免得丽莎担心这会花太长时间。"

translate chinese chinese_6368170_1112:
    old "Well, how do you feel, Angelina?"
    new "那你觉得呢，安吉丽娜？"

translate chinese chinese_8865934_1113:
    old "I feel great! Thanks, Lisa!"
    new "我感觉棒极了！谢谢你，丽莎！"

translate chinese chinese_7502542_1114:
    old "I can see that, I'm glad to see evidence of the positive effect yoga's having on you."
    new "我看得出来，很高兴看到瑜伽对你产生了积极的影响。"

translate chinese chinese_0608296_1115:
    old "It also makes me happy to see that [pla]'s been a proper guide for you on this yoga journey."
    new "看到[pla]在这段瑜伽之旅中成了你的合格导师，我也很高兴。"

translate chinese chinese_4096346_1116:
    old "He really has been, and I can't wait for my next class."
    new "他确实很棒，我真期待下一节课。"

translate chinese chinese_5767958_1117:
    old "Well, I'll schedule it right away."
    new "那我就马上安排吧。"

translate chinese chinese_1495955_1118:
    old "Thank you, and thank you, [pla]."
    new "谢谢，还有谢谢你，[pla]。"

translate chinese chinese_3193367_1119:
    old "You're welcome, I'll see you next time."
    new "不客气，下次见。"

translate chinese chinese_9595426_1120:
    old "Goodbye, and until next time."
    new "再见，下次见。"

translate chinese chinese_3912789_1121:
    old "Okay, so, tell me how did you feel her energy today?"
    new "好吧，说说今天你感受到她的气息了吗？"

translate chinese chinese_9580298_1122:
    old "Well, honestly, I saw that she was doing the exercises better."
    new "说实话，我看到她的练习进步了。"

translate chinese chinese_8607290_1123:
    old "Really? In my last session with her, I felt her so much more connected."
    new "真的吗？上次和她的互动中，我感觉她和我的联系紧密多了。"

translate chinese chinese_2923332_1124:
    old "Definitely, a masculine energy was just what her chakras needed to let go."
    new "确实，她的脉轮正是需要这种阳刚之气来释放。"

translate chinese chinese_5700798_1125:
    old "Yeah, she really let herself go..."
    new "是啊，她真的放纵自己了……"

translate chinese chinese_4958765_1126:
    old "Excellent, [pla], fate truly gifted me by bringing you into my path."
    new "太好了，[pla]，命运真是眷顾我，让你出现在我的生活中。"

translate chinese chinese_7498430_1127:
    old "By the way, I wanted to ask how your evenings look for scheduling the next tantric session with Anastasia?"
    new "对了，我想问一下你晚上什么时间方便，好安排下次和安纳斯塔西娅的 tantra 课程？"

translate chinese chinese_1517880_1128:
    old "Hmm, fine, I don't think I’ll have any problem coming at night."
    new "嗯，好吧，我觉得晚上过来应该没问题。"

translate chinese chinese_4170091_1129:
    old "Excellent! See how the universe puts everything in its place?"
    new "太好了！看看宇宙是如何让一切各就其位的？"

translate chinese chinese_5557414_1130:
    old "I'll talk to Anastasia and set up an appointment for the next tantric session. We'll be expecting you at night as always."
    new "我去找安纳斯塔西娅安排下次 tantra 课程的时间。还是老时间，晚上见。"

translate chinese chinese_5995355_1131:
    old "Sure, count me in."
    new "行，算我一个。"

translate chinese chinese_6114369_1132:
    old "Wonderful, I'll get everything ready, and I'll see you then."
    new "太好了，我会准备好一切，到时候见。"

translate chinese chinese_2790634_1133:
    old "Hmm, this is odd, there's no one here."
    new "嗯，这挺奇怪的，这里一个人也没有。"

translate chinese chinese_2361972_1134:
    old "Anastasia hasn't arrived? Maybe she's running late?"
    new "安娜斯塔西娅还没到？ maybe她迟到了？"

translate chinese chinese_7752657_1135:
    old "I'll take a look upstairs, maybe they're already in the yoga room."
    new "我上去看看，也许他们已经在瑜伽室了。"

translate chinese chinese_9658811_1136:
    old "Oh! You're both here already, did I arrive too late?"
    new "哦！你们俩都在这里，我来晚了吗？"

translate chinese chinese_2096263_1137:
    old "Hi [pla], good evening."
    new "你好 [pla]，晚上好。"

translate chinese chinese_7407570_1138:
    old "No, it's alright, Anastasia just got here early, so we got ready and were just chatting."
    new "不，没关系，安纳斯塔西娅只是来早了，所以我们准备了一下，就在聊天。"

translate chinese chinese_1236122_1139:
    old "But you're not late or anything."
    new "但是你并没有迟到啊。"

translate chinese chinese_5582272_1140:
    old "I see, that's good to hear."
    new "哦，这样啊，听到这个很好。"

translate chinese chinese_6646821_1141:
    old "Yeah, but now that you're here, we can begin. Why don't you go and get changed?"
    new "没错，但现在你来了，我们可以开始了。你去换身衣服吧？"

translate chinese chinese_9630172_1142:
    old "Alright, I'm ready."
    new "好了，我准备好了。"

translate chinese chinese_9810996_1143:
    old "Excellent."
    new "非常好。"

translate chinese chinese_8223895_1144:
    old "Ok, are you ready to start, Anastasia?"
    new "好了，安妮斯塔西娅，准备开始吗？"

translate chinese chinese_6926028_1145:
    old "Oh yeah, I'm more than ready!"
    new "哦 yeah，我早就准备好了！"

translate chinese chinese_8193882_1146:
    old "After last time, I've been waiting for this."
    new "自从上次之后，我就一直在等着这一刻。"

translate chinese chinese_6869167_1147:
    old "I can't wait to have another orgasm like last time. I want to cum."
    new "我迫不及待想再来一次像上次那样的高潮了。我想射。"

translate chinese chinese_8202065_1148:
    old "Well, I'm glad you're this excited for the session."
    new "好吧，很高兴你对这次会面这么兴奋。"

translate chinese chinese_5658093_1149:
    old "But remember, what's most important is that you're able to connect with yourself and feel the energy flow through you."
    new "但记住，最重要的是你能与自己连接，并感受到能量在你体内流动。"

translate chinese chinese_6972607_1150:
    old "Of course, of course."
    new "当然，当然。"

translate chinese chinese_2947797_1151:
    old "I haven't forgotten what you taught me last time."
    new "上次你教我的东西我还没忘呢。"

translate chinese chinese_6257747_1152:
    old "Good, then we can begin."
    new "好的，那我们可以开始了。"

translate chinese chinese_8545852_1153:
    old "Are you ready too, [pla]?"
    new "你准备好了吗，[pla]？"

translate chinese chinese_8671298_1154:
    old "Oh yeah, for sure."
    new "哦，对，肯定的。"

translate chinese chinese_9360201_1155:
    old "Great, let's begin then."
    new "好，那我们开始吧。"

translate chinese chinese_2374639_1156:
    old "So, how was it, Anastasia? Did you enjoy the process?"
    new "所以，安娜斯塔西娅，怎么样？你觉得过程愉快吗？"

translate chinese chinese_2814287_1157:
    old "Oh yeah! I loved it! It was amazing!"
    new "哦对！我太喜欢了！太棒了！"

translate chinese chinese_2386293_1158:
    old "It felt amazing, just like last time. I loved it!"
    new "感觉太棒了，就像上次一样。我爱死它了！"

translate chinese chinese_1906291_1159:
    old "I'm glad to hear that. It's a testament to the work being done to help you bring your chakras and energies into balance."
    new "听到这个我很高兴。这证明了正在帮助你平衡脉轮和能量的工作是有效的。"

translate chinese chinese_6829877_1160:
    old "And I can see that you're doing very well, right [pla]?"
    new "而且我能看出来你过得很好，对吧 [pla]？"

translate chinese chinese_5865973_1161:
    old "Oh yeah, you're doing great."
    new "哦 yeah，你做得很好。"

translate chinese chinese_3376190_1162:
    old "I can tell by your good mood that your Muladhara chakra is already getting balanced."
    new "从你的好心情来看，你的根基轮已经趋于平衡了。"

translate chinese chinese_6003768_1163:
    old "[pla]'s right, your energy is flowing so much better through your body."
    new "[pla]说得对，你的能量现在在体内流动得好多了。"

translate chinese chinese_7745973_1164:
    old "Thank you guys, I'm very happy to hear that."
    new "谢谢你们，听到这个我非常高兴。"

translate chinese chinese_7642633_1165:
    old "But, I was wondering if maybe we could do a little bit more."
    new "但是，我在想我们是不是可以再多做一些。"

translate chinese chinese_9277077_1166:
    old "Y-You know, s-since you say I'm doing so well."
    new "你、你知道，既然你说我做得这么好。"

translate chinese chinese_2467060_1167:
    old "I would like to know if we can keep going."
    new "我想知道我们能否继续。"

translate chinese chinese_8446928_1168:
    old "Maybe we could do another exercise?"
    new "要不我们再做个别的练习吧？"

translate chinese chinese_2168481_1169:
    old "That's only if you think it's alright!"
    new "那只有你觉得可以才行！"

translate chinese chinese_1548870_1170:
    old "Actually, I was about to tell you just that."
    new "实际上，我正打算告诉你这件事。"

translate chinese chinese_5440817_1171:
    old "You've done very well during this first stage of the process of chakra balancing."
    new "你在这一阶段的查克拉平衡过程中表现得很好。"

translate chinese chinese_9817609_1172:
    old "So I believe you're ready to try something new."
    new "所以我认为你准备好尝试一些新东西了。"

translate chinese chinese_9949496_1173:
    old "Really? Great! What will we be doing? I can't wait."
    new "真的吗？太好了！我们打算做什么？我都等不及了。"

translate chinese chinese_2135130_1174:
    old "Well, the goal with what we've been doing so far is getting you to connect with yourself."
    new "好吧，我们到目前为止做的这一切的目标就是让你与自己产生连接。"

translate chinese chinese_7889910_1175:
    old "So that you could feel the flow of energy in your body."
    new "这样你能感受到体内能量的流动。"

translate chinese chinese_9963968_1176:
    old "Now, it's time to create a connection with the outside, and for that, [pla] will be helping us in this new practice."
    new "现在，是时候与外界建立联系了，为此，在这个新的练习中，[pla]将会帮助我们。"

translate chinese chinese_0861033_1177:
    old "Alright, what are we going to do?"
    new "好吧，我们接下来怎么办？"

translate chinese chinese_8902806_1178:
    old "We're engaging in a posture where the goal is for the three of us to create an energetic chain."
    new "我们要进入一个姿势，目标是三个人形成一个能量链。"

translate chinese chinese_6129369_1179:
    old "The point of that is that we're able to unite our energies."
    new "关键在于我们能够凝聚力量。"

translate chinese chinese_8845478_1180:
    old "And you can allow yourself to release what's pent up inside of you, Anastasia."
    new "你可以让自己释放内心压抑的东西了，阿纳斯塔西娅。"

translate chinese chinese_6663035_1181:
    old "Okay, that sounds interesting."
    new "好吧，这听起来挺有意思的。"

translate chinese chinese_7825084_1182:
    old "I bet that's going to feel even better than the massage."
    new "我敢打赌这感觉比按摩还要爽。"

translate chinese chinese_8906196_1183:
    old "Sure, it might."
    new "行吧，可能会。"

translate chinese chinese_1907821_1184:
    old "But you have to remember that whatever sexual pleasure you get from this is only secondary to the actual goal of getting your chakras in proper balance."
    new "但你必须记住，从这个过程中获得的性愉悦只是次要的，主要目标是让你的脉轮达到平衡。"

translate chinese chinese_4710880_1185:
    old "Of course, of course, I haven't forgotten."
    new "当然，当然，我没忘。"

translate chinese chinese_1840138_1186:
    old "Alright, it's time to start."
    new "好了，开始吧。"

translate chinese chinese_0732118_1187:
    old "I- Is this okay? Am I positioned properly?"
    new "我——这样可以吗？位置对吗？"

translate chinese chinese_3395937_1188:
    old "You are, that's just perfect."
    new "你真是，这再完美不过了。"

translate chinese chinese_9567584_1189:
    old "How are you [pla]? Is this comfortable for you?"
    new "你怎么样，[pla]？这样舒服吗？"

translate chinese chinese_5267147_1190:
    old "Y- yeah! No problem!"
    new "耶！没问题！"

translate chinese chinese_8154015_1191:
    old "Good, then we're going to start moving slowly."
    new "好的，那我们就慢慢开始行动。"

translate chinese chinese_2959042_1192:
    old "Ok, I would like to ask if you have any comments on how this process is going."
    new "好的，我想问一下你对这个过程有什么看法。"

translate chinese chinese_5668974_1193:
    old "The only thing I have to say is that it's been amazing!"
    new "我唯一想说的是，这真是太棒了！"

translate chinese chinese_1138731_1194:
    old "It's just as good as I wanted it to be."
    new "这正是我想要的。"

translate chinese chinese_5480628_1195:
    old "Although, I still would love to do something a little... Harder with [pla]."
    new "虽然，我还是很想和[pla]做一些稍微……激烈一点的事情。"

translate chinese chinese_0657498_1196:
    old "All in good time."
    new "一切顺其自然。"

translate chinese chinese_8344297_1197:
    old "But I'm glad to hear that you're satisfied with the way this has been working."
    new "不过听到你对这个结果满意，我也很高兴。"

translate chinese chinese_9758614_1198:
    old "What do you say we get dressed and come down?"
    new "你说我们穿好衣服下去怎么样？"

translate chinese chinese_3164928_1199:
    old "Alright, I will be seeing you both for the next session."
    new "好的，下次见你们俩。"

translate chinese chinese_7817818_1200:
    old "Sure, but before I leave, I want to thank you, Lisa."
    new "好的，但在走之前，我想感谢你，丽莎。"

translate chinese chinese_5440083_1201:
    old "At first, I was only interested in having sex with you guys."
    new "一开始，我只对和你们发生关系感兴趣。"

translate chinese chinese_7921039_1202:
    old "But doing this has been an eye-opening experience for me."
    new "但是这样做对我来说真是大开眼界。"

translate chinese chinese_0508420_1203:
    old "This has completely changed my perspective about what pleasure and enjoyment are."
    new "这完全改变了我对快乐和享受的看法。"

translate chinese chinese_8364085_1204:
    old "I'm glad you feel this way about what we've been doing. That's the main goal of this."
    new "很高兴你对我们的事情有这种感觉。这才是最重要的目标。"

translate chinese chinese_6777371_1205:
    old "Thanks a lot, Lisa, and also you, [pla]. I can't wait for the next session."
    new "谢谢你，丽莎，还有你，[pla]。我期待下次的环节。"

translate chinese chinese_0828148_1206:
    old "Very well. We’ll schedule it after our next yoga session."
    new "好吧。我们在下次瑜伽课后安排吧。"

translate chinese chinese_7865102_1207:
    old "So, how did you find today's session? Did you feel all that energy and balance between the three of you?"
    new "所以，你觉得今天的环节怎么样？感受到你们三个人之间的那种能量和平衡了吗？"

translate chinese chinese_2461272_1208:
    old "Hmm, yeah, I definitely felt it a lot."
    new "嗯，是的，我确实感觉到了很多。"

translate chinese chinese_2231109_1209:
    old "It's amazing. And did you hear what she said about the whole process?"
    new "太神奇了。而且你听说她是怎么说整个过程的吗？"

translate chinese chinese_4970025_1210:
    old "I really feel like I'm an instrument of the universe, balancing and transmitting energy to all my clients."
    new "我真觉得自己是宇宙的工具，为所有客户平衡和传递能量。"

translate chinese chinese_4198554_1211:
    old "Yes, you’ve truly helped all the women you’ve worked with."
    new "是的，你确实帮助了所有合作过的女性。"

translate chinese chinese_6452796_1212:
    old "Thank you for your words. By the way, I wanted to talk to you about Angelina."
    new "谢谢你的安慰。对了，我想和你谈谈安吉丽娜。"

translate chinese chinese_8692477_1213:
    old "Uhh, sure, tell me..."
    new "嗯，好吧，告诉我……"

translate chinese chinese_0380759_1214:
    old "Well, I had a yoga session with Angelina, and I have to tell you that I've seen an impressive improvement in her condition."
    new "嗯，我和安吉拉上了一节瑜伽课，我得告诉你，她的状况有了显著的改善。"

translate chinese chinese_3370316_1215:
    old "The problems with her Muladhara chakra seem to be getting resolved."
    new "她的 Muladhara 脉轮问题似乎正在解决。"

translate chinese chinese_5161091_1216:
    old "She's still not entirely ok, but I can feel her prana flowing better within her body."
    new "她还没完全恢复，但我能感觉到她的魔力在体内流动得更好了。"

translate chinese chinese_2797269_1217:
    old "Her energy is a lot more balanced, and I can see her being more receptive to the flow of energy among her chakras."
    new "她的能量平衡了很多，我能看出她对经脉间能量流动的接受度更高了。"

translate chinese chinese_3064113_1218:
    old "I must start recommending you to my other clients that may have some problems with their energy flow."
    new "我必须开始把我其他有能量流动问题的客户介绍给你了。"

translate chinese chinese_6954736_1219:
    old "You've done so much by helping first Anastasia, and then Angelina."
    new "你帮了安纳斯塔西娅那么多，后来又帮了安杰莉娜。"

translate chinese chinese_4911060_1220:
    old "You've done an excellent job [pla], congratulations."
    new "你做得非常出色，[pla]，恭喜你。"

translate chinese chinese_0279706_1221:
    old "W-well, thank you."
    new "嗯，谢谢。"

translate chinese chinese_9204385_1222:
    old "The last thing is that she asked me if there was a possibility of you giving her another class."
    new "最后一件事是，她问我你有没有可能再给她上一次课。"

translate chinese chinese_1103541_1223:
    old "Sure! If our sessions together are working, then I'm more than happy to do it. No problem."
    new "当然！如果我们的疗程有效，那我很乐意继续。没问题。"

translate chinese chinese_2667696_1224:
    old "Excellent, I'm glad you're willing to accept because I believe she still needs it."
    new "太好了，我很高兴你愿意接受，因为我认为她仍然需要它。"

translate chinese chinese_1513263_1225:
    old "So thank you [pla]."
    new "所以谢谢你，[pla]。"

translate chinese chinese_3175734_1226:
    old "You're welcome, you know I'm more than happy to help you."
    new "不客气，你知道我乐意帮你。"

translate chinese chinese_7249116_1227:
    old "Thanks a lot [pla], I'll see you later then."
    new "多谢了[pla]，那回头见。"

translate chinese chinese_3417710_1228:
    old "Hey Lisa, hi Angelina, how are you?"
    new "嘿丽莎，安吉莉娜你好，最近怎么样？"

translate chinese chinese_6984102_1229:
    old "Hello [pla], good afternoon."
    new "你好[pla]，下午好。"

translate chinese chinese_5785353_1230:
    old "Hi, [pla], nice to see you again"
    new "嗨，[pla]，又见到你真好"

translate chinese chinese_7747781_1231:
    old "Are you ready for your next session?"
    new "你准备好接下来的环节了吗？"

translate chinese chinese_9340419_1232:
    old "Yeah, sure, I'm ready."
    new "好吧，我准备好了。"

translate chinese chinese_4262704_1233:
    old "Great, I've already talked with Angelina and she's ready too. So let's go to the yoga room then."
    new "好的，我已经和Angelina谈过了，她也准备好了。那我们就去瑜伽室吧。"

translate chinese chinese_9291379_1234:
    old "Well, I'll let you guys be, I hope you enjoy today's session as well Angelina."
    new "那我就先告辞了，希望你今天也玩得开心，安吉丽娜。"

translate chinese chinese_4688542_1235:
    old "Thank you, Lisa."
    new "谢谢你，丽莎。"

translate chinese chinese_4030093_1236:
    old "See you, Lisa."
    new "再见，丽莎。"

translate chinese chinese_8305498_1237:
    old "So, how are you?"
    new "所以，你怎么样？"

translate chinese chinese_8380500_1238:
    old "I'm feeling alright."
    new "我感觉还不错。"

translate chinese chinese_0060552_1239:
    old "But this whole deal with the pregnancy hormones has me going through the roof."
    new "但这些怀孕激素让我简直要疯了。"

translate chinese chinese_8528969_1240:
    old "The doctor explained to me that it's perfectly normal."
    new "医生跟我解释说这是完全正常的。"

translate chinese chinese_4051957_1241:
    old "But I'm not sure about that, because I wasn't feeling this way before, it's just since I saw you that I started feeling this weird way."
    new "但是我不确定，因为之前我可不是这种感觉，只是自从见到你之后，我才开始有这种奇怪的感觉。"

translate chinese chinese_1962572_1242:
    old "Yeah, but he said that as soon as the baby's born, everything should be fine."
    new "是啊，但他说了等宝宝出生后，一切都会好起来的。"

translate chinese chinese_9947464_1243:
    old "So, keeping that in mind... I wanted to ask a favor of you [pla]."
    new "所以，考虑到这一点……我想请你帮个忙，[pla]。"

translate chinese chinese_3071614_1244:
    old "Do you think you would be willing to help me again with these... needs that I have?"
    new "你觉得愿意再帮我满足这些需求吗？"

translate chinese chinese_1694430_1245:
    old "I- It would just be the one time, I swear."
    new "我发誓，就这一次。"

translate chinese chinese_2558313_1246:
    old "It's just that I'm feeling this enormous tension as of late, and I really need to deal with it."
    new "只是最近感觉压力山大，我真的需要处理一下。"

translate chinese chinese_9545967_1247:
    old "And I think you're the only one who can really help me with it."
    new "而且我觉得只有你能真正帮到我。"

translate chinese chinese_7788255_1248:
    old "Uhh, I don't know... Lisa's downstairs and could come by any moment."
    new "呃，我不知道……丽莎在楼下，随时可能过来。"

translate chinese chinese_4074917_1249:
    old "Also, you're pregnant, I don't know how safe this is."
    new "而且，你怀孕了，我不知道这安全不安全。"

translate chinese chinese_3292763_1250:
    old "Don't worry about that, it's nothing dangerous. I already checked with my doctor. It'll just be quick, I promise I won't make much noise."
    new "别担心，没什么危险的。我已经让医生检查过了。很快就好，我保证不会弄出很大声音的。"

translate chinese chinese_9332941_1251:
    old "But what about the yoga class..."
    new "但是关于瑜伽课……"

translate chinese chinese_1320880_1252:
    old "Look, I signed up for the class with Lisa because I felt so repressed, just like when I studied with Dr. Johnson."
    new "你看，我跟丽莎一起报名上课是因为我觉得自己很压抑，就像跟约翰逊博士学习时一样。"

translate chinese chinese_3363641_1253:
    old "And being pregnant, I wanted to try something different... But I ended up finding you again, and well, my hormones went wild and they're practically shouting for it."
    new "而且怀孕了，我想尝试些不同的东西……但最后还是找到了你，然后我的荷尔蒙失控了，简直是在大声呼喊着想要。"

translate chinese chinese_1587267_1254:
    old "This would really help me more than a yoga class, and I think you know that."
    new "这对我比上瑜伽课有用多了，我想你应该知道。"

translate chinese chinese_0971026_1255:
    old "{b}*Sigh*{/b}, alright, but only this once, and then we'll go back to yoga classes like before."
    new "{b}*叹气*{/b}，好吧，但只有这一次，然后我们就回去上瑜伽课。"

translate chinese chinese_3189413_1256:
    old "Yes, yes, go ahead, my body is craving it and I think you'll enjoy it too, really."
    new "是的，是的，来吧，我的身体渴望这个，我觉得你也会喜欢的，真的。"

translate chinese chinese_6140293_1257:
    old "Hmm... Alright..."
    new "嗯……好吧……"

translate chinese chinese_9535607_1258:
    old "Ok, lie back and let me enjoy suking that big cock of yours."
    new "好吧，躺下来让我好好享受吸你的大鸡巴。"

translate chinese chinese_2331524_1259:
    old "Mmm! I have been waiting for this since last time!"
    new "嗯！我从上次就开始期待这个了！"

translate chinese chinese_3913970_1260:
    old "I can't have enough of this!"
    new "我还不够满足！"

translate chinese chinese_5064522_1261:
    old "That felt wonderful [pla]!"
    new "那感觉真棒，[pla]！"

translate chinese chinese_0641722_1262:
    old "Well, I'm glad that you're feeling better, that was the whole point of this."
    new "好吧，我很高兴你感觉好些了，这本来就是目的。"

translate chinese chinese_7659836_1263:
    old "Thank you [pla], I also think that once the baby's born I'll feel a lot better."
    new "谢谢你[pla]，我也觉得等宝宝出生后我会感觉好很多。"

translate chinese chinese_4780555_1264:
    old "I'm sure you will."
    new "我敢肯定你会的。"

translate chinese chinese_1075841_1265:
    old "Remember, if you really want a YOGA class, you can talk to Lisa."
    new "记得，如果你真的想上瑜伽课，可以去找莉莎聊聊。"

translate chinese chinese_2765562_1266:
    old "Thank you [pla], I'll keep it in mind, and of course, if I ever need it, I'll let Lisa know."
    new "谢谢你[pla]，我会记住的，当然了，如果我需要的话，会告诉丽莎的。"

translate chinese chinese_8894299_1267:
    old "And I hope she'll tell you."
    new "希望她会告诉你。"

translate chinese chinese_1182902_1268:
    old "Great! But for now, it's getting late, so I think I'll head home."
    new "太好了！不过现在有点晚了，我想我还是回家吧。"

translate chinese chinese_9785408_1269:
    old "But once again, thank you [pla], for all your help. This has been great."
    new "但是再次感谢你，[pla]，谢谢你的帮助。这真是太好了。"

translate chinese chinese_9964721_1270:
    old "Are you guys done?"
    new "你们好了吗？"

translate chinese chinese_8793245_1271:
    old "We are. It was great, Lisa."
    new "我们是。真的很棒，丽莎。"

translate chinese chinese_4575148_1272:
    old "I can see that, it seems the yoga really worked on you, Angelina."
    new "我看得出来，看来瑜伽真的很对你胃口，安吉丽娜。"

translate chinese chinese_0753750_1273:
    old "I can see your energy flowing a lot better within you."
    new "我看得出来你的能量流动好多了。"

translate chinese chinese_1712783_1274:
    old "Very good, [pla], you've done a good job."
    new "非常好，[pla]，你做得很好。"

translate chinese chinese_2364205_1275:
    old "He has been a very good teacher."
    new "他是个非常好的老师。"

translate chinese chinese_1048468_1276:
    old "I can see that."
    new "我看得出来。"

translate chinese chinese_6387545_1277:
    old "I hope you'll keep coming to classes after this, Angelina."
    new "我希望你这次之后还会继续来上课，安吉莉娜。"

translate chinese chinese_3295345_1278:
    old "I will, I'll keep coming even after the baby's born."
    new "我会的，就算宝宝出生了我也会继续来的。"

translate chinese chinese_4947855_1279:
    old "That's wonderful news."
    new "那真是个好消息。"

translate chinese chinese_2545084_1280:
    old "Thank you, both of you."
    new "谢谢你们两个。"

translate chinese chinese_0691683_1281:
    old "I'll go home now."
    new "我现在回家。"

translate chinese chinese_9347292_1282:
    old "But I'll come back soon for my next class."
    new "但我很快就会回来上下次课。"

translate chinese chinese_4638757_1283:
    old "Of course, see you soon."
    new "当然，很快见。"

translate chinese chinese_7662933_1284:
    old "She's definitely looking much better, [pla]. You did a great job with her today."
    new "她确实看起来好多了，[pla]。你今天做得很好。"

translate chinese chinese_4404575_1285:
    old "Uh, yeah, it was an excellent session. She really enjoyed it."
    new "嗯，是的，那次真的很棒。她真的很享受。"

translate chinese chinese_9799466_1286:
    old "Awesome! You’ve learned how to transmit that energy well. I truly feel you’ll become a great instrument for the universe."
    new "太棒了！你已经学会了很好地传递那种能量。我真心觉得你会成为宇宙中伟大的工具。"

translate chinese chinese_9181492_1287:
    old "Speaking of which, I’m scheduling a new tantric session with Angelina. Could you come by one evening soon?"
    new "说起来，我打算近期和安吉丽娜安排一个新的 tantra 课程。你有空晚上过来吗？"

translate chinese chinese_4541845_1288:
    old "Uh, sure, no problem."
    new "嗯，好的，没问题。"

translate chinese chinese_0753438_1289:
    old "Hmm, they're not here again."
    new "嗯，他们又不在这里。"

translate chinese chinese_7801450_1290:
    old "Well, I imagine that just means that they're already up in the yoga room."
    new "好吧，我想那 probably 意味着他们已经在瑜伽室了。 \n\n(Note: \"probably\" is kept as is since it was not explicitly mentioned in the instruction to translate it.)"

translate chinese chinese_4391119_1291:
    old "Hello [pla], I'm glad you arrived."
    new "你好[pla]，很高兴你来了。"

translate chinese chinese_8156023_1292:
    old "Hey, were you waiting too long for me?"
    new "嘿，你等我很久吗？"

translate chinese chinese_4522802_1293:
    old "No, Anastasia arrived not too long ago, and we just got ready. Why don't you get changed so we can start?"
    new "不，阿纳斯塔西娅刚才才到，我们刚准备好的。你不如去换身衣服，我们可以开始了？"

translate chinese chinese_6851461_1294:
    old "Great, then we can start with the session."
    new "好的，那我们可以开始这一环节了。"

translate chinese chinese_4664404_1295:
    old "Lisa told me that we would be trying something new today."
    new "丽莎告诉我今天我们会尝试一些新的东西。"

translate chinese chinese_5906367_1296:
    old "I can't wait to see what we'll do."
    new "真期待我们要做什么。"

translate chinese chinese_8463879_1297:
    old "Of course, but remember that before anything else you have to connect with yourself."
    new "当然，但记住最重要的是首先要和自己连接。"

translate chinese chinese_9728792_1298:
    old "And focus on the balance of your chakras."
    new "还要注意你的脉轮平衡。"

translate chinese chinese_9914349_1299:
    old "It's just that I'm very excited to see what's coming."
    new "我只是对即将发生的事情非常兴奋。"

translate chinese chinese_9678262_1300:
    old "Let's begin then, so you can see how it is."
    new "那我们就开始吧，让你看看是怎么回事。"

translate chinese chinese_3861774_1301:
    old "Well done Anastasia, I can see by how well you're doing that these sessions have been very effective for you."
    new "干得好，阿纳斯塔西娅，看得出来这些疗程对你非常有效。"

translate chinese chinese_0286225_1302:
    old "How do you feel about what we've been doing?"
    new "你觉得我们做的事情怎么样？"

translate chinese chinese_5864090_1303:
    old "I feel great! I no longer feel any nervousness or anxiety about what we're doing."
    new "我感觉很棒！不再对我们在做的事情感到任何紧张或焦虑。"

translate chinese chinese_1186945_1304:
    old "And it's all thanks to you both, [pla] and Lisa. Thank you."
    new "这全都要感谢你们俩，[pla] 和丽莎。谢谢你们。"

translate chinese chinese_2331932_1305:
    old "Hey, I'm happy to help."
    new "嘿，我很乐意帮忙。"

translate chinese chinese_8533606_1306:
    old "It makes me happy to see that you're doing so well."
    new "看到你过得这么好，我真的很高兴。"

translate chinese chinese_7435846_1307:
    old "And I believe you're ready for the next stage."
    new "我相信你已经准备好进入下一阶段了。"

translate chinese chinese_0270947_1308:
    old "Alright, great! I trust that you know what's best."
    new "好吧，很好！我相信你知道什么最好。"

translate chinese chinese_0834856_1309:
    old "Now, for this next exercise, the idea is that you finish the internal connection with yourself."
    new "现在，这个下一个练习的目的是让你完成与自己的内心连接。"

translate chinese chinese_8490171_1310:
    old "The first one we made was to help you relax and understand yourself on a deeper level."
    new "我们做的第一个是为了帮你放松，更深层次地了解自己。"

translate chinese chinese_0574607_1311:
    old "The second one was focused on you learning to let your energy flow freely in and out of you."
    new "第二个重点是让你学会让能量自由地进出你的身体。"

translate chinese chinese_7022684_1312:
    old "This last one is about you using what you have learned to forge a new connection with your inner being."
    new "这个最后的部分是关于你运用所学来与自己的内心建立新的联系。"

translate chinese chinese_5910521_1313:
    old "For this, [pla] will be playing an important role, but what's most important is that you focus on yourself, okay?"
    new "为此，[pla]将扮演重要角色，但最重要的是你要专注于自己，好吗？"

translate chinese chinese_8872643_1314:
    old "Sure! I get it!"
    new "行吧！我懂了！"

translate chinese chinese_2357402_1315:
    old "Alright, let's get started."
    new "好了，开始吧。"

translate chinese chinese_5276173_1316:
    old "Ok, are you ready?"
    new "好了，你准备好了吗？"

translate chinese chinese_3989318_1317:
    old "Yes, I am, I feel like I can do this now."
    new "是的，我现在觉得我可以做到。"

translate chinese chinese_1903701_1318:
    old "Remember to keep your breathing stable."
    new "记得保持呼吸平稳。"

translate chinese chinese_4321276_1319:
    old "Focus on yourself, what you're feeling deep inside."
    new "专注于你自己，你内心深处的感受。"

translate chinese chinese_3455413_1320:
    old "On the balance of your chakras."
    new "关于你的脉轮平衡。"

translate chinese chinese_1930580_1321:
    old "Well done, Anastasia. I can clearly see a change in you from the time we started this process to now."
    new "干得好，阿纳斯塔西娅。从我们开始这个过程到现在，我明显看到了你的变化。"

translate chinese chinese_9110537_1322:
    old "Your chakras are much more balanced now, and I can feel all the positive energy coming from you."
    new "你现在气脉平衡多了，我能感受到你身上的正能量。"

translate chinese chinese_8932457_1323:
    old "Thank you, Lisa, and thank you, [pla]."
    new "谢谢你，丽莎，还有你，[pla]。"

translate chinese chinese_0897786_1324:
    old "Because of this great help from you two, my perspective on sex has completely changed."
    new "因为你们俩的大帮助，我对性的看法完全改变了。"

translate chinese chinese_3765982_1325:
    old "I'll be sure to apply this to my own life in the future."
    new "我以后一定会把这一点应用到自己的生活中。"

translate chinese chinese_6798202_1326:
    old "Excellent! Because that's exactly what this is about!"
    new "太好了！因为这正是我们要谈的！"

translate chinese chinese_1776639_1327:
    old "As I already explained to [pla], this is something that you can live in every area of your life."
    new "就像我之前向[pla]解释的那样，这是你可以贯穿生活各个方面的东西。"

translate chinese chinese_6018809_1328:
    old "It's not just about sex, but about how you project your energy daily, and it makes me happy that you understood that."
    new "这不仅仅是关于性，还关乎你每天如何释放能量，你明白这一点让我很开心。"

translate chinese chinese_9952392_1329:
    old "Thank you, Lisa, I'll be sure to remember that."
    new "谢谢丽莎，我一定会记住的。"

translate chinese chinese_2698300_1330:
    old "Really, what I got from these sessions is more than what I was expecting."
    new "真的，从这些训练中我得到的比预期的要多。"

translate chinese chinese_3670779_1331:
    old "I'm happy that's how you feel, but this isn't a finished process."
    new "我很高兴你这么觉得，但这不是一个结束的过程。"

translate chinese chinese_3785718_1332:
    old "It's important that you keep practicing these teachings in the future."
    new "重要的是你要在未来继续实践这些教诲。"

translate chinese chinese_9878696_1333:
    old "I'll be sure to do that."
    new "我一定会这么做的。"

translate chinese chinese_7138504_1334:
    old "Great! Now, it's late, so let's get changed so that you two can go home."
    new "好啦！现在已经晚了，你们俩去换衣服回家吧。"

translate chinese chinese_6780498_1335:
    old "Alright, that's it for now, but remember, we will see each other soon, okay? Both for your regular yoga classes, and for tantric sesions."
    new "好吧，暂时就到这里，但记住，我们很快就会见面的，好吗？不仅是为了你的常规瑜伽课，还有 tantra 课程。"

translate chinese chinese_6954813_1336:
    old "Sure, I'll be seeing you soon."
    new "好的，很快见。"

translate chinese chinese_7813289_1337:
    old "Thanks again to both of you, see you."
    new "再次感谢你们两个，再见。"

translate chinese chinese_9964142_1338:
    old "Happy to help, see you later."
    new "乐意帮忙，回头见。"

translate chinese chinese_9076192_1339:
    old "Okay, I think this first step of adding other areas besides yoga to my classes was a total success."
    new "好吧，我觉得在课程中加入瑜伽以外的其他项目这个第一步非常成功。"

translate chinese chinese_6859760_1340:
    old "Yeah, I think it would go really well if you offered it to more of your clients."
    new "嗯，我觉得如果你向更多的客户推荐的话，效果会很好的。"

translate chinese chinese_7738669_1341:
    old "Wow [pla], I feel so excited about this path the universe is taking me on."
    new "哇 [pla]，我觉得宇宙带我走的这条路太令人兴奋了。"

translate chinese chinese_1346002_1342:
    old "I believe we can do great things to help a lot of people."
    new "我相信我们可以做些伟大的事情来帮助很多人。"

translate chinese chinese_8998884_1343:
    old "I'm sure of it."
    new "我确定。"

translate chinese chinese_6929782_1344:
    old "I’ll follow the natural flow of destiny, I’ll take it step by step; I don’t want things to get out of hand."
    new "我会顺其自然，一步步来；我不想事情失控。"

translate chinese chinese_6589655_1345:
    old "I hope you can keep helping me, there are many clients who would really benefit from your energy and vitality."
    new "我希望你能继续帮助我，有很多客户都能从你的活力中受益。"

translate chinese chinese_1799238_1346:
    old "Of course, count on me whenever you need."
    new "当然了，你需要的时候就尽管算上我。"

translate chinese chinese_5367541_1347:
    old "Aww, you’ve been such a wonderful gift from the universe to me."
    new "哎呀，你真是宇宙送给我的一份美好的礼物。"

translate chinese chinese_5444408_1348:
    old "Oh, speaking of that, I didn’t think it was necessary, but Angelina asked again for you to accompany her in a new class."
    new "哦，说到这个，我以为不需要了，但Angelina又问你陪她上一门新课。"

translate chinese chinese_6184138_1349:
    old "Hmm, yeah, I figured that would happen."
    new "嗯，我想到了会这样。"

translate chinese chinese_6236003_1350:
    old "You’ve done so much good for that girl, the difference is noticeable. She looks radiant, smiling, with such special energy."
    new "你为那个女孩做了这么多好事，变化很明显。她看起来光彩照人，笑容满面，散发着特别的活力。"

translate chinese chinese_0359753_1351:
    old "Does it sound good if I schedule you with her for a session in the afternoon?"
    new "如果我安排你们下午见面，听起来怎么样？"

translate chinese chinese_3607309_1352:
    old "Yes, go ahead, no problem. I’ll talk to her about what she really wants to focus on."
    new "好的，没问题。我会和她谈谈她真正想专注的事情。"

translate chinese chinese_8761992_1353:
    old "Sounds great, you’re a real guru! I’ll schedule the appointment with her and we’ll see each other then for your next session with her."
    new "听起来不错，你真是个高手！我会给她安排预约，到时候见，你的下次疗程就和她一起。"

translate chinese chinese_4145378_1354:
    old "Okay, thanks Lisa, we’ll meet then for Angelina’s next session. Have a good night."
    new "好的，谢谢丽莎，那我们就下次安吉莉娜的疗程见了。晚安。"

translate chinese chinese_8430720_1355:
    old "Rest well [pla], take care."
    new "好好休息 [pla]，保重。"

translate chinese chinese_9885111_1356:
    old "Oh, hey [pla], you’re just in time, Angelina just arrived too."
    new "哦，嘿[pla]，你来的正好，Angelina也刚到。"

translate chinese chinese_7624761_1357:
    old "Hi [pla], great to see you again."
    new "你好[pla]，很高兴再次见到你。"

translate chinese chinese_0324035_1358:
    old "Hey Angelina, how are you?"
    new "嘿，安吉丽娜，你好吗？"

translate chinese chinese_1126682_1359:
    old "Excited for the new yoga class."
    new "对新瑜伽课很兴奋。"

translate chinese chinese_2613005_1360:
    old "Uh, heh, yeah, I can imagine..."
    new "呃，哈哈，我能想象……"

translate chinese chinese_7123560_1361:
    old "Well, I see you’re both eager for the class, so why not head upstairs and enjoy it?"
    new "好吧，我看你们两个都迫不及待了，那为什么不上去好好享受一下呢？"

translate chinese chinese_1353180_1362:
    old "Sounds perfect, I’m excited, let’s go [pla]."
    new "听起来完美，我好激动，我们走吧[pla]。"

translate chinese chinese_0676084_1363:
    old "{b}*Sigh*{/b}, Sure, let’s go."
    new "{b}*叹气*{/b}，好吧，我们走吧。"

translate chinese chinese_4065129_1364:
    old "Okay, okay, what did we talk last time?"
    new "好啦好啦，上次我们聊到哪里了？"

translate chinese chinese_9186460_1365:
    old "Because I don’t think you came just to practice yoga exercises, right?"
    new "因为我不认为你来只是为了练习瑜伽动作，对吧？"

translate chinese chinese_3918523_1366:
    old "Look, I know, but seriously my body is going crazy, you don’t understand."
    new "你看，我知道，但 seriously 我的身体快要失控了，你不懂的。"

translate chinese chinese_0117606_1367:
    old "Being pregnant turns me into a teenager full of hormones."
    new "怀孕让我变成了一个荷尔蒙爆棚的 teenager。"

translate chinese chinese_7290271_1368:
    old "And after weeks of sexual frustration, seeing you again reactivated so many things in me that I’d only felt during therapy with Dr. Johnson."
    new "经过几周的性压抑，再次见到你让我重新感受到了很多之前只在约翰逊医生治疗时才有的感觉。"

translate chinese chinese_4535732_1369:
    old "Honestly, if it weren’t so necessary for me right now, I wouldn’t bother you."
    new "说实话，如果不是我现在真的很需要，我根本不会麻烦你。"

translate chinese chinese_0264592_1370:
    old "{b}*Sigh*{/b}, Okay, let’s do it if it makes you feel better."
    new "{b}*叹气*{/b}，好吧，如果你觉得这样做会好受点，我们就这么做吧。"

translate chinese chinese_3224878_1371:
    old "I appreciate it [pla], I’ll make sure you enjoy it."
    new "我明白[pla]，我会确保你玩得开心的。"

translate chinese chinese_3168806_1372:
    old "Oh, yes, I’ve been fantasizing about this since last time..."
    new "哦，是的，从上次开始我就一直幻想这个..."

translate chinese chinese_8619528_1373:
    old "Mmm, it feels so good, I could never get tired of it."
    new "嗯，感觉真好，我永远不会厌倦。"

translate chinese chinese_4913272_1374:
    old "Wow, that was amazing, [pla]!"
    new "哇，真棒，[pla]！"

translate chinese chinese_0034651_1375:
    old "I’m really happy you’re feeling better."
    new "真高兴你感觉好多了。"

translate chinese chinese_9677606_1376:
    old "And hey, if you ever want a real YOGA session, just let me know."
    new "哦对了，如果你真想体验瑜伽，就告诉我一声。"

translate chinese chinese_6671439_1377:
    old "Thanks, [pla]. I’ll definitely keep that in mind."
    new "谢谢，[pla]。我一定会记住的。"

translate chinese chinese_7478534_1378:
    old "This has been wonderful, but it’s getting late. I should head home."
    new "这真是太好了，不过已经很晚了，我该回家了。"

translate chinese chinese_6999472_1379:
    old "Really, thank you so much for all your GREAT help today, it means a lot."
    new "真的，非常感谢你今天所有的大力帮助，意义重大。"

translate chinese chinese_8203421_1380:
    old "You’re welcome. Now let's go down to talk with Lisa."
    new "不客气。现在我们下去找丽莎谈谈。"

translate chinese chinese_4145212_1381:
    old "Oh, Are you guys done?"
    new "哦，你们搞定了吗？"

translate chinese chinese_3380016_1382:
    old "How do you feel after our yoga session?"
    new "我们瑜伽结束后你觉得怎么样？"

translate chinese chinese_0931658_1383:
    old "It was amazing, Lisa, thank you!"
    new "太棒了，丽莎，谢谢你！"

translate chinese chinese_7692917_1384:
    old "I can sense a calm clarity in your energy now, Angelina."
    new "我现在能感受到你能量中的一种平静清晰，安吉莉娜。"

translate chinese chinese_2869557_1385:
    old "Your inner balance has really deepened."
    new "你的内心平衡感真的加深了。"

translate chinese chinese_3430081_1386:
    old "And [pla], you did an excellent job guiding her through the flow."
    new "还有[pla]，你很好地引导了她。"

translate chinese chinese_2908894_1387:
    old "He was so attentive and supportive."
    new "他那么体贴和支持我。"

translate chinese chinese_0751710_1388:
    old "Absolutely, you two make a great team."
    new "绝对的，你们俩真是绝配。"

translate chinese chinese_5525747_1389:
    old "Angelina, I hope you'll continue with these sessions. [pla] and I are always here for you."
    new "安杰丽娜，希望你能继续这些疗程。[pla] 和我都会一直在这里支持你。"

translate chinese chinese_1523445_1390:
    old "I definitely will, even after the baby arrives, I’ll keep practicing."
    new "我一定会的，就算宝宝来了，我也会继续练习。"

translate chinese chinese_8310477_1391:
    old "That’s wonderful to hear."
    new "听到这个真是太好了。"

translate chinese chinese_9547722_1392:
    old "Thank you both for your guidance."
    new "感谢两位的指导。"

translate chinese chinese_8517092_1393:
    old "I’ll head back now, but I’m looking forward to our next class."
    new "我现在先回去了，不过很期待我们下次的课。"

translate chinese chinese_8708835_1394:
    old "We’ll be ready, see you soon!"
    new "我们会准备好的，很快见！"

translate chinese chinese_2571750_1395:
    old "Take care, Angelina."
    new "照顾好自己，Angelina。"

translate chinese chinese_0591719_1396:
    old "As always, you did an amazing job, [pla]."
    new "像往常一样，你做得非常棒，[pla]。"

translate chinese chinese_7769837_1397:
    old "I can see it in the vibrant energy you both radiate afterward."
    new "我能从你们之后散发出的活力中看出来。"

translate chinese chinese_8855984_1398:
    old "Uh, thanks, yeah, I really put my effort into it."
    new "呃，谢谢，是的，我真的很努力了。"

translate chinese chinese_4468142_1399:
    old "I love your dedication and your calling to help others. You remind me of myself when I was younger."
    new "我欣赏你的奉献精神和帮助他人的热情。你让我想起了年轻时的自己。"

translate chinese chinese_6115259_1400:
    old "Anyway, it’s quite late. You should get some rest."
    new "反正现在已经很晚了，你应该去休息一下。"

translate chinese chinese_5742435_1401:
    old "You’re right. Goodbye, and rest well."
    new "你说得对。再见，好好休息。"

translate chinese chinese_2566218_1402:
    old "Same to you, [pla]. Take care, and we’ll see each other soon."
    new "同样祝福你，[pla]。保重，很快我们会再见面的。"

translate chinese chinese_5397000_1403:
    old "Hey Lisa, how have you been?"
    new "嘿丽莎，最近怎么样？"

translate chinese chinese_3198710_1404:
    old "Hi [pla], great to see you! Are you here for another yoga session with me?"
    new "嗨 [pla]，见到你真好！你是来跟我再上一节瑜伽课的吗？"

translate chinese chinese_4781681_1405:
    old "Uh, maybe another day..."
    new "呃，要不改天吧..."

translate chinese chinese_2292649_1406:
    old "Actually, I was wondering, why haven’t we had any new sessions with Anastasia or Angelina lately?"
    new "其实我在想，最近为什么没有和阿纳斯塔西娅或者安杰丽娜的新会面呢？"

translate chinese chinese_4825029_1407:
    old "Oh, well, Anastasia actually went out of town for a bit, but I’ve stayed in touch with her. She’s planning to return soon."
    new "哦，其实安纳斯塔西娅去外地了一段时间，但我一直和她保持联系。她计划很快回来。"

translate chinese chinese_3673283_1408:
    old "Oh, nice. I hope she’s enjoying her trip. Did she mention when she’ll be back?"
    new "哦，挺好的。希望她旅途愉快。提到什么时候回来吗？"

translate chinese chinese_7280374_1409:
    old "She said in a few weeks."
    new "她说几个星期吧。"

translate chinese chinese_6254210_1410:
    old "Oh, alright. And Angelina?"
    new "哦，好吧。还有安吉丽娜？"

translate chinese chinese_2466674_1411:
    old "Oh, you didn’t hear? The doctor told Angelina to take it easy, no workouts or anything, so we’re giving her a break from the sessions."
    new "哦，你不知道吗？医生让安吉丽娜休息一下，不要做运动之类的，所以我们暂停了她的训练课程。"

translate chinese chinese_7160672_1412:
    old "Oh really? Well, makes sense. Health first."
    new "哦真的吗？好吧，说得通。健康最重要。"

translate chinese chinese_8898012_1413:
    old "Absolutely. She was disappointed, she loved the sesions, but she needs to focus on her well-being."
    new "绝对的。她很失望，她很喜欢那些课程，但她需要专注于自己的健康。"

translate chinese chinese_8375497_1414:
    old "I’m sorry I didn’t let you know earlier, you’re a blessing for always caring about others."
    new "对不起，我没早点告诉你，你真是个善解人意的福星。"

translate chinese chinese_7157067_1415:
    old "Oh, no, it’s nothing. I was just wondering, since we’ve had some busy days with Angelina and Anastasia’s sessions lately."
    new "哦，不，没什么。我只是在想，因为我们最近忙着Angelina和Anastasia的课程。"

translate chinese chinese_4059364_1416:
    old "Don't worry, once Angelina and Anastasia resume, we’ll pick up right where we left off."
    new "别担心，一旦安吉丽娜和阿纳斯塔西娅恢复了，我们就从上次离开的地方继续。"

translate chinese chinese_4755616_1417:
    old "And who knows, we might even add a group workshop."
    new "而且谁知道呢，我们甚至可能会加一个小组工作坊。"

translate chinese chinese_2030909_1418:
    old "A group workshop? Uhh, o- ok, yeah sure..."
    new "一个小组工作坊？呃，好……好吧……"

translate chinese chinese_9401936_1419:
    old "It’s so thrilling, right? I can’t wait to see what else the universe has in store."
    new "太刺激了，对吧？真迫不及待想看看宇宙还准备了什么。"

translate chinese chinese_8297959_1420:
    old "Everything is happening so fast, it’s so exhilarating..."
    new "一切发生得太快了，真是刺激……"

translate chinese chinese_9208143_1421:
    old "Heh, I’m glad you’re so excited."
    new "嘿嘿，看你这么兴奋我也很高兴。"

translate chinese chinese_3582965_1422:
    old "Well, I’ll be on standby for whenever you need me."
    new "好吧，我随时待命等你召唤。"

translate chinese chinese_1970664_1423:
    old "Yes, don’t worry, you’ll be back here helping me soon. There are even new clients I’d like you to meet."
    new "放心，你会很快回来帮我忙的。甚至还有新客户我想介绍给你。"

translate chinese chinese_6201418_1424:
    old "For now, rest and keep working on your exercises and inner energy."
    new "暂时先休息一下，继续练习你的内功。"

translate chinese chinese_1563472_1425:
    old "Sure, I’ll keep that in mind."
    new "行，我会记住的。"

translate chinese chinese_1217130_1426:
    old "Excellent, have a great day [pla], we’ll see each other soon."
    new "太好了，祝你今天过得愉快 [pla]，很快再见。"

translate chinese chinese_7023972_1427:
    old "Goodbye Lisa, see you soon."
    new "再见丽莎，很快见。"

translate chinese chinese_7850238_1428:
    old "Hello Lisa, how are you?"
    new "你好丽莎，最近怎么样？"

translate chinese chinese_5631472_1429:
    old "Good, the energies have come to me, how about you."
    new "好的，能量已经来了，你呢？"

translate chinese chinese_6310022_1430:
    old "Pretty nice, I am glad to see everything is going well."
    new "挺不错的，看到一切都好我也很高兴。"

translate chinese chinese_5178475_1431:
    old "I can't complain, the business is running just fine."
    new "没什么好抱怨的，生意挺好的。"

translate chinese chinese_7445136_1432:
    old "Hmm... I'm happy for you."
    new "嗯……为你高兴。"

translate chinese chinese_7467084_1433:
    old "Remember that you are free to come over any time you want for a few free yoga lessons."
    new "记得你随时可以过来上几节免费的瑜伽课。"

translate chinese chinese_5636212_1434:
    old "Sure, I think, I'll make an appointment soon."
    new "好的，我想我很快会预约一下。"

translate chinese chinese_3882892_1435:
    old "That sounds good, you have such energy and potential."
    new "听起来不错，你这么有活力又有潜力。"

translate chinese chinese_2938083_1436:
    old "Thank you. Anyway, I will let you keep working, it was nice to see you."
    new "谢谢。总之，我会让你继续工作的，见到你很高兴。"

translate chinese chinese_0290687_1437:
    old "It was nice to you too, have a wonderful day."
    new "也很高兴见到你，祝你一天愉快。"

translate chinese chinese_1273553_1438:
    old "No, no, sorry I was just walking around. See you later..."
    new "不，不，对不起我只是在四处走走。回头见..."

translate chinese chinese_1966426_1439:
    old "Hey, good morning, nice to see you so early."
    new "嘿，早上好，这么早见到你真好。"

translate chinese chinese_8757083_1440:
    old "Hehehe,It's nice to see you too."
    new "嘿嘿嘿，见到你也很高兴。"

translate chinese chinese_0999106_1441:
    old "I am always ready very early to make the sungreeting, it's one of my favorites, you can't imagine how grateful I feel with the universe."
    new "我总是很早就准备好做日出问候，这是我最喜欢的事情之一，你无法想象我对宇宙有多么感激。"

translate chinese chinese_2183150_1442:
    old "Sounds very interesting."
    new "听起来很有趣。"

translate chinese chinese_4921529_1443:
    old "By the way, why are you so early here? Do you want to practice?"
    new "对了，你今天怎么来得这么早？想练习吗？"

translate chinese chinese_8112280_1444:
    old "Oh no, I can't at this moment."
    new "哦不，我现在不行。"

translate chinese chinese_2159155_1445:
    old "It's ok, remember you need to keep on training so you can take the most out of you and your energy."
    new "没关系，记得你需要持续训练，才能充分发挥你的潜力和精力。"

translate chinese chinese_2911343_1446:
    old "You are right."
    new "你说得对。"

translate chinese chinese_1413673_1447:
    old "Don't forget you are welcome to train whenever you need."
    new "别忘了你需要的时候随时可以来训练。"

translate chinese chinese_8267532_1448:
    old "I appreciate your kindness."
    new "我感激你的善良。"

translate chinese chinese_1986248_1449:
    old "It's always good to have you here, come back anytime you want."
    new "有你在这里总是很好，想来就来。"

translate chinese chinese_3738095_1450:
    old "I'll do, bye bye."
    new "我挂了，拜拜。"

translate chinese chinese_9955193_1451:
    old "bye!"
    new "拜拜！"

translate chinese chinese_9167920_1452:
    old "Yes, I think I need to work on that, so I came to check if you are not busy."
    new "是的，我觉得我需要在这方面努力一下，所以来看看你有没有空。"

translate chinese chinese_5994039_1453:
    old "Oh no, I was about to start my training too so we can do it together."
    new "哦不，我正准备开始训练，我们可以一起做。"

translate chinese chinese_0699773_1454:
    old "Let's go to the training room to be more comfortable."
    new "我们去训练室里更舒服一点。"

translate chinese chinese_7027342_1455:
    old "What exercise would you like to train with?"
    new "你想练什么运动？"

translate chinese chinese_2778540_1456:
    old "Excellent choice, let's start to make the most out of this morning."
    new "excellent choice, 让我们开始充分利用这个早晨吧。"

translate chinese chinese_8973648_1457:
    old "Wonderful, I am full of energy today."
    new "太好了，我今天精力充沛。"

translate chinese chinese_1232218_1458:
    old "That was wonderful, please keep that enthusiasm, Yoga is better with such a great attitude like yours."
    new "太棒了，请继续保持这种热情，像你这样的态度练瑜伽效果会更好。"

translate chinese chinese_7166370_1459:
    old "Yes, I'm in a very good mood, every position helped me today to feel a lot better."
    new "是的，我心情很好，每个姿势今天都让我感觉好多了。"

translate chinese chinese_8892276_1460:
    old "We can continue training anytime you need..."
    new "我们可以随时继续训练..."

translate chinese chinese_8584638_1461:
    old "Sure, I will be coming more often to improve!"
    new "好的，我会常来提升自己的！"

translate chinese chinese_1799248_1462:
    old "I love to hear that."
    new "我很喜欢听这个。"

translate chinese chinese_7302198_1463:
    old "Thank you, it was a very incredible time today."
    new "谢谢，今天真是个难以忘怀的时光。"

translate chinese chinese_9646807_1464:
    old "You did a fantastic job, keep working hard."
    new "你干得非常棒，继续加油。"

translate chinese chinese_6462728_1465:
    old "I will!"
    new "我会的！"

translate chinese chinese_5848133_1466:
    old "Remember the lessons with Anastasia at the afternoon and also the tantric sessions at night, you have a lot of work to do."
    new "别忘了下午和阿纳斯塔西娅的课程，还有晚上的 tantra 课程，你有很多事情要做。"

translate chinese chinese_7249466_1467:
    old "Yes, I will be on time."
    new "好的，我会准时的。"

translate chinese chinese_4590573_1468:
    old "It was nice to see you."
    new "见到你真好。"

translate chinese chinese_4623879_1469:
    old "It was nice to see you too, see you later."
    new "见到你也很高兴，再见。"

translate chinese chinese_8202676_1470:
    old "Perfect, keep your energies for this afternoon."
    new "完美，下午留点精力。"

translate chinese chinese_5862481_1471:
    old "I sure will."
    new "我一定会的。"

translate chinese chinese_5982305_1472:
    old "Hello [pla], how are you?"
    new "你好[pla]，最近怎么样？"

translate chinese chinese_5516095_1473:
    old "Hi, Pretty good, how about you?"
    new "嗨，还不错，你呢？"

translate chinese chinese_8503906_1474:
    old "I'm great... So? Are you ready to have another tantric session?"
    new "我很好……那么，准备好再来一次 tantra 了吗？"

translate chinese chinese_9053511_1475:
    old "Oh no, thank you."
    new "哦不，谢谢。"

translate chinese chinese_8279523_1476:
    old "It's ok, remember you need to keep training so you can make the most out of you and your energy."
    new "没关系，记得你需要持续训练，这样才能充分发挥你的潜力和精力。"

translate chinese chinese_6428544_1477:
    old "I will, bye bye."
    new "我会的，拜拜。"

translate chinese chinese_5131946_1478:
    old "It's really important for you to continue these trainings so you can control your chakras better, you know this is a complete process you can't stop."
    new "你知道持续训练对你控制查克拉非常重要，这是一个完整的过程，不能停下来。"

translate chinese chinese_4156596_1479:
    old "Yes, you are right."
    new "是的，你说得对。"

translate chinese chinese_0979614_1480:
    old "Let's go to the room so we can start."
    new "我们去房间开始吧。"

translate chinese chinese_8249648_1481:
    old "What session did you like the most? Whichever it is we can repeat it."
    new "你最喜欢哪一段呢？不管哪一段，我们可以再来一次。"

translate chinese chinese_2020080_1482:
    old "Session 1"
    new "第一幕"

translate chinese chinese_8819694_1483:
    old "Good option, let's start to make the most out of this tantric session tonight."
    new "好主意，今晚我们就好好享受这个 tantra 体验吧。"

translate chinese chinese_6979198_1484:
    old "Perfect, I am very relaxed and ready to start the massage..."
    new "完美，我非常放松，准备好开始按摩了……"

translate chinese chinese_7060459_1485:
    old "Session 2"
    new "第二幕"

translate chinese chinese_5728377_1486:
    old "Session 3"
    new "第三章"

translate chinese chinese_6572676_1487:
    old "It has been a really good time, I can see your improvement with every single session, your energy has totally changed."
    new "这段时间真的很不错，我看得出来你每次都有进步，你的气场完全不一样了。"

translate chinese chinese_0964802_1488:
    old "I appreciate all that you say."
    new "我真的很感激你所说的每一句话。"

translate chinese chinese_4170159_1489:
    old "It's really amazing to see the progress you have achieved."
    new "看到你的进步真是令人惊讶。"

translate chinese chinese_7929949_1490:
    old "Any progress is thanks to you."
    new "任何进展都归功于你。"

translate chinese chinese_1756684_1491:
    old "We need to keep training to be better every time."
    new "我们需要继续训练，每次都要变得更好。"

translate chinese chinese_6630224_1492:
    old "I'm grateful with the universe for this wonderful opportunity, I hope we can meet more often, so you can improve the control over your chakras."
    new "我感激宇宙给我这个美妙的机会，希望我们可以经常见面，这样你可以更好地控制你的脉轮。"

translate chinese chinese_8492686_1493:
    old "Sure, I will come more often."
    new "好的，我会经常来的。"

translate chinese chinese_9941347_1494:
    old "It was nice to see, have a good one."
    new "看到你真好，祝你一切顺利。"

translate chinese chinese_8317268_1495:
    old "Same or you, bye!"
    new "一样或你，拜拜！"

translate chinese chinese_6294946_1496:
    old "Hi Anastasia, how is everything going?"
    new "嗨，阿纳斯塔西娅，一切都还好吗？"

translate chinese chinese_6868059_1497:
    old "Very good, been waiting all day for my training session."
    new "非常好，我等了一整天就为了这次训练。"

translate chinese chinese_2786669_1498:
    old "That is perfect! [pla] must be about to-"
    new "太完美了！[pla] 必须要做的事情是——"

translate chinese chinese_4030466_1499:
    old "Good afternoon guys."
    new "下午好大家。"

translate chinese chinese_8157115_1500:
    old "Hello [pla], how are you doing?"
    new "你好[pla]，最近怎么样？"

translate chinese chinese_0694258_1501:
    old "Pretty Fine! Hi Anastasia."
    new "还不错！嗨，阿纳斯塔西娅。"

translate chinese chinese_1153099_1502:
    old "Hi, I was waiting for you, glad to see you got here fine, I came ready to have a good session today."
    new "嗨，我在等你呢，看到你平安到了我很高兴，今天我准备好要来个愉快的环节了。"

translate chinese chinese_8035334_1503:
    old "Oh perfect!"
    new "哦，太好了！"

translate chinese chinese_9058062_1504:
    old "Well guys, I will leave alone so you can work hard, in case you need me, I will be here."
    new "好吧，我先不打扰你们工作了，有需要我的地方我就在这里。"

translate chinese chinese_4732346_1505:
    old "I appreciate that..."
    new "我明白……"

translate chinese chinese_6374257_1506:
    old "Let's go to the room, I need to train NOW..."
    new "我们去房间吧，我现在需要训练……"

translate chinese chinese_0248368_1507:
    old "What exercise are we going to do today?"
    new "今天我们做什么运动？"

translate chinese chinese_2472047_1508:
    old "Well, let me tell you..."
    new "好吧，让我告诉你……"

translate chinese chinese_6446261_1509:
    old "Exercise 1"
    new "练习1"

translate chinese chinese_8274724_1510:
    old "That's a great choice, I will do my best to ensure that you learn as much we can."
    new "这是个很好的选择，我会尽全力确保你能学到最多的东西。"

translate chinese chinese_1555750_1511:
    old "Sounds really good."
    new "听起来真不错。"

translate chinese chinese_3435607_1512:
    old "Exercise 2"
    new "练习2"

translate chinese chinese_5770858_1513:
    old "Exercise 3"
    new "练习3"

translate chinese chinese_0742689_1514:
    old "Exercise 4"
    new "练习4"

translate chinese chinese_4597554_1515:
    old "It was delicious, I really love these sessions."
    new "真好吃，我真的很喜欢这些时光。"

translate chinese chinese_7987475_1516:
    old "I am glad that you are satisfied, I am training hard so I can help you better."
    new "我很高兴你满意，我正在努力训练，以便能更好地帮助你。"

translate chinese chinese_9241266_1517:
    old "Please, don't stop training, your job is quite interesting."
    new "求你了，别停止训练，你的工作挺有意思的。"

translate chinese chinese_2804439_1518:
    old "Ok, I will continue working hard."
    new "好的，我会继续努力的。"

translate chinese chinese_1323875_1519:
    old "Perfect, because you are scheduled for me from now on."
    new "完美，因为从现在开始你都被我预订了。"

translate chinese chinese_5261408_1520:
    old "Ok, I hope to see you next session."
    new "好，希望下次再见。"

translate chinese chinese_6478538_1521:
    old "I'll be here ready for a new adventure."
    new "我会在这里准备好迎接新的冒险。"

translate chinese chinese_6647272_1522:
    old "I'll be ready!"
    new "我会准备好的！"

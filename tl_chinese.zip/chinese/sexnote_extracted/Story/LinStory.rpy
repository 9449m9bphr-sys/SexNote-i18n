# auto-tl Qwen Colab

translate chinese chinese_7787880_0:
    old "What was that?!"
    new "那是什么?!"

translate chinese chinese_9537752_1:
    old "I have no idea... I'm as surprised as you're right now."
    new "我真的不知道……我现在跟你一样惊讶。"

translate chinese chinese_5648317_2:
    old "I've been here for many years and it's the first time I hear such strange noise."
    new "我在这里待了很多年，还是第一次听到这么奇怪的声音。"

translate chinese chinese_4840200_3:
    old "God! Something strange is happening here... It's not normal for the lights to turn off and on by themselves all the time."
    new "天啊！这里发生了一些奇怪的事情……灯自己不停地亮灭根本就不是正常的。"

translate chinese chinese_5159501_4:
    old "I know... But... What could it be?"
    new "我知道……但是……会是什么呢？"

translate chinese chinese_9961739_5:
    old "A ghost! An evil presence, what else could it be?!"
    new "是鬼！一股邪恶的气息，还能是什么！"

translate chinese chinese_8654401_6:
    old "What!? Do you really think so?"
    new "什么！？你真的这么认为？"

translate chinese chinese_0321492_7:
    old "Of course! I'm not joking... So why do you think this youth is so rotten and lost? It's the devil's work!"
    new "当然了！我不是开玩笑……所以你认为这个年轻人为什么会这么堕落？这是魔鬼的工作！"

translate chinese chinese_2763275_8:
    old "Yes Mrs. Jones, you're right, must be that. I don't think it's an electricity issue."
    new "是的，琼斯夫人，您说得对，肯定是那样。我不认为是电力问题。"

translate chinese chinese_0484430_9:
    old "We gotta do something! Fuck... Jesus Christ!"
    new "我们必须做点什么！操... 基督啊！"

translate chinese chinese_7544778_10:
    old "Sister Grace! Watch your mouth, please!"
    new "格蕾丝姐姐！说话注意点！"

translate chinese chinese_3146174_11:
    old "Sorry Mrs. Jones, but this situation gets on my nerves, it's a ghost or a devil. We must perform an exorcism!."
    new "抱歉，琼斯夫人，但这种情况让我很生气，这是鬼魂或恶魔。我们必须进行驱魔！"

translate chinese chinese_2296446_12:
    old "We need the pries-"
    new "我们需要牧师"

translate chinese chinese_7287452_13:
    old "(I should use the Agamoto's eye and check if I can see something...)"
    new "（我应该用因戈尔的瞳看看能不能发现些什么……）"

translate chinese chinese_5892431_14:
    old "(Oh no! It's not a ghost... It's a shinigami!)"
    new "（哦不！那不是鬼...那是死神！）"

translate chinese chinese_0928000_15:
    old "(But... What happened to her!? Seems she is trapped or...)"
    new "（但是……她怎么了！？看起来像是被困住了或者……）"

translate chinese chinese_6251423_16:
    old "(She looks like she's in pain... And why does she fly like that??!)"
    new "(她看起来很痛苦……而且她为什么要那样飞？！)"

translate chinese chinese_7155953_17:
    old "(I gotta talk to this shinigami... This has something to do with the magic...)"
    new "（我得和这个死神谈谈……这和魔法有关……）"

translate chinese chinese_1796301_18:
    old "Hello, Oh! Sorry... I didn't want to interrupt..."
    new "喂，哦！对不起……我没想打断……"

translate chinese chinese_9654898_19:
    old "Oh! Hello [pla] don't worry, we were discussing something important but it's fine..."
    new "哦！你好[pla]不用担心，我们在讨论一些重要的事情，但是没关系……"

translate chinese chinese_7103997_20:
    old "Let me introduce you to our Sister Grace, she is the nun of the church."
    new "让我给你介绍一下我们的格蕾丝修女，她是教堂的修女。"

translate chinese chinese_4977704_21:
    old "Hi, nice to meet you."
    new "你好，很高兴见到你。"

translate chinese chinese_9903681_22:
    old "Hi [pla], nice to meet you to."
    new "你好[pla]，很高兴见到你。"

translate chinese chinese_9256001_23:
    old "I was just passing by to say hell-"
    new "我刚过来是想说声 hell-"

translate chinese chinese_2120327_24:
    old "Hun, something terrible is happening here... We might have the presence of a ghost in the church! Can you believe it?"
    new "亲爱的，这里出大事了……教堂里可能有鬼魂出现！你能相信吗？"

translate chinese chinese_0570515_25:
    old "Or a devil... Gosh darn I-!"
    new "或者是个恶魔……天啊我—！"

translate chinese chinese_9850186_26:
    old "Sister Grace, please!"
    new "格蕾丝姐姐，求你了！"

translate chinese chinese_2491657_27:
    old "Wait! Why do you think is a ghost?"
    new "等一下！你为什么觉得她是鬼？"

translate chinese chinese_6072635_28:
    old "There are strange noises, the lights turn off and on by themselves... And I'm a very spiritual person, if I'm telling you this is because it is what it is..."
    new "有奇怪的声音，灯自己亮了又灭……而且我很迷信，我告诉你这些是有原因的……"

translate chinese chinese_1523969_29:
    old "I- I believe you... But what are you gonna do?"
    new "我……我相信你……但是你打算怎么办？"

translate chinese chinese_4166581_30:
    old "An exorcism!"
    new "驱魔！"

translate chinese chinese_7543874_31:
    old "An exorcism?"
    new "驱魔？"

translate chinese chinese_0601778_32:
    old "(I have to talk to the girls... They should know what's happening.)"
    new "（我得跟她们谈谈……她们应该知道发生了什么。）"

translate chinese chinese_8763747_33:
    old "Hun, we don't want to scare you..."
    new "宝贝，我们不想吓到你..."

translate chinese chinese_6385283_34:
    old "No, I'm not... I gotta go now, I- I have some... Homework to do but I will pass by to see what happens."
    new "不，我没……我现在得走了，我还有些……作业要做，但我还是会过来看看情况的。"

translate chinese chinese_1348795_35:
    old "Perhaps I could help out... Dunno... It's very strange what's happening here."
    new "也许我可以帮忙……不知道……这里发生的事情很奇怪。"

translate chinese chinese_5991713_36:
    old "Alright, please take care of yourself."
    new "好吧，请你好好照顾自己。"

translate chinese chinese_7507128_37:
    old "You too Mrs. Jones... Goodbye..."
    new "你也再见了，琼斯夫人...再见..."

translate chinese chinese_8177572_38:
    old "Bye [pla], may God take care of your soul."
    new "再见[pla]，愿上帝保佑你的灵魂。"

translate chinese chinese_1734564_39:
    old "(What's happening here, this is weird, I gotta talk to the shinigamis.)"
    new "（这是怎么了，好诡异，我得去找死神谈谈。）"

translate chinese chinese_4344951_40:
    old "(Alright, I'm here... Fortunately there is no one here, I should use the Agamoto's eye and talk with them before someone comes.)"
    new "（好吧，我来了……好在周围没人，我应该先用阿戈尔之眼和他们谈谈，免得有人过来。）"

translate chinese chinese_4365799_41:
    old "Hey girls, I gotta tell you something!"
    new "嘿，姑娘们，我有件事要告诉你们！"

translate chinese chinese_0937121_42:
    old "Well, hello... We're actually fine and you?"
    new "嗯，嗨……我们挺好的，你呢？"

translate chinese chinese_3521510_43:
    old "Opss! Sorry... Hi hi..."
    new "哦豁！对不起...嘿嘿..."

translate chinese chinese_3263007_44:
    old "This is something important... I found a new Shinigami at the church..."
    new "这件事很重要……我在教堂里发现了一个新的死神……"

translate chinese chinese_2320129_45:
    old "I don't know what's happening but she's not fine for sure, she was flying around, looking drowsy..."
    new "我不知道发生了什么，但肯定不对劲，她一直在乱飞，看起来昏昏欲睡……"

translate chinese chinese_0708905_46:
    old "A new shinigami? And what do you mean by drowsy?"
    new "一个新的死神？还有你说的昏昏欲睡是什么意思？"

translate chinese chinese_3047605_47:
    old "Hmm, like very weak... Dunno! Do you guys have any idea of what's happening there?"
    new "嗯，感觉很弱……不知道！你们有没有什么头绪？"

translate chinese chinese_9475149_48:
    old "What? What was she doing in there?"
    new "什么？她在里面干什么？"

translate chinese chinese_4651450_49:
    old "Well, she was flying but it seemed she was stuck in there..."
    new "嗯，她本来是飞的，但看起来被困在里面了……"

translate chinese chinese_7636356_50:
    old "Hmm, alright... I may know what's happening."
    new "嗯，好吧……我可能知道发生了什么。"

translate chinese chinese_3049742_51:
    old "If what you said is happening, it might be that the shinigami is in trouble with her energy."
    new "如果你说的是真的，那可能是死神的能量出问题了。"

translate chinese chinese_3656222_52:
    old "I mean, there is no much energy around and she must be stuck in there. When there is not enough energy, we suffer the consequences."
    new "我的意思是，周围能量不多，她肯定被困在里面了。能量不足的话，我们会受到后果的。"

translate chinese chinese_5075299_53:
    old "Most likely she has just a couple of..."
    new "多半她只有几颗..."

translate chinese chinese_7889399_54:
    old "A couple of? Of what?"
    new "几件？什么几件？"

translate chinese chinese_0971711_55:
    old "A couple of days left..."
    new "就剩下几天了……"

translate chinese chinese_5009911_56:
    old "This is so sad... We all will die..."
    new "这真是太悲哀了……我们终究都会死……"

translate chinese chinese_3206591_57:
    old "All this is bullshit..."
    new "这一切都是 bullshit..."

translate chinese chinese_9872621_58:
    old "Girls! Wait a sec... We can still do something, we have [pla] on our side, he's gonna help us."
    new "女生们！等一下……我们还能做些什么，我们有[pla]帮忙，他会帮我们的。"

translate chinese chinese_3635170_59:
    old "But... But how? There is no more magic power around us... Tell me how?"
    new "但是……但是怎么做到的？我们周围已经没有魔力了……告诉我怎么做到的？"

translate chinese chinese_5941383_60:
    old "There has to be a way, just tell me what to do and I'll do it, we can't let her die."
    new "一定有办法，告诉我该怎么做，我会做到的，我们不能让她死。"

translate chinese chinese_3307428_61:
    old "[pla] just go and check how is her... Try to share some of your magic power with her."
    new "[pla] 去看看她的情况... 尝试分享一些你的魔力给她。"

translate chinese chinese_1656899_62:
    old "Sure, I'll... I'm so sorry all this is happening but don't worry, I'll help..."
    new "好吧，我……真的很抱歉你遇到这些事情，但别担心，我会帮忙的……"

translate chinese chinese_6854498_63:
    old " It's better if I go now... See you!"
    new "我现在走比较好……再见！"

translate chinese chinese_5686054_64:
    old "Good luck... And see you."
    new "祝你好运……再见了。"

translate chinese chinese_6405782_65:
    old "[pla] take care and don't forget we count on you."
    new "[pla] 保重，别忘了我们 counting on you."

translate chinese chinese_8534857_66:
    old "I know... I'll do my best!"
    new "我知道……我会尽力的！"

translate chinese chinese_5635693_67:
    old "Alright, we are going to start the exorcism."
    new "好吧，我们要开始驱魔了。"

translate chinese chinese_2549445_68:
    old "Lord, please protect our church, protect us from these evil presences that surround us."
    new "主啊，请保护我们的教堂，保护我们免受这些邪恶的存在包围。"

translate chinese chinese_5464354_69:
    old "Amen."
    new "阿门。"

translate chinese chinese_2219114_70:
    old "Our Father, who art in Heaven, hallowed be Thy name, Thy kingdom come..."
    new "我们在天上的父，愿人都尊你的名为圣，愿你的国降临..."

translate chinese chinese_1615231_71:
    old "Thy will be done, on earth as it is in Heaven. Give us this day our daily bread, and forgive us ou-"
    new "愿你的旨意行在地上，如同行在天上。赐给我们今日我们的日用面包，赦免我们的罪，就像我们也赦免那些辜负我们的人一样。"

translate chinese chinese_4060989_72:
    old "(There she is... Is the shinigami... She'll die if I don't do something!)"
    new "（就是她……那个死神……我要是不采取行动她就会死！）"

translate chinese chinese_0755886_73:
    old "Huh,  w- what's happening? "
    new "咦，这、这是怎么回事？"

translate chinese chinese_1604638_74:
    old "[pla]! Hi hun, is the ghost... The demon presence... It's taking over the church."
    new "[pla]！亲爱的，那个鬼魂……那个恶魔的气息……它正在接管教堂。"

translate chinese chinese_8300427_75:
    old "Hi [pla], Mrs. Jones is right, the situation is getting worse."
    new "嗨[pla]，琼斯夫人说得对，情况变得更糟了。"

translate chinese chinese_2031927_76:
    old "What? Why do you think is a demon?"
    new "什么？为什么你觉得她是恶魔？"

translate chinese chinese_4189232_77:
    old "Because it is! What else could it be if not a demon, a ghost!?"
    new "因为就是啊！如果不是妖魔鬼怪还能是什么！"

translate chinese chinese_6877207_78:
    old "It is hun... We know that, just look at the lights, everything is a mess here because of that."
    new "是那个家伙搞的……我们知道，看看这些灯光，这里的一切都因为他变得一团糟。"

translate chinese chinese_2563568_79:
    old "(If I don't do something quickly, she will probably die.)"
    new "（如果我不赶紧做点什么，她可能会死。）"

translate chinese chinese_1112994_80:
    old "Ehmm... I'm sorry to contradict you but the presence we have right now in this church is not malignant at all, I'm sure of that."
    new "嗯……不好意思反驳你，但是我们现在在这座教堂里的存在完全不是恶意的，我敢肯定。"

translate chinese chinese_5305997_81:
    old "What? What are you saying? If you're so sure, prove it!"
    new "什么？你在说什么？如果你这么确定，就证明给我看！"

translate chinese chinese_6862930_82:
    old "W- Well... I can do it! Take a look at the lights."
    new "嗯……我可以的！看看这些灯光。"

translate chinese chinese_6235307_83:
    old "I'll tell the spirit to move to the right and the lights on that side will start to fade, if this happens you'll see that this spirit has good intentions."
    new "我会让那个灵体向右移动，那边的灯光会开始变暗，如果这样的话，你会看到这个灵体是怀好意的。"

translate chinese chinese_3574170_84:
    old "Hmm, let's see."
    new "嗯，让我想想。"

translate chinese chinese_1920129_85:
    old "Spirit! Listen to me... We know we can help you as you can help us as well, please move to the right side and let us know by using the lights..."
    new "精神体！听我说……我们知道我们可以帮助你，你也可以帮助我们，请移到右边，用灯光告诉我们……"

translate chinese chinese_0166260_86:
    old "My God! He did it! The lights were fading..."
    new "天啊！他真做了！灯光在渐渐消失……"

translate chinese chinese_1924370_87:
    old "Spirit! Thanks! We saw it, you may now come back to your place."
    new "精神点！谢谢！我们已经看到了，你现在可以回去了。"

translate chinese chinese_7415725_88:
    old "[pla]! You were right... But how, how did you know it!?"
    new "[pla]！你说对了……但是你怎么知道的！？"

translate chinese chinese_5438515_89:
    old "I simply knew it, I can feel the creature's energy and I know it's good... There is nothing bad within it."
    new "我就是知道，我能感受到那生物的能量，我知道它是好的……里面没有任何坏的东西。"

translate chinese chinese_0371944_90:
    old "I'm surprised..."
    new "我没想到……"

translate chinese chinese_1845195_91:
    old "Son, we see you're right, this spirit actually listens to you and does accordingly but what does it want? What can we do?"
    new "儿子，我们看得出来你是对的，这个灵确实听你的指挥，但它想要什么？我们能做些什么？"

translate chinese chinese_9284652_92:
    old "Well, I thin-"
    new "嗯，我觉"

translate chinese chinese_2513516_93:
    old "What's the fuss about? Granma what's happening here?"
    new "干嘛这么激动？奶奶，这里发生什么事了？"

translate chinese chinese_9711810_94:
    old "Hi darling! It's a ghost-"
    new "亲爱的！是个鬼——"

translate chinese chinese_0734969_95:
    old "Oh really! Shut up, please! You're talking nonsense."
    new "哦真的！闭嘴吧！你在胡说八道。"

translate chinese chinese_8558406_96:
    old "It's true! There is an evil presence here..."
    new "是真的！这里有个邪恶的存在..."

translate chinese chinese_5527073_97:
    old "Sister Grace I wasn't talking to you, please don't be rude... I can't deal with nosy people."
    new "格蕾丝姐姐，我没跟你说话，请不要插嘴……我讨厌多管闲事的人。"

translate chinese chinese_2161151_98:
    old "What's happening Billie? BILLIE!?"
    new "发生什么事了，比莉？比莉！？"

translate chinese chinese_1949456_99:
    old "Nooo! Billie, wake up!! What's happening!? Someone help me, please!"
    new "不要啊！比莉，醒醒！！发生什么事了！？有人帮帮我吧！"

translate chinese chinese_9422296_100:
    old "Oh God, please help us."
    new "哦上帝，求你帮帮我们。"

translate chinese chinese_2085803_101:
    old "Calm down everybody...!"
    new "大家冷静点...!"

translate chinese chinese_0716337_102:
    old "I believe in God, the Father Almighty, Creator of Heaven and earth; and in Jesus Christ, His only Son, Our Lord..."
    new "我信上帝，全能的父，天地的创造者；也信耶稣基督，他的独生子，我们的主……"

translate chinese chinese_0431076_103:
    old "Father Morgan?"
    new "莫甘神父？"

translate chinese chinese_4509595_104:
    old "It's important to keep praying for Billie."
    new "为比莉祈祷很重要。"

translate chinese chinese_3114852_105:
    old "Let's pra-"
    new "我们来pra-"

translate chinese chinese_3304716_106:
    old "Noo! Father Morgan, take her to the hospital with Mrs. Jones, I'll take care of the church..."
    new "不要！摩根神父，带着她和琼斯夫人去医院，我来处理教堂的事..."

translate chinese chinese_4928595_107:
    old "Yes, let's go now... She has to be checked by a doctor."
    new "好的，我们现在就去吧……她必须让医生检查一下。"

translate chinese chinese_1346976_108:
    old "Sister Grace, please take care of the church, call me if anything... Ok?"
    new "格蕾丝姐姐，请照顾好教堂，如果有任何事情就给我打电话，好吗？"

translate chinese chinese_6085302_109:
    old "Wow that was... Weird..."
    new "哇，那真是……奇怪……"

translate chinese chinese_6440023_110:
    old "I hope Mrs. Jones's granddaughter is fine."
    new "希望琼斯太太的孙女没事。"

translate chinese chinese_5845164_111:
    old "Yeah, me too."
    new "是的，我也是。"

translate chinese chinese_5160432_112:
    old "Wait a minute, the lights are not flashing! The ghost is gone!"
    new "等一下，灯没闪！鬼不见了！"

translate chinese chinese_1576052_113:
    old "W- what? (Oh shit, what happened with the shinigami?)"
    new "什、什么？（哦shit，那个死神发生了什么事？）"

translate chinese chinese_4088551_114:
    old "You are right... I can't see anything either"
    new "你说得对……我也什么都没看到"

translate chinese chinese_8493267_115:
    old "(Oh no... It means she... d- died.)"
    new "（哦不……这意味着她……死、死了。）"

translate chinese chinese_8972119_116:
    old "And it was because of you! Thank you for your help."
    new "而且这都是因为你！谢谢你的帮助。"

translate chinese chinese_3105833_117:
    old "Yeah... It was because of me... (It was my fault...)"
    new "嗯……是因为我……（是我的错……）"

translate chinese chinese_1491208_118:
    old "I'm really impressed, don't know which kind of spiritual connection you have."
    new "真是印象深刻，不知道你们有什么样的心灵连接。"

translate chinese chinese_4567344_119:
    old "It was as if you were communicating with something higher... Something that we cannot see, something beyond our comprehension, perhaps divine."
    new "那感觉就像你在与某种更高层次的东西交流……某种我们看不见的东西，超越我们的理解范畴，或许可以说是神明。"

translate chinese chinese_0553707_120:
    old "Hmm yeah... Something like that"
    new "嗯，是啊……差不多就是那样"

translate chinese chinese_1637524_121:
    old "(Argh! I didn't save her... I'm completely useless...) "
    new "（啊！我没救到她……我完全没用……)"

translate chinese chinese_0040811_122:
    old "You're definitely closer to the divine spirit than even Father Morgan..."
    new "你肯定比摩根父亲更接近那股神灵……"

translate chinese chinese_0670602_123:
    old "I better go home, goodbye Sister Grace."
    new "我还是回家吧，再见格蕾丝姐姐。"

translate chinese chinese_0033176_124:
    old "Wait [pla]!..."
    new "等一下[pla]！..."

translate chinese chinese_0382506_125:
    old "Good morning darling, someone is looking for you..."
    new "亲爱的，早上好，有人找你……"

translate chinese chinese_3113548_126:
    old "Looking for me?... Who's that?"
    new "找我吗？……那是谁？"

translate chinese chinese_7682704_127:
    old "Two women... An old lady and a nun, where do you know them from?"
    new "两个女人……一个老奶奶和一个修女，你从哪里认识她们的？"

translate chinese chinese_6987261_128:
    old "Ahh ok! Hmm... They're from the church, you know I have been there quite a few times..."
    new "啊好吧！嗯……他们是从教堂来的，你知道我去了好几次……"

translate chinese chinese_8578967_129:
    old "I see... Well, they're waiting, go to see what they need, honey."
    new "我明白了……好吧，他们还在等着呢，去看看他们需要什么吧，亲爱的。"

translate chinese chinese_4724339_130:
    old "Sure! Thanks [mo1]."
    new "好啊！谢谢[mo1]。"

translate chinese chinese_9775713_131:
    old "Hi dear, I'm so sorry to bother you but you're the only one who can help us..."
    new "亲爱的，真的很抱歉打扰你，但你是唯一能帮我们的人……"

translate chinese chinese_3821250_132:
    old "Hi Mrs. Jones... Hmm, me? Why? What happened?"
    new "喂，琼斯夫人……嗯，我？为什么？发生什么事了？"

translate chinese chinese_6190442_133:
    old "Hi [pla], well... As I told you in the church, you were a great help and we think you could do something for Billie."
    new "嗨 [pla]，嗯……就像我在教堂里告诉你的，你帮了大忙，我们认为你能为 Billie 做些什么。"

translate chinese chinese_0546679_134:
    old "I'm so worried for my granddaughter, I'm afraid I'll lose her... Please help me!"
    new "我真的很担心我的孙女，害怕会失去她……请帮帮我！"

translate chinese chinese_4115669_135:
    old "I'm so sorry to hear she's not ok... But I don't know how could I help... I'm not a doctor."
    new "听说她不好受，我很难过……但我不知道该怎么帮忙……我又不是医生。"

translate chinese chinese_2551391_136:
    old "Well, we think this case is more related on a spiritual level, and you showed divine talents, so we hope that you could help us."
    new "好吧，我们认为这个案件更多是精神层面相关的，而你展现出了非凡的天赋，所以我们希望你能帮我们。"

translate chinese chinese_5024848_137:
    old "And what about the Father Morgan?"
    new "那么莫甘神父呢？"

translate chinese chinese_6646895_138:
    old "He already tried but didn't work and well... You're our only hope."
    new "他已经试过了但没用，而且……你是我们唯一的希望。"

translate chinese chinese_8205670_139:
    old "Alright, I'll try to help, but I'm not sure if I can-"
    new "好吧，我会尽量帮忙，但我不确定我能不能——"

translate chinese chinese_7767106_140:
    old "Thank you! We knew we can count on you."
    new "谢谢！我们知道你可以靠得住。"

translate chinese chinese_6705212_141:
    old "Come with us, we have no time to lose. "
    new "跟我们来，我们没时间浪费了。"

translate chinese chinese_2936907_142:
    old "[pla] look at her... She's suffering, please do something!"
    new "[pla] 看她……她很痛苦，请做点什么！"

translate chinese chinese_9502747_143:
    old "Hmm let's see..."
    new "嗯，让我想想..."

translate chinese chinese_4899611_144:
    old "(What? The shinigami isn't dead? What's happening here!)"
    new "（什么？死神还没死？这里发生了什么！）"

translate chinese chinese_5398076_145:
    old "Oh my God! She is crying black tears..."
    new "天啊！她在流黑色的泪..."

translate chinese chinese_7653136_146:
    old "Is there any way to help her [pla]?"
    new "有没有办法帮助她 [pla]？"

translate chinese chinese_5503214_147:
    old "(What the fuck is this?)"
    new "（这他妈是什么？）"

translate chinese chinese_4564899_148:
    old "[pla], are you fine? Are you in shock?"
    new "[pla]，你还好吗？是不是吓到了？"

translate chinese chinese_7786304_149:
    old "(I don't understand what's happening here. I have to talk with the shinigamis.)"
    new "（我不明白这里发生了什么。我得去和死神谈谈。）"

translate chinese chinese_5110323_150:
    old "Hmm... W- Well..."
    new "嗯……那个……"

translate chinese chinese_8826885_151:
    old "Hmm... I'll need to see her at night, right now I can't do anything but I'll come back later."
    new "嗯……我得晚上来找她，现在什么也做不了，我晚点再回来。"

translate chinese chinese_4424157_152:
    old "I need to... Prepare myself, if we do everything in the proper way, Billie will be fine soon."
    new "我需要……做好准备，如果我们一切按部就班来，比莉很快就会好起来的。"

translate chinese chinese_7987637_153:
    old "I have no words to thank you for everything you have done for us, her life is on your hands [pla]."
    new "我无法用言语来感谢你为我们所做的一切，她的生命掌握在你手中[pla]。"

translate chinese chinese_8084638_154:
    old "(My God! I really gotta do something for her and the shinigami.)"
    new "（天啊！我真的得为她和那个死神做点什么。）"

translate chinese chinese_1056675_155:
    old "Don't worry Mrs. Jones, she'll be fine. I better go now but I'll see you later."
    new "别担心，琼斯夫人，她会没事的。我得走了，回头见。"

translate chinese chinese_5752073_156:
    old "See you later as well Sister Grace."
    new "格蕾丝姐姐，下次见。"

translate chinese chinese_4455490_157:
    old "Thanks! We'll be waiting for you."
    new "谢谢！我们在等你。"

translate chinese chinese_7396601_158:
    old "Take care hun and thanks again."
    new "照顾好自己，再次感谢。"

translate chinese chinese_2036986_159:
    old "I saw the shinigami! Apparently she's inside Billie's body. I saw her!"
    new "我看到了死神！她好像在比莉的身体里。我看到她了！"

translate chinese chinese_5979520_160:
    old "I'm surprised with your manners... Hi [pla]!"
    new "我对你的礼貌感到惊讶……嗨，[pla]！"

translate chinese chinese_5784105_161:
    old "Hi hi! I know but this is important, I didn't expect to see her there..."
    new "嗨嗨！我知道但这很重要，我没想到会在那里见到她..."

translate chinese chinese_2043664_162:
    old "Wait a sec! Who's Billie? What are you talking about?"
    new "等一下！比莉是谁？你在说什么？"

translate chinese chinese_0923624_163:
    old "Alright! Billie is a girl from the church and it seems the shinigami is inside of her, I have no idea how,.. You tell me!"
    new "好吧！比莉是教堂来的女孩，看来死神就在她体内，我也不知道是怎么回事……你告诉我啊！"

translate chinese chinese_4121534_164:
    old "[pla], this is actually delicate, that shinigami is trapped in Billie's body, that happens when there is a lack of energy in the shinigami's body..."
    new "[pla]，这件事其实很微妙，那个死神被困在比莉的身体里了，这种情况发生在死神身体能量不足的时候……"

translate chinese chinese_5557904_165:
    old "That shinigami is having serious problems and getting into a human's body was the only option she had..."
    new "那个死神遇到了大问题，进入人类的身体是她唯一的办法……"

translate chinese chinese_8054956_166:
    old "She's struggling right now and the only way to get out of Billie's body is through an energy transfer since the body where she's now doesn't have any energy."
    new "她现在很挣扎，唯一的方法是通过能量转移来离开比莉的身体，因为现在的身体没有任何能量。"

translate chinese chinese_7800759_167:
    old "What? I thought she did possess her body... This makes more sense, that's why she's still there."
    new "什么？我以为她确实占据了她的身体……这样解释通顺多了，这就是为什么她还在那里。"

translate chinese chinese_8829215_168:
    old "Yes, she can't get out by herself. Billie's body doesn't have enough energy and as I'm telling you.. The only way to help them is through a powerful load of energy."
    new "是的，她自己出不来。Billie的身体没有足够的能量，就像我告诉你的……帮助他们的唯一方法就是提供大量的能量。"

translate chinese chinese_4059291_169:
    old "Are you willing to do that for them?"
    new "你愿意为他们做到那一步吗？"

translate chinese chinese_6063718_170:
    old "Yes, of course... I don't want anybody to die. How can I perform that energy transfer?"
    new "是的，当然了……我不希望任何人死去。我该怎么进行那个能量转移呢？"

translate chinese chinese_5067474_171:
    old "Come on! You already know how..."
    new "快点！你已经知道怎么..."

translate chinese chinese_0393061_172:
    old "Well, the only way to get energy I know is through s- sex-... A- are you saying that I have to have sex with Billie?"
    new "好吧，我知道获取能量的唯一方法就是通过……性行为……你的意思是我要和比莉发生关系吗？"

translate chinese chinese_3796400_173:
    old "You just said it... Yeah, it's the only way. Once the shinigami gets your energy, she'll be able to get out of Billie's body. There is no other way."
    new "你刚才说的……没错，这是唯一的方法。一旦死神得到了你的能量，她就能离开比莉的身体。没有其他办法了。"

translate chinese chinese_7935318_174:
    old "You're a young, strong and virile man. You're the only one able to help her."
    new "你年轻力壮，只有你能帮她。"

translate chinese chinese_8768489_175:
    old "I get it, I'll do whatever it takes to help her."
    new "我明白了，我会不惜一切代价帮助她。"

translate chinese chinese_4470601_176:
    old "Get ready for it! You'll have to last much longer since it will not be easy but we know you can do it."
    new "准备好吧！这不会容易，你得坚持更久，但我们知道你能行的。"

translate chinese chinese_6601303_177:
    old "I'll do my best for her to come and come out... See you girls."
    new "我会尽全力让她来，让她出现……再见了，姑娘们。"

translate chinese chinese_2808135_178:
    old "See you [pla], we're counting on you."
    new "[pla]，我们看好你了。"

translate chinese chinese_2292710_179:
    old "Please take care, [pla]"
    new "请多保重，[pla]"

translate chinese chinese_1156338_180:
    old "Hello Mrs. Jones, Sister Grace..."
    new "琼斯夫人，格蕾丝修女……"

translate chinese chinese_7192345_181:
    old "Hi dear, we're so glad you're here... Let's start now. Tell us how to help you."
    new "亲爱的，我们很高兴你来了……我们现在开始吧。告诉我们怎么帮助你。"

translate chinese chinese_9844265_182:
    old "Dear [pla], we are at your service, just tell us how we help you."
    new "亲爱的[pla]，我们随时为您服务，您说怎么帮您吧。"

translate chinese chinese_0637589_183:
    old "We trust you and the gifts that the Lord has given you, please help my Billie."
    new "我们相信你和上帝赐予你的能力，请帮帮我比利。"

translate chinese chinese_7959090_184:
    old "(They can't be here... I gotta say something for them to go out...)"
    new "（他们不能在这里……我得说点什么让他们出去……）"

translate chinese chinese_5033263_185:
    old "Tell us! Tell us hun!"
    new "告诉我们！快说嘛亲爱的！"

translate chinese chinese_2254421_186:
    old "Are you ok? What's happening? Why don't we start now?"
    new "你还好吗？发生什么事了？我们现在开始吧？"

translate chinese chinese_7154587_187:
    old "Yes, n- no. I- I mean, I'll start now but you can't be here, this is an important ritual that I must do alone."
    new "好，不——我不敢。我的意思是，我现在开始，但你不能在这里，这是我必须独自完成的重要仪式。"

translate chinese chinese_2577936_188:
    old "Alone? Why? We could assist you with our presence and prayers."
    new "独自一人？为什么？我们可以陪在你身边为你祈祷。"

translate chinese chinese_7070560_189:
    old "Hmm... Because, it's how it should be, could be dangerous for you."
    new "嗯……因为，这样比较合适，对你来说可能会有危险。"

translate chinese chinese_1926448_190:
    old "I don't think you're prepared to see what I'll do..."
    new "我觉得你还没准备好看我要做什么……"

translate chinese chinese_0658315_191:
    old "Billie? Billie, do you hear me?"
    new "比莉？比莉，你听到我说话了吗？"

translate chinese chinese_8437753_192:
    old "Gulp... is tha-?"
    new "吞咽...那是-?"

translate chinese chinese_4680485_193:
    old "My Godness! Billie spoke! Let's get out of here. He knows what he's doing."
    new "天啊！比莉说话了！我们赶紧走吧。他知道他在做什么。"

translate chinese chinese_0189732_194:
    old "Please leave me alone with her, we can't waste more time."
    new "请让我们单独待一会儿，我们没时间浪费了。"

translate chinese chinese_3529085_195:
    old "I- I n- need h- help."
    new "我- 我需- 需要帮- 帮助。"

translate chinese chinese_8515350_196:
    old "Call us if you need anything, [pla]."
    new "需要什么就联系我们，[pla]。"

translate chinese chinese_0453072_197:
    old "Alright, how I'm gonna do this?"
    new "好吧，我该怎么来办这件事？"

translate chinese chinese_7421984_198:
    old "Shinigami? Billie?"
    new "死神？比莉？"

translate chinese chinese_6865101_199:
    old "Y- You're here! P- please help me to get out of her, I- I'm trapped."
    new "你、你在这里！求、求你帮我出去，我、我被困住了。"

translate chinese chinese_6785137_200:
    old "I know... You know the only way is through an energy transfer process, right?"
    new "我知道……你知道唯一的方法是通过能量转移过程，对吧？"

translate chinese chinese_3785597_201:
    old "Y- Yes, please hurry up! I- I'll die if we don't do it."
    new "好、好的，请快点！再不动手我就完蛋了。"

translate chinese chinese_8438874_202:
    old "We'll need to have s- sex, well... You know it's how it's called."
    new "我们需要做那个……你知道的，就是那个事。"

translate chinese chinese_3325717_203:
    old "Shoot! C- Can you simply do it!? I already know what you're saying. I need you to do it now!"
    new "见鬼！C- 你能直接做吗！？我已经知道你要说什么了。我现在就需要你去做！"

translate chinese chinese_1848490_204:
    old "No! No, I was just saying..."
    new "不！我不是说..."

translate chinese chinese_6011447_205:
    old "But I shouldn't have sex with this girl, I don't even know her."
    new "但我不能和这个女孩发生关系，我甚至不认识她。"

translate chinese chinese_6645044_206:
    old "W- what you are going to do is share a magical power with me the shinigami... Don't overthink it. "
    new "你、你要做的事情是和我这个死神分享魔力……别想太多。"

translate chinese chinese_1186851_207:
    old "I need you to free me now... Do it..."
    new "我现在需要你放了我……这么做……"

translate chinese chinese_6992003_208:
    old "[pla]!?"
    new "[pla]!?"

translate chinese chinese_8629434_209:
    old "My God! What's going on here? What did you do to Billie?"
    new "天啊！这里发生了什么？你对比莉做了什么？"

translate chinese chinese_6556553_210:
    old "(Oh no! Now what?!)"
    new "（哦不！现在怎么办？）"

translate chinese chinese_6880396_211:
    old "[pla]? Is this part of the ritual you had planned to perform? I don't understand..."
    new "[pla]？这是你计划进行的仪式的一部分吗？我不明白……"

translate chinese chinese_4857740_212:
    old "(Damn it! What should I say?)"
    new "（该死！我该说什么？）"

translate chinese chinese_9335015_213:
    old "Grandma? Sister Grace? Where am I?... What happened?"
    new "奶奶？格蕾丝姐姐？我在哪儿？……发生了什么？"

translate chinese chinese_2727579_214:
    old "Someone tell me what happened to me? Why am I naked and sweating?"
    new "有人告诉我发生了什么吗？我为什么光着身子还一身汗？"

translate chinese chinese_5384478_215:
    old "Well! She looks much better now..."
    new "嗯！她现在看起来好多了..."

translate chinese chinese_6363243_216:
    old "My God, thanks! She's back!"
    new "天啊，谢谢！她回来了！"

translate chinese chinese_1882294_217:
    old "Huhh, what is going on?"
    new "huhh，这是怎么了？"

translate chinese chinese_5935544_218:
    old "We know you must be feeling so confused about everything..."
    new "我们知道你一定对这一切感到很困惑……"

translate chinese chinese_1599194_219:
    old "Your body was possessed by a spirit, but [pla] helped us perform a ritual and now you're back, you're fine now... "
    new "你的身体被 spirits 附身了，但 [pla] 帮我们做了一个仪式，你现在回来了，现在没事了……"

translate chinese chinese_5056309_220:
    old "What? My body... Possessed? What the fuck?"
    new "什么？我的身体……被附身了？靠什么？"

translate chinese chinese_1686693_221:
    old "Yes, it happened while we all were at the church, we don't know why but what matters now is that you're fine."
    new "是的，这件事发生在我们都在教堂的时候，我们不知道为什么，但现在重要的是你没事。"

translate chinese chinese_2665430_222:
    old "I guess that what [pla] did was part of the ritual..."
    new "我想[pla]做的那件事是仪式的一部分..."

translate chinese chinese_8384719_223:
    old "It was part of the ritual... It was the only way to help her out."
    new "这是仪式的一部分……这是唯一能帮到她的方法。"

translate chinese chinese_5395261_224:
    old "She seems to be totally fine now, I don't feel the spirit's presence anymore."
    new "她现在好像完全没事了，我再也没感觉到那股灵的存在。"

translate chinese chinese_2704421_225:
    old "She's fine now, I've cleaned her body from the spirit's presence... Now she's fine and healthy."
    new "她现在没事了，我已经把她身上的灵体痕迹清理干净了……现在她健康得很。"

translate chinese chinese_1829280_226:
    old "Don't worry my love, you're fine now. You just need to rest..."
    new "别担心，亲爱的，你现在没事了，just需要休息一下……"

translate chinese chinese_8606101_227:
    old "Huhh could you please let me go? I'm not breathing..."
    new "喂，你能放开我吗？我都快喘不过气了……"

translate chinese chinese_1143461_228:
    old "Ohh, sorry... It's just that we're so happy you're fine..."
    new "哦，对不起……只是看到你平安无事，我们真的很高兴……"

translate chinese chinese_0934027_229:
    old "Thanks [pla], you have been such a great help."
    new "谢谢[pla]，你帮了大忙了。"

translate chinese chinese_0845618_230:
    old "Yeah, thanks hun, I'm so grateful with you, you're a saint. Definitely God is inside of you..."
    new "是啊，谢谢你宝贝，我真的很感激你，你真是个圣人。上帝肯定住在你心里..."

translate chinese chinese_0886391_231:
    old "Don't worry, I just did what... God told me to do... I'll be here to help."
    new "别担心，我刚才只是做了……上帝让我做的事……我会在这里帮忙的。"

translate chinese chinese_6094631_232:
    old "I should be going now... It's been a very demanding ritual and I need to get some rest."
    new "我该走了……这个仪式很耗费精力，我需要休息一下。"

translate chinese chinese_1744226_233:
    old "Sure hun! Take care and thanks again!"
    new "当然了，亲爱的！保重，再次感谢！"

translate chinese chinese_0001909_234:
    old "Mmm... Thanks, see you Mrs. Jones... Bye Sister Grace."
    new "嗯……谢谢，再见了琼斯夫人……拜拜格蕾丝姐姐。"

translate chinese chinese_8878453_235:
    old "Bye dear [pla]"
    new "再见亲爱的[pla]"

translate chinese chinese_1800436_236:
    old "What was that naked guy doing here?"
    new "那个裸男来这里干什么？"

translate chinese chinese_4526128_237:
    old "How are you feeling? Are you ok?"
    new "你感觉怎么样？还好吗？"

translate chinese chinese_2198420_238:
    old "You know what... There are more shinigamis like you, we can help you."
    new "你知道吗……像你这样的死神还有很多，我们可以帮助你们。"

translate chinese chinese_3928671_239:
    old "Who are you? Why are you helping me?"
    new "你是谁？为什么要帮我？"

translate chinese chinese_4026027_240:
    old "Oh yes, sorry! I'm [pla], as I just told you... I know others like you."
    new "哦对，抱歉！我就是刚才告诉你的[pla]……我知道还有像你这样的其他人。"

translate chinese chinese_0952906_241:
    old "I see... Nice to meet you [pla], I'm Linett and well..."
    new "我明白了……很高兴见到你[pla]，我是林内特，嗯……"

translate chinese chinese_2432176_242:
    old "I feel better now but still weak, I don't have enough energy yet."
    new "我现在感觉好些了，但还是有点虚弱，还没有足够的力气。"

translate chinese chinese_8612531_243:
    old "Do you think we should continue with the energy transfer?"
    new "你觉得我们应该继续能量传输吗？"

translate chinese chinese_0590668_244:
    old "Hmm, we definitely have to continue the energy transfer, everything you shared with me was just to get out of that girl's body."
    new "嗯，我们必须继续能量转移，你告诉我的一切只是为了离开那个女孩的身体。"

translate chinese chinese_0395589_245:
    old "Hmm ok, no problem, let's do it."
    new "嗯好，没问题，咱们就這麼办。"

translate chinese chinese_4010539_246:
    old "Great! It's better if I suck you cock first, that will give me initial energy so that later you continue with the whole transfer."
    new "太好了！我先吸你的棒棒会给我初始能量，这样后面你可以继续完成整个传输。"

translate chinese chinese_2768513_247:
    old "Are you fine with that?"
    new "你对此没问题吧？"

translate chinese chinese_0137107_248:
    old "Yeah, I already told you I'm here to help and if I have to do that... I won't let you down."
    new "是的，我已经告诉你我来这里帮忙了，如果我必须这么做……我不会让你失望的。"

translate chinese chinese_6424572_249:
    old "That's the attitude we need... One more thing, could you please turn on the lights, I prefer to watch what I'm doing..."
    new "这就是我们需要的态度……还有一件事，你能把灯打开吗？我更喜欢看清楚我在做什么……"

translate chinese chinese_5324880_250:
    old "Ehmm... Sure."
    new "嗯……好啊。"

translate chinese chinese_8770640_251:
    old "So how are you now?"
    new "那你现在怎么样了？"

translate chinese chinese_9476432_252:
    old "Totally fine... You really did excellent!"
    new "完全没问题……你真的做得很好！"

translate chinese chinese_2136182_253:
    old "I'm glad you're fine now but... Are you gonna tell me what were you doing at the church? What was happening there?"
    new "我很高兴你现在没事了，但是……你打算告诉我你在教堂里干什么了吗？那里发生了什么？"

translate chinese chinese_9699927_254:
    old "Yes, sure! Well... Hmm."
    new "好啊……嗯。"

translate chinese chinese_2523018_255:
    old "I was trying to do a small ritual to achieve a reception of energy, for this it was required to deliver a lot of energy and I thought that with me it would have been enough, but it wasn't."
    new "我试着做一个小仪式来接收能量，这需要消耗大量能量，我以为我自己就够用了，但不够。"

translate chinese chinese_0979115_256:
    old "I tried to condense the magic power but since I didn't have enough energy, I got weak and got trapped in the church and later, in Billie's body."
    new "我试着压缩魔力，但因为能量不足，自己变得虚弱，被困在了教堂里，后来又进了比莉的身体。"

translate chinese chinese_2929253_257:
    old "We have to restore the power generator through a magic ritual and we only have one chance."
    new "我们必须通过一个魔法仪式来恢复发电器，而且只有一次机会。"

translate chinese chinese_8043686_258:
    old "So we gotta find the way to do it, tell me what to do and I'll do it... Now it's my responsibility as well."
    new "所以我们得找到办法，告诉我该怎么做，我会去做的……现在这也是我的责任了。"

translate chinese chinese_7827552_259:
    old "Are you sure? Are you sure you wanna help? You'll have to do lots of things."
    new "你确定吗？你确定要帮忙吗？你得做很多事情的。"

translate chinese chinese_5345834_260:
    old "Well, I've done some already and I'm willing to do more."
    new "嗯，我已经做了一些，而且我愿意做更多。"

translate chinese chinese_6543008_261:
    old "Ok... Well, the church is a special point and has an unique vibration that allows us to collect more energy."
    new "好吧……教堂是一个特殊地点，有一种独特的振动，能让我们收集更多的能量。"

translate chinese chinese_7332289_262:
    old "[pla], you gotta have sex with humans, so you will collect more energy and it should be done soon... We don't have much time."
    new "[pla]，你得和人类发生关系，这样才能收集更多能量，而且这事得赶紧办……我们没多少时间了。"

translate chinese chinese_9758538_263:
    old "What? Why do I need to have sex with humans? I mean, I get that it's the way to transfer energy but... Why not with the shinigamis?"
    new "什么？为什么我需要和人类发生性关系？我的意思是，我知道那是传递能量的方式，但是……为什么不是和死神呢？"

translate chinese chinese_5977368_264:
    old "It's dangerous, the shinigamis could get trapped... And you already know it's not easy to get out of a human's body. It's too risky at this point."
    new "这很危险，死神可能会被困住……而且你已经知道从人类身体里出来并不容易。现在太冒险了。"

translate chinese chinese_4034439_265:
    old "And on the other hand, we need people with a great concentration of power. You gotta look for at least two people who have this. Otherwise..."
    new "另一方面，我们需要权力集中度高的人。至少得找两个这样的人。否则……"

translate chinese chinese_5177159_266:
    old "It won't work..."
    new "这不管用……"

translate chinese chinese_9253103_267:
    old "Hmm... Ok, I get it..."
    new "嗯……好吧，我明白了……"

translate chinese chinese_5802003_268:
    old "(Actually I could try it with... The nun and Mrs. Jones would be perfect for that.)"
    new "（其实我可以试试和……修女和琼斯太太就perfect了。）"

translate chinese chinese_5389741_269:
    old "Are you already thinking on someone?"
    new "你已经在想某个人了？"

translate chinese chinese_7818007_270:
    old "Yeah, I do know two women... But It won't be easy... Sister Grace and Mrs. Jones, are part of the church's community and they liked me."
    new "是的，我确实认识两个女人……但不会那么容易……格蕾丝姐姐和琼斯夫人是教会社区的一部分，她们挺喜欢我的。"

translate chinese chinese_9274136_271:
    old "I'm not sure but I could definitely try..."
    new "我不确定，但肯定可以试试..."

translate chinese chinese_7944842_272:
    old "That's great! Do it... We have to try because it's our last chance, otherwise we'll have to wait until next year."
    new "太好了！去做吧……我们必须试试，因为这是我们的最后一次机会，否则就得等到明年了。"

translate chinese chinese_7408959_273:
    old "The energy that will emerge in the church will only increase in this period of the year, that's why it's so important."
    new "这一年中的这段时间，教堂里会出现的能量会不断增加，这就是为什么这么重要的原因。"

translate chinese chinese_1656109_274:
    old "Now you know what we've to do... I'll get some rest and you should as well, you'll be very busy the next few days."
    new "现在你知道我们要做什么了……我去休息一下，你也该休息下，接下来几天你会很忙的。"

translate chinese chinese_6475692_275:
    old "I can imagine... Ahh... I forgot to tell you, nice to meet you."
    new "我能想象……啊……忘了告诉你，很高兴见到你。"

translate chinese chinese_3276981_276:
    old "After all we've done you say that... Haha, good night [pla]"
    new "经过这一切你还这么说……哈哈，晚安[pla]"

translate chinese chinese_4666420_277:
    old "Good night, Linett."
    new "晚安，林内特。"

translate chinese chinese_3860459_278:
    old "Ritual"
    new "仪式"

translate chinese chinese_3067070_279:
    old "[pla] how's it going? Are you ready for the ritual?"
    new "[pla] 近况如何？你准备好仪式了吗？"

translate chinese chinese_6810232_280:
    old "I'm... I'm still preparing myself for it..."
    new "我……我还在为自己做准备……"

translate chinese chinese_7547421_281:
    old "Great! If you need anything, just let me know..."
    new "太好了！如果你需要什么，尽管告诉我..."

translate chinese chinese_6133492_282:
    old "Thanks, I'll... Now I should go..."
    new "谢谢，我……现在该走了……"

translate chinese chinese_7626183_283:
    old "Alright, see you!"
    new "好了，再见！"

translate chinese chinese_2645083_284:
    old "Share your magic power"
    new "分享你的魔力"

translate chinese chinese_2625877_285:
    old "Hey [pla], how are you?"
    new "嘿[pla]，最近怎么样？"

translate chinese chinese_8317550_286:
    old "I'm totally fine, I was wondering if you need me to share some magic power with you?"
    new "我完全没事，想问你需要我分点魔力给你吗？"

translate chinese chinese_7171271_287:
    old "You're such a kind man! Yes, I need some power... Please give it to me!"
    new "你真是个好人！是的，我需要一些力量……请给我吧！"

translate chinese chinese_0943181_288:
    old "Ask for magic power"
    new "请求魔力"

translate chinese chinese_5049148_289:
    old "Hey, how are you?"
    new "嘿，你好吗？"

translate chinese chinese_4049812_290:
    old "Hey [pla], I'm fine... What can I do for you?"
    new "嘿[pla]，我挺好的……有什么事吗？"

translate chinese chinese_5222215_291:
    old "I need some magic power... Could you please share some with me?"
    new "我需要一些魔法力量……能分给我一些吗？"

translate chinese chinese_6518145_292:
    old "I can always share my power with you..."
    new "我总是可以和你分享我的力量……"

translate chinese chinese_8662577_293:
    old "It was good as usual, I'm feeling much more energetic now."
    new "和平常一样棒，我现在感觉精神多了。"

translate chinese chinese_2813656_294:
    old "I'm glad I can always help!"
    new "能一直帮上忙真好！"

translate chinese chinese_3176486_295:
    old "See you [pla]"
    new "[pla]，再见"

translate chinese chinese_6221831_296:
    old "Thanks Linett, that was very energizing!"
    new "谢谢你，林内特，这真让人精神振奋！"

translate chinese chinese_5668691_297:
    old "It was... I'm here whenever you need me"
    new "是……我随时都在这里等你"

translate chinese chinese_3902404_298:
    old "Great! See you!"
    new "太好了！再见！"

translate chinese chinese_4889998_299:
    old "Hey [pla]! Long time no see. How are you?"
    new "嘿[pla]！好久不见，怎么样？"

translate chinese chinese_3952054_300:
    old "Woah! Linett! You scared me!"
    new "哇！林内特！你吓我一跳！"

translate chinese chinese_9500006_301:
    old "What are you doing here?"
    new "你在这里干什么？"

translate chinese chinese_6159313_302:
    old "I have to talk with you. It's important."
    new "我得和你谈谈。这事很重要。"

translate chinese chinese_0769246_303:
    old "So, I was waiting here for you to wake up."
    new "所以，我就在这里等你醒来。"

translate chinese chinese_5395317_304:
    old "Yeah well. That's a bit weird."
    new "嗯，那个有点奇怪。"

translate chinese chinese_9951099_305:
    old "But anyway, what did you wanna tell me?"
    new "不过话说回来，你想要告诉我什么？"

translate chinese chinese_4348011_306:
    old "It's about the ritual we did in the church, do you remember?"
    new "是关于我们在教堂做的仪式，你还记得吗？"

translate chinese chinese_6033851_307:
    old "Yeah I do, what about it?"
    new "是的，我就是怎么了？"

translate chinese chinese_4320515_308:
    old "Well, it's been a while since we tried it, and I think we should give it another go."
    new "嗯，我们有一段时间没试了，我觉得我们应该再试试。"

translate chinese chinese_0684623_309:
    old "After all, we still need those portals to generate magic again. And we're nearing the time of year to do it."
    new "毕竟，我们还需要那些传送门来重新生成魔法。而且我们快到那个时间了。"

translate chinese chinese_0286745_310:
    old "But it didn't work last time, right?"
    new "但是上次没成功，对吧？"

translate chinese chinese_9382750_311:
    old "It didn't."
    new "没有。"

translate chinese chinese_0389275_312:
    old "And to be honest. I don't really know why..."
    new "说实话，我也不知道为什么..."

translate chinese chinese_5337209_313:
    old "I've been thinking about it, but I can't come up with a full explanation."
    new "我一直在想这件事，但还是想不出一个完整的解释。"

translate chinese chinese_2812793_314:
    old "And you still want to try again? I mean... If we don't know what went wrong last time."
    new "你还想再试一次？我的意思是……如果我们不知道上次哪里出了问题。"

translate chinese chinese_3055313_315:
    old "How do we know this time it's going to work?"
    new "我们怎么知道这次一定能行？"

translate chinese chinese_4584102_316:
    old "About that, I said I didn't know but I do have some ideas as to what could make it work this time."
    new "关于这个，我说过我不知道，但我确实有一些想法，可以让这次成功。"

translate chinese chinese_8583740_317:
    old "An important part of what went wrong, is that we couldn't direct the magic power the way we needed it to go."
    new "问题的关键在于，我们无法按需要的方式引导魔力。"

translate chinese chinese_6508682_318:
    old "Direct? What do you mean?"
    new "直接？你是说什么？"

translate chinese chinese_1610553_319:
    old "Well, as you can see when you use the agamoto's eye."
    new "好吧，这你用八尺目之眼就能看到了。"

translate chinese chinese_6798789_320:
    old "Magic power is, in essence, a series of particles that human bodies are able to absorb."
    new "魔法力量本质上是一系列人体能够吸收的粒子。"

translate chinese chinese_3987957_321:
    old "However, human bodies are not designed to use and direct these particles into a specific point."
    new "然而，人体并没有设计成能够使用并把这些粒子导向特定点的。"

translate chinese chinese_3387112_322:
    old "So we weren't able to condense the magic in the place we needed to."
    new "所以我们没能把需要地方的魔法浓缩起来。"

translate chinese chinese_3302926_323:
    old "But we did in the church, you said that was where it had to be."
    new "但是在教堂里做的，你说那里是唯一的地方。"

translate chinese chinese_6854328_324:
    old "Yeah sure, but it couldn't be the whole church, it has to be a specific point where the breach can occur."
    new "嗯，没错，但不可能是整个教堂，肯定有个特定的地方会出问题。"

translate chinese chinese_7271793_325:
    old "Hmm, ok. So what do we have to do this time to make it happen?"
    new "嗯，好吧。那这次我们要做什么才能让这件事发生？"

translate chinese chinese_2955294_326:
    old "To be honest, I'm not sure yet. I have to figure it out soon."
    new "说实话，我还没确定。我得尽快想清楚。"

translate chinese chinese_3111945_327:
    old "However, it is true that the magic power is running out."
    new "不过，魔法力量确实正在耗尽。"

translate chinese chinese_9456739_328:
    old "That means we definitely have to do it again soon. And it has to be in the church."
    new "那意思是我们肯定得尽快再做一次。而且必须在教堂里。"

translate chinese chinese_4278159_329:
    old "So, while I figure it all out, you talk to the church people again, so we have access to it."
    new "所以，在我搞清楚这一切的同时，你再去跟那些教会的人谈谈，这样我们就能有使用权了。"

translate chinese chinese_1720530_330:
    old "Oh, damn, do we have to do it again with them?"
    new "哦，糟了，我们还得再和他们来一次吗？"

translate chinese chinese_9814213_331:
    old "Not necessarily... Let me solve this first."
    new "不一定……让我先解决这个问题。"

translate chinese chinese_7879570_332:
    old "For now just try and make sure we can use the church again when the moment comes, ok?"
    new "现在先确保我们在关键时刻能再使用这间教堂，好吗？"

translate chinese chinese_2442956_333:
    old "Sure, no problem, I'll handle it."
    new "行，没问题，我来处理。"

translate chinese chinese_4475895_334:
    old "Fine, then I'll keep in touch in case we need something else."
    new "好吧，那我保持联系以防还需要其他东西。"

translate chinese chinese_4163057_335:
    old "Oh my! What a wonderful surprise! Hello [pla]!"
    new "哦我的天！真是个美妙的惊喜！你好[pla]！"

translate chinese chinese_1410224_336:
    old "Hello Sister Grace, nice seeing you again."
    new "你好格蕾丝姐姐，又见到你真好。"

translate chinese chinese_6414903_337:
    old "And what do I owe this nice surprise?"
    new "那我这是欠了什么好运气呢？"

translate chinese chinese_2078444_338:
    old "I just wanted to say hello. And see if you need help with anything."
    new "我只是想打个招呼，看看你需不需要帮忙什么的。"

translate chinese chinese_0938844_339:
    old "You know, with decorating and stuff. I have some free time, so I figured I could help you."
    new "你知道的，装饰和其他事情。我有些空闲时间，所以想帮你一下。"

translate chinese chinese_7698631_340:
    old "Oh lord! You're sent again from the heavens, this is perfect."
    new "哦天啊！你这是从天而降的，真是太完美了。"

translate chinese chinese_4423867_341:
    old "Just today we were going to start with the Christmas decorations. So you came at the right moment."
    new "就在今天，我们本来打算开始布置圣诞装饰。所以你来得正好。"

translate chinese chinese_3449634_342:
    old "Oh really? That's perfect, I can help with whatever you need."
    new "哦真的吗？那太好了，我可以帮你处理任何事情。"

translate chinese chinese_3809519_343:
    old "Come with me, I'll show you."
    new "跟我来，我给你看。"

translate chinese chinese_7909334_344:
    old "[pla]! what a nice surprise!"
    new "[pla]！真是个惊喜！"

translate chinese chinese_8599503_345:
    old "Hi Mrs. Jones."
    new "琼斯夫人您好。"

translate chinese chinese_3518502_346:
    old "Hello darling, it's good to see you. And may I ask what brings you here?"
    new "亲爱的，见到你真好。不知道你这次来有什么事？"

translate chinese chinese_1537138_347:
    old "I just came to see if I could help with the Christmas decorations."
    new "我就是来看看能不能帮忙搞圣诞装饰。"

translate chinese chinese_0151981_348:
    old "Oh! Well, that's very nice of you. And you came just in time, we were about to start."
    new "哦！那真是太好了。而且你来得正好，我们正准备开始呢。"

translate chinese chinese_4380146_349:
    old "I was telling him just that, the Lord knew we needed his help and sent him to us."
    new "我就是这么跟他说的，主知道我们需要他的帮助，所以派他来了。"

translate chinese chinese_6573579_350:
    old "Well darling, let's not waste time, come with us, we'll show you what we need."
    new "亲爱的，别浪费时间了，跟我们来，我们会展示你需要什么。"

translate chinese chinese_0255300_351:
    old "We need your help with putting up the decorations for Christmas."
    new "我们需要你的帮助来布置圣诞装饰。"

translate chinese chinese_8777541_352:
    old "The decorations have to be put on the benches and up in the ceiling."
    new "装饰品得放在长椅上，还要挂在天花板上。"

translate chinese chinese_2381593_353:
    old "It has to be ready before Christmas eve for the members of the congregation to enjoy."
    new "它必须在圣诞前夕准备好，让教众们享受。"

translate chinese chinese_3167759_354:
    old "Sure thing, no problem."
    new "没问题，行。"

translate chinese chinese_8889982_355:
    old "Click all the marked spaces in time to decorate the church."
    new "按时点击所有标记的空间来装饰教堂。"

translate chinese chinese_9978586_356:
    old "Good morning Mrs. Jones, Sister Grace."
    new "早上好，琼斯夫人，格蕾丝修女。"

translate chinese chinese_4147946_357:
    old "Hello [pla], what a blessing from the lord seeing you today."
    new "你好[pla]，今天见到你真是上帝的恩赐。"

translate chinese chinese_5721673_358:
    old "Hello darling, how are you?"
    new "亲爱的，你好吗？"

translate chinese chinese_7609886_359:
    old "I'm fine thank you, I came to help you with the decorations again."
    new "我挺好的，谢谢。我是来帮你装饰的。"

translate chinese chinese_5612378_360:
    old "Oh thank you so much, you're of such great help."
    new "哦，真是太感谢你了，你帮了大忙了。"

translate chinese chinese_9837557_361:
    old "Sister Grace is right, it's nice that you came back today. Thank you darling."
    new "格蕾丝姐姐说得对，今天你能回来真好。谢谢你，亲爱的。"

translate chinese chinese_8739632_362:
    old "It's no problem."
    new "没问题。"

translate chinese chinese_7539413_363:
    old "I'll get to it then."
    new "那我就开始了。"

translate chinese chinese_3499443_364:
    old "Oh darling! You're such a good worker."
    new "哦亲爱的！你真是个工作狂。"

translate chinese chinese_2442861_365:
    old "I'm sure if you keep going at this pace you'll have it ready in no time."
    new "照这个进度下去，很快就能搞定了。"

translate chinese chinese_4349272_366:
    old "Having you do all this work really helps us a lot."
    new "让你做这么多真的帮了我们大忙。"

translate chinese chinese_6795609_367:
    old "I agree, the Lord graced us with this great help of yours."
    new "我同意，主赐予了我们你这样的大帮助。"

translate chinese chinese_7600047_368:
    old "Now, I'm sure you have some other things to do. So we won't keep you here anymore."
    new "好了，我知道你还有其他事情要忙，所以我们就不再耽误你了。"

translate chinese chinese_2199385_369:
    old "But make sure to come back soon."
    new "但记得要快点回来。"

translate chinese chinese_2886140_370:
    old "Sure, I'll be back soon and keep helping you."
    new "好的，我很快就会回来继续帮你。"

translate chinese chinese_2853843_371:
    old "Well... You didn't really do much today."
    new "嗯……你今天也没干什么啊。"

translate chinese chinese_4415456_372:
    old "But it's ok, it's a delicate thing to do. I'm sure you'll get the hang of it soon."
    new "但是没关系，这是一件很微妙的事情，我相信你会很快上手的。"

translate chinese chinese_3492319_373:
    old "That's right, the lord will illuminate you and you'll get better at it. Don't worry."
    new "没错，大人会指引你的，你会变得更强的。别担心。"

translate chinese chinese_5867237_374:
    old "Yeah... Sure."
    new "嗯……好吧。"

translate chinese chinese_5730627_375:
    old "I have a couple of things to do, so I think I'll get going, but I'll come back again and keep working."
    new "我还有几件事要处理，所以我想我现在就出发吧，但我会再回来继续工作的。"

translate chinese chinese_1958203_376:
    old "We know you will, don't worry."
    new "我们知道你会的，别担心。"

translate chinese chinese_5473046_377:
    old "Hey [pla]. I figured out what the problem was."
    new "嘿[pla]。我搞清楚问题出在哪里了。"

translate chinese chinese_5622051_378:
    old "Huh? Problem? Good morning by the way."
    new "huh? 出什么事了？顺便说一声，早上好。"

translate chinese chinese_8193551_379:
    old "Yeah, the problem we had with the ritual last time, I figured out what it was."
    new "嗯，上次仪式出现的问题，我已经搞清楚了。"

translate chinese chinese_0633219_380:
    old "Oh right, right. I remember."
    new "哦，对对，我想起来了。"

translate chinese chinese_1510368_381:
    old "So? What was it?"
    new "所以？是什么？"

translate chinese chinese_0424469_382:
    old "Well, I figured out that the problem last time, was that we did it with human bodies that couldn't retain as much magic power."
    new "好吧，我想通了，上次的问题是我们用的是人类的身体，它们无法储存那么多魔力。"

translate chinese chinese_9962849_383:
    old "Well, two of them couldn't."
    new "嗯，有两个不行。"

translate chinese chinese_6881010_384:
    old "What? What does that mean?"
    new "什么？那是什么意思？"

translate chinese chinese_6057507_385:
    old "Unlike us, you humans get old as time passes."
    new "不像我们，人类会随着时间的流逝变老。"

translate chinese chinese_9906050_386:
    old "This means that the older you get, the less magic power you're able to retain."
    new "这意味着你年纪越大，能保留的魔力就越少。"

translate chinese chinese_0360007_387:
    old "I believe that's the mistake we made last time."
    new "我相信那正是我们上次犯的错误。"

translate chinese chinese_5561435_388:
    old "So this time it has to be done with young people. They should be able to retain the amount of magic we need."
    new "所以这次必须用年轻人。他们应该能保留我们需要的魔法量。"

translate chinese chinese_7163742_389:
    old "Three young girls... I mean, damn, that would be a bit difficult."
    new "三个小女孩……我是说，那样确实有点难办。"

translate chinese chinese_7180255_390:
    old "Hmm... I suppose Billie would help again... and my only friends are Belle and Hinn..."
    new "嗯……我想比莉会再次帮忙……而我唯一的朋友就是贝儿和希恩……"

translate chinese chinese_5642849_391:
    old "What should I say? {i}\"Hey, do you want to be in an orgy at the church?\"{/i} "
    new "说什么好呢？{i}“嘿，你想在教堂里参加一场 orgy 吗？”{/i}"

translate chinese chinese_6415905_392:
    old "Well, you should definetly find a way... And I'm also working on the ritual..."
    new "嗯，你最好找一个办法……而且我也在准备那个仪式……"

translate chinese chinese_7993288_393:
    old "Directing the magic power to a specific point isn't as easy as I thought."
    new "将魔力导向一个特定点没我想的那么容易。"

translate chinese chinese_0878043_394:
    old "I still have to run some more tests."
    new "我还有很多测试要进行。"

translate chinese chinese_7363000_395:
    old "So you have time to figure it out."
    new "所以你有时间搞清楚了。"

translate chinese chinese_2845420_396:
    old "Ok, ok, I'll think about it."
    new "好啦好啦，我会考虑的。"

translate chinese chinese_6369853_397:
    old "Ok, then keep working on the church, I'll contact you as soon as I know exactly what we need."
    new "好的，那你继续处理教堂的事，我知道我们需要什么了就会马上联系你。"

translate chinese chinese_1959400_398:
    old "Ok, see you later then."
    new "好吧，那回头见。"

translate chinese chinese_1278624_399:
    old "Oh, hi [sis], how are you doing?"
    new "哦，嗨 [sis]，最近怎么样？"

translate chinese chinese_2880714_400:
    old "Oh, hi [sis], what are you doing up so late?"
    new "哦，嗨 [sis]，你怎么这么晚了还在啊？"

translate chinese chinese_0918494_401:
    old "I did it [pla]! It worked!"
    new "我做到了[pla]！成功了！"

translate chinese chinese_0172060_402:
    old "Huh? What do you mean it worked?"
    new "huh? 什么叫成功了？"

translate chinese chinese_4641969_403:
    old "Did you sell something expensive online?"
    new "你在网上卖了什么贵重的东西吗？"

translate chinese chinese_3391742_404:
    old "No, no, no, it's me Linett. Listen, use agamoto's eye."
    new "不，不，不，我是林nett。听着，使用阿戈摩托之眼。"

translate chinese chinese_1106071_405:
    old "Just do it, use the agamoto's eye."
    new "直接用吧，用那颗种子眼。"

translate chinese chinese_1967319_406:
    old "Wow! But, what the fuck? You're Linett? But... Why do you look like my [sisrel]?"
    new "哇！但是，靠什么啊？你是林内特？但是……为什么你看起来像我的[sisrel]？"

translate chinese chinese_3000886_407:
    old "Yeah! Remember that I said I still had to test something? I managed to do again what I did with your friend last time!"
    new "对！记得我说我还得测试些什么吗？我成功再次对你朋友上次做的事情了！"

translate chinese chinese_4492478_408:
    old "Wait what? What the fuck? You went into my [sisrel]'s body?"
    new "等下什么？什么情况？你进到我的[sisrel]的身体里了？"

translate chinese chinese_7211285_409:
    old "Yes! Yes! I did it. I managed to get insider her!"
    new "是的！是的！我做到了。我成功进入她内心了！"

translate chinese chinese_4172025_410:
    old "Woah! That's insane. But wait, come with me for a moment, we can't keep talking here."
    new "哇！这也太疯狂了。不过等等，跟我来一下，我们不能在这里继续说了。"

translate chinese chinese_3664714_411:
    old "Now, what the fuck are you doing in [sis]'s body?"
    new "现在，你他妈的干嘛穿上了[sis]的身体？"

translate chinese chinese_6016182_412:
    old "Well, I figured out that doing this would be necessary for the ritual, so I decided to try to do it again."
    new "我想通了，这样做对仪式是必要的，所以决定再试一次。"

translate chinese chinese_0087597_413:
    old "To see if I could do it better this time."
    new "看看这次能不能做得更好。"

translate chinese chinese_1115979_414:
    old "What do you mean to do it better?"
    new "什么叫做得更好？"

translate chinese chinese_4560682_415:
    old "Well, we don't usually get involved with humans."
    new "嗯，我们通常不跟人类打交道。"

translate chinese chinese_5005749_416:
    old "So, doing something like getting inside a person is a bit weird."
    new "所以，像进入一个人这样的事情有点奇怪。"

translate chinese chinese_9308919_417:
    old "I did it last time because, I was looking trying to survive by taking your friend as my host."
    new "上次我是因为想活下去，才把你朋友当成宿主。"

translate chinese chinese_9105110_418:
    old "So, I was almost dead that time..."
    new "所以，那次我差点就挂了……"

translate chinese chinese_2126099_419:
    old "Ok... But why did you do it again?"
    new "好吧……但是你为什么又要这么做？"

translate chinese chinese_3668582_420:
    old "Well, I thought that if I did it at will, and at full strength, maybe it would be different."
    new "嗯，我想如果我随意做，并且全力去做，也许会有所不同。"

translate chinese chinese_5340482_421:
    old "That I could do it with a lot more control."
    new "我可以做得更有控制些。"

translate chinese chinese_7393113_422:
    old "And it worked! See how well I can control her?! There's not even a little bit of interference."
    new "成功了！看我多能控制她？根本没有任何干扰。"

translate chinese chinese_0344463_423:
    old "Yeah, yeah, congrats. But you have to get out of [sis]‘s body."
    new "好吧，恭喜你。但是你得离开[sis]的身体。"

translate chinese chinese_6644926_424:
    old "And you have to do it now!"
    new "而且你现在就必须做！"

translate chinese chinese_5784116_425:
    old "Well, you see... We may have a little of a problem there."
    new "嗯，你看……我们可能有点小问题。"

translate chinese chinese_5084357_426:
    old "What do you mean a problem?"
    new "什么叫有问题？"

translate chinese chinese_9345178_427:
    old "Remember what you did last time to get me out of your friend's body?"
    new "还记得上次你是怎么把我从你朋友的身体里弄出来的吗？"

translate chinese chinese_8623908_428:
    old "Hmm, not really...  Why?"
    new "嗯，不太……为什么？"

translate chinese chinese_6434323_429:
    old "The thing is that to be able to get out of your [sisrel] ‘s body I'm going to need a recharge of magical power."
    new "问题是，要想从你的[sisrel]的身体里出来，我需要补充魔法力量。"

translate chinese chinese_7579567_430:
    old "That's the only way to undo my ‘possession'."
    new "那是唯一能解除我的“附身”的方法。"

translate chinese chinese_5029235_431:
    old "Oh fuck, so I have to have sex with you in [sis] ‘s body?"
    new "哦操，所以我要用[sis]的身体和你发生关系？"

translate chinese chinese_6272189_432:
    old "Yes, that's right. You got it. Come on, let's do it."
    new "对，就是这样。你说得没错。来吧，咱们就這麼办。"

translate chinese chinese_6381438_433:
    old "W- wait a minute. What about [sis]? Won't she know about it? Isn't she going to feel anything?"
    new "等一下。[sis]怎么办？她不会知道吗？不会有感觉吗？"

translate chinese chinese_6966221_434:
    old "No, she won't feel or remember anything."
    new "不，她不会有任何感觉或记忆的。"

translate chinese chinese_6490833_435:
    old "How do you know?"
    new "你怎么知道的？"

translate chinese chinese_2025115_436:
    old "Well, I did it with a different spell, one that grants me total control of this body."
    new "好吧，我是用不同的咒语做到的，一个能让我完全控制这具身体的咒语。"

translate chinese chinese_1649007_437:
    old "The host is unconscious. And she will be until I leave the body."
    new "主机已经昏迷了。而且她会一直这样直到我离开这具身体。"

translate chinese chinese_8857324_438:
    old "Besides, this time I'm at full magic power, so I have no trouble controlling her completely."
    new "而且这次我的魔法力量满值，完全控制她毫无问题。"

translate chinese chinese_3967370_439:
    old "I still don't get why you had to do this. I mean, what is all of this for?"
    new "我还不明白你为什么要这么做。我是说，这一切都是为了什么？"

translate chinese chinese_4972600_440:
    old "This is for the ritual I mean, with all the control this method gives to me, I'll have no trouble directing the magic power."
    new "我说的是仪式，这种方法给我这么大的控制权，引导魔力对我来说没什么问题。"

translate chinese chinese_8951080_441:
    old "Ohhh... I get it."
    new "哦……我明白了。"

translate chinese chinese_2823541_442:
    old "Now, give me the magic power I need to get out of this body."
    new "现在，给我需要的魔力，让我脱离这具身体。"

translate chinese chinese_0584818_443:
    old "Are you sure [sis] won't feel it?"
    new "你确定[sis]不会感觉到吗？"

translate chinese chinese_9835059_444:
    old "What if she wakes up during it?"
    new "要是她在过程中醒了怎么办？"

translate chinese chinese_1668253_445:
    old "That's not possible, even after I get out, it's going to take a while before she wakes up."
    new "那不可能，就算我出来了，她也要过一阵才能醒过来。"

translate chinese chinese_9912647_446:
    old "Hmmm, ok."
    new "嗯，好吧。"

translate chinese chinese_3867699_447:
    old "Your cock is impressive, this size and thickness."
    new "你的棒棒很 impressive，这么大这么粗。"

translate chinese chinese_2077939_448:
    old "No wonder you never have trouble supplying me with magic."
    new "怪不得你总是能给我提供魔法供应而不愁。"

translate chinese chinese_2303054_449:
    old "We have to do this quick. Someone could hear us."
    new "我们必须快点。有人可能会听到。"

translate chinese chinese_4515321_450:
    old "Oh, relax, remember you have to cum for me to come out of you [sisrel]‘s body."
    new "哦，放松点，记得你要射了我才能从[sisrel]的身体里出来。"

translate chinese chinese_7656202_451:
    old "And you won't if you're not enjoying it."
    new "如果你不喜欢，就不会这样了。"

translate chinese chinese_7346189_452:
    old "Ok, ok, I'll do it."
    new "好啦好啦，我做就是了。"

translate chinese chinese_3441414_453:
    old "I might do it again just to experience that."
    new "我可能会再做一次，就为了体验那种感觉。"

translate chinese chinese_4243691_454:
    old "Haha, very funny."
    new "哈哈，真逗。"

translate chinese chinese_2970025_455:
    old "We should go to my bedroom."
    new "我们应该去我的卧室。"

translate chinese chinese_4201760_456:
    old "But first help me clean her and put her in bed."
    new "但是先帮我把她清理干净然后扶她上床。"

translate chinese chinese_5260578_457:
    old "She's not gonna wake up if we move her. Right?"
    new "如果我们移动她，她不会醒来的，对吧？"

translate chinese chinese_0999381_458:
    old "No, she's passed out."
    new "不，她昏过去了。"

translate chinese chinese_3241193_459:
    old "And won't wake up for a while, so it's ok."
    new "而且过一阵子才醒，所以没关系。"

translate chinese chinese_8647791_460:
    old "This is perfect, now we can finally do the whole ritual succesfully!"
    new "这太完美了，现在我们终于可以成功完成整个仪式了！"

translate chinese chinese_1730118_461:
    old "That's good and all, but that experiment was a little too much."
    new "那样挺好的，但那个实验有点过头了。"

translate chinese chinese_1206212_462:
    old "Well, it worked and that's all that matters."
    new "反正成功了，这才是最重要的。"

translate chinese chinese_6847650_463:
    old "What's most important right now is that there's another problem to solve."
    new "当前最重要的是还有一个问题需要解决。"

translate chinese chinese_0031930_464:
    old "What another one? What else do we need?"
    new "还有另一个？我们还需要什么？"

translate chinese chinese_7325450_465:
    old "Well, we need the actual people."
    new "好吧，我们需要实际的人选。"

translate chinese chinese_6586506_466:
    old "Remember, I did this experiment because we need to control the magic in humans?"
    new "记得吗，我做这个实验是因为我们需要控制人体内的魔法？"

translate chinese chinese_8760756_467:
    old "Oh, you're right, I forgot."
    new "哦，你说得对，我忘了。"

translate chinese chinese_6909296_468:
    old "The problem is that we need three people, and I can't get inside all three of them."
    new "问题是我们需要三个人，而我不能同时进入三个人的体内。"

translate chinese chinese_0665138_469:
    old "Oh, actually, I hadn't told you, but I know three other shinigamis."
    new "哦，其实我还没告诉你，我还认识三个其他的死神。"

translate chinese chinese_8060419_470:
    old "Maybe we could explain the situation to them, and ask for their help."
    new "maybe 我们可以向他们解释情况，并请求他们的帮助。"

translate chinese chinese_6156536_471:
    old "Hmm... It could be, but I would need to train them to do it."
    new "嗯……可能是这样，但我得训练她们才行。"

translate chinese chinese_9945684_472:
    old "I think it will be fine if we talk to them."
    new "我觉得如果我们和他们谈谈应该没问题。"

translate chinese chinese_0814638_473:
    old "Ok, so let's go, where are they?"
    new "好吧，那我们走吧，他们在哪儿？"

translate chinese chinese_4552851_474:
    old "Woah, you wanna go now?"
    new "哇，你现在想走？"

translate chinese chinese_3389321_475:
    old "Listen, it's pretty late and I haven't slept at all."
    new "听着，已经很晚了，我一点都没睡。"

translate chinese chinese_1966974_476:
    old "What about if we go tomorrow morning?"
    new "要不明天早上我们去怎么样？"

translate chinese chinese_3301426_477:
    old "Hmm, ok, I'll come here tomorrow morning then."
    new "嗯，好的，那我明天早上过来吧。"

translate chinese chinese_9279775_478:
    old "Ok, see you tomorrow."
    new "好的，明天见。"

translate chinese chinese_0099238_479:
    old "Hey, are you ready to go talk with the other shinigamies?"
    new "嘿，你准备好去和其他死神谈谈了吗？"

translate chinese chinese_5546721_480:
    old "What? Now? I just woke up!"
    new "什么？现在？我刚起床！"

translate chinese chinese_6596562_481:
    old "What!? Remember I have to teach them how to do the spell. It's not as simple as when you use magic."
    new "什么！？别忘了我得教他们怎么施法。这可不是你使用魔法那么简单。"

translate chinese chinese_9379752_482:
    old "It takes time to learn a spell, and we don't even know if they're going to say yes."
    new "学会一个咒语需要时间，而且我们还不知道他们会不会同意。"

translate chinese chinese_8572515_483:
    old "So we have to go now!"
    new "所以我们现在就得走！"

translate chinese chinese_9357686_484:
    old "Ok, ok, I get it."
    new "好啦好啦，我懂了。"

translate chinese chinese_8911749_485:
    old "Let's go then."
    new "那我们走吧。"

translate chinese chinese_7293339_486:
    old "Hey girls."
    new "嘿，姑娘们。"

translate chinese chinese_5462471_487:
    old "Hello."
    new "喂。"

translate chinese chinese_3263407_488:
    old "Oh! [pla] is here! Hiiii, it's been a while since I've seen you!"
    new "哦！[pla]来了！嗨，好长时间不见啦！"

translate chinese chinese_1220450_489:
    old "Hello, how have you been?"
    new "你好，最近怎么样？"

translate chinese chinese_2083707_490:
    old "Fine, fine, thank you."
    new "好，好，谢谢。"

translate chinese chinese_4449617_491:
    old "Hey, remember that a while ago, I told you about a shinigami that was inside one of my friends?"
    new "嘿，还记得我之前跟你说过的，我一个朋友体内有个死神的事吗？"

translate chinese chinese_4681953_492:
    old "And I asked you for advice about what to do?"
    new "而且我还向你请教该怎么办？"

translate chinese chinese_4001447_493:
    old "Indeed, we remember, what about it?"
    new "确实，我们记得，那又怎样？"

translate chinese chinese_1486598_494:
    old "Well, I wanted to introduce her to you, so I brought her with me."
    new "嗯，我想把她介绍给你，所以就带她来了。"

translate chinese chinese_8815251_495:
    old "Everyone, this is Linett."
    new "大家，这是林内特。"

translate chinese chinese_7065319_496:
    old "Hello, nice meeting you."
    new "你好，很高兴见到你。"

translate chinese chinese_7619077_497:
    old "Umm... eh, hi."
    new "嗯……呃，嗨。"

translate chinese chinese_6093980_498:
    old "I understand your surprise, I didn't expect to see other shinigamis in this town."
    new "我理解你的惊讶，我也没想到会在这个镇上看到其他的死神。"

translate chinese chinese_2647858_499:
    old "But I have to talk to you about something important."
    new "但是有些重要的事情我得和你谈谈。"

translate chinese chinese_5501517_500:
    old "I think you should listen to her, it's about the magic power."
    new "我觉得你应该听她的，这关乎魔力。"

translate chinese chinese_2937092_501:
    old "The magic power? What about it?"
    new "魔法力量？怎么了？"

translate chinese chinese_7197414_502:
    old "I don't know about you. But if [pla] says it's ok, I'll listen."
    new "我不清楚你的想法。但如果[pla]说没问题，我就听他的。"

translate chinese chinese_6980987_503:
    old "Hmm, this could be important."
    new "嗯，这可能很重要。"

translate chinese chinese_1668831_504:
    old "Some time ago I discovered that in this town's church used to be a place with a strong connection with the magic world."
    new "有一段时间，我发现这个镇上的教堂曾经是一个与魔法世界联系紧密的地方。"

translate chinese chinese_5697048_505:
    old "So? What does it matter now that the magic world doesn't exist?"
    new "所以呢？既然魔法世界不存在了，这又有什么关系？"

translate chinese chinese_2642026_506:
    old "Well... That connection remains even if the magic world is gone."
    new "嗯……那个联系即使魔法世界消失了也依然存在。"

translate chinese chinese_1556421_507:
    old "Oh! Really?"
    new "哦！真的吗？"

translate chinese chinese_3625650_508:
    old "And what does it mean?"
    new "那是什么意思？"

translate chinese chinese_2513873_509:
    old "It means that is a perfect place to set a magic power generating point."
    new "这意味着这里是设置一个魔法能量生成点的完美地点。"

translate chinese chinese_3957109_510:
    old "Wow, really? That's amazing."
    new "哇，真的吗？太棒了。"

translate chinese chinese_8324109_511:
    old "That's right, and me, along with [pla], did a ritual to trying to create that magic point."
    new "没错，我和[pla]做了一个仪式，试图创造那个魔法点。"

translate chinese chinese_5277533_512:
    old "But it went wrong. However, I believe I've solved the issue and I would like to try again."
    new "但是出了问题。不过我相信我已经解决了这个问题，想再试一次。"

translate chinese chinese_1596538_513:
    old "Actually, that's why we came here today. We need your help with the ritual."
    new "实际上，这就是我们今天来这里的原因。我们需要你在仪式上帮忙。"

translate chinese chinese_9440058_514:
    old "Our help? We don't even know you... or your intentions..."
    new "我们的帮助？我们甚至不认识你……或者你的意图……"

translate chinese chinese_1097496_515:
    old "She's right, this is the first time any of us has heard anything like this."
    new "她说得对，这是我们第一次听到这样的事情。"

translate chinese chinese_8825933_516:
    old "I know it sounds strange, this is actually new for me too."
    new "我知道这听起来很奇怪，对我来说这也是新鲜事。"

translate chinese chinese_4028934_517:
    old "But we need to try it because the magic power is running out."
    new "但是我们必须试试，因为魔力快用完了。"

translate chinese chinese_9035581_518:
    old "And if we don't do anything we're just going to die. I gain nothing by lying to you."
    new "如果我们什么都不做，我们就只能等死了。我骗你也没啥好处。"

translate chinese chinese_8219362_519:
    old "Ok and what do you propose we do?"
    new "好，那你提议我们该怎么办？"

translate chinese chinese_5557693_520:
    old "For starters, we're going to need three young humans. [pla] will handle that."
    new "首先，我们需要三个年轻人。[pla]会负责这件事。"

translate chinese chinese_4848713_521:
    old "The idea is that we use them in a ritual in which we will create a breach point, and pour magic into it to force it to open."
    new "我们的想法是，在仪式中使用它们，制造一个裂缝点，并向其中灌注魔法，迫使它打开。"

translate chinese chinese_4711125_522:
    old "I see, I get the idea."
    new "我明白了。"

translate chinese chinese_4208476_523:
    old "But I see some difficulties with the plan."
    new "但我觉得这个计划有些困难。"

translate chinese chinese_8760159_524:
    old "For starters, humans can't control magic. And even if they could, how would we make them do that?"
    new "说起来，人类是无法控制魔法的。就算能控制，我们又怎么让他们做到呢？"

translate chinese chinese_2627296_525:
    old "Well, the idea is that we're going to get inside them, and control the magic from within."
    new "好吧，想法是我们要进入它们体内，从内部控制魔法。"

translate chinese chinese_8404214_526:
    old "What? We're going to be trapped!"
    new "什么？我们要被困住了！"

translate chinese chinese_3932059_527:
    old "That's right, it's pretty weird to think doing that on purpose, is really dangerous."
    new "没错，故意那样做真的很危险，想想都觉得很奇怪。"

translate chinese chinese_5268941_528:
    old "Isn't this just a trap to imprison us in human bodies?"
    new "这不就是个陷阱，让我们被困在人类身体里吗？"

translate chinese chinese_1217345_529:
    old "What!? What would I get from that?"
    new "什么！？我从中能得到什么？"

translate chinese chinese_5976126_530:
    old "A- actually, we discovered that there is a way to do it safely."
    new "其、其实，我们发现有一种安全的方法可以做到。"

translate chinese chinese_2618275_531:
    old "Exactly, I've been running some tests, and found a way in which it can be done."
    new "没错，我做了一些测试，找到了一个可行的方法。"

translate chinese chinese_3339306_532:
    old "I've created a spell with which we can get inside a human body and control it at will."
    new "我创造了一个咒语，可以让我们进入人体并随意控制它。"

translate chinese chinese_8491338_533:
    old "And we can do it without being on the verge of death."
    new "而且我们可以不用濒临死亡就能做到。"

translate chinese chinese_9676732_534:
    old "I had never heard of something like that, are you sure about what you're saying?"
    new "我从来没听说过这样的事，你确定你说的是真的吗？"

translate chinese chinese_1551328_535:
    old "She's telling the truth, I helped her."
    new "她在说真话，我帮过她。"

translate chinese chinese_3829538_536:
    old "If you'll let me show, I can teach you how to do it."
    new "如果你让我示范，我可以教你怎么做。"

translate chinese chinese_0572163_537:
    old "I can't believe you're actually considering listening to this!"
    new "真不敢相信你居然在考虑听这个！"

translate chinese chinese_8961692_538:
    old "I don't really trust you. But I do [pla], if he says it's ok maybe we should listen."
    new "我其实不太信任你。但我确实[pla]，如果他说没问题，也许我们应该听听。"

translate chinese chinese_7494770_539:
    old "Ok, we'll hear what you have to say, but if you don't convince us, we won't follow you."
    new "好吧，我们会听你说什么，但如果你说服不了我们，我们就不会跟着你。"

translate chinese chinese_7104687_540:
    old "Ok, I know after listening you will understand."
    new "好的，我知道听了之后你会明白的。"

translate chinese chinese_2817777_541:
    old "But wait, before I start. Don't have to keep working in the church? Let me this to me and you keep working on the church."
    new "但是等一下，在我开始之前。你不用继续在教堂工作吗？让我来做这件事，你继续在教堂工作吧。"

translate chinese chinese_0131865_542:
    old "We are running out of time and need that place ready for the ritual."
    new "我们时间不多了，需要把那个地方准备好进行仪式。"

translate chinese chinese_1176667_543:
    old "Oh right."
    new "哦，对了。"

translate chinese chinese_8202153_544:
    old "Ok, ok I'll keep working on the church, while you explain everything to them. See you later guys."
    new "好吧好吧，我继续修教堂，你给他们解释清楚。一会儿见。"

translate chinese chinese_6929525_545:
    old "Great, we'll talk later at home."
    new "好的，回家再聊。"

translate chinese chinese_4974446_546:
    old "See you [pla]!"
    new "[pla]，再见！"

translate chinese chinese_3144412_547:
    old "Hey there [pla]!"
    new "嘿，[pla]！"

translate chinese chinese_9096795_548:
    old "Oh, hey, did you manage to convince them?"
    new "哦，嘿，你搞定他们了吗？"

translate chinese chinese_8320601_549:
    old "Yeah, I did, they didn't believe me at first."
    new "是的，我确实说了，他们最开始不信我。"

translate chinese chinese_1063546_550:
    old "Especially that Mildret one. She was a lot of trouble."
    new "特别是那个Mildret，她真是够呛。"

translate chinese chinese_7555740_551:
    old "But once I showed them the spell they understood."
    new "但一旦我给他们看了那个咒语，他们就明白了。"

translate chinese chinese_7572633_552:
    old "You showed them? But how did you get out of the host?"
    new "你给他们看了？但是你怎么从宿主身上出来的？"

translate chinese chinese_9069402_553:
    old "I didn't perform it. I only told them how it was done."
    new "我没做过，我只是告诉他们怎么做而已。"

translate chinese chinese_9928218_554:
    old "All shinigami know and understand magic, so they knew I was telling them the truth."
    new "所有死神都懂魔法，所以他们知道我说的是真话。"

translate chinese chinese_8313640_555:
    old "Oh, I see, nice."
    new "哦，我明白了，不错。"

translate chinese chinese_1755898_556:
    old "Everything's fine now, right? I mean, now you all know the spell."
    new "现在一切都好了吧？我是说，你们现在都知道那个咒语了。"

translate chinese chinese_5451339_557:
    old "And I'm taking care of the church, so we're almost ready."
    new "我在负责教堂的事情，所以差不多准备好了。"

translate chinese chinese_9622435_558:
    old "Hmm, not really. It sounds ok, but it's a very complicated spell. And I merely explained it to them...."
    new "嗯，也不是。听起来还行，但这个咒语非常复杂。我只是给他们解释了一下……"

translate chinese chinese_2404362_559:
    old "If we want to make sure that everything goes perfect the day of the ritual, they're going to need practice."
    new "如果我们想确保仪式当天一切完美，他们需要练习。"

translate chinese chinese_0929366_560:
    old "Ok, so, what do you need me to do now?"
    new "好吧，那现在你需要我做什么？"

translate chinese chinese_6165033_561:
    old "For now it would be really good if you can decide on the three humans we're using for the ritual."
    new "目前最好你能决定出我们仪式要用的三个普通人。"

translate chinese chinese_8546415_562:
    old "You said you had some people in mind."
    new "你说你有几个人选。"

translate chinese chinese_9487478_563:
    old "Y- yeah I did. But I- I don't know..."
    new "嗯，我是做了。但是……我不知道……"

translate chinese chinese_8537250_564:
    old "I already told you there's no need to worry."
    new "我already告诉过你不用担心。"

translate chinese chinese_1480624_565:
    old "Remember, they'll be unconscious during the ritual and after."
    new "记得，他们在仪式过程中和之后都会昏迷的。"

translate chinese chinese_7714413_566:
    old "And all the time we'll be controlling them."
    new "而我们会一直控制他们。"

translate chinese chinese_4148003_567:
    old "So, you shouldn't be this worried."
    new "所以，你不用这么担心。"

translate chinese chinese_7538137_568:
    old "Hmm ok, if that's how it is. Then, I guess I know who could work..."
    new "嗯好吧，如果是这样的话。那么，我想我知道谁可以胜任..."

translate chinese chinese_9286356_569:
    old "Great, then tomorrow morning we'll go see the shinigamis again and would be perfect to test the spell with one of them."
    new "太好了，那明天早上我们就再去见一下死神，用其中一个来测试咒语就完美了。"

translate chinese chinese_2003989_570:
    old "So that they can practice before the ritual."
    new "这样他们在仪式前就可以练习了。"

translate chinese chinese_6670804_571:
    old "You mean with a human?"
    new "你是说和人类吗？"

translate chinese chinese_0342349_572:
    old "Yes [pla], we have to test the spell before the ritual with the girls."
    new "是的 [pla]，我们在和女孩们进行仪式之前必须先测试这个咒语。"

translate chinese chinese_3924851_573:
    old "We need to be sure everything is going to work."
    new "我们需要确保一切都能顺利进行。"

translate chinese chinese_2462672_574:
    old "Hmm... I guess you are right..."
    new "嗯……我想你是对的……"

translate chinese chinese_1251278_575:
    old "All right, everything is done, you better go to sleep because we have a lot to do tomorrow."
    new "好了，一切都搞定了，你最好去睡觉，因为明天有很多事情要做。"

translate chinese chinese_9078782_576:
    old "Ok, I'll see you tomorrow."
    new "好的，明天见。"

translate chinese chinese_1542868_577:
    old "Hey [pla], are you ready to go?"
    new "嘿[pla]，准备好了吗？"

translate chinese chinese_5613538_578:
    old "Oh, good morning, yeah sure, let's go."
    new "哦，早上好，行吧，我们走。"

translate chinese chinese_7254298_579:
    old "Hey girls, good morning."
    new "嘿，姑娘们，早上好。"

translate chinese chinese_6791860_580:
    old "Hello again."
    new "又见面了。"

translate chinese chinese_8927219_581:
    old "Hi, how are you today?"
    new "嗨，今天怎么样？"

translate chinese chinese_4479237_582:
    old "Hiii, good seeing you again."
    new "嗨，又见到你真好。"

translate chinese chinese_7729816_583:
    old "Listen, [pla] and I talked last night about the humans that are taking part in the ritual."
    new "听着，我和[pla]昨晚谈到了参加仪式的人类。"

translate chinese chinese_1364399_584:
    old "And he's told me that he already has three people in mind for it."
    new "而且他已经告诉我有三个人选了。"

translate chinese chinese_2656400_585:
    old "So we'll go and find them for you to practice the spell before the ritual."
    new "所以我们去找它们让你在仪式前练习这个咒语。"

translate chinese chinese_5433997_586:
    old "Just to make sure that you can handle the spell and control the host body."
    new "只是为了确保你能施放这个咒语并控制宿主体。"

translate chinese chinese_3812879_587:
    old "What? Now?... B- but I'm not ready... What if I can't get out?"
    new "什么？现在？... 我还没准备好... 如果我出不去怎么办？"

translate chinese chinese_8748594_588:
    old "Don't worry Devonne, We may practice more with you."
    new "别担心，德冯，我们可能会多和你练习一下。"

translate chinese chinese_5066763_589:
    old "Actually, I was thinking of starting with Gomory, I think she is ready."
    new "其实，我在想是不是可以从戈莫里开始，我觉得她已经准备好了。"

translate chinese chinese_9625091_590:
    old "Ok, it sounds fine."
    new "好的，听起来不错。"

translate chinese chinese_2462689_591:
    old "Yeah, it would be good to try it now."
    new "嗯，现在试试挺好的。"

translate chinese chinese_9236638_592:
    old "[pla], Gomory seemed to be the one that had a better grasp of the spell yesterday."
    new "[pla]，戈莫里昨天似乎对这个咒语掌握得更好一些。"

translate chinese chinese_5662044_593:
    old "So you and her go find her host, while I keep working with Mildret and Devonne."
    new "那你和她去找她的宿主，我继续和Mildret还有Devonne工作。"

translate chinese chinese_8465974_594:
    old "Ok, so what's the idea? What should we do?"
    new "好吧，那你的想法是什么？我们应该怎么做？"

translate chinese chinese_4643344_595:
    old "You just have to take her to where her host is."
    new "你只要把她带到她的宿主那里就行了。"

translate chinese chinese_4826764_596:
    old "And see that everything goes well while she performs the spell."
    new "确保她在施法期间一切顺利。"

translate chinese chinese_6918997_597:
    old "As long as you're with her there shouldn't be a problem."
    new "只要你和她在一起，应该就没问题。"

translate chinese chinese_3555130_598:
    old "Hmph, I see..."
    new "哼，我明白了……"

translate chinese chinese_5726268_599:
    old "Ok, I get it. Then let's go to where she is. Come with me Gomory."
    new "好吧，我明白了。那我们就去她那里吧。跟我来，Gomory。"

translate chinese chinese_0551660_600:
    old "Who is going to be my host?"
    new "谁会成为我的向导？"

translate chinese chinese_0249969_601:
    old "She's a friend of mine, her name is Belle, I think we should try with her first."
    new "她是我的朋友，叫贝尔，我觉得我们应该先试试她。"

translate chinese chinese_4584876_602:
    old "Ok, we found her. What do you need to get in her body?"
    new "好了，我们找到她了。你需要什么东西才能进入她的身体？"

translate chinese chinese_4781807_603:
    old "Not much really, all we need is for her to be relaxed for a moment, and I'll canalize the spell."
    new "其实也没多少，我们只需要让她放松一会儿，我就能引导咒语了。"

translate chinese chinese_8853589_604:
    old "Hmm, ok, so it should be fine if we're just talking, right?"
    new "嗯，好吧，如果我们只是聊天的话应该没问题吧？"

translate chinese chinese_7771390_605:
    old "That's right, it doesn't take more than a few seconds."
    new "没错，这不过几秒钟的事。"

translate chinese chinese_4678898_606:
    old "Ok, I think I got it. I'll go there and talk to her for a moment, you wait here for a minute."
    new "好的，我想我明白了。我去那边和她聊一会儿，你在这里等我一下。"

translate chinese chinese_4243014_607:
    old "Then you come close. And the person that you see me talking to it's who you do the spell on, ok?"
    new "那你靠近点。然后你看我聊天的对象就是你要施法的人，好吗？"

translate chinese chinese_9342385_608:
    old "That's very simple, sounds good, let's do it."
    new "那很简单，听起来不错，我们就这么办吧。"

translate chinese chinese_4213744_609:
    old "Ok, I'll there then."
    new "好的，我会去那里的。"

translate chinese chinese_1008390_610:
    old "Oh! [pla] Hi!"
    new "哦！[pla] 你好！"

translate chinese chinese_8733331_611:
    old "I'm ok. Hey listen, I wanted to talk to you about something Miss Mia said in class."
    new "我没事。嘿，听我说，我想和你谈谈米娅老师在课上说的一些事情。"

translate chinese chinese_8005553_612:
    old "Sure, tell me. What is it?"
    new "好吧，告诉我，是什么？"

translate chinese chinese_1182088_613:
    old "HA! Who do we have here? Piglet and the loser."
    new "哈！这是谁啊？小猪和那个输家。"

translate chinese chinese_8216255_614:
    old "What happened to your ears Piglet? Afraid they were talking too much attention from that flat nose?"
    new "你的耳朵怎么了，小猪？担心它们抢了那张扁鼻子的风头吗？"

translate chinese chinese_6257160_615:
    old "Oh for God's sake!"
    new "天啊！"

translate chinese chinese_0044753_616:
    old "Listen, dumbass, I'm not in the mood for your shit today! So fuck off!"
    new "听着，白痴，我今天没心情对付你这一套！所以滚蛋吧！"

translate chinese chinese_7976921_617:
    old "And what crawled up her that she's this angry?"
    new "她怎么了，这么生气？"

translate chinese chinese_7157253_618:
    old "Honestly, you can't say anything to people because they get their panties in a bunch."
    new "说实话，你根本就不能跟这些人说什么，他们一激动就乱了。"

translate chinese chinese_1233810_619:
    old "What are you talking about? You just insulted her!"
    new "你在说什么？你刚刚侮辱了她！"

translate chinese chinese_3189862_620:
    old "Don't you ever get tired of talking like that to people?"
    new "你不会厌倦这么跟人说话吗？"

translate chinese chinese_6912105_621:
    old "What, who do you think you're talking to?"
    new "喂，你到底在跟谁说话？"

translate chinese chinese_7135408_622:
    old "Listen loser, I don't care what you have to say, so why don't you get lost?"
    new "听着，输家，我根本不在乎你说什么，你为什么不滚蛋呢？"

translate chinese chinese_6789619_623:
    old "Yeah, whatever, who would want to deal with you?"
    new "yeah, 随便吧，谁愿意理你呢？"

translate chinese chinese_9920026_624:
    old "Oh no!"
    new "哦不！"

translate chinese chinese_2447839_625:
    old "Yeah! You shouldn't have messed with me you little brat!"
    new "没错！你这小鬼可别招惹我！"

translate chinese chinese_5328894_626:
    old "Wait! Wait! Stop!"
    new "等！等！停下来！"

translate chinese chinese_7778549_627:
    old "Stop? After you insulted me? You better be ready for what you have coming your way!"
    new "停？在我侮辱了你之后？你最好准备好迎接即将到来的一切！"

translate chinese chinese_3185966_628:
    old "No, no, no, no, it's not her, it's not her."
    new "不，不，不，不，不是她，不是她。"

translate chinese chinese_6738048_629:
    old "W- What??"
    new "什、什么？？"

translate chinese chinese_7657633_630:
    old "Ooh shit!"
    new "哦shit！"

translate chinese chinese_1456916_631:
    old "Damn, what do I do now? This wasn't supposed to happen!"
    new "妈的，现在怎么办？这根本不是计划内的！"

translate chinese chinese_4502529_632:
    old "Hey, I did it! It worked! Linett is a genius!"
    new "嘿，我做到了！成功了！林内特真是个天才！"

translate chinese chinese_8073135_633:
    old "Devonne? Is that you?"
    new "德冯？是你吗？"

translate chinese chinese_1428268_634:
    old "It is! It worked! We did it [pla]!"
    new "成功了！真的成功了！我们做到了，[pla]！"

translate chinese chinese_2703328_635:
    old "No, we didn't! You got the wrong person!"
    new "不，我们没有！你搞错人了！"

translate chinese chinese_4955581_636:
    old "It was supposed to be the other girl I was talking with!"
    new "我本来是想说另一个女孩的！"

translate chinese chinese_5115039_637:
    old "Well, you should have said something, I did what you told me to."
    new "那你应该说清楚啊，我可是按你说的做的。"

translate chinese chinese_2482382_638:
    old "I waited for a minute and get into the person I saw you talking with."
    new "我等了一分钟，然后接近了刚才看到你聊天的那个人。"

translate chinese chinese_5577010_639:
    old "Well, the point is you're in the wrong body. You're gonna have to get out of there."
    new "关键是，你进了错的身体。你得想办法出来。"

translate chinese chinese_9426012_640:
    old "Ok, but you know what's the only possible one way."
    new "好吧，但你知道只有一种可能的方式。"

translate chinese chinese_0570974_641:
    old "Ohhh right... Oh my God... I have to do it with Ruby... Fuck!"
    new "哦对了……天啊……我得和Ruby做……见鬼！"

translate chinese chinese_0737651_642:
    old "Well, it could be just a blowjob... it works too..."
    new "嗯，可能只是一个口交……这也有效……"

translate chinese chinese_3016012_643:
    old "I know, I know. Look, we can't do that here. So let's go somewhere else before anyone notices us speaking."
    new "我知道，我知道。看，我们在这里不能这么做。所以在有人注意到我们说话之前，我们去别的地方吧。"

translate chinese chinese_7449776_644:
    old "Hey Ruby, so here this is where you've been. Hey listen, I've been thinking about our..."
    new "嘿，Ruby，原来你在这儿。听我说，我一直在想我们……"

translate chinese chinese_9071081_645:
    old "And what do we have here? If it is the captain of the nerd club."
    new "这是谁啊？居然是学霸俱乐部的队长。"

translate chinese chinese_4361772_646:
    old "What are you doing here nerd? Looking for better company than your loser friends"
    new "你这书呆子来这里干吗？找比你那群失败朋友更好的伴儿吗？"

translate chinese chinese_6115841_647:
    old "Yeah, sure... That's right, I'm trying to become friends with Ruby. Right, Ruby?"
    new "嗯，好吧……没错，我正试着和Ruby成为朋友。对吧，Ruby？"

translate chinese chinese_7175737_648:
    old "Ohh... Yeah, that's right, he and I are very good friends heh."
    new "哦……对，他和我是非常好的朋友哈哈。"

translate chinese chinese_6811429_649:
    old "(Oh my God...)"
    new "（天啊……）"

translate chinese chinese_5717956_650:
    old "W- what? What are you saying ruby?"
    new "什、什么？你在说什么ruby？"

translate chinese chinese_5653949_651:
    old "Do you feel ok? Did this nerd do anything to you?"
    new "你还好吗？这个书呆子有没有对你做什么？"

translate chinese chinese_4228580_652:
    old "Hey, I haven't done anything."
    new "喂，我什么都没做。"

translate chinese chinese_2192292_653:
    old "We're just talking about homework... S- she wants me to do her homework..."
    new "我们只是在谈论作业……她想让我帮她做作业……"

translate chinese chinese_9327233_654:
    old "Is that true Ruby?"
    new "鲁比，这是真的吗？"

translate chinese chinese_6303400_655:
    old "Uhh, yes, yes! It's true, he's helping me with... Something."
    new "嗯，对，对！是真的，他在帮我处理……一些事情。"

translate chinese chinese_3633483_656:
    old "Anyway, I think we need to go look for some books. You know, for that homework... We better leave."
    new "总之，我觉得我们需要去找些书。你知道的，为了那作业……我们还是走吧。"

translate chinese chinese_1166887_657:
    old "Yeah! I think we need to leave."
    new "对！我觉得我们应该离开了。"

translate chinese chinese_5811465_658:
    old "Goodbye human friend! It was good to talk to you, I'll see you later."
    new "再见了人类朋友！和你聊天很愉快，回头见。"

translate chinese chinese_4644011_659:
    old "Ok, I think we'll be safe here. It's almost class time, nobody's going to come."
    new "好吧，我觉得这里应该安全。快上课了，没人会来的。"

translate chinese chinese_2543955_660:
    old "It's incredible, I have soo much control, I didn't know this was possible."
    new "太不可思议了，我有如此多的控制力，没想到这竟然可能。"

translate chinese chinese_3524517_661:
    old "So, you're feeling ok?"
    new "所以，你觉得还好吗？"

translate chinese chinese_5549100_662:
    old "That's right! I feel in complete control, it's almost as if this was my real body."
    new "没错！我感觉完全掌控了，几乎就像这是我的真实身体一样。"

translate chinese chinese_3163035_663:
    old "Ok, that's good. At least you didn't start twitching in the middle of the hallway, that would have given us up."
    new "好吧，这挺好的。至少你没有在走廊中间突然抽搐，那样我们就暴露了。"

translate chinese chinese_0840080_664:
    old "Which, by the way, you almost did when Olivia got there. Thank God she's not very smart."
    new "话说，奥利via到的时候，你差点就做到了。还好她不是很聪明。"

translate chinese chinese_9697924_665:
    old "Oh yes, who was that girl? She was friendly!"
    new "哦对，那个女孩是谁？她挺友好的！"

translate chinese chinese_3442583_666:
    old "Hmm, that's the last thing I would call her. She's the best friend of Ruby, the... Uhhh, owner of this body."
    new "嗯，那可是最后我会用来形容她的词。她是Ruby最好的朋友，而Ruby是……呃，这个身体的主人。"

translate chinese chinese_1743212_667:
    old "So that could have been a lot closer..."
    new "那差点就挨上了……"

translate chinese chinese_6223665_668:
    old "Well, this is the problem with using the wrong body."
    new "唉，这就是用错身体的问题了。"

translate chinese chinese_8258750_669:
    old "But anyway, can you leave that body before someone else notices how weird you're acting?"
    new "不过话说回来，在有人注意到你行为怪异之前，你能离开那具身体吗？"

translate chinese chinese_8155498_670:
    old "I want to get out, but I'm going to need your help."
    new "我想出去，但需要你的帮助。"

translate chinese chinese_3032085_671:
    old "Yeah, right, I remember..."
    new "是啊，我记得……"

translate chinese chinese_6954329_672:
    old "We need to do this quick."
    new "我们需要快点搞定这件事。"

translate chinese chinese_3803071_673:
    old "Ok, I've been waiting for this since I took over this body"
    new "好吧，自从接管这具身体我就一直在等这一刻"

translate chinese chinese_1319220_674:
    old "Well, I knew we had to do this for me to leave my host's body."
    new "好吧，我知道为了让我离开宿主的身体，我们必须这么做。"

translate chinese chinese_7114962_675:
    old "And I've been wanting to taste this cock for a while."
    new "我早就想尝尝这个了。"

translate chinese chinese_2117766_676:
    old "Uh... yeah, sure, remember we can't take much time."
    new "呃……对，记得我们没多少时间。"

translate chinese chinese_2436583_677:
    old "I know, I know, this will be quick."
    new "我知道，我知道，这很快就好。"

translate chinese chinese_0850759_678:
    old "Are you ok? Did everything work?"
    new "你还好吗？一切都顺利吗？"

translate chinese chinese_1178347_679:
    old "Oh yeah, I'm perfect, and she didn't feel anything."
    new "哦对，我完美无缺，而她什么感觉都没有。"

translate chinese chinese_2725260_680:
    old "Oh shit! That's right, if we don't clean her up, she's gonna wake up and realize what happened."
    new "哦shit！对了，如果我们不把她收拾干净，她醒来就会意识到发生了什么。"

translate chinese chinese_0355491_681:
    old "Come, help me clean her up, bring her to the toilet and get out of here."
    new "来，帮我把她清理一下，带到厕所，然后离开这里。"

translate chinese chinese_3345783_682:
    old "Ok, now let's go. We have to tell the others about how this went."
    new "好了，现在走吧。我们要把这事的经过告诉其他人。"

translate chinese chinese_8462526_683:
    old "Ugh, what happened?"
    new "哎，怎么了？"

translate chinese chinese_0354932_684:
    old "I can't remember anything. Why am I in the school bathroom?"
    new "我什么都记不起来了。为什么我会在学校洗手间？"

translate chinese chinese_7738169_685:
    old "Ugh, did I fall asleep in the toilet?"
    new "哎，我不会是在厕所里睡着了吧？"

translate chinese chinese_3280173_686:
    old "And what is this taste in my mouth?"
    new "而且我嘴里这是什么味道？"

translate chinese chinese_3001284_687:
    old "It's like a salty smoothie. Ughh, disgusting."
    new "就像咸味奶昔一样。呃，真恶心。"

translate chinese chinese_8586288_688:
    old "And what is that smell? It smells like... dick?"
    new "而且那是什么味道？闻起来像……棒子？"

translate chinese chinese_1188861_689:
    old "I bet some loser was jerking off in the women's bathroom!"
    new "肯定是个loser在女厕所里自渎！"

translate chinese chinese_0726340_690:
    old "Pathetic, I bet it was one of those losers that hangs out with Piglet."
    new "真可怜，我敢打赌肯定是和小猪一起的那些家伙之一。"

translate chinese chinese_7945521_691:
    old "I'll give them a piece of my mind next time I see them."
    new "下次见到他们，我得好好说说他们。"

translate chinese chinese_7622567_692:
    old "Hey guys, how did it go?"
    new "嘿，大家，怎么样了？"

translate chinese chinese_1089598_693:
    old "Terrible! Gomory got in the wrong body, so we don't know if it's going to work with Belle."
    new "糟了！戈莫里进了错误的身体，所以我们不知道这种方法对贝勒是否有效。"

translate chinese chinese_1551450_694:
    old "What? What happened?"
    new "什么？发生什么事了？"

translate chinese chinese_3706723_695:
    old "There was a confusion when I was about to perform the spell, and I accidentally jumped in the wrong person."
    new "我在念咒语的时候搞错了，不小心跳到了错的人身上。"

translate chinese chinese_9126524_696:
    old "So I ended up controlling her instead."
    new "结果我反而控制了她。"

translate chinese chinese_4850061_697:
    old "But did it work? I mean controling that body?"
    new "但是有效吗？我是说控制那个身体？"

translate chinese chinese_1236255_698:
    old "It did! Perfectly! I had no trouble getting inside her. And once I did I had total control over her body."
    new "成功了！完美无缺！我毫不费力就进入了她。一旦进入，我就完全控制了她的身体。"

translate chinese chinese_0972376_699:
    old "That's great! So we know you can do it too!"
    new "太好了！这样我们就知道你也行了！"

translate chinese chinese_9389132_700:
    old "Yeah well, we almost got caught though."
    new "好吧，不过我们差点就被抓到了。"

translate chinese chinese_2371571_701:
    old "Oh, I think you're making too much fuzz."
    new "哦，我觉得你小题大做了。"

translate chinese chinese_2207637_702:
    old "What's important is that it can be replicated."
    new "重要的是它可以被复制。"

translate chinese chinese_3750997_703:
    old "Hmm I think so..."
    new "嗯，我想是的……"

translate chinese chinese_0329644_704:
    old "Ok, we can say that was a success."
    new "好吧，我们可以认为那是成功的。"

translate chinese chinese_4778916_705:
    old "All right, then, we should keep training the spell with Devonne and Mildret, so they get ready for her practice."
    new "好吧，那我们应该继续和德冯和米尔德雷特一起练习这个魔法，好让她们为她的实战做好准备。"

translate chinese chinese_0246664_706:
    old "You can go and keep working on the church meanwhile [pla]."
    new "你可以继续去忙教堂的事，[pla]。"

translate chinese chinese_7448199_707:
    old "Alright, I'll keep working there."
    new "好吧，我会继续在那里工作的。"

translate chinese chinese_3694713_708:
    old "Perfect, go do that, and I'll meet you whenever they are ready."
    new "完美，你去办吧，等他们准备好了我再去找你。"

translate chinese chinese_8021541_709:
    old "Bye girls, good luck with the training."
    new "再见了，祝你们训练顺利。"

translate chinese chinese_3818260_710:
    old "Thank you, see you later."
    new "谢谢，再见。"

translate chinese chinese_7250751_711:
    old "Hey [pla], good morning. Ready for the next practice with the shinigamis?"
    new "嘿[pla]，早上好。准备好接下来和死神的训练了吗？"

translate chinese chinese_6504131_712:
    old "Hey Linet, yeah sure, I was thinking about what went wrong with Devonne."
    new "嘿，Linet，是的，我在想和Devonne之间出了什么问题。"

translate chinese chinese_9734189_713:
    old "This time I have an idea to ensure it's done with the right person."
    new "这次我有个主意，确保这件事是和对的人一起做的。"

translate chinese chinese_1212446_714:
    old "Sure, whatever you need. Let's go."
    new "行吧，你需要什么就来吧。走吧。"

translate chinese chinese_0448750_715:
    old "Hii."
    new "嗨。"

translate chinese chinese_7481062_716:
    old "Hi, good morning."
    new "你好，早上好。"

translate chinese chinese_7786917_717:
    old "Ok, given the advances she made yesterday, I think Gomory is the one that should go with you today."
    new "好吧，鉴于她昨天的进展，我觉得今天应该和你一起去的是Gomory。"

translate chinese chinese_5211951_718:
    old "I still have a couple of things to train with Mildret, but you two go ahead and practice."
    new "我还有几件事要和米德雷特训练，你们两个先去练习吧。"

translate chinese chinese_1532237_719:
    old "And this time please try and do it in the right body [pla]. We don't want to call attention to ourselves."
    new "而且这次请尽量用正确的身体[pla]。我们不想引起别人的注意。"

translate chinese chinese_0135374_720:
    old "Yeah, sure, I'll be more careful."
    new "好吧，我会更小心的。"

translate chinese chinese_5614364_721:
    old "Are you ready Devonne?"
    new "准备好了吗，德文？"

translate chinese chinese_1373129_722:
    old "I am."
    new "我是。"

translate chinese chinese_5773482_723:
    old "Ok, then let's go."
    new "好吧，那我们走吧。"

translate chinese chinese_2928877_724:
    old "Ok, so, are you sure you're clear on the process?"
    new "好的，所以，你确定明白流程了吗？"

translate chinese chinese_3269348_725:
    old "I am, I know it completely."
    new "我是知道的，完全知道。"

translate chinese chinese_3919214_726:
    old "Ok then, come on, let's find Billie."
    new "好吧，走吧，我们去找比莉。"

translate chinese chinese_6067992_727:
    old "Ok, we found her."
    new "好了，我们找到她了。"

translate chinese chinese_4896959_728:
    old "Listen, to avoid confusion like what happened with Gomory."
    new "听着，为了避免像戈莫里那样的混淆。"

translate chinese chinese_0685902_729:
    old "I'll go and talk to her, and convince her to go with me to the classroom."
    new "我去和她说，说服她跟我一起去教室。"

translate chinese chinese_5962129_730:
    old "You wait here and when you see me going inside, you can go and get inside the body the girl who is with me at that moment."
    new "你在这等着，等你看我进去的时候，你就进入我和那个女孩在一起时她的身体里。"

translate chinese chinese_2828108_731:
    old "Is everything clear?"
    new "都清楚了吗？"

translate chinese chinese_7896046_732:
    old "Yes, don't worry, that's very simple actually."
    new "是的，别担心，其实很简单。"

translate chinese chinese_8966289_733:
    old "Ok, glad to hear that, let's do it then."
    new "好的，听到这个很高兴，那我们就行动吧。"

translate chinese chinese_1309481_734:
    old "Hey Billie, how are you?"
    new "嘿，比莉，你好吗？"

translate chinese chinese_5595493_735:
    old "Hey [pla], what's up?"
    new "嘿[pla]，最近怎么样？"

translate chinese chinese_2256856_736:
    old "Not much, I just wanted to ask you something."
    new "没什么，我只是想问你件事。"

translate chinese chinese_9381637_737:
    old "Oh yeah? What is it?"
    new "哦？是什么？"

translate chinese chinese_6527746_738:
    old "Honestly, you're such a bad student already and you still take the luxury of skipping classes."
    new "说实话，你已经是个差学生了，还敢翘课这么奢侈。"

translate chinese chinese_2940790_739:
    old "Uh, Miss Mia, I- I can explain..."
    new "呃，米娅小姐，我……我可以解释……"

translate chinese chinese_3057648_740:
    old "I don't need you to explain anything!"
    new "我可不需要你解释什么！"

translate chinese chinese_4239863_741:
    old "A bad student is a bad student. That's it, but not only do you skip classes."
    new "差学生就是差学生。就是这么回事，但你不仅仅是逃课。"

translate chinese chinese_3435792_742:
    old "You're also here being a bad influence for Billie."
    new "你在这里也对比莉产生不良影响了。"

translate chinese chinese_1137448_743:
    old "I won't let you do that."
    new "我不会让你那么做的。"

translate chinese chinese_8135035_744:
    old "Come with me to the classroom!"
    new "跟我去教室吧！"

translate chinese chinese_7230851_745:
    old "W- Wha-?"
    new "W- 哪里——？"

translate chinese chinese_7474107_746:
    old "B- but, I'm talking with Billie."
    new "我、我在和比莉聊天呢。"

translate chinese chinese_5083289_747:
    old "I- it's important..."
    new "这很重要..."

translate chinese chinese_1078366_748:
    old "Please, what could someone like you to tell her that's important."
    new "拜托，像你这样的人能有什么重要的事情告诉她。"

translate chinese chinese_9009474_749:
    old "Now, don't make me repeat myself again, GO TO THE CLASSROOM NOW!"
    new "现在，别逼我再说一遍，马上去教室！"

translate chinese chinese_0154238_750:
    old "Don't worry, we can talk later [pla]."
    new "别担心，我们可以等会再聊 [pla]。"

translate chinese chinese_7099033_751:
    old "{alpha=0.8}{i}*Sigh*{/i}{/alpha} Oh fuck..."
    new "{alpha=0.8}{i}*叹气*{/i}{/alpha} 哦靠..."

translate chinese chinese_7564559_752:
    old "Listen, I don't want you contaminating the minds of other students with your bad behaviour."
    new "听着，我不希望你的不良行为影响到其他学生的思想。"

translate chinese chinese_6032287_753:
    old "Especially someone that just arrived at the school like Miss Billie."
    new "特别是像比莉小姐这样刚来学校的。"

translate chinese chinese_5305943_754:
    old "So you better stay away from here."
    new "所以你最好离这远点。"

translate chinese chinese_8350856_755:
    old "No no no! Wait!"
    new "不要不要不要！等一下！"

translate chinese chinese_4859649_756:
    old "What did you just say to me?"
    new "你刚说什么？"

translate chinese chinese_1590844_757:
    old "Does that mean you're going to ignore what I told you?"
    new "那你的意思是打算忽略我跟你说的话吗？"

translate chinese chinese_1087142_758:
    old "No! she is not the girl!"
    new "不！她不是那个女孩！"

translate chinese chinese_6170584_759:
    old "DON'T THINK YOU CAN JUST DO WHAT YOU WANT!"
    new "别以为你可以为所欲为！"

translate chinese chinese_2213897_760:
    old "Oh fuck!"
    new "哦操！"

translate chinese chinese_9094978_761:
    old "Wow! That was a lot easier than I thought it would be!"
    new "哇！这比我想象的要容易多了！"

translate chinese chinese_0595570_762:
    old "The sensations... are so weird! I feel... Heavy."
    new "这些感觉……好怪异！我觉得……很沉重。"

translate chinese chinese_7691055_763:
    old "But not in a bad way. You know?"
    new "但不是坏事。你知道吧？"

translate chinese chinese_6206797_764:
    old "Yeah ok, cool."
    new "好吧，行。"

translate chinese chinese_8886758_765:
    old "But listen, this wasn't supposed to happen."
    new "但是听我说，这本来不应该发生的。"

translate chinese chinese_5124885_766:
    old "It wasn't?"
    new "不是吗？"

translate chinese chinese_1139156_767:
    old "No, not at all. This is not the person that's going to be your host for the ritual."
    new "不，根本不是。这个人不会是你的仪式主持人。"

translate chinese chinese_7895826_768:
    old "Well, I did what you told me to. You're not very good at doing these plans you know?"
    new "好吧，我按你说的做了。你这计划制定得不太行啊，你知道吗？"

translate chinese chinese_4728442_769:
    old "God, why does this keep happening to me?!"
    new "天啊，为什么这种事情一直发生在我身上！"

translate chinese chinese_8864460_770:
    old "Anyway, you have to get out of that body."
    new "总之，你得离开那具身体。"

translate chinese chinese_0826779_771:
    old "I'll do it gladly."
    new "我乐意得很。"

translate chinese chinese_5603232_772:
    old "But, I would need your help..."
    new "但是，我需要你的帮助……"

translate chinese chinese_8830439_773:
    old "Yeah, yeah I know..."
    new "嗯嗯，我知道……"

translate chinese chinese_9111822_774:
    old "Linett said that receiving magic feels a lot different in a human body."
    new "林nett说，在人类身体里接收魔法的感觉大不相同。"

translate chinese chinese_0316615_775:
    old "Let's see if it's true."
    new "看看是不是真的。"

translate chinese chinese_0426045_776:
    old "Sure, but we better be quick."
    new "好吧，但我们最好快点。"

translate chinese chinese_7469635_777:
    old "Yeah, yeah."
    new "好吧好吧。"

translate chinese chinese_5122289_778:
    old "Doing it with a human body, so exciting!"
    new "用人身体来做这个，真刺激！"

translate chinese chinese_5039693_779:
    old "And i bet it's even going to be better with that big cock of yours."
    new "而且我敢打赌，有了你那大鸡巴会更棒。"

translate chinese chinese_8704986_780:
    old "Now... let's try this."
    new "现在……让我们试试这个。"

translate chinese chinese_1820280_781:
    old "Now let's get out of here."
    new "现在让我们离开这里。"

translate chinese chinese_7618763_782:
    old "We need to report back to Linett and the others."
    new "我们需要向林nett和其他人汇报。"

translate chinese chinese_2506823_783:
    old "Sure, right behind you."
    new "好的，就在你后面。"

translate chinese chinese_5212105_784:
    old "Why was I on the floor?"
    new "我为什么在地上？"

translate chinese chinese_6316400_785:
    old "All I can remember is that I was talking and everything went black."
    new "我只记得当时正在说话，然后一切就黑了。"

translate chinese chinese_3281271_786:
    old "Ugh! Who was I talking with?"
    new "哎！我刚才在跟谁说话？"

translate chinese chinese_0083168_787:
    old "[pla]!"
    new "[pla]!"

translate chinese chinese_4181700_788:
    old "Hey guys! How did it go?"
    new "嘿，大家！怎么样了？"

translate chinese chinese_3164313_789:
    old "Did you manage to do it right this time?"
    new "这次总算做对了吗？"

translate chinese chinese_0026170_790:
    old "Hmm, not exactly."
    new "嗯，不完全是。"

translate chinese chinese_9581837_791:
    old "What do you mean, the spell didn't work?"
    new "你说咒语没生效是什么意思？"

translate chinese chinese_9502305_792:
    old "Oh, not that, it worked perfectly."
    new "哦，不是那个，效果完美。"

translate chinese chinese_3761940_793:
    old "It's just that she didn't go into the right body."
    new "就是她的身体进错了。"

translate chinese chinese_6350225_794:
    old "Oh, again? You know [pla] you should really work on your plans."
    new "哦，又来了？你知道[pla]你真的需要改进你的计划了。"

translate chinese chinese_8082984_795:
    old "We don't want you to ruin it on the big day."
    new "我们不想让你在大日子搞砸了。"

translate chinese chinese_6954961_796:
    old "Yeah, sure."
    new "好吧，行。"

translate chinese chinese_9318576_797:
    old "But other than that, how did it go? How did you feel?"
    new "不过除此之外，事情进展如何？你感觉怎么样？"

translate chinese chinese_8176008_798:
    old "It was amazing! You had told me it worked, but this was unexpected."
    new "太棒了！你之前说有效果，但没想到会这样。"

translate chinese chinese_9250856_799:
    old "Human bodies feel so different!"
    new "人类的身体感觉真不一样！"

translate chinese chinese_7735672_800:
    old "Well, if everything goes well, you'll have a chance soon."
    new "嗯，如果一切顺利，你很快就有机会了。"

translate chinese chinese_3864664_801:
    old "As for you [pla], I still have some things to work out with Mildret, why don't you keep working on the church?"
    new "至于你[pla]，我还有些事情要和Mildret解决，你先继续处理教堂的事情吧？"

translate chinese chinese_9132459_802:
    old "And I'll contact you when it's time for the next practice."
    new "等下次练习的时候我会联系你。"

translate chinese chinese_1986594_803:
    old "Sure, then I'll see you later."
    new "行，那待会儿见。"

translate chinese chinese_1833843_804:
    old "Hey [pla], today's the last practice day. I hope you're ready."
    new "嘿[pla]，今天是最后一次练习了。希望你准备好了。"

translate chinese chinese_2799479_805:
    old "Good morning Linett; yeah sure, I'm ready to do this."
    new "早上好，林内特；好的，我准备好了。"

translate chinese chinese_6445674_806:
    old "Ok, let's go see the girls then..."
    new "好吧，那我们就去看那些女孩吧..."

translate chinese chinese_7217762_807:
    old "Hii, we're fine, how are you?"
    new "嗨，我们挺好的，你呢？"

translate chinese chinese_0887309_808:
    old "I'm ok, thanks."
    new "我挺好的，谢谢。"

translate chinese chinese_9554586_809:
    old "Today is the last practice day."
    new "今天是最后一次练习日。"

translate chinese chinese_0574560_810:
    old "[pla] I've been working with Mildret on perfecting the spell, and she finally learned it."
    new "[pla] 我和Mildret一直在完善这个咒语，她终于学会了。"

translate chinese chinese_4669104_811:
    old "So take her with you to where her host is and try it."
    new "那就带她去她的宿主那里试试吧。"

translate chinese chinese_4189692_812:
    old "Sure, no problem, are you ready Mildret?"
    new "好的，没问题，米德雷特准备好了吗？"

translate chinese chinese_3075167_813:
    old "Great, do ahead and let me know how everything goes."
    new "好的，你先去吧，回头告诉我结果怎么样。"

translate chinese chinese_3620702_814:
    old "Ok, so the last two previous attempts have failed because of confusion and bad timing."
    new "好的，所以前两次尝试失败是因为混乱和时机不对。"

translate chinese chinese_0093128_815:
    old "So this time, I brought a picture with me."
    new "这次我带了一张照片来。"

translate chinese chinese_8566100_816:
    old "This is the person that you're gonna get inside."
    new "这就是你要攻略的人。"

translate chinese chinese_1974902_817:
    old "Make sure you memorize her face, so this time won't happen as before."
    new "确保记住她的脸，这样就不会像以前那样了。"

translate chinese chinese_7093043_818:
    old "Ok, I'll make sure to remember this face, where can we find her?"
    new "好的，我会记住这张脸的，我们在哪儿能找到她？"

translate chinese chinese_9937458_819:
    old "She should be at her house, let's go."
    new "她应该在家，我们去看看。"

translate chinese chinese_5319936_820:
    old "Oh, hello [pla]. It's been quite a while, how are you?"
    new "哦，你好[pla]。好一阵子没见了，你怎么样？"

translate chinese chinese_3525360_821:
    old "I'm fine Mrs. Jade, thank you."
    new "我很好， jade 夫人，谢谢。"

translate chinese chinese_7300871_822:
    old "Are you here looking for Hinn?"
    new "你是来找赫恩的吗？"

translate chinese chinese_2621754_823:
    old "I am, I have to talk to her about our school project."
    new "我是得跟她谈谈关于我们学校的项目。"

translate chinese chinese_5371784_824:
    old "Oh, but you see, she's not in at the moment."
    new "哦，不过你见不着她，她现在不在家。"

translate chinese chinese_2193885_825:
    old "I think she went out with your friend Belle."
    new "我觉得她和你的朋友贝尔出去了。"

translate chinese chinese_3037720_826:
    old "If you want to, you can come back later when she arrives."
    new "如果你想的话，等她来了再回来吧。"

translate chinese chinese_4878144_827:
    old "I guess I'll have to..."
    new "我猜我得……"

translate chinese chinese_4578789_828:
    old "Nooo, not again! Damn it!"
    new "不，别再来了！该死！"

translate chinese chinese_8402085_829:
    old "It worked! I can't believe Linett was right."
    new "成功了！真不敢相信林nett是对的。"

translate chinese chinese_6562853_830:
    old "Hmph, yeah fine, that's very good and all. But you're in the wrong body!"
    new "哼，好吧，那很好，但是你的身体不对！"

translate chinese chinese_7844024_831:
    old "But I got in the body you told me to, I even had the picture and all."
    new "但我确实进入了你让我进的身体，我还拍了照片呢。"

translate chinese chinese_1179569_832:
    old "Well, that's not her. The body you got into it's her mother."
    new "好吧，那不是她。你附身的这个身体是她的母亲。"

translate chinese chinese_0446145_833:
    old "Well that's not my fault, they look identical!"
    new "那可不怪我，她们看起来一模一样！"

translate chinese chinese_4748483_834:
    old "I mean, all you humans are very similar to begin with, how was I supposed to know which is which?"
    new "我的意思是，你们人类本来就很相似，我怎么可能分得清呢？"

translate chinese chinese_9984253_835:
    old "I can't believe this is happening again."
    new "真不敢相信这又发生了。"

translate chinese chinese_4533265_836:
    old "Well anyway, let's get you out of that body quickly, I don't know when Hinn could come back home."
    new "好吧，还是赶紧把你从那个身体里弄出来，不知道Hinn什么时候会回家。"

translate chinese chinese_5081862_837:
    old "Sure, we already tested that I can do the spell, and it works how intended, let's not delay this any longer."
    new "好吧，我已经测试过我能念这个咒语，而且效果如预期，不要再拖延了。"

translate chinese chinese_1325670_838:
    old "Uhh, A- Are you ok?"
    new "呃，你、你还好吗？"

translate chinese chinese_4842160_839:
    old "You seem a little weird."
    new "你看起来有点奇怪。"

translate chinese chinese_7957550_840:
    old "Me? Weird? Don't be foolish."
    new "我？奇怪？别开玩笑了。"

translate chinese chinese_9416724_841:
    old "We do this often, why would I be weird about receiving magic in a human body?"
    new "我们经常这样做，为什么我会在意在人体里接收魔法呢？"

translate chinese chinese_7712507_842:
    old "Eh, well... I didn't say anything about that."
    new "呃，那个……我没说那件事。"

translate chinese chinese_8109914_843:
    old "But sure."
    new "不过可以。"

translate chinese chinese_8885984_844:
    old "You're talking too much."
    new "你话说太多了。"

translate chinese chinese_8927804_845:
    old "Remember we can't waste any time on this."
    new "记得这件事不能浪费任何时间。"

translate chinese chinese_3590147_846:
    old "Or the daughter of this body could come back and see us."
    new "或者这个身体的女儿能回来见我们。"

translate chinese chinese_0535388_847:
    old "You're right."
    new "你说得对。"

translate chinese chinese_5054240_848:
    old "Ok, we are done here, let's go."
    new "好了，我们这边完了，走吧。"

translate chinese chinese_5921026_849:
    old "How did I fall asleep?"
    new "我怎么会睡着了？"

translate chinese chinese_2429867_850:
    old "I can't even remember what I was doing..."
    new "我甚至不记得自己刚才在做什么了……"

translate chinese chinese_9896789_851:
    old "All I remember is I was talking to someone and then nothing."
    new "我只记得我在跟人说话，然后就什么都不知道了。"

translate chinese chinese_4479693_852:
    old "Who was I talking to?"
    new "我刚才在跟谁说话？"

translate chinese chinese_6930690_853:
    old "Well? How did it go? Did you manage to do it?"
    new "怎么样了？进展如何？你搞定了吗？"

translate chinese chinese_2008116_854:
    old "You could say that..."
    new "这么说也行……"

translate chinese chinese_4895516_855:
    old "But... you see, something happened."
    new "但是……你知道的，发生了一些事情。"

translate chinese chinese_4613869_856:
    old "And Mildret ended up in the wrong body again."
    new "结果米德尔又穿到错误的身体里了。"

translate chinese chinese_5129723_857:
    old "Amazing, you officially suck at this."
    new "真厉害，你正式成为这个的高手了。"

translate chinese chinese_3337234_858:
    old "Hey! Those were accidents, it wasn't my fault."
    new "喂！那些都是意外，不怪我。"

translate chinese chinese_3457068_859:
    old "It's ok, your ineptitude hasn't cost us anything."
    new "没事，你的无能还没给我们造成损失。"

translate chinese chinese_9901247_860:
    old "But enough about you [pla]."
    new "但是够了，说这些关于你的事情 [pla]。"

translate chinese chinese_8826658_861:
    old "I want to know how you felt, Mildret. What did you think of the spell?"
    new "我想知道你当时的感觉，Mildret。你觉得那个咒语怎么样？"

translate chinese chinese_5842854_862:
    old "Was it too difficult?"
    new "是不是太难了？"

translate chinese chinese_1693383_863:
    old "No, no, no, the opposite actually, it was very easy."
    new "不，不，不，其实正好相反，那非常容易。"

translate chinese chinese_5562619_864:
    old "I must say I'm amazed at how good your spell is. The connection to the body is complete."
    new "我必须说，你的咒语真的很厉害。和身体的连接完全契合。"

translate chinese chinese_3009508_865:
    old "Oh, it feels delicious, doesn't it?"
    new "哦，感觉真爽，对吧？"

translate chinese chinese_6326940_866:
    old "Hmph, I wouldn't say that."
    new "哼，我可不会那么说。"

translate chinese chinese_1136919_867:
    old "But it is true that the sensory experience is... Interesting."
    new "但不可否认的是，这种感官体验……挺有意思的。"

translate chinese chinese_9326158_868:
    old "Well, what's important is that now all of you have gotten to test the spell and see that it works."
    new "好吧，重要的是你们现在都测试了这个咒语，并且看到它确实有效。"

translate chinese chinese_5808154_869:
    old "That will make things easier to handle the day of the ritual."
    new "这会让仪式那天的事情处理起来更容易。"

translate chinese chinese_9307135_870:
    old "That makes me feel sure that there won't be any problem the day of the ritual."
    new "这让我确信仪式那天不会出任何问题。"

translate chinese chinese_8704313_871:
    old "But we're not done. Now that you know how to control bodies, we have to work on directing magic power."
    new "但我们还没完。现在你知道如何控制身体了，接下来我们必须练习引导魔力。"

translate chinese chinese_7476270_872:
    old "Hey, does that mean that my work here is done?"
    new "嘿，这意思是我的工作完了吗？"

translate chinese chinese_3413120_873:
    old "It is, now we need you to focus on securing both the church and making sure the hosts are ready for the day of the ritual."
    new "现在我们需要你集中精力确保教堂的安全，并且确认仪式当天的接待工作准备就绪。"

translate chinese chinese_5041333_874:
    old "Make sure everything's in place for that day."
    new "确保那天一切就绪。"

translate chinese chinese_7081960_875:
    old "Sure, no problem, I'll go then."
    new "行，没问题，那我去了。"

translate chinese chinese_3282619_876:
    old "Oh darling! I knew you'd do it."
    new "哦亲爱的！我就知道你能行。"

translate chinese chinese_8843915_877:
    old "Just look at how beautiful the church looks! What a miracle!"
    new "看看这教堂多漂亮！真是奇迹！"

translate chinese chinese_0952320_878:
    old "Thank you, I'm glad you like it."
    new "谢谢，很高兴你喜欢。"

translate chinese chinese_4488254_879:
    old "Oh darling, we don't like it, we love it!"
    new "哦，亲爱的，我们不是喜欢，我们是爱惨了！"

translate chinese chinese_6520196_880:
    old "Who knows how much time it would've taken Sister Grace and I to finish it by ourselves."
    new "谁知道格蕾丝姐姐和我得花多少时间才能自己搞定这件事。"

translate chinese chinese_0951619_881:
    old "That's right. You made it possible for this to be ready."
    new "没错。是你让它变得可能的。"

translate chinese chinese_2706961_882:
    old "Well darling, I'm sure you must be very busy."
    new "亲爱的，我敢肯定你一定很忙。"

translate chinese chinese_9234096_883:
    old "And I'm sure you don't want to spend even one more hour of your time here."
    new "我相信你甚至不希望在这里多待一个小时。"

translate chinese chinese_3515322_884:
    old "Actually, I wanted to ask you something."
    new "其实，我有件事想问你。"

translate chinese chinese_0082343_885:
    old "What would you like to know?"
    new "你想知道什么？"

translate chinese chinese_6778316_886:
    old "Well, the thing is that I'm doing this... Hmm, religious thing with a couple of my friends from school."
    new "嗯，其实我在和几个学校的朋友做一些……嗯，宗教活动。"

translate chinese chinese_3160594_887:
    old "And I would like to know if I can use the church one of these days to have a little ritual."
    new "我还想问一下，我能不能有一天在教堂里举行一个小仪式。"

translate chinese chinese_9888440_888:
    old "Ritual?"
    new "仪式？"

translate chinese chinese_1818042_889:
    old "Nothing bad."
    new "没什么不好的。"

translate chinese chinese_7338201_890:
    old "Just something like what happened last time, you know, to bring them to the lord."
    new "就像上次发生的事情一样，你知道的，把他们带到主人那里。"

translate chinese chinese_0297056_891:
    old "Oh my god! That sounds wonderful!"
    new "天啊！那听起来太棒了！"

translate chinese chinese_3030912_892:
    old "I agree. It's so inspiring to see young people acting in such a way, looking for a connection with the lord. Simply great!"
    new "我同意。看到年轻人这样行动，寻找与主的联系，真是非常鼓舞人心。太棒了！"

translate chinese chinese_5428867_893:
    old "Say [pla], could we participate? Just like last time? I would like you to bring me closer to heaven again!"
    new "说[pla]，我们能参加吗？就像上次一样？我想再让你带我接近天堂！"

translate chinese chinese_7242950_894:
    old "Uhh, I think not."
    new "呃，我觉得不行。"

translate chinese chinese_9417484_895:
    old "You see, you've already been blessed, the idea is to bring in new people, to receive the blessing."
    new "你看，你已经被赐福了，现在是要带新人来接受赐福。"

translate chinese chinese_4479138_896:
    old "Oh, really? I must say that's a little disappointing."
    new "哦，是吗？我得说这有点让人失望。"

translate chinese chinese_8175274_897:
    old "No, no, sister, what [pla] says it's true."
    new "不，不，姐姐，[pla]说得对。"

translate chinese chinese_6471308_898:
    old "We must allow for other people to receive such a special blessing and be brought over to the community."
    new "我们必须允许其他人也能得到这样的特殊恩赐，并被带入我们的社区。"

translate chinese chinese_8641139_899:
    old "It's great that you understand."
    new "你能理解真是太好了。"

translate chinese chinese_6540009_900:
    old "So, I think we'll need the church for some days, so that the ritual can be properly done."
    new "所以，我想我们需要教堂几天时间，以便仪式能顺利进行。"

translate chinese chinese_3427045_901:
    old "I would love it if nobody came here, just so that we're not interrupted."
    new "如果没人来这里就好了，这样我们就不会被打扰。"

translate chinese chinese_8357925_902:
    old "Oh sure, no problem. We'll see to that, right Sister Grace?"
    new "哦，当然，没问题。我们会处理好的，对吧，格蕾丝姐姐？"

translate chinese chinese_1491715_903:
    old "There will be no issue."
    new "没问题的。"

translate chinese chinese_9725580_904:
    old "We trust you completely, so we'll do as you ask us."
    new "我们完全信任你，所以会按你的要求去做。"

translate chinese chinese_1204491_905:
    old "Thank you very much! You're of great help."
    new "非常感谢！你帮了大忙了。"

translate chinese chinese_4642584_906:
    old "Not at all darling, you're the one who is of great help, bringing people over to the community. What a good young man."
    new "亲爱的，你才是帮了大忙，把人们带到这个社区来。真是个好小伙子。"

translate chinese chinese_9699975_907:
    old "It's true, you are a true blessing from the lord."
    new "是真的，你真是上帝赐予的恩典。"

translate chinese chinese_5896312_908:
    old "Thank you, very much for saying that."
    new "谢谢你这么说。"

translate chinese chinese_2693536_909:
    old "I think I better get going then."
    new "那我还是走吧。"

translate chinese chinese_3459609_910:
    old "Good night [pla], and thanks again for all your help."
    new "晚安[pla]，再次感谢你的帮助。"

translate chinese chinese_1381829_911:
    old "Yes, thank you so much, God bless you."
    new "好的，非常感谢，上帝保佑你。"

translate chinese chinese_1043936_912:
    old "Oh, hi, what's up?"
    new "哦，嗨，最近怎么样？"

translate chinese chinese_2845354_913:
    old "Nothing much, I just wanted to let you know that I talked to the girls."
    new "没什么，就是想让你知道我跟那些女孩聊过了。"

translate chinese chinese_2424713_914:
    old "And I'm very happy with the results of the training, they're now ready to do the ritual."
    new "我对训练的结果非常满意，他们现在准备好进行仪式了。"

translate chinese chinese_5154607_915:
    old "It is, that's why I wanted to ask you, how are things going with the church?"
    new "就是这个原因，我想问问你，和教堂的事情进展如何？"

translate chinese chinese_7917566_916:
    old "It's great, I asked them to let me use it, and they said it was ok, so we're all set."
    new "太好了，我问他们能不能让我用一下，他们说可以，所以我们没问题了。"

translate chinese chinese_6851160_917:
    old "Fantastic, and how are things going with the three humans we need? Did you convince them already?"
    new "太好了，那我们需要的三个凡人怎么样了？你已经说服他们了吗？"

translate chinese chinese_5965241_918:
    old "Uhh, not really, but I think I can convince them of it pretty soon."
    new "呃，还不行，但我想我很快就能说服他们。"

translate chinese chinese_9989687_919:
    old "Please do it and remember, they won't notice the ritual at all, so you don't need to worry."
    new "请去做吧，记住，他们根本不会注意到这个仪式，所以你不用担心。"

translate chinese chinese_0212276_920:
    old "Ok, I'll keep that in mind. And will talk to them as soon as I can."
    new "好的，我会记住的。一有机会就去找他们谈谈。"

translate chinese chinese_9972405_921:
    old "I'll leave it in your hands then."
    new "那我就交给你了。"

translate chinese chinese_4616090_922:
    old "Hmm, the day for the ritual is coming. I better hurry up and talk to the girls soon."
    new "嗯，举行仪式的日子快到了。我得赶紧去找女孩们谈谈。"

translate chinese chinese_8832428_923:
    old "Hi [pla]! It's good to see you."
    new "嗨 [pla]！见到你真好。"

translate chinese chinese_0987547_924:
    old "Hey, listen, I'm glad we can talk. I wanted to tell you something."
    new "嘿，听着，我很高兴我们可以谈谈。我有些事情想告诉你。"

translate chinese chinese_7440585_925:
    old "Sure, is everything ok?"
    new "当然，一切都好吗？"

translate chinese chinese_7161509_926:
    old "Yeah, yeah, everything's fine, it's nothing bad."
    new "嗯嗯，一切都好，没什么不好的。"

translate chinese chinese_2241641_927:
    old "Oh, ok, what is it then?"
    new "哦，好的，那是什么？"

translate chinese chinese_8412796_928:
    old "Well, it's about what happened the other day with that dumbass bimbo."
    new "好吧，说的就是那天和那个蠢女人的事。"

translate chinese chinese_0986659_929:
    old "She made me angry and I took off and left you alone with her. So I wanted to say sorry."
    new "她把我惹生气了，我就自己先走了，把你一个人丢给她。所以我想说声对不起。"

translate chinese chinese_7860312_930:
    old "That's all? Don't worry about it. I understand how irritating her comments can be."
    new "就这些？别担心了。我明白她的评论有多烦人。"

translate chinese chinese_7294019_931:
    old "They really are and she just makes me so mad."
    new "他们确实这样，她真的让我很生气。"

translate chinese chinese_0999503_932:
    old "I hope nothing bad happened with her when I left."
    new "希望我离开后她没什么事。"

translate chinese chinese_9389460_933:
    old "Bad? Haha, no, of course not, what could happen between us? Nothing happened at all."
    new "糟了？哈哈，不，当然不是，我们之间会发生什么吗？根本什么都没发生。"

translate chinese chinese_0114123_934:
    old "Hmm, Okay..."
    new "嗯，好吧……"

translate chinese chinese_1016532_935:
    old "Well anyway, leaving that aside, there's something that I wanted to talk to you about."
    new "好吧，不说这个了，我有件事想和你谈谈。"

translate chinese chinese_3437737_936:
    old "Well, these past few days I've been helping decorate the church, for the holidays and stuff."
    new "嗯，这些天我一直在帮忙装饰教堂，为了节日什么的。"

translate chinese chinese_8230531_937:
    old "And the church actually looks really cool."
    new "而且那座教堂看起来真的很酷。"

translate chinese chinese_9648318_938:
    old "And it came to me that since we have some free time, why don't we have a little christmas celebration?"
    new "我想既然我们有些空闲时间，为什么不搞个小圣诞庆祝呢？"

translate chinese chinese_5116052_939:
    old "I thought it could be really cool if we played truth or dare like last time."
    new "我觉得如果我们像上次那样玩真心话大冒险会很酷的。"

translate chinese chinese_4482466_940:
    old "With me, Billie and Hinn by the way."
    new "我和Billie还有Hinn一起。"

translate chinese chinese_7337938_941:
    old "Not Mike, I know he can be a little annoying."
    new "不是迈克，我知道他有时候挺烦人的。"

translate chinese chinese_0986978_942:
    old "Hmm, that sounds like fun. And I do like that Mike won't be there..."
    new "嗯，听起来挺好玩的。而且迈克不在那里我也挺喜欢的……"

translate chinese chinese_5972239_943:
    old "Oh, by the way, I think it would be cool if we dressed up for christmas."
    new "哦，对了，我觉得圣诞节的时候打扮一下挺酷的。"

translate chinese chinese_9880067_944:
    old "That's actually nice."
    new "那 actually 挺好的。"

translate chinese chinese_5811183_945:
    old "Sure, why not? Count me in."
    new "行啊，为什么不行？算我一个。"

translate chinese chinese_6369396_946:
    old "That's great Belle! So, how about we tomorrow night on the beach? Same spot as last time."
    new "太好了，贝尔！那我们明天晚上还在上次那个地方见面吧？"

translate chinese chinese_3897262_947:
    old "And from there we can go to the church."
    new "从那里我们可以去教堂。"

translate chinese chinese_3344257_948:
    old "Hey Billie, how are you doing?"
    new "嘿，比莉，最近怎么样？"

translate chinese chinese_2871454_949:
    old "Hey dude, what's up?"
    new "嘿哥们，最近怎么样？"

translate chinese chinese_9397216_950:
    old "Hey, I wanted to talk to you about something."
    new "嘿，我有件事想和你谈谈。"

translate chinese chinese_8244248_951:
    old "Sure, is it the same thing you wanted to say to me when Miss Mia dragged you away the other day?"
    new "当然，是不是那天米娅小姐把你拖走时，你想对我说的话？"

translate chinese chinese_3620144_952:
    old "Oh, yeah, actually it is. But thanks for reminding me that Miss Mia hates me."
    new "哦，对了，确实如此。不过还是要谢谢你提醒我米娅小姐讨厌我。"

translate chinese chinese_1180242_953:
    old "Hahahaha, dude, she really does. I don't know what you did to get on her bad side. But she has it in for you."
    new "哈哈哈哈哈，伙计，她真的生气了。我不知道你做了什么让她不高兴。但她肯定是针对你。"

translate chinese chinese_7001543_954:
    old "She does, she really does."
    new "她确实做了，她真的做了。"

translate chinese chinese_1356637_955:
    old "But anyway, that's not what I wanted to say."
    new "不过话说回来，那不是我想说的重点。"

translate chinese chinese_5325176_956:
    old "Listen, I've been thinking, and that game of truth or dare was actually pretty fun."
    new "听我说，我一直在想，那个真心话大冒险游戏其实挺好玩的。"

translate chinese chinese_0890958_957:
    old "So I thought that since we're gonna have some free time soon. Maybe we could go for another round."
    new "所以我想既然我们很快会有空闲时间，也许我们可以再来一轮。"

translate chinese chinese_2565863_958:
    old "Oh, I wasn't expecting you to say that."
    new "哦，我没想到你会这么说。"

translate chinese chinese_8113741_959:
    old "I mean, sure, it could be fun, but I don't know."
    new "我的意思是，这可能会很有趣，但我不确定。"

translate chinese chinese_3516742_960:
    old "Sounds a little boring now."
    new "现在听起来有点无聊。"

translate chinese chinese_4459007_961:
    old "Oh, come on. Let's do it. Besides, I've been helping your grandma decorate the church."
    new "哦，别这样了。我们来吧。再说，我一直在帮你奶奶装饰教堂呢。"

translate chinese chinese_3881687_962:
    old "Yeah, she mentioned it."
    new "嗯，她提过。"

translate chinese chinese_9798314_963:
    old "Yeah and it actually looks great, so it came to my mind that we could have a little celebration there."
    new "是的，而且看起来真的很棒，所以我想我们可以在那里稍微庆祝一下。"

translate chinese chinese_9601731_964:
    old "And we can even wear holiday outfits."
    new "甚至还可以穿节日服装。"

translate chinese chinese_2955993_965:
    old "When you say that we celebrate there."
    new "你说的在那里庆祝。"

translate chinese chinese_6726868_966:
    old "I hope that doesn't means my grandma and the nun will be there. Right?"
    new "希望那不意味着我奶奶和修女也会在场。对吧？"

translate chinese chinese_2336808_967:
    old "No, not at all."
    new "不，根本不是那样。"

translate chinese chinese_2371372_968:
    old "I talked to them and I got them to lend me the place for the night. So it will just be us."
    new "我跟他们说了，让他们今晚借给我这个地方。所以就我们俩。"

translate chinese chinese_2047318_969:
    old "Even with that, it doesn't sound like the coolest thing."
    new "就算这样，听起来也不像是最酷的事情。"

translate chinese chinese_4584041_970:
    old "It will be cool. And you kind of owe for what happened last time."
    new "这会很酷的。而且上一次的事你多少也欠我的。"

translate chinese chinese_5543481_971:
    old "Remember whose idea it was that I climbed that roof?"
    new "别忘了爬屋顶的主意是谁出的？"

translate chinese chinese_1336415_972:
    old "Ugh, dude, come on! Don't bring that up now, lame."
    new "哎呀，别这样好不好！现在提这个多尴尬。"

translate chinese chinese_9184189_973:
    old "But it's true, I do owe you. And what the hell, it could be fun."
    new "但事实就是，我确实欠你的人情。而且去它的，这可能会很有趣。"

translate chinese chinese_9664761_974:
    old "But no Mike, ok? He's annoying."
    new "但是不要迈克，好吗？他很烦人。"

translate chinese chinese_3998865_975:
    old "Thanks Billie! I'm sure we'll have a great time. Ok, so tomorrow night at the beach? We can go from there."
    new "谢谢比莉！我相信我们会玩得很开心。好的，那么明天晚上在海滩见？我们可以从那里开始。"

translate chinese chinese_7416431_976:
    old "Yeah, whatever."
    new "好吧，随便你。"

translate chinese chinese_2039161_977:
    old "Alright, see you tomorrow then."
    new "好吧，那明天见。"

translate chinese chinese_3558360_978:
    old "[pla] Hi! How are you?"
    new "[pla] 嗨！你好吗？"

translate chinese chinese_6505857_979:
    old "I'm glad. My mother told me you came home the other day looking for me. I'm sorry we couldn't talk."
    new "我挺高兴的。我妈妈告诉我你前几天来找我。抱歉我们没能聊上。"

translate chinese chinese_4828935_980:
    old "Don't worry, it happens."
    new "别担心，这种情况有的是。"

translate chinese chinese_9187045_981:
    old "Yeah, by the way, my mom wanted me to ask you if you remember anything strange happening."
    new "对了，我妈妈让我问问你，最近有没有什么奇怪的事情发生。"

translate chinese chinese_7986592_982:
    old "Strange? Heh, Me? N- no, no, why?"
    new "奇怪？嘿嘿，我吗？不，不，为什么？"

translate chinese chinese_2590766_983:
    old "Well, she says that she remembers talking to you, but then she just woke up, apparently she fell asleep without knowing."
    new "嗯，她说她记得和你聊过天，但后来就醒了，好像是不知不觉睡着了。"

translate chinese chinese_2213756_984:
    old "So she wanted me to ask you if you know anything about that."
    new "所以她想让我问你知不知道那件事。"

translate chinese chinese_8475600_985:
    old "Hmm, not really, after she told me you weren't there I just left."
    new "嗯，差不多吧，她告诉我你不在，我就离开了。"

translate chinese chinese_7930588_986:
    old "Maybe she was tired and doesn't remember falling asleep."
    new "maybe她累了，不记得自己睡着了。"

translate chinese chinese_7882818_987:
    old "Yeah, that's what I told her."
    new "是的，我就是这么跟她说的。"

translate chinese chinese_3440826_988:
    old "But anyway, what did you want to talk to me about?"
    new "不过话说回来，你找我有什么事？"

translate chinese chinese_7597336_989:
    old "Oh right, I forgot."
    new "哦对了，我忘了。"

translate chinese chinese_5934672_990:
    old "Well, you see. I've been thinking that maybe we could get together with Billie and Belle."
    new "嗯，我的意思是，我在想我们是不是可以和比莉还有贝儿一起聚聚。"

translate chinese chinese_3474437_991:
    old "And play another round of truth or dare with them. It was very fun last time and maybe it would be good to do it again."
    new "然后再和他们玩一轮真心话大冒险。上次玩得很开心，也许再玩一次也不错。"

translate chinese chinese_0595523_992:
    old "Especially since we have some free time coming up."
    new "尤其是我们很快就有空闲时间了。"

translate chinese chinese_5532518_993:
    old "I don't know [pla]. I mean, it is fun. But you know how nervous I get in those kind situations."
    new "我不知道[pla]。我觉得挺好玩的。但你知道那种情况我会紧张。"

translate chinese chinese_2302948_994:
    old "I know, I know. But that's in part why I propose it, I think it could be very helpful with your anxiety."
    new "我知道，我知道。但这也是我提议的原因之一，我觉得这对你缓解焦虑会有很大帮助。"

translate chinese chinese_8098613_995:
    old "I mean, you can practice a bit and of course stay with me and your friends in a safe place."
    new "我的意思是，你可以稍微练习一下，当然也可以和我还有你的朋友们待在一个安全的地方。"

translate chinese chinese_7678597_996:
    old "You know what? You might be right. And I think I could also use the experience to deal with my anxiety."
    new "你知道吗？你说的可能对。而且我觉得这个经历也能帮助我应对焦虑。"

translate chinese chinese_5464640_997:
    old "I- I'll do it."
    new "我——我来吧。"

translate chinese chinese_3530291_998:
    old "That's cool Hinn. I'm sure we'll have a good time."
    new "这样也挺好的，Hinn。我相信我们会玩得很开心的。"

translate chinese chinese_4933441_999:
    old "Oh, and I was thinking, maybe we could take the chance and dress up christmas themed, what do you think?."
    new "哦，对了，我在想，我们是不是可以趁这个机会穿圣诞主题的服装，你觉得怎么样？"

translate chinese chinese_7118888_1000:
    old "You know, because it's the holidays."
    new "你知道的，因为现在是假期。"

translate chinese chinese_3354656_1001:
    old "That sounds great! Count me in."
    new "听起来不错！算我一个。"

translate chinese chinese_4450534_1002:
    old "I was thinking that we could meet at the beach tomorrow night."
    new "我在想我们明天晚上可以在海滩见面。"

translate chinese chinese_3270103_1003:
    old "That sounds ok."
    new "那听起来还行。"

translate chinese chinese_2402505_1004:
    old "See you later then."
    new "那回头见。"

translate chinese chinese_8133827_1005:
    old "Sure, goodbye."
    new "好吧，再见。"

translate chinese chinese_3776819_1006:
    old "Hi, you were waiting for me?"
    new "喂，你在等我吗？"

translate chinese chinese_3308868_1007:
    old "I was, I wanted to tell the other three shinigami are ready for the ritual."
    new "我是想说，另外三个死神已经准备好进行仪式了。"

translate chinese chinese_2649912_1008:
    old "I already spoke with my friends, they all said yes."
    new "我已经跟我朋友们说过了，他们全都说好。"

translate chinese chinese_6719402_1009:
    old "That's perfect! Ok, so we're all set now."
    new "太完美了！好了，现在一切就绪。"

translate chinese chinese_4930338_1010:
    old "Get ready, we'll have a lot of work to do tomorrow. Be sure you get enough rest."
    new "准备好，明天有很多工作要做。确保你有足够的休息。"

translate chinese chinese_3771676_1011:
    old "I'll make sure to get enough rest."
    new "我一定会保证充足休息的。"

translate chinese chinese_0304290_1012:
    old "Ok then, I'll see you tomorrow."
    new "好吧，那明天见。"

translate chinese chinese_8158574_1013:
    old "Hey Linett, good morning."
    new "嘿，林内特，早上好。"

translate chinese chinese_7908325_1014:
    old "Are you ready for today?"
    new "今天准备好了吗？"

translate chinese chinese_5849263_1015:
    old "Yeah sure, I'm ready."
    new "行吧，我准备好了。"

translate chinese chinese_2539126_1016:
    old "Ok then, so let's go talk to the others."
    new "好吧，那我们就去和其他人谈谈吧。"

translate chinese chinese_1288580_1017:
    old "Good morning, I hope you're all ready for the ritual today."
    new "早上好，希望你们都为今天的仪式做好了准备。"

translate chinese chinese_1283494_1018:
    old "Hello, yes, we are. We've been practicing so we're confident it's going to go well."
    new "喂，是的，我们准备得很充分，所以觉得会很顺利。"

translate chinese chinese_5289731_1019:
    old "Hello, I agree."
    new "你好，我同意。"

translate chinese chinese_1558435_1020:
    old "Sure, we feel like we won't have any issues. Good morning [pla]."
    new "当然，我们觉得不会有什么问题。早上好[pla]。"

translate chinese chinese_4925920_1021:
    old "Ok, it's good to hear you're confident. So, before we leave for the church, we should go over the plan."
    new "好吧，听你这么说我很放心。所以在去教堂之前，我们应该再确认一下计划。"

translate chinese chinese_8209434_1022:
    old "[pla] has been working to have the place ready for us to use. So that won't be an issue."
    new "[pla] 一直在努力把这里准备好供我们使用。所以这不会是个问题。"

translate chinese chinese_3637960_1023:
    old "That's great."
    new "太好了。"

translate chinese chinese_9345682_1024:
    old "It is. The idea is that we'll go to the church and wait there."
    new "是的。我们的想法是去教堂等在那里。"

translate chinese chinese_6485199_1025:
    old "In the meantime [pla] will meet with the people that will be our hosts somewhere else and bring them over."
    new "与此同时，[pla]会在别的地方与我们的东道主见面，并把他们带过来。"

translate chinese chinese_2931317_1026:
    old "When they get to the church they'll come and you'll get inside them."
    new "等他们到了教堂，你就进去他们体内。"

translate chinese chinese_8369879_1027:
    old "How will we know who's getting inside who?"
    new "我们怎么知道谁会上谁？"

translate chinese chinese_5013830_1028:
    old "I was thinking about that, but honestly it doesn't really makes much of a difference."
    new "我在想这件事，但老实说差别不大。"

translate chinese chinese_6651067_1029:
    old "It would if you had run the practice with your actual hosts. But since you didn't, you can just get inside anybody."
    new "如果你用实际的主持人进行过练习就好了。但既然你没有，你就可以随意进入任何人。"

translate chinese chinese_8971960_1030:
    old "Ok, It sounds fairly easy."
    new "好吧，听起来挺简单的。"

translate chinese chinese_8665348_1031:
    old "It will be, after you get them we can start the ritual."
    new "等你拿到那些东西后，我们就可以开始仪式了。"

translate chinese chinese_8459974_1032:
    old "So while you channel magic power, I'll handle the union of all three sources into the breach point."
    new "所以你在引导魔力的同时，我会负责将三个源头汇聚到缺口处。"

translate chinese chinese_1019658_1033:
    old "If everything goes well, we should be able to create a magic generator point."
    new "如果一切顺利，我们应该能创建一个魔法生成点。"

translate chinese chinese_9262909_1034:
    old "So, we better get to it. [pla] go ahead, and we'll meet back at the church."
    new "所以，我们还是开始吧。[pla]你先走，我们在教堂碰面。"

translate chinese chinese_2898522_1035:
    old "Ok, see you then."
    new "好，到时候见。"

translate chinese chinese_4830075_1036:
    old "Several hours later..."
    new "几个小时后……"

translate chinese chinese_1575857_1037:
    old "Hey girls! Wow... You look stunning!"
    new "嘿，姑娘们！哇……你们真漂亮！"

translate chinese chinese_6411248_1038:
    old "Y- You think so?"
    new "你、你是这么认为的？"

translate chinese chinese_5869785_1039:
    old "I do. For starters, you look great as a reindeer."
    new "我有。首先，你扮成驯鹿的样子真好看。"

translate chinese chinese_1263490_1040:
    old "And you Belle, that santa claus outfit really fits you. You look amazing."
    new "贝尔，这套圣诞老人的服装真的很适合你，你看起来棒极了。"

translate chinese chinese_8713590_1041:
    old "And Billie, green really is your colour, I think it goes really well with your hair."
    new "比莉，绿色真的很适合你，我觉得它和你的头发很搭。"

translate chinese chinese_1670038_1042:
    old "Well and where is this coming from?"
    new "那这个是从哪里来的呢？"

translate chinese chinese_7071233_1043:
    old "It's odd to hear you being so flattering."
    new "听你这么奉承还真有点别扭。"

translate chinese chinese_5697766_1044:
    old "But he's right, we look great. Hahaha."
    new "但他说得对，我们看起来很棒。哈哈哈哈哈。"

translate chinese chinese_3279159_1045:
    old "And what about you? What happended with your outfit?"
    new "那你呢？你的衣服怎么了？"

translate chinese chinese_0629873_1046:
    old "Oh crap! I completely forgot… I was a bit busy with all the preparations"
    new "哦crap！我完全忘了……我一直在忙着准备这些东西"

translate chinese chinese_0468845_1047:
    old "That's not fair..."
    new "那不公平……"

translate chinese chinese_8133615_1048:
    old "Yeah, yeah whatever..."
    new "嗯哼，随便吧..."

translate chinese chinese_4273338_1049:
    old "Ok dude, let's start this!"
    new "好了，咱们开始吧！"

translate chinese chinese_4102999_1050:
    old "Wow! [pla] look at this place! It's amazing!"
    new "哇！[pla] 看这个地方！太棒了！"

translate chinese chinese_1366143_1051:
    old "They're right, it looks very beautiful [pla]."
    new "他们说得对，看起来真的很漂亮[pla]。"

translate chinese chinese_3882906_1052:
    old "Well thank you, I'm glad you girls like it."
    new "好吧，谢谢，很高兴你们喜欢。"

translate chinese chinese_2086962_1053:
    old "Ok, we should start playing, don't we."
    new "好吧，我们应该开始玩了，对吧。"

translate chinese chinese_9417012_1054:
    old "Yeah, it's time! Let's start."
    new "没错，时候到了！我们开始吧。"

translate chinese chinese_2238252_1055:
    old "Woah!"
    new "哇！"

translate chinese chinese_5332579_1056:
    old "That sensation, it's so strong."
    new "那种感觉，太强烈了。"

translate chinese chinese_7998504_1057:
    old "Did it work?"
    new "成功了吗？"

translate chinese chinese_5814269_1058:
    old "It did, the spell went well."
    new "成功了，咒语生效了。"

translate chinese chinese_8385875_1059:
    old "Great, that was very good."
    new "很好，做得不错。"

translate chinese chinese_1693785_1060:
    old "Well, I wouldn't say it went that well. I mean, look at me! This body is so small."
    new "好吧，我不会说这进展得很顺利。我是说，看看我！这身体太小了。"

translate chinese chinese_6753723_1061:
    old "I don't have any more curves! This isn't fair!"
    new "我再也没有曲线了！这不公平！"

translate chinese chinese_9685997_1062:
    old "I actually gained size. This girl has way more curves than I do."
    new "我实际上丰满了不少。这个女孩的曲线比我多多了。"

translate chinese chinese_2307456_1063:
    old "I think that the one that came up the better in that sense was Mildret."
    new "我觉得在这方面表现更好的是Mildret。"

translate chinese chinese_4772131_1064:
    old "Your host has some real curves, it's amazing!"
    new "你的主人真是曲线玲珑，太棒了！"

translate chinese chinese_8463755_1065:
    old "I suppose you could say that. She is really big."
    new "我想你可以这么说。她确实很大。"

translate chinese chinese_6144268_1066:
    old "I must say I'm surprised she can move around with these things. Specially since humans can't fly."
    new "不得不说我挺惊讶她能带着这些东西行动。特别是人类又不会飞。"

translate chinese chinese_0497274_1067:
    old "They can't fly, but they have some sensory capabilities that are unique to them."
    new "它们不能飞，但有一些独特的感官能力。"

translate chinese chinese_2904366_1068:
    old "They have access to sensations that we don't."
    new "他们能体验到我们无法体验的感觉。"

translate chinese chinese_2169897_1069:
    old "Oh, you don't have to tell me that. I've had it in my mind since before we made the spell."
    new "哦，你不用告诉我这个，从我们开始念那个咒语之前，我就已经想到了。"

translate chinese chinese_1134257_1070:
    old "I know what you mean, but please remember that's not the reason why we're doing this."
    new "我知道你的意思，但请记住那不是我们这么做的原因。"

translate chinese chinese_8800105_1071:
    old "I know, I know... But still, you can't deny that it's a very interesting experience."
    new "我知道，我知道……但无论如何，你不能否认这是一次非常有趣的经历。"

translate chinese chinese_1270284_1072:
    old "I mean, even Mildret's waiting for it. Right?"
    new "我是说，就连米德雷特都在等着呢。对吧？"

translate chinese chinese_7309402_1073:
    old "Hmph, the only thing I'm waiting for is the magic we'll get once the ritual is over. Nothing else."
    new "哼，我唯一期待的就是仪式结束后我们会得到的魔法，别的没什么。"

translate chinese chinese_2594545_1074:
    old "Ha! Yeah right. I know you enjoyed your practice the other day."
    new "哈！说得倒轻巧。我知道你前几天的训练挺享受的。"

translate chinese chinese_8236522_1075:
    old "Oh, shut up!"
    new "哦，闭嘴！"

translate chinese chinese_6794124_1076:
    old "Enough of that, remember we're doing a ritual. And it's better if we begin."
    new "别闹了，记得我们现在要做仪式。还是开始吧。"

translate chinese chinese_5457280_1077:
    old "[pla] are you ready?"
    new "[pla] 你准备好了吗？"

translate chinese chinese_5624373_1078:
    old "I am, what do I have to do? How is the process?"
    new "我是认真的，我该怎么做？流程是怎样的？"

translate chinese chinese_9724573_1079:
    old "You just have to supply them with magic power so that they can  leave your friends bodies."
    new "你只要提供他们魔法力量，让他们离开你朋友的身体就行了。"

translate chinese chinese_3339030_1080:
    old "The amount of magic that's actually needed to break the possession is really small."
    new "实际上打破控制所需的魔法量很小。"

translate chinese chinese_5689053_1081:
    old "I'm not sure I follow."
    new "我不太明白。"

translate chinese chinese_8648588_1082:
    old "What she means is that in the process of pushing us out of these bodies."
    new "她的意思是说在把我们推出这些身体的过程中。"

translate chinese chinese_7111583_1083:
    old "There's going to be an excess of magic that's being produced."
    new "会产生多余的魔法。"

translate chinese chinese_7497122_1084:
    old "And that extra magic is the one I'll take and divert to the point where I'll open a breach."
    new "而那额外的魔法就是我要抽取并转移到打开裂缝的地方的。"

translate chinese chinese_7288291_1085:
    old "That will transform into the magic generation point."
    new "那将会变成魔法生成点。"

translate chinese chinese_4918635_1086:
    old "Well, if you do then we better not delay this any longer."
    new "好吧，如果你准备好了，那我们就不要再拖了。"

translate chinese chinese_1865962_1087:
    old "She's right. We better get started."
    new "她说得对。我们还是开始吧。"

translate chinese chinese_4477419_1088:
    old "Yay!"
    new "耶！"

translate chinese chinese_7922462_1089:
    old "Alright, now it's time to you to give us that big cock!"
    new "好了，现在轮到你给我们那大鸡巴了！"

translate chinese chinese_2529815_1090:
    old "My god, this cock of yours, I’ve always thought it’s very big for a human."
    new "天啊，你的这个家伙，我一直觉得对于人类来说它很大。"

translate chinese chinese_8173436_1091:
    old "But seeing it with human eyes... It’s something else."
    new "但用人类的眼睛去看……那就是另一回事了。"

translate chinese chinese_9731976_1092:
    old "It’s true, I never thought I’d care about the size and girth."
    new "是真的，我从没想到我会在意大小和粗细。"

translate chinese chinese_6531142_1093:
    old "But with this body..."
    new "但是有了这副身体……"

translate chinese chinese_4074690_1094:
    old "And I never noticed it before, but it has an amazing smell too."
    new "而且我之前也没注意到，它还有一种很棒的香味。"

translate chinese chinese_1429273_1095:
    old "I must admit that it is quite... Enticing."
    new "我必须承认，这确实很...诱人。"

translate chinese chinese_1893743_1096:
    old "Mmm! I bet you can’t wait either [pla]."
    new "嗯！我敢打赌你也很迫不及待吧[pla]。"

translate chinese chinese_0398312_1097:
    old "Oh, don’t worry, we’ll make sure you enjoy the process."
    new "哦，别担心，我们会确保你享受这个过程的。"

translate chinese chinese_5993052_1098:
    old "It really was, I could feel the magic flowing through me, incredible!"
    new "真的太棒了，我能感觉到魔法流遍全身，太神奇了！"

translate chinese chinese_3546451_1099:
    old "That's because there was a lot of magic in the room."
    new "那是因为房间里有很多魔法。"

translate chinese chinese_5054466_1100:
    old "Enough to make the breach and create the portal."
    new "足以制造裂痕并创造传送门。"

translate chinese chinese_1626539_1101:
    old "Does that mean that it worked?"
    new "那意思是不是成功了？"

translate chinese chinese_2371028_1102:
    old "Well, we did everything right. And I made sure to siphon the magic to where we needed it."
    new "好吧，我们一切操作都正确。而且我确保把魔法引导到了我们需要的地方。"

translate chinese chinese_5776268_1103:
    old "But the portal takes some time to form."
    new "但是传送门需要一些时间才能形成。"

translate chinese chinese_2200854_1104:
    old "So, we won't know for a while."
    new "所以，我们得过一段时间才能知道。"

translate chinese chinese_5921719_1105:
    old "Then, there's a chance we may have failed."
    new "那么，我们就可能失败了。"

translate chinese chinese_5336709_1106:
    old "Well, if it did all we have to do is repeat the ritual."
    new "好吧，如果真发生了，我们只需要重复那个仪式就行了。"

translate chinese chinese_0514996_1107:
    old "That's not a problem, if anything happens it would be a good idea."
    new "这没问题，万一有什么事的话，这么做挺好的。"

translate chinese chinese_3273761_1108:
    old "I'm glad you're positive about it."
    new "很高兴你对此持积极态度。"

translate chinese chinese_1142568_1109:
    old "For now let's just wait and see."
    new "还是先看看情况吧。"

translate chinese chinese_9428003_1110:
    old "Girls, I'm sorry to interrupt, but maybe you could help me clean up my friends."
    new "女孩们，不好意思打断你们，但你们能不能帮我清理一下我的朋友们？"

translate chinese chinese_7051796_1111:
    old "We have to make it look as if they were sleeping."
    new "我们必须让他们看起来像是在睡觉。"

translate chinese chinese_8551347_1112:
    old "Sure, let's do that."
    new "行，我们就这么办。"

translate chinese chinese_7650933_1113:
    old "Done, now your friends are clean."
    new "好了，现在你的朋友们干净了。"

translate chinese chinese_3791089_1114:
    old "Thank you for your help girls."
    new "谢谢你们的帮助。"

translate chinese chinese_9864602_1115:
    old "Listen, [pla] since the ritual is done, we have nothing else to do here tonight."
    new "听着，[pla]，既然仪式已经结束了，今晚我们这里没什么好做的了。"

translate chinese chinese_5824785_1116:
    old "We'll leave and pay attention to see if we feel any changes in the magic concentration in the air."
    new "我们先离开，注意观察空气中魔法浓度是否有变化。"

translate chinese chinese_6528122_1117:
    old "You make sure there's no problem here."
    new "你确保这里没有问题。"

translate chinese chinese_5785986_1118:
    old "Alright, I'm gonna wait for my friends to wake up."
    new "好吧，我就等我的朋友们醒过来。"

translate chinese chinese_6482506_1119:
    old "Hmm, given all the power that went through them, they won't wake up until the morning."
    new "嗯，考虑到她们经历了那么多，恐怕要到早上才能醒过来。"

translate chinese chinese_3021224_1120:
    old "Ohh man... Really?"
    new "哦 man... 真的吗？"

translate chinese chinese_9745659_1121:
    old "Yeap, I guess so."
    new "嗯，我想是这样。"

translate chinese chinese_1461870_1122:
    old "Well, I have no option... Otherwise, it would be really weird for them to wake up without me around."
    new "好吧，我也没别的选择……不然他们醒来发现我不在会很奇怪的。"

translate chinese chinese_0499423_1123:
    old "Yeah, you are right."
    new "嗯，你说得对。"

translate chinese chinese_4166700_1124:
    old "Alright, that's all, it's time for us to leave. Let's go."
    new "好了，就这样吧，我们该走了。走吧。"

translate chinese chinese_3583753_1125:
    old "Thanks for... Everything."
    new "谢谢你……一切。"

translate chinese chinese_6463938_1126:
    old "Good bye [pla]."
    new "再见[pla]。"

translate chinese chinese_8350049_1127:
    old "[pla]? What happened?"
    new "[pla]？发生什么事了？"

translate chinese chinese_8180310_1128:
    old "I can't remember anything."
    new "我什么都记不起来了。"

translate chinese chinese_4829003_1129:
    old "What the hell? We fell asleep?"
    new "怎么回事？我们睡着了？"

translate chinese chinese_7486806_1130:
    old "I think we just fell asleep after playing."
    new "我觉得我们是玩着玩着就睡着了。"

translate chinese chinese_8904773_1131:
    old "I also just woke up."
    new "我也是刚醒。"

translate chinese chinese_0685539_1132:
    old "We just fell asleep?"
    new "我们就这样睡着了？"

translate chinese chinese_3466894_1133:
    old "Uhh yeah, you know, it was pretty late."
    new "嗯嗯，你知道的，那会已经很晚了。"

translate chinese chinese_7829815_1134:
    old "Hmm, I guess that makes sense. "
    new "嗯，我想说得通。"

translate chinese chinese_2041806_1135:
    old "Hey, I think it's better if we just go home, it's already morning, and someone may come."
    new "嘿，我觉得咱们还是回家吧，都早上啦，万一有人来就不好了。"

translate chinese chinese_4189000_1136:
    old "You're right, we shouldn't worry our parents."
    new "你说得对，我们不应该让父母担心。"

translate chinese chinese_2216978_1137:
    old "That's true, see you later then."
    new "那倒是，那回头见。"

translate chinese chinese_6069206_1138:
    old "I still don't get why I can't remember anything, but anyway, I guess I'll go home, later."
    new "我还是不明白为什么什么都记不起来，不过算了，我想我还是先回家吧。"

translate chinese chinese_6281087_1139:
    old "I think I'll also be on my way, bye [pla]."
    new "我想我也该走了，再见[pla]。"

translate chinese chinese_4922796_1140:
    old "Bye girls."
    new "再见了，姑娘们。"

translate chinese chinese_7494461_1141:
    old "Oh, you're finnally here."
    new "哦，你终于来了。"

translate chinese chinese_5988604_1142:
    old "Good morning, I'm glad you are fine. I just wanted to thank you for everything you did."
    new "早上好，很高兴你一切都好。我只是想感谢你做的一切。"

translate chinese chinese_6639052_1143:
    old "Oh, you don't have to thank me, I'm a Sexnote owner, that's my mission."
    new "哦，不用谢我，我是Sexnote的主人，这是我的使命。"

translate chinese chinese_3267184_1144:
    old "That's right, however you have done a lot you didn't have to."
    new "没错，不过你做了很多本不必做的事情。"

translate chinese chinese_9756431_1145:
    old "And everything was for us, to save and protect us."
    new "而这一切都是为了我们，为了拯救和保护我们。"

translate chinese chinese_6307524_1146:
    old "All right. Now we just have to wait to see if everything worked..."
    new "好吧。现在我们只能等待看看一切是否奏效..."

translate chinese chinese_2459602_1147:
    old "How much would it takes?"
    new "需要多少？"

translate chinese chinese_1257422_1148:
    old "To be honest I don't know... It's the first time someone tries to create a magic generation point."
    new "说实话，我也不知道……这是第一次有人试图创造一个魔法生成点。"

translate chinese chinese_3500102_1149:
    old "It could take, hours, days, weeks or months, the only thing we can do now is wait.."
    new "这可能需要几个小时、几天、几周甚至几个月，我们现在唯一能做的就是等待.."

translate chinese chinese_0478032_1150:
    old "Oh, man... I was expecting a faster result."
    new "哦， man... 我本来期待结果能快一点。"

translate chinese chinese_1647839_1151:
    old "Actually, I'm pretty sure, that is everthing worked, we could notice a change in the whole area, and it won't take long for sure."
    new "实际上，我敢肯定，如果一切顺利，我们会注意到整个区域的变化，而且肯定不会花很长时间。"

translate chinese chinese_2000259_1152:
    old "Yeah, don't worry, this time we did it right. And all of this thanks to you."
    new "嗯，别担心，这次我们做得对。这一切都要感谢你。"

translate chinese chinese_2151597_1153:
    old "I'm glad to had helped."
    new "我很高兴能帮忙。"

translate chinese chinese_9354110_1154:
    old "All right, I think you should rest. I can see you pretty tired."
    new "好吧，我觉得你应该休息一下。我看得出来你很累。"

translate chinese chinese_0442213_1155:
    old "You're right, I did slept well last night... Thank you and see you later."
    new "你说得对，我昨晚确实睡得很好……谢谢你，再见。"

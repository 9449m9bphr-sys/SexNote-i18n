# auto-tl Qwen Colab

translate chinese chinese_0026703_0:
    old "Uhh, I didn't sleep well last night... I should drink a cup of water... "
    new "呃，我昨晚没睡好……我应该喝杯水……"

translate chinese chinese_7358551_1:
    old "Oh, hi honey, good morning!"
    new "哦，早上好亲爱的！"

translate chinese chinese_5671745_2:
    old "Uhh, good morning..."
    new "呃，早上好……"

translate chinese chinese_0231321_3:
    old "Do you have everything ready for tonight?"
    new "今晚的东西都准备好了吗？"

translate chinese chinese_5152049_4:
    old "T- onight?"
    new "今-晚？"

translate chinese chinese_4888326_5:
    old "The halloween party is tonight... Don't you have your costume already?"
    new "万圣节派对今晚举行……你的 cosplay 服装还没准备好吗？"

translate chinese chinese_0844126_6:
    old "Ohh... Right, I completely forget about that... Ehmm no, actually I don't have a costume yet..."
    new "哦……对了，我完全忘了那件事……嗯，其实我还没弄好 cosplay 呢……"

translate chinese chinese_1718402_7:
    old "Oh, don't worry, Talk with [sis], she was the one who got us our costumes, she could have one for you too."
    new "哦，别担心，和[sis]聊聊吧，她是我们服装的提供者，也能给你准备一套。"

translate chinese chinese_6243851_8:
    old "Oh, great, I'm going to talk with her. Thank you!"
    new "哦，太好了，我要去和她聊聊。谢谢！"

translate chinese chinese_9200065_9:
    old "You are welcome honey."
    new "别客气，甜心。"

translate chinese chinese_7111602_10:
    old "Ohhh... Wow..."
    new "哦哦…… wow……"

translate chinese chinese_0280068_11:
    old "Ohh, hey [pla]! How do I look with this costume?"
    new "哦，嘿 [pla]！这套 cosplay 我穿上怎么样？"

translate chinese chinese_0697146_12:
    old "Where is your [mo1rel]?"
    new "你的[mo1rel]在哪里？"

translate chinese chinese_8143793_13:
    old "Where is [mo1]?"
    new "[mo1]在哪里？"

translate chinese chinese_0455632_14:
    old "Hmm she is in the kitchen... Why?"
    new "嗯，她在厨房……为什么？"

translate chinese chinese_2743823_15:
    old "Perfect. Do you wanna see the fun thing about this costume?"
    new "完美。你想看看这个 cosplay 的有趣之处吗？"

translate chinese chinese_8072733_16:
    old "The fun... Thing? What do you mean?"
    new "那个好玩……的东西？你是说什么？"

translate chinese chinese_5941769_17:
    old "Hahaha, you are going to love it!"
    new "哈哈，你会爱上它的！"

translate chinese chinese_3482517_18:
    old "Hmm a- alright..."
    new "嗯，好啦……"

translate chinese chinese_5289433_19:
    old "Well, I chose this costume for just one reason, it has a tail. Do you see it?"
    new "好吧，我选这个 cosplay 服装只有一个原因，它有个尾巴。你看出来了吗？"

translate chinese chinese_8308136_20:
    old "Hmm... Yes."
    new "嗯……是的。"

translate chinese chinese_6665667_21:
    old "Ok, now I'm going to take it out."
    new "好，现在我要把它拿出来。"

translate chinese chinese_1531526_22:
    old "You are going to wha-"
    new "你要去做什么——"

translate chinese chinese_5978190_23:
    old "I wanted something like this from a long time ago... Did you know I have never try anal sex?"
    new "我很久以前就想要这样了……你知道我从来没试过肛交吗？"

translate chinese chinese_8349996_24:
    old "Well I wanna change that today... I want you to fuck my ass..."
    new "好吧，今天我就想改变这个……我想让你操我的屁股……"

translate chinese chinese_5675062_25:
    old "Uhhh [pla], do it gently... Is my first time..."
    new "呃呃[pla]，轻点……这是我第一次……"

translate chinese chinese_3598348_26:
    old "Wow, it was better than I thought, and your big cock didn't hurt me at all..."
    new "wow，比我想象的要好，而且你那么大的家伙居然一点都没疼……"

translate chinese chinese_5664252_27:
    old "I did it gently..."
    new "我是轻点做的……"

translate chinese chinese_5543993_28:
    old "Definitely we need to repeat it."
    new "肯定得再来一次。"

translate chinese chinese_7530539_29:
    old "Uhh... O- ok."
    new "呃……好。"

translate chinese chinese_9450587_30:
    old "Anyway, I have work, see you later [pla]."
    new "反正我得去工作了，再见[pla]。"

translate chinese chinese_8971613_31:
    old "Wait... Hmm I came, because I need a halloween costume."
    new "等一下……嗯，我来是因为我需要一个万圣节 costumes。"

translate chinese chinese_6472021_32:
    old "Ohh, your costume? Is in your bedroom."
    new "哦，你的 cosplay 服装？在你的卧室里。"

translate chinese chinese_8352204_33:
    old "Oh really?"
    new "哦是吗？"

translate chinese chinese_8544120_34:
    old "Yes, I left it there a few minutes ago."
    new "是的，我几分钟前放那里的。"

translate chinese chinese_5689075_35:
    old "Ohh, thank you so much."
    new "哦，真是太感谢了。"

translate chinese chinese_4583719_36:
    old "You're welcome. You will like that costume, it's perfect for you."
    new "不客气。你会喜欢那套 cosplay 服装的，非常适合你。"

translate chinese chinese_0521047_37:
    old "Hmm... Alright."
    new "嗯……好吧。"

translate chinese chinese_5963803_38:
    old "Uhh, yes."
    new "呃，是的。"

translate chinese chinese_3616960_39:
    old "Hmm could you please come for a minute?"
    new "嗯，你能过来一下吗？"

translate chinese chinese_8516409_40:
    old "Ohhh wow!"
    new "哦哦，真厉害！"

translate chinese chinese_2654192_41:
    old "I'm sorry... Is just that this costume is a bit hard to dress up... Could you please help me with that?"
    new "对不起……就是这个 cosplay 服装穿起来有点困难……你能帮我一下吗？"

translate chinese chinese_4959541_42:
    old "Uhh... S- sure."
    new "呃……好吧。"

translate chinese chinese_3233807_43:
    old "Thank you. You are a sweetheart!"
    new "谢谢你，你真甜！"

translate chinese chinese_8651978_44:
    old "Ok... Let's see..."
    new "好……让我想想……"

translate chinese chinese_9409653_45:
    old "Well, I think is done..."
    new "嗯，我觉得差不多完了……"

translate chinese chinese_5973581_46:
    old "Oh, it's perfect just like in the box picture!"
    new "哦，和盒子上的图片一模一样！"

translate chinese chinese_2261939_47:
    old "Oh, wait... It doesn't cover up my nipples at all..."
    new "哦，等一下……根本没遮住我的乳头……"

translate chinese chinese_6209676_48:
    old "Maybe it is a bit small for me...  What do you think [pla]?"
    new "maybe它对我来说确实有点小……你觉得呢，[pla]？"

translate chinese chinese_9889306_49:
    old "(Oh God, I just had sex! How can I get this horny again?..."
    new "（天啊，我刚才刚做完……怎么又这么快就想了？..."

translate chinese chinese_8704573_50:
    old "[pla]? Are you-... Oh, you got hard-"
    new "[pla]？你……哦，你硬了"

translate chinese chinese_7448563_51:
    old "Sorry... I didn't mean to-"
    new "对不起……我无意于"

translate chinese chinese_1832708_52:
    old "Oh, honey don't worry... You got hard for my tits?"
    new "哦，亲爱的别担心……你为我的胸部硬起来了？"

translate chinese chinese_3753714_53:
    old "Ok, what about if I help you with them?"
    new "好，要是我帮你处理这些呢？"

translate chinese chinese_7141426_54:
    old "Get naked and let me return you the help."
    new "脱光衣服让我回报你的帮助。"

translate chinese chinese_3426817_55:
    old "Do you like my boobs honey?"
    new "你喜欢我的胸部吗，宝贝？"

translate chinese chinese_3174376_56:
    old "Uhh.... Y- yes... I love your boobs."
    new "呃……是的……我喜欢你的胸部。"

translate chinese chinese_6143923_57:
    old "Then fuck them!"
    new "那就操他们！"

translate chinese chinese_7404363_58:
    old "Do you feel better now honey?"
    new "你现在感觉好点了吗，亲爱的？"

translate chinese chinese_9654583_59:
    old "Y- yes... Thank you."
    new "是的……谢谢。"

translate chinese chinese_5598765_60:
    old "No, thanks to you for your help with this costume. By the way did you talk with [sis]?"
    new "不，谢谢你帮忙弄这个 cosplay。对了，你和[sis]说话了吗？"

translate chinese chinese_0696177_61:
    old "Uhh... W- with [sis]..."
    new "呃……和[sis]……"

translate chinese chinese_3432039_62:
    old "Yes, about your costume."
    new "是关于你的 cosplay 服装。"

translate chinese chinese_6159793_63:
    old "Ohhh the costume, right... Yes, I have it in my bedroom, I need to try it"
    new "哦哦，那个 cosplay 服装，对……是的，我放在卧室里了，我要去试试看"

translate chinese chinese_6234662_64:
    old "Oh great, then go, if you need any help just let me know. Now I'm going to clean this mess."
    new "哦好，那你去吧，如果需要帮忙就告诉我。我现在要去收拾这个烂摊子了。"

translate chinese chinese_1238542_65:
    old "Alright, Thank you."
    new "好的，谢谢。"

translate chinese chinese_0226643_66:
    old "(Alright, I should try the costume.)"
    new "（好吧，我应该试试这套服装。）"

translate chinese chinese_9363533_67:
    old "Hmm, it looks a bit weird... What is this? Maybe I'm doing something wrong, I better ask [sis]."
    new "嗯，看起来有点奇怪……这是什么？可能是我做错了，我还是去问问[sis]吧。"

translate chinese chinese_1352618_68:
    old "Hey, I was looking for you."
    new "嘿，我一直在找你。"

translate chinese chinese_2923678_69:
    old "Oh, you have your costume! You look great!"
    new "哦，你穿上了 cosplay 服装！你看起来很棒！"

translate chinese chinese_5002706_70:
    old "Thank you, but I was wondering what is t-"
    new "谢谢，不过我在想t是什么——"

translate chinese chinese_3654271_71:
    old "Hmm your costume is not ready..."
    new "嗯，你的服装还没准备好……"

translate chinese chinese_0440599_72:
    old "You need to get hard to fill the snake."
    new "你需要硬起来才能填满那条蛇。"

translate chinese chinese_7325794_73:
    old "F- fill the snake? "
    new "填——填蛇？"

translate chinese chinese_5289992_74:
    old "You always have to be that slow?"
    new "你总是这么慢吗？"

translate chinese chinese_3715482_75:
    old "Alright, let me give you a blowjob to make you hard-"
    new "好吧，让我给你口交让你硬起来-"

translate chinese chinese_8230040_76:
    old "Hi guys, what are you doing?"
    new "大家好，你们在干什么？"

translate chinese chinese_3803822_77:
    old "(Oh shit...)"
    new "（哦shit...）"

translate chinese chinese_9635775_78:
    old "Well, [pla] needs help with his costume..."
    new "嗯，[pla] 的 cosplay 需要帮忙……"

translate chinese chinese_6711670_79:
    old "Oh really, what does he need?"
    new "哦真的，他需要什么？"

translate chinese chinese_5187762_80:
    old "He needs to get hard to fill his costume."
    new "他需要硬起来才能把那套衣服撑起来。"

translate chinese chinese_0297425_81:
    old "Oh, the snake will become to anaconda?"
    new "哦，这条蛇会变成树蚺吗？"

translate chinese chinese_0645366_82:
    old "(What the hell!?)"
    new "（怎么回事！？）"

translate chinese chinese_8682627_83:
    old "Exactly! I was thinking in a blowjob. What do you think?"
    new "没错！我在想一个口交。你觉得呢？"

translate chinese chinese_1127940_84:
    old "What about a double blowjob, I think that would make him hard for all night!"
    new "双人口交怎么样，我觉得那样能让他整晚都硬！"

translate chinese chinese_1029764_85:
    old "(WHAT THE FUCK IS GOING ON?!)"
    new "（这到底是怎么回事?!）"

translate chinese chinese_1348547_86:
    old "Great idea!"
    new "好主意！"

translate chinese chinese_6966697_87:
    old "[pla]?"
    new "[pla]?"

translate chinese chinese_6034315_88:
    old "Uhh...  W- what is happening?"
    new "呃……发生什么了？"

translate chinese chinese_2094677_89:
    old "Hahaha, let's show him what is happening [sis]..."
    new "哈哈哈哈哈，让我们给他展示一下发生了什么[sis]..."

translate chinese chinese_3387888_90:
    old "OHHHH SHITT...."
    new "噢哦哦 坏了...."

translate chinese chinese_3810142_91:
    old "I- I REALLY CAN BELIEVE IT..."
    new "我—我真的不敢相信……"

translate chinese chinese_0501082_92:
    old "(OH GOD I'M DEAD.)"
    new "（天啊，我要死了。）"

translate chinese chinese_0819799_93:
    old "I can't believe all of you started the party without me..."
    new "真不敢相信你们竟然没有我就开始聚会了……"

translate chinese chinese_7569946_94:
    old "WHAAAAATTT...."
    new "WHAAAAATTT...."

translate chinese chinese_6597063_95:
    old "There is more for you too..."
    new "你还有更多的……"

translate chinese chinese_4729501_96:
    old "We will give you the best spot."
    new "我们会给你最好的位置。"

translate chinese chinese_8936816_97:
    old "And what are we waiting for? Let's enjoy!"
    new "那我们在等什么？开始享受吧！"

translate chinese chinese_6978720_98:
    old "This is just a halloween party..."
    new "这只是一个万圣节派对……"

translate chinese chinese_0896489_99:
    old "Don't you want to join us?"
    new "你不想要加入我们吗？"

translate chinese chinese_1268992_100:
    old "You can't lose this chance..."
    new "你可别错过这个机会..."

translate chinese chinese_9407353_101:
    old "... What the hell... Let's do it!"
    new "... 这是什么情况... 做吧！"

translate chinese chinese_0720936_102:
    old "Oh God... I can't anymore"
    new "哦天哪……我受不了了"

translate chinese chinese_2062351_103:
    old "Hey [pla], we want to keep fucking."
    new "嘿[pla]，我们还想继续做爱。"

translate chinese chinese_3108236_104:
    old "Hmm... I- I just can't... I'm really tired..."
    new "嗯……我——我真的不能……我真的很累……"

translate chinese chinese_9888441_105:
    old "Oh no honey, you don't understand."
    new "哦不，亲爱的，你不懂的。"

translate chinese chinese_8432454_106:
    old "You fucked us, now is our turn to fuck you."
    new "你坑了我们，现在轮到我们来坑你了。"

translate chinese chinese_1491629_107:
    old "We want to fuck you..."
    new "我们想操你..."

translate chinese chinese_1917215_108:
    old "Just like you did..."
    new "就像你做的那样..."

translate chinese chinese_3669913_109:
    old "We are going to drill you."
    new "我们要好好训练你。"

translate chinese chinese_8370171_110:
    old "Wow... It was just a nightmare... Thank God."
    new "wow... 原来只是个噩梦... 谢天谢地。"

translate chinese chinese_5308461_111:
    old "Hmm... Actually it wasn't a nightmare at all..."
    new "嗯……实际上那根本不是噩梦……"

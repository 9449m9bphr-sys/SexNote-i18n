# auto-tl Qwen Colab

translate chinese chinese_7018656_0:
    old "Did you see my notes report?!"
    new "你看到我的笔记报告了吗？！"

translate chinese chinese_5927604_1:
    old "You're a fucking moron!"
    new "你真是个白痴！"

translate chinese chinese_5202864_2:
    old "{i}'Oh yeah, I know all the topics, I'll for sure help you get better...'{/i}"
    new "{i}“哦对，我知道所有的话题，我一定会帮你变好的……”{/i}"

translate chinese chinese_1219274_3:
    old "{b}*Sigh*{/b} Honestly..."
    new "{b}*叹气*{/b} 真是的..."

translate chinese chinese_6084505_4:
    old "B- but, I- I really did teach you what was needed for the exam... I mean, I did well..."
    new "B-但是，我-我真的教了你考试需要的东西……我的意思是，我教得挺好的……"

translate chinese chinese_7529692_5:
    old "Are you suggesting that I'm dumb? Or that it was my fault?"
    new "你是说我傻吗？还是说这是我的错？"

translate chinese chinese_6754938_6:
    old "No, no, what I'm saying is that..."
    new "不，不，我的意思是说……"

translate chinese chinese_6427485_7:
    old "You assured me that if I spent time with you and let you do 'that' to me..."
    new "你保证过，如果我花时间和你在一起，让你那样对我……"

translate chinese chinese_9401771_8:
    old "... You were going to help me pass the exams."
    new "……你本来要帮我通过考试的。"

translate chinese chinese_1126652_9:
    old "But I ended up failing anyway!"
    new "但我最后还是失败了！"

translate chinese chinese_3649424_10:
    old "If you didn't actually understand the subjects, you could've just told me that..."
    new "如果你真的不懂这些科目，直接告诉我就行了……"

translate chinese chinese_2945679_11:
    old "That way I wouldn't have wasted my time with you."
    new "那样我就不至于浪费时间和你在一起了。"

translate chinese chinese_1947910_12:
    old "But I don't know what happened, I explained it to you just like [pla] did with m-..."
    new "但是我不知道发生了什么，我跟你解释的就跟[pla]跟我讲的一样..."

translate chinese chinese_5949733_13:
    old "What? [pla]? What does he have to do with all this?"
    new "什么？[pla]？他和这一切有什么关系？"

translate chinese chinese_4770279_14:
    old "N- nothing, nothing, I meant that I also helped him and he had a good result on the exam..."
    new "没、没什么，我的意思是我也帮了他，他考试成绩很好……"

translate chinese chinese_0281358_15:
    old "Maybe you just didn't understand the topics I explained well."
    new "maybe你只是没有理解我解释的话题。"

translate chinese chinese_0202321_16:
    old "Hey man... That sounded rough. What's going on?"
    new "嘿，听起来挺严重的。怎么回事？"

translate chinese chinese_0005724_17:
    old "Apparently, she did really poorly on the last set of exams we took."
    new "看来她在上次的考试中表现得很差。"

translate chinese chinese_2274454_18:
    old "And now she's blaming me!"
    new "而现在她还在怪我！"

translate chinese chinese_6453376_19:
    old "Like it's my fault..."
    new "好像这事都是我的错一样……"

translate chinese chinese_8594857_20:
    old "Well, you did promise her you'd help her with her exams."
    new "好吧，你确实答应过帮她复习考试。"

translate chinese chinese_4136191_21:
    old "But you didn't really follow through..."
    new "但是你并没有真正去做……"

translate chinese chinese_7058560_22:
    old "W- well, t- that's just because..."
    new "嗯，那个，那只是因为..."

translate chinese chinese_4487270_23:
    old "I don't know, man, I really helped her!"
    new "我真的帮了她，兄弟。"

translate chinese chinese_0097732_24:
    old "I- I mean, I even got good grades, man!"
    new "我——我的意思是，我甚至还考得很好，伙计！"

translate chinese chinese_4227366_25:
    old "Well, yeah, but it doesn't matter how well you did."
    new "嗯，是啊，但你的表现如何并不重要。"

translate chinese chinese_0942643_26:
    old "What matters is that she didn't do well."
    new "重要的是她表现得不好。"

translate chinese chinese_7257847_27:
    old "I think you just didn't know how to explain the subjects to her."
    new "我觉得你只是不知道怎么向她解释这些话题。"

translate chinese chinese_9300161_28:
    old "Alright! You don't have to repeat what she said!"
    new "好了！你不用重复她说的话！"

translate chinese chinese_6033824_29:
    old "Besides, I don't think you get to say anything to me, this is your fault after all."
    new "再说，我觉得你也没资格说我，这明明是你的错。"

translate chinese chinese_1600092_30:
    old "Excuse me? What's that supposed to mean?"
    new "抱歉？那是什么意思？"

translate chinese chinese_1659536_31:
    old "What I said! You were supposed to explain the subjects to me so that I could help Olivia!"
    new "我说的！你应该给我解释清楚这些内容，这样我才能帮奥利维亚啊！"

translate chinese chinese_3301742_32:
    old "But look at the results she got."
    new "但看看她得到的结果。"

translate chinese chinese_8607024_33:
    old "That has nothing to do with me!"
    new "这和我无关！"

translate chinese chinese_3883659_34:
    old "If she didn't learn anything, it's just because you're such a shit teacher!"
    new "如果她什么都没学到，那只是因为你是这么烂的老师！"

translate chinese chinese_6425573_35:
    old "Maybe you should've taught her properly instead of spending your time staring at her tits."
    new "也许你应该好好教她，而不是一直盯着她的胸部看。"

translate chinese chinese_8051699_36:
    old "Yeah well, whatever the reason is, she's super angry with me now."
    new "好吧，不管什么原因，她现在超级生我的气。"

translate chinese chinese_7837203_37:
    old "If she fails the coming exams, that's going to really suck, man."
    new "如果她接下来考试不及格，那就惨了。"

translate chinese chinese_2811087_38:
    old "Well, it would be bad, but she'll have other chances to pass."
    new "嗯，虽然不好，但她还有其他机会及格。"

translate chinese chinese_0930228_39:
    old "What? That's not what I mean, dude."
    new "什么？那不是我的意思，伙计。"

translate chinese chinese_8173363_40:
    old "If she fails, she'll just blame me, and I won't be able to move forward with her."
    new "如果她失败了，就会怪到我头上，我就没法再跟她进一步了。"

translate chinese chinese_5615596_41:
    old "I'm so close to hooking up with her, dude, so close."
    new "我快和她上床了，兄弟，真的快了。"

translate chinese chinese_1545527_42:
    old "She was just about to let me hit it, and now this."
    new "她刚才都快让我上了，结果现在这样。"

translate chinese chinese_3493129_43:
    old "... Sure, dude."
    new "……行吧，兄弟。"

translate chinese chinese_2742959_44:
    old "Hey, come on, let's go to class."
    new "嘿，快点，我们去上课吧。"

translate chinese chinese_7199194_45:
    old "You can keep worrying about this later."
    new "你可以等会再担心这个。"

translate chinese chinese_8513510_46:
    old "Yeah... Okay."
    new "嗯……好。"

translate chinese chinese_8184542_47:
    old "Hey [pla]! Wait!"
    new "喂，[pla]！等一下！"

translate chinese chinese_4553535_48:
    old "Uh, yeah? Do you need something?"
    new "嗯，有什么事吗？"

translate chinese chinese_5526581_49:
    old "Yeah, I need to talk to you about something."
    new "嗯，我有件事想和你谈谈。"

translate chinese chinese_3338658_50:
    old "Uh... Alright, what is it?"
    new "呃……好吧，什么事？"

translate chinese chinese_6243655_51:
    old "Well, as you probably already know."
    new "好吧，你可能已经知道了。"

translate chinese chinese_1788963_52:
    old "I've been having some problems with my grades lately."
    new "我最近成绩有些问题。"

translate chinese chinese_0026082_53:
    old "Hmph, I mean... I haven't really paid attention to what you've been doing or anything..."
    new "哼，我的意思是……我其实没怎么注意你在做什么……"

translate chinese chinese_1982938_54:
    old "Oh please, don't pretend you haven't talked with that dumbass Mike."
    new "哦拜托，别装作你没和那个蠢货迈克聊过天。"

translate chinese chinese_7397199_55:
    old "I know he told you about him giving me lessons in the subjects I'm failing, so don't play dumb."
    new "我知道他告诉过你，他给我补习那些我挂掉的科目，所以别装傻。"

translate chinese chinese_4622263_56:
    old "Well, he did mention something about that."
    new "嗯，他确实提过这件事。"

translate chinese chinese_0955315_57:
    old "But what about it?"
    new "但是那又怎样？"

translate chinese chinese_6469446_58:
    old "The thing is, I haven't really learned much of anything."
    new "问题是，我其实什么都没学到。"

translate chinese chinese_7162913_59:
    old "Because he's so fucking bad at teaching!"
    new "因为他教得太差了！"

translate chinese chinese_0198996_60:
    old "But on the last exams, I did notice his grades got better."
    new "但是说到上次的考试，我倒是注意到他的成绩有所提高。"

translate chinese chinese_1176595_61:
    old "I thought that was strange, very strange."
    new "我觉得那很奇怪，非常奇怪。"

translate chinese chinese_4094401_62:
    old "While spending time with him, I realized he's not the brightest guy."
    new "和他在一起的时候，我意识到他不是最聪明的家伙。"

translate chinese chinese_2009447_63:
    old "Actually, he's a fucking idiot!"
    new "实际上，他真是个白痴！"

translate chinese chinese_2156096_64:
    old "Okay, okay, but what does this have to do with me?"
    new "好啦好啦，但这和我有什么关系？"

translate chinese chinese_9824080_65:
    old "As I told you, spending time with your friend made me realize he's a fucking idiot."
    new "就像我告诉你的，和他在一起让我意识到，他真是个白痴。"

translate chinese chinese_8303955_66:
    old "It just didn't make sense to me that he would suddenly make such an improvement in his grades."
    new "我就是想不通他为什么会突然成绩提高这么多。"

translate chinese chinese_7991405_67:
    old "So, I met him under the pretense that it was a date."
    new "所以，我以约会为借口见了他。"

translate chinese chinese_1786428_68:
    old "And I pushed him until he spilled the beans about how he'd suddenly managed to get good grades in the exams."
    new "我逼他说出了突然考试成绩变好的原因。"

translate chinese chinese_0823584_69:
    old "After a while, he confessed that he wasn't any good at studying."
    new "过了一会儿，他承认自己不擅长学习。"

translate chinese chinese_9908582_70:
    old "But that it was thanks to YOU that he was able to get better grades."
    new "但他的成绩能提高，多亏了你。"

translate chinese chinese_8574794_71:
    old "T- that's what he told you?"
    new "那、那是他告诉你的？"

translate chinese chinese_7603201_72:
    old "He did! And I should've known from the start that his grades didn't get better because of him!"
    new "他确实做到了！而且从一开始我就应该知道他的成绩没有进步是因为他本人！"

translate chinese chinese_1736305_73:
    old "But anyway, that's not what I care about."
    new "不过话说回来，那不是我关心的重点。"

translate chinese chinese_1681604_74:
    old "Because I'm still stuck with my bad grades."
    new "因为我还是摆脱不了这些糟糕的成绩。"

translate chinese chinese_6018841_75:
    old "I got to thinking about it."
    new "我一直在想这件事。"

translate chinese chinese_3701901_76:
    old "Well, if you were able to teach that dumbass Mike enough to get good scores on the exams."
    new "好吧，如果你能教那个笨蛋迈克足够的知识，让他考试得高分。"

translate chinese chinese_9383161_77:
    old "You should be more than capable of bringing me to the top of the class."
    new "你应该完全有能力让我成为班上的顶尖学生。"

translate chinese chinese_2582256_78:
    old "Yeah, I mean, thanks for the compliment."
    new "嗯，谢谢你的夸奖。"

translate chinese chinese_0238204_79:
    old "But, why would I do that?"
    new "但是，我为什么要那样做？"

translate chinese chinese_6507878_80:
    old "In case you don't remember, every time you and Ruby are around."
    new "如果你不记得了，每次你和Ruby在一起的时候。"

translate chinese chinese_0427880_81:
    old "You attack and bully my friends and me. The only thing you know how to do is be rude to us."
    new "你攻击欺负我和我的朋友，你只会对我们粗鲁。"

translate chinese chinese_0931338_82:
    old "Especially towards Belle and Hinn."
    new "特别是对贝拉和赫恩。"

translate chinese chinese_7725615_83:
    old "So no, I think I'll pass."
    new "所以不了，我觉得我还是算了吧。"

translate chinese chinese_8277441_84:
    old "So that's how it is... Either way, you HAVE to help me whether you like it or not."
    new "原来是这样……不管怎样，你都得帮我，不管你愿不愿意。"

translate chinese chinese_3880759_85:
    old "And why would that be?"
    new "那会为什么呢？"

translate chinese chinese_0594630_86:
    old "I'll tell you why."
    new "我告诉你为什么。"

translate chinese chinese_4042096_87:
    old "You better help me, or I'll spill what I know."
    new "你最好帮我，不然我就把我知道的都抖出来了。"

translate chinese chinese_7921111_88:
    old "And everyone will know just what kind of guy you are and the stuff you’re up to."
    new "大家都会知道你是什么样的人，还有你在做什么。"

translate chinese chinese_2743335_89:
    old "But I want to make something clear."
    new "但我有件事要说明白。"

translate chinese chinese_3496476_90:
    old "If I do this, you can't bring it up ever again, no matter what."
    new "如果我做了这件事，你就永远不能再提起来，无论发生什么。"

translate chinese chinese_4310750_91:
    old "SO, after I'm done helping you, you can't tell anyone about it!"
    new "所以，等我帮你完了，你可不能告诉任何人这件事！"

translate chinese chinese_5599818_92:
    old "Are we clear?"
    new "清楚了吗？"

translate chinese chinese_8848618_93:
    old "Sure, I don't care about you or what you're doing."
    new "行吧，我不管你做什么。"

translate chinese chinese_8693061_94:
    old "So I won't tell anyone."
    new "所以我不告诉任何人。"

translate chinese chinese_6634891_95:
    old "But that's only if I do well on the exams."
    new "但这只有在我考试表现好的情况下才行。"

translate chinese chinese_1271031_96:
    old "So you better outdo Mike, for your own sake."
    new "所以为了你自己，你最好超过迈克。"

translate chinese chinese_4007071_97:
    old "Hmph, sure."
    new "哼，好吧。"

translate chinese chinese_9166543_98:
    old "So... Should I go to your house?"
    new "所以……我应该去你家吗？"

translate chinese chinese_5253079_99:
    old "No, today's not a good day."
    new "不，今天不行。"

translate chinese chinese_3343168_100:
    old "There are a couple of things I have to deal with at home."
    new "家里有几件事我要处理一下。"

translate chinese chinese_2006065_101:
    old "Just keep your schedule open for now, and I'll let you know when we can start."
    new "先空出你的日程，等我们可以开始的时候我会通知你。"

translate chinese chinese_9697898_102:
    old "Hmm, alright..."
    new "嗯，好吧……"

translate chinese chinese_0430528_103:
    old "Ok, see you later then. Bye."
    new "好吧，那回头见。再见。"

translate chinese chinese_5462044_104:
    old "{b}*Sigh*{/b} This is something I wasn't expecting."
    new "{b}*叹气*{/b} 这是我没想到的。"

translate chinese chinese_8614845_105:
    old "What a fucking situation this is..."
    new "真是个操蛋的局面……"

translate chinese chinese_5781085_106:
    old "{b}*Sigh*{/b} I guess I'll head home."
    new "{b}*叹气*{/b} 算了，我还是回家吧。"

translate chinese chinese_8681785_107:
    old "Oh, h- hi dude, what's up?"
    new "哦，嗨，最近怎么样？"

translate chinese chinese_1473443_108:
    old "I'm alright, but hey, don't dodge the question."
    new "我挺好的，不过别躲问题啊。"

translate chinese chinese_7091308_109:
    old "What were you doing talking to my girl?"
    new "你刚才跟我女朋友说什么呢？"

translate chinese chinese_2283522_110:
    old "Are you trying to snatch her from me?"
    new "你在试图从我这里抢走她吗？"

translate chinese chinese_6222971_111:
    old "{i}(Snatch her from him? So... He still thinks he has a chance with her? Is he serious?){/i}"
    new "{i}(把她从他身边抢过来？他还以为自己有机会吗？他是认真的吗？){/i}"

translate chinese chinese_4352891_112:
    old "It's not what you think, dude. She was just asking me for my notes from class."
    new "不是你想的那样，哥们。她只是问我借了课堂笔记。"

translate chinese chinese_0323195_113:
    old "Well, I think she just wants to do some extra studying, and she asked for my notes."
    new "嗯，我觉得她只是想多学一会儿，所以问我借了笔记。"

translate chinese chinese_2391879_114:
    old "And why your notes? She could've asked for mine..."
    new "而且为什么要你的笔记？她可以要我的啊……"

translate chinese chinese_1329387_115:
    old "Your notes? Do you even have any notes?"
    new "你的笔记？你还有笔记吗？"

translate chinese chinese_5416261_116:
    old "Did you even bring a notebook today?"
    new "你今天带笔记本了吗？"

translate chinese chinese_0880827_117:
    old "Well, I- I didn't."
    new "嗯，我——我没。"

translate chinese chinese_0878636_118:
    old "I understand, dude, but still, I hope you're not thinking of using this to take my girl away from me!"
    new "我懂，兄弟，但话说回来，我希望你不要动什么歪心思想把我女朋友抢走！"

translate chinese chinese_2091813_119:
    old "Don't worry, dude..."
    new "别担心，伙计..."

translate chinese chinese_3696155_120:
    old "I assure you that's not on my mind."
    new "我保证那根本不在我的脑海里。"

translate chinese chinese_1797229_121:
    old "Alright, I'll believe you."
    new "好吧，我相信你。"

translate chinese chinese_0132053_122:
    old "We're pretty close, you know?"
    new "你知道吗，我们关系挺好的？"

translate chinese chinese_6774406_123:
    old "In no time she'll be mine, don't doubt it."
    new "很快她就会是我的，别怀疑。"

translate chinese chinese_0919799_124:
    old "Sure dude, no doubt..."
    new "行吧，没问题……"

translate chinese chinese_6414143_125:
    old "Anyway, I have to go home now, are you leaving too?"
    new "总之，我现在得回家了，你也走吗？"

translate chinese chinese_2238053_126:
    old "Yeah sure, let's go."
    new "行吧，走吧。"

translate chinese chinese_3166413_127:
    old "Oh, damn, I'm really late. Has the class already ended?"
    new "哦，糟了，我真的迟到了。课已经结束了吗？"

translate chinese chinese_4369667_128:
    old "Oh, look who decided to show up. Class ended a while ago, dumbass."
    new "哦，看谁决定要出现了。课早就结束了，白痴。"

translate chinese chinese_2188835_129:
    old "Oh crap, I totally lost track of time..."
    new "哦crap，我完全忘了时间……"

translate chinese chinese_7051640_130:
    old "Really? I hadn't noticed. It's not like anyone wants to see your ugly face around here."
    new "真的吗？我还没注意到呢。这里又没人想看到你那张丑脸。"

translate chinese chinese_9467751_131:
    old "{b}*Sigh*{/b} Really? Do you want to do this now?"
    new "{b}*叹气*{/b} 真的吗？你现在想做这个？"

translate chinese chinese_2548723_132:
    old "What? Not feeling brave without your little friends around?"
    new "什么？没有你的小伙伴就不敢勇敢了吗？"

translate chinese chinese_5919562_133:
    old "You know? I don't have time to deal with you right now."
    new "你知道吗？我现在没时间理你。"

translate chinese chinese_6456289_134:
    old "Can you believe that loser?"
    new "你能相信那个家伙吗？"

translate chinese chinese_4602253_135:
    old "Yeah... What an idiot."
    new "是啊……真够傻的。"

translate chinese chinese_9875439_136:
    old "Hey, listen, I think we'll have to cancel our plans for today."
    new "嘿，听我说，我觉得今天咱们的计划得取消了。"

translate chinese chinese_2586752_137:
    old "I thought you wanted to meet those cute guys today."
    new "我还以为你今天想见那些可爱的家伙呢。"

translate chinese chinese_0648572_138:
    old "I do! I really do."
    new "我真的做过了。我真的做过了。"

translate chinese chinese_9325684_139:
    old "But I just remembered my mom needs me to help her with some stuff at home."
    new "但是我刚想起我妈妈需要我回家帮忙。"

translate chinese chinese_2617401_140:
    old "So I have to go home early."
    new "所以我得早些回家。"

translate chinese chinese_4431537_141:
    old "Hmm, alright, I guess that's okay."
    new "嗯，好吧，我想这样也行。"

translate chinese chinese_4067149_142:
    old "I guess I'll be hanging out with the guys by myself."
    new "看来我要自己和那些家伙们混了。"

translate chinese chinese_5089554_143:
    old "Sure, but next time I'll definitely be going out with you guys."
    new "好吧，但下次我一定会和你们一起去。"

translate chinese chinese_2633286_144:
    old "Alright, I guess that's fine."
    new "好吧，我想这样也行。"

translate chinese chinese_0748624_145:
    old "Yeah?"
    new "是吗？"

translate chinese chinese_8123044_146:
    old "Listen, I was thinking today could be a good day for you to come over."
    new "听着，我在想今天你可以过来，会是个好日子。"

translate chinese chinese_1463652_147:
    old "So we can start studying."
    new "这样我们就可以开始学习了。"

translate chinese chinese_8006376_148:
    old "W- what... Now?"
    new "什...什么...现在？"

translate chinese chinese_9094835_149:
    old "Yes, why? I told you to clear your schedule."
    new "是的，为什么？我让你清空日程了。"

translate chinese chinese_3656329_150:
    old "No, no, you just caught me off guard."
    new "不，不，你只是把我吓到了。"

translate chinese chinese_1627666_151:
    old "Well, you don't have to come if you don't want to."
    new "好吧，你不想来就不来了。"

translate chinese chinese_6750048_152:
    old "That is, if you don't care about everyone knowing you're fucking Mike's mom."
    new "也就是说，如果你不在乎每个人都知道你在和迈克的妈妈上床。"

translate chinese chinese_7829059_153:
    old "{i}(Damn... She's got some attitude.){/i}"
    new "{i}(真够呛……她态度很强硬。){/i}"

translate chinese chinese_5941442_154:
    old "{b}*Sigh*{/b} Alright, let's go to your house."
    new "{b}*叹气*{/b} 好吧，去你家吧。"

translate chinese chinese_5891625_155:
    old "Oh, m- mom, you're here."
    new "哦，妈，你在这里。"

translate chinese chinese_1820017_156:
    old "I- I thought you were going to be out this afternoon."
    new "我—我以为你今天下午会出去。"

translate chinese chinese_1717659_157:
    old "That was the plan, but the appointment got canceled, so I just came back home."
    new "本来是这么打算的，但预约取消了，所以我直接回家了。"

translate chinese chinese_5721886_158:
    old "But anyway honey, who's your friend here? Aren't you going to introduce me to him?"
    new "不过亲爱的，这位是你的朋友吗？你不打算介绍我认识一下吗？"

translate chinese chinese_7250846_159:
    old "Well... Yeah."
    new "嗯……是的。"

translate chinese chinese_1587505_160:
    old "His name is [pla], he's a friend from school."
    new "他的名字是[pla]，他是学校的朋友。"

translate chinese chinese_9339358_161:
    old "[pla], this is my mother, her name's Priya."
    new "[pla]，这是我的母亲，她叫Priya。"

translate chinese chinese_6141743_162:
    old "Hello Mrs. Priya, nice to meet you."
    new "你好，普里亚夫人，很高兴见到你。"

translate chinese chinese_3753108_163:
    old "Nice to meet you too, [pla]."
    new "也很高兴见到你，[pla]。"

translate chinese chinese_1485524_164:
    old "[pla]'s going to help me study some topics for school."
    new "[pla]要帮我复习一些学校的课题。"

translate chinese chinese_8599832_165:
    old "You know, some exams are coming up, and I want to do well."
    new "你知道，有些考试快来了，我想考好。"

translate chinese chinese_9981685_166:
    old "And [pla] here is a great student. He always gets top grades."
    new "而[pla]是个优秀的学生，他总是拿最高分。"

translate chinese chinese_0408275_167:
    old "So I asked him to help me."
    new "所以我请他帮忙。"

translate chinese chinese_3049301_168:
    old "Oh, that's so good to hear, honey!"
    new "哦，听到这个真好，亲爱的！"

translate chinese chinese_5635220_169:
    old "I'm so glad you're finally taking your studies seriously."
    new "真高兴你终于认真对待学习了。"

translate chinese chinese_6702606_170:
    old "Your father's going to be very pleased if you do well in school, you know that."
    new "你知道的，如果你学习好，你爸爸会很高兴的。"

translate chinese chinese_8660532_171:
    old "Yeah, yeah, I know what he wants..."
    new "嗯嗯，我知道他想要什么……"

translate chinese chinese_8390750_172:
    old "Honey, don't take that attitude."
    new "亲爱的，别摆出那副态度。"

translate chinese chinese_0568011_173:
    old "I know your father can be hard to deal with sometimes."
    new "我知道你爸爸有时候很难对付。"

translate chinese chinese_9929634_174:
    old "But you have to understand that he just wants what's best for you."
    new "但你得明白，他只是想对你好。"

translate chinese chinese_7561844_175:
    old "As do I."
    new "我也是。"

translate chinese chinese_5984957_176:
    old "So, I'm very happy to see you making an effort to improve your grades."
    new "所以，看到你在努力提高成绩，我非常高兴。"

translate chinese chinese_1321499_177:
    old "Yeah... Thank you."
    new "嗯……谢谢。"

translate chinese chinese_5550935_178:
    old "Hey mom, [pla] and I are going to study in my room, alright?"
    new "妈，我和[pla]要去我房间学习，好吗？"

translate chinese chinese_4378590_179:
    old "Sure thing, sweetie."
    new "没问题，亲爱的。"

translate chinese chinese_3002889_180:
    old "I'm sorry you had to see that."
    new "对不起让你看到这个。"

translate chinese chinese_5501636_181:
    old "I wasn't expecting my mom to be here."
    new "我没想到我妈妈会在这里。"

translate chinese chinese_8697015_182:
    old "It's okay."
    new "没关系。"

translate chinese chinese_9845811_183:
    old "You don't have to apologize."
    new "你不用道歉。"

translate chinese chinese_9680479_184:
    old "Anyway, I guess it's a good thing she met you right away."
    new "不管怎样，我想她一开始就遇到你也是好事。"

translate chinese chinese_0068901_185:
    old "That will make things easier in the future."
    new "这会让将来的事情变得容易些。"

translate chinese chinese_6647288_186:
    old "So, should we get to it?"
    new "那，我们开始吧？"

translate chinese chinese_7478903_187:
    old "Okay, let's start with this topic."
    new "好吧，我们就从这个话题开始。"

translate chinese chinese_3943437_188:
    old "And we'll work our way to the others. Alright?"
    new "然后我们会一个个解决其他的。好吗？"

translate chinese chinese_4403650_189:
    old "Uhh... Sure, whatever you say."
    new "呃……好吧，随便你了。"

translate chinese chinese_6968571_190:
    old "See? This is the right way to prove that result."
    new "看？这才是证明那个结果的正确方法。"

translate chinese chinese_9789678_191:
    old "I see, that makes a lot of sense."
    new "我明白了，这说得通。"

translate chinese chinese_2560950_192:
    old "Alright, I think we can move on to the next topic!"
    new "好吧，我觉得我们可以进入下一个话题了！"

translate chinese chinese_1669678_193:
    old "I never could have guessed you'd be so good at this, you know?"
    new "你知道吗，我真没想到你会这么擅长这个。"

translate chinese chinese_5751613_194:
    old "I know, everyone assumes that just because I'm pretty and popular, I'm just an airhead..."
    new "我知道，每个人都以为我既漂亮又受欢迎，就一定是空有其表……"

translate chinese chinese_1523826_195:
    old "But everyone is wrong, I'm not dumb at all..."
    new "但是大家错了，我一点都不笨..."

translate chinese chinese_8202432_196:
    old "Even if it doesn't look like it, I do pay attention, just to what really interests me."
    new "即使看起来不是这样，我确实会在意，只是在意真正让我感兴趣的东西。"

translate chinese chinese_4255433_197:
    old "Uhh... What do you mean?"
    new "呃……你的意思是什么？"

translate chinese chinese_3332608_198:
    old "Well, I want to be a fashion designer, and for that, I don't need to memorize differential calculus formulas, you know what I mean?"
    new "好吧，我想当个服装设计师，为此我不需要记住微积分公式，你知道我的意思吧？"

translate chinese chinese_3546566_199:
    old "Hmm, so why do you want to improve your grades now?"
    new "嗯，那你现在为什么想提高成绩呢？"

translate chinese chinese_2214733_200:
    old "Is it because of what you were talking to your mom about your dad?"
    new "是因为你和妈妈谈到你爸爸的事情了吗？"

translate chinese chinese_6877870_201:
    old "Hmm, well, yeah... Something like that."
    new "嗯，好吧，是的……差不多就是那样。"

translate chinese chinese_4690695_202:
    old "But wait!"
    new "但是等一下！"

translate chinese chinese_0907737_203:
    old "What does this have to do with you?"
    new "这跟你有什么关系？"

translate chinese chinese_2637780_204:
    old "How about we stop with the questions and get back to studying?"
    new "要不咱们别问了，回去学习吧？"

translate chinese chinese_4191171_205:
    old "Hmm, yeah right, let's keep going."
    new "嗯，好吧，咱们继续吧。"

translate chinese chinese_3579084_206:
    old "Alright, it was just our first session, but we got a lot done."
    new "好吧，虽然只是第一次见面，但我们已经做了很多了。"

translate chinese chinese_1421963_207:
    old "We're very short on time."
    new "我们时间非常紧迫。"

translate chinese chinese_2231333_208:
    old "But I think at this pace, we should be able to cover everything we need to before the exams."
    new "但是我觉得以这个进度，我们应该能在考试前把所有需要的内容都复习完。"

translate chinese chinese_1596706_209:
    old "Hey sis, can I borrow your blue dress today for a- "
    new "姐，今天能借我你的蓝裙子吗？我要去——"

translate chinese chinese_9876573_210:
    old "Oh, I didn't know you had company..."
    new "哦，我不知道你有客人……"

translate chinese chinese_9563614_211:
    old "What were you two doing in here? Does Dad know you're bringing boys into your room?"
    new "你们两个在里面干什么？爸爸知道你把男生带到房间里吗？"

translate chinese chinese_1727775_212:
    old "We were studying... And it's none of your business..."
    new "我们在学习……而且不关你的事……"

translate chinese chinese_4398295_213:
    old "Oh Olivia, where are your manners? You should introduce us."
    new "哦，奥利via，你的礼貌去哪儿了？你应该介绍我们一下。"

translate chinese chinese_4143837_214:
    old "Hi, my name is Ayeshaa, nice to meet you."
    new "你好，我叫Ayeshaa，很高兴认识你。"

translate chinese chinese_1182095_215:
    old "Uhh, hi, nice to meet you too, my name's [pla]."
    new "呃，你好，也很高兴见到你，我叫[pla]。"

translate chinese chinese_4487522_216:
    old "Alright, alright, what have I told you about coming into my room unannounced?"
    new "好了好了，我跟你说过多少次了，不要擅自闯进我的房间？"

translate chinese chinese_2762321_217:
    old "I just wanted to see if you could let me borrow the dress—"
    new "我只是想看看你能不能让我借那条裙子——"

translate chinese chinese_8451543_218:
    old "No, you can't borrow my blue dress."
    new "不，你不能借我的蓝色裙子。"

translate chinese chinese_2003096_219:
    old "Now get the hell out of here."
    new "现在滚出去。"

translate chinese chinese_8064311_220:
    old "Ugh, why do you always have to have that nasty attitude?!"
    new "哎，你为什么总是这么臭脾气！"

translate chinese chinese_0008996_221:
    old "You know what? I actually hope you screw up your grades..."
    new "你知道吗？我其实希望你的成绩搞砸……"

translate chinese chinese_0810441_222:
    old "So dad will take you to India with him!"
    new "所以爸爸会带你一起去印度！"

translate chinese chinese_8411934_223:
    old "Maybe then you'll learn some humility."
    new "也许这样你就能学会一些谦虚了。"

translate chinese chinese_1154589_224:
    old "Alright, alright!"
    new "好啦好啦！"

translate chinese chinese_1031210_225:
    old "Bye, cutie."
    new "再见，可爱。"

translate chinese chinese_0639688_226:
    old "B- bye..."
    new "拜...拜..."

translate chinese chinese_6539957_227:
    old "I'm sorry about that."
    new "对不起这件事。"

translate chinese chinese_4816635_228:
    old "She's just a brat, and my mom always lets her get away with everything, that's why she acts like that."
    new "她就是个熊孩子，我妈妈总是让她为所欲为，所以她才那样。"

translate chinese chinese_6343870_229:
    old "Uhh... S- sure, no problem."
    new "呃……好，没问题。"

translate chinese chinese_3148871_230:
    old "Uhmm, by the way, w- what she said about you going to India..."
    new "嗯，对了，她刚才说你要去印度……"

translate chinese chinese_3313633_231:
    old "I told you! I'm not talking about that!"
    new "我跟你说过！我不是在说那个！"

translate chinese chinese_4046428_232:
    old "Anyway, I think we were done studying for today, right?"
    new "总之，我觉得今天的学习到此为止了吧？"

translate chinese chinese_3160957_233:
    old "Uhh, yeah, we made good progress today, but we still have more to do. You need to get a high grade to boost your average..."
    new "嗯，是的，今天我们进展不错，但还有很多要做的。你需要拿高分来提高平均分……"

translate chinese chinese_3237619_234:
    old "I know you're worried, but I think we can handle it."
    new "我知道你担心，但我觉得我们可以应付过来。"

translate chinese chinese_7401829_235:
    old "If you say so..."
    new "如果你这么说的话……"

translate chinese chinese_1688131_236:
    old "Alright, I think I have to go. So, are afternoons good for you to keep studying?"
    new "好吧，我觉得我得走了。那么，下午对你来说适合继续学习吗？"

translate chinese chinese_2354972_237:
    old "Right, make sure to come by my house in the afternoons. Don't miss it, or you know what will happen..."
    new "好的，记得下午来我家。别错过，不然你知道会发生什么..."

translate chinese chinese_2260076_238:
    old "Yeah, sure, you don't have to remind me."
    new "是的，好的，你不用提醒我。"

translate chinese chinese_0027883_239:
    old "Anyway, see you later."
    new "总之，再见了。"

translate chinese chinese_5864919_240:
    old "Ok, see you."
    new "好，再见。"

translate chinese chinese_0513821_241:
    old "Hey, I was waiting for you. You’re here to help me study, right?"
    new "嘿，我在等你呢。你是来帮我复习的吧？"

translate chinese chinese_3581468_242:
    old "Yeah, I'm here to keep working on the stuff we still need to cover."
    new "是的，我来这里就是为了继续处理我们还没完成的事情。"

translate chinese chinese_0715939_243:
    old "Great! I was getting worried you might take too long to come back."
    new "太好了！我还担心你可能会很久才回来呢。"

translate chinese chinese_3459955_244:
    old "Let's not waste any time and get started."
    new "别浪费时间了，我们开始吧。"

translate chinese chinese_6291499_245:
    old "Alright, let's continue where we left off last time."
    new "好吧，我们接着上次的地方继续。"

translate chinese chinese_8123761_246:
    old "Sure, let's do it."
    new "行，咱们就這麼定了。"

translate chinese chinese_2660725_247:
    old "Alright, I think that's enough for today."
    new "好吧，今天就到这儿吧。"

translate chinese chinese_5263371_248:
    old "We still have some other things to cover, but I'll be back soon so we can continue with what's left."
    new "我们还有一些其他的事情要谈，但我很快会回来继续未完的部分。"

translate chinese chinese_9044353_249:
    old "And then we can move on to the next topic."
    new "然后我们可以进入下一个话题。"

translate chinese chinese_7529612_250:
    old "Alright, sure, thanks for coming."
    new "好吧，谢谢来了。"

translate chinese chinese_4314373_251:
    old "I'll see you soon."
    new "很快见。"

translate chinese chinese_2315743_252:
    old "Hi [pla]! Good morning!"
    new "你好 [pla]！早上好！"

translate chinese chinese_8261854_253:
    old "Hi Mrs. Priya, how are you today?"
    new "嗨，Priya夫人，你今天怎么样？"

translate chinese chinese_7492468_254:
    old "I'm doing alright sweetheart."
    new "我挺好的，甜心。"

translate chinese chinese_8637336_255:
    old "Honey, did you come to see Olivia?"
    new "亲爱的，你是来看奥利维亚的吗？"

translate chinese chinese_5266508_256:
    old "Because right now it's time for school."
    new "因为现在是上学的时间。"

translate chinese chinese_7723761_257:
    old "Shouldn't you be there?"
    new "你不应该在那里吗？"

translate chinese chinese_8680692_258:
    old "Oh, yeah, Mrs. Priya, I just have the day off school to run a couple of errands."
    new "哦，对了，Priya夫人，我今天请假去办几件事。"

translate chinese chinese_6116905_259:
    old "And I wanted to say hi."
    new "而且我还想打个招呼。"

translate chinese chinese_9534177_260:
    old "I see, I'm glad to see you dear."
    new "我明白了，见到你真好。"

translate chinese chinese_5330746_261:
    old "I'll be sure to tell Olivia you stopped by."
    new "我一定会告诉奥利via你来过。"

translate chinese chinese_8679597_262:
    old "Alright, thanks ma'am."
    new "好的，谢谢大姐。"

translate chinese chinese_3377843_263:
    old "Hello, [pla]!"
    new "你好，[pla]！"

translate chinese chinese_0527261_264:
    old "Hi, Mrs. Priya!"
    new "嗨，普里亚夫人！"

translate chinese chinese_3298335_265:
    old "It's good to see you, dear. How are you today?"
    new "见到你真好，亲爱的。今天怎么样？"

translate chinese chinese_2476336_266:
    old "I'm fine, Mrs. Priya, and you?"
    new "我很好，普里娅夫人，您呢？"

translate chinese chinese_8721935_267:
    old "I'm doing alright, dear. Keeping busy as usual, thanks for asking."
    new "我挺好的，亲爱的。像往常一样忙忙碌碌，谢谢关心。"

translate chinese chinese_6882333_268:
    old "Tell me, did you come to see Olivia?"
    new "告诉我，你是来看奥利维亚的吗？"

translate chinese chinese_0726085_269:
    old "Great! She's in her bedroom right now, dear."
    new "太好了！她现在在卧室里，亲爱的。"

translate chinese chinese_9073429_270:
    old "Don't mind me, you can go right in."
    new "别管我，你可以直接进去。"

translate chinese chinese_1645086_271:
    old "Thanks, Mrs. Priya. I'll catch up with you later."
    new "谢谢，普里亚夫人。待会儿再聊。"

translate chinese chinese_8057752_272:
    old "That's alright, dear. Nice seeing you."
    new "没关系，亲爱的。见到你很高兴。"

translate chinese chinese_1880563_273:
    old "And if you kids need anything, just let me know."
    new "你们要是需要什么，就告诉我。"

translate chinese chinese_8519420_274:
    old "Alright, that's it, that's the right method."
    new "好了，就是这样的，这才是正确的方法。"

translate chinese chinese_5170452_275:
    old "Great, you got it!"
    new "太好了，你做到了！"

translate chinese chinese_6392351_276:
    old "You know, we're making very good progress."
    new "你知道吗，我们的进展非常顺利。"

translate chinese chinese_3930467_277:
    old "At this rate we'll manage to go over every topic before the exams."
    new "照这个进度，考试前我们可以把每个话题都复习一遍了。"

translate chinese chinese_3569145_278:
    old "Yeah, ok... Great."
    new "好吧……太好了。"

translate chinese chinese_3275470_279:
    old "That doesn't seem like you're too sure about it."
    new "这听起来你好像不太确定。"

translate chinese chinese_4039674_280:
    old "I just feel like this isn't working [pla]."
    new "我就觉得这根本行不通，[pla]。"

translate chinese chinese_2600488_281:
    old "You just said that you think we'll be able to tackle every topic before the exams."
    new "你刚才说你觉得我们在考试前能搞定每一个话题。"

translate chinese chinese_2347632_282:
    old "But how well am I really going to do in them?"
    new "但我真的能在那些事情上做得好吗？"

translate chinese chinese_4508878_283:
    old "With so little time, there's only so much I can learn."
    new "时间这么少，我学的东西也有限。"

translate chinese chinese_5299187_284:
    old "Come on, don't be so negative."
    new "别这么消极嘛。"

translate chinese chinese_4417286_285:
    old "I know what you mean. But it's worth giving it a shot."
    new "我知道你的意思。但值得一试。"

translate chinese chinese_1112231_286:
    old "I know it is."
    new "我知道是这样的。"

translate chinese chinese_5580925_287:
    old "It's just that when I see how much more we have to study."
    new "只是当我看到我们还有这么多要学的时候。"

translate chinese chinese_2622049_288:
    old "And the time that's left before the exams."
    new "还有考试前剩下的时间。"

translate chinese chinese_5799207_289:
    old "That was just a huge waste of time!"
    new "那真是浪费时间！"

translate chinese chinese_9706187_290:
    old "Hey, hey, come on."
    new "喂，喂，快点。"

translate chinese chinese_2206842_291:
    old "I understand how you feel, but let's not get discouraged."
    new "我理解你的感受，但咱们不要灰心。"

translate chinese chinese_2085977_292:
    old "I'm sure you'll do well in these exams."
    new "我相信你这次考试一定能考好的。"

translate chinese chinese_1955885_293:
    old "I mean... Yeah, it would be very difficult to get perfect scores."
    new "我的意思是……是的，要得满分确实很难。"

translate chinese chinese_7573880_294:
    old "But I'm sure that if we keep studying at this pace, and with a little luck."
    new "但是我相信如果我们继续保持这个学习进度，再加上一点运气。"

translate chinese chinese_1910640_295:
    old "You'll get grades that are good enough for you to pass all the subjects."
    new "你会拿到足以让你通过所有科目的成绩。"

translate chinese chinese_0301508_296:
    old "But that's the problem! I can't just get {i}‘passing grades'{/i}."
    new "但问题就在这里！我不能只拿到{i}“及格分数”{/i}。"

translate chinese chinese_6454630_297:
    old "If I don't get maximum grades, it won't be good enough!"
    new "如果我得不到满分，那就不够好！"

translate chinese chinese_2404340_298:
    old "Uh, ok?"
    new "呃，好？"

translate chinese chinese_1594767_299:
    old "But why, though?"
    new "但是为什么呢？"

translate chinese chinese_5093297_300:
    old "I mean, I understand that studying and grades are important."
    new "我的意思是，我明白学习和成绩很重要。"

translate chinese chinese_6054029_301:
    old "But why is it so important to get the maximum grades?"
    new "但是为什么一定要拿最高分呢？"

translate chinese chinese_3947398_302:
    old "I didn't want to tell you about this, but I guess it's better if you understand the full picture."
    new "我本不想告诉你这件事，但我想还是让你了解整个情况比较好。"

translate chinese chinese_9019437_303:
    old "Listen, if I don't get maximum or top grades by the end of the term, I'll be sent to India to live with my dad."
    new "听着，如果这学期期末我没有拿到最高分，我就得去印度跟我爸爸一起住了。"

translate chinese chinese_0584581_304:
    old "Well, you know my parents are from India, right?"
    new "你知道我父母是印度人吧？"

translate chinese chinese_5241713_305:
    old "Hmm, yeah sure..."
    new "嗯，好吧……"

translate chinese chinese_4397940_306:
    old "See, my father is still living there. He comes here often, but his business is located there."
    new "你看，我父亲还住在那里。他经常过来，但他的生意在那里。"

translate chinese chinese_2731848_307:
    old "While we stay here with my mother."
    new "我们在妈妈这里待着。"

translate chinese chinese_9937867_308:
    old "Well, my dad's a very traditional guy."
    new "嗯，我爸爸是个很传统的人。"

translate chinese chinese_3005461_309:
    old "He cares a lot about upholding tradition and customs."
    new "他非常重视维护传统和习俗。"

translate chinese chinese_6819466_310:
    old "And since I'm the oldest daughter, he wants me to take part in a lot of those traditions."
    new "因为我是最大的女儿，所以他希望我参与很多那些传统活动。"

translate chinese chinese_6543040_311:
    old "Without consulting me or letting me know about it!"
    new "竟然不跟我商量一下，也不通知我！"

translate chinese chinese_4988919_312:
    old "Uh, I- I see."
    new "哦，我——我明白了。"

translate chinese chinese_0329642_313:
    old "B- but, don’t you think if you talked to him, he’d understand you’re not in love with the guy he wants you to marry?"
    new "B-但是，你不觉得如果你和他说清楚，他会明白你并不爱那个他想让你结婚的人吗？"

translate chinese chinese_8754524_314:
    old "{b}*Sigh*{/b} Come on, be realistic."
    new "{b}*叹气*{/b} 快点，现实一点。"

translate chinese chinese_2733666_315:
    old "Love has nothing to do with it [pla]."
    new "这和爱情没关系[pla]。"

translate chinese chinese_4365615_316:
    old "The guy he engaged me to is the heir to a very successful company."
    new "他让我订婚的那个家伙是某个非常成功公司的继承人。"

translate chinese chinese_1091123_317:
    old "He knows that by getting me married to him, he would get a big opportunity to do business."
    new "他知道通过让我嫁给他，就能得到一个很大的商机。"

translate chinese chinese_5405413_318:
    old "He thinks that since I'm the oldest daughter, it is my duty to the family to go through with his plan!"
    new "他认为我是长女，有义务按照他的计划行事！"

translate chinese chinese_3861945_319:
    old "B- but, isn't there anything that you can do?"
    new "B-但是，难道你就没有什么可以做的吗？"

translate chinese chinese_8650002_320:
    old "Well, that's why I need to get good grades."
    new "所以我就得好好学习。"

translate chinese chinese_2384875_321:
    old "My mom's a little more open-minded than my dad. She knows I don't want to live my life that way."
    new "我妈妈比爸爸开明一些。她知道我不想那样生活。"

translate chinese chinese_9240162_322:
    old "She's been supporting me, and interceding on my behalf with my dad."
    new "她一直在支持我，并且替我和我爸爸说情。"

translate chinese chinese_9900163_323:
    old "That's been a huge problem between them, they've been fighting over it."
    new "这一直是他们之间的大问题，他们为此争吵不休。"

translate chinese chinese_5242305_324:
    old "But my mom finally convinced him to let me off the hook if I get good grades by the end of the term."
    new "但是我妈终于说服他，如果我这学期期末成绩好的话就放过我。"

translate chinese chinese_9710781_325:
    old "That's why I'm so desperate to get the highest scores! Because I really have to!"
    new "这就是为什么我那么渴望得到最高分！因为我真的必须做到！"

translate chinese chinese_2920548_326:
    old "I- I see. I understand."
    new "我……我明白了。"

translate chinese chinese_9082522_327:
    old "I didn't know how important the exam results would be for you."
    new "我不知道考试结果对你这么重要。"

translate chinese chinese_3076648_328:
    old "I'm not sure, but I think we can make it so that you'll be able to get the top grades."
    new "我不确定，但我觉得我们可以让你拿到最高分数。"

translate chinese chinese_9217106_329:
    old "Do you really mean it?"
    new "你真是这么想的？"

translate chinese chinese_0173077_330:
    old "I know there's too little time to do this."
    new "我知道时间太少了，没法做这个。"

translate chinese chinese_1842293_331:
    old "But I know we can make it, come on let's keep going!"
    new "但是我知道我们可以做到的，来吧，我们继续前进！"

translate chinese chinese_2656623_332:
    old "Okay, okay."
    new "好啦好啦。"

translate chinese chinese_2605228_333:
    old "I think that's enough for today, but I'll be back soon so we can keep going."
    new "我觉得今天就到这儿吧，但我会很快回来继续的。"

translate chinese chinese_7052843_334:
    old "Don't worry, we'll get this done before you know it."
    new "放心，我们会很快搞定的。"

translate chinese chinese_3214352_335:
    old "You know [pla], I'm not sure about this."
    new "你知道[pla]，我有点不确定。"

translate chinese chinese_7121171_336:
    old "But if you say we can make it, I'll believe you."
    new "但是如果你说我们可以做到，我就相信你。"

translate chinese chinese_5881695_337:
    old "Thanks for the help [pla]."
    new "谢谢你帮忙，[pla]。"

translate chinese chinese_0057856_338:
    old "No problem, I'm happy to help."
    new "没问题，我很乐意帮忙。"

translate chinese chinese_2133050_339:
    old "I'll go for now, but I'll see you later."
    new "我先走了，回头见。"

translate chinese chinese_2352414_340:
    old "Yeah, that's right. Your aunt Fatima said she'd be sending Devika here to spend some time with us."
    new "没错。你阿姨法蒂玛说她会派迪维卡来这里和我们待一段时间。"

translate chinese chinese_1173456_341:
    old "Oh honey, don't make that face."
    new "哎呀，别那样表情嘛。"

translate chinese chinese_0552453_342:
    old "I just don't know if she should come here."
    new "我就不知道她是不是应该来这儿。"

translate chinese chinese_0281524_343:
    old "Where is she going to sleep?"
    new "她打算去哪里睡觉？"

translate chinese chinese_2442624_344:
    old "You don't need to worry about that."
    new "你不用担心那个。"

translate chinese chinese_9513707_345:
    old "Besides, I know you like your cousin. You two used to be very close!"
    new "再说，我知道你喜欢你的表哥。你们以前关系很好！"

translate chinese chinese_5370948_346:
    old "Hmm, that was a long time ago."
    new "嗯，那已经是很久以前的事了。"

translate chinese chinese_7916431_347:
    old "But I guess it's alright if she comes here. I like Aunty Fatima, so it shouldn't be too much of a problem."
    new "不过我想她来这儿也行。我喜欢法蒂玛阿姨，所以问题不大。"

translate chinese chinese_7137966_348:
    old "Uh, s- sorry for interrupting."
    new "呃，对不起打断了。"

translate chinese chinese_7297875_349:
    old "Hi Olivia, I came to continue our study sessions."
    new "奥利维亚，我来继续我们的学习了。"

translate chinese chinese_6487973_350:
    old "[pla], I'm so glad you're here! I was just waiting for you!"
    new "[pla]，你在这里我真是太高兴了！我刚才还在等你呢！"

translate chinese chinese_5486011_351:
    old "Uh... You were?"
    new "呃……你是说你当时在场？"

translate chinese chinese_6780358_352:
    old "W- well, here I am, I guess."
    new "嗯，那我就来了吧。"

translate chinese chinese_0421657_353:
    old "Yeah, I was just waiting for you to make our announcement."
    new "是啊，我就等着你来宣布了。"

translate chinese chinese_0161269_354:
    old "O- our announcement? What do you-"
    new "O-我们的公告？你是什么意思-"

translate chinese chinese_4402019_355:
    old "Mom, there's something that [pla] and I have been wanting to tell you."
    new "妈妈，有件事我和[pla]想告诉你。"

translate chinese chinese_7436521_356:
    old "And we decided this is the right time to do it."
    new "所以我们决定现在是做这件事的时候了。"

translate chinese chinese_3844523_357:
    old "Hmm, o-kay? What is it?"
    new "嗯，好啊？怎么了？"

translate chinese chinese_7981257_358:
    old "Well, you see, the truth is that [pla] isn't actually my friend."
    new "好吧，其实，[pla] 并不是我的朋友。"

translate chinese chinese_3192242_359:
    old "Actually, it would be more accurate to say that he's not only my friend."
    new "其实，更准确地说，他不只是我的朋友。"

translate chinese chinese_1051610_360:
    old "What you just heard, Mom. [pla] and I have been dating for a while now."
    new "刚才你听到的，妈妈。[pla] 和我已经交往一段时间了。"

translate chinese chinese_7586616_361:
    old "I'm sorry, and why hadn't I heard about this until now?"
    new "对不起，为什么我到现在才听说这件事？"

translate chinese chinese_3703707_362:
    old "Because I just wanted to be sure about what he and I feel, and of our relationship."
    new "因为我只是想确认一下他和我的感受，以及我们的关系。"

translate chinese chinese_0601831_363:
    old "Also, I knew that you and Dad wouldn't have approved."
    new "还有，我知道你和爸爸不会同意的。"

translate chinese chinese_7715158_364:
    old "Oh, you think so?"
    new "哦，你是这么认为的？"

translate chinese chinese_1295596_365:
    old "Not only are you dating someone without our approval."
    new "你不仅在没有我们同意的情况下约会别人。"

translate chinese chinese_1031421_366:
    old "Now you also come and tell me like this?"
    new "现在你也这样对我说了？"

translate chinese chinese_7885772_367:
    old "You know full well that this is not how we do things, Olivia!"
    new "你心里清楚这可不是我们的做事方式，奥利维亚！"

translate chinese chinese_0283415_368:
    old "I can't even imagine the face Vihaan's going to make when he finds out about this."
    new "我简直不敢想象维哈安知道这件事会是什么表情。"

translate chinese chinese_5498128_369:
    old "That's precisely why I'm telling you this right now."
    new "这正是我为什么要现在告诉你。"

translate chinese chinese_4997713_370:
    old "Mom, [pla] and I are in love."
    new "妈妈，我和[pla]相爱了。"

translate chinese chinese_0106748_371:
    old "But I know that if I tell Dad about this, he'll never approve of us."
    new "但我知道如果我把这件事告诉爸爸，他永远不会同意我们的关系。"

translate chinese chinese_4049811_372:
    old "So I need your help to convince him that this is okay."
    new "所以我需要你的帮助来说服他这没什么问题。"

translate chinese chinese_3090723_373:
    old "It's not that simple, honey. You know I have no problem with you having a boyfriend."
    new "事情没那么简单，亲爱的。你知道我从不介意你交男朋友。"

translate chinese chinese_3208376_374:
    old "But Vihaan is a lot more traditional than me."
    new "但是维哈an比我要传统得多。"

translate chinese chinese_8398746_375:
    old "And he won't be pleased with this at all."
    new "而他对此绝对不会高兴。"

translate chinese chinese_8634550_376:
    old "I know that, Mom, but I don't want to go along with Dad's plan."
    new "我知道这些，妈妈，但我不想按照爸爸的计划来。"

translate chinese chinese_8061627_377:
    old "You know what he wants..."
    new "你知道他想要什么……"

translate chinese chinese_3703310_378:
    old "If it was up to him, I would already be wedded to that guy he wants me to marry."
    new "要是听他的，我早就被安排嫁给那个他想让我嫁的人了。"

translate chinese chinese_8981538_379:
    old "But I don't want to live my life like that, Mom!"
    new "但是妈妈，我不要那样生活！"

translate chinese chinese_9311785_380:
    old "I don't care about that guy I don't know."
    new "我管那个不认识的家伙干嘛。"

translate chinese chinese_3300835_381:
    old "He's not what I want for my life."
    new "他不是我想要的生活伴侣。"

translate chinese chinese_9697079_382:
    old "[pla] is the one I'm in love with!"
    new "[pla]才是我爱的人！"

translate chinese chinese_9573821_383:
    old "I need your help to convince Dad, please Mom."
    new "我需要你的帮助来说服爸爸，拜托了妈妈。"

translate chinese chinese_6316105_384:
    old "Alright, I can see you're serious about this."
    new "好吧，我看得出来你是认真的。"

translate chinese chinese_9533085_385:
    old "That means you'll help me?"
    new "那也就是说你会帮我了？"

translate chinese chinese_0178233_386:
    old "Well, what choice do I have?"
    new "那我还有什么选择呢？"

translate chinese chinese_7952802_387:
    old "You're putting me in a tough spot right now, honey."
    new "你现在把我放到一个很尴尬的境地了，亲爱的。"

translate chinese chinese_7331280_388:
    old "But I wouldn't want to force your hand."
    new "但我可不想强迫你。"

translate chinese chinese_7537971_389:
    old "And to be honest, I'm not too keen on this whole arranged marriage situation."
    new "说实话，我对这整个包办婚姻的事儿也不是很热衷。"

translate chinese chinese_1261294_390:
    old "So I'll help you with your father for now."
    new "那我先帮你对付你爸爸。"

translate chinese chinese_0814232_391:
    old "That's great, Mom, thank you!"
    new "太好了，妈妈，谢谢你！"

translate chinese chinese_5497665_392:
    old "Yeah well, that's only if you get good grades, you know."
    new "嗯，那也得看你成绩好不好才行。"

translate chinese chinese_9627447_393:
    old "Remember, that's a deal we already made with your father, so don't disappoint us."
    new "记得，这可是你爸爸已经谈好的条件，别让我们失望。"

translate chinese chinese_7853288_394:
    old "Don't worry, I promise you I'm working very hard."
    new "别担心，我保证我在很努力地工作。"

translate chinese chinese_3364717_395:
    old "Come on [pla], let's get to studying."
    new "快来吧[pla]，我们开始学习吧。"

translate chinese chinese_8363647_396:
    old "Uh, I- Uh... S- see to you later, Mrs. Priya."
    new "呃，我- 嗯... S-再见了，普里亚夫人。"

translate chinese chinese_4471395_397:
    old "Ok, that went well."
    new "好吧，这还算是顺利。"

translate chinese chinese_3999078_398:
    old "Would you mind telling me what this business of us dating is about?"
    new "你能告诉我我们约会这件事到底是怎么回事吗？"

translate chinese chinese_2607365_399:
    old "Well, you heard me talking to my mom."
    new "好吧，你听到我跟我妈说话了。"

translate chinese chinese_3802645_400:
    old "Listen, after the last time you came here, I got to thinking about how much work is still left to do."
    new "听着，上一次你来之后，我一直在想还有很多事情需要做。"

translate chinese chinese_0672386_401:
    old "And I got worried about the possibility of not finishing it."
    new "我还担心可能完不成呢。"

translate chinese chinese_8915286_402:
    old "So I figured I needed a contingency plan in case my grades don't turn out to be good."
    new "所以我想我需要一个备选计划，以防我的成绩不好。"

translate chinese chinese_6613505_403:
    old "So you came up with the idea of us dating? How is that going to help?"
    new "所以你是想出我们约会这个主意的？这怎么会有帮助呢？"

translate chinese chinese_5417828_404:
    old "Think about it [pla], if I can convince my Dad that I'm in love with you."
    new "想想吧，[pla]，如果我能说服我爸爸，说我爱上你了。"

translate chinese chinese_8632738_405:
    old "And that things are serious enough for me to consider marrying you."
    new "而且事情已经严重到我考虑要娶你的地步了。"

translate chinese chinese_3592842_406:
    old "Maybe he'll give up on trying to push me into that marriage."
    new "也许他会放弃逼我结婚了。"

translate chinese chinese_9199085_407:
    old "I'm sorry, is this a problem for you?"
    new "对不起，这对你来说是个问题吗？"

translate chinese chinese_8259190_408:
    old "No, not really. I promised to help you with this, and I get what you're doing."
    new "不，不是真的。我答应过要帮你，我也明白你在做什么。"

translate chinese chinese_8928415_409:
    old "So it's alright, I'll help you with it."
    new "那好吧，我来帮你。"

translate chinese chinese_4434116_410:
    old "Thanks [pla], you have no idea how much I appreciate you saying that."
    new "谢谢[pla]，你不知道我有多感激你这么说。"

translate chinese chinese_8094936_411:
    old "I'm happy to help you."
    new "我很乐意帮你。"

translate chinese chinese_1033799_412:
    old "Now, let's get to studying, to ensure that you don't need your contingency plan."
    new "好了，现在让我们开始学习，确保你不需要用到备选计划。"

translate chinese chinese_5336850_413:
    old "Ugh! This is pointless!"
    new "哎！这根本没用！"

translate chinese chinese_0819778_414:
    old "W-what? What do you mean?"
    new "什、什么？你什么意思？"

translate chinese chinese_9761249_415:
    old "I'm talking about this whole studying for exams thing!"
    new "我说的是这整个考试复习的事情！"

translate chinese chinese_0228350_416:
    old "It's pointless!"
    new "这根本没用！"

translate chinese chinese_1478762_417:
    old "W- why do you say that?"
    new "你为什么这么说？"

translate chinese chinese_2268131_418:
    old "Think about it, [pla]..."
    new "想想吧，[pla]..."

translate chinese chinese_4135730_419:
    old "Look at how much I still have to do!"
    new "看看我还有多少事情要做！"

translate chinese chinese_1722788_420:
    old "There are so many topics!"
    new "话题这么多！"

translate chinese chinese_9747287_421:
    old "There's no way I can cram all of this into my head before the exams!"
    new "考试前我根本记不住这么多东西！"

translate chinese chinese_8468709_422:
    old "Oh! Olivia is with her boyfriend in her room again?"
    new "哦！奥利via又和她的男朋友在房间里吗？"

translate chinese chinese_3300643_423:
    old "I wonder what they talk about when they're alone..."
    new "真想知道他们单独在一起时都聊些什么……"

translate chinese chinese_3000867_424:
    old "Or maybe they're doing some dirty stuff?"
    new "或者他们在干些见不得人的事？"

translate chinese chinese_2242909_425:
    old "I guess a little eavesdropping won't hurt."
    new "我想偷听一下也不会有什么大碍。"

translate chinese chinese_9649074_426:
    old "I can see why you're worried."
    new "我能理解你为什么担心。"

translate chinese chinese_0772099_427:
    old "But you still have to try."
    new "但你还是得试试。"

translate chinese chinese_5445681_428:
    old "Look at how much work you've put in already."
    new "看看你已经付出了多少努力了。"

translate chinese chinese_2606154_429:
    old "You can't give up now."
    new "你现在不能放弃。"

translate chinese chinese_0312218_430:
    old "I know I've put in a lot of work, [pla]."
    new "我知道我付出了很多努力，[pla]。"

translate chinese chinese_3615434_431:
    old "But come on, there's no way I'm going to be able to learn all of this before the exams."
    new "但是拜托，考试前我怎么可能学得完这些。"

translate chinese chinese_0422374_432:
    old "{i}(Hmm, I guess they're talking about her grades.){/i}"
    new "{i}（嗯，他们大概是在谈论她的成绩。）{/i}"

translate chinese chinese_1029949_433:
    old "{i}(She seems to be struggling.){/i}"
    new "{i}(她好像很挣扎。){/i}"

translate chinese chinese_9147629_434:
    old "{i}(Ha! That's great!){/i}"
    new "哈哈！太好了！"

translate chinese chinese_0883642_435:
    old "{i}(When Dad finds out, he'll bring her to India right away!){/i}"
    new "{i}（爸爸知道后会马上带她去印度！）{/i}"

translate chinese chinese_2995460_436:
    old "{i}(She'll finally get what she deserves!){/i}"
    new "{i}（她终于会得到她应得的了！){/i}"

translate chinese chinese_0746338_437:
    old "I get it, I know you're stressed and frustrated."
    new "我明白，我知道你压力很大，也很沮丧。"

translate chinese chinese_1477974_438:
    old "But come on, you can't give up."
    new "但是别放弃啊。"

translate chinese chinese_4994490_439:
    old "I don't know, I think we should make another plan."
    new "我不知道，我觉得我们应该再想个别的计划。"

translate chinese chinese_1697821_440:
    old "{i}(W-what? What is she talking about?){/i}"
    new "({i}什么？她在说什么？{/i})"

translate chinese chinese_9293588_441:
    old "{i}(He's not her boyfriend?){/i}"
    new "{i}(他不是她的男朋友？){/i}"

translate chinese chinese_7507746_442:
    old "{i}(Oh, this is too good!){/i}"
    new "噢，这真是太好了！"

translate chinese chinese_9159483_443:
    old "Hey sis! How are you?"
    new "嘿姐！最近怎么样？"

translate chinese chinese_2108557_444:
    old "{b}*Sigh*{/b} What do you want?"
    new "{b}*叹气*{/b} 你想要什么？"

translate chinese chinese_4138797_445:
    old "Oh, not much."
    new "哦，没什么。"

translate chinese chinese_5107056_446:
    old "I was just walking down the hallway a minute ago."
    new "我刚才还在走廊里走着呢。"

translate chinese chinese_3274931_447:
    old "And I accidentally overheard something about [pla] here not being your boyfriend."
    new "而且我无意中听到这里说你男朋友不是[pla]。"

translate chinese chinese_6909482_448:
    old "I wonder what that's about?"
    new "不知道那是怎么回事？"

translate chinese chinese_6619960_449:
    old "I- I don't know what you're talking about."
    new "我- 我不知道你在说什么。"

translate chinese chinese_8813523_450:
    old "Oh yeah, I bet you don't."
    new "哦，是吗，我敢打赌你不会。"

translate chinese chinese_5762863_451:
    old "You know, dad's going to be very displeased about this."
    new "你知道的，爸爸会对这件事非常不高兴。"

translate chinese chinese_0264313_452:
    old "I can already imagine his face when I tell him that you're apparently faking having a boyfriend."
    new "我都能想象当他听说你假装有男朋友时的表情了。"

translate chinese chinese_5244488_453:
    old "I can't wait."
    new "我等不及了。"

translate chinese chinese_8844949_454:
    old "W-wait! You don't understand."
    new "等一下！你误会了。"

translate chinese chinese_8439981_455:
    old "I think you misheard us or something."
    new "我觉得你是听错了什么。"

translate chinese chinese_1717884_456:
    old "Oh no, don't give me that. I didn't mishear anything!"
    new "哦不，别这样。我没听错！"

translate chinese chinese_6141810_457:
    old "You know, I thought it was strange."
    new "你知道吗，我觉得这很奇怪。"

translate chinese chinese_5025710_458:
    old "When you suddenly brought a boyfriend home."
    new "当你突然带了个男朋友回家的时候。"

translate chinese chinese_0150991_459:
    old "And not only that, from one moment to the next, you decided to start studying."
    new "而且不止这些，你突然间决定开始学习了。"

translate chinese chinese_3416527_460:
    old "When I had never seen you take your studies seriously."
    new "我从来没见过你认真对待学习。"

translate chinese chinese_8458580_461:
    old "I see now that this is just a ploy to avoid going to India with dad, isn't it?"
    new "我现在明白了，这不过是不想和爸爸一起去印度的借口罢了，对吧？"

translate chinese chinese_5960765_462:
    old "{i}(W-wow, she's sharp. She figured it out just like that!){/i}"
    new "({i}哇哦，她真敏锐。一下子就看出来了！{/i})"

translate chinese chinese_7329645_463:
    old "Ugh, shut up! This has nothing to do with that!"
    new "哎呀，闭嘴！这根本没关系！"

translate chinese chinese_8411478_464:
    old "Now get out of my room before I throw you out!"
    new "现在给我滚出我的房间，不然我把你扔出去！"

translate chinese chinese_1648571_465:
    old "Oh, I'll get out of here!"
    new "哦，我赶紧走吧！"

translate chinese chinese_6150286_466:
    old "And I'll go call Dad right away!"
    new "我这就去给我爸打电话！"

translate chinese chinese_1702182_467:
    old "With all the work Dad's doing to grant you a future!"
    new "爸爸为了给你一个未来做了这么多！"

translate chinese chinese_3459884_468:
    old "And this is how you decide to repay him, by lying to him!"
    new "这就是你回报他的方式，竟然对他撒谎！"

translate chinese chinese_1668540_469:
    old "I can't wait to let him know how bad his favorite daughter really is!"
    new "我迫不及待要让他知道他最疼爱的女儿有多坏了！"

translate chinese chinese_7545267_470:
    old "Yes? What do you want?"
    new "怎么了？你想干什么？"

translate chinese chinese_8947985_471:
    old "{b}*Sigh*{/b} If I prove to you that he's my boyfriend, will you shut up and not talk to Dad?"
    new "{b}*叹气*{/b} 如果我证明他是我男朋友，你就闭嘴不跟爸爸说了吗？"

translate chinese chinese_4633886_472:
    old "Hmm... Maybe, if you can convince me, of course."
    new "嗯……也许吧，如果你能说服我的话。"

translate chinese chinese_9585139_473:
    old "I swear to God, one day."
    new "我发誓，总有一天。"

translate chinese chinese_9256725_474:
    old "Here I come, [pla]..."
    new "我来了，[pla]..."

translate chinese chinese_7320576_475:
    old "There, are you happy?"
    new "好了，你现在满意了吧？"

translate chinese chinese_0202926_476:
    old "What? Happy?"
    new "什么？开心？"

translate chinese chinese_4899642_477:
    old "I could kiss him right now too."
    new "我现在也想吻他。"

translate chinese chinese_0615445_478:
    old "That doesn't prove anything!"
    new "那根本证明不了什么！"

translate chinese chinese_5050834_479:
    old "What are you insinuating?"
    new "你这是什么意思？"

translate chinese chinese_0750631_480:
    old "Come on sis, prove to me that you're really a couple."
    new "喂，姐，证明给我看你们真的是情侣。"

translate chinese chinese_1465949_481:
    old "What do you mean by that?"
    new "你这话是什么意思？"

translate chinese chinese_1774092_482:
    old "Oh come on! I knew you were dumb, but I didn't think this much."
    new "Oh come on! 我知道你笨，但没想到这么笨。"

translate chinese chinese_8875616_483:
    old "W- what? What are you talking about? Do you think I just go around doing that?"
    new "什、什么？你在说什么？你以为我是那种人吗？"

translate chinese chinese_0479321_484:
    old "I don't do that sort of thing!"
    new "我可不做那种事！"

translate chinese chinese_9510545_485:
    old "Don't treat me like I'm stupid!"
    new "别把我当傻子看待！"

translate chinese chinese_9306672_486:
    old "Maybe Mom and Dad are willing to buy your {i}‘nice girl'{/i} act..."
    new "也许爸妈愿意买你{i}“好女孩”{/i}的那套把戏……"

translate chinese chinese_9218889_487:
    old "But I know who you really are!"
    new "但我知道你究竟是谁！"

translate chinese chinese_5981699_488:
    old "H- hey, hey! L- let's not get carried away, girls."
    new "喂，喂！别激动，姑娘们。"

translate chinese chinese_3817081_489:
    old "Stay out of this!"
    new "别管这事！"

translate chinese chinese_7602755_490:
    old "Listen, you little bitch."
    new "听着，你这小贱人。"

translate chinese chinese_3676716_491:
    old "First, be very careful about who you're calling a whore."
    new "首先，叫人家婊子可得小心点。"

translate chinese chinese_6803385_492:
    old "Second, there must be something really wrong with your head if you want to see me fuck this guy in front of you."
    new "第二，如果你真想看到我和这家伙在你面前做那种事，那你的脑子一定有问题。"

translate chinese chinese_6622152_493:
    old "And if you think I'll let you watch that."
    new "如果你以为我会让你看那个。"

translate chinese chinese_8425670_494:
    old "So why don't you get the hell out of here?!"
    new "那你还不出去！"

translate chinese chinese_8403345_495:
    old "Oh, I can leave, I told you I have no problem with that."
    new "哦，我可以走，我告诉你我没问题的。"

translate chinese chinese_5840771_496:
    old "But you know what I'll do right away!"
    new "但是你知道我接下来会做什么！"

translate chinese chinese_3362122_497:
    old "Because I don't have any proof that this guy is your real boyfriend."
    new "因为我没有任何证据证明这家伙是你真正的男朋友。"

translate chinese chinese_1598963_498:
    old "Thinking about it, right now it must be early morning in India."
    new "想想现在应该是印度的清晨。"

translate chinese chinese_7515137_499:
    old "Daddy must be waiting for me to send him his good morning message."
    new "爸爸肯定在等我发早安消息给他。"

translate chinese chinese_3760659_500:
    old "I'm sure he'll appreciate the extra news!"
    new "我相信他会 appreciate 这些额外的消息的！"

translate chinese chinese_4263264_501:
    old "{i}({b}*Sigh*{/b} I can't believe this...){/i}"
    new "{i}({b}*叹气*{/b} 我真不敢相信这会发生……){/i}"

translate chinese chinese_5197822_502:
    old "Listen you..."
    new "听着你这..."

translate chinese chinese_8814091_503:
    old "I'm NOT going to have sex with this guy in front of you."
    new "我可不会在他面前和你做那种事。"

translate chinese chinese_4433670_504:
    old "But if I do something sexual with him..."
    new "但是要是我和他发生性关系……"

translate chinese chinese_0195237_505:
    old "Will you stop saying he's not my boyfriend and leave us alone?"
    new "你能不能别再说他不是我男朋友了，让我们俩清净点？"

translate chinese chinese_8556472_506:
    old "Hmm, I don't know, that really depends on you."
    new "嗯，这个我真的不知道，这真的取决于你。"

translate chinese chinese_0954222_507:
    old "It has to look real, sis."
    new "得看起来真实点，姐。"

translate chinese chinese_4565288_508:
    old "I get it..."
    new "我明白了……"

translate chinese chinese_6798798_509:
    old "I will do this then."
    new "那我就这么做吧。"

translate chinese chinese_5990167_510:
    old "The only reason I'm going along with this sick game of yours."
    new "我唯一配合你这病态游戏的原因。"

translate chinese chinese_1020051_511:
    old "Is because I don't have any other way of proving to you that this guy and I have a relationship."
    new "是因为我没有其他办法来证明我和这家伙的关系。"

translate chinese chinese_1185984_512:
    old "But this is the last time I'll let you push me into something like this."
    new "但是这是我最后一次让你把我逼到这种地步。"

translate chinese chinese_5306903_513:
    old "If you ever try this again, I don't care what you have to say to anyone, I'll fucking make you pay!"
    new "你再敢试试这个，不管你跟谁说什么，我他妈都会让你付出代价！"

translate chinese chinese_5320961_514:
    old "Very clear, sis, but I don't see you proving anything, so why don't you get to it?"
    new "很清楚，姐姐，但你还没证明什么，所以你赶紧开始吧？"

translate chinese chinese_8782820_515:
    old "And remember, make it convincing."
    new "而且记得，要做得让人信服。"

translate chinese chinese_6495919_516:
    old "W- woah! Woah! Is this for real? Do you want to do this in front of her?"
    new "哇！哇！这是认真的吗？你想在她面前做这个？"

translate chinese chinese_9085177_517:
    old "Do you get the situation, [pla]? Do you know how serious it is?"
    new "你明白情况吗，[pla]？你知道这有多严重吗？"

translate chinese chinese_8923688_518:
    old "Of course I'm being serious..."
    new "我当然是认真的..."

translate chinese chinese_4400266_519:
    old "Oh gosh! You're actually doing it!"
    new "天啊！你真的做了！"

translate chinese chinese_3999408_520:
    old "This is for real! I can't believe it!"
    new "这可不是开玩笑的！我简直不敢相信！"

translate chinese chinese_4322794_521:
    old "I have to say, sis, that was quite the spectacle."
    new "得说一声，姐，那可真是够精彩的。"

translate chinese chinese_6252256_522:
    old "Are you satisfied?"
    new "你满意了吗？"

translate chinese chinese_6638658_523:
    old "Oh! Of course, I am!"
    new "哦！当然了，我是！"

translate chinese chinese_7160838_524:
    old "I can tell how much you liked it!"
    new "我能看出来你有多喜欢它！"

translate chinese chinese_5489336_525:
    old "You can just tell how much love there is between the two of you!"
    new "你们之间的爱意简直溢于言表！"

translate chinese chinese_9151789_526:
    old "Alright, you have what you wanted. Now get the hell out of here!"
    new "好了，你想要的都得到了。现在滚出去！"

translate chinese chinese_0257605_527:
    old "And remember what I told you."
    new "还有记得我跟你说过的。"

translate chinese chinese_4397206_528:
    old "I won't allow this to happen a second time, now get the hell out of my room, you bitch!"
    new "我不会再让这种事发生第二次，现在给我滚出我的房间，你这个贱人！"

translate chinese chinese_2026883_529:
    old "Oh, I'm leaving alright."
    new "哦，我确实是走了。"

translate chinese chinese_5314908_530:
    old "But I can't wait to see you again soon, [pla]."
    new "但我迫不及待想尽快再见到你了，[pla]。"

translate chinese chinese_5202570_531:
    old "Out!"
    new "出去！"

translate chinese chinese_8671525_532:
    old "Uhmm... A- are you alright?"
    new "嗯……你、你还好吗？"

translate chinese chinese_1870463_533:
    old "Shut up, [pla]."
    new "闭嘴，[pla]。"

translate chinese chinese_2778415_534:
    old "We still have a lot of ground to cover."
    new "我们还有很多要谈的。"

translate chinese chinese_9229645_535:
    old "And not a lot of time, so let's just get back to studying."
    new "而且时间不多了，所以我们还是回去学习吧。"

translate chinese chinese_3156363_536:
    old "R- right."
    new "嗯……对。"

translate chinese chinese_3534938_537:
    old "I guess I'll go home for now. And I'll come back later."
    new "那我先回家吧，回头再来。"

translate chinese chinese_3810903_538:
    old "But before you leave, I want to make something clear."
    new "但在你走之前，我想澄清一件事。"

translate chinese chinese_7336099_539:
    old "What just happened here was just a one-time thing, alright?"
    new "刚才发生的事就当是一次性的，好吗？"

translate chinese chinese_2669416_540:
    old "Don't get any ideas about it happening again."
    new "别想着这事会再发生。"

translate chinese chinese_8563366_541:
    old "S-sure, of course."
    new "好、好的，当然。"

translate chinese chinese_2115335_542:
    old "Alright, then I'll see you later."
    new "好吧，那回头见。"

translate chinese chinese_5019155_543:
    old "Sure, bye."
    new "行吧，再见。"

translate chinese chinese_7591911_544:
    old "Alright, we somehow managed to cover everything."
    new "好吧，我们不知怎么把一切都讲清楚了。"

translate chinese chinese_2600124_545:
    old "It might not have been too thorough."
    new "可能不太彻底。"

translate chinese chinese_2226632_546:
    old "But I'm sure you know enough now to shoot for the highest grades."
    new "但我相信你现在知道足够的知识，可以争取最高分了。"

translate chinese chinese_0479482_547:
    old "I'm sure you'll do great."
    new "我相信你会表现得很棒。"

translate chinese chinese_4058337_548:
    old "Just remember, all you have to do is stay calm while you're answering the questions."
    new "记住，你只需要在回答问题时保持冷静。"

translate chinese chinese_5113305_549:
    old "As long as you don't worry too much, you should be fine to answer everything."
    new "只要你不要太紧张，应该可以回答所有问题。"

translate chinese chinese_9937936_550:
    old "I'll do my best to answer everything as well as I can!"
    new "我一定会尽全力回答好每一个问题！"

translate chinese chinese_9007172_551:
    old "I'm so thankful for your help!"
    new "我真的很感谢你的帮助！"

translate chinese chinese_4054027_552:
    old "Without you, I couldn't have gone through all those topics."
    new "没有你，我根本没法搞定那些话题。"

translate chinese chinese_6892837_553:
    old "Really, thank you so much."
    new "真的，太感谢了。"

translate chinese chinese_5866652_554:
    old "It's alright, I'm glad I was able to help you."
    new "没关系，我很高兴能帮到你。"

translate chinese chinese_2652769_555:
    old "And I'm sure you'll do great on the exam."
    new "我相信你考试一定能考得很好。"

translate chinese chinese_5205865_556:
    old "So, I'll leave for now, and I'll see you later."
    new "那我先走了，回头见。"

translate chinese chinese_7997213_557:
    old "Alright, I'll be sure to let you know how I do in the exams."
    new "好吧，我会告诉你我的考试结果的。"

translate chinese chinese_5380945_558:
    old "Hmm, I just remembered, I need to check my exam results when I get home."
    new "嗯，我想起来了，回家后得查一下考试成绩。"

translate chinese chinese_5148100_559:
    old "Oh! Hey Olivia."
    new "哦！奥利维亚。"

translate chinese chinese_8213959_560:
    old "Hey, [pla]..."
    new "嘿，[pla]..."

translate chinese chinese_3889288_561:
    old "How did you do on the exams? Have you checked the results yet?"
    new "考试怎么样？查成绩了吗？"

translate chinese chinese_8758355_562:
    old "How do you think you did on them?"
    new "你觉得你表现如何？"

translate chinese chinese_9824687_563:
    old "Well, about that, do you think you could come with me to my house?"
    new "嗯，关于这个，你能陪我回家吗？"

translate chinese chinese_3802807_564:
    old "Uh, s-sure. Is there anything wrong?"
    new "呃，好 sure. 有什么问题吗？"

translate chinese chinese_3434546_565:
    old "You have no idea... But I'll tell you at my house."
    new "你不知道……不过我可以在我家告诉你。"

translate chinese chinese_4996520_566:
    old "Come on, let's go."
    new "走吧，我们赶紧去。"

translate chinese chinese_4724895_567:
    old "Yeah, yeah, I know."
    new "嗯嗯，我知道。"

translate chinese chinese_8880910_568:
    old "Oh my god, Vihaan! I said I got it!"
    new "天啊，维韩！我说我来搞定！"

translate chinese chinese_1710064_569:
    old "What do you mean my fault?"
    new "你说是我的错是什么意思？"

translate chinese chinese_8092225_570:
    old "Maybe if you were here too..."
    new "maybe if you were here too... \n\n保持原文，因为这句话在某些上下文中可能有特殊的含义或情感表达，直接翻译可能会失去原意。如果有更多上下文可以提供，我可以给出更贴切的翻译。"

translate chinese chinese_7318865_571:
    old "Yeah, I know..."
    new "嗯，我知道……"

translate chinese chinese_1523501_572:
    old "You know, this really isn't as bad as you're making it out to be."
    new "你知道吗，这真的没有你说的那么糟糕。"

translate chinese chinese_2785701_573:
    old "Well, because this isn't the end of the world."
    new "因为这并不是世界末日。"

translate chinese chinese_9850981_574:
    old "She can always try again..."
    new "她总是可以再试一次……"

translate chinese chinese_9750131_575:
    old "Oh! I know full well what you think about that!"
    new "哦！我可清楚你对那件事的看法了！"

translate chinese chinese_6499791_576:
    old "But that's beside the point."
    new "但这不是重点。"

translate chinese chinese_6886585_577:
    old "And what do you propose we do about her boyfriend?"
    new "那她的男朋友怎么办？"

translate chinese chinese_1210069_578:
    old "Of course it's important, Vihaan!"
    new "当然重要了，维罕！"

translate chinese chinese_9700867_579:
    old "What do you mean why?"
    new "你什么意思为什么？"

translate chinese chinese_6492022_580:
    old "Because her feelings are important!"
    new "因为她的感受很重要！"

translate chinese chinese_6154207_581:
    old "I know that."
    new "我知道那件事。"

translate chinese chinese_4142936_582:
    old "No, he's not rich."
    new "不，他不算有钱。"

translate chinese chinese_9867451_583:
    old "But I think that's beside the..."
    new "但是我觉得这有点离题……"

translate chinese chinese_8995254_584:
    old "Hmm, yeah that's true."
    new "嗯，说得对。"

translate chinese chinese_8127828_585:
    old "{b}*Sigh*{/b} Yeah, you're very right."
    new "{b}*叹气*{/b} 嗯，你说得对。"

translate chinese chinese_2224824_586:
    old "Yeah, I guess I'll talk to her."
    new "好吧，我想我会去和她聊聊。"

translate chinese chinese_8423344_587:
    old "Yes, you're right."
    new "是的，你说得对。"

translate chinese chinese_7482137_588:
    old "You should talk to her as well."
    new "你也应该和她聊聊。"

translate chinese chinese_0875737_589:
    old "Yeah, talk to you later then."
    new "那回头聊吧。"

translate chinese chinese_9873295_590:
    old "So, I guess you got what your father said in that conversation."
    new "所以，我想你应该听到了你爸爸在那次谈话中说了什么。"

translate chinese chinese_4391780_591:
    old "Yeah, I can figure."
    new "嗯，我明白。"

translate chinese chinese_9307153_592:
    old "Oh! You're in trouble!"
    new "哦！你麻烦了！"

translate chinese chinese_5629620_593:
    old "What's the matter, sis?"
    new "怎么了，姐？"

translate chinese chinese_8776995_594:
    old "Is the favorite daughter not living up to expectations?"
    new "掌上明珠没达到预期吗？"

translate chinese chinese_8062352_595:
    old "Why don't you shut your mouth before I shut it for you?"
    new "再罗嗦我就帮你闭嘴了。"

translate chinese chinese_1076279_596:
    old "OK! That's enough."
    new "好啦！够了。"

translate chinese chinese_0041666_597:
    old "Listen, Olivia, I don't like the attitude your father's taking on this."
    new "听着，奥利维亚，我不喜欢你父亲在这个问题上的态度。"

translate chinese chinese_7701475_598:
    old "But you were aware of what he wanted you to do."
    new "但是你知道他想让你做什么。"

translate chinese chinese_5759284_599:
    old "And the only way that you could stop him from sending you to India was by getting good grades."
    new "而你能阻止他把你送到印度的唯一办法就是取得好成绩。"

translate chinese chinese_6984295_600:
    old "I know, I know, this isn't fair."
    new "我知道，我知道，这不公平。"

translate chinese chinese_4793081_601:
    old "But it is the way things are."
    new "但事实就是如此。"

translate chinese chinese_4798559_602:
    old "Because you're too stupid."
    new "因为你太笨了。"

translate chinese chinese_1509192_603:
    old "The point is that your dad decided that he's not going to wait for you to finish the school year."
    new "重点是，你爸爸决定不等你读完这个学期了。"

translate chinese chinese_3026327_604:
    old "He told me that he wants you to start organizing your things."
    new "他告诉我，他希望你开始整理东西。"

translate chinese chinese_7807697_605:
    old "After the next batch of exams, you're transferring to a school in India."
    new "接下来这批考试结束后，你要转去印度的学校了。"

translate chinese chinese_6999091_606:
    old "But that's not fair! He doesn't get to decide that for me!"
    new "但这不公平！他不能替我决定这件事！"

translate chinese chinese_5241785_607:
    old "Well, apparently he does."
    new "好吧，看来他是这样的。"

translate chinese chinese_3975833_608:
    old "And honestly, Olivia, you should've known this was going to happen."
    new "说实话，奥利维亚，你应该知道这会发生。"

translate chinese chinese_7803418_609:
    old "I'm sorry, honey, but at this point, there's not a lot more that I can do for you."
    new "对不起，亲爱的，但到了这一步，我也没办法再帮你更多了。"

translate chinese chinese_9047039_610:
    old "It looks like you're taking a plane to our motherland, sis! Hahaha!"
    new "看来你要飞回咱们祖国了，姐姐！哈哈！"

translate chinese chinese_5132734_611:
    old "You shouldn't be gloating too much, young lady."
    new "你这小姑娘也不应该太得意忘形。"

translate chinese chinese_5707473_612:
    old "With the way your grades are going, you'll be joining your sister."
    new "看你现在的成绩，你很快就会和你姐姐一样了。"

translate chinese chinese_9116601_613:
    old "You heard me, your father wasn't only talking about Olivia."
    new "你听到了，你父亲说的不止是奥利维亚。"

translate chinese chinese_3115637_614:
    old "And your grades aren't much better than hers."
    new "而且你的成绩也好不到哪里去。"

translate chinese chinese_2744347_615:
    old "But, I mean... Mom!"
    new "但是，我是说... 妈妈！"

translate chinese chinese_8853772_616:
    old "We'll talk about this later, I have to run some errands."
    new "我们回头再聊，我得去办点事。"

translate chinese chinese_6575908_617:
    old "Listen, honey, I'm sorry about this, but I guess that's just how it is."
    new "听着，亲爱的，我为这个道歉，但我想这就是现实。"

translate chinese chinese_2770181_618:
    old "Wait, Mom, let me go with you! We still need to talk about Dad!"
    new "等一下，妈妈，让我跟你一起去！我们还得谈谈爸爸的事！"

translate chinese chinese_0318772_619:
    old "I imagine you can guess what happened..."
    new "我想你应该能猜到发生了什么……"

translate chinese chinese_4737674_620:
    old "I think so... The exams didn't go well?"
    new "应该是吧……考试没考好？"

translate chinese chinese_9459423_621:
    old "They didn't."
    new "他们没有。"

translate chinese chinese_3736356_622:
    old "But you studied so hard."
    new "但是你那么用功。"

translate chinese chinese_7911887_623:
    old "I did, and you did a great job teaching me [pla]."
    new "我做到了，而且你教我[pla]教得很好。"

translate chinese chinese_2488064_624:
    old "But when I was taking the exams, I couldn't focus."
    new "但是考试的时候，我根本集中不了注意力。"

translate chinese chinese_7453863_625:
    old "I just kept thinking about how important it was to get top marks."
    new "我一直在想拿到满分是多么重要。"

translate chinese chinese_3107944_626:
    old "And the more I thought about it, the more scared I got."
    new "越想就越害怕。"

translate chinese chinese_9465701_627:
    old "In the end, I couldn't answer anything correctly."
    new "最后，我什么问题都没答对。"

translate chinese chinese_1789781_628:
    old "I mean, I get it."
    new "我的意思是，我明白。"

translate chinese chinese_7380133_629:
    old "With that much pressure, it would be hard to do well."
    new "这么大的压力，要做好还真不容易。"

translate chinese chinese_5202730_630:
    old "I'm sorry, Olivia."
    new "对不起，奥利维亚。"

translate chinese chinese_7385619_631:
    old "Well, it happens. Nothing I can do about it."
    new "嗯，这种事情发生了。我也无能为力。"

translate chinese chinese_3392457_632:
    old "But that doesn't mean I won't deal with this."
    new "但这不代表我不处理这件事。"

translate chinese chinese_1002913_633:
    old "Oh... Okay, what do you have in mind?"
    new "哦……好吧，你有什么想法？"

translate chinese chinese_4015879_634:
    old "Well, this is going to surprise you."
    new "好吧，这肯定会让你吃惊。"

translate chinese chinese_1801580_635:
    old "But I don't have an easy way to say this."
    new "但是我不知道该怎么轻松地说这件事。"

translate chinese chinese_5374682_636:
    old "W- WHAT?! What are you talking about?!"
    new "W- 哪里啊？！你在说什么？！"

translate chinese chinese_1843236_637:
    old "You heard me, I'm going to get pregnant."
    new "你听清楚了，我要怀孕了。"

translate chinese chinese_1059894_638:
    old "Yeah, that doesn't explain anything."
    new "是啊，这根本没解释什么。"

translate chinese chinese_2204891_639:
    old "I'm sorry, like an actual pregnancy?"
    new "对不起，你是说真的怀孕了吗？"

translate chinese chinese_6177854_640:
    old "Or are you talking about pretending to be pregnant?"
    new "还是说假装怀孕那种？"

translate chinese chinese_3632733_641:
    old "No, I mean literally pregnant."
    new "不，我是说真的怀孕了。"

translate chinese chinese_1582307_642:
    old "W- what? B- but why?"
    new "什、什么？为、为什么？"

translate chinese chinese_0823001_643:
    old "Because it's the only way to change my circumstances."
    new "因为这是改变我处境的唯一办法。"

translate chinese chinese_1275443_644:
    old "That's putting it mildly!"
    new "这还算是轻描淡写了！"

translate chinese chinese_0959822_645:
    old "Is this what you want? To be a mother?"
    new "这就是你想要的吗？成为一个母亲？"

translate chinese chinese_7131293_646:
    old "I don't."
    new "我不。"

translate chinese chinese_4566905_647:
    old "Or at least not yet."
    new "至少现在还没有。"

translate chinese chinese_9945865_648:
    old "Then why do you want to get pregnant?"
    new "那为什么你想怀孕？"

translate chinese chinese_9959592_649:
    old "Getting pregnant doesn't automatically mean I have to be a mother [pla]!"
    new "怀孕并不自动意味着我必须成为母亲[pla]！"

translate chinese chinese_3187802_650:
    old "I don't plan on carrying the pregnancy to term."
    new "我本来就不打算把孩子生下来。"

translate chinese chinese_8867645_651:
    old "I just want to get rid of this whole {i}'arranged marriage'{/i} thing."
    new "我就是想摆脱这个什么‘包办婚姻’。"

translate chinese chinese_0769758_652:
    old "And how would that work?"
    new "那会怎么运作呢？"

translate chinese chinese_2471404_653:
    old "In our culture, when a woman is arranged to marry, she's expected to be virtuous."
    new "在我们的文化中，当一个女人被安排结婚时，她被期望要有美德。"

translate chinese chinese_2155883_654:
    old "Nowadays, there's no way to ensure that the girl is a virgin."
    new "现在根本没法保证女孩是不是处女。"

translate chinese chinese_7249654_655:
    old "So that tends to be overlooked."
    new "所以这往往被忽视。"

translate chinese chinese_4367885_656:
    old "But a pregnancy is a very different thing."
    new "但是怀孕可是完全不同的事情。"

translate chinese chinese_4982130_657:
    old "The family of the guy my dad chose for me is very illustrious and traditional."
    new "我爸爸为我选中的那家人的家族非常显赫且传统。"

translate chinese chinese_8164882_658:
    old "If they find out I'm pregnant, they'll cancel it immediately."
    new "如果他们发现我怀孕了，肯定会立即取消的。"

translate chinese chinese_6566983_659:
    old "And better yet, once the word spreads, it'll be impossible for my father to arrange another marriage for me."
    new "而且一旦消息传开，我父亲就更不可能再为我安排婚事了。"

translate chinese chinese_3558712_660:
    old "You seem very certain this will work."
    new "你好像很确信这会成功。"

translate chinese chinese_6562708_661:
    old "Well, because I've seen something like it."
    new "因为我也见过类似的东西。"

translate chinese chinese_0363823_662:
    old "I have this cousin who was in a similar situation a couple of years ago."
    new "我有个堂兄几年前遇到过类似的情况。"

translate chinese chinese_9727820_663:
    old "The difference is that she actually wanted to get married."
    new "区别在于她其实是想结婚的。"

translate chinese chinese_7702753_664:
    old "The guy my uncle selected for her is a doctor who lives in Delhi."
    new "我叔叔给她选的人是个住在德里的医生。"

translate chinese chinese_8877813_665:
    old "So on paper, she had the perfect deal."
    new "纸面上看，她得到了完美的交易。"

translate chinese chinese_6556406_666:
    old "The problem came when she went to a party and hooked up with some guy."
    new "问题出在她去参加了一个派对，并且跟一个家伙发生了关系。"

translate chinese chinese_7791947_667:
    old "That's not a big deal, but she wasn't careful and ended up getting pregnant."
    new "这不算什么大事，但她不小心怀孕了。"

translate chinese chinese_5689930_668:
    old "She tried to keep it under wraps while she dealt with it."
    new "她试图在处理这件事时保持低调。"

translate chinese chinese_2702199_669:
    old "But that kind of thing is almost impossible to keep hidden in a place like Delhi, to be honest."
    new "说实话，在德里这样的地方，那种事情几乎不可能隐瞒得住。"

translate chinese chinese_0339592_670:
    old "So, her marriage was canceled almost immediately, there was nothing she could do."
    new "所以她的婚事几乎立刻就被取消了，她什么也做不了。"

translate chinese chinese_2047613_671:
    old "Moreover, she hasn't been able to get a single meeting to arrange a marriage."
    new "而且，她连一次相亲都安排不成。"

translate chinese chinese_5710801_672:
    old "Much less a fiancé."
    new "更别提什么未婚夫了。"

translate chinese chinese_5576299_673:
    old "Wow, is it really like that?"
    new "wow, 真的是那样吗？"

translate chinese chinese_4578576_674:
    old "Of course it is."
    new "当然了。"

translate chinese chinese_5477622_675:
    old "It's not good to say, but once a woman gets pregnant, she's no longer seen as virtuous."
    new "说出来可能不太好听，但女人一旦怀孕，就不再被视为贞洁了。"

translate chinese chinese_8865842_676:
    old "Rather as {i}'damaged goods.'{/i} Ugh!"
    new "更像是被弄坏的货物。呕！"

translate chinese chinese_1894397_677:
    old "But yeah... That's why I believe my idea will work."
    new "但是呢……那正是我相信我的想法能行的原因。"

translate chinese chinese_5555236_678:
    old "Still, it sounds so drastic."
    new "不过，这听起来还是太激烈了。"

translate chinese chinese_2349203_679:
    old "Don't you think there's anything less... extreme you could do?"
    new "你不觉得有什么不那么……极端的事情可以做吗？"

translate chinese chinese_3300051_680:
    old "How about taking other exams?"
    new "要不参加其他的考试吧？"

translate chinese chinese_7890900_681:
    old "What will that do? You already heard my mother, my dad won't even let me finish the year."
    new "这能干什么？你已经听到我妈妈说了，我爸爸连让我读完这一年都不肯。"

translate chinese chinese_1115864_682:
    old "And to be honest [pla], I don't think that was ever a real option."
    new "说实话，[pla]，我觉得那从来就不是个真实的选择。"

translate chinese chinese_1665068_683:
    old "I think he was just entertaining my mom, but his real plan has always been to get me married to someone in India."
    new "我觉得他只是在陪我妈妈玩，但他的真实计划一直都是想让我嫁给一个印度人。"

translate chinese chinese_5786274_684:
    old "But that's not what I want for myself [pla]!"
    new "但是那不是我想要的[pla]！"

translate chinese chinese_1890305_685:
    old "Life in an arranged marriage is restrictive."
    new "包办婚姻的生活很束缚人。"

translate chinese chinese_1890257_686:
    old "You're not your own person; everything you want to do or have has to come through your husband."
    new "你不是你自己，你想做的一切、拥有的东西都得通过你丈夫。"

translate chinese chinese_1763463_687:
    old "Any social life you might want or access depends on him."
    new "你任何社交生活都得依赖他。"

translate chinese chinese_5321705_688:
    old "In the best case, the guy will be understanding and permissive. And you can imagine how it is at the worst."
    new "最好的情况是这家伙会理解且宽容。你可以想象最糟的情况是怎么样的。"

translate chinese chinese_5350968_689:
    old "I don't want that for myself! Why do I have to marry some guy I don't know just so my dad can make money from it?!"
    new "我可不想这样！为什么我就得嫁给一个我不认识的人，就为了让我爸赚钱?!"

translate chinese chinese_0516727_690:
    old "So, if I have to get pregnant to stop myself from being married to some guy I don't know, I'll gladly do it."
    new "所以，如果我必须怀孕才能阻止自己嫁给一个不认识的人，那我也愿意。"

translate chinese chinese_3010947_691:
    old "I see, but are you sure you can do this?"
    new "我明白了，但你确定你能做到吗？"

translate chinese chinese_8567903_692:
    old "I mean, interrupting a pregnancy's not easy."
    new "我的意思是，中断怀孕可不是件容易的事。"

translate chinese chinese_3731569_693:
    old "Well, abortion is legal and pretty common these days."
    new "好吧，堕胎现在是合法的，也很常见。"

translate chinese chinese_3534544_694:
    old "I know a girl who got one."
    new "我认识一个女孩，她就有那个。"

translate chinese chinese_4977903_695:
    old "Yeah, she's a friend of Ruby."
    new "嗯，她是Ruby的朋友。"

translate chinese chinese_3040071_696:
    old "She got pregnant from a one-night stand with her ex-boyfriend."
    new "她和前男友一夜情怀孕了。"

translate chinese chinese_3599510_697:
    old "But she went to the hospital to get an abortion, and it went very well. You know?"
    new "但她去医院做了流产，做得很好。你知道吗？"

translate chinese chinese_3432278_698:
    old "I see... I think I get it."
    new "我明白了……我觉得我懂了。"

translate chinese chinese_2068892_699:
    old "That's right, so you see it now, it's not a bad plan."
    new "没错，现在你看清楚了，这并不是一个坏计划。"

translate chinese chinese_5432258_700:
    old "{i}(Now that I think about it, Brixxida did mention that a magical pregnancy would be quicker.){/i}"
    new "{i}（现在想想，Brixxida确实提到过魔法怀孕会快一些。){/i}"

translate chinese chinese_8357754_701:
    old "{i}(And she did tell me that I had to get as many women as I could pregnant.){/i}"
    new "{i}(而且她确实告诉我，我必须让尽可能多的女人怀孕。){/i}"

translate chinese chinese_1663510_702:
    old "{i}(Hmm, it could be that this is a good idea.){/i}"
    new "{i}（嗯，这可能是个好主意。){/i}"

translate chinese chinese_8496853_703:
    old "No, it isn't a bad plan."
    new "不，这并不是个坏计划。"

translate chinese chinese_5791031_704:
    old "And... That's more or less where you come in."
    new "然后……差不多就是你出场的时候了。"

translate chinese chinese_2895457_705:
    old "Listen [pla], our original deal is already fulfilled."
    new "听好了[pla]，我们原来的交易已经完成了。"

translate chinese chinese_4285533_706:
    old "I didn't pass my exams, but you still helped me the best way you could."
    new "我考试没过，但你还是尽你所能帮我了。"

translate chinese chinese_1201277_707:
    old "So I wouldn't tell you that you have to get me pregnant."
    new "所以我也不会告诉你非得让我怀孕。"

translate chinese chinese_5080837_708:
    old "But if I'm honest, it's hard for me to think of a better person to ask."
    new "但说老实话，我觉得很难找到比她更适合的人选。"

translate chinese chinese_7021520_709:
    old "You know my situation in a way that I couldn't explain to anyone else."
    new "你知道我的处境，这是我无法向别人解释的。"

translate chinese chinese_4014385_710:
    old "And you wouldn't have to worry about it, all I need is your seed."
    new "你不用担心这些，我只需要你的种子。"

translate chinese chinese_4128581_711:
    old "And I would take care of everything regarding the pregnancy and the interruption."
    new "我会处理好关于怀孕和中断的一切事宜。"

translate chinese chinese_8669118_712:
    old "But I would understand if you didn't want to do it."
    new "但是如果不愿意做的话我也理解。"

translate chinese chinese_3749245_713:
    old "Actually, I was thinking that I wanted to help you with it."
    new "其实，我在想我想要帮你做这件事。"

translate chinese chinese_2153566_714:
    old "What you say is true. I am fully aware of your situation, both with your parents."
    new "你说的没错。我完全明白你的处境，包括你和你父母的事。"

translate chinese chinese_5067717_715:
    old "And what you're doing to try and deal with it."
    new "以及你打算怎么应对这件事。"

translate chinese chinese_0380222_716:
    old "So I agree that I'm probably the best person to help you with this."
    new "所以我觉得我可能是最适合帮你的人。"

translate chinese chinese_3655306_717:
    old "Also, I'm really against what your parents are putting you through, you know?"
    new "还有，我真的反对你父母让你经历的这一切，你知道吗？"

translate chinese chinese_5931938_718:
    old "I don't think it's fair at all that you have to live your life the way they want you to."
    new "我觉得你不得不按他们的方式生活根本就不太公平。"

translate chinese chinese_0340372_719:
    old "So I'll help you get out of it."
    new "那我就帮你脱身吧。"

translate chinese chinese_3784378_720:
    old "OK, let's go to my room."
    new "好，我们去我的房间吧。"

translate chinese chinese_2036557_721:
    old "W- what? Do it now?"
    new "什、什么？现在就做？"

translate chinese chinese_3794782_722:
    old "Yeah, of course. I don't think there's a better time for it."
    new "是啊，当然。我觉得没有比这更好的时机了。"

translate chinese chinese_0891186_723:
    old "My mom will be out with Ayesha running errands until late."
    new "我妈妈会和Ayesha一起出去办些事，要很晚才回来。"

translate chinese chinese_5412773_724:
    old "And we don't have much time. I need to get pregnant soon."
    new "而且我们时间不多了。我需要尽快怀孕。"

translate chinese chinese_4668366_725:
    old "So we should do it now."
    new "那我们就现在做吧。"

translate chinese chinese_9760052_726:
    old "Ok, so... Uhh, let's do it..."
    new "好吧，那……嗯，咱们开始吧……"

translate chinese chinese_5306815_727:
    old "Uhh... Yeah, yeah..."
    new "呃……对对……"

translate chinese chinese_1027403_728:
    old "Well... Uhh, where do we start? I mean, I know how to do it, but... Uhhh you get what I mean..."
    new "嗯……呃，我们从哪里开始呢？我的意思是，我知道该怎么做，但是……呃，你懂的……"

translate chinese chinese_7293402_729:
    old "Uhh... Well, I think, we should... Uhh..."
    new "呃……嗯，我觉得我们应该……呃……"

translate chinese chinese_4667819_730:
    old "You know what, this is silly, we don't have time for this. After all, I've already sucked your cock..."
    new "你知道吗，这真是傻了，我们没时间搞这些。毕竟，我已经吸过你的鸡巴了……"

translate chinese chinese_1141615_731:
    old "Alright, I'll start, after all, I'm the one who needs your help with this."
    new "好吧，我先来，毕竟需要你帮忙的是我。"

translate chinese chinese_0329894_732:
    old "Does this feel good?"
    new "这感觉好吗？"

translate chinese chinese_9629375_733:
    old "U- uh, yeah..."
    new "嗯……对……"

translate chinese chinese_2730212_734:
    old "I have to say, you have a big... dick..."
    new "我得说，你有个很大的...鸡巴..."

translate chinese chinese_4990435_735:
    old "Uhh, thanks..."
    new "呃，谢谢……"

translate chinese chinese_1776959_736:
    old "Alright! That was great [pla]!"
    new "好样的！[pla]，干得漂亮！"

translate chinese chinese_5478914_737:
    old "It may be too soon to know if I'm pregnant yet, but I'll take a test as soon as I can and let you know."
    new "现在可能还太早说是否怀孕，但我一有机会就会去做个测试然后告诉你。"

translate chinese chinese_7559054_738:
    old "Alright, that sounds good."
    new "好吧，那听起来不错。"

translate chinese chinese_7904440_739:
    old "Thanks again for helping me [pla]."
    new "再次感谢你帮了我[pla]。"

translate chinese chinese_3479744_740:
    old "It's alright, I'm happy to help."
    new "没关系，我很乐意帮忙。"

translate chinese chinese_0891303_741:
    old "Anyway, I think you should get going before my mom gets back."
    new "总之，在我妈妈回来之前，你还是赶紧走吧。"

translate chinese chinese_4388086_742:
    old "Oh! Right, sure, I'll see you later."
    new "哦！对了，好的，待会儿见。"

translate chinese chinese_8308835_743:
    old "And hey, thank you again."
    new "还有，再次谢谢你。"

translate chinese chinese_6406743_744:
    old "Hey! Brixxida! I have some very good news for you!"
    new "喂！布里克西达！我有一些非常好的消息要告诉你！"

translate chinese chinese_5890284_745:
    old "Well, I made an advancement in our plans!"
    new "好吧，我在我们的计划上取得了一些进展！"

translate chinese chinese_4788662_746:
    old "Our plan of getting women pregnant."
    new "我们的让女人怀孕的计划。"

translate chinese chinese_8762118_747:
    old "You know, so we can use their magical power to feed the portal to the magic world."
    new "你知道的，我们可以用他们的魔法力量来喂养通往魔法世界的大门。"

translate chinese chinese_0236741_748:
    old "Okay? How did you make this {i}'advancement?'{/i}"
    new "好吧？你是怎么做到这个{i}“进步？”{/i}"

translate chinese chinese_1834164_749:
    old "Well, I have this friend from school who asked me for some help studying."
    new "嗯，我有个同学问我帮忙复习。"

translate chinese chinese_6332661_750:
    old "As we studied, we got closer, and I got to know her."
    new "我们一起学习，关系越来越近，我也更了解她了。"

translate chinese chinese_4059227_751:
    old "It turns out that her problems were a lot bigger than just school."
    new "原来她的麻烦远不止学校里的事。"

translate chinese chinese_2937379_752:
    old "And that the only way out of them was to get pregnant."
    new "而唯一的出路就是怀孕。"

translate chinese chinese_0683544_753:
    old "So... You're telling me that you got this woman pregnant?"
    new "所以……你在告诉我你让这个女人怀孕了？"

translate chinese chinese_6538004_754:
    old "I did!"
    new "我真的做了！"

translate chinese chinese_8479713_755:
    old "Or at least I think I did, she told me she was going to take a pregnancy test."
    new "至少我这么认为，她告诉我她要去验孕。"

translate chinese chinese_9729349_756:
    old "You heard me!"
    new "你听见我说的了！"

translate chinese chinese_1051365_757:
    old "Did you forget what I told you last time?"
    new "你忘了上次我跟你说的话了吗？"

translate chinese chinese_1266839_758:
    old "Uhmm- We need the magic?"
    new "嗯——我们需要魔法吗？"

translate chinese chinese_1500481_759:
    old "No! You idiot!"
    new "不！你这个白痴！"

translate chinese chinese_1084767_760:
    old "What I told you is that I had to be there when you have sex with the girl!"
    new "我跟你说的是，我要在你和那个女孩做爱的时候在现场！"

translate chinese chinese_0446751_761:
    old "Ugh, try to pay attention when I speak to you."
    new "唉，我跟你说话时认真点。"

translate chinese chinese_1724540_762:
    old "Listen, it's not just about you getting her pregnant and that's it."
    new "听着，这不仅仅是让你怀孕那么简单。"

translate chinese chinese_0705847_763:
    old "I have to be there to perform a ritual while it's happening."
    new "我必须在现场，在发生的时候进行仪式。"

translate chinese chinese_7256510_764:
    old "Of course! Otherwise, it would just be a regular pregnancy."
    new "当然了！不然就只是普通的怀孕而已。"

translate chinese chinese_2895401_765:
    old "That's why it's so bad that you just went ahead and tried to get her pregnant!"
    new "这就是为什么你擅自去让她怀孕这么糟糕的原因！"

translate chinese chinese_7394492_766:
    old "Because if she is, then we will have lost the chance of getting a girl pregnant."
    new "因为如果她不去的话，我们就失去了让女孩怀孕的机会。"

translate chinese chinese_4291776_767:
    old "And we'll have to look for another person."
    new "然后我们就得找另一个人了。"

translate chinese chinese_1802744_768:
    old "If that's true, why weren't you there when I had sex with Barbie and got her pregnant?"
    new "如果真是那样，为什么我在和芭比发生关系并让她怀孕的时候你不在呢？"

translate chinese chinese_2417049_769:
    old "Who says that I wasn't?"
    new "谁说我没有？"

translate chinese chinese_9134003_770:
    old "Think about it [pla], where did you do it with Barbie the first time?"
    new "想想吧[pla]，你第一次和芭比在哪里做的？"

translate chinese chinese_2005913_771:
    old "Uhm, we did it here."
    new "嗯，我们在这里做的。"

translate chinese chinese_0348178_772:
    old "Exactly, and this is where I spend most of my time."
    new "没错，这里就是我大部分时间待的地方。"

translate chinese chinese_5735922_773:
    old "I'm either at the garage, taking care of the portal."
    new "我要么在车库，照看传送门。"

translate chinese chinese_9913485_774:
    old "Or I'm here resting."
    new "或者我在这里休息。"

translate chinese chinese_2150555_775:
    old "So last time, when you arrived with Barbie, I was able to initiate the spell when you two started to have sex."
    new "上次你带着芭比来的时候，你们开始做爱时我就启动了咒语。"

translate chinese chinese_8098257_776:
    old "Otherwise it would've been wasted."
    new "不然就浪费了。"

translate chinese chinese_4093602_777:
    old "Yeah... Luckily that time we were fine."
    new "嗯……好在那次我们没事。"

translate chinese chinese_1465517_778:
    old "But I'm not omnipresent [pla]."
    new "但我不是无所不在的[pla]。"

translate chinese chinese_8284642_779:
    old "Now there's a chance that girl is pregnant and we may have lost our next chance."
    new "现在那女孩有可能怀孕了，我们可能失去了下一个机会。"

translate chinese chinese_5458921_780:
    old "I- I'm sorry Brixxida, I should have talked it over with you before I had sex with her."
    new "我……对不起，布里克西达，我在和她发生关系前应该先和你商量一下的。"

translate chinese chinese_6066665_781:
    old "But I mean, there's still a chance that she's not pregnant."
    new "但是话说回来，她可能还没怀孕。"

translate chinese chinese_9948995_782:
    old "Hmph, for your sake, we better hope she isn't."
    new "哼，为了你的 sake，最好希望她不是。"

translate chinese chinese_6810335_783:
    old "Now, in order for this to not happen again."
    new "现在，为了防止这种情况再发生。"

translate chinese chinese_5328394_784:
    old "I think I should teach you a summoning spell."
    new "我觉得我应该教你一个召唤术。"

translate chinese chinese_5028708_785:
    old "So that this doesn't happen again."
    new "这样就不会再发生了。"

translate chinese chinese_2175223_786:
    old "S- summoning spell?!"
    new "召-召唤术?!"

translate chinese chinese_1234073_787:
    old "Right, this isn't the most complicated spell, so you should be able to master it easily."
    new "对了，这个咒语不是最复杂的，你应该能轻松掌握。"

translate chinese chinese_0460221_788:
    old "And it's good that you know it."
    new "你知道这一点很好。"

translate chinese chinese_8783707_789:
    old "So that you can call on me whenever you see yourself in a situation where you think we can start the ritual with someone."
    new "这样你就可以在我看到自己处于某种情况时联系我，你觉得我们可以开始进行仪式了。"

translate chinese chinese_0878950_790:
    old "I see... Alright, so how does this spell work?"
    new "我明白了……好吧，那这个咒语怎么用？"

translate chinese chinese_7666616_791:
    old "I'll tell you, get your SexNote out."
    new "我告诉你，把SexNote拿出来。"

translate chinese chinese_4040665_792:
    old "Alright, I'll explain everything to you, pay attention."
    new "好吧，我会把一切都告诉你，注意听。"

translate chinese chinese_0229110_793:
    old "Alright, that should be enough for now."
    new "好了，现在差不多够了。"

translate chinese chinese_4396549_794:
    old "With that, you should be able to do the spell properly without needing any kind of help from my end."
    new "这样的话，你应该就能自己正确地施法了，不需要我再帮忙。"

translate chinese chinese_0489604_795:
    old "I got it, I'll keep that in mind."
    new "我知道了，我会记住的。"

translate chinese chinese_7736677_796:
    old "By the way, since you say it isn't a normal pregnancy."
    new "对了，既然你说这不是普通的怀孕。"

translate chinese chinese_6005208_797:
    old "How is a magical pregnancy different from a normal one?"
    new "魔法怀孕和普通怀孕有什么不同？"

translate chinese chinese_6727860_798:
    old "Listen, in general, she'll have more or less the same experience she would if this was a normal, human pregnancy."
    new "听着，总的来说，她的体验会和正常人类怀孕差不多。"

translate chinese chinese_9465979_799:
    old "But there will be two big differences."
    new "但是会有两个很大的不同。"

translate chinese chinese_1400916_800:
    old "The first one is that it's going to be a lot faster than it would normally be."
    new "第一个是这会比平时快很多。"

translate chinese chinese_1152343_801:
    old "Since she'll be concentrating magic power within her."
    new "因为她会在体内集中魔力。"

translate chinese chinese_2237104_802:
    old "It's different from woman to woman, but it should be about a third of the time."
    new "因人而异，但大概应该是三分之一的时间。"

translate chinese chinese_8775499_803:
    old "Maybe even a fourth, who knows."
    new "甚至可能是第四个，谁知道呢。"

translate chinese chinese_9218103_804:
    old "Well, if you're going to be a father or not depends on whether or not she'll have the {i}'baby'{/i}."
    new "好吧，你是不是当爸爸就看她会不会有那个'宝宝'了。"

translate chinese chinese_0382179_805:
    old "Either way, it doesn't make a difference for us."
    new "不管怎样，这对我们都没区别。"

translate chinese chinese_0011667_806:
    old "It doesn't?"
    new "不是吗？"

translate chinese chinese_2910237_807:
    old "That's good to hear."
    new "听到这个真好。"

translate chinese chinese_8302631_808:
    old "Yeah, what we're doing is using the pregnancy to concentrate the magic in her body."
    new "没错，我们就是利用怀孕来集中她体内的魔法。"

translate chinese chinese_1119546_809:
    old "The baby itself is not actually important to our plans."
    new "那个婴儿本身对我们计划并不重要。"

translate chinese chinese_1633113_810:
    old "So, when the moment comes to harvest the magic, it can be done either by the baby being born."
    new "所以，当收获魔法的时刻到来时，可以通过宝宝出生来完成。"

translate chinese chinese_7329880_811:
    old "Or by the pregnancy being interrupted."
    new "或者怀孕被中断了。"

translate chinese chinese_7675789_812:
    old "It doesn't matter, as long as I can harvest the magic growing within her."
    new "没关系，只要我能收割她体内生长的魔力。"

translate chinese chinese_4406657_813:
    old "By the way, there's another small difference with a normal pregnancy you have to look out for."
    new "对了，还有一点小差别需要注意，这和正常的怀孕不一样。"

translate chinese chinese_8194184_814:
    old "This pregnancy will come with the added need for magic power within her system."
    new "这次怀孕会让她体内额外需要魔力。"

translate chinese chinese_4170099_815:
    old "As the baby grows in her womb, she'll naturally absorb it from the environment."
    new "随着胎儿在子宫内成长，她会自然地从环境中吸收它。"

translate chinese chinese_1107846_816:
    old "But you can expect that she'll still feel the need for sex. Much like how us shinigami need it from you."
    new "但是你可以预期她仍然会有性需求。就像我们死神需要你们一样。"

translate chinese chinese_0766751_817:
    old "You'll probably have to have sex with her once in a while during her pregnancy."
    new "你可能得在她怀孕期间偶尔和她发生关系。"

translate chinese chinese_7166076_818:
    old "So that's a very good thing for you."
    new "那对你来说就是非常好的事情了。"

translate chinese chinese_5843001_819:
    old "Listen [pla], I hope that girl isn't pregnant, so that we won't miss a chance to add somebody to the ritual."
    new "听着[pla]，我希望那个女孩不要怀孕，否则我们就错过了在仪式中加入一个人的机会。"

translate chinese chinese_0799069_820:
    old "I understand, and I'm sorry I didn't let you know about it before doing it."
    new "我明白，对不起没有在做之前告诉你。"

translate chinese chinese_4143337_821:
    old "I'll talk to her, and I'll let you know how things evolve."
    new "我去找她聊聊，然后告诉你事情的发展。"

translate chinese chinese_8194428_822:
    old "Alright, I'll be waiting for the news."
    new "好吧，我等着消息。"

translate chinese chinese_5310891_823:
    old "Hey Olivia, I came to-"
    new "嘿，奥利维亚，我来是想——"

translate chinese chinese_8246323_824:
    old "I can't believe this! I just can't believe it!"
    new "真不敢相信！我真的不敢相信！"

translate chinese chinese_9694844_825:
    old "I'm sorry honey, but this is not my fault."
    new "对不起亲爱的，这不怪我。"

translate chinese chinese_8828413_826:
    old "And is it my fault?"
    new "这算是我的错吗？"

translate chinese chinese_8913924_827:
    old "Well, who else?"
    new "那还能有谁？"

translate chinese chinese_2462146_828:
    old "Oh my God, I can't believe you're saying that!"
    new "天啊，你竟然这么说！"

translate chinese chinese_7909541_829:
    old "You know what this means, right?!"
    new "你知道这意味着什么吗？！"

translate chinese chinese_1868847_830:
    old "He already decided on the date of the marriage!"
    new "他都已经决定结婚日期了！"

translate chinese chinese_1557799_831:
    old "He can't do that! How can you just let him decide that by himself!"
    new "他不能这么做！你们怎么能让他自己决定！"

translate chinese chinese_6243459_832:
    old "This isn't my fault, Olivia!"
    new "这不关我的事，奥利维亚！"

translate chinese chinese_1766368_833:
    old "I tried to help you, you know that."
    new "我试着帮你，你知道的。"

translate chinese chinese_3583886_834:
    old "But you didn't do your part!"
    new "但是你那边还没做好！"

translate chinese chinese_0248410_835:
    old "You knew what your father's expectations were."
    new "你清楚你父亲的期望。"

translate chinese chinese_3764607_836:
    old "But instead of studying to improve your grades, you decided to waste time."
    new "但你没有选择学习提高成绩，反而浪费了时间。"

translate chinese chinese_1990355_837:
    old "What do you expect me to do for you then?"
    new "那你指望我干什么呢？"

translate chinese chinese_6883210_838:
    old "It was up to you, and you didn't do what you had to."
    new "这取决于你，而你却没有做你应该做的事。"

translate chinese chinese_8561551_839:
    old "And that means that I have to be sent away to be married to some stranger?!"
    new "那也就是说我要被送到一个陌生人那里结婚？！"

translate chinese chinese_2345018_840:
    old "That's my punishment for doing badly in algebra?!"
    new "这就是我代数考差的惩罚？！"

translate chinese chinese_2248415_841:
    old "I can't believe you, Mom! With all that you kept talking about how you don't agree with what Dad wants to do!"
    new "真不敢相信你，妈妈！你之前不是一直在说不同意爸爸的做法吗！"

translate chinese chinese_9348664_842:
    old "I don't agree with it! But you know that your father's word is law!"
    new "我不同意！但你知道你爸爸的话就是规矩！"

translate chinese chinese_2937637_843:
    old "If you wanted to get out of it so badly, all you had to do was study."
    new "如果你那么想脱身，只要好好学习就行了。"

translate chinese chinese_9136980_844:
    old "Now it's too late to cry over spilled milk."
    new "现在后悔也来不及了。"

translate chinese chinese_8933579_845:
    old "You should've thought about that before wasting your time with the likes of Ruby."
    new "你早该想想清楚，别浪费时间在Ruby那样的人身上。"

translate chinese chinese_6071414_846:
    old "I'm sorry honey, but this is just how it is."
    new "对不起亲爱的，事情就是这样的。"

translate chinese chinese_3622560_847:
    old "And you'll have to learn to live with it."
    new "你得学会接受这个。"

translate chinese chinese_2666976_848:
    old "Yeah... I don't think I will."
    new "嗯……我觉得我不会。"

translate chinese chinese_3073729_849:
    old "I don't think I'll have to learn to live with it."
    new "我不认为我需要学会接受它。"

translate chinese chinese_7202999_850:
    old "I won't do what dad wants me to."
    new "我不会按爸爸的意思做的。"

translate chinese chinese_0276457_851:
    old "Olivia, be reasonable, how are you planning to go against your father's wishes?"
    new "奥利维亚，理智一点，你打算怎么违背你父亲的意愿？"

translate chinese chinese_5215938_852:
    old "I don't plan on doing anything."
    new "我没什么打算。"

translate chinese chinese_5842268_853:
    old "Especially because I already did it."
    new "特别是因为我已经做过了。"

translate chinese chinese_2642204_854:
    old "Okay now you're just being cryptic, what are you talking about?"
    new "好了，你现在变得神秘兮兮的，你在说什么？"

translate chinese chinese_6361596_855:
    old "W- what?! P- pregnant?! What do you mean?!"
    new "什、什么？！怀、怀孕？！你什么意思？！"

translate chinese chinese_8855078_856:
    old "When did this happen?!"
    new "这什么时候发生的?!"

translate chinese chinese_0180186_857:
    old "Well, I only found out last week, but I wouldn't know exactly when I got pregnant."
    new "嗯，我上周才刚发现，但具体怀孕的时间就不清楚了。"

translate chinese chinese_4846718_858:
    old "But that's how things are, Mom. I wanted to be sure before letting you know, but the situation calls for me to let you know."
    new "但是事情就是这样的，妈妈。我本来想确定一点再告诉你，但情况需要我告诉你。"

translate chinese chinese_2568923_859:
    old "And you think this is the best moment to bring that out?!"
    new "而且你认为现在拿出这个是最好的时机吗？！"

translate chinese chinese_8630469_860:
    old "If you already knew, you should've let us know sooner!"
    new "如果你早就知道了，就应该早点告诉我们！"

translate chinese chinese_3608895_861:
    old "Do you have any idea about what this means?!"
    new "你知道这意味着什么吗？!"

translate chinese chinese_7606237_862:
    old "Do you know how your dad will react?!"
    new "你知道你爸会怎么反应吗？!"

translate chinese chinese_3323451_863:
    old "I don't know, but he won't be able to send me to India like this."
    new "我不知道，但这样他是没法把我送到印度去的。"

translate chinese chinese_8273975_864:
    old "And you think things are just going to be alright?!"
    new "你觉得事情就会这样没事了？！"

translate chinese chinese_4030310_865:
    old "Your father will come here and kill [pla]!"
    new "你爸爸会过来杀掉[pla]！"

translate chinese chinese_1597835_866:
    old "I can't believe this from you, Olivia! Not only did you get pregnant, but you also hid it!"
    new "真不敢相信这是你的做法，奥利维亚！你不仅怀孕了，还隐瞒了！"

translate chinese chinese_5127167_867:
    old "But you guys were pushing me so hard into it! I just didn't know how to!"
    new "但是你们逼得太紧了！我就是不知道该怎么办！"

translate chinese chinese_1833252_868:
    old "No! I don't want to hear anything from you!"
    new "不要！我可不想听你说什么！"

translate chinese chinese_2416402_869:
    old "You have no idea about what this that you're doing means."
    new "你根本不知道自己在做什么的意思。"

translate chinese chinese_3705328_870:
    old "So I won't listen to you and I won't talk to you about it for now!"
    new "所以我现在既不听你的，也不和你谈这个！"

translate chinese chinese_4696458_871:
    old "What? B- but!"
    new "什么？这……但是！"

translate chinese chinese_7944579_872:
    old "Ughh...!"
    new "呃……！"

translate chinese chinese_6552627_873:
    old "I- Uh... E- excuse me!"
    new "我—呃……对不起！"

translate chinese chinese_2833914_874:
    old "Hey."
    new "喂。"

translate chinese chinese_8634473_875:
    old "Sooo... I guess you're pregnant?"
    new "所以……你怀孕了？"

translate chinese chinese_4861200_876:
    old "Of course I'm not."
    new "我当然不是。"

translate chinese chinese_2973054_877:
    old "We only did it once, it can happen but we weren't lucky."
    new "我们只试了一次，可能会成功，但我们不够幸运。"

translate chinese chinese_1063490_878:
    old "I only said that to my mom to get both her and my dad off my back."
    new "我那只是对我说妈的，为的是让我爸妈都别烦我。"

translate chinese chinese_7530385_879:
    old "But now I have to be pregnant for real!"
    new "但现在我得真的怀孕了！"

translate chinese chinese_1579534_880:
    old "And it can't take too long."
    new "而且不能花太长时间。"

translate chinese chinese_7997091_881:
    old "Because they'll want to check soon for it."
    new "因为他们很快就会来检查的。"

translate chinese chinese_9599561_882:
    old "So, s- should we do it now?"
    new "那，我们现在做吧？"

translate chinese chinese_7009350_883:
    old "Of course not!"
    new "当然不是！"

translate chinese chinese_8126391_884:
    old "My mom said she didn't want to talk to me for now."
    new "我妈妈说她现在不想跟我说话。"

translate chinese chinese_5978022_885:
    old "But be sure that she's going to barge in here any minute now."
    new "但肯定她马上就会闯进来。"

translate chinese chinese_3080008_886:
    old "Actually, I think it would be better if you leave for now."
    new "其实，我觉得你现在离开会比较好。"

translate chinese chinese_9094995_887:
    old "Just to avoid an awkward situation."
    new "只是为了避免尴尬的局面。"

translate chinese chinese_6342268_888:
    old "Oh yeah, sure, we can talk later."
    new "哦，好的，我们可以以后再谈。"

translate chinese chinese_0639222_889:
    old "Sure, see you..."
    new "行吧，再见..."

translate chinese chinese_8086200_890:
    old "Oh! [pla]!"
    new "哦！[pla]！"

translate chinese chinese_0449959_891:
    old "I was just thinking that I have to talk to you."
    new "我刚才就在想我得和你谈谈。"

translate chinese chinese_8991224_892:
    old "How did everything turn out after I left your home?"
    new "我离开你家后，一切都怎么样了？"

translate chinese chinese_3567381_893:
    old "Ugh, you have no idea."
    new "唉，你根本不知道。"

translate chinese chinese_2681368_894:
    old "My mom called my dad and told him everything."
    new "我妈妈打电话给我爸爸，把一切都告诉了他。"

translate chinese chinese_0948474_895:
    old "He got incredibly angry and started screaming about honor and responsibility."
    new "他愤怒到了极点，开始大喊大叫关于荣誉和责任的事。"

translate chinese chinese_0814090_896:
    old "I'm glad it was only over the phone, I can't imagine what he would've done if I had been in front of him."
    new "还好只是电话里，要是面对面的话，我真不敢想象他会怎么做。"

translate chinese chinese_3298475_897:
    old "It got that bad, huh?"
    new "已经糟糕到这种地步了，是吗？"

translate chinese chinese_7615333_898:
    old "I guess he's that worried about you then."
    new "看来他真的很担心你。"

translate chinese chinese_8171256_899:
    old "I don't think it has anything to do with me."
    new "我觉得这和我没关系。"

translate chinese chinese_0480438_900:
    old "He's just angry about having to call off the engagement."
    new "他只是因为取消婚约而生气。"

translate chinese chinese_5808599_901:
    old "Really?! That's what bothers him?"
    new "真的吗？！这就是他烦恼的原因？"

translate chinese chinese_8497976_902:
    old "It is, it's just an integral part of our culture [pla]."
    new "是的，这只是我们文化的一部分[pla]。"

translate chinese chinese_1187203_903:
    old "In India, an arranged marriage is something to be taken seriously."
    new "在印度，包办婚姻是件严肃的事情。"

translate chinese chinese_5503129_904:
    old "Because it's a promise of uniting families."
    new "因为这是家庭团聚的承诺。"

translate chinese chinese_3040996_905:
    old "Now my dad has to go to his friend's house and explain to him why I can't get married."
    new "现在我爸爸得去他朋友家解释为什么我不能结婚。"

translate chinese chinese_3918218_906:
    old "I see, I guess honor's very important there."
    new "我明白了，看来那里的荣誉很重要。"

translate chinese chinese_1789364_907:
    old "It is, but if I'm honest with you, it has nothing to do with that."
    new "是的，但老实说，这和那没关系。"

translate chinese chinese_6123344_908:
    old "He's just angry about losing this business."
    new "他只是因为这桩生意失败而生气。"

translate chinese chinese_6279003_909:
    old "Yeah, those marriages are very honorable and whatever."
    new "是啊，那些婚姻很光荣，之类的。"

translate chinese chinese_4451077_910:
    old "But what he cares about are the business opportunities he could get by marrying his daughters to rich men."
    new "但他关心的是通过把女儿嫁给富人所能获得的商业机会。"

translate chinese chinese_2552525_911:
    old "But it doesn't matter now."
    new "但现在这已经不重要了。"

translate chinese chinese_8891367_912:
    old "Once the news that I'm pregnant starts spreading around, nobody will want to marry me."
    new "一旦大家知道我怀孕了，就没有人会愿意娶我了。"

translate chinese chinese_8479334_913:
    old "And Dad will have to leave that alone."
    new "而爸爸就只能不管了。"

translate chinese chinese_5655731_914:
    old "Ok, so it's all done, right?"
    new "好了，所以都搞定了吧？"

translate chinese chinese_3964530_915:
    old "Yeah, he has to get off my back, but that only means that I HAVE to get pregnant."
    new "是啊，他得让我清静点，但这只意味着我必须得怀孕。"

translate chinese chinese_3709197_916:
    old "And that's where you come in."
    new "而你就在这里出场了。"

translate chinese chinese_8534288_917:
    old "I wanted to ask you if you can come to my house with me."
    new "我想问你能不能跟我一起去我家。"

translate chinese chinese_8607066_918:
    old "My mom's going to be out with my sister running some errands."
    new "我妈妈会带着我妹妹出去办些事情。"

translate chinese chinese_4447188_919:
    old "Which means I'll have the house to myself for some hours."
    new "这意味着我有好几个小时可以独享这房子。"

translate chinese chinese_2193264_920:
    old "That's an opportunity that we can't let pass."
    new "这是一个不能错过的机遇。"

translate chinese chinese_4521728_921:
    old "So, can you come with me to my house?"
    new "那，你能跟我去我家吗？"

translate chinese chinese_4028180_922:
    old "Alright! Let's not waste any time and go then."
    new "好啦！别浪费时间了，我们走吧。"

translate chinese chinese_2504648_923:
    old "Alright, are you ready for it?"
    new "好了，你准备好了吗？"

translate chinese chinese_3408296_924:
    old "Ok, give me a second to freshen up, and we'll do it."
    new "好的，给我一会儿时间整理一下，我们就开始。"

translate chinese chinese_9906094_925:
    old "Ok, I guess now's the time to call Brixxida."
    new "好吧，我想现在是时候打电话给Brixxida了。"

translate chinese chinese_9753441_926:
    old "Wow! What's this?"
    new "哇！这是什么？"

translate chinese chinese_9085064_927:
    old "Hey, this girl and I are about to start having sex."
    new "嘿，我和这个女孩就要开始做爱了。"

translate chinese chinese_6679299_928:
    old "So I summoned you to make sure everything goes well."
    new "所以我召唤你是为了确保一切顺利。"

translate chinese chinese_5311194_929:
    old "I see, good, that's good."
    new "我明白了，很好，这样就好。"

translate chinese chinese_7783738_930:
    old "Hey, are you ready?"
    new "嘿，准备好了吗？"

translate chinese chinese_6179968_931:
    old "Sure, sure, let's do it."
    new "行吧，咱们就来。"

translate chinese chinese_3440064_932:
    old "Ok, just remember to be gentle... I'm still not used to your big cock."
    new "好吧，记得温柔点……我还没习惯你的大鸡巴。"

translate chinese chinese_7771159_933:
    old "Sure, of course..."
    new "当然，没问题……"

translate chinese chinese_9477172_934:
    old "I'm sure that this time it worked."
    new "这次肯定成功了。"

translate chinese chinese_0496034_935:
    old "Yeah, I'm sure it did."
    new "是的，我敢肯定它确实这样做了。"

translate chinese chinese_5330708_936:
    old "At least this way you can get your family off your back a little."
    new "至少这样你可以让你家人少烦你一点。"

translate chinese chinese_6434149_937:
    old "Yeah, well, I wouldn't be so sure about that."
    new "嗯，不过我可不那么确定。"

translate chinese chinese_5325374_938:
    old "But let's see how everything goes."
    new "不过咱们看看事情会怎么发展。"

translate chinese chinese_6206775_939:
    old "But now, I think you better leave before my mom comes back and sees us like this."
    new "但是现在，我觉得你最好在我妈回来看到我们这样之前离开。"

translate chinese chinese_5153369_940:
    old "That shouldn't be a problem if we're supposed to be dating."
    new "如果我们真的在交往，这不应该是个问题。"

translate chinese chinese_4487852_941:
    old "But let's not push our luck."
    new "但咱们也不要太冒险了。"

translate chinese chinese_9077520_942:
    old "Sure, I understand. I'll leave, but I'll check on you later to see how you're doing."
    new "好吧，我明白。我会先离开，但稍后会再来看看你怎么样。"

translate chinese chinese_7529886_943:
    old "Thank you [pla], for everything."
    new "谢谢你[pla]，一切都要感谢你。"

translate chinese chinese_7974443_944:
    old "Alright, I'll see you later."
    new "好吧，回头见。"

translate chinese chinese_5020736_945:
    old "I'm sure that this is going to work!"
    new "我敢肯定这一定会成功的！"

translate chinese chinese_5148098_946:
    old "Well done!"
    new "干得好！"

translate chinese chinese_2103928_947:
    old "Thank you, I'm glad you're satisfied with the results."
    new "谢谢，很高兴你对结果满意。"

translate chinese chinese_8791217_948:
    old "Of course I am."
    new "当然了。"

translate chinese chinese_0418523_949:
    old "And now we can move on to the next target!"
    new "现在我们可以转向下一个目标了！"

translate chinese chinese_5266348_950:
    old "Don't we have to make sure that everything's alright with Olivia before doing that?"
    new "我们不先确认奥利维亚没事吗？"

translate chinese chinese_3727306_951:
    old "Oh don't worry, I'm sure that everything's going to be alright!"
    new "哦别担心，我相信一切都会好起来的！"

translate chinese chinese_6012711_952:
    old "There's no doubt about it."
    new "毫无疑问。"

translate chinese chinese_0475901_953:
    old "I guess I'll get to looking for new girls."
    new "那我就开始物色新的女孩吧。"

translate chinese chinese_1320128_954:
    old "I'll let you know what I find."
    new "我会告诉你我发现了什么。"

translate chinese chinese_9066800_955:
    old "Great! I'll be waiting."
    new "太好了！我等着。"

translate chinese chinese_8220321_956:
    old "Once again, well done [pla]."
    new "再一次做得很好，[pla]。"

translate chinese chinese_3200257_957:
    old "Hey Olivia, how are you?"
    new "嘿，奥利维亚，你好吗？"

translate chinese chinese_3779149_958:
    old "I'm doing fine."
    new "我挺好的。"

translate chinese chinese_1599959_959:
    old "Although I have to say it's been difficult to deal with my family these last few days."
    new "虽然我得说，这几天处理家里事务挺难的。"

translate chinese chinese_0762427_960:
    old "It has?"
    new "是吗？"

translate chinese chinese_1267278_961:
    old "Yeah, I got a pregnancy test done."
    new "是的，我做了个怀孕测试。"

translate chinese chinese_2811071_962:
    old "My dad and mom wanted to make sure that I actually was pregnant and I wasn't just lying to get out of the marriage."
    new "我爸妈想确认我真的怀孕了，不是为了逃避婚姻而撒谎。"

translate chinese chinese_7214634_963:
    old "So, they took me to an ob-gyn and asked them to do the test."
    new "所以他们带我去看了妇产科医生，让他们做了检查。"

translate chinese chinese_8657225_964:
    old "And? What did it say?"
    new "然后呢？上面写了什么？"

translate chinese chinese_7223154_965:
    old "It came out positive!"
    new "结果是阳性！"

translate chinese chinese_1835903_966:
    old "It's good that I got pregnant when I did, because otherwise who knows what would've happened."
    new "我那时候怀孕挺好的，不然谁知道会发生什么。"

translate chinese chinese_2705894_967:
    old "I would probably be on a plane on my way to India right now."
    new "我现在可能已经在去印度的飞机上了。"

translate chinese chinese_1787111_968:
    old "Well, I guess it's a good thing that you're pregnant then."
    new "嗯，那你觉得你现在怀孕也是件好事了。"

translate chinese chinese_8461936_969:
    old "Does that mean that your parents are going to back off now?"
    new "那意思是你爸妈现在会放弃了吗？"

translate chinese chinese_7649269_970:
    old "Well, not really, if anything I think they'll just get even more intense."
    new "嗯，其实不会，我觉得他们只会变得更加激烈。"

translate chinese chinese_0900332_971:
    old "My dad's incredibly furious right now."
    new "我爸爸现在超级生气。"

translate chinese chinese_7918899_972:
    old "You should've seen him, talking about how his good name is being dragged through the mud."
    new "你应该看看他，说他的好名声被毁了。"

translate chinese chinese_3103386_973:
    old "They also told me to let you know that you should get ready for a marriage."
    new "他们还让我告诉你，你应该为结婚做好准备。"

translate chinese chinese_3082775_974:
    old "Because there's no way that I'm having a bastard child."
    new "因为我可不想有个私生子。"

translate chinese chinese_2325992_975:
    old "W- what? M- marriage?"
    new "什、什么？结、结婚？"

translate chinese chinese_1483102_976:
    old "B- but I thought you said that wasn't going to happen."
    new "你之前不是说不会这样的吗？"

translate chinese chinese_3080427_977:
    old "And it probably won't, because I won't let it come to that."
    new "而且这也不会发生，因为我不会让事情发展到那一步的。"

translate chinese chinese_7984428_978:
    old "Besides, remember that the plan is to interrupt the pregnancy before it gets to term."
    new "再说，记得我们的计划是在怀孕未满期前中断它。"

translate chinese chinese_8926949_979:
    old "So there is some pressure because of it."
    new "所以还是有些压力的。"

translate chinese chinese_2562587_980:
    old "But I don't think my mom's going to consult you about wedding plans anytime soon."
    new "但我认为我妈妈近期不会来征求你关于婚礼的建议了。"

translate chinese chinese_3055606_981:
    old "I see... I guess that's a little reassuring."
    new "我明白了……这多少让人放心一点。"

translate chinese chinese_5337545_982:
    old "But anyway, that's not what's most important."
    new "不过话说回来，那不是最重要的。"

translate chinese chinese_4908237_983:
    old "What's most important is what I'm going to do next after this pregnancy."
    new "最重要的是，怀孕之后我接下来要做什么。"

translate chinese chinese_3606629_984:
    old "Are you planning something else?"
    new "你在计划别的什么吗？"

translate chinese chinese_5711886_985:
    old "Of course, my plan is not to be a young mom."
    new "当然，我的计划可不是要做年轻妈妈。"

translate chinese chinese_4162821_986:
    old "And I didn't get pregnant just to get out of an arranged marriage."
    new "我可不是为了逃避包办婚姻才怀孕的。"

translate chinese chinese_1370633_987:
    old "This whole situation is just to buy some time for me to start doing some things that I want to do."
    new "整个情况就是为了给我争取一些时间，让我开始做些我想做的事情。"

translate chinese chinese_5806769_988:
    old "I decided that I want to get into college."
    new "我决定要去上大学了。"

translate chinese chinese_6405645_989:
    old "I need to get on my mother's good side, and to establish a future for myself."
    new "我需要博得妈妈的好感，并为自己建立一个未来。"

translate chinese chinese_9566260_990:
    old "That sounds great Olivia, it sounds like a great plan."
    new "听起来很棒哦，奥利维亚，这真是个好计划。"

translate chinese chinese_3475742_991:
    old "Yeah, but listen..."
    new "是的，但是听..."

translate chinese chinese_8030755_992:
    old "I don't really know how to ask you this."
    new "我真的不知道该怎么问你这个。"

translate chinese chinese_0423241_993:
    old "But I was wondering if you could help me study for the college entrance exams."
    new "但我想知道你能不能帮我复习高考。"

translate chinese chinese_0614073_994:
    old "I know that I've already asked way too much of you, more than what would be reasonable."
    new "我知道我已经向你提出了太多要求，超出了合理的范围。"

translate chinese chinese_8414348_995:
    old "But the truth is that you're a very good teacher, and I think that to get into college I will really need your help."
    new "但事实是你是个非常好的老师，我觉得要上大学我真的需要你的帮助。"

translate chinese chinese_4766436_996:
    old "I would understand it if you don't want to do it."
    new "如果你不想做，我能理解。"

translate chinese chinese_6543800_997:
    old "But if you will, that would be the greatest thing."
    new "但如果你愿意的话，那将是最棒的事。"

translate chinese chinese_1271321_998:
    old "Oh yeah for sure, I'll help you."
    new "哦，当然，我会帮你。"

translate chinese chinese_5498504_999:
    old "Of course, I don't have a problem with doing that."
    new "当然，我做这个没问题。"

translate chinese chinese_3164320_1000:
    old "And I think you need it, that would help you to get out from under your parents."
    new "而且我觉得你需要这个，这会帮你摆脱父母的束缚。"

translate chinese chinese_8184119_1001:
    old "So I'll be more than happy to help you study."
    new "所以我非常乐意帮你学习。"

translate chinese chinese_3949394_1002:
    old "Oh god [pla] you have no idea how good it is to hear that! Thank you so much!"
    new "哦天啊 [pla] 你不知道听到这个有多好！太感谢了！"

translate chinese chinese_3945551_1003:
    old "Glad to help you."
    new "很高兴能帮到你。"

translate chinese chinese_2047012_1004:
    old "Hmm, so I guess we should get going to your house then?"
    new "嗯，那我们应该去你家了？"

translate chinese chinese_7621177_1005:
    old "No, I don't think right now would be a good idea."
    new "不，我觉得现在不是个好主意。"

translate chinese chinese_0712933_1006:
    old "I have to gather some more information about college admission exams and such."
    new "我得再搜集一些关于大学入学考试的信息。"

translate chinese chinese_4637799_1007:
    old "But as soon as I have it I'll let you know."
    new "但我一拿到就会告诉你。"

translate chinese chinese_8779357_1008:
    old "Alright, I'll be waiting."
    new "好吧，我等着。"

translate chinese chinese_1789728_1009:
    old "I guess I'll see you later."
    new "那我猜一会儿见了。"

translate chinese chinese_8423537_1010:
    old "Hey Olivia."
    new "嘿，奥利维亚。"

translate chinese chinese_9825084_1011:
    old "Hey [pla]! How are you doing?"
    new "嘿[pla]！最近怎么样？"

translate chinese chinese_3946747_1012:
    old "I'm alright, and you?"
    new "我挺好的，你呢？"

translate chinese chinese_6864216_1013:
    old "I'm doing well, actually I'm glad that I caught you here."
    new "我挺好的，其实见到你在这里我很高兴。"

translate chinese chinese_8350620_1014:
    old "I got to checking the information that I told you about."
    new "我查了你之前说的那些信息。"

translate chinese chinese_1339972_1015:
    old "So I was wondering if you could come with me to my house so that we can start studying today."
    new "所以我想问问你能不能来我家，我们一起今天就开始学习。"

translate chinese chinese_5424037_1016:
    old "Sure, I'll gladly come with you to study."
    new "行，我很乐意和你一起去学习。"

translate chinese chinese_4272725_1017:
    old "Great! Let's go then."
    new "好极了！那我们走吧。"

translate chinese chinese_2880623_1018:
    old "Alright, I think we should get to it, right?"
    new "好了，我觉得我们应该开始了，对吧？"

translate chinese chinese_6553372_1019:
    old "Alright, so what are we going to study?"
    new "好吧，那我们要学什么？"

translate chinese chinese_0229952_1020:
    old "We're going to be covering the entrance exam for the design school."
    new "我们要开始准备设计学院的入学考试了。"

translate chinese chinese_0690700_1021:
    old "It came to my mind that maybe there could be a couple of previous exams online that I could use to study."
    new "我想也许网上有一些之前的考试题，我可以用来学习。"

translate chinese chinese_6742113_1022:
    old "Hmm, so you want to study design..."
    new "嗯，所以你是想学设计……"

translate chinese chinese_0920484_1023:
    old "I mean, do you think I would be the best person to help you with it?"
    new "我的意思是，你觉得我是帮你搞定这件事的最佳人选吗？"

translate chinese chinese_7416292_1024:
    old "I don't know anything about the subject, to be honest."
    new "说实话，我对这个话题一无所知。"

translate chinese chinese_3923500_1025:
    old "That's alright, you don't actually have to know."
    new "没关系，你其实不需要知道。"

translate chinese chinese_0603218_1026:
    old "The college I'm applying to has a fundamental curriculum that every student must complete."
    new "我申请的大学有一门所有学生都必须完成的基础课程。"

translate chinese chinese_0829634_1027:
    old "And it's very heavy on chemistry, math, and sciences."
    new "而且非常重视化学、数学和科学。"

translate chinese chinese_8432744_1028:
    old "So it's alright if that's what we study. Because those topics are going to be the focus of the admission exam."
    new "所以我们就研究这个也没问题。因为这些话题会是入学考试的重点。"

translate chinese chinese_3017648_1029:
    old "Oh, I see, alright, let's get to it then."
    new "哦，我明白了，那我们就开始吧。"

translate chinese chinese_9660055_1030:
    old "Uhmm, not much, it's just that you're taking very well to this."
    new "嗯，没什么，只是你觉得这个挺顺的。"

translate chinese chinese_8752096_1031:
    old "But before, you were struggling so much to learn the school topics."
    new "但之前，你还在努力学习学校的课程呢。"

translate chinese chinese_4560309_1032:
    old "Well, as I told you before, I'm not dumb."
    new "好吧，就像我之前说的，我可不是傻子。"

translate chinese chinese_2812030_1033:
    old "It's just that the school topics are so much more boring to me."
    new "只是学校里的那些话题对我来说太无聊了。"

translate chinese chinese_9364873_1034:
    old "They're not interesting in any way."
    new "它们一点都不可interesting。"

translate chinese chinese_2015350_1035:
    old "I mean, these are most of the same topics."
    new "我的意思是，这些基本上是同样的话题。"

translate chinese chinese_4984497_1036:
    old "But I'm studying them to get into college and do something that I actually want to do."
    new "但我是在为了上大学和做我想做的事情而努力学习。"

translate chinese chinese_9095242_1037:
    old "It also has to do with the fact that I kinda know I have to push myself through this."
    new "这也因为我心里明白，我得逼自己挺过去。"

translate chinese chinese_2111186_1038:
    old "With how far I've come already, it would be a real shame if I gave up now."
    new "我都已经走到这一步了，如果现在放弃就太可惜了。"

translate chinese chinese_6096208_1039:
    old "I see, that actually makes a lot of sense."
    new "我明白了，这实际上说得通。"

translate chinese chinese_9122612_1040:
    old "Come on, let's keep going."
    new "快点，我们继续吧。"

translate chinese chinese_1166638_1041:
    old "Alright, I think that should be enough for today."
    new "好吧，我觉得今天就到此为止吧。"

translate chinese chinese_3238028_1042:
    old "Really? Already?"
    new "真的？已经？"

translate chinese chinese_1006062_1043:
    old "Yeah sure, this was just an introductory session."
    new "嗯哼，这只是一个入门环节。"

translate chinese chinese_3294219_1044:
    old "So we should stop before we get too tired."
    new "所以我们应该在太累之前停下来。"

translate chinese chinese_0615064_1045:
    old "Hmm, yeah I guess you're right."
    new "嗯，我想你是对的。"

translate chinese chinese_7451863_1046:
    old "Alright, that was very good."
    new "好吧，你做得很好。"

translate chinese chinese_5777405_1047:
    old "If we keep going like that, I'm sure you'll ace that entrance exam."
    new "如果我们继续这样下去，我相信你一定能考上。"

translate chinese chinese_8832187_1048:
    old "For everything, you know?"
    new "所有的一切，你知道的？"

translate chinese chinese_7135175_1049:
    old "I have been coming up with these crazy plans, and you've kept supporting me."
    new "我一直在想这些疯狂的计划，而你一直支持我。"

translate chinese chinese_1542355_1050:
    old "Thanks a lot."
    new "多谢了。"

translate chinese chinese_3987018_1051:
    old "So, I guess I should get going, but I'll come back soon so that we can keep studying."
    new "所以，我想我该走了，但我会很快回来继续学习的。"

translate chinese chinese_2750194_1052:
    old "And of course, to check on the pregnancy."
    new "当然，还要确认一下怀孕的事情。"

translate chinese chinese_9671921_1053:
    old "Sure thing [pla], thanks a lot."
    new "没问题[pla]，多谢了。"

translate chinese chinese_0343620_1054:
    old "Hey [pla]! Did you come to study again?"
    new "嘿[pla]！你是来学习的吗？"

translate chinese chinese_0257427_1055:
    old "Yeah, I figured that it's time for another session."
    new "嗯，我觉得是时候再来一次了。"

translate chinese chinese_2943526_1056:
    old "Great, let's get to it then."
    new "好，那我们开始吧。"

translate chinese chinese_4493543_1057:
    old "Alright, where did we leave off last time?"
    new "好了，上次我们说到哪里了？"

translate chinese chinese_2351388_1058:
    old "I think it was this topic here..."
    new "我觉得是这个话题……"

translate chinese chinese_4696400_1059:
    old "Oh yeah! For sure!"
    new "哦对！肯定的！"

translate chinese chinese_8241036_1060:
    old "Alright, let's continue from there then."
    new "好吧，那我们就从那里继续吧。"

translate chinese chinese_4725596_1061:
    old "Alright, that was a good session."
    new "好吧，这次训练不错。"

translate chinese chinese_9233884_1062:
    old "Just a couple more and I know you'll have what it takes to ace those exams."
    new "就剩下几个了，我知道你有足够的能力考好这些考试。"

translate chinese chinese_0414634_1063:
    old "Thanks a lot [pla]..."
    new "多谢了[pla]..."

translate chinese chinese_8817052_1064:
    old "For everything."
    new "为了所有的一切。"

translate chinese chinese_8271305_1065:
    old "Hey, my pleasure."
    new "嘿，我的荣幸。"

translate chinese chinese_3148953_1066:
    old "I have to leave for now, but I'll come back to see you soon, alright?"
    new "我先得走了，但我会很快再来看你，好吗？"

translate chinese chinese_6152533_1067:
    old "Sure, no problem, see you."
    new "好的，没问题，再见。"

translate chinese chinese_7323885_1068:
    old "Hi Mrs. Priya, how are you?"
    new "嗨，Priya夫人，你好吗？"

translate chinese chinese_8078463_1069:
    old "Are you here looking for Olivia?"
    new "你是来找奥利维亚的吗？"

translate chinese chinese_1905958_1070:
    old "Uhh, yeah, I was kinda hoping to catch her here."
    new "嗯，是啊，我本来有点希望能在这里碰到她。"

translate chinese chinese_9442331_1071:
    old "Well, no, she's at school."
    new "嗯，她还在学校。"

translate chinese chinese_5387622_1072:
    old "And you should be there too, you know?"
    new "你知道，你也应该在那里的。"

translate chinese chinese_8913364_1073:
    old "Uh, yeah, yeah, you're probably right."
    new "嗯，对对，你probably说得对。"

translate chinese chinese_0029895_1074:
    old "I'll come by later then."
    new "那我晚点再来。"

translate chinese chinese_8619267_1075:
    old "Sure, I'll let her know you stopped by."
    new "好的，我会告诉她你来过的。"

translate chinese chinese_0158280_1076:
    old "Hi, Mrs. Priya, how are you?"
    new "嗨，普里亚夫人，你好吗？"

translate chinese chinese_9274141_1077:
    old "Hello, [pla]. I'm doing fine, and you?"
    new "你好，[pla]。我挺好的，你呢？"

translate chinese chinese_7436243_1078:
    old "I'm alright, thank you."
    new "我挺好的，谢谢。"

translate chinese chinese_3408019_1079:
    old "That's good to hear..."
    new "听到这个很好……"

translate chinese chinese_7147698_1080:
    old "So tell me, did you come looking for Olivia?"
    new "说吧，你是来找奥利维亚的吗？"

translate chinese chinese_9400852_1081:
    old "That's right. Is she here?"
    new "没错。她在吗？"

translate chinese chinese_1490111_1082:
    old "Great... Yes, she's in her room."
    new "好吧……是的，她在房间里。"

translate chinese chinese_2785692_1083:
    old "You can go in, go ahead, don't mind me."
    new "你可以进去，随便看看，不用管我。"

translate chinese chinese_5917927_1084:
    old "Uh... S- sure, thank you."
    new "呃……好，谢谢。"

translate chinese chinese_6104266_1085:
    old "I guess I'll see you around, Mrs. Priya."
    new "那我就四处见你吧，普里亚夫人。"

translate chinese chinese_0616013_1086:
    old "Yes, of course. Good afternoon, [pla]."
    new "是的，当然。下午好，[pla]。"

translate chinese chinese_7127305_1087:
    old "Alright, that's good. I think we can move on to something else."
    new "好吧，这样就行了。我觉得我们可以换个话题了。"

translate chinese chinese_7073331_1088:
    old "Ok, that sounds good."
    new "好的，听起来不错。"

translate chinese chinese_1577088_1089:
    old "Olivia, are you there? I'm coming in!"
    new "奥利维亚，你在吗？我要进来了！"

translate chinese chinese_3228550_1090:
    old "Oh [pla], hi... So you were here too."
    new "哦 [pla]，嗨……原来你也在这里。"

translate chinese chinese_1274095_1091:
    old "H- hi Mrs. Priya."
    new "嗨，普里亚夫人。"

translate chinese chinese_3853300_1092:
    old "We were just studying, Mom, nothing else."
    new "我们只是在学习，妈妈，没有别的。"

translate chinese chinese_1907157_1093:
    old "Yeah well, I hope it's going better than last time you two studied."
    new "好吧，希望这次比上次你们俩学习的时候好些。"

translate chinese chinese_7290690_1094:
    old "Anyway, what do you want?"
    new "总之，你想要什么？"

translate chinese chinese_3025623_1095:
    old "What do you mean by that? Did you forget that we have a phone call with your father to talk about your pregnancy?"
    new "你这话是什么意思？你不记得我们今天要和你爸爸打电话讨论你的怀孕事情了吗？"

translate chinese chinese_7460823_1096:
    old "And before you ask, no, we cannot reschedule, you know how Vihaan is about his time."
    new "而且在你问之前，不行，我们不能改时间，你知道维韩对时间有多讲究。"

translate chinese chinese_8681401_1097:
    old "Oh shoot! I forgot about it!"
    new "哦糟了！我忘了这事！"

translate chinese chinese_9527318_1098:
    old "Listen [pla], I'm going to have to step out for a while, this call with my dad is very important."
    new "听着 [pla]，我得出去一下，我跟我爸爸的电话很重要。"

translate chinese chinese_1702973_1099:
    old "But please don't leave."
    new "但是请不要离开。"

translate chinese chinese_2171745_1100:
    old "This isn't going to take too much time. And we have a lot more to cover in today's session."
    new "这不会花太多时间。而且今天我们还有很多内容要讲。"

translate chinese chinese_3830948_1101:
    old "So, I'll talk to my dad, and I'll come back so that we can keep studying."
    new "所以，我会和我爸爸谈谈，然后回来继续学习。"

translate chinese chinese_2070112_1102:
    old "Oh, a- alright, sure, no problem."
    new "哦，好啦，没问题。"

translate chinese chinese_0425700_1103:
    old "Come on, we have to go call him now."
    new "快点，我们现在得去给他打电话。"

translate chinese chinese_8353392_1104:
    old "Alright, alright, let's go."
    new "好吧，好吧，我们走。"

translate chinese chinese_4040003_1105:
    old "Hmm, I mean, I guess I'll just sit here and wait for her to come back."
    new "嗯，我就坐在这里等她回来吧。"

translate chinese chinese_1372814_1106:
    old "Hey brother-in-law! How are you?"
    new "喂，姐夫！你好吗？"

translate chinese chinese_4142855_1107:
    old "Uhmm, hi... I'm doing fine."
    new "嗯，嗨……我挺好的。"

translate chinese chinese_3675684_1108:
    old "But what are you doing here all alone?"
    new "但是你一个人在这里干什么？"

translate chinese chinese_1006778_1109:
    old "Oh, I was helping your sister study."
    new "哦，我在帮你姐姐学习。"

translate chinese chinese_0534808_1110:
    old "And you know, spending time with her and checking that the pregnancy is going well."
    new "而且你知道，花时间和她一起检查怀孕情况是否正常。"

translate chinese chinese_5595015_1111:
    old "But she had to step out with your mom for a call they had scheduled with your dad."
    new "但她得和你妈妈出去，接一个之前跟你爸爸约好的电话。"

translate chinese chinese_4679430_1112:
    old "So I'm just waiting here for her to come back."
    new "所以我就在这里等她回来。"

translate chinese chinese_7746276_1113:
    old "I see, hmm, that's interesting, I guess."
    new "哦，嗯，那挺有意思的，我想。"

translate chinese chinese_1224835_1114:
    old "Do you like spending time with her?"
    new "你喜欢和她在一起吗？"

translate chinese chinese_8564353_1115:
    old "Uh, I mean, y- yeah sure."
    new "呃，我的意思是，好啦。"

translate chinese chinese_3997932_1116:
    old "I see, I see."
    new "我知道，我知道。"

translate chinese chinese_6747250_1117:
    old "And you like to do it even though she's just a fat cow?"
    new "而且你喜欢这么做，尽管她只是个胖奶牛？"

translate chinese chinese_6266941_1118:
    old "W- what? What are you talking about?"
    new "什、什么？你在说什么？"

translate chinese chinese_4998369_1119:
    old "Nothing much, I was just wondering if you still like to spend time with her."
    new "没什么，就是想知道你是否还喜欢和她在一起。"

translate chinese chinese_1790654_1120:
    old "Because she no longer looks as beautiful as she did before."
    new "因为她不再像以前那样美丽了。"

translate chinese chinese_7317546_1121:
    old "You know, she's been getting fatter and fatter."
    new "你知道吗，她越来越胖了。"

translate chinese chinese_8518600_1122:
    old "I can't imagine that's attractive in any way."
    new "我简直无法想象这有什么吸引力。"

translate chinese chinese_5185659_1123:
    old "Uhmm, to be honest with you that's not even something I had considered."
    new "嗯，说实话，这根本就没在我考虑范围内。"

translate chinese chinese_3599950_1124:
    old "I mean, she just looks a little bit bigger because of the pregnancy."
    new "我的意思是，她只是因为怀孕看起来大了一点点。"

translate chinese chinese_2275789_1125:
    old "But that's completely normal, right?"
    new "但这完全正常，对吧？"

translate chinese chinese_8621628_1126:
    old "Yeah, yeah, as I was saying, she's a fat cow."
    new "yeah, yeah，就像我说的，她就是一头肥母牛。"

translate chinese chinese_2444694_1127:
    old "But anyway, that's not important right now."
    new "不过话说回来，那现在不重要。"

translate chinese chinese_2484443_1128:
    old "You know? I've been thinking a lot about you recently."
    new "你知道吗？我最近一直在想你。"

translate chinese chinese_1210359_1129:
    old "Y- you have? H- how come?"
    new "你——有？那——为什么？"

translate chinese chinese_9660247_1130:
    old "I just think it's very unfortunate that you had to fall in love with the worst part of our family."
    new "我只是觉得很不幸，你竟然爱上了我们家族最糟糕的部分。"

translate chinese chinese_1369478_1131:
    old "I mean sure, my sister's pretty."
    new "我的意思是，我妹妹确实挺漂亮的。"

translate chinese chinese_5921067_1132:
    old "But you know that she doesn't care about you, not really, right?"
    new "但你知道她其实并不在乎你，对吧？"

translate chinese chinese_3810995_1133:
    old "She's just using you to get out of going to India."
    new "她只是想利用你来逃避去印度。"

translate chinese chinese_3105164_1134:
    old "I'm sorry it has to be like that."
    new "很抱歉事情变成这样。"

translate chinese chinese_1300529_1135:
    old "Uh- I uh-"
    new "呃——我呃——"

translate chinese chinese_0173187_1136:
    old "I'm not sure I know what you're talking about..."
    new "我不确定我明白你在说什么……"

translate chinese chinese_1698954_1137:
    old "Yeah right, of course you don't!"
    new "是啊，当然不！"

translate chinese chinese_1579114_1138:
    old "But anyway, it's a shame that she's not only using you, but that you also have to have sex with her."
    new "不过话说回来，她不仅在利用你，你还得跟她发生关系，真是够倒霉的。"

translate chinese chinese_1104620_1139:
    old "With how bad she is, it surprises me that you're that much into her."
    new "以她那样，你还这么喜欢她，真让我惊讶。"

translate chinese chinese_3315282_1140:
    old "Uh... W- what do you mean?"
    new "呃……你什么意思？"

translate chinese chinese_3583476_1141:
    old "Oh come on [pla]!"
    new "哦，快点吧，[pla]！"

translate chinese chinese_1450732_1142:
    old "You know my sister's nothing special in bed."
    new "你知道我妹妹在床上没什么特别的。"

translate chinese chinese_5287715_1143:
    old "It only took me the other day to be sure that she's not any good with sex stuff."
    new "我那天才确定她对性方面真的不在行。"

translate chinese chinese_6877824_1144:
    old "She was sucking your dick without any interest in doing it."
    new "她吸你的 dicks 时完全没什么兴趣。"

translate chinese chinese_5081411_1145:
    old "Which is a shame because that big dick of yours deserves better."
    new "真可惜，因为你那大棒子值得更好的待遇。"

translate chinese chinese_4367197_1146:
    old "I mean, it's such an amazing dick. So big and so thick."
    new "我的意思是，那真是个棒极了的家伙。又大又粗。"

translate chinese chinese_1705699_1147:
    old "My sister's just wasting it with that sloppy technique of hers."
    new "我妹妹用那种粗糙的技巧就是在浪费它。"

translate chinese chinese_9604091_1148:
    old "And in bed..."
    new "而在床上……"

translate chinese chinese_4253172_1149:
    old "I bet she's just a dead fish, she probably isn't anything special there."
    new "我敢打赌她肯定是个死鱼烂虾，那里肯定没什么特别的。"

translate chinese chinese_9730079_1150:
    old "I was thinking that it would do you well to have a small tasting of what you've been missing..."
    new "我在想让你尝尝你错过的滋味可能会对你有好处……"

translate chinese chinese_2149441_1151:
    old "Uh, I uh..."
    new "呃，我呃……"

translate chinese chinese_8935226_1152:
    old "I- think you shouldn't be here..."
    new "我——觉得你不应该在这里..."

translate chinese chinese_7773869_1153:
    old "Y- your sister could think the wrong thing."
    new "你姐姐可能会误会的。"

translate chinese chinese_3036245_1154:
    old "And what would that be?"
    new "那会是什么？"

translate chinese chinese_6972168_1155:
    old "Y- you know... L- like."
    new "你、你知道的……像那样。"

translate chinese chinese_6699055_1156:
    old "Come on brother-in-law, I know you'll love it."
    new "来吧姐夫，我知道你会喜欢的。"

translate chinese chinese_2789322_1157:
    old "W- what are you doing?!!"
    new "你干什么呢!!"

translate chinese chinese_2013291_1158:
    old "Come on! I know you'll love this!"
    new "快来吧！我知道你会喜欢这个的！"

translate chinese chinese_7704932_1159:
    old "W- what if your sister or your mom comes in here?!"
    new "万一你妹妹或者你妈妈进来怎么办?!"

translate chinese chinese_6938581_1160:
    old "Ugh, relax, nothing will happen!"
    new "哎呀，放松点，没什么会发生的！"

translate chinese chinese_4552641_1161:
    old "I'm sure you've never had anything like it."
    new "我敢肯定你从未有过这样的经历。"

translate chinese chinese_7702027_1162:
    old "Now you can see what you're missing by doing it with my sister."
    new "现在你可以看到和我妹妹做的时候你错过了什么。"

translate chinese chinese_6648709_1163:
    old "It's a shame that you have to endure something like that."
    new "真可惜，你竟然要经历这样的事情。"

translate chinese chinese_5390819_1164:
    old "But you never know, maybe you and I can have another one of these sessions sometime."
    new "但说不准，也许将来我们还能再来一次这样的聚会。"

translate chinese chinese_0360010_1165:
    old "Or maybe we could do something else."
    new "或者我们可以做别的事情。"

translate chinese chinese_2317461_1166:
    old "Yeah... That's great."
    new "嗯……那很好。"

translate chinese chinese_1634282_1167:
    old "But it might be better if you leave for now, you know?"
    new "不过你现在先离开可能会更好，你知道的？"

translate chinese chinese_7738074_1168:
    old "Sure, I guess I will."
    new "好吧，我想我会的。"

translate chinese chinese_4677307_1169:
    old "But I'll be seeing you later."
    new "但是待会儿还会见到你。"

translate chinese chinese_5785713_1170:
    old "God... She is something else."
    new "天……她真是个奇葩。"

translate chinese chinese_0370670_1171:
    old "Is everyone in this family so brazen?"
    new "这家人是不是都这么大胆？"

translate chinese chinese_1901152_1172:
    old "I'm just glad nobody saw us."
    new "我就放心没人看到我们。"

translate chinese chinese_4005895_1173:
    old "Hey [pla], I'm sorry I kept you waiting for so long."
    new "嘿[pla]，对不起让你等了这么久。"

translate chinese chinese_1947846_1174:
    old "Hey, it's alright, no problem."
    new "嘿，没事，没问题。"

translate chinese chinese_1516567_1175:
    old "I imagine you had a lot to talk with your dad, didn't you?"
    new "我想你有很多话要和你爸爸说吧？"

translate chinese chinese_6377786_1176:
    old "Oh yeah, a lot, he just kept going and going."
    new "哦 yeah，很多，他就一直不停地来。"

translate chinese chinese_6022671_1177:
    old "I understand. Are you ready to get back to studying?"
    new "我明白。你准备好回去学习了吗？"

translate chinese chinese_9173566_1178:
    old "You know what? I think we should stop for the day."
    new "你知道吗？我觉得今天就到这儿吧。"

translate chinese chinese_2726568_1179:
    old "I just had a very bad conversation with my Dad and mom and I don't feel like studying at the moment."
    new "我刚和爸妈吵了一架，现在没心情学习。"

translate chinese chinese_3484593_1180:
    old "I think I just want to rest a little bit."
    new "我觉得我只是想休息一下。"

translate chinese chinese_3169261_1181:
    old "Oh! Sure, sure, no problem."
    new "哦！好的好的，没问题。"

translate chinese chinese_0780004_1182:
    old "Hey Oli, how are you?"
    new "嘿奥利，最近怎么样？"

translate chinese chinese_7550403_1183:
    old "Hey [pla], how are you doing right now?"
    new "嘿[pla]，你现在怎么样？"

translate chinese chinese_2465683_1184:
    old "I'm doing fine, I came for us to continue studying. Are you ready?"
    new "我挺好的，我是来继续学习的。你准备好了吗？"

translate chinese chinese_6461861_1185:
    old "You know? I don't think I am."
    new "你知道吗？我觉得我可能不是。"

translate chinese chinese_0737091_1186:
    old "I've been feeling really bad all day."
    new "我今天一整天都感觉很糟糕。"

translate chinese chinese_9584983_1187:
    old "You know, things from the pregnancy."
    new "你知道的，怀孕期间的事情。"

translate chinese chinese_5153633_1188:
    old "So I think I'll just lay down for a while."
    new "所以我想我先躺一会儿吧。"

translate chinese chinese_9799703_1189:
    old "I'm sorry that you came all the way here for nothing."
    new "真对不起，让你白跑一趟。"

translate chinese chinese_9973633_1190:
    old "It's alright, I understand."
    new "没关系，我明白。"

translate chinese chinese_2978702_1191:
    old "You're pregnant, it's only natural that the body would feel that way."
    new "你怀孕了，身体有这样的感觉是很正常的。"

translate chinese chinese_2623738_1192:
    old "The best thing would be for you to rest, and we can see each other later."
    new "最好你先休息一下，我们晚点再见面。"

translate chinese chinese_6203943_1193:
    old "Sure [pla], see you later."
    new "好的[pla]，回头见。"

translate chinese chinese_7859924_1194:
    old "Hmm, you know, I think I need to use the bathroom."
    new "嗯，你知道吗，我觉得我需要去洗手间。"

translate chinese chinese_2610828_1195:
    old "Oh, sure!"
    new "哦，当然！"

translate chinese chinese_6796353_1196:
    old "No problem, it's down the hallway."
    new "没问题，就在走廊尽头。"

translate chinese chinese_3526521_1197:
    old "Alright, I'll be back in a minute."
    new "好的，我一会儿就回来。"

translate chinese chinese_4109372_1198:
    old "Hmm, there's a weird sound coming from that room, what's going on in there?"
    new "嗯，那房间里传来奇怪的声音，里面到底在干什么？"

translate chinese chinese_9327822_1199:
    old "I don't think there's any harm in checking, right?"
    new "我觉得查一下也没坏处，对吧？"

translate chinese chinese_5124460_1200:
    old "{i}(D- damn! That's Olivia's mom!){/i}"
    new "{i}(妈的！那是Olivia的妈妈！){/i}"

translate chinese chinese_6533360_1201:
    old "{i}(And she's masturbating!){/i}"
    new "{i}(而且她在自慰！){/i}"

translate chinese chinese_2011235_1202:
    old "{i}(I- I think she's having video sex with her husband.){/i}"
    new "{i}(我觉…我觉得她正在和她丈夫视频啪。){/i}"

translate chinese chinese_1083444_1203:
    old "{i}(S- should I leave? But what if I make noise and she catches me?){/i}"
    new "{i}(我应该离开吗？但如果我发出声音被她发现了怎么办？){/i}"

translate chinese chinese_7793941_1204:
    old "Oh yes! Yes, do you like what you're seeing honey?"
    new "哦，是的！你喜欢看到的吗，宝贝？"

translate chinese chinese_6449997_1205:
    old "Of course I do! I love what I'm seeing!"
    new "当然了！我爱死我看到的了！"

translate chinese chinese_2923998_1206:
    old "What the fuck is wrong with you?"
    new "你他妈怎么了？"

translate chinese chinese_3742015_1207:
    old "How long were you there just peeping on me?"
    new "你在那里偷看我多久了？"

translate chinese chinese_0203883_1208:
    old "You are my daughter's fiancé! Have you no shame at all?!"
    new "你是我女儿的未婚夫！你一点羞耻心都没有吗？!"

translate chinese chinese_9347558_1209:
    old "I- I'm so sorry Mrs. Priya!"
    new "我真的很抱歉，普里亚夫人！"

translate chinese chinese_0506067_1210:
    old "But I swear to god that it wasn't my intention to break your privacy."
    new "但我发誓，我真的没有打算侵犯你的隐私。"

translate chinese chinese_3534456_1211:
    old "I was just coming back from the bathroom when I heard some weird noise coming from the bedroom."
    new "我刚从浴室回来，就听到卧室里传来一些奇怪的声音。"

translate chinese chinese_1715783_1212:
    old "I just wanted to make sure that there wasn't anything wrong in here."
    new "我只是想确认一下这里没有什么问题。"

translate chinese chinese_0574468_1213:
    old "And I accidentally saw you..."
    new "而且我无意中看到了你..."

translate chinese chinese_2349353_1214:
    old "I thought about leaving, but I didn't want to make any noise that could alert you to my presence."
    new "我本想离开，但又不想发出任何声音让你察觉到我的存在。"

translate chinese chinese_6858193_1215:
    old "But I swear to god this was just a big misunderstanding ma'am."
    new "但我发誓，这真的只是一个大误会，女士。"

translate chinese chinese_5101531_1216:
    old "I mean, I want to believe you but..."
    new "我的意思是，我想相信你，但是……"

translate chinese chinese_7352588_1217:
    old "{i}(My god is that his hand??){/i}"
    new "{i}(天啊，那真的是他的手吗？){/i}"

translate chinese chinese_3092428_1218:
    old "{i}(How big is he?!){/i}"
    new "{i}(他有多大？!){/i}"

translate chinese chinese_4908883_1219:
    old "{i}(He must be at least twice as big as Vihaan!){/i}"
    new "{i}（他至少是维哈安的两倍大！){/i}"

translate chinese chinese_2975880_1220:
    old "Uhmm, ma'am? Is everything alright?"
    new "嗯，女士？一切都好吗？"

translate chinese chinese_6986790_1221:
    old "What? Oh yeah..."
    new "什么？哦，对了..."

translate chinese chinese_1724431_1222:
    old "Listen [pla], I'll believe you for now."
    new "听着，[pla]，我暂时相信你。"

translate chinese chinese_2787425_1223:
    old "But it still isn't alright that you were just spying on me like that."
    new "但是你那样偷看我还是不对的。"

translate chinese chinese_0485596_1224:
    old "Next time knock or something, so that I can at least be prepared."
    new "下次敲个门什么的，至少让我有所准备。"

translate chinese chinese_4940268_1225:
    old "Yeah, you're right, I'm sorry."
    new "嗯，你说得对，对不起。"

translate chinese chinese_8327140_1226:
    old "Now, my daughter will think something's happening if you take that long to come back from the bathroom."
    new "现在，如果你上厕所这么久不回来，我女儿会以为出了什么事的。"

translate chinese chinese_9655600_1227:
    old "So go back already."
    new "那就回去吧。"

translate chinese chinese_3891031_1228:
    old "Uh... S- sure, excuse me."
    new "呃……好、好的，对不起。"

translate chinese chinese_1752528_1229:
    old "That was a very unpleasant surprise."
    new "那真是个非常不愉快的惊喜。"

translate chinese chinese_1664164_1230:
    old "But I guess I'll believe him."
    new "但我想我会相信他的。"

translate chinese chinese_9721355_1231:
    old "But I wasn't expecting him to have such a huge boner from seeing me."
    new "但我没想到他看到我会这么兴奋。"

translate chinese chinese_0044779_1232:
    old "Is that what Olivia is enjoying?"
    new "那就是奥利via享受的？"

translate chinese chinese_8191458_1233:
    old "Meanwhile all I have is my fingers and a laptop..."
    new "而我只有手指和一台笔记本电脑……"

translate chinese chinese_7677999_1234:
    old "Damn! I wasn't expecting that!"
    new "妈的！我没想到会这样！"

translate chinese chinese_9378889_1235:
    old "I guess I'm lucky that she didn't get angrier with me."
    new "猜她没生我的气已经算我走运了。"

translate chinese chinese_3869859_1236:
    old "Next time I should just keep walking and mind my own business."
    new "下次我应该直接走开，少管闲事。"

translate chinese chinese_9472352_1237:
    old "Hey, what took you so long? Are you alright?"
    new "喂，你这么久才来，没事吧？"

translate chinese chinese_5295159_1238:
    old "Me? O- oh yeah."
    new "我？O- 哦，对了。"

translate chinese chinese_8667849_1239:
    old "I - I think I just ate something bad."
    new "我——我觉得我可能是吃坏东西了。"

translate chinese chinese_9526642_1240:
    old "But I'm alright now."
    new "但现在我没事了。"

translate chinese chinese_9701904_1241:
    old "Well, let's keep studying."
    new "好吧，我们继续学习吧。"

translate chinese chinese_1029450_1242:
    old "We have a lot more to do. Come on."
    new "我们还有很多事情要做。快点。"

translate chinese chinese_6232293_1243:
    old "Oh! Hi Olivia, how are you today?"
    new "哦！奥利维亚，你今天怎么样？"

translate chinese chinese_6557385_1244:
    old "I'm doing fine, and you? How are you?"
    new "我挺好的，你呢？怎么样？"

translate chinese chinese_6516659_1245:
    old "Oh I'm alright, you know, not much is happening."
    new "哦，我挺好的，你知道的，没什么特别的事。"

translate chinese chinese_5157365_1246:
    old "How are you handling the pregnancy? Is everything alright?"
    new "怀孕的情况怎么样？一切都好吗？"

translate chinese chinese_0330541_1247:
    old "Oh yeah, for the most part it is."
    new "哦对，大部分情况都是这样的。"

translate chinese chinese_5311119_1248:
    old "My mom's still in a bad mood, but I think she'll come around."
    new "我妈妈还在生气，但我觉得她会想通的。"

translate chinese chinese_4523649_1249:
    old "The other thing is that I've been feeling somewhat bad because of nausea and stuff."
    new "还有就是我因为恶心什么的觉得有点不舒服。"

translate chinese chinese_0413519_1250:
    old "You have seen it, how I get, I start to feel bad and my head hurts and stuff."
    new "你见过的，我一发作就感觉很难受，头也疼。"

translate chinese chinese_1924174_1251:
    old "Yeah, I know, I'm sorry about that."
    new "是的，我知道，对不起。"

translate chinese chinese_1432954_1252:
    old "I hope that as the pregnancy goes the symptoms will start to decrease."
    new "希望随着怀孕进展，症状会开始减轻。"

translate chinese chinese_2657839_1253:
    old "Yeah, me too. But I mean is not as if I'm not managing to..."
    new "是啊，我也是。但我的意思是也不是说我没有办法……"

translate chinese chinese_4193359_1254:
    old "Hey you idiot! What do you think you're doing bothering her this early in the morning?"
    new "喂你白痴啊！一大早烦她干什么？"

translate chinese chinese_7416200_1255:
    old "What? Did you think that just because Olivia's pregnant now you could just start harassing her like it was nothing?"
    new "什么？你不会以为奥利维亚怀孕了你就可以随便骚扰她吧？"

translate chinese chinese_7466695_1256:
    old "Well think again buddy, because I'm not gonna let you bother her anymore!"
    new "那可得重新考虑了，因为我不会再让你烦她了！"

translate chinese chinese_8294932_1257:
    old "Actually, why don't you get out of here before I call the teachers of you for harassing Olivia?"
    new "实际上，你在我说你骚扰奥利维亚去叫老师之前赶紧滚蛋吧。"

translate chinese chinese_3592101_1258:
    old "Hey! I'm not harassing anybody!"
    new "喂！我没骚扰任何人！"

translate chinese chinese_4149649_1259:
    old "Get out of here or I'll call the teachers!"
    new "滚出去不然我叫老师了！"

translate chinese chinese_3536547_1260:
    old "We'll see who they believe more..."
    new "咱们看看他们更相信谁..."

translate chinese chinese_6800662_1261:
    old "Jeez, I'm leaving then."
    new "喂，那我走了啊。"

translate chinese chinese_0431915_1262:
    old "Hpmh finally that stalker left."
    new "哼，那个跟踪狂终于走了。"

translate chinese chinese_8481876_1263:
    old "How are you? Are you alright?"
    new "你怎么样？还好吗？"

translate chinese chinese_1932270_1264:
    old "H- hi, I'm doing well, and you?"
    new "嗨，我挺好的，你呢？"

translate chinese chinese_2561889_1265:
    old "Well, I'm alright, you know. There's nothing much going on in my life."
    new "嗯，我还好啦。我生活中也没什么大事发生。"

translate chinese chinese_2801011_1266:
    old "Unlike you..."
    new "不像你……"

translate chinese chinese_7606359_1267:
    old "I can't believe you didn't tell me about this before."
    new "真不敢相信你之前没告诉我这件事。"

translate chinese chinese_6749334_1268:
    old "I'm only finding out because of your belly."
    new "我只因为你肚子的事才知道的。"

translate chinese chinese_7392863_1269:
    old "Why didn't you let me know before?"
    new "你之前为什么不告诉我？"

translate chinese chinese_1432131_1270:
    old "W- well, the truth is that even though I found out early, I wasn't really sure about who to tell."
    new "嗯，其实我虽然早就发现了，但也不知道该告诉谁好。"

translate chinese chinese_8096316_1271:
    old "Why not? Is everything alright?"
    new "为什么不行？一切都好吗？"

translate chinese chinese_0133918_1272:
    old "Uhmm, I guess it is."
    new "嗯，我想是这样的。"

translate chinese chinese_5433765_1273:
    old "I've just been dealing with my parents. You know how they are."
    new "我刚和我爸妈打交道。你知道他们是什么样的。"

translate chinese chinese_5759138_1274:
    old "Hmph, yeah, I have an idea."
    new "哼，好吧，我有个主意。"

translate chinese chinese_1458213_1275:
    old "And what does the father say? Is he helping you?"
    new "那父亲怎么说？他在帮你吗？"

translate chinese chinese_8978152_1276:
    old "Hmm, w- well... W- we're actually not in contact."
    new "嗯，那个……其实我们已经不联系了。"

translate chinese chinese_2704149_1277:
    old "What? Is that scumbag not planning on answering for what he did?"
    new "什么？那混蛋不打算为他的行为负责吗？"

translate chinese chinese_0312923_1278:
    old "Tell me who he is! I'll make him answer!"
    new "告诉我他是谁！我会让他回答的！"

translate chinese chinese_3154582_1279:
    old "N- no, it's nothing like what you're imagining."
    new "不，不是你想的那样。"

translate chinese chinese_0000191_1280:
    old "Is not that he doesn't want to answer for it, is just that..."
    new "不是他不想回答，只是……"

translate chinese chinese_3642863_1281:
    old "I don't know who he is."
    new "我不知道他是谁。"

translate chinese chinese_1571291_1282:
    old "How come?"
    new "为什么？"

translate chinese chinese_6129890_1283:
    old "Well, it happened at this party."
    new "嗯，这件事发生在一次聚会上。"

translate chinese chinese_7379264_1284:
    old "I didn't measure my drinks and got drunk."
    new "我没控制好饮酒量，喝醉了。"

translate chinese chinese_2907512_1285:
    old "And there was this very tall guy that I thought was cute."
    new "而且有个很高大的家伙我觉得挺可爱的。"

translate chinese chinese_4811177_1286:
    old "I decided to approach him and we ended up spending the night together."
    new "我决定主动接近他，结果我们在一起过了一夜。"

translate chinese chinese_8046664_1287:
    old "But I never asked him his name or where he goes to school or anything."
    new "但我从来没有问他叫什么名字，上哪所学校之类的。"

translate chinese chinese_9255724_1288:
    old "To be honest, I barely remember his face."
    new "说实话，他的脸我几乎都记不清了。"

translate chinese chinese_0414888_1289:
    old "So you see, there's not much use in worrying about the father."
    new "所以你看，担心那个父亲也没什么用。"

translate chinese chinese_8136883_1290:
    old "Hmph, I guess you're right."
    new "哼，我想你是对的。"

translate chinese chinese_8041718_1291:
    old "But it doesn't matter, you don't need that deadbeat to answer for anything."
    new "但那没关系，你不需要那个混蛋来为你做任何解释。"

translate chinese chinese_7649413_1292:
    old "You have your family and you have me, that's all you need."
    new "你有家人，还有我，这就足够了。"

translate chinese chinese_3067676_1293:
    old "Thanks Ruby, I know I can always count on you."
    new "谢谢你了，Ruby，我知道我总是可以依赖你。"

translate chinese chinese_3425736_1294:
    old "But to be honest, I don't know yet if I'll be keeping it you know?"
    new "但老实说，我还不确定会不会留着它。"

translate chinese chinese_9461559_1295:
    old "Having a baby is a lot of work, so I'm still figuring out if I'll actually be a mother."
    new "养孩子很辛苦，所以我还在考虑自己是否真的要做母亲。"

translate chinese chinese_8790857_1296:
    old "I see, I understand... That makes a lot of sense."
    new "我明白了，说得有道理……这样理解起来容易多了。"

translate chinese chinese_0917998_1297:
    old "And if you decide not to have it, what are you going to do about it?"
    new "如果你决定不要它，那你打算怎么办？"

translate chinese chinese_0503919_1298:
    old "Well, I was thinking that I could just go to the same doctor your friend went to that other time."
    new "嗯，我在想我干脆去你朋友上次去的那同一个医生那里好了。"

translate chinese chinese_8648736_1299:
    old "They did a very good job the last time, didn't they?"
    new "上次他们做得很好，不是吗？"

translate chinese chinese_3358142_1300:
    old "I think I could go to them."
    new "我觉得我可以去找他们。"

translate chinese chinese_2972217_1301:
    old "I see, I understand... Well, I agree."
    new "我明白了……好吧，我同意。"

translate chinese chinese_1484464_1302:
    old "You know I'll help you no matter what, right?"
    new "你知道无论发生什么我都会帮你，对吧？"

translate chinese chinese_5928512_1303:
    old "Whatever you choose to do, I'm here for you."
    new "不管你选择做什么，我都会在这里支持你。"

translate chinese chinese_5505719_1304:
    old "I know that thanks."
    new "我知道这个谢谢了。"

translate chinese chinese_0705096_1305:
    old "Hey, what do you say we skip classes for today?"
    new "嘿，要不今天逃课吧？"

translate chinese chinese_5315840_1306:
    old "Come on, let's go to the mall and have some ice cream."
    new "走吧，去商场吃点冰淇淋。"

translate chinese chinese_8969694_1307:
    old "Haha, alright let's do it."
    new "哈哈，好吧，咱们就来吧。"

translate chinese chinese_3648302_1308:
    old "Dude! I'm so angry!"
    new "喂！我超级生气的！"

translate chinese chinese_7064619_1309:
    old "H- huh? W- what's up?"
    new "哈？怎么了？"

translate chinese chinese_6795426_1310:
    old "{i}'What's up?'{/i} Are you serious?"
    new "{i}“最近怎么样？”{/i} 你是认真的吗？"

translate chinese chinese_7788245_1311:
    old "Olivia's pregnant man!"
    new "奥莉via怀孕了！"

translate chinese chinese_9935614_1312:
    old "Y- yeah, s- she is, so?"
    new "嗯，她是啊，那又怎样？"

translate chinese chinese_6978031_1313:
    old "So? Don't you see what's wrong with that?"
    new "所以呢？你看不出那有问题吗？"

translate chinese chinese_0150060_1314:
    old "I can't believe this treason!"
    new "真不敢相信这是背叛！"

translate chinese chinese_4886425_1315:
    old "H- hey man, c- calm down..."
    new "嘿，兄弟，冷静点..."

translate chinese chinese_5963619_1316:
    old "What do you mean calm down? Would you be able to if you were in my shoes?"
    new "什么叫冷静下来？如果你是我，你能冷静吗？"

translate chinese chinese_2169806_1317:
    old "I know man, this doesn't look good."
    new "我知道，这看起来不对劲。"

translate chinese chinese_3757848_1318:
    old "B- but I can explain, I swear."
    new "我、我可以解释的，我真的。"

translate chinese chinese_8340726_1319:
    old "Explain? You know who the guy is?"
    new "解释一下？你知道那家伙是谁吗？"

translate chinese chinese_1426101_1320:
    old "Uhmm... What?"
    new "嗯……什么？"

translate chinese chinese_7104501_1321:
    old "Yeah, do you know who the guy that got Olivia pregnant is?"
    new "是的，你知道让奥利via怀孕的那个家伙是谁吗？"

translate chinese chinese_9144284_1322:
    old "Oh! S- so you don't know who the father is."
    new "哦！那、那你还不知道孩子的爸爸是谁。"

translate chinese chinese_5544429_1323:
    old "Of course I don't, there are some rumors that it might be some jock in the football team."
    new "当然没有了，有些传言说可能是足球队里的某个家伙。"

translate chinese chinese_6364240_1324:
    old "But nobody knows."
    new "但没人知道。"

translate chinese chinese_4185340_1325:
    old "But since you say you can explain, I imagine you know who it is, don't you?"
    new "但既然你说你能解释，我想你应该知道他是谁吧？"

translate chinese chinese_1135167_1326:
    old "Uh... N- no, I- I don't know who the guy is."
    new "呃……不，我——我不知道那个家伙是谁。"

translate chinese chinese_1693524_1327:
    old "Then what did you mean by that?"
    new "那你那样是什么意思？"

translate chinese chinese_9335771_1328:
    old "Uhmm... I just thought you were going to get into an argument with Olivia or something."
    new "嗯……我只是以为你会和奥利维亚吵架或者什么的。"

translate chinese chinese_2603454_1329:
    old "And I figured I had to stop you."
    new "我就觉得必须得阻止你。"

translate chinese chinese_8657957_1330:
    old "What? Because she's pregnant?"
    new "什么？因为她怀孕了？"

translate chinese chinese_9750037_1331:
    old "No man, not at all."
    new "别闹了，根本不是那样的。"

translate chinese chinese_2342442_1332:
    old "I'm hurt by her betrayal that's for certain!"
    new "我确信我被她的背叛伤到了！"

translate chinese chinese_6695161_1333:
    old "But there's no way that I would ever be angry or fight with my beloved Olivia."
    new "但我绝不会对心爱的奥利维亚生气或吵架。"

translate chinese chinese_4639716_1334:
    old "I love her too much for it."
    new "我太爱她了，不能那样做。"

translate chinese chinese_9520598_1335:
    old "Is that so?"
    new "是吗？"

translate chinese chinese_1661452_1336:
    old "Of course, it doesn't matter what she did to me."
    new "当然，她对我做了什么根本不重要。"

translate chinese chinese_4944997_1337:
    old "But that son of a bitch that got her pregnant, he's a different story."
    new "但是那个让她怀孕的混蛋，那就另说了。"

translate chinese chinese_9946030_1338:
    old "When I catch the guy I swear to god that I'll make him pay for getting with my woman!"
    new "等我抓到那家伙，我发誓一定要让他为勾引我的女人付出代价！"

translate chinese chinese_3887975_1339:
    old "And with how close I was to scoring with her."
    new "而且我差点就成功了。"

translate chinese chinese_8166531_1340:
    old "Yeah, I understand buddy."
    new "嗯，我明白，兄弟。"

translate chinese chinese_7604568_1341:
    old "Must be rough."
    new "肯定很难受。"

translate chinese chinese_0894188_1342:
    old "It's alright dude, nothing I can do about it."
    new "没事兄弟，我也没办法。"

translate chinese chinese_9812751_1343:
    old "But anyway this doesn't mean that I won't be there for her anyway."
    new "不过这并不意味着我不会在她身边支持她。"

translate chinese chinese_0639923_1344:
    old "Think about it dude, if no one knows who the father is it means he's a bum or a deadbeat."
    new "想想吧，伙计，如果没人知道孩子的父亲是谁，那就意味着他是混混或者渣男。"

translate chinese chinese_8096752_1345:
    old "Which means my poor Olivia is having to go at this by herself."
    new "这意味着我可怜的奥利维亚不得不一个人应付这一切。"

translate chinese chinese_5828712_1346:
    old "But she won't have to worry about anything man!"
    new "但她就不用操心任何事了！"

translate chinese chinese_5663390_1347:
    old "I'll step up! I'll answer for everything the kid needs."
    new "我来顶上！孩子需要什么我都负责。"

translate chinese chinese_9485393_1348:
    old "I'll even give him my last name so that they'll know I'm their father."
    new "我甚至会给他我的姓，让他们知道我是他的父亲。"

translate chinese chinese_9024502_1349:
    old "Oh, I mean, that's great man."
    new "哦，我是说，太好了。"

translate chinese chinese_7645496_1350:
    old "But what does Olivia think about your noble intentions? Have you talked to her?"
    new "但是奥利维亚对你的高尚意图怎么看呢？你和她谈过吗？"

translate chinese chinese_8703859_1351:
    old "Hmm, no, not really. I haven't been able to talk to her."
    new "嗯，不太行。我还没能和她说话。"

translate chinese chinese_5064256_1352:
    old "But I will, don't doubt dude!"
    new "但我一定会的，别怀疑！"

translate chinese chinese_0580813_1353:
    old "I'm sure you will bro, I'm sure you will."
    new "我相信你行的，兄弟，我相信你行的。"

translate chinese chinese_2817994_1354:
    old "[pla], Mike, class is about to start, why haven't you taken your seats?"
    new "[pla]，迈克，快上课了，你怎么还没坐好？"

translate chinese chinese_5139652_1355:
    old "Sorry ma'am."
    new "对不起，女士。"

translate chinese chinese_5542357_1356:
    old "This will also be at the end of term exam, so be sure to take good notes."
    new "这也会出现在期末考试中，所以一定要好好记笔记。"

translate chinese chinese_1786496_1357:
    old "Remember to practice the subject at home, the exam is very close, so don't relax too much and forget to study."
    new "记得在家多练习这个科目，考试快到了，不要放松太多忘了学习。"

translate chinese chinese_6805439_1358:
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term exams."
    new "我知道这听起来像是很多工作，但如果你想在期末考试前彻底掌握所有科目，你就必须这样做。"

translate chinese chinese_8434353_1359:
    old "Hmph, that was a surprise."
    new "哼，真没想到。"

translate chinese chinese_7578845_1360:
    old "I thought Mike had figured out it was me who got Olivia pregnant."
    new "我以为迈克已经知道是我让奥利维亚怀孕的。"

translate chinese chinese_4025848_1361:
    old "Thinking about it, now I have two things to keep hidden from him."
    new "想想，现在我有两件事要对他保密了。"

translate chinese chinese_7997143_1362:
    old "Ugh, this is so awkward."
    new "哎，真尴尬。"

translate chinese chinese_5869602_1363:
    old "Hey [pla], did you come to study again?"
    new "嘿[pla]，你是来学习的吗？"

translate chinese chinese_9969075_1364:
    old "Yeah, we've been advancing well lately, I figured we could have another study session."
    new "是啊，最近进展不错，我想我们可以再搞一次学习 session。"

translate chinese chinese_9130743_1365:
    old "Hmm, that's a good idea."
    new "嗯，这个主意不错。"

translate chinese chinese_8395844_1366:
    old "But... To be honest I'm not sure I'm up to it right now."
    new "但是……老实说，我现在不确定自己能不能行。"

translate chinese chinese_6973653_1367:
    old "Are you feeling bad again because of the pregnancy?"
    new "是因为怀孕又不舒服了吗？"

translate chinese chinese_4236750_1368:
    old "No, it's not that."
    new "不，不是那样的。"

translate chinese chinese_5381898_1369:
    old "Or rather, I think it is..."
    new "或者说，我觉得是..."

translate chinese chinese_3512689_1370:
    old "I just don't think I can study right now [pla]."
    new "我现在真的没法学习[pla]。"

translate chinese chinese_6670931_1371:
    old "I see, I understand."
    new "我明白了。"

translate chinese chinese_5883211_1372:
    old "Is there anything I can do to help you?"
    new "有什么我可以帮忙的吗？"

translate chinese chinese_1898748_1373:
    old "Could I get you something for the discomfort you're feeling?"
    new "我能帮你找些什么来缓解不适吗？"

translate chinese chinese_2789241_1374:
    old "I mean, I'm not in pain or anything like that."
    new "我的意思是，我没觉得痛或者什么的。"

translate chinese chinese_8713775_1375:
    old "I'm asking you in case there's anything I could do to help."
    new "我是想问你有没有什么我可以帮忙的。"

translate chinese chinese_5538262_1376:
    old "I don't know [pla]..."
    new "我不知道[pla]..."

translate chinese chinese_2863512_1377:
    old "It's just a little embarrassing, you know?"
    new "就是有点尴尬，你知道的？"

translate chinese chinese_4171491_1378:
    old "Is it? Why? What's happening?"
    new "是吗？为什么？发生什么事了？"

translate chinese chinese_7624323_1379:
    old "{b}*Sigh*{/b} I guess there's no harm in telling you."
    new "{b}*叹气*{/b} 我猜告诉你也没关系。"

translate chinese chinese_7901461_1380:
    old "You know, ever since I got pregnant I've been feeling this kind of..."
    new "你知道吗，自从怀孕后我就一直有种..."

translate chinese chinese_5881973_1381:
    old "Tiredness? Fatigue?"
    new "疲劳？倦怠？"

translate chinese chinese_9383821_1382:
    old "It's hard to explain, but since the pregnancy started that's how I've been feeling."
    new "很难解释，但从怀孕开始我就一直这样感觉。"

translate chinese chinese_7662550_1383:
    old "{i}(That's similar to what Brixxida told me was going to happen.){/i}"
    new "{i}（这和Brixxida告诉我的差不多。）{/i}"

translate chinese chinese_7817570_1384:
    old "{i}(I wonder if it's because her body needs more magic.){/i}"
    new "{i}（不知道是不是因为她身体需要更多的魔法。）{/i}"

translate chinese chinese_7460974_1385:
    old "I went to the doctor and asked if that's a normal thing to happen."
    new "我去医生那里问了，这种情况正常吗？"

translate chinese chinese_0202069_1386:
    old "They said that it's uncommon, but I might be experiencing some sort of chronic fatigue because of the pregnancy."
    new "他们说这种情况不常见，但可能是怀孕导致的慢性疲劳。"

translate chinese chinese_5145925_1387:
    old "But they ran several tests and concluded that I'm in good health."
    new "但是他们做了几次检查，结论是我身体健康。"

translate chinese chinese_6677367_1388:
    old "Alright, and is it that fatigue the reason why you don't feel like studying?"
    new "好吧，那疲劳是你不想学习的原因吗？"

translate chinese chinese_3631733_1389:
    old "Not really..."
    new "不太……"

translate chinese chinese_6607205_1390:
    old "I think it's related, but it's so hard to explain..."
    new "我觉得有关联，但真的很难解释……"

translate chinese chinese_9294832_1391:
    old "I think you can explain it to me. No problem."
    new "我觉得你可以向我解释一下。没问题。"

translate chinese chinese_4663444_1392:
    old "Hmm, you think so?"
    new "嗯，你是这么认为的？"

translate chinese chinese_2602520_1393:
    old "Ok, well..."
    new "好吧，嗯……"

translate chinese chinese_3816840_1394:
    old "The thing that has me feeling bad is this weird..."
    new "让我感觉不好的是这个奇怪的..."

translate chinese chinese_7270328_1395:
    old "H- horniness that I've been feeling ever since I got pregnant."
    new "自从怀孕以来我一直感到的 horny。"

translate chinese chinese_2453894_1396:
    old "O- oh! I- I see..."
    new "哦！我……我明白了……"

translate chinese chinese_0875598_1397:
    old "Y- yeah... And it's a very weird type of being horny."
    new "嗯……而且这是一种非常奇怪的兴奋感。"

translate chinese chinese_0211716_1398:
    old "At first I thought it was just because of the hormones."
    new "一开始我以为只是因为荷尔蒙的原因。"

translate chinese chinese_1834458_1399:
    old "But as that fatigue that I told you about has kept growing, so has this weird feeling of horniness."
    new "但是正如我告诉你的那样，疲劳感越来越重，这种奇怪的欲念也越来越强烈。"

translate chinese chinese_3096102_1400:
    old "And lately sex is the only thing that I've been able to think about, you know?"
    new "最近除了性我什么都想不起来，你知道吗？"

translate chinese chinese_0619568_1401:
    old "I think I understand."
    new "我觉得我明白了。"

translate chinese chinese_0983485_1402:
    old "But if that's the case, why didn't you tell me about it before?"
    new "但如果是这样的话，你之前为什么没有告诉我？"

translate chinese chinese_9954492_1403:
    old "I mean... It's not as if we don't know each other."
    new "我的意思是……我们也不是不认识。"

translate chinese chinese_1759524_1404:
    old "I could've helped you with it."
    new "我本可以帮你解决的。"

translate chinese chinese_0342061_1405:
    old "I don't know [pla], you've already done so much for me."
    new "我不知道[pla]，你已经为我做了这么多。"

translate chinese chinese_6015662_1406:
    old "And it's not as if we're a couple, this whole pregnancy thing is just you helping me with a problem that I have."
    new "而且我们又不是情侣，这怀孕的事只是你帮我解决一个问题而已。"

translate chinese chinese_6540074_1407:
    old "I wouldn't even know how to bring up the subject."
    new "我甚至不知道该怎么提起这个话题。"

translate chinese chinese_4514824_1408:
    old "Hey, I get that, but come on, if it's something that you need, I'll be more than happy to help you."
    new "嘿，我理解你的想法，但如果你需要帮助的话，我很乐意帮忙。"

translate chinese chinese_7392999_1409:
    old "So... i- if you think you could use my help, maybe I can do something for you."
    new "所以……如果你觉得需要我的帮助，也许我可以做些什么。"

translate chinese chinese_7923922_1410:
    old "Ok, m- maybe we can give it a go then..."
    new "好吧，或许我们可以试试..."

translate chinese chinese_2355484_1411:
    old "Ngnh! Oh god! This is amazing!"
    new "嗯嗯！哦天啊！这太棒了！"

translate chinese chinese_1803609_1412:
    old "This big dick is just so great!"
    new "这个大棒真棒！"

translate chinese chinese_3639020_1413:
    old "Oh [pla]! I can't believe how good it feels!"
    new "哦 [pla]！感觉太棒了！"

translate chinese chinese_5340177_1414:
    old "Oh God [pla]! That feels so much better!"
    new "哦上帝 [pla]！这感觉好太多了！"

translate chinese chinese_4640122_1415:
    old "I don't know why, but it's as if that tiredness had just left my body all of a sudden."
    new "不知道为什么，突然感觉那种疲倦一下子从身体消失了。"

translate chinese chinese_0789551_1416:
    old "If I had known before that it was going to be that way, I would've told you about this sooner."
    new "如果早知道会这样，我就会早点告诉你了。"

translate chinese chinese_0430189_1417:
    old "I'm very happy that you feel better."
    new "我很高兴你觉得好多了。"

translate chinese chinese_5462638_1418:
    old "That was the whole point, it's good that this worked."
    new "这才是重点，这样就好。"

translate chinese chinese_4821058_1419:
    old "You're the best, [pla]. Thank you so much."
    new "你是最好的，[pla]。真的非常感谢。"

translate chinese chinese_7169458_1420:
    old "I don't think we'll be able to get to study right now."
    new "我觉得我们现在没法学习了。"

translate chinese chinese_7849376_1421:
    old "But I think we can do it later."
    new "但是我觉得我们可以稍后再做。"

translate chinese chinese_6504484_1422:
    old "For now, thank you so much for the help [pla]."
    new "暂时先谢谢你了，[pla]。"

translate chinese chinese_1901012_1423:
    old "My pleasure, after all, we're in this together."
    new "我的荣幸，反正我们是一起的。"

translate chinese chinese_2226691_1424:
    old "I guess I'll get going to my house and I'll see you later, alright?"
    new "那我先回去了，待会儿见，好吗？"

translate chinese chinese_9092253_1425:
    old "Oh! Hey Olivia, how are you?"
    new "哦！奥利维亚，你好吗？"

translate chinese chinese_1340276_1426:
    old "Hey [pla], well you know..."
    new "嘿[pla]，你知道的..."

translate chinese chinese_9365722_1427:
    old "What? Did something happen?"
    new "什么？发生什么事了？"

translate chinese chinese_3752834_1428:
    old "I mean, my family's still a little annoying."
    new "我的意思是，我家人还是有点烦人。"

translate chinese chinese_1802974_1429:
    old "It's been a little hard, you know, all this with my dad and mom..."
    new "你知道的，最近因为爸爸和妈妈的事，有点难熬..."

translate chinese chinese_0907191_1430:
    old "And with my body getting fatter and fatter..."
    new "而且我的身体越来越胖……"

translate chinese chinese_0218310_1431:
    old "You know... This makes me feel kinda guilty."
    new "你知道吗……这让我有点内疚。"

translate chinese chinese_8501722_1432:
    old "Well... I mean, it is kinda my fault that you're in this situation."
    new "嗯……我的意思是，你落到这种地步，我也有责任。"

translate chinese chinese_8765235_1433:
    old "And I don't only mean the pregnancy."
    new "而且我不仅仅是指怀孕这件事。"

translate chinese chinese_0909489_1434:
    old "But also what's happening with your family."
    new "还有你的家庭情况。"

translate chinese chinese_9400585_1435:
    old "I can't avoid thinking that this is my responsibility."
    new "我无法不去想这可能是我的责任。"

translate chinese chinese_1468864_1436:
    old "I understand why you would feel that way."
    new "我明白你为什么会这么觉得。"

translate chinese chinese_9775424_1437:
    old "I get what you're saying [pla]."
    new "我明白你的意思[pla]。"

translate chinese chinese_1311143_1438:
    old "But I don't think you should feel any guilt for it."
    new "但是我觉得你不必为此感到内疚。"

translate chinese chinese_4706372_1439:
    old "After all, I was the one that came up with this idea."
    new "毕竟，这个主意是我提出来的。"

translate chinese chinese_9389314_1440:
    old "Not to mention I'm the one who dragged you into this whole situation."
    new "更别提是我把你拖进这个局面的。"

translate chinese chinese_7187533_1441:
    old "Well, yeah, but still, you're the one bearing all the weight of this whole thing."
    new "嗯，是啊，但你还是得承担这一切的重担。"

translate chinese chinese_9647456_1442:
    old "Both figuratively and literally."
    new "比喻上和实际上都是。"

translate chinese chinese_6363277_1443:
    old "Yeah, but is something that was needed."
    new "是的，但那是必要的。"

translate chinese chinese_5303510_1444:
    old "So don't beat yourself up too much for putting me in this state."
    new "所以别太自责把我弄成这样。"

translate chinese chinese_5854113_1445:
    old "Besides, it's not as if we didn't both enjoy it, right?"
    new "再说，我们两个也都享受了，不是吗？"

translate chinese chinese_3211861_1446:
    old "Well, yeah, we did."
    new "嗯，是的，我们确实做了。"

translate chinese chinese_3871149_1447:
    old "There you go. So don't beat yourself up over it. There's no problem."
    new "就是这样。所以别自责了，没什么问题的。"

translate chinese chinese_3806556_1448:
    old "I guess so."
    new "我想是这样吧。"

translate chinese chinese_4868208_1449:
    old "But still, I'd like it if you could feel a little bit more comfortable."
    new "不过我还是希望你能再放松一点。"

translate chinese chinese_5414663_1450:
    old "Oh, I think there's something that you could do to help me with that."
    new "哦，我觉得你能做点什么来帮我。"

translate chinese chinese_6787737_1451:
    old "Come on, don't think too much about me being uncomfortable."
    new "别想那么多，不用顾忌我是不是不舒服。"

translate chinese chinese_1899568_1452:
    old "Now, let's go to my house."
    new "好了，现在去我家吧。"

translate chinese chinese_8516886_1453:
    old "The entrance exams are coming, so I want to study a little more."
    new "入学考试快来了，我想再努力学习一下。"

translate chinese chinese_3756969_1454:
    old "W- w- what was that?! W- what did I just hear?!"
    new "哇哇那是什么？！我刚才听到了什么？！"

translate chinese chinese_3607046_1455:
    old "[pla]?! H- he got my girl pregnant?!"
    new "[pla]?! 他把我女朋友搞怀孕了?!"

translate chinese chinese_1788501_1456:
    old "N- no way! I- it can't be..."
    new "N- 不可能！这不可能是..."

translate chinese chinese_6597250_1457:
    old "No! H- he wouldn't do that!"
    new "不！他不会那样的！"

translate chinese chinese_0134720_1458:
    old "With my girl?! What the hell?!"
    new "和我的女孩？！你在说什么鬼？！"

translate chinese chinese_9167446_1459:
    old "Oh! Brixxida, hi."
    new "哦！布里克西达，你好。"

translate chinese chinese_8631944_1460:
    old "Hey, good morning."
    new "嘿，早上好。"

translate chinese chinese_0941780_1461:
    old "What are you doing here in my room so early?"
    new "你这么早跑到我房间里来干什么？"

translate chinese chinese_6269798_1462:
    old "Well, I was about to wake you up actually.."
    new "其实我正准备叫醒你呢.."

translate chinese chinese_7497057_1463:
    old "Oh! How come?"
    new "哦！为什么？"

translate chinese chinese_2068808_1464:
    old "Well, how long has it been since you implanted the magic in that girl?"
    new "好吧，自从你把魔法植入那个女孩体内以来，已经过去多久了？"

translate chinese chinese_5543841_1465:
    old "And you haven't given me any update on how things are going with her."
    new "而且你还没给我任何关于她情况的更新。"

translate chinese chinese_1125642_1466:
    old "Uh, well, there haven't been any new updates."
    new "嗯，好吧，没什么新更新。"

translate chinese chinese_3362032_1467:
    old "The only thing that's happened is what you told me."
    new "唯一发生的就是你告诉我的那些。"

translate chinese chinese_5068732_1468:
    old "She's been feeling a little tired, so she asked me to have sex with her."
    new "她最近有点累，所以让我和她做爱。"

translate chinese chinese_3378587_1469:
    old "And that's it? How's her pregnancy going?"
    new "就这些？她的怀孕情况怎么样？"

translate chinese chinese_2391339_1470:
    old "How's it going?"
    new "怎么样了？"

translate chinese chinese_6039128_1471:
    old "Uhmm, it's very advanced, I would say."
    new "嗯，我敢说这非常先进。"

translate chinese chinese_9470799_1472:
    old "Just as you told me, her belly grew so quickly."
    new "就像你告诉我的那样，她的肚子涨得很快。"

translate chinese chinese_9079034_1473:
    old "You would think she's going to give birth any time now."
    new "你看看她，好像随时都要生了。"

translate chinese chinese_0939646_1474:
    old "That's exactly what I mean you dimwit!!"
    new "那正是我的意思你这家伙！！"

translate chinese chinese_7705768_1475:
    old "W- why are you angry?"
    new "你为什么生气？"

translate chinese chinese_1820485_1476:
    old "Why do you think?"
    new "你猜为什么？"

translate chinese chinese_0343743_1477:
    old "I told you [pla]! This isn't a normal human pregnancy!"
    new "我跟你说过[pla]！这可不是普通的怀孕！"

translate chinese chinese_1659148_1478:
    old "Any moment now she could give birth! And we haven't made the closing ritual for the spell!"
    new "随时都可能生了！而且我们还没完成那个咒语的收尾仪式！"

translate chinese chinese_8001850_1479:
    old "What are you talking about? Closing ritual?"
    new "你在说什么？闭幕仪式？"

translate chinese chinese_5443160_1480:
    old "Yes [pla]! A closing ritual."
    new "是的 [pla]！一个结束仪式。"

translate chinese chinese_1200451_1481:
    old "In the same way that I had to be there for the implantation of the magic."
    new "就像我必须在现场进行魔法植入一样。"

translate chinese chinese_3132161_1482:
    old "E- extraction? What are you talking about?"
    new "E-提取？你在说什么？"

translate chinese chinese_0022736_1483:
    old "You never told me about any kind of extraction!"
    new "你从来没告诉我有任何提取的事！"

translate chinese chinese_5766365_1484:
    old "Where was all of this with Barbie?"
    new "这些和芭比之间发生过吗？"

translate chinese chinese_6658077_1485:
    old "Well, for your information, we were never even close to finishing anything with Barbie because you decided to interrupt the spell!"
    new "好吧，告诉你，我们根本就没接近完成任何事，因为你决定打断那个咒语！"

translate chinese chinese_6058520_1486:
    old "Besides, I decided to modify the spell after your stupid tantrum last time with Barbie."
    new "再说，上次你因为芭比发脾气后，我决定修改那个咒语了。"

translate chinese chinese_4974700_1487:
    old "Uh, o- ok? But I don't get it, why?"
    new "呃，好……好吧？但是我不明白，为什么？"

translate chinese chinese_0848709_1488:
    old "As I told you, after what happened last time with Barbie, I gave it a thought and decided the best thing to do was modify the spell."
    new "就像我告诉你的，上次和芭比发生那事后，我仔细想了想，觉得最好的办法是修改这个咒语。"

translate chinese chinese_0050875_1489:
    old "This is because last time we ended up losing a lot of magic power."
    new "这是因为上次我们损失了很多魔法力量。"

translate chinese chinese_4579350_1490:
    old "You see, the way it should work is that the condensation spell is over at the same time that the pregnancy is."
    new "你看，本来应该是这样的：凝结咒和怀孕同时结束。"

translate chinese chinese_5648894_1491:
    old "But I realized that this approach only works if we let things come to term naturally."
    new "但我意识到这种方法只有让我们顺其自然才能行得通。"

translate chinese chinese_6371639_1492:
    old "But if it's something like what happened with Barbie were to happen again."
    new "但如果再发生像芭比那次那样的事情。"

translate chinese chinese_1988539_1493:
    old "We would end up losing all of the already cultivated magic power."
    new "我们会失去所有已经培养出来的魔力。"

translate chinese chinese_1455458_1494:
    old "But how did you solve it then?"
    new "那你是怎么解决的呢？"

translate chinese chinese_0672076_1495:
    old "I did it by making a change to the way the spell works."
    new "我是通过改变咒语的工作方式做到的。"

translate chinese chinese_6976192_1496:
    old "Instead of letting it end by itself, we're directly extracting the magic power from the girl."
    new "我们不是让它自行结束，而是直接从女孩身上抽取魔力。"

translate chinese chinese_4276594_1497:
    old "This way it affords me a lot more control over the magic, and the moment it's extracted."
    new "这样我可以对魔法有更多控制，也能在提取的瞬间掌握它。"

translate chinese chinese_8060592_1498:
    old "So, even if something similar to what happened last time with Barbie were to happen again."
    new "所以，即使再次发生类似上次芭比的事情。"

translate chinese chinese_9800167_1499:
    old "We could simply cancel the cultivation process and we wouldn't lose anything."
    new "我们可以直接取消修炼过程，什么也不会失去。"

translate chinese chinese_9637542_1500:
    old "That's awesome Brixxida! And it's very reassuring!"
    new "太棒了，布里克西达！这让人很安心！"

translate chinese chinese_5735212_1501:
    old "Yeah, it's very good."
    new "是的，非常好。"

translate chinese chinese_1399001_1502:
    old "But there's a condition to the spell in this new form: there HAS to be an extraction."
    new "但是这个新形式的咒语有一个条件：必须要有提取。"

translate chinese chinese_2849336_1503:
    old "There's no point if we don't do it and the pregnancy just ends without us doing the extraction! We will lose all the magic!!"
    new "如果我们不做，怀孕就这样结束了，没有做提取的话，我们就什么魔法都得不到！我们会失去所有的魔法的！！"

translate chinese chinese_8981203_1504:
    old "I- I'm sorry Brixxida, I didn't know."
    new "我……对不起，布里克西达，我不知道。"

translate chinese chinese_9019376_1505:
    old "Hmph, as long as you understand."
    new "哼，反正你明白就好。"

translate chinese chinese_8266307_1506:
    old "But then you have to remember, sooner rather than later, we need to extract the magic power from her."
    new "但是你得记住，早晚会需要从她身上提取魔力的。"

translate chinese chinese_9211770_1507:
    old "Otherwise, she'll have a human with a magic supercharge."
    new "否则，她就会有一个魔力强化的人类。"

translate chinese chinese_6851878_1508:
    old "And honestly, I don't know what that means in the long term."
    new "老实说，我也不知道这长期意味着什么。"

translate chinese chinese_8309559_1509:
    old "By the way, [pla], there's something else you should know."
    new "对了，[pla]，还有一件事你应该知道。"

translate chinese chinese_4738198_1510:
    old "Before we do the magic extraction, she has to decide if she wants to be a mother or not."
    new "在进行魔法提取之前，她得决定是否要做母亲。"

translate chinese chinese_4102222_1511:
    old "This is because when we extract the magic power, I need to know if I'll take it all or just a small part."
    new "这是因为当我们抽取魔力时，我需要知道我是要全部吸取还是只取一小部分。"

translate chinese chinese_8739647_1512:
    old "What happens either way?"
    new "不管怎样都会发生什么呢？"

translate chinese chinese_8735163_1513:
    old "Well, if she decides not to go through with the whole process, I'll extract all the magic power from her."
    new "好吧，如果她决定不完成整个过程，我会把她所有的魔力都抽取出来。"

translate chinese chinese_9253462_1514:
    old "And her pregnancy will be reversed."
    new "而且她的怀孕状态会被逆转。"

translate chinese chinese_1345754_1515:
    old "So in the end, it'll be like she was never pregnant."
    new "这样一来，就好像是她从来没有怀孕过一样。"

translate chinese chinese_7617724_1516:
    old "On the other hand, if she decides to go through the whole process."
    new "另一方面，如果她决定走完整个过程。"

translate chinese chinese_9767680_1517:
    old "I'll take most of it, but I'll leave a small amount of power, so a life will be created."
    new "我会拿走大部分，但会留下一小部分力量，这样就会有生命产生。"

translate chinese chinese_1095333_1518:
    old "I see... So that's how it is."
    new "我明白了……原来是这样。"

translate chinese chinese_2215973_1519:
    old "Alright, I'll be sure to talk to her about it."
    new "好的，我一定会跟她谈谈这个事。"

translate chinese chinese_2028177_1520:
    old "Good, make sure you do that."
    new "好的，确保你那样做。"

translate chinese chinese_7883936_1521:
    old "Yeah, I'll do it and let you know."
    new "好的，我会去做然后告诉你。"

translate chinese chinese_8486494_1522:
    old "Alright! That's it!"
    new "好！够了！"

translate chinese chinese_5907817_1523:
    old "I think that's all the subjects we needed to study for the entrance exam."
    new "我觉得这就是我们需要为入学考试复习的所有科目了。"

translate chinese chinese_6487888_1524:
    old "I think with that, you should ace the exam!"
    new "我觉得这样你应该能考满分了！"

translate chinese chinese_6963775_1525:
    old "Oh my god! Thank you so much, [pla]!"
    new "哦我的天！谢谢你啦，[pla]！"

translate chinese chinese_3586692_1526:
    old "At first, I couldn't believe we would ever manage to cover everything."
    new "一开始，我真不敢相信我们能搞定所有的事情。"

translate chinese chinese_3131193_1527:
    old "But we did it!"
    new "但我们做到了！"

translate chinese chinese_1400427_1528:
    old "I can't believe it, this is the best thing ever, [pla]!"
    new "真不敢相信，这是有史以来最好的东西，[pla]！"

translate chinese chinese_0025255_1529:
    old "Yeah, for a moment there, I also thought we wouldn't have time to cover everything."
    new "是啊，有一瞬间我也以为我们没有时间把所有事情都说完。"

translate chinese chinese_7287506_1530:
    old "But you've been so disciplined, Olivia. It's amazing how much effort you've put in such a short time."
    new "但是你一直这么自律，奥利维亚。这么短的时间内你付出这么多努力，真是令人惊讶。"

translate chinese chinese_1861520_1531:
    old "This is definitely all because of your hard work."
    new "这肯定是你的努力的结果。"

translate chinese chinese_8336212_1532:
    old "Still, you've been an amazing teacher, [pla]."
    new "不过，你真是个了不起的老师，[pla]。"

translate chinese chinese_8799595_1533:
    old "Thinking about it, we had a very rocky start."
    new "想想看，我们的开始真是磕磕绊绊的。"

translate chinese chinese_8353809_1534:
    old "With me blackmailing you with what I saw you do at Mike's house."
    new "我用在迈克家看到你做的事来威胁你。"

translate chinese chinese_9237749_1535:
    old "I'm sorry about that, by the way."
    new "对了，为此我道歉。"

translate chinese chinese_3178921_1536:
    old "I mean, it's alright, given the situation you were in."
    new "我的意思是，考虑到你当时的情况，这也算正常。"

translate chinese chinese_1212965_1537:
    old "I'm not saying it's okay, but I understand you were in a desperate position."
    new "我不是说这样是对的，但我能理解你当时很绝望。"

translate chinese chinese_2057681_1538:
    old "But it's alright."
    new "但是没关系。"

translate chinese chinese_2320754_1539:
    old "Thank you for your understanding."
    new "感谢你的理解。"

translate chinese chinese_6113803_1540:
    old "And for being so helpful."
    new "而且你帮了这么大的忙。"

translate chinese chinese_9593695_1541:
    old "I came up with such a crazy idea, and you decided to help me with it."
    new "我有个疯狂的想法，而你决定帮我实现它。"

translate chinese chinese_0223668_1542:
    old "And on top of that, you even took time to explain all these topics to me."
    new "而且你还花时间给我解释了这些话题。"

translate chinese chinese_5710499_1543:
    old "I don't know how to show my gratitude."
    new "我不知道该怎么表达我的感激之情。"

translate chinese chinese_3352122_1544:
    old "But I can think of a couple of ways."
    new "但我能想到几种方法。"

translate chinese chinese_4938307_1545:
    old "You know, I've been feeling a little tired lately."
    new "你知道吗，我最近总觉得有点累。"

translate chinese chinese_1990975_1546:
    old "Y- you are?"
    new "你……是吗？"

translate chinese chinese_6091018_1547:
    old "Yeah, I'm not feeling my best lately."
    new "是啊，我最近状态不太好。"

translate chinese chinese_9726554_1548:
    old "I was thinking maybe you could help me a bit with that."
    new "我在想你也许能在这方面帮我一点。"

translate chinese chinese_8598427_1549:
    old "And at the same time, maybe I can show my thanks for everything you've done for me."
    new "同时，也许我可以表达一下对你为我所做一切的感激之情。"

translate chinese chinese_0747094_1550:
    old "Uh, y- yeah sure, I don't see why not."
    new "呃，好啊，我不觉得有什么问题。"

translate chinese chinese_9241211_1551:
    old "Great! Give me a second to go to the bathroom, and I'll be right back."
    new "太好了！让我去趟厕所，马上回来。"

translate chinese chinese_8692127_1552:
    old "Don't worry, you won't have to wait long."
    new "别担心，你不用等太久的。"

translate chinese chinese_2173599_1553:
    old "Oh right! By the way."
    new "哦对了！顺便说一下。"

translate chinese chinese_4123890_1554:
    old "I wanted to ask you something."
    new "我有件事想问你。"

translate chinese chinese_0750158_1555:
    old "Maybe this isn't what you expect right now."
    new "也许这并不是你现在期望的。"

translate chinese chinese_3524687_1556:
    old "But I was thinking we still haven't talked about your decision regarding your pregnancy."
    new "但是我在想，我们还没谈到你关于怀孕的决定呢。"

translate chinese chinese_2043651_1557:
    old "D- don't get me wrong, I'm not trying to convince you of anything."
    new "别误会，我可没打算说服你什么。"

translate chinese chinese_8084332_1558:
    old "I just want to know where you stand on it, you know?"
    new "我只是想知道你对这件事的看法，你知道的？"

translate chinese chinese_9932132_1559:
    old "Just because I worry about you."
    new "因为我担心你。"

translate chinese chinese_1926129_1560:
    old "Well... I have to say I originally thought about waiting for the entrance exam results."
    new "嗯……我得说，我本来打算等入学考试结果出来的。"

translate chinese chinese_7135642_1561:
    old "You know, because I wanted to know if I got into college."
    new "你知道的，因为我想知道我是否被大学录取了。"

translate chinese chinese_0303652_1562:
    old "But I thought about it and understood what I want."
    new "但我想了想，明白了自己想要什么。"

translate chinese chinese_1472583_1563:
    old "Extract the whole magic power."
    new "抽取全部魔力。"

translate chinese chinese_9334820_1564:
    old "I've decided that I don't want to be a mother."
    new "我决定我不想要当妈妈。"

translate chinese chinese_0951222_1565:
    old "I- it's just that it wasn't my original plan, you know?"
    new "我——我只是没想到这本来不是我的计划，你知道吗？"

translate chinese chinese_1195799_1566:
    old "When I got myself into this situation, it was only to get my parents off my back."
    new "我陷入这种境地只是为了摆脱父母的唠叨。"

translate chinese chinese_0923577_1567:
    old "But I have to say, I've never considered being a mother so young."
    new "但不得不说，我从没想过会这么年轻就当妈妈。"

translate chinese chinese_6767077_1568:
    old "There are still so many things I want to do, and being a mother would get in the way of all that."
    new "我还想做很多事，当妈妈会妨碍这一切的。"

translate chinese chinese_9273489_1569:
    old "Besides, I would be dragging you into this situation too."
    new "再说，我也会把你拖进这种局面的。"

translate chinese chinese_1175539_1570:
    old "You've done a lot for me, [pla], but I can't ask any more from you."
    new "你为我做了很多，[pla]，但我不能再向你要求更多了。"

translate chinese chinese_4174572_1571:
    old "So I think it's better if I just leave things as they are."
    new "所以我觉得还是保持现状比较好。"

translate chinese chinese_9624690_1572:
    old "You know? I completely understand what you mean."
    new "你知道吗？我完全明白你的意思。"

translate chinese chinese_0012391_1573:
    old "I'm happy you're thinking about your future."
    new "我很高兴你在考虑未来。"

translate chinese chinese_7633130_1574:
    old "And hey, thanks for trusting me."
    new "还有，谢谢你信任我。"

translate chinese chinese_5563394_1575:
    old "I'm glad you've been my partner through this whole process, [pla]. Thank you so much."
    new "很高兴你能全程陪我度过，[pla]。真的非常感谢你。"

translate chinese chinese_6529210_1576:
    old "Extract most of the magic power but leave a small part."
    new "抽取大部分魔力，但留下一小部分。"

translate chinese chinese_3722847_1577:
    old "Well, I don't know how to tell you this."
    new "嗯，我不知道该怎么告诉你这个。"

translate chinese chinese_1320097_1578:
    old "But I decided that I want to be a mother."
    new "但我决定我要当妈妈。"

translate chinese chinese_2675039_1579:
    old "I- I don't mean that I want to make you a father or anything, [pla]!"
    new "我——我不是说想要让你当爸爸什么的，[pla]！"

translate chinese chinese_9388440_1580:
    old "It's just that I've been thinking, and I think I want to give it a go."
    new "就是我一直都在想，我觉得我想试一试。"

translate chinese chinese_8100583_1581:
    old "Ever since this happened, I've been feeling better and better about the possibility of being a mother."
    new "自从这件事发生以来，我越来越觉得当妈妈的可能性也不错。"

translate chinese chinese_5879468_1582:
    old "And you decided that you want to do it?"
    new "那你决定要做这件事了？"

translate chinese chinese_8682825_1583:
    old "Well, yeah."
    new "嗯，是啊。"

translate chinese chinese_5298560_1584:
    old "I've been thinking about it and I think it's possible."
    new "我考虑过了，我觉得这是有可能的。"

translate chinese chinese_8391833_1585:
    old "Lately, my father has come around to the idea of me being a mom."
    new "最近，我爸爸开始接受我当妈妈这件事了。"

translate chinese chinese_3497235_1586:
    old "And my mom's pretty excited about it too."
    new "我妈妈也挺兴奋的。"

translate chinese chinese_0629092_1587:
    old "So I figured I could try it."
    new "所以我想试试看。"

translate chinese chinese_7881269_1588:
    old "B- but I'm not trying to make you a father!"
    new "我、我不是想让你当爸爸啊！"

translate chinese chinese_2257923_1589:
    old "I don't expect you to get involved or anything."
    new "我可没指望你会插手什么的。"

translate chinese chinese_9945327_1590:
    old "It's just what I want to do, [pla]."
    new "这正是我想做的，[pla]。"

translate chinese chinese_3500007_1591:
    old "It's alright, I understand. And I would never try to convince you otherwise."
    new "没关系，我理解。而且我绝不会试图改变你的想法。"

translate chinese chinese_6923394_1592:
    old "I just wanted to know what your plans were."
    new "我只是想知道你的计划是什么。"

translate chinese chinese_2579696_1593:
    old "And I'm happy you're in a position where you can decide this."
    new "而且我很高兴你能处于能做这个决定的位置。"

translate chinese chinese_6172037_1594:
    old "I'll help you in any way you need me to."
    new "我会以任何你需要的方式帮助你。"

translate chinese chinese_3642529_1595:
    old "Thanks for all your support, [pla]!"
    new "感谢你的全力支持，[pla]！"

translate chinese chinese_9493028_1596:
    old "Listen, I have to go to the bathroom."
    new "听着，我得去厕所。"

translate chinese chinese_3165522_1597:
    old "But when I come back, I want to see you ready."
    new "但是等我回来的时候，我希望你已经准备好了。"

translate chinese chinese_4089097_1598:
    old "Ok, I should take this chance to bring Brixxida here!"
    new "好的，我应该趁这个机会把Brixxida带过来！"

translate chinese chinese_1730470_1599:
    old "What do you need?"
    new "你需要什么？"

translate chinese chinese_6001347_1600:
    old "That really surprised me."
    new "那真的让我很惊讶。"

translate chinese chinese_6509197_1601:
    old "Well, I think now's the perfect time for you to end the spell."
    new "好吧，我觉得现在是你解除咒语的完美时机。"

translate chinese chinese_7529030_1602:
    old "That's just perfect. Well done calling me here, [pla]!"
    new "这真是完美。叫我和你来这里真好，[pla]！"

translate chinese chinese_2071210_1603:
    old "Alright, let's do this."
    new "好吧，咱们开始吧。"

translate chinese chinese_6023511_1604:
    old "Come on, I want you to fuck me right now."
    new "快来，我现在就想让你肏我。"

translate chinese chinese_4904773_1605:
    old "S- sure, right away!"
    new "好、好的，马上！"

translate chinese chinese_6121075_1606:
    old "Oh God yes! That's just what I've been missing, [pla]!"
    new "哦天啊是的！这正是我缺少的，[pla]！"

translate chinese chinese_7659551_1607:
    old "Oh yeah, [pla]! That's just what I wanted!"
    new "哦对，[pla]！这正是我想要的！"

translate chinese chinese_5523376_1608:
    old "This feels so amazing!"
    new "这感觉太棒了！"

translate chinese chinese_6887523_1609:
    old "That was sooo good, [pla]!"
    new "那真是太好了，[pla]！"

translate chinese chinese_0113774_1610:
    old "Just like always, that dick of yours never disappoints."
    new "就像always一样，你的那玩意从不让人失望。"

translate chinese chinese_0175417_1611:
    old "I'm glad you liked it."
    new "很高兴你喜欢。"

translate chinese chinese_6438725_1612:
    old "Well, mostly, yeah."
    new "嗯，基本上是这样的。"

translate chinese chinese_1240489_1613:
    old "But you know? I still feel a little bit tired."
    new "但是你知道吗？我 still 感觉有点累。"

translate chinese chinese_2665589_1614:
    old "And I feel like I haven't thanked you enough for everything."
    new "我觉得我还没有足够感谢你所做的一切。"

translate chinese chinese_9951514_1615:
    old "So I have another thing for you. Come here."
    new "我还有件事要给你。过来。"

translate chinese chinese_1739882_1616:
    old "Slrrp! Oh yeah!"
    new "slurp! 哦耶！"

translate chinese chinese_9165777_1617:
    old "Hmm! I wanted to taste this dick again!"
    new "哼！我还想再尝尝这个家伙呢！"

translate chinese chinese_2439055_1618:
    old "Just relax and enjoy it [pla]!"
    new "just放松享受吧[pla]！"

translate chinese chinese_1950527_1619:
    old "Alright! I think that does it!"
    new "好了！我觉得这就搞定了！"

translate chinese chinese_1776709_1620:
    old "I hope you liked my way of saying thanks to you, [pla]!"
    new "希望你喜欢我向[pla]表达感谢的方式！"

translate chinese chinese_0295476_1621:
    old "Yeah, I think it was great!"
    new "是的，我觉得太棒了！"

translate chinese chinese_5047974_1622:
    old "I'm glad. Thanks again for everything, [pla]."
    new "我很高兴。再次感谢你做的一切，[pla]。"

translate chinese chinese_9101528_1623:
    old "I'm sure I'm going to do great on those exams."
    new "我相信我一定能考得很好。"

translate chinese chinese_4214439_1624:
    old "I'm completely sure of it."
    new "我完全确定。"

translate chinese chinese_5262310_1625:
    old "You've worked very hard to get a good result."
    new "你很努力才得到这样的结果。"

translate chinese chinese_9812963_1626:
    old "There's no doubt that you'll ace it."
    new "你肯定能搞定的。"

translate chinese chinese_9201925_1627:
    old "Thanks, [pla]. Your support means everything to me."
    new "谢谢，[pla]。你的支持对我来说意味着一切。"

translate chinese chinese_7439541_1628:
    old "Hey, I think I should be going home, right?"
    new "嘿，我觉得我该回家了吧？"

translate chinese chinese_5020894_1629:
    old "So you'll have time to rest properly."
    new "这样你就能好好休息了。"

translate chinese chinese_1033751_1630:
    old "Sure, thanks again, [pla]."
    new "好的，再次感谢你，[pla]。"

translate chinese chinese_8606427_1631:
    old "You're welcome, Olivia."
    new "不客气，奥利维亚。"

translate chinese chinese_7659061_1632:
    old "Okay, I think that settles everything with the spell, right?"
    new "好了，我觉得这样咒语的事情就都搞定了吧？"

translate chinese chinese_9461957_1633:
    old "That's right. Now that we stopped the spell, she'll return to normal soon."
    new "没错。现在我们阻止了那个咒语，她很快就会恢复正常。"

translate chinese chinese_8405013_1634:
    old "And don't worry about her health; she'll be completely fine."
    new "而且不用担心她的健康，她会完全没事的。"

translate chinese chinese_0118062_1635:
    old "So it should be all good."
    new "所以应该没问题。"

translate chinese chinese_2335636_1636:
    old "Now, we can't extract the magic power from you yet."
    new "现在，我们还不能从你身上提取魔力。"

translate chinese chinese_6369950_1637:
    old "Because we need a little bit of time for the magic you extracted from her to settle within you."
    new "因为我们需要一点时间让你体内吸收的魔法稳定下来。"

translate chinese chinese_9121248_1638:
    old "Hmm? Hello?"
    new "嗯？喂？"

translate chinese chinese_2766131_1639:
    old "Yes, this is him speaking."
    new "是的，就是他本人说话。"

translate chinese chinese_5175338_1640:
    old "W- what?! N- now?!"
    new "什、什么？！现、现在？！"

translate chinese chinese_9007776_1641:
    old "I- I'll be there right away!"
    new "我—我马上就来！"

translate chinese chinese_2718315_1642:
    old "I can't believe Olivia's already in the hospital!"
    new "真不敢相信奥利维亚已经住院了！"

translate chinese chinese_2611169_1643:
    old "I better hurry!"
    new "我得赶快了！"

translate chinese chinese_8006836_1644:
    old "I- I can't believe you're already here!"
    new "我——我真的不敢相信你已经在这里了！"

translate chinese chinese_0001738_1645:
    old "Me too, but my obgyn decided that now was the best time."
    new "我也是，但是我的妇产科医生决定现在是最好的时机。"

translate chinese chinese_7803013_1646:
    old "So you know, I guess it's fine."
    new "所以你知道了，我想这也挺好。"

translate chinese chinese_5915012_1647:
    old "And how do you feel? Are you ready?"
    new "那你感觉怎么样？准备好了吗？"

translate chinese chinese_5651765_1648:
    old "I am, thank you, [pla]."
    new "我是，谢谢，[pla]。"

translate chinese chinese_5567507_1649:
    old "And hey, don't worry too much about me."
    new "而且嘿，别太担心我。"

translate chinese chinese_5567187_1650:
    old "I'm sure of my decision."
    new "我确定我的决定。"

translate chinese chinese_1078730_1651:
    old "And my mom and sister are already here to help with everything, so don't worry, alright?"
    new "我妈妈和妹妹已经来这里帮忙了，所以别担心，好吗？"

translate chinese chinese_7398891_1652:
    old "Alright, sure."
    new "好吧，行。"

translate chinese chinese_5564557_1653:
    old "Honey, the nurse says they have to move you into the operating room."
    new "亲爱的，护士说他们得把你推进手术室了。"

translate chinese chinese_4221182_1654:
    old "Sure, mom, no problem."
    new "好的，妈妈，没问题。"

translate chinese chinese_3498068_1655:
    old "Alright, [pla], wish me luck."
    new "好吧，[pla]，祝我好运。"

translate chinese chinese_9290138_1656:
    old "Good luck, I know you've got this."
    new "祝你好运，我知道你能行的。"

translate chinese chinese_5708631_1657:
    old "Alright, that was rather fast."
    new "好吧，那还真快。"

translate chinese chinese_2110832_1658:
    old "I'm doing okay."
    new "我挺好的。"

translate chinese chinese_8258070_1659:
    old "Really, [pla], I'm completely fine with this."
    new "真的，[pla]，我完全没问题。"

translate chinese chinese_1990233_1660:
    old "I was a little worried that my mom was going to be all annoying about it."
    new "我还担心我妈妈会在这方面烦死我。"

translate chinese chinese_4912089_1661:
    old "But she seems to be completely okay with all of this, so there's no problem really."
    new "但她似乎对这一切完全无所谓，所以其实没什么问题。"

translate chinese chinese_2303155_1662:
    old "That sounds alright."
    new "那听起来还行。"

translate chinese chinese_9522103_1663:
    old "I'm sorry to bother you, sir, but it's time for the patient to rest."
    new "对不起打扰您了，先生，但病人需要休息了。"

translate chinese chinese_7844242_1664:
    old "Alright, I guess I'll see you later then."
    new "好吧，那我猜一会儿见了。"

translate chinese chinese_4426579_1665:
    old "Sure, and hey, [pla], thanks again."
    new "好的，对了，[pla]，再次感谢。"

translate chinese chinese_3571031_1666:
    old "This big shift in my life wouldn't have been possible without you."
    new "没有你，我生活中这场巨大的变化是不可能实现的。"

translate chinese chinese_4777547_1667:
    old "I hope we'll continue being friends."
    new "希望我们还能继续做朋友。"

translate chinese chinese_6375162_1668:
    old "And hey, come see me whenever you want. We don't have to stop having fun after this."
    new "还有啊，想见我的时候就过来。这次之后我们也不用停止玩乐。"

translate chinese chinese_1631723_1669:
    old "Sure, I'll do it."
    new "行，我做。"

translate chinese chinese_9556005_1670:
    old "Hey, how do you feel?"
    new "嘿，你觉得怎么样？"

translate chinese chinese_7701513_1671:
    old "I'm doing alright, it was a lot easier than I expected, you know?"
    new "我挺好的，这比我想的要简单多了，你知道吗？"

translate chinese chinese_3982367_1672:
    old "It was?"
    new "是吗？"

translate chinese chinese_3850970_1673:
    old "Yeah, it was. The doctor really helped me."
    new "是的，医生真的帮了我很多。"

translate chinese chinese_2652846_1674:
    old "So I didn't feel a lot of pain."
    new "所以我不觉得疼。"

translate chinese chinese_4132523_1675:
    old "That sounds great, Olivia. That's awesome."
    new "听起来很棒，奥利维亚。太好了。"

translate chinese chinese_9838476_1676:
    old "Would the new parents like to meet their newborn son?"
    new "新爸妈想见见他们的新生儿儿子吗？"

translate chinese chinese_3685373_1677:
    old "But I think I'm a little too tired to hold him right now."
    new "但是我觉得我现在有点太累了，抱不动他。"

translate chinese chinese_7313876_1678:
    old "But why don't you do it, [pla]?"
    new "但是你为什么不做呢，[pla]？"

translate chinese chinese_4561450_1679:
    old "How about you, [pla]?"
    new "你呢，[pla]？"

translate chinese chinese_5698487_1680:
    old "I'm actually alright, you know?"
    new "其实我还挺好的，你知道吗？"

translate chinese chinese_2836613_1681:
    old "I have to say, I never expected to be a father so soon."
    new "不得不说我真没想到会这么快当爸爸。"

translate chinese chinese_9981344_1682:
    old "But I can't say that I feel bad about any of this."
    new "但我不能说我对这些感到难过。"

translate chinese chinese_5461817_1683:
    old "I never expected to have all these feelings within me."
    new "我从没想到自己会有这些感觉。"

translate chinese chinese_6584069_1684:
    old "But I think it's great, really."
    new "但我真的觉得这很棒。"

translate chinese chinese_9093737_1685:
    old "I'm so glad you feel that way, [pla]."
    new "我很高兴你这么觉得，[pla]。"

translate chinese chinese_0462481_1686:
    old "And by the way, you don't need to worry about anything related to money, you know?"
    new "对了，你知道的，不用担心任何关于钱的事情。"

translate chinese chinese_4705230_1687:
    old "My dad said he's moving here to be closer to his grandson."
    new "我爸爸说他要搬来这里，好离他的孙子近一点。"

translate chinese chinese_6061023_1688:
    old "So I don't think you'll need to worry about that."
    new "所以我想你不用担心那个。"

translate chinese chinese_3823627_1689:
    old "I see, well, that's good."
    new "哦，这样啊，那挺好的。"

translate chinese chinese_8362755_1690:
    old "And by the way, we can still keep in touch."
    new "对了，我们还可以保持联系。"

translate chinese chinese_6663259_1691:
    old "I'll be expecting some of your visits in the future."
    new "以后可别忘了来玩哦。"

translate chinese chinese_8162381_1692:
    old "A- and I'll be sure to visit you."
    new "我一定会来看你的。"

translate chinese chinese_0993819_1693:
    old "I'm sorry, sir, but the mother needs to rest."
    new "对不起，先生，但她需要休息。"

translate chinese chinese_3335701_1694:
    old "And visiting hours are almost over."
    new "而且探视时间快结束了。"

translate chinese chinese_6197298_1695:
    old "No problem, I'll leave right now."
    new "没问题，我现在就走。"

translate chinese chinese_7255772_1696:
    old "Sure, and [pla], thanks again. For everything."
    new "好的，还有 [pla]，再次感谢你。一切的一切。"

translate chinese chinese_0592450_1697:
    old "Alright, [pla]! You are just on time!"
    new "好了，[pla]！你正好及时赶到！"

translate chinese chinese_0520201_1698:
    old "We have to unload the magic from the spell into the magic portal."
    new "我们必须把咒语中的魔法卸载到魔法门户中。"

translate chinese chinese_3818989_1699:
    old "Oh right, okay, how do we do that?"
    new "哦对，好的，那我们怎么弄呢？"

translate chinese chinese_9195879_1700:
    old "Oh, that's the best part. Come with me."
    new "哦，那个是最精彩的。跟我来。"

translate chinese chinese_3619060_1701:
    old "Alright, here we are, I've prepared the portal to receive the magic power you collected from Olivia."
    new "好了，我们来了，我已经准备好了接收你从奥莉维亚那里收集的魔力的传送门。"

translate chinese chinese_3186733_1702:
    old "Now, drop your pants."
    new "现在，把裤子脱了。"

translate chinese chinese_8167394_1703:
    old "Oh! So that's how it's done..."
    new "哦！原来是这样..."

translate chinese chinese_8170121_1704:
    old "Of course! Were you expecting anything else? Come on, let me help you."
    new "当然了！你还期待什么别的吗？来吧，让我帮你。"

translate chinese chinese_4312448_1705:
    old "That's it, [pla]!"
    new "就是你了，[pla]！"

translate chinese chinese_9257065_1706:
    old "Just relax and let me do the work."
    new "放松点，让我来搞定。"

translate chinese chinese_8654604_1707:
    old "You just need to focus on enjoying it."
    new "你只需要专注于享受就行了。"

translate chinese chinese_7707641_1708:
    old "Wonderful, [pla]!"
    new "太棒了，[pla]！"

translate chinese chinese_9963505_1709:
    old "This is the best first experience we could've hoped for."
    new "这真是我们能期望的最好的初次体验了。"

translate chinese chinese_7799544_1710:
    old "But now, don't forget that we need to keep looking for other subjects."
    new "但是现在，别忘了我们还需要继续寻找其他对象。"

translate chinese chinese_4052205_1711:
    old "Hmph, yeah sure."
    new "哼，是啊，当然。"

translate chinese chinese_6630373_1712:
    old "Hi, [pla], how are you doing?"
    new "嗨，[pla]，最近怎么样？"

translate chinese chinese_7778394_1713:
    old "Hi, Mrs. Priya. I'm doing alright, and you?"
    new "嗨，普里亚夫人。我挺好的，你呢？"

translate chinese chinese_1369327_1714:
    old "I'm alright, honey."
    new "我挺好的，亲爱的。"

translate chinese chinese_3420708_1715:
    old "A little busy, but that's normal."
    new "有点忙，但这也是正常的。"

translate chinese chinese_8008138_1716:
    old "And tell me, what brings you here today, honey?"
    new "说说看，今天是什么风把你吹来的，宝贝？"

translate chinese chinese_1367618_1717:
    old "Well, not much. I was just passing by and wanted to say hello."
    new "嗯，没什么，我只是路过，想打个招呼。"

translate chinese chinese_0592369_1718:
    old "Oh dear, aren't you sweet."
    new "哦，真可爱。"

translate chinese chinese_9036828_1719:
    old "It's good to see you."
    new "见到你真好。"

translate chinese chinese_5167924_1720:
    old "Be sure to come back soon, dear."
    new "亲爱的，记得很快回来哦。"

translate chinese chinese_6860466_1721:
    old "With all the help you've given Olivia, you're always more than welcome."
    new "因为你给了奥利维亚这么多帮助，你永远都是受欢迎的。"

translate chinese chinese_8135855_1722:
    old "Thanks a lot, ma'am."
    new "非常感谢，女士。"

translate chinese chinese_7456217_1723:
    old "See you, honey."
    new "再见，亲爱的。"

translate chinese chinese_2654849_1724:
    old "Hello, [pla]! It's so good to see you. How are you?"
    new "你好，[pla]！见到你真好。你怎么样？"

translate chinese chinese_7809828_1725:
    old "I'm okay, dear."
    new "我没事，亲爱的。"

translate chinese chinese_9372612_1726:
    old "I've been a little busy ever since the baby came, you know."
    new "自从宝宝来了以后，我一直挺忙的，你知道的。"

translate chinese chinese_2307360_1727:
    old "But he's such a bundle of joy that he's made everything so cheerful around here!"
    new "但他是个如此快乐的源泉，让这里的一切都变得如此愉快！"

translate chinese chinese_0398767_1728:
    old "That's very good to hear, Mrs. Priya."
    new "听到这个消息真好，普里亚夫人。"

translate chinese chinese_1343320_1729:
    old "Tell me, honey, what brings you here today?"
    new "告诉我，宝贝，今天是什么风把你吹来的？"

translate chinese chinese_8720298_1730:
    old "Oh, I just wanted to say hello."
    new "哦，我只是想打个招呼。"

translate chinese chinese_2284785_1731:
    old "See how you're doing and stuff."
    new "看看你过得怎么样之类的。"

translate chinese chinese_6801507_1732:
    old "Aren't you sweet?"
    new "真甜呢。"

translate chinese chinese_1937738_1733:
    old "Well, as you can see, we're doing more than alright."
    new "嗯，你看，我们的状况挺好的。"

translate chinese chinese_6986726_1734:
    old "It's a shame the baby's sleeping now, otherwise you could see him."
    new "真可惜，宝宝现在睡着了，不然你可以看看他。"

translate chinese chinese_0235638_1735:
    old "But maybe some other time."
    new "不过也许改天吧。"

translate chinese chinese_5536626_1736:
    old "Well, it was good seeing you, Mrs. Priya. I'll be sure to come back later."
    new "嗯，见到你很高兴，普里亚夫人。我一定会再来的。"

translate chinese chinese_9829921_1737:
    old "Sure, dear, you're welcome anytime."
    new "当然了，亲爱的，你随时都可以来。"

translate chinese chinese_7782316_1738:
    old "Nice seeing you."
    new "见到你真好。"

translate chinese chinese_0628686_1739:
    old "Thanks, ma'am."
    new "谢谢，女士。"

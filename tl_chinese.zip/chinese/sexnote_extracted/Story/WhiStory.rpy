# auto-tl Qwen Colab

translate chinese chinese_1624423_0:
    old "What the fuck? I just can't believe it!"
    new "什么情况？我真不敢相信！"

translate chinese chinese_1748705_1:
    old "Ruby please! Just listen to me."
    new "ruby 求你了！ just 听我说。"

translate chinese chinese_5071429_2:
    old "Listen, to what?"
    new "听什么？"

translate chinese chinese_4939151_3:
    old "What explanation could you possibly have to go around making friends with that loser?!"
    new "你跟她这种loser交朋友还能有什么好解释？！"

translate chinese chinese_2060030_4:
    old "You don't understand, I need his help, my grades have been low."
    new "你不懂，我需要他的帮助，我的成绩一直不好。"

translate chinese chinese_6494938_5:
    old "So, he's going to help me study for my tests. If he doesn't I'll fail my classes."
    new "所以他要帮我复习考试。如果他不帮忙，我就会挂科。"

translate chinese chinese_0399152_6:
    old "And? Who cares?! You can't just hang out with that disgusting nerd!"
    new "而且？谁在乎嘛！你不能就这么跟他混在一起，那个恶心的书呆子！"

translate chinese chinese_0890769_7:
    old "Listen, you better find another way other than spending time with that loser."
    new "听着，你最好找其他方式，别再浪费时间在那个loser身上了。"

translate chinese chinese_5962261_8:
    old "B- b- but..."
    new "b- b- 但是..."

translate chinese chinese_2496375_9:
    old "Ugh, look at that, now the fucking nerds are even eavesdropping our conversations."
    new "哎，看看，现在这些该死的书呆子连我们的对话都偷听了。"

translate chinese chinese_9827398_10:
    old "But Ruby! Wait!"
    new "但是Ruby！等一下！"

translate chinese chinese_3697198_11:
    old "Oh hey Mike, what's up?"
    new "哦，迈克，最近怎么样？"

translate chinese chinese_5503829_12:
    old "Hmph..."
    new "哼……"

translate chinese chinese_5842972_13:
    old "Hmm, that was weird."
    new "嗯，那真是奇怪。"

translate chinese chinese_7418561_14:
    old "Yeah, it was. What's up with him, is he angry about something?"
    new "是啊。他怎么了，是不是生什么气了？"

translate chinese chinese_3292597_15:
    old "Well, now that you mention it. He's been acting odd recently."
    new "说到这个，他最近确实行为有点奇怪。"

translate chinese chinese_3145180_16:
    old "I don't really know why though."
    new "虽然我真的不知道为什么。"

translate chinese chinese_0598696_17:
    old "Hmm, I see. I guess I'll have to speak with him."
    new "嗯，我明白了。看来我得和他谈谈。"

translate chinese chinese_1223668_18:
    old "I think so. He'll probably tell you what's his deal."
    new "应该是吧。他可能会告诉你他的想法。"

translate chinese chinese_9510556_19:
    old "Yeah, well, see you later then."
    new "好吧，那回头见。"

translate chinese chinese_3893948_20:
    old "Oh hi [pla]!"
    new "哦，嗨 [pla]！"

translate chinese chinese_3244170_21:
    old "Uhh, what a nice surprise...It's so good to see you, how are you?"
    new "呃，真是个意外的惊喜……见到你真好，你怎么样？"

translate chinese chinese_0639802_22:
    old "Hi Mrs. White, nice to see you."
    new "白太太，很高兴见到您。"

translate chinese chinese_9368912_23:
    old "Hey, I came looking for Mike, is he around? I wanted to talk to him."
    new "嘿，我是来找迈克的，他在吗？我想和他谈谈。"

translate chinese chinese_5168183_24:
    old "Hmm, well, he is here, but... I don't think he wants to see you."
    new "嗯，他倒是在这里，但是……我觉得他不想见你。"

translate chinese chinese_0168857_25:
    old "Really, why?"
    new "真的，为什么？"

translate chinese chinese_9041469_26:
    old "Well, he's been a little... Uhh, unwell these past few days, so he doesn't really want to talk to anybody."
    new "嗯，他这些天有点……不舒服，所以不想跟任何人说话。"

translate chinese chinese_0209332_27:
    old "Unwell? Is he ok?"
    new "不舒服？他好吗？"

translate chinese chinese_0282181_28:
    old "He's fine, but... Uhh, not really in a good mood."
    new "他倒是没事，但是……嗯，心情不太好。"

translate chinese chinese_9002351_29:
    old "Hmm, is there something I can help with?"
    new "嗯，有什么我可以帮忙的吗？"

translate chinese chinese_8755559_30:
    old "Listen, he asked me not to tell anybody about this. But since you're one of his best friends I'll let you know."
    new "听着，他让我不要把这件事告诉任何人。但既然你是他的好朋友，我就告诉你吧。"

translate chinese chinese_5193024_31:
    old "The thing is, his birthday was a couple of days ago... and nobody seemed to remember."
    new "问题是，他的生日就在几天前……而且好像没人记得。"

translate chinese chinese_1252199_32:
    old "Ohhh, damn! I totally forgot about it. Shit!"
    new "哦豁，忘了这事了。见鬼！"

translate chinese chinese_2603456_33:
    old "Yes well, not one of his friends gave him a call, or even said happy birthday to him."
    new "嗯，他的朋友们没人给他打电话，甚至没人对他说生日快乐。"

translate chinese chinese_5348024_34:
    old "Damn it, of course, he's angry."
    new "该死，当然他生气了。"

translate chinese chinese_9450865_35:
    old "The reason I tell you this is because Mike is always talking about you, he says you're his best friend."
    new "我告诉你这些是因为迈克总是说起你，他说你是他最好的朋友。"

translate chinese chinese_8955156_36:
    old "He admires you a lot, you know..."
    new "他很崇拜你，你知道吗……"

translate chinese chinese_1295971_37:
    old "D- do you think he'll talk to me if I try?"
    new "D- 如果我试试，你觉得他会理我吗？"

translate chinese chinese_6406206_38:
    old "Hmm, I don't really know... But I guess you can try. I actually think it would be good for him."
    new "嗯，我真的不太清楚……但是我觉得你可以试试。实际上，我觉得这对他有好处。"

translate chinese chinese_8895473_39:
    old "He's been really depressed lately. So, it would be good if you could help him out with that."
    new "他最近真的很抑郁。所以如果你能帮他一下就太好了。"

translate chinese chinese_2918455_40:
    old "Sure, sure, don't worry, I'll do my best to fix this."
    new "行吧，别担心，我会尽力解决这个问题的。"

translate chinese chinese_6562240_41:
    old "Ok,  then he's in his room. Good luck."
    new "好吧，那他在房间里。祝你好运。"

translate chinese chinese_0184826_42:
    old "Ugh, did my mom let you in?"
    new "哎，是我妈让你进来的吗？"

translate chinese chinese_4075341_43:
    old "Hey man, listen, I'm really sorry. I've been dealing with some stuff, so, I forgot about your birthday."
    new "嘿，听我说，我真的挺抱歉的。我最近有些事情，所以忘了你的生日了。"

translate chinese chinese_0458589_44:
    old "But I totally care about it, really."
    new "但我真的很在乎这件事。"

translate chinese chinese_0622500_45:
    old "Oh yeah, you care?"
    new "哦 yeah，你还关心这个？"

translate chinese chinese_2146743_46:
    old "That's funny, you seem to care a lot more about the girls' birthdays..."
    new "真有趣，你好像对女生的生日很上心……"

translate chinese chinese_7488907_47:
    old "But I guess it's no surprise since I'm always the one who's left out..."
    new "但我想这也算不上意外，因为我总是被排除在外……"

translate chinese chinese_7274896_48:
    old "Aww, come on dude, you know it's not like that."
    new "哎呀，别这样，你知道不是那样的。"

translate chinese chinese_8629832_49:
    old "It's just that recently I've been kinda busy."
    new "就是最近有点忙。"

translate chinese chinese_0132483_50:
    old "Yeah, yeah, yeah, you're always busy. I get it, you're Mr. important."
    new "yeah, yeah, 你总是很忙。我懂了，你就是个大忙人。"

translate chinese chinese_3989050_51:
    old "Hey Mike, come on man, listen to me."
    new "嘿迈克， seriously 听我说。"

translate chinese chinese_6869966_52:
    old "No! You listen. It's just unbelievable man, like, wow."
    new "不！你听我说。这简直难以置信，天啊。"

translate chinese chinese_9167924_53:
    old "You know, I've always been there for you when you needed it!"
    new "你知道吗，每次你需要我的时候，我都在那里！"

translate chinese chinese_1561943_54:
    old "I know dude, I'm sorry."
    new "我知道，真的很抱歉。"

translate chinese chinese_7607710_55:
    old "You know what? It's ok, it's not like it's the first time anyway. So I'm used to it. I really don't have any friends."
    new "你知道吗？没关系，这也不是第一次了。所以我习惯了。我真的没有朋友。"

translate chinese chinese_4272304_56:
    old "Hey don't say that, you know very well I'm your friend."
    new "别这么说，你知道我是你的朋友。"

translate chinese chinese_5391522_57:
    old "And what do you mean it's not the first time, it was just this year that I forgot your birthday."
    new "什么叫不止一次，今年我才忘了你的生日。"

translate chinese chinese_1832432_58:
    old "Oh shut up! I'm not talking about my birthday. Remember Halloween?"
    new "oh shut up！我才不提我的生日呢。还记得万圣节吗？"

translate chinese chinese_4385278_59:
    old "When we were playing that game you guys made fun of me. And had me leave with that stupid challenge."
    new "你们玩游戏的时候取笑我，还给我那个愚蠢的挑战让我离开。"

translate chinese chinese_0978529_60:
    old "Of course, you didn't want me there."
    new "当然，你不想让我在那里。"

translate chinese chinese_3053294_61:
    old "Listen dude..."
    new "听着，兄弟..."

translate chinese chinese_9121613_62:
    old "Shut up! Keep your excuses to yourself."
    new "闭嘴！把你的借口留给自己。"

translate chinese chinese_8809074_63:
    old "And get the hell out of here. I'm busy."
    new "滚出去，我忙着呢。"

translate chinese chinese_6379676_64:
    old "Mike, please, calm down."
    new "迈克，请冷静一下。"

translate chinese chinese_0996296_65:
    old "Thinking about it, I can see your point, you're absolutely right."
    new "想一想，你的观点我明白了，你说得完全正确。"

translate chinese chinese_3637989_66:
    old "I've been a really shitty friend."
    new "我真是个糟糕的朋友。"

translate chinese chinese_9867886_67:
    old "So... I'm really sorry bud, and I hope you can forgive me."
    new "所以……我真的感到很抱歉，希望你能原谅我。"

translate chinese chinese_8265496_68:
    old "Pfff! Get out of here!"
    new "puff! 走开！"

translate chinese chinese_8092957_69:
    old "Do you really think you can get out of this with a simple apology?"
    new "你真以为一句道歉就能解决这件事？"

translate chinese chinese_2619857_70:
    old "Hmm... You're right... And I think I can do something to show you I'm your friend."
    new "嗯……你说得对……而且我想我可以做点什么来证明我是你的朋友。"

translate chinese chinese_5373473_71:
    old "And this is kinda risky, so I know you'll believe me once you see it."
    new "这有点冒险，所以我知道你看了就会相信我。"

translate chinese chinese_4220608_72:
    old "Come with me for a second."
    new "跟我来一下。"

translate chinese chinese_5305434_73:
    old "Where?"
    new "在哪里？"

translate chinese chinese_0178763_74:
    old "I have to show you something."
    new "我得给你看样东西。"

translate chinese chinese_2875610_75:
    old "Just shut up and come with me."
    new "别说了，跟我来。"

translate chinese chinese_7785322_76:
    old "If afterwards you're still mad at me I'll leave you alone."
    new "如果之后你还在生我的气，我就不再烦你了。"

translate chinese chinese_3564544_77:
    old "But this is worth it."
    new "但这值得。"

translate chinese chinese_9999305_78:
    old "Hmm, ok, let's go."
    new "嗯，好吧，我们走吧。"

translate chinese chinese_2217966_79:
    old "What's this? Where are you taking me?"
    new "这是什么？你带我去哪儿？"

translate chinese chinese_6058391_80:
    old "It's ok dude. Just trust me, you'll like this."
    new "放心吧，相信我，你会喜欢的。"

translate chinese chinese_3391282_81:
    old "What the fuck? This is my neighbor's house. What are we doing here?"
    new "妈的？这是隔壁家。我们来这里干什么？"

translate chinese chinese_1234752_82:
    old "Chill out dude. It's ok, I know her."
    new "冷静点兄弟。没事，我认识她。"

translate chinese chinese_0836587_83:
    old "Just as I thought, If she's not here, that means she'll be probably with a customer upstairs."
    new "果然，如果她不在这里，那就意味着她可能在楼上陪客人。"

translate chinese chinese_9765812_84:
    old "I think I can show you something worthwhile. Just hush and follow me."
    new "我觉得我可以给你看些值得一看的东西。你就跟着我来吧。"

translate chinese chinese_9543750_85:
    old "Great, they're in there."
    new "好了，她们在里面。"

translate chinese chinese_0371567_86:
    old "They? What's happening?"
    new "他们？发生什么事了？"

translate chinese chinese_1981437_87:
    old "Listen man, this is something I'm doing only this one time."
    new "听我说，这件事我只做这一次。"

translate chinese chinese_5232611_88:
    old "Take it as my birthday gift to you."
    new "就当是我的生日礼物送给你吧。"

translate chinese chinese_1874897_89:
    old "Now come here and take a peek."
    new "现在过来瞧一眼。"

translate chinese chinese_3188839_90:
    old "Dude! Wow!"
    new "喂！真厉害！"

translate chinese chinese_8768882_91:
    old "I would never have been able to see this through my telescope!"
    new "我用望远镜也看不到这个！"

translate chinese chinese_8685456_92:
    old "How did you know she does this kind of stuff?"
    new "你怎么知道她会做这种事？"

translate chinese chinese_0232849_93:
    old "Just shut up and enjoy it."
    new "别说了，享受吧。"

translate chinese chinese_5393099_94:
    old "I will man, you're the best."
    new "我会的，你是最棒的。"

translate chinese chinese_9830634_95:
    old "Dude, that was the best birthday present ever!"
    new "伙计，那真是我有史以来收到的最好的生日礼物了！"

translate chinese chinese_2059085_96:
    old "Well, I'm glad you liked it."
    new "嗯，很高兴你喜欢。"

translate chinese chinese_0267322_97:
    old "I just wanted to say sorry again for being such a lousy friend."
    new "我只是想再说声对不起，因为我真是个糟糕的朋友。"

translate chinese chinese_3760330_98:
    old "And listen, man, I know you think you're all alone, but that's not true."
    new "听着，我知道你觉得你一个人孤零零的，但事实并非如此。"

translate chinese chinese_7790637_99:
    old "I really do think of you as my best friend, and I'm sure the girls... Uhh, they find you as a good classmate..."
    new "我真的把你当做好朋友，而且我敢肯定，女生们……嗯，她们觉得你是个好同学……"

translate chinese chinese_8428051_100:
    old "It's just that lately we all have been dealing with some stuff."
    new "就是最近我们都有一些事情要处理。"

translate chinese chinese_0896674_101:
    old "But I want you to know that I would never take you for granted."
    new "但我想让你知道，我永远不会把你当成理所当然。"

translate chinese chinese_0732486_102:
    old "It's ok man, I was angry, but you've more than made up for it with that awesome gift."
    new "没事兄弟，我本来很生气，但你那个超赞的礼物已经完全弥补了。"

translate chinese chinese_9246401_103:
    old "It was so fucking rad."
    new "那真是他妈的酷毙了。"

translate chinese chinese_9847859_104:
    old "Well I'm happy we're ok now. But I kinda have to leave."
    new "好吧，现在我们没事了我挺高兴的。但我得走了。"

translate chinese chinese_8421197_105:
    old "I have to do a couple of things, but I'll swing by later."
    new "我有几件事要处理，但晚点会过来。"

translate chinese chinese_2935200_106:
    old "Wait, Dude!"
    new "等一下，伙计！"

translate chinese chinese_2684719_107:
    old "Before you leave, there's something I have to ask you."
    new "走之前，我有个问题必须问你。"

translate chinese chinese_0538071_108:
    old "Hmm, sure, tell me."
    new "嗯，说吧。"

translate chinese chinese_7443673_109:
    old "Hmm, the thing is... I don't really know how to say this..."
    new "嗯，问题是……我真不知道该怎么说……"

translate chinese chinese_7954889_110:
    old "I'm gonna need you to help me study for a subject..."
    new "我需要你帮我复习一个科目……"

translate chinese chinese_3608850_111:
    old "What? Haha! But you've never wanted to study with us before."
    new "什么？哈哈！但你以前从不想和我们一起学习。"

translate chinese chinese_2324989_112:
    old "Why now all of a sudden?"
    new "为什么突然这样？"

translate chinese chinese_0063191_113:
    old "It's because it's super lame."
    new "就是因为超级尴尬。"

translate chinese chinese_0720034_114:
    old "But you see, this time is not really for me."
    new "但是你看，这次其实不是为了我。"

translate chinese chinese_4418818_115:
    old "I told Olivia I would help her with her studies, so I kinda have to learn the subject."
    new "我跟Olivia说会帮她学习，所以我也得学这个科目。"

translate chinese chinese_2311873_116:
    old "Oh, really? Hahahahahaha!"
    new "哦，是吗？哈哈哈哈哈！"

translate chinese chinese_9731252_117:
    old "Dude! Don't laugh, this is important, ok?"
    new "喂！别笑，这事很重要，好吗？"

translate chinese chinese_8711371_118:
    old "Heh, s- sure, sorry."
    new "嘿嘿，好啦，对不起。"

translate chinese chinese_3373689_119:
    old "Well anyway, the point is that I'm gonna need your help to learn the subjects."
    new "总之，我的意思是需要你的帮助来学习这些科目。"

translate chinese chinese_2581079_120:
    old "'Cause you'll help me out, right? I mean, we're friends..."
    new "因为你一定会帮我的，对吧？我是说，我们是朋友……"

translate chinese chinese_1545731_121:
    old "*Sigh*"
    new "*叹气*"

translate chinese chinese_7967186_122:
    old "I mean, sure, if you really need it I'll help you out."
    new "我的意思是，如果你真的需要的话，我会帮你。"

translate chinese chinese_0307280_123:
    old "But dude, isn't she always super mean to us?"
    new "但是伙计，她不是总是对我们很凶吗？"

translate chinese chinese_5869779_124:
    old "You've heard the way she and Ruby talk to us."
    new "你听他们俩跟我们说话的样子。"

translate chinese chinese_2737695_125:
    old "Like... You know?"
    new "就是……你知道的？"

translate chinese chinese_7105558_126:
    old "I know, I know. But the thing is..."
    new "我知道，我知道。但是问题是..."

translate chinese chinese_3175352_127:
    old "I actually like that, a lot if I can be honest."
    new "说实话，我真的很喜欢那样。"

translate chinese chinese_4961278_128:
    old "What? Are you for real right now?"
    new "什么？你 serious 吗？"

translate chinese chinese_4010043_129:
    old "What could you possibly like about that?"
    new "那东西你到底看上了哪里？"

translate chinese chinese_5001893_130:
    old "To be honest, I don't know why, but I love it when girls are mean to me. It's so hot!"
    new "说实话，我不知道为什么，但我就是喜欢女生对我凶的样子，真是火辣！"

translate chinese chinese_6663278_131:
    old "Mmm, even the other day when they were insulting us in the hallway."
    new "嗯，就连那天他们在走廊上侮辱我们的时候也是。"

translate chinese chinese_3279148_132:
    old "Uhh man, I almost got a hard-on!"
    new "哎呀，我差点就硬了！"

translate chinese chinese_3288802_133:
    old "Ok, I get it, you're a freak. But it's fine I guess."
    new "好吧，我懂了，你就是个怪胎。不过我觉得还好吧。"

translate chinese chinese_2223270_134:
    old "Ok man, I guess I can help you, I'm not sure what you need exactly though."
    new "好吧，我猜我可以帮你，不过我还不确定你需要什么具体的东西。"

translate chinese chinese_3291321_135:
    old "Well, I have to give her classes on those subjects. So, something that will help me with that."
    new "嗯，我得给她上那些科目的课。所以，有些能帮我做到这一点的东西。"

translate chinese chinese_2476109_136:
    old "Hmm, I think I know what we can do."
    new "嗯，我想我知道我们可以做什么。"

translate chinese chinese_1611816_137:
    old "How about I give you the classes, and you just repeat them to Olivia?"
    new "要不我教你这些课程，然后你再重复给奥利维亚听？"

translate chinese chinese_8106397_138:
    old "Ohh, that sounds perfect."
    new "哦，那听起来perfect。"

translate chinese chinese_5896709_139:
    old "But, you're gonna have to pay a lot of attention to everything I tell you."
    new "但是，你得非常注意我告诉你的每一件事。"

translate chinese chinese_8061929_140:
    old "After all it won't be useful if she asks you a question and you can't answer ir properly."
    new "毕竟如果她问你问题而你又答不上来那就没什么用了。"

translate chinese chinese_1255374_141:
    old "Sure, sure, sure. No problem man, I'm sure I'll learn it all."
    new "行吧行吧行吧，没问题兄弟，我肯定能学会的。"

translate chinese chinese_2764803_142:
    old "Well, with that sorted out, I'll go home. And we can meet after class to study."
    new "好了，既然这件事解决了，我就回家吧。我们下课后再见面学习。"

translate chinese chinese_2387476_143:
    old "No problem. Thank you so much dude! You're the best."
    new "没问题。真是太感谢你了！你真棒。"

translate chinese chinese_4391139_144:
    old "Yeah, yeah, but don't be so quick to thank me. We don't know if this will work."
    new "好吧，好吧，但别这么快感谢我。我们还不知道这是否管用。"

translate chinese chinese_7777227_145:
    old "I'll do my best, I promise!"
    new "我一定会尽全力的，我保证！"

translate chinese chinese_7201813_146:
    old "Alright, see you later."
    new "好吧，回头见。"

translate chinese chinese_9583528_147:
    old "Hi [pla]! How are you? It's so nice to see you."
    new "嗨 [pla]！你好吗？见到你真好。"

translate chinese chinese_7310742_148:
    old "Hi Mrs. White, nice seeing you too."
    new "白太太，见到您也很高兴。"

translate chinese chinese_1059171_149:
    old "Let me tell you something. I don't know what you said to Mike."
    new "让我告诉你一件事。我不知道你对迈克说了什么。"

translate chinese chinese_4473993_150:
    old "But since you two talked, he's been in a much better mood. Thank you so much for that."
    new "但是自从你们俩聊过之后，他的心情好多了。真的很感谢你。"

translate chinese chinese_5416187_151:
    old "No problem, I'm happy we got to sort things out."
    new "没问题，我很高兴我们能把事情说清楚。"

translate chinese chinese_9353034_152:
    old "You did a great job."
    new "你干得不错。"

translate chinese chinese_3111373_153:
    old "So good that I've been thinking maybe I should give you a small reward."
    new "好到我一直在想 maybe 我应该给你一点奖励。"

translate chinese chinese_1472555_154:
    old "Oh, I appreciate it, but you really don't have to."
    new "哦，我很感激，但你真的不用这么做的。"

translate chinese chinese_2351563_155:
    old "I was just trying to be a good friend, and help him out."
    new "我只是想当个好朋友，帮帮他。"

translate chinese chinese_5331028_156:
    old "Also, I don't want it to be of any trouble."
    new "另外，我也不想给你添麻烦。"

translate chinese chinese_0675363_157:
    old "Oh, but it's no trouble sweety, you've been very good to Mike."
    new "哦，没关系的，甜心，你对迈克很好。"

translate chinese chinese_3955372_158:
    old "And I believe that deserves a good reward."
    new "我觉得这值得好好奖励一下。"

translate chinese chinese_6017463_159:
    old "Uhh, I'm very thankful Mrs. White, but I think I'm ok."
    new "呃，我很感谢怀特夫人，但我觉得我还好。"

translate chinese chinese_0619029_160:
    old "And... uh, I kinda have to go study with Mike now, so..."
    new "而且……我得去和迈克一起学习了，所以……"

translate chinese chinese_5794618_161:
    old "Hmm, yeah, that's right, you two have to study. Go ahead."
    new "嗯，对了，你们两个得学习呢。去吧。"

translate chinese chinese_0929348_162:
    old "In the meantime I'll think of something."
    new "到时候我再想想办法。"

translate chinese chinese_5126973_163:
    old "And I'm sure you'll love it."
    new "我相信你会喜欢的。"

translate chinese chinese_8194346_164:
    old "I see you later sweety."
    new "一会儿见甜心。"

translate chinese chinese_1173179_165:
    old "See you later Mrs. White."
    new "白太太，再见。"

translate chinese chinese_0893373_166:
    old "[pla] dude! Hi!"
    new "[pla] 哥们儿！你好！"

translate chinese chinese_8121018_167:
    old "Did you come to study?"
    new "你是来学习的吗？"

translate chinese chinese_1391535_168:
    old "Yeah dude, I figured you'd want to start as soon as possible."
    new "是啊，兄弟，我想你会想尽快开始的。"

translate chinese chinese_4016762_169:
    old "For sure, my first session with Olivia's coming soon."
    new "当然，我和Olivia的第一回合很快就要来了。"

translate chinese chinese_1756510_170:
    old "And I don't know shit about the subject."
    new "我对这个话题一窍不通。"

translate chinese chinese_5186135_171:
    old "Don't you say..."
    new "别说了..."

translate chinese chinese_9987930_172:
    old "But that's why I'm here, so let's get to it."
    new "但这就是我在这里的原因，所以咱们开始吧。"

translate chinese chinese_3211222_173:
    old "Let's do it dude..."
    new "来吧伙计..."

translate chinese chinese_0175525_174:
    old "Oh, [pla]! Did you and Mike finish already? How did it go?"
    new "哦，[pla]！你和迈克结束了吗？怎么样？"

translate chinese chinese_8674742_175:
    old "That's right Mrs. White, we actually progressed quite a bit."
    new "没错，怀特夫人，我们实际上进展了不少。"

translate chinese chinese_9269567_176:
    old "Mike has been putting in quite some effort to study, so he caught the lesson really quick."
    new "迈克学习很用功，所以很快就掌握了这节课的内容。"

translate chinese chinese_6154037_177:
    old "But wait, leaving so soon?"
    new "但是等等，这么快就走吗？"

translate chinese chinese_0181203_178:
    old "Well, yeah, since we're done, and it's getting kinda late."
    new "嗯，反正我们也差不多了，而且时间也挺晚的。"

translate chinese chinese_9759674_179:
    old "I thought it would be better to go home."
    new "我以为回家会比较好。"

translate chinese chinese_3801859_180:
    old "Oh no, no, no. I just finished making dinner. Stay and have dinner with us."
    new "哦不，不，不。我刚做好晚饭。留下来和我们一起吃吧。"

translate chinese chinese_8635816_181:
    old "Hmm, I don't know Mrs. White, I'm very thankful, but I don't want it to be of any trouble."
    new "嗯，我不太认识怀特夫人，我很感激，但不想给她添麻烦。"

translate chinese chinese_6789975_182:
    old "Don't be silly"
    new "别傻了"

translate chinese chinese_2682901_183:
    old "It's only an extra plate, besides you must be tired from studying with Mike."
    new "只是多一个盘子而已，再说和迈克一起学习你肯定累了。"

translate chinese chinese_5360076_184:
    old "And you've been so good, not only did you talk to Mike when he was angry."
    new "而且你表现得很好，不仅在迈克生气的时候和他说话了。"

translate chinese chinese_9356365_185:
    old "You're also helping him study."
    new "你也在帮他学习。"

translate chinese chinese_5433371_186:
    old "The least I can do is invite you to have some dinner with us."
    new "我至少可以邀请你和我们一起吃晚饭。"

translate chinese chinese_8745549_187:
    old "I can't just let you leave like that."
    new "我不能让你就这样离开。"

translate chinese chinese_3265971_188:
    old "Hey, mom, I'm hungry. It's dinner ready?"
    new "妈，我饿了，饭做好了吗？"

translate chinese chinese_9654395_189:
    old "Oh [pla], you're still here?"
    new "哦，[pla]，你还在啊？"

translate chinese chinese_6875097_190:
    old "Dinner's ready honey, I was just telling your friend that he should stay for it."
    new "晚饭好了亲，我刚才跟你的朋友说让他留下来一起吃。"

translate chinese chinese_8596350_191:
    old "For sure dude! You should totally stay."
    new "当然了兄弟！你绝对应该留下。"

translate chinese chinese_0274366_192:
    old "My mom makes the best pot roast you'll ever try, trust me you'll like it."
    new "我妈妈做的红酒炖肉超级好吃，相信我，你会喜欢的。"

translate chinese chinese_5180994_193:
    old "Oh he's gonna love it."
    new "哦，他一定会喜欢的。"

translate chinese chinese_1515071_194:
    old "All right, if you insist, I can't say no..."
    new "好吧，如果你坚持，我就不拒绝了……"

translate chinese chinese_2550545_195:
    old "Thanks a lot Mrs. White, I really appreciate it."
    new "白太太，真的非常感谢你。"

translate chinese chinese_2425921_196:
    old "Let's go then!"
    new "那我们走吧！"

translate chinese chinese_4136789_197:
    old "So tell me, how are your studies going? And your grades?"
    new "所以告诉我，你的学习怎么样了？成绩呢？"

translate chinese chinese_6447029_198:
    old "I hope everything's going well with your exams."
    new "希望你的考试一切顺利。"

translate chinese chinese_7023901_199:
    old "Well, Belle and I are doing well on our end of term project."
    new "嗯，我和贝尔期末项目进展得还不错。"

translate chinese chinese_4360582_200:
    old "She's really smart, and has helped me a lot with that."
    new "她真的很聪明，帮我了很多忙。"

translate chinese chinese_8913395_201:
    old "Oh right [pla], you did yours with Hin, right?"
    new "哦对了，[pla]，你是和hin一起做的，对吧？"

translate chinese chinese_6636613_202:
    old "How did that go?"
    new "怎么样了？"

translate chinese chinese_4073846_203:
    old "Uhh... W- well, it went really... well."
    new "呃……嗯，挺……好的。"

translate chinese chinese_0660200_204:
    old "Really well actually, Hin is a very good student, so we flew through it."
    new "其实挺好的，Hin 是个很好的学生，所以我们很快就搞定了。"

translate chinese chinese_9637489_205:
    old "Uh, that makes sense, of course she would do a good job."
    new "嗯，说得通，她肯定能做好。"

translate chinese chinese_6568506_206:
    old "Specially since she's so into you."
    new "特别是她对你那么有感觉。"

translate chinese chinese_4547651_207:
    old "Please dude, don't play fool, she's sooo got a thing for you."
    new "拜托了，别装了，她对你可是有意思得很。"

translate chinese chinese_5509906_208:
    old "I don't know what you're talking about, we're just friends..."
    new "我不知道你在说什么，我们只是朋友..."

translate chinese chinese_5260659_209:
    old "Hinn is Jade's daugther, right? She's such a nice, smart girl."
    new "欣是 jade 的女儿对吧？她真是个又漂亮又聪明的女孩。"

translate chinese chinese_8746741_210:
    old "Are you two dating?"
    new "你们俩在交往吗？"

translate chinese chinese_9401479_211:
    old "No, we're not. Mike's just messing with me."
    new "不，不是那样的。迈克只是在逗我。"

translate chinese chinese_9606918_212:
    old "Come on, she totally likes you..."
    new "得了，她明明喜欢你..."

translate chinese chinese_5713097_213:
    old "She's just a good friend. That's all there is to it."
    new "她只是个好朋友，就这么简单。"

translate chinese chinese_1437488_214:
    old "Hmm, I see [pla] is a total succes with girls, isn't he?"
    new "哼，看来[pla]在女生面前很吃得开嘛？"

translate chinese chinese_4565072_215:
    old "Only Hin."
    new "只有希恩。"

translate chinese chinese_5137737_216:
    old "I don't know what she see's in you dude."
    new "真不知道她看上你哪点了。"

translate chinese chinese_0934770_217:
    old "Oh, but he's a total heartthrob."
    new "哦，但他完全是个心动对象。"

translate chinese chinese_2391962_218:
    old "Hin's very bright for liking you [pla]."
    new "_HINTNAME非常中意你[pla]。"

translate chinese chinese_1905720_219:
    old "Uhhh, yeah... yeah she's really smart, but just a good friend."
    new "呃，是的……她是真的很聪明，但只是好朋友而已。"

translate chinese chinese_6602096_220:
    old "I see, that's very good."
    new "我明白了，这很好。"

translate chinese chinese_2276157_221:
    old "By the way what are your projects about?"
    new "对了，你的项目是关于什么的？"

translate chinese chinese_2385400_222:
    old "Ugh, some online content creation thing Belle said we should do."
    new "唉，贝尔说我们应该做的某个在线内容创作的东西。"

translate chinese chinese_6491279_223:
    old "It's a research project."
    new "这是一个研究项目。"

translate chinese chinese_6219458_224:
    old "She's very into those subjects."
    new "她对那些话题很感兴趣。"

translate chinese chinese_8656529_225:
    old "And you [pla]? What are you and your friend Hin doing?"
    new "那你 [pla] 呢？你和你的朋友 Hin 在做什么？"

translate chinese chinese_0839796_226:
    old "We... Uhh, we have a psychology project."
    new "我们……嗯，有个心理项目。"

translate chinese chinese_3841435_227:
    old "About personal development and self confidence and stuff."
    new "关于个人成长和自信这些东西。"

translate chinese chinese_3342005_228:
    old "Oh, I see, interesting."
    new "哦，我明白了，挺有意思的。"

translate chinese chinese_2928397_229:
    old "It sounds like a very, very HARD subject."
    new "听起来是个非常、非常硬的话题。"

translate chinese chinese_0856781_230:
    old "I- it kind of is..."
    new "我——算是吧……"

translate chinese chinese_6079624_231:
    old "I imagine you must be working very very... hard."
    new "我猜你肯定是在非常非常...努力工作。"

translate chinese chinese_2740162_232:
    old "Yes, we really are."
    new "是的，我们确实如此。"

translate chinese chinese_7770740_233:
    old "The food was delicious Mrs. White, thanks a lot."
    new "怀特夫人，食物很好吃，谢谢您。"

translate chinese chinese_3859414_234:
    old "But it's getting kinda late. So, if you'll excuse me I should go home."
    new "但是已经挺晚了。所以，恕我失陪，我要回家了。"

translate chinese chinese_9794951_235:
    old "But I'll be back soon to keep studying, Mike."
    new "但我很快就会回来继续学习的，迈克。"

translate chinese chinese_0640720_236:
    old "That's ok sweety, I'm glad to hear you liked dinner."
    new "没关系，甜心，听说你晚饭吃得开心我就很高兴。"

translate chinese chinese_5663034_237:
    old "And I'm also glad you had a good time."
    new "我也很高兴你玩得开心。"

translate chinese chinese_3044069_238:
    old "Yes, it was... very good. You've got marvelous hands Mrs. White... For the kitchen of course..."
    new "是的，很……好。怀特夫人，你的手真厉害……当然，是在厨房里的意思……"

translate chinese chinese_2779336_239:
    old "You should stay for dinner more often.."
    new "你应该多留下来吃饭。。"

translate chinese chinese_7276709_240:
    old "So, you don't have to worry about coming here, and spending all the time you want."
    new "所以，你不用担心来这里，可以随心所欲地待多久都行。"

translate chinese chinese_8801183_241:
    old "Thanks a lot Mrs. White, that's very kind of you."
    new "白太太，真是太感谢您了。"

translate chinese chinese_4961265_242:
    old "I'm always happy to have some extra company here. And you know you're more than welcome."
    new "我总是很高兴这里能有多一些的陪伴。而且你知道你随时都受欢迎。"

translate chinese chinese_2895763_243:
    old "Uhh, sure, thank you."
    new "呃，好的，谢谢。"

translate chinese chinese_2462626_244:
    old "I think I should go now."
    new "我觉得我现在应该走了。"

translate chinese chinese_3196001_245:
    old "Get home safe. See you later sweetie."
    new "路上小心。一会儿见，甜心。"

translate chinese chinese_1690997_246:
    old "Later dude."
    new "一会儿见。"

translate chinese chinese_5657990_247:
    old "Ok, bye..."
    new "好吧，再见..."

translate chinese chinese_7465380_248:
    old "[pla] dude! Hi! What's up?"
    new "[pla] 哥们儿！嗨！最近怎么样？"

translate chinese chinese_1760999_249:
    old "Did you come to help me study?"
    new "你是来帮我学习的吗？"

translate chinese chinese_1855012_250:
    old "Yeah dude, that's right."
    new "对啊，兄弟，说得好。"

translate chinese chinese_9235881_251:
    old "Oh thank god, my next session with Olivia's coming soon."
    new "哦，感谢上帝，我下次和奥利维亚的约会很快就要来了。"

translate chinese chinese_0793601_252:
    old "And I was getting worried, because I'm not ready for her class."
    new "我还挺担心的，因为我还没准备好她的课。"

translate chinese chinese_1979010_253:
    old "Well that's why I'm here. Are you ready to start?"
    new "那我就来了。准备好了吗？"

translate chinese chinese_1718087_254:
    old "Yeah I'm ready, let's do this!"
    new "好了，我准备好了，咱们开始吧！"

translate chinese chinese_0443701_255:
    old "Wow! Dude! You got it right! I didn't know you were so good at this!"
    new "哇！哥们！你答对了！我不知道你这么擅长这个！"

translate chinese chinese_5665958_256:
    old "I mean, if you studied like that more often you'd have straight A's."
    new "我的意思是，如果你经常这么用功学习，你就全是A了。"

translate chinese chinese_6295723_257:
    old "Hehe, thanks man, I've tried to pay attention to what you've taught me."
    new "嘿嘿，谢谢啊，我尽量注意你教我的东西了。"

translate chinese chinese_2360914_258:
    old "So that I can teach it to Olivia."
    new "这样我就可以教给奥利维亚了。"

translate chinese chinese_6089840_259:
    old "Well I'm sure it's gonna go great if you keep going like that."
    new "照这样下去，我敢肯定一切都会很顺利的。"

translate chinese chinese_7198286_260:
    old "So, listen dude, it's getting kinda late, so, I should go home."
    new "所以，听我说，兄弟，天色不早了，我该回家了。"

translate chinese chinese_7833046_261:
    old "But I'll be back before your next session with Olivia."
    new "但我会在你下次和奥利维亚见面之前回来的。"

translate chinese chinese_2792537_262:
    old "Sure man, thanks a lot. See you later."
    new "行，谢谢了。回头见。"

translate chinese chinese_6600353_263:
    old "Damn, I'm sorry dude. I suck at this so much."
    new "妈的，真对不起。我真是烂透了。"

translate chinese chinese_2572908_264:
    old "I think I'm just wasting your time."
    new "我觉得我可能在浪费你的时间。"

translate chinese chinese_1502463_265:
    old "Nah, it's ok, this isn't an easy topic anyway."
    new "算了吧，没关系，这个话题本来就不容易。"

translate chinese chinese_6674240_266:
    old "We still got some time before you have to teach Olivia. So let's just relax."
    new "你教奥利维亚还有一段时间，所以我们先放松一下吧。"

translate chinese chinese_1326723_267:
    old "I can't relax dude! I told Olivia I was gonna teach her and I'm not ready."
    new "我根本放松不下来！我跟奥利维亚说要教她的，但我还没准备好。"

translate chinese chinese_8296999_268:
    old "I know, man, I know."
    new "我知道，兄弟，我知道。"

translate chinese chinese_5678662_269:
    old "I'm sure you'll get it before the day."
    new "我相信你今天肯定能搞定了。"

translate chinese chinese_8033264_270:
    old "Hmm... You're probably right [pla], sorry I got a little anxious."
    new "嗯……你说得对，[pla]，对不起，我有点急了。"

translate chinese chinese_0647224_271:
    old "Let's just try again, I'm sure I'll do better this time."
    new "咱们再试一次吧，这次我肯定能做得更好。"

translate chinese chinese_6677299_272:
    old "Nah, I don't think we should keep going today"
    new "算了，今天还是别继续了"

translate chinese chinese_8938033_273:
    old "We're already tired, and just forcing this won't help."
    new "我们已经累了，硬来也没用。"

translate chinese chinese_2015423_274:
    old "Besides, it's kinda late, so I think I better go home for now."
    new "再说，现在已经挺晚了，我想我还是先回家吧。"

translate chinese chinese_2563151_275:
    old "And we can pick it up another time."
    new "我们可以下次再继续。"

translate chinese chinese_8406253_276:
    old "Sure, you're probably right."
    new "好吧，你可能说得对。"

translate chinese chinese_0285588_277:
    old "Hello [pla] I'm so glad to see you."
    new "你好 [pla]，见到你真高兴。"

translate chinese chinese_6363526_278:
    old "Hi Mrs. White, how are you?"
    new "白太太，您好吗？"

translate chinese chinese_9806120_279:
    old "I'm fine sweetie, and you?"
    new "我很好甜心，你呢？"

translate chinese chinese_4047839_280:
    old "Let me guess, you came to see Mike, right?"
    new "让我猜猜，你是来看迈克的吧？"

translate chinese chinese_3931078_281:
    old "That's right, we'd planned another study session for today."
    new "没错，我们今天本来计划再搞一次学习 session。"

translate chinese chinese_8242139_282:
    old "Well sweetie, I'm sorry to tell you he isn't here."
    new "宝贝，抱歉告诉你，他不在这里。"

translate chinese chinese_7237698_283:
    old "I don't know if he forgot to tell you, but he said he was meeting a girl to study."
    new "我不知道他有没有告诉你，他说他要去和一个女孩一起学习。"

translate chinese chinese_0576136_284:
    old "Oh right! Damn, I totally forgot about that."
    new "哦对了！靠，我完全忘了这件事。"

translate chinese chinese_6980903_285:
    old "He did say something about it."
    new "他确实提过这件事。"

translate chinese chinese_3358827_286:
    old "Well, I guess I'm gonna have to come back later. Please tell him I came by."
    new "那我只好改天再来吧。请告诉他我来过了。"

translate chinese chinese_4995421_287:
    old "But, wait [pla]!"
    new "但是，等一下[pla]！"

translate chinese chinese_3661748_288:
    old "Y- yes?"
    new "是、是吗？"

translate chinese chinese_7269932_289:
    old "Sweetie it would be a shame if you left just after getting here."
    new "甜心，你刚到就走真是太可惜了。"

translate chinese chinese_1916398_290:
    old "Why don't you stay for a little while?"
    new "你为什么不留下来一会儿呢？"

translate chinese chinese_2995649_291:
    old "You can make me some company."
    new "你可以陪陪我。"

translate chinese chinese_4186133_292:
    old "I actually was about to move around the furniture in my room."
    new "我其实正打算重新摆一下房间里的家具。"

translate chinese chinese_3723653_293:
    old "I could use your help and I thought maybe a big and strong guy like you could help me out."
    new "我需要帮忙，觉得像你这么高大强壮的家伙或许能帮上我。"

translate chinese chinese_0672422_294:
    old "Heh, sure, I can help you out."
    new "嘿嘿，行吧，我可以帮你。"

translate chinese chinese_6092218_295:
    old "Come on up, I'll show you what I need."
    new "上来吧，我给你看看需要什么。"

translate chinese chinese_0898928_296:
    old "Ok, Mrs. White, what do you want me to help you with?"
    new "好的，怀特夫人，你想让我帮你什么？"

translate chinese chinese_2160723_297:
    old "Oh, wow!"
    new "哦，天啊！"

translate chinese chinese_2735645_298:
    old "You see... I figured, since we're alone."
    new "你见了吧……我想既然我们俩单独在一起。"

translate chinese chinese_8779122_299:
    old "Why don't we have a little bit of fun?"
    new "我们来玩一点好玩的怎么样？"

translate chinese chinese_8217385_300:
    old "B- But, Mrs. White, what happens if Mike catches us?"
    new "伯特，但是怀特太太，如果迈克发现我们怎么办？"

translate chinese chinese_6971146_301:
    old "You worry too much."
    new "你太担心了。"

translate chinese chinese_7748617_302:
    old "He won't be home for a while, besides, this is my room. So he won't come in without knocking first."
    new "他一时半会儿不会回来，再说，这是我的房间。所以他不会不敲门就进来。"

translate chinese chinese_2083669_303:
    old "We have time and privacy."
    new "我们有时间和隐私。"

translate chinese chinese_3427778_304:
    old "So don't worry and let's just enjoy."
    new "所以别担心，我们就享受一下吧。"

translate chinese chinese_9532833_305:
    old "I mean, I- I understand what you're saying, but I think it's too risky."
    new "我的意思是，我明白你的想法，但我觉得太冒险了。"

translate chinese chinese_1853902_306:
    old "Oh please, don't act like you don't want it."
    new "哦拜托，别装作你不想。"

translate chinese chinese_5825030_307:
    old "I know you're turned on right now, so come here."
    new "我知道你现在很兴奋，过来。"

translate chinese chinese_2806138_308:
    old "You know, I know you enjoyed dinner last time."
    new "你知道的，上次吃饭你挺享受的。"

translate chinese chinese_3322142_309:
    old "But I'm still not satisfied."
    new "但我还是不满意。"

translate chinese chinese_1209723_310:
    old "I want to taste something a little better."
    new "我想尝点更好东西。"

translate chinese chinese_8496551_311:
    old "Mmm, look at that big cock of yours."
    new "嗯，看看你那大鸡巴。"

translate chinese chinese_7987811_312:
    old "I told you I knew you were getting turned on and very, very hard by the looks of it...."
    new "我跟你说过，我知道你很兴奋，而且看起来非常硬……"

translate chinese chinese_2983191_313:
    old "I've been wanting to taste this big dick since last dinner."
    new "自从上次晚饭后，我就想尝尝这个大鸡巴了。"

translate chinese chinese_8101182_314:
    old "Dude, you were here?"
    new "伙计，你在这里？"

translate chinese chinese_5268894_315:
    old "Yes, he came looking for you, but you weren't home, so I asked him to stay."
    new "是的，他来找你，但你不在家，所以我请他留了下来。"

translate chinese chinese_6430113_316:
    old "Stay? What for?"
    new "留下？留什么留？"

translate chinese chinese_1880426_317:
    old "Uhhh... W- well... you know..."
    new "呃……那个……你知道的……"

translate chinese chinese_9639300_318:
    old "Well, if you remember, there were some stuff in my room that I wanted to move to the attic."
    new "好吧，如果你还记得，我房间里有些东西我想搬到阁楼去。"

translate chinese chinese_0701276_319:
    old "And I've been telling you for a while to help me, but you haven't done anything."
    new "我之前就一直跟你说要帮我，但你什么都没做。"

translate chinese chinese_7429700_320:
    old "So you're friend here was kind enough to help me. You could learn one or two things from him, you know young man?"
    new "所以你这位朋友好心帮我了。你知道吗，小伙子，你可以从他身上学一两招。"

translate chinese chinese_0807168_321:
    old "Hmm, yeah, uh, I forgot about that stuff."
    new "嗯，对啊，哦，那个事情我忘了。"

translate chinese chinese_2023914_322:
    old "... No problem."
    new "……没问题。"

translate chinese chinese_3478497_323:
    old "Well, I have to clean up some things, and start making dinner. So I'll leave you two alone."
    new "好吧，我得收拾一下，开始做饭了。所以你们俩慢慢聊。"

translate chinese chinese_3012762_324:
    old "Thanks again for your help [pla]."
    new "再次感谢你的帮助[pla]。"

translate chinese chinese_6487216_325:
    old "Sure Mrs. White."
    new "好的，怀特夫人。"

translate chinese chinese_5025610_326:
    old "Sorry you had to see that dude."
    new "抱歉让你看到那个家伙。"

translate chinese chinese_5858739_327:
    old "My mom is very annoying, sometimes she won't stop nagging me."
    new "我妈妈很烦人，有时候她会不停地唠叨我。"

translate chinese chinese_5053196_328:
    old "Don't worry about it... My mom's the same."
    new "别担心……我妈妈也一样。"

translate chinese chinese_1178223_329:
    old "Well anyway, come to my room, I have to tell you something."
    new "好吧，来我的房间，我有件事要告诉你。"

translate chinese chinese_2854079_330:
    old "Dudeee! Things went so well with Olivia!"
    new "喂！我和奥利维亚进展得超好！"

translate chinese chinese_8768635_331:
    old "Yeah! She said I helped her a lot and that I'm a very good tutor."
    new "是的！她说我帮了她很多，而且是个非常好的家教。"

translate chinese chinese_8366581_332:
    old "And it's all thanks to you dude. Thank you!"
    new "这全靠你了，兄弟。谢谢！"

translate chinese chinese_3046824_333:
    old "You're welcome man, I'm glad to be able to help."
    new "不客气，能帮上忙我很高兴。"

translate chinese chinese_8326784_334:
    old "So you're gonna keep seeing her?"
    new "所以你还要继续见她？"

translate chinese chinese_4180575_335:
    old "Yeah, but she says she's going to come here next time."
    new "是啊，但她说了下次会来的。"

translate chinese chinese_9032364_336:
    old "Because she says she's embarrassed to be seen with me, so it's better to come here instead."
    new "因为她不好意思被别人看到和我在一起，所以她说来这里比较好。"

translate chinese chinese_0649120_337:
    old "Whoa! What?! That's awful!"
    new "谁啊！什么！那太糟糕了！"

translate chinese chinese_1621267_338:
    old "And you're ok with that?"
    new "你就这么接受了？"

translate chinese chinese_8966528_339:
    old "Sure, why wouldn't I be? That means she wants to spend time with me. right?"
    new "当然，我为什么不呢？那意味着她想花时间陪我，对吧？"

translate chinese chinese_6016076_340:
    old "I mean, that's one way to put it..."
    new "我的意思是，那样说也行……"

translate chinese chinese_4337599_341:
    old "Come on man, she's gonna be here... in my room!"
    new "喂，伙计，她就要来这儿……我的房间了！"

translate chinese chinese_5287981_342:
    old "That's an opportunity to get closer with her!"
    new "这是个接近她的机会！"

translate chinese chinese_7554460_343:
    old "And I don't really care what people think, you know? So what the hell."
    new "而且我根本不在乎别人怎么想，你知道吗？所以管它呢。"

translate chinese chinese_4560160_344:
    old "Well... as long as you're happy."
    new "嗯……只要你开心就好。"

translate chinese chinese_2287169_345:
    old "And you're positive about it. So, sure."
    new "而且你很肯定。所以，好吧。"

translate chinese chinese_7212499_346:
    old "Listen man, I came to help you study, but it's kinda late."
    new "听我说，我是来帮你学习的，但现在已经挺晚了。"

translate chinese chinese_0081798_347:
    old "So, what do you say if we leave it for next time."
    new "那，我们下次再继续怎么样。"

translate chinese chinese_5587378_348:
    old "Besides, you must be tired from studying with Olivia."
    new "再说，和奥莉via学习肯定让你累了。"

translate chinese chinese_8939261_349:
    old "Sure dude, to be honest I was afraid you were gonna say we had to study."
    new "当然了，老实说我还怕你要我说我们要去学习呢。"

translate chinese chinese_4039468_350:
    old "So I'm ok with doing it another time."
    new "所以我下次做也行。"

translate chinese chinese_1927848_351:
    old "Cool, see you later then."
    new "行，那回头见。"

translate chinese chinese_7225448_352:
    old "Later bro."
    new "回头见兄弟。"

translate chinese chinese_7120935_353:
    old "Oh [pla] wait!"
    new "哦 [pla] 等一下！"

translate chinese chinese_0438268_354:
    old "Yes Mrs. White?"
    new "白太太，请问有什么事？"

translate chinese chinese_2732945_355:
    old "It's very late, so I figured you were gonna stay for dinner."
    new "已经很晚了，所以我想你会留下来吃饭的。"

translate chinese chinese_4660359_356:
    old "The food is served already, so you can't say no."
    new "菜都上齐了，你不能拒绝。"

translate chinese chinese_5887489_357:
    old "Oh, all right, thank you."
    new "哦，好吧，谢谢。"

translate chinese chinese_4906369_358:
    old "Do you like today's dinner?"
    new "你喜欢今天的晚餐吗？"

translate chinese chinese_0509683_359:
    old "Yeah, it's very good Mrs. White, thanks a lot."
    new "是的，非常好，怀特夫人，谢谢您。"

translate chinese chinese_9173438_360:
    old "He's right mom, it's really good."
    new "妈妈，他说得对，这真的很好。"

translate chinese chinese_4105521_361:
    old "Excuse me, let me go to the bathroom real quick."
    new "不好意思，我赶紧去一下洗手间。"

translate chinese chinese_8460742_362:
    old "Woah! What are you doing Mrs. White?"
    new "哇！怀特太太你在干什么？"

translate chinese chinese_7660208_363:
    old "We're in the middle of dinner! Mike could come back at any second!"
    new "我们在吃饭呢！迈克随时可能会回来！"

translate chinese chinese_3111185_364:
    old "Oh relax, Mike always takes his time in the bathroom."
    new "别紧张，迈克在浴室总是慢慢悠悠的。"

translate chinese chinese_2575687_365:
    old "I don't know exactly what he does there, but he'll be there for a while."
    new "我不太清楚他在那里做什么，但他会待上一段时间。"

translate chinese chinese_8113931_366:
    old "Still, we're in the dining room..."
    new "不过，我们还在餐厅里……"

translate chinese chinese_9420870_367:
    old "So? Nobody will see us, just enjoy it."
    new "所以呢？没人会看到我们，就享受一下吧。"

translate chinese chinese_6626473_368:
    old "Uhh, Mrs. White you have some... Uhh... In your face..."
    new "呃，怀特夫人，您脸上有点……呃……东西。"

translate chinese chinese_7096644_369:
    old "It's ok honey, [pla] and I had a chance to have a very nice conversation."
    new "没关系亲爱的，我和[pla]有机会进行了一次很好的谈话。"

translate chinese chinese_7938378_370:
    old "Right, [pla]?"
    new "对，[pla]？"

translate chinese chinese_2534607_371:
    old "Mom, why do you have so much mayo all over your face?"
    new "妈妈，你脸上怎么有这么多蛋黄酱？"

translate chinese chinese_2775420_372:
    old "Oh! Heh silly me. I just love the taste of it!"
    new "哦！哈哈，我真傻。我就喜欢它的味道！"

translate chinese chinese_9089572_373:
    old "I know mom, we all know you really like mayo"
    new "我知道妈妈，我们都知道你真的很喜欢蛋黄酱"

translate chinese chinese_1844215_374:
    old "Yeah, mayo. Of course..."
    new "嗯，蛋黄酱。当然了……"

translate chinese chinese_1149002_375:
    old "Once again, it was all very good Mrs. White."
    new "白太太，一切都非常好。"

translate chinese chinese_5366237_376:
    old "Thanks a lot!"
    new "太感谢了！"

translate chinese chinese_9873918_377:
    old "My pleasure sweety, it was good seeing you again."
    new "我的荣幸，甜心，再次见到你真好。"

translate chinese chinese_2052946_378:
    old "And as you could see, I also think everything was delicious..."
    new "就像你看到的，我也觉得一切都很美味……"

translate chinese chinese_1923313_379:
    old "...Sure."
    new "...好吧。"

translate chinese chinese_7933386_380:
    old "Mike, I think I'll head home dude, I'll come back another time to keep studying."
    new "迈克，我想我该回家了，改天再来继续学习。"

translate chinese chinese_9904793_381:
    old "Sure dude, have a good night."
    new "行了兄弟，晚安。"

translate chinese chinese_0239655_382:
    old "And remember to come back soon... You're always welcome."
    new "记得要快点回来……你随时都受欢迎。"

translate chinese chinese_7470486_383:
    old "Uuuh... thank you."
    new "呃……谢谢。"

translate chinese chinese_2730036_384:
    old "Hi Mrs. White, is Mike around?"
    new "白太太，迈克在吗？"

translate chinese chinese_1137409_385:
    old "Hi [pla] is good to see you sweetie."
    new "嗨，[pla]，见到你真好，甜心。"

translate chinese chinese_3184938_386:
    old "Well, Mike is in the house. But I don't think he can see you right now."
    new "迈克在家，但我想他现在可能看不到你。"

translate chinese chinese_4900976_387:
    old "What? Why not?"
    new "什么？为什么不行？"

translate chinese chinese_7431678_388:
    old "Well, he's got some company."
    new "好吧，他不是一个人。"

translate chinese chinese_2772970_389:
    old "A girl came to see him, and they locked themselves in his room."
    new "有个女孩来找他，他们把自己锁在房间里。"

translate chinese chinese_5074387_390:
    old "He told me that I shouldn't bother him or even knock on the door."
    new "他告诉我不要打扰他，甚至不要敲门。"

translate chinese chinese_9708604_391:
    old "Ohh, that's right, he told me Olivia was gonna come today, I don't know how I forgot about it."
    new "哦，对了，他告诉我奥利维亚今天会来，我不知道怎么忘了这事。"

translate chinese chinese_0948828_392:
    old "Ok, then I guess I'll come later, see you Mrs. White."
    new "好的，那我晚点再来吧，再见怀特夫人。"

translate chinese chinese_5717701_393:
    old "Wait a minute!"
    new "等一下！"

translate chinese chinese_4880198_394:
    old "Uhh... yes?"
    new "呃……是吗？"

translate chinese chinese_9543402_395:
    old "How are you leaving after you just arrived? Don't be silly."
    new "刚到就要走？别闹了。"

translate chinese chinese_5946794_396:
    old "You're going to help me move some other boxes in my room."
    new "你要帮我搬房间里的其他箱子。"

translate chinese chinese_7977288_397:
    old "What? What are you talking about? Mike's here!"
    new "什么？你在说什么？迈克在这里！"

translate chinese chinese_9271536_398:
    old "So? They just went up to his room a couple of minutes ago."
    new "所以？他们几分钟前才上去他的房间。"

translate chinese chinese_3172921_399:
    old "How long do you think the study session will last?"
    new "你觉得学习会持续多久？"

translate chinese chinese_3690977_400:
    old "Well... It should take a while, because the subject is a little long."
    new "嗯……这可能需要一段时间，因为这个话题有点长。"

translate chinese chinese_2927142_401:
    old "See? Nothing's going to happen."
    new "看吧？什么都不会发生的。"

translate chinese chinese_7770899_402:
    old "Besides, if they finish early, all I have to do is tell him I'm in my room and don't want him to go in."
    new "再说，如果他们提前结束，我只要告诉他我在房间里不想让他进来就行了。"

translate chinese chinese_7613551_403:
    old "Still, I don't think we..."
    new "不过，我还是觉得我们..."

translate chinese chinese_0975778_404:
    old "Enough talking, you worry too much. Just come with me to the room."
    new "别说了，你 worrying too much. 跟我回房间吧。"

translate chinese chinese_9324434_405:
    old "I know you'll love it."
    new "我知道你会喜欢的。"

translate chinese chinese_8130591_406:
    old "(Oh man, I just fucked my best friend's mom... I can't believe I'm doing this to Mike.)"
    new "（天啊，我刚刚和我最好的朋友的妈妈……我真的不敢相信我在对迈克做这种事。）"

translate chinese chinese_9571751_407:
    old "(Jeez, honestly... I'm ok with helping Mike, but damn, this is getting dangerous.)"
    new "（天啊，真是的……帮忙就算了，但这也太危险了吧。）"

translate chinese chinese_1434448_408:
    old "(I mean, I just can't even imagine what would happen if Mike caught us one day)"
    new "（我是说，我简直不敢想象有一天如果迈克抓到我们会发生什么）"

translate chinese chinese_1457282_409:
    old "Ah! W- What are you doing here?"
    new "啊！你在这里干什么？"

translate chinese chinese_1021419_410:
    old "Uhh... Well, this is my friend's house."
    new "呃……这是我家朋友的屋子。"

translate chinese chinese_2455234_411:
    old "So, I came to see him."
    new "所以，我是来看他的。"

translate chinese chinese_2027705_412:
    old "And you? Did you come to study with him, right? "
    new "那你呢？你是来跟他一起学习的，对吧？"

translate chinese chinese_4546827_413:
    old "I... uhh..."
    new "我……呃……"

translate chinese chinese_8431887_414:
    old "What do you care? I can come and go wherever I want."
    new "你管呢？我想去哪儿就去哪儿。"

translate chinese chinese_3670504_415:
    old "And I'm leaving now!"
    new "我现在就走！"

translate chinese chinese_0845960_416:
    old "By the way! You better not tell anybody about me being here!"
    new "对了！你最好别告诉任何人我在这里！"

translate chinese chinese_2316221_417:
    old "Or you'll hear about me, you got that fucking nerd?"
    new "不然你就等着后悔吧，你这个该死的书呆子听懂了没有？"

translate chinese chinese_7110148_418:
    old "Sure, sure whatever you say."
    new "好吧好吧，随你怎么说。"

translate chinese chinese_3495900_419:
    old "Oh [pla], what's up man? I didn't know you were here."
    new "哦 [pla]，最近怎么样？我都不知道你在这儿。"

translate chinese chinese_8046515_420:
    old "Uh, yeah, I came to see you."
    new "呃，是的，我是来看你的。"

translate chinese chinese_1067290_421:
    old "I forgot that you were going to see Olivia today."
    new "我忘了你今天要去见奥利维亚。"

translate chinese chinese_6007252_422:
    old "By the way, how did it go?"
    new "对了，结果怎么样？"

translate chinese chinese_3914111_423:
    old "Aww man! It was awesome!"
    new "哎呀，太棒了！"

translate chinese chinese_4634742_424:
    old "She said I'm being very helpful."
    new "她说我帮了很大的忙。"

translate chinese chinese_8572507_425:
    old "I'm telling you [pla], I'm winning her over."
    new "我跟你说[pla]，我已经快打动她了。"

translate chinese chinese_2575321_426:
    old "But anyway, we can keep talking about it while we have dinner."
    new "不过话说回来，我们可以边吃饭边继续聊这个。"

translate chinese chinese_7742337_427:
    old "Uh what? Dinner? I- I don't think I can."
    new "啊什么？吃饭？我— 我觉得不行。"

translate chinese chinese_4575451_428:
    old "Come on, you know it's no trouble. My mom will be happy to have you here."
    new "别客气，这没什么麻烦的。我妈妈也很高兴你能来。"

translate chinese chinese_0712350_429:
    old "I'm sure she will. But I promised my mother I would have dinner at our house tonight."
    new "我相信她会的。但是我和妈妈答应今晚在家里吃晚饭。"

translate chinese chinese_1329445_430:
    old "I've been eating out too much, so I can't miss it tonight."
    new "我最近外面吃太多了，今晚不能错过了。"

translate chinese chinese_8563669_431:
    old "Uhh, all right, next time then."
    new "呃，好吧，那下次再说吧。"

translate chinese chinese_0399412_432:
    old "See you later then bud."
    new "那回头见了，伙计。"

translate chinese chinese_3175920_433:
    old "Sure man, see you."
    new "行吧，回头见。"

translate chinese chinese_0207489_434:
    old "Hi [pla] are you two done studying today?"
    new "嗨 [pla]，你们今天学习完了吗？"

translate chinese chinese_5298935_435:
    old "Yes Mrs. White, we just finished."
    new "是的，怀特夫人，我们刚结束。"

translate chinese chinese_4839808_436:
    old "So I figured I should go."
    new "所以我决定走了。"

translate chinese chinese_7659061_437:
    old "Oh don't be silly!"
    new "哎呀，别傻了！"

translate chinese chinese_2971862_438:
    old "I already finished the dinner."
    new "我已经做好晚饭了。"

translate chinese chinese_4828941_439:
    old "And you know I want you to stay."
    new "而且你知道我想要你留下。"

translate chinese chinese_2137593_440:
    old "L- Listen Mrs. White, I already told my mom I was going to have dinner with her and sh..."
    new "L- 听着怀特夫人，我已经告诉我妈妈我要去和她吃晚饭了，而且……"

translate chinese chinese_1983916_441:
    old "I'm sure your mother will understand that I invited you."
    new "我相信你妈妈会理解我邀请你这件事的。"

translate chinese chinese_3403700_442:
    old "Come on. Let's have dinner."
    new "走吧，我们去吃饭。"

translate chinese chinese_7671773_443:
    old "This is really good mom."
    new "这个真不错，妈妈。"

translate chinese chinese_3514541_444:
    old "I don't know what's happened, but you've been making some awesome food these days."
    new "我不知道发生了什么，但你最近做的饭真的很棒。"

translate chinese chinese_2284253_445:
    old "I don't know what you mean by that, my food is always delicious."
    new "我不知道你在说什么，我的菜一向都很好吃。"

translate chinese chinese_9514315_446:
    old "You're going to make your friend think that my cooking is usually bad."
    new "你会让你朋友以为我做饭一般都很难吃。"

translate chinese chinese_3491861_447:
    old "What? Of course not."
    new "什么？当然不是。"

translate chinese chinese_3468286_448:
    old "All I'm saying is the meals are extra special these days."
    new "我只是说最近的饭菜特别好吃。"

translate chinese chinese_7291347_449:
    old "Well, I have to put in some effort, we've been having an extra special guest..."
    new "好吧，我得努力一下了，我们有个特别的客人……"

translate chinese chinese_7932781_450:
    old "Ha! My mom likes you dude."
    new "哈！我妈妈挺喜欢你的。"

translate chinese chinese_1571768_451:
    old "(You have no idea...)"
    new "（你不知道……）"

translate chinese chinese_9535215_452:
    old "I'm just being nice to your friend."
    new "我只不过是对你朋友好一点罢了。"

translate chinese chinese_9469511_453:
    old "Are you enjoying it too [pla]?"
    new "你也很享受吧，[pla]？"

translate chinese chinese_9345168_454:
    old "I like it a lot. It's delicious, thank you."
    new "我非常喜欢，味道很好，谢谢你。"

translate chinese chinese_8511896_455:
    old "By the way [pla], Belle told me to ask you about th..."
    new "对了 [pla]，Belle 让我问你关于那个事..."

translate chinese chinese_3129119_456:
    old "Hold it right there, I'm gonna take this call."
    new "等一下，我接个电话。"

translate chinese chinese_4889617_457:
    old "Oh come on..."
    new "哦，别这样..."

translate chinese chinese_4802543_458:
    old "W- What are you doing Mrs. White?"
    new "你、你在干什么，怀特夫人？"

translate chinese chinese_7324085_459:
    old "What? This is just like last time."
    new "什么？这和上次一样啊。"

translate chinese chinese_4803820_460:
    old "You know he'll take a while."
    new "你知道他要花些时间的。"

translate chinese chinese_5023158_461:
    old "So, we can have a little bit of fun."
    new "所以，我们可以玩一点小花样。"

translate chinese chinese_1819560_462:
    old "No, no, no. This isn't like last time. He only left to pick up a call."
    new "不，不，不是那样的。他只是去接个电话而已。"

translate chinese chinese_2176296_463:
    old "Which means it won't be long."
    new "这意味着不会太久。"

translate chinese chinese_6388020_464:
    old "Mrs. White please stop!"
    new "怀特夫人请停下！"

translate chinese chinese_0244231_465:
    old "Well, I could stop."
    new "好吧，我可以停下来。"

translate chinese chinese_5697233_466:
    old "But this hard dick tells me you want me to do it anyway."
    new "但这个硬棒告诉我，你还是想让我做。"

translate chinese chinese_9217566_467:
    old "Just relax, it won't take long."
    new "放松点，很快就好。"

translate chinese chinese_9807346_468:
    old "Where did my mom go?"
    new "我妈妈去哪儿了？"

translate chinese chinese_3263070_469:
    old "Uhhh... S- she went to the... bathroom. Yeah, she said she needed to go."
    new "呃……她去……洗手间了。对，她说她得去。"

translate chinese chinese_5605455_470:
    old "But I came from there, and I didn't see her enter."
    new "但我从那边过来的，没看到她进去。"

translate chinese chinese_4550367_471:
    old "She... must be using the one in her bedroom."
    new "她……肯定是在卧室里用的那个。"

translate chinese chinese_0485212_472:
    old "I think she went upstairs."
    new "我觉得她上楼了。"

translate chinese chinese_7253832_473:
    old "Hmm."
    new "嗯。"

translate chinese chinese_5879023_474:
    old "Yeah you're right."
    new "嗯，你说得对。"

translate chinese chinese_4790055_475:
    old "(Damn, I can't believe she actually gave me a blowjob and made me cum with Mike here!)"
    new "（真他妈的，没想到她真的给我口交了，还让我在这里面射了！）"

translate chinese chinese_7850360_476:
    old "(I need to think about something or Mike will really catch us.)"
    new "（我得想个理由，不然迈克真的会发现我们的。）"

translate chinese chinese_6248945_477:
    old "You know what Mike? I think I could really use a headache pill."
    new "迈克，你知道吗？我觉得我真的需要一颗止痛药。"

translate chinese chinese_8481325_478:
    old "If you have anything here that I could take it would be good."
    new "如果你这里有什么我可以拿走的东西就太好了。"

translate chinese chinese_9630150_479:
    old "Hmm, let me check the cabinet in the bathroom."
    new "嗯，让我去浴室的柜子里看看。"

translate chinese chinese_4877647_480:
    old "A headache? That was a good idea."
    new "头痛？这个主意不错。"

translate chinese chinese_6154093_481:
    old "Why are you so chirpy? I told you he was going to come back!"
    new "你为什么这么高兴？我告诉过你他会回来的！"

translate chinese chinese_5795928_482:
    old "Awww, my baby boy was scary, don't worry sweetie."
    new "哎呀，我宝贝儿子好吓人啊，别担心，甜心。"

translate chinese chinese_5883453_483:
    old "Next time I see you I'll give you something in return for this."
    new "下次见到你，我会给你点东西作为回报。"

translate chinese chinese_3356463_484:
    old "Hmph, this isn't about that."
    new "哼，这不关那事。"

translate chinese chinese_2697687_485:
    old "Sorry dude, we don't have anything like that."
    new "抱歉伙计，我们没有那样的东西。"

translate chinese chinese_2987290_486:
    old "Mom, you're back."
    new "妈妈，你回来了。"

translate chinese chinese_9467183_487:
    old "I thought you had gone to sleep."
    new "我还以为你睡了呢。"

translate chinese chinese_2519486_488:
    old "Oh no, it's just that I had to go to the bathroom. But I came back to finish my dinner."
    new "哦不，我只是去了一下洗手间。但我回来继续吃晚饭了。"

translate chinese chinese_5769068_489:
    old "By the way, you should finish yours too, before it gets cold."
    new "对了，你也赶紧吃完，别凉了。"

translate chinese chinese_8130912_490:
    old "I know, I know, I was just getting a pill for [pla], where do we keep then?"
    new "我知道，我知道，我刚才只是去拿[pla]的药片，我们把药片放在哪里了？"

translate chinese chinese_7423304_491:
    old "You know what, dude?"
    new "你知道吗，伙计？"

translate chinese chinese_5161000_492:
    old "I don't think I'll need it, the headache is gone."
    new "我觉得我不需要了，头痛已经消失了。"

translate chinese chinese_6538978_493:
    old "Yeah, all you needed was to relax and release everything as Mike said."
    new "是啊，你只需要放松，像迈克说的那样释放一切。"

translate chinese chinese_0593374_494:
    old "Yeah, that's what I sai-... Wait how do you know-"
    new "是啊，我说的就是这个... 等等，你怎么知道的？"

translate chinese chinese_8726584_495:
    old "Oh, honey, I'm really hungry and the food is gonna get cold. Why don't we finish this delicious dinner?"
    new "哦，亲爱的，我真的很饿，饭菜要凉了。我们不如把这顿美味的晚餐吃完吧？"

translate chinese chinese_6198105_496:
    old "Yeah, dude, just enjoy the dinner."
    new "yeah，伙计，就享受晚餐吧。"

translate chinese chinese_5023836_497:
    old "As always Mrs. White, your food is always the best."
    new "白太太，您的厨艺一如既往地好。"

translate chinese chinese_6596589_498:
    old "It's very good that you always enjoy... Everything I give you sweety."
    new "你总是享受……我给你的每一样东西，甜心，这真是太好了。"

translate chinese chinese_0841176_499:
    old "It always makes me want to give you some more..."
    new "这总是让我想再给你一些……"

translate chinese chinese_5380055_500:
    old "Uh... yeah, thank you."
    new "呃……是的，谢谢。"

translate chinese chinese_9578061_501:
    old "Well, it's very late, so I shold go now."
    new "好吧，现在已经很晚了，我应该走了。"

translate chinese chinese_9564970_502:
    old "Sure man, no problem. Thanks for today."
    new "行，没问题。谢谢今天的陪伴。"

translate chinese chinese_5909051_503:
    old "Hi Mrs.White, how are you?"
    new "嗨，怀特夫人，你好吗？"

translate chinese chinese_0079162_504:
    old "Hi sweetie, I'm very well, thank you."
    new "嗨甜心，我很好，谢谢。"

translate chinese chinese_5314636_505:
    old "Let me guess, you came to study with Mike again."
    new "让我猜猜，你是来找迈克学习的吧。"

translate chinese chinese_5058369_506:
    old "Yeah, is he here?"
    new "嗯，他在吗？"

translate chinese chinese_0080220_507:
    old "I'm sorry, but he isn't, he went out with that girl Olivia."
    new "对不起，他没在这里，他和那个女孩奥利维亚出去了。"

translate chinese chinese_9353992_508:
    old "Hmm... I see."
    new "嗯……我明白了。"

translate chinese chinese_6738332_509:
    old "I suppose I should come later then, right?"
    new "那我晚点再来吧？"

translate chinese chinese_9921322_510:
    old "Oh, why do you ask that when you already know the answer?"
    new "哦，你明明知道答案还问这个干什么？"

translate chinese chinese_6068859_511:
    old "No my sweet boy, you're not going anywhere."
    new "不，我的甜心，你哪儿也不要去。"

translate chinese chinese_3492942_512:
    old "We're going to finish what we started the other night at dinner."
    new "我们要把上次晚饭时开始的事情做完。"

translate chinese chinese_6629180_513:
    old "Come here sweetie, I want you right now."
    new "过来宝贝，我现在就要你。"

translate chinese chinese_4692655_514:
    old "What? Here?"
    new "什么？这里？"

translate chinese chinese_9756629_515:
    old "Sure! Why not? We're alone and Mike will take his time."
    new "当然可以！有什么关系？我们这儿没人，迈克还要一会儿才来。"

translate chinese chinese_9760686_516:
    old "B- but... I- I mean, he could come back early... or he could"
    new "B-但是……我意思是，他可能会早回来……或者他可能会"

translate chinese chinese_0879806_517:
    old "That's enough, Mike doesn't even suspect a thing and you're always worrying."
    new "够了，迈克根本就没起疑心，你总是瞎担心。"

translate chinese chinese_9695367_518:
    old "So stop thinking so much and just get naked."
    new "所以别想那么多，直接脱光就行了。"

translate chinese chinese_5597486_519:
    old "I want that big cock now!"
    new "我现在就要那个大 cock！"

translate chinese chinese_2143669_520:
    old "Ah yes! Look at how hard you already are."
    new "啊，没错！看看你已经硬成这样了。"

translate chinese chinese_1826735_521:
    old "That big long dick."
    new "那根大鸡巴。"

translate chinese chinese_8144424_522:
    old "I want you to put in me."
    new "我想让你进入我体内。"

translate chinese chinese_2895277_523:
    old "I can't wait!"
    new "我等不及了！"

translate chinese chinese_2716763_524:
    old "Hi Mrs. White. It's good seeing you again."
    new "白太太，很高兴又见到您。"

translate chinese chinese_5420695_525:
    old "Hi sweety, are you here to see Mike?"
    new "嗨甜心，你是来看迈克的吗？"

translate chinese chinese_6703139_526:
    old "Well, I'm sorry to tell you that he's not available."
    new "好吧，我不得不告诉你他不在。"

translate chinese chinese_9613236_527:
    old "That girl Olivia came a while ago, and he was very clear that they shouldn't be interrupted."
    new "那个女孩奥利维亚之前来了，他很清楚他们不想被打扰。"

translate chinese chinese_9567417_528:
    old "But don't be sad, because you know what that means."
    new "但不要难过，因为你知道这意味着什么。"

translate chinese chinese_0570703_529:
    old "It means you and I get to have some fun."
    new "这意味着你可以和我一起玩了。"

translate chinese chinese_3036190_530:
    old "What?! Are you kidding me?!!"
    new "什么?! 你在开玩笑吗?!!"

translate chinese chinese_2741369_531:
    old "After what happened last time. You still want to do it?!"
    new "上次发生那种事之后，你还想再来一次？！"

translate chinese chinese_3513175_532:
    old "Aww, my baby boy is worried."
    new "哎呀，我的小宝贝担心起来了。"

translate chinese chinese_2633015_533:
    old "Don't worry, this time we'll do it in my bedroom, so what happened last time won't happen again."
    new "别担心，这次我们在我的卧室里做，上次的事情不会再发生了。"

translate chinese chinese_2941759_534:
    old "Hmm, but what happens if they finish before us and they hear us?"
    new "嗯，但如果他们提前结束然后听到我们怎么办？"

translate chinese chinese_4183953_535:
    old "I mean... How long have they been up there?"
    new "我的意思是……他们上去多久了？"

translate chinese chinese_8672494_536:
    old "Hmm, to be honest I didn't really look at the clock."
    new "嗯，说实话，我根本没看时间。"

translate chinese chinese_5987911_537:
    old "I don't think we should do anything without knowing how long they'll be there."
    new "我觉得在不知道他们会待多久的情况下，我们不应该采取任何行动。"

translate chinese chinese_2721992_538:
    old "You're thinking too much, just relax a little."
    new "你想太多啦，放松一点。"

translate chinese chinese_6863184_539:
    old "I can't, after what happened last time, we need to be sure... And I have an idea."
    new "我不能，上次的事情之后，我们需要确定……而且我有个想法。"

translate chinese chinese_6561257_540:
    old "Let me go upstairs and check on them first."
    new "让我先上去看看他们。"

translate chinese chinese_7972723_541:
    old "Hmm, ok. Do that and let me know."
    new "嗯，好的。去做吧，然后告诉我一声。"

translate chinese chinese_4397709_542:
    old "Damn, I didn't think Mike and Olivia were really going to do anything."
    new "真没想到迈克和奥利维亚真的会采取行动。"

translate chinese chinese_2843888_543:
    old "Well, I guess all that work really paid off. I'm happy for him."
    new "嗯，我想所有的努力终于有了回报。我为他高兴。"

translate chinese chinese_3553653_544:
    old "So? What topic are they on?"
    new "所以？他们在聊什么话题？"

translate chinese chinese_2728103_545:
    old "Hmm, let's just say they'll be busy for a while."
    new "嗯，这么说吧，他们有一阵子忙的了。"

translate chinese chinese_6143859_546:
    old "So, I think we'll be fine."
    new "所以，我觉得我们会没事的。"

translate chinese chinese_8079504_547:
    old "Really? Perfect! Let's go to my room then!"
    new "真的吗？太好了！那我们去我的房间吧！"

translate chinese chinese_6885891_548:
    old "Whoa! Whoa! Whoa!"
    new "谁啊！谁啊！谁啊！"

translate chinese chinese_9953936_549:
    old "Fuck! She saw us, I have to go after her!"
    new "操！她看到我们了，我得去追她！"

translate chinese chinese_8391198_550:
    old "Olivia! Wait!"
    new "奥利维亚！等一下！"

translate chinese chinese_3988632_551:
    old "Dude! What the fuck!"
    new "喂！你在搞什么！"

translate chinese chinese_7917694_552:
    old "You're fucking your friend's mother?! What the fuck is wrong with you."
    new "你在和朋友的妈妈乱搞?! 你他妈的是怎么了。"

translate chinese chinese_6917035_553:
    old "It's not what you think! We're just..."
    new "不是你想的那样！我们只是……"

translate chinese chinese_6886021_554:
    old "You're just what? I saw you dude!"
    new "你刚才说什么？我看见你了！"

translate chinese chinese_8345513_555:
    old "I saw your big coc-... your penis hanging out, and jizz everywhere."
    new "我看到你的大鸡巴漏出来了，而且到处都是精液。"

translate chinese chinese_9761085_556:
    old "Ok, listen, I was doing that, but please you can't tell Mike."
    new "好吧，听我说，我在做那个，但拜托你不要告诉迈克。"

translate chinese chinese_8931028_557:
    old "Please! I'm begging you! He'll never forgive me!"
    new "求你了！我求求你！他永远不会原谅我的！"

translate chinese chinese_3474471_558:
    old "Well, maybe you should've thought about that before fucking his mom."
    new "那你在操他妈妈之前就应该想好了。"

translate chinese chinese_9773839_559:
    old "Oh, come on! You wouldn't get anything by telling him that!"
    new "哦，拜托！你那样告诉他也没用啊！"

translate chinese chinese_1203512_560:
    old "Perhaps I would, who knows?"
    new "也许我会，谁知道呢？"

translate chinese chinese_7048612_561:
    old "I guess you would be willing to do anything in exchange for me not telling him anything, right?"
    new "我想你应该愿意做任何事来换我什么都不告诉他，对吧？"

translate chinese chinese_9248189_562:
    old "Right?!!!!"
    new "对吧？！！！"

translate chinese chinese_4685306_563:
    old "I would, I would, I'd do anything, just please don't tell Mike."
    new "我会的，我会的，我什么都愿意做，只要别告诉迈克。"

translate chinese chinese_6520352_564:
    old "Listen, I'm leaving now, I can't waste my time on you."
    new "听着，我现在要走了，没时间浪费在你身上。"

translate chinese chinese_7734739_565:
    old "I'm not going to tell him anything... For now."
    new "我不会告诉他任何事情的……至少现在不会。"

translate chinese chinese_3313681_566:
    old "We'll see if that changes later."
    new "看看后来会不会有变化。"

translate chinese chinese_1765337_567:
    old "Oh, gosh, I'm fucked.."
    new "哦，糟了，这下完了.."

translate chinese chinese_8759996_568:
    old "(Damn it! She just saw me fucking my best friends mom!)"
    new "（该死！她刚才看到我跟我最好的朋友的妈妈在一起！）"

translate chinese chinese_3239676_569:
    old "(I have to do something...)"
    new "（我得做点什么...）"

translate chinese chinese_4467943_570:
    old "(I have to try and convince her someway not to tell Mike.)"
    new "（我得想办法说服她不要告诉迈克。）"

translate chinese chinese_5470933_571:
    old "Hey man, what's up?"
    new "嘿，哥们，最近怎么样？"

translate chinese chinese_6863125_572:
    old "Did you run into Olivia again?"
    new "又碰到奥利维亚了？"

translate chinese chinese_1154641_573:
    old "Uhh, yeah... Sorry dude."
    new "呃，是啊……对不起兄弟。"

translate chinese chinese_0433497_574:
    old "It's ok dude."
    new "没事兄弟。"

translate chinese chinese_7102568_575:
    old "I already talked to her about it."
    new "我已经和她谈过了。"

translate chinese chinese_5136731_576:
    old "I told her that you've been helping me. So don't worry, we're fine."
    new "我告诉她你一直在帮我。所以不用担心，我们没事。"

translate chinese chinese_3403610_577:
    old "I see... well, that's very cool dude."
    new "我明白了……嗯，挺酷的。"

translate chinese chinese_0234121_578:
    old "Yeah... I guess it is."
    new "嗯……我想是的。"

translate chinese chinese_8255324_579:
    old "Hey man, listen, today is a little late, so how about we study another time?"
    new "喂，听我说，今天有点晚了，要不我们改天再学习吧？"

translate chinese chinese_2900695_580:
    old "Actually, we don't have to do that for now."
    new "实际上，我们现在不需要做那个。"

translate chinese chinese_7691034_581:
    old "Really? Why?"
    new "真的吗？为什么？"

translate chinese chinese_3758563_582:
    old "Olivia's going on a trip."
    new "奥利维亚要去旅行。"

translate chinese chinese_2109307_583:
    old "She's going to be out of time for a while."
    new "她暂时没时间。"

translate chinese chinese_0924706_584:
    old "So I don't think you don't have to worry for now."
    new "所以我觉得你现在不用担心。"

translate chinese chinese_6145105_585:
    old "That's a relief, I gues..."
    new "这样就好多了，我猜..."

translate chinese chinese_6373755_586:
    old "I- I mean... I see... Um, sorry dude. That sucks."
    new "我——我的意思是……我懂了……啊，对不起，那真糟糕。"

translate chinese chinese_2960010_587:
    old "Are you kidding me? Dude, it has been awesome spending time with her."
    new "你开玩笑吧？和她在一起真的很棒。"

translate chinese chinese_8606410_588:
    old "And I know for a fact that she likes me."
    new "而且我确信她喜欢我。"

translate chinese chinese_5005291_589:
    old "So, I'm sure I'll see her again when this is over."
    new "所以，我相信这事结束后我还会再见到她的。"

translate chinese chinese_6520152_590:
    old "So am I..."
    new "我也是..."

translate chinese chinese_7585111_591:
    old "[pla]! Did you talk to her? What did she say?"
    new "[pla]！你跟她说话了吗？她说什么了？"

translate chinese chinese_9962253_592:
    old "Yeah, I did Mrs. White, and I know you're worried about that."
    new "是的，我和怀特太太那个了，我知道你为此担心。"

translate chinese chinese_1319448_593:
    old "But she said she wasn't going to tell anything to him."
    new "但她说了不会告诉他任何事情的。"

translate chinese chinese_7949089_594:
    old "At least for now..."
    new "至少现在是这样的..."

translate chinese chinese_5943126_595:
    old "I don't know, what if she tells him? He's going to kill me!"
    new "我不知道，要是她告诉他了怎么办？他肯定会杀了我的！"

translate chinese chinese_9287362_596:
    old "Hey, it's ok, let me handle it. Ok?"
    new "嘿，没事，让我来处理好吗？"

translate chinese chinese_7568892_597:
    old "Ok, I trust you."
    new "好吧，我相信你。"

translate chinese chinese_8722581_598:
    old "Listen, it's very late already, and my mom wants me to eat with her."
    new "听着，已经很晚了，我妈妈想让我跟她一起吃饭。"

translate chinese chinese_2121632_599:
    old "So I'll be on my way home, and I'll see you later."
    new "那我就回家了，回头见。"

translate chinese chinese_6730057_600:
    old "Just try not to worry too much and just let me handle this. Ok?"
    new "just try not to worry too much and just let me handle this. ok?\n\n尽量别想太多，让我来处理这件事，好吗？"

translate chinese chinese_6808595_601:
    old "Ok, ok, I'll try not to think about it."
    new "好啦好啦，我尽量不去想它。"

translate chinese chinese_9179549_602:
    old "Bye. I'll see you later baby boy."
    new "拜拜。一会儿见，小宝贝。"

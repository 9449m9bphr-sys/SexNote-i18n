# auto-tl Qwen Colab

translate chinese chinese_3177226_0:
    old "Good morning honey."
    new "早安，亲爱的。"

translate chinese chinese_2050654_1:
    old "Oh! good morning [mo1rel]."
    new "哦！早上好，[mo1rel]。"

translate chinese chinese_9029290_2:
    old "Did you have a good night?"
    new "你昨晚睡得好吗？"

translate chinese chinese_2328283_3:
    old "Yeah, I did. And you?"
    new "是的，我做了。你呢？"

translate chinese chinese_7526022_4:
    old "I did hun, thank you."
    new "我已经做了，谢谢。"

translate chinese chinese_7016527_5:
    old "Is there anything I can help you with [mo1rel]?"
    new "有什么我可以帮到你的吗，[mo1rel]？"

translate chinese chinese_2805883_6:
    old "Well, not really. I just wanted to see if you're doing anything with your friends for halloween."
    new "嗯，也不是。我只是想看看你万圣节有没有和朋友一起做什么计划。"

translate chinese chinese_2431684_7:
    old "Oh that's right! It's today! I'd totally forgotten about it."
    new "哦对了！就是今天！我完全忘了。"

translate chinese chinese_0450735_8:
    old "That reminds me, I need to pick up my costume."
    new "对了，我得去拿我的 cosplay 服装。"

translate chinese chinese_9164713_9:
    old "Are you going to school in a costume?"
    new "你打算穿 cosplay 去学校吗？"

translate chinese chinese_1419579_10:
    old "Yeah, me and my friends are dressing up for Halloween."
    new "嗯，我和朋友们准备去参加万圣节化妆舞会。"

translate chinese chinese_3857640_11:
    old "Really? Why? Are you having a party?"
    new "真的吗？为什么？你在开派对吗？"

translate chinese chinese_9907015_12:
    old "No, no, nothing special like that. It's just that the school principal said all students get to wear costumes today."
    new "不，不，没什么特别的。只是校长说今天所有学生都可以穿 cosplay 服装。"

translate chinese chinese_3584687_13:
    old "Seriously? That's cool."
    new "seriously? 那挺酷的。"

translate chinese chinese_6272666_14:
    old "Yeah, it's nice we get to do this once in a while. Everyone's excited about it."
    new "是啊，偶尔能这样做挺好的。大家都对此很兴奋。"

translate chinese chinese_2423627_15:
    old "Well [pla], that sounds like a lot of fun. I'm happy you get to do that with your friends."
    new "好吧 [pla]，听起来很有趣。很高兴你能和朋友们一起做这件事。"

translate chinese chinese_1157786_16:
    old "After all, this is your last Halloween at school, where you still get to dress up, so make sure to enjoy it."
    new "毕竟，这是你在学校的最后一个万圣节，还能打扮一番，所以一定要好好享受。"

translate chinese chinese_8362991_17:
    old "Yeah, I'll do. We're competing about who has the worst costume."
    new "好吧，我参加。我们在比谁的 cosplay 最差。"

translate chinese chinese_4363619_18:
    old "And do you have one already?"
    new "那你已经有了吗？"

translate chinese chinese_3497157_19:
    old "Yeah, I asked Kylee to get one for me. I should ask her if it's already arrived. Bye [mo1rel], see you later."
    new "嗯，我让凯莉帮我买一个。我应该问问她是不是已经到了。再见[mo1rel]，回头见。"

translate chinese chinese_3637491_20:
    old "Bye honey, have a good day."
    new "拜拜宝贝，祝你今天愉快。"

translate chinese chinese_6754961_21:
    old "Hi [sis], good morning."
    new "你好 [sis]，早上好。"

translate chinese chinese_4968473_22:
    old "Hi [pla], good morning. How are you?"
    new "你好 [pla]，早上好。怎么样？"

translate chinese chinese_6096286_23:
    old "I'm fine. Hey, I just remembered I asked you to get my costume for Halloween. Did it arrive?"
    new "我挺好的。对了，我想起来了，我让你帮我买的万圣节 cosplay 服装到了吗？"

translate chinese chinese_5593598_24:
    old "Yeah, it did. It came in with the last shipment of clothing for the store."
    new "是的，它是和上次店铺进货的衣服一起到的。"

translate chinese chinese_0846703_25:
    old "Great! Where is it?"
    new "太好了！在哪里？"

translate chinese chinese_1037020_26:
    old "Hmm... I haven't unpacked anything yet, so it must be in one of the boxes."
    new "嗯……我还没拆任何箱子，所以肯定在其中一个箱子里。"

translate chinese chinese_3591370_27:
    old "Just wait here a minute. I'll go get it for you."
    new "你就在这里等一会儿，我去给你拿。"

translate chinese chinese_7759833_28:
    old "Here you go."
    new "给你。"

translate chinese chinese_5049968_29:
    old "This is great! Thanks [sis]."
    new "太好了！谢谢[sis]。"

translate chinese chinese_1513989_30:
    old "Well, you go try it on and let me know if it fits you, and you like it."
    new "那你去试试看，合适不合适、喜不喜欢告诉我一下。"

translate chinese chinese_3084938_31:
    old "Of course, by the way, how much do I owe you?"
    new "对了，我欠你多少？"

translate chinese chinese_0637964_32:
    old "Oh, don't worry about it..."
    new "哦，别担心……"

translate chinese chinese_6186066_33:
    old "It's on the house."
    new "算我请的。"

translate chinese chinese_4529094_34:
    old "Oh really? Well... Thank you [sis]."
    new "哦真的吗？那么……谢谢你[sis]。"

translate chinese chinese_3484917_35:
    old "Now leave, I have a lot of work to do."
    new "现在走吧，我还有很多工作要做。"

translate chinese chinese_7022677_36:
    old "Ok, I'll go try on the costume then. See you later [sis], thanks again."
    new "好的，那我去试穿一下这套服装。[sis]，待会儿见，再次感谢。"

translate chinese chinese_4406230_37:
    old "You're welcome and enjoy it."
    new "不客气，尽情享受吧。"

translate chinese chinese_4086804_38:
    old "Wow! This is so cool! [sis] has some really good products."
    new "哇！这真是太酷了！[sis] 的产品真的很棒。"

translate chinese chinese_4709627_39:
    old "I think I'll definitely blow their minds with this."
    new "我觉得这肯定能让他们大吃一惊。"

translate chinese chinese_8665288_40:
    old "Now I'm ready for Halloween!"
    new "现在我准备好过万圣节了！"

translate chinese chinese_8867713_41:
    old "Hey guys, what 's up?"
    new "嘿，大家，最近怎么样？"

translate chinese chinese_0849222_42:
    old "Whooa [pla]! What a costume!"
    new "哇[pla]！这身打扮真棒！"

translate chinese chinese_2982211_43:
    old "Cool, isn't it?"
    new "酷吧？"

translate chinese chinese_1135184_44:
    old "It looks very good."
    new "看起来很不错。"

translate chinese chinese_8856647_45:
    old "Yeah dude, really cool."
    new "yeah 哥们，真的很酷。"

translate chinese chinese_8937929_46:
    old "But to be honest, not as cool as mine."
    new "但老实说，没有我的酷。"

translate chinese chinese_2053075_47:
    old "Really? And why is that?"
    new "真的吗？那为什么呢？"

translate chinese chinese_6380483_48:
    old "Because I'm Iron Man, I mean... Come on!"
    new "因为我就是铁人啊，我说的是…… 快点吧！"

translate chinese chinese_5352864_49:
    old "I'm the super rich, genius, chick magnet! No way Spiderman beats that."
    new "我是超级有钱、天才、磁吸妹！蜘蛛侠可比不了我。"

translate chinese chinese_2808570_50:
    old "It actually is a cool Iron Man costume... Even the goatee."
    new "这确实是个酷炫的钢铁侠战衣……连胡子都一样。"

translate chinese chinese_1124908_51:
    old "Hmph, I guess."
    new "哼，大概吧。"

translate chinese chinese_9388428_52:
    old "And you Belle? Are you like a type of rabbit?"
    new "那你贝尔呢？你是某种兔子吗？"

translate chinese chinese_9478459_53:
    old "Not a type of rabbit. I'm a bunny, the coolest one, Lola Bunny!"
    new "不是一种兔子。我是兔女郎，最酷的那个，洛拉兔女郎！"

translate chinese chinese_1932667_54:
    old "Ohh right. I get it now."
    new "哦，对了。我现在明白了。"

translate chinese chinese_2934890_55:
    old "Cool costume, it looks really good on you."
    new "挺酷的 cosplay，穿在你身上真好看。"

translate chinese chinese_4765019_56:
    old "Oh my, Olivia, would you look at that? The loser club in their dumb costumes. Aren't they childish?"
    new "哦我的天，奥利维亚，你看那是什么？那些loser俱乐部的人穿着他们愚蠢的服装。他们不是太幼稚了吗？"

translate chinese chinese_4195008_57:
    old "Yeah, always acting like little kids. Dumb, poor kids."
    new "是啊，总是像小孩子一样行事。真是可怜又愚蠢的孩子们。"

translate chinese chinese_1944826_58:
    old "Don't you two airheads have anything better to do this early in the morning?"
    new "你们两个傻瓜早上没事干吗不做点别的？"

translate chinese chinese_0919884_59:
    old "Better than showing you just how much of a dumbass you are? Don't think so."
    new "这比让你知道你有多蠢强多了吧？别这么想。"

translate chinese chinese_5051631_60:
    old "By the way, are you supposed to be Lola Bunny?"
    new "对了，你是洛拉兔吗？"

translate chinese chinese_1560383_61:
    old "Y-yeah, I am. Why?"
    new "嗯，我是。为什么？"

translate chinese chinese_7426623_62:
    old "Dear, you should realize that with those ears, and that pig nose of yours, you're much more of a Piglet."
    new "亲爱的，你应该意识到，有了那对耳朵和那个猪鼻子，你更像是个小猪猡。"

translate chinese chinese_7695093_63:
    old "Hey! Don't you think that's too much?"
    new "喂！你不觉得这太过分了吗？"

translate chinese chinese_7430290_64:
    old "That's right. Shut up!"
    new "没错。闭嘴！"

translate chinese chinese_6705905_65:
    old "Wow Olivia, look who's defending Piglet! Spiderman the scrawny loser, and Iron fat."
    new "哇，奥利维亚，看看谁在替小猪侠辩护！瘦弱的loser蜘蛛侠，还有铁憨憨。"

translate chinese chinese_1574090_66:
    old "What's funny is that they're opposites. One is too slim to fill his Spiderman pajamas, and the other's too fat to fit into the costume."
    new "有趣的是他们完全相反。一个瘦得连蜘蛛侠睡衣都撑不起来，另一个胖得穿不下那套衣服。"

translate chinese chinese_0534731_67:
    old "Hey Iron Man, don't you think it's ridiculous that your belly's rounder than your chest?"
    new "嘿，铁 man，你不觉得你的肚子比胸部还要圆吗？"

translate chinese chinese_0011067_68:
    old "Maybe we should call him barrel man."
    new "也许我们应该叫他桶男。"

translate chinese chinese_5882693_69:
    old "Hey guys! What's up? It's everything ok?"
    new "嘿大家！最近怎么样？一切都好吗？"

translate chinese chinese_5565873_70:
    old "Ohh wow. What a costume..."
    new "哦哦，好厉害。这身衣服……"

translate chinese chinese_6206034_71:
    old "My god! And what the hell are you wearing? You look like a WHORE."
    new "天啊！你穿的这是什么？你看起来像个妓女。"

translate chinese chinese_6931420_72:
    old "The stupid cow came dressed up like a bat-whore."
    new "那个蠢女人打扮得像什么蝙蝠婊子一样。"

translate chinese chinese_8921038_73:
    old "Hey! It's not a whore costume. I'm Morrigan from Darkstalkers. And for your information this took a lot of time to make..."
    new "喂！这可不是妓女装，我是《暗魂街》里的莫莉甘。而且告诉你，这个花了我好多时间才做出来的……"

translate chinese chinese_9180859_74:
    old "Ughh nerd... I don't care..."
    new "哎呀书呆子……我不在乎……"

translate chinese chinese_5158308_75:
    old "I am only surprised that the shy moron I see here every day would bring such a revealing costume."
    new "我没想到平时见到的这个害羞白痴会穿这么暴露的 cosplay。"

translate chinese chinese_2462544_76:
    old "Which by the way, it's disgusting."
    new "话说这真的挺恶心的。"

translate chinese chinese_2261731_77:
    old "I mean, you couldn't wear ANYTHING more revealing! My god! You should be ashamed!"
    new "我说，你不能再穿得更暴露了！天啊！你应该感到羞耻！"

translate chinese chinese_1297531_78:
    old "W- what are you talking about? Your costume has also a cleavage..."
    new "你、你在说什么？你的服装也有 декольте..."

translate chinese chinese_3205127_79:
    old "WHAT? YOU'VE GOTTA BE KIDDING ME!"
    new "什么？你在开玩笑吧！"

translate chinese chinese_5912223_80:
    old "We have decent classy costumes, there's nothing wrong with ours."
    new "我们的服装挺不错的，没什么问题。"

translate chinese chinese_0293731_81:
    old "In case you haven't noticed, Olivia and I are Disney princesses..."
    new "你可能没注意到，奥利维亚和我是迪士尼公主……"

translate chinese chinese_1082278_82:
    old "While you just came in a stupid costume from some nerd stuff."
    new "而你只是穿了个愚蠢的 cosplay 服装。"

translate chinese chinese_9604438_83:
    old "Well, I don't care, because I really have something to show and I feel comfortable with my body, unlike you two stupid bitches..."
    new "好吧，我不在乎，因为我真的有东西要展示，而且我对自己的身体很自信，不像你们两个蠢货……"

translate chinese chinese_2284688_84:
    old "W- what did you just say to me?! Olivia! Did you hear that?!!"
    new "你刚刚说什么?! 奥利维亚！你听到那句话了吗!!"

translate chinese chinese_1680316_85:
    old "I did Ruby! How dare you talk to us like that? You bat-whore!"
    new "我做了Ruby！你怎么敢这么跟我们说话？你这个贱货！"

translate chinese chinese_8571564_86:
    old "Shut up you two! You envious bitches!"
    new "你们俩闭嘴！你们这两个嫉妒的女人！"

translate chinese chinese_9731424_87:
    old "Ohhhh! What's the matter, girls? You can dish it, but you can't take it?"
    new "哦呵！怎么了，姑娘们？你们能说但不能听？"

translate chinese chinese_8556835_88:
    old "H-Hey, Hinn, maybe it's best if we just leave, look, classes are about to start..."
    new "嘿，希恩，也许我们还是走吧，你看，快上课了..."

translate chinese chinese_3583544_89:
    old "And why do we have to be the ones to leave?! These idiots are the ones who started."
    new "而且为什么非要我们走？这些蠢货才是先开始的。"

translate chinese chinese_9809992_90:
    old "You two better get out here! I've had enough of your bullshit!"
    new "你们两个给我出来！我受够你们的 bullshit 了！"

translate chinese chinese_8503306_91:
    old "Ughh. We're leaving! But it's not because you tell us to, you little whore! I just don't want to keep wasting my time with you, dumbasses."
    new "呃。我们走！但这可不是因为你叫我们走的，你这个小贱人！我只是不想再浪费时间在你们这些白痴身上。"

translate chinese chinese_4963258_92:
    old "Let 's go Olivia."
    new "走吧，奥利维亚。"

translate chinese chinese_9565586_93:
    old "Wow! Hinn, what's happened to you? That was sooo awesome!"
    new "哇！hin，你怎么了？这也太酷了吧！"

translate chinese chinese_5229721_94:
    old "Hehe, you think so?"
    new "嘿嘿，你觉得是这样？"

translate chinese chinese_8383932_95:
    old "Hell yeah! I don't know what you've been doing, but you're so confident now. Just look at how you put those airheads in their place!"
    new "妈的，对！不知道你最近在干嘛，但现在你自信多了。看看你刚才怎么把那些傻瓜教训了一顿！"

translate chinese chinese_7654414_96:
    old "And... What do you think [pla]?"
    new "然后……你觉得[pla]呢？"

translate chinese chinese_9066415_97:
    old "I agree with Belle, you were totally awesome Hinn!"
    new "我同意贝尔的观点，你真是太棒了，赫因！"

translate chinese chinese_5710537_98:
    old "Well, it's a relief to hear you guys say that... For a moment there I thought you may have thought ill of me."
    new "好吧，听到你们这么说我就放心了……刚才我还以为你们可能对我有意见呢。"

translate chinese chinese_6632281_99:
    old "Aww, we wouldn't. And hey, for what it's worth, I think your costume is great."
    new "哎呀，我们才不会呢。而且说起来，我觉得你的 cosplay 很棒。"

translate chinese chinese_7531127_100:
    old "Yeah Hinn, you look gorgeous, and I'm happy you're finally showing some skin, it was about time!"
    new "yeah Hinn, 你看起来真性感，终于露出点皮肤了，真是时候！"

translate chinese chinese_0530686_101:
    old "Sigh, stop it with that."
    new "sigh，别这样了。"

translate chinese chinese_8877898_102:
    old "Yeah Hinn, it really, really suits you."
    new "yeah Hinn, 这真的很适合你。"

translate chinese chinese_7866741_103:
    old "And hey, I support you sharing your natural gifts with us. It's a really nice view."
    new "而且嘿，我支持你和我们分享你的天然礼物。这真的是一道美景。"

translate chinese chinese_8030418_104:
    old "Oh my gosh Mike, couldn't you be a little decent at least once?"
    new "天啊，迈克，你就不能至少有一次表现得好一点吗？"

translate chinese chinese_8392966_105:
    old "What? What did I say? I was giving Hinn a compliment!"
    new "什么？我说什么了？我在夸hin呢！"

translate chinese chinese_1189955_106:
    old "Yeah right, sure you were..."
    new "是吗，确实像你说的……"

translate chinese chinese_9659946_107:
    old "Anyway, we better get going. It's almost time for class."
    new "反正我们还是赶紧走吧，快到上课时间了。"

translate chinese chinese_3147081_108:
    old "Huh? But we still have some time."
    new "huh? 但我们还有些时间啊。 \n\n(Note: \"huh?\" is kept as is since it's a natural spoken interjection often left untranslated in localized VNs for authenticity.)"

translate chinese chinese_1809549_109:
    old "I know, but you know Ms. Mia has her eyes on you because you keep skipping. So, let's go, come on!"
    new "我知道，但你明白米娅老师一直注意着你，因为你老是逃课。所以走吧，快点！"

translate chinese chinese_9186298_110:
    old "W- was that true [pla]?"
    new "那件事是真的 [pla]？"

translate chinese chinese_0946298_111:
    old "What you said about my costume, do you really like it?"
    new "你说的关于我的 cosplay，你真的喜欢吗？"

translate chinese chinese_9878383_112:
    old "Of course! I like it a lot."
    new "当然了！我非常喜欢。"

translate chinese chinese_6111802_113:
    old "And to be honest... I think you're the only student who could pull it off."
    new "说实话……我觉得你是唯一能办到的学生。"

translate chinese chinese_0378647_114:
    old "Huh? You mean it?"
    new "huh? 你是认真的？"

translate chinese chinese_8006035_115:
    old "Yeah! Nobody else could wear that costume that well."
    new "对！没人能像她那样穿那套 cosplay。"

translate chinese chinese_7399276_116:
    old "Come with me for a moment [pla]..."
    new "跟我来一下[pla]..."

translate chinese chinese_0249288_117:
    old "Uhh, where are we going?"
    new "呃，我们这是要去哪儿？"

translate chinese chinese_8903986_118:
    old "Just come."
    new "就来吧。"

translate chinese chinese_3389614_119:
    old "Hmm, Hinn, this is the girl's bathroom, I don't think it's ok for me to go in."
    new "嗯，hin，这是女生洗手间，我觉得我进去不太好吧。"

translate chinese chinese_0560708_120:
    old "Maybe it's better if I wait outside."
    new "也许我在外面等比较好。"

translate chinese chinese_2466598_121:
    old "For you to use the bathroom..."
    new "让你去上厕所..."

translate chinese chinese_1213838_122:
    old "Hahahaha. Don't be silly, I didn't bring you here for that."
    new "哈哈哈哈哈。别傻了，我可不是为了那个才带你来的。"

translate chinese chinese_3709425_123:
    old "Uhh, you didn't? Then why?"
    new "呃，你没？那为什么？"

translate chinese chinese_1260257_124:
    old "You see, working with you and Dr. Johnson has really helped me get over my shyness, that's how I was able to stand up to those bullies."
    new "你知道吗，和你以及约翰逊博士一起工作真的帮我在克服害羞方面取得了很大进步，这就是我能够对抗那些欺凌者的原因。"

translate chinese chinese_1646859_125:
    old "So, I thought maybe we could have a little session now. Besides, I want to thank you."
    new "所以，我想也许我们现在可以来一小段。再说，我还想感谢你。"

translate chinese chinese_2307912_126:
    old "B- but here? What if someone sees us?"
    new "可是这里？要是有人看到我们怎么办？"

translate chinese chinese_9995451_127:
    old "Ohh, don't worry, I'm sure it's gonna be fine, classes are about to start, so there's nobody around."
    new "哦，别担心，肯定没事的，快上课了，周围没人。"

translate chinese chinese_1577695_128:
    old "Well, if you say so... I guess it's ok then."
    new "好吧，如果你这么说……那应该没关系吧。"

translate chinese chinese_5760160_129:
    old "Yes, I'm sure nobody will see us."
    new "是的，我确定没人会看到我们。"

translate chinese chinese_6273677_130:
    old "Come here, pull down your pants."
    new "过来，把裤子脱了。"

translate chinese chinese_4554328_131:
    old "It's always amazing how big you are [pla]."
    new "你总是这么大，[pla]。"

translate chinese chinese_7505898_132:
    old "I can believe we're doing it in the bathroom."
    new "真不敢相信我们在洗手间做这个。"

translate chinese chinese_7213455_133:
    old "I'm happy you're this hard because of me."
    new "我很高兴你能为我这么努力。"

translate chinese chinese_1550790_134:
    old "Look, it's almost time for class."
    new "看，快到上课时间了。"

translate chinese chinese_4566258_135:
    old "I'll go ahead. Don't be late."
    new "我先走了，别迟到哦。"

translate chinese chinese_8468785_136:
    old "Wow! I don't know what that was, but I sure like this new Hinn."
    new "哇！我不知道那是什么，但这个新的Hinn我超喜欢的。"

translate chinese chinese_3115766_137:
    old "Ohh! Wow, Billie! What are you doing here?"
    new "哦！哇，比莉！你在这里干什么？"

translate chinese chinese_2972187_138:
    old "Hey! What's up? I just transferred here. Today's my first day."
    new "嘿！怎么了？我刚转学来的。今天是我第一天。"

translate chinese chinese_0239461_139:
    old "Ahh, I see. That's cool, what school did you transfer from?"
    new "啊，我明白了。那挺好的，你之前转学来自哪所学校？"

translate chinese chinese_7184546_140:
    old "From nowhere actually. All my life I've been home schooled, and that's fine, I guess. But you see, this is my last year..."
    new "其实是从没去过。我一辈子都是在家自学的，我想这也挺好的。但你知道，这是我的最后一年了……"

translate chinese chinese_1017839_141:
    old "So, I wanted to have the school experience at least for senior year."
    new "所以，我至少想在高三的时候体验一下学校生活。"

translate chinese chinese_4204754_142:
    old "Well, I think that's a great idea! I'm glad you get to live that at least once. And hey, welcome."
    new "嗯，我觉得这个主意很棒！很高兴你能至少体验一次。而且，欢迎加入。"

translate chinese chinese_5964172_143:
    old "It was a coincidence that my first day was Halloween. So, I had to come in costume. What do you think?"
    new "我第一天上班正好赶上万圣节。所以不得不穿 cosplay 来上班。你觉得怎么样？"

translate chinese chinese_3183189_144:
    old "I think it's great, it's really good. You look just like the real Harley Quinn."
    new "我觉得太棒了，真的很不错。你看起来就像真正的哈莉·奎因。"

translate chinese chinese_0276014_145:
    old "Thanks, and hey, I think you also make for a very good Spiderman."
    new "谢谢，对了，我觉得你当蜘蛛侠也挺合适的。"

translate chinese chinese_4256422_146:
    old "Thanks!"
    new "谢谢！"

translate chinese chinese_2071304_147:
    old "By the way. Why were you leaving the girls bathroom?"
    new "对了，你为什么要从女生洗手间出来？"

translate chinese chinese_7506175_148:
    old "Ohh! Hmm, no reason."
    new "哦！嗯，没有理由。"

translate chinese chinese_1251567_149:
    old "I guess, I- I just got confused."
    new "我猜，我——我只是搞糊涂了。"

translate chinese chinese_1072614_150:
    old "Uhh... Sure..."
    new "呃……好吧……"

translate chinese chinese_6705705_151:
    old "We better get going, the class has already started."
    new "我们赶紧走吧，课已经开始了。"

translate chinese chinese_7028862_152:
    old "Ok guys, let's start today's lesson. Now who can tell me where we left it last time?"
    new "好了，大家，今天我们开始上课。现在谁能告诉我上次我们讲到哪里了？"

translate chinese chinese_7790854_153:
    old "Sorry ma'am! We came as quickly as we could."
    new "对不起女士！我们尽快赶来了。"

translate chinese chinese_9371248_154:
    old "Ugh! It's always the same with you [pla]! Would it kill you to act like a good student at least once?"
    new "哎！你[pla]总是这样！就不能至少有一次表现得好学生的样子吗？"

translate chinese chinese_9098696_155:
    old "I- I'm sorry Ms. Mia, it won't happen again, it's just that I met my friend in the hallway."
    new "我……对不起米娅老师，下次不会了，只是我在走廊上遇到了朋友。"

translate chinese chinese_5362226_156:
    old "Yeah right! Always excuses with you. Anyway, go sit down!"
    new "说得倒轻松！你总是找借口。总之，赶紧坐下！"

translate chinese chinese_0772110_157:
    old "Ok guys, before we begin, I have to introduce you to a new student."
    new "好了，大家，在开始之前，我得先给大家介绍一位新同学。"

translate chinese chinese_8035998_158:
    old "This is Billie, she's going to be accompanying us during this last year. Be sure to be nice to her."
    new "这是比莉，她会在最后一年里陪我们一起。大家一定要对她友好一点。"

translate chinese chinese_4599607_159:
    old "Hi."
    new "嗨。"

translate chinese chinese_1512420_160:
    old "Take seat Billie, there's a spot for you there."
    new "坐吧，比莉，那边有个位置给你。"

translate chinese chinese_5245769_161:
    old "Ok guys, as I was saying before being so rudely interrupted by [pla].  Who can tell me what we were talking about last class?"
    new "好的，大家，就像我被[pla]这么粗鲁地打断之前说的，谁能告诉我上节课我们在讨论什么？"

translate chinese chinese_4003223_162:
    old "Ok, that's it for today, don't forget to read up on the textbook before next class. It's better if you prepare your classes ahead."
    new "好的，今天就到这里，别忘了下次课前预习课本。最好提前准备一下课程。"

translate chinese chinese_8716778_163:
    old "Ok everybody, classes are over, and we have time. Why don't we go ask for some candy?"
    new "好了大家，课结束了，我们现在有时间了。要不去讨点糖果吃？"

translate chinese chinese_4304541_164:
    old "Ugh, candy? Are you serious? Don't you think we're a little too old for that?"
    new "哎呀，糖果？你是认真的吗？你不觉得我们有点太大龄了吧？"

translate chinese chinese_8553227_165:
    old "Ohh, come on! This is our last year, so we won't be able to do it anymore."
    new "哦，快点！这是我们最后一年了，以后就再也做不到了。"

translate chinese chinese_3964783_166:
    old "Yeah! Billie, trick or treating is super cool, we'll have a great time."
    new "没错！比莉，万圣节讨糖太酷了，我们会玩得很开心的。"

translate chinese chinese_9335200_167:
    old "I don't think walking around, knocking on front doors is a ‘great time.'"
    new "我觉得到处乱走，随便按人家门铃算不上“玩得开心”。"

translate chinese chinese_8095717_168:
    old "But whatever, if you all want to."
    new "不过随便你们了。"

translate chinese chinese_2093552_169:
    old "I actually want too, it's a good way to spend the afternoon."
    new "我其实也想，这样度过下午很不错。"

translate chinese chinese_9563720_170:
    old "Besides, we get to use the costumes some more."
    new "而且我们还能再穿那些 cosplay 服装。"

translate chinese chinese_8147483_171:
    old "And what do you think Hinn?"
    new "那你觉得Hinn呢？"

translate chinese chinese_9575948_172:
    old "I think it's a nice idea. I wanna hang out some more."
    new "我觉得这个主意不错。还想多玩一会儿。"

translate chinese chinese_4780070_173:
    old "And to be honest I also don't want to get out of my costume just yet."
    new "说实话，我也不想这么快脱下这套衣服。"

translate chinese chinese_5893699_174:
    old "Oh my god, you guys are so lame."
    new "天啊，你们真没劲。"

translate chinese chinese_8418323_175:
    old "But fine, fine, if you want to do it, I'll do it too. This better be good."
    new "好吧好吧，如果你想做，我就跟着做。这最好值得。"

translate chinese chinese_8623388_176:
    old "That was so awesome! I can't believe they gave us this much candy at our age."
    new "太棒了！真不敢相信他们在这个年纪给了我们这么多糖果。"

translate chinese chinese_8625281_177:
    old "Definitely, a real success I'd say."
    new "绝对的，可以说是个真正的成功。"

translate chinese chinese_0624335_178:
    old "You see? It was totally worth it. I knew it was gonna be this much fun. Right Billie?"
    new "你看？这完全值得。我知道会这么好玩。对吧，比莉？"

translate chinese chinese_7803910_179:
    old "Yeah... I guess. It wasn't so bad after all."
    new "嗯……我想还好。其实也没那么糟。"

translate chinese chinese_6165343_180:
    old "It's still early, we could keep going if you want to."
    new "还早呢，如果你想的话我们可以继续。"

translate chinese chinese_0836113_181:
    old "Nah, I don't think so. This is nice and all, but my feet hurt, I'm a little tired of carrying this heavy custume."
    new "不行，我不这么认为。这样挺好的，但我的脚好痛，背着这个沉重的服装也累了。"

translate chinese chinese_7651627_182:
    old "Come on man, don't ruin the mood, you're the one who wanted to ask for candy in the first place."
    new "拜托，别破坏气氛了，要不是你先提出要糖的。"

translate chinese chinese_6796684_183:
    old "Actually [pla], it annoys me to say this, but I think Mike may be right. We've been going for a while now, we should rest."
    new "实际上[pla]，说这话让我很不爽，但我觉得迈克可能是对的。我们已经走了好一阵了，应该休息一下了。"

translate chinese chinese_1037112_184:
    old "Well, if that's the case, we should go to the beach then, it's very nearby and we could sit and rest there."
    new "那这样的话，我们应该去海滩吧，就在附近，我们可以坐在那里休息。"

translate chinese chinese_4994084_185:
    old "Hmm, and what do you think, Hinn? Do you want to keep going?"
    new "嗯，你觉得呢，Hinn？你想继续吗？"

translate chinese chinese_0129389_186:
    old "Ohh, I'm fine. I only said it because I thought everyone else wanted to do it too, but if everyone it's ok with stopping here I'd agree."
    new "哦，我没事。我只是以为大家也想这么做才说的，但如果大家都觉得到这里停下来也可以，那我也同意。"

translate chinese chinese_2615753_187:
    old "That settles it then, let's go to the beach."
    new "那就这么定了，去海滩吧。"

translate chinese chinese_7924004_188:
    old "Well, this is nice. I thought there were going to be people here."
    new "嗯，这里挺安静的。我还以为会有人在这里。"

translate chinese chinese_9906532_189:
    old "Yeah, it's good that it is so quiet, this is a good place to rest."
    new "是啊，这么安静挺好的，这里是个休息的好地方。"

translate chinese chinese_6319203_190:
    old "We should find a place to sit down."
    new "我们应该找个地方坐下来。"

translate chinese chinese_6129088_191:
    old "Can't we just sit here?"
    new "我们就坐在这里不行吗？"

translate chinese chinese_5165127_192:
    old "I think we could sit a little bit closer to the sea."
    new "我觉得我们可以坐得离海再近一点。"

translate chinese chinese_2204245_193:
    old "Let's just go to that spot over there"
    new "我们就去那边那个地方吧"

translate chinese chinese_9629493_194:
    old "Yeah, that seems fine."
    new "嗯，那样好像不错。"

translate chinese chinese_6325013_195:
    old "Ok, since we're here. Why don't we make it a little bit more interesting than just sitting down doing nothing? Let's play truth or dare!"
    new "好吧，既然来了。我们干嘛就坐着什么都不干呢？来玩真心话大冒险吧！"

translate chinese chinese_3726110_196:
    old "Uhh, I'm sorry. Truth or what?"
    new "呃，对不起。真心话还是什么？"

translate chinese chinese_0500785_197:
    old "What? You don't know what truth or dare is?"
    new "什么？你不知道真心话大冒险吗？"

translate chinese chinese_9375023_198:
    old "Hey! I know what it is."
    new "喂！我知道那是什么。"

translate chinese chinese_0072337_199:
    old "Uhh, I think I know it, but I haven't played it."
    new "呃，我觉得我知道那个游戏，但我没玩过。"

translate chinese chinese_8371947_200:
    old "Just so we're all on the same page, could you explain?"
    new "为了确保大家都在同一页面上，你能解释一下吗？"

translate chinese chinese_0404273_201:
    old "It's very simple: Each round, one of us chooses someone and asks them 'truth or dare'"
    new "很简单：每轮我们其中一个人选一个人，然后问他们“真心话还是大冒险”"

translate chinese chinese_7536863_202:
    old "If the person chooses ‘truth' they have to answer whatever the other one asks. If they choose ‘dare', they have to do what the person tells them to."
    new "如果选“真心话”，就必须回答对方问的任何问题。如果选“大冒险”，就必须按照对方的要求去做。"

translate chinese chinese_8461615_203:
    old "All right..."
    new "好吧……"

translate chinese chinese_3004754_204:
    old "You have to be really honest in answering or accomplishing the dare, otherwise, you must go and can't continue playing."
    new "你必须非常诚实地回答或完成挑战，否则你就出局了，不能继续玩。"

translate chinese chinese_2682860_205:
    old "Yeah, just like that, it's really fun. Come on, let's play!"
    new "就是那样，真的很有趣。快来，我们一起玩！"

translate chinese chinese_9537314_206:
    old "Hmm, I don't know Billie..."
    new "嗯，我不太确定，比莉……"

translate chinese chinese_7934454_207:
    old "Oh no! We're not backing down from this, [pla]. Come on! It sounds like a lot of fun!"
    new "哦不！我们不会退缩的，[pla]。快点！听起来很有趣啊！"

translate chinese chinese_7834394_208:
    old "Yeah guys, let's do it. You never know, you may end up liking it."
    new "好了 guys，咱们来吧。你可能最后会喜欢上它的。"

translate chinese chinese_4094507_209:
    old "Ok, ok. If you guys really want to, let's do it."
    new "好吧好吧。如果你们真的想的话，我们就来吧。"

translate chinese chinese_8003689_210:
    old "Alright! Let's do it!"
    new "好！干吧！"

translate chinese chinese_1185398_211:
    old "Did you get it Hinn?"
    new "你搞定了吗，Hinn？"

translate chinese chinese_0652190_212:
    old "Yeah, it's not that hard."
    new "yeah, 这没什么难的。"

translate chinese chinese_9717687_213:
    old "Ok, since you say you understood it Hinn. Let's start with you, truth or dare?"
    new "好吧，既然你说你明白了，hin。那我们就从你开始，真心话还是挑战？"

translate chinese chinese_9660025_214:
    old "Uhmm, truth."
    new "嗯，说实话。"

translate chinese chinese_7575098_215:
    old "Hmm, are you in love with anybody here?"
    new "嗯，你在这里爱上谁了吗？"

translate chinese chinese_3272670_216:
    old "W- what? What kind of question is that?!"
    new "什、什么？这是什么问题啊?!"

translate chinese chinese_0976575_217:
    old "Uhh, it's a valid question, and you have to answer it, those are the rules..."
    new "呃，这是个有效的问题，你必须回答，这就是规则……"

translate chinese chinese_9664861_218:
    old "That's right, that's the game."
    new "没错，就是这个游戏。"

translate chinese chinese_2878156_219:
    old "*Sigh* O- ok. Y- yes, I- I'm in love with someone who's here."
    new "*叹气* 好吧...是的，我爱上这里的人了。"

translate chinese chinese_3109245_220:
    old "WHAT?! Who is it? Who is it?"
    new "什么?! 是谁? 是谁?"

translate chinese chinese_9080196_221:
    old "Hey, hey! Not fair, dude, she already answered a question. You can't ask her anything else. Right Billie?"
    new "嘿，嘿！不公平，伙计，她已经回答了一个问题了。你不能再问她别的了。对吧，比莉？"

translate chinese chinese_4694193_222:
    old "Yeah, if you really wanna know that kind of stuff, you're gonna have to ask better questions."
    new "是啊，如果你真想知道那种事情，你就得问得好一点。"

translate chinese chinese_0612185_223:
    old "But come on, I think we should go for dares... It makes the game exciting!"
    new "但是快点，我觉得我们应该来点挑战……这样游戏才刺激！"

translate chinese chinese_2506815_224:
    old "Anyway, since you already spoke, why don't you ask the next question [pla]?"
    new "总之，既然你已经说了，为什么不接着问下一个问题呢，[pla]？"

translate chinese chinese_8554641_225:
    old "Hmm, ok. Well then, Belle, truth or dare?"
    new "嗯，好吧。那么，贝尔，真心话还是大冒险？"

translate chinese chinese_6619319_226:
    old "Truth."
    new "真相。"

translate chinese chinese_7798273_227:
    old "Oh come on! Don't be pussies! Dares are way more fun!"
    new "Oh come on! Don't be pussies! Dares are way more fun! \n\n（注：此处为成人内容，翻译保持原意但需注意语境）\n\n哦，别这样！别那么胆小！挑战才更有趣呢！"

translate chinese chinese_6061433_228:
    old "Hmm... H- have you ever kissed a man before?"
    new "嗯……你以前吻过男人吗？"

translate chinese chinese_7329481_229:
    old "What kind of question is that? Are you serious? Oh my god, you're a bunch of wusses."
    new "这什么问题啊？你是认真的吗？天啊，你们都是一群胆小鬼。"

translate chinese chinese_7000603_230:
    old "I'll ask the question. Belle, have you ever taken naked pics?"
    new "我来问吧。贝尔，你拍过裸照吗？"

translate chinese chinese_2224285_231:
    old "W- whoa. Don't you think that's a little too far?"
    new "喂喂喂，你不觉得这有点过头了吗？"

translate chinese chinese_4740911_232:
    old "No it's not and answer the question."
    new "不是，回答问题。"

translate chinese chinese_2265486_233:
    old "Yeah Belle, those are the rules. You answer the question or leave!"
    new "没错，贝尔，这就是规矩。你回答问题或者离开！"

translate chinese chinese_6576723_234:
    old "Ugh! Yeah fine, I've taken naked photos before."
    new "哎呀！好吧，我之前拍过裸照。"

translate chinese chinese_9275358_235:
    old "Whoa! Really?!"
    new "谁啊！真的吗？！"

translate chinese chinese_9078990_236:
    old "Hehe, ok. Who 's next?"
    new "嘿嘿，好啦。下一个是谁？"

translate chinese chinese_0858741_237:
    old "Me, me, me! I'm next."
    new "我我我！轮到我了。"

translate chinese chinese_8174301_238:
    old "Ok, Billie. Truth or dare?"
    new "好吧，比莉。真心话还是大冒险？"

translate chinese chinese_1218379_239:
    old "Dare! Unlike you guys, I actually have some guts."
    new "敢！不像你们，我可是有点胆量的。"

translate chinese chinese_6188862_240:
    old "Ok... Hmm... I dare you to... kiss Belle!"
    new "好啦……嗯……我敢打赌你……会亲吻贝尔！"

translate chinese chinese_1477177_241:
    old "What? But I'm not the one with the dare! It's Billie."
    new "什么？但我不是那个打赌的人啊，是比莉。"

translate chinese chinese_3601346_242:
    old "Well, yeah. But this kind of dares are valid too. After all, I'm the one that has to do it."
    new "嗯，是啊。但这种挑战也有效。毕竟，要做的又是我。"

translate chinese chinese_6150633_243:
    old "Yeah! Remember, you have to do it or you're out!"
    new "对！记住，不做就没份了！"

translate chinese chinese_1877894_244:
    old "Yeah whatever, I'll do it, it's no big deal."
    new "行吧，我做就是了，没什么大不了的。"

translate chinese chinese_8219242_245:
    old "Come on, just help me with this... Otherwise I won't be able to continue playing..."
    new "拜托了，就帮我这个忙吧……不然我就没法继续玩了……"

translate chinese chinese_5668942_246:
    old "Just come here, close your eyes and think of someone you like."
    new "just过来，闭上眼睛，想想你喜欢的人。"

translate chinese chinese_6087813_247:
    old "I'm sure we both are gonna enjoy it."
    new "我相信我们两个都会享受的。"

translate chinese chinese_2269859_248:
    old "Ok. Now it's my turn to have a go!"
    new "好。现在轮到我了！"

translate chinese chinese_1730977_249:
    old "Mike, truth or dare?"
    new "迈克，真心话还是大冒险？"

translate chinese chinese_0081244_250:
    old "Of course dare."
    new "当然敢。"

translate chinese chinese_7393822_251:
    old "Well, I dare you to leave and go home."
    new "好吧，我敢打赌你会离开回家的。"

translate chinese chinese_8725859_252:
    old "Uhh?..."
    new "嗯？..."

translate chinese chinese_1492945_253:
    old "Yeah! That's right, we all had to do our dares. You have to do the same."
    new "对！我们都得完成我们的挑战，你也一样。"

translate chinese chinese_5438444_254:
    old "What is it Mike? You can't do it, uhh?"
    new "怎么了，迈克？你做不到，嗯？"

translate chinese chinese_9402481_255:
    old "Of course I can do it! I'll show you!"
    new "我当然能行！我会让你看看的！"

translate chinese chinese_4725640_256:
    old "Yeah, I didn't think he would do it."
    new "是啊，我也没想到他会这么做。"

translate chinese chinese_2658755_257:
    old "Hahaha, very good trick Hinn, well done."
    new "哈哈，希恩这招挺妙的，干得不错。"

translate chinese chinese_8302763_258:
    old "Ok, now that he's gone. It's my turn again. [pla] truth or dare?"
    new "好了，现在他走了。轮到我了。[pla] 真心话还是挑战？"

translate chinese chinese_1676252_259:
    old "Hmm, truth."
    new "嗯，说真话。"

translate chinese chinese_2670767_260:
    old "You know what? I- I choose dare."
    new "你知道吗？我——我选择接受挑战。"

translate chinese chinese_6478285_261:
    old "What? No, you've got to answer the question."
    new "什么？不，你必须回答这个问题。"

translate chinese chinese_7660212_262:
    old "No, it's fine. In fact, from now on let's play only with 'dares', no more truths."
    new "不，没关系。事实上，从现在开始我们只玩“挑战”，不再玩“真心话”。"

translate chinese chinese_7611407_263:
    old "Hmm, ok, if that's how it is. Then I dare you to take your penis out."
    new "嗯，好吧，如果是这样的话。那我敢打赌你敢把你的鸡巴拿出来。"

translate chinese chinese_9412806_264:
    old "W- what? Why do I have to do that?"
    new "什、什么？为什么我得做那个？"

translate chinese chinese_5057495_265:
    old "Well, you can either do that, or answer my question!"
    new "好吧，你可以选择那样做，或者回答我的问题！"

translate chinese chinese_5755059_266:
    old "Hmm, fine..."
    new "哼，好吧……"

translate chinese chinese_6574386_267:
    old "(What a fucking big cock!)"
    new "(真他娘的大鸡巴！)"

translate chinese chinese_6978159_268:
    old "Ok, now it's done."
    new "好了，现在搞定了。"

translate chinese chinese_4886141_269:
    old "It's my turn again. And Belle, since you already made [pla] show something..."
    new "又轮到我了。而且贝尔，既然你已经让[pla]展示了一些东西..."

translate chinese chinese_5926769_270:
    old "Why don't you show something of your own as well? What about if you take your boobs out?"
    new "你为什么不也展示一下自己呢？把胸露出来怎么样？"

translate chinese chinese_2752893_271:
    old "Hey, I already did it. You have to fulfill the dare."
    new "喂，我已经做了。你得完成那个挑战。"

translate chinese chinese_0211856_272:
    old "Fine. I'll do it."
    new "好吧，我来做。"

translate chinese chinese_3762690_273:
    old "Ok, since I've done it... It's my turn, Billie! Show us your breasts too."
    new "好吧，既然我做了……轮到我了，比莉！也把你的胸部给我们看看。"

translate chinese chinese_8089748_274:
    old "Ughh, so original..."
    new "唉，真有创意……"

translate chinese chinese_1544654_275:
    old "Then, since there's only one person here that hasn't shown anything. Hinn, I dare you to take your breast out too."
    new "那么，既然这里只有一个人还没展示过。hin，我敢打赌你也会把胸露出来的。"

translate chinese chinese_8258401_276:
    old "I- I... Uhh... I'm sorry guys, I- I can't do it."
    new "我……呃……对不起，大家，我……做不到。"

translate chinese chinese_7932585_277:
    old "Hinn wait!"
    new "等一下！"

translate chinese chinese_6149528_278:
    old "No! [pla], just let her go. I think we went a little too far, right now she's a little nervous. Just leave her alone for now."
    new "不！[pla]，就让她走吧。我觉得我们有点过头了，现在她有点紧张。就先让她一个人待会儿吧。"

translate chinese chinese_7716369_279:
    old "But... I think she needs company."
    new "但是……我觉得她需要有人陪。"

translate chinese chinese_8471695_280:
    old "Not right now, if you go after her you're just going to make her feel worse."
    new "现在不行，如果你去追她，只会让她感觉更糟。"

translate chinese chinese_7047950_281:
    old "Trust me, it's better if you just let it be. You can talk to her later. Right Billie?"
    new "相信我，还是别管了比较好。你可以晚点再跟她聊。对吧，比莉？"

translate chinese chinese_8005446_282:
    old "Yeah, what she said."
    new "对，她说得对。"

translate chinese chinese_6894630_283:
    old "Hmm, all right."
    new "嗯，好吧。"

translate chinese chinese_5208286_284:
    old "Well, I guess we can continue playing then."
    new "那好吧，我想我们可以继续玩了。"

translate chinese chinese_9036134_285:
    old "I agree, since we already started playing. I think it's the best we can do."
    new "我同意，既然我们已经开始玩了，我觉得这是最好的选择。"

translate chinese chinese_2792713_286:
    old "Yeah fine. Let's do it."
    new "好吧，咱们就这么做。"

translate chinese chinese_8414525_287:
    old "Now, it's your turn to do a dare again [pla]."
    new "现在轮到你再做一项挑战了，[pla]。"

translate chinese chinese_3397384_288:
    old "Why don't you suck Billie's boobs?"
    new "为什么不吸Billie的奶呢？"

translate chinese chinese_3608195_289:
    old "Whoa! Really?"
    new "谁啊！真的吗？"

translate chinese chinese_0361389_290:
    old "Well, a dare is a dare, so..."
    new "好吧，既然是挑战，那就..."

translate chinese chinese_5373360_291:
    old "A- all right."
    new "好，好吧。"

translate chinese chinese_3058073_292:
    old "Hmm, this isn't going to stay like this."
    new "嗯，这种情况不会一直持续下去的。"

translate chinese chinese_9459924_293:
    old "Belle, since you like contact that much. Why don't you give [pla] a handjob?"
    new "贝尔，既然你喜欢亲密接触，为什么不给[pla]来次手淫呢？"

translate chinese chinese_5365652_294:
    old "W- what? For real?!"
    new "什、什么？ seriously?!"

translate chinese chinese_8652298_295:
    old "That's right."
    new "没错。"

translate chinese chinese_5827418_296:
    old "Ughh, fine, let's do it."
    new "唉，好吧，咱们就做吧。"

translate chinese chinese_0482957_297:
    old "My god [pla] your dick is huge! I can't believe you carry this around."
    new "天啊[pla]，你的 dicks 真的大！我还以为你平时不带着呢。"

translate chinese chinese_2270050_298:
    old "Come on, quit stalling and do it."
    new "快点，别磨叽了，赶紧做吧。"

translate chinese chinese_6805788_299:
    old "Yeah, well, here I come."
    new "好吧，我来了。"

translate chinese chinese_3360885_300:
    old "Ok, I did what you dared me too."
    new "好吧，我做了你让我做的挑战。"

translate chinese chinese_4276583_301:
    old "But since you wanted to see that so badly, why don't you give [pla] a blowjob, Billie?"
    new "但是既然你那么想看，为什么不下手给[pla]口交呢，比莉？"

translate chinese chinese_8135288_302:
    old "What's this, copying me again?"
    new "这是什么，又抄我吗？"

translate chinese chinese_2516638_303:
    old "What? After you made me do all of that, you can't do it?"
    new "什么？你让我做了那么多，你自己却做不到？"

translate chinese chinese_3727275_304:
    old "Tsk, of course I can, come on [pla] let's do it!"
    new "啧，当然可以，来吧[pla]，我们干吧！"

translate chinese chinese_8388903_305:
    old "I still can't believe you pack this much."
    new "我真不敢相信你带了这么多东西。"

translate chinese chinese_0450210_306:
    old "Are you nervous?"
    new "你紧张吗？"

translate chinese chinese_8260718_307:
    old "Of course not. I was just saying."
    new "当然不是。我只是说说而已。"

translate chinese chinese_5034505_308:
    old "Ok, this has been fun. But what do you say about taking this to the next level?"
    new "好吧，这很有趣。但是你说我们是不是可以把这个升级一下？"

translate chinese chinese_2052861_309:
    old "The next level? Hasn't this been enough?"
    new "下一个等级？这还不够吗？"

translate chinese chinese_5062667_310:
    old "No, I'm talking about something extreme, How about we go to the haunted house here in town?"
    new "不，我说的是极端一点的。要不去镇上的那间鬼屋看看怎么样？"

translate chinese chinese_3570142_311:
    old "Haunted house?"
    new "鬼屋？"

translate chinese chinese_7776710_312:
    old "Yeah that's right. There's a house in town with vampires. Why don't we go?"
    new "没错。镇上有一栋房子有吸血鬼。我们不去看看吗？"

translate chinese chinese_7776050_313:
    old "Ohh, you're talking about the old mansion."
    new "哦，你在说那座老宅子。"

translate chinese chinese_0159399_314:
    old "B- but you said vampires. Which vampires?"
    new "你、你说的是吸血鬼？哪个吸血鬼？"

translate chinese chinese_4070031_315:
    old "There's a legend about that house, that says there are vampires in there."
    new "关于那栋房子有个传说，说里面住着吸血鬼。"

translate chinese chinese_5134261_316:
    old "All its inhabitants are women, people say that they have been seen kidnapping men, to then suck all of their blood out."
    new "那里的居民全是女人，据说她们会绑架男人，然后吸干他们的血。"

translate chinese chinese_3886220_317:
    old "And leave them completely dry."
    new "并且完全弄干它们。"

translate chinese chinese_5935889_318:
    old "Besides, it is said that they are all very pale, and apparently they only go out at night. Never in the sunlight. Surely to pick up another victim."
    new "而且据说他们都很苍白，显然只在晚上外出，从不在阳光下出现，肯定是去寻找另一个受害者。"

translate chinese chinese_4441778_319:
    old "Yeah, yeah, yeah. It's super creepy and spooky, let's go!"
    new "好了好了，真的很阴森，我们走吧！"

translate chinese chinese_5253316_320:
    old "Uhh... I- I'm not sure I want to go there."
    new "呃……我——我不确定要不要去那里。"

translate chinese chinese_9552291_321:
    old "Aww, are you that much of a wuss? Come on, have some guts."
    new "哎呀，你这么没用吗？来点勇气好吗。"

translate chinese chinese_6058115_322:
    old "I'm not a wuss... Ok, let's do it then."
    new "我可不是胆小鬼……好吧，那我们就来吧。"

translate chinese chinese_5626198_323:
    old "Wow guys, this really feels sinister. It's quite terrifying."
    new "喂，这感觉真的很阴森，挺吓人的。"

translate chinese chinese_0908901_324:
    old "Y-y-yeah, this is very scary. Maybe we should head back."
    new "嗯……这个真的很可怕。 maybe we should head back. \n\n注意：最后一部分\"maybe we should head back.\"未翻译以遵守规则。"

translate chinese chinese_3257713_325:
    old "What? No, we're not doing that. We've gotta keep playing. And it's your turn again [pla]."
    new "什么？不，我们不做那个。我们必须继续玩。而且又轮到你了[pla]。"

translate chinese chinese_6911953_326:
    old "And since you are spiderman... I dare you to climb up to the roof."
    new "既然你是蜘蛛侠……我敢打赌你能爬到屋顶上去。"

translate chinese chinese_5844906_327:
    old "W-what? B-but..."
    new "什、什么？但……"

translate chinese chinese_3689507_328:
    old "It's a dare, isn't it? We accomplished ours very well."
    new "这是在赌注吧？我们这边完成得很不错。"

translate chinese chinese_1551377_329:
    old "And you seemed to enjoy those a lot. Didn't you? it would be unfair if you chicken out now. Do it!"
    new "而且你似乎很享受那些。不是吗？你现在退缩就太不公平了。来吧！"

translate chinese chinese_3662625_330:
    old "Hmph, fine. I'll do it."
    new "哼，好吧。我来做。"

translate chinese chinese_1591667_331:
    old "But use all the suit, even with the mask, just like spiderman."
    new "但是穿上全套衣服，连面具都戴好，就像蜘蛛侠一样。"

translate chinese chinese_5174896_332:
    old "Really? Hmm, Alright."
    new "真的吗？嗯，好吧。"

translate chinese chinese_7245231_333:
    old "That's it! Yes, you're doing well!"
    new "就是这样！没错，你做得很好！"

translate chinese chinese_1667840_334:
    old "Keep going! You can't just stop halfway up! You have to make it to the roof!"
    new "继续！你不能半途而废！一定要爬到屋顶！"

translate chinese chinese_3753245_335:
    old "I know, ugh! I know!"
    new "我知道，哎！我知道！"

translate chinese chinese_9331979_336:
    old "Ok! I made it all the way up! Just wait there, I'm gonna go down again!"
    new "好啦！我爬到顶了！你就在那等我，我要下去了！"

translate chinese chinese_9119742_337:
    old "Yeah sure! You made it, come down!"
    new "当然啦！你做到了，下来吧！"

translate chinese chinese_5421383_338:
    old "AAAAAAH!!"
    new "啊啊啊啊啊!!"

translate chinese chinese_6044746_339:
    old "[pla]! [pla]! Can you hear us [pla]?! Talk to us!"
    new "[pla]！[pla]！你能听到我们[pla]的声音吗？！跟我们说说话！"

translate chinese chinese_0223944_340:
    old "We're going to get some help! Just hang in there!"
    new "我们要去找些帮助！坚持住！"

translate chinese chinese_1842488_341:
    old "W- what is this? W- where I-?"
    new "这、这是什么？我、我在哪儿？"

translate chinese chinese_3160121_342:
    old "Ugh!! My god, what happened? Why does my head hurt so much?"
    new "哎呀！！我的天，发生了什么？为什么我头疼得这么厉害？"

translate chinese chinese_6969365_343:
    old "Oh, Hello! You're finally awake, I'm glad you woke up. I was thinking that if you didn't, I might have to call an ambulance."
    new "哦，你好！你终于醒了，真高兴你醒了。我在想如果你再不醒，我可能得叫救护车了。"

translate chinese chinese_7917701_344:
    old "Whoa! Ah... W- where am I?"
    new "谁啊！啊... 我在哪？"

translate chinese chinese_3409652_345:
    old "Calm down, this is my house. You fell in here yesterday while you were playing on our roof."
    new "冷静点，这是我的房子。你昨天在我们房顶玩的时候掉进来了。"

translate chinese chinese_4774252_346:
    old "Y- your house?"
    new "你家？"

translate chinese chinese_0675736_347:
    old "Yes, that's right. Maybe you thought you actually were spiderman?"
    new "没错。也许你以为自己真的是蜘蛛侠？"

translate chinese chinese_4850085_348:
    old "Oh my God! It's morning already?!"
    new "天啊！已经早上了吗？！"

translate chinese chinese_4324661_349:
    old "I- I have to go, [mo1rel] must be worried sick about me."
    new "我……我得走了，[mo1rel]肯定很担心我。"

translate chinese chinese_1521229_350:
    old "Are you already leaving?"
    new "你这就走了？"

translate chinese chinese_1647055_351:
    old "Y- yes, but don't worry, I promise I'll come back to fix your roof."
    new "是的，但是别担心，我保证会回来修你的屋顶。"

translate chinese chinese_5541546_352:
    old "Ok, if you say so. Be careful though. You got a big hit there."
    new "好吧，如果你这么说。不过小心点，你刚才可是受了重伤。"

translate chinese chinese_7430174_353:
    old "Dear, you're home! Oh my god! You had me so worried. Where were you?!"
    new "亲爱的，你回家了！天啊！我好担心你。你去哪里了?!"

translate chinese chinese_8840842_354:
    old "S- sorry [mo1rel]. Me and my friends went trick or treating yesterday after school was over."
    new "对不起[mo1rel]。我和朋友们昨天放学后去了不给糖就捣蛋。"

translate chinese chinese_0742668_355:
    old "And after we were done Mike invited me to stay at his house."
    new "而且我们完了之后，迈克邀请我去他家住。"

translate chinese chinese_5864409_356:
    old "That's not a problem. But why didn't you call to let us know where you were?!"
    new "这没问题。但你为什么不来电话告诉我们你在哪儿呢？！"

translate chinese chinese_3746098_357:
    old "I- I guess I just lost track of time and then forgot about it. Sorry [mo1rel] I didn't mean to scare you."
    new "我……我只是忘了时间，然后就忘记了。对不起[mo1rel]，我没想吓到你。"

translate chinese chinese_8752257_358:
    old "Well you did! You're an adult, so you can do whatever you want, but at least call to let me know about this sort of thing."
    new "那你做到了啊！你是大人了，想做什么都可以，但至少打个电话告诉我一声这种事。"

translate chinese chinese_4751160_359:
    old "You're right, my bad."
    new "你说得对，是我的错。"

translate chinese chinese_0704344_360:
    old "It's ok honey, I'm just happy to see you're safe."
    new "没事的宝贝，我 just 很高兴看到你平安无事。"

translate chinese chinese_7431913_361:
    old "Thanks [mo1rel]. By the way, I've gotta get ready for school."
    new "谢谢[mo1rel]。对了，我得准备去上学了。"

translate chinese chinese_5753292_362:
    old "Ohh, what a crazy day yesterday was. I can't believe we did all that."
    new "哦，昨天真是疯狂的一天。真不敢相信我们做了那些事。"

translate chinese chinese_8766897_363:
    old "I would like to rest a little bit more. But I guess I better get to school. I don't want to give Ms. Mia any more reasons to suspend me."
    new "我还想再休息一会儿。但我想我还是去上学吧。我不想给米娅老师更多开除我的理由。"

translate chinese chinese_5284807_364:
    old "Hey girls, how are you?"
    new "嘿，姑娘们，你们好吗？"

translate chinese chinese_4815673_365:
    old "Are you really ok? We went asking for assistance but when we came back you weren't there."
    new "你真的没事吗？我们去找人帮忙了，回来你就不见了。"

translate chinese chinese_0299302_366:
    old "We were very worried because we didn't know where you went."
    new "我们非常担心，因为不知道你去了哪里。"

translate chinese chinese_2654908_367:
    old "Yeah, sorry about that. But to be honest I don't know what happened either."
    new "嗯，对不起。但老实说，我也不知道发生了什么。"

translate chinese chinese_8232396_368:
    old "All I remember was hitting the ground really hard, and you calling out for me. But then I passed out."
    new "我只记得狠狠地撞到地上，然后你喊我的名字。之后我就晕过去了。"

translate chinese chinese_0830961_369:
    old "I imagined it was the lady who moved me."
    new "我想象是那位女士打动了我。"

translate chinese chinese_8421981_370:
    old "Lady? You're talking about the vampire?!"
    new "女士？你在说吸血鬼？！"

translate chinese chinese_9671729_371:
    old "Uhhh, I- I don't know, I just met her this morning when I woke up, apparently she took care of me."
    new "呃，我— 我不知道，今天早上醒来的时候才遇到她，看来是她在照顾我。"

translate chinese chinese_1855898_372:
    old "Whoa! And how was it? Weren't you scared?"
    new "谁啊！怎么样？你不害怕吗？"

translate chinese chinese_8100859_373:
    old "Me? Not really? I was only surprised, because she wasn't angry. In fact, she was really nice to me."
    new "我？不太吧？我只是感到惊讶，因为她并没有生气。事实上，她对我很好。"

translate chinese chinese_8497074_374:
    old "I promised to come back later and fix the damage I did to her roof."
    new "我答应过晚点回来修理我弄坏的她的屋顶。"

translate chinese chinese_0888702_375:
    old "Whoa! Well I guess it's better that way."
    new "谁啊！嗯，这样可能更好。"

translate chinese chinese_7221204_376:
    old "Yeah, after all, you did ruin her roof. So, it's better if you fix it."
    new "是啊，毕竟你把她的屋顶搞坏了。所以还是你来修好吧。"

translate chinese chinese_8854391_377:
    old "Yeah, I think I went a little overboard with that last dare."
    new "是啊，我觉得上次那个挑战我有点过头了。"

translate chinese chinese_0793976_378:
    old "I promise I'll make it up to you next time we play. Right Belle?"
    new "我保证下次玩的时候会补偿你的。对吧，贝尔？"

translate chinese chinese_1667871_379:
    old "Yeah, for sure."
    new "没错，就是这样。"

translate chinese chinese_6709512_380:
    old "Well, I didn't think I would want to play that again."
    new "嗯，我没想到自己不想再玩那个了。"

translate chinese chinese_9558715_381:
    old "But if it's going to be like you say, then count me in for next time."
    new "但如果真像你说的那样，下次算我一个。"

translate chinese chinese_6832896_382:
    old "Well, we have classes now. See you later."
    new "好吧，我们现在有课。回头见。"

translate chinese chinese_3765614_383:
    old "Alright, see you girls."
    new "好了，再见了，姑娘们。"

translate chinese chinese_9735717_384:
    old "G- good morning [pla]. How are you?"
    new "早、早上好[pla]。你怎么样？"

translate chinese chinese_1878751_385:
    old "Hey Hinn. I'm fine, thank God I get to see you today."
    new "嘿，Hinn。我挺好的，感谢上帝今天能见到你。"

translate chinese chinese_8391565_386:
    old "Hey, listen, I've been thinking, and I'm sorry about the way things ended up yesterday, me and the girls took it a little too far."
    new "嘿，听我说，我一直在想，对于昨天发生的事，我感到很抱歉，我和那些女孩有点过火了。"

translate chinese chinese_8135820_387:
    old "It's ok, actually I wanted to say sorry to you."
    new "没关系，其实我想向你道歉。"

translate chinese chinese_3885569_388:
    old "To be honest, I'm still not used to being that open. It's ok when I'm with you and Dr. Johnson."
    new "说实话，我还不太习惯这么坦白。和你还有约翰逊医生在一起的时候还好些。"

translate chinese chinese_7320552_389:
    old "But if things turn sexual when there's other people around, and watching me, I just freeze."
    new "但如果周围有人，看着我的话，一到涉及性的事情我就僵住了。"

translate chinese chinese_5516231_390:
    old "And yesterday things got a little too dense for my liking, so I couldn't handle it, and took off."
    new "昨天情况有点超出我能接受的范围，所以我应付不来，就跑了。"

translate chinese chinese_1393539_391:
    old "S- sorry for leaving like that, I hope I didn't ruin your night."
    new "对不起突然离开，希望我没有破坏你的夜晚。"

translate chinese chinese_1515610_392:
    old "No, not at all! You didn't ruin anything."
    new "不，根本没那回事！你什么都没毁。"

translate chinese chinese_8634344_393:
    old "Yes, really. I'm just happy to see you're doing fine."
    new "是的，真的。我 just 很高兴看到你一切都好。 \n\n(Note: The word \"just\" seems out of place in this sentence in English and doesn't translate directly. If you want to keep it, please clarify its intended meaning.) \n\n修正后:\n是的，真的。我真的很高兴看到你一切都好。"

translate chinese chinese_7004592_394:
    old "Thank you [pla]."
    new "谢谢你[pla]。"

translate chinese chinese_7616298_395:
    old "But... honestly, I don't think I'm that well..."
    new "但是……老实说，我觉得自己不太……"

translate chinese chinese_9209687_396:
    old "Well, I- I've been thinking... maybe I could talk with Dr. Johnson again, take a couple more lessons from her."
    new "嗯，我——我在想…… maybe 我可以再去找 Johnson 博士谈谈，再跟她上几节课。"

translate chinese chinese_4781814_397:
    old "Really? Do you feel you need it?"
    new "真的吗？你觉得你需要那样吗？"

translate chinese chinese_9722517_398:
    old "I do. I know she's already helped me a lot. But it can't hurt to keep working on things. There's always room for improvement"
    new "我知道她已经帮了我很多。但继续努力也不会有什么坏处。总是有改进的空间。"

translate chinese chinese_0357955_399:
    old "Hmm, well, if you think it's the best thing for you, I support you completely."
    new "嗯，好吧，如果你觉得这是最好的选择，我完全支持你。"

translate chinese chinese_5371353_400:
    old "Thank you, your support does mean a lot to me. Also, would you come with me? To the sessions? I think it's easier with you there."
    new "谢谢你，你的支持对我来说意义重大。还有，你能陪我一起去吗？去那些会议？我觉得有你在会容易些。"

translate chinese chinese_7373924_401:
    old "Of course I will, if you need me, I'm more than happy to help you."
    new "当然了，如果你需要我，我很乐意帮忙。"

translate chinese chinese_0024717_402:
    old "Thanks again [pla] I knew I could count on you."
    new "再次感谢[pla]，我知道我可以信赖你。"

translate chinese chinese_2331563_403:
    old "Oh! Look at the time, I think we better get to class."
    new "哦！看看时间，我觉得我们最好去上课了。"

translate chinese chinese_9019179_404:
    old "Yeah, if not Ms. Mia will be angry."
    new "是啊，不然米娅小姐会生气的。"

translate chinese chinese_6889574_405:
    old "You are right. let's go."
    new "你说得对，我们走吧。"

translate chinese chinese_8477732_406:
    old "Good morning ma'am, how are you?"
    new "早上好，女士，您好吗？"

translate chinese chinese_8253815_407:
    old "Ohh! This is a surprise... I didn't think you were gonna come back."
    new "哦！这真是个惊喜……我以为你不会回来了。"

translate chinese chinese_6460936_408:
    old "No, I couldn't do that. I said I was gonna fix it, and that's what I'll do."
    new "不，我不能那么做。我说过我会解决的，我就会做到。"

translate chinese chinese_3560097_409:
    old "Well, isn't that nice?"
    new "嗯，真不错呀？"

translate chinese chinese_2586179_410:
    old "Truth be told, I had already prepared some tools to fix it myself. But if you're gonna do it I'll lend them to you."
    new "说实话，我自己已经准备了一些工具来修理。但如果你要修的话，我可以借给你。"

translate chinese chinese_4496468_411:
    old "Thank you ma'am. I promised it's going to be as good as new when I'm done."
    new "谢谢您。我保证修好后会跟新的一样。"

translate chinese chinese_4953920_412:
    old "That's really nice of you, thank you."
    new "你真好，谢谢。"

translate chinese chinese_0019073_413:
    old "So, where are the tools and materials?"
    new "那么，工具和材料在哪里？"

translate chinese chinese_6964262_414:
    old "Oh, they're in the next room, in the garage."
    new "哦，他们在隔壁的车库里面。"

translate chinese chinese_3492352_415:
    old "The damage isn't that small, so it's going to take you a while to finish completely, you may have to come a couple more times."
    new "伤害不小，你得花些时间才能完全恢复，可能还得来几次。"

translate chinese chinese_4971892_416:
    old "That's fine, it was my fault, so it doesn't matter to me how much time it takes. I'll fix it completely."
    new "没关系，是我的错，所以我不在乎花多少时间。我会彻底解决的。"

translate chinese chinese_2986405_417:
    old "And once again ma'am. I'm sorry for doing that."
    new "女士，再次向您道歉。"

translate chinese chinese_3133885_418:
    old "It's ok, what's important it's that you came back, and by the way, I'm Alcina Dimitrescu."
    new "没关系，重要的是你回来了，对了，我是阿尔西娜·德米特雷斯库。"

translate chinese chinese_0957766_419:
    old "Ohh sorry... I haven't told you my name. I'm [pla], nice to meet you."
    new "哦，对不起……我还没告诉你我的名字。我是[pla]，很高兴见到你。"

translate chinese chinese_2657324_420:
    old "Oh don't worry, nice to meet you too [pla]..."
    new "哦别担心，见到你也很高兴，[pla]..."

translate chinese chinese_0722904_421:
    old "I'll be in the next room if you need me. I won't take more of your time and let you start your work..."
    new "如果你需要我，我就在隔壁。我不再占用你的时间，让你开始工作吧……"

translate chinese chinese_8030027_422:
    old "All right, thank you."
    new "好吧，谢谢。"

translate chinese chinese_1101389_423:
    old "Congratulations! You made a lot of progress today."
    new "恭喜！你今天进步很大。"

translate chinese chinese_6682838_424:
    old "You're very fast, and it's all very well done."
    new "你动作很快，做得也很到位。"

translate chinese chinese_3581502_425:
    old "Thank you ma'am. I'm glad you like my progress."
    new "谢谢您。很高兴您喜欢我的进步。"

translate chinese chinese_6532878_426:
    old "I'm sure if I keep going at this pace it'll be ready very soon."
    new "我相信如果我保持这个进度，很快就能完成了。"

translate chinese chinese_5822449_427:
    old "Sure, I have no doubt about it. Very nice."
    new "行，我完全相信。很好。"

translate chinese chinese_1701610_428:
    old "Thank you ma'am."
    new "谢谢您。"

translate chinese chinese_8824451_429:
    old "It's a little late, so I think I should be going home. But I'll come back soon."
    new "现在已经有点晚了，我觉得我应该回家了。但我会很快回来的。"

translate chinese chinese_8227849_430:
    old "Oh yeah, don't worry, go home, I'll see you later then."
    new "哦，好的，别担心，回家吧，回头见。"

translate chinese chinese_1057198_431:
    old "Hmm, this is harder than I expected."
    new "嗯，这比我想的要难多了。"

translate chinese chinese_8889872_432:
    old "Sorry for doing so little. But I'm sure next time I'll progress a lot more."
    new "抱歉做得这么少。但下次我肯定能进步很多。"

translate chinese chinese_9002527_433:
    old "Well, you didn't do much today, but I understand, it's a big job after all. "
    new "好吧，你今天没做多少，但我理解，这毕竟是一项大工程。"

translate chinese chinese_6849485_434:
    old "Don't worry about the progress, I know you'll make it."
    new "别担心进度，我知道你能行的。"

translate chinese chinese_2905973_435:
    old "Yeah, thank you. I'll come back later and keep working on it."
    new "好的，谢谢。我稍后再回来继续处理。"

translate chinese chinese_1193193_436:
    old "Yes, it's a little late, so you should go home and come another time."
    new "嗯，有点晚了，你应该回家，改天再来。"

translate chinese chinese_0562257_437:
    old "You are right. Thank you."
    new "你说得对。谢谢。"

translate chinese chinese_5762350_438:
    old "Hmm, listen, ma'am before I leave, may I ask you something?"
    new "嗯，听着，女士，在我离开前，可以问你个问题吗？"

translate chinese chinese_3611550_439:
    old "And what may that be?"
    new "那会是什么呢？"

translate chinese chinese_2949981_440:
    old "Well, I'm a little ashamed to admit this."
    new "好吧，我有点不好意思承认这个。"

translate chinese chinese_0511064_441:
    old "But the reason I crashed into your living room the other day was because a couple of my friends dared me to climb your roof."
    new "但我那天撞进你客厅的原因是我有几个朋友敢我爬你的屋顶。"

translate chinese chinese_3351382_442:
    old "And why did they do that?"
    new "他们为什么要那样做？"

translate chinese chinese_1589090_443:
    old "Well... it's because there are some rumors about this house being haunted."
    new "嗯……是因为有关于这栋房子闹鬼的传言。"

translate chinese chinese_6942606_444:
    old "Haunted you say?"
    new "你说的是吓到你了吗？"

translate chinese chinese_1829454_445:
    old "Yeah... I mean, I don't believe them now, but that's what they say."
    new "嗯……我的意思是，我现在不信了，但她们是这么说的。"

translate chinese chinese_5133061_446:
    old "And, that's not all of it..."
    new "而且，这还不是全部……"

translate chinese chinese_9637194_447:
    old "It isn't?"
    new "不是吗？"

translate chinese chinese_0649554_448:
    old "Well, apparently there's a story about a group of vampires living here..."
    new "嗯，据说这里有一群吸血鬼住着……"

translate chinese chinese_6568516_449:
    old "Is that so? And what do you think? Do I look like a vampire to you?"
    new "是吗？你觉得呢？我看起来像吸血鬼吗？"

translate chinese chinese_1059960_450:
    old "O- of course not. I just wanted to apologize for the reason I climbed your roof. Because the rumor isn't true, right?"
    new "O-当然不是。我只是想为爬你屋顶的事道歉。因为谣言不是真的，对吧？"

translate chinese chinese_0901475_451:
    old "Hehe, of course not. Seriously, kids these days have some imagination."
    new "嘿嘿，当然不是。 seriously, 小孩子现在的想象力真是丰富。"

translate chinese chinese_4309241_452:
    old "But now it's not the time for that, it's very late and I think you need to go home."
    new "但是现在不是做这个的时候，已经很晚了，我觉得你需要回家了。"

translate chinese chinese_3029388_453:
    old "You're right, sorry for bothering you with all of this."
    new "你说得对，对不起打扰你这么多。"

translate chinese chinese_4428023_454:
    old "And don't worry, I'll come soon to keep working on the roof."
    new "别担心，我很快就会来继续修屋顶的。"

translate chinese chinese_6761220_455:
    old "I really appreciate your help. Have a good night."
    new "真的很感谢你的帮助。晚安。"

translate chinese chinese_5564068_456:
    old "Hello again lady Dimitrescu. How are you today?"
    new "德米特雷斯库女士，又见面了。今天怎么样？"

translate chinese chinese_0765626_457:
    old "Hello [pla], I'm fine. You've come to keep working on the roof?"
    new "你好[pla]，我很好。你是来继续在屋顶工作的吗？"

translate chinese chinese_5357902_458:
    old "Yes ma'am. I'm going to get to it right away. So, I can finish it as soon as I can."
    new "好的，我马上开始，争取尽快完成。"

translate chinese chinese_0433671_459:
    old "Oh perfect. Well, I'll leave you to it. If you need me, I'm in the room next door."
    new "哦，太好了。那我就不打扰了。你需要我的话，我就在隔壁房间。"

translate chinese chinese_6850766_460:
    old "Excuse ma'am, but before I go home, there's something else I'd like to ask you about."
    new "对不起，女士，在我回家之前，还有一件事想问您。"

translate chinese chinese_0722957_461:
    old "Perhaps another rumor?"
    new "或许是另一个谣言？"

translate chinese chinese_9033175_462:
    old "No, no. Nothing like that. It's just... After I fell and passed out. I remember waking up for a brief moment. "
    new "不，不是那样的。就是……我摔倒昏迷后，记得短暂醒过一次。"

translate chinese chinese_5000250_463:
    old "And I could swear I saw you with someone else, watching me."
    new "而且我发誓我看到你和别人在一起，看着我。"

translate chinese chinese_6916672_464:
    old "S- someone else, heh... What do you mean?"
    new "有、有人 else，哈哈……你是说什么意思？"

translate chinese chinese_3171503_465:
    old "Well, I saw two young ladies, they kinda looked like you. But I'm not sure..."
    new "嗯，我看到了两个年轻女士，长得有点像你。但我不确定……"

translate chinese chinese_8562028_466:
    old "Hmm, sorry [pla], but I was alone when I picked you up."
    new "嗯，对不起[pla]，但我捡到你的时候是独自一人。"

translate chinese chinese_6755194_467:
    old "I think you must have seen some kind of hallucination or something."
    new "我觉得你一定是看到了某种幻觉之类的东西。"

translate chinese chinese_6141089_468:
    old "Are you sure? It felt so real..."
    new "你确定吗？感觉那么真实……"

translate chinese chinese_4908475_469:
    old "Yes I'm sure. Now, It's getting very late, so you should go home now."
    new "是的，我很确定。现在很晚了，你应该回家了。"

translate chinese chinese_7074911_470:
    old "Hmm, ok. I think you're right. Bye ma'am."
    new "嗯，好吧。我觉得你说得对。再见女士。"

translate chinese chinese_3177870_471:
    old "Have a good night, [pla]."
    new "晚安，[pla]。"

translate chinese chinese_1806832_472:
    old "Ok! That's it for today. It's almost done."
    new "好！今天就到这里。差不多完成了。"

translate chinese chinese_4947411_473:
    old "Wow! Look at how much you have done already! I think you only need to come back one more time and you will have finished."
    new "哇！你看你已经做了这么多！我觉得你再回来一次就能完成了。"

translate chinese chinese_5831855_474:
    old "Thank you ma'am, I'm happy you like how the repairs are going, I also think I only need to come once more, and it'll be ready."
    new "谢谢您，很高兴您对修理工作满意，我觉得我再来一次就可以了，到时候就能完成了。"

translate chinese chinese_0185667_475:
    old "I'm astounded at how fast you are, you're a very good worker."
    new "我对你这么快的速度感到惊讶，你真是个好员工。"

translate chinese chinese_1282926_476:
    old "Thank you very much!"
    new "非常感谢！"

translate chinese chinese_5848165_477:
    old "Well, I think I'll head home. I'll be sure to come back and finish."
    new "好吧，我想我该回家了。我一定会回来完成的。"

translate chinese chinese_7870959_478:
    old "Wait! [pla]"
    new "等一下！[pla]"

translate chinese chinese_8287848_479:
    old "Yes? Is there a problem?"
    new "怎么了？有什么问题吗？"

translate chinese chinese_3893198_480:
    old "A problem? No, no, nothing like that, I just wanted to thank you once again for how well the repairs are going."
    new "有问题吗？不，不，没什么那样的事，我只是想再次感谢你，修理工作进行得很顺利。"

translate chinese chinese_9754970_481:
    old "Being completely honest, I didn't think you were actually going to do it. But I'm glad I was wrong."
    new "说实话，我没想到你真的会这么做。不过我很高兴我错了。"

translate chinese chinese_0560599_482:
    old "Well, it's not a problem at all. It was my fault that the roof broke in the first place, I feel like it's only fair that I handle the repairs."
    new "嗯，这根本不是问题。屋顶本来就是因为我才破的，我觉得我来修理是理所应当的。"

translate chinese chinese_7058177_483:
    old "Well, I'm happy that you're such an upstanding young man."
    new "好吧，我很高兴你是个如此正直的年轻人。"

translate chinese chinese_3005532_484:
    old "And another thing..."
    new "还有一件事……"

translate chinese chinese_2711180_485:
    old "Yes?"
    new "怎么了？"

translate chinese chinese_8419655_486:
    old "It's about those rumors that you mentioned. The truth is I have actually heard of them as well."
    new "说的就是你提到的那些传言。其实我也听说过。"

translate chinese chinese_9676633_487:
    old "You knew about them?"
    new "你知道他们的事情？"

translate chinese chinese_1859853_488:
    old "Of course I did. it's difficult not to notice when people look at me and murmur wherever I go."
    new "当然注意到了。我走到哪儿都有人盯着我看，还小声议论，很难不注意到。"

translate chinese chinese_5965571_489:
    old "But some people are even worse, they come to my house and try to sneak in, or to get pics of the 'vampire lady'."
    new "但有些人更过分，他们跑到我家来偷拍，想搞到所谓的“吸血鬼女士”的照片。"

translate chinese chinese_0822980_490:
    old "It's really stressful, so I was a bit cautious of your intentions at first."
    new "真的很紧张，所以最开始对你有点小心谨慎。"

translate chinese chinese_7245581_491:
    old "Ohh, I- I see, I'm sorry things are like that. It must be so awkward to have to deal with that all the time."
    new "哦，我——我明白了，对不起事情变成这样。一直得应付这个肯定很尴尬。"

translate chinese chinese_6871767_492:
    old "Oh yeah, it's tremendously stressful... Actually, there is a reason why those rumours exist."
    new "哦对，压力真的很大……实际上，那些传言的存在是有原因的。"

translate chinese chinese_3974070_493:
    old "Uhh? What do you mean?"
    new "嗯？什么意思？"

translate chinese chinese_0662264_494:
    old "Well, as I said, I was a bit cautious of you, but I think you've managed to keep your word."
    new "嗯，就像我说的，我一开始对你有点警惕，但我觉得你还是守信了。"

translate chinese chinese_0967752_495:
    old "And I realize I haven't been completely honest with you..."
    new "我意识到我还没完全对你坦白……"

translate chinese chinese_5674329_496:
    old "So, let me tell you the truth; it would be good if at least one person in town knows things as they really are."
    new "所以，让我告诉你真相；至少镇上有人知道事情的真相也是好的。"

translate chinese chinese_9239400_497:
    old "I suffer from a rare condition in which my body is unable to produce a certain type of amino acid."
    new "我患有一种罕见的疾病，身体无法产生某种氨基酸。"

translate chinese chinese_9971418_498:
    old "Not all of them, but this particular one is very important. Do you know what that means [pla]?"
    new "不是全部，但这个特别重要。你知道那意味着什么[pla]吗？"

translate chinese chinese_1805967_499:
    old "Hmm, not really."
    new "嗯，不太行。"

translate chinese chinese_5210180_500:
    old "Haha, it means that I'm unable to produce and store a type of protein that the body needs to function properly."
    new "哈哈，意思是我无法产生和储存身体正常运作所需的一种蛋白质。"

translate chinese chinese_3843825_501:
    old "Ohh..."
    new "哦……"

translate chinese chinese_0869010_502:
    old "As I said, it's not all of them, I'd be dead if it was like that. But this one is crucial nonetheless."
    new "就像我说的，并不是所有的都是那样，如果是那样我早就挂了。但这个依然至关重要。"

translate chinese chinese_5503617_503:
    old "Nor am I able to absorb it from the usual sources, like meat and vegetables."
    new "我也无法从平常的来源，比如肉和蔬菜中吸收它。"

translate chinese chinese_9724787_504:
    old "So, does that mean your health is in danger?"
    new "那么，这意思是你的健康有危险吗？"

translate chinese chinese_8319981_505:
    old "Hmm kind of. My body it's very delicate to certain things. For example, I'm unable to go directly into the sunlight."
    new "嗯，算是吧。我的身体对某些东西很敏感。比如，我不能直接暴露在阳光下。"

translate chinese chinese_9497158_506:
    old "If I did, I would start suffering from strong allergic reactions. So, every time I go outside it has to be during the nighttime."
    new "如果我真的那样做，我会开始出现强烈的过敏反应。所以每次出去都必须选在晚上。"

translate chinese chinese_9938558_507:
    old "Ohh, so, is that why people think you're a vampire?"
    new "哦，所以人们以为你是吸血鬼就是因为这个？"

translate chinese chinese_8335390_508:
    old "Well, that and my appearance, that's also the result of my disease."
    new "嗯，还有我的外表，这也是我的病造成的。"

translate chinese chinese_0686411_509:
    old "This amino acid helps with the creation of melanin, which is what gives colour to the skin."
    new "这种氨基酸有助于生成黑色素，也就是给皮肤上色的物质。"

translate chinese chinese_4448188_510:
    old "So I'm very white, and my eyes are pale."
    new "我皮肤很白，眼睛也很淡。"

translate chinese chinese_7867605_511:
    old "Oh, I get it now."
    new "哦，我现在明白了。"

translate chinese chinese_1851486_512:
    old "Yeah, and I understand them, if somebody who looks like me it's only seen outside at night. And well... people talk..."
    new "是的，我能理解他们，像我这样的人只有晚上才在外面出现。而且……人们爱议论纷纷……"

translate chinese chinese_4197290_513:
    old "But, it's not fair, I mean, you can't judge people just because of their appearance."
    new "但是，这不公平，我的意思是，不能因为外表就评判一个人。"

translate chinese chinese_8156631_514:
    old "Well, is not just that. The thing is, since I'm unable to produce this substance, I have to obtain it from a different source."
    new "好吧，不只是那样。问题是，由于我无法产生这种物质，我必须从其他来源获得它。"

translate chinese chinese_5794207_515:
    old "But you said you couldn't get it from food either..."
    new "但是你说过也不能从食物中获取……"

translate chinese chinese_1109483_516:
    old "That's right, I can't get it from food. But there's something else that can help me."
    new "没错，我不能从食物中获取。但有其他东西可以帮助我。"

translate chinese chinese_9190572_517:
    old "You see, for whatever reason I can actually receive the proteins that I need from semen."
    new "你知道吗，不管什么原因，我实际上可以从精液中获取所需的蛋白质。"

translate chinese chinese_9448798_518:
    old "So, I made a deal with some men from town that were willing to help me. That sustained me for a while..."
    new "所以，我和镇上的一些人做了个交易，他们愿意帮我。那段时间我勉强撑过去了..."

translate chinese chinese_5154025_519:
    old "Ohh, I see..."
    new "哦，我明白了……"

translate chinese chinese_9602757_520:
    old "But the problem is that for whatever reason, when I touch a man, it has a very strong effect on them."
    new "但问题是，不知道为什么，当我碰到男人的时候，对他们会有非常强烈的影响。"

translate chinese chinese_9277031_521:
    old "They caught the disease too?"
    new "他们也染上那病了？"

translate chinese chinese_8309641_522:
    old "What? No, no, it's not that."
    new "什么？不，不是那样的。"

translate chinese chinese_4591190_523:
    old "What I have is not contagious, but it does cause certain effects on men."
    new "我身上的东西不会传染，但确实会对男人产生某些影响。"

translate chinese chinese_7737285_524:
    old "So anytime one of them helped me. They would be very drained afterwards."
    new "所以每次他们帮我之后都会非常疲惫。"

translate chinese chinese_3962772_525:
    old "They ended up looking pale and famished. That's probably where the vampire myth mostly comes from."
    new "他们最后看起来脸色苍白，饿得不行。吸血鬼的传说可能大多来源于此。"

translate chinese chinese_4997155_526:
    old "Oh, I understand..."
    new "哦，我明白了……"

translate chinese chinese_3993135_527:
    old "And as you know, there is a very large religious community in this town."
    new "而且你知道，这个镇上有一个非常大的宗教团体。"

translate chinese chinese_7475938_528:
    old "Many women got worried that I would hurt their husbands, and even worse, that I would steal them."
    new "很多女人都担心我会伤害她们的丈夫，甚至更糟，会把她们的丈夫抢走。"

translate chinese chinese_9076273_529:
    old "And seeing how tired the men were after helping me, the rumors began to circulate."
    new "看到那些帮我的人累成那样，谣言就开始传开了。"

translate chinese chinese_0948423_530:
    old "I see, I think I now understand better where the legend comes from."
    new "我明白了，我现在更清楚这个传说的来源了。"

translate chinese chinese_9176073_531:
    old "But still, your disease is no reason for them to be talking that way about you."
    new "但是，你的病并不是他们那样谈论你的理由。"

translate chinese chinese_9947544_532:
    old "I'm sorry ma'am, because not only do you have to take care of your condition. You also have to deal with the town's scorn."
    new "对不起，女士，因为你不仅要应对自己的病情，还要承受镇上的鄙视。"

translate chinese chinese_3669683_533:
    old "It's really nice of you to say that, thank you. But I'm used to it already."
    new "你这么说真好，谢谢。但我已经习惯了。"

translate chinese chinese_5753729_534:
    old "The only thing that really affects me is that I haven't been able to get the protein I need as of late."
    new "唯一影响我的是最近没能得到我需要的蛋白质。"

translate chinese chinese_9125217_535:
    old "Wait, so does that mean nobody is helping you right now? So, how do you meet your protein needs then?"
    new "等一下，那是不是意味着现在没人帮你？那你是怎么满足蛋白质需求的呢？"

translate chinese chinese_2944287_536:
    old "Hmm, not really, it is true that nobody comes here anymore. "
    new "嗯，确实，没人再来这里了。"

translate chinese chinese_2230486_537:
    old "But I have a deal with the hospital, having a certificate for my condition allows me to receive some semen supplies from them."
    new "但我跟医院有协议，有了我病情的证明，他们就会给我提供一些精液供应。"

translate chinese chinese_1144077_538:
    old "It all comes from donation to the sperm bank of the hospital. They give them to me because it's for the treatment of a medical condition."
    new "这都是来自医院精子库的捐赠。他们给我是因为这是用于治疗一种医疗状况。"

translate chinese chinese_4442188_539:
    old "Uhh, I see."
    new "哦，我明白了。"

translate chinese chinese_8023925_540:
    old "It's not perfect, but it kind of works."
    new "虽然不完美，但多少还是管用的。"

translate chinese chinese_5905921_541:
    old "So, you see now? Why do people believe in that legend? And where did those rumours start?"
    new "所以你现在明白了吗？为什么人们会相信那个传说？那些谣言又是从哪里开始的？"

translate chinese chinese_7821005_542:
    old "Yeah, I can see it now, but I don't think it's fair!"
    new "是的，我现在看得出来，但我觉得这不公平！"

translate chinese chinese_2745837_543:
    old "You're right, it isn't, but that's how things are."
    new "你说得对，不是那样的，但事实就是如此。"

translate chinese chinese_8922999_544:
    old "And at least now you know the truth and are willing to talk to me."
    new "现在至少你知道真相了，也愿意和我谈谈。"

translate chinese chinese_0492244_545:
    old "Hmm, actually... I don't know if you're ok with me saying this."
    new "嗯，其实……我不确定你是否介意我这么说。"

translate chinese chinese_7047803_546:
    old "But I think I could do more than just listen to you."
    new "但是我觉得我不仅能听你说。"

translate chinese chinese_2974081_547:
    old "If you're ok with me doing it, I would like to help you."
    new "如果你不介意我帮忙的话，我很愿意帮你。"

translate chinese chinese_7903795_548:
    old "I mean, you said that what you get from the hospital helps, but is not enough, right?"
    new "我的意思是，你说医院给的东西有帮助，但不够，对吧？"

translate chinese chinese_6064427_549:
    old "So, I want to help you."
    new "所以，我想帮你。"

translate chinese chinese_7880951_550:
    old "That's really nice of you to say, but I don't think you understand."
    new "你这么说真的很贴心，但我感觉你可能不太明白。"

translate chinese chinese_2913755_551:
    old "I told you that the men who helped me were very drained after doing it."
    new "我跟你说过，帮我的人做完之后都累坏了。"

translate chinese chinese_8422801_552:
    old "Uhh... I mean, I could just do it in a cup or something and give it to you, right?"
    new "呃……我的意思是，我可以直接用杯子什么的弄好给你，对吧？"

translate chinese chinese_7960953_553:
    old "Not really, you see, that's the problem with the sperm I get from the hospital."
    new "其实不是这样的，你看，问题就出在我从医院得到的精子上。"

translate chinese chinese_6104232_554:
    old "I don't only get what I need from the semen, but also from the contact with the penis."
    new "我不仅从精液中获得我需要的东西，还从与阴茎的接触中获得。"

translate chinese chinese_1756004_555:
    old "So if I only receive your semen, I won't be able to extract the necessary amount."
    new "所以如果我只接收你的精液，就无法提取足够的量。"

translate chinese chinese_8855609_556:
    old "Well, I still think we can maybe do a small test and see how we do."
    new "嗯，我还是觉得我们可以先做一个小测试，看看效果如何。"

translate chinese chinese_9195718_557:
    old "I don't know. Are you sure?"
    new "我不知道。你确定吗？"

translate chinese chinese_3889780_558:
    old "Yeah, I think so. I really want to help you in any way I can."
    new "是的，我觉得可以。我真的想尽我所能帮助你。"

translate chinese chinese_8833258_559:
    old "Good, then I guess we can try testing how it goes."
    new "好的，那我们就试试看吧。"

translate chinese chinese_6836472_560:
    old "Great, so let's do it."
    new "好，那我们就这么办吧。"

translate chinese chinese_5963152_561:
    old "All right, then take out your pants."
    new "好吧，那就把裤子脱了。"

translate chinese chinese_9287407_562:
    old "I must say I'm impressed young man."
    new "我必须说，年轻人，你真让我印象深刻。"

translate chinese chinese_8168091_563:
    old "You got one of the biggest penises I have ever seen."
    new "我见过的最大阳具之一就是你的了。"

translate chinese chinese_1064711_564:
    old "It's impressive."
    new "真厉害。"

translate chinese chinese_1139290_565:
    old "Uhh... T- thank you ma'am... I guess."
    new "呃……谢谢阿姨……我想。"

translate chinese chinese_1695180_566:
    old "It's good that you can feel better ma'am. I'll do it again if you need me to."
    new "你能感觉好点真不错，女士。如果你需要的话我可以再做一次。"

translate chinese chinese_1128645_567:
    old "Hmm, you seem to be very fine. Normally when I do this with a man, they look very tired afterwards. I wonder if it's because of your age."
    new "嗯，你看起来状态很好。通常我这么做的时候，男人之后都会显得很疲惫。不知道是不是因为你的年龄呢。"

translate chinese chinese_4675059_568:
    old "I don't know what it may be. But I am a little tired. Maybe I should go home for today. But I'll come back to finish the roof."
    new "我不知道那是什么。但我有点累了。今天 maybe 我应该回家。但我会回来把屋顶弄好的。"

translate chinese chinese_3019522_569:
    old "Ok, just remember to drink a lot of water, and eat as much as you can."
    new "好的，记得多喝水，尽量多吃点。"

translate chinese chinese_3866046_570:
    old "You may not look tired, but I'm sure it must've had some effect on you. Be sure to rest."
    new "你可能不显得累，但我肯定这对你多少有些影响。一定要休息好。"

translate chinese chinese_5945990_571:
    old "I'll do, don't worry. See you later Lady Dimitrescu."
    new "我会搞定的，放心吧。回头见，迪米特雷斯库女士。"

translate chinese chinese_9503463_572:
    old "Good morning Lady Dimitrescu! I've come to continue repairing the roof."
    new "早上好，德米特雷斯库夫人！我来继续修理屋顶了。"

translate chinese chinese_5414823_573:
    old "Good morning."
    new "早上好。"

translate chinese chinese_2795133_574:
    old "You know, I must say, you don't look very tired at all. Even though I'm certain I took a lot from you."
    new "你知道吗，我必须说，你看起来一点都不累。即使我确信我从你那里拿了不少。"

translate chinese chinese_1416378_575:
    old "(Hmm, I wonder if it's because of the magic power. Maybe it protected me from the effects.)"
    new "（嗯，不知道是不是因为魔力。也许它保护了我免受那些影响。）"

translate chinese chinese_2880099_576:
    old "I don't really know what to tell you, I actually don't feel bad at all."
    new "我真的不知道该怎么跟你说，其实我一点感觉都没有。"

translate chinese chinese_1680224_577:
    old "This is a surprise. Are you sure you're ok to work on the roof today?"
    new "这真是意外。你确定今天还能上去干活吗？"

translate chinese chinese_8191774_578:
    old "Yes, don't worry, I feel great, I'm going to get to it right away. So, I can finish it as soon as I can."
    new "是的，别担心，我感觉很好，我会马上开始的。所以，我可以尽快完成它。"

translate chinese chinese_8425979_579:
    old "This is great! You really did it! Thank you so much, it's fantastic that you put in all this effort. "
    new "太好了！你真的做到了！非常感谢，你付出这么多努力真是太棒了。"

translate chinese chinese_3390765_580:
    old "It looks even better than it was before."
    new "看起来比以前更好了。"

translate chinese chinese_7889137_581:
    old "I'm happy you like it ma'am. It makes all of that effort worth it."
    new "很高兴您喜欢，女士。这让我所有的努力都变得值得了。"

translate chinese chinese_2809409_582:
    old "I don't know how to repay you."
    new "我不知道该怎么报答你。"

translate chinese chinese_3398568_583:
    old "Oh no, you don't need to pay me or anything. After all, I did the initial damage."
    new "哦不，你不用给我钱什么的。毕竟，最开始是我搞砸的。"

translate chinese chinese_3778761_584:
    old "Well, with this you have more than made up for it. Thanks again [pla]."
    new "好吧，有了这个你就完全弥补了。再次感谢你，[pla]。"

translate chinese chinese_2041678_585:
    old "Once again, I'm sorry for damaging your roof, and thank you for your patience. This took a while, but you never got angry with me."
    new "再次为损坏你的屋顶道歉，感谢你的耐心。这花了很长时间，但你从未生我的气。"

translate chinese chinese_1506890_586:
    old "Ohh, I wouldn't get angry."
    new "哦，别生气了。"

translate chinese chinese_0746744_587:
    old "As I told you, at this point I'm used to people just trying to take a peek into my house, so I was just annoyed when it happened"
    new "就像我告诉你的，到了这种地步，我已经习惯了有人想偷看我家里面的情况，所以当这事儿发生的时候我只是觉得烦。"

translate chinese chinese_7872432_588:
    old "But you've proven to me that you're a stand up young man. I'm happy I got to meet you."
    new "但你已经证明了自己是个有担当的小伙子。很高兴能遇到你。"

translate chinese chinese_9954686_589:
    old "Thank you ma'am, if there's anything else I can do for you, please tell me. I'm more than happy to do it."
    new "谢谢您，如果还有什么需要我做的，请告诉我，我很乐意帮忙。"

translate chinese chinese_5152665_590:
    old "Well... Now that you mention it, there might be..."
    new "嗯……现在你提到，可能确实有……"

translate chinese chinese_8911348_591:
    old "Really? If that's the case, please tell me. I'll do my best to help you."
    new "真的吗？如果是这样的话，请告诉我。我会尽我最大的努力帮助你。"

translate chinese chinese_9955576_592:
    old "You see, since you don't seem to be at all affected about the help you already gave me. I was wondering if I can ask for your help again."
    new "你看，因为你似乎完全不在意之前给我的帮助，我想知道我能不能再请你帮忙。"

translate chinese chinese_3770184_593:
    old "But this time it might be a little different."
    new "但这次可能会有点不同。"

translate chinese chinese_0053640_594:
    old "Different? How?"
    new "不一样？怎么个不一样法？"

translate chinese chinese_1171082_595:
    old "Let me explain, I can assimilate a lot through my digestive system, but the most efficient way of taking in the protein content is through my uterus."
    new "让我解释一下，我可以通过消化系统吸收很多东西，但最有效吸收蛋白质的方式是通过子宫。"

translate chinese chinese_0743957_596:
    old "Because that way my body can absorb it better."
    new "因为那样我的身体能更好地吸收。"

translate chinese chinese_3227796_597:
    old "Wow, does that mean you have to have sex with me?"
    new "wow, 这意思是你要和我发生性关系吗？"

translate chinese chinese_9511400_598:
    old "Well, only if you are okay with that, of course."
    new "当然，只有你同意才行。"

translate chinese chinese_5657663_599:
    old "Hmm... Well, if that actually helps you, and it's better for you, sure."
    new "嗯……好吧，如果这真的对你有帮助，而且对你更好，那当然可以。"

translate chinese chinese_9538219_600:
    old "After all, I did promise I would help you. didn't I?"
    new "毕竟，我确实答应过会帮你，不是吗？"

translate chinese chinese_5667789_601:
    old "Perfect! Thank you so much!"
    new "完美！太感谢了！"

translate chinese chinese_5045182_602:
    old "Hmm, come with me to the stairs..."
    new "嗯，跟我去楼梯那里……"

translate chinese chinese_0543567_603:
    old "That was fantastic, thank you! You have no idea how much you help me."
    new "太棒了，谢谢你！你不知道你帮我多少。"

translate chinese chinese_7706262_604:
    old "I'm happy to help... and to be honest I enjoyed it too."
    new "我很乐意帮忙……说实话，我也挺享受的。"

translate chinese chinese_5997705_605:
    old "It's very interesting that you don't get tired at all doing this with me."
    new "你和我做这个一点都不会累，这真是很有趣。"

translate chinese chinese_2163287_606:
    old "Maybe that could be of help..."
    new "也许那个能帮上忙……"

translate chinese chinese_6804392_607:
    old "Uhh, what do you mean?"
    new "呃，你的意思是什么？"

translate chinese chinese_9864327_608:
    old "Well, there's something I must let you know."
    new "嗯，有件事我必须告诉你。"

translate chinese chinese_2751128_609:
    old "Do you remember what you told me about the night you fell in here? That you saw me with two other girls?"
    new "你还记得你告诉我的，关于你掉进这里那个晚上，你说你看到我和另外两个女孩在一起的事情吗？"

translate chinese chinese_0871586_610:
    old "Yeah, the girls from my dream."
    new "对，就是我梦里的那些女孩。"

translate chinese chinese_5777428_611:
    old "Well, actually they're my daughters. Or at least that's what I call them."
    new "其实她们是我的女儿。或者说，我这么称呼她们。"

translate chinese chinese_0175428_612:
    old "You see, years ago I found out I'm not the only person with my condition."
    new "你知道吗，几年前我发现自己不是唯一一个有这种状况的人。"

translate chinese chinese_2659496_613:
    old "There are some other people, and I decided to help them. That's why I have this mansion, to receive people like me, and give them a hand."
    new "还有一些其他人，我决定帮助他们。这就是为什么我有这座庄园，来接待像我这样的人，并给他们提供帮助。"

translate chinese chinese_2339856_614:
    old "Really? So, you live with several people here? I haven't seen them."
    new "真的吗？所以，你和好几个人住在这里？我还没见过他们呢。"

translate chinese chinese_7657244_615:
    old "Right now it's only me and my two daughters. With the years some have come and go."
    new "现在只有我和我的两个女儿。这些年里，有些人来了又走。"

translate chinese chinese_3684830_616:
    old "We communicate with each other every time anyone finds anything that can help us."
    new "每次有人找到能帮我们的东西，我们就互相沟通。"

translate chinese chinese_2995177_617:
    old "Oh, it's a very nice gesture of you that you take people in and help them. You really are a good person."
    new "哦，你收留并帮助别人，真是个很好的举动。你真是个好人。"

translate chinese chinese_8004012_618:
    old "Thank you, I'm glad you think that about me."
    new "谢谢，我很高兴你这么认为。"

translate chinese chinese_4465143_619:
    old "And yeah, we help each other cope with the condition. And since it's such a rare thing, it's really useful that we are all close to each other."
    new "而且是的，我们互相帮助应对这种情况。因为这真的很罕见，所以我们彼此亲近非常有用。"

translate chinese chinese_7492415_620:
    old "And you see, since you've now been able to help me twice, and don't seem to be affected..."
    new "而且你看，既然你现在能帮我两次了，而且看起来不受影响..."

translate chinese chinese_8398487_621:
    old "I was wondering if you could also help my two daughters."
    new "我在想你能不能也帮我两个女儿一下。"

translate chinese chinese_5595130_622:
    old "Oh! I see."
    new "哦！我明白了。"

translate chinese chinese_2927926_623:
    old "I would love it if you could. They could really use your help to improve their health."
    new "如果你能做到的话就太好了。他们真的很需要你的帮助来改善健康状况。"

translate chinese chinese_6398851_624:
    old "Well, I think that if I really did help you treat your condition. I don't see why it couldn't do it for you daughters."
    new "嗯，我觉得如果我真的帮你治疗了你的病情，那对你女儿们也应该有效。"

translate chinese chinese_3853550_625:
    old "You're an angel. Then I'll talk to them, so that you can help them as soon as possible."
    new "你真是个天使。那我来跟他们谈谈，让你能尽快帮上忙。"

translate chinese chinese_2920773_626:
    old "Is that ok with you?"
    new "这样行吗？"

translate chinese chinese_8836785_627:
    old "All right, have a good night [pla]."
    new "好吧，晚安[pla]。"

translate chinese chinese_9702463_628:
    old "Good night to you too, Lady Dimitrescu."
    new "晚安，迪米特雷斯库女士。"

translate chinese chinese_6996585_629:
    old "Good morning ma'am, I'm here to help you as we talked before."
    new "早上好，女士，我是来帮您的，就像之前说的那样。"

translate chinese chinese_1176951_630:
    old "Good morning. I'm happy to see that you actually came."
    new "早上好。很高兴看到你真的来了。"

translate chinese chinese_3431666_631:
    old "Allow me to introduce you to my daughters. These are Bela and Daniela."
    new "让我给你介绍一下我的女儿们。她们是贝拉和达妮埃拉。"

translate chinese chinese_9777773_632:
    old "This is [pla] he's the one I've told you about and has come to help us with our condition."
    new "这是[pla]，我之前跟你说过的，他来帮我们处理这个问题了。"

translate chinese chinese_0403765_633:
    old "H- hi. I'm Bela, nice to meet you."
    new "嗨。我是贝拉，很高兴见到你。"

translate chinese chinese_4499918_634:
    old "Hello, I'm Daniela, mother has told us about you, and what you're able to do for us. Thank you very much for coming."
    new "你好，我是Daniela，妈妈已经跟我们提到过你，还有你能为我们做的事情。非常感谢你能来。"

translate chinese chinese_7842880_635:
    old "N- nice meeting you. I'm [pla], happy to be of help."
    new "N- 很高兴见到你。我是[pla]，很高兴能帮忙。"

translate chinese chinese_6954824_636:
    old "Well, now that the introductions are over, I think it's best if we start."
    new "好吧，既然介绍完了，我觉得我们最好开始吧。"

translate chinese chinese_1168484_637:
    old "Uhh... Right now? And just like that?"
    new "呃……现在吗？就这样？"

translate chinese chinese_3836504_638:
    old "Well, have in mind my daughters really needs it, and we use to do it in the past with other guys..."
    new "好吧，你得知道我女儿真的需要这个，而且我们以前也和其他人这么做过……"

translate chinese chinese_4004607_639:
    old "So, don't worry, just relax, and let us do all for you."
    new "所以，别担心，放松，让我们来为你搞定一切。"

translate chinese chinese_2758025_640:
    old "Mmmm, look at that, you're already in the mood for it..."
    new "嗯，看看，你都已经开始兴奋了……"

translate chinese chinese_7092159_641:
    old "Oh wow! Look at what you're packing there."
    new "哦 wow！看看你这身材。"

translate chinese chinese_9082507_642:
    old "Daniela darling, please, you don't have to be this forward."
    new "丹妮拉宝贝，请不要这么主动。"

translate chinese chinese_0290107_643:
    old "But mother, it is true that's an impressive size."
    new "但是妈妈，那确实是个惊人的尺寸。"

translate chinese chinese_9735653_644:
    old "Hehe, we can't deny that..."
    new "嘿嘿，这个我们可否认不了..."

translate chinese chinese_0169203_645:
    old "But remember, we're doing this for a reason, so control yourselves."
    new "但是记住，我们这么做是有原因的，所以克制点。"

translate chinese chinese_6105280_646:
    old "Yes, mother."
    new "好的，妈妈。"

translate chinese chinese_2515160_647:
    old "Now, I think we've talked enough."
    new "现在，我觉得我们聊得够多了。"

translate chinese chinese_7994861_648:
    old "Are you ready [pla]?"
    new "你准备好了吗 [pla]?"

translate chinese chinese_5132387_649:
    old "By the way, how are you feeling [pla]?"
    new "对了，你觉得怎么样，[pla]？"

translate chinese chinese_4639829_650:
    old "Well, to be honest I'm a little tired. But it's nothing a nap and some food won't fix. I'll be ok."
    new "说实话，我有点累了。但小睡一下吃点东西就好了，我会没事的。"

translate chinese chinese_7003674_651:
    old "I must admit your endurance is astounding."
    new "我必须承认，你的耐力真是惊人。"

translate chinese chinese_7727647_652:
    old "But I'm happy you're fine."
    new "但是我很高兴你没事。"

translate chinese chinese_9425387_653:
    old "And I'm happy I can be of help to you all."
    new "而且我很高兴能帮到大家。"

translate chinese chinese_8982246_654:
    old "Honestly, our health had been going down due to not being able to get enough semen for all three of us."
    new "说实话，我们的健康状况一直下降，因为三个人根本得不到足够的精液。"

translate chinese chinese_0184294_655:
    old "And even if the hospital donated more, it's not the same thing as receiving it directly from a person."
    new "就算医院多捐一些，也比不上直接从个人那里收到的好。"

translate chinese chinese_0943938_656:
    old "Hmm, does that mean that if no one else helps you, you'll be in trouble again?"
    new "嗯，那是不是意味着如果没有别人帮你，你又会陷入麻烦了？"

translate chinese chinese_9497305_657:
    old "Sadly it does."
    new "可惜确实如此。"

translate chinese chinese_0739659_658:
    old "Then I'll be sure to come back again and help you. I'll do it as many times as you need me to."
    new "那我一定会再回来帮你。你需要多少次我都行。"

translate chinese chinese_9072602_659:
    old "Hmm are you sure? I understand that one time is something. But if you do too many times it might affect you."
    new "嗯，你确定吗？我明白一次是例外。但如果你做得太频繁，可能会影响你的。"

translate chinese chinese_7167309_660:
    old "I think I could keep helping you some more, given that so far I haven't had any negative reaction."
    new "我觉得我可以继续帮你，毕竟到目前为止我没有任何不良反应。"

translate chinese chinese_1162972_661:
    old "So you can count on me."
    new "所以你可以相信我。"

translate chinese chinese_6338232_662:
    old "Aww, you're an angel. Well then, when we need it, we'll be sure to call you on."
    new "哎呀，你真是个天使。好吧，到时候我们需要的话，一定会联系你的。"

translate chinese chinese_6012359_663:
    old "Hi Lady Dimitrescu."
    new "你好，德米特雷斯库夫人。"

translate chinese chinese_6715142_664:
    old "Oh, hi [pla], it's always nice to see you."
    new "哦，嗨 [pla]，见到你总是很高兴。"

translate chinese chinese_8662819_665:
    old "How can I help you today?"
    new "今天我能帮你什么？"

translate chinese chinese_5930470_666:
    old "Help them again"
    new "再帮他们一次"

translate chinese chinese_7074378_667:
    old "Well, I have been thinking about helping you again."
    new "其实，我一直在想着再帮你一次。"

translate chinese chinese_2701255_668:
    old "Oh, have you come help us with our protein needs?"
    new "哦，你是来帮我们补充蛋白质的吗？"

translate chinese chinese_2102214_669:
    old "That's right, I thought you might need it."
    new "没错，我想你可能需要它。"

translate chinese chinese_1223631_670:
    old "That's perfect, you came at just the right moment."
    new "太好了，你来的正是时候。"

translate chinese chinese_9343798_671:
    old "Let me call the girls."
    new "让我来叫她们。"

translate chinese chinese_4886093_672:
    old "Hi [pla]! How are you?"
    new "嗨 [pla]！你好吗？"

translate chinese chinese_0254428_673:
    old "I'm fine, thank you, I came to see if you needed my help today."
    new "我挺好的，谢谢，我来看看今天需不需要帮忙。"

translate chinese chinese_0421483_674:
    old "Yeah, mother told us."
    new "嗯，妈妈告诉我们的。"

translate chinese chinese_4591587_675:
    old "What?! Oh no, sorry, I was just a little distracted."
    new "什么?! 哦不，对不起，我刚才只是有点分心。"

translate chinese chinese_7334561_676:
    old "Hmm, I see, well, be careful on the way back."
    new "嗯，我知道了，路上小心。"

translate chinese chinese_8815650_677:
    old "Yes ma'am, bye."
    new "好的，再见。"

translate chinese chinese_3204132_678:
    old "Oh, sorry, I was just passing by."
    new "哦，对不起，我刚才只是路过。"

translate chinese chinese_6907593_679:
    old "Hmm, I see, well, make sure you come when you have some free time."
    new "嗯，我知道了，不过记得有空的时候过来哦。"

translate chinese chinese_1429285_680:
    old "Yes ma'am, of course. See you later."
    new "好的好的，回头见。"

translate chinese chinese_5162489_681:
    old "Bye, take care."
    new "再见，保重。"

# auto-tl Qwen Colab

translate chinese chinese_9305299_0:
    old "I can't believe they were getting freaky in the living room."
    new "真不敢相信他们在客厅里做那种事。"

translate chinese chinese_6480868_1:
    old "I know they are married but... they should do that in their room..."
    new "我知道他们结婚了，但是……这种事情应该在房间里做……"

translate chinese chinese_3417994_2:
    old "Anyway... let's take a look at this weird book."
    new "不管怎样……咱们来看看这本奇怪的书。"

translate chinese chinese_3188887_3:
    old "Let's see what it says..."
    new "看看它写了什么……"

translate chinese chinese_4317209_4:
    old "Expergiscimini defensoris librum... The hell does that mean? Did that airplane came from China?"
    new "Expergiscimini defensoris librum... 这是什么意思？那架飞机是从中国来的吗？"

translate chinese chinese_1306790_5:
    old "A TUTELA EXPERGISCIMINI!!!"
    new "A TUTELA EXPERGISCIMINI!!!"

translate chinese chinese_3799018_6:
    old "What the fuck! What is this?!"
    new "妈的！这是什么！"

translate chinese chinese_3792252_7:
    old "Qui audet excitare me!"
    new "Qui audet excitare me!"

translate chinese chinese_6793557_8:
    old "Oh my God! Please don't hurt me. I'm too young to die."
    new "天啊！求你不要伤害我。我还太年轻，不想死。"

translate chinese chinese_3359303_9:
    old "Latina loqui tibi."
    new "Latina loqui tibi."

translate chinese chinese_2614243_10:
    old "What?  I- I don't understand. Just please don't kill me... I didn't do anything... This thing just fell from an airplane..."
    new "什么？我—我不明白。求你不要杀我……我没做什么……这东西只是从飞机上掉下来的……"

translate chinese chinese_5982795_11:
    old "Huh? What fell from an airplane?"
    new "huh?什么从飞机上掉下来了？"

translate chinese chinese_7996029_12:
    old "What? Oh, um, yeah! The book... This book fell from an airplane."
    new "什么？哦，嗯，对！这本书……这本书是从飞机上掉下来的。"

translate chinese chinese_4870620_13:
    old "Oooh, hehe. Let's start from the beginning, shall we?"
    new "哦哦，嘿嘿。要不我们从头开始吧？"

translate chinese chinese_4989490_14:
    old "Nice to meet you!  My name is Brixxida."
    new "很高兴见到你！我叫Brixxida。"

translate chinese chinese_3887662_15:
    old "Bri... xxi... da? Da fuck? Do you speak English?"
    new "布里... xxii... 达？你在说什么？你说英语吗？"

translate chinese chinese_3401985_16:
    old "Well, yes! I'm speaking it now. Hehe. I can actually speak all human languages..."
    new "嗯，是啊！我现在就说出来了。嘿嘿。我实际上能说所有的人类语言..."

translate chinese chinese_0014908_17:
    old "Human languages? That's a weird way to say it. What exactly are you?"
    new "人类语言？这么说挺奇怪的。你到底是什么？"

translate chinese chinese_1646245_18:
    old "I'm the protective shinigami of the book you have there."
    new "我是你手里那本书的守护死神。"

translate chinese chinese_9094206_19:
    old "OH FUCK! A shinigami? Oh my God..."
    new "噢操！死神？天啊..."

translate chinese chinese_7963822_20:
    old "I'm so sorry, miss shinigami lady. I just found this on the ground and I picked it up. Brought it home. It looked cool."
    new "真的很抱歉，死神小姐。我只是在地上发现了这个，就捡了起来，带回家了。因为它看起来很酷。"

translate chinese chinese_8133136_21:
    old "I didn't mean to-"
    new "我不是想-"

translate chinese chinese_7510326_22:
    old "Calm down, human. Hehe. If you were the one who found and opened the book, it means that you are the 'chosen One'."
    new "冷静点，人类。嘿嘿。如果你是找到并打开这本书的人，那就说明你是“被选中的那个人”。"

translate chinese chinese_2655553_23:
    old "Cho-sen-one?"
    new "Cho-sen-one?"

translate chinese chinese_4703537_24:
    old "That's right!  And now the book belongs to you. And that also means I now belong to you. Hehe"
    new "没错！现在这本书属于你了。这也意味着我现在属于你了。嘿嘿"

translate chinese chinese_0636631_25:
    old "What? You belong to me?  That means you are not going to kill me?"
    new "什么？你是我的？那意思是你不打算杀我了？"

translate chinese chinese_9166591_26:
    old "No, of course not. Why would you think that?"
    new "不，当然不会。你为什么会这么想？"

translate chinese chinese_0297475_27:
    old "Because you look like a monster about to devour me."
    new "因为你看起来像要吃掉我的怪物。"

translate chinese chinese_6088767_28:
    old "Oh? Sorry about that."
    new "哦？抱歉啊。"

translate chinese chinese_8814485_29:
    old "...Is this form better? Hehe."
    new "……这个姿势好一点吗？嘿嘿。"

translate chinese chinese_2684641_30:
    old "Why are you making that face, [pla]?"
    new "你为什么做出那副表情，[pla]？"

translate chinese chinese_9760843_31:
    old "[mo2]... It is not what it looks like… I can explain... she is... naked... but she is... a shinigami-"
    new "[mo2]……不是这样的……我可以解释……她……裸着……但是她是死神……"

translate chinese chinese_1821412_32:
    old "What?! What are you talking about? Were you watching porn again?"
    new "什么?! 你在说什么？你又在看黄片吗？"

translate chinese chinese_4678388_33:
    old "What? Porn... No. I was just-"
    new "什么？色情……不。我只是——"

translate chinese chinese_9636022_34:
    old "Hmm... probably were. You fucking pervert... I'll just have your [mo1rel] talk to you about this."
    new "嗯……大概吧。你这个色狼……我就让[mo1rel]来和你谈谈这个。"

translate chinese chinese_6414127_35:
    old "Finish whatever you were doing."
    new "把你刚才做的事情做完。"

translate chinese chinese_7364895_36:
    old "What the hell? Didn't she see you?"
    new "怎么回事？她没看到你吗？"

translate chinese chinese_2675243_37:
    old "Only you can see or hear me... And she called you [pla]? Is that your name?"
    new "只有你能看到或听到我……而且她叫你[pla]？那是你的名字吗？"

translate chinese chinese_6632390_38:
    old "Yes, that's my name. And-um, why are you naked???"
    new "是的，那是我的名字。而且——咦，你为什么光着身子？？？"

translate chinese chinese_5891309_39:
    old "Oh, I'm sorry! Hehe. I took human form to be more familiar to you, but I forgot that humans cover their bodies with 'clothing'."
    new "哦，对不起！嘿嘿。我变成人类形态是为了让你更熟悉，但忘了人类会用“衣服”遮住身体。"

translate chinese chinese_3304523_40:
    old "Couldn't find anything that covers you a little bit more, huh? But at least nobody can see you. Now tell me again, who are you exactly?"
    new "找不到能多遮掩一点的衣服吗？不过至少没人能看到你。再告诉我一次，你到底是谁？"

translate chinese chinese_3238435_41:
    old "I am Brixxida! A shinigami. I can shift and adapt to the form of any species, although my true form is this... "
    new "我是Brixxida！一个死神。我可以变形并适应任何物种的形态，虽然我的真实形态就是这个..."

translate chinese chinese_6573315_42:
    old "...I am now much smaller, but I like being this size. Much more comfortable. Hehe"
    new "……我现在变小了很多，但喜欢这个尺寸。舒服多了。嘿嘿"

translate chinese chinese_7613296_43:
    old "Ok, ok. I get it now. I'm going crazy. This isn't real. It's a dream! Yeah, that's it! It's a dream..."
    new "好吧，好吧。我现在明白了。我快疯了。这不真实。这只是个梦！对，就是这样！这只是个梦……"

translate chinese chinese_9899039_44:
    old "I fell asleep in class and soon I'm going to wake up... hmmm... I am going to wake up now.... hmmm."
    new "我在课堂上睡着了，很快就要醒来了……嗯……我要醒来了……嗯。"

translate chinese chinese_1522364_45:
    old "I'm trying to wake up from this dream."
    new "我正试图从这个梦中醒来。"

translate chinese chinese_5640124_46:
    old "You look wide awake to me, [pla]."
    new "你看起来精神得很呢，[pla]。"

translate chinese chinese_0409709_47:
    old "That's right!  I'm too tired, so I should rest. And tomorrow I will be back to normal."
    new "没错！我太累了，应该休息一下。明天就会恢复正常了。"

translate chinese chinese_3972200_48:
    old "Yes, yes. I'm going to sleep... "
    new "好啦好啦，我要睡觉了……"

translate chinese chinese_1147716_49:
    old "Ok! Goodnight. Hehe."
    new "好啦！晚安。嘿嘿。"

translate chinese chinese_5593539_50:
    old "Hmm... what a weird ass dream. I gotta lay off playing so many weird visual novels..."
    new "嗯……真是个奇怪的梦。我得少玩些奇怪的视觉小说了……"

translate chinese chinese_9102633_51:
    old "What are visual novels?"
    new "什么是视觉小说？"

translate chinese chinese_5146333_52:
    old "Oh shit!  You... and you're naked again!"
    new "哦shit！你……而且你又裸着！"

translate chinese chinese_2787370_53:
    old "Oh, my mistake.  I'm sorry. You humans are very dramatic about this... "
    new "哦，我的错。对不起。你们人类对这个很夸张……"

translate chinese chinese_2113485_54:
    old "Ok, ok. Just explain to me, Brixxida, why did the book fall from the sky?"
    new "好啦好啦。给我解释一下，Brixxida，那本书为什么会从天而降？"

translate chinese chinese_1303000_55:
    old "The book chooses you! Now you are part of a tradition of sorcerers that can use the book's magical powers."
    new "书会选中你！现在你已经成为了一名可以使用这本书魔力的巫师，传承了这一传统。"

translate chinese chinese_1269571_56:
    old "Magic powers, you say?...  The hell-?"
    new "你说的是魔法力量？... 去特么的？"

translate chinese chinese_4411627_57:
    old "[pla]?  Are you awake?  Who were you talking to?"
    new "[pla]？你醒着吗？你在跟谁说话？"

translate chinese chinese_5413612_58:
    old "Me? Oh, hmmm, nobody... I'm, uhh... preparing a speech for a class project..."
    new "我？哦，嗯，没人……我在， uh……准备一个班级项目的演讲……"

translate chinese chinese_6388003_59:
    old "Very good, [pla]!"
    new "非常好，[pla]！"

translate chinese chinese_3681367_60:
    old "Listen, I want to talk to you about yesterday... About the living room."
    new "听着，我想和你谈谈昨天的事……关于客厅的事。"

translate chinese chinese_1849885_61:
    old "Oh, [mo1], I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "哦，[vars][mo1][/vars]，我明白。你们是一对我觉得很正常的情侣……而且你是我的[vars][mo1rel][/vars]，你不用给我解释。"

translate chinese chinese_7717265_62:
    old "I'm glad to hear that. But... I do want to apologize. We were a bit careless getting... Intimate in the living room."
    new "听到这个我很高兴。但是……我也想道歉。我们在客厅里有点太不小心了……亲近了。"

translate chinese chinese_4421531_63:
    old "Don't worry about it. I actually think it's good that you keep the flame alive in your relationship over all these years."
    new "别担心，其实我觉得这些年你在关系中保持激情是件好事。"

translate chinese chinese_5684904_64:
    old "Do you really think that? Thank you so much for being so understanding, [pla]!"
    new "你真的这么认为吗？谢谢你这么理解我，[pla]！"

translate chinese chinese_5366074_65:
    old "Well, I won't bother you anymore. Please keep studying hard, honey, if you need me I will be in kitchen."
    new "好吧，我不会再打扰你了。亲爱的，如果你需要我，我会在厨房，记得好好学习。"

translate chinese chinese_5379395_66:
    old "Didn't you say they can't hear you?"
    new "你不是说他们听不见你吗？"

translate chinese chinese_2398640_67:
    old "Nope! But they can hear you! Hehe."
    new "不行！但他们能听到你哦。嘿嘿。"

translate chinese chinese_1204389_68:
    old "Oh... Ok, that makes sense... but explain everything to me again."
    new "哦……好的，那说得通……但是再把一切都解释一遍给我听吧。"

translate chinese chinese_9099197_69:
    old "What do you want to know, [pla]?"
    new "你想知道什么，[pla]？"

translate chinese chinese_1718460_70:
    old "Who are you?"
    new "你是谁？"

translate chinese chinese_9270083_71:
    old "Again, I'm Brixxida, a shinigami. I am the protector of the book you found. Hehe."
    new "再说一遍，我是Brixxida，一个死神。我是你找到的那本书的守护者。嘿嘿。"

translate chinese chinese_8481128_72:
    old "Ok. Now, where did you come from?"
    new "好的。现在，你到底是从哪里来的？"

translate chinese chinese_6317230_73:
    old "I come from another dimension. There, magic and power were natural, but that world has been destroyed."
    new "我来自另一个维度。在那里，魔法和力量是司空见惯的，但那个世界已经被摧毁了。"

translate chinese chinese_4418875_74:
    old "So... you are a time traveler?"
    new "所以……你是时间旅行者？"

translate chinese chinese_7092413_75:
    old "What? No, no... I have been asleep for hundreds of years with a spell. But when you opened and read the book, I woke up."
    new "什么？不，不……我被魔法封印睡了几百年。但当你打开并读了那本书时，我就醒来了。"

translate chinese chinese_5247022_76:
    old "Ok, I think I'm starting to understand."
    new "好的，我觉得我开始明白了。"

translate chinese chinese_7685104_77:
    old "What's this book about?"
    new "这本书讲的是什么？"

translate chinese chinese_7324866_78:
    old "Well... this book contains all the knowledge of that magical world..."
    new "嗯……这本书包含了那个魔法世界的所有知识……"

translate chinese chinese_1844089_79:
    old "Eww. So, it's like a history book?"
    new "eww. 那么，就像历史书一样？ \n\n(Note: \"eww\" is kept as is since it's an expression and doesn't have a direct translation that conveys the same feeling.)"

translate chinese chinese_5510132_80:
    old "No, silly. This book contains specific spells and mantras that enable impressive magic powers beyond human understanding."
    new "傻瓜，这本书里包含的是特定的咒语和真言，能够赋予超越人类理解的魔力。"

translate chinese chinese_6975720_81:
    old "Ok, I get that part."
    new "好的，这部分我明白了。"

translate chinese chinese_7959333_82:
    old "Magic, you say?"
    new "你说的是魔法？"

translate chinese chinese_0420639_83:
    old "Yes! The magic is a natural power that was lost, but you can get it and actually improve it..."
    new "没错！魔法是一种失落的自然力量，但你可以获得它并实际提升它..."

translate chinese chinese_4380762_84:
    old "Yeah, yeah. But... what can I do with magic?"
    new "好吧，好吧。但是……我能用魔法做什么？"

translate chinese chinese_4920934_85:
    old "Actually, there are no limits with magic! It is the most powerful force in the known universe..."
    new "实际上，魔法是没有限制的！它是已知宇宙中最强大的力量……"

translate chinese chinese_4667994_86:
    old "Really? Interesting..."
    new "真的吗？有意思……"

translate chinese chinese_1319985_87:
    old "What else do you want to know, [pla]?"
    new "你还想知道什么，[pla]？"

translate chinese chinese_3334165_88:
    old "What do I have to do?"
    new "我该做什么？"

translate chinese chinese_1676567_89:
    old "Well... you have to learn different spells and mantras to achieve powerful skills but... you will find everything in the book."
    new "嗯……你得学习不同的咒语和 mantra 才能掌握强大的技能，但是……书里什么都有。"

translate chinese chinese_4141649_90:
    old "Imperium mens et feminam. What is that? Russian or some shit?"
    new "Imperium mens et feminam. 这是什么？俄语还是什么的？"

translate chinese chinese_8950032_91:
    old "Actually, Latin is the language in which it was written... But don't worry, my job is to help the Chosen One translate..."
    new "实际上，它是用拉丁语写的……但别担心，我的工作就是帮助选中之人翻译……"

translate chinese chinese_7390106_92:
    old "Do I have to learn a lot of information about spells and mantras?"
    new "我得学一堆关于咒语和真言的知识吗？"

translate chinese chinese_7641377_93:
    old "That's right! Hehe. And gaining a lot of power!"
    new "没错！嘿嘿。而且力量大增！"

translate chinese chinese_0894721_94:
    old "Ok, I hope this is all worth it."
    new "好吧，希望这一切都是值得的。"

translate chinese chinese_9075492_95:
    old "Alright, [pla]. What else do you want to know?"
    new "好吧，[pla]。你还想知道什么？"

translate chinese chinese_9313492_96:
    old "That's the spirit!  So, look at the beginning of the book for an easy spell..."
    new "就是这种精神！那么，看看书的开头找一个简单的咒语……"

translate chinese chinese_3160264_97:
    old "Let's see here..."
    new "让我看看……"

translate chinese chinese_2386259_98:
    old "Damn, forgot. Everyone can hear me in this room. I gotta look for a better place to do this..."
    new "靠，忘了。这房间里所有人都能听到我讲话。我得找个更好的地方才行……"

translate chinese chinese_3330218_99:
    old "Hmm, probably the garage. Noone can hear me in there. Could you go there with me, Brixxida?"
    new "嗯，可能是车库吧。那里没人能听到我。你能陪我去吗，Brixxida？"

translate chinese chinese_7869474_100:
    old "I will follow you wherever you tell me."
    new "我会跟着你去任何你说的地方。"

translate chinese chinese_9814746_101:
    old "Perfect! Let's do this in the garage."
    new "完美！我们在车库里面做吧。"

translate chinese chinese_6197285_102:
    old "So? Are you ready to start?"
    new "那么，准备好了吗？"

translate chinese chinese_4152334_103:
    old "I should talk with my [mo1rel] before we begin."
    new "我应该在开始前和我的[mo1rel]谈谈。"

translate chinese chinese_1528712_104:
    old "Alright, I spoke to my [mo1rel] and explained to her that I will be in here preparing my project."
    new "好吧，我和我的[mo1rel]说了，解释了一下我得在这里准备我的项目。"

translate chinese chinese_5655728_105:
    old "So, how does all this work, Brixxida?"
    new "那么，这到底是怎么运作的，布里克西达？"

translate chinese chinese_7809623_106:
    old "Well, first you must understand the magical power..."
    new "好吧，首先你得明白这股魔力……"

translate chinese chinese_6619183_107:
    old "Magical power?"
    new "魔法力量？"

translate chinese chinese_8488705_108:
    old "Yes, you must have the magical power to be able to do any spell..."
    new "是的，你必须拥有魔法力量才能施放任何咒语……"

translate chinese chinese_0217158_109:
    old "I understand, but then how do I generate that magical power?"
    new "我明白，但是那股魔力要怎么产生呢？"

translate chinese chinese_5956888_110:
    old "Well, magical power is an energy that was produced naturally in the magical world..."
    new "好吧，魔力是在魔法世界中自然产生的能量……"

translate chinese chinese_8947896_111:
    old "Even you?"
    new "连你也是？"

translate chinese chinese_0677910_112:
    old "Yes... We feed on magical energy, when in the real world all the remaining energy has been used up, I will disappear..."
    new "是的……我们靠魔法能量为生，当现实世界中所有的能量都被耗尽时，我就会消失……"

translate chinese chinese_2390836_113:
    old "Wow... And how do we prevent magic energy from running out?"
    new "wow...那怎么防止魔法能量耗尽呢？"

translate chinese chinese_8755884_114:
    old "The magical energy will continue to run out until there be a new being so powerful that it can restore the magical world and return everything to its natural balance..."
    new "魔法能量会一直耗尽，直到出现一个足够强大的新存在，能够恢复魔法世界，并将一切恢复到自然的平衡……"

translate chinese chinese_0726420_115:
    old "That powerful being is supposed to be... me?..."
    new "那个强大的存在是……我？……"

translate chinese chinese_5353404_116:
    old "Yes.. You are the chosen one."
    new "是的……你是被选中的那个人。"

translate chinese chinese_6255338_117:
    old "Hmm, it's a lot of responsibility..."
    new "嗯，责任很大呢……"

translate chinese chinese_7044141_118:
    old "Don't worry. I know we will make it!"
    new "别担心，我知道我们会成功的！"

translate chinese chinese_3394878_119:
    old "Okay, but then how can I make spells if I don't have magic energy?"
    new "好吧，但是如果没有魔法能量，我怎么施法呢？"

translate chinese chinese_8251493_120:
    old "Well, let me think... It's really not difficult, The magic energy is in the air."
    new "嗯，让我想想……这真的不难，魔法能量就在空气中。"

translate chinese chinese_6946094_121:
    old "I can see it. What you need to do is acquire a certain skill that allows you to see it too..."
    new "我看得出来。你需要做的是获得一种技能，让你也能看到……"

translate chinese chinese_0633235_122:
    old "Agamoto's eye! With it, you can see all the particles of magical power and collect them..."
    new "阿戈摩多之眼！有了它，你可以看到所有魔法粒子并收集它们..."

translate chinese chinese_1358546_123:
    old "Whose eye?"
    new "谁的眼睛？"

translate chinese chinese_5770985_124:
    old "Agamoto's eye, is a special ability of vision. It will allow you to see many things of the magical world and expand your vision in a way never seen before by humans..."
    new "阿戈摩托之眼是一种特殊的视觉能力。它将让你看到魔法世界中的许多事物，并以人类从未见过的方式扩展你的视野……"

translate chinese chinese_2248372_125:
    old "Great. How do I get that ability then?"
    new "好啊。那我怎么获得那个能力呢？"

translate chinese chinese_2374441_126:
    old "Ohhh... Well, heh... You'll need magical power... Hahaha."
    new "哦……嗯……嘿嘿……你需要魔力……哈哈。"

translate chinese chinese_5024218_127:
    old "Really?... So how can I get magic power? If I need magic power to get magic power..."
    new "真的吗？……那我该怎么获得魔法力量呢？如果我需要魔法力量才能获得魔法力量……"

translate chinese chinese_4092062_128:
    old "Well, I think the easiest way is that I share you magic power!"
    new "嗯，我觉得最简单的方法就是我分享一些魔力给你！"

translate chinese chinese_1885156_129:
    old "You share magic power with me?"
    new "你要和我共享魔力？"

translate chinese chinese_4131873_130:
    old "Yes! As I explained to you, all magical beings are constituted of magical power."
    new "对！就像我解释过的，所有魔法生物都是由魔法力量构成的。"

translate chinese chinese_3161860_131:
    old "In fact, we are like little magnets that we are gathering magical power constantly to live."
    new "事实上，我们就像小磁铁一样，不断聚集魔法力量来维持生命。"

translate chinese chinese_3484462_132:
    old "In the magical world it was totally normal to share our magical energy with others because there were lots..."
    new "在魔法世界里，和别人分享我们的魔法能量是很正常的，因为有很多..."

translate chinese chinese_2704044_133:
    old "The problem is that in this world there is less and less, so if I share more than necessary, it could disappear forever."
    new "问题是这个世界的东西越来越少，如果我分享得过多，这些东西可能会永远消失。"

translate chinese chinese_3618203_134:
    old "Wow, it looks dangerous... So what will we do?"
    new "wow，看起来好危险……那我们该怎么办？"

translate chinese chinese_6220034_135:
    old "Bah, I'm going to share enough, and then you can return me some magical power so that nothing happens to me."
    new "好吧，我会分享足够的，然后你可以返还一些魔力给我，这样我就不会有事了。"

translate chinese chinese_3412603_136:
    old "Okay, how do you share me then?"
    new "好吧，那你怎么分享我呢？"

translate chinese chinese_2596723_137:
    old "Hmm, let's see. Take off your pants and lie on the floor..."
    new "嗯，这样吧。脱掉裤子躺在地上..."

translate chinese chinese_9126418_138:
    old "What... Why do I have to take off my pants?"
    new "什么……为什么我得脱裤子？"

translate chinese chinese_4849188_139:
    old "Oh, of course... You humans treat nudity as a taboo. Even though it's something natural..."
    new "哦，当然了……你们人类把裸体当作禁忌。即使那是很自然的事情……"

translate chinese chinese_7551166_140:
    old "Besides what we're going to do... How do you call it?... Uhh, sex!"
    new "除了我们要做什么……怎么叫来着？……嗯，性！"

translate chinese chinese_9541316_141:
    old "What the fuck!? Are we going to have sex?"
    new "妈的！我们要做爱吗？"

translate chinese chinese_8481362_142:
    old "Yes, it's super fun... I understand that you see it in a different way. But for us, this is simply a form of common energy exchange..."
    new "是的，这超级有趣……我知道你有不同的看法。但对我们来说，这只是普通能量交换的一种形式……"

translate chinese chinese_7864377_143:
    old "Are you saying that this is how you are going to share magical power?"
    new "你是说你要这样分享魔力？"

translate chinese chinese_0643222_144:
    old "Exactly, the magic power resides in an inner gland, and the only way to transfer it is to excite it..."
    new "没错，魔力存在于一个内腺中，唯一转移它的方法是刺激它..."

translate chinese chinese_2193983_145:
    old "In my case, you must be inside me and you will receive my magic power!"
    new "在我这里，你必须进入我的体内，你会接收我的魔力！"

translate chinese chinese_4385284_146:
    old "... And there is no other way. I'm not sure if it's a good idea..."
    new "……而且没有其他办法。我不确定这是否是个好主意……"

translate chinese chinese_6382464_147:
    old "Oh come on! You humans are very complicated, but you have to see it as a magical being..."
    new "哦，别这样！你们人类很复杂，但你得从一个神奇生物的角度来看……"

translate chinese chinese_7814860_148:
    old "Think of sex as a way to feed yourself with magical energy... Is very natural."
    new "可以把性爱当作吸收魔法能量的一种方式……这很自然。"

translate chinese chinese_8942622_149:
    old "Alright, let's do it then..."
    new "好吧，那我们就来吧..."

translate chinese chinese_5111251_150:
    old "Excellent! Take off your pants and get on the floor!"
    new "太好了！脱了裤子趴下！"

translate chinese chinese_6070700_151:
    old "Wow, this is very good! I haven't done it for a long time..."
    new "哇，这真不错！我很久没做了……"

translate chinese chinese_1130251_152:
    old "Do you have some magic power to share with me?"
    new "你有没有什么魔法力量可以分给我一些？"

translate chinese chinese_1800348_153:
    old "Do you need more from me?"
    new "你需要我再做些什么吗？"

translate chinese chinese_3895549_154:
    old "Well, only if you have some to share..."
    new "嗯，只有如果你愿意分享……"

translate chinese chinese_6027851_155:
    old "Ok, but just because is really fun... hahaha"
    new "好吧，但只是因为这真的很有趣... 哈哈哈"

translate chinese chinese_8528780_156:
    old "Take off your pants and lie on the floor..."
    new "脱掉裤子躺在地上..."

translate chinese chinese_7911815_157:
    old "Wow, I've never slept that well."
    new "哇，我从没睡得这么好过。"

translate chinese chinese_7486697_158:
    old "I see that your body was able to completely assimilate magic. How do you feel?"
    new "我看到你的身体完全同化了魔法。你觉得怎么样？"

translate chinese chinese_7063469_159:
    old "I don't feel any different..."
    new "我感觉没什么不同..."

translate chinese chinese_6974122_160:
    old "Well, the best thing to do is to use the magic energy that I gave you to acquire Agamoto's Eye before it runs out..."
    new "好吧，最好的办法就是在我给你的魔法能量耗尽之前，用它来获取阿伽墨托之眼..."

translate chinese chinese_4696850_161:
    old "Does that mean that if I don't use the magic power it will run out?"
    new "那也就是说如果不使用魔力它就会消失吗？"

translate chinese chinese_2844531_162:
    old "Yes, indeed. Every day you will have less magical power, which is why it is urgent that you acquire the skill."
    new "没错。你每天的魔力都会减少，所以尽快学会这个技能很急迫。"

translate chinese chinese_4906278_163:
    old "Perfect, let's go to the garage to do it then..."
    new "完美，那我们去车库做吧..."

translate chinese chinese_5358474_164:
    old "So, what should I do?"
    new "那我该怎么办呢？"

translate chinese chinese_9850970_165:
    old "Well, actually, yesterday we couldn't finish our magic transfer..."
    new "其实，昨天我们的魔法转移还没完成……"

translate chinese chinese_0471580_166:
    old "So, we should do it again, in order to you get completly charged with magic power."
    new "所以，我们应该再做一次，让你完全充满魔力。"

translate chinese chinese_9953092_167:
    old "Hmm alright, but I'm not going to lay on the floor like last time, I don't want someone else to see me in that weird position..."
    new "嗯好吧，但我不会再像上次那样躺在地板上，我不想让别人看到我那个奇怪的姿势……"

translate chinese chinese_1005551_168:
    old "All right!"
    new "好嘞！"

translate chinese chinese_0405970_169:
    old "All right. Now what should I do?"
    new "好吧。那我现在该做什么？"

translate chinese chinese_1730229_170:
    old "First open your SexNote"
    new "先打开你的SexNote"

translate chinese chinese_1892143_171:
    old "Now check the first spell named 'Agamoto's eye' and activate it."
    new "现在检查第一个名为“阿伽墨托之眼”的法术并激活它。"

translate chinese chinese_9816943_172:
    old "Understood..."
    new "明白了……"

translate chinese chinese_6274023_173:
    old "I think it's done... But I don't feel anything different..."
    new "我觉得搞定了……但是没什么不同感觉……"

translate chinese chinese_4288383_174:
    old "You must activate it, click on ability and look at the magic dimension!"
    new "你必须激活它，点击技能并查看魔法维度！"

translate chinese chinese_8757033_175:
    old "Wow... It looks so... Magical?..."
    new "哇……看起来好……神奇？……"

translate chinese chinese_4165132_176:
    old "Do you see those little colored spheres? That is magic power, it has become particles, you just have to pick it all up..."
    new "你看那些小彩球吗？那是魔力，已经变成颗粒了，你只要把它们都捡起来就行了……"

translate chinese chinese_2660774_177:
    old "And when you do it, just click the Agamoto's Eye to desactivate it and see the real world."
    new "当你这么做时，只要点击阿伽摩之眼来关闭它，就能看到真实的世界。"

translate chinese chinese_3763541_178:
    old "Wow, it's easier than I expected..."
    new "哇，这比预期的要简单得多……"

translate chinese chinese_6247680_179:
    old "Of course, what did you expect? Having to memorize and recite strange meaningless words or make puzzles that never fit in  corners?"
    new "当然，你期望什么呢？记住并背诵一些奇怪的无意义的词语，或者做一些永远无法拼合的拼图？"

translate chinese chinese_3257332_180:
    old "What?..."
    new "什么？..."

translate chinese chinese_2727887_181:
    old "Nevermind... It's simple, you just have to look for the spheres of magic power and that's it..."
    new "算了吧……很简单，你只要找到那些魔法球就行了……"

translate chinese chinese_6420422_182:
    old "In fact... There is a spell you can use called Ayax's Hand"
    new "事实上……有一个叫做艾雅克斯之手的咒语可以使用"

translate chinese chinese_4304462_183:
    old "With this one your body will automatically begin to collect magic power everywhere you move, it's sorta like a magnet.."
    new "有了这个，你的身体会自动开始在移动时收集魔力，有点像磁铁一样。"

translate chinese chinese_9117792_184:
    old "Yes, you're right, there are several more spells I saw in the SexNote, how can I activate them?"
    new "对，你说得没错，在SexNote里我还看到了几个其他的咒语，我该怎么激活它们？"

translate chinese chinese_8662437_185:
    old "Very easy you only spend the magic power you have in them and so you can activate those spells, each one has three different levels of power."
    new "非常简单，你只需要消耗存储在其中的魔法力量就能激活这些法术，每个法术都有三种不同的威力等级。"

translate chinese chinese_5455816_186:
    old "For example, the higher the level of power you have with Agamoto's eye, the more spheres you will see and so you can collect more magical power!"
    new "比如说，你用阿戈莫多之眼的力量等级越高，看到的魔球就越多，这样就能收集更多的魔法力量！"

translate chinese chinese_4675303_187:
    old "Ohhh understood, and when I have collected all the magical power from a place?"
    new "哦，明白了，那当我从一个地方收集完所有的魔法力量呢？"

translate chinese chinese_7324342_188:
    old "Check this out, power spheres group everyday so keep an eye out and collect more magical power!"
    new "看看这个，力量球每天都会出现，注意收集更多的魔法力量！"

translate chinese chinese_5270752_189:
    old "Something important is that your body cannot store much magical power..."
    new "重要的是你的身体不能储存太多魔法力量..."

translate chinese chinese_9983861_190:
    old "For that you must use a spell, and thus increase the amount of power that you can store within yourself."
    new "为此你必须使用魔法，从而增加自己能储存的力量。"

translate chinese chinese_5791668_191:
    old "Excellent, so I'm going to devote myself to collecting some magical power in the meantime..."
    new "太好了，那我接下来就专心收集一些魔法力量……"

translate chinese chinese_3118008_192:
    old "Perfect, now that you can do it... You could give me a little, remember that I need it to exist."
    new "完美，现在你能做到了……你可以给我一点点，记得我需要它才能存在。"

translate chinese chinese_4494594_193:
    old "Ohh yes, I'm sorry, let me pick up some more magical power and I will give you later..."
    new "哦哦，是的，对不起，让我再吸收一些魔法力量，等会儿给你..."

translate chinese chinese_3745829_194:
    old "Oh, by the way! Keep in mind that using your Agamotto Eye spends some magical power and time."
    new "哦，对了！记得使用你的阿加莫托之眼会消耗一些魔法力量和时间。"

translate chinese chinese_8442005_195:
    old "Well, all magical skills, requires some magical power to be used..."
    new "嗯，所有的魔法技能，使用时都需要一些魔力……"

translate chinese chinese_1682863_196:
    old "And when you are in the magic dimension time passes a little faster too."
    new "而且当你在魔法维度时，时间也会过得稍微快一点。"

translate chinese chinese_2971761_197:
    old "If you use only a couple of times, you will not see much difference but if you use them alot you will end the day very quickly."
    new "如果你只用几次，可能看不出多大差别，但如果你用很多次，一天很快就会结束。"

translate chinese chinese_8629899_198:
    old "Ohh ok, understood..."
    new "哦，好的，明白了……"

translate chinese chinese_4104154_199:
    old "It is indeed a good way to kill time if you have nothing to do at some point."
    new "确实，如果你有时候没事做，这的确是个打发时间的好方法。"

translate chinese chinese_4084730_200:
    old "I guess you are right..."
    new "我猜你是对的……"

translate chinese chinese_2879081_201:
    old "Ok, I'll be here if you need me."
    new "好，你需要我的时候我就在这里。"

translate chinese chinese_5625214_202:
    old "Hey Brixxida... I think I was visited by another shinigami, like you, yesterday."
    new "嘿，Brixxida……我觉得昨天有个像你这样的死神来找我了。"

translate chinese chinese_6638673_203:
    old "You are the only shinigami alive in the human world?"
    new "你是人界唯一活着的死神？"

translate chinese chinese_8596199_204:
    old "I'm not sure, there are likely to be more, the magical world was very big..."
    new "我不确定，可能还有更多，魔法世界非常大……"

translate chinese chinese_6160270_205:
    old "Well, one of them visited me last night and she was sucking my... She was stealing my magic power..."
    new "好吧，其中一个昨晚来找我了，她在我身上吸吮着……她是在偷我的魔力……"

translate chinese chinese_8487613_206:
    old "Wow... Really?"
    new "wow... 真的吗？"

translate chinese chinese_2509975_207:
    old "Who is she and why did she steal my magic power?"
    new "她是谁，为什么她偷了我的魔法力量？"

translate chinese chinese_1105378_208:
    old "I don't know, it's not like I knew all the magical beings..."
    new "我不知道，我又不认识所有的魔法生物……"

translate chinese chinese_8819128_209:
    old "So what can we do?"
    new "那我们该怎么办？"

translate chinese chinese_6523764_210:
    old "I don't think it will happen again, it's best we wait. If she steals from you again we'll have to defend ourselves..."
    new "我觉得不会再发生了，最好还是等一等。如果她再偷你东西，我们就得自卫了……"

translate chinese chinese_0766220_211:
    old "What do you mean defend ourselves?"
    new "你说的自卫是什么意思？"

translate chinese chinese_2618262_212:
    old "Well, we would have to hunt her and take away her magical power instead..."
    new "好吧，我们就得去抓她，夺走她的魔力才行……"

translate chinese chinese_1286317_213:
    old "All her magical power? That would make her disappear... wouldn't it?"
    new "她所有的魔力？那会让她消失……对吧？"

translate chinese chinese_5058296_214:
    old "Well if she attack you again, we can't sit by while she keeps stealing our magical power! We must stop her somehow..."
    new "好吧，如果她再攻击你，我们不能坐视不管让她继续偷走我们的魔力！我们必须想办法阻止她..."

translate chinese chinese_1336603_215:
    old "Hmmm... Ok, just let's wait and hopefully she won't  show up again."
    new "嗯……好吧，我们就等着吧，希望她不要再出现了。"

translate chinese chinese_0262800_216:
    old "Right... Don't worry, thought. Just keep improving with your skills..."
    new "好吧……别担心，继续提升你的技能就行了……"

translate chinese chinese_2879149_217:
    old "Brixxida, last night another shinigami visited me!"
    new "布里克西达，昨晚又有死神来找我了！"

translate chinese chinese_2565331_218:
    old "Another? And did she steal more magic power from you?"
    new "还有？而且她又从你那里偷走了更多的魔法力量？"

translate chinese chinese_4623713_219:
    old "Well... yes."
    new "嗯……是的。"

translate chinese chinese_7914301_220:
    old "Damn! That can't keep happening! We must recover my magical power... I mean, our magical power..."
    new "该死！这不能一直发生！我们必须恢复我的魔力……我是说我们的魔力……"

translate chinese chinese_5440639_221:
    old "And how do we do it?"
    new "那我们怎么做到呢？"

translate chinese chinese_0486230_222:
    old "We must go on the hunt... We will attack them so they don't bother us again..."
    new "我们必须去狩猎……我们要攻击他们，让他们不要再烦我们……"

translate chinese chinese_4144177_223:
    old "No, no, this time I was able to talk with her a little more..."
    new "不，不，这次我多和她聊了一会儿……"

translate chinese chinese_2166468_224:
    old "In fact she didn't steal much magic from me... and I would like to understand the situation better..."
    new "事实上她并没有从我这里窃取多少魔法……而且我想更清楚地了解情况……"

translate chinese chinese_8111567_225:
    old "They have stolen magical power. If it continues, we will be wasting valuable time that we must use to collect more magical power..."
    new "他们偷走了魔法力量。如果再这样下去，我们将浪费宝贵的时间，而这些时间本应用来收集更多的魔法力量……"

translate chinese chinese_6662644_226:
    old "Let me try one more time. When they return I will try to find out more and see if we can calm them down..."
    new "让我再试一次。等他们回来我会尽力多了解一些情况，看看能不能让他们冷静下来……"

translate chinese chinese_7289512_227:
    old "Hmm, if they steal your magic power again, we will have to defend ourselves, okay?"
    new "嗯，如果他们再偷走你的魔力，我们就得自卫了，好吗？"

translate chinese chinese_7691160_228:
    old "Okay. I will try to use Sauron's Mouth to find out more next time..."
    new "好吧。下次我试试用索隆之口来探探情况..."

translate chinese chinese_4407955_229:
    old "Well, make sure you have the skill at the highest level to get as much information as possible."
    new "好吧，确保你的技能等级最高，这样才能获得尽可能多的信息。"

translate chinese chinese_8196954_230:
    old "For sure..."
    new "肯定……"

translate chinese chinese_4114100_231:
    old "Well, things will be fine ..."
    new "嗯，事情会好起来的……"

translate chinese chinese_4845925_232:
    old "You put a stop to the night robberies?"
    new "你阻止了夜间的抢劫？"

translate chinese chinese_8970175_233:
    old "Well, Not really..."
    new "嗯，也不是真的……"

translate chinese chinese_2105232_234:
    old "Then we will have to fight back now..."
    new "那么我们现在就不得不反击了……"

translate chinese chinese_0250763_235:
    old "No, wait! The problem is that I have taken magical energy that they need to live..."
    new "不，等一下！问题是我取走了他们赖以生存的魔力……"

translate chinese chinese_2681055_236:
    old "You have taken magical energy that is scattered throughout the world. You have never attacked any of them..."
    new "你吸收了散落世界各地的魔法能量，你从未攻击过它们......"

translate chinese chinese_2233801_237:
    old "But... I can generate magical power in other ways..."
    new "但是……我可以用其他方式产生魔法力量……"

translate chinese chinese_5944536_238:
    old "You still don't have enough sexual activity with other women, to guarantee a constant production of magical energy."
    new "你和其他女人的性活动还不够多，无法保证魔法能量的持续供应。"

translate chinese chinese_5261221_239:
    old "I can do it and not affect them..."
    new "我可以做到不牵连他们……"

translate chinese chinese_1526396_240:
    old "You must think about the main goal and it is to be able to rebuild the magical world."
    new "你必须考虑主要目标，那就是重建魔法世界。"

translate chinese chinese_8320922_241:
    old "There are many magical beings that will disappear..."
    new "有许多魔法生物会消失……"

translate chinese chinese_6771394_242:
    old "And we can do nothing but work harder to rebuild everything as quickly as possible..."
    new "而我们只能更加努力，尽快重建一切……"

translate chinese chinese_1110975_243:
    old "Hmm... I guess you're right, but we don't have to attack them."
    new "嗯……你说得对，但我们也不一定要攻击他们。"

translate chinese chinese_0036086_244:
    old "I will try to produce our own energy and little by little we can move forward with the spells..."
    new "我会试着自己制造能量，然后一点一点地用这些魔法前进……"

translate chinese chinese_7921010_245:
    old "They will continue stealing your magical power if we do nothing."
    new "如果我们什么都不做，他们会继续偷走你的魔法力量。"

translate chinese chinese_9734564_246:
    old "We don't have to take away all the magical power, just enough to scare them and they won't look for you again..."
    new "我们不需要剥夺他们所有的魔力，只要够让他们害怕，他们就不会再找你了……"

translate chinese chinese_5618213_247:
    old "Hmm that's fine... How do we do it?"
    new "嗯，那好吧……我们怎么搞呢？"

translate chinese chinese_4031583_248:
    old "I'll take care of tracking them and you'll do the attacking..."
    new "我负责追踪他们，你负责攻击..."

translate chinese chinese_9496184_249:
    old "Attack them?"
    new "攻击他们？"

translate chinese chinese_7024496_250:
    old "Yes, you will have to fuck them..."
    new "是的，你得和他们上床……"

translate chinese chinese_5989893_251:
    old "Hmmm... Ok."
    new "嗯……好。"

translate chinese chinese_2378989_252:
    old "Ok, give me a second. I'm going to use a special spell to detect nearby magical beings..."
    new "好的，给我一会儿。我要用一个特殊法术来探测附近的魔法生物……"

translate chinese chinese_6145549_253:
    old "{b} Radar calidus morollo! {/b}"
    new "{b} Radar calidus morollo! {/b}"

translate chinese chinese_9270014_254:
    old "Done... I already identified where one of them are! She is in your classroom at school! Go there and fuck her..."
    new "搞定了……我已经找到其中一个了！她在你的教室里！去找她搞定她吧……"

translate chinese chinese_0668190_255:
    old "But... What if other people are there?"
    new "但是……如果其他人也在怎么办？"

translate chinese chinese_1355036_256:
    old "Don't worry! When you are in the magical dimension with Agamoto's Eye nobody can see you..."
    new "别担心！当你在阿伽墨托之眼的魔法维度里时，没人能看见你……"

translate chinese chinese_2288700_257:
    old "Ok, I'm going there then..."
    new "好吧，那我就去那里……"

translate chinese chinese_5711495_258:
    old "Good luck! See you later..."
    new "祝你好运！回头见..."

translate chinese chinese_1770534_259:
    old "(Well, she is supposed to be here...)"
    new "（她应该是会在这里的……）"

translate chinese chinese_7439277_260:
    old "(Let's use the Agamoto's Eye.)"
    new "（我们用一下阿伽莫托之眼吧。）"

translate chinese chinese_5757861_261:
    old "What the fuck are you doing here?"
    new "你他妈在这里干什么？"

translate chinese chinese_6941412_262:
    old "So, how did it go? Did you get magic power back?"
    new "所以，结果怎么样了？你恢复魔力了吗？"

translate chinese chinese_9070714_263:
    old "Yes, I already recovered my magic power..."
    new "是的，我已经恢复魔力了……"

translate chinese chinese_0880216_264:
    old "Great... I don't think they will bother again after that..."
    new "太好了……我想他们不会再来了……"

translate chinese chinese_7072501_265:
    old "Hmm I don't know... We shall see."
    new "嗯，我不太确定……走着瞧吧。"

translate chinese chinese_2339253_266:
    old "Again, problems with these shinigamis, I think they've gone crazy..."
    new "又是这些死神的问题，我觉得他们疯了……"

translate chinese chinese_3659428_267:
    old "AGAIN? Okay let's finish them..."
    new "又来？好吧，我们继续吧..."

translate chinese chinese_0478176_268:
    old "No, no... It's very strange. The one who I talked to yesterday was very kind and friendly after having accused me of destroying the magical world..."
    new "不，不……这很奇怪。我昨天聊过的那个人，在指责我破坏魔法世界之后，竟然变得非常友善和亲切……"

translate chinese chinese_6670800_269:
    old "What?... Ehh... They are totally crazy... It's best to make them disappear. We don't want to deal with them later..."
    new "什么？... 嗯... 他们完全疯了... 最好让他们消失。我们不想以后再对付他们..."

translate chinese chinese_8639253_270:
    old "We'll let's try this... I will try to find the next shinigami and I will see what's happening..."
    new "那我们就试试这个……我会去找下一个死神，看看发生了什么……"

translate chinese chinese_0784653_271:
    old "But you should kill them! We've had enough..."
    new "但是你应该杀了他们！我们受够了..."

translate chinese chinese_4172826_272:
    old "No, no. Let me handle this. I have an idea..."
    new "不不，让我来处理。我有个想法……"

translate chinese chinese_1721745_273:
    old "Hmmm ok. I'm gonna use the spell again and I'll tell you where to find the next shinigami..."
    new "嗯好吧。我要再使用那个咒语，然后告诉你下一个死神在哪里找……"

translate chinese chinese_1764104_274:
    old "Well, she is in fact in your friend Hinn's living room."
    new "好吧，她事实上在你朋友赫恩的客厅里。"

translate chinese chinese_0148245_275:
    old "Hmmm, alright... No problem."
    new "嗯哼，好吧……没问题。"

translate chinese chinese_9380314_276:
    old "But you should consider killing them. It can't waste more time..."
    new "但你应该考虑杀了他们。不能再浪费时间了……"

translate chinese chinese_5620136_277:
    old "I know what to do..."
    new "我知道该怎么做……"

translate chinese chinese_8234816_278:
    old "Hmm, Ok."
    new "嗯，好吧。"

translate chinese chinese_0242751_279:
    old "(Great, no one is in the livingroom...)"
    new "（真好，客厅没人……)"

translate chinese chinese_8512764_280:
    old "Excellent! Just what I wanted..."
    new "太好了！正是我想要的……"

translate chinese chinese_5142567_281:
    old "What? What are you doing?"
    new "什么？你在干什么？"

translate chinese chinese_7192372_282:
    old "I have some questions to ask you..."
    new "我有些问题要问你..."

translate chinese chinese_8923682_283:
    old "Sure! Do you want to know more about spells?"
    new "当然！你想了解更多关于咒语的内容吗？"

translate chinese chinese_4467962_284:
    old "No, in fact, I want you to tell me who destroyed the magical world..."
    new "不，事实上，我想让你告诉我谁毁掉了魔法世界..."

translate chinese chinese_6097718_285:
    old "Of course, the magical world was a wonderful place. Everyone lived in harmony..."
    new "当然，魔法世界是一个美妙的地方。每个人都和谐地生活……"

translate chinese chinese_3278421_286:
    old "But a dark being, for unknown reasons, destroyed everything with a spell. When started to act it was too late because the being had too much power..."
    new "但是一个不明原因的黑暗存在用魔法摧毁了一切。等人们开始行动时已经太晚了，因为那个存在拥有太多力量……"

translate chinese chinese_6239647_287:
    old "And why did the shinigami tell me the person who destroyed the magical world was the SexNote owner?"
    new "为什么死神告诉我破坏魔法世界的人是SexNote的主人？"

translate chinese chinese_2952618_288:
    old "I don't know... It could have been the former owner of the SexNote or it could have been another SexNote..."
    new "我不知道……可能是SexNote的前主人，也可能是另一个SexNote……"

translate chinese chinese_0085931_289:
    old "Is there more than one SexNote?"
    new "难道不止一个SexNote吗？"

translate chinese chinese_7024259_290:
    old "It is not known for sure. Nobody knows. In fact, many ignore the real existence of a SexNote. It is something very secret because of the power it has..."
    new "这并不能确定。没有人知道。事实上，很多人忽略了SexNote的真实存在。因为它拥有的力量，这件事非常保密……"

translate chinese chinese_3899922_291:
    old "That's why you're the Chosen One to use it to repair all the damage..."
    new "这就是为什么你是被选中的那个人，用它来修复所有的伤害..."

translate chinese chinese_6021575_292:
    old "I understand... Still, you don't know anything about the previous owner of the SexNote or who destroyed the magical world?"
    new "我明白……不过，你对SexNote的前主人或者破坏魔法世界的人一无所知吗？"

translate chinese chinese_5391647_293:
    old "Correct, My mission was entrusted after the destruction of the magical world, to find a way to preserve the remaining magic of the universe..."
    new "正确，我的任务是在魔法世界毁灭后被委托的，目的是找到保存宇宙中剩余魔法的方法……"

translate chinese chinese_3223800_294:
    old "Got cha. Then everything is a silly misunderstanding... Help me look again for the shinigami to talk to them..."
    new "好吧。那一切就是一个愚蠢的误会……帮我再找一下死神，去和他们谈谈……"

translate chinese chinese_4274229_295:
    old "I don't think that is for the best. After what happened, it could be dangerous. It is best to leave it be as I doubt they'll look for you again..."
    new "我觉得那样不太好吧。出了那种事，可能会很危险。还是别管它好了，我想他们不会再找你了……"

translate chinese chinese_0238960_296:
    old "But you heard them, they are running out of magic power..."
    new "但是你听到了，他们的魔法力量快用完了……"

translate chinese chinese_6454676_297:
    old "The magic power is scattered throughout the world, they just have to go to other places to collect. It is not as serious as they want you to think..."
    new "魔法力量分散在世界各地，他们只要去别的地方收集就行了。没他们说得那么严重……"

translate chinese chinese_7448828_298:
    old "Hmmm... Ok... I guess you're right"
    new "嗯……好……我想你是对的"

translate chinese chinese_8925138_299:
    old "Well, I'm going to keep improving my skills and collecting magical power."
    new "好吧，我会继续提升我的技能并收集魔法力量。"

translate chinese chinese_7431656_300:
    old "Great! See you later."
    new "太好了，待会儿见。"

translate chinese chinese_5101145_301:
    old "(I still think there is something up with Brixxida. I should try to talk with those shinigamis again)"
    new "（我还是觉得Brixxida有问题。我应该再试着和那些死神谈谈）"

translate chinese chinese_3708621_302:
    old "(But, I can't ask Brixxida to look for them...)"
    new "（但是，我不能让Brixxida去找他们...）"

translate chinese chinese_1980326_303:
    old "(I will have to look for them by myself)"
    new "（我得自己去找它们了）"

translate chinese chinese_9827940_304:
    old "Ok, I should look around to find them..."
    new "好吧，我应该四处找找他们..."

translate chinese chinese_1687569_305:
    old "Talk with her"
    new "和她聊聊"

translate chinese chinese_3527294_306:
    old "Well, I already collected enough magic power, I think I can share some with you..."
    new "嗯，我已经收集了足够的魔法力量，我想我可以分享一些给你……"

translate chinese chinese_4414250_307:
    old "Yummy. I love to share the magic power. It's very fun!"
    new "yummy. 我喜欢分享魔力，很有趣！"

translate chinese chinese_5413494_308:
    old "Repeat"
    new "再说一遍"

translate chinese chinese_0128563_309:
    old "Wait... What are you doing..."
    new "等一下……你在干什么……"

translate chinese chinese_5423682_310:
    old "Duh. Receiving your magical power, this is how it is done..."
    new "当然了。接收你的魔力，就是这样..."

translate chinese chinese_9221447_311:
    old "But..."
    new "但是……"

translate chinese chinese_4897427_312:
    old "You must stop being so dramatic with this. You have to be more professional and understand that this is the way it is done. So stop being so... Human..."
    new "你不能再这么夸张了。你得更专业一点，明白这是做事的方式。所以别这么……人性化……"

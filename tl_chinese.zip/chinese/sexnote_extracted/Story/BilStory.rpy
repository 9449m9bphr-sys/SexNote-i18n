# auto-tl Qwen Colab

translate chinese chinese_6560831_0:
    old "What's this? Doodles, messy scratches... hold up, are these lyrics?"
    new "这是什么？涂鸦，乱七八糟的划痕……等等，这些是歌词吗？"

translate chinese chinese_3512177_1:
    old "Music notes scribbled everywhere. 'Faded echoes, songs we lost...'"
    new "到处都是涂鸦的音符。‘消逝的回声，失去的歌...’"

translate chinese chinese_9242436_2:
    old "Yeah, that's the right call."
    new "没错，这才是正确的决定。"

translate chinese chinese_6294785_3:
    old "Hold up, what’s this flyer on the floor?"
    new "等一下，地上这是什么传单？"

translate chinese chinese_0928305_4:
    old "School’s doing a music contest? 'Sign up now'..."
    new "学校要举办音乐比赛？“立即报名”……"

translate chinese chinese_7905605_5:
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 percent yourself. Ready? Let’s make magic!"
    new "所以深呼吸，尽情享受，记住：舞台是唯一一个你可以完全做自己的地方。准备好了吗？让我们创造奇迹吧！"

translate chinese chinese_9008605_6:
    old "Arielle and Kayla!"
    new "艾丽尔和凯拉！"

translate chinese chinese_9520630_7:
    old "Lord have mercy on my edges! Arielle, those whistle tones cleaner than my Sunday choir. Kayla, that belt could wake the dead."
    new "主啊，救救我的音准吧！艾丽尔，那哨子般的音调比我的周日合唱团还要纯净。凯拉，那嗓音能把死人唤醒。"

translate chinese chinese_6459213_8:
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100 percent. Volume was whisper quiet, but somehow you filled the entire room."
    new "你的语气像丝绸般柔软，措辞令人心碎，情感真实度百分之百。声音轻得像耳语，却不知怎么的充满了整个房间。"

translate chinese chinese_8730509_9:
    old "However, [pla]... sweetheart, you were a potted plant."
    new "然而，[pla]……亲爱的，你不过是一盆植物。"

translate chinese chinese_2708203_10:
    old "Next time you move, you breathe with her, you support her. Deal?"
    new "下次你动的时候，要跟着她的呼吸，支撑她。 deal?"

translate chinese chinese_2981538_11:
    old "Sharpay & Ryan: spectacle and precision. Arielle & Kayla: vocal olympics. Billie & [pla]: pure soul."
    new "Sharpay & Ryan：精彩与精准。Arielle & Kayla：声乐奥运会。Billie & [pla]：纯粹的灵魂。"

translate chinese chinese_7823408_12:
    old "Watched like three tutorials last night. How hard can be?"
    new "昨晚看了好几个教程，能有多难？"

translate chinese chinese_4430042_13:
    old "Let’s try again..."
    new "我们再试一次吧..."

translate chinese chinese_5756453_14:
    old "One more time. Come on, [pla]."
    new "再来一次。快点，[pla]。"

translate chinese chinese_2953948_15:
    old "Okay... that almost sounded like music... right?"
    new "好……那几乎听起来像音乐……对吧？"

translate chinese chinese_6400302_16:
    old "Ugh, enough for today. Fingers are officially dead."
    new "哎，今天够了。手指都僵硬了。"

translate chinese chinese_3339122_17:
    old "Wow... you're amazing."
    new "wow... 你真棒。"

translate chinese chinese_6387008_18:
    old "Still not perfect... but it sounded more like a song this time."
    new "还是不完美……但这次听起来更像一首歌了。"

translate chinese chinese_7504482_19:
    old "T- they're so sensitive... I can feel them hardening more."
    new "她们……这么敏感……我能感觉到她们变得更硬了。"

translate chinese chinese_9903479_20:
    old "W- what do you have in mind?"
    new "你、你什么意思？"

translate chinese chinese_5354008_21:
    old "And of course, I know you’re gonna need a little extra motivation..."
    new "当然了，我知道你可能需要一点额外的动力……"

translate chinese chinese_7450699_22:
    old "Shh. Focus. This is practical training, remember?"
    new "嘘。集中点。这是实战训练，记得吗？"

translate chinese chinese_7962060_23:
    old "O- Ok..."
    new "好……"

translate chinese chinese_3062573_24:
    old "Mmm... good. Feel how it responds under your fingers?"
    new "嗯……很好。感受一下它在你手指下的反应吗？"

translate chinese chinese_9836600_25:
    old "It's... getting wetter already."
    new "它……已经变得更湿了。"

translate chinese chinese_6285193_26:
    old "That's normal. Keep the rhythm steady. You're learning the technique."
    new "这是正常的。保持节奏稳定。你在学习技巧。"

translate chinese chinese_6253714_27:
    old "Now increase the pressure a bit. Faster circles. Don't lose the rhythm."
    new "现在加大一点力度，加快圈圈的速度，不要失去节奏。"

translate chinese chinese_2644453_28:
    old "Nngh— yes... that's it. You're doing well. Keep going."
    new "嗯——是的……就是这样。你做得很好。继续。"

translate chinese chinese_6474221_29:
    old "Harder. Don't stop. Make me feel it."
    new "再用力点。别停。让我感受一下。"

translate chinese chinese_2828512_30:
    old "[bil]... you're breathing heavier."
    new "[bil]……你的呼吸变重了。"

translate chinese chinese_8007563_31:
    old "Fuck... just like that. Keep going. Don't you dare slow down."
    new "操……就这样。继续。你敢慢下来试试。"

translate chinese chinese_6945072_32:
    old "Ngh- Stop, stop, stop..."
    new "嗯——停下，停下，停下……"

translate chinese chinese_1078489_33:
    old "... Did I do something wrong?"
    new "……我做错什么了吗？"

translate chinese chinese_3551489_34:
    old "Mmm, no, no... actually you were doing it really well."
    new "嗯，不，其实你做得挺好的。"

translate chinese chinese_3510143_35:
    old "But I want you to try something... Uhh, more advanced."
    new "但是我想让你试试……更高级的。"

translate chinese chinese_5262712_36:
    old "Now... use two fingers. Slide them in together. Start slow."
    new "现在……用两根手指，一起滑进去。开始慢一点。"

translate chinese chinese_8683800_37:
    old "Uhh... like this?"
    new "呃……是这样吗？"

translate chinese chinese_7825929_38:
    old "Mmm, yeah, just like that..."
    new "嗯，对，就那样..."

translate chinese chinese_0135662_39:
    old "Curl them. Find the spot and start moving them slowly... let me feel it."
    new "卷起来，找到那个地方，慢慢动……让我感受一下。"

translate chinese chinese_7696148_40:
    old "Ready for your advanced practice?"
    new "准备好进行高级练习了吗？"

translate chinese chinese_4421771_41:
    old "Finally. You're late."
    new "终于来了。你迟到了。"

translate chinese chinese_9189694_42:
    old "I know, I know... I’m sorry."
    new "我知道，我知道……对不起。"

translate chinese chinese_8426165_43:
    old "We don’t have time for this. The teacher’s expecting us."
    new "我们没时间搞这个了。老师还在等着我们呢。"

translate chinese chinese_2247507_44:
    old "Billie... Wait!"
    new "比莉……等一下！"

translate chinese chinese_3113949_45:
    old "I- I don’t think I can do this."
    new "我—我觉得我做不到。"

translate chinese chinese_0690653_46:
    old "Here we go again."
    new "又来了。"

translate chinese chinese_4978401_47:
    old "I mean it. I don’t feel ready. Not even close."
    new "我是认真的。我觉得还没准备好。差得远呢。"

translate chinese chinese_3926781_48:
    old "Come on! You’ve been practicing for days. You improved a ton."
    new "加油！你已经练习了好几天了。进步很大。"

translate chinese chinese_7831776_49:
    old "Yeah, but only with you. Or at home. This is different. With the teacher... with pressure... I’m not ready."
    new "是啊，但只有和你。或者在家里。这不一样。和老师……有压力……我不准备好的。"

translate chinese chinese_0253695_50:
    old "Relax, you don’t have to be perfect today."
    new "放松点，今天不用完美的。"

translate chinese chinese_3950486_51:
    old "But I’m barely even good. What if I mess everything up?"
    new "但我根本就不太行。如果我把一切都搞砸了怎么办？"

translate chinese chinese_2900978_52:
    old "Then you mess up. It happens."
    new "那你搞砸了。这种事情时有发生。"

translate chinese chinese_8410149_53:
    old "I don't know, Billie... maybe you should just do this one alone."
    new "我不知道，比莉……也许你还是自己来吧。"

translate chinese chinese_6583074_54:
    old "Stop. You’re not backing out now."
    new "停下。你现在不能退缩。"

translate chinese chinese_7085828_55:
    old "Billie... I really don’t think I can do this."
    new "比莉……我真的觉得我做不到这个。"

translate chinese chinese_0282248_56:
    old "Shut Up! I know you can. You’ve improved. A lot."
    new "闭嘴！我知道你能行的。你进步了很多。"

translate chinese chinese_2377261_57:
    old "But what if I freeze? What if everything falls apart? What if—"
    new "但是如果我卡住了呢？如果一切都崩溃了呢？如果—"

translate chinese chinese_6322480_58:
    old "Okay, okay, breathe. You’re spiraling."
    new "好啦好啦，深呼吸，你太紧张了。"

translate chinese chinese_5722907_59:
    old "I- I don’t know... I feel like I’m gonna choke the moment she looks at me."
    new "我……我不知道……我觉得只要她一看我，我就要窒息了。"

translate chinese chinese_8301518_60:
    old "Look, standing here arguing isn’t helping either. Come with me."
    new "你看，站在这里争论也没用。跟我来。"

translate chinese chinese_3949540_61:
    old "What? W- where?"
    new "什么？在哪儿？"

translate chinese chinese_7290797_62:
    old "Somewhere quiet. You need to reset before we walk in there."
    new "找个安静的地方。你需要调整一下状态再进去。"

translate chinese chinese_9665709_63:
    old "The bathroom? [bil], what are we—"
    new "浴室？[bil]，我们在干什么——"

translate chinese chinese_8817708_64:
    old "Shh. Ok, i locked the door."
    new "嘘。好了，我锁上门了。"

translate chinese chinese_5415939_65:
    old "Uhh, W- what? Why? We should be heading to class."
    new "呃，W-什么？为什么？我们应该去上课了。"

translate chinese chinese_9257190_66:
    old "Listen, you need to chill first. Watch."
    new "听着，你先冷静一下。看着。"

translate chinese chinese_7362605_67:
    old "W- whoa! [bil]!"
    new "哇！[bil]！"

translate chinese chinese_0106191_68:
    old "There. Take a look."
    new "好了，看看吧。"

translate chinese chinese_5005265_69:
    old "I... Uh... they're... wow."
    new "我……呃……他们……哇。"

translate chinese chinese_2108127_70:
    old "Heh. Does this help?"
    new "嘿嘿。这样帮到你吗？"

translate chinese chinese_9090887_71:
    old "Kinda? But... this isn't about that."
    new "有点儿？但是……这不关那事。"

translate chinese chinese_2672106_72:
    old "You can touch them if you want. Might relax you more."
    new "你可以摸它们，可能会让你更放松。"

translate chinese chinese_9430948_73:
    old "Hmm... to be honest, I don't think this is gonna help with the anxiety."
    new "嗯……老实说，我觉得这并不能缓解焦虑。"

translate chinese chinese_6506721_74:
    old "Really? Not even a little?"
    new "真的吗？一点都没有？"

translate chinese chinese_7881852_75:
    old "I mean, I really like them, of course. But I'm still freaked about performing."
    new "我的意思是，我当然真的很喜欢她们。但一想到要表演我还是很紧张。"

translate chinese chinese_8574252_76:
    old "Hmm. Okay, okay... Plan B then."
    new "嗯。好啦好啦……那计划B吧。"

translate chinese chinese_0474561_77:
    old "Plan B?"
    new "计划B？"

translate chinese chinese_0916450_78:
    old "Yeah. Something that always works."
    new "是啊。一个屡试不爽的方法。"

translate chinese chinese_6052213_79:
    old "Oh God, [bil]..."
    new "哦上帝，[bil]..."

translate chinese chinese_2319511_80:
    old "Shh. Let me handle your stress."
    new "嘘，让我来帮你缓解压力。"

translate chinese chinese_3819850_81:
    old "This is crazy... but... don't stop."
    new "这真是疯了……但是……不要停。"

translate chinese chinese_4923322_82:
    old "Told you. My methods are foolproof."
    new "告诉你吧。我的方法绝对可靠。"

translate chinese chinese_0969329_83:
    old "Phew... okay, nerves are gone. Mostly."
    new "呼……好了，紧张感消失了。差不多吧。"

translate chinese chinese_4752311_84:
    old "Good. Now let's go before Bey bails on us."
    new "好的。现在走吧，免得Bey甩了我们。"

translate chinese chinese_7337131_85:
    old "Right. I'm ready now. I think."
    new "好。我现在准备好了。我想是的。"

translate chinese chinese_7164975_86:
    old "You are. Come on."
    new "是你。快点。"

translate chinese chinese_3400628_87:
    old "Oh! There you two are. I was about to leave."
    new "哦！你们俩在这儿。我正准备离开呢。"

translate chinese chinese_6926713_88:
    old "Sorry. We had... a situation."
    new "对不起。我们遇到……一些情况。"

translate chinese chinese_8166486_89:
    old "A situation?"
    new "情况？"

translate chinese chinese_9702298_90:
    old "Stage panic. I had to calm him down with... a technique that always works."
    new "他突然紧张起来。我只好用一个屡试不爽的技巧让他冷静下来。"

translate chinese chinese_4734803_91:
    old "Oh! Well, whatever you did, I’m glad it helped. Next time, bring him here, I have plenty of ways to help with anxiety too."
    new "哦！不管你怎么做的，我很高兴帮上了忙。下次带他来这里吧，我还有很多缓解焦虑的方法。"

translate chinese chinese_6279558_92:
    old "Don’t worry. I have a method that works every time."
    new "别担心，我有一个每次都能成功的办法。"

translate chinese chinese_3953289_93:
    old "Well, as long as he’s fine now."
    new "好吧，只要他现在没事就行了。"

translate chinese chinese_3218951_94:
    old "I... think so."
    new "我……觉得是这样。"

translate chinese chinese_2069261_95:
    old "Good. Now tell me, how have you two been? Practicing together?"
    new "好的。现在告诉我，你们俩最近怎么样？有在一起练习吗？"

translate chinese chinese_1327634_96:
    old "A lot. He’s been improving faster than I expected."
    new "很多。他的进步比我预期的要快。"

translate chinese chinese_3614170_97:
    old "Really? That’s wonderful."
    new "真的吗？太好了。"

translate chinese chinese_6446787_98:
    old "Uhh, actually, I’m still not that great."
    new "呃，其实我还没好多少。"

translate chinese chinese_8423140_99:
    old "No one expects you to be. What matters is progress."
    new "没人期待你会的。重要的是进步。"

translate chinese chinese_0725617_100:
    old "He’s now supporting me with guitar for the performance."
    new "他现在正为我的表演伴吉他。"

translate chinese chinese_0457631_101:
    old "Ah! Excellent idea. Your voice with live accompaniment gives the duet a lot of potential."
    new "啊！好主意。你的声音加上现场伴奏让二重唱很有潜力。"

translate chinese chinese_1171549_102:
    old "Yeah, that’s the plan."
    new "对，就是这样计划的。"

translate chinese chinese_7155127_103:
    old "Alright then, let’s hear you. Perform as if it were the actual contest. After that, I’ll give you both feedback."
    new "好吧，那你来表演一下。就当是真正的比赛一样。演完之后，我会给你们俩反馈。"

translate chinese chinese_7123047_104:
    old "O-okay..."
    new "好……好吧……"

translate chinese chinese_0498997_105:
    old "({i}No pressure... no pressure...{/i})"
    new "({i}不要紧张……不要紧张……{/i})"

translate chinese chinese_4638736_106:
    old "Okay! Why don’t we do this like a mock presentation?"
    new "好啊！我们不如来个模拟展示吧？"

translate chinese chinese_5615332_107:
    old "Imagine you’re already on stage at the contest. Perform the piece you’ve been working on."
    new "想象你自己已经在比赛的舞台上。演奏你一直在练习的那首曲子。"

translate chinese chinese_0445864_108:
    old "{i}Billie... I don—{/i}"
    new "{i}比莉……我——{/i}"

translate chinese chinese_6538715_109:
    old "Don’t start panicking again. Just do what we’ve practiced."
    new "别又开始慌了，就按我们练习的做。"

translate chinese chinese_6304260_110:
    old "{i}Right... right.{/i}"
    new "{i}对……对。{/i}"

translate chinese chinese_2146490_111:
    old "Wow. That was genuinely impressive."
    new "wow. 那真的挺厉害的。"

translate chinese chinese_8321878_112:
    old "Absolutely. You two have grown a lot."
    new "绝对的。你们两个成长了很多。"

translate chinese chinese_6836143_113:
    old "[pla]... last time you barely moved. You were like a decorative tree."
    new "[pla]……上次你几乎没动，就像棵装饰树。"

translate chinese chinese_2049016_114:
    old "Uhh... ok."
    new "呃……好。"

translate chinese chinese_1111395_115:
    old "This time you actually you played. And with feeling. I’m proud of that."
    new "这次你真的投入进去了。而且很有感觉。我为你感到骄傲。"

translate chinese chinese_8301233_116:
    old "You still get nervous, and it shows in your transitions. A few spots were shaky."
    new "你还是有点紧张，换镜头的时候露出来了。有几个地方还抖了。"

translate chinese chinese_6542483_117:
    old "It’s normal. With more practice you'll smooth it out. If you want, you can come to extra sessions with me. I can help strengthen your hand technique."
    new "这是正常的。多练习就会熟练了。如果你愿意，可以来跟我一起加练。我可以帮你加强手部技巧。"

translate chinese chinese_4900358_118:
    old "No need. I’ve already got him on a very effective practice."
    new "不用了。我已经让他进行非常有效的训练了。"

translate chinese chinese_3675010_119:
    old "Oh! Great. If it works, keep doing it. You two clearly connect well."
    new "哦！太好了。如果有效，就继续吧。你们俩显然很合拍。"

translate chinese chinese_5092482_120:
    old "Now, Billie. As always your voice is beautiful. Rich tone, controlled color, great emotional delivery."
    new "现在，Billie。你的声音一如既往地美丽。音色丰富，控制得当，情感表达也很到位。"

translate chinese chinese_9463942_121:
    old "However, there’s room to grow. You rely a bit too much on natural skill."
    new "不过，还是有提升的空间。你有点太依赖天赋了。"

translate chinese chinese_9518422_122:
    old "We need to work on technique, breath support, especially sustaining phrases without losing power."
    new "我们需要练习技巧，呼吸支持，特别是持续发音而不失去力量。"

translate chinese chinese_4551697_123:
    old "Your diaphragm engagement is good, but not consistent. With proper training, your projection and stability will improve a lot."
    new "你的横膈膜运用不错，但还不够稳定。经过适当的训练，你的发声和稳定性会提高很多。"

translate chinese chinese_4528840_124:
    old "Oh, ok..."
    new "哦，好的……"

translate chinese chinese_7257816_125:
    old "I’d love to train that with you. Come for vocal sessions, and we’ll shape your sound for the contest."
    new "我真的很想和你一起训练这个。来参加声乐课程吧，我们会为你比赛的声音做准备。"

translate chinese chinese_3949611_126:
    old "Just you and me. We’ll polish your technique and make sure you’re ready for the real contest."
    new "就我们俩。我们会磨练你的技巧，确保你准备好参加真正的比赛。"

translate chinese chinese_0285626_127:
    old "Sounds good. I’m in."
    new "听起来不错，我参加。"

translate chinese chinese_7515511_128:
    old "Perfect. And [pla], keep practicing with Billie. You two work wonderfully together."
    new "完美。还有[pla]，继续和Billie练习。你们俩合作得非常好。"

translate chinese chinese_8866622_129:
    old "We will."
    new "我们会的。"

translate chinese chinese_9022754_130:
    old "Oh, trust me... We definitely will."
    new "哦，相信我……我们肯定会的。"

translate chinese chinese_2773927_131:
    old "You both have something special together."
    new "你们俩之间有什么特别的东西。"

translate chinese chinese_2068702_132:
    old "Keep up the rhythm. I’ll call you both again for another evaluation soon."
    new "保持这个节奏。我很快会再联系你们俩进行另一次评估。"

translate chinese chinese_2406579_133:
    old "Thank you for everything."
    new "感谢一切。"

translate chinese chinese_9309526_134:
    old "Well, well... look who actually survived a real practice session."
    new "哦呵……看看谁竟然真的挺过了一次实战训练。"

translate chinese chinese_9130647_135:
    old "We heard you two through the wall. That was... almost not terrible. Hahaha"
    new "我们隔着墙听到你们俩了。那几乎不算糟糕。哈哈哈哈哈"

translate chinese chinese_6615686_136:
    old "Heh. Almost?"
    new "嘿嘿。差点就成功了？"

translate chinese chinese_9332648_137:
    old "Your breath control still wavers on the sustain, sweetie. Fix it or you’ll crack on stage."
    new "你的长音气息控制还不稳，宝贝。改掉这个毛病，不然上台会破音的。"

translate chinese chinese_7298909_138:
    old "And you, [pla]... congrats on finally moving. You’re only half a statue now."
    new "至于你，[pla]……恭喜你终于动了。你现在只是一半的石像了。"

translate chinese chinese_1075060_139:
    old "Thanks... I think?"
    new "谢谢……我想？"

translate chinese chinese_5639966_140:
    old "Keep taking notes, girls. We’re just warming up."
    new "继续记笔记，姑娘们。我们才刚热身呢。"

translate chinese chinese_9986514_141:
    old "Please. Technique beats 'raw emotion' every single time."
    new "拜托。技巧每次都胜过所谓的“真情实感”。"

translate chinese chinese_5951417_142:
    old "See you at the contest... try not to choke when it actually counts."
    new "比赛上见……别到时候关键时刻掉链子。"

translate chinese chinese_6395878_143:
    old "They’re still exactly the same, huh?"
    new "他们还是一点都没变啊？"

translate chinese chinese_7371636_144:
    old "Perfect. Makes crushing them way more satisfying."
    new "完美。这样碾压他们就更有满足感了。"

translate chinese chinese_7981676_145:
    old "Okay... I have to admit, that went better than I expected."
    new "好吧……我得承认，这比预期的要好。"

translate chinese chinese_2375657_146:
    old "Way better. I didn’t completely freeze."
    new "好多了。我这次没完全僵住。"

translate chinese chinese_0581214_147:
    old "Wow, what an achievement. Should we throw you a parade?"
    new "哇，真了不起。我们应该为你举行游行吗？"

translate chinese chinese_3336716_148:
    old "Hey, for me that’s huge."
    new "嘿，对我来说这已经很大了。"

translate chinese chinese_0460902_149:
    old "Yeah... it kinda is."
    new "嗯……确实有点那个意思。"

translate chinese chinese_8990020_150:
    old "Seriously, thanks for earlier. Uhh, you know."
    new "seriously, thanks for earlier. uhh, you know. \n\n（注：此处翻译保持原文，因涉及上下文具体含义未明确，直接翻译可能不符合语境。） \n\n认真点，刚才真的谢谢你。你知道的。"

translate chinese chinese_0905396_151:
    old "If you hadn’t helped me calm down, I would’ve messed everything up."
    new "要不是你帮我冷静下来，我早就把一切都搞砸了。"

translate chinese chinese_1492519_152:
    old "I know."
    new "我知道。"

translate chinese chinese_8557891_153:
    old "You owe me one."
    new "你欠我一个了。"

translate chinese chinese_7645594_154:
    old "Actually, more than one. I mean it."
    new "实际上，不只一个，我是认真的。"

translate chinese chinese_7265847_155:
    old "Relax. You did the hard part. You didn’t run away."
    new "放松点。你已经完成了难的那一部分。你没有逃跑。"

translate chinese chinese_2306539_156:
    old "Heh, I almost did."
    new "嘿嘿，我差点就做到了。"

translate chinese chinese_4832078_157:
    old "And I almost slapped you. Balance."
    new "我差点就扇你了。平衡一下。"

translate chinese chinese_1092590_158:
    old "Still... I’m glad you didn’t let me quit."
    new "不过……我还是很高兴你没有让我放弃。"

translate chinese chinese_6348153_159:
    old "Good. Because you’re way more useful when you don’t panic every five seconds."
    new "好。因为你如果不每隔五秒就惊慌失措的话，会更有用得多。"

translate chinese chinese_1737253_160:
    old "I’m working on that."
    new "我正在处理呢。"

translate chinese chinese_7217698_161:
    old "And you’re getting better. With the guitar. With the nerves. With everything."
    new "而且你进步了。吉他弹得更好了。紧张情绪也缓解了。一切都在变好。"

translate chinese chinese_7729872_162:
    old "You really think so?"
    new "你真的这么认为？"

translate chinese chinese_5836605_163:
    old "Don’t get cocky. But yeah... you’re not useless anymore."
    new "别得意忘形了。但话说回来……你不再没用了。"

translate chinese chinese_7194901_164:
    old "Haha, that’s the nicest thing you’ve ever said to me."
    new "哈哈，这是我听过的你最Nice的话了。"

translate chinese chinese_3319641_165:
    old "Don’t get used to it."
    new "别以为我会惯着你。"

translate chinese chinese_4597599_166:
    old "So... what now?"
    new "所以……接下来怎么办？"

translate chinese chinese_1658141_167:
    old "Now we keep practicing. You, with the guitar. Me, with the teacher."
    new "现在我们继续练习。你弹吉他。我当老师。"

translate chinese chinese_4184306_168:
    old "And together... We make this thing actually work."
    new "我们一起……让这件事真的成功了。"

translate chinese chinese_7860715_169:
    old "Deal."
    new "成交。"

translate chinese chinese_8141384_170:
    old "Alright, it’s getting late. Go home before you turn into a pumpkin."
    new "好吧，天色不早了。赶紧回家，别变成南瓜了。"

translate chinese chinese_8465894_171:
    old "Yeah, I should. But... thanks again. For everything."
    new "是的，我应该这么做的。但是……再次感谢你。为了一切。"

translate chinese chinese_4334454_172:
    old "Yeah, yeah. Just don’t waste what we started."
    new "好了好了，别浪费我们开始的东西。"

translate chinese chinese_9023414_173:
    old "I won’t. I promise."
    new "我不会的。我保证。"

translate chinese chinese_5930363_174:
    old "See you soon."
    new "很快见。"

translate chinese chinese_4873765_175:
    old "Finally. You're here."
    new "终于，你来了。"

translate chinese chinese_8623392_176:
    old "Yeah, your text said it was urgent. What's up?"
    new "嗯，你的短信说很紧急。怎么了？"

translate chinese chinese_9517321_177:
    old "Well, I've been in lessons with the teacher. It's going okay, but I need your help with something."
    new "嗯，我一直在跟老师上课。还行，但有些事需要你的帮助。"

translate chinese chinese_1053722_178:
    old "Do you need my help?"
    new "你需要我的帮助吗？"

translate chinese chinese_4641822_179:
    old "Better talk in my room. Come on."
    new "还是到我房间里再说吧。走吧。"

translate chinese chinese_4273550_180:
    old "Alright, so, those vocal sessions with Bey were way tougher than I expected."
    new "好吧，所以，和Bey的那些录音 session 真的是比我想象中难多了。"

translate chinese chinese_7798222_181:
    old "'Tougher' for you? Seriously?"
    new "“更厉害”对你来说？ seriously?"

translate chinese chinese_0316620_182:
    old "Yeah, I mean, I have the talent, sure. But I haven't practiced consistently in years."
    new "是啊，我的确有天赋，但几年来我都没坚持练习过。"

translate chinese chinese_6251558_183:
    old "I lost some edge on breath control, especially under pressure."
    new "我在呼吸控制上失去了一些优势，特别是在压力之下。"

translate chinese chinese_7128697_184:
    old "Like, when nerves hit or heart rate spikes, my voice shakes. So, I can't sustain some notes without cracking."
    new "就是说，当我紧张或者心跳加速时，我的声音会发抖。所以，我不能不破音地唱某些音调。"

translate chinese chinese_1485242_185:
    old "That sounds rough. What does the teacher say?"
    new "听起来挺糟的。老师怎么说？"

translate chinese chinese_8389132_186:
    old "She's got me on diaphragmatic breathing deep belly breaths to stabilize. And box breathing: inhale four, hold four, exhale four, hold four."
    new "她在让我做膈式呼吸，深腹呼吸来稳定情绪。还有盒子呼吸法：吸四秒，停四秒，呼四秒，再停四秒。"

translate chinese chinese_2809703_187:
    old "Helps calm the nervous system, reduces anxiety. But it's not enough for real stage stress."
    new "有助于缓解神经系统，减少焦虑。但对付真正的舞台压力还不够。"

translate chinese chinese_8230919_188:
    old "Stage stress? Like performance anxiety?"
    new "舞台压力？就像表演焦虑那样？"

translate chinese chinese_6973798_189:
    old "Exactly. Heart pounding, shallow breaths... Voice goes to shit. Need to practice holding technique when everything's agitated."
    new "没错。心跳加速，呼吸急促……声音也变糟糕了。需要练习在一切激动时保持镇定的技巧。"

translate chinese chinese_7988409_190:
    old "Ohh, like exercises while running or something?"
    new "哦，像跑步时做的运动之类的？"

translate chinese chinese_8891702_191:
    old "Hmm, kinda. I already tried that stuff. Jogging while singing, high-heart-rate drills... even picturing the crowd without freaking out."
    new "嗯，差不多吧。那些方法我都试过了。跑步时唱歌、高强度训练……甚至想象观众时不紧张。"

translate chinese chinese_5769270_192:
    old "Progress is slow. With the contest coming, traditional stuff won't cut it."
    new "进度很慢。比赛快来了，老套的东西不行了。"

translate chinese chinese_3242092_193:
    old "Damn. So what's the plan?"
    new "真糟糕。那计划是什么？"

translate chinese chinese_5647793_194:
    old "Well, I've been researching some non-traditional stuff. Found training under extreme stimulation to build resilience."
    new "嗯，我一直在研究一些非传统的东西。发现通过极端刺激下的训练可以增强韧性。"

translate chinese chinese_6226282_195:
    old "Like... What kind?"
    new "比如……什么类型的？"

translate chinese chinese_3788092_196:
    old "Ways to spike heart rate and nerves, but controlled. Make the body adapt to singing through it."
    new "提高心率和神经紧张的方法，但要控制住。让身体适应在这种状态下唱歌。"

translate chinese chinese_9840242_197:
    old "Anyway, the thing is I need you, because I wanna practice vocals under some strong stimulation. You know, to simulate the pressure."
    new "不管怎样，我是需要你的，因为我想在强烈的刺激下练习 vocals，你知道的，模拟一下压力。"

translate chinese chinese_6297436_198:
    old "Strong stimulation? Like... Distracting you?"
    new "强烈的刺激？比如……让你分心？"

translate chinese chinese_5708337_199:
    old "Why do you have to be so slow sometimes?"
    new "你为什么有时候这么慢呢？"

translate chinese chinese_3501074_200:
    old "Uh?"
    new "嗯？"

translate chinese chinese_0649197_201:
    old "Listen, I need my heart racing and my body all tense while I'm practicing singing."
    new "听着，我唱歌的时候需要心跳加速，身体紧张。"

translate chinese chinese_2358936_202:
    old "Still not following..."
    new "还是没懂……"

translate chinese chinese_0464189_203:
    old "Ughh. I need you to stimulate me... sexually. While I sing."
    new "呃……我需要你在我不唱的时候刺激我……性地。"

translate chinese chinese_3813505_204:
    old "Ohhhh..."
    new "哦hhh..."

translate chinese chinese_4603127_205:
    old "Yeah, it's not orthodox, but time's short. And hey, I've helped you with 'non-traditional' methods before."
    new "没错，这不 orthodox，但时间紧迫。而且说起来，我以前就帮过你用“非传统”的方法。"

translate chinese chinese_9066361_206:
    old "You owe me a few, remember?"
    new "你欠我几次了，记得吗？"

translate chinese chinese_9973582_207:
    old "Well, that’s... fair, I guess."
    new "嗯，那……也挺公平的，我想。"

translate chinese chinese_2879053_208:
    old "But, I mean, I’m not saying you’re obligated."
    new "但是我的意思是，我不是说你有义务。"

translate chinese chinese_3887705_209:
    old "I’m saying this could actually help me control my voice when everything inside me is going wild."
    new "我的意思是，这实际上可以帮助我在内心狂乱时控制住自己的声音。"

translate chinese chinese_9127344_210:
    old "And you really think this will work?"
    new "你真的觉得这能行？"

translate chinese chinese_7884966_211:
    old "Well, I’m not doing it just for fun."
    new "好吧，我可不是为了好玩才做的。"

translate chinese chinese_6025859_212:
    old "Okay, maybe a little."
    new "好吧，可能有点。"

translate chinese chinese_2221772_213:
    old "Heh. Alright, if you’re serious, then... Yeah. I’ll help."
    new "嘿嘿。好吧，如果你是认真的，那……行吧。我会帮忙。"

translate chinese chinese_6369389_214:
    old "You helped me when I was stuck. If this is what you need, I’m in."
    new "在我遇到困难时你帮助了我。如果你需要这个，我愿意帮忙。"

translate chinese chinese_1301564_215:
    old "If you’re going to help, we’ll treat this like real training."
    new "如果你要帮忙，我们就当这是真正的训练。"

translate chinese chinese_6213428_216:
    old "Alright... So what exactly am I supposed to do?"
    new "好吧……那我到底该做什么？"

translate chinese chinese_3753070_217:
    old "Ok, first, you follow my lead."
    new "好的，首先，你跟着我的节奏来。"

translate chinese chinese_0976825_218:
    old "Second, you don’t overthink it."
    new "第二，别想太多。"

translate chinese chinese_4262749_219:
    old "Third, remember the goal: I have to keep singing no matter what I’m feeling."
    new "第三，记住目标：不管我感觉如何，都必须继续唱歌。"

translate chinese chinese_3699436_220:
    old "Got it. You sing, I... create the distraction."
    new "明白了。你唱歌，我……制造分散注意力的动静。"

translate chinese chinese_1662785_221:
    old "Yeah. If we do this right, my voice should stays steady even when everything else is falling apart."
    new "是的。如果我们做得好，即使其他一切都乱了，我的声音也应该保持稳定。"

translate chinese chinese_4153705_222:
    old "Alright, I'm in. Just tell me exactly what you need, and I'll handle it."
    new "好吧，我同意了。你就直接告诉我你需要什么，我会处理的。"

translate chinese chinese_9695219_223:
    old "Ok, first let me get ready..."
    new "好的，让我先准备一下……"

translate chinese chinese_7321485_224:
    old "Do you like what you see? Heh?"
    new "你喜欢看到的吗？嘿嘿？"

translate chinese chinese_6490845_225:
    old "What about now?"
    new "现在呢？"

translate chinese chinese_4821000_226:
    old "Holy... fuck..."
    new "卧槽..."

translate chinese chinese_1027841_227:
    old "No reason we both can't benefit from this 'practice', right?"
    new "我们俩从这“练习”中受益，没什么不对吧？"

translate chinese chinese_4008948_228:
    old "Heh. Still takes your breath away every time, huh?"
    new "嘿嘿。每次都能让你心动不已，对吧？"

translate chinese chinese_6362059_229:
    old "Perfect. Means you're properly motivated."
    new "完美。说明你有足够的动力。"

translate chinese chinese_4001196_230:
    old "Now that you're all fired up... let me get comfortable."
    new "既然你已经这么激动了……让我舒服一点。"

translate chinese chinese_0946667_231:
    old "Now lie down on the floor before you pass out staring."
    new "现在躺到地上去，别愣着直勾勾地看着直到晕过去。"

translate chinese chinese_0867733_232:
    old "Uhh, a- alright..."
    new "呃，好……"

translate chinese chinese_9857757_233:
    old "Perfect."
    new "完美。"

translate chinese chinese_7464704_234:
    old "Your job: stimulate me as hard as you can. Mine: keep breath controlled, sustain notes, hold pitch no matter what."
    new "你的任务：尽可能强烈地刺激我。我的任务：控制呼吸，持续发声，无论发生什么都要保持音调。"

translate chinese chinese_2181871_235:
    old "Got it. Let's do this."
    new "明白了，开始吧。"

translate chinese chinese_3922539_236:
    old "Phew... that was intense."
    new "呼……那真是紧张刺激。"

translate chinese chinese_0553146_237:
    old "Yeah... did it actually work?"
    new "嗯……真的有效吗？"

translate chinese chinese_4688804_238:
    old "Big time. I could feel the control improving even as everything else was going crazy."
    new "很厉害。我甚至能感觉到控制能力在提升，尽管其他一切都乱成一团。"

translate chinese chinese_0872234_239:
    old "Voice held up better than I expected... but yeah, I'm definitely gonna need more of this."
    new "声音比我预期的好多了……但确实，我需要更多这样的训练。"

translate chinese chinese_1508466_240:
    old "A lot more practice before the stage doesn't wreck me."
    new "得多练习，不然上台就会完蛋了。"

translate chinese chinese_1179247_241:
    old "Uhh, if you need it, I'm down to keep helping. Same way you've been helping me."
    new "呃，如果你需要的话，我愿意继续帮忙，就像你帮我一样。"

translate chinese chinese_8932363_242:
    old "You know... with the 'advanced practice' and all."
    new "你知道的……还有那个“高级练习”。"

translate chinese chinese_5091902_243:
    old "Oh, I get it."
    new "哦，我明白了。"

translate chinese chinese_6371282_244:
    old "Heh. Tit for tat, huh? Fair enough."
    new "嘿嘿。以其人之道还治其人之身，公平合理。"

translate chinese chinese_7912117_245:
    old "Deal. You keep me steady under pressure... I'll keep those fingers of yours 'motivated'."
    new "成交。你在压力下让我保持冷静……我会让你的手指“有动力”的。"

translate chinese chinese_0468471_246:
    old "We're both getting better this way. Win-win."
    new "这样我们俩都能进步，双赢。"

translate chinese chinese_4428905_247:
    old "Exactly. Looking forward to it."
    new "没错。很期待。"

translate chinese chinese_9846258_248:
    old "Alright, perv. Now seriously, get out before grandma shows up and smells the trouble."
    new "好了，色狼。说正经的，赶紧滚蛋，别让奶奶来了闻出不对劲。"

translate chinese chinese_1615536_249:
    old "On my way. See you soon... for more 'practice'."
    new "马上就来。很快见……还要更多的“练习”。"

translate chinese chinese_9719111_250:
    old "You better. Don't slack on that guitar either."
    new "你最好别松懈，吉他也不能落下。"

translate chinese chinese_4340442_251:
    old "Wouldn't dream of it."
    new "才不会呢。"

translate chinese chinese_7433594_252:
    old "Wow, you’re on time. That’s new."
    new "wow, 你准时到了。这倒是新鲜事。"

translate chinese chinese_9780878_253:
    old "Yeah... I made sure to wake up early today. Been doing extra practice every day. Feeling ready for whatever comes today."
    new "嗯……我今天特意早起的。每天都在加练。感觉今天无论发生什么都能应对了。"

translate chinese chinese_9198709_254:
    old "Wow. Actual growth. Who would’ve thought?"
    new "wow. 真的有了进步。谁能想到呢？"

translate chinese chinese_2099608_255:
    old "So? No panic attack today?"
    new "所以？今天没有恐慌发作吗？"

translate chinese chinese_1832067_256:
    old "A little butterflies, sure... but I'm fine. We've got this."
    new "有点小紧张，不过我没事。我们能做到的。"

translate chinese chinese_0672466_257:
    old "Look at you. All grown up."
    new "看看你，都长大了。"

translate chinese chinese_4381396_258:
    old "Yeah. I trust what we’ve practiced."
    new "是的，我相信我们的练习。"

translate chinese chinese_9730401_259:
    old "Good. Because today is just about showing what we can already do."
    new "好的。因为今天主要是展示我们已经能做的事情。"

translate chinese chinese_9374038_260:
    old "No panic, no drama."
    new "不要慌，也不要夸张。"

translate chinese chinese_7402308_261:
    old "I'll try to keep the drama to a minimum."
    new "我会尽量减少戏剧化的场面。"

translate chinese chinese_5707911_262:
    old "Do that and I might even be proud of you."
    new "你要是能做到，我甚至可能会为你感到骄傲。"

translate chinese chinese_3040554_263:
    old "High honor."
    new "崇高荣誉。"

translate chinese chinese_1460872_264:
    old "Darlings! Look who we found!"
    new "亲爱的们！看看我们找到了谁！"

translate chinese chinese_7938845_265:
    old "We just finished our private session with Bey. Absolute perfection!"
    new "我们刚和Bey结束了私人环节。绝对完美！"

translate chinese chinese_2045564_266:
    old "The choreography, the lighting cues, the costume changes... we have a full Broadway production ready, honey!"
    new "编舞、灯光提示、换装……亲爱的，我们已经准备好了一场完整的百老汇演出！"

translate chinese chinese_8611262_267:
    old "Everything planned down to the last sparkle. The crowd is going to lose their minds!"
    new "每一点细节都计划好了。大家一定会疯掉的！"

translate chinese chinese_3511423_268:
    old "Great for you."
    new "那很好啊。"

translate chinese chinese_4753848_269:
    old "Oh, look at their little faces. So serious. So... scared."
    new "哦，看看他们的表情。这么严肃。这么……害怕。"

translate chinese chinese_5353116_270:
    old "It’s adorable, really. Like two lost puppies trying to play with the big dogs."
    new "真的好可爱，就像两只迷路的小狗试图和大狗一起玩。"

translate chinese chinese_2990728_271:
    old "You two still look like you’re auditioning for your very first school play."
    new "你们俩看起来还在为第一次学校戏剧试镜呢。"

translate chinese chinese_2777799_272:
    old "While we just delivered a show stopping number that will make people stand up and cheer."
    new "而我们刚刚表演了一个震撼全场的节目，会让人们站起来欢呼。"

translate chinese chinese_1850037_273:
    old "Keep talking, Sparkle Twins."
    new "继续说吧，闪光双胞胎。"

translate chinese chinese_4977553_274:
    old "Cute. Very cute. The underdogs always have that fighting spirit."
    new "真可爱。非常可爱。弱者总是有那种战斗精神。"

translate chinese chinese_8419662_275:
    old "Good luck in there, sweethearts. Try not to faint from all the pressure."
    new "进去好好加油，甜心们。尽量别因为压力太大而晕倒了。"

translate chinese chinese_2484798_276:
    old "Ta-ta, lovebirds! The stage belongs to the stars... not the scared little duo."
    new "拜拜了，情人鸟们！舞台属于明星……而不是这对胆小的二人组。"

translate chinese chinese_6794383_277:
    old "Ughh... I hate those two so much."
    new "呃……我真的很讨厌那两个人。"

translate chinese chinese_1242251_278:
    old "They really know how to get under your skin..."
    new "他们真是知道怎么惹你生气..."

translate chinese chinese_8673803_279:
    old "Good. Let’s use that anger. Time to show Bey what we can really do."
    new "好，就用这份怒气吧。是时候让贝伊看看我们的真正实力了。"

translate chinese chinese_6571856_280:
    old "There you are already! Early today, I wasn’t expecting you two so soon."
    new "你已经来了！今天这么早，我没想到你们会来得这么快。"

translate chinese chinese_7246694_281:
    old "This time we didn't wanna show up late like last session."
    new "这次我们不想像上次那样迟到了。"

translate chinese chinese_2885546_282:
    old "Yeah, sorry if we’re a little early this time."
    new "嗯，抱歉我们这次来早了点。"

translate chinese chinese_2970015_283:
    old "That’s a good problem to have. Gives us extra time to really dig in."
    new "那是个很好的问题。给我们额外的时间来深入了解。"

translate chinese chinese_4592778_284:
    old "So, this is our last tutoring session before the contest."
    new "所以，这是我们在比赛前的最后一节辅导课。"

translate chinese chinese_8565393_285:
    old "How are you both feeling?"
    new "你们俩感觉怎么样？"

translate chinese chinese_0083512_286:
    old "Ready."
    new "准备好了。"

translate chinese chinese_8440463_287:
    old "Nervous... but ready."
    new "紧张……但已经准备好了。"

translate chinese chinese_0495829_288:
    old "That’s exactly how you should feel."
    new "你就是应该有这样的感觉。"

translate chinese chinese_3104207_289:
    old "Alright, let’s do this like before."
    new "好吧，我们就像之前那样来。"

translate chinese chinese_5522397_290:
    old "Perform as if you were already on stage at the contest."
    new "就当自己已经站在比赛的舞台上表演吧。"

translate chinese chinese_4070796_291:
    old "Alright... let’s go."
    new "好吧……我们走。"

translate chinese chinese_2203697_292:
    old "Wow."
    new "wow."

translate chinese chinese_0865765_293:
    old "Is that a good ‘wow’ or...?"
    new "这是在表示惊讶的“哇”还是……？"

translate chinese chinese_1114685_294:
    old "Oh honey, it’s a ‘hell yes’ wow!"
    new "哦亲爱的，当然是“好极了”！"

translate chinese chinese_7488771_295:
    old "This is night and day from your audition. Completely different level."
    new "这和你试镜时的表现简直是天壤之别。完全不一样了。"

translate chinese chinese_1973926_296:
    old "[pla], look at you!"
    new "[pla]，看看你这模样！"

translate chinese chinese_0934832_297:
    old "Me?"
    new "我？"

translate chinese chinese_6845629_298:
    old "From that quiet little tree in the audition to actually carrying the whole song with her!"
    new "从试镜时那个安静的小配角到独挑大梁唱完整首歌！"

translate chinese chinese_5947833_299:
    old "Your chords are locking in perfectly now, your rhythm is steady, and you’re breathing with Billie like you were born to do this."
    new "你的和弦现在完全锁定了，节奏很稳，呼吸也和Billie同步，就像你天生就应该这样做一样。"

translate chinese chinese_2957081_300:
    old "You’re not just following anymore... you’re complementing her. You’re making her voice shine even brighter."
    new "你不仅仅是跟随……你在衬托她。你让她的声音更加闪耀。"

translate chinese chinese_7426402_301:
    old "For real? That actually worked?"
    new "真的吗？那 actually 管用？"

translate chinese chinese_0577971_302:
    old "Yes! You two are finally sounding like a real duo."
    new "没错！你们两个终于听起来像一对真正的搭档了。"

translate chinese chinese_5709223_303:
    old "And Billie... that breath control? Chef’s kiss."
    new "还有比莉……那呼吸控制？简直完美。"

translate chinese chinese_0176199_304:
    old "Absolutely. Way more power behind those soft notes. You’re letting that voice breathe."
    new "绝对的。那些柔和的音符里蕴含着更多的力量。你在让声音自由呼吸。"

translate chinese chinese_5013066_305:
    old "Your breath support is stronger, and you’re keeping your tone stable even in longer phrases."
    new "你的气息更稳了，即使在长句中也能保持音调的稳定。"

translate chinese chinese_0727034_306:
    old "You’re managing your diaphragm much more consciously now."
    new "你现在控制膈肌要自觉得多。"

translate chinese chinese_9060150_307:
    old "That’s... really good to hear."
    new "那……真是很好听。"

translate chinese chinese_1103411_308:
    old "You both sound like a team now."
    new "你们俩现在听起来像一个团队了。"

translate chinese chinese_8357266_309:
    old "Not just two people doing their own thing, but one performance."
    new "不只是两个人各做各的，而是一场表演。"

translate chinese chinese_3133793_310:
    old "That’s what we were aiming for."
    new "那就是我们的目标。"

translate chinese chinese_0534761_311:
    old "Well, I think you’re ready for the contest."
    new "嗯，我觉得你已经准备好参加比赛了。"

translate chinese chinese_1118419_312:
    old "You mean... really ready?"
    new "你是说……真的准备好了？"

translate chinese chinese_7550732_313:
    old "Yes. You should keep practicing, of course."
    new "是的。当然，你应该继续练习。"

translate chinese chinese_4215959_314:
    old "But now it’s about polishing, not fixing big problems."
    new "但现在是打磨细节，而不是解决大问题了。"

translate chinese chinese_1703391_315:
    old "Also... don’t forget to rest."
    new "还有……不要忘了休息。"

translate chinese chinese_4650270_316:
    old "Overworking right before a performance can be just as bad as not practicing."
    new "演出前过度工作可能和不练习一样糟糕。"

translate chinese chinese_3897659_317:
    old "We’ll be careful."
    new "我们会小心的。"

translate chinese chinese_2083281_318:
    old "And one more thing."
    new "还有一件事。"

translate chinese chinese_1494400_319:
    old "Start thinking about your stage look."
    new "开始考虑你的舞台造型吧。"

translate chinese chinese_1024935_320:
    old "O- Our look?"
    new "我—我们的样子？"

translate chinese chinese_3063707_321:
    old "Clothes, style, how you present yourselves."
    new "衣服、风格，你们怎么打扮自己。"

translate chinese chinese_4083166_322:
    old "Your music has a mood. Your image should match it."
    new "你的音乐有氛围，形象也要匹配。"

translate chinese chinese_4414980_323:
    old "Oh, That actually sounds fun."
    new "哦，那听起来还挺好玩的。"

translate chinese chinese_2162581_324:
    old "I’ll be cheering for you both."
    new "我会给你们俩加油的。"

translate chinese chinese_8365364_325:
    old "Thank you. For everything."
    new "谢谢你。一切的一切。"

translate chinese chinese_6786339_326:
    old "Yeah, thank you."
    new "嗯，谢谢。"

translate chinese chinese_4705994_327:
    old "Well... that timing was just perfect."
    new "嗯……那时机真是刚刚好。"

translate chinese chinese_5988589_328:
    old "Yeah, that rain came out of nowhere."
    new "是啊，那雨真是突然来的。"

translate chinese chinese_7860888_329:
    old "Tell me about it."
    new "说来听听。"

translate chinese chinese_0618582_330:
    old "Anyway, go dry off in the bathroom, towel's there."
    new "总之，去洗手间把身上的水擦干，毛巾在那里。"

translate chinese chinese_4252852_331:
    old "I'm heading to my bedroom to change."
    new "我回卧室换衣服去了。"

translate chinese chinese_5538401_332:
    old "Try not to flood the place."
    new "尽量别把这里弄湿了。"

translate chinese chinese_0379862_333:
    old "No promises."
    new "没准。"

translate chinese chinese_9885007_334:
    old "Hey [bil], sorry, I kinda flooded the bathroom floor while drying off-"
    new "嘿[bil]，对不起，我刚才擦身体的时候把浴室地板弄湿了——"

translate chinese chinese_9282546_335:
    old "Hey, eyes up here, perv."
    new "喂，眼睛放上来点，色狼。"

translate chinese chinese_2562851_336:
    old "Heh, what? Rain made them look that good?"
    new "嘿嘿，什么？下雨让它们看起来那么好看？"

translate chinese chinese_3904919_337:
    old "Uhhh, well, I- I can literally see your nipples through the shirt..."
    new "呃，那个，我都能看到你的乳头了……"

translate chinese chinese_6858652_338:
    old "Haha, you’re practically drooling already... you're such a mess"
    new "哈哈，你都快流口水了……真是个大色狼"

translate chinese chinese_2717768_339:
    old "Heh, wanna get a better view?"
    new "嘿嘿，想看得更清楚点吗？"

translate chinese chinese_0618720_340:
    old "I— I- I- Uhhh... y- yea-"
    new "我— 我- 我- 嗯... 嗯- 是的-"

translate chinese chinese_3258045_341:
    old "There. Way better without anything in the way, right?"
    new "好了。没有任何东西挡道，感觉好多了，对吧？"

translate chinese chinese_1635774_342:
    old "Holy shit, [bil]..."
    new "卧槽，[bil]..."

translate chinese chinese_1476155_343:
    old "Heh, oh my gosh... look at you."
    new "嘿嘿，天啊……看你这模样。"

translate chinese chinese_9878372_344:
    old "Someone got rock hard just from staring at my tits."
    new "有人光是盯着我的胸部看就硬起来了。"

translate chinese chinese_8729230_345:
    old "S- Sorry, I can't help it..."
    new "对不起，我控制不住..."

translate chinese chinese_2981394_346:
    old "Obviously. I love how easily I can turn a perv like you into a complete mess."
    new "很明显。我喜欢你能这么轻易地被我搞乱。"

translate chinese chinese_7973457_347:
    old "You know... good boys who practice as hard as you do deserve something special."
    new "你知道吗……像你这么努力的好孩子是值得特别奖励的。"

translate chinese chinese_6977703_348:
    old "And you’ve been such a good boy lately..."
    new "而且你最近表现得这么好……"

translate chinese chinese_5588812_349:
    old "Uhh..."
    new "呃……"

translate chinese chinese_0200445_350:
    old "Yeah, so I think you’ve earned yourself a little prize."
    new "是的，所以我觉得你赚了一个小奖励。"

translate chinese chinese_7261907_351:
    old "Mmm... feel that? Every single inch sliding in..."
    new "嗯……感觉到了吗？每一寸都在滑入……"

translate chinese chinese_3032933_352:
    old "God... you’re so fucking tight..."
    new "上帝……你真是紧得要命……"

translate chinese chinese_6747250_353:
    old "Slow... nice and deep. Let me take control."
    new "慢点……深一点。让我来控制。"

translate chinese chinese_4474747_354:
    old "({i}That was... intense. Too intense.{/i})"
    new "(那太激烈了。太激烈了。)"

translate chinese chinese_7419129_355:
    old "You okay? You look like I just broke your brain."
    new "你还好吗？你看起来像是被我吓到了。"

translate chinese chinese_5344257_356:
    old "I... yeah. I’m good. Just... damn."
    new "我……嗯。我还好。就是……妈的。"

translate chinese chinese_7632738_357:
    old "Heh. 'Damn' is right. We both really needed that, didn’t we?"
    new "嘿嘿。说“真好”是对的。我们两个都挺需要这个的，不是吗？"

translate chinese chinese_6345873_358:
    old "Yeah... I think we did."
    new "嗯……我觉得我们做到了。"

translate chinese chinese_8880133_359:
    old "But... it felt different this time..."
    new "但是……这次感觉不一样……"

translate chinese chinese_2936315_360:
    old "I mean, when we were looking at each other... I could see it in your eyes. You were feeling it too."
    new "我的意思是，当我们对视的时候……我能从你的眼睛里看出来。你也感觉到了。"

translate chinese chinese_5975427_361:
    old "Uhh.. D- Don’t get all sappy on me now..."
    new "呃……别现在变得这么感性……"

translate chinese chinese_1765531_362:
    old "Listen, it was just blowing off steam, okay? Don't start reading too much into it."
    new "听着，那只是发泄一下，别多想。"

translate chinese chinese_0674487_363:
    old "I guess, you're right, still... it felt really good."
    new "我想，你是对的，不过……那感觉真的很棒。"

translate chinese chinese_1182403_364:
    old "Heh. Yeah... you weren’t half bad yourself."
    new "嘿嘿。嗯……你自己也挺不错的。"

translate chinese chinese_9140894_365:
    old "Doesn’t mean I’m going soft on you though."
    new "但这不代表我会对你手下留情。"

translate chinese chinese_5833617_366:
    old "The contest is in a few days. We can’t afford to get distracted."
    new "比赛就在几天后。我们不能分心。"

translate chinese chinese_8989854_367:
    old "Right... back to serious practice."
    new "好吧……回到正经练习。"

translate chinese chinese_6479487_368:
    old "Exactly. Guitar for you, vocals for me. No slacking."
    new "没错。你弹吉他，我唱歌。不许偷懒。"

translate chinese chinese_0052953_369:
    old "But... if you need a little extra 'motivation' again... I guess I can make time."
    new "但是……如果你需要一点额外的“动力”……我想我可以抽时间。"

translate chinese chinese_7224085_370:
    old "I’ll take that."
    new "我来拿这个。"

translate chinese chinese_0108046_371:
    old "Don’t get cocky. Next time I might make you work even harder for it."
    new "别得意得太早，下次我可能会让你更努力才行。"

translate chinese chinese_9908934_372:
    old "Bring it."
    new "来吧。"

translate chinese chinese_4335865_373:
    old "Now seriously, we need to clean up before my grandma walks in and smells sex and rain in my room."
    new "seriously, 我们得赶紧收拾一下，不然我奶奶进来闻到我房间里有性爱和雨的味道就糟了。"

translate chinese chinese_8889725_374:
    old "Yeah... I’m moving."
    new "嗯……我要搬家了。"

translate chinese chinese_9096900_375:
    old "And [pla]?"
    new "还有[pla]？"

translate chinese chinese_8907642_376:
    old "Uhh, nevermind... Just keep practicing like your life depends on it. I expect results."
    new "呃，忘了刚才的话吧……就当你的命悬一线一样继续练习。我等着看你的好成绩。"

translate chinese chinese_5054857_377:
    old "I will. Promise."
    new "我会的。 promise."

translate chinese chinese_8672530_378:
    old "Yeah, you said you needed me for something. But... we've been practicing a lot lately, right?"
    new "是啊，你说你需要我帮忙。但是……我们最近练习了很多，对吧？"

translate chinese chinese_1046246_379:
    old "Heh, yeah. But no, I don't need you for that today."
    new "嘿嘿，是啊。不过今天我不需要你做那个。"

translate chinese chinese_1953548_380:
    old "Wait, seriously? Not practice?"
    new "等一下， seriously? 不是练习？"

translate chinese chinese_3228657_381:
    old "Nope. Today I need you for something else."
    new "不行。今天我需要你做别的事。"

translate chinese chinese_3039455_382:
    old "I want to go buy some clothes. For the contest."
    new "我想去买些衣服。为了比赛。"

translate chinese chinese_1559440_383:
    old "Clothes? Like... an outfit?"
    new "衣服？像……一套服装？"

translate chinese chinese_4366136_384:
    old "Exactly. I don't want to show up in my usual stuff."
    new "没错。我不想去的时候穿我平时的衣服。"

translate chinese chinese_2364196_385:
    old "Those other idiots are probably gonna be all glitter and sequins. I don't wanna look like I didn't even try."
    new "那些白痴肯定全身闪亮亮的。我不想看起来一点准备都没有。"

translate chinese chinese_2597861_386:
    old "Okay, that makes sense. Let's go then. I'll help you pick."
    new "好吧，说得通。那我们走吧。我帮你挑。"

translate chinese chinese_9546205_387:
    old "Good. I already have a few ideas. Come on."
    new "好。我已经有一些想法了。来吧。"

translate chinese chinese_3298927_388:
    old "Alright, there's this store I saw online. Not really my usual vibe, but they might have something that works for the stage."
    new "好吧，我看到一个网店。不是我平时喜欢的风格，但也许他们有些适合舞台的东西。"

translate chinese chinese_6487150_389:
    old "What exactly are you thinking?"
    new "你到底在想什么？"

translate chinese chinese_7231774_390:
    old "Honestly? I don't know yet. I wanna look around, try a bunch of stuff, and see what feels right. Let's just go in."
    new "说实话？我还没想好。我想先四处看看，试试各种事情，找到感觉对的。我们还是进去吧。"

translate chinese chinese_1192469_391:
    old "Hi. I'm performing in a music contest in a few days and I need an outfit that fits the stage."
    new "嗨，我几天后要参加一个音乐比赛，需要一套适合舞台的服装。"

translate chinese chinese_7449793_392:
    old "Hello?"
    new "喂？"

translate chinese chinese_8683679_393:
    old "Huh? Oh. Yeah, everything's for sale. Just browse and bring whatever you want to the counter when you're ready."
    new "huh? 哦。对，这里的东西都可以卖。随便看看，想买什么就拿到收银台就行了。"

translate chinese chinese_4588841_394:
    old "({i}Wow, helpful.{/i})"
    new "({i}哇，真有帮助。{/i})"

translate chinese chinese_1758191_395:
    old "Uh... okay?"
    new "呃……好吧？"

translate chinese chinese_3080359_396:
    old "Hmm, whatever. Let's just look around."
    new "哼，随便吧。我们还是四处看看吧。"

translate chinese chinese_8889191_397:
    old "Yeah. What are you searching for exactly?"
    new "嗯。你具体在找什么？"

translate chinese chinese_2676269_398:
    old "I'm not totally sure yet. I'll grab a few things, try them on, and you tell me what you think. Deal?"
    new "我还没完全确定。我去拿几件东西，试穿一下，你告诉我你觉得怎么样。行吗？"

translate chinese chinese_8486195_399:
    old "Deal. I'll be honest."
    new "行吧。我老实说。"

translate chinese chinese_3791851_400:
    old "You better be."
    new "你最好就是这样。"

translate chinese chinese_0709700_401:
    old "Ready?"
    new "准备好了吗？"

translate chinese chinese_8081036_402:
    old "Yeah. I grabbed a few options... even some wigs. Didn't expect that here."
    new "是啊。我拿了几种选项……甚至还有假发。没想到这里会有这些。"

translate chinese chinese_0931740_403:
    old "Wigs? For the contest?"
    new "假发？参加比赛用的？"

translate chinese chinese_3037690_404:
    old "I'm trying to switch up my whole look a bit. Not going full Sparkle Queen like the others, but... something different."
    new "我打算稍微改变一下我的整体风格。虽然不会像其他人那样变成闪亮女王，但……还是要有点不同。"

translate chinese chinese_6077332_405:
    old "Okay, first one coming out."
    new "好吧，第一个出来。"

translate chinese chinese_0406882_406:
    old "Okay... I was thinking something like what those empty headed girls would wear. Bright, short, cute. What do you think?"
    new "好吧……我在想些像那些空虚的女孩会穿的衣服。亮闪闪的，短款，可爱的。你觉得呢？"

translate chinese chinese_1796268_407:
    old "({i}Holy shit... she actually looks amazing in this. I wasn't expecting the pink to suit her this well.{/i})"
    new "({i}天啊……她穿这个真的超美的。没想到粉色这么衬她。{/i})"

translate chinese chinese_9495480_408:
    old "Use Agamoto's eye"
    new "使用阿伽摩之眼"

translate chinese chinese_3662650_409:
    old "Uhh... Y- you look really good actually. The color pops and the skirt is beautiful... wait, and that hair? It's completely black now."
    new "呃……你 actually 真的很好看。颜色很衬你，裙子也很漂亮……等等，还有你的头发？现在完全是黑色的。"

translate chinese chinese_7627709_410:
    old "It's a wig, obviously."
    new "这很明显是个假发。"

translate chinese chinese_2265118_411:
    old "My green hair would clash horribly with this pink. It'd look ridiculous, so I grabbed a black one to match the outfit."
    new "我这绿头发和粉色搭配起来会很奇怪，看起来会很滑稽，所以我拿了个黑色的来搭配衣服。"

translate chinese chinese_3957457_412:
    old "Uhh... So? What do you think overall? Do you like it?"
    new "呃……所以呢？总体感觉怎么样？你喜欢吗？"

translate chinese chinese_0808594_413:
    old "Totally. It screams 'stage presence'."
    new "完全同意。这简直就是“舞台感”十足。"

translate chinese chinese_3117869_414:
    old "But... it's so pink. So girly. So... not me. Ugh, too cutesy. Nope."
    new "但是……它太粉了。太女性化了。太……不像是我的风格。哎呀，太可爱了。不行。"

translate chinese chinese_5797523_415:
    old "({i}She looks killer though... but I get it.{/i})"
    new "(她确实看起来很辣……但我懂。)"

translate chinese chinese_1276362_416:
    old "Whatever. Next one."
    new "随便吧。下一个。"

translate chinese chinese_1768774_417:
    old "Ok, now this one... more elegant, kinda bohemian, long flowy thing. Thoughts?"
    new "好的，这个……更优雅一些，有点波西米亚风，长而飘逸的款式。觉得如何？"

translate chinese chinese_4700293_418:
    old "({i}Wow... she looks absolutely stunning. The long dress and blonde hair completely transform her vibe.{/i})"
    new "({i}哇……她看起来简直绝了。长裙和金发完全改变了她的气质。{/i})"

translate chinese chinese_3984826_419:
    old "Uhh... Damn, Billie... you look like a whole vibe. Sophisticated, mysterious... and that blonde hair? It's wild on you."
    new "呃……天啊，比莉……你整个人散发出一种气质。既高雅又神秘……还有那金发，在你身上显得特别抢眼。"

translate chinese chinese_9614975_420:
    old "It doesn't look much like a wig, right? I picked one that blended in pretty well."
    new "看起来不像是假发吧？我选了一个融合得很好的。"

translate chinese chinese_6709437_421:
    old "Well, it looks a bit odd to me, but I think it's just because I know you."
    new "嗯，看起来有点奇怪，但可能只是因为我认识你。"

translate chinese chinese_7161819_422:
    old "It's like seeing a completely different person, you know?"
    new "感觉就像看到了一个完全不同的陌生人，你知道吗？"

translate chinese chinese_2746431_423:
    old "A different person? Uhh, but do you think it could actually work for the contest?"
    new "不同的人？嗯，但是你觉得这真的能在比赛中行得通吗？"

translate chinese chinese_4550889_424:
    old "I guess so. It's classy as hell. You'd definitely stand out for sure."
    new "大概吧。这特么真是高大上，你肯定能脱颖而出。"

translate chinese chinese_7612209_425:
    old "Hmm, I don't know... I think it's too much. Way too much, you know?"
    new "嗯，我不知道……我觉得太多了。实在是太多了，你知道吧？"

translate chinese chinese_3621624_426:
    old "I feel like I'm playing dress up as some celebrity. This isn't me at all."
    new "我觉得自己在玩装扮名人游戏。这根本不是我。"

translate chinese chinese_1793131_427:
    old "Ughh, and no more wigs after this. They're boiling hot and I feel super fake wearing them."
    new "哎呀，这次之后再也不戴假发了。热得要命，戴着感觉特别不自然。"

translate chinese chinese_5094662_428:
    old "Alright, moving on."
    new "好吧，继续吧。"

translate chinese chinese_8385118_429:
    old "Okay, this one's bolder. Short skirt, tight top... figured it might grab attention. Be honest."
    new "好吧，这套比较大胆。短裙，紧身上衣……想着可能会吸引注意力。说实话。"

translate chinese chinese_4691199_430:
    old "({i}Holy fuck... her ass is completely exposed. That skirt is barely covering anything...{/i})"
    new "({i}天啊……她的屁股完全暴露了。那条裙子几乎什么都没遮住……{/i})"

translate chinese chinese_8673641_431:
    old "({i}Shit... no, not now! Why the hell am I getting hard right here in the middle of the store? This is so bad...{/i})"
    new "({i}该死……不，不是现在！我怎么会在商店中间硬起来？这太糟糕了……{/i})"

translate chinese chinese_3294141_432:
    old "So? What do you think?"
    new "那么，你怎么看？"

translate chinese chinese_8694768_433:
    old "I- I... Uhh... That's... This one is really nic- ass..."
    new "我——我……呃……这个……这个真的很……好……屁股……"

translate chinese chinese_5835552_434:
    old "Ohhh, look at that. Someone really liked what he saw."
    new "哦呵，看来有人对他看到的东西很感兴趣。"

translate chinese chinese_5955366_435:
    old "You're already rock hard just from staring at my ass. How cute."
    new "光是盯着我的屁股看你就已经硬了。真可爱。"

translate chinese chinese_6938601_436:
    old "I- I can't help it... you look way too good like that."
    new "我、我忍不住……你那样看起来太诱人了。"

translate chinese chinese_2570936_437:
    old "Mmm, really? Then don't just look."
    new "嗯，真的吗？那不要只是看着。"

translate chinese chinese_4511226_438:
    old "So, you really liked this outfit, huh? Why could that be?"
    new "所以，你真的喜欢这套衣服吗？为什么会这样？"

translate chinese chinese_6371021_439:
    old "Do you like how your cock looks between my cheeks?"
    new "你喜欢我的屁股夹着你的棒棒的样子吗？"

translate chinese chinese_7958775_440:
    old "Pull it out. I want to feel that warm big cock against my skin."
    new "拿出来吧。我想感受那温暖的大 cock 贴着我的皮肤。"

translate chinese chinese_2219194_441:
    old "W- wait! Billie! We're in a fitting room... someone could walk in any second!"
    new "等一下！比莉！我们在试衣间……随时都可能有人进来！"

translate chinese chinese_0607996_442:
    old "Relax, dummy. That stupid salesgirl is still glued to her phone. No one's coming this way. We're basically alone."
    new "放松点，傻瓜。那个愚蠢的售货员还在玩手机。没人会往这边来的。我们基本上是单独的。"

translate chinese chinese_0168717_443:
    old "Now take your cock out... or should I do it for you?"
    new "现在把你的家伙拿出来……还是我帮你弄？"

translate chinese chinese_5513454_444:
    old "Mmm... it feels warm... and so hard."
    new "嗯……感觉好温暖……而且好硬。"

translate chinese chinese_4602329_445:
    old "[bil], this is so risky..."
    new "[bil]，这太危险了……"

translate chinese chinese_8302537_446:
    old "That's what makes it fun."
    new "这就是乐趣所在。"

translate chinese chinese_5255083_447:
    old "It's nice you like it so much..."
    new "你喜欢成这样真好……"

translate chinese chinese_0857006_448:
    old "Besides, this feels way too slutty for the stage. Like I'm selling my ass instead of my voice. Hard pass."
    new "再说，这感觉太低俗了，不适合舞台。感觉像是在卖身而不是卖声。免了。"

translate chinese chinese_0338398_449:
    old "({i}She does look fire though... but yeah, she is right.{/i})"
    new "(她确实很辣……但话说回来，她说得对。)"

translate chinese chinese_7710159_450:
    old "Next."
    new "下一个。"

translate chinese chinese_5709321_451:
    old "Last one. Casual but edgy. Urban, not too flashy. What do you say?"
    new "最后一件。休闲但带点酷感。街头风，不要太张扬。你觉得如何？"

translate chinese chinese_5105517_452:
    old "({i}Fuck... even in this one she looks incredible. Those tits in that blue bra...{/i})"
    new "({i}妈的……就算在这里她也看起来超棒的。那蓝色胸罩里的巨乳……{/i})"

translate chinese chinese_2834857_453:
    old "({i}Nooo... not again! I just came all over her ass two minutes ago... What the hell is wrong with me?!{/i})"
    new "({i}Nooo... 又来了！我刚才才射她屁股里... 我这是怎么了?!{/i})"

translate chinese chinese_7868021_454:
    old "Uhh... yeah, this one is nice too..."
    new "嗯……是啊，这个也不错……"

translate chinese chinese_8380371_455:
    old "What? Just that? Wait a second..."
    new "什么？就这？等一下..."

translate chinese chinese_5378790_456:
    old "Are you serious right now?! You just blew a huge load on my ass and you're already rock hard again? Just from seeing me squeeze my tits?"
    new "你现在是认真的吗？！你刚才才在我屁股上射了，现在又硬起来了？就因为我挤了挤胸部？"

translate chinese chinese_5567710_457:
    old "Damn... these really drive you crazy, huh?"
    new "真够烦的……这些真的让你抓狂了吧？"

translate chinese chinese_5303992_458:
    old "Mmm, greedy boy... still got more for me? Let me milk you dry."
    new "嗯，贪心的男孩……还有更多的给我吗？让我榨干你。"

translate chinese chinese_4670930_459:
    old "Come here. Let me take care of that with my tits."
    new "过来。让我用我的胸部来照顾你。"

translate chinese chinese_7338932_460:
    old "Alright, this one isn't right either."
    new "好吧，这个也不对。"

translate chinese chinese_5547686_461:
    old "What? W-why?"
    new "什么？为、为什么？"

translate chinese chinese_6521524_462:
    old "Judging by the way you just got hard again... it doesn't make much difference from the last one."
    new "看你又硬起来了……跟上一个没什么区别嘛。"

translate chinese chinese_3806749_463:
    old "Yeah... I guess you're right."
    new "嗯……我想你是对的。"

translate chinese chinese_2420340_464:
    old "Hmm, whatever... I'm just gonna change back."
    new "哼，随便了……我还是变回去吧。"

translate chinese chinese_3659441_465:
    old "({i}I thought this would be easier...{/i})"
    new "({i}我以为这会简单一点...{/i})"

translate chinese chinese_5914782_466:
    old "Alright, let's go."
    new "好了，我们走吧。"

translate chinese chinese_9046332_467:
    old "W- What? so, none of them? You didn't like any?"
    new "什、什么？一个都不喜欢吗？你一个都没看上？"

translate chinese chinese_1122046_468:
    old "No. None of them feel right. All that color, glitter, fake glamour..."
    new "不。它们都不对劲。那些颜色、亮片、假浮华……"

translate chinese chinese_4861551_469:
    old "It's not me. I don't want to pretend to be someone I'm not just to compete with those idiots."
    new "这不是我的风格。我不想为了和那些白痴竞争而假装成另一个人。"

translate chinese chinese_3648505_470:
    old "({i}She's got a point. That's what makes her special.{/i})"
    new "({i}她说得对。这就是她的特别之处。{/i})"

translate chinese chinese_3816499_471:
    old "Okay, fair enough. So... sticking with your usual look for the contest?"
    new "好吧，公平 enough. 那……还是保持你一贯的风格参加比赛吗？"

translate chinese chinese_5403791_472:
    old "For now, yeah. I'll keep thinking, but I'm not forcing something that doesn't feel like me. Thanks for coming with me though. Seriously."
    new "暂时是这样吧。我会继续想的，但不会强迫自己做不喜欢的事。谢谢你陪我来，真的。"

translate chinese chinese_3457478_473:
    old "Anytime. I had fun watching you rock every single one, even if you hated them."
    new "随时都可以。看你搞定每一个都挺好玩的，哪怕你讨厌他们。"

translate chinese chinese_8623139_474:
    old "Heh. Flatterer. Come on, let's get out of here before I change my mind and buy the whole store."
    new "嘿嘿。拍马屁。走吧，趁我还没改变主意把整个店都买下来。"

translate chinese chinese_2510099_475:
    old "You made it."
    new "你成功了。"

translate chinese chinese_0551559_476:
    old "Of course. You texted 'last practice' like it was serious."
    new "当然了。你发短信说“最后一次练习”，搞得那么认真。"

translate chinese chinese_9591452_477:
    old "Uh... You okay?"
    new "呃……你还好吗？"

translate chinese chinese_1347999_478:
    old "Yeah, don't worry. Come in."
    new "嗯，别担心，进来吧。"

translate chinese chinese_6267178_479:
    old "Tomorrow’s the contest."
    new "明天就是比赛了。"

translate chinese chinese_7512833_480:
    old "Yeah... kinda crazy, huh?"
    new "嗯……挺疯狂的，对吧？"

translate chinese chinese_6165157_481:
    old "I never thought I’d stand on a stage again."
    new "我真没想到自己还能再站上舞台。"

translate chinese chinese_5432383_482:
    old "'Again'?"
    new "“再？”"

translate chinese chinese_7593102_483:
    old "I mean... after everything."
    new "我的意思是……在这一切之后。"

translate chinese chinese_8191126_484:
    old "But you’re here."
    new "但你在这里。"

translate chinese chinese_1825412_485:
    old "Yeah. And that scares me more than the stage."
    new "是啊。这比舞台更让我害怕。"

translate chinese chinese_4658728_486:
    old "Because the stage can’t leave."
    new "因为舞台不能离开。"

translate chinese chinese_2961303_487:
    old "You don’t have to carry everything alone, you know."
    new "你知道吗，你不必一个人承担一切。"

translate chinese chinese_9576492_488:
    old "Let’s run it once. Soft. No pressure."
    new "咱们先来一次，轻松点，不紧张。"

translate chinese chinese_8935269_489:
    old "That felt different."
    new "那感觉不一样。"

translate chinese chinese_6821264_490:
    old "It always does..."
    new "总是这样..."

translate chinese chinese_6297230_491:
    old "Do you know why I really stopped singing?"
    new "你知道我为什么真的停止唱歌了吗？"

translate chinese chinese_0505112_492:
    old "Uhh, your grandma told me some of it."
    new "呃，你奶奶告诉了我一些。"

translate chinese chinese_6214386_493:
    old "She tells the gentle version."
    new "她讲了温和版的。"

translate chinese chinese_4518827_494:
    old "What’s the real one?"
    new "哪个才是真的？"

translate chinese chinese_5090727_495:
    old "When they died... everyone said 'be strong’."
    new "他们去世的时候……每个人都说“要坚强”。"

translate chinese chinese_1997519_496:
    old "So I was."
    new "确实如此。"

translate chinese chinese_8521750_497:
    old "I stopped crying. Stopped singing. Stopped needing."
    new "我不再哭了。不再唱了。不再需要了。"

translate chinese chinese_3597397_498:
    old "That’s not strength."
    new "那不算力量。"

translate chinese chinese_9172043_499:
    old "Well, it felt like survival."
    new "嗯，感觉就像在求生。"

translate chinese chinese_7908450_500:
    old "Every song sounded like them."
    new "每首歌都像在唱他们。"

translate chinese chinese_3615189_501:
    old "Every note felt like losing them again."
    new "每一段旋律都像是再次失去了他们。"

translate chinese chinese_1090841_502:
    old "So you buried it."
    new "所以你把它埋了。"

translate chinese chinese_7597853_503:
    old "Yeah. And I buried part of me with it."
    new "是的。我也把一部分自己埋葬了。"

translate chinese chinese_3902663_504:
    old "But then you showed up. Loud. Stubborn. Impossible."
    new "但然后你就出现了。大声的。固执的。不可思议的。"

translate chinese chinese_8765862_505:
    old "I guess I have a talent for that."
    new "我想我在这方面有点天赋。"

translate chinese chinese_9251344_506:
    old "You dragged me back to something I was scared to touch."
    new "你把我拉回了我害怕触及的东西。"

translate chinese chinese_7405756_507:
    old "And now I’m scared of losing it again."
    new "现在我害怕再次失去它。"

translate chinese chinese_9424365_508:
    old "You won’t."
    new "你不会的。"

translate chinese chinese_0352592_509:
    old "You don’t know that."
    new "你不知道的。"

translate chinese chinese_7240950_510:
    old "I know I’ll be with you."
    new "我知道我会和你在一起的。"

translate chinese chinese_6252802_511:
    old "You promise too easily."
    new "你答应得太容易了。"

translate chinese chinese_0314888_512:
    old "I don’t make promises I can’t keep."
    new "我不会做出无法兑现的承诺。"

translate chinese chinese_4810433_513:
    old "I don’t want to be alone tomorrow, [pla]."
    new "我明天不想一个人待着，[pla]。"

translate chinese chinese_0974788_514:
    old "You won’t be."
    new "你不会的。"

translate chinese chinese_4452214_515:
    old "I mean... really alone."
    new "我是说……真的一个人。"

translate chinese chinese_0569512_516:
    old "Then don’t be."
    new "那你就不要。"

translate chinese chinese_5280447_517:
    old "You don’t run when things get heavy?"
    new "事情变严重了就不跑了？"

translate chinese chinese_3635751_518:
    old "I would never leave you."
    new "我永远不会离开你。"

translate chinese chinese_7722101_519:
    old "What if I break on stage?"
    new "要是我在台上崩了怎么办？"

translate chinese chinese_2606586_520:
    old "Then I’ll be right there, with you."
    new "那我就在你身边。"

translate chinese chinese_6844608_521:
    old "What if I fail?"
    new "如果我失败了怎么办？"

translate chinese chinese_3712192_522:
    old "Then you still tried. And that already makes you brave."
    new "那你还是试了。这已经让你很勇敢了。"

translate chinese chinese_3549470_523:
    old "I don’t want to have to hide anymore."
    new "我不要再躲躲藏藏了。"

translate chinese chinese_2269154_524:
    old "Then don’t."
    new "那别这样做。"

translate chinese chinese_5892183_525:
    old "I don’t know how to do this..."
    new "我不知道该怎么搞……"

translate chinese chinese_6730616_526:
    old "Don’t. Just be real."
    new "别了，就坦白吧。"

translate chinese chinese_9990451_527:
    old "If this goes wrong tomorrow..."
    new "如果明天出了问题……"

translate chinese chinese_9437868_528:
    old "It won’t erase everything we’ve done."
    new "这不会抹去我们做的一切。"

translate chinese chinese_8594903_529:
    old "You’re not scared of me falling apart?"
    new "你不害怕我会崩溃吗？"

translate chinese chinese_8376273_530:
    old "I’m scared of you thinking you have to."
    new "我怕你觉得你非得这样做不可。"

translate chinese chinese_2627788_531:
    old "I don’t know what this is..."
    new "我不知道这是什么……"

translate chinese chinese_6451386_532:
    old "Neither do I. But I know it’s real."
    new "我也不想去。但我知道这是真的。"

translate chinese chinese_1842078_533:
    old "That... wasn’t in the plan."
    new "那……不在计划内。"

translate chinese chinese_4365993_534:
    old "Neither was any of this."
    new "这一切都不是。"

translate chinese chinese_0468598_535:
    old "I don’t want this to be a mistake."
    new "我不希望这变成一个错误。"

translate chinese chinese_0893495_536:
    old "Then let it be a choice."
    new "那就当作是一个选择吧。"

translate chinese chinese_5984928_537:
    old "I think I want you... right now..."
    new "我现在想要你……"

translate chinese chinese_2331190_538:
    old "Hey... whatever happens tomorrow..."
    new "喂……不管明天发生什么……"

translate chinese chinese_8329985_539:
    old "I'm really glad you decided to do this. And I’m really proud of you."
    new "我真的很高兴你决定这么做。我真的很为你感到骄傲。"

translate chinese chinese_4712055_540:
    old "Don’t make me all soft right now."
    new "别现在就让我心软。"

translate chinese chinese_0742766_541:
    old "But... thank you. For pushing me. For being here tonight."
    new "但是……谢谢你。谢谢你推了我一把。谢谢你今晚在这里。"

translate chinese chinese_7167725_542:
    old "I’ll be right there with you on that stage."
    new "我会马上到那个舞台上和你在一起。"

translate chinese chinese_4642064_543:
    old "You better not run away when I get nervous."
    new "我紧张的时候你可别跑。"

translate chinese chinese_7611069_544:
    old "Goodnight, Billie."
    new "晚安，比莉。"

translate chinese chinese_8812534_545:
    old "Goodnight... and [pla]?"
    new "晚安……和[pla]？"

translate chinese chinese_8124763_546:
    old "Hmm?"
    new "哼？"

translate chinese chinese_4825288_547:
    old "Wait... I almost forgot something."
    new "等一下……我差点忘了什么。"

translate chinese chinese_5386840_548:
    old "Give me a second. Don’t move."
    new "等一下，别动。"

translate chinese chinese_7584728_549:
    old "Here. I have something for you."
    new "给你。我有点东西。"

translate chinese chinese_1079724_550:
    old "A jacket?"
    new "一件夹克？"

translate chinese chinese_6550323_551:
    old "It’s my dad’s old one."
    new "是我爸的老款。"

translate chinese chinese_0827986_552:
    old "Billie... I can’t take this."
    new "比莉……我受不了这个。"

translate chinese chinese_2822040_553:
    old "Yes, you can. And you will."
    new "可以，你一定能行。而且你会做到的。"

translate chinese chinese_2981116_554:
    old "No one else deserves to wear it more than you."
    new "没有人比你更配得上穿它。"

translate chinese chinese_4862422_555:
    old "Besides, I can’t let you show up to the contest in that same old t-shirt and those ridiculous pink shorts again."
    new "再说，我不能让你还穿着那件旧T恤和那些荒谬的粉短裤去参加比赛。"

translate chinese chinese_7215124_556:
    old "Hah... fair point."
    new "哈哈……说得也是。"

translate chinese chinese_9788128_557:
    old "I’m serious. I want you to have it."
    new "我是认真的，我想给你。"

translate chinese chinese_4877800_558:
    old "It feels right... you wearing it. It meant a lot to me."
    new "感觉正合适……你穿着它。对我来说意义重大。"

translate chinese chinese_2392316_559:
    old "Then... thank you. I’ll take good care of it."
    new "那么……谢谢你。我会好好照顾它的。"

translate chinese chinese_0606632_560:
    old "Mmm, looking good, handsome."
    new "嗯，看起来不错，帅哥。"

translate chinese chinese_5301326_561:
    old "Heh... you really think so?"
    new "嘿嘿……你真的这么认为？"

translate chinese chinese_6611953_562:
    old "Well, not as good as it looked on him... but damn, it still looks good on you."
    new "嗯，虽然没有在他身上看起来那么好……但妈的，穿在你身上也挺好看的。"

translate chinese chinese_4875527_563:
    old "Now go. Before I change my mind and drag you back to bed."
    new "现在去。不然我改变主意把你拖回床上了。"

translate chinese chinese_9337320_564:
    old "Whoa... you really have gotten bold tonight."
    new "谁啊……你今晚真是大胆多了。"

translate chinese chinese_7063879_565:
    old "But yeah... we both need to rest. Big day tomorrow."
    new "不过……我们都得休息一下。明天是大日子。"

translate chinese chinese_6747600_566:
    old "Go home. Sleep. And be ready."
    new "回家。睡觉。准备好。"

translate chinese chinese_2929951_567:
    old "I will. See you tomorrow... on that stage."
    new "我会的。明天见……在那个舞台上。"

translate chinese chinese_2582587_568:
    old "See you tomorrow."
    new "明天见。"

translate chinese chinese_4581744_569:
    old "({i}Tomorrow changes everything... but tonight was ours.{/i})"
    new "(明天一切都会改变……但今晚属于我们。)"

translate chinese chinese_3886419_570:
    old "Today’s the day..."
    new "今天就是那天了……"

translate chinese chinese_3872894_571:
    old "The contest. Our contest."
    new "那个比赛。我们的比赛。"

translate chinese chinese_8582472_572:
    old "I feel... ready. For the first time in a long time."
    new "我感觉……准备好了。很久以来第一次有这样的感觉。"

translate chinese chinese_9356545_573:
    old "This jacket... it feels like she’s with me already."
    new "这件夹克……感觉她已经陪在我身边了。"

translate chinese chinese_6089194_574:
    old "Alright. Let’s go win this thing."
    new "好吧，让我们去赢了这场。"

translate chinese chinese_7574964_575:
    old "I’m actually early for once."
    new "我这次actually提前了。"

translate chinese chinese_5218089_576:
    old "Billie should be here any minute. She said she’d meet me right here."
    new "比莉应该马上就到。她说会在这里跟我碰面。"

translate chinese chinese_5405866_577:
    old "We’ve practiced so much... today’s gonna be good."
    new "我们练习了这么多……今天一定会很好的。"

translate chinese chinese_0171519_578:
    old "Okay... she’s still not here."
    new "好吧……她还是没来。"

translate chinese chinese_9503353_579:
    old "Where is she? The contest is gonna start soon."
    new "她在哪里？比赛快开始了。"

translate chinese chinese_8661405_580:
    old "She’s probably just running a little late. No big deal."
    new "她可能只是稍微晚一点，没什么大不了的。"

translate chinese chinese_3121790_581:
    old "Look who it is. The tree and his little jacket upgrade."
    new "看谁来了。树和他的小外套升级版。"

translate chinese chinese_3428006_582:
    old "Cute jacket, [pla]. Do you think that’s enough to impress anyone?"
    new "可爱的夹克，[pla]。你觉得这足以让人印象深刻吗？"

translate chinese chinese_2476465_583:
    old "Yeah, good luck trying not to be a statue again."
    new "好吧，祝你这次不要又变成雕像。"

translate chinese chinese_3441593_584:
    old "Whatever. You two just worry about your own act."
    new "随便你们了。你们俩就担心自己的表现吧。"

translate chinese chinese_2044298_585:
    old "We’re up soon. See you losers on stage."
    new "我们马上就要上场了。到时候舞台上见了，各位 loser。"

translate chinese chinese_1343710_586:
    old "They’re already heading in... the contest really is starting."
    new "他们已经进去了……比赛真的要开始了。"

translate chinese chinese_5135419_587:
    old "Still no sign of her..."
    new "还是没有她的踪影……"

translate chinese chinese_5991863_588:
    old "Come on, Billie... you promised."
    new "快点，比莉……你答应过的。"

translate chinese chinese_8876843_589:
    old "Screw it. I’m gonna check if the contest already started."
    new "算了吧，我去看看比赛是不是已经开始了。"

translate chinese chinese_6733149_590:
    old "Oh no... fuck... the contest already started!"
    new "哦不……靠……比赛已经开始了！"

translate chinese chinese_7966659_591:
    old "Fuck, fuck, fuck... Billie still hasn’t arrived."
    new "妈的，妈的，妈的……比莉还没到。"

translate chinese chinese_1032347_592:
    old "Why isn’t she here? What happened?"
    new "她为什么不在这里？发生什么事了？"

translate chinese chinese_5778045_593:
    old "Should I run to her house? But what if she shows up and doesn’t see me?"
    new "我应该跑去她家吗？但如果她出现了却没看到我怎么办？"

translate chinese chinese_8510892_594:
    old "No... I have to wait here. She said she’d come. I know she’s coming."
    new "不……我得在这里等。她说她会来的。我知道她会来。"

translate chinese chinese_9092667_595:
    old "Billie! There you are! Finally!"
    new "比莉！原来你在那儿！终于找到了！"

translate chinese chinese_7161026_596:
    old "Oh wow! You look... beautiful. Really. That outfit... wow."
    new "哦 wow！你看起来……真漂亮。真的。那套衣服……wow。"

translate chinese chinese_8971983_597:
    old "[pla], I... I can’t do this."
    new "[pla]，我……我做不到。"

translate chinese chinese_9663836_598:
    old "Hey, hey what’s wrong? Talk to me."
    new "喂，喂，怎么了？跟我说说。"

translate chinese chinese_7489015_599:
    old "My hands won’t stop shaking. I feel like I’m going to throw up."
    new "我的手停不下来地发抖，感觉要吐了。"

translate chinese chinese_1844520_600:
    old "Every time I close my eyes I hear their voices... my parents. And then I remember they’re gone."
    new "每次闭上眼睛都能听到他们的声音……我父母的。然后我就想起他们已经不在了。"

translate chinese chinese_2695974_601:
    old "What if I open my mouth and nothing comes out? What if I break in front of everyone?"
    new "如果我张嘴却什么也说不出来怎么办？如果我在所有人面前崩溃了怎么办？"

translate chinese chinese_7639243_602:
    old "Breathe. Look at me."
    new "深呼吸。看着我。"

translate chinese chinese_1721839_603:
    old "I’m not ready. I thought I was, but I’m not."
    new "我还没准备好。我以为我准备好了，但其实没有。"

translate chinese chinese_7415329_604:
    old "Come with me. We’re going somewhere quieter."
    new "跟我来。我们去个安静点的地方。"

translate chinese chinese_1500883_605:
    old "Ok, just breathe with me, okay? In... and out."
    new "好，就跟我一起呼吸，好吗？吸...然后呼。"

translate chinese chinese_4382928_606:
    old "I can’t... my chest feels tight."
    new "我……胸口好闷。"

translate chinese chinese_8587493_607:
    old "You’re safe. I’m right here."
    new "你安全了。我在这里。"

translate chinese chinese_8349125_608:
    old "It doesn’t feel safe... it feels like I’m about to lose everything again."
    new "感觉不安全……感觉又要失去一切了。"

translate chinese chinese_3943450_609:
    old "What if I freeze on stage... what if I open my mouth and nothing comes out..."
    new "要是我在台上僵住了……要是我张嘴却发不出声音……"

translate chinese chinese_8342177_610:
    old "Billie, look at me. You’ve practiced this a thousand times."
    new "比莉，看着我。你已经练习过上千次了。"

translate chinese chinese_2250351_611:
    old "Practicing is not the same as standing in front of everyone..."
    new "练习和站在所有人面前是两码事……"

translate chinese chinese_4616652_612:
    old "Every note is going to bring them back... and then they’ll disappear again..."
    new "每一条笔记都会把他们带回来……然后他们又会消失……"

translate chinese chinese_7162817_613:
    old "Hey... hey, come here."
    new "喂……喂，过来。"

translate chinese chinese_8630581_614:
    old "I can’t... I can’t do this..."
    new "我……我做不到……"

translate chinese chinese_3196172_615:
    old "({i}Nothing I say is working... she’s spiraling hard.{/i})"
    new "(我说的话一点用都没有……她的情绪越来越糟了。)"

translate chinese chinese_2778944_616:
    old "Wait! I have an idea!"
    new "等一下！我有个想法！"

translate chinese chinese_7135885_617:
    old "I don’t want to get your dad’s jacket dirty."
    new "我不想把您爸爸的夹克弄脏。"

translate chinese chinese_7499827_618:
    old "I don’t understand..."
    new "我不明白……"

translate chinese chinese_2632058_619:
    old "Well, I want you to take off your dress... and your underwear."
    new "好吧，我想让你脱掉你的裙子……还有内衣。"

translate chinese chinese_5864109_620:
    old "W- what...?"
    new "什...什么？"

translate chinese chinese_4188617_621:
    old "Well, I’m using that technique you showed me once... the one that always works."
    new "嗯，我用你上次教我的那个方法……那个每次都能成功的。"

translate chinese chinese_1604582_622:
    old "It's called 'Plan B'"
    new "这叫“备选计划”"

translate chinese chinese_9510252_623:
    old "I- I am not sur-"
    new "我- 我不确定-"

translate chinese chinese_3857561_624:
    old "You calmed me down the same way once. Let me do the same for you."
    new "你曾经用同样的方式让我冷静下来。现在让我也这样帮你。"

translate chinese chinese_3091479_625:
    old "This is insane..."
    new "这太疯狂了……"

translate chinese chinese_7989907_626:
    old "Come on. Take off your dress... and the underwear. Now."
    new "来吧。把裙子脱了……还有内衣。现在。"

translate chinese chinese_1792557_627:
    old "[pla]... I- I..."
    new "[pla]... 我- 我..."

translate chinese chinese_3752509_628:
    old "I’m not asking twice. Come on, take it all off."
    new "我可不会问第二次。快来，全部脱了。"

translate chinese chinese_7000104_629:
    old "Sit on my face. Let me take care of you."
    new "坐在我脸上。让我来照顾你。"

translate chinese chinese_1328017_630:
    old "You’re really doing this..."
    new "你真的要这么做……"

translate chinese chinese_9195799_631:
    old "Mmm... your tongue..."
    new "嗯……你的舌头……"

translate chinese chinese_8683263_632:
    old "We’re late... but I think I can do this now."
    new "我们迟到了……但我现在觉得我可以做到。"

translate chinese chinese_7021346_633:
    old "Then let’s go win this thing."
    new "那我们就去把这个搞定了。"

translate chinese chinese_0315766_634:
    old "Last call for Billie and [pla]!"
    new "最后呼叫Billie和[pla]！"

translate chinese chinese_1300655_635:
    old "We’re here! We’re coming!"
    new "我们到了！我们来了！"

translate chinese chinese_4905270_636:
    old "Hey... look at me."
    new "喂……看着我。"

translate chinese chinese_0452954_637:
    old "You’ve got this. You’re not alone up there."
    new "你能行的，你不是一个人。"

translate chinese chinese_6021449_638:
    old "Breathe with me, okay? In... and out."
    new "和我一起呼吸，好吗？吸...然后呼。"

translate chinese chinese_6881145_639:
    old "Okay... T- thank you..."
    new "好……谢谢……"

translate chinese chinese_9578563_640:
    old "You’re the one with the voice. I’m just there to hold you steady."
    new "你才是出声的那个，我只是在那里稳住你。"

translate chinese chinese_2132565_641:
    old "You ready?"
    new "准备好了吗？"

translate chinese chinese_5368181_642:
    old "No... but I’m doing it anyway."
    new "不……但我还是要这么做。"

translate chinese chinese_1895093_643:
    old "That's good, let´s go!"
    new "好的，走吧！"

translate chinese chinese_3034839_644:
    old "Do it for them."
    new "为了他们，去做吧。"

translate chinese chinese_0762606_645:
    old "Do it for your mom... and your dad. They’d be so proud of you right now."
    new "为了你的妈妈……还有你的爸爸。他们现在一定会为你感到骄傲的。"

translate chinese chinese_7246697_646:
    old "They would, wouldn’t they?"
    new "他们会这么做的，不是吗？"

translate chinese chinese_8168715_647:
    old "Thank you... for reminding me why I’m here."
    new "谢谢……提醒我为什么在这里。"

translate chinese chinese_7856833_648:
    old "Let’s do this."
    new "干吧。"

translate chinese chinese_5938731_649:
    old "Together."
    new "在一起。"

translate chinese chinese_8531392_650:
    old "Wow... what a night."
    new "wow... 真是疯狂的一晚。"

translate chinese chinese_3486026_651:
    old "First of all, thank you all for waiting so patiently... I know we made you sit through a lot today."
    new "首先，感谢大家耐心等待……我知道今天让大家等了很久。"

translate chinese chinese_3949260_652:
    old "Because you didn’t just perform... you gave us a show we’re never going to forget."
    new "因为你不仅仅是表演……你给我们呈现了一场永生难忘的演出。"

translate chinese chinese_6993443_653:
    old "Every duo showed heart, talent, and courage."
    new "每对搭档都展现了他们的热情、才华和勇气。"

translate chinese chinese_1189797_654:
    old "This wasn’t just a Music contest. This was a night full of real stories, real voices, and real passion."
    new "这不仅仅是一场音乐比赛，这是一个充满真实故事、真实声音和真实热情的夜晚。"

translate chinese chinese_4990670_655:
    old "The jury had an almost impossible job tonight."
    new "陪审团今晚的任务几乎不可能完成。"

translate chinese chinese_5513427_656:
    old "They argued, they debated, they went back and forth... because every single performance deserved to be celebrated."
    new "他们争论，他们辩论，他们反复讨论……因为每一次演出都值得庆祝。"

translate chinese chinese_2338214_657:
    old "But after long deliberation... they finally made their decision."
    new "但在长时间的考虑之后……他们终于做出了决定。"

translate chinese chinese_3368464_658:
    old "The winners of this year’s Music Contest are..."
    new "今年音乐大赛的获胜者是..."

translate chinese chinese_8775540_659:
    old "Come on up here, you two! You earned this."
    new "上来吧，你们两个，你们挣来的。"

translate chinese chinese_6312491_660:
    old "Get your prize and let everyone see the duo that stole the show tonight!"
    new "领取你的奖品，让大家看看今晚抢镜的二人组！"

translate chinese chinese_1886426_661:
    old "We... we actually did it."
    new "我...们真的做到了。"

translate chinese chinese_2117991_662:
    old "I... I can’t believe it."
    new "我……真不敢相信。"

translate chinese chinese_3505525_663:
    old "We did it."
    new "我们做到了。"

translate chinese chinese_2128816_664:
    old "Come on, darling... come and get your trophy."
    new "来吧，亲爱的……来拿你的奖品。"

translate chinese chinese_8196883_665:
    old "Go ahead, this is your moment..."
    new "来吧，这是你的时刻……"

translate chinese chinese_8842492_666:
    old "Billie, honey... would you like to say a few words to the audience?"
    new "比莉，亲爱的……你想对观众说几句话吗？"

translate chinese chinese_6634317_667:
    old "I... no, I’m not good with words."
    new "我……不，我不擅长表达。"

translate chinese chinese_0756053_668:
    old "I don’t think I can..."
    new "我觉得我做不到..."

translate chinese chinese_4771981_669:
    old "Come on, Billie. Say something."
    new "快点，Billie。说点什么。"

translate chinese chinese_3425984_670:
    old "They want to hear from you. You earned this moment."
    new "他们想听你的。这一刻是你赢得的。"

translate chinese chinese_6681107_671:
    old "Okay... just this once."
    new "好吧……就这一次。"

translate chinese chinese_0606962_672:
    old "I... I didn’t think I’d ever sing again."
    new "我……没想到自己还能再唱歌。"

translate chinese chinese_0474819_673:
    old "For years I buried this part of me because every note reminded me of my parents."
    new "多年来我一直压抑着这部分的自己，因为每一个音符都会让我想起我的父母。"

translate chinese chinese_1351705_674:
    old "They taught me to sing. They taught me to love music. And when I lost them... I lost that too."
    new "他们教会了我唱歌，教会了我热爱音乐。而当我失去了他们……我也失去了这一切。"

translate chinese chinese_4195688_675:
    old "But someone stubborn refused to let me hide forever."
    new "但有人死活不肯让我永远躲下去。"

translate chinese chinese_4814832_676:
    old "He dragged me back to the stage... even when I fought him every step of the way."
    new "他硬是把我拖回了舞台……即使我每一步都在反抗。"

translate chinese chinese_3948636_677:
    old "Come here, dummy."
    new "过来，傻瓜。"

translate chinese chinese_0581459_678:
    old "So tonight... this win isn’t just mine. It’s ours."
    new "所以今晚……这个胜利不只是我的，是我们的。"

translate chinese chinese_1871524_679:
    old "Mom... Dad... this one’s for you."
    new "妈妈……爸爸……这个给你们。"

translate chinese chinese_0571893_680:
    old "I still can’t believe we actually won..."
    new "我仍然不敢相信我们真的赢了……"

translate chinese chinese_4665628_681:
    old "You were incredible up there. Everyone saw it."
    new "你在上面太棒了。 everyone 看到了。"

translate chinese chinese_8883478_682:
    old "I didn’t think I’d ever stand on a stage again... and now I’m holding a trophy."
    new "我本以为自己再也不会站上舞台了……而现在我手里拿着奖杯。"

translate chinese chinese_0181964_683:
    old "For a long time I told myself I was going to win just to look strong... I never really believed it."
    new "很长时间里，我告诉自己要赢只是为了显得坚强……我从没真正相信过。"

translate chinese chinese_5297151_684:
    old "But you did win. And it wasn’t fake. It was real."
    new "但是你确实赢了。而且不是假的。是真实的。"

translate chinese chinese_2848370_685:
    old "Your voice came straight from your heart. The others were all flash and technique... but you? You made people feel something."
    new "你的声音发自内心。其他人都是花哨的技巧……但你呢？你让人感同身受。"

translate chinese chinese_0554165_686:
    old "I know so. That’s why you won. Not because of any outfit or trick... because it was you."
    new "我知道的。那就是为什么你能赢。不是因为任何装扮或技巧……是因为是你。"

translate chinese chinese_6318135_687:
    old "It’s weird... I spent years running from this, and now it feels like I finally got a piece of myself back."
    new "真奇怪……我花了好几年逃避这一切，现在却感觉像是终于找回了自己的一部分。"

translate chinese chinese_0354974_688:
    old "You did. And I’m really proud of you."
    new "你做到了。我真的很为你骄傲。"

translate chinese chinese_0789071_689:
    old "I couldn’t have done any of this without you."
    new "没有你，我什么都做不成。"

translate chinese chinese_7293671_690:
    old "You pushed me when I wanted to hide. You stayed when I tried to push you away."
    new "你想让我躲的时候你推了我。我想推开你的时候你却留下来了。"

translate chinese chinese_3729536_691:
    old "I wasn’t going anywhere."
    new "我哪儿也没去。"

translate chinese chinese_4188270_692:
    old "I know... and that means more than you’ll ever understand."
    new "我知道……而且这比你想象的要重要得多。"

translate chinese chinese_7187692_693:
    old "Speaking of outfits... you never really said anything about this one."
    new "说到衣服了……你从来没提过这件呢。"

translate chinese chinese_2418174_694:
    old "What do you think? Be honest."
    new "你怎么看？诚实点。"

translate chinese chinese_4465864_695:
    old "You look... stunning. It’s edgy, it’s dark, it’s completely you. No one else could pull it off like that."
    new "你看起来……惊艳。这很前卫，很暗黑，完全就是你的风格。没人能像你这样驾驭得住。"

translate chinese chinese_1375524_696:
    old "Heh... good answer."
    new "嘿嘿……好回答。"

translate chinese chinese_3777484_697:
    old "I was nervous about wearing something so different... but the way you’re looking at me right now..."
    new "我本来还担心穿这么不一样的衣服……但是你现在的样子……"

translate chinese chinese_7952228_698:
    old "Makes me want to give you a better view."
    new "让我想给你一个更好的视角。"

translate chinese chinese_5922233_699:
    old "Tonight I want to celebrate... my way."
    new "今晚我想庆祝一下……我的方式。"

translate chinese chinese_1387406_700:
    old "You’ve been staring at my tits all night... time to give them some attention."
    new "你整晚都在盯着我的胸部……是时候给它们一些关注了。"

translate chinese chinese_4439550_701:
    old "Mmm... morning already?"
    new "嗯……已经早上了吗？"

translate chinese chinese_8505572_702:
    old "Yeah... I don’t want it to be."
    new "是啊……我不希望这样。"

translate chinese chinese_7094078_703:
    old "Last night still feels like a dream."
    new "昨晚的感觉依然像一场梦。"

translate chinese chinese_3753959_704:
    old "It wasn’t a dream. You won. We won."
    new "这不是梦。你赢了。我们赢了。"

translate chinese chinese_9697273_705:
    old "And I didn’t completely fall apart... thanks to you."
    new "而且我也没有完全崩溃……多亏了你。"

translate chinese chinese_7473319_706:
    old "You didn’t need me to win. You just needed to remember who you are."
    new "你不需要我就能赢。你只需要记住你是谁。"

translate chinese chinese_6424221_707:
    old "Still... having you there made it feel possible."
    new "虽然如此……有你在身边让我觉得这一切都是可能的。"

translate chinese chinese_4507071_708:
    old "I don’t usually do the whole ‘morning after’ thing."
    new "我通常不做那种“晨后”事情。"

translate chinese chinese_9334904_709:
    old "Neither do I... but I’m really glad we did."
    new "我也不……但是真的很高兴我们做了。"

translate chinese chinese_8279452_710:
    old "Don’t get used to it, though. I’m still the same Billie."
    new "不过别以为就这样了，我还是原来的比莉。"

translate chinese chinese_1979895_711:
    old "Good. I like that Billie."
    new "很好。我就喜欢这样的比莉。"

translate chinese chinese_6468272_712:
    old "...."
    new "...."

translate chinese chinese_6719187_713:
    old "You should probably head home before your family starts asking questions."
    new "你最好早点回家，免得家人开始问东问西。"

translate chinese chinese_7051553_714:
    old "But last night... everything we did, everything we said..."
    new "但是昨晚……我们做的一切，说的一切……"

translate chinese chinese_1830504_715:
    old "It meant a lot to me."
    new "这对我来说意义重大。"

translate chinese chinese_5691055_716:
    old "It meant a lot to me too."
    new "对我来说也意义重大。"

translate chinese chinese_9299857_717:
    old "I’m not great at saying this stuff, but... thank you. For not giving up on me. For pushing me. For staying."
    new "我不擅长说这种话，但是……谢谢你。没有放弃我。一直激励我。一直陪在我身边。"

translate chinese chinese_5833521_718:
    old "Alright, we better get dressed."
    new "好吧，我们还是穿好衣服吧。"

translate chinese chinese_2658321_719:
    old "I’ll see you at school later?"
    new "一会儿学校见？"

translate chinese chinese_8162164_720:
    old "Yeah... I’ll be there."
    new "嗯……我会去的。"

translate chinese chinese_2405663_721:
    old "And don’t be late, or I’ll drag you back here again."
    new "而且不要迟到，否则我还会把你拖回来的。"

translate chinese chinese_0474178_722:
    old "Wouldn’t miss it."
    new "不会错过的。"

translate chinese chinese_1219791_723:
    old "Take care of yourself, Billie."
    new "照顾好自己，比莉。"

translate chinese chinese_4369525_724:
    old "You too."
    new "你也是。"

translate chinese chinese_2594834_725:
    old "({i}He really stayed... and I didn’t push him away.{/i})"
    new "(他真的留下了……而我没有推开他。)"

translate chinese chinese_2007814_726:
    old "I guess I know what it means..."
    new "我大概明白是什么意思了……"

translate chinese chinese_2057756_727:
    old "Alright... time for some practice."
    new "好吧……该练习了。"

translate chinese chinese_0966571_728:
    old "It’s becoming part of the routine... and I actually look forward to it."
    new "这已经成为例行公事了……而且我实际上很期待它。"

translate chinese chinese_0889116_729:
    old "Feels natural now... like the guitar is actually listening."
    new "现在感觉很自然……就像吉他真的在听你一样。"

translate chinese chinese_6400669_730:
    old "({i}This is actually fun... who would’ve thought?{/i})"
    new "(这 actually 真的挺好玩的……谁会想到呢？)"

translate chinese chinese_6431707_731:
    old "Still a couple of rough spots... but overall it sounded solid."
    new "还有一些粗糙的地方……但总体听起来还不错。"

translate chinese chinese_5579923_732:
    old "It doesn’t feel like a chore anymore. It feels... right."
    new "这不再像是任务了。感觉……对了。"

translate chinese chinese_8234174_733:
    old "Tomorrow I’ll pick it up again... no pressure, just playing."
    new "明天再接着玩吧……不着急，就当放松。"

translate chinese chinese_4943984_734:
    old "Yeah... I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "嗯……我一个人练了很多，但感觉和你在一起时进步更快。"

translate chinese chinese_7414526_735:
    old "Rehearse the song together"
    new "一起练习这首歌"

translate chinese chinese_0706047_736:
    old "I want to polish the chords even more, you know..."
    new "你知道的，我还想把和弦打磨得更精细一些……"

translate chinese chinese_9532421_737:
    old "Heh. Going for the safe route first? Fine by me... for now."
    new "嘿嘿。先走安全路线？行啊……暂时先这么着吧。"

translate chinese chinese_0040710_738:
    old "Hmm... your changes are actually smooth now. You’ve been practicing."
    new "嗯……你的变化现在挺自然的。你肯定练过。"

translate chinese chinese_5050887_739:
    old "Still... I wouldn’t mind if you picked something a little more fun next time."
    new "不过……下次如果你能选个好玩点的，我就谢天谢地了。"

translate chinese chinese_9950577_740:
    old "Finger practice"
    new "手指练习"

translate chinese chinese_7736291_741:
    old "They’re... so soft every time. I can feel them filling my hands."
    new "它们……每次都很软，我能感觉到它们填满了我的手。"

translate chinese chinese_2320003_742:
    old "Mmm... squeeze them slowly. Open and close your hands... just like that."
    new "嗯……慢慢捏。张开手指再合上……就是这样。"

translate chinese chinese_1367937_743:
    old "Nngh— yeah... a little harder now. Grip them properly."
    new "嗯——对了……现在再用力一点。握紧点。"

translate chinese chinese_4478219_744:
    old "Fuck... keep that pace. Squeeze them like you mean it."
    new "操……保持这个节奏。用力捏。"

translate chinese chinese_2164061_745:
    old "Now the nipples... grab them and pull... slow at first."
    new "现在是乳头……抓住它们然后拉扯……一开始慢一点。"

translate chinese chinese_7436708_746:
    old "That’s it... stretch them gently."
    new "就这样……轻轻地拉伸它们。"

translate chinese chinese_2443635_747:
    old "Fuck... faster. Pull them nice and firm. I love how confident your hands feel now."
    new "操... 快点。把它们捏紧些。我喜欢你现在手上的自信感觉。"

translate chinese chinese_4404109_748:
    old "Mmm... your touch is way more precise lately. You’ve improved a lot."
    new "嗯……你最近的手法精准多了。进步很大。"

translate chinese chinese_1205526_749:
    old "Keep practicing that rhythm at home... or just come back whenever you want more of... this."
    new "在家继续练习那个节奏……或者你想再来……这个的时候就回来吧。"

translate chinese chinese_5807461_750:
    old "Advanced finger practice"
    new "高级手指训练"

translate chinese chinese_0369087_751:
    old "Uhh... I’ve been practicing the guitar a lot by myself lately."
    new "嗯……我最近一个人练习吉他挺多的。"

translate chinese chinese_9252872_752:
    old "And I was thinking... maybe it would be good if I helped you with your practice too, you know?"
    new "而且我在想……也许我也帮你练习会比较好，你知道吗？"

translate chinese chinese_5279882_753:
    old "Like... helping you stay steady under pressure... like last time..."
    new "比如……帮你稳住压力……就像上次那样……"

translate chinese chinese_3210006_754:
    old "Heh... look at you trying to be all subtle."
    new "嘿嘿……看你装模作样。"

translate chinese chinese_6279919_755:
    old "Get motivated"
    new "振作起来"

translate chinese chinese_1490111_756:
    old "And sometimes I feel like I still need... a little extra motivation to keep improving."
    new "有时候我觉得我还需要一点额外的动力来继续进步。"

translate chinese chinese_9463933_757:
    old "Heh... so that’s what this is really about."
    new "嘿嘿……原来如此。"

translate chinese chinese_4009542_758:
    old "Just looking at them... does that help?"
    new "just看着它们……有帮助吗？"

translate chinese chinese_3189475_759:
    old "Y-yeah... they look amazing but... I was thinking maybe something more... direct?"
    new "嗯……他们看起来很棒，但是……我在想也许可以更……直接一点？"

translate chinese chinese_6676055_760:
    old "Heh... fine. I know exactly how to motivate you properly."
    new "嘿嘿……好吧。我知道怎么正好激励你。"

translate chinese chinese_9464784_761:
    old "Phew... that’s enough for today."
    new "呼……今天就到此为止吧。"

translate chinese chinese_6148324_762:
    old "Hey... before you go."
    new "喂……走之前。"

translate chinese chinese_3163919_763:
    old "It’s important... and I don’t want to go alone."
    new "这很重要……而且我不想去一个人去。"

translate chinese chinese_0353310_764:
    old "Oh, by the way..."
    new "哦，对了..."

translate chinese chinese_9154071_765:
    old "Just text me. I’ll always make time... especially if you want the fun version."
    new "就发短信给我吧。我总会留出时间……特别是如果你想听有趣版本的话。"

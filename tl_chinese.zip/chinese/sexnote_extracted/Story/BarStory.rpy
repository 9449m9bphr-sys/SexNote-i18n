# auto-tl Qwen Colab

translate chinese chinese_7142635_0:
    old "Hey [pla], wake up!"
    new "喂，[pla]，醒醒！"

translate chinese chinese_9653184_1:
    old "Hmm... Just a little longer..."
    new "嗯……再久一点……"

translate chinese chinese_2739252_2:
    old "I said..."
    new "我说了..."

translate chinese chinese_6130792_3:
    old "What? What's happening? Is there anything wrong?!"
    new "什么？发生什么事了？有什么不对劲吗？！"

translate chinese chinese_3171673_4:
    old "What's wrong is that it's been a while since I created the portal we're going to use to restore the magic world."
    new "问题是，自从我创建用来恢复魔法世界的传送门以来，已经有一段时间了。"

translate chinese chinese_1204489_5:
    old "But I haven't seen you make any progress with our objective ever since."
    new "但是自从那以后，我可没看到你在目标上有什么进展。"

translate chinese chinese_2207211_6:
    old "Why is it taking so long for you to get to it?"
    new "你为什么这么慢才进入正题？"

translate chinese chinese_7824623_7:
    old "What?! You woke me up for that? What are you talking about?"
    new "什么?! 你就为这个把我吵醒？你在说什么？"

translate chinese chinese_3120708_8:
    old "It's not as if it's easy you know?"
    new "这可不是那么容易的你知道吗？"

translate chinese chinese_2123227_9:
    old "Do you want me to just walk around and tell people {i}'Hey! let me get you pregnant'{/i}?"
    new "你想让我到处走然后跟人说“嘿！让我给你怀孕”吗？"

translate chinese chinese_0324884_10:
    old "I can already imagine the looks I'll get."
    new "我已经能想象到别人看我的眼神了。"

translate chinese chinese_4125593_11:
    old "That's not what you're going to do! You have to seduce them!"
    new "你不是要去这么做！你要诱惑他们！"

translate chinese chinese_0987279_12:
    old "I thought you were supposed to be charming to human females."
    new "我还以为你要对人类女性迷人呢。"

translate chinese chinese_0420848_13:
    old "Try that!"
    new "试试这个！"

translate chinese chinese_1189280_14:
    old "Why are you so worried about me doing it quickly anyway?"
    new "你干嘛这么担心我快点做呢？"

translate chinese chinese_0663851_15:
    old "I thought you had stabilized the portal. So we have time, right?"
    new "我以为你稳定了传送门。所以我们还有时间，对吧？"

translate chinese chinese_9302220_16:
    old "Yeah, time to do the ritual properly."
    new "好吧，是时候正式进行仪式了。"

translate chinese chinese_0635104_17:
    old "Not to laze around and not get anything done!"
    new "不要懒散度日，一事无成！"

translate chinese chinese_0124561_18:
    old "This is urgent business [pla]."
    new "这是紧急事务[pla]。"

translate chinese chinese_7790533_19:
    old "The magic world is gone, and this portal might be the only chance we get to save it."
    new "魔法世界已经消失，这个传送门可能是我们唯一的机会来拯救它。"

translate chinese chinese_2220425_20:
    old "And the fact that it's stable for now doesn't mean it's going to last forever."
    new "而且现在稳定并不意味着会永远持续。"

translate chinese chinese_9762274_21:
    old "If we want to reform the magic world we need to move fast!"
    new "如果我们想改造魔法世界，就得赶紧行动！"

translate chinese chinese_2881168_22:
    old "There's no time to just lay about doing nothing."
    new "没时间什么都不做了。"

translate chinese chinese_8738124_23:
    old "Ok, I get it I get it! I'll get to it!"
    new "好了好了，我懂了！我会去做的！"

translate chinese chinese_6148922_24:
    old "When?"
    new "什么时候？"

translate chinese chinese_2526395_25:
    old "Soon!"
    new "很快！"

translate chinese chinese_6389195_26:
    old "Jeez! What's gotten into you all of a sudden?!"
    new "喂！你突然怎么了嘛！"

translate chinese chinese_5788661_27:
    old "I'll remind you that you and your little friend Linnet made a mess out of this entire situation!"
    new "我要提醒你，你和你那个小朋友林奈特把整个局面搞砸了！"

translate chinese chinese_6664708_28:
    old "And I'm the one that's going to have to fix it!"
    new "而我要去解决这个问题！"

translate chinese chinese_9590062_29:
    old "So, since the portal won't last forever, and you clearly don't want to re-start the process from the beginning..."
    new "所以，既然传送门不会永远开着，而且你显然不想从头再来……"

translate chinese chinese_6080518_30:
    old "Start looking for the people we need!"
    new "开始找我们需要的人吧！"

translate chinese chinese_8885600_31:
    old "Ok, ok, I'll do it!... I guess I could start talking to people."
    new "好啦好啦，我会做的……我想我可以开始和人聊天了。"

translate chinese chinese_6987869_32:
    old "It's just that that's quite difficult to do, you know?"
    new "只是那个挺难做的，你知道吧？"

translate chinese chinese_7784813_33:
    old "Oh come on, it won't be that bad."
    new "Oh come on, it won't be that bad. \n\n（注：此处保留了原文，因为这是角色对话中的一种表达方式，直接翻译可能会失去原意或效果。） \n\n真来吧，不会那么糟糕的。"

translate chinese chinese_8551492_34:
    old "I bet you'll get to have plenty of fun."
    new "我敢打赌你会玩得很开心的。"

translate chinese chinese_8457281_35:
    old "Hello [pla], good morning."
    new "你好 [pla]，早上好。"

translate chinese chinese_3160851_36:
    old "H- hi [mo1rel], how are you? Good morning."
    new "嗨，[mo1rel]，你好吗？早上好。"

translate chinese chinese_9737894_37:
    old "Were you talking to someone?"
    new "你在跟谁说话？"

translate chinese chinese_3527730_38:
    old "What? No, no, no..."
    new "什么？不，不，不……"

translate chinese chinese_2550291_39:
    old "Just to myself, you know?"
    new "就是自己享受一下，你知道的？"

translate chinese chinese_7546537_40:
    old "Ohh... Okay."
    new "哦……好的。"

translate chinese chinese_0593538_41:
    old "Listen [pla], I need you to do me a favor."
    new "听好了[pla]，我需要你帮我个忙。"

translate chinese chinese_6197254_42:
    old "{i}(Jeez, what's gotten into Brixxida all of a sudden?){/i}"
    new "{i}(天啊，布里克西达突然怎么了？){/i}"

translate chinese chinese_3678537_43:
    old "Hmm... [pla]?"
    new "嗯……[pla]？"

translate chinese chinese_0139005_44:
    old "Uhh... Sure, what do you need?"
    new "呃……好啊，你需要什么？"

translate chinese chinese_6988797_45:
    old "Well, I was wondering if you could please bring some documents to the [mo2]'s office for me."
    new "嗯，我想请你帮我把一些文件送到[mo2]的办公室。"

translate chinese chinese_1177764_46:
    old "You don't need to go up to her office, just leave them at the reception of the building."
    new "你不用去她的办公室，把东西放在大楼的前台就行了。"

translate chinese chinese_1984501_47:
    old "Sure, no problem."
    new "行，没问题。"

translate chinese chinese_2902244_48:
    old "Thank you so much, honey. You are always so helpful."
    new "谢谢你啊，亲爱的。你总是这么帮倒忙。"

translate chinese chinese_9920203_49:
    old "Hmm... I suppose you're going to do that for your [mo1rel] now, aren't you?"
    new "嗯……我想你现在为了你的[mo1rel]也会这么做的，对吧？"

translate chinese chinese_0486675_50:
    old "Uhh... Yeah, Of course."
    new "呃……是的，当然。"

translate chinese chinese_9661965_51:
    old "Okay, I'm coming with you. You won't stop our task, so I'll help you look for our first target."
    new "好吧，我跟你一起去。你不会放弃我们的任务，那我就帮你一起找第一个目标。"

translate chinese chinese_8082667_52:
    old "{b}*Sigh*{/b} Alright, let's go."
    new "{b}*叹气*{/b} 好吧，我们走吧。"

translate chinese chinese_9136476_53:
    old "So, as I was saying, you should've at least talked to somebody while we were coming here."
    new "所以，就像我刚才说的，我们在来这里的路上，你至少也应该和人聊一聊的。"

translate chinese chinese_5277822_54:
    old "At this rate you're never going to end with what we have to do!"
    new "这样下去，我们永远也完不成要做的事情了！"

translate chinese chinese_5079843_55:
    old "You should be putting all your focus on that!"
    new "你应该把全部注意力放在那上面！"

translate chinese chinese_5316194_56:
    old "But I have to do this first! So let me finish here, and then we can start looking for people for your ritual!"
    new "但我得先做这个！所以让我先把这里搞定，然后我们就可以开始为你找仪式需要的人了！"

translate chinese chinese_5746999_57:
    old "Alright! But as soon as you finish, I'll pester you to get to it!"
    new "好啦！但你一完事，我就缠着你要你去做！"

translate chinese chinese_0652748_58:
    old "Yeah, yeah, whatever."
    new "好吧好吧，随便你。"

translate chinese chinese_0501844_59:
    old "Oh... Uhh... Yeah, Hi Barbie, how are you doing?"
    new "哦……嗯……嗨，芭比，你最近怎么样？"

translate chinese chinese_1825509_60:
    old "Uhh... No, actually, I didn't come to see her."
    new "呃……不，其实，我不是来看她的。"

translate chinese chinese_6600954_61:
    old "I have something for [mo2], but I was told I could just leave it with you."
    new "我有东西要给[mo2]，但被告知可以交给你就好了。"

translate chinese chinese_7160629_62:
    old "Hey, [pla]!! Did you hear what I told you?!"
    new "喂，[pla]！你听到我说的话了吗？！"

translate chinese chinese_6484483_63:
    old "What? No, no, sorry."
    new "什么？不，不，对不起。"

translate chinese chinese_2034211_64:
    old "I- uhm, I didn't mean to be rude."
    new "我——嗯，我不是故意要粗鲁的。"

translate chinese chinese_4510205_65:
    old "I meant to say, {i}‘ok, alright, that's great'{/i}."
    new "我想说的是，{i}“好的，好吧，那太好了”{/i}。"

translate chinese chinese_3486721_66:
    old "Right."
    new "对。"

translate chinese chinese_0935239_67:
    old "Sure, thank you."
    new "好的，谢谢。"

translate chinese chinese_6021859_68:
    old "Thanks Barbie, I guess I'll see you later."
    new "谢谢芭比，我想我待会儿见吧。"

translate chinese chinese_5204264_69:
    old "Great news [pla]! As I told you before, we have the first target to start cultivating power for the spell!"
    new "好消息，[pla]！就像我之前告诉你的，我们有了第一个目标来开始为这个咒语积累力量！"

translate chinese chinese_1117775_70:
    old "Yeah, I figured..."
    new "嗯，我猜到了……"

translate chinese chinese_3743448_71:
    old "Is that why you interrupted me while I was talking to her?"
    new "这就是你为什么在我跟她说话时打断我的原因吗？"

translate chinese chinese_1804704_72:
    old "Well, it was important that you knew..."
    new "嗯，重要的是你知道了……"

translate chinese chinese_8462636_73:
    old "But anyway, that doesn't matter."
    new "不过话说回来，这都不重要。"

translate chinese chinese_9481045_74:
    old "What's important is that that woman you were talking with will be our first target."
    new "重要的是，你刚才聊天的那位女士将会是我们第一个目标。"

translate chinese chinese_7192533_75:
    old "Well, while you two were talking, I was examining her."
    new "嗯，你们俩聊天的时候，我在检查她。"

translate chinese chinese_5441269_76:
    old "Yeah, I noticed... That was weird, luckily no one else can see you."
    new "是啊，我注意到了……那挺奇怪的，还好没人能看见你。"

translate chinese chinese_9400783_77:
    old "Yeah, yeah, whatever, the point is that she's the first person you have to seduce for our ritual."
    new "好吧好吧，重点是她是你要第一个勾引的人，为了我们的仪式。"

translate chinese chinese_7855615_78:
    old "Huh?! W- why? Why does it have to be her?"
    new "huh?! W-为什么？为什么非得是她？"

translate chinese chinese_4764869_79:
    old "Because she's the right specimen, she has just the right qualities we need for it."
    new "因为她正是我们需要的样本，具备我们所需要的全部特质。"

translate chinese chinese_3011226_80:
    old "As far as you humans go, she's the best prospect I could have expected to find to start our ritual."
    new "就你们人类而言，她是我能找到的最适合开始我们仪式的人选。"

translate chinese chinese_7621607_81:
    old "Why? What's so special about her?"
    new "为什么？她有什么特别的？"

translate chinese chinese_5298540_82:
    old "Well, as I said she has the perfect qualities... To- to..."
    new "嗯，就像我说的，她具备完美的特质……呃……"

translate chinese chinese_8465723_83:
    old "H- host and... Condense the magic power within her."
    new "主... 主人和... 压缩她体内的魔力。"

translate chinese chinese_7715034_84:
    old "Her body composition is just the right one."
    new "她的身材刚刚好。"

translate chinese chinese_9003516_85:
    old "Right..."
    new "嗯……"

translate chinese chinese_8437736_86:
    old "Besides, this should be easy to do, right?"
    new "再说，这应该很容易做到吧？"

translate chinese chinese_7311403_87:
    old "Isn't she the type of female you male humans like?"
    new "她不是你们人类男性喜欢的那种类型吗？"

translate chinese chinese_4255486_88:
    old "Her mammary glands are gigantic, even for the standards of what your species would consider big."
    new "她的乳房大得惊人，即使以你们种族的标准来看也属于巨大的。"

translate chinese chinese_1238631_89:
    old "And I {i}know{/i} you just love that sort of thing."
    new "而且我{i}知道{/i}你最喜欢这种事了。"

translate chinese chinese_5667119_90:
    old "So don't think too much about it. Just focus on having a good time."
    new "所以别想太多，just focus on having a good time."

translate chinese chinese_1821101_91:
    old "If you seduce her, and implant the magic within her you'll enjoy it, won't you?"
    new "如果你勾引她，并把魔法植入她体内，你会享受的，不是吗？"

translate chinese chinese_3308174_92:
    old "Ugh, I guess you're right."
    new "唉，我想你是对的。"

translate chinese chinese_4742373_93:
    old "But I barely know her, we have never exchanged more than a couple of words, how the hell am I going to seduce her?"
    new "但我几乎不认识她，我们从来没有说过几句话，我怎么可能勾引她？"

translate chinese chinese_7053833_94:
    old "Don't worry, I'll help you with that."
    new "别担心，我会帮你搞定的。"

translate chinese chinese_7384366_95:
    old "Hahaha... Really? How?"
    new "哈哈……真的吗？怎么做到的？"

translate chinese chinese_0595122_96:
    old "By using magic of course!"
    new "当然是用魔法了！"

translate chinese chinese_0037229_97:
    old "There's a lot of magic you still don't know about, you've barely scratched the surface of what's possible."
    new "还有很多魔法是你不知道的，你只是刮到了可能性的表面而已。"

translate chinese chinese_8324525_98:
    old "By employing a simple mind reading spell, I can get inside her thoughts and emotions."
    new "通过使用一个简单的读心咒语，我可以进入她的思想和情感。"

translate chinese chinese_6995665_99:
    old "And let you know what she has in her mind while you're speaking to her."
    new "让你知道她在你说话时心里在想什么。"

translate chinese chinese_2204723_100:
    old "I can even read deep thoughts, and see if anything is influencing her deep mind."
    new "我甚至能读取深层思绪，看看是否有东西在影响她的内心深处。"

translate chinese chinese_8763940_101:
    old "I have to say, that sounds amazing."
    new "不得不说我听起来好极了。"

translate chinese chinese_3009821_102:
    old "It is, but it's also inconvinient. Since I'll be reading her mind and telling you what she's thinking."
    new "是的，但也很麻烦。因为我将会读她的想法然后告诉你她在想什么。"

translate chinese chinese_3706803_103:
    old "That means that whenever you talk to her I'll have to be with you."
    new "那也就是说每次你跟她说话我都得陪着你。"

translate chinese chinese_5794305_104:
    old "Besides, in order to maintain the mind-reading, I have to keep the channel between her mind and mine open."
    new "再说，为了保持读心能力，我必须保持她的思维和我的思维之间的通道畅通。"

translate chinese chinese_1428890_105:
    old "That drains the magic power too quickly."
    new "那样会很快耗尽魔力。"

translate chinese chinese_8826230_106:
    old "So you'll have to be sure to make good use of the information I'm able to give you."
    new "所以你得确保好好利用我能给你的信息。"

translate chinese chinese_7503226_107:
    old "I get it, but if it's that difficult, why don't you teach me the spell to do it myself?"
    new "我明白，但如果这么难，为什么不教我这个咒语自己来做呢？"

translate chinese chinese_0148632_108:
    old "That way I can just do the mind reading by myself, and your magic reserves won't have to be drained."
    new "这样我就可以自己读心了，你的魔法储备就不会被耗尽了。"

translate chinese chinese_0993747_109:
    old "Sadly I can't do that, this spell is a level beyond your current abilities."
    new "可惜不行，这个咒语超出了你的当前能力水平。"

translate chinese chinese_4965831_110:
    old "The complexity is too high for you to handle right now."
    new "这个复杂度你现在还应付不来。"

translate chinese chinese_0304101_111:
    old "Maybe if you had been a bit more diligent with your practices..."
    new "也许你平时练习再勤快点……"

translate chinese chinese_4803619_112:
    old "And had improved your abilities with the Sexnote, you'd be able to do it."
    new "而且如果你用SexNote提升了能力，你就办得到了。"

translate chinese chinese_9762339_113:
    old "But it didn't happen, did it?"
    new "但是那件事并没有发生，对吧？"

translate chinese chinese_3193820_114:
    old "So, I'll have to do the hard work of reading her mind and telling you what to say."
    new "所以，我得费劲去读懂她的心思，然后告诉你该说什么。"

translate chinese chinese_1849695_115:
    old "I see, I guess that's how it has to be."
    new "我明白了，我想只能这样了。"

translate chinese chinese_0222227_116:
    old "Oh! I know!"
    new "哦！我知道！"

translate chinese chinese_2095332_117:
    old "What about the {i}Sauron Mouth?{/i} I could use that instead of you having to use your magic, right?"
    new "那个{i}索伦之口{/i}怎么样？我可以用那个代替你使用魔法，对吧？"

translate chinese chinese_7173882_118:
    old "What? What are you talking about? Didn't you pay attention when you learned the spell?!"
    new "什么？你在说什么？学咒语的时候你不注意听吗？！"

translate chinese chinese_9763138_119:
    old "The {i}Sauron Mouth{/i} doesn't work like that."
    new "{i}索伦之口{/i} 不是那样工作的。"

translate chinese chinese_7739691_120:
    old "There are two conditions that prevent anyone from using it to just outright control another person."
    new "有两个条件可以防止任何人用这个直接控制另一个人。"

translate chinese chinese_0155203_121:
    old "First, it's not a mental power; it works by {b}influencing{/b}, not {b}forcing{/b} the will of the target."
    new "首先，这并不是精神力量；它是通过{b}影响{/b}目标，而不是{b}强迫{/b}目标的意志。"

translate chinese chinese_0548110_122:
    old "So, you can't just make someone do something they don't want to do, you can't go over personal limits."
    new "所以，你不能强迫别人做他们不愿意做的事，不能越过个人的界限。"

translate chinese chinese_1784129_123:
    old "Is not like you can just tell someone to fall in love with you or anything."
    new "不可能像命令别人爱上你这么简单。"

translate chinese chinese_8281303_124:
    old "I get it, I can't 'force' anyone with the {i}Sauron Mouth{/i}."
    new "我懂了，我不能用“{i}索伦之口{/i}”强迫任何人。"

translate chinese chinese_7381907_125:
    old "Is not just that, you can't use it on someone if you don't have a connection to them."
    new "不止这个，如果你和对方没有联系的话，你就不能对他们使用这个。"

translate chinese chinese_6031547_126:
    old "So, even if you go up to her and tell her to do something, it won't work, since you barely know each other."
    new "所以，即使你走到她面前让她做些什么，也没用，毕竟你们彼此都不太熟悉。"

translate chinese chinese_6306782_127:
    old "There are no shortcuts for this [pla], you have to do it properly."
    new "这个[pla]没有捷径，你必须老老实实地做。"

translate chinese chinese_8181173_128:
    old "I get it, I get it, so that's a no on the {i}Sauron Mouth{/i} then."
    new "我懂了我懂了，那{i}索伦之吻{/i}就算了。"

translate chinese chinese_6582485_129:
    old "It is, you see why I keep pestering you to start working on the ritual? It's a lot of work, and we don't have much time."
    new "是的，你明白为什么我老是催你开始准备仪式吗？这工作量很大，而且我们时间不多。"

translate chinese chinese_8554515_130:
    old "Yeah, yeah I get it."
    new "好吧好吧，我懂了。"

translate chinese chinese_5201805_131:
    old "Good, now that you understand it, let's go."
    new "好的，既然你明白了，我们走吧。"

translate chinese chinese_4377684_132:
    old "What?! Now?"
    new "什么?! 现在?"

translate chinese chinese_7043873_133:
    old "Yes, now! Haven't you understood how urgent this is?"
    new "是的，现在！你还不明白这有多紧急吗？"

translate chinese chinese_6759478_134:
    old "But we just arrived! I was just there a moment ago! If I go back now, it will look weird."
    new "但我们刚到！我刚才还在那里！如果我现在回去，会显得很奇怪。"

translate chinese chinese_7655525_135:
    old "Don't you worry about that, after all, I will be reading her mind and telling you what you need to know to handle the situation."
    new "别担心这个，反正我会读她的心思，告诉你处理这种情况所需的信息。"

translate chinese chinese_6480911_136:
    old "You sound very confident about this."
    new "你听起来很自信啊。"

translate chinese chinese_0261323_137:
    old "Well is not as if it's difficult..."
    new "这也不是很难嘛..."

translate chinese chinese_6010809_138:
    old "You humans are so easy to manipulate! You just have to say the right thing and you fold!"
    new "你们人类真是好操纵啊！只要说对了话，你们就招了！"

translate chinese chinese_0500931_139:
    old "We do? How do you know that?"
    new "我们有吗？你怎么知道的？"

translate chinese chinese_8804796_140:
    old "I- I mean..."
    new "我——我是说……"

translate chinese chinese_5684962_141:
    old "It's what I've observed in my time here watching you and the other humans."
    new "这是我在这里观察你和其他人类时得出的结论。"

translate chinese chinese_6695077_142:
    old "Hmm... alright."
    new "嗯……好吧。"

translate chinese chinese_5845730_143:
    old "I guess you're right."
    new "我想你是对的。"

translate chinese chinese_0636511_144:
    old "Of course I am!"
    new "那当然了！"

translate chinese chinese_7847526_145:
    old "Now, let's go seduce that human with the big mammary glands!"
    new "好了，现在去勾引那个胸部大的人类吧！"

translate chinese chinese_0695540_146:
    old "{b}*Sigh*{/b} Alright let's go."
    new "{b}*叹气*{/b} 好吧，我们走吧。"

translate chinese chinese_3665765_147:
    old "Hi Barbie."
    new "嗨，芭比。"

translate chinese chinese_4170742_148:
    old "... Again."
    new "...又来。"

translate chinese chinese_3325955_149:
    old "Uhm, no."
    new "呃，不是。"

translate chinese chinese_6695938_150:
    old "I actually came to talk with you."
    new "我其实是来找你聊天的。"

translate chinese chinese_7017936_151:
    old "Hmm, yeah..."
    new "嗯，是啊……"

translate chinese chinese_6986228_152:
    old "About what..."
    new "关于什么……"

translate chinese chinese_2448970_153:
    old "Hmm, that's... {i}a good question...{/i}"
    new "嗯，这个……{i}是个好问题……{/i}"

translate chinese chinese_6836808_154:
    old "Sigh! Look at you strugling to come up with something."
    new "sigh! 看你挣扎着想东西。"

translate chinese chinese_5138510_155:
    old "Don't worry, I have this."
    new "放心，我搞定。"

translate chinese chinese_1446197_156:
    old "[pla]! She's feeling sad about something."
    new "[pla]！她好像有什么心事难过。"

translate chinese chinese_8485849_157:
    old "Is just that you looked a little sad to me when I saw you."
    new "就是觉得刚才看你好像有点难过。"

translate chinese chinese_5873558_158:
    old "So I was wondering if there's anything that I could do for you, maybe you would like to talk about it?"
    new "所以我想知道我能不能帮你做些什么，或许你想谈谈？"

translate chinese chinese_7266694_159:
    old "That's a lie! She's feeling a great sadness!"
    new "那是谎话！她感到非常悲伤！"

translate chinese chinese_4938657_160:
    old "I don't know yet what it is, but she's definitely sad about something."
    new "我还不是很清楚是什么事，但她肯定是因为某件事很难过。"

translate chinese chinese_3611069_161:
    old "Are you sure about it?"
    new "你确定吗？"

translate chinese chinese_8644470_162:
    old "I don't want to be annoying or anything, is just that you seem like you have a lot on your mind."
    new "我不想烦你，只是你看起来心事重重的。"

translate chinese chinese_5609686_163:
    old "And I would like to help you with {i}anything{/i} if possible."
    new "而且如果可能的话，我很愿意帮你{i}任何事情{/i}。"

translate chinese chinese_8675785_164:
    old "Oh! It seems she's feeling frustrated about something!"
    new "哦！看来她有些烦躁的事情！"

translate chinese chinese_8524722_165:
    old "It's just hard to tell about what... She has a lot of emotions and thoughts going through her..."
    new "就是很难说清楚……她心里有很多情绪和想法……"

translate chinese chinese_0220935_166:
    old "Just give me a second."
    new "给我一会儿。"

translate chinese chinese_3578462_167:
    old "Really? That's a relief to hear, it's good that you're doing so well."
    new "真的吗？听到这个放心多了，你过得这么好真是太好了。"

translate chinese chinese_5609732_168:
    old "It just looked for a moment there like you had something in your mind."
    new "刚才看起来你好像在想些什么。"

translate chinese chinese_8067676_169:
    old "Kind of as if you were feeling {b}frustrated{/b} about something."
    new "感觉你好像对某些事情感到{b}沮丧{/b}。"

translate chinese chinese_1423407_170:
    old "But you aren't, right?"
    new "但是你不是这样的，对吧？"

translate chinese chinese_0399994_171:
    old "And it's related to why she's feeling frustrated."
    new "而这与她感到沮丧的原因有关。"

translate chinese chinese_5016235_172:
    old "She recently failed at something..."
    new "她最近失败了些什么……"

translate chinese chinese_6982763_173:
    old "An audition!"
    new "试镜！"

translate chinese chinese_5180202_174:
    old "What's an audition?"
    new "什么是试镜？"

translate chinese chinese_9445996_175:
    old "{i}(I see now!){/i}"
    new "{i}（我现在明白了！）{/i}"

translate chinese chinese_1239116_176:
    old "Well, I'm happy you're feeling well."
    new "嗯，很高兴你感觉不错。"

translate chinese chinese_6598577_177:
    old "Maybe I'm just projecting myself."
    new "也许我只是在自我投射。"

translate chinese chinese_3035564_178:
    old "You see, I recently failed an interview for a job I wanted."
    new "你知道吗，我最近面试一个心仪的工作失败了。"

translate chinese chinese_7781134_179:
    old "Yeah... I really wanted to get it. And I thought I was the best for it, but the hiring team chose someone else."
    new "是啊……我真的想要那份工作。我还以为我是最合适的人选，但招聘团队选择了别人。"

translate chinese chinese_3458301_180:
    old "[pla]! Now she's remembering something else!"
    new "[pla]！现在她又想起别的事情了！"

translate chinese chinese_5742450_181:
    old "{i}What is it?!{/i}"
    new "{i}怎么了？！{/i}"

translate chinese chinese_2666427_182:
    old "What is this feeling?..."
    new "这是什么感觉？..."

translate chinese chinese_8022493_183:
    old "Yeah, it was a huge {b}disappointment{/b} that I wasn't able to get it."
    new "是的，没能得到它真是个巨大的遗憾。"

translate chinese chinese_8151704_184:
    old "But I guess I have to let it go."
    new "但我想我得放手了。"

translate chinese chinese_5026240_185:
    old "I think that, sadly, sometimes our projects don't turn out the way we want them to. You know?"
    new "我觉得有时候，我们的项目可能不会像我们希望的那样成功。你知道吧？"

translate chinese chinese_3735571_186:
    old "You do?"
    new "你真的要？"

translate chinese chinese_5838968_187:
    old "Yeah, that's right."
    new "对，就是这样。"

translate chinese chinese_3817987_188:
    old "But you know what? I think I'll give it another go and I'll try to get that job."
    new "但是你知道吗？我觉得我再试一次，争取那份工作。"

translate chinese chinese_2154500_189:
    old "Well, I guess I'll just have to try again, and again until I make it."
    new "好吧，我想我只能一次次再试，直到成功为止。"

translate chinese chinese_6032063_190:
    old "After all, this job is sort of a {i}dream{/i} of mine."
    new "毕竟，这份工作算是我的梦想之一。"

translate chinese chinese_9864791_191:
    old "So I wouldn't want to give up on it for nothing."
    new "所以我不会轻易放弃的。"

translate chinese chinese_5912919_192:
    old "Do you? What do you mean?"
    new "你是什么意思？"

translate chinese chinese_6494108_193:
    old "Is there something you shouldn't give up on?"
    new "有没有什么是你不应该放弃的？"

translate chinese chinese_1400252_194:
    old "Ohh, he is not bad at this..."
    new "哦，他还真不错……"

translate chinese chinese_8759332_195:
    old "Come on, I know there's something on your mind that's been making you feel rather bad."
    new "来吧，我知道你心里有些事情让你感觉很不好。"

translate chinese chinese_2318369_196:
    old "If you need to talk about it I'll be more than happy to hear you."
    new "如果你需要倾诉，我非常乐意倾听。"

translate chinese chinese_5559673_197:
    old "After all... I already told you about my situation."
    new "毕竟……我已经跟你说过我的情况了。"

translate chinese chinese_0161538_198:
    old "Maybe I could help you with yours."
    new "也许我可以帮你解决你的问题。"

translate chinese chinese_1979195_199:
    old "What? What do you mean?"
    new "什么？你什么意思？"

translate chinese chinese_8029920_200:
    old "Listen, if this is something you want, and it's important to you, there's no way that it is ridiculous!"
    new "听着，如果这是你想要的，对你很重要，那就不可能是荒谬的！"

translate chinese chinese_4854216_201:
    old "She's feeling very bad [pla], there's something bothering her deeply."
    new "她感到非常不好[pla]，有什么事情深深地困扰着她。"

translate chinese chinese_3954386_202:
    old "What she's transmitting more strongly is a very deep feeling of insecurity."
    new "她更强烈传达出的是一种深深的不安全感。"

translate chinese chinese_8050081_203:
    old "Listen Barbie."
    new "听着，芭比。"

translate chinese chinese_0239156_204:
    old "I understand that sometimes things don't go the way we want them to."
    new "我明白有时候事情不会按我们想的那样发展。"

translate chinese chinese_0370937_205:
    old "But if it's something that's really important for you, I think it's worth it to give it a shot."
    new "但如果这件事对你真的很重要，我觉得值得一试。"

translate chinese chinese_4348458_206:
    old "Don't you think? Why don't you let me know about it?"
    new "你不觉得吗？为什么不告诉我呢？"

translate chinese chinese_2258398_207:
    old "I see, it must be very frustrating to deal with that."
    new "我明白了，那一定很让人沮丧。"

translate chinese chinese_2041494_208:
    old "But I'm sure you still can make that dream a reality..."
    new "但我相信你仍然可以让那个梦想成真..."

translate chinese chinese_7526359_209:
    old "I mean, I'm sure there are a lot of auditions being held every day, aren't there?"
    new "我的意思是，每天肯定有很多试镜吧？"

translate chinese chinese_1559273_210:
    old "You might land a role sooner rather than later, and that could propel you upward, isn't that right?"
    new "你可能会很快得到一个角色，这能帮你更上一层楼，不是吗？"

translate chinese chinese_3182092_211:
    old "Why would you say that?"
    new "你为什么这么说？"

translate chinese chinese_7003825_212:
    old "That's terrible! They have no right to treat you that way!"
    new "太糟糕了！他们没权利那样对你！"

translate chinese chinese_8560983_213:
    old "Besides, it isn't fair to say something like that."
    new "再说，那样说不公平。"

translate chinese chinese_6112220_214:
    old "I'm sorry about that, Barbie."
    new "对此我感到很抱歉，芭比。"

translate chinese chinese_5677320_215:
    old "No, they're not."
    new "不，他们不是。"

translate chinese chinese_0549128_216:
    old "You don't have to believe that just because they say it to you."
    new "他们跟你说的你不必全信。"

translate chinese chinese_7250522_217:
    old "[pla]! She's thinking about something!"
    new "[pla]！她在想些什么！"

translate chinese chinese_3606864_218:
    old "But it isn't clear what it is."
    new "但是不清楚那是什么。"

translate chinese chinese_6423070_219:
    old "Keep talking to her, maybe she'll open up more."
    new "继续和她聊，也许她会多说一些。"

translate chinese chinese_3187008_220:
    old "I mean, I'm sure you've faced some obstacles, right?"
    new "我的意思是，你肯定遇到一些障碍了吧？"

translate chinese chinese_6766069_221:
    old "Something just came up on her mind!"
    new "她突然想到什么了！"

translate chinese chinese_1762968_222:
    old "Something about..."
    new "有些关于..."

translate chinese chinese_5082211_223:
    old "{i}Number of auditions?{/i}"
    new "{i}试镜次数？{/i}"

translate chinese chinese_5131981_224:
    old "What is that?"
    new "那是什么？"

translate chinese chinese_9661135_225:
    old "({i}I think I know what she means!{/i})"
    new "({i}我觉得我知道她的意思！{/i})"

translate chinese chinese_1255867_226:
    old "Like, have you gotten enough auditions? I bet you haven't been able to attend to many, right?"
    new "比如说，你够到试镜的机会了吗？我猜你没太多机会参加吧？"

translate chinese chinese_8203905_227:
    old "You see? It isn't your fault."
    new "你看，这不怪你。"

translate chinese chinese_7011286_228:
    old "[pla]! Something else just came into her mind!"
    new "[pla]！她突然想到别的事情了！"

translate chinese chinese_1823482_229:
    old "{i}What is it?{/i}"
    new "{i}怎么了？{/i}"

translate chinese chinese_5248188_230:
    old "I'm not sure, her mind's kinda foggy."
    new "我不太确定，她的脑子有点迷糊。"

translate chinese chinese_0601809_231:
    old "Practice! She's thinking about not being able to practice!"
    new "练习！她在想不能练习的事！"

translate chinese chinese_2099035_232:
    old "I mean, you are working here full time, I bet it's very difficult to do things like acting if you don't have enough practice time."
    new "我是说，你在这里全职工作，如果没有足够的练习时间，想去做演戏这样的事情肯定很困难。"

translate chinese chinese_7341945_233:
    old "Right?"
    new "对吧？"

translate chinese chinese_3581105_234:
    old "She's not thinking about time [pla], there's something else there."
    new "她不是在想时间[pla]，还有别的什么事。"

translate chinese chinese_1477175_235:
    old "Partners?"
    new "搭档？"

translate chinese chinese_2143714_236:
    old "I don't know what she means by that."
    new "我不知道她那是什么意思。"

translate chinese chinese_5752255_237:
    old "{i}But I think I do! Thanks Brixxida!{/i}"
    new "{i}但我确实记得！谢谢Brixxida！{/i}"

translate chinese chinese_1629728_238:
    old "Yeah, I bet that since you're always working here."
    new "是啊，我敢打赌你一直都在这里工作。"

translate chinese chinese_3923467_239:
    old "It must be very difficult  to find partners to practice with."
    new "找到练习伙伴一定很困难吧。"

translate chinese chinese_0141340_240:
    old "And even if you did find them, making the space to practice must be very difficult. Right?"
    new "就算你找到了他们，找地方练习也一定很困难吧？"

translate chinese chinese_0706181_241:
    old "But you know, those things can be dealt with."
    new "但是你知道，那些事情是可以解决的。"

translate chinese chinese_0229701_242:
    old "How about I help you with them?"
    new "要不我帮你处理吧？"

translate chinese chinese_8459308_243:
    old "Uhm... W- well..."
    new "嗯……那个……"

translate chinese chinese_7518955_244:
    old "S- since you can't practice with other actors, how about I do it with you?"
    new "既然你不能和其他演员练习，要不我来陪你练吧？"

translate chinese chinese_0972374_245:
    old "I could give you pointers and help you memorize your lines."
    new "我可以给你一些指导，帮你记住台词。"

translate chinese chinese_0148316_246:
    old "M- maybe I could help you find another audition."
    new "M-也许我可以帮你找另一个试镜的机会。"

translate chinese chinese_3624008_247:
    old "I understand that you're very busy."
    new "我明白你很忙。"

translate chinese chinese_2620801_248:
    old "So, how about I'm the one that searches around, and helps you find auditions for roles that you may be good at?"
    new "这样吧，我来帮你找找试镜的机会，找一些你可能适合的角色怎么样？"

translate chinese chinese_3391192_249:
    old "Y- Your agent?"
    new "你、你的经纪人？"

translate chinese chinese_7403947_250:
    old "I- I don't think that's..."
    new "我——我觉得那不……"

translate chinese chinese_0241872_251:
    old "Yes! Say yes! That's exactly what she wants! I can see it in her mind!"
    new "是的！说yes！这正是她想要的！我能看出来！"

translate chinese chinese_4242250_252:
    old "{i}B- but, being an agent is...{/i}"
    new "{i}B-但是，当一个特工就是...{/i}"

translate chinese chinese_7892637_253:
    old "What are you so hesitant about? Just say yes or you won't be able to establish a relationship with her!"
    new "你这么犹豫什么呢？就答应吧，不然你就没法和她建立关系了！"

translate chinese chinese_1185735_254:
    old "We'll figure out how to do that later!"
    new "我们以后再想办法搞定这个！"

translate chinese chinese_7430090_255:
    old "{b}*Sigh*{/b}"
    new "{b}*叹气*{/b}"

translate chinese chinese_9663909_256:
    old "Yeah, you're right, I would be acting as your manager."
    new "嗯，你说得对，我会担任你的经理。"

translate chinese chinese_9650682_257:
    old "... I guess."
    new "……我猜吧。"

translate chinese chinese_9133017_258:
    old "Well, I just want to help you."
    new "我只是想帮你。"

translate chinese chinese_7281118_259:
    old "After all, I told you you shouldn't give up on your dreams."
    new "毕竟，我告诉过你不要放弃梦想。"

translate chinese chinese_6898623_260:
    old "So... How about I go home for now and start making some calls?"
    new "所以……要不我现在先回家开始打电话吧？"

translate chinese chinese_5590495_261:
    old "And if something comes up I'll let you know."
    new "如果有事我会告诉你。"

translate chinese chinese_0984647_262:
    old "Uhm, happy to help..."
    new "嗯，乐意帮忙……"

translate chinese chinese_4338580_263:
    old "I guess I'll see you later then, Bye."
    new "那我猜一会儿见了，拜拜。"

translate chinese chinese_9226352_264:
    old "Ok, I think that went well."
    new "好吧，我觉得这进展得不错。"

translate chinese chinese_2245483_265:
    old "What are you talking about?! Why didn't you have sex with her?!"
    new "你在说什么？！为什么你不和她发生关系？！"

translate chinese chinese_5768858_266:
    old "I told you, you humans are very easy to manipulate."
    new "我告诉过你，你们人类很容易被操纵。"

translate chinese chinese_7767426_267:
    old "I thought that by helping you talk to her you would already be having sex with her!"
    new "我以为帮你跟她说话了，你们早就上床了！"

translate chinese chinese_5660064_268:
    old "You know we don't have much time!"
    new "你知道我们时间不多了！"

translate chinese chinese_8374829_269:
    old "Well, I'm sorry, I thought you didn't have any spells that would make her have sex with me right away."
    new "好吧，对不起，我以为你没有那种能让她立刻和我上床的魔法呢。"

translate chinese chinese_0661302_270:
    old "I don't have any, that doesn't exist."
    new "我没有，那东西不存在。"

translate chinese chinese_4744582_271:
    old "Then how about you let me handle this and stop yelling at me about it?"
    new "那你就让我来处理这件事，别再对我大喊大叫了？"

translate chinese chinese_1423029_272:
    old "What you told me about her barely helped me a little to connect with her."
    new "你告诉我的那些关于她的事情对我了解她帮助不大。"

translate chinese chinese_2940162_273:
    old "Listen, is not as easy to convince humans to have sex just like that."
    new "听着，要让人类随便就发生关系可不是那么容易的。"

translate chinese chinese_7908796_274:
    old "You may be able to read minds, but you don't know how human emotions work."
    new "你也许能读心，但你不懂人类情感是怎么回事。"

translate chinese chinese_5192060_275:
    old "So let me handle this, ok?"
    new "所以让我来处理这件事，好吗？"

translate chinese chinese_5756569_276:
    old "Fine... I'll let you do what you want."
    new "好吧……我让你随便做你想做的事。"

translate chinese chinese_3068127_277:
    old "But be sure to do it quickly!"
    new "但一定要快点做！"

translate chinese chinese_2443691_278:
    old "Magic power is not eternal in case you forgot!"
    new "别忘了魔力不是永恒的！"

translate chinese chinese_8516498_279:
    old "And I already used a lot of it today, so be sure you do this properly."
    new "而且我今天已经用了很多了，所以你一定要做好。"

translate chinese chinese_2193630_280:
    old "Yeah, yeah, I'll be sure to do what you need."
    new "好吧好吧，我会确保做到你需要的。"

translate chinese chinese_3215144_281:
    old "But I'm in a tight spot with this. I know nothing about acting. I'll have to come up with something."
    new "但我现在处境尴尬，我对演戏一窍不通，得想个办法才行。"

translate chinese chinese_8626403_282:
    old "But I just don't have any ideas about how..."
    new "但是我真的没有任何想法关于怎么..."

translate chinese chinese_1452498_283:
    old "And I don't know anybody that works in acting, how am I going to get her an audition..."
    new "而且我根本不认识任何做演员工作的，我要怎么给她争取试镜的机会……"

translate chinese chinese_5407571_284:
    old "Well, that was your idea after all..."
    new "好吧，这主意本来就是你提出的..."

translate chinese chinese_6839885_285:
    old "What? You were the one who told me to accept being your agent. I didn't even..."
    new "什么？你之前还让我接受当你的代理人呢。我甚至还没..."

translate chinese chinese_7682027_286:
    old "Belle!"
    new "贝尔！"

translate chinese chinese_6398239_287:
    old "She's very into content creation and social media."
    new "她非常热衷于内容创作和社交媒体。"

translate chinese chinese_3364967_288:
    old "It may be a long shot, but maybe she knows somebody who could help us with this."
    new "这可能有点儿悬，但她可能认识能帮我们的人。"

translate chinese chinese_2435585_289:
    old "Right now is a little late, but I'll go talk to her soon to see if she could help me."
    new "现在有点晚了，但我很快会去找她看看能不能帮帮我。"

translate chinese chinese_9139032_290:
    old "Yes, honestly, I need to recharge. I spent a lot of magical power today, so I need to recover, and I won't be able to help you for a few days."
    new "是的，老实说，我需要充充电。今天消耗了很多魔力，所以需要恢复一下，接下来几天可能帮不了你了。"

translate chinese chinese_6992432_291:
    old "Hmm, alright, I can handle it with Belle for now, and what you helped with Barbie was a lot; at least, she trusts me now."
    new "嗯，好吧，我暂时可以和贝勒应付一下，而且你帮芭比做了很多；至少现在她信任我了。"

translate chinese chinese_8304845_292:
    old "Ok, then see you tomorrow, [pla]."
    new "好，那明天见，[pla]。"

translate chinese chinese_4742060_293:
    old "Sure, have a good rest."
    new "好吧，好好休息。"

translate chinese chinese_3770361_294:
    old "Hey Belle! How are you?"
    new "嘿，贝儿！最近怎么样？"

translate chinese chinese_1638244_295:
    old "Hey [pla]! Good morning! I'm fine, thank you."
    new "嘿[pla]！早上好！我很好，谢谢。"

translate chinese chinese_1166192_296:
    old "How about you? Are you doing well?"
    new "你呢？过得怎么样？"

translate chinese chinese_3763618_297:
    old "Well... Yeah, I'm doing well."
    new "嗯……是啊，我挺好的。"

translate chinese chinese_0669957_298:
    old "But you see... There's this situation.... It's a little complicated and I was wondering if you could help me with it."
    new "但是你看……有个情况……有点复杂，我想知道你能不能帮我一下。"

translate chinese chinese_0982102_299:
    old "Uhmm... Sure, whatever I can help you with, I'll be happy to do it."
    new "嗯……好啊，无论你能帮我什么，我都很乐意去做。"

translate chinese chinese_2787929_300:
    old "What  is it?"
    new "什么回事？"

translate chinese chinese_2465627_301:
    old "Well, do you know the business building in the center of town?"
    new "嗯，你知道镇中心的那栋商务楼吗？"

translate chinese chinese_5720964_302:
    old "Sure, my mom's previous office was located there. I used to go from time to time."
    new "当然，我妈妈以前的办公室就在那里，我时不时会去一下。"

translate chinese chinese_3890376_303:
    old "Oh, nice. Well, the thing is that I sometimes have to go there."
    new "哦，挺好的。不过有时候我得去那里。"

translate chinese chinese_1044187_304:
    old "You know, to bring documents for a family member from time to time, that kind of stuff."
    new "你知道的，就是时不时帮家人带些文件之类的东西。"

translate chinese chinese_6174368_305:
    old "Well the other day I came there to bring some documents, and I got to talking with the receptionist of the building."
    new "前几天我去那边送一些文件，然后和大楼的接待员聊了起来。"

translate chinese chinese_8252384_306:
    old "Barbie?"
    new "芭比？"

translate chinese chinese_1333212_307:
    old "Yeah, do you know her?"
    new "是啊，你认识她吗？"

translate chinese chinese_0734420_308:
    old "I do, from when I used to come to my mom's office."
    new "我见过，以前来我妈妈办公室的时候看过的。"

translate chinese chinese_3086421_309:
    old "We never really talked much, but I remember she's a very nice girl."
    new "我们虽然没说过多少话，但我记得她是个很好的女孩。"

translate chinese chinese_3503944_310:
    old "Oh yeah, sure, she's very nice."
    new "哦 yeah，当然，她人很好。"

translate chinese chinese_0205959_311:
    old "But you see, when I got there the other day, I saw that she was very sad."
    new "但是你看，那天我去的时候，发现她很伤心。"

translate chinese chinese_1248467_312:
    old "Why? Is she okay?"
    new "为什么？她没事吧？"

translate chinese chinese_6699414_313:
    old "Well, nothing bad has happened, but you see..."
    new "嗯，没什么坏事发生，但是你看..."

translate chinese chinese_3967587_314:
    old "I asked her what was wrong."
    new "我问她怎么了。"

translate chinese chinese_5375687_315:
    old "And after we got to talking, she told me that she's been feeling very frustrated as of late."
    new "后来我们聊了起来，她告诉我最近感到非常沮丧。"

translate chinese chinese_8113789_316:
    old "Because she feels like her life is just coming to a halt, and she doesn't know what to do about it."
    new "因为她觉得自己的生活停滞不前，而且不知道该怎么办。"

translate chinese chinese_6679944_317:
    old "Why? What's happening?"
    new "为什么？发生什么事了？"

translate chinese chinese_2980731_318:
    old "Well, as she told me, she originally came to town looking for opportunities to be an actress."
    new "嗯，就像她告诉我的，她本来是来镇上寻找当演员的机会的。"

translate chinese chinese_6742802_319:
    old "But ever since she arrived, she's been attending one audition after another."
    new "但是自从她来了之后，一直在参加一个又一个的试镜。"

translate chinese chinese_9779233_320:
    old "Without ever being selected to any roles."
    new "从未被选中任何角色。"

translate chinese chinese_2572892_321:
    old "I understand [pla], that's a very sad thing."
    new "我明白[pla]，那是一件很悲伤的事情。"

translate chinese chinese_8497395_322:
    old "The thing you wanted me to help you with is related to that?"
    new "你想让我帮忙的事情和那个有关？"

translate chinese chinese_3528541_323:
    old "It is, at first I only thought that she was just a little frustrated about not being able to book any roles."
    new "是的，一开始我只是觉得她只是因为没能接任何角色而有点沮丧。"

translate chinese chinese_4141043_324:
    old "But while we talked I came to realize how important being an actress is to her."
    new "但是聊天的过程中，我意识到当演员对她来说有多重要。"

translate chinese chinese_5173528_325:
    old "This is what she wants to do the most in life."
    new "这是她这辈子最想做的事情。"

translate chinese chinese_3939416_326:
    old "To the point where she's feeling depressed for being unable to get any opportunities to act."
    new "以至于她因为没有机会表现而感到抑郁。"

translate chinese chinese_1283440_327:
    old "I get it [pla], I understand that feeling."
    new "我明白[pla]，我能理解那种感觉。"

translate chinese chinese_3532629_328:
    old "The frustration of not being able to live your dreams."
    new "无法实现梦想的挫败感。"

translate chinese chinese_1333791_329:
    old "It's overwhelming..."
    new "太震撼了……"

translate chinese chinese_8939542_330:
    old "Yeah it is, but it's not just that."
    new "是的，但不止是因为那个。"

translate chinese chinese_5656224_331:
    old "She's also feeling bad about not being able to even try."
    new "她也觉得自己连试一下都不行，感觉很糟糕。"

translate chinese chinese_4116596_332:
    old "Since she's always so busy working, she can't look for auditions."
    new "因为她总是忙于工作，所以没时间去找试镜的机会。"

translate chinese chinese_4774697_333:
    old "Or attend acting classes whenever she gets a role."
    new "或者每次拿到角色时去上表演课。"

translate chinese chinese_3598822_334:
    old "So, after hearing of all the things she's been going through, I decided to help her."
    new "所以，在听说了她经历的一切后，我决定帮助她。"

translate chinese chinese_1668660_335:
    old "I think that's just the best thing that I could do right now, you know?"
    new "我觉得我现在做的就是最好的选择，你知道吗？"

translate chinese chinese_4092076_336:
    old "Yeah, I understand [pla], and I think that's just a great thing for you to do."
    new "是的，我理解[pla]，我觉得你这么做很好。"

translate chinese chinese_6990589_337:
    old "Thanks Belle!"
    new "谢谢你，贝尔！"

translate chinese chinese_8325684_338:
    old "And that's more or less what I need your help with."
    new "这大概就是我需要你帮忙的地方。"

translate chinese chinese_8709260_339:
    old "I ended up promising her that I would help her with the whole process of getting auditions."
    new "最后我答应帮她搞定整个试镜的过程。"

translate chinese chinese_6043319_340:
    old "But truth be told, I don't know how to do that."
    new "但说实话，我不知道该怎么去做。"

translate chinese chinese_5588968_341:
    old "I haven't ever even seen any acting agencies, or anything like that. So I don't know where to start."
    new "我甚至没见过什么演艺公司之类的，所以根本不知道从哪里开始。"

translate chinese chinese_3831545_342:
    old "That's why I thought you might be able to help me with it."
    new "那就是为什么我觉得你可能能帮我解决这个问题。"

translate chinese chinese_1621286_343:
    old "I know you're very active on social media and you know a lot of people in the industry."
    new "我知道你在社交媒体上很活跃，而且认识很多圈内人。"

translate chinese chinese_6527317_344:
    old "And you know, you also work a lot in content creation and that kind of stuff."
    new "而且你知道的，你也在内容创作那方面做了很多工作。"

translate chinese chinese_9826738_345:
    old "So, I was thinking that maybe you knew of a way for me to get an audition for her."
    new "所以，我在想你可能知道一些让我能为她试镜的方法。"

translate chinese chinese_3318055_346:
    old "Or maybe you knew of a studio of something like that..."
    new "或者你认识哪家工作室之类的..."

translate chinese chinese_4063033_347:
    old "Hmm, I see what you mean..."
    new "嗯，我明白你的意思了……"

translate chinese chinese_2502009_348:
    old "You know, there may be someone that could..."
    new "你知道吗，可能有人能..."

translate chinese chinese_4537110_349:
    old "[pla], Belle, the class bell already rang."
    new "[pla]，贝尔，上课铃已经响了。"

translate chinese chinese_8191356_350:
    old "Hurry up and get to the classroom or you'll be late."
    new "快点去教室，要迟到了。"

translate chinese chinese_8219554_351:
    old "So, while we were in class I got to thinking, and it came to my mind that I might know of a place where she could go."
    new "所以，我们在上课的时候，我一直在想，突然想到我可能知道一个她可以去的地方。"

translate chinese chinese_5006305_352:
    old "You did? Great!"
    new "你做到了？太棒了！"

translate chinese chinese_0002266_353:
    old "Yeah, just let me do a couple of calls and I'll let you know."
    new "好的，让我打几个电话然后告诉你。"

translate chinese chinese_1361966_354:
    old "In fact, I'll call right now and I'll let you know right away."
    new "事实上，我现在就打电话，然后立刻告诉你。"

translate chinese chinese_1461970_355:
    old "Alright, I talked with a couple of my contacts."
    new "好吧，我和几个我的线人谈过了。"

translate chinese chinese_8233964_356:
    old "Great news! They said they would agree to audition her for an upcoming role."
    new "好消息！他们说会同意让她试镜一个即将上映的角色。"

translate chinese chinese_3083272_357:
    old "I'll give you their number so you can call and see when she could go there."
    new "我把他们的号码给你，你可以打电话问问她什么时候能过去。"

translate chinese chinese_6589305_358:
    old "I already gave them your info, so they'll know you're calling on my recommendation."
    new "我已经把你的信息给他们了，他们会知道你是通过我推荐联系他们的。"

translate chinese chinese_5222372_359:
    old "Great! Thanks a lot, Belle!"
    new "太好了！谢谢你，贝尔！"

translate chinese chinese_8293672_360:
    old "It's fine, I'm happy to be able to help."
    new "没关系，我很高兴能帮忙。"

translate chinese chinese_2652069_361:
    old "From what you told me about Barbie's story, she needs this opportunity."
    new "从你告诉我的芭比的故事来看，她需要这个机会。"

translate chinese chinese_2456481_362:
    old "I know that if it was me I would love to get any help that I could get."
    new "我知道如果是我的话，我会很乐意接受任何帮助的。"

translate chinese chinese_2011273_363:
    old "So I'm very happy to help."
    new "所以我非常乐意帮忙。"

translate chinese chinese_1393538_364:
    old "That's great Belle, and a huge help!"
    new "太好了，贝儿，帮了大忙了！"

translate chinese chinese_4427200_365:
    old "Thank you so much!"
    new "太感谢了！"

translate chinese chinese_4888721_366:
    old "You're welcome, I hope things will go well."
    new "不客气，希望一切顺利。"

translate chinese chinese_9923871_367:
    old "Let me know how this turns out."
    new "告诉我结果怎么样。"

translate chinese chinese_1701352_368:
    old "I'll see you later then, thanks again."
    new "那回头见，再次感谢。"

translate chinese chinese_2771556_369:
    old "Asking Belle about it turned out Better than expected."
    new "问贝勒结果比预期的好。"

translate chinese chinese_5662040_370:
    old "Barbie will really like this news."
    new "芭比会很喜欢这个消息的。"

translate chinese chinese_9061567_371:
    old "Now is too late for me to go talk to her. But I'll go there soon and let her now."
    new "现在再去跟她说话已经太晚了。但我很快会去那让她知道。"

translate chinese chinese_9556874_372:
    old "Hey Barbie, how are you doing?"
    new "嘿，芭比，你怎么样？"

translate chinese chinese_8014200_373:
    old "Well, let me tell you that that may be about to change. Because I got you an audition."
    new "好吧，让我告诉你，这可能很快就要改变了。因为我给你搞到了一个试镜的机会。"

translate chinese chinese_0724839_374:
    old "Yeah, it's a role in an upcoming movie."
    new "嗯，这是即将上映的电影里的一个角色。"

translate chinese chinese_6645791_375:
    old "It’s being produced by an indie studio from outside of town."
    new "这是由镇外的一家独立工作室制作的。"

translate chinese chinese_9688801_376:
    old "They’re holding some castings here for it."
    new "他们在这里举行一些试镜。"

translate chinese chinese_0666627_377:
    old "I already booked you a spot in their next auditions block."
    new "我已经帮你预约了他们下一轮试镜的名额。"

translate chinese chinese_7310089_378:
    old "So you'll have a chance of getting a role."
    new "所以你有机会得到一个角色。"

translate chinese chinese_7876457_379:
    old "You're welcome, I'm happy to help you. I'm sure you'll do a great job with the role."
    new "不客气，我很乐意帮你。我相信你会把这个角色演得很棒。"

translate chinese chinese_8091816_380:
    old "You'll be auditioning for the role of a rich girl who's in love with a man that her family doesn't approve of."
    new "你将试镜扮演一个爱上家庭不认可的男人的富家女。"

translate chinese chinese_6914715_381:
    old "It is, you'll be auditioning for the lead role!"
    new "是的，你将要试镜主演角色！"

translate chinese chinese_1834932_382:
    old "That's great, isn't it?"
    new "那很棒，不是吗？"

translate chinese chinese_2493860_383:
    old "Is... Is there a problem?"
    new "是……有问题吗？"

translate chinese chinese_7753465_384:
    old "Why not? Is there something wrong?"
    new "为什么不行？有什么问题吗？"

translate chinese chinese_0231371_385:
    old "Why do you think that?"
    new "你为什么这么想？"

translate chinese chinese_8530300_386:
    old "Hey [pla]."
    new "嘿[pla]。"

translate chinese chinese_4129925_387:
    old "{i}What are you doing here?{/i}"
    new "{i}你在这里干什么？{/i}"

translate chinese chinese_3813917_388:
    old "I followed you in case you needed my help. Just because there's no certainty that you will know how to speak to her."
    new "我跟着你以防你需要帮助。毕竟你不一定知道该怎么跟她说话。"

translate chinese chinese_7385110_389:
    old "So, do you want my help?"
    new "所以，你想要我的帮助吗？"

translate chinese chinese_2345234_390:
    old "{i}I think I can convince her on my own.{/i}"
    new "{i}我觉得我可以自己说服她。{/i}"

translate chinese chinese_9592976_391:
    old "I mean, I'm sure you're more than capable of taking the role, you know?"
    new "我的意思是，我相信你完全有能力胜任这个角色，你知道的？"

translate chinese chinese_6654947_392:
    old "I know you're very talented."
    new "我知道你很才华横溢。"

translate chinese chinese_9166581_393:
    old "And sure, there's going to be some competition."
    new "当然，肯定会有些竞争。"

translate chinese chinese_0474351_394:
    old "But you're just as good as any of them, you're more than capable of holding your own in the audion, no doubt."
    new "但你和他们一样棒，你在试音中绝对能独当一面。"

translate chinese chinese_9595006_395:
    old "B- but you were so excited just a minute ago!"
    new "你刚才还那么兴奋呢！"

translate chinese chinese_2577133_396:
    old "Listen, I understand that you're feeling insecure because of what's happened before."
    new "听着，我明白因为你之前经历的事情感到不安全感。"

translate chinese chinese_0850620_397:
    old "But you'll never know if you don't try it."
    new "但如果你不试试，就永远也不知道了。"

translate chinese chinese_7774457_398:
    old "So... You don't seem to be {i}'handling'{/i} things too well."
    new "所以……你好像不太能“应付”这些事情。"

translate chinese chinese_0189337_399:
    old "Will you let me help you now?"
    new "你现在让我帮忙好吗？"

translate chinese chinese_0621865_400:
    old "I also need you to have sex with this human female, so this is also in my best interest."
    new "我也需要你和这个人类女性发生关系，所以这对我来说也有好处。"

translate chinese chinese_7731647_401:
    old "{i}Alright, alright! Get in her head and tell me what's really troubling her.{/i}"
    new "好的好的！进入她的内心，告诉我究竟什么困扰着她。"

translate chinese chinese_9482374_402:
    old "Okay!"
    new "好啦！"

translate chinese chinese_8737179_403:
    old "I understand that because of what's happened before you feel uncomfortable with the idea of auditioning."
    new "我明白因为之前发生的事情，你对试镜感到不舒服。"

translate chinese chinese_6609907_404:
    old "But you shouldn't let that stop you."
    new "但你不应该因此停下来。"

translate chinese chinese_8318965_405:
    old "Hold on, I'm starting to get something."
    new "等一下，我开始有感觉了。"

translate chinese chinese_8317057_406:
    old "She feels like she's a failure."
    new "她觉得自己是个失败者。"

translate chinese chinese_4748284_407:
    old "{i}Uhhh... {/i}"
    new "{i}嗯... {/i}"

translate chinese chinese_3142897_408:
    old "No, no, she feels like her life's a failure."
    new "不，不，她觉得自己的一生是个失败。"

translate chinese chinese_6484669_409:
    old "{i}Her life is a failure?{/i}"
    new "她的生活是失败的？"

translate chinese chinese_6649563_410:
    old "I- I mean, I understand that you may feel like a failure."
    new "我——我是说，我明白你可能觉得自己失败了。"

translate chinese chinese_8358806_411:
    old "But the reason I'm helping you is because I believe in you and your talent."
    new "但我帮你是因为我相信你和你的才华。"

translate chinese chinese_5131086_412:
    old "She's afraid of being rejected [pla]!"
    new "她害怕被拒绝[pla]！"

translate chinese chinese_5603254_413:
    old "What strong emotions, wow!"
    new "情绪这么强烈， wow!"

translate chinese chinese_8076982_414:
    old "You know, I understand that you may feel a fear of being rejected."
    new "你知道吗，我明白你可能害怕被拒绝。"

translate chinese chinese_5389645_415:
    old "But I do believe you're more than capable of getting the role."
    new "但是我相信你完全有能力得到这个角色。"

translate chinese chinese_1309624_416:
    old "You have been trying for so long to finally get an acting career."
    new "你努力了这么久终于有了一个演员的职业机会。"

translate chinese chinese_2963595_417:
    old "And you haven't ever given up no matter what."
    new "而且无论发生什么，你都从未放弃过。"

translate chinese chinese_9568017_418:
    old "I just know that you have an amazing amount of passion for this."
    new "我就是知道你对这个充满热情。"

translate chinese chinese_6227990_419:
    old "With how hard you've worked, I don't think anyone deserves the role any more than you do."
    new "以你的努力，我觉得没有人比你更配这个角色了。"

translate chinese chinese_6904200_420:
    old "Of course I do, I truly believe in what you can do."
    new "当然了，我真的很相信你的能力。"

translate chinese chinese_3825884_421:
    old "What do you say?"
    new "你怎么说？"

translate chinese chinese_8020507_422:
    old "Will you give it a try?"
    new "你要不要试试看？"

translate chinese chinese_7721932_423:
    old "Of course you should. I know, you'll crush it."
    new "当然你应该去。我知道，你一定能搞定的。"

translate chinese chinese_3398356_424:
    old "You're welcome Barbie, I know you'll do great."
    new "不客气芭比，我知道你会做得很好的。"

translate chinese chinese_3619663_425:
    old "Anyway, I have to go home for now."
    new "总之，我现在得回家了。"

translate chinese chinese_5875412_426:
    old "But I'll send you the info about the address and date for the audition."
    new "但我會把試鏡的地點和日期信息發給你。"

translate chinese chinese_1206707_427:
    old "I'll see you later then, bye."
    new "那回头见，拜拜。"

translate chinese chinese_0056892_428:
    old "Alright, that went well."
    new "好吧，这进展得不错。"

translate chinese chinese_7638794_429:
    old "Thanks for the help Brixxida."
    new "谢谢你帮忙，Brixxida。"

translate chinese chinese_3100018_430:
    old "Yeah yeah, but why aren't you having sex already with her?"
    new "好了好了，但你为什么还不和她上床呢？"

translate chinese chinese_4494575_431:
    old "I told you how she was feeling so that you could have sex with her right away!"
    new "我告诉你她的感受，不就是为了你能马上和她发生关系吗！"

translate chinese chinese_0328034_432:
    old "Two times talking and you still haven't achieved anything."
    new "说了两次了，你还是没什么进展。"

translate chinese chinese_6368212_433:
    old "What's taking you so long?"
    new "你磨磨蹭蹭什么呢？"

translate chinese chinese_9773815_434:
    old "I thought I told you."
    new "我以为我告诉过你了。"

translate chinese chinese_8831624_435:
    old "Is not so simple to get somebody into bed."
    new "要让人上床可不是那么简单的事。"

translate chinese chinese_1306216_436:
    old "You can't just say something nice to someone once or twice, and suddenly they'll want to fuck you out of nowhere."
    new "你不能就因为跟人家说过一两次好话，就突然期望人家会想跟你上床。"

translate chinese chinese_4896031_437:
    old "Ok, then how long will it take?"
    new "好的，那需要多长时间？"

translate chinese chinese_4231031_438:
    old "You're not the only one who's making an effort, you know?"
    new "你不是唯一一个在努力的人，你知道吗？"

translate chinese chinese_2308993_439:
    old "I'm using a lot of magical power every time I read her mind, this isn't easy to do."
    new "每次读她的想法都要消耗很多魔力，这可不是件容易的事。"

translate chinese chinese_9883754_440:
    old "And unlike in my world, magical power isn't infinite here."
    new "而且不像在我的世界里，这里的魔法力量不是无限的。"

translate chinese chinese_8093393_441:
    old "I know, and I understand that this must be hard for you."
    new "我知道，我也明白这对你来说很困难。"

translate chinese chinese_9971141_442:
    old "But I can't just ask her to have sex with me just because. That's not how it works."
    new "但我不能随便就要求她和我发生关系。事情没有那么简单。"

translate chinese chinese_3330011_443:
    old "You humans are so complicated. When shinigamis have sex is just an energy exchange. Nothing else."
    new "你们人类真复杂。死神发生关系就是能量交换，没什么别的。"

translate chinese chinese_5967896_444:
    old "Listen, I'm doing my best to do what we need. So just trust me on this and let me handle it. Ok?"
    new "听着，我正在尽全力处理这件事。所以就相信我，让我来搞定它，好吗？"

translate chinese chinese_1416517_445:
    old "Okay,  I'll trust that you know what you're doing."
    new "好吧，我相信你知道自己在做什么。"

translate chinese chinese_7724612_446:
    old "But don't take too long, I remind you that this is just the beginning of this process."
    new "但别花太长时间，我要提醒你，这仅仅是过程的开始。"

translate chinese chinese_8740379_447:
    old "Don't worry, I haven't forgotten about that."
    new "放心，那个我没忘。"

translate chinese chinese_6647296_448:
    old "I'm ok, I came to check up on you."
    new "我挺好的，我是来看看你的。"

translate chinese chinese_6715069_449:
    old "I wanted to know how the audition went."
    new "我想知道试镜怎么样了。"

translate chinese chinese_2291837_450:
    old "Did it go well? Did you feel alright?"
    new "进展顺利吗？你觉得怎么样？"

translate chinese chinese_3523963_451:
    old "Alright, that sounds great. When's the next audition?"
    new "好的，听起来不错。下一次试镜是什么时候？"

translate chinese chinese_7584805_452:
    old "I see, and how long is it?"
    new "我明白了，那有多长？"

translate chinese chinese_3229073_453:
    old "Ohh wow, t- that's a lot."
    new "哦哦，那、那个好多啊。"

translate chinese chinese_4969763_454:
    old "Oh, come on, why not?"
    new "哦，别这样，为什么不行？"

translate chinese chinese_3223475_455:
    old "{i}Could you please give me a hand...{/i}"
    new "{i}你能帮我一下……{/i}"

translate chinese chinese_5210490_456:
    old "Ok, I'm getting some strong emotional waves from her!"
    new "好的，我感觉到她情绪很强烈！"

translate chinese chinese_8169043_457:
    old "She's feeling, very, very insecure."
    new "她感到非常不安全。"

translate chinese chinese_5780899_458:
    old "I hadn't seen her like that before."
    new "我之前没见过她那样。"

translate chinese chinese_4932633_459:
    old "She's closing her emotions! Just say something to reassure her."
    new "她在关闭自己的情感！说点什么让她放心吧。"

translate chinese chinese_9035463_460:
    old "I- I understand what you're saying Barbie... I really do."
    new "我……我明白你的意思，芭比……我真的明白。"

translate chinese chinese_6932193_461:
    old "But you know... Uhh, I don't think that this is as bad a situation as you think."
    new "但是你知道……嗯，我觉得这情况没有你想的那么糟。"

translate chinese chinese_7235201_462:
    old "Yeah, why not?"
    new "是啊，为什么不行？"

translate chinese chinese_4168412_463:
    old "Uhh... Well, that's certainly a lot of pages, but I don't think they are expecting you to memorize all of it."
    new "呃……嗯，页数确实很多，但我不认为他们期望你能全部背下来。"

translate chinese chinese_6876628_464:
    old "I think it's more about how you say and act with the lines."
    new "我觉得这更多是看你怎么说怎么做的问题。"

translate chinese chinese_0028998_465:
    old "Maybe all you have to do is read it ahead of time, and practice it."
    new "maybe 你只需要提前读一下，然后练习一下就行了。"

translate chinese chinese_6366238_466:
    old "Ok, how about you do it with me?"
    new "好吧，要不你跟我一起做？"

translate chinese chinese_4359311_467:
    old "Sure, I mean, I don't know anything about acting, but I could still read the dialogues with you."
    new "行吧，我意思是，我对演戏一窍不通，但我还是可以和你一起读对话的。"

translate chinese chinese_6758467_468:
    old "And I could give you my opinion about how I think you are doing it."
    new "我可以给你我的意见，关于我觉得你这样做的看法。"

translate chinese chinese_6441995_469:
    old "Well, we don't lose anything by trying, and this way, you could be more prepared for your role."
    new "好吧，试试也不亏，这样你可以更好地为你的角色做准备。"

translate chinese chinese_6484930_470:
    old "How about you come to my house after you leave work."
    new "要不你下班后来我家吧。"

translate chinese chinese_3371365_471:
    old "And we can start practicing."
    new "我们可以开始练习了。"

translate chinese chinese_7901698_472:
    old "So, what do you think if you let me take a look at the script they gave you while I wait for you to finish your shift?"
    new "所以，你觉得在我等你下班的时候，让我看看他们给你的剧本怎么样？"

translate chinese chinese_5375033_473:
    old "Okay, I'll go through them while you finish. I'll be in the hallway."
    new "好的，你先做完，我在这走廊里翻翻这些东西。"

translate chinese chinese_7438816_474:
    old "Great, let's go."
    new "好，我们走。"

translate chinese chinese_1922525_475:
    old "So, I checked out the script, and honestly, it's pretty interesting."
    new "所以，我看了下剧本，说实话，还挺有趣的。"

translate chinese chinese_8051154_476:
    old "Yeah, and I really do think you're not supposed to memorize this. It's rather about you reading it."
    new "是的，我真的觉得你不应该背这些东西。主要是让你读的。"

translate chinese chinese_0495316_477:
    old "Otherwise I don't think anybody could learn this entire thing by memory."
    new "否则我不认为有人能完全背下来这些东西。"

translate chinese chinese_8604392_478:
    old "Besides, if there are several participants the audition would just take too long."
    new "再说，如果有好几个参与者的话，试镜会花费太长时间的。"

translate chinese chinese_1084461_479:
    old "What I think is best is for us to focus on how you can portray the character."
    new "我觉得最好的做法是专注于你怎么塑造这个角色。"

translate chinese chinese_4232069_480:
    old "I mean, act as you read, so you can be better prepared tomorrow having practiced your role."
    new "我的意思是，边读边练习，这样明天就能更熟练地扮演你的角色了。"

translate chinese chinese_8577814_481:
    old "I know a scene with a lot of emotions."
    new "我知道一个充满情感的场景。"

translate chinese chinese_3665404_482:
    old "Here, take the full script, I got a few copies..."
    new "这儿，拿完整的剧本吧，我有几份副本……"

translate chinese chinese_5665852_483:
    old "Is in the second act, page 57."
    new "在第二幕，第57页。"

translate chinese chinese_4218118_484:
    old "The two protagonists are fighting, but the scene ends in their reconciliation, I think it would be appropriate."
    new "两个主角在打架，但场景以他们的和解结束，我觉得这样挺合适的。"

translate chinese chinese_2695745_485:
    old "Alright, let's start with the reading, and I'll give you pointers along the way."
    new "好吧，我们从阅读开始，我会沿途给你指正的。"

translate chinese chinese_9394966_486:
    old "'Don't leave! Don't turn your back on me now!'"
    new "‘不要走！现在不要背弃我！’"

translate chinese chinese_0883705_487:
    old "'If you do, what little remains of this heart will disappear!'"
    new "“如果你这么做了，这颗心中剩下的那点东西也会消失的！”"

translate chinese chinese_3093783_488:
    old "Hmm... Barbie?"
    new "嗯……芭比？"

translate chinese chinese_0789026_489:
    old "I think you're doing it... Well."
    new "我觉得你做得... 还不错。"

translate chinese chinese_2904269_490:
    old "But, the volume of what you're saying is a little high."
    new "但是，你说话的声音有点大。"

translate chinese chinese_5721990_491:
    old "Also, you're... Yelling some words, and saying others a little low."
    new "而且，你在……有些话大声喊出来，有些则说得比较低。"

translate chinese chinese_0137971_492:
    old "Hmm, it's okay to add emotion to the lines, but try to keep the volume average, or it might sound a bit odd."
    new "嗯，给台词加点情感是可以的，但尽量保持语气平和，否则可能会显得有点奇怪。"

translate chinese chinese_5007836_493:
    old "Great, let's try it again."
    new "好，咱们再试一次。"

translate chinese chinese_8099698_494:
    old "You know what? Maybe it isn't necessary to start over every time."
    new "你知道吗？也许每次都不必从头开始。"

translate chinese chinese_1838224_495:
    old "How about you just keep reading where you left it?"
    new "你还是接着上次看的地方继续读吧？"

translate chinese chinese_4246855_496:
    old "{i}(Why is she making that accent in those words?){/i}"
    new "{i}（她为什么要在那些词上用那种腔调？）{/i}"

translate chinese chinese_3503457_497:
    old "Oh, right, right."
    new "哦，对对对。"

translate chinese chinese_6231237_498:
    old "'Why? You ask?'"
    new "“为什么？你问？”"

translate chinese chinese_7637334_499:
    old "'Because it isn't little!'"
    new "“因为它不小！”"

translate chinese chinese_3323547_500:
    old "'What I offer is my heart!'"
    new "‘我给你的，是我的心！’"

translate chinese chinese_7043017_501:
    old "'Naked, with no obstructions, just for you!'"
    new "“裸着身子，没有任何遮挡，全都是为了你！”"

translate chinese chinese_5409915_502:
    old "{i}(There she goes again making that weird accent in certain words.){/i}"
    new "{i}（她又开始在某些词上用那种奇怪的腔调了。){/i}"

translate chinese chinese_2449272_503:
    old "I see..."
    new "我明白了……"

translate chinese chinese_5073454_504:
    old "But maybe that's not necessary, you know?"
    new "但也许那没必要，你知道？"

translate chinese chinese_3268494_505:
    old "I think it can be a little distracting."
    new "我觉得这可能会有点分散注意力。"

translate chinese chinese_0163953_506:
    old "And people might not understand what you're trying to do."
    new "而且人们可能不会理解你的想法。"

translate chinese chinese_1694395_507:
    old "Hey, that's why we're practicing."
    new "嘿，这就是我们要练习的原因。"

translate chinese chinese_4651814_508:
    old "I don't think you need to feel bad about it."
    new "我觉得你不用为此感到难过。"

translate chinese chinese_7468846_509:
    old "Come on, don't let yourself feel down, let's continue."
    new "来吧，别让自己沮丧了，我们继续吧。"

translate chinese chinese_5566560_510:
    old "'How can you say that I let you down?'"
    new "‘你怎么能说我让你失望了呢？’"

translate chinese chinese_0108052_511:
    old "'When I gave everything to you?!'"
    new "“我什么时候把一切都给你了？”"

translate chinese chinese_7238700_512:
    old "'I left myself change for your sake!'"
    new "“我为了你留了些零钱！”"

translate chinese chinese_6491805_513:
    old "'For our sake!'"
    new "‘为了我们！’"

translate chinese chinese_1589047_514:
    old "'All I've ever wanted in this relationship is to give you happiness!'"
    new "“我在这段关系中唯一想要的就是给你幸福！”"

translate chinese chinese_8555363_515:
    old "'I didn't leave!'"
    new "‘我没走！’"

translate chinese chinese_4971623_516:
    old "'I couldn't be here for you!'"
    new "‘我不能在这里陪你！’"

translate chinese chinese_6420274_517:
    old "'There's no way I wouldn't be here if I could avoid it!'"
    new "‘我怎么可能能避就避呢！’"

translate chinese chinese_8342397_518:
    old "'You have to believe.'"
    new "‘你得相信。’"

translate chinese chinese_6610444_519:
    old "'You're my life!'"
    new "‘你就是我的生命！’"

translate chinese chinese_9260590_520:
    old "'You're my heart!'"
    new "‘你就是我的心肝！’"

translate chinese chinese_1831953_521:
    old "Uhh... So, there's something else I'd like to tell you."
    new "呃……所以，还有件事我想告诉你。"

translate chinese chinese_1890021_522:
    old "Well, is just that..."
    new "嗯，就是说..."

translate chinese chinese_8000702_523:
    old "You keep changing your face while reading the lines."
    new "你读台词的时候老是变表情。"

translate chinese chinese_1978569_524:
    old "I- uh... No, I wouldn't say is wrong."
    new "我——呃……不，我不说是错的。"

translate chinese chinese_3350257_525:
    old "Is just that it's a little distracting from the dialogue, that's all."
    new "就是有点分散对话的注意力而已。"

translate chinese chinese_4045398_526:
    old "I wouldn't say is a bad thing though."
    new "不过我也不会说这是坏事。"

translate chinese chinese_5604752_527:
    old "W- what are you talking about?"
    new "你、你在说什么？"

translate chinese chinese_3913271_528:
    old "W- why?"
    new "为、为什么？"

translate chinese chinese_1117992_529:
    old "B- but that's just me tryting to help you!"
    new "我、我只是想帮你而已！"

translate chinese chinese_8348097_530:
    old "But I don't think you're bad."
    new "但是我觉得你并不差。"

translate chinese chinese_5075482_531:
    old "You just need a little practice."
    new "你只需要多练习一下。"

translate chinese chinese_0646042_532:
    old "You know, to learn the character."
    new "你知道的，为了了解这个角色。"

translate chinese chinese_5384930_533:
    old "W- what? Are you serious?"
    new "什、什么？你是认真的？"

translate chinese chinese_5003028_534:
    old "Come on, you can't just give up like this."
    new "别这样，你不能就这么放弃。"

translate chinese chinese_3206780_535:
    old "You have to try it."
    new "你得试试。"

translate chinese chinese_2041889_536:
    old "It isn't impossible, you don't have to know the script."
    new "这并不是不可能，你不需要知道剧本。"

translate chinese chinese_6151508_537:
    old "Or even read the whole thing."
    new "或者干脆全文都读一下。"

translate chinese chinese_6886817_538:
    old "Let's just keep practicing this part."
    new "我们就继续练习这部分吧。"

translate chinese chinese_5011182_539:
    old "And I'm sure you'll be able to use what we practice here today for the audition tomorrow."
    new "我相信你今天在这里练习的东西明天试镜时一定能用得上。"

translate chinese chinese_4774840_540:
    old "[pla], is just the same as earlier, her emotions are all over the place!"
    new "[pla]还是一样，情绪波动好大！"

translate chinese chinese_1898180_541:
    old "I'm not even reading her mind right now and I can tell."
    new "我现在甚至都没读她的想法，都能看出来。"

translate chinese chinese_3256846_542:
    old "{i}Well, can't you read her mind right now and tell me anything useful?{/i}"
    new "{i}那，你现在不能读她的想法然后告诉我一些有用的东西吗？{/i}"

translate chinese chinese_1084472_543:
    old "Let me see."
    new "让我看看。"

translate chinese chinese_2330805_544:
    old "Hmm, I don't know."
    new "嗯，我不知道。"

translate chinese chinese_2774694_545:
    old "All I can tell is that she's incredibly stressed."
    new "我只能感觉到她压力山大。"

translate chinese chinese_8343876_546:
    old "It's amazing [pla], she's under so much tension!"
    new "真是的，[pla]，她紧张得要命！"

translate chinese chinese_6677258_547:
    old "With the way she's feeling now she won't listen to anything you have to say to her."
    new "以她现在的心情，根本不会听你说什么。"

translate chinese chinese_7388618_548:
    old "{i}Yeah, I can see that...{i}"
    new "{i}嗯，我看得出来……{i}"

translate chinese chinese_3398663_549:
    old "{i}What about you? Don't you have something that could be useful?{/i}"
    new "那你呢？难道你没有什么有用的东西吗？"

translate chinese chinese_8930342_550:
    old "{i}Like a spell to calm her nerves or something?{/i}"
    new "{i}像是一种让她放松的咒语之类的？{/i}"

translate chinese chinese_1753150_551:
    old "There's nothing like that."
    new "没什么那样的事。"

translate chinese chinese_8898923_552:
    old "{i}Really?{/i}"
    new "{i}真的吗？{/i}"

translate chinese chinese_0229475_553:
    old "Yeah, all I could do with a spell is try to influence her will, but there's nothing to change emotions into others."
    new "是的，我用咒语只能试着影响她的意志，但没有办法把情绪变成其他东西。"

translate chinese chinese_9865737_554:
    old "{i}Well, then we're in a bad situation here.{/i}"
    new "嗯，那我们现在就处于一个糟糕的境地了。"

translate chinese chinese_8528562_555:
    old "{i}Because she's very certain that she's terrible.{/i}"
    new "因为她非常确定自己很糟糕。"

translate chinese chinese_0238208_556:
    old "Isn't there anything you could use to calm her feelings?"
    new "难道没有什么能让她的心情平静下来吗？"

translate chinese chinese_0989495_557:
    old "Don't you humans have a substance you ingest in these situations?"
    new "你们人类在这种情况下不会吃些什么东西吗？"

translate chinese chinese_4964728_558:
    old "I've seen your [mo1rel] use it before, she seems to calm down with it."
    new "我见过你的[mo1rel]用过，她似乎会因此平静下来。"

translate chinese chinese_4064231_559:
    old "What? No, no, nothing like that."
    new "什么？不，不是那样的。"

translate chinese chinese_7777818_560:
    old "I'm sure you can do it."
    new "我相信你能行的。"

translate chinese chinese_0892674_561:
    old "Just wait here a second, I know of something that can help."
    new "你就在这里等一下，我知道有个东西能帮上忙。"

translate chinese chinese_0869143_562:
    old "Alright, I think this is just what we need."
    new "好吧，我觉得这正是我们所需要的。"

translate chinese chinese_1134379_563:
    old "Well, no, not really."
    new "嗯，其实不是。"

translate chinese chinese_1680960_564:
    old "But I think that drinking a little might help."
    new "但是我觉得喝一点可能会有帮助。"

translate chinese chinese_8463253_565:
    old "I can't remember exactly where I read it"
    new "我记不清具体在哪里看到的了"

translate chinese chinese_6049329_566:
    old "But it was about how some famous actors sometimes drink a little alcohol before shooting some of their scenes."
    new "但是那是关于一些著名演员有时会在拍摄某些场景前喝一点酒的事情。"

translate chinese chinese_2249777_567:
    old "This is supposed to help them feel relaxed, and be able to act more naturally."
    new "这应该让他们感到放松，表现得更自然。"

translate chinese chinese_6250866_568:
    old "I understand that it seems a bit odd, but we could give it a try."
    new "我明白这看起来有点奇怪，但我们不妨试试看。"

translate chinese chinese_9427898_569:
    old "After all, you are feeling a little stressed. Maybe this could help you relax enough for you to recite the lines."
    new "毕竟，你确实有点紧张。也许这能帮你放松一下，好背出那些台词。"

translate chinese chinese_4067283_570:
    old "Oh come on, you can be a little bit more positive than that. I'm sure this is going to help you."
    new "哦，别这样，你可以更积极一点。我相信这对你有帮助的。"

translate chinese chinese_8028682_571:
    old "I'm glad you like it."
    new "很高兴你喜欢。"

translate chinese chinese_3345007_572:
    old "Do you feel better now?"
    new "你现在感觉好些了吗？"

translate chinese chinese_7733646_573:
    old "I see you're feeling better. Let's try it."
    new "看你感觉好多了，我们试试吧。"

translate chinese chinese_4789253_574:
    old "I can prove it!'"
    new "我能证明的！'"

translate chinese chinese_3184781_575:
    old "'I can tell you!"
    new "我可以告诉你！"

translate chinese chinese_8999535_576:
    old "'I'm here now! And you didn't call me!'"
    new "‘我现在来了！而且你还没叫我呢！’"

translate chinese chinese_6839119_577:
    old "'I came because you needed me!'"
    new "‘我来是因为你需要我！’"

translate chinese chinese_4707721_578:
    old "{i}(Wow! It seems like drinking really helped, she got so good all of a sudden!){/i}"
    new "{i}（哇！看来喝酒真的有用，她突然变得这么好了！）{/i}"

translate chinese chinese_9553982_579:
    old "{i}(Now it's my line, I better not brake her concentration now that she's finally doing it well.){/i}"
    new "{i}（现在轮到我说了，她终于做得不错了，我可不能打扰她的专注。）{/i}"

translate chinese chinese_5863699_580:
    old "'Not staying was a mistake!'"
    new "‘不留下来是个错误！’"

translate chinese chinese_8037199_581:
    old "'I should've stayed by your side, I should've been here when you needed me!'"
    new "‘我应该一直陪在你身边，在你需要我的时候在这里！’"

translate chinese chinese_8130017_582:
    old "'But that's why I'm here now!'"
    new "“但这就是我为什么现在在这里的原因！”"

translate chinese chinese_4744735_583:
    old "'To be your companion!'"
    new "‘做你的伴侣！’"

translate chinese chinese_1129774_584:
    old "'Your rock! Your partner!'"
    new "“你的依靠！你的伙伴！”"

translate chinese chinese_9469770_585:
    old "'I will be!'"
    new "“我会的！”"

translate chinese chinese_8358021_586:
    old "'I promise you!'"
    new "我发誓！"

translate chinese chinese_0397616_587:
    old "You know what? It was, it really was."
    new "你知道吗？确实，真的很……"

translate chinese chinese_6896923_588:
    old "I think the alcohol really helped you. Because that last part was great."
    new "我觉得酒精真的帮了你。因为最后那段真的很棒。"

translate chinese chinese_0700819_589:
    old "But let's keep going until we finish this part of the dialogue."
    new "但我们还是继续说到这段对话结束吧。"

translate chinese chinese_1293459_590:
    old "'So! Do you believe me when I say it?'"
    new "“那么！我说的话你相信吗？”"

translate chinese chinese_3994493_591:
    old "'That I want to be by you!'"
    new "‘我想和你在一起！’"

translate chinese chinese_3366599_592:
    old "'That I need to be by your side!'"
    new "‘我需要在你身边！’"

translate chinese chinese_2568133_593:
    old "'Nothing would make me happier!'"
    new "‘没什么能让我更开心了！’"

translate chinese chinese_6513976_594:
    old "'It means that we love each other!'"
    new "‘这意味着我们彼此相爱！’"

translate chinese chinese_8903944_595:
    old "{i}(Wow! She's so much better than she was just a minute ago!){/i}"
    new "{i}（哇！她比刚才好多了！）{/i}"

translate chinese chinese_3545123_596:
    old "{i}(Hmm, there's a kiss scene coming, and I didn't tell her where the scene would end.){/i}"
    new "({i}嗯，有个吻戏要来了，但我还没告诉她这场戏会怎么结束。{/i})"

translate chinese chinese_7192517_597:
    old "{i}(She won't kiss me without talking with me about it, right?){/i}"
    new "{i}（她不会在不和我谈谈的情况下吻我，对吧？）{/i}"

translate chinese chinese_4002057_598:
    old "'I can, and I will!'"
    new "‘我能，我也会这么做！’"

translate chinese chinese_1285856_599:
    old "'If you say yes now I promise I'll always be there!'"
    new "“如果你现在答应了，我发誓我会永远都在！”"

translate chinese chinese_0288753_600:
    old "'I will always be the rock that you need!'"
    new "“我永远都会是你需要的依靠！”"

translate chinese chinese_6284274_601:
    old "'No matter what!'"
    new "不管怎样！"

translate chinese chinese_5165381_602:
    old "{i}(I can't believe it, she actually kissed me!){/i}"
    new "{i}(真不敢相信，她竟然吻了我！){/i}"

translate chinese chinese_9903578_603:
    old "{i}(That was unexpected, but I guess she's really into the role.){/i}"
    new "{i}（这真是出乎意料，但看来她真的很入戏。）{/i}"

translate chinese chinese_2762251_604:
    old "{i}(If that's the case then I should just keep going with the script.){/i}"
    new "{i}（如果是这样的话，那我应该继续按剧本进行。）{/i}"

translate chinese chinese_8390997_605:
    old "'I'll gladly take it!'"
    new "“我欣然接受！”"

translate chinese chinese_6754645_606:
    old "'But in return, I'll let you have mine!'"
    new "“但是作为回报，我的给你！”"

translate chinese chinese_5578863_607:
    old "'Because this is a partnership!'"
    new "“因为这是合作关系！”"

translate chinese chinese_1150099_608:
    old "'We're meant to be together!'"
    new "‘我们是天生一对！’"

translate chinese chinese_7950436_609:
    old "'I know it!'"
    new "我知道！"

translate chinese chinese_8526539_610:
    old "'Are you sure?'"
    new "你确定吗？"

translate chinese chinese_5018154_611:
    old "'Does this mean that you'll stay by my side?'"
    new "‘这意思是你会一直陪在我身边吗？’"

translate chinese chinese_1018121_612:
    old "Uhh... Y- yeah, it was, it really, really was."
    new "呃……是的，真的很……"

translate chinese chinese_9889248_613:
    old "I- I mean, your acting was great."
    new "我——我是说，你演得太好了。"

translate chinese chinese_4098232_614:
    old "I think you won't have any problems when the audition comes."
    new "我觉得到试镜的时候你应该不会有什么问题。"

translate chinese chinese_8753605_615:
    old "Hmm... Sure."
    new "嗯……好吧。"

translate chinese chinese_3716343_616:
    old "Okay."
    new "好吧。"

translate chinese chinese_6088594_617:
    old "But maybe we should change the scene because this one ends in a love scene between the leads."
    new "但也许我们应该换个场景，因为这个场景最后是主角们的床戏。"

translate chinese chinese_0544230_618:
    old "So, we could look for another one."
    new "所以，我们可以再找一个。"

translate chinese chinese_7532883_619:
    old "U- Uhh, I- I don't know how- ."
    new "uh, 我- 我不知道怎么- ."

translate chinese chinese_8999569_620:
    old "Don't you think you're drinking a little too much of that?"
    new "你不觉得你喝这个喝得有点多了吗？"

translate chinese chinese_4707315_621:
    old "W- what are you doing Barbie?"
    new "你干什么呢，芭比？"

translate chinese chinese_3310060_622:
    old "Listen... About last night..."
    new "听着……关于昨晚……"

translate chinese chinese_7944138_623:
    old "Uhh... Yeah, yeah, sure, don't worry about it..."
    new "呃……是的，是的，没关系，别担心……"

translate chinese chinese_5489192_624:
    old "Good luck with the audition, I know you'll do great."
    new "祝你试镜顺利，我知道你会表现得很棒。"

translate chinese chinese_9153713_625:
    old "That was great [pla]!"
    new "[pla]，你真棒！"

translate chinese chinese_9228031_626:
    old "You finally did it! Well done!"
    new "你终于做到了！干得好！"

translate chinese chinese_1924995_627:
    old "Of course you'll have to have more sex with her..."
    new "当然你得和她发生更多的性关系……"

translate chinese chinese_9447160_628:
    old "But now that you've done it once, you shouldn't have any problems doing it again..."
    new "但既然你已经做过一次了，再做一次应该没问题了吧……"

translate chinese chinese_3482799_629:
    old "Now we can focus on finding the next specimen."
    new "现在我们可以专心找下一个样本了。"

translate chinese chinese_7991189_630:
    old "Well of couse."
    new "那当然了。"

translate chinese chinese_9441536_631:
    old "Now that you know you're going to have sex with this woman so easily."
    new "现在你知道你会这么轻易地和这个女人上床了。"

translate chinese chinese_8818002_632:
    old "You can stop wasting time on her and focus on finding the next person we need."
    new "你可以停止浪费时间在她身上，专心找下一个我们需要的人。"

translate chinese chinese_5944621_633:
    old "Hey, hey, stop it right there!"
    new "喂，喂，停下来！"

translate chinese chinese_1855073_634:
    old "I don't know what it is you have in mind."
    new "我不知道你在想什么。"

translate chinese chinese_3439723_635:
    old "But is not that easy..."
    new "但是没那么简单……"

translate chinese chinese_8304546_636:
    old "I promised I would help her with this, and I plan to fulfill that promise."
    new "我答应过会帮她的，我打算履行这个承诺。"

translate chinese chinese_2902998_637:
    old "So I'm sorry to disappoint you, but until she gets an acting job, I won't be looking for another 'specimen'..."
    new "所以我很抱歉让你失望了，但在她找到演戏的工作之前，我不会再去寻找另一个“样本”……"

translate chinese chinese_6088755_638:
    old "Besides, I don't think there's going to be a next time having sex with her if I just leave her hanging."
    new "再说，如果我这样甩了她，下次再和她上床的可能性也不大了。"

translate chinese chinese_0797896_639:
    old "And you still need me to do it with her more times, isn't it?"
    new "而且你还需要我多和她做几次，对吧？"

translate chinese chinese_8615708_640:
    old "Ughh! You humans are so complicated!"
    new "哎呀！你们人类真是复杂！"

translate chinese chinese_8123349_641:
    old "Fine! Do as you wish!"
    new "好！随你便！"

translate chinese chinese_9965749_642:
    old "But do it quickly! We don't have much time to lose!"
    new "但是快点！我们没多少时间可以浪费！"

translate chinese chinese_1434351_643:
    old "Yeah, yeah, you've made that clear."
    new "好了好了，你已经说得很清楚了。"

translate chinese chinese_9353114_644:
    old "Hey Barbie, how are you?"
    new "嘿，芭比，最近怎么样？"

translate chinese chinese_1517883_645:
    old "W- what? Why?"
    new "什、什么？为什么？"

translate chinese chinese_4344068_646:
    old "It did? You didn't feel comfortable?"
    new "真的吗？你觉得不舒服吗？"

translate chinese chinese_7380462_647:
    old "I get it, I mean... I guess fear made you forget the dialogue..."
    new "我懂了，我的意思是……大概是害怕得忘了台词了吧……"

translate chinese chinese_7542696_648:
    old "Who does he think he is? He has no right to treat you like that!"
    new "他以为他是谁啊？他没有权利那样对你！"

translate chinese chinese_7572016_649:
    old "I'm sorry Barbie, you didn't deserve him treating you like that."
    new "对不起芭比，你不应该被他那样对待。"

translate chinese chinese_5163637_650:
    old "No you're not, don't make what he told you a law."
    new "你不是这样的，不要把他的话当成金科玉律。"

translate chinese chinese_3350017_651:
    old "You're very talented Barbie, I saw it the other day while we were practicing."
    new "你很有天赋，芭比，我前几天练习的时候看出来了。"

translate chinese chinese_4595023_652:
    old "I'm sure it's going to be better in the next audition you go to."
    new "我相信你在下一次试镜时会表现得更好的。"

translate chinese chinese_3026181_653:
    old "B- but that's your dream, to be part of show business."
    new "但那是你的梦想，成为演艺圈的一员。"

translate chinese chinese_7511877_654:
    old "You know, to work in acting and stuff."
    new "你知道，去做演员什么的。"

translate chinese chinese_8371052_655:
    old "Wait! Wait!"
    new "等！等！"

translate chinese chinese_4862536_656:
    old "Don't think so bad about yourself!"
    new "别这么看自己！"

translate chinese chinese_3094468_657:
    old "You shouldn't believe that you're not good enough to act!"
    new "你不应该认为自己不够好去演戏！"

translate chinese chinese_5281554_658:
    old "I know you're more than capable of it."
    new "我知道你完全能做到的。"

translate chinese chinese_1432978_659:
    old "Hey I have an idea!"
    new "嘿，我有个主意！"

translate chinese chinese_5122076_660:
    old "Listen, I know you're feeling bad."
    new "听着，我知道你很难过。"

translate chinese chinese_6552302_661:
    old "But I think there's a way so that you don't have to give up on your dream."
    new "但是我觉得有一条路可以让你不放弃梦想。"

translate chinese chinese_6468486_662:
    old "I get it, but listen, your dream is to be famous, right?"
    new "我明白，但听我说，你的梦想是出名，对吧？"

translate chinese chinese_6622194_663:
    old "But there's more than one way of achieving it."
    new "但是达成目标的方法不止一种。"

translate chinese chinese_8167021_664:
    old "For example, have you thought about modeling?"
    new "比如说，你考虑过做模特吗？"

translate chinese chinese_1584253_665:
    old "Sure!  Listen, maybe you're right about not being the best actor right now."
    new "当然！听我说，也许你现在确实不是最好的演员。"

translate chinese chinese_7685992_666:
    old "But that's not the only way to earn fame."
    new "但那不是成名的唯一途径。"

translate chinese chinese_8638447_667:
    old "There are several different things that you can do."
    new "你可以做几件不同的事情。"

translate chinese chinese_0170501_668:
    old "And I think you could easily be an amazing model!"
    new "而且我觉得你完全可以成为一名出色的模特！"

translate chinese chinese_8752413_669:
    old "Of course I do!"
    new "我当然有！"

translate chinese chinese_8009863_670:
    old "There are several actors that got their start as models, and over time they moved into acting."
    new "有一些演员是从模特转行做演员的，随着时间的推移他们逐渐进入了演艺圈。"

translate chinese chinese_8999415_671:
    old "With how beautiful you are. I don't see why you couldn't do the same thing."
    new "像你这么漂亮，我觉得你也能做到同样的事情。"

translate chinese chinese_8802935_672:
    old "You have to be kidding me."
    new "你在开玩笑吧。"

translate chinese chinese_8047553_673:
    old "I mean, look at yourself. You're beautiful."
    new "我是说，看看你自己。你很漂亮。"

translate chinese chinese_0324218_674:
    old "And you have an amazing body!"
    new "而且你身材棒极了！"

translate chinese chinese_9817140_675:
    old "Of course you can be a model!"
    new "当然你可以当模特了！"

translate chinese chinese_9441437_676:
    old "How can you say that?"
    new "你怎么能这么说？"

translate chinese chinese_5559999_677:
    old "Maybe what you're saying about models was true several years ago."
    new "也许你说的关于模特的情况几年前是真的。"

translate chinese chinese_4580667_678:
    old "But there are several different types now. And you are one of the most beautiful women that I've met."
    new "但是现在有很多不同的类型。而且你是我在见过的女人中最美丽的之一。"

translate chinese chinese_7422392_679:
    old "I'm sure you'll find work in any agency you want in no time."
    new "我相信你很快就能在任何你想去的机构找到工作。"

translate chinese chinese_6219735_680:
    old "Of course I believe it. And I'm sure it's going to go great."
    new "我当然相信。而且我相信一定会很顺利。"

translate chinese chinese_2581891_681:
    old "R- right... Sure."
    new "嗯……好。"

translate chinese chinese_1651250_682:
    old "I'll get you something as a model."
    new "我给你找个模特儿。"

translate chinese chinese_5448481_683:
    old "So, I'm going to have to make a couple of calls, but I'll let you know later about what I find."
    new "好吧，我得打几个电话，但我会稍后告诉你我查到什么的。"

translate chinese chinese_1741163_684:
    old "Ok?"
    new "好吧？"

translate chinese chinese_7491022_685:
    old "You're more than welcome."
    new "非常乐意。"

translate chinese chinese_7549747_686:
    old "I'm just happy to help."
    new "我就是乐意帮忙。"

translate chinese chinese_6003934_687:
    old "I'll go for now, and I'll see you later, alright?"
    new "我先走了，待会儿见，好吗？"

translate chinese chinese_1073790_688:
    old "Hmm, I guess it's good that Barbie's feeling better now."
    new "嗯，看来芭比现在感觉好些了，这挺好的。"

translate chinese chinese_3515256_689:
    old "But now, how will I get her a modeling casting?"
    new "但现在，我怎么给她找一个模特试镜的机会呢？"

translate chinese chinese_2583522_690:
    old "I don't know anyone who works as a model or something similar..."
    new "我不认识有什么人是当模特或者类似工作的……"

translate chinese chinese_7412050_691:
    old "Hmph, I don't want to bother Belle again to get me an audition..."
    new "哼，我可不想再麻烦贝尔给我安排试镜..."

translate chinese chinese_0092267_692:
    old "Who else could help me with this..."
    new "还有谁能帮我解决这个……"

translate chinese chinese_9014408_693:
    old "What are you doing?"
    new "你在干什么？"

translate chinese chinese_2820533_694:
    old "When you went looking for her, I thought you would come back together to have sex..."
    new "你去找她的时候，我还以为你会带她一起回来做爱……"

translate chinese chinese_9992801_695:
    old "Of course not, things don't work like that..."
    new "当然不是，事情不会那样发展的..."

translate chinese chinese_8100308_696:
    old "Perhaps you should be helping me instead of complaining so much."
    new "也许你应该帮我而不是抱怨这么多。"

translate chinese chinese_3093494_697:
    old "Maybe this way we can help Barbie more quickly..."
    new "也许这样我们可以更快地帮助芭比……"

translate chinese chinese_6463330_698:
    old "And so we can wrap this up and start looking for the next 'specimen' as you want..."
    new "这样我们就能搞定这件事，开始寻找下一个“标本”了，就像你想要的那样……"

translate chinese chinese_5092132_699:
    old "Hmph, I guess you leave me no choice..."
    new "哼，看来你这是逼我了……"

translate chinese chinese_8489360_700:
    old "It's not easy, really, unless you magically know somebody that can get a casting with a modeling agency."
    new "真的不容易，除非你神奇地认识能拿到模特公司试镜机会的人。"

translate chinese chinese_7220655_701:
    old "I need someone who works with models, you know, like these clothes and lingerie brands, or something like that..."
    new "我需要一个能跟模特打交道的人，就是这种衣服和内衣品牌之类的……"

translate chinese chinese_0272252_702:
    old "Wait! I got it! [sis]!"
    new "等一下！我想起来了！[sis]！"

translate chinese chinese_5324912_703:
    old "Right now it's too late, but tomorrow I'll go talk with my [sisrel]."
    new "现在太晚了，但明天我会去找我的[sisrel]谈谈。"

translate chinese chinese_4770305_704:
    old "Oh no, why do I get the feeling this is going to take even longer?"
    new "哦不，为什么我觉得这会花更长时间？"

translate chinese chinese_3168377_705:
    old "Relax, you help me to talk with [sis] tomorrow and we could get Barbie a model job, and that's it."
    new "放松点，你明天帮我跟[sis]谈谈，然后帮芭比找份模特工作，就这些。"

translate chinese chinese_5498662_706:
    old "Hmm, if you say so..."
    new "嗯，如果你这么说的话……"

translate chinese chinese_1299821_707:
    old "Anyway, I'm a bit tired, so, I'm going to sleep now..."
    new "总之，我有点累了，现在去睡觉了……"

translate chinese chinese_5674138_708:
    old "See you tomorrow Brixxida."
    new "明天见，布里克西达。"

translate chinese chinese_5877381_709:
    old "See you..."
    new "再见..."

translate chinese chinese_2580325_710:
    old "What brings you here so early?"
    new "你这么早来干什么？"

translate chinese chinese_9773994_711:
    old "Hey [sis]. Good morning."
    new "嘿[sis]，早上好。"

translate chinese chinese_2290416_712:
    old "What's up?"
    new "怎么了？"

translate chinese chinese_6714657_713:
    old "W- well... Uhmm."
    new "嗯……那个。"

translate chinese chinese_2759710_714:
    old "T- the thing is that I kinda need a favor from you."
    new "其实，我有点事需要请你帮忙。"

translate chinese chinese_6929210_715:
    old "But... I don't really know how to ask you..."
    new "但是……我不知道该怎么问你……"

translate chinese chinese_8180963_716:
    old "Well just do it."
    new "那就直接做吧。"

translate chinese chinese_3709169_717:
    old "You know I'll help you with anything you want."
    new "你知道的，无论你需要什么帮助，我都会帮你的。"

translate chinese chinese_8150223_718:
    old "{b}*Sigh*{/b} Well, here it goes..."
    new "{b}*叹气*{/b} 好吧，就这么开始了..."

translate chinese chinese_0318618_719:
    old "Do you know Barbie? The receptionist of the building where Jane's office is located?"
    new "你认识芭比吗？就是简办公室那栋大楼的前台？"

translate chinese chinese_4594322_720:
    old "Yeah, sure I do. That silicon-filled bimbo."
    new "是啊，我确实在。那个充满硅胶的蠢女人。"

translate chinese chinese_2467322_721:
    old "What about her?"
    new "她怎么了？"

translate chinese chinese_0756789_722:
    old "Uh... W- well, the thing is that..."
    new "呃……那个，其实是这样的……"

translate chinese chinese_4187808_723:
    old "S- she kind of needs help with something right now, and I promised I would give her that help."
    new "她现在有点需要帮忙，我答应过会帮她的。"

translate chinese chinese_4019074_724:
    old "Are you serious right now [pla]?!"
    new "你现在是认真的吗，[pla]?!"

translate chinese chinese_4053760_725:
    old "What kind of help? And what favor are you gonna ask me?"
    new "什么帮忙？你还想让我做什么 favors？"

translate chinese chinese_2608332_726:
    old "Well, a few days ago I came into the building to bring some documents from [mo1] and...."
    new "嗯，几天前我进大楼给[mo1]送些文件，然后……"

translate chinese chinese_9067095_727:
    old "We got to talking and she told me that lately she's been feeling very sad about not being able to..."
    new "我们聊着聊着，她告诉我最近因为不能……感到很悲伤。"

translate chinese chinese_7021221_728:
    old "Well, she wants to be a model, so I said that I would help her with that."
    new "嗯，她想当模特，所以我答应帮她实现这个愿望。"

translate chinese chinese_4555758_729:
    old "But the truth is that I have no contacts in the modeling industry."
    new "但事实是我没有任何模特圈的人脉。"

translate chinese chinese_2051535_730:
    old "So, I was wondering if you would consider having her model for your online business."
    new "所以，我在想你是否考虑让她为你在线上的生意当模特。"

translate chinese chinese_5306241_731:
    old "No I would not accept it!"
    new "我才不会接受呢！"

translate chinese chinese_8483337_732:
    old "Why would I want that vulgar, plastic bimbo modeling in my clothes?!"
    new "我为什么要让那个粗俗的塑料美女来给我衣服做模？！"

translate chinese chinese_8723222_733:
    old "It would ruin the reputation of my brand!"
    new "这会毁了我的品牌声誉！"

translate chinese chinese_7622543_734:
    old "Which by the way, I'm surprised you're so interested in her as to come here and ask me if I would let her model my clothes!"
    new "话说回来，我挺惊讶你对她这么感兴趣，特地来这里问我让她给我当衣服模特的事！"

translate chinese chinese_6276109_735:
    old "You know [pla], I thought you had better taste than that."
    new "你知道[pla]，我以为你的品味比这好。"

translate chinese chinese_3478767_736:
    old "I mean..."
    new "我的意思是..."

translate chinese chinese_9330426_737:
    old "All of this just because you want to bang that stupid girl?"
    new "这一切就因为你想要那个愚蠢的女孩？"

translate chinese chinese_6932908_738:
    old "What? Come on, is not like that."
    new "什么？别这样，不是那样的。"

translate chinese chinese_6794166_739:
    old "Oh yeah? Then how is it?"
    new "哦是吗？那怎么样？"

translate chinese chinese_8917015_740:
    old "Because it seems to me that you're more interested in fucking her than anything else."
    new "因为在我看来，你对她感兴趣的程度似乎超过了其他任何事情。"

translate chinese chinese_4647022_741:
    old "You men are so predictable, you see some stupid girl with tits and ass like balloons and you go crazy."
    new "你们男人真是容易预测，看到有些胸大屁股大的傻女孩就疯了。"

translate chinese chinese_4120503_742:
    old "I already told you, is not like that..."
    new "我already告诉过你，不是那样的..."

translate chinese chinese_9897897_743:
    old "Boy, you seem to have a talent for altering people's feelings."
    new "嘿，你好像很有改变别人情绪的天赋啊。"

translate chinese chinese_6396514_744:
    old "Every time I'm with you, you're making some woman angry or cry or just lose her temper."
    new "每次和你在一起，你都能把某个女人气到哭或者发飙。"

translate chinese chinese_8126592_745:
    old "Why don't you help me then?"
    new "那你为什么不来帮我呢？"

translate chinese chinese_8811958_746:
    old "What? Do you need even more explanations?"
    new "什么？你需要更多的解释吗？"

translate chinese chinese_7238942_747:
    old "Uhh? No, no, I- I-... Nevermind..."
    new "呃？不，不，我- 我- ... 算了..."

translate chinese chinese_8848692_748:
    old "Hahaha, look at you! Grasping for words."
    new "哈哈，看你这模样，都结巴了。"

translate chinese chinese_4997657_749:
    old "I'll help you then."
    new "那我帮你吧。"

translate chinese chinese_9090495_750:
    old "Listen [pla]."
    new "听着，[pla]。"

translate chinese chinese_1564027_751:
    old "She's experiencing a very negative emotion. And it's all directed at you."
    new "她正在经历一种非常负面的情绪，而且这一切都是针对你的。"

translate chinese chinese_1244808_752:
    old "Anyway, you can leave, I'm busy."
    new "反正你可以走了，我忙着呢。"

translate chinese chinese_7192954_753:
    old "No wait! It's not directed at you!"
    new "别急！那不是针对你的！"

translate chinese chinese_0141813_754:
    old "Is about that girl!"
    new "就是那个女孩！"

translate chinese chinese_0956034_755:
    old "She's..."
    new "她..."

translate chinese chinese_9406610_756:
    old "Jelaous!"
    new "吃醋了！"

translate chinese chinese_0540733_757:
    old "That's it, she's feeling jealous."
    new "没错，她吃醋了。"

translate chinese chinese_5783776_758:
    old "No, [pla], I'm not gonna help you to bang that bimbo..."
    new "不，[pla]，我不会帮你搞那个女人的..."

translate chinese chinese_1105356_759:
    old "Uhh, you better do something about that or she really won't help you at all."
    new "呃，你最好采取点行动，否则她真的不会帮你了。"

translate chinese chinese_1822063_760:
    old "I mean, I think I didn't express explain properly."
    new "我的意思是，我觉得我没有解释清楚。"

translate chinese chinese_9433881_761:
    old "Listen, the reason why I want to help Barbie is not that I want to sleep with her or something like that."
    new "听着，我想帮芭比的原因不是因为我想要跟她上床或者什么的。"

translate chinese chinese_5263647_762:
    old "The truth is that I've been thinking that I would like to be a photographer."
    new "其实我一直在想，我想成为一名摄影师。"

translate chinese chinese_6690854_763:
    old "A photographer?"
    new "摄影师？"

translate chinese chinese_1866726_764:
    old "Yeah, you know I'm good with the camera."
    new "yeah, 你知道我对摄像很在行。"

translate chinese chinese_6493143_765:
    old "And that I know how to edit and present pictures."
    new "而且我知道如何编辑和展示照片。"

translate chinese chinese_0716304_766:
    old "So it came to my mind that I could do some work in that field. You know for magazines and stuff."
    new "突然想到我可以在那方面做些工作，你知道的，比如杂志之类的。"

translate chinese chinese_5022311_767:
    old "But getting a job as a photographer is too difficult."
    new "但是当摄影师太难了。"

translate chinese chinese_8653557_768:
    old "But then I talked with Barbie, and it came to my mind that maybe that was it."
    new "但是后来我和芭比聊了聊，突然想到也许就是那样。"

translate chinese chinese_1688848_769:
    old "That if I helped her it could be good for the both of us, and that I could get a job as a photographer like that."
    new "她说如果我帮了她，对我们俩都有好处，而且我可以借此机会当上摄影师。"

translate chinese chinese_2209747_770:
    old "Hmm, are you serius?"
    new "哼，你是认真的吗？"

translate chinese chinese_9969416_771:
    old "Yeah, that's really all I'm looking for. I don't know where you got the idea about sex..."
    new "是的，这真的就是我想要的全部。我不知道你是从哪里想到性这个话题的..."

translate chinese chinese_8226245_772:
    old "Well, that's not such a bad idea [pla]."
    new "嗯，这倒不是什么坏主意[pla]。"

translate chinese chinese_5442213_773:
    old "It's actually some good thinking on your part."
    new "你这倒是挺聪明的。"

translate chinese chinese_6328119_774:
    old "But why didn't you start with that?"
    new "但是你为什么不一开始就那样说？"

translate chinese chinese_9553323_775:
    old "W- well you know."
    new "嗯，你知道的。"

translate chinese chinese_4031738_776:
    old "I- I didn't think that was that important."
    new "我——我以为那不那么重要。"

translate chinese chinese_7724937_777:
    old "You didn't think that was important?"
    new "你没想到那很重要吗？"

translate chinese chinese_8102764_778:
    old "But you thought it was more important to just tell me you want to help that plastic bimbo?"
    new "但你认为更重要的是告诉我你想去帮那个塑料美女？"

translate chinese chinese_4892196_779:
    old "Very smart."
    new "很聪明。"

translate chinese chinese_9291695_780:
    old "But anyway, I think I see your point."
    new "不过话说回来，我大概明白你的意思了。"

translate chinese chinese_4456831_781:
    old "And you are good with the camera."
    new "你用相机的功夫不错。"

translate chinese chinese_5644213_782:
    old "You could be a good photographer."
    new "你有可能成为一个好摄影师。"

translate chinese chinese_3002392_783:
    old "Now, let me see your portfolio of her pictures."
    new "现在，让我看看她的照片集。"

translate chinese chinese_0845418_784:
    old "Portfolio?"
    new "作品集？"

translate chinese chinese_9363705_785:
    old "Well of course."
    new "那当然了。"

translate chinese chinese_2177098_786:
    old "I mean, you do have a portfolio of pictures right?"
    new "我的意思是，你总有一份照片集吧？"

translate chinese chinese_3103217_787:
    old "I- I don't..."
    new "我……我不……"

translate chinese chinese_1152290_788:
    old "Ugh, be serious [pla]."
    new "哎，严肃点，[pla]。"

translate chinese chinese_4288114_789:
    old "You say you want to be a photographer, but you don't know anything."
    new "你说你想当摄影师，但你什么都不知道。"

translate chinese chinese_7003615_790:
    old "If you want someone to give you a job in photography you need to have pictures to show."
    new "如果你想让人给你摄影工作，你需要有照片展示。"

translate chinese chinese_9283486_791:
    old "Especially with something like pictures of that little plastic dumb."
    new "特别是像那种小塑料玩偶的照片。"

translate chinese chinese_0195606_792:
    old "How else is someone going to hire her?"
    new "不然别人怎么雇佣她？"

translate chinese chinese_3250815_793:
    old "I understand, so you need me to take pictures of her?"
    new "我明白了，所以你需要我给她拍照？"

translate chinese chinese_4755932_794:
    old "I think I can do that, and bring some of those for you."
    new "我觉得我可以做到，并且给你带一些。"

translate chinese chinese_5484333_795:
    old "Good. Be sure they're good so that I can show them to the people that might hire her."
    new "好的。确保这些作品足够好，这样我就可以拿给可能会雇佣她的人看了。"

translate chinese chinese_7015712_796:
    old "By the way, I hope you understand I'm not doing this out of the goodness of my heart, right?"
    new "对了，希望你明白我不是出于好心才这么做的，好吧？"

translate chinese chinese_9843832_797:
    old "If she's going to get money for it, and I got her the job, I want my cut."
    new "如果她要从中赚钱，而且是我给她找的工作，那我也得分一杯羹。"

translate chinese chinese_0727649_798:
    old "Uhh, yeah yeah, sure..."
    new "呃，好吧好吧……"

translate chinese chinese_6877073_799:
    old "If you get her a job, then sure, I can give you a commission."
    new "如果你给她找份工作，那我可以给你提成。"

translate chinese chinese_2249309_800:
    old "I want a 10 percent! Is that clear?"
    new "我要百分之十！听清楚了没？"

translate chinese chinese_7122473_801:
    old "Sure, whatever."
    new "行吧，随便你。"

translate chinese chinese_2302712_802:
    old "Hey, thanks a lot [sis]."
    new "嘿，谢谢你，[sis]。"

translate chinese chinese_4325857_803:
    old "Yeah well, I'm not doing it for her."
    new "好吧，我做这个可不是为了她。"

translate chinese chinese_7912775_804:
    old "I'm helping you."
    new "我在帮你。"

translate chinese chinese_6394429_805:
    old "Sure, but thanks anyway."
    new "好吧，不过还是谢谢你。"

translate chinese chinese_3913862_806:
    old "You're welcome."
    new "不客气。"

translate chinese chinese_4000626_807:
    old "I'll talk to Barbie later and let her know about this."
    new "我待会儿和芭比说一下这个事。"

translate chinese chinese_7751217_808:
    old "Listen, I have to leave for now, so I'll send you the info when I get it."
    new "听着，我现在得走了，等我拿到信息再发给你。"

translate chinese chinese_4309367_809:
    old "I'm doing well, thank you."
    new "我挺好的，谢谢。"

translate chinese chinese_7378802_810:
    old "Hey listen, I have great news!"
    new "嘿，听我说，有个好消息！"

translate chinese chinese_0495411_811:
    old "You could say that."
    new "这么说也没错。"

translate chinese chinese_5692032_812:
    old "Do you remember what we had talked about modeling?"
    new "你还记得我们之前聊过的关于模特的事情吗？"

translate chinese chinese_2963516_813:
    old "Well, after we talked I got in contact with someone I know that has some connections to the modeling business."
    new "好吧，聊完之后我联系了一个认识的人，他在模特行业有些人脉。"

translate chinese chinese_5194795_814:
    old "And she told me that she could get you an interview!"
    new "而且她告诉我她能帮你弄到面试机会！"

translate chinese chinese_2661291_815:
    old "Yeah, but you see..."
    new "是啊，但是你看……"

translate chinese chinese_9771765_816:
    old "She told me that I had to take some pictures of you, to show to the agency."
    new "她告诉我得拍些你的照片给经纪公司看。"

translate chinese chinese_2572494_817:
    old "Like a portfolio or something."
    new "就像一个作品集之类的东西。"

translate chinese chinese_4154363_818:
    old "You know, to see how you look."
    new "你知道的，看看你长什么样子。"

translate chinese chinese_1101512_819:
    old "Actually, I can take them myself."
    new "其实我自己能搞定。"

translate chinese chinese_5847426_820:
    old "Yeah sure, it wouldn't be a problem."
    new "嗯哼，这没问题。"

translate chinese chinese_8307656_821:
    old "I have some experience as a photographer."
    new "我有一些当摄影师的经验。"

translate chinese chinese_1914969_822:
    old "Heh, well thank you."
    new "嘿嘿，谢谢了。"

translate chinese chinese_9457811_823:
    old "But you see, we have to take the pictures soon."
    new "但是你看，我们必须尽快拍这些照片。"

translate chinese chinese_2491894_824:
    old "She wants to send them as soon as possible."
    new "她想尽快把它们寄出去。"

translate chinese chinese_4908855_825:
    old "So, how about we go to my house after you finish work and take the photos?"
    new "这样吧，你下班后去我家拍照片怎么样？"

translate chinese chinese_5319793_826:
    old "Come on, you don't have to worry about it."
    new "放心吧，你不用担心这个。"

translate chinese chinese_2919312_827:
    old "What you're wearing is perfect, you don't need to worry about it."
    new "你穿的已经很完美了，不用担心。"

translate chinese chinese_0894322_828:
    old "Of course, you look perfect the way you are."
    new "当然了，你本来的样子就完美无缺。"

translate chinese chinese_0897385_829:
    old "Great, so I'll wait until your shift is over, and after we can go to my house."
    new "好的，那我就等你下班，然后我们可以去我家。"

translate chinese chinese_2849477_830:
    old "Okay, lets go."
    new "好吧，我们走吧。"

translate chinese chinese_7901931_831:
    old "Alright, we can get started then-"
    new "好吧，那我们可以开始了—"

translate chinese chinese_5596132_832:
    old "Don't worry about it."
    new "别担心这个。"

translate chinese chinese_5994101_833:
    old "I can show you."
    new "我可以给你看。"

translate chinese chinese_6846470_834:
    old "Well, I've helped my [sisRel] before with her work."
    new "嗯，我之前帮过我的[sisRel]工作。"

translate chinese chinese_3465041_835:
    old "She has an online clothing business."
    new "她在网上经营一家服装店。"

translate chinese chinese_8577998_836:
    old "And sometimes I'm the one that takes the pictures of her new clothes."
    new "有时候是我给她新衣服拍照。"

translate chinese chinese_7874174_837:
    old "Heh, thank you."
    new "嘿嘿，谢谢。"

translate chinese chinese_6001582_838:
    old "Anyway, I guess we can get started then."
    new "总之，我想我们可以开始了。"

translate chinese chinese_6800766_839:
    old "Just relax, I'll tell you how you should pose."
    new "放松点，我会告诉你应该怎么摆姿势。"

translate chinese chinese_7446960_840:
    old "So, for the first picture..."
    new "所以，第一张图片……"

translate chinese chinese_9062742_841:
    old "How about you sit down in the bed with your legs open, looking this way."
    new "你坐在床上，双腿张开，朝这边看着。"

translate chinese chinese_9094611_842:
    old "Put your left arm up behind your head, and bring the right one to your neck."
    new "把左臂抬到脑后，右臂放到脖子上。"

translate chinese chinese_4464053_843:
    old "Over your right breast."
    new "在你的右胸上方。"

translate chinese chinese_8766042_844:
    old "And look straight at the camera, Ok?"
    new "而且直视镜头，好吗？"

translate chinese chinese_3505160_845:
    old "Alright perfect! "
    new "好的，完美！"

translate chinese chinese_6554495_846:
    old "That way you're more than perfect!"
    new "这样你就不仅仅是完美了！"

translate chinese chinese_9399408_847:
    old "Just stay put and I'll take the first picture."
    new "你就待着别动，我先拍第一张。"

translate chinese chinese_6993601_848:
    old "That was perfect Barbie!"
    new "完美 Barbie！"

translate chinese chinese_0179608_849:
    old "Now, for the second pose."
    new "现在，换第二个姿势。"

translate chinese chinese_4933919_850:
    old "Hmm, let's see..."
    new "嗯，让我想想..."

translate chinese chinese_1317793_851:
    old "I think we should show you from all angles."
    new "我觉得我们应该从各个角度给你展示一下。"

translate chinese chinese_7774570_852:
    old "So, how about you take more of a kneeling position in the bed."
    new "那你在床上跪着试试怎么样？"

translate chinese chinese_5855896_853:
    old "With your legs towards me."
    new "腿朝我这边。"

translate chinese chinese_2677472_854:
    old "And put your weight on your left arm."
    new "然后把重心放在左臂上。"

translate chinese chinese_9433434_855:
    old "Yes! That's perfect!"
    new "没错！就是这样！"

translate chinese chinese_7949542_856:
    old "Great Barbie!"
    new "太棒了，芭比！"

translate chinese chinese_8343802_857:
    old "Just stay like that, and I'll take the picture."
    new "就保持那个姿势，我来给你拍照。"

translate chinese chinese_5870195_858:
    old "Alright, that's great!"
    new "好吧，那太好了！"

translate chinese chinese_6664166_859:
    old "Now, I think we can take another picture."
    new "现在，我觉得我们可以再拍一张照片了。"

translate chinese chinese_9247452_860:
    old "Sure, for the third one let's make it a close-up."
    new "好的，第三个我们就来个特写吧。"

translate chinese chinese_6580489_861:
    old "So, turn to face the camera."
    new "所以，转过身面对镜头。"

translate chinese chinese_5587401_862:
    old "And bring your breasts forward with your hands while you smile."
    new "笑着用手把胸部往前推。"

translate chinese chinese_0126377_863:
    old "Ok, I know what you mean."
    new "好的，我知道你的意思。"

translate chinese chinese_1698708_864:
    old "That's right! Perfect!"
    new "对了！完美！"

translate chinese chinese_6929648_865:
    old "You're very good at this Barbie!"
    new "你在这方面很擅长啊，芭比！"

translate chinese chinese_4175536_866:
    old "No matter how good I am, it wouldn't be possible without such a beautiful model."
    new "不管我多么擅长，没有这么漂亮的模特也不行。"

translate chinese chinese_0896235_867:
    old "Alright, that's it, I think that we have enough pictures with those ones."
    new "好吧，够了，我觉得这些照片已经拍得差不多了。"

translate chinese chinese_3957325_868:
    old "Yeah, I think those are more than enough."
    new "是的，我觉得这些已经够多了。"

translate chinese chinese_0901860_869:
    old "Ok, I think these came out great!"
    new "好的，我觉得这些效果很棒！"

translate chinese chinese_6015612_870:
    old "Here, look."
    new "看这里。"

translate chinese chinese_3256819_871:
    old "I'm sure they will."
    new "我相信他们会的。"

translate chinese chinese_1723204_872:
    old "Besides, I still have to do a couple of edits on them."
    new "再说，我还要对它们做几处修改。"

translate chinese chinese_4384341_873:
    old "When I'm done they're going to look even better."
    new "等我弄完，她们会看起来更好。"

translate chinese chinese_8379424_874:
    old "What? There's no way this is just because of me taking the pictures!"
    new "什么？这不可能只是因为我拍了照片吧！"

translate chinese chinese_2470234_875:
    old "These pictures are because of how beautiful you are."
    new "这些照片是因为你太漂亮了。"

translate chinese chinese_9887750_876:
    old "After all the only thing I'm doing is just taking the pictures."
    new "毕竟我做的只是拍照而已。"

translate chinese chinese_7329115_877:
    old "You're the one that's posing."
    new "你才是摆姿势的那个。"

translate chinese chinese_2900068_878:
    old "And if they come up any good, is just because of how well you posed."
    new "而且如果它们看起来不错，那只是因为你摆姿势摆得很好。"

translate chinese chinese_2373229_879:
    old "Woah, woah, w- what are you doing Barbie?"
    new "喂喂，巴比，你在干什么？"

translate chinese chinese_3702963_880:
    old "B- but..."
    new "B-但是..."

translate chinese chinese_6848796_881:
    old "Alright, so I'll send the pictures to my contact today. And she'll let me know if she can get the interview for you."
    new "好吧，我今天就把照片发给我的联系人。她会告诉我是否能为你安排采访。"

translate chinese chinese_6664690_882:
    old "It will probably not be something big, at least not to start with."
    new "这可能不会是什么大事，至少一开始不会。"

translate chinese chinese_3249886_883:
    old "But I think that it might be a good starting point for you."
    new "但我觉得这可能是你一个好的起点。"

translate chinese chinese_6328168_884:
    old "Yeah, I have to get to it now."
    new "嗯，我现在得去处理了。"

translate chinese chinese_0424611_885:
    old "But as soon as the pictures are done I'll hand them over to my contact."
    new "但是照片一拍完我就交给我的联系人。"

translate chinese chinese_4926985_886:
    old "And when I get an answer I'll let you know."
    new "等我得到答复再告诉你。"

translate chinese chinese_1107882_887:
    old "Hey [sis], good morning, how are you?"
    new "嘿[sis]，早上好，你怎么样？"

translate chinese chinese_1007969_888:
    old "I'm doing great, and you?"
    new "我很好，你呢？"

translate chinese chinese_1982112_889:
    old "I'm ok, thank you."
    new "我挺好的，谢谢。"

translate chinese chinese_5372172_890:
    old "Hey, listen, about the favor that I asked you last time."
    new "嘿，听我说，上次我拜托你的那件事。"

translate chinese chinese_8370884_891:
    old "Oh yeah, your little plastic girl's pictures."
    new "哦对了，你那些小塑料女友的照片。"

translate chinese chinese_9743419_892:
    old "I send them over to a friend of mine that works for another clothing business."
    new "我把它们寄给了我一个在另一家服装公司工作的朋友。"

translate chinese chinese_4448434_893:
    old "Their clothes are more like the type of thing that that idiot would wear."
    new "他们的衣服更像是那个白痴会穿的那种。"

translate chinese chinese_4216650_894:
    old "And what did they say?"
    new "他们说了什么？"

translate chinese chinese_0127322_895:
    old "When do they want to meet her?"
    new "他们想什么时候见她？"

translate chinese chinese_2417935_896:
    old "In a couple of days."
    new "过几天吧。"

translate chinese chinese_8100736_897:
    old "I'll send you the info."
    new "我会把信息发给你。"

translate chinese chinese_6073593_898:
    old "And don't worry, I talked with them."
    new "放心，我跟他们谈过了。"

translate chinese chinese_3889211_899:
    old "They said that if they hire her they'll be sure to give us our cut."
    new "他们说如果雇用她，一定会给我们分成的。"

translate chinese chinese_5203815_900:
    old "I see... That's great."
    new "我明白了……那很好。"

translate chinese chinese_6315110_901:
    old "Alright, I'll have to tell her about this."
    new "好吧，我得把这个告诉她。"

translate chinese chinese_8291524_902:
    old "Thanks a lot [sis]."
    new "多谢了[sis]。"

translate chinese chinese_3335912_903:
    old "Remember to tell your little friend that she has to be there on time."
    new "记得提醒你的小朋友准时到场。"

translate chinese chinese_6182464_904:
    old "I don't want her to make me look bad by getting there late or anything."
    new "我不希望她因为我迟到或其他什么事让我难堪。"

translate chinese chinese_8251194_905:
    old "Is that clear?"
    new "清楚了吗？"

translate chinese chinese_9728215_906:
    old "Yeah, yeah, it is."
    new "嗯嗯，是的。"

translate chinese chinese_7397394_907:
    old "Good."
    new "好。"

translate chinese chinese_3807717_908:
    old "Yeah.. I'll see you later then."
    new "嗯……那回头见吧。"

translate chinese chinese_6118289_909:
    old "Bye [sis], thanks for the help."
    new "再见[sis]，谢谢你的帮助。"

translate chinese chinese_1685188_910:
    old "I'm good, and listen I have some great news!"
    new "我挺好的，而且听我说，有个好消息！"

translate chinese chinese_2820210_911:
    old "That contact I told you about got an interview for you!"
    new "我跟你说的那个联系人给你安排了面试！"

translate chinese chinese_7407137_912:
    old "Yeah, it's to apply for a position as a model for a clothing brand that works mainly online."
    new "嗯，是申请一个主要在线工作的服装品牌的模特职位。"

translate chinese chinese_9051079_913:
    old "It's not the biggest job in the world but..."
    new "这工作也不是什么大不了的……但……"

translate chinese chinese_6979028_914:
    old "It's my pleasure."
    new "这是我的荣幸。"

translate chinese chinese_9495390_915:
    old "I'm happy to be able to help you."
    new "我很高兴能帮你。"

translate chinese chinese_9787075_916:
    old "I'll send you the details, don't forget to go, alright?'"
    new "详情我发给你，别忘了去啊。"

translate chinese chinese_9272746_917:
    old "Hey, don't thank me yet. Let's wait until you get the job."
    new "嘿，别急着谢我。等你拿到这份工作再说吧。"

translate chinese chinese_1858216_918:
    old "I'll come by later to see how everything went, alright?"
    new "我晚点过来看看事情怎么样了，好吗？"

translate chinese chinese_1398767_919:
    old "You're taking too long, how many more times are you going to see this woman?"
    new "你花的时间太长了，你还打算见这个女人几次？"

translate chinese chinese_0765451_920:
    old "I already told you. Until I'm done helping her with everything I promised I would do."
    new "我早就告诉过你了。在我把她答应要帮她的所有事情都做完之前。"

translate chinese chinese_1206150_921:
    old "What are you doing here anyway?"
    new "你在这里干什么呢？"

translate chinese chinese_6457485_922:
    old "I thought I told you, you take too long."
    new "我以为我告诉过你，你动作太慢了。"

translate chinese chinese_5911021_923:
    old "So, I came to help you deal with this quickly."
    new "所以，我来帮你快速解决这个问题。"

translate chinese chinese_9338448_924:
    old "Ok, thank you I guess."
    new "好吧，我猜谢谢你了。"

translate chinese chinese_3900873_925:
    old "But I think everything's going to go well, you know?"
    new "但是我觉得一切都会顺利的，你知道吧？"

translate chinese chinese_2325241_926:
    old "Since I got her the interview, I'm sure that went well, and now she has good news."
    new "既然我帮她安排了面试，肯定进展顺利，现在她应该有好消息。"

translate chinese chinese_1147290_927:
    old "But let's go and talk to her."
    new "但是我们去和她聊聊吧。"

translate chinese chinese_4464069_928:
    old "Hey Barbie, good morning."
    new "嘿，芭比，早上好。"

translate chinese chinese_7579414_929:
    old "W- what's wrong Barbie?"
    new "巴比，你怎么了？"

translate chinese chinese_2588175_930:
    old "It didn't go well?"
    new "没搞好？"

translate chinese chinese_2566653_931:
    old "What happened?"
    new "发生了什么？"

translate chinese chinese_7943170_932:
    old "S- sure, no problem."
    new "好 sure, 没问题。"

translate chinese chinese_0077129_933:
    old "I'll see you later then."
    new "那回头见吧。"

translate chinese chinese_6286041_934:
    old "Ok, so now will you tell me about what happened?"
    new "好吧，那你现在会告诉我发生了什么吗？"

translate chinese chinese_3101543_935:
    old "How did the interview go?"
    new "面试怎么样？"

translate chinese chinese_5305283_936:
    old "Ok, that's good to hear."
    new "好的，听到这个很高兴。"

translate chinese chinese_2244395_937:
    old "But then what went wrong?"
    new "那后来哪里出了问题？"

translate chinese chinese_7615219_938:
    old "So, did he say anything to you about that?"
    new "所以，他有没有跟你说过这件事？"

translate chinese chinese_6866665_939:
    old "What the hell? Who does he think he is?!"
    new "怎么回事？他到底觉得自己是谁？！"

translate chinese chinese_8605726_940:
    old "I'm sorry Barbie, I had no idea things would turn out that way."
    new "对不起芭比，我没想到会变成这样。"

translate chinese chinese_2988156_941:
    old "I didn't expect that."
    new "没想到会这样。"

translate chinese chinese_1653332_942:
    old "But I'll get you another interview in a better place."
    new "但我可以在更好的地方给你另一次采访。"

translate chinese chinese_8889296_943:
    old "And I'll make sure that this doesn't happen again."
    new "我会确保这种事情不会再发生。"

translate chinese chinese_2214448_944:
    old "W- wait!"
    new "等一下！"

translate chinese chinese_8043540_945:
    old "I get it, you've had a bad streak with the auditions and interviews."
    new "我明白，你最近试镜和面试都不太顺利。"

translate chinese chinese_3495889_946:
    old "But that doesn't mean that you should give up."
    new "但这不意味着你应该放弃。"

translate chinese chinese_2172405_947:
    old "Don't let a couple of bad experiences rob you of your dream."
    new "不要让几次不好的经历夺走你的梦想。"

translate chinese chinese_3716202_948:
    old "D- do you want to talk about it?"
    new "你……你想谈谈这个吗？"

translate chinese chinese_5153397_949:
    old "Listen Barbie, what you have been going through with these... Bad experiences."
    new "听着芭比，你经历的这些...糟糕的经历。"

translate chinese chinese_8895732_950:
    old "I can't imagine how frustrating it must be."
    new "我简直无法想象那有多令人沮丧。"

translate chinese chinese_0823044_951:
    old "Especially if there are things from your past that are related to this. I think that causes you a lot of pain."
    new "特别是如果你过去的事情和这有关。我觉得这给你带来了很大的痛苦。"

translate chinese chinese_7091027_952:
    old "I understand, and that's fair."
    new "我明白，这样也挺公平的。"

translate chinese chinese_6250535_953:
    old "But I also think you still shouldn't give up on your dream of becoming a star Barbie."
    new "但是我也认为你不应该放弃成为明星芭比的梦想。"

translate chinese chinese_4424024_954:
    old "I've seen your passion for it. And I know how much of a hard worker you are."
    new "我看到了你对它的热情。我知道你有多努力。"

translate chinese chinese_0886533_955:
    old "If someone deserves a shot at something like that, it's you."
    new "如果有人值得尝试那样的事情，那就应该是你。"

translate chinese chinese_8629204_956:
    old "Hmm, I see..."
    new "嗯，我明白了……"

translate chinese chinese_5185890_957:
    old "Listen, you already told me that something's troubling you."
    new "听着，你已经告诉我有些事情困扰着你。"

translate chinese chinese_3660328_958:
    old "But you told me you don't want to talk about it."
    new "但是你告诉我你不想谈这个。"

translate chinese chinese_2617441_959:
    old "Which I understand."
    new "我明白。"

translate chinese chinese_3028865_960:
    old "But I think you should talk about it."
    new "但我觉得你应该说出来。"

translate chinese chinese_1586678_961:
    old "Maybe opening up about it would do you well."
    new "maybe 打开心扉对你有好处。"

translate chinese chinese_7385733_962:
    old "I get it, it must be a painful memory, but you know, there's nothing to be afraid of."
    new "我明白，那肯定是个痛苦的回忆，但你知道，没什么好怕的。"

translate chinese chinese_2674214_963:
    old "You can trust me with anything you want to share."
    new "你可以把任何想分享的事情都告诉我。"

translate chinese chinese_8792595_964:
    old "No matter what it is, I want to support you and make sure that you feel safe and happy."
    new "不管是什么，我都想支持你，确保你感到安全和快乐。"

translate chinese chinese_1066031_965:
    old "I mean it Barbie, whatever it is."
    new "我是认真的，芭比，不管是什么。"

translate chinese chinese_8167630_966:
    old "That makes sense, but I'll be more than happy to listen to what you have to say."
    new "有道理，但我很乐意听听你的想法。"

translate chinese chinese_9781069_967:
    old "To listen to you."
    new "听你说。"

translate chinese chinese_9041731_968:
    old "Maybe talking about it you can get rid of some of that pain, you know?"
    new "maybe 谈谈也许能减轻一些痛苦，你知道吗？"

translate chinese chinese_8048610_969:
    old "And... W- what happened?"
    new "然后……发生什么了？"

translate chinese chinese_6760912_970:
    old "Listen Barbie, I know that what happened in your past was very painful."
    new "听着，芭比，我知道你过去的经历非常痛苦。"

translate chinese chinese_1928247_971:
    old "And that we can't go back and changed it."
    new "而且我们无法回去改变它。"

translate chinese chinese_2754945_972:
    old "But I don't think you're wrong for chasing your dreams."
    new "但是我觉得你追梦是没有错的。"

translate chinese chinese_5777041_973:
    old "Or that you have made any mistakes by choosing to chase your dreams."
    new "或者因为你选择追逐梦想而犯了任何错误。"

translate chinese chinese_8857612_974:
    old "Yes it's true that you've been unlucky with how things have gone in the past."
    new "没错，你过去确实运气不好。"

translate chinese chinese_0463691_975:
    old "But I believe you still have a lot of chances for things to go your way."
    new "但我相信你还有很多机会让事情如你所愿。"

translate chinese chinese_7954763_976:
    old "You're a beautiful and hard-working woman."
    new "你是一个美丽又能干的女人。"

translate chinese chinese_4813574_977:
    old "I'm sure if you keep trying, sooner or later you'll someday meet someone that will be different from the rest."
    new "我相信如果你一直努力下去，早晚会遇到一个和别人不同的特别的人。"

translate chinese chinese_1613002_978:
    old "Of course you will!"
    new "当然会啊！"

translate chinese chinese_2370218_979:
    old "You're diligent and capable."
    new "你既勤奋又能干。"

translate chinese chinese_8752651_980:
    old "And I'm completely sure that you will find very good fortune."
    new "而且我完全确信你会找到非常好的运气。"

translate chinese chinese_9631342_981:
    old "As I told you, if someone deserves good things coming their way, that is you."
    new "就像我告诉你的，如果有人值得拥有好东西，那就是你。"

translate chinese chinese_8763202_982:
    old "So, if you'll believe me, I would like to help you keep working towards achieving your dream."
    new "所以，如果你相信我的话，我想帮助你继续朝着实现梦想的目标前进。"

translate chinese chinese_6300451_983:
    old "I'm just happy that I get to be here for you Barbie."
    new "我 just 很高兴能在这里陪你看 Barbie。  \n\n（注：这里的 \"Barbie\" 如果是人名或特定角色名，则保留不变；如果是其他含义，请进一步说明。）"

translate chinese chinese_4602853_984:
    old "About the other things, I'm just saying the truth every time we talk."
    new "至于其他的事情，每次说话我都只是说真话。"

translate chinese chinese_4588431_985:
    old "You're a capable and talented person."
    new "你是一个有能力又有才华的人。"

translate chinese chinese_0886809_986:
    old "I- I'll do my best."
    new "我我会尽力的。"

translate chinese chinese_8490185_987:
    old "Really, the next one will be better."
    new "真的，下一个会更好的。"

translate chinese chinese_7304783_988:
    old "I'm sure of it Barbie."
    new "我确定，芭比。"

translate chinese chinese_3431589_989:
    old "I'm glad you feel that way."
    new "很高兴你这么觉得。"

translate chinese chinese_2939216_990:
    old "Even though there have been a couple of inconveniences."
    new "虽然有些小麻烦。"

translate chinese chinese_0939939_991:
    old "But I'm sure we'll get you a job that's good enough for you."
    new "但我相信我们会给你找一个足够好的工作。"

translate chinese chinese_0117674_992:
    old "U- Uh, I- I mean."
    new "uh, 我——我是说。"

translate chinese chinese_2265582_993:
    old "Uh, s- sure, see you later."
    new "呃，好，回头见。"

translate chinese chinese_6001489_994:
    old "Hey [pla], good morning."
    new "嘿[pla]，早上好。"

translate chinese chinese_6505056_995:
    old "Hey [sis], good morning."
    new "嘿[sis]，早上好。"

translate chinese chinese_2858021_996:
    old "How are you today?"
    new "你今天怎么样？"

translate chinese chinese_9312146_997:
    old "I'm doing fine, but there's something we have to talk about."
    new "我挺好的，但有些事我们必须谈谈。"

translate chinese chinese_4522026_998:
    old "What is it?"
    new "怎么了？"

translate chinese chinese_1215603_999:
    old "Well, I don't know the full details."
    new "嗯，我还不清楚全部细节。"

translate chinese chinese_4213705_1000:
    old "But as Barbie told me, the guy who interviewed her for the modeling job tried to sleep with her."
    new "但正如芭比告诉我的，面试她那个模特工作的家伙试图跟她上床。"

translate chinese chinese_1187723_1001:
    old "Yeah, he did. Apparently, he told her that there were a lot of good candidates for that job."
    new "是的，他那样说了。据说他告诉她那个职位有很多好的候选人。"

translate chinese chinese_5675486_1002:
    old "So if she wanted the job, she would have to give him a {i}'payment'{/i} for it."
    new "所以如果她想要这份工作，就必须给他一个{i}“报酬”{/i}。"

translate chinese chinese_4345141_1003:
    old "That pig!"
    new "那猪猡！"

translate chinese chinese_9638308_1004:
    old "I mean what the fuck! What's wrong with him?!"
    new "我是说靠！他到底怎么了?!"

translate chinese chinese_6254614_1005:
    old "What a disgusting thing."
    new "真恶心。"

translate chinese chinese_6719613_1006:
    old "Can you believe that bastard was trying to get me to model some clothes for his brand?"
    new "你能相信那个混蛋竟然想让我给他品牌当模特吗？"

translate chinese chinese_2949383_1007:
    old "But I hadn't had the time to do it."
    new "但我还没来得及做。"

translate chinese chinese_3082621_1008:
    old "That means that if I had been available he would probably have tried the same thing with me!"
    new "那也就是说，如果我当时有空，他可能会对我做同样的事！"

translate chinese chinese_8468266_1009:
    old "And he had the gall to try and pull that with her?!"
    new "他还敢对她这么做？！"

translate chinese chinese_1131146_1010:
    old "Sure, he probably realized that she needed that opportunity and decided to take advantage."
    new "当然，他可能意识到她需要这个机会，于是决定趁机利用一下。"

translate chinese chinese_8880884_1011:
    old "What a fucking coward!"
    new "真他娘的胆小鬼！"

translate chinese chinese_4413436_1012:
    old "Uhm... Yeah."
    new "嗯……是的。"

translate chinese chinese_6065924_1013:
    old "But don't worry [pla], I'm not going to let things stay like this."
    new "但是别担心[pla]，我不会让事情变成这样的。"

translate chinese chinese_0936320_1014:
    old "I'm actually in contact with a couple of brands that are working with that guy."
    new "我实际上联系过几个和那个家伙合作的品牌。"

translate chinese chinese_5277110_1015:
    old "But they won't be after I tell them what happened."
    new "但在我告诉他们发生了什么之后就不会了。"

translate chinese chinese_6708139_1016:
    old "I'll make everyone knows what that bastard tried to do."
    new "我会让大家都知道那个混蛋想干什么。"

translate chinese chinese_6694838_1017:
    old "That way that pig will learn how to treat women!"
    new "这样那只猪就能学会怎么对待女人了！"

translate chinese chinese_3483684_1018:
    old "Uh- I- I see."
    new "哦——我——我明白了。"

translate chinese chinese_4943490_1019:
    old "Tell Barbie sorry on my behalf."
    new "代我跟芭比说声对不起。"

translate chinese chinese_0379984_1020:
    old "I may not like her too much, but I would have never knowingly sent her to a place like that."
    new "我虽然不太喜欢她，但绝不会故意把她送到那种地方去。"

translate chinese chinese_6364924_1021:
    old "And of course, I'll make her up for it."
    new "当然了，我会补偿她的。"

translate chinese chinese_1358402_1022:
    old "So don't worry, I'll get her another interview."
    new "所以不用担心，我会给她另找一个面试机会的。"

translate chinese chinese_0519440_1023:
    old "And I'll make sure that this time is with a reputable place."
    new "这次我会确保找一个信誉好的地方。"

translate chinese chinese_4591382_1024:
    old "That sounds great [sis], thank you!"
    new "听起来很棒 [sis]，谢谢你！"

translate chinese chinese_3000762_1025:
    old "Now, I'll talk to you later."
    new "好了，我待会儿再跟你聊。"

translate chinese chinese_3220437_1026:
    old "I have a couple of calls to make."
    new "我有几个电话要打。"

translate chinese chinese_3464669_1027:
    old "Uh- S- sure, see you later."
    new "呃——好，回头见。"

translate chinese chinese_8733978_1028:
    old "Good news, I brought something for you."
    new "好消息，我给你带了点东西。"

translate chinese chinese_4731486_1029:
    old "Oh really? How come?"
    new "哦真的吗？为什么呢？"

translate chinese chinese_6732440_1030:
    old "Well, I got another interview for Barbie."
    new "嗯，我又给芭比安排了一次面试。"

translate chinese chinese_3388698_1031:
    old "That's great [sis]! Thank you."
    new "太好了，[sis]！谢谢。"

translate chinese chinese_0354044_1032:
    old "Don't worry about it. I'm happy to help her."
    new "别担心，我很乐意帮她。"

translate chinese chinese_6999838_1033:
    old "And this time I made sure that the place where I'm sending her is quite reputable."
    new "而且这次我确保把她送到的地方相当有信誉。"

translate chinese chinese_1187578_1034:
    old "So you can be sure that nothing like what happened last time will happen again."
    new "所以你可以放心，上次发生的事情绝不会再发生了。"

translate chinese chinese_2273899_1035:
    old "That's awesome [sis]!"
    new "太棒了，[sis]！"

translate chinese chinese_1707408_1036:
    old "So, what you have in the box is related to that?"
    new "所以，你盒子里的东西和那个有关吗？"

translate chinese chinese_6992564_1037:
    old "It is."
    new "是的。"

translate chinese chinese_1048856_1038:
    old "The place where Barbie's going is a lingerie company."
    new "芭比要去的地方是一家内衣公司。"

translate chinese chinese_9463000_1039:
    old "So, when I send them the pictures you had given me of Barbie, they thought she looked very good."
    new "所以，当我把巴比的照片发给他们时，他们觉得她看起来很好。"

translate chinese chinese_7889263_1040:
    old "But they said they wanted to see her posing in some lingerie or underwear."
    new "但他们说想看她穿比基尼或内衣的样子。"

translate chinese chinese_4634086_1041:
    old "And I imagine you don't have a portfolio of pictures of her in lingerie, right?"
    new "而且我猜你没有她的内衣写真集吧？"

translate chinese chinese_5922190_1042:
    old "Uh- n- no, I don't"
    new "呃——不，我不"

translate chinese chinese_7732769_1043:
    old "Well, that's why I took the liberty of getting some new lingerie that would fit her. You know, for you to take some pictures."
    new "好吧，所以我自作主张给她买了一些新的内衣，你知道的，为了你拍照用。"

translate chinese chinese_8362075_1044:
    old "Oh wow [sis], t- that's awesome!"
    new "哦 wow [sis], 这-这个太棒了！"

translate chinese chinese_2352808_1045:
    old "Well, I think it was the least I could do. You know?"
    new "嗯，我觉得这是我起码应该做的。你知道吧？"

translate chinese chinese_1377561_1046:
    old "So, take this. And talk to her to take the pictures as soon as you can."
    new "所以，把这个拿上。然后尽快和她谈谈拍些照片。"

translate chinese chinese_6028894_1047:
    old "Alright, I'll talk to her as soon as I can."
    new "好吧，我一有机会就和她谈谈。"

translate chinese chinese_9245115_1048:
    old "Alright. I'll be waiting for the pictures then."
    new "好吧，那我就等着照片了。"

translate chinese chinese_9796097_1049:
    old "By the way, you haven't forgotten about my 10 percent right?"
    new "对了，你还没忘了我的百分之十吧？"

translate chinese chinese_5502687_1050:
    old "No, no, I got you."
    new "不用了，我明白。"

translate chinese chinese_6533536_1051:
    old "Alright, I'll see you later then."
    new "好吧，那回头见。"

translate chinese chinese_3163066_1052:
    old "Sure, Bye."
    new "行吧，再见。"

translate chinese chinese_9824385_1053:
    old "I'm fine."
    new "我没事。"

translate chinese chinese_4281924_1054:
    old "Actually I'm more than fine, I just got some good news."
    new "其实我挺好的，刚收到了一些好消息。"

translate chinese chinese_7411295_1055:
    old "That contact I told you about got you an interview!"
    new "我跟你说的那个关系给你弄到了面试机会！"

translate chinese chinese_6750679_1056:
    old "And don't worry, this time she ensured me that what happened last time wouldn't happen again."
    new "而且不用担心，这次她保证上次发生的事情不会再发生了。"

translate chinese chinese_8560246_1057:
    old "Well, that's the thing, before they interview you. They said they would like to see a couple of pictures of you."
    new "好吧，关键是，在他们面试你之前，他们说想看你几张照片。"

translate chinese chinese_9131146_1058:
    old "Yeah, and they really liked them."
    new "是的，他们真的很喜欢。"

translate chinese chinese_3695330_1059:
    old "But you see, this new place is a lingerie retailer."
    new "但是你看，这家新店是一家内衣零售商。"

translate chinese chinese_1094460_1060:
    old "So they said they'd be interested in seeing how you look in lingerie before you go."
    new "他们说在你走之前想看看你穿情趣内衣的样子。"

translate chinese chinese_6536114_1061:
    old "So, my contact got some lingerie for you to try."
    new "所以，我的线人给你准备了一些内衣试试。"

translate chinese chinese_8034712_1062:
    old "I was thinking that maybe after you're done with your shift you'd like to come with me to my house and you can try it on."
    new "我想你下班后，要不要来我家试试看？"

translate chinese chinese_2697182_1063:
    old "Great, then I'll wait until your shift is over and then we can come back to my house."
    new "好的，那我就等到你下班，然后我们可以回我家。"

translate chinese chinese_2384609_1064:
    old "Alright, let's go then."
    new "好吧，那我们走吧。"

translate chinese chinese_9347425_1065:
    old "Alright, this is the lingerie, why don't you change into it? And we'll do the pictures."
    new "好了，这是内衣，为什么不换上呢？然后我们就拍照。"

translate chinese chinese_1515328_1066:
    old "S- sorry, is not that I don't like it, I was just surprised because of how beautiful you look."
    new "对不起，不是我不喜欢，我只是被你美丽的外表惊到了。"

translate chinese chinese_2843805_1067:
    old "That lingerie looks very good on you."
    new "那套内衣穿在你身上很好看。"

translate chinese chinese_1197507_1068:
    old "What? Of course not!"
    new "什么？当然不是！"

translate chinese chinese_4408970_1069:
    old "You look just perfect!"
    new "你看起来完美极了！"

translate chinese chinese_3749342_1070:
    old "You look very beautiful, I mean it."
    new "你看起来非常漂亮，我是真心的。"

translate chinese chinese_5308220_1071:
    old "Why? You don't think the same?"
    new "为什么？你不这么认为吗？"

translate chinese chinese_0719965_1072:
    old "You know, if you don't feel alright about this we don't have to do it."
    new "你知道，如果你觉得不舒服，我们可以不这么做。"

translate chinese chinese_2114310_1073:
    old "Come on, no one's going to think that."
    new "别这样，没人会那么想的。"

translate chinese chinese_4225913_1074:
    old "You are one of the most beautiful girls I know  Barbie."
    new "你是我知道的最美丽的女孩之一，芭比。"

translate chinese chinese_9493646_1075:
    old "I'm sure that as soon as they see you they'll want to hire you."
    new "我相信他们一看见你就会想雇用你。"

translate chinese chinese_9967057_1076:
    old "Of course I do."
    new "我当然有。"

translate chinese chinese_6723790_1077:
    old "Ok, the first picture is just going to be you standing there normally."
    new "好的，第一张照片你就正常站在那里就行了。"

translate chinese chinese_8986101_1078:
    old "So don't move while I take the picture."
    new "所以我在拍照的时候不要动。"

translate chinese chinese_5630225_1079:
    old "Alright, that was good."
    new "好吧，那挺不错的。"

translate chinese chinese_1213194_1080:
    old "So, for the second picture, how about you lay on your right side."
    new "那么，第二张照片，你侧躺在右边怎么样？"

translate chinese chinese_5714919_1081:
    old "Open your body a little bit, and put your left leg up."
    new "把身体打开一点，左腿抬起来。"

translate chinese chinese_2166631_1082:
    old "Then rest your left hand on your hip, and lift your torso up a little using your right arm."
    new "然后左手叉腰，用右手把上身撑起来一点。"

translate chinese chinese_0339139_1083:
    old "That's it, perfect!"
    new "就是这个，完美！"

translate chinese chinese_6581193_1084:
    old "I do, you look wonderful"
    new "我看得出来，你真漂亮"

translate chinese chinese_9798464_1085:
    old "Alright, for the next one."
    new "好吧，下一个。"

translate chinese chinese_7675651_1086:
    old "How about we show a little bit of how you look from behind?"
    new "要不展示一下你的背面身材如何？"

translate chinese chinese_3448705_1087:
    old "Great, kneel with your back towards  me."
    new "好的，跪下来，背对着我。"

translate chinese chinese_8507621_1088:
    old "While you rest your forearms on the bed."
    new "当你把手臂放在床上的时候。"

translate chinese chinese_7580933_1089:
    old "And turn your head over your right shoulder while you look at me."
    new "同时把头转向右肩看着我。"

translate chinese chinese_9316900_1090:
    old "That's it! Perfect!"
    new "就是这个！完美！"

translate chinese chinese_5234413_1091:
    old "That's great Barbie!"
    new "太棒了，芭比！"

translate chinese chinese_6222357_1092:
    old "You look great Barbie!"
    new "你看起来很棒，芭比！"

translate chinese chinese_7639221_1093:
    old "{i}(Dang, she really does look amazing.){/i}"
    new "{i}(天啊，她真的好美。){/i}"

translate chinese chinese_4335524_1094:
    old "{i}(I can't believe she thought she wouldn't look good using the lingerie.){/i}"
    new "{i}(真不敢相信她以为自己穿这种内衣不会好看。){/i}"

translate chinese chinese_2131332_1095:
    old "{i}(Damn it! Why do I have to get a boner now?){/i}"
    new "{i}(该死！为什么我现在会硬起来？){/i}"

translate chinese chinese_1420702_1096:
    old "{i}(I think she hasn't noticed yet. Let's just finish this before she notices it.){/i}"
    new "{i}（我觉得她还没发现。还是在她发现之前搞定这件事吧。){/i}"

translate chinese chinese_6995092_1097:
    old "Alright, I think that's it."
    new "好了，我想就这些了。"

translate chinese chinese_5814885_1098:
    old "W- why don't you go change while I put the camera away?"
    new "你…你先去换衣服，我来收相机怎么样？"

translate chinese chinese_8979146_1099:
    old "Uhh... w- well, y- you know."
    new "呃……那个……你知道的。"

translate chinese chinese_4808965_1100:
    old "W- what are you doing?"
    new "你、你在干什么？"

translate chinese chinese_6912926_1101:
    old "Uhh, I- I'm glad you liked it."
    new "呃，我——我很高兴你喜欢。"

translate chinese chinese_1571580_1102:
    old "I'll let you know what they say about the pictures, alright?"
    new "我会告诉你他们对那些照片怎么说的，好吗？"

translate chinese chinese_4303081_1103:
    old "Why are you waking me up at this time?"
    new "你为什么在这个时候叫我起床？"

translate chinese chinese_0516875_1104:
    old "Well, I have something to tell you."
    new "嗯，我有件事要告诉你。"

translate chinese chinese_0608930_1105:
    old "Great news! The process of implantation of the magic power within Barbie is complete!"
    new "好消息！芭比体内的魔力植入过程已经完成了！"

translate chinese chinese_3463078_1106:
    old "So we can now move into the next objective!"
    new "那我们现在可以进入下一个目标了！"

translate chinese chinese_5788015_1107:
    old "Implantation of the magic power? What do you mean?"
    new "魔力量植入？你是说什么意思？"

translate chinese chinese_5571331_1108:
    old "Ugh, I see that you forgot about what we were trying to do here."
    new "唉，看来你忘了我们在这里要做什么了。"

translate chinese chinese_0358320_1109:
    old "Did you forget that we're trying to get you to implant magic power into different women."
    new "你不会忘了我们现在正想办法让你把魔力植入不同的女人身上吧。"

translate chinese chinese_1243047_1110:
    old "So that they can cultivate the magic power within their bodies?"
    new "这样就能修炼体内的魔力了？"

translate chinese chinese_3133990_1111:
    old "Hmm... Yeah, right."
    new "嗯……是吗。"

translate chinese chinese_8472539_1112:
    old "According to what you told me last time."
    new "根据你上次告诉我的。"

translate chinese chinese_0723809_1113:
    old "Does that mean that she's pregnant now?!"
    new "那是不是意味着她怀孕了?!"

translate chinese chinese_5803742_1114:
    old "Hmph, I guess that from your point of view that's how it looks."
    new "哼，从你的角度看，可能就是那样。"

translate chinese chinese_7961649_1115:
    old "But not really."
    new "但也不是真的。"

translate chinese chinese_5469204_1116:
    old "She'll just look and feel as if she is, but she's not pregnant."
    new "她只是看起来和感觉像是怀孕了，但实际上并没有怀孕。"

translate chinese chinese_2044944_1117:
    old "So you don't have to worry, when we're done with the spell we'll just collect the power."
    new "所以你不用担心，完成咒语后我们就收集力量就行了。"

translate chinese chinese_4077320_1118:
    old "And she'll just go back to normal."
    new "然后她就会恢复正常。"

translate chinese chinese_7268476_1119:
    old "When we're done with the spell?!"
    new "我们把咒语弄完再说！"

translate chinese chinese_1522755_1120:
    old "So until we're not done with it she'll be pregnant?"
    new "所以直到这件事完成之前，她都会怀孕状态？"

translate chinese chinese_9432274_1121:
    old "That's not okay!"
    new "那可不行！"

translate chinese chinese_9004516_1122:
    old "She just barely got a chance to work."
    new "她刚刚才有个工作的机会。"

translate chinese chinese_3998344_1123:
    old "And if she's pregnant she won't even be able to work."
    new "而且如果她怀孕了，甚至没法工作。"

translate chinese chinese_5056341_1124:
    old "You'll have to reverse it."
    new "你得把它反过来。"

translate chinese chinese_1010853_1125:
    old "Reverse it?! Are you crazy?"
    new "反转？！你疯了吗？"

translate chinese chinese_7313964_1126:
    old "With all of the time and magic power that has gone into it?!"
    new "花了那么多时间和魔力？！"

translate chinese chinese_2753927_1127:
    old "How can you even say such a thing?"
    new "你怎么能这么说？"

translate chinese chinese_8081281_1128:
    old "Because, as I told you! She can't be pregnant!"
    new "因为，就像我告诉你的！她不可能怀孕！"

translate chinese chinese_1400002_1129:
    old "I understand that you want me to hurry up with the ritual."
    new "我明白你希望我赶紧完成这个仪式。"

translate chinese chinese_9502130_1130:
    old "And I promise you that if you do it I'll make sure to do what you need me to for the ritual to go well."
    new "我向你保证，如果你这么做了，我会确保在仪式中做你需要我做的事情。"

translate chinese chinese_2204381_1131:
    old "Ugh, you're so difficult to handle [pla]."
    new "哎，你真难搞，[pla]。"

translate chinese chinese_9099374_1132:
    old "Fine, I'll do it."
    new "好吧，我来做。"

translate chinese chinese_4716989_1133:
    old "But I want you to start working on the next target right away!"
    new "但我想要你马上开始着手下一个目标！"

translate chinese chinese_3337906_1134:
    old "Sure... But just let me finish what I have to do with Barbie."
    new "好吧……但让我先和芭比把事情搞定。"

translate chinese chinese_8246317_1135:
    old "I just have to finish a couple of things with her, and I'll get into working in the person."
    new "我只要再和她处理几件事，就能正式开始工作了。"

translate chinese chinese_8151922_1136:
    old "{b}*Sigh*{/b}."
    new "{b}*叹气*{/b}."

translate chinese chinese_9687368_1137:
    old "Alright, but remember what you promised me [pla]."
    new "好吧，但别忘了你答应我的事情[pla]。"

translate chinese chinese_5242891_1138:
    old "Sure, sure..."
    new "好吧，好吧……"

translate chinese chinese_2980665_1139:
    old "I'm okay, but I imagine that not as well as you will."
    new "我还可以，但肯定没有你想象的那么好。"

translate chinese chinese_3410572_1140:
    old "You bet!"
    new "当然了！"

translate chinese chinese_2801904_1141:
    old "I just got a text from the person who got you the interview for the modeling gig."
    new "刚才有个短信，是介绍你去面试模特工作的那个人发的。"

translate chinese chinese_5193133_1142:
    old "They said that they loved the pictures, and how you look with the lingerie on!"
    new "他们说他们喜欢那些照片，还有你穿内衣的样子！"

translate chinese chinese_2188281_1143:
    old "They said they wanted to meet with you to discuss hiring you as their model!"
    new "他们说想见你，讨论聘请你当他们的模特的事！"

translate chinese chinese_5224371_1144:
    old "Haha, I'm glad this makes you happy."
    new "哈哈，看到你开心我也高兴。"

translate chinese chinese_9837185_1145:
    old "Oh no, it isn't."
    new "哦不，不是那样的。"

translate chinese chinese_4208196_1146:
    old "I've only made a couple of phone calls."
    new "我只打了几个电话而已。"

translate chinese chinese_5877331_1147:
    old "This is because of your effort."
    new "这是你的努力的结果。"

translate chinese chinese_5718814_1148:
    old "Although don't forget you still have to go to the interview."
    new "虽然别忘了你还要去面试。"

translate chinese chinese_7436140_1149:
    old "But I'm sure everything's going to go well."
    new "但我肯定一切都会顺利的。"

translate chinese chinese_4830614_1150:
    old "W- w- what are you doing Barbie?"
    new "你你在干什么，芭比？"

translate chinese chinese_9444603_1151:
    old "Y- you can't do that here!"
    new "你、你不能在这里这么做！"

translate chinese chinese_5196345_1152:
    old "B- but, t- there are cameras!"
    new "我、我可是，这里有摄像头！"

translate chinese chinese_6301751_1153:
    old "O- or someone could walk through here!"
    new "O-或者有人会从这里经过！"

translate chinese chinese_3506888_1154:
    old "I can't believe you actually did that!"
    new "真不敢相信你真的做了那件事！"

translate chinese chinese_6871270_1155:
    old "Well... Whatever."
    new "嗯……随便吧。"

translate chinese chinese_7998607_1156:
    old "Don't forget that you have to go to the interview, alright?"
    new "别忘了你还要去面试，好吗？"

translate chinese chinese_6487207_1157:
    old "It's alright, no problem."
    new "没事，没问题。"

translate chinese chinese_2553816_1158:
    old "I'll see you later so you can tell me how the interview went, alright?"
    new "待会儿见，到时候你告诉我面试怎么样了，好吗？"

translate chinese chinese_5774615_1159:
    old "Hmm, who could it be?"
    new "嗯，会是谁呢？"

translate chinese chinese_4062596_1160:
    old "I better hurry up and open the door..."
    new "我得赶紧开门……"

translate chinese chinese_4667181_1161:
    old "Oh, hi Barbie, nice to see you here."
    new "哦，嗨，芭比，真没想到会在这里见到你。"

translate chinese chinese_5729748_1162:
    old "You did?! That's awesome Barbie!"
    new "你做到了?! 太棒了芭比!"

translate chinese chinese_1357007_1163:
    old "So I take it the interview went well, right?"
    new "所以面试进行得还顺利吧？"

translate chinese chinese_0421877_1164:
    old "That's great, hey, let's come to my room."
    new "太好了，嘿，去我的房间吧。"

translate chinese chinese_7186573_1165:
    old "That way you can tell me everything."
    new "这样你就可以告诉我一切了。"

translate chinese chinese_9546720_1166:
    old "That's so awesome Barbie, congrats!"
    new "太棒了芭比，恭喜！"

translate chinese chinese_3128754_1167:
    old "Well, I'm glad you're happy."
    new "好吧，我很高兴你能开心。"

translate chinese chinese_8727151_1168:
    old "You're still going to work?"
    new "你还要去上班？"

translate chinese chinese_3567190_1169:
    old "Alright! I hear all of that!"
    new "好了！我都听到了！"

translate chinese chinese_9694563_1170:
    old "She's happy, and you accomplished what you wanted."
    new "她很开心，你也达到了你的目的。"

translate chinese chinese_4082451_1171:
    old "That means we can get to my thing now, right?"
    new "那意思是我们可以开始我的计划了，对吧？"

translate chinese chinese_2206449_1172:
    old "[pla], wake up!"
    new "[pla]，醒醒！"

translate chinese chinese_1156060_1173:
    old "[mo1]? What's happening?"
    new "[mo1]？发生什么事了？"

translate chinese chinese_1734240_1174:
    old "Well, you see, Barbie's in the livingroom, she's waiting there to talk to you."
    new "嗯，你看，芭比在客厅里，她在那儿等你说话。"

translate chinese chinese_7309984_1175:
    old "Ohh, sure, I'll be downstairs in a minute."
    new "哦，好的，我一会儿下楼。"

translate chinese chinese_0936559_1176:
    old "Ok, by the way. she's pregnant..."
    new "好吧，对了，她怀孕了……"

translate chinese chinese_1227572_1177:
    old "Do you know anything about that?"
    new "你知道些什么吗？"

translate chinese chinese_5659415_1178:
    old "Me? No, nothing! I don't know what this is about..."
    new "我？没有，没什么！我不知道这回事……"

translate chinese chinese_8455869_1179:
    old "But I'll go down and talk to her."
    new "但我下去和她谈谈。"

translate chinese chinese_2524057_1180:
    old "Okay honey."
    new "好吧，亲爱的。"

translate chinese chinese_5340220_1181:
    old "B- Barbie! H- hi!"
    new "B- 芭比！H- 嗨！"

translate chinese chinese_5662033_1182:
    old "W- what's happening?"
    new "什、什么情况？"

translate chinese chinese_9558721_1183:
    old "I- I... W- what's this?"
    new "我……这……这是什么？"

translate chinese chinese_5955392_1184:
    old "Y- you're pregnant!"
    new "你你怀孕了！"

translate chinese chinese_0474162_1185:
    old "H- hey, don't worry, we'll figure something out."
    new "嘿，别担心，我们会想出办法的。"

translate chinese chinese_3067994_1186:
    old "I know, I know."
    new "我知道，我知道。"

translate chinese chinese_7394348_1187:
    old "But I'm sure everything will be fine."
    new "但我肯定一切都会好的。"

translate chinese chinese_2280354_1188:
    old "And I can promise you that I'll be here for you, no matter what. Alright?"
    new "我可以向你保证，无论发生什么，我都会在你身边。好吗？"

translate chinese chinese_5356875_1189:
    old "Let's just wait for now, and give ourselves time to think about this."
    new "我们现在先等等，给自己一些时间思考这个问题。"

translate chinese chinese_3328431_1190:
    old "Of course, I understand."
    new "当然，我明白。"

translate chinese chinese_0087007_1191:
    old "But before we make any decision let's just make sure that you check with a doctor to see how you're doing."
    new "但是在做任何决定之前，最好先去医院检查一下你的身体状况。"

translate chinese chinese_7925800_1192:
    old "You know, you're physical state."
    new "你知道的，你的身体状况。"

translate chinese chinese_3803376_1193:
    old "You know, just to make sure everything's fine with you."
    new "你知道的，就是确认一下你一切都好。"

translate chinese chinese_5104848_1194:
    old "I think it is."
    new "我觉得是的。"

translate chinese chinese_3968222_1195:
    old "I know a lot is going through your head right now."
    new "我知道你现在心里有很多想法。"

translate chinese chinese_2872752_1196:
    old "But precisely because of that, I think we shouldn't rush into anything."
    new "正因为那样，我觉得我们不应该急着做决定。"

translate chinese chinese_7974264_1197:
    old "That's a great idea."
    new "这个主意真好。"

translate chinese chinese_9098533_1198:
    old "And keep me informed if you can, I'd like to know how you're doing."
    new "如果你能的话，记得让我知道你的进展，我很想知道你怎么样了。"

translate chinese chinese_1998546_1199:
    old "Hey, I'm happy to help you."
    new "嘿，我很乐意帮你。"

translate chinese chinese_7891092_1200:
    old "Hey [pla], why the long face?"
    new "嘿[pla]，怎么了，愁眉苦脸的？"

translate chinese chinese_9304372_1201:
    old "You ask why?!"
    new "你问为什么！？"

translate chinese chinese_5459404_1202:
    old "Barbie just came here, she's pregnant!"
    new "芭比刚来这儿，她怀孕了！"

translate chinese chinese_3638408_1203:
    old "I thought you had stopped the spell!"
    new "我以为你已经停止那个咒语了！"

translate chinese chinese_0342959_1204:
    old "Well, I did stop it."
    new "好吧，我确实阻止了它。"

translate chinese chinese_4241307_1205:
    old "But the magic cultivation process had already started."
    new "但是修炼的过程已经开始了。"

translate chinese chinese_7996665_1206:
    old "You should know by now that when it comes to magic, nothing is ever as simple as 'canceling' a spell."
    new "你应该知道，涉及到魔法时，从来没有像“取消”咒语这么简单的事情。"

translate chinese chinese_3584491_1207:
    old "It's not like flipping a switch."
    new "这可不是翻个开关就能解决的。"

translate chinese chinese_1135372_1208:
    old "The magic power is already in cultivation inside of her."
    new "魔法力量已经在她的体内开始修炼了。"

translate chinese chinese_8672505_1209:
    old "Or in human words, she's already pregnant."
    new "用人类的话来说，她已经怀孕了。"

translate chinese chinese_4441595_1210:
    old "Besides, the magic spell to direct the magic you implanted in her."
    new "而且，还有引导你植入她体内的魔法的咒语。"

translate chinese chinese_5308390_1211:
    old "And said magic developing within her are two different things."
    new "和她说体内正在发展的魔法是两码事。"

translate chinese chinese_5682701_1212:
    old "Then what's the point of even canceling the spell?"
    new "那取消这个咒语还有什么意义？"

translate chinese chinese_8300199_1213:
    old "If she's still going to go through with it. We might as well have let her go through with it."
    new "如果她还是打算这么做，那我们还不如让她去做。"

translate chinese chinese_5702171_1214:
    old "I wasn't finished!"
    new "我还没说完呢！"

translate chinese chinese_0508697_1215:
    old "If what you're describing was the case, I wouldn't have done anything."
    new "如果情况真是你说的那样，我根本就不会采取任何行动。"

translate chinese chinese_6291970_1216:
    old "Yes, she's still condensing magic within her."
    new "是的，她还在体内凝聚魔法。"

translate chinese chinese_7337308_1217:
    old "But that doesn't mean that there's nothing we can do."
    new "但这并不意味着我们无能为力。"

translate chinese chinese_1728326_1218:
    old "Listen, even though this appears to be a normal human pregnancy, you must keep in mind that magic's involved."
    new "听着，虽然这看起来像是正常的怀孕，但你必须记住这里面有魔法的因素。"

translate chinese chinese_2934624_1219:
    old "I can't just make her pregnancy go away. But I can make it go a lot faster than it normally would."
    new "我不能让她怀孕的事情消失，但我可以让它比正常情况下快很多。"

translate chinese chinese_5622236_1220:
    old "W- what? So she'll have a baby soon?!"
    new "什、什么？她很快就要生宝宝了？！"

translate chinese chinese_7310870_1221:
    old "Hmph, no, she won't."
    new "哼，她不会的。"

translate chinese chinese_6565924_1222:
    old "Uhh... Alright? I'm a little confused."
    new "呃……好吧？我有点困惑。"

translate chinese chinese_7750619_1223:
    old "Well... Magic adheres to the natural laws of your world..."
    new "嗯……魔法遵循你世界中的自然法则……"

translate chinese chinese_6441721_1224:
    old "And that's why, even though it may seem 'pregnant,' what it's actually gestating is magical power..."
    new "而这就是为什么，即使看起来像是“怀孕”了，实际上孕育的却是魔力……"

translate chinese chinese_1259567_1225:
    old "Ok, so there is not baby?"
    new "好了，所以没有宝宝吗？"

translate chinese chinese_4223814_1226:
    old "Well, technically, a baby could be born from this process since it's all magical power..."
    new "好吧，从技术上讲，这个过程可能会生出一个婴儿，毕竟全是魔法力量……"

translate chinese chinese_6782008_1227:
    old "However, that would only happen if we decide that a portion of the magical power she's gestating materializes and develops."
    new "不过，这只有在我们决定她孕育的一部分魔力物质化并发育的情况下才会发生。"

translate chinese chinese_4449322_1228:
    old "That way, a portion of the magical power would adapt to the woman's womb..."
    new "这样一来，一部分魔力就会适应女人的子宫……"

translate chinese chinese_6329516_1229:
    old "And, powered by the condensing magical energy, it would develop like a human baby."
    new "而且，在凝聚的魔力驱动下，它会像人类胎儿一样发育。"

translate chinese chinese_3480100_1230:
    old "So by the time the magic is fully cultivated they both come out of the body together."
    new "所以等到魔法完全修炼好了，它们就会一起从体内出来。"

translate chinese chinese_8082395_1231:
    old "But in this case things are going to be very different."
    new "但这次情况会非常不同。"

translate chinese chinese_6597861_1232:
    old "Since it's going to be a lot faster than normal, only the magic will develop inside of her."
    new "因为这比正常速度快很多，所以只有魔法会在她体内发展。"

translate chinese chinese_5335815_1233:
    old "So by the time she gives birth only the magic will be coming out of her."
    new "所以等她生孩子的时候，出来的就只有魔法了。"

translate chinese chinese_4717827_1234:
    old "Ok, ok... I think I understand."
    new "好啦好啦……我想我明白了。"

translate chinese chinese_9919576_1235:
    old "But wait! What's going to happen when she goes to the doctor? Won't they realize there's something weird going on?"
    new "但是等一下！她去看医生的话会发生什么？他们不会发现有什么不对劲吗？"

translate chinese chinese_5522910_1236:
    old "I can see why you would think that."
    new "我能理解你为什么这么想。"

translate chinese chinese_2529810_1237:
    old "But in human terms, she's still pregnant, even if it's just with magic."
    new "但从人类的角度来说，她还是怀孕了，即使那只是魔法。"

translate chinese chinese_9502976_1238:
    old "When she goes to get checked with doctors and such, everything will appear to be normal."
    new "等她去医院检查的时候，一切都会显示正常。"

translate chinese chinese_3469612_1239:
    old "So everything should be ok."
    new "所以一切应该都没问题。"

translate chinese chinese_5173404_1240:
    old "Alright, that's good to hear."
    new "好吧，听到这个很高兴。"

translate chinese chinese_2088777_1241:
    old "So everything should be okay from here on out, right?"
    new "所以从现在开始一切都会好起来，对吧？"

translate chinese chinese_3404927_1242:
    old "Hmm, not entirely."
    new "嗯，不完全是。"

translate chinese chinese_4136270_1243:
    old "R- really?"
    new "真、真的？"

translate chinese chinese_2950049_1244:
    old "Is there something else?"
    new "还有别的吗？"

translate chinese chinese_7523195_1245:
    old "Well, what we're doing with this spell is trying to condense the magic energy needed to power up the portal to the magic world."
    new "好吧，我们用这个咒语的目的就是尝试浓缩开启魔法世界之门所需的魔力能量。"

translate chinese chinese_7135982_1246:
    old "And we're doing it by condensing magic within the bodies of women."
    new "我们是通过将魔法浓缩在女性体内来实现的。"

translate chinese chinese_8953262_1247:
    old "Yeah, I get that."
    new "嗯，我明白。"

translate chinese chinese_9443703_1248:
    old "Well, the thing is that these women aren't natural magic wielders."
    new "其实，这些女人并不是天生的魔法使用者。"

translate chinese chinese_4272460_1249:
    old "Their bodies aren't able to condense magic at the same rate that the spell demands it."
    new "他们的身体无法以法术所需的速度凝聚魔力。"

translate chinese chinese_4912625_1250:
    old "They would need your help with providing the magic they can't procure for themselves."
    new "他们需要你的帮助来提供他们自己无法获得的魔法。"

translate chinese chinese_5957271_1251:
    old "So, under normal circumstances, Barbie would need you to help her by giving her magic."
    new "所以，在正常情况下，芭比需要你的帮助，给你提供魔法。"

translate chinese chinese_3102823_1252:
    old "But since this pregnancy will be so short, I don't think she'll need you to give her any condensed magic power."
    new "但是因为这次怀孕时间很短，我觉得她不需要你给她浓缩魔力。"

translate chinese chinese_0234726_1253:
    old "How would that work? The giving her magic part?"
    new "那怎么操作？给她魔力那部分？"

translate chinese chinese_4780834_1254:
    old "Oh, you know full well how that works, the same way you do it for me."
    new "哦，你心里清楚那怎么运作的，就像你对我做的那样。"

translate chinese chinese_1639965_1255:
    old "I- I see..."
    new "我……明白了……"

translate chinese chinese_1962546_1256:
    old "But as I explained to you, given her particular conditions I can't be sure about what's about to happen with her."
    new "但是像我解释的那样，鉴于她的特殊情况，我不能确定接下来会发生什么。"

translate chinese chinese_4349864_1257:
    old "So just be sure to be vigilant about what can happen to her. Just to make that she's fine."
    new "所以一定要警惕可能会发生什么事，确保她没事。"

translate chinese chinese_5755570_1258:
    old "I understand, alright, I'll be sure to do that."
    new "我明白，好吧，我一定会这么做。"

translate chinese chinese_4991757_1259:
    old "But thanks anyway Brixxida, this gives me some peace of mind."
    new "不过还是谢谢你了，Brixxida，这让我心里踏实了不少。"

translate chinese chinese_7254135_1260:
    old "Well, I'm just letting you know what happened."
    new "我只是想让你知道发生了什么。"

translate chinese chinese_4689414_1261:
    old "But don't forget that now you have to keep going with our plans."
    new "但是别忘了，你现在得继续执行我们的计划。"

translate chinese chinese_8074905_1262:
    old "I'm letting you off the hook with this one, but be sure to keep searching the next specimen."
    new "这次放过你了，但下次一定要继续搜寻标本。"

translate chinese chinese_8276648_1263:
    old "Yeah, alright."
    new "好吧。"

translate chinese chinese_8919913_1264:
    old "Oh, Barbie, hi!"
    new "哦，芭比，你好！"

translate chinese chinese_4194364_1265:
    old "Hi, how are you?"
    new "嗨，你好吗？"

translate chinese chinese_5887569_1266:
    old "Is everything alright?"
    new "一切都好吗？"

translate chinese chinese_4123381_1267:
    old "Uhmm... Are you alright?"
    new "嗯……你还好吗？"

translate chinese chinese_6450504_1268:
    old "Did you go to the doctor? Is everything okay?"
    new "你去看医生了吗？一切都好吗？"

translate chinese chinese_5691624_1269:
    old "Are you sure?"
    new "你确定吗？"

translate chinese chinese_5703396_1270:
    old "Uhm... Sure, I don't see why not."
    new "嗯……好吧，我不觉得有什么不行的。"

translate chinese chinese_5952417_1271:
    old "Let's go to my bedroom and we'll talk there."
    new "我们去我的卧室再说吧。"

translate chinese chinese_4957410_1272:
    old "Alright, do you want to tell me what's going on?"
    new "好吧，你想告诉我发生了什么吗？"

translate chinese chinese_0442133_1273:
    old "Because I can tell that something's not right."
    new "因为我觉得有些不对劲。"

translate chinese chinese_8522029_1274:
    old "So what's the problem?"
    new "那问题是什么？"

translate chinese chinese_9891535_1275:
    old "Fatigue? Like you're tired?"
    new "疲劳？就像你累了那样？"

translate chinese chinese_4633170_1276:
    old "How do you know that?"
    new "你怎么知道的？"

translate chinese chinese_8693421_1277:
    old "Hot?"
    new "热吗？"

translate chinese chinese_2144433_1278:
    old "Oh! I- I see."
    new "哦！我——我明白了。"

translate chinese chinese_4989830_1279:
    old "This is it [pla]! This is what I told you about!"
    new "就是这个[pla]！这就是我跟你说过的！"

translate chinese chinese_6453521_1280:
    old "This fatigue she's talking about is her body manifesting its need for magic."
    new "她所说的疲劳是她的身体在表现它对魔法的需求。"

translate chinese chinese_4565654_1281:
    old "And the feeling of being {i}'horny'{/i} is her body telling her what she has to do to solve it."
    new "而那种“欲火焚身”的感觉是她的身体在告诉她该如何解决它。"

translate chinese chinese_4947295_1282:
    old "I wasn't expecting it to go this way, since the spell was canceled and everything."
    new "我没想到会这样，毕竟咒语已经取消了。"

translate chinese chinese_7040376_1283:
    old "But what you have to do now is have sex with her so that she can feed off your magic!"
    new "但是你现在要做的就是和她发生关系，这样她就能吸取你的魔力了！"

translate chinese chinese_6470738_1284:
    old "W- what? N- no, of course not."
    new "什、什么？不、不是，当然不是。"

translate chinese chinese_4124198_1285:
    old "Why would I think that there's anything weird about it?"
    new "我为什么要觉得这有什么奇怪的？"

translate chinese chinese_3261310_1286:
    old "I think that's very normal."
    new "我觉得这很正常。"

translate chinese chinese_8655044_1287:
    old "After all, you're pregnant, I think it's pretty normal that you would have those feelings."
    new "毕竟你怀孕了，我觉得有这样的感觉挺正常的。"

translate chinese chinese_4550815_1288:
    old "What's wrong?"
    new "怎么了？"

translate chinese chinese_1241324_1289:
    old "Ohh, come on, what are you talking about?"
    new "哦呵，你到底在说什么？"

translate chinese chinese_6056790_1290:
    old "Yeah, it's true that you don't look like you usually do."
    new "是啊，你确实不像平时的样子。"

translate chinese chinese_3536499_1291:
    old "But that doesn't mean you look bad in any way."
    new "但这不意味着你有任何不好看的地方。"

translate chinese chinese_4572161_1292:
    old "I mean, you look just as sexy as you always have."
    new "我是说，你看起来还是一样性感。"

translate chinese chinese_9222781_1293:
    old "Of course I would!"
    new "我当然会啊！"

translate chinese chinese_6566645_1294:
    old "I'm surprised that you even feel like you'd have to ask me."
    new "我没想到你还会觉得需要问我一下。"

translate chinese chinese_9884951_1295:
    old "You look just as beautiful as you always have."
    new "你看起来还是一如既往的美丽。"

translate chinese chinese_8142101_1296:
    old "And I'll be more than happy to help you feel better."
    new "我很乐意帮你感觉好一点。"

translate chinese chinese_8401710_1297:
    old "Come on, don't say that."
    new "别这么说嘛。"

translate chinese chinese_1253984_1298:
    old "You're just as beautiful as always."
    new "你一如既往地美丽。"

translate chinese chinese_0060167_1299:
    old "Let me show you."
    new "让我给你看看。"

translate chinese chinese_3049887_1300:
    old "I'm glad to be able to help you."
    new "我很高兴能帮你。"

translate chinese chinese_9950735_1301:
    old "After all, you didn't get into this situation by yourself."
    new "毕竟，你不是自己一个人陷入这种境地的。"

translate chinese chinese_6138663_1302:
    old "I figure this is the least that I can do."
    new "我觉得这是我能做的最少的事情了。"

translate chinese chinese_4631221_1303:
    old "I'm glad it actually works."
    new "还好它真的管用。"

translate chinese chinese_4541156_1304:
    old "Sure, I'll be seeing you later."
    new "好的，待会儿见。"

translate chinese chinese_9492305_1305:
    old "Well done [pla]!"
    new "干得好[pla]！"

translate chinese chinese_0211641_1306:
    old "With what you just did I'm sure that she'll be alright."
    new "以你刚才做的，我相信她会没事的。"

translate chinese chinese_3767475_1307:
    old "Hmm, I guess that if she's going to be alright with just that, then that's fine."
    new "嗯，我想如果她对这样就满意了，那也挺好。"

translate chinese chinese_9370916_1308:
    old "She will be. Don't worry, I'm sure that that's more than enough."
    new "她会的。别担心，我相信这已经足够多了。"

translate chinese chinese_3996054_1309:
    old "Which is great, because now you  can focus on what's next."
    new "这很好，因为现在你可以专注于接下来的事情了。"

translate chinese chinese_2437731_1310:
    old "However, this time I'll choose. We were lucky this time, but really 'impregnating' someone is not easy at all..."
    new "不过这次我来选择。这次我们运气不错，但真的“怀孕”可一点也不容易……"

translate chinese chinese_1205197_1311:
    old "Alright... But you can't take too long; we need to keep incubating more magical power for the portal..."
    new "好吧……但你不能花太长时间；我们需要继续孵化更多的魔法力量来维持传送门……"

translate chinese chinese_3125858_1312:
    old "Anyway, I'm gonna rest, I spend too much magic power with Barbie..."
    new "总之，我要去休息了，刚才给芭比用了太多魔法力量……"

translate chinese chinese_2556040_1313:
    old "Ok, see you later."
    new "好的，回头见。"

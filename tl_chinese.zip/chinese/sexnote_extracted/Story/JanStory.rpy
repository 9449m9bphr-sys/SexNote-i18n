# auto-tl Qwen Colab

translate chinese chinese_6227331_0:
    old "Ugh, finally at home."
    new "唉，终于到家了。"

translate chinese chinese_5236937_1:
    old "Hmm. What is that noise? It's coming from the living room..."
    new "嗯？那是什么声音？是从客厅传来的……"

translate chinese chinese_4518350_2:
    old "Woah! Are they... Having sex?"
    new "哇！他们……在做爱吗？"

translate chinese chinese_2210624_3:
    old "I... Am... Sorry... I... Just... Heard..."
    new "我... 对不起... 我... 就是... 听到..."

translate chinese chinese_3848047_4:
    old "Weren't you supposed to come back at night?!"
    new "你不是说晚上回来吗？！"

translate chinese chinese_1991803_5:
    old "Yes, but my after school program was canceled..."
    new "是的，但是我的课后辅导取消了……"

translate chinese chinese_7943950_6:
    old "[pla] is not what it looks like... We were just..."
    new "[pla]并不是看起来那样……我们只是……"

translate chinese chinese_9113679_7:
    old "... I'm sorry... I..."
    new "……对不起……我……"

translate chinese chinese_1990176_8:
    old "I know they are married but... They should do that in their room..."
    new "我知道他们结婚了，但是……这种事应该去房间里做……"

translate chinese chinese_5302157_9:
    old "Anyway, I have all day to relax..."
    new "不管怎样，我今天一整天都可以放松……"

translate chinese chinese_4492537_10:
    old "Listen, I want to talk to you about t- the living room"
    new "听着，我想和你谈谈客厅的事"

translate chinese chinese_1428216_11:
    old "Oh, I understand. You are a couple I think is perfectly normal... And you are my [mo1rel], you don't have to give me explanations."
    new "哦，我明白了。你们是一对我觉得很正常的情侣……而且你是我的[mo1rel]，你不用给我解释。"

translate chinese chinese_3599424_12:
    old "I'm glad to hear that. But... I want to apologize. We were a bit careless getting... Intimate in the living room."
    new "听到这个我很高兴。但是……我要道歉。我们在客厅里有点太不小心了……亲近了。"

translate chinese chinese_7252728_13:
    old "Well, I won't bother you anymore. Please keep studying hard, honey."
    new "好吧，我不会再打扰你了。请继续努力学习，亲爱的。"

translate chinese chinese_2943457_14:
    old "Oh, by the way, you haven't had breakfast, come downstairs and I'll make you breakfast!"
    new "哦，对了，你还没吃早餐呢，下来我给你做早餐！"

translate chinese chinese_7583023_15:
    old "Oh right, thank you [mo1rel]."
    new "哦对，谢谢[mo1rel]。"

translate chinese chinese_6850371_16:
    old "(What the fuck!... what are they doing?)"
    new "（妈的！他们在干什么？）"

translate chinese chinese_1563279_17:
    old " (Shit!) Oh, no... Nuh uh... The door was open. I just didn't know someone was in here."
    new "（shit!）哦，不... 不行... 门是开着的。我只是不知道有人在这里。"

translate chinese chinese_4204311_18:
    old "[pla], [mo2] and I were just giving each other a little hug, sweetie."
    new "[pla]，[mo2]和我刚才只是互相抱了一下，亲爱的。"

translate chinese chinese_2711972_19:
    old "See, I tried to tell you he is a damn pervert!... GO AWAY!"
    new "你看，我早就告诉你他是个变态了！... 走开！"

translate chinese chinese_8317794_20:
    old "I wasn't... Nevermind... I'll go."
    new "我还没... 算了... 我走吧。"

translate chinese chinese_9815627_21:
    old "Oh hi [pla], I'm glad you're here, I wanted to talk to you too."
    new "哦，你好[pla]，很高兴你在这里，我也想和你谈谈。"

translate chinese chinese_6934873_22:
    old "Ehm... Is something happening?"
    new "嗯……发生什么事了吗？"

translate chinese chinese_8876311_23:
    old "I don't know, I just arrived."
    new "我不知道，我刚到。"

translate chinese chinese_1549955_24:
    old "Hmm... Actually, yes... That's why I need to talk to you both."
    new "嗯……实际上，是的……这就是为什么我需要和你们俩谈谈。"

translate chinese chinese_8170428_25:
    old "We are having some... Uhh, financial issues..."
    new "我们有些……嗯，经济问题……"

translate chinese chinese_3692338_26:
    old "Well, we don't have e- enough money to pay our obligations..."
    new "嗯，我们手头不够钱来支付这些债务..."

translate chinese chinese_8244906_27:
    old "Ohh."
    new "哦。"

translate chinese chinese_3766472_28:
    old "But why didn't you say anything before?"
    new "那你之前为什么不说话？"

translate chinese chinese_2158615_29:
    old "Hmm, I didn't want you to worry about it... It's my obligation to provide for both of you... It's just that our current monetary situation is getting worse and..."
    new "嗯，我本来不想让你担心的……养家是我的责任……只是我们现在经济状况越来越糟了……"

translate chinese chinese_7144403_30:
    old "I- I have been looking at some options and I have applied for different jobs but even that seems to be difficult."
    new "我……我在看看一些选项，也申请了几份工作，但看来这也不容易。"

translate chinese chinese_2549490_31:
    old "It's not that easy... Since I have been unemployed for so long, now it's much harder for me to find a job."
    new "没那么简单……因为我失业很久了，现在找工作难多了。"

translate chinese chinese_0347254_32:
    old "I have already talked to my [mo1rel] and friends but no luck... Nothing yet and only God knows when I'll get something good enough."
    new "我已经和我的[mo1rel]以及朋友们聊过了，但没什么用……到现在还没消息，也不知道什么时候能有好的结果。"

translate chinese chinese_2881624_33:
    old "[mo2] was very generous with us when we were together, she paid for almost everything since she has a high salary income."
    new "[mo2] 和我们一起的时候非常大方，她几乎包揽了一切开支，因为她收入很高。"

translate chinese chinese_7701763_34:
    old "Now that she is gone and we are no longer together, we are facing many more issues. I didn't expect the situation to go this way..."
    new "现在她走了，我们不再在一起了，面对的问题更多了。我没想到情况会变成这样……"

translate chinese chinese_5019102_35:
    old "You're not alone on this... Kyle and I will help you... Right?"
    new "你不是一个人在做这个……凯尔和我会帮你……对吧？"

translate chinese chinese_2696934_36:
    old "Yes, of course! I'm working and you know I can help, don't worry about it [mo1rel]."
    new "当然了！我正在工作，你知道我可以帮忙的，别担心，[mo1rel]。"

translate chinese chinese_2214618_37:
    old "It's not that easy, I know you wanna help but we owe a lot of money... Argh! I- I don't know what to do."
    new "没那么简单，我知道你想帮忙，但我们欠了很多钱……啊！我不知道该怎么办。"

translate chinese chinese_5858696_38:
    old "And [mo2] is gone, she is gone and I'm here..."
    new "而且[mo2]走了，她走了而我却在这里..."

translate chinese chinese_0032606_39:
    old "We'll find the way to solve thi-"
    new "我们会找到解决办法的-"

translate chinese chinese_1198588_40:
    old "I- I can't now, I better go to take some rest... I can't do this now... Sorry but I can't."
    new "我—我现在不行，我还是去休息一下吧……我现在做不到……对不起，我真的不行。"

translate chinese chinese_2197423_41:
    old "S- Sure [mo1rel], it's fine."
    new "好啦，[mo1rel]，没关系的。"

translate chinese chinese_0937294_42:
    old "It's the first time I see [mo1rel] this worried and sad, especially sad. We gotta do something to help."
    new "这是我第一次看到[mo1rel]这么焦虑和难过，尤其是难过。我们必须做点什么来帮帮她。"

translate chinese chinese_0350123_43:
    old "Yeah! I didn't imagine seeing her like this. [pla] find a job and I'll do my part, I'll find a way to help as well, even if she says isn't enough."
    new "yeah! 我没想到会看到她这副样子。[pla]去找个工作，我也会尽我所能帮忙，即使她说不够。"

translate chinese chinese_7492400_44:
    old "Sure! I'll start to look for something immediately... It's too sa-"
    new "好啊！我马上就开始找……太惨了-"

translate chinese chinese_0380846_45:
    old "Yeah, yeah... I know it's sad but we gotta focus on finding a solution for this..."
    new "嗯嗯……我知道这很悲伤，但我们得专注于找出解决办法……"

translate chinese chinese_5151929_46:
    old "Tell me once you have found something..."
    new "找到东西了再告诉我……"

translate chinese chinese_7108648_47:
    old "I will."
    new "我会的。"

translate chinese chinese_6351369_48:
    old "Alright, See ya!"
    new "好了，再见！"

translate chinese chinese_9427693_49:
    old "Shit! This is bad... I gotta find a job, my [mo1rel] is gonna get sick and depressed if we don't do something."
    new "shit! 这糟了……我得找份工作，如果我们再不采取行动，我的[mo1rel]会生病抑郁的。"

translate chinese chinese_7403506_50:
    old "Argh! But where? Really, where can I find a job?"
    new "啊！但是在哪儿呢？真的，我在哪儿能找到工作？"

translate chinese chinese_2771757_51:
    old "Maybe at the vet's store... Or with Dr. Johnson... I don't know!"
    new "maybe在宠物店... 或者是和约翰逊医生... 我也不知道！"

translate chinese chinese_4351869_52:
    old "I know! With Lisa..."
    new "我知道！和丽莎..."

translate chinese chinese_6081228_53:
    old "Or [mo2]... No! What am I thinking about!... [mo2], no!... She would kick out my ass."
    new "或者[mo2]……不！我在想什么呢！……[mo2]，不行！……她会一脚踢飞我的。"

translate chinese chinese_7818261_54:
    old "I shouldn't keep wasting my time... I'll go to all and see what I find, I need a job, I cannot let my [mo1rel] down... She needs me"
    new "我不应该再浪费时间了……我去四处看看有没有什么发现，我需要一份工作，不能让[mo1rel]失望……她需要我"

translate chinese chinese_6674434_55:
    old "What a day! Argh! It seems to be impossible to find a job... Don't know what I'm gonna do"
    new "真是糟糕的一天！啊~看来找工作是不可能了……不知道该怎么办了"

translate chinese chinese_1207367_56:
    old "Maybe I should ask at schoo-"
    new "maybe 我应该在学校问一问—"

translate chinese chinese_0976434_57:
    old "Hey [pla], we have to talk."
    new "嘿[pla]，我们得谈谈。"

translate chinese chinese_4276414_58:
    old "What happened? Why the sad face?"
    new "怎么了？为什么这么难过？"

translate chinese chinese_6981607_59:
    old "Well, I was looking for any job opportunity the whole day but no luck, nobody wants to hire me."
    new "好吧，我一整天都在找工作，但没 luck，没人愿意雇我。"

translate chinese chinese_6931020_60:
    old "That's bad... You know, [mo1rel] was crying a lot today, she is feeling like shit."
    new "这可不好……你知道吗，[mo1rel]今天哭了很多，她感觉糟透了。"

translate chinese chinese_7156325_61:
    old "Argh! I can't see her like that... You have to find something, you really have to."
    new "啊！我不能让她变成那样……你一定要找到什么，真的一定要。"

translate chinese chinese_5678487_62:
    old "Did she tell you anything? Did you talk to her?"
    new "她跟你说了什么吗？你跟她说话了吗？"

translate chinese chinese_2108806_63:
    old "No, she doesn't want us to notice how she's feeling, I didn't say anything and that's why I'm telling you."
    new "不，她不想让我们注意到她的感受，我什么都没说，这就是为什么我要告诉你。"

translate chinese chinese_0037916_64:
    old "I'll find something, we can't let [mo1rel] down."
    new "我会找到办法的，不能让[mo1rel]失望。"

translate chinese chinese_5414675_65:
    old "No, we can't. You find something tomorrow... Do your best, man! Do something about it because we have serious bullshit here."
    new "不行，我们不能。你明天找点什么……尽力吧，兄弟！得做点什么，因为我们这里真的很棘手。"

translate chinese chinese_9382105_66:
    old "I know, I know..."
    new "我知道，我知道……"

translate chinese chinese_1639618_67:
    old "Good, see you tomorrow then..."
    new "好的，那明天见……"

translate chinese chinese_6623176_68:
    old "Bye..."
    new "再见..."

translate chinese chinese_0697358_69:
    old "Oh my Gosh! Where am I going to find a job now?"
    new "天啊！我现在上哪儿去找工作？"

translate chinese chinese_4268870_70:
    old "I already tried with the best options I had in mind... What abou-"
    new "我已经试过我想到的最佳选项了……那什么关于"

translate chinese chinese_3366306_71:
    old "[mo2]? Perhaps she doesn't hate me that much and I could have a chance there... Argh! No! Fuck, I don't wanna ask to her..."
    new "[mo2]？也许她并没有那么讨厌我，我还有机会……啊рг! 不！妈的，我不想去问她……"

translate chinese chinese_3348027_72:
    old "Fuck it! I'll do it, this is about my [mo1rel], I have to try at least... Tomorrow I'll see [mo2]."
    new "操！我干了，这是关于我的[mo1rel]，至少得试试……明天去看看[mo2]。"

translate chinese chinese_4606250_73:
    old "Hi Akita... I'm [pla]"
    new "喂，秋田……我是[pla]"

translate chinese chinese_5360900_74:
    old "Oh! Hey, I remember you, yes... You're the handsome delivery guy..."
    new "哦！想起来了，你是那位帅气的送货小哥……"

translate chinese chinese_9372125_75:
    old "Tell me... What can I do for you?"
    new "告诉我……你能为我做些什么？"

translate chinese chinese_1287889_76:
    old "H- Handsome? Haha t- thanks."
    new "帅、帅吗？哈哈，谢谢。"

translate chinese chinese_9834453_77:
    old "Actually I'm here looking for [mo2]."
    new "实际上我是来找[mo2]的。"

translate chinese chinese_7468804_78:
    old "Yes, I hav-"
    new "是的，我有－"

translate chinese chinese_1202374_79:
    old "[pla]? What the heck are you doing here?"
    new "[pla]？你在这里干什么？"

translate chinese chinese_1090316_80:
    old "H- Hi [mo2], I- I don't want to bother you but I have to talk to you, I- I need to tell you something."
    new "H- 嗨 [mo2]，我- 我不想打扰你，但是我要和你说件事，我- 我有些事情需要告诉你。"

translate chinese chinese_1974383_81:
    old "What do you want?"
    new "你想要什么？"

translate chinese chinese_2937693_82:
    old "I see but I really need to ask you for a favor..."
    new "我明白，但我真的需要请你帮忙……"

translate chinese chinese_9739904_83:
    old "I need a job, I can do whatever you ask me to but I need to work. The situation at home is not ok and we all are worried."
    new "我需要工作，你可以让我做什么我就做什么，但我真的得工作。家里的情况不太好，我们都挺担心的。"

translate chinese chinese_8944918_84:
    old "So you come to my office and you pretend I give you a job? Why should I do that!?"
    new "所以你来我的办公室，假装我给你一份工作？我为什么要这么做！？"

translate chinese chinese_2901784_85:
    old "[mo2], please! I know you don't like me but believe you're the last option I have, I don't know what else to do."
    new "[mo2]，求你了！我知道你不喜欢我，但相信你是我的最后选择，我真的不知道该怎么办了。"

translate chinese chinese_9886141_86:
    old "Finally you got it! Yes, I don't like you and I won't hire you. Don't be stupid! Now go away! I don't want you here."
    new "终于明白啦！没错，我不喜欢你，也不会雇用你。别傻了！现在给我滚蛋！我不想看到你在这里。"

translate chinese chinese_1938545_87:
    old "Now that you all need me, you come here looking for me! Well, I don't care!"
    new "现在你们需要我了，就来找我！我才不在乎呢！"

translate chinese chinese_5988997_88:
    old "I said get out!"
    new "我说出去！"

translate chinese chinese_7471978_89:
    old "Now where I'm going to find a job?"
    new "现在我去哪儿找工作？"

translate chinese chinese_0940042_90:
    old "Wait, what is that sound? It comes from the livingroom..."
    new "等一下，那是什么声音？是从客厅传来的……"

translate chinese chinese_7245251_91:
    old "Oh, [mo1rel]? A- Are you fine?"
    new "哦，[mo1rel]？你、你还好吗？"

translate chinese chinese_6397381_92:
    old "Are you crying? I don't want to see you like this [mo1rel]."
    new "你在哭吗？我不希望看到你这个样子 [mo1rel]。"

translate chinese chinese_4244017_93:
    old "I- I know honey but it's hard... I'm feeling so sad, so lonely, I- I."
    new "我……我知道亲爱的，但很难……我感到这么悲伤，这么孤单，我……"

translate chinese chinese_9697252_94:
    old "[mo1rel], you're not alone, we're here for you. I promise you I'll find a job and everything will be fine."
    new "[mo1rel]，你不是一个人，我们在你身边。我答应你会找到工作的，一切都会好起来的。"

translate chinese chinese_7206874_95:
    old "I'm sorry, it's just that it's a bunch of things, I would like to solve our monetary issues without putting pressure on you or your [sisrel]..."
    new "对不起，就是有些事情，我想解决我们的经济问题，又不想给你或你的[sisrel]压力……"

translate chinese chinese_6224265_96:
    old "And... I have to admit... I really miss her... It's been hard to be without her."
    new "而且……我不得不承认……我真的想念她……没有她很难受。"

translate chinese chinese_7220338_97:
    old "No [mo1rel]! Don't worry for us, we are a family and we'll find a way to solve it:"
    new "不 [mo1rel]！别为我们担心，我们是一家人，会找到解决办法的："

translate chinese chinese_5319332_98:
    old "We'll do whatever it takes to make you feel better."
    new "我们会不惜一切代价让你感觉好些的。"

translate chinese chinese_5194803_99:
    old "The only thing that would make me feel better is... Argh!"
    new "能让我感觉好一点的只有……啊！"

translate chinese chinese_8347860_100:
    old "This is hard, you know... It's really hard to feel so helpless, I feel my hands are tied and there is nothing I can do."
    new "这真的很难……感觉这么无力，我觉得自己束手无策，什么都做不了。"

translate chinese chinese_9813272_101:
    old "I'm so so sorry."
    new "真的很抱歉。"

translate chinese chinese_7935396_102:
    old "I'll rest for now... I can barely talk..."
    new "我先休息一下……我都快说不出话了……"

translate chinese chinese_6304175_103:
    old "Yes [mo1], just go and try to rest. I'll take care of this."
    new "好的 [mo1]，去休息吧。这件事交给我。"

translate chinese chinese_0411858_104:
    old "See you hun, thanks for being so good..."
    new "宝贝，再见了，谢谢你这么乖……"

translate chinese chinese_4032539_105:
    old "My [mo1rel] doesn't deserve this, I'll insist to [mo2], she has to help me..."
    new "我的[mo1rel]不值得这样，我会坚持要求[mo2]帮助我..."

translate chinese chinese_3791027_106:
    old "It doesn't matter what I have to do to get that job... I don't want to see my [mo1rel] so depressed and worried."
    new "不管我得做什么才能得到那份工作……我都不想看到我的[mo1rel]这么沮丧和担心。"

translate chinese chinese_4246916_107:
    old "I wish I could help her to come back with [mo2], it is obvious how much she misses her..."
    new "我希望我能帮她和[mo2]重归于好，很明显她有多想念他……"

translate chinese chinese_7548366_108:
    old "This is absurd! What happened to the delivery boy?"
    new "这太荒谬了！送餐员怎么了？"

translate chinese chinese_7762775_109:
    old "I- I'm calling him, but he doesn't answer."
    new "我给他打了电话，但他不接。"

translate chinese chinese_2047458_110:
    old "What? It's incredible how useless everyone in this company is... What am I paying these people for!?"
    new "什么？这家公司里的人都这么没用……我雇他们干嘛！？"

translate chinese chinese_5300284_111:
    old "We should have sent those documents hours ago... "
    new "那些文件几个小时前就应该发出去了……"

translate chinese chinese_6218118_112:
    old "[mo2]? Hi..."
    new "[mo2]？喂……"

translate chinese chinese_9136001_113:
    old "Argh! Again you..."
    new "啊！你又..."

translate chinese chinese_2121527_114:
    old "Akita, I'm waiting for an answer, what happened to the delivery boy? Can we get another one? I need you to solve this fucking issue NOW!"
    new "秋田，我在等你的答复，送货员怎么了？我们可以再找一个吗？我现在就需要你解决这个问题！"

translate chinese chinese_0757824_115:
    old "It would be hard to find another one right now, it's pretty late and the Mayor's office is waiting for those documents. I don't know  Mrs. [mo2]."
    new "现在要找别人可不容易，时间已经很晚了，市长办公室还在等着那些文件呢。我不知道 Mrs. [mo2]。"

translate chinese chinese_9865293_116:
    old "You don't kno-?"
    new "你不知道？"

translate chinese chinese_5708927_117:
    old "I- I could d- deliver t- those d- documents..."
    new "我……我可以送……送那些文件……"

translate chinese chinese_4483314_118:
    old "Are you fucking kidding me!? You're an idiot, I won't trust you with those things, just get out, I told you I don't want you here..."
    new "你特么在逗我吗！？你真是个白痴，那些事情我不会信任你的，滚出去，我说过我不想要你在这里..."

translate chinese chinese_3965120_119:
    old "Mrs. [mo2]! That's actually a good idea and the only option we have if we want those documents to be delivered now."
    new "[mo2]太太！这实际上是个好主意，如果我们现在想要那些文件送达，这也是我们唯一的选择。"

translate chinese chinese_3611576_120:
    old "No and no! I don't want him to do anything... Akita, just find another way..."
    new "不行不行！我不希望他做什么……阿基塔，你找别的办法吧……"

translate chinese chinese_8266419_121:
    old "Uhh... I- I'm afraid there is no other way right now..."
    new "呃……我……我怕现在没有其他办法了……"

translate chinese chinese_4975781_122:
    old "I'll do it! I can do it well, I promise, please [mo2]... It's just a little help."
    new "我来做！我能做好，我保证，求你了[mo2]……只是帮个小忙。"

translate chinese chinese_8103769_123:
    old "Argh! FINE! Go and deliver the documents NOW! If I get to know that you did something wrong, I'll fucking kill you."
    new "啊！好！你现在就去送文件！如果你敢搞砸，我发誓我会杀了你的。"

translate chinese chinese_7847497_124:
    old "[pla], You have to take the documents to the Mayor's office, please go as fast as you can."
    new "[pla]，你必须把文件送到市长办公室，请尽快前往。"

translate chinese chinese_9755880_125:
    old "Alright, I'm going now..."
    new "好吧，我走了……"

translate chinese chinese_9701524_126:
    old "H- Hello?"
    new "喂？"

translate chinese chinese_6223896_127:
    old "Yes, pardon me?"
    new "嗯，抱歉？"

translate chinese chinese_2461874_128:
    old "Oh hi! I'm [pla], I'm coming from [mo2]'s office..."
    new "哦，嗨！我是[pla]，我刚从[mo2]的办公室过来..."

translate chinese chinese_1218565_129:
    old "Hello! I'm Amy, nice meeting you."
    new "你好！我是艾米，很高兴见到你。"

translate chinese chinese_7147877_130:
    old "Do you have the documents? Let me see them, please."
    new "你有文件吗？让我看看，好吗？"

translate chinese chinese_7870035_131:
    old "Yes, here they are..."
    new "好的，在这里..."

translate chinese chinese_6655666_132:
    old "Perfect... You came just in time, we were waiting for them."
    new "完美……你来的正是时候，我们在等他们。"

translate chinese chinese_1266807_133:
    old "Well... Guess that's it... Thank you."
    new "嗯……猜这就是结局了……谢谢。"

translate chinese chinese_7559637_134:
    old "Huh! One more thing! Tell [mo2] that everything is in order and that we'll call her back."
    new "huh! 还有一件事！告诉[mo2]一切正常，我们会再联系她的。"

translate chinese chinese_9517871_135:
    old "Alright, have a nice day."
    new "好吧，祝你今天愉快。"

translate chinese chinese_0124263_136:
    old "Bye! See ya."
    new "拜拜！再见。"

translate chinese chinese_6357342_137:
    old "Alright, I think that was easier than I expected. Now it's time to go back to [mo2]'s office."
    new "好吧，我觉得这比预期的要容易。现在是回去[mo2]办公室的时候了。"

translate chinese chinese_4453898_138:
    old "H- Hello A- Akita..."
    new "哈- hello，阿基塔..."

translate chinese chinese_7022963_139:
    old "(I can't even focus...)"
    new "（我根本无法集中精力……）"

translate chinese chinese_1491940_140:
    old "Good... I delivered everything."
    new "好了……我全都说了。"

translate chinese chinese_4006260_141:
    old "So apparently you did a good job..."
    new "看来你干得不错……"

translate chinese chinese_1140151_142:
    old "Y- Yeah... Well, I delivered the documents and the girl said it was fine and that it was in time, so I guess, yeah..."
    new "嗯……好吧，我送了文件，那个女孩说没问题，还说正好及时，所以我想应该是吧……"

translate chinese chinese_9101443_143:
    old "I know, I know... And... Hmm."
    new "我知道，我知道……而且……嗯。"

translate chinese chinese_7010600_144:
    old "Yeah? What happened? Did I do anything wrong?"
    new "是吗？发生了什么？我做错什么了吗？"

translate chinese chinese_4133130_145:
    old "Well... Hmm, not here but... Did you notice what you have down there?"
    new "嗯……嗯，不是在这里，但是……你注意到你下面有什么吗？"

translate chinese chinese_2145107_146:
    old "What? What do you mea-"
    new "什么？你什么意思-"

translate chinese chinese_5418609_147:
    old "Argh fuck! I- I don't kno- I- I h- have to go."
    new "妈的！我— 我不知道— 我— 我得走了。"

translate chinese chinese_4558410_148:
    old "You better have done it right!"
    new "你最好搞定了！"

translate chinese chinese_6969370_149:
    old "Y- yes [mo2], I- I did everything... S- She said she will call-"
    new "是的 [mo2]，我……我全都做了……她说她会打电话来的……"

translate chinese chinese_6304474_150:
    old "What's wrong with you? Why are you acting so weird?"
    new "你这是怎么了？为什么表现得这么奇怪？"

translate chinese chinese_3254887_151:
    old "M- me? Uhh, no... Nothing..."
    new "我我？呃，不...没什么..."

translate chinese chinese_8584882_152:
    old "What do you have on your hands? Why are you acting like a freak? You idiot! Tell me what have you done?"
    new "你手里拿着什么？你干嘛装模作样？你这个笨蛋！告诉我你做了什么？"

translate chinese chinese_4585407_153:
    old "[mo2] I have done nothing... I don't know what you're talking about..."
    new "[mo2] 我什么都没做……我不知道你在说什么……"

translate chinese chinese_2305039_154:
    old "You're not gonna fool me... Let me see your hands now! What are you hiding?"
    new "你别想骗我……把手拿出来给我看看！你在藏什么？"

translate chinese chinese_8286868_155:
    old "What the fuck!? You are a fucking pervert!"
    new "妈的！你真是个变态！"

translate chinese chinese_0100574_156:
    old "Why do you have a fucking boner right now?"
    new "你现在为什么这么硬？"

translate chinese chinese_1587840_157:
    old "[mo2]... I- I c- can explai-"
    new "[mo2]... 我我我可以解释..."

translate chinese chinese_9793118_158:
    old "Explain what?"
    new "解释什么？"

translate chinese chinese_5777103_159:
    old "That you got fucking horny and now you're having a BONER IN FRONT OF ME!?"
    new "你特么兴奋了，现在在我面前硬起来了！？"

translate chinese chinese_3959736_160:
    old "N- not r- really..."
    new "不……不是真的……"

translate chinese chinese_7382572_161:
    old "Bullcrap!"
    new "胡说八道！"

translate chinese chinese_4275943_162:
    old "I've had a pretty shitty day and now this... BUT! You'll see... Little motherfucker... You'll see!"
    new "我今天过得糟透了，结果还遇到这种事……但是！你会看到的……小王八蛋……你会看到的！"

translate chinese chinese_7596409_163:
    old "W- What? "
    new "什、什么？"

translate chinese chinese_8050765_164:
    old "Get on the floor... NOW!"
    new "趴下……马上！"

translate chinese chinese_7303975_165:
    old "O- On t- the f- floor? W- why?"
    new "O- 在- 在地板上？为- 为什么？"

translate chinese chinese_3847599_166:
    old "I've given you an order! Do it, you are a stupid pervert... Do what I'm telling you and do it now."
    new "我命令你！去做，你这个愚蠢的色鬼……照我说的做，现在就做。"

translate chinese chinese_2917223_167:
    old "(Oh fuck!)"
    new "（哦操！）"

translate chinese chinese_7870491_168:
    old "Your knees on the floor NOW!"
    new "现在把膝盖放到地上！"

translate chinese chinese_3449346_169:
    old "A- alright... Uhh."
    new "好……啊。"

translate chinese chinese_4017354_170:
    old "I'll have fun with you... You get horny here... I give you shit!"
    new "我会和你玩的……你在这里兴奋了……我就给你点刺激！"

translate chinese chinese_5067573_171:
    old "You will suck my foot!"
    new "你会给我舔脚的！"

translate chinese chinese_0188924_172:
    old "W- what!? Do you want me to suck you-"
    new "什、什么！？你想让我吸你—"

translate chinese chinese_3575538_173:
    old "WHAT? WHY are you questioning me? I've just said, SUCK MY FOOT!"
    new "什么？你为什么质疑我？我刚才说了，舔我的脚！"

translate chinese chinese_8328774_174:
    old "Go! Disappear from here... I don't want to see you."
    new "滚！从这里消失……我不想再看到你。"

translate chinese chinese_2730487_175:
    old "B- but what about the job? Can I c- come back?"
    new "可是工作怎么办？我还能回来吗？"

translate chinese chinese_1339406_176:
    old "Yes, whatever... Just go away."
    new "好吧，随便你…… just走开吧。"

translate chinese chinese_7208774_177:
    old "S- So am I hired?"
    new "那我被雇用了？"

translate chinese chinese_9711369_178:
    old "Are you stupid or what? I just said YES! Now, GET OUT!"
    new "你傻啊还是怎么的？我刚刚说了YES！现在，滚出去！"

translate chinese chinese_0681237_179:
    old "Fuck! That was weird..."
    new "操！那真是诡异……"

translate chinese chinese_8129518_180:
    old "Oh, hi [mo1rel], how are you? A bit better?"
    new "哦，嗨 [mo1rel]，你好吗？好一点了吗？"

translate chinese chinese_8721861_181:
    old "Hi honey, I'm ok... Not that good but I guess I'll be fine eventually..."
    new "亲爱的，我没事……虽然不是很好，但我想总归会好起来的……"

translate chinese chinese_3360863_182:
    old "I'm still worried about our economic situation..."
    new "我还在担心我们的经济状况……"

translate chinese chinese_6086532_183:
    old "No [mo1rel]! You don't have to worry about it... I got a job and I'll be able to help you."
    new "不[mo1rel]！你不用担心……我找到了工作，能帮你了。"

translate chinese chinese_5830967_184:
    old "A job? How? Where are you working?"
    new "工作？怎么了？你在哪儿上班？"

translate chinese chinese_4167682_185:
    old "Hmm... I'm working in [mo2]'s office... Basically, I just started but yeah... It's good that I'll have some money to help..."
    new "嗯……我在[mo2]的办公室工作……基本上刚起步吧……有份收入帮忙挺好的……"

translate chinese chinese_1323652_186:
    old "[mo2]? Are you serious?"
    new "[mo2]？你是认真的吗？"

translate chinese chinese_7046781_187:
    old "Yes, she gave me a chance to work for her..."
    new "是的，她给了我一个为她工作的机会……"

translate chinese chinese_5187286_188:
    old "And... Is she fine? Hmm, has she asked for me or anything...?"
    new "而且……她还好吗？嗯，她有没有问我什么的……？"

translate chinese chinese_2076211_189:
    old "She's fine [mo1rel]... You know, I haven't really talked much to her..."
    new "她还好[mo1rel]……你知道，我和她其实没说过多少话……"

translate chinese chinese_0913894_190:
    old "Ok... Yeah, I assume she's fine... Probably better than me..."
    new "好吧……是的，我猜她挺好的……可能比我好……"

translate chinese chinese_7347959_191:
    old "Honey, go get some rest... I guess you've been tired since you started working..."
    new "亲爱的，去休息一下吧……我想从你开始工作就没怎么休息过……"

translate chinese chinese_4288212_192:
    old "Kinda, today it's been a very long and hard day... I'm gonna head to my room."
    new "有点儿，今天真是漫长又辛苦的一天……我要回房间了。"

translate chinese chinese_8088715_193:
    old "I imagine how hard it is working with her..."
    new "我想象着和她一起工作有多难……"

translate chinese chinese_5024014_194:
    old "(Well... It was hard, quite literally...)"
    new "（嗯……那真的很艰难，字面意义上就是如此……）"

translate chinese chinese_7655557_195:
    old "If you need anything just tell me, ok? Love you [mo1rel]."
    new "如果你需要什么就告诉我，好吗？爱你 [mo1rel]。"

translate chinese chinese_1424298_196:
    old "Bye honey, love you too."
    new "拜拜宝贝，我也爱你。"

translate chinese chinese_5524793_197:
    old "Hmm, [mo1rel] is feeling really sad for [mo2]..."
    new "嗯，[mo1rel] 对 [mo2] 非常难过..."

translate chinese chinese_9215252_198:
    old "And the worst part is that she misses her a lot but [mo2] doesn't even ask for her."
    new "最糟糕的是，她非常想念她，但[mo2]甚至不来找她。"

translate chinese chinese_7553224_199:
    old "I should find the way to talk with [mo2] about my [mo1rel]... I'll see."
    new "我得找个办法和[mo2]谈谈我的[mo1rel]... 看情况吧。"

translate chinese chinese_5136032_200:
    old "Hey Kylee! What's up?"
    new "嘿，凯莉！最近怎么样？"

translate chinese chinese_4700016_201:
    old "I'm great. What about You?"
    new "我很好。你呢？"

translate chinese chinese_6256509_202:
    old "Well, I got a job!"
    new "嗯，我找到工作了！"

translate chinese chinese_8462920_203:
    old "Cool, finally man! What's it about?"
    new "酷，终于来了！是关于什么的？"

translate chinese chinese_1783535_204:
    old "That's the not so cool part... I'm working with [mo2]..."
    new "不酷的是……我正在和[mo2]合作……"

translate chinese chinese_5619637_205:
    old "[mo2]? Really?... But that woman hates you..."
    new "[mo2]？真是这样... 但是那个女人恨你啊..."

translate chinese chinese_6691767_206:
    old "What are you doing for her?"
    new "你为她做什么了？"

translate chinese chinese_7739564_207:
    old "Hmm... Just l- like... delivery guy...."
    new "嗯……就比如……送餐的……"

translate chinese chinese_0518743_208:
    old "I see... Well you have talent for that, don't you? Hahaha. "
    new "我明白了……不过你在这方面很有天赋吧？哈哈。"

translate chinese chinese_8860617_209:
    old "Yeah, so funny... "
    new "是啊，真搞笑……"

translate chinese chinese_9677358_210:
    old "At least you finally got a job."
    new "至少你终于找到工作了。"

translate chinese chinese_4821501_211:
    old "Hmm, I know... I know..."
    new "嗯，我知道……我知道……"

translate chinese chinese_7451193_212:
    old "Today was a really weird day, I need some rest, see you."
    new "今天真是怪异的一天，我需要休息了，再见。"

translate chinese chinese_9813969_213:
    old "I believe you, Hahaha, see you."
    new "我相信你，哈哈，再见。"

translate chinese chinese_6662640_214:
    old "Hi [pla], how's it going?"
    new "嗨 [pla]，最近怎么样？"

translate chinese chinese_0907395_215:
    old "Hello Akita, all good... Getting involved in the job."
    new "喂，秋田，一切还好……已经开始忙工作了。"

translate chinese chinese_8169278_216:
    old "Oh great, so are you ready to start with the new deliveries?"
    new "哦，好的，那你准备好开始新的送货了吗？"

translate chinese chinese_2185738_217:
    old "Yeah, please explain to me what I have to do."
    new "好吧，请告诉我我该怎么做。"

translate chinese chinese_8543255_218:
    old "Well, it really is very simple, at the moment we must send correspondence from some projects to three specific places."
    new "好吧，这真的很简单，目前我们必须把一些项目的文件送到三个特定的地方。"

translate chinese chinese_0034012_219:
    old "They all have a different format depending on where they should go."
    new "它们的格式都不同，取决于它们应该放在哪里。"

translate chinese chinese_6454619_220:
    old "For example, all mayoral documents have a red border."
    new "比如，所有的市长文件都有红色边框。"

translate chinese chinese_5019152_221:
    old "While the documents that go to the bank are green."
    new "而送到银行的文件是绿色的。"

translate chinese chinese_3254033_222:
    old "And finally the yellow documents for the factory."
    new "最后是工厂的黄色文件。"

translate chinese chinese_4618537_223:
    old "Red, green and yellow, got it."
    new "红、绿和黄，记住了。"

translate chinese chinese_0343324_224:
    old "It shouldn't be difficult at all, you just need to send them quickly to reach all the deliveries of the day."
    new "根本就没什么难的，你只需要快速发送它们就能完成全天的配送了。"

translate chinese chinese_7925351_225:
    old "Anyway if you need anything else just let me know."
    new "反正如果你还需要什么就告诉我吧。"

translate chinese chinese_6707176_226:
    old "Alright, thank you."
    new "好的，谢谢。"

translate chinese chinese_0698725_227:
    old "So? Are you ready to start the deliveries?"
    new "那么，你准备好开始送货了吗？"

translate chinese chinese_6090730_228:
    old "Sure! Let's do it."
    new "行！咱们就来吧。"

translate chinese chinese_2401533_229:
    old "So do you think I'm paying to do a shitty job? Is that what you think?"
    new "所以你觉得我在花钱做糟糕的工作吗？是这个意思吗？"

translate chinese chinese_0820917_230:
    old "No! No [mo2]! I'm sorry... I'm still learning but I promise I'll do it better."
    new "不！不要[mo2]！对不起……我还在学习，但我保证我会做得更好。"

translate chinese chinese_2530776_231:
    old "You're an idiot... I seriously doubt you'll do it better..."
    new "你真是个白痴……我 seriously 怀疑你能做得更好……"

translate chinese chinese_4724031_232:
    old "I can let this go... You gotta learn a lesson out of this."
    new "我可以放过你……但你得从这件事中吸取教训。"

translate chinese chinese_1175453_233:
    old "A- A l- lesson? But I just started working with you..."
    new "一、一节课？但我才刚和你开始工作..."

translate chinese chinese_3357953_234:
    old "And now you're questioning my decisions... You better change that fucking shitty behavior or you'll suffer in this office."
    new "你现在竟然质疑我的决定……你最好改改这该死的臭毛病，否则你就在这办公室里等着倒霉吧。"

translate chinese chinese_9642416_235:
    old "Do you understand that?"
    new "你明白这一点吗？"

translate chinese chinese_4533714_236:
    old "DO YOU? I'm asking..."
    new "你有吗？我在问……"

translate chinese chinese_0419060_237:
    old "Y- Yeah... I do."
    new "嗯……是的。"

translate chinese chinese_0063093_238:
    old "Good! Now get on the floor... You'll see what it's like not doing a good job for me..."
    new "好！现在趴下……你会知道不好好为我服务的后果……"

translate chinese chinese_0472167_239:
    old "I guess lastime wasn't enough for you... You deserve to be on the floor where you belong!"
    new "看来上次还不够让你满足……你这种人就应该待在地上！"

translate chinese chinese_0162576_240:
    old "You're my little bitch on the floor... Waiting for me to feed you."
    new "你是我的小贱货……在地上等着我喂你。"

translate chinese chinese_9088380_241:
    old "That's how you should be treated, like the cockroach that you are!"
    new "就应该这样对你，就像对你这样的臭虫一样！"

translate chinese chinese_1931136_242:
    old "You got a hardon?! Ughh... That's disgusting!"
    new "你硬起来了?! 哼……真恶心！"

translate chinese chinese_3224090_243:
    old "Alright, if this is what a pervert wants, maybe I should use other methods of punishment."
    new "好吧，如果这就是色狼想要的，那我也许应该用其他方法惩罚他。"

translate chinese chinese_8686560_244:
    old "Let's see if this teaches you a lesson!"
    new "看看这个能不能让你长点记性！"

translate chinese chinese_1967308_245:
    old "[mo2]? Hmm, I- I wanted to tell you something..."
    new "[mo2]？嗯，我——我想告诉你件事……"

translate chinese chinese_0162636_246:
    old "Be quick and get out from here!"
    new "快点，从这里出去！"

translate chinese chinese_4843854_247:
    old "It's about my [mo1rel], you know she has been asking for you... I don't know if maybe you could call her or you know... Something."
    new "是关于我的[mo1rel]，你知道她一直在找你……不知道你能不能给她打个电话或者什么的。"

translate chinese chinese_6339832_248:
    old "Oh gosh! Really?"
    new "天啊！真的吗？"

translate chinese chinese_9400010_249:
    old "I won't talk to her."
    new "我不会跟她说话的。"

translate chinese chinese_9819714_250:
    old "Now just get out idiot! I feel gross just by seeing you."
    new "现在给我滚开白痴！光看你我就觉得恶心。"

translate chinese chinese_5692015_251:
    old "What am I doing?"
    new "我在干什么？"

translate chinese chinese_3136511_252:
    old "[mo2] is crazy... I can't keep doing whatever she wants."
    new "[mo2] 真疯了……我不能一直随她的意。"

translate chinese chinese_5288461_253:
    old "Argh!"
    new "啊！"

translate chinese chinese_0536073_254:
    old "Hello Akita, all good..."
    new "喂，秋田，一切还好……"

translate chinese chinese_0973388_255:
    old "Great! You know what you've to do... So just let me know if you need help."
    new "太好了！你知道该怎么做……所以如果需要帮忙就告诉我。"

translate chinese chinese_0192716_256:
    old "I would like to know if all the documents that must be sent today are ready?"
    new "我想知道今天必须发送的所有文件都准备好了吗？"

translate chinese chinese_0950191_257:
    old "Hmm, There are still several documents missing that [mo2] must sign, if you come in the afternoon I will have them ready for you."
    new "嗯，还有一些文件[mo2]必须签字，如果你下午来，我会准备好给你。"

translate chinese chinese_4678205_258:
    old "Great, see you later."
    new "好的，回头见。"

translate chinese chinese_7915355_259:
    old "Yes, I got all of them."
    new "是的，我都搞定了。"

translate chinese chinese_1677300_260:
    old "Oh, perfect."
    new "哦，太好了。"

translate chinese chinese_7824804_261:
    old "Could you please explain to me again the what I have to do."
    new "你能再给我解释一遍我该做什么吗？"

translate chinese chinese_2698377_262:
    old "Sure, it's very simple, at the moment we must send correspondence from some projects to three specific places."
    new "好的，很简单，我们现在必须把一些项目的文件发送到三个特定的地方。"

translate chinese chinese_8412146_263:
    old "For example, all documents sent to the mayor or his office have a red frame."
    new "例如，所有发给市长或他办公室的文件都有一个红色边框。"

translate chinese chinese_7265195_264:
    old "Red, green and yellow, got it, "
    new "红、绿和黄，记住了。"

translate chinese chinese_5450123_265:
    old "Wow, You're good at this!"
    new "wow, 你真擅长这个！"

translate chinese chinese_3379172_266:
    old "Haha, thanks! I'm doing my best..."
    new "哈哈，谢谢！我正在尽力..."

translate chinese chinese_2781566_267:
    old "Good job, keep it up!"
    new "干得好，继续保持！"

translate chinese chinese_2151625_268:
    old "I've to... You know how [mo2] is..."
    new "我得……你知道[mo2]是怎么样的……"

translate chinese chinese_9319263_269:
    old "Yeah, I totally understand."
    new "嗯，我完全明白。"

translate chinese chinese_7561574_270:
    old "Hey, do you know if I can talk to [mo2]?"
    new "嘿，你知道我能不能和[mo2]说话吗？"

translate chinese chinese_3141858_271:
    old "Uhh, well she is busy all the time, I don't think I will attend to you, unless it's to scold or punish you..."
    new "呃，她一直很忙，我觉得我不会管你的，除非是来责骂或惩罚你……"

translate chinese chinese_3582003_272:
    old "Hmm, right... Ok, thank you Akita."
    new "嗯，对了……好的，谢谢阿基塔。"

translate chinese chinese_6022951_273:
    old "Have a good day [pla]."
    new "祝你今天愉快，[pla]。"

translate chinese chinese_4790089_274:
    old "Hmm maybe, I shouldn't be so good at this, if I want to have the chance to speak with [mo2] whenever she calls me to her office..."
    new "嗯，也许我不应该这么擅长这个，如果我想有机会在[mo2]叫我到办公室时和她说话……"

translate chinese chinese_1218349_275:
    old "Maybe if I do bad work, [mo2] will call me to break my balls and I'll get the chance to talk to her about [mo1rel]..."
    new "也许如果我故意把工作搞砸，[mo2]会叫我过去训斥我，那样我就有机会跟她谈谈[mo1rel]了……"

translate chinese chinese_2143606_276:
    old "Oh man, I'm sure I will regret this."
    new "哦 man，我敢肯定我会后悔的。"

translate chinese chinese_7208700_277:
    old "Hmm... Sorry [pla], I hope next time you can do it better."
    new "嗯……对不起[pla]，希望下次你能做得更好。"

translate chinese chinese_1414664_278:
    old "Argh! Yes... I'll be more focused next time, sorry."
    new "啊！好吧……下次我会更专注的，对不起。"

translate chinese chinese_4956647_279:
    old "It's fine, just do your best because you know how [mo2] is, she'll give you shit if you keep failing."
    new "没事，尽力吧，你知道[mo2]的，如果你一直失败她会骂你的。"

translate chinese chinese_2839013_280:
    old "Gulp, I guess it's time."
    new "gulp, 看来时候到了。"

translate chinese chinese_2645172_281:
    old "Good luck..."
    new "祝你好运……"

translate chinese chinese_7690873_282:
    old "I know you were stupid but I didn't imagine this much."
    new "我知道你挺傻的，但没想到会这么傻。"

translate chinese chinese_4782580_283:
    old "Listen, I- I know I did wrong again but... I- I am sorry [mo2]."
    new "听好，我……我知道我又错了但是……我真的对不起[mo2]。"

translate chinese chinese_5950055_284:
    old "I'll be more careful next time."
    new "下次我会小心点。"

translate chinese chinese_7615285_285:
    old "Yeah... Whatever... I don't care about the next time..."
    new "嗯……随便吧……我不管下一次了……"

translate chinese chinese_3268924_286:
    old "Now you gotta pay for this one."
    new "现在你得为这个付出代价了。"

translate chinese chinese_8036516_287:
    old "A- Again?"
    new "又——来了？"

translate chinese chinese_9261201_288:
    old "I have done some stuff wrong with you..."
    new "我有些地方对你做得不对..."

translate chinese chinese_6780261_289:
    old "You shouldn't get so much pleasure for all mistakes you've done here..."
    new "你不应该因为在这里犯下的所有错误而感到如此快乐……"

translate chinese chinese_0586189_290:
    old "You have been a lucky idiot!"
    new "你真是个幸运的白痴！"

translate chinese chinese_7104444_291:
    old "But not anymore!"
    new "但现在不一样了！"

translate chinese chinese_8602168_292:
    old "I should get something in return for hiring such a stupid person... And for still paying you."
    new "雇用这么个蠢货，我还得有所回报……而且我还在付你工资。"

translate chinese chinese_0770968_293:
    old "You have been the worst employee I have ever had... The most useless person I have worked with. You're disgusting."
    new "你是我见过最差的员工……一起工作过的人中最无用的一个。你真恶心。"

translate chinese chinese_7360690_294:
    old "What kind of punishment should I give you this time?"
    new "这次该给你什么惩罚呢？"

translate chinese chinese_2305586_295:
    old "I definitely did wrong giving you pleasure, an idiot like you will only learn the hard way."
    new "我确实错了，给你这样的白痴带来快乐，你只会吃苦头的。"

translate chinese chinese_8865727_296:
    old "Then perhaps the best thing is that this time you are the one who gives pleasure, like the useless little bitch you are."
    new "那也许最好的办法就是这次你来给予快乐，就像你这个无用的小贱人一样。"

translate chinese chinese_5869489_297:
    old "I know! Come here!"
    new "我知道！过来！"

translate chinese chinese_8527236_298:
    old "You'll lick my pussy... Let's see if you can do it well or you're completely useless..."
    new "你会舔我的下体……看看你能不能做得好，还是完全没用……"

translate chinese chinese_4180018_299:
    old "W- WHAT? Y- Your puss-"
    new "W-什么？你这"

translate chinese chinese_3951076_300:
    old "I don't understand why you keep talking... More licking and less talking. You're my bitch, remember?"
    new "我不明白你为什么老是说话……多舔少说。记住，你是我的小贱人。"

translate chinese chinese_5683467_301:
    old "[mo2]?"
    new "[mo2]?"

translate chinese chinese_1070852_302:
    old "Well, it's about [mo1], she-"
    new "嗯，这是关于[mo1]的，她"

translate chinese chinese_8808036_303:
    old "Ohh come on, you again with that?"
    new "哦呵，你又来这套？"

translate chinese chinese_2733305_304:
    old "I don't care! Don't waste my time with this bullshit."
    new "我才不在乎！别用这破事浪费我的时间。"

translate chinese chinese_7121151_305:
    old "I'm not going to pay again for all of you leechers..."
    new "我不会再为你们这些寄生虫付钱了..."

translate chinese chinese_1412030_306:
    old "No, isn't about paying-"
    new "不，这并不是关于付款的事——"

translate chinese chinese_3300575_307:
    old "Just go away."
    new "just走开。"

translate chinese chinese_3376282_308:
    old "Hmm, this is not working..."
    new "嗯，这不管用……"

translate chinese chinese_7104958_309:
    old "[pla], [mo1rel] has been locked in her room all day long."
    new "[pla]，[mo1rel] 一整天都待在房间里不出来。"

translate chinese chinese_0082706_310:
    old "Yes... She's so depressed..."
    new "是的……她好沮丧……"

translate chinese chinese_9118496_311:
    old "This is serious... I don't know, we gotta do something."
    new "这很严重……我不知道，我们必须得做点什么。"

translate chinese chinese_1094802_312:
    old "Today I told [mo2] about my [mo1rel] but you know how she is... She refuses to get in touch."
    new "今天我跟[mo2]说了我的[mo1rel]，但你知道她是什么性格……她拒绝联系。"

translate chinese chinese_8898856_313:
    old "She's a proud motherfucker!"
    new "她真是个骄傲的王八蛋！"

translate chinese chinese_7293251_314:
    old "Keep insisting... My [mo1rel] can't be like this... We have to help her."
    new "继续坚持……我的[mo1rel]不会这样的……我们必须帮她。"

translate chinese chinese_0595931_315:
    old "I know... I will..."
    new "我知道……我会……"

translate chinese chinese_4253615_316:
    old "Don't worry Kylee, we'll do something."
    new "别担心，凯莉，我们会做点什么的。"

translate chinese chinese_6122609_317:
    old "I hope we do... See you, then."
    new "希望我们能……到时候见。"

translate chinese chinese_3223272_318:
    old "I definitely have to keep trying to talk with [mo2]."
    new "我 definitely 要继续尝试和 [mo2] 交谈。"

translate chinese chinese_9549086_319:
    old "It really seems you're a big idiot! You keep making the same mistakes..."
    new "你真是个大白痴啊！总是犯同样的错误..."

translate chinese chinese_0836981_320:
    old "I assume you're already imagining how you gonna pay for it..."
    new "我猜你已经在想象该怎么补偿了吧……"

translate chinese chinese_5710982_321:
    old "(Oh God, Now what?)"
    new "（哦上帝，现在怎么办？）"

translate chinese chinese_5269898_322:
    old "[mo2]... I'll try to improve, it's just that... I- I'm worried about other things and it's difficult to focus sometimes."
    new "[mo2]……我会努力改进的，只是……我担心其他的事情，有时候很难集中注意力。"

translate chinese chinese_2410642_323:
    old "I don't CARE! I don't care about your shitty life."
    new "我才不在乎！根本不想管你那破生活。"

translate chinese chinese_7605143_324:
    old "You'll need to focus on this NOW!"
    new "你现在必须集中精力应对这个！"

translate chinese chinese_5562078_325:
    old "Now you will do what I tell you to do! You'll do whatever I want! I'm your Master, I'm the one paying you and you'll follow my orders!"
    new "现在你得听我的！你要做我想让你做的任何事！我是你的主人，我是付钱给你的人，你得服从我的命令！"

translate chinese chinese_2677045_326:
    old "Your job and what you do is shit! Now do what I tell you."
    new "你的工作和做的事都是垃圾！现在照我说的做。"

translate chinese chinese_1620052_327:
    old "Now is the time to pay back the money I'm paying you for all your shitty work."
    new "现在是时候用你的烂工作来偿还我给你的钱了。"

translate chinese chinese_2287344_328:
    old "Come on, you already know what to do."
    new "快点，你已经知道该怎么做。"

translate chinese chinese_8887725_329:
    old "Uhh... A- alright."
    new "呃……好吧。"

translate chinese chinese_6762121_330:
    old "I know you don't wanna hear about my [mo1rel] but... B- But she is not ok, she keeps crying for you..."
    new "我知道你不想听我的[mo1rel]但……她真的不行了，她一直在哭着找你……"

translate chinese chinese_8537903_331:
    old "I think she's getting depressed."
    new "我觉得她快抑郁了。"

translate chinese chinese_8679142_332:
    old "Why don't you call her? Just to... Argh!"
    new "你为什么不给她打电话？就……唉！"

translate chinese chinese_6004237_333:
    old "Crying? Is she that bad?"
    new "哭吗？她有那么差劲？"

translate chinese chinese_7254876_334:
    old "I'm not lying, she's feeling like shit."
    new "我没撒谎，她感觉糟透了。"

translate chinese chinese_1572039_335:
    old "I could visi-"
    new "我可以拜访一下——"

translate chinese chinese_8065978_336:
    old "No! Just stop with that bullshit... And get out..."
    new "别！别再扯那些 bullshit…还有，滚出去…"

translate chinese chinese_7888859_337:
    old "What the... W- what are you doing."
    new "什么... 你你在干什么。"

translate chinese chinese_5463030_338:
    old "Well, I knew you wouldn't learn so I'll have to use more drastic methods."
    new "好吧，我知道你不会学的，所以只好用更激烈的手段了。"

translate chinese chinese_8283309_339:
    old "So I'm going to give you a couple of new lessons, it seems that with you it will always have to be in the hard way."
    new "所以我要给你上几堂新课，看来和你在一起总是得用硬的方式来解决。"

translate chinese chinese_9084337_340:
    old "Alright, undress and lie on the floor."
    new "好吧，脱衣服躺到地上。"

translate chinese chinese_8313583_341:
    old "B- but... I- I don't-"
    new "我—但是……我—我不—"

translate chinese chinese_5766384_342:
    old "Are you questioning your master's orders?"
    new "你在质疑主人的命令吗？"

translate chinese chinese_2273656_343:
    old "No, no, I'm sorry master."
    new "不，不，对不起主人。"

translate chinese chinese_9612787_344:
    old "That sounds a lot better."
    new "听起来好多了。"

translate chinese chinese_0690540_345:
    old "Again? Let me guess, it's about [mo1], isn't it?"
    new "又来了？让我猜猜，是关于[mo1]的吧？"

translate chinese chinese_1566134_346:
    old "Well, yes, she is-"
    new "嗯，是的，她确实-"

translate chinese chinese_5847758_347:
    old "Not today, I really don't have time, I already wasted it all with you."
    new "今天不行，我真的没时间了，已经全都浪费在你身上了。"

translate chinese chinese_3679257_348:
    old "Maybe if you do a good job I wouldn't have to waste time with you."
    new "如果你表现好一点，我就不必浪费时间在你身上了。"

translate chinese chinese_6983594_349:
    old "What a surprise, again complaints about your work."
    new "真没想到，又是关于你工作的抱怨。"

translate chinese chinese_4312643_350:
    old "Could we start, talking about [mo1]?"
    new "我们能不能从[mo1]开始聊起？"

translate chinese chinese_6957803_351:
    old "Do you pretend to be the one who gives the orders?"
    new "你假装自己是发号施令的人吗？"

translate chinese chinese_8350300_352:
    old "No, I'm sorry, master."
    new "不，对不起，主人。"

translate chinese chinese_9324298_353:
    old "That sounds so much better."
    new "听起来好多了。"

translate chinese chinese_2596158_354:
    old "Okay, let's not waste any more time, so get naked and lie down on the floor."
    new "好吧，别浪费时间了，脱光衣服躺在地上。"

translate chinese chinese_4714537_355:
    old "Yes, master."
    new "是的，主人。"

translate chinese chinese_9971102_356:
    old "[mo2]... You can hate this... Torture me if you want... B- But my [mo1rel] is really bad, she's not even eating."
    new "[mo2]……你可以讨厌这个……如果你想的话就折磨我吧……但是我的[mo1rel]真的很糟糕，她甚至都不吃饭了。"

translate chinese chinese_8179931_357:
    old "Visit her, please... Make me work more if you want... But just visit her."
    new "去看看她吧……如果你想让我多工作也没关系……但至少去看看她。"

translate chinese chinese_3814463_358:
    old "Argh! Ok... Let's imagine I'll go... When should I pass by."
    new "唉！好吧……那我们就假设我会去……我什么时候过去合适。"

translate chinese chinese_1331519_359:
    old "Really? Well... Let me check with her. [mo2], thanks! This will make her so happy."
    new "真的吗？那……让我去确认一下。[mo2]，谢谢！这会让她很开心的。"

translate chinese chinese_1168770_360:
    old "Listen little bastard! I'll go just because I wanna see if she is really that bad, not because of you. Got it?"
    new "听好了小混蛋！我只是想去看看她是不是真的那么差劲，不是因为你。懂了吗？"

translate chinese chinese_3832303_361:
    old "Yes, yes... T- Thanks anyway."
    new "好，好……多谢了。"

translate chinese chinese_7568826_362:
    old "Ask her when it's a good time to swing by and I'll be there..."
    new "问她什么时候方便，我会去的..."

translate chinese chinese_5630571_363:
    old "I hope you're not lying to me..."
    new "希望你没骗我……"

translate chinese chinese_9684379_364:
    old "N- No."
    new "不。"

translate chinese chinese_1638016_365:
    old "Fuck! I'll kill you if you're lying to me."
    new "操！如果你骗我，我杀了你。"

translate chinese chinese_0387087_366:
    old "Alright, go away. I have to work."
    new "好了，走开吧。我得工作了。"

translate chinese chinese_5802022_367:
    old "(At least she'll see [mo1rel]... That's something.)"
    new "（至少她会看到[mo1rel]……总算是有点收获。）"

translate chinese chinese_6722542_368:
    old "Hi [mo1rel]! How are you?"
    new "嗨 [mo1rel]！你好吗？"

translate chinese chinese_7153005_369:
    old "Hi honey... I'm fine, and you?"
    new "亲爱的……我很好，你呢？"

translate chinese chinese_3545904_370:
    old "Guess what?"
    new "猜猜怎么着？"

translate chinese chinese_8991447_371:
    old "I don't know, what happened?"
    new "我不知道，发生了什么？"

translate chinese chinese_3348154_372:
    old "[mo2] is coming to see you..."
    new "[mo2]要来看你了..."

translate chinese chinese_3891483_373:
    old "What? [mo2] wants to see me? When?"
    new "什么？[mo2]想见我？什么时候？"

translate chinese chinese_5529935_374:
    old "Well, I talked to her and she said she will come whenever you want..."
    new "嗯，我和她聊了，她说你想什么时候来都行..."

translate chinese chinese_3800445_375:
    old "Oh God! That's great! Tell her to come tomorrow."
    new "哦天啊！太好了！让她明天来吧。"

translate chinese chinese_3916585_376:
    old "I'll have to wear something nice... Yes, tell her that tomorrow is fine and that I'll be waiting for her."
    new "我得穿得体一点……好吧，告诉她明天可以，我会等她的。"

translate chinese chinese_4558633_377:
    old "I'll... And I'm glad you're feeling better now."
    new "我……而且很高兴你现在感觉好多了。"

translate chinese chinese_1407873_378:
    old "Thanks for doing this for me..."
    new "谢谢你为我做这件事……"

translate chinese chinese_6346129_379:
    old "Get some rest, honey... You've been working a lot."
    new "休息一下，亲爱的……你工作太多了。"

translate chinese chinese_7895604_380:
    old "Every day is harder, [mo1rel]... But it's fine as long as you're fine and less worried."
    new "每天都在变难，[mo1rel]……但是只要你过得好，少担心点就好了。"

translate chinese chinese_8546292_381:
    old "I'm heading to my room... Love you [mo1rel]!"
    new "我回房间了……爱你哦[mo1rel]！"

translate chinese chinese_7004111_382:
    old "And here you are again... You are definitely a lost cause."
    new "而你又在这里……你真是无可救药了。"

translate chinese chinese_5625396_383:
    old "I know, I know, I'm sorry..."
    new "我知道，我知道，对不起..."

translate chinese chinese_8477769_384:
    old "However, I actually wanted to talk about the visit- "
    new "不过，我其实想说的是关于那次拜访——"

translate chinese chinese_9013509_385:
    old "Shut up! I give a shit about what you want. I am your master and it's time for your punishment."
    new "闭嘴！我才不管你想要什么。我是你的主人，现在是时候惩罚你了。"

translate chinese chinese_2204631_386:
    old "Get on the floor... That's your place."
    new "趴下……那里才是你的位置。"

translate chinese chinese_5961723_387:
    old "Come on, just a second. I don't want to do this."
    new "快点，就一会儿。我不想去干这个。"

translate chinese chinese_1463465_388:
    old "Get on the fucking floor now..."
    new "赶紧趴下……"

translate chinese chinese_4850088_389:
    old "I- I'm not gonna do it... No, no more."
    new "我……我不做了……不，再也不做了。"

translate chinese chinese_3610207_390:
    old "I'm telling you to get on the fucking floor!"
    new "我让你滚到地板上去！"

translate chinese chinese_1142043_391:
    old "You can't keep doing this, it's humiliating for me."
    new "你不能一直这样，这让我很丢脸。"

translate chinese chinese_2310687_392:
    old "WHAT!? What did you just say to me? Did you say NO to your Master?"
    new "什么！？你刚说什么？你对你主人说不？"

translate chinese chinese_4015904_393:
    old "Do you think you are better than me? I have kicked bigger butts than yours!"
    new "你是不是觉得你比我强？我踢过比你更大的屁股！"

translate chinese chinese_4583124_394:
    old "You're getting in real trouble with me! I'm commanding you, did you get that part?"
    new "你这是在跟我找麻烦！我是命令你，这一点听清楚了没？"

translate chinese chinese_4200427_395:
    old "Don't you dare to say NO to me, you obey to whatever I say because I'm your fucking master and you're nothing..."
    new "你敢说不？你得听我的，因为我是你的操蛋主人，而你什么都不是..."

translate chinese chinese_0496270_396:
    old "You're my little bitch, a cockroach, my slave..."
    new "你是我的小贱人，一只蟑螂，我的奴隶..."

translate chinese chinese_3638881_397:
    old "This time you will really be punished, you must learn to obey your master."
    new "这次你真的会受到惩罚，你必须学会服从主人。"

translate chinese chinese_7638881_398:
    old "Master? May I ask you something?"
    new "主人？我可以问你件事吗？"

translate chinese chinese_6678961_399:
    old "Hmm... You're learning... You're starting to understand..."
    new "嗯……你在进步了……开始懂了……"

translate chinese chinese_9997827_400:
    old "It's good that you ask me... You don't do anything without my permission."
    new "你问我比较好……没有我的允许你不准做什么。"

translate chinese chinese_1477884_401:
    old "Speak..."
    new "说..."

translate chinese chinese_4776513_402:
    old "I spoke to my [mo1rel] and she said you can go and see her today... I- if you want..."
    new "我和你的[mo1rel]谈过了，她说你可以今天去见她……如果你愿意的话……"

translate chinese chinese_4417145_403:
    old "Hmm... Fine... I'm going today... Just want to get it over with..."
    new "嗯……好吧……我今天去…… just想赶紧搞定……"

translate chinese chinese_4548789_404:
    old "T- Thanks..."
    new "谢谢..."

translate chinese chinese_8290525_405:
    old "Alright, now get out!"
    new "好了，现在出去！"

translate chinese chinese_3800484_406:
    old "Oh God, what just happened... At least [mo1rel] will be happy today..."
    new "哦上帝，刚才发生了什么……至少[mo1rel]今天会很开心……"

translate chinese chinese_4307953_407:
    old "I can't keep working here, I need to get away from [mo2]'s office."
    new "我不能再在这里工作了，需要远离[mo2]的办公室。"

translate chinese chinese_9884300_408:
    old "Hi honey, how do I look?"
    new "亲爱的，我看起来怎么样？"

translate chinese chinese_1720294_409:
    old "Wow, you look gorgeous!"
    new "哇，你真漂亮！"

translate chinese chinese_0858501_410:
    old "Oh, really? Thank you honey..."
    new "哦，是吗？谢谢你宝贝..."

translate chinese chinese_1777635_411:
    old "So? Do you have any news about [mo2]?"
    new "所以？你有关于[mo2]的消息吗？"

translate chinese chinese_2250298_412:
    old "Uhh, yes, [mo2] is coming today... If that's what you're asking..."
    new "呃，是的，[mo2]今天会来……如果这是你在问的话……"

translate chinese chinese_5506873_413:
    old "Great! I'm gonna get ready for her."
    new "太好了，我这就准备迎接她。"

translate chinese chinese_3985416_414:
    old "I hope you enjoy seeing her... And if you need anything, just let me know, [mo1rel]..."
    new "希望你能喜欢看到她……有什么需要尽管告诉我，[mo1rel]……"

translate chinese chinese_4699457_415:
    old "Now I gotta go, I need to take a nap..."
    new "现在我得去睡觉了……"

translate chinese chinese_8816085_416:
    old "Sure, take care, honey."
    new "好的，照顾好自己，亲爱的。"

translate chinese chinese_9679202_417:
    old "(Huh? What's that noise?)"
    new "（咦？那是什么声音？）"

translate chinese chinese_9996287_418:
    old "It's on my [mo1rel]'s bedroom..."
    new "在我的[mo1rel]的卧室里..."

translate chinese chinese_0358055_419:
    old "Wow, they are having sex!"
    new "哇，他们正在做爱！"

translate chinese chinese_4284052_420:
    old "Oh my God, I have never been so happy to see someone having sex!"
    new "天啊，我从没见过有人做爱这么让我开心！"

translate chinese chinese_6134801_421:
    old "Fuck! This is great! I won't have to work for [mo2] anymore..."
    new "操！太好了！我不用再为[mo2]工作了..."

translate chinese chinese_6776321_422:
    old "They're back together, everything will be fine and I won't have to go back to her office."
    new "他们复合了，一切都会好起来的，我就不用再去她的办公室了。"

translate chinese chinese_5642001_423:
    old "From now on, I am free! I will no longer have to bear Jane's humiliations!"
    new "从现在开始，我自由了！再也不用忍受简的羞辱了！"

translate chinese chinese_6816692_424:
    old "H- Hey... [mo2], h- how are you?"
    new "嘿... [mo2]，你怎么样？"

translate chinese chinese_4357457_425:
    old "Don't pretend to be a good guy... I know how shitty you're and how pervert you can be."
    new "别装好人了……我知道你有多渣，有多色。"

translate chinese chinese_0792661_426:
    old "I have a business trip, but I'll see you in the office in a few weeks..."
    new "我有个商务旅行，但几周后会在办公室见到你..."

translate chinese chinese_5111737_427:
    old "B- But..."
    new "B- 但是..."

translate chinese chinese_2767407_428:
    old "Excuse me!?"
    new "抱歉！？"

translate chinese chinese_5133753_429:
    old "Did I hear a BUT?"
    new "我听到一个“但是”了吗？"

translate chinese chinese_0944571_430:
    old "I thought you had already learned how you have to talk to me..."
    new "我以为你已经学会该怎么跟我说话了……"

translate chinese chinese_2328608_431:
    old "S- Sorry..."
    new "对...对不起..."

translate chinese chinese_8678477_432:
    old "Master... May I talk to you?"
    new "主人……我可以和你谈谈吗？"

translate chinese chinese_6204156_433:
    old "Now you can, slave."
    new "现在你可以了，奴隶。"

translate chinese chinese_6199634_434:
    old "You said that we'll see each other in the office bu-"
    new "你说我们会办公室见来着bu-"

translate chinese chinese_3329794_435:
    old "Yes, I said it!"
    new "是的，我说了！"

translate chinese chinese_2087778_436:
    old "You'll do whatever I want, nothing's gonna change..."
    new "你会按我的意思行事，什么都不会改变……"

translate chinese chinese_1698721_437:
    old "Regardless of the situation between [mo1] and I, you'll keep obeying me... I'm your master and that won't change."
    new "不管[mo1]和我之间的情况如何，你都会继续服从我……我是你的主人，这一点不会改变。"

translate chinese chinese_0454021_438:
    old "Don't forget that... Now you are my bitch."
    new "别忘了……现在你是我的人了。"

translate chinese chinese_9266283_439:
    old "Y- Yes..."
    new "是的..."

translate chinese chinese_5830149_440:
    old "Oh God... "
    new "哦，天哪……"

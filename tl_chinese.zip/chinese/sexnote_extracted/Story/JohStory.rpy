# auto-tl Qwen Colab

translate chinese chinese_6641318_0:
    old "Oh, hi [pla], I‘m glad you came. Are you ready to start?"
    new "哦，嗨 [pla]，很高兴你能来。准备好了吗？"

translate chinese chinese_1142180_1:
    old "Uhh... Hi, yes, sure."
    new "呃……嗨，好的。"

translate chinese chinese_4553703_2:
    old "Ok, as we discussed last time, I'll need your help with some of my patients."
    new "好的，就像上次讨论的那样，我需要你帮忙照顾一些病人。"

translate chinese chinese_8775810_3:
    old "However, you will need a bit of instruction to gain more experience and do a better job."
    new "不过，你需要一些指导来积累更多经验，才能做得更好。"

translate chinese chinese_4932356_4:
    old "Hmm, ‘Instruction'? What do you mean?"
    new "嗯，‘指令’？你是说什么意思？"

translate chinese chinese_3288255_5:
    old "Just think about it like a class made just for you, I'll provide you with the proper training and tell you what to do."
    new "就当是为你量身定做的课程吧，我会给你提供适当的训练并告诉你该怎么做。"

translate chinese chinese_0267486_6:
    old "Hmm, ok..."
    new "嗯，好吧……"

translate chinese chinese_2991089_7:
    old "Ok, to start you need to know I assist some patients who have, most of the time, some... Hmm, ‘sexual difficulties'..."
    new "好的，首先你需要知道我帮助一些患者，他们大多数时候有一些……嗯，”性方面的问题“……"

translate chinese chinese_8017845_8:
    old "Some of them are married women that don't enjoy their sexuality, this brings a lot of problems to their lives."
    new "其中一些是不享受自己性生活的已婚女性，这给她们的生活带来了许多问题。"

translate chinese chinese_2005500_9:
    old "Hmm, I see."
    new "嗯，我明白了。"

translate chinese chinese_8776400_10:
    old "In other words, I help them to discover and enjoy their sexuality and have more pleasant moments with their partners."
    new "换句话说，我帮助他们发现和享受自己的性欲，与伴侣共度更多愉快的时光。"

translate chinese chinese_8432392_11:
    old "Ok, I got it, but... What do I have to do?"
    new "好吧，我明白了，但是……我该做什么？"

translate chinese chinese_1918630_12:
    old "Well, I know you can support me to achieve success in a lot of patients' treatment like you did with Hinn."
    new "好吧，我知道你能像帮助Hinn那样，在很多病人的治疗中支持我取得成功。"

translate chinese chinese_7754826_13:
    old "L- like I did with... H- Hinn?"
    new "就和……和Hinn一样吗？"

translate chinese chinese_0785452_14:
    old "It's ok, I am pretty conscious about the process we will need to go through so you can do it well."
    new "没关系，我对我们需要经历的过程很清楚，所以你可以做得很好。"

translate chinese chinese_9374484_15:
    old "Don't worry, we will have some lessons to teach you."
    new "放心，我们会有一些课程来教你。"

translate chinese chinese_4764149_16:
    old "Also, I'll be with you at all times, you just have to follow the instructions, okay?"
    new "还有，我会一直陪在你身边的，你只需要按照指示来就行了，好吗？"

translate chinese chinese_1434490_17:
    old "Hmm, got it."
    new "嗯，明白了。"

translate chinese chinese_9151378_18:
    old "I really want you to perform the best way possible and I will ensure you develop the skills you need."
    new "我真的希望你能发挥出最好的水平，我会确保你掌握所需的技能。"

translate chinese chinese_9850637_19:
    old "So, let's not waste any more time and let's go to the practice room!"
    new "好了，别浪费时间了，我们去练习室吧！"

translate chinese chinese_0422050_20:
    old "Well, to start, do you remember that Hinn learned how to please a man? Well, now is your turn!"
    new "好吧，首先，你还记得希恩学会了如何取悦男人吗？现在轮到你了！"

translate chinese chinese_0274816_21:
    old "What I meant [pla] is, I'll teach you how to fuck like a pro..."
    new "我的意思是[pla]，我会教你如何像专业人士一样做爱..."

translate chinese chinese_2511561_22:
    old "At this point I think you must take it more natural since I've already sucked your cock several times so just relax."
    new "到了这地步，我觉得你应该更自然一点，反正我已经吸过你几次了，放松点吧。"

translate chinese chinese_9154289_23:
    old "We are going to start with some oral sex, I want you to show me those skills, so I can be sure my patients are going be satisfied."
    new "我们先来点口交，我要看看你的技术，确保我的客户会满意。"

translate chinese chinese_5471534_24:
    old "W- what? Do you mean you want me to give you... O- oral sex?"
    new "什、什么？你是说你想让我给你...口...口交？"

translate chinese chinese_4897784_25:
    old "Yes, remember, just relax and follow my instructions."
    new "好的，记住，放松点，跟着我的指示来。"

translate chinese chinese_5929364_26:
    old "We are learning and this is part of your process, so, come here and get on your knees."
    new "我们在学习，这是过程的一部分，所以过来，跪下。"

translate chinese chinese_0904599_27:
    old "I can assure you this lesson is going to be useful for you."
    new "我可以保证这节课对你会有用的。"

translate chinese chinese_9838175_28:
    old "And it will be necessary for my patients, and of course, should be amusing for both of us, so, let's start."
    new "这对我病人来说是必要的，当然了，对我们俩来说也会很有趣，所以，我们开始吧。"

translate chinese chinese_5400231_29:
    old "I want you to kiss me, like if that were my mouth, move your tongue carefully, slowly..."
    new "我想让你吻我，就像那是我的嘴一样，小心地、慢慢地移动你的舌头……"

translate chinese chinese_1891745_30:
    old "Just like that, try to keep it wet, and slowly move your tongue a bit faster..."
    new "就这样，保持湿润，然后慢慢加快你的舌头速度……"

translate chinese chinese_3541253_31:
    old "Keep doing it like that... Ahh."
    new "继续这样……啊。"

translate chinese chinese_8789584_32:
    old "Try Again"
    new "再试一次"

translate chinese chinese_3354736_33:
    old "Next Round"
    new "下一回合"

translate chinese chinese_9475880_34:
    old "Oh careful!"
    new "哦，小心！"

translate chinese chinese_7058147_35:
    old "Ouch!"
    new "哎哟！"

translate chinese chinese_4165442_36:
    old "NO! NO! STOP!"
    new "不！不要！停下来！"

translate chinese chinese_0667492_37:
    old "Did I do something wrong?"
    new "我做错什么了吗？"

translate chinese chinese_1694257_38:
    old "Hmm, I think you could do it a lot better..."
    new "嗯，我觉得你可以做得好很多..."

translate chinese chinese_2550800_39:
    old "Softer, the idea is to make the patient experience a lot of pleasure and not the opposite, but we can work on that."
    new "轻一点，目的是让病人体验更多的快感，而不是相反，但我们可以在那方面改进。"

translate chinese chinese_6971217_40:
    old "Hmm... Ok."
    new "嗯……好。"

translate chinese chinese_7804597_41:
    old "Listen, that is something normal, we can always improve our abilities, don't feel bad about this particular moment where it was not as expected, it's ok."
    new "听着，这很正常，我们可以不断提高自己的能力，不要因为这次没达到预期就感到不好，没事的。"

translate chinese chinese_2360312_42:
    old "Unfortunately, our time is up. I think you need to learn a couple of things more before continuing."
    new "不幸的是，时间到了。我觉得在继续之前你还需要学几件事。"

translate chinese chinese_8081012_43:
    old "Perfect, see you later [pla]."
    new "完美，再见[pla]。"

translate chinese chinese_9337319_44:
    old "See you too, bye!"
    new "也看到你了，再见！"

translate chinese chinese_0923521_45:
    old "Congratulations, you definitely have what it takes, so, we can do a perfect team."
    new "恭喜你，你绝对有这个能力，所以我们能组成完美的搭档。"

translate chinese chinese_8402894_46:
    old "I can see you have other talents and they are pretty valuable."
    new "我能看出来你还有其他特长，而且挺有价值的。"

translate chinese chinese_7409871_47:
    old "Yes, I'm very satisfied, you did just fine."
    new "是的，我很满意，你做得很好。"

translate chinese chinese_4536332_48:
    old "I am glad you liked it."
    new "很高兴你喜欢。"

translate chinese chinese_4240057_49:
    old "It can be better but I am proud of you, I can count on you to make the best for my patients."
    new "还可以更好，但我为你骄傲，我相信你能为我的病人做到最好。"

translate chinese chinese_4754807_50:
    old "The great news is that these lessons are going to be quite fascinating for me."
    new "好消息是这些课程对我来说会非常有趣。"

translate chinese chinese_8870785_51:
    old "I think that's all, you need to rest a bit, I am exhausted but I have some patients I have scheduled."
    new "我想就这些了，你需要休息一下，我虽然也累了，但还有几个病人要见。"

translate chinese chinese_3676503_52:
    old "Ok, thank you."
    new "好的，谢谢。"

translate chinese chinese_8411527_53:
    old "It was a pleasure... I hope you're on time tomorrow."
    new "很愉快……希望你明天准时来。"

translate chinese chinese_9491456_54:
    old "I'll be waiting for you, there are some lessons we need to have go through."
    new "我会等着你，有些事情我们需要谈谈。"

translate chinese chinese_7400860_55:
    old "Perfect, see you tomorrow."
    new "完美，明天见。"

translate chinese chinese_8621711_56:
    old "Hi [pla], glad to see you. There's no time to lose, let's go to the room."
    new "你好[pla]，见到你很高兴。时间不等人，我们去房间吧。"

translate chinese chinese_4245798_57:
    old "Uhhh... Ok!"
    new "呃……好！"

translate chinese chinese_5766988_58:
    old "We need to repeat the session we were practising last time, I need you to finish it successfully."
    new "我们需要重复上次练习的环节，你需要成功完成它。"

translate chinese chinese_2182547_59:
    old "I have to budget my time because I have a couple of patients coming earlier, so please help me to finish on time."
    new "我得安排好时间，因为早些时候有几个病人要来，所以请帮我按时完成好吗？"

translate chinese chinese_9912107_60:
    old "Let's start, you already know how to do it, so please do your best."
    new "开始吧，你已经知道怎么做了，所以请尽力而为。"

translate chinese chinese_4712003_61:
    old "Uhh, Ok..."
    new "呃，好吧……"

translate chinese chinese_0789477_62:
    old "Keep doing it like that... Ahh..."
    new "继续这样……啊……"

translate chinese chinese_6204178_63:
    old "Welcome [pla], I'm happy to have you here, we have a lot of things to work on."
    new "欢迎[pla]，很高兴你能来，我们有很多事情要处理。"

translate chinese chinese_1811006_64:
    old "Hi... Uhh, ok, ok, I- I am ready."
    new "喂……嗯，好，好，我——我准备好了。"

translate chinese chinese_6784602_65:
    old "Wonderful! Today we have a new goal I want you to work on."
    new "太好了！今天有个新目标想让你去完成。"

translate chinese chinese_4827944_66:
    old "Ok, what is it?"
    new "好吧，是什么事？"

translate chinese chinese_4221204_67:
    old "I think it's something kind of new for you but I can walk you through it. It's related to self-mastery."
    new "我觉得这对你来说可能是有点新鲜的东西，但我可以带你一步步来。这和自我控制有关。"

translate chinese chinese_3658685_68:
    old "'Self-mastery'?"
    new "“自我控制”？"

translate chinese chinese_6923418_69:
    old "Yeah, let me explain it to you, most of the time our desires or emotions can be really difficult to control..."
    new "嗯，让我解释一下，很多时候我们的欲望或情绪真的很难控制……"

translate chinese chinese_6659869_70:
    old "Once you can defeat them, you will be strong enough to act without their control."
    new "一旦你能击败他们，你就会变得足够强大，不再受他们的控制。"

translate chinese chinese_3129248_71:
    old "The most visible aspect of this exercise will be that you can last longer during any kind of sexual interaction."
    new "这个练习最明显的效果就是你能在这类性互动中持续更长时间。"

translate chinese chinese_3297290_72:
    old "Hmm interesting..."
    new "嗯，有趣……"

translate chinese chinese_4191876_73:
    old "Talking about our sexual performance, we need to be sure we can control our body to react the exact way we want..."
    new "说到性表现，我们需要确保能控制身体做出我们想要的反应……"

translate chinese chinese_4054934_74:
    old "That way we can guarantee your sexual partner reaches the orgasm before you do."
    new "这样可以保证你的性伴侣在你之前达到高潮。"

translate chinese chinese_2630586_75:
    old "That's cool, so today we are going to see if your performance can be mastered without cumming."
    new "那好吧，今天我们就来看看你能不能在不射的情况下掌握这些技巧。"

translate chinese chinese_7713633_76:
    old "Or we will need to work on it harder so you can perform better with the patients."
    new "或者我们需要更努力地练习，这样你才能在面对病人时表现得更好。"

translate chinese chinese_2484587_77:
    old "Ok, and how are we going to verify that?"
    new "好的，那我们要怎么验证呢？"

translate chinese chinese_5195824_78:
    old "That's an interesting part, I want you to relax and just be yourself, I will do the rest of the job, let's go to the room."
    new "那是个有趣的部分，我想让你放松一点，做自己就好，剩下的交给我，我们去房间吧。"

translate chinese chinese_8546648_79:
    old "Uhh... Ok."
    new "呃……好。"

translate chinese chinese_5200449_80:
    old "Please take off your pants, so we can start..."
    new "请把裤子脱了，我们可以开始了..."

translate chinese chinese_7378015_81:
    old "I want to test how long you can last, so, get ready because I will use my mouth, I will give you the best blowjob of your entire life."
    new "我想测试你能撑多久，所以准备好，我会用嘴给你一生中最好的口交。"

translate chinese chinese_9377950_82:
    old "So, come on, take off your pants, I'm going to make myself comfortable too."
    new "好了，把裤子脱了，我也要准备好了。"

translate chinese chinese_5157324_83:
    old "WOW!"
    new "哇！"

translate chinese chinese_3170530_84:
    old "I am glad you like them because I want you to look at them carefully."
    new "我很高兴你喜欢它们，因为我想让你仔细看看。"

translate chinese chinese_8054526_85:
    old "I need you to be very stimulated to test your endurance."
    new "我需要你非常兴奋来测试你的耐力。"

translate chinese chinese_8599976_86:
    old "The idea is that, even though all sensorial stimulation you feel, you can control your body and don't cum."
    new "想法是，即使你感受到所有的感官刺激，也能控制自己的身体不射精。"

translate chinese chinese_6169050_87:
    old "Are you serious?"
    new "你是认真的吗？"

translate chinese chinese_4299043_88:
    old "Absolutely, under any circumstance you must not cum, until I say you can, ok?"
    new "绝对不行，无论什么情况都不要射，直到我说可以为止，好吗？"

translate chinese chinese_4824833_89:
    old "Hmm ok..."
    new "嗯，好吧……"

translate chinese chinese_1581523_90:
    old "Ok now it comes the hard part, I will suck your entire dick, are you ready?"
    new "好的，现在要开始难的部分了，我会吸你整个 dicks，准备好了吗？"

translate chinese chinese_0796006_91:
    old "(Oh God, it feels so good...)"
    new "（哦天啊，感觉真好……）"

translate chinese chinese_5215322_92:
    old "Dr. Johnson I- I- ... Ughhhh..."
    new "约翰逊博士，我……我……呃呃呃……"

translate chinese chinese_0859898_93:
    old "OH NO! You came before!"
    new "哦不！你先来了！"

translate chinese chinese_7333520_94:
    old "I- I am... Sorry..."
    new "我……对不起……"

translate chinese chinese_7923387_95:
    old "It's ok, it's something we knew could happen so calm down, what a mess you did..."
    new "没事，这是我们预料到可能会发生的事，冷静点，你搞得一团糟……"

translate chinese chinese_7953442_96:
    old "I'm sorry, it was my fault."
    new "对不起，是我的错。"

translate chinese chinese_7047785_97:
    old "It's ok, it wasn't that bad, the thing is that we now need to have this in mind to make sure you can control yourself."
    new "没关系，也没那么糟，关键是现在我们需要记住这件事，确保你能控制自己。"

translate chinese chinese_2404541_98:
    old "We can't have this mess with a patient..."
    new "我们不能让这种情况发生在病人身上……"

translate chinese chinese_4195165_99:
    old "How can I do it better?"
    new "我该怎么做得更好？"

translate chinese chinese_1235812_100:
    old "I will help you, don't worry."
    new "我会帮你，别担心。"

translate chinese chinese_4093796_101:
    old "But, I am running out of time, the patients are about to arrive and I need to clean this mess..."
    new "但是，我的时间快不够了，病人就要来了，我还得清理这 mess..."

translate chinese chinese_3732546_102:
    old "I hope you be on time tomorrow, We need to correct this behavior."
    new "希望你明天准时来，我们需要纠正这种行为。"

translate chinese chinese_1155865_103:
    old "I am very sorry to disappoint you."
    new "非常抱歉让你失望了。"

translate chinese chinese_7964497_104:
    old "There is nothing we can't improve, I'm sure next time it will be different."
    new "没有什么是我们不能改进的，我相信下次会不同的。"

translate chinese chinese_4440571_105:
    old "I think that's all, you need to rest a bit, I have some patients scheduled, so, see you later."
    new "我想就这些了，你需要休息一下，我还有病人要见，所以，回头见。"

translate chinese chinese_3557727_106:
    old "We will need to repeat this exercise, I'll be waiting for you."
    new "我们需要重复这个练习，我会等着你。"

translate chinese chinese_0655131_107:
    old "Ok, see you later..."
    new "好吧，回头见..."

translate chinese chinese_7392149_108:
    old "Oh great! That was good, you have surprised me! What a huge load, it's delicious."
    new "哦，太好了！这真不错，你吓到我了！这么大一份，真好吃。"

translate chinese chinese_1604691_109:
    old "Congratulations, I can see that you havea lot more control of body."
    new "恭喜你，我看得出来你现在对身体的控制好多了。"

translate chinese chinese_8731428_110:
    old "All right, I'm gonna clean this mess. My next patient is about to arrive... I hope you be on time tomorrow."
    new "好吧，我要去收拾这个烂摊子了。下一个病人就要来了……希望你明天准时出现。"

translate chinese chinese_6864544_111:
    old "Ok, there are some lessons we need to have to go through."
    new "好吧，有些课我们需要上一上。"

translate chinese chinese_3471863_112:
    old "Got it, see you tomorrow then."
    new "好的，那明天见。"

translate chinese chinese_3304593_113:
    old "Fine! Thanks for asking, hope you are doing good too."
    new "好吧！谢谢关心，也希望你一切顺利。"

translate chinese chinese_0385004_114:
    old "Oh absolutely! But I can tell you it will be better just in a moment, Are you ready?"
    new "哦，当然了！但你可以放心，马上就会好起来的，你准备好了吗？"

translate chinese chinese_0783597_115:
    old "Ready? For what?"
    new "准备什么？"

translate chinese chinese_5735343_116:
    old "Well, today we will continue your process to make you able to control yourself, the main focus for today will be performance."
    new "好吧，今天我们将继续你的训练，让你能够控制自己，重点是表现。"

translate chinese chinese_1860497_117:
    old "Performance?"
    new "表演？"

translate chinese chinese_2670201_118:
    old "Yes, we need to test your capabilities to accomplish the tasks that you will have..."
    new "是的，我们需要测试你的能力，看看你能否完成将要交给你的任务……"

translate chinese chinese_6997835_119:
    old "So, you need to work not only on the time you can last, but the quality of that time."
    new "所以，你不仅需要提高持久时间，还要提升这段时间的质量。"

translate chinese chinese_7099157_120:
    old "Oh... I understand."
    new "哦……我明白了。"

translate chinese chinese_5092563_121:
    old "Today we have a very nice exercise, so I hope you put all your effort to make a successful session."
    new "今天我们有一个非常好的训练，希望你能全力以赴，让这次训练取得成功。"

translate chinese chinese_5860030_122:
    old "Remember, focus on the rhythm and performance."
    new "记住，要注重节奏和表现。"

translate chinese chinese_2385992_123:
    old "Uhh, ok."
    new "呃，好吧。"

translate chinese chinese_1947595_124:
    old "So, let's go, we will have sex now."
    new "好了，走吧，我们现在就做爱。"

translate chinese chinese_4027982_125:
    old "I will hav-... W- wait, what? Sex?"
    new "我将要… 等等，什么？性？"

translate chinese chinese_7866075_126:
    old "Of course, that is how we can practice, besides, I need to test the quality of my assistant."
    new "当然，这样我们可以练习，而且我还需要测试我的助手的质量。"

translate chinese chinese_7884987_127:
    old "Great, let's get started, first we need to go to the practice room."
    new "好，我们开始吧，首先我们需要去练习室。"

translate chinese chinese_1372920_128:
    old "From this particular exercise and on, we will need to guarantee your partner reaches the orgasm, that is the key."
    new "从这个特定的练习开始，我们需要确保你的伴侣能够达到高潮，这是关键。"

translate chinese chinese_1360113_129:
    old "Ok, I will focus on that."
    new "好的，我会集中精力处理那个的。"

translate chinese chinese_2035566_130:
    old "But, anyways remember to enjoy what you are doing, let's get prepared. Take off your clothes."
    new "不过，无论如何记得享受你正在做的事情，让我们准备一下。脱掉你的衣服。"

translate chinese chinese_6444104_131:
    old "Perfect, now that you are ready let's fuck!"
    new "完美，现在你准备好了，我们开始吧！"

translate chinese chinese_8536088_132:
    old "Ohhh... Ohhh... I- I-"
    new "哦哦... 哦哦... 我- 我-"

translate chinese chinese_8223320_133:
    old "Huh, you finished quite earlier..."
    new "huh，你完得挺早的..."

translate chinese chinese_9241133_134:
    old "I know you are doing a great effort, but I need you to take control of yourself and wait for the right moment."
    new "我知道你在努力，但你需要控制自己，等待时机。"

translate chinese chinese_4308277_135:
    old "I- I'm trying to focus-"
    new "我—我在努力集中—"

translate chinese chinese_1204309_136:
    old "I know, we only need to work harder. "
    new "我知道，我们只需要更努力一点。"

translate chinese chinese_8246675_137:
    old "I think you need to do some workout, so, you can keep your body up until I reach the orgasm."
    new "我觉得你需要锻炼一下，这样等我高潮的时候，你的身体还能跟得上。"

translate chinese chinese_4428682_138:
    old "I will improve, I think I was tired because of the rhythm."
    new "我会改进的，我觉得是因为节奏太累了。"

translate chinese chinese_6203487_139:
    old "Sure you will improve, that's why we are doing this together, so you can develop all the skills you have."
    new "你肯定会进步的，这就是为什么我们要一起做这件事，这样你可以发挥出所有的技能。"

translate chinese chinese_8078482_140:
    old "Don't mention it, let's clean this mess, I have to continue working..."
    new "别提了，咱们先把这烂摊子收拾一下，我得继续工作了……"

translate chinese chinese_1792500_141:
    old "I'm very impressed, you are quite awesome at this, let me tell you the exercise was a complete success."
    new "我非常印象深刻，你真的很擅长这个，让我告诉你，这次练习完全成功了。"

translate chinese chinese_1153789_142:
    old "T- thanks... I did all that I could."
    new "谢……谢谢……我尽力了。"

translate chinese chinese_5662587_143:
    old "Hahaha good job kid, you are doing the exercises very consciously."
    new "哈哈，干得好孩子，你做得非常自觉。"

translate chinese chinese_8545656_144:
    old "Keep working, the benefits will be incredible and remember the benefits won't be only yours..."
    new "继续努力，好处会非常惊人，而且记住这些好处不只是你的……"

translate chinese chinese_2161400_145:
    old "It was a very productive session, so, I hope next time we keep the level as high as today."
    new "这次效率非常高，希望下次还能保持今天的水平。"

translate chinese chinese_4940967_146:
    old "Sure, I will keep working hard."
    new "行，我会继续努力的。"

translate chinese chinese_2728273_147:
    old "Yes... really Hard."
    new "是的……真的很硬。"

translate chinese chinese_5328331_148:
    old "Oh, you are here! Quite on time."
    new "哦，你在这里！挺准时的。"

translate chinese chinese_1461886_149:
    old "Yes, I came a bit earlier."
    new "是的，我来得早了一点。"

translate chinese chinese_4076128_150:
    old "That's perfect, we have a lot to work on."
    new "太好了，我们有很多事情要忙。"

translate chinese chinese_4413369_151:
    old "Ok, I am ready."
    new "好的，我准备好了。"

translate chinese chinese_0324430_152:
    old "Great, today we will work on your strength, the power given on every sexual encounter."
    new "好的，今天我们将提升你的力量，每次性接触都会赋予的力量。"

translate chinese chinese_4969644_153:
    old "Hmm... Strength? What do you mean?"
    new "嗯……力量？你是什么意思？"

translate chinese chinese_7778268_154:
    old "Sex requires a lot of power if you really want to satisfy, I need you to start doing the process beyond the limits."
    new "性爱需要很多能量才能真正满足对方，你需要开始超越极限的过程。"

translate chinese chinese_5606972_155:
    old "Wow, And how can I achieve that?"
    new "哇，那我该怎么做到呢？"

translate chinese chinese_9463008_156:
    old "Well, I need you to focus because you are going to use your dick quite differently."
    new "好吧，我需要你集中注意力，因为你要用你的 dicks 做一些完全不同的事情。"

translate chinese chinese_6309470_157:
    old "You must control your body so you can give a hardcore sex experience."
    new "你必须控制自己的身体，才能给予 hardcore 的性爱体验。"

translate chinese chinese_3040180_158:
    old "Hmm, ok."
    new "嗯，好吧。"

translate chinese chinese_0191842_159:
    old "Let's go ahead to the practice room, I can't wait to get fucke- ... I mean to start the new exercise..."
    new "我们先进练习室吧，我迫不及待想开始新训练了……"

translate chinese chinese_3497188_160:
    old "Ok, previous lesson was focused on endurance and lasting as much as I wanted."
    new "好的，上一节课主要集中在耐力和持续尽可能长的时间。"

translate chinese chinese_3202044_161:
    old "This time I need you to keep this in mind, I want you to be hardcore hitting my pussy really hard."
    new "这次我需要你记住，我要你猛烈地用力弄我。"

translate chinese chinese_9733746_162:
    old "Let's do it, please take off your clothes and get ready."
    new "来吧，请脱掉衣服准备一下。"

translate chinese chinese_7964143_163:
    old "Oh God! This is too much!"
    new "哦天哪！这太夸张了！"

translate chinese chinese_1802788_164:
    old "Did I cum quick, right?"
    new "我射得很快，对吧？"

translate chinese chinese_0288766_165:
    old "Not just that... I'm afraid you are not strong enough, you need to hit harder, some girls will like to be pounded really hard."
    new "不止那样……我怕你还不够强势，你需要打得更重一些，有些女孩喜欢被狠狠地 pounding。"

translate chinese chinese_5450316_166:
    old "[pla], we need to satisfy certain preferences..."
    new "[pla]，我们需要满足某些偏好..."

translate chinese chinese_4090042_167:
    old "This is not a regular sexual encounter you will find really demanding girls that want something harder, and you need to provide that."
    new "这可不是普通的性爱，你会遇到一些非常有要求的女孩，她们想要更激烈的东西，你需要满足她们。"

translate chinese chinese_1856787_168:
    old "You are right, I'm sorry.."
    new "你说得对，对不起.."

translate chinese chinese_0091894_169:
    old "Don't worry I know you can learn... But today I need to get ready for my next patient, so next time we will practice this lesson again."
    new "别担心，我知道你能学会……但是今天我得为下一个病人做准备，所以我们下次再练习这一课。"

translate chinese chinese_1801820_170:
    old "See you later kido."
    new "一会儿见，小子。"

translate chinese chinese_5979224_171:
    old "See you doctor."
    new "医生，再见。"

translate chinese chinese_9712664_172:
    old "You are doing great! Congratulations for this improvement, you definitely approved, my patients will love you."
    new "你做得很好！恭喜你有了这样的进步，你肯定会有提高的，我的病人会喜欢你的。"

translate chinese chinese_7935648_173:
    old "Thank you, I appreciate it."
    new "谢谢你，我真的很感激。"

translate chinese chinese_5612976_174:
    old "The process has been successful, I want you to keep working..."
    new "过程很成功，我希望你继续工作……"

translate chinese chinese_9916252_175:
    old "I guess in the mornings we can continue with these lessons, because I want to... Hmm, help you practice more..."
    new "我想早上我们可以继续这些课程，因为我想……嗯，帮你多练习一下……"

translate chinese chinese_0077159_176:
    old "Oh, ok that sounds good to me..."
    new "哦，好的，听起来不错……"

translate chinese chinese_8715108_177:
    old "Perfect, I'm looking forward to seeing your progress, there are many things we can improve."
    new "完美，我很期待看到你的进步，还有很多我们可以改进的地方。"

translate chinese chinese_1847743_178:
    old "I appreciate your help."
    new "我很感激你的帮助。"

translate chinese chinese_9373511_179:
    old "In our next session we will have a patient to put what we have learned into practice."
    new "在下次课程中，我们将有一个病人来实践我们所学的内容。"

translate chinese chinese_7109903_180:
    old "Don't worry, I will walk you through so we can do an outstanding job."
    new "放心，我会带你一步步来，我们可以做得非常出色。"

translate chinese chinese_6030388_181:
    old "All right, I need you to leave so I can get ready for my next patient, thanks for your great job, it was remarkable."
    new "好吧，你需要离开，让我为下一个病人做准备，感谢你的出色工作，真是棒极了。"

translate chinese chinese_9816060_182:
    old "Bye!"
    new "再见！"

translate chinese chinese_8201415_183:
    old "(I can't believe myself, that dick is driving me so crazy...)"
    new "（我都不敢相信自己，那家伙真的把我搞疯了……）"

translate chinese chinese_9940518_184:
    old "Oh, [pla], I'm glad you came early, there's something I needed to talk to you about before we start."
    new "哦，[pla]，你早来了我挺高兴的，我们开始之前有件事需要和你谈谈。"

translate chinese chinese_4639338_185:
    old "Well, today we're going to work with Angelina, she is a patient who doesn't enjoy having sex."
    new "好吧，今天我们要和Angelina一起工作，她是一个不喜欢性爱的病人。"

translate chinese chinese_3104189_186:
    old "I have tried with several exercises, but she is kind of stuck in the process..."
    new "我试过好几个练习，但她好像卡在过程中了……"

translate chinese chinese_5303663_187:
    old "Also, her marriage is in danger, because she doesn't want to have sex with her husband."
    new "而且她的婚姻也出现了危机，因为她不想和丈夫发生性关系。"

translate chinese chinese_9347593_188:
    old "Oh, that's really bad."
    new "哦，那真的很糟糕。"

translate chinese chinese_2930434_189:
    old "Yes, so we need to have noticeable progress as soon as possible, and we are going to achieve that with your help."
    new "是的，所以我们需要尽快取得明显进展，这需要你的帮助来实现。"

translate chinese chinese_1804567_190:
    old "With m- my... Help?"
    new "用我……的帮助？"

translate chinese chinese_3758036_191:
    old "Well, with the training you've been through we can help..."
    new "好吧，凭借你接受的训练，我们可以帮忙……"

translate chinese chinese_6497596_192:
    old "We will need to apply all the concepts that we have worked on so that she can discover how pleasurable sex is."
    new "我们需要运用所有之前讨论过的概念，让她发现性是多么愉悦的事情。"

translate chinese chinese_0492104_193:
    old "Then everything she learns here, she can put into practice with her husband, and our treatment will be successful."
    new "那么她在这里学到的一切，都可以在实践中用到她丈夫身上，我们的治疗就会成功。"

translate chinese chinese_9184491_194:
    old "Ohhh, that makes sense..."
    new "哦，原来如此……"

translate chinese chinese_3178380_195:
    old "Ok, so, please stay in the practice room and I will let you know when to come in to get involved with the session."
    new "好的，所以请待在练习室里，我会通知你什么时候进来参与的。"

translate chinese chinese_6064127_196:
    old "I will need you to be ready, I mean to have your cock prepared when I call you."
    new "我需要你准备好，我的意思是当我叫你的时候，你的鸡鸡要准备好。"

translate chinese chinese_9441991_197:
    old "Remember to stay focused on her pleasure, you'll have to practice everything we've learned, once Angelina is ready I'll let you know."
    new "记得要专注于她的愉悦，你得把我们学过的一切都实践出来，等安吉丽娜准备好我会通知你的。"

translate chinese chinese_8060563_198:
    old "Ok, now go to the practice room, she could arrive at any time."
    new "好的，现在去练习室，她随时可能会到。"

translate chinese chinese_0814618_199:
    old "Welcome Angelina, it's pretty nice to have you here again."
    new "欢迎天使丽娜，再次见到你真好。"

translate chinese chinese_2620197_200:
    old "Thank you doctor Johnson is good to see you again."
    new "谢谢约翰逊医生，再次见到你真好。"

translate chinese chinese_9563490_201:
    old "I'm very happy to hear that, how is it going?"
    new "听到这个我非常高兴，进展如何？"

translate chinese chinese_4164320_202:
    old "Everything is fine I guess, except for what you already know."
    new "一切都还好吧，除了你已经知道的那件事。"

translate chinese chinese_1718526_203:
    old "Tell me about that please, did you see any improvement since the last session?"
    new "请告诉我详情，自从上次疗程后你有什么进步吗？"

translate chinese chinese_6995124_204:
    old "Hmm... Well, I'm doing the things that you told me to, but I'm not really comfortable when I'm doing it..."
    new "嗯……我在做你让我做的事，但做起来总觉得不太舒服……"

translate chinese chinese_6146550_205:
    old "I have tried all the ways but it feels really disgusting."
    new "我试过所有方法，但感觉真的很恶心。"

translate chinese chinese_1454611_206:
    old "No worries darling, I understand and it's totally ok, it's part of the expectations we had set previously, so it's ok to feel that way..."
    new "放心吧亲爱的，我明白，这样也没问题，这符合我们之前设定的预期，所以有这样的感觉也没关系……"

translate chinese chinese_2451868_207:
    old "You are the only person I feel free to share this with."
    new "你是唯一一个让我觉得可以自由分享这些的人。"

translate chinese chinese_1838564_208:
    old "And I'm here for you, and I'll see to it that we get through this problem once and for all."
    new "而我会在这里支持你，确保我们彻底解决这个问题。"

translate chinese chinese_3044627_209:
    old "I really appreciate that, because I have nothing else to do and..."
    new "我真的很感激，因为我没什么别的事可做，而且..."

translate chinese chinese_6835708_210:
    old "And? Is it everything ok Angelina?"
    new "而且？安吉丽娜，一切都好吗？"

translate chinese chinese_6286454_211:
    old "I think it is not."
    new "我觉得不是这样的。"

translate chinese chinese_0675575_212:
    old "Is there something else you think I need to know?"
    new "还有别的你觉得我需要知道的事情吗？"

translate chinese chinese_8643813_213:
    old "Well, lately we have been fighting a lot because of that."
    new "嗯，最近因为我们那个问题吵了很多次。"

translate chinese chinese_1760033_214:
    old "Oh, darling, I understand how hard it must be, it's not your fault of course."
    new "哦，亲爱的，我明白这对你来说有多难，当然这不是你的错。"

translate chinese chinese_1312169_215:
    old "I'd love to think it's not my fault, but I know it is, it's me not working the way it should."
    new "我真希望这不怪我，但我知道是怪我，是我没有像应该的那样工作。"

translate chinese chinese_0288478_216:
    old "Honey, I know how you feel, but I've seen the progress from a different perspective and I can assure you that you've been doing your best."
    new "亲爱的，我知道你的感受，但从另一个角度看，我可以肯定你已经做得很好了。"

translate chinese chinese_1230538_217:
    old "I'm not sure about that..."
    new "这个我不太确定……"

translate chinese chinese_0811173_218:
    old "Angelina remember we talked about it at the beginning."
    new "安吉丽娜，记得我们在开始时讨论过的。"

translate chinese chinese_0972352_219:
    old "Some treatments may take longer than expected and the results won't be seen in the short term, you have to be patient."
    new "有些治疗可能需要比预期更长的时间，短期内看不到效果，你得有耐心。"

translate chinese chinese_9795820_220:
    old "I know, I know, you are right-"
    new "我知道，我知道，你是对的-"

translate chinese chinese_2050910_221:
    old "This is one of the stages we can be on, the treatment is working..."
    new "这是我们能进入的一个阶段，治疗起作用了……"

translate chinese chinese_5854844_222:
    old "We need to keep calm and keep working. I know today's session will show some improvements."
    new "我们需要保持冷静，继续工作。我知道今天的环节会有所改进。"

translate chinese chinese_6722298_223:
    old "I am sure of it."
    new "我确定。"

translate chinese chinese_2558437_224:
    old "Oh, great please, I need to get this resolved as soon as possible."
    new "哦，拜托了，我需要尽快解决这件事。"

translate chinese chinese_7857523_225:
    old "Ok, so let's get started. We don't have time to lose."
    new "好吧，那我们开始吧。我们没时间浪费了。"

translate chinese chinese_6011873_226:
    old "Perfect! Thank you."
    new "完美！谢谢。"

translate chinese chinese_8566689_227:
    old "Okay, let's start with the previous exercise, remember? The one with the dildo?"
    new "好的，我们从上次的练习开始，记得吗？那个用 dildo 的？"

translate chinese chinese_9020252_228:
    old "Hmm, I'm not sure, I mean, it's quite different when I do it with a dildo than it is with a real one, you know?"
    new "嗯，我不太确定，我的意思是，用 dildo 和真的东西做起来感觉差别挺大的，你知道吧？"

translate chinese chinese_7329434_229:
    old "Of course, and that is why today we are going to do the exercise bandaged."
    new "当然，这也是为什么今天我们要做绑着绷带的训练。"

translate chinese chinese_8220666_230:
    old "I want you to focus on the sensations, your caresses, and your mouth."
    new "我想让你专注于这些感觉，你的爱抚，还有你的嘴唇。"

translate chinese chinese_5140427_231:
    old "Hmm ok, that sounds interesting..."
    new "嗯好，听起来挺有意思的……"

translate chinese chinese_5009953_232:
    old "It is, and today I bring you a new toy, this one is particularly realistic, and this would help us take big steps in treatment..."
    new "是的，今天我给你带来了一个新玩具，这个特别逼真，这将帮助我们在治疗方面迈出一大步……"

translate chinese chinese_7092276_233:
    old "Huh! That sounds really nice."
    new "huh! 听起来真不错。"

translate chinese chinese_3413131_234:
    old "Ok, let's get comfortable, and start with the session."
    new "好的，咱们放松一下，开始吧。"

translate chinese chinese_1460803_235:
    old "I want you to play with it, rediscover its shape, I want you to immerse yourself in it, discover the textures, the flavors, the sensations."
    new "我想让你玩弄它，重新发现它的形状，我想让你沉浸其中，探索它的质地、味道和感觉。"

translate chinese chinese_1264733_236:
    old "Remember that the main objective is to replicate this moment with your husband, try to enjoy it, and focus on pleasure."
    new "记得主要目标是和你的丈夫重现这一刻，试着享受它，专注于快乐。"

translate chinese chinese_8628432_237:
    old "Keep in mind, his pleasure will also be your satisfaction."
    new "记住，他的快乐也会让你感到满足。"

translate chinese chinese_8428267_238:
    old "Is it good?"
    new "好不好？"

translate chinese chinese_1530300_239:
    old "Yes."
    new "是的。"

translate chinese chinese_1646366_240:
    old "Use your whole mouth, your lips, moistened enough that you can move them freely and seductively."
    new "用你整个嘴巴，你的嘴唇要湿润到可以自由而挑逗地移动。"

translate chinese chinese_7938604_241:
    old "I- I think I like it... a bit."
    new "我……我觉得还行……有点喜欢。"

translate chinese chinese_0408683_242:
    old "That is perfect, now let's move on."
    new "太完美了，现在让我们继续吧。"

translate chinese chinese_6438758_243:
    old "{i}Pss! Pss! Come here, it is your turn.{/i}"
    new "嘘！嘘！过来，轮到你了。"

translate chinese chinese_2233716_244:
    old "(Oh God...){i} I- I'm coming.{/i}"
    new "（哦上帝...）{i} 我—我来了。{/i}"

translate chinese chinese_6515270_245:
    old "Ok, please hold on, here is the new toy. We are going to do the same process we were doing with the previous one."
    new "好的，请等一下，这是新的玩具。我们要像之前一样进行同样的过程。"

translate chinese chinese_2051288_246:
    old "Enjoy this new toy I have for you, the exercise will be better, and you will find it almost real, so please let me know what you think."
    new "试试这个新玩具，锻炼效果会更好，你会觉得几乎跟真的一样，请告诉我你的感受。"

translate chinese chinese_2571243_247:
    old "Oh yes, this texture is really different... Something tasty, warm and the texture is flexible."
    new "哦，是的，这种质地真的很不一样……有点美味，温暖，而且质地很柔软。"

translate chinese chinese_0477355_248:
    old "I'm glad you like it, please do it like we have learned."
    new "我很高兴你喜欢，就按我们学的那样做吧。"

translate chinese chinese_1216094_249:
    old "Yeah, please enjoy it, let's do the exercise, imagine it's natural, think he needs to feel really pleased..."
    new "嗯，请尽情享受吧，我们来做这个练习，想象这是很自然的，想着他需要感到非常满足……"

translate chinese chinese_8526029_250:
    old "Remember to change the rhythm and to use the fluids to make it easier."
    new "记得改变节奏，用润滑剂让它更容易一些。"

translate chinese chinese_6935764_251:
    old "Do you think the bandage on your eyes is helping?"
    new "你觉得眼上的绷带有用吗？"

translate chinese chinese_3400342_252:
    old "Absolutely, I'm just thinking on what you are saying and focus on the exercise and the sensations."
    new "绝对，我只是在思考你说的话，专注于练习和感觉。"

translate chinese chinese_3341374_253:
    old "Perfect, I knew it was going to work..."
    new "完美，我就知道会成功..."

translate chinese chinese_3466661_254:
    old "This one is pretty nice, it tastes really good."
    new "这个挺不错的，味道很好。"

translate chinese chinese_3607062_255:
    old "That's great, I want you to enjoy it, try a little harder, and think of it as a real one."
    new "太好了，我希望你能享受它，再努力一点，就当是真实的。"

translate chinese chinese_2513235_256:
    old "Angelina, relax. This is part of the treatment."
    new "安吉丽娜，放松点。这是治疗的一部分。"

translate chinese chinese_1592103_257:
    old "What?! B- But- Who is he? D- Did I sucked his- ? Why didn't you tell me?"
    new "什么?! B-但是-他是谁? D-我吸了他的- ? 你为什么不告诉我?"

translate chinese chinese_2997732_258:
    old "He is one of my assistants and is specifically trained for this."
    new "他是我的助手之一，专门为此训练的。"

translate chinese chinese_6518057_259:
    old "This was necessary, we were stuck for weeks, you needed a shock therapy to progress."
    new "这是必要的，我们已经卡了几周了，你需要一次冲击疗法才能继续前进。"

translate chinese chinese_4010856_260:
    old "What? B- but... I- I cheated on my husband because of you!"
    new "什么？我、可是……我因为你就出轨了！"

translate chinese chinese_2981694_261:
    old "Again, calm down Angelina..."
    new "再说一次，冷静点，安吉丽娜..."

translate chinese chinese_3745715_262:
    old "This wasn't cheating, everything was done professionally, in a controlled environment and under my supervision."
    new "这不算作弊，一切都是在专业、受控的环境下，并且在我的监督下进行的。"

translate chinese chinese_4034643_263:
    old "B- but I sucked another guy's cock and I don't even know him! I can't understand, I didn't want to do this to my husband..."
    new "我、但我吸了另一个男人的鸡巴，我甚至不认识他！我不明白，我不想这样对我丈夫..."

translate chinese chinese_0937049_264:
    old "Listen Angelina, this is part of the treatment, we have been going through a long process."
    new "听着，安吉丽娜，这是治疗的一部分，我们已经经历了一个很长的过程。"

translate chinese chinese_5093240_265:
    old "And this was a great step, and it's the right one to solve your problem."
    new "这一步非常关键，也是解决你问题的正确方法。"

translate chinese chinese_9692862_266:
    old "I- I just-"
    new "我——我只是——"

translate chinese chinese_0976050_267:
    old "Do you realize the results of this session?"
    new "你意识到这次的结果了吗？"

translate chinese chinese_1440437_268:
    old "You did great, you were very confident, you enjoyed the session, everything went just as planned."
    new "你表现得很棒，非常自信，也很享受这次过程，一切都按计划进行。"

translate chinese chinese_7551798_269:
    old "B- but... I- I- ... and He... Who is-"
    new "B-但是...我-我-...和他...是谁-"

translate chinese chinese_0110241_270:
    old "Don't worry, [pla] is a very well-trained member of my team."
    new "别担心，[pla] 是我团队中训练有素的一员。"

translate chinese chinese_2893618_271:
    old "He has been prepared by me and has followed the treatments of another patient, he is very professional and trustworthy."
    new "他已经由我准备好了，并且按照另一个病人的治疗方案进行，他非常专业而且值得信赖。"

translate chinese chinese_5759367_272:
    old "I'm sorry, but I can't accept this, I feel like I'm betraying my husband..."
    new "对不起，我不能接受这个，我觉得我在背叛我的丈夫..."

translate chinese chinese_8826118_273:
    old "I think there was a misunderstanding about this... I need to go."
    new "我觉得这里有点误会……我得走了。"

translate chinese chinese_6381929_274:
    old "Wow, she has left!"
    new "哇，她真的走了！"

translate chinese chinese_0130912_275:
    old "It's okay, she has a lot of emotions to think about."
    new "没关系，她有很多情绪需要处理。"

translate chinese chinese_3047822_276:
    old "So she's going to need some time to process what happened and understand what was necessary within his process."
    new "所以她需要一些时间来处理发生的事情，并理解在他过程中什么是必要的。"

translate chinese chinese_6405345_277:
    old "Absolutely! That's what is called 'shock therapy'."
    new "绝对的！这就叫“冲击疗法”。"

translate chinese chinese_4844675_278:
    old "But, looks like she feels pretty bad."
    new "但是，看来她感觉挺糟糕的。"

translate chinese chinese_5425025_279:
    old "Well, it is something that needs to happen."
    new "好吧，这件事总得发生。"

translate chinese chinese_3106688_280:
    old "She is dealing with changing the most ingrained ideas about her sexuality and the way she expresses her love, so she needs time."
    new "她在应对关于自己性取向和表达爱的方式的根本改变，所以需要时间。"

translate chinese chinese_4591857_281:
    old "The only thing we can do is wait until she internalizes these new emotions and figure out how to deal with them."
    new "我们唯一能做的就是等待她内化这些新情绪，并找出如何应对它们的方法。"

translate chinese chinese_9326488_282:
    old "I understand."
    new "我明白。"

translate chinese chinese_1790284_283:
    old "I appreciate your commitment, you did an amazing job today."
    new "我欣赏你的投入，今天干得非常棒。"

translate chinese chinese_1393529_284:
    old "I'm sorry, but I have to go, another patient should be here in a few minutes."
    new "对不起，我得走了，几分钟后另一个病人就该来了。"

translate chinese chinese_5139144_285:
    old "Oh ok... But when should I come again?"
    new "哦，好的……但是我又什么时候来呢？"

translate chinese chinese_3152478_286:
    old "Once Angelina books her next session I will let you know, for now you can come in the morning to continue training."
    new "等Angelina预约了下一次课程我会通知你，现在你可以早上过来继续训练。"

translate chinese chinese_2101738_287:
    old "Thank you and see you later [pla]."
    new "谢谢，下次见[pla]。"

translate chinese chinese_8315020_288:
    old "Ok, see you doctor."
    new "好的，医生，再见。"

translate chinese chinese_7673637_289:
    old "No Angelina, I can't tolerate this anymore!"
    new "不，安吉丽娜，我再也不能忍受这个了！"

translate chinese chinese_6268839_290:
    old "I'm doing all what I can, just to make you happy."
    new "我尽全力只是想让你开心。"

translate chinese chinese_2870774_291:
    old "I don't see the effort you make, and I'm tired of waiting so long for you."
    new "我看不见你的努力，等了你这么久我也累了。"

translate chinese chinese_2029195_292:
    old "Why are you such a prick? You can't see how much I love you..."
    new "你为什么这么刺猬呢？你看不出来我有多爱你..."

translate chinese chinese_4106034_293:
    old "I know that but I need a real woman, not a beautiful doll beside me..."
    new "我知道，但我需要的是一个真正的女人，而不是我身边这个漂亮的洋娃娃……"

translate chinese chinese_4494298_294:
    old "I have been really patient... But I can't wait anymore... Look for me when you are ready to have sex like a normal person."
    new "我真的很耐心……但再也不能等了……准备好像正常人一样做爱的时候就来找我。"

translate chinese chinese_0852515_295:
    old "Come on darling... Please, you know this is hard for me..."
    new "亲爱的，求你了……你知道这对我来说很难……"

translate chinese chinese_2432310_296:
    old "Are you serious? Listen 5 months without sex I- I... You know what? I will not discuss it anymore, see you later at home..."
    new "你是认真的吗？听我讲，五个月没有性生活，我……你知道吗？我不再讨论这个了，回家见吧……"

translate chinese chinese_6041270_297:
    old "Wait! Roonnie- !"
    new "等一下！鲁尼！"

translate chinese chinese_7749564_298:
    old "I'm sorry..."
    new "对不起..."

translate chinese chinese_1752223_299:
    old "It's ok, welcom-"
    new "没事，欢迎"

translate chinese chinese_7077534_300:
    old "(WHAT IS HE DOING HERE?.)"
    new "（他怎么会在这里？）"

translate chinese chinese_9364721_301:
    old "Huh, t- thank you."
    new "嗯，谢谢。"

translate chinese chinese_3710652_302:
    old "N- nice to see you again... Ehh-"
    new "又见到你真好……呃——"

translate chinese chinese_0573528_303:
    old "Yes, the doctor Johnson's... assistant, right?"
    new "对，是约翰逊医生的……助理，没错吧？"

translate chinese chinese_2952689_304:
    old "Right, is Roonnie your husband?"
    new "对了，Roonnie是你的丈夫吗？"

translate chinese chinese_7948293_305:
    old "Hmm it seems like not for long... Anyway, how are you?"
    new "嗯，看来不会太久……不过，你怎么样？"

translate chinese chinese_9008867_306:
    old "I'm fine, thanks for asking..."
    new "我挺好的，谢谢关心……"

translate chinese chinese_6401569_307:
    old "Great, and what are you doing here?"
    new "太好了，那你在这里干什么？"

translate chinese chinese_3331725_308:
    old "I'm sorry, I was not aware you were here-"
    new "对不起，我不知道你在这里——"

translate chinese chinese_1760593_309:
    old "Oh no don't worry, actually, I'm sorry that you had to listen to all of... This."
    new "哦不，别担心，其实我抱歉你不得不听这一切……这个。"

translate chinese chinese_6908467_310:
    old "Oh no, it wasn't my intention, I- I didn't know-"
    new "哦不，那不是我的本意，我——我不知道——"

translate chinese chinese_6702093_311:
    old "Never mind, though, I've been thinking about last time and wanted to apologize for the incident in Dr. Johnson's office."
    new "不过没关系，我一直在想上次的事，想为在约翰逊医生办公室里的那件事道歉。"

translate chinese chinese_6553678_312:
    old "Oh, no worries about that, I'm sorry about you and husband, I know it's something hard to deal with."
    new "哦，没关系的，我为你和你丈夫的事感到抱歉，我知道这很难处理。"

translate chinese chinese_3510504_313:
    old "Yes, he is lovely but he is also tired, he is right about what he says, I can't satisfy his needs..."
    new "是的，他确实可爱，但他也很累，他说的话是对的，我无法满足他的需求……"

translate chinese chinese_8346713_314:
    old "I'm sorry to tell you all this, I don't even know you..."
    new "很抱歉跟你说这些，我甚至还不认识你..."

translate chinese chinese_0437218_315:
    old "It's ok, don't worry."
    new "没事，别担心。"

translate chinese chinese_6796650_316:
    old "I appreciate that... And I still embarrassed about the last time-"
    new "我明白……上次的事我还是觉得挺尴尬的——"

translate chinese chinese_0883866_317:
    old "Oh please forget it, it's not important."
    new "哦忘了它吧，这不重要。"

translate chinese chinese_1473499_318:
    old "It is, I was disrespectful to both of you and left the place without any explanation, and it's not your fault of course."
    new "是的，我对你俩不尊重，还毫无解释就离开了，这当然不怪你。"

translate chinese chinese_9088290_319:
    old "I felt like I was betraying my husband, I had never cheated on him and I really love him..."
    new "我觉得自己背叛了丈夫，我从没有背叛过他，而且我真的爱他……"

translate chinese chinese_8943159_320:
    old "I still don't know why doctor Johnson did something like that."
    new "我 still 不明白 Johnson 医生为什么会这么做。"

translate chinese chinese_6091501_321:
    old "I understand your point, I can't say too much because I was part of the session but..."
    new "我明白你的意思，因为我也参与了那次活动，所以不能说太多，但是……"

translate chinese chinese_1287734_322:
    old "I know she is quite good at what she does, I have seen the progress of other patients."
    new "我知道她很擅长她的工作，我见过其他病人的进步。"

translate chinese chinese_3262591_323:
    old "Yes, that is why I met her, because one of my friends needed help."
    new "是的，我就是为此才见她的，因为我的一个朋友需要帮助。"

translate chinese chinese_1600966_324:
    old "And it was a very surprising thing to see how she changed and how positive it was for her."
    new "看到她的变化以及这对她有多么积极的影响，真是非常令人惊讶。"

translate chinese chinese_5587940_325:
    old "Hmm, I don't know..."
    new "嗯，我不知道……"

translate chinese chinese_5793111_326:
    old "I know, at the beginning I was sceptical..."
    new "我知道，一开始我是有点怀疑……"

translate chinese chinese_4603486_327:
    old "But later on, my friend was improving so much that I had to be honest and recognize how amazing she did it with her treatment."
    new "但后来，我的朋友进步得如此之大，我不得不坦诚地承认，她用她的治疗方法做得真的很棒。"

translate chinese chinese_2137119_328:
    old "I think I am sceptical now..."
    new "我现在有点怀疑了……"

translate chinese chinese_2749647_329:
    old "It is pretty normal, your process is not easy and these experiences are new for everyone."
    new "这挺正常的，你的过程不容易，这些经历对每个人来说都是新的。"

translate chinese chinese_9798135_330:
    old "However, if she dares to try this method, it is because she knows you well enough."
    new "然而，如果她敢用这种方法，说明她对你很了解。"

translate chinese chinese_5310725_331:
    old "I must confess that I was a bit nervous, but we were in a very professional environment."
    new "我必须承认我当时有点紧张，但我们在一个非常专业的环境中。"

translate chinese chinese_4028513_332:
    old "Everything was planned to make sure that you could overcome your fear."
    new "一切都是计划好的，确保你能克服恐惧。"

translate chinese chinese_3717671_333:
    old "Hmm, I thinnk you are right, maybe I overreacted that day, my marriage needs whatever effort I can make."
    new "嗯，我觉得你说得对，那天我可能反应过激了，我的婚姻需要我付出所有努力。"

translate chinese chinese_7628558_334:
    old "I know you were confused but I am sure doctor Johnson is expecting to see you again no matter what happens before."
    new "我知道你当时很困惑，但不管之前发生了什么，我敢肯定约翰逊医生都希望再次见到你。"

translate chinese chinese_3303109_335:
    old "I owe her an apology, but yes I need to solve this problem as soon as possible."
    new "我欠她一个道歉，但确实需要尽快解决这个问题。"

translate chinese chinese_7128201_336:
    old "She will be very happy to see you and the most important thing you can continue the process you are in, you need to trust her."
    new "她见到你会非常高兴，而且最重要的是你能继续正在进行的过程，你需要信任她。"

translate chinese chinese_0153703_337:
    old "You're right, I need this now more than ever, my husband is about to dump me, so I'll do whatever it takes."
    new "你说得对，我现在比任何时候都更需要这个，我丈夫就要甩了我，所以我愿意不惜一切代价。"

translate chinese chinese_6619283_338:
    old "Don't worry, visit doctor Johnson, she will help you."
    new "别担心，去看约翰逊医生，她会帮助你的。"

translate chinese chinese_5392255_339:
    old "Hmm alright, I will do an appointment,  I think I need to continue with my treatment, thank you so much for your words."
    new "嗯好吧，我会去预约的，我觉得我需要继续治疗，非常感谢你的建议。"

translate chinese chinese_1283109_340:
    old "You are welcome,I hope things improve soon."
    new "不客气，希望事情尽快好转。"

translate chinese chinese_3618430_341:
    old "I appreciate it."
    new "我感激不尽。"

translate chinese chinese_1939958_342:
    old "Good bye."
    new "再见。"

translate chinese chinese_5864645_343:
    old "Bye Bye."
    new "拜拜。"

translate chinese chinese_7855161_344:
    old "Welcome back Angelina, I am very happy to have you here again."
    new "欢迎回来，Angelina，很高兴再次见到你。"

translate chinese chinese_9114635_345:
    old "Hi doctor, I'm terribly sorry for my behavior last time..."
    new "医生你好，上次我的行为真的很抱歉……"

translate chinese chinese_2315459_346:
    old "Listen, the past is just a page we can't see anymore. Now tell me, how is everything going?"
    new "听着，过去就是一页我们再也看不到了。现在告诉我，一切都还好吗？"

translate chinese chinese_8549251_347:
    old "I need your help, my husband will dump me anytime because of my problem and I don't know what to do."
    new "我需要你的帮助，我丈夫因为我的问题随时可能抛弃我，我不知道该怎么办。"

translate chinese chinese_3080317_348:
    old "Hmm, okay, we have to think carefully because we'll need something that will deliver immediate results."
    new "嗯，好吧，我们必须仔细考虑，因为我们需要一些能立即见效的东西。"

translate chinese chinese_0755214_349:
    old "Oh, [pla], welcome, I'm glad to see you here."
    new "哦，[pla]，欢迎，很高兴见到你在这里。"

translate chinese chinese_7913510_350:
    old "Hello Dr. Johnson, hi Angelina."
    new "你好约翰逊博士，嗨安吉丽娜。"

translate chinese chinese_6025183_351:
    old "Hi... [pla], nice to see you again."
    new "嗨...[pla]，很高兴再次见到你。"

translate chinese chinese_4066188_352:
    old "Well, now that [pla] is here, I have an idea to go ahead with the treatment."
    new "好吧，既然[pla]在这里，我有个主意可以继续进行治疗。"

translate chinese chinese_5783335_353:
    old "But how do you feel about what happened last time with [pla]?"
    new "但是你对上次和[pla]发生的事有什么感觉？"

translate chinese chinese_1094441_354:
    old "Hmm, I had a chance to talk to him and now I feel much better."
    new "嗯，我有机会和他谈谈，现在感觉好多了。"

translate chinese chinese_7823489_355:
    old "Oh really? Well, that makes things a lot easier for us."
    new "哦真的吗？那对我们来说就容易多了。"

translate chinese chinese_7561226_356:
    old "All right, then, today we are going to continue the treatment."
    new "好吧，今天我们就继续治疗。"

translate chinese chinese_6021833_357:
    old "So, [pla] remember that we will need to apply all the concepts you have learned."
    new "所以，[pla]，记得我们需要应用你学到的所有概念。"

translate chinese chinese_1894727_358:
    old "But before we start I want you to help her to get relaxed a bit so please give her a massage."
    new "但是在开始之前，我想让你帮她放松一下，所以请给她按摩一下。"

translate chinese chinese_8663159_359:
    old "Also, Angelina, I want you to become more familiar with the image of your husband."
    new "还有，Angelina，我希望你能更熟悉你丈夫的形象。"

translate chinese chinese_8349480_360:
    old "So, [pla] will help us with that, he will play the role of your husband."
    new "所以，[pla]会帮我们处理这件事，他会扮演你的丈夫。"

translate chinese chinese_2065619_361:
    old "We will start with a basic exercise, this will prepare your mind and body, then we will have the real session."
    new "我们将从一个基础练习开始，这会准备好你的身心，然后我们会进入正式环节。"

translate chinese chinese_5109071_362:
    old "So, let's begin, please take off your shirt."
    new "好了，开始吧，请脱掉你的衬衫。"

translate chinese chinese_3700909_363:
    old "But... I- I'm not wearing a bra..."
    new "但是……我……我没穿胸罩……"

translate chinese chinese_3587921_364:
    old "I know that darling."
    new "我知道那家伙挺可爱的。"

translate chinese chinese_6201106_365:
    old "So, do you mean stay topless?"
    new "所以，你是说保持无胸罩吗？"

translate chinese chinese_8356201_366:
    old "That's correct, he will give you a little breasts massage, so, you can relax and get in the mood for the next exercise."
    new "没错，他会给你做个胸部按摩，所以你可以放松一下，为下一个动作做好准备。"

translate chinese chinese_3952749_367:
    old "I- I am not... Sure about it..."
    new "我……我不太确定……"

translate chinese chinese_8933662_368:
    old "Oh, darling, don't worry, we're already working on that, right? You shouldn't feel insecure about your body..."
    new "哦，亲爱的，别担心，我们已经在处理了，对吧？你不应该对自己的身体感到不安全感..."

translate chinese chinese_9314280_369:
    old "I know, but... Having a man in the room makes this a little more difficult..."
    new "我知道，但是……房间里有个男人让这事有点难办……"

translate chinese chinese_2311535_370:
    old "I know you had a tough adolescence, your body grew fast and you didn't feel comfortable about it..."
    new "我知道你的青春期很艰难，身体快速发育，你对此感到不自在……"

translate chinese chinese_1750877_371:
    old "But, you already know that your body is beautiful, all men love it, your husband loves it, right?"
    new "但是，你已经知道你的身体很美，所有的男人都喜欢它，你的丈夫也喜欢它，对吧？"

translate chinese chinese_8579475_372:
    old "Yes, but he doesn't care..."
    new "是的，但他不在乎……"

translate chinese chinese_9520950_373:
    old "Of course not, you are very hot, you are incredible, what do you think [pla]? You like them? Those are bigger than mine, aren't they?"
    new "当然不，你非常热辣，你太棒了，你觉得[pla]呢？你喜欢它们吗？那些比我的大，对吧？"

translate chinese chinese_3878564_374:
    old "... Y- yes... I think you have a hug-... Beautiful boobs..."
    new "... 嗯... 我觉得你有很... 漂亮的胸部..."

translate chinese chinese_3651402_375:
    old "Honey, I can tell you that I have not seen a more beautiful breast."
    new "宝贝，我可以告诉你，我从未见过更美的胸部。"

translate chinese chinese_4027569_376:
    old "It's the first time someone tells me that..."
    new "这是第一次有人这么告诉我……"

translate chinese chinese_2470584_377:
    old "It's not going to be the last time. I'm sure, now please get comfortable because our session about to begins."
    new "这不会是最后一次。我相信，现在请放松一下，因为我们的环节就要开始了。"

translate chinese chinese_5927803_378:
    old "I told you and I want you to enjoy it a lot... [pla], please!"
    new "我跟你说过了，我希望你能好好享受它……[pla]，拜托！"

translate chinese chinese_3927370_379:
    old "Of course!"
    new "当然了！"

translate chinese chinese_7001243_380:
    old "Thank... You..."
    new "谢...谢..."

translate chinese chinese_1534048_381:
    old "Alright, let's take out those big babies..."
    new "好吧，让我们拿出那些大家伙……"

translate chinese chinese_4812408_382:
    old "Ohhh, they are really beautiful... Don't you think [pla]?"
    new "哦哦，真的好漂亮……你不这么觉得吗，[pla]？"

translate chinese chinese_0852201_383:
    old "Hahaha, you see Angelina, now he is speechless... Come on, [pla] please have a seat, and you Angelina, have a seat over his lap."
    new "哈哈哈哈哈，你看Angelina，现在他无话可说了……来吧，[pla]，请坐，你Angelina，坐在他的腿上。"

translate chinese chinese_3306984_384:
    old "Ok, [pla] to start, do it gently..."
    new "好的，从[pla]开始，动作轻一点……"

translate chinese chinese_4802513_385:
    old "Ok, like this?"
    new "好的，像这样？"

translate chinese chinese_0078410_386:
    old "Yeah, how do you feel Angelina?"
    new "是啊，天使娜，你觉得怎么样？"

translate chinese chinese_1434141_387:
    old "I- It's ok... I'm fine..."
    new "我...没事...我真的很好..."

translate chinese chinese_4057285_388:
    old "Next exercise?"
    new "下一个练习？"

translate chinese chinese_1905100_389:
    old "It's ok, You just follow [pla], he will walk you through. Now please take off your clothes."
    new "没事，你就跟着[pla]就行了，他会带你完成的。现在请脱掉你的衣服。"

translate chinese chinese_8614548_390:
    old "Do you want me to take off everything?"
    new "你要我全部脱光吗？"

translate chinese chinese_6515971_391:
    old "Yes, please, and then lie on the bed..."
    new "好的，请，然后躺在床上..."

translate chinese chinese_3520830_392:
    old "... Hmm alright."
    new "... 嗯，好吧。"

translate chinese chinese_8603109_393:
    old "Ohh, look at that, you so thick girl... Ok [pla], now is your turn."
    new "哦呵，看看你这厚脸皮的姑娘……好了，现在轮到你了，[pla]。"

translate chinese chinese_3047866_394:
    old "My... T- turn? What do you mean?"
    new "我……轮到我了？你是说什么意思？"

translate chinese chinese_8383243_395:
    old "I'm sorry, I meant it's your turn to please Angelina. Now give oral sex to her."
    new "对不起，我是说该你取悦安吉丽娜了。现在给她口交。"

translate chinese chinese_5078520_396:
    old "O- oral sex?"
    new "口...口交？"

translate chinese chinese_7111663_397:
    old "Ok, Angelina, please remember this is part of the treatment for you, and your marriage."
    new "好的，安吉丽娜，请记住这是治疗的一部分，也是为了你们的婚姻。"

translate chinese chinese_3399168_398:
    old "You are right, I'm sorry."
    new "你说得对，对不起。"

translate chinese chinese_5337939_399:
    old "It's ok, let's move on, [pla] do your job, please."
    new "没事，我们继续吧，[pla] 请你做好你的工作。"

translate chinese chinese_0451370_400:
    old "[pla] please do it as soft as possible, she must just feel you over there."
    new "[pla] 请尽量轻柔一点，她应该只是能感觉到你在那边。"

translate chinese chinese_0177812_401:
    old "Close your eyes Angelina, focus on the sensations, and enjoy the experience."
    new "闭上眼睛，安吉丽娜，专注于这些感觉，享受这个过程。"

translate chinese chinese_5089550_402:
    old "I will try..."
    new "我会试试..."

translate chinese chinese_4658463_403:
    old "Keep focused [pla], use your tongue like we have learned."
    new "集中精神，[pla]，用你的舌头像我们学的那样做。"

translate chinese chinese_0047843_404:
    old "Wow, you can't imagine how happy I feel."
    new "哇，你无法想象我有多开心。"

translate chinese chinese_3095044_405:
    old "Well, that's fantastic because it means the process is working out."
    new "好吧，这真是太好了，因为这意味着整个过程进展顺利。"

translate chinese chinese_8621399_406:
    old "If you feel more confident to have sexual interactions, it means you are ready to try this with your husband with no fears."
    new "如果你觉得在性方面更加自信了，那就意味着你可以毫无畏惧地和你的丈夫尝试这些。"

translate chinese chinese_3527281_407:
    old "Great, so let's get dressed and go to the therapy bedroom."
    new "好的，那我们穿好衣服去治疗室吧。"

translate chinese chinese_9326208_408:
    old "Ok!"
    new "好！"

translate chinese chinese_7685407_409:
    old "Ok, it was everything for today, but we need to continue working pretty hard."
    new "好吧，今天就到这里，但我们还需要继续努力工作。"

translate chinese chinese_8961593_410:
    old "Next session is really important, so, guys please get ready and see you soon."
    new "下次很重要，大家准备好，很快见。"

translate chinese chinese_5882509_411:
    old "Oh thank you, I will be here on time, bye bye!"
    new "哦，谢谢你，我会准时来的，拜拜！"

translate chinese chinese_0879159_412:
    old "Good bye!"
    new "再见！"

translate chinese chinese_8091215_413:
    old "Hi Angelina, how is everything going?"
    new "嗨，安吉丽娜，一切都还好吗？"

translate chinese chinese_0540972_414:
    old "Wonderful! I applied what we did with my husband and he was really happy, now I just want to learn more."
    new "太好了！我把我丈夫也一起带入了我们的玩法，他非常开心，现在我只是想学更多。"

translate chinese chinese_4601622_415:
    old "And you will, our session today is aimed at helping you do more exercises with your husband."
    new "你会的，今天我们的话题就是为了帮助你和丈夫多做一些锻炼。"

translate chinese chinese_9789881_416:
    old "Sounds great!"
    new "听起来很棒！"

translate chinese chinese_3591251_417:
    old "Hi, how are you doing?"
    new "嗨，最近怎么样？"

translate chinese chinese_3463274_418:
    old "Hi [pla], I'm doing amazing."
    new "嗨 [pla]，我过得很好。"

translate chinese chinese_8916324_419:
    old "Welcome [pla], good to see you again, are you ready to start the new session?"
    new "欢迎[pla]，很高兴再次见到你，准备好开始新的环节了吗？"

translate chinese chinese_5055310_420:
    old "Yes, I am ready."
    new "是的，我准备好了。"

translate chinese chinese_6080320_421:
    old "Ok, Angelina, this time we are going to practice a fellation, this time with no fears and doing your best, ok?"
    new "好的，Angelina，这次我们要练习口交，不要害怕，尽全力，好吗？"

translate chinese chinese_6976077_422:
    old "Oh... I had to... S- suck his cock?"
    new "哦……我不得不……吸他的棒？"

translate chinese chinese_7365449_423:
    old "Of course, last time you received all the pleasure, today we will make sure that you are able to provide it too."
    new "当然，上次你只得到了快乐，今天我们要确保你也能给予快乐。"

translate chinese chinese_0813561_424:
    old "So that we can guarantee that your husband will also be satisfied."
    new "这样就能保证你丈夫也会满意了。"

translate chinese chinese_7025500_425:
    old "Hmm, I guess you are right..."
    new "嗯，我想你是对的……"

translate chinese chinese_0845983_426:
    old "Great, just remember what we had practiced before with the dildo, and by the way you already sucked his cock before, so don't worry."
    new "好的，记得之前用 dildo 练习的内容，而且你之前已经给他吹过鸡了，所以别紧张。"

translate chinese chinese_5999349_427:
    old "Ok, our time is short we need to work, so, let's start. [pla], take off your pants and Angelina, please start the fellation."
    new "好的，时间紧迫，我们需要开始工作了。[pla]，脱掉你的裤子，Angelina，请开始口交。"

translate chinese chinese_8549791_428:
    old "Hmm... "
    new "嗯……"

translate chinese chinese_9629549_429:
    old "Please enjoy it Angelina, try to focus only on what you feel, like last time, don't think about [pla], just enjoy what you can feel."
    new "请享受吧，Angelina，尽量只关注你的感觉，就像上次一样，不要想[pla]，只要享受你能感受到的就好。"

translate chinese chinese_9146056_430:
    old "Alright, now let's continue with the next exercise."
    new "好了，现在让我们继续下一个练习。"

translate chinese chinese_6123251_431:
    old "NEXT EXERCISE?"
    new "下一个练习？"

translate chinese chinese_7154547_432:
    old "Of course, you're the one asking for faster improvement, aren't you?"
    new "当然，要加快进度的人是你吧？"

translate chinese chinese_2644252_433:
    old "Also, we need you to be able to have sex with your husband as soon as possible, so your marriage can be saved."
    new "另外，我们需要你能尽快和丈夫发生关系，这样你们的婚姻才能挽救。"

translate chinese chinese_2810020_434:
    old "Hmm, you're right..."
    new "嗯，你说得对..."

translate chinese chinese_5385209_435:
    old "Alright, let's go to the bedroom, so you can have sex with [pla]."
    new "好吧，去卧室吧，你可以和[pla]做爱。"

translate chinese chinese_7458925_436:
    old "Sex?"
    new "性？"

translate chinese chinese_7634999_437:
    old "Oh, relax, you are going to love it."
    new "哦，放松点，你会爱上它的。"

translate chinese chinese_1541441_438:
    old "Alright, [pla] I need you to remember your trainin."
    new "好了，[pla]，你需要记住你的训练。"

translate chinese chinese_2285998_439:
    old "You're going to have sex but you can't stop until she has reached the orgasm."
    new "你要进行性行为，但必须持续到她达到高潮为止。"

translate chinese chinese_4456361_440:
    old "Angelina, I need you to understand this, in your treatment, there is no way to learn about sex without having sex."
    new "安吉丽娜，我需要你明白，在你的治疗过程中，如果不发生性行为就无法了解性。"

translate chinese chinese_5243842_441:
    old "That is why we are here in a safe therapy so that you learn to enjoy it."
    new "这就是为什么我们要在这里进行安全的治疗，让你学会享受它。"

translate chinese chinese_4167593_442:
    old "... Ok, thank you doctor Johnson."
    new "... 好的，谢谢约翰逊医生。"

translate chinese chinese_3751499_443:
    old "Alright, please, both get naked and let's start."
    new "好吧，请都脱光然后开始吧。"

translate chinese chinese_8446451_444:
    old "Wow, that was really good, I thank you so much doctor Johnson."
    new "哇，真的很好，约翰逊医生，非常感谢你。"

translate chinese chinese_2128217_445:
    old "You still have a lot to learn, but now you are open to new experiences, and [pla] you did an outstanding job."
    new "你还有很多要学的，但现在你已经对新体验持开放态度了，而且[pla]，你做得非常出色。"

translate chinese chinese_8635631_446:
    old "Yes, you [pla], you made me feel things I've never felt before with any man."
    new "是的，你[pla]，你让我感受到了以前从未有过的男人给我的感觉。"

translate chinese chinese_1102186_447:
    old "... I- I'm glad everything turned out okay..."
    new "……我……我很高兴最后一切都没事……"

translate chinese chinese_0869024_448:
    old "Alright, get dressed and let's go to the therapy room, I have a new patient in a few minutes."
    new "好吧，快点穿好衣服，我们去治疗室，几分钟后我有个新病人。"

translate chinese chinese_1802657_449:
    old "Alright, please apply these exercises with your husband."
    new "好吧，请和你丈夫一起做这些练习。"

translate chinese chinese_1006784_450:
    old "Focus on enjoying, but don't push it, as you will see the changes gradually."
    new "专注于享受，但不要强求，你会逐渐看到变化的。"

translate chinese chinese_4464513_451:
    old "Ok, I will have that in mind."
    new "好的，我会注意的。"

translate chinese chinese_7120984_452:
    old "I'm glad to see you happy, I can't wait to hear how it went with your husband."
    new "看到你这么开心我也很高兴，迫不及待想听听你和你老公的事了。"

translate chinese chinese_2897289_453:
    old "Yes, I am a little anxious to try it as soon as possible."
    new "是的，我有点迫不及待想试试了。"

translate chinese chinese_3394079_454:
    old "Okay, then don't waste any more time and go home. See you at the next session, darling."
    new "好吧，那不要再浪费时间了，回家吧。下次见，亲爱的。"

translate chinese chinese_9115517_455:
    old "Alright, thank you so much!"
    new "好的，太感谢了！"

translate chinese chinese_6277333_456:
    old "See you. And please, have fun!"
    new "再见。玩得开心点！"

translate chinese chinese_7395493_457:
    old "That was a significant step with her therapy."
    new "这对她的治疗来说是个重要的步骤。"

translate chinese chinese_1757163_458:
    old "And you, Congratulations on such a fantastic performance, I can see that my lessons were very helpful, maybe better than I thought."
    new "你啊，恭喜你这么出色的表演，我能看出来我的教导很有帮助，也许比我想象的还要好。"

translate chinese chinese_8245661_459:
    old "Thank you, I appreciate all your patient with me."
    new "谢谢你，感谢你的耐心。"

translate chinese chinese_0775700_460:
    old "You are welcome. Anyway, I have to get ready for my next patient, so, see you at the next session."
    new "不客气。不过我得准备迎接下一个病人了，所以我们下次见。"

translate chinese chinese_4514058_461:
    old "Sure, good bye Dr. Johnson."
    new "好的，再见了，约翰逊博士。"

translate chinese chinese_3628536_462:
    old "Welcome Angelina, how is everything going?"
    new "欢迎天使丽娜，一切都还好吗？"

translate chinese chinese_9828707_463:
    old "I couldn't be happier."
    new "我再开心不过了。"

translate chinese chinese_7873006_464:
    old "So, were you able to do the exercises with your husband without problems? "
    new "所以，你和你老公做那些练习的时候没有遇到问题吧？"

translate chinese chinese_4693985_465:
    old "That's right! And my husband is really happy, your work is incredible!"
    new "没错！我老公真的很开心，你的工作太棒了！"

translate chinese chinese_6882100_466:
    old "I'm so happy to hear that! I've prepared a new lesson today, you'll love it..."
    new "听到这个我太高兴了！我今天准备了一堂新课程，你会喜欢的..."

translate chinese chinese_9008082_467:
    old "Welcome [pla], we are happy to have you here."
    new "欢迎[pla]，很高兴你能来到这里。"

translate chinese chinese_6540573_468:
    old "Hello!"
    new "喂！"

translate chinese chinese_7101727_469:
    old "Hi, [pla]!!"
    new "喂，[pla]！！"

translate chinese chinese_5171711_470:
    old "Well guys, now [pla] is here, there's no time to lose, so, let's go to the room."
    new "好了，大家，现在[pla]来了，没有时间浪费了，我们去房间吧。"

translate chinese chinese_5242831_471:
    old "Perfect!"
    new "完美！"

translate chinese chinese_7045476_472:
    old "According to the advances that you mentioned that sex with your husband is reaching... Let's practice again with a sexual exercise."
    new "根据你提到的你和你丈夫的性爱进展情况，我们再来做一次性爱练习吧。"

translate chinese chinese_8489645_473:
    old "But, before we start, I want you to practice oral sex, that will drive your husband crazy."
    new "但是，在开始之前，我想让你练习口交，这会让你丈夫疯狂的。"

translate chinese chinese_7810905_474:
    old "Got it! I want to make sure I'm doing this the right way for my husband."
    new "明白了！我想确保自己以正确的方式为丈夫做这件事。"

translate chinese chinese_7261902_475:
    old "Now that we are ready, I have a special task for you Angelina."
    new "既然我们已经准备好了，我有一个特别的任务给你，安吉丽娜。"

translate chinese chinese_1523820_476:
    old "Ok, I'm ready for whatever you want."
    new "好的，我准备好了，你想怎么样都行。"

translate chinese chinese_6570995_477:
    old "I love that enthusiasm! I want you to take the lead and fuck him wild, I want you to be the one to say what to do."
    new "我就喜欢这种热情！我要你带头疯狂地干他，我要你来指挥该怎么做。"

translate chinese chinese_7250835_478:
    old "So, I want you to get on him and take the rhythm and intensity, I want you to take an active role in sex..."
    new "所以，我想让你主动骑在他身上，掌握节奏和强度，在性爱中扮演一个积极的角色……"

translate chinese chinese_9295847_479:
    old "Hmm... I- I will try, get ready [pla]."
    new "嗯……我—我会试试的，准备好吧，[pla]。"

translate chinese chinese_7323578_480:
    old "You are the most amazing therapist I've ever had."
    new "你是我在意遇到过的最棒的治疗师。"

translate chinese chinese_3265153_481:
    old "I appreciate all the effort you did, I know it was not easy but now you can see the results."
    new "我真的很感激你的努力，我知道这不容易，但现在你可以看到结果了。"

translate chinese chinese_4071331_482:
    old "Doctor, I have, no words to say how much I thank you for all the knowledge and patience you invested..."
    new "医生，我不知道该怎么表达我对您所投入的知识和耐心的感激之情……"

translate chinese chinese_5458112_483:
    old "And I thank you too [pla], you really help me with your... Abilities."
    new "我也谢谢你，[pla]，你的……能力真的帮了我大忙。"

translate chinese chinese_0649087_484:
    old "It's a pleasure, I'm glad to have helped you."
    new "很荣幸，很高兴能帮到你。"

translate chinese chinese_7280777_485:
    old "Ok, it's time guys, get dressed and let's go to the therapy bedroom..."
    new "好了，大家，穿上衣服，我们去治疗室……"

translate chinese chinese_7815615_486:
    old "Ok, today we finished our team practice sessions. Angelina, you and I will continue the process together with therapy."
    new "好的，今天我们完成了团队训练。安吉丽娜，你和我将继续一起进行治疗。"

translate chinese chinese_9174523_487:
    old "Oh... So, there are no more sessions with [pla]?"
    new "哦……所以，再没有和[pla]的会面了？"

translate chinese chinese_6050241_488:
    old "No, he did his job and now we can continue with therapy. Now is the moment to put all of this in practice with your husband."
    new "不，他完成了他的工作，现在我们可以继续治疗了。现在是时候把这些都用在你丈夫身上了。"

translate chinese chinese_0652660_489:
    old "Oh, alright..."
    new "哦，好吧……"

translate chinese chinese_8176818_490:
    old "Remember we have other things to work on together. If we see we would need [pla]'s help again, I would bring him to therapy."
    new "记得我们还有很多其他的事情要一起处理。如果我们发现还需要[pla]的帮助，我会带他去治疗的。"

translate chinese chinese_9625102_491:
    old "Oh, great, I'm glad to hear that. Anyway, I can't describe how happy I am and how happy I will make my husband..."
    new "哦，太好了，听到这个我很高兴。不过，我无法形容我有多开心，以及我会让我的丈夫多么幸福..."

translate chinese chinese_0178547_492:
    old "I will practice a lot with him! Thank you doctor Johnson, I will call you to make a new appointment."
    new "我会多跟他练习的！谢谢约翰逊医生，我会打电话预约新的时间。"

translate chinese chinese_0903578_493:
    old "Ok, please have fun, it was nice to walk you through this process."
    new "好的，玩得开心点，带你看完这个过程很高兴。"

translate chinese chinese_2951600_494:
    old "Uhh... Goodbye Angelina."
    new "呃……再见了，安吉丽娜。"

translate chinese chinese_5755521_495:
    old "Well, [pla], I really appreciate your job, you did amazing, every single session, I'm very proud of you."
    new "好吧，[pla]，我真的很感激你的工作，你每次的表现都太棒了，我为你感到非常骄傲。"

translate chinese chinese_1465276_496:
    old "Oh, t- thank you, I just followed all your instructions."
    new "哦，谢谢，我 just 按照你的指示做的。"

translate chinese chinese_7981314_497:
    old "I know. By the way,  I want to have another session, just for you and me..."
    new "我知道。对了，我想再来一次，就我们两个人……"

translate chinese chinese_9813750_498:
    old "But I have another patient coming, it's too late to cancel it..."
    new "但我还有另一个病人要来，现在已经太晚取消了……"

translate chinese chinese_2542821_499:
    old "Another session, what do you mean?"
    new "另一场是什么意思？"

translate chinese chinese_9259817_500:
    old "Hmm, I mean I need to check something, so let's call it another lesson..."
    new "嗯，我的意思是我要检查一些东西，我们就当是另一节课吧……"

translate chinese chinese_6509288_501:
    old "... Hmm ok, sure."
    new "……嗯，好吧。"

translate chinese chinese_7109632_502:
    old "I know next session is going to be pretty fun, so please sleep well."
    new "我知道下次会很有趣，所以请好好睡觉。"

translate chinese chinese_5786947_503:
    old "I am considering giving you a prize before we start another treatment, just because you were amazing with Angelina..."
    new "我在考虑在我们开始下一轮治疗前给你一个奖励，因为你和安吉丽娜的表现太棒了……"

translate chinese chinese_2550290_504:
    old "Just come see me tomorrow and don't be late."
    new "明天来见我，别迟到。"

translate chinese chinese_2710687_505:
    old "Alright, I will be here."
    new "好吧，我就在这里。"

translate chinese chinese_3685330_506:
    old "Great, see you!"
    new "好的，再见！"

translate chinese chinese_9551367_507:
    old "Hi, I was waiting for you desperately."
    new "喂，我一直在等你。"

translate chinese chinese_4399082_508:
    old "Good morning, thank you I tried to be on time-"
    new "早上好，谢谢，我尽量准时来了—"

translate chinese chinese_4991851_509:
    old "You are, don't worry! It's just that I don't want to talk."
    new "你放心，我只是不想说话。"

translate chinese chinese_5197241_510:
    old "Uhh, w- wha-?"
    new "呃，什——？"

translate chinese chinese_1188459_511:
    old "Let's go to the room, there is no time to lose."
    new "我们去房间吧，时间不等人。"

translate chinese chinese_7557277_512:
    old "Well, I want to fuck you right now, no lessons, no patients just hard sex."
    new "好吧，我现在就想跟你做爱，不想有任何教训或顾忌，就是硬核的性爱。"

translate chinese chinese_7367597_513:
    old "Why don't you make yourself comfortable and let me suck your dick?"
    new "你放松点，让我来吸你的棒怎么样？"

translate chinese chinese_8044800_514:
    old "Yummy!"
    new "真好吃！"

translate chinese chinese_3493697_515:
    old "It's delicious, do you like the way I suck it?"
    new "味道不错，你喜欢我这样吸吗？"

translate chinese chinese_6094217_516:
    old "Wow, I needed that session. You can't imagine how hot it was, you did amazing."
    new "哇，那真是很棒的一次。你无法想象有多激烈，你太棒了。"

translate chinese chinese_9476392_517:
    old "I did my best."
    new "我已经尽力了。"

translate chinese chinese_3853477_518:
    old "Absolutely, you fucked me as I needed to.  I think I need a little more, though..."
    new "绝对的，你按我需要的那样干了我。不过我觉得还需要多来一点……"

translate chinese chinese_8261302_519:
    old "Just keeps coming over sometimes just to... You know, have some fun lessons."
    new "就是有时候过来看看……你知道的，上点有趣的课程。"

translate chinese chinese_1839932_520:
    old "Perfect, and when I need your help again with another patient, I'll let you know."
    new "完美，下次我再需要你帮忙处理其他病人的时候，我会通知你的。"

translate chinese chinese_7176249_521:
    old "Ok, now I have to get ready for the session with my next patient, see you soon [pla]."
    new "好的，现在我得为下一个病人的会诊做准备了，很快见 [pla]。"

translate chinese chinese_7737957_522:
    old "Got it. See you, doctor Johnson."
    new "明白了。再见，约翰逊医生。"

translate chinese chinese_1553322_523:
    old "Oh, wow."
    new "哦，天啊。"

translate chinese chinese_0469404_524:
    old "Hey buddy! What's up?"
    new "嘿哥们儿！最近怎么样？"

translate chinese chinese_6359210_525:
    old "H- Hi."
    new "嗨。"

translate chinese chinese_2026137_526:
    old "Hey [pla], how are you doing?"
    new "嘿[pla]，最近怎么样？"

translate chinese chinese_5792743_527:
    old "Oh, so you guys know each other?"
    new "哦，你们认识啊？"

translate chinese chinese_3637247_528:
    old "Uhh... W- well- "
    new "呃……嗯——"

translate chinese chinese_4156099_529:
    old "Yes! He is the assistant of doctor Johnson... He helped us with... With the treatment..."
    new "没错！他是约翰逊医生的助手……他帮了我们……帮了治疗……"

translate chinese chinese_3191045_530:
    old "Wow, you are quite young, I didn't know you had such wonderful therapy abilities. You must know buddy, you saved my marriage!"
    new "哇，你真是年轻有为，没想到你有这样的治疗能力。你知道吗，你救了我的婚姻！"

translate chinese chinese_3377060_531:
    old "You don't know how important was this, I feel so thankful that I hope you go to the store so I can give an enormous discount."
    new "你不知道这有多重要，我感觉这么感激，希望你能去商店，这样我可以给你一个巨大的折扣。"

translate chinese chinese_0951681_532:
    old "Oh, thanks."
    new "哦，谢谢。"

translate chinese chinese_6684962_533:
    old "I have no words to tell how I appreciate what you did for me, look Angelina is pregnant and we are very happy about it."
    new "我都不知道该怎么表达我对你的感激之情了，你看Angelina怀孕了，我们都很开心。"

translate chinese chinese_3629044_534:
    old "I know the universe will reward you for this magnificent help and-"
    new "我知道宇宙会因为你这次伟大的帮助而奖励你的——"

translate chinese chinese_5623223_535:
    old "We really appreciate your help. Darling we need to go, I want to get some fresh air."
    new "我们真的很感激你的帮助。亲爱的，我们得走了，我想呼吸一下新鲜空气。"

translate chinese chinese_6573881_536:
    old "Oh sure, it was nice to see that you guys are happy."
    new "哦，看到你们开心当然很好。"

translate chinese chinese_2063811_537:
    old "We are very happy to see you too, now excuse us, we have to go."
    new "我们也非常高兴见到你，不过我们现在得走了。"

translate chinese chinese_5179929_538:
    old "... Sure."
    new "...好吧。"

translate chinese chinese_9899973_539:
    old "Have a nice day [pla]!"
    new "祝你今天愉快，[pla]！"

translate chinese chinese_3687950_540:
    old "Yes buddy! Have a great day."
    new "没错兄弟！祝你今天愉快。"

translate chinese chinese_4359528_541:
    old "See you!"
    new "再见！"

translate chinese chinese_1933919_542:
    old "Wow... So, she is pregnant..."
    new "wow... 所以，她是怀孕了..."

translate chinese chinese_6481863_543:
    old "Hi Dr. Johnson, how are you?"
    new "嗨，约翰逊博士，你好吗？"

translate chinese chinese_4235699_544:
    old "Hi [pla], I'm excellent, thanks for asking. What about yourself, young man?"
    new "嗨 [pla]，我很好，谢谢关心。你自己呢，小伙子？"

translate chinese chinese_5857520_545:
    old "I'm good, thanks! And hmm, I would like to talk about s- something with you, it would take just a couple of minutes."
    new "我挺好的，谢谢！还有啊，我想和你谈谈一些事情，就几分钟。"

translate chinese chinese_2232662_546:
    old "Sure, what is it about?"
    new "当然，是关于什么的？"

translate chinese chinese_9001364_547:
    old "I wouldn't like to bother you but I'm f- facing a tough situation now and I'm l- looking for a job."
    new "我不想打扰你，但我现在面临一个棘手的情况，正在找工作。"

translate chinese chinese_4122529_548:
    old "You know I'm a hard worker and I would do whatever you assign to me."
    new "你知道我是个勤勉的人，你会分配给我的任务我都会完成的。"

translate chinese chinese_6648183_549:
    old "I see, but... I can't offer you anything right now."
    new "我明白，但是……我现在什么也给不了你。"

translate chinese chinese_8334974_550:
    old "I don't have any patients for you at the moment..."
    new "我现在没有病人给你……"

translate chinese chinese_2775279_551:
    old "R- really? I had some hopes on you."
    new "真、真的吗？我还对你有些期望呢。"

translate chinese chinese_3439973_552:
    old "Maybe if you think of somethin-"
    new "maybe if you think of somethin- \n\n（注意：原文似乎不完整，翻译保持一致。）"

translate chinese chinese_6349802_553:
    old "[pla], I really don't have anything since I don't have many patients now, however, if I get to need you, I'll reach you out."
    new "[pla]，我现在没什么事情，因为病人不多，但是如果我需要你的话，会联系你的。"

translate chinese chinese_4803687_554:
    old "You have been very well trained and you were exceptional at your duties with the last patient."
    new "你训练有素，之前对那位病人也做得非常出色。"

translate chinese chinese_7845306_555:
    old "I'll call you when I need you..."
    new "等我需要你的时候会打电话给你……"

translate chinese chinese_1071574_556:
    old "I see... Hmm, alright... I'll keep looking for it. Thanks Dr. Johnson, I appreciate your time."
    new "我明白了……嗯，好吧……我会继续找的。谢谢你了，约翰逊博士，我很感激你的时间。"

translate chinese chinese_1180494_557:
    old "Goodbye and keep me posted in case you have jobs for me, I would appreciate it."
    new "再见了，如果有我的工作机会，请记得通知我，我会很感激的。"

translate chinese chinese_5851026_558:
    old "Sure I will, have a nice day."
    new "当然，祝你今天愉快。"

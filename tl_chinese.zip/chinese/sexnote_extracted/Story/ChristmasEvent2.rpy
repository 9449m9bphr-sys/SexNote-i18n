# auto-tl Qwen Colab

translate chinese chinese_1838671_0:
    old "Hmm, what is this?"
    new "嗯，这是什么？"

translate chinese chinese_7407599_1:
    old "What's this feeling?"
    new "这是什么感觉？"

translate chinese chinese_7029127_2:
    old "I- I have a hard-on?!"
    new "我——我硬了？！"

translate chinese chinese_7990531_3:
    old "Lydia?! W- what are you doing?"
    new "莉迪亚？！你你在干什么？"

translate chinese chinese_4975815_4:
    old "Good morning hon! Great, you finally wake up!"
    new "亲爱的，早上好！太好了，你终于醒了！"

translate chinese chinese_7639058_5:
    old "W- what's happenning? What's this?!"
    new "什、什么情况？这是什么？！"

translate chinese chinese_9959774_6:
    old "And what is that you're wearing?!"
    new "那你穿的这是什么玩意儿?!"

translate chinese chinese_3788912_7:
    old "Do you like it? It's my Mrs. Claus outfit for the day!"
    new "你喜欢吗？这是我的今天圣诞夫人装扮！"

translate chinese chinese_4517185_8:
    old "You know, to get in the spirit of Christmas."
    new "你知道的，为了圣诞气氛。"

translate chinese chinese_9403067_9:
    old "Whatever! What are you doing in my room, and giving me a blowjob?!"
    new "随便啦！你在我房间里做什么，还给我口交？！"

translate chinese chinese_8593395_10:
    old "Well, I came to spend Christmas with you guys."
    new "嗯，我是来和你们一起过圣诞的。"

translate chinese chinese_9329512_11:
    old "But when I arrived I saw that you were still sleeping."
    new "但是当我到的时候，看到你还在睡觉。"

translate chinese chinese_7998139_12:
    old "Then I decided to wake you up in a special way!"
    new "然后我决定用特别的方式叫醒你！"

translate chinese chinese_4731961_13:
    old "I guess you can say it is my early Christmas present to you!"
    new "我想说这算是我提前送给你的圣诞礼物吧！"

translate chinese chinese_4907703_14:
    old "What are you talking about?!"
    new "你在说什么？！"

translate chinese chinese_5474412_15:
    old "Do you know what my [mo1rel]'s going to do if she sees what you're doing?!"
    new "你知道如果[mo1rel]看到你在做什么会怎么反应吗？"

translate chinese chinese_0520367_16:
    old "What's gotten into you all of a sudden?"
    new "你突然怎么了？"

translate chinese chinese_3010218_17:
    old "Oh, don't say that."
    new "哦，别这么说。"

translate chinese chinese_7342366_18:
    old "Nothing got into me."
    new "我没中招。"

translate chinese chinese_0776999_19:
    old "I just wanted to start Christmas the right way."
    new "我只是想以正确的方式开始圣诞节。"

translate chinese chinese_2487106_20:
    old "I bet you can help me with that."
    new "我相信你能帮我解决这个问题。"

translate chinese chinese_6110890_21:
    old "After all, you have something I want in me..."
    new "毕竟，你身上有我想要的东西..."

translate chinese chinese_1989640_22:
    old "W- what? You must be kidding me!"
    new "什、什么？你一定是在开玩笑！"

translate chinese chinese_1810553_23:
    old "Don't be so shy baby"
    new "别那么害羞宝贝"

translate chinese chinese_7864912_24:
    old "After all, it's not like you haven't done it before."
    new "反正你也不是第一次做了。"

translate chinese chinese_8717491_25:
    old "Besides, I can see very clearly that you want it."
    new "再说，我看得出来你很想要。"

translate chinese chinese_2308783_26:
    old "T- that's just because you woke me up that way!"
    new "那、那只是因为你那样把我吵醒的！"

translate chinese chinese_6825053_27:
    old "It- it will go down in a minute."
    new "它——它一会儿就会下去的。"

translate chinese chinese_6093782_28:
    old "Oh, but I can't let that happen!"
    new "哦，但我不能让那种事发生！"

translate chinese chinese_1993583_29:
    old "I haven't had any breakfast yet, and I think I want some of your eggnog!"
    new "我还没吃早餐呢，我觉得我想喝点你的蛋酒！"

translate chinese chinese_2747367_30:
    old "My god, I love the taste and smell of your dick!"
    new "天啊，我爱你这味道和气味！"

translate chinese chinese_0816777_31:
    old "I'm already so wet!"
    new "我已经湿透了！"

translate chinese chinese_6133634_32:
    old "What a shame we don't have much time."
    new "真可惜，我们时间不多。"

translate chinese chinese_9692803_33:
    old "Otherwise I'd like to do something else..."
    new "不然我想做别的事情……"

translate chinese chinese_5378574_34:
    old "Well, that was a great way to start the day, right [pla]?"
    new "嗯，这真是个不错的开始，对吧，[pla]？"

translate chinese chinese_3303272_35:
    old "I'll go say good morning to the rest of the family."
    new "我去跟家里其他人说早上好。"

translate chinese chinese_5062533_36:
    old "So, you can get dressed in peace."
    new "这样，你可以安心穿衣服了。"

translate chinese chinese_5351212_37:
    old "Uhh... sure."
    new "呃……好吧。"

translate chinese chinese_9816709_38:
    old "W- what? What was that? What's happening?"
    new "什、什么？那是什么？发生什么事了？"

translate chinese chinese_2208259_39:
    old "I was asking you if you had a minute, I have something to show you..."
    new "我问你有没有空，我有东西要给你看……"

translate chinese chinese_2946040_40:
    old "Excuse me?"
    new "抱歉？"

translate chinese chinese_0033775_41:
    old "Uhh, nevermind... Uhh, what do you want to show me?"
    new "呃，算了吧……呃，你想给我看什么？"

translate chinese chinese_4567217_42:
    old "Hmm, come to my bedroom with me."
    new "嗯，跟我来卧室吧。"

translate chinese chinese_4255245_43:
    old "Uh, sure."
    new "呃，好吧。"

translate chinese chinese_8370886_44:
    old "So, I wanted to show you the new Christmas clothes that just arrived."
    new "所以，我想给你看看刚到的圣诞新衣服。"

translate chinese chinese_4504924_45:
    old "They're for the shop."
    new "这些是给店铺的。"

translate chinese chinese_9439888_46:
    old "That's great [sis]."
    new "那太好了，[sis]。"

translate chinese chinese_7884760_47:
    old "Do you want to see them?"
    new "你想看看它们吗？"

translate chinese chinese_6681578_48:
    old "Great! Just wait here."
    new "好极了！你就在这里等着吧。"

translate chinese chinese_0795203_49:
    old "Ok, this is the first one, what do you think?"
    new "好的，这是第一个，你觉得怎么样？"

translate chinese chinese_0874883_50:
    old "I think it's great, very festive, it suits you."
    new "我觉得很好，很应景，很适合你。"

translate chinese chinese_6898454_51:
    old "I'm sure it's going to sell great."
    new "我敢肯定这会卖得很火。"

translate chinese chinese_5214714_52:
    old "That's just what I thought."
    new "这正是我所想的。"

translate chinese chinese_3666751_53:
    old "Let me show you the other one."
    new "让我给你看另一个。"

translate chinese chinese_4063843_54:
    old "So, what about this one?"
    new "那么，这个怎么样？"

translate chinese chinese_9544887_55:
    old "This one is my favorite."
    new "这个是我最喜欢的。"

translate chinese chinese_2905204_56:
    old "I- I mean, it looks great on you."
    new "我——我是说，你穿上真好看。"

translate chinese chinese_4757235_57:
    old "I'm not sure this counts as an outfit per se."
    new "我不确定这算不算是一套衣服。"

translate chinese chinese_1500346_58:
    old "But maybe it will sell well as lingerie."
    new "但也许作为内衣会卖得很好。"

translate chinese chinese_0082696_59:
    old "This one could also be good for the ladies that want to surprise their husbands and boyfriends."
    new "这个也适合想给丈夫或男朋友惊喜的女士们。"

translate chinese chinese_2631858_60:
    old "Yeah, and it's very comfortable too."
    new "是啊，而且非常舒服。"

translate chinese chinese_3098519_61:
    old "The fabric's very soft."
    new "这布料很软。"

translate chinese chinese_9140744_62:
    old "Uhhh... What are we doing [sis]?"
    new "呃……我们在干什么[sis]？"

translate chinese chinese_4463562_63:
    old "Oh well, I just want you to feel the fabric."
    new "哦，我只是想让你感受一下这布料。"

translate chinese chinese_6619582_64:
    old "What do you think? Isn't it soft?"
    new "你觉得怎么样？不是挺软的吗？"

translate chinese chinese_7829807_65:
    old "I- I guess it is, yeah..."
    new "我——我猜是这样的……"

translate chinese chinese_4711505_66:
    old "But how much do you like it?"
    new "但是你有多喜欢呢？"

translate chinese chinese_2048670_67:
    old "Let me see how you feel down here..."
    new "让我看看你这里的感觉……"

translate chinese chinese_2663806_68:
    old "W- What are you doing [sis]?!"
    new "你干什么呢[sis]?!"

translate chinese chinese_1451608_69:
    old "I just wanted to see how much you like my outfit..."
    new "我只是想看看你喜不喜欢我的这套衣服..."

translate chinese chinese_7891381_70:
    old "And oh my god! Look at that!"
    new "天啊！你看那个！"

translate chinese chinese_9117348_71:
    old "You clearly really like it!"
    new "你明显很享受嘛！"

translate chinese chinese_6149362_72:
    old "Uh... I- I mean."
    new "呃……我——我的意思是。"

translate chinese chinese_8869061_73:
    old "It's ok [pla] I know you love it."
    new "没事的[pla]，我知道你喜欢的。"

translate chinese chinese_4539529_74:
    old "Just look at that big cock!"
    new "看看那大鸡巴！"

translate chinese chinese_8325877_75:
    old "What I could with it..."
    new "我用它能做什么……"

translate chinese chinese_3350622_76:
    old "I'm sure the clients will love this new line!"
    new "我敢肯定客户会喜欢这个新系列的！"

translate chinese chinese_5745141_77:
    old "Umm, yeah, I guess they will."
    new "嗯，是的，我想他们会的。"

translate chinese chinese_3056620_78:
    old "Hey, listen [sis]... Do you feel well?"
    new "嘿，听一下[sis]……你觉得还好吗？"

translate chinese chinese_0850221_79:
    old "Me? I feel great!"
    new "我？我觉得棒极了！"

translate chinese chinese_9686445_80:
    old "Why do you ask?"
    new "你为什么问这个？"

translate chinese chinese_7874993_81:
    old "No reason, it's just a strange feeling..."
    new "没有理由，就是一种奇怪的感觉……"

translate chinese chinese_4251150_82:
    old "You know what? Forget it, it must be my imagination."
    new "你知道吗？算了吧，一定是我的错觉。"

translate chinese chinese_4205239_83:
    old "Well, I have to work on some things for the website, you can leave now."
    new "嗯，我得处理一些网站的事情，你可以走了。"

translate chinese chinese_6343085_84:
    old "Uhh, right..."
    new "呃，对了……"

translate chinese chinese_7615177_85:
    old "Uhh... That was weird..."
    new "呃……那真是奇怪……"

translate chinese chinese_1791085_86:
    old "I still has that strange feeling... What was that?"
    new "我仍然有种奇怪的感觉……那是什么？"

translate chinese chinese_5367597_87:
    old "Anyway, I better go downstairs and see what happened with Lydia..."
    new "不管怎样，我还是下去看看莉迪亚发生了什么吧……"

translate chinese chinese_5908128_88:
    old "Ah! [pla] honey!"
    new "啊！[pla]亲！"

translate chinese chinese_7421771_89:
    old "You've arrived, wonderful!"
    new "你来了，太好了！"

translate chinese chinese_3367452_90:
    old "We're opening our Christmas gifts, you're just in time."
    new "我们在拆圣诞礼物，你正好赶上。"

translate chinese chinese_6778001_91:
    old "It's your turn now [mo1], and this one's from me, why don't you open it?"
    new "现在轮到你了[mo1]，这个是我给你的，为什么不打开看看？"

translate chinese chinese_7349097_92:
    old "Oh! Honey! Thank you!"
    new "哦！亲爱的！谢谢你！"

translate chinese chinese_5907483_93:
    old "I can't wait to see what it is!"
    new "我迫不及待想看看是什么！"

translate chinese chinese_1868849_94:
    old "Oh my god [mo2]! This is just what I wanted!"
    new "天啊[mo2]！这正是我想要的！"

translate chinese chinese_4936482_95:
    old "(Is that a bottle of lube?)"
    new "（那是瓶润滑剂吗？）"

translate chinese chinese_5527557_96:
    old "Of course I do! This is my favorite brand!"
    new "当然有啦！这是我最喜欢的牌子！"

translate chinese chinese_9603983_97:
    old "You know, this lube is very good because it enhance all sensations."
    new "你知道吗，这款润滑剂非常好，因为它能增强所有的感觉。"

translate chinese chinese_6045156_98:
    old "(Holy shit, yes it is...)"
    new "（天呐，真的是……）"

translate chinese chinese_4898497_99:
    old "So, when we use it you can feel even harder when you're getting railed."
    new "所以，用这个的时候，你会觉得被顶得更紧更硬。"

translate chinese chinese_6062231_100:
    old "(What the... Why are they talking like that in front of Lydia...)"
    new "（什么……他们为什么当着莉迪亚的面说这种话……）"

translate chinese chinese_5037166_101:
    old "Oh honey! That sounds fantastic! We have to use it as soon as we can!"
    new "哦亲爱的！那听起来太棒了！我们必须尽快使用它！"

translate chinese chinese_3363888_102:
    old "Off course! I really enjoy this one, is really warm..."
    new "当然！我真的很喜欢这个，真的很有暖意..."

translate chinese chinese_7546110_103:
    old "We have to put it to the test to see if you like it."
    new "我们得试试看你会不会喜欢。"

translate chinese chinese_8704631_104:
    old "Oh please, stop..."
    new "哦天啊，停下来..."

translate chinese chinese_7447940_105:
    old "Come on [mo2], is this a gift for [mo1], or is it a gift for you?"
    new "来吧[mo2]，这是给[mo1]的礼物，还是给你自己的？"

translate chinese chinese_7504341_106:
    old "(What the...)"
    new "（什么回事……）"

translate chinese chinese_9872384_107:
    old "There's no reason why it couldn't be for the both of us!"
    new "没有理由不能是为我们两个的！"

translate chinese chinese_0347616_108:
    old "As long as we both enjoy it, who cares who it is for!"
    new "只要我们两个都玩得开心，管它是为了谁！"

translate chinese chinese_5559458_109:
    old "That's right Lydia, relax."
    new "说得对，莉迪亚，放松点。"

translate chinese chinese_5625325_110:
    old "After all, I can fuck [mo1] with it, but she can also rail me later."
    new "毕竟，我可以和[mo1]搞，但她后来也可以给我来个底朝天。"

translate chinese chinese_3892233_111:
    old "I guess you're right [mo1], [mo2]."
    new "我想你是对的，[mo1]，[mo2]。"

translate chinese chinese_0377288_112:
    old "All gifts should be enjoyed equally."
    new "所有的礼物都应该平等享受。"

translate chinese chinese_1673670_113:
    old "I think everybody should get to have a good time with these gifts."
    new "我觉得每个人都应该有机会用这些礼物玩得开心。"

translate chinese chinese_5278676_114:
    old "Oh, I agree with that."
    new "哦，我同意这一点。"

translate chinese chinese_2203822_115:
    old "Uhh... W- what is happening?"
    new "呃……这、这是怎么回事？"

translate chinese chinese_1221555_116:
    old "Thinking about it... [pla], you haven't opened your presents yet."
    new "想一想吧……[pla]，你还没打开礼物呢。"

translate chinese chinese_0888726_117:
    old "M- me?"
    new "我？"

translate chinese chinese_4503167_118:
    old "{i}(I don't think I like where this is going.){/i}"
    new "{i}我觉得这事不太对劲。{/i}"

translate chinese chinese_4694710_119:
    old "I think I'm ok for now."
    new "我觉得我现在还好。"

translate chinese chinese_4579981_120:
    old "I'll open my gifts later."
    new "我待会再打开礼物。"

translate chinese chinese_9257973_121:
    old "Don't be foolish sweetie! You have to open them right now!"
    new "别傻了宝贝！你必须现在就打开它们！"

translate chinese chinese_2033261_122:
    old "Otherwise it is no fun."
    new "不然就没意思了。"

translate chinese chinese_2778260_123:
    old "That's right [pla], come honey, open your presents."
    new "没错 [pla]，来吧宝贝，打开你的礼物。"

translate chinese chinese_2294015_124:
    old "I- I'm not sure I should."
    new "我——我不确定该不该。"

translate chinese chinese_2652230_125:
    old "Don't be a brag and do it!"
    new "别吹牛了，赶紧做吧！"

translate chinese chinese_1141005_126:
    old "W- WHAT THA FUCK? THIS WEIRD THING AGAIN???"
    new "W- 去你妈的？这奇怪的东西又来了？？？"

translate chinese chinese_2966235_127:
    old "Oh, don't worry honey, this is just one of your Christmas gifts."
    new "哦，别担心亲爱的，这只是你的圣诞礼物之一。"

translate chinese chinese_4855506_128:
    old "After all you have been such a good boy this year."
    new "毕竟你今年表现这么好。"

translate chinese chinese_8216428_129:
    old "And we have been such naughty girls."
    new "我们真是调皮的女孩。"

translate chinese chinese_8157588_130:
    old "So, just relax and let us take care of you for a chance."
    new "所以，放松点，让我们来照顾你一番吧。"

translate chinese chinese_5977493_131:
    old "{i}(What the hell is happening with them?){/i}"
    new "{i}(他们到底发生了什么？){/i}"

translate chinese chinese_4511543_132:
    old "{i}(Lydia had already been acting weird since this morning.){/i}"
    new "{i}（莉迪亚今天早上就开始行为古怪。）{/i}"

translate chinese chinese_5046728_133:
    old "{i}(But now even [mo2] and [mo1] are doing this!){/i}"
    new "{i}（但是现在连[mo2]和[mo1]也在这么做！）{/i}"

translate chinese chinese_9889222_134:
    old "{i}(Not to mention the way [sis] was acting when I went into her room...){/i}"
    new "{i}（更不用说我去她房间时她的表现了……）{/i}"

translate chinese chinese_0004070_135:
    old "{i}(I figure this must be another one of those dreams? There's no other way of explaining this.){/i}"
    new "{i}（我想这肯定又是那种梦吧？没法解释这种情况。){/i}"

translate chinese chinese_9251172_136:
    old "{i}(So, if this is a dream...){/i}"
    new "{i}（所以，如果这是梦的话……）{/i}"

translate chinese chinese_4866796_137:
    old "{i}(I guess I can just enjoy it, right?){/i}"
    new "{i}（我想我只要享受就好了，对吧？){/i}"

translate chinese chinese_0502422_138:
    old "Woww... That thing again... I'm starting to feel dizzy..."
    new "wow...那个东西又来了...我开始觉得头晕..."

translate chinese chinese_2176275_139:
    old "God [pla], you're so hard!"
    new "上帝[pla]，你真够硬的！"

translate chinese chinese_7432703_140:
    old "(What the fuck?? Now is [sis] here too?)"
    new "（什么情况？这家伙也在这里？）"

translate chinese chinese_1792079_141:
    old "{i}(I guess I was right, this must be a dream.){/i}"
    new "{i}（我想我是对的，这肯定是在做梦。){/i}"

translate chinese chinese_9891910_142:
    old "And your cock is so big!"
    new "而且你的 cock 真的大！"

translate chinese chinese_8428000_143:
    old "And your tongue is so good baby!"
    new "你的舌头真棒宝贝！"

translate chinese chinese_3408556_144:
    old "Oh! [mo2] honey, I love how you eat me out!"
    new "哦！[mo2]甜心，我喜欢你这样让我高潮的感觉！"

translate chinese chinese_9382791_145:
    old "{i}(Well, I think I just should just keep enjoying it.){/i}"
    new "{i}（嗯，我觉得我还是继续享受吧。）{/i}"

translate chinese chinese_9067561_146:
    old "{i}(When am I going to have another dream like this?){/i}"
    new "{i}（我什么时候还能再做这样的梦？）{/i}"

translate chinese chinese_0947549_147:
    old "L- Linett, whoah! You're in my dream too?"
    new "L- Linett，哇！你也在我梦里？"

translate chinese chinese_8127504_148:
    old "Did you come to join in on the fun?"
    new "你是来加入好玩的吗？"

translate chinese chinese_9744931_149:
    old "I mean, I haven't done it with shinigamis and humans simultaneously."
    new "我的意思是，我还没同时和死神和人类做过呢。"

translate chinese chinese_1349638_150:
    old "But it could be interesting! Hop in!"
    new "但这也挺有意思的！上来吧！"

translate chinese chinese_7270817_151:
    old "What? What are you talking about?"
    new "什么？你在说什么？"

translate chinese chinese_5105644_152:
    old "Oh come on, you don't have to act like you don't want it."
    new "哦，别这样，你不用装作不想似的。"

translate chinese chinese_3652750_153:
    old "This is a dream after all."
    new "这毕竟只是个梦。"

translate chinese chinese_9650102_154:
    old "This isn't a dream you dumbass!"
    new "这可不是梦你白痴！"

translate chinese chinese_9576735_155:
    old "W- What? What do you mean?"
    new "什、什么？你什么意思？"

translate chinese chinese_3552775_156:
    old "As you heard, this isn't a dream!"
    new "就像你听到的，这可不是梦！"

translate chinese chinese_1010327_157:
    old "This is all real [pla]!"
    new "这一切都是真实的[pla]！"

translate chinese chinese_1311426_158:
    old "Apparently the magic concentrating spell we did in the church."
    new "看来是在教堂里做的那个集中魔法的仪式。"

translate chinese chinese_2834744_159:
    old "Seems to have affected reality in a way we couldn't predict."
    new "似乎以我们无法预测的方式影响了现实。"

translate chinese chinese_2245533_160:
    old "The ritual was successful but it's now starting to gather magic from all around."
    new "仪式成功了，但现在开始从周围聚集魔法了。"

translate chinese chinese_7318249_161:
    old "And given that most magic in this world is stored in human bodies, it's trying to force it out!"
    new "而鉴于这个世界大多数魔法都储存在人体内，它正在试图把魔法逼出来！"

translate chinese chinese_0846184_162:
    old "When that happens to human bodies they start to feel their life energy deplete."
    new "当这种情况发生在人类身上时，他们会开始感到生命能量在流失。"

translate chinese chinese_0519631_163:
    old "So, all the weird human behavior is caused because of the magic power..."
    new "所以，所有奇怪的人类行为都是因为魔法力量..."

translate chinese chinese_5745517_164:
    old "They're not really themselves, they're in a sort of magically unconscious state..."
    new "他们不是真正的自己，处于一种魔法定神的状态……"

translate chinese chinese_0787635_165:
    old "And if it isn't stopped now it will wreak havoc in this world."
    new "如果现在不阻止它，它就会在这个世界上制造混乱。"

translate chinese chinese_4342564_166:
    old "Although it already started. So, we have very little time."
    new "虽然已经开始了。所以我们时间不多。"

translate chinese chinese_9816414_167:
    old "Truth be told, when we did the last ritual I noticed something was odd."
    new "说起来，在我们上次做仪式的时候，我注意到有些不对劲。"

translate chinese chinese_2103767_168:
    old "I probably should've done something about it then."
    new "我当时 probably 应该做点什么的。  \n\nNote: The word \"probably\" is kept in English as per the instruction to keep Latin names and words. However, for better fluency, it might be translated as \"大概\" or \"可能\". If you want it translated, please let me know."

translate chinese chinese_9820070_169:
    old "But I didn't expect anything like this to happen."
    new "但我没想到会发生这样的事。"

translate chinese chinese_9663113_170:
    old "I- I- I'm not getting it at all..."
    new "我一点都看不懂..."

translate chinese chinese_5269768_171:
    old "What I'm telling you is that reality is starting to fragment!"
    new "我要告诉你的是，现实开始碎片化了！"

translate chinese chinese_5943449_172:
    old "So, we have to hurry and do something about it!"
    new "所以，我们必须赶紧采取行动！"

translate chinese chinese_2430412_173:
    old "The ritual we did was successful."
    new "我们做的仪式成功了。"

translate chinese chinese_3105688_174:
    old "The problem  is that there's not enough magic density in this world to just create a portal."
    new "问题是这个世界里的魔法密度不够，无法直接创建一个传送门。"

translate chinese chinese_4039192_175:
    old "What can we do about it?"
    new "我们能怎么办？"

translate chinese chinese_9280489_176:
    old "I have a couple ideas."
    new "我有几个想法。"

translate chinese chinese_5266795_177:
    old "Honestly I don't know if what I'm thinking off will work."
    new "老实说，我不知道我的想法能不能行。"

translate chinese chinese_7083699_178:
    old "So, we'll have to try a couple of things to see what sticks."
    new "所以，我们得试试几种方法看看哪种有效。"

translate chinese chinese_3023757_179:
    old "But whatever it is we do."
    new "但是无论我们做什么。"

translate chinese chinese_8048955_180:
    old "I'm sure we'll need the other three shinigami for it, so, let's go."
    new "我相信我们需要那三个死神，所以走吧。"

translate chinese chinese_9626362_181:
    old "W- What? Who are you?!"
    new "什、什么？你是谁?!"

translate chinese chinese_9337294_182:
    old "What the fuck is going on here?!"
    new "这里到底发生了什么回事?!"

translate chinese chinese_1100182_183:
    old "Uh- Listen, I don't know who you are."
    new "呃——听着，我不知道你是谁。"

translate chinese chinese_6291205_184:
    old "I didn't even know there was another shinigami around."
    new "我甚至不知道周围还有另一个死神。"

translate chinese chinese_5674955_185:
    old "But nice to meet you... I guess. I'm Linnet."
    new "不过见到你也不错……我想。我是林内特。"

translate chinese chinese_5951427_186:
    old "Listen, right now there's no time for us to talk."
    new "听着，现在没时间聊天。"

translate chinese chinese_6284605_187:
    old "In case you haven't noticed, reality is tearing itself apart!"
    new "你没注意到吗？现实正在分崩离析！"

translate chinese chinese_5635414_188:
    old "Are you going to help us or not?!"
    new "你到底帮不帮我们?!"

translate chinese chinese_6290888_189:
    old "Oh, I know full well who you are!"
    new "哦，我可清楚你是谁！"

translate chinese chinese_7787227_190:
    old "You're that idiot that keeps messing with the magic of this world!"
    new "你就是那个一直干扰这个世界魔法的白痴！"

translate chinese chinese_4697981_191:
    old "Look at the mess you've made!"
    new "看看你搞的什么 mess！"

translate chinese chinese_6863619_192:
    old "Not to mention that you keep setting [pla] down the wrong path!"
    new "更别提你一直把[pla]引向错误的道路了！"

translate chinese chinese_7420675_193:
    old "Don't you see you're screwing our only chance of fixing the magical world?"
    new "你难道没看到你在毁掉我们唯一修复魔法世界的机会吗？"

translate chinese chinese_7902981_194:
    old "I'M NOT GOING TO LET YOU CONTINUE RUINING EVERYTHING!"
    new "我不会让你继续破坏一切的！"

translate chinese chinese_0732693_195:
    old "B- Brixxida! W- What are you doing? She's an ally!"
    new "布- 布里克西达！你你在干什么？她是盟友！"

translate chinese chinese_4687667_196:
    old "Oh! You shut up! Enough with the stupidities!"
    new "哦！你闭嘴！别再胡说了！"

translate chinese chinese_3348171_197:
    old "You've already ruined too many things."
    new "你已经毁掉太多东西了。"

translate chinese chinese_8248375_198:
    old "And I won't keep risking my life, this world, and the magic world."
    new "我不会再拿我的生命、这个世界和魔法世界冒险了。"

translate chinese chinese_9376205_199:
    old "Because of the actions of a group of stupid inexperienced shinigamis."
    new "因为一群愚蠢又没经验的死神搞出来的。"

translate chinese chinese_1248292_200:
    old "There, you take care of that."
    new "好了，你处理一下这个。"

translate chinese chinese_0178307_201:
    old "Put her some place where she won't be a bother."
    new "把她放到不会打扰到别人的地方。"

translate chinese chinese_2639458_202:
    old "And come with me [pla], I'll fix this quickly."
    new "然后跟我来 [pla]，我会快点解决这个问题。"

translate chinese chinese_6264655_203:
    old "So, what are we doing here?"
    new "那么，我们在这里干什么？"

translate chinese chinese_9741023_204:
    old "I don't see anything wrong..."
    new "我没看出有什么不对劲..."

translate chinese chinese_4824112_205:
    old "Oh really? Use your Eye of Agamotto..."
    new "哦真的吗？用你的阿加莫托之眼……"

translate chinese chinese_8830554_206:
    old "Uhh... Alright..."
    new "呃……好吧……"

translate chinese chinese_9021629_207:
    old "Woah! What's this? What's happening?"
    new "哇！这是什么？发生什么事了？"

translate chinese chinese_8017560_208:
    old "This is what you and that idiot did!"
    new "这就是你和那个白痴干的好事！"

translate chinese chinese_5547806_209:
    old "What you're seeing is the result of a difficult spell being casted by an inexpert hand."
    new "你看到的是一个不熟练的人施了一个困难的咒语的结果。"

translate chinese chinese_5114055_210:
    old "This is why you should've come to me with these things [pla]!"
    new "这就是为什么你应该把这些事情告诉我[pla]的原因！"

translate chinese chinese_6263735_211:
    old "But it's ok, I'm here now."
    new "但是没关系，我现在在这里。"

translate chinese chinese_1392204_212:
    old "Ok, but what's your plan to fix all this?"
    new "好吧，但你打算怎么解决这一切？"

translate chinese chinese_7265904_213:
    old "Just watch."
    new "看着吧。"

translate chinese chinese_8445264_214:
    old "Now! Quick! We have to go to your house to stabilize it!"
    new "快！我们现在要去你家稳定它！"

translate chinese chinese_8744935_215:
    old "Woah, Woah! What do you mean?!"
    new "喂，喂！你什么意思？！"

translate chinese chinese_8552053_216:
    old "Are you planning on putting that in my house?"
    new "你打算把那个放在我家里吗？"

translate chinese chinese_8399195_217:
    old "Don't worry nothing will happen."
    new "放心，没什么会发生的。"

translate chinese chinese_3498988_218:
    old "Unlike your little friend, I know how to do things properly."
    new "不像你那个小朋友，我知道怎么做得正规。"

translate chinese chinese_5111117_219:
    old "So, let's hurry and go to your house!"
    new "好了，赶紧去你家吧！"

translate chinese chinese_8003597_220:
    old "R- Right!"
    new "对！"

translate chinese chinese_7748691_221:
    old "So, what now?"
    new "那现在怎么办？"

translate chinese chinese_0563063_222:
    old "I'm going to invoke the portal here."
    new "我要在这里开启传送门。"

translate chinese chinese_4052061_223:
    old "Oh wow..."
    new "哦 wow..."

translate chinese chinese_0978479_224:
    old "{b}*Sigh*{/b} That was dangerous."
    new "{b}*叹气*{/b}那真是太危险了。"

translate chinese chinese_4695642_225:
    old "But at least we now have a portal."
    new "但至少我们现在有一个传送门了。"

translate chinese chinese_3151231_226:
    old "Uhh... So, does that mean that we can go to the magical world now?"
    new "呃……所以，这意思是我们现在可以去魔法世界了？"

translate chinese chinese_5235149_227:
    old "Of course not. Going from one world to another is not that easy!"
    new "当然不是。从一个世界到另一个世界可不是那么容易的！"

translate chinese chinese_2365733_228:
    old "To work, this portal needs a massive amount of magic to finish its development."
    new "要完成这个传送门的开发，需要大量的魔法。"

translate chinese chinese_3366172_229:
    old "What it was doing before was sucking all of the magic power around, without any control or direction."
    new "它之前是在无序地吸收周围的所有魔力。"

translate chinese chinese_8581441_230:
    old "That could've ended the world."
    new "那差点就毁了世界。"

translate chinese chinese_1527157_231:
    old "I just stabilized it so that it wouldn't continue extracting magic from all around and destroy the world."
    new "我只是稳定了一下，防止它继续从周围抽取魔法，破坏这个世界。"

translate chinese chinese_0191630_232:
    old "What we must do now is feed it magic power in a more controlled way."
    new "我们现在必须做的是以更可控的方式为它注入魔力。"

translate chinese chinese_1618792_233:
    old "Uh... ok."
    new "呃……好。"

translate chinese chinese_4377888_234:
    old "So, how do we feed it magic power now?"
    new "那么，我们现在怎么给它注入魔力呢？"

translate chinese chinese_7240207_235:
    old "Well, normally it would be just a simple issue of using the eye of Agamoto to stock up in magic power."
    new "嗯，通常情况下，这只是一个简单的问题，用阿加莫托之眼来储备魔力就行了。"

translate chinese chinese_0350601_236:
    old "And then just release it in the portal."
    new "然后直接在 портал 里发布就行了。"

translate chinese chinese_5261744_237:
    old "But now, due to you and your little friend messing up."
    new "但是现在，因为你和你的小朋友搞砸了。"

translate chinese chinese_0586222_238:
    old "It extracted a lot of free-flowing energy from the world."
    new "它从世界上汲取了大量的自由能量。"

translate chinese chinese_7204619_239:
    old "We can get it back, but it's going to take a longer time. And it will be a lot more dangerous."
    new "我们可以拿回来，但需要更长的时间。而且会危险得多。"

translate chinese chinese_1474184_240:
    old "All thanks to you and that stupid little shinigami with which you have been playing."
    new "全都是因为你和那个愚蠢的小死神，你一直在玩弄它。"

translate chinese chinese_1659620_241:
    old "I'm sorry Brixxida, all I wanted was to help, you know?"
    new "对不起，布里克西达，我只是想帮忙而已，你知道的？"

translate chinese chinese_5070304_242:
    old "Hmph."
    new "哼。"

translate chinese chinese_5791374_243:
    old "So, what can we do to make the portal work?"
    new "那么，我们该怎么让传送门运作起来呢？"

translate chinese chinese_0668063_244:
    old "Well, the only way is to seed the magic power..."
    new "好吧，唯一的方法就是注入魔力..."

translate chinese chinese_7333814_245:
    old "Seed the magic power? What's that?"
    new "注入魔力？那是什么？"

translate chinese chinese_9588504_246:
    old "It's a magic ritual we use to concentrate magic power."
    new "这是一种用来集中魔力的魔法仪式。"

translate chinese chinese_5847232_247:
    old "By incubating it inside the bodies of humans."
    new "通过在人体内孵化。"

translate chinese chinese_1226413_248:
    old "The power grows and concentrates over time. Until it finally flows out and into the portal."
    new "力量随着时间的增长而集中，直到最终流向 портал。"

translate chinese chinese_6826784_249:
    old "Ok, I think I get it. So, how do we do it?"
    new "好吧，我想我明白了。那我们怎么操作呢？"

translate chinese chinese_7722403_250:
    old "There's only one real way to do it. You have to plan the seed inside the body."
    new "只有一个真正的方法。你得把种子种到身体里。"

translate chinese chinese_8811187_251:
    old "Once inside it gestates and grows, until it's time to come out."
    new "一旦进入体内就会生长发育，直到它出来的时候。"

translate chinese chinese_7473283_252:
    old "Ok, but how do I do it?"
    new "好的，但我要怎么做？"

translate chinese chinese_3326648_253:
    old "Well, you have to seed them the same way you gather and give magic power out."
    new "好吧，你得用同样的方式给它们充能，就像你收集和施放魔法一样。"

translate chinese chinese_2667343_254:
    old "Woah! Woah! Woah! You mean I have to impregnate them?!"
    new "哇！哇！哇！你是说我要让他们怀孕？！"

translate chinese chinese_3875767_255:
    old "In human terms, that's what it's called, yeah."
    new "用人类的说法，就是这样的，没错。"

translate chinese chinese_7526709_256:
    old "What the fuck? Are you for real?"
    new "妈的，你是认真的吗？"

translate chinese chinese_9773273_257:
    old "I'm way too young to have children!"
    new "我才太年轻，不能有孩子！"

translate chinese chinese_5989604_258:
    old "But don't worry, it's not the way you think."
    new "但别担心，不是你想的那样。"

translate chinese chinese_8233904_259:
    old "During the growing period, the magic power will concentrate without a particular form."
    new "在成长期，魔力会以没有特定形态的方式集中起来。"

translate chinese chinese_6726815_260:
    old "And it will only change if, you decide it to be anything in particular."
    new "而只有当你决定让它变成什么的时候，它才会改变。"

translate chinese chinese_8809701_261:
    old "It means that if you just take out all of the magic power from these women it will just be energy."
    new "这意味着如果你把这些女人身上的魔力全部抽出来，那就只是能量了。"

translate chinese chinese_2797999_262:
    old "Pure magic energy, without any form in particular."
    new "纯粹的魔法能量，没有任何特定形态。"

translate chinese chinese_1151296_263:
    old "And it will only take the shape of a human infant if you decide that you will leave energy remains behind."
    new "只有当你决定留下能量残余时，它才会呈现人类婴儿的形态。"

translate chinese chinese_2091357_264:
    old "Otherwise there won't be any reproduction between you and the humans we use for this ritual."
    new "否则你就不能和我们用来进行这个仪式的人类繁殖了。"

translate chinese chinese_9549281_265:
    old "I- I see, I guess that's..."
    new "我……我明白了，大概这就是……"

translate chinese chinese_6517566_266:
    old "Fine, I guess?"
    new "好吧，大概？"

translate chinese chinese_9600092_267:
    old "However, until the magic power is ready to be taken out of their bodies and we do it."
    new "然而，在魔法力量准备好从他们体内取出之前，我们必须这么做。"

translate chinese chinese_2955634_268:
    old "They will look like they are pregnant."
    new "他们会看起来像怀孕了一样。"

translate chinese chinese_3608166_269:
    old "The entire process it's going to be very similar to the way you humans gestate your infants."
    new "整个过程将会非常类似于人类孕育婴儿的方式。"

translate chinese chinese_5298461_270:
    old "Is just that at the end of it, there won't necessary be another human."
    new "只是到了最后，不一定会有另一个人类。"

translate chinese chinese_2253097_271:
    old "So, their bodies will just go back to how they were before the ritual started."
    new "所以，他们的身体会恢复到仪式开始前的状态。"

translate chinese chinese_8255212_272:
    old "I get it now."
    new "我现在明白了。"

translate chinese chinese_8232090_273:
    old "Listen, I know you don't like it."
    new "听着，我知道你不喜欢这样。"

translate chinese chinese_5554021_274:
    old "But for now, that's the only way we have to power up the portal and return the magic world to what it was before."
    new "但目前，这是唯一能启动传送门并恢复魔法世界原貌的方法。"

translate chinese chinese_6707445_275:
    old "Not to mention avoiding the destruction of yours."
    new "更不用说避免你的毁灭了。"

translate chinese chinese_0212613_276:
    old "I get it."
    new "我明白了。"

translate chinese chinese_4021074_277:
    old "If I have to do it, I guess there's no choice."
    new "如果非要做的话，我想也没办法了。"

translate chinese chinese_5317250_278:
    old "By the way; from now on, I will be in charge of everything, you get that?"
    new "对了，从现在开始，一切由我负责，你明白吗？"

translate chinese chinese_7641664_279:
    old "No more running around like an idiot with you dumbass shinigami friends messing everything up!!"
    new "再也不要和你们这些笨死神朋友像白痴一样乱跑了！！"

translate chinese chinese_1482217_280:
    old "Uh. I- sure..."
    new "呃。我——好吧……"

translate chinese chinese_2560428_281:
    old "Good, I'm glad you understand that."
    new "好，我很高兴你能明白这一点。"

translate chinese chinese_4602157_282:
    old "Now, get ready, because there are a lot of things you will need to learn about all of this."
    new "好了，准备好吧，因为有很多事情你需要了解。"

translate chinese chinese_9810856_283:
    old "Oh, man... Alright..."
    new "哦，好吧……"

translate chinese chinese_9321535_284:
    old "I guess I'll leave you here for now..."
    new "我想我暂时就先留你在这里吧……"

translate chinese chinese_6283468_285:
    old "I'm so sorry, about this Linnet."
    new "真的很抱歉，林内特。"

translate chinese chinese_9687068_286:
    old "I promise that I will help you to get free from this."
    new "我承诺会帮你从这困境中解脱出来。"

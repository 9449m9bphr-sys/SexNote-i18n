# auto-tl Qwen Colab

translate chinese chinese_1063390_0:
    old "Hmph, I see you're late again [pla], you never learn, do you?"
    new "哼，我又看到你迟到了，[pla]，你永远学不乖吗？"

translate chinese chinese_3560404_1:
    old "Although that's not really a surprise, you're always doing this kinda stuff."
    new "虽然这也没什么好惊讶的，你总是干这种事。"

translate chinese chinese_0356918_2:
    old "Uhh... Good morning, Miss Mia."
    new "呃……早上好，米娅小姐。"

translate chinese chinese_3210667_3:
    old "I'm sorry? Don't think that you can be a wise ass with me young man, and get in the classroom already! We're about to start."
    new "抱歉？别以为你可以这么油腔滑调地跟我说话，小子，赶紧进教室！我们要开始上课了。"

translate chinese chinese_0482025_4:
    old "Don't you see there are some students that DO care about studying?"
    new "你没看到有些学生是真的在乎学习的吗？"

translate chinese chinese_8299950_5:
    old "(What the hell got into her?)"
    new "（她这是怎么了？）"

translate chinese chinese_6090230_6:
    old "(Gosh, this is gonna be a looong day)"
    new "（天啊，今天要熬很久啊）"

translate chinese chinese_2654550_7:
    old "As you can see, establishing a single reason for the start of world war I is nearly impossible."
    new "正如你可以看到的，为第一次世界大战的爆发确立一个单一的原因几乎是不可能的。"

translate chinese chinese_3967714_8:
    old "Certainly the detonating event was the killing of Archduke Franz Ferdinand."
    new "当然，引爆事件是斐迪南大公被刺杀。"

translate chinese chinese_8791886_9:
    old "But as I explained already, this was merely a consequence of the authoritarian rule..."
    new "但是如我之前解释的，这只不过是专制统治的结果而已……"

translate chinese chinese_6787632_10:
    old "(Geez this is boring... What do I need to know any of this stuff for?)"
    new "（天啊这真无聊……我为什么要了解这些？）"

translate chinese chinese_6981730_11:
    old "(Isn't she wearing underwear?)"
    new "（她不是穿了内裤吗？）"

translate chinese chinese_2627447_12:
    old "As I was saying, what's most important to remember when examining the causes of the war..."
    new "正如我刚才所说，在分析战争起因时最重要的是记住……"

translate chinese chinese_8677667_13:
    old "It's that the political climate of Europe was tremendously charged..."
    new "这是因为欧洲的政治气氛非常紧张..."

translate chinese chinese_0647248_14:
    old "{i}Hey Mike, dude! Did you see that?! {/i}"
    new "{i}嘿迈克，老兄！你看到那件事了吗？{/i}"

translate chinese chinese_7133246_15:
    old "{i}U-uh? Are you talking to me? Did Ms. Mia ask a question?{/i}"
    new "{i}嗯？你在跟我说话吗？米娅小姐问问题了吗？{/i}"

translate chinese chinese_9034185_16:
    old "{i}What? No dude! You didn't see that?{/i}"
    new "({i}什么？喂，你没看到那件事吗？{/i})"

translate chinese chinese_0062135_17:
    old "{i}See what?{/i}"
    new "{i}看到什么了？{/i}"

translate chinese chinese_8380732_18:
    old "{i}Nevermind...{/i}"
    new "{i}算了...{/i}"

translate chinese chinese_2456755_19:
    old "(Was I the only one that saw that?)"
    new "（就我一个人看到那幕了吗？）"

translate chinese chinese_6103194_20:
    old "(I'm sure I saw she wasn't wearing any panties.)"
    new "（我肯定看到她没穿内裤。）"

translate chinese chinese_7290658_21:
    old "Ok guys, that's today's class, remember I'm going to need you to write a three-page report on the causes of world war I for the next class."
    new "好的，今天的课就到这里，记得下次课我要你们写一份三页纸关于第一次世界大战起因的报告。"

translate chinese chinese_8704033_22:
    old "And [pla], remember to be on time for next time!"
    new "还有[pla]，记得下次准时到场！"

translate chinese chinese_9939438_23:
    old "Hmm, late again! You just never learn, do you [pla]?"
    new "哼，又迟到了！你真是永远学不乖啊，[pla]？"

translate chinese chinese_5127451_24:
    old "Hi Miss Mia, were you waiting for me? I mean, I'm just on time."
    new "嗨，米娅小姐，你在等我吗？我的意思是，我只是刚好赶到。"

translate chinese chinese_7669117_25:
    old "Just on time to interrupt the class by entering late!"
    new "正好迟到进教室打断上课！"

translate chinese chinese_2126298_26:
    old "I'm telling you, you better straighten up!"
    new "我告诉你，你最好收敛点！"

translate chinese chinese_3147108_27:
    old "Oh! Mia, good morning."
    new "哦！米娅，早上好。"

translate chinese chinese_4083694_28:
    old "Good Morning ma'am, how are you today?"
    new "早上好，女士，您今天怎么样？"

translate chinese chinese_9303015_29:
    old "I'm pretty good, thank you, just checking up on things before I go to my office to start the day."
    new "我挺好的，谢谢。就是去办公室开始工作前检查一下事情。"

translate chinese chinese_0611887_30:
    old "By the way, don't you think it's about time for you to start with your class?"
    new "对了，你不觉得该开始上课了吗？"

translate chinese chinese_2725461_31:
    old "You're right, sorry ma'am, I was just waiting for this student, he needs a little extra attention."
    new "你说得对，抱歉女士，我刚才只是在等这个学生，他需要多一点关注。"

translate chinese chinese_4739641_32:
    old "This is [pla]."
    new "这是[pla]。"

translate chinese chinese_2820896_33:
    old "Good morning ma'am.."
    new "早上好，女士.."

translate chinese chinese_4370548_34:
    old "Ah, this is the student you told me about."
    new "啊，这就是你跟我说过的那个学生。"

translate chinese chinese_3878983_35:
    old "Well [pla], given what Mia has told me about you, I don't think it's very good that you're arriving this late to class."
    new "好吧 [pla]，考虑到米娅告诉我的关于你的事情，你上课迟到可不是什么好现象。"

translate chinese chinese_5775140_36:
    old "You're right ma'am, I'm sorry."
    new "您说得对，我很抱歉。"

translate chinese chinese_6268936_37:
    old "Trust me, you don't want to see your classmates move on and you being stuck here."
    new "相信我，你不想看到同学们都走了，而你却留在这里。"

translate chinese chinese_1890604_38:
    old "So, make sure you buckle down and start studying seriously."
    new "所以，确保你认真开始学习。"

translate chinese chinese_4893442_39:
    old "Otherwise you'll have to come here and take extra classes during your Holidays."
    new "否则你假期得过来补课。"

translate chinese chinese_0131306_40:
    old "You're right, ma'am."
    new "您说得对。"

translate chinese chinese_1688172_41:
    old "Just keep it in mind. Mia already has an eye on you, be thankful that your teacher cares so much."
    new "记住了。Mia已经注意到你了，感谢你的老师这么关心你。"

translate chinese chinese_1523712_42:
    old "Hmm... Yes ma'am."
    new "嗯……是的，女士。"

translate chinese chinese_2927888_43:
    old "Good boy."
    new "好孩子。"

translate chinese chinese_2496086_44:
    old "Now Mia, I think it's time for you to start your class."
    new "现在米娅，我觉得你应该开始上课了。"

translate chinese chinese_6798803_45:
    old "Yes ma'am, I'm about to."
    new "好的，我这就来。"

translate chinese chinese_5529509_46:
    old "Have a very good day ma'am."
    new "女士，祝您有美好的一天。"

translate chinese chinese_3411963_47:
    old "You too dear."
    new "你也保重哦。"

translate chinese chinese_9004346_48:
    old "You see? That's your second warning about your studies. You better listen!"
    new "你看？这是关于你学习的第二次警告了。你最好听好了！"

translate chinese chinese_5093904_49:
    old "And come in!"
    new "快进来！"

translate chinese chinese_2073985_50:
    old "Ok guys, we'll continue with the world war one chapter."
    new "好的，大家，我们继续一战这部分。"

translate chinese chinese_6610351_51:
    old "This time we'll talk about Africa and the Ottoman Empire during this period of time."
    new "这次我们来谈谈这段时期的非洲和奥斯曼帝国。"

translate chinese chinese_3351615_52:
    old "Is it me or is it really hot today? I think I need to get a bit more comfortable."
    new "是我感觉错了吗，今天真的很热吗？我觉得我需要放松一点。"

translate chinese chinese_9953402_53:
    old "(What the fuck?! She's not wearing a bra!)"
    new "（什么情况?! 她竟然没穿胸罩!）"

translate chinese chinese_9571194_54:
    old "(What's happening with her?)"
    new "（她怎么了？）"

translate chinese chinese_9986358_55:
    old "Phew, too much better, ok, let's continue with the subject..."
    new "呼，好多了，好吧，我们继续说正题吧……"

translate chinese chinese_3593533_56:
    old "{i}Dude! Are you seeing what I'm seeing?{/i}"
    new "{i}伙计！你看到我看到的了吗？{/i}"

translate chinese chinese_4317790_57:
    old "{i}(So this time I'm not the only one who notices.)"
    new "{i}(这次不止我一个人注意到了。)"

translate chinese chinese_7444812_58:
    old "{i}Yeah, what's up with that?{/i}"
    new "{i}是啊，那是什么情况？{/i}"

translate chinese chinese_8304807_59:
    old "{i}I don't know, but this is totally rad!{/i}"
    new "我不知道，但这简直太酷了！"

translate chinese chinese_0698899_60:
    old "Is there something you want to share with the class? Or can I continue with the class."
    new "有什么想跟大家说的话吗？还是我可以继续上课了？"

translate chinese chinese_0482377_61:
    old "U- uh, sorry Miss Mia."
    new "呃，对不起，米娅小姐。"

translate chinese chinese_3426523_62:
    old "Yeah, sorry."
    new "嗯，对不起。"

translate chinese chinese_4270905_63:
    old "Honestly, I would hope that you of all people should be the one paying the most attention [pla]."
    new "说实话，我本以为你最应该关注[pla]。"

translate chinese chinese_2131034_64:
    old "Let me remind you that your grades have been terrible."
    new "我要提醒你，你的成绩一直很糟糕。"

translate chinese chinese_2205039_65:
    old "I imagine that paper you had to write must be excellent, right?"
    new "我猜你写的那篇论文肯定很出色吧？"

translate chinese chinese_6193154_66:
    old "I said I was sorry..."
    new "我说过对不起..."

translate chinese chinese_7451260_67:
    old "Hmph, you better be."
    new "哼，最好如此。"

translate chinese chinese_7637638_68:
    old "I'm sorry class, let's just continue, I know some of you actually want to learn."
    new "对不起大家，我们继续吧，我知道有些同学是真的想学习的。"

translate chinese chinese_1333840_69:
    old "Dude! [pla], did you notice?!"
    new "喂！[pla]，你没发现吗？！"

translate chinese chinese_8093799_70:
    old "You could see her nipples! It was the best class ever!"
    new "你看到她的乳头了！那是最好的一节课！"

translate chinese chinese_7317130_71:
    old "Yeah, that was weird."
    new "是啊，那挺奇怪的。"

translate chinese chinese_6380010_72:
    old "Hey Belle, did you see that?"
    new "嘿，贝尔，你看到那件事了吗？"

translate chinese chinese_0895687_73:
    old "Now we have a new motivation to come to class!"
    new "现在我们有了来上课的新动力！"

translate chinese chinese_8806171_74:
    old "Yes, I noticed that Miss Mia wasn't wearing a bra... I assume that's what you mean?"
    new "是的，我注意到米娅小姐没穿胸罩……你的意思是这个吗？"

translate chinese chinese_5739453_75:
    old "That was weird, and it's not the first time, last class I also noticed something."
    new "那真奇怪，而且这也不是第一次了，上节课我也注意到了一些东西。"

translate chinese chinese_5649827_76:
    old "Yeah, I also saw that."
    new "是啊，我也看到了那件事。"

translate chinese chinese_3137940_77:
    old "What? Last class?"
    new "什么？最后一节课？"

translate chinese chinese_8003099_78:
    old "I didn't see anything."
    new "我没看到任何东西。"

translate chinese chinese_7442066_79:
    old "What was it? What was it?"
    new "是什么？是什么？"

translate chinese chinese_5783448_80:
    old "There's something odd about Ms. Mia's behavior lately."
    new "米娅小姐最近的行为有些奇怪。"

translate chinese chinese_6123099_81:
    old "I know what you mean."
    new "我明白你的意思。"

translate chinese chinese_9030091_82:
    old "But I guess that's none of our concern."
    new "但我想这不关我们的事。"

translate chinese chinese_6048697_83:
    old "By the way, I'm going over to Billie's to hang out."
    new "对了，我打算去比莉那里玩玩。"

translate chinese chinese_9850654_84:
    old "You guys wanna come?"
    new "你们想来吗？"

translate chinese chinese_2949045_85:
    old "I would love to."
    new "我愿意。"

translate chinese chinese_8345072_86:
    old "But I have to get working on the next project, otherwise Ms. Mia will never get off my back."
    new "但我得开始下一个项目了，不然米娅小姐会一直催我的。"

translate chinese chinese_9749800_87:
    old "She really doesn't like you, does she?"
    new "她真的不太喜欢你，是吧？"

translate chinese chinese_9640020_88:
    old "Ha, that's saying little."
    new "哈，这还算是轻的。"

translate chinese chinese_6418115_89:
    old "Oh, damn, I just realized, I forgot my notes in the classroom."
    new "哦，糟了，刚想起来，我把笔记忘教室里了。"

translate chinese chinese_8614600_90:
    old "I have to go back and grab them. See you later guys!"
    new "我得回去拿那些东西。一会儿见！"

translate chinese chinese_7067270_91:
    old "So, where are we going Belle?"
    new "那么，我们要去哪，贝尔？"

translate chinese chinese_1826193_92:
    old "Yeah, yeah, I did what you asked!! Okay?!"
    new "好吧好吧，我按你说的做了！！行了吧？！"

translate chinese chinese_8279289_93:
    old "Yeah, but I won't be doing that shit again!"
    new "是的，但这种事情我不会再做了！"

translate chinese chinese_4372335_94:
    old "This was so embarrassing. You went way overboard with this!"
    new "这真是太尴尬了。你这也太过分了！"

translate chinese chinese_1070677_95:
    old "And I'm telling you now, I'm not doing anything more in public!"
    new "我现在告诉你，我不会再在公共场合做任何事了！"

translate chinese chinese_3311217_96:
    old "What...?!"
    new "什么...?!"

translate chinese chinese_9375926_97:
    old "Ugh, great, just what I needed!"
    new "哎，真好，正是我需要的！"

translate chinese chinese_2478626_98:
    old "Um, sorry, I just came back to pick up my notes, I'm leaving now."
    new "嗯，对不起，我刚回来拿我的笔记，我现在就走。"

translate chinese chinese_1319635_99:
    old "Uh? What? Him?"
    new "呃？什么？他？"

translate chinese chinese_2077259_100:
    old "He's nobody, just another one of my stupid students."
    new "他不过是个没人，我那些愚蠢的学生之一。"

translate chinese chinese_4612569_101:
    old "Nah, he just came in, he heard nothing."
    new "没，他刚进来，什么都没听到。"

translate chinese chinese_1413682_102:
    old "What does his name have to do with anything?"
    new "他的名字和这件事有什么关系？"

translate chinese chinese_7245360_103:
    old "Yeah, I don't like him, so what?"
    new "是啊，我不喜欢他，那又怎样？"

translate chinese chinese_1271874_104:
    old "What? Listen, that doesn't have anything to do with our conversation."
    new "什么？听我说，这和我们的谈话无关。"

translate chinese chinese_0460953_105:
    old "The point is that I'm not doing anything else, so you better stop harassing me, you got that?!"
    new "重点是我没在做别的，所以你最好别再骚扰我，懂了吗？！"

translate chinese chinese_2822122_106:
    old "Ughh..."
    new "呃……"

translate chinese chinese_4709045_107:
    old "Hmm, I guess Mike and Belle already left."
    new "嗯，看来迈克和贝勒已经走了。"

translate chinese chinese_2672477_108:
    old "(But what the hell was that phone call about? That was so weird.)"
    new "（但那通电话到底是怎么回事？太奇怪了。）"

translate chinese chinese_6119779_109:
    old "(Although I guess it's not my business.)"
    new "（虽然这可能不关我的事。）"

translate chinese chinese_3818812_110:
    old "All right guys, today we'll talk about American development during the period from 1925 to 1938, the period between the two world wars..."
    new "好的大家，今天我们来谈谈1925年到1938年，两次世界大战之间的美国发展情况……"

translate chinese chinese_0718048_111:
    old "(God this is so fucking boring.)"
    new "（天啊，这真是他妈的无聊透了。）"

translate chinese chinese_6770116_112:
    old "(What?)"
    new "（什么？）"

translate chinese chinese_6232768_113:
    old "(Is she looking at me?)"
    new "（她在看我吗？）"

translate chinese chinese_0673443_114:
    old "The European crisis allowed the emergence of powerful industrialists, like Rockefeller and Ford."
    new "欧洲危机使得像洛克菲勒和福特这样的强大实业家得以崛起。"

translate chinese chinese_5833637_115:
    old "(Why does she look so angry?)"
    new "（她为什么看起来这么生气？）"

translate chinese chinese_1997538_116:
    old "Ok, guys, that's it for today, for the next class I'll need you to read about the treaty of Versailles."
    new "好了，大家，今天就到这里，下次课我要你们读关于凡尔赛条约的内容。"

translate chinese chinese_0673098_117:
    old "Aw, dude, that was so dull!"
    new "哎，真没劲！"

translate chinese chinese_3106783_118:
    old "I'm exhausted, can't wait for lunch."
    new "我累死了，真盼着吃午饭。"

translate chinese chinese_2864175_119:
    old "Hey [pla], I'm going to need you to stay."
    new "嘿[pla]，你需要留下来。"

translate chinese chinese_0183405_120:
    old "Uh-oh, you're in trouble dude. I think I better get going home."
    new "哎呀，你这次麻烦大了。我觉得我还是回家吧。"

translate chinese chinese_9955947_121:
    old "Good luck dude."
    new "祝你好运。"

translate chinese chinese_4891648_122:
    old "See you dude."
    new "拜了，兄弟。"

translate chinese chinese_2543368_123:
    old "If this is about the project I-"
    new "如果这是关于我那个项目的事——"

translate chinese chinese_3504508_124:
    old "Oh shut up! Just shut up! Who cares about that stupid project?!"
    new "哦闭嘴！给我闭嘴！谁在乎那个愚蠢的项目！"

translate chinese chinese_2130308_125:
    old "Uh w-what? But you said..."
    new "呃，什么？但是你说过..."

translate chinese chinese_8206848_126:
    old "So, it was you, wasn't it?!"
    new "所以，就是你干的，对吧！？"

translate chinese chinese_6060236_127:
    old "I see, of course, he had someone on the inside."
    new "我明白了，当然，他肯定有人里应外合。"

translate chinese chinese_0946443_128:
    old "You're the bastard that's been verifying that I do his stupid challenges. I should've known."
    new "你这个混蛋一直在确认我做他的愚蠢挑战。我早该知道的。"

translate chinese chinese_7846957_129:
    old "Uhmm, what? What are you talking about?"
    new "嗯，什么？你在说什么？"

translate chinese chinese_9476372_130:
    old "Well, I'll let you know I'm tired of this bullshit! You better not think you'll keep getting away with this disgusting behavior."
    new "好吧，我告诉你，我受够这 bullshit 了！你最好别以为这种恶心的行为还能继续下去。"

translate chinese chinese_6155683_131:
    old "I was so stupid not to realize it was you, of course, you were the clear option."
    new "我真是傻了，没意识到当然是你，你本来就是最明显的选择。"

translate chinese chinese_0174383_132:
    old "I should've known from the beginning. It was obvious."
    new "我从一开始就应该知道的。这很明显。"

translate chinese chinese_3232416_133:
    old "Excuse me, I don't know what you're accusing me of, but I haven't done anything."
    new "对不起，我不知道你在指控我什么，但我什么都没做。"

translate chinese chinese_9233419_134:
    old "Will you stop playing dumb already?!!! You know very well what I'm talking about!"
    new "你能不能别再装傻了！！！你心里清楚我在说什么！"

translate chinese chinese_1142730_135:
    old "Or are you telling me you haven't been following that bastard Denzel's orders to spy on me?"
    new "还是说你在告诉我，你没有按照那个混账丹泽尔的命令来监视我？"

translate chinese chinese_1710302_136:
    old "Denzel? What the-"
    new "丹泽尔？什么回事-"

translate chinese chinese_3407713_137:
    old "Or that you just happened to come into the classroom just as I was reporting to him?!"
    new "或者你刚好在我向他汇报的时候走进教室？！"

translate chinese chinese_0135965_138:
    old "I know you're a bastard, but spare me your stupid lies!"
    new "我知道你不是好人，但别拿你的愚蠢谎言来骗我！"

translate chinese chinese_2577392_139:
    old "I already told you I don't know what you're talking about!"
    new "我早就说了，我不知道你在说什么！"

translate chinese chinese_8971721_140:
    old "Ugh, whatever, let's just get this over with."
    new "唉，随便吧，赶紧搞定算了。"

translate chinese chinese_9136614_141:
    old "Woah! Woah! What do you think you're doing?"
    new "喂！喂！你搞什么？"

translate chinese chinese_1705888_142:
    old "Will you stop pretending you don't know what's going on?!!"
    new "你别装作不知道发生了什么好不好!!"

translate chinese chinese_6172819_143:
    old "How can you keep acting like this after all that you've made me do?!"
    new "你让我做了那么多事后，怎么还能这样装作没事人一样！"

translate chinese chinese_0019138_144:
    old "At least pretend you have some decency, will you?!"
    new "至少装装有廉耻的样子，行不行？！"

translate chinese chinese_3800896_145:
    old "I-I don't... W- what do you mean?"
    new "我……不……你什么意思？"

translate chinese chinese_2528589_146:
    old "I already told you, I have no idea what you're talking about."
    new "我already告诉过你了，我真的不知道你在说什么。"

translate chinese chinese_3437487_147:
    old "Yeah right... As if I'll believe anything you say."
    new "是吗……我才不信你呢。"

translate chinese chinese_9397000_148:
    old "But I'll give you what you want, you sick freak."
    new "但我会给你你想要的，你这个变态。"

translate chinese chinese_8378992_149:
    old "Listen, I've had enough of your bullshit for one day."
    new "听着，我今天受够你的 bullshit 了。"

translate chinese chinese_6516938_150:
    old "I already sent that asshole the picture. Just leave me alone."
    new "我早就把照片发给那个混蛋了。你就别烦我了。"

translate chinese chinese_5432620_151:
    old "What the fuck?!"
    new "卧槽?!"

translate chinese chinese_9082119_152:
    old "Of course, your little accomplice would come!"
    new "当然，你的小帮凶肯定会来！"

translate chinese chinese_4589460_153:
    old "What are you two, sick freaks, planning now?"
    new "你们这两个变态现在又在打什么主意？"

translate chinese chinese_1292964_154:
    old "W- what? I... What are you talking about?"
    new "什、什么？我...你在说什么？"

translate chinese chinese_9853266_155:
    old "I just came early for class!"
    new "我就是早来上课的！"

translate chinese chinese_4368321_156:
    old "Ugh! Denzel, could you tell your little minion to stop acting?"
    new "哎呀！丹泽尔，你能让你的小跟班停止演戏吗？"

translate chinese chinese_8212058_157:
    old "Well, Miss Mia, I must say this is the first time I've seen your student."
    new "好吧，米娅小姐，我必须说，这是我第一次见到你的学生。"

translate chinese chinese_8108096_158:
    old "I don't even know his name."
    new "我甚至不知道他的名字。"

translate chinese chinese_9143767_159:
    old "What?! What do you mean?"
    new "什么?! 你什么意思?"

translate chinese chinese_0401263_160:
    old "Well, I don't think you even have enough in that empty head of yours to remember."
    new "好吧，我觉得你那空荡荡的脑子里根本记不住这些东西。"

translate chinese chinese_1448335_161:
    old "But while you were my teacher, you made my life miserable, absolutely horrible."
    new "但当你是我老师的时候，你让我的生活苦不堪言，糟糕透了。"

translate chinese chinese_8398508_162:
    old "And from what I can see, that's something you're still doing..."
    new "而从我看来，这还是你在做的事情……"

translate chinese chinese_9441733_163:
    old "Well, I've noticed you always pick on a poor and innocent guy from your classes to torment."
    new "好吧，我注意到了你总是欺负班上某个可怜又无辜的家伙。"

translate chinese chinese_9086088_164:
    old "Tremendously immature of you, I must say, someone would think a teacher would be a little bit more... nuanced."
    new "不得不说我真是觉得你非常不成熟，有人可能会认为一个老师会更……细腻一些。"

translate chinese chinese_6485098_165:
    old "So, the other day, after listening to your answer when we were talking and you got interrupted by him."
    new "所以那天，当我们聊天被他打断时，我听了你的回答之后。"

translate chinese chinese_8712653_166:
    old "It came to my mind, why not give the young guy a chance to take some revenge on his horrible teacher?"
    new "我突然想到，为什么不给这小子一个机会，让他报复那个可怕的老师呢？"

translate chinese chinese_6396968_167:
    old "... The fuck?"
    new "… 哪里来的？"

translate chinese chinese_5994345_168:
    old "W-w-what the hell is happening? What are you guys talking about?"
    new "喂喂喂，怎么回事？你们在说什么？"

translate chinese chinese_7482929_169:
    old "Oh, how rude of me, I went into a monologue without even introducing myself. Apologies buddy."
    new "哦，真不好意思，我还没自我介绍就自说自话了。抱歉啊朋友。"

translate chinese chinese_7374192_170:
    old "My name is Denzel, and just like you, I was once a victim of this so-called teacher's horrible personality."
    new "我叫丹泽尔，和你一样，我曾经也是这个所谓老师可怕性格的受害者。"

translate chinese chinese_1193149_171:
    old "She used to be my teacher, and she made my life miserable too."
    new "她以前是我的老师，也让我日子很不好过。"

translate chinese chinese_7780206_172:
    old "I never forgave her, but I didn't actually have any way to get back at her for anything."
    new "我从没原谅她，但其实我也找不到任何报复她的方法。"

translate chinese chinese_4215684_173:
    old "That is, until recently, when I learned a couple of things from her past that she would prefer to have hidden."
    new "直到最近，我从她的过去得知了一些她宁愿隐藏的事情。"

translate chinese chinese_1761392_174:
    old "No! Don't say anything about that! Please, I'm already doing whatever you ask me."
    new "不要！别提那个！拜托，我已经按你的要求做了。"

translate chinese chinese_4431926_175:
    old "W-what are you talking about?"
    new "你、你在说什么？"

translate chinese chinese_3424798_176:
    old "Go ahead Mia, tell your favorite student all about your past..."
    new "好吧，米娅，把你过去的事情都告诉你最喜欢的学生吧……"

translate chinese chinese_7967948_177:
    old "Please... No..."
    new "求你了……不要……"

translate chinese chinese_2291252_178:
    old "I mean, there's nothing to feel ashamed about, is there?"
    new "我的意思是，没什么好感到羞耻的，是吧？"

translate chinese chinese_8776402_179:
    old "That's right! Can you believe it? She's always so self-righteous, always taking her anger out on other people."
    new "没错！你能相信吗？她总是自以为是，总是把怒气发泄到别人身上。"

translate chinese chinese_9880039_180:
    old "She's offensive, arrogant, and demanding, when she used to be just a whore!"
    new "她以前不过是个妓女，现在却变得咄咄逼人、自大还爱摆谱！"

translate chinese chinese_7436174_181:
    old "Anyway, she got out of that, but I found out and got proof that she used to be a pornstar."
    new "不管怎样，她躲过去了，但我发现了她以前是 pornstar 的证据。"

translate chinese chinese_9650091_182:
    old "And if she doesn't want to be fired, and get her life ruined,  she'll have to do as I say."
    new "而且如果她不想被解雇，生活被毁掉，就只好按我说的做了。"

translate chinese chinese_2443570_183:
    old "Or I'll out her as the whore she is, and her life here will be over."
    new "否则我就揭露她的真面目，让她在这里的生活完蛋。"

translate chinese chinese_3932211_184:
    old "You fucking bastard!"
    new "你这个混蛋！"

translate chinese chinese_7608557_185:
    old "Oh, call me what you want, that only makes it better when I punish you."
    new "哦，叫我什么都可以，等我惩罚你的时候只会更带劲。"

translate chinese chinese_0398577_186:
    old "By the way... I think it's about time for your next punishment."
    new "对了……我觉得该到你下次受罚的时候了。"

translate chinese chinese_7794415_187:
    old "Oh, sorry, we're calling them challenges. Right?"
    new "哦，对不起，我们在叫它们挑战。对吧？"

translate chinese chinese_5248756_188:
    old "Challenge? Punishment?!"
    new "挑战？惩罚？！"

translate chinese chinese_8373872_189:
    old "This is blackmail! And abuse!"
    new "这是敲诈！还有虐待！"

translate chinese chinese_1382906_190:
    old "Call it whatever you want, but you have to do it."
    new "管它叫什么，反正你得做。"

translate chinese chinese_9738711_191:
    old "And seeing as your favorite student's here, why don't we have you give him a little bit of attention?"
    new "既然你最喜欢的学生在这里，为什么不给他一点关注呢？"

translate chinese chinese_8412652_192:
    old "Give him a blowjob."
    new "给他口交。"

translate chinese chinese_9168098_193:
    old "What?! You must be kidding me! A blowjob?!"
    new "什么?! 你在开玩笑吧! 吹箫?!"

translate chinese chinese_6663015_194:
    old "This is going way too far!"
    new "这太过分了！"

translate chinese chinese_3503711_195:
    old "Didn't you have enough with your pictures and stuff?"
    new "照片那些东西还不够吗？"

translate chinese chinese_2531908_196:
    old "Oh, I really enjoyed those, but that's not what I want right now."
    new "哦，那些真的很享受，但这不是我现在想要的。"

translate chinese chinese_8688644_197:
    old "I already told you what to do, take out his dick and suck it!"
    new "我already告诉你该怎么做，把他那东西拿出来吸！"

translate chinese chinese_2103506_198:
    old "Otherwise I suppose tomorrow the school principal will receive a mail with an interesting video."
    new "不然我想明天校长就会收到一封带有有趣视频的邮件了。"

translate chinese chinese_5164955_199:
    old "You sick freak..."
    new "你这个变态..."

translate chinese chinese_8817682_200:
    old "I'll do it, ok? Just don't spread anything, ok?"
    new "我来做，好吧？ just不要乱传哦，好吗？"

translate chinese chinese_7372567_201:
    old "Ugh, come here [pla]... I'll do this quickly."
    new "唉，过来吧[pla]……我快点搞定。"

translate chinese chinese_3763086_202:
    old "Y- you can't be serious."
    new "你不会是认真的吧。"

translate chinese chinese_4794570_203:
    old "Well, what do you think stupid?!"
    new "那你觉得呢蠢货?!"

translate chinese chinese_2137206_204:
    old "I wouldn't joke about this shit."
    new "这种事情我不开玩笑。"

translate chinese chinese_8265351_205:
    old "I- I'm sorry Miss Mia, but I don't have anything to do with this. I should just leave."
    new "我……对不起米娅小姐，但我跟这件事没关系。我还是走吧。"

translate chinese chinese_3301123_206:
    old "Well, I guess you could just leave. But if you do, I'll just leak the information I have about her."
    new "好吧，我想你可以直接离开。但如果你真走了，我就把我知道的关于她的信息公之于众。"

translate chinese chinese_9803237_207:
    old "That's also an option by the way."
    new "话说这也是一种选择。"

translate chinese chinese_7529387_208:
    old "After all, she's also been cruel to you all this time, you may as well just let her suffer with this."
    new "毕竟，她也一直对你很残忍，你干脆就让她这么痛苦吧。"

translate chinese chinese_5641596_209:
    old "Tell you what, maybe you'll change your mind if you see her beg for it. How about it?"
    new "这样吧，如果你看到她苦苦哀求，说不定你会改变主意。怎么样？"

translate chinese chinese_7923456_210:
    old "Go ahead Mia, beg him to let you suck his dick, remember what's at stake here for you."
    new "来吧米娅，求他让你吸他的鸡，记住这里对你来说有什么风险。"

translate chinese chinese_0822670_211:
    old "Listen, [pla] I don't want this to happen any more than you do."
    new "听着，[pla]，我也不想让这件事发生。"

translate chinese chinese_5699741_212:
    old "Ha! What a weird way to beg! heh."
    new "哈！真是个奇怪的求饶方式！嘿嘿。"

translate chinese chinese_3100208_213:
    old "But if we don't do this, he'll just release his disgusting pictures and videos of me."
    new "但如果我们不做这件事，他就會把那些恶心的照片和视频公开了。"

translate chinese chinese_4290456_214:
    old "Please, please, please help me out."
    new "求你了，帮帮我。"

translate chinese chinese_2138878_215:
    old "After my life went to shit because of what happened before, it's taken me so much work to create something here."
    new "自从之前的事情让我的生活变得一团糟之后，我花了很大的努力才在这里建立起一些东西。"

translate chinese chinese_2512736_216:
    old "Aww, you're breaking my heart."
    new "哎，你都快把我心碎了。"

translate chinese chinese_1222711_217:
    old "Fuck you."
    new "去你的。"

translate chinese chinese_9483372_218:
    old "Hmm, ok, I'll do it."
    new "嗯，好吧，我做。"

translate chinese chinese_9633254_219:
    old "You will, Ha! I knew it, you also want to get revenge on her, right?"
    new "你会的，哈！我就知道，你也想报复她，对吧？"

translate chinese chinese_8818056_220:
    old "No!"
    new "不！"

translate chinese chinese_5372405_221:
    old "I'll do it just to help her, I don't want revenge on anyone."
    new "我这么做只是为了帮她，不想对任何人报仇。"

translate chinese chinese_5741487_222:
    old "Heh, whatever you say, kid."
    new "嘿嘿，随便你了，小子。"

translate chinese chinese_7429274_223:
    old "All right Mia, it's time to do what you do best!"
    new "好吧，米娅，是时候展现你的绝技了！"

translate chinese chinese_9345402_224:
    old "(I can't believe I'm actually doing this, and to [pla] of all people!)"
    new "(真不敢相信我真的会这么做，而且对象还是[pla]！)"

translate chinese chinese_4132839_225:
    old "I bet you actually wanted this, even if you left the porn business."
    new "我敢打赌，即使你离开了色情行业，其实你还是想要这样的。"

translate chinese chinese_1265691_226:
    old "After all you're just a whore."
    new "毕竟你不过是个妓女。"

translate chinese chinese_8934231_227:
    old "Whatever you say, but remember, you won't get away with this for long."
    new "随便你，但记住，你不会长久逍遥法外的。"

translate chinese chinese_0351237_228:
    old "Heh, we'll see."
    new "嘿嘿，走着瞧。"

translate chinese chinese_0222999_229:
    old "Woah, what the fuck?!"
    new "卧槽，什么情况?!"

translate chinese chinese_2168237_230:
    old "What are you doing? What did you take that picture for?"
    new "你在干什么？你为什么要拍那张照片？"

translate chinese chinese_0781056_231:
    old "Don't worry about it, that's just to..."
    new "别担心，那只是用来..."

translate chinese chinese_3166583_232:
    old "Let's say, commemorate the occasion."
    new "这么说吧，纪念一下这个场合。"

translate chinese chinese_9751949_233:
    old "Anyway, I think I should just leave."
    new "不管怎样，我想我还是走吧。"

translate chinese chinese_1791370_234:
    old "Well done [pla], I bet you liked that."
    new "干得好[pla]，我敢打赌你肯定喜欢那样。"

translate chinese chinese_4440065_235:
    old "Until we see each other again, bye."
    new "下次见，拜拜。"

translate chinese chinese_2753541_236:
    old "U-uh, Miss Mia, I- I think..."
    new "uh，米娅小姐，我觉..."

translate chinese chinese_5002494_237:
    old "I don't want to talk, or anything. Bye."
    new "我不想说话，拜拜。"

translate chinese chinese_7313040_238:
    old "Damn."
    new "真糟糕。"

translate chinese chinese_6034271_239:
    old "(What did I get myself into now?)"
    new "（这次我又闯进什么麻烦里了？）"

translate chinese chinese_9314713_240:
    old "Eh, ehem."
    new "嗯，咳。"

translate chinese chinese_2006959_241:
    old "Hi Miss Mia, good morning."
    new "早上好，米娅小姐。"

translate chinese chinese_0363724_242:
    old "G-good morning."
    new "早、早上好。"

translate chinese chinese_0719966_243:
    old "I see you're early today, congratulations."
    new "看你今天来得挺早的，恭喜你。"

translate chinese chinese_6014030_244:
    old "The class doesn't start yet, so take a seat and wait for your classmates."
    new "课还没开始，先坐下来等同学吧。"

translate chinese chinese_0807695_245:
    old "Hmm, actually, I was kinda hoping we could talk."
    new "嗯，其实，我本来有点希望我们可以谈谈。"

translate chinese chinese_0081860_246:
    old "You know, about what happened last time..."
    new "说起来，上次发生的事……"

translate chinese chinese_8568331_247:
    old "Listen, we don't have anything to talk about."
    new "听着，我们没什么好谈的。"

translate chinese chinese_4954109_248:
    old "I'm really sorry that you saw yourself being dragged into it, and I thank you for helping me."
    new "真的很抱歉你被卷进来了，感谢你的帮助。"

translate chinese chinese_7316404_249:
    old "But that's all I will say about that issue."
    new "但关于这个问题我就说到这。"

translate chinese chinese_4862286_250:
    old "Which, by the way, it's my own business, so I would appreciate it if you didn't interfere."
    new "话说回来，这是我的私事，希望你不要干涉。"

translate chinese chinese_7879567_251:
    old "What? You can't be talking seriously."
    new "什么？你不会是认真的吧。"

translate chinese chinese_8837525_252:
    old "Listen, what happened yesterday wasn't ok, and you can't let him keep forcing you into that kind of stuff."
    new "听着，昨天发生的事不对劲，你不能让他继续强迫你做那种事。"

translate chinese chinese_2129224_253:
    old "It's just not right, you have to do something..."
    new "这太不对劲了，你得做点什么……"

translate chinese chinese_2353637_254:
    old "And you think I don't know that?!"
    new "你以为我不知道这个吗？！"

translate chinese chinese_6066580_255:
    old "Of course it's not right! But I can't do anything, I've racked my brain to come up with a satisfying solution. But nothing."
    new "当然不对了！但我什么也做不了，我绞尽脑汁想出一个满意的解决方案。但什么也没有。"

translate chinese chinese_6998132_256:
    old "Otherwise, I wouldn't be stuck following his orders! Don't treat me like an idiot!"
    new "要不是这样的话，我怎么会一直被他的命令牵着走！别把我当傻子！"

translate chinese chinese_2515335_257:
    old "I know you're not dumb, but that's why I wanted to talk to you because I think maybe I could help you."
    new "我知道你不是傻瓜，但正因为如此，我想和你谈谈，因为我觉得也许我能帮到你。"

translate chinese chinese_7413055_258:
    old "Listen, I just don't think it's right that he keeps pushing you around like that."
    new "听着，我真的觉得他那样欺负你不对。"

translate chinese chinese_4328740_259:
    old "I want to do something to help you."
    new "我想做点什么来帮你。"

translate chinese chinese_6310786_260:
    old "I think it's the best thing that I can do. If you'll let me."
    new "我觉得这是我能做的最好的事情。如果你允许的话。"

translate chinese chinese_2099707_261:
    old "Hmm... I guess you're right."
    new "嗯……我想你是对的。"

translate chinese chinese_9925299_262:
    old "Listen, Denzel, is a previous student of mine, that apparently recent me from when I was his teacher."
    new "听着，丹泽尔是我以前的学生，就是我当老师时教过的一个学生。"

translate chinese chinese_1947738_263:
    old "And he's decided to get back at me by threatening to release some footage that he found from when I was..."
    new "而且他决定通过威胁要发布一些他找到的我……时候的录像来报复我。"

translate chinese chinese_8451185_264:
    old "From when I was..."
    new "从我..."

translate chinese chinese_5793430_265:
    old "Ugh! It's even hard to talk about it!"
    new "哎！连说都说不了！"

translate chinese chinese_2311575_266:
    old "From when I was a pornstar, ok?"
    new "从我当色情演员的时候开始，好吧？"

translate chinese chinese_8642612_267:
    old "That was a long time ago, I was just fresh out of high school, and didn't have any money to pay for college."
    new "那已经是很久以前的事了，我刚高中毕业，也没钱上大学。"

translate chinese chinese_7598975_268:
    old "Somebody had talked to me about how much money you could make in little time working on porn."
    new "有人跟我说过，在色情行业赚大钱很快的。"

translate chinese chinese_9201124_269:
    old "I was young, so I didn't really think it through, and just decided to do it."
    new "我当时年轻，没多想就决定了。"

translate chinese chinese_0569113_270:
    old "But I regret it so much, it didn't bring anything good to my life. That period gave me very low self-esteem."
    new "但我真的很后悔，那件事没有给我带来任何好处。那段时期让我自尊心很低。"

translate chinese chinese_1556625_271:
    old "Besides, it caused me depression and anxiety that lasted for a very long time."
    new "而且，那让我抑郁和焦虑了很长一段时间。"

translate chinese chinese_4880275_272:
    old "At the end I decided I couldn't take it anymore, so I just got away from it, and did everything I could to conceal that part of my past."
    new "最后我决定再也受不了了，于是就摆脱了它，并且竭尽全力隐瞒那段过去的经历。"

translate chinese chinese_8991294_273:
    old "Finally things worked out, but I had to change my entire life, move city, change name, everything. Just to get away from it."
    new "终于一切尘埃落定，但我不得不改变我的整个生活，搬家，改名，所有的一切。只是为了远离那些。"

translate chinese chinese_8512435_274:
    old "You can imagine then how hard it is for me to see that material is still out there, and somebody could see it."
    new "你可以想象当我看到那些材料还在外面流通，而且有人可能会看到它们时，我是多么的难受。"

translate chinese chinese_9552911_275:
    old "I mean, I get that. But what do you mean 'Still out there'?"
    new "我的意思是，我明白这一点。但是你说的“还在外面”是什么意思？"

translate chinese chinese_4461280_276:
    old "I imagine that whatever you filmed before would just be on the internet, right?"
    new "我想你之前拍的那些东西应该都在网上了吧？"

translate chinese chinese_6499430_277:
    old "Why is it weird that Denzel has pictures and videos of you?"
    new "为什么丹泽尔有你的照片和视频会这么奇怪？"

translate chinese chinese_0528077_278:
    old "Because..."
    new "因为……"

translate chinese chinese_3468153_279:
    old "Even though I was working hard, I never actually left college, so when I got out of porn, I wanted to work on what I had studied."
    new "虽然我一直在努力工作，但从来没有真正离开过学校，所以当我退出成人行业后，我想从事我所学的专业。"

translate chinese chinese_0386747_280:
    old "It may be because I was so young, but I didn't think my previous job was going to be an issue."
    new "可能是因为我那时候太年轻了，没想到之前的工作会成为问题。"

translate chinese chinese_9265645_281:
    old "Nobody wanted to hire, a lot of parents, teachers, and principals at schools had seen my work."
    new "没人愿意雇用我，很多学校的家长、老师和校长都看过我的作品。"

translate chinese chinese_9503944_282:
    old "Ugh, they believed it was inappropriate for me to teach the children..."
    new "唉，他们认为我不适合教孩子..."

translate chinese chinese_9448303_283:
    old "I suppose it wasn't to jack up to my face."
    new "我想不是要在我面前装逼吧。"

translate chinese chinese_2774753_284:
    old "Anyway, I decided that since I wasn't working in that industry any longer I didn't want my videos and pictures out there."
    new "不管怎样，我决定既然不再从事那行了，就不想让那些视频和照片流传出去。"

translate chinese chinese_2834699_285:
    old "So, I sued my previous producer, and I managed to get everything taken down."
    new "所以，我把之前的制作人告了，结果把所有东西都下架了。"

translate chinese chinese_3119894_286:
    old "Wow, that's amazing."
    new "哇，真厉害。"

translate chinese chinese_9492947_287:
    old "But it didn't really fix things where I lived, in the end, I had to move... several times."
    new "但那并没有真正解决我住的地方的问题，最后我不得不搬家……好几次。"

translate chinese chinese_7972304_288:
    old "A lot of people in different places knew who I was. Finally, I came to this place, where nobody seems to know me."
    new "很多地方的人都知道我是谁。最后，我来到这里，似乎没人认识我。"

translate chinese chinese_0735578_289:
    old "I understand, so you don't want people finding out about it."
    new "我明白了，所以你不想让别人知道这件事。"

translate chinese chinese_9994404_290:
    old "Of course not, it's taken me a lot of work to build a life for myself here."
    new "当然不会，我在这里努力打拼建立了自己的生活。"

translate chinese chinese_8700062_291:
    old "I see, but how did he manage to get that material of you if it was all taken down?"
    new "我明白了，但是那些素材他是怎么搞到的，明明都删了啊？"

translate chinese chinese_6661228_292:
    old "Honestly I have no idea, I've looked for hours on end for traces of my material."
    new "说实话我也不知道，我找了好几个小时都没找到我的东西的踪迹。"

translate chinese chinese_0374256_293:
    old "And I haven't been able to find anything, at all. So, it's a mystery to me that he was able to put his hands on it."
    new "而且我一点线索都没找到。所以，他怎么搞到的，对我来说还是个谜。"

translate chinese chinese_4768232_294:
    old "And now he's using it to blackmail me, either I do what he demands, or he takes it to the principal and outs me in front of everybody."
    new "而现在他用这个来威胁我，要么我按他的要求做，要么他就把这事报告给校长，在所有人面前揭发我。"

translate chinese chinese_8150340_295:
    old "After all this work! You have no idea how hard it's been for me to rebuild my life!"
    new "经过了这么多努力！你根本不知道我重建生活有多难！"

translate chinese chinese_4461076_296:
    old "How much I enjoy teaching! Instead of...!"
    new "我多么享受教学啊！而不是……！"

translate chinese chinese_9327107_297:
    old "Instead of letting random actors do what they wanted to me on camera!"
    new "而不是让那些随机的演员在镜头前随意对我做他们想做的事！"

translate chinese chinese_1582953_298:
    old "What's worse about it, is that ever since he began blackmailing me, I've given him more content to use."
    new "更糟糕的是，自从他开始勒索我之后，我还给了他更多的把柄。"

translate chinese chinese_1143826_299:
    old "Being that desperate I've been following his orders, and he has a lot of stuff of me doing inappropriate things at school."
    new "我这么绝望地听从他的命令，他还存了很多我在学校做不适当事情的照片。"

translate chinese chinese_8346486_300:
    old "Like that picture he took of us..."
    new "就像他拍的那张我们的照片一样……"

translate chinese chinese_5903272_301:
    old "Listen, Ms. Mia, we'll do everything we can to stop him."
    new "听着，米娅女士，我们会尽全力阻止他的。"

translate chinese chinese_8409245_302:
    old "Oh really? How?"
    new "哦真的吗？怎么个情况？"

translate chinese chinese_5998681_303:
    old "Uh... I don't really know yet, but there must be a way."
    new "嗯……我还不太清楚，但肯定有办法。"

translate chinese chinese_9981302_304:
    old "Maybe we can hack his computer, or follow him and steal it from him."
    new "maybe 我们可以黑他的电脑，或者跟踪他然后把东西偷过来。"

translate chinese chinese_1480364_305:
    old "Or maybe there's something we can use against him, like his place of work, or something like..."
    new "或者也许有什么可以用来对付他的东西，比如他的工作地点，或者其他什么……"

translate chinese chinese_4850885_306:
    old "Ok, enough! Who do you think you're talking to? Don't you think I already thought about every way I could handle this?"
    new "好了，够了！你以为你在跟谁说话呢？难道你觉得我没想过各种处理方法吗？"

translate chinese chinese_6053598_307:
    old "All of these suggestions of yours are very nice, but they amount to nothing."
    new "你提出的这些建议都很好，但根本没什么用。"

translate chinese chinese_1692797_308:
    old "So, I think it's better if we no longer talk about it, I'll deal with Denzel by myself."
    new "所以，我觉得最好不要再说这个了，我会自己处理丹泽尔的事。"

translate chinese chinese_0145847_309:
    old "What? B-but Miss Mia, I really want to help you, and..."
    new "什么？可是米娅小姐，我真的想帮你，而且..."

translate chinese chinese_5805081_310:
    old "That's very sweet, but there's nothing you can do for me [pla]."
    new "这很甜，但你什么都帮不了我[pla]。"

translate chinese chinese_1761036_311:
    old "But."
    new "但是。"

translate chinese chinese_2727364_312:
    old "Class Is about to start, your classmates will arrive soon and I don't want them catch us talking about this. So drop it!"
    new "快上课了，同学们很快就会来了，我不想让他们看到我们在聊这个。所以别说了！"

translate chinese chinese_4773289_313:
    old "Fine."
    new "好吧。"

translate chinese chinese_1780571_314:
    old "Ok, from today on we'll talk about Latin American political history in the twentieth century."
    new "好的，从今天开始我们来谈谈二十世纪的拉美政治史。"

translate chinese chinese_5718816_315:
    old "And we'll start with the Cuban coup d'etat..."
    new "那我们就从古巴政变开始吧……"

translate chinese chinese_8095275_316:
    old "Ok, that's all for today, I hope you took proper notes of the class."
    new "好的，今天就到这里，希望你好好记了笔记。"

translate chinese chinese_0785738_317:
    old "Remember to practice the subject at home, the test is very close, so don't relax too much and forget to study."
    new "记得在家多练习这个科目，考试快到了，别太放松忘了学习。"

translate chinese chinese_1518734_318:
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term tests."
    new "我知道这听起来像是很多工作，但如果你想在期末考试前彻底掌握所有科目，你就必须这样做。"

translate chinese chinese_8940589_319:
    old "See you at the next class guys."
    new "下次课见了。"

translate chinese chinese_8854535_320:
    old "Oh! It's you."
    new "哦！是你。"

translate chinese chinese_9843122_321:
    old "I came to see you, we need to talk."
    new "我是来看你的，我们需要谈谈。"

translate chinese chinese_4119281_322:
    old "Do we?"
    new "我们是吗？"

translate chinese chinese_7517638_323:
    old "About what?"
    new "关于什么？"

translate chinese chinese_8283024_324:
    old "About Mia, of course, I want you to work with me."
    new "关于Mia，当然了，我希望你能和我一起工作。"

translate chinese chinese_8216710_325:
    old "You what?"
    new "你说什么？"

translate chinese chinese_2273335_326:
    old "Yeah dude, listen, she has no way to get out of this."
    new "yeah 哥们，听我说，她根本没路可走。"

translate chinese chinese_2249038_327:
    old "I have all the information, and the videos and pictures. We can both use it to get revenge on her."
    new "我有所有的信息，还有视频和照片。我们可以用这些来报复她。"

translate chinese chinese_8601081_328:
    old "Come on, revenge? Really?"
    new "喂，报仇？真的吗？"

translate chinese chinese_4617994_329:
    old "Listen, I know she's been terrible to you, right?"
    new "听着，我知道她对你很糟糕，对吧？"

translate chinese chinese_2616050_330:
    old "If we both work together, we can make that little bitch pay for everything she's done to us."
    new "如果我们联手，就能让她为所有对我们做的事付出代价。"

translate chinese chinese_2333591_331:
    old "Besides, imagine all the things you can get her to do to you, just by telling her you'll release the pictures."
    new "再说，想想看，只要你说会放那些照片，你能让她为你做多少事。"

translate chinese chinese_8473776_332:
    old "We'll make sure that she pays like the little slut she is."
    new "我们会让她这个小贱人付出代价的。"

translate chinese chinese_1324292_333:
    old "What do you say, huh?"
    new "你说什么？哼？"

translate chinese chinese_9688863_334:
    old "What's wrong with you dude?! Revenge?! Make her pay? Slut?"
    new "你这家伙怎么了？！复仇？！让她付出代价？婊子？"

translate chinese chinese_8836274_335:
    old "Are you really that twisted? The fuck?! This is a person's life you're talking about!"
    new "你真是那么扭曲吗？妈的！你在谈论的是一个人的人生！"

translate chinese chinese_4582153_336:
    old "You would destroy her life just because she was a little mean to you?"
    new "你就因为她对你有点刻薄就要毁了她的生活？"

translate chinese chinese_6446425_337:
    old "There's something seriously wrong with you dude..."
    new "你这家伙真是有问题..."

translate chinese chinese_8583154_338:
    old "Oh, so that's how it is, I thought you would understand, but it turns out you're just one of those moralist idiots."
    new "哦，原来如此，我还以为你会理解呢，没想到你只是个道德主义者白痴。"

translate chinese chinese_9155680_339:
    old "I'm an molarist idiot? You're the one who thinks he can destroy someone's life and get away with it."
    new "我是磨牙主义者白痴？你才是以为自己可以毁了别人的生活还逍遥法外的那个。"

translate chinese chinese_5602873_340:
    old "Don't give me that bullshit! Listen pal, Mia's just a simple whore who enjoys making others suffer."
    new "别跟我扯这些 bullshit！听好了，Mia 就是个简单的婊子，喜欢看别人受苦。"

translate chinese chinese_8439115_341:
    old "What's wrong with making her pay for all of the bad shit she does?"
    new "让她为做过的坏事付出代价有什么不对吗？"

translate chinese chinese_5894264_342:
    old "After all, it's just giving her a taste of her own medicine."
    new "毕竟，这只是让她尝尝自己的药。"

translate chinese chinese_6055374_343:
    old "What's wrong with you? I won't do anything like that, you asshole."
    new "你毛病吧？我才不会做那种事呢，混蛋。"

translate chinese chinese_3691215_344:
    old "It's true that Mia has a bad temper and a strong character, but not enough for you to justify destroying her life."
    new "米娅确实脾气不好性格强势，但还不至于让你毁了她的生活。"

translate chinese chinese_3336476_345:
    old "You're just hung up on some shit that happened a long time ago and you haven't been able to let it go."
    new "你就是死盯着很久以前的事不放，一直过不去这个坎。"

translate chinese chinese_2861616_346:
    old "You're even more fucking stupid than I thought!"
    new "你简直比我想的还要蠢到家了！"

translate chinese chinese_8205177_347:
    old "But it's ok dude, you'll understand, after all, I can still punish Mia by myself."
    new "但没事兄弟，你会明白的，反正我还能自己惩罚米娅。"

translate chinese chinese_8995329_348:
    old "Whatever you say dude, I don't want anything to do with you or your sick plans."
    new "随便你了兄弟，我可不想跟你还有你的那些变态计划有任何关系。"

translate chinese chinese_3826385_349:
    old "Yeah well, remember this, I'll take my revenge on Mia, and one way or another you'll have to do with it."
    new "好吧，记住这句话，我会报复米娅的，到时候你得接受这个事实。"

translate chinese chinese_2888489_350:
    old "Wow, what is wrong with that guy?"
    new "wow，那家伙到底怎么了？"

translate chinese chinese_0193346_351:
    old "Oh, hey Belle, morning."
    new "哦，嘿，贝儿，早上好。"

translate chinese chinese_0044302_352:
    old "Hey, who was that guy that was talking with you at the entrance? He looked like he was angry, were you arguing?"
    new "嘿，刚才在入口和你说话的那个家伙是谁？他看起来很生气，你们在吵架吗？"

translate chinese chinese_1482663_353:
    old "Oh, him? He's just some guy I know, don't worry about it."
    new "哦，他啊？他就只是个认识的人，别担心。"

translate chinese chinese_4325341_354:
    old "Hmm, I thought that maybe he has something to do with Ms. Mia."
    new "嗯，我想他可能和米娅女士有关。"

translate chinese chinese_5586303_355:
    old "W-why do you think that?"
    new "你为什么这么想？"

translate chinese chinese_3363132_356:
    old "Did you hear anything?"
    new "你听到什么了吗？"

translate chinese chinese_8161262_357:
    old "Well, it's just that lately, I've seen you talking with Ms. Mia, so I figured that maybe he had something to do with it."
    new "就是最近我看到你和米娅老师在一起聊天，所以我想可能他有什么关系。"

translate chinese chinese_1399591_358:
    old "Uhhh, no, no, he has nothing to do with it."
    new "呃，不，不，他跟这没关系。"

translate chinese chinese_3389751_359:
    old "I've just been talking to Ms. Mia about my grades, you know she's always harping on me."
    new "我刚才和米娅老师聊了我的成绩，你知道她总是对我唠叨个不停。"

translate chinese chinese_3684726_360:
    old "Oh, I see, I guess you do need to pay attention to your grades."
    new "哦，我明白了，看来你确实得注意一下成绩了。"

translate chinese chinese_9018982_361:
    old "Hey, it's time for classes, so come in!"
    new "嘿，上课时间到了，进来吧！"

translate chinese chinese_1062298_362:
    old "Ok guys, it's time to start preparing for the midterm test, so today we'll do a couple of mock tests to help you get ready for it."
    new "好的大家，现在是时候开始准备期中测试了，所以今天我们会做一些模拟测试来帮助你们做好准备。"

translate chinese chinese_7243226_363:
    old "So, I hope you found the excersises useful, remember to practice again at home, the test is very close, so don't relax too much and forget to study."
    new "所以，希望你发现这些练习很有用，记得回家再练习，考试快到了，所以不要放松太多忘记学习。"

translate chinese chinese_8686166_364:
    old "[pla], wait a minute, I'll need you stay, we need to talk about your grades."
    new "[pla]，等一下，你需要留下来，我们得谈谈你的成绩。"

translate chinese chinese_9360011_365:
    old "What the fuck did you do?!! You idiot! I told you to stay out of it!"
    new "你他妈干了什么！！白痴！我让你别管的！"

translate chinese chinese_6023292_366:
    old "Denzel called me and was very fucking angry! He said you were gonna pay him for saying what you said!"
    new "丹泽尔打电话给我，非常愤怒！他说你要赔偿他，因为你说了那些话！"

translate chinese chinese_8790835_367:
    old "What did you do?!"
    new "你干了什么?!"

translate chinese chinese_9334561_368:
    old "Nothing, nothing! I swear to God! He's the one that came to talk to me this morning, when I was arriving at school!"
    new "没什么，真的没什么！我发誓！今天早上我到学校的时候，是他主动来跟我讲话的！"

translate chinese chinese_0259588_369:
    old "He wanted me to allie with him and help him mess with you."
    new "他想让我跟他联手，然后一起对付你。"

translate chinese chinese_5181634_370:
    old "But I told him no, that I wasn't gonna be part of it."
    new "但我告诉他不行，我不打算参与这件事。"

translate chinese chinese_1323909_371:
    old "Oh FUCK! Why did you have to get involved with this!"
    new "哦操！你为什么要卷进这事！"

translate chinese chinese_9742286_372:
    old "This has nothing to do with you!"
    new "这跟你没关系！"

translate chinese chinese_1068908_373:
    old "Because of what you told him he's now fucking angry!"
    new "因为你跟他说了那些话，他现在气疯了！"

translate chinese chinese_4997585_374:
    old "Listen to me [pla], stay out of this, okay?! This has absolutely nothing to do with you!"
    new "听我说，[pla]，别管这事，好吗？！这跟你完全没关系！"

translate chinese chinese_6481295_375:
    old "Don't talk to that guy, don't make contact. Nothing!"
    new "别跟那家伙说话，别接触。什么也别说！"

translate chinese chinese_3457698_376:
    old "Do you get it?!"
    new "你明白了吗？！"

translate chinese chinese_2972543_377:
    old "Whatever you say, but that guy is the one that came to me, and you know he's insane."
    new "随便你怎么说，但那个家伙是主动来找我的，你知道他有多疯狂。"

translate chinese chinese_5329174_378:
    old "I came to visit, I had to see my favorite teacher."
    new "我来拜访的，我非见见我最喜欢的老师不可。"

translate chinese chinese_2145714_379:
    old "And look at that! My good friend [pla] is here as well!"
    new "看看！我好朋友[pla]也在呢！"

translate chinese chinese_7227253_380:
    old "Good, good, just what I was expecting."
    new "很好，很好，正是我所期望的。"

translate chinese chinese_4838448_381:
    old "Dude, don't you have anything else to do besides stalking Ms. Mia all day?"
    new "伙计，除了整天跟踪米娅小姐你没什么别的事做吗？"

translate chinese chinese_9812561_382:
    old "Heh, you shouldn't worry that much about what I do to fill my time."
    new "嘿嘿，你不用这么担心我怎么打发时间。"

translate chinese chinese_0330129_383:
    old "It's more interesting what you're about to do!"
    new "你接下来要做的事更有趣！"

translate chinese chinese_6756306_384:
    old "After all, I think it's about time that you two start."
    new "毕竟，我觉得你们也该开始了。"

translate chinese chinese_5116879_385:
    old "'Ms.' Mia, you haven't told him about the new challenge?"
    new "“米娅小姐”，你还没告诉他关于新的挑战吗？"

translate chinese chinese_4835343_386:
    old "Don't even think about Denzel."
    new "别想德伦zel了。"

translate chinese chinese_1403738_387:
    old "It's not happening! No way in hell!"
    new "没门儿！想都别想！"

translate chinese chinese_6365762_388:
    old "Well, that surprises me, I guess that you don't mind then about the school principal receiving an interesting mail, do you?"
    new "好吧，这让我有点惊讶，看来你不在乎校长收到一封有趣的邮件了，是吧？"

translate chinese chinese_8719012_389:
    old "Wait, what's happening? What did you ask this time."
    new "等一下，发生什么事了？这次你问了什么。"

translate chinese chinese_1603248_390:
    old "Tell him, Mia."
    new "告诉她吧，米娅。"

translate chinese chinese_0905450_391:
    old "{i}*Sigh*{/i} The thing is, this sick bastard wants us to have sex."
    new "{i}*叹气*{/i} 问题是，这个混账想要我们发生关系。"

translate chinese chinese_2207413_392:
    old "What?! What the fuck?!"
    new "什么?! 干什么?!"

translate chinese chinese_5019472_393:
    old "There's something seriously wrong with you pal! That's way too far! I'm going to the police!"
    new "你这家伙真是有问题！这太过分了！我要报警！"

translate chinese chinese_0812178_394:
    old "HA! Do it! Fine by me!"
    new "哈！来啊！我无所谓！"

translate chinese chinese_2263489_395:
    old "I mean, sure, maybe I'll get trial for blackmail, nothing severe 'cause you don't have any evidence..."
    new "我的意思是，好吧，也许我会因为敲诈勒索接受审判，但没什么大不了的，因为你没有任何证据……"

translate chinese chinese_9029553_396:
    old "But what's gonna happen when they review the photos and videos I got from you, what do you think will happen then, eh [pla]?"
    new "但是等他们审查我从你这里得到的照片和视频时会发生什么，你觉得到时候会怎么样呢，哼，[pla]？"

translate chinese chinese_3172656_397:
    old "All of that is gonna come out to the public, and everyone will know Mia used to be a pornstar."
    new "所有这些都会公之于众，大家都会知道米娅以前是 pornstar。"

translate chinese chinese_6422250_398:
    old "But that's not the worst part."
    new "但这还不是最糟糕的。"

translate chinese chinese_4066534_399:
    old "What will really make people angry is the fact that she's fucking her students."
    new "真正让人愤怒的是她在跟学生搞暧昧。"

translate chinese chinese_6260540_400:
    old "Imagine what will happen then, hahaha."
    new "想想那时候会发生什么，哈哈。"

translate chinese chinese_7007813_401:
    old "W-what?! Fucking her student? The hell are you talking about?"
    new "什、什么？！跟她学生？你在说什么鬼？"

translate chinese chinese_0714513_402:
    old "I suppose you remember that picture I took of you the other day."
    new "我想你还记得我前几天给你拍的那张照片。"

translate chinese chinese_6294411_403:
    old "Come on, everybody will believe that you two have been fucking anyway."
    new "得了，大家反正都会以为你们俩上过床。"

translate chinese chinese_4286809_404:
    old "I'll just make it a reality."
    new "我就让它成真吧。"

translate chinese chinese_3837082_405:
    old "You're sick dude!"
    new "你这家伙真是够了！"

translate chinese chinese_7951652_406:
    old "Wait [pla], stop... just stop."
    new "等一下[pla]，停下...就停在这里。"

translate chinese chinese_3362159_407:
    old "{i}*Sigh*{/i} All right Denzel, you win... We'll do it."
    new "{i}*叹气*{/i} 好了，丹泽尔，你赢了……我们就这么办。"

translate chinese chinese_0844290_408:
    old "You can't be serious!"
    new "你不是认真的吧！"

translate chinese chinese_6411228_409:
    old "You can't let this guy get away with something like that! We have to go to the police!"
    new "你不能让他这么嚣张！我们必须报警！"

translate chinese chinese_7536725_410:
    old "And then what?! You heard him! If we go to the police my life will be ruined!"
    new "然后呢？！你听到他说的了！如果我们报警，我的生活就完了！"

translate chinese chinese_8926490_411:
    old "Besides, with the other photos that he has, he could also drag you down with me!"
    new "而且，凭借他手上的其他照片，他也能够把你和我一起拖下水！"

translate chinese chinese_8721395_412:
    old "Hmph!"
    new "哼！"

translate chinese chinese_0102162_413:
    old "Look, I don't want this, but I really need your help. Please [pla]."
    new "听着，我并不想这样，但我真的需要你的帮助。请[pla]。"

translate chinese chinese_5448565_414:
    old "{i}*Sigh*{/i} Ok, I guess we have to."
    new "{i}*叹气*{/i} 好吧，我想我们得这么做。"

translate chinese chinese_9000332_415:
    old "Ok, Denzel, we'll do it."
    new "好吧，丹泽尔，我们答应你。"

translate chinese chinese_2441380_416:
    old "Fantastic! I knew you guys would come around!"
    new "太好了！我就知道你们会同意的！"

translate chinese chinese_4069791_417:
    old "Ok, let's get to it!"
    new "好，开始吧！"

translate chinese chinese_3438623_418:
    old "What? Here? Now?"
    new "什么？这里？现在？"

translate chinese chinese_7993146_419:
    old "What would be better?"
    new "有什么更好的吗？"

translate chinese chinese_7295895_420:
    old "It's ok, I don't think the janitor will come anytime soon. So nobody will notice us."
    new "没关系，我觉得清洁工不会很快来，所以没人会注意到我们的。"

translate chinese chinese_6944425_421:
    old "Wait, 'us'? Does that mean you're gonna be here while we do it?"
    new "等下，\\\"我们\\\"？那你是不是也要在这里看着我们做？"

translate chinese chinese_7371957_422:
    old "Of course I'm serious! What else am I going to do?"
    new "我当然是认真的！我还打算干什么呢？"

translate chinese chinese_7845592_423:
    old "Besides, you can't be angry about it Mia, you're used to fucking in front of other people, right? This should be easy for you."
    new "再说，米娅，你不能生这个气吧，你不是习惯了在别人面前做爱吗？这对你来说应该很简单。"

translate chinese chinese_9984508_424:
    old "Just close your eyes and imagine it's the good old days. You whore."
    new "just闭上眼睛，想象一下那是美好的旧时光。你这个婊子。"

translate chinese chinese_9299191_425:
    old "Oh, by the way, remember to take your tits out. You've been keeping them hidden, and I think it's time for you to let them out."
    new "哦，对了，记得把胸露出来。你一直藏着，我觉得是时候该露出来了。"

translate chinese chinese_8602926_426:
    old "You're fucking pathetic."
    new "你真是个废物。"

translate chinese chinese_7159526_427:
    old "Hehehe, sure, sure."
    new "嘿嘿嘿，好啦好啦。"

translate chinese chinese_6111433_428:
    old "I bet you're happy getting drilled by that cock."
    new "我敢打赌，被那家伙操得挺爽吧。"

translate chinese chinese_7147860_429:
    old "Ugh, whatever dude."
    new "哎呀，随便你了。"

translate chinese chinese_4886072_430:
    old "We're only doing this because you're forcing us, you ass."
    new "我们只是因为被你逼的才这么做的，你这个混蛋。"

translate chinese chinese_1922877_431:
    old "You know, you're making me sound like the bad guy, but I'm sure you're enjoying this."
    new "你知道吗，你这么说让我听起来像是坏人，但肯定你在享受这个过程。"

translate chinese chinese_1126542_432:
    old "You may fool yourself and others with this whole 'teacher' thing, but I know that you're really a whore."
    new "你用这副老师的模样骗得了自己也骗得了别人，但我清楚你其实是个婊子。"

translate chinese chinese_7007325_433:
    old "You're sick."
    new "你真够阴险的。"

translate chinese chinese_8866586_434:
    old "Hahaha, you keep fucking like the bitch you are."
    new "哈哈，你就继续像条母狗一样干吧。"

translate chinese chinese_1583118_435:
    old "Oh come on!"
    new "Oh 加油！"

translate chinese chinese_4331534_436:
    old "Come on dude!"
    new "喂，别这样！"

translate chinese chinese_6734647_437:
    old "Oh, I'm sorry, I interrupted you guys when you were having such a sweet time together."
    new "哦，对不起，我打扰到你们甜蜜的时光了。"

translate chinese chinese_5843063_438:
    old "I'm so rude."
    new "我真是粗鲁。"

translate chinese chinese_8327509_439:
    old "But you see, now I have actual evidence that you guys fucked!"
    new "但你看，现在我有实际证据证明你们真的发生过关系！"

translate chinese chinese_8719819_440:
    old "I guess that means that I now have two bitches instead of just one. Am I right?"
    new "我猜这意味着我现在有两个骚货而不是一个。对吧？"

translate chinese chinese_5365598_441:
    old "Hahahahahahahaha."
    new "哈哈哈哈哈。"

translate chinese chinese_8140612_442:
    old "I told you you were going to be a part of this [pla]."
    new "我告诉过你，你会是这个计划的一部分的。"

translate chinese chinese_3841438_443:
    old "You're really twisted."
    new "你真是扭曲。"

translate chinese chinese_0002047_444:
    old "I think I should get going, but don't worry guys, I'll be seeing you soon."
    new "我觉得我该走了，但别担心，大家很快就会见到我的。"

translate chinese chinese_8759904_445:
    old "There's something seriously wrong with that guy's head."
    new "那家伙脑袋真的有问题。"

translate chinese chinese_9423806_446:
    old "{i}*Sigh*{/i} Whatever. For now, let's just get dressed."
    new "{i}*叹气*{/i} 算了。先穿衣服吧。"

translate chinese chinese_5638295_447:
    old "Listen, Ms. Mia, I know that what just happened's disheartening, but I'm sure there must be something we can do."
    new "听着，米娅小姐，我知道刚刚发生的事很让人沮丧，但我相信我们一定可以做些什么。"

translate chinese chinese_0345193_448:
    old "We can't just give in to what that maniac wants."
    new "我们不能就这么屈服于那个疯子的要求。"

translate chinese chinese_3907400_449:
    old "No, there isn't anything, he's already got us."
    new "不，没什么了，他已经把我们都搞定了。"

translate chinese chinese_7715469_450:
    old "It's just as he says, we're his bitches."
    new "就像他说的，我们就是他的玩物。"

translate chinese chinese_8838155_451:
    old "Let's just leave it at that."
    new "我们就到此为止吧。"

translate chinese chinese_0382477_452:
    old "Damn it, there has to be something I can do, I'm sure of it."
    new "该死，我肯定能做点什么的。"

translate chinese chinese_5880636_453:
    old "Oh, thanks God, I found you! Please come here for a minute."
    new "哦，感谢上帝，我找到你了！请过来一下。"

translate chinese chinese_1579397_454:
    old "Listen, I have to tell you something."
    new "听着，我有件事必须告诉你。"

translate chinese chinese_0011522_455:
    old "Denzel called me, he gave us another 'challenge'."
    new "丹泽尔给我打电话了，他又给了我们一个“挑战”。"

translate chinese chinese_1116454_456:
    old "What? Are you for real?"
    new "什么？你是认真的吗？"

translate chinese chinese_6602450_457:
    old "What does he want now?"
    new "他又想要什么？"

translate chinese chinese_8184524_458:
    old "Well, every time he's given me a new 'challenge' to do, they have been getting riskier and riskier."
    new "好吧，每次他给我一个新的“挑战”时，这些挑战的风险就越来越大了。"

translate chinese chinese_5782488_459:
    old "This time is the same, he wants us to... Have sex in the school bathroom."
    new "这次也一样，他想让我们……在学校洗手间做爱。"

translate chinese chinese_1644915_460:
    old "Woah! Really? But that's way too risky!"
    new "哇！真的吗？但这风险太大了吧！"

translate chinese chinese_9346441_461:
    old "I mean, last time everyone had already gone home. What will happen if someone sees us?"
    new "我的意思是，上次大家已经都回家了。要是有人看到我们怎么办？"

translate chinese chinese_6451172_462:
    old "I already thought of that, that's why I'm telling you now because everyone else is in their classrooms."
    new "我早就想到这一点了，所以现在告诉你，因为其他人还在教室里。"

translate chinese chinese_4681020_463:
    old "If we do it now nobody should see us."
    new "如果我们现在做，应该没人会看到。"

translate chinese chinese_7808067_464:
    old "So we should go have sex in the bathroom now?"
    new "所以我们现在去洗手间做爱？"

translate chinese chinese_4242198_465:
    old "That's right, he said I have to do a video call... for him to see us."
    new "没错，他说我得进行视频通话……让他看看我们。"

translate chinese chinese_2594474_466:
    old "Jesus! What the hell is wrong with that freak?!"
    new "天啊！那个变态到底怎么了？！"

translate chinese chinese_4674320_467:
    old "No way we're doing that."
    new "没门，我们不会那么做的。"

translate chinese chinese_4661483_468:
    old "Not this again..."
    new "又来了……"

translate chinese chinese_8698603_469:
    old "[pla], this is really difficult for me, you know? You know all the stuff he has of us."
    new "[pla]，这对我来说真的很困难，你知道的？你知道他有多少我们的东西。"

translate chinese chinese_8654914_470:
    old "Please don't make me beg you again, I really need you to help me."
    new "别让我再求你了，我真的需要你的帮助。"

translate chinese chinese_3048839_471:
    old "Hmm, yeah, you're right."
    new "嗯，对，你说得对。"

translate chinese chinese_1254314_472:
    old "{i}*Sigh*{/i} Ok, let's go then."
    new "{i}*叹气*{/i} 好吧，那我们走吧。"

translate chinese chinese_3196666_473:
    old "I know I keep putting too many hurdles, but are you sure about this?"
    new "我知道我总是设置很多障碍，但你确定要这么做吗？"

translate chinese chinese_1398359_474:
    old "As I already told you, we don't have any other choice."
    new "就像我刚才告诉你的，我们没有其他选择。"

translate chinese chinese_3533192_475:
    old "Hmph, yeah, yeah, you're right."
    new "哼，好吧，你说得对。"

translate chinese chinese_1987643_476:
    old "Ok, let's call this asshole."
    new "好吧，咱们就联系这个混蛋。"

translate chinese chinese_4464181_477:
    old "... Ringing ..."
    new "... 正在振铃 ..."

translate chinese chinese_3879141_478:
    old "Hello! Wow, you guys are early!"
    new "喂！哇，你们来得好早啊！"

translate chinese chinese_0971257_479:
    old "This is the perfect location, isn't it Mia?"
    new "这里是最完美的地点，不是吗，米娅？"

translate chinese chinese_2577654_480:
    old "A dirty little place for a dirty little whore. Hahaha."
    new "一个脏兮兮的地方给一个脏兮兮的婊子。哈哈。"

translate chinese chinese_7015785_481:
    old "What about you [pla]? Aren't you happy you get to fuck your dear teacher again?"
    new "那你呢，[pla]？不高兴又能再次和亲爱的老师做爱吗？"

translate chinese chinese_6015794_482:
    old "Fuck you dude! Don't think you can keep getting away with this for too long."
    new "去你的！别以为你能一直这样逃避。"

translate chinese chinese_2451177_483:
    old "Hahaha, whatever, let's just get started with this."
    new "哈哈，管它呢，咱们还是开始吧。"

translate chinese chinese_9169865_484:
    old "Oh! And remember to take your tits out Mia, I'm recording this, so I want it to be good quality."
    new "哦！还有记得把胸露出来，米娅，我在录这段，所以想要高质量的。"

translate chinese chinese_0091203_485:
    old "Oh yeah, just like that, nice."
    new "哦 yeah，就是那样，不错。"

translate chinese chinese_2500864_486:
    old "My gosh, I hate P.E. so much! I'm so sweaty!"
    new "天啊，我超级讨厌体育课！我现在一身汗！"

translate chinese chinese_4880134_487:
    old "{i}Stop, stop! Oh shit! Someone is coming!{/i}"
    new "停，停！哦shit！有人来了！"

translate chinese chinese_9041703_488:
    old "Ugh, I know, like, look at my makeup!"
    new "哎呀，你看我这妆花了！"

translate chinese chinese_8878467_489:
    old "Now I'm gonna have to re-do it all over again!"
    new "现在我得全部重来了！"

translate chinese chinese_6269064_490:
    old "Hey, by the way, had you noticed how Mia is acting lately?"
    new "嘿，对了，你有没有注意到米娅最近的行为？"

translate chinese chinese_4994881_491:
    old "Oh my god yeah! She's acting like a whore, flashing off in front of the whole classroom!"
    new "天啊对！她简直像妓女一样，在全班面前大秀特秀！"

translate chinese chinese_5107234_492:
    old "What was that?"
    new "那是什么？"

translate chinese chinese_1373862_493:
    old "Like... a voice?"
    new "像……一个声音？"

translate chinese chinese_4654792_494:
    old "Hmm, it's nothing, maybe somebody spoke in the hall."
    new "嗯，没什么，可能是有人在走廊上说话吧。"

translate chinese chinese_4682445_495:
    old "Yeah, you're right."
    new "嗯，你说得对。"

translate chinese chinese_8846493_496:
    old "Ok, I'm ready."
    new "好的，我准备好了。"

translate chinese chinese_7739325_497:
    old "Yeah, me too, let's go. Anyway, as I was telling you, what the fuck is wrong with Mia?"
    new "yeah, 我也是，走吧。话说，刚才跟你说的，Mia 究竟怎么了？"

translate chinese chinese_7279330_498:
    old "Ok, ok, they are gone."
    new "好啦好啦，他们走了。"

translate chinese chinese_6485819_499:
    old "Ha! What's the matter Mia? Afraid of getting caught?"
    new "哈！米娅，怎么了？害怕被抓住吗？"

translate chinese chinese_7254089_500:
    old "But I know you like people seeing your pussy! What's the big deal?"
    new "但我知道你喜欢让人看你的屄！有什么大不了的？"

translate chinese chinese_1576727_501:
    old "Ugh, let's just get this over with [pla]."
    new "唉，赶紧搞定吧[pla]。"

translate chinese chinese_8710042_502:
    old "Fuck, this is getting more and more risky!"
    new "操，这越来越危险了！"

translate chinese chinese_9942938_503:
    old "At the end it won't matter if he tells on us or not!"
    new "到最后，他告不告密都无所谓了！"

translate chinese chinese_3235021_504:
    old "People will end up catching us anyway!"
    new "反正最后还是会被人发现的！"

translate chinese chinese_7304687_505:
    old "We have to do something."
    new "我们必须做点什么。"

translate chinese chinese_1032618_506:
    old "I'm also not happy with this. And It's already started to affect me, I can't even sleep well."
    new "我也不满意这种情况。这已经开始影响到我了，我甚至睡不好觉。"

translate chinese chinese_1956952_507:
    old "I'm starting to get severe anxiety again, and the nightmares have come back. But what can I do?"
    new "我又开始严重焦虑了，噩梦也回来了。但我能怎么办？"

translate chinese chinese_0792455_508:
    old "We can't just go to the police! I don't want to lose my life! And now he has stuff that's even worse!"
    new "我们不能直接报警！我不想丢掉性命！而且现在他还掌握了更糟糕的东西！"

translate chinese chinese_8287398_509:
    old "I know this is hard, but there must be a solution."
    new "我知道这很难，但一定有解决办法。"

translate chinese chinese_4047971_510:
    old "Well, if there is one I don't know what it may be."
    new "好吧，如果有我也就不知道了。"

translate chinese chinese_9785997_511:
    old "Let's just let's get out of here before someone comes again."
    new "我们还是赶紧走吧，别让人再撞见了。"

translate chinese chinese_6447871_512:
    old "(She's feeling really bad, I'm sorry for her.)"
    new "（她感觉很糟糕，我为她感到难过。）"

translate chinese chinese_9537915_513:
    old "I bet there's something else I could do..."
    new "我敢打赌还有别的事情可以做..."

translate chinese chinese_0292209_514:
    old "Hmmm... But I do have the SexNote..."
    new "嗯……但是我现在确实有SexNote……"

translate chinese chinese_6675320_515:
    old "Hey Linett. How are you?"
    new "嘿，林内特。你好吗？"

translate chinese chinese_2828200_516:
    old "Oh, [pla] I'm fine, thanks for asking, what about you?"
    new "哦，[pla] 我挺好的，谢谢关心，你呢？"

translate chinese chinese_5181562_517:
    old "Hmm, a little bit worried actually, I have a small problem that I would like you to help me with."
    new "嗯，其实有点担心，我有个小问题想请你帮忙。"

translate chinese chinese_0708640_518:
    old "Oh, interesting."
    new "哦，有意思。"

translate chinese chinese_1956156_519:
    old "Well, I know a person that's being blackmailed."
    new "好吧，我知道有个人被敲诈了。"

translate chinese chinese_1799026_520:
    old "Blackmailed? What is that?"
    new "敲诈？那是什么意思？"

translate chinese chinese_2506032_521:
    old "I've never heard of it, is it some type of tradition between humans?"
    new "我从来没听说过，这是人类之间的一种传统吗？"

translate chinese chinese_6443229_522:
    old "Uhh, somebody being blackmailed means that somebody else is threatening them with something that they care about."
    new "嗯，被敲诈的意思就是有人用他们关心的东西来威胁他们。"

translate chinese chinese_1027811_523:
    old "That can be anything, something that belongs to them, or something they want."
    new "那可以是任何东西，属于他们的东西，或者他们想要的东西。"

translate chinese chinese_4791982_524:
    old "And if you don't do what that person wants, they'll punish you with what they have against you."
    new "如果你不按那个人的要求去做，他们就会用他们掌握的东西来惩罚你。"

translate chinese chinese_4508678_525:
    old "Wow, that sounds horrible! You humans really are something else!"
    new "wow, 听起来真糟糕！你们人类真是让人无语！"

translate chinese chinese_0033652_526:
    old "The type of things you do to each other is always surprising."
    new "你们互相做的事情总是让人惊讶。"

translate chinese chinese_0788697_527:
    old "Yeah, well, this person I know is going through that. So, I'm trying to help her."
    new "嗯，我认识的一个人正经历这个。所以我在试着帮她。"

translate chinese chinese_3482234_528:
    old "That's very good, you should do that."
    new "很好，你应该这么做。"

translate chinese chinese_1112992_529:
    old "Well, I'm glad I was able to help you [pla]."
    new "嗯，我很高兴能帮到你[pla]。"

translate chinese chinese_5495589_530:
    old "That wasn't the point."
    new "那不是重点。"

translate chinese chinese_3833278_531:
    old "Oh, ok, so what is it?"
    new "哦，好的，那是什么？"

translate chinese chinese_8282134_532:
    old "Uhhh, I'll tell you the story, this person we're talking about is my teacher."
    new "呃，我告诉你，这个人是我们谈论的老师。"

translate chinese chinese_5161984_533:
    old "The thing is that some guy found some 'information' about her that she doesn't want anyone to see."
    new "问题是有个家伙找到了一些她不想让人看到的“信息”。"

translate chinese chinese_3217107_534:
    old "But there's no way of stopping him from putting it out there. At least not through anything we can do."
    new "但阻止他发布是不可能的了。至少我们无能为力。"

translate chinese chinese_5434503_535:
    old "So, I was thinking that maybe there's a way to do it through the SexNote."
    new "所以，我在想也许可以通过SexNote来办到。"

translate chinese chinese_3300727_536:
    old "What kind of information is this?"
    new "这是什么信息？"

translate chinese chinese_9796615_537:
    old "It's videos and pictures, they must be safe in his computer or something."
    new "是视频和照片，肯定在他电脑里或者什么地方保存着。"

translate chinese chinese_5944381_538:
    old "Well, don't you think it would just be easier if you steal his computer and delete that?"
    new "嗯，你觉得要是偷了他的电脑直接删了不就轻松多了？"

translate chinese chinese_7587800_539:
    old "I don't think that would do anything, he wouldn't be that stupid not to make any copies of it."
    new "我觉得那样没用，他不会蠢到不做备份。"

translate chinese chinese_4419839_540:
    old "Besides, he also remembers it all, if he just tells the police or the press or anyone what he knows, they could find something."
    new "再说，他如果把知道的事情告诉警察或者媒体或者其他任何人，他们也能查出些什么。"

translate chinese chinese_2932491_541:
    old "Hmm, I see what you mean."
    new "嗯，我明白你的意思了。"

translate chinese chinese_3620116_542:
    old "So basically, what you want is a spell that'll change reality."
    new "所以基本上，你想要的是一个能改变现实的魔法。"

translate chinese chinese_8729801_543:
    old "U-uh, w-what? I-I don't think..."
    new "呃，什么？我我不觉得..."

translate chinese chinese_3644135_544:
    old "Well, that's what you need, isn't it?"
    new "嗯，这就是你需要的，对吧？"

translate chinese chinese_7014835_545:
    old "I mean, you need every version of this information to disappear."
    new "我的意思是，你需要让这个信息的所有版本都消失。"

translate chinese chinese_7998229_546:
    old "That includes his memories, so that he won't go around telling it to people."
    new "这包括他的记忆，这样他就不会到处乱说了。"

translate chinese chinese_9073761_547:
    old "That's a very high requirement for a spell [pla]."
    new "对于法术[pla]来说，这要求太高了。"

translate chinese chinese_4259167_548:
    old "But... There's a way..."
    new "但是……还是有办法的……"

translate chinese chinese_7544587_549:
    old "Something like that, there's a way to erase stuff magically... or at least their 'presence'."
    new "差不多就是有这样的魔法可以擦除东西……或者至少是他们的“存在”。"

translate chinese chinese_8481936_550:
    old "'Presence'? W- what do you mean?"
    new "“存在”？你什么意思？"

translate chinese chinese_5193362_551:
    old "I mean just that, you humans live in a world full of traces, all of your technology is marked with traces of who you are."
    new "我的意思是，你们人类生活在一个充满痕迹的世界里，你们的所有技术都带着你们的痕迹。"

translate chinese chinese_7405312_552:
    old "Like those pictures that you take of each other and then you can save or send."
    new "就像你们互相拍的照片，然后可以保存或发送的那种。"

translate chinese chinese_5659667_553:
    old "But also memories, whatever traces left by time in the mind of someone else. That's also a 'presence'."
    new "但也有关于记忆，时间在别人心中留下的任何痕迹。这也是一种“存在”。"

translate chinese chinese_9304809_554:
    old "All of that can be gone. With a big spell."
    new "所有的一切都可以消失。只要一个大咒语。"

translate chinese chinese_6838181_555:
    old "I suppose that's what you mean when you say you want me to help you."
    new "我想这就是你说的想要我帮忙的意思吧。"

translate chinese chinese_9952547_556:
    old "Uhh, I mean, I think I do, but I'm not sure. I- I don't really understand all what you said."
    new "呃，我的意思是，我觉得我懂，但也不太确定。我——我真的不太明白你说的全部。"

translate chinese chinese_2522746_557:
    old "What I said is that I can use a spell that can erase all information about her, that's what you are asking me, right?"
    new "我说的是我可以使用一个能抹去关于她的所有信息的咒语，这就是你问我的吧？"

translate chinese chinese_1282860_558:
    old "Yes! That's exactly what I need..."
    new "没错！这正是我需要的……"

translate chinese chinese_5885243_559:
    old "And if you have another spell for the bad guy, you know, something to make him forget all about her."
    new "如果你还有别的咒语对付坏家伙的话，你知道的，就是那种让他完全忘记她的咒语。"

translate chinese chinese_8927373_560:
    old "Yeah, with the same spell the bad human doing the 'blackmail' thing, he won't even remember her."
    new "是的，用同样的咒语，那个搞“敲诈”的坏人甚至不会记得她。"

translate chinese chinese_8375177_561:
    old "Everything about her would be forgotten."
    new "关于她的所有记忆都会消失。"

translate chinese chinese_2622355_562:
    old "If he can't remember anything about her, and all the information he has is also gone. That would solve your problem, would it not?"
    new "如果他什么都记不起来，而且所有关于她的信息也都消失了，那你的问题不就解决了吗？"

translate chinese chinese_4873054_563:
    old "Wow! Yeah, that's perfect!"
    new "哇！对，就是这样！"

translate chinese chinese_2992174_564:
    old "All right, this spell is somewhat difficult to execute, but is possible."
    new "好吧，这个咒语有点难施展，但还是有可能的。"

translate chinese chinese_2148368_565:
    old "Ok, what do I need?"
    new "好的，我需要什么？"

translate chinese chinese_5458260_566:
    old "Hmm, to be honest, you're still not very good with magic..."
    new "嗯，说实话，你的魔法还是不太熟练……"

translate chinese chinese_2722300_567:
    old "So, I'll have to prepare a lot of things beforehand to make it easier for you to use that spell."
    new "所以，我得提前准备很多东西，让你更容易使用那个咒语。"

translate chinese chinese_3160116_568:
    old "Oh, it can't be done today? I mean, I have a bit of an urgency with this..."
    new "哦，今天不行吗？我的意思是，这个有点急..."

translate chinese chinese_1264413_569:
    old "No, I'll need a couple of days to get everything ready, we can't afford any mistakes with this."
    new "不，我需要几天时间来准备一切，这件事我们不能出任何差错。"

translate chinese chinese_4392068_570:
    old "Hmm, I guess that's fine if there's no way to do it now."
    new "嗯，我想现在没办法做的话就算了。"

translate chinese chinese_9127820_571:
    old "Thanks for your help Linnet, I'm counting on you."
    new "谢谢你帮忙，林内特，我靠你了。"

translate chinese chinese_1352632_572:
    old "I'll do my best to help you, don't worry."
    new "我会尽全力帮助你的，别担心。"

translate chinese chinese_7553126_573:
    old "I knew it, magic should be useful for something."
    new "我就知道，魔法应该有些用处。"

translate chinese chinese_4951430_574:
    old "With this I'm sure I'll be able to help Ms. Mia."
    new "有了这个，我肯定能帮上米娅小姐的忙。"

translate chinese chinese_6793743_575:
    old "[pla]... I'm gonna need you to come to the classroom with me."
    new "[pla]……我需要你跟我去教室。"

translate chinese chinese_3506129_576:
    old "Oh, not Denzel again, come on. What does he want now?"
    new "哦，又是丹泽尔，快别说了。这次他又想要什么？"

translate chinese chinese_5590908_577:
    old "Just come with me."
    new "跟我来就行了。"

translate chinese chinese_5314351_578:
    old "Denzel said he wanted to talk to both of us, let me call him and I'll put the call on speaker."
    new "丹泽尔说他想和我们两个谈谈，我给他打个电话，然后免提吧。"

translate chinese chinese_8916856_579:
    old "Denzel, hi."
    new "丹泽尔，你好。"

translate chinese chinese_6924296_580:
    old "Hi there Ms. Mia! How are you? Is my good friend [pla] over there?"
    new "嗨，米娅小姐！你好吗？我好朋友[pla]在那里吗？"

translate chinese chinese_1369151_581:
    old "I'm here."
    new "我在这儿。"

translate chinese chinese_4802517_582:
    old "Excellent, excellent! Ok, guys, I've been thinking, and I came to a conclusion."
    new "非常好，非常好！大家，我考虑了一下，得出了一个结论。"

translate chinese chinese_8595028_583:
    old "Well, I've decided that it's time for you two to take your relationship to the next level."
    new "好吧，我决定你们是时候把关系提升到下一个层次了。"

translate chinese chinese_9026236_584:
    old "Given that you already consummated your teacher-student love."
    new "既然你们师生恋都已经实质了。"

translate chinese chinese_0805358_585:
    old "I think you need to take the next step?"
    new "我觉得你需要再进一步了？"

translate chinese chinese_1942301_586:
    old "The next step? We already had sex, what do you even mean?"
    new "下一步？我们已经那个了，你到底什么意思？"

translate chinese chinese_2376513_587:
    old "Stop beating around the bush and tell us already!"
    new "别绕圈子了，赶紧告诉我们吧！"

translate chinese chinese_8259966_588:
    old "Easy there buddy! Trust me, you'll like what I have in store for you guys today."
    new "别急，兄弟！相信我，今天给你们准备的东西你们会喜欢的。"

translate chinese chinese_7954137_589:
    old "Well, I want you to fuck Mia in the ass. It's time she gets her ass fucked."
    new "好吧，我想让你干米娅的屁股。是时候让她尝尝那个滋味了。"

translate chinese chinese_0697901_590:
    old "W-what?!"
    new "什、什么？！"

translate chinese chinese_2824013_591:
    old "I-I can't do that, I've never done it before! Not even when I was a porn actress!"
    new "我我做不到，我从来没做过这种事！ even when I was a porn actress! \n\n（注：最后一部分保持原文，因为是专有名词或特定情境下的表达。）"

translate chinese chinese_9131891_592:
    old "Well, I guess there's a first time for everything, am I right?"
    new "嗯，我想凡事都有第一次，对吧？"

translate chinese chinese_8636862_593:
    old "Of course you'll do it on video call with me so that I can record it."
    new "当然要通过视频通话给我做，这样我才能录下来。"

translate chinese chinese_5007898_594:
    old "We wouldn't want to waste that good material right?"
    new "我们可不想浪费了那好材料吧？"

translate chinese chinese_8814573_595:
    old "You're crazy if you think we'll do this!"
    new "如果你以为我们会这么做，那你真是疯了！"

translate chinese chinese_1133882_596:
    old "This is way too much! We're not doing anything!"
    new "这实在是太多了！我们什么都没做！"

translate chinese chinese_6336749_597:
    old "Aww, this again dude?"
    new "哎，这又是老一套了？"

translate chinese chinese_6268852_598:
    old "Come on [pla], don't you ever get bored of this routine? It really annoys me that you say no to everything I tell you to do."
    new "来吧[pla]，你难道不厌倦这种例行公事吗？你对我让你做的事情一律说不，这真的让我很烦。"

translate chinese chinese_9798784_599:
    old "Only to then turn around and do it anyway."
    new "结果还是那样做了。"

translate chinese chinese_6659599_600:
    old "It really tests my patience, so shut up and do it!"
    new "真他妈考验耐心，闭嘴赶紧做！"

translate chinese chinese_3056151_601:
    old "We're not doing anything!"
    new "我们什么都没做！"

translate chinese chinese_7323098_602:
    old "W- wait [pla]!"
    new "等一下 [pla]！"

translate chinese chinese_3110471_603:
    old "You know we have to do it. We have no choice."
    new "你知道我们必须这么做，没有选择的余地。"

translate chinese chinese_8019962_604:
    old "If what he has on us comes out we'll both be ruined!"
    new "如果他手里的把柄曝光了，我们俩就都完了！"

translate chinese chinese_3341013_605:
    old "No! Think about it!"
    new "别！想清楚！"

translate chinese chinese_4356242_606:
    old "What is it going to be next time?! He already made us do all those things! Next time he'll make us fuck in the principals office!"
    new "下次会怎么样?! 他已经让我们做了那些事！下次他会让我们在校长办公室做爱！"

translate chinese chinese_3025477_607:
    old "But we have to!"
    new "但我们必须得这样做！"

translate chinese chinese_1958268_608:
    old "No we don't, and I won't do anything!"
    new "我们没有，我也不会做任何事！"

translate chinese chinese_3991352_609:
    old "That so? Well, then I guess you leave me no choice."
    new "是吗？那我猜你没给我留什么选择余地了。"

translate chinese chinese_4938606_610:
    old "I suppose this was gonna happen anyway, I was already getting bored with you two."
    new "我想这迟早会发生，我早就对你们俩厌倦了。"

translate chinese chinese_0342599_611:
    old "Wait! Wait! Give us a minute, I can convince him!"
    new "等！等！给我们一分钟，我能说服他的！"

translate chinese chinese_6942188_612:
    old "You already heard him Mia, he's not gonna do anything."
    new "米娅，你已经听他说了，他不会做什么的。"

translate chinese chinese_5301319_613:
    old "So, I guess he's fine with me sending the information out."
    new "所以，我想他应该不介意我发送这些信息出去。"

translate chinese chinese_5773678_614:
    old "And that's what I will do, I'll send it straight to your school's principal."
    new "那我就这么办，直接发给你学校的校长。"

translate chinese chinese_1915308_615:
    old "I'll be eager to see how things pan out for you 'Ms.' Mia."
    new "我很期待看看你这位“小姐”米娅会有什么样的结局。"

translate chinese chinese_1466751_616:
    old "No, please don't' do this!"
    new "不，求你了，不要这样做！"

translate chinese chinese_2911984_617:
    old "I have to say it was an honor to be a student of Mia the pornstar."
    new "不得不说能成为 pornstar 米亚的学生是我的荣幸。"

translate chinese chinese_9976728_618:
    old "I bet that when things blow out, you'll get that job back in no time."
    new "我敢打赌，一旦事情爆发，你很快就能把那份工作拿回来。"

translate chinese chinese_3072815_619:
    old "And [pla], you see what you fucking did? I hope you're happy with that!"
    new "还有[pla]，你看你干的好事？希望你满意了！"

translate chinese chinese_6580621_620:
    old "Wait... Hello? Denzel?? Hello?"
    new "等一下……喂？丹泽尔？？喂？"

translate chinese chinese_6935054_621:
    old "Oh, no, no, no, no, no!"
    new "哦，不，不，不，不，不！"

translate chinese chinese_1701538_622:
    old "What the fuck you did [pla]! I have to call him again..."
    new "你到底干了什么[pla]！我得再给他打一次..."

translate chinese chinese_0614373_623:
    old "... Ringing... {w} Ringing..."
    new "... ringing... {w} ringing... \n\n（注：此处的\"ringing\"未翻译，因为可能是特定代码或效果名称。）"

translate chinese chinese_1965804_624:
    old "FUCK! HE DOESN'T ANSWER!"
    new "操！他根本不回应！"

translate chinese chinese_9101116_625:
    old "Oh my gosh! Why did you do that? You idiot!!"
    new "天啊！你干嘛这么做？笨蛋！！"

translate chinese chinese_8757633_626:
    old "Don't you care what will happen to you?! Or me?!"
    new "你不在乎你会怎么样吗？！还是我在乎？！"

translate chinese chinese_4689830_627:
    old "You said you wanted to help me, and this is what you do?!!"
    new "你说你要帮我，结果就是这么回事？！！"

translate chinese chinese_4446337_628:
    old "You fucking asshole! What are we going to do now?!"
    new "你这个混蛋！我们现在该怎么办？！"

translate chinese chinese_2904702_629:
    old "You know he was going to do this sooner or later. He's that type of bastard."
    new "你知道他早晚都会这么做的。他就是那种混账。"

translate chinese chinese_1302710_630:
    old "Well, he did it now! So what are we going to do?!"
    new "好了，他现在真是这么做了！那我们现在该怎么办？！"

translate chinese chinese_1764889_631:
    old "Calm down, listen, look, he kept talking about a mail."
    new "冷静点，听我说，他一直在提到一封邮件。"

translate chinese chinese_1479818_632:
    old "Which means he's gonna have to send it through some physical means, a cd or a usb."
    new "这意味着他得通过一些物理媒介发送，比如光盘或者U盘。"

translate chinese chinese_3922273_633:
    old "So?!"
    new "所以呢？!"

translate chinese chinese_3120638_634:
    old "So, all we have to do is intercept it before it arrives. Even if it's an express delivery, that's going to take a little while."
    new "所以，我们只需要在它到达前拦截就行了。即使是快递，也需要一点时间。"

translate chinese chinese_9642214_635:
    old "And then what? Even if we stop that, he still has copies!"
    new "然后呢？就算我们阻止了这个，他还有备份！"

translate chinese chinese_1466712_636:
    old "He could just send it to the police! Or the news! Or somewhere else!"
    new "他可以直接发给警察！或者新闻！或者其他地方！"

translate chinese chinese_1333320_637:
    old "Then what?!"
    new "那怎么办！"

translate chinese chinese_4019281_638:
    old "Ha, I've got a way to deal with that."
    new "哈，我有办法对付这个。"

translate chinese chinese_5813304_639:
    old "Listen, I'm going to need you to trust me on this, ok?"
    new "听着，这件事我需要你信任我，好吗？"

translate chinese chinese_7918149_640:
    old "If everything goes according to my plan, not only will everything remain a secret, you'll never have to worry about it ever again."
    new "如果一切按我的计划进行，不仅一切都会保密，你再也不用为此担心了。"

translate chinese chinese_9954381_641:
    old "What are you going to do?"
    new "你打算怎么办？"

translate chinese chinese_2676867_642:
    old "That... I can't tell you, but trust me, everything's going to be alright."
    new "那个……我不能告诉你，但相信我，一切都会好起来的。"

translate chinese chinese_0157298_643:
    old "All I have to do is go check if everything's ready."
    new "我只要去确认一下一切是否准备就绪。"

translate chinese chinese_1408647_644:
    old "What are you talking about? You're not making any sense!"
    new "你在说什么？你根本没说清楚！"

translate chinese chinese_9324975_645:
    old "I know you don't get it right now, but you'll see... Please just trust me."
    new "我知道你现在不明白，但你会看到的……请相信我。"

translate chinese chinese_6015551_646:
    old "I guess I have no choice..."
    new "我猜我没有选择……"

translate chinese chinese_0169337_647:
    old "For now, we have to deal with what Denzel's about to send to the school principal."
    new "现在，我们必须处理丹泽尔即将寄给校长的东西。"

translate chinese chinese_6310094_648:
    old "That's the priority."
    new "那是优先事项。"

translate chinese chinese_2596111_649:
    old "What do you propose then?"
    new "那你有什么建议？"

translate chinese chinese_4834687_650:
    old "I think we're gonna have to steal it."
    new "我觉得我们得偷它了。"

translate chinese chinese_8122489_651:
    old "For now just stay here and check if a delivery guy comes, I'll go to my house to check on things."
    new "先待在这里看看有没有送货的来，我去家里看看情况。"

translate chinese chinese_1192330_652:
    old "Again, what are you talking about?!"
    new "再说，你在说什么嘛？！"

translate chinese chinese_4181104_653:
    old "As I said, you'll understand later."
    new "像我说的，你会明白的。"

translate chinese chinese_7349094_654:
    old "But I really have to rush home, will you stay here and check if anything arrives?"
    new "但我真的得赶紧回家，你能留在这里看看有没有东西送来吗？"

translate chinese chinese_3686988_655:
    old "Yes, fine, I'll be here. You better know what you're doing."
    new "好吧，我会在这里。你最好知道自己在做什么。"

translate chinese chinese_8496727_656:
    old "I really think I do. I'll be back soon."
    new "我真的觉得我能行。我很快就会回来的。"

translate chinese chinese_3458102_657:
    old "I can't believe it, now everything depends on him..."
    new "真不敢相信，现在一切都取决于他了……"

translate chinese chinese_9456044_658:
    old "Hey! Linnet!"
    new "喂！林内特！"

translate chinese chinese_4383697_659:
    old "Oh, hi [pla]."
    new "哦，你好[pla]。"

translate chinese chinese_1136496_660:
    old "I'm going to need that spell of yours right now."
    new "我现在需要你的那个咒语。"

translate chinese chinese_9819536_661:
    old "Do you think we can use it?"
    new "你觉得我们可以用它吗？"

translate chinese chinese_7498435_662:
    old "No, we can't, this is a process [pla], and we can't just force it out. Sorry."
    new "不，我们不能，这是一步步的进程[pla]，我们不能强迫它。对不起。"

translate chinese chinese_2731929_663:
    old "Oh really?! Fuck I really need it now..."
    new "哦真的?! 见鬼，我现在真的需要它了..."

translate chinese chinese_5946365_664:
    old "When do you think we'll be able to do it?"
    new "你认为我们要什么时候才能做到呢？"

translate chinese chinese_1125888_665:
    old "Well, if I'm quick with this, tomorrow, I'll need another day."
    new "嗯，如果我快点搞定这个，明天我就又要一天了。"

translate chinese chinese_9047573_666:
    old "Hmm... Are you sure it'll be ready tomorrow?"
    new "嗯……你确定明天能准备好？"

translate chinese chinese_5864047_667:
    old "Yeah, it'll be difficult, but I can make it."
    new "嗯，这会很难，但我能做到。"

translate chinese chinese_2043923_668:
    old "Ok, then I guess we'll have to find a way to make it tomorrow."
    new "好吧，那看来我们得想办法放到明天了。"

translate chinese chinese_4720640_669:
    old "Please help me with that, I really need it as soon as possible."
    new "请帮帮我，我真的很需要，越快越好。"

translate chinese chinese_8339822_670:
    old "Ok then I will continue working on the spell."
    new "好的，那我就继续研究这个咒语。"

translate chinese chinese_9628554_671:
    old "Hey, what happened? I have been waiting for you... Did you get what you need? Is everything solved?"
    new "嘿，发生什么事了？我一直在等你……你拿到你需要的东西了吗？一切都解决了吗？"

translate chinese chinese_0312280_672:
    old "Hmm, n-not really."
    new "嗯，不算是。"

translate chinese chinese_1224729_673:
    old "It's almost ready, but it's still going to take a little while."
    new "差不多好了，但还需要一点时间。"

translate chinese chinese_6101666_674:
    old "At least until tomorrow."
    new "至少到明天吧。"

translate chinese chinese_0851105_675:
    old "I still don't understand, what's going to take until tomorrow?"
    new "我还是不明白，什么要拖到明天？"

translate chinese chinese_7459067_676:
    old "Just trust me. After tomorrow everything will be solved."
    new "你就信我一次吧。明天之后一切都会解决的。"

translate chinese chinese_7474443_677:
    old "Are you going to kill Denzel?"
    new "你要杀掉丹泽尔吗？"

translate chinese chinese_6651347_678:
    old "What?! No! How can you think something like that?"
    new "什么?! 不！你怎么能这么想？"

translate chinese chinese_8240351_679:
    old "Just relax. You'll get it tomorrow.."
    new "放松点。你明天就会得到的。。"

translate chinese chinese_1950133_680:
    old "But we're gonna have to deal with the delivery."
    new "但我们得处理送货的事。"

translate chinese chinese_8769619_681:
    old "We have to find a way to steal away what Denzel sent today."
    new "我们必须想办法偷走丹泽尔今天送的东西。"

translate chinese chinese_2484858_682:
    old "So that the principal won't see them."
    new "以免校长看到他们。"

translate chinese chinese_8710237_683:
    old "Well, she's already gone home. So even if it arrives today, she won't see it until tomorrow."
    new "好吧，她已经回家了。所以就算今天送到，她也要明天才能看到。"

translate chinese chinese_0393943_684:
    old "Ok, so I suppose we'll have to steal it tomorrow before she sees it."
    new "好吧，那我想我们得明天在她看到之前把它偷走。"

translate chinese chinese_5111144_685:
    old "We'll have to arrive very early. Before she does."
    new "我们必须很早到达，在她之前。"

translate chinese chinese_6017895_686:
    old "After that everything will be fine."
    new "那样的话一切都会好起来的。"

translate chinese chinese_9186407_687:
    old "It will? But what are you going to do?"
    new "会吗？那你打算怎么办？"

translate chinese chinese_2691483_688:
    old "I just can't tell you."
    new "我就是不能告诉你。"

translate chinese chinese_5352731_689:
    old "Damn, ok, whatever. You better make whatever you do really work..."
    new "妈的，好吧，随你了。你最好让你做的事情见鬼的有效……"

translate chinese chinese_7277283_690:
    old "Don't worry."
    new "别担心。"

translate chinese chinese_6377286_691:
    old "So, we'll meet here tomorrow?"
    new "所以，我们明天在这里见面？"

translate chinese chinese_5220885_692:
    old "Yeah, before classes."
    new "对，上课前。"

translate chinese chinese_1001218_693:
    old "Ok, that's it then. Don't be late."
    new "好吧，那就这样了。别迟到。"

translate chinese chinese_6990605_694:
    old "Of course not."
    new "当然不是。"

translate chinese chinese_7420346_695:
    old "All right, see you tomorrow then."
    new "好吧，那明天见。"

translate chinese chinese_7673774_696:
    old "Ok, don't worry tomorrow this will all be over."
    new "好吧，别担心，明天这一切就都结束了。"

translate chinese chinese_0636523_697:
    old "Hi, Ms. Mia."
    new "嗨，米娅女士。"

translate chinese chinese_7797869_698:
    old "At this point I think just Mia's fine."
    new "到这地步，我觉得只要米娅在就行了。"

translate chinese chinese_1714518_699:
    old "Ok, so I came in very early to check that the coast is clear."
    new "好的，我来得很早，确认周围没人。"

translate chinese chinese_6756484_700:
    old "Nobody's around."
    new "周围没人。"

translate chinese chinese_5517485_701:
    old "That's perfect, so we should be able to get it with no problem."
    new "那太完美了，我们应该能轻松搞定。"

translate chinese chinese_9984026_702:
    old "Ok, let's go, we need to check out the principal's office."
    new "好吧，我们走吧，得去校长办公室看看。"

translate chinese chinese_5425997_703:
    old "Have you found anything?"
    new "找到什么了吗？"

translate chinese chinese_0568866_704:
    old "Nothing, everything look's fine."
    new "没事，一切都看起来挺好的。"

translate chinese chinese_2936482_705:
    old "Hmm, there must be something."
    new "嗯，肯定有什么原因。"

translate chinese chinese_7054169_706:
    old "Ah, that must be it."
    new "啊，那肯定是了。"

translate chinese chinese_7031452_707:
    old "Why else would there be a CD on her desk?"
    new "否则她的桌子上怎么会有一张CD？"

translate chinese chinese_2794490_708:
    old "Yeah, you're probably right. It must've arrived during the evening and the janitor put it here."
    new "嗯，你说得对。肯定是晚上送来的，然后清洁工把它放这儿了。"

translate chinese chinese_0196926_709:
    old "Ok, so what do we do now?"
    new "好吧，那我们现在做什么？"

translate chinese chinese_1738243_710:
    old "What we have to do is just..."
    new "我们得做的是……"

translate chinese chinese_3604435_711:
    old "Wait! I just heard something! I think someone's coming."
    new "等一下！我刚刚听到什么了！我觉得有人来了。"

translate chinese chinese_6892489_712:
    old "Quick get in that closet."
    new "快进那个衣柜。"

translate chinese chinese_6932330_713:
    old "What are we going to do?"
    new "我们该怎么办？"

translate chinese chinese_4126581_714:
    old "Shhhh, someone's coming, they'll hear us."
    new "嘘，有人来了，他们会听到的。"

translate chinese chinese_8178647_715:
    old "Ok, I see some correspondence arrived yesterday. What do we have here?"
    new "好的，我看到昨天有一些信件来了。我们来看看有什么？"

translate chinese chinese_0654879_716:
    old "Oh! Not the auditing process again!"
    new "哦！别又是审计过程！"

translate chinese chinese_5136129_717:
    old "The day just started and it's already ruined, everytime they do it we have to jump through so many hurdles."
    new "一天才开始就这么糟糕了，每次他们这么搞，我们都得克服这么多困难。"

translate chinese chinese_5130425_718:
    old "{i}*Sigh*{/i} I guess there's nothing to do, I'll just deal with it."
    new "{i}*叹气*{/i} 算了，没什么好做的，我就应付一下吧。"

translate chinese chinese_6165638_719:
    old "But first..."
    new "但是首先..."

translate chinese chinese_0944704_720:
    old "Nothing wrong with dealing with some stress early before work."
    new "工作前早点缓解一下压力没什么不对。"

translate chinese chinese_1265164_721:
    old "I don't usually do this here at the office, but what the hell."
    new "我平时不在办公室这么做，但管它呢。"

translate chinese chinese_0173624_722:
    old "It's been quite a while, I think it will be fun."
    new "已经有一段时间了，我觉得会很有趣。"

translate chinese chinese_3398823_723:
    old "What the hell? Do you actually have a boner right now?"
    new "搞什么？你现在真的硬了吗？"

translate chinese chinese_5734619_724:
    old "S- sorry, I just can't help it."
    new "对不起，我就是控制不住。"

translate chinese chinese_2592191_725:
    old "It's not my intention."
    new "这可不是我的本意。"

translate chinese chinese_6068839_726:
    old "Ugh, you're incredible, I can't believe you."
    new "哎，你真是够了，我简直不敢相信你。"

translate chinese chinese_8495082_727:
    old "Mmm, oh yeah, this is just what I needed."
    new "嗯，对啊，这就是我需要的。"

translate chinese chinese_0432241_728:
    old "Oh! It's so good!"
    new "哦！真好吃！"

translate chinese chinese_4333230_729:
    old "That's it, yeah, yeah."
    new "就是这个，嗯嗯。"

translate chinese chinese_3828279_730:
    old "Wow, she is..."
    new "wow, 她是..."

translate chinese chinese_9373843_731:
    old "Shhh..."
    new "嘘..."

translate chinese chinese_0351026_732:
    old "W-what are you doing?"
    new "你干什么？"

translate chinese chinese_1151252_733:
    old "Shhh, be quiet, she'll find us if you keep talking."
    new "嘘，安静点，你再说话她会找到我们的。"

translate chinese chinese_7314094_734:
    old "But you're- ..."
    new "但是你……"

translate chinese chinese_1118201_735:
    old "Shhh, just shut up!"
    new "嘘，闭嘴！"

translate chinese chinese_4305688_736:
    old "Fantastic!"
    new "太棒了！"

translate chinese chinese_1799631_737:
    old "But I better go check on things around the school before the students arrive."
    new "但我还是先去学校看看情况吧，学生就要来了。"

translate chinese chinese_8698514_738:
    old "Mmm! Oh! Oh yeah!"
    new "嗯！哦！哦 yeah！"

translate chinese chinese_9276870_739:
    old "Hmm, M-Mia, the principal just left."
    new "嗯，米娅，校长刚离开。"

translate chinese chinese_6921500_740:
    old "I think we better get out of here before she or anybody else comes back."
    new "我觉得我们最好在她或其他人回来之前离开这里。"

translate chinese chinese_5478529_741:
    old "Uh, what? Oh yeah!"
    new "啊，什么？哦，对了！"

translate chinese chinese_9287414_742:
    old "You're right, l- let's get out of here."
    new "你说得对，咱们走吧。"

translate chinese chinese_4277724_743:
    old "Ok, we have to go then, we can't keep wasting any more time here."
    new "好吧，那我们就走吧，不能再浪费时间了。"

translate chinese chinese_2500973_744:
    old "Yeah, I guess you're right, don't forget to bring the CD."
    new "嗯，我想你是对的，别忘了带CD。"

translate chinese chinese_9275903_745:
    old "Phew, it's good that we made it."
    new "呼，还好我们赶到了。"

translate chinese chinese_9633891_746:
    old "I can't believe we almost got caught. Hehe, right?"
    new "真不敢相信我们差点被发现了。嘿嘿，对吧？"

translate chinese chinese_1045467_747:
    old "Eh, yeah, you're right haha, that was close, phew!"
    new "eh, 对啊，你没错 哈哈，那真是险呢，呼！"

translate chinese chinese_1388518_748:
    old "What now then?"
    new "那现在怎么办？"

translate chinese chinese_6407647_749:
    old "Well, we're relieved, but we're not sure if this really is what we were looking for."
    new "我们是松了口气，但不确定这是否真的是我们要找的。"

translate chinese chinese_9010531_750:
    old "So we better check in the computer to see if it is."
    new "所以我们最好检查一下电脑看看是不是这样。"

translate chinese chinese_5244501_751:
    old "Yeah, you're right, we should check."
    new "嗯，你说得对，我们应该去看看。"

translate chinese chinese_1471229_752:
    old "That's very weird, there only seems to be a single video."
    new "这很奇怪，好像只有一个视频。"

translate chinese chinese_5486335_753:
    old "Nothing else."
    new "没有别的了。"

translate chinese chinese_2512455_754:
    old "Well, open it, we need to see if it is."
    new "好吧，打开看看吧。"

translate chinese chinese_3825344_755:
    old "Woah! I wasn't expecting that."
    new "哇！我没想到会这样。"

translate chinese chinese_8035499_756:
    old "Oh my god! It is."
    new "天啊！真的是的。"

translate chinese chinese_1323546_757:
    old "I can't believe he actually found something."
    new "真不敢相信他真的找到了什么东西。"

translate chinese chinese_7007907_758:
    old "It seems the producers didn't get rid of everything as I wanted them to."
    new "看来制作人并没有把我想要删掉的东西全部去掉。"

translate chinese chinese_7470696_759:
    old "How did Denzel get his hands on this?"
    new "Denzel是怎么搞到这个的？"

translate chinese chinese_0731551_760:
    old "I need to see you both in my office."
    new "我需要你们俩到我的办公室来。"

translate chinese chinese_0653793_761:
    old "So come to my office as soon as you're done working on whatever it is you're working on that computer."
    new "所以等你那台电脑上的事情弄完了就来我办公室。"

translate chinese chinese_7873015_762:
    old "W-what? Why does she want to see us there?"
    new "什、什么？她为什么想在那里见我们？"

translate chinese chinese_8419972_763:
    old "Oh no, she found out we were there, or maybe Denzel sent her another thing!"
    new "哦不，她发现我们在那里了，或者可能是丹泽尔又给她发了些什么！"

translate chinese chinese_3158904_764:
    old "Calm down, calm down, there's no reason why she would know we were in her office."
    new "冷静点，冷静点，根本没有理由认为她会知道我们在她的办公室里。"

translate chinese chinese_6860988_765:
    old "And why would Denzel send her another CD?"
    new "而且丹泽尔为什么要再送她一张CD？"

translate chinese chinese_3901145_766:
    old "Then what do you think she wants to talk to us about?"
    new "那你觉得她想和我们聊什么？"

translate chinese chinese_6899962_767:
    old "I guess we have to talk to her."
    new "看来我们得跟她谈谈。"

translate chinese chinese_0657178_768:
    old "{i}*Sigh*{/i} Ok, let's go then, I guess we'll have to see."
    new "{i}*叹气*{/i} 好吧，那我们就去吧，看看情况吧。"

translate chinese chinese_4719196_769:
    old "Why aren't you walking?"
    new "你为什么不动呢？"

translate chinese chinese_1347628_770:
    old "Hmm, the thing is, I-I kinda can't right now."
    new "嗯，其实，我我现在有点做不到。"

translate chinese chinese_4538243_771:
    old "Why not?"
    new "为什么不行？"

translate chinese chinese_4559090_772:
    old "Uhhh...I just need a few minutes... I mean after I watched your video."
    new "呃……我只需要几分钟……我是说在看完你的视频之后。"

translate chinese chinese_9189315_773:
    old "You're really unbelievable, you know?! I can't believe you actually got a boner from that!"
    new "你真是够了啊！我不敢相信你竟然硬起来了！"

translate chinese chinese_7660463_774:
    old "Well, I'm still a man, you know? It's not like I want to go around with a boner."
    new "好吧，我毕竟还是个男人，你知道？我不可能整天都硬着吧。"

translate chinese chinese_4155892_775:
    old "Ugh, shut up. Just get rid of it, will you?"
    new "哎呀，闭嘴吧。 just get rid of it, will you? 废话少说，赶紧处理掉吧？"

translate chinese chinese_2951928_776:
    old "Get rid of it? How?"
    new "处理掉它？怎么弄？"

translate chinese chinese_8494620_777:
    old "How do you think genius? Jerk off!"
    new "你怎么想的呢？自渎一下吧！"

translate chinese chinese_3988944_778:
    old "And do it quickly the principal is waiting for us."
    new "而且要快点，校长在等我们。"

translate chinese chinese_3585768_779:
    old "I don't think that will work, I mean, I'm very nervous, and I just don't have my mind in it."
    new "我觉得这行不通，我的意思是，我非常紧张，根本无法集中精力。"

translate chinese chinese_1576041_780:
    old "I just can't believe this."
    new "我真是不敢相信这件事。"

translate chinese chinese_9393625_781:
    old "Ughh... We have to do it now before he comes back..."
    new "呃……我们必须在他回来之前赶紧做……"

translate chinese chinese_4726809_782:
    old "Just give me a couple of minutes..."
    new "就给我几分钟..."

translate chinese chinese_4052607_783:
    old "Hmm, you know what, I'll do it then."
    new "嗯，你知道吗，那我来吧。"

translate chinese chinese_9741363_784:
    old "What do you think genius? I'm making you cum."
    new "你觉得呢，天才？我让你高潮。"

translate chinese chinese_1134499_785:
    old "We can't take too much time, the principal is waiting for us."
    new "我们不能花太多时间，校长还在等我们。"

translate chinese chinese_6926750_786:
    old "And since you can't do it yourself, I guess I'll have to do it for you."
    new "既然你自己做不到，看来只好我来帮你了。"

translate chinese chinese_6497679_787:
    old "Come on [pla], it's not something we haven't done before, just focus on finishing quickly."
    new "来吧[pla]，这也不是我们没做过的事，just focus on finishing quickly."

translate chinese chinese_5010011_788:
    old "You took a while to come..."
    new "你来得好晚啊……"

translate chinese chinese_9843343_789:
    old "Ah, yeah, sorry. We didn't mean to."
    new "啊，对，对不起。我们不是故意的。"

translate chinese chinese_7192512_790:
    old "It's just that the... thing we were doing took a little longer than expected."
    new "就是说，那个……我们做的事情花了比预期更长的时间。"

translate chinese chinese_6829632_791:
    old "Ok, listen up. Mia, last week you gave me a report..."
    new "好了，听好了。米娅，上周你给我了一份报告..."

translate chinese chinese_4011349_792:
    old "In which [pla] appeared as someone to pay attention to because he wasn't performing up to the standards of the school. Right?"
    new "在哪个[pla]因为表现不符合学校的标准而引起了注意的情节里。对吧？"

translate chinese chinese_3976999_793:
    old "Y-yeah, that's right. Is there a problem with it ma'am?"
    new "嗯，对。有什么问题吗，女士？"

translate chinese chinese_3894950_794:
    old "Not per se, after all, there's nothing unusual about a student needing to improve his grades."
    new "也不是，毕竟一个学生需要提高成绩也没什么不正常的。"

translate chinese chinese_4775371_795:
    old "The problem is that this morning I received a letter informing me we're about to be audited by the superintendent."
    new "问题是今天早上我收到了一封信，说我们要被校长审计了。"

translate chinese chinese_7011896_796:
    old "And it would be very good for us if we don't have a student about to be expelled due to his poor performance."
    new "如果我们没有一个因为表现差而即将被开除的学生，那就太好了。"

translate chinese chinese_4707242_797:
    old "So, Mia, I normally wouldn't do this, but I need you to start helping him personally with his studies."
    new "所以，米娅，我平时不会这么做的，但我要你亲自帮他学习。"

translate chinese chinese_7550378_798:
    old "Sorry? Do you want me to tutor him? Personally?"
    new "抱歉？你是想让我辅导他吗？亲自辅导？"

translate chinese chinese_7926095_799:
    old "Exactly, think of it as extra classes for him. It must be done."
    new "没错，就当是给他上的额外课程吧。这事必须得做。"

translate chinese chinese_1049523_800:
    old "We can't have any bad marks for the school qualification."
    new "我们不能在学校考核中留下任何差评。"

translate chinese chinese_8630717_801:
    old "I see, great."
    new "我明白了，太好了。"

translate chinese chinese_3191314_802:
    old "Great?"
    new "很好？"

translate chinese chinese_3336576_803:
    old "Uh, I mean, I think it's great that we can get a good score just by doing that."
    new "呃，我的意思是，我觉得我们只要那样做就能得到好成绩挺不错的。"

translate chinese chinese_5433553_804:
    old "Actually ma'am, [pla]'s notes have been getting a lot better recently."
    new "实际上，女士，[pla]的笔记最近进步了很多。"

translate chinese chinese_2668606_805:
    old "I'm sure that his grades will be on par with everyone else's when the auditing starts."
    new "我相信等审计开始的时候，他的成绩会和其他人一样。"

translate chinese chinese_5202539_806:
    old "Well, that's great to hear. I trust you have this Mia."
    new "嗯，听到这个很高兴。我相信你搞定Mia没问题。"

translate chinese chinese_5814620_807:
    old "Now, I'm very busy, so you two can go back to class."
    new "好了，我还有很多事情要忙，你们两个回教室去吧。"

translate chinese chinese_2700787_808:
    old "Sure ma'am. Thank you."
    new "好的，谢谢。"

translate chinese chinese_3922931_809:
    old "{i}*Sigh*{/i} Oh my god, that was very close."
    new "{i}*叹气*{/i} 哇，那真是太危险了。"

translate chinese chinese_3880710_810:
    old "I thought we were done for. I was sure she had received another copy of the video from Denzel or something."
    new "我还以为这次完了呢。我还以为她从丹泽尔那里又收到了那段视频的副本。"

translate chinese chinese_8419738_811:
    old "Yeah, me too, I'm glad we managed to avoid the trouble."
    new "是啊，我也很高兴我们成功避开了麻烦。"

translate chinese chinese_9942540_812:
    old "Well, that was just the start of it, we still have to deal with Denzel."
    new "好吧，那只是开始，我们还得对付丹泽尔。"

translate chinese chinese_3283687_813:
    old "Which by the way, you still haven't told me anything about how you plan on doing that."
    new "话说，你还没告诉我你打算怎么去做呢。"

translate chinese chinese_2586933_814:
    old "It's ok, it should be ready by now, I think I just have to go handle that."
    new "没事，现在应该好了，我想我只需要去处理一下就行了。"

translate chinese chinese_7145695_815:
    old "Ready? What do you mean by that?"
    new "准备好了？你这话是什么意思？"

translate chinese chinese_1729201_816:
    old "Don't think too much about it."
    new "别想太多。"

translate chinese chinese_9660979_817:
    old "You just have to know that by this afternoon not only will we have dealt with Denzel."
    new "你只需要知道，今天下午不仅我们会处理掉丹泽尔。"

translate chinese chinese_8061095_818:
    old "There's going to be no way of him or anyone else using anything from your past to try and hurt you."
    new "不会再有任何机会让他或者别人利用你的过去来伤害你。"

translate chinese chinese_0711514_819:
    old "You make it sound so easy."
    new "你听起来好像很简单的样子。"

translate chinese chinese_4621096_820:
    old "But you seem to be very confident about this. So, I'll trust you."
    new "但你看起来对此非常有信心。所以，我相信你。"

translate chinese chinese_7390296_821:
    old "But wait, will you look for me to tell me if whatever it is you plan on doing works?"
    new "但是等一下，你会来找我告诉我你的计划是否成功吗？"

translate chinese chinese_4950124_822:
    old "Sure, you just focus on getting rid of that CD with your video on it."
    new "行吧，你只要把那张有你视频的光盘处理掉就行了。"

translate chinese chinese_4930460_823:
    old "And I'll handle the rest."
    new "剩下的我来处理。"

translate chinese chinese_6200242_824:
    old "Ok, whatever you say."
    new "好吧，随你了。"

translate chinese chinese_0690997_825:
    old "Thank you, I have to go, I'll see you later."
    new "谢谢，我得走了，待会儿见。"

translate chinese chinese_8007260_826:
    old "Hey! Hey! Linett! Are you ready?"
    new "喂！喂！林内特！准备好了吗？"

translate chinese chinese_1198293_827:
    old "I need to know if the spell's ready to be used!"
    new "我需要知道那个咒语是否已经准备好了！"

translate chinese chinese_4409278_828:
    old "Hi [pla]! Yeah, you're right on time, I just finished it."
    new "嗨 [pla]！没错，你正好赶上，我刚做完。"

translate chinese chinese_3560714_829:
    old "The spell's ready, so we can now use the SexNote to conjure it."
    new "咒语准备好了，我们现在可以使用SexNote来召唤它。"

translate chinese chinese_8632683_830:
    old "That's great, so what do we do?"
    new "那太好了，那我们接下来做什么？"

translate chinese chinese_1435710_831:
    old "The hard work was already done by me, by focusing the magic power on the person you told me about."
    new "艰苦的工作我已经完成了，我把魔力集中在了你告诉我的那个人身上。"

translate chinese chinese_6047389_832:
    old "And limiting the reach of the spell."
    new "还有限制咒语的范围。"

translate chinese chinese_1318702_833:
    old "All you have to do is read it from the SexNote, and it will be cast."
    new "你只需要从SexNote上念出来，就能生效了。"

translate chinese chinese_9093794_834:
    old "Ok, that's very simple, can we do it now?"
    new "好的，这个很简单，我们现在就开始吧？"

translate chinese chinese_1893195_835:
    old "Sure, it should have already appeared in the SexNote, so you just have to read it, and that's it."
    new "行吧，应该已经在SexNote里了，你只要看了就行。"

translate chinese chinese_8945138_836:
    old "You're right! Is there!"
    new "你说得对！确实有！"

translate chinese chinese_5636509_837:
    old "So, all I have to do is read it?"
    new "所以，我只要读一下就行了？"

translate chinese chinese_7628795_838:
    old "That's it."
    new "就是这么回事。"

translate chinese chinese_0062669_839:
    old "Ok, here it goes."
    new "好吧，来了。"

translate chinese chinese_6518288_840:
    old "Elementum recolligo Huic Commodo locus mihi vestri vox."
    new "Elementum recolligo Huic Commodo locus mihi vestri vox."

translate chinese chinese_6542708_841:
    old "Venire ventus venire, sinere solus sentire relaxari."
    new "Venire ventus venire, sinere solus sentire relaxari."

translate chinese chinese_1553556_842:
    old "I-I think it's starting to take effect!"
    new "我我觉得开始起作用了！"

translate chinese chinese_0255092_843:
    old "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"
    new "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"

translate chinese chinese_0021289_844:
    old "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"
    new "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"

translate chinese chinese_2365318_845:
    old "What's happening?!!"
    new "发生什么事了!!"

translate chinese chinese_2623222_846:
    old "Where am I?! What's this place?!"
    new "我在哪儿?! 这是什么地方?!"

translate chinese chinese_8621171_847:
    old "What the hell?! What's this?"
    new "什么鬼？这是什么？"

translate chinese chinese_8136578_848:
    old "Where are we Linett?"
    new "我们在哪儿，林nett？"

translate chinese chinese_5725568_849:
    old "Hmmm, it seems something went awry with the spell..."
    new "嗯，看来这个咒语出问题了……"

translate chinese chinese_5685494_850:
    old "What?! Can we fix it? What happened and where are we?!"
    new "什么?! 能修好吗? 发生了什么? 我们在哪?!"

translate chinese chinese_6359573_851:
    old "I don't know, I think we'll just have to wait."
    new "我不知道，我觉得我们只能等了。"

translate chinese chinese_8878047_852:
    old "W- what?..."
    new "什、什么？..."

translate chinese chinese_1165304_853:
    old "Oh wow, you look like another person now!"
    new "哦 wow，你现在看起来完全不一样了！"

translate chinese chinese_6573023_854:
    old "The fuck is happening Linett?!"
    new "林奈特，到底发生了什么！"

translate chinese chinese_0311207_855:
    old "Well, I told you, something went awry, apparently the energy is fluctuating..."
    new "好吧，我跟你说过，出了些问题，看来能量在波动……"

translate chinese chinese_8525308_856:
    old "I don't know what that means!"
    new "我不知道那是什么意思！"

translate chinese chinese_4889992_857:
    old "Wait, we're back to normal."
    new "等下，我们恢复正常了。"

translate chinese chinese_7863529_858:
    old "What was that all about Linett? Was there something wrong with the spell?"
    new "林奈特，那到底是怎么回事？那个咒语有什么问题吗？"

translate chinese chinese_0663531_859:
    old "It could be, but I don't think so. I think it has more to do with all of the power that it takes to call the spell."
    new "可能是这样，但我不这么认为。我觉得这更多是因为召唤这个咒语需要耗费大量的力量。"

translate chinese chinese_2056407_860:
    old "All of that energy must've caused a tear in our reality that connected us to another one."
    new "所有那些能量肯定导致了现实的裂缝，把我们连接到了另一个世界。"

translate chinese chinese_5281852_861:
    old "The energy probably began to flow into the tear, and that made things begin switching places between the two realities."
    new "能量很可能开始流入裂缝，这导致两个现实之间的事物开始互换位置。"

translate chinese chinese_9179266_862:
    old "Uh, sure..."
    new "呃，好吧……"

translate chinese chinese_2041400_863:
    old "But what does that mean? Is everything alright?"
    new "但是那是什么意思？一切都好吗？"

translate chinese chinese_3183206_864:
    old "There shouldn't be any problem, things must've stabilized after you finished the spell."
    new "没问题的，你念完咒语后情况肯定已经稳定下来了。"

translate chinese chinese_0754724_865:
    old "The person you wanted to be forgotten is no longer in the mind of the bad human."
    new "你想被遗忘的人已经不再存在于那个坏人的脑海中了。"

translate chinese chinese_5559043_866:
    old "Also, every single trace of her presence has been removed."
    new "而且，她存在的每一丝痕迹都被清除了。"

translate chinese chinese_5436724_867:
    old "Does that mean no more videos or pictures of anything?"
    new "那是不是意味着再没有视频或照片了？"

translate chinese chinese_3779094_868:
    old "Everything has been removed [pla]."
    new "一切都被移除了[pla]。"

translate chinese chinese_5860172_869:
    old "Great! That's awesome, thanks Linett!"
    new "太好了！太棒了，谢谢你，林奈特！"

translate chinese chinese_6472231_870:
    old "I'm happy to help you [pla], after all, you've done a lot for me and the other shinigamis."
    new "我很乐意帮你[pla]，毕竟你为我们和其他死神做了很多。"

translate chinese chinese_9061353_871:
    old "I'll go and talk to Mia right now!"
    new "我现在就去和米娅谈谈！"

translate chinese chinese_8431464_872:
    old "Mia! Hey! It's done!"
    new "米娅！嘿！搞定了！"

translate chinese chinese_7786724_873:
    old "What are you talking about? What's done?"
    new "你在说什么？什么事做了？"

translate chinese chinese_5973469_874:
    old "You just have to know that I already took care of your problem with Denzel."
    new "你只需要知道，我已经处理了你和丹泽尔之间的问题。"

translate chinese chinese_0977490_875:
    old "He won't bother you any longer, there are no more videos or pictures or anything!"
    new "他不会再烦你了，没有更多的视频或照片或其他东西了！"

translate chinese chinese_1772102_876:
    old "Uh- I mean, I think that's good, but what about him? He can just go to the press and talk about me."
    new "呃——我的意思是，我觉得那样挺好的，但他要是去找媒体说我怎么办？"

translate chinese chinese_0118638_877:
    old "Don't worry about that either, he won't even remember you, trust me."
    new "这个你也不用担心，他根本就不会记得你，相信我。"

translate chinese chinese_9808644_878:
    old "What do you mean he won't even remember me?"
    new "你说他连我都不记得了是什么意思？"

translate chinese chinese_5161273_879:
    old "You know what? Let's check it, why don't you call him?"
    new "你知道吗？咱们查查看，你为什么不给他打个电话？"

translate chinese chinese_3234676_880:
    old "Now I really think you have gone insane. Call him?"
    new "现在我真的觉得你疯了。给他打电话？"

translate chinese chinese_9182343_881:
    old "Just trust me, everything will be fine."
    new "相信我，一切都会好的。"

translate chinese chinese_2620218_882:
    old "I guess we can try."
    new "我想我们可以试试。"

translate chinese chinese_9045255_883:
    old "Yeah, don't worry."
    new "嗯，别担心。"

translate chinese chinese_7682769_884:
    old "Hello, who is this? I don't recognize the number."
    new "喂，你是谁啊？我不认识这个号码。"

translate chinese chinese_2090742_885:
    old "Wh-?!"
    new "啥？！"

translate chinese chinese_1428616_886:
    old "Denzel? It's me, Mia... Uhh... from the school...."
    new "丹泽尔？我是米娅……呃……来自学校的……"

translate chinese chinese_2610086_887:
    old "Listen, I don't know who you are, if you think you can scam me you better think twice!"
    new "听着，我不知道你是谁，如果你以为能骗过我，那就再好好想想吧！"

translate chinese chinese_9764033_888:
    old "What? No! I mean..."
    new "什么？不！我的意思是..."

translate chinese chinese_3830045_889:
    old "Hello? Helloo?..."
    new "喂？喂喂？..."

translate chinese chinese_8161294_890:
    old "He hung up, he said he didn't know who I was..."
    new "他挂了电话，说他不知道我是谁……"

translate chinese chinese_5713520_891:
    old "See?"
    new "看到了吧？"

translate chinese chinese_9535952_892:
    old "What did you do?"
    new "你做了什么？"

translate chinese chinese_9350025_893:
    old "I'm sorry but I can't tell you that, all that matters is that with that your problem should be taken care of."
    new "对不起，这个我不能告诉你，重要的是你的问题应该解决了。"

translate chinese chinese_1823913_894:
    old "I mean, I guess it is, but this is very odd."
    new "我的意思是，也许它是，但这真的很奇怪。"

translate chinese chinese_9466308_895:
    old "Listen, all you have to do is trust me, ok?"
    new "听着，你只需要信任我就好了，好吗？"

translate chinese chinese_4789977_896:
    old "If you think it'll make you feel any safer, why don't we both go tomorrow to the principal's office again?"
    new "如果你觉得这样会更安全的话，我们明天再去一次校长办公室怎么样？"

translate chinese chinese_3489524_897:
    old "That way we can check if everything will be in order."
    new "这样我们可以检查一下一切是否就绪。"

translate chinese chinese_8539086_898:
    old "Ok, let's do as you say."
    new "好吧，按你说的做。"

translate chinese chinese_5653378_899:
    old "Great, then I'll see you tomorrow."
    new "好的，那明天见。"

translate chinese chinese_8647232_900:
    old "I don't know what you did, but thank you."
    new "我不知道你做了什么，但谢谢你。"

translate chinese chinese_8937593_901:
    old "Oh, Belle, hi!"
    new "哦，贝儿，你好！"

translate chinese chinese_0432838_902:
    old "What are you doing here so early?"
    new "你这么早来这里干什么？"

translate chinese chinese_0093087_903:
    old "Hi [pla] good morning."
    new "你好，[pla]，早上好。"

translate chinese chinese_3511013_904:
    old "I just came because Miss Lucy asked me, I'm helping her with a group project."
    new "我来是因为露西小姐让我来的，我在帮她做一个小组项目。"

translate chinese chinese_1519358_905:
    old "Miss Lucy? Who's that? Like a new teacher?"
    new "卢西小姐？是谁啊？新老师吗？"

translate chinese chinese_4566218_906:
    old "What? Are you messing with me? Of course, you know Ms Lucy, our teacher."
    new "什么？你在逗我吗？当然认识卢西老师。"

translate chinese chinese_6848919_907:
    old "Who?!"
    new "谁啊！？"

translate chinese chinese_6681927_908:
    old "I mean, I know you two don't like each other [pla] but this is a little childish for you."
    new "我的意思是，我知道你们俩不喜欢对方[pla]但这对你来说有点太孩子气了。"

translate chinese chinese_7333863_909:
    old "What? I really don't know who she is!"
    new "什么？我真的不知道她是谁！"

translate chinese chinese_7428743_910:
    old "I have no idea what you're talking about."
    new "我不知道你在说什么。"

translate chinese chinese_9671398_911:
    old "Hi Belle, how are you today sweetheart?"
    new "嗨，贝儿，今天怎么样，甜心？"

translate chinese chinese_3164510_912:
    old "Hmph, what are you doing here so early [pla]? I hope you're not planning anything stupid."
    new "哼，[pla]，你这么早来这里干什么？希望你没打算搞什么蠢事。"

translate chinese chinese_9326400_913:
    old "I also hope you won't corrupt Belle, your are bad influence!"
    new "我也希望你别把贝儿带坏，你真是个不好的影响！"

translate chinese chinese_0477839_914:
    old "And you Belle, you need better friends."
    new "还有你，贝尔，你需要一些更好的朋友。"

translate chinese chinese_6203000_915:
    old "... (What the fuck?)"
    new "...（什么鬼？）"

translate chinese chinese_8376282_916:
    old "Well, see you later in class. Belle, come with me."
    new "好吧，那下节课见。贝尔，跟我来。"

translate chinese chinese_7485289_917:
    old "Sorry [pla], see you later!"
    new "对不起[pla]，回头见！"

translate chinese chinese_1709301_918:
    old "What te fuck? What is happening?"
    new "什么情况？发生什么事了？"

translate chinese chinese_5942151_919:
    old "[pla]! What the hell did you do?!"
    new "[pla]！你到底做了什么！"

translate chinese chinese_8768138_920:
    old "I mean, as I said, I thought I had fixed the issue. Did Denzel contact you again?"
    new "我的意思是，像我之前说的，我以为我已经解决了这个问题。丹泽尔又联系你了吗？"

translate chinese chinese_5243862_921:
    old "No! Not that."
    new "不！不是那个。"

translate chinese chinese_0111199_922:
    old "Nobody remembers who I am!"
    new "没人记得我是谁了！"

translate chinese chinese_3607869_923:
    old "That's right! When I woke up I wasn't in any of the pictures on my wall!"
    new "没错！我醒来时，墙上的照片里都没有我！"

translate chinese chinese_3032730_924:
    old "Even the doorman here didn't want to let me in! He asked if I was someone's parent!"
    new "就连这里的门卫都不想让我进去！他还问我是不是谁的家长！"

translate chinese chinese_3822259_925:
    old "There's even another teacher giving my class! I already looked at the lists, I don't appear in any of them!"
    new "甚至还有另一个老师给我们上课！我已经看了名单，上面根本没有我！"

translate chinese chinese_6323987_926:
    old "It's like if I didn't ever exist, What did you do [pla]? And how did you do it?!"
    new "感觉就像我从来没存在过一样。你做了什么[pla]？又是怎么做到的！"

translate chinese chinese_0942934_927:
    old "What? But that's... that's..."
    new "什么？但这……这……"

translate chinese chinese_3854686_928:
    old "You know what? Denzel didn't ruin my life, but you did!"
    new "你知道吗？丹泽尔没有毁了我的生活，但你却做到了！"

translate chinese chinese_5182408_929:
    old "I don't know how you did it, but you blew it! I shouldn't have trusted you!"
    new "我不知道你是怎么做到的，但你搞砸了！我不应该信任你的！"

translate chinese chinese_0394308_930:
    old "What the- "
    new "什么回事-"

translate chinese chinese_2045766_931:
    old "Whoah [pla], Who's that babe?"
    new "谁啊[pla]，那个美女是谁？"

translate chinese chinese_0043530_932:
    old "She's super hot!"
    new "她超级辣！"

translate chinese chinese_6039166_933:
    old "Although she's a little too old for you."
    new "虽然她比你大了些。"

translate chinese chinese_7065264_934:
    old "You dog, did you get a sugar mommy somewhere?"
    new "色狼，你是不是找了个糖妈妈？"

translate chinese chinese_8350984_935:
    old "Don't you know who she is? That's Ms. Mia, our history teacher!"
    new "你不知道她是谁吗？那是我们的历史老师米娅老师！"

translate chinese chinese_5653950_936:
    old "Well, I had never seen her before."
    new "嗯，我之前没见过她。"

translate chinese chinese_8139987_937:
    old "But if that babe's gonna be our teacher I wouldn't mind paying a little more attention in class."
    new "但如果那个美女要当我们的老师，我倒不介意在课堂上多注意点。"

translate chinese chinese_5567767_938:
    old "She's looks super hot, like a pornstar!"
    new "她看起来超级热，像个色情明星！"

translate chinese chinese_9572310_939:
    old "Linett, what the hell happened?! The spell went wrong!"
    new "林内特，到底发生了什么！咒语出错了！"

translate chinese chinese_5154661_940:
    old "What? Did that guy appear again?"
    new "什么？那个家伙又出现了？"

translate chinese chinese_7724222_941:
    old "No! That's not it! He doesn't remember her!"
    new "不！不是那样的！他不记得她了！"

translate chinese chinese_5532148_942:
    old "Oh."
    new "哦。"

translate chinese chinese_2551602_943:
    old "Then what's the problem?"
    new "那问题在哪？"

translate chinese chinese_1304303_944:
    old "That no one does! Not a single person knows who she is!"
    new "没人知道！根本就没有人认识她！"

translate chinese chinese_7110629_945:
    old "Well... yeah."
    new "嗯……是的。"

translate chinese chinese_9984522_946:
    old "What? What do you mean..."
    new "什么？你的意思是..."

translate chinese chinese_9217532_947:
    old "I told you, didn't I? 'Every trace of her presence will be gone.' All of it [pla]."
    new "我告诉过你吧？“她存在的所有痕迹都会消失。”全部[pla]。"

translate chinese chinese_0596849_948:
    old "Wait, this can't happen, we need to revert this, how do we do it?"
    new "等一下，这不能发生，我们需要撤销它，怎么操作？"

translate chinese chinese_8864895_949:
    old "I don't know, I don't even think it's possible."
    new "我不知道，我觉得这根本不可能。"

translate chinese chinese_0259096_950:
    old "Holly shit..."
    new "holy shit... \n\n注意：这句话包含不雅词汇，在某些情况下可能需要谨慎处理。如果你希望我替换或省略这类词汇，请告知。但由于你的规则中提到不进行审查，所以我保留了原样。"

translate chinese chinese_4408247_951:
    old "Eh... What's happening?"
    new "eh... 怎么回事？"

translate chinese chinese_4350513_952:
    old "Where am I? Who are you?"
    new "我在哪儿？你是谁？"

translate chinese chinese_7646927_953:
    old "What the fuck? Who are you? And what are you doing in my bedroom?"
    new "妈的？你是谁？怎么跑到我卧室来了？"

translate chinese chinese_4054236_954:
    old "[pla], listen things are alot worse than I thought."
    new "[pla]，听我说，情况比我想象的要糟得多。"

translate chinese chinese_2135415_955:
    old "Who the hell are you?!"
    new "你特么是谁?!"

translate chinese chinese_8915924_956:
    old "And why are you naked?"
    new "而且你为什么光着身子？"

translate chinese chinese_1008396_957:
    old "Nevermind that... Listen [pla] the tear between realities that we oppenned with our spell was a lot bigger than I thought it would be."
    new "别管那个了……听我说，[pla]，我们用咒语打开的现实裂缝比我想象的要大得多。"

translate chinese chinese_8303042_958:
    old "What? So? What does that mean?"
    new "什么？所以呢？那是什么意思？"

translate chinese chinese_9757961_959:
    old "It means that both realities are about to collapse on each other!"
    new "这意味着两个现实即将相互崩溃！"

translate chinese chinese_5122484_960:
    old "Collapse? You mean like everything will be destroyed?"
    new "崩溃？你是说一切都会被毁掉吗？"

translate chinese chinese_3716206_961:
    old "No, fortunately I was able to find the disturbance early, I think I can fix it."
    new "不，幸好我早发现了这个问题，我觉得我能解决它。"

translate chinese chinese_9676351_962:
    old "And I'll do that right now."
    new "我现在就去做。"

translate chinese chinese_8094392_963:
    old "I'm just not sure if I'll make it on time, but I have to try..."
    new "我只是不确定能不能准时赶到，但总得试试..."

translate chinese chinese_2396468_964:
    old "Wow, this is a very trippy dream."
    new "哇，这真是个很诡异的梦。"

translate chinese chinese_2237153_965:
    old "Where I am? What is this???"
    new "我在哪儿？这是什么???"

translate chinese chinese_9735653_966:
    old "Is he the guy I saw a few moments ago?"
    new "他是我刚才看到的那个家伙吗？"

translate chinese chinese_4660006_967:
    old "Is this a Dream or I'm going crazy?"
    new "这是一场梦还是我疯了？"

translate chinese chinese_9405105_968:
    old "Oh God, this is making me dizzy..."
    new "哦天，这让我头晕..."

translate chinese chinese_1087894_969:
    old "What the fuck was that? Was it all a dream?"
    new "妈的那是什么？这一切都是梦吗？"

translate chinese chinese_2334507_970:
    old "All right class, it's time to start."
    new "好了，同学们，开始吧。"

translate chinese chinese_2926478_971:
    old "Today we'll start a new subject, so, take out your textbooks and open them in the next chapter."
    new "今天我们开始一个新的课题，所以把课本拿出来，翻到下一章。"

translate chinese chinese_9281539_972:
    old "This will also be at the end of term test, so be sure to take good notes."
    new "这也会出现在期末考试中，所以一定要好好记笔记。"

translate chinese chinese_2674564_973:
    old "Belle?"
    new "贝尔？"

translate chinese chinese_1821099_974:
    old "Please read the first page of the chapter."
    new "请阅读第一章的第一页。"

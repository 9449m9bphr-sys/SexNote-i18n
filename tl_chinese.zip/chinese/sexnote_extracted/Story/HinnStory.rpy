# auto-tl Qwen Colab

translate chinese chinese_6926242_0:
    old "Hey, Hinn! How are you doing?"
    new "嘿，Hinn！最近怎么样？"

translate chinese chinese_9817591_1:
    old "H... Hey [pla]! I...I'm fine. Thanks for asking?"
    new "哈...嘿[pla]！我...我挺好的。谢谢关心？"

translate chinese chinese_8911641_2:
    old "Are we a couple?"
    new "我们是情侣吗？"

translate chinese chinese_9095422_3:
    old "W... WHAT?... WE... WHAT?"
    new "什... 什么？... 我们... 什么？"

translate chinese chinese_3059059_4:
    old "Well, we are partners for the class project, right?"
    new "好吧，我们是同班项目的合作伙伴，对吧？"

translate chinese chinese_3261893_5:
    old "Ohh... Riiight. Haha. The class project. Yeah, we are. Sorry, I just forgot..."
    new "哦……对对。哈哈。班级项目。是的，我们在做。对不起，我忘了……"

translate chinese chinese_8340015_6:
    old "Don't worry. We can meet to work on it. If you prefer, I could go to your house."
    new "别担心。我们可以见面来处理这件事。如果你愿意，我可以去你家。"

translate chinese chinese_1530001_7:
    old "W...What? My house? Why? Haha. I mean, why not your place?"
    new "什……什么？我家？为什么？哈哈，我是说，为什么不去你那儿？"

translate chinese chinese_6108372_8:
    old "Well, I just thought it would be more comfortable for you. But if you don't wanna-"
    new "嗯，我只是觉得这样你会更舒服一点。但如果你不想——"

translate chinese chinese_2914428_9:
    old "No! I don't have a problem with that. Hehe. We can meet at my house then. I will wait for you tomorrow after class so we can meet up, ok?"
    new "不！我没问题的。嘿嘿。那我们就去我家见面吧。我明天放学后等你，我们一起见面，好吗？"

translate chinese chinese_2558847_10:
    old "Sounds good to me!"
    new "听起来不错！"

translate chinese chinese_6661066_11:
    old "Ok then... I... I have to go, see you tomorrow, [pla]."
    new "好吧……我……我得走了，明天见，[pla]。"

translate chinese chinese_3156212_12:
    old "See you tomorrow, Hinn!"
    new "明天见，Hinn！"

translate chinese chinese_8242343_13:
    old "Hey Hinn, how are you?"
    new "嘿，Hinn，你好吗？"

translate chinese chinese_7255835_14:
    old "Hi [pla], I'm great!, I mean, I'm good, what about you?"
    new "嗨 [pla]，我很好！我是说，我还不错，你呢？"

translate chinese chinese_1750837_15:
    old "I'm good too. So, are you ready to start?"
    new "我也很好。那么，准备开始了吗？"

translate chinese chinese_4923527_16:
    old "Well yes! I- I think so..."
    new "嗯，是的！我——我觉得是这样..."

translate chinese chinese_2274708_17:
    old "Ok, then, let's do it!"
    new "好，那我们就来吧！"

translate chinese chinese_7749033_18:
    old "Woah! Look who we have here, it's the girl who dresses as a man."
    new "哇！看看谁来了，这是那个女扮男装的姑娘。"

translate chinese chinese_1919727_19:
    old "Yes! Perhaps you have nothing but that horrible gigantic sweatshirt."
    new "没错！也许你身上就只有那件可怕的巨汗衫。"

translate chinese chinese_3831164_20:
    old "You know what the problem is? the problem is that she is kind of fat and that's why she wears those sweatshirts hahaha."
    new "你知道问题在哪里吗？问题在于她有点胖，所以才穿那些卫衣哈哈。"

translate chinese chinese_4569164_21:
    old "No, I'm not-"
    new "不，我不是-"

translate chinese chinese_4287405_22:
    old "Hahaha you're a fat woman. Don't you have any sense of style?"
    new "哈哈你真是个胖女人。你没有一点时尚感吗？"

translate chinese chinese_3566678_23:
    old "Style? Hahaha look at her such horrible clothes obviously she doesn't know what that is."
    new "风格？哈哈，看看她这衣服多难看，明显不懂什么是风格。"

translate chinese chinese_8639718_24:
    old "Hey, you shouldn't be so bitchy to Hinn..."
    new "喂，你不应该对Hinn这么刻薄..."

translate chinese chinese_2329397_25:
    old "Hahaha check it out Olivia, the loser defends the fatty woman."
    new "哈哈哈哈哈，奥利维亚，看看那个loser在替胖女人辩护。"

translate chinese chinese_4016077_26:
    old "Why don't you go away with your fat girlfriend, loser?"
    new "你这个loser，为什么不带着你那胖女友滚远点？"

translate chinese chinese_7736947_27:
    old "... Assholes."
    new "...真够混蛋的。"

translate chinese chinese_1531411_28:
    old "Bye Loser!"
    new "拜拜 loser！"

translate chinese chinese_1240502_29:
    old "Wait Hinn..."
    new "等一下，Hinn..."

translate chinese chinese_3366294_30:
    old "Hmm... some stupid girls were bothering Hinn."
    new "嗯……有些蠢女孩在烦希恩。"

translate chinese chinese_2159527_31:
    old "Has this happened before?"
    new "这之前发生过吗？"

translate chinese chinese_2469427_32:
    old "Yes, but she won't let me go talk to the principal, she says that I would only embarrass her even more..."
    new "是的，但她不让我去跟校长说话，她说我会让她更难堪..."

translate chinese chinese_8064309_33:
    old "By the way, I'm Jade Hinn's mom, are you her friend?"
    new "对了，我是 Jade Hinn 的妈妈，你是她的朋友吗？"

translate chinese chinese_4463105_34:
    old "Yes, right, I'm glad to meet you, my name is [pla]."
    new "是的，对了，很高兴见到你，我叫[pla]。"

translate chinese chinese_5601390_35:
    old "Hahaha, Nice to meet you. [pla] please excuse me for a moment. I'm going to talk to Hinn."
    new "哈哈哈哈哈，很高兴见到你。[pla]请稍等一下，我去和Hinn说句话。"

translate chinese chinese_8332446_36:
    old "Okay, see you later."
    new "好吧，回头见。"

translate chinese chinese_7208233_37:
    old "Oh no, don't go wait for me here, get comfortable and I'll be back in a minute."
    new "哦不，别在这里等我，先舒服点，我一会儿就回来。"

translate chinese chinese_5844162_38:
    old "All right, I talked to her, everything is fine, she's just a little embarrassed."
    new "好了，我和她聊过了，一切都没问题，她只是有点尴尬。"

translate chinese chinese_7868092_39:
    old "I can tell she really appreciates you that's why I want to take the opportunity to ask you a favor."
    new "我能看出来她真的很感激你，所以我想趁这个机会请你帮忙。"

translate chinese chinese_0147751_40:
    old "I have encouraged her to seek therapy many times as she has had problems at times."
    new "我多次鼓励她去寻求治疗，因为她有时会遇到一些问题。"

translate chinese chinese_2176585_41:
    old "To the psychologist?"
    new "去找心理医生？"

translate chinese chinese_9273245_42:
    old "Yes, That would be the best option for her to improve her self-esteem, I know it could help her a lot, but she won't listen to me."
    new "是的，这对她提升自信心是最好的选择，我知道这能帮到她很多，但她就是不听我的。"

translate chinese chinese_3892893_43:
    old "Hmm, I understand."
    new "嗯，我明白。"

translate chinese chinese_0445888_44:
    old "So, I thought you could help me convince her."
    new "所以，我想你可以帮我劝劝她。"

translate chinese chinese_2415546_45:
    old "Yes, I'm sure with your help we can convince her that that's the right thing to do."
    new "是的，我相信在你的帮助下，我们可以说服她那是正确的选择。"

translate chinese chinese_9966727_46:
    old "Alright. But what should I do?"
    new "好吧。但我要怎么做？"

translate chinese chinese_6446699_47:
    old "First of all, help me find a psychologist, the truth is that I have been looking for one, but I haven't been able to find anyone."
    new "首先，帮我找个心理医生，说实话，我一直在找，但是一直没找到。"

translate chinese chinese_7603845_48:
    old "Hmm, ok, I can handle it."
    new "嗯，好吧，我能应付。"

translate chinese chinese_8199152_49:
    old "All right, as soon as you find a therapist let me know. You can meet me here in the morning."
    new "好吧，你一找到心理治疗师就告诉我。你可以早上在这里找我见面。"

translate chinese chinese_6017824_50:
    old "Hello [pla], sorry for the delay..."
    new "你好[pla]，抱歉让你久等了..."

translate chinese chinese_0204332_51:
    old "All right guys, I'll leave you, so, you can go on with your work."
    new "好了，我先走了，你们继续工作吧。"

translate chinese chinese_3269560_52:
    old "Don't worry Hinn, do you feel better?"
    new "别担心，Hinn，你觉得好点了吗？"

translate chinese chinese_1537770_53:
    old "Yes a little, I'm very sorry that-"
    new "是的，有一点，非常抱歉那——"

translate chinese chinese_6244053_54:
    old "No, you don't have to apologize for anything, they're just bitches."
    new "不，你不用为任何事道歉，她们就是一群泼妇。"

translate chinese chinese_0156931_55:
    old "Hehehe, if you say so."
    new "嘿嘿嘿，如果你这么说的话。"

translate chinese chinese_3922259_56:
    old "Do you want to work today? We could do it tomorrow if you think thats better."
    new "今天想工作吗？如果你觉得明天更好也可以。"

translate chinese chinese_9207042_57:
    old "No, no, I'm fine, we can start today."
    new "不，不，我没事，今天就可以开始。"

translate chinese chinese_3280838_58:
    old "Ok, let's do it."
    new "好，我们开始吧。"

translate chinese chinese_7974233_59:
    old "Wow, Hinn! I didn't know you were so good at this!"
    new "哇，hin！没想到你这么擅长这个！"

translate chinese chinese_6230960_60:
    old "Well... It's not as difficult as it seems. Hehe. I just study a little here and there."
    new "嗯……其实没有想象中那么难。嘿嘿，我就是这里学学那里学学的。"

translate chinese chinese_1882477_61:
    old "Well, thanks to you, we made a lot of progress. I think we can stop for now."
    new "好吧，多亏了你，我们取得了很大进展。我觉得现在可以停下来了。"

translate chinese chinese_9536178_62:
    old "Yes, it's getting late. We can continue tomorrow!"
    new "没错，已经很晚了。我们明天继续吧！"

translate chinese chinese_5332918_63:
    old "Ok. I really enjoyed working with you. I think we make a very good team."
    new "好的。和你一起工作真的很愉快。我觉得我们是一个很好的团队。"

translate chinese chinese_4544802_64:
    old "Do... D- do you think that?"
    new "你... 你这么认为吗？"

translate chinese chinese_0690298_65:
    old "Of course! I think we are going to kick some ass together."
    new "当然了！我觉得我们可以一起大干一场。"

translate chinese chinese_8162152_66:
    old "Well, see you tomorrow, Hinn. Have a good night."
    new "好吧，明天见，Hinn。晚安。"

translate chinese chinese_3420001_67:
    old "You too. By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "你也是。对了，记得把我们的进度展示给米娅夫人看，让她知道我们已经走了多远。明天见。"

translate chinese chinese_8366697_68:
    old "Ok... See you."
    new "好吧……再见。"

translate chinese chinese_7609524_69:
    old "You came! I didn't know if you would actually come..."
    new "你来了！我不知道你是否会来……"

translate chinese chinese_1738184_70:
    old "Well, I like Hinn and I want to help her anyway I can, I finally found a therapist."
    new "好吧，我喜欢Hinn，我想尽我所能帮助她，我终于找到了一位心理治疗师。"

translate chinese chinese_9003604_71:
    old "That's excellent! What's their name?"
    new "太好了！他们叫什么名字？"

translate chinese chinese_4878930_72:
    old "She is Dr. Johnson, she has her office in the town Business Building."
    new "她是约翰逊博士，在镇上的商务大楼有她的办公室。"

translate chinese chinese_4139458_73:
    old "Great, it's not far from here."
    new "好，不远了。"

translate chinese chinese_4601919_74:
    old "No is not, if you want I can make an appointment to see her."
    new "不去的话，如果你想，我可以帮你预约见她。"

translate chinese chinese_5186025_75:
    old "Oh, don't worry I'll take care of it."
    new "哦，别担心，我会处理的。"

translate chinese chinese_6067186_76:
    old "However, now comes the toughest part, convincing Hinn to go to therapy."
    new "然而，现在最难的部分来了，说服Hinn去接受治疗。"

translate chinese chinese_2218185_77:
    old "So, I'll talk to her today but you should convince her to agree to do it."
    new "所以，我今天会跟她谈谈，但你应该说服她同意这么做。"

translate chinese chinese_1995352_78:
    old "Understood!"
    new "明白！"

translate chinese chinese_8474169_79:
    old "Perfect! Now hurry too school. I don't want you to be late because of me."
    new "完美！现在快去学校吧。我不想因为你而迟到。"

translate chinese chinese_8214960_80:
    old "Alright! Bye."
    new "好了！拜拜。"

translate chinese chinese_9575932_81:
    old "I only care about you and your well-being, sweetheart..."
    new "我只在乎你和你的幸福，亲爱的..."

translate chinese chinese_4635107_82:
    old "I don't need a psychologist. I'm not crazy!"
    new "我用不着心理医生。我没疯！"

translate chinese chinese_8342373_83:
    old "Oh... Hi [pla]!"
    new "哦... 嗨，[pla]！"

translate chinese chinese_5292582_84:
    old "(Oh no...)"
    new "（哦不……）"

translate chinese chinese_5058863_85:
    old "Good morning Mr. Jade... Hello there, Hinn."
    new "早上好， jade先生……嗨，hinn。"

translate chinese chinese_9044663_86:
    old "Sorry, [pla]. My mother now thinks I'm crazy..."
    new "对不起，[pla]。我妈妈现在觉得我疯了..."

translate chinese chinese_8825429_87:
    old "I don't think you're crazy honey, I just want you to go to therapy to strengthen your self-esteem."
    new "我不觉得你疯了亲爱的，我只是希望你能去治疗一下，增强自信心。"

translate chinese chinese_8187293_88:
    old "I have nothing that I need to be strengthened!"
    new "我没有什么需要加强的！"

translate chinese chinese_8761674_89:
    old "Honey, I know the reason why you don't want to go, it is because you think they are going to make fun of you even more at school."
    new "亲爱的，我知道你不想去的原因，你认为他们在学校会更加嘲笑你。"

translate chinese chinese_4801381_90:
    old "But I promise it won't happen, we can do everything without anyone knowing."
    new "但我保证不会出事的，我们可以神不知鬼不觉地做一切。"

translate chinese chinese_8049501_91:
    old "No, no, I won't do it, and I don't want you to continue embarrassing me."
    new "不，我不做，也不想让你继续让我难堪。"

translate chinese chinese_8402688_92:
    old "[pla], would you think Hinn is crazy if she goes to the therapist?"
    new "[pla]，如果你觉得希恩去看心理医生是不是有点疯？"

translate chinese chinese_4036981_93:
    old "Actually, I think it's healthy, and if it's something that will help you feel better, I don't think it matters what others think, right?"
    new "实际上，我觉得这挺健康的，如果这能让你感觉好些，我不认为别人怎么想重要，对吧？"

translate chinese chinese_3967965_94:
    old "You see darling, there is nothing wrong with it, many people attend to therapy and it is completely normal."
    new "你看亲爱的，这没什么不对的，很多人去接受治疗，这完全正常。"

translate chinese chinese_3711096_95:
    old "In fact, [pla] would you go with Hinn?"
    new "事实上，[pla]，你会和Hinn一起去吗？"

translate chinese chinese_9363162_96:
    old "Sure, I'd love to."
    new "当然，我很乐意。"

translate chinese chinese_5856124_97:
    old "See honey, don't worry any more, go to a single session and then decide whether to continue or not."
    new "宝贝，别担心了，先试一次，然后再决定要不要继续。"

translate chinese chinese_8940616_98:
    old "Would you really be willing to go with me?"
    new "你真的愿意跟我一起去吗？"

translate chinese chinese_1448769_99:
    old "Of course, it should be fun."
    new "当然，这应该很有趣。"

translate chinese chinese_5526729_100:
    old "Okay, but don't think I don't realize how you are manipulating me."
    new "好吧，但别以为我不知道你在操纵我。"

translate chinese chinese_9984416_101:
    old "Excellent honey, I'm going to make the appointment. So, you can start studying now."
    new "很好，亲爱的，我要去预约了。所以你现在可以开始学习了。"

translate chinese chinese_5804336_102:
    old "She's unbelievable..."
    new "她真是不可思议……"

translate chinese chinese_4037190_103:
    old "Well, the truth is, I think she's doing the best she can to help you."
    new "其实，我认为她已经在尽最大努力帮你了。"

translate chinese chinese_1357214_104:
    old "If you say so... Anyway, let's start to work."
    new "如果你这么说的话……不管怎样，我们开始工作吧。"

translate chinese chinese_0922070_105:
    old "[pla], thank you... seriously. Thanks for having my back."
    new "[pla]，谢谢你……真的。谢谢你在背后支持我。"

translate chinese chinese_3776600_106:
    old "It's nothing..."
    new "没什么..."

translate chinese chinese_8452980_107:
    old "Ok, see you tomorrow, Hinn."
    new "好，明天见，Hinn。"

translate chinese chinese_1520735_108:
    old "Ok. Have a good night."
    new "好的，晚安。"

translate chinese chinese_5313852_109:
    old "Hello [pla], How are you doing?"
    new "你好[pla]，最近怎么样？"

translate chinese chinese_4103661_110:
    old "Hey Hinn, I am doing great, you?"
    new "嘿，Hinn，我很好，你呢？"

translate chinese chinese_9067895_111:
    old "Fine, thanks for asking. Today is the so-called “therapy session”, are you coming?"
    new "好吧，谢谢关心。今天是所谓的“治疗 session”，你来吗？"

translate chinese chinese_2030908_112:
    old "Is it today?"
    new "是今天吗？"

translate chinese chinese_3451183_113:
    old "Yes... My mother finally managed to schedule an appointment as we agreed."
    new "是的……我妈妈终于按我们说的预约上了。"

translate chinese chinese_7231275_114:
    old "Sure, I promised that I'll join you."
    new "好吧，我答应加入你们。"

translate chinese chinese_6795371_115:
    old "Awesome, are you ready?"
    new "太好了，准备好了吗？"

translate chinese chinese_0496273_116:
    old "Yes, let's get going."
    new "好的，我们出发吧。"

translate chinese chinese_4006684_117:
    old "Very well."
    new "好吧。"

translate chinese chinese_5568767_118:
    old "Good afternoon, nice to meet you, you must be Hinn, right?"
    new "下午好，很高兴见到你，你一定是Hinn吧？"

translate chinese chinese_6711189_119:
    old "Yes, Dr. Johnson, nice to meet you too."
    new "是的，约翰逊博士，也很高兴见到您。"

translate chinese chinese_4838221_120:
    old "Your mother has already told me a little about you and you are..."
    new "你妈妈已经跟我说了一些关于你的事，你..."

translate chinese chinese_0591439_121:
    old "My name is [pla], nice to meet you."
    new "我叫[vars], 很高兴认识你。"

translate chinese chinese_9417919_122:
    old "Oh, are you her boyfriend?"
    new "哦，你是她的男朋友吗？"

translate chinese chinese_1310881_123:
    old "He's a friend..."
    new "他是朋友……"

translate chinese chinese_7091772_124:
    old "Oh ok, I understand a friend..."
    new "哦，好的，我明白了，朋友……"

translate chinese chinese_9312710_125:
    old "All right, I think it's time to start therapy. [pla] could you wait for us outside?"
    new "好吧，我觉得是时候开始治疗了。[pla]，你能在外面等我们吗？"

translate chinese chinese_4208537_126:
    old "A few minutes later"
    new "几分钟后"

translate chinese chinese_0381610_127:
    old "[pla] Can you come in for a moment, please?"
    new "[pla] 你能进来一下吗？"

translate chinese chinese_6867617_128:
    old "Very well, let me explain. With Hinn we have discussed the issue of bullying in the school."
    new "好吧，让我解释一下。我和Hinn讨论了学校里的欺凌问题。"

translate chinese chinese_6683341_129:
    old "And we have reached to the conclusion that it is best for her to try on other outfits so that she feels more comfortable with her body."
    new "我们得出结论，让她试穿其他衣服会让她对自己的身体感觉更舒服。"

translate chinese chinese_4561338_130:
    old "I understand, I think it's a good idea."
    new "我明白，我觉得这是个好主意。"

translate chinese chinese_7643932_131:
    old "Yes, but to help her to have a better progress with the therapy, we require your help."
    new "是的，但为了帮助她更好地进行治疗，我们需要你的帮助。"

translate chinese chinese_0442776_132:
    old "My help? How so?"
    new "我的帮助？怎么帮？"

translate chinese chinese_8533271_133:
    old "We need a male friend opinion for each outfit so Hinn can feel that someone cares for her."
    new "我们需要每个装扮都征求一个男性朋友的意见，这样Hinn才会觉得有人关心她。"

translate chinese chinese_1863997_134:
    old "Oh, I understand, no problem."
    new "哦，我明白了，没问题。"

translate chinese chinese_5593815_135:
    old "Yes, it will be fun."
    new "是的，这会很有趣。"

translate chinese chinese_0488543_136:
    old "All right, in that case sit on the couch while Hinn takes off that sweatshirt."
    new "好吧，那你就坐在沙发上，让Hinn脱掉那件汗衫。"

translate chinese chinese_0339773_137:
    old "Are you ready Hinn?"
    new "准备好了吗，Hinn？"

translate chinese chinese_5711052_138:
    old "Hmm, I think so."
    new "嗯，我想是这样。"

translate chinese chinese_1506679_139:
    old "Very well take off that sweatshirt and let us see your body better."
    new "好吧，脱掉那件卫衣，让我们更好地看看你的身体。"

translate chinese chinese_0090824_140:
    old "Don't worry, you're in a safe place, nobody's going to judge you here."
    new "别担心，你在这里很安全，没人会评判你。"

translate chinese chinese_4487471_141:
    old "Hmm alright."
    new "嗯，好吧。"

translate chinese chinese_6809801_142:
    old "But girl you have a great body!"
    new "但是女孩，你身材真好！"

translate chinese chinese_4781247_143:
    old "What about you [pla]? Her body shape looks better, right?"
    new "那你呢，[pla]？她的身材看起来更好，对吧？"

translate chinese chinese_9693752_144:
    old "Yes, she certainly looks better."
    new "是的，她确实看起来更好了。"

translate chinese chinese_0986030_145:
    old "Do you think you could survive without your Sweatshirt?"
    new "你觉得你能不用你的卫衣活下去吗？"

translate chinese chinese_1988045_146:
    old "They are going to criticize me at school, because of my... b- breasts."
    new "他们会在学校批评我，因为我的... b-胸部。"

translate chinese chinese_8877594_147:
    old "Hahaha, but how are you going to be embarrassed by those beautiful breasts?"
    new "哈哈，但是你被那对漂亮胸部尴尬到什么程度呢？"

translate chinese chinese_1931673_148:
    old "What do you say [pla], Hinn should be ashamed?"
    new "你说[pla]，Hinn应该感到羞愧吗？"

translate chinese chinese_0168954_149:
    old "... Hmm no, really your breasts look great."
    new "... 嗯，不，真的，你的胸部看起来很棒。"

translate chinese chinese_2375356_150:
    old "You have a blessing, you have a slim waist and a couple of really nice boobs, with those you might make all the boys crazy over you. "
    new "你有福气，腰细还有 pair 很不错的胸部，这些足以让所有男生为你疯狂。"

translate chinese chinese_9676588_151:
    old "All right, all right, no problem, I think that's it for today."
    new "好吧好吧，没问题，我想今天就到这里吧。"

translate chinese chinese_6608983_152:
    old "However, we will have to get some more outfits to continue with your treatment."
    new "不过，我们需要再准备一些衣服来继续你的治疗。"

translate chinese chinese_0428969_153:
    old "Hmm, I'd rather it wasn't your own clothes, since from what I've see your clothes cover a lot."
    new "嗯，我宁愿不是你自己的衣服，因为从我看到的来看，你的衣服遮得挺多的。"

translate chinese chinese_5330539_154:
    old "I think I could help, I could get some clothes for Hinn."
    new "我觉得我能帮忙，我可以给Hinn拿些衣服。"

translate chinese chinese_6366904_155:
    old "Fantastic! Make sure it's a bit of a daring and revealing outfit."
    new "太好了！确保是有点大胆又暴露的装扮。"

translate chinese chinese_0656526_156:
    old "We need to gradually make Hinn feel more secure in her body."
    new "我们需要逐渐让Hinn对自己的身体感到更安全。"

translate chinese chinese_3943804_157:
    old "Ok, see you in the next session guys!"
    new "好，下次见大家！"

translate chinese chinese_8048142_158:
    old "Thanks Dr. Johnson, goodbye."
    new "谢谢约翰逊博士，再见。"

translate chinese chinese_1486191_159:
    old "Goodbye."
    new "再见。"

translate chinese chinese_0838878_160:
    old "How did you feel Hinn?"
    new "你觉得怎么样，Hinn？"

translate chinese chinese_1358915_161:
    old "Actually, it was quite interesting, I felt comfortable in therapy, confronting it a little I think it can help."
    new "实际上，还挺有趣的，我在治疗中感觉很舒服，面对它一点我觉得这能有帮助。"

translate chinese chinese_6084954_162:
    old "Excellent, I think it's great that you feel that way."
    new "太好了，我觉得你这么想很棒。"

translate chinese chinese_6173016_163:
    old "So, will you continue attending therapy?"
    new "那么，你会继续参加治疗吗？"

translate chinese chinese_1578602_164:
    old "Hmm... Would you still accompany me?"
    new "嗯……你还会陪我吗？"

translate chinese chinese_5200668_165:
    old "Of course I will."
    new "当然会。"

translate chinese chinese_4970169_166:
    old "Okay, let's just don't make a fuss in front of my mother, I don't want her to think she was right."
    new "好吧，别在我妈面前闹，我不想让她以为她是对的。"

translate chinese chinese_4396258_167:
    old "Hahaha, alright."
    new "哈哈，好吧。"

translate chinese chinese_2345680_168:
    old "Thanks again for your support."
    new "再次感谢你的支持。"

translate chinese chinese_2953724_169:
    old "It's a pleasure, Hinn."
    new "很高兴见到你，Hinn。"

translate chinese chinese_4177372_170:
    old "Could you come with me to my house today? I don't want my mother to ask me many questions."
    new "今天能跟我去我家吗？我不想让我妈问东问西的。"

translate chinese chinese_9618824_171:
    old "How did it go guys?"
    new "怎么样了 guys？"

translate chinese chinese_0482657_172:
    old "Hmm... it wasn't a bad idea after all..."
    new "嗯……这主意倒也不是很差……"

translate chinese chinese_4166495_173:
    old "You should tell by now that therapy is a very positive thing to do."
    new "你应该明白，做治疗是一件非常积极的事情。"

translate chinese chinese_7774073_174:
    old "Then I will immediately schedule the next appointment!"
    new "那我马上就安排下一次预约！"

translate chinese chinese_4453216_175:
    old "No, I'm not going to go to therapy every day mom..."
    new "不，妈妈，我不会每天去治疗的..."

translate chinese chinese_6240346_176:
    old "But... I thought you liked it."
    new "但是……我以为你喜欢的。"

translate chinese chinese_8455123_177:
    old "Yes, I will go but remember, I have more responsibilities, like the class project with [pla]."
    new "好，我会去，但记住，我还有很多责任，比如和[pla]的班级项目。"

translate chinese chinese_0790924_178:
    old "Hmm, I understand, So when I should make the next appointment?"
    new "嗯，我明白了，那我下次预约什么时候比较好？"

translate chinese chinese_8504511_179:
    old "No, I will make the appointments myself when I think it is appropriate."
    new "不，我觉得合适的时候会自己安排的。"

translate chinese chinese_2148416_180:
    old "Besides, [pla] must also agree when we should go, since he's going to the therapies as well."
    new "再说，[pla] 也得同意我们什么时候去，因为他也要参加治疗。"

translate chinese chinese_4925588_181:
    old "Okay, you're right, I'll leave that up to you, if you need anything don't hesitate to ask me."
    new "好吧，你说得对，这件事我交给你了，如果你需要什么就尽管问我。"

translate chinese chinese_6377672_182:
    old "I'll leave you alone, so, you can say goodbye to each other, heh."
    new "我给你们单独待着，你们慢慢道别吧，嘿嘿。"

translate chinese chinese_9748597_183:
    old "I'm glad that everything went well with therapy."
    new "很高兴治疗一切顺利。"

translate chinese chinese_4949945_184:
    old "Yes, me too, at least my mom will stop bothering me every day, or I hope so."
    new "是的，我也是，至少我妈妈不会再每天烦我了，但愿如此。"

translate chinese chinese_2322694_185:
    old "Hahaha I don't think that's going to happen."
    new "哈哈，我觉得那不可能会发生。"

translate chinese chinese_8218883_186:
    old "Hehehe neither do I."
    new "嘿嘿嘿，我也没有。"

translate chinese chinese_5416133_187:
    old "Well, well, it's getting late, so I'm going home, see you tomorrow."
    new "好吧，天晚了，我回家了，明天见。"

translate chinese chinese_8364885_188:
    old "Yes, thank you so much for what you are doing."
    new "是的，非常感谢你的帮助。"

translate chinese chinese_8059725_189:
    old "You are welcome, I enjoyed it as much as you did and I love spending time with you."
    new "不客气，我玩得也超开心的，我很喜欢和你在一起。"

translate chinese chinese_7144150_190:
    old "Well... see you tomorrow."
    new "嗯……明天见。"

translate chinese chinese_0821556_191:
    old "Hey Hinn! How are you today?"
    new "嘿，Hinn！今天怎么样？"

translate chinese chinese_4368480_192:
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy sesion."
    new "我挺好的，谢谢[pla]，我在等你，今天是新的治疗 session。"

translate chinese chinese_7379361_193:
    old "Oh great, let's go then."
    new "哦，好的，那我们走吧。"

translate chinese chinese_3128722_194:
    old "Ok, ok."
    new "好，好。"

translate chinese chinese_9113357_195:
    old "Hi guys, how are you?"
    new "大家好，你们怎么样？"

translate chinese chinese_2624436_196:
    old "Fine, thanks."
    new "还好，谢谢。"

translate chinese chinese_8648955_197:
    old "Ready to go on with the treatment?"
    new "准备好继续治疗了吗？"

translate chinese chinese_7024441_198:
    old "I think so..."
    new "我觉得是这样的……"

translate chinese chinese_5862284_199:
    old "Excellent, [pla] you brought the clothes, didn't you?"
    new "很好，[pla]你把衣服带来了吧？"

translate chinese chinese_4404908_200:
    old "Well, yes although I'm not sure if this will work, the clothes are... a little more revealing than necessary."
    new "嗯，虽然我不确定这会不会有效，这些衣服……有点太暴露了。"

translate chinese chinese_6381481_201:
    old "Hmm, we'll see let's go Hinn, to the changing room."
    new "嗯，我们去看看，希恩，去换衣间。"

translate chinese chinese_5540991_202:
    old "Hmm... ok."
    new "嗯……好吧。"

translate chinese chinese_5751470_203:
    old "Well, it took me a while to convince her, but finally got her to try on this outfit..."
    new "嗯，我花了好一阵子才说服她，终于让她试穿了这套衣服..."

translate chinese chinese_6496075_204:
    old "What do you think [pla]?"
    new "你觉得[pla]怎么样？"

translate chinese chinese_2778744_205:
    old "(Oh my God!) Well, I think you look really good, Hinn..."
    new "（天啊！）嗯，我觉得你看起来很好，hin..."

translate chinese chinese_9523506_206:
    old "Do you really think so?"
    new "你真的这么认为吗？"

translate chinese chinese_0812718_207:
    old "Yes, you look great."
    new "是的，你看起来很棒。"

translate chinese chinese_9212176_208:
    old "What did I tell you? You should wear these kinds of clothes every day."
    new "我跟你说过什么来着？你应该每天都穿这种衣服。"

translate chinese chinese_7915444_209:
    old "No way. I'm not going to wear this in public..."
    new "没门。我不会在公共场合穿这个的..."

translate chinese chinese_3435419_210:
    old "Well, at least you tried it. We are making progress. However, we need to go further. Next time bring something more revealing, ok [pla]?"
    new "好吧，至少你试过了。我们在进步。不过，我们需要更进一步。下次带点更暴露的东西来，好吗，[pla]？"

translate chinese chinese_3860296_211:
    old "More revealing?!"
    new "还要更暴露?!"

translate chinese chinese_4141844_212:
    old "Yeah, honey remember we are going to do it privately and in a safe place, so we can improve."
    new "嗯，宝贝，记得我们要私下里在一个安全的地方做，这样我们可以进步。"

translate chinese chinese_7553159_213:
    old "Well, that's it. See you in the next session."
    new "好了，就到这里吧。下次见。"

translate chinese chinese_6478204_214:
    old "Thanks Dr. Johnson."
    new "谢谢约翰逊博士。"

translate chinese chinese_9011284_215:
    old "Thank you so much for joining me again... I really appreciate it."
    new "真的很感谢你再次陪我……我真的很感激。"

translate chinese chinese_2083431_216:
    old "Oh, don't worry, I think it's fun."
    new "哦，别担心，我觉得这很有趣。"

translate chinese chinese_6661645_217:
    old "You're right, it's a bit fun..."
    new "你说得对，这有点好玩……"

translate chinese chinese_7025705_218:
    old "Would you like me to walk you home?"
    new "要我送你回家吗？"

translate chinese chinese_8900490_219:
    old "Oh no, don't worry my mom will come to pick me up."
    new "哦不，不用担心，我妈妈会来接我的。"

translate chinese chinese_0533852_220:
    old "Alright, then see you tomorrow?"
    new "好吧，那明天见？"

translate chinese chinese_1105498_221:
    old "Yes!... I mean, sure."
    new "是的！……我的意思是，好吧。"

translate chinese chinese_6740153_222:
    old "Great, see you tomorrow Hinn."
    new "好的，明天见，Hinn。"

translate chinese chinese_6614074_223:
    old "See you tomorrow [pla]."
    new "明天见[pla]。"

translate chinese chinese_3169747_224:
    old "I'm fine thanks [pla], I was waiting for you, today is the new therapy session."
    new "我挺好的，谢谢[pla]，我在等你，今天是新的治疗课程。"

translate chinese chinese_2867682_225:
    old "Ready to get started with the treatment?"
    new "准备开始治疗了吗？"

translate chinese chinese_5477758_226:
    old "Excellent, let's go Hinn."
    new "太好了，我们走吧，Hinn。"

translate chinese chinese_6425174_227:
    old "I love this outfit, I find it fancy and it looks great on you Hinn..."
    new "我超爱这套衣服的，感觉很高级，穿在你身上hin好看……"

translate chinese chinese_8321424_228:
    old "Look at you, wow, you look fantastic."
    new "看看你，哇，你看起来棒极了。"

translate chinese chinese_8242054_229:
    old "I think this skirt is too short..."
    new "我觉得这条裙子太短了……"

translate chinese chinese_5208692_230:
    old "That's the idea! To show those pretty legs of yours. Hehe. See how [pla] is drooling over them?"
    new "就是这样！展示你那漂亮的腿。嘿嘿。看看[pla]流口水的样子？"

translate chinese chinese_6644789_231:
    old "Mmm Yes... I mean no... I'm just watching. Nothing more."
    new "嗯，是的……我的意思是不……我只是在看，没有别的。"

translate chinese chinese_6262692_232:
    old "Sure, you are... Do you think Hinn has pretty legs?"
    new "好吧，你认为希恩的腿漂亮吗？"

translate chinese chinese_7704926_233:
    old "Uhhh... Well, actually yes, I do..."
    new "呃……其实，我是有的……"

translate chinese chinese_1830724_234:
    old "Yes, you really look nice."
    new "是的，你真的很好看。"

translate chinese chinese_1805922_235:
    old "And how about that cleavage, aye?"
    new "那胸口的风景也不错吧？"

translate chinese chinese_2503594_236:
    old "Uhh... It looks great, too. Hinn has a really good... Body."
    new "呃……看起来也很好。Hinn的身体真的很好。"

translate chinese chinese_4356153_237:
    old "She has great boobs, too, doesn't she?"
    new "她的胸部也很大，对吧？"

translate chinese chinese_0661387_238:
    old "I'm going to change my clothes..."
    new "我要去换衣服……"

translate chinese chinese_7442523_239:
    old "Hehe. I was just kidding..."
    new "嘿嘿，我刚才只是开玩笑..."

translate chinese chinese_3047449_240:
    old "Well, that's it, [pla] you can surprise me the next session with another beautiful outfit like today."
    new "好吧，[pla]，下次你可以像今天这样再给我一个惊喜，换套漂亮的衣服。"

translate chinese chinese_3366534_241:
    old "I will try."
    new "我会试试。"

translate chinese chinese_0981505_242:
    old "Great! All right guys, see you in the next session."
    new "太好了！大家，下次见。"

translate chinese chinese_4755711_243:
    old "Thank you Dr. Johnson."
    new "谢谢约翰逊博士。"

translate chinese chinese_5175949_244:
    old "You are right, it's a bit fun..."
    new "你说得对，这有点好玩……"

translate chinese chinese_4614819_245:
    old "Do you want me to walk you home?"
    new "你要我送你回家吗？"

translate chinese chinese_3996192_246:
    old "I talked to Mrs. Mia... Ugh, I think she hates me or something."
    new "我和米娅太太谈过了……唉，我觉得她可能讨厌我。"

translate chinese chinese_4507057_247:
    old "Why do you say that?"
    new "你为什么这么说？"

translate chinese chinese_7768960_248:
    old "She doesn't think I did anything on our project... And she wants you to talk to her alone."
    new "她觉得我没参与我们的项目……而且她想让你单独和她谈谈。"

translate chinese chinese_0427946_249:
    old "Oh, no problem, [pla]. Don't worry I'll talk to her and let her know the truth."
    new "哦，没问题，[pla]。放心，我会跟她谈谈，让她知道真相的。"

translate chinese chinese_8405134_250:
    old "Ok. Thank you, Hinn."
    new "好的。谢谢你，Hinn。"

translate chinese chinese_2520133_251:
    old "Everything is fine. I explained everything to her."
    new "一切都好。我已经把一切都解释给她了。"

translate chinese chinese_8029796_252:
    old "Really? Just like that, huh?"
    new "真的吗？就那样吗？"

translate chinese chinese_7513551_253:
    old "Well, I can be very persuasive if I set my mind to it."
    new "好吧，如果我下定决心，我可以非常有说服力。"

translate chinese chinese_7307333_254:
    old "Wow, Hinn! You sure have changed. You're way more open and secure..."
    new "哇，Hinn！你真是变了好多。你变得开朗多了，也更自信了……"

translate chinese chinese_7204756_255:
    old "Yes, I really do."
    new "是的，我确实这么认为。"

translate chinese chinese_9728320_256:
    old "Hahaha. Well, thank you, [pla]. It seems that my mom's crazy ideas really worked somehow."
    new "哈哈。好吧，谢谢你，[pla]。看来我妈妈的疯狂想法还真起了作用。"

translate chinese chinese_4764549_257:
    old "Yes. I definitely think so..."
    new "是的。我确实这么认为..."

translate chinese chinese_0334655_258:
    old "Well, speaking of that, today is the new therapy session."
    new "说起来，今天是新的治疗 session。"

translate chinese chinese_3692621_259:
    old "Great, let's go Hinn."
    new "好的，我们走吧，Hinn。"

translate chinese chinese_3947394_260:
    old "I honestly didn't think that Hinn was going to wear this... But we really are coming a long way..."
    new "我真的没想到hin会穿这个……但我们确实走了好远的路了……"

translate chinese chinese_0421606_261:
    old "I don't really feel comfortable..."
    new "我感觉不太舒服……"

translate chinese chinese_0646520_262:
    old "You look fantastic, girl! With this outfit, you will drive them all crazy!"
    new "你看起来棒极了，女孩！穿上这套衣服，你会让他们全部疯狂的！"

translate chinese chinese_7309452_263:
    old "What! Who's supposed to wear this in public?"
    new "什么！这东西谁穿出去啊？"

translate chinese chinese_1911865_264:
    old "Hahaha, I'd be surprised. What do you think, [pla]?"
    new "哈哈，我倒是挺意外的。你觉得呢，[pla]？"

translate chinese chinese_2485223_265:
    old "...(Oh shit! I'm getting hard.)"
    new "...(糟糕！我硬了。)"

translate chinese chinese_9720637_266:
    old "Haha! Well, you've already made him get horny."
    new "哈哈！不过，你已经让他兴奋起来了。"

translate chinese chinese_6644973_267:
    old "Can't you see his pants?"
    new "你看不见他的裤子吗？"

translate chinese chinese_4535942_268:
    old "That right there, Hinn, is the most honest show of appreciation you can receive from a man..."
    new "hin，那个就是你能从一个男人那里收到的最真诚的感激表现……"

translate chinese chinese_8714161_269:
    old "Oh my..."
    new "哦我的天..."

translate chinese chinese_1917825_270:
    old "Sorry... It wasn't... My intention..."
    new "对不起……那不是……我的本意……"

translate chinese chinese_1339872_271:
    old "Oh, no. Don't worry, honey. In fact, Hinn, you should feel flattered."
    new "哦，别担心，亲爱的。实际上，赫因，你应该感到荣幸。"

translate chinese chinese_2329610_272:
    old "Do you know what that erection means? [pla] is sexually attracted to you!"
    new "你知道那个勃起是什么意思吗？[pla] 对你有性吸引力！"

translate chinese chinese_1247588_273:
    old "(Oh shit!)"
    new "（糟了！）"

translate chinese chinese_1880005_274:
    old "Well, since you are both quite young, I think I could take this chance to give you a little sex education lesson..."
    new "嗯，既然你们都还很小，我觉得我可以趁这个机会给你们上一小节性教育课……"

translate chinese chinese_0624642_275:
    old "Hahaha, [pla], you have Hinn speechless... Come here, don't be shy..."
    new "哈哈哈哈哈，[pla]，你把Hinn说得无话可说了……过来，别害羞……"

translate chinese chinese_5080753_276:
    old "I have to admit, [pla], I didn't imagine it would be this big... His size is pretty impressive, huh, Hinn?"
    new "不得不承认，[pla]，我没想到会这么大……他的尺寸挺惊人的，对吧，Hinn？"

translate chinese chinese_4100525_277:
    old "(It's so big.)"
    new "（好大。）"

translate chinese chinese_3873537_278:
    old "Haha. This surely is the first time she's seen a real one and seeing one of this size even surprises me."
    new "哈哈。这肯定是她第一次看到真的，而且这么大一个连我都觉得惊讶。"

translate chinese chinese_8573601_279:
    old "Let me get all this out of here..."
    new "让我把这些都清理掉……"

translate chinese chinese_7998426_280:
    old "Certainly... This is awesome, kid... What a big cock you have down here!"
    new "当然了……这太棒了，小子……你下面的家伙真大！"

translate chinese chinese_0658028_281:
    old "Well, Hinn, pay close attention... I'm going to teach you how to please a man with your hands, this will be very useful knowledge..."
    new "好吧，Hinn，仔细看好了……我要教你如何用手让男人满意，这将是非常有用的知识……"

translate chinese chinese_7979350_282:
    old "You have to take it in your hands and start to massage, from top to bottom very carefully..."
    new "你得用手握住，从上到下仔细地按摩……"

translate chinese chinese_8608115_283:
    old "Well... I hope you learned a little more about your sexuality, kids... If you want me to give you another small lesson, just let me know."
    new "嗯……希望你们对性取向有了更多的了解……如果想让我再给你们上一小课，随时告诉我。"

translate chinese chinese_6470066_284:
    old "See you in the next session."
    new "下次见。"

translate chinese chinese_0475238_285:
    old "Well..."
    new "嗯……"

translate chinese chinese_2050280_286:
    old "Your mom is coming to pick you up?"
    new "你妈妈来接你？"

translate chinese chinese_5993479_287:
    old "Yes, yes, she is coming to get me."
    new "是的，是的，她过来找我了。"

translate chinese chinese_2764335_288:
    old "Oh, ok, then see you tomorrow?"
    new "哦，好的，那明天见？"

translate chinese chinese_7676289_289:
    old "Yes, I love to help. Also, I think your mom did everything to help you."
    new "是的，我很乐意帮忙。而且，我觉得你妈妈已经为你做了所有能做的事。"

translate chinese chinese_8073189_290:
    old "I really think you look good with any clothes you decide to wear, the most important thing is how you feel about yourself."
    new "我真的觉得你穿任何衣服都好看，最重要的是你自己感觉如何。"

translate chinese chinese_0346462_291:
    old "Thank you, [pla]. I really appreciate it..."
    new "谢谢你，[pla]。我真的很感激……"

translate chinese chinese_6041020_292:
    old "My pleasure... So, see you this afternoon?"
    new "我的荣幸……那么，下午见？"

translate chinese chinese_1966738_293:
    old "For sure, see you in the afternoon."
    new "没问题，下午见。"

translate chinese chinese_2477820_294:
    old "Great. Bye."
    new "好极了。再见。"

translate chinese chinese_3793543_295:
    old "Hi guys! Ready for the last session?"
    new "大家好！准备好最后一节课了吗？"

translate chinese chinese_4359925_296:
    old "Is this the last session?"
    new "这是最后一次了吗？"

translate chinese chinese_0749179_297:
    old "Yes, you have advanced very well with the therapy."
    new "是的，你的治疗进展得很好。"

translate chinese chinese_6715438_298:
    old "And have managed to gain more security in yourself and in your body and that was the objective."
    new "而且你已经成功增强了对自己的身体的信心，这就是目标。"

translate chinese chinese_7195607_299:
    old "But... I- I don't feel... Ready."
    new "但是……我——我不觉得……准备好。"

translate chinese chinese_4986158_300:
    old "Well... We still have this session, right?"
    new "嗯……我们还有这次机会，对吧？"

translate chinese chinese_3740336_301:
    old "Hmm... ok..."
    new "嗯……好……"

translate chinese chinese_6493564_302:
    old "All right for this last one I told you that you didn't need to bring any more clothes [pla]."
    new "好吧，最后一次我告诉你不用再带衣服了[pla]。"

translate chinese chinese_4412568_303:
    old "And that's because this last session we are going to do an exercise of accepting your own body."
    new "因为在这最后一次课程中，我们要进行一个接受自己身体的练习。"

translate chinese chinese_3020027_304:
    old "Right, little by little you started to wear clothes that exposed more of your body, this time there will be nothing covering your body..."
    new "对了，你渐渐开始穿暴露身体的衣服，这次你的身体将没有任何遮盖..."

translate chinese chinese_0639272_305:
    old "So?"
    new "所以呢？"

translate chinese chinese_6254935_306:
    old "Right, this time you'll be naked."
    new "好的，这次你会裸着身子。"

translate chinese chinese_7071260_307:
    old "Come on girl, that's not much different from what you've already done before."
    new "喂，这和你之前做的没什么两样。"

translate chinese chinese_9578371_308:
    old "Just let's go girl, Your body is natural, your body is perfect."
    new "来吧女孩，你的身体很自然，你的身体很完美。"

translate chinese chinese_2298345_309:
    old "Well, I think we're ready!"
    new "好吧，我觉得我们可以开始了！"

translate chinese chinese_8647187_310:
    old "How are you feeling my dear?"
    new "亲爱的，你感觉怎么样？"

translate chinese chinese_4933353_311:
    old "I don't feel very good..."
    new "我感觉不太舒服……"

translate chinese chinese_2965475_312:
    old "But come on it's very natural, that's your body and it's beautiful, right [pla]?"
    new "但是拜托，这很自然啊，那是你的身体，而且很漂亮，对吧，[pla]？"

translate chinese chinese_9240962_313:
    old "Hahaha again in silence?"
    new "哈哈，又是在沉默中吗？"

translate chinese chinese_4774119_314:
    old "I guess you guys will have played around a bit since the last lesson I gave you, right?"
    new "我想你们上次我教你们之后肯定玩得不亦乐乎吧？"

translate chinese chinese_0833591_315:
    old "... No, we haven't..."
    new "...不，我们还没..."

translate chinese chinese_5683921_316:
    old "Oh really? That's a shame."
    new "哦真的吗？那真可惜。"

translate chinese chinese_8709413_317:
    old "You know what I'll give you another free lesson, would you like to?"
    new "你知道吗，我可以再给你一次免费课程，你要不要？"

translate chinese chinese_5491696_318:
    old "Hahaha, what are you trying to hide [pla] and Hinn's embarrassed face says yes."
    new "哈哈哈哈哈，你在藏什么啊 [pla]，hininn尴尬的表情说明了一切。"

translate chinese chinese_9423052_319:
    old "Okay, but only because it's our last session together."
    new "好吧，但仅仅因为这是我们最后一次一起见面。"

translate chinese chinese_2946071_320:
    old "Come here Hinn, I'll teach you how to take the next step in male pleasure."
    new "过来，Hinn，我教你如何提升男性的快感。"

translate chinese chinese_9931957_321:
    old "Very well, you take it in your hand and this time you use your mouth."
    new "好吧，你用手拿着，这次用嘴。"

translate chinese chinese_9472928_322:
    old "You must pay close attention to the head, it is the most pleasant area"
    new "你必须密切注意头部，那是最让人愉悦的区域"

translate chinese chinese_3513904_323:
    old "So, you should use your tongue and lips to stimulate that whole area."
    new "所以，你应该用舌头和嘴唇刺激那个整个区域。"

translate chinese chinese_8260983_324:
    old "Well, you've been naked for over 10 min, in front of us and you look pretty comfortable with that."
    new "好吧，你已经裸着超过10分钟了，而且在我们面前还显得挺自在的。"

translate chinese chinese_4388816_325:
    old "That is proof that my work is already done."
    new "这就是我的工作已经完成的证明。"

translate chinese chinese_8025968_326:
    old "Thank you very much Dr. Johnson."
    new "非常感谢你，约翰逊博士。"

translate chinese chinese_1051246_327:
    old "But girl you can get dressed now, you don't have to be naked all the time..."
    new "但是姑娘你现在可以穿衣服了，不用一直裸着……"

translate chinese chinese_6452711_328:
    old "... Sorry."
    new "... 对不起。"

translate chinese chinese_5361924_329:
    old "Hahaha."
    new "哈哈哈哈哈。"

translate chinese chinese_1682069_330:
    old "Well this is it, I hope the sessions and the little lessons have helped you, enjoy your sexuality and your youth guys!"
    new "好吧，就到这里了，希望这些课程和小教程对你有帮助，享受你们的性欲和青春吧！"

translate chinese chinese_9667409_331:
    old "I hope you do very well."
    new "希望你表现得很好。"

translate chinese chinese_5283738_332:
    old "How did you feel in today's session?"
    new "今天这一段你感觉如何？"

translate chinese chinese_2118613_333:
    old "I think it was exciting..."
    new "我觉得很刺激……"

translate chinese chinese_8199151_334:
    old "Ehmm, yes, it was exciting, right?"
    new "嗯，是啊，那真是刺激，对吧？"

translate chinese chinese_7997384_335:
    old "Did you like it?"
    new "你喜欢吗？"

translate chinese chinese_1053988_336:
    old "Well... Yes."
    new "嗯……是的。"

translate chinese chinese_3583657_337:
    old "I liked too."
    new "我也喜欢。"

translate chinese chinese_8940743_338:
    old "Ok, then see you tomorrow?"
    new "好的，那明天见？"

translate chinese chinese_6542483_339:
    old "See you, Hinn."
    new "再见，Hinn。"

translate chinese chinese_6358391_340:
    old "Yes! We finally did it! We finished the project, even Mrs. Mia was happy with it!"
    new "太好了！我们终于做到了！我们完成了项目，甚至连米娅太太都对它很满意！"

translate chinese chinese_0608496_341:
    old "Great, now that we're done, I want to ask you if... Will you continue to accompany me to therapy sessions?"
    new "好了，现在我想问你，你会不会继续陪我一起去治疗？"

translate chinese chinese_3253801_342:
    old "FOR REAL?"
    new "真的一起？"

translate chinese chinese_4036989_343:
    old "I mean... Seriously?"
    new "我是说…… seriously？"

translate chinese chinese_4984939_344:
    old "Sure! Well, only if you want too."
    new "当然！嗯，只要你愿意。"

translate chinese chinese_0800917_345:
    old "Yes, I would like it! You have helped me a lot and I would like to continue hanging out with you."
    new "是的，我愿意！你帮了我很多，我想继续和你在一起。"

translate chinese chinese_7107980_346:
    old "You can always count on me, Hinn."
    new "你随时都可以依赖我，Hinn。"

translate chinese chinese_6326667_347:
    old "...Thank you, [pla]! I really mean it."
    new "...谢谢你，[pla]！我是真心的。"

translate chinese chinese_5682648_348:
    old "But how are you going to keep the sessions going, Doctor Johnson said we were done."
    new "但是你怎么继续这些疗程呢，约翰逊医生说我们已经结束了。"

translate chinese chinese_5518313_349:
    old "Hmm... Let me talk to her and see what I can do."
    new "嗯……让我去和她谈谈，看看能做些什么。"

translate chinese chinese_1118700_350:
    old "Great! I hope you can convince her..."
    new "太好了！希望你能说服她..."

translate chinese chinese_1969147_351:
    old "Yes me too."
    new "是的，我也是。"

translate chinese chinese_6251635_352:
    old "Thank you very much Dr. Johnson, today's session was great."
    new "非常感谢约翰逊博士，今天的疗程很棒。"

translate chinese chinese_1051957_353:
    old "I hope these tips help you, in the next session and we will analyze the progress."
    new "希望这些建议能帮到你，下次我们会分析进度。"

translate chinese chinese_6952999_354:
    old "Very well, goodbye doctor."
    new "好吧，再见医生。"

translate chinese chinese_9384127_355:
    old "Bye bye."
    new "拜拜。"

translate chinese chinese_0953594_356:
    old "Hey, hello [pla] how are you doing?"
    new "嘿，你好[pla]，最近怎么样？"

translate chinese chinese_9641061_357:
    old "I'm doing good Dr. Johnson."
    new "我挺好的，约翰逊博士。"

translate chinese chinese_6859647_358:
    old "How can I help you?"
    new "我怎么帮你？"

translate chinese chinese_9180606_359:
    old "Well... I've been thinking with Hinn... And we wonder if we can continue with the..."
    new "嗯……我和Hinn讨论过……我们在想是否可以继续……"

translate chinese chinese_1378512_360:
    old "With the?"
    new "和什么？"

translate chinese chinese_4060583_361:
    old "If we can continue with the therapy?"
    new "如果我们能继续治疗呢？"

translate chinese chinese_3648832_362:
    old "Oh, Hmm... I made an exception with you guys since that kind of session is for couple therapy..."
    new "哦，嗯……因为我看到你们是情侣，所以破例了……那种环节通常是为夫妻治疗准备的……"

translate chinese chinese_6912643_363:
    old "Hmm, could we get some more of those?"
    new "嗯，能再来点那个吗？"

translate chinese chinese_2585417_364:
    old "I don't think so, I'm sorry [pla]..."
    new "我不这么认为，对不起[pla]..."

translate chinese chinese_8056675_365:
    old "(Hmm... I think I should use it this time...)"
    new "（嗯……我觉得这次应该用一下……）"

translate chinese chinese_5120945_366:
    old "{b}Sauron's mouth:{/b}  Dr. Johnson I think you should make an exception with us..."
    new "{b}索伦的嘴：{/b} 琼森博士，我觉得你应该破例一下……"

translate chinese chinese_0880012_367:
    old "Hmm, you know what, let's make a deal..."
    new "嗯，你知道吗，咱们做个交易吧……"

translate chinese chinese_3724772_368:
    old "I'll give those therapy sessions if you help me with another patients exercise, I think you could help me with them..."
    new "如果你帮我另一个病人做练习，我就参加那些治疗课程，我觉得你能帮到我……"

translate chinese chinese_5072445_369:
    old "Help with another patients?"
    new "帮忙照顾其他病人？"

translate chinese chinese_9002932_370:
    old "Yes, I actually have a case where I think you would be a great help..."
    new "是的，我确实有一个案子，我觉得你会很有帮助……"

translate chinese chinese_3395905_371:
    old "Hmm okay, and will the therapy continue in return?"
    new "嗯，好的，那作为回报，治疗会继续吗？"

translate chinese chinese_4684212_372:
    old "Yes, I think it is an excellent deal."
    new "是的，我觉得这真是个不错的交易。"

translate chinese chinese_8745843_373:
    old "Very well then, Hinn will schedule the appointment for the next lesson."
    new "好吧，希恩会安排下次课程的预约。"

translate chinese chinese_1146599_374:
    old "Perfect, I'll let you know when I need you to work with my patient."
    new "完美，等我需要你帮我照顾病人的时候会通知你的。"

translate chinese chinese_7018893_375:
    old "Understood."
    new "明白了。"

translate chinese chinese_0555273_376:
    old "Well? What happened?"
    new "怎么样？发生什么事了？"

translate chinese chinese_0614667_377:
    old "Everything is settled, you just have to call her to make the next appointment."
    new "一切都搞定了，你只要给她打电话预约下次见面就行了。"

translate chinese chinese_9185356_378:
    old "Really? Excellent! I'll call her right away, thanks [pla]."
    new "真的吗？太好了！我马上给她打电话，谢谢[pla]。"

translate chinese chinese_1604704_379:
    old "No problem. Then, see you tomorrow?"
    new "没问题。那明天见？"

translate chinese chinese_4832189_380:
    old "Wow Hinn, you decided to not wear the jacket, I see that the sessions served you well."
    new "wow Hinn，你决定不穿夹克了，看来那些训练对你挺有帮助的。"

translate chinese chinese_8965657_381:
    old "Well, you're looking forward to continuing my therapy, uh?"
    new "嗯，你可是期待继续我的治疗吧？"

translate chinese chinese_2288935_382:
    old "Well... "
    new "嗯……"

translate chinese chinese_9986057_383:
    old "Hahaha I like to give therapy, so, don't worry guys."
    new "哈哈，我喜欢做心理咨询，所以大家不用担心。"

translate chinese chinese_9029172_384:
    old "I think I've already given you a good introduction, what do you say if we go to Hinn's practice?"
    new "我觉得我已经给你详细介绍过了，要不去希恩的练习场所怎么样？"

translate chinese chinese_9635055_385:
    old "Come on girl, don't be shy, after all you guys asked me for more lessons, right?"
    new "来吧姑娘，别害羞，反正你们是要求我多上几节课的，对吧？"

translate chinese chinese_0371505_386:
    old "Yes, yes, I'm sorry..."
    new "好，好，对不起..."

translate chinese chinese_3162745_387:
    old "All right, let's go step by step, ok?"
    new "好吧，我们一步一步来，好吗？"

translate chinese chinese_9111654_388:
    old "[pla] take off your shorts and sit on the couch, you come with me Hinn..."
    new "[pla] 脱掉短裤，坐在沙发上，你跟我过来，Hinn..."

translate chinese chinese_3685763_389:
    old "Oh yeah take it like that, fill your hand completely right?"
    new "哦 yeah，就这样接受吧，把手弄得满满的对吧？"

translate chinese chinese_5617397_390:
    old "How does it feel Hinn..."
    new "感觉怎么样，Hinn..."

translate chinese chinese_0847765_391:
    old "Warm and... Hard..."
    new "温暖而……坚硬……"

translate chinese chinese_0978088_392:
    old "Hahaha the advantages of youth."
    new "哈哈，年轻的好处啊。"

translate chinese chinese_7598045_393:
    old "All right guys I think that's it for this lesson."
    new "好了，大家，我觉得这节课就到这里吧。"

translate chinese chinese_2624423_394:
    old "I think you both enjoyed it a lot, and you already have some things to practice at home..."
    new "我觉得你们两个都很享受，而且已经有了一些可以在家练习的东西……"

translate chinese chinese_3290939_395:
    old "It was really a pleasure guys, I'll wait for you for the next lesson..."
    new "真是很高兴 guys, 我会在下次课等你们..."

translate chinese chinese_7816371_396:
    old "That was... Fun."
    new "那真是……好玩。"

translate chinese chinese_1405954_397:
    old "Yes, I think it was... Very educational."
    new "是的，我觉得这……非常有教育意义。"

translate chinese chinese_9293661_398:
    old "Hehehe yes it was..."
    new "嘿嘿嘿，是的……"

translate chinese chinese_4906843_399:
    old "Well, see you tomorrow Hinn."
    new "好吧，明天见，Hinn。"

translate chinese chinese_3796161_400:
    old "Hi Hinn, how are you?"
    new "嗨，Hinn，你好吗？"

translate chinese chinese_4586253_401:
    old "I'm great-"
    new "我很好-"

translate chinese chinese_7404337_402:
    old "Wow, did you lose your ugly sweatshirt girl?"
    new "哇，你把那个难看的卫衣女孩弄丢了？"

translate chinese chinese_1373415_403:
    old "Yes, don't you feel sorry to show that fatness?"
    new "是啊，难道不觉得露那种胖乎乎的样子有点不好意思吗？"

translate chinese chinese_5619334_404:
    old "Really, you aga-"
    new "真的，你又——"

translate chinese chinese_5490924_405:
    old "Are you talking about my big boobs? You envious Ruby jerk?"
    new "你在说我大胸吗？你这嫉妒的Ruby混蛋？"

translate chinese chinese_1868428_406:
    old "What ?! I envy? I don't know what-"
    new "什么？！嫉妒？我不知道你在说什么-"

translate chinese chinese_9300963_407:
    old "Ohh sorry, I'm a woman with a really good body and some brain..."
    new "哦，对不起，我是个身材很好还有点脑子的女人……"

translate chinese chinese_8105893_408:
    old "Ouchh..."
    new "好疼..."

translate chinese chinese_0054226_409:
    old "Ohh I'm sorry, was it too much for your little head? Maybe tomorrow you will understand it..."
    new "哦，对不起，这对你的小脑袋来说是不是太复杂了？也许明天你会懂的……"

translate chinese chinese_1424192_410:
    old "Right now I don't have time to waste with a couple of stupid brainless girls like you. See ya..."
    new "现在我没时间浪费在一个像你这样的愚蠢女孩身上。拜拜了..."

translate chinese chinese_8153265_411:
    old "Hehehe see ya..."
    new "嘿嘿嘿，再见了..."

translate chinese chinese_1027318_412:
    old "Oh you shut up, loser!"
    new "哦你闭嘴，输家！"

translate chinese chinese_2154558_413:
    old "Ugh, sorry..."
    new "呃，对不起……"

translate chinese chinese_5816922_414:
    old "Wow Hinn that was great!"
    new "哇，_HINT，太棒了！"

translate chinese chinese_2767673_415:
    old "It doesn't matter, come sit on the couch."
    new "没关系，过来坐沙发吧。"

translate chinese chinese_2523450_416:
    old "What? What for?"
    new "什么？为什么？"

translate chinese chinese_2893720_417:
    old "I'm going to suck it you, sit down..."
    new "我要亲你，坐下来..."

translate chinese chinese_6501127_418:
    old "(What the...) All right."
    new "（什么……）好吧。"

translate chinese chinese_0192635_419:
    old "Are you sure-"
    new "你确定-"

translate chinese chinese_1522484_420:
    old "You just watch and enjoy."
    new "你就看着享受吧。"

translate chinese chinese_3614621_421:
    old "Sorry, sorry. I was so impulsive... I just felt adrenaline after what happened and I wanted to try-"
    new "对不起，对不起。我太冲动了……刚才发生那种事之后我就热血上头，想试试看——"

translate chinese chinese_5280654_422:
    old "No, don't worry, I'm amazed at your progress, you're more confident."
    new "不，别担心，我对你进步这么大感到惊讶，你更自信了。"

translate chinese chinese_6718179_423:
    old "And I like that."
    new "而且我喜欢这样。"

translate chinese chinese_7536724_424:
    old "Yes, it was exciting."
    new "是的，那真的很刺激。"

translate chinese chinese_2358223_425:
    old "I think Dr. Johnson has helped a lot."
    new "我觉得约翰逊博士帮了很大的忙。"

translate chinese chinese_1750480_426:
    old "You bet she has..."
    new "那还用说……"

translate chinese chinese_7534559_427:
    old "Well, I think my mom will be here soon, we can continue tomorrow, what do you think?"
    new "嗯，我觉得我妈妈很快就会回来，我们可以明天继续，你觉得怎么样？"

translate chinese chinese_3331167_428:
    old "Sure, see you tomorrow Hinn."
    new "好的，明天见，Hinn。"

translate chinese chinese_6754359_429:
    old "I love it."
    new "我超爱的。"

translate chinese chinese_4478848_430:
    old "I'm glad you liked."
    new "很高兴你喜欢。"

translate chinese chinese_4933895_431:
    old "Whenever you want another one we could practice again."
    new "什么时候想再来一次我们就再练习吧。"

translate chinese chinese_6897444_432:
    old "Great. See you tomorrow."
    new "好的，明天见。"

translate chinese chinese_7819831_433:
    old "Good night Hinn."
    new "晚安，Hinn。"

translate chinese chinese_2748590_434:
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy session."
    new "我很好，谢谢[pla]。我在等你，今天是新的治疗课程。"

translate chinese chinese_1777308_435:
    old "Hi guys! Think you're ready to go on with the lessons, uh?"
    new "大家好！觉得准备好继续上课了吗？"

translate chinese chinese_3044016_436:
    old "Yes, but we would like to try something more advanced..."
    new "是的，但我们想尝试一些更高级的东西……"

translate chinese chinese_6929041_437:
    old "Hahaha, that's what I wanted to hear. And what about you [pla]? Ready for the next level?"
    new "哈哈，这就是我想听的。那你呢，[pla]？准备好迎接下一个阶段了吗？"

translate chinese chinese_2834641_438:
    old "... Well-"
    new "... 嗯——"

translate chinese chinese_5991357_439:
    old "Great, let's not waste any more time..."
    new "好，不要再浪费时间了……"

translate chinese chinese_8642134_440:
    old "Let's heat the situation up a bit, since you want something more advanced Hinn, let's try a double blowjob."
    new "既然你想来点高级的，希恩，我们试试双口吧，让气氛热一下。"

translate chinese chinese_1124548_441:
    old "I hope it's not too much for you..."
    new "希望这对你来说不是太过了……"

translate chinese chinese_3149445_442:
    old "Okay, let's try it."
    new "好吧，咱们试试看。"

translate chinese chinese_7754909_443:
    old "Hahaha who are you and what did you do with Hinn?"
    new "哈哈哈哈哈，你是谁，把希恩怎么了？"

translate chinese chinese_5927024_444:
    old "All right [pla] down your pants and Hinn you bend down with me."
    new "好吧，[pla]，把裤子脱了，Hinn，你也和我一起蹲下。"

translate chinese chinese_5353739_445:
    old "With your tongue, stimulate the tip of the penis."
    new "用舌头刺激阴茎的顶端。"

translate chinese chinese_9521954_446:
    old "This drives any man crazy..."
    new "这能把任何一个男人逼疯..."

translate chinese chinese_1153009_447:
    old "Hmm, I think you guys are ready to do it right?"
    new "嗯，我觉得你们准备好做那个了吧？"

translate chinese chinese_9695605_448:
    old "Do... What?"
    new "做……什么？"

translate chinese chinese_5137012_449:
    old "Fuck, let's fuck guys..."
    new "妈的，咱们干吧……"

translate chinese chinese_8504683_450:
    old "Come with me."
    new "跟我来。"

translate chinese chinese_4335705_451:
    old "This is a practice room that I use with some patients."
    new "这是我和一些病人使用的练习室。"

translate chinese chinese_2156410_452:
    old "Come on guys take off your clothes, today you are going to have sex!"
    new "来吧，把衣服脱了，今天你们要发生关系！"

translate chinese chinese_4175636_453:
    old "What's up [pla]? Now are you the shy one?"
    new "怎么了[pla]？现在你害羞了？"

translate chinese chinese_1876011_454:
    old "Maybe you need some example..."
    new "maybe你需要个例子..."

translate chinese chinese_1465541_455:
    old "Well? What are you waiting for, you're the only one with clothes, don't you want to fuck this cute Hinn?"
    new "喂？你在等什么，你是这里唯一穿衣服的，你不想要这个可爱的Hinn吗？"

translate chinese chinese_4964435_456:
    old "All right, as I know this is probably your first time, let's go smooth and slow..."
    new "好吧，我知道这可能是你的第一次，我们慢慢来……"

translate chinese chinese_2277572_457:
    old "Let me lubricate it well before we start."
    new "我们在开始前先润滑一下吧。"

translate chinese chinese_0852790_458:
    old "Well guys, I hope to see you for a lesson soon... You can continue your practices in the meantime."
    new "好吧，大家，希望不久能见到你们来上课……你们可以先继续练习。"

translate chinese chinese_8105477_459:
    old "Yes, it was a lot of fun."
    new "是的，那真的很有趣。"

translate chinese chinese_9296172_460:
    old "Great, I think that's it for today let's get dressed and go to the office."
    new "好了，今天就到这里吧，我们穿好衣服去办公室。"

translate chinese chinese_7476360_461:
    old "Well guys, I hope to see you for a next lesson soon... You can continue your practices in the meantime."
    new "好吧，大家，希望很快能在下一节课见到你们……你们可以在这期间继续练习。"

translate chinese chinese_5773248_462:
    old "Alright, see you in the next lesson."
    new "好，下次课见。"

translate chinese chinese_5407088_463:
    old "I'm great thanks [pla]. I was waiting for you, today is the new therapy sesion."
    new "我很好，谢谢[pla]。我在等你，今天是新的治疗 session。"

translate chinese chinese_9315591_464:
    old "What do we have here? Ready for another hardcore sex lesson?"
    new "这是什么？准备好再来一节硬核性爱课程了吗？"

translate chinese chinese_9702915_465:
    old "Haha that's great..."
    new "哈哈，真好……"

translate chinese chinese_7764941_466:
    old "So, are we going to the couch?"
    new "那么，去沙发吗？"

translate chinese chinese_8921399_467:
    old "Ohh no, let's not waste time, let's go directly to a more comfortable place..."
    new "哦不，别浪费时间了，我们直接去一个更舒服的地方吧……"

translate chinese chinese_6231499_468:
    old "Alright lie down on the bed [pla] and Hinn get on top of him."
    new "好吧，躺在床上[pla]，然后Hinn爬到他身上。"

translate chinese chinese_5290989_469:
    old "We're going to lubricate that cock well while [pla] giving you some pleasure."
    new "我们会好好润滑那个家伙的同时，给你一些快感。"

translate chinese chinese_4273193_470:
    old "All right, are you ready for another hardfuck Hinn?"
    new "好吧，你准备好再来一次激烈的Hinn了吗？"

translate chinese chinese_7302393_471:
    old "I've seen that [pla] has been looking at my big boobs a lot, uh?"
    new "我注意到[pla]老是盯着我的大胸部看，嗯？"

translate chinese chinese_9397718_472:
    old "... No, no, I just-"
    new "……不，不，我只是-"

translate chinese chinese_4965586_473:
    old "Hahaha, come on I've already sucked your penis, there's no reason to be ashamed."
    new "哈哈，都吸过你的鸡巴了，没什么好害羞的。"

translate chinese chinese_1225976_474:
    old "Actually, today while you fuck Hinn you are going to enjoy my soft and big boobs..."
    new "实际上，今天当你和Hinn做爱的时候，你会喜欢上我的柔软大胸..."

translate chinese chinese_6208338_475:
    old "Another successful session guys... Let's get dressed."
    new "又成功了一次……咱们赶紧穿衣服吧。"

translate chinese chinese_4148010_476:
    old "All right that's it for today, I hope to see you soon for a next lesson guys."
    new "好吧，今天就到这里，希望很快能在下一课见到大家。"

translate chinese chinese_1969249_477:
    old "Of course we will Dr. Johnson."
    new "当然了，约翰逊博士。"

translate chinese chinese_6442083_478:
    old "Oh, but here are my favorite patients... Hehehe."
    new "哦，但这些都是我最喜欢的病人……嘿嘿嘿。"

translate chinese chinese_8376195_479:
    old "Good afternoon Dr. Johnson."
    new "下午好，约翰逊博士。"

translate chinese chinese_3393760_480:
    old "How are you guys? Ready for our last lesson?"
    new "你们怎么样？准备好上最后一课了吗？"

translate chinese chinese_7208231_481:
    old "Last lesson?"
    new "最后一课？"

translate chinese chinese_4354909_482:
    old "Yes, I think you already have the basics, it is important that you now experience for yourselves to discover your own sexuality."
    new "是的，我觉得你已经掌握了基础，现在重要的是你们亲自体验，去发现自己的性欲。"

translate chinese chinese_5364358_483:
    old "But... Can't we go on?"
    new "但是……我们不能继续吗？"

translate chinese chinese_0093835_484:
    old "Well, we could repeat some of the lessons we've already done..."
    new "嗯，我们可以重复一些已经做过的课程……"

translate chinese chinese_7498622_485:
    old "Oh great, sounds good..."
    new "哦，听起来不错……"

translate chinese chinese_4827641_486:
    old "So, what will we do today?"
    new "那，今天我们做什么？"

translate chinese chinese_2370723_487:
    old "Let's go to the room and I'll explain."
    new "我们去房间里再说。"

translate chinese chinese_9070579_488:
    old "All right, let's heat things up a bit by lubricating it well, you know what to do."
    new "好吧，让我们加点热度，好好润滑一下，你知道该怎么做。"

translate chinese chinese_3944089_489:
    old "Well, that was great, now you [pla] are going to fuck Hinn alone."
    new "好吧，那现在你就得独自和Hinn上床了。"

translate chinese chinese_6819238_490:
    old "Alone?"
    new "一个人？"

translate chinese chinese_2615036_491:
    old "Yes, I will just be watching, the idea is that you can continue to do it yourself so that you can enjoy your sexuality alone."
    new "好的，我就看着，你可以继续自己做，这样你可以独自享受你的性欲。"

translate chinese chinese_0684161_492:
    old "Hmm ok."
    new "嗯，好吧。"

translate chinese chinese_7924762_493:
    old "Well guys, that was it for today, get dressed."
    new "好了，今天就到这儿，穿上衣服吧。"

translate chinese chinese_4461248_494:
    old "I think it's time for you to practice what you learned. Enjoy it guys!"
    new "我觉得是你实践所学的时候了。大家玩得开心点！"

translate chinese chinese_2201924_495:
    old "If you want to repeat one of the lessons, don't hesitate to come back."
    new "如果你想重修某个课程，随时可以回来。"

translate chinese chinese_2301695_496:
    old "I'm great, What about you?"
    new "我很好，你呢？"

translate chinese chinese_3734106_497:
    old "So? Would you like to repeat some session with Dr. Johnson?"
    new "那么？你想再和约翰逊博士进行一些疗程吗？"

translate chinese chinese_8643326_498:
    old "Of course! Let's do it."
    new "当然！咱们就這麼定了。"

translate chinese chinese_1425413_499:
    old "I really would like to... But I can't right now."
    new "我真的想……但是现在不行。"

translate chinese chinese_9933448_500:
    old "Oh don't worry you can look for me if you change your mind."
    new "哦，别担心，如果你改变主意了可以来找我。"

translate chinese chinese_6752170_501:
    old "I will do it."
    new "我会做的。"

translate chinese chinese_5431207_502:
    old "I knew it would not take long for you to return from the last session."
    new "我就知道你不会很久就从上次的环节回来。"

translate chinese chinese_0993331_503:
    old "So? What do you want to do today guys?"
    new "那么？今天你们想做什么？"

translate chinese chinese_8888425_504:
    old "Oh, you guys want to go from the beginning, right?"
    new "哦，你们是想从头来过，对吧？"

translate chinese chinese_6481174_505:
    old "I like it! Let's do it."
    new "我喜欢！就这么办。"

translate chinese chinese_3509838_506:
    old "It always surprises me!"
    new "这总是让我感到惊讶！"

translate chinese chinese_6296112_507:
    old "Well, let's do it..."
    new "好吧，那我们就这么做吧..."

translate chinese chinese_7118403_508:
    old "Do you need another blowjob lesson? Uh? Or just [pla] want a good blowjob from me?"
    new "你需要再上一堂口交课吗？嗯？还是只是想让我给你一个棒的口交？"

translate chinese chinese_5002097_509:
    old "Anyway... I like it! Let's do it."
    new "不管怎样……我喜欢！就这么办。"

translate chinese chinese_8200391_510:
    old "O third lesson, let's team up to give [pla] a great amount of pleasure!"
    new "好的，让我们一起给[pla]带来极大的愉悦吧！"

translate chinese chinese_0726403_511:
    old "Your cock is in one of biggest I've ever saw."
    new "你的 cock 是我见过最大的之一。"

translate chinese chinese_2008863_512:
    old "Double blowjob and Doggystyle? How great does it sounds?"
    new "双口服务再加狗仔式？听起来多带劲啊？"

translate chinese chinese_4463954_513:
    old "And you are becoming some kind of expert Hinn!"
    new "而且你正在变成某种专家呢，Hinn！"

translate chinese chinese_6002206_514:
    old "Lesson 5"
    new "第五课"

translate chinese chinese_3140524_515:
    old "Do you want to have my boobs on your face while you fuck Hinn, uh?"
    new "你想在我揉着你的脸的时候操hin吧？"

translate chinese chinese_6078206_516:
    old "Lesson 6"
    new "第六课"

translate chinese chinese_1808934_517:
    old "Oh god, I'm dying to see that pretty face covered with a good facial."
    new "哦天啊，真想看看那张漂亮的脸蛋敷上面膜的样子。"

translate chinese chinese_7497006_518:
    old "Alright lie down on the bed [pla] and your Hinn get on top of him."
    new "好吧，你先躺在床上[pla]，然后你的Hinn爬到他身上。"

translate chinese chinese_7958401_519:
    old "All right guys, that was fun, but it's all for today."
    new "好了大家，今天就到这里，玩得开心吗？"

translate chinese chinese_6234462_520:
    old "Will come back soon..."
    new "很快就会回来..."

translate chinese chinese_9532591_521:
    old "I will be waiting."
    new "我就等着吧。"

translate chinese chinese_6381134_522:
    old "See you soon Dr Johnson."
    new "很快再见，约翰逊博士。"

translate chinese chinese_1018773_523:
    old "That was hot, right?"
    new "那真是辣眼睛，对吧？"

translate chinese chinese_4940160_524:
    old "Yes, it was great."
    new "是的，太棒了。"

translate chinese chinese_0783918_525:
    old "Hehehe do want to repeat it tomorrow?"
    new "嘿嘿嘿，明天还想再来一次吗？"

translate chinese chinese_4703425_526:
    old "Nice, then see you tomorrow [pla]."
    new "不错，那明天见了，[pla]。"

translate chinese chinese_7945995_527:
    old "Ok, see you tomorrow Hinn."
    new "好的，明天见，Hinn。"

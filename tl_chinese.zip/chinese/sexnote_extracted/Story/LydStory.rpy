# auto-tl Qwen Colab

translate chinese chinese_5073659_0:
    old "I mean mom, online dating?!! What the fuck?!!!"
    new "我是说妈妈，网上交友？！！你在开玩笑吧？！！"

translate chinese chinese_9092886_1:
    old "You couldn't think about anything else?"
    new "你就不能想想别的吗？"

translate chinese chinese_8467220_2:
    old "Why don't you just join a knitting group? Or play bingo like any other widow?"
    new "你为什么不加入个编织小组呢？或者像其他寡妇一样去玩宾果游戏？"

translate chinese chinese_6429181_3:
    old "What's so bad about what I said?"
    new "我说的有什么不对吗？"

translate chinese chinese_2562895_4:
    old "I don't think there's anything wrong with a single woman thinking about meeting new people."
    new "我觉得一个单身女人想认识新朋友没什么不对的。"

translate chinese chinese_1285704_5:
    old "Now that your father's not here I'd like to make some new friends, and..."
    new "现在你爸爸不在了，我想交些新朋友，而且..."

translate chinese chinese_0350075_6:
    old "Do you think you're at the age where you should be meeting people through a dating app?"
    new "你认为你现在到了该通过约会软件认识人的年龄了吗？"

translate chinese chinese_0807169_7:
    old "Besides, who the hell is going to talk to you? To a widowed grandmother?"
    new "再说，谁会理你这个寡妇奶奶？"

translate chinese chinese_9410803_8:
    old "If you want to meet new people why don't you just go to an elderly home?"
    new "如果你想认识新朋友，为什么不去养老院呢？"

translate chinese chinese_0138975_9:
    old "Maybe there you'll find some people your age."
    new "也许你会找到一些同龄人。"

translate chinese chinese_2330901_10:
    old "It's that way to talk to your mother?"
    new "这就是你跟你妈说话的态度？"

translate chinese chinese_2383562_11:
    old "Are you listening to yourself?"
    new "你在听你自己说话吗？"

translate chinese chinese_0411604_12:
    old "I don't care!"
    new "我才不在乎呢！"

translate chinese chinese_2260411_13:
    old "You should be the one thinking about what you're saying! Dad's not even been dead for a year!"
    new "你应该想想自己在说什么！爸爸去世还不到一年呢！"

translate chinese chinese_7645258_14:
    old "And here you are thinking about picking guys up like you're some... Ugh!"
    new "而你还在想着搭讪男生，就像你是个……哎！"

translate chinese chinese_1357568_15:
    old "I don't want my mother to go around giving herself up to some randoms on the internet."
    new "我不希望我妈妈在网上随便跟陌生人发生关系。"

translate chinese chinese_5679139_16:
    old "Listen, you can do what you want, but don't expect me to help you with anything..."
    new "听着，你可以随便做你想做的事，但别指望我会帮你什么..."

translate chinese chinese_2596376_17:
    old "Ugh! I don't even want to keep talking to you!"
    new "哎！我甚至不想再跟你说了！"

translate chinese chinese_3266018_18:
    old "Uh, hi..."
    new "呃，嗨……"

translate chinese chinese_1845637_19:
    old "[pla]! H- hi!"
    new "[pla]！嗨！"

translate chinese chinese_3770112_20:
    old "I hope you didn't see much of what just happened..."
    new "希望你没看到刚才发生太多的事情……"

translate chinese chinese_0874997_21:
    old "Uhhh... Just the last bit of it, I think..."
    new "呃……就最后一点了吧……"

translate chinese chinese_7059459_22:
    old "All I heard was Anna being as annoying as always."
    new "我只听到安娜一如既往地烦人。"

translate chinese chinese_7215840_23:
    old "What's the matter? Why is she acting up now?"
    new "怎么了？她现在为什么要闹别扭？"

translate chinese chinese_2043229_24:
    old "Well... How can I put it?"
    new "嗯……该怎么说呢？"

translate chinese chinese_2304576_25:
    old "Do you remember the other day when you went with me to church?"
    new "你还记得那天陪我去教堂的事吗？"

translate chinese chinese_8358319_26:
    old "Hmmm, yeah."
    new "嗯，是的。"

translate chinese chinese_8928827_27:
    old "The thing is, ever since we ran into Mrs. Jones, I've been thinking and..."
    new "其实，自从我们遇到琼斯太太后，我就一直在想……"

translate chinese chinese_8340055_28:
    old "I don't want to be like that [pla]. Her husband died five years ago, and she's been unable to move on from that."
    new "我不想变成那样。她的丈夫五年前去世了，她一直无法走出那段阴影。"

translate chinese chinese_1126492_29:
    old "She hasn't moved on? What do you mean?"
    new "她还没放下？你是说什么意思？"

translate chinese chinese_2395585_30:
    old "You know, all she ever does is talk about God and faith. Frankly, it's pitying."
    new "你知道吗，她成天就只会谈论上帝和信仰。坦白说，真让人觉得可怜。"

translate chinese chinese_1776855_31:
    old "I decided I don't want that to happen to me too."
    new "我决定不想让我也发生那样的事情。"

translate chinese chinese_3442821_32:
    old "So, I've been trying to get myself out there, I've gone to a couple of bars, and clubs."
    new "所以，我最近试着多出去一下，去了几家酒吧和夜店。"

translate chinese chinese_3643248_33:
    old "Trying to meet new people, you know?"
    new "就是想认识一些新朋友嘛。"

translate chinese chinese_1342460_34:
    old "But, it's been to no avail. It turns out people don't really go to bars or clubs to meet new people anymore."
    new "但是，这并没有什么用。原来人们去酒吧或俱乐部已经不再是为了结识新人了。"

translate chinese chinese_6042633_35:
    old "It's not as common to go out to meet new people. Nowadays, if someone goes out it's because they already have plans with someone else."
    new "出去认识新人都不太常见了。现在出去一般都是已经有约了。"

translate chinese chinese_7811613_36:
    old "So, I thought maybe I should do what I heard young people are doing these days, and try online dating."
    new "所以，我想我应该试试年轻人现在流行的东西，网上交友。"

translate chinese chinese_0707791_37:
    old "Well, that sounds like a good idea."
    new "嗯，那听起来像是个好主意。"

translate chinese chinese_5493291_38:
    old "I guess so, but the whole internet thing just flies over my head. It's so complicated."
    new "大概吧，但整个互联网的事情我根本搞不懂，太复杂了。"

translate chinese chinese_2045933_39:
    old "Given that I can't really do it myself I asked Anna to help me out."
    new "因为我自个儿搞不定，所以就请安娜帮忙了。"

translate chinese chinese_0302999_40:
    old "But, you already saw how that turned out."
    new "但是，你已经看到结果了。"

translate chinese chinese_3147740_41:
    old "Hmph, I did..."
    new "哼，我确实……"

translate chinese chinese_6582661_42:
    old "Although maybe she's right. Maybe I'm just too old to be thinking about doing things like online dating and such."
    new "虽然也许她说得对。也许我只是太老了，不适合考虑网上交友这类事情。"

translate chinese chinese_7151337_43:
    old "I'm just an old, lonely widow after all... So I'll just give up."
    new "我不过是个老寡妇罢了……所以我就放弃吧。"

translate chinese chinese_5346022_44:
    old "Woah, woah, wait a minute."
    new "喂，喂，等一下。"

translate chinese chinese_8923722_45:
    old "Listen, you don't have to say all those bad things about you, and you also shouldn't say that you're going to give up."
    new "听着，你不用说这么多自己的坏话，也不应该说你要放弃。"

translate chinese chinese_8503827_46:
    old "I actually agree with you, you have every right to live your life any way you want to."
    new "我实际上同意你的观点，你有权以任何方式生活。"

translate chinese chinese_6792915_47:
    old "Anna's just jealous because you're her mother. And she's always very possessive."
    new "安娜只是因为你是她的妈妈而嫉妒而已。而且她总是非常占有欲强。"

translate chinese chinese_8509413_48:
    old "But you're free to do whatever you want. And I'm totally sure you can be with anyone you want to."
    new "但你可以随心所欲。我完全确定你可以和你想的人在一起。"

translate chinese chinese_4013983_49:
    old "Of course I do! Anyone would be lucky to meet you. I'm sure of it."
    new "那当然了！能遇到你谁都会觉得幸运的。我敢肯定。"

translate chinese chinese_3393873_50:
    old "In fact, if Anna won't do it. Let me help you, I'll set up your profile for you."
    new "事实上，如果安娜不愿意做的话，让我来帮你吧，我给你设置一下个人资料。"

translate chinese chinese_0954205_51:
    old "Of course, I'll do it right now."
    new "当然，我马上就做。"

translate chinese chinese_9745608_52:
    old "Ohh! That's so nice of you! Thank you [pla]!"
    new "哦！你真好！谢谢你[pla]！"

translate chinese chinese_7810514_53:
    old "Let's go to my room, my computer's there."
    new "去我的房间吧，电脑在那里。"

translate chinese chinese_6537372_54:
    old "Oh no, there's no need. These days the best and easiest ways to meet people online are dating apps."
    new "哦不，不用了。这些天在网上认识人的最好最简单的方式就是约会应用了。"

translate chinese chinese_9244242_55:
    old "You know, on the phone. Have you ever heard of Tinder?"
    new "你知道的，就是在电话里。你听说过Tinder吗？"

translate chinese chinese_9110569_56:
    old "Tinder? No, no idea what it is."
    new "Tinder？不，不知道那是什么。"

translate chinese chinese_1938775_57:
    old "Well, it's this new dating app, in which you create a profile with your information on it."
    new "其实就是这个新的约会应用，你可以创建一个包含个人信息的资料。"

translate chinese chinese_8386834_58:
    old "The profile is public, so anyone can see it, and decide if they would like to talk to you or not."
    new "这个资料是公开的，所以任何人都可以看到，并决定是否想和你聊天。"

translate chinese chinese_7511811_59:
    old "I see, what kind of information should go in there?"
    new "我明白了，那里应该填什么信息呢？"

translate chinese chinese_3259985_60:
    old "Nothing private, just the type of person you are, what you like and dislike."
    new "没什么私人的，就是你的性格，你喜欢什么不喜欢什么。"

translate chinese chinese_9284351_61:
    old "And a couple of pictures of you, so they know how you look."
    new "还有一些你的照片，让他们知道你长什么样。"

translate chinese chinese_6390738_62:
    old "You can also write what you want to find in a partner, so they know if you'll like them."
    new "你也可以写下你希望在伴侣身上找到什么，这样他们就知道你是否喜欢他们。"

translate chinese chinese_3121940_63:
    old "That sounds interesting. How does it work?"
    new "听起来挺有意思的。它是怎么工作的？"

translate chinese chinese_2627398_64:
    old "It's very simple, once your profile is on the app it will be visible to people in it."
    new "很简单，一旦你的资料上了应用程序，就会被里面的人看到。"

translate chinese chinese_6335366_65:
    old "And they get to decide if they would like to meet you."
    new "他们可以决定是否想见你。"

translate chinese chinese_3676860_66:
    old "If they do, all they have to do is swipe your profile to the right, if they don't they swipe left."
    new "如果他们感兴趣，就向右滑你的资料，如果不感兴趣就向左滑。"

translate chinese chinese_5035757_67:
    old "And it's the same with you, if you see a profile you swipe either right or left, depending on if you like them or not."
    new "对你也一样，看到一个资料页，你喜欢就往右滑，不喜欢就往左滑。"

translate chinese chinese_4709235_68:
    old "If both of you swipe right, that means it's a match, and you can both start talking."
    new "如果你们俩都右滑，那就表示匹配成功，你们就可以开始聊天了。"

translate chinese chinese_3698435_69:
    old "Hmm, that sounds very simple and practical."
    new "嗯，那听起来很简单也很实用。"

translate chinese chinese_1551122_70:
    old "It is, come on, I'll help you set your profile."
    new "是的，快点，我帮你设置个人资料。"

translate chinese chinese_8959945_71:
    old "Ok, so, first of all, is setting up your bio, it's just a small description of you and the things you like and your interests."
    new "好的，首先，设置你的个人资料，就是对你自己、你喜欢的东西和兴趣爱好做一个简单的描述。"

translate chinese chinese_9890130_72:
    old "Ok, so let me see, hmm... I got it!"
    new "好的，让我想想，嗯……我想到了！"

translate chinese chinese_1593567_73:
    old "I'm a single woman who enjoys the simple things in life. I love long walks, enjoying nature and talking."
    new "我是一个单身女性，喜欢生活中的简单事物。我喜欢长时间散步、享受大自然和聊天。"

translate chinese chinese_5433338_74:
    old "My perfect evening is a summer afternoon enjoying a glass of merlot and reading a good book."
    new "我完美的夜晚是在夏天的下午，喝一杯梅洛红酒，读一本好书。"

translate chinese chinese_9301354_75:
    old "Ok, so that's your profile all set."
    new "好的，这样你的资料就设置好了。"

translate chinese chinese_6992759_76:
    old "Oh wow, that took no time, and it looks great!"
    new "哦 wow，这么快就搞定了，看起来还很不错！"

translate chinese chinese_6548227_77:
    old "So? What do I do now?"
    new "那怎么办？我现在该做什么？"

translate chinese chinese_8398909_78:
    old "Well, now that you have your own profile, what you have to do is look at other people's profiles."
    new "好吧，现在你有了自己的个人资料，接下来你要看别人的资料了。"

translate chinese chinese_7700506_79:
    old "And see if you like any of them. You do this by swiping right or left..."
    new "看看有没有你喜欢的。你可以通过向右或向左滑来选择..."

translate chinese chinese_8406806_80:
    old "Woah, woah, that's a little too fast for me, and it sounds a bit complicated."
    new "喂喂，这对我来说有点太快了，听起来还挺复杂的。"

translate chinese chinese_4259330_81:
    old "Hmm, why don't you do it for me?"
    new "嗯，你帮我做吧？"

translate chinese chinese_9554762_82:
    old "Hmm... ok sure, no problem, it's not hard, once you get it, it will be really easy."
    new "嗯……好的，没问题，其实不难，一旦掌握了就很简单了。"

translate chinese chinese_3608156_83:
    old "Alright, let's start, but, if I'm the one doing it, I won't know what kind of guy you're into."
    new "好吧，我们开始吧，但是，如果我来选的话，就不知道你喜欢什么类型的男生了。"

translate chinese chinese_3570103_84:
    old "Why don't you tell me what you're looking for in a man?"
    new "你为什么不告诉我你想要男人有什么样的品质呢？"

translate chinese chinese_0210459_85:
    old "That way I'll know who to select."
    new "这样我就知道该选谁了。"

translate chinese chinese_3894078_86:
    old "What I'm looking for? Hmm, let's see..."
    new "我找的东西？嗯，让我想想……"

translate chinese chinese_1959785_87:
    old "Well, I tend to like guys with beards, I think they look very manly, but it's not a requirement."
    new "嗯，我比较喜欢有胡子的男生，觉得他们看起来很男人，但这不是必须的。"

translate chinese chinese_7733520_88:
    old "Hmm, ok, I'll keep that in mind."
    new "嗯，好吧，我会记住的。"

translate chinese chinese_9387802_89:
    old "But, be sure that it's a beard, not a mustache, I hate mustaches."
    new "但是，一定要弄成胡子，不是山羊胡，我讨厌山羊胡。"

translate chinese chinese_9022632_90:
    old "My husband used to have one and I was never able to get him to shave it."
    new "我老公以前有的，但我从来没让他剃掉。"

translate chinese chinese_3762664_91:
    old "Sure, that's an important detail."
    new "好吧，那是个重要细节。"

translate chinese chinese_4922961_92:
    old "Anything else?"
    new "还有别的吗？"

translate chinese chinese_0176482_93:
    old "I don't like bald men, I prefer a nice head of hair, but no white hair, not even at the sides."
    new "我不喜欢秃头的男人，我喜欢一头好头发，但不要有白发，哪怕是两边也不行。"

translate chinese chinese_9516809_94:
    old "Alright, no bald men or white hair."
    new "好吧，不要秃头或白发。"

translate chinese chinese_0952111_95:
    old "Well, to be honest, I'm looking for a young guy, so I'd rather he didn't look old, like wrinkles and stuff..."
    new "好吧，说实话，我在找一个年轻男孩，所以不太希望他看起来老气横秋，比如满脸皱纹之类的……"

translate chinese chinese_4513016_96:
    old "Got it. Something else?"
    new "明白了。还有别的吗？"

translate chinese chinese_1655139_97:
    old "Oh right, I don't know why but I have never been into gingers... So, no red hair, nothing personal..."
    new "哦对，不知道为什么我从来不喜欢红头发的……所以，不是针对你个人……"

translate chinese chinese_0595284_98:
    old "Hmm, Ok, I think I got everything. I'll try my best to find you someone like that."
    new "嗯，好的，我想我明白你的意思了。我会尽力帮你找到这样的人。"

translate chinese chinese_6789491_99:
    old "Woah, thank you pumpkin, this is exciting!"
    new "哇，谢谢你，这真是太刺激了！"

translate chinese chinese_7867559_100:
    old "Ok Lydia, here you go, I think I got just what you wanted."
    new "好的莉迪亚，给你，我觉得这正是你想要的。"

translate chinese chinese_5509484_101:
    old "And look at that, you already matched with a couple of them!"
    new "看看，你已经和几个匹配上了！"

translate chinese chinese_3936270_102:
    old "If you want to you can start talking with them."
    new "如果你想的话，可以开始和他们聊天。"

translate chinese chinese_4918484_103:
    old "That's wonderful pumpkin!"
    new "太棒了，小南瓜！"

translate chinese chinese_0967943_104:
    old "Oh, they all look very interesting indeed!"
    new "哦，看起来都很有趣呢！"

translate chinese chinese_6863956_105:
    old "This is great, I'll start talking to them."
    new "太好了，我开始和他们聊天吧。"

translate chinese chinese_8922535_106:
    old "I'm glad you think they're good picks."
    new "很高兴你觉得这些选择不错。"

translate chinese chinese_1155568_107:
    old "I do, they look great."
    new "我有，它们看起来很棒。"

translate chinese chinese_1119031_108:
    old "Now listen [pla], I'm very happy and thankful that you're helping me with this."
    new "现在听好了[pla]，我非常高兴和感激你能帮我做这件事。"

translate chinese chinese_4509692_109:
    old "But, Anna might come back soon, and I fear what she'll say if she sees us doing this."
    new "但是，安娜很快可能会回来，如果她看到我们在做这个，我不知道她会怎么说。"

translate chinese chinese_7556717_110:
    old "I think it would be better if you leave before she comes back."
    new "我觉得你还是在她回来前离开比较好。"

translate chinese chinese_9826049_111:
    old "Oh, sure, you're right! I'd forgotten about Anna."
    new "哦，对了，你说得对！我忘了安娜了。"

translate chinese chinese_8532256_112:
    old "I'll come back later to see how it went with the guys, ok?"
    new "我待会儿回来看看和那些人谈得怎么样，好吗？"

translate chinese chinese_2564371_113:
    old "Sure, but please come in the afternoon, when Anna is usually out."
    new "行，但请下午再来，安娜那时通常不在。"

translate chinese chinese_2050589_114:
    old "Alright, I will come in the afternoon."
    new "好吧，我下午来。"

translate chinese chinese_2879606_115:
    old "Thank you so much pumpkin, I really appreciate your help."
    new "真的非常感谢你，宝贝，你的帮助我真的很感激。"

translate chinese chinese_1221899_116:
    old "No biggie, I'm happy to help, bye!"
    new "没什么大不了的，乐意帮忙，再见！"

translate chinese chinese_8577471_117:
    old "Damn, I think I didn't do a good job with this Lydia, sorry."
    new "妈的，我觉得我没把这件事处理好，对不起，莉迪亚。"

translate chinese chinese_8789735_118:
    old "Really? Did the phone fail?"
    new "真的吗？手机坏了吗？"

translate chinese chinese_3250403_119:
    old "No, no, it's just that I think I selected some profiles wrong. So you may not like them too much."
    new "不，不，就是我觉得我选错了一些角色设定。所以你可能不太喜欢它们。"

translate chinese chinese_6888605_120:
    old "Aw, that's ok, you don't need to stress too much about it."
    new "哎，没关系，你不用太紧张。"

translate chinese chinese_2427409_121:
    old "We're both learning about this kind of thing. It's ok, really."
    new "我们俩都在了解这些事情。真的没关系的。"

translate chinese chinese_6839205_122:
    old "Thanks... Well, I think there's still a couple of matches, so you may talk to a couple of them, if you want to of course."
    new "谢谢……嗯，我觉得还有几场比赛，所以如果你想的话，可以和他们中的几个聊聊。"

translate chinese chinese_7004734_123:
    old "I'll do it, maybe they're not that bad. But for now, I think it would be better if you left."
    new "我来吧，也许他们也没那么糟。但你现在还是离开比较好。"

translate chinese chinese_4003356_124:
    old "Anna has been out for a little while now, so she could come back at any moment."
    new "安娜出去了一会儿，随时可能会回来。"

translate chinese chinese_2977770_125:
    old "I don't even know what she would say if she finds out about this."
    new "我甚至不知道如果她发现了会怎么说。"

translate chinese chinese_7108416_126:
    old "I don't want any more trouble with her. So it's best if you leave."
    new "我不想再因为她惹麻烦。所以你还是离开吧。"

translate chinese chinese_3193715_127:
    old "Yeah, you're right. I'll come back later to help again, bye Lydia."
    new "嗯，你说得对。我一会儿再回来帮忙，再见莉迪亚。"

translate chinese chinese_7001267_128:
    old "Hi pumpkin! How are you?"
    new "嗨，小甜心！怎么样？"

translate chinese chinese_2659053_129:
    old "Hey, it's Anna around?"
    new "嘿，安娜在附近吗？"

translate chinese chinese_8386912_130:
    old "She isn't, why?"
    new "她不是，为什么？"

translate chinese chinese_8638696_131:
    old "Well, I thought I could help you again with the app."
    new "嗯，我以为我又可以帮你搞定那个应用了。"

translate chinese chinese_3673160_132:
    old "How has it been going since the last time? Have you talked to anybody?"
    new "上次之后怎么样了？有跟谁说话吗？"

translate chinese chinese_7456468_133:
    old "Oh, not really, I've had a couple of conversations with some people, but nothing interesting."
    new "哦，也没啥，我和几个人聊了聊，但没什么有趣的。"

translate chinese chinese_2030249_134:
    old "Well, that's why I'm here, to help you out. So let's see the app."
    new "那我就来了，帮你解决。所以让我们看看这个应用吧。"

translate chinese chinese_8884374_135:
    old "Ok, here you go, I think I got just what you wanted."
    new "好的，给你，我觉得这正是你想要的。"

translate chinese chinese_0473200_136:
    old "With that done, I think it's better if I leave."
    new "这件事搞定后，我觉得我还是离开比较好。"

translate chinese chinese_2597086_137:
    old "We wouldn't want Anna to get here and catch us."
    new "我们可不想让安娜过来撞见我们。"

translate chinese chinese_9389695_138:
    old "Sure, thanks again [pla], I really appreciate your help."
    new "好的，再次感谢[pla]，真的很感激你的帮助。"

translate chinese chinese_3767355_139:
    old "Hmm, I guess that's ok, you don't need to stress too much about it."
    new "嗯，我想这样也行，不用太紧张。"

translate chinese chinese_9765413_140:
    old "Thanks... Well, I think there's still a couple of them you could talk to if you want to of course."
    new "谢谢……嗯，我想如果你愿意的话，还是有几个可以聊聊的。"

translate chinese chinese_8153403_141:
    old "Hi Lydia, how are you?"
    new "嗨，莉迪亚，你好吗？"

translate chinese chinese_0818707_142:
    old "Hmm, hello [pla] I'm ok, I guess..."
    new "嗯，你好 [pla] 我还行吧..."

translate chinese chinese_7767552_143:
    old "What? Did something happen? Why do you look so sad?"
    new "什么？发生什么事了吗？为什么你看起来这么难过？"

translate chinese chinese_7027470_144:
    old "Well... the thing is..."
    new "嗯……就是说……"

translate chinese chinese_8642495_145:
    old "Ugh, I've been talking with a couple of men on tinder, and..."
    new "唉，我在 Tinder 上和几个男人聊了聊，然后……"

translate chinese chinese_3257324_146:
    old "Oh, did I make a mistake choosing their profiles? Is there something wrong with them?"
    new "哦，选他们的资料时我犯错了？他们有什么问题吗？"

translate chinese chinese_6156538_147:
    old "Hmm, their perfectly nice gentlemen, very smart and all."
    new "嗯，他们都是很不错的绅士，非常聪明。"

translate chinese chinese_0258963_148:
    old "But, they're very old! As old as my ex husband was! And I don't want that!"
    new "但是，它们很老！跟我前夫一样老！我不要那样的！"

translate chinese chinese_4119966_149:
    old "I mean, I just widowed a man that age."
    new "我的意思是，我刚刚让一个那个年纪的人成了寡妇。"

translate chinese chinese_6061458_150:
    old "When I talked about dating again I was thinking more along the lines of young, energetic men, full of vitality... You know?"
    new "我说再谈恋爱，想的是一些年轻有活力的男生……你知道的。"

translate chinese chinese_5000577_151:
    old "I- I guess I do."
    new "我——我想我是这样的。"

translate chinese chinese_8107852_152:
    old "Why is the app only pairing me with these old guys?"
    new "为什么这个应用总是给我配这些老家伙？"

translate chinese chinese_5629244_153:
    old "Uhh, I don't really know why."
    new "呃，我真的不知道为什么。"

translate chinese chinese_5202298_154:
    old "Maybe it's the algorithm putting you with people your age."
    new "可能是算法把你匹配给了同龄人。"

translate chinese chinese_0979385_155:
    old "But, I think there might be something we can do about that."
    new "但是，我觉得这件事我们可能能做点什么。"

translate chinese chinese_9584736_156:
    old "Yeah? What is it?"
    new "嗯？什么事儿？"

translate chinese chinese_5043269_157:
    old "Well, we could 'fix' your profile. Improve it a little."
    new "嗯，我们可以“修理”一下你的资料，改进一点。"

translate chinese chinese_8638867_158:
    old "What do you mean by 'fix'?"
    new "你说的“解决”是什么意思？"

translate chinese chinese_2898048_159:
    old "We could, for example, put a better picture of you. Or maybe another description of you in the bio."
    new "比如说，我们可以放一张更好的你的照片，或者在简介里加另一个关于你的描述。"

translate chinese chinese_6130376_160:
    old "Something that will be more attractive to younger men."
    new "一些更能吸引年轻男人的东西。"

translate chinese chinese_1453492_161:
    old "That sounds like a great idea!"
    new "听起来真是个好主意！"

translate chinese chinese_9771072_162:
    old "Yeah, keeping in mind that those are the things that people will see when they go to your profile."
    new "嗯，记得这些是你个人资料里别人会看到的东西。"

translate chinese chinese_7578663_163:
    old "We could work on them to get more young people to swipe right instead of left on your profile."
    new "我们可以想办法让你的个人资料吸引更多年轻人向右滑，而不是向左滑。"

translate chinese chinese_3621377_164:
    old "That'd be perfect, let's do it."
    new "那太完美了，咱们就這麼辦。"

translate chinese chinese_2350548_165:
    old "The first thing is the picture, do you have any picture in which you look a little more casual?"
    new "第一件事是照片，你有没有看起来随意一点的照片？"

translate chinese chinese_5645212_166:
    old "I think I do, yeah, there must be a couple of some trips and excursions there in the phone."
    new "我想是的，手机里肯定有一些旅行和出游的信息。"

translate chinese chinese_9552272_167:
    old "Ok, that's perfect, now for the bio."
    new "好的，就这样，现在来说说个人资料。"

translate chinese chinese_3299306_168:
    old "I think we could maybe change it for either something more casual or a little bit more... Uhh, seductive."
    new "我觉得我们可以改成更随意一点的，或者稍微有点...嗯，挑逗性的。"

translate chinese chinese_4717551_169:
    old "What do you think?"
    new "你觉得呢？"

translate chinese chinese_9169495_170:
    old "Well, if that helps, I think we should give it a try."
    new "好吧，如果这有帮助的话，我觉得我们应该试试。"

translate chinese chinese_3026513_171:
    old "Alright, let me think in something."
    new "好吧，让我想想。"

translate chinese chinese_0907577_172:
    old "Ok, it's ready, what do you think?"
    new "好了，准备好了，你觉得怎么样？"

translate chinese chinese_8958605_173:
    old "It looks great! And I think I get what you were saying, this one definitely sounds and looks a lot more attractive."
    new "看起来很棒！我觉得我明白你的意思了，这个确实显得更有吸引力。"

translate chinese chinese_7883099_174:
    old "I'm glad you like it. I'm sure this time we'll attract some younger men."
    new "很高兴你喜欢。这次肯定能吸引一些年轻的男人。"

translate chinese chinese_0088536_175:
    old "Do you want to try now? I could get on the app and see if you can make a match with some new people."
    new "你现在想试试吗？我可以打开软件看看你能不能和一些新人匹配上。"

translate chinese chinese_9608821_176:
    old "Sure, just one little thing pumpkin. What does that GILF thing mean? Is it some kind of world play?"
    new "当然，就一件事，宝贝。那个GILF是什么意思？是一种文字游戏吗？"

translate chinese chinese_8297782_177:
    old "Uhh, t-that... yeah."
    new "呃，那件事……对。"

translate chinese chinese_6446621_178:
    old "It's actually an acronym."
    new "这其实是一个首字母缩略词。"

translate chinese chinese_9004329_179:
    old "It is? What does it stand for?"
    new "是吗？它代表什么？"

translate chinese chinese_1633718_180:
    old "Hmm, it stands for... Great... I- Intelligent, L- Loving... Friend."
    new "嗯，那代表……伟大的……I-聪明的，L-温柔的……朋友。"

translate chinese chinese_9348128_181:
    old "It's something that people my age understand, don't worry."
    new "这是咱们这个年纪的人能懂的事，放心吧。"

translate chinese chinese_9527868_182:
    old "Ohh, I see! That's great! Thank you."
    new "哦，我明白了！太好了！谢谢。"

translate chinese chinese_2707519_183:
    old "Well, I guess we can start looking for some profiles now."
    new "那我想我们现在可以开始找一些资料了。"

translate chinese chinese_6455026_184:
    old "Hi pumpkin!"
    new "嗨，小甜心！"

translate chinese chinese_8024717_185:
    old "I'm very fine, thank you."
    new "我很好，谢谢。"

translate chinese chinese_1615306_186:
    old "Oh yeah? Has anything good happened on tinder?"
    new "哦是吗？ Tinder 上有什么好事发生吗？"

translate chinese chinese_4157263_187:
    old "Well, you could say that. Ever since we changed my profile the number of young men talking to me has increased. It's been very exciting."
    new "这么说也行。自从改了我的资料后，来找我说话的年轻人多了不少，挺刺激的。"

translate chinese chinese_1955471_188:
    old "That's good to hear. So, it worked! it's what you expected, right?"
    new "听到这个很好。所以，成功了！这就是你期待的，对吧？"

translate chinese chinese_3301544_189:
    old "Hmm, it kinda is but..."
    new "嗯，有点儿那样，但是……"

translate chinese chinese_1923051_190:
    old "What? Anything wrong with anyone?"
    new "什么？大家有什么问题吗？"

translate chinese chinese_9510377_191:
    old "No, nothing wrong per se with the people I'm speaking to or the app."
    new "不，我和他们说话没什么不对的，这个应用也没问题。"

translate chinese chinese_7982697_192:
    old "Then what is it?"
    new "那是什么？"

translate chinese chinese_5316977_193:
    old "Well, it's more to do with their language."
    new "嗯，这更多是因为他们的语言。"

translate chinese chinese_6757217_194:
    old "To be honest I don't understand a lot of what they say. There is this one guy I was talking to."
    new "说实话，我听不懂他们说的很多内容。有次我跟一个家伙聊天。"

translate chinese chinese_4902428_195:
    old "And he suddenly began writing things like, lmao, brb, tbh."
    new "然后他突然开始写一些像lmao、brb、tbh这样的缩写。"

translate chinese chinese_6120601_196:
    old "And when asked him what he meant."
    new "然后问他是什么意思。"

translate chinese chinese_4660144_197:
    old "And he answered saying: 'lol, Idk wdym?"
    new "然后他回答说：“哈哈，我不懂你在说什么？"

translate chinese chinese_2989909_198:
    old "What?! What does that even mean?!"
    new "什么?! 这是什么意思?!"

translate chinese chinese_5520625_199:
    old "Yeah, how am I even supposed to talk to these people?"
    new "是啊，我该怎么和这些人说话呢？"

translate chinese chinese_7654174_200:
    old "Don't laugh, this isn't funny."
    new "别笑，这不好笑。"

translate chinese chinese_6268750_201:
    old "Y-you're right, sorry."
    new "你、你说得对，对不起。"

translate chinese chinese_2249683_202:
    old "It's just that I wasn't expecting that. But, I get what you mean, I guess young people talk in a confusing way."
    new "只是我没预料到而已。不过，我大概明白你的意思了，年轻人说话就是让人搞不懂。"

translate chinese chinese_0237500_203:
    old "Don't worry, they're not saying anything weird, they're just abbreviations, so you don't have to write the whole thing."
    new "别担心，他们说的没什么奇怪的，只是缩写，所以你不用写全。"

translate chinese chinese_1960487_204:
    old "I'll teach you how to use them."
    new "我来教你怎么用它们。"

translate chinese chinese_6571782_205:
    old "Well, I thank you, but I don't think that's going to do much for me. Because I've got another problem with the app."
    new "好吧，谢谢你，但我觉得这对我帮助不大。因为我应用程序又出问题了。"

translate chinese chinese_3953425_206:
    old "And is that damned keyboard, it's so small! I have no idea how you can write so fast on those little keyboards; you can't even see them!"
    new "而且那个该死的键盘，太小了！我真的不知道你怎么能在那么小的键盘上打那么快的字；你看都看不见！"

translate chinese chinese_6345592_207:
    old "Come on, come on, don't stress too much about it."
    new "好了好了，别太紧张了。"

translate chinese chinese_6952292_208:
    old "Let's just work on it and in no time you'll master them. You'll see."
    new "咱们就练吧，很快你就能掌握它们了。你会看到的。"

translate chinese chinese_6762642_209:
    old "If you say so. I guess I can try to learn..."
    new "如果这样的话，我猜我可以试着学学..."

translate chinese chinese_2178559_210:
    old "What a coincidence, this is the guy I was talking with yesterday night."
    new "真巧，这就是我昨晚聊天的那个家伙。"

translate chinese chinese_1942209_211:
    old "I know! Why don't we try speaking to him now? You could write for me!"
    new "我知道了！我们现在为什么不试着和他说话呢？你可以为我写信！"

translate chinese chinese_9314366_212:
    old "Hmm, I don't know, I mean, it's your conversation."
    new "嗯，我不知道，毕竟这是你的对话。"

translate chinese chinese_4021625_213:
    old "Oh please, since you'll actually understand if he uses those abbreviations, and you can use the keyboard."
    new "哦请吧，既然你能理解他的那些缩写，也能用键盘。"

translate chinese chinese_6146246_214:
    old "Why don't you just tell me what he's saying and I'll tell you what to answer?"
    new "你为什么不直接告诉我他说了什么，然后我告诉你该怎么回答？"

translate chinese chinese_6528272_215:
    old "Hahaha, that sounds odd."
    new "哈哈，听起来好怪哦。"

translate chinese chinese_4959795_216:
    old "But I guess we can try."
    new "但我想我们可以试试。"

translate chinese chinese_7609380_217:
    old "So, you see that it's not that difficult."
    new "所以，你看这其实没那么难。"

translate chinese chinese_0690087_218:
    old "What did he say?"
    new "他说什么了？"

translate chinese chinese_1677493_219:
    old "He's just saying hello, and asking how you are today."
    new "他只是打个招呼，问问你今天怎么样。"

translate chinese chinese_0346490_220:
    old "Well, don't keep him waiting! Say hello back!"
    new "别让他等太久！回个招呼吧！"

translate chinese chinese_8231942_221:
    old "What did he say now?"
    new "他又说了什么？"

translate chinese chinese_2290585_222:
    old "He said..."
    new "他说..."

translate chinese chinese_4127199_223:
    old "Here, let me see!"
    new "给我看看！"

translate chinese chinese_9953809_224:
    old "Hmm, 'hbu'? What is that supposed to mean?"
    new "嗯，'hbu'是什么意思？"

translate chinese chinese_1649276_225:
    old "It means 'How about you?'"
    new "意思是“你呢？”"

translate chinese chinese_6135268_226:
    old "Jesus, and he couldn't write that? How lazy are young people these days?"
    new "天啊，他连这个都写不了？现在的孩子有多懒？"

translate chinese chinese_5029463_227:
    old "It's not about being lazy, just answering fast."
    new "这不是懒，只是快速回答。"

translate chinese chinese_8338426_228:
    old "Which by the way, he's waiting for us to answer him."
    new "话说，他在等我们回答呢。"

translate chinese chinese_7523754_229:
    old "Oh shoot, right!"
    new "哦对了，想起来了！"

translate chinese chinese_0996385_230:
    old "Tell him: 'Oh, it's so good that you exercise, that's very good for the joints and muscles."
    new "告诉他：‘哦，你锻炼真是太好了，这对关节和肌肉很有好处。'"

translate chinese chinese_3858014_231:
    old "Be sure to hydrate and rest properly."
    new "一定要补充水分和好好休息。"

translate chinese chinese_4378742_232:
    old "Wait, what?!"
    new "等一下，什么？！"

translate chinese chinese_4774664_233:
    old "Hahahahaha."
    new "哈哈哈哈哈。"

translate chinese chinese_9423301_234:
    old "Now what's so funny?"
    new "现在有什么好笑的？"

translate chinese chinese_6445290_235:
    old "Hahaha, well, we can't tell him that. You'd sound like a P.E. teacher. You have to be a little more playful."
    new "哈哈，不过我们不能这么说。你会听起来像一个体育老师。得调皮一点。"

translate chinese chinese_6876848_236:
    old "Playful?"
    new "开玩笑？"

translate chinese chinese_8222687_237:
    old "Yeah you know, something about how attractive that is to you and stuff."
    new "就是啊，你知道的，那对你来说有多有吸引力之类的。"

translate chinese chinese_3750825_238:
    old "I see, well..."
    new "我明白了，嗯……"

translate chinese chinese_0562081_239:
    old "How about this?"
    new "怎么样？"

translate chinese chinese_4569071_240:
    old "I love that you exercise, you must be in great shape then."
    new "我喜欢你锻炼，你肯定身材很好吧。"

translate chinese chinese_9592864_241:
    old "Hmm, not really playful, but it could work."
    new "嗯，不太调皮，但也可以用用看。"

translate chinese chinese_1164806_242:
    old "Let's see how it goes."
    new "看看会怎么样吧。"

translate chinese chinese_0690366_243:
    old "He said 'Oh yeah, maybe if you're lucky I'll let you take a peek later.'"
    new "他说“哦，是吗？如果你运气好，说不定我later让你看看。”"

translate chinese chinese_2036784_244:
    old "Oh, hahaha, that's so cute. Then tell him that..."
    new "哦，哈哈，真可爱。然后告诉她……"

translate chinese chinese_6811578_245:
    old "Wait, there's more."
    new "等一下，还有更多。"

translate chinese chinese_7989784_246:
    old "Hmm, he says 'Judging from your pictures you must be super hot too.'"
    new "嗯，他说“从你的照片来看，你肯定也很火。”"

translate chinese chinese_5474326_247:
    old "Oh, really? That's so nice!"
    new "哦，真的吗？太好了！"

translate chinese chinese_6040775_248:
    old "Hmm... Tell him 'You're joking, right? I'm just an old woman.'"
    new "嗯……告诉她“你在开玩笑吧？我只是一个老女人。”"

translate chinese chinese_3710279_249:
    old "Really? Hmm alright..."
    new "真的吗？嗯，好吧……"

translate chinese chinese_2230671_250:
    old "He says 'Come on! Don't say that, I'm sure you're beautiful.'"
    new "他说：“快点！不要这么说，我相信你很漂亮。”"

translate chinese chinese_9939515_251:
    old "And then he says 'Also, I wouldn't call you 'old'. On the contrary, I think you're very experienced, and experience is sexy.'"
    new "然后他说：“另外，我可不会叫你‘老’。相反，我觉得你很有经验，而经验是性感的。”"

translate chinese chinese_4660853_252:
    old "Hahaha, what a cute guy."
    new "哈哈，真是个可爱的男人。"

translate chinese chinese_5515163_253:
    old "Tell him 'Well it seems you know how to compliment a lady.'"
    new "告诉她“看来你挺会夸女人的。”"

translate chinese chinese_1125521_254:
    old "He says 'That's not the only thing I know how to do with a lady.'"
    new "他说“那可不是我对付女士的唯一招数。”"

translate chinese chinese_5495408_255:
    old "And now he adds 'Why don't we go out for dinner and you let me show you?'"
    new "而现在他又加了一句“我们出去吃饭，让我带你去怎么样？”"

translate chinese chinese_3838553_256:
    old "Well isn't he brave? He just invited me to date out of the blue!"
    new "他还真是够勇敢的啊，竟然突然邀请我约会！"

translate chinese chinese_4336867_257:
    old "But I don't think I should accept just like that, I don't want him to think that I'm desperate."
    new "但是我觉得不能就这样接受，我不想让他觉得我是在死缠烂打。"

translate chinese chinese_4247432_258:
    old "Then what should I tell him?"
    new "那我该告诉他什么？"

translate chinese chinese_8134064_259:
    old "Hmm, let me think..."
    new "嗯，让我想想..."

translate chinese chinese_7243164_260:
    old "I got it."
    new "我明白了。"

translate chinese chinese_0752812_261:
    old "Tell him 'Ohh, I don't know, I think you'll be bored if you go out with an old woman like me.'"
    new "告诉他“哦，我不知道，我觉得如果你跟我这种老女人出去你会无聊的。”"

translate chinese chinese_8295702_262:
    old "Why did you write 'idk' what does that mean?"
    new "你为什么写“idk”，那是什么意思？"

translate chinese chinese_4816929_263:
    old "I mean 'I don't know' it's just so that he doesn't think you're super formal."
    new "我是说“我不知道”，这样他不会觉得你很正式。"

translate chinese chinese_8059563_264:
    old "Ohh, I see."
    new "哦，我明白了。"

translate chinese chinese_7645527_265:
    old "Hmm, isn't he something?"
    new "哼，这家伙真是的？"

translate chinese chinese_7851271_266:
    old "Write 'Oh really? Are you sure you're not just saying that to try and get in my pants?'"
    new "写“哦真的吗？你确定这不是为了勾引我？”"

translate chinese chinese_5753501_267:
    old "He's saying 'Of course not, I honestly think you're super interesting.'"
    new "他在说“当然不是，我真的很觉得你超级有趣。”"

translate chinese chinese_4543476_268:
    old "And also 'But hey, for what it's worth, I do like my women a little older ;)'"
    new "还有“不过说起来，我确实喜欢年龄大一点的女性 ;)”"

translate chinese chinese_0818307_269:
    old "Hahahaha, tell him 'Well, aren't you something?'"
    new "哈哈哈哈哈，跟他说“哼，真有你的。”"

translate chinese chinese_6541989_270:
    old "Uhh... Now he's saying 'Baby I'm a little more than just something'"
    new "呃……现在他在说“宝贝，我可不只是某件事而已”"

translate chinese chinese_0106486_271:
    old "And he is asking if you want to... Uhh, see."
    new "而且他在问你是否想...呃，看看。"

translate chinese chinese_3101425_272:
    old "See? See what?"
    new "看什么？看到什么了？"

translate chinese chinese_7252611_273:
    old "Well... you know."
    new "嗯……你知道的。"

translate chinese chinese_3633115_274:
    old "Know what? Ask him, 'see what?'"
    new "知道吗？问问他，“看什么？”"

translate chinese chinese_2841690_275:
    old "He replied 'lol, you bad girl, you know what I mean...'"
    new "他回了“哈哈，你这个坏女孩，你知道我的意思……”"

translate chinese chinese_0337029_276:
    old "Lol? What's that?"
    new "哈哈？那是什么？"

translate chinese chinese_9358642_277:
    old "It means: 'Laughing out loud'."
    new "意思是“大声笑”。"

translate chinese chinese_4064271_278:
    old "So, something that I said was funny?"
    new "所以，我说的什么好笑了？"

translate chinese chinese_3791252_279:
    old "But what? And what's he talking about me knowing what he means?"
    new "但是什么？而且他说的我知道他的意思又是什么意思？"

translate chinese chinese_1616036_280:
    old "Oh wow! I wasn't expecting that!"
    new "哦 wow！我没想到会这样！"

translate chinese chinese_4041938_281:
    old "Hmm, me neither..."
    new "嗯，我也是..."

translate chinese chinese_0913748_282:
    old "What do I answer now?"
    new "我现在该怎么回答？"

translate chinese chinese_2434939_283:
    old "Hmm, I- I guess you can tell him how surprised you are."
    new "嗯，我——我想你可以告诉他你有多惊讶。"

translate chinese chinese_9193359_284:
    old "Sure, tell him that I wasn't expecting that picture."
    new "好吧，告诉他那张照片我没想到会看到。"

translate chinese chinese_2498308_285:
    old "He replied: 'Hahaha, well, you know... yolo, right?'"
    new "他回复说：‘哈哈，你知道的……YOLO吧？’"

translate chinese chinese_8452372_286:
    old "Yolo?"
    new "耶洛？"

translate chinese chinese_7424092_287:
    old "You only live once."
    new "人生只有一次。"

translate chinese chinese_0526889_288:
    old "You young people, honestly..."
    new "你们这些年轻人，真是的……"

translate chinese chinese_0043546_289:
    old "He wants to know what you thought about the picture."
    new "他想知道你对那张照片的看法。"

translate chinese chinese_3156781_290:
    old "Really? W- what should I tell him?"
    new "真的吗？我该告诉他什么？"

translate chinese chinese_2222124_291:
    old "Just tell him what you think."
    new "就告诉他你的想法吧。"

translate chinese chinese_2528428_292:
    old "Well, let me see it again..."
    new "好吧，让我再看看..."

translate chinese chinese_0180262_293:
    old "Well, I wasn't expecting him to just send it. That was very unexpected."
    new "好吧，我没想到他会直接发过来。这真的很意外。"

translate chinese chinese_6478751_294:
    old "But if I'm honest, it's very... impressive. Also, he's rock hard, do you think that's for me?"
    new "但说真的，这非常……令人印象深刻。而且他硬得像块岩石，你觉得这是为我准备的吗？"

translate chinese chinese_8114772_295:
    old "Do I tell him that?"
    new "我告诉他这个吗？"

translate chinese chinese_0340989_296:
    old "Well, that's what I think about that pic."
    new "好吧，那就是我对那张照片的看法。"

translate chinese chinese_0678046_297:
    old "Alright, I'll tell him that."
    new "好吧，我会告诉他这件事的。"

translate chinese chinese_7669622_298:
    old "Of course it is, to be honest, you're super hot, so hot that you make me hard just thinking about being with you."
    new "说实话，当然了，你超级性感，想到和你在一起我就硬了。"

translate chinese chinese_3968104_299:
    old "That that's very sweet, thank you."
    new "那真的很甜，谢谢你。"

translate chinese chinese_6842844_300:
    old "And to be honest, seeing your hard dick also turns on a little."
    new "说实话，看到你硬硬的也让我有点兴奋。"

translate chinese chinese_1371396_301:
    old "Oh yeah? Tell me how much."
    new "哦是吗？告诉我具体多少。"

translate chinese chinese_7384423_302:
    old "Mmm, just seeing your hard dick is making me horny."
    new "嗯，光看你那硬挺的样子我就兴奋了。"

translate chinese chinese_1646429_303:
    old "That's it baby and thinking about your wet pussy makes me even harder."
    new "就是这样，宝贝，想到你湿漉漉的下体我就更硬了。"

translate chinese chinese_3473586_304:
    old "Yes, my pussy is dripping just thinking about your cock."
    new "是的，一想到你的 cock，我的 pussy 就在滴液了。"

translate chinese chinese_7488480_305:
    old "Oh baby, I want to fuck you with this big cock."
    new "哦宝贝，我想用这大鸡巴干你。"

translate chinese chinese_2029385_306:
    old "Oh yes, I want you to come over and put that hard cock in me."
    new "哦是的，我希望你过来，把那硬硬的东西塞进我里面。"

translate chinese chinese_5924717_307:
    old "Do you really want that baby?"
    new "你真的想要这个孩子吗？"

translate chinese chinese_9716918_308:
    old "Oh yes! I want it so bad!"
    new "哦 yeah！我好想要！"

translate chinese chinese_5900489_309:
    old "Tell me, what else do you want me to do to you?"
    new "告诉我，你还想让我对你做什么？"

translate chinese chinese_9617906_310:
    old "I want you to come over and pull my hair while you fuck me!"
    new "我想让你过来，在做爱的时候扯我的头发！"

translate chinese chinese_6763562_311:
    old "Yes! I'll pull your hair while I fuck you from behind!"
    new "好！我一边从后面干你一边拔你的头发！"

translate chinese chinese_1287689_312:
    old "Yes! Yes! I want you to pull my hair and slap my ass!"
    new "是的！是的！我想让你拽我的头发和拍我的屁股！"

translate chinese chinese_3623995_313:
    old "I'll pull your hair and call you my little slut!"
    new "我揪你的头发，叫你小骚货！"

translate chinese chinese_0071733_314:
    old "Oh yeah! I'm your little slut!"
    new "哦对！我是你的小荡妇！"

translate chinese chinese_1813102_315:
    old "Mmmm... Phew..."
    new "嗯……呼……"

translate chinese chinese_3202682_316:
    old "Wow, that was fun."
    new "哇，真好玩。"

translate chinese chinese_0536647_317:
    old "He says he has to go now, he is late for his work."
    new "他说他现在得走了，他要迟到了。"

translate chinese chinese_1148937_318:
    old "Ohh... hmm, sure."
    new "哦……嗯，好吧。"

translate chinese chinese_4746011_319:
    old "He says 'It was awesome, you really are cool. I can't wait to meet you in person.'"
    new "他说“太棒了，你真的很酷。我迫不及待想见你了。”"

translate chinese chinese_4607592_320:
    old "Uhh t- thanks... see you later."
    new "呃，谢谢……回头见。"

translate chinese chinese_7811843_321:
    old "Ok, I think it's done, so I'm going home."
    new "好了，我觉得搞定了，我要回家了。"

translate chinese chinese_9111698_322:
    old "Uhh... Listen [pla]. I- I'm sorry. I didn't mean it for things to turn this way."
    new "呃……听着，[pla]。我……我很抱歉。我不希望事情变成这样。"

translate chinese chinese_7244014_323:
    old "I'm sorry, I don't know what happened."
    new "对不起，我不知道发生了什么。"

translate chinese chinese_6586899_324:
    old "It's just that it's been so long since any kind of you know... Release."
    new "只是因为太久了，你知道的……释放。"

translate chinese chinese_5188516_325:
    old "I wasn't expecting the conversation to take a turn that way."
    new "我没想到对话会变成这样。"

translate chinese chinese_2258645_326:
    old "But please believe me that I didn't plan any of this, I just couldn't help it."
    new "但是请相信我，这一切都不是我计划的，我只是忍不住。"

translate chinese chinese_3614969_327:
    old "Hey, hey, it's ok. Don't worry."
    new "嘿，嘿，没事的。别担心。"

translate chinese chinese_2624341_328:
    old "I understand, and I'm not angry."
    new "我明白，我也不会生气。"

translate chinese chinese_5481668_329:
    old "I won't lie, I'm a little surprised."
    new "我不撒谎，我有点惊讶。"

translate chinese chinese_1484500_330:
    old "But, I understand. After all, the whole point of doing this was for you to let loose and meet new people."
    new "但是，我理解。毕竟，做这一切的目的是让你放松并结识新朋友。"

translate chinese chinese_5214517_331:
    old "Thank you so much [pla]. You're an angel for understanding."
    new "真是太感谢你了，[pla]。你能理解我真是个大天使。"

translate chinese chinese_2102255_332:
    old "No biggie, but maybe I should go now."
    new "没什么大不了的，但也许我现在该走了。"

translate chinese chinese_8920590_333:
    old "Yeah, you're right. Anna might come back any minute."
    new "嗯，你说得对。安娜随时可能会回来。"

translate chinese chinese_0674500_334:
    old "Yeah, however, I'm glad to see that you're making progress with your online app."
    new "是的，不过看到你的在线应用有了进展，我挺高兴的。"

translate chinese chinese_5704189_335:
    old "But being honest it's all thanks to your help."
    new "但老实说，这全靠你的帮助。"

translate chinese chinese_8214250_336:
    old "It's nothing, I'm glad I can be of help to you."
    new "没什么，能帮你我挺高兴的。"

translate chinese chinese_1888078_337:
    old "Keep chatting and I'll be back soon to keep helping you."
    new "继续聊，我很快就会回来继续帮你。"

translate chinese chinese_0043382_338:
    old "All right, Thank you!"
    new "好的，谢谢！"

translate chinese chinese_6964878_339:
    old "Hi, how a..."
    new "喂，怎么了..."

translate chinese chinese_2853827_340:
    old "Is everything alright? Did anything happen?"
    new "一切都好吗？发生什么事了吗？"

translate chinese chinese_6370882_341:
    old "Hi [pla] how are you?"
    new "你好 [pla]，最近怎么样？"

translate chinese chinese_6473934_342:
    old "I guess everything's right. I'm just not feeling well right now."
    new "我想一切都挺好的，就是现在感觉不太舒服。"

translate chinese chinese_6186392_343:
    old "Hmm, well, it's not much."
    new "嗯，其实没什么。"

translate chinese chinese_3048221_344:
    old "It's just that I went out with that guy you were helping me chat with."
    new "就是说，我和你帮我聊天的那个家伙出去了。"

translate chinese chinese_5467334_345:
    old "And it didn't go well, it was actually kinda bad."
    new "而且情况不太妙，实际上挺糟糕的。"

translate chinese chinese_0323675_346:
    old "Did he say anything bad to you?"
    new "他有没有说什么难听的话？"

translate chinese chinese_0180631_347:
    old "No, no. The problem is that it didn't feel good."
    new "不，不。问题是我感觉不到快感。"

translate chinese chinese_2502043_348:
    old "We only talked about everyday stuff and the conversation didn't go anywhere from there. Is just as if he had lost all interest."
    new "我们只聊了些日常琐事，话题根本就没深入。感觉他完全失去了兴趣。"

translate chinese chinese_1735365_349:
    old "I swear to god he wasn't even looking at me!"
    new "我发誓他根本就没看我！"

translate chinese chinese_4800658_350:
    old "And after saying all that stuff on our chat."
    new "而且还在聊天里说了那些话。"

translate chinese chinese_7649837_351:
    old "It's extremely disappointing."
    new "这真是令人非常失望。"

translate chinese chinese_2347138_352:
    old "I see, I'm sorry that happened."
    new "我明白了，真遗憾发生了这样的事。"

translate chinese chinese_1936752_353:
    old "But to be honest [pla]. This date got me thinking."
    new "但老实说，[pla]。这次约会让我有些想法。"

translate chinese chinese_4247523_354:
    old "And I don't think this whole thing of looking for younger men is for me."
    new "而且我觉得追求年轻男人这种事不适合我。"

translate chinese chinese_4006128_355:
    old "Think about it, I don't even understand what they're saying when they write with those strange words they make up."
    new "想想看，他们用那些自创的奇怪词语写的东西，我都不明白他们在说什么。"

translate chinese chinese_4783366_356:
    old "And when I got a date with a guy that seemingly wanted to have something with me."
    new "而且当我约会了一个似乎想和我发展些什么的家伙时。"

translate chinese chinese_0297431_357:
    old "He just lost all interest and began treating me all cordial and distant."
    new "他突然失去了兴趣，开始对我很客气也很疏远。"

translate chinese chinese_1070944_358:
    old "I didn't like that at all. I'm not doing this to be looked at as if I was their grandma."
    new "我完全不喜欢这样。我可不是想被当成他们的奶奶来看待的。"

translate chinese chinese_3352670_359:
    old "So it's better if we just look for older men that are my age, I think I can date then."
    new "所以我觉得还是找一些和我年纪相仿的成熟男人比较好，那样我可以约会他们。"

translate chinese chinese_8002841_360:
    old "Well, I get what you mean."
    new "好吧，我明白你的意思。"

translate chinese chinese_6714392_361:
    old "But I don't actually think that's what you want Lydia."
    new "但是我觉得那其实不是你想要的，莉迪亚。"

translate chinese chinese_9761670_362:
    old "Listen, that guy was an idiot. You shouldn't let his attitude bring you down."
    new "听着，那家伙就是个白痴。你不应该因为他的情绪而受影响。"

translate chinese chinese_2087911_363:
    old "Hmm, you say that but..."
    new "嗯，你这么说，但是……"

translate chinese chinese_2250352_364:
    old "Listen, you went on a date, and it didn't go great because the guy turned out to be an asshole."
    new "听着，你去约会了，结果那家伙是个混蛋，所以约会搞砸了。"

translate chinese chinese_1745381_365:
    old "I get it sucks, but that stuff happens."
    new "我知道这很糟糕，但这种事情有时就是会发生。"

translate chinese chinese_9373141_366:
    old "Believe me, if it didn't go well it's because of him. You didn't have anything to do with that."
    new "相信我，如果事情不顺利，那是因为他。跟你没关系。"

translate chinese chinese_8426950_367:
    old "Of course! I mean, look at you. You are beautiful, and you're great to hang around. Any guy would be lucky to be with you."
    new "当然了！我是说，看看你自己。你很漂亮，而且跟你在一起很愉快。任何一个男生能跟你在一起都会很幸运的。"

translate chinese chinese_7372757_368:
    old "Hmph, you're sweet, but I know you're only saying that to cheer me up. I know you don't mean it."
    new "哼，你真甜，但我知道你只是想让我高兴起来。你知道的，你不是认真的。"

translate chinese chinese_7226073_369:
    old "Swear to god that I do."
    new "我发誓我真的有。"

translate chinese chinese_7088573_370:
    old "Well then you're the only one!"
    new "那你就唯一一个了！"

translate chinese chinese_9960900_371:
    old "I mean let's just face it [pla]. I'm an old lonely widow with nothing to offer to any guy."
    new "我是说，[pla]，我们就面对现实吧。我只是一个孤独的老寡妇，对任何男人都没什么可提供的。"

translate chinese chinese_9243141_372:
    old "Besides, I can't compete with the girls young men go around with. With their perfect toned bodies."
    new "再说，我也没法跟那些小伙子们身边的女孩比，她们都有完美的身材。"

translate chinese chinese_2149343_373:
    old "I'm old, any sex appeal that I had I lost a long time ago."
    new "我老了，早就没有魅力了。"

translate chinese chinese_6215337_374:
    old "W- What?! What are you saying? You can't be serious."
    new "什、什么？你在说什么？你不是认真的吧。"

translate chinese chinese_1087643_375:
    old "Well, I am!"
    new "我就是！"

translate chinese chinese_3236773_376:
    old "It's just true, I'm no longer pretty."
    new "这就是事实，我再也不漂亮了。"

translate chinese chinese_2479873_377:
    old "What are you talking about, you're so beautiful."
    new "你在说什么呢，你这么漂亮。"

translate chinese chinese_9934296_378:
    old "You're still a very sexy woman, your face, your body, everything about you is perfect."
    new "你仍然是一位非常性感的女人，你的脸、你的身体，关于你的每一处都完美无缺。"

translate chinese chinese_9404775_379:
    old "Yeah right..."
    new "说得倒轻松……"

translate chinese chinese_3079817_380:
    old "I mean it, any man would find you to be incredibly sexy."
    new "我是认真的，任何男人都会觉得你超级性感。"

translate chinese chinese_1761369_381:
    old "Any man?"
    new "任何男人？"

translate chinese chinese_7817122_382:
    old "All of them?"
    new "全部吗？"

translate chinese chinese_5796666_383:
    old "... Even you?"
    new "... 连你也是？"

translate chinese chinese_2759998_384:
    old "Yeah, you, you said any man would think I'm sexy."
    new "对，你说过任何一个男人都会认为我性感。"

translate chinese chinese_1443954_385:
    old "How about you? Do you really think I'm sexy?"
    new "那你呢？你真的觉得我性感吗？"

translate chinese chinese_2767600_386:
    old "Uhh, w- well, yeah, I mean..."
    new "呃，嗯，那个，我的意思是..."

translate chinese chinese_2924566_387:
    old "You mean what?"
    new "你是说什么？"

translate chinese chinese_2512129_388:
    old "I knew it! You also just think I'm old!"
    new "我就知道！你也觉得我老了！"

translate chinese chinese_6594699_389:
    old "No, no, not at all."
    new "不，不，根本不是那样的。"

translate chinese chinese_4571106_390:
    old "It's just that I wasn't expecting you to ask me that."
    new "只是我没想到你会这么问我。"

translate chinese chinese_5720026_391:
    old "But I mean, of course, I also think you're sexy."
    new "但是我说真的，我也觉得你性感。"

translate chinese chinese_0108481_392:
    old "Really? And you actually mean it? You're not just saying that to please me?"
    new "真的吗？而且你是真心的？不是 just 说说而已讨我喜欢？"

translate chinese chinese_8654625_393:
    old "For real, I mean it 100."
    new "seriously，我是完全认真的。"

translate chinese chinese_9334721_394:
    old "Well, I don't know if you're lying, but just you saying I'm sexy is not enough."
    new "好吧，我不知道你在不在撒谎，但光说我觉得我很性感是不够的。"

translate chinese chinese_4375267_395:
    old "But there's one way to know for certain... Your cock."
    new "但有一个确定的方法……你的 dicks。"

translate chinese chinese_9189120_396:
    old "My cock? W- what do you mean?"
    new "我的 cock？你什么意思？"

translate chinese chinese_6671610_397:
    old "To know if you're lying, you may say I'm sexy, but if you don't have an erection I won't believe you."
    new "要知道你是不是在撒谎，你可以说我性感，但如果你没有硬起来，我是不会相信的。"

translate chinese chinese_1370613_398:
    old "It's the same with all men, the penis never lies."
    new "所有男人都是这样， penis 从不说谎。"

translate chinese chinese_9278833_399:
    old "So..."
    new "所以……"

translate chinese chinese_4728378_400:
    old "W- whoa! What are you doing?"
    new "哇！你在干什么？"

translate chinese chinese_3778875_401:
    old "Well, I wanted to know what you think about my breasts."
    new "嗯，我想知道你对我这副胸部有什么看法。"

translate chinese chinese_0113651_402:
    old "How about now? Do you still think I'm sexy?"
    new "现在呢？你还觉得我性感吗？"

translate chinese chinese_5562408_403:
    old "Y- yeah, of course."
    new "嗯，当然了。"

translate chinese chinese_8015970_404:
    old "So, look at them, and let's see if your cock thinks the same."
    new "所以，看看她们，看看你那玩意儿是不是也有同感。"

translate chinese chinese_2274869_405:
    old "I don't think that's a good idea. After all..."
    new "我觉得那不是个好主意。毕竟……"

translate chinese chinese_0166896_406:
    old "Stop putting up excuses and see my tit!"
    new "别再找借口了，看看我的胸！"

translate chinese chinese_3441866_407:
    old "Or I'll know you're lying to me."
    new "不然我就知道你在骗我。"

translate chinese chinese_2904589_408:
    old "!!!!"
    new "!!!!"

translate chinese chinese_9109976_409:
    old "Oh wow, this is impressive."
    new "哦 wow，这真是厉害。"

translate chinese chinese_5862680_410:
    old "Ok, I believe you, if you're this hard you must be telling the truth."
    new "好吧，我相信你，如果你这么坚持，肯定是在说真话。"

translate chinese chinese_1910590_411:
    old "Yeah, well, I do believe you're very beautiful."
    new "好吧，我相信你真的很漂亮。"

translate chinese chinese_9083199_412:
    old "Well, I have no doubt about that now."
    new "好吧，我现在完全确定了。"

translate chinese chinese_3716481_413:
    old "I must say [pla] your cock is something else."
    new "必须说，你的家伙真是不一样。"

translate chinese chinese_8502592_414:
    old "It's so... big."
    new "它好...大。"

translate chinese chinese_8463552_415:
    old "I- I can believe that it is because of me."
    new "我——我相信是因为我。"

translate chinese chinese_2985073_416:
    old "It's really flattering that such a young man like you can feel that way about a woman my age."
    new "一个像你这样的年轻人对我这种年纪的女人有这种感觉，真是很荣幸。"

translate chinese chinese_1052477_417:
    old "I- I just want to see it closer..."
    new "我……我只是想再近一点看看……"

translate chinese chinese_0180647_418:
    old "It's been a long time since I've seen one so close."
    new "好长时间没见过这么近的了。"

translate chinese chinese_5346590_419:
    old "And, it wasn't that big... Not at all..."
    new "而且，也没那么大……根本不算什么……"

translate chinese chinese_8781120_420:
    old "Knowing this is caused by me really makes me tingle."
    new "知道这是因为我造成的，真是让我心痒痒的。"

translate chinese chinese_1440968_421:
    old "I'm sorry to ask but, may I see it... I mean, out of your pants?"
    new "不好意思问这个，但我能看看……你的裤子里面吗？"

translate chinese chinese_5712100_422:
    old "To be honest, is the first time I have seen one that big, and really makes me curious..."
    new "说实话，这是我第一次见到那么大的，真的让我很好奇……"

translate chinese chinese_2185417_423:
    old "... Hmm o- ok."
    new "... 嗯，好。"

translate chinese chinese_4699718_424:
    old "Oh wow! It's even bigger than I thought it was..."
    new "哦 wow！比我想的还要大……"

translate chinese chinese_5336135_425:
    old "I have never thought you were this... gifted."
    new "我从没想到你会这么...有天赋。"

translate chinese chinese_0071667_426:
    old "And it's so hard... really seen just this old boob make you so hard?"
    new "而且好硬……真的只是看到这副老胸就让你这么激动？"

translate chinese chinese_4411549_427:
    old "It was something instinctive, you know a natural reaction..."
    new "那是本能反应，你知道的，就是自然反应..."

translate chinese chinese_4088709_428:
    old "That is the most honest answer a woman can get from a man..."
    new "这是男人能给女人的最诚实的答案……"

translate chinese chinese_7829049_429:
    old "Thanks [pla], you really made me regain some self-esteem after the bad date I had with the other guy..."
    new "谢谢[pla]，在我和其他人约会搞砸后，你真的帮我找回了一些自尊心..."

translate chinese chinese_9015380_430:
    old "You have to know you are really beautiful and sexy, any man can see that, really."
    new "你得知道你真的很漂亮很性感，任何男人都能看出来，真的。"

translate chinese chinese_7320350_431:
    old "Yeah, now I can see it..."
    new "嗯，现在我能看清楚了……"

translate chinese chinese_8030307_432:
    old "Uhh... C- can I touch it?"
    new "呃……我……我可以摸一下吗？"

translate chinese chinese_5296481_433:
    old "I mean, I just want to see how hard you are, if you're really excited or if it's just barely."
    new "我的意思是，我只是想看看你有多硬，是不是真的兴奋了，还是只是有点儿。"

translate chinese chinese_1258444_434:
    old "And you can't tell just from seeing it?"
    new "光看就不能判断吗？"

translate chinese chinese_7468257_435:
    old "You can't always know that from just looking."
    new "你不能单凭看就总是知道。"

translate chinese chinese_6687106_436:
    old "It's always better to check with my own hands."
    new "还是亲自确认一下比较好。"

translate chinese chinese_0916966_437:
    old "Woah, you're really hard!"
    new "哇，你真够劲的！"

translate chinese chinese_0874545_438:
    old "And you're so big! This is impressive!"
    new "而且你这么大！真厉害！"

translate chinese chinese_7705833_439:
    old "L-listen [pla]. I'm sorry. I didn't mean to do that when you got here."
    new "L-听一下[pla]，对不起。我不是故意在你来的时候那样做的。"

translate chinese chinese_3700482_440:
    old "It's just that you've been so good to me, and I was feeling rather vulnerable."
    new "只是因为你对我太好了，我感觉有点脆弱。"

translate chinese chinese_1837772_441:
    old "And seeing how hard you got because of me."
    new "还有看到你因为我变得这么硬。"

translate chinese chinese_8599935_442:
    old "But, I swear to God I didn't mean to..."
    new "但是，我发誓我真的不是故意..."

translate chinese chinese_9457860_443:
    old "Hey, hey, it's ok."
    new "嘿，嘿，没事的。"

translate chinese chinese_6188638_444:
    old "No need for you to stress over this."
    new "这件事不用你担心。"

translate chinese chinese_9994243_445:
    old "I'm not angry with you. I understand."
    new "我没有生你的气，我理解。"

translate chinese chinese_2575299_446:
    old "Yeah, I do, it's ok."
    new "嗯，我愿意，没关系。"

translate chinese chinese_7859516_447:
    old "Hmm, but maybe we should clean this up before we keep talking."
    new "嗯，不过也许我们应该先把这个收拾干净再继续聊。"

translate chinese chinese_4780742_448:
    old "Thanks a lot for your help [pla]."
    new "谢谢你帮忙，[pla]。"

translate chinese chinese_1710244_449:
    old "The truth is that what happened with that guy really affected me. I was feeling really down."
    new "事实是，那个家伙的事真的影响到我了。我心情很低落。"

translate chinese chinese_5423404_450:
    old "Thanks for helping me feel better."
    new "谢谢你让我感觉好些了。"

translate chinese chinese_6457768_451:
    old "No problem, I understand, that kind of thing can make you feel really bad."
    new "没问题，我理解，那种事情确实会让人感觉很糟糕。"

translate chinese chinese_0422282_452:
    old "I'm glad you're ok now."
    new "很高兴你现在没事了。"

translate chinese chinese_7796992_453:
    old "Now that I see you feel better, I think I should go home."
    new "既然看到你感觉好多了，我想我该回家了。"

translate chinese chinese_3739100_454:
    old "Sure, no problem. Bye."
    new "好的，没问题。再见。"

translate chinese chinese_7783192_455:
    old "Hey Lydia. How are you today?"
    new "嘿，莉迪亚。今天怎么样？"

translate chinese chinese_2507771_456:
    old "Hi [pla]! Nice seeing you. You arrive just at the perfect time."
    new "嗨 [pla]！见到你真好。你来得正是时候。"

translate chinese chinese_4339362_457:
    old "The perfect time? For what?"
    new "完美时机？干什么？"

translate chinese chinese_1165937_458:
    old "You see, I've been talking to this new guy on Tinder, and the conversations have been going pretty well."
    new "你知道吗，我在Tinder上认识了一个新 guy，聊天聊得还不错。"

translate chinese chinese_2533635_459:
    old "Yeah, it is."
    new "是的，就是那样。"

translate chinese chinese_3706326_460:
    old "The thing is that he has been asking to see some pictures of me for a while..."
    new "问题是，他之前就一直想看我的照片……"

translate chinese chinese_1667611_461:
    old "And he has sent me a lot of pics, and the conversation is going really well, so, I want to send them to him a few ones."
    new "而且他发了很多照片给我，聊天也很顺利，所以我想给他回几张。"

translate chinese chinese_5767664_462:
    old "But, to be honest, I don't really know what to send him."
    new "但是说实话，我真的不知道该给他送什么。"

translate chinese chinese_7274428_463:
    old "So, I think you could take some pictures of me so I can send him some good ones."
    new "所以，我觉得你可以给我拍些照片，这样我可以给他发些好的。"

translate chinese chinese_3049822_464:
    old "So, what do you say? Do you think you can do it?"
    new "那么，你怎么说？你觉得你能做到吗？"

translate chinese chinese_3814834_465:
    old "Hmm, sure, I guess I can."
    new "嗯，好吧，我想我可以。"

translate chinese chinese_3932181_466:
    old "Ok, I think something casual, like this, what do you think?"
    new "好的，我觉得来点轻松的，像这样，你觉得如何？"

translate chinese chinese_8511184_467:
    old "It looks great!"
    new "看起来很棒！"

translate chinese chinese_8769147_468:
    old "But it's ok, take it, if you like it I think he will too."
    new "但是没关系，拿去吧，如果你喜欢的话，我想他也会喜欢的。"

translate chinese chinese_2267122_469:
    old "Is it ok? Do you like it?"
    new "怎么样？你喜欢吗？"

translate chinese chinese_9634505_470:
    old "Yeah, I think it looks very good."
    new "是的，我觉得看起来很好。"

translate chinese chinese_3644852_471:
    old "Great! So, next one."
    new "好极了！下一个。"

translate chinese chinese_6465599_472:
    old "Ok, for this one I want to try something a little hotter."
    new "好的，这次我想试试更刺激一点的。"

translate chinese chinese_2641952_473:
    old "Does my ass look good enough?"
    new "我的屁股看起来够好吗？"

translate chinese chinese_2305426_474:
    old "Sure, I think it looks great."
    new "当然，我觉得看起来很棒。"

translate chinese chinese_2482767_475:
    old "Do I look fat? What do you think? Do you like that one?"
    new "我看起来胖吗？你觉得呢？你喜欢那个吗？"

translate chinese chinese_4667184_476:
    old "Don't worry, I think you look just perfect."
    new "别担心，我觉得你看起来刚刚好。"

translate chinese chinese_7634758_477:
    old "Great, I've got an idea for the next one."
    new "好主意，我有个下一个的点子。"

translate chinese chinese_1887825_478:
    old "Ha! I knew it, you men and breasts, I don't know why you're so crazy about them."
    new "哈！我就知道，你们男人一看见胸部就疯了，真不知道你们为什么这么迷恋它们。"

translate chinese chinese_0390321_479:
    old "The truth is, he's already sent me a couple of pictures of himself."
    new "其实，他已经给我发了几张他的照片。"

translate chinese chinese_8227146_480:
    old "And some of those are actually very spicy."
    new "其中一些actually非常辣。"

translate chinese chinese_8803983_481:
    old "So, I thought that maybe I could send him some like that too."
    new "所以，我想我也可以给他发一些那样的东西。"

translate chinese chinese_1161978_482:
    old "I- I think it's great."
    new "我——我觉得很好。"

translate chinese chinese_5711146_483:
    old "Yeah, I can see that. Fufu."
    new "嗯，我看得出来。呋呋。"

translate chinese chinese_7656399_484:
    old "Anyway, take the picture."
    new "总之，把照片拿走。"

translate chinese chinese_9888636_485:
    old "So how does the picture look?"
    new "那情况看起来怎么样？"

translate chinese chinese_7180647_486:
    old "Very well I think."
    new "还不错吧。"

translate chinese chinese_5566790_487:
    old "And my breasts? They don't look soggy or wrinkled?"
    new "还有我的胸部？不会显得松软或起皱吧？"

translate chinese chinese_3750453_488:
    old "No, no, they look great as well."
    new "不，不，她们看起来也很好。"

translate chinese chinese_8729948_489:
    old "That's great, I'm glad that's how it is."
    new "太好了，我很高兴是这样。"

translate chinese chinese_2643066_490:
    old "That was very good [pla], thank you."
    new "那非常好[pla]，谢谢。"

translate chinese chinese_3688902_491:
    old "It's ok, happy to help."
    new "没事，乐意帮忙。"

translate chinese chinese_8249896_492:
    old "I hope he likes the pictures."
    new "希望他喜欢这些照片。"

translate chinese chinese_8434666_493:
    old "I'm sure he will, you look great, don't worry."
    new "我相信他会的，你看起来很棒，别担心。"

translate chinese chinese_5490142_494:
    old "Well thank you, that's very sweet of you."
    new "嗯，谢谢，你真甜。"

translate chinese chinese_5182683_495:
    old "I believe you this time."
    new "这次我相信你。"

translate chinese chinese_5081208_496:
    old "After all, I can see it this time."
    new "毕竟，这次我看得出来。"

translate chinese chinese_1963982_497:
    old "Sorry, it's just that you took your shirt off all of a sudden."
    new "抱歉，只是你突然把衬衫脱了。"

translate chinese chinese_1394574_498:
    old "It's ok, don't worry, I actually like to see that reaction."
    new "没事，别担心，我其实喜欢看到那样的反应。"

translate chinese chinese_3383354_499:
    old "I think it's very flattering."
    new "我觉得这很令人受宠若惊。"

translate chinese chinese_1283488_500:
    old "To see such a young man get so hard because of me, I can never get tired of it."
    new "看到这么年轻的男子因为我变得如此兴奋，我永远都不会厌倦。"

translate chinese chinese_2340782_501:
    old "In fact, how about I help you with that? I know it can take a while for your dick to calm down."
    new "事实上，要不我来帮你吧？我知道你的 dicks 需要一段时间才能平静下来。"

translate chinese chinese_5649053_502:
    old "You don't really have to do it."
    new "你真的不用这么做。"

translate chinese chinese_1315108_503:
    old "Well, you helped me with the pictures, it's fine if I help you back. Don't you think?"
    new "好吧，你帮我处理照片了，我帮你回下也是应该的，你不觉得吗？"

translate chinese chinese_5880310_504:
    old "And to be honest, doing these photos made me a bit horny..."
    new "说实话，拍这些照片让我有点兴奋..."

translate chinese chinese_9696003_505:
    old "Now come, let me help you."
    new "来，让我帮你。"

translate chinese chinese_7154506_506:
    old "I didn't notice last time, but your dick has a great smell."
    new "上次没注意，你的丁丁味道真好。"

translate chinese chinese_5690952_507:
    old "And I can't believe how hard you get."
    new "真不敢相信你这么硬。"

translate chinese chinese_0274228_508:
    old "Young men are amazing."
    new "年轻男人真是了不起。"

translate chinese chinese_8771054_509:
    old "It's sooo big too."
    new "而且还大得离谱。"

translate chinese chinese_5416673_510:
    old "Honestly I'm not sure it will fill all in my mouth."
    new "老实说，我不确定它能不能完全填满我的嘴。"

translate chinese chinese_5020286_511:
    old "But don't worry, I'll make sure you finish in a moment."
    new "但别担心，我保证一会儿就让你爽完。"

translate chinese chinese_7925593_512:
    old "Well, I think I should go home."
    new "嗯，我想我该回家了。"

translate chinese chinese_0218514_513:
    old "Sure thing, thanks again for the pictures. I'll let you know if he likes them."
    new "没问题，再次感谢照片。如果他喜欢的话我会告诉你。"

translate chinese chinese_0167560_514:
    old "I mean, what the fuck mom?! What the actual fuck?!"
    new "我说妈，你特么在搞什么？！你到底在搞什么鬼？！"

translate chinese chinese_1387109_515:
    old "Now you're coming home late? JESUS!"
    new "现在你开始晚归了？天啊！"

translate chinese chinese_1453104_516:
    old "After all those times you scolded me for doing it when I was a teenager. And not only that, but I'm sure you were on a date with someone."
    new "当年你老是骂我十几岁时做这事，而且肯定还是在跟人约会的时候。"

translate chinese chinese_9508420_517:
    old "I imagine it was some guy you must've met there. What's wrong with you?"
    new "我想那一定是你在那儿遇到的某个家伙。你这是怎么了？"

translate chinese chinese_7375526_518:
    old "Don't you realize you're too old to be going out with guys like those?"
    new "你难道不觉得自己年纪太大，不适合跟那样的男生出去吗？"

translate chinese chinese_5685627_519:
    old "Honestly..."
    new "老实说..."

translate chinese chinese_7919009_520:
    old "Why are you so angry?"
    new "你为什么这么生气？"

translate chinese chinese_8738014_521:
    old "I get that I forgot to tell you I was going out last night, but that's no reason to be acting like this."
    new "我知道我忘了告诉你我昨晚出去了，但这不代表你这么反应是有道理的。"

translate chinese chinese_4844795_522:
    old "Listen, your mother is a mature woman, and I have every right to go out and date anyone I want to."
    new "听着，你妈妈是个成熟的女性，我有权出去和任何我想交往的人约会。"

translate chinese chinese_4229458_523:
    old "I DON'T GIVE A FUCK!"
    new "我根本不在乎！"

translate chinese chinese_8506369_524:
    old "I just don't want to go around picking up random dudes that you find on the street!"
    new "我就是不想随便捡个街上的陌生男人！"

translate chinese chinese_5977305_525:
    old "I mean, what's everyone going to think? That you're just some whore looking for dick!"
    new "我是说，别人会怎么想？觉得你就是一个到处找男人的烂婊子！"

translate chinese chinese_0820944_526:
    old "They would be right by the way! Because that's what you're acting like!!!"
    new "他们说得对！因为你就是那样表现的！！！"

translate chinese chinese_5775046_527:
    old "Ugh! I'm so mad mom! I swear to god!"
    new "哎！妈的我太生气了！我发誓！"

translate chinese chinese_5452746_528:
    old "You know what? I won't keep talking about this!"
    new "你知道吗？我不会再提这件事了！"

translate chinese chinese_0484375_529:
    old "I'm out of here!"
    new "我闪了！"

translate chinese chinese_6305342_530:
    old "Oh [pla], hi. How are you?"
    new "哦，[pla]，你好吗？"

translate chinese chinese_2240880_531:
    old "Never mind me, how about you? What was Anna mad about this time?"
    new "别管我了，你呢？这次安娜又为什么生气了？"

translate chinese chinese_4925509_532:
    old "Well, remember the guy that we took the pictures for?"
    new "嗯，记得我们给他拍照的那个家伙吗？"

translate chinese chinese_5057833_533:
    old "Well, we went out on a date, and we ended up staying out until very late, and Anna noticed it."
    new "嗯，我们出去约会了，结果一直待到很晚，安娜注意到了。"

translate chinese chinese_3049968_534:
    old "As you can see, she's not too thrilled about it."
    new "你看，她对此不太高兴。"

translate chinese chinese_3690385_535:
    old "Yeah, I caught that she's not too happy about the situation."
    new "是啊，我看得出来她对这种情况不太高兴。"

translate chinese chinese_5700211_536:
    old "But so what? You're a grown woman, and she can't be telling you what to do or not."
    new "但这又怎样？你是个大人了，她不能告诉你该做什么不该做什么。"

translate chinese chinese_5089959_537:
    old "I don't know, lately I've been thinking that she may be right and that I'm actually acting like a whore."
    new "我不知道，最近我在想她可能是对的，我实际上是在像妓女一样行事。"

translate chinese chinese_9247197_538:
    old "Whoah, whoah, whoah."
    new "谁啊，谁啊，谁啊。"

translate chinese chinese_8280507_539:
    old "No, no, let's not go there."
    new "不，不，我们不要谈这个。"

translate chinese chinese_7513732_540:
    old "Listen, Anna's just angry, and since she's such a hothead she doesn't know how to deal with it."
    new "听着，安娜只是生气了，因为她是个急性子，所以不知道该怎么处理。"

translate chinese chinese_2022046_541:
    old "All she knows is how to get angry, scream and be cruel. Don't pay any attention to what she says, ok?"
    new "她只知道生气、尖叫和刻薄。别理会她说的话，好吗？"

translate chinese chinese_6558679_542:
    old "Ok, I guess you have a point."
    new "好吧，我猜你有点道理。"

translate chinese chinese_9832834_543:
    old "Now, tell me how your night went."
    new "好了，告诉我你晚上过得怎么样。"

translate chinese chinese_4486384_544:
    old "It sounds like it was a very good time."
    new "听起来那段时间很愉快。"

translate chinese chinese_5304080_545:
    old "Hmm, yeah, I guess so..."
    new "嗯，是啊，我想是这样..."

translate chinese chinese_5085911_546:
    old "Yeah? Because you don't look very excited about it."
    new "是吗？因为你看起来并不太兴奋。"

translate chinese chinese_0216578_547:
    old "Well... you see."
    new "嗯……你瞧。"

translate chinese chinese_9718160_548:
    old "The date went well, he was a perfect gentleman, and I think we had a lot of chemistry. He actually said he wanted to see me again soon."
    new "约会进行得很顺利，他是个完美的绅士，我觉得我们很有火花。他还说想尽快再见到我。"

translate chinese chinese_8389633_549:
    old "But that got me thinking, with the way things are going, that we could end up having sex next time."
    new "但那让我想到，照这样下去，下次可能会发生性关系。"

translate chinese chinese_1059380_550:
    old "Well, yeah, that's usually how those things go."
    new "嗯，是啊，这种事情通常都是这样的。"

translate chinese chinese_3878411_551:
    old "You don't want to?"
    new "你不想吗？"

translate chinese chinese_8366274_552:
    old "It's not that, I obviously want to."
    new "不是那样的，我当然是想的。"

translate chinese chinese_1450874_553:
    old "The problem is that it's been a while since I had sex for the last time."
    new "问题是，我上次做爱已经很久以前了。"

translate chinese chinese_4463479_554:
    old "Even with my deceased husband, the last few years of our relationship we barely had any contact."
    new "就连我已故的丈夫，在我们关系最后几年里，我们也几乎没有任何联系。"

translate chinese chinese_7193102_555:
    old "I'm afraid that I'm not gonna be good enough or that I'll end up disappointing him."
    new "我怕自己不够好，或者最后让他失望。"

translate chinese chinese_7848837_556:
    old "After all this time it's a lot of pressure you know?"
    new "毕竟过了这么久，压力挺大的你知道吗？"

translate chinese chinese_3924120_557:
    old "Especially since I'm not sure he'll like my body."
    new "尤其是我不确定他会不会喜欢我的身体。"

translate chinese chinese_8563374_558:
    old "What if he thinks that I'm too old? or that I'm not hot enough?"
    new "如果他认为我太老了怎么办？或者觉得我不够火辣？"

translate chinese chinese_2858464_559:
    old "What? Not at all!"
    new "什么？根本不是！"

translate chinese chinese_0696379_560:
    old "Don't even think about it. That guy has already seen pictures of you, and if he says that you're hot, you should believe him."
    new "别想了，那家伙已经看过你的照片了，他说你性感你应该相信他。"

translate chinese chinese_0024200_561:
    old "Everything is gonna be fine, believe me."
    new "一切都会好的，相信我。"

translate chinese chinese_0046195_562:
    old "Ok, I'll stop worrying about it. Thanks again [pla], I don't know what I would do without all your help."
    new "好吧，我不再担心了。再次感谢[pla]，没有你的帮助我真不知道该怎么办。"

translate chinese chinese_1679378_563:
    old "Don't even mention it."
    new "别提了。"

translate chinese chinese_3049996_564:
    old "Hmmm."
    new "嗯哼。"

translate chinese chinese_2888195_565:
    old "So, since I'm already here, do you want us to browse through some tinder profiles?"
    new "所以，既然我已经来了，你想我们一起看看一些 Tinder 的资料吗？"

translate chinese chinese_2002510_566:
    old "I don't really feel like doing that right now, besides, since Anna is in her room she could come down any second."
    new "我现在真的不想做这个，再说安娜在房间里，随时可能会下来。"

translate chinese chinese_5991407_567:
    old "I don't want to have to deal with her temper again today."
    new "我今天不想再应付她的脾气了。"

translate chinese chinese_4395511_568:
    old "I understand, then I guess it's better if I leave."
    new "我明白了，那我还是离开比较好。"

translate chinese chinese_3640336_569:
    old "But before I go, remember what I told you."
    new "但在走之前，记得我说的话。"

translate chinese chinese_9224724_570:
    old "You're a beautiful woman, and you're in your right to be or date anyone."
    new "你是个美丽的女人，有权选择或约会任何人。"

translate chinese chinese_2749030_571:
    old "No matter what Anna thinks about that. She can keep her opinions to herself."
    new "不管安娜怎么想，她可以把她的意见留给自己。"

translate chinese chinese_8537215_572:
    old "Thank you [pla] I'll be sure to remember that."
    new "谢谢[pla]，我一定会记住的。"

translate chinese chinese_9624618_573:
    old "That's cool, goodbye then."
    new "那好吧，再见了。"

translate chinese chinese_6848710_574:
    old "Hi [pla], I guess I'm fine, thank you."
    new "你好 [pla]，我猜我还不错，谢谢。"

translate chinese chinese_3803448_575:
    old "You guess? What happened?"
    new "你猜怎么了？"

translate chinese chinese_5116122_576:
    old "Oh [pla], it's just so bad..."
    new "哦 [pla]，真是糟糕透了……"

translate chinese chinese_2994400_577:
    old "What's bad? You're worrying me now, tell me."
    new "怎么了？你现在吓到我了，告诉我。"

translate chinese chinese_5515409_578:
    old "Well, the thing is that I did go on that date with the guy I told you about."
    new "好吧，其实我确实和我跟你说过的那个家伙出去约会了。"

translate chinese chinese_6923606_579:
    old "I suppose it went well, just like last time he was a gentleman, the conversation was good and we had a good time."
    new "我想挺顺利的，就像上次一样，他很绅士，聊天也很愉快，我们玩得很开心。"

translate chinese chinese_3224807_580:
    old "The problem came later... when we were about to have sex."
    new "问题后来才出现……当我们准备做爱的时候。"

translate chinese chinese_4395334_581:
    old "Ohh... Why?"
    new "哦……为什么？"

translate chinese chinese_4626959_582:
    old "Well, after dinner he asked me if I wanted to continue the evening at his house, I said yes and we went there."
    new "嗯，晚饭后他问我是否愿意去他家继续度过晚上，我说好，然后我们就去了。"

translate chinese chinese_8246990_583:
    old "I really wanted to do it, and things were going so well..."
    new "我真的想做，而且一切进行得那么顺利……"

translate chinese chinese_3814503_584:
    old "But, I just couldn't do it... I got nervous and uncomfortable."
    new "但是，我就是做不到……我紧张得不行，感觉很不自在。"

translate chinese chinese_9994984_585:
    old "Was it something he did?"
    new "是他做了什么吗？"

translate chinese chinese_0192477_586:
    old "Oh no, nothing like that, he was actually very nice, as I said, a perfect gentleman."
    new "哦不，不是那样的，他实际上很好，就像我说的，一个完美的绅士。"

translate chinese chinese_2692060_587:
    old "I was the one with the problem, no matter what we tried all I could think was about my husband, and Anna's words."
    new "不管我们试什么，我心里想的只有我的丈夫和安娜的话，问题出在我身上。"

translate chinese chinese_4706081_588:
    old "Telling me that I was ugly and undesirable, that what I was doing was wrong."
    new "告诉我我很丑没人要，说我做的事情不对。"

translate chinese chinese_5055192_589:
    old "After a while, I just backed out and asked him to drive me home."
    new "过了一会儿，我就退了出来，让他送我回家。"

translate chinese chinese_9872436_590:
    old "After all I think Mrs. Jones was right, at my age it's just impossible for me to form a connection with another person."
    new "毕竟我觉得琼斯太太说得对，像我这个年纪，根本不可能再和其他人建立联系了。"

translate chinese chinese_6501743_591:
    old "I think I should just give up and become a church lady like her."
    new "我觉得我还是放弃吧，像她一样当个教会女士。"

translate chinese chinese_3672850_592:
    old "Wait, wait, don't say that."
    new "等一下，别那样说。"

translate chinese chinese_6822659_593:
    old "Listen, what you went through is perfectly normal, you don't need to beat yourself over it."
    new "听着，你经历的这一切都很正常，不用自责。"

translate chinese chinese_3413742_594:
    old "Sure it would be good if you could have sex with the guy."
    new "当然，如果你能和他上床那就最好了。"

translate chinese chinese_8525322_595:
    old "But think about it, you were out of the dating game for a long time, it's ok to feel insecure."
    new "但想想吧，你很久没有谈恋爱了，感觉不安全是很正常的。"

translate chinese chinese_2663819_596:
    old "There's no need for you to feel that you're going to become someone like Mrs. Jones."
    new "你不需要觉得你会变成像琼斯太太那样的人。"

translate chinese chinese_4436105_597:
    old "That's very cute of you, but [pla] I don't know, it's just too difficult."
    new "你这么说很可爱，但是 [pla] 我不知道，就是太难了。"

translate chinese chinese_7604004_598:
    old "It is, but that doesn't mean you should give up, or pay any attention to what Anna says."
    new "是这样的，但这不意味着你应该放弃，或者在意安娜说什么。"

translate chinese chinese_2245884_599:
    old "Listen, you're doing this for yourself, not for Anna, or your husband or anyone else, just for you."
    new "听着，你是为自己做的，不是为了安娜，也不是为了你的丈夫或者其他任何人，只是为了你自己。"

translate chinese chinese_7021376_600:
    old "You have every right to be happy and to search for that happiness."
    new "你有权快乐，也有权去寻找那份快乐。"

translate chinese chinese_1296110_601:
    old "So, there's no need for you to feel guilty about living your life."
    new "所以，你不需要因为活自己的生活而感到内疚。"

translate chinese chinese_7748391_602:
    old "I understand what you're saying, but I don't know how to do it."
    new "我明白你的意思，但我不知道该怎么去做。"

translate chinese chinese_1742426_603:
    old "How do I manage to do it when I feel so uncomfortable?"
    new "我感觉这么别扭要怎么去做呢？"

translate chinese chinese_7090033_604:
    old "I wasn't able to even get naked!"
    new "我连脱衣服的机会都没有！"

translate chinese chinese_5662856_605:
    old "I can't imagine even trying to be even more intimate in a physical way."
    new "我甚至无法想象在身体上更加亲密。"

translate chinese chinese_4775735_606:
    old "Hmm... It's just you haven't done it in a long time, you're a bit... Rusty..."
    new "嗯……就是你很久没做了，有点……生疏了……"

translate chinese chinese_2940038_607:
    old "But how do I fix it? How can I ever be able to have some sexual contact again?"
    new "但是怎么解决呢？我怎么能再次有性接触的机会呢？"

translate chinese chinese_2307620_608:
    old "Wait... What about me?"
    new "等一下……那我呢？"

translate chinese chinese_2875259_609:
    old "Well, you say that, but you've been able to do a few sexual things with... me."
    new "话说回来，你还是和……我做过一些性方面的事情的。"

translate chinese chinese_8145228_610:
    old "Oh... Yeah well, that's different."
    new "哦……是的，那个情况不同。"

translate chinese chinese_4603749_611:
    old "I don't know... with you it doesn't feel like I'm doing some weird thing with a stranger, you just feel... safer."
    new "我不知道……和你在一起的时候，感觉不像在和陌生人做奇怪的事情，反而觉得……更安全。"

translate chinese chinese_6677178_612:
    old "With this other guy I felt very awkward like we didn't have a bond, or anything connecting us."
    new "和那个家伙在一起时我觉得很别扭，感觉我们之间没有任何联系。"

translate chinese chinese_9456052_613:
    old "Hmph, I think I get what you're saying."
    new "哼，我觉得我懂你的意思了。"

translate chinese chinese_5367325_614:
    old "Oh, I have an idea."
    new "哦，我有个主意。"

translate chinese chinese_0305670_615:
    old "I think that my problem might be taking that first step to physical intimacy. That's what's holding me back."
    new "我觉得我的问题可能是迈不出那第一步走向身体亲密。这才是让我退缩的原因。"

translate chinese chinese_2464854_616:
    old "It's just as you said, I'm rusty, so, maybe I just need a bit of practice?"
    new "就像你说的，我生疏了，所以 maybe 我只是需要多练习一下？"

translate chinese chinese_0344442_617:
    old "Practice?"
    new "练习？"

translate chinese chinese_2935441_618:
    old "I think that if I do it with someone at least once, from there on it should be a lot easier with other guys."
    new "我觉得如果至少和一个人做过一次，以后和其他人就会容易多了。"

translate chinese chinese_5281183_619:
    old "Ohh, I get it... Well, that makes a lot of sense. I think you're right."
    new "哦，我明白了……嗯，说得挺有道理的。我觉得你是对的。"

translate chinese chinese_4312307_620:
    old "But who are you gonna do it with first?"
    new "但是你先和谁来呢？"

translate chinese chinese_1507128_621:
    old "Well... so far there's only one man I think I feel comfortable enough to do it with."
    new "嗯……到目前为止，只有一个人让我觉得足够舒服可以这样做。"

translate chinese chinese_1929722_622:
    old "And who is it?"
    new "那是谁？"

translate chinese chinese_4531078_623:
    old "Oh wait, you don't mean... me?!"
    new "哦等下，你不会是指...我吧？！"

translate chinese chinese_3554008_624:
    old "What can I tell you? As you've seen you're the only one with which I've been able to do anything without feeling weird."
    new "还能怎么说呢？你看，只有和你在一起的时候，我才能不做怪地做些事情。"

translate chinese chinese_1120274_625:
    old "B- but you know."
    new "你、你知道的。"

translate chinese chinese_0518375_626:
    old "I know, it sounds crazy, and maybe I'm just saying this impulsively, but this wouldn't be the first time we do something of the sort."
    new "我知道这听起来很疯狂，也许我只是冲动了，但这种事情我们以前也不是没做过。"

translate chinese chinese_1777773_627:
    old "And I think that I wouldn't have any problem if it were you, I'm clearly comfortable with you...."
    new "而且我觉得如果是你的话，我不会有问题的，我显然对你很放松...."

translate chinese chinese_6385360_628:
    old "B- but, that would be way too far over the line!"
    new "这、这太过分了！"

translate chinese chinese_3088940_629:
    old "You are right... I better stop this and settle down."
    new "你说得对……我最好停下来，安定下来。"

translate chinese chinese_6339594_630:
    old "No, no, it's not about that."
    new "不，不，不是那回事。"

translate chinese chinese_8670777_631:
    old "It's just that the solution sounds way too drastic."
    new "只是这个解决方案听起来太极端了。"

translate chinese chinese_5975123_632:
    old "Why don't you try other solutions first? Going to therapy, or maybe trying with some other dude..."
    new "为什么不先试试其他方法呢？去治疗一下，或者试试和其他人在一起……"

translate chinese chinese_9230895_633:
    old "Oh please, you know that's not going to help me!"
    new "哦拜托，你知道那对我没帮助的！"

translate chinese chinese_6387322_634:
    old "Besides, this isn't easy for me either."
    new "再说，这对我来说也不容易。"

translate chinese chinese_6401840_635:
    old "Just imagine how embarrassing it would be to keep trying with one and another person without managing to do anything."
    new "想象一下，一直尝试着和一个人又另一个人在一起却什么都做不成，那该有多尴尬。"

translate chinese chinese_3338372_636:
    old "It's not like I want my life to be in shambles like this, you know [pla]?"
    new "我又不是想让自己的生活变成这样一团糟，你知道吧[pla]？"

translate chinese chinese_4075917_637:
    old "All I'm telling you is that I'm trying to put my life back together so that I don't end up like Mrs. Jones."
    new "我告诉你的就是，我正在努力把生活重新整理好，以免变成琼斯太太那样。"

translate chinese chinese_7888805_638:
    old "Won't you help me with that?"
    new "你不帮我吗？"

translate chinese chinese_4784237_639:
    old "After all, it would just be this one time, just so that I get used to it again."
    new "毕竟这只是一次，只是为了让我重新习惯而已。"

translate chinese chinese_6459939_640:
    old "Hmm, I suppose what you're saying makes sense."
    new "嗯，我想你说的也有道理。"

translate chinese chinese_8684092_641:
    old "I'm not sure I like this, but ok, I suppose we can do it."
    new "我不太确定我喜欢这个，但好吧，我想我们可以试试。"

translate chinese chinese_2849230_642:
    old "Really? Thank you so much [pla]!"
    new "真的吗？谢谢你这么多[pla]！"

translate chinese chinese_0003433_643:
    old "Don't worry just lie on the couch and leave everything to me!"
    new "别担心，你就躺在沙发上，一切交给我好了！"

translate chinese chinese_4994867_644:
    old "I think the best thing is that I go for today."
    new "我觉得今天还是算了。"

translate chinese chinese_7212036_645:
    old "Are you going to keep talking with the guy?"
    new "你还要继续和这家伙聊天吗？"

translate chinese chinese_3547418_646:
    old "I will, I really like him, so, I hope we can have another date."
    new "我会的，我真的很喜欢他，所以希望我们能再约会一次。"

translate chinese chinese_9717497_647:
    old "And this time I'm sure everything will go well."
    new "这次我敢肯定一切都会顺利的。"

translate chinese chinese_8601125_648:
    old "I'm sure it will, good luck."
    new "我相信会的，祝你好运。"

translate chinese chinese_7009060_649:
    old "Oh hi [pla]! It's good seeing you."
    new "哦，嗨 [pla]！见到你真好。"

translate chinese chinese_0383108_650:
    old "I'm fine thanks for asking!"
    new "我挺好的，谢谢关心！"

translate chinese chinese_6960364_651:
    old "Great, so tell me, everything went well on your date, right?"
    new "好了，跟我说说，你们约会一切都顺利吧？"

translate chinese chinese_6347656_652:
    old "Oh, that? Not at all!"
    new "哦，那个？根本不是！"

translate chinese chinese_7614832_653:
    old "What's with that face?"
    new "你怎么了，这副表情？"

translate chinese chinese_1838954_654:
    old "Don't tell me things went wrong again on your date."
    new "别告诉我你的约会又出问题了。"

translate chinese chinese_6448679_655:
    old "Ugh. Then I don't know what else to tell you."
    new "唉。那我也不知道还能告诉你什么了。"

translate chinese chinese_2580856_656:
    old "Nothing happened, that's the problem."
    new "什么都没发生，这才是问题。"

translate chinese chinese_9627413_657:
    old "Nothing? Nothing at all?"
    new "什么都没有？一点都没有？"

translate chinese chinese_7700282_658:
    old "Well, yes..."
    new "嗯，是的……"

translate chinese chinese_6800534_659:
    old "Oh [pla], that was so frustrating"
    new "哦 [pla]，真让人 frustratening"

translate chinese chinese_4802081_660:
    old "But why?"
    new "但是为什么？"

translate chinese chinese_2943352_661:
    old "I don't know, the date went well, he was as well behaved as always, but when the moment came I just felt that I couldn't do it."
    new "我不知道，约会挺顺利的，他一直都很规矩，但到了那一刻我就觉得没法继续了。"

translate chinese chinese_5521250_662:
    old "But, I thought you had gotten over your intimacy problem, that's why we did what we did, right?"
    new "但是，我以为你已经克服了你的亲密问题，所以我们才做了那些事，对吧？"

translate chinese chinese_3581607_663:
    old "Yeah, yeah, and I think it did help. After all, this time I wasn't scared or feeling bad or anything."
    new "嗯嗯，我觉得这确实有帮助。毕竟这次我一点也不害怕，也没有感到难过什么的。"

translate chinese chinese_4270338_664:
    old "I just didn't want him to put his hands on me, I don't know, I guess we just didn't have any sexual attraction."
    new "我只是不想让他碰我，我不知道，我想我们之间可能没什么性吸引力。"

translate chinese chinese_9134255_665:
    old "You have no idea how annoyed I am because of that."
    new "你根本不知道那件事让我有多生气。"

translate chinese chinese_5093664_666:
    old "Hmm, well, if you say that you didn't feel bad or scared, I guess that's a good thing."
    new "嗯，好吧，如果你说你没有感到难过或害怕，那我想这是一件好事。"

translate chinese chinese_3479979_667:
    old "Those things happen."
    new "这种事情时有发生。"

translate chinese chinese_3724747_668:
    old "I'm still very frustrated though."
    new "不过我仍然很沮丧。"

translate chinese chinese_8627462_669:
    old "But I understand that the problem wasn't me, I think the problem was that I didn't like him enough."
    new "但是我知道问题不在我，我觉得问题是我不够喜欢他。"

translate chinese chinese_4927209_670:
    old "Hmph, if you say so."
    new "哼，你说的算。"

translate chinese chinese_4323647_671:
    old "Oh, don't be mad, at least I'm not feeling bad about it."
    new "哦，别生气了，至少我不觉得难过。"

translate chinese chinese_5738283_672:
    old "Just a little bit annoyed."
    new "有点烦。"

translate chinese chinese_8127479_673:
    old "I guess we can call that a silver lining..."
    new "我想我们可以称之为一线希望……"

translate chinese chinese_6122565_674:
    old "But if that's not the thing that has you in a good mood, what is it?"
    new "但如果那不是让你心情好的原因，那是什么？"

translate chinese chinese_4316699_675:
    old "Right, that!"
    new "对，就是那个！"

translate chinese chinese_2752831_676:
    old "I've been talking to another guy, and actually, things seem to be going well."
    new "我最近在和其他人聊天，实际上进展得还不错。"

translate chinese chinese_9364255_677:
    old "We haven't met, but I really like his personality."
    new "我们没见过面，但我真的很喜欢他的性格。"

translate chinese chinese_5647790_678:
    old "That's cool."
    new "那挺好的。"

translate chinese chinese_7222570_679:
    old "Hmm, in fact, I think you could help me out with that."
    new "嗯，其实我觉得你能帮我一下。"

translate chinese chinese_9325278_680:
    old "Help you?"
    new "帮你的？"

translate chinese chinese_4488951_681:
    old "Yeah, to talk to him, just before you arrived we were in the middle of a conversation."
    new "是啊，正准备和他说话，你来之前我们正在聊天。"

translate chinese chinese_4417574_682:
    old "I think you could help me chat with him."
    new "我觉得你能帮我跟他聊聊。"

translate chinese chinese_1608182_683:
    old "Hmm, I don't know... I mean, if you've been talking with these guys I think you can keep up the conversation without my help."
    new "嗯，我不知道……我的意思是，如果你已经在和这些人聊天了，我觉得你可以不用我的帮助继续聊下去。"

translate chinese chinese_3731695_684:
    old "Oh, don't say that, you are really a great help to me."
    new "哦，别这么说，你真的帮了我大忙。"

translate chinese chinese_7882471_685:
    old "But you know I have some problems with the keyboard and his expressions."
    new "但是你知道我对键盘和他的表情有些问题。"

translate chinese chinese_4696475_686:
    old "I guess you're right. I suppose it would do no harm to give you a hand."
    new "我想你是对的。帮帮你也没什么坏处。"

translate chinese chinese_3540649_687:
    old "Great, then, let's go to the sofa to chat more comfortably."
    new "好的，那我们去沙发那边更舒服地聊吧。"

translate chinese chinese_5710174_688:
    old "This is where we were in the conversation a little before you arrived."
    new "这就是你在来之前我们聊到的地方。"

translate chinese chinese_6510488_689:
    old "I see, things seem to be going well."
    new "我明白了，看来一切都挺顺利的。"

translate chinese chinese_4237802_690:
    old "I guess they are... so what do I tell him now?"
    new "我猜他们是……那我现在该怎么跟他说？"

translate chinese chinese_7433535_691:
    old "Well, as I told you last time, you have to be playful, but a little suggestive."
    new "嗯，就像上次告诉你的那样，你要玩得开心一点，但也要有点挑逗意味。"

translate chinese chinese_9111713_692:
    old "I was​​ thinking of telling him something about my clothes, about how sexy they would be."
    new "我在想要不要告诉他关于我的衣服，有多性感。"

translate chinese chinese_4880192_693:
    old "That sounds good, how do you want me to say it?"
    new "听起来不错，你想要我怎么说？"

translate chinese chinese_7757620_694:
    old "Like this 'To start, I would get there wearing a trench coat'."
    new "比如这个“首先，我会穿着风衣去那儿”之类的。"

translate chinese chinese_8165676_695:
    old "What? That's not sexy at all!"
    new "什么？那根本一点也不性感！"

translate chinese chinese_2041120_696:
    old "Of course it isn't, it's something I read in a magazine a long time ago, just write it."
    new "当然不是，这是我很久以前在杂志上看到的，就写这个吧。"

translate chinese chinese_7275383_697:
    old "He answered 'a trench coat?' See? That's not sexy."
    new "他回答说“一件风衣？”看吧，这不性感。"

translate chinese chinese_2514796_698:
    old "Fufu, what's sexy is what I would bring underneath."
    new "呋呋，最性感的是我会带到下面的东西。"

translate chinese chinese_7743856_699:
    old "Write 'Then I would take it off, to let you see the black lingerie that I'm wearing underneath.'"
    new "然后我会把它脱掉，让你看到我穿的黑色内衣。"

translate chinese chinese_1110382_700:
    old "Oh! I see what you mean."
    new "哦！我明白你的意思了。"

translate chinese chinese_9402776_701:
    old "He really seemed to like that, now he's asking 'Then what else?'"
    new "他好像真的很喜欢，现在还在问“那还有什么？”"

translate chinese chinese_3300762_702:
    old "I would take you by the hand and bring you to the couch, where I would want you to lay down."
    new "我会牵着你的手带你到沙发那里，让你躺下来。"

translate chinese chinese_7672469_703:
    old "He says 'Oh yeah? And what would you do once I'm laying down on the couch baby?'"
    new "他说：“哦，是吗？那等我躺在沙发上的时候，你会怎么办，宝贝？”"

translate chinese chinese_6614916_704:
    old "I would lay down on top of you, and I would take those lips of yours on a hot, rough kiss."
    new "我会躺在你身上，然后给你一个热烈而粗犷的吻。"

translate chinese chinese_4954180_705:
    old "He wrote 'I like that! But that's all you'd want?'"
    new "他写的是“我喜欢那样！但这就是你想要的全部？”"

translate chinese chinese_7198509_706:
    old "Haha, so cute, tell him 'Well, aren't we a little impatient tonight?'"
    new "哈哈，好可爱，跟他说“哼，今晚有点急不可耐嘛？”"

translate chinese chinese_3414136_707:
    old "Hmm, he says 'I'm sorry baby, it's just that I can't resist you.'"
    new "嗯，他说“对不起宝贝，我只是忍不住你。”"

translate chinese chinese_3304620_708:
    old "That's very cute of him."
    new "他真是很可爱。"

translate chinese chinese_9749454_709:
    old "Write 'It's ok, I can't resist you either.'"
    new "写“没关系，我也 resist不住你。”"

translate chinese chinese_7700881_710:
    old "So while we're kissing, I slowly bring my hand down your chest, pass your abs... and over that big bulging dick under your pants."
    new "所以我们接吻的时候，我慢慢把手从你的胸口滑下，经过你的腹肌……然后移到你裤子下面那根大大的硬挺的棒上。"

translate chinese chinese_3149330_711:
    old "That's it baby! Yeah, you know just what I want."
    new "就是这样宝贝！对，你知道我想要什么。"

translate chinese chinese_1245474_712:
    old "Fufu, and you haven't seen anything yet..."
    new "呋呋，你还没看到什么呢……"

translate chinese chinese_5226516_713:
    old "Tell me more!"
    new "告诉我更多！"

translate chinese chinese_6002934_714:
    old "I'll feel your big hard cock with my hand, and that is gonna make me horny..."
    new "我会用我的手感受你那粗大的硬棒，这会让我欲火焚身……"

translate chinese chinese_0959379_715:
    old "And I'm going to rub it over your pants, feeling how big it is..."
    new "然后我要在你的裤子上摩擦，感受它的大小……"

translate chinese chinese_5342199_716:
    old "Ohh, you'll love to feel every inch of me..."
    new "哦，你会喜欢感受我的每一寸肌肤……"

translate chinese chinese_1298894_717:
    old "I already love it... But you'll love what I'm going to do next..."
    new "我已经爱上它了……但是你会更爱我接下来要做的事……"

translate chinese chinese_5064550_718:
    old "Ohh yes babe, what are you gonna do next?"
    new "哦哦是的宝贝，接下来你要做什么？"

translate chinese chinese_7995443_719:
    old "Well, I'm going to kneel in front of you and I'm going to take out that huge cock."
    new "好吧，我要跪在你面前，然后拿出那巨大的 cocks。"

translate chinese chinese_8706139_720:
    old "Then, I'll bring my head down and kiss and lick the tip of your cock."
    new "然后，我会低下头吻你的鸡头，并舔舐它。"

translate chinese chinese_9461678_721:
    old "Mmm, I love that, I love how you kiss it."
    new "嗯，我喜欢这样，我喜欢你吻的样子。"

translate chinese chinese_3725225_722:
    old "That was a great conversation! Wasn't it?"
    new "那真是个很棒的聊天！不是吗？"

translate chinese chinese_9137592_723:
    old "Uhm, sure... I was very good."
    new "嗯，好吧……我很好。"

translate chinese chinese_0168040_724:
    old "I think this might be the right guy for me, he's hot, he's into me. He's just great, right?"
    new "我觉得这个人可能就是我的真命天子了，他性感，对我也挺有意的。他真的很棒，对吧？"

translate chinese chinese_5666000_725:
    old "Yeah, yeah... He sounds like a great guy."
    new "嗯哼……他听起来真是个不错的人。"

translate chinese chinese_2012525_726:
    old "Anyway, I think I should probably go now."
    new "总之，我想我现在应该走了。"

translate chinese chinese_8154884_727:
    old "You know, before Anna arrives and stuff."
    new "你知道的，在安娜来之前之类的。"

translate chinese chinese_8626264_728:
    old "Yeah, that's probably better. Thank you so much."
    new "嗯，那样可能更好。真的谢谢你。"

translate chinese chinese_2559128_729:
    old "Whoaa?! What are you doing here?!"
    new "哇?! 你在这里干什么?!"

translate chinese chinese_7280906_730:
    old "H- Heelloo [pla]!"
    new "喂喂，[pla]！"

translate chinese chinese_9519149_731:
    old "Did I zurprish you?"
    new "我给你惊喜了吗？"

translate chinese chinese_1861367_732:
    old "Did I s- surprize you?!"
    new "我吓到你了?!"

translate chinese chinese_1841681_733:
    old "Oh! Yes, you did! Why are you in my room?"
    new "哦！是的，你来了！你为什么在我房间里？"

translate chinese chinese_8326712_734:
    old "How did you get in?"
    new "你怎么进来的？"

translate chinese chinese_2534052_735:
    old "Sue gave 'e a key."
    new "苏给了他一把钥匙。"

translate chinese chinese_4713748_736:
    old "I see, well, that makes sense."
    new "我明白了，这么说也有道理。"

translate chinese chinese_7027437_737:
    old "But you still haven't answered, what are you doing in my room? And this smell... It's alcohol."
    new "但是你还没回答呢，你为什么在我房间里？还有这个味道……是酒精。"

translate chinese chinese_8958453_738:
    old "Are you drunk? I thought tonight was the night of your date."
    new "你喝醉了？我还以为今晚是你约会的日子呢。"

translate chinese chinese_2203464_739:
    old "Shouldn't you be with the guy?"
    new "你不应该陪那个家伙吗？"

translate chinese chinese_7021064_740:
    old "I 'uess I zhould be. But it didn't go well, like a' all."
    new "我猜我应该去的。但结果糟透了。"

translate chinese chinese_1318184_741:
    old "It didn't? What happened this time?"
    new "没用？这次发生了什么？"

translate chinese chinese_2735033_742:
    old "I don't know!"
    new "我不知道！"

translate chinese chinese_3430149_743:
    old "I just wasn't able to, when 'e moment came I just felt... nothing."
    new "我只是做不到，当那一刻来临时，我就是觉得……没什么。"

translate chinese chinese_6973000_744:
    old "What do you mean nothing? I thought you liked the guy."
    new "什么叫没什么？我还以为你喜欢他呢。"

translate chinese chinese_0884373_745:
    old "I did, I really did, and I think he's cute, and sexy, and funny... but I just wasn't able to focus on him."
    new "我真的做了，而且我觉得他很可爱，性感，又有趣……但我就是没法专心在他身上。"

translate chinese chinese_8817173_746:
    old "I just didn't want to do it with him... but I still want to have sex."
    new "我只是不想跟他做……但我还是想做爱。"

translate chinese chinese_5322590_747:
    old "I don't get it, if you want sex all you had to do was sleep with that guy."
    new "我不明白，如果你想做爱，只要跟那个家伙上床就行了。"

translate chinese chinese_1060099_748:
    old "I don't really think that would have worked."
    new "我觉得那根本行不通。"

translate chinese chinese_1989914_749:
    old "I think I was wrong about some'ing, I'm not the type of woman who... hips!"
    new "我觉得我有些地方错了，我不是那种……臀部！"

translate chinese chinese_0580441_750:
    old "Sorry... who sleeps around. I'm a one-man woman!"
    new "对不起……谁乱搞。我可是专一的女人！"

translate chinese chinese_3484646_751:
    old "I get that, but you told me you believed this guy was that one man, why did you suddenly backed out of it? "
    new "我明白，但是你之前告诉我你认为这个人就是你的那个唯一的人，为什么你突然退缩了？"

translate chinese chinese_5203472_752:
    old "D- don't you get it? I already have a man in my life."
    new "你... 你不明白吗？我已经有男人了。"

translate chinese chinese_7102649_753:
    old "What? Don't tell me you're still thinking about grandpa."
    new "什么？不会吧，你还在想着爷爷呢？"

translate chinese chinese_2211890_754:
    old "I think you need to move on from that, that's the whole point, that you wouldn't be caught up in the past."
    new "我觉得你需要放下那件事，这才是重点，不要老是陷在过去。"

translate chinese chinese_9207219_755:
    old "No, not, no, think about it, there's only one man that I let, and want to touch me."
    new "不，不是，想想，只有一个人让我，也想让他碰我。"

translate chinese chinese_0872051_756:
    old "You don't mean... me?!"
    new "你不会是说... 我吧?!"

translate chinese chinese_3198183_757:
    old "Who else dummy?"
    new "还能有谁傻瓜？"

translate chinese chinese_4497990_758:
    old "W- w- what?"
    new "什、什么？"

translate chinese chinese_6892341_759:
    old "As I said you're the only one I'll allow to touch me."
    new "就像我说的，你是我唯一允许碰我的人。"

translate chinese chinese_5450567_760:
    old "Not only that, you're the only man I was able to think about when I tried to do it with those other guys."
    new "不止这样，当我和其他人在一起的时候，唯一能想到的男人就是你。"

translate chinese chinese_0273119_761:
    old "Oh [pla]! I know it sounds crazy to you, but that's how it is, and I don't want to go around wasting my time with those other men."
    new "哦[pla]！我知道这听起来很疯狂，但事实就是如此，我不想去浪费时间在那些其他男人身上。"

translate chinese chinese_0084391_762:
    old "After having seen all those dick pics they kept sending me, now I only think they're not much. Nothing compared to you."
    new "看了他们一直发给我的那些照片后，我现在觉得那些都不算什么。根本比不上你。"

translate chinese chinese_7427607_763:
    old "Besides, all of those guys, they're so childish, going all out on a phone."
    new "再说，那些家伙都这么孩子气，为了一个电话这么拼命。"

translate chinese chinese_3794986_764:
    old "Ugh!"
    new "哎！"

translate chinese chinese_0647035_765:
    old "There's only one man I want to be intimate with..."
    new "我只想和一个男人亲密……"

translate chinese chinese_4892916_766:
    old "Are you for real? Do you really mean this?"
    new "你是认真的吗？真的这么想？"

translate chinese chinese_2368694_767:
    old "I do, I really do."
    new "我有，我真的有。"

translate chinese chinese_2224363_768:
    old "And I also know you want it too, come on, I know you liked it, the other times. So come on, let's just do it."
    new "而且我也知道你想要的，来吧，我知道你之前也喜欢的，所以来吧，我们就做吧。"

translate chinese chinese_5109609_769:
    old "Why do you think I came all the way here?"
    new "你觉得我为什么特地来这里？"

translate chinese chinese_8183916_770:
    old "It wasn't only to tell you that I couldn't get it on with some other guys."
    new "这不仅仅是为了告诉你我没能和其他人上床。"

translate chinese chinese_0529467_771:
    old "But- but... w- we're in my room, I don't think we should."
    new "但——但是……我们在我的房间里，我觉得我们不应该这样做。"

translate chinese chinese_5897664_772:
    old "Shhh, don't worry, nobody will listen to us. It's ok..."
    new "嘘，别担心，没人会听到我们的。没事的……"

translate chinese chinese_8116822_773:
    old "What do you think, I'm finally cutting loose and doing what I want."
    new "我觉得我终于可以放纵一下，做我想做的事了。"

translate chinese chinese_0708731_774:
    old "Ever since last time I've been wanting you to fuck me again."
    new "自从上次以后，我就想让你再干我一次。"

translate chinese chinese_8082910_775:
    old "It's because of this dick of yours that I haven't been able to be with other guys."
    new "就是因为你的这玩意儿，我才能没法和其他人在一起。"

translate chinese chinese_3055699_776:
    old "I still remember how good it felt that one time."
    new "我还记得那次有多爽。"

translate chinese chinese_2375621_777:
    old "Now, let's not delay it anymore, I want it in me right now!"
    new "现在，不要再拖延了，我要你现在就给我！"

translate chinese chinese_4091131_778:
    old "Oh! Oh my god! What am I doing in your room?!"
    new "哦！天啊！我怎么会在这房间里？！"

translate chinese chinese_7968525_779:
    old "Uhh... Well... yesterday you came here."
    new "呃……嗯……昨天你来了这里。"

translate chinese chinese_2966381_780:
    old "You were drunk and..."
    new "你喝醉了，然后..."

translate chinese chinese_7324145_781:
    old "Oh God! That's right! I came in here when I was drunk!"
    new "哦天哪！对了！我是喝醉了才进来的！"

translate chinese chinese_5673412_782:
    old "Listen [pla], I'm sorry, I don't know what happened."
    new "听着 [pla]，我很抱歉，我不知道发生了什么。"

translate chinese chinese_4350935_783:
    old "And I shouldn't be here, last night was just a product of the alcohol and nothing else."
    new "我本不该在这里，昨晚只是酒后的产物，没什么别的。"

translate chinese chinese_1890737_784:
    old "Hey..."
    new "喂……"

translate chinese chinese_3562258_785:
    old "Don't say anything, it's getting very early and somebody could see us."
    new "别说话，天快亮了，有人可能会看到我们。"

translate chinese chinese_0692935_786:
    old "I should just leave, bye."
    new "我还是走吧，再见。"

translate chinese chinese_2758232_787:
    old "Hi... Uhh, h- how are you... feeling?"
    new "喂……呃，你感觉怎么样……？"

translate chinese chinese_4100752_788:
    old "[pla]! H- hi."
    new "[pla]！嗨。"

translate chinese chinese_5242001_789:
    old "Listen [pla] what happened last night made me think a lot about some stuff."
    new "听好了，[pla]，昨晚的事让我想到了很多东西。"

translate chinese chinese_5902717_790:
    old "That was a horrible mistake, and it shouldn't have happened."
    new "那是一个可怕的错误，根本不应该发生。"

translate chinese chinese_3141740_791:
    old "So, I decided we shouldn't see each other or talk again for a while."
    new "所以，我决定我们暂时不要见面也不要联系了。"

translate chinese chinese_6860709_792:
    old "Listen, I know you're shook and confused."
    new "听着，我知道你现在心里没底，也很困惑。"

translate chinese chinese_6574221_793:
    old "But I don't think you should be alone right now."
    new "但是我觉得你现在不应该一个人。"

translate chinese chinese_6610483_794:
    old "This isn't just a rash decision."
    new "这可不是一时冲动的决定。"

translate chinese chinese_9215087_795:
    old "I think I made a mistake with this whole online dating thing."
    new "我觉得我在网上交友这件事上犯错了。"

translate chinese chinese_8287481_796:
    old "I did want to meet and date somebody."
    new "我确实想找个对象见面交往。"

translate chinese chinese_1421034_797:
    old "But it got out of my hands at one point. You saw how much it was affecting me."
    new "但后来失控了。你看得出那对我影响有多大。"

translate chinese chinese_3537102_798:
    old "My sudden mood swings, and odd behavior."
    new "我突然的情绪波动，以及奇怪的行为。"

translate chinese chinese_3223727_799:
    old "I don't want to deal with that anymore."
    new "我不要再处理这些了。"

translate chinese chinese_5272314_800:
    old "No, what I need is time to think and get my bearings together."
    new "不，我需要的是时间来思考和理清头绪。"

translate chinese chinese_9353797_801:
    old "So, I shouldn't have helped you?"
    new "所以，我就不应该帮你吗？"

translate chinese chinese_6608698_802:
    old "That's not what I said. I actually think that your help was good for me, and I'm grateful for it."
    new "那不是我说的。实际上，我觉得你的帮助对我很好，我很感激。"

translate chinese chinese_9552024_803:
    old "It's just that I feel that things have gotten out of hand lately, so we should just relax for a little while. You know?"
    new "就是觉得最近事情有点失控，所以我们应该放松一下。你知道的？"

translate chinese chinese_6376458_804:
    old "I guess that if that is what you want..."
    new "我猜如果你想要的话..."

translate chinese chinese_1933756_805:
    old "It is, it really is."
    new "是的，真的。"

translate chinese chinese_2555265_806:
    old "I see... I understand. If you're ok, then I guess I better leave."
    new "我明白了……如果没事的话，那我最好还是走吧。"

translate chinese chinese_8717696_807:
    old "But if you ever feel like you need to talk, don't hesitate to call me. Ok?"
    new "但是如果你觉得有什么需要倾诉的，随时给我打电话，好吗？"

translate chinese chinese_9577711_808:
    old "I will, thank you."
    new "我会的，谢谢。"

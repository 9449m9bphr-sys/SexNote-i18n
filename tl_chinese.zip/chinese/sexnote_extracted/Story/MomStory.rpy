# auto-tl Qwen Colab

translate chinese chinese_6955404_0:
    old "Hi honey! Your breakfast is ready!"
    new "亲爱的，早安！早餐准备好了！"

translate chinese chinese_8201809_1:
    old "Thank you [mo1rel]."
    new "谢谢你[mo1rel]。"

translate chinese chinese_4465524_2:
    old "[pla], I wanted to talk to you..."
    new "[pla]，我想和你谈谈..."

translate chinese chinese_8098791_3:
    old "I was thinking of a way to improve your relationship with your [mo2rel]."
    new "我在想一个办法来提升你和你的[mo2rel]的关系。"

translate chinese chinese_9606569_4:
    old "Well, I think if you spend some time with her, it could help her get to know you."
    new "嗯，我觉得如果你多花些时间和她在一起，可能会帮她更好地了解你。"

translate chinese chinese_5870645_5:
    old "You know she's pretty stressed. But only because she's not around enough since she's always working."
    new "你知道她压力很大。但这只是因为工作太忙，没时间放松。"

translate chinese chinese_0294630_6:
    old "Just try, please? Could you?... For me?"
    new "就试一次好吗？可以吗……为了我？"

translate chinese chinese_4598145_7:
    old "Uhmm... Fine."
    new "嗯……好吧。"

translate chinese chinese_2403949_8:
    old "Great, It's very simple. She needs some help for her job. She's thought about hiring an assistant..."
    new "好的，很简单。她工作上需要一些帮助。她考虑过雇一个助理……"

translate chinese chinese_8206330_9:
    old "So, I asked her to let you work for her. And of course she will reward you for all your help."
    new "所以，我让她让你为她工作。当然了，她会奖励你所有帮助的。"

translate chinese chinese_0381846_10:
    old "Alright, alright. I'll help her then..."
    new "好吧好吧，那我就帮她一下……"

translate chinese chinese_4073478_11:
    old "Do you have the receipt of-"
    new "你有收据吗？"

translate chinese chinese_8189877_12:
    old "Oh, there you are..."
    new "哦，你在那儿啊……"

translate chinese chinese_1168854_13:
    old "Good morning, [mo2]. How are you today so far?"
    new "早上好，[mo2]。今天过得怎么样？"

translate chinese chinese_9692795_14:
    old "Busy... Did you talk with him. Huh?"
    new "忙……你和他谈了吗？嗯？"

translate chinese chinese_5479336_15:
    old "Yes, I just did. And you have nothing to worry about."
    new "是的，我刚做了。而且你不用担心。"

translate chinese chinese_3436991_16:
    old "... He's still a pervert."
    new "...他还是个色狼。"

translate chinese chinese_4188623_17:
    old "I'm not a-"
    new "我不是a-"

translate chinese chinese_6846505_18:
    old "He is just a teenager. No need to be rude. Everything is okay."
    new "他只是个 teenager。不用这么粗鲁。一切都没事。"

translate chinese chinese_5744383_19:
    old "Hmm... If you say so..."
    new "嗯……如果你这么说的话……"

translate chinese chinese_3414215_20:
    old "I will be doing some calls, [pla]. Look for me when you are ready."
    new "我这边要打电话，[pla]。准备好就来找我。"

translate chinese chinese_8695913_21:
    old "Ok. (Geez)"
    new "好吧。（真是的）"

translate chinese chinese_3063206_22:
    old "Anyway, did you want to talk about something?"
    new "话说，你有什么想说的吗？"

translate chinese chinese_7280024_23:
    old "(W- what is she doing?)"
    new "（她这是在干什么？）"

translate chinese chinese_7777631_24:
    old "Ohh, sorry I'm trying to apply some sunscreen on my butt, hehehe."
    new "哦，对不起，我正在给我屁股涂防晒霜，嘿嘿嘿。"

translate chinese chinese_4312400_25:
    old "Hi honey, are you coming to hang out in the pool?"
    new "亲爱的，你过来游泳池玩吗？"

translate chinese chinese_5029828_26:
    old "No, I don't want to swim today."
    new "不，我今天不想游泳。"

translate chinese chinese_6326724_27:
    old "Really? It's a shame on this beautiful day."
    new "真的吗？这么美好的日子真是可惜了。"

translate chinese chinese_4114092_28:
    old "Why don't you help me then to apply some sunscreen on my back?"
    new "那你为什么不帮我涂点防晒霜在背上呢？"

translate chinese chinese_1958174_29:
    old "Oh, okay."
    new "哦，好的。"

translate chinese chinese_0108315_30:
    old "Thanks sweetheart."
    new "谢谢你，甜心。"

translate chinese chinese_3372171_31:
    old "I'm sorry I have some things to do."
    new "对不起，我有些事情要处理。"

translate chinese chinese_9947619_32:
    old "Oh, don't worry honey, go and do what you have to do."
    new "哦，别担心宝贝，去处理你的事情吧。"

translate chinese chinese_0343921_33:
    old "Ok. See you later."
    new "好的，回头见。"

translate chinese chinese_2014125_34:
    old "Be sure to cover the entire back."
    new "一定要把整个背部都擦到。"

translate chinese chinese_7618578_35:
    old "I will, don't worry."
    new "我会的，别担心。"

translate chinese chinese_0093195_36:
    old "I think that's it with your back, would you need anything else?"
    new "我觉得你的背部就到这里了，还需要别的吗？"

translate chinese chinese_2829652_37:
    old "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} In fact, I would really appreciate it if you help me with some foot massages."
    new "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} 其实，如果你能帮我按摩一下脚，我会非常感激的。"

translate chinese chinese_7091127_38:
    old "Okay, no problem."
    new "好的，没问题。"

translate chinese chinese_8599841_39:
    old "Hmm, there still some areas that I think might need some Sunscreen."
    new "嗯，我还是觉得有些地方可能需要涂点防晒霜。"

translate chinese chinese_4052050_40:
    old "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} Really? Then please apply more on me, I don't want to get sunburned"
    new "{color=#00b8e7}{b}(-AFFECTION ACCOMPLISHED-){/b}{/color} 真的吗？那请多涂一点，我不想被晒伤"

translate chinese chinese_9642006_41:
    old "(Should I try to go further?)"
    new "（我该试着进一步吗？）"

translate chinese chinese_9674214_42:
    old "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} (I think is a good moment to try the Sauron's Mouth.)"
    new "{color=#00b8e7}{b}(萨鲁曼的口技成功了){/b}{/color} (我觉得现在是试试萨鲁曼的口技的好时机。)"

translate chinese chinese_6674015_43:
    old "{b}Sauron's mouth:{/b} [mo1rel], I'll give you a foot massage again, you just stay calm."
    new "{b}索伦的嘴：{/b} [mo1rel]，我再给你捏脚，你就乖乖的。"

translate chinese chinese_3476064_44:
    old "(I think it works... Let's see.)"
    new "（我觉得有效……看看吧。）"

translate chinese chinese_9134500_45:
    old "Well it's done. I think you are perfect now."
    new "好了，完成了。我觉得你现在完美了。"

translate chinese chinese_4577668_46:
    old "{color=#d74627}{b}(-INSUFFICIENT AFFECTION-){/b}{/color} Oh, no, honey, I think it's enough, thanks for your help."
    new "哦，不，亲爱的，我觉得够了，谢谢你帮忙。"

translate chinese chinese_3781840_47:
    old "Ok... (Maybe next time.)"
    new "好吧...（也许下次吧。）"

translate chinese chinese_1719821_48:
    old "Hey, [pla], I wanted to ask if you could come with me to the doctor's office."
    new "嘿，[pla]，我想问一下你能不能陪我去趟诊所。"

translate chinese chinese_0818195_49:
    old "What! Why? Did something happen to you? Are you sick?"
    new "什么！为什么？你出什么事了吗？生病了吗？"

translate chinese chinese_1965133_50:
    old "No, no, it's nothing bad. It's just a routine check up."
    new "不不，没什么坏事，只是例行检查。"

translate chinese chinese_5937588_51:
    old "Oh, ok. Sure no problem"
    new "哦，好的，没问题。"

translate chinese chinese_3297766_52:
    old "Perfect! Wait for me while I get changed, okay?"
    new "完美！你等我一下，我换身衣服好吗？"

translate chinese chinese_1752977_53:
    old "Thank you, baby."
    new "谢谢你，宝贝。"

translate chinese chinese_9955664_54:
    old "I'm ready! How do I look?"
    new "我准备好了！我看起来怎么样？"

translate chinese chinese_4676191_55:
    old "You look... (So hot) V- Very nice [mo1rel]."
    new "你看起来... (真热辣) 嗯, 非常不错 [mo1rel]。"

translate chinese chinese_4230126_56:
    old "Aww, thanks, honey... Ok, let's head to the doctor's office."
    new "哎呀，谢谢亲爱的……好吧，我们去医院吧。"

translate chinese chinese_8417837_57:
    old "Ok, we're here. What's the appointment about, [mo1rel]?"
    new "好了，我们到了。这次预约是关于什么的，[mo1rel]？"

translate chinese chinese_5111100_58:
    old "Oh... It's called a mammogram. It's to make sure there's no problem with my boobies. Hehe."
    new "哦……这叫乳腺检查。是为了确保我的胸部没有问题啦。嘿嘿。"

translate chinese chinese_1592521_59:
    old "Oh... ok, I understand... And what should we do?"
    new "哦……好的，我明白了……那我们应该怎么办？"

translate chinese chinese_9064245_60:
    old "Well, it's time for the appointment! So we should go to nurse Mary's office right now."
    new "好吧，该去医院了！所以我们现在应该去玛丽护士的办公室。"

translate chinese chinese_7567707_61:
    old "Ok, Come on..."
    new "好啦，快来..."

translate chinese chinese_8372836_62:
    old "Good morning..."
    new "早上好……"

translate chinese chinese_0133050_63:
    old "Hello, How have you been? Long-time, no see."
    new "你好，最近怎么样？好久不见。"

translate chinese chinese_9884833_64:
    old "Ohh, and who is this handsome young man? Are you trying out young meat? "
    new "哦呵，这位帅气的年轻人是谁呀？你在尝试新鲜的小伙子吗？"

translate chinese chinese_7806480_65:
    old "Oh Mary. Haha. Don't be silly, I'm his [mo1rel], he's just joining me for my appointment."
    new "哦，玛丽。哈哈。别傻了，我是他的[iVar000/]，他只是来陪我赴约而已。"

translate chinese chinese_1342398_66:
    old "Oh, I see. Right... talking about the test... I have some bad news... The technical machine to do the mammogram is broken at the moment."
    new "哦，我明白了。对了……说到考试……我有个坏消息……做乳腺摄影的技术设备现在坏了。"

translate chinese chinese_7842266_67:
    old "So we will have to do it in the old fashioned way... So I get to give you a good massage on those babies ..."
    new "所以我们得用老办法了……所以我可以好好给你按摩一下那些小东西……"

translate chinese chinese_4148386_68:
    old "Hehehe. It's fine Mary, as you wish..."
    new "嘿嘿嘿。没关系玛丽，如你所愿..."

translate chinese chinese_7385657_69:
    old "Well now, Sue, take off your clothes..."
    new "好吧，苏，把衣服脱了..."

translate chinese chinese_5700095_70:
    old "... (Oh crap)"
    new "... （糟糕）"

translate chinese chinese_8256053_71:
    old "Ehh ... Well ... I'll just head on out, to give you guys some privacy."
    new "呃……那我先出去，给你们留点私人空间。"

translate chinese chinese_4850966_72:
    old "Hey! Wait there. What a shy one you have here. Don't worry, sugar. This is nothing you haven't seen before."
    new "喂！等一下。你这家伙真害羞。别担心，甜心。这没什么好怕的，你以前肯定见过。"

translate chinese chinese_8333814_73:
    old "Besides, she won't get naked. Haha. Don't worry. This is very professional."
    new "再说，她不会脱衣服的。哈哈，别担心，这很专业的。"

translate chinese chinese_0714829_74:
    old "Oh. Ok, then..."
    new "哦，好的，那……"

translate chinese chinese_9451645_75:
    old "Let's see those babies!... I'm going to massage them gently. Tell me, how does it feel?"
    new "让我看看那些宝贝……我要轻轻地按摩它们。告诉我，感觉怎么样？"

translate chinese chinese_9892802_76:
    old "Wow, I didn't remember them being so big... Lucky you!"
    new "哇，没想到它们这么大……你真幸运！"

translate chinese chinese_1107280_77:
    old "... (This is...)"
    new "...（这是...）"

translate chinese chinese_6299703_78:
    old "Do you feel any pain?"
    new "你感觉疼吗？"

translate chinese chinese_5421590_79:
    old "No, not at all. In fact, it feels very... good..."
    new "不，根本不是。事实上，感觉很...好..."

translate chinese chinese_0320182_80:
    old "Hmm... Honestly, I haven't done this manually for a long time. I can't feel anything... I'm going to do it a little harder, ok?"
    new "嗯……说实话，我很久没有手动做了。没什么感觉……我要稍微用力一点，好吗？"

translate chinese chinese_9673227_81:
    old "Well, that's it for now..."
    new "好吧，就说到这吧..."

translate chinese chinese_7594937_82:
    old "I still couldn't feel anything..."
    new "我还是没有任何感觉……"

translate chinese chinese_8098677_83:
    old "So, I would like you to come again. We can do the test again and be more thorough. How does Monday sound?"
    new "所以，我想让你再来一次。我们可以再做一次测试，更仔细一点。周一怎么样？"

translate chinese chinese_1204839_84:
    old "Monday is perfect."
    new "周一perfect。"

translate chinese chinese_8827594_85:
    old "Ok, then Thursday, we will try again. It was really nice to see you again!"
    new "好的，那就在星期四再试一次吧。真高兴又见到你！"

translate chinese chinese_3342963_86:
    old "Likewise, Mary."
    new "同样，玛丽。"

translate chinese chinese_7138218_87:
    old "See you later, young man..."
    new "再见了，小伙子..."

translate chinese chinese_7302684_88:
    old "...See you later..."
    new "...回头见..."

translate chinese chinese_4241408_89:
    old "Hi, honey! Do you want to join me?"
    new "亲爱的，你想加入我吗？"

translate chinese chinese_9639845_90:
    old "I am sorry, [mo1rel]. I'm a little tired. I'm gonna go to sleep."
    new "对不起，[mo1rel]。我有点累了，打算去睡觉了。"

translate chinese chinese_6934732_91:
    old "Don't worry, honey. Go to sleep. I will watch a movie then head out myself."
    new "别担心，亲爱的。去睡觉吧。我看完电影就出去。"

translate chinese chinese_6973445_92:
    old "Ok. Good night."
    new "好的，晚安。"

translate chinese chinese_9277585_93:
    old "Sweet dreams, dear."
    new "好梦，亲爱的。"

translate chinese chinese_7264591_94:
    old "Sure"
    new "行吧"

translate chinese chinese_4995733_95:
    old "Are you sure, I think you drank a lot and should rest..."
    new "你确定吗？我觉得你喝了不少，应该休息一下……"

translate chinese chinese_6388299_96:
    old "Awww, don't worry honey... I'm fine, I just want to relax a little..."
    new "哎呀，别担心宝贝……我没事，我只是想放松一下……"

translate chinese chinese_0125237_97:
    old "I also like your company and your big-"
    new "我也喜欢你的陪伴和你的大"

translate chinese chinese_9531927_98:
    old "Your big... Heart is what I meant. Oh, come on, don't leave me alone, I want some company, please?"
    new "你的大……心胸就是我说的。哦，别这样，不要丢下我一个人，我想有人陪，求求你了？"

translate chinese chinese_6328731_99:
    old "Great, you are the best!"
    new "太好了，你是最棒的！"

translate chinese chinese_5457273_100:
    old "But this time I choose the movie"
    new "但这次我来选电影"

translate chinese chinese_5868506_101:
    old "Great, honey! What movie would you like to watch?"
    new "太好了，宝贝！你想看什么电影？"

translate chinese chinese_3513969_102:
    old "Romance"
    new "浪漫"

translate chinese chinese_2564766_103:
    old "Ohh, I love these kind of movies!"
    new "哦，我超爱这种电影的！"

translate chinese chinese_3248079_104:
    old "Great, let's enjoy it!"
    new "好啊，让我们享受一下吧！"

translate chinese chinese_2472545_105:
    old "Action"
    new "行动"

translate chinese chinese_5286666_106:
    old "This is your favorite type of movie, isn't it?"
    new "这可是你最喜欢的电影类型吧？"

translate chinese chinese_7313041_107:
    old "Yup, but if you want, we can watch something else..."
    new "没错，但如果你想，我们可以看别的东西..."

translate chinese chinese_9974371_108:
    old "Ohh no, don't worry honey. I'm happy to spend time with you."
    new "哦不，别担心亲爱的。我很乐意花时间陪你。"

translate chinese chinese_0371690_109:
    old "Horror"
    new "恐怖"

translate chinese chinese_2004181_110:
    old "Are you sure? I don't want you to have any nightmares."
    new "你确定吗？我不想让你做噩梦。"

translate chinese chinese_8131915_111:
    old "Hahaha. I can handle it, [mo1rel]."
    new "哈哈。我应付得来，[mo1rel]。"

translate chinese chinese_8100259_112:
    old "Wait... Before we start, let me get a glass of wine. I want to relax a little and enjoy the movie."
    new "等一下……在开始之前，让我先拿一杯酒。我想放松一下，好好享受这部电影。"

translate chinese chinese_6878504_113:
    old "Ok. No problem. (Hmm.)"
    new "好的，没问题。（嗯。）"

translate chinese chinese_5978786_114:
    old "Thanks, honey!"
    new "谢谢，亲爱的！"

translate chinese chinese_4385599_115:
    old "Perfect! A movie night and a good glass of wine. What a great combination. Do you want a bit of wine, too, sugar?"
    new "完美！电影之夜再配上一杯好酒，真是绝配。你也来点酒吗，甜心？"

translate chinese chinese_0976358_116:
    old "I'm fine for now."
    new "我暂时没事。"

translate chinese chinese_3578801_117:
    old "Ok, honey. Let's start the movie"
    new "好啦，宝贝。我们开始看电影吧"

translate chinese chinese_5454462_118:
    old "Wow, this movie is great, isn't it, honey?"
    new "哇，这部电影真不错，亲爱的，你觉得呢？"

translate chinese chinese_1855821_119:
    old "Yeah, is pretty awesome-"
    new "是啊，真的很棒-"

translate chinese chinese_7738077_120:
    old "Hmm, it looks like you are ready for the best moment of movie night..."
    new "嗯，看来你已经准备好享受电影之夜的最佳时刻了……"

translate chinese chinese_4797821_121:
    old "... W- what do you mean..."
    new "...你什么意思..."

translate chinese chinese_1525882_122:
    old "What I mean is... Take that big buddy of yours out..."
    new "我的意思是……把你那个大朋友拿出来……"

translate chinese chinese_8206162_123:
    old "Mmm, nice!... What do you want today, baby?"
    new "嗯，不错……今天想干什么，宝贝？"

translate chinese chinese_6347953_124:
    old "Good choice! Let [mo1rel] handle this beast."
    new "好选择！让[mo1rel]来对付这只野兽吧。"

translate chinese chinese_2945103_125:
    old "You really like this, huh?..."
    new "你真的好喜欢这个啊？..."

translate chinese chinese_9246348_126:
    old "You read my mind..."
    new "你真是猜透了我的心思……"

translate chinese chinese_0085731_127:
    old "Hmmm, honey? This movie is exciting you that much?"
    new "嗯哼，宝贝？这部电影让你这么兴奋？"

translate chinese chinese_9185855_128:
    old "I'm sorry, [mo1rel]. I can't handle it. I honestly didn't mean to..."
    new "对不起，[mo1rel]。我应付不来。我真的不是故意要……"

translate chinese chinese_1637987_129:
    old "It's ok. Don't you worry. Let me give you a hand with that. I don't want you to be like this the whole movie."
    new "没事的，别担心。让我来帮你处理这个。我不想你整个过程都这样。"

translate chinese chinese_9331186_130:
    old "Hmm, honey? Are you getting hard again?"
    new "嗯，亲爱的？你又硬起来了？"

translate chinese chinese_8412667_131:
    old "Sorry [mo1rel], I didn't mean to..."
    new "对不起[mo1rel]，我不是故意要..."

translate chinese chinese_7287486_132:
    old "It's ok. actually I wanted to try something a bit different this time..."
    new "没关系，其实这次我想尝试些不同的东西……"

translate chinese chinese_0939972_133:
    old "Don't worry honey, you are going to love it."
    new "别担心亲爱的，你会爱上它的。"

translate chinese chinese_2239987_134:
    old "The movie was great!"
    new "这部电影太棒了！"

translate chinese chinese_3479878_135:
    old "Yeah, I didn't expect that ending at all..."
    new "是啊，我完全没想到会是这样的结局..."

translate chinese chinese_5652735_136:
    old "Thanks for spending time with me, [pla]."
    new "谢谢陪我度过这段时间，[pla]。"

translate chinese chinese_4952949_137:
    old "You don't have to thank me, [mo1rel]. I enjoy your company!"
    new "你不用谢我，[mo1rel]。我喜欢和你在一起！"

translate chinese chinese_1892342_138:
    old "Aww, that makes me happy. If you want to watch another movie, come to see me tomorrow night."
    new "哎呀，这让我很开心。如果你想再看一部电影，明天晚上来找我吧。"

translate chinese chinese_0871901_139:
    old "I know we will have a good time together."
    new "我知道我们会一起玩得很开心的。"

translate chinese chinese_0230979_140:
    old "You can count on it!"
    new "你放心吧！"

translate chinese chinese_5998737_141:
    old "Ok, dear. Let's go to sleep."
    new "好啦，亲爱的，我们去睡觉吧。"

translate chinese chinese_5038870_142:
    old "Alright, [mo1rel]. Good night."
    new "好了，[mo1rel]。晚安。"

translate chinese chinese_4477401_143:
    old "Sweet dreams, honey..."
    new "好梦，宝贝..."

translate chinese chinese_6574092_144:
    old "[pla]... I- I'm so sorry... I don't know what came over me... I'm your [mo1rel]! I shouldn't have... It must have been all the wine I drank..."
    new "[pla]... 对不起... 我也不知道怎么了... 我是你的[mo1rel]！我不应该... 可能是因为喝了太多酒..."

translate chinese chinese_2519264_145:
    old "Uhh, there's nothing wrong with that, you're just helping me... Also, I really enjoyed it a lot..."
    new "呃，这没什么不对的，你只是在帮我……而且我真的很享受……"

translate chinese chinese_8076433_146:
    old "Do you really think that?  "
    new "你真的这么认为吗？"

translate chinese chinese_2972455_147:
    old "Well... I haven't done that for years and I was trying to make you feel better. So, yeah, maybe there's nothing wrong with that."
    new "嗯……我好几年没那样做了，当时也是想让你感觉好一点。所以，也许那样做也没错。"

translate chinese chinese_8720888_148:
    old "Yeah, also, you're taking care of me so I can release all my repression. and I really appreciate it."
    new "是的，而且，你照顾我，让我释放所有的压抑，我真的很感激。"

translate chinese chinese_0680638_149:
    old "Awww, of course, honey. You always make me feel better... Now let's clean this up... And remember, don't to tell anyone."
    new "哎呀，当然了，亲爱的。你总是让我感觉好些……现在让我们清理一下……记住，不要告诉任何人。"

translate chinese chinese_9332310_150:
    old "Don't worry, I won't."
    new "放心，我不会的。"

translate chinese chinese_1045630_151:
    old "That's a good boy. Let's go to bed."
    new "真是个好孩子。我们去睡觉吧。"

translate chinese chinese_2997460_152:
    old "Ok, [mo1rel]. Good night."
    new "好的，[mo1rel]。晚安。"

translate chinese chinese_8491684_153:
    old "Good night, honey. Sleep well."
    new "晚安，亲爱的。睡个好觉。"

translate chinese chinese_8342125_154:
    old "That movie was great!"
    new "那部电影真棒！"

translate chinese chinese_7098671_155:
    old "Yeah, it was fun..."
    new "是啊，挺好玩的……"

translate chinese chinese_4352119_156:
    old "You know what? We could continue this upstairs."
    new "你知道吗？我们可以去楼上继续。"

translate chinese chinese_0520757_157:
    old "Hell yeah"
    new "妈的没错"

translate chinese chinese_2471719_158:
    old "Oh really?, Well what are we waiting for?"
    new "哦真的吗？那我们还等什么？"

translate chinese chinese_3836617_159:
    old "That's what I thought."
    new "我就知道是这样。"

translate chinese chinese_3197148_160:
    old "Not tonight"
    new "今晚不行"

translate chinese chinese_8327569_161:
    old "Ok honey, anyway if you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "好吧亲，反正如果你还想看电影，明天来找我吧。我知道我们会玩得很开心的..."

translate chinese chinese_0956021_162:
    old "Ok, honey. Let's go to sleep."
    new "好啦，宝贝。我们去睡觉吧。"

translate chinese chinese_9976626_163:
    old "Sweet dreams, honey. Sleep well."
    new "好梦，宝贝。睡个好觉。"

translate chinese chinese_2273178_164:
    old "Thanks for spending time with me, baby."
    new "谢谢你陪我度过这段时光，宝贝。"

translate chinese chinese_5223465_165:
    old "You don't have to thank me [mo1rel]. I really enjoy it!"
    new "你不用谢我[mo1rel]，我真的觉得很享受！"

translate chinese chinese_9427947_166:
    old "I'm glad to hear that. If you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "听到这个我很高兴。如果你想再看一部电影，明天来找我吧。我知道我们会一起玩得很开心的……"

translate chinese chinese_2576221_167:
    old "Looks like someone is really happy for the movie..."
    new "看来有人对这部电影真的很开心……"

translate chinese chinese_1113466_168:
    old "You know what? I want to have sex here..."
    new "你知道吗？我想要在这里做爱……"

translate chinese chinese_6733468_169:
    old "... Are you sure?"
    new "……你确定吗？"

translate chinese chinese_8238403_170:
    old "What is the difference, we already had sex..."
    new "有什么区别，我们已经发生过性关系了……"

translate chinese chinese_7600838_171:
    old "Good morning [pla]."
    new "早上好 [pla]。"

translate chinese chinese_0477044_172:
    old "Good morning [mo1rel]."
    new "早上好[mo1rel]。"

translate chinese chinese_3671720_173:
    old "I wanted to talk to you about yesterday ..."
    new "我想和你谈谈昨天的事……"

translate chinese chinese_3497685_174:
    old "I- I'm really sorry... It wasn't-"
    new "我真的很抱歉……那不是——"

translate chinese chinese_2992429_175:
    old "No, I want to apologize for the way I treated you ..."
    new "不，我想为我对待你的态度道歉……"

translate chinese chinese_3767969_176:
    old "You want to... Apologize?"
    new "你想... 道歉？"

translate chinese chinese_7690607_177:
    old "Yes, I think I was very rude with you, but please understand, it was a bit shocking for me..."
    new "是的，我觉得我对你很粗鲁，但请理解，这对我来说有点震惊……"

translate chinese chinese_0958812_178:
    old "I mean, I don't want you to think that I judge you, I know you're going through a lot."
    new "我的意思是，我不想让你觉得我在评判你，我知道你经历了很多。"

translate chinese chinese_2165257_179:
    old "And I know this is hard for you, so I want you to know that I'm not mad at you."
    new "我知道这对你来说很难，所以我想让你知道我不会生你的气。"

translate chinese chinese_5274994_180:
    old "Yes, In fact I think it was some kind of my fault..."
    new "是的，事实上我觉得可能是我的错..."

translate chinese chinese_7628267_181:
    old "Your fault? W- what do you mean?"
    new "是你不对？你什么意思？"

translate chinese chinese_8004362_182:
    old "I think I should have helped you more."
    new "我觉得我应该多帮你一点。"

translate chinese chinese_9307275_183:
    old "I mean, [mo2] is a bit strict, she didn't want me to talk to you about, you know... Sexual things."
    new "我的意思是，[mo2]有点严格，她不想让我和你谈论，你知道的……性方面的事情。"

translate chinese chinese_4653989_184:
    old "And now you're a bit repressed, that's why your hormones are making you lose your mind."
    new "而现在你有点压抑，所以荷尔蒙让你变得失控。"

translate chinese chinese_3444574_185:
    old "And do things that... You shouldn't do."
    new "做一些你不应该做的事情。"

translate chinese chinese_0283260_186:
    old "I- it was not my intention."
    new "我——我不是故意的。"

translate chinese chinese_1308499_187:
    old "I know honey... I know this can be difficult for you, but if you can't control yourself in front of your [mo1rel]... It really worries me."
    new "我知道亲爱的……我知道这对你来说很难，但如果你在你的[mo1rel]面前控制不住自己……我真的挺担心的。"

translate chinese chinese_7542537_188:
    old "I won't do it again, I promise."
    new "我不会再这样了，我保证。"

translate chinese chinese_7272562_189:
    old "Actually, what worries me is that you get to do it at school or in front of any other girl."
    new "实际上，我担心的是你会在学校或者别的女生面前做这些。"

translate chinese chinese_3787272_190:
    old "W- what? I- I won't-"
    new "什、什么？我、我不会——"

translate chinese chinese_2603247_191:
    old "It's not under your control, you already show me that."
    new "这不在你的控制范围内，你已经展示给我看了。"

translate chinese chinese_4831638_192:
    old "I- I'm sorry-"
    new "我- 对不起-"

translate chinese chinese_7556194_193:
    old "And it's my fault. I should have helped you before, now you are facing troubles because of my irresponsibility."
    new "而且这是我的错。我本应该早点帮你，现在你遇到麻烦都是因为我不负责任。"

translate chinese chinese_7950373_194:
    old "And I have been thinking about it a lot and... I think I have to help you to... Release your, uhm... S- stress."
    new "我一直在想这件事，而且……我觉得我得帮你……释放你的，嗯……压力。"

translate chinese chinese_9699442_195:
    old "Uhh, w- what do you mean?"
    new "呃，你什么意思？"

translate chinese chinese_7381232_196:
    old "Hmm you know honey... I'll help you with your... Ahem, load release."
    new "嗯，亲爱的……我会帮你……咳，释放压力的。"

translate chinese chinese_8431768_197:
    old "No, [mo1rel], don't worry I can do it by myself..."
    new "不，[mo1rel]，别担心，我自己能行..."

translate chinese chinese_5642475_198:
    old "Sorry honey, but apparently you haven't done very well so far."
    new "宝贝，看来你做得还不够好。"

translate chinese chinese_8470709_199:
    old "I know it won't be comfortable for any of us, but I need to make sure you get it right."
    new "我知道这对我们任何人都不会舒服，但我需要确保你搞对了。"

translate chinese chinese_5080596_200:
    old "I don't want you to keep repressing yourself and that it leads you to do worse things."
    new "我不希望你一直压抑自己，结果做出更糟糕的事情。"

translate chinese chinese_7117837_201:
    old "Are you right this is the only way?"
    new "你确定这真的是唯一的方法吗？"

translate chinese chinese_3950733_202:
    old "Well, the thing is, I don't want [mo2] to realize it, that would really make things more difficult."
    new "好吧，问题是，我不希望[mo2]意识到这一点，那样会更麻烦的。"

translate chinese chinese_1374558_203:
    old "So the best way is to do it here alone and keep everything between you and me."
    new "所以最好的办法是独自在这里做，一切就当是我们俩之间的秘密。"

translate chinese chinese_8710325_204:
    old "Please [pla] don't make it more difficult than it already is."
    new "请[pla]不要让事情变得更复杂。"

translate chinese chinese_2051547_205:
    old "I will help you with a handjo-... Hmm with a massage, to help you relax and release your... Load and that's it."
    new "我帮你做个手...嗯，做个按摩，帮你放松一下，释放你的...负担，就这样。"

translate chinese chinese_2193637_206:
    old "Just think of it as some kind of sex ed class."
    new "就当是性教育课吧。"

translate chinese chinese_6569103_207:
    old "Sex ed class... Uhmm, alright."
    new "性教育课……嗯，好吧。"

translate chinese chinese_2454814_208:
    old "Thanks honey."
    new "谢谢亲爱的。"

translate chinese chinese_2369307_209:
    old "Alright, come and sit on the bed and leave it all to me."
    new "好了，过来坐在床上，剩下的交给我。"

translate chinese chinese_3327391_210:
    old "What the fuck is going on???"
    new "到底发生了什么???"

translate chinese chinese_3049386_211:
    old "What were those yells?? It's coming from the house's entrance."
    new "那些喊声是什么？是从房子入口传来的。"

translate chinese chinese_4838567_212:
    old "I better go check it out."
    new "我最好去看看。"

translate chinese chinese_9239606_213:
    old "I'm tired of this, I'm the only one who works in this house..."
    new "我受够了，这家里只有我在干活……"

translate chinese chinese_0956275_214:
    old "But honey..."
    new "但是亲爱的..."

translate chinese chinese_4565558_215:
    old "It makes no sense to keep providing for three good for nothing bums!"
    new "继续养这三个废物根本没道理！"

translate chinese chinese_9337068_216:
    old "But we are a family."
    new "但我们是一家人啊。"

translate chinese chinese_3044602_217:
    old "No, you are leeches who want to live at my expense."
    new "不，你们是寄生虫，想靠我活着。"

translate chinese chinese_1903994_218:
    old "Besides, now your drinking wine every night and getting drunk. Don't you feel ashamed?!"
    new "再说，你现在每天晚上喝酒喝醉。你不觉得羞耻吗？!"

translate chinese chinese_9187076_219:
    old "I'm not getting drunk..."
    new "我没醉..."

translate chinese chinese_9198952_220:
    old "You know what, I'm going to the office ... There is no point in continuing to argue"
    new "你知道吗，我要去办公室了……继续争论也没意义"

translate chinese chinese_0310208_221:
    old "Hi [mo1rel], what happened?"
    new "喂，[mo1rel]，发生什么事了？"

translate chinese chinese_4551403_222:
    old "Hi honey, don't worry... Just a little discussion."
    new "亲爱的，别担心……只是小小的讨论一下。"

translate chinese chinese_1123030_223:
    old "Oh yes, I'm fine, don't worry, I'll be in my room, ok?"
    new "哦，我没事，别担心，我在房间里待着，好吗？"

translate chinese chinese_6456275_224:
    old "Oh, come on, are they arguing again?"
    new "哦，他们又在吵架吗？"

translate chinese chinese_9213177_225:
    old "I better go and make sure what's happening now."
    new "我还是去看看现在发生了什么吧。"

translate chinese chinese_6448522_226:
    old "Seriously, were you drinking yesterday again?"
    new "seriously, 你昨天又喝酒了？"

translate chinese chinese_3346787_227:
    old "I'm sorry, but I was feeling bad..."
    new "对不起，我那时候心情不好……"

translate chinese chinese_3000336_228:
    old "You are a sick alcoholic."
    new "你真是个病态的酒鬼。"

translate chinese chinese_3773590_229:
    old "NO!"
    new "不！"

translate chinese chinese_3097499_230:
    old "I'm not an alcoholic and I'm tired of your offenses and your aggressiveness!"
    new "我不是酒鬼，你的侮辱和咄咄逼人让我很厌烦！"

translate chinese chinese_2164220_231:
    old "Well, I'm tired of living with good for nothings..."
    new "好吧，我受够了和这些没用的人生活在一起……"

translate chinese chinese_4954638_232:
    old "Actually, I'm leaving this house, I'm not going to keep paying everything for all of you anymore."
    new "实际上，我要离开这栋房子了，我不再为你们所有人付账单了。"

translate chinese chinese_9885410_233:
    old "Uhmm, [mo1rel] are you alright?"
    new "嗯，[mo1rel]，你还好吗？"

translate chinese chinese_4766041_234:
    old "No, not really."
    new "不，不是真的。"

translate chinese chinese_5117489_235:
    old "I'm so sorry [mo1rel]"
    new "我真的很抱歉 [mo1rel]"

translate chinese chinese_0717976_236:
    old "Don't worry, I think it's for the best anyway."
    new "别担心，我觉得这样最好。"

translate chinese chinese_5095314_237:
    old "I didn't know you were having these problems."
    new "我不知道你有这些问题。"

translate chinese chinese_8477680_238:
    old "Always, from the beginning of the relationship, we are very different and as much as we try..."
    new "一直以來，從關係開始的時候，我们就很不同，儘管我們努力了……"

translate chinese chinese_5132043_239:
    old "I think we are simply not compatible."
    new "我觉得我们就是不合适。"

translate chinese chinese_3816884_240:
    old "Do you need anything?"
    new "你需要什么吗？"

translate chinese chinese_4090159_241:
    old "No, thanks, I just want to be alone."
    new "不了，谢谢，我只是想一个人待着。"

translate chinese chinese_4884145_242:
    old "I wanted to ask you again about your doctor's appointment..."
    new "我想再问问你关于你的医生预约的事……"

translate chinese chinese_7887217_243:
    old "Oh, I had forgotten, can you go with me?"
    new "哦，我都忘了，你能陪我一起去吗？"

translate chinese chinese_8154435_244:
    old "Yes, that's why I was looking for you..."
    new "是的，那就是为什么我在找你..."

translate chinese chinese_9882297_245:
    old "Perfect! Wait for me at the entrance while I get changed and come out, okay?"
    new "完美！你在入口等我，我去换衣服出来，好吗？"

translate chinese chinese_7117027_246:
    old "Ok, I'll wait for you then..."
    new "好吧，那我就等你了……"

translate chinese chinese_0437123_247:
    old "Ok, I'm ready. Let's go to the hospital..."
    new "好的，我准备好了。我们去医院吧..."

translate chinese chinese_3789909_248:
    old "Hi, sweetie! What are you up to?"
    new "嗨，甜心！你在干什么呢？"

translate chinese chinese_9936398_249:
    old "Hey, [mo1rel]. I'm good."
    new "嘿，[mo1rel]。我挺好的。"

translate chinese chinese_6584629_250:
    old "Did you want to talk about something?"
    new "你想谈些什么吗？"

translate chinese chinese_6392753_251:
    old "As you know, I'm preparing a speech for class."
    new "你知道的，我正在准备课堂演讲。"

translate chinese chinese_8782776_252:
    old "Yes! I'm proud of you for studying so hard, dear!"
    new "太好了！我为你这么用功学习感到骄傲，亲爱的！"

translate chinese chinese_4448343_253:
    old "Yeah… Well, I don't want to bother anyone, so I will be studying in the garage instead of my room."
    new "嗯……我不想打扰任何人，所以我会在车库而不是房间里学习。"

translate chinese chinese_1331836_254:
    old "Aww, that's very considerate of you. Thank you."
    new "哎呀，你真体贴。谢谢。"

translate chinese chinese_6895019_255:
    old "So, I will be heading to the garage to study now."
    new "所以，我现在要去车库学习了。"

translate chinese chinese_9325792_256:
    old "Ok, sweetie. Do you want to talk about anything else?"
    new "好啦，甜心。你还想聊些什么吗？"

translate chinese chinese_8314364_257:
    old "Yes, I wanted to ask you again about doctor's appointment..."
    new "是的，我想再问一下关于医生预约的事……"

translate chinese chinese_2164095_258:
    old "Sure, honey. The appointment is next Thursday... Only look for me in the morning to go to the hospital, okay?"
    new "好的，亲爱的。预约是下个星期四……只有早上来找我一起去医院，好吗？"

translate chinese chinese_6489707_259:
    old "Oh, right. Then I'll look for you then."
    new "哦，对了。到时候我就来找你。"

translate chinese chinese_5408402_260:
    old "Okay, sweetie, do you want to talk about anything else?"
    new "好啦，宝贝，你还想聊些什么吗？"

translate chinese chinese_9529279_261:
    old "Sure, honey. The appointment is next Monday... Only look for me in the morning to go to the hospital, okay?"
    new "好的，亲爱的。预约是下周一……只有早上来找我一起去医院，好吗？"

translate chinese chinese_8212310_262:
    old "Yes, I wanted to ask you again about doctor appointment..."
    new "是的，我想再问一下关于医生预约的事……"

translate chinese chinese_1107371_263:
    old "It's today, Can you go with me?"
    new "就是今天，你能陪我一起去吗？"

translate chinese chinese_2337658_264:
    old "By the way, please remember to visit my mom, remember that next week marks a month of my father's death..."
    new "对了，请记得去我妈妈那里看看，下周是我爸爸去世一个月……"

translate chinese chinese_2333715_265:
    old "Oh, has it been a month?"
    new "哦，已经一个月了？"

translate chinese chinese_3799888_266:
    old "Yes, and it would be a great gesture if you could visit her, now that she is a widow, she needs some company."
    new "是的，如果你能去看望她就太好了，现在她成了寡妇，需要有人陪伴。"

translate chinese chinese_2736516_267:
    old "Perfect, I'll go visit her..."
    new "完美，我去看看她..."

translate chinese chinese_6235022_268:
    old "Before you go, [mo2] talked to me... And, I want you to know that watching porn is perfectly normal."
    new "走之前，[mo2] 和我谈过……而且，我想让你知道看色情片是很正常的。"

translate chinese chinese_6069465_269:
    old "You are at the age of exploring your body, stimulations and physical sensations..."
    new "你正处于探索身体、刺激和物理感觉的年龄……"

translate chinese chinese_8467403_270:
    old "What?... I wasn't-"
    new "什么？……我没——"

translate chinese chinese_1510330_271:
    old "Don't worry, honey. Nobody is judging you. You have urges, and it is important for you to release them... It is very healthy."
    new "别担心，亲爱的。没人评判你。你有冲动，释放它们对你很重要……这非常健康。"

translate chinese chinese_3306033_272:
    old "I just want you to know that if you have any questions or need help, please ask me."
    new "我只是想让你知道，如果你有任何问题或者需要帮助，请告诉我。"

translate chinese chinese_7894200_273:
    old "I will be in the pool if you need me."
    new "如果你需要我，我会在泳池里。"

translate chinese chinese_3263122_274:
    old "Ok, [mo1rel]. Thanks."
    new "好的，[mo1rel]。谢谢。"

translate chinese chinese_6043087_275:
    old "Alright, sweetie. I will be here if you need me..."
    new "好吧，亲爱的。你需要我的时候我就在这里..."

translate chinese chinese_1155917_276:
    old "Would you like a-"
    new "你想来点-"

translate chinese chinese_2279101_277:
    old "What the... Oh [mo2] you scared me ..."
    new "什么……哦[mo2]你吓我一跳……"

translate chinese chinese_5890651_278:
    old "We... We were watching a movie, do you... Want to join?"
    new "我们……我们在看电影，你……想一起来吗？"

translate chinese chinese_0940691_279:
    old "No, I don't want to join, but the Wi-Fi is better here and I.. need to download some files."
    new "不，我不想加入，但是这里的Wi-Fi信号好些，我……需要下载一些文件。"

translate chinese chinese_1339035_280:
    old "You keep watching your stupid movie, I'll be busy."
    new "你继续看你的傻电影吧，我会很忙的。"

translate chinese chinese_3123995_281:
    old "Oh, ok we won't bother you."
    new "哦，好的，我们不打扰你了。"

translate chinese chinese_1875171_282:
    old "{i}Now where were we?{/i}"
    new "现在说到哪儿了？"

translate chinese chinese_3897977_283:
    old "{i}Lower your voice. We don't want to be caught{/i}"
    new "({i}声音低点。别被人发现了。{/i})"

translate chinese chinese_9483956_284:
    old "{i}Ok. Are we really going to do this?{/i}"
    new "{i}好。我们真的要这么做吗？{/i}"

translate chinese chinese_5909693_285:
    old "{i}This is more exciting, isn't?{/i}"
    new "这更刺激些，不是吗？"

translate chinese chinese_4413368_286:
    old "{i}No, this is pretty dangerous.{/i}"
    new "不，这真的很危险。"

translate chinese chinese_4709958_287:
    old "{i}That's why it gets so exciting...{/i}"
    new "{i}这就是为什么它会变得如此刺激...{/i}"

translate chinese chinese_1456584_288:
    old "Shit, she's not doing well. It's best to take her to her room so she can rest."
    new "shit，她状态不好。最好带她回房间休息。"

translate chinese chinese_1821863_289:
    old "Thank you honey for bringing me here, excuse me for being like this..."
    new "谢谢你带我来这里，对不起变得这样……"

translate chinese chinese_2984569_290:
    old "I think I drank a little more... "
    new "我觉得我多喝了一点……"

translate chinese chinese_2933079_291:
    old "But you know, the break up with [mo2] has affected me a little."
    new "但是你知道吗，和[mo2]的分手还是有点影响到我。"

translate chinese chinese_8208548_292:
    old "Don't worry, it's no problem, just try to rest..."
    new "别担心，没问题的，just试试休息一下..."

translate chinese chinese_3634283_293:
    old "[pla]."
    new "[pla]."

translate chinese chinese_6626725_294:
    old "Could you sleep with me?... I don't want to sleep alone in such a cold bed."
    new "你能陪我睡吗？……我不愿意在这张冷冰冰的床上独自入睡。"

translate chinese chinese_8061208_295:
    old "Yes, don't worry I'll sleep with you ..."
    new "好的，别担心，我会和你睡的……"

translate chinese chinese_4512261_296:
    old "Oh, thank you very much, excuse me for bothering you so much..."
    new "哦，非常感谢，打扰你这么多真是不好意思……"

translate chinese chinese_6135259_297:
    old "Could you please come to bed after turning on the light? Everything is dark."
    new "你能开灯后再上床吗？ everything is dark."

translate chinese chinese_5547284_298:
    old "Thank you so much for all your support, I really appreciate it,"
    new "真的很感谢你的支持，我非常感激。"

translate chinese chinese_4551819_299:
    old "This break up has been very hard..."
    new "这次分手真的很难……"

translate chinese chinese_8684149_300:
    old "But you've been there for me..."
    new "但是你一直在支持我……"

translate chinese chinese_2274406_301:
    old "You are so handsome, did you know?"
    new "你真是帅炸了，知道吗？"

translate chinese chinese_9935798_302:
    old "You've made me feel things I haven't felt in a long time..."
    new "你让我感受到了很久没有过的感受……"

translate chinese chinese_7849945_303:
    old "The last time I was with a man was so many years ago..."
    new "上一次和男人在一起还是很多年前的事了……"

translate chinese chinese_2991521_304:
    old "But, he wasn't as big as you."
    new "但是，他没有你这么大。"

translate chinese chinese_9500320_305:
    old "Look at this size, I think if I had met a man with something like that..."
    new "看看这尺寸，我觉得如果我遇到一个有这样的东西的男人……"

translate chinese chinese_0185649_306:
    old "Probably never would have been with a woman."
    new "大概永远不会和女人在一起。"

translate chinese chinese_7078409_307:
    old "You have been so good to me."
    new "你对我真好。"

translate chinese chinese_5398967_308:
    old "I just want to reward you a little for that ..."
    new "我只是想稍微奖励你一下……"

translate chinese chinese_3738244_309:
    old "You know what, get on the edge of the bed, I will give you a good gift."
    new "你知道吗，到床边来，我会给你一个好礼物。"

translate chinese chinese_5402277_310:
    old "(Wow...)"
    new "（哇……）"

translate chinese chinese_2371832_311:
    old "(Sorry but I have to do it...)"
    new "（对不起，但我必须这么做...）"

translate chinese chinese_3616587_312:
    old "Hi honey..."
    new "亲爱的……"

translate chinese chinese_0113512_313:
    old "Wow, what are you doing?"
    new "哇，你在干什么？"

translate chinese chinese_9851927_314:
    old "We shouldn't do it here honey... Your [sisrel] could caught us."
    new "我们不该在这里做这个，亲爱的……你的[sisrel]可能会发现我们。"

translate chinese chinese_2985806_315:
    old "Oh honey, do you need me?"
    new "哦宝贝，你需要我吗？"

translate chinese chinese_6934055_316:
    old "No, I was just walking around."
    new "不，我刚才只是随便走走。"

translate chinese chinese_5863830_317:
    old "Ok, Ill be here if you need me."
    new "好的，你需要我的时候我就在这里。"

translate chinese chinese_7462099_318:
    old "Wow that was pretty intense."
    new "哇，那真是挺激烈的。"

translate chinese chinese_9096798_319:
    old "Next time, just make sure nobody is at home, ok?"
    new "下次确保家里没人就行了，好吗？"

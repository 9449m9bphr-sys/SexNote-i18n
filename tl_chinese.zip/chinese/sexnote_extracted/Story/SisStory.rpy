# auto-tl Qwen Colab

translate chinese chinese_7630460_0:
    old "Hey [pla], I heard [mo1] and [mo2] arguing about you last night."
    new "嘿[pla]，我听说昨晚[mo1]和[mo2]在争论你。"

translate chinese chinese_4813585_1:
    old "Do you know what happened?"
    new "你知道发生了什么吗？"

translate chinese chinese_3546251_2:
    old "About me? Oh, fuck... "
    new "关于我？哦，操..."

translate chinese chinese_7423779_3:
    old "What? Do you know what it was about?"
    new "什么？你知道那是什么回事吗？"

translate chinese chinese_0619823_4:
    old "No, no I don't know. I, uh... I have to go."
    new "不，我不知道。我，呃……我得走了。"

translate chinese chinese_6898304_5:
    old "Wait, don't leave yet! I kinda need your help... "
    new "等一下，别走！我其实需要你的帮助……"

translate chinese chinese_2273359_6:
    old "Well, you know all the nerdy shit, right?"
    new "好吧，你知道所有那些宅男的东西，对吧？"

translate chinese chinese_2621250_7:
    old "... What are you trying to say?"
    new "……你什么意思？"

translate chinese chinese_9338619_8:
    old "What I mean is, do you know how to make a website?"
    new "我的意思是，你知道怎么建网站吗？"

translate chinese chinese_7642660_9:
    old "Well, yes, I know how to do it."
    new "嗯，是的，我知道怎么做。"

translate chinese chinese_8822092_10:
    old "See, that's nerdy shit... "
    new "你看，这就是书呆子的行为..."

translate chinese chinese_7329302_11:
    old "Come out with it. What do you need?"
    new "说出来吧，你需要什么？"

translate chinese chinese_4619008_12:
    old "Haha. Ok, just come to my room in the afternoon and I will explain everything..."
    new "哈哈。好吧，下午来我的房间，我再详细解释……"

translate chinese chinese_6749905_13:
    old "Oh, shit..."
    new "哦，shit..."

translate chinese chinese_7711865_14:
    old "(GOD that's his... It's huge...)"
    new "（天哪，那他的……好大……）"

translate chinese chinese_3648660_15:
    old "No... It's... Not... What... It seems..."
    new "不……那……不是……什么……看起来的那样……"

translate chinese chinese_3200734_16:
    old "Oh shit, did she see you?"
    new "哦shit，她看到你了吗？"

translate chinese chinese_7147268_17:
    old "Of course not. No one but you can see me..."
    new "当然不行。除了你没人能看见我..."

translate chinese chinese_3341452_18:
    old "Yeah... But she saw me... Like this... Fuck..."
    new "嗯……但她看到我……像这样……操……"

translate chinese chinese_8110181_19:
    old "Now what? It doesn't go down..."
    new "现在怎么办？它没下去……"

translate chinese chinese_7540635_20:
    old "Well, I think that interrupting the process of transferring magic power so abruptly was not a good thing..."
    new "嗯，我觉得这么突然中断转移魔力的过程不是什么好事情……"

translate chinese chinese_9223807_21:
    old "So, now what do I do to get this thing down?"
    new "那我现在该怎么办才能搞定这件事呢？"

translate chinese chinese_3198644_22:
    old "Well... It would be best to wait for your body to process all the magical power it received for the first time."
    new "嗯……最好等你的身体完全处理完第一次接收的魔力。"

translate chinese chinese_0986331_23:
    old "Okay. It's probably best to go to my room before someone else comes in and sees me with this..."
    new "好吧。最好还是去我的房间，免得有人进来看到我拿着这个……"

translate chinese chinese_0612007_24:
    old "Ok, I'll rest and try to recover some magical energy."
    new "好吧，我先休息一下，尝试恢复一些魔法能量。"

translate chinese chinese_1575221_25:
    old "Oh... Hi, [sis]... "
    new "哦……嗨，[sis]……"

translate chinese chinese_7636226_26:
    old "I've been waiting for you. Let's jump right into it, shall we?"
    new "我一直在等你呢。咱们直接开始吧？"

translate chinese chinese_6641815_27:
    old "... Sure, I guess."
    new "……好吧，我想。"

translate chinese chinese_3477849_28:
    old "Now, pay attention... As you know, I have been selling clothes to friends and acquaintances."
    new "现在注意听……你知道的，我一直在向朋友和熟人卖衣服。"

translate chinese chinese_6503565_29:
    old "But now I want to sell them on the internet! That's why I need you to help me make a website."
    new "但现在我想在网上卖掉它们！这就是为什么需要你帮我做个网站。"

translate chinese chinese_6868416_30:
    old "Well, I've never done a storefront site before... But it should be easy enough."
    new "嗯，我之前没做过店面网站……但应该挺简单的。"

translate chinese chinese_0577453_31:
    old "Perfect! Good nerd! Because I will need it ready for next week. I have a lot of items to post."
    new "完美！好棒！因为下周我需要它准备好。我有很多东西要发布。"

translate chinese chinese_0607138_32:
    old "What? That's gonna be pretty hard to make it that fast, [sis]."
    new "什么？那样快就做到可不容易啊，[sis]。"

translate chinese chinese_5538865_33:
    old "Making a good website takes time. You'd have to work on it for days, sometimes weeks. And then it could be buggy and-."
    new "做一个好的网站需要时间。你可能得花上好几天，甚至几周的时间来制作它。而且它可能会有bug，然后——"

translate chinese chinese_8093567_34:
    old "Oh, come on, [pla]! You're a nerd. King nerd, in fact. I trust you can whip my site up in no time."
    new "哦，别这样，[pla]！你是个书呆子。事实上是书呆之王。我相信你能很快给我做好网站的。"

translate chinese chinese_6464009_35:
    old "It's just not as simple as you think. Actually, I'm going to need you to work closely with me to tell me how you want it designed."
    new "事情没你想的那么简单。实际上，我需要你密切配合，告诉我你想要的设计方案。"

translate chinese chinese_0806737_36:
    old "Alright, but how long will this take? And I'm not trying to just get this for free. I'm willing to pay a small fee for your help."
    new "好吧，但这需要多长时间？我不是想白拿这些东西。我愿意付一点费用来请你帮忙。"

translate chinese chinese_3732961_37:
    old "Really? Hmmm... Maybe we can work in the afternoons and see how far we can go with it."
    new "真的吗？嗯……也许我们可以下午工作，看看能走多远。"

translate chinese chinese_0376416_38:
    old "That's the spirit, little dude. And hey, if it all works out well, I could share some of the profits."
    new "就是这股劲头，小家伙。而且嘿，如果一切顺利，我可以分你一些利润。"

translate chinese chinese_7836107_39:
    old "Nice. Sounds good to me."
    new "不错，听起来挺好的。"

translate chinese chinese_2614847_40:
    old "Perfect! Then I will wait for you in the afternoon in my room so we can start working. And don't have me waiting like you did yesterday."
    new "完美！那我下午就在房间里等你，我们可以开始工作了。别像昨天那样让我等。"

translate chinese chinese_1478962_41:
    old "Ok, I will see you in the afternoon to help you."
    new "好的，我下午来帮你。"

translate chinese chinese_9464182_42:
    old "Thank you so much! By the way, what have you been doing in the garage?"
    new "太感谢了！对了，你在车库里面干什么呢？"

translate chinese chinese_4887259_43:
    old "Well... Uhh... A school project... "
    new "嗯……啊……一个学校项目……"

translate chinese chinese_2494001_44:
    old "And what's so exciting in the project that's making your dick so hard?"
    new "项目里有什么这么让你兴奋的，把你激动成这样的？"

translate chinese chinese_1941698_45:
    old "What? Uhh... I don't know... What are you're talking about... "
    new "什么？呃……我不知道……你在说什么……"

translate chinese chinese_0296603_46:
    old "Haha. Yeah, right. You know I saw it?"
    new "哈哈。是吗？你知道我看到了吗？"

translate chinese chinese_8076916_47:
    old "Ok, ok, don't answer me. I was just being curious... If you need to go ahead with your project, do your thing."
    new "好吧好吧，你不回答就算了。我只是好奇而已……如果你要继续你的项目，就去做吧。"

translate chinese chinese_5825637_48:
    old "Just don't forget me in the afternoons."
    new "下午别忘了我。"

translate chinese chinese_7720516_49:
    old "Damn, it's late. I didn't realize how much time has passed."
    new "妈的，好晚了。我都没注意到时间过得这么快。"

translate chinese chinese_6861812_50:
    old "Yup, we did a lot of work today."
    new "没错，今天我们干了很多活。"

translate chinese chinese_5951455_51:
    old "That's right, you deserve a break today. Thanks for your hard work."
    new "没错，你今天应该休息一下。感谢你的辛勤工作。"

translate chinese chinese_2237806_52:
    old "Ok, you are very welcome... See you later, good night."
    new "好，不客气……再见，晚安。"

translate chinese chinese_7193642_53:
    old "Yeah, but we are making so much progress."
    new "是啊，但我们已经取得了很大进展。"

translate chinese chinese_6334501_54:
    old "Right! I like this kind of work. You typing all of those codes and me saying what to do... "
    new "对！我就喜欢这种工作。你打代码，我指挥……"

translate chinese chinese_9165399_55:
    old "Yeah... That was really fun... "
    new "嗯……那真的很有趣……"

translate chinese chinese_7458929_56:
    old "Oh, come on, it wasn't that bad and I will pay you... "
    new "哦，别这样，也没那么糟，我会付你钱的……"

translate chinese chinese_5241442_57:
    old "You are right about that. We are a good team."
    new "你说得对，我们是很棒的搭档。"

translate chinese chinese_5038982_58:
    old "That's better! Ok, let's link back up tomorrow to keep working!"
    new "这样就好多了！好吧，明天再联系继续干活！"

translate chinese chinese_0136714_59:
    old "Ok, see you later, [sis]. Have a good night."
    new "好的，再见了，[sis]。晚安。"

translate chinese chinese_3457034_60:
    old "What the fuck! What is this?"
    new "妈的！这是什么？"

translate chinese chinese_9203793_61:
    old "NOTHING... NOTHING! (Shit!) I THINK WE'RE DONE FOR TODAY!"
    new "什么……什么！（糟了！）我觉得今天就到此为止吧！"

translate chinese chinese_2428423_62:
    old "But... There is still so much to do."
    new "但是……还有很多事情要做。"

translate chinese chinese_6548213_63:
    old "A Virus! My laptop has a virus and I need to fix it... Come tomorrow. Leave now."
    new "病毒！我的笔记本电脑中病毒了，我得修一下……明天再来吧。你现在先走吧。"

translate chinese chinese_5090741_64:
    old "... (Hmm, that was weird.)"
    new "……（嗯，这挺奇怪的。）"

translate chinese chinese_4658182_65:
    old "I should check if [sis] needs help with the website."
    new "我应该看看[sis]是否需要帮忙处理网站。"

translate chinese chinese_3008370_66:
    old "Oh wow!"
    new "哦 wow！"

translate chinese chinese_3209309_67:
    old "I- I'm sorry, I didn't k- know..."
    new "我……对不起，我不知道……"

translate chinese chinese_0667650_68:
    old "Oh, come on... This isn't what you wanted to see?"
    new "哦，别这样……这不就是你想看到的吗？"

translate chinese chinese_3795880_69:
    old "Turn around [pla], I want you to see me..."
    new "转过身来[pla]，我想让你看看我..."

translate chinese chinese_4605228_70:
    old "Ohh... Look what we have here... You definitely have a huge cock..."
    new "哦……看看我们这是有什么……你确实有个很大的棒子……"

translate chinese chinese_2183265_71:
    old "You have worked very, very hard for me, maybe you deserve a small reward."
    new "你为我付出了很多努力，也许你应该得到一点奖励。"

translate chinese chinese_9580787_72:
    old "Well I think you have something for me down there, maybe I should take care of it."
    new "嗯，我觉得你下面有东西是给我的，也许我应该处理一下。"

translate chinese chinese_5343597_73:
    old "I know you want to fuck me... I think I could let you fuck my mouth, would you like that?"
    new "我知道你想操我……我觉得我可以让你操我的嘴，你觉得怎么样？"

translate chinese chinese_8364103_74:
    old "Yes, I'll let you fuck my mouth, with that huge cock..."
    new "好吧，我让你用那么大的 cock 干我的嘴……"

translate chinese chinese_4466685_75:
    old "Now, take out that cock and come here!"
    new "现在，把那东西拿出来，给我过来！"

translate chinese chinese_7951116_76:
    old "Wow! That was just a dream..."
    new "哇！那只是个梦……"

translate chinese chinese_7753828_77:
    old "I should definitely stop playing visual novels..."
    new "我真该停止玩视觉小说了..."

translate chinese chinese_2910162_78:
    old "Working with her so much is affecting me in some way."
    new "和她一起工作这么多，多少也影响到我了。"

translate chinese chinese_2969044_79:
    old "Ufff finally... I think that's it, we are done."
    new "呼，终于……我想这就完了，我们搞定了。"

translate chinese chinese_7972755_80:
    old "Really? Finally? Excellent!!! So, how do we start selling products?"
    new "真的吗？终于了吗？太好了！！！那我们怎么开始卖产品呢？"

translate chinese chinese_8122112_81:
    old "Hmm... I'm a bit tired because of all I have done, we can check tomorrow."
    new "嗯……因为我做了很多事情，有点累了，我们明天再看吧。"

translate chinese chinese_1388596_82:
    old "What?! I've been waiting for weeks! I need to sell my products as fast as I can, it will take just a moment and you're not going die for that... "
    new "什么?! 我等了好几个星期！我得赶紧卖掉我的产品，这只需要一会儿，你不会为此死掉的……"

translate chinese chinese_4539843_83:
    old "Ok, I will explain, pay attention to this."
    new "好，我来解释一下，注意听。"

translate chinese chinese_0969328_84:
    old "Oh, this is a very interesting part on web designing, I used javascript in order to make your webpage responsive, I apply the layouts and-"
    new "哦，这是网页设计中非常有趣的一部分，我用了JavaScript来让你的网页响应式布局，我应用了这些布局并且——"

translate chinese chinese_6873024_85:
    old "Come On! straight to the point nerd! How do I upload the content?"
    new "快点！别绕弯子！怎么上传内容？"

translate chinese chinese_9980337_86:
    old "Ok, well, to upload the pics and info, you need to access with the admin account, open the products window and there you can upload, item by item... "
    new "好的，那你需要使用管理员账号登录，打开产品窗口，然后就可以一项项上传图片和信息了……"

translate chinese chinese_8237078_87:
    old "The description needs a title, detailed info of the product, the pics and finally the price, and there you go!"
    new "描述需要标题、产品的详细信息、图片，最后是价格，就这样！"

translate chinese chinese_3998917_88:
    old "Woow, amazing, let me try myself... "
    new "哇，真厉害，让我也试试..."

translate chinese chinese_2336253_89:
    old "Ok... "
    new "好吧……"

translate chinese chinese_9870898_90:
    old "It's not as hard as you said, actually it's pretty simple... "
    new "其实没有你说的那么难，挺简单的..."

translate chinese chinese_7786576_91:
    old "Well, it's because the hardest part was done already with the coding... "
    new "嗯，因为最难的部分已经通过编码完成了……"

translate chinese chinese_2334072_92:
    old "Suuuuure. Now, how can an user make a purchase?"
    new "当然了。那么，用户怎么进行购买呢？"

translate chinese chinese_5666114_93:
    old "Well, everything is done thru the security framework-"
    new "嗯，一切都是通过安全框架来处理的——"

translate chinese chinese_8065813_94:
    old "BORING! just tell me how I can see the money. "
    new "真无聊！直接告诉我怎么能看到钱就行了。"

translate chinese chinese_3522145_95:
    old "Hmm ok. You need to go to the sales window, here you will see the customer info, products and money."
    new "嗯好。你需要去销售窗口，这里你会看到客户信息、产品和钱。"

translate chinese chinese_6709111_96:
    old "Wujuu! If you behave I think, there is an option to make you my partner."
    new "喂！如果你表现好，我觉得可以考虑让你当我的搭档。"

translate chinese chinese_1871007_97:
    old "Yeah right. Well I think that's all for today, need anything else?"
    new "是吗。好吧，今天就到这里吧，还需要什么吗？"

translate chinese chinese_1290798_98:
    old "No, if I need something I'll reach out to you... You better not doing something weird... "
    new "不，如果我需要什么会主动联系你……你最好别搞什么奇怪的举动……"

translate chinese chinese_3515246_99:
    old "Nevermind... I will be busy, doing my work, see you later... "
    new "算了吧……我一会儿忙着工作，回头见……"

translate chinese chinese_2739875_100:
    old "Hmm, Ok... (You are welcome, by the way... )"
    new "嗯，好吧……（对了，你太客气了……）"

translate chinese chinese_7784771_101:
    old "(Oh shit! My [sisrel] is taking a shower... )"
    new "（哦shit！我的[sisrel]正在洗澡……）"

translate chinese chinese_4618604_102:
    old "(She's got such an amazing body... )"
    new "（她身材真好……）"

translate chinese chinese_9002479_103:
    old "(I should leave... I don't want to make her think I'm perverted.)"
    new "（我还是走吧……我不想让她觉得我是个变态。）"

translate chinese chinese_8393017_104:
    old "(I should leave... I don't want to make her think I'm a pervert.)"
    new "(我还是走吧……我不想让她以为我是变态。)"

translate chinese chinese_5018185_105:
    old "What the fuck! What are you doing, [pla]?"
    new "妈的！你在干什么，[pla]？"

translate chinese chinese_6382903_106:
    old "Sorry, I was-."
    new "对不起，我刚才-."

translate chinese chinese_6066523_107:
    old "COME IN... AND CLOSE THE DOOR."
    new "进来……然后把门关上。"

translate chinese chinese_6354667_108:
    old "(Shit!)"
    new "（糟了！）"

translate chinese chinese_5817804_109:
    old "Look I... "
    new "看我..."

translate chinese chinese_0147489_110:
    old "Shut up... You just saw me... Now it's my turn."
    new "闭嘴……你刚才还看着我……现在轮到我了。"

translate chinese chinese_7510734_111:
    old "(Gulp) What? What do you mean?"
    new "（咽口水）什么？你什么意思？"

translate chinese chinese_2953119_112:
    old "I mean, show me what you got in those shorts."
    new "我的意思是，让我看看你短裤里有什么。"

translate chinese chinese_2080046_113:
    old "Whaat?... "
    new "啥？..."

translate chinese chinese_7902591_114:
    old "Well, if you don't show me, I'm going to scream and tell [mo1] and [mo2] you were peeping on me."
    new "好吧，如果你不给我看，我就尖叫着告诉[mo1]和[mo2]你偷看我。"

translate chinese chinese_9546942_115:
    old "B- but... Why do you want to see me naked?"
    new "你、你为什么想看我裸体？"

translate chinese chinese_6070381_116:
    old "Is justice for a pervert... And I'm just curious about what I saw in the garage last time... So show me... Now!"
    new "一个色狼的正义……而且我只是好奇上次在车库看到的东西……所以给我看看……现在！"

translate chinese chinese_7654094_117:
    old "Alright, alright... "
    new "好吧，好吧……"

translate chinese chinese_5806929_118:
    old "(Mmm... It's bigger than some pornstars I use to see.)"
    new "（嗯……比一些我以前看过的pornstar还要大。）"

translate chinese chinese_5370332_119:
    old "And... Why were you so excited at the garage?"
    new "而且……你在车库为什么会那么兴奋？"

translate chinese chinese_9881399_120:
    old "Hmm... I- I don't know what you're talking about."
    new "嗯……我——我不知道你在说什么。"

translate chinese chinese_7337583_121:
    old "Ugh. Ok, nevermind... I should go... "
    new "唉，算了……我应该走了……"

translate chinese chinese_4926051_122:
    old "Wait... That's my? "
    new "等一下……那是我的？"

translate chinese chinese_0563360_123:
    old "Bye... "
    new "再见..."

translate chinese chinese_7707292_124:
    old "What the hell! She took my clothes!"
    new "妈的！她把我的衣服拿走了！"

translate chinese chinese_1544487_125:
    old "Oh shit! What do I do now?"
    new "哦shit！我现在该怎么办？"

translate chinese chinese_0557096_126:
    old "I gotta get to my room really fast!"
    new "我得赶紧回房间！"

translate chinese chinese_4371912_127:
    old "Ok I don't see anyone nearby, now is my chance... "
    new "好的，我没看到附近有人，现在是我的机会了……"

translate chinese chinese_2173164_128:
    old "WHAT THE FUCK?!"
    new "卧槽?!"

translate chinese chinese_0329600_129:
    old "(... Oh god..) Sorry... "
    new "（……哦天……）对不起……"

translate chinese chinese_8023629_130:
    old "YOU ARE A FUCKING PERVERT AND AN EXHIBITIONIST!!!"
    new "你真是个变态而且还是个暴露狂！！！"

translate chinese chinese_4004239_131:
    old "(Oh shit, oh shit. I almost died! Fuck!)"
    new "（哦操，哦操。我差点死了！操！）"

translate chinese chinese_8197066_132:
    old "It's probably best to stay here until tomorrow... "
    new "最好还是待到明天吧……"

translate chinese chinese_7297705_133:
    old "Well, I am kind of ok."
    new "嗯，我还算好吧。"

translate chinese chinese_6451174_134:
    old "Hmm... Is everything alright?"
    new "嗯……一切都好吗？"

translate chinese chinese_1815575_135:
    old "Not really, the website is not working and I don't know what's wrong."
    new "不是啦，网站出问题了，我不知道怎么了。"

translate chinese chinese_2696219_136:
    old "Is not working? You wanna check it together to see what the problem could be?"
    new "不好用吗？你想一起检查一下问题出在哪里吗？"

translate chinese chinese_0980699_137:
    old "Oh please, because I feel a bit down, you know."
    new "哦请，因为我感觉有点沮丧，你知道。"

translate chinese chinese_4176674_138:
    old "Don't worry, we can find a solution."
    new "别担心，我们可以找到解决办法。"

translate chinese chinese_1711096_139:
    old "I can see that your webpage has been visited several times, so there are actually people looking at it."
    new "我能看出来你的网页被访问了好几次，所以实际上是有人都在看的。"

translate chinese chinese_0288512_140:
    old "I think the clothes are nice, but do you think they're maybe too expensive?"
    new "我觉得这些衣服不错，但你觉得它们会不会太贵了？"

translate chinese chinese_1199287_141:
    old "Hmmm, I think you have a good variety of prices, so I don't think that is the problem."
    new "嗯，我觉得你的价格范围挺广的，所以问题可能不在这儿。"

translate chinese chinese_1249900_142:
    old "Could it be that the products aren't that nice?"
    new "难道这些产品真的不好？"

translate chinese chinese_2744312_143:
    old "I actually like them, I've seen you wearing some of the clothes, they look cool."
    new "我其实挺喜欢的，我见过你穿一些这些衣服，看起来挺酷的。"

translate chinese chinese_3314118_144:
    old "Is the website running correctly?"
    new "网站运行正常吗？"

translate chinese chinese_3784051_145:
    old "What do you mean? Sure! it works, I made it myself."
    new "你什么意思？当然可以！我自己做的，没问题。"

translate chinese chinese_7479357_146:
    old "Let's try to make a purchase to see if the website is ok."
    new "咱们试着买点东西，看看网站有没有问题。"

translate chinese chinese_3174186_147:
    old "I did everything carefully... Hmm, but we can double check."
    new "我一切都做得非常仔细……嗯，不过我们可以再检查一遍。"

translate chinese chinese_8882590_148:
    old "Perfect, select that shirt, then those pants, add them to the shopping cart."
    new "好的，选那件衬衫，然后那条裤子，加到购物车里。"

translate chinese chinese_1793621_149:
    old "What's next?"
    new "接下来做什么？"

translate chinese chinese_2937772_150:
    old "The delivery info"
    new "配送信息"

translate chinese chinese_3548736_151:
    old "Ok, let's use ours."
    new "好吧，我们用我们的。"

translate chinese chinese_4568041_152:
    old "Oh, payment options, let's put the card in."
    new "哦，支付选项，把卡插进去吧。"

translate chinese chinese_0218130_153:
    old "Finally, summary cart."
    new "终于，总结栏。"

translate chinese chinese_9102742_154:
    old "Order went through successfully, the website works perfectly. That's not the problem."
    new "订单已经成功提交，网站运行完美。那不是问题。"

translate chinese chinese_3924756_155:
    old "Cancel the order."
    new "取消订单。"

translate chinese chinese_0846638_156:
    old "I don't get it... What am I doing wrong?"
    new "我不明白……我哪里做错了？"

translate chinese chinese_1099834_157:
    old "What do other people do to sell?"
    new "其他人是怎么卖的？"

translate chinese chinese_8097287_158:
    old "Huh! that's brilliant."
    new "huh! 真是个好主意。"

translate chinese chinese_2364779_159:
    old "Really? Wait... What's brilliant?"
    new "真的？等一下……什么很厉害？"

translate chinese chinese_0893420_160:
    old "A very good idea could be to check how other people do it."
    new "一个非常好的想法是看看别人是怎么做的。"

translate chinese chinese_8419621_161:
    old "Let's compare ours with other websites, that way we can take some ideas too."
    new "咱们可以和其他网站对比一下，顺便也能借鉴一些想法。"

translate chinese chinese_6814122_162:
    old "Let's check a big one like... Hmm I don't know, Calvin Klown."
    new "我们来看看像卡尔文·克洛恩这样的大人物吧。嗯，我不知道，卡尔文·克洛恩。"

translate chinese chinese_7885653_163:
    old "Yeah, that could work."
    new "嗯，那样倒是可以。"

translate chinese chinese_4657328_164:
    old "They are really good, this looks amazing."
    new "它们真的很棒，这看起来太惊艳了。"

translate chinese chinese_9021261_165:
    old "Yeah, it's very depressing."
    new "是啊，真的很压抑。"

translate chinese chinese_3090640_166:
    old "Just look! They are just so gorgeous, mine doesn't look even close."
    new "你看！她们简直太漂亮了，我的根本没法比。"

translate chinese chinese_6378923_167:
    old "Well, it's not fair if you compare yourself with them, this is a worldwide fashion business!"
    new "好吧，如果你拿自己和他们比就不公平了，这可是全球性的时尚业！"

translate chinese chinese_7006379_168:
    old "Consider, that they invest millions on advertisement, Internet, TV characters, even music videos and artists."
    new "想想他们投入了数百万在广告、互联网、电视角色，甚至音乐视频和艺人上。"

translate chinese chinese_5283042_169:
    old "Yeah, that's very impressive."
    new "是啊，真厉害。"

translate chinese chinese_1349067_170:
    old "Alright, that was enough Calvin Klown for one day."
    new "好吧，今天卡尔文·克劳恩的份够多了。"

translate chinese chinese_7935716_171:
    old "Hmm... I have something in mind."
    new "嗯……我有个想法。"

translate chinese chinese_0150384_172:
    old "Well, we could, and I am not sure... But try some options to show the clothes like they do."
    new "好吧，我们可以试试，虽然我不确定……但试着像他们那样展示衣服选项。"

translate chinese chinese_7704268_173:
    old "You mean the way they use models and take the pics?"
    new "你是说他们使用模特拍照的方式吗？"

translate chinese chinese_3398862_174:
    old "Yes, it could look more... Interesting? I guess so?"
    new "是的，它可以看起来更...有趣？大概吧？"

translate chinese chinese_2190801_175:
    old "We can give it a try, doing the pics instead of using the ones you're using."
    new "我们可以试试，用这些照片代替你现在用的那些。"

translate chinese chinese_3848532_176:
    old "Hmm but we'll need a model and we can't afford that... "
    new "嗯，但是我们需要一个模特，我们又负担不起……"

translate chinese chinese_4269935_177:
    old "Wait a minute... I could be the model, can't I?"
    new "等一下……我当模特不行吗？"

translate chinese chinese_5497921_178:
    old "I considered that an option at first, but I saw there are some clothes where you would be almost naked."
    new "一开始我也考虑过这个选项，但看到有些衣服几乎是裸体的。"

translate chinese chinese_6011705_179:
    old "I mean some clothes are 'sexy' and a lot of people would watch them... Are you sure you are ok with that?"
    new "我是说有些衣服穿起来‘性感’，很多人会看……你确定你能接受这个？"

translate chinese chinese_7778367_180:
    old "Actually, I like the idea... I think it's kind of exciting!"
    new "实际上，我喜欢这个想法……我觉得挺刺激的！"

translate chinese chinese_7332918_181:
    old "Well, if you'd like we would have covered an important part of the problem and if you are the model that would be very useful to have a defined market image."
    new "好吧，如果你愿意的话，我们会讨论问题的一个重要部分，如果你是这个模型，拥有一个明确的市场形象将会非常有用。"

translate chinese chinese_7756201_182:
    old "Ok, so, what do we need?"
    new "好的，那我们需要什么？"

translate chinese chinese_6156074_183:
    old "We will for sure need a photographer."
    new "我们肯定需要一个摄影师。"

translate chinese chinese_5121865_184:
    old "Wait a minute! A photographer could be really expensive."
    new "等一下！请摄影师可能会很贵的。"

translate chinese chinese_3525118_185:
    old "Why don't you take the pics instead?"
    new "你为什么不自己来拍呢？"

translate chinese chinese_4863569_186:
    old "Technically, I could but I have no camera."
    new "理论上我可以，但我没带相机。"

translate chinese chinese_4078132_187:
    old "I think I can handle that. But can you use a professional camera?"
    new "我觉得我可以应付。但是你能用专业的相机吗？"

translate chinese chinese_4861509_188:
    old "What I'm asking for of course a nerd knows."
    new "我问的当然一个书呆子会知道。"

translate chinese chinese_5519407_189:
    old "That's great, so if you take the pictures, we can save a little without asking for the help of a photographer."
    new "太好了，这样的话你自己拍照片，我们就不用请摄影师也能省点钱。"

translate chinese chinese_8885345_190:
    old "So, I will use all my money to buy a lot of clothes, so we can take tons of pics."
    new "所以，我会用所有的钱去买很多衣服，这样我们可以拍好多照片。"

translate chinese chinese_3908189_191:
    old "Wait what? No, no, no, calm down! It isn't convenient to use all the money you have."
    new "等一下什么？不，不，不，冷静点！把所有的钱都用掉并不方便。"

translate chinese chinese_7770468_192:
    old "But we will need the clothes for the pics... "
    new "但是我们还需要衣服来拍照……"

translate chinese chinese_0584105_193:
    old "Yes, we do, however, we have to do some baby steps to check if it works."
    new "是的，不过我们得先做一些小步骤来检查是否可行。"

translate chinese chinese_7647349_194:
    old "If we can see some progress then you can invest more to see an improvement."
    new "如果我们能看到一些进展，你就可以投入更多来看到改进。"

translate chinese chinese_4810765_195:
    old "Hmm... Yeah, I think you're right."
    new "嗯……是的，我觉得你说得对。"

translate chinese chinese_9544625_196:
    old "Ok, I need time now, to get all of this ready. thanks for your help, I really appreciate it."
    new "好的，我现在需要一点时间来准备这一切。感谢你的帮助，我真的很感激。"

translate chinese chinese_3696927_197:
    old "I will let you know as soon as I have everything ready."
    new "等我一切都准备好了就告诉你。"

translate chinese chinese_0408195_198:
    old "Cool, I'll see you then."
    new "好的，到时候见。"

translate chinese chinese_2816100_199:
    old "[pla], where were you? I've been looking for you."
    new "[pla]，你去哪了？我一直在找你。"

translate chinese chinese_9985736_200:
    old "Let's go, the delivery has just arrived."
    new "走吧，快递刚到。"

translate chinese chinese_4771999_201:
    old "You can't imagine how excited I am, I almost jumped from the window when I saw the driver."
    new "你无法想象我有多兴奋，看到司机的时候我差点从窗户跳出去。"

translate chinese chinese_3894729_202:
    old "I can see that, you're all anxious to start."
    new "我看得出来，你急着要开始了。"

translate chinese chinese_5655205_203:
    old "Yes, we can't waste time, I have been waiting for this, the website needs this."
    new "没错，不能浪费时间，我一直在等这个，网站需要这个。"

translate chinese chinese_3425096_204:
    old "Let's go to my bedroom."
    new "去我的卧室吧。"

translate chinese chinese_1227114_205:
    old "Give me a moment, I don't know where to start. "
    new "给我一会儿，我不知道从哪里开始。"

translate chinese chinese_2098422_206:
    old "Ok, just calm down a bit."
    new "好，先冷静一下。"

translate chinese chinese_9224750_207:
    old "I'm pretty impatient we can start right away."
    new "我挺急的，我们可以马上开始。"

translate chinese chinese_5245962_208:
    old "This is for you."
    new "这个给你。"

translate chinese chinese_5987056_209:
    old "Wow, this is huge, looks like a very good camera."
    new "哇，这东西很大，看起来像是一台很好的相机。"

translate chinese chinese_6054490_210:
    old "I am sure you will figure out how it works."
    new "我相信你会搞清楚怎么用的。"

translate chinese chinese_3471041_211:
    old "Bear with me a moment while I get ready. You should try the cam in the meantime."
    new "给我一会儿准备一下。你 meanwhile 可以试试相机。  \n\n（注：此处 \"meanwhile\" 未翻译，因为原文中没有明确指示是否保留该词。如果需要翻译，请告知。）"

translate chinese chinese_1070694_212:
    old "Ok, Sure, I will start checking (It doesn't look so hard.)"
    new "好的，没问题，我会开始检查的。（看起来也没那么难。）"

translate chinese chinese_9128024_213:
    old "(I think auto mode should work just fine to start, I'll give a further review later.)"
    new "（我觉得先用自动模式就行了，后面再详细看看。）"

translate chinese chinese_7754856_214:
    old "(Let's check... She bought really nice clothes.)"
    new "（看看……她买了很不错的衣服。）"

translate chinese chinese_7100080_215:
    old "(This is very short and tiny. How does she fit in?)"
    new "（这非常短小。她是怎么进去的？）"

translate chinese chinese_5594663_216:
    old "(This is a great color for a pic, I think I have a couple of ideas.)"
    new "（这个颜色拍出来肯定很好看，我有几个想法。）"

translate chinese chinese_6637183_217:
    old "(What is this?)"
    new "（这是什么？）"

translate chinese chinese_4317678_218:
    old "(Ohh... This is a...)"
    new "（哦……这是个……）"

translate chinese chinese_7317286_219:
    old "Wow,wow, wow. GET AWAY FROM MY STUFF... You little snoopy."
    new "喂喂喂，别动我的东西……你这个小窥探者。"

translate chinese chinese_1172808_220:
    old "Where did you get it?"
    new "你在哪里搞到的？"

translate chinese chinese_4264494_221:
    old "I mean why are you looking through my stuff?"
    new "我是说，你为什么翻我的东西？"

translate chinese chinese_6919163_222:
    old " I... I- I just... "
    new "我……我 just..."

translate chinese chinese_7837273_223:
    old " I... I... I... What?"
    new "我……我……我……什么？"

translate chinese chinese_8159717_224:
    old "I was checking the clothes you bought, and it was just there."
    new "我检查你买的衣服时，就发现它在那儿。"

translate chinese chinese_3387191_225:
    old "I was not snooping, just checking the clothes and that appeared out nowhere."
    new "我没在偷看，只是看看衣服，那些东西突然就出现了。"

translate chinese chinese_4161153_226:
    old "THERE'S NO TIME TO WASTE, WE CAME TO WORK, LET'S GET STARTED."
    new "没时间浪费了，我们来这里是工作的，开始吧。"

translate chinese chinese_6444163_227:
    old "You're right, I'm sorry."
    new "你说得对，对不起。"

translate chinese chinese_4652393_228:
    old "Alright, just get everything ready while I change."
    new "好吧，我换衣服的时候你就把一切都准备好。"

translate chinese chinese_8968826_229:
    old "Well... How do I look?"
    new "嗯……我看起来怎么样？"

translate chinese chinese_8121483_230:
    old "Gulp... Y-you look ho- nice, you look pretty nice."
    new "gulp... 噗...你看起来很...很好。"

translate chinese chinese_0368327_231:
    old "Let's start, we have already wasted enough."
    new "开始吧，我们已经浪费够多了。"

translate chinese chinese_6602610_232:
    old "Ok, let me try... I will stay here to catch you better, stay right there."
    new "好吧，让我试试……我会待在这里更好地接住你，就在那里别动。"

translate chinese chinese_5297699_233:
    old "(Oh shit.. It's not as easy as I thought...)"
    new "（哦shit……没想到会这么难应付……）"

translate chinese chinese_7817859_234:
    old "Ehh... Just give me a second... I- I'm finding your best... Angle."
    new "呃……给我一会儿……我正在找你最美的角度。"

translate chinese chinese_2226460_235:
    old "(Shit! I must take the picture when it's fully focused...)"
    new "（糟了！我得在完全对焦的时候拍照...）"

translate chinese chinese_3405471_236:
    old "Ehmm... Fine, we could check it at the end of the session..."
    new "嗯……好吧，我们可以在结束时再检查一下……"

translate chinese chinese_4335331_237:
    old "You're right, sorry I'm just a bit anxious."
    new "你说得对，对不起，我就是有点紧张。"

translate chinese chinese_9899978_238:
    old "Don't worry, relax a bit to look more natural."
    new "别紧张，放松一点看起来更自然。"

translate chinese chinese_6801833_239:
    old "Okay, so for the next photo what should I do?"
    new "好的，那下一张照片我该怎么做？"

translate chinese chinese_9479078_240:
    old "Hmm, I think we should take a picture from behind to show the back of the dress..."
    new "嗯，我觉得我们应该从后面拍一张，展示一下裙子的背面……"

translate chinese chinese_7982222_241:
    old "Oh right! So what position should I take?"
    new "哦对了！那我应该采取什么姿势？"

translate chinese chinese_4139684_242:
    old "Hmm, I think we could use the bed, what about if you lean on the edge of the bed with you back pointing to me in a... Sexy way."
    new "嗯，我觉得我们可以用床，如果你背对着我靠在床边，以一种……性感的方式。"

translate chinese chinese_1189931_243:
    old "Alright ..."
    new "好吧……"

translate chinese chinese_1027575_244:
    old "So, do I look good like this?"
    new "所以，我这样看起来怎么样？"

translate chinese chinese_2490873_245:
    old "(Wow) Yeah... You look, great, let me focus on the camera ..."
    new "（ wow ）是啊……你看起来很棒，让我专注于摄像……"

translate chinese chinese_4362170_246:
    old "(Oh shit, I'm getting hard. She looks really hot.)"
    new "（哦shit，我硬了。她看起来真性感。）"

translate chinese chinese_9113831_247:
    old "(I hope she doesn't notice my hardon...)"
    new "（希望她没注意到我硬了……)"

translate chinese chinese_0886466_248:
    old "Ok... I- I think that's enough, for now."
    new "好……我——我觉得够了，暂时先这样吧。"

translate chinese chinese_6098775_249:
    old "What? Just two pics? No, I actually have an idea for a next photo..."
    new "什么？就两张照片？不，我实际上有个下一个照片的主意……"

translate chinese chinese_6351592_250:
    old "R- really? With a front and backside photo of the dress is not... Enough?"
    new "真…真的吗？前后两张照片还不够？"

translate chinese chinese_7870421_251:
    old "(Why is he acting so strange.) No, let's take one last photo, ok?"
    new "（他为什么表现得这么奇怪。）不，我们再拍一张照片吧，好吗？"

translate chinese chinese_6477279_252:
    old "Let me try something I saw."
    new "让我试试我看到的方法。"

translate chinese chinese_2887879_253:
    old "(Is he ok?, he's walking different) Do you think this looks good?"
    new "（他好吗？他走路的样子不一样了）你觉得这样好看吗？"

translate chinese chinese_3477360_254:
    old "(Shit... I'm so hard right now...)"
    new "（shit... 现在好硬...）"

translate chinese chinese_1346819_255:
    old "Y- yes, you look great..."
    new "是的，你看起来很棒……"

translate chinese chinese_9272121_256:
    old "(What he gots there? Ohh! He has a boner. How could I not realize it before?)"
    new "（他那是什么？哦！他硬了。我之前怎么没发现呢？）"

translate chinese chinese_4013972_257:
    old "(Well, I need to let him work, he is very focused, and don't want to make him feel uncomfortable.)"
    new "（好吧，我得让他工作，他很专注，不想让他感到不舒服。）"

translate chinese chinese_5618376_258:
    old "Alright, I think that's enough for now..."
    new "好吧，我觉得现在差不多了..."

translate chinese chinese_3296967_259:
    old "Oh, great, so it's done then see you later..."
    new "哦，太好了，那就这样吧，回头见..."

translate chinese chinese_9245700_260:
    old "Wait a minute..."
    new "等一下……"

translate chinese chinese_8133127_261:
    old "You said we could check the photos at the end of the session..."
    new "你说过我们可以在这次结束后看看那些照片..."

translate chinese chinese_1036093_262:
    old "You're right..."
    new "你说得对..."

translate chinese chinese_7958757_263:
    old "Ok... L- let's see the photos..."
    new "好……好吧，让我们看看照片……"

translate chinese chinese_2089562_264:
    old "Watch again"
    new "再看一遍"

translate chinese chinese_2087663_265:
    old "Not Again"
    new "不会又是这样"

translate chinese chinese_5400256_266:
    old "These photos are out of focus! They look really bad..."
    new "这些照片都模糊了！看起来真的很糟糕……"

translate chinese chinese_9738234_267:
    old "I am sorry, I think I need to practice more."
    new "对不起，我觉得我需要多练习一下。"

translate chinese chinese_4576183_268:
    old "Oh no, this is not good, I wanted to have this material for the website really soon."
    new "哦不，这可不好，我本来想很快就把这个材料准备好发布到网站上的。"

translate chinese chinese_3949023_269:
    old "I can make it better, just need some time."
    new "我可以让你好起来的， just需要一点时间。"

translate chinese chinese_1981438_270:
    old "So you need time but a moment ago you were snooping through my personal stuff."
    new "所以你需要时间，但刚才你还在我个人东西里翻来翻去的。"

translate chinese chinese_3604684_271:
    old "I can't believe it."
    new "真不敢相信。"

translate chinese chinese_6483307_272:
    old "I'm sorry, I will practice more."
    new "对不起，我会多练习的。"

translate chinese chinese_5750156_273:
    old "All right, take the cam with you, and next time you better do it right."
    new "好吧，把相机带上，下次你可得做好点。"

translate chinese chinese_1337641_274:
    old "Well, I am not surprised."
    new "嗯，我一点也不惊讶。"

translate chinese chinese_2136740_275:
    old "Why, don't you like them?"
    new "为什么，你不喜欢它们吗？"

translate chinese chinese_3984175_276:
    old "Yep, I look gorgeous, I mean what could I expect from the 'nerd'."
    new "没错，我看起来棒极了，我是说从这个‘书呆子’身上我能期待什么呢。"

translate chinese chinese_9741326_277:
    old "I just wanted to help you."
    new "我只是想帮你。"

translate chinese chinese_4598901_278:
    old "You did well nerd."
    new "干得不错，书呆子。"

translate chinese chinese_1990730_279:
    old "I didn't mean they are not good, don't take me the wrong way, I meant I knew it."
    new "我不是说他们不好，别误会，我的意思是我知道这件事。"

translate chinese chinese_3741594_280:
    old "I appreciated it."
    new "我挺感激的。"

translate chinese chinese_2913666_281:
    old "Time is money, let me upload this material, I need to sell."
    new "时间就是金钱，让我上传这些材料，我得卖掉。"

translate chinese chinese_8355635_282:
    old "Ok, I guess I'm leaving then."
    new "好吧，那我看来是走了。"

translate chinese chinese_1800261_283:
    old "Ready to repeat the last photoshoot?"
    new "准备好重复上次的拍照了吗？"

translate chinese chinese_5790605_284:
    old "Yes, I practiced and I know I'll do better now..."
    new "是的，我练习过了，我知道我现在会做得更好……"

translate chinese chinese_7470250_285:
    old "You better do it right this time... Don't waste more time. Get ready while I get changed."
    new "这次你最好做好……不要浪费更多时间了。我换衣服的时候你就准备一下。"

translate chinese chinese_9386488_286:
    old "Oh, by the way, do you need some help before we start?"
    new "哦，对了，我们在开始前需要帮忙吗？"

translate chinese chinese_6065449_287:
    old "Well... Ok."
    new "嗯……好吧。"

translate chinese chinese_3563996_288:
    old "Hahaha, I'm going to make you cum fast..."
    new "哈哈，我要让你很快就射了..."

translate chinese chinese_7530625_289:
    old "I'm gonna get changed. You get the camera and stay ready."
    new "我换衣服了。你准备相机，待命。"

translate chinese chinese_5743766_290:
    old "It's ok, I think I will be fine."
    new "没事，我觉得我会没事的。"

translate chinese chinese_6052944_291:
    old "Yes, don't worry. I appreciate your help."
    new "是的，别担心。我很感激你的帮助。"

translate chinese chinese_5014166_292:
    old "Perfect! then let's go, we have so much to do!"
    new "太好了！那我们赶紧出发，有好多事情要做！"

translate chinese chinese_1711288_293:
    old "I am excited, I just want to upload the new pics to get more sales!"
    new "我好激动，just想上传新照片多赚点钱！"

translate chinese chinese_8896176_294:
    old "Alright, let's start! "
    new "好了，开始吧！"

translate chinese chinese_3348044_295:
    old "I already know all the positions. You just focus on taking good pictures this time..."
    new "这些姿势我都知道了。这次你就专心把照片拍好……"

translate chinese chinese_3116116_296:
    old "Ehmm... Done..."
    new "嗯……好了……"

translate chinese chinese_4791210_297:
    old "Alright, next one. You know what to do."
    new "好了，下一个。你知道该怎么做。"

translate chinese chinese_1101532_298:
    old "Very well, last one. I hope all the photos are perfect, right?"
    new "好吧，最后一个。我希望所有的照片都是完美的，对吧？"

translate chinese chinese_8324042_299:
    old "Yes, don't worry..."
    new "是的，别担心……"

translate chinese chinese_8414886_300:
    old "Ok, let's see the new photos!"
    new "好，让我们看看新照片！"

translate chinese chinese_9617570_301:
    old "Really [pla]?! Again out of focus... I can't believe it..."
    new "真的 [pla]？！又走神了……我不敢相信……"

translate chinese chinese_2576153_302:
    old "I-it wasn't my fault, I really tried to improve..."
    new "我、我真的没故意，我真的很努力改进了..."

translate chinese chinese_2019695_303:
    old "Well, it wasn't enough... And you are making me lose money!"
    new "好吧，这还不够……而且你还让我亏本了！"

translate chinese chinese_2683283_304:
    old "Get out... Come back when you learn to use that damn camera..."
    new "滚出去……等你学会用那个该死的相机再回来……"

translate chinese chinese_3144647_305:
    old "Well, finally! These photos are great."
    new "好吧，总算来了！这些照片很棒。"

translate chinese chinese_7873397_306:
    old "I hope next time we don't have to do the photoshoot twice again..."
    new "希望下次不要再重拍照片了……"

translate chinese chinese_9194905_307:
    old "Don't worry..."
    new "别担心……"

translate chinese chinese_1492799_308:
    old "Hmm... Time is money, let me upload this material, I need to sell."
    new "嗯……时间就是金钱，让我上传这些材料，我要卖掉。"

translate chinese chinese_6960802_309:
    old "Ok, leaving now."
    new "好的，我现在就走。"

translate chinese chinese_4746089_310:
    old "(Holy shit! If I get caught she'll kill me!)"
    new "（天呐！要是被发现了她会杀了我的！）"

translate chinese chinese_0297766_311:
    old "Hey, big boy. Do you need some help?"
    new "嘿，大哥哥，需要帮忙吗？"

translate chinese chinese_7304710_312:
    old "Oh, god. Thanks. If she would have caught me, I'd be a goner."
    new "哦，天哪。谢谢。要是被她抓到，我就死定了。"

translate chinese chinese_9778822_313:
    old "It's ok! you are saved now, just relax."
    new "没事了！你现在安全了，放松点。"

translate chinese chinese_3008015_314:
    old "Yes, I appreciate it, you saved my ass."
    new "是的，我心领了，你救了我的命。"

translate chinese chinese_3632243_315:
    old "I feel thankful too, last time you were great with the pics."
    new "我也很感激，上次你拍的照片很棒。"

translate chinese chinese_4015422_316:
    old "Haven't given you a proper reward."
    new "还没给你正式的奖励呢。"

translate chinese chinese_4671874_317:
    old "Wh- What... Do you mean?"
    new "你... 你是说什么？"

translate chinese chinese_7319717_318:
    old "What I mean is... Take off those pants and show me that dick."
    new "我的意思是……把裤子脱了，让我看看那玩意。"

translate chinese chinese_1738190_319:
    old "Oh, come on, [sis]..."
    new "哦，快点吧，[sis]..."

translate chinese chinese_2031143_320:
    old "Just do it... Your [mo2rel] is close. And you don't want me to call her..."
    new "就做吧……你的[mo2rel]就在附近。你可不想让我叫她过来……"

translate chinese chinese_8307242_321:
    old "Really?… Ugh... Ok."
    new "真的吗？……唉……好吧。"

translate chinese chinese_7029952_322:
    old "I knew it! It's fucking huge..."
    new "我就知道！它特么的超大..."

translate chinese chinese_8633492_323:
    old "Just let me turn on the lights to get a better look at it."
    new "让我把灯打开，好仔细看看。"

translate chinese chinese_4427318_324:
    old "Hey buddy, guess what?"
    new "嘿哥们，猜猜怎么着？"

translate chinese chinese_9169924_325:
    old "Your idea was a big noise, it pulled off selling!"
    new "你的想法很奏效，真的卖出去了！"

translate chinese chinese_3475073_326:
    old "Yep, come to my bedroom I need your help with something..."
    new "嗯，来我的卧室，我有件事需要你帮忙……"

translate chinese chinese_1721431_327:
    old "Well, besides the messages I have now. We actually got a new customer, she was pretty interested in the last pics we did, remember?"
    new "好吧，除了我现在收到的信息外，我们实际上有了一个新客户，她对我们上次拍的照片挺感兴趣的，记得吗？"

translate chinese chinese_4607873_328:
    old "Yeah! I know which ones."
    new "对！我知道是哪些。"

translate chinese chinese_3425772_329:
    old "Anyway, I need your help now, we have several customers' messages."
    new "总之，我现在需要你的帮助，有几个客户的留言。"

translate chinese chinese_0231056_330:
    old "I'll need to answer them as some of them are very potential purchases."
    new "我得回复一下，有些可能是很有潜力的购买意向。"

translate chinese chinese_2967730_331:
    old "Need you to take one package to a customer."
    new "需要你把一个包裹送到客户那里。"

translate chinese chinese_8166936_332:
    old "You mean today?"
    new "你是说今天？"

translate chinese chinese_0797873_333:
    old "Oh no, I mean right now."
    new "哦不，我是说现在。"

translate chinese chinese_0079047_334:
    old "I am kind of busy now."
    new "我现在有点忙。"

translate chinese chinese_4744849_335:
    old "That's not a business wise decision."
    new "这可不是一个明智的商业决定。"

translate chinese chinese_8433843_336:
    old "You know this is not actually a favor, it's included in the money you are expecting."
    new "你知道这其实不是什么帮个忙，这是包含在你期望的报酬里的。"

translate chinese chinese_9180977_337:
    old "Hmm... I know, but I can't do it right away... We never discussed these kind of things."
    new "嗯……我知道，但我不马上做……我们从来没讨论过这些事。"

translate chinese chinese_2753882_338:
    old "Yes, I know but we have to be committed to make this business grow."
    new "我知道，但是我们必须全力以赴才能让这个生意发展起来。"

translate chinese chinese_2504073_339:
    old "Come on, almost everybody knows about me here in town, it's not comfortable."
    new "快点，镇上几乎人人都认识我，这让我很不自在。"

translate chinese chinese_2387646_340:
    old "I don't want to be embarrassed delivering sexy panties to a classmate's mother."
    new "我不想因为给同学的妈妈送性感内裤而尴尬。"

translate chinese chinese_1789420_341:
    old "Why would you be embarrassed, it isn't like you're the one wearing it."
    new "你为什么要尴尬，又不是你穿的。"

translate chinese chinese_9358975_342:
    old "Here is the thing, do you still wanna be helped like the other night?"
    new "说吧，你还想像昨晚那样被帮忙吗？"

translate chinese chinese_3142750_343:
    old "So, think about the 'business', if you help me I'll help you. I think my help is amazing, don't you like it?"
    new "所以，想想这个“生意”，如果你帮我，我也会帮你。我觉得我的帮助很厉害，你不觉得吗？"

translate chinese chinese_3495641_344:
    old "Hmm... Fine, but don't take me wrong, It's for business!"
    new "嗯……好吧，但别误会，这是为了生意！"

translate chinese chinese_3609387_345:
    old "Hehehe, yeah sure! The business..."
    new "嘿嘿嘿，好啊好啊！那个生意……"

translate chinese chinese_6685408_346:
    old "You will find all the info you need on the package."
    new "你需要的所有信息都在包装上。"

translate chinese chinese_2688108_347:
    old "Hmm alright..."
    new "嗯，好吧……"

translate chinese chinese_2252846_348:
    old "I think it's here... I hope it's not someone I know."
    new "我觉得就在附近……希望不是认识的人。"

translate chinese chinese_7439813_349:
    old "Yes, sir, how can I help you?"
    new "是的，有什么可以帮助您的？"

translate chinese chinese_2312157_350:
    old "(For real? Is she wearing this?)"
    new "（ seriously? 她穿这个了吗? )"

translate chinese chinese_7596832_351:
    old "Hmmm, I think this package is for you."
    new "嗯，我觉得这个包裹是给你的。"

translate chinese chinese_0321213_352:
    old "(Wow! I know this young man, I met him in church.) "
    new "（哇！我认识这个年轻人，我在教堂见过他。）"

translate chinese chinese_5122049_353:
    old "For me?"
    new "给我？"

translate chinese chinese_3723163_354:
    old "Yes, we had your order record, let me confirm, it is the Ultra short skirt, marvelous night surprise dress."
    new "是的，我们有你的订单记录，让我确认一下，是超短裙，还有奇妙夜晚惊喜礼服。"

translate chinese chinese_2861568_355:
    old "... What? This must be a mistake."
    new "……什么？这一定是搞错了。"

translate chinese chinese_7868924_356:
    old "(Of course is yours, who else could be, has your name on it.)"
    new "（当然归你所有，还能有谁，上面写着你的名字。）"

translate chinese chinese_0226052_357:
    old "It could be, however, you're Mrs. Jones, right?"
    new "不过，你是琼斯太太吧？"

translate chinese chinese_0771939_358:
    old "Yes, that's me..."
    new "是的，那就是我……"

translate chinese chinese_0356702_359:
    old "Well, we have all your information here, and the payment was done online... So..."
    new "嗯，你的信息我们都已经有了，付款也是在线完成的……所以……"

translate chinese chinese_5714041_360:
    old "(Hmm... I need to make up something, he knows me...)"
    new "（嗯……我得编个理由，他知道我的……）"

translate chinese chinese_3249833_361:
    old "Oh! I remembered now, this is for my daughter, I forgot completely, hehehe."
    new "哦！我想起来了，这是给我女儿的，我完全忘了，嘿嘿嘿。"

translate chinese chinese_1707749_362:
    old "Hmm... It's ok, I understand, hope you daughter likes it."
    new "嗯……没关系，我理解，希望你喜欢。"

translate chinese chinese_5083863_363:
    old "Ok... Thank you! Bye bye."
    new "好的……谢谢！再见。"

translate chinese chinese_1993614_364:
    old "It's done!"
    new "搞定了！"

translate chinese chinese_6457148_365:
    old "Awesome, What happened? I wanna know everything."
    new "太好了，发生了什么？我想知道一切。"

translate chinese chinese_4153598_366:
    old "It was ok, gave her the package, that was it."
    new "挺好的，把包裹给了她，就这些。"

translate chinese chinese_8410874_367:
    old "Was she excited about the purchase?"
    new "她对这次购买兴奋吗？"

translate chinese chinese_2837572_368:
    old "Couldn't tell you, she was kind of reserved."
    new "说不上来，她挺内向的。"

translate chinese chinese_6407564_369:
    old "Did you see if she liked it?"
    new "你看她喜欢吗？"

translate chinese chinese_4420480_370:
    old "No, I just gave her the package and she said thank you."
    new "不，我 just 给了她包裹，她说了声谢谢。"

translate chinese chinese_9822181_371:
    old "I need you to pay careful attention to those details in future deliveries. "
    new "我需要你在以后的送货中注意这些细节。"

translate chinese chinese_2712217_372:
    old "What do you mean by future deliveries?"
    new "你说的未来送货是什么意思？"

translate chinese chinese_8363527_373:
    old "I have more merchandise coming so get prepare for another photoshoot session. "
    new "我还有更多的商品要来，准备好再拍一组写真吧。"

translate chinese chinese_4113874_374:
    old "Hmm... All right."
    new "嗯……好吧。"

translate chinese chinese_7091359_375:
    old "Now leave me alone. It's late and I have a lot to do... "
    new "现在让我一个人待会儿。天晚了，我还有很多事情要做……"

translate chinese chinese_8494460_376:
    old "Hey!, You won't believe the great news I have, I am so excited, this is working really well."
    new "嘿！你猜不到我有什么好消息，我兴奋极了，这真的很管用。"

translate chinese chinese_5031812_377:
    old "We have a new customer, she ordered almost the entire website catalogue."
    new "我们有个新客户，她几乎把整个网站目录都订了。"

translate chinese chinese_0617483_378:
    old "Wow, that's great!"
    new "哇，真棒！"

translate chinese chinese_3371655_379:
    old "The order already went through, soooo... I need your help!"
    new "订单已经下了，所以……我需要你的帮助！"

translate chinese chinese_2366125_380:
    old "Let me guess, you want me to make the delivery?"
    new "让我猜猜，你想让我去送吗？"

translate chinese chinese_5791297_381:
    old "Yes, but if you go right now, you won't have to do it later, huh?"
    new "是啊，但如果你现在就去做，以后就不用做了，对吧？"

translate chinese chinese_5257600_382:
    old "Well, it's still me doing the delivery!"
    new "好吧，这仍然是我来完成的！"

translate chinese chinese_6828178_383:
    old "I love how engaged you are, this is why we are growing and growing!"
    new "我爱你的积极参与，这就是我们不断成长的原因！"

translate chinese chinese_6586366_384:
    old "Hmm, alright, I'll do the damn delivery... "
    new "嗯，好吧，我去搞那个该死的送货……"

translate chinese chinese_1500611_385:
    old "Hahaha remember is for the ‘business'."
    new "哈哈，记得这是为了“生意”。"

translate chinese chinese_5154258_386:
    old "Alright, let me know when it's done, see you later."
    new "好的，完了告诉我一声，回头见。"

translate chinese chinese_5626339_387:
    old "(Hmmm I hope it isn't anyone I know like last time.)"
    new "（嗯，希望这次不是我认识的人。）"

translate chinese chinese_6324335_388:
    old "(Alright, is here...)"
    new "（好了，到了这里……）"

translate chinese chinese_1916182_389:
    old "Good morning, how can I help you?"
    new "早上好，有什么可以帮你的？"

translate chinese chinese_7034645_390:
    old "G-good morning, Mrs. Anastasia? Here is your package!"
    new "早上好，安纳斯塔西娅夫人？这是您的包裹！"

translate chinese chinese_9720278_391:
    old "Oh, Thank you so much! So? Are you the business guy behind this?"
    new "哦，太感谢了！那么，你是背后的老板吗？"

translate chinese chinese_6928848_392:
    old "Oh no, this is my [sisrel] business, I'm just helping."
    new "哦不，这是我的[sisrel]生意，我只是帮忙的。"

translate chinese chinese_7244443_393:
    old "That's so sweet, She is very lucky to have a handsome young man like you helping."
    new "真甜，她有个像你这样的帅气小伙子帮忙，真是太幸运了。"

translate chinese chinese_7442986_394:
    old "Thanks... We are trying to get some extra income."
    new "谢谢……我们在努力赚点外快。"

translate chinese chinese_8540987_395:
    old "I like your products, surely I will look forward to knowing more about you guys."
    new "我喜欢你的产品，肯定很期待更多地了解你们。"

translate chinese chinese_1278991_396:
    old "Specially you, sweety."
    new "特别是你，甜心。"

translate chinese chinese_0071647_397:
    old "Hmmm... T-thanks."
    new "嗯……谢谢。"

translate chinese chinese_7268451_398:
    old "My pleasure, see you later sweetheart..."
    new "我的荣幸，待会儿见甜心..."

translate chinese chinese_1888358_399:
    old "(What a nice lady.)"
    new "（真是个不错的女士。）"

translate chinese chinese_5071776_400:
    old "Well, I am back."
    new "好了，我回来了。"

translate chinese chinese_6133427_401:
    old "How was it? I'm kind of busy, but let me know everything."
    new "怎么样？我有点忙，但告诉我详情。"

translate chinese chinese_3713293_402:
    old "She was very interested in the clothes."
    new "她对那些衣服很感兴趣。"

translate chinese chinese_8299675_403:
    old "Great, what did you tell her?"
    new "太好了，你跟她说了什么？"

translate chinese chinese_9467967_404:
    old "The common stuff, you know, I said hello, the information of the delivery."
    new "一些日常的事，你知道的，打了声招呼，说了下送货的信息。"

translate chinese chinese_7688255_405:
    old "She mentioned she will order more."
    new "她提到她会再订购一些。"

translate chinese chinese_0540064_406:
    old "Fantastic, I will need your help next time, so she feels engaged with the purchase."
    new "太好了，下次我需要你的帮助，让她觉得参与了购买过程。"

translate chinese chinese_0817455_407:
    old "Let me continue... I have more and more customers messaging."
    new "让我继续……我收到的顾客消息越来越多了。"

translate chinese chinese_9417702_408:
    old "Sure, you are very welcome!"
    new "当然，非常欢迎！"

translate chinese chinese_3032983_409:
    old "You ready for the pics? I've been waiting for you."
    new "准备好看照片了吗？我等你好久了。"

translate chinese chinese_3969431_410:
    old "Oh right, I'm going for the camera, I'll see you in your bedroom."
    new "哦对了，我去拿相机，卧室见。"

translate chinese chinese_6899504_411:
    old "(Holy shit!)"
    new "（天啊！）"

translate chinese chinese_0671266_412:
    old "Finally, I have good ideas for today's session."
    new "终于，我今天有了好主意。"

translate chinese chinese_4439710_413:
    old "What do you think? Do I look beautiful?"
    new "你觉得呢？我看起来漂亮吗？"

translate chinese chinese_5792172_414:
    old "Gulp... (Wow, she is really hot) I think you look very... N-nice."
    new "咽了口唾沫……（天，她真的好辣）我觉得你看起来很……嗯，不错。"

translate chinese chinese_8289111_415:
    old "Great... But, before we start do you think, you need any... Help?"
    new "好吧……不过，在开始之前，你觉得你需要一些……帮助吗？"

translate chinese chinese_1629862_416:
    old "What do you mean? I have the camera and everything..."
    new "你的意思是什么？我有相机什么的……"

translate chinese chinese_0208005_417:
    old "I mean if you need to 'relax' before we start..."
    new "我是说如果你需要在开始前‘放松’一下……"

translate chinese chinese_9105213_418:
    old "I-I don't understand..."
    new "我我听不懂……"

translate chinese chinese_3376901_419:
    old "I mean, don't be flushed I know you got hard last time and is totally normal..."
    new "我的意思是，别紧张，我知道上次你兴奋了，这完全正常……"

translate chinese chinese_7629441_420:
    old "It's because of the clothes I'm wearing, I think it's fair, you know, you help me, I can help you too and I already did, didn't I?"
    new "是因为我穿的衣服，我觉得这样公平，你知道的，你帮我，我也能帮你，我已经帮过你了，不是吗？"

translate chinese chinese_1939847_421:
    old "I'm not sure if it's okay..."
    new "我不确定这样好不好……"

translate chinese chinese_7071780_422:
    old "Oh come on, you're not going to take good pictures if you're hard the whole session..."
    new "哦拜托，如果你全程都硬着，肯定拍不出好照片..."

translate chinese chinese_3736358_423:
    old "It's because of business, remember?"
    new "是因为生意，记得吗？"

translate chinese chinese_8474784_424:
    old "Great, take off your pants I'm going to suck you off..."
    new "好的，脱了裤子，我要给你口交..."

translate chinese chinese_0200219_425:
    old "W-WHAT?! Are you going to suck-..."
    new "W-WHAT?! 你要吸..."

translate chinese chinese_3312312_426:
    old "Well... You did a great job with the deliveries, I think you deserve a reward, don't you think?"
    new "嗯……你送东西做得很好，我觉得你应该得到奖励，不是吗？"

translate chinese chinese_1803482_427:
    old "By the way, I'll have to take off my clothes, just to be sure I don't stain the clothes for the photos..."
    new "对了，我得脱掉衣服，确保拍照的时候不会弄脏衣服……"

translate chinese chinese_9934596_428:
    old "Does it bother you?"
    new "这让你不舒服吗？"

translate chinese chinese_5520699_429:
    old "Hahaha you will love it..."
    new "哈哈哈哈哈你会喜欢的..."

translate chinese chinese_8426932_430:
    old "I hope you are relaxed now, so let's do it!"
    new "希望你现在放松了，那我们开始吧！"

translate chinese chinese_6386324_431:
    old "You think this way it looks good?"
    new "你觉得这样看起来好看吗？"

translate chinese chinese_5608052_432:
    old "Absolutely."
    new "绝对。"

translate chinese chinese_1958257_433:
    old "Let me be sure the skirt stands out. I will take a pic of entire clothes."
    new "让我确保裙子突出一点。我拍张全身的照片。"

translate chinese chinese_3026952_434:
    old "Yes, let's do the next one from another position."
    new "好的，下一个换个姿势。"

translate chinese chinese_3346486_435:
    old "Great! I saw one I want to try."
    new "太好了！我看到一个想试试的。"

translate chinese chinese_3263593_436:
    old "Sure, what do you have on mind?"
    new "行，你有什么想法？"

translate chinese chinese_9984884_437:
    old "I want to take some pics on the bed."
    new "我想在床上拍些照片。"

translate chinese chinese_7111995_438:
    old "Well, we haven't done anything like that before. Let's do it!"
    new "嗯，我们之前还没做过这种事呢。来吧！"

translate chinese chinese_9882388_439:
    old "Lay down on the bed but leave the legs out of the bed so we can see your butt."
    new "躺在床上，但把腿留在外面，好让我们能看到你的屁股。"

translate chinese chinese_6880771_440:
    old "Nicee."
    new "不错哦。"

translate chinese chinese_7743936_441:
    old "I hope it looks sexy."
    new "希望看起来很性感。"

translate chinese chinese_9767897_442:
    old "(Holy shit...) I-I am sure you're gonna love these."
    new "（卧槽……）我我确信你会喜欢这些的。"

translate chinese chinese_5912574_443:
    old "But let me try to catch a bit more, your legs must look huge."
    new "但是让我再试试，你的腿肯定很大。"

translate chinese chinese_8128426_444:
    old "I think I have it."
    new "我觉得我搞定了。"

translate chinese chinese_2540957_445:
    old "Ok, for the next picture I need you to turn around please, I want to try an option like the last time but slightly different."
    new "好的，下一张照片请你转个身，我想试试上次那种角度，但稍微有点不同。"

translate chinese chinese_1117961_446:
    old "Do not look at the camera and try to lift a bit more your butt, hold your hair with one hand."
    new "不要看镜头，把屁股再抬高一点，用手撩起头发。"

translate chinese chinese_9409252_447:
    old "Ohh, I like it!"
    new "哦，我喜欢！"

translate chinese chinese_0123773_448:
    old "It's perfect."
    new "太完美了。"

translate chinese chinese_5475121_449:
    old "Ok, I think we are done."
    new "好了，我觉得我们可以结束了。"

translate chinese chinese_6262474_450:
    old "Awesome!!! Let me see them!"
    new "太棒了！！！让我看看！"

translate chinese chinese_5946671_451:
    old "Ok... Gallery... Done"
    new "好的……画廊……完成"

translate chinese chinese_5932299_452:
    old "I do not know what's happening today, these photos are not sharp enough."
    new "我今天也不知道怎么回事，这些照片不够清晰。"

translate chinese chinese_1680123_453:
    old "We will need to try again, this material is important. "
    new "我们需要再试一次，这个材料很重要。"

translate chinese chinese_7858207_454:
    old "Yes, I am sure we can make it a lot better."
    new "是的，我确信我们可以让它变得好多了。"

translate chinese chinese_4110264_455:
    old "I just need to practice more."
    new "我 just 需要多练习一下。"

translate chinese chinese_0072272_456:
    old "I need you to put more effort, we can't keep wasting time like this."
    new "你需要更努力一点，我们不能继续这样浪费时间。"

translate chinese chinese_3817370_457:
    old "It won't happen again!"
    new "这种事情不会再发生了！"

translate chinese chinese_3880963_458:
    old "Wow, we're on fire!"
    new "哇，我们状态真好！"

translate chinese chinese_9695299_459:
    old "Look at me, so hot. I like your job and I'm not talking about the pics only."
    new "看看我，这么性感。我喜欢你的工作，我说的不只是照片。"

translate chinese chinese_4477254_460:
    old "We are doing a great job."
    new "我们干得不错。"

translate chinese chinese_4078130_461:
    old "Yes, everyday I have more customers, you're a big help."
    new "是的，每天顾客都越来越多，你帮了大忙了。"

translate chinese chinese_9531160_462:
    old "I will go ahead to upload this content on the website."
    new "我会先把这个内容上传到网站上。"

translate chinese chinese_5180827_463:
    old "Ok, bye."
    new "好的，再见。"

translate chinese chinese_5786902_464:
    old "Hey, now that you are here, do you remember Mrs Anastasia? Well, she placed another order, it was mostly the last ones we took pics of!"
    new "嘿，既然你在这里，你还记得安纳斯塔西娅夫人吗？她又下了一个订单，大部分是我们上次拍的那些！"

translate chinese chinese_4679105_465:
    old "Need you to be really nice with her, I'm sure, she will buy anything we post later!"
    new "你需要对她特别好，我相信，她以后会买我们发布的任何东西！"

translate chinese chinese_2656506_466:
    old "So you better give her amazing customer service, don't want you to mess things up with her."
    new "所以你最好给她提供优质的服务，别把事情搞砸了。"

translate chinese chinese_3010840_467:
    old "Ok... I'll go right away."
    new "好……我马上就去。"

translate chinese chinese_6971040_468:
    old "Don't forget to be really kind, she is a very important client."
    new "别忘了要非常客气，她是个非常重要的人物。"

translate chinese chinese_7552315_469:
    old "Yes, yes, I know!"
    new "是的是的，我知道！"

translate chinese chinese_0256086_470:
    old "Good morning Mrs, I have another package for you!"
    new "早上好，夫人，我又有一个包裹给您！"

translate chinese chinese_6159126_471:
    old "Oh, it's you again, you came really fast, Thank you very much!"
    new "哦，又是你，你来得好快，真是太感谢了！"

translate chinese chinese_7834358_472:
    old "We really appreciate your purchase."
    new "我们真的很感谢你的购买。"

translate chinese chinese_0707644_473:
    old "I do appreciate how much of a gentleman you are."
    new "我真的很欣赏你的绅士风度。"

translate chinese chinese_8622474_474:
    old "Hmmm, thank you... Uhh this is your package."
    new "嗯，谢谢…… uh 这是你的包裹。"

translate chinese chinese_7571810_475:
    old "Thank you sweety!"
    new "谢谢你，甜心！"

translate chinese chinese_9566415_476:
    old "You know what? you deserve a tip."
    new "你知道吗？你值得打赏。"

translate chinese chinese_9920709_477:
    old "Oh please don't worry..."
    new "哦，请别担心……"

translate chinese chinese_4970570_478:
    old "Give me just a second, your kindness deserves compensation."
    new "给我一秒，你的善良值得补偿。"

translate chinese chinese_2557493_479:
    old "It's not necessary, I am very glad to bring your package."
    new "不用了，我很乐意给你送包裹。"

translate chinese chinese_5500325_480:
    old "Do not dare to leave!"
    new "敢离开试试！"

translate chinese chinese_5069080_481:
    old "I beg your pardon... Can't find my purse."
    new "对不起……我找不到我的钱包了。"

translate chinese chinese_6948416_482:
    old "Do not worry, it's not a problem."
    new "别担心，这没问题。"

translate chinese chinese_8387080_483:
    old "Oh no, you deserve it."
    new "哦不，你活该。"

translate chinese chinese_3809304_484:
    old "Let me see if I could have something here... Hope you like it."
    new "让我看看这里有没有什么东西……希望你会喜欢。"

translate chinese chinese_0157459_485:
    old "(Wow) ..."
    new "（哇）..."

translate chinese chinese_2962970_486:
    old "(He's so shy... Hehehe, can't even speak.)"
    new "（他好害羞啊……嘿嘿，连话都说不出来。）"

translate chinese chinese_2690379_487:
    old "Gulp, tha-... Thank you."
    new "gulp, tha-... 谢谢。"

translate chinese chinese_7997894_488:
    old "Hehehe, You are kind of tender."
    new "嘿嘿嘿，你还挺温柔的。"

translate chinese chinese_0533856_489:
    old "I hope I can see you next time, I'll have cash handy. Bye handsome!"
    new "希望下次还能见到你，我到时候会带现金的。再见 handsome！"

translate chinese chinese_1315072_490:
    old "Was everything alright?"
    new "一切都好吗？"

translate chinese chinese_9863076_491:
    old "Definitely, she is amazing!"
    new "没错，她真的很棒！"

translate chinese chinese_9210149_492:
    old "(Amazing?) Hmm ok, thank you!"
    new "（Amazing?）嗯，好的，谢谢！"

translate chinese chinese_0235773_493:
    old "Does she like the products."
    new "她喜欢这些产品吗？"

translate chinese chinese_2166912_494:
    old "She seemed to be very interested about the new products."
    new "她似乎对新产品很感兴趣。"

translate chinese chinese_5490024_495:
    old "That's fascinating."
    new "真有意思。"

translate chinese chinese_6495958_496:
    old "Hope you are doing your part, so she definitely keeps her business with us."
    new "希望你能尽好自己的部分，让她肯定继续和我们合作。"

translate chinese chinese_6037751_497:
    old "Besides, I need you to get prepared, we have more products coming."
    new "再说，我需要你准备好，我们还有更多的产品要来。"

translate chinese chinese_2726709_498:
    old "Yes, we need to work hard."
    new "没错，我们需要努力工作。"

translate chinese chinese_7632895_499:
    old "Uhh, let's see what happens."
    new "嗯，看看会发生什么吧。"

translate chinese chinese_6288104_500:
    old "You can be sure it's worth."
    new "你可以肯定这值得。"

translate chinese chinese_9102160_501:
    old "Come on [pla]! Time is money and you're late, let's go to the pool."
    new "快点，[pla]！时间就是金钱，你已经迟到了，我们去游泳池吧。"

translate chinese chinese_2215279_502:
    old "To the p-pool?"
    new "去泳池？"

translate chinese chinese_8173997_503:
    old "Yep, the pool. Summer is coming, bikinis are amazing so I need all your effort today."
    new "对，就是游泳池。夏天来了，比基尼超赞的，所以今天需要你全力配合。"

translate chinese chinese_3101507_504:
    old "We are selling new things and people are crazy with the new summer alternatives."
    new "我们正在推出新品，大家对新的夏季选择疯狂不已。"

translate chinese chinese_3427391_505:
    old "Do you need some help before we start?"
    new "我们在开始前需要帮忙吗？"

translate chinese chinese_3894805_506:
    old "I mean do you want me to suck your dick, because at the pool it's not that easy. "
    new "我是说你想让我吸你的 dicks 吗，因为在这里可没那么容易。"

translate chinese chinese_9042991_507:
    old "And don't beat around the bush!"
    new "别绕圈子！"

translate chinese chinese_1688213_508:
    old "I-I am not sure."
    new "我——我不太确定。"

translate chinese chinese_7469501_509:
    old "Do you want it or not?"
    new "你要还是不要？"

translate chinese chinese_8944670_510:
    old "We don't have time to lose I will take it as a yes..."
    new "我们没时间浪费了，我就当你是同意了..."

translate chinese chinese_9454442_511:
    old "I'm going to make you cum fast..."
    new "我要让你很快就射..."

translate chinese chinese_9247582_512:
    old "I hope you're better now, let's do it!"
    new "希望你现在感觉好些了，我们开始吧！"

translate chinese chinese_6316472_513:
    old "Oh, I will love the pics today, look at the sun, the pool, everything in its right place."
    new "哦，今天的照片一定会很棒，看看太阳，游泳池，一切都恰到好处。"

translate chinese chinese_2027380_514:
    old "Yeah I couldn't ask for a better light and place."
    new "是的，我再也找不到比这更好的光线和地方了。"

translate chinese chinese_8698289_515:
    old "Don't lose more time, let's start."
    new "别浪费时间了，我们开始吧。"

translate chinese chinese_7495105_516:
    old "You're right. Stay right there, let me start with a full body!"
    new "你说得对。别动，让我来个全身的！"

translate chinese chinese_8715172_517:
    old "Ok, I will stay like this."
    new "好吧，我就这样吧。"

translate chinese chinese_0116915_518:
    old "I think you should look to the right, to get a better perspective..."
    new "我觉得你应该往右边看看，这样能有更好的视角……"

translate chinese chinese_8997859_519:
    old "Alright, you are the nerd..."
    new "好吧，你是那个书呆子..."

translate chinese chinese_0523806_520:
    old "Wonderful, the light is perfect, your hair looks very bright."
    new "太棒了，光线正好，你的头发看起来很亮。"

translate chinese chinese_5090702_521:
    old "Perfect, make sure I look sexy."
    new "完美，确保我看起来性感。"

translate chinese chinese_9058597_522:
    old "Got it!"
    new "收到！"

translate chinese chinese_5812215_523:
    old "It would be more interesting if we take advantage of some elements of the place."
    new "如果我们利用一下这里的某些元素会更有趣。"

translate chinese chinese_5552667_524:
    old "Hmmm, what do you think about the pool?"
    new "嗯，你觉得游泳池怎么样？"

translate chinese chinese_9946936_525:
    old "I don't think so, we need the clothes dry."
    new "我不这么认为，我们需要衣服干才行。"

translate chinese chinese_3340659_526:
    old "You now what? Go to the chair, something casual, let's use those glasses you have."
    new "你知道吗？去椅子那边，穿得随意点，把你的那副眼镜拿来用用。"

translate chinese chinese_0847551_527:
    old "Yes, just like that, that's perfect."
    new "对，就是这样，perfect."

translate chinese chinese_6948051_528:
    old "Perfect, try to hold the glasses with your hands."
    new "完美，试着用手拿着眼镜。"

translate chinese chinese_5835574_529:
    old "Try to show my boobs a bit more, I want them to stand out."
    new "试着多露出一点胸部，我想让它们更抢眼一些。"

translate chinese chinese_2599755_530:
    old "I think this is the pic you're looking for."
    new "我觉得这就是你要找的照片。"

translate chinese chinese_8583682_531:
    old "Ok, next photo..."
    new "好的，下一张……"

translate chinese chinese_6780284_532:
    old "I have a great idea, let's show a different emotion."
    new "我有个好主意，让我们展示一种不同的情绪。"

translate chinese chinese_0111856_533:
    old "I am listening..."
    new "我在听..."

translate chinese chinese_1734657_534:
    old "Let's take advantage of the pool but I don't want the same poses we already tried before, I want to do something unexpected."
    new "我们来利用一下泳池吧，但是我不想再做之前试过的姿势，我想做一些出乎意料的事情。"

translate chinese chinese_5719397_535:
    old "Hmm, turn around and try to look at me, but close your eyes..."
    new "嗯，转过身去，试着看着我，但是闭上眼睛……"

translate chinese chinese_8278096_536:
    old "With my eyes closed? Alright, let me try it."
    new "闭上眼睛吗？好吧，让我试试。"

translate chinese chinese_4300031_537:
    old "keep that smile, do not change your face."
    new "保持那个微笑，不要改变表情。"

translate chinese chinese_7556583_538:
    old "That's a plot twist."
    new "这是个剧情反转。"

translate chinese chinese_2220127_539:
    old "I like it."
    new "我喜欢。"

translate chinese chinese_3509081_540:
    old "Ok, I think that's it."
    new "好吧，我想就这些了。"

translate chinese chinese_7317195_541:
    old "Ok... Here they are."
    new "好……在这里。"

translate chinese chinese_7403737_542:
    old "I don't know what's happening today, they are not sharp enough."
    new "今天不知道怎么回事，他们不够利索。"

translate chinese chinese_9571571_543:
    old "I need you to put more effort, we can't waste time like today."
    new "你需要更努力一点，不能再像今天这样浪费时间了。"

translate chinese chinese_6298102_544:
    old "Hmm, look for me to repeat the sesion again..."
    new "嗯，希望我能再重复一次这个环节..."

translate chinese chinese_6229550_545:
    old "I like them, but there's something not working."
    new "我喜欢它们，但总觉得有点不对劲。"

translate chinese chinese_4823999_546:
    old "What's not working? I can check, so you like them more."
    new "什么不好用？我可以检查一下，让你更喜欢它们。"

translate chinese chinese_2916979_547:
    old "Oh no, it's not you, I need some sunbathing."
    new "哦不，不是你，我需要晒晒太阳。"

translate chinese chinese_8760673_548:
    old "Don't you think so?"
    new "你不这么认为吗？"

translate chinese chinese_4022051_549:
    old "I think you look great."
    new "我觉得你看起来很棒。"

translate chinese chinese_6383036_550:
    old "Hehehe of course... "
    new "嘿嘿嘿，当然了……"

translate chinese chinese_7957105_551:
    old "Anyway, I'm going work on the website, have a good one."
    new "总之，我要去弄网站了，再见。"

translate chinese chinese_4039028_552:
    old "Glad that you came, quite on time to apply my sunscreen, can you help me?"
    new "很高兴你来了，正好帮我涂防晒霜，能帮帮我吗？"

translate chinese chinese_3572879_553:
    old "I can show you how to do it... Let's start with my boobs."
    new "我可以教你怎么做……就从我的胸部开始吧。"

translate chinese chinese_2817978_554:
    old "Your... Wh- What?"
    new "你……什么？"

translate chinese chinese_5397332_555:
    old "My boobs, I need to show the bikinis, so my boobs are important. And you see them all the time in the photoshoots."
    new "我的胸部，我要穿比基尼，所以胸部很重要。而且你在拍摄时总是能看到它们。"

translate chinese chinese_9342628_556:
    old "Hmmm... Alright..."
    new "嗯……好吧……"

translate chinese chinese_7227970_557:
    old "Wow! What are you doing?"
    new "哇！你在干什么？"

translate chinese chinese_7397684_558:
    old "Taking off my bra, you weren't pretending to tan my breasts with it on, did you?"
    new "我把胸罩脱了，你刚才不是假装给我晒胸吗？"

translate chinese chinese_7226986_559:
    old "So you want me to apply the sunscreen like thi-"
    new "所以你想让我像这样涂防晒霜？"

translate chinese chinese_7783945_560:
    old "Oh, shut up... You and I both know you're dying to touch them..."
    new "哦，闭嘴吧……你我都知道你巴不得能摸一摸……"

translate chinese chinese_5676809_561:
    old "And I just want a good massage and sunbathe to get a tan."
    new "我只是想要好好按摩一下，然后晒晒太阳变晒成古铜色。"

translate chinese chinese_9987204_562:
    old "So stop acting like an idiot and play with my babies..."
    new "所以别装白痴了，跟我家宝宝玩玩..."

translate chinese chinese_9699379_563:
    old "Do you want more, [pla]?"
    new "你还想要更多吗，[pla]？"

translate chinese chinese_4333194_564:
    old "Don't try to hide it from me... I know you're hard already."
    new "别想瞒我……我知道你已经硬了。"

translate chinese chinese_3409423_565:
    old "I-I don't know what you mea-"
    new "我我我不知道你在说什"

translate chinese chinese_2373052_566:
    old "Let me give you a clue... I've heard cum is a great treatment for the skin, so I wanted to test it on my boobs."
    new "让我给你个提示……我听说精液对皮肤很好，所以我想在我的胸部试试看。"

translate chinese chinese_8163582_567:
    old "W-What!?... "
    new "什、什么！？..."

translate chinese chinese_7439109_568:
    old "Shut up and come here..."
    new "闭嘴过来……"

translate chinese chinese_2434444_569:
    old "Did you enjoy it?"
    new "你觉得怎么样？"

translate chinese chinese_1424470_570:
    old "Yeah!"
    new "yeah!"

translate chinese chinese_9573524_571:
    old "I would love to have this skin care therapy more often."
    new "我真希望可以更经常做这种护肤疗法。"

translate chinese chinese_6381443_572:
    old "I'll enjoy the sun, thank you."
    new "谢谢，我会享受阳光的。"

translate chinese chinese_9386368_573:
    old "You're welcome, see you later!"
    new "不客气，再见！"

translate chinese chinese_5185932_574:
    old "Oh, you came at the right time."
    new "哦，你来得正好。"

translate chinese chinese_0959385_575:
    old "Fortunately there is good news, I want to tell you something to cheer you up a bit."
    new "幸好有个好消息，我想告诉你一些事情让你高兴一点。"

translate chinese chinese_6017365_576:
    old "The bikini session was great, Anastasia ordered again."
    new "比基尼拍摄很棒，安娜斯塔西娅又下单了。"

translate chinese chinese_3716294_577:
    old "I need you to be nice with her again, so she feels comfortable."
    new "我需要你再对她好一点，让她感到舒服。"

translate chinese chinese_2374893_578:
    old "Ok, I will."
    new "好的，我会的。"

translate chinese chinese_3431578_579:
    old "You already know her place, remember, that everything you do is really important."
    new "你已经知道她的底细了，记住，你所做的每件事都非常重要。"

translate chinese chinese_1806484_580:
    old "Good morning Mrs."
    new "早上好，夫人。"

translate chinese chinese_5647465_581:
    old "Oh what a nice surprise, It's my favorite delivery boy!"
    new "哦，真是个惊喜，是我的最爱送货男孩！"

translate chinese chinese_4737804_582:
    old "Hehehe, Thank you, I am glad to see you too."
    new "嘿嘿嘿，谢谢，我也很高兴见到你。"

translate chinese chinese_6896168_583:
    old "Here you are!"
    new "给你！"

translate chinese chinese_8039547_584:
    old "Thank you, you're so kind."
    new "谢谢你，真体贴。"

translate chinese chinese_2966512_585:
    old "I hope you enjoy your purchase, have a nice day!"
    new "希望您满意购买的商品，祝您有美好的一天！"

translate chinese chinese_2927973_586:
    old "Oh, are you planning on leaving already? Actually I was considering to ask you for a big favor and I have nobody else to help me."
    new "哦，你打算这么快就走吗？其实我正想请你帮个大忙，而且除了你没人能帮我。"

translate chinese chinese_9104149_587:
    old "I think since you're a man you could help me."
    new "我觉得既然你是男人，应该能帮到我。"

translate chinese chinese_0426318_588:
    old "(I have to make her feel comfortable, she's our best client.)"
    new "（我得让她感到舒服些，她是我们的大客户。）"

translate chinese chinese_2587402_589:
    old "It won't take you too long, I promise."
    new "不会花太长时间的，我保证。"

translate chinese chinese_3459715_590:
    old "Oh, sure, how can I help you?"
    new "哦，当然，你需要我怎么帮忙？"

translate chinese chinese_7860086_591:
    old "Please come in."
    new "请进。"

translate chinese chinese_7180192_592:
    old "Just wait a second, I will be right back."
    new "等一下，我马上回来。"

translate chinese chinese_9806217_593:
    old "(Wow, Wow!)"
    new "（哇，哇！）"

translate chinese chinese_7719036_594:
    old "I needed a second opinion, and I just thought you could help."
    new "我需要第二个意见，只是觉得你能帮上忙。"

translate chinese chinese_4788159_595:
    old "Please be honest, do you like it?"
    new "老实说，你喜欢吗？"

translate chinese chinese_6517434_596:
    old "Gulp, You look..."
    new "gulp, 你看起来..."

translate chinese chinese_8434099_597:
    old "No, no, no, of course not, You look... A-amazing."
    new "不，不，当然不，你看起来……棒极了。"

translate chinese chinese_4550877_598:
    old "Y-Yes... I- I am being really honest."
    new "是的……我真的很坦白。"

translate chinese chinese_4917339_599:
    old "(Oh shit... I'm getting hard.)"
    new "（哦shit...我硬了。）"

translate chinese chinese_7789099_600:
    old "Wow dear, what you got in there?"
    new "wow 宝贝，你里面装的是什么？"

translate chinese chinese_6902813_601:
    old "I'm sorry, I didn't mean to-"
    new "对不起，我不是故意要——"

translate chinese chinese_6360981_602:
    old "Ohh, You are very sweet, I apologize for this, I didn't mean to make you feel uncomfortable."
    new "哦，你真甜，我道歉，我没想让你感到不舒服的。"

translate chinese chinese_7158090_603:
    old "I-I am sorry, I-I... Just should leave."
    new "我、我很抱歉，我、我……还是离开吧。"

translate chinese chinese_7357639_604:
    old "Oh no, please let me apologize correctly, you can't leave like that."
    new "哦不，让我好好道歉吧，你不能这样离开。"

translate chinese chinese_6673629_605:
    old "I think you deserve a bigger tip this time due to this big inconvenience."
    new "我觉得这次因为这么大的不便，你应该得到更多的小费。"

translate chinese chinese_8222687_606:
    old "How about if you just relax a little bit on the couch and let me fix this with my own hands. "
    new "要不你就在沙发上放松一下，让我亲手来解决这个问题。"

translate chinese chinese_7858273_607:
    old "Please, relax and let me compensate for the situation, just close your eyes and enjoy."
    new "请放松点，让我来弥补这个情况，闭上眼睛享受就好。"

translate chinese chinese_4114508_608:
    old "I hope you liked it..."
    new "希望你喜欢……"

translate chinese chinese_6766499_609:
    old "Uhh... Y-yes, thank you"
    new "呃……是的，谢谢"

translate chinese chinese_7936205_610:
    old "Alright sweetie, thanks for your help, it was very clear to me that this bikini suits me very well... I hope to see you in my next delivery."
    new "好吧甜心，谢谢你帮忙，我清楚地知道这款比基尼很适合我……希望下次送货还能见到你。"

translate chinese chinese_9761155_611:
    old "(Wow, I'm starting to love this job)"
    new "（哇，我开始喜欢这份工作了）"

translate chinese chinese_9926208_612:
    old "Of course, I'll bring your next purchase."
    new "当然，我会带上你的下次购买的东西。"

translate chinese chinese_9236943_613:
    old "That sounds great..."
    new "听起来不错……"

translate chinese chinese_0757262_614:
    old "Hey, you are back."
    new "嘿，你回来了。"

translate chinese chinese_8033932_615:
    old "Yep."
    new "没错。"

translate chinese chinese_6667694_616:
    old "So? Everything went alright?"
    new "怎么样？一切都顺利吗？"

translate chinese chinese_0356310_617:
    old "It was... Wonderful."
    new "那真是……美妙极了。"

translate chinese chinese_3619576_618:
    old "(Wonderful?) Hmm, ok thanks for your help."
    new "（棒极了？）嗯，好吧，谢谢你的帮助。"

translate chinese chinese_9749784_619:
    old "Did she like it?"
    new "她喜欢吗？"

translate chinese chinese_7009800_620:
    old "Yeah, she loved it."
    new "是的，她很喜欢。"

translate chinese chinese_8426014_621:
    old "How are you so sure about it?"
    new "你怎么这么确定？"

translate chinese chinese_1943177_622:
    old "Well... Is the second time she purchases, so she liked the first one."
    new "嗯……这是她第二次购买了，所以她应该喜欢第一个。"

translate chinese chinese_1096372_623:
    old "Ok... I'll let you know once we are ready for the next photography session."
    new "好的……等我们准备好下次摄影 session 时我会通知你。"

translate chinese chinese_8893816_624:
    old "I'll look forward to it."
    new "我期待着。"

translate chinese chinese_9157409_625:
    old "Uhh... I am so horny, I'll need more."
    new "呃……我好 horny，我要更多。"

translate chinese chinese_1542407_626:
    old "(Oh shit... She saw me!)"
    new "（哦shit... 她看到我了！）"

translate chinese chinese_7164288_627:
    old "I know you have been there for a while."
    new "我知道你在那里待了一段时间了。"

translate chinese chinese_3889358_628:
    old "Sorry... I-I was just-"
    new "对不起……我我只是-"

translate chinese chinese_5023540_629:
    old "It's ok dummy! I think it is time to get paid back."
    new "别担心笨蛋！我觉得是时候讨回了。"

translate chinese chinese_4478231_630:
    old "I mean, I need you to pay me back, I know that you have more than enough to give."
    new "我的意思是，你需要还我钱，我知道你有的是钱。"

translate chinese chinese_1037468_631:
    old "Come here, let me suck that big dick."
    new "过来，让我吸那大鸡巴。"

translate chinese chinese_2959719_632:
    old "Grab my head and fuck my mouth!"
    new "抓住我的头，操我的嘴！"

translate chinese chinese_6002211_633:
    old "Oh, shit. I can't handle it anymore... Want you to fuck me, I need you inside of me now."
    new "哦，shit。我再也受不了了……想要你 fucks 我，我现在需要你在里面。"

translate chinese chinese_5219551_634:
    old "Come here and fuck your [sisrel]... Fuck me hard [pla]!"
    new "过来操你的[sisrel]... 劲点操我[pla]！"

translate chinese chinese_0009945_635:
    old "Wow, you did great!"
    new "哇，你做得真好！"

translate chinese chinese_9725406_636:
    old "Ugh, I got really tired, that was pretty intense."
    new "哎，我真的很累了，那真是挺激烈的。"

translate chinese chinese_0955615_637:
    old "Anyway, I'm gonna need some of your skills tomorrow too."
    new "不管怎样，明天我也需要你的技能。"

translate chinese chinese_0254558_638:
    old "Hahaha, I'm talking about the photshoot, dummy. I'm preparing a new one, so, I count on you."
    new "哈哈，我说的是摄影棚，傻瓜。我正在准备一个新的，所以就靠你了。"

translate chinese chinese_1914565_639:
    old "Sure, I'll be ready."
    new "行，我会准备好的。"

translate chinese chinese_7209123_640:
    old "Now leave me alone. I just want to rest..."
    new "现在让我一个人待会儿。我只是想休息一下……"

translate chinese chinese_2995331_641:
    old "Hmm, alright... See you later."
    new "嗯，好吧……回头见。"

translate chinese chinese_8448939_642:
    old "Hey, did you sleep well?"
    new "嘿，睡得好吗？"

translate chinese chinese_5370045_643:
    old "Yeah, pretty well!"
    new "嗯，还不错！"

translate chinese chinese_4224979_644:
    old "Good, that means we're gonna rock today!"
    new "好，那就意味着今天我们能嗨起来了！"

translate chinese chinese_9740869_645:
    old "I will be at the pool, don't be late."
    new "我在游泳池等你，不要迟到。"

translate chinese chinese_3553576_646:
    old "I'm going to pick up the camera and see you there."
    new "我拿着相机过去找你。"

translate chinese chinese_6107081_647:
    old "This is the newest collection, what do you think?"
    new "这是最新的系列，你觉得怎么样？"

translate chinese chinese_7466517_648:
    old "Really? It's pretty nice!"
    new "真的吗？挺不错的呀！"

translate chinese chinese_6166248_649:
    old "I have some ideas for today."
    new "我今天有些想法。"

translate chinese chinese_3546603_650:
    old "Awesome, what are we waiting for?"
    new "太好了，我们在等什么？"

translate chinese chinese_6525476_651:
    old "Ok, let's start with you standing up in front of the pool for a full body one."
    new "好的，那你先站在泳池前，来一张全身的。"

translate chinese chinese_4598425_652:
    old "Ok, do I look good like this?"
    new "好啦，我这样看起来怎么样？"

translate chinese chinese_5154902_653:
    old "Yeah, keep your hand there, do not move... It looks more fancy."
    new "嗯，手就放在那里，不要动……这样看起来更性感。"

translate chinese chinese_9602818_654:
    old "Now I want try something special."
    new "现在我想试试特别的东西。"

translate chinese chinese_2835311_655:
    old "Tell me what to do."
    new "告诉我该怎么做。"

translate chinese chinese_5760462_656:
    old "Please get on your knees, looking at me very very enticingly and to move your shoulders a bit ahead of your body..."
    new "请跪下来，用非常非常诱人的目光看着我，然后让你的肩膀稍微向前倾..."

translate chinese chinese_4206494_657:
    old "Do you like it this way?"
    new "你喜欢这样吗？"

translate chinese chinese_4055791_658:
    old "Oh boy, this is by far one of the best ones."
    new "哦买噶，这绝对是其中一个最好的。"

translate chinese chinese_5282443_659:
    old "Hmm I think would be great another one on the floor, but you turning around."
    new "嗯，我觉得再来一个在地上的好，不过你要转个身。"

translate chinese chinese_5511485_660:
    old "Alright, but what kind of position should I do?"
    new "好吧，但我要做哪种姿势？"

translate chinese chinese_4879955_661:
    old "Let's see if we can make it a bit hotter..."
    new "看看能不能再热一点……"

translate chinese chinese_3424646_662:
    old "Try to spread a bit your legs... And look at the camera. Also lift up your butt a bit more but try to keep your breast lower."
    new "试着把腿张开一点……然后看着镜头。再把屁股抬高一点，但尽量让你的胸部低一点。"

translate chinese chinese_5397577_663:
    old "Hmm, let me try."
    new "嗯，让我试试。"

translate chinese chinese_8005098_664:
    old "Oh perfect! let me take the picture."
    new "哦，太好了！让我来拍照。"

translate chinese chinese_6962913_665:
    old "This looks amazing."
    new "这看起来棒极了。"

translate chinese chinese_8930966_666:
    old "Ok, I really think we are done..."
    new "好吧，我真的觉得我们该结束了……"

translate chinese chinese_2891178_667:
    old "Really? Yayyy! let me see them."
    new "真的吗？太棒了！让我看看它们。"

translate chinese chinese_3987967_668:
    old "Of course..."
    new "当然……"

translate chinese chinese_8151047_669:
    old "I do not know what's happening today, they are not sharp enough."
    new "我今天也不知道怎么回事，他们不够尖。"

translate chinese chinese_7584172_670:
    old "Hmm, again with that..."
    new "哼，又是这个……"

translate chinese chinese_3215368_671:
    old "Hahaha, You did it well nerd."
    new "哈哈，干得好，书呆子。"

translate chinese chinese_6491825_672:
    old "Anyway, I'm going to upload more material, I need to sell."
    new "反正我要上传更多素材，我得赚钱。"

translate chinese chinese_9979953_673:
    old "Oh by the way... I'm considering bringing some sexy friends so we can make pics with new models."
    new "对了……我打算带些性感的朋友过来，这样我们可以用新模特拍些照片。"

translate chinese chinese_5263086_674:
    old "It would help us get everybody's attention and it means more sales, more money."
    new "这能帮我们吸引大家的注意，意味着更多的销量，更多的钱。"

translate chinese chinese_2842438_675:
    old "Sure, you are gonna like it!"
    new "肯定的，你会喜欢的！"

translate chinese chinese_9193371_676:
    old "Well time is money, see you around..."
    new "时间就是金钱，改天见..."

translate chinese chinese_0342318_677:
    old "New models, uh?"
    new "新模型啊？"

translate chinese chinese_5467924_678:
    old "Well you're on time, wanna have fun? I need help with my sunscreen again."
    new "好吧，你准时到了，想玩吗？我又需要帮忙涂防晒霜了。"

translate chinese chinese_2996081_679:
    old "Let's start with my butt."
    new "我们就从我的屁股开始吧。"

translate chinese chinese_5733379_680:
    old "I love the sun, it feels great and makes me look better, don't you think."
    new "我超爱太阳的，晒起来感觉棒极了，还让我看起来更好看，你不觉得吗？"

translate chinese chinese_9656285_681:
    old "Please pay attention, I need you to spread it aaaaall over my butt while giving a slow massage."
    new "请认真点，我要你慢慢地按摩，同时把它涂满我的屁股。"

translate chinese chinese_3384797_682:
    old "You know what? Let's fuck right now!"
    new "你知道吗？我们现在就做爱吧！"

translate chinese chinese_3906652_683:
    old "Wha-? But... Someone could see us."
    new "什么？但是……有人会看到我们的。"

translate chinese chinese_3610252_684:
    old "People are busy, nobody is gonna come, I already checked."
    new "大家都很忙，没人会来的，我已经确认过了。"

translate chinese chinese_0920680_685:
    old "Last time you weren't so worried about that!"
    new "上次你可没这么担心！"

translate chinese chinese_3916883_686:
    old "Don't worry about the people, think just about my ass"
    new "别担心那些人，只想着我的屁股就行"

translate chinese chinese_5939751_687:
    old "I really liked it, you are by far much better than my toy."
    new "我真的很喜欢，你远远比我那个玩具好多了。"

translate chinese chinese_0074898_688:
    old "It's like a super toy, delicious!"
    new "就像超级玩具，好吃极了！"

translate chinese chinese_9702974_689:
    old "Hope you liked it too, gonna take a shower."
    new "希望你也喜欢，我要去洗澡了。"

translate chinese chinese_5847796_690:
    old "Bye now."
    new "拜拜。"

translate chinese chinese_2400381_691:
    old "Yep, how bout you?"
    new "嗯，你呢？"

translate chinese chinese_0234799_692:
    old "Amazing, sun makes me feel good."
    new "真棒，阳光让我感觉很好。"

translate chinese chinese_9008041_693:
    old "I want to share some news to you."
    new "我有一些消息想告诉你。"

translate chinese chinese_1650547_694:
    old "Sure, meet me in my bedroom."
    new "行吧，来我卧室找我。"

translate chinese chinese_7543689_695:
    old "Coming."
    new "来了。"

translate chinese chinese_8623003_696:
    old "Well, being honest, the business is running pretty good."
    new "说实话，生意挺不错的。"

translate chinese chinese_7488333_697:
    old "Part of this success has been your help with the website, the pics, and your effort."
    new "这份成功的一部分要归功于你对网站、照片以及你的努力的帮助。"

translate chinese chinese_1341602_698:
    old "I know you have been more than the 'nerd' with the website, but also the one who delivers, photographer, market couch, you name it."
    new "我知道你不仅仅是那个搞网站的“书呆子”，你还负责送货、摄影、市场调研，你说什么就是什么。"

translate chinese chinese_0650864_699:
    old "Well, that is not true, but thanks."
    new "嗯，那不属实，不过谢谢。"

translate chinese chinese_2167320_700:
    old "I think it would be fair if we split the incomes instead of just giving you part of it, because you are more like my partner."
    new "我觉得我们应该平分收入而不是只给你一部分，因为你更像是我的合伙人。"

translate chinese chinese_9122638_701:
    old "Wow... I am glad to hear that."
    new "wow... 听到这个我真高兴。"

translate chinese chinese_4719848_702:
    old "To be honest, there is more you should know."
    new "说实话，你还有一些事情需要知道。"

translate chinese chinese_6260093_703:
    old "This is just part of the incomes, there is something you should be more excited about."
    new "这只不过是收入的一部分，你应该更兴奋一点的事情还在后面呢。"

translate chinese chinese_7770789_704:
    old "Lay on the bed, I will show you."
    new "躺在床上，我来给你看。"

translate chinese chinese_6694832_705:
    old "Let me give you something money can't buy."
    new "让我给你点钱买不到的东西。"

translate chinese chinese_7183304_706:
    old "Ohh, I love this taste..."
    new "哦，这个味道真喜欢..."

translate chinese chinese_0509446_707:
    old "Now, let's fuck! I'm going to ride you..."
    new "现在，让我们干吧！我要骑你..."

translate chinese chinese_6434085_708:
    old "That was intense... What a mess we've made."
    new "那真是太激烈了……我们真是搞砸了。"

translate chinese chinese_3947485_709:
    old "Hell yeah."
    new "妈的，对极了。"

translate chinese chinese_6469970_710:
    old "I think this is how a very successful partnership starts!"
    new "我觉得这就是一段非常成功的合作的开始！"

translate chinese chinese_8885156_711:
    old "I appreciate your hard work especially in this extra activity."
    new "我特别感谢你在这一项额外活动中的辛勤工作。"

translate chinese chinese_3092485_712:
    old "From now you can ask anything from me. I mean we are partners."
    new "从现在起你可以问我任何事情。我是说我们是搭档了。"

translate chinese chinese_6736313_713:
    old "I need a bit of rest... See you later [pla]"
    new "我需要休息一下……再见了 [pla]"

translate chinese chinese_6964602_714:
    old "See you later [sis]."
    new "再见 [sis]。"

translate chinese chinese_6499773_715:
    old "I really love your cock, Nerd!"
    new "我真的好喜欢你的鸡，书呆子！"

translate chinese chinese_9346326_716:
    old "I asked you to come to my bedroom in the afternoons, dummy..."
    new "我让你下午来我的卧室，傻瓜……"

translate chinese chinese_1130981_717:
    old "Oh, my bad. I will be in the garage studying then."
    new "哦，是我的错。那我到车库去学习了。"

translate chinese chinese_0145338_718:
    old "Studying in the garage?... (Hmm, I wonder what he's really doing in there.)"
    new "在车库学习？……（嗯，我在想他到底在里边干什么。）"

translate chinese chinese_7704331_719:
    old "Oh... sorry. I was just thinking of something..."
    new "哦……对不起。我刚才在想些事情……"

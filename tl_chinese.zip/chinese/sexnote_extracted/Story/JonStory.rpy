# auto-tl Qwen Colab

translate chinese chinese_3075927_0:
    old "Oh... hey."
    new "哦……嘿。"

translate chinese chinese_8223922_1:
    old "... Uhh hi."
    new "……嗯，嗨。"

translate chinese chinese_6626722_2:
    old "This is a bit awkward... Do you need something?"
    new "这个情况有点尴尬……你有什么事吗？"

translate chinese chinese_3871699_3:
    old "Weird."
    new "真奇怪。"

translate chinese chinese_5050975_4:
    old "Oh, no, no sorry, I was just looking for Mrs. Jones."
    new "哦，不不，对不起，我只是在找琼斯夫人。"

translate chinese chinese_8837502_5:
    old "... Alright, see you."
    new "……好吧，再见。"

translate chinese chinese_3582342_6:
    old "Hi everybody, how are you doing?"
    new "大家好，你们最近怎么样？"

translate chinese chinese_5532061_7:
    old "Hi [pla], God be with you!"
    new "你好[pla]，愿上帝与你同在！"

translate chinese chinese_0297512_8:
    old "Hi [pla] so happy to see you! We were talking about you..."
    new "嗨 [pla]，见到你真高兴！我们在聊你呢……"

translate chinese chinese_6455081_9:
    old "In fact, we were talking about you with Father Morgan as well."
    new "事实上，我和莫甘神父也在谈论你。"

translate chinese chinese_1415615_10:
    old "Oh! Really? What were you saying about me? Am I in trouble?"
    new "哦！真的吗？你在说我什么？我有麻烦了吗？"

translate chinese chinese_9100176_11:
    old "Noo! It's the opposite, we are so grateful for what you've done for us."
    new "不！正好相反，我们非常感激你为我们所做的一切。"

translate chinese chinese_7221486_12:
    old "Billie is feeling good now and we can feel our church is a peaceful place again, all thanks to you."
    new "比莉现在感觉很好，我们可以感受到我们的教堂又变成了一个宁静的地方，这全都是你的功劳。"

translate chinese chinese_8143150_13:
    old "Well... I-I just did what God told me to do... It was actually him, not me."
    new "嗯……我我只是做了上帝让我做的事……其实是他让我这么做的，不是我。"

translate chinese chinese_8325091_14:
    old "And that's why we want you to be part of our community, we want you to join our activities."
    new "所以我们也希望你能成为我们社区的一员，参加我们的活动。"

translate chinese chinese_2028682_15:
    old "We saw how God works through your hands, you've shown us that you're like a saint."
    new "我们看到了上帝通过你的双手在工作，你让我们觉得你就像一个圣人。"

translate chinese chinese_2302755_16:
    old "Join us, please! It would be our pleasure to have you here."
    new "请加入我们吧！能有你在这里我们会很开心的。"

translate chinese chinese_5102439_17:
    old "(Yes! This is the perfect chance to get closer to them...)"
    new "（太好了！这是接近他们的绝佳机会……）"

translate chinese chinese_5806489_18:
    old "I'm so glad to hear that, of course I will be more than happy to be here helping and being part of the community."
    new "听到这个我真的很高兴，当然我很乐意在这里帮忙，成为社区的一员。"

translate chinese chinese_7409717_19:
    old "I can start whenever you want... Just tell me what to do."
    new "你想什么时候开始都行…… just告诉我该怎么做。"

translate chinese chinese_9511287_20:
    old "Oh really hun, that's great!"
    new "哦，真的吗甜心，太好了！"

translate chinese chinese_6075831_21:
    old "Well, our main interest is to attract more young people to the community."
    new "嗯，我们主要感兴趣的是吸引更多年轻人加入社区。"

translate chinese chinese_7992971_22:
    old "That's why we believe that you are the best to help us and with your example and attitude we believe that we will be able to attract many young people."
    new "这就是为什么我们认为你是帮助我们的最佳人选，而且以你的榜样和态度，我们相信能够吸引很多年轻人。"

translate chinese chinese_2633852_23:
    old "Even get to have altar girls in the church!"
    new "甚至教堂里还有altar girls！"

translate chinese chinese_8037369_24:
    old "Wow, that's sounds good, so what do you want me to do?"
    new "哇，听起来不错，那你想让我做什么？"

translate chinese chinese_2390990_25:
    old "Well, we have to wait a bit for that. Father Morgan is a bit busy these days and we can't start without him."
    new "嗯，这个得等一会儿。摩根爸爸这些天挺忙的，没有他我们没法开始。"

translate chinese chinese_6692236_26:
    old "However, we still need help in other activities. And a young hand would be very useful."
    new "不过，我们在其他活动上还是需要帮忙的。有个年轻力壮的手脚会非常有用。"

translate chinese chinese_2043344_27:
    old "For example, cleaning the church after every mass is very tiring for just the two of us."
    new "比如，每次弥撒后打扫教堂对我们俩来说非常累人。"

translate chinese chinese_5044885_28:
    old "Perfect! So, you can come every afternoon to help us with the cleaning, the three of us can finish in a jiffy."
    new "太好了！那你每天下午过来帮我们打扫，三个人很快就能搞定。"

translate chinese chinese_2054179_29:
    old "Great, then why don't we start tomorrow, okay?"
    new "好的，那我们明天开始怎么样？"

translate chinese chinese_0523291_30:
    old "Alright! So I'll be back tomorrow."
    new "好啦！那我明天回来。"

translate chinese chinese_4574921_31:
    old "Thank you so much hun, see you tomorrow!"
    new "谢谢你哦，明天见！"

translate chinese chinese_8594555_32:
    old "Bye [pla]"
    new "再见 [pla]"

translate chinese chinese_3744896_33:
    old "S-see you Mrs. Jones and sister Grace."
    new "S-见到您了，琼斯夫人和格蕾丝姐姐。"

translate chinese chinese_9245616_34:
    old "Oh, hi [pla], you came just in time!"
    new "哦，你好 [pla]，你来得正好！"

translate chinese chinese_8125223_35:
    old "Hi, well, I don't want to leave all the work to just the two of you."
    new "嗨，嗯，我不想把所有的工作都留给你们俩。"

translate chinese chinese_2944128_36:
    old "Oh thank you honey, you are so kind."
    new "哦，谢谢你亲爱的，你真好。"

translate chinese chinese_7271314_37:
    old "Ok, let me explain you, it's simple, we just have to clean up the church a bit... As you can see, it's a mess!"
    new "好吧，让我解释一下，很简单，我们只需要稍微打扫一下教堂……你看，这里一团糟！"

translate chinese chinese_7617519_38:
    old "[pla], pick up papers if you see them on the floor... You know, make the place pretty."
    new "[pla]，如果你看到地上的纸就捡起来……你知道的，让地方整洁一点。"

translate chinese chinese_7929316_39:
    old "And pick up what shouldn't be in the church right now... All those stuff."
    new "然后捡起现在不应该出现在教堂里的那些东西……"

translate chinese chinese_0637078_40:
    old "This will be too easy for you, cleaning won't be an issue..."
    new "这对你来说太简单了，打扫根本不是问题..."

translate chinese chinese_8789874_41:
    old "Don't worry, I wanna be as quick as possible."
    new "别担心，我也想尽快搞定。"

translate chinese chinese_7427956_42:
    old "So, hurry up hun, hahaha."
    new "所以，快点哦，哈哈。"

translate chinese chinese_1877829_43:
    old "Oh, hi [pla], How are you today?"
    new "哦，嗨 [pla]，今天怎么样？"

translate chinese chinese_1925720_44:
    old "Hi sister Grace, I'm pretty good, thanks for asking."
    new "嗨，格蕾丝姐姐，我挺好的，谢谢关心。"

translate chinese chinese_9860551_45:
    old "Great Hun, are you ready to start with cleaning?"
    new "好啦， Hun，你准备好开始打扫了吗？"

translate chinese chinese_1577253_46:
    old "Sure, I'm ready to start."
    new "好的，我准备好了开始。"

translate chinese chinese_6329791_47:
    old "Perfect, let's start to clean the church."
    new "完美，我们开始打扫教堂吧。"

translate chinese chinese_6933550_48:
    old "Hi [pla], you came early, I'm waiting for sister Grace, she is with Father Morgan."
    new "嗨 [pla]，你来得真早，我在等格蕾丝姐姐，她和莫甘神父在一起。"

translate chinese chinese_5086781_49:
    old "Oh, don't worry. I can accompany you in the meantime."
    new "哦，别担心，我可以暂时陪陪你。"

translate chinese chinese_7025820_50:
    old "Oh, thanks hun... I really appreciate your help on this."
    new "哦，谢谢你亲爱的……我真的非常感激你的帮助。"

translate chinese chinese_3995809_51:
    old "I'm old and you know... I'm not as flexible as I was before."
    new "我老了，你知道的……没以前那么灵活了。"

translate chinese chinese_4608030_52:
    old "Hmm... I'm sorry to hear that... I think you're still young, though."
    new "嗯……听到这个我很难过……不过我觉得你还年轻。"

translate chinese chinese_0465435_53:
    old "You know, when I look at you... I see a very kind person, you're really nice, dear."
    new "你知道吗，当我看你的时候……我看到一个非常善良的人，你真的很温柔，亲爱的。"

translate chinese chinese_2428978_54:
    old "Haha, thanks Mrs. Jones!"
    new "哈哈，谢谢琼斯夫人！"

translate chinese chinese_5761720_55:
    old "You're like an angel... Sent by God!"
    new "你就像天使一样……是上帝派来的！"

translate chinese chinese_8957605_56:
    old "That's very nice of you but I'm just a normal guy..."
    new "你真好，但我只是个普通人..."

translate chinese chinese_3681666_57:
    old "You know dear... It's like destiny, I think you're here for a reason.."
    new "亲爱的，你知道吗……这就像命运，我觉得你出现是有原因的……"

translate chinese chinese_0648276_58:
    old "Ehm... Really?"
    new "嗯……真的吗？"

translate chinese chinese_0184605_59:
    old "I've seen what you've done and well... Yeah! I think so..."
    new "我看到了你的所作所为，嗯……是的！我觉得是这样的……"

translate chinese chinese_1533429_60:
    old "You're very spiritual and you remind me of..."
    new "你很有灵性，让我想起了……"

translate chinese chinese_3495401_61:
    old "Remind you of? W- Who?"
    new "让你想起？谁？"

translate chinese chinese_6420480_62:
    old "You remind me of my husband. When he was alive, he was so kind and strong, just like you."
    new "你让我想起了我的丈夫。他活着的时候，那么善良又坚强，就像你一样。"

translate chinese chinese_3064925_63:
    old "He was amazing, I truly miss him."
    new "他太棒了，我真的好想念他。"

translate chinese chinese_1362441_64:
    old "Hey [pla], I didn't know you were here... I see you're very committed to our community. How are you?"
    new "嘿[pla]，我不知道你在这里……看来你对我们社区很投入啊。你怎么样？"

translate chinese chinese_5039142_65:
    old "I'm fine... And you?"
    new "我没事……你呢？"

translate chinese chinese_7782273_66:
    old "All good!"
    new "一切安好！"

translate chinese chinese_6928229_67:
    old "Great! Mrs. Jones? We need to start cleaning, this is really a mess!"
    new "太好了！琼斯夫人？我们需要开始打扫了，这里真是乱糟糟的！"

translate chinese chinese_6628600_68:
    old "Yeah, sure sister Grace..."
    new "好吧，格蕾丝姐姐..."

translate chinese chinese_4013897_69:
    old "Let's get this done! We have many things to do."
    new "赶紧搞定吧！我们还有很多事情要做。"

translate chinese chinese_4455016_70:
    old "(I have to find the way to get closer to Mrs. Jones...)"
    new "（我得想办法接近琼斯太太...）"

translate chinese chinese_5539058_71:
    old "[pla]? Are you with us?"
    new "[pla]？你在听吗？"

translate chinese chinese_2795591_72:
    old "Yeah... Yeah, sure... Let's do it."
    new "嗯……好吧……我们来吧。"

translate chinese chinese_3861561_73:
    old "Wow! That was a hard job! I'm exhausted..."
    new "哇！那可真是个苦差事！我累死了..."

translate chinese chinese_4852494_74:
    old "It was a lot, yeah... "
    new "确实很多……"

translate chinese chinese_2702134_75:
    old "sister Grace, I'm gonna go now..."
    new "格蕾丝姐姐，我要走了..."

translate chinese chinese_2506133_76:
    old "Oh, do you have to leave early today?"
    new "哦，你今天要早走吗？"

translate chinese chinese_5039369_77:
    old "Yes, I think it would be nice to spend some time with Billie too, I'll go to see her."
    new "是的，我觉得花些时间和比莉在一起也很好，我去看看她。"

translate chinese chinese_6106581_78:
    old "Ahh! Of course, Mrs. Jones... Have fun with your granddaughter. I'll be in good hands with [pla] here."
    new "啊！当然，琼斯夫人……祝你和孙女玩得开心。有[pla]在这里，我会很安全的。"

translate chinese chinese_0702199_79:
    old "You'll, see you sister Grace..."
    new "你会见到你姐姐格蕾丝..."

translate chinese chinese_1621917_80:
    old "See you [pla]."
    new "[pla]，再见"

translate chinese chinese_1018011_81:
    old "Bye Mrs. Jones, take care."
    new "再见琼斯夫人，保重。"

translate chinese chinese_8338208_82:
    old "You did a great job today [pla]."
    new "今天干得不错，[pla]。"

translate chinese chinese_6144761_83:
    old "Thanks, we all worked really hard."
    new "谢谢，我们大家都很努力。"

translate chinese chinese_7536561_84:
    old "I've noticed how spiritual and good you're... I'm a bit embarrased to ask you this but..."
    new "我注意到你变得这么有精神和好……有点不好意思问你这个，但是……"

translate chinese chinese_6144905_85:
    old "But... I would like to ask for your help."
    new "但是……我还是想请你帮忙。"

translate chinese chinese_6510747_86:
    old "My help? Sure, tell me sister Grace. What can I do for you?"
    new "我的帮助？当然，告诉我格蕾丝姐姐，我能为你做些什么？"

translate chinese chinese_7277228_87:
    old "W- well... I wanna clean my spirit and my soul... I've been working on this with Father Morgan..."
    new "嗯……我想净化我的心灵和灵魂……我一直在和莫甘纳神父一起努力……"

translate chinese chinese_3267736_88:
    old "But to be honest I think you're much more spiritual than him, perhaps you could help me more..."
    new "但老实说，我觉得你比他更有灵性，也许你能帮上我更多的忙……"

translate chinese chinese_9131575_89:
    old "(I think see where this is going...)"
    new "（我觉得我知道这要往哪去了……）"

translate chinese chinese_7824691_90:
    old "I mean, you did the exorcism... You helped Billie and you're nice with everyone. I can feel your energy is different."
    new "我是说，你确实做了驱魔……你还帮了比莉，对每个人都很好。我能感觉到你的气场不一样了。"

translate chinese chinese_2017744_91:
    old "It's divine and sacred."
    new "这是神圣的。"

translate chinese chinese_9426528_92:
    old "I'm glad you think that of me and if you truly believe I could help you out, I'll do it..."
    new "我很高兴你能这么想，如果你真的认为我能帮到你，那我就试试……"

translate chinese chinese_6472643_93:
    old "I feel a bit embarrassed, I'll do what I believe is good and saint, and I'm thinking of you as a blessed man..."
    new "我感觉有点尴尬，我会做我认为的好人好事，而且我在心里把你当成一个有福气的人..."

translate chinese chinese_1890440_94:
    old "I'll be honest with you... Since I saw you performing the ritual with Billie, I have been constantly thinking of you."
    new "我老实告诉你……自从看到你和比莉一起做仪式后，我就一直在想着你。"

translate chinese chinese_6599000_95:
    old "I feel like you can help me as you helped her. You saved her and you could save me too."
    new "我觉得你能像帮助她那样帮助我。你救了她，也能救我。"

translate chinese chinese_8654807_96:
    old "(Wow) O- ok..."
    new "（ wow ） 好的..."

translate chinese chinese_5489034_97:
    old "I need to cleanse my soul."
    new "我需要净化我的灵魂。"

translate chinese chinese_5055754_98:
    old "I would need to go down on you."
    new "我得给你口交。"

translate chinese chinese_8051419_99:
    old "W-What? D-down?"
    new "什、什么？下、下去？"

translate chinese chinese_3419110_100:
    old "I have to pray in a different way."
    new "我得用不同的方式祈祷。"

translate chinese chinese_2436749_101:
    old "A- Are y- you s- sure about that?"
    new "你—你确—确定吗？"

translate chinese chinese_3625374_102:
    old "You helped Billie and everytime I'm next to you, I can feel your divine and strong energy."
    new "你帮助了比莉，每次我靠近你的时候，都能感受到你那神圣而强大的能量。"

translate chinese chinese_2031062_103:
    old "W- Would you please... L- let me suck your... D- dick?"
    new "你、你能让我... 吸一下你的... 小弟弟吗？"

translate chinese chinese_5068573_104:
    old "(This is really in line with the plan, I should do whatever it takes.)"
    new "（这完全符合计划，我应该不惜一切代价去做。）"

translate chinese chinese_4011817_105:
    old "S- sister Grace... I'll always do what is required to help you and to help the church's community."
    new "S- 姐姐格蕾丝……我一定会尽我所能帮助你和教会的社区。"

translate chinese chinese_4471471_106:
    old "I will really appreciate your help."
    new "我真的非常感激你的帮助。"

translate chinese chinese_1198081_107:
    old "Wow, I do feel much better now, kinda renewed. I'm your faithful devotee."
    new "哇，我现在确实感觉好多了，有种焕然一新的感觉。我是你的忠实信徒。"

translate chinese chinese_3660188_108:
    old "I would do everything for you as you have done everything for our community."
    new "我会为你做一切，就像你为我们社区做的一切一样。"

translate chinese chinese_1040110_109:
    old "(Oh hell! She really liked it.)"
    new "（哦天啊！她真的喜欢。）"

translate chinese chinese_0246739_110:
    old "You don't have to... I'm glad to help sister Grace..."
    new "你不用... 我很乐意帮助格蕾丝姐姐..."

translate chinese chinese_6483818_111:
    old "And you're so humble..."
    new "你还真谦虚……"

translate chinese chinese_9921234_112:
    old "I feel a bit embarrassed now, I've kept you here for quite a long time. I'm sure you have to rest."
    new "我现在有点尴尬，把你留了这么长时间，你肯定得休息了。"

translate chinese chinese_0277328_113:
    old "Actually, yes, I do but it's fine."
    new "实际上，是的，但我无所谓。"

translate chinese chinese_4641573_114:
    old "Thank you so much."
    new "真是太感谢了。"

translate chinese chinese_7971660_115:
    old "Hmm ok... I- I think should go..."
    new "嗯，好吧……我——我觉得我应该走了……"

translate chinese chinese_5734099_116:
    old "Yeah, of course, I have to go as well, see you [pla]."
    new "是的，我也得走了，[pla]，再见。"

translate chinese chinese_5096118_117:
    old "See you sister Grace."
    new "再见，格蕾丝姐姐。"

translate chinese chinese_7037774_118:
    old "I'm more tired than last time... And my back is killing me."
    new "我比上次更累了……而且我的背疼死了。"

translate chinese chinese_6558318_119:
    old "Ohh, I'm so sorry Mrs. Jones... [pla] could you please take Mrs. Jones to her house?"
    new "哦，琼斯夫人，真对不起……[pla]你能送琼斯夫人回家吗？"

translate chinese chinese_9231862_120:
    old "Of course, I'll be happy to do it."
    new "当然，我很乐意去做。"

translate chinese chinese_6683665_121:
    old "Oh no, it's not necessary, don't worry..."
    new "哦不，没关系的，别担心……"

translate chinese chinese_4143959_122:
    old "Mrs Jones, I inssist... [pla], she lives pretty close to the church."
    new "琼斯夫人，我坚持... [pla]，她住在教堂附近。"

translate chinese chinese_2834998_123:
    old "Alright, I will go with you Mrs. Jones, it's not a problem."
    new "好吧，我会和你一起去的，琼斯夫人，没问题。"

translate chinese chinese_1044595_124:
    old "Hmm alright, but just this time."
    new "嗯好吧，但就这一次。"

translate chinese chinese_6034393_125:
    old "Sure, don't worry."
    new "行，别担心。"

translate chinese chinese_4404893_126:
    old "Ok guys, see you tomorrow. Hope you get better, Mrs. Jones."
    new "好了，大家，明天见。希望你早日康复，琼斯夫人。"

translate chinese chinese_0029610_127:
    old "Thank you honey."
    new "谢谢你，亲爱的。"

translate chinese chinese_3623392_128:
    old "I'm so glad you could come with me."
    new "真高兴你能陪我一起来。"

translate chinese chinese_5213642_129:
    old "My pleasure Mrs. Jones."
    new "荣幸之至，琼斯夫人。"

translate chinese chinese_3555439_130:
    old "Come inside with me... Let me give you something to drink."
    new "进来吧……让我给你点喝的。"

translate chinese chinese_6526768_131:
    old "Hmm... Yes, why not?"
    new "嗯……好啊，为什么不呢？"

translate chinese chinese_2942352_132:
    old "By the way, I'm still surprised at how similar you're to my husband when he was young."
    new "对了，我到现在都还惊讶你和我丈夫年轻时多么相似。"

translate chinese chinese_9595802_133:
    old "Oh, really? I imagine how great he was."
    new "哦，是吗？我想象他有多棒。"

translate chinese chinese_7516943_134:
    old "He was... So strong and manly."
    new "他……太强壮太男人了。"

translate chinese chinese_2990215_135:
    old "Just like you..."
    new "就像你一样..."

translate chinese chinese_7388208_136:
    old "Hmm... I don't wanna put you in an uncomfortable position... Tell me more about yourself, we haven't talked about your spiritual development."
    new "嗯……我不想让你感到尴尬……多告诉我一些关于你自己吧，我们还没聊过你的精神发展呢。"

translate chinese chinese_7437747_137:
    old "(Actually, there is no a spiritual development...)"
    new "（实际上，根本没有精神发展……）"

translate chinese chinese_7319014_138:
    old "Ahhh! Well... It started- hmm, one day when I was walking and... Suddenly I felt the light, like a warm light all around my arms... Yeah, it was something like that."
    new "啊哈哈！嗯……那是——嗯，有一天我走路的时候……突然感觉到光芒，就像温暖的光芒包围着我的手臂……对，就是那样的感觉。"

translate chinese chinese_0402749_139:
    old "I asked because I want you to be my spiritual guide, I want to feel the grace of God within me. "
    new "我问是因为我想让你成为我的精神导师，我想感受到内心的神恩。"

translate chinese chinese_4520647_140:
    old "Your spiritual guide? Ok, but how do you think I could help you?"
    new "你的精神导师？好吧，但你认为我怎么能帮你呢？"

translate chinese chinese_3928675_141:
    old "Well... The first time I saw you, I felt really impressed by your beauty. You're extremely handsome."
    new "嗯……第一次见到你的时候，我就被你的美貌深深吸引了。你真是英俊极了。"

translate chinese chinese_2725606_142:
    old "And as I told you the other day... You remind me of my great husband."
    new "就像我前几天告诉你的……你让我想起了我伟大的丈夫。"

translate chinese chinese_2215051_143:
    old "You know, when I look at you... I see that you could be my savior as he was years ago."
    new "你知道吗，当我看你的时候……我看到你可能会成为我的救星，就像他多年前那样。"

translate chinese chinese_1235884_144:
    old "Y- your savior? What do you mean Mrs. Jones?"
    new "你—你的救星？琼斯太太，你什么意思？"

translate chinese chinese_2645009_145:
    old "Well, I know I look old but I have the needs of a young woman."
    new "好吧，我知道我看起来老了，但我还是有年轻女人的需求。"

translate chinese chinese_5532484_146:
    old "Needs? Which type of needs?"
    new "需求？哪种需求？"

translate chinese chinese_6425418_147:
    old "Don't you imagine which needs I have? It's really easy to guess, I'm a widow."
    new "你不会想象一下我需要什么吗？猜起来真的很容易，我是个寡妇。"

translate chinese chinese_8320178_148:
    old "I- I... Don't k- know if I- I am thinking wrong..."
    new "我... 我... 不知道我是不是想错了..."

translate chinese chinese_5095151_149:
    old "I need a man in my life, I need to feel some adrenaline and you're like send by God... You're beautiful on the inside and outside."
    new "我需要一个男人在我的生活中，我需要感受到一些肾上腺素，你就像上帝派来的……你内外兼修，真的很美。"

translate chinese chinese_8231844_150:
    old "You're like a saint man and I believe in you since you helped Billie... I truly believe you can guide my spiritual journey."
    new "你就像圣人一样，自从你帮助了比莉，我就相信你了……我真的相信你能引导我的精神之旅。"

translate chinese chinese_2201902_151:
    old "What? Me?"
    new "什么？我？"

translate chinese chinese_3117668_152:
    old "Yes, you! I saw how you cured my granddaughter and I am not planning to let you go."
    new "没错，就是你！我看你是怎么治好我孙女的，我可不打算让你走。"

translate chinese chinese_3373811_153:
    old "Not without a taste of what is divine... I want you to be my holy savior until I feel what Billie felt."
    new "不尝尝那神圣的味道我就不答应……我要你当我的救世主，直到我感受到比莉的感受。"

translate chinese chinese_7203697_154:
    old "I- I don't know what to say... I mean, you're such a beautiful woman but... I don't know..."
    new "我……我不知道该说什么……我是说，你真是个美丽的女人，但是……我不知道……"

translate chinese chinese_7195045_155:
    old "You already have the answer... Follow the will of God, you know this is the right thing to do, handsome."
    new "你已经知道答案了……顺从神的旨意，你知道这是正确的选择， handsome."

translate chinese chinese_7943323_156:
    old "(Ok, I think this can help me to do the ritual.)"
    new "（好吧，我觉得这个可以帮助我完成仪式。）"

translate chinese chinese_5070070_157:
    old "Yes, if that is what you need, I'll do what is required. I'll follow God's will."
    new "好的，如果你需要的话，我会做该做的事。我会顺从上帝的旨意。"

translate chinese chinese_9952294_158:
    old "I have no doubts... You were sent to clean my sins like I used to do with my husband..."
    new "我毫不怀疑……你是被派来净化我的罪孽的，就像我过去对我丈夫做的那样……"

translate chinese chinese_5935187_159:
    old "What would you like to do that reminds you of him?"
    new "你想做些什么来怀念他？"

translate chinese chinese_9810957_160:
    old "Well, I would love to start by putting your dick inside my mouth and then brushing it with my sinful lips..."
    new "嗯，我倒是想从把你的丁丁放进嘴里开始，然后用我的罪唇舔刷它……"

translate chinese chinese_0702254_161:
    old "... I guess God will be happy with that..."
    new "……我想上帝会对那个满意的……"

translate chinese chinese_9214754_162:
    old "I want to have your sacred presence on my lips and keep the taste on my tongue..."
    new "我想让你神圣的存在留在我的唇间，让味道停留在我的舌头上..."

translate chinese chinese_1214160_163:
    old "(Maybe this is getting a bit out of hand?)"
    new "(这可能有点失控了？)"

translate chinese chinese_8447443_164:
    old "That was incredible, you're a divine presence in my life and well..."
    new "太棒了，你是我生命中的神一般的存在，嗯……"

translate chinese chinese_3568156_165:
    old "I do feel so renewed and younger now."
    new "我现在确实感觉焕然一新，年轻了许多。"

translate chinese chinese_5832180_166:
    old "Hmm... I just did what God told me to do... It was my pleasure to help you."
    new "嗯……我只是做了上帝让我做的事……能帮你是我很开心。"

translate chinese chinese_4598855_167:
    old "Did you enjoy it? Isn't?"
    new "你享受吗？不是吗？"

translate chinese chinese_4221174_168:
    old "Oh no hun! I'm sorry, I know this is just part of your holy duty... I shouldn't ask those things."
    new "哦不，亲爱的！对不起，我知道这只是你的神圣职责……我不应该问那些事情。"

translate chinese chinese_9009112_169:
    old "Y- Yes Mrs. Jones, it's m- my d- duty."
    new "是的，琼斯夫人，这是我的职责。"

translate chinese chinese_2290751_170:
    old "I should go now... It's getting late."
    new "我该走了……天色不早了。"

translate chinese chinese_4983441_171:
    old "Go with God, handsome... And thanks again. I'll be eager for more."
    new "一路平安， handsome... 再次感谢。我还会想要更多。"

translate chinese chinese_6241288_172:
    old "S- sure, goodbye Mrs. Jones."
    new "好，再见了，琼斯夫人。"

translate chinese chinese_8317877_173:
    old "It was nice, now the church looks much better."
    new "挺好的，现在教堂看起来漂亮多了。"

translate chinese chinese_7122001_174:
    old "It looks better now..."
    new "现在看起来好多了..."

translate chinese chinese_0985066_175:
    old "It's tiring to clean... "
    new "打扫真累……"

translate chinese chinese_8807853_176:
    old "I'll see tomorrow... I gotta go now."
    new "我明天再看吧……我现在得走了。"

translate chinese chinese_1033926_177:
    old "See you Mrs. Jones..."
    new "再见了，琼斯夫人..."

translate chinese chinese_2724658_178:
    old "Take care, dear."
    new "照顾好自己，亲爱的。"

translate chinese chinese_4736251_179:
    old "I'm glad it's just the two of us now."
    new "我很高兴现在只有我们两个人。"

translate chinese chinese_4970961_180:
    old "Hmm... Yeah, it's nice."
    new "嗯……是的，挺不错的。"

translate chinese chinese_3301082_181:
    old "[pla] I have to tell you something."
    new "[pla] 我有件事必须告诉你。"

translate chinese chinese_4368358_182:
    old "I think shouldn't feel so good when I'm with you... I should pay with pain, I should suffer..."
    new "我觉得和你在一起不应该这么舒服……我应该付出痛苦，应该承受折磨……"

translate chinese chinese_7802599_183:
    old "I have never felt so much grace within me, my body feels renewed."
    new "我从未感到过如此优雅，身体仿佛焕然一新。"

translate chinese chinese_1617968_184:
    old "But I'm not sure if that is ok... A spiritual journey requires suffering and I do not feel that it's fair just to feel pleasure and purification through you."
    new "但是我不确定这样好不好……精神之旅需要痛苦，我觉得仅仅通过你获得愉悦和净化是不公平的。"

translate chinese chinese_2454388_185:
    old "I need you to punish me, I have to do penance..."
    new "我需要你惩罚我，我必须赎罪..."

translate chinese chinese_8184905_186:
    old "W-what?"
    new "什、什么？"

translate chinese chinese_9116736_187:
    old "Yes, I know is what God wants and I know that with pain I will purify my soul..."
    new "是的，我知道这是上帝的旨意，我也知道我会通过痛苦净化我的灵魂……"

translate chinese chinese_9618432_188:
    old "But I need you to guide and help me... Since you have given me so much purification, you should be the one punishing and showing me the way..."
    new "但是你需要引导我、帮助我……既然你给了我这么多净化，就应该由你来惩罚我、指引我……"

translate chinese chinese_0601592_189:
    old "A- alright... B- but, h- how?"
    new "好……吧……但是，怎……怎么呢？"

translate chinese chinese_6538578_190:
    old "You're like my master. I need you to see me as your sinful slave who needs to come out of the dark side."
    new "你就像我的主人，我需要你把我看作是需要走出黑暗面的罪恶奴隶。"

translate chinese chinese_2482538_191:
    old "As I get naked, I know that God will enlighten you and act through you for your guidance."
    new "当我脱光时，我知道上帝会启迪你，并通过你来指引你。"

translate chinese chinese_6230226_192:
    old "He'll tell you what to do..."
    new "他会告诉你该怎么做..."

translate chinese chinese_9257013_193:
    old "Please! The pain and pleasure will go away but my submission and loyalty to you will remain eternally in my soul... I need it."
    new "求你了！痛苦和快感都会过去，但我对你的顺从和忠诚将永远留在我的灵魂中……我需要它。"

translate chinese chinese_4417475_194:
    old "If that's what you need, I'll do it."
    new "如果你需要的话，我就做。"

translate chinese chinese_6647067_195:
    old "I would like to thank you... You can't imagine how important this was to me."
    new "我想感谢你……你无法想象这对我有多重要。"

translate chinese chinese_7560138_196:
    old "I- I am glad, sister Grace."
    new "我……我很高兴，格蕾丝姐姐。"

translate chinese chinese_0257632_197:
    old "I should go now, I have to be home soon..."
    new "我得走了，我很快就要回家了……"

translate chinese chinese_6049098_198:
    old "Alright! I have to go as well. I'll be thinking of your great and massive..."
    new "好了！我也得走了。我会想着你的伟大和巨大的..."

translate chinese chinese_7978886_199:
    old "... Spirit and soul."
    new "...精神与灵魂。"

translate chinese chinese_3957546_200:
    old "hi [pla], how are you?"
    new "嗨 [pla]，你好吗？"

translate chinese chinese_5442738_201:
    old "Hey! I'm fine... What about you?"
    new "喂！我没事……你呢？"

translate chinese chinese_0615232_202:
    old "I'm a bit worried [pla], you know we don't have much time to perform the ritual, you gotta hurry up!"
    new "我有点担心[pla]，你知道我们没有多少时间来完成仪式，你得快点！"

translate chinese chinese_6274402_203:
    old "I'm working on it, you don't need to worry about it, I'll do it and everything will be fine."
    new "我正在处理，你不用担心，我会搞定的，一切都会好的。"

translate chinese chinese_2635515_204:
    old "Alright! I just wanna make sure you have everything ready because we're running out of time..."
    new "好啦！我只是想确认一下你都准备好了，因为时间不多了……"

translate chinese chinese_4254411_205:
    old "Hmm, okay, I'll have to rush the plans ... "
    new "嗯，好吧，我得赶紧把计划赶出来……"

translate chinese chinese_0602023_206:
    old "Great, and who will be with you in the ritual? Which humans?"
    new "太好了，那你仪式上会带谁？是哪些人类？"

translate chinese chinese_0402987_207:
    old "Mrs. Jones and the sister Grace, they both have a lot of accumulated energy."
    new "琼斯太太和格蕾丝妹妹都积攒了很多能量。"

translate chinese chinese_4585146_208:
    old "Do they know what they have to do?"
    new "他们知道自己要做什么吗？"

translate chinese chinese_0213036_209:
    old "Well, not yet... But they'll do it, I have been working on getting closer to them and it's going better than I expected."
    new "嗯，还没呢……但是他们会这么做的，我一直在努力接近他们，进展比我预期的要好。"

translate chinese chinese_7625616_210:
    old "Ok, I don't wanna put more pressure on you but we have to... We do need that energy to perform the ritual."
    new "好吧，我不想给你更多压力，但我们确实需要那股能量来完成仪式。"

translate chinese chinese_1261787_211:
    old "I know! In fact, I'm going to talk to them and get everything ready..."
    new "我知道！事实上，我打算去和他们谈谈，把一切都准备好……"

translate chinese chinese_0039119_212:
    old "Ok, since you have everything almost ready for the ritual... I wanna share some energy with you."
    new "好吧，既然你几乎已经准备好仪式了……我想和你分享一些能量。"

translate chinese chinese_4579800_213:
    old "S- Sure... Let's do it!"
    new "好……好啊……我们来吧！"

translate chinese chinese_6160177_214:
    old "All right, get naked and lie on the bed... "
    new "好吧，脱光衣服躺在床上..."

translate chinese chinese_5220255_215:
    old "It's done, go and prepare everything for the ritual! "
    new "搞定了，去准备仪式的一切吧！"

translate chinese chinese_2548322_216:
    old "Got it, thanks, see you!"
    new "收到，谢谢，再见！"

translate chinese chinese_2355194_217:
    old "See ya..."
    new "再见..."

translate chinese chinese_0802210_218:
    old "The best of luck!!! I'm so excited for you..."
    new "祝你好运！！！我好为你激动..."

translate chinese chinese_9926487_219:
    old "Hi sister Grace, I'm ready to start cleaning..."
    new "嗨，格蕾丝姐姐，我准备好开始打扫了……"

translate chinese chinese_8713980_220:
    old "It's so nice to see you, hi [pla]... Actually we don't have to clean today..."
    new "见到你真好，嗨 [pla]……其实今天我们不用打扫……"

translate chinese chinese_8113667_221:
    old "We have some issues now..."
    new "我们现在有些问题……"

translate chinese chinese_6895329_222:
    old "[pla]... Your help it's been exceptional, I'm so grateful with you."
    new "[pla]... 你的帮助真的非常出色，我真的很感激你。"

translate chinese chinese_8958098_223:
    old "It's what God wants me to do... I could help even more if needed."
    new "这是上帝想让我做的……如果需要的话，我还能帮更多。"

translate chinese chinese_4435529_224:
    old "Well... Now that you mentioned it, I need you to do something..."
    new "嗯……现在你提到了，我需要你做件事……"

translate chinese chinese_3149848_225:
    old "(Not punishment, please!)"
    new "（不要惩罚，拜托！）"

translate chinese chinese_8329964_226:
    old "Hmm, tell me sister Grace, what can I do for you?"
    new "嗯，告诉我，格蕾丝姐姐，你需要我做什么？"

translate chinese chinese_3179486_227:
    old "Mrs. Jones is feeling a bit sick but I can't go to see her...  I can't leave the church right now. Would you please stop by her house to see how she's doing?"
    new "琼斯夫人感觉有点不舒服，但我不能去看她……我现在不能离开教堂。你能去她家看看她的情况吗？"

translate chinese chinese_5943030_228:
    old "I'm so sorry she's sick... I'll go right now."
    new "真抱歉她生病了……我马上就去。"

translate chinese chinese_9045436_229:
    old "Thanks dear [pla]... Call me if you need anything, alright!"
    new "谢谢亲爱的[pla]……有什么需要就打电话给我，好吗！"

translate chinese chinese_8684306_230:
    old "(I hope she's not that sick... I'll need her for the ritual)"
    new "（希望她不是那么不舒服……我还需要她来完成仪式）"

translate chinese chinese_3007447_231:
    old "(Hmm... Actually, before I go... I should definitely talk to the nun about the ritual...)"
    new "（嗯……其实，在我走之前……我一定要和修女谈谈那个仪式……）"

translate chinese chinese_4505009_232:
    old "Sister Grace? Sorry! Hmm... I wanna tell you something before I go..."
    new "格蕾丝姐姐？对不起！嗯……在我走之前想告诉你件事……"

translate chinese chinese_6130085_233:
    old "Yeah? Tell me [pla]... What's that?"
    new "是吗？告诉我[pla]……那是什么？"

translate chinese chinese_7519860_234:
    old "You said you were my faithful devotee and you would always be loyal to me, right?"
    new "你说过你是我的忠实信徒，会永远忠诚于我，对吧？"

translate chinese chinese_5944889_235:
    old "Yes, of course. After all you've done to me and for me, I would do anything for you."
    new "当然了。你为我做的一切，我会为你做任何事。"

translate chinese chinese_9047025_236:
    old "Well... I have to do a spiritual ritual, it's very important and it has to be done here at the church... And I would like you to help me to perform it."
    new "嗯……我得做一个精神仪式，这非常重要，而且必须在这里的教堂进行……我想请你帮我完成它。"

translate chinese chinese_3450112_237:
    old "Yes, I'm not even gonna question you about it, as a submissive being to your will, I will always be at your service."
    new "是的，我甚至不会质疑你，作为一个顺从者，我将永远服从您的意愿。"

translate chinese chinese_0348629_238:
    old "Well! That's great, thanks! I knew I could count on you."
    new "哇！太好了，谢谢！我就知道你能行的。"

translate chinese chinese_3030343_239:
    old "I need you to make sure the church is empty at night, we can't allow sinful people to be here..."
    new "你需要确保晚上教堂里没人，不能让有罪的人待在这里……"

translate chinese chinese_2486959_240:
    old "I'm always obedient to God and to you."
    new "我总是顺从上帝和你的。"

translate chinese chinese_4241366_241:
    old "Hmm by the way... We won't be alone, one more person will join us, you already know her and I'm sure you'll do great during the ritual."
    new "嗯，对了……我们不会孤单，还会有一个加入我们，你已经认识她了，我相信你在仪式上会表现得很棒。"

translate chinese chinese_7005968_242:
    old "One more person? Who?"
    new "再加一个人？谁？"

translate chinese chinese_3134488_243:
    old "Trust me... You know I'm the hand of God."
    new "相信我……你知道我是上帝之手。"

translate chinese chinese_9269243_244:
    old "I'm so sorry!"
    new "真的很抱歉！"

translate chinese chinese_3849028_245:
    old "Just make sure the place is ready..."
    new "just make sure the place is ready...\n\n确保地方准备好..."

translate chinese chinese_6528721_246:
    old "I'll do everything to please you."
    new "我会做一切让你满意的事。"

translate chinese chinese_2263258_247:
    old "You're great! I'll go now since we need to know how Mrs. Jones is..."
    new "你真棒！那我现在就走吧，我们还得去看看琼斯太太的情况……"

translate chinese chinese_8155997_248:
    old "Go with God..."
    new "一路平安……"

translate chinese chinese_5869698_249:
    old "Hello? Mrs. Jones? "
    new "喂？琼斯夫人？"

translate chinese chinese_2946636_250:
    old "Are you here?"
    new "你在吗？"

translate chinese chinese_2772968_251:
    old "Dear? [pla]?"
    new "亲爱的？[pla]？"

translate chinese chinese_6605897_252:
    old "Come here, handsome..."
    new "过来， handsome..."

translate chinese chinese_7870850_253:
    old "Hi dear, I was waiting for you..."
    new "亲爱的，我在等你呢……"

translate chinese chinese_0209344_254:
    old "Wow! Mrs. Jones what are you wearing?"
    new "哇！琼斯夫人，你穿的是什么？"

translate chinese chinese_2859713_255:
    old "I'm so happy you're here... How are you, handsome?"
    new "真高兴你在这里……你过得怎么样， handsome？"

translate chinese chinese_3377672_256:
    old "H- hi Mrs. Jones, I'm fine... But tell me how are you feeling?"
    new "哈啰，琼斯夫人，我很好……不过您呢，感觉怎么样？"

translate chinese chinese_6084380_257:
    old "The sister Grace told me you have been quite sick..."
    new "格蕾丝姐姐告诉我你病得不轻..."

translate chinese chinese_4805645_258:
    old "But you look d- different..."
    new "但是你看起来……不一样了……"

translate chinese chinese_5539164_259:
    old "I'm fine as you can see... Maybe a bit hot ..."
    new "我挺好的你看…… maybe a bit hot ..."

translate chinese chinese_3602207_260:
    old "You should enjoy what you're seeing right now... As much as I'm enjoying having you here."
    new "你应该享受你现在看到的……就像我享受你在这里一样。"

translate chinese chinese_9193446_261:
    old "M- mrs. Jones, why are you wearing that?"
    new "琼斯夫人，你为什么穿那个？"

translate chinese chinese_9834408_262:
    old "Well, You were the one bringing me this dress time ago... You made me remember my younger years with my husband..."
    new "嗯，是你之前给我这件衣服的……让你想起了我和丈夫年轻时候的日子……"

translate chinese chinese_5039482_263:
    old "I used to wear a similar dress to this one and my husband used to devore me with his hands..."
    new "我以前穿过类似的裙子，我丈夫喜欢用手把我剥光……"

translate chinese chinese_3569540_264:
    old "We liked rough sex... You know..."
    new "我们喜欢粗暴一点的性爱……你知道的……"

translate chinese chinese_4297680_265:
    old "(W- What?)"
    new "（什么？）"

translate chinese chinese_2351008_266:
    old "I forgot you're a bit shy sometimes... But perhaps you forgot I'm not and I want to have you now!"
    new "我忘了你有时候挺害羞的……但也许你忘了我不是那种人，我现在就想拥有你！"

translate chinese chinese_1293686_267:
    old "I'll take the initiative... I know you like when your cock is between my lips."
    new "我主动一点吧……我知道你喜欢我的嘴里含着你的鸡巴。"

translate chinese chinese_4305105_268:
    old "And I know you're getting hard as fuck right now... Just let me take off your pants, handsome."
    new "而且我知道你现在硬得跟岩石一样……就让我帮你脱掉裤子吧， handsome."

translate chinese chinese_1591424_269:
    old "I'm feeling much better now... I should say thank you..."
    new "我现在感觉好多了……应该说声谢谢……"

translate chinese chinese_5533510_270:
    old "(Hmm sure...) I hope you're much better now."
    new "（嗯，好吧……）希望你现在好多了。"

translate chinese chinese_3164719_271:
    old "Totally hun... Thanks for passing by..."
    new "完全明白啦……谢谢你过来……"

translate chinese chinese_1157223_272:
    old "Hmm... Mrs. Jones, I actually wanted to ask you a favor..."
    new "嗯……琼斯夫人，我其实想请你帮个忙……"

translate chinese chinese_3630955_273:
    old "A favor? Sure, anything for you, love..."
    new "帮忙？当然，什么都愿意为你做，亲爱的……"

translate chinese chinese_2685458_274:
    old "I'll have to perform a ritual at the church to clean the energies..."
    new "我得去教堂做个仪式来净化这些能量……"

translate chinese chinese_2182996_275:
    old "And since we're closer now and you know that I've such a spiritual development, I would like you to be part of that ritual."
    new "既然我们现在关系更近了，而且你知道我在精神层面有所发展，我希望你能参与那个仪式。"

translate chinese chinese_9290410_276:
    old "Sister Grace would be there, you and me... Would you help me? "
    new "格蕾丝姐姐会在那里，你和我……你会帮我吗？"

translate chinese chinese_6935421_277:
    old "You've done so much for me, hun... I already told you, I would do whatever you ask me to do. You can count on me for it."
    new "你为我做了这么多，亲爱的……我已经告诉你了，你会让我做什么我就做什么。你可以相信我的。"

translate chinese chinese_2833874_278:
    old "Thanks Mrs. Jones, I didn't expect less from you..."
    new "谢谢琼斯夫人，我可没对你抱什么期望……"

translate chinese chinese_9016690_279:
    old "I'll see at the church, now I should go..."
    new "我在教堂见，现在我该走了..."

translate chinese chinese_6669250_280:
    old "See you there, handsome."
    new "到时候见， handsome."

translate chinese chinese_8708286_281:
    old "Ok... Today is the ritual day!"
    new "好……今天就是仪式日！"

translate chinese chinese_4903314_282:
    old "And you'll be great, we count on you..."
    new "你会很棒的，我们相信你..."

translate chinese chinese_7605645_283:
    old "I know Linett, I've everything ready and well... It'll be fine."
    new "我知道林奈特，我都准备好了……一切都会好的。"

translate chinese chinese_0848397_284:
    old "[pla] make sure you have sex with both, the nun and the older woman, it's extremely important to get energy from both. I'll be there with you..."
    new "[pla] 确保你两个都得上，修女和那个女人，从两个身上获取能量非常重要。我会在你身边的..."

translate chinese chinese_2807724_285:
    old "Great! I didn't know you were coming with me..."
    new "太好了！我不知道你也一起来……"

translate chinese chinese_5019411_286:
    old "Ohh! Ok..."
    new "哦……好的……"

translate chinese chinese_1321990_287:
    old "So are you ready... We gotta start the ritual now."
    new "那你准备好了吗……我们现在得开始仪式了。"

translate chinese chinese_0671376_288:
    old "Yeah... Let's do it!"
    new "嗯……咱们干吧！"

translate chinese chinese_6715929_289:
    old "Oh, they are back there..."
    new "哦，他们在那边……"

translate chinese chinese_6584979_290:
    old "Great! It's time to start the ritual."
    new "太好了！是时候开始仪式了。"

translate chinese chinese_2519615_291:
    old "Mrs. Jones, sister Grace... Hi, I'm glad you both are here..."
    new "琼斯夫人，格蕾丝修女……嗨，很高兴你们都在这里……"

translate chinese chinese_4110390_292:
    old "Good night hun."
    new "晚安亲爱的。"

translate chinese chinese_1951987_293:
    old "Hi [pla], it's a pleasure to be here with you."
    new "你好[pla]，能和你在一起我感到很荣幸。"

translate chinese chinese_6867054_294:
    old "Billie? W- What are you doing here?"
    new "比莉？你在这里干什么？"

translate chinese chinese_8835128_295:
    old "Oh, I invited her... As you said you are going to clean the bad energies I thought it would be a great idea to invite Billie..."
    new "哦，我邀请了她……既然你说你要清除那些负面能量，我觉得邀请比莉来会是个好主意……"

translate chinese chinese_2089267_296:
    old "W- what? B- but she doesn't know what we are going to have se- ... An important ritual..."
    new "什、什么？但她不知道我们要进行的这、这个重要的仪式……"

translate chinese chinese_8105505_297:
    old "Oh, don't worry hun, I already explained it to her, she was really worried about her sexorcis-... I mean exorcism."
    new "哦，别担心亲爱的，我已经跟她解释过了，她真的很担心她的除灵……我的意思是驱魔。"

translate chinese chinese_5835369_298:
    old "I wanted to come... I never thought that I could be religious having sex."
    new "我想来……我从没想过自己会在做爱时变得如此虔诚。"

translate chinese chinese_2430256_299:
    old "And I wanna thank you for what you did for me as well..."
    new "我也想感谢你为我做的一切……"

translate chinese chinese_5643582_300:
    old "Hmm alright... I- I see..."
    new "嗯，好吧……我——我明白了……"

translate chinese chinese_0186409_301:
    old "{i}Pstt... [pla], we are running out of time... Start now!{/i}"
    new "{i}嘘……[pla]，我们快没时间了……现在开始！{/i}"

translate chinese chinese_0385471_302:
    old "(Oh shit, she is right.)"
    new "（哦shit，她说得对。）"

translate chinese chinese_7525070_303:
    old "Well ladies, this is a spiritual ritual in which we all will do a transfer of spirituality among us..."
    new "好吧女士们，这是一个精神仪式，我们将在这其中互相传递精神能量……"

translate chinese chinese_6506097_304:
    old "I've noticed how spiritual you all are and that's why I've chosen you for this."
    new "我注意到你们都很有灵性，所以选择了你们。"

translate chinese chinese_9285220_305:
    old "We'll have to open our hearts to God and give to each other what's required..."
    new "我们必须向上帝敞开心扉，彼此给予所需……"

translate chinese chinese_7872430_306:
    old "I can't wait to do it... You have all of me for this..."
    new "我迫不及待想做了……你全都要了……"

translate chinese chinese_2743365_307:
    old "I agree with Mrs. Jones..."
    new "我同意琼斯太太的说法..."

translate chinese chinese_1204383_308:
    old "The better we do it, the better our lives will be in the eyes of God..."
    new "我们做得越好，在上帝眼中的生活就会越好……"

translate chinese chinese_8452175_309:
    old "Put all your faith on me and I'll guide through the ritual, it's all about spirituality and love."
    new "把所有的信任都放在我身上，我会引导你完成仪式的，这全关乎精神和爱。"

translate chinese chinese_3948639_310:
    old "Can't we just start?"
    new "我们不能直接开始吗？"

translate chinese chinese_9296120_311:
    old "Right, can you turn on the lights before we start?"
    new "好的，我们开始前能把灯打开吗？"

translate chinese chinese_4960093_312:
    old "Let's start with the sex!"
    new "我们直接开始做爱吧！"

translate chinese chinese_6684873_313:
    old "Ahhh."
    new "啊hhh。"

translate chinese chinese_1322218_314:
    old "Oh dear please calm down..."
    new "哦天啊，请冷静一下……"

translate chinese chinese_2951978_315:
    old "Good job! Now it's my turn!"
    new "干得好！现在轮到我了！"

translate chinese chinese_0849741_316:
    old "W- Well... Thank you... It was an excellent ritual, you all did good and I'm very thankful..."
    new "嗯……谢谢……仪式很成功，你们都做得很好，我非常感激……"

translate chinese chinese_5448384_317:
    old "I'm happy we got to help you and you helped us during this ritual..."
    new "我很高兴我们能帮你，同时你也在这个仪式中帮了我们……"

translate chinese chinese_8326153_318:
    old "It was cool..."
    new "挺酷的……"

translate chinese chinese_0416956_319:
    old "I feel totally new... Totally different, thanks so much [pla]..."
    new "我感觉完全不一样了……完全变了，谢谢你这么多[pla]……"

translate chinese chinese_5199394_320:
    old "I'm glad..."
    new "我很高兴……"

translate chinese chinese_1245244_321:
    old "I have to go now... "
    new "我得走了……"

translate chinese chinese_5699414_322:
    old "See you [pla], I need some rest after this..."
    new "[pla]，再见，这个之后我需要休息一下……"

translate chinese chinese_1832202_323:
    old "Goodbye, dear... See you!"
    new "再见了，亲爱的……下次见！"

translate chinese chinese_8151869_324:
    old "Linett!?..."
    new "林奈特！？..."

translate chinese chinese_4380387_325:
    old "Hi... How are you feeling?"
    new "喂……你觉得怎么样？"

translate chinese chinese_0156257_326:
    old "I'm happy, we did it!"
    new "我好开心，我们做到了！"

translate chinese chinese_1100444_327:
    old "Well... It didn't work..."
    new "嗯……没用呢……"

translate chinese chinese_5613482_328:
    old "What? Why? What happened?"
    new "什么？为什么？发生了什么事？"

translate chinese chinese_5112811_329:
    old "It simply didn't work... It happens sometimes, it's a complex ritual and well... This time it didn't work..."
    new "这根本没用……有时候就是这样，这个仪式很复杂，嗯……这次就是没成功……"

translate chinese chinese_7089870_330:
    old "Really? Now what?"
    new "真的吗？现在怎么办？"

translate chinese chinese_1927943_331:
    old "There is nothing we can do now... We have to wait until christmas, there is no other way..."
    new "我们现在什么也做不了……只能等到圣诞节，没有其他办法……"

translate chinese chinese_3155630_332:
    old "During christmas there is a load of human energy all around and that's the only chance we will have..."
    new "圣诞节周围充满了人类的能量，这是我们唯一的机会……"

translate chinese chinese_6766591_333:
    old "For now there is nothing we can do..."
    new "现在我们什么也做不了……"

translate chinese chinese_1439578_334:
    old "I see... We'll try for Christmas..."
    new "我明白了……我们争取圣诞节吧……"

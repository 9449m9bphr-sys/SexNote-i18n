# auto-tl Qwen Colab

translate chinese chinese_7983378_0:
    old "Hey guys, how are you?"
    new "嘿，大家怎么样？"

translate chinese chinese_3332560_1:
    old "Hi [pla], good morning."
    new "你好 [pla]，早上好。"

translate chinese chinese_8598352_2:
    old "Hi dude."
    new "嘿，兄弟。"

translate chinese chinese_1116782_3:
    old "Hey, what's up?"
    new "嘿，最近怎么样？"

translate chinese chinese_5785550_4:
    old "Hi [pla]."
    new "你好[pla]。"

translate chinese chinese_3114294_5:
    old "What were you guys talking about?"
    new "你们刚才在聊什么？"

translate chinese chinese_6399337_6:
    old "Oh you know, just listening to Mike's dumb stuff."
    new "哦，你知道的，就是在听迈克的傻话。"

translate chinese chinese_1424972_7:
    old "Hey, what do you mean dumb stuff?"
    new "嘿，你说的傻东西是什么意思？"

translate chinese chinese_5856305_8:
    old "As I recall, you seemed to think it was very interesting."
    new "我记得你当时好像觉得这很有趣。"

translate chinese chinese_1579449_9:
    old "Well, it was only because there's nothing else going on this early in the morning."
    new "嗯，只是因为一大早没什么别的事情好做。"

translate chinese chinese_1888831_10:
    old "Hey guys, I think we should get going, classes are about to start."
    new "大家，我觉得我们该走了，快上课了。"

translate chinese chinese_6041172_11:
    old "Yeah, we probably should."
    new "嗯，我们 probably 应该这么做。"

translate chinese chinese_0033280_12:
    old "[pla], wait."
    new "[pla]，等一下。"

translate chinese chinese_6338267_13:
    old "Yeah? What's up?"
    new "嗯？怎么了？"

translate chinese chinese_7564526_14:
    old "Uhm, the thing is... That there's something I need your help with."
    new "嗯，是这样的……我有件事需要你的帮忙。"

translate chinese chinese_5639241_15:
    old "Sure, what is it?"
    new "当然，什么事？"

translate chinese chinese_8391491_16:
    old "Hmm, I think it would be better if we talk about this somewhere else."
    new "嗯，我觉得我们换个地方再谈这个比较好。"

translate chinese chinese_9773738_17:
    old "Besides, there's something I have to show you."
    new "而且，我有东西要给你看。"

translate chinese chinese_5389441_18:
    old "So, how about you come to my house after classes."
    new "所以，放学后你来我家怎么样？"

translate chinese chinese_0020671_19:
    old "Uh, yeah, sure..."
    new "呃，好吧……"

translate chinese chinese_8301396_20:
    old "Good morning Belle, [pla]."
    new "早上好，Belle，[pla]。"

translate chinese chinese_4223545_21:
    old "Godd morning Miss Lucy."
    new "早上好，露西小姐。"

translate chinese chinese_0256926_22:
    old "Good morning Miss Lucy."
    new "早上好，露西小姐。"

translate chinese chinese_2273442_23:
    old "Guys, classes are about to start."
    new "大家，上课要开始了。"

translate chinese chinese_4221794_24:
    old "It's not good that you two stay here talking in the hallway."
    new "你们俩在这走廊里说话不太好。"

translate chinese chinese_8339149_25:
    old "Good, now go to the classroom you two..."
    new "好的，现在你们两个去教室……"

translate chinese chinese_3081856_26:
    old "Ugh, that was eternal."
    new "唉，那真是太久了。"

translate chinese chinese_5970156_27:
    old "Miss Lucy just kept talking and talking."
    new "卢西小姐一直在说个不停。"

translate chinese chinese_5617581_28:
    old "Tell me about it. I thought classes weren't going to end today."
    new "说起来，我还以为今天课上不完呢。"

translate chinese chinese_5797930_29:
    old "Yeah, but anyway."
    new "嗯，不过话说回来。"

translate chinese chinese_3315332_30:
    old "Now that that is over, will you come with me to my house?"
    new "这件事结束了，你愿意跟我回家吗？"

translate chinese chinese_0716590_31:
    old "Uhh, sure."
    new "呃，好吧。"

translate chinese chinese_5422753_32:
    old "Alright, then let's go!"
    new "好吧，那我们走吧！"

translate chinese chinese_4233895_33:
    old "What?! Oh."
    new "什么?! 哦。"

translate chinese chinese_9369376_34:
    old "I'm just realizing that I have never visited your house before."
    new "我才意识到我以前从没去过你家。"

translate chinese chinese_8258921_35:
    old "Oh, I see."
    new "哦，我明白了。"

translate chinese chinese_0860413_36:
    old "Well, I try to avoid inviting people over because my mom tends to be intrusive and it annoys me."
    new "嗯，我尽量不邀请别人过来，因为妈妈总是爱管闲事，这让我很烦。"

translate chinese chinese_0817105_37:
    old "Although Mike has been here before."
    new "虽然迈克之前来过这里。"

translate chinese chinese_7258061_38:
    old "I had to bring him when we were doing that team project."
    new "我们在做那个团队项目时不得不带他一起去。"

translate chinese chinese_8338863_39:
    old "And he met my mom..."
    new "而且他还见了我妈妈……"

translate chinese chinese_5294656_40:
    old "It wasn't any fun to see him constantly trying to hit on her..."
    new "看到他老是想占她便宜真的没什么好玩的..."

translate chinese chinese_7000770_41:
    old "I can imagine him doing that."
    new "我能想象他会那样做。"

translate chinese chinese_4105086_42:
    old "It was so awkward."
    new "真是尴尬死了。"

translate chinese chinese_3969551_43:
    old "But anyway, what do you think about the house?"
    new "不过说正经的，你觉得这房子怎么样？"

translate chinese chinese_2556243_44:
    old "Uh... It's very nice. I like the decoration a lot."
    new "呃……挺不错的。我很喜欢这里的装饰。"

translate chinese chinese_0750630_45:
    old "You do? My mom would be happy to hear that, she's really into interior design."
    new "你真的吗？我妈妈听到肯定会很高兴，她对室内设计很感兴趣。"

translate chinese chinese_1489339_46:
    old "She is? Really?"
    new "她是吗？真的吗？"

translate chinese chinese_2142359_47:
    old "Yep, she's a graphic designer, so, she's quite into decorating and stuff."
    new "没错，她是平面设计师，所以对装饰这些东西挺感兴趣的。"

translate chinese chinese_3782655_48:
    old "Hmm, I guess that makes a lot of sense."
    new "嗯，我想这说得通。"

translate chinese chinese_8603835_49:
    old "So... Changing the subject."
    new "所以……换个话题吧。"

translate chinese chinese_4320056_50:
    old "About... Uhhh, what I wanted to talk to you [pla]."
    new "关于……呃，我想和你谈的事情[pla]。"

translate chinese chinese_0373387_51:
    old "Right, right, w- what is it?"
    new "好，好，你有什么事？"

translate chinese chinese_5230767_52:
    old "Well, there's something I want to let you know about."
    new "嗯，有些事情我想让你知道。"

translate chinese chinese_3740451_53:
    old "Something I- I've been keeping hidden about myself."
    new "有些我——我自己一直隐藏的事情。"

translate chinese chinese_2702551_54:
    old "Uhh... W- what is it?"
    new "呃……是什麼？"

translate chinese chinese_8275861_55:
    old "Well, I- I think it's easier if I show you..."
    new "嗯，我觉觉得还是演示给你看会比较简单……"

translate chinese chinese_8914341_56:
    old "This is it."
    new "就是这个。"

translate chinese chinese_7494303_57:
    old "Oh wow, w- what is this?"
    new "哦 wow，这这这是什么？"

translate chinese chinese_7884673_58:
    old "Well, not exactly."
    new "嗯，也不完全是。"

translate chinese chinese_6085990_59:
    old "I'm a webcam model, it's a little different."
    new "我是 webcam 模特，有点不一样。"

translate chinese chinese_1941402_60:
    old "This is something I've been doing for a while now."
    new "这事我已经做了很久了。"

translate chinese chinese_0715466_61:
    old "I started by streaming video games, and I enjoyed it a lot."
    new "我一开始是直播玩游戏，觉得很有趣。"

translate chinese chinese_7966739_62:
    old "Over time some of my followers started asking me about some..."
    new "后来，有些粉丝开始问我关于一些……"

translate chinese chinese_1860772_63:
    old "More adult content."
    new "更多成人内容。"

translate chinese chinese_6598707_64:
    old "I started thinking about it. And decided I should give it a go."
    new "我开始想了，觉得应该试一试。"

translate chinese chinese_1874404_65:
    old "After all, I like being in front of the cameras, and I figured it would be alright as long as my face wasn't shown."
    new "毕竟我喜欢站在镜头前，而且我觉得只要不露脸就没问题。"

translate chinese chinese_2615681_66:
    old "From then on, I kept getting deeper and deeper into it."
    new "从那以后，我越陷越深。"

translate chinese chinese_0939328_67:
    old "After all, I discovered I really enjoyed it."
    new "毕竟，我发现我真的喜欢它。"

translate chinese chinese_4014234_68:
    old "I've gotten a lot of experience doing this now."
    new "我现在做这个经验丰富多了。"

translate chinese chinese_7867557_69:
    old "I- I guess I get it."
    new "我——我大概明白了。"

translate chinese chinese_8492251_70:
    old "It's been good actually. I've even gotten to make some money off of it."
    new "其实还挺好，我甚至还靠这个赚了点钱。"

translate chinese chinese_1735290_71:
    old "Oh! That sounds good."
    new "哦！那听起来不错。"

translate chinese chinese_5363241_72:
    old "But why are you suddenly bringing this up?"
    new "但是你为什么突然提到这个？"

translate chinese chinese_4503509_73:
    old "It's just that I imagine this is the type of thing you would want to keep secret, right?"
    new "只是我觉得这种事你可能会想保密，对吧？"

translate chinese chinese_9640084_74:
    old "I guess, so. Yeah."
    new "我猜是这样吧。嗯。"

translate chinese chinese_2271297_75:
    old "But there's something happening, and I need some help with it."
    new "但是有些事情发生了，我需要帮忙。"

translate chinese chinese_0119886_76:
    old "And I think you're the one that could help me with it."
    new "而且我觉得你能帮我解决这个问题。"

translate chinese chinese_2371027_77:
    old "M- me?!"
    new "我...我吗？！"

translate chinese chinese_0804871_78:
    old "You see, this is only my first year camming."
    new "你看，这只是我做网播的第一年。"

translate chinese chinese_0426643_79:
    old "But my results have been very good. I have received a lot of fan engagement."
    new "但是我的成绩很好。我收到了很多粉丝的互动。"

translate chinese chinese_4134071_80:
    old "I even got nominated for an award!"
    new "我甚至还被提名了一个奖项！"

translate chinese chinese_8905371_81:
    old "That's great Belle!"
    new "太好了，贝尔！"

translate chinese chinese_1367642_82:
    old "Uh, I- I mean... I think so..."
    new "呃，我——我是说……应该是吧……"

translate chinese chinese_0369178_83:
    old "Yeah, it is. It's a {b}'Female Revelation Streamer of the Year.'{/b}"
    new "是的，这是一个{b}“年度女性启示主播”{/b}。"

translate chinese chinese_4722333_84:
    old "And I'm one of the forerunners for it!"
    new "而我可是其中的领先者之一！"

translate chinese chinese_3057548_85:
    old "I see, congrats Belle, that's awesome!"
    new "我明白了，恭喜贝儿，太棒了！"

translate chinese chinese_3725122_86:
    old "But all of that sounds very good."
    new "但听起来都很好。"

translate chinese chinese_1359196_87:
    old "I don't see what you could need my help with."
    new "我看不出你需要我帮忙的地方。"

translate chinese chinese_3410134_88:
    old "You see, these awards are measured as a popularity contest."
    new "你看，这些奖项其实就是个 popularity contest（人气比赛）。"

translate chinese chinese_7789835_89:
    old "So, the winner is decided by who gets the most fan votes and tips in their category by the end of the time period."
    new "所以，获胜者是由时间结束时每个类别中获得最多粉丝投票和打赏的人决定的。"

translate chinese chinese_4152905_90:
    old "The number of votes and tips each person receives is put into a public chart, so, we know who's in the lead."
    new "每个人收到的投票数和提示数都会公开显示在图表上，所以我们知道谁领先了。"

translate chinese chinese_8101073_91:
    old "Well, that's only until the final days of the contest."
    new "嗯，这只持续到比赛最后几天。"

translate chinese chinese_0512542_92:
    old "Some days before it's over the results are hidden and the winner is announced at the end."
    new "有时候结果会隐藏到结束，最后才公布获胜者。"

translate chinese chinese_5331068_93:
    old "I see."
    new "我明白了。"

translate chinese chinese_1290506_94:
    old "I've been doing pretty well on the polls."
    new "我在民调中表现得挺好的。"

translate chinese chinese_3937539_95:
    old "Since the beginning of the contest I have been at the top of the standings."
    new "自从比赛开始，我就一直名列前茅。"

translate chinese chinese_1237097_96:
    old "So much so that I thought I was going to win it easily."
    new "我以为我会轻易赢下来。"

translate chinese chinese_1792218_97:
    old "However, recently a new model has been getting all the attention."
    new "然而，最近一个新的模型吸引了所有人的注意。"

translate chinese chinese_2292677_98:
    old "There's this girl named Lana. She just appeared seemingly out of nowhere and overtook me."
    new "有个叫 Lana 的女孩，她突然出现，一下子就超过了我。"

translate chinese chinese_5352520_99:
    old "With the way things are going, she's going to run away with the lead, and beat me."
    new "照这样下去，她会一直领先并击败我的。"

translate chinese chinese_4852328_100:
    old "Oh, I'm sorry Belle, it sucks that something like this is happening."
    new "哦，贝儿，真抱歉，发生这样的事真糟糕。"

translate chinese chinese_6502221_101:
    old "Oh! It really does! Especially because she's not getting the lead in the competition fairly!"
    new "哦！真的呢！尤其是因为她根本不是公平竞争得来的主角位置！"

translate chinese chinese_7499770_102:
    old "Well, I've been thinking about why this girl is so popular."
    new "嗯，我在想为什么这个女孩这么受欢迎。"

translate chinese chinese_8491525_103:
    old "And I figured it out."
    new "而且我搞清楚了。"

translate chinese chinese_1499321_104:
    old "It's just because she's not doing the same things I and the other girls in the category are doing."
    new "就是因为她没有像我和分类里的其他女孩一样做那些事情。"

translate chinese chinese_5356859_105:
    old "Isn't she doing livestreams like the others?"
    new "她不像其他人那样做直播吗？"

translate chinese chinese_9943140_106:
    old "Yes, but, as I told you, the category in which I'm competing is called ‘Female Revelation Streamer of the Year.'"
    new "是的，但就像我告诉你的那样，我参赛的类别叫做“年度女性揭秘主播”。"

translate chinese chinese_4657943_107:
    old "It's a {i}single-person{/i} category."
    new "这是{i}单人{/i}类别。"

translate chinese chinese_2081657_108:
    old "Otherwise couples or even groups could take part and compete in it."
    new "否则情侣甚至多人组也可以参加并进行比赛。"

translate chinese chinese_9906113_109:
    old "But they have their own category."
    new "但他们有自己的分类。"

translate chinese chinese_3222738_110:
    old "However, she is doing streams with a guy..."
    new "然而，她正在和一个男生直播……"

translate chinese chinese_7959698_111:
    old "Obviously, this type of content is much more appealing to the audience since it's literally a sex live show."
    new "显然，这种内容对观众更有吸引力，因为它基本上就是一场性直播秀。"

translate chinese chinese_3259587_112:
    old "And this gives her a significant advantage over those of us who participate individually in our category..."
    new "这让她在我们这些单独参赛的人中占据了显著优势……"

translate chinese chinese_7041955_113:
    old "So she should be participating in another category, for example, {i}'Best Streamer couple of the Year'{/i}."
    new "所以她应该参加另一个类别，比如{i}“年度最佳主播情侣”{/i}。"

translate chinese chinese_0098314_114:
    old "I see, I suppose that makes sense."
    new "我明白了，这说得通。"

translate chinese chinese_2815207_115:
    old "Of course, that makes sense! I even thought they would move her to a different category or suspend her for doing a different type of content..."
    new "当然，这说得通！我还以为他们会把她移到另一个分类或者因为做不同类型的内容而暂停她..."

translate chinese chinese_0212654_116:
    old "But apparently, there aren't any rules against what she is doing to compete in this category..."
    new "但是看来她的竞争手段在这个类别里并没有被禁止……"

translate chinese chinese_4998126_117:
    old "Since when she was nominated in the category, she was doing solo streams."
    new "自从她在这个类别被提名后，就开始做单人直播了。"

translate chinese chinese_2670507_118:
    old "But then, does that mean she can do whatever she wants and win?"
    new "那岂不是意味着她想怎么来就怎么来，还能赢？"

translate chinese chinese_9638639_119:
    old "Taking advantage of doing things from other categories to get more attention?"
    new "借着做其他类的事情来博取更多关注？"

translate chinese chinese_4905375_120:
    old "Hmm, yes, I understand. If you look at it a certain way, it's like she's cheating."
    new "嗯，是的，我明白。换个角度看，她这算是作弊了。"

translate chinese chinese_3294456_121:
    old "That's exactly what I think too! But the webcam platform doesn't seem to care..."
    new "这正是我的想法！但那个 webcam 平台似乎不在乎……"

translate chinese chinese_2024977_122:
    old "After all, is not the same to see a couple fucking on screen, to just seeing somebody playing with a toy or something."
    new "毕竟，在屏幕上看到一对情侣做爱和看到某人只是玩玩具或什么的，感觉是不一样的。"

translate chinese chinese_0625186_123:
    old "And the problem with that is that she's only doing it to win..."
    new "问题在于她这么做只是为了获胜..."

translate chinese chinese_7716274_124:
    old "Which means she's only interested in winning in this category now, by using tactics that of course gain her more popularity here."
    new "这意味着她现在只对在这个领域获胜感兴趣，通过当然能在这里获得更多人气的策略。"

translate chinese chinese_0084819_125:
    old "Because she knows she wouldn't win doing what we do, or doing what she's doing in a couples category!"
    new "因为她知道，如果像我们这样去做，或者在情侣分类里做她正在做的事，她是赢不了的！"

translate chinese chinese_1565625_126:
    old "Look, this is a recording from a recent streaming she did."
    new "看，这是她最近直播的录像。"

translate chinese chinese_2810497_127:
    old "I know this is what you guys have been waiting for."
    new "我知道这正是你们期待的。"

translate chinese chinese_1205487_128:
    old "You all wanted to see me sucking a big cock didn't you?"
    new "你们都想要看我吸大 cock 对不对？"

translate chinese chinese_8644928_129:
    old "Do you see? She's practically doing live sex!"
    new "你看吗？她几乎是在进行现场性爱！"

translate chinese chinese_1739942_130:
    old "She shouldn't be in the 'Female Revelation Streamer' category!"
    new "她不应该被归类为“女性揭秘主播”！"

translate chinese chinese_9423721_131:
    old "I guess that her winning the contest by doing something that no one else is doing is unfair."
    new "我猜她通过做别人没做的事情赢得比赛是不公平的。"

translate chinese chinese_7709325_132:
    old "I get it, I get it."
    new "我知道了，我知道了。"

translate chinese chinese_8100132_133:
    old "And what are you planning to do about it?"
    new "那你打算怎么办？"

translate chinese chinese_3019436_134:
    old "Well, to be honest [pla]..."
    new "好吧，说老实话，[pla]..."

translate chinese chinese_9619594_135:
    old "I really like doing this, a lot."
    new "我真的很喜欢这样做。"

translate chinese chinese_7979635_136:
    old "I've worked so hard from the beginning."
    new "我从开始就努力了这么多。"

translate chinese chinese_2159837_137:
    old "And ever since I started I've put a lot of effort into being number one."
    new "自从开始以来，我就付出了很多努力来成为第一。"

translate chinese chinese_1496098_138:
    old "In fact, until just a few days ago I was first in the rankings."
    new "事实上，就在几天前我还在排行榜上排名第一。"

translate chinese chinese_8779970_139:
    old "So, I think I should be the one that wins that award!"
    new "所以，我觉得那个奖项应该颁给我！"

translate chinese chinese_1766736_140:
    old "Not some rando that just came out nowhere!"
    new "不是突然冒出来的什么随机路人！"

translate chinese chinese_3767148_141:
    old "So, I've decided that I'm going to retake the lead in the contest."
    new "所以，我决定要在比赛中重新取得领先。"

translate chinese chinese_6185566_142:
    old "That's where I want you to help me."
    new "那正是我要你帮忙的地方。"

translate chinese chinese_6044604_143:
    old "Uhm... H- how?"
    new "嗯……怎、怎么？"

translate chinese chinese_7572779_144:
    old "I want to fight fire with fire!"
    new "我要以牙还牙！"

translate chinese chinese_6012382_145:
    old "I want to see if she will actually beat me if both of us are doing the same."
    new "我想看看如果我们俩都这么做，她会不会真的打过我。"

translate chinese chinese_9278658_146:
    old "You want to record yourself having sex on camera?!"
    new "你想录下自己做爱的过程吗？！"

translate chinese chinese_7001728_147:
    old "W- Well... Technically we would be having s- sex live, but it would be recorded."
    new "嗯……严格来说我们会进行直播性爱，但是会录下来。"

translate chinese chinese_9930721_148:
    old "Well, yeah, that's why I need your help..."
    new "嗯，是啊，这就是为什么我需要你的帮助……"

translate chinese chinese_6854407_149:
    old "T- that way, I- I think I'll manage to get the votes to surpass Lana."
    new "那、那样的话，我觉、我觉得我能拿到足够的票数超过Lana。"

translate chinese chinese_5551252_150:
    old "That's not the point..."
    new "那不是重点……"

translate chinese chinese_6216706_151:
    old "I kinda get what you're saying, but, this is a little unexpected, you know?"
    new "我大概明白你的意思，但这有点出乎意料，你知道吗？"

translate chinese chinese_9835977_152:
    old "I- I know it is. But listen, I've put a lot of effort into this."
    new "我——我知道是这样的。但是听我说，我已经为此付出了很多努力。"

translate chinese chinese_6901185_153:
    old "From streaming video games to getting into camming, and growing my fanbase."
    new "从直播玩游戏到开始做摄像头直播，还扩大了我的粉丝群。"

translate chinese chinese_5881316_154:
    old "Losing is just not an option..."
    new "失败根本不是个选项……"

translate chinese chinese_3434223_155:
    old "So I need your help, please."
    new "所以我需要你的帮助，请。"

translate chinese chinese_0532923_156:
    old "It will only be a couple of times, only until I can overtake her."
    new "就几次而已，只到我能追上她为止。"

translate chinese chinese_0746912_157:
    old "I mean, I think I get it."
    new "我的意思是，我觉得我明白了。"

translate chinese chinese_6886742_158:
    old "What I don't understand is why it has to be me."
    new "我不明白的是为什么非得是我。"

translate chinese chinese_5192959_159:
    old "Don't you know somebody that knows about this sort of thing?"
    new "你不会认识懂这些事情的人吧？"

translate chinese chinese_2234872_160:
    old "You know... a professional?"
    new "你知道的……一个专业人士？"

translate chinese chinese_5773186_161:
    old "Actually, I don't know anybody... Any men, I mean."
    new "其实，我一个人都不认识……我是说男人。"

translate chinese chinese_9462893_162:
    old "I've been doing everything by myself."
    new "我一直在独自做这一切。"

translate chinese chinese_7885221_163:
    old "I haven't ever worked with anybody before, so I don't know any man inside this business that would do it."
    new "我之前从来没和别人合作过，所以不认识这里有什么人会这么做。"

translate chinese chinese_6603123_164:
    old "But if I'm completely honest with you [pla], even if I knew a webcam actor or model I would still prefer to do it with you."
    new "但说句实话，[pla]，即使我认识 webcam 演员或模特，我还是更愿意和你一起做这件事。"

translate chinese chinese_7210426_165:
    old "What? R- Really?"
    new "什么？真、真的？"

translate chinese chinese_7086091_166:
    old "Well, I don't want to do this with some unknown person. For me sex is a very intimate thing."
    new "好吧，我不愿意和一个不认识的人做这个。对我来说，性是一件非常私密的事情。"

translate chinese chinese_9999241_167:
    old "I at least want it to be with someone I trust."
    new "我至少希望是和一个我信任的人。"

translate chinese chinese_6931069_168:
    old "I- uh... I understand."
    new "我... 我明白。"

translate chinese chinese_2250219_169:
    old "But I'm don't know Belle. I don't think I want people watching me have sex on camera."
    new "但是我不认识贝尔。我觉得我不希望有人看着我做爱。"

translate chinese chinese_7122096_170:
    old "Besides, and I know this is kind of obvious... That also means that you and I would have to have sex, right?"
    new "再说，虽然这有点显而易见……那也意味着你和我得发生关系，对吧？"

translate chinese chinese_8388162_171:
    old "Are you ok with that?"
    new "你同意这样吗？"

translate chinese chinese_6099893_172:
    old "I- I do... As I told you [pla], I trust you."
    new "我……我确实……就像我告诉你的，[pla]，我相信你。"

translate chinese chinese_8583778_173:
    old "Also, is not as if you and I have never done that sort of thing before, right?"
    new "而且，也不是我们俩从来没有做过那种事吧？"

translate chinese chinese_0646158_174:
    old "This won't be too different from that."
    new "这和那不会太不一样的。"

translate chinese chinese_2945752_175:
    old "And about the whole appearing on camera thing, you don't have to worry about that."
    new "至于上镜的事情，你不用担心那个。"

translate chinese chinese_2903417_176:
    old "I will focus the camera so that your face doesn't show in any way."
    new "我会调整相机角度，确保你的脸不会出现。"

translate chinese chinese_9416926_177:
    old "Please [pla], I want to win this."
    new "求你了[pla]，我想赢这场比赛。"

translate chinese chinese_0015542_178:
    old "I know this is just what I need to win against Lana."
    new "我知道这正是我战胜 Lana 所需要的。"

translate chinese chinese_1960362_179:
    old "I guess it's fine if it helps you..."
    new "我想如果这能帮到你的话……也就算了。"

translate chinese chinese_9978556_180:
    old "So, you'll do it?"
    new "所以，你会答应吗？"

translate chinese chinese_7130561_181:
    old "I can't believe it, but I will."
    new "我不敢相信，但我会接受的。"

translate chinese chinese_2641505_182:
    old "Thanks a lot [pla]!"
    new "多谢[pla]！"

translate chinese chinese_3170793_183:
    old "So, I have to prepare everything on stream."
    new "所以，我得在直播中准备一切。"

translate chinese chinese_6249541_184:
    old "I have to let my fans know about it."
    new "我得让我粉丝们知道这件事。"

translate chinese chinese_1170256_185:
    old "Let them know there's a surprise coming and stuff."
    new "让他们知道有个惊喜要来了之类的。"

translate chinese chinese_0757546_186:
    old "I'll let you know when we'll do it."
    new "等我们什么时候做，我会通知你的。"

translate chinese chinese_3694168_187:
    old "Thanks a lot [pla]."
    new "谢谢你[pla]。"

translate chinese chinese_5637529_188:
    old "So... "
    new "所以……"

translate chinese chinese_9812816_189:
    old "I think I'll see you later then."
    new "那我一会儿再找你吧。"

translate chinese chinese_6707043_190:
    old "Sure, I'll prepare everything and let you know when we're ready to stream."
    new "好的，我会准备好一切，到时候直播前会通知你。"

translate chinese chinese_6344608_191:
    old "Alright, great!"
    new "好，太棒了！"

translate chinese chinese_6312942_192:
    old "Bye Belle."
    new "再见，贝尔。"

translate chinese chinese_5457784_193:
    old "Bye [pla], and thank you so much again."
    new "再见[pla]，再次非常感谢你。"

translate chinese chinese_8560703_194:
    old "Hi Belle, good morning, how are you?"
    new "嗨，贝儿，早上好，你怎么样？"

translate chinese chinese_5879709_195:
    old "Listen [pla], my mother told me she won't be in the house this afternoon."
    new "听好了[pla]，我妈妈告诉我她今天下午不在家。"

translate chinese chinese_7690308_196:
    old "She has a meeting or something."
    new "她有个会议或者什么的。"

translate chinese chinese_4598997_197:
    old "So, today can be the first day that you come and help me with my stream."
    new "所以，今天可以是你来帮我直播的第一天。"

translate chinese chinese_6192134_198:
    old "Plus, I think this is a good opportunity for you to make your first appearance on camera."
    new "而且，我觉得这是一个很好的机会让你第一次在镜头前亮相。"

translate chinese chinese_0388867_199:
    old "So that you can get a feel for it, and start getting used to beign on camera."
    new "这样你可以先适应一下，开始习惯在镜头前出现。"

translate chinese chinese_6936850_200:
    old "O- ok sure, no problem."
    new "好 sure，没问题。"

translate chinese chinese_6454788_201:
    old "L- lets do it."
    new "好，我们开始吧。"

translate chinese chinese_0735544_202:
    old "Ok, great!"
    new "好，太棒了！"

translate chinese chinese_7052136_203:
    old "Come to my house in the afternoon."
    new "下午来我家。"

translate chinese chinese_0964327_204:
    old "I thought I would go with you right after we finished classes."
    new "我以为我们下课后就会一起去。"

translate chinese chinese_3843098_205:
    old "No, I will skip classes today. I need to go home and get everything ready for the stream. I just came to let you know."
    new "不，我今天要逃课，回家准备直播。我只是来告诉你一声。"

translate chinese chinese_4696122_206:
    old "Alright, no problem."
    new "好吧，没问题。"

translate chinese chinese_2915344_207:
    old "So, see you later at my house."
    new "那，待会儿我家见。"

translate chinese chinese_6105135_208:
    old "Ok, I think Belle must be waiting for me..."
    new "好吧，我觉得贝尔一定在等我……"

translate chinese chinese_7251653_209:
    old "Phew, I don't know how I always get myself into these things..."
    new "呼，我不知道我怎么总是把自己卷进这些事里……"

translate chinese chinese_4274242_210:
    old "Oh! Hello."
    new "哦！你好。"

translate chinese chinese_6720031_211:
    old "Uh... H- hi, g- good afternoon."
    new "呃……嗨，好……下午好。"

translate chinese chinese_9825373_212:
    old "Good afternoon. Can I help you with something?"
    new "下午好。有什么可以帮你的吗？"

translate chinese chinese_9644737_213:
    old "I- uh... yes, I'm [pla], I'm a friend of Belle."
    new "我……嗯……是的，我是[pla]，我是Belle的朋友。"

translate chinese chinese_7903954_214:
    old "I- I came to do some... Uh, s- schoolwork with her."
    new "我……我是来找她一起做……嗯，做作业的。"

translate chinese chinese_4691208_215:
    old "Oh! Nice meeting you [pla]! My name is Ashley, I'm Belle's mother."
    new "哦！见到你真高兴，[pla]！我叫Ashley，是Belle的妈妈。"

translate chinese chinese_7317137_216:
    old "H- Hi..."
    new "哈...你好..."

translate chinese chinese_0694687_217:
    old "{i}(Her mother? Belle told me she wouldn't be here. I guess I should ask her about Belle.){/i}"
    new "{i}（她妈妈？贝尔告诉我她不会在这里。我想我应该去问问她关于贝尔的事。){/i}"

translate chinese chinese_7496033_218:
    old "Excuse me Mrs. Ashley..."
    new "不好意思，阿什利夫人..."

translate chinese chinese_4116466_219:
    old "Mrs. Ashley? Haha, oh dear no, just call me Ashley. I'm too young to have anyone call me Mrs."
    new "艾希莉夫人？哈哈，哦天哪不，就叫我艾希莉吧。我还太年轻，不想让人叫夫人。"

translate chinese chinese_6910616_220:
    old "O- ok, A- Ashley. Is Belle around? She told me to come at this time."
    new "好、好的，艾什利。贝尔在吗？她让我这个时候来的。"

translate chinese chinese_1995444_221:
    old "She is dear, she's in her bedroom."
    new "她在卧室里。"

translate chinese chinese_6042937_222:
    old "I'll let her know you're here."
    new "我会告诉她你在这里。"

translate chinese chinese_5730741_223:
    old "T- thanks."
    new "谢、谢谢。"

translate chinese chinese_3532451_224:
    old "[pla]! H- hi! I- I didn't notice you arrived! Sorry."
    new "[pla]！嗨！我、我没注意到你来了！对不起。"

translate chinese chinese_6093803_225:
    old "Mom, why didn't you tell me a visit for me had arrived?"
    new "妈妈，为什么你不告诉我有人来看我呢？"

translate chinese chinese_0913756_226:
    old "Well sweety, you didn't tell me you were expecting anyone."
    new "好吧，甜心，你没告诉我你会有人来。"

translate chinese chinese_5169821_227:
    old "But I was just about to come and tell you your friend had arrived."
    new "但我正准备过来告诉你你的朋友到了。"

translate chinese chinese_2111035_228:
    old "I- I see...."
    new "我……明白了……"

translate chinese chinese_3221441_229:
    old "Anyway mom, [pla] and I are going to be working in my room."
    new "总之妈妈，我和[pla]要在我的房间里工作。"

translate chinese chinese_2162512_230:
    old "So, it would be nice if you could avoid interrupting us."
    new "所以，如果你能避免打断我们就更好了。"

translate chinese chinese_0387729_231:
    old "Well, I guess I'll do my best not to bother you, sweetheart."
    new "好吧，我想我会尽量不打扰你，亲爱的。"

translate chinese chinese_4921165_232:
    old "Come on [pla], let's go."
    new "快来吧，[pla]，我们走。"

translate chinese chinese_6392566_233:
    old "Hey, what's up? I thought you said she wasn't going to be here today?"
    new "嘿，怎么了？你不是说她今天不来吗？"

translate chinese chinese_7549824_234:
    old "Yeah I know, sorry"
    new "我知道，对不起"

translate chinese chinese_6573257_235:
    old "She just suddenly came back home and said she was going to work from home today."
    new "她突然回家说今天要在家办公。"

translate chinese chinese_6134987_236:
    old "I don't know why, I guess something happened at the office."
    new "我不知道为什么，可能是办公室出了什么事。"

translate chinese chinese_5120450_237:
    old "Hmm ok, yeah, I understand."
    new "嗯，好的，我知道了。"

translate chinese chinese_1598674_238:
    old "I suppose we're not streaming today then."
    new "看来今天我们不直播了。"

translate chinese chinese_5610643_239:
    old "Yep, we can't do the stream with my mother here."
    new "没错，我妈妈在这里我们不能开直播。"

translate chinese chinese_2952729_240:
    old "She could come in at any time."
    new "她随时都可能进来。"

translate chinese chinese_9178428_241:
    old "She'll be bringing some snacks, or knocking on the door to see how we're doing, or something."
    new "她会带些零食过来，或者敲门看看我们怎么样了，之类的。"

translate chinese chinese_6994215_242:
    old "My mom's very controlling, and she'll want to know what we're doing here."
    new "我妈妈很控制欲强，她会想知道我们在这里干什么。"

translate chinese chinese_6840424_243:
    old "So, it's better if we don't risk being caught in the middle of it."
    new "所以，最好不要冒险被卷进去。"

translate chinese chinese_4456822_244:
    old "I'm sorry [pla]... that ruins our plans for today."
    new "对不起 [pla]... 这样我们的今天计划泡汤了。"

translate chinese chinese_9421597_245:
    old "I'm sorry to have you come here for nothing."
    new "真抱歉让你白跑一趟。"

translate chinese chinese_7732841_246:
    old "Oh, don't worry. We can do it on any other day. I'll head back home then."
    new "哦，别担心。我们可以改天再做。那我先回家了。"

translate chinese chinese_6393486_247:
    old "Well, maybe you should stay for a little while."
    new "嗯，也许你应该再待一会儿。"

translate chinese chinese_7529395_248:
    old "After all, you just got here. My mom could get suspicious if you leave just after arriving."
    new "毕竟你刚到，如果你刚来就走，我妈妈可能会起疑心。"

translate chinese chinese_9928987_249:
    old "Ok, so what are we going to do?"
    new "好吧，那我们接下来做什么？"

translate chinese chinese_7284195_250:
    old "I was thinking I could let you know a bit more about this whole camming thing, how it works and stuff."
    new "我在想我可以让你更多地了解这个直播的事情，它是怎么运作的之类的。"

translate chinese chinese_5685138_251:
    old "Oh, ok sure."
    new "哦，好的。"

translate chinese chinese_4181889_252:
    old "So, the way the stream works is through a {i}'tips'{/i} system."
    new "所以，直播的工作机制是通过一个{i}“打赏”{/i}系统来运行的。"

translate chinese chinese_6540706_253:
    old "While we're doing it, that's the most important thing to keep in mind."
    new "我们在做这件事的时候，这是最重要的事情。"

translate chinese chinese_0311145_254:
    old "And whatever I'm going to do, I do it live, instead of having it pre-recorded, like in porn."
    new "不管我要做什么，我都是现场直播的，而不是像色情片那样预先录好的。"

translate chinese chinese_9644502_255:
    old "Since everything is completely live, tips are very important."
    new "由于一切都是现场直播，小费非常重要。"

translate chinese chinese_9331953_256:
    old "Why?"
    new "为什么？"

translate chinese chinese_2373355_257:
    old "Well, because the livestream is a type of show."
    new "因为直播就是一种表演。"

translate chinese chinese_8373221_258:
    old "Which means that my fans have to be engage and entertained."
    new "这意味着我的粉丝们需要被吸引和娱乐。"

translate chinese chinese_6447877_259:
    old "And the only reliable way I can gauge if they really like it, is by seeing their tips."
    new "而我能判断他们是否真的喜欢的唯一可靠方法就是看小费。"

translate chinese chinese_5833780_260:
    old "So, the whole objective of each time I'm on camera is to get them to tip."
    new "所以，每次我上镜的目的就是让他们给小费。"

translate chinese chinese_0277093_261:
    old "Uhh... I see."
    new "呃……我明白了。"

translate chinese chinese_9856369_262:
    old "So, whenever the stream starts, I have to set up some {i}'goals'{/i}."
    new "所以，每次直播开始时，我得设定一些{i}“目标”{/i}。"

translate chinese chinese_8813255_263:
    old "Which is the number of tips I want my fans to give me before I do anything."
    new "这是我做任何事之前希望粉丝给我的打赏数目。"

translate chinese chinese_3551190_264:
    old "If the audience matches the goals by tipping, I do what I promised for that goal, and move into the next one."
    new "如果观众通过打赏达成目标，我就履行那个目标的承诺，然后进入下一个目标。"

translate chinese chinese_6755156_265:
    old "I think I get it."
    new "我想我明白了。"

translate chinese chinese_7845704_266:
    old "So, whether we do something or not, depends on the audience?"
    new "所以，做不做某件事取决于观众？"

translate chinese chinese_1583625_267:
    old "That's right, we decide what to do, but we only do it if the goal is met."
    new "没错，我们决定做什么，但只有达到目标才会去做。"

translate chinese chinese_5066251_268:
    old "That sounds simple."
    new "听起来很简单。"

translate chinese chinese_6108518_269:
    old "Well, it's all about personality, and how much you connect with the audience, you know?"
    new "嗯，这主要是关于个性，以及你与观众的连接程度，你知道的？"

translate chinese chinese_4761373_270:
    old "So it's important to talk to them, try and pay attention to their comments, and the demands they make."
    new "所以和他们交流很重要，尽量注意他们的评论和提出的要求。"

translate chinese chinese_5125670_271:
    old "That makes sense."
    new "说得通。"

translate chinese chinese_9911733_272:
    old "And as I told you before, you don't need to talk or interact with them."
    new "就像我之前告诉你的，你不需要和他们说话或互动。"

translate chinese chinese_7827478_273:
    old "After all, my fans want to see me doing something with a... w- with a penis."
    new "毕竟，我的粉丝想看到我和一个...和一个阳具做的事情。"

translate chinese chinese_7443957_274:
    old "But they don't really want to get to know you."
    new "但他们真的不想了解你。"

translate chinese chinese_9294865_275:
    old "T- the most important is for you to... have a b- boner during the show."
    new "你…最重要的就是在表演时…硬起来。"

translate chinese chinese_6283040_276:
    old "I- I'll take care of the rest."
    new "我来处理剩下的吧。"

translate chinese chinese_2696731_277:
    old "Well... I- I guess I can manage that."
    new "嗯……我—我猜我可以搞定。"

translate chinese chinese_8284778_278:
    old "Hey guys! How are you doing?"
    new "嘿，大家好！你们怎么样？"

translate chinese chinese_4031931_279:
    old "Uhmm, we're doing fine mom."
    new "嗯，我们挺好的，妈妈。"

translate chinese chinese_7211454_280:
    old "But I would've appreciated it if you'd knocked on the door before entering."
    new "不过如果你进来前敲一下门就更好了。"

translate chinese chinese_3861861_281:
    old "I'm sorry honey, but I just wanted to see if you needed anything."
    new "宝贝，对不起，我只是想看看你需不需要什么。"

translate chinese chinese_2502724_282:
    old "Maybe you would like me to bring you some snacks?"
    new "maybe你喜欢我给你带些零食来？"

translate chinese chinese_0610360_283:
    old "I think we're fine mom, thank you."
    new "妈妈，我觉得我们挺好的，谢谢。"

translate chinese chinese_0853762_284:
    old "Ok sweety, I'll leave for now then."
    new "好吧，宝贝，那我现在就先走了。"

translate chinese chinese_7533998_285:
    old "But if you two need anything, just let me know."
    new "但你们如果需要什么，尽管告诉我。"

translate chinese chinese_8230206_286:
    old "Yeah, right, thank you..."
    new "是的，谢谢……"

translate chinese chinese_5148973_287:
    old "Sorry, she just came in unannounced."
    new "抱歉，她突然就进来了。"

translate chinese chinese_9680492_288:
    old "It's ok, we kinda knew she was going to do that."
    new "没事，我们多少有点预料到她会那样做。"

translate chinese chinese_5791417_289:
    old "Yeah... but that's why we can't do anything whenever she's here."
    new "嗯……但就是因为她在，我们才什么都做不了。"

translate chinese chinese_5417105_290:
    old "Y- yeah, I- I get it..."
    new "嗯，我懂了……"

translate chinese chinese_4229347_291:
    old "Well, anyway, t- there hasn't been enough time since you came here."
    new "嗯，不管怎样，你来这里的时间还不够长。"

translate chinese chinese_4088099_292:
    old "So, why don't I show you the webcam platform in the meantime?"
    new "那么，要不我先带你看看 webcam 平台吧？"

translate chinese chinese_8199437_293:
    old "Yeah... sure."
    new "嗯……好吧。"

translate chinese chinese_6104235_294:
    old "Ok, this is my profile..."
    new "好的，这是我的资料……"

translate chinese chinese_8969016_295:
    old "Ok [pla], I think that should be enough time for my mom not to suspect anything."
    new "好了 [pla]，我觉得这样应该足够让我妈不会起疑了。"

translate chinese chinese_3028444_296:
    old "I'll let you know when it's ok for you to come again."
    new "等我可以让你再来的时候会通知你的。"

translate chinese chinese_2100113_297:
    old "Yeah, sure, just tell me when and I'll come to help you."
    new "行吧，你告诉我时间，我来帮你。"

translate chinese chinese_7860583_298:
    old "You're welcome Belle, I'm happy to help you."
    new "不客气贝尔，我很乐意帮你。"

translate chinese chinese_0577313_299:
    old "I hope next time we won't have any problems streaming."
    new "希望下次直播不会有什么问题。"

translate chinese chinese_0263590_300:
    old "The voting period is closing soon, and we won't be able to do anything if we have to postpone it too much."
    new "投票期快要结束了，如果我们再推迟的话就来不及了。"

translate chinese chinese_2846842_301:
    old "I get it, but what happened today was just unexpected."
    new "我明白，但今天发生的事真是没想到。"

translate chinese chinese_8704246_302:
    old "I bet there won't be any problem going forward."
    new "我敢打赌接下来不会有任何问题。"

translate chinese chinese_5600914_303:
    old "Yeah, you're probably right."
    new "嗯，你probably说得对。"

translate chinese chinese_2817548_304:
    old "So, listen... I guess I should get going, right?"
    new "所以，听我说……我想我该走了，对吧？"

translate chinese chinese_9549404_305:
    old "Sure, I'll see you later [pla], thanks again for coming."
    new "好的，一会儿见[pla]，感谢你来的这段时间。"

translate chinese chinese_9474192_306:
    old "You're welcome, see you later Belle."
    new "不客气，再见贝拉。"

translate chinese chinese_4736403_307:
    old "Hi [pla]!"
    new "嗨 [pla]！"

translate chinese chinese_1210953_308:
    old "Hi Belle."
    new "嗨，贝儿。"

translate chinese chinese_3936235_309:
    old "Uhm, I'm doing well, and you?"
    new "嗯，我挺好的，你呢？"

translate chinese chinese_8502090_310:
    old "So listen, after you left, my mom said it was very nice to meet you."
    new "所以听我说，你走后，我妈妈说很高兴见到你。"

translate chinese chinese_1155173_311:
    old "S- she did?"
    new "她真的做了？"

translate chinese chinese_9847937_312:
    old "Yeah, she said that you seemed to be a good person."
    new "嗯，她说你觉得你好像挺好的。"

translate chinese chinese_3764786_313:
    old "I- I guess that's nice."
    new "我——我猜这挺好的。"

translate chinese chinese_9377464_314:
    old "It is, when she met Mike she went on an on about how rude he was."
    new "当时她见到迈克的时候，一直在说他有多粗鲁。"

translate chinese chinese_8726992_315:
    old "So, I'm glad she liked you."
    new "所以，我很高兴她喜欢你。"

translate chinese chinese_3450006_316:
    old "Uhh, w- well, that's great."
    new "呃，嗯，那很好。"

translate chinese chinese_2959770_317:
    old "Yeah, that may make things easier in the future."
    new "嗯，这样将来可能会轻松些。"

translate chinese chinese_8685763_318:
    old "But leaving that aside, my mom told me she won't be home this afternoon."
    new "不过撇开那个不说，我妈妈告诉我今天下午不会在家。"

translate chinese chinese_3468266_319:
    old "So we can start streaming today!"
    new "所以我们今天就可以开始直播了！"

translate chinese chinese_1901775_320:
    old "Ok... that sounds alright."
    new "好吧……听起来还行。"

translate chinese chinese_0444274_321:
    old "Ok, let's go to my house after classes then."
    new "好的，那下课后去我家吧。"

translate chinese chinese_1773522_322:
    old "Ok, let's go to my house then."
    new "好吧，那我们去我家吧。"

translate chinese chinese_0920769_323:
    old "Alright, before we begin there's a couple of things we have to check."
    new "好的，在开始之前有几件事我们要确认一下。"

translate chinese chinese_6247947_324:
    old "Oh... Ok."
    new "哦……好的。"

translate chinese chinese_1588381_325:
    old "You remember what I told you about how it's important to talk to the audience, right?"
    new "你还记得我告诉过你跟观众交流很重要吧？"

translate chinese chinese_6266925_326:
    old "You also remember that I told you I'm the one who's going to be talking to them, right?"
    new "你还记得我说过我会去跟他们谈吗？"

translate chinese chinese_0877501_327:
    old "Yeah, I do, no problem."
    new "嗯，我可以，没问题。"

translate chinese chinese_3833247_328:
    old "Ok, I already announced that I was going to have a big surprise in today's stream."
    new "好的，我已经宣布今天直播有个大惊喜。"

translate chinese chinese_7818232_329:
    old "So, I'll come in on stream and start the whole thing."
    new "所以，我会进直播开始整个过程。"

translate chinese chinese_3138791_330:
    old "Talking to the audience, and when it's the right time, I'll tell you to come in."
    new "对着观众说话，到时候我会让你进场的。"

translate chinese chinese_1962133_331:
    old "Ok, I understand."
    new "好的，我明白了。"

translate chinese chinese_6766996_332:
    old "The camera will be pointing in my direction."
    new "相机将会对着我。"

translate chinese chinese_2242116_333:
    old "You'll wait out of frame while I start the stream, and when I tell you, you come in."
    new "你在画面外等着，等我开始直播，我会告诉你什么时候进来。"

translate chinese chinese_4489156_334:
    old "By the way, you won't be naked from the beginning... J- just wearing your shorts will be ok."
    new "对了，你不会从一开始就裸着……就穿个短裤也行。"

translate chinese chinese_7111215_335:
    old "Ok, I think I get it."
    new "好的，我觉得我明白了。"

translate chinese chinese_6175196_336:
    old "You know, [pla], I'm very thankful to you for doing this."
    new "你知道吗，[pla]，我非常感谢你这么做。"

translate chinese chinese_6242992_337:
    old "I know this is new for you, and you're probably not very comfortable with it."
    new "我知道这对你来说是新的，你可能不太适应。"

translate chinese chinese_7804368_338:
    old "So it means a lot to me that you're willing to help me this way."
    new "所以你愿意这样帮我对我来说意义重大。"

translate chinese chinese_0505955_339:
    old "I will admit I was very surprised when you asked me to do this."
    new "我得说，你让我做这件事的时候，我真的很惊讶。"

translate chinese chinese_3984515_340:
    old "But you're a very good friend, and if this is important for you, then I'm happy to help you."
    new "但是你是个非常好的朋友，如果这对你很重要，那我很乐意帮你。"

translate chinese chinese_5455514_341:
    old "Now, we should go to my room."
    new "现在，我们应该去我的房间。"

translate chinese chinese_0266659_342:
    old "Now, before we start, I have to change. Wait here a minute."
    new "好了，在开始之前，我得换一下衣服。你在这里等我一会儿。"

translate chinese chinese_3458230_343:
    old "What are you making that face for?"
    new "你干嘛做出那样的表情？"

translate chinese chinese_9584486_344:
    old "Oh, n- nothing, you just..."
    new "哦，没，没什么，你刚才..."

translate chinese chinese_3704368_345:
    old "I- I wasn't expecting it."
    new "我——我真的没想到。"

translate chinese chinese_5187815_346:
    old "Well... thank you."
    new "嗯……谢谢。"

translate chinese chinese_0644561_347:
    old "So, I'll start with the stream, and let you know when to come into frame, ok?"
    new "好的，我先开始直播，到时候告诉你什么时候入镜，好吗？"

translate chinese chinese_0806270_348:
    old "Right, sure."
    new "好吧，行。"

translate chinese chinese_5775624_349:
    old "Ok guys!"
    new "好了，大家！"

translate chinese chinese_5854725_350:
    old "Hello! Are you all ready for a new session?"
    new "喂！准备好开始新的环节了吗？"

translate chinese chinese_9808932_351:
    old "I've missed you guys!"
    new "我好想你们啊！"

translate chinese chinese_1718060_352:
    old "Yes, I know I didn't stream the other day when I told you I would."
    new "是的，我知道我那天没有像说好的那样开直播。"

translate chinese chinese_8817615_353:
    old "But something came up, and it became impossible to start the stream."
    new "但是有些事情发生了，导致开播变得不可能了。"

translate chinese chinese_1821068_354:
    old "But I'm going to make it up to you guys!"
    new "但我一定会补偿大家的！"

translate chinese chinese_2607410_355:
    old "As I promised you, I have a big surprise today!"
    new "就像我答应你的，今天有个大惊喜！"

translate chinese chinese_7193003_356:
    old "This is something a lot of you have been asking me about!"
    new "这是很多你们一直想问我的问题！"

translate chinese chinese_6460057_357:
    old "So I decided to treat you!"
    new "所以我决定请你！"

translate chinese chinese_2911766_358:
    old "This is my first time doing something like this on camera. So I'm a little nervous."
    new "这是我第一次在镜头前做这种事，所以有点紧张。"

translate chinese chinese_3208283_359:
    old "But I bet that if you show me your support by tipping, I'll feel a lot better."
    new "但如果你通过打赏来支持我，我肯定会感觉好很多。"

translate chinese chinese_3288601_360:
    old "Now, do you want to see the surprise I have in store for you?"
    new "现在，你想看看我为你准备的惊喜吗？"

translate chinese chinese_3486519_361:
    old "This person is a very good friend of mine. And he's very excited to be joining me here in the stream today!"
    new "这个人是我的一个非常好的朋友。他今天非常兴奋能来我的直播间！"

translate chinese chinese_5790882_362:
    old "Say hi to him!"
    new "跟他打个招呼！"

translate chinese chinese_6139764_363:
    old "Everyone, my friend is here because I promised you that you would see me having some fun with a real dick!"
    new "大家，我的朋友来了，因为我答应过你们会看到我和真正的家伙玩得开心！"

translate chinese chinese_4114871_364:
    old "And he came to help me with it."
    new "而且他还来帮我处理这件事。"

translate chinese chinese_0254286_365:
    old "Why don't we see what he's hiding under these shorts then?"
    new "那我们就来看看他短裤底下藏着什么吧？"

translate chinese chinese_6348261_366:
    old "Oh my god! Look at how big it is!"
    new "天啊！看看它有多大！"

translate chinese chinese_4665858_367:
    old "I bet you want to see me play with this big dick, right?"
    new "我敢打赌，你想看我玩这个大鸡巴，对吧？"

translate chinese chinese_7472944_368:
    old "You want me to care for it, and play with it, don't you?"
    new "你想让我照顾它，还陪它玩，对吧？"

translate chinese chinese_1410152_369:
    old "Let's not wait anymore for it then!"
    new "那我们就不再等了！"

translate chinese chinese_7311821_370:
    old "Oh! You have been waiting to see me play with your dick, haven't you?"
    new "哦！你一直在等看我玩你的棒棒，对吧？"

translate chinese chinese_7576133_371:
    old "I bet you love the way I stroke your big, thick, dick!"
    new "我敢打赌你肯定喜欢我这样抚摸你那粗大的家伙！"

translate chinese chinese_7388959_372:
    old "I knew you were going to love what I had in store for you!"
    new "我就知道你会喜欢我为你准备的东西！"

translate chinese chinese_5787927_373:
    old "Thanks a lot for accomplishing the goals!"
    new "感谢你完成了目标！"

translate chinese chinese_7426925_374:
    old "You guys have made me very happy!"
    new "你们让我很开心！"

translate chinese chinese_7468525_375:
    old "Now, sadly is time for me to disconnect, but be sure I'll come back soon."
    new "现在，遗憾的是我得下线了，但肯定会很快回来的。"

translate chinese chinese_3140428_376:
    old "And, of course, my friend will be here, accompanying us once again."
    new "当然了，我的朋友也会在这里，再次陪我们一起。"

translate chinese chinese_9793701_377:
    old "Don't forget to subscribe to the stream!"
    new "别忘了订阅直播！"

translate chinese chinese_4423640_378:
    old "So you will get a notification the next time I'm online guys!"
    new "所以下次我上线的时候你们就会收到通知了！"

translate chinese chinese_2814476_379:
    old "And of course, don't forget to check all my socials!"
    new "当然了，别忘了关注我所有的社交账号！"

translate chinese chinese_7727952_380:
    old "Thanks a lot guys!"
    new "谢谢大家！"

translate chinese chinese_3885147_381:
    old "See you soon..."
    new "很快见..."

translate chinese chinese_7732304_382:
    old "It's amazing how many tips we got!"
    new "真没想到我们收到了这么多建议！"

translate chinese chinese_0728706_383:
    old "I already thought that we were going to do well because my fans had never seen me doing something like this."
    new "我本来就已经觉得我们会做得很好，因为我的粉丝们从来没有见过我这样做。"

translate chinese chinese_9140395_384:
    old "But this is far more than I expected!"
    new "但这远超我的预期！"

translate chinese chinese_2316274_385:
    old "They really came through with the tipping!"
    new "他们真是下足了本钱！"

translate chinese chinese_8576740_386:
    old "We reached the goal in no time!"
    new "我们很快就达到目标了！"

translate chinese chinese_1577311_387:
    old "I'm very happy that it all came out better than you expected Belle."
    new "我很高兴这一切都比你预期的要好，贝勒。"

translate chinese chinese_9863825_388:
    old "That's very good."
    new "很好。"

translate chinese chinese_9682851_389:
    old "Do you think that with this you'll surpass Lana in the voting?"
    new "你认为这样就能在投票中超过 Lana 了吗？"

translate chinese chinese_9435613_390:
    old "It's hard to tell, I think I will."
    new "很难说，我想我会去的。"

translate chinese chinese_6228036_391:
    old "But only temporarily, with this type of thing you never know for certain who's going to win until the end."
    new "但只是暂时的，这种事直到最后你都不可能确定谁会赢。"

translate chinese chinese_8495245_392:
    old "Does that mean you're going to need my help on another occasion?"
    new "那意思是你以后还需要我的帮忙吗？"

translate chinese chinese_7555867_393:
    old "Oh, don't doubt it! This is only the first time you're appearing on camera with me."
    new "哦，别怀疑了！这只不过是第一次和我一起出镜而已。"

translate chinese chinese_5012846_394:
    old "And I'm very thankful for that [pla]."
    new "对此我非常感激 [pla]。"

translate chinese chinese_5230934_395:
    old "Well, I'm happy to help."
    new "好吧，我很乐意帮忙。"

translate chinese chinese_6435627_396:
    old "Thanks [pla]."
    new "谢谢[pla]。"

translate chinese chinese_7338841_397:
    old "{i}W- what is she doing here?! Wasn't she going to be out today?!{/i}"
    new "{i}她来这里干什么？！今天不是说她要出去吗？！{/i}"

translate chinese chinese_3655628_398:
    old "{i}I don't know!{/i}"
    new "{i}我不知道！{/i}"

translate chinese chinese_3459136_399:
    old "{i}Maybe she had some problems at work or something like that.{/i}"
    new "{i}也许她在工作中遇到了一些问题，或者其他类似的事情。{/i}"

translate chinese chinese_3234472_400:
    old "{i}You better answer her, or else she's going to come here to see if everything is alright.{i}"
    new "你最好回答她，不然她会过来确认是否一切都好。"

translate chinese chinese_0136416_401:
    old "{i}Yeah, you're right.{i}"
    new "{i}嗯，你说得对。{i}"

translate chinese chinese_5960182_402:
    old "I'm here mom! I... I was just doing some schoolwork!"
    new "我在这儿妈妈！我……我刚才就在做作业！"

translate chinese chinese_1849421_403:
    old "I see honey, ok!"
    new "我知道了，好啦！"

translate chinese chinese_3694889_404:
    old "I think we better get dressed up and get out of here before she comes to check on me and sees us like this."
    new "我觉得我们最好赶紧穿好衣服离开这里，免得她过来检查时看到我们这副样子。"

translate chinese chinese_2259757_405:
    old "Yeah, yeah, you're right."
    new "嗯嗯，你说得对。"

translate chinese chinese_5000428_406:
    old "Oh [pla], hi, I didn't know you were here."
    new "哦，[pla]，你好，我不知道你在这里。"

translate chinese chinese_0879275_407:
    old "H- hi, uh... A- Ashley."
    new "嗨，呃……阿什利。"

translate chinese chinese_2241280_408:
    old "It's good seeing you again dear."
    new "亲爱的，再次见到你真好。"

translate chinese chinese_6123712_409:
    old "Are you guys working on that school work you told me about?"
    new "你们在做之前告诉我的那个学校作业吗？"

translate chinese chinese_7313469_410:
    old "Uh... y- yeah, t- that's right."
    new "呃……对、对，就是这样。"

translate chinese chinese_8224861_411:
    old "What are you doing home mom? I thought you had that important meeting you had talked about."
    new "妈妈，你怎么在家里？我以为你有个很重要的会议要参加。"

translate chinese chinese_8385458_412:
    old "Oh honey, you won't believe what just happened!"
    new "哦亲爱的，你猜刚才发生了什么！"

translate chinese chinese_7457532_413:
    old "Today was supposed to be my first planning meeting with my team."
    new "今天本来是我第一次和团队开计划会议。"

translate chinese chinese_6187540_414:
    old "You know, so we could make a marketing plan to show our clients."
    new "你知道的，这样我们可以制定一个营销计划给客户看。"

translate chinese chinese_7296420_415:
    old "But the web developer I had hired suddenly backed out of the deal!"
    new "但是那个我雇来的网页开发者突然退出了！"

translate chinese chinese_6308513_416:
    old "Apparently he got a better job offer, and decided to take it."
    new "看来他得到了一份更好的工作offer，就决定去那边了。"

translate chinese chinese_0196719_417:
    old "But he didn't even give me a heads up or anything, he just bailed without notice!"
    new "但他连个招呼都没打，就突然消失了！"

translate chinese chinese_4172557_418:
    old "What am I going to do now?"
    new "我现在该怎么办？"

translate chinese chinese_2981468_419:
    old "Can't you just replace him, mom? I'm sure there must be someone out there that you can hire."
    new "妈，你不能找个代替的吗？我相信外面肯定有人可以雇来的。"

translate chinese chinese_9135033_420:
    old "If it was that easy I wouldn't have a problem."
    new "如果那么容易我就不会有问题了。"

translate chinese chinese_9750747_421:
    old "Getting that web developer wasn't easy."
    new "找那个网页开发者可不容易。"

translate chinese chinese_7761440_422:
    old "You know my firm is only setting up here in town, so we can't actually offer anybody long-term contracts."
    new "你知道我的公司才刚在这里成立，所以我们实际上没法提供长期合同给任何人。"

translate chinese chinese_9261566_423:
    old "Finding somebody qualified that's willing to freelance for a while is very hard."
    new "找到一个愿意兼职的合格人选很难。"

translate chinese chinese_0244526_424:
    old "But we already took the commission, and my bosses are expecting me to show them a marketing plan soon!"
    new "但是我们已经接了委托，而且我的老板们指望我尽快给他们看一个营销计划！"

translate chinese chinese_8250304_425:
    old "Tell me dear, do you know of anybody that could help me?"
    new "亲爱的，你知道有没有人能帮我的？"

translate chinese chinese_8834968_426:
    old "Me? Why would I happen to know someone who is a web developer?"
    new "我？我怎么会认识一个网页开发者？"

translate chinese chinese_0031606_427:
    old "I don't know, maybe someone from your school?"
    new "我不知道，可能是你学校里的谁吧？"

translate chinese chinese_4671905_428:
    old "Well, I'm sorry to disappoint you, mom, but I don't know any web developers..."
    new "好吧，妈妈，很抱歉让你失望了，但我根本不认识任何网页开发者……"

translate chinese chinese_3628624_429:
    old "I see... that's disappointing."
    new "我明白了……真是令人失望。"

translate chinese chinese_2209940_430:
    old "MOM! What are you talking about? Don't rope him into this!"
    new "妈！你在说什么？别把他牵扯进来！"

translate chinese chinese_7547000_431:
    old "Well honey, I'm sorry if you don't like me asking your friend for help."
    new "亲爱的，如果你不喜欢我找你的朋友帮忙，我道歉。"

translate chinese chinese_7166783_432:
    old "But I'm in a very thought spot right now, I need whatever help I can get."
    new "但我现在正处在思考的关键时刻，我需要任何能获得的帮助。"

translate chinese chinese_4079734_433:
    old "So, do you know of anybody that could help me [pla]?"
    new "所以，你知道有谁可以帮助我[pla]吗？"

translate chinese chinese_9358124_434:
    old "Well... Actually, I- I think that... Maybe I could help"
    new "嗯……其实，我—我觉得…… maybe我能够帮忙"

translate chinese chinese_9542387_435:
    old "Really? Are you a web developer?"
    new "真的吗？你是网页开发者吗？"

translate chinese chinese_2056981_436:
    old "Well, I'm not a professional, but I have a little bit of experience."
    new "好吧，我可不是专业人士，但多少有点经验。"

translate chinese chinese_0305913_437:
    old "My [sisrel] has an online clothing store."
    new "我的[sisrel]有一个在线服装店。"

translate chinese chinese_6359448_438:
    old "When she was getting started I was the one who set up the e-commerce for her."
    new "她刚开始的时候，是我帮她搭建的电商系统。"

translate chinese chinese_0365184_439:
    old "And... I have been doing the maintenance ever since."
    new "而且……我从那以后就一直在做维护。"

translate chinese chinese_4667078_440:
    old "And you think you could help me with this?"
    new "你觉得你能帮我解决这个吗？"

translate chinese chinese_0934513_441:
    old "W- well, I think so, I would have to see first what it is that you need me to do, though."
    new "嗯，我觉得是这样，不过我得先看看你要我做什么。"

translate chinese chinese_6811537_442:
    old "That's wonderful [pla]! Oh my God! I would love it if you could help me."
    new "太棒了[pla]！天啊！如果你能帮我我会很开心的。"

translate chinese chinese_7036962_443:
    old "Maybe asking you to do the whole website right now would be too much."
    new "也许现在就让你做整个网站要求太高了。"

translate chinese chinese_4778202_444:
    old "But I think you could help me with the planning of it, while I find a web developer to hire."
    new "但是我觉得你可以帮我规划一下，同时我去找一个网页开发者来雇用。"

translate chinese chinese_5834367_445:
    old "It would only be a few times that I would need your help with the planning."
    new "我只需要你帮忙策划几次而已。"

translate chinese chinese_7819211_446:
    old "Hmm... Sure, I think I could do that."
    new "嗯……好吧，我觉得我可以试试。"

translate chinese chinese_2667791_447:
    old "That's great!"
    new "太好了！"

translate chinese chinese_1850032_448:
    old "And don't worry, I'll make sure you get properly compensated for it. I can add the cost to the budget."
    new "放心，我会确保你得到相应的补偿。我可以把这笔费用加到预算里。"

translate chinese chinese_4076461_449:
    old "So, there shouldn't be any problem with your pay."
    new "所以，你的报酬应该没问题。"

translate chinese chinese_6747062_450:
    old "I- I see... So, s- should I come to your office later?"
    new "我……明白了……那，我晚点去你办公室吧？"

translate chinese chinese_6474523_451:
    old "Actually, I'm not sure if that would be a good idea because I wouldn't want the firm's directors to know about this."
    new "实际上，我不确定这是否是个好主意，因为我不想让公司的董事知道这件事。"

translate chinese chinese_7541667_452:
    old "I think it's better if we just work here at home."
    new "我觉得还是在家工作比较好。"

translate chinese chinese_7722624_453:
    old "You're really helping me with this [pla], a lot! You have no idea about how useful you're being!"
    new "你真的帮了我大忙了，[pla]！你根本不知道你有多有用！"

translate chinese chinese_2007178_454:
    old "Now, I left some documents that you'll need in the office, I'll go and grab them."
    new "刚才我在办公室放了一些你需要的文件，我去拿一下。"

translate chinese chinese_3964217_455:
    old "But don't worry, we won't be starting right away, you can come back on another occasion and I'll let you know what the job is about."
    new "但别担心，我们不会马上开始，你可以改天再来，我会告诉你这份工作的详情。"

translate chinese chinese_5318821_456:
    old "Alright, I'll be sure to do it."
    new "好的，我一定会做的。"

translate chinese chinese_3789865_457:
    old "Great, see you later then [pla]."
    new "好的，那回头见了，[pla]。"

translate chinese chinese_8254795_458:
    old "I can't believe you're actually going to help her with that."
    new "真不敢相信你真的要去帮她做那事。"

translate chinese chinese_7103423_459:
    old "Don't you think that's going to get in the way of us doing the stream?"
    new "你不觉得这会妨碍我们做直播吗？"

translate chinese chinese_2358320_460:
    old "In fact, I think it's convenient for us because since she needs me to work here, we'll know more accurately when she will be here and when she won't."
    new "事实上，我觉得这对我们很方便，因为她需要我在这里工作，所以我们能更准确地知道她什么时候会来，什么时候不会来。"

translate chinese chinese_6318208_461:
    old "But still, I'm sorry my mom is putting you up to this."
    new "不过我还是抱歉，我妈妈让你做这些。"

translate chinese chinese_3289529_462:
    old "Don't worry about it, I'm happy to help."
    new "别担心，我很乐意帮忙。"

translate chinese chinese_8176708_463:
    old "Yeah, I know."
    new "是的，我知道。"

translate chinese chinese_9541157_464:
    old "You're being very nice helping both my mom and me like this."
    new "你帮我和我妈妈真是帮了大忙了，真好。"

translate chinese chinese_4906375_465:
    old "That's very good of you [pla]."
    new "你真好，[pla]。"

translate chinese chinese_3189282_466:
    old "Thanks for saying that."
    new "谢谢你这么说。"

translate chinese chinese_0283305_467:
    old "Hey, so I think I should get going, after all, we just finished streaming, I bet you want to take a shower or something."
    new "嘿，我想我该走了，毕竟直播刚结束，你肯定想洗个澡什么的。"

translate chinese chinese_9850322_468:
    old "Uhh, yeah, sure, I'll let you know when we have to stream the next time, thanks again [pla]."
    new "呃，好的，下次我们需要直播的时候我会通知你的，再次感谢[pla]。"

translate chinese chinese_6938475_469:
    old "Sure, see you later, bye."
    new "好的，一会儿见，拜拜。"

translate chinese chinese_8646739_470:
    old "Hi [pla]! I have great news!"
    new "喂，[pla]！我有个好消息！"

translate chinese chinese_7741459_471:
    old "The poll results from yesterday came out this morning!"
    new "昨天的投票结果今天早上公布了！"

translate chinese chinese_6827063_472:
    old "I'm number one now!"
    new "我现在是第一了！"

translate chinese chinese_7071523_473:
    old "That's great belle!"
    new "太好了，贝勒！"

translate chinese chinese_2335843_474:
    old "I'm very happy for you."
    new "我为你感到非常高兴。"

translate chinese chinese_9653849_475:
    old "Thanks, this is wonderful!"
    new "谢谢，这真是太棒了！"

translate chinese chinese_3682474_476:
    old "She's been appearing with a guy on stream for longer, so I didn't know if I would be able to catch her with just one stream."
    new "她和一个男生一起直播已经有一段时间了，所以我不知道只看一次直播能不能遇到她。"

translate chinese chinese_8433941_477:
    old "But my fans really liked it!"
    new "但是我的粉丝们真的很喜欢它！"

translate chinese chinese_3277687_478:
    old "If we keep going like this, she won't have any chance of catching me!"
    new "如果我们继续这样下去，她根本没机会追上我！"

translate chinese chinese_7446008_479:
    old "That sounds great."
    new "听起来不错。"

translate chinese chinese_8305351_480:
    old "So, when it's the next stream?"
    new "那么，下次直播是什么时候？"

translate chinese chinese_9486306_481:
    old "Well, that's where we have a little bit of a problem."
    new "嗯，这里就有点问题了。"

translate chinese chinese_4750480_482:
    old "Why? What happened?"
    new "为什么？发生什么事了？"

translate chinese chinese_3125588_483:
    old "You see, I had already thought about what we're going to do next."
    new "你看，我早就想好了接下来我们要做什么。"

translate chinese chinese_4255867_484:
    old "My fans have been asking for me to do cosplay for a while, so I thought now it would be a good occasion."
    new "我的粉丝们一直催我搞 cosplay，所以我觉得现在是个不错的时机。"

translate chinese chinese_2288643_485:
    old "Cosplay?"
    new "cosplay？"

translate chinese chinese_7918868_486:
    old "Yes, we can't just repeat the same as last time."
    new "是的，我们不能只是重复上次的事情。"

translate chinese chinese_6699959_487:
    old "If we just do the same thing over and over the audience will get bored."
    new "如果我们一直重复同样的事情，观众会感到无聊的。"

translate chinese chinese_5415449_488:
    old "We have to give them some variety."
    new "我们必须给他们一些变化。"

translate chinese chinese_7099240_489:
    old "But you see, I don't know when the next stream will be."
    new "但是你看，我也不知道下次直播是什么时候。"

translate chinese chinese_5305146_490:
    old "I already know what character I want to do."
    new "我已经知道我想扮演的角色了。"

translate chinese chinese_4821231_491:
    old "It's somewhat of an interesting character, and my fans seem to have a fixation for that type of girl."
    new "这个角色还算有趣，我的粉丝们似乎特别喜欢这种类型的女孩。"

translate chinese chinese_1904891_492:
    old "So I wanted to please them, I even ordered for the cosplay to be delivered by express shipping."
    new "我就想让他们高兴一下，甚至特地叫快递送来了 cosplay 服装。"

translate chinese chinese_8149811_493:
    old "But it turns out there was a mixup when I placed my order, when I bought it they had alredy sold it!"
    new "但是结果我发现下单时搞错了，我买的时候他们已经卖掉了！"

translate chinese chinese_4077966_494:
    old "And they don't seem to have any more!"
    new "而且他们好像没有更多了！"

translate chinese chinese_0380942_495:
    old "I have been looking for that same cosplay in other websites, but I can't find it!"
    new "我在其他网站上也找了同样的 cosplay，但找不到！"

translate chinese chinese_7578616_496:
    old "And I already promised the audience that's the character I was going to do."
    new "而且我已经答应观众要扮演那个角色了。"

translate chinese chinese_8141558_497:
    old "I guess we'll have to postpone it for another time."
    new "我想我们得改天了。"

translate chinese chinese_7196602_498:
    old "Besides, you also have to go help my mom with that website thing..."
    new "再说，你还要去帮我妈妈处理那个网站的事……"

translate chinese chinese_8818036_499:
    old "Ugh, this annoys me so much, Lana's going to overtake me again!"
    new "哎，这真让我烦死了，兰娜又要超过我了！"

translate chinese chinese_0107401_500:
    old "Hmm, I might be able to do something about that. My [sisRel] has her own clothing store."
    new "嗯，我可能能做点什么。我的[sisRel]有自己的服装店。"

translate chinese chinese_8980064_501:
    old "So, I think maybe she can find that cosplay for you in time for the next stream."
    new "所以，我觉得她可能能在下次直播前给你找到那个 cosplay。"

translate chinese chinese_9843848_502:
    old "Really? Oh [pla] that would be great!"
    new "真的吗？哦 [pla] 那太棒了！"

translate chinese chinese_7505624_503:
    old "Well, it's not certain, I'll have to ask, but I think it's possible."
    new "嗯，这个不确定，我得问一下，但我觉得有可能。"

translate chinese chinese_9190097_504:
    old "If you could, that would be wonderful."
    new "如果你能这么做的话就太好了。"

translate chinese chinese_3994241_505:
    old "I'll ask with my [sisRel] this afternoon, after classes."
    new "我今天下午下课后会用我的[sisRel]问她。"

translate chinese chinese_3226202_506:
    old "And I'll let you know."
    new "我会让你知道的。"

translate chinese chinese_5968452_507:
    old "Sure, thanks a lot [pla]."
    new "好的，谢谢你[pla]。"

translate chinese chinese_7386638_508:
    old "For now let's go to class."
    new "先去上课吧。"

translate chinese chinese_7481794_509:
    old "Hi [sis], how are you?"
    new "嗨 [sis]，你好吗？"

translate chinese chinese_8853351_510:
    old "I'm doing pretty well, working on a new collection."
    new "我挺好的，正在做一个新的系列。"

translate chinese chinese_2472907_511:
    old "Uhh, so are you busy?"
    new "呃，你忙吗？"

translate chinese chinese_3240093_512:
    old "Uhh a little bit, Why? What do you need?"
    new "嗯，有点儿，为什么？你需要什么？"

translate chinese chinese_4253917_513:
    old "Well, I was wondering if you could help me with getting a cosplay."
    new "嗯，我想问问你能不能帮我搞一套 cosplay。"

translate chinese chinese_2194065_514:
    old "A cosplay? I didn't know you were into that kind of stuff..."
    new "cosplay？我不知道你也喜欢这种东西……"

translate chinese chinese_4467289_515:
    old "Anyway, what kind of cosplay is it? Like a superhero or something?"
    new "不管怎样，是哪种 cosplay 呢？像超级英雄那样的吗？"

translate chinese chinese_3280663_516:
    old "Uhh, it's actually a female cosplay, it's a famous character from a videogame."
    new "呃，其实是女角色的 cosplay，她是某个游戏里的著名角色。"

translate chinese chinese_3703190_517:
    old "A female cosplay? Why do you need that?"
    new "女 cosplay？你为什么要那个？"

translate chinese chinese_2465751_518:
    old "Don't tell me you're thinking of becoming a drag queen."
    new "别告诉我你在考虑当一个变装皇后。"

translate chinese chinese_7639982_519:
    old "W- what? Of course not!"
    new "什、什么？当然不是！"

translate chinese chinese_6560024_520:
    old "It's for a friend of mine that needs it."
    new "这是我朋友需要的。"

translate chinese chinese_4163425_521:
    old "Oh! Is that so? And why are you getting it for her? Are you two doing something naughty?"
    new "哦！是吗？那你为什么要给她买？你们俩是不是要干些什么坏事？"

translate chinese chinese_1113605_522:
    old "N- no, we're not, I'm just doing her a favor because she needs it. That's all."
    new "不——不是，我们没那个意思，我只是帮她一下因为她需要帮忙，就这么简单。"

translate chinese chinese_1779861_523:
    old "Haha! Relax, I'm just messing with you."
    new "哈哈！别紧张，我开玩笑的。"

translate chinese chinese_1330857_524:
    old "I don't mind what you're doing with your friend."
    new "我不介意你和朋友做什么。"

translate chinese chinese_4299090_525:
    old "As long as you keep helping me with my business, you can do whatever you want."
    new "只要你继续帮我打理生意，你想干什么都行。"

translate chinese chinese_4394743_526:
    old "I'll get you the cosplay, it should be easy to get it here soon."
    new "我会给你弄到那个 cosplay 的，这里应该很快就能搞到。"

translate chinese chinese_2615075_527:
    old "Thanks a lot [sis]!"
    new "多谢[sis]！"

translate chinese chinese_7605742_528:
    old "I'm happy to help."
    new "我很乐意帮忙。"

translate chinese chinese_2358525_529:
    old "I'll let you know when it's ready."
    new "等准备好我会通知你。"

translate chinese chinese_3379547_530:
    old "Hello [pla]! How are you dear?"
    new "你好[pla]！亲爱的，最近怎么样？"

translate chinese chinese_4384747_531:
    old "Hi Mrs. Ash-"
    new "嗨，艾什夫人——"

translate chinese chinese_5627671_532:
    old "Just Ashley dear, remember what I told you, no need for the Mrs."
    new "just Ashley亲爱的，记得我跟你说过的，不用加Mrs."

translate chinese chinese_8842051_533:
    old "Uhh... Right."
    new "呃……对。"

translate chinese chinese_9940826_534:
    old "Hi A- Ashley."
    new "嗨，A- Ashley。"

translate chinese chinese_3752509_535:
    old "That's better."
    new "这样就好多了。"

translate chinese chinese_9354075_536:
    old "How have you been honey?"
    new "宝贝，你最近怎么样？"

translate chinese chinese_8430577_537:
    old "Is school going well?"
    new "学校过得怎么样？"

translate chinese chinese_1567052_538:
    old "Uhh? Y- yeah. I- I have been studying a lot..."
    new "呃？嗯。我最近一直在学习……"

translate chinese chinese_8525792_539:
    old "That's great dear."
    new "那太好了，亲爱的。"

translate chinese chinese_4840035_540:
    old "Uh... Listen, A- Ashley, about the w- website."
    new "呃……听着，阿什利，关于那个网站的事。"

translate chinese chinese_9059977_541:
    old "Right! We should focus on that."
    new "对！我们应该专注于那件事。"

translate chinese chinese_3108440_542:
    old "Sure ma'am. But I'm not entirely sure what it is that I will be doing."
    new "好的，女士。但我不完全确定我要做什么。"

translate chinese chinese_5319842_543:
    old "Well, before that, I would like to see the e-commerce site you told me you made for your [sisrel]."
    new "好吧，在那之前，我想看看你为你的[sisrel]做的那个电商网站。"

translate chinese chinese_4128246_544:
    old "To see what type of thing you've done before. Would you like to use my computer?"
    new "看看你以前都做过什么类型的。你想用我的电脑吗？"

translate chinese chinese_3173221_545:
    old "Uh... Sure, no problem."
    new "呃……好的，没问题。"

translate chinese chinese_6022229_546:
    old "So, this is the site where you can see the apparel that my [sisrel] sells."
    new "所以，这里就是可以查看我[sisrel]出售的服装的网站。"

translate chinese chinese_3499775_547:
    old "And if you click here you can place an order."
    new "在这里点击就可以下单了。"

translate chinese chinese_1345053_548:
    old "Then, it will take you to the payment portal. And there you can finalize the purchase."
    new "然后会带你到支付页面。在那里你可以完成购买。"

translate chinese chinese_5501719_549:
    old "You know [pla]? This is very good."
    new "你知道[pla]吗？这个非常好。"

translate chinese chinese_8128275_550:
    old "This is very high quality, even better than the work some of the developers I've worked with before."
    new "这质量非常高，甚至比之前合作过的有些开发者的作品还要好。"

translate chinese chinese_1398114_551:
    old "Actually, this is more than what I need you to do."
    new "实际上，这已经超出了我需要你做的范围。"

translate chinese chinese_3630131_552:
    old "After seeing this, I'm thinking that you could just take the full job of developing the website for the client."
    new "看了这个，我觉得你可以全权负责为客户开发网站了。"

translate chinese chinese_5621897_553:
    old "Come on, why are you surprised? You did a very good job with this website."
    new "别这样，为什么这么惊讶？你把这个网站做得很好。"

translate chinese chinese_7233940_554:
    old "And as I told you, this is even more than what I need to be done for the marketing campaign."
    new "就像我告诉你的，这已经超出了营销活动所需的内容。"

translate chinese chinese_7559352_555:
    old "You could just do the job by yourself."
    new "你可以自己搞定这件事。"

translate chinese chinese_7024701_556:
    old "And It would really help me, because I wouldn't have to look for someone to finish the project."
    new "这样真的能帮到我，因为我就不用再找人来完成这个项目了。"

translate chinese chinese_7031264_557:
    old "I mean, that's a very nice offer, uh... Ashley, b- but I'm not sure if I have the experience to do it."
    new "我的意思是，这真是个不错的提议，呃……艾希莉，但我不确定自己是否有经验去做这件事。"

translate chinese chinese_5247556_558:
    old "It would be a lot of responsability."
    new "那会责任很大的。"

translate chinese chinese_0804250_559:
    old "Don't worry about it, dear. I'll accompany you every time you work on it, so I'll tell you exactly what I need from you."
    new "别担心，亲爱的。每次你做的时候我都会陪在你身边，我会告诉你我具体需要什么。"

translate chinese chinese_5238221_560:
    old "Alright, if you think it's ok for me to do it, I guess I can take the job."
    new "好吧，如果你觉得我可以做，那我就接下这份工作吧。"

translate chinese chinese_0635012_561:
    old "Great! That's just what I wanted to hear."
    new "太好了，这正是我想听到的。"

translate chinese chinese_9042562_562:
    old "Ok, but what exactly is the type of website that I'm going to be working on? Is it an e-commerce?"
    new "好的，但是我要做的网站具体是什么类型的呢？是电子商务网站吗？"

translate chinese chinese_2073522_563:
    old "Not really, what I need you to make is one where we can show a lot of information about a business."
    new "不是那样的，我需要你能做一个能展示很多关于企业信息的。"

translate chinese chinese_0956125_564:
    old "The business in question is an organic coffee shop that's gotten very popular here in the city."
    new "这家有机咖啡店在这里市里变得非常受欢迎。"

translate chinese chinese_0564796_565:
    old "And they're looking to expand their business by franchising outside of town."
    new "他们正打算通过镇外的特许经营来扩大业务。"

translate chinese chinese_1252676_566:
    old "I see. So they hired you to do their marketing campaign?"
    new "我明白了。所以他们是雇你来做他们的营销活动的？"

translate chinese chinese_3029007_567:
    old "Not me, my marketing firm. I'm just leading my team."
    new "不是我，是我的营销公司。我只是带领我的团队而已。"

translate chinese chinese_3203538_568:
    old "But, I still have the responsibility for the entire marketing plan."
    new "但是，我仍然要负责整个营销计划。"

translate chinese chinese_8818429_569:
    old "Because the clients already paid for the service, and I already received the budget."
    new "因为客户已经支付了服务费用，而且我已经收到了预算。"

translate chinese chinese_6035421_570:
    old "That's why it's so bad that the web developer quit all of a sudden. Because he put me in a very difficult position."
    new "这就是为什么那个网页开发者突然辞职这么糟糕了。因为他把我置于一个非常困难的境地。"

translate chinese chinese_7748523_571:
    old "I understand, I'm sorry that happened."
    new "我明白，很抱歉发生了那样的事。"

translate chinese chinese_1065371_572:
    old "That's very nice of you dear, thank you."
    new "亲爱的，你真好，谢谢。"

translate chinese chinese_6316217_573:
    old "Now, why don't we get started and I'll tell you what to do along the way?"
    new "好了，我们现在开始吧，我会边走边告诉你该怎么做？"

translate chinese chinese_6727864_574:
    old "Ok, now please put the title in higher case."
    new "好的，现在请把标题改成大写。"

translate chinese chinese_1407227_575:
    old "That's it, perfect. Could you also make those pictures a little bigger?"
    new "就是这样，完美。那些图片还能放大一点吗？"

translate chinese chinese_8315584_576:
    old "I want the raw coffee shots to be front and center."
    new "我要把现磨咖啡放在显眼的位置。"

translate chinese chinese_9319099_577:
    old "Ok, is that because of their brand?"
    new "好的，是因为他们的牌子吗？"

translate chinese chinese_0956230_578:
    old "That's right, they want to show themselves as an organic coffee business, that's a contrast to the bigger coffee chains you see everywhere."
    new "没错，他们想展示自己是一家有机咖啡生意，这与随处可见的大咖啡连锁店形成了对比。"

translate chinese chinese_7228316_579:
    old "I see, I think I get it."
    new "我明白了，我想我懂了。"

translate chinese chinese_2110499_580:
    old "Well, the whole point of marketing is developing and delivering the message the client wants to show."
    new "好吧，营销的整个要点就是开发并传递客户想要展示的信息。"

translate chinese chinese_5505364_581:
    old "So, I really enjoy the process of using optics and messaging to find good ways to attract attention to our clients."
    new "所以，我真的很喜欢利用光学和信息传递来找到吸引客户注意的好方法。"

translate chinese chinese_5340221_582:
    old "That's really cool Ashley."
    new "真是酷毙了，Ashley。"

translate chinese chinese_5165864_583:
    old "Thanks dear..."
    new "谢谢亲爱的..."

translate chinese chinese_3090450_584:
    old "Now, let's keep going."
    new "好了，我们继续吧。"

translate chinese chinese_1171714_585:
    old "Yes! That's exactly what I wanted!"
    new "没错！这正是我想要的！"

translate chinese chinese_9278833_586:
    old "You're really good at this [pla], I can't believe you thought you wouldn't do it properly."
    new "你真的很擅长这个[pla]，真不敢相信你会觉得自己做不好。"

translate chinese chinese_4071748_587:
    old "T- Thank you, Ashley, I hope your bosses will like it too."
    new "谢、谢谢你，Ashley，希望你的老板们也会喜欢。"

translate chinese chinese_3072871_588:
    old "I'm sure they will, this is turning out better than what I expected."
    new "我相信会的，这比我预期的要好。"

translate chinese chinese_2702122_589:
    old "Actually, I think you've done enough for today."
    new "实际上，我觉得你今天做得已经够多了。"

translate chinese chinese_0050249_590:
    old "Why don't we stop and continue another day?"
    new "要不我们先停到这里，改天再继续吧？"

translate chinese chinese_1795956_591:
    old "You're very good at this [pla], I think that with your help we will have this ready in no time."
    new "你很擅长这个[pla]，我觉得有你的帮助很快就能搞定。"

translate chinese chinese_3996399_592:
    old "Thanks ma'am, I'm sure we will."
    new "谢谢阿姨，我们一定会的。"

translate chinese chinese_9322554_593:
    old "So, I- I guess I should leave for know."
    new "所以，我—我想我现在应该离开了。"

translate chinese chinese_1243247_594:
    old "Wait, before you go, I wanted to ask you about how much time you have available to work on this."
    new "等一下，临走前我想问一下你有多少时间可以用来做这个。"

translate chinese chinese_1680686_595:
    old "You're a student after all. I wouldn't want to use all of your time."
    new "你畢竟是學生，我不會想佔用你所有時間的。"

translate chinese chinese_4994817_596:
    old "But if I'm honest, I could use your help as often as possible."
    new "但说老实话，我希望能尽可能经常地得到你的帮助。"

translate chinese chinese_5851922_597:
    old "So, it occurs to me that you could tell me when it works best for you."
    new "所以，我想你可以告诉我什么时候对你最方便。"

translate chinese chinese_9393063_598:
    old "For us to work on the website."
    new "为了我们一起做网站。"

translate chinese chinese_9597195_599:
    old "I- I guess I could come... Maybe every other day and work with you?"
    new "我—我猜我可以来... maybe每隔一天和你一起工作？"

translate chinese chinese_3945407_600:
    old "That's just perfect for me!"
    new "这对我来说再完美不过了！"

translate chinese chinese_5722021_601:
    old "Great, that's good to hear."
    new "太好了，听到这个消息真高兴。"

translate chinese chinese_0335195_602:
    old "Alright, it's getting a bit late, so,I think I'll go home now, Ashley."
    new "好吧，已经有点晚了，我想我现在就回家吧，Ashley。"

translate chinese chinese_2868793_603:
    old "Sure dear, thanks again for your great help."
    new "好的亲爱的，再次感谢你的大力帮助。"

translate chinese chinese_3363414_604:
    old "You're welcome, see you later."
    new "不客气，回头见。"

translate chinese chinese_1815107_605:
    old "See you honey."
    new "拜拜，亲爱的。"

translate chinese chinese_9330833_606:
    old "Hey [sis]."
    new "嘿[sis]。"

translate chinese chinese_1249000_607:
    old "Listen, your cosplay has arrived."
    new "听着，你的 cosplay 已经到了。"

translate chinese chinese_1597356_608:
    old "Really? It arrived this quickly? That's great!"
    new "真的吗？这么快就到了？太好了！"

translate chinese chinese_2106359_609:
    old "Well, I have a direct contact, and they always send it via express delivery."
    new "好吧，我有直接渠道，他们总是用快递寄来的。"

translate chinese chinese_1848311_610:
    old "Oh, that's great."
    new "哦，那太好了。"

translate chinese chinese_9654312_611:
    old "Come with me, the package is in my bedroom."
    new "跟我来，包裹在我的卧室里。"

translate chinese chinese_4509366_612:
    old "Oh, right."
    new "哦，对了。"

translate chinese chinese_6796378_613:
    old "Wait here."
    new "在这里等一下。"

translate chinese chinese_6849055_614:
    old "Here it is."
    new "就是这个。"

translate chinese chinese_0770950_615:
    old "I ordered it directly from a producer."
    new "我是直接从制作人那里订购的。"

translate chinese chinese_4984573_616:
    old "I knew that you needed it quickly, right?"
    new "我知道你需要得很快，对吧？"

translate chinese chinese_9915594_617:
    old "This is great, thanks a lot."
    new "太好了，谢谢你。"

translate chinese chinese_4513365_618:
    old "Don't worry about it, I'm happy to help you."
    new "别担心，我很乐意帮你。"

translate chinese chinese_3141383_619:
    old "I hope your friend likes it."
    new "希望你的朋友会喜欢。"

translate chinese chinese_0199844_620:
    old "I'm sure she will, thanks [sis]."
    new "我相信她会的，谢谢[sis]。"

translate chinese chinese_2477978_621:
    old "Hi belle, good morning."
    new "嗨，贝勒，早上好。"

translate chinese chinese_1540310_622:
    old "Hi [pla], how are you today?"
    new "你好 [pla]，今天怎么样？"

translate chinese chinese_0496964_623:
    old "Hey, listen, I got your cosplay!"
    new "嘿，听我说，我搞到你的 cosplay 了！"

translate chinese chinese_8252725_624:
    old "Really? That's wonderful [pla]!"
    new "真的吗？那太棒了[pla]！"

translate chinese chinese_2964491_625:
    old "Yeah, I received it this morning. Is your mom going to be home this afternoon? If not, I can bring it to your house so you can try it on."
    new "嗯，我今天早上收到了。你妈妈今天下午在家吗？不在的话我可以带到你家，让你试穿一下。"

translate chinese chinese_7184370_626:
    old "She won't be, so we can stream today as well!"
    new "她不会的，所以我们今天也可以直播！"

translate chinese chinese_0733215_627:
    old "You want to stream right away?"
    new "你想马上开直播吗？"

translate chinese chinese_4925328_628:
    old "Of course, we have to."
    new "当然，我们必须这么做。"

translate chinese chinese_9954940_629:
    old "Lana has been putting up a lot of new content, I can't let any more time pass by."
    new "Lana 发了很多新内容，我不能再浪费时间了。"

translate chinese chinese_4959499_630:
    old "Yeah, you're right, I'll bring the cosplay after classes. Ok?"
    new "嗯，你说得对，我下课后再带 cosplay 好吗？"

translate chinese chinese_5804288_631:
    old "Yeah, perfect."
    new "没错，完美。"

translate chinese chinese_3483072_632:
    old "Ok, so you'll pick up the cosplay at your house and I'll set up the stream. Ok?"
    new "好的，你就去家里拿 cosplay 服装，我来准备直播。行吗？"

translate chinese chinese_0864984_633:
    old "Sure, I'll be there right away."
    new "好的，我马上就到。"

translate chinese chinese_5577279_634:
    old "Hey Belle, here it is."
    new "嘿，贝尔，就是这个。"

translate chinese chinese_6240700_635:
    old "Great! Let's go up to my room and I'll try it on."
    new "太好了！我们上去我的房间试试吧。"

translate chinese chinese_2977664_636:
    old "Ok, I'll put it on."
    new "好吧，我穿上。"

translate chinese chinese_9601787_637:
    old "So, what do you think?"
    new "所以，你怎么看？"

translate chinese chinese_8576371_638:
    old "You look great Belle!"
    new "你看起来很棒，贝拉！"

translate chinese chinese_8477476_639:
    old "It really fits you."
    new "真的很适合你。"

translate chinese chinese_6811110_640:
    old "I'm happy you like it."
    new "我很高兴你喜欢。"

translate chinese chinese_0148172_641:
    old "Let's get started with the stream then."
    new "那我们就开始直播吧。"

translate chinese chinese_7384285_642:
    old "Ok guys, it's time for another good time!"
    new "好了，大家，是时候再来一次愉快的时光了！"

translate chinese chinese_7167673_643:
    old "What do you think of the cosplay that I prepared for you?"
    new "你觉得我为你准备的 cosplay 怎么样？"

translate chinese chinese_7843047_644:
    old "I know you have been waiting to see me like this, so be sure to enjoy!"
    new "我知道你一直等着看我这样，所以一定要好好享受哦！"

translate chinese chinese_4448253_645:
    old "But that's not all."
    new "但这还不是全部。"

translate chinese chinese_0320253_646:
    old "Since you guys liked to see my friend so much last time, I brought him here again!"
    new "上次你们那么喜欢看我的朋友，这次我又把他带来了！"

translate chinese chinese_7805600_647:
    old "So say hi to him again!"
    new "所以再跟他打个招呼吧！"

translate chinese chinese_5432158_648:
    old "Ok, guys, let's not waste any more time."
    new "好了，大家，不要再浪费时间了。"

translate chinese chinese_3394940_649:
    old "I know you've been waiting for it, so let's get to it."
    new "我知道你已经等不及了，那就开始吧。"

translate chinese chinese_6186149_650:
    old "OH! God! This cock!"
    new "哦！天啊！这鸡巴！"

translate chinese chinese_5566161_651:
    old "I love it! It's just the best taste in the world!"
    new "我超爱的！这是世界上最好的味道！"

translate chinese chinese_6859236_652:
    old "Your dick is so big guys!"
    new "你的 dicks 真的大啊！"

translate chinese chinese_5039266_653:
    old "I'm happy you enjoyed the stream and my cosplay!"
    new "很高兴你喜欢我的直播和 cosplay！"

translate chinese chinese_2966600_654:
    old "After all, I'm doing this for all of you!"
    new "毕竟，我这是为了大家好！"

translate chinese chinese_9483182_655:
    old "I'll end the stream here for now."
    new "我先在这里结束直播。"

translate chinese chinese_4833650_656:
    old "But be sure that I'll come back soon."
    new "但放心，我很快就会回来的。"

translate chinese chinese_7198106_657:
    old "As always, remember to subscribe to the stream."
    new "像往常一样，记得订阅直播。"

translate chinese chinese_7004179_658:
    old "And you’ll be notified every time I’m online!"
    new "每次我上线你都会收到通知！"

translate chinese chinese_1369561_659:
    old "And of course, remember to check out my social media links!"
    new "别忘了关注我的社交媒体链接！"

translate chinese chinese_0398854_660:
    old "Thans for your support guys!"
    new "谢谢大家的支持！"

translate chinese chinese_5681096_661:
    old "See you later, bye!"
    new "一会儿见，拜拜！"

translate chinese chinese_4916268_662:
    old "I'm sure that with this, Lana will not have a chance to catch me!"
    new "我敢肯定，有了这个，Lana就没机会抓到我了！"

translate chinese chinese_4784897_663:
    old "Awesome!"
    new "太棒了！"

translate chinese chinese_1602729_664:
    old "After all you've worked really hard for this."
    new "毕竟你为了这个努力了很久。"

translate chinese chinese_5735333_665:
    old "I think I'll head back home before your mother arrives."
    new "我想在你妈妈回来之前先回家。"

translate chinese chinese_8615286_666:
    old "Alright, I'll let you know how the voting goes tomorrow."
    new "好吧，我明天告诉你投票结果。"

translate chinese chinese_7356608_667:
    old "Sure, I'm sure it's going to go great."
    new "行吧，我敢肯定一切都会很顺利。"

translate chinese chinese_3199448_668:
    old "Hi, Ashley, I'm fine thank you."
    new "嗨，Ashley，我很好，谢谢。"

translate chinese chinese_0882742_669:
    old "That's good, tell me, is there anything I can help you with?"
    new "很好，告诉我，有什么我可以帮忙的吗？"

translate chinese chinese_3918202_670:
    old "Well, I was thinking that I could keep helping you with developing the website."
    new "嗯，我在想我还可以继续帮你开发网站。"

translate chinese chinese_0026005_671:
    old "That would be great [pla]!"
    new "那真是太好了，[pla]！"

translate chinese chinese_5790016_672:
    old "Ok, wait here a minute and I'll get everything ready."
    new "好的，你在这等一分钟，我准备一下东西。"

translate chinese chinese_5997720_673:
    old "Oh, not much, I was just passing by."
    new "哦，没什么，我刚才路过而已。"

translate chinese chinese_5618939_674:
    old "Please remember to come work on the website project soon. The deadline is coming soon."
    new "请记得尽快来网站项目工作，截止日期快到了。"

translate chinese chinese_7097408_675:
    old "Sure, don't worry I'll keep that in mind."
    new "好的，放心，我会记住的。"

translate chinese chinese_5848788_676:
    old "Thank you [pla], I'll see you later then."
    new "谢谢[pla]，那回头见。"

translate chinese chinese_9681006_677:
    old "Ok, so for today I want us to focus on a new part of the project."
    new "好的，今天我想让我们专注于项目的一个新部分。"

translate chinese chinese_1295524_678:
    old "Alright, what are we doing?"
    new "好吧，我们接下来做什么？"

translate chinese chinese_5564321_679:
    old "Let's get started and I'll explain to you along the way."
    new "我们开始吧，路上我再解释。"

translate chinese chinese_7527120_680:
    old "Ok, Ok, I really like how this turned out."
    new "好，好，我真的觉得这个结果很好。"

translate chinese chinese_0012305_681:
    old "I think we can move on to the next category."
    new "我觉得我们可以进入下一个环节了。"

translate chinese chinese_9626205_682:
    old "Really? Don't you want to use make any corrections?"
    new "真的吗？你不想要做任何修改吗？"

translate chinese chinese_7494039_683:
    old "Not right now, because I haven't  seen how it works with other areas of the website."
    new "现在不行，因为我还没看过它在网站其他区域是如何工作的。"

translate chinese chinese_9799496_684:
    old "So, let's shift our focus to those, and then we can make any pertinent corrections."
    new "那么，让我们把注意力转移到那些上面，然后我们可以进行任何必要的修正。"

translate chinese chinese_5020924_685:
    old "I see, ok, let's do that."
    new "我明白了，好吧，那我们就这么办。"

translate chinese chinese_4894355_686:
    old "Alright [pla], I think that was enough for today. I think we can continue this another time."
    new "好吧[pla]，我觉得今天就到此为止吧。下次我们可以继续。"

translate chinese chinese_6959810_687:
    old "Once again, thanks a lot for your help."
    new "再次感谢你的帮助。"

translate chinese chinese_9638247_688:
    old "You're welcome. My pleasure to help you."
    new "不客气，能帮你我很乐意。"

translate chinese chinese_5888354_689:
    old "Now, it's a little late, so why don't you go home and rest?"
    new "现在有点晚了，为什么不回家休息呢？"

translate chinese chinese_7761074_690:
    old "Yeah, you're right. See you later Ashley."
    new "嗯，你说得对。一会儿见，Ashley。"

translate chinese chinese_2587228_691:
    old "See you later hon."
    new "一会儿见亲爱的。"

translate chinese chinese_9482531_692:
    old "Hi Belle, how are you?"
    new "嗨，贝拉，你好吗？"

translate chinese chinese_8271316_693:
    old "What? What's with that expresion?"
    new "什么？那是什么表情？"

translate chinese chinese_4810987_694:
    old "Is there anything wrong?"
    new "有什么不对劲吗？"

translate chinese chinese_7584103_695:
    old "I guess you could say there is."
    new "我想你说的也有道理。"

translate chinese chinese_4205665_696:
    old "I saw the latests results of the poll before I came."
    new "我来之前看到了最新的民调结果。"

translate chinese chinese_5738881_697:
    old "And Lana is still on top!"
    new "而Lana依然占据榜首！"

translate chinese chinese_2109527_698:
    old "She is? But I thought you said that with what we did last time, there was no way she could catch you."
    new "她是吗？但我觉得你说过上次那样做，她根本不可能抓到你。"

translate chinese chinese_9890584_699:
    old "I know, but you just won't believe what that whore is doing now!"
    new "我知道，但你绝对不会相信那个贱人现在在干什么！"

translate chinese chinese_3114889_700:
    old "She's doing anal!"
    new "她在做肛交！"

translate chinese chinese_1905236_701:
    old "I mean, can you believe it?!"
    new "我是说，你能相信吗？！"

translate chinese chinese_0144413_702:
    old "Uhmm, I mean... Is it weird for people to do webcamming?"
    new "嗯，我的意思是……人们做网路直播有什么奇怪的吗？"

translate chinese chinese_0872533_703:
    old "For a new model, of course it is... She just started streaming a few weeks ago!"
    new "作为新模型，当然了……她几周前才开始直播！"

translate chinese chinese_4393122_704:
    old "She hasn't built a fanbase or anything yet, she is crazy!"
    new "她还没建立起粉丝群什么的，真是疯了！"

translate chinese chinese_9573940_705:
    old "Besides, you know what else she did?"
    new "再说，你知道她还做了什么吗？"

translate chinese chinese_9951147_706:
    old "She just uploaded it as a video to her stream!"
    new "她刚刚把它上传到直播作为视频了！"

translate chinese chinese_7370433_707:
    old "Well, she didn't do it live; she just recorded it off-camera and then uploaded it as if it were live..."
    new "好吧，她并不是现场做的，只是提前录好然后上传假装是现场的……"

translate chinese chinese_1706794_708:
    old "I don't know for certain, but come on, you can tell she did."
    new "我不敢肯定，但你看她那样子，肯定做了。"

translate chinese chinese_9230958_709:
    old "She's not interacting with her chat, answering questions, or anything."
    new "她没有回应聊天，也没有回答任何问题。"

translate chinese chinese_9889608_710:
    old "She's just doing it and that's it."
    new "她就是这么做的，就这么简单。"

translate chinese chinese_7882159_711:
    old "It's clear that it wasn't a live stream, that's for sure!"
    new "很明显那不是直播，这倒是确定的！"

translate chinese chinese_9595269_712:
    old "Ok, I get it, what are you going to do about it then?"
    new "好吧，我明白了，那你打算怎么办？"

translate chinese chinese_6777523_713:
    old "Isn't it obvious?"
    new "这不是明摆着的吗？"

translate chinese chinese_9245493_714:
    old "I'm going to match her!"
    new "我要和她一决高下！"

translate chinese chinese_2811940_715:
    old "I'm not going to just sit down and wait for her to pass me in the rankings!"
    new "我可不会坐以待毙，等着她在排名上超过我！"

translate chinese chinese_4391199_716:
    old "So... You're also doing anal too?"
    new "所以……你也在做肛交吗？"

translate chinese chinese_2333356_717:
    old "Yes, why? Are you against doing it or something?"
    new "是的，为什么？你反对做这个吗？"

translate chinese chinese_1509402_718:
    old "Uhh, no, no, nothing like that."
    new "uh, 不不，不是那样的。"

translate chinese chinese_0827350_719:
    old "It's just surprising, that's all."
    new "只是觉得挺意外的，就这么回事。"

translate chinese chinese_1751859_720:
    old "It wasn't my plan, obviously."
    new "这显然不是我的计划。"

translate chinese chinese_4403504_721:
    old "But after I saw Lana's {i}'Stream'{/i}..."
    new "但是在我看了Lana的直播之后..."

translate chinese chinese_1094241_722:
    old "I asked my followers if they would like to see me doing something similar."
    new "我问了我的粉丝们，他们是否希望看到我做类似的事情。"

translate chinese chinese_3304737_723:
    old "They said they'd totally love to see it."
    new "他们说他们非常想看看这个。"

translate chinese chinese_7054461_724:
    old "So that settles it, we're doing it!"
    new "那就这么定了，我们干吧！"

translate chinese chinese_8223241_725:
    old "I told them we had a surprise coming the next time you appeared on the stream with me."
    new "我跟他们说下次你跟我一起直播的时候有个惊喜。"

translate chinese chinese_0082093_726:
    old "I see, w- well if you're ok with it, I- I guess it's fine."
    new "我明白了，如果你没问题的话，那我猜也行吧。"

translate chinese chinese_3944450_727:
    old "Yeah, I know that the next time you come to my house you have to do that website thing with my mom."
    new "是的，我知道下次你来我家的时候，得和我妈妈一起做那个网站的事情。"

translate chinese chinese_3843625_728:
    old "But perhaps we could do it afterwards."
    new "但也许我们可以之后再做。"

translate chinese chinese_3642640_729:
    old "Actually, it's going to be at least a couple of times that I come to your house and help your mom with the website."
    new "实际上，我得来你家好几次，帮你妈弄那个网站。"

translate chinese chinese_1678171_730:
    old "Really?!"
    new "真的吗？！"

translate chinese chinese_7259323_731:
    old "But we're really short on time [pla]!"
    new "但是我们真的时间很紧[pla]！"

translate chinese chinese_4892643_732:
    old "I know, I'm sorry, but apparently, she has to show some progress to her bosses in the next meeting."
    new "我知道，对不起，但她下次会议得向老板展示一些进展。"

translate chinese chinese_2976510_733:
    old "So, I kinda have to help her with it."
    new "所以，我得帮她处理这件事。"

translate chinese chinese_8919028_734:
    old "Hmph OK, I guess that's fine."
    new "哼，好吧，我猜这也行。"

translate chinese chinese_2606100_735:
    old "I'll tell my fans to wait for a while before I show them the '{i}surprise{/i}' I'd promise them."
    new "我会告诉我的粉丝们先等等，我答应过他们的'{i}surprise{/i}'很快就会展示给他们。"

translate chinese chinese_3925131_736:
    old "But after that we have to do it, ok?"
    new "但是那之后我们必须得做，好吗？"

translate chinese chinese_4089698_737:
    old "Ok, I guess we better go to classes for now."
    new "好吧，我想我们现在还是去上课吧。"

translate chinese chinese_1089019_738:
    old "Thank you, dear. I'm very glad I've got to meet you, you know?"
    new "谢谢你，亲爱的。我很高兴能遇到你，你知道吗？"

translate chinese chinese_5331926_739:
    old "After all, Belle never introduces me to any of her friends."
    new "毕竟，贝尔从来没有把我介绍给她的任何朋友。"

translate chinese chinese_6564603_740:
    old "That girl's so secretive now."
    new "那女孩现在这么神秘。"

translate chinese chinese_6105498_741:
    old "So... Aren't you and Belle close?"
    new "所以……你和贝尔不亲近吗？"

translate chinese chinese_9651763_742:
    old "No, we're not."
    new "不，我们不是。"

translate chinese chinese_3870671_743:
    old "We used to be very close before, but over the years she and I have distanced a lot."
    new "我们以前关系很亲密，但这些年来我们俩疏远了很多。"

translate chinese chinese_9198891_744:
    old "Yes, when Belle was growing up we were inseparable."
    new "是的，贝尔成长的时候我们形影不离。"

translate chinese chinese_3888503_745:
    old "I would never go anywhere without her, and you'd be hard-pressed to see one without the other."
    new "我从来不会离开她，你几乎看不到她们分开。"

translate chinese chinese_6673312_746:
    old "But as time went by we began to distance."
    new "但随着时间的推移，我们开始疏远了。"

translate chinese chinese_3921542_747:
    old "Now we barely even talk, and whenever we're together is like she's angry with me all the time."
    new "现在我们几乎都不说话了，每次在一起她都像是对我很生气。"

translate chinese chinese_5262090_748:
    old "I'm sorry, I didn't know things were like that between the two of you."
    new "对不起，我不知道你们俩之间是这样的。"

translate chinese chinese_0150486_749:
    old "Yeah, but I blame myself."
    new "是的，但我怪自己。"

translate chinese chinese_8751926_750:
    old "Well, I'm a single mother, and I had Belle when I was very young."
    new "嗯，我是单亲妈妈，而且我生贝尔的时候年纪还很小。"

translate chinese chinese_9619792_751:
    old "I decided that I would do everything I could to raise her properly."
    new "我决定尽我所能好好抚养她。"

translate chinese chinese_5145729_752:
    old "So, as she grew up, my focus was on my work."
    new "所以，随着她的成长，我的重心都在工作上。"

translate chinese chinese_3584735_753:
    old "Since I was always working, I never had any time for her or the things related to school."
    new "因为我总是忙于工作，所以从来没有时间陪她或者处理学校的事情。"

translate chinese chinese_3728296_754:
    old "Is not that I wasn't interested, is just that I was busy all the time."
    new "不是我不感兴趣，只是我一直都很忙。"

translate chinese chinese_6097034_755:
    old "I sort of thought that as long as I was providing for her, things would be fine."
    new "我总觉得只要我养着她，事情就会好起来。"

translate chinese chinese_4739528_756:
    old "But I didn't realize she was pulling away from me. Nowadays I never know what she's doing."
    new "但我没意识到她正在疏远我。现在我真的不知道她在做什么。"

translate chinese chinese_3896034_757:
    old "Her interests, or the things she's into..."
    new "她的兴趣爱好或者喜欢的东西……"

translate chinese chinese_2789325_758:
    old "It's a miracle I even know Hinn, and that's just because I came home one time while she was here."
    new "我竟然认识希恩，这简直是个奇迹，而且仅仅是因为有一次我回家时她正好在这里。"

translate chinese chinese_7567234_759:
    old "Oh, and that other friend... Mike."
    new "哦，还有那个朋友……迈克。"

translate chinese chinese_5506230_760:
    old "But I'd rather not to talk about him."
    new "但我宁愿不谈他。"

translate chinese chinese_8615643_761:
    old "I- I'm sorry about that M- Mrs... I- I mean A- Ashley."
    new "我... 对不起，M... 夫人... 我... 的意思是A... 艾希利。"

translate chinese chinese_7105539_762:
    old "But I'm sure you and Belle will be fine."
    new "但我相信你和贝尔会没事的。"

translate chinese chinese_1765745_763:
    old "You think so?"
    new "你这么认为？"

translate chinese chinese_8947090_764:
    old "For sure, after all, you say you've always been close."
    new "当然了，毕竟你说你们一直很亲近。"

translate chinese chinese_4019592_765:
    old "I'm sure Belle's just..."
    new "我敢肯定贝尔只是..."

translate chinese chinese_8703028_766:
    old "Uhm... Worried about things from school and such."
    new "嗯……担心学校的事情之类的。"

translate chinese chinese_0294985_767:
    old "I guess I'll have to take your word for it. After all, you may be more informed about what she's doing lately than me."
    new "我猜我只能相信你了。毕竟，你可能比我更了解她最近在做什么。"

translate chinese chinese_5501904_768:
    old "The good thing is that she doesn't seem to be doing anything weird or out of the ordinary."
    new "好的是，她看起来没有什么异常的举动。"

translate chinese chinese_9617814_769:
    old "She's just focused on school."
    new "她只是专注于学习。"

translate chinese chinese_0359342_770:
    old "Although I think it would be good if she went out a little bit more. She seems to expend most of her time on her computer."
    new "虽然我觉得她多出去走走会比较好。她好像大部分时间都花在电脑上了。"

translate chinese chinese_1597483_771:
    old "But I guess that's good, at least she's not doing anything bad."
    new "不过这样也好，至少她没有做坏事。"

translate chinese chinese_2908541_772:
    old "Uhh, sure..."
    new "呃，好吧……"

translate chinese chinese_2153424_773:
    old "But anyway, enough of my lamenting, it's getting a little late [pla], and you've been here for a while."
    new "不过话说回来，别再听我抱怨了，已经有点晚了[pla]，你也在这儿待了一段时间了。"

translate chinese chinese_8738939_774:
    old "Why don't you go home for now? We can continue working some other time."
    new "你先回家吧，我们改天再继续工作。"

translate chinese chinese_2389524_775:
    old "Oh! Sure!"
    new "哦！当然！"

translate chinese chinese_0312934_776:
    old "I'll see you later then. Goodbye, Ashley."
    new "那回头见吧。再见，阿什利。"

translate chinese chinese_9535572_777:
    old "Goodbye hon, thanks for your help today."
    new "拜拜亲爱的，谢谢今天帮忙。"

translate chinese chinese_6350457_778:
    old "And thank you, for listening to me."
    new "谢谢你听我说。"

translate chinese chinese_1395349_779:
    old "Gladly, I'm happy to help you, and to talk to you."
    new "很乐意，我愿意帮助你，也愿意和你聊天。"

translate chinese chinese_4600678_780:
    old "That's very sweet."
    new "真甜。"

translate chinese chinese_7455024_781:
    old "I think I should get going then."
    new "那我还是走吧。"

translate chinese chinese_1306140_782:
    old "Yeah, yeah, sure. Bye."
    new "好吧，好吧，再见。"

translate chinese chinese_1096016_783:
    old "Hi [pla], how are you?"
    new "嗨 [pla]，你好吗？"

translate chinese chinese_3944395_784:
    old "Well, I wanted to discuss what we're going to do for our next stream together."
    new "好吧，我想讨论一下我们下次一起直播要做什么。"

translate chinese chinese_3132853_785:
    old "Well, I know you had to help my mom with that website she's working on."
    new "嗯，我知道你得帮我妈妈做她正在做的那个网站。"

translate chinese chinese_5659055_786:
    old "But I think today you're supposed to be free, right?"
    new "但是今天你应该有空吧？"

translate chinese chinese_7189557_787:
    old "So, do you think you could come to my house today?"
    new "所以，你觉得今天能来我家吗？"

translate chinese chinese_2701374_788:
    old "Great! So let's go after classes."
    new "太好了！那我们就放学后去吧。"

translate chinese chinese_4704828_789:
    old "Ok, let's go."
    new "好，我们走。"

translate chinese chinese_6915147_790:
    old "Right, let's do it."
    new "好，我们开始吧。"

translate chinese chinese_3760735_791:
    old "Alright, let's do this!"
    new "好吧，干吧！"

translate chinese chinese_7428540_792:
    old "Wait, before we start."
    new "等一下，开始之前。"

translate chinese chinese_2255193_793:
    old "Are you sure you want to do this?"
    new "你确定要这么做吗？"

translate chinese chinese_1942422_794:
    old "I know it's not that big a deal to some people, but  you would be doing it for the first time."
    new "我知道对有些人来说这不算什么大事，但对你来说可是第一次。"

translate chinese chinese_2450629_795:
    old "I am, listen [pla], I've worked very hard for this."
    new "我是认真的，听好了[pla]，我为了这个付出了很多努力。"

translate chinese chinese_2498769_796:
    old "Winning this award means a lot to me."
    new "赢得这个奖项对我来说意义重大。"

translate chinese chinese_4280821_797:
    old "And I'm not backing down because of Lana suddenly coming into the scene."
    new "我不会因为 Lana 突然出现就退缩。"

translate chinese chinese_9923172_798:
    old "So yeah, I'm sure!"
    new "没错，我敢肯定！"

translate chinese chinese_7723946_799:
    old "Ok, if you're this determined, let's do it."
    new "好吧，如果你这么坚持，我们就来吧。"

translate chinese chinese_7809960_800:
    old "Yeah! Let's do it!"
    new "yeah! 干就完了！"

translate chinese chinese_6696096_801:
    old "Hello again guys!"
    new "大家好啊！"

translate chinese chinese_6988439_802:
    old "I'm very happy to see you all again!"
    new "很高兴又见到大家！"

translate chinese chinese_3454475_803:
    old "And I have very good news, everybody!"
    new "而且我有个非常好的消息要告诉大家！"

translate chinese chinese_1697395_804:
    old "Remember the other surprise I'd talked to you about?!"
    new "还记得我之前跟你说的另一个惊喜吗？！"

translate chinese chinese_0111256_805:
    old "Well, it's happening today!"
    new "好吧，今天就发生了！"

translate chinese chinese_0295887_806:
    old "I know this is something you've been dying to see!"
    new "我知道这正是你渴望看到的！"

translate chinese chinese_5917609_807:
    old "And I know you will love it!"
    new "而且我知道你会喜欢的！"

translate chinese chinese_5305900_808:
    old "So, say hello again to my friend, and let's get to it!"
    new "所以，再跟我朋友打个招呼，我们开始吧！"

translate chinese chinese_2281190_809:
    old "Remember guys, just as always! Today's surprise can only come if you guys reach our goal."
    new "大家记得，还是老规矩！今天的惊喜只有达到目标才能解锁。"

translate chinese chinese_7570249_810:
    old "But I'm sure you'll reach it!"
    new "但我相信你一定能达到的！"

translate chinese chinese_5688758_811:
    old "For today we're going to need it well lubricated, isn't that right, guys?"
    new "今天我们需要它充分润滑一下，对吧，伙计们？"

translate chinese chinese_4393740_812:
    old "So I'll take care of doing a good job with my mouth to get it ready for what comes next."
    new "那我就先用嘴好好服务，为接下来的事情做好准备。"

translate chinese chinese_2231132_813:
    old "My God! What a great cock!"
    new "天啊！真大的 cocks!"

translate chinese chinese_3526375_814:
    old "Right guys?!"
    new "对吧伙计们?!"

translate chinese chinese_7686433_815:
    old "I bet you can't wait to see me being ravaged by it."
    new "我敢打赌，你一定等不及想看到我被它糟蹋的样子了。"

translate chinese chinese_0167191_816:
    old "Just be sure to get to the goal guys!"
    new "大家只要确保达到目标就行了！"

translate chinese chinese_9655804_817:
    old "Uh- I- uh..."
    new "呃——我——呃……"

translate chinese chinese_3192190_818:
    old "I came to do something with Belle."
    new "我是来找贝儿做些事情的。"

translate chinese chinese_7980711_819:
    old "Some... Uh- school work..."
    new "一些... 嗯-学校作业..."

translate chinese chinese_5622193_820:
    old "Ok, I see, but where is Belle?"
    new "好的，我明白了，但贝尔在哪里？"

translate chinese chinese_4489971_821:
    old "She... Uh- she went out for a while."
    new "她……嗯，她出去了一下。"

translate chinese chinese_5743499_822:
    old "She said something about picking up a thing at Hinn's house."
    new "她说要去Hinn家拿什么东西。"

translate chinese chinese_0680750_823:
    old "I had to pop home to get some documents for work, and I wanted to talk with her."
    new "我回家拿了一些工作文件，还想和她谈谈。"

translate chinese chinese_0026121_824:
    old "Well, it's good to see you anyway."
    new "不管怎样，见到你真好。"

translate chinese chinese_8070500_825:
    old "I'll go back to the office, please tell Belle to give me a call when she gets back."
    new "我回办公室了，请告诉她贝尔回来后给我打电话。"

translate chinese chinese_0373216_826:
    old "See you later [pla]."
    new "再见 [pla]。"

translate chinese chinese_8375859_827:
    old "Sure, see you later ma'am."
    new "好的，女士，回头见。"

translate chinese chinese_1587274_828:
    old "{i}What the fuck just happened...{/i}"
    new "{i}刚刚到底发生了什么……{/i}"

translate chinese chinese_5678707_829:
    old "{i}Holy shit, I know... Anyway, let's just keep going with the stream... Shhh...{/i}"
    new "{i}卧槽，我知道……不管怎样，咱们还是继续直播吧……嘘……{/i}"

translate chinese chinese_0187092_830:
    old "Sorry, guys! I'm sorry for that little interruption... You know, this can happen when you're doing it live..."
    new "对不起，大家！刚才那个小插曲真是抱歉……你们知道的，直播时这种情况有时会发生……"

translate chinese chinese_3172880_831:
    old "Anyways, let's continue with the show!"
    new "总之，让我们继续表演吧！"

translate chinese chinese_8239679_832:
    old "But now we can resume with what we were doing, and you know what that means."
    new "但现在我们可以继续刚才的事情了，你知道那意味着什么。"

translate chinese chinese_5809828_833:
    old "No, she won't be joining us or anything."
    new "不，她不会加入我们的。"

translate chinese chinese_9893236_834:
    old "That was just an unplanned thing."
    new "那只是个意外。"

translate chinese chinese_3291995_835:
    old "But don't worry, we're not stopping here."
    new "但不用担心，我们不会在这里停下来。"

translate chinese chinese_5898146_836:
    old "Let's keep going!"
    new "我们继续吧！"

translate chinese chinese_0801778_837:
    old "Wow, that was close!"
    new "哇，那真是险啊！"

translate chinese chinese_6004942_838:
    old "Really close."
    new "差一点就成功了。"

translate chinese chinese_4123434_839:
    old "That really scared me."
    new "那真的吓到我了。"

translate chinese chinese_3324597_840:
    old "It's good that she didn't see us doing anything."
    new "还好她没看到我们做什么。"

translate chinese chinese_7757594_841:
    old "I can't imagine how we would explain the whole situation to her."
    new "我简直无法想象我们要怎么把整个情况解释给她听。"

translate chinese chinese_1915436_842:
    old "Yeah, tell me about it."
    new "是啊，跟我说说。"

translate chinese chinese_1580699_843:
    old "Well, we should get back to the stream before the fans get impatient."
    new "好吧，我们还是回直播去吧，别让粉丝们等得不耐烦了。"

translate chinese chinese_1113074_844:
    old "Hngh! Oh yes!"
    new "嗯！哦 yeah！"

translate chinese chinese_9053532_845:
    old "This is what you've all been waiting for isn't it?"
    new "这就是你们一直期待的，对吧？"

translate chinese chinese_0131759_846:
    old "Well, you earned it!"
    new "好吧，你赚到了！"

translate chinese chinese_8046226_847:
    old "So, be sure to enjoy it!"
    new "所以，一定要享受哦！"

translate chinese chinese_5817739_848:
    old "Guys! I'm so glad you liked it!"
    new "大家！你们喜欢真是太好了！"

translate chinese chinese_6851081_849:
    old "You keep making all of this possible."
    new "你让这一切都成为可能。"

translate chinese chinese_8342794_850:
    old "Witout your support this just wouldn't be possible."
    new "没有你的支持，这根本不可能实现。"

translate chinese chinese_7112432_851:
    old "So, it makes me very happy to do this kind of thing for you."
    new "所以，为你做这种事让我很开心。"

translate chinese chinese_5086875_852:
    old "Ok guys, I have to leave for now."
    new "好了，我得先走了。"

translate chinese chinese_3619817_853:
    old "But be sure that I'll be back soon with another stream."
    new "但放心，我很快就会带着另一场直播回来的。"

translate chinese chinese_8952548_854:
    old "I wonder what surprise I'll have for you then?"
    new "不知道我又能给你什么惊喜呢？"

translate chinese chinese_7547830_855:
    old "As always remember to subscribe so you will get notified of the next stream!"
    new "别忘了订阅，这样你就能收到下次直播的通知了！"

translate chinese chinese_8292805_856:
    old "And remember to follow me on all my socials."
    new "别忘了关注我所有的社交平台。"

translate chinese chinese_4689220_857:
    old "So you won't miss any updates!"
    new "这样你就不会错过任何更新了！"

translate chinese chinese_9154765_858:
    old "Until next time, see you guys! Love you!"
    new "下次见，大家再见！爱你们！"

translate chinese chinese_6881140_859:
    old "That came out really well [pla]!"
    new "这效果真不错[pla]！"

translate chinese chinese_2889699_860:
    old "They matched the goal so quickly!"
    new "他们达到目标这么快！"

translate chinese chinese_4645586_861:
    old "I'm sure I'll overtake Lana in no time!"
    new "我肯定很快就能超过兰娜！"

translate chinese chinese_3673413_862:
    old "And this time I'm certain the first spot in the rankings is mine for sure!"
    new "这次我确定排行榜的第一名非我莫属了！"

translate chinese chinese_6010023_863:
    old "That's great to hear Belle, I'm sure you'll get it."
    new "听到这个真好，贝尔，我相信你能行的。"

translate chinese chinese_3792800_864:
    old "Although I hope your fans weren't bothered by your mom coming in midstream."
    new "虽然希望你的粉丝不会因为你妈妈中途出现而感到困扰。"

translate chinese chinese_4896937_865:
    old "That really scared me, I thought she was going to see us."
    new "真的吓死我了，我还以为她会看到我们。"

translate chinese chinese_6995342_866:
    old "Yeah, me too, I'm sorry that happened, by the way."
    new "是啊，我也是，对了，真抱歉发生了那样的事。"

translate chinese chinese_7082517_867:
    old "She just had to come in at the most inopportune time."
    new "她偏偏选在这个最糟糕的时机出现。"

translate chinese chinese_2837313_868:
    old "But don't worry, the fans weren't too bothered by her intrusion."
    new "但不用担心，粉丝们对她插播的内容并没有太介意。"

translate chinese chinese_3476023_869:
    old "Yeah... they were writing how thrilling it was."
    new "嗯……他们在写有多刺激。"

translate chinese chinese_0809742_870:
    old "So many of them were even writing how hot it would be to see my mom fuck with us."
    new "他们甚至写了很多觉得看到我妈妈和我们搞在一起会很带劲的话。"

translate chinese chinese_9833276_871:
    old "But leaving that aside, everything went better than I expected."
    new "但撇开那件事不谈，一切都比我预期的要好。"

translate chinese chinese_9696485_872:
    old "Thanks a lot [pla], this wouldn't have been possible without you."
    new "谢谢你[pla]，没有你这是不可能的。"

translate chinese chinese_9160033_873:
    old "Don't even mention it, I'm happy I can help you."
    new "别提了，能帮你我高兴还来不及呢。"

translate chinese chinese_5619688_874:
    old "I know how much this means to you."
    new "我知道这对你意味着多少。"

translate chinese chinese_7344402_875:
    old "But even still, is not as if this is just nothing."
    new "但是，这也不是什么都没有的事。"

translate chinese chinese_0321043_876:
    old "After all, we're... Getting closer."
    new "毕竟，我们……越来越近了。"

translate chinese chinese_4271703_877:
    old "Yeah... We are."
    new "嗯……我们是的。"

translate chinese chinese_9205629_878:
    old "Well, I think I should leave for now."
    new "嗯，我想我现在应该离开了。"

translate chinese chinese_8054340_879:
    old "Right, for sure! I think I better get dressed and call my mom before she goes crazy because I haven't talked to her."
    new "对，肯定的！我觉得我最好先穿好衣服，然后给我妈打个电话，免得她因为我没联系她而着急。"

translate chinese chinese_8795498_880:
    old "Once again [pla], thanks."
    new "再次感谢你，[pla]。"

translate chinese chinese_4854643_881:
    old "You're doing so much for me, I can't thank you enough."
    new "你为我做了这么多，我都不知道怎么感谢你。"

translate chinese chinese_1125381_882:
    old "Don't worry, I'm just happy I can help you Belle, with anything you need."
    new "别担心，我就是高兴能帮你，贝尔，无论你需要什么。"

translate chinese chinese_4831909_883:
    old "I'll leave for now, see you later."
    new "我先走了，回头见。"

translate chinese chinese_3702137_884:
    old "Hi Ashley, I came to help you with the website."
    new "嗨，Ashley，我来帮你弄网站了。"

translate chinese chinese_3094429_885:
    old "Oh, is good that you're here I need your help with something right now."
    new "哦，你在这真好，我现在需要你的帮忙。"

translate chinese chinese_1974995_886:
    old "Well, I was thinking about the design of the banners that we're making for the coffee shop."
    new "嗯，我在想我们为咖啡店设计的横幅该怎么弄。"

translate chinese chinese_7168379_887:
    old "And I remembered some banners that we had made before but never got around to releasing."
    new "然后我想起了一些我们之前做但一直没有发布的横幅。"

translate chinese chinese_8758720_888:
    old "I think we'll be able to reuse some of those ready-made designs to add them to the website."
    new "我觉得我们可以重用一些现成的设计，添加到网站上。"

translate chinese chinese_0799790_889:
    old "I remembered that I saved those designs on an old flash drive, and I placed it up there on the shelves."
    new "我记得那些设计存在一个旧的闪存驱动器里，我把它放在架子上了。"

translate chinese chinese_3538892_890:
    old "But it's a bit too high for me to reach by myself without risking falling over."
    new "但是对我来说有点太高了，自己够的话可能会摔跤。"

translate chinese chinese_7093271_891:
    old "So, I need you to help me stay stable on the ladder while I look for it."
    new "所以，我需要你在梯子上帮我保持稳定，让我找东西。"

translate chinese chinese_5397756_892:
    old "Uhh, s- sure, no problem."
    new "呃，好、好的，没问题。"

translate chinese chinese_3906385_893:
    old "Thank you, hun."
    new "谢谢你，亲爱的。"

translate chinese chinese_9462215_894:
    old "Are you okay there? Can you reach it?"
    new "你还好吗？够得着吗？"

translate chinese chinese_7201129_895:
    old "Yeah, I'm close. Just a little more and I'll grab it."
    new "嗯，我快到了。再靠近一点就能拿到了。"

translate chinese chinese_5656631_896:
    old "{i}(... Damn, I hadn't thought about it, but Ashley's really hot.){/i}"
    new "(... 哎呀，没想到，Ashley 真的很辣。)"

translate chinese chinese_6569492_897:
    old "{i}(Maybe it is because she's so young, but wow, her body's amazing!){/i}"
    new "{i}(也许是因为她还那么年轻，但她身体真是棒极了！){/i}"

translate chinese chinese_7160178_898:
    old "{i}(I mean, just look at her ass...){/i}"
    new "{i}（我是说，就看看她的屁股...）{/i}"

translate chinese chinese_8860444_899:
    old "{i}(Oh shit! I'm getting horny.){/i}"
    new "{i}(哦shit！我开始兴奋了。){/i}"

translate chinese chinese_9027021_900:
    old "{i}(I have to calm down or I'll get a boner){/i}"
    new "{i}（我得冷静一下，不然会硬起来的）{/i}"

translate chinese chinese_8097001_901:
    old "[pla]? Is everything alright?"
    new "[pla]？一切都好吗？"

translate chinese chinese_7734677_902:
    old "Uh, yeah, yeah... Why do you ask?"
    new "嗯，是啊，是啊……你为什么问这个？"

translate chinese chinese_3378239_903:
    old "Well, you moved suddenly, so I was wondering if I made you lose your balance."
    new "你突然动了一下，我就在想是不是我让你失去平衡了。"

translate chinese chinese_3295719_904:
    old "No, no, Uhh, nothing happened, it's ok."
    new "不，不，啊，没什么事，没事的。"

translate chinese chinese_1015496_905:
    old "Uh, ok... sure."
    new "呃，好……行。"

translate chinese chinese_3197106_906:
    old "{i}(Shit! I better calm down before I get a boner.){/i}"
    new "{i}（糟了！我得冷静一下，别硬起来了。){/i}"

translate chinese chinese_0751360_907:
    old "Ok, I think I've got them, I'm coming down."
    new "好的，我想我拿到了，我下来。"

translate chinese chinese_6684407_908:
    old "Oh, alright."
    new "哦，好吧。"

translate chinese chinese_9319328_909:
    old "Ughh, damn, that was painful."
    new "哎呀，真他妈疼。"

translate chinese chinese_7432112_910:
    old "{i}(Hmm? What is this? What do I have on my face?){/i}"
    new "哼？这是什么？我脸上有什么？"

translate chinese chinese_5779948_911:
    old "{i}(Oh wow, it's Ashley's ass!){/i}"
    new "{i}（天啊，这是Ashley的臀部！）{/i}"

translate chinese chinese_0820211_912:
    old "{i}(D- Damn! I better get up before she I get a boner!){/i}"
    new "{i}(该死！我得赶紧起来，不然就尴尬了！){/i}"

translate chinese chinese_9261195_913:
    old "Ouch, that really hurt."
    new "哎哟，真疼。"

translate chinese chinese_0304313_914:
    old "I'm sorry [pla], I don't know what happened, are you okay?"
    new "对不起[pla]，我不知道发生了什么，你还好吗？"

translate chinese chinese_5626420_915:
    old "{i}(Oh fuck, just what I wanted to avoid! I got a boner!){/i}"
    new "{i}(哦操，正是我想避免的！我硬起来了！){/i}"

translate chinese chinese_6753580_916:
    old "{i}(Oh my gosh! H- He's got a boner!){/i}"
    new "{i}(天啊！他硬起来了！){/i}"

translate chinese chinese_4689560_917:
    old "Y- yeah, I- I am. I'm sorry, I think I was the one who slipped."
    new "嗯，我——我是。对不起，我觉得是我自己滑倒的。"

translate chinese chinese_9975647_918:
    old "Uh... A- Ashley? Can you please move?"
    new "呃……阿什利？你能让开一下吗？"

translate chinese chinese_1235898_919:
    old "Uh, I- I..."
    new "呃，我—我..."

translate chinese chinese_0335049_920:
    old "Is just that you have a..."
    new "就是你有个..."

translate chinese chinese_1968763_921:
    old "I- I uh... I'm sorry Ashley, it wasn't my intention..."
    new "我……对不起，Ashley，我不是故意的……"

translate chinese chinese_6506179_922:
    old "I- its just that..."
    new "我——就是觉得..."

translate chinese chinese_7527580_923:
    old "It's fine, it's fine."
    new "没事，没事。"

translate chinese chinese_3896791_924:
    old "You're a young man after all. It's perfectly understandable that this happens."
    new "你畢竟是個小伙子，這很正常。"

translate chinese chinese_3161992_925:
    old "I fell on you and... M- my butt landed on your face..."
    new "我扑到你身上了，而且……我的屁股压到你的脸上了……"

translate chinese chinese_8816594_926:
    old "So, I think I understand that you would get a..."
    new "所以，我想我明白你会得到一个..."

translate chinese chinese_1444938_927:
    old "Uhh... T- thank you... for understanding."
    new "呃……谢谢……你的理解。"

translate chinese chinese_7434677_928:
    old "Hmm... Sure, i- it's very normal."
    new "嗯……好，我——这很正常。"

translate chinese chinese_5853711_929:
    old "Uhh, s- should we get to working on the website then?"
    new "呃，咱，咱们开始做网站吧？"

translate chinese chinese_3273705_930:
    old "I- I don't think that's a good idea right now [pla]."
    new "我——我觉得现在这样做不太好，[pla]。"

translate chinese chinese_8417578_931:
    old "B- because I have to bring the banners to my team in the office, so they can use them to design the new ones."
    new "因为我要把横幅带到办公室给团队，他们要用这些来设计新的横幅。"

translate chinese chinese_9070167_932:
    old "Oh... Alright."
    new "哦……好吧。"

translate chinese chinese_7136689_933:
    old "I- I think I'll leave for now, see you later."
    new "我- 我先走了，回头见。"

translate chinese chinese_1539681_934:
    old "Y- yeah... S- see you later hon."
    new "嗯……那回头见甜心。"

translate chinese chinese_1094694_935:
    old "Wow, he really has it very big c-... Now I understand why Belle likes him so much..."
    new "哇，他真的很大啊……现在我懂为什么贝儿这么喜欢他了……"

translate chinese chinese_3942216_936:
    old "Hey Belle, good morning, how are you?"
    new "嘿，贝儿，早上好，怎么样？"

translate chinese chinese_0154612_937:
    old "To be honest, I'm quite upset..."
    new "老实说，我挺生气的……"

translate chinese chinese_5996548_938:
    old "Why? What happened now?"
    new "为什么？这次发生了什么？"

translate chinese chinese_8661139_939:
    old "Well, it's that bitch Lana."
    new "好吧，就是那个臭婆娘莉娜。"

translate chinese chinese_0189546_940:
    old "You won't believe what she pulled now!"
    new "你猜她这次干了什么！"

translate chinese chinese_0831038_941:
    old "W- what? Why?!"
    new "什、什么？为什么！？"

translate chinese chinese_8041126_942:
    old "I thought that you had surpassed her with what we did last time."
    new "我还以为你上次已经超越她了。"

translate chinese chinese_1693241_943:
    old "And we did!"
    new "我们做到了！"

translate chinese chinese_8917531_944:
    old "After our last streaming session I went up on the charts by a lot."
    new "上次直播后，我的排名上升了很多。"

translate chinese chinese_4305214_945:
    old "So, I guess Lana felt desperate or something."
    new "所以，我想Lana可能是感到很绝望吧。"

translate chinese chinese_1682542_946:
    old "Because then she came out and did a threesome!"
    new "因为然后她就出来搞了个三人行！"

translate chinese chinese_8654691_947:
    old "A threesome?"
    new "三人行？"

translate chinese chinese_4849041_948:
    old "Yeah, she just did it out of nowhere."
    new "是的，她刚才突然就那么做了。"

translate chinese chinese_6068232_949:
    old "You know what really triggers me? She didn't even do it with another cam streamer or anything!"
    new "你知道什么真的让我抓狂吗？她甚至不是和另一个摄像头主播做的！"

translate chinese chinese_7323864_950:
    old "But of course she didn't, she doesn't know anybody in this business."
    new "但她当然不知道了，她在这个圈子里谁都不认识。"

translate chinese chinese_1203225_951:
    old "I bet she just paid some amateur pornstar to do it with her, that whore!"
    new "我敢打赌她肯定是找了个业余的 pornstar 来陪她做那事，这个婊子！"

translate chinese chinese_2466455_952:
    old "OK, what is your plan then?"
    new "好，那你打算怎么办？"

translate chinese chinese_1600125_953:
    old "What do you mean what is my plan? I'm going to answer her the same way of course?"
    new "你说我的计划是什么？当然是用同样的方式回应她啊？"

translate chinese chinese_8164834_954:
    old "Uhh, really? Are you sure?"
    new "呃，真的吗？你确定？"

translate chinese chinese_3242226_955:
    old "Of course I'm sure [pla], I've done too much to win this contest."
    new "当然确定 [pla]，我已经做了太多来赢得这个比赛了。"

translate chinese chinese_8774703_956:
    old "I've been working hard to get every vote I've received."
    new "我一直在努力争取每一张选票。"

translate chinese chinese_8951907_957:
    old "I've augmented the number of times I stream weekly. I roped you into this."
    new "我增加了每周直播的次数。还把你拉进来了。"

translate chinese chinese_3689011_958:
    old "I even let you fuck me in the ass!"
    new "我甚至让你肛我了！"

translate chinese chinese_0799573_959:
    old "I've worked hard for this, and I'm not going to let some newcomer take it away."
    new "我为此努力了很久，不会让什么新人给抢走的。"

translate chinese chinese_2275872_960:
    old "Well, I don't know what to tell you."
    new "好吧，我不知道该怎么跟你说。"

translate chinese chinese_8166562_961:
    old "You don't have to say anything, all I need is for you to be willing to help me when I need it."
    new "你不用说什么，我只需要你在需要的时候愿意帮我就行了。"

translate chinese chinese_5447707_962:
    old "Of course! You know I'll help you with anything I can."
    new "当然了！你知道我会尽我所能帮你。"

translate chinese chinese_5696971_963:
    old "Thanks [pla], I'm glad I can count on you."
    new "谢谢[pla]，能依靠你真好。"

translate chinese chinese_0226827_964:
    old "Also, I already have someone in mind who can help us with the threesome."
    new "而且，我已经想到一个人可以帮我们进行三人行了。"

translate chinese chinese_3512480_965:
    old "I'll have to contact her and see when she would be available to arrange everything for the stream."
    new "我得联系她，看看她什么时候有空安排直播的事情。"

translate chinese chinese_3757334_966:
    old "Meanwhile, you have to work with my mom the next time you come home, right?"
    new "话说，下次回家你得和我妈妈一起工作，对吧？"

translate chinese chinese_3012945_967:
    old "Uhh, yeah, we are still working on the website, there are still several things left to finish."
    new "嗯，对，网站还在制作中，还有一些事情没完成。"

translate chinese chinese_6257192_968:
    old "Ok, so while you do that I'll talk with my friend and see if she can help us."
    new "好的，那你去忙吧，我先跟我朋友聊聊，看看她能不能帮上忙。"

translate chinese chinese_5051685_969:
    old "I'll let you know as soon as we can do it."
    new "我们一能做我就告诉你。"

translate chinese chinese_4476960_970:
    old "Uhh, alright."
    new "呃，好吧。"

translate chinese chinese_1084418_971:
    old "Great, then see you later [pla]."
    new "好的，那再见了，[pla]。"

translate chinese chinese_9611242_972:
    old "See you Belle."
    new "再见，贝勒。"

translate chinese chinese_3607249_973:
    old "Well, I was thinking I could keep helping you develop the website."
    new "嗯，我在想我可以继续帮你开发网站。"

translate chinese chinese_5850192_974:
    old "Hmm... There might be a problem with that [pla]."
    new "嗯……那个[pla]可能有问题。"

translate chinese chinese_6489821_975:
    old "Hmm, what is it?"
    new "嗯，是什么？"

translate chinese chinese_1251013_976:
    old "Well, my laptop isn't working right now."
    new "好吧，我现在的笔记本电脑坏了。"

translate chinese chinese_0728269_977:
    old "I was... Uh, u- using it the other day, looking for some... References."
    new "我……嗯，那天在用它找一些……参考。"

translate chinese chinese_6047934_978:
    old "But it suddenly stopped working."
    new "但是突然就不行了。"

translate chinese chinese_4892386_979:
    old "I can turn it on now, it will even power up normally."
    new "我现在可以打开它了，甚至能正常启动。"

translate chinese chinese_3855314_980:
    old "But after that, it doesn't work."
    new "但是之后就不管用了。"

translate chinese chinese_5694085_981:
    old "What do you mean? The screen just stays black?"
    new "你的意思是说屏幕一直黑着吗？"

translate chinese chinese_0507691_982:
    old "No, it's not that. Once it's fully turned on, you simply can't do anything with it."
    new "不，不是那样的。一旦完全启动，你就根本无法对它进行任何操作。"

translate chinese chinese_0501457_983:
    old "If you click on something, multiple windows open up, and when you attempt to use the web browser, numerous tabs start to open up."
    new "如果你点击某个东西，会弹出多个窗口，而且当你尝试使用网页浏览器时，会自动打开许多标签页。"

translate chinese chinese_9124018_984:
    old "And you can't close them down or do anything about it."
    new "而你没办法关闭它们或者做些什么。"

translate chinese chinese_8725557_985:
    old "Hmm, that sounds like an adware."
    new "嗯，这听起来像是广告软件。"

translate chinese chinese_7602167_986:
    old "But don't worry, I think I can fix it."
    new "但别担心，我觉得我能解决。"

translate chinese chinese_4803744_987:
    old "Yeah, all I have to do is run an antivirus through it, and it should be completely fine."
    new "嗯，我只需要运行一下杀毒软件，应该就能完全搞定。"

translate chinese chinese_8083239_988:
    old "That sounds great! Alright, let's do it."
    new "听起来不错！好吧，我们就这么办。"

translate chinese chinese_0472386_989:
    old "There, that's what happens as soon as you try to use it."
    new "看到了吧，你一用它就出问题。"

translate chinese chinese_7973244_990:
    old "Hmm, yeah, I see what you mean."
    new "嗯，是啊，我明白你的意思。"

translate chinese chinese_2647744_991:
    old "Yeah, this appears to be an adware virus. But don't worry, it can be easily fixed."
    new "嗯，这看起来是个广告软件病毒。但别担心，很容易解决。"

translate chinese chinese_7115235_992:
    old "I just have to run the antivirus, and it will take care of cleaning up all those annoying ads."
    new "我只要运行一下杀毒软件，就能清理掉那些烦人的广告了。"

translate chinese chinese_7768728_993:
    old "It should start to work quickly."
    new "应该很快就会起作用。"

translate chinese chinese_4880395_994:
    old "See? It's already starting to work."
    new "看吧，已经开始起作用了。"

translate chinese chinese_6470917_995:
    old "Ok, now it's searching for viruses and malicious content."
    new "好的，现在正在搜索病毒和恶意内容。"

translate chinese chinese_1173880_996:
    old "As soon as it's done with the scanning, it will start deleting all the damaged files and threats to the system."
    new "扫描一完成，它就会开始删除所有受损文件和系统威胁。"

translate chinese chinese_7803828_997:
    old "Wow, you're very good with computers [pla]."
    new "哇，你电脑用得很溜啊[pla]。"

translate chinese chinese_1423193_998:
    old "Well, it's not as difficult as it seems, heh."
    new "嗯，其实也没那么难嘛，嘿嘿。"

translate chinese chinese_3969273_999:
    old "Ok, it's almost done, it shouldn't take much longer."
    new "好的，快搞定了，应该不会花太长时间。"

translate chinese chinese_5641166_1000:
    old "Wow, I didn't know it was so fast. I thought I would have to take it for maintenance and it would take days."
    new "wow，没想到这么快。我还以为得送去维修，要好几天呢。"

translate chinese chinese_3471004_1001:
    old "Okay, we're done. The viruses that were affecting your computer should have been eliminated by now."
    new "好了，我们结束了。影响你电脑的病毒应该已经被清除了。"

translate chinese chinese_4018110_1002:
    old "Great, thank you!"
    new "太好了，谢谢！"

translate chinese chinese_8506516_1003:
    old "Just let me refresh it and we'll see..."
    new "让我刷新一下，我们就知道了……"

translate chinese chinese_9287598_1004:
    old "Now, all of those ads and windows that it opened previously should start closing down."
    new "现在，之前打开的所有广告和窗口都应该开始关闭了。"

translate chinese chinese_0815602_1005:
    old "Oh! there's a webpage from your previous session."
    new "哦！这里有你上次会话的网页。"

translate chinese chinese_6416391_1006:
    old "Hmm, let's see, what does it say?"
    new "嗯，让我看看，上面写了什么？"

translate chinese chinese_0833211_1007:
    old "Sneaky Stepmom Fucks Step Daugther's Boyfri-..."
    new "偷情继母和继女男友..."

translate chinese chinese_2272099_1008:
    old "Oh! T- that's..."
    new "哦！那..."

translate chinese chinese_1513017_1009:
    old "I- I Uh- I- I'm sorry [pla]! I don't know what that's doing in there."
    new "我……对不起[pla]！我不知道那东西怎么会在那里。"

translate chinese chinese_7958090_1010:
    old "M- maybe the virus s- send us to that website!"
    new "M-也许病毒让我们去了那个网站！"

translate chinese chinese_8053430_1011:
    old "Uhm... Yeah, that's probably what happened."
    new "嗯……对，大概就是那样吧。"

translate chinese chinese_7033743_1012:
    old "W- well, let's just close it. And keep checking if the pc is fine."
    new "嗯，那我们就先关掉吧。然后继续检查电脑有没有问题。"

translate chinese chinese_6120510_1013:
    old "Okay, I think the computer is good to go."
    new "好的，我觉得电脑可以用了。"

translate chinese chinese_7968019_1014:
    old "Now it shouldn't be a problem to continue with the work."
    new "现在继续工作应该没问题了。"

translate chinese chinese_5234966_1015:
    old "Ohh, t- thank you [pla]."
    new "哦，谢谢你，[pla]。"

translate chinese chinese_0636948_1016:
    old "I- It's great that you managed to get it working again."
    new "你能让它重新工作真是不错。"

translate chinese chinese_9227274_1017:
    old "And I'm sorry about that website that you saw."
    new "对于你看到的那个网站，我感到很抱歉。"

translate chinese chinese_7870319_1018:
    old "I don't know how that got in there."
    new "我不知道那东西怎么进去了。"

translate chinese chinese_0758854_1019:
    old "Uhh sure... I'm just glad I can be of help."
    new "呃，好吧……我只希望能帮上忙。"

translate chinese chinese_6341922_1020:
    old "That's very nice of you."
    new "你真好。"

translate chinese chinese_7667436_1021:
    old "Uhh, I guess we should continue working, right?"
    new "呃，我想我们应该继续工作吧？"

translate chinese chinese_9450517_1022:
    old "Oh, sure, we should get to that."
    new "哦，对了，我们该处理那个了。"

translate chinese chinese_6891374_1023:
    old "Hey Belle, how are you?"
    new "嘿，贝儿，你好吗？"

translate chinese chinese_2502902_1024:
    old "Actually, I'm doing great, you know? I have very good news!"
    new "其实，我挺好的，你知道吗？我有个非常好的消息！"

translate chinese chinese_5526893_1025:
    old "Remember what I told you before? What we needed to do for the next stream?"
    new "还记得我之前跟你说的吗？我们需要为下一次直播做什么？"

translate chinese chinese_9065910_1026:
    old "Uhh, yeah, I do."
    new "呃，是的，我有。"

translate chinese chinese_1057471_1027:
    old "Well, I got the girl we needed for the stream!"
    new "好吧，我搞到了我们需要的直播女孩！"

translate chinese chinese_1381401_1028:
    old "T- that's great."
    new "那、那真是太好了。"

translate chinese chinese_3066264_1029:
    old "Yeah, she's an amazing streamer."
    new "是啊，她是个超棒的主播。"

translate chinese chinese_3565261_1030:
    old "So, get ready because today we're going to do the stream!"
    new "所以，准备好今天我们要开直播了！"

translate chinese chinese_9329920_1031:
    old "A- alright, so, are we going to your house after class ends?"
    new "嗯……好吧，所以，下课后去你家吗？"

translate chinese chinese_0781536_1032:
    old "Uhh, actually, I will skip classes today."
    new "呃，实际上，我今天打算逃课。"

translate chinese chinese_1833740_1033:
    old "I have to go to the girl's house now to pick her up and take her to my house."
    new "我现在得去那个女孩家接她，然后带她到我家去。"

translate chinese chinese_8667541_1034:
    old "And then I'll set up the stream and make sure that everything's ready."
    new "然后我会设置直播，确保一切就绪。"

translate chinese chinese_1153224_1035:
    old "So, don't worry, you go to class and we'll meet at my house when you're done."
    new "所以，别担心，你去上课，下课后来我家找我。"

translate chinese chinese_1495002_1036:
    old "You'll see, with this, I will definitely surpass Lana in the rankings for good."
    new "你会看到的，有了这个，我一定能稳超兰娜的排名。"

translate chinese chinese_6433995_1037:
    old "Thanks, [pla]. Now, I'll leave, and we'll meet at my house in the afternoon."
    new "谢谢，[pla]。现在我先走了，下午去我家见面。"

translate chinese chinese_2116161_1038:
    old "Ok, I guess  I'll go to Belle's house now."
    new "好吧，我想我现在就去贝尔家吧。"

translate chinese chinese_7401949_1039:
    old "That's weird, I'm going to Belle's house to have a... Threesome, and with a girl I don't know..."
    new "真奇怪，我要去 Belle 家来个……三人行，而且还是和一个不认识的女生……"

translate chinese chinese_0525762_1040:
    old "This definitely escalated quickly..."
    new "这简直升级得太快了……"

translate chinese chinese_0178690_1041:
    old "Well, anyway, I better go quickly. I don't want to be late for Belle's stream.."
    new "好吧，我还是赶紧走吧。我不想迟到 Belle 的直播。"

translate chinese chinese_8190936_1042:
    old "Hi [pla], thanks for coming."
    new "你好 [pla]，感谢你能来。"

translate chinese chinese_1515803_1043:
    old "So, this is my friend Amorette, she will be joining us for today's stream."
    new "这是我的朋友阿莫蕾特，她今天会和我们一起直播。"

translate chinese chinese_6573775_1044:
    old "Oh... U- uhm... Hi!"
    new "哦... 嗯... 你好！"

translate chinese chinese_4458301_1045:
    old "Hi! Nice meeting you!"
    new "嗨！很高兴见到你！"

translate chinese chinese_6195412_1046:
    old "So this is the guy you've been streaming with lately, Belle!"
    new "原来这就是你最近直播时一起玩的家伙，贝勒！"

translate chinese chinese_0947190_1047:
    old "I can't believe I'm actually meeting you! You know, I'm a big fan of yours."
    new "真不敢相信我真的见到你了！你知道吗，我是你的大粉丝。"

translate chinese chinese_3466456_1048:
    old "My fan? Really?"
    new "我的扇子？真的吗？"

translate chinese chinese_9269861_1049:
    old "Of course I follow Belle's stream because she's one of the best-ranked streamers."
    new "我当然关注贝尔的直播了，她可是排名靠前的主播之一。"

translate chinese chinese_4923289_1050:
    old "And lately her content has been great, especially the one she's doing with you."
    new "最近她的内容很棒，特别是和你合作的那一期。"

translate chinese chinese_2628205_1051:
    old "So, I'm also a fan of yours."
    new "所以，我也是你的粉丝呢。"

translate chinese chinese_7989518_1052:
    old "But how couldn't I be? After all, you have that amazing cannon in between your legs."
    new "但我怎么可能不去在意呢？毕竟你腿间有那么棒的炮筒。"

translate chinese chinese_5459633_1053:
    old "With how long and thick it is... I know my views would skyrocket if I ever have you in one of my streams."
    new "以它的长度和厚度……我知道如果我在直播中让你出现，我的观看人数会暴涨的。"

translate chinese chinese_6683077_1054:
    old "I- Uh- Well... I- I don't know what to say..."
    new "我- 嗯- 嗯……我不知道该说什么……"

translate chinese chinese_7218736_1055:
    old "Oh! Look at that reaction! It's so cute, hahaha."
    new "哦！看那反应！好可爱啊，哈哈。"

translate chinese chinese_7034646_1056:
    old "Ok guys, everything's already set up, so we're ready to go."
    new "好了，大家，一切都已经准备好了，我们可以开始了。"

translate chinese chinese_6671409_1057:
    old "At first I'll be alone on camera, I'll introduce you and then you can come in Amorette."
    new "一开始我会独自面对镜头，然后介绍你，到时候你再进来吧，阿莫瑞特。"

translate chinese chinese_6615184_1058:
    old "After that I'll bring you in [pla], and we can get started."
    new "之后我就带你去[pla]，我们可以开始了。"

translate chinese chinese_3270154_1059:
    old "Great, then let's do it."
    new "好，那我们就干吧。"

translate chinese chinese_5655109_1060:
    old "Hey guys! It's great to see you all again!"
    new "大家好！很高兴又见到你们！"

translate chinese chinese_3525699_1061:
    old "I've been waiting for today's show more than ever!"
    new "我今天等这场节目等得好辛苦！"

translate chinese chinese_0904608_1062:
    old "Because I have yet another great surprise for you guys!"
    new "因为我还有一个大惊喜给你们！"

translate chinese chinese_2853901_1063:
    old "This is something you have been asking me about! And it's finally time for you guys to enjoy it."
    new "这是你们一直想问我的东西！现在终于可以给你们享受了。"

translate chinese chinese_8812700_1064:
    old "So, today I have with me a friend that's going to help us."
    new "所以，今天我带来了一个朋友帮忙。"

translate chinese chinese_4706876_1065:
    old "I know you all know her because she's very popular, so please give a warm welcome to my friend Amorette!"
    new "我知道你们都认识她，因为她很受欢迎，所以请热烈欢迎我的朋友阿莫瑞特！"

translate chinese chinese_8268379_1066:
    old "Hi guys! How are you?!"
    new "大家好！你们怎么样？！"

translate chinese chinese_0465293_1067:
    old "It's so nice to be here!"
    new "能来这里真好！"

translate chinese chinese_1526706_1068:
    old "Oh, some of you know me from my stream?"
    new "哦，你们有些人是从我的直播认识我的？"

translate chinese chinese_5581964_1069:
    old "It's great to see you!"
    new "见到你真好！"

translate chinese chinese_9993348_1070:
    old "I hope we'll have a very good time together today guys!"
    new "希望今天我们能玩得很开心！"

translate chinese chinese_3423434_1071:
    old "And of course, my friend from before is also here to help us!"
    new "当然了，我之前的那位朋友也来帮忙了！"

translate chinese chinese_9937059_1072:
    old "Well guys, it's time for me to tell you about the surprise I'd planned for you."
    new "好吧， guys，现在是我告诉你们我为你们准备的惊喜的时候了。"

translate chinese chinese_8278435_1073:
    old "And it's that today we're having a threesome!"
    new "而且今天我们要来个三人行！"

translate chinese chinese_7015054_1074:
    old "It's great right?"
    new "很棒吧？"

translate chinese chinese_5816078_1075:
    old "Yey!"
    new "耶！"

translate chinese chinese_5940097_1076:
    old "Oh! We've all been waiting for this! Let's not delay it anymore!"
    new "哦！我们都等这一刻了！不要再拖延了！"

translate chinese chinese_0171576_1077:
    old "So, remember to tip so that we can reach the goal!"
    new "所以记得打赏，好让我们能达到目标！"

translate chinese chinese_4788929_1078:
    old "Oh wow, just look at that dick guys!"
    new "哦 wow，看看那家伙的丁丁！"

translate chinese chinese_1069172_1079:
    old "I saw it before on screen, but it's so much bigger in person!"
    new "我之前在屏幕上见过，但真人看起来大多了！"

translate chinese chinese_8163650_1080:
    old "It's great isn't it?"
    new "很棒是不是？"

translate chinese chinese_7384054_1081:
    old "Thanks guys, you are the best fans in the world!"
    new "谢谢大家，你们是世界上最好的粉丝！"

translate chinese chinese_8124684_1082:
    old "I'm very happy and proud of you!"
    new "我非常为你高兴和自豪！"

translate chinese chinese_5624582_1083:
    old "I hope you enjoyed this threesome as much as we did."
    new "希望你和我们一样享受这个三人行。"

translate chinese chinese_2978852_1084:
    old "Belle is right guys!"
    new "贝尔说得对！大家听着！"

translate chinese chinese_0195777_1085:
    old "That was so hot!"
    new "真是太辣了！"

translate chinese chinese_4664264_1086:
    old "You guys have been so nice!"
    new "你们真是太好了！"

translate chinese chinese_8780375_1087:
    old "It makes me think of coming back to stream with Belle again..."
    new "这让我想到再次和贝尔一起直播回来..."

translate chinese chinese_8686470_1088:
    old "I know if Amorette comes back to stream with us, we will all enjoy it!"
    new "我知道如果阿莫rette回来和我们一起直播，大家都会很开心的！"

translate chinese chinese_1117426_1089:
    old "And of course, my friend here will be back as well!"
    new "当然了，我这位朋友也会回来的！"

translate chinese chinese_6044202_1090:
    old "Well, guys, that's all for today."
    new "好吧， guys，今天就到这里了。"

translate chinese chinese_8937916_1091:
    old "Remember to subscribe to my profile and follow me on my social networks!"
    new "记得关注我的个人资料，在社交网络上关注我！"

translate chinese chinese_6989759_1092:
    old "And remember to follow Amorette as well."
    new "别忘了也关注Amorette。"

translate chinese chinese_5257738_1093:
    old "She does some amazing things in her stream guys!"
    new "她在直播里做了很多惊人的事情！"

translate chinese chinese_3843437_1094:
    old "Thanks for the warm reception guys!"
    new "谢谢大家的热烈欢迎！"

translate chinese chinese_8880550_1095:
    old "And thank you for having me Belle."
    new "谢谢你邀请我，贝尔。"

translate chinese chinese_0558949_1096:
    old "See you later guys!"
    new "一会儿见！"

translate chinese chinese_5496859_1097:
    old "Bye guys!"
    new "拜拜了！"

translate chinese chinese_0221096_1098:
    old "They really reached the goal in no time!"
    new "他们真的很快就达到目标了！"

translate chinese chinese_9052877_1099:
    old "Thanks a lot guys! I'm amazed it all went this well. And it's all thanks to you!"
    new "谢谢大家！真没想到一切这么顺利。这全都是你们的功劳！"

translate chinese chinese_7243415_1100:
    old "You're welcome Belle."
    new "不客气，贝尔。"

translate chinese chinese_8843797_1101:
    old "I'm very happy to help, and this is also good for my own stream."
    new "我很乐意帮忙，这对我自己的直播也有好处。"

translate chinese chinese_8649539_1102:
    old "It's great that you managed to reach the goal."
    new "你能达到目标真是太好了。"

translate chinese chinese_8051086_1103:
    old "And I love that I was able to meet you [pla]."
    new "而我能够遇到你[pla]，这让我感到很开心。"

translate chinese chinese_7663995_1104:
    old "You definitely have to come to do one of my streams with me one of these days."
    new "你一定要来参加我的一次直播。"

translate chinese chinese_5670607_1105:
    old "Just you and me, I'm sure you'll enjoy it."
    new "就我们俩，我相信你会喜欢的。"

translate chinese chinese_0591495_1106:
    old "Uhh... Sure."
    new "呃……好啊。"

translate chinese chinese_2478096_1107:
    old "Ok, that's great."
    new "好的，太棒了。"

translate chinese chinese_4003167_1108:
    old "Guys, my mom's coming home soon."
    new "guys, 我妈妈快回来了。"

translate chinese chinese_0364390_1109:
    old "So it would be better if you go."
    new "所以你去会比较好。"

translate chinese chinese_8598603_1110:
    old "Thanks again for having me Belle."
    new "谢谢你邀请我，贝勒。"

translate chinese chinese_1230785_1111:
    old "I'll see you later."
    new "待会儿见。"

translate chinese chinese_8057888_1112:
    old "Sure, thanks for helping me."
    new "好的，谢谢你的帮助。"

translate chinese chinese_4266447_1113:
    old "I guess I'll see you later then."
    new "那我猜一会儿见了。"

translate chinese chinese_2387407_1114:
    old "Of course, thank you, [pla]."
    new "当然，谢谢，[pla]。"

translate chinese chinese_2039170_1115:
    old "I'm sure that with this, I can surpass Lana in the voting."
    new "我相信有了这个，我在投票中一定能超过Lana。"

translate chinese chinese_5504994_1116:
    old "And it's all because of you."
    new "而这都是因为你。"

translate chinese chinese_9801287_1117:
    old "Don't mention it, I know you've worked hard for it, so you deserve to win it."
    new "别提了，我知道你为此努力了，所以你值得赢得它。"

translate chinese chinese_3815388_1118:
    old "And I'm sure you will."
    new "我敢肯定你会的。"

translate chinese chinese_2673697_1119:
    old "Thank you so much, [pla]!"
    new "真是太感谢你了，[pla]！"

translate chinese chinese_0092663_1120:
    old "Alright, I'll get going then. See you later."
    new "好吧，那我先走了，回头见。"

translate chinese chinese_6369938_1121:
    old "Ok! I think I managed to finish it all."
    new "好啦！我觉得我差不多都搞定了。"

translate chinese chinese_6129844_1122:
    old "That's great [pla]!"
    new "太好了，[pla]！"

translate chinese chinese_5623414_1123:
    old "Can you show me?"
    new "你能给我演示一下吗？"

translate chinese chinese_6007008_1124:
    old "Here, this is the homepage, in here I just left information about the business."
    new "这里，这是首页，我在这里只留下了关于生意的信息。"

translate chinese chinese_1683869_1125:
    old "Their history and stuff."
    new "他们的历史之类的。"

translate chinese chinese_4476678_1126:
    old "If you press here it will take you to the menu."
    new "如果你在这里按一下就会回到菜单。"

translate chinese chinese_0296598_1127:
    old "If you wish to make an order to pick up in advance, you can place it here."
    new "如果你想提前下单自取，可以在这里下单。"

translate chinese chinese_4124649_1128:
    old "There's also an option for you to customize your order."
    new "你也可以自定义你的订单。"

translate chinese chinese_4084003_1129:
    old "Oh! I see!"
    new "哦！我明白了！"

translate chinese chinese_4661459_1130:
    old "Yeah, you can even select the coffee by level of roasting."
    new "是的，你甚至可以选择不同烘焙程度的咖啡。"

translate chinese chinese_3390467_1131:
    old "Or you can even select the region where it comes from."
    new "或者你可以选择它来源的区域。"

translate chinese chinese_9981309_1132:
    old "This is really good work [pla]."
    new "这真是很好的工作，[pla]。"

translate chinese chinese_3535125_1133:
    old "This is better than what I have seen some professional web developers do."
    new "这比我看过的有些专业网页开发者的作品还要好。"

translate chinese chinese_6776547_1134:
    old "I know you're not looking for a job right now."
    new "我知道你现在不想找工作。"

translate chinese chinese_9581854_1135:
    old "Because you have to do things with school and stuff."
    new "因为你得处理学校那些事情。"

translate chinese chinese_0800328_1136:
    old "But if you ever want to get into web developing, just let me know."
    new "但如果你以后想做网页开发，告诉我一声就行了。"

translate chinese chinese_8143700_1137:
    old "I'm sure I'll be able to get you something good."
    new "我相信我一定能给你找件好东西。"

translate chinese chinese_9197455_1138:
    old "Also, if I ever need your help, I'll let you know."
    new "还有，如果我需要你的帮助，我会告诉你。"

translate chinese chinese_7526381_1139:
    old "Maybe you can give me a hand with something."
    new "maybe 你可以帮我个忙。"

translate chinese chinese_8293769_1140:
    old "For sure! If I can help you with anything, just tell me, I'll do my best to help you any time I can."
    new "当然了！如果你需要任何帮助，尽管告诉我，我随时都会尽力帮忙。"

translate chinese chinese_0920467_1141:
    old "I guess I'll leave for now Ashley. But I guess I'll see you later."
    new "那我先走了Ashley。不过应该还会见到你的。"

translate chinese chinese_1213285_1142:
    old "Wait [pla]."
    new "等一下[pla]。"

translate chinese chinese_5796633_1143:
    old "Yes ma'am?"
    new "是的，小姐？"

translate chinese chinese_5019324_1144:
    old "Before you leave, I just wanted to take a second to thank you for all the help you've given me these days."
    new "在你走之前，我想花点时间感谢你这些天给我的所有帮助。"

translate chinese chinese_4883901_1145:
    old "I was in a very difficult situation, and with your help, I was able to solve it even better than I expected."
    new "我当时处于一个非常困难的境地，多亏了你的帮助，问题解决得比我预期的还要好。"

translate chinese chinese_4857284_1146:
    old "I just wanted to help you, I'm happy I was able to do something."
    new "我只是想帮你，能做点什么我挺开心的。"

translate chinese chinese_9787411_1147:
    old "And you really did, you're welcome here at our home any time you need."
    new "而且你真的来了，你随时都可以来我们家。"

translate chinese chinese_7045880_1148:
    old "So thanks again [pla], I hope I'll see you again soon."
    new "所以再次感谢[pla]，希望很快能再见到你。"

translate chinese chinese_3580494_1149:
    old "Sure ma'am, I'm sure we'll see each other soon."
    new "好的，女士，我相信我们很快就会见面的。"

translate chinese chinese_3791532_1150:
    old "Bye for now then."
    new "那先再见了。"

translate chinese chinese_8527408_1151:
    old "Bye [pla]."
    new "再见 [pla]。"

translate chinese chinese_4452157_1152:
    old "Why do you look so down?"
    new "你为什么看起来这么沮丧？"

translate chinese chinese_5790342_1153:
    old "Nothing bad, I'm just a little nervous."
    new "没什么不好的，我就是有点紧张。"

translate chinese chinese_0215454_1154:
    old "Well, the results of the voting are coming out today."
    new "嗯，投票结果今天就要公布了。"

translate chinese chinese_2411554_1155:
    old "Already? It didn't take any time."
    new "已经了？根本没花时间。"

translate chinese chinese_1324991_1156:
    old "The contest was a bit longer. It's just that when we started streaming, we were already close to the deadline."
    new "比赛持续的时间有点长。只是当我们开始直播时，已经接近截止日期了。"

translate chinese chinese_8419985_1157:
    old "Well, I hope that all the streaming we did helped you win."
    new "好吧，希望我们做的所有直播都能帮到你。"

translate chinese chinese_8597570_1158:
    old "I don't know, I checked the voting before I went out today. Me and Lana were neck and neck."
    new "我不知道，我今天出去前查过投票情况了。我和Lana势均力敌。"

translate chinese chinese_6806526_1159:
    old "I haven't seen anything else, I'll check it as soon as I get home."
    new "我没看到别的，我一回家就检查。"

translate chinese chinese_8958176_1160:
    old "So, I wanted to know if you want to accompany me this afternoon to check the results."
    new "所以，我想知道你是否愿意今天下午陪我去查看结果。"

translate chinese chinese_1675970_1161:
    old "Sure, I'll come with you."
    new "行，我跟你一起去。"

translate chinese chinese_2570351_1162:
    old "Thank you [pla]. We can go to my house right after classes and check it."
    new "谢谢你[pla]。下课后我们可以直接去我家看看。"

translate chinese chinese_1690647_1163:
    old "For sure, let's go to class for now, and I'll come to your house with you when we're done."
    new "行，先去上课，下课后再一起去你家。"

translate chinese chinese_3792311_1164:
    old "I can't wait to see the results, but I'm also so nervous!"
    new "我好期待看到结果，但同时也紧张死了！"

translate chinese chinese_9548067_1165:
    old "Don't worry, everything will be fine. Let's get going so we can see the results at your place."
    new "别担心，一切都会好的。我们赶紧去你那儿看结果吧。"

translate chinese chinese_1259517_1166:
    old "Yes, yes, you're right... Let's go. I'll feel calmer there."
    new "嗯，嗯，你说得对……走吧。我在那里会感觉平静些。"

translate chinese chinese_7942591_1167:
    old "Ok, let's check how this all turned out."
    new "好吧，让我们看看这一切的结果吧。"

translate chinese chinese_5568650_1168:
    old "You did?!"
    new "你做了？！"

translate chinese chinese_2218593_1169:
    old "That's great Belle! Congrats!"
    new "太好了，贝尔！恭喜！"

translate chinese chinese_4530363_1170:
    old "Thank you so much [pla]!"
    new "真是太感谢你了，[pla]！"

translate chinese chinese_8474592_1171:
    old "This is all thanks to you!"
    new "这全都是你的功劳！"

translate chinese chinese_8200682_1172:
    old "What?! This is all because of you! You're the one that has been doing all the hard work."
    new "什么?! 这都是因为你！你才是那个一直在努力的人。"

translate chinese chinese_9480758_1173:
    old "Really Belle, congrats, you deserve this."
    new "真的，贝尔，恭喜你，你 deserves this. \n\n（注：这里\"deserves this\"未翻译是因为保持了原文中的英文名字和表达习惯，但通常会翻译为“你应得的”。）"

translate chinese chinese_7288140_1174:
    old "Well, it was impossible without you."
    new "好吧，没有你这是不可能的。"

translate chinese chinese_3017868_1175:
    old "I have no way of repaying you [pla], this is just so great."
    new "我根本无法报答你[pla]，这真是太好了。"

translate chinese chinese_3963166_1176:
    old "Really Belle, congratulations, you deserve that victory. And I'm happy I was able to help you. It makes me very happy."
    new "真的，贝尔，恭喜你，你 deserves 这场胜利。我很高兴能帮到你。这让我很开心。"

translate chinese chinese_1883079_1177:
    old "What do you mean by 'what's going on here?' And why are you barging into my room as if it's yours?"
    new "你说的“这里发生了什么”是什么意思？而且你为什么闯进我的房间，好像这是你的房间一样？"

translate chinese chinese_7643167_1178:
    old "What the hell is happening?!"
    new "到底发生了什么！"

translate chinese chinese_6845013_1179:
    old "Woah, woah, woah, where did you get that from?!"
    new "喂喂喂，这个是从哪儿听来的？！"

translate chinese chinese_2694358_1180:
    old "A coworker showed it to me! He caught his son using his credit card to send money to you on this website."
    new "一个同事给我看的！他抓到他儿子用他的信用卡在这个网站上给你转账。"

translate chinese chinese_7891639_1181:
    old "He recognized you and decided to ask me if this was you!"
    new "他认出你了，然后决定问我这是不是你！"

translate chinese chinese_0714192_1182:
    old "Oh my gosh Belle! What the hell are you doing?"
    new "天啊，贝尔！你在干什么？"

translate chinese chinese_7006959_1183:
    old "Why are you asking for money from strangers on the internet?"
    new "为什么你要在网上向陌生人要钱？"

translate chinese chinese_5287336_1184:
    old "If you needed money you could've told me!"
    new "如果你需要钱的话可以直接告诉我啊！"

translate chinese chinese_4273116_1185:
    old "And doing it this way! Oh my god!"
    new "而且是这么做的！天啊！"

translate chinese chinese_7631186_1186:
    old "Wait a minute, what do you mean by {i}'doing it this way{/i}'?"
    new "等一下，你说的“这样搞”是什么意思？"

translate chinese chinese_7594891_1187:
    old "First of all, I'll let you know I'm not doing it for the money!"
    new "首先，我要让你知道我可不是为了钱才做的！"

translate chinese chinese_3117562_1188:
    old "I'm doing it because I like it."
    new "我是因为喜欢才做的。"

translate chinese chinese_5488360_1189:
    old "But even if I was doing it for money. What's wrong with me doing something like that?"
    new "但是就算我是为了钱做的。我做这种事有什么不对吗？"

translate chinese chinese_6133036_1190:
    old "You're the one who's always telling me that I should just live my sexuality any way I can."
    new "你总是告诉我应该随心所欲地活出自己的性取向。"

translate chinese chinese_3060411_1191:
    old "And that I shouldn't care about what people have to say about me."
    new "而且我不应该在乎别人怎么说我。"

translate chinese chinese_6212483_1192:
    old "That isn't the problem here!"
    new "那不是这里的问题！"

translate chinese chinese_9127660_1193:
    old "You know that I'm just taking over my new role in the company!"
    new "你知道我这只是在公司里接手新职务而已！"

translate chinese chinese_3171251_1194:
    old "Imagine how I felt when my coworker told me his son is stealing money from him to give to my daughter for being naked online!"
    new "想象一下当我同事告诉我，他儿子偷他的钱给我女儿，就因为她在网上的裸照，我是什么感受！"

translate chinese chinese_7575360_1195:
    old "This could bring problems to my image as the branch director of the company. The executives could fire me!"
    new "这可能会给我作为分公司总监的形象带来问题。高管们可能会解雇我！"

translate chinese chinese_6565809_1196:
    old "And what do you want me to do? To not do it just because those assholes at your job might think bad about it?"
    new "那你想要我怎么做？就因为你们公司那些王八蛋可能会说三道四就不做了？"

translate chinese chinese_2076956_1197:
    old "I'm sorry but I'm not doing that."
    new "对不起，我不能那样做。"

translate chinese chinese_9399607_1198:
    old "Oh my gosh could you be any more selfish?!"
    new "天啊，你还能再自私一点吗？!"

translate chinese chinese_5305305_1199:
    old "Ok, ok, why don't you two try to talk about this in a calmer way?"
    new "好啦好啦，你们俩为什么不冷静点谈谈这个问题？"

translate chinese chinese_2181934_1200:
    old "Before either of you says anything that you may regret."
    new "在你们俩说出可能会后悔的话之前。"

translate chinese chinese_0731476_1201:
    old "I was thinking about who's the person in the video with Belle! It's you isn't it?"
    new "我在想视频里和贝尔在一起的人是谁，难道是你？"

translate chinese chinese_8303380_1202:
    old "I'm so stupid!"
    new "我真是个白痴！"

translate chinese chinese_5105802_1203:
    old "Here I was thinking that you were just a good friend of Belle!"
    new "我还以为你只是贝尔的好朋友呢！"

translate chinese chinese_7278634_1204:
    old "Someone whom I could trust, and here doing this!"
    new "一个我可以信任的人，竟然在这里做这种事！"

translate chinese chinese_2790493_1205:
    old "And in my house, of all places!"
    new "而且还是在我家！"

translate chinese chinese_4888480_1206:
    old "Wait a minute! Don't involve him in this!"
    new "等一下！别把他牵扯进来！"

translate chinese chinese_7229506_1207:
    old "He was just helping me, and it's something that I wanted to do and there's nothing wrong with it!"
    new "他只是在帮我，而且这是我想要做的，没什么不对劲的！"

translate chinese chinese_8234623_1208:
    old "Oh yeah? Well, I'm sorry you want to do it so badly because you're about to stop!"
    new "哦是吗？那真抱歉，你这么想做的，因为现在就要停了！"

translate chinese chinese_1425689_1209:
    old "I already told you, the people at my company are not okay with this!"
    new "我 already 告诉你了，我公司的人不答应这个！"

translate chinese chinese_0827919_1210:
    old "So, unless whatever money you're making with that is enough for you to pay for everything around here!"
    new "所以，除非你靠那个赚的钱足够支付这里的一切！"

translate chinese chinese_1497763_1211:
    old "You're about to stop with this weird little hobby of yours!"
    new "你该放弃这个奇怪的小嗜好了！"

translate chinese chinese_9787084_1212:
    old "You have to be kidding me!"
    new "你开玩笑吧！"

translate chinese chinese_7185810_1213:
    old "Well I'm sorry, but I'm not going to stop doing anything! And if you don't like me doing it in your house then I guess I can leave!"
    new "好吧，但我不会停下来不做任何事的！如果你不喜欢我在你家做这些，那我猜我可以离开！"

translate chinese chinese_2621919_1214:
    old "Then I guess you can!"
    new "那我猜你可以！"

translate chinese chinese_6086444_1215:
    old "I'll do it then!"
    new "那我来吧！"

translate chinese chinese_5320445_1216:
    old "Wait! Belle!"
    new "等一下！贝勒！"

translate chinese chinese_7382020_1217:
    old "I- uh..."
    new "我—呃……"

translate chinese chinese_5818486_1218:
    old "I- I'm sorry!"
    new "我……对不起！"

translate chinese chinese_0135217_1219:
    old "Hey, I guess I'm doing ok."
    new "嘿，我觉得我还不错。"

translate chinese chinese_4706495_1220:
    old "I left my mom's house, so at least she's not annoying me or anything."
    new "我离开了妈妈的房子，至少她不会再烦我了。"

translate chinese chinese_5778369_1221:
    old "W- what? You actually left your home?"
    new "什、什么？你真的离开家了？"

translate chinese chinese_1034528_1222:
    old "I did, what else was I supposed to do?"
    new "我那样做了，我还 supposed to do 什么 else？ \n\n注：这里保留了 \"supposed to do\" 和 \"what else\" 的英文，因为根据规则需要保留非中文的内容。不过通常情况下，我们会将其翻译为“我那样做了，我还 supposed to do 什么 else？”更自然的表达是“我那样做了，我还能做什么呢？”但为了遵守规则，我保留了英文部分。"

translate chinese chinese_7566103_1223:
    old "I'm not going to stop streaming just to give her the pleasure."
    new "我可不会为了让她高兴就停播。"

translate chinese chinese_7602669_1224:
    old "This is too important for me, no matter what she says."
    new "这对我来说太重要了，不管她说什么。"

translate chinese chinese_5154802_1225:
    old "I see, I'm sorry Belle; I feel like I caused this."
    new "我明白了，贝尔，对不起，我觉得这是我的错。"

translate chinese chinese_7625545_1226:
    old "Don't worry, this isn't your fault. It was bound to happen sooner or later."
    new "别担心，这不怪你。早晚都会发生的。"

translate chinese chinese_2667262_1227:
    old "I guess."
    new "我猜是吧。"

translate chinese chinese_1232827_1228:
    old "So, where are you staying now?"
    new "那么，你现在住在哪里？"

translate chinese chinese_6498015_1229:
    old "I'm staying at Amorette's apartment."
    new "我住在阿莫rette的公寓里。"

translate chinese chinese_6003637_1230:
    old "It's really nice because she has an entire room where we can stream."
    new "真的很方便，因为她有一个专门的房间可以用来直播。"

translate chinese chinese_6748573_1231:
    old "By the way, she says that you're welcome to come to visit anytime you want."
    new "对了，她说你随时都可以来拜访。"

translate chinese chinese_2480828_1232:
    old "I see... Well, thank you I guess."
    new "我明白了……嗯，谢谢吧。"

translate chinese chinese_6615279_1233:
    old "Leaving aside her offer."
    new "先不提她的提议。"

translate chinese chinese_0439204_1234:
    old "I hope things will be fixed between you and your mom soon."
    new "希望你和你妈妈之间的关系能很快好转。"

translate chinese chinese_0052814_1235:
    old "Thanks... But I wouldn't count on it."
    new "谢谢……但别抱太大希望。"

translate chinese chinese_6613415_1236:
    old "Listen, I have a couple of things to do now, so I'll see you later, ok?"
    new "听着，我现在有点事要忙，待会儿见，好吗？"

translate chinese chinese_4263410_1237:
    old "Yeah, see you."
    new "嗯，再见。"

translate chinese chinese_2788985_1238:
    old "Damn, things between them really went out of whack."
    new "真他娘的，他们之间的事真的变糟了。"

translate chinese chinese_8779542_1239:
    old "Maybe I could do something to help them."
    new "也许我能做些什么来帮他们。"

# auto-tl Qwen Colab

translate chinese chinese_3170751_0:
    old "(God! I hope everybody is sleeping already... I gotta whisper to her...)"
    new "（天啊！希望大家都已经睡了……我得小声点跟她说话……）"

translate chinese chinese_3304024_1:
    old "{i}Psst psst psst, Hey... I'm [pla], I know you are in trouble... I can help you! Where are you?{/i}"
    new "{i}嘘嘘嘘，喂……我是[pla]，我知道你有麻烦了……我可以帮你！你在哪儿？{/i}"

translate chinese chinese_8091459_2:
    old "{i}You can trust me... Just let me see you, I came here to help you.{/i}"
    new "你可以信任我…… just让我看看你，我是来帮助你的。"

translate chinese chinese_5521958_3:
    old "Hello! Who's there?"
    new "喂！谁在那里？"

translate chinese chinese_8621878_4:
    old "If you come to steal, you are in the wrong place... Don't you see this is God's house?!"
    new "如果你来偷东西，那你来错地方了……难道你看不出来这是上帝的家吗？！"

translate chinese chinese_9312984_5:
    old "(Holy shit! The nun heard me... I need to hide.)"
    new "（卧槽！修女听到我的声音了……我得躲起来。）"

translate chinese chinese_6885662_6:
    old "(But... I don't see anybody... God! Maybe it is Father Morgan...)"
    new "（但是……我什么人都没看到……天啊！ maybe it is Father Morgan...）"

translate chinese chinese_9493064_7:
    old "Father Morgan? It is you? I'm sorry, I thought it was somebody else, a thief... I didn't know you would have been here so late."
    new "莫甘神父？是你吗？对不起，我以为是别人，是个贼……我不知道你会这么晚还在。"

translate chinese chinese_3695211_8:
    old "(Holy fuck!! She also entered the confessional.)"
    new "（卧槽！！她也进忏悔室了。）"

translate chinese chinese_5606066_9:
    old "Father? Are you upset? I'm sorry if I disturbed you with my shouting."
    new "爸爸？你在生气吗？如果我刚才喊叫打扰到你了，我很抱歉。"

translate chinese chinese_6633539_10:
    old "I see what you're thinking... I have done wrong again and I must clean up that offense I have committed, that's why you're so quiet."
    new "我明白你在想什么……我又做错了事，必须改正我犯下的错误，这就是你为什么这么安静的原因。"

translate chinese chinese_5648077_11:
    old "No father Morgan... You don't have to say a word."
    new "没有父亲摩根……你不需要说一个字。"

translate chinese chinese_4111098_12:
    old "You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "你知道我完全遵从主的旨意，我会让你再次引导我，净化我的身体，摆脱那些不良想法。"

translate chinese chinese_6235475_13:
    old "Thoughts that I had a few minutes ago."
    new "几分钟前的想法。"

translate chinese chinese_9841550_14:
    old "(What? What's she talking about?!)"
    new "（什么？她在说什么？）"

translate chinese chinese_7422106_15:
    old "(What's happening with her-)"
    new "（她怎么了—）"

translate chinese chinese_1931688_16:
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I'm giving you my spirit through my body, Father."
    new "信仰上帝就是无所畏惧，你是我的指引，帮我净化这个罪恶的灵魂吧。我把我的灵魂通过身体交给你，父亲。"

translate chinese chinese_8226671_17:
    old "(I- is she talking about... s- sex?)"
    new "（她是在说……性吗？）"

translate chinese chinese_3235599_18:
    old "I'm ready to receive your sacred water, your purifying milk... It's my mission to reach divinity through you, let me try it one more time."
    new "我准备好接受你的圣水，你的净化之乳……我的使命是通过你达到神明之境，让我再试一次吧。"

translate chinese chinese_0946280_19:
    old "(Oh shit!... This is so wrong...)"
    new "（哦shit！……这太不对劲了……）"

translate chinese chinese_5913846_20:
    old "I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Tell me something or show me your help, please!"
    new "我在求你帮我，我差点就堕入黑暗了，是你给我带来了光明……摩根神父？告诉我些什么或者展示你的帮助吧，求你了！"

translate chinese chinese_4890849_21:
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, Father."
    new "我希望我们的神能快乐，没有什么比这更美好了，我会通过你让神快乐的，父亲。"

translate chinese chinese_1874409_22:
    old "(My God! Alright, I gotta do this. If I don't, she'll suspect and see that I'm not the Father Morgan.)"
    new "（天啊！好吧，我得这么做。如果不做，她会起疑，发现我不是摩根父亲。）"

translate chinese chinese_1839053_23:
    old "My great Father Morgan, I don't have words to express how grateful I'm. One more time, you've shown me how big and great you're, I feel your grace."
    new "伟大的父亲摩根，我无法用言语表达我的感激之情。又一次，你展现了你的伟大与宽广，我感受到了你的恩典。"

translate chinese chinese_3675889_24:
    old "I will go to pray for you and for your great and powerful divine tool."
    new "我会为你和你的伟大而强大的神兵祈祷。"

translate chinese chinese_5800115_25:
    old "Good night Father Morgan, I'll be eager to see you again."
    new "晚安，摩根神父，期待下次再见到您。"

translate chinese chinese_0090407_26:
    old "(What a night!...)"
    new "（真是疯狂的一夜……)"

translate chinese chinese_4475560_27:
    old "(Argh! The shinigami... Shit! I couldn't find her! But I can't risk myself, perhaps the nun or the priest could come back...)"
    new "（啊呕！那个死神……见鬼！我没找到她！但是我自己不能冒险，也许那个修女或神父会回来……）"

translate chinese chinese_2872411_28:
    old "(I better come back another day...)"
    new "(我还是改天再来吧……)"

translate chinese chinese_8646969_29:
    old "(I hope the Sister Grace doesn't not appear tonight...)"
    new "（但愿今晚慈悲之姐不要出现……)"

translate chinese chinese_4390302_30:
    old "{i}Psst psst psst, Hey shinigami... I'm [pla], I know you are in trouble...{/i}"
    new "{i}嘘嘘嘘，喂，死神……我是[pla]，我知道你有麻烦了……{/i}"

translate chinese chinese_9377626_31:
    old "{i}You can trust me... I came here to help you, let me see where you are.{/i}"
    new "你可以信任我……我来这里是为了帮助你，让我看看你在哪儿。"

translate chinese chinese_0791285_32:
    old "Hello! F- Father Morgan?"
    new "喂！Morgan爸爸？"

translate chinese chinese_1150888_33:
    old "Is it you again?..."
    new "又是你啊？..."

translate chinese chinese_9710159_34:
    old "(Oh no! She's back... Damn it!)"
    new "（哦不！她回来了……该死！）"

translate chinese chinese_5367884_35:
    old "Father Morgan? I was eager to see you again..."
    new "莫甘神父？我很想再见到你..."

translate chinese chinese_0708436_36:
    old "Father? I'm sorry for bothering you again but I still need some help, my sins keep disturbing my soul."
    new "爸爸？很抱歉又打扰你，但我还是需要一些帮助，我的罪孽一直在困扰着我。"

translate chinese chinese_4362603_37:
    old "I need to continue with the penance."
    new "我需要继续我的忏悔。"

translate chinese chinese_8027806_38:
    old "No father Morgan... You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "没有父亲摩根……你知道我对主的旨意完全忠诚，我会让你再次引导我，净化我的身体，摆脱那些邪恶的想法。"

translate chinese chinese_1690017_39:
    old "Thoughts that I had today, again..."
    new "今天又有的想法……"

translate chinese chinese_4453138_40:
    old "(I guess I already know what she wants...)"
    new "（我想我已经知道她想要什么了……）"

translate chinese chinese_0709790_41:
    old "(But what's happening with her, why to do this?)"
    new "（但她这是怎么了，为什么要这么做？）"

translate chinese chinese_3345648_42:
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "信仰上帝就是无所畏惧，你是我的指引，帮我净化这个罪恶的灵魂吧。我将我的灵魂通过身体交给你，父亲。"

translate chinese chinese_9327509_43:
    old "(Well, I gotta do it... Otherwise she'll realized I'm not the Father Morgan)"
    new "（好吧，我得这么做……否则她会发现我不是摩根爸爸）"

translate chinese chinese_2794447_44:
    old "Yes, I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Show me your help, please!"
    new "是的，我在求你帮我，我差点陷入黑暗，是你让我看到了光明……莫甘神父？请展现你的帮助吧！"

translate chinese chinese_9086240_45:
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, my greatest Father."
    new "我希望我们的神能快乐，没有什么比这更美好了，我会通过你，我最伟大的父亲，让他快乐。"

translate chinese chinese_2302568_46:
    old "My soul is open to be purified, as opened as my mouth right now..."
    new "我的灵魂敞开了，准备被净化，就像我现在张开的嘴巴一样……"

translate chinese chinese_0794237_47:
    old "(Oh God!)"
    new "（天啊！）"

translate chinese chinese_6115292_48:
    old "My great Father Morgan, you have no idea how grateful I'm. One more time, you've shown me how big and great you're, I can taste your grace."
    new "伟大的父亲摩根，你不知道我有多感激。又一次，你展现了你的伟大，我能感受到你的恩典。"

translate chinese chinese_8381842_49:
    old "Good night Father Morgan, I'll be needing more of your sacred assistance to purify my existence in this world."
    new "晚安，莫甘神父，我还需要更多您的神圣帮助来净化我在世上的存在。"

translate chinese chinese_6190197_50:
    old "(Damn it! I couldn't find the shinigami tonight either... I better come back another day... This is to risky, the nun could come back...)"
    new "（该死！今晚也没找到死神……我得改天再来……这样太危险了，修女可能会回来……）"

translate chinese chinese_9176484_51:
    old "(God! This is my last chance to find the shinigami, I gotta find her tonight.)"
    new "（天啊！这是我最后找到死神的机会，今晚一定要找到她。）"

translate chinese chinese_4592347_52:
    old "{i}Psst psst psst, Hi... I'm [pla], a friend of shinigamis... I know you are in trouble, please show up!{/i}"
    new "{i}嘘嘘嘘，你好……我是[pla]，死神的朋友……我知道你有麻烦了，请现身吧！{/i}"

translate chinese chinese_8764645_53:
    old "Father Morgan... I'm so glad you're here."
    new "莫甘神父……真高兴你在这里。"

translate chinese chinese_3409853_54:
    old "(Argh! No... No again!!!)"
    new "（啊！不要……又不要！！！）"

translate chinese chinese_1875014_55:
    old "I was waiting for you, my holy savior."
    new "我一直在等你，我的救星。"

translate chinese chinese_2234810_56:
    old "Father Morgan? How should we start tonight? Just tell me..."
    new "莫甘神父？今晚我们该怎么开始呢？直接告诉我吧..."

translate chinese chinese_2134428_57:
    old "(Holy fuck!! She'll catch me this time...)"
    new "（卧槽！！这次她要抓到我了...）"

translate chinese chinese_4843928_58:
    old "Father? I already know you don't like to talk much when you're praying and well... I know what my soul needs this time. "
    new "爸爸？我已经知道你在祈祷时不喜欢多说话，而且……我知道这次我的灵魂需要什么。"

translate chinese chinese_1474832_59:
    old "Thoughts that I have had since long time ago."
    new "很久以前就在心里的想法。"

translate chinese chinese_1902208_60:
    old "Having faith in your God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "相信你的上帝就意味着无所畏惧，你是我的指引，帮助我净化这个罪恶的灵魂。我把我的灵魂通过身体交给你，父亲。"

translate chinese chinese_4673005_61:
    old "(Shit!... I gotta do it again.)"
    new "（糟了！……我得再试一次。）"

translate chinese chinese_0743634_62:
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're, I feel your grace inside."
    new "伟大的父亲摩根，我无法用言语表达我的感激之情。你让我看到了你的伟大，我感受到了你的恩典。"

translate chinese chinese_0753379_63:
    old "Good night Father Morgan, I can't wait to feel you inside of me again."
    new "晚安，摩根神父，我好想再感受你的存在。"

translate chinese chinese_7998315_64:
    old "(Damn it! This is becoming more and more complicated.)"
    new "（真该死！这变得越来越复杂了。）"

translate chinese chinese_6201592_65:
    old "Hmm looks like no one is around."
    new "嗯，看来周围没人。"

translate chinese chinese_5485116_66:
    old "Maybe the nun will come later... I better go to wait at the confessional."
    new "也许修女一会儿会来……我还是去忏悔室等吧。"

translate chinese chinese_6547414_67:
    old "Father Morgan? You're already here, right?"
    new "莫甘神父？你已经在这里了，对吧？"

translate chinese chinese_6472810_68:
    old "Thank God! So, how should we start tonight Father? Just tell me..."
    new "谢天谢地！那么，今晚我们该怎么开始呢，爸爸？你就告诉我吧……"

translate chinese chinese_3304930_69:
    old "No,  you know what? It is better to trust in divine providence and may the Lord be the one to guide the forgiveness of my sins tonight."
    new "不，你知道吗？还是相信天意吧，让主今晚引导我的罪过得到宽恕。"

translate chinese chinese_8927530_70:
    old "Sex"
    new "性爱"

translate chinese chinese_2662775_71:
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're."
    new "伟大的父亲摩根，我无法用言语表达我的感激之情。你让我看到了你的伟大和宽广。"

translate chinese chinese_4934556_72:
    old "(It's too late, I better go to sleep...)"
    new "（太晚了，我还是去睡觉吧……）"

translate chinese chinese_2409361_73:
    old "Hi sister Grace, I'm fine and you?"
    new "嗨，格蕾丝姐姐，我挺好的，你呢？"

translate chinese chinese_2009923_74:
    old "I'm blessed thank God... Tell me, how can I help you?"
    new "感谢上帝，我真幸运……告诉我，我怎么帮你？"

translate chinese chinese_3119829_75:
    old "[pla], are you ok?"
    new "[pla]，你还好吗？"

translate chinese chinese_6657845_76:
    old "Oh don't worry, I'm just checking if everything is okay."
    new "哦，别担心，我只是确认一下一切是否正常。"

translate chinese chinese_1361670_77:
    old "Oh right, thank you so much for all your help."
    new "哦，对了，非常感谢你的帮助。"

translate chinese chinese_6035352_78:
    old "You are welcome, see you later."
    new "不客气，回头见。"

translate chinese chinese_3143932_79:
    old "God be with you."
    new "祝你好运。"

# auto-tl Qwen Colab

translate chinese chinese_3190172_0:
    old "Go to Sleep."
    new "去睡觉。"

translate chinese chinese_6576958_1:
    old "Go to sleep."
    new "去睡觉吧。"

translate chinese chinese_3908707_2:
    old "Go to school in the morning."
    new "早上上学。"

translate chinese chinese_7259951_3:
    old "Keep progressing with Brixxida."
    new "继续和Brixxida进展。"

translate chinese chinese_2451233_4:
    old "Keep progressing with other characters."
    new "继续和其他角色发展。"

translate chinese chinese_2432798_5:
    old "step mom"
    new "继母"

translate chinese chinese_5386561_6:
    old "Meet her in the hallway."
    new "在走廊里见她。"

translate chinese chinese_3274053_7:
    old "Keep progressing with Hinn."
    new "继续和Hinn发展吧。"

translate chinese chinese_9833987_8:
    old "Go to her house."
    new "去她家。"

# auto-tl Qwen Colab

translate chinese chinese_9951501_0:
    old "Alright… time for some practice."
    new "好吧……该练习一下了。"

translate chinese chinese_6347372_1:
    old "Feels good to just sit down and play now."
    new "现在坐下来玩感觉真好。"

translate chinese chinese_9087276_2:
    old "It’s becoming part of the routine… and I actually look forward to it."
    new "这已经成为例行公事了……而且我实际上很期待它。"

translate chinese chinese_6981912_3:
    old "That one came out clean."
    new "那个说得挺干净。"

translate chinese chinese_7436270_4:
    old "The chords are flowing better every day."
    new "和弦每天都在流畅不少。"

translate chinese chinese_7372273_5:
    old "Hand still gets tired, but it doesn’t fight me anymore."
    new "手还是会觉得累，但不会再和我作对了。"

translate chinese chinese_8256620_6:
    old "Feels natural now… like the guitar is actually listening."
    new "现在感觉很自然……就像吉他真的在听你一样。"

translate chinese chinese_5018545_7:
    old "Rhythm’s locking in nicely."
    new "节奏很稳。"

translate chinese chinese_3456339_8:
    old "I can feel the music instead of just chasing the notes."
    new "我能感受到音乐，而不仅仅是追着音符走。"

translate chinese chinese_7266639_9:
    old "({i}This is actually fun… who would’ve thought?{/i})"
    new "(这 actually 真的挺好玩的……谁会想到呢？)"

translate chinese chinese_1184891_10:
    old "One more run-through. Let’s make it feel even smoother."
    new "再过一遍，让我们让它感觉更流畅。"

translate chinese chinese_7997618_11:
    old "Still a couple of rough spots… but overall it sounded solid."
    new "还有一些粗糙的地方……但总体听起来还不错。"

translate chinese chinese_3077343_12:
    old "I’m really starting to enjoy this."
    new "我开始真的喜欢这个了。"

translate chinese chinese_3965409_13:
    old "It doesn’t feel like a chore anymore. It feels… right."
    new "这不再像是任务了。感觉……对了。"

translate chinese chinese_8373793_14:
    old "Who knew picking up the guitar would end up being something I actually look forward to?"
    new "谁想到拿起吉他竟然变成了一件我期待的事情？"

translate chinese chinese_8039423_15:
    old "That’s enough for today. Fingers are happy."
    new "今天就到这里吧。手指很满意。"

translate chinese chinese_7594897_16:
    old "Tomorrow I’ll pick it up again… no pressure, just playing."
    new "明天再接着玩吧……不着急，就当放松。"

translate chinese chinese_3692553_17:
    old "There you are."
    new "你在这里啊。"

translate chinese chinese_8011491_18:
    old "Hey Billie."
    new "嘿，比莉。"

translate chinese chinese_2500906_19:
    old "Heh. Back again already?"
    new "嘿嘿。这么快又回来了？"

translate chinese chinese_3321988_20:
    old "The guitar at home not doing it for you anymore?"
    new "家里的吉他不再吸引你了？"

translate chinese chinese_0050971_21:
    old "Yeah… I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "嗯……我一个人练习了很多，但感觉和你在一起时进步更快。"

translate chinese chinese_6408390_22:
    old "Of course you do."
    new "当然可以。"

translate chinese chinese_2128178_23:
    old "Heh. Come on. Let’s take this to my room."
    new "嘿嘿。走吧。去我的房间再说。"

translate chinese chinese_4691952_24:
    old "Alright, we're here."
    new "好了，我们到了。"

translate chinese chinese_6376708_25:
    old "So... what are we practicing today?"
    new "所以……今天我们要练习什么？"

translate chinese chinese_7749509_26:
    old "Uhh, I would say let’s just rehearse the song together today."
    new "嗯，我说咱们今天就一起排练这首歌吧。"

translate chinese chinese_1600802_27:
    old "I want to polish the chords even more, youb know..."
    new "我想把和弦再打磨一下，你知道的……"

translate chinese chinese_1047836_28:
    old "Heh. Going for the safe route first? Fine by me… for now."
    new "嘿嘿。先走安全路线？随便你了……暂时先这样吧。"

translate chinese chinese_4832667_29:
    old "Grab the guitar. Show me what you’ve been working on."
    new "拿吉他来。让我看看你一直在练什么。"

translate chinese chinese_5195114_30:
    old "{i}I used to float above the ground…{/i}"
    new "{i}我以前能浮在空中……{/i}"

translate chinese chinese_4501946_31:
    old "{i}Now every step just pulls me down…{/i}"
    new "现在每一步都像是在拖我下去……"

translate chinese chinese_8054013_32:
    old "Hmm… your changes are actually smooth now. You’ve been practicing."
    new "嗯……你的变化现在挺自然的。你一直在练习吧。"

translate chinese chinese_9708440_33:
    old "We’re starting to sound like we really belong together on stage."
    new "我们听起来越来越像天生一对了。"

translate chinese chinese_1929448_34:
    old "Not bad at all. You’re actually carrying your part."
    new "挺不错的。你这部分完成得很到位。"

translate chinese chinese_4452993_35:
    old "Yeah, it feels good."
    new "是的，感觉真好。"

translate chinese chinese_6768038_36:
    old "See? When we rehearse like this, we both get better together."
    new "看？当我们这样排练时，我们俩都能一起进步。"

translate chinese chinese_2204117_37:
    old "Still… I wouldn’t mind if you picked something a little more fun next time."
    new "不过……下次如果你选个有趣点的，我也不会介意。"

translate chinese chinese_1403055_38:
    old "Uhh, I- I think my fingers could use some... practice."
    new "呃，我觉我的手指需要一些……练习。"

translate chinese chinese_6713909_39:
    old "You know what I mean?"
    new "你知道我的意思吧？"

translate chinese chinese_9692045_40:
    old "Heh. There it is. I was hoping you’d go for this."
    new "嘿嘿，就是这个。我本来就在希望你会选这个。"

translate chinese chinese_4654697_41:
    old "Good choice. I like when you get straight to it."
    new "好选择。我喜欢你直截了当。"

translate chinese chinese_6357326_42:
    old "Come here, let’s make ourselves comfortable."
    new "过来，让我们舒服一点。"

translate chinese chinese_7980838_43:
    old "This is what you wanted, huh?"
    new "这就是你想要的，对吧？"

translate chinese chinese_2958856_44:
    old "*Gulp*"
    new "*咕噜*"

translate chinese chinese_8671408_45:
    old "They’re all yours today."
    new "今天她们都归你了。"

translate chinese chinese_1818343_46:
    old "Hands on them. You already know exactly how I like it."
    new "把手放在上面。你已经知道我喜欙的方式了。"

translate chinese chinese_6485999_47:
    old "They’re… so soft every time. I can feel them filling my hands."
    new "它们……每次都很软，我能感觉到它们填满了我的手。"

translate chinese chinese_1987677_48:
    old "Mmm… squeeze them slowly. Open and close your hands… just like that."
    new "嗯……慢慢捏。张开手指，再合上……就是这样。"

translate chinese chinese_1529273_49:
    old "Nngh— yeah… a little harder now. Grip them properly."
    new "嗯——对……现在再用力一点。握紧点。"

translate chinese chinese_0888638_50:
    old "Fuck… keep that pace. Squeeze them like you mean it."
    new "妈的……保持这个节奏。用力捏。"

translate chinese chinese_5138066_51:
    old "Now the nipples… grab them and pull… slow at first."
    new "现在是乳头……捏住它们然后拉扯……一开始动作慢一点。"

translate chinese chinese_8421673_52:
    old "That’s it… stretch them gently."
    new "就是这样……轻轻地拉伸它们。"

translate chinese chinese_7520367_53:
    old "Mmm—harder. Tug them a little more. You’re getting really good at this."
    new "嗯——再用力点。再拉紧一点。你越来越擅长这个了。"

translate chinese chinese_0937576_54:
    old "Fuck… faster. Pull them nice and firm. I love how confident your hands feel now."
    new "操…快点。捏紧一点。我喜欢你现在手上的自信感觉。"

translate chinese chinese_4788105_55:
    old "Mmm… your touch is way more precise lately. You’ve improved a lot."
    new "嗯……你最近的手法精准多了。进步很大。"

translate chinese chinese_5768219_56:
    old "Your fingers are definitely improving. They feel so much more alive and sure of themselves."
    new "你的手指确实进步了。感觉它们变得更加有活力和自信了。"

translate chinese chinese_5512926_57:
    old "Keep practicing that rhythm at home… or just come back whenever you want more of... this."
    new "继续在家里练习那个节奏……或者你想再来……这个的时候就回来吧。"

translate chinese chinese_6975891_58:
    old "Uhh, actually I was wondering if we could try the... 'advanced practice' today..."
    new "呃，其实我在想今天我们能不能试试……“高级练习”……"

translate chinese chinese_1434259_59:
    old "Heh. Straight to my favorite part. I was really hoping you’d pick this one."
    new "嘿嘿。直接到我最喜欢的部分了。我真的希望你会选这个。"

translate chinese chinese_2070127_60:
    old "You know I like when you get straight to the fun stuff."
    new "你知道我喜欢直接进入正题。"

translate chinese chinese_5303998_61:
    old "Get ready. I’m getting on top."
    new "准备好，我要上去了。"

translate chinese chinese_9166701_62:
    old "I know how much you like to see them, so why don’t we make it more enjoyable for both of us?"
    new "我知道你喜欢看这些，那我们为什么不一起弄得更有趣一点呢？"

translate chinese chinese_7231220_63:
    old "Now use those fingers right. Show me what you’ve learned."
    new "现在用那些手指好好表现一下。把你学到的展示给我看看。"

translate chinese chinese_5023128_64:
    old "Mmm… circle my clit first. Gentle, like I showed you."
    new "嗯……先弄我的 clit，轻一点，就像我教你的那样。"

translate chinese chinese_1431145_65:
    old "Shit… your fingers really kept perfect rhythm this time."
    new "shit… 你这次手指的节奏真的很完美。"

translate chinese chinese_8340172_66:
    old "This is exactly the kind of dexterity we need… both on stage and off it."
    new "这正是我们需要的灵巧……无论是台上还是台下。"

translate chinese chinese_4088027_67:
    old "Uhh… I’ve been practicing the guitar a lot by myself lately."
    new "呃……我最近一个人练吉他练得挺多的。"

translate chinese chinese_5686772_68:
    old "And I was thinking… maybe it would be good if I helped you with your practice too, you know?"
    new "而且我在想……也许我也帮你练习会比较好，你知道吗？"

translate chinese chinese_4317024_69:
    old "Like… helping you stay steady under pressure… like last time…"
    new "比如……帮助你在压力下保持冷静……就像上次一样……"

translate chinese chinese_9098837_70:
    old "Heh… look at you trying to be all subtle."
    new "嘿嘿……看你装模作样。"

translate chinese chinese_0839596_71:
    old "You’ve been practicing hard, huh? And now you want to 'help' me with my vocal training."
    new "你一直在努力练习吧？现在还想帮我进行 vocal 训练吗？"

translate chinese chinese_6372847_72:
    old "Cute. Real cute."
    new "真可爱。真够可爱的。"

translate chinese chinese_7410725_73:
    old "I know exactly what you mean, dummy."
    new "我完全明白你的意思，傻瓜。"

translate chinese chinese_5791241_74:
    old "Lie down. Time to put that tongue to good use."
    new "躺下。是时候让你那舌头派上用场了。"

translate chinese chinese_4699240_75:
    old "Tongue out. Keep me steady while I lose it."
    new "舌头伸出来。帮我稳住，让我尽情释放。"

translate chinese chinese_7272221_76:
    old "You’re already dripping…"
    new "你已经湿了……"

translate chinese chinese_8727989_77:
    old "Nngh… your tongue is getting way too good at this."
    new "嗯……你的舌头越来越厉害了。"

translate chinese chinese_0533756_78:
    old "Every time you do this my voice gets stronger under pressure… and I get to enjoy that mouth of yours."
    new "每次你这么做的时候，我的声音在压力下变得更强……而且我可以享受你的嘴巴。"

translate chinese chinese_1630140_79:
    old "And sometimes I feel like I still need… a little extra motivation to keep improving."
    new "有时候我觉得我还需要一点额外的动力来继续进步。"

translate chinese chinese_6596508_80:
    old "Heh… so that’s what this is really about."
    new "嘿嘿……原来这才是重点。"

translate chinese chinese_8854568_81:
    old "All that solo practice and you still need me to give you a little push, huh?"
    new "那么多独自练习，还需要我给你一点助推吗？"

translate chinese chinese_8780030_82:
    old "Would this be enough motivation for you?"
    new "这够成为你的动力吗？"

translate chinese chinese_2832391_83:
    old "Just looking at them… does that help?"
    new "just looking at them… does that help? \n\n（这里似乎有部分内容缺失或不完整，我直接翻译了可用的部分。如果有更多上下文，请提供。） \n\n看着它们……这有用吗？"

translate chinese chinese_8516755_84:
    old "Y-yeah… they look amazing but… I was thinking maybe something more… direct?"
    new "嗯……他们看起来很棒，但是……我在想也许可以更……直接一点？"

translate chinese chinese_5045371_85:
    old "Oh? Not satisfied with just the view?"
    new "哦？光看不够吗？"

translate chinese chinese_1692276_86:
    old "Greedy today, aren’t you?"
    new "今天挺贪心的嘛？"

translate chinese chinese_9294394_87:
    old "Heh… fine. I know exactly how to motivate you properly."
    new "嘿嘿……好吧。我知道怎么正好激励你。"

translate chinese chinese_2618516_88:
    old "Let me take care of that motivation the right way."
    new "让我用正确的方式处理那个动机。"

translate chinese chinese_5925661_89:
    old "Eyes on me the whole time."
    new "一直盯着我。"

translate chinese chinese_5040485_90:
    old "Mmm… look at you. Already so hard just from asking."
    new "嗯……看看你。光是问一下就這麼硬了。"

translate chinese chinese_9322898_91:
    old "Billie… that feels so good…"
    new "比莉……感觉真好……"

translate chinese chinese_5864854_92:
    old "Deeper now… I want to feel every throb."
    new "现在更深一点……我想感受每一次的悸动。"

translate chinese chinese_0566920_93:
    old "Fuck… you’re way too good at this."
    new "妈的……你太擅长这个了。"

translate chinese chinese_6942919_94:
    old "I’m— I’m close…!"
    new "我——快到了！"

translate chinese chinese_2865857_95:
    old "Mmm… every drop. Good boy."
    new "嗯……每一滴。好孩子。"

translate chinese chinese_6269628_96:
    old "Heh… feeling more motivated already?"
    new "嘿嘿……感觉更有动力了？"

translate chinese chinese_2208735_97:
    old "Come back whenever you need some real motivation again… I’ll be waiting."
    new "随时回来找我获取些真正的动力吧……我会等着的。"

translate chinese chinese_0762744_98:
    old "Phew, well, that’s enough for today."
    new "呼，好吧，今天就到这儿吧。"

translate chinese chinese_9146164_99:
    old "You can come back whenever you need more 'practice'."
    new "你需要更多“练习”的时候随时可以回来。"

translate chinese chinese_5588350_100:
    old "Just text me. I’ll always make time… especially if you want the fun version."
    new "就发短信给我吧。我总是会留出时间……特别是如果你想听有趣版本的话。"

translate chinese chinese_3237274_101:
    old "I’ll be back soon."
    new "我很快就回来。"

translate chinese chinese_5739247_102:
    old "You better. Now get out before grandma walks in."
    new "你最好快点。在奶奶进来前给我滚出去。"

translate chinese chinese_6201787_103:
    old "Phew… that’s enough for today."
    new "呼……今天就到此为止吧。"

translate chinese chinese_8405084_104:
    old "Not bad. You’re actually starting to sound like you belong up there with me."
    new "不错嘛。你开始听起来像是能和我并肩了。"

translate chinese chinese_1666313_105:
    old "Oh, by the way…"
    new "哦，对了……"

translate chinese chinese_1073035_106:
    old "Tomorrow we have a practice with Bey. Don’t slack off tonight."
    new "明天我们要和Bey一起练习。今晚别偷懒。"

translate chinese chinese_6452870_107:
    old "Get some rest, warm up your fingers, and meet me at school. We’re doing a full run-through with her watching."
    new "休息一下，暖暖手指，然后在学校见。我们要来一次完整的彩排，让她看着。"

translate chinese chinese_6448315_108:
    old "Got it. I’ll be there."
    new "知道了，我会去的。"

translate chinese chinese_0133071_109:
    old "You better. Don’t make me drag you out of bed."
    new "最好行。别逼我把你从床上拖起来。"

translate chinese chinese_5484091_110:
    old "You’re getting better every time. I can feel it."
    new "你每次都在进步。我感觉得到。"

translate chinese chinese_7681570_111:
    old "Hey… before you go."
    new "喂……走之前。"

translate chinese chinese_8815253_112:
    old "I need a favor. Free up your afternoon tomorrow and come over."
    new "我有个忙要请你帮。明天下午空出来，过来一下。"

translate chinese chinese_4011038_113:
    old "Sure, what for?"
    new "当然，干什么用？"

translate chinese chinese_8684548_114:
    old "Just come. I need you to accompany me somewhere. No questions."
    new "你就来吧。我需要你陪我去个地方。别问了。"

translate chinese chinese_0295781_115:
    old "It’s important… and I don’t want to go alone."
    new "这很重要……而且我不想去一个人去。"

translate chinese chinese_2754412_116:
    old "A- alright. I’ll be here."
    new "好啦，我会在这里的。"

translate chinese chinese_8145341_117:
    old "Good. Don’t be late. Now get out before grandma walks in."
    new "好。别迟到。快走，在奶奶进来前出去。"

# auto-tl Qwen Colab

translate chinese chinese_9029386_0:
    old "Talk to her"
    new "和她聊聊"

translate chinese chinese_6864341_1:
    old "Hello, welcome to Jamliz Corporation! How can I help you?"
    new "你好，欢迎来到Jamliz公司！有什么可以帮你的？"

translate chinese chinese_4553918_2:
    old "Hi, nice to meet you. My name is [pla]. I was sent by my [mo2rel], to give you these documents..."
    new "你好，很高兴见到你。我叫[pla]，我是被我的[mo2rel]派来给你送这些文件的..."

translate chinese chinese_3270220_3:
    old "Ohh right. She told me she was going to send a delivery boy with those documents. Perfect... Thank you very much!"
    new "哦对，她说会派一个送货员送那些文件过来。太好了……非常感谢！"

translate chinese chinese_5812278_4:
    old "Delivery boy? Ok, well... I think that's it... right?"
    new "送餐员？好吧……我想就这些了……对吧？"

translate chinese chinese_1748359_5:
    old "Yes, and by the way, my name is Akita nice to meet you..."
    new "是的，对了，我叫秋田，很高兴见到你..."

translate chinese chinese_6486351_6:
    old "Oh, yes, I'm [pla]. The pleasure is mine..."
    new "哦，是的，我是[pla]。很高兴……"

translate chinese chinese_9411887_7:
    old "Yes, yes you already told me... Hahaha."
    new "是的是的，你已经告诉我了……哈哈。"

translate chinese chinese_2108346_8:
    old "Oh... right, of course, my bad... Well, it was nice to meet you, see you later..."
    new "哦……对了，当然，是我的错……好吧，很高兴见到你，再见……"

translate chinese chinese_5180666_9:
    old "See you later, [pla]."
    new "再见了，[pla]。"

translate chinese chinese_3725713_10:
    old "Oh, hi [pla], Mrs. [mo2] sent you with more documents or did you come to visit me?"
    new "哦，你好[pla]，[mo2]太太派你送文件来的，还是来看我的？"

translate chinese chinese_6019203_11:
    old "Well, Mr. [mo2] sent me..."
    new "嗯，[mo2]先生派我来的..."

translate chinese chinese_8930066_12:
    old "Hahaha, I'm just messing with you, perfect... Thank you very much."
    new "哈哈，我开玩笑的，完美……非常感谢。"

translate chinese chinese_3808227_13:
    old "Well... You're welcome, see you later..."
    new "嗯……不客气，再见……"

translate chinese chinese_3921188_14:
    old "Goodbye, handsome."
    new "再见了， handsome."

translate chinese chinese_8607716_15:
    old "..."
    new "..."

translate chinese chinese_8518854_16:
    old "I shouldn't bother her. She's working."
    new "我不应该打扰她，她正在工作。"

translate chinese chinese_6531607_17:
    old "Use Agamoto Eye 1"
    new "使用阿伽摩眼1"

translate chinese chinese_8692604_18:
    old "Use Agamoto Eye 2"
    new "使用阿伽摩托之眼 2"

translate chinese chinese_9951931_19:
    old "Use Agamoto Eye 3"
    new "使用阿伽摩托之眼3"

translate chinese chinese_6780745_20:
    old "No, no. Sorry. I was just walking around."
    new "不，不。对不起。我只是在四处走走。"

translate chinese chinese_9478570_21:
    old "Back"
    new "返回"

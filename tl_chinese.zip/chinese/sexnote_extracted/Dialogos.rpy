# auto-tl Qwen Colab

translate chinese chinese_1587314_0:
    old "Another day..."
    new "又一天……"

translate chinese chinese_8751189_1:
    old "Let’s just get through classes and survive."
    new "咱们还是先熬过这些课吧。"

translate chinese chinese_6381084_2:
    old "Hope nothing weird happens today."
    new "希望今天不要发生什么奇怪的事情。"

translate chinese chinese_2047679_3:
    old "Hmm... What's that sound coming down the hall?"
    new "嗯……那是从走廊传来的什么声音？"

translate chinese chinese_8188788_4:
    old "{i}Now every step just pulls me down...{/i}"
    new "现在每一步都像是在拖我后腿..."

translate chinese chinese_8307824_5:
    old "({i}Sounds like music, but faint. Someone’s phone playing a song?{/i})"
    new "({i}听起来像音乐，但很微弱。是有人的手机在播放歌曲吗？{/i})"

translate chinese chinese_1796769_6:
    old "{i}Everything I wanted slips right through my hands...{/i}"
    new "{i}所有我想要的东西都从手中溜走了……{/i}"

translate chinese chinese_7865337_7:
    old "No way, it’s a voice. Singing softly... from the girls’ bathroom?"
    new "不可能，那是歌声。轻轻地……从女生洗手间传来的？"

translate chinese chinese_5489131_8:
    old "{i}And I’m still breathing... but I don’t understand...{/i}"
    new "{i}我还在呼吸……但我不明白……{/i}"

translate chinese chinese_3453365_9:
    old "({i}That melody’s got so much heart. Who’s in there?{/i})"
    new "(那旋律充满了感情。里面是谁？)"

translate chinese chinese_5852187_10:
    old "Hey [bil]... that singing? Was that you?"
    new "嘿[bil]……刚才唱歌的是你吗？"

translate chinese chinese_6391641_11:
    old "Heh, singing? Nah, probably just music from next classroom."
    new "嘿嘿，唱歌？应该只是隔壁教室的音乐吧。"

translate chinese chinese_6040274_12:
    old "Uhh, music? It sounded like someone singing, like right here."
    new "呃，音乐？听起来像是有人在这里唱歌。"

translate chinese chinese_7188994_13:
    old "Or someone’s phone blasting some old track. This place is a noise fest."
    new "或者有人的手机在放老歌。这里简直就是噪音节。"

translate chinese chinese_6223252_14:
    old "({i}She’s dodging it hard. But that voice was totally hers.{/i})"
    new "(她在拼命回避。但那个声音绝对是她的。)"

translate chinese chinese_8253435_15:
    old "Come on, [bil], it was too good to be just an echo."
    new "来吧，[bil]，那声音好到不可能只是回声。"

translate chinese chinese_4599127_16:
    old "Too good? Dude, if I was singing, I’d be viral already. Blame the vents."
    new "太好了？兄弟，如果我唱歌的话，早就火了。怪这些通风口。"

translate chinese chinese_5501069_17:
    old "The vents? For real? It had this raw emotion..."
    new "通风口？ seriously? 这种 raw emotion... \n\n（注：此处\"seriously?\"和\"raw emotion\"未翻译以保留原文效果）"

translate chinese chinese_7140650_18:
    old "Emotional vents, then. Case closed. Catch you later, [pla]."
    new "那就发泄一下情绪吧。结案了。待会儿见，[pla]。"

translate chinese chinese_5937346_19:
    old "Whoa, her notebook just dropped."
    new "谁啊，她的笔记本掉了。"

translate chinese chinese_9504940_20:
    old "What’s this? Doodles, messy scratches... hold up, are these lyrics?"
    new "这是什么？涂鸦，乱七八糟的划痕……等等，这些是歌词吗？"

translate chinese chinese_6643628_21:
    old "Music notes scribbled everywhere. ‘Faded echoes, songs we lost...’"
    new "到处都是涂鸦的音符。‘消逝的回声，失去的歌曲……’"

translate chinese chinese_3687655_22:
    old "({i}This matches the melody perfectly. It was definitely her.{/i})"
    new "({i}这完全符合旋律。肯定是她。{/i})"

translate chinese chinese_6304255_23:
    old "Why deny it? Someone with this talent..."
    new "为什么要否认呢？有这种天赋的人..."

translate chinese chinese_8036612_24:
    old "({i}Hiding something this raw doesn’t make sense. I’ll take it to her place.{/i})"
    new "({i}这么直接地隐瞒没什么意义。我还是带去她家吧。{/i})"

translate chinese chinese_8728656_25:
    old "Yeah, that’s the right call."
    new "嗯，那是正确的决定。"

translate chinese chinese_2885553_26:
    old "Oh, [pla]! What a treat to see you, honey!"
    new "哦，[pla]！看到你真高兴，宝贝！"

translate chinese chinese_8426390_27:
    old "Hey, Mrs. Jones. Sorry for dropping by unannounced."
    new "嘿，琼斯夫人。抱歉突然来访。"

translate chinese chinese_2691419_28:
    old "Nonsense, you’re always welcome. How’s school going?"
    new "胡说，你随时都欢迎。学校怎么样？"

translate chinese chinese_5099863_29:
    old "It’s alright. Keeps me on my toes."
    new "没关系。这样让我保持警惕。"

translate chinese chinese_6496061_30:
    old "Oh, you’re always so busy! [bil]’s out with friends, but what brings you by?"
    new "哦，你总是这么忙！[bil]出去和朋友玩了，那你来干嘛呢？"

translate chinese chinese_8671257_31:
    old "Well, she dropped her notebook at school. Figured it’s important."
    new "嗯，她在学校掉了笔记本。估计很重要。"

translate chinese chinese_9927551_32:
    old "Let me see... Oh, these sketches and notes. Takes me way back."
    new "让我看看……哦，这些草图和笔记。真是勾起了不少回忆。"

translate chinese chinese_8683720_33:
    old "Way back? To what, if it’s okay to ask?"
    new "很久以前？能问一下是多久吗？"

translate chinese chinese_3340181_34:
    old "To when she was little. Her parents... they used to sing with her every night."
    new "回到她小时候。她的父母……每晚都会陪她唱歌。"

translate chinese chinese_6370356_35:
    old "({i}Singing together? That’s so sweet.{/i})"
    new "({i}一起唱歌？真甜。{/i})"

translate chinese chinese_2480608_36:
    old "I can imagine that. Must’ve been her whole world."
    new "我能想象。那一定是她的整个世界。"

translate chinese chinese_3459929_37:
    old "It was. Her dad with his old guitar, her mom humming along. It lit her up."
    new "是的。她爸爸弹着那把旧吉他，妈妈在一旁哼唱。这让她很开心。"

translate chinese chinese_0590243_38:
    old "({i}So that’s where her gift comes from.{/i})"
    new "({i}原来她的天赋是从这里来的。{/i})"

translate chinese chinese_8170685_39:
    old "I heard her today. It really hit me deep."
    new "我今天听到了她的声音，真的触动很深。"

translate chinese chinese_1246863_40:
    old "Oh really? You heard her singing today?"
    new "哦真的吗？你今天听到她唱歌了？"

translate chinese chinese_3939528_41:
    old "Well, she used to sing all the time. It was such a lovely thing to hear... but after her parents passed, everything changed for her."
    new "嗯，她以前经常唱歌。听起来真好听……但自从她的父母去世后，一切都变了。"

translate chinese chinese_8198961_42:
    old "Oh, I didn't know? I’m so sorry, Mrs. Jones. That sounds so tough."
    new "哦，我不知道？琼斯夫人，真对不起，那听起来好辛苦。"

translate chinese chinese_2295723_43:
    old "It was a long time ago... A car accident. Took them both in an instant."
    new "那是很久以前的事了……一场车祸。一瞬间就带走了他们两个。"

translate chinese chinese_2136795_44:
    old "({i}Gone just like that. No wonder it shook her.{/i})"
    new "({i}就这样消失了。难怪会让她这么震惊。{/i})"

translate chinese chinese_4112904_45:
    old "That’s so sad. How did [bil] get through it?"
    new "真可怜。[bil]是怎么挺过来的？"

translate chinese chinese_4929332_46:
    old "Faith carried us. But for her, singing turned into pain."
    new "信仰支撑着我们。但对她来说，唱歌变成了痛苦。"

translate chinese chinese_6998740_47:
    old "Every note brought their voices back. First happy, then just the hurt."
    new "每一张便条都让他们的声音回荡起来。起初是快乐的，然后就是伤痛的。"

translate chinese chinese_6965492_48:
    old "So it stopped being joy. More like ripping open old wounds?"
    new "所以这已经不再是快乐了，更像是揭开旧伤口？"

translate chinese chinese_9151766_49:
    old "Exactly. She shut it down, like flipping a switch."
    new "没错。她直接拒绝了，就像开关一样干脆。"

translate chinese chinese_9645819_50:
    old "({i}That cool act she pulls... it’s gotta be shielding all this.{/i})"
    new "(她那副酷酷的样子……肯定是在掩饰这一切。)"

translate chinese chinese_1471715_51:
    old "I get why she’d hide something tied to them."
    new "我能理解她为什么要隐瞒和他们有关的东西。"

translate chinese chinese_4299160_52:
    old "You see her heart, [pla]. Not many do."
    new "你能看到她的内心，[pla]。不是很多人都能做到。"

translate chinese chinese_0593315_53:
    old "Just wish it didn’t weigh her down like that. Feels so unfair."
    new "就希望这件事不要压得她那么重。感觉好不公平。"

translate chinese chinese_1533151_54:
    old "Life’s not always kind, honey. But you’re sweet to care."
    new "生活并不总是善良的，亲爱的。但你很体贴，我很感激。"

translate chinese chinese_0577384_55:
    old "I’ll leave the notebook. Tell her I didn’t snoop too much."
    new "我把笔记本留下。告诉她我没有乱翻。"

translate chinese chinese_6663057_56:
    old "Of course, dear. Safe walk home now."
    new "当然了，亲爱的。路上小心。"

translate chinese chinese_1270409_57:
    old "Thanks, Mrs. Jones. See you soon."
    new "谢谢琼斯夫人，很快见。"

translate chinese chinese_3775324_58:
    old "Man... what a day."
    new "唉……真是辛苦的一天。"

translate chinese chinese_8951277_59:
    old "So that’s why she acts like nothing touches her."
    new "怪不得她表现得好像什么都不在乎。"

translate chinese chinese_3454565_60:
    old "Losing both parents at once... and singing was the last thing connecting her to them."
    new "一下子失去了双亲……而且唱歌是她最后与他们相连的东西。"

translate chinese chinese_6811506_61:
    old "Now I get why she kept dodging the whole thing. Every note probably feels like losing them again."
    new "现在我明白她为什么一直回避了。每一条便签可能都让她感觉像是再次失去了他们。"

translate chinese chinese_0155994_62:
    old "She’s not hiding because she’s shy. She’s hiding because it hurts too much to let it out."
    new "她不是因为害羞才躲藏。她是痛到无法释放自己才躲藏。"

translate chinese chinese_1095278_63:
    old "That cool girl armor isn’t just attitude. It’s survival."
    new "那酷girl的盔甲不仅仅是态度，那是生存之道。"

translate chinese chinese_5867592_64:
    old "But that voice... It’s still in there. And it’s beautiful."
    new "但是那个声音……它还在里面。而且它很美。"

translate chinese chinese_9728874_65:
    old "If there’s even a tiny chance something could help her feel that joy again... I have to try."
    new "如果有一丝机会能让她再次感受到那种快乐……我必须试试。"

translate chinese chinese_8555825_66:
    old "I don’t know how yet, but I’m not letting her carry this alone."
    new "我不知道该怎么帮，但我不让她一个人承担这一切。"

translate chinese chinese_4875056_67:
    old "({i}Still can’t get [bil]’s voice out of my head. That song was something else.{/i})"
    new "({i}还是无法把[bil]的声音从脑海里赶出去。那首歌真是不同凡响。{/i})"

translate chinese chinese_9956413_68:
    old "Hold up, what’s this flyer on the wall?"
    new "等一下，墙上的这张传单是什么？"

translate chinese chinese_0178523_69:
    old "School’s doing a music contest? Sign-ups are open..."
    new "学校要举办音乐比赛？报名已经开始……"

translate chinese chinese_7829501_70:
    old "Wait. This is exactly what [bil] needs right now."
    new "等一下。这正是[bil]现在需要的。"

translate chinese chinese_0745419_71:
    old "({i}She’s got the talent, she just doesn’t show it. This could pull her out of that shell.{/i})"
    new "({i}她有这个天赋，只是不表现出来。这也许能让她走出自己的壳。{/i})"

translate chinese chinese_1142342_72:
    old "({i}She’s literally going to murder me for signing her up without asking.{/i})"
    new "(她要是知道我未经她同意就替她报名，肯定要杀了我。)"

translate chinese chinese_3157065_73:
    old "({i}Like, straight-up bury me in the backyard. But it’s worth the risk, right?{/i})"
    new "（就像直接把我埋在后院一样。但值得一试，对吧？）"

translate chinese chinese_2354712_74:
    old "Gotta do it."
    new "得这么做。"

translate chinese chinese_3569998_75:
    old "Hi, are you Ms. Beylaine?"
    new "你好，你是贝莱恩小姐吗？"

translate chinese chinese_0877429_76:
    old "That’s me, honey! Come in, come in."
    new "那就是我啦，宝贝！进来进来。"

translate chinese chinese_4141849_77:
    old "I saw the flyer about the music contest. Looks really cool."
    new "我看到了那个音乐比赛的海报，看起来很酷。"

translate chinese chinese_9572277_78:
    old "Cool? Baby, it’s about to be everything."
    new "酷？宝贝，这将是一切。"

translate chinese chinese_9188031_79:
    old "I wanna sign up. Me and my friend [bil]."
    new "我想报名。我和我的朋友[bil]。"

translate chinese chinese_3188481_80:
    old "Love the duo energy! Tell me about you two."
    new "你们俩的CP感真强！跟我说说你们吧。"

translate chinese chinese_4962841_81:
    old "Well, she’s got an insane voice, but she keeps it hidden. I thought this might be good for her."
    new "嗯，她的声音很特别，但她一直藏着不露。我觉得这可能对她有好处。"

translate chinese chinese_7216188_82:
    old "Hidden talent? That’s my favorite kind."
    new "隐藏的才能？那正是我最喜欢的类型。"

translate chinese chinese_7717954_83:
    old "What about you, handsome? What do you bring to the stage?"
    new "那你呢， handsome？你给这个舞台带来了什么？"

translate chinese chinese_6421960_84:
    old "Uhh... honestly? Nothing. I can’t sing, can’t play. Zero."
    new "呃……老实说？什么都不会。不会唱歌，也不会玩。零蛋。"

translate chinese chinese_0259255_85:
    old "Zero today doesn’t mean zero tomorrow."
    new "今天没有不代表明天也没有。"

translate chinese chinese_2020804_86:
    old "Don't worry, we’re doing practice sessions first. Technique, composition, stage fire. I pull the best out of everybody."
    new "放心，我们会先进行练习。技巧、构图、舞台火焰。我会把每个人的潜力都激发出来。"

translate chinese chinese_2388478_87:
    old "So we get actual coaching before the contest?"
    new "所以我们比赛前真的会接受训练？"

translate chinese chinese_9778328_88:
    old "Exactly. I don’t just throw y’all to the wolves. We build it together."
    new "没错。我不是把你们随便扔到狼群里。我们一起努力。"

translate chinese chinese_2717716_89:
    old "Oh, that sounds perfect, actually."
    new "哦，那听起来正好。"

translate chinese chinese_6855291_90:
    old "Ok, to start, I just need you to fill out a couple forms for you and your friend. After that, I’ll reach out to schedule the audition."
    new "好的，首先，我需要你填写几份表格，你和你的朋友各一份。之后我会联系你们安排试镜。"

translate chinese chinese_8026591_91:
    old "Got it, thanks, Ms. Beylaine. This means a lot."
    new "明白了，谢谢贝莱因女士。这对我来说意义重大。"

translate chinese chinese_1271935_92:
    old "Call me Bey. And tell your friend: when she’s ready to own that stage, I got her."
    new "叫我Bey。还有告诉你朋友，等她准备好征服那个舞台时，我支持她。"

translate chinese chinese_0182505_93:
    old "({i}This is really happening. [bil]’s gonna flip... but in a good way. I hope.{/i})"
    new "({i}这真的发生了。[bil]会很激动……但愿是好的那种。{/i})"

translate chinese chinese_9114651_94:
    old "({i}Best idea I’ve ever had.{/i})"
    new "({i}我这辈子最好的主意。{/i})"

translate chinese chinese_8693754_95:
    old "({i}Now I just gotta figure out how to tell [bil] without her breaking my neck.{/i})"
    new "({i}现在我得想怎么跟[bil]说这件事，又不会被她扭断脖子。{/i})"

translate chinese chinese_0178434_96:
    old "({i}She’s scary when she’s mad... but this is for her.{/i})"
    new "({i}她生气时很可怕……但这都是为了她。{/i})"

translate chinese chinese_9213196_97:
    old "Hey [bil]! You’re not gonna believe what I just did!"
    new "嘿[bil]！你猜我刚做了什么！"

translate chinese chinese_1429240_98:
    old "Hmm, what now?"
    new "嗯，接下来怎么办？"

translate chinese chinese_1427736_99:
    old "I signed us up for the music contest!"
    new "我为我们报名参加音乐比赛了！"

translate chinese chinese_5289098_100:
    old "You... did what?"
    new "你……做了什么？"

translate chinese chinese_9152606_101:
    old "Yeah! They’ve got coaching and everything. It’s perfect!"
    new "对啊！他们有教练什么的，完美极了！"

translate chinese chinese_6197960_102:
    old "You signed me up. Without even asking."
    new "你连问都没问我就给我报了名。"

translate chinese chinese_9612725_103:
    old "I know, I know, it sounds crazy, but just hear me out—"
    new "我知道，我知道，这听起来很疯狂，但请听我解释—"

translate chinese chinese_4397136_104:
    old "No. You don’t get to decide that for me, [pla]."
    new "不。你不能替我决定这些，[pla]。"

translate chinese chinese_3372914_105:
    old "No, no, it's just that you have this insane voice. Like, people need to hear it."
    new "不，不，只是因为你有这种疯狂的声音。就像，人们需要听到它。"

translate chinese chinese_6521946_106:
    old "That’s not the point. It’s my thing, not yours."
    new "那不是重点。那是我的事，跟你无关。"

translate chinese chinese_1756601_107:
    old "Come on, it’s just a contest! You’d crush everyone."
    new "别紧张，这只是一个比赛！你肯定能碾压所有人的。"

translate chinese chinese_5269364_108:
    old "Stop acting like you know what’s best for me."
    new "别装作你知道什么对我最好。"

translate chinese chinese_4736197_109:
    old "I’m not! I just... saw the flyer and thought 'this is made for [bil]'."
    new "我才没有！我只是……看到传单觉得“这简直就是为[bil]准备的”。"

translate chinese chinese_6786339_110:
    old "Well, you thought wrong."
    new "嗯，你猜错了。"

translate chinese chinese_0364812_111:
    old "Wait, your grandma told me how much you used to love singing with your parents—"
    new "等一下，你奶奶告诉我你以前有多喜欢和父母一起唱歌——"

translate chinese chinese_8399335_112:
    old "I- I- I’m sorry!"
    new "我我我对不起！"

translate chinese chinese_1777285_113:
    old "I- I didn’t mean it l- like that, I- I swear!"
    new "我—我没那个意思，我发誓！"

translate chinese chinese_2526012_114:
    old "You have no idea what you’re talking about."
    new "你根本不知道自己在说什么。"

translate chinese chinese_1135193_115:
    old "I know! I messed up, okay? I’m really sorry."
    new "我知道！我搞砸了，好吧？我真的对不起。"

translate chinese chinese_6150797_116:
    old "I just... I thought it would help. That’s all."
    new "我就是……以为会有帮助。就这么回事。"

translate chinese chinese_2757173_117:
    old "You don’t get to dig into my life like that!"
    new "你没权利这么刨根问底！"

translate chinese chinese_3634514_118:
    old "You’re right. I overstepped. Big time."
    new "你说得对。我过线了。而且过得很厉害。"

translate chinese chinese_3150702_119:
    old "I- I’m sorry, [bil]. Seriously."
    new "我……真的很抱歉，[bil]。真的。"

translate chinese chinese_8465548_120:
    old "Tsk..."
    new "啧……"

translate chinese chinese_0260381_121:
    old "Mind your own business, [pla]. This isn’t your thing to fix."
    new "管好你自己的事，[pla]。这不关你的事。"

translate chinese chinese_8631721_122:
    old "I get it. But your voice... it’s too good to stay hidden."
    new "我明白。但是你的声音……太好了，不应该被埋没。"

translate chinese chinese_4643092_123:
    old "Why do you even care?"
    new "你为什么在乎呢？"

translate chinese chinese_4811036_124:
    old "Because I hate seeing you hold back something you’re amazing at."
    new "因为我不喜欢看到你对自己擅长的事情有所保留。"

translate chinese chinese_9530695_125:
    old "It’s not that simple."
    new "没那么简单。"

translate chinese chinese_9384617_126:
    old "I know it’s not. But just one practice. One."
    new "我知道不是这样的。但就一次练习。一次。"

translate chinese chinese_9704913_127:
    old "You’re seriously not dropping this?"
    new "你真的不打算放弃吗？"

translate chinese chinese_4466474_128:
    old "I can’t. Not when I know how much talent you have."
    new "我不能。我知道你有多少才华。"

translate chinese chinese_8517147_129:
    old "You’re impossible."
    new "你真是个难题。"

translate chinese chinese_7560256_130:
    old "Please. One session. If it sucks, we never talk about it again."
    new "拜托了。就一次。如果不好玩，我们就再也不提了。"

translate chinese chinese_9807134_131:
    old "You’re gonna keep bugging me until I say yes, aren’t you?"
    new "你打算缠着我直到我说好吧？"

translate chinese chinese_0557607_132:
    old "Uhh... pretty much."
    new "嗯……差不多吧。"

translate chinese chinese_2583507_133:
    old "Ughh... fine. One practice. Just to shut you up."
    new "唉……好吧。就练一次。让你闭嘴。"

translate chinese chinese_1027359_134:
    old "But that’s it. And after that, we’re done talking about it. Got it? End of discussion."
    new "但是就这样了。说完这一句，我们就不要再提这件事了。明白吗？讨论到此为止。"

translate chinese chinese_0273293_135:
    old "Deal! Thank you!"
    new "成交！谢谢！"

translate chinese chinese_0387642_136:
    old "Don’t thank me yet."
    new "别急着谢我。"

translate chinese chinese_9219660_137:
    old "And don’t you ever ever bring up my parents again. You hear me?"
    new "而且你永远都不要再提我的父母，听见没有？"

translate chinese chinese_4372127_138:
    old "Uhh, yeah, got it..."
    new "嗯，好吧，明白了……"

translate chinese chinese_0704215_139:
    old "Phew.... Well, she didn’t kill me... I’ll call that a win."
    new "呼……好吧，她没杀我……我就当赢了吧。"

translate chinese chinese_8060116_140:
    old "One practice. That’s all I needed."
    new "只要一次练习，我就够了。"

translate chinese chinese_0089154_141:
    old "The audition. The contest thing. Oh man, [bil] better not bail on me."
    new "试镜。那个比赛。哦 man，[bil] 可别放我鸽子。"

translate chinese chinese_4041953_142:
    old "She said she’d show... right?"
    new "她说会展示的……对吧？"

translate chinese chinese_8875257_143:
    old "I have zero clue what I’m doing up there, but it’s for her. Gotta move."
    new "我在上面完全不知道自己在做什么，但都是为了她。得行动了。"

translate chinese chinese_9535786_144:
    old "There you are! Ready for this?"
    new "你在这里！准备好了吗？"

translate chinese chinese_6515647_145:
    old "Ready? I’m here because you wouldn’t shut up about it."
    new "准备好了？我来这里是因为你一直念念不忘。"

translate chinese chinese_7006510_146:
    old "Come on, it’s gonna be fine. Just one showcase."
    new "放心吧，没事的。就一次展示。"

translate chinese chinese_9658092_147:
    old "Yeah, yeah. Let’s get this over with so I can go back to my life."
    new "好吧好吧，赶紧搞定这样我就能回去过我的生活了。"

translate chinese chinese_5183608_148:
    old "You’re gonna kill it, [bil]. I know it."
    new "你一定能行的，[bil]。我有信心。"

translate chinese chinese_9687777_149:
    old "Save the pep talk, [pla]. I’m doing this to make you stop bugging me, remember?"
    new "省省吧，[pla]。我这么做是为了让你别再烦我，记得吗？"

translate chinese chinese_9778559_150:
    old "Fair enough."
    new "说得没错。"

translate chinese chinese_1598427_151:
    old "({i}She’s trying to act like she doesn’t care... but she showed up.{/i})"
    new "(她在装作不在乎……但还是来了。)"

translate chinese chinese_0256718_152:
    old "Whatever. Let's go I don't have all day."
    new "随便了。走吧，我可没一整天的时间。"

translate chinese chinese_8294749_153:
    old "Sure, let's go."
    new "行，咱们去吧。"

translate chinese chinese_3370470_154:
    old "I’m Beylaine, but you can call me Bey, and I’m the teacher who’s going to get you ready to take this year’s Music Contest crown."
    new "我是Beylaine，你可以叫我Bey，我是负责训练你们参加今年音乐比赛的老师。"

translate chinese chinese_7961069_155:
    old "Look around you. Every single person in this room has fire inside them."
    new "看看周围。这房间里每个人心里都有一团火。"

translate chinese chinese_1797493_156:
    old "Some of you know it, some of you are scared of it, some of you are still hiding it. My job? Pull that fire out and turn it into a supernova."
    new "你们有些人知道它，有些人害怕它，有些人还在隐藏它。我的工作就是把那团火拉出来，变成超新星。"

translate chinese chinese_4951309_157:
    old "From today until the final I’m your personal mentor, private feedback, whatever each of you needs to bring your absolute best act."
    new "从今天起直到最后，我将是你的私人导师，提供一对一的反馈，尽全力帮助你们发挥出最好的表现。"

translate chinese chinese_7131807_158:
    old "You’ll cry, you’ll laugh, you’ll hate me on Tuesdays and love me on Fridays, but by the final show you’ll thank me when the entire school is screaming your names."
    new "你会哭，你会笑，你会在周二讨厌我，在周五又爱我，但到了最后的演出，当全校都在喊你的名字时，你会感谢我的。"

translate chinese chinese_1657876_159:
    old "I'll be here for everything you need, we’re talking vocal technique, stage command, songwriting, harmonies, emotional truth, the whole package."
    new "我会在这里为你提供你需要的一切，无论是发声技巧、舞台掌控力、歌曲创作、和声还是情感表达，全部都包括在内。"

translate chinese chinese_5102762_160:
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 % yourself. Ready? Let’s make magic!"
    new "所以深呼吸，尽情享受，记住：舞台是唯一一个你可以完全做自己的地方。准备好了吗？让我们创造奇迹吧！"

translate chinese chinese_2187382_161:
    old "Hit it, darling!"
    new "来吧，亲爱的！"

translate chinese chinese_2318212_162:
    old "Let’s give them a show they’ll never forget!"
    new "让我们给他们来一场永生难忘的表演！"

translate chinese chinese_9134722_163:
    old "{i}We’re the headliners, baby, front page news!{/i}"
    new "{i}我们是头条新闻，宝贝，头版头条！{/i}"

translate chinese chinese_1235546_164:
    old "{i}Spotlights on us, no time to lose!{/i}"
    new "聚光灯照到我们了，没时间浪费了！"

translate chinese chinese_1796902_165:
    old "{i}Diamonds flashing, sequins bright!{/i}"
    new "{i}钻石闪耀，亮片璀璨！{/i}"

translate chinese chinese_8226814_166:
    old "{i}We own the stage every single night!{/i}"
    new "{i}我们每晚都掌控着舞台！{/i}"

translate chinese chinese_2735732_167:
    old "Y’all just brought Broadway to this classroom! Energy off the charts, synchronization tighter than my ponytail, costume game insane."
    new "你们把百老汇搬进了教室！能量爆表，同步性比我的马尾辫还紧，服装也超带感。"

translate chinese chinese_9587961_168:
    old "My only note: sometimes less is more. When every second is maximum sparkle, there’s nowhere left to go for the big moments. Save some glitter for the finale, babies. Otherwise? Flawless."
    new "我唯一的建议是：有时候少即是多。如果每一秒都闪耀到极点，到了关键时刻就没法再提升了。把一些闪亮点留到最后吧。否则的话，完美无缺。"

translate chinese chinese_3135740_169:
    old "Let’s remind them why we’re here."
    new "让我们提醒他们我们为什么来这里。"

translate chinese chinese_7776717_170:
    old "Exactly."
    new "没错。"

translate chinese chinese_5171557_171:
    old "{i}I’m feeling dangerous, feeling so brand new{/i}"
    new "感觉危险又新鲜"

translate chinese chinese_2429458_172:
    old "{i}Shaking off the dust, ready for round two{/i}"
    new "抖落灰尘，准备第二轮"

translate chinese chinese_5307722_173:
    old "{i}High notes climbing, watch me touch the sky{/i}"
    new "高音攀升，看我触摸天空"

translate chinese chinese_7186269_174:
    old "{i}Beat drops heavy, no more asking why!{/i}"
    new "{i}节奏低沉，不再追问！{/i}"

translate chinese chinese_0684897_175:
    old "Lord have mercy on my edges! Ariana, those whistle tones cleaner than my Sunday choir. Taylor, that belt could wake the dead."
    new "主啊，救救我的音域吧！阿丽安娜，那哨声般的高音比我的礼拜天合唱团还要清澈。泰勒，那穿透力能唤醒死人。"

translate chinese chinese_8372996_176:
    old "Pitch perfect, breath control insane, harmony game lethal."
    new "音准完美，气息控制惊人，和声致命。"

translate chinese chinese_6569154_177:
    old "My tiny note: sometimes perfection can feel safe. Next time risk a little crack, a little rawness. Vulnerability wins hearts. But technically? Untouchable."
    new "我的小贴士：有时候完美会让人感到安全。下次试着展现一点裂痕，一点真实。脆弱才能打动人心。但话说回来？还是那么不可侵犯。"

translate chinese chinese_4795166_178:
    old "Uhh... W- we didn’t really get a chance to rehearse..."
    new "呃……我们其实没机会排练……"

translate chinese chinese_6559652_179:
    old "Ugh, just give me the mic."
    new "唉，直接给我麦克风吧。"

translate chinese chinese_1995557_180:
    old "Oh my gosh, Billie... honey. That wasn’t singing. That was bleeding through music."
    new "天啊，比莉……宝贝。那根本不是唱歌。那是通过音乐在流血。"

translate chinese chinese_3783480_181:
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100%. Volume was whisper quiet, but somehow you filled the entire room."
    new "你的语气如同丝绒般柔软，措辞令人动容，情感真实度百分之百。声音轻得像耳语，却不知怎么的充满了整个房间。"

translate chinese chinese_0453174_182:
    old "Stage presence was nonexistent, lighting was wrong for that mood, and [pla]... sweetheart, you were a potted plant."
    new "舞台表现力全无，灯光也不对劲，而且[pla]……亲爱的，你就像一盆植物一样。"

translate chinese chinese_0341383_183:
    old "But the voice? The voice is once in a generation. We’re going to protect it, grow it, and teach it to roar when it needs to roar."
    new "但是那声音呢？那声音可是百年难遇的。我们要保护它，培养它，教会它在需要的时候咆哮。"

translate chinese chinese_8055468_184:
    old "[pla], next time you move, you breathe with her, you support her. Deal?"
    new "[pla]，下次你动的时候，要跟着她的呼吸，支持她。 deal?"

translate chinese chinese_2823532_185:
    old "Uhh... Y- yeah sure."
    new "呃……好啦好啦。"

translate chinese chinese_8414988_186:
    old "Well, I have goosebumps from head to toe. Three completely different universes in one room."
    new "好吧，我从头到脚都起鸡皮疙瘩了。一个房间里竟然有三个完全不同的宇宙。"

translate chinese chinese_0613854_187:
    old "Sharpay & Ryan: spectacle and precision. Ariana & Taylor: vocal olympics. Billie & [pla]: pure soul."
    new "Sharpay & Ryan：精彩与精准。Ariana & Taylor：声乐奥运会。Billie & [pla]：纯粹的灵魂。"

translate chinese chinese_1178148_188:
    old "Next sessions we start real work: breathing, dynamics, choreography, song choice, storytellin, everyone gets one-on-one time with me."
    new "下几次我们会开始真正的训练：呼吸、动态、编舞、选歌、讲故事，每个人都会有一对一跟我练习的时间。"

translate chinese chinese_3366511_189:
    old "Because every single one of you can win this thing. I’m not here to pick favorites; I’m here to make favorites out of all of you."
    new "因为你们每个人都有能力赢得这个东西。我来这里不是为了偏袒任何人；我是来让你们每个人都成为优胜者的。"

translate chinese chinese_9624774_190:
    old "Go home, rest those voices, dream big, and come back hungry. See you at the next session!"
    new "回家好好休息，多做梦想，下次来时充满干劲。下次见！"

translate chinese chinese_1211603_191:
    old "Wow, Billie, did you hear everything she was saying about your voice?"
    new "哇，比莉，你听到她说关于你的声音的话了吗？"

translate chinese chinese_6891145_192:
    old "Yeah, yeah, Anyway. I did the one practice. We’re done."
    new "好吧好吧，总之。我做了那个练习。我们搞定啦。"

translate chinese chinese_9409686_193:
    old "W- what? Are you serius? You were unbelievable—"
    new "什、什么？你是认真的？你简直太棒了—"

translate chinese chinese_1523286_194:
    old "Unbelievable is right. Unbelievably depressing."
    new "真不可思议。简直让人沮丧透了。"

translate chinese chinese_3003988_195:
    old "What was that, a lullaby for the dead?"
    new "那是什么，死人的摇篮曲吗？"

translate chinese chinese_8379651_196:
    old "Volume exists for a reason, sweetie. The back row couldn’t hear a thing."
    new "音量是有原因的，甜心。后排的人什么都没听到。"

translate chinese chinese_3326380_197:
    old "Oh, wait, is this the girl who whispered her whole song? Heh"
    new "哦，等下，这是那个全程 whisper singing 的女孩吗？嘿嘿"

translate chinese chinese_7390294_198:
    old "I thought someone forgot to plug in the mic, hahaha."
    new "我还以为有人忘了插麦克风呢，哈哈。"

translate chinese chinese_5576639_199:
    old "Exactly. Bedroom sad girl vibes don’t win contests, sweetie."
    new "没错。卧室里的忧郁气息可不会赢得比赛，甜心。"

translate chinese chinese_5760769_200:
    old "We’re trying to make people dance, not cry."
    new "我们是想让人跳舞，不是哭。"

translate chinese chinese_7662488_201:
    old "Yeah, save the therapy session for TikTok."
    new "yeah, 把心理咨询 session 留给 TikTok 吧。"

translate chinese chinese_7447276_202:
    old "Hey, that’s enough—"
    new "喂，够了——"

translate chinese chinese_9873394_203:
    old "Oh, and her backup tree finally speaks!"
    new "哦，她的备用树角色终于开口了！"

translate chinese chinese_0836175_204:
    old "What did you contribute, [pla]? Standing there like a scared statue?"
    new "你贡献了什么，[pla]？就像个吓坏的雕像一样站在那里？"

translate chinese chinese_0279955_205:
    old "Cute support system. Zero talent, zero movement."
    new "可爱的辅助系统。零才能，零行动力。"

translate chinese chinese_9617051_206:
    old "Maybe both of you should just quit now."
    new "也许你们俩现在就该放弃。"

translate chinese chinese_2958439_207:
    old "Hey, we are not-"
    new "喂，我们不是-"

translate chinese chinese_8354231_208:
    old "You know what’s funny?"
    new "你知道什么好笑吗？"

translate chinese chinese_5696475_209:
    old "You three spend twenty minutes jumping and screaming so hard nobody can even remember the melody."
    new "你们三个跳了二十分钟，尖叫得连旋律都记不住了。"

translate chinese chinese_6071777_210:
    old "But sure, tell me my quiet voice is the problem."
    new "好吧，你说我声音太轻是问题吧。"

translate chinese chinese_4611768_211:
    old "And [pla] standing still? At least he’s not faking it with glitter and fake smiles."
    new "而且[pla]还站在那里不动？至少他没有用闪光粉和假笑来装模作样。"

translate chinese chinese_9260956_212:
    old "It’s kinda cute how you go all out screaming and dancing just to get a little attention."
    new "你为了博取一点关注就大喊大叫、又唱又跳的样子还挺可爱的。"

translate chinese chinese_3910214_213:
    old "But volume isn’t talent, sweetie, glitter isn’t personality..."
    new "但是音量不代表才华，亲爱的，闪光不代表个性..."

translate chinese chinese_7281584_214:
    old "And sequins don’t hide the fact you’re all noise and no soul."
    new "而且亮片也掩盖不了你这个人华而不实的事实。"

translate chinese chinese_2750096_215:
    old "See you in the final, girls."
    new "决赛见了，姑娘们。"

translate chinese chinese_1466219_216:
    old "Try not to choke when someone actually feels something."
    new "有人真的对你有感觉时，别紧张。"

translate chinese chinese_8027785_217:
    old "And that's how it's done."
    new "就是这样做的。"

translate chinese chinese_6014707_218:
    old "Hey Billie, wait!"
    new "喂，比莉，等一下！"

translate chinese chinese_5603810_219:
    old "Are you okay?"
    new "你还好吗？"

translate chinese chinese_5975503_220:
    old "Yeah, that was nothing. They’re just a bunch of idiots."
    new "yeah,那根本不算什么。他们就是一群白痴。"

translate chinese chinese_5319069_221:
    old "Yeah, you’re right. But the way you shut them down? Damn, that was epic. I’ll never forget their faces haha."
    new "没错，你这么对付他们，真是够绝的。他们的表情我一辈子都忘不了哈哈。"

translate chinese chinese_2477347_222:
    old "And what was that about seeing them in the finals? I thought you were dropping out after the audition... like you said."
    new "说看到他们在决赛中是什么意思？我以为你试镜后就要退出了……就像你说的那样。"

translate chinese chinese_7951595_223:
    old "Drop out?"
    new "退学？"

translate chinese chinese_4823308_224:
    old "Please. After that little circus?"
    new "拜托。经过那场小马戏之后？"

translate chinese chinese_6992178_225:
    old "I’m not giving them the satisfaction."
    new "我不会给他们这个满足感的。"

translate chinese chinese_2714464_226:
    old "So you’re staying?"
    new "所以你留下来了？"

translate chinese chinese_4678149_227:
    old "Yeah, I’m staying."
    new "是的，我留下。"

translate chinese chinese_3241751_228:
    old "And we’re winning."
    new "而且我们赢了。"

translate chinese chinese_6229713_229:
    old "Wait, for real?"
    new "等下， seriously？"

translate chinese chinese_3694053_230:
    old "Dead serious. You wanted me in this mess? Congratulations."
    new "说真的，你想要我陷入这种烂摊子？恭喜你。"

translate chinese chinese_2725997_231:
    old "Now we’re doing it my way. Every day. No excuses."
    new "现在按我的方式来。每天。没有借口。"

translate chinese chinese_1277132_232:
    old "Come to my place so we can start rehearsing and get ready."
    new "来我家开始排练，做好准备。"

translate chinese chinese_6045127_233:
    old "Of course I will!"
    new "我当然会！"

translate chinese chinese_3204745_234:
    old "Alright. I’ll see you later, then."
    new "好吧，那回头见。"

translate chinese chinese_2736598_235:
    old "S- sure, see you later."
    new "好，再见。"

translate chinese chinese_5303143_236:
    old "({i}Holy crap... she’s actually doing it.{/i})"
    new "({i}天啊……她真的做了。{/i})"

translate chinese chinese_9142045_237:
    old "I seriously did not think she was gonna say yes."
    new "我真的没想到她会答应。"

translate chinese chinese_6807836_238:
    old "Like... damn, she walked out of here looking way more motivated than I expected."
    new "就像……靠，她走出去的时候看起来比我想的要积极多了。"

translate chinese chinese_2206712_239:
    old "Heh, I guess I owe part of that to those bullies running their mouths earlier."
    new "嘿嘿，我想那部分要归功于刚才那些混蛋的闲话。"

translate chinese chinese_9868805_240:
    old "If they hadn’t pushed her buttons, she’d never have agreed that fast."
    new "如果不是他们故意激她，她绝不会那么快就同意的。"

translate chinese chinese_9043611_241:
    old "Phew... okay... okay, that’s one problem solved."
    new "呼……好……好，这个问题解决了。"

translate chinese chinese_3651209_242:
    old "({i}Now there’s the other problem.{/i})"
    new "({i}现在又有另一个问题了。{/i})"

translate chinese chinese_8507025_243:
    old "What the hell am I supposed to do in a music contest when I know absolutely nothing about music?"
    new "我完全不懂音乐，在音乐比赛中我该怎么办？"

translate chinese chinese_0115327_244:
    old "Oh man... this is gonna be a disaster."
    new "哦 man... 这下要完蛋了。"

translate chinese chinese_4362901_245:
    old "({i}Yeah... I’m so screwed.{/i})"
    new "({i}嗯……我这下完了。{/i})"

translate chinese chinese_6327401_246:
    old "Took you long enough."
    new "你可真慢。"

translate chinese chinese_7518285_247:
    old "Hey, sorry. Got caught up with stuff."
    new "嘿，对不起。我有点忙过了头。"

translate chinese chinese_2576290_248:
    old "Whatever. Come in, grandma’s out."
    new "随便吧。进来吧，奶奶出去了。"

translate chinese chinese_1200668_249:
    old "O- ok..."
    new "好……"

translate chinese chinese_7367207_250:
    old "Alright, Before we dive in, what do you know about music?"
    new "好吧，在我们开始之前，你对音乐了解多少？"

translate chinese chinese_4917837_251:
    old "Uhh... I can tell when a song’s good?"
    new "呃……我能听出一首歌好不好？"

translate chinese chinese_2431502_252:
    old "That’s it? No instruments? No singing lessons?"
    new "就这些？不用乐器？不去唱歌课？"

translate chinese chinese_2822723_253:
    old "Uhh nope. Closest I got was humming in the shower."
    new "呃，没有。最接近的就是洗澡时哼歌了。"

translate chinese chinese_3278889_254:
    old "Hmph, great start."
    new "哼，真是个好开头。"

translate chinese chinese_9428184_255:
    old "Okay. We’re trying everything today. Voice, rhythm, keys. See what sticks to your zero skills."
    new "好吧。今天我们什么都试试。声音、节奏、按键。看看哪一样能对你的零技能起作用。"

translate chinese chinese_1903381_256:
    old "Everything?"
    new "一切？"

translate chinese chinese_1656804_257:
    old "Yes, we’re gonna find something you don’t completely suck at."
    new "没错，我们要找到你不是完全不行的事情。"

translate chinese chinese_7416925_258:
    old "I’m your coach now. And it’s gonna be brutal, because we’re winning this thing."
    new "我现在是你的教练了。而且这会很残酷，因为我们一定要赢。"

translate chinese chinese_3490911_259:
    old "No mercy, no excuses. You wanted me in? Now you’re in all the way."
    new "没有怜悯，没有借口。你想让我参与？现在你就彻底进来了。"

translate chinese chinese_1524473_260:
    old "No pressure then."
    new "那就不着急了。"

translate chinese chinese_4637060_261:
    old "All the pressure. We’re winning this, so get ready to sweat."
    new "压力山大。我们要赢了，准备好出力吧。"

translate chinese chinese_6312432_262:
    old "*Gulp*..."
    new "*咕噜*..."

translate chinese chinese_2930633_263:
    old "Ok, voice first. Easiest to test."
    new "好的，先试声音。最简单了。"

translate chinese chinese_0376711_264:
    old "Repeat after me, same melody."
    new "跟我重复，同样的旋律。"

translate chinese chinese_0813808_265:
    old "Your turn."
    new "该你了。"

translate chinese chinese_7011473_266:
    old "Jesus Christ. Were you aiming for every wrong note?"
    new "天啊。你是故意弹错的吗？"

translate chinese chinese_7060066_267:
    old "I told you I can’t sing..."
    new "我跟你说过我不会唱歌..."

translate chinese chinese_0250447_268:
    old "Come on, try again. Feel the words."
    new "来吧，再试一次。感受这些话语。"

translate chinese chinese_1997680_269:
    old "Hmm, that wasn’t singing, that was a hate crime against music."
    new "哼，那不是唱歌，那是音乐的仇恨犯罪。"

translate chinese chinese_1629342_270:
    old "I’ve never had lessons, okay?"
    new "我从来没上过课，好吧？"

translate chinese chinese_3313020_271:
    old "Noted. Voice is a disaster. Moving on."
    new "记住了。声音一团糟。继续吧。"

translate chinese chinese_3779154_272:
    old "Keyboard. C major scale. Slow and clean."
    new "键盘。C大调音阶。慢且清晰。"

translate chinese chinese_2951613_273:
    old "I think I can do piano... kind of."
    new "我觉得我差不多会弹钢琴……吧。"

translate chinese chinese_7075526_274:
    old "Great! You just played a car alarm."
    new "太好了，你刚才按了汽车报警器。"

translate chinese chinese_6853875_275:
    old "My fingers won’t cooperate."
    new "我的手指不听使唤。"

translate chinese chinese_7168342_276:
    old "Your fingers have the coordination of drunk spaghetti."
    new "你的手指协调性跟醉汉拌的 spaghetti 一样。"

translate chinese chinese_7958478_277:
    old "I’ve never touched a piano in my life..."
    new "我这辈子都没碰过钢琴……"

translate chinese chinese_0310531_278:
    old "Clearly, try again."
    new "说清楚点，再试一次。"

translate chinese chinese_2842174_279:
    old "Wrong finger. Index, not pinky."
    new "错了，是食指，不是小指。"

translate chinese chinese_3984174_280:
    old "Sorry, I guess I don’t have much finger dexterity."
    new "抱歉，我想我的手指灵活性不是很好。"

translate chinese chinese_0858573_281:
    old "Oh? No practice with the fingers, huh?"
    new "哦？手指不过关吗？"

translate chinese chinese_7741759_282:
    old "Hey!"
    new "喂！"

translate chinese chinese_8981414_283:
    old "Just saying. You’ve got zero practice to do... in a lot of areas."
    new "就是说说。你有很多方面都没练习过……"

translate chinese chinese_9020085_284:
    old "This is humiliating."
    new "这真是丢脸。"

translate chinese chinese_2278544_285:
    old "You´re right. Keyboard out. Next one."
    new "你说得对。换下一个。"

translate chinese chinese_2313851_286:
    old "Ok, let's try with congas. Hands only. Feel the groove."
    new "好吧，我们试试用康加鼓吧。只用手。感受一下节奏。"

translate chinese chinese_1283948_287:
    old "Four simple beats. One-two-three-four. Like a heartbeat."
    new "四个简单的节拍。一二三四。就像心跳一样。"

translate chinese chinese_4785905_288:
    old "I got this."
    new "我来搞定。"

translate chinese chinese_9182253_289:
    old "You're rushing a little... No problem. Try again."
    new "你急了一点……没关系。再试一次。"

translate chinese chinese_4583090_290:
    old "Uhh ok..."
    new "呃，好吧……"

translate chinese chinese_2546678_291:
    old "Hmm, you’re dragging a little now."
    new "嗯，你现在有点拖拖拉拉了。"

translate chinese chinese_6677791_292:
    old "All good, here we go."
    new "一切就绪，开始吧。"

translate chinese chinese_0448686_293:
    old "No, not quite my tempo."
    new "不，这节奏不太对。"

translate chinese chinese_3239374_294:
    old "What does that even—"
    new "这到底是什么意思——"

translate chinese chinese_5004852_295:
    old "Uhh... I... I d- don’t kn-"
    new "呃……我……我真不……"

translate chinese chinese_3211642_296:
    old "Tell me are you a rusher, are you a dragger, or are you going to be ON MY FUCKING TIME!?"
    new "告诉我，你是急先锋，还是拖拖拉拉的，还是打算按我妈的节奏来！？"

translate chinese chinese_1030390_297:
    old "W- what?!"
    new "什、什么?!"

translate chinese chinese_8611521_298:
    old "Ugh... Nevermind. Mostly. Rhythm is dead."
    new "唉……算了吧。基本上是这样。Rhythm死了。"

translate chinese chinese_6742217_299:
    old "This is pointless. I suck at everything."
    new "这根本没用。我什么都做不好。"

translate chinese chinese_1528143_300:
    old "I’m just gonna embarrass you in front of the whole school."
    new "我就是要在全校面前让你出丑。"

translate chinese chinese_4285049_301:
    old "I’m dragging you down. You saw those girls. They’re pros."
    new "我在拖你的后腿。你看到那些女孩了，她们是专业人士。"

translate chinese chinese_6081772_302:
    old "I’m the weak link. Maybe you should just go solo."
    new "我是薄弱环节。也许你应该一个人行动。"

translate chinese chinese_2994026_303:
    old "Are you quitting on me right now?"
    new "你现在要放弃我吗？"

translate chinese chinese_3660711_304:
    old "I’m just being realistic."
    new "我只是实事求是而已。"

translate chinese chinese_6164229_305:
    old "I don’t want to be the reason you lose."
    new "我不想成为你失败的原因。"

translate chinese chinese_0109782_306:
    old "You’re the reason I’m even doing this."
    new "要不是为了你，我才不会做这件事呢。"

translate chinese chinese_5989401_307:
    old "You pushed me. Remember? 'You’ve got talent, don’t hide it.' Ring a bell?"
    new "你推了我。忘了？你说过“你有才华，不要藏起来。”还记得吗？"

translate chinese chinese_2356754_308:
    old "So no. You don’t get to bail when it’s your turn."
    new "所以不行。轮到你的时候不能逃避。"

translate chinese chinese_0266619_309:
    old "That’s different. You’re actually good."
    new "那不一样，你真的很棒。"

translate chinese chinese_6278206_310:
    old "I wasn’t always. And I’m not doing this alone."
    new "我以前不是这样的。而且我不是一个人在做这件事。"

translate chinese chinese_5183274_311:
    old "But I’m useless."
    new "但我一点用都没有。"

translate chinese chinese_3327700_312:
    old "You’re not useless. You’re untrained. And I’m fixing that."
    new "你不是没用，只是没受过训练。我会帮你改正的。"

translate chinese chinese_3434808_313:
    old "This is gonna be tough... I mean, I basically suck at everything."
    new "这会很困难……我的意思是，我基本上什么都不擅长。"

translate chinese chinese_6095692_314:
    old "Hmm, maybe not at everything. Wait here."
    new "嗯，也许不是每件事都行。在这等一下。"

translate chinese chinese_1061257_315:
    old "This was my dad’s."
    new "这是我爸的。"

translate chinese chinese_8545471_316:
    old "Whoa..."
    new "谁啊……"

translate chinese chinese_5025235_317:
    old "He taught me my first chords on this."
    new "他就是用这个教我弹第一个和弦的。"

translate chinese chinese_8617642_318:
    old "Now it’s yours to borrow."
    new "现在你可以借用了。"

translate chinese chinese_7516984_319:
    old "Ohh.. I- I’ll be careful."
    new "哦……我我會小心的。"

translate chinese chinese_0077485_320:
    old "You better. If you break it, I break you."
    new "最好别弄坏，否则我让你好看。"

translate chinese chinese_8858279_321:
    old "Noted."
    new "收到。"

translate chinese chinese_1280780_322:
    old "We’ll start with three chords. Easiest thing in the world."
    new "我们从三个和弦开始。世界上最简单的事情。"

translate chinese chinese_0375363_323:
    old "You’re gonna learn them. Even if I have to sit on you."
    new "你得学会这些。哪怕我得坐在你身上逼你学。"

translate chinese chinese_5846156_324:
    old "That’s... motivational?"
    new "那……算是励志的？"

translate chinese chinese_2011146_325:
    old "Damn right it is."
    new "没错，就是这样。"

translate chinese chinese_7611400_326:
    old "Alright. Before we even start real lessons, you need to get familiar with that guitar."
    new "好吧。在正式上课之前，你需要先熟悉那把吉他。"

translate chinese chinese_5727621_327:
    old "Yeah, I figured. But, what should I actually do with it?"
    new "嗯，我明白。但是，我到底该怎么用它呢？"

translate chinese chinese_3503633_328:
    old "Well, familiarize yourself with the strings, stop poking the guitar like it’s a wild animal."
    new "好吧，熟悉一下这些弦，别像对待野生动物一样戳吉他。"

translate chinese chinese_7112094_329:
    old "And please! Use your fingers. Right now they move like you borrowed them from a mannequin."
    new "而且请用你的手指。现在它们动起来就像从模特身上借来的一样。"

translate chinese chinese_4609244_330:
    old "Come on, they’re not that bad..."
    new "得了，也没那么糟……"

translate chinese chinese_4761572_331:
    old "Relly? You need agility. Flexibility. Some kind of life in those fingers."
    new "真的吗？你需要敏捷性。灵活性。手指得有点活力。"

translate chinese chinese_1496300_332:
    old "Okay, so... practice the strings? Just messing around with them?"
    new "好吧，那么……练习下琴弦？就随便玩玩？"

translate chinese chinese_2793969_333:
    old "Exactly. Touch them, get used to the tension, the spacing, the feel."
    new "没错。摸摸它们，适应那种紧张感、间距和感觉。"

translate chinese chinese_3215025_334:
    old "Learn what each string does when you press it... without crying."
    new "按下每个字符串时学会它们的作用……不要哭。"

translate chinese chinese_9519102_335:
    old "Well, I can do that."
    new "好吧，我可以做到。"

translate chinese chinese_0786792_336:
    old "Good. Because in your current state, I can’t teach you anything yet."
    new "好。因为你现在这个状态，我还教不了你什么。"

translate chinese chinese_5058032_337:
    old "That bad, huh?"
    new "这么糟糕吗？"

translate chinese chinese_2939882_338:
    old "Let’s just say your dexterity is... nonexistent."
    new "咱们就说你的灵巧度是……不存在的。"

translate chinese chinese_3977314_339:
    old "Which tells me you haven’t used those fingers for anything interesting."
    new "这说明你还没用那些手指干过什么有趣的事。"

translate chinese chinese_8468458_340:
    old "H- hey..."
    new "喂……"

translate chinese chinese_0238867_341:
    old "Point is: practice. Move your fingers up and down the strings. Build some coordination."
    new "关键是练习。上下拨动琴弦。培养一下协调性。"

translate chinese chinese_0175521_342:
    old "Alright. I’ll work on that."
    new "好吧，我会处理的。"

translate chinese chinese_9833081_343:
    old "And once your hands stop embarrassing me, come back."
    new "等你的手不让我尴尬了再回来。"

translate chinese chinese_0956861_344:
    old "Ok, ok, got it."
    new "好啦好啦，知道了。"

translate chinese chinese_1794123_345:
    old "Good. But for today, we’re done."
    new "好。但今天就到此为止吧。"

translate chinese chinese_9868923_346:
    old "Already?"
    new "已经了吗？"

translate chinese chinese_4349385_347:
    old "Yeah. You should leave before my grandma shows up."
    new "是啊。你最好在我奶奶出现前离开。"

translate chinese chinese_6367305_348:
    old "W-what? Why?"
    new "什、什么？为什么？"

translate chinese chinese_8704302_349:
    old "I don’t want her finding me here with all these instruments and with you."
    new "我不希望她发现我在这里，身边摆着这些东西，还有你。"

translate chinese chinese_0987708_350:
    old "She’ll think I’m getting back into music."
    new "她会以为我要重新回到音乐圈。"

translate chinese chinese_1925142_351:
    old "But... what’s wrong with that?"
    new "但是……那样有什么不对吗？"

translate chinese chinese_4487593_352:
    old "Not your problem. Don’t dig into it."
    new "不关你的事。别多管闲事。"

translate chinese chinese_7590834_353:
    old "Alright... Alright."
    new "好吧... 好吧。"

translate chinese chinese_6903227_354:
    old "So practice. When you're actually ready, come find me."
    new "那就练习吧。等你真的准备好了，来找我。"

translate chinese chinese_7482861_355:
    old "I will. I’ll get better and I’ll be back soon."
    new "我会的。我会变强，很快就会回来。"

translate chinese chinese_9140280_356:
    old "It’s really late now, I should leave guitar practice for tomorrow."
    new "现在已经很晚了，我把吉他练习留到明天吧。"

translate chinese chinese_7785450_357:
    old "I’d better let my fingers rest a bit, or they’re gonna start bleeding..."
    new "我最好让手指休息一下，不然它们就要出血了……"

translate chinese chinese_1788923_358:
    old "Okay... here we go. First time ever touching a real guitar."
    new "好吧……开始了。第一次摸到真正的吉他。"

translate chinese chinese_9676736_359:
    old "This thing’s heavier than it looks."
    new "这东西比看起来重多了。"

translate chinese chinese_0030716_360:
    old "And it smells like old wood... it’s nice though."
    new "而且闻起来像旧木头……不过挺不错的。"

translate chinese chinese_5633367_361:
    old "Alright... let’s see if those YouTube videos helped at all."
    new "好吧……看看那些YouTube视频有没有帮上忙。"

translate chinese chinese_9572353_362:
    old "Watched like three tutorials last night. How hard can open chords be?"
    new "昨晚看了好几个教程。开放和弦有那么难吗？"

translate chinese chinese_5620410_363:
    old "Ow! That buzzed like a dying bee."
    new "哎哟！那感觉就像一只垂死的蜜蜂在嗡嗡叫。"

translate chinese chinese_8311151_364:
    old "Strings hurt more than I expected."
    new "这些话比预期的还要伤人。"

translate chinese chinese_3809370_365:
    old "Let’s try again... second fret, second string... mute the others..."
    new "我们再试一次……第二品，第二弦……其他弦消音……"

translate chinese chinese_3484199_366:
    old "Why do my fingers feel like drunk spaghetti? It´s just like [bil] said."
    new "为什么我的手指感觉像醉汉的意大利面？就像[bil]说的一样。"

translate chinese chinese_9541505_367:
    old "One chord. ONE chord. Come on, [pla]."
    new "一个和弦。就一个和弦。快点，[pla]。"

translate chinese chinese_9392501_368:
    old "I’m literally the worst guitarist in history. Zero dexterity."
    new "我可能是有史以来最烂的吉他手了。完全没技巧。"

translate chinese chinese_8929838_369:
    old "She’s gonna murder me if I don’t improve."
    new "如果我不改进，她会杀了我的。"

translate chinese chinese_4879732_370:
    old "({i}But I’m not quitting. Not after she trusted me with this guitar.{/i})"
    new "(但我不会放弃的。不会在她把这把吉他托付给我之后。)"

translate chinese chinese_0418968_371:
    old "I have to keep practicing."
    new "我得继续练习。"

translate chinese chinese_1010846_372:
    old "Okay... that one almost sounded like an actual chord."
    new "好吧……那个几乎听起来像一个真正的和弦了。"

translate chinese chinese_0946664_373:
    old "Progress! Tiny, painful progress."
    new "有进展！虽然只是微小且痛苦的进展。"

translate chinese chinese_8375929_374:
    old "Enough for today. Fingers are officially dead."
    new "今天够了。手指正式罢工了。"

translate chinese chinese_9118010_375:
    old "Tomorrow I’ll be slightly less terrible."
    new "明天我会稍微好一点。"

translate chinese chinese_3762579_376:
    old "Okay, even if it’s tough, I’ve gotta keep practicing. I need to get better at guitar or Billie’s gonna kill me."
    new "好吧，即使很难，我也得继续练习。我得把吉他练好，不然Billie会杀了我的。"

translate chinese chinese_3389857_377:
    old "My fingers are still sore from last time. Awesome."
    new "上次之后我的手指还疼呢。太棒了。"

translate chinese chinese_3925412_378:
    old "Sigh... let’s try this again."
    new "sigh... 好吧，我们再试一次。"

translate chinese chinese_1623503_379:
    old "Still buzzing on the high E. Damn it!"
    new "还在高音E上回荡。该死！"

translate chinese chinese_1303159_380:
    old "Left hand cramps, right hand can’t keep time."
    new "左手抽筋，右手跟不上节奏。"

translate chinese chinese_3380438_381:
    old "Come on, come on, again."
    new "来吧，再来一次。"

translate chinese chinese_1414768_382:
    old "Rhythm’s all over the place. Why can’t I get this?"
    new "节奏完全乱了。为什么我做不到？"

translate chinese chinese_6042648_383:
    old "I thought I’d be better by now. This is torture."
    new "我以为我现在会好些的。这简直就是折磨。"

translate chinese chinese_6286644_384:
    old "({i}She’s probably nailing everything while I’m stuck here.{/i})"
    new "(她在那边肯定忙得不可开交，而我却困在这里。)"

translate chinese chinese_0116714_385:
    old "Hmm, one more run through. Clean changes or bust."
    new "嗯，再试一次。要么干净利落，要么就不干。"

translate chinese chinese_6652131_386:
    old "Nope. Still sounds like crap."
    new "不行，听起来还是糟透了。"

translate chinese chinese_9403624_387:
    old "Fingers raw, brain fried, and zero improvement."
    new "手指磨破了，脑子也混乱了，却一点进步都没有。"

translate chinese chinese_5769840_388:
    old "That’s it for now. Can’t force it."
    new "就这样吧，不能强求。"

translate chinese chinese_5122422_389:
    old "Tomorrow. Maybe it’ll click tomorrow."
    new "明天吧。也许明天就会有感觉了。"

translate chinese chinese_9996911_390:
    old "I’m not getting anywhere on my own. This isn’t working."
    new "我自己根本没办法进展。这样下去不行。"

translate chinese chinese_5984912_391:
    old "({i}I need help. [bil]’s the only one who can teach me.{/i})"
    new "({i}我需要帮助。只有[bil]能教我。{/i})"

translate chinese chinese_5323818_392:
    old "Time to text her. Can’t stay stuck forever."
    new "该给她发短信了。不能一直这么僵下去。"

translate chinese chinese_8517967_393:
    old "That’s it for today. Tomorrow, I’m going to her."
    new "今天就到这里。明天我就去找她。"

translate chinese chinese_0458549_394:
    old "Hey, you look like someone kicked your puppy."
    new "嘿，你看起来像是有人踢了你的小狗。"

translate chinese chinese_8286797_395:
    old "You texted like the world was ending. What's up?"
    new "你短信发得跟世界末日似的，怎么了？"

translate chinese chinese_5527884_396:
    old "It's the guitar. I tried... really tried."
    new "是吉他。我试过了……真的试过了。"

translate chinese chinese_0436244_397:
    old "And?"
    new "然后呢？"

translate chinese chinese_8747564_398:
    old "Nothing. Fingers won't move right, everything buzzes. I'm stuck."
    new "没什么。手指不听使唤，一切都嗡嗡作响。我动不了了。"

translate chinese chinese_3975045_399:
    old "Stuck over just a couple of days? That’s dramatic."
    new "就因为几天而已就卡住了？这也太夸张了吧。"

translate chinese chinese_7309089_400:
    old "I'm serious. YouTube videos, hours... still crap."
    new "我是认真的。YouTube视频，看了好几个小时……还是不行。"

translate chinese chinese_4212642_401:
    old "Okay, okay. Let's fix it. Room. Now."
    new "好啦好啦，我们去房间里解决。现在。"

translate chinese chinese_4944189_402:
    old "Okay, spill. What exactly did you try?"
    new "好吧，说吧。你到底试了什么？"

translate chinese chinese_5138866_403:
    old "Well, I watched videos, did the finger positions, strummed, practiced for hours... and still nothing."
    new "好吧，我看了视频，做了手指的位置，拨弦，练习了几个小时……还是不行。"

translate chinese chinese_8125694_404:
    old "Okay, relax. You’re not hopeless, just untrained."
    new "好吧，别紧张。你不是没希望，只是没训练过。"

translate chinese chinese_7831817_405:
    old "Hmm, I feel hopeless."
    new "嗯，我觉得好无力。"

translate chinese chinese_4542182_406:
    old "Well, it does at first. That's normal. We'll figure it out."
    new "嗯，一开始是这样的。这是正常的。我们会解决的。"

translate chinese chinese_4393516_407:
    old "Really?"
    new "真的吗？"

translate chinese chinese_2372562_408:
    old "Yeah. I'm your coach. Brutal, but we'll get you there."
    new "没错。我是你的教练。虽然严厉，但我会帮你达到目标的。"

translate chinese chinese_0707915_409:
    old "First, let me show you how it's done. Watch."
    new "首先，让我示范一下。看着。"

translate chinese chinese_9397168_410:
    old "Holy... you're amazing."
    new "holy... 你太棒了。 \n\nNote: \"Holy\" is kept as is since it's a mild exclamation often left untranslated."

translate chinese chinese_2764115_411:
    old "It looks so easy when you do it."
    new "你看起来做得这么轻松。"

translate chinese chinese_3709912_412:
    old "It’s just practice. Your turn."
    new "这只是练习。轮到你了。"

translate chinese chinese_8169685_413:
    old "Uhh, like... this?"
    new "呃，像……这样？"

translate chinese chinese_9635606_414:
    old "Buzzing. Press harder on the strings."
    new "嗡嗡响。再用力按弦。"

translate chinese chinese_2793326_415:
    old "Ow... got it."
    new "哦……明白了。"

translate chinese chinese_8174591_416:
    old "Better. Still ugly, but better."
    new "好些了。还是丑，但好些了。"

translate chinese chinese_3315085_417:
    old "Try shifting your hand a bit. Find a spot that actually sounds alive."
    new "试着动一下手，找一个听起来有反应的地方。"

translate chinese chinese_5399564_418:
    old "Switching... crap."
    new "切换中……糟糕。"

translate chinese chinese_8307905_419:
    old "Slow. Don't rush the change."
    new "慢点。不要急于改变。"

translate chinese chinese_5914180_420:
    old "It's like my fingers hate me."
    new "感觉我的手指都在跟我作对。"

translate chinese chinese_1195676_421:
    old "They're lazy. Make 'em work."
    new "他们很懒。让他们工作去。"

translate chinese chinese_2250552_422:
    old "Like this...."
    new "就这样......"

translate chinese chinese_2611481_423:
    old "No, you're not covering the strings properly."
    new "不，你没有正确覆盖琴弦。"

translate chinese chinese_4163645_424:
    old "Closer. But your fingers are stiff as boards."
    new "再靠近点。不过你的手指僵得像木头一样。"

translate chinese chinese_3176489_425:
    old "Yeah... no dexterity."
    new "嗯……完全没有灵巧。"

translate chinese chinese_7738073_426:
    old "Reset your hand. Try the last position. Light touch, then press."
    new "把手复位。试试上次的位置。轻轻触碰，然后按压。"

translate chinese chinese_6777663_427:
    old "Uhh okay..."
    new "嗯好吧……"

translate chinese chinese_6469573_428:
    old "I- I can't. This is stupid."
    new "我——我做不到。这太蠢了。"

translate chinese chinese_1464028_429:
    old "You're wasting your time with me."
    new "你在浪费时间。"

translate chinese chinese_3011293_430:
    old "You know what? I should probably go."
    new "你知道吗？我可能该走了。"

translate chinese chinese_0019878_431:
    old "No."
    new "不。"

translate chinese chinese_3164603_432:
    old "B- but-"
    new "b-但是-"

translate chinese chinese_0728431_433:
    old "You're frustrated. I get it."
    new "你很沮丧。我明白。"

translate chinese chinese_1559762_434:
    old "I suck. Completely."
    new "我真的一点都不行。"

translate chinese chinese_9171390_435:
    old "You don't suck. It's hard. Not everyone even tries."
    new "你还不赖。这很难。不是每个人都会尝试的。"

translate chinese chinese_1008338_436:
    old "I know... but I’m failing so bad."
    new "我知道……但我做得真的很差。"

translate chinese chinese_4452471_437:
    old "Trying and failing is braver than not trying at all."
    new "尝试并失败比完全不去尝试要勇敢得多。"

translate chinese chinese_5873300_438:
    old "Feels like I'm just letting you down."
    new "感觉我在让你失望。"

translate chinese chinese_7164153_439:
    old "You’re not. You’re working hard, and that means a lot."
    new "你不是。你很努力，这很重要。"

translate chinese chinese_8724197_440:
    old "But I have no talents. Zero. I'm good at... existing?"
    new "但我没什么特长。一点都没有。我擅长的就只是……存在吗？"

translate chinese chinese_9755247_441:
    old "What do you mean you have no talents? Now you’re just being an idiot, you’ve got plenty."
    new "你说你没什么特长？你现在这是装傻吧，你有的是特长。"

translate chinese chinese_4254624_442:
    old "You're friendly. Always helping everyone, even when it's inconvenient."
    new "你很友好。总是帮助每个人，即使不方便也一样。"

translate chinese chinese_9212145_443:
    old "I guess..."
    new "我猜..."

translate chinese chinese_7278814_444:
    old "Stubborn too. Look at this, we wouldn’t even be in this mess if you hadn’t pushed and pushed, even when I almost hit you."
    new "真是固执。你看，如果不是你一直逼我，甚至在我差点打你的时候还逼我，我们现在也不会陷入这种困境。"

translate chinese chinese_2345873_445:
    old "Yeah, but that backfired."
    new "是啊，但那反而适得其反了。"

translate chinese chinese_9267508_446:
    old "It didn't. It got us here."
    new "没有。它把我们带到这里。"

translate chinese chinese_5708283_447:
    old "And you're funny. That dying cat voice? Gold."
    new "而且你还挺搞笑的。那个快要死的猫的声音？绝了。"

translate chinese chinese_6113035_448:
    old "Those aren’t really talen-"
    new "那些根本不算天赋－"

translate chinese chinese_8076640_449:
    old "Also... you’re kinda cute, in that awkward, pushy way."
    new "还有……你挺可爱的，虽然有点尴尬和急躁。"

translate chinese chinese_3256346_450:
    old "A-are you serious?"
    new "你 seriousness？  \n（注：这里\"seriousness\"是直接翻译了\"serious\"，但根据上下文，可能是想表达惊讶或难以置信的情绪，通常会说“你 serious？”或者“你是认真的吗？”由于规则限制，我只能按字面翻译。）  \n\n考虑到规则"

translate chinese chinese_1817150_451:
    old "And now that I think about it... you’ve got a huge talent down there, huh..."
    new "现在想想……你下面可真有一手啊……"

translate chinese chinese_7718244_452:
    old "Well... I mean, you do have talents after all. You see it now?"
    new "嗯……我的意思是，你毕竟还是有天赋的。你现在看出来了？"

translate chinese chinese_2221151_453:
    old "Uhh... I guess, but what about the guitar?"
    new "呃……我猜是这样，但吉他怎么办？"

translate chinese chinese_4093854_454:
    old "Well, guitar's just one more to unlock. But those fingers... they really need waking up."
    new "好吧，吉他只是一个待解锁的项目。但那些手指……真的需要唤醒一下。"

translate chinese chinese_2264368_455:
    old "Yeah, I know... but how am I supposed to do that?"
    new "我知道……但是我要怎么做呢？"

translate chinese chinese_1181764_456:
    old "You know what, I have an idea."
    new "你知道吗，我有个想法。"

translate chinese chinese_2096063_457:
    old "W- whaat a- are you d- doing?"
    new "你你你在干什么？"

translate chinese chinese_3118670_458:
    old "Well, I think you need some extra motivation with those sausage fingers, you know?"
    new "嗯，我觉得你需要一些额外的动力，特别是那些香肠手指，你知道吧？"

translate chinese chinese_8724188_459:
    old "Hey, what the Fuc-!"
    new "嘿，妈的！"

translate chinese chinese_2390942_460:
    old "Shh. Focus on your fingers. Feel the touch."
    new "嘘。专注于你的手指。感受触感。"

translate chinese chinese_5134814_461:
    old "[bil]... this is..."
    new "[bil]……这是……"

translate chinese chinese_2377363_462:
    old "Relax... Focus on the task. Circle gently, don't rush it."
    new "放松点……专注于任务。动作轻柔点，不要急。"

translate chinese chinese_1559130_463:
    old "({i}Oh God...{/i})"
    new "(Oh God...)"

translate chinese chinese_5456375_464:
    old "Mmm... that's better. How do they feel to you, [pla]? Soft enough for your liking?"
    new "嗯……这样好多了。它们给你感觉怎么样，[pla]？够软吗？"

translate chinese chinese_7650166_465:
    old "They're... so soft, [bil]. It feels amazing."
    new "它们……好软，[bil]。感觉太棒了。"

translate chinese chinese_2312478_466:
    old "Heh, good answer. Now, add a bit more pressure. Let's see if you can actually handle the real thing."
    new "嘿嘿，好回答。现在，加点压力。看看你能不能应付真正的场面。"

translate chinese chinese_2437658_467:
    old "O- okay."
    new "好……好吧。"

translate chinese chinese_9546679_468:
    old "Like this? Am I doing it right?"
    new "像这样？我做得对吗？"

translate chinese chinese_6176218_469:
    old "Nngh—yeah. Exactly like that..."
    new "嗯——就是这样..."

translate chinese chinese_6084244_470:
    old "See? you're learning."
    new "看？你在进步。"

translate chinese chinese_5062335_471:
    old "({i}This is insane... and it's working?{/i})"
    new "({i}这太疯狂了……而且竟然有效？{/i})"

translate chinese chinese_3282645_472:
    old "Mmm, nice. Now pick up the pace. Let’s see if you can keep your finesse while speeding up."
    new "嗯，不错。现在加快点速度。看看你能不能在加快速度的同时保持你的细腻。"

translate chinese chinese_4522252_473:
    old "Tell me how they feel right now."
    new "告诉我他们现在的感觉。"

translate chinese chinese_8586329_474:
    old "Hot... heavy... and every time I squeeze they bounce a little. It's insane."
    new "热乎乎的……沉甸甸的……每次我捏一下都还会弹起来。简直疯了。"

translate chinese chinese_6710938_475:
    old "Good feedback. Noted."
    new "好的反馈，已记下。"

translate chinese chinese_1809407_476:
    old "Keep going. Feel the rhythm."
    new "继续。感受节奏。"

translate chinese chinese_7763603_477:
    old "I... I feel something."
    new "我……我觉得有些东西。"

translate chinese chinese_3125941_478:
    old "Yeah, I noticed. Looks like your other talent’s waking up, huh?"
    new "是啊，我注意到了。看来你的另一个天赋觉醒了，对吧？"

translate chinese chinese_0131881_479:
    old "Oh shit... sorry!"
    new "哦shit... 对不起！"

translate chinese chinese_6603224_480:
    old "Oh, come on, you're literally groping my tits..."
    new "哦，别这样，你明明在摸我的胸部..."

translate chinese chinese_7457562_481:
    old "You know what? Come here, let me show you one of my hidden talents too..."
    new "你知道吗？过来，让我也展示一下我的隐藏技能..."

translate chinese chinese_8308496_482:
    old "This throat does more than just sing, you know?"
    new "这嗓子可不止会唱歌，你知道吧？"

translate chinese chinese_5046532_483:
    old "Hooooly shit!"
    new "卧槽！"

translate chinese chinese_5353377_484:
    old "So... you like my other talent too, huh?"
    new "所以……你也喜欢我的其他才艺啊？"

translate chinese chinese_9549728_485:
    old "Oh, yeah, it feels so good..."
    new "哦，是的，感觉真好..."

translate chinese chinese_8743340_486:
    old "Mmm... I’ve missed this since that stupid spin-the-bottle game."
    new "嗯……自从那个该死的真心话大冒险游戏后，我就一直想念这个。"

translate chinese chinese_9958382_487:
    old "You... you have?"
    new "你……你有？"

translate chinese chinese_7496341_488:
    old "Shut up. Let me show you my real talent."
    new "闭嘴。让我展示我的真实才能。"

translate chinese chinese_7782382_489:
    old "So... I guess we made some progress today."
    new "所以……我想今天我们有些进展。"

translate chinese chinese_8650314_490:
    old "Oh yeah, a lot."
    new "哦 yeah，很多。"

translate chinese chinese_1854732_491:
    old "I meant with the guitar."
    new "我是说用吉他。"

translate chinese chinese_0949778_492:
    old "Oh, right. Yes. That too."
    new "哦，对了。是的。那个也有。"

translate chinese chinese_6087819_493:
    old "And from what I see, you definitely have plenty of motivation now."
    new "而依我看来，你现在肯定有足够的动力。"

translate chinese chinese_1155094_494:
    old "Oh, that’s for sure."
    new "哦，那是肯定的。"

translate chinese chinese_6087963_495:
    old "Good. Because that whole quit-the-contest nonsense better be gone."
    new "好。因为那整个退出比赛的胡说八道最好是一去不复返了。"

translate chinese chinese_1438379_496:
    old "Of course. I’m not quitting."
    new "当然，我不会放弃的。"

translate chinese chinese_6331310_497:
    old "Perfect. Then keep practicing at home like you’ve been doing."
    new "完美。那就继续像这样在家练习吧。"

translate chinese chinese_3167184_498:
    old "Your fingers still need work... a lot of work."
    new "你的手指还需要练习……很多练习。"

translate chinese chinese_4834655_499:
    old "I’ll practice every day. I actually want to improve."
    new "我会每天练习的。我真的想进步。"

translate chinese chinese_6499042_500:
    old "Hmm. And if you need something, just tell me."
    new "嗯。如果你需要什么，就告诉我。"

translate chinese chinese_1363946_501:
    old "I will. Thanks... seriously."
    new "我会的。谢谢……真心的。"

translate chinese chinese_5725593_502:
    old "Alright. Let’s leave it here for today."
    new "好吧。今天就到这儿吧。"

translate chinese chinese_4823624_503:
    old "Go home before my grandma shows up."
    new "在我奶奶出现前回家。"

translate chinese chinese_0394477_504:
    old "Yeah, I should. I’ll come back soon."
    new "是的，我应该回去。我很快会再回来的。"

translate chinese chinese_5643768_505:
    old "You better."
    new "你最好这样。"

translate chinese chinese_9683730_506:
    old "Okay... it’s still hard, but I can’t skip practice now."
    new "好吧……还是很难，但我不能现在逃避练习。"

translate chinese chinese_2378055_507:
    old "I’m not great yet, but I’m not totally hopeless either."
    new "我还不算很好，但也算不上完全没希望。"

translate chinese chinese_3852999_508:
    old "Alright. Let’s see if I can do this a little better today."
    new "好吧。看看今天我能不能做得好一点。"

translate chinese chinese_8813239_509:
    old "Hey... that one didn’t buzz as bad."
    new "嘿……那个没那么刺痛。"

translate chinese chinese_1848848_510:
    old "Still not perfect... but it sounded more like a chord this time."
    new "还是不完美……但这次听起来更像和弦了。"

translate chinese chinese_6607186_511:
    old "Hand’s tired, but it’s moving better."
    new "手有点累，但动作更灵活了。"

translate chinese chinese_1478846_512:
    old "Ok, again. Same thing."
    new "好，再来一次。一样的。"

translate chinese chinese_5554394_513:
    old "Rhythm’s still messy... but I didn’t completely lose it."
    new "节奏还是乱了……但我还没完全失控。"

translate chinese chinese_2479430_514:
    old "I can actually feel where I mess up now."
    new "我现在actually能感觉到哪里出错了。"

translate chinese chinese_4714160_515:
    old "({i}Okay... that’s something. I didn’t feel that before.{/i})"
    new "({i}好吧……这倒是有点意思。我之前没有这种感觉。{/i})"

translate chinese chinese_5566905_516:
    old "One more time. Let’s make it cleaner."
    new "再来一次。让我们做得干净点。"

translate chinese chinese_5466374_517:
    old "Still rough... but not total garbage."
    new "还是有点生疏……但不是完全不行。"

translate chinese chinese_4262055_518:
    old "That sounded... closer."
    new "那声音……好像更近了。"

translate chinese chinese_9020402_519:
    old "Yeah. Not there yet, but it’s moving."
    new "是啊。还没到那步，但有进展。"

translate chinese chinese_6849457_520:
    old "Enough for today. Don’t want to ruin what I actually did right."
    new "今天就到此为止吧。不想破坏我做得对的地方。"

translate chinese chinese_1372465_521:
    old "Tomorrow... let’s see if it gets even better."
    new "明天……看看会不会更好。"

translate chinese chinese_9583773_522:
    old "Oh, look who showed up."
    new "哦，看看谁来了。"

translate chinese chinese_1432030_523:
    old "Yeah, I wanted to practice with you again."
    new "是啊，我想再和你一起练习。"

translate chinese chinese_3840687_524:
    old "Right, you texted about that. How's it going?"
    new "对了，你短信提过这个。进展如何？"

translate chinese chinese_3827720_525:
    old "Uhh, better than before... kinda."
    new "呃，比之前好一点吧……算是。"

translate chinese chinese_7582102_526:
    old "Oh really? Hah. I need to see that to believe it."
    new "哦是吗？哈。我得亲眼看看才信。"

translate chinese chinese_8878724_527:
    old "Come on. Let’s go to my room and talk properly."
    new "走吧。去我的房间好好谈谈。"

translate chinese chinese_7031328_528:
    old "Okay, spill. What did you do these days?"
    new "好了，说吧。这些天你干了什么？"

translate chinese chinese_4954121_529:
    old "Honestly... a lot. I practiced every day. My fingers feel way more alive now."
    new "说实话……很多。我每天都在练习。现在手指感觉灵活多了。"

translate chinese chinese_4186588_530:
    old "Good. About time they woke up from the dead."
    new "好，他们该死而复生一阵子了。"

translate chinese chinese_8104730_531:
    old "Yeah, but... I feel like I hit a wall again."
    new "是啊，但是……我觉得我又碰到壁了。"

translate chinese chinese_8212910_532:
    old "Hmm. Typical. Let me see. Take the guitar."
    new "嗯。典型。让我看看。拿吉他。"

translate chinese chinese_0340141_533:
    old "Alright... here goes."
    new "好吧……来了。"

translate chinese chinese_4160860_534:
    old "Huh... pressure’s steadier. The tone’s still messy, but at least you’re not fighting the guitar anymore."
    new "huh... 压力更稳了。调子还是乱糟糟的，但至少你不跟吉他较劲了。"

translate chinese chinese_8056253_535:
    old "Yeah, I feel more control. I can switch positions smoother now."
    new "是的，我觉得更有控制力了。现在换姿势也更顺畅了。"

translate chinese chinese_2866874_536:
    old "Still too slow. But hey, your hand is finally acting like it belongs to a living person."
    new "还是太慢了。不过好了，你的手终于像活人一样动起来了。"

translate chinese chinese_9483364_537:
    old "Not bad. Your fingers actually woke up this time."
    new "不错。这次你的手指总算清醒了。"

translate chinese chinese_1688234_538:
    old "Yeah, but that’s the problem. I think I hit my limit again. I can’t push past this alone."
    new "是啊，但问题就在这里。我觉得我又到极限了。我一个人没法再突破了。"

translate chinese chinese_7754183_539:
    old "Honestly... I was hoping you could help me practice again."
    new "说实话……我本来是希望你能再帮我练习一下的。"

translate chinese chinese_3964752_540:
    old "Huh?"
    new "huh?"

translate chinese chinese_6557256_541:
    old "So that’s why you came back. You want more 'practice'."
    new "所以你回来就是为了更多的“练习”。"

translate chinese chinese_7977350_542:
    old "Exactly. Something a bit more advanced. Something that forces my fingers to—"
    new "没错。有点更高级的。一些能让我的手指——"

translate chinese chinese_1176037_543:
    old "Oh, I see where this is going."
    new "哦，我懂了，这是要去哪儿。"

translate chinese chinese_0869447_544:
    old "Yeah, sure. More 'advanced practice', right?"
    new "是啊，没错。更多的“高级练习”，对吧？"

translate chinese chinese_2715107_545:
    old "Exactly! I need something beyond the basics. I’m not improving anymore."
    new "没错！我需要一些超越基础的东西。我已经不再进步了。"

translate chinese chinese_5358993_546:
    old "Alright, alright, I get it. No need to act innocent."
    new "好吧好吧，我懂了。不用装无辜。"

translate chinese chinese_6481753_547:
    old "Come on, don’t be shy. I know what you’re actually here for."
    new "别害羞了，我知道你实际上来这里是为了什么。"

translate chinese chinese_4098433_548:
    old "No, no, that’s not—"
    new "不，不，那不是——"

translate chinese chinese_2336720_549:
    old "Stop overthinking. You came to practice."
    new "别想那么多。你来这里是为了练习。"

translate chinese chinese_0301684_550:
    old "So let’s practice."
    new "那我们就练习一下吧。"

translate chinese chinese_3074697_551:
    old "({i}Oh God, they feel incredible...{/i})"
    new "(Oh God,他们感觉太棒了...)"

translate chinese chinese_9147153_552:
    old "There. Full palms first. feel how soft they are when you take your time."
    new "好了。先来满掌的，慢慢感受它们的柔软。"

translate chinese chinese_5727065_553:
    old "Keep that rhythm. Don't rush the ‘practice’."
    new "保持那个节奏。别急着“练习”。"

translate chinese chinese_2167225_554:
    old "Fuck... [bil], they feel unreal."
    new "操... [bil]，感觉不真实。"

translate chinese chinese_4371913_555:
    old "Limited edition, baby."
    new "限量版，宝贝。"

translate chinese chinese_6428956_556:
    old "Come on, a little more pressure. You know what I like."
    new "来吧，再加把劲。你知道我喜欢什么。"

translate chinese chinese_8480529_557:
    old "L-like... this?"
    new "像...这样？"

translate chinese chinese_8698279_558:
    old "Yes... perfect. You're doing better than I expected."
    new "是的……完美。你做得比我预期的好。"

translate chinese chinese_2594151_559:
    old "Your nipples... they're getting hard. Does that mean I'm doing good?"
    new "你的乳头……变硬了。这说明我做得不错吗？"

translate chinese chinese_3118063_560:
    old "Means you’re not completely hopeless. Keep going."
    new "意思是你还不完全没希望。继续吧。"

translate chinese chinese_2614665_561:
    old "Okay, new part. First time for this one."
    new "好的，新部分。这个是第一次。"

translate chinese chinese_0151204_562:
    old "Nipples only. Start super gentle... just the tips of your fingers."
    new "只有乳头。开始的时候要非常轻柔…… just你的指尖。"

translate chinese chinese_8534445_563:
    old "T-they're so sensitive... I can feel them hardening more."
    new "他们好敏感……我能感觉到它们变得更硬了。"

translate chinese chinese_2842436_564:
    old "Good. Now a little harder. Build it up, don't rush."
    new "好。现在再用力一点。慢慢来，不要急。"

translate chinese chinese_6394474_565:
    old "A-are you sure?"
    new "你确定吗？"

translate chinese chinese_8322109_566:
    old "Harder, [pla]. Don’t be scared. Make me feel it."
    new "再用力点，[pla]。别怕，让我感受一下。"

translate chinese chinese_0834895_567:
    old "L-like this? God, you're starting to breathe heavier..."
    new "像、像这样？天啊，你开始呼吸急促了……"

translate chinese chinese_2419434_568:
    old "Yes—fuck—keep going. Harder now, make it count."
    new "是的——操——继续。现在用力点，让我觉得值得。"

translate chinese chinese_3834378_569:
    old "({i}Fuck... he’s careful but he’s getting it...{/i})"
    new "({i}操...他虽然小心但还是中招了...{/i})"

translate chinese chinese_3939894_570:
    old "I- I don’t want to hurt you..."
    new "我……我不想伤害你……"

translate chinese chinese_0664874_571:
    old "You won’t. Trust me. Slowly harder each time."
    new "你不会的。相信我。每次慢慢加重。"

translate chinese chinese_5040239_572:
    old "({i}Shit, for a first-timer...{/i})"
    new "(shit, 对于一个初学者来说...)"

translate chinese chinese_2466114_573:
    old "I-I can feel you tensing... come for me, [bil]?"
    new "我感觉你紧张起来了……来吧，[bil]？"

translate chinese chinese_9720288_574:
    old "Harder—now—ahh—fuck—yes—!"
    new "再用力点—现在—啊—操—对了—！"

translate chinese chinese_9081337_575:
    old "Okay... that was more than enough warm up for your fingers."
    new "好吧……这已经足够让你的手指热身了。"

translate chinese chinese_4536549_576:
    old "Y- yeah... definitely intense."
    new "嗯……确实很激烈。"

translate chinese chinese_6520809_577:
    old "So? Feeling more agile now?"
    new "那么？感觉现在更敏捷了？"

translate chinese chinese_7413880_578:
    old "Honestly... a little. But... I don’t think that alone will fix everything."
    new "老实说……有点。但……我觉得光这样是解决不了所有问题的。"

translate chinese chinese_0343219_579:
    old "Oh, really?"
    new "哦，是吗？"

translate chinese chinese_8235058_580:
    old "Yeah. I mean... thanks for the help, seriously, but I don’t think that kind of practice is enough to improve my speed or accuracy."
    new "是啊。我的意思是……谢谢你的帮助，但我觉得那种练习不足以提高我的速度或准确性。"

translate chinese chinese_4184915_581:
    old "Huh."
    new "咦。"

translate chinese chinese_4420078_582:
    old "So what, now you want something even more advanced?"
    new "所以你现在想要更高级的东西了？"

translate chinese chinese_8617351_583:
    old "Well— I mean— I just—"
    new "嗯——我的意思是——我只是——"

translate chinese chinese_5714048_584:
    old "No. No, no, no. Don’t even think I’m giving you a blowjob every time you struggle with a chord."
    new "不。不不不。别想每次你弹和弦有困难我就给你口交。"

translate chinese chinese_1399328_585:
    old "Wait— what? No! That’s not what I meant!"
    new "等一下——什么？不！那不是我的意思！"

translate chinese chinese_2216313_586:
    old "Good. Because I’m not doing that every time you show up."
    new "好。因为我不可能每次你出现都那样做。"

translate chinese chinese_0536049_587:
    old "N- no! I swear I wasn’t asking for that!"
    new "不！我真的不是那个意思！"

translate chinese chinese_5574546_588:
    old "Then what were you asking for?"
    new "那你刚才问什么了？"

translate chinese chinese_0777521_589:
    old "I just... genuinely need help finding a better exercise. Something real. Something useful for my fingers."
    new "我就是……真心需要帮忙找一个更好的练习。一些实际的东西。一些对我手指有用的练习。"

translate chinese chinese_0626056_590:
    old "So you’re... actually serious."
    new "所以你是...认真的。"

translate chinese chinese_8350586_591:
    old "Yes. I figured you’d know something. A technique, an exercise, something."
    new "是的。我想你会知道一些东西的。一种技巧，一个练习，什么的。"

translate chinese chinese_6642847_592:
    old "Exactly, that’s what I’m looking for."
    new "没错，这正是我想要的。"

translate chinese chinese_5916343_593:
    old "Okay, okay, Hmm, then let me think."
    new "好啦好啦，嗯，那让我想想。"

translate chinese chinese_3342655_594:
    old "Hmm... something advanced for finger dexterity... something that forces your hand to adapt..."
    new "嗯……什么能提高手指灵活性的……什么能让你的手适应起来有难度的……"

translate chinese chinese_7554645_595:
    old "Yeah. Exactly."
    new "对。就是这样。"

translate chinese chinese_5967432_596:
    old "Oh..."
    new "哦……"

translate chinese chinese_4540154_597:
    old "...I have an idea."
    new "……我有个想法。"

translate chinese chinese_5750530_598:
    old "You do? What is it?"
    new "你有？是什么？"

translate chinese chinese_2517584_599:
    old "You’ll see. Just stay there."
    new "你会看到的。就待在那里别动。"

translate chinese chinese_6471052_600:
    old "So... what do you have in mind?"
    new "所以……你有什么想法？"

translate chinese chinese_4093779_601:
    old "Something advance. Trust me."
    new "来点刺激的。相信我。"

translate chinese chinese_4704664_602:
    old "W- what are you doing?!"
    new "你干什么啊?!"

translate chinese chinese_9161484_603:
    old "Relax. This is the training. Just extreme level."
    new "放松点。这只是训练，只是级别比较高而已。"

translate chinese chinese_6531203_604:
    old "Now... use those fingers. Start slow."
    new "现在……用那些手指。慢慢来。"

translate chinese chinese_4980492_605:
    old "Shh. Focus. Circle the clit gently."
    new "嘘。专心点。轻轻地圈着她的 clit。"

translate chinese chinese_1910179_606:
    old "Mmm... good. Now slide one in."
    new "嗯……很好。现在塞一个进去。"

translate chinese chinese_9991842_607:
    old "Like... this?"
    new "像……这样？"

translate chinese chinese_0926070_608:
    old "Yes... curl it. Find the spot."
    new "是的……卷起来。找到那个地方。"

translate chinese chinese_0887659_609:
    old "Faster now. Add another finger."
    new "现在加快速度，再加一根手指。"

translate chinese chinese_1904844_610:
    old "[bil]... you're squeezing..."
    new "[bil]...你在挤我..."

translate chinese chinese_8960885_611:
    old "That's it. Rub harder."
    new "就是这样，再用力点。"

translate chinese chinese_5672677_612:
    old "Fuck... you're dripping."
    new "妈的……你湿透了。"

translate chinese chinese_0365655_613:
    old "Deeper. Don't stop."
    new "更深一点。不要停。"

translate chinese chinese_1298861_614:
    old "Harder... make me cum."
    new "再用力点……让我高潮。"

translate chinese chinese_8151404_615:
    old "Oh fuck... cum for me."
    new "哦操...给我高潮。"

translate chinese chinese_3190329_616:
    old "Yes... feel it all."
    new "是的……尽情感受吧。"

translate chinese chinese_5400131_617:
    old "Oh god... that's it."
    new "哦god... 就是这样了。"

translate chinese chinese_5225497_618:
    old "Alright, THAT was definetly an advance training..."
    new "好吧，那 definitely 是个高级训练……"

translate chinese chinese_9430178_619:
    old "Y-yeah... that was... a lot."
    new "嗯……那个……真是够呛的。"

translate chinese chinese_2807010_620:
    old "But hey, your fingers definitely kept up this time."
    new "不过说真的，这次你的手指跟上了。"

translate chinese chinese_7471776_621:
    old "I did feel a big difference. Seriously."
    new "我确实感觉到了很大的不同。真心的。"

translate chinese chinese_9477449_622:
    old "Good. Then keep practicing at home. Use what you learned today."
    new "好的。那就在家继续练习吧。用今天学的东西。"

translate chinese chinese_2001515_623:
    old "If you get stuck again, come back. We’ll figure something out."
    new "如果你又卡住了，就回来。我们会想出办法的。"

translate chinese chinese_2081321_624:
    old "I will. Thanks... for everything."
    new "我会的。谢谢……一切。"

translate chinese chinese_1669883_625:
    old "Alright, event’s over. Go home before my grandma arrives."
    new "好了，事件结束了。在我奶奶来之前回家吧。"

translate chinese chinese_6467029_626:
    old "Finally. Took you long enough."
    new "终于来了。让你等久了。"

translate chinese chinese_3796911_627:
    old "You texted me. Said it was important."
    new "你给我发了短信，说很重要。"

translate chinese chinese_9734959_628:
    old "Yeah. Because it is. The teacher called me."
    new "是啊。因为确实如此。老师打电话给我了。"

translate chinese chinese_1697973_629:
    old "Wait... what? Already?"
    new "等一下……什么？已经？"

translate chinese chinese_8493822_630:
    old "She wants to schedule our supervised practice."
    new "她想安排我们的监督练习。"

translate chinese chinese_6904018_631:
    old "Like... with her? Watching me? Listening to me?"
    new "比如……和她一起？看着我？听着我？"

translate chinese chinese_5784851_632:
    old "Mhm. Exactly that."
    new "嗯，就是那样。"

translate chinese chinese_0660957_633:
    old "Oh man... I’m not ready for that."
    new "哦天... 我还没准备好面对这个。"

translate chinese chinese_7091516_634:
    old "That’s why I told you to come."
    new "这就是为什么我让你来的。"

translate chinese chinese_5197683_635:
    old "We need to polish you up before she sees anything."
    new "我们需要在她看到你之前把你打扮一下。"

translate chinese chinese_2463728_636:
    old "I don’t know if I can—"
    new "我不知道我是否能——"

translate chinese chinese_5276762_637:
    old "Stop. You’re doing it. We’re doing it. End of story."
    new "停下。你在做了。我们在做了。到此为止。"

translate chinese chinese_1101727_638:
    old "Come on. Room. We’ll talk there."
    new "来吧。去房间里。我们在那儿聊。"

translate chinese chinese_9692351_639:
    old "Alright. Tell me. How’ve you been since last time?"
    new "好吧。告诉我，上次之后你过得怎么样？"

translate chinese chinese_7640929_640:
    old "Honestly? Way better. After all that... 'advanced practice'... I definitely improved."
    new "说实话？好太多了。经过那一切……“高级训练”……我确实进步了。"

translate chinese chinese_8072442_641:
    old "Oh, I bet you did."
    new "哦，我敢打赌你是这么做的。"

translate chinese chinese_4487940_642:
    old "Yeah, yeah. Show me."
    new "好了好了，给我看看。"

translate chinese chinese_8546383_643:
    old "Okay... here goes."
    new "好吧……来了。"

translate chinese chinese_0877412_644:
    old "Huh. Look at that."
    new "咦，看看这个。"

translate chinese chinese_7413618_645:
    old "Hand’s lighter. Movement’s cleaner. You’re not strangling the strings anymore."
    new "手更轻了。动作也更干净了。你不再勒弦了。"

translate chinese chinese_3484520_646:
    old "Yeah, I feel the difference. And switching positions isn’t torture now."
    new "是啊，我感觉到了变化。而且换姿势现在也不算是折磨了。"

translate chinese chinese_9932810_647:
    old "Well, seems last session really loosened you up."
    new "嗯，看来上次真的让你放开了很多。"

translate chinese chinese_3573072_648:
    old "I... guess so."
    new "我……猜是这样吧。"

translate chinese chinese_4161207_649:
    old "Still not perfect. You need a final push if you want to stand in front of a teacher."
    new "还是不够完美。如果你想站在老师面前，还需要最后的努力。"

translate chinese chinese_8801649_650:
    old "You really think I need more?"
    new "你真觉得我还需要更多？"

translate chinese chinese_9364800_651:
    old "Oh, absolutely. A little more ‘advanced training’ won’t hurt."
    new "哦，当然。再进行一点“高级训练”也没关系。"

translate chinese chinese_0442286_652:
    old "Billie... I don’t know. I think I’ve improved a lot already."
    new "比莉……我不确定。我觉得我已经进步很多了。"

translate chinese chinese_3567823_653:
    old "You did. But if you want her to take you seriously, you need your fingers sharp."
    new "你做到了。但如果你想让她认真对待你，你需要保持敏锐。"

translate chinese chinese_2435247_654:
    old "And we both know exactly what helped last time."
    new "而且我们俩都清楚上次是什么帮的忙。"

translate chinese chinese_8508566_655:
    old "B- Billie, I—"
    new "B- 比莉，我—"

translate chinese chinese_3415834_656:
    old "Save it. We’re not wasting time. The supervised practice is soon."
    new "省省吧。我们不浪费时间了。监督练习很快就要开始了。"

translate chinese chinese_7116173_657:
    old "So let's get you ready properly."
    new "那我们就好好把你准备好。"

translate chinese chinese_0371198_658:
    old "Okay... damn. You’ve definitely improved again."
    new "好吧……妈的。你确实又进步了。"

translate chinese chinese_4531740_659:
    old "Yeah. I can feel it. Your fingers are way more confident now."
    new "是啊。我能感觉到。你的手指现在自信多了。"

translate chinese chinese_2233929_660:
    old "I... still don’t know if I’m ready for the teacher, though."
    new "我……还是不确定自己是否准备好面对老师。"

translate chinese chinese_0771842_661:
    old "Relax."
    new "放松点。"

translate chinese chinese_6045979_662:
    old "You’re not being tested for the contest yet. This is just to show progress."
    new "你还没到比赛的测试阶段。这只是展示进度而已。"

translate chinese chinese_8310448_663:
    old "Right... progress."
    new "对了……进度。"

translate chinese chinese_1366854_664:
    old "She’ll give us feedback. Then we adjust. Simple."
    new "她会给我们反馈。然后我们调整。很简单。"

translate chinese chinese_0099252_665:
    old "Okay... I guess that makes sense."
    new "好吧……我猜这也说得通。"

translate chinese chinese_8926961_666:
    old "Good. Then keep practicing at home. A lot."
    new "好。那就回家多练习。"

translate chinese chinese_3019828_667:
    old "Don’t make me regret putting in all this effort."
    new "别让我后悔花这么多心思在你身上。"

translate chinese chinese_1709415_668:
    old "I won’t. I’ll practice."
    new "我不会的，我会练习。"

translate chinese chinese_2827718_669:
    old "Alright... I’m done. Literally done. And I’m getting sleepy."
    new "好吧……我完了。真的完了。而且我有点困了。"

translate chinese chinese_6824071_670:
    old "Sleepy?"
    new "困了？"

translate chinese chinese_3882807_671:
    old "Yeah. ‘Advanced training’ is exhausting, in case you didn’t notice."
    new "是啊，‘高级训练’累死人了，你没发现吗？"

translate chinese chinese_1432477_672:
    old "R-right... sorry."
    new "好啦……对不起。"

translate chinese chinese_5134324_673:
    old "Go home. Practice. And don’t come back useless."
    new "回家去。练习。不要没用地回来。"

translate chinese chinese_4950958_674:
    old "I’ll do my best. I’ll see you soon."
    new "我会尽力的。很快见。"

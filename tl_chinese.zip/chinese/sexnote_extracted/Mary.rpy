# auto-tl Qwen Colab

translate chinese chinese_5473941_0:
    old "Oh [pla]! To what do I owe your visit? Are you coming to get a checkup?"
    new "哦 [pla]！你来有什么事吗？是来做检查的吗？"

translate chinese chinese_7051622_1:
    old "Well... Yes... You told me that."
    new "嗯……是的……你是告诉过我。"

translate chinese chinese_0913256_2:
    old "Don't worry, boy. I'm here to take care of your health. As many times as you need... Come on, get on the table."
    new "别担心，小子。我在这里照顾你的健康。你需要多少次都行……来吧，上床。"

translate chinese chinese_2329764_3:
    old "Oh, no, I was just leaving. I'm sorry ..."
    new "哦，不，我只是正要离开。对不起……"

translate chinese chinese_3788293_4:
    old "Okay, if you need a checkup again, you know where to find me..."
    new "好吧，如果你需要再检查一下，你知道在哪里能找到我……"

translate chinese chinese_9855690_5:
    old "Ok, thank you..."
    new "好的，谢谢..."

translate chinese chinese_6718887_6:
    old "Hello, Nurse Mary. Good morning."
    new "你好，玛丽护士。早上好。"

translate chinese chinese_2125615_7:
    old "Good morning! How are you today?"
    new "早上好！今天怎么样？"

translate chinese chinese_4946391_8:
    old "Very well, thank you..."
    new "好吧，谢谢..."

translate chinese chinese_3807093_9:
    old "And what about you, boy?"
    new "那你呢，小子？"

translate chinese chinese_3289287_10:
    old "I'm fine, too. Thank you..."
    new "我也很好。谢谢..."

translate chinese chinese_6095008_11:
    old "He's very quiet, huhm?"
    new "他很安静啊，嗯？"

translate chinese chinese_4383685_12:
    old "He's a bit shy..."
    new "他有点害羞……"

translate chinese chinese_6679093_13:
    old "Haha... Well, let's get to the matter at hand... First, take off your clothes."
    new "哈哈……好吧，言归正传吧……首先，把衣服脱了。"

translate chinese chinese_2037869_14:
    old "Ok... Ok... I really don't feel much... I think I'm going to need a second opinion..."
    new "好……好……我真的没什么感觉……我觉得我需要再听听别的意见……"

translate chinese chinese_5072304_15:
    old "Another practitioner?"
    new "另一个修行者？"

translate chinese chinese_5185166_16:
    old "Oh, no. That's not necessary... You! Boy. Come here..."
    new "哦，不用了……你！过来……"

translate chinese chinese_4156054_17:
    old "...I... But I..."
    new "……我……但是……"

translate chinese chinese_0700353_18:
    old "Come on, come here... This is for the health of your [mo1rel]."
    new "来吧，过来……这是为了你的[mo1rel]健康。"

translate chinese chinese_2310307_19:
    old "In that case..."
    new "那这样的话……"

translate chinese chinese_6673194_20:
    old "I know very well that you saw the massage I was giving her... Because you did not take your eyes off of her..."
    new "我非常清楚你看到了我给她按摩的样子……因为你的眼睛一直没有离开过她……"

translate chinese chinese_5180334_21:
    old "I... I... Wasn't-"
    new "我... 我... 不是-"

translate chinese chinese_5448357_22:
    old "The idea is to do the same thing I'm doing, but you do it this time, alright?"
    new "想法就是做跟我一样的事情，不过这次轮到你了，好吗？"

translate chinese chinese_9270791_23:
    old "Oh, ok, I will try..."
    new "哦，好的，我会试试..."

translate chinese chinese_4114604_24:
    old "But, nurse, is it okay that-"
    new "但是，护士，这样好吗——"

translate chinese chinese_3473869_25:
    old "Don't worry, I know what I'm doing, ok?"
    new "别担心，我知道自己在做什么，好吗？"

translate chinese chinese_7518493_26:
    old "Yes, Nurse Mary..."
    new "是的，玛丽护士..."

translate chinese chinese_2045506_27:
    old "Let's see... put your hands here, cover her breasts well..."
    new "让我看看……把手放这里，把她的胸部盖好……"

translate chinese chinese_6743069_28:
    old "Very well..."
    new "好吧……"

translate chinese chinese_8404367_29:
    old "Now... Start massaging them gently..."
    new "现在……轻轻地开始按摩……"

translate chinese chinese_4976537_30:
    old "(Oh shit!)... Uhh... But..."
    new "（哦shit!）... 嗯... 但是..."

translate chinese chinese_6267736_31:
    old "You already have your hands on, just move them a little, kid..."
    new "你的手已经在上面了，就动动它们吧，孩子……"

translate chinese chinese_7255862_32:
    old "How do they feel, huh?"
    new "他们感觉怎么样，是不是？"

translate chinese chinese_9122527_33:
    old "Hmm... Very soft... Warm..."
    new "嗯……很软……暖暖的……"

translate chinese chinese_2565900_34:
    old "Very well... Now, rub a little harder, focus on sensing if you feel anything strange..."
    new "好吧……现在，再用力一点揉，注意感受有没有什么奇怪的感觉……"

translate chinese chinese_4008414_35:
    old "Well... I really don't feel anything..."
    new "嗯……我真的一点感觉都没有……"

translate chinese chinese_2887044_36:
    old "Well, I think I feel better with that second opinion... However, come for the last appointment on Thursday, do you think that's okay?"
    new "嗯，有了第二个意见我感觉好一些了……不过，请在星期四来最后一次预约，你觉得可以吗？"

translate chinese chinese_2917316_37:
    old "It's fine with me, Nurse Mary."
    new "我无所谓，玛丽护士。"

translate chinese chinese_7073273_38:
    old "...But young man, you can now take your hands off those tits."
    new "……但是小伙子，你现在可以把手从那些胸部拿开了。"

translate chinese chinese_6445332_39:
    old "Sorry... I didn't-"
    new "对不起……我还没来得及……"

translate chinese chinese_2406207_40:
    old "Hahaha, I'm just kidding... I think we have a future doctor standing here..."
    new "哈哈，我开玩笑的……我觉得我们这里站着个未来的医生……"

translate chinese chinese_7262047_41:
    old "Haha. Yes, [pla] is a very good boy..."
    new "哈哈。是的，[pla] 是个非常乖的孩子..."

translate chinese chinese_4008611_42:
    old "Well, until the next appointment, it was nice to see you!"
    new "好吧，下次见面之前，很高兴见到你！"

translate chinese chinese_3490061_43:
    old "You too, Nurse Mary."
    new "你也是，玛丽护士。"

translate chinese chinese_3395821_44:
    old "See you later, boy..."
    new "回头见，小子..."

translate chinese chinese_0311982_45:
    old "See... you... too."
    new "看见了……你……也一样。"

translate chinese chinese_8237136_46:
    old "Hello, Nurse Mary! Good morning."
    new "你好，玛丽护士！早上好。"

translate chinese chinese_3696671_47:
    old "Oh, hi, How are you today?"
    new "哦，嗨，今天怎么样？"

translate chinese chinese_2964912_48:
    old "Very well, thank you."
    new "好吧，谢谢。"

translate chinese chinese_7858255_49:
    old "Well, let's take the final exam, and if we still can't identify it, I already have a solution planned. So let's start... now, take off your clothes."
    new "好吧，我们来做最后的测试，如果还是无法确定，我已经有了计划。那我们现在开始……脱衣服。"

translate chinese chinese_9487770_50:
    old "Hmm... Very well... I think we will definitely need another method..."
    new "嗯……好吧……我觉得我们肯定需要另一个方法……"

translate chinese chinese_0917392_51:
    old "Are you going to need the help of [pla] again?"
    new "你还需要[pla]的帮助吗？"

translate chinese chinese_1980448_52:
    old "Maybe later... For now, I'm going to need you to take off your bra."
    new "也许等会儿吧……不过现在，我需要你把胸罩脱了。"

translate chinese chinese_4357300_53:
    old "Uh, well... I think I'm gonna go on and head out..."
    new "呃，那个……我想我还是先走了……"

translate chinese chinese_1680659_54:
    old "Come on... You have already grabbed her tits, what is the problem to see them now without a bra? You have to be more professional, [pla]..."
    new "来吧……你已经抓过她的胸部了，现在不戴胸罩看有什么问题吗？你得更专业一点，[pla]……"

translate chinese chinese_7385953_55:
    old "Well, what are you waiting for, take off your bra..."
    new "那你还等什么，把胸罩脱了..."

translate chinese chinese_2203443_56:
    old "Yes, Nurse..."
    new "是的，护士……"

translate chinese chinese_3961733_57:
    old "That's what I'm talking about... much better..."
    new "这才是我说的……好得多……"

translate chinese chinese_4715980_58:
    old "Now I can feel every detail better..."
    new "现在我能更清楚地感受到每一个细节……"

translate chinese chinese_9920562_59:
    old "Hmm... I'm going to do it harder..."
    new "嗯……我要更用力了……"

translate chinese chinese_4938300_60:
    old "Well, I really don't feel anything... But I wouldn't want to get carried away. So it's your turn give me your impression, [pla]."
    new "好吧，我确实没什么感觉……但也不想太过火。所以轮到你给我印象了，[pla]。"

translate chinese chinese_8059279_61:
    old "Mary, do you really think it is-"
    new "玛丽，你真的认为是——"

translate chinese chinese_8850808_62:
    old "You guys are so dramatic. Haha. It's just the human body. You have done this before with a bra."
    new "你们真是太过火了。哈哈，不就是人体吗。你之前用胸罩做过这个。"

translate chinese chinese_9489120_63:
    old "There is no big difference now. You do not have to sexualize everything, you know."
    new "现在没什么大区别了。你也不用什么都往那方面想。"

translate chinese chinese_3323648_64:
    old "Ok, ok, Nurse Mary. If you insist..."
    new "好啦好啦，玛丽护士。如果你坚持的话……"

translate chinese chinese_7606457_65:
    old "Let's see now. Do the massages again..."
    new "好吧，再做一次按摩..."

translate chinese chinese_1445333_66:
    old "That's it, nice... your hands cover her breasts well..."
    new "就是这样，很好……你的手正好覆盖住她的胸部……"

translate chinese chinese_6416676_67:
    old "Start massaging them gently..."
    new "开始轻轻地按摩它们..."

translate chinese chinese_3434587_68:
    old "Very well... You can feel them better, right?"
    new "好吧……你能更清楚地感觉到它们，对吧？"

translate chinese chinese_8072694_69:
    old "...Y-Yes ... (Fuck, I'm getting hard)"
    new "...是的……（妈的，我硬了）"

translate chinese chinese_7982110_70:
    old "Very well... Rub a little harder, focus on seeing if you feel anything strange..."
    new "好吧……再用力揉一会儿，注意感受有没有什么异样的感觉……"

translate chinese chinese_1567948_71:
    old "Yes, ma'am..."
    new "是的，小姐..."

translate chinese chinese_4343431_72:
    old "Well... I don't really feel anything strange..."
    new "嗯……我没什么特别的感觉……"

translate chinese chinese_3325231_73:
    old "Well, I think that's definite. My final medical verdict is that these babies are in perfect condition... Make sure you take care of them, please."
    new "嗯，我认为这是确定的。我的最终医疗结论是这些宝宝状况完美……请务必好好照顾他们。"

translate chinese chinese_7690283_74:
    old "You bet, Nurse Mary..."
    new "没错，玛丽护士..."

translate chinese chinese_1772173_75:
    old "Hey... [pla]... thanks for your commitment, but we're done here..."
    new "嘿……[pla]……谢谢你的付出，但我们到此为止了……"

translate chinese chinese_3794818_76:
    old "Oh, right, sure... Sorry again..."
    new "哦，对对……真是对不起……"

translate chinese chinese_3351758_77:
    old "Well, I think that's it..."
    new "嗯，我想就这样吧……"

translate chinese chinese_1015094_78:
    old "Wait a second... What do you have there?"
    new "等一下……你那是什么？"

translate chinese chinese_9338499_79:
    old "(Oh god no...)"
    new "（哦不……）"

translate chinese chinese_6261108_80:
    old "Oh boy, is that all yours?"
    new "天啊，这些都是你的？"

translate chinese chinese_4299880_81:
    old "Hmm... I think this is abnormal... Has a doctor checked you out yet?"
    new "嗯……我觉得这不太正常……医生检查过你吗？"

translate chinese chinese_8552635_82:
    old "...Well, umm, no."
    new "……嗯，不是的。"

translate chinese chinese_0875781_83:
    old "Well, it's time to do it, [pla]..."
    new "好吧，是时候做了，[pla]..."

translate chinese chinese_7156741_84:
    old "Take off all your clothes, young man. I'm going to do a full-body exam..."
    new "把衣服都脱了，小伙子。我要做全身检查……"

translate chinese chinese_9661699_85:
    old "Now? But... I-"
    new "现在？但是……我-"

translate chinese chinese_3721190_86:
    old "But nothing! You don't see that this could be a health problem?... It is always best to examine it to make sure there is no issues."
    new "但是没什么啊！你看不出来这可能是健康问题吗？... 最好还是检查一下，确保没有问题。"

translate chinese chinese_4369322_87:
    old "I  will go out then, Mary..."
    new "那我就出去了，玛丽……"

translate chinese chinese_6356784_88:
    old "Really? He got to see your goods and now you are shy to see his?... Again, it's just a medical procedure. There's no need to freak out about it."
    new "真的吗？他都看过你的了，你现在反而害羞不想看他？……再说，这只是一个医疗程序，不用这么紧张。"

translate chinese chinese_5575008_89:
    old "Ok, nurse..."
    new "好吧，护士..."

translate chinese chinese_6301648_90:
    old "Well... I see your whole body is normal, except your penis."
    new "嗯……我看到你全身都正常，除了你的 penis。"

translate chinese chinese_2295919_91:
    old "I mean, for your age, it is normal to have hard erections. But I think you have a lot of tension built, much more than normal actually."
    new "我的意思是，以你的年龄来说，硬 erection 是正常的。但我觉得你积压了很多紧张情绪，实际上比正常情况要多得多。"

translate chinese chinese_2379718_92:
    old "Also, your size is not at all common... So I need to relax it in order to evaluate it better..."
    new "而且，你的尺寸并不常见……所以我要放松一下，以便更好地评估它……"

translate chinese chinese_1292063_93:
    old "...Wha-what do you mean?"
    new "...什么什么意思？"

translate chinese chinese_1301293_94:
    old "It means I'm going to massage it until it is in a relaxed, flaccid state..."
    new "我的意思是我要按摩到它完全放松、软下来……"

translate chinese chinese_3024321_95:
    old "Let's see... I'm going to massage it like this..."
    new "让我看看……我要这样按摩……"

translate chinese chinese_3436094_96:
    old "How does it feel, boy?"
    new "感觉怎么样，小子？"

translate chinese chinese_2742403_97:
    old "... It feels... really good."
    new "……感觉……真好。"

translate chinese chinese_7844473_98:
    old "Let's do it a little faster..."
    new "我们快一点吧..."

translate chinese chinese_3399813_99:
    old "Nurse... I'm going to..."
    new "护士……我要……"

translate chinese chinese_0702842_100:
    old "That's it... Let it out, [pla]. Relax your body."
    new "就这样……发泄出来吧，[pla]。放松身体。"

translate chinese chinese_9564390_101:
    old "Wow, that was quite the show... Well, I don't see anything that can affect your overall health..."
    new "哇，那可真是精彩……好吧，我没看到有什么能影响你整体健康的东西……"

translate chinese chinese_8981059_102:
    old "However, I am prescribing that you do these massages anytime you feel tension..."
    new "不过，我建议你在感到紧张时做这些按摩..."

translate chinese chinese_8373830_103:
    old "...Ok, Nurse Mary..."
    new "...好吧，玛丽护士..."

translate chinese chinese_9666304_104:
    old "Thank you very much, Mary, for helping us both..."
    new "玛丽，非常感谢你帮助我们俩……"

translate chinese chinese_3525032_105:
    old "It's a pleasure, Sue. Well, that's it. If you need me again you know where to find me..."
    new "很高兴见到你，苏。好吧，就这样吧。如果你还需要我，知道在哪里能找到我……"

translate chinese chinese_1586197_106:
    old "Okay, see you later,Mary..."
    new "好吧，再见了，玛丽..."

translate chinese chinese_1338056_107:
    old "See you later..."
    new "回头见..."

translate chinese chinese_1881068_108:
    old "You can bet it."
    new "那是肯定的。"

translate chinese chinese_9100181_109:
    old "Well, I see you're still in perfect health... That was all for now..."
    new "嗯，看来你还是健健康康的……这次就先到这里吧……"

translate chinese chinese_2584295_110:
    old "If you need a checkup again, you know where to find me..."
    new "如果你还需要检查，知道在哪里找到我……"

translate chinese chinese_2435438_111:
    old "Ok, thanks..."
    new "好的，谢谢……"

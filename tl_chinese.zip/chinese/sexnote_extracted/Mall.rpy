# auto-tl Qwen Colab

translate chinese chinese_3111452_0:
    old "Hey buddy, how are you doing?"
    new "嘿哥们，最近怎么样？"

translate chinese chinese_3315651_1:
    old "Wow!!!"
    new "哇!!!"

translate chinese chinese_2053486_2:
    old "Oh! No worries at all, she is harmless, actually the only way to be attacked by them is that they feel threatened, it's ok, touch her."
    new "哦！放心吧，她无害的，实际上只有在她们感到受到威胁时才会攻击，没事，摸摸她。"

translate chinese chinese_5998830_3:
    old "No, no...  It's fine thank you."
    new "不，不用了……谢谢。"

translate chinese chinese_6299360_4:
    old "Hehehe! It's ok, the first time is kind of impressive... Her name is Gorgo, I really love her, it's my pet."
    new "嘿嘿嘿！没关系，第一次挺让人印象深刻的……她的名字叫戈尔戈，我真的很喜欢她，她是我的宠物。"

translate chinese chinese_6955148_5:
    old "I can see it..."
    new "我看得出来..."

translate chinese chinese_4058341_6:
    old "Do you like snakes? Would you like to adopt one?"
    new "你喜欢蛇吗？想收养一条吗？"

translate chinese chinese_4703736_7:
    old "Oh no, no thank you... Hmm I'm more a cat person... You know..."
    new "哦不，不用了……嗯，我更喜欢猫……你知道的……"

translate chinese chinese_2237954_8:
    old "Oh, they are beautiful too, here you can find anything you need related with any pet... You know their food, cat litter or any toy you want for them to play with."
    new "哦，它们也很漂亮，这里你能找到任何你需要的宠物相关的东西……你知道的，比如它们的食物、猫砂或者任何你想买的玩具。"

translate chinese chinese_7182869_9:
    old "Alright, thank you, I've never been to this place before! It 's amazing..."
    new "好吧，谢谢，我以前从没来过这里！真是棒极了..."

translate chinese chinese_1807329_10:
    old "Yes, I just opened a couple of months ago, so that's probably  why you haven't seen it before..."
    new "是的，我只开了几个月，所以你之前可能没见过……"

translate chinese chinese_4657006_11:
    old "You can come at any time, this place is a free space for animals and earth care, you can find anything and help with everything to save this beautiful world..."
    new "你可以随时来，这里是一个为动物和地球关怀的自由空间，你可以找到任何东西并帮助一切来拯救这个美丽的世界……"

translate chinese chinese_2436390_12:
    old "Oh, it's very nice to see this kind of place."
    new "哦，看到这样的地方真好。"

translate chinese chinese_2175083_13:
    old "Anytime you want to come we are here for you, ok? What's your name buddy?"
    new "你什么时候想来我们都在这里等你，好吗？伙计，你叫什么名字？"

translate chinese chinese_9797291_14:
    old "I'm [pla] nice to meet you."
    new "我是[pla]，很高兴见到你。"

translate chinese chinese_2059015_15:
    old "It's a pleasure [pla], I'm Roonie, I love the energy I can feel from people, yours is quite special keep that feeling, we need more people like you."
    new "见到你很高兴 [pla]，我是Roonie，我喜欢感受人们的活力，你的感觉很特别，保持这种感觉，我们需要更多像你这样的人。"

translate chinese chinese_5898013_16:
    old "Ok... Thank you..."
    new "好……谢谢……"

translate chinese chinese_1619849_17:
    old "It was nice to meet you! Have a peaceful day!"
    new "很高兴见到你！祝你一天平安！"

translate chinese chinese_9566098_18:
    old "Thanks, see you!"
    new "谢谢，再见！"

translate chinese chinese_5191400_19:
    old "Hey buddy, how are you?"
    new "嘿哥们，最近怎么样？"

translate chinese chinese_6430403_20:
    old "I'm fine, thank you."
    new "我很好，谢谢。"

translate chinese chinese_0695779_21:
    old "It's nice to see you here, very nice and positive energy you are spreading today."
    new "在这里见到你真好，你今天散发出的正能量很积极。"

translate chinese chinese_2797341_22:
    old "... Thank you."
    new "...谢谢。"

translate chinese chinese_9912345_23:
    old "What do you need today, I'm here to help you."
    new "今天你需要什么，我在这里帮你。"

translate chinese chinese_7088034_24:
    old "Oh, I was just passing by."
    new "哦，我刚才路过这里。"

translate chinese chinese_7230861_25:
    old "Ok, Remember if you find any homeless animal you can bring it here, so we can help, I know this world is very mean to them..."
    new "好的，如果你发现任何流浪动物，可以带到这里来，我们可以帮忙。我知道这个世界对他们很残酷……"

translate chinese chinese_9112320_26:
    old "I will do!"
    new "我会做的！"

translate chinese chinese_1480365_27:
    old "Count on you buddy to make a more beautiful world for them."
    new "就靠你了，伙计，为他们创造一个更美好的世界。"

translate chinese chinese_7345823_28:
    old "Sure... I need to leave."
    new "好吧……我得走了。"

translate chinese chinese_2558549_29:
    old "I know, busy day, isn't it?"
    new "我知道，今天挺忙的，不是吗？"

translate chinese chinese_3748084_30:
    old "Kind of..."
    new "有点儿..."

translate chinese chinese_6894506_31:
    old "Thank you for stopping by to say hi."
    new "谢谢你过来打个招呼。"

translate chinese chinese_3907400_32:
    old "Don't mention it."
    new "别提了。"

translate chinese chinese_5594083_33:
    old "You too, bye!"
    new "你也再见！"

translate chinese chinese_6816551_34:
    old "Hey! How are you?"
    new "嘿！最近怎么样？"

translate chinese chinese_8235293_35:
    old "Hey my man, nice seeing you again! I'm pretty fine, what about you?"
    new "嘿，老兄，好久不见！我挺好的，你呢？"

translate chinese chinese_8901890_36:
    old "I'm glad... Well, Hmm, I'm ok."
    new "我很高兴……嗯，我挺好的。"

translate chinese chinese_4730697_37:
    old "Cool man! Is there anything I can do for you?"
    new "酷毙了！有什么我能帮你的吗？"

translate chinese chinese_4819970_38:
    old "Hmm, actually yes... I- I w- wanted to ask you for a j- job? I thought you maybe had something for me."
    new "嗯，实际上是有……我—我—我想请你帮个忙？我以为你可能有适合我的任务。"

translate chinese chinese_3756074_39:
    old "Really? [pla] you put me in a complicated situation. I would like to help you but now it's impossible. I don't have much resources right now and Angelina is pregnant."
    new "真的吗？[pla]你把我置于一个很复杂的境地。我想帮你，但现在根本不可能。我现在资源不多，而且Angelina怀孕了。"

translate chinese chinese_5160906_40:
    old "Pregnant? Oh right! Uhh...  Congrats Ronnie, t- that's... great."
    new "怀孕了？哦对！呃……恭喜你，罗尼，那……很好。"

translate chinese chinese_8652992_41:
    old "I'm sorry I bothered you, I understand you can't help me now. I should go now... I have things to do but thanks..."
    new "对不起打扰你了，我明白你现在帮不了我。我还是走吧……我还有事要处理，不过谢谢……"

translate chinese chinese_3786045_42:
    old "No, no, it's fine, sorry I couldn't help, but you don't have to go, stay and let's chit-chat."
    new "不用，不用，没关系，对不起帮不上忙，但你不用走，留下来咱们聊聊天。"

translate chinese chinese_2371230_43:
    old "Oh n- no, thanks but I really need to go now. See you!"
    new "哦不，不用了，我真的得走了。再见！"

translate chinese chinese_4117353_44:
    old "Have a nice one! Take care [pla]."
    new "祝好！保重[pla]。"

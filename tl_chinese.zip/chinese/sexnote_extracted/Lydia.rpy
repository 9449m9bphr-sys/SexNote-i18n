# auto-tl Qwen Colab

translate chinese chinese_7467748_0:
    old "No Anna, you can't live your life like this."
    new "安娜，你不能这样生活。"

translate chinese chinese_5728926_1:
    old "I'm already big enough to decide what I do with my life."
    new "我已经足够成熟，可以决定自己的人生了。"

translate chinese chinese_6537764_2:
    old "Yes, but in recent weeks you have been drinking excessively and even using drugs!"
    new "是的，但最近几周你喝酒喝得太多，甚至还在吸毒！"

translate chinese chinese_2376705_3:
    old "I'm very worried about you, about your health, I know your father's loss was not easy, it hurts me a lot too-"
    new "我非常担心你，担心你的健康，我知道你父亲的去世对你来说很不容易，这对我来说也很痛苦——"

translate chinese chinese_6768514_4:
    old "it has nothing to do with it... I just want to enjoy my life, I don't want to live locked up and self-conscious like... You."
    new "这和它没关系……我只是想享受生活，不想像你那样被束缚住，活得那么在意自己。"

translate chinese chinese_7761835_5:
    old "Anyway... Don't wait for me tonight..."
    new "不管怎样……今晚不要等我……"

translate chinese chinese_1811429_6:
    old "I'm sorry you heard that... Things have not been very easy for either of us."
    new "听到那些话你很难过吧……我们俩的情况都不太好。"

translate chinese chinese_0379712_7:
    old "I'm very sorry, I just came to accompany you a little..."
    new "非常抱歉，我只是过来陪你一会儿……"

translate chinese chinese_7493607_8:
    old "Aww thank you very much pumpkin."
    new "哎呀，谢谢你啦，小甜心。"

translate chinese chinese_8441592_9:
    old "But you don't have to worry, I know you have your things to do, and at the moment I don't feel very well."
    new "但是你不用担心，我知道你有自己的事情要忙，而且我现在感觉不太舒服。"

translate chinese chinese_1840656_10:
    old "Hmm, is it because of the discussion with Anna?"
    new "嗯，是因为和安娜的谈话吗？"

translate chinese chinese_3687289_11:
    old "Yes honey, she was greatly affected by her father's death and has been... Quite bad lately."
    new "是的亲爱的，她父亲的去世对她影响很大，最近……状况不太好。"

translate chinese chinese_3162930_12:
    old "I understand, I can come another day if you want."
    new "我明白，如果你想的话，我可以改天再来。"

translate chinese chinese_6430831_13:
    old "You know what? Yes, come over the weekend and come with me to church, are you okay with that?"
    new "你知道吗？周末过来，然后跟我一起去教堂，行不行？"

translate chinese chinese_3071591_14:
    old "Perfect! I will come in the weekend."
    new "完美！我周末过来。"

translate chinese chinese_2288991_15:
    old "Great, thank you for your visit and support honey, I really appreciate it."
    new "太好了，谢谢你来看我和支持我，我真的非常感激。"

translate chinese chinese_7555061_16:
    old "Don't worry, I'm glad for helping you..."
    new "别担心，能帮你我很高兴..."

translate chinese chinese_9176169_17:
    old "Oh hi pumpkin, did you come to help me with the dating app?"
    new "哦，亲爱的，你是来帮我弄那个约会软件的吗？"

translate chinese chinese_8726603_18:
    old "Uhh yeah, how's it going?"
    new "嗯嗯，最近怎么样？"

translate chinese chinese_1604521_19:
    old "Well, remember we have to do it in the afternoons, because Anna is here in the mornings..."
    new "好吧，记得我们要在下午做，因为安娜早上在这里……"

translate chinese chinese_3215868_20:
    old "Ohh, you're right! I'm sorry, I totally forgot."
    new "哦，你说得对！对不起，我完全忘了。"

translate chinese chinese_1312842_21:
    old "Don't worry pumpkin, just come back in a few hours."
    new "别担心，小南瓜，几个小时后回来就行了。"

translate chinese chinese_4461974_22:
    old "Alright, see you later then."
    new "好吧，那回头见。"

translate chinese chinese_0244566_23:
    old "See you later."
    new "回头见。"

translate chinese chinese_1097184_24:
    old "Hey pumpkin, did you come to accompany me to church?"
    new "嘿，小甜心，你是来陪我去教堂的吗？"

translate chinese chinese_6863049_25:
    old "Of course, are you ready?"
    new "当然了，你准备好了吗？"

translate chinese chinese_1928089_26:
    old "Sure, let's go!"
    new "行，走吧！"

translate chinese chinese_3879840_27:
    old "Thank you so much for joining me to this mass in commemoration of my husband."
    new "非常感谢你能参加这场纪念我丈夫的弥撒。"

translate chinese chinese_3580749_28:
    old "Don't worry, it's a pleasure to share with you."
    new "别担心，能和你分享是我的荣幸。"

translate chinese chinese_1835313_29:
    old "Oh honey, you don't know how important is the support like yours right now."
    new "亲爱的，你不知道现在像你这样的支持对我有多重要。"

translate chinese chinese_5160399_30:
    old "Hi Lydia, I'm so sorry for your husband, how have you been these past few week?"
    new "莉迪亚，我对你丈夫的事感到非常抱歉，这几周你过得怎么样？"

translate chinese chinese_5230375_31:
    old "Coping with patience, Mrs. Jones."
    new "耐心应对吧，琼斯夫人。"

translate chinese chinese_7877584_32:
    old "Yes, I understand you perfectly, I also lost my husband 5 years ago."
    new "是的，我完全理解你，我也在五年前失去了丈夫。"

translate chinese chinese_1722146_33:
    old "Do you know what helped me? Praying and approach to God."
    new "你知道是什么帮到我吗？祈祷和接近上帝。"

translate chinese chinese_0684237_34:
    old "Yes Mrs. Jones, that's the best."
    new "是的，琼斯夫人，那个最好。"

translate chinese chinese_6860968_35:
    old "I will continue coming to church everyday, giving my life to the lord."
    new "我会继续每天来教堂，把我的生命献给主。"

translate chinese chinese_8256152_36:
    old "Yes... He comforts us..."
    new "是的……他在安慰我们……"

translate chinese chinese_8357320_37:
    old "There's nothing like being faithful to the Lord all your life, right Lydia?"
    new "一生忠于主的感觉无与伦比吧，莉迪亚？"

translate chinese chinese_6569345_38:
    old "Sure... Excuse me Mrs. Jones, I have to go, I hope to see you soon."
    new "好吧……琼斯夫人，我得走了，希望很快能再见到您。"

translate chinese chinese_1855902_39:
    old "Okay Lydia, remember that this is the house of God and here you will always be welcome."
    new "好吧，莉迪亚，记住这是上帝的家，你随时都欢迎来这里。"

translate chinese chinese_9484889_40:
    old "Let's go [pla]."
    new "走吧，[pla]。"

translate chinese chinese_5321102_41:
    old "Are you feeling alright? You seem a little disturbed."
    new "你没事吧？你看起来有点不对劲。"

translate chinese chinese_0386120_42:
    old "Did you hear what Mrs. Jones said?"
    new "你听到琼斯太太说了什么吗？"

translate chinese chinese_7737403_43:
    old "Yes, she is a very religious woman, will you accompany her to church?."
    new "是的，她是个非常虔诚的女人，你会陪她去教堂吗？"

translate chinese chinese_4643121_44:
    old "No, no, you don't understand..."
    new "不，不，你不懂……"

translate chinese chinese_8273541_45:
    old "I've been thinking... After so many years, I have never lived my life..."
    new "我一直在想……这么多年了，我从来没有真正活过……"

translate chinese chinese_9847371_46:
    old "[pla], I've never lived, I've always been a homely woman, I haven't really felt happy."
    new "[pla]，我从来没有真正活过，一直是个家庭主妇，没有真正感到过快乐。"

translate chinese chinese_7129974_47:
    old "You know when you reach a certain age you start looking back and see what you've lived..."
    new "你知道当你到了一定年纪就开始回顾自己的生活……"

translate chinese chinese_6933191_48:
    old "And after so many years I had conformed to what it should be like."
    new "这么多年了，我已经习惯了它该有的样子。"

translate chinese chinese_7046277_49:
    old "But after listening to Mrs. Jones... That's not what I want for my life."
    new "但是听了琼斯太太的话之后……那不是我想要的生活。"

translate chinese chinese_8500851_50:
    old "I already gave my whole life to a man, now he isn't here anymore, I don't want to stay locked up in a church now either."
    new "我已经把一生都献给一个男人了，现在他都不在了，我也不想再被锁在教堂里了。"

translate chinese chinese_6043076_51:
    old "I don't want to be like Mrs Jones in 5 years, it's not what I want for my life..."
    new "我可不想五年后变成琼斯太太那样，那不是我想要的生活……"

translate chinese chinese_4766237_52:
    old "Then, what will you do?"
    new "那你会怎么做？"

translate chinese chinese_8681189_53:
    old "I think Anna is right... I have to start living my life, live new experiences."
    new "我觉得安娜说得对……我得开始活出自己的生活，尝试新的体验。"

translate chinese chinese_2878949_54:
    old "You know? I never had sex with any other man... I really don't know if I enjoyed sex at least!"
    new "你知道吗？我从来没有和其他男人上过床……我真的不知道自己是否至少享受过性爱！"

translate chinese chinese_4328702_55:
    old "Today was a revelation for me... and I don't want to bother you anymore."
    new "今天对我来说是个启示……我不想再打扰你了。"

translate chinese chinese_8648671_56:
    old "Thank you very much for your company, these days I will be thinking about what I should do with my life."
    new "非常感谢你的陪伴，这些天我会思考我应该怎样继续我的生活。"

translate chinese chinese_5530324_57:
    old "I understand, if you need anything just let me know..."
    new "我明白，如果你需要什么就告诉我……"

translate chinese chinese_3358019_58:
    old "In fact I think if I'm going to need several things from you..."
    new "事实上，我觉得我需要你提供几样东西……"

translate chinese chinese_3293394_59:
    old "Never mind, see you later pumpkin."
    new "算了，再见啦 Pumpkin。"

translate chinese chinese_8256794_60:
    old "Hi Honey, remember that I need you to accompany me to the church the weekend."
    new "亲爱的，记得这个周末你需要陪我去教堂。"

translate chinese chinese_0580986_61:
    old "Ohhh, of course, no problem, I'll be here on the weekend."
    new "哦，当然，没问题，我周末会在这里。"

translate chinese chinese_9727546_62:
    old "Thank you very much pumpkin!"
    new "谢谢你，小南瓜！"

translate chinese chinese_1417829_63:
    old "Hi Honey, do you need me?"
    new "亲爱的，你需要我吗？"

translate chinese chinese_2418505_64:
    old "Oh no, sorry, I was just walking around."
    new "哦不，对不起，我刚才只是在走来走去。"

translate chinese chinese_2539855_65:
    old "Ok, pumpkin"
    new "好的，小甜心"

translate chinese chinese_3288043_66:
    old "Sorry, I was just walking around."
    new "对不起，我刚才只是在四处走走。"

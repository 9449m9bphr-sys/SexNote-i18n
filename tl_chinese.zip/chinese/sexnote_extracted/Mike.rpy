# auto-tl Qwen Colab

translate chinese chinese_5982334_0:
    old "Mmm, hi, [pla]. Long time, no see! My, how you've grown!"
    new "嗯，嗨，[pla]。好久不见！我的天，你都长大了！"

translate chinese chinese_8616224_1:
    old "(Gulp) Hello, Mrs. White. Thank you."
    new "（咽口水）你好，怀特夫人。谢谢。"

translate chinese chinese_5365031_2:
    old "I guess you came over to see Mike? What are you two planning on doing?"
    new "你过来是看迈克的吧？你们俩打算干啥？"

translate chinese chinese_5657550_3:
    old "Uhh... We... Nothing... Hehe."
    new "呃……我们……没什么……嘿嘿。"

translate chinese chinese_4771000_4:
    old "Finally! You decided to come! Don't bother us, Mom. We gotta work on that dumb school project."
    new "终于！你决定来了！别烦我们了，妈妈。我们得搞那个愚蠢的学校项目。"

translate chinese chinese_7339172_5:
    old "Ok. If you guys need anything, I'll be here."
    new "好的。你们需要什么尽管说，我就在这。"

translate chinese chinese_8707856_6:
    old "Alright, man. What's this great thing you just had to show me? "
    new "好吧，伙计。有什么好东西非要让我看看？"

translate chinese chinese_7991720_7:
    old "Well, you came just in time. Every day... at this minute... it begins."
    new "好吧，你来的正是时候。每天……在这个时刻……就开始了。"

translate chinese chinese_7183788_8:
    old "What begins?"
    new "什么开始了？"

translate chinese chinese_0119177_9:
    old "You'll see... Just wait."
    new "你会看到的…… just wait."

translate chinese chinese_8082349_10:
    old "The hell you doing, Mike?"
    new "迈克，你在搞什么？"

translate chinese chinese_9095422_11:
    old "Let me enjoy for a sec. It'll be your turn in a bit."
    new "让我享受一下。很快轮到你了。"

translate chinese chinese_6001154_12:
    old "Ok, here. Take this and peep what's out the front window? "
    new "好的，给你，去看看前面窗户外面有什么？"

translate chinese chinese_8879678_13:
    old "Oh shit!"
    new "哦shit！"

translate chinese chinese_3127841_14:
    old "She's hot, isn't she?"
    new "她挺辣的，对吧？"

translate chinese chinese_4162752_15:
    old "Damn. I think... I think, I've seen her before"
    new "真见鬼。我觉得……我觉得我以前见过她"

translate chinese chinese_7361084_16:
    old "Wait... Do you really know  that lady?"
    new "等一下……你真的认识那位女士？"

translate chinese chinese_9816901_17:
    old " I think so but I'm not sure... I'd have to get a closer look."
    new "我觉得是那样，但也不太确定……得再仔细看看。"

translate chinese chinese_3368122_18:
    old "Well ... I know something for sure... she is sexy as fuck! "
    new "嗯……我敢肯定一件事……她性感极了！"

translate chinese chinese_3924682_19:
    old "(she really is...)"
    new "（她确实……）"

translate chinese chinese_7454945_20:
    old "(I think she is my [lisrel]) Mmm... Let me see her again ..."
    new "（我觉得她是我的[lisrel]）嗯……让我再看看她……"

translate chinese chinese_6353683_21:
    old "Haha. I knew you would like it."
    new "哈哈。我就知道你会喜欢的。"

translate chinese chinese_1892034_22:
    old "What? Is she getting naked? Give me those binoculars!"
    new "什么？她脱衣服了？把望远镜给我！"

translate chinese chinese_7657299_23:
    old "(Hmm... What am I going to do now? Can't let Mike see me like this.)"
    new "（嗯……我现在该怎么办？不能让迈克看到我这副样子。）"

translate chinese chinese_2805910_24:
    old "(The only solution is to go to the bathroom and try to masturbate.)"
    new "（唯一的解决办法就是去卫生间试着自慰。）"

translate chinese chinese_7262074_25:
    old "Hmm... I need to use your bathroom, man. You keep watching her..."
    new "嗯……我得用一下你的浴室，兄弟。你继续看着她……"

translate chinese chinese_7532895_26:
    old "Ok. Suit yourself."
    new "好吧，随你了。"

translate chinese chinese_7307173_27:
    old " Whoops. I'm sorry, ma'am. I thought there was no one-"
    new "谁ops。对不起，夫人。我以为没人——"

translate chinese chinese_1839832_28:
    old "Ohh, are you [pla]? Don't worry. Go on and use the toilet. I trust that you won't peep, right? "
    new "哦，你是[pla]吗？别担心，去上厕所吧。我相信你不会偷看的，对吧？"

translate chinese chinese_9477365_29:
    old "No. Of course not, Mrs. White..."
    new "不。当然不，怀特夫人..."

translate chinese chinese_2177356_30:
    old "Haha! I am just kidding. Do what you need to do, kid. I'll continue taking a shower, deal?"
    new "哈哈！我开玩笑的。你该干嘛就干嘛，我继续洗澡，行吧？"

translate chinese chinese_3472519_31:
    old "Ok... (Hmm I have no option) "
    new "好吧...（嗯，我没有选择）"

translate chinese chinese_6910342_32:
    old "(What is that noise? ...What is he doing?)"
    new "（那是什么声音？……他在干什么？）"

translate chinese chinese_9385270_33:
    old "(My word... He is hung!)"
    new "（天啊……他好大！）"

translate chinese chinese_5941460_34:
    old "(Mmm... I should just take my shower. I don't want him to see me peeping.)"
    new "（嗯……我还是去洗澡吧。我不想让他看到我偷看。）"

translate chinese chinese_6085021_35:
    old "Well, I managed to solve it, but I don't know for how long..."
    new "嗯，我倒是解决了，但不知道能维持多久……"

translate chinese chinese_7347940_36:
    old "I better say goodbye to Mike and go home."
    new "我还是跟迈克道个别然后回家吧。"

translate chinese chinese_3548172_37:
    old " Hey, Mike. I have to jet."
    new "嘿，迈克，我得走了。"

translate chinese chinese_4793226_38:
    old "Oh, ok.  If you want to check her out again, come tomorrow."
    new "哦，好的。如果你想再看看她，明天再来吧。"

translate chinese chinese_6180507_39:
    old "W-What?!"
    new "什、什么?!"

translate chinese chinese_1495914_40:
    old "Yeah. If you want to see my neighbor again, come tomorrow..."
    new "嗯。如果你想再见到我的邻居，明天再来吧..."

translate chinese chinese_7676515_41:
    old " Ohh, right. (Whew.) The neighbor... Ok. See you later, dude."
    new "哦，对了。（呼。）邻居……好吧。回头见，兄弟。"

translate chinese chinese_7380336_42:
    old "Hey dude, you wanna see her again?"
    new "嘿，你想再见到她吗？"

translate chinese chinese_4639418_43:
    old "Yeah, man. I want to check if I really know her."
    new "是啊，我想确认一下我是不是真的了解她。"

translate chinese chinese_2639604_44:
    old "Really? Ok, yeah, sure... Ok, it's your turn then..."
    new "真的吗？好吧，行吧……那轮到你了……"

translate chinese chinese_5893509_45:
    old "Remember, if she starts to undress you have to tell me..."
    new "记住，如果她开始脱衣服你必须告诉我..."

translate chinese chinese_6706159_46:
    old "Alright..."
    new "好吧……"

translate chinese chinese_5648238_47:
    old "(Hmm, really? Another hardon?) Mike, I need to use the bathroom. You wanna keep watching?"
    new "（嗯，真的吗？又硬了？）迈克，我需要去厕所。你要继续看吗？"

translate chinese chinese_8923793_48:
    old "Of course!... She's so hot."
    new "当然了……她真性感。"

translate chinese chinese_2555255_49:
    old "You back, dude?... Check out this other position she's practicing..."
    new "你回来了，兄弟？……看看她正在练习的这个姿势……"

translate chinese chinese_6969256_50:
    old "Really? Let me see. (Maybe now I can see her face and know if I can if i can recognize her.)"
    new "真的吗？让我看看。（也许现在我能看见她的脸，知道能不能认出她。）"

translate chinese chinese_5170943_51:
    old "Yeah, sure... Here you go."
    new "嗯，好吧……给你。"

translate chinese chinese_7388367_52:
    old "(Hmm, really? An erection again?) Mike, I need to use your bathroom. You can have the binoculars back, bud."
    new "（嗯，真的吗？又硬了？）迈克，我需要去一下你的洗手间。你可以把望远镜拿回去了，伙计。"

translate chinese chinese_3528395_53:
    old "Sweet!"
    new "太棒了！"

translate chinese chinese_2072514_54:
    old "[pla]! Come look, man! It's gotten sexier than ever!"
    new "[pla]！快来看，这家伙变得比以前更性感了！"

translate chinese chinese_4274339_55:
    old "What the fuck..."
    new "妈的……"

translate chinese chinese_1203248_56:
    old "She makes me so fuckin' hard. I really wanna fuck her..."
    new "她让我硬得不行。我真的想跟她做..."

translate chinese chinese_2336305_57:
    old "(Aaaand, of course, another erection...) Yeah, Mike... this is awesome... You can keep watching..."
    new "（啊啊啊，当然，又硬起来了……）嗯，迈克……这太棒了……你可以继续看……"

translate chinese chinese_7444899_58:
    old "Perfect! Ohh man. Tonight, I'm going to jerk off just thinking about her... "
    new "完美！哦 man。今晚我就想着她来爽一爽……"

translate chinese chinese_3137529_59:
    old "...(This guy...)"
    new "...(这个家伙...)"

translate chinese chinese_3408027_60:
    old "Mike, I need to use your bathroom, man..."
    new "迈克，我得用一下你的浴室，兄弟..."

translate chinese chinese_1240979_61:
    old "Nice... take your time. My turn to enjoy the view."
    new "不错……慢慢来。轮到我欣赏了。"

translate chinese chinese_8486481_62:
    old "Hey [pla], you wanna see her again?"
    new "嘿[pla]，你想再见到她吗？"

translate chinese chinese_2877215_63:
    old "Well... Yes..."
    new "嗯……是的……"

translate chinese chinese_3101805_64:
    old "Ok, it's your turn then..."
    new "好吧，那现在轮到你了……"

translate chinese chinese_1593121_65:
    old "Position 1"
    new "姿势1"

translate chinese chinese_5746554_66:
    old "Position 2"
    new "姿势2"

translate chinese chinese_5638484_67:
    old "Position 3"
    new "位置3"

translate chinese chinese_7974605_68:
    old "Continue"
    new "继续"

translate chinese chinese_1537079_69:
    old "(Aaaand, here it is, another erection...) Mike... I need to use your bathroom.... You can keep watching..."
    new "（啊哈，又来了，另一个勃起……）迈克……我需要去一下洗手间……你可以继续看……"

translate chinese chinese_3302860_70:
    old "Ok, man. It's my turn again..."
    new "好吧，轮到我了..."

translate chinese chinese_9878745_71:
    old "Handjob"
    new "手淫"

translate chinese chinese_7522833_72:
    old "Blowjob"
    new "口交"

translate chinese chinese_0793255_73:
    old "Hi [pla]. If you're looking for Mike, he's in his room."
    new "你好[pla]。如果你找迈克的话，他在房间里。"

translate chinese chinese_6421393_74:
    old "Ok, thank you, Mrs. White."
    new "好的，谢谢怀特夫人。"

translate chinese chinese_4047670_75:
    old "Hey big boy... Don't you want to go to the bathroom again?"
    new "嘿大男孩……你不想要再去厕所吗？"

translate chinese chinese_5957380_76:
    old "...I...Umm... What... do you mean?"
    new "……我……嗯……什么……意思？"

translate chinese chinese_5094139_77:
    old "I mean don't leave me waiting. I will be in there if you want to go at it again..."
    new "我的意思是别让我等太久。如果你想再来一次，我就在里面。"

translate chinese chinese_0585182_78:
    old "Hey, handsome... Are you looking for some help?"
    new "嘿， handsome... 你在找帮助吗？"

translate chinese chinese_0416969_79:
    old "Wh... Huh?... Nah, I was... Looking for Mike..."
    new "什... 啊？... 不，我刚才... 在找迈克..."

translate chinese chinese_5687067_80:
    old "Ok, honey. Mmm, I will be in the bathroom waiting for you..."
    new "好啦，亲爱的。嗯，我在浴室等你……"

translate chinese chinese_4450594_81:
    old "...Yeah, I'm looking for Mike, I... I will go to his bedroom, excuse me."
    new "...是的，我在找迈克，我...我要去他的卧室，不好意思。"

translate chinese chinese_5927334_82:
    old "(Daaaamn!).... I'm sorry, ma'am. I'm leaving right now."
    new "（真他妈的！）……对不起，女士，我现在就走。"

translate chinese chinese_2434989_83:
    old "Ohh. I'm sorry. Silly me, I forgot to close the curtains... Haha! But don't you worry. I know what you're going to do and maybe I can give you some... inspiration..."
    new "哦。对不起。我忘了拉窗帘了……哈哈！不过别担心，我知道你要做什么，也许我可以给你一些……灵感……"

translate chinese chinese_2936418_84:
    old "I... don't know... what you're talking about. (Gulp)"
    new "我……不知道……你在说什么。（咽了口唾沫）"

translate chinese chinese_2088886_85:
    old "Ohh, come on... you're about to burst in those shorts of yours... Just let it out. Mmm, I wanna see it..."
    new "哦呵，别忍了……你那短裤都快绷不住了……就让它出来吧。嗯，我想看看它……"

translate chinese chinese_8521890_86:
    old "...O-Ok."
    new "...好、好的。"

translate chinese chinese_3841133_87:
    old "That's right... Stroke that big cock for mommy..."
    new "没错……给妈妈撸那个大鸡巴……"

translate chinese chinese_8620092_88:
    old "Nice... Mmm, what a good load, [pla]..."
    new "不错……嗯，射得真爽，[pla]……"

translate chinese chinese_3914631_89:
    old "...That was intense..."
    new "……刚才真是紧张刺激……"

translate chinese chinese_1923362_90:
    old "Thank you, honey... I hope we have a bathroom rondevu again."
    new "谢谢你，亲爱的……希望我们还能再来一次浴室幽会。"

translate chinese chinese_5400199_91:
    old "I... I... have to go, Mrs. White."
    new "我……我……得走了，怀特夫人。"

translate chinese chinese_0294772_92:
    old "Whoa... That was crazy..."
    new "谁啊……那真是太疯狂了……"

translate chinese chinese_9791406_93:
    old "I better go home."
    new "我还是回家吧。"

translate chinese chinese_1203676_94:
    old "(Oh shit... Again).... I'm sorry, I'm leaving right now."
    new "（哦shit... 又来了）.... 对不起，我现在就走。"

translate chinese chinese_7289341_95:
    old "Mmm, I knew you would come... I was waiting for you, [pla]."
    new "嗯，我就知道你会来……我一直在这里等你，[pla]。"

translate chinese chinese_3320962_96:
    old "Ohh, come on... Just let it out. I wanna see it again..."
    new "哦，别这样了……就让我看看吧。我想再看一次……"

translate chinese chinese_2636358_97:
    old "Thank you, honey... I hope we have a bathroom rendezvous again."
    new "谢谢你，亲爱的……希望我们还能在卫生间相聚。"

translate chinese chinese_0895823_98:
    old "Hey handsome, I was waiting for you."
    new "喂， handsome，我在等你呢。"

translate chinese chinese_2162524_99:
    old "Come on, don't be shy. Take that monster out and get to jerking..."
    new "来吧，别害羞了。把那怪物拿出来，开始自渎吧……"

translate chinese chinese_4363981_100:
    old "Would you mind if I give you a hand?"
    new "你介不介意我帮你一下？"

translate chinese chinese_8392960_101:
    old "(Is this really happening?) W- What?"
    new "（这真的在发生吗？）什、什么？"

translate chinese chinese_6435267_102:
    old "You can come whenever you want and, I'll give you a hand, my pleasure, okay?"
    new "你想来就来，我会帮你，这是我乐意做的，好吗？"

translate chinese chinese_5454778_103:
    old "Yes, ma'am."
    new "是的，小姐。"

translate chinese chinese_6809171_104:
    old "Get out before Mike suspects anything..."
    new "快走，在迈克起疑之前..."

translate chinese chinese_2134064_105:
    old "Ok, Mrs. White... "
    new "好的，怀特夫人..."

translate chinese chinese_6893198_106:
    old "Hmm, what a big load..."
    new "哼，好大一堆……"

translate chinese chinese_9840671_107:
    old "Wow... She jerked me off..."
    new "wow... 她给我手淫了..."

translate chinese chinese_7264389_108:
    old "I should take my ass home."
    new "我该带我的屁股回家了。"

translate chinese chinese_2655253_109:
    old "Come on, Take off your pants. I have a little surprise for you..."
    new "来吧，把裤子脱了。我有个小惊喜给你..."

translate chinese chinese_4352030_110:
    old "I will be waiting for you handsome..."
    new "我会等着你这位帅 guy 的..."

translate chinese chinese_6217874_111:
    old "Hmm, that tasted so good!"
    new "嗯，那个味道真好！"

translate chinese chinese_1723935_112:
    old "Wow... W- what just happened?"
    new "哇……刚发生了什么？"

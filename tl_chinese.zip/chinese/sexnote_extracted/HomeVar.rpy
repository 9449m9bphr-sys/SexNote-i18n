# auto-tl Qwen Colab

translate chinese chinese_7240714_0:
    old "What do you want? I'm busy with the website..."
    new "你想要什么？我正忙着搞网站呢……"

translate chinese chinese_2072576_1:
    old "Do you need some help?"
    new "你需要帮忙吗？"

translate chinese chinese_5179121_2:
    old "No, I need to be alone..."
    new "不，我需要一个人..."

translate chinese chinese_4602266_3:
    old "Ok... (What is wrong with her?)"
    new "好吧...（她到底怎么了？）"

translate chinese chinese_3255185_4:
    old "Hey [sis], I was thinking about repeat a photoshoot."
    new "嘿[sis]，我在想要不要再拍一次写真。"

translate chinese chinese_0065736_5:
    old "Do you want to repeat a photoshoot?"
    new "你想重拍一次写真吗？"

translate chinese chinese_3362149_6:
    old "Right, I think it would be useful to have more photos even with the same outfits..."
    new "对了，我觉得即使穿同样的衣服，多拍些照片也会有用……"

translate chinese chinese_3397072_7:
    old "Alright, you are the nerd here."
    new "好吧，你是这里的书呆子。"

translate chinese chinese_3444886_8:
    old "Which photoshoot should we repeat?"
    new "我们应该重拍哪一组照片？"

translate chinese chinese_1964277_9:
    old "The first one"
    new "第一个"

translate chinese chinese_2490254_10:
    old "Good choice..."
    new "好选择……"

translate chinese chinese_5763305_11:
    old "The second one"
    new "第二个"

translate chinese chinese_0226092_12:
    old "Hmm I really like that one..."
    new "嗯，我真的很喜欢那个..."

translate chinese chinese_4280759_13:
    old "The third one"
    new "第三个"

translate chinese chinese_0393373_14:
    old "Great, let's go to the pool..."
    new "好啊，去游泳池吧……"

translate chinese chinese_6011659_15:
    old "The fourth one"
    new "第四个"

translate chinese chinese_6540407_16:
    old "Oh, I love this photoshoot..."
    new "哦，我太爱这次拍摄了..."

translate chinese chinese_8608249_17:
    old "Are you ready to work on the website?"
    new "准备好开始做网站了吗？"

translate chinese chinese_7467992_18:
    old "Yeah, I think so."
    new "是的，我也这么觉得。"

translate chinese chinese_3472327_19:
    old "So, what are we waiting for? Let's work!"
    new "那，我们在等什么？开工吧！"

translate chinese chinese_4758600_20:
    old "Mmm, what do we have here?"
    new "嗯，这是什么？"

translate chinese chinese_0257171_21:
    old "(Gulp) Well..."
    new "（咽了口唾沫）嗯……"

translate chinese chinese_3566381_22:
    old "I already know... You want my help, right?"
    new "我已经知道了……你想要我的帮助，对吧？"

translate chinese chinese_1909609_23:
    old "With all my pleasure! Hehe."
    new "非常乐意！嘿嘿。"

translate chinese chinese_2517195_24:
    old "Glad that you came, quite on time for applying the sunscreen, would you help me again?"
    new "很高兴你来了，正好赶上涂防晒霜，你能再帮我一次吗？"

translate chinese chinese_0599693_25:
    old "Hmm, Sure."
    new "嗯，好啊。"

translate chinese chinese_2174163_26:
    old "I can't right now..."
    new "我现在不行……"

translate chinese chinese_2377414_27:
    old "Oh, it's a shame, I was expecting a new skin care therapy..."
    new "哦，真可惜，我还指望一个新的护肤疗法呢……"

translate chinese chinese_7092980_28:
    old "Alright, I will be here taking a sunbath if you change your mind..."
    new "好吧，如果你改变主意了，我就在这里晒太阳等着……"

translate chinese chinese_7561961_29:
    old "Great, I wanted to have some fun today..."
    new "太好了，我今天想玩得开心点……"

translate chinese chinese_2374592_30:
    old "So, what do you want to do today?"
    new "那，今天你想做什么？"

translate chinese chinese_1196330_31:
    old "Boobs"
    new "胸部"

translate chinese chinese_6869571_32:
    old "Hmm I think would be great for the next photoshoot, to focus on your boobs..."
    new "嗯，我觉得下次拍摄可以重点拍你的胸部……"

translate chinese chinese_7115158_33:
    old "I like that too... Al right, let's do it..."
    new "我也喜欢那个……好吧，我们就这么做吧……"

translate chinese chinese_1756937_34:
    old "Ready to fuck them?"
    new "准备好了吗？要去干他们了？"

translate chinese chinese_5827250_35:
    old "Uhhh, that's it. I love how much it is, let me spread it all over, I am ready to take a sunbath."
    new "呃，就这个了。我喜欢它的量，让我全身都抹上，我准备好要晒日光浴了。"

translate chinese chinese_5485625_36:
    old "Thanks for your help again, [pla]"
    new "再次感谢你的帮助，[pla]"

translate chinese chinese_7325181_37:
    old "You are welcome, always trying to help."
    new "不客气，我总是尽力帮忙。"

translate chinese chinese_4637595_38:
    old "Hahaha Sure."
    new "哈哈，好吧。"

translate chinese chinese_2883311_39:
    old "Ass"
    new "屁股"

translate chinese chinese_0016407_40:
    old "Hmm I think would be great for the next photoshoot, to focus on your ass..."
    new "嗯，我觉得下次拍摄可以重点拍你的屁股……"

translate chinese chinese_2016721_41:
    old "Oh yeah, let's focus on my ass..."
    new "哦 yeah，还是关注我的屁股吧..."

translate chinese chinese_7363226_42:
    old "You can touch all you want! I love it."
    new "你想摸哪儿就摸哪儿吧！我超喜欢的。"

translate chinese chinese_8164829_43:
    old "Alright, now let's fuck!"
    new "好了，现在让我们干吧！"

translate chinese chinese_6755981_44:
    old "Uhhh, it was delicious..."
    new "呃，真好吃……"

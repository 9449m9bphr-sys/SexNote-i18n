# auto-tl Qwen Colab

translate chinese chinese_2731730_0:
    old "Talk to her."
    new "和她聊聊。"

translate chinese chinese_9326862_1:
    old "Hmm, are we starting or what?"
    new "哼，我们要开始吗？"

translate chinese chinese_6144055_2:
    old "Uhh... E- excuse me?"
    new "呃……对不起？"

translate chinese chinese_4249425_3:
    old "I'm asking you if we're going to study or something."
    new "我在问你我们是要去学习还是什么的。"

translate chinese chinese_4694597_4:
    old "Because you just stayed there staring at me like a creep."
    new "因为你就在那边像变态一样盯着我看。"

translate chinese chinese_3002996_5:
    old "S- sorry, I- I didn't notice I was doing it."
    new "对不起，我...我没意识到自己在这么做。"

translate chinese chinese_3371861_6:
    old "I was just passing by and wanted to say hello."
    new "我刚好路过，想打个招呼。"

translate chinese chinese_0257985_7:
    old "That's it? Alright."
    new "就这些？好吧。"

translate chinese chinese_2194434_8:
    old "But make sure to come back soon. We’ve got a lot to study."
    new "但是记得很快回来。我们还有很多要学习的。"

translate chinese chinese_3243272_9:
    old "Sure, don't worry about it. I'll see you soon."
    new "好吧，别担心，很快见。"

translate chinese chinese_8363965_10:
    old "Hey, what's up? Did you come to study with me?"
    new "嘿，最近怎么样？你是来跟我一起学习的吗？"

translate chinese chinese_3376730_11:
    old "Hey, oh no, I can't right now, I just wanted to say hi."
    new "嘿，哦不，我现在不行，我只是想打个招呼。"

translate chinese chinese_8015957_12:
    old "Hmm, alright, but make sure you come back soon."
    new "嗯，好吧，但你要尽快回来。"

translate chinese chinese_8091946_13:
    old "So we can hit the books together."
    new "我们可以一起学习。"

translate chinese chinese_9295192_14:
    old "Sure thing."
    new "没问题。"

translate chinese chinese_5974064_15:
    old "Excuse me [pla], do you need anything?"
    new "不好意思，[pla]，你需要什么吗？"

translate chinese chinese_9917483_16:
    old "Uhmm, no, sorry ma'am, I- uh- I was just passing by."
    new "嗯，不，对不起女士，我—呃—我只是路过。"

translate chinese chinese_4222129_17:
    old "I see... Well, I guess I'll see you around then."
    new "我明白了……那好吧，改天见。"

translate chinese chinese_8453636_18:
    old "Hello [pla], how are you today?"
    new "你好[pla]，今天怎么样？"

translate chinese chinese_0886385_19:
    old "Hello Mrs. Priya, I'm fine, how about you?"
    new "你好，Priya夫人，我很好，你呢？"

translate chinese chinese_7154533_20:
    old "I'm doing alright."
    new "我挺好的。"

translate chinese chinese_1823491_21:
    old "Tell me, do you need anything?"
    new "告诉我，你需要什么？"

translate chinese chinese_8239623_22:
    old "Oh, not really. I just wanted to say hello."
    new "哦，也不是啦。我只是想打个招呼。"

translate chinese chinese_4635666_23:
    old "I see, well, I guess I'll see you around then."
    new "我明白了，那猜猜什么时候见吧。"

translate chinese chinese_6661001_24:
    old "Sure thing ma'am, see you."
    new "好的，再见。"

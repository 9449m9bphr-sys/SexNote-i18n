# auto-tl Qwen Colab

translate chinese chinese_3569174_0:
    old "So? Are you ready to do something useful with your life?"
    new "那么？你准备开始做些有意义的事情了吗？"

translate chinese chinese_7439670_1:
    old "Umm..."
    new "嗯……"

translate chinese chinese_1124638_2:
    old "I don't feel comfortable with a young pervert around me, but your [mo1rel] asked me to do this for you..."
    new "我身边有个年轻色鬼让我觉得很不自在，但你的[mo1rel]让我为你做这件事……"

translate chinese chinese_8324720_3:
    old "Which means that this is an opportunity for you to see how to make some money..."
    new "这意味着这是一个让你看看怎么赚钱的机会..."

translate chinese chinese_4112617_4:
    old "Sweet! You're going to teach me?"
    new "太好了！你要教我？"

translate chinese chinese_3680917_5:
    old "Oh, hell no! I'm not your damn teacher. Just do what I tell you. And watch what I do, then maybe you will learn on your own..."
    new "哦，去你的！我不是你妈老师。你就按我说的做。看着我怎么做，也许你自己就能学会了..."

translate chinese chinese_7325261_6:
    old "Ok, ok... So what do you need me to do?"
    new "好啦好啦……那你需要我做什么？"

translate chinese chinese_8009685_7:
    old "First of all, I don't need you. I'm letting you work for me and learn."
    new "首先，我不需要你。我让你为我工作并学习。"

translate chinese chinese_6613879_8:
    old "Secondly, if you try to peep on me at work or do something perverted, I will fire your ass. Understood?"
    new "其次，如果你敢在我工作时偷看或者做些变态的事情，我就炒了你。明白了吗？"

translate chinese chinese_4840558_9:
    old "(This is going to be harder than I thought.)"
    new "(这比我想象的要难得多。)"

translate chinese chinese_3708740_10:
    old "Hey! I'm not a-"
    new "喂！我可不是..."

translate chinese chinese_2331388_11:
    old "Shut up! Pervert!"
    new "闭嘴！色狼！"

translate chinese chinese_8838671_12:
    old "...Ok. So, you are my boss now and I will respect you... Is that better?"
    new "...好吧。所以你现在是我的老板，我会尊重你……这样行了吗？"

translate chinese chinese_4391196_13:
    old "That's the respect you have to show me all the time, got it?. But enough talk, [pla]. Let's get to work!"
    new "这就是你得一直对我表现出的尊重，懂了吗？不过说够了，[pla]，开始工作吧！"

translate chinese chinese_7607414_14:
    old "Nice. What do you need me to do?"
    new "不错。你需要我做什么？"

translate chinese chinese_9640644_15:
    old "I need you to take these documents to my office and give them to the secretary. Then come back to me."
    new "我需要你把这些文件送到我的办公室，交给秘书，然后再回来找我。"

translate chinese chinese_0398567_16:
    old "As you wish."
    new "如你所愿。"

translate chinese chinese_9577159_17:
    old "Done! I already delivered the documents to Akita."
    new "好了！我已经把文件交给秋田了。"

translate chinese chinese_7404501_18:
    old "Well, was that very difficult?"
    new "嗯，这很难吗？"

translate chinese chinese_2918132_19:
    old "Hmm, not really..."
    new "嗯，不太……"

translate chinese chinese_1967566_20:
    old "Alright. Look for me tomorrow to take a new delivery to Akita..."
    new "好吧。明天来找我，有个新的送货任务去秋田……"

translate chinese chinese_2371715_21:
    old "I must deliver the documents to Akita first."
    new "我必须先把这些文件交给秋田。"

translate chinese chinese_0612244_22:
    old "Are you ready to work today? I don't want any interruptions from you..."
    new "你今天准备好工作了吗？我不希望你有任何打扰……"

translate chinese chinese_2774635_23:
    old "Ready to work for you"
    new "随时为你服务"

translate chinese chinese_6453704_24:
    old "Ok then, You know what to do. Take these documents to my secretary, then come back to me..."
    new "好吧，你知道该怎么做。把这些文件交给我的秘书，然后回来找我……"

translate chinese chinese_8873025_25:
    old "Of course, [mo2]!"
    new "当然了，[mo2]！"

translate chinese chinese_5084242_26:
    old "Not now"
    new "现在不行"

translate chinese chinese_8195430_27:
    old "Actually, I have to do something first... I'll talk to you later."
    new "其实我有个事情要先处理……待会儿再聊。"

translate chinese chinese_7092831_28:
    old "Ugh. Ok, [pla]. Don't waste my time. Come talk to me when you're really ready"
    new "唉，好吧，[pla]。别浪费我的时间。等你真的准备好了再来找我。"

translate chinese chinese_0263042_29:
    old "Uh... Nothing, I was just going to my bedroom, sorry."
    new "呃……没什么，我只是要去卧室，对不起。"

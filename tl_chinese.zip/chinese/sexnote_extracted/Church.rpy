# auto-tl Qwen Colab

translate chinese chinese_1661920_0:
    old "She is praying, I shouldn't bother her."
    new "她在祈祷，我不要打扰她。"

translate chinese chinese_2319767_1:
    old "Oh, hi young man, are you the one who accompanied Lydia a few days ago?"
    new "哦，你好小伙子，你是前几天陪莉迪亚的那个吗？"

translate chinese chinese_7707242_2:
    old "Yes Mrs. Jones, my name is [pla], nice to meet you."
    new "是的，琼斯夫人，我叫[pla]，很高兴见到您。"

translate chinese chinese_6914173_3:
    old "Excellent [pla], I think it's very good that you visit the church."
    new "非常好 [pla]，我觉得你去教堂参观很好。"

translate chinese chinese_3841442_4:
    old "Many young people should be like you."
    new "很多年轻人都应该像你这样。"

translate chinese chinese_1366921_5:
    old "Oh no, I just-"
    new "哦不，我刚——"

translate chinese chinese_8392596_6:
    old "Today all young people think about is sex, parties and devil things."
    new "现在年轻人都只想着性、派对和那些乱七八糟的事。"

translate chinese chinese_0461125_7:
    old "Did you know that sister Grace is organizing the church choir?"
    new "你知道格蕾丝姐姐正在组织教堂合唱团吗？"

translate chinese chinese_3735634_8:
    old "If you want I could introduce you, so you could continue on your way to the Lord."
    new "如果你愿意，我可以介绍你认识他，让你继续走向领主的道路。"

translate chinese chinese_3407082_9:
    old "Well, actually-"
    new "其实，"

translate chinese chinese_9909489_10:
    old "Perfect! I'll talk to sister Grace, she'll be very happy."
    new "太好了！我去跟Grace姐姐说，她会很高兴的。"

translate chinese chinese_5021956_11:
    old "Ok ..."
    new "好吧……"

translate chinese chinese_7564195_12:
    old "Oh, hi [pla], how are you doing."
    new "哦，嗨 [pla]，你最近怎么样。"

translate chinese chinese_9232988_13:
    old "Hi, Mrs. Jones, I'm great thanks, what about you?"
    new "嗨，琼斯夫人，我很好，谢谢，您呢？"

translate chinese chinese_1110467_14:
    old "I'm fine, waiting for the next mass."
    new "我没事，等着下次行动。"

translate chinese chinese_6467554_15:
    old "Do you need something hun?"
    new "亲爱的，你需要什么？"

translate chinese chinese_8562469_16:
    old "Honey?"
    new "亲爱的？"

translate chinese chinese_1227337_17:
    old "Not now."
    new "现在不行。"

translate chinese chinese_7814805_18:
    old "Oh no, don't worry, I just wanted to say hi."
    new "哦不，别担心，我只是想打个招呼。"

translate chinese chinese_8655214_19:
    old "Alright, thank you hun, see you later."
    new "好啦，谢谢亲爱的，待会儿见。"

translate chinese chinese_8373591_20:
    old "Bye, Mrs. Jones."
    new "再见，琼斯夫人。"

translate chinese chinese_2453597_21:
    old "(Wow!)"
    new "（哇！）"

translate chinese chinese_2193551_22:
    old "(Sister Grace is really attractive...)"
    new "（格蕾丝姐姐真有魅力……）"

translate chinese chinese_4620276_23:
    old "(Should I use the Agamoto eye?)"
    new "（我该用阿戈马托之眼吗？）"

translate chinese chinese_6941739_24:
    old "Yes"
    new "是的"

translate chinese chinese_3789796_25:
    old "(Oh my...)"
    new "（天啊……）"

translate chinese chinese_7950042_26:
    old "No"
    new "不"

translate chinese chinese_3661150_27:
    old "(I better get back to work.)"
    new "（我还是回去工作吧。）"

translate chinese chinese_2679548_28:
    old "(Mrs. Jones's skirt went up quite a bit...)"
    new "（琼斯太太的裙子抬得很高……）"

translate chinese chinese_2676056_29:
    old "Wow! I knew you would have been fast but I didn't expect that much."
    new "哇！我知道你会很快，但没想到这么快。"

translate chinese chinese_4509119_30:
    old "Haha, thanks Sister Grace... I like to do things as fast as possible."
    new "哈哈，谢谢格蕾丝姐……我喜欢尽快把事情搞定。"

translate chinese chinese_2106446_31:
    old "I wonder if you're that good at everything... Great job!"
    new "不知道你是不是样样都这么厉害……干得不错！"

translate chinese chinese_1974434_32:
    old "Anyway, it's already very late, and I think we should all rest now, see you again tomorrow."
    new "反正现在已经很晚了，我觉得我们都应该休息了，明天见。"

translate chinese chinese_4520879_33:
    old "Thank you, so much for your help Mrs. Jones and [pla]."
    new "谢谢你这么帮忙，琼斯夫人和[pla]。"

translate chinese chinese_9076923_34:
    old "Alright, see you tomorrow."
    new "好吧，明天见。"

translate chinese chinese_2621316_35:
    old "Oh, it's too late and we can't finish cleaning."
    new "哦，太晚了，我们没法打扫完了。"

translate chinese chinese_8626537_36:
    old "Well, today was a bit harder than usual..."
    new "嗯，今天比平时要难一些……"

translate chinese chinese_9468480_37:
    old "Don't worry, I can stay and finish the cleaning."
    new "别担心，我可以留下来把打扫做完。"

translate chinese chinese_0189013_38:
    old "Oh no! It's fine, we'll finish tomorrow..."
    new "哦不！没关系，我们明天再继续吧..."

translate chinese chinese_4647454_39:
    old "It's fine, just hurry a little more next time and we will make it."
    new "没关系，下次快一点我们就赶上了。"

translate chinese chinese_6486274_40:
    old "I guess the next time will be better."
    new "我想下次会好一点吧。"

translate chinese chinese_2878849_41:
    old "Sure, it will!, anyway see you again tomorrow."
    new "行吧，到时候见。"

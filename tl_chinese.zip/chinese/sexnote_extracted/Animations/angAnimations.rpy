# auto-tl Qwen Colab

translate chinese chinese_3432688_0:
    old "Are you enjoying it, honey?"
    new "亲爱的，你爽吗？"

translate chinese chinese_1819257_1:
    old "Mmm, yes, this one is giving me a pretty warm and wet sensation."
    new "嗯，是的，这个给我一种温暖湿润的感觉。"

translate chinese chinese_6729027_2:
    old "Okay, you're doing a great job, now try to do it a little faster."
    new "好的，你做得很好，现在试着加快一点速度。"

translate chinese chinese_7761697_3:
    old "Oh yeah, just like that honey, don't stop, you are gonna make him cum soon..."
    new "哦 yeah，就这样宝贝，别停，你很快就会让他射了..."

translate chinese chinese_8185084_4:
    old "!!!"
    new "!!!"

translate chinese chinese_4692304_5:
    old "Slurp, slurp."
    new "咕噜，咕噜。"

translate chinese chinese_0904799_6:
    old "Ok, you've had enough, you can cum now [pla]."
    new "好了，你够了，现在可以射了，[pla]。"

translate chinese chinese_4264606_7:
    old "W- what?"
    new "什、什么？"

translate chinese chinese_8440362_8:
    old "Ughhh..."
    new "呃……"

translate chinese chinese_3175437_9:
    old "Huh, what is this?"
    new "咦，这是什么？"

translate chinese chinese_4879167_10:
    old "WHAT THE FUCK!"
    new "妈的！"

translate chinese chinese_9122244_11:
    old "WHO THE HELL ARE YOU?!!"
    new "你特么是谁?!"

translate chinese chinese_2438934_12:
    old "Ok [pla], I need you to show her your tricky fingers..."
    new "好的 [pla]，你需要展示你的花哨手指给她看..."

translate chinese chinese_5820624_13:
    old "More speed and a bit of more pressure, she needs to enjoy more, to get hornier."
    new "加快速度，再加点力道，她需要获得更多快感，更兴奋一些。"

translate chinese chinese_8552711_14:
    old "Uhh... It f- feels nice..."
    new "嗯……感觉很舒服……"

translate chinese chinese_9807913_15:
    old "Yes, just like that, [pla]."
    new "没错，就是这样，[pla]。"

translate chinese chinese_2762388_16:
    old "[pla], I want you to be tough now, press them hardly, feel them, touch them all."
    new "[pla]，我要你现在强硬一点，用力按压她们，感受她们，触摸每一个地方。"

translate chinese chinese_9870575_17:
    old "Ok."
    new "好的。"

translate chinese chinese_5445927_18:
    old "Do you like it Angelina?"
    new "你喜欢吗，安吉丽娜？"

translate chinese chinese_6336194_19:
    old "... Y- yes."
    new "... 是的。"

translate chinese chinese_6580731_20:
    old "Perfect, now that we feel a bit more confident with each other let's move to the other exercise, in this case in the practice bedroom."
    new "完美，现在我们互相感觉更自信一点了，让我们去进行下一个练习，在这个情况下是去练习卧室。"

translate chinese chinese_0233883_21:
    old "Do you like it?"
    new "你喜欢吗？"

translate chinese chinese_2558193_22:
    old "Yes, it feels a bit... Nice."
    new "是的，感觉有点……舒服。"

translate chinese chinese_7305030_23:
    old "You needed a better trained person to start enjoying it, let's make it more interesting, [pla], I want you to do it faster."
    new "你需要一个训练更好的人来享受这个，让我们让它更有趣一点，[pla]，我要你加快速度。"

translate chinese chinese_9169949_24:
    old "How do you feel now?"
    new "你现在感觉怎么样？"

translate chinese chinese_9801895_25:
    old "Ahh! I- I am... Starting to feel... n- nice."
    new "啊！我—我开始感觉…很舒服。"

translate chinese chinese_6898480_26:
    old "Ok, [pla], I want you to make her cum, do your thing!"
    new "好的，[pla]，让她高潮吧，尽情表现！"

translate chinese chinese_9544892_27:
    old "Ohhh...  Don't stop, ahh! Nngh!"
    new "哦哦……不要停，啊嗯！"

translate chinese chinese_1097285_28:
    old "Oh God! OH GOD! I feel like I'm going to... EXPLODE!"
    new "哦天啊！哦天啊！我觉得我要... 爆炸了！"

translate chinese chinese_1003143_29:
    old "Wonderful!"
    new "太棒了！"

translate chinese chinese_5987958_30:
    old "Oh God... I had never felt this before..."
    new "哦上帝……我从没感受过这种感觉……"

translate chinese chinese_6384841_31:
    old "So, what do you feel Angelina?"
    new "那么，天使丽娜，你觉得呢？"

translate chinese chinese_1175215_32:
    old "Hmm, It's really hard and tasteful."
    new "嗯，真的很有硬度，而且很讲究。"

translate chinese chinese_4816549_33:
    old "That's perfect, how are you feeling, [pla]?"
    new "太好了，感觉怎么样，[pla]？"

translate chinese chinese_3316821_34:
    old "Hmm... Slurp, slurp."
    new "嗯……哧溜，哧溜。"

translate chinese chinese_1747612_35:
    old "Right, that's the best answer. Just enjoy it guys."
    new "对，这就是最好的回答。大家享受一下吧。"

translate chinese chinese_2574215_36:
    old "You think you can hold on a bit more [pla]?"
    new "你觉得你能再坚持一下吗，[pla]？"

translate chinese chinese_5231876_37:
    old "Perfect, now Angelina, I want you to give him all you have, I want you to make him cum."
    new "完美，现在安吉丽娜，我要你把他的一切都拿走，我要你让他射。"

translate chinese chinese_2992047_38:
    old "Mmm, ok."
    new "嗯，好吧。"

translate chinese chinese_7045494_39:
    old "Don't stop now, he is almost done, he will cum any time, so, keep moving your head."
    new "别停，他快完了，随时都可能射，所以继续动你的头。"

translate chinese chinese_7968079_40:
    old "Slurp, slurp...!"
    new "咕噜，咕噜...！"

translate chinese chinese_5960823_41:
    old "Ahh!"
    new "啊！"

translate chinese chinese_7258828_42:
    old "Wow, that's a lot of cum, I think I did it."
    new "哇，好多精液，我觉得我做到了。"

translate chinese chinese_9872516_43:
    old "You did amazing!"
    new "你太棒了！"

translate chinese chinese_1028052_44:
    old "[pla], since Angelina is not so experienced I need you to be as gentle as you can be, she can't do it like me, so pease start softly."
    new "[pla]，因为Angelina经验不足，你需要尽可能温柔一些，她做不到像我这样，所以请轻柔开始。"

translate chinese chinese_5210556_45:
    old "Sure, I'll try my best."
    new "行，我会尽力的。"

translate chinese chinese_4983262_46:
    old "Mmm it hurts a bit... But it also feels good..."
    new "嗯，有点疼……但也感觉很好……"

translate chinese chinese_7160875_47:
    old "Told you. [pla] please, speed it up a bit, I want you to make her scream a bit, you already know how to do it."
    new "跟你说过了。[pla] 求求你了，快一点，我想让你让她尖叫一声，你已经知道怎么做了。"

translate chinese chinese_3782718_48:
    old "Are you satisfied Angelina?"
    new "你满意了吗，安吉丽娜？"

translate chinese chinese_0079927_49:
    old "Ohhh... Yess..."
    new "哦哦……是的……"

translate chinese chinese_4011147_50:
    old "And we've got even more to go, so [pla], give her more!"
    new "而且我们还有更多要进行的，所以[pla]，再给她更多！"

translate chinese chinese_7425999_51:
    old "Got it."
    new "收到。"

translate chinese chinese_1551597_52:
    old "HOLLY SHIT! AHHH!"
    new "Holy Shit! 啊！"

translate chinese chinese_0910331_53:
    old "Don't stop, she's about to cum!"
    new "别停，她快来了！"

translate chinese chinese_4283325_54:
    old "NNGH!"
    new "嗯咕！"

translate chinese chinese_6298324_55:
    old "[pla], finish with her!"
    new "[pla]，搞定她！"

translate chinese chinese_7297748_56:
    old "I feel like an explosion inside just like the other day, I- I... AHH!"
    new "我感觉里面像前几天一样爆炸了，我—我……啊！"

translate chinese chinese_7493803_57:
    old "That's impressive, you are doing it really really good, do you like it [pla]?"
    new "真厉害，你做得真的很棒，你喜欢这样吗，[pla]？"

translate chinese chinese_2087492_58:
    old "Absolutely!"
    new "绝对！"

translate chinese chinese_6891917_59:
    old "(She's getting really good at it.)"
    new "（她越来越擅长这样了。）"

translate chinese chinese_5070640_60:
    old "I'm glad to see you feel more confident with your partner."
    new "很高兴看到你对你伴侣更有信心了。"

translate chinese chinese_4932794_61:
    old "That's great, don't stop, remember is your husband pleasure what we are talking about."
    new "太好了，别停，记住我们在谈论的是你丈夫的快感。"

translate chinese chinese_3873760_62:
    old "Now suck it faster, show me those blowjob skills."
    new "现在吸快点，展示一下你的口技。"

translate chinese chinese_9618869_63:
    old "Woow!"
    new "哇！"

translate chinese chinese_0260444_64:
    old "Wow, I can see it's getting closer, do it faster, you want him to cum, don't you?"
    new "哇，我看快要到了，快点，你想要他射吧？"

translate chinese chinese_6866381_65:
    old "Yes!"
    new "是的！"

translate chinese chinese_9218448_66:
    old "So, do it as fast as you can... make him cum in your throat!"
    new "所以，动作快点……让他在你喉咙里射精！"

translate chinese chinese_3346046_67:
    old "Ahh yes! Take it."
    new "啊哈，对了！拿去。"

translate chinese chinese_9038011_68:
    old "Wonderful, did you like it Angelina?"
    new "太棒了，安吉丽娜，你喜欢吗？"

translate chinese chinese_6661296_69:
    old "That's my girl."
    new "真是我的好姑娘。"

translate chinese chinese_7918099_70:
    old "Oh yeah, ride him Angelina, jump on him and fuck him."
    new "哦 yeah，骑上他吧 Angelina，跳上去狠狠干他。"

translate chinese chinese_5138301_71:
    old "I didn't know riding was so intense, this is definitely the position I like the most."
    new "我不知道骑马这么刺激，这绝对是我的最爱姿势。"

translate chinese chinese_3183034_72:
    old "(Oh wow, she moves really good, I like it.)"
    new "（哦 wow，她动作真流畅，我喜欢。）"

translate chinese chinese_7426279_73:
    old "Oh God! I don't want to stop, we should do this for a week..."
    new "哦天啊！我不想去停下来，我们应该这样持续一周……"

translate chinese chinese_3746878_74:
    old "I like it too."
    new "我也喜欢。"

translate chinese chinese_0384912_75:
    old "Fuck him Angelina, fuck [pla] hard!"
    new "操他吧天使娜，狠狠地操[pla]！"

translate chinese chinese_1187899_76:
    old "Ahhh..."
    new "啊hhh..."

translate chinese chinese_8803416_77:
    old "Ahhh... Your dick is so hard that I want to hit it faster."
    new "啊hhh... 你的 dicks 如此硬挺，我好想更快地抽动它。"

translate chinese chinese_2842268_78:
    old "Fuck him harder, just as you want!"
    new "把他操得更狠点，就按你想要的来！"

translate chinese chinese_5906649_79:
    old "Ahh! This is really delicious, I don't want to stop."
    new "啊！这真的很好吃，我不想停下来。"

translate chinese chinese_6737278_80:
    old "I really love this, I want to feel you cuming."
    new "我真的好喜欢这样，想要感受你的高潮。"

translate chinese chinese_9702560_81:
    old "I- I can't hold it anymore."
    new "我-我真的忍不住了。"

translate chinese chinese_3985890_82:
    old "Mmm, I- I want more... May I have another round?"
    new "嗯，我—我还想要更多……可以再来一轮吗？"

translate chinese chinese_8396976_83:
    old "Wow girl, you're insatiable... Well, if [pla] says she can go on, that's fine with me, we still have time."
    new "wow girl, 你真是个尤物……好吧，如果 [pla] 说她还能继续，那我就没意见了，时间还来得及。"

translate chinese chinese_8875330_84:
    old "Uhh... Yes, I guess..."
    new "呃……是啊，我想……"

translate chinese chinese_7086659_85:
    old "Ok, now you fuck me, I want you to make me cum again."
    new "好，现在你给我干，我要你让我再高潮一次。"

translate chinese chinese_1488411_86:
    old "A- Alright..."
    new "好……"

translate chinese chinese_0810741_87:
    old "Oh yes, just like that. I have to say my husband is not as big as you."
    new "哦，是的，就是这样。我得说，我老公没有你这么大。"

translate chinese chinese_3351669_88:
    old "Your huge cock makes me feel so much more!"
    new "你那巨大的 cocks 让我感觉好多了！"

translate chinese chinese_1442513_89:
    old "Mmmm, it feels really nice, but I want more!"
    new "嗯，感觉真好，但我还想更多！"

translate chinese chinese_8074090_90:
    old "Give me more of your cock. I want you to fuck me harder!"
    new "给我更多的你的cock。我要你更用力地操我！"

translate chinese chinese_5689997_91:
    old "Uhhhh... Holly Shit! This is soo good."
    new "呃呃呃……Holy Shit！这真是太好了。"

translate chinese chinese_0128322_92:
    old "Don't stop baby, keep fucking me hard!"
    new "别停宝贝，继续狠狠地操我！"

translate chinese chinese_3591071_93:
    old "I want you to make me cum! Please [pla], make cum!"
    new "我想让你让我高潮！求你了[pla]，给我高潮！"

translate chinese chinese_2756960_94:
    old "Ahhh! Ahhh! Oh my God!"
    new "啊hhh! 啊hhh! 哦天啊!"

translate chinese chinese_1147960_95:
    old "(Uhh... Doctor Johnson has been a bit quiet, that's weird)"
    new "（呃……约翰逊医生一直很安静，这挺奇怪的）"

translate chinese chinese_2204022_96:
    old "Yes! Yes! I- I cumming again! Ahhh!"
    new "是的！是的！我—我又要来了！啊hhh！"

translate chinese chinese_8964967_97:
    old "Mmmm, it was so good."
    new "嗯，真不错。"

translate chinese chinese_6887174_98:
    old "Great job guys, I can tell you that the sessions have been very efficient..."
    new "干得好，我可以告诉你们这些会议非常高效……"

translate chinese chinese_3047132_99:
    old "Angelina as you can see you will be very happy with your husband!"
    new "安吉丽娜，你看，你会非常幸福的和你的丈夫在一起！"

translate chinese chinese_0510786_100:
    old "Mmm... Oh God, this feeling..."
    new "嗯……哦上帝，这种感觉……"

translate chinese chinese_7647982_101:
    old "And the size of your cock!"
    new "还有你那玩意儿的大小！"

translate chinese chinese_4169777_102:
    old "It brings so much back!"
    new "这让我想起了好多事情！"

translate chinese chinese_5302545_103:
    old "I haven't felt this way in forever!"
    new "我好久都没有这种感觉了！"

translate chinese chinese_5999347_104:
    old "I've missed feeling this way!"
    new "我好久没这种感觉了！"

translate chinese chinese_2945985_105:
    old "Slrrp! It's been so long!"
    new "湿吻！真是好久了！"

translate chinese chinese_6913809_106:
    old "This is nothing like my husband!"
    new "这完全不像我老公！"

translate chinese chinese_0550083_107:
    old "I love how good it tastes!"
    new "我爱它的味道！"

translate chinese chinese_8936896_108:
    old "Oh it makes me feel so good!"
    new "哦，这让我感觉太好了！"

translate chinese chinese_6723287_109:
    old "Angelina! I-I can't hold it in anymore!"
    new "安吉丽娜！我忍不住了！"

translate chinese chinese_8920883_110:
    old "Oh yes! I want you to let it out!"
    new "哦，是的！我想让你尽情释放！"

translate chinese chinese_6186702_111:
    old "Let me taste it!"
    new "让我尝一下！"

translate chinese chinese_2431925_112:
    old "Mmm that felt so good."
    new "嗯，感觉真好。"

translate chinese chinese_8259377_113:
    old "It was amazing."
    new "太棒了。"

translate chinese chinese_7000882_114:
    old "Uh, yeah, I guess so."
    new "嗯，应该是吧。"

translate chinese chinese_3732547_115:
    old "But hey, let’s get up and clean this up before Lisa walks in and sees us."
    new "不过好了，咱们起来把这收拾一下，别让丽莎进来看到了。"

translate chinese chinese_7997048_116:
    old "Sure, sure."
    new "好吧，好吧。"

translate chinese chinese_4065013_117:
    old "How are you feeling Angelina?"
    new "安吉丽娜，你觉得怎么样？"

translate chinese chinese_1839746_118:
    old "Great! That was fantastic! I want more!"
    new "太棒了！太精彩了！我还想要更多！"

translate chinese chinese_8828974_119:
    old "Hmm, yeah sure."
    new "嗯，好吧。"

translate chinese chinese_8255878_120:
    old "Mmm! Oh yes!"
    new "嗯！哦，是的！"

translate chinese chinese_7463393_121:
    old "Oh God! this feels amazing!"
    new "哦天啊！这感觉太棒了！"

translate chinese chinese_6278680_122:
    old "Oh [pla], this is just what I wanted!"
    new "哦 [pla]，这正是我想要的！"

translate chinese chinese_8646311_123:
    old "Oh God [pla] I love it!"
    new "哦天啊 [pla] 我爱死这个了！"

translate chinese chinese_1468463_124:
    old "This is so good!"
    new "这真是太好了！"

translate chinese chinese_0383279_125:
    old "My God [pla], I love the way you're doing it!"
    new "天啊[pla]，我就喜欢你这样！"

translate chinese chinese_7871335_126:
    old "This is amazing [pla]!"
    new "这太棒了[pla]！"

translate chinese chinese_2351340_127:
    old "Oh yes! Ah! AH!"
    new "哦 yeah! 哦！AH!"

translate chinese chinese_7654017_128:
    old "Oh [pla]!"
    new "哦 [pla]！"

translate chinese chinese_4561143_129:
    old "How do you feel?"
    new "你觉得怎么样？"

translate chinese chinese_2094262_130:
    old "I feel amazing [pla]!"
    new "我感觉太棒了[pla]！"

translate chinese chinese_5720280_131:
    old "That's the best sex I've ever had!"
    new "这是我有史以来最好的性爱！"

translate chinese chinese_4759067_132:
    old "Heh, that's good to hear."
    new "嘿嘿，听到这个真好。"

translate chinese chinese_5865661_133:
    old "Great! That was fantastic! I want more, please!"
    new "太好了！太棒了！我要更多，请！"

translate chinese chinese_5221811_134:
    old "Yeah, that’s what I thought..."
    new "嗯，就是这么回事……"

translate chinese chinese_8326633_135:
    old "Ohhh, yeah... it feels so deep..."
    new "哦哦，是的……感觉好深……"

translate chinese chinese_8551149_136:
    old "Mmm, this is the best!"
    new "嗯，这真是太好了！"

translate chinese chinese_9109224_137:
    old "Oh God, oh God! It's amazing."
    new "哦天哪，哦天哪！太棒了。"

translate chinese chinese_2193978_138:
    old "It feels so good..."
    new "感觉真好……"

translate chinese chinese_5613574_139:
    old "Ohh fuck, yes, yes, faster, faster [pla]..."
    new "哦哦fuck，对，对，快点，再快点[pla]..."

translate chinese chinese_5741843_140:
    old "Mmm, that's right, don't stop [pla], don't stop!"
    new "嗯，对，不要停[pla]，不要停！"

translate chinese chinese_6252425_141:
    old "Oh my God! Yes, yes!"
    new "天啊！是的，是的！"

translate chinese chinese_4492113_142:
    old "[pla], I'm about to cum, don't stop, give me more, give me more!"
    new "[pla]，我要来了，不要停，再多一点，再多一点！"

translate chinese chinese_4242460_143:
    old "Ohhh that was amazing... Oh my God."
    new "哦哦，太棒了……天啊。"

translate chinese chinese_7855061_144:
    old "[pla], you really have no idea how wonderful that was."
    new "[pla]，你真的不知道那有多棒。"

translate chinese chinese_3869848_145:
    old "You're feeling better now, right?"
    new "你现在感觉好些了吧？"

translate chinese chinese_1994174_146:
    old "Ohh, you have no idea."
    new "哦，你根本不知道。"

translate chinese chinese_3682613_147:
    old "I'm glad, but, let’s get up and clean this up before Lisa walks in and sees us."
    new "我很高兴，但是我们还是赶紧起来收拾一下吧，免得丽莎进来看到我们。"

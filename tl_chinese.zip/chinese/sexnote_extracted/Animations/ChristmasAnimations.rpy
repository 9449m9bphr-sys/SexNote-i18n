# auto-tl Qwen Colab

translate chinese chinese_2143562_0:
    old "Ok [pla], just make sure to enjoy it."
    new "好的[pla]，只要确保玩得开心就行了。"

translate chinese chinese_3298296_1:
    old "Mmmmm."
    new "嗯嗯嗯。"

translate chinese chinese_4792204_2:
    old "Yes, like that, do you like the taste of his dick?"
    new "是的，那样，你喜欢他的味道吗？"

translate chinese chinese_4387097_3:
    old "Mmm! Slurrp!"
    new "嗯！吸吮声！"

translate chinese chinese_0750496_4:
    old "Hahaha, that’s right. Enjoy it, put it all in your mouth."
    new "哈哈，对了。尽情享受，全部放进嘴里。"

translate chinese chinese_4227908_5:
    old "It’s so big, it can’t even fit it in her mouth."
    new "太大了，她根本塞不进嘴里。"

translate chinese chinese_6765193_6:
    old "Is it feeling good [pla]?"
    new "感觉不错吧，[pla]？"

translate chinese chinese_5655985_7:
    old "Y- yes, it feels really good."
    new "是的，感觉真的很好。"

translate chinese chinese_4028977_8:
    old "It's so fucking huge..."
    new "它真是大得离谱……"

translate chinese chinese_9603424_9:
    old "And it’s throbbing in my mouth."
    new "而且它在我嘴里跳动。"

translate chinese chinese_9026461_10:
    old "I think he’s getting close."
    new "我觉得他快到了。"

translate chinese chinese_1009409_11:
    old "That’s right, keep pushing that cock in your mouth!"
    new "没错，继续用嘴巴套着那个鸡巴！"

translate chinese chinese_4109080_12:
    old "Are you cummin [pla]?"
    new "你快要射了嘛 [pla]?"

translate chinese chinese_6165982_13:
    old "Ughh... Y- yes..."
    new "呃……是的……"

translate chinese chinese_7439189_14:
    old "Then do it! Cum! Fill her mouth!"
    new "那就来吧！射！灌满她的嘴！"

translate chinese chinese_1621711_15:
    old "Ughhh! Ahhh!!!"
    new "呃赫！啊赫！！！"

translate chinese chinese_6683120_16:
    old "That looked great!"
    new "看起来很棒！"

translate chinese chinese_2686636_17:
    old "It really did."
    new "确实如此。"

translate chinese chinese_1244957_18:
    old "You see Mildret? We knew you would enjoy it."
    new "你看到梅尔德雷特了吗？我们知道你会喜欢的。"

translate chinese chinese_4759014_19:
    old "It was... good."
    new "那……挺好的。"

translate chinese chinese_5512189_20:
    old "These bodies are certainly incredible."
    new "这些身体真是棒极了。"

translate chinese chinese_1311857_21:
    old "And the taste... I feel I could get used to it."
    new "而且那味道……我觉得我可以习惯。"

translate chinese chinese_4743529_22:
    old "Hahaha, it’s good to see you’re enjoying the ritual."
    new "哈哈，看你这么享受这个仪式也不错。"

translate chinese chinese_5999945_23:
    old "What about if we get ready to enjoy that cock inside us?"
    new "如果我们准备好享受那根棒在里面呢？"

translate chinese chinese_4677851_24:
    old "That's a good idea..."
    new "这是个好主意……"

translate chinese chinese_3975925_25:
    old "All right."
    new "好吧。"

translate chinese chinese_0866639_26:
    old "How is the ritual going Linett?"
    new "仪式进行得怎么样了，林奈特？"

translate chinese chinese_8278297_27:
    old "It’s good, I was able to stabilize a breaching point."
    new "还好，我稳定了一个裂缝。"

translate chinese chinese_6582615_28:
    old "But to open it I’m going to need an even bigger magic discharge."
    new "但是要打开它，我需要更大的魔法释放。"

translate chinese chinese_8543005_29:
    old "Oh, don’t worry, that’s what’s coming just now. Or maybe I meant cumming..."
    new "哦，别担心，刚才那只是个开头。或者我应该是说射了……"

translate chinese chinese_1009102_30:
    old "This is where we really enjoy it."
    new "这才是我们真正享受的地方。"

translate chinese chinese_1831184_31:
    old "Let’s do it then."
    new "那我们就干吧。"

translate chinese chinese_8888787_32:
    old "This is still new for me [pla]. So remember to be gentle."
    new "这对我来说还是新的，[pla]。所以记得温柔一点。"

translate chinese chinese_4392488_33:
    old "Sure."
    new "行吧。"

translate chinese chinese_6530649_34:
    old "Mmm, this sensation. It’s so strong."
    new "嗯，这种感觉。太强烈了。"

translate chinese chinese_2425691_35:
    old "And so big, incredible."
    new "而且这么大，难以置信。"

translate chinese chinese_3094639_36:
    old "Move a little faster [pla]."
    new "动作快一点，[pla]。"

translate chinese chinese_9467645_37:
    old "Oh! It feels so hot!"
    new "哦！好烫啊！"

translate chinese chinese_7255137_38:
    old "Yes, enjoy it Mildret. Do you like his cock inside you?"
    new "是的，享受吧，米德尔特。你喜欢他的棒子在里面吗？"

translate chinese chinese_4649559_39:
    old "I do, I really like it!"
    new "我喜欢，真的喜欢！"

translate chinese chinese_6717344_40:
    old "Ahh! Ahh! This is amazing!"
    new "啊！啊！太棒了！"

translate chinese chinese_0224685_41:
    old "It feels so good!"
    new "感觉真好！"

translate chinese chinese_5004454_42:
    old "Do it some more, keep going!"
    new "再来点，继续！"

translate chinese chinese_1433885_43:
    old "This feeling, I think I’m cumming!"
    new "这种感觉，我要来了！"

translate chinese chinese_1657280_44:
    old "You hear that [pla]? Make her Cum!"
    new "你听见了吗[pla]？让她高潮！"

translate chinese chinese_6508943_45:
    old "Ahh! Y- yes!"
    new "啊！是的！"

translate chinese chinese_1710485_46:
    old "So, did you like it?"
    new "所以，你觉得怎么样？"

translate chinese chinese_6227484_47:
    old "It was very good."
    new "非常好。"

translate chinese chinese_5418032_48:
    old "I’m glad you enjoyed it, but it’s my turn now."
    new "我很高兴你喜欢，但现在轮到我了。"

translate chinese chinese_4076580_49:
    old "I actually wonder how it’s going to be with this small body."
    new "我其实好奇有了这副小身板会怎么样。"

translate chinese chinese_9551414_50:
    old "I hope it’s going to be as good as last time."
    new "希望这次能和上次一样好。"

translate chinese chinese_0508244_51:
    old "Only one way to find out..."
    new "只有一个办法能搞清楚……"

translate chinese chinese_6680744_52:
    old "Ohh! Ahh! It’s so big!"
    new "哦！啊！好大啊！"

translate chinese chinese_0797500_53:
    old "It fills me up, completely."
    new "这让我感到完全满足。"

translate chinese chinese_7757395_54:
    old "Uhhh it hurts, but still feels so good!"
    new "呃，好疼，但感觉还是那么爽！"

translate chinese chinese_4280479_55:
    old "Yes, yes, just like that."
    new "对，就是这样。"

translate chinese chinese_8228969_56:
    old "I love how your cock feels."
    new "我喜欢你的棒棒的感觉。"

translate chinese chinese_9996909_57:
    old "Ohhh yeah, with this little body feels even better!."
    new "哦哦 yeah，有了这小身体感觉更好！."

translate chinese chinese_9915058_58:
    old "Do you like how he pounds your pussy Devonne?"
    new "你喜欢他这样弄你吗，德冯ne？"

translate chinese chinese_7227496_59:
    old "Ah, Ah, YES!"
    new "啊，啊，是的！"

translate chinese chinese_0164296_60:
    old "I love it! I love it!"
    new "我爱死这个了！我爱死这个了！"

translate chinese chinese_4509098_61:
    old "I want to keep doing it in this body forever!"
    new "我想永远用这副身体继续做这件事！"

translate chinese chinese_7898343_62:
    old "I’m cummin! I can feel it!"
    new "我要射了！感觉到了！"

translate chinese chinese_9200999_63:
    old "M- me too!"
    new "我也是！"

translate chinese chinese_7366355_64:
    old "Do it! Cum in me!"
    new "来吧！在里面射！"

translate chinese chinese_6635898_65:
    old "That was sooo good."
    new "那真是太好了。"

translate chinese chinese_6499909_66:
    old "I think I could get addicted to it."
    new "我觉得我会上瘾的。"

translate chinese chinese_7168999_67:
    old "And I think it felt even better because of how small this body is."
    new "而且我觉得因为这身体很小，感觉更好了。"

translate chinese chinese_7658614_68:
    old "Hmm, now you’ve made me crave it even more!"
    new "哼，现在你让我更想吃了！"

translate chinese chinese_6053979_69:
    old "Come on [pla] let’s finish the ritual."
    new "来吧[pla]，我们完成这个仪式吧。"

translate chinese chinese_4257862_70:
    old "You’ve done a lot [pla]."
    new "你已经做得很多了，[pla]。"

translate chinese chinese_5660480_71:
    old "So you must be tired, but don’t falter now."
    new "所以你肯定累了，但 jetzt 不要松懈。"

translate chinese chinese_8518227_72:
    old "S- sure."
    new "好……好吧。"

translate chinese chinese_5948480_73:
    old "Oh yes! That’s just what I wanted."
    new "哦，是吗！这正是我想要的。"

translate chinese chinese_7068121_74:
    old "That’s right [pla]. Fill her all the way up."
    new "说得好，[pla]。让她彻底满足。"

translate chinese chinese_0230141_75:
    old "And go a little faster."
    new "再快一点。"

translate chinese chinese_3051527_76:
    old "Ah, Ah, your cock, it’s reaching so deep!"
    new "啊，啊，你的棒子插得好深！"

translate chinese chinese_2550118_77:
    old "And it feels so hot as you penetrate me!"
    new "而且你进入我的时候感觉这么热！"

translate chinese chinese_8143912_78:
    old "I can feel it throbbing in me. I love how it feels!"
    new "我能感觉到它在我体内跳动。我爱这种感觉！"

translate chinese chinese_5613667_79:
    old "Ohh! Ohh! YES!"
    new "哦！哦！是的！"

translate chinese chinese_6792857_80:
    old "This is great!"
    new "太好了！"

translate chinese chinese_2643837_81:
    old "I feel the magic pushing in!"
    new "我感觉魔法正在涌进来！"

translate chinese chinese_9862267_82:
    old "I’m about to cum!"
    new "我要射了！"

translate chinese chinese_4643270_83:
    old "M- me too"
    new "我也是"

translate chinese chinese_0661090_84:
    old "I can’t hold it anymore!"
    new "我忍不住了！"

translate chinese chinese_3303096_85:
    old "Let it go!"
    new "算了吧！"

translate chinese chinese_4918341_86:
    old "Shoot your magic in my pussy!"
    new "把你的魔法射到我的 pussy 里！"

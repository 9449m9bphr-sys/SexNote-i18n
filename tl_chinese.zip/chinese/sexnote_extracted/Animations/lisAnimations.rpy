# auto-tl Qwen Colab

translate chinese chinese_0621220_0:
    old "Just relax and feel all my body, focus on the new sensations."
    new "放松点，感受我的身体，专注于这些新的感觉。"

translate chinese chinese_4853506_1:
    old "Can you feel my breast over your back?"
    new "能感觉到我胸部贴在你背上吗？"

translate chinese chinese_2460242_2:
    old "Y- yeah..."
    new "嗯……"

translate chinese chinese_6137979_3:
    old "I'm going to do it faster so you can feel more all my energy."
    new "我要加快速度，让你更感受到我的全部力量。"

translate chinese chinese_2472328_4:
    old "You are very connected with the moment and the environment, it means we can go beyond, you are ready for the next step."
    new "你非常融入当下的环境，这意味着我们可以更进一步，你已经准备好下一步了。"

translate chinese chinese_9238550_5:
    old "... Ok."
    new "...好。"

translate chinese chinese_2403860_6:
    old "Please lie down now on your back so we can expose the parts of your body that we need to balance the energy."
    new "请现在仰卧，这样我们可以暴露需要平衡能量的身体部位。"

translate chinese chinese_8090240_7:
    old "We can heal your body together, we can heal each other, please follow my instructions so you can release all these negative experiences..."
    new "我们可以一起治愈你的身体，互相治愈，请按照我的指示做，这样你可以释放所有这些负面经历……"

translate chinese chinese_6648894_8:
    old "Please lie down on your back, so we can take the negative energy out..."
    new "请躺下来，这样我们可以把负能量去掉..."

translate chinese chinese_3022899_9:
    old "Ok, we are done now, let's do the next exercise..."
    new "好了，我们现在结束，来做下一个练习吧……"

translate chinese chinese_1012611_10:
    old "Is it pleasant?"
    new "感觉舒服吗？"

translate chinese chinese_7371420_11:
    old "Yes..."
    new "是的..."

translate chinese chinese_5424583_12:
    old "Keep breathing, that is the key, your muscles must get extremely relaxed, my hands will clean the bad energies, let them do their job."
    new "保持呼吸，这是关键，你的肌肉必须极度放松，我的手会清除那些负能量，让它们发挥作用。"

translate chinese chinese_6164483_13:
    old "Please let yourself go, do not think about anything else, I will move faster so you can't release the tension, so you can let the chakra muladhara to be cleaned."
    new "请放松自己，不要想其他事情，我会加快速度，让你无法释放紧张，这样你可以让密陀哈轮得到净化。"

translate chinese chinese_6468981_14:
    old "Do you feel the negative chakra leaving?"
    new "你觉得负面气场消散了吗？"

translate chinese chinese_3147872_15:
    old "Let it out... Breath and let it out."
    new "呼出来……深呼吸，然后呼出来。"

translate chinese chinese_5563839_16:
    old "Phew..."
    new "呼……"

translate chinese chinese_3431843_17:
    old "Wow, that was wonderful, our job had abundant results."
    new "哇，太棒了，我们的工作成果丰硕。"

translate chinese chinese_9593325_18:
    old "Do you feel my boobs?"
    new "感受一下我的胸部？"

translate chinese chinese_2556158_19:
    old "Let it move... Feel me, I can see your body is doing it great..."
    new "让它动起来……感受我，我能感觉到你的身体很出色……"

translate chinese chinese_9379851_20:
    old "I can see it's hard to fight with your chakra muladhara but we can try harder than that, stay focused and just release the negative energy..."
    new "我能看出用你的基础脉轮战斗很困难，但我们还可以更努力一些，保持专注，释放负面能量就行了……"

translate chinese chinese_1884913_21:
    old "Yes, breath, and feel how your energy is moving...  I want you to let it go..."
    new "没错，呼吸，感受你的能量流动……我要你释放它……"

translate chinese chinese_7296937_22:
    old "Do you feel relieved?"
    new "你觉得松了一口气吗？"

translate chinese chinese_4253980_23:
    old "Great, we will need to continue working on it but you are doing amazing."
    new "很好，我们还需要继续努力，但你做得非常棒。"

translate chinese chinese_5162224_24:
    old "Oh, yes... Just like that..."
    new "哦，是的……就那样……"

translate chinese chinese_0164114_25:
    old "You really have a big cock... It feels... Good."
    new "你真的很大……感觉……很好。"

translate chinese chinese_4492287_26:
    old "Wow, uhhh, yes [pla] keep doing it..."
    new "哇，嗯，是的 [pla] 继续……"

translate chinese chinese_1836648_27:
    old "Lisa, I'm goig to c- cum..."
    new "丽莎，我要射了..."

translate chinese chinese_7342145_28:
    old "Oh, cum all over me."
    new "哦，射里面吧。"

translate chinese chinese_3301902_29:
    old "Feel the fire of the universe with each kiss, you must know the universe is healing your body."
    new "每个吻都感受到宇宙的火焰，你一定知道宇宙正在治愈你的身体。"

translate chinese chinese_4294875_30:
    old "Yeah, I can feel it."
    new "是的，我能感觉到。"

translate chinese chinese_7945941_31:
    old "I will do it more intense so you feel the healing power of the universe at its fullest expression."
    new "我会做得更激烈一些，让你感受到宇宙治愈力量的极致表达。"

translate chinese chinese_8118979_32:
    old "I will take that energy out."
    new "我会把那股劲头耗掉的。"

translate chinese chinese_1146723_33:
    old "I- I'm goin-"
    new "我—我正要去—"

translate chinese chinese_4540733_34:
    old "Let it flow [pla], let it flow."
    new "让它流吧 [pla]，让它流吧。"

translate chinese chinese_5078435_35:
    old "Oh [pla], what amazing energy you have."
    new "哦 [pla]，你真有活力。"

translate chinese chinese_2673035_36:
    old "Oh yes, I'm feeling the universe through you..."
    new "哦，是的，我通过你感受到了整个宇宙……"

translate chinese chinese_7867337_37:
    old "OH GOD, I NEED IT HARDER INSIDE OF ME!"
    new "哦天啊，我要更用力！"

translate chinese chinese_7259145_38:
    old "Let all your energy cum inside me, I need to feel it."
    new "把所有能量都射进我身体里，我要感受它。"

translate chinese chinese_1990643_39:
    old "Ohh man, look at that, this is so fucking hot!"
    new "哦天，看看这个，真是辣眼睛！"

translate chinese chinese_5602850_40:
    old "Hey, keep it down, they could hear you."
    new "嘿，小声点，他们会听到的。"

translate chinese chinese_7073286_41:
    old "Alright, alright."
    new "好吧，好吧。"

translate chinese chinese_3337618_42:
    old "God damn it! This is getting me on!"
    new "该死！这真让我生气！"

translate chinese chinese_2498286_43:
    old "Hey! Keep it down!"
    new "喂！小声点！"

translate chinese chinese_6793666_44:
    old "Listen, dude, do you think you could leave for a couple of minutes?"
    new "听着，兄弟，你能离开几分钟吗？"

translate chinese chinese_9167013_45:
    old "What? Hell no! What the hell are you thinking?"
    new "什么？去你的！你在想些什么？"

translate chinese chinese_9570022_46:
    old "Oh they're going faster! This is fucking amazing."
    new "哦，他们更快了！这真是太棒了。"

translate chinese chinese_8060146_47:
    old "I'm glad you like it man, but hey, we gotta go."
    new "我很高兴你喜欢，不过我们得走了。"

translate chinese chinese_6175615_48:
    old "Ohhh no, please just a little more, I think they're about to finish."
    new "哦不，求你了再坚持一会儿，我觉得他们快结束了。"

translate chinese chinese_5531103_49:
    old "Hmm, alright."
    new "嗯，好吧。"

translate chinese chinese_1643996_50:
    old "Oh wow, that's the fucking best. I wasn't expecting that today."
    new "哦 wow，真是他妈的太好了。我今天根本没想到会这样。"

translate chinese chinese_0643731_51:
    old "Thanks man."
    new "谢谢兄弟。"

translate chinese chinese_7496360_52:
    old "No problem bro, but let's get out of here before they see us."
    new "没问题兄弟，但在他们看到我们之前先离开这里。"

translate chinese chinese_9678435_53:
    old "Mmm, this is just what I needed."
    new "嗯，这正是我需要的。"

translate chinese chinese_0815520_54:
    old "{i}(What a weird position to do that.){/i}"
    new "{i}（真是个奇怪的姿势。）{/i}"

translate chinese chinese_2200723_55:
    old "{i}(I guess it has to do with her whole yoga thing.){/i}"
    new "{i}（大概和她的瑜伽有关。）{/i}"

translate chinese chinese_8235904_56:
    old "Oh yes! I can sense the energy moving!"
    new "哦，是的！我能感觉到能量在流动！"

translate chinese chinese_5713729_57:
    old "{i}(So I guess I was right, it has to do with the yoga thing.){/i}"
    new "{i}(看来我是对的，这和瑜伽有关。){/i}"

translate chinese chinese_9328416_58:
    old "Oh! Oh, I can feel the energy flowing."
    new "哦！我能感觉到能量在流动。"

translate chinese chinese_7119314_59:
    old "{i}(Damn! This is so fucking hot...){/i}"
    new "{i}(妈的，这真是热死了……){/i}"

translate chinese chinese_8238158_60:
    old "Oh! Oh yeah!"
    new "哦！对对对！"

translate chinese chinese_5280981_61:
    old "Ah! Ah! That's right!"
    new "啊！啊！对了！"

translate chinese chinese_8260742_62:
    old "I can feel it! My Muladhara chakra is in full harmony!"
    new "我感觉到了！我的根基脉轮完全和谐了！"

translate chinese chinese_7805182_63:
    old "That was absolutely perfect!"
    new "那简直完美极了！"

translate chinese chinese_2863813_64:
    old "And just what I needed, what a wonderful thing."
    new "这正是我需要的，真是太好了。"

translate chinese chinese_3390887_65:
    old "I can feel the energy flowing through my entire body."
    new "我能感觉到能量流遍全身。"

translate chinese chinese_0876616_66:
    old "I'm ready to continue my day now."
    new "我现在准备继续我的一天了。"

# auto-tl Qwen Colab

translate chinese chinese_5093248_0:
    old "Oh yes, just like that. Does it feel nice hun?"
    new "哦，就是这样。感觉不错吧，宝贝？"

translate chinese chinese_8696654_1:
    old "Mmmm yeah, it feels really nice."
    new "嗯哼，感觉真不错。"

translate chinese chinese_6899769_2:
    old "Great, just relax and enjoy the... Uhmm massage."
    new "好啦，放松点，享受这...按摩吧。"

translate chinese chinese_8730528_3:
    old "Let me do it a bit faster."
    new "让我快一点。"

translate chinese chinese_1401126_4:
    old "Uhmm? does it hurt darling??"
    new "嗯？疼吗，亲爱的？？"

translate chinese chinese_0544609_5:
    old "No, no, don't worry. It feels better."
    new "不，不，别担心。感觉好多了。"

translate chinese chinese_3478118_6:
    old "Ohh, ok, I'm glad."
    new "哦，好的，我很高兴。"

translate chinese chinese_8923843_7:
    old "Hmm, [mo1rel]? Would you please do it faster?"
    new "嗯，[mo1rel]？你能快一点吗？"

translate chinese chinese_2740950_8:
    old "Ohh, of course hun."
    new "哦，当然了，亲爱的。"

translate chinese chinese_3428827_9:
    old "Ohhh yes, yes, just like this."
    new "哦哦，对，就是这样。"

translate chinese chinese_8415243_10:
    old "I can feel that body is tensing up. You can release your load whenever you want, darling."
    new "我能感觉到你的身体在紧张。你想什么时候射就什么时候射，亲爱的。"

translate chinese chinese_4120354_11:
    old "Mmmm, [mo1rel] I- I feel like I'm going to explode..."
    new "嗯，[mo1rel] 我觉得我要爆炸了..."

translate chinese chinese_6978439_12:
    old "It's alright honey, just let it all go."
    new "没事的宝贝，就让它都过去吧。"

translate chinese chinese_0648317_13:
    old "Ahhh... Ahhhh!"
    new "啊hhh... 啊hhh!"

translate chinese chinese_7385143_14:
    old "Mmmm, good job honey. You did it just great."
    new "嗯，干得好宝贝。你做得很好。"

translate chinese chinese_7779763_15:
    old "-Sigh- Thanks [mo1rel]."
    new "—叹气— 谢了[mo1rel]。"

translate chinese chinese_5391553_16:
    old "Okay, this will definitely help."
    new "好的，这肯定有帮助。"

translate chinese chinese_0544894_17:
    old "Thanks."
    new "谢谢。"

translate chinese chinese_6268401_18:
    old "You are welcome honey, I hope you feel better now."
    new "不客气宝贝，希望你现在感觉好些了。"

translate chinese chinese_0916054_19:
    old "Yes, I do. although I'm feeling a bit tired."
    new "是的，虽然我感觉有点累。"

translate chinese chinese_2757136_20:
    old "Aww, don't worry hun, just rest a little."
    new "别担心宝贝，just休息一下吧。"

translate chinese chinese_0498917_21:
    old "Oh, and remember, don't tell anyone. Especially [mo2]! She wouldn't understand and would kill us!"
    new "哦，还有一件事，不要告诉任何人。尤其是[mo2]！她不会理解的，会杀了我们的！"

translate chinese chinese_7937086_22:
    old "Ok [mo1rel]."
    new "好的[mo1rel]。"

translate chinese chinese_7603189_23:
    old "You know you can always count on me."
    new "你知道你可以随时依赖我。"

translate chinese chinese_4881295_24:
    old "Yes, thank you [mo1rel]."
    new "好的，谢谢[mo1rel]。"

translate chinese chinese_0411726_25:
    old "You are welcome. Well, if you need me, you know where to find me."
    new "不客气。好吧，如果你需要我，知道在哪里找我。"

translate chinese chinese_2214828_26:
    old "Oh my God, I can't believe how big it is."
    new "天啊，我简直不敢相信它有多大。"

translate chinese chinese_0650860_27:
    old "Is the biggest I have ever seen."
    new "是我见过最大的。"

translate chinese chinese_3318297_28:
    old "Do you like how I'm jerking you off?"
    new "你喜欢我这样给你手淫的感觉吗？"

translate chinese chinese_6016343_29:
    old "... Y- yes it feels nice."
    new "... 嗯，感觉不错。"

translate chinese chinese_6598399_30:
    old "Mmm, your cock looks really tasty."
    new "嗯，你的那个看起来真诱人。"

translate chinese chinese_9956361_31:
    old "Are you getting close?"
    new "你快到了吗？"

translate chinese chinese_5892918_32:
    old "Uhh y- yes."
    new "嗯，是的。"

translate chinese chinese_3066560_33:
    old "Would you like to cum for me?"
    new "你想为我高潮吗？"

translate chinese chinese_1079149_34:
    old "Mmmm, [mo1rel] I- I gonna cum..."
    new "嗯，[mo1rel] 我快...来了..."

translate chinese chinese_7887574_35:
    old "Oh yeah, cum for mommy."
    new "哦 yeah，为妈妈射吧。"

translate chinese chinese_0451210_36:
    old "Ughh, that was so intense, [mo1rel]."
    new "哦，那真是太激烈了，[mo1rel]。"

translate chinese chinese_6390715_37:
    old "Mmmm, I'm glad you liked it..."
    new "嗯，很高兴你喜欢……"

translate chinese chinese_3676990_38:
    old "But... Now, let's finish watching this movie."
    new "但是……现在，我们先把这部电影看完吧。"

translate chinese chinese_2029096_39:
    old "For sure."
    new "肯定的。"

translate chinese chinese_8652719_40:
    old "Mmmm, it tastes really good."
    new "嗯，味道真不错。"

translate chinese chinese_4224866_41:
    old "Does it feels better than my hand, isn't it?"
    new "感觉比我的手好多了吧？"

translate chinese chinese_2248051_42:
    old "Uhhh, yeah."
    new "呃，是的。"

translate chinese chinese_5500160_43:
    old "Do you like to feel my warm and wet mouth?"
    new "你喜欢感受我温暖湿润的嘴巴吗？"

translate chinese chinese_4466744_44:
    old "Ohhh, y- yes it feels amazing."
    new "哦哦，是的，感觉好极了。"

translate chinese chinese_6913385_45:
    old "Then there is something that you are going to enjoy even more."
    new "那就有件事你会更喜欢的。"

translate chinese chinese_3587106_46:
    old "Mmmm, I love to suck your cock!"
    new "嗯嗯，我最喜欢吸你的cock了！"

translate chinese chinese_1284686_47:
    old "Would you like to cum in my mouth?"
    new "你想在我嘴里射吗？"

translate chinese chinese_5602920_48:
    old "Wow, can I?"
    new "wow, 我可以吗？"

translate chinese chinese_6756740_49:
    old "Mmmm, please honey. I would love to taste all your load."
    new "嗯嗯，求你了宝贝。我真的想尝尝你的所有精华。"

translate chinese chinese_6641059_50:
    old "Mmmm, [mo1rel], I feel like..."
    new "嗯，[mo1rel]，我觉得..."

translate chinese chinese_8192941_51:
    old "Glurpp... Wow, it was a huge load."
    new "咕噜pp... 哇，真够多的。"

translate chinese chinese_3046575_52:
    old "Glup... Whew, I had to swallow a lot."
    new "咕噜... 哎，我吞了好大一口。"

translate chinese chinese_1305479_53:
    old "It was AMAZING [mo1rel]."
    new "太棒了[mo1rel]。"

translate chinese chinese_1715871_54:
    old "Well, I'm glad you loved it..."
    new "好吧，我很高兴你喜欢它……"

translate chinese chinese_8603616_55:
    old "But now let's continue the movie."
    new "不过现在让我们继续看电影吧。"

translate chinese chinese_8179642_56:
    old "Is this a dream?"
    new "这是梦吗？"

translate chinese chinese_5946588_57:
    old "Oh my gosh! My [mo1rel] it's fucking hot!"
    new "天啊！我的[mo1rel]好热！"

translate chinese chinese_1386556_58:
    old "Holly shit! Look at those tits bouncing!"
    new "Holy shit! 看那对巨乳弹跳的样子！"

translate chinese chinese_4700051_59:
    old "This view is amazing."
    new "这景色太棒了。"

translate chinese chinese_9816946_60:
    old "Wow... That was a dream?"
    new "wow...那只是个梦？"

translate chinese chinese_4409340_61:
    old "It was very strange because it felt very real..."
    new "那感觉非常真实，所以很奇怪……"

translate chinese chinese_2678870_62:
    old "Anyway, I better go to sleep..."
    new "总之，我还是去睡觉吧..."

translate chinese chinese_0583838_63:
    old "Mmmm, it feels really nice."
    new "嗯，感觉真不错。"

translate chinese chinese_2743854_64:
    old "Sorry, did you say something?"
    new "抱歉，你说什么了？"

translate chinese chinese_0894339_65:
    old "Uhmm, no, no sorry."
    new "嗯，不，对不起。"

translate chinese chinese_1422695_66:
    old "(Shit I better stay quiet)"
    new "（糟糕，我得保持安静）"

translate chinese chinese_8935984_67:
    old "Wow honey, did you spill more sunscreen in my legs?"
    new "wow 宝贝，你是不是又把防晒霜洒到我腿上了？"

translate chinese chinese_7305163_68:
    old "(Oh shit...) Yes, I spilled more to make sure, you don't get sunburned."
    new "（哦shit...）是的，我多倒了些，确保你不会被晒伤。"

translate chinese chinese_8797714_69:
    old "Aww, you are a sweetheart."
    new "哎呀，你真是个甜心。"

translate chinese chinese_7243555_70:
    old "(Oh fuck that was close... Should I make another try?)"
    new "（哦靠，那真是太险了……要不要再试一次？）"

translate chinese chinese_7058223_71:
    old "{color=#00b8e7}{b}(-SAURON'S MOUTH POWER ACCOMPLISHED-){/b}{/color} (I can't waste this chance.)"
    new "{color=#00b8e7}{b}(－索伦的口技已完成－){/b}{/color}(我不能错过这个机会。)"

translate chinese chinese_4311371_72:
    old "{b}Sauron's mouth:{/b} Now is your turn... Use your feet to massage me, ok?"
    new "{b}索伦的嘴：{/b} 现在轮到你了……用脚给我按摩一下，好吗？"

translate chinese chinese_3990069_73:
    old "(Holly shit! Is working.)"
    new "（Holy shit! 真的有用。）"

translate chinese chinese_8935443_74:
    old "{color=#d74627}{b}(-INSUFFICIENT SAURON'S MOUTH POWER-){/b}{/color} (No, I shouldn't take risks.)"
    new "{color=#d74627}{b}(-不够萨鲁曼的嘴炮之力-){/b}{/color} (不，我不能冒险。)"

translate chinese chinese_2801488_75:
    old "Well is done, I think you are perfect now."
    new "好吧，我觉得你现在完美了。"

translate chinese chinese_7934885_76:
    old "Aww, thank you so much, see you later sweetheart."
    new "哎呀，太感谢了，一会儿见甜心。"

translate chinese chinese_0984074_77:
    old "Holy shit, I can't help it anymore..."
    new "妈的，我忍不住了..."

translate chinese chinese_2709729_78:
    old "What the fuck?"
    new "什么鬼？"

translate chinese chinese_2583923_79:
    old "(Oh... Shit.)"
    new "（哦... 糟了。）"

translate chinese chinese_4966900_80:
    old "What the fuck were you doing [pla]!?"
    new "你刚才在搞什么[pla]！？"

translate chinese chinese_8456010_81:
    old "Sorry I... I..."
    new "对不起我...我..."

translate chinese chinese_5291111_82:
    old "You were rubbing your... With my ass?"
    new "你在用我的屁股摩擦你的……？"

translate chinese chinese_1342020_83:
    old "I can't believe it! What's wrong with you?"
    new "真不敢相信！你这是怎么了？"

translate chinese chinese_2017726_84:
    old "Sorry... It was not my intention..."
    new "对不起……那不是我的本意……"

translate chinese chinese_7027242_85:
    old "It wasn't your intention? What the fuck?..."
    new "这不是你的本意？什么情况..."

translate chinese chinese_2372804_86:
    old "I... I'll clean it myself, I don't want to see you anymore..."
    new "我……我自己来清理，我不想再见到你了……"

translate chinese chinese_2101635_87:
    old "Oh shit, I messed it up."
    new "哦shit，我搞砸了。"

translate chinese chinese_2704622_88:
    old "Again?"
    new "又来？"

translate chinese chinese_2934157_89:
    old "Oh honey again?"
    new "哦，又是蜂蜜？"

translate chinese chinese_5417496_90:
    old "I'm sorry I couldn't resist, I can't control it"
    new "对不起，我忍不住，控制不了自己"

translate chinese chinese_1750551_91:
    old "Mmm... It's alright, just please try not to rub your... against my ass, ok?"
    new "嗯……没关系，但请你不要摩擦我的屁股，好吗？"

translate chinese chinese_3711479_92:
    old "If you need to release it, you can ask my help or do it by yourself."
    new "如果你需要释放的话，可以请求我的帮助或者自己来。"

translate chinese chinese_7226285_93:
    old "You're right... It was not my intention..."
    new "你说得对……那不是我的本意……"

translate chinese chinese_4825680_94:
    old "I know sweetheart don't worry..."
    new "我知道亲爱的，别担心……"

translate chinese chinese_7556921_95:
    old "I'm going to clean myself."
    new "我要去清理一下自己。"

translate chinese chinese_9884136_96:
    old "{i}Does it turn you on?{/i}"
    new "{i}这让你兴奋吗？{/i}"

translate chinese chinese_5745318_97:
    old "{i}W- what?{/i}"
    new "{i}W-什么？{/i}"

translate chinese chinese_2123859_98:
    old "{i}Does it turn you on, doing it in front of [mo2]?{/i}"
    new "{i}在[mo2]面前做这个会不会让你兴奋？{/i}"

translate chinese chinese_3276440_99:
    old "{i}If she caught us, she will kill us.{/i}"
    new "{i}如果被她发现了，我们会死定了。{/i}"

translate chinese chinese_1212156_100:
    old "{i}That's why we should stop.{/i}"
    new "{i}这就是为什么我们应该停下来。{/i}"

translate chinese chinese_1752166_101:
    old "{i}Oh no, all of this is making me horny.{/i}"
    new "哦不，这些都让我兴奋起来了。"

translate chinese chinese_6865615_102:
    old "{i}Oh yeah, I'm gonna make you cum in front of [mo2].{/i}"
    new "哦对，我要让你在[mo2]面前高潮。"

translate chinese chinese_8187264_103:
    old "{i}...{/i}"
    new "{i}...{/i}"

translate chinese chinese_3486458_104:
    old "{i}Cum quietly!{/i}"
    new "{i}安静点射！{/i}"

translate chinese chinese_0634072_105:
    old "{i}Wow, you still hard... We will need to do something else, right?{/i}"
    new "{i} wow，你还挺硬的……我们需要做点别的，对吧？{/i}"

translate chinese chinese_2533305_106:
    old "{i}Oh come on... No, please we should stop now...{/i}"
    new "{i}哦，拜托……不，求你了，我们现在停下来吧……{/i}"

translate chinese chinese_6831602_107:
    old "{i}Shut up, and take your pants off...{/i}"
    new "{i}闭嘴，把裤子脱了...{/i}"

translate chinese chinese_2224168_108:
    old "{i}You will love this...{/i}"
    new "{i}你会喜欢这个的...{/i}"

translate chinese chinese_8515562_109:
    old "{i}Holy Shit!{/i}"
    new "{i}卧槽！{/i}"

translate chinese chinese_3494417_110:
    old "Uhhh... No, no, I- I'm just excited by the movie..."
    new "呃……不，不，我——我只是对这部电影很兴奋……"

translate chinese chinese_1365766_111:
    old "Can't you see a movie quietly?"
    new "你不能安静地看个电影吗？"

translate chinese chinese_2129477_112:
    old "Yes, yes I- I'm sorry."
    new "是的，是的，对不起。"

translate chinese chinese_2378683_113:
    old "{i}Shhh, just relax and enjoy...{/i}"
    new "{i}嘘，放松点，享受一下...{/i}"

translate chinese chinese_1203414_114:
    old "{i}Do you realize I'm giving you a blowjob almost in front of [mo2]?{/i}"
    new "{i}你意识到我几乎是在[mo2]面前给你口交吗？{/i}"

translate chinese chinese_4428325_115:
    old "{i}Yeah, that's crazy.{/i}"
    new "{i}是啊，真疯狂。{/i}"

translate chinese chinese_7932406_116:
    old "{i}Actually, is behind [mo2], and it sounds even naughtier... Hehehe.{/i}"
    new "{i}实际上，是在[mo2]后面，听起来更 naughty……嘿嘿嘿。{/i}"

translate chinese chinese_0032389_117:
    old "{i}How much did you drink?{/i}"
    new "{i}你喝了多少？{/i}"

translate chinese chinese_5994166_118:
    old "{i}Are you ready for my oral creampie?{/i}"
    new "{i}你准备好接受我的口爆了嗎？{/i}"

translate chinese chinese_0113213_119:
    old "{i}I want to kiss [mo2], after that, hahaha.{/i}"
    new "{i}我想吻[mo2]，之后，呵哈哈。{/i}"

translate chinese chinese_7532709_120:
    old "{i}Wow it was a lot... Did you like it?{/i}"
    new "{i}哇，真的很多……你喜欢吗？{/i}"

translate chinese chinese_9658510_121:
    old "{i}Hell yeah, it was great...{/i}"
    new "{i}太棒了...{/i}"

translate chinese chinese_6435534_122:
    old "{i}Let's clean this mess quietly.{/i}"
    new "{i}我们悄悄地清理这个烂摊子吧。{/i}"

translate chinese chinese_3732645_123:
    old "Wow the movie was great, right [pla]?"
    new "哇，这部电影真棒，对吧，[pla]？"

translate chinese chinese_6647562_124:
    old "Oh yes, it was awesome."
    new "哦 yeah，太棒了。"

translate chinese chinese_5043585_125:
    old "I thought it was stupid... Anyway I'm going bed."
    new "我觉得这很蠢……不管怎样，我要去睡觉了。"

translate chinese chinese_7549353_126:
    old "Yes, good night honey, sleep well."
    new "好的，晚安亲爱的，睡个好觉。"

translate chinese chinese_8509675_127:
    old "Good night"
    new "晚安"

translate chinese chinese_6639204_128:
    old "Do you like my tits, isn't it?"
    new "你喜欢我的胸部，对吧？"

translate chinese chinese_2706913_129:
    old "Well, I think you deserve a great titjob."
    new "嗯，我觉得你应该得到一次很棒的胸腔服务。"

translate chinese chinese_7944521_130:
    old "How does it feel to have your [mo1rel] tits around your cock?"
    new "感觉你的[mo1rel]胸部环绕着你的丁丁是什么滋味？"

translate chinese chinese_8216534_131:
    old "Uhh... It feels amazing!"
    new "呃……感觉太棒了！"

translate chinese chinese_3154879_132:
    old "Mmmm, I'm enjoying it too."
    new "嗯，我也很享受。"

translate chinese chinese_5488253_133:
    old "Would you like to cum on my tits?"
    new "你想在我胸口射吗？"

translate chinese chinese_6073010_134:
    old "Oh yeah."
    new "哦，对了。"

translate chinese chinese_2588123_135:
    old "So, cum on your [mo1rel]'s tits."
    new "所以，射在[mo1rel]的胸部吧。"

translate chinese chinese_4218572_136:
    old "Ughhh... Ahhh!"
    new "呃……啊！"

translate chinese chinese_6420032_137:
    old "Oh yes! Cum all over me!"
    new "哦 yeah！射里面来！"

translate chinese chinese_2622087_138:
    old "Wow you came a lot..."
    new "wow 你来得真多..."

translate chinese chinese_0727883_139:
    old "I'm glad you're still hard, because I need you inside of me now."
    new "很高兴你还是硬的，因为我现在需要你在里面。"

translate chinese chinese_6846820_140:
    old "Come with me to the bed"
    new "跟我来床上"

translate chinese chinese_3046391_141:
    old "Uhhh, yes, just like that."
    new "嗯哼，对，就是这样。"

translate chinese chinese_6590352_142:
    old "I'm I can feel your cock inside me, and it feels amazing!"
    new "我能感觉到你的硬挺在里面，感觉太棒了！"

translate chinese chinese_2877008_143:
    old "Mmmm, it feels so nice!"
    new "嗯，感觉真好！"

translate chinese chinese_8289474_144:
    old "Oh yeah, don't stop baby, don't stop!"
    new "哦 yeah，别停宝贝，别停！"

translate chinese chinese_2290198_145:
    old "Ahhh, ahhh, yeah fuck me, fuck me!"
    new "啊hhh，啊hhh，对的就是那样，继续fuck me!"

translate chinese chinese_0067184_146:
    old "Yess! Fuck your [mo1rel] harder!"
    new "耶！更用力地操你的[mo1rel]！"

translate chinese chinese_3058002_147:
    old "Mmmm... I'm getting close, don't stop."
    new "嗯……快要到了，别停。"

translate chinese chinese_5798223_148:
    old "God, that was awesome."
    new "天啊，那真是太棒了。"

translate chinese chinese_2006528_149:
    old "Let's rest a little."
    new "我们休息一下吧。"

translate chinese chinese_1625053_150:
    old "That was a fantastic night honey."
    new "宝贝，那真是个美妙的夜晚。"

translate chinese chinese_2785446_151:
    old "Yes, I really enjoyed it."
    new "是的，我真的很享受。"

translate chinese chinese_2606146_152:
    old "Remember we must be careful, no one can know... Ok?"
    new "记得我们要小心，不能让任何人知道……好吗？"

translate chinese chinese_9801198_153:
    old "Yes, don't worry."
    new "好的，别担心。"

translate chinese chinese_6856872_154:
    old "Go to your room quietly to avoid suspicion."
    new "悄悄回房间以免引起怀疑。"

translate chinese chinese_0808152_155:
    old "You're right! I will."
    new "你说得对！我会的。"

translate chinese chinese_9329055_156:
    old "Oh no... I'm sorry, I'm really sorry ..."
    new "哦不……对不起，我真的对不起……"

translate chinese chinese_3963193_157:
    old "What? Why?"
    new "什么？为什么？"

translate chinese chinese_9105348_158:
    old "For what happened last night, it was definitely very bad, I drank too much and-"
    new "对于昨晚发生的事，确实很糟糕，我喝多了——"

translate chinese chinese_4103916_159:
    old "No, we both decided to do it, I also agreed."
    new "不，是我们俩都决定这么做的，我也同意了。"

translate chinese chinese_3195292_160:
    old "But I am your [mo1rel]."
    new "但是我是你的[mo1rel]。"

translate chinese chinese_1761250_161:
    old "(Hmmm... I could need a bit of help here ...)"
    new "（嗯……这里我可能需要一点帮助……）"

translate chinese chinese_1590327_162:
    old "{b}Sauron's mouth:{/b} It's ok, it's what we both wanted and there's no problem doing it, we're both adults."
    new "{b}索伦的嘴：{/b} 没关系，这是我们俩都想要的，做这件事没有问题，我们都是成年人。"

translate chinese chinese_1360282_163:
    old "Yes, we are both adults ..."
    new "是的，我们都是成年人……"

translate chinese chinese_6260293_164:
    old "You know what, what the hell, I'm not going to keep worrying about [mo2]."
    new "你知道吗，管它呢，我不会再为[mo2]担心了。"

translate chinese chinese_6826524_165:
    old "If you're okay with this, I think I'm fine too, right?"
    new "如果你觉得没问题，那我也应该没问题吧？"

translate chinese chinese_5880039_166:
    old "Also yesterday I really enjoyed it and can't believe I haven't done it in so many years!"
    new "而且昨天我真的很享受，真不敢相信我已经很多年没有做了！"

translate chinese chinese_0835470_167:
    old "I also enjoyed it a lot."
    new "我也很享受。"

translate chinese chinese_6301929_168:
    old "Just be careful, I don't want anyone to notice, ok?"
    new "小心点，我不想让人发现，好吗？"

translate chinese chinese_9405311_169:
    old "Great honey, let's go, I have to prepare breakfast."
    new "好啦亲爱的，我们走吧，我得准备早餐了。"

translate chinese chinese_0951200_170:
    old "Well, that was insane... I had sex with [mo1rel]..."
    new "好吧，那真是太疯狂了……我和[mo1rel]发生了关系……"

translate chinese chinese_2770478_171:
    old "Cool."
    new "酷。"

translate chinese chinese_8264051_172:
    old "Ahhhh... It's so big"
    new "啊啊啊……好大啊"

translate chinese chinese_0643749_173:
    old "Mmmm, it feels amazing!"
    new "嗯，感觉太棒了！"

translate chinese chinese_0951647_174:
    old "Uhhh yeah, baby I love your cock."
    new "嗯哼，宝贝，我超爱你的鸡巴。"

translate chinese chinese_1534411_175:
    old "Oh God, oh God! I'm so wet."
    new "哦天哪，我好湿。"

translate chinese chinese_2194548_176:
    old "Yeah, yeah, I love having your cock inside me."
    new "是的，是的，我喜欢你硬挺在里面。"

translate chinese chinese_4723001_177:
    old "Ohh yeah, just like this..."
    new "哦哦，就是这样..."

translate chinese chinese_9983664_178:
    old "Ahhh... Ahhh! I- I'm cumming!"
    new "啊hhh... 我要来了！"

translate chinese chinese_8319931_179:
    old "Ughhhh m- me too."
    new "呃呃呃，我也是。"

translate chinese chinese_1626543_180:
    old "Oh yes... It was really good."
    new "哦，是的……真的很棒。"

translate chinese chinese_1372962_181:
    old "But I want more!"
    new "但我还想更多！"

translate chinese chinese_9034983_182:
    old "Ohhh God!"
    new "哦哦哦天啊！"

translate chinese chinese_9577478_183:
    old "This is amazing!"
    new "太棒了！"

translate chinese chinese_9618577_184:
    old "Uhh, I'll never get tired of this."
    new "呃，我永远不会厌倦这个的。"

translate chinese chinese_8278782_185:
    old "Mmmm, do you like your [mo1rel] riding you?"
    new "嗯哼，你喜欢[mo1rel]骑你吗？"

translate chinese chinese_0563916_186:
    old "Ohhh yes."
    new "哦哦，是的。"

translate chinese chinese_3721199_187:
    old "Yeah! Fuck me [pla], Fuck your [mo1rel]!"
    new "yeah! 干我吧 [pla], 干你的 [mo1rel]!"

translate chinese chinese_5604200_188:
    old "Ohhh my God!"
    new "哦我的天！"

translate chinese chinese_6783015_189:
    old "Mmmm, let me try something."
    new "嗯，让我试试。"

translate chinese chinese_1531744_190:
    old "I'm sure you will enjoy this."
    new "我相信你会喜欢这个的。"

translate chinese chinese_5565509_191:
    old "Uhhh this feels even better."
    new "嗯，这个感觉更好了。"

translate chinese chinese_9288629_192:
    old "Ohhh myy-"
    new "哦哦我的天——"

translate chinese chinese_4429828_193:
    old "Mmmm, I learned this in college."
    new "嗯，这个我是大学里学的。"

translate chinese chinese_1863296_194:
    old "Do you like how I'm moving?"
    new "你喜欢我的动作吗？"

translate chinese chinese_1599537_195:
    old "Ahhh... Oh my God it feels so fucking goood!"
    new "啊hhh... 哇哦，感觉真他妈的好极了！"

translate chinese chinese_5129832_196:
    old "Yeah, yeah, I'm getting close!"
    new "好了好了，我快到了！"

translate chinese chinese_3139133_197:
    old "Yeah yeah! Let's cum together!"
    new "yeah yeah! 让我们一起高潮吧！"

translate chinese chinese_1242678_198:
    old "Yes, cum with mommy baby! Cum with me!"
    new "没错，和妈妈一起高潮吧宝贝！和我一起高潮！"

translate chinese chinese_7886040_199:
    old "Holly shit, that was amazing!"
    new "Holy shit, 那真是太棒了！"

translate chinese chinese_4682249_200:
    old "Pheww... Ohh yeah."
    new "呼……哦耶。"

translate chinese chinese_2206909_201:
    old "It's getting better and better!"
    new "越来越好了！"

translate chinese chinese_8686244_202:
    old "Ohh my God!"
    new "哦我的天！"

translate chinese chinese_5562662_203:
    old "It's so big! Oh God I feel it so deep!"
    new "好大啊！天啊，我感觉好深啊！"

translate chinese chinese_2209777_204:
    old "Oh yes, fuck me [pla], fuck me!"
    new "哦 yeah，操我 [pla]，操我！"

translate chinese chinese_0026504_205:
    old "Oh yeah, faster, faster! Fuck me harder!"
    new "哦 yeah，更快，更快！操得我再狠点！"

translate chinese chinese_2117707_206:
    old "Uhhh, yes, yes, fuck your mommy!"
    new "呃，是的，是的，去你的妈妈！"

translate chinese chinese_2701805_207:
    old "Ohhhh m- my God! I'm cumming!"
    new "哦哦哦天啊！我要射了！"

translate chinese chinese_3527324_208:
    old "Ughhh mee too!"
    new "呃 好吧！"

translate chinese chinese_4101241_209:
    old "Wow it was a huge load"
    new "哇，真够多的。"

translate chinese chinese_7542336_210:
    old "Mmmm, you cum all over me."
    new "嗯，你弄得我全身都是。"

translate chinese chinese_9018250_211:
    old "Let's clean this up before someone comes."
    new "咱们在有人来之前把这收拾干净。"

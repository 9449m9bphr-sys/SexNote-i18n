# auto-tl Qwen Colab

translate chinese chinese_8479498_0:
    old "All right, how is that [pla]? Do you like how Belle jerks off your cock?"
    new "好吧，那个[pla]怎么样？你喜欢贝尔给你 handjob的感觉吗？"

translate chinese chinese_2343324_1:
    old "Ohh yeah it feels really nice."
    new "哦，感觉真不错。"

translate chinese chinese_3515477_2:
    old "Ugh! That's really a big dick... Have you seen one like that before Belle?"
    new "呃！那真是个大鸡巴……贝尔，你以前见过那样的吗？"

translate chinese chinese_9697259_3:
    old "N- no, I had never seen a cock this big."
    new "不，我从没见过这么大的鸡巴。"

translate chinese chinese_0527031_4:
    old "He seems to like it like that, keep going."
    new "他好像喜欢这样，继续吧。"

translate chinese chinese_0162075_5:
    old "Keep going Belle! Don't stop."
    new "继续吧，贝尔！别停。"

translate chinese chinese_5408784_6:
    old "Do you like that [pla]?"
    new "你喜欢那个[pla]吗？"

translate chinese chinese_1343418_7:
    old "Mmmm... Y- yeah."
    new "嗯……好啦。"

translate chinese chinese_5391093_8:
    old "It's soo hard in my hand, right now!"
    new "现在在我手里硬得不得了！"

translate chinese chinese_3138409_9:
    old "I-I think I'm cuming!"
    new "我我快要射了！"

translate chinese chinese_5298023_10:
    old "Uhh?"
    new "嗯？"

translate chinese chinese_4247502_11:
    old "Yes! Cum [pla]!"
    new "是的！射吧 [pla]！"

translate chinese chinese_1061270_12:
    old "Cum in her face!"
    new "射她脸上！"

translate chinese chinese_4216902_13:
    old "Ughhhh!"
    new "哎呀呀！"

translate chinese chinese_8228541_14:
    old "Ughh... You gotta be more careful [pla], I'm all covered with cum now."
    new "呃……你得小心点，[pla]，我现在全身都是精液了。"

translate chinese chinese_6094551_15:
    old "S- sorry, I couldn't really help it."
    new "对不起，我实在忍不住。"

translate chinese chinese_8658023_16:
    old "Hah! What's the matter Belle?"
    new "哈！贝尔，怎么了？"

translate chinese chinese_9037056_17:
    old "Aren't you happy you gave him a good time."
    new "你不开心自己给他带来了快乐时光吗？"

translate chinese chinese_9263742_18:
    old "Phew, yeah right! As if I wanted this sticky thing on me."
    new "呼，才不要呢！我才不想粘着这个东西。"

translate chinese chinese_1175720_19:
    old "Wait a minute, I'll clean myself."
    new "等一下，我先收拾一下自己。"

translate chinese chinese_4600043_20:
    old "Oh! Oh my gosh!"
    new "哦！天啊！"

translate chinese chinese_0505484_21:
    old "This cock!"
    new "这王八蛋！"

translate chinese chinese_1438827_22:
    old "It's so good!"
    new "太好了！"

translate chinese chinese_0897037_23:
    old "I love how deep into my throat it's going!"
    new "我喜欢它深入我喉咙的感觉！"

translate chinese chinese_3504715_24:
    old "Oh! Yeah! Do you guys like this?"
    new "哦！对了！你们喜欢这样吗？"

translate chinese chinese_1553530_25:
    old "Seeing this huge cock fill my mouth up?!"
    new "看到这么大的家伙塞满我的嘴？！"

translate chinese chinese_8084419_26:
    old "Yes! Yes! Yes!"
    new "是的！是的！是的！"

translate chinese chinese_3768379_27:
    old "Oh my gosh this is the best taste ever!"
    new "天啊，这味道真是太好了！"

translate chinese chinese_3984411_28:
    old "I can't get enough of this taste!"
    new "我根本停不下来这味道！"

translate chinese chinese_8196535_29:
    old "Oh my gosh!"
    new "天啊！"

translate chinese chinese_1034362_30:
    old "He's about to fill my mouth with his cum!"
    new "他就要用他的精液填满我的嘴了！"

translate chinese chinese_5379360_31:
    old "Do you want to see it?"
    new "你想看吗？"

translate chinese chinese_9590498_32:
    old "That was fantastic guys!"
    new "你们真是太棒了！"

translate chinese chinese_3337779_33:
    old "And it's all thanks to your tips!"
    new "这全都要感谢你的建议！"

translate chinese chinese_4009052_34:
    old "If you want to see me getting fucked in the future remember to subscribe to premium and keep tipping."
    new "如果你想以后看到我被操的情景，记得订阅高级会员并继续打赏。"

translate chinese chinese_8072510_35:
    old "And of course, join my fan club so you can download the video of this streaming."
    new "当然了，加入我的粉丝俱乐部就可以下载这次直播的视频了。"

translate chinese chinese_6642614_36:
    old "What great dick this is"
    new "这真是个棒极了的家伙"

translate chinese chinese_3092375_37:
    old "I love the way it feels in my hand!"
    new "我爱这种握在手里的感觉！"

translate chinese chinese_3511469_38:
    old "It's so big and so nice!"
    new "这么大这么好！"

translate chinese chinese_9835528_39:
    old "Do you like how I stroke it?"
    new "你喜欢我这样抚摸吗？"

translate chinese chinese_9837602_40:
    old "Do you like how I grab your big dick in my hand?"
    new "你喜欢我用手握着你的大鸡巴的感觉吗？"

translate chinese chinese_8152584_41:
    old "It's such a nice big cock!"
    new "真大的 cocks!"

translate chinese chinese_0464271_42:
    old "Oh my god!"
    new "天啊！"

translate chinese chinese_9869494_43:
    old "So big and hot!"
    new "这么大这么热！"

translate chinese chinese_5688016_44:
    old "I can feel you're about to cum!"
    new "我感觉你快来了！"

translate chinese chinese_1724901_45:
    old "Your dick is twitching so hard in my hand!"
    new "你的 dicks 在我手里抖得这么厉害！"

translate chinese chinese_3507726_46:
    old "Come! I want you to see you do it!"
    new "来！我想看你做！"

translate chinese chinese_7205840_47:
    old "That was sooo good!"
    new "太棒了！"

translate chinese chinese_8819734_48:
    old "But that's not all we're doing today guys!"
    new "但这不是今天我们做的全部！"

translate chinese chinese_5246948_49:
    old "Why don't I show you what I have next for you?"
    new "要不我给你看看接下来准备什么怎么样？"

translate chinese chinese_4784586_50:
    old "Mmm! The taste of this big cock!"
    new "嗯！这大棒的滋味！"

translate chinese chinese_9572100_51:
    old "It's so hot and thick!"
    new "热得要命！"

translate chinese chinese_4349995_52:
    old "You guys wanted this, didn't you?"
    new "你们这是想要的吧？"

translate chinese chinese_5624985_53:
    old "Do you like how I stuff my mouth with your dick?"
    new "你喜欢我用嘴含着你的棒棒的感觉吗？"

translate chinese chinese_9151410_54:
    old "I love it!"
    new "我爱死这个了！"

translate chinese chinese_7120360_55:
    old "I love how you're filling my mouth with your big cock!!"
    new "我喜欢你用那么大的 cock 填满我的嘴！！"

translate chinese chinese_9438602_56:
    old "I can't get enough of it!"
    new "我根本停不下来！"

translate chinese chinese_8304299_57:
    old "I love how it tastes!"
    new "我爱它的味道！"

translate chinese chinese_7227166_58:
    old "My god! This taste is so good!"
    new "天啊！这味道真好！"

translate chinese chinese_7959294_59:
    old "I love how you're ravishing my mouth!"
    new "我喜欢你这样吻我！"

translate chinese chinese_9554205_60:
    old "I can't get enough of your dick guys!"
    new "你的 dicks 真是让我欲罢不能！"

translate chinese chinese_1573676_61:
    old "You guys want to cum in my mouth?"
    new "你们想在我嘴里射吗？"

translate chinese chinese_0897488_62:
    old "I want you to fill my throat with your hot load!"
    new "我想让你热腾腾的射进我的喉咙里！"

translate chinese chinese_0283664_63:
    old "That was so good guys!"
    new "你们真是太棒了！"

translate chinese chinese_6844122_64:
    old "This cum is so good!"
    new "这精液真好！"

translate chinese chinese_2441320_65:
    old "It's just the best taste in the world!"
    new "这简直是世界上最好的味道！"

translate chinese chinese_8406657_66:
    old "Mmm! oh my god! I can never get enough of this dick!"
    new "嗯！天啊！我永远都不会厌倦这个家伙的！"

translate chinese chinese_8141377_67:
    old "This has to be the most amazing dick in the world!"
    new "这绝对是世界上最棒的鸡巴！"

translate chinese chinese_7743389_68:
    old "I love how much it's filling my mouth!"
    new "我爱这种塞满嘴巴的感觉！"

translate chinese chinese_0368472_69:
    old "Do you guys like seeing me like this? Who would want to have me right in front of you like this?"
    new "你们喜欢这样看着我吗？谁会希望我就这样站在你面前呢？"

translate chinese chinese_6519021_70:
    old "Do you like the way this cock is filling in my entire mouth?!"
    new "你喜欢这根鸡巴填满我整个嘴巴的感觉吗？！"

translate chinese chinese_3391848_71:
    old "Oh yes! I can feel it pushing all the way to my throat!"
    new "哦，是的！我能感觉到它一直推到喉咙！"

translate chinese chinese_8594629_72:
    old "Mmm! Oh my god guys look at this!"
    new "嗯！天啊，你们看这个！"

translate chinese chinese_2474723_73:
    old "This cock is just as hard as it was a minute ago!"
    new "这根鸡巴和一分钟前一样硬！"

translate chinese chinese_3806915_74:
    old "My god! It's so good!"
    new "天啊！真好吃！"

translate chinese chinese_2421907_75:
    old "It doesn't matter what happens, it's always so great!!"
    new "不管发生什么，总是这么棒!!"

translate chinese chinese_0470644_76:
    old "I- Slrrp! I bet you guys like this don't you?"
    new "我—啧！你们这种人肯定喜欢吧？"

translate chinese chinese_0147495_77:
    old "I- Mmm! I love it!"
    new "我—嗯！我喜欢！"

translate chinese chinese_4832243_78:
    old "OH! Yes! This cock tastes so great!"
    new "哦！是的！这个味道真棒！"

translate chinese chinese_6651835_79:
    old "Slrrrp! Mmmm! I can't get enough of it!"
    new "啧啧！嗯嗯！我根本停不下来！"

translate chinese chinese_0033184_80:
    old "Oh God I love the way you're fucking my mouth!"
    new "哦上帝，我爱你舔我的方式！"

translate chinese chinese_0637992_81:
    old "Oh god! I can feel you getting tense!"
    new "哦天啊！我能感觉到你紧张起来了！"

translate chinese chinese_7671134_82:
    old "You're about to cum, right guys?!"
    new "你们快要射了对吧?!"

translate chinese chinese_3515874_83:
    old "Do it! Don't hold it back!"
    new "来吧！别克制！"

translate chinese chinese_0268126_84:
    old "Throw your cum in my throat!"
    new "把你的精液射进我的喉咙里！"

translate chinese chinese_2814240_85:
    old "I'm so happy you liked it too!"
    new "太好了，你也喜欢它！"

translate chinese chinese_8107748_86:
    old "Especially because we've managed to get to the goal!"
    new "特别是因为我们已经成功达到目标了！"

translate chinese chinese_7704015_87:
    old "So now we can go ahead and I can show you!"
    new "那我们现在就可以继续，我可以展示给你看了！"

translate chinese chinese_7995645_88:
    old "Just give me a couple of minutes, we're going to get ready for what comes next."
    new "就给我几分钟，我们要为接下来的事情做好准备。"

translate chinese chinese_0866235_89:
    old "Don't go anywhere because I know you're going to love it!"
    new "别走开，因为我敢肯定你会喜欢的！"

translate chinese chinese_0333719_90:
    old "Oh! Yeah!"
    new "哦！对了！"

translate chinese chinese_0423944_91:
    old "The feeling in my throath is so great!"
    new "我喉咙里的感觉太棒了！"

translate chinese chinese_1102558_92:
    old "I like it so much!"
    new "我超喜欢的！"

translate chinese chinese_3583901_93:
    old "Do you like to see me sucking cock guys?!"
    new "你们喜欢看我吸棒吗？！"

translate chinese chinese_2103736_94:
    old "Oh, yeah! Yeah!"
    new "哦，对！没错！"

translate chinese chinese_9725725_95:
    old "Oh my god! This is so good!"
    new "天啊！这真是太好了！"

translate chinese chinese_1986599_96:
    old "I can't imagine a better tasting dick than this!"
    new "我简直不能想象还有比这更好味的鸡巴！"

translate chinese chinese_2444630_97:
    old "Oh yeah!"
    new "哦，对了！"

translate chinese chinese_2694360_98:
    old "I can feel your dick twitching."
    new "我能感觉到你的 dicks 在抽动。"

translate chinese chinese_1019809_99:
    old "I know you're about to come!"
    new "我知道你快来了！"

translate chinese chinese_5505535_100:
    old "Do it guys! Cum in my mouth!"
    new "来吧，射到我嘴里！"

translate chinese chinese_8814996_101:
    old "That was lovely guys!"
    new "你们真是太棒了！"

translate chinese chinese_9705732_102:
    old "But we're not stopping here!"
    new "但我们不会在这里停下来！"

translate chinese chinese_0150789_103:
    old "Let's get to what you really want to see!"
    new "让我们进入你想看的内容吧！"

translate chinese chinese_3413583_104:
    old "Hngh!"
    new "嗯！"

translate chinese chinese_8419527_105:
    old "Oh god! This is so amazing!"
    new "哦天啊！这太棒了！"

translate chinese chinese_0326665_106:
    old "My god! This sensation is so good!"
    new "天啊！这种感觉真好！"

translate chinese chinese_6806379_107:
    old "Oh my god! Oh my god!"
    new "天啊！天啊！"

translate chinese chinese_7696845_108:
    old "I love the way you're making me feel!"
    new "我爱死你给我带来的感觉了！"

translate chinese chinese_1461159_109:
    old "I can't get enough of this dick!"
    new "我根本停不下来！"

translate chinese chinese_0493981_110:
    old "My pussy feels so good!"
    new "我的 pussy 真舒服！"

translate chinese chinese_6608459_111:
    old "This dick is so hot! It's so good!"
    new "这个家伙真性感！太棒了！"

translate chinese chinese_5267595_112:
    old "Ugh! Oh yes! yes!"
    new "哎呀！哦 yeah！yes！"

translate chinese chinese_9533082_113:
    old "I love the way this feels!"
    new "我爱这种感觉！"

translate chinese chinese_0929811_114:
    old "My pussy feels so great!"
    new "我的下体感觉棒极了！"

translate chinese chinese_9239469_115:
    old "I know you guys want to come inside of me!"
    new "我知道你们都想进我身体里！"

translate chinese chinese_9847485_116:
    old "Do it! Fill my pussy again with your hot load!"
    new "来吧！用你的热精液再次填满我的 pussy！"

translate chinese chinese_7638607_117:
    old "I want to feel that cum inside me!"
    new "我想感受那股热流在里面！"

translate chinese chinese_7665391_118:
    old "I knew you would like it!"
    new "我就知道你会喜欢的！"

translate chinese chinese_6875665_119:
    old "Oh god!"
    new "哦天啊！"

translate chinese chinese_3233092_120:
    old "This cock was so impressive before"
    new "这根鸡巴之前真是棒极了"

translate chinese chinese_1101496_121:
    old "But now that I have it on my ass!"
    new "但现在它粘我身上了！"

translate chinese chinese_9515113_122:
    old "It's even better!"
    new "甚至更好！"

translate chinese chinese_4358384_123:
    old "God! It's so good!"
    new "天啊！真好吃！"

translate chinese chinese_7002763_124:
    old "I love how hard you're fucking my ass guys!"
    new "我喜欢你们这样狠狠地操我的屁股！"

translate chinese chinese_6563909_125:
    old "Mmm! Do you like the way you're stretching me?!"
    new "嗯！你喜欢这样拉伸我的感觉吗？！"

translate chinese chinese_8438710_126:
    old "Oh! Oh! Yes!"
    new "哦！哦！是的！"

translate chinese chinese_5214801_127:
    old "Yes! Keep fucking me like that!"
    new "没错！就这样继续操我！"

translate chinese chinese_5682006_128:
    old "I love the way it's filling me!"
    new "我喜欢这种被填满的感觉！"

translate chinese chinese_3299519_129:
    old "It's just stretching my ass!"
    new "这只不过是在拉伸我的屁股而已！"

translate chinese chinese_1676489_130:
    old "OH yes! I can feel it!"
    new "哦，是的！我感觉到了！"

translate chinese chinese_9914664_131:
    old "You're about to cum aren't you?"
    new "你快要射了吧？"

translate chinese chinese_3923275_132:
    old "Do it! Cum!"
    new "来吧！射！"

translate chinese chinese_9555912_133:
    old "Fill my ass with your hot cum!"
    new "用你的热精液填满我的屁股！"

translate chinese chinese_8944587_134:
    old "That was so awesome guys!"
    new "你们太棒了！"

translate chinese chinese_9454448_135:
    old "I knew you guys would do great today!"
    new "我就知道你们今天会表现得很棒！"

translate chinese chinese_5284584_136:
    old "And you didn't disappoint!"
    new "而且你果然没有让我失望！"

translate chinese chinese_7445274_137:
    old "Slrrp! Oh my god!"
    new "啧！天啊！"

translate chinese chinese_1688060_138:
    old "What a great taste this dick has!"
    new "这小子的品味真不错！"

translate chinese chinese_2570544_139:
    old "Mmm! It feels so amazing in my mouth!"
    new "嗯！感觉嘴里太棒了！"

translate chinese chinese_5155138_140:
    old "Do you like seeing us taste dick guys?"
    new "你喜欢看我们被男人操吗？"

translate chinese chinese_0547007_141:
    old "It's so amazing to lick it!"
    new "舔起来真爽！"

translate chinese chinese_8424367_142:
    old "I love how hot it is!"
    new "我超爱这种火热的感觉！"

translate chinese chinese_9965186_143:
    old "Slrrp! Mmmm!"
    new "slurp! 呀呜！"

translate chinese chinese_1088057_144:
    old "This dick is so hard!"
    new "这家伙硬得不行！"

translate chinese chinese_6445089_145:
    old "And the taste! So amazing!"
    new "还有那味道！太棒了！"

translate chinese chinese_5027847_146:
    old "I can feel this dick twitching!"
    new "我能感觉到这根棒在抽动！"

translate chinese chinese_2299059_147:
    old "You want to see him cum because of our tongues don't you?!"
    new "你想看他因为我们的舌头射吧！"

translate chinese chinese_0705781_148:
    old "Oh yes! I want to see that!"
    new "哦 yeah！我想看那个！"

translate chinese chinese_4971979_149:
    old "Oh my God guys! You're amazing!"
    new "天啊，你们太棒了！"

translate chinese chinese_6397098_150:
    old "You actually did it!"
    new "你真的做到了！"

translate chinese chinese_6014293_151:
    old "You reached the goal!"
    new "你达到目标了！"

translate chinese chinese_2867178_152:
    old "And you know what that means."
    new "而你知道那意味着什么。"

translate chinese chinese_5436719_153:
    old "This is what I was waiting for!"
    new "这正是我等待的！"

translate chinese chinese_1092722_154:
    old "Mmm! Oh God yes! This is what I had been waiting for!"
    new "嗯！哦上帝是的！这就是我一直在等待的！"

translate chinese chinese_9304422_155:
    old "What an amazing cock!"
    new "真棒的鸡巴！"

translate chinese chinese_1275755_156:
    old "Oh yeah [pla]!"
    new "哦对了[pla]！"

translate chinese chinese_9481205_157:
    old "Do you like how he's stretching her pussy?"
    new "你喜欢他这样弄她的 pussy 吗？"

translate chinese chinese_8654554_158:
    old "I love the way it feels!"
    new "我爱这种感觉！"

translate chinese chinese_9652673_159:
    old "Do you like how he's fucking her guys?"
    new "你们觉得他那样干她爽不爽？"

translate chinese chinese_9191109_160:
    old "It's amazing isn't it?"
    new "真不可思议，对吧？"

translate chinese chinese_8221539_161:
    old "Oh my God! This cock is so amazing!"
    new "天啊！这鸡巴真是太棒了！"

translate chinese chinese_7876855_162:
    old "Oh God! Oh yes!"
    new "哦上帝！哦没错！"

translate chinese chinese_6567235_163:
    old "Yes! Yes! Keep stretching my pussy!"
    new "是的！是的！继续拉伸我的下体！"

translate chinese chinese_2312936_164:
    old "What a great cock! It's so hard! And so big!"
    new "好大的鸡巴！硬得不得了！而且还那么大！"

translate chinese chinese_6865165_165:
    old "I- Ah! I can feel his dick twitching!"
    new "我——啊！我能感觉到他的 dicks 在动！"

translate chinese chinese_5075251_166:
    old "Are you about to cum?! Do it!"
    new "你要射了?! 来吧!"

translate chinese chinese_7530592_167:
    old "Fill her up with your cum!"
    new "把她填满你的精液！"

translate chinese chinese_8766282_168:
    old "Yes! Oh yes! I want to feel it inside!"
    new "是的！哦，是的！我想感受那种感觉在里面！"

translate chinese chinese_8090024_169:
    old "That was wonderful guys!"
    new "你们真是太棒了！"

translate chinese chinese_6903230_170:
    old "I felt so amazing!"
    new "我感觉太棒了！"

translate chinese chinese_3909877_171:
    old "To have my pussy stretched like that!"
    new "让我的 pussy 这样被撑开！"

translate chinese chinese_2657237_172:
    old "But now it's time for Belle's turn."
    new "但现在轮到贝勒了。"

translate chinese chinese_6869024_173:
    old "Alright! I was waiting for this too."
    new "好啊！我也是等这一刻呢。"

translate chinese chinese_7026393_174:
    old "Oh! That's fucking hot to see!"
    new "哦！看到那真是够刺激的！"

translate chinese chinese_6949717_175:
    old "How does it feel Belle?"
    new "感觉怎么样，贝尔？"

translate chinese chinese_6928809_176:
    old "Hmm! I love it!"
    new "哼！我爱死这个了！"

translate chinese chinese_1142815_177:
    old "I can never get enough of this dick!"
    new "我永远都不会厌倦这个家伙的！"

translate chinese chinese_9879154_178:
    old "No matter how many times I have it!"
    new "不管我做多少次！"

translate chinese chinese_5756036_179:
    old "God that's just so good to see!"
    new "天啊，看到这个真是太好了！"

translate chinese chinese_1727695_180:
    old "Look at how that dick comes in and out of your pussy!"
    new "看那家伙进出你阴道的样子！"

translate chinese chinese_1431724_181:
    old "OH! OH! God!"
    new "哦！哦！天啊！"

translate chinese chinese_3365684_182:
    old "This dick! Is so good!"
    new "这个家伙真棒！"

translate chinese chinese_4849391_183:
    old "I love it! It's so hot!"
    new "我爱死了！热死人了！"

translate chinese chinese_8628668_184:
    old "Do you like fucking me guys?"
    new "你们喜欢跟我做爱吗？"

translate chinese chinese_2538789_185:
    old "I- Oh! I can feel his dick twitching!"
    new "我——哦！我能感觉到他的 dicks 在动！"

translate chinese chinese_0771933_186:
    old "I feel it coming!"
    new "我感觉要来了！"

translate chinese chinese_2304857_187:
    old "Do it! Cum inside her! Fill her pussy!"
    new "干吧！在里面射！把她填满！"

translate chinese chinese_5052254_188:
    old "I'm so happy you reached the goal!"
    new "真为你达到目标感到高兴！"

translate chinese chinese_9659649_189:
    old "You never disappoint me!"
    new "你从不会让我失望！"

translate chinese chinese_2531087_190:
    old "It really was great!"
    new "真的太棒了！"

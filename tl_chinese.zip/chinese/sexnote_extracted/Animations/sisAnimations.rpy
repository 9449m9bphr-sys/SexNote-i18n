# auto-tl Qwen Colab

translate chinese chinese_7090060_0:
    old "W- What are you doing?"
    new "你、你在干什么？"

translate chinese chinese_8574286_1:
    old "What does it look like?"
    new "看起来像什么？"

translate chinese chinese_7079178_2:
    old "Hmm, your cock is so tasty!"
    new "哼，你的棒棒真好吃！"

translate chinese chinese_6938619_3:
    old "Don't you like it?"
    new "你不觉得喜欢吗？"

translate chinese chinese_9202141_4:
    old "I can't believe you have such a big cock!"
    new "真不敢相信你竟然有这么大的鸡巴！"

translate chinese chinese_4665326_5:
    old "Please, stop. You are... Gonna make me-"
    new "求你了，停下来。你……要让我忍不住了-"

translate chinese chinese_0872634_6:
    old "Cum? Oh please do it. I'm dying to see this monster cock cum all over..."
    new "射吧？哦请射吧。我真的想看到这个巨棒射得满是..."

translate chinese chinese_8584543_7:
    old "Shit! That was so intense... Did you like it?"
    new "shit! 那真是太激烈了……你觉得怎么样？"

translate chinese chinese_0464957_8:
    old "Ye... I- I have to go..."
    new "Ye... 我- 我得走了..."

translate chinese chinese_1980547_9:
    old "What the fuck was that?"
    new "那是什么鬼？"

translate chinese chinese_0716536_10:
    old "I better go to sleep now..."
    new "我还是去睡觉吧……"

translate chinese chinese_2443571_11:
    old "Ready for a new day!..."
    new "准备好迎接新的一天了！..."

translate chinese chinese_0363299_12:
    old "Hmm I love this taste."
    new "嗯，我喜欢这个味道。"

translate chinese chinese_1642004_13:
    old "Do you like how it feels inside my mouth?"
    new "你喜欢这种在我的嘴里感觉吗？"

translate chinese chinese_3983920_14:
    old "It's fucking huge, I want to have it all inside, do you think I'm capable?"
    new "它大得离谱，我想全部塞进去，你觉得我能做到吗？"

translate chinese chinese_3996582_15:
    old "Oh my god, I can feel it reaching my throat."
    new "天啊，我能感觉到它已经到喉咙了。"

translate chinese chinese_5476766_16:
    old "What about a deepthroat?"
    new "来个深喉怎么样？"

translate chinese chinese_1846088_17:
    old "Oh my God!"
    new "天啊！"

translate chinese chinese_0880294_18:
    old "Oh my, I can feel every inch inside my mouth!"
    new "哦我的天，每一寸都感觉到了！"

translate chinese chinese_1571464_19:
    old "Ohhh, I- I!"
    new "哦哦，我——我！"

translate chinese chinese_5547713_20:
    old "Wow... That was massive, let me clean this mess... "
    new "wow... 那真是太大了，让我来收拾一下这个烂摊子..."

translate chinese chinese_8613666_21:
    old "(Oh man in a second I will be hard...)"
    new "（哦，一会儿我就硬了……）"

translate chinese chinese_1629014_22:
    old "Ohh, I love it ... My tits are very sensitive, I'm getting horny..."
    new "哦，我喜欢……我的胸部很敏感，我开始兴奋了……"

translate chinese chinese_8441953_23:
    old "Ohh yeah, just like that... Don't stop baby..."
    new "哦哦，就是这样……不要停宝贝……"

translate chinese chinese_6213416_24:
    old "How does it feel in between these amazing boobs?"
    new "在这对惊人的胸部之间感觉如何？"

translate chinese chinese_3501538_25:
    old "Ohh... It... Feels great."
    new "哦……这……感觉真好。"

translate chinese chinese_3920493_26:
    old "Ohh... It feels really good..."
    new "哦……感觉真好……"

translate chinese chinese_0266665_27:
    old "Do not try to stop, keep moving faster."
    new "不要停下来，继续加快速度。"

translate chinese chinese_8346367_28:
    old "Oh yeah, fuck my tits! Harder, fuck them harder!"
    new "哦 yeah，操我的胸！再用力点，用力操它们！"

translate chinese chinese_0229984_29:
    old "[sis], I'm going to..."
    new "[sis]，我要去..."

translate chinese chinese_9198938_30:
    old "Oh yeah, cum all over me!"
    new "哦 yeah，射我身上吧！"

translate chinese chinese_7288370_31:
    old "Hey Ky-... (Wow!)"
    new "嘿，凯-... (哇！)"

translate chinese chinese_9842437_32:
    old "Oh shit, she is playing with her dildo..."
    new "哦shit，她正在玩她的 dildo..."

translate chinese chinese_1483398_33:
    old "I have to keep quiet so she doesn't notice me."
    new "我得保持安静，以免她注意到我。"

translate chinese chinese_8079360_34:
    old "Mmm, it feels so good!"
    new "嗯，感觉真好！"

translate chinese chinese_3534680_35:
    old "My pussy wants a big, hard cock!"
    new "我想要一个大大的硬硬的屌！"

translate chinese chinese_6483454_36:
    old "Oh yeah! it feels better than fingering!"
    new "哦 yeah！这感觉比手指还要好！"

translate chinese chinese_2019241_37:
    old "I'm so fucking wet right now."
    new "我现在湿透了。"

translate chinese chinese_0839907_38:
    old "Ughhh I can't take it anymore, I want to feel my pussy fucked! "
    new "哎呀我受不了了，我想感受我的 pussy 被操的感觉！"

translate chinese chinese_6518311_39:
    old "(Oh wow!)"
    new "（哦 wow!）"

translate chinese chinese_7073016_40:
    old "Ohhh yeah!"
    new "噢哦哦，是的！"

translate chinese chinese_0271195_41:
    old "Ahhh, yes! Right there."
    new "啊hh，对了！就那里。"

translate chinese chinese_7016076_42:
    old "This is so fucking good!"
    new "这他妈太好了！"

translate chinese chinese_7932161_43:
    old "Mmmm, I want to cum now!"
    new "嗯，我现在就要高潮了！"

translate chinese chinese_2305196_44:
    old "Oh, yeah! Yeahh!!!"
    new "哦，对！耶！！！"

translate chinese chinese_8916204_45:
    old "I'm cumming!"
    new "我要射了！"

translate chinese chinese_8378401_46:
    old "(Oh my god it's like my dream!)"
    new "（天啊，就像我的梦一样！）"

translate chinese chinese_7112531_47:
    old "Oh yeah, fuck my mouth [pla]."
    new "哦 yeah，操我嘴 [pla]。"

translate chinese chinese_8765528_48:
    old "Come on! I want you to fuck my throat harder!"
    new "来吧！我要你更用力地插我的喉咙！"

translate chinese chinese_3821442_49:
    old "A- alright..."
    new "好……"

translate chinese chinese_9627961_50:
    old "I want to have it all inside my mouth."
    new "我想全部放进嘴里。"

translate chinese chinese_8891249_51:
    old "Harder [pla], fuck my mouth harder!"
    new "再用力点[pla]，把我嘴fuck得更狠些！"

translate chinese chinese_6359940_52:
    old "Hmmm!"
    new "哼！"

translate chinese chinese_9447378_53:
    old "Don't stop, don't stop! Cum inside my throat!"
    new "别停，别停！射进我的喉咙里！"

translate chinese chinese_0279235_54:
    old "Ohh! It's so big..."
    new "哦！好大……"

translate chinese chinese_5733053_55:
    old "Your cock is so much better than my dildo."
    new "你的棒棒比我的 dildo 好多了。"

translate chinese chinese_2470852_56:
    old "Come on, I want you harder, fuck me harder [pla]!"
    new "来吧，我要你再用力点，狠狠地操我[pla]！"

translate chinese chinese_3627058_57:
    old "Do you like being inside your [sisrel]?"
    new "你喜欢待在你的[sisrel]里吗？"

translate chinese chinese_6183121_58:
    old "Yeah! Yeah! Fuck me [pla], Fuck me!"
    new "yeah! yeah! 干我啊 [pla], 干我啊!"

translate chinese chinese_0877436_59:
    old "Oh gosh! It's fucking huge!"
    new "天啊！它大得离谱！"

translate chinese chinese_0324012_60:
    old "You're drilling me"
    new "你在盘问我呢"

translate chinese chinese_7885930_61:
    old "I'M GONNA... I'M GONNA-"
    new "我要...我要..."

translate chinese chinese_4648128_62:
    old "OOOOOHHHH! YEAHHH..."
    new "噢噢噢噢噢！ yeah..."

translate chinese chinese_4680227_63:
    old "Fuck... It was really good..."
    new "妈的……真的很好……"

translate chinese chinese_6691854_64:
    old "Ok... Let me try, like this?"
    new "好吧……让我试试这样？"

translate chinese chinese_5787045_65:
    old "Just relax your hands and enjoy what you are doing, don't you like it?"
    new "just放松你的手，享受正在做的事情，你不觉得这样很好吗？"

translate chinese chinese_1952609_66:
    old "Gulp... Y-yes."
    new "吞咽... 是的。"

translate chinese chinese_0763671_67:
    old "Yeah, you're doing great, very gentle."
    new "是啊，你做得很好，很温柔。"

translate chinese chinese_5101901_68:
    old "(This is delicious, she is so hot.)"
    new "（这味道真好，她真是火辣。）"

translate chinese chinese_6039076_69:
    old "Do you like my ass?"
    new "你喜欢我的屁股吗？"

translate chinese chinese_3202031_70:
    old "Be creative, you can touch all you want! I like it."
    new "发挥点创意，你想摸哪里都行！我喜欢这样。"

translate chinese chinese_8105123_71:
    old "Do it harder baby..."
    new "再用力点宝贝..."

translate chinese chinese_5405731_72:
    old "Ugghh... It feels great."
    new "嗯……感觉真好。"

translate chinese chinese_2722022_73:
    old "Oh yeah... Fuck my pussy baby."
    new "哦 yeah... 来搞我吧宝贝。"

translate chinese chinese_4478546_74:
    old "Ohh yeah baby, don't stop."
    new "哦哦 yeah 宝贝，别停。"

translate chinese chinese_6816201_75:
    old "Yes! Yes! Just like that fuck me [pla]!"
    new "是的！是的！就那样操我[pla]！"

translate chinese chinese_0183583_76:
    old "Ohhh, ohhh, I'm goona cum. Harder. Fuck me harder!"
    new "哦哦，我要来了。再用力点。操我再用力点！"

translate chinese chinese_8072400_77:
    old "OHH GOD, OHH GOD. I'M CUMMING!"
    new "哦天啊，哦天啊。我要射了！"

translate chinese chinese_8748963_78:
    old "I- I'm cumming too!"
    new "我我也要来了！"

translate chinese chinese_0188458_79:
    old "Oh yeah... I can feel it all inside me."
    new "哦，是啊……我能感觉到全身都在反应。"

translate chinese chinese_4538748_80:
    old "I love playing with your cock"
    new "我喜欢玩你的鸡鸡"

translate chinese chinese_9526666_81:
    old "Enjoy the view..."
    new "欣赏一下景色吧……"

translate chinese chinese_5804639_82:
    old "Do you like my throat?"
    new "你喜欢我的喉咙吗？"

translate chinese chinese_6230304_83:
    old "Oh yes..."
    new "哦，是的……"

translate chinese chinese_2361398_84:
    old "Then, what are you waiting to fuck it?"
    new "那你还等什么，赶紧上吧？"

translate chinese chinese_6091684_85:
    old "Harder [pla], fuck your [sisrel] throat!"
    new "再用力点[pla]，狠狠地操你的[sisrel]喉咙！"

translate chinese chinese_5744839_86:
    old "[sis] I'm going to-"
    new "[sis] 我要——"

translate chinese chinese_5976272_87:
    old "Cum in my mouth baby..."
    new "在我嘴里高潮吧，宝贝..."

translate chinese chinese_9835894_88:
    old "Ughh, is so big."
    new "呃，好大。"

translate chinese chinese_7079700_89:
    old "I love it!!!"
    new "我爱死这个了！！！"

translate chinese chinese_1953234_90:
    old "Ohhh nicee baby, yeah fuck your [sisrel]!"
    new "噢哦很好宝宝，对就是那个[sisrel]！"

translate chinese chinese_8969003_91:
    old "Ohh I want you deep inside me..."
    new "哦，我要你深入我体内……"

translate chinese chinese_2898505_92:
    old "My pussy is gripping that fucking cock."
    new "我的 pussy 正紧抱着那个操蛋的 cock。"

translate chinese chinese_2823927_93:
    old "HARDER! FUCK ME HARDER BABY!"
    new "再用力点！操得我再狠点宝贝！"

translate chinese chinese_3044148_94:
    old "OH GOD, OH GOD! I'M CUMING!"
    new "哦 god，哦 god！我要射了！"

translate chinese chinese_1502693_95:
    old "I'm gonna-"
    new "我要去——"

translate chinese chinese_9415062_96:
    old "YES BABY CUM INSIDE ME!"
    new "快来高潮在里面射我啊！"

translate chinese chinese_6436550_97:
    old "Alright, now it's time to wake up."
    new "好了，现在该醒了。"

translate chinese chinese_1053074_98:
    old "This is a dream, dummy... "
    new "这是梦，傻瓜..."

translate chinese chinese_2204279_99:
    old "Did you really think that I would let you fuck my mouth?"
    new "真以为我会让你对我这样吗？"

translate chinese chinese_8739179_100:
    old "I- I-"
    new "我—我—"

translate chinese chinese_5119509_101:
    old "Hahaha! Hahahaha!"
    new "哈ahaha! 哈ahaha!"

translate chinese chinese_1530717_102:
    old "That’s right, just let me do the work."
    new "没错，就让我来搞定吧。"

translate chinese chinese_0981358_103:
    old "Mmmm! It’s so big."
    new "嗯！好大。"

translate chinese chinese_7762061_104:
    old "Do you feel ok? Has anything changed?"
    new "你感觉还好吗？有什么变化吗？"

translate chinese chinese_2898405_105:
    old "I do, it feels so different, human bodies are more sensitive after all."
    new "我感觉到了，差别真大，人类的身体毕竟更敏感。"

translate chinese chinese_5449043_106:
    old "But nothing has changed, no problem."
    new "但是没什么变化，没问题的。"

translate chinese chinese_2117900_107:
    old "Oh, yes, like that."
    new "哦，对，就是这样。"

translate chinese chinese_8041417_108:
    old "It feels soo great."
    new "感觉棒极了。"

translate chinese chinese_0612123_109:
    old "Do you feel any magic?"
    new "你感觉到有什么魔法吗？"

translate chinese chinese_7204895_110:
    old "Not yet... Ah! keep going."
    new "还不行……啊！继续。"

translate chinese chinese_3488183_111:
    old "Maybe in a little. Mmmm."
    new "maybe再过一会儿吧。mmm。"

translate chinese chinese_4795049_112:
    old "AH, AH, YES!"
    new "啊，啊，是的！"

translate chinese chinese_6364213_113:
    old "N- now I feel it."
    new "现在……感觉到了。"

translate chinese chinese_8683848_114:
    old "Don’t stop, keep going!"
    new "别停，继续！"

translate chinese chinese_1269127_115:
    old "I- I can’t hold it anymore."
    new "我- 我忍不住了。"

translate chinese chinese_5853088_116:
    old "Oh yes, do it!"
    new "哦 yeah，就这样！"

translate chinese chinese_0487050_117:
    old "Ohh yeahh!"
    new "哦哦 yeah!"

translate chinese chinese_6177629_118:
    old "Amazing, it’s incredible how much magic power you’re able to hold and release."
    new "太惊人了，你能够蕴含并释放出这么多魔力。"

translate chinese chinese_8353360_119:
    old "And doing it in a human body felt so different and good!"
    new "而在人类身体里做这件事感觉完全不同，而且好极了！"

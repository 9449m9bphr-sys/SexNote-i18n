# auto-tl Qwen Colab

translate chinese chinese_2450231_0:
    old "My god this dick is so big!"
    new "天啊，这玩意儿真大！"

translate chinese chinese_8440740_1:
    old "I noticed it the last time!"
    new "我上次就注意到了！"

translate chinese chinese_3612209_2:
    old "But having it in my mouth is just something else!"
    new "但被我含在嘴里就是不一样！"

translate chinese chinese_1911141_3:
    old "I bet you've never gotten head like this before right?"
    new "我敢打赌你之前从没这么吹过吧？"

translate chinese chinese_1038608_4:
    old "I know I'm so much better than my sister!"
    new "我知道我比姐姐强多了！"

translate chinese chinese_4255073_5:
    old "I'm sure there's no comparison!"
    new "我敢肯定没得比！"

translate chinese chinese_1263621_6:
    old "Is this good [pla]?!"
    new "这就是你说的好[pla]吗？！"

translate chinese chinese_9556575_7:
    old "Y- yeah, it is!"
    new "嗯，是的！"

translate chinese chinese_6678417_8:
    old "Slrrp! Mmm!"
    new "slurp! 呀呜！"

translate chinese chinese_1190122_9:
    old "Of course it is! I'm so much better than Olivia!"
    new "当然啦！我比奥利维亚强多了！"

translate chinese chinese_8052977_10:
    old "I- I can feel like you're about to finish!"
    new "我感觉你快要完事了！"

translate chinese chinese_0019157_11:
    old "Y- yeah! I am!"
    new "耶！我就是！"

translate chinese chinese_8975190_12:
    old "Do it! I want to get your cum in my mouth!"
    new "来吧！我想尝尝你的精液！"

translate chinese chinese_4666814_13:
    old "Look at how much you came!"
    new "看你流了这么多。"

translate chinese chinese_0066606_14:
    old "You see? I told you I was way better than Olivia!"
    new "你看？我跟你说过我比奥利维亚强多了！"

translate chinese chinese_8601528_15:
    old "I bet you've never had anything like that before!"
    new "我敢打赌你以前从没有过这样的经历！"

translate chinese chinese_6294528_16:
    old "Yeah, yeah..."
    new "嗯嗯……"

translate chinese chinese_7149522_17:
    old "Listen, get up before your mother or your sister come here and see us like this."
    new "听着，快起来，别让你妈妈或者妹妹看到我们这样。"

translate chinese chinese_8349649_18:
    old "Ugh, you're such a prude."
    new "哎呀，你真是个保守的人。"

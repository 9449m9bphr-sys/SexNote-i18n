# auto-tl Qwen Colab

translate chinese chinese_1106418_0:
    old "(Oh shit, I'm dead.)"
    new "（哦shit，这下完了。）"

translate chinese chinese_6986012_1:
    old "Wow! Are they... Having sex?"
    new "哇！他们……在做爱吗？"

translate chinese chinese_2045111_2:
    old "I should leave... I don't want to get caught peeping."
    new "我应该走了……不想被发现偷看。"

translate chinese chinese_1558942_3:
    old "(Damn, she's so tight! Oh shit! I feel like... I am going to...)"
    new "（妈的，她好紧！shit! 我觉得……我要……）"

translate chinese chinese_1122153_4:
    old "Fuck, baby. This new strap-on has a good lubrication system. It feels like a real cumshot... And it's so warm."
    new "操，宝贝。这个新的 strapon 润滑系统很好。感觉就像真的射了一样……而且这么暖和。"

translate chinese chinese_9547897_5:
    old "Mmm. Let me rest a little..."
    new "嗯。让我休息一会儿..."

translate chinese chinese_6736930_6:
    old "(Alright. I should get out of here.)"
    new "（好吧，我该离开了。）"

translate chinese chinese_3495247_7:
    old "(She's so tight! Oh shit, I feel like... I am going to...)"
    new "(她好紧！哦shit，我觉得我要...)"

translate chinese chinese_3213945_8:
    old "Mmm, still so good... Let me rest up, baby..."
    new "嗯，还是那么好……让我休息一下，宝贝……"

translate chinese chinese_0539179_9:
    old "(Ok, I should get out...)"
    new "（好吧，我该离开了……）"

translate chinese chinese_9605429_10:
    old "So nice to see like a little rat on the floor..."
    new "看到地板上像只小老鼠一样……真不错……"

translate chinese chinese_3109667_11:
    old "Are getting horny again?"
    new "又想起来了？"

translate chinese chinese_2630415_12:
    old "You're so gross... Getting horny just by sucking my foot."
    new "你真恶心……光舔我的脚就兴奋成这样。"

translate chinese chinese_9899344_13:
    old "Yeah! This is what you like..."
    new "对！这就是你喜欢的..."

translate chinese chinese_5956964_14:
    old "I see you want more and more... You are a disgusting needy bastard."
    new "我看你是越来越贪心了……你真是个下流的贪婪鬼。"

translate chinese chinese_0960741_15:
    old "That's what you deserve for being a fucking pervert!"
    new "你这个混蛋变态，活该！"

translate chinese chinese_6752785_16:
    old "I'm going to make you suck my foot! Every day you little rat!"
    new "我要让你给我舔脚！每天都要舔！你这只小老鼠！"

translate chinese chinese_2565433_17:
    old "That's it. Enough!"
    new "够了！"

translate chinese chinese_8732878_18:
    old "Fuck! This is gross... Now I have my foot full of your disgusting slime."
    new "操！真恶心……现在我的脚全是你的恶心黏液。"

translate chinese chinese_4579999_19:
    old "I hope you've learned your lesson and don't go back to being perverted with your disgusting hardon."
    new "希望你长点记性，别再带着那恶心的硬胀去猥亵别人了。"

translate chinese chinese_8958066_20:
    old "I need to clean myself from all this bullcrap..."
    new "我得从这一切垃圾中清理干净自己……"

translate chinese chinese_3574143_21:
    old "Is this what you like, you little pervert? Do you like that your boss treats you like a cockroach?"
    new "这就是你喜欢的吗，你这个小色鬼？你喜欢老板这样把你当蟑螂一样对待吗？"

translate chinese chinese_2880367_22:
    old "Does that turn you on, you fucking bastard?"
    new "这让你兴奋吗，你这个混蛋？"

translate chinese chinese_5436290_23:
    old "I ASKED YOU. ANSWER YOUR BOSS!"
    new "我问你呢。给老板回答！"

translate chinese chinese_6726156_24:
    old "Y- yes."
    new "是的。"

translate chinese chinese_5803300_25:
    old "Ohh poor baby, he thinks I'm doing this to please him..."
    new "哦呵，可怜的小家伙，他还以为我是为了取悦他呢……"

translate chinese chinese_0567866_26:
    old "I'm doing this to torture you ..."
    new "我这是在折磨你……"

translate chinese chinese_0757678_27:
    old "Because a pervert like you only thinks with the cock!"
    new "因为像你这样的色狼只会用那玩意儿思考！"

translate chinese chinese_8467869_28:
    old "So, I won't make you cum until you get humillied, and accept you are a cockroach and I am your master."
    new "所以，我不会让你射的，直到你被羞辱，并承认你是一只臭虫，我是你的主人。"

translate chinese chinese_8790742_29:
    old "I'm gonna make you my bitch [pla]."
    new "我要让你成为我的小奴隶 [pla]。"

translate chinese chinese_6111267_30:
    old "Ohh, are you close?"
    new "哦，快要来了吗？"

translate chinese chinese_5243665_31:
    old "Well, I'm not gonna let you cum."
    new "好吧，我不会让你射的。"

translate chinese chinese_8607232_32:
    old "If you want to cum, you have to beg for it."
    new "如果你想射，就得求我。"

translate chinese chinese_6102823_33:
    old "W- What?"
    new "什、什么？"

translate chinese chinese_0002724_34:
    old "Yes! Beg for it!"
    new "没错！求求吧！"

translate chinese chinese_8444712_35:
    old "P- please... L- let me cum..."
    new "求你了...让我高潮..."

translate chinese chinese_4643556_36:
    old "Do you realize how pathetic that sounds?"
    new "你意识到这话有多可笑吗？"

translate chinese chinese_7147112_37:
    old "You are a cockroach, a disgusting and perverted cockroach ... What are you?"
    new "你就是只蟑螂，肮脏变态的蟑螂……你是谁？"

translate chinese chinese_9349281_38:
    old "I- I am a... D- disgusting and p- perverted... Cockroach."
    new "我……我是……肮脏而且变态的……蟑螂。"

translate chinese chinese_3612051_39:
    old "And who am I?"
    new "而我是谁？"

translate chinese chinese_9419797_40:
    old "Uhh... Y- you are m- my boss..."
    new "呃……你是我老板……"

translate chinese chinese_2283887_41:
    old "I AM YOUR MASTER!"
    new "我是你的主人！"

translate chinese chinese_9017437_42:
    old "Uhh... My master, y- you are m- my master."
    new "呃……我的主人，你你你是我的主人。"

translate chinese chinese_5702824_43:
    old "That sounds much better."
    new "这样听起来好多了。"

translate chinese chinese_5111602_44:
    old "I guess you are finally learning."
    new "看来你终于学会点了。"

translate chinese chinese_0564493_45:
    old "Ahh..."
    new "啊……"

translate chinese chinese_9109783_46:
    old "Oh, are you close again?"
    new "哦，你们又接近了？"

translate chinese chinese_0064403_47:
    old "It would be a shame if I stop again, isn't it?"
    new "要是我又停下来的话，岂不是可惜了？"

translate chinese chinese_9876573_48:
    old "No, please... Don't stop... It hurts."
    new "不，求你了……不要停……这感觉好刺激。"

translate chinese chinese_7829919_49:
    old "Then beg your master!"
    new "那就向你的主人求饶吧！"

translate chinese chinese_6984766_50:
    old "Please, master... Please let me cum... I- I'm your... Slave!"
    new "求求你，主人……让我高潮吧……我我是你的……奴隶！"

translate chinese chinese_9034828_51:
    old "Yes, you are..."
    new "是的，你确实是..."

translate chinese chinese_2870474_52:
    old "Ahhhh!"
    new "啊hhh！"

translate chinese chinese_9194116_53:
    old "Ughh gross..."
    new "呃，真恶心..."

translate chinese chinese_3870075_54:
    old "I guess you are learning some respect here, aren't you?"
    new "看来你在这里学到了一些尊重，对吧？"

translate chinese chinese_1937568_55:
    old "Now, clean this, it's disgusting."
    new "现在，把这清理干净，真恶心。"

translate chinese chinese_1251598_56:
    old "Ohh yeah, just like that little bitch."
    new "哦呵，就是像那个小贱人一样。"

translate chinese chinese_4559660_57:
    old "Keep licking it."
    new "继续舔。"

translate chinese chinese_0897115_58:
    old "Wow, you are not completely useless after all."
    new "wow, 你原来也不是完全没用。"

translate chinese chinese_7042446_59:
    old "Ahh, finally you are doing a good job."
    new "啊，终于你干得不错了。"

translate chinese chinese_9843427_60:
    old "I see you love licking and kissing my pussy..."
    new "我看你很喜欢舔我的下体……"

translate chinese chinese_9219270_61:
    old "Ahh! Wow!"
    new "啊！好厉害！"

translate chinese chinese_6192092_62:
    old "Oh yeah, keep going little bitch!"
    new "哦 yeah，继续啊，小贱人！"

translate chinese chinese_3705444_63:
    old "I'm your master and you gotta lick me until I tell you to stop."
    new "我是你的主人，你得舔我直到我说停。"

translate chinese chinese_8214729_64:
    old "Don't stop, don't stop, you fucking bastard..."
    new "不要停，不要停，你这个混蛋..."

translate chinese chinese_6127881_65:
    old "Oh gosh! Ahhhhh! Fuck!"
    new "哦天啊！啊hhh！操！"

translate chinese chinese_2153789_66:
    old "Ahh, that wasn't bad, you are finally good at something."
    new "啊，这还不错，你终于有一项擅长的东西了。"

translate chinese chinese_6867218_67:
    old "T- Thank-"
    new "T- 谢-"

translate chinese chinese_3716668_68:
    old "Anyway, get out, I have to work."
    new "总之，出去，我得工作了。"

translate chinese chinese_0162692_69:
    old "Uhhh, I think you are improving."
    new "呃，我觉得你进步了。"

translate chinese chinese_9105910_70:
    old "Maybe I could reward you for doing a good job, maybe that way you will stop being a stupid useless at everything else."
    new "也许我可以因为你表现好奖励你，这样你就不会在其他事情上都那么愚蠢无用了。"

translate chinese chinese_5034767_71:
    old "W- what do you mean?"
    new "你、你什么意思？"

translate chinese chinese_6804384_72:
    old "I'm tough but fair, and you have pleased me these last two times."
    new "我虽然严厉但公平，而且你最近两次的表现让我很满意。"

translate chinese chinese_3253239_73:
    old "Now it's time for a reward for this little pervert. Now take out your pants."
    new "现在轮到这个小色鬼得到奖励了。把裤子脱了。"

translate chinese chinese_1246889_74:
    old "Y- yes master."
    new "是的，主人。"

translate chinese chinese_3264394_75:
    old "What are you waiting for? I'm not going to do it for you, if you want to cum you will have to do it yourself, idiot."
    new "你在等什么？我可不会替你做，如果你想射就自己来，白痴。"

translate chinese chinese_4329788_76:
    old "Uhh... R- right, sorry."
    new "呃……对、对不起。"

translate chinese chinese_2839765_77:
    old "Hahaha, you look like a poor animal begging to cum with my foot."
    new "哈哈，你看起来像一只可怜的动物，用脚就能让你射了。"

translate chinese chinese_7393069_78:
    old "Oh, you're getting more excited, just like a bitch in heat."
    new "哦，你越来越兴奋了，就像发情的母狗一样。"

translate chinese chinese_4177866_79:
    old "You are disgusting."
    new "你真恶心。"

translate chinese chinese_6124368_80:
    old "I see you're speeding up, Are you getting close?"
    new "我看你在加速，快要到了吗？"

translate chinese chinese_1572016_81:
    old "Y- yes..."
    new "是的..."

translate chinese chinese_4637997_82:
    old "Don't you dare come on my foot, because I kill you."
    new "你敢碰我的脚一下，我弄死你。"

translate chinese chinese_3252307_83:
    old "Ohh, your cock is about to explode but you cannot cum because I haven't said you can do so..."
    new "哦，你的家伙快要爆炸了，但你不能射，因为我还没说你可以射呢……"

translate chinese chinese_1978724_84:
    old "Poor boy can't cum because I won't let you do it. Unless you beg for it."
    new "可怜的孩子因为我不让你做而射不出来。除非你求我。"

translate chinese chinese_7188490_85:
    old "... P- please master... L- let me cum."
    new "... 求求您了主人... 让我高潮吧。"

translate chinese chinese_9858639_86:
    old "Hmm, I'm not sure... you should give it a better try."
    new "嗯，我不太确定……你应该再努力一点。"

translate chinese chinese_2355290_87:
    old "I- I- I am your bitch... Just a cockroach, and you are my master, p- please let this cockroach c- cum..."
    new "我…我是你的奴仆…… just一只蟑螂，而你是我的主人，求你让这只蟑螂高潮……"

translate chinese chinese_8213636_88:
    old "Hmm, why do I have to be so merciful? Alright, stop moving, I'm gonna help you out."
    new "哼，为什么我得这么慈悲呢？好吧，别动，我要帮你了。"

translate chinese chinese_1926768_89:
    old "One more time you see who is the Master..."
    new "再试一次你就知道谁才是主人了..."

translate chinese chinese_3174975_90:
    old "Y- Yes-"
    new "是的——"

translate chinese chinese_2140554_91:
    old "You're shit... Don't talk if I don't tell you so..."
    new "你真差劲……我没让你说话你就别开口……"

translate chinese chinese_9314322_92:
    old "S- sorr-"
    new "对不起——"

translate chinese chinese_3990236_93:
    old "Shut up!"
    new "闭嘴！"

translate chinese chinese_7018018_94:
    old "Yeahh! I like when you don't talk and only listen to your master."
    new "yeahh！我喜欢你不多话，只听主人的话。"

translate chinese chinese_8701728_95:
    old "Fucking pervert!"
    new "操，变态！"

translate chinese chinese_3100996_96:
    old "Shut up and follow my words... You won't talk if your master wants silence..."
    new "闭嘴，听我的话……主人想要安静你就不能说话……"

translate chinese chinese_2953320_97:
    old "Oh look at you so vulnerable and needy."
    new "哟，看你这么脆弱又渴望的样子。"

translate chinese chinese_9802047_98:
    old "Are you getting close? Because you look awful."
    new "你是不是快要不行了？因为你看起来糟透了。"

translate chinese chinese_9730752_99:
    old "Y- yes, master."
    new "是的，主人。"

translate chinese chinese_1771283_100:
    old "Alright, don't cum until I tell you."
    new "好吧，不要在我让你之前射。"

translate chinese chinese_1918998_101:
    old "Uhh, Y- yes, m- master."
    new "呃，是的，主人。"

translate chinese chinese_0263938_102:
    old "Ask for permission if you want to cum."
    new "想射的话就征求一下许可。"

translate chinese chinese_4369048_103:
    old "Yes! Ask your Master for permission."
    new "没错！向你的主人请求许可。"

translate chinese chinese_8233183_104:
    old "I need to cum... N- now, please."
    new "我需要高潮……现在，求你了。"

translate chinese chinese_0015782_105:
    old "M- Maste-"
    new "M- 主人-"

translate chinese chinese_0309510_106:
    old "You'll come whenever I want, not when you need to..."
    new "我会在你想见我的时候出现，而不是你方便的时候..."

translate chinese chinese_0874432_107:
    old "Say that you're my little bitch... Say it and I'll make you cum, maybe... Who knows if I'll change my mind."
    new "说你是我的小贱人……说了我就让你高潮，也许……谁知道我会不会改变主意。"

translate chinese chinese_6175773_108:
    old "I- I'm your L- little B- bitch."
    new "我……我是你的小贱人。"

translate chinese chinese_9219217_109:
    old "Let me cum, please..."
    new "让我射吧……"

translate chinese chinese_4686943_110:
    old "Uhh... Gross."
    new "呃……真恶心。"

translate chinese chinese_2029380_111:
    old "At least you're getting better on this."
    new "至少你在这件事上进步了。"

translate chinese chinese_4400533_112:
    old "Oh yeah, keep licking it."
    new "哦 yeah，继续舔。"

translate chinese chinese_4283792_113:
    old "Uhh this position is pretty good!"
    new "呃，这个姿势挺不错的！"

translate chinese chinese_5868488_114:
    old "Do you like it? Having your master pussy on your face?"
    new "你喜欢吗？被主人的蜜汁沾满脸庞的感觉？"

translate chinese chinese_0167878_115:
    old "Good boy, keep doing it, and I might reward you."
    new "好孩子，继续这样，我可能会奖励你。"

translate chinese chinese_6061639_116:
    old "Ahh! Yess!"
    new "啊！对！"

translate chinese chinese_6397956_117:
    old "Oh yeah, keep going, keep going!"
    new "哦 yeah，继续，继续！"

translate chinese chinese_9186031_118:
    old "You're my bitch... Keep doing it."
    new "你是我的小奴隶……继续。"

translate chinese chinese_4865738_119:
    old "Oh gosh! Ahhhh! Fuck!"
    new "天啊！啊hhh！操！"

translate chinese chinese_6971684_120:
    old "You're a bad employee but since you've done well today, I'm gonna give you something."
    new "你是个糟糕的员工，但因为你今天表现不错，我要给你点东西。"

translate chinese chinese_0610399_121:
    old "However, you will keep licking and you will make me cum again."
    new "然而，你会继续舔，直到我再次高潮。"

translate chinese chinese_3757958_122:
    old "Wow, you are definitely enjoying your master's pussy, right?"
    new "哇，你肯定很享受主人的 pussy，对吧？"

translate chinese chinese_9228373_123:
    old "Uhh I-"
    new "呃 我—"

translate chinese chinese_7918142_124:
    old "Don't ever stop licking, or I'll rip your cock off!"
    new "永远不要停下舔，不然我就把你那玩意儿给咬下来！"

translate chinese chinese_4985872_125:
    old "Look how much you enjoy it... Uhh? your little bastard."
    new "看你享受的样子……嗯？你这个小混蛋。"

translate chinese chinese_1661993_126:
    old "You are really a pervert, is this what you wanted? Uh?"
    new "你真是个色狼，这就是你想要的？嗯？"

translate chinese chinese_5147420_127:
    old "Just keep going."
    new "继续吧。"

translate chinese chinese_1081683_128:
    old "Oh yeah, keep going, make me cum again!"
    new "哦 yeah，继续，让我再来一次！"

translate chinese chinese_5194172_129:
    old "Don't stop, don't stop, you little bastard."
    new "别停，别停，你这小混蛋。"

translate chinese chinese_6101784_130:
    old "Ohhhh... F- Fuckk!"
    new "哦hhh... 去- 去操！"

translate chinese chinese_5898042_131:
    old "Okay, I'm done here, I hope you don't screw it up again at work. Otherwise, next time it will be worse."
    new "好了，我这边完了，希望你不要再把工作搞砸了。否则下次就更惨了。"

translate chinese chinese_4482084_132:
    old "Get dressed and leave, I can't waste any more time with you."
    new "穿好衣服走吧，我不能再浪费时间在你身上了。"

translate chinese chinese_8099683_133:
    old "Uhh that was good..."
    new "嗯，那个挺好的……"

translate chinese chinese_9709321_134:
    old "Alright, I'm gonna get dressed."
    new "好吧，我要去穿衣服了。"

translate chinese chinese_5827157_135:
    old "Oh gosh, I want a little more."
    new "哦天，我还想要多一点。"

translate chinese chinese_3668191_136:
    old "Shut up and keep licking. I'm going to try something different."
    new "闭嘴继续舔。我要试试别的。"

translate chinese chinese_5638522_137:
    old "Oh wow! What the fuck!"
    new "哦 wow！什么情况！"

translate chinese chinese_8592103_138:
    old "Don't even think about saying or doing something, keep quiet, and don't stop licking."
    new "别想说什么或做什么，保持安静，继续舔。"

translate chinese chinese_3503215_139:
    old "This is what you always wanted, isn't it?"
    new "这不就是你一直想要的吗？"

translate chinese chinese_5022775_140:
    old "Getting your naughty and disgusting cock sucked."
    new "被吸吮着你那肮脏下流的家伙。"

translate chinese chinese_1990632_141:
    old "Do you like it? Uh? Do you like your master sucking your cock?"
    new "你喜欢吗？嗯？你喜欢主人吸你的棒棒吗？"

translate chinese chinese_7703775_142:
    old "Of course you do, look how excited and horny you are."
    new "当然了，看你多兴奋多激动。"

translate chinese chinese_6935827_143:
    old "Ohh, yeah, keep going, keep licking my pussy, you little pervert."
    new "哦，对，继续，继续舔我的下体，你这个小色鬼。"

translate chinese chinese_9097629_144:
    old "Are you going to remain useless, good for nothing? Are you going to keep doing it so that I continue to punish you?"
    new "你要一直这么没用下去吗？你要一直让我惩罚你吗？"

translate chinese chinese_5768559_145:
    old "You're my bitch, [pla] never forget about it."
    new "你是我的奴隶，[pla] 永远记住了。"

translate chinese chinese_3779773_146:
    old "Ohh, yeah, don't stop, don't stop!"
    new "哦哦，对了，别停，别停！"

translate chinese chinese_8572411_147:
    old "I- I'm cumming!"
    new "我快要来了！"

translate chinese chinese_4684745_148:
    old "Ahhh I- I'm cumming to!"
    new "啊hhh 我要射了！"

translate chinese chinese_1892055_149:
    old "Ughhh, gross..."
    new "呕，真恶心……"

translate chinese chinese_4993244_150:
    old "I better go clean this up, it's disgusting... "
    new "我还是去清理一下吧，真恶心……"

translate chinese chinese_2076668_151:
    old "I'm your boss and your Master."
    new "我是你的老板，也是你的主人。"

translate chinese chinese_2975478_152:
    old "And you're shit... And you do what I say."
    new "而且你很烂……你得按我说的做。"

translate chinese chinese_8532686_153:
    old "Got it?"
    new "明白了吗？"

translate chinese chinese_2719161_154:
    old "You belong to me and I do whatever I fucking want with you."
    new "你属于我，我想要怎么对你就怎么对你。"

translate chinese chinese_7822287_155:
    old "Yeahh! This is what you like..."
    new "yeahh！这就是你喜欢的..."

translate chinese chinese_4849614_156:
    old "Fucking pervert! Fucking slave... Useless bitch."
    new "操你娘的变态！操你娘的奴隶……没用的贱人。"

translate chinese chinese_0707213_157:
    old "Your cock is really hard but I won't make you cum yet... Not if you are so eagered. You don't deserve to cum now."
    new "你的家伙真的硬得很，但我还不打算让你射……特别是你这么急色的话。你现在不值得射。"

translate chinese chinese_2725824_158:
    old "You are about to explode! isn't it? Fuck you!"
    new "你快要爆炸了吧？是不是？去你的！"

translate chinese chinese_5501790_159:
    old "Say who is your Master?"
    new "说，谁是你的主人？"

translate chinese chinese_2319478_160:
    old "Say it out loud NOW!"
    new "现在大声说出来！"

translate chinese chinese_1363250_161:
    old "If you wanna cum, you'll need to say it!"
    new "如果你想射，你就得说出来！"

translate chinese chinese_9242162_162:
    old "Y- You... You're my Master."
    new "你... 你是我的主人。"

translate chinese chinese_7054118_163:
    old "You want to cum... Poor boy can't come because I won't let him do it."
    new "你想射……可怜的小子射不了，因为我没让他射。"

translate chinese chinese_2716081_164:
    old "If you want to come, you have to beg for it again."
    new "如果你想来，就得再求我一次。"

translate chinese chinese_8193377_165:
    old "A- again..."
    new "再...一次..."

translate chinese chinese_3606632_166:
    old "Yes! Beg for it! You have to learn little bitch."
    new "没错！求求吧！你得学学呢，小贱人。"

translate chinese chinese_4725490_167:
    old "P- please, I- I need to cum... I really need it... N- now."
    new "求你了，我……我真的需要……现在。"

translate chinese chinese_3753096_168:
    old "You'll cum whenever I want not when you need to..."
    new "你什么时候高潮由我说了算，不是你想怎么来就怎么来..."

translate chinese chinese_6436808_169:
    old "Say that you're my bitch... Say it and I'll let you cum."
    new "说你是我的小贱人……说了我就让你射。"

translate chinese chinese_2315689_170:
    old "I'm your b- bitch, master..."
    new "我是你的贱人，主人..."

translate chinese chinese_8241443_171:
    old "I didn't expect this to happen but I'll do it..."
    new "我没想到会发生这种事，但我还是会做..."

translate chinese chinese_4171819_172:
    old "I've tried to show you who is the Master here but you still refuse to believe..."
    new "我试着让你明白谁才是这里的主人，但你还是不肯相信……"

translate chinese chinese_4928183_173:
    old "We cannot keep going in the same way... Now you'll know who is the master and who is the slave."
    new "我们不能一直这样下去……现在你就知道谁是主人，谁是奴隶了。"

translate chinese chinese_6142151_174:
    old "I'm your fucking Master and you're my slave, you listen and do as I say..."
    new "我是你的操蛋主人，你是我的奴隶，你得听我的话..."

translate chinese chinese_7301818_175:
    old "This is not a game! I'm gonna fuck you if I want, you do as I tell you..."
    new "这可不是游戏！我想上你就上你，你给我听着..."

translate chinese chinese_1558187_176:
    old "W- what-"
    new "什-什么-"

translate chinese chinese_9636186_177:
    old "Little bastard, useless and needy..."
    new "小混蛋，既没用又黏人……"

translate chinese chinese_8653222_178:
    old "I'm your Master and I want you to say it more often."
    new "我是你的主人，我想让你多说说这个。"

translate chinese chinese_8456615_179:
    old "M- Mas-"
    new "M- 姆-"

translate chinese chinese_7048142_180:
    old "I don't hear you!"
    new "我听不到你的声音！"

translate chinese chinese_1068437_181:
    old "Say it! Who is your Master?"
    new "说吧！谁是你的主人？"

translate chinese chinese_3215624_182:
    old "Y- You..."
    new "你..."

translate chinese chinese_2326076_183:
    old "Seems that the slave is doing okay..."
    new "看来这奴隶还过得去..."

translate chinese chinese_8512895_184:
    old "Are you enjoying this? Who told you to enjoy this... You're just a fucking slave..."
    new "你在享受这个吗？谁让你享受这个的……你不过是个该死的奴隶……"

translate chinese chinese_3820806_185:
    old "You're almost nonexistent... Without me, you're nothing. Without your Master, you're nothing."
    new "你几乎不存在……没有我，你就什么都不是。没有你的主人，你就什么都不是。"

translate chinese chinese_0097405_186:
    old "I'll make you suffer, motherfucker!"
    new "我会让你尝尝痛苦的滋味，混蛋！"

translate chinese chinese_6557049_187:
    old "You are about to explode! isn't it? Fucking idiot!"
    new "你快要爆炸了吧？蠢货！"

translate chinese chinese_0934572_188:
    old "I'm fucking you, little bastard."
    new "我操你，小兔崽子。"

translate chinese chinese_0892458_189:
    old "Now you are my bitch, I'm fucking my little bitch."
    new "现在你是我的小贱货，我在操我的小贱货。"

translate chinese chinese_4438890_190:
    old "Change perspective"
    new "改变视角"

translate chinese chinese_5654199_191:
    old "Ohh yeahh, can you feel how hard I'm fucking you?"
    new "哦哦，你能感觉到我有多用力吗？"

translate chinese chinese_6630072_192:
    old "Ahhh... I- I-"
    new "啊……我——我——"

translate chinese chinese_4140624_193:
    old "Yes, I'm cuming on you fucking bastard"
    new "是的，我要射了，你这个混蛋"

translate chinese chinese_9337029_194:
    old "All right, I already made you my bitch!"
    new "好吧，你已经成了我的小奴仆了！"

translate chinese chinese_3639962_195:
    old "Never ever, try to rebel against me, I am your master."
    new "永远不要反抗我，我是你的主人。"

translate chinese chinese_4112286_196:
    old "Oh, yes [mo2]! I missed you so much..."
    new "哦，是的[mo2]！我好想你..."

translate chinese chinese_0788510_197:
    old "Uhh... You are fucking hot babe..."
    new "呃……你真是辣妹一枚……"

translate chinese chinese_6367090_198:
    old "This feels so nice... Oh my God!"
    new "这感觉真好……天啊！"

translate chinese chinese_5962260_199:
    old "Ahhh, don't stop baby, don't stop!"
    new "啊hhh，别停宝贝，别停！"

translate chinese chinese_3436886_200:
    old "Oh yes! I have been waiting a lot for this!"
    new "哦 yeah！我等这一刻很久了！"

translate chinese chinese_9284469_201:
    old "I love you [mo2], I love you so much!"
    new "我爱你[mo2]，我超级爱你！"

translate chinese chinese_2913603_202:
    old "I love you too. You are my girl."
    new "我也爱你。你是我的女孩。"

translate chinese chinese_8271183_203:
    old "(What the fuck, she doesn't sound like the [mo2] I know...)"
    new "（靠，她听起来不像我认识的[mo2]……）"

translate chinese chinese_5321115_204:
    old "Oh yeah, just like that babe, Just like that!"
    new "哦 yeah，就是这样宝贝，就那样！"

translate chinese chinese_4620397_205:
    old "Ahhh, Ahhh! I love you."
    new "啊hhh，啊hhh！我爱你。"

translate chinese chinese_1346355_206:
    old "Keep going, keep going!"
    new "继续，继续！"

translate chinese chinese_7531809_207:
    old "Oh my God, I'm so fucking horny!"
    new "天啊，我好 horny！"

translate chinese chinese_7807093_208:
    old "Yes, Yes, cum for me baby!"
    new "嗯，嗯，为我高潮吧宝贝！"

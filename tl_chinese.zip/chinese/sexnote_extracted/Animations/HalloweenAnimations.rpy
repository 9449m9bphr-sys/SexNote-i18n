# auto-tl Qwen Colab

translate chinese chinese_5136639_0:
    old "I'm ready... Do your thing and put it in..."
    new "我准备好了……来吧，把它放进去……"

translate chinese chinese_3441494_1:
    old "Alright."
    new "好吧。"

translate chinese chinese_4877329_2:
    old "Oh God... It feels really nice... Your cock feels really nice in my ass..."
    new "哦天啊……感觉真好……你的 cock 在我屁股里感觉真好……"

translate chinese chinese_5356595_3:
    old "Uhh it feels.... Tight..."
    new "嗯，感觉……好紧……"

translate chinese chinese_8698217_4:
    old "Ohh yesss... Keep doing it... Fuck my ass [pla]... Fuck my ass!"
    new "哦哦是的……继续……操我的屁股[pla]……操我的屁股！"

translate chinese chinese_1392915_5:
    old "Ahhh... Ahhhh..."
    new "啊hhh... 啊hhh..."

translate chinese chinese_4126256_6:
    old "Ohh God! I'm coming... I'm coming!!!"
    new "哦天啊！我要来了... 我来了！！！"

translate chinese chinese_8432715_7:
    old "Ahhh...."
    new "啊hhh...."

translate chinese chinese_8983443_8:
    old "Does it feel nice baby?"
    new "感觉不错吧，宝贝？"

translate chinese chinese_4605191_9:
    old "It feels amazing, please don't stop!"
    new "感觉太棒了，请不要停下来！"

translate chinese chinese_1771744_10:
    old "Oh yes! Oh yes! Fuck my tits baby!"
    new "哦 yeah! 哦 yeah! 宝贝猛干我！"

translate chinese chinese_5979203_11:
    old "Ahh... Ahhh"
    new "啊... 啊啊"

translate chinese chinese_5915156_12:
    old "Fuck my tits harder [pla]! I want you to cum on my tits baby."
    new "操我奶头操硬点[pla]！我要你射在我奶头上宝贝。"

translate chinese chinese_6526595_13:
    old "Uhhhh..."
    new "呃……"

translate chinese chinese_3509506_14:
    old "I- I am going to... Ahhh"
    new "我——我要……啊hhh"

translate chinese chinese_3467390_15:
    old "Cum on my tits honey!"
    new "射在我胸上宝贝！"

translate chinese chinese_3123074_16:
    old "Did you have a double blowjob before [pla]?"
    new "你在[pla]之前有过双重口交吗？"

translate chinese chinese_9077809_17:
    old "Enjoy it baby!"
    new "享受吧，宝贝！"

translate chinese chinese_9096381_18:
    old "What does it feel like to have your [mo1rel] and [sisrel] sucking your dick?"
    new "被[mo1rel]和[sisrel]吸吮的感觉怎么样？"

translate chinese chinese_3077321_19:
    old "(OH MY GOD I CAN'T BELIEVE IT.)"
    new "（天啊，我不敢相信。）"

translate chinese chinese_9379488_20:
    old "It's probably his darkest fantasy..."
    new "这大概是他最黑暗的幻想吧……"

translate chinese chinese_1535112_21:
    old "And what about if you cum for us?"
    new "如果你为我们高潮呢？"

translate chinese chinese_8936656_22:
    old "Yes! Let's make him cum!"
    new "没错！让他射吧！"

translate chinese chinese_1978042_23:
    old "Oh my... I- I am going to... "
    new "哦我的天... 我要..."

translate chinese chinese_6548060_24:
    old "Don't stop [sis]."
    new "不要停[sis]。"

translate chinese chinese_9303978_25:
    old "What a HUGE cock [pla]!"
    new "这么大的鸡巴[pla]！"

translate chinese chinese_7035486_26:
    old "Does it taste great, isn't?"
    new "味道很棒吧，不是吗？"

translate chinese chinese_0696813_27:
    old "Oh yeah..."
    new "哦，对了……"

translate chinese chinese_3900729_28:
    old "Oh god I can't ever think about being fucked by this cock..."
    new "哦天哪，我再也不想被这根棒子操了..."

translate chinese chinese_1744223_29:
    old "Is fucking amazing... You should try it."
    new "简直太棒了……你应该试试。"

translate chinese chinese_1267662_30:
    old "Definetely I will..."
    new "我肯定……"

translate chinese chinese_4782224_31:
    old "Enought waste of time, I want to fuck! Let's make him cum."
    new "够了，别浪费时间了，我要上！让他射吧。"

translate chinese chinese_9278797_32:
    old "Yes! Let's make him cum again!"
    new "没错！让他再来一次吧！"

translate chinese chinese_0638335_33:
    old "I- I..."
    new "我—我..."

translate chinese chinese_8940736_34:
    old "Yeesss..."
    new "嗯哼……"

translate chinese chinese_3297005_35:
    old "Alright... What the fuck is happening here?"
    new "好吧……这里到底发生了什么？"

translate chinese chinese_1838862_36:
    old "Oh God! It's fucking huge..."
    new "哦上帝！它简直巨大得..."

translate chinese chinese_1172626_37:
    old "Does it hurt [mo2]?"
    new "这会疼吗，[mo2]？"

translate chinese chinese_2078501_38:
    old "A little bit, but it feels so good..."
    new "一点点，但感觉真好……"

translate chinese chinese_1379895_39:
    old "Oh my fucking God, he is drilling me!"
    new "哦我的上帝，他简直要钻死我了！"

translate chinese chinese_4441267_40:
    old "Don't stop, fuck me harder [pla]!"
    new "不要停，再用力点 [pla]！"

translate chinese chinese_9910506_41:
    old "Oh yessss! Harder, Fuck me harder baby!"
    new "哦耶耶耶！再用力点，宝贝，狠狠地操我！"

translate chinese chinese_8477543_42:
    old "Ahhhhh Ahhh, I'm cumming!"
    new "啊啊啊啊，我要来了！"

translate chinese chinese_0762269_43:
    old "Well, it's my turn now..."
    new "好吧，现在轮到我了..."

translate chinese chinese_8228108_44:
    old "I will bring one of our toys..."
    new "我会带一个我们的玩具过来..."

translate chinese chinese_1158224_45:
    old "We haven't tried anal sex in a long time... How does it feel to be completely filled?"
    new "我们很久没试过肛交了……被完全填满的感觉如何？"

translate chinese chinese_7867566_46:
    old "Ohhhhh God, this is like a double penetration! It's to much..."
    new "哦哦哦上帝，这就像双重 penetrations 一样！太多了吧..."

translate chinese chinese_5389498_47:
    old "OHHH WOW! I can't handle this!"
    new "噢哦哇！我受不了这个！"

translate chinese chinese_7018397_48:
    old "Ahhh Ahhhh!"
    new "啊hhh 啊hhh!"

translate chinese chinese_7760455_49:
    old "Let's fuck her harder [pla], let's fuck your [mo1rel] hard!"
    new "让我们狠狠地操她吧[pla]，狠狠地操你的[mo1rel]！"

translate chinese chinese_3923934_50:
    old "Oh oh yeeesss! I have never feel something like this!"
    new "哦哦耶耶斯！我从没感受过这样的感觉！"

translate chinese chinese_1255058_51:
    old "I- I... Ahhhhh I- am... Cumming!"
    new "我- 我... 噢噢噢 我- 快... 来了！"

translate chinese chinese_6056972_52:
    old "Holy shit... I'm fucking dry."
    new "卧槽……我干得简直。"

translate chinese chinese_2440064_53:
    old "Oh no... I have been waiting my turn."
    new "哦不……我一直在等着。"

translate chinese chinese_7489402_54:
    old "Honey, let him rest a bit, I'm going to help him get ready to fuck you too."
    new "宝贝，让他先休息一下，我去帮他准备一下，等会儿也帮你俩解决。"

translate chinese chinese_9299295_55:
    old "Hmmm Alright."
    new "嗯，好吧。"

translate chinese chinese_8680210_56:
    old "Now! I want it now!"
    new "现在！我现在就要！"

translate chinese chinese_2126702_57:
    old "Oh, honey just let me enjoy it a little bit more..."
    new "哦，亲爱的，就让我再享受一会儿..."

translate chinese chinese_4147360_58:
    old "Hmmm..."
    new "嗯……"

translate chinese chinese_1277507_59:
    old "NOW!"
    new "马上！"

translate chinese chinese_1240807_60:
    old "Let her fuck [pla], she wants to enjoy too, don't be selfish..."
    new "让她和[pla]做爱吧，她也想享受，别那么自私..."

translate chinese chinese_4233200_61:
    old "Alright... It's your turn [sis], enjoy it "
    new "好吧……现在轮到你了[sis]，尽情享受吧"

translate chinese chinese_9668307_62:
    old "Ohhhh yeahh, this is what I'm talking about..."
    new "噢哦哦，对了，说的就是这个感觉..."

translate chinese chinese_7633969_63:
    old "Does it feel good honey?"
    new "感觉好吗，宝贝？"

translate chinese chinese_0219648_64:
    old "It feels great, I never get tired of this..."
    new "感觉真好，我永远不会厌倦这种感觉……"

translate chinese chinese_7427836_65:
    old "Fuck me harder! I want you to make me cum like you did with [mo1rel]..."
    new "操得我再凶一点！我要你让我高潮，就像你对[mo1rel]做的那样..."

translate chinese chinese_2863632_66:
    old "Ohh yeah, just like that, don't stop baby."
    new "哦哦，就是这样，别停宝贝。"

translate chinese chinese_3550408_67:
    old "You are definetly a little pervert [pla], aren't you? You already fucked me, your [mo1rel] and now you are fucking your [sisrel]."
    new "你 definitely 是个小色鬼 [pla]，对吧？你已经搞了我，你的 [mo1rel]，现在又搞你的 [sisrel]。"

translate chinese chinese_9294418_68:
    old "Oh god, but it feels really good."
    new "哦天啊，但感觉真好。"

translate chinese chinese_7092042_69:
    old "Yes! He is making me cum!"
    new "是的！他在让我高潮！"

translate chinese chinese_0051197_70:
    old "Yesss Yesss... I'm cumming!!!"
    new "嗯嗯嗯...我要来了！！！"

translate chinese chinese_2849580_71:
    old "Ahhhhhh..."
    new "啊啊啊啊..."

translate chinese chinese_6165209_72:
    old "I want it on my mouth."
    new "我要它在我嘴里。"

# auto-tl Qwen Colab

translate chinese chinese_1685632_0:
    old "Oh yeah, sis! Woohoo!"
    new "哦耶，姐姐！哇哦！"

translate chinese chinese_0374041_1:
    old "I can tell how good you are at this!"
    new "我能看出来你很擅长这个！"

translate chinese chinese_9390271_2:
    old "Look at that huge cock filling your mouth!"
    new "看看那巨大的 cocks 填满了你的嘴！"

translate chinese chinese_1308972_3:
    old "I know you like it, sis!"
    new "我知道你喜欢的，姐姐！"

translate chinese chinese_8527479_4:
    old "With how big his cock is, I'd say you chose well!"
    new "看他那玩意儿多大，你说选得不错！"

translate chinese chinese_7579807_5:
    old "Look at you go to town on that monster cock!"
    new "看你爽得不得了的样子！"

translate chinese chinese_8875502_6:
    old "How about you, brother-in-law? Do you like it?"
    new "你呢，姐夫？你喜欢吗？"

translate chinese chinese_4969443_7:
    old "Come on, tell me! Don't leave me hanging!"
    new "快说嘛！别吊我胃口！"

translate chinese chinese_0060935_8:
    old "Slrrp, j- just answer her!"
    new "slurp, j-just回答她！"

translate chinese chinese_3242970_9:
    old "Haha! Oh yeah!"
    new "哈哈！对对对！"

translate chinese chinese_7160838_10:
    old "O- Olivia! I- I'm about to cum!"
    new "奥利维亚！我快要来了！"

translate chinese chinese_1021536_11:
    old "Yeah! Cum in her mouth! Come on!"
    new "yeah! 在她嘴里射! 来吧!"

translate chinese chinese_8563890_12:
    old "I want to see that!"
    new "我想看看那个！"

translate chinese chinese_0091699_13:
    old "I- it's alright, just let it out!"
    new "我——没事的，就让你的情绪宣泄出来吧！"

translate chinese chinese_1246785_14:
    old "Oh my gosh look at how much you came!"
    new "天啊，你看你射了这么多！"

translate chinese chinese_4404078_15:
    old "That's amazing!"
    new "太棒了！"

translate chinese chinese_3072283_16:
    old "I have to say, sis, this guy may not look like much."
    new "得说一声，姐，这人虽然看起来不起眼。"

translate chinese chinese_2099942_17:
    old "But he is certainly well gifted."
    new "但他确实很有天赋。"

translate chinese chinese_5265321_18:
    old "Oh shut up, just let me clean up and leave us alone."
    new "哦闭嘴，让我清理一下，然后让我们自己待着。"

translate chinese chinese_2843943_19:
    old "Oh, wow... Your cock is getting even harder..."
    new "哦，天啊……你的家伙变得更硬了……"

translate chinese chinese_4344019_20:
    old "It feels soft and warm though."
    new "不过感觉软软的，暖暖的。"

translate chinese chinese_7122993_21:
    old "Does my hand feel good?"
    new "觉得我的手摸起来舒服吗？"

translate chinese chinese_1456134_22:
    old "Yes, it feels really nice..."
    new "是的，感觉真的很舒服..."

translate chinese chinese_6832353_23:
    old "To be honest, it's the biggest I've ever seen..."
    new "说实话，这是我见过最大的……"

translate chinese chinese_0287947_24:
    old "I mean, it's pretty impresive..."
    new "我的意思是，这真的很厉害……"

translate chinese chinese_3022465_25:
    old "I'll do it a little faster..."
    new "我做得快一点……"

translate chinese chinese_1827981_26:
    old "Is that okay?"
    new "这样行吗？"

translate chinese chinese_9418568_27:
    old "Uhh, s- sure..."
    new "呃，好……"

translate chinese chinese_2494632_28:
    old "Ok, I think that's enough... I don't want you to waste your cum..."
    new "好吧，我觉得差不多了……我不想让你浪费了精液……"

translate chinese chinese_0681768_29:
    old "I mean, I need your sperm, you know the idea is to get pregnant..."
    new "我的意思是，我需要你的精子，你知道目的就是为了怀孕……"

translate chinese chinese_5595036_30:
    old "Uhh, yeah, you're right..."
    new "嗯，对，你是对的……"

translate chinese chinese_2191615_31:
    old "Alright, I'm going to take off my pants and get on the edge of the bed. I guess you know what to do..."
    new "好吧，我要脱裤子然后坐在床沿上了。我想你应该知道该怎么做吧……"

translate chinese chinese_8640678_32:
    old "Uhh, yeah, of course..."
    new "呃，对，当然……"

translate chinese chinese_3130277_33:
    old "Uhh, your cock is so big, so, I'm going to ask you to please be gentle..."
    new "呃，你的棒子好大，所以，请你温柔一点……"

translate chinese chinese_2317629_34:
    old "Ohh, s- sure, don't worry."
    new "哦，好、好的，别担心。"

translate chinese chinese_4740847_35:
    old "Hngh! Oh God!"
    new "嗯！哦上帝！"

translate chinese chinese_4132245_36:
    old "It's even bigger than I thought!"
    new "比我想象的还要大！"

translate chinese chinese_6438657_37:
    old "A- are you alright?"
    new "你、你还好吗？"

translate chinese chinese_8934460_38:
    old "Y- yes, don't worry, don't stop..."
    new "是的，别担心，不要停..."

translate chinese chinese_2266354_39:
    old "Come on, do it a little faster, I want you to cum inside me..."
    new "快点，再快一些，我想让你在里面高潮……"

translate chinese chinese_5389686_40:
    old "Mmm, it feels so deep... I've never felt anything like this before..."
    new "嗯，感觉好深……我从没感受过这样的东西……"

translate chinese chinese_6311124_41:
    old "Uhh... T- this is so good!"
    new "呃……这太好了！"

translate chinese chinese_2833674_42:
    old "Ughh... Yes..."
    new "呃……是的……"

translate chinese chinese_2563947_43:
    old "[pla] I- I'm about to finish!"
    new "[pla] 我快好了！"

translate chinese chinese_7501334_44:
    old "M- me too! I'm about to cum!"
    new "我也是！我要来了！"

translate chinese chinese_7907196_45:
    old "Y- yes! Yes! Cum inside me!"
    new "是的！是的！在里面射吧！"

translate chinese chinese_0335461_46:
    old "W- woah!"
    new "哇！"

translate chinese chinese_5593219_47:
    old "I- I wasn't expecting it to be that way."
    new "我——没想到会是这样。"

translate chinese chinese_7567041_48:
    old "I was a lot better than I thought!"
    new "我表现得比我想象中好得多！"

translate chinese chinese_2211360_49:
    old "Did you like it too [pla]?"
    new "你也很喜欢吧，[pla]？"

translate chinese chinese_6730365_50:
    old "Yeah, it was great."
    new "是的，真的很棒。"

translate chinese chinese_6072168_51:
    old "Alright, awesome!"
    new "好嘞，太棒了！"

translate chinese chinese_0971816_52:
    old "Now, let's get cleaned before my mom comes back and sees us."
    new "好了，赶紧洗个澡，免得我妈妈回来看到我们这样。"

translate chinese chinese_8930683_53:
    old "Ohhh, yeah, I've missed this feeling..."
    new "哦哦，是啊，我好久没这种感觉了……"

translate chinese chinese_0662510_54:
    old "[pla]! She's really liking this!"
    new "[pla]！她真的很喜欢这样！"

translate chinese chinese_0956269_55:
    old "I can see her emotions, she wants to get pregnant very badly!"
    new "我能看出来她的想法，她非常想怀孕！"

translate chinese chinese_7201087_56:
    old "Oh my God! Your cock is so big!"
    new "天啊！你的屌好大！"

translate chinese chinese_0784840_57:
    old "Yeah, yeah, just don't stop!"
    new "嗯哼，就是别停！"

translate chinese chinese_3511551_58:
    old "Oh God yes!"
    new "哦天啊，是的！"

translate chinese chinese_9060122_59:
    old "F- fuck me harder! Harder"
    new "妈的，再用力点！再用力点！"

translate chinese chinese_6914826_60:
    old "Mmm... I love this!"
    new "嗯……我喜欢这个！"

translate chinese chinese_2411103_61:
    old "O- Olivia! I think I'm about to cum!"
    new "奥利维亚！我觉得我要来了！"

translate chinese chinese_5498378_62:
    old "Y- yeah! D- do it!"
    new "耶！干吧！"

translate chinese chinese_2022483_63:
    old "Fill me up with your cum!"
    new "用你的精液填满我！"

translate chinese chinese_6202073_64:
    old "Get me pregnant!"
    new "让我怀孕！"

translate chinese chinese_9317076_65:
    old "God! That was fantastic [pla]!"
    new "天啊！那真是太棒了[pla]！"

translate chinese chinese_2293773_66:
    old "I can't believe how good it was!"
    new "真不敢相信有多棒！"

translate chinese chinese_3266982_67:
    old "I'm sure this time I'll be pregnant for real."
    new "这次我肯定真的怀孕了。"

translate chinese chinese_1220728_68:
    old "I hope so..."
    new "但愿如此……"

translate chinese chinese_3329825_69:
    old "Alright, let's get up and get cleaned before my family comes back."
    new "好吧，起来洗个澡，别让我家人回来了看到这样。"

translate chinese chinese_3839168_70:
    old "Ah! ah! I'm loving it!"
    new "啊！啊！我喜欢！"

translate chinese chinese_6889398_71:
    old "I've missed your dick so much [pla]!"
    new "我好想你的棒棒啊，[pla]！"

translate chinese chinese_1041214_72:
    old "There's just nothing like it!"
    new "这感觉真是无与伦比！"

translate chinese chinese_5046333_73:
    old "D- do you like it [pla]?"
    new "你喜不喜欢啊，[pla]？"

translate chinese chinese_2516364_74:
    old "How it feels?"
    new "感觉怎么样？"

translate chinese chinese_8832512_75:
    old "Oh god yes this is just what I've been missing!"
    new "哦天啊，这正是我一直在渴望的！"

translate chinese chinese_3007791_76:
    old "I can already start to feel myself getting better!"
    new "我已经开始感觉到自己变好了！"

translate chinese chinese_4169407_77:
    old "This is unbelievable!"
    new "这简直难以置信！"

translate chinese chinese_7629551_78:
    old "Oh [pla]! I'm about to cum!"
    new "哦[pla]！我要来了！"

translate chinese chinese_4741456_79:
    old "G- great! Let's do it together!"
    new "太好了！我们一起做吧！"

translate chinese chinese_3489184_80:
    old "Oh God! That was so great!"
    new "哦天啊！那真是太棒了！"

translate chinese chinese_4109371_81:
    old "I can't believe how good it felt [pla]!"
    new "真不敢相信[pla]感觉这么好！"

translate chinese chinese_6329285_82:
    old "I think that's just what I needed!"
    new "我觉得这正是我需要的！"

translate chinese chinese_6903948_83:
    old "I- I'm glad it helped you."
    new "我——我很高兴能帮到你。"

translate chinese chinese_7450050_84:
    old "Did you like it too?"
    new "你也喜欢吗？"

translate chinese chinese_3383346_85:
    old "Oh yeah, it was very good."
    new "哦 yeah，非常好。"

translate chinese chinese_3796803_86:
    old "Now, how about we get up before your Mom comes back."
    new "现在，咱们还是在你妈妈回来前起床吧。"

translate chinese chinese_0242983_87:
    old "Sure!"
    new "行！"

translate chinese chinese_7593052_88:
    old "Oh god! Yes! Yes!"
    new "哦天啊！是的！是的！"

translate chinese chinese_3426338_89:
    old "Oh yes daddy! Fuck me just like that!"
    new "哦是的爸爸！就那样操我！"

translate chinese chinese_2619047_90:
    old "This is so amazing [pla]!"
    new "这真是太棒了，[pla]！"

translate chinese chinese_6875527_91:
    old "That's it [pla]!"
    new "就是你了[pla]！"

translate chinese chinese_1346397_92:
    old "Keep going! That's just what's needed for the spell!"
    new "继续！这正是咒语需要的！"

translate chinese chinese_0175640_93:
    old "Oh God [pla]!"
    new "哦天啊[pla]！"

translate chinese chinese_7533444_94:
    old "Y- you're making me go insane!"
    new "你你你把我搞疯了！"

translate chinese chinese_7843843_95:
    old "This is so great!"
    new "太棒了！"

translate chinese chinese_9649716_96:
    old "Oh fuck yes! I want you to fill me up!"
    new "哦操对！我要你填满我！"

translate chinese chinese_6018556_97:
    old "You've already extracted the magic power! Let yourself go!"
    new "你已经抽取了魔力！放纵自己吧！"

translate chinese chinese_7307878_98:
    old "That was awesome [pla]!"
    new "太棒了[pla]！"

translate chinese chinese_5828339_99:
    old "Just what we needed to end the ritual!"
    new "正好用来结束仪式！"

translate chinese chinese_2601970_100:
    old "Oh God [pla] that felt so good!"
    new "哦上帝 [pla] 这感觉真好！"

translate chinese chinese_7147255_101:
    old "Oh god [pla]! The taste of your dick!"
    new "哦天啊[pla]！你那味道！"

translate chinese chinese_0079426_102:
    old "This is such an amazing dick!"
    new "这真是个棒极了的丁丁！"

translate chinese chinese_9734152_103:
    old "It never disappoints me!"
    new "它从不会让我失望！"

translate chinese chinese_2260640_104:
    old "I just love feeling it in my mouth!"
    new "我就是喜欢那种在嘴里的感觉！"

translate chinese chinese_7003500_105:
    old "I love it [pla]!"
    new "我超爱的，[pla]！"

translate chinese chinese_7395113_106:
    old "I love this dick!"
    new "我爱这个棒货！"

translate chinese chinese_2648765_107:
    old "I love it's taste and smell!"
    new "我爱它的味道和香气！"

translate chinese chinese_0697366_108:
    old "O- Olivia! I- ugh! I can't hold it in anymore!"
    new "奥利维亚！我忍不住了！"

translate chinese chinese_5847518_109:
    old "That's alright! I don't want you to!"
    new "没关系！我不希望你这么做！"

translate chinese chinese_9941821_110:
    old "You don't need to hold it in!"
    new "你不用憋着！"

translate chinese chinese_5373075_111:
    old "Let go and fill my mouth with your hot cum!"
    new "松开，让我嘴里充满你的热精液！"

translate chinese chinese_2528419_112:
    old "Mmm! That's an amazing taste [pla]!"
    new "嗯！味道真好[pla]！"

translate chinese chinese_3776954_113:
    old "This is just wonderful!"
    new "这真是太好了！"

translate chinese chinese_2273270_114:
    old "I- I'm glad you like it."
    new "我——我很高兴你喜欢。"

translate chinese chinese_7901550_115:
    old "Oh yeah, I love it!"
    new "哦 yeah，我爱死这个了！"

translate chinese chinese_0078257_116:
    old "Now, I think we should get clean before my mom comes back and finds us like this."
    new "现在，我觉得我们应该先清理一下，免得我妈妈回来发现我们这样。"

translate chinese chinese_5719808_117:
    old "Sure, sure!"
    new "行行行！"

# auto-tl Qwen Colab

translate chinese chinese_2407586_0:
    old "Holy shit! You really have a big cock!"
    new "卧槽！你真的很大啊！"

translate chinese chinese_6304610_1:
    old "That makes it even better to share my power with you!"
    new "这让我更想和你分享我的力量了！"

translate chinese chinese_8265993_2:
    old "Do you feel how your body receive my magical power within you?"
    new "你能感觉到我的魔力在你体内流动吗？"

translate chinese chinese_5189565_3:
    old "Ah?... Yes, yes... That's what I'm feeling..."
    new "啊？...是的，是的...那就是我的感觉..."

translate chinese chinese_0673318_4:
    old "Let's do it faster so you get more power!"
    new "动作快点，让你更有力！"

translate chinese chinese_2375231_5:
    old "Oh! Wow..."
    new "哦！ wow..."

translate chinese chinese_3187526_6:
    old "Do you feel it? Do you feel all the power within me?"
    new "你感觉到了吗？你感觉到了我身上的全部力量吗？"

translate chinese chinese_8593987_7:
    old "Yes, yes... I actually think I'm going to..."
    new "嗯，嗯……我实际上觉得我要……"

translate chinese chinese_2051543_8:
    old "Well that is enough for now..."
    new "好吧，现在就到此为止吧……"

translate chinese chinese_2623043_9:
    old "Now you have more magic power."
    new "现在你的魔法力量更多了。"

translate chinese chinese_4381886_10:
    old "If you need more just let me collect some magic power for a couple of days..."
    new "如果你需要更多，我就再收集几天魔力……"

translate chinese chinese_6469906_11:
    old "Or you could share more with me for me to give you back just for fun."
    new "或者你可以多分享一些给我，我也可以反过来逗逗你。"

translate chinese chinese_2085517_12:
    old "Actually that's a good idea, I'll keep that in mind..."
    new "实际上这是个好主意，我会记住的……"

translate chinese chinese_1277142_13:
    old "Great..."
    new "真好……"

translate chinese chinese_6946204_14:
    old "Uhh, it's definitely huge!"
    new "呃，那绝对很大！"

translate chinese chinese_7237936_15:
    old "You'll be definitely be one of the best Sexnote owners..."
    new "你肯定会成为最好的Sexnote主人之一..."

translate chinese chinese_5467822_16:
    old "Ohh yeah, just like that! Oh gosh it feels amazing!"
    new "哦哦是的，就是这样！天啊感觉太棒了！"

translate chinese chinese_1559543_17:
    old "Mmm, are you enjoying the magic transfer?"
    new "嗯，你在享受这个魔法转移吗？"

translate chinese chinese_2209498_18:
    old "I want more! Give me all you have!"
    new "我要更多！全都给我！"

translate chinese chinese_2942087_19:
    old "Oh yeah, don't stop, don't stop! Get all my power!"
    new "哦 yeah，别停，别停！把我的力量都拿走！"

translate chinese chinese_6555318_20:
    old "I- I cumming!"
    new "我快来了！"

translate chinese chinese_1164833_21:
    old "Ohhh yesss!"
    new "噢耶！"

translate chinese chinese_3895183_22:
    old "Phew! That was AWESOME!"
    new "呼！那真是太棒了！"

translate chinese chinese_3178856_23:
    old "I really missed this."
    new "我真的好想念这个。"

translate chinese chinese_7415215_24:
    old "Oh fuck... I'm going to..."
    new "哦操... 我要..."

translate chinese chinese_4013776_25:
    old "I love to do this..."
    new "我喜欢这样做..."

translate chinese chinese_0665743_26:
    old "Did you get good magic power?"
    new "你的魔力提升了吗？"

translate chinese chinese_0174577_27:
    old "Yes, but you can always give me more if you want..."
    new "可以，但如果你想给更多也可以……"

translate chinese chinese_5970477_28:
    old "Not now, I Need to use it to improve my skills first."
    new "现在不行，我得先用它来提升我的技能。"

translate chinese chinese_4803681_29:
    old "You are right..."
    new "你说得对..."

translate chinese chinese_6349651_30:
    old "By the way, I could help you too when you get an boner."
    new "对了，你硬的时候我也可以帮你。"

translate chinese chinese_5040552_31:
    old "Now that you mention it, I have a question... If I ever get to do something like this with a woman... Will I lose magical power?"
    new "说起来，我有个问题……如果有一天我也能和女人做这种事……我会失去魔力吗？"

translate chinese chinese_0421664_32:
    old "To do what, have some sexual activity?"
    new "去做什么，发生关系？"

translate chinese chinese_6585678_33:
    old "Ehh... Well, yes..."
    new "呃……嗯……是的……"

translate chinese chinese_4624564_34:
    old "Don't worry! In fact, you should do it. "
    new "别担心！事实上，你应该这么做。"

translate chinese chinese_2061863_35:
    old "What do you mean?"
    new "你是什么意思？"

translate chinese chinese_7159536_36:
    old "Humans have a very particular phenomenon, when they have some high sexual excitation they generate magical power..."
    new "人类有一种很特殊的现象，当他们性兴奋到一定程度时就会产生魔力……"

translate chinese chinese_2782560_37:
    old "That magic power usually disappear quickly because there is nobody enabled to store that energy..."
    new "那种魔力通常会很快消失，因为没有人能储存那种能量……"

translate chinese chinese_0327183_38:
    old "But you can, so, any kind of sexual activity will help you generate magical power and the more intense or higher sexual excitation the more magical power you will receive..."
    new "但是你可以通过任何形式的性活动来生成魔法力量，而且性兴奋越强烈，获得的魔法力量就越多……"

translate chinese chinese_9039605_39:
    old "That is why within your objectives as a chosen, you must have a lot of sex, only then can you restore the magical world and regenerate the sources of magical power..."
    new "正因为如此，作为被选中者，你的目标之一就是必须有很多性行为，只有这样你才能恢复魔法世界并再生魔法力量源泉……"

translate chinese chinese_3758204_40:
    old "What the Fuck? You didn't tell me that..."
    new "卧槽？你没告诉我那件事..."

translate chinese chinese_9589044_41:
    old "I'm telling you right now... It's that there are many things and I don't remember them all..."
    new "我现在告诉你……就是有很多事情，我记不住全部……"

translate chinese chinese_7312644_42:
    old "So I have to have a lot of sex to receive magical power?"
    new "所以我要通过频繁的性行为来获得魔法力量？"

translate chinese chinese_4829686_43:
    old "Actually, You must seek to reach the maximum of sexual arousal, so you must experiment a lot to see what is the most exciting for you..."
    new "实际上，你必须追求最大程度的性兴奋，所以你得尝试很多东西来看看什么最能让你兴奋……"

translate chinese chinese_1415284_44:
    old "Hmmm... Ok, I'll see how to do something about it"
    new "嗯……好吧，我会看看怎么处理这件事。"

translate chinese chinese_5650889_45:
    old "It was great..."
    new "太棒了……"

translate chinese chinese_1108637_46:
    old "Yes, it was really fun... I want to do it again."
    new "是的，真的很有趣……我想再做一次。"

translate chinese chinese_8122835_47:
    old "Maybe later when I get more Magic Power..."
    new "maybe later when I get more Magic Power... \n也许等我魔力充足一点再考虑吧..."

translate chinese chinese_8812474_48:
    old "There you go [pla]."
    new "就是你了[pla]。"

translate chinese chinese_2402910_49:
    old "Let yourself enjoy this."
    new "让自己享受这一刻。"

translate chinese chinese_3918053_50:
    old "It's very important that you relax."
    new "你放松非常重要。"

translate chinese chinese_2438982_51:
    old "Are you liking this [pla]?"
    new "你喜不喜欢这个[pla]？"

translate chinese chinese_0716412_52:
    old "Good! That's the most important part!"
    new "好！这才是最重要的部分！"

translate chinese chinese_5117217_53:
    old "I've always thought this [pla]! But as a human, your cock is very impressive!"
    new "我一直觉得这个[pla]！但是作为人类，你的鸡巴真的很棒！"

translate chinese chinese_0108871_54:
    old "It's incredible that is rock hard!"
    new "真不敢相信这硬得像个岩石！"

translate chinese chinese_2628810_55:
    old "I- I feel like I'm about to cum Brixxida!"
    new "我快来了，布里克西达！"

translate chinese chinese_7306648_56:
    old "Yeah! That's good! Do it!"
    new "对！很好！就这样做！"

translate chinese chinese_8579583_57:
    old "Cum! I want you to shoot everything into the portal!"
    new "射！我要你把所有的东西都射进那个门户里！"

translate chinese chinese_9866096_58:
    old "That's perfect [pla]!"
    new "那正是完美的[pla]！"

translate chinese chinese_2282140_59:
    old "Look at that! I can already tell that the portal is starting to charge!"
    new "看那！我都能看出传送门已经开始充能了！"

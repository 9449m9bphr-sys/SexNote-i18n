# auto-tl Qwen Colab

translate chinese chinese_4980926_0:
    old "I'm stimulating your testicles while I masturbate you so I can get the maximum amount of semen out."
    new "我一边刺激你的睾丸一边帮你自慰，这样能让你射出最多的精液。"

translate chinese chinese_0321242_1:
    old "How is it? Do you feel ok?"
    new "怎么样？感觉还好吗？"

translate chinese chinese_4154032_2:
    old "Y- yes ma'am"
    new "是的，长官"

translate chinese chinese_4366040_3:
    old "Just relax and let me do the job. I promise it won't feel bad."
    new "放松点，让我来处理。我保证不会难受的。"

translate chinese chinese_1641985_4:
    old "O- ohhh! I- I think I'm getting close."
    new "哦哦！我觉 得我要接近了。"

translate chinese chinese_6169381_5:
    old "Yes! I can feel your body tensing up."
    new "没错！我能感觉到你的身体在紧张。"

translate chinese chinese_6391542_6:
    old "Mmmm! It's so hard!"
    new "嗯！好硬啊！"

translate chinese chinese_7395421_7:
    old "Ma'am I-I think I'm cumming!"
    new "夫人，我……我要射了！"

translate chinese chinese_1097776_8:
    old "Yes! I want you to!!"
    new "是的！我就想要你这么做！！"

translate chinese chinese_5328343_9:
    old "Slurrp! That's it, let it all out!"
    new "咕噜！就是这样，全部吐出来！"

translate chinese chinese_2440157_10:
    old "That was impressive, you came a lot."
    new "挺厉害的，你来得不少。"

translate chinese chinese_6235282_11:
    old "This will really help me a lot. I'm already starting to feel it's effects."
    new "这真的会帮到我很多。我已经开始感觉到它的效果了。"

translate chinese chinese_2083780_12:
    old "Really? Already? Well, I'm happy it worked."
    new "真的？这么快？好吧，我很高兴成功了。"

translate chinese chinese_9555173_13:
    old "It really did. And I can't believe you came that much."
    new "确实如此。真不敢相信你来了这么多。"

translate chinese chinese_8046214_14:
    old "Although we made a bit of a mess."
    new "虽然我们弄得有点乱。"

translate chinese chinese_3815754_15:
    old "Sorry, I sometimes can't control myself."
    new "对不起，我有时候控制不住自己。"

translate chinese chinese_3101195_16:
    old "It's ok, you were helping me anyway. Just wait a second and I'll clean myself."
    new "没关系，你本来就在帮我。等一下，我马上就收拾干净。"

translate chinese chinese_1189086_17:
    old "Wow!"
    new "哇！"

translate chinese chinese_5916423_18:
    old "Just relax and enjoy it."
    new "放松点，享受一下吧。"

translate chinese chinese_7216612_19:
    old "Y- yes ma'am."
    new "是的，长官。"

translate chinese chinese_5906007_20:
    old "Ahh! I-I feel like I'm getting better already"
    new "啊！我感觉我已经好转了"

translate chinese chinese_2855933_21:
    old "Oh yes! Just like this..."
    new "哦，就是这样..."

translate chinese chinese_8542221_22:
    old "Keep going! Don't stop!"
    new "继续！不要停！"

translate chinese chinese_6126393_23:
    old "Yes! Yes! I can feel it!"
    new "是的！是的！我感觉到了！"

translate chinese chinese_3588116_24:
    old "This is amazing! Your dick fills me up completely!"
    new "太棒了！你的家伙完全填满了我！"

translate chinese chinese_0384674_25:
    old "Ahhh! Ohhhh!"
    new "啊hhh！哦hhh！"

translate chinese chinese_9290872_26:
    old "Cum, now! I want to feel your cum fill me up."
    new "射吧，现在！我想感觉到你的精液充满我。"

translate chinese chinese_1928110_27:
    old "Y- yes! I'm about to!"
    new "是、是的！我马上就好！"

translate chinese chinese_3487559_28:
    old "That's it! Yes!"
    new "就是这个！没错！"

translate chinese chinese_7713975_29:
    old "Phew! That was impressive [pla]. Not only are you that well endowed, you know how to use your penis."
    new "呼！[pla]真厉害。不仅装备这么好，还知道怎么使用你的家伙。"

translate chinese chinese_6898516_30:
    old "It's fantastic!"
    new "太棒了！"

translate chinese chinese_3777655_31:
    old "T- thank you Miss. I'm glad you liked it."
    new "谢、谢谢您。很高兴您喜欢。"

translate chinese chinese_5722716_32:
    old "And I hope I was of help."
    new "希望我帮上忙了。"

translate chinese chinese_9069650_33:
    old "Oh, I'm sure you were."
    new "哦，我敢肯定你就是这样做的。"

translate chinese chinese_3961898_34:
    old "You came a great amount. I have no doubt I'll feel better with this."
    new "你来得很多。我敢肯定有了这个我会感觉好些。"

translate chinese chinese_3738214_35:
    old "Now, we better get dressed, it's late and you have to go home."
    new "现在，我们还是穿好衣服吧，天晚了，你得回家了。"

translate chinese chinese_0834399_36:
    old "Yes ma'am."
    new "是的，小姐。"

translate chinese chinese_8621732_37:
    old "Just relax. And Iet us do the work."
    new "just relax. 和我们一起来。"

translate chinese chinese_4570028_38:
    old "We'll get you off in no time."
    new "我们会很快把你弄出来的。"

translate chinese chinese_0523992_39:
    old "Y- yes, I am."
    new "是的，我是。"

translate chinese chinese_9011246_40:
    old "Your penis is always so impressive [pla]!"
    new "你的 penis 总是这么厉害，[pla]！"

translate chinese chinese_5161773_41:
    old "Mmm, and it has such a nice taste!"
    new "嗯，味道真不错！"

translate chinese chinese_7621302_42:
    old "Slurrp! Your dick... it's so warm, and it feels so nice in my mouth."
    new "啧啧，你的棒棒……好温暖，在我嘴里感觉好舒服。"

translate chinese chinese_2333796_43:
    old "I- it's so big..."
    new "它好大……"

translate chinese chinese_7496564_44:
    old "Your dick it's so amazing! I can feel it throbbing!"
    new "你的棒棒太棒了！我能感觉到它的跳动！"

translate chinese chinese_2032070_45:
    old "Yes! just like this! it's so nice!"
    new "没错！就是这样！感觉真好！"

translate chinese chinese_4189255_46:
    old "It's so long! And so thick!"
    new "好长！而且还那么粗！"

translate chinese chinese_3578980_47:
    old "I can feel it, you're getting close!"
    new "我感觉到了，你越来越近了！"

translate chinese chinese_0630599_48:
    old "I- I think I'm gonna...!"
    new "我— 我觉得我要...！"

translate chinese chinese_8913618_49:
    old "Mmmm! Yes!"
    new "嗯！是的！"

translate chinese chinese_4638329_50:
    old "It's ok, do it. Cum for us!"
    new "没事，来吧。为我们射吧！"

translate chinese chinese_4185166_51:
    old "That was amazing [pla]! How do you feel? I hope you're not too drained."
    new "那真是太棒了[pla]！你觉得怎么样？希望你不要太累。"

translate chinese chinese_7410626_52:
    old "Not at all, I feel very well... I know I can keep going."
    new "一点也不，我感觉很好……我知道我可以继续下去。"

translate chinese chinese_6368453_53:
    old "Wow, Y- you're not tired? Amazing!"
    new "哇，你你不累吗？真厉害！"

translate chinese chinese_2143746_54:
    old "Incredible, I'd never met anybody that wouldn't feel tired after getting a blowjob from one of us. Let alone three!"
    new "真不可思议，我从来没见过有人在被我们其中一个口后还不觉得累的。更别提三个了！"

translate chinese chinese_2615115_55:
    old "I told you, this young man is the key for us to get better."
    new "我跟你说过了，这个小伙子是我们好转的关键。"

translate chinese chinese_8573558_56:
    old "And we're just getting started."
    new "这才刚开始呢。"

translate chinese chinese_8872889_57:
    old "My god! Look at this, you just came, and yet your cock is still rock hard."
    new "我的天！你看这，你刚来，鸡巴还是硬得跟石头一样。"

translate chinese chinese_9355750_58:
    old "Amazing!"
    new "太棒了！"

translate chinese chinese_6887297_59:
    old "Hurry up mother, I think you're wanting it."
    new "快点妈妈，我觉得你想要呢。"

translate chinese chinese_6025037_60:
    old "Mmm, I am darling, I am."
    new "嗯，我就是亲爱的本人。"

translate chinese chinese_1193609_61:
    old "Now [pla], let's beginning."
    new "现在[pla]，让我们开始吧。"

translate chinese chinese_6251527_62:
    old "Uhhh... Your cock... It's so big!"
    new "呃……你的棒棒……好大！"

translate chinese chinese_4196370_63:
    old "Mmm! It fills me up completely!"
    new "嗯！这让我完全满足了！"

translate chinese chinese_2173250_64:
    old "Wow mother, he really is deep into you!"
    new "妈，他真是对你挺感兴趣的！"

translate chinese chinese_4720453_65:
    old "Mmm, I can see you're enjoying it a lot!"
    new "嗯，看得出来你很享受呢！"

translate chinese chinese_4702601_66:
    old "Ahh! Yes dear, It would be... Ahh! Impossible not to."
    new "啊！是的，亲爱的，那会……啊！无法抗拒的。"

translate chinese chinese_6714357_67:
    old "Oh yeah, just like this..."
    new "哦，就是这样的..."

translate chinese chinese_3360121_68:
    old "Ohh! Oh my god!"
    new "哦！天啊！"

translate chinese chinese_5578814_69:
    old "Ah, it feels so good!"
    new "啊，感觉真好！"

translate chinese chinese_2231241_70:
    old "Ahhh! I- I'm close! I can feel it!"
    new "啊hhh！我—我要来了！我能感觉到！"

translate chinese chinese_9166397_71:
    old "Uhhhhh!"
    new "呃呃呃！"

translate chinese chinese_1768856_72:
    old "M- Ma'am! I think I'm cumming!"
    new "妈的！我觉得我要射了！"

translate chinese chinese_7032383_73:
    old "Ah! Do it! I want you to! Cum!"
    new "啊！来吧！我就想要你这样！射吧！"

translate chinese chinese_9862622_74:
    old "My god! That was impressive, you came so much."
    new "天啊！那真是太棒了，你表现得这么出色。"

translate chinese chinese_4004914_75:
    old "Phew, glad I can help."
    new "呼，能帮上忙真好。"

translate chinese chinese_2679358_76:
    old "But you know, I shouldn't keep you for myself..."
    new "但是你知道，我不应该把你占为己有……"

translate chinese chinese_8375569_77:
    old "It's your turn Daniela..."
    new "该你了，Daniela..."

translate chinese chinese_3563780_78:
    old "I hope you're not tired from being with mother, because I've been waiting for this."
    new "希望你和妈妈在一起没累坏，因为我一直在等这一刻。"

translate chinese chinese_3757330_79:
    old "Daniela darling, I know our health is a little compromised."
    new "丹妮拉宝贝，我知道我们的健康状况有点堪忧。"

translate chinese chinese_7878833_80:
    old "But there's no need to pressure him that much."
    new "但是没必要给他那么大的压力。"

translate chinese chinese_3184267_81:
    old "Haha, I don't think she meant it that way mother."
    new "哈哈，妈妈，我想她不是那个意思。"

translate chinese chinese_5618496_82:
    old "Ok, here we go."
    new "好了，开始吧。"

translate chinese chinese_7807714_83:
    old "Mmm! This cock, it's reaching all the way!"
    new "嗯！这根棒子，简直深入到底了！"

translate chinese chinese_0657074_84:
    old "Uhh, it looks amazing!"
    new "呃，看起来好棒！"

translate chinese chinese_1812486_85:
    old "And it is! Mmm! So good."
    new "就是这个！嗯！真棒。"

translate chinese chinese_3545495_86:
    old "I can see that you're enjoying this [pla]."
    new "我能看出来你很享受这个[pla]。"

translate chinese chinese_5963638_87:
    old "Mmm... Y- yes ma'am"
    new "嗯……是的，小姐"

translate chinese chinese_3320663_88:
    old "Heh, Daniela is enjoying it too mother."
    new "嘿嘿，丹妮拉也在享受呢，妈妈。"

translate chinese chinese_0259388_89:
    old "I- It's so thick, and I feel so warm inside."
    new "它好粗，我里面感觉好热。"

translate chinese chinese_7135383_90:
    old "What about if you go a little faster [pla]?."
    new "如果你再快一点呢，[pla]？"

translate chinese chinese_8257865_91:
    old "Oh, Oh god!"
    new "哦，天啊！"

translate chinese chinese_0241733_92:
    old "Yes! Yes! Like that! Pound me more!"
    new "是的！对！就是这样！再用力点！"

translate chinese chinese_1150425_93:
    old "Mmm, Ahhh!"
    new "嗯，啊hh!"

translate chinese chinese_8987253_94:
    old "I can feel it! Your body it's tensing up!"
    new "我感觉到了！你的身体在紧张！"

translate chinese chinese_7962899_95:
    old "Yes! Cum! Cum inside me!"
    new "yes! 来吧！在里面射吧！"

translate chinese chinese_1415607_96:
    old "Wow, that was amazing."
    new "哇，真棒。"

translate chinese chinese_9005162_97:
    old "Look how much you came. I can't believe it."
    new "看你来了这么多，真不敢相信。"

translate chinese chinese_6062191_98:
    old "You never cease to surprise me [pla]."
    new "你真是让我惊喜不断，[pla]。"

translate chinese chinese_5146205_99:
    old "I think it's my turn now mother."
    new "妈妈，现在轮到我了。"

translate chinese chinese_6949282_100:
    old "Be gentle with me, ok?"
    new "温柔点，好吗？"

translate chinese chinese_5299659_101:
    old "I don't like it as rough as my sister."
    new "我可不喜欢像我姐姐那样粗鲁。"

translate chinese chinese_0316783_102:
    old "That's it, slowly. Mmm."
    new "就是这样，慢慢来。嗯。"

translate chinese chinese_8252768_103:
    old "Ah! I can feel how you stretch me."
    new "啊！我能感觉到你在拉伸我。"

translate chinese chinese_2280054_104:
    old "Yes sister, I felt it too. It's unbelievable."
    new "没错，我也感觉到了。真是难以置信。"

translate chinese chinese_4711411_105:
    old "Y- You can do it, a little harder"
    new "你行的，再用力一点"

translate chinese chinese_8823544_106:
    old "You like that big cock sis?"
    new "你喜欢那种大鸡巴姐姐？"

translate chinese chinese_0101176_107:
    old "Ohh, yes, yes, just like that."
    new "哦，对，就是这样。"

translate chinese chinese_1129530_108:
    old "That's it Bela, enjoy it darling."
    new "就是这样贝尔拉，尽情享受吧，亲爱的。"

translate chinese chinese_1728223_109:
    old "P- please, go a little faster."
    new "求你了，动作快一点。"

translate chinese chinese_5269575_110:
    old "Ah, Ahh, Ahhh!"
    new "啊，啊啊，啊啊啊！"

translate chinese chinese_5859033_111:
    old "I- It's soooo fucking big!"
    new "它大到变态！"

translate chinese chinese_2475066_112:
    old "It's warming me up inside!"
    new "这让我心里暖洋洋的！"

translate chinese chinese_2258353_113:
    old "Yes! Me too!"
    new "是的！我也是！"

translate chinese chinese_1541492_114:
    old "Ughhh!"
    new "哎呀！"

translate chinese chinese_2541086_115:
    old "Amazing, you have such amazing endurance."
    new "真厉害，你的耐力真好。"

translate chinese chinese_0921259_116:
    old "And he still hard... "
    new "而且他还硬着..."

translate chinese chinese_7736528_117:
    old "Hmm, do you think you could give us a little bit more?"
    new "嗯，你觉得能再多给一点吗？"

translate chinese chinese_1720205_118:
    old "Uhhh.... I- I think so."
    new "呃……我— 我觉得是的。"

translate chinese chinese_5277356_119:
    old "Mmmm, that was lovely [pla]."
    new "嗯，那真是很棒的[pla]。"

translate chinese chinese_2506294_120:
    old "T- Thanks ma'am."
    new "谢、谢谢您。"

translate chinese chinese_5664443_121:
    old "You managed to do it with all three of us."
    new "你竟然和我们三个都做到了。"

translate chinese chinese_8291735_122:
    old "I think we can give you a little extra."
    new "我觉得我们可以多给你一点。"

translate chinese chinese_4261266_123:
    old "God! your cock still so hard."
    new "天啊！你的家伙还这么硬。"

translate chinese chinese_6390758_124:
    old "I can see you still have some left in the tank. Give it to us."
    new "我还看得出你还有余力，给我看看。"

translate chinese chinese_2583339_125:
    old "Ah... Ahh!"
    new "啊... 啊！"

translate chinese chinese_0750339_126:
    old "I love how big you are."
    new "我喜欢你这么丰满。"

translate chinese chinese_3005947_127:
    old "It's got such a nice smell."
    new "味道真好。"

translate chinese chinese_7144681_128:
    old "Let's do it a faster mother."
    new "咱们快点来吧，妈的。"

translate chinese chinese_2091340_129:
    old "Yes! That's it! I love seeing you enjoy it."
    new "对！就是那样！我喜欢看你享受的样子。"

translate chinese chinese_9648457_130:
    old "It's so warm, and it's getting harder."
    new "好温暖，而且越来越硬了。"

translate chinese chinese_5870019_131:
    old "I think he's about to cum."
    new "我觉得他要射了。"

translate chinese chinese_1105657_132:
    old "I- I think I'm cumming!"
    new "我——我要来了！"

translate chinese chinese_0437686_133:
    old "Yes! Let it all out! Cum all over us!"
    new "没错！全部射出来吧！全都射在我们身上！"

translate chinese chinese_0742669_134:
    old "Wow, that was really intense."
    new "哇，那真是非常激烈。"

translate chinese chinese_4081027_135:
    old "Yes, it was. I think I'm finally feeling a little tired."
    new "是的，我觉得我终于有点累了。"

translate chinese chinese_4005079_136:
    old "Hah! Just now? I did it only once with you, and I'm already tired!"
    new "哈！刚才吗？我只和你做了一次就累了！"

translate chinese chinese_9564691_137:
    old "Wow [pla], just wow! You really had sex with all three of us and are ok."
    new "哇 [pla]，真是的！你真的和我们三个都上过床还觉得无所谓。"

translate chinese chinese_8335798_138:
    old "Well, I wouldn't say I don't feel it. But I wanted to help."
    new "好吧，我不会说我没有感觉。但我想要帮忙。"

translate chinese chinese_7818695_139:
    old "And you did. Right girls?"
    new "你做到了。对吧，姑娘们？"

translate chinese chinese_4158282_140:
    old "Yes, you really are a lifesaver."
    new "是的，你真是个救星。"

translate chinese chinese_4256031_141:
    old "That's right, this is great for us."
    new "没错，这对我们很有利。"

translate chinese chinese_7522800_142:
    old "Thank you very much."
    new "非常感谢。"

translate chinese chinese_3117564_143:
    old "Well, why don't we get dressed? I think you probably need to rest at home [pla]."
    new "那我们穿衣服吧？我觉得你probably需要在家休息一下[pla]。"

translate chinese chinese_2216538_144:
    old "How are you feeling girls?"
    new "你们感觉怎么样？"

translate chinese chinese_9753267_145:
    old "I feel amazing, that was so good, and I feel myself getting better already!"
    new "感觉太棒了，真是太好了，我已经觉得自己变好了！"

translate chinese chinese_2307947_146:
    old "Yeah, me too. The amount of cum we were able to take is amazing."
    new "是啊，我也是。我们能承受的精液量真是惊人。"

translate chinese chinese_2541306_147:
    old "I'm happy I can be of help to you all."
    new "我很高兴能帮到大家。"

translate chinese chinese_1546518_148:
    old "I think I should probably go home and rest."
    new "我觉得我还是回家休息一下吧。"

translate chinese chinese_7799466_149:
    old "That's fine. But before you leave, allow us to thank you once again for everything you've done for us."
    new "那好吧。但在你离开前，允许我们再次感谢你为我们所做的一切。"

translate chinese chinese_2405051_150:
    old "T- that's right [pla] thank you very much."
    new "嗯……没错 [pla]，非常感谢。"

translate chinese chinese_6116765_151:
    old "Thank you [pla], please come soon again."
    new "谢谢[pla]，请尽快再来。"

translate chinese chinese_6650383_152:
    old "Sure, you can count on me."
    new "行，你放心吧。"

translate chinese chinese_8074494_153:
    old "Aww, you're an angel. Thank you so much."
    new "哎呀，你真是个天使。太感谢了。"

# auto-tl Qwen Colab

translate chinese chinese_0671022_0:
    old "What a nice cock do you have..."
    new "你这鸡巴真不错……"

translate chinese chinese_5961470_1:
    old "Do you like it, Uh? Do you want it faster baby?"
    new "你喜欢这样吗，嗯？想要更快一点吗，宝贝？"

translate chinese chinese_4127660_2:
    old "Oh yeah baby, I wanna see that huge cock cumming..."
    new "哦 yeah 宝贝，我想看看那巨大的 cocks 射出来..."

translate chinese chinese_5677741_3:
    old "Mrs Anastasia... I- going to-"
    new "安纳斯塔西娅夫人……我——要去——"

translate chinese chinese_6969167_4:
    old "Oh yes, cum for mommy, give it to me..."
    new "哦 yeah，为妈妈射吧，给我..."

translate chinese chinese_6088167_5:
    old "Wow that was a lot of cum..."
    new "哇，真够多的……"

translate chinese chinese_2995071_6:
    old "Mmm, I love your huge cock!"
    new "嗯，我爱你那巨大的棒！"

translate chinese chinese_8165615_7:
    old "Do you like my mounth, baby?"
    new "你喜欢我的嘴巴吗，宝贝？"

translate chinese chinese_2308157_8:
    old "Come on fuck my throat with your big cock!"
    new "来啊，用你那大鸡巴狠狠插我的喉咙！"

translate chinese chinese_9084415_9:
    old "Anastasia I'm going to..."
    new "阿纳斯塔西娅，我要去..."

translate chinese chinese_7949504_10:
    old "Ohh yeah, cum all over my face!"
    new "哦耶，射我脸上！"

translate chinese chinese_4950058_11:
    old "Uhhh warm and sweet..."
    new "嗯，温暖又甜蜜……"

translate chinese chinese_9471623_12:
    old "Ahhh, yeah baby fuck me, FUCK ME!"
    new "啊哈哈，对了宝贝，给我再来点，干我啊，干我啊！"

translate chinese chinese_8640527_13:
    old "Oh god, Oh god, It feels great!"
    new "哦天啊，感觉真好！"

translate chinese chinese_4196774_14:
    old "H- Harder... Fuck me harder!"
    new "再用力点……操得我再狠一点！"

translate chinese chinese_2776190_15:
    old "Ahhh I'm cumming!"
    new "啊hh我来了！"

translate chinese chinese_6172052_16:
    old "I- I'm cumming too..."
    new "我我也要来了..."

translate chinese chinese_1672809_17:
    old "Oh my God! This is amazing! Fuck me, Fuck me!"
    new "天啊！这也太棒了！操我，操我！"

translate chinese chinese_9100721_18:
    old "AHHHH AHHHH, YEAH YEAH, HARDER BABY, HARDEER!"
    new "啊啊啊 啊啊，对对，再用力点宝贝，更用力！"

translate chinese chinese_7446533_19:
    old "OH MY GOD I LOVE YOUR COCK! GIMME MOREE!"
    new "天啊，我爱你的棒！再多来点！"

translate chinese chinese_4760183_20:
    old "Oh my god! I loved it..."
    new "天啊！我超爱的..."

translate chinese chinese_1781195_21:
    old "I- I like it... too."
    new "我……我也喜欢。"

translate chinese chinese_5387812_22:
    old "Oh my god! You are amazing, I loved it..."
    new "天啊！你太棒了，我爱死了..."

translate chinese chinese_4202859_23:
    old "I loved it..."
    new "我爱死了..."

translate chinese chinese_1275948_24:
    old "Ohhh, your cock feels so nice!"
    new "哦哦，你的棒棒感觉真好！"

translate chinese chinese_2991570_25:
    old "YEAH, BABY, FASTER, FASTER!"
    new "对，宝贝，快点，再快点！"

translate chinese chinese_6340084_26:
    old "OH MY FUCKING GOD! HARDER, FUCK ME HARDER!"
    new "噢我的上帝！再用力点，操得我再用力点！"

translate chinese chinese_1168231_27:
    old "Alright, take a few moments to settle into your position."
    new "好吧，花几分钟时间调整好姿势。"

translate chinese chinese_3204687_28:
    old "Bring your attention to your breath."
    new "把注意力集中在你的呼吸上。"

translate chinese chinese_6549444_29:
    old "Focus on the air coming in and out."
    new "专注于呼吸的进出。"

translate chinese chinese_6782183_30:
    old "Notice the cool air entering your nostrils and the warm air leaving them."
    new "注意凉爽的空气进入鼻孔，温暖的空气又呼出去。"

translate chinese chinese_4318960_31:
    old "Without trying to change your breath, simply observe it."
    new "不用试图改变你的呼吸，只需观察它。"

translate chinese chinese_0005052_32:
    old "Let your body and mind relax."
    new "让你的身体和心灵放松一下。"

translate chinese chinese_1159526_33:
    old "If your mind begins to wander, that's okay."
    new "如果你开始走神，也没关系。"

translate chinese chinese_5701046_34:
    old "Let your body feel everything it needs to feel."
    new "让你的身体感受它需要的一切。"

translate chinese chinese_3234663_35:
    old "The sensation of my and [pla]'s hands going over your body."
    new "我和[pla]的手在你身上抚摸的感觉。"

translate chinese chinese_8261462_36:
    old "Gently guide your focus back to the sensation of breathing."
    new "轻轻地把注意力重新引导到呼吸的感觉上。"

translate chinese chinese_5710210_37:
    old "Allow yourself to be fully present with each breath."
    new "让自己随着每一次呼吸都全然地存在。"

translate chinese chinese_4484938_38:
    old "Finding calm and clarity in this simple act."
    new "在这个简单的动作中找到平静和清晰。"

translate chinese chinese_7747596_39:
    old "Mmm, this feels great, guys."
    new "嗯，这感觉真好， guys."

translate chinese chinese_7833848_40:
    old "M-My body's feeling amazing!"
    new "我身体感觉棒极了！"

translate chinese chinese_1286693_41:
    old "That's good, that's your body reacting to the energy flowing within you."
    new "好的，那是你的身体在对流经体内的能量作出反应。"

translate chinese chinese_7081639_42:
    old "As your chakras are being cleansed."
    new "随着你的脉轮被净化。"

translate chinese chinese_1737962_43:
    old "[pla], place yourself between her legs, and help her energy flow through a massage."
    new "[pla]，站在她双腿之间，通过按摩帮助她的能量流动。"

translate chinese chinese_2437972_44:
    old "I... Oh my god!"
    new "我... 哦我的天！"

translate chinese chinese_4167418_45:
    old "This feels incredible!"
    new "这感觉太棒了！"

translate chinese chinese_5851857_46:
    old "I feel like I'm having an orgasm, Lisa!"
    new "我觉得我要高潮了，丽莎！"

translate chinese chinese_2124709_47:
    old "Good! Enjoy that feeling!"
    new "好！享受这种感觉吧！"

translate chinese chinese_8393548_48:
    old "Let yourself fall deeply into it!"
    new "让自己深深地陷入其中吧！"

translate chinese chinese_1083822_49:
    old "Oh gosh! I can't believe it!"
    new "天啊！我不敢相信！"

translate chinese chinese_1505976_50:
    old "I actually had an orgasm that way."
    new "我那次真的高潮了。"

translate chinese chinese_9902742_51:
    old "Of course, your body reacted positively to your Mudhalara chakra coming into balance."
    new "当然，你的身体对平衡了的Mudhalara脉轮作出了积极反应。"

translate chinese chinese_1473349_52:
    old "That is the beauty of a tantric process."
    new "这就是 tantra 过程的美妙之处。"

translate chinese chinese_3720864_53:
    old "I have to say it was amazing!"
    new "我得说真是太棒了！"

translate chinese chinese_2591728_54:
    old "Haha, I'm glad you liked it."
    new "哈哈，高兴你喜欢。"

translate chinese chinese_5861228_55:
    old "I'll let you get up now."
    new "我现在让你起来。"

translate chinese chinese_2517747_56:
    old "Uhh, that was so good!"
    new "呃，那真是太好了！"

translate chinese chinese_4753891_57:
    old "I loved it!"
    new "我超爱的！"

translate chinese chinese_8025386_58:
    old "I see that your connection with yourself and the balance of your chakras is improving."
    new "我看到你与自己的连接以及你的脉轮平衡都在改善。"

translate chinese chinese_0910345_59:
    old "I think that with this we can move on to the next exercise."
    new "我觉得这样我们可以进行下一个练习了。"

translate chinese chinese_6634525_60:
    old "Great!"
    new "太好了！"

translate chinese chinese_0940406_61:
    old "Remember to focus on your breathing, Anastasia."
    new "记得专注于你的呼吸，阿纳斯塔西娅。"

translate chinese chinese_8177991_62:
    old "Feel the air going in and out of your body."
    new "感受空气进出你的身体。"

translate chinese chinese_1617423_63:
    old "Let go of any thoughts or worries, allowing them to drift away with your breath."
    new "放开所有的思绪和烦恼，让它们随着你的呼吸飘散。"

translate chinese chinese_3596708_64:
    old "Continue to focus on this flow of energy, allowing it to move freely and naturally."
    new "继续专注于这股能量流动，让它自由自在地移动。"

translate chinese chinese_9720235_65:
    old "With each breath, feel more relaxed and centered."
    new "随着每一次呼吸，感觉更加放松和集中。"

translate chinese chinese_5393162_66:
    old "Just breathe and let your energy flow in and out."
    new "just breathe and let your energy flow in and out.\n\n({i}深呼吸，让能量自然流动。{/i}) \n\n由于您要求保留Ren'Py标记且不进行解释，我直接翻译了文本内容并保留了{i}{/i}标记。不过，原句\"just breathe and let your energy flow in and out.\"似乎与上下文不符，可能是输入错误或特殊情境下的表达。如果需要更准确的翻译，请提供更多的上下文信息。"

translate chinese chinese_1761754_67:
    old "Mmm! This feels amazing, Lisa."
    new "嗯！感觉太棒了，丽莎。"

translate chinese chinese_5667859_68:
    old "Yes! Focus on that sensation!"
    new "对！专注于那种感觉！"

translate chinese chinese_3780161_69:
    old "Let your body guide you in what you need!"
    new "让身体告诉你它需要什么！"

translate chinese chinese_7037233_70:
    old "I'm about to... Cum Lisa!"
    new "我要... 来了，丽莎！"

translate chinese chinese_8121396_71:
    old "Yes! Yes! Let it all out!"
    new "是的！是的！尽情释放吧！"

translate chinese chinese_9224193_72:
    old "Let everything flow out of you!"
    new "让一切从你内心流出吧！"

translate chinese chinese_3936624_73:
    old "Oh that was so amazing!"
    new "哦，那真是太棒了！"

translate chinese chinese_9593014_74:
    old "It felt so good!"
    new "感觉真爽！"

translate chinese chinese_8323462_75:
    old "I'm glad you enjoyed it, that's your Mudhalara chakra coming into balance."
    new "很高兴你喜欢，那是你的穆达拉拉脉轮正在趋于平衡。"

translate chinese chinese_4636678_76:
    old "I belive we're on the right path."
    new "我相信我们走在正确的道路上。"

translate chinese chinese_9866658_77:
    old "But now, let's get up, so that [pla] can also rest a little."
    new "但是现在，让我们起来吧，这样[pla]也能稍微休息一下。"

translate chinese chinese_7349162_78:
    old "Relax, feel the depth of your energy."
    new "放松，感受你的能量深度。"

translate chinese chinese_4862333_79:
    old "Feel how far it goes inside you."
    new "感受它深入你体内的程度。"

translate chinese chinese_2779839_80:
    old "And the connection [pla]'s helping you achieve."
    new "以及[pla]帮你达成的连接。"

translate chinese chinese_1692351_81:
    old "Do you feel it, Anastasia?"
    new "你感觉到了吗，阿纳斯塔西娅？"

translate chinese chinese_2680547_82:
    old "How deep inside you your energy goes?"
    new "你的能量能深入到你身体的多深处？"

translate chinese chinese_5294763_83:
    old "Do you feel it flowing?"
    new "你能感觉到它的流动吗？"

translate chinese chinese_4378483_84:
    old "Y-Yes I do."
    new "是的，我有。"

translate chinese chinese_3832753_85:
    old "I can feel it very deep inside me!"
    new "我内心深处能感受到！"

translate chinese chinese_5374382_86:
    old "Do you feel your energy flowing inside, Anastasia?"
    new "你感觉到体内的能量流动了吗，阿纳斯塔西娅？"

translate chinese chinese_0156869_87:
    old "Oh yes! It's going so far inside me!"
    new "哦，是的！它深入进来了！"

translate chinese chinese_7658644_88:
    old "I love how it feels!"
    new "我爱这种感觉！"

translate chinese chinese_0098964_89:
    old "Lisa! [pla]! I can't hold it in anymore!"
    new "丽莎！[pla]！我忍不住了！"

translate chinese chinese_2526151_90:
    old "Don't! Let yourself go!"
    new "别克制了！放纵一下自己！"

translate chinese chinese_3479263_91:
    old "Let it all out!"
    new "尽情释放吧！"

translate chinese chinese_5820137_92:
    old "How do you feel, Anastasia?"
    new "你觉得怎么样，阿纳斯塔西娅？"

translate chinese chinese_7237275_93:
    old "I feel amazing!"
    new "我感觉太棒了！"

translate chinese chinese_8422232_94:
    old "Were you able to make an internal connection?"
    new "你内部有没有联系上？"

translate chinese chinese_7704022_95:
    old "I can feel it all inside me."
    new "我都能感受到内心的这一切。"

translate chinese chinese_2875101_96:
    old "Wonderful! That was the objective of this!"
    new "太好了！这就是目标！"

translate chinese chinese_1359940_97:
    old "Now, time to get up and get cleaned up."
    new "现在，起来洗漱一下。"

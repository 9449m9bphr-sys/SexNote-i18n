# auto-tl Qwen Colab

translate chinese chinese_2588913_0:
    old "Perfect, you are doing it so good, don't stop..."
    new "完美，你做得很好，不要停..."

translate chinese chinese_3162402_1:
    old "Please keep in mind the places where it's better to touch, where you can make your patient feel even more..."
    new "请记住那些更适合触碰的地方，让你的患者感觉更加..."

translate chinese chinese_0536767_2:
    old "You are doing perfect, don't stop, it feels so good."
    new "你做得很好，别停，感觉真好。"

translate chinese chinese_2804610_3:
    old "Slurp... Slurp..."
    new "吸... 吸..."

translate chinese chinese_9313484_4:
    old "Ahh, I want you to do it faster!... Go as fast as you c- can."
    new "啊，我要你快点做！……尽可能快地做。"

translate chinese chinese_4618319_5:
    old "Yeah, Yeah, YEAH! keep moving... I- I am cuming! AHH!"
    new "yeah, yeah, YEAH! 继续……我——我要来了！啊！"

translate chinese chinese_4684058_6:
    old "Please, just let me to enjoy your dick..."
    new "求你了，就让我享受一下你的棒..."

translate chinese chinese_4641326_7:
    old "It's so hard... I just wanted to have it since I saw you fucking Angelina."
    new "好难啊……我看到你和Angelina那个之后就一直想要了。"

translate chinese chinese_2533752_8:
    old "I want you to feel the tip of my tongue playing with the head of your dick..."
    new "我想让你感觉到我舌尖玩弄着你的丁丁头..."

translate chinese chinese_7398561_9:
    old "(Oh God...)"
    new "（天啊……）"

translate chinese chinese_7687990_10:
    old "I'm really really wet right now... Do you like my mouth?"
    new "我现在真的很湿……你喜欢我的嘴吗？"

translate chinese chinese_0307570_11:
    old "Oh God, yes, it feels really good..."
    new "哦上帝，是的，感觉真好……"

translate chinese chinese_3760982_12:
    old "I need you to feel my mouth, to internalize the pleasure you are feeling, it's something you should handle. "
    new "我需要你感受我的嘴唇，将你感受到的愉悦内化，这是你应该处理的事情。"

translate chinese chinese_8122383_13:
    old "Who do you prefer to suck your cock?  Me... Slurp... Or... Slurp... Angelina?"
    new "你更喜欢谁来吸你的棒？我……咕嘟……还是……咕嘟……安吉丽娜？"

translate chinese chinese_0894316_14:
    old "Are you really considering it?"
    new "你真的在考虑吗？"

translate chinese chinese_9992163_15:
    old "Can you feel my tongue? Do you feel how wet it is now, feel the tip playing with your dick's head..."
    new "能感觉到我的舌头吗？感觉到它现在有多湿，舌尖玩弄着你的丁丁头..."

translate chinese chinese_3699006_16:
    old "Yes, I- I can."
    new "是的，我——我能。"

translate chinese chinese_4320163_17:
    old "I'm gonna show you WHO is the MASTER..."
    new "我要让你知道谁才是主人..."

translate chinese chinese_0601870_18:
    old "I'm going to do it with all I have, so be ready."
    new "我打算全力以赴，所以你准备好吧。"

translate chinese chinese_2132851_19:
    old "This is how a master do it..."
    new "这就是大师的水准..."

translate chinese chinese_4141612_20:
    old "Uhhh..."
    new "呃……"

translate chinese chinese_7762331_21:
    old "Stay focused, you can't cum."
    new "集中点，你不能射。"

translate chinese chinese_0270121_22:
    old "I won't."
    new "我不会的。"

translate chinese chinese_3570029_23:
    old "I hope so!"
    new "但愿如此！"

translate chinese chinese_9759268_24:
    old "So? What do you think now? Who is better?"
    new "所以呢？你现在怎么想？谁更好？"

translate chinese chinese_3213815_25:
    old "Ahh... Y- you... You are better..."
    new "啊……你……你真是……厉害……"

translate chinese chinese_9386873_26:
    old "That's what I wanted to ear..."
    new "那正是我想听到的..."

translate chinese chinese_0990164_27:
    old "I will speed up a bit, I know you will enjoy it."
    new "我会加快一点速度，我知道你会喜欢的。"

translate chinese chinese_4938135_28:
    old "I'm going to make you cum NOW!"
    new "我现在就要让你射了！"

translate chinese chinese_9414178_29:
    old "You are doing it better than I expected... But you can't against my full speed."
    new "你做得比我预期的要好……但是你挡不住我的全力速度。"

translate chinese chinese_5684537_30:
    old "AHH!"
    new "啊！"

translate chinese chinese_4172817_31:
    old "I- I think I'm going to-"
    new "我— 我觉得我要—"

translate chinese chinese_2194123_32:
    old "Oh, please let it go, spill it over my mouth..."
    new "哦，请让它溢出来，溅到我的嘴里..."

translate chinese chinese_9628904_33:
    old "A- are you sure?"
    new "你——你确定吗？"

translate chinese chinese_9174967_34:
    old "Yess, I want to feel all you cum in my mouth, give it all to me!"
    new "嗯，我想感受你全部的射精在我的嘴里，全都给我！"

translate chinese chinese_5500441_35:
    old "Definetly, I need to ride this cock, I want it all inside me, lie on the bed I need you to fuck me!"
    new "绝对了，我需要骑上这根棒，我想让它全部进入我体内，躺在床上，我要你狠狠地干我！"

translate chinese chinese_2192692_36:
    old "I don't want any kids game, fuck me really HARD!"
    new "我不要什么小孩的游戏，给我狠狠地来真的！"

translate chinese chinese_9998291_37:
    old "A- alright."
    new "好，好吧。"

translate chinese chinese_8341866_38:
    old "Listen carefully, I want you to keep a regular rythm, and also an uniform strength..."
    new "听好了，我要你保持稳定的节奏，还要力度均匀……"

translate chinese chinese_3434718_39:
    old "You need to plan your movements, your energy, I will tell when you can do it faster."
    new "你需要规划好你的动作和精力，我会告诉你什么时候可以更快地完成。"

translate chinese chinese_1574929_40:
    old "Ahh... I like it, keep it like that..."
    new "啊……我喜欢这样，继续保持……"

translate chinese chinese_4000034_41:
    old "Oh, now faster, I'm very wet, do it harder."
    new "哦，现在快点，我湿得很，再用力一点。"

translate chinese chinese_9339629_42:
    old "O- ok."
    new "好。"

translate chinese chinese_7880746_43:
    old "POUND ME HARDER!"
    new "再用力一点！"

translate chinese chinese_0977076_44:
    old "Huh..."
    new "huh..."

translate chinese chinese_0955274_45:
    old "Ahh, do it as hard as you have to, I want you to smash my pussy"
    new "啊，用力点，我要你把我弄湿透"

translate chinese chinese_3282731_46:
    old "Oh yeah, don't stop, don't stop!"
    new "哦 yeah，别停，别停！"

translate chinese chinese_2941222_47:
    old "Show me how powerful your dick is, I want you to make cum!"
    new "展示给我看看你有多强，我要你射出来！"

translate chinese chinese_8182327_48:
    old "Ughh... "
    new "呃……"

translate chinese chinese_9891780_49:
    old "Oh God! I'm cumming!! Ahhh! Ahhhh!"
    new "哦天啊！我要射了！！啊hh！啊hhhh！"

translate chinese chinese_6720502_50:
    old "Yes, just like this baby..."
    new "是的，就象这个宝宝一样..."

translate chinese chinese_1205662_51:
    old "Gulp..."
    new "咽了口唾沫..."

translate chinese chinese_9596212_52:
    old "Ahh! Your dick is so good..."
    new "啊！你的棒棒真好……"

translate chinese chinese_1060356_53:
    old "Ah!"
    new "啊！"

translate chinese chinese_0103079_54:
    old "SO GOOD!!!"
    new "太棒了！！！"

translate chinese chinese_1427195_55:
    old "Ohh yeahh, it's so big!"
    new "哦耶，好大啊！"

translate chinese chinese_7364172_56:
    old "AH!"
    new "啊！"

translate chinese chinese_3946114_57:
    old "HARDER, HARDER!"
    new "更用力，更用力！"

translate chinese chinese_6409055_58:
    old "I'm gonna cum!!!"
    new "我要射了！！！"

translate chinese chinese_3601690_59:
    old "Let's cum together, DON'T STOP, DON'T STOP... AHHH!"
    new "我们一起高潮吧，不要停，不要停……啊啊啊！"

translate chinese chinese_6262271_60:
    old "Mmmm!! I- I'm coming..."
    new "嗯！！我快来了..."

translate chinese chinese_4012019_61:
    old "Wow..."
    new "wow..."

translate chinese chinese_4721158_62:
    old "Oh yeah, I'm going to show you how an expert fucks!"
    new "哦 yeah，我要让你看看专家怎么干！"

translate chinese chinese_5694064_63:
    old "Ughh, It feels amazing..."
    new "哦，感觉真爽……"

translate chinese chinese_5074109_64:
    old "Mmmm... Riding you drives me crazy!"
    new "嗯……骑你让我疯狂！"

translate chinese chinese_4330706_65:
    old "Oh yess... Please don't stop it... Ahh!"
    new "哦 yeah... 求你不要停下来... 噢！"

translate chinese chinese_2455635_66:
    old "Yeah, you like it? Then I'm gonna fuck you harder!"
    new "嗯，你喜欢这样？那我就更用力了！"

translate chinese chinese_2082111_67:
    old "Uhhh... You have really huge cock! I can't fit it all in my pussy."
    new "呃……你的鸡巴真的好大！我装不下这么多。"

translate chinese chinese_3803534_68:
    old "Fuck me! Fuck me! I want you to fill my cunt of cum."
    new "操我！操我！我要你让我高潮。"

translate chinese chinese_1503582_69:
    old "Yeeeeesss... Yesss... I- I'm cumming!!"
    new "耶耶耶斯... 是的... 我—我要来了!!"

translate chinese chinese_0653338_70:
    old "Ahhhhh... Ughhh..."
    new "啊啊啊……呕……"

translate chinese chinese_5249975_71:
    old "Ohh, yes, I feel it inside, that's delicious."
    new "哦，是的，我感觉到了，真美味。"

translate chinese chinese_9835106_72:
    old "Don't even think about stopping... I need more of your cock NOW!"
    new "别想停下来……我现在就需要你更多的硬棒！"

translate chinese chinese_7475405_73:
    old "Now softly... I wanna feel all your big cook..."
    new "现在轻轻地……我想感受你全部的大厨艺……"

translate chinese chinese_4382244_74:
    old "Ohh yeahh... Just like that baby..."
    new "哦哦 yeah... 就这样宝宝..."

translate chinese chinese_8973501_75:
    old "Do you like my big boobs? How do they bounce when you fuck me?"
    new "你喜欢我的大胸吗？当我们做爱时它们是怎么弹跳的？"

translate chinese chinese_1785492_76:
    old "Yes, I love your tits!"
    new "是的，我超爱你的胸部！"

translate chinese chinese_2421134_77:
    old "Then, fuck me faster, with that huge cock!"
    new "那就操我快点，用那巨大的 cocks!"

translate chinese chinese_3276206_78:
    old "Harder! Fuck me harder! I want you to make me cum as you did with Angelina!"
    new "再用力点！狠狠地操我！我要你让我像操Angelina那样高潮！"

translate chinese chinese_0023800_79:
    old "OH GOD... I'M GONNA FUCK YOU EVERYDAY..."
    new "哦天哪……我每天都要跟你做爱……"

translate chinese chinese_7541873_80:
    old "I- I going to..."
    new "我……我要去……"

translate chinese chinese_6542574_81:
    old "Yes! Cum inside me!"
    new "yes! 在我里面射!"

# auto-tl Qwen Colab

translate chinese chinese_1024946_0:
    old "I must say... Mmmm, the size of your dick never stops being surprising."
    new "我必须说……嗯，你的尺寸真是从不会让人失望。"

translate chinese chinese_6740579_1:
    old "It’s impressive."
    new "真厉害。"

translate chinese chinese_3695813_2:
    old "And this scent... I had never perceived it."
    new "还有这个味道……我从未察觉过。"

translate chinese chinese_3710750_3:
    old "It’s... nice."
    new "挺不错的。"

translate chinese chinese_9593635_4:
    old "Are you enjoying this?"
    new "你在享受这个吗？"

translate chinese chinese_6204321_5:
    old "I ask because it’s important for you to cum."
    new "我问是因为对你来说高潮很重要。"

translate chinese chinese_2804605_6:
    old "It feels good."
    new "感觉真好。"

translate chinese chinese_5567291_7:
    old "Mmmmm!"
    new "嗯嗯嗯！"

translate chinese chinese_9026430_8:
    old "This sensation! I’d never felt it before!"
    new "这种感觉！我从没感受过！"

translate chinese chinese_6696746_9:
    old "Ughh... It hurts, but it feels so good!"
    new "呃……好痛，但感觉好爽！"

translate chinese chinese_4455764_10:
    old "I- I’m enjoying it!"
    new "我…我在享受呢！"

translate chinese chinese_6003766_11:
    old "I don’t think I will last longer!"
    new "我觉得我坚持不了多久了！"

translate chinese chinese_4429232_12:
    old "It’s ok, cum for me!"
    new "没事，射我身上吧！"

translate chinese chinese_0410400_13:
    old "Slurrp!!"
    new "咕噜一声！！"

translate chinese chinese_3546350_14:
    old "Cum! Give me the magic!"
    new "射吧！给我那种魔力！"

translate chinese chinese_0139715_15:
    old "That... that was unexpected."
    new "那……那真是没想到。"

translate chinese chinese_0591671_16:
    old "Are you ok?"
    new "你还好吗？"

translate chinese chinese_4176543_17:
    old "I’m fine."
    new "我没事。"

translate chinese chinese_2749022_18:
    old "It’s just that I wasn’t expecting that."
    new "只是我没想到会这样。"

translate chinese chinese_0036004_19:
    old "The act feels so different with a human body."
    new "用人类的身体做爱感觉完全不同。"

translate chinese chinese_8489950_20:
    old "And to be able to feel all that. Linett’s spell is very complete!"
    new "能感受到这一切，林奈特的咒语真是太完美了！"

translate chinese chinese_3791151_21:
    old "Ah... sure. Hey listen, I think we need to get going before we’re discovered here."
    new "啊……好吧。听着，我觉得我们在被发现之前最好赶紧离开这里。"

translate chinese chinese_2832438_22:
    old "I’ll clean Mrs. Jade, and then we take off. Ok?"
    new "我先收拾一下玉太太的房间，然后我们就走。好吗？"

translate chinese chinese_0123177_23:
    old "(Mmm, it feels so nice...)"
    new "（嗯，感觉真好……）"

translate chinese chinese_4854993_24:
    old "(Uhh... A- am I moving? God, I- I can't control it... I hope [pla] doesn't notice.)"
    new "（呃……我动了吗？天啊，我控制不了……希望[pla]没注意到。）"

translate chinese chinese_1025507_25:
    old "(Wait, is she moving? What the-)"
    new "（等下，她在动吗？什么回事－）"

translate chinese chinese_2539569_26:
    old "(Wow... Yeah, she is definitely moving... Geez, and just in front of Hinn...)"
    new "（ wow... 的确在动... 哎呀，就在 Hinn 面前...）"

translate chinese chinese_5843244_27:
    old "Hey, talking about dad, I saw he deleted the post about his marriage."
    new "说起来，我看到爸爸删了那篇关于他结婚的帖子。"

translate chinese chinese_4014997_28:
    old "Kinda late, we already saw it."
    new "有点晚了，我们已经看过了。"

translate chinese chinese_0470334_29:
    old "Mmm... Yeah, he’s just like that."
    new "嗯……是啊，他就是那样的人。"

translate chinese chinese_7559227_30:
    old "Not surprising..."
    new "不意外……"

translate chinese chinese_3136931_31:
    old "(Oh my God! I can't help myself anymore, this feels so fucking good.)"
    new "（天啊！我忍不住了，这感觉真是太棒了。）"

translate chinese chinese_0675833_32:
    old "Ahh! Ahh!"
    new "啊！啊！"

translate chinese chinese_1724355_33:
    old "(Holy cow!) U- uh, nothing, I just hurt my toe."
    new "（天啊！） uh，没什么，我只是撞到脚趾了。"

translate chinese chinese_7423024_34:
    old "A- accidentally."
    new "是-不小心。"

translate chinese chinese_8553873_35:
    old "Oh, you should be more careful."
    new "哦，你应该更小心点。"

translate chinese chinese_9931051_36:
    old "Yes honey, hehe, how silly of me..."
    new "好啦宝贝，嘿嘿，我真傻..."

translate chinese chinese_4512793_37:
    old "Are you about to finish?"
    new "你要搞定了吗？"

translate chinese chinese_7891793_38:
    old "Yeah, I’m almost done."
    new "嗯，我快好了。"

translate chinese chinese_7186798_39:
    old "Me too..."
    new "我也是……"

translate chinese chinese_6805356_40:
    old "Well, that was a relief, I’m sorry I interrupted your shower."
    new "好吧，那真是松了口气，对不起打断你洗澡了。"

translate chinese chinese_8433288_41:
    old "Don’t worry honey."
    new "别担心，宝贝。"

translate chinese chinese_3391652_42:
    old "I have to get going, gotta get back to school."
    new "我得走了，得回去上课了。"

translate chinese chinese_0532973_43:
    old "Sure honey."
    new "当然了，亲爱的。"

translate chinese chinese_5498008_44:
    old "(Oh my god! What did I just do?)"
    new "（天啊！我刚刚做了什么？）"

translate chinese chinese_0259901_45:
    old "I- I think we should get out of this tub [pla]."
    new "我— 我觉得我们应该从这个浴缸里出来[pla]。"

translate chinese chinese_3238163_46:
    old "Uhh, right, right."
    new "哦，对对。"

translate chinese chinese_5696226_47:
    old "Oh yeah, this feels so nice.."
    new "哦 yeah，这感觉真好.."

translate chinese chinese_9896669_48:
    old "Mmm, I want that big hard cock inside of me!"
    new "嗯，我要那根大硬棒在里面！"

translate chinese chinese_0402774_49:
    old "I need it."
    new "我需要它。"

translate chinese chinese_4347614_50:
    old "Uhh, I- it’s the biggest cock I’ve seen!"
    new "呃，我——这是我见过最大的鸡巴！"

translate chinese chinese_2454278_51:
    old "Oh God! I- I want to be fucked by him!"
    new "哦天啊！我—我想被他操！"

translate chinese chinese_3019527_52:
    old "(She's thinking about someone she knows?)"
    new "（她在想某个认识的人？）"

translate chinese chinese_7516750_53:
    old "Mmm... I want him to fuck me like he fucks Hinn!"
    new "嗯……我要他像对付Hinn那样狠狠地干我！"

translate chinese chinese_8539304_54:
    old "(Woah! Woah! She's not thinking about me, right?!)"
    new "（哇哦！她不会是在想我吧？!）"

translate chinese chinese_3451544_55:
    old "Oh yes, yes, yes!!"
    new "哦 yeah, yeah, yeah!!"

translate chinese chinese_4573606_56:
    old "I want to feel that hard cock inside me!"
    new "我想感受那硬邦邦的滋味！"

translate chinese chinese_4787161_57:
    old "That young, thick, hard, cock!"
    new "那年轻、粗壮、硬挺的家伙！"

translate chinese chinese_4740459_58:
    old "AH! AH! Ohhh I'm cumming, I'm cumming!"
    new "啊！啊！哦哦我要来了，我要来了！"

translate chinese chinese_2475394_59:
    old "YES! YES! YES! YES!"
    new "是的！是的！是的！是的！"

translate chinese chinese_3349439_60:
    old "Phew, that felt so good."
    new "呼，感觉真好。"

translate chinese chinese_0852839_61:
    old "I needed that."
    new "我正需要这个。"

translate chinese chinese_2917240_62:
    old "But, it’s still not the same as a dick."
    new "但是，这还是不一样于真正的阳具。"

translate chinese chinese_3341011_63:
    old "Wait, what was that sound?"
    new "等一下，那是什么声音？"

translate chinese chinese_5218350_64:
    old "Mmmm, that was a huge cock!"
    new "嗯，那真是个巨大的鸡巴！"

translate chinese chinese_7973980_65:
    old "(Is she talking about my...)"
    new "（她在说我的...）"

translate chinese chinese_9877286_66:
    old "Oh god, it barely fit in my mouth, and it tasted so good..."
    new "哦天，好不容易塞进嘴里，味道真是好极了……"

translate chinese chinese_9382913_67:
    old "Oh my God! I had never felt this before..."
    new "天啊！我从没感受过这种感觉..."

translate chinese chinese_6165912_68:
    old "Mmmm, I want that cock so badly..."
    new "嗯，我好想要那个家伙……"

translate chinese chinese_4040136_69:
    old "Ahhh! Ahh! Ah!"
    new "啊hhh! 啊hh! 啊!"

translate chinese chinese_4463454_70:
    old "I- I want your big dick inside me [pla]!"
    new "我…我要你那大棒插进来 [pla]！"

translate chinese chinese_4379103_71:
    old "I love you big cock!"
    new "我爱你大棒！"

translate chinese chinese_9789367_72:
    old "Ahh! Ahhh! I want you to fill me up!"
    new "啊！啊啊！我要你填满我！"

translate chinese chinese_7261636_73:
    old "Yes! Yes! Oh, this is so good!"
    new "是的！是的！哦，这感觉真好！"

translate chinese chinese_9866995_74:
    old "I- I’m cumming!"
    new "我快要来了！"

translate chinese chinese_1247700_75:
    old "Phew... I bet that surprised you."
    new "呼……那肯定让你吃惊了吧。"

translate chinese chinese_4370695_76:
    old "(Is she talking to me?)"
    new "（她在跟我说话吗？）"

translate chinese chinese_0747975_77:
    old "Sorry I couldn't help it, I've been a bit horny lately."
    new "对不起，我控制不住，最近有点欲火难耐。"

translate chinese chinese_5596655_78:
    old "It’s ok, I knew you were there [pla], it’s just that I needed to loosen up a little bit before."
    new "没事，我知道你在那儿[pla]，只是我之前需要放松一下。"

translate chinese chinese_2611556_79:
    old "Uhh... Before? Before what?"
    new "呃……之前？之前什么？"

translate chinese chinese_6430585_80:
    old "Before this."
    new "在这之前。"

translate chinese chinese_3791037_81:
    old "I love how big is his cock, isn't it?"
    new "我好喜欢他的 cock 那么大，不是吗？"

translate chinese chinese_1356742_82:
    old "Are you enjoying the view Jade?"
    new "你在欣赏景色吗， jade？"

translate chinese chinese_3780876_83:
    old "Mmm, yeah, have you ever seen a deep throat, Jade?"
    new "嗯，说起来，你见过深喉吗， Jade？"

translate chinese chinese_6130411_84:
    old "Do you like what I'm doing with my mouth?"
    new "你喜欢我用嘴做的这些吗？"

translate chinese chinese_7996459_85:
    old "What about if I get an oral creampie, would you like to see that jade?"
    new "要是我来个口爆，你会想看那块玉吗？"

translate chinese chinese_9929559_86:
    old "Mmmm..."
    new "嗯……"

translate chinese chinese_7424355_87:
    old "That's all what I need to know."
    new "这就够我知道了。"

translate chinese chinese_3016413_88:
    old "Mmmm, I- I think I'm about to-"
    new "嗯，我—我觉得我要—"

translate chinese chinese_2023423_89:
    old "Yes! Do it! Show Jade what she's been missing!"
    new "没错！就这样！让 jade 看看她错过了什么！"

translate chinese chinese_6676424_90:
    old "You want it too, don't you Jade?"
    new "你也很想要，不是吗， Jade？"

translate chinese chinese_9870001_91:
    old "You also want him to push this big hard dick in you mouth?"
    new "你也想让他把这根大硬棒塞进你嘴里吗？"

translate chinese chinese_2650751_92:
    old "Mmm, are you ready for your turn?"
    new "嗯，你准备好了吗？"

translate chinese chinese_0044158_93:
    old "Well? Do you want to try it, isn't it?"
    new "怎么样？你想试试，是不是？"

translate chinese chinese_1805807_94:
    old "Uhh, I- I do."
    new "呃，我——我是有的。"

translate chinese chinese_8195960_95:
    old "Good! I'm glad you're finally admitting it."
    new "好！我很高兴你终于承认了。"

translate chinese chinese_6757346_96:
    old "Great, now let's do it!"
    new "好，现在开始吧！"

translate chinese chinese_5922898_97:
    old "That's it, girl, just relax, don’t think about anything else other than what you have in your mouth right now."
    new "就是这样，宝贝，放松点，除了你现在嘴里的东西什么都不要想。"

translate chinese chinese_1907009_98:
    old "He must be enjoying this as hell, two sexy MILFS sucking his dick, that should be like heaven. Isn't it [pla]?"
    new "他肯定乐翻了，两个性感的 MILF 吸他的棒，那简直是天堂。不是吗，[pla]？"

translate chinese chinese_4842630_99:
    old "Uhh... Mmmm, yeah..."
    new "嗯……嗯嗯，对……"

translate chinese chinese_9051079_100:
    old "Hehe, enjoy this huge cock Jade."
    new "嘿嘿，享受这个巨大的鸡巴吧， jade。"

translate chinese chinese_4673287_101:
    old "I bet you've been wanting to get his hot dick in your mouth for a while, haven't you?"
    new "我敢打赌，你早就想尝尝他那火热的家伙了吧？"

translate chinese chinese_7968837_102:
    old "Mmmm!"
    new "嗯嗯！"

translate chinese chinese_0510365_103:
    old "Hahaha, that's all the answer I needed."
    new "哈哈，这就够了。"

translate chinese chinese_1349412_104:
    old "I can tell you girl, this is about a hundred times better than your ex-husband's limp dick!"
    new "我可以告诉你，这比你前夫那软塌塌的家伙好上一百倍！"

translate chinese chinese_8987010_105:
    old "Slrrrrp! Mmmm, yeah!"
    new "slurp! 哇哦！"

translate chinese chinese_5680931_106:
    old "Mmmm, how sexy you look with a big cock in your mouth."
    new "嗯，嘴里含着大鸡巴的样子真性感。"

translate chinese chinese_7107963_107:
    old "Oh yeah baby! let's make him cum. You want him to cum in your mouth and taste that big load, right?"
    new "哦 yeah 宝贝！让他射吧。你想让他在你嘴里射，尝尝那大量的精液，对吧？"

translate chinese chinese_4341162_108:
    old "...Y- yes, I want it..."
    new "...是的，我想要..."

translate chinese chinese_0906973_109:
    old "You already heard it please, don't hold back and give us a huge cumshot."
    new "你已经听到了，请不要克制，给我们一个巨大的射精。"

translate chinese chinese_1428535_110:
    old "I- I think I’m about to...!"
    new "我——我觉得我要......！"

translate chinese chinese_2105110_111:
    old "That’s it, cum for us baby!"
    new "就是这样，为我们高潮吧，宝贝！"

translate chinese chinese_9132703_112:
    old "I want you to cum in her mouth!"
    new "我想让你在她嘴里射！"

translate chinese chinese_1003669_113:
    old "You are going to drink every single drop, Jade."
    new "你得把每一滴都喝下去，翡翠。"

translate chinese chinese_1566489_114:
    old "Ohh yeah, that was a huge load. Did you enjoy it Jade?"
    new "哦耶，那真是好多。你爽吗， Jade？"

translate chinese chinese_5722133_115:
    old "Uhh... Y- yes..."
    new "呃……是的……"

translate chinese chinese_2632310_116:
    old "What did I tell you? This is a lot better than masturbating."
    new "我跟你说过，这比自渎好多了。"

translate chinese chinese_1849095_117:
    old "And with such a young gifted man, you didn’t know what you were missing on girl."
    new "这样一个年轻有才华的男人，你不知道自己错过了什么，女孩。"

translate chinese chinese_0445640_118:
    old "I- I suppose you’re right."
    new "我—我想你是对的。"

translate chinese chinese_5866120_119:
    old "You know I’m right. Now let me help you clean up all this mess."
    new "你知道我是对的。现在让我帮你收拾这一切烂摊子。"

translate chinese chinese_9746442_120:
    old "Uhh, w- what is happening?"
    new "呃，这，这是怎么回事？"

translate chinese chinese_5888891_121:
    old "Well, you know what Mrs. White said last time."
    new "嗯，你知道怀特夫人上次怎么说的。"

translate chinese chinese_3287502_122:
    old "Maybe we should try to do some of this on our own."
    new "maybe 我们应该试着自己做些这个。"

translate chinese chinese_3514344_123:
    old "To be honest, I’ve been thinking about this way too much, it’s about time I do something about it."
    new "说实话，我一直在想这件事，是时候采取行动了。"

translate chinese chinese_7190338_124:
    old "Hmph! Slrrrp!"
    new "哼！啧！"

translate chinese chinese_9226357_125:
    old "I can kind of see why Hinn likes you so much."
    new "我能理解希恩为什么这么喜欢你。"

translate chinese chinese_0393081_126:
    old "How could she not? With such an amazing cock!"
    new "她怎么可能呢？这么棒的家伙！"

translate chinese chinese_7502348_127:
    old "I love how hot your cock is?"
    new "我好喜欢你这么火热的丁丁？"

translate chinese chinese_4556029_128:
    old "Are you liking it, honey?"
    new "你喜欢这样吗，宝贝？"

translate chinese chinese_1015470_129:
    old "Mmm, yeah..."
    new "嗯，是的……"

translate chinese chinese_6248528_130:
    old "Me too!"
    new "我也是！"

translate chinese chinese_0958879_131:
    old "I- I think I’m about to cum!"
    new "我——我觉得我要来了！"

translate chinese chinese_8233376_132:
    old "It’s ok, you can cum in my mouth!"
    new "没事，你可以射在我嘴里！"

translate chinese chinese_4007835_133:
    old "I want to taste it again!"
    new "我想再尝一次！"

translate chinese chinese_3044591_134:
    old "Phew, that was really good [pla]."
    new "呼，那真是很好吃[pla]。"

translate chinese chinese_4124574_135:
    old "OH MY GOD!! Oh wow!"
    new "天啊！！好厉害！"

translate chinese chinese_6390952_136:
    old "Hahaha, he’s huge isn’t he?"
    new "哈哈，他真的很大吧？"

translate chinese chinese_1616680_137:
    old "Just relax and enjoy it girl."
    new "放松点，享受吧姑娘。"

translate chinese chinese_9872316_138:
    old "Not always can you enjoy something like this."
    new "不是每次都能有这样的享受。"

translate chinese chinese_0543879_139:
    old "Ah! Ah! I can’t! This is just too good!"
    new "啊！啊！我忍不住了！这太棒了！"

translate chinese chinese_5705892_140:
    old "Yeah that’s right, take it all."
    new "没错，全部都拿去。"

translate chinese chinese_0977279_141:
    old "Ha! I bet that looser of your ex-husband never fucked you like this!"
    new "哈！我敢打赌，你那个loser前夫从没这样对你吧！"

translate chinese chinese_4017949_142:
    old "What do you say [pla]? How does it feel to have two MILFS like us just for you?"
    new "你说呢，[pla]？有两个像我们这样的 MILF 专门宠着你，感觉如何？"

translate chinese chinese_0999117_143:
    old "Did you ever feel anything like this before, Jade?"
    new "jade，你以前有过这种感觉吗？"

translate chinese chinese_5877578_144:
    old "Ahh! Ahh! O- of course not!"
    new "啊！啊！不—当然不是！"

translate chinese chinese_6495538_145:
    old "Hahaha, I love to see you like this!"
    new "哈哈哈哈哈，我就喜欢看你这副样子！"

translate chinese chinese_6653338_146:
    old "Enjoy it girl, you deserve it!"
    new "享受吧女孩，你值得的！"

translate chinese chinese_2548472_147:
    old "Keep going [pla]!"
    new "继续吧，[pla]！"

translate chinese chinese_7368555_148:
    old "You’re about to make her cum!"
    new "你快要让她高潮了！"

translate chinese chinese_3298462_149:
    old "Don’t stop! Don’t stop now!"
    new "不要停！现在不要停！"

translate chinese chinese_7948499_150:
    old "Ahhhh, Ahhhhh!"
    new "啊hhh, 啊hhhh!"

translate chinese chinese_0947551_151:
    old "Oh my! That was great, really great."
    new "哦我的天！太棒了，真的太棒了。"

translate chinese chinese_2422779_152:
    old "And look at that, he just came and he’s still hard!"
    new "你看，他刚来还没软呢！"

translate chinese chinese_2267166_153:
    old "It must be great to be that young!"
    new "能那么年轻一定很棒吧！"

translate chinese chinese_4930668_154:
    old "But now it’s my turn."
    new "但现在轮到我了。"

translate chinese chinese_6973494_155:
    old "Come here [pla], I want you to fuck me hard."
    new "过来 [pla]，我要你狠狠地干我。"

translate chinese chinese_8013437_156:
    old "Nngh! Oh yeah, that’s it!"
    new "嗯！哦 yeah，就是这样！"

translate chinese chinese_4389544_157:
    old "That’s just what I have been waiting for."
    new "这正是我一直在等的。"

translate chinese chinese_3132787_158:
    old "Uhhh, it just fills me up!"
    new "呃，那真的让我很满足！"

translate chinese chinese_0362954_159:
    old "Ah! Ah! Ah! It’s so big!"
    new "啊！啊！啊！好大啊！"

translate chinese chinese_1747248_160:
    old "I want to keep being fucked by you everyday!"
    new "我想每天都被你操！"

translate chinese chinese_8451345_161:
    old "I- I never had any sex like this with my ex-husband either!"
    new "我——我和前夫也没发生过这样的事！"

translate chinese chinese_1945950_162:
    old "It’s unbelievable how good this is!"
    new "这简直好得难以置信！"

translate chinese chinese_2366798_163:
    old "Keep going [pla]! Keep pounding my pussy!"
    new "继续干吧[pla]！继续猛击我的下体！"

translate chinese chinese_7006307_164:
    old "Yes! yes! yes!"
    new "是的！是的！是的！"

translate chinese chinese_9285371_165:
    old "Mrs. White, I can’t hold it in any longer!"
    new "怀特夫人，我实在忍不住了！"

translate chinese chinese_0400329_166:
    old "Cum! Cum inside me!"
    new "射！在里面射！"

translate chinese chinese_9503919_167:
    old "Oh my God! I have missed this cock so much!"
    new "天啊！我好想这个家伙！"

translate chinese chinese_0382859_168:
    old "I love being fucked by you!"
    new "我爱被你操！"

translate chinese chinese_6825995_169:
    old "Well, I must say that was wonderful."
    new "好吧，我必须说那真是太棒了。"

translate chinese chinese_4240049_170:
    old "Just look at you Jade! You look so calm and relaxed now!"
    new "看看你，翡翠！你现在看起来这么淡定自若！"

translate chinese chinese_1588233_171:
    old "Yeah, I think you’re absolutely right!"
    new "是的，我觉得你说得完全正确！"

translate chinese chinese_7565817_172:
    old "I can’t believe how relaxed I am!"
    new "真不敢相信我这么放松！"

translate chinese chinese_1254917_173:
    old "I must say, I don’t even care about what’s happening with Hiashi right now. I hope he’s very happy with his new wife."
    new "必须说，我现在根本不在乎辉夜的事。希望他和他的新妻子过得很快乐。"

translate chinese chinese_7916100_174:
    old "If she doesn’t cheat on him."
    new "如果她没有背叛他。"

translate chinese chinese_5542546_175:
    old "Hahahaha!"
    new "哈哈哈哈哈！"

translate chinese chinese_3049018_176:
    old "Hahahaha."
    new "哈哈哈哈哈。"

translate chinese chinese_1732621_177:
    old "Well, I think we should better get dressed before your daughter gets home."
    new "嗯，我觉得咱们最好在你女儿回家前穿好衣服。"

translate chinese chinese_9824651_178:
    old "Right, right."
    new "对对对。"

translate chinese chinese_4401670_179:
    old "I- it's so big... Oh my God!"
    new "它好大……天啊！"

translate chinese chinese_9594609_180:
    old "Mmmm [pla]! I could get addicted to your cock!"
    new "嗯嗯 [pla]！我可能会对你的棒子上瘾的！"

translate chinese chinese_4647795_181:
    old "No wonder Hinn always wants to fuck with you!"
    new "怪不得赫恩总是想跟你搞呢！"

translate chinese chinese_0209314_182:
    old "It’s so hot! So thick and hard!"
    new "好热！又粗又硬！"

translate chinese chinese_2210299_183:
    old "I can’t resist it!"
    new "我忍不住了！"

translate chinese chinese_1720051_184:
    old "Yes! Yes! Yes! Keep going!"
    new "是的！是的！是的！继续！"

translate chinese chinese_5848788_185:
    old "Just like that!"
    new "就是那样！"

translate chinese chinese_4680787_186:
    old "Fuck me, fuck me harder [pla]!"
    new "操我，再用力点操我 [pla]!"

translate chinese chinese_7125948_187:
    old "Ahhh! I love it!"
    new "啊hhh！我爱死了！"

translate chinese chinese_2557188_188:
    old "I'm about to cum honey!"
    new "我要来了，宝贝！"

translate chinese chinese_1323449_189:
    old "L- let's do it!"
    new "好，我们来吧！"

translate chinese chinese_4940028_190:
    old "Let's cum together!!"
    new "我们一起高潮吧！！"

translate chinese chinese_0753135_191:
    old "Wow, that was wonderful honey."
    new "哇，真是太棒了，宝贝。"

translate chinese chinese_9479631_192:
    old "And the shower it’s also working perfectly."
    new "淋浴也工作得很好。"

translate chinese chinese_2142936_193:
    old "Oh my God! It's too late, Come on honey, let’s get dressed."
    new "天啊！已经太晚了，快来穿衣服，宝贝。"

# auto-tl Qwen Colab

translate chinese chinese_6911420_0:
    old "And... Who are you?"
    new "而且……你是谁？"

translate chinese chinese_2490008_1:
    old "Wow, can you see me? So it was true. Interesting... "
    new "哇，你能看到我？所以是真的了。有意思……"

translate chinese chinese_7671037_2:
    old "You are the human with Agamoto's Eye?"
    new "你是拥有阿戈莫托之眼的人类？"

translate chinese chinese_4926083_3:
    old "Yes... and you... are you a... shinigami?"
    new "是的……而你……你是……死神吗？"

translate chinese chinese_4379510_4:
    old "Yes! This is the first time I've met a human."
    new "是的！这是我第一次遇到人类。"

translate chinese chinese_1504074_5:
    old "Ok... So, do you know the shinigami of the other night?"
    new "好吧……那么，你知道那天晚上的死神吗？"

translate chinese chinese_4239081_6:
    old "You mean Mildret?"
    new "你是说Mildret？"

translate chinese chinese_6392197_7:
    old "I don't know her name, but she also sucked up my magical power..."
    new "我不知道她的名字，但她也吸了我的魔法力量……"

translate chinese chinese_7441493_8:
    old "Yes, then you talk about Mildret  hehehe."
    new "好的，然后你再说说Mildret嘿嘿嘿。"

translate chinese chinese_4582292_9:
    old "Are there more shinigami, besides Mildret and... you?"
    new "除了Mildret和你之外，还有其他的死神吗？"

translate chinese chinese_2705079_10:
    old "Yes we are only three and I am Devonne. Nice to meet you!"
    new "没错，我们只有三个人，我是黛冯。很高兴见到你！"

translate chinese chinese_2691986_11:
    old "Nice... to... meet... you. My name is [pla]..."
    new "很高兴...见到...你。我叫[pla]..."

translate chinese chinese_9115278_12:
    old "Wow, [pla]? What strange names humans have... hahaha."
    new "哇，[pla]？人类起的名字真奇怪……哈哈。"

translate chinese chinese_7187579_13:
    old "You're not mad at me?"
    new "你不会生我的气吧？"

translate chinese chinese_9375484_14:
    old "Me? No... Why would I be?"
    new "我？不……为什么我会是？"

translate chinese chinese_4498303_15:
    old "Because Mildret accused me of stealing magical power..."
    new "因为米德雷特诬陷我偷窃魔力..."

translate chinese chinese_0394359_16:
    old "Ohhh you mean that... Well, there has been someone who has been gathering the magical power in this area and we think it's you... Is it you?"
    new "哦hhh你是说那个……好吧，有人一直在收集这个区域的魔法力量，我们认为是你……是吗？"

translate chinese chinese_3372467_17:
    old "Well, yes... But..."
    new "嗯，是的……但是……"

translate chinese chinese_7181825_18:
    old "Ohhh... Then it's true, You are the thief... And you were starting to like me... I better go before you take away the little I recovered..."
    new "哦……那是真的，你是小偷……而且你开始喜欢我了……我还是走吧，免得你把我好不容易恢复的一点东西也抢走了……"

translate chinese chinese_6871777_19:
    old "No,wait!"
    new "等一下！"

translate chinese chinese_4476616_20:
    old "Hmm... Again... And they are three huh?"
    new "嗯……再来一次……他们三个啊？"

translate chinese chinese_1086876_21:
    old "So, did you get enought magic power?"
    new "所以，你够到足够的魔法力量了吗？"

translate chinese chinese_0720122_22:
    old "Yeay! Thank you so much..."
    new "耶！太感谢你了..."

translate chinese chinese_6508533_23:
    old "Don't worry, I just wanna help you..."
    new "别担心，我只是想帮你..."

translate chinese chinese_8965081_24:
    old "You are the best!"
    new "你是最棒的！"

translate chinese chinese_8955804_25:
    old "Well I have to go... Goodbye, [pla]"
    new "好吧，我得走了……再见，[pla]"

translate chinese chinese_6200475_26:
    old "I hoped you wouldn't steal more magical power..."
    new "我还希望你不要再偷取更多的魔力……"

translate chinese chinese_0355131_27:
    old "You destroyed the magical world!!!"
    new "你毁掉了魔法世界！！！"

translate chinese chinese_0903898_28:
    old "You are the worst being in the universe!..."
    new "你真是宇宙中最差的生物！..."

translate chinese chinese_1020965_29:
    old "I don't understand... Why do you say that?..."
    new "我不明白……为什么你会这么说……"

translate chinese chinese_5548198_30:
    old "You have already done a lot of damage, and now you want to make us disappear by talking away the magical power... Leave us alone, once and for all..."
    new "你已经造成了很大的伤害，现在还想通过消耗魔力让我们消失……永远不要再管我们了……"

translate chinese chinese_0647360_31:
    old "... What the hell?..."
    new "……这是什么情况……"

translate chinese chinese_8312463_32:
    old "Oh boy, there is nothing more fun than sharing magical power."
    new "哦哟，没有什么比共享魔力更有趣的了。"

translate chinese chinese_6578593_33:
    old "I'm glad you feel good, you can still count on receiving magical power when you need me, you can go when you want it..."
    new "很高兴你觉得好，你需要我的时候还是可以指望获得魔力，你想走的时候就可以走..."

translate chinese chinese_2659785_34:
    old "Do not hesitate..."
    new "不要犹豫..."

translate chinese chinese_8163081_35:
    old "Well, I must go now, I'm glad I closed the deal and finished everything in good terms..."
    new "好吧，我现在得走了，很高兴把事情都处理好了……"

translate chinese chinese_4409913_36:
    old "[pla], take care of Brixxida, she's not what she seems..."
    new "[pla]，照顾好Brixxida，她不是表面上看起来的那样..."

translate chinese chinese_1465044_37:
    old "Yes, I'll be careful..."
    new "好的，我会小心的..."

translate chinese chinese_0337463_38:
    old "Okay..."
    new "好吧……"

translate chinese chinese_0065331_39:
    old "Yeay! really fun... right?..."
    new "耶！真好玩……对吧？……"

translate chinese chinese_4743838_40:
    old "Haha right, it was fun."
    new "哈哈，对啊，真好玩。"

translate chinese chinese_4296655_41:
    old "Ok, I'm going to collect more magic power to do it again..."
    new "好的，我去收集更多的魔力再来一次……"

translate chinese chinese_7585559_42:
    old "Just take it easy... Ok?"
    new "just take it easy... Ok? \n\n({i}放轻松点... 好吗？{/i})"

translate chinese chinese_9439927_43:
    old "Ok, ok..."
    new "好啦好啦……"

translate chinese chinese_8770210_44:
    old "(Perfect, I must use Sauron's mouth) {b}Sauron's mouth!{/b}"
    new "(完美，我必须使用索伦之口) {b}索伦之口！{/b}"

translate chinese chinese_1495716_45:
    old "Tell me your name shinigami!"
    new "告诉我你的名字，死神！"

translate chinese chinese_4735965_46:
    old "My name is Gomory..."
    new "我叫Gomory..."

translate chinese chinese_8726149_47:
    old "Hmmm... Do you know Devonne and... Mildret? "
    new "嗯……你知道德沃内和……米尔德雷特吗？"

translate chinese chinese_4630136_48:
    old "Yes, they are two allied shinigamis..."
    new "是的，他们是两个同盟的死神……"

translate chinese chinese_2496148_49:
    old "Why are you stealing magic power from me?"
    new "你为什么偷我的魔法力量？"

translate chinese chinese_4295796_50:
    old "You have been collecting magical power from this area, which has left us with few reserves... and soon we'll not enough to exist."
    new "你一直在吸收这里的魔力，导致我们几乎没有什么储备了……很快我们就无法维持存在了。"

translate chinese chinese_2672940_51:
    old "I should go... I've said enough..."
    new "我该走了……我说得够多了……"

translate chinese chinese_3657107_52:
    old "No, no, wait! I didn't know I was taking magic power from you..."
    new "不，不，等一下！我不知道我在吸收你的魔力..."

translate chinese chinese_3115704_53:
    old "Well, actually, it is not the magic power from us. It's just that there is less and less in the area."
    new "其实，这并不是因为我们身上的魔力减少了，而是这一带的魔力本身就在逐渐减少。"

translate chinese chinese_7918994_54:
    old "I think we will soon cease to exist because there will be no more..."
    new "我觉得我们很快就会消失，因为再也不会有……"

translate chinese chinese_9928462_55:
    old "And you do not need the magic power to exist..."
    new "而你不需要魔力就能存在……"

translate chinese chinese_3783697_56:
    old "Ohhh... I understand perfectly... I didn't know... I mean, I knew it, but I didn't know you existed..."
    new "哦……我完全明白了……我不知道……我是说，我知道那些，但我不知道你存在……"

translate chinese chinese_2279109_57:
    old "Well, you already know... It is not something that makes much difference. At some point all the magical power will end and we will disappear..."
    new "好吧，你已经知道了……这没什么大不了的。总有一天魔力会耗尽，我们会消失……"

translate chinese chinese_7575915_58:
    old "What about the 'Chosen One'? Who will rebuild the magical world? "
    new "那个“天选之人”呢？谁来重建魔法世界？"

translate chinese chinese_7757977_59:
    old "It's a myth... No one really thinks that will happen since years have passed... Anyway... I'm leaving..."
    new "这只是一个传说……这么多年过去了，没人真的认为会发生……不管怎样……我要走了……"

translate chinese chinese_2963903_60:
    old "But... Hmm... Now I understand... I have to talk with Brixxida"
    new "但是……嗯……现在我明白了……我得和Brixxida谈谈"

translate chinese chinese_7260117_61:
    old "Well, did you get enough magic power?"
    new "嗯，你魔力够了吗？"

translate chinese chinese_4561615_62:
    old "Yes, I have enough for now..."
    new "是的，我现在够了……"

translate chinese chinese_6116229_63:
    old "Ok, you can come anytime if you need more..."
    new "好吧，你需要更多的话随时可以来……"

translate chinese chinese_2699473_64:
    old "Ok, thanks. I have to go."
    new "好的，谢谢。我得走了。"

translate chinese chinese_1679879_65:
    old "Damn, you left me with too little energy..."
    new "妈的，你把我能量值设得太低了……"

translate chinese chinese_6596421_66:
    old "{b}Sauron's mouth!{/b}"
    new "{b}索伦的嘴！{/b}"

translate chinese chinese_4970972_67:
    old "Answer me, why do you say that I destroyed the magical world?"
    new "给我解释一下，为什么你说我毁掉了魔法世界？"

translate chinese chinese_5545062_68:
    old "You are the owner of the SexNote, who destroyed the magical world..."
    new "你是SexNote的主人，摧毁了魔法世界..."

translate chinese chinese_7943209_69:
    old "What? But I didn't..."
    new "什么？可是我还没..."

translate chinese chinese_7414456_70:
    old "How was the magical world destroyed? "
    new "魔法世界是怎么被毁的？"

translate chinese chinese_8852885_71:
    old "A powefull being who possessed the SexNote, performed a forbidden spell that caused the magical world to collapse..."
    new "一个拥有SexNote的强大力量的存在，施展了一个禁忌咒语，导致魔法世界崩塌……"

translate chinese chinese_3854812_72:
    old "What the fuck?..."
    new "什么玩意儿？..."

translate chinese chinese_2050671_73:
    old "Thieves!! Stop stealing the magic power!"
    new "偷贼！！别再偷魔法力量了！"

translate chinese chinese_3873524_74:
    old "We have little magic energy left for Mildret and me... Don't attack us anymore..."
    new "我们和米德雷特剩下的魔法能量不多了……不要再攻击我们了……"

translate chinese chinese_9377017_75:
    old "You must die! I will finish you!"
    new "你必须死！我要结果你！"

translate chinese chinese_9888218_76:
    old "What are you doing!?"
    new "你在干什么！？"

translate chinese chinese_4426953_77:
    old "I'm trying to make them not bother you again..."
    new "我正想办法让他们不要再烦你..."

translate chinese chinese_3507798_78:
    old "I was getting information... You chased her away..."
    new "我正在搜集情报……你把她吓跑了……"

translate chinese chinese_5232535_79:
    old "Sorry, I am upset about the magical power that was stolen from us..."
    new "对不起，我在为被偷走的魔力感到沮丧……"

translate chinese chinese_5282010_80:
    old "But... Why did you do that?"
    new "但是……你为什么这么做？"

translate chinese chinese_7627541_81:
    old "Anyway, just let's go home..."
    new "总之，我们还是回家吧..."

translate chinese chinese_3159300_82:
    old "Ok..."
    new "好吧……"

translate chinese chinese_6762052_83:
    old "Hmm... Things are very suspicious... I'll have to talk to Brixxida to clarify everything..."
    new "嗯……事情很可疑……我得去和Brixxida谈谈弄清楚一切……"

translate chinese chinese_7540072_84:
    old "Well I hope this little help you, to improve your skills..."
    new "好吧，我希望这点帮助能提高你的技能……"

translate chinese chinese_8356957_85:
    old "Thank you, I really appreciate all your help."
    new "谢谢你，真的很感激你的帮助。"

translate chinese chinese_8926263_86:
    old "You're welcome, we count on you to save the magical world."
    new "不客气，我们靠你来拯救魔法世界了。"

translate chinese chinese_2098499_87:
    old "I'll take care of fixing everything, I promise..."
    new "我会负责修好的，我保证..."

translate chinese chinese_5330057_88:
    old "Thank you."
    new "谢谢。"

translate chinese chinese_8661496_89:
    old "What the fuck? Who are you? And What was that?!"
    new "妈的？你是谁？刚刚那是什么？！"

translate chinese chinese_5177325_90:
    old "What? Can you see me?"
    new "什么？你能看到我吗？"

translate chinese chinese_2711062_91:
    old "Yes! Of course, I can see you..."
    new "是的！当然，我能看见你..."

translate chinese chinese_6537688_92:
    old "How the fuck can you see me? You are a simple human... "
    new "你怎么妈的能看见我？你只是一个普通人……"

translate chinese chinese_1522419_93:
    old "Uhh no... I think it's because I have Agamoto's eyes."
    new "呃，不是……我觉得是因为我有阿戈莫多的眼睛。"

translate chinese chinese_7404094_94:
    old "What?! You have Agamoto's eyes?"
    new "什么?! 你有阿戈莫托的眼睛?"

translate chinese chinese_6724163_95:
    old "Ehh yeah... But who are you?"
    new "嗯嗯……但是你是谁？"

translate chinese chinese_4918071_96:
    old "Sooo... it's you who's been stealing the magic power?!"
    new "所以……偷走魔法力量的就是你？！"

translate chinese chinese_3322630_97:
    old "What? Stealing magic power?"
    new "什么？偷魔力？"

translate chinese chinese_0466649_98:
    old "Look, I'll only warn you this once... If you keep stealing the magic power I will be forced to take extreme measures..."
    new "听着，我只警告你一次……如果你继续偷我的魔力，我将被迫采取极端措施……"

translate chinese chinese_3792692_99:
    old "Extreme measures?"
    new "极端手段？"

translate chinese chinese_4643441_100:
    old "This is not a children's game... You better stop stealing the magical power."
    new "这可不是儿童游戏……你最好停止偷取魔力。"

translate chinese chinese_2202623_101:
    old "But- wait... What?"
    new "但是——等一下……什么？"

translate chinese chinese_6146622_102:
    old "Hmm... Will have to talk to Brixxida tomorrow..."
    new "嗯……明天得去找布里克西达谈谈……"

translate chinese chinese_5132905_103:
    old "Well, did you get enough?"
    new "嗯，够了吗？"

translate chinese chinese_1215418_104:
    old "Yes, thank you for everything..."
    new "是的，感谢你做的一切……"

translate chinese chinese_5273601_105:
    old "No problem. You can come back anytime if you need more..."
    new "没问题。你需要更多的话随时可以回来。"

translate chinese chinese_4666948_106:
    old "We just need a little to not disappear..."
    new "我们只需要一点点就不会消失了……"

translate chinese chinese_2953405_107:
    old "Anyway I will let you keep sleeping... Bye..."
    new "算了，让你继续睡吧……拜拜……"

translate chinese chinese_9130092_108:
    old "Don't you see? You're a thief... And now you steal directly."
    new "你看不出来吗？你是个小偷……而且现在你直接就偷了。"

translate chinese chinese_8470522_109:
    old "I'm not... I'm only recovering what you took away from me, Nothing more."
    new "我……我只是想拿回你从我这里夺走的东西， nothing more."

translate chinese chinese_3162192_110:
    old "You have been taking away all the energy in these past few days..."
    new "这些天你把我的精力都吸干了……"

translate chinese chinese_8719195_111:
    old "You don't need it to exist..."
    new "你不需要它也能存在……"

translate chinese chinese_4555305_112:
    old "I am the chosen one, I will be able to restore the magical world..."
    new "我是被选中的那个人，我能够恢复魔法世界……"

translate chinese chinese_7729383_113:
    old "You are a simple human, you cannot do anything for the magical world..."
    new "你只是一个普通人，无法为魔法世界做任何事……"

translate chinese chinese_8777714_114:
    old "I am the owner of the SexNote!..."
    new "我是SexNote的主人！..."

translate chinese chinese_9163359_115:
    old "You... have... the... SexNote?..."
    new "你……有……SexNote……吗？……"

translate chinese chinese_8273334_116:
    old "That's right... I will rebuild the magical world..."
    new "没错……我将会重建魔法世界……"

translate chinese chinese_4156046_117:
    old "... "
    new "... "

translate chinese chinese_1114172_118:
    old "Wait... Hmm..."
    new "等一下……嗯……"

translate chinese chinese_0616862_119:
    old "Ok, I think is enought for now, right?..."
    new "好吧，我觉得现在差不多了，对吧？..."

translate chinese chinese_5582997_120:
    old "Well, yes, thank you... But if you have little just left tell me."
    new "嗯，好的，谢谢……但是如果你只剩下一点点了就告诉我。"

translate chinese chinese_4050464_121:
    old "Don't worry I'm good for now..."
    new "别担心，我现在没事……"

translate chinese chinese_7035708_122:
    old "Now let me rest and recover some magic power..."
    new "现在让我休息一下，恢复一些魔法力量……"

translate chinese chinese_7048276_123:
    old "Ok, see you..."
    new "好吧，再见..."

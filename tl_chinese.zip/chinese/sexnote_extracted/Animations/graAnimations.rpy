# auto-tl Qwen Colab

translate chinese chinese_3440670_0:
    old "I feel I'm in heaven just by touching it! Oh my Father, I'm so grateful."
    new "我感觉只要碰到它我就上天了！哦我的天，我太感激了。"

translate chinese chinese_4056921_1:
    old "(My God!...)"
    new "（天啊！...）"

translate chinese chinese_8935711_2:
    old "The feeling of your big grace on my hands, it's so pure."
    new "你那双大手给予我的恩赐，是如此纯粹。"

translate chinese chinese_9864420_3:
    old "My heavenly God!... It's so... S- So great and big, divine!"
    new "天啊！……它这么……壮、壮丽，简直神乎其神！"

translate chinese chinese_4413007_4:
    old "I feel that grace is going to come in my fac- Ahhhhhh!!!"
    new "我觉得优雅就要降临到我脸上了——啊啊啊！！！"

translate chinese chinese_9584313_5:
    old "Your divine phallus is precious, just by seeing it I can feel the glory in him."
    new "你的神圣阳具很珍贵，光是看看就能感受到它的荣耀。"

translate chinese chinese_3900663_6:
    old "(Wow is s- she... S- sucking it...)"
    new "（哇，她…在吸…）"

translate chinese chinese_4235854_7:
    old "Your divine phallus tastes like heaven... Oh my Father, I'm so grateful."
    new "你的神之阳具味道像天堂……哦，我的父亲，我好感激。"

translate chinese chinese_7239470_8:
    old "My soul is silent and my door is open for you, I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "我的灵魂是寂静的，大门向你敞开，我需要你的圣水在我口中洗净，最近我说了很多错话，得清理一下了。"

translate chinese chinese_6360348_9:
    old "I wanna feel it in my tongue... My tongue is thirsty of you..."
    new "我想用舌头感受它……我的舌头渴望你……"

translate chinese chinese_7270241_10:
    old "I feel that grace is going to come... To come in my lips!!!"
    new "我觉得那种优雅即将……来到我的唇间！！！"

translate chinese chinese_8776417_11:
    old "Ahhhhhhhh!!"
    new "啊啊啊啊啊！！"

translate chinese chinese_5125516_12:
    old "(My Godness!... This is heaven, divine!)"
    new "（天啊！……这是天堂，太美妙了！）"

translate chinese chinese_8440428_13:
    old "(Wow is s- she... S- sucking it again...)"
    new "（哇，她…在吸…）"

translate chinese chinese_2791347_14:
    old "I need your sacred water in my mouth, I have said many wrong things lately and I gotta clean that."
    new "我需要你的圣水在我嘴里，我最近说了好多错话，得清理一下。"

translate chinese chinese_3919761_15:
    old "Oh father, my soul is silent and my door is open for you, I need you inside of me cleaning my impure soul."
    new "哦爸爸，我的灵魂是寂静的，我的心门为你敞开，我需要你在我的体内净化我的污秽灵魂。"

translate chinese chinese_2115899_16:
    old "Does she wants me to f- fuck... her?"
    new "她想让我…干她？"

translate chinese chinese_5122802_17:
    old "Ohhh father, I can feel your grace inside me!"
    new "哦哦爸爸，我感到你的恩典在我体内！"

translate chinese chinese_4755251_18:
    old "And it feels sooo goood!"
    new "感觉好好哦！"

translate chinese chinese_0573138_19:
    old "(Ohh yeah...)"
    new "（哦哦，是的...）"

translate chinese chinese_9268113_20:
    old "Yes, father! Please clean all my sins harder!"
    new "是的，父亲！请用力洗净我的所有罪孽！"

translate chinese chinese_0177034_21:
    old "Ohhh God! Oh God!"
    new "哦天啊！哦天啊！"

translate chinese chinese_5712995_22:
    old "Ahhh Ahhh father. Yes, give me more! MORE!"
    new "啊啊啊爸爸。没错，再多一点！再多点！"

translate chinese chinese_6686406_23:
    old "(My heavenly God!... I'm seeing the heaven!)"
    new "（我的天啊！……我看到天堂了！）"

translate chinese chinese_0303065_24:
    old "I feel that grace is going to come... To come insid- Ahhhhhh!!!"
    new "我觉得格蕾丝要来了……要进来了——啊啊啊啊！！！"

translate chinese chinese_7672921_25:
    old "My heavenly God, it's so big."
    new "天啊，这么大。"

translate chinese chinese_6590664_26:
    old "Oh God! It tastes like heaven..."
    new "哦天啊！味道好极了……"

translate chinese chinese_1362164_27:
    old "I need to purify my soul with your holy milk."
    new "我需要用你的圣洁牛奶净化我的灵魂。"

translate chinese chinese_1839067_28:
    old "Sister Grace... I- I-"
    new "格蕾丝姐姐……我——我——"

translate chinese chinese_7845930_29:
    old "Oh yeah! I want to feel that grace in my mouth-"
    new "哦耶！我想感受那种优雅在我的嘴里—"

translate chinese chinese_3104401_30:
    old "Ahhhhhh!!! I can feel the greatness of your body inside me..."
    new "啊啊啊啊！！我感觉到你的身体在我体内……"

translate chinese chinese_7801693_31:
    old "I wanted this so badly... There is no pain I can't bear for God."
    new "我这么渴望这个……为了上帝，我没有什么痛苦是承受不了的。"

translate chinese chinese_7946210_32:
    old "Harder! Harder! I want you to make me feel more pain!"
    new "再用力点！再用力点！我要你让我感觉更多的痛！"

translate chinese chinese_4896122_33:
    old "Ahhhhhh! Ahhhhh! Ahhh!"
    new "啊啊啊啊！啊啊啊！啊啊！"

translate chinese chinese_1702303_34:
    old "My soul needs as much forgiveness as my body needs punishment."
    new "我的灵魂需要宽恕，就像我的身体需要惩罚一样。"

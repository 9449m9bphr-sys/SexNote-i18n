# auto-tl Qwen Colab

translate chinese chinese_9476254_0:
    old "Wow! I see you've a lot of energy repressed... Big and impressive."
    new "哇！看来你压抑了很多精力……很大很惊人。"

translate chinese chinese_0201578_1:
    old "... I guess..."
    new "……我猜……"

translate chinese chinese_5993866_2:
    old "Hmm..."
    new "嗯……"

translate chinese chinese_3259907_3:
    old "Ohh it tastes great! I really like it."
    new "哦，真好吃！我真的很喜欢。"

translate chinese chinese_4596952_4:
    old "Oh yeah... Give it to me... Give me all your load!"
    new "哦 yeah……给我……把所有都给我！"

translate chinese chinese_5475833_5:
    old "Ahhh... I'm feeling it on my mouth!"
    new "啊hhh...我感觉到我的嘴上了！"

translate chinese chinese_1496524_6:
    old "Hmmm, It was great... Now I need your dick inside, the energy transfer should be done now."
    new "嗯，真不错……现在需要你进去，能量传输应该完成了。"

translate chinese chinese_3889660_7:
    old "Oh yeah... I haven't felt this in a long time ..."
    new "哦，是啊……我好久没这种感觉了……"

translate chinese chinese_6286620_8:
    old "Wow is huge and is drilling this girl..."
    new "哇，好大，正在猛搞这个女孩……"

translate chinese chinese_3869160_9:
    old "Ohhh yeahhh, harder, harder!"
    new "哦哦，对了，再用力点，再用力点！"

translate chinese chinese_3620000_10:
    old "Don't stop! Gimme more! I want it all!"
    new "别停！再来！我要全部！"

translate chinese chinese_9818770_11:
    old "Ahhhhh.... Yeah!"
    new "啊啊啊……对！"

translate chinese chinese_4814350_12:
    old "Wow... Ahhhhhhhh!"
    new "哇……啊啊啊啊啊！"

translate chinese chinese_0469286_13:
    old "Pfff... "
    new "呼……"

translate chinese chinese_5338556_14:
    old "Hmm, Billie has really big boobs, isn't she [pla]?"
    new "嗯，Billie 的胸部真的很大，不是吗 [pla]？"

translate chinese chinese_0903249_15:
    old "Ohh yeah..."
    new "哦哦……是的……"

translate chinese chinese_2857860_16:
    old "How does it feel to get your boobs sucked Billie?"
    new "被吸胸部的感觉怎么样，比莉？"

translate chinese chinese_7979096_17:
    old "I'm not gonna lie, it feels pretty nice."
    new "说句实话，感觉挺不错的。"

translate chinese chinese_4719261_18:
    old "Woahh, [pla] are you getting excited?"
    new "哇哦，[pla] 你激动了吗？"

translate chinese chinese_3601515_19:
    old "Mmm, I'm really enjoying it..."
    new "嗯，我真的很享受……"

translate chinese chinese_2252652_20:
    old "Mmm..."
    new "嗯……"

translate chinese chinese_8300714_21:
    old "All right, I think is enough."
    new "好了，我觉得够了。"

translate chinese chinese_8160727_22:
    old "So Billie? Do you like that big dick in your mouth?"
    new "那么比莉，你喜欢嘴里含着那个大鸡巴的感觉吗？"

translate chinese chinese_4534627_23:
    old "Mmmm."
    new "嗯嗯。"

translate chinese chinese_9071346_24:
    old "Yeah, I bet you do. Just enjoy it."
    new "是啊，我相信你能行的。just享受它吧。"

translate chinese chinese_9063758_25:
    old "Keep going, you have to do it well. Are you enjoying it [pla]?"
    new "继续，你得好好来。[pla]，你觉得怎么样？"

translate chinese chinese_7406803_26:
    old "Uhh... Mmm..."
    new "嗯……呣……"

translate chinese chinese_7726620_27:
    old "He's enjoying it Billie!"
    new "他在享受呢，比莉！"

translate chinese chinese_3279779_28:
    old "Gulp."
    new "咽了口唾沫。"

translate chinese chinese_0641306_29:
    old "Slurrp, I- I can feel you getting even harder."
    new "啧，我感觉你更硬了。"

translate chinese chinese_0646924_30:
    old "He's close Billie! Keep going!"
    new "他快到了，Billie！继续！"

translate chinese chinese_8443394_31:
    old "Ahhh, ahhhh!"
    new "啊hhh, 啊hhh!"

translate chinese chinese_4841151_32:
    old "That's it Billie! Just like that."
    new "就是这样，比莉！就保持这个样子。"

translate chinese chinese_5178915_33:
    old "Ahh! I- I'm cumming!"
    new "啊！我快来了！"

translate chinese chinese_0636270_34:
    old "Ugh, duuude, you came all in my mouth!"
    new "哎呀，兄弟，你全喷我嘴里了！"

translate chinese chinese_7582579_35:
    old "And Belle had already told you to be careful!"
    new "而且贝尔已经提醒你要小心了！"

translate chinese chinese_9884418_36:
    old "S- sorry, I couldn't stop myself."
    new "对不起，我忍不住。"

translate chinese chinese_4436489_37:
    old "Yeah, he does come a lot, doesn't he?"
    new "是啊，他确实来得很频繁，不是吗？"

translate chinese chinese_1579148_38:
    old "He does, anyway, help me clean myself."
    new "反正他帮我清理了一下自己。"

translate chinese chinese_0054150_39:
    old "S- sure..."
    new "好……"

translate chinese chinese_1986704_40:
    old "Oh God... [bil]..."
    new "哦，天啊……[bil]……"

translate chinese chinese_2729329_41:
    old "Mmm... you taste even better than I remembered."
    new "嗯……你尝起来比我想像的还要好吃。"

translate chinese chinese_4172726_42:
    old "This feels... insane."
    new "这感觉……简直疯了。"

translate chinese chinese_4055634_43:
    old "Good. That's the point."
    new "好。这就是重点。"

translate chinese chinese_0598264_44:
    old "A little faster now..."
    new "现在快一点..."

translate chinese chinese_4729594_45:
    old "Yes... please... don't stop."
    new "是的……求你了……不要停。"

translate chinese chinese_2659737_46:
    old "Your cock's throbbing... love feeling you like this."
    new "你的 cock 跳动着……这样感觉你真好。"

translate chinese chinese_0821825_47:
    old "Harder... give me more."
    new "再用力点……再来更多点。"

translate chinese chinese_3422727_48:
    old "[bil]... I'm close..."
    new "[bil]... 我快到了..."

translate chinese chinese_6089671_49:
    old "Yeah? Cum for me. Fill my mouth."
    new "是吗？射给我。填满我的嘴。"

translate chinese chinese_9456441_50:
    old "Oh fuck... yes!"
    new "哦fuck... 对！"

translate chinese chinese_9567069_51:
    old "I- I'm cumming—!"
    new "我—我要来了—！"

translate chinese chinese_5232005_52:
    old "Mmm... give it all to me."
    new "嗯……全都给我。"

translate chinese chinese_2484667_53:
    old "Every drop... that's it."
    new "每一滴……就这些了。"

translate chinese chinese_8893416_54:
    old "That was... wow."
    new "那个……真厉害。"

translate chinese chinese_8323168_55:
    old "Better?"
    new "好些了吗？"

translate chinese chinese_2229079_56:
    old "Uhh, yeah, definetly, t- thank you..."
    new "呃，对，肯定的，谢谢……"

translate chinese chinese_3436702_57:
    old "Alright... we should clean up this mess before my grandma walks in."
    new "好吧……我们应该在奶奶进来之前把这里收拾一下。"

translate chinese chinese_2759639_58:
    old "Yeah... good idea."
    new "嗯……好主意。"

translate chinese chinese_2918525_59:
    old "Is this okay?"
    new "这样可以吗？"

translate chinese chinese_0718896_60:
    old "Oh god, yeah... you're doing it right. Keep the technique."
    new "哦天哪，对……你做得没错。保持这个技巧。"

translate chinese chinese_0222266_61:
    old "Faster now. Rub harder."
    new "快点，再用力点。"

translate chinese chinese_7676278_62:
    old "You're so tight..."
    new "你真是个保守的人……"

translate chinese chinese_6442404_63:
    old "Deeper. D-don't stop-"
    new "更深一点。别停——"

translate chinese chinese_2013877_64:
    old "Harder! I want to feel you deeper."
    new "再用力点！我想更深地感受你。"

translate chinese chinese_4760953_65:
    old "[bil]... you're pulsing..."
    new "[bil]……你在脉动……"

translate chinese chinese_3214376_66:
    old "Yes! I'm close!"
    new "没错！我就要到了！"

translate chinese chinese_6907361_67:
    old "Oh fuck..."
    new "哦操..."

translate chinese chinese_1359745_68:
    old "Oh God... that's it."
    new "哦上帝……就这样吧。"

translate chinese chinese_1999415_69:
    old "That was... intense."
    new "那真是……激烈。"

translate chinese chinese_2849058_70:
    old "Phew... yeah, it was nice."
    new "呼……是啊，挺不错的。"

translate chinese chinese_6591207_71:
    old "Better fingers?"
    new "更灵活的手指？"

translate chinese chinese_1254206_72:
    old "Way better. Like they woke up."
    new "好太多了。就像他们刚醒来一样。"

translate chinese chinese_0358595_73:
    old "Mmm... feel better already?"
    new "嗯……感觉好些了吗？"

translate chinese chinese_0194758_74:
    old "Yeah... tension's melting away."
    new "嗯……紧张感渐渐消失了。"

translate chinese chinese_2358105_75:
    old "Good. Deeper now."
    new "好，再深一点。"

translate chinese chinese_9635394_76:
    old "Fuck... yes."
    new "妈的……是的。"

translate chinese chinese_6160531_77:
    old "Cum for me. Let it all out."
    new "为我射吧。全部释放出来。"

translate chinese chinese_6502516_78:
    old "I'm... close!"
    new "我……快到了！"

translate chinese chinese_4073953_79:
    old "Ahh— cumming!"
    new "啊— 来了！"

translate chinese chinese_7372427_80:
    old "Mmm... that's it."
    new "嗯……就是这个。"

translate chinese chinese_8079905_81:
    old "Wow... that was... intense."
    new "wow...那个...真是激烈。"

translate chinese chinese_2320402_82:
    old "Feeling better?"
    new "感觉好些了吗？"

translate chinese chinese_5153414_83:
    old "Yeah, actually. A lot. Thanks, [bil]. Didn't think it'd work that well."
    new "是的，实际上。很多。谢谢，[bil]。没想到效果这么好。"

translate chinese chinese_8731980_84:
    old "{i}I used to float... above the ground...{/i}"
    new "{i}我以前能浮在... 空中...{/i}"

translate chinese chinese_4510154_85:
    old "You're already tensing up... feel that?"
    new "你已经紧张起来了……感觉到没？"

translate chinese chinese_8298339_86:
    old "Mmm—keep it slow—notes steady... don't rush me yet..."
    new "嗯——慢慢来——节奏稳一点……别急着催我……"

translate chinese chinese_7037071_87:
    old "{i}Now every step... just pulls me down...{/i}"
    new "现在每一步……都在把我往下拉……"

translate chinese chinese_4409175_88:
    old "Heart's racing already, huh? Your voice is still holding strong."
    new "心跳已经加速了吧？你的声音还稳得很。"

translate chinese chinese_1711936_89:
    old "Yes—fuck—deeper now—everything I wanted... slips right through my hands..."
    new "是的——操——再深一点——一切我想要的……都从手中溜走了……"

translate chinese chinese_8468339_90:
    old "{i}And I’m still breathing... but I don’t... understand—{/i}"
    new "{i}我还在呼吸……但我不明白——{/i}"

translate chinese chinese_4364618_91:
    old "{i}Ahh—fuck—keep going—don't stop—{/i}"
    new "{i}啊—操—继续—别停—{/i}"

translate chinese chinese_2922073_92:
    old "You're pulsing around my fingers... you're so close, [bil]."
    new "你在我的手指间脉动着……你快到了，[bil]。"

translate chinese chinese_9316165_93:
    old "Harder—yes—right there—I'm—I'm gonna—"
    new "再用力一点—对了—就是那里—我快—"

translate chinese chinese_2115713_94:
    old "I-I'm—cumming—fuck—yes—!"
    new "我我我——来了——操——对——！"

translate chinese chinese_3614185_95:
    old "Nngh... holy shit..."
    new "嗯……天啊……"

translate chinese chinese_8921764_96:
    old "Fuuck..."
    new "fucks..."

translate chinese chinese_2414895_97:
    old "... Damn..."
    new "...该死..."

translate chinese chinese_2678267_98:
    old "Okay... that... was something else."
    new "好吧……那个……真是不同凡响。"

translate chinese chinese_8095597_99:
    old "You... held it together. Mostly."
    new "你……还算是镇定了。基本上。"

translate chinese chinese_5078793_100:
    old "Mostly? I felt the slip at the peak... but I pulled it back. That's progress."
    new "大部分时候？我觉得在高潮的时候有点滑...但我拉回来了。这是进步。"

translate chinese chinese_4536464_101:
    old "This method is insane... but it might just work."
    new "这个方法太疯狂了……但说不定还真行。"

translate chinese chinese_5653849_102:
    old "Yeah... insane in the best way."
    new "嗯……疯狂到极致。"

translate chinese chinese_8474188_103:
    old "Do you like when I ride you like this?"
    new "你喜欢我这样骑你吗？"

translate chinese chinese_5552838_104:
    old "Fuck yes... you’re perfect..."
    new "妈的，对……你太完美了……"

translate chinese chinese_6495140_105:
    old "Good boy... keep looking at me."
    new "好孩子……继续看着我。"

translate chinese chinese_6089727_106:
    old "Faster now... bounce with me."
    new "现在加快点……和我一起弹起来。"

translate chinese chinese_9229501_107:
    old "Bil... you’re gonna make me lose it..."
    new "碧尔……你再这样我会忍不住了……"

translate chinese chinese_9063810_108:
    old "Not yet. I want to feel you throb inside me."
    new "还不到时候。我想感受你在里面 pulsing。"

translate chinese chinese_3949084_109:
    old "Harder— give it to me—"
    new "再用力点——给我——"

translate chinese chinese_0672747_110:
    old "I’m so close..."
    new "我就快到了……"

translate chinese chinese_1231044_111:
    old "Inside! Cum inside me-"
    new "里面！射进去——"

translate chinese chinese_8740154_112:
    old "Yes— fill me up—!"
    new "是的——给我来满的——！"

translate chinese chinese_5419203_113:
    old "Ahh— fuck— cumming— !"
    new "啊呵——操——要来了——！"

translate chinese chinese_2360458_114:
    old "Nngh... that’s it... every drop..."
    new "嗯……就是这里……每一滴……"

translate chinese chinese_9392908_115:
    old "Mmm... good boy. That felt so damn good."
    new "嗯……好孩子。感觉真他妈的好。"

translate chinese chinese_8619944_116:
    old "That was... insane."
    new "那真是……疯狂。"

translate chinese chinese_4326386_117:
    old "Heh. Way better than any vocal warm up, right?"
    new "嘿嘿。比任何热嗓音的方法都管用，对吧？"

translate chinese chinese_9503705_118:
    old "But we gotta stop... grandma could walk in any second."
    new "但是我们得停下来……奶奶随时可能会进来。"

translate chinese chinese_4143699_119:
    old "Right, right..."
    new "嗯嗯……"

translate chinese chinese_9210522_120:
    old "Mmm... feel how soft and warm my ass is rubbing all over your hard cock?"
    new "嗯……感觉到我柔软温暖的屁股在你硬挺的家伙上摩擦吗？"

translate chinese chinese_3032970_121:
    old "Fuck... Billie... that feels incredible..."
    new "妈的...比莉...这感觉太爽了..."

translate chinese chinese_9589663_122:
    old "You're throbbing so much between my cheeks. My ass turns you on that bad, huh?"
    new "你在我的腿间 throbbing 得这么厉害。我的屁股让你这么兴奋，是吗？"

translate chinese chinese_7284473_123:
    old "Yes... don't stop..."
    new "是的……不要停……"

translate chinese chinese_2768860_124:
    old "Do you like feeling my ass? Then cum for me. I want you to finish all over it."
    new "你喜欢摸我的屁股吗？那就射吧。我想让你在上面射个够。"

translate chinese chinese_7614543_125:
    old "Oh God, Billie, don't stop..."
    new "哦上帝，比莉，不要停..."

translate chinese chinese_4485483_126:
    old "Ahh— fuck— I'm cumming—!"
    new "啊呵——操——我要射了——!"

translate chinese chinese_0388166_127:
    old "Mmm... yes, that's it. Cum all over my ass."
    new "嗯……对，就是这样。射我屁股里。"

translate chinese chinese_9375179_128:
    old "Heh... look at the mess you made on me. Someone really liked this outfit."
    new "嘿嘿……看看你在我身上弄的这一团糟。有人真的很喜欢这套衣服。"

translate chinese chinese_6766477_129:
    old "That was insane... we could've been caught..."
    new "太疯狂了……我们差点被发现了……"

translate chinese chinese_1156191_130:
    old "But we weren't. Now help me clean up before that lazy bitch looks up from her phone."
    new "但我们没有。现在帮我收拾一下，在那个懒婆娘从手机上抬起头之前。"

translate chinese chinese_1759319_131:
    old "Mmm... feel how soft and warm they are wrapping all around your cock?"
    new "嗯……感受一下它们包裹着你的硬度，又软又暖的感觉吗？"

translate chinese chinese_8898720_132:
    old "Fuck... Billie... your tits feel amazing..."
    new "妈的……比莉……你的胸部感觉太棒了……"

translate chinese chinese_3285410_133:
    old "You're throbbing so much between them. You love fucking my tits, don't you?"
    new "你在她们之间胀得这么厉害。你最喜欢插我的胸了吧？"

translate chinese chinese_5840219_134:
    old "That's it... fuck my tits harder. I want you to cum all over them."
    new "就是那样……用力揉我的胸部。我想让你射在上面。"

translate chinese chinese_9919232_135:
    old "Billie... I'm gonna cum..."
    new "比莉……我要来了……"

translate chinese chinese_5270586_136:
    old "Do it. Cover my tits. I want to feel your hot load on me."
    new "做吧。遮住我的胸部。我想感受你火热的高潮。"

translate chinese chinese_4992358_137:
    old "Ahh— fuck— I'm cumming!"
    new "啊啊—妈的—我要射了！"

translate chinese chinese_9716942_138:
    old "Mmm... yes, give it to me. Cum all over my tits."
    new "嗯……是的，给我，射在我胸口。"

translate chinese chinese_1107594_139:
    old "Heh... look at you. Made another mess on me."
    new "嘿嘿……看看你，又弄脏我一身。"

translate chinese chinese_5243684_140:
    old "Guess my tits are too much for you."
    new "看来我的胸部对你来说太夸张了。"

translate chinese chinese_9378132_141:
    old "It's nice you like them so much..."
    new "你喜欢它们这么多……挺好的……"

translate chinese chinese_9808783_142:
    old "Mmm... slow... just like this... I want to feel every inch of you."
    new "嗯……慢一点……就這樣……我想感受你的每一寸。"

translate chinese chinese_4444380_143:
    old "You feel so good... so warm..."
    new "你感觉真好……这么温暖……"

translate chinese chinese_2494819_144:
    old "Mmm... deeper... I need you inside me... all of you."
    new "嗯……再深一点……我要你进入我体内……全部。"

translate chinese chinese_9328295_145:
    old "Ahh... yes... right there..."
    new "啊……是的……就那里……"

translate chinese chinese_0015769_146:
    old "Fuck... Billie... you’re perfect."
    new "操... 比莉... 你真完美。"

translate chinese chinese_6092452_147:
    old "Don’t hold back... I want all of you tonight... I need this."
    new "别保留……今晚我要全部都要……我需要这个。"

translate chinese chinese_5821153_148:
    old "Harder... don’t stop... I want to feel you lose control..."
    new "再用力点……不要停……我想感受你失去控制的感觉……"

translate chinese chinese_2393885_149:
    old "I’m getting so close..."
    new "我快到了……"

translate chinese chinese_8739213_150:
    old "Inside me... cum inside me... I want to feel you let go completely."
    new "在我里面……射在里面……我想感受你完全释放的感觉。"

translate chinese chinese_3179289_151:
    old "Billie— I’m cumming—!"
    new "比莉——我要射了——！"

translate chinese chinese_4040091_152:
    old "Yes— fill me up... give me everything..."
    new "是的——给我灌满……全部给我……"

translate chinese chinese_7240493_153:
    old "Mmm... I can still feel you pulsing inside me..."
    new "嗯……我还能感觉到你在里面脉动……"

translate chinese chinese_3943011_154:
    old "That was... incredible."
    new "那真是……惊人。"

translate chinese chinese_5020287_155:
    old "That wasn’t everything. Tonight I don’t want to stop until you’ve given me all of you."
    new "那不是全部。今晚我要一直持续到你把一切都给了我为止。"

translate chinese chinese_5749244_156:
    old "Come here... don’t pull out yet."
    new "过来……别拔出来。"

translate chinese chinese_3610225_157:
    old "I want to feel you again... deeper this time."
    new "我想再感受一下你……这次更深一点。"

translate chinese chinese_4114946_158:
    old "Slow... just like that... I love feeling you fill me completely."
    new "慢一点……就那样……我喜欢被你完全填满的感觉。"

translate chinese chinese_6381261_159:
    old "God, Billie... you’re so tight... so warm..."
    new "天啊，比莉……你这么紧……这么暖……"

translate chinese chinese_6573329_160:
    old "Mmm... keep your eyes on me... I know how much you love looking at my tits like this."
    new "嗯……看着我……我知道你有多喜欢这样盯着我的胸部看。"

translate chinese chinese_9121160_161:
    old "Look at them bouncing for you... they’re all yours tonight."
    new "看看它们为你弹跳的样子……今晚它们全归你了。"

translate chinese chinese_3542405_162:
    old "Ahh... yes... right there... harder now..."
    new "啊……是的……就那里……现在再用力一点……"

translate chinese chinese_3111556_163:
    old "You feel amazing... I can’t get enough of you."
    new "你太棒了……我根本无法满足。"

translate chinese chinese_9168677_164:
    old "Don’t hold back... I need you to lose yourself in me tonight."
    new "别保留……今晚我要你彻底放纵自己。"

translate chinese chinese_2423428_165:
    old "Faster... fuck me harder... I want everything you have left."
    new "快点……狠狠地操我……把你剩下的全部给我。"

translate chinese chinese_7615739_166:
    old "Billie... I’m so close again..."
    new "比莉……我又这么接近了……"

translate chinese chinese_6871236_167:
    old "Then give it to me... cum inside me again... fill me up."
    new "那就给我……在里面射……填满我。"

translate chinese chinese_6361797_168:
    old "Yes— deep inside... let go... I want to feel every drop."
    new "是的——深入里面……放开……我想感受每一滴。"

translate chinese chinese_9467286_169:
    old "Mmm... I feel you throbbing again... so warm..."
    new "嗯……我觉得你又开始悸动了……好温暖……"

translate chinese chinese_6945476_170:
    old "I don’t want this night to end..."
    new "我不希望这个夜晚结束……"

translate chinese chinese_0272417_171:
    old "Neither do I."
    new "我也不。"

translate chinese chinese_5164977_172:
    old "But tomorrow is going to be a long day..."
    new "但是明天会是很长的一天……"

translate chinese chinese_3537032_173:
    old "Yeah... I know."
    new "嗯……我知道。"

translate chinese chinese_4069311_174:
    old "I hate saying it, but we both need to rest."
    new "我讨厌说这句话，但我们俩都得休息一下。"

translate chinese chinese_8325504_175:
    old "You’re right, we better get dressed in case your grandma shows up."
    new "你说得对，最好穿好衣服，以防你奶奶突然出现。"

translate chinese chinese_1174599_176:
    old "Ahh... just like that..."
    new "啊……就那样……"

translate chinese chinese_3959866_177:
    old "Focus on my mouth... nothing else matters right now."
    new "盯着我的嘴……现在其他什么都不重要。"

translate chinese chinese_0661684_178:
    old "Yes... right there... don’t stop..."
    new "是的……就那里……不要停……"

translate chinese chinese_1399206_179:
    old "You’re getting so wet... that’s it, let go."
    new "你都湿成这样了……就这样，放松点。"

translate chinese chinese_1520713_180:
    old "Harder... use your tongue... I’m so close..."
    new "再用力点……用舌头……我快来了……"

translate chinese chinese_3292780_181:
    old "Ahh— I’m— I’m cumming—!"
    new "啊—我—我要来了—!"

translate chinese chinese_3340195_182:
    old "Fuck... that actually worked..."
    new "靠……这竟然成功了……"

translate chinese chinese_8615189_183:
    old "You look a lot calmer now."
    new "你现在看起来平静多了。"

translate chinese chinese_9686955_184:
    old "I do... thank you. I really needed that."
    new "我……谢谢。我真的需要这个。"

translate chinese chinese_0583350_185:
    old "I don’t want to freak you out, but the contest already started. We gotta get on stage."
    new "我不想吓你，但比赛已经开始了，我们得上台了。"

translate chinese chinese_5652864_186:
    old "Okay, okay... yeah, I feel way better now. Let’s go."
    new "好吧，好吧……嗯，我现在感觉好多了。我们走吧。"

translate chinese chinese_4195091_187:
    old "Mmm... feel how soft they are wrapping around you?"
    new "嗯……感受一下它们包裹着你的柔软感觉吗？"

translate chinese chinese_4841394_188:
    old "Fuck... Billie... they feel perfect..."
    new "妈的……比莉……感觉完美……"

translate chinese chinese_0416729_189:
    old "You’re throbbing so much between them... you love fucking my tits, don’t you?"
    new "你在她们之间肿得那么厉害……你肯定喜欢插我的胸吧？"

translate chinese chinese_1894785_190:
    old "Yes... don’t stop..."
    new "是的……不要停……"

translate chinese chinese_9882640_191:
    old "Harder... fuck them... I want you to cum all over them."
    new "再用力点……操他们……我要你射他们一脸。"

translate chinese chinese_3628596_192:
    old "Billie... I’m so close..."
    new "比莉……我快到了……"

translate chinese chinese_9318939_193:
    old "Then do it. Cover me."
    new "那就动手吧。给我掩护。"

translate chinese chinese_2135337_194:
    old "Ahh— fuck— I’m cumming—!"
    new "啊啊—操—我要射了—!"

translate chinese chinese_9326386_195:
    old "Mmm... yes, give me every drop... paint them nice and white."
    new "嗯……是的，给我每一滴……把它们涂得白白的。"

translate chinese chinese_6897051_196:
    old "Heh... look at the mess you made."
    new "嘿嘿……看看你搞的什么 mess。"

translate chinese chinese_9194765_197:
    old "We’re not done yet."
    new "我们还没完呢。"

translate chinese chinese_7952756_198:
    old "Come here... I want you inside me again."
    new "过来……我要你再进入我体内。"

translate chinese chinese_4968084_199:
    old "Slow at first... I want to feel all of you."
    new "先慢慢来……我想感受你的一切。"

translate chinese chinese_6413735_200:
    old "Mmm... yes... just like that..."
    new "嗯……是的……就那样……"

translate chinese chinese_2774653_201:
    old "You feel so good... so tight..."
    new "你感觉真好……这么紧……"

translate chinese chinese_2119274_202:
    old "Harder... don’t hold back..."
    new "再用力点……别留情……"

translate chinese chinese_9176652_203:
    old "Billie... you’re perfect."
    new "比莉……你完美得不得了。"

translate chinese chinese_1432565_204:
    old "Fuck me... I want everything you have left..."
    new "操...我把剩下的都想要..."

translate chinese chinese_8765053_205:
    old "I’m gonna cum again..."
    new "我要再来一次了..."

translate chinese chinese_0871963_206:
    old "Inside me... fill me up one more time."
    new "在我里面……再让我满足一次。"

translate chinese chinese_6636025_207:
    old "Yes... give it all to me..."
    new "是的……全部给我……"

translate chinese chinese_9555565_208:
    old "Mmm... I can feel you... so warm inside..."
    new "嗯……我感觉到了……里面好温暖……"

translate chinese chinese_7746442_209:
    old "I don’t think I can move..."
    new "我觉得我动不了..."

translate chinese chinese_2740094_210:
    old "Then don’t. Stay right here with me."
    new "那别走，就待在我身边。"

translate chinese chinese_6404515_211:
    old "Tonight... everything feels right."
    new "今晚……一切感觉都对了。"

translate chinese chinese_6525501_212:
    old "We did it. Together."
    new "我们做到了。一起。"

translate chinese chinese_6780450_213:
    old "Yeah... we really did."
    new "嗯……我们确实做了。"

translate chinese chinese_5612961_214:
    old "({i}Tomorrow the world will keep spinning... but right now, this is all I need.{/i})"
    new "(明天世界还会继续转动……但此刻，这就够了。)"

translate chinese chinese_0247852_215:
    old "Mmm... circle my clit first. Gentle, like I showed you."
    new "嗯……先弄我的 clit，轻一点，就像我教你的那样。"

translate chinese chinese_4217922_216:
    old "Like this?"
    new "这样吗？"

translate chinese chinese_8106467_217:
    old "Deeper. Slide one in and curl it. You already know the spot."
    new "更深一点。插进去然后卷动。你已经知道那个地方了。"

translate chinese chinese_4196501_218:
    old "Add another—fuck—yes, right there. You’re getting so good at this."
    new "再加一点—妈的—对，就是那里。你越来越擅长这个了。"

translate chinese chinese_4589181_219:
    old "Harder, baby. Make me cum all over your hand."
    new "再用力点，宝贝。让我在你手上高潮。"

translate chinese chinese_2265897_220:
    old "I’m—cumming—fuck—!"
    new "我—来了—操—！"

translate chinese chinese_9866346_221:
    old "Shit... your fingers really kept perfect rhythm this time."
    new "shit... 你这次手指的节奏真的保持得很完美。"

translate chinese chinese_9923364_222:
    old "You’re getting faster and way more precise every time. I can feel it."
    new "你每次都在变快，而且准头也提高了很多。我感觉得到。"

translate chinese chinese_6061956_223:
    old "This is exactly the kind of dexterity we need... both on stage and off it."
    new "这正是我们需要的灵巧……无论是在台上还是台下。"

translate chinese chinese_8576464_224:
    old "{i}I used to float above the ground...{/i}"
    new "{i}我以前能浮在空中...{/i}"

translate chinese chinese_1354082_225:
    old "You’re already dripping..."
    new "你已经湿了……"

translate chinese chinese_3746132_226:
    old "Deeper—fuck—keep the rhythm steady."
    new "更深一点——操——保持节奏。"

translate chinese chinese_6418804_227:
    old "Faster—make me cum while I try to hold the note—ahh—!"
    new "快点——在我试着按住音符的时候让我高潮——啊h——！"

translate chinese chinese_5527705_228:
    old "I’m cumming—fuck—yes—!"
    new "我来了——操——对——！"

translate chinese chinese_6244616_229:
    old "Nngh... your tongue is getting way too good at this."
    new "嗯……你的舌头越来越熟练了。"

translate chinese chinese_4584000_230:
    old "You held me through it perfectly. That’s the kind of control I need."
    new "你完美地控制了我。这就是我需要的控制。"

translate chinese chinese_8826480_231:
    old "Every time you do this my voice gets stronger under pressure... and I get to enjoy that mouth of yours."
    new "每次你这样做的时候，我的声音都会在压力下变得更强烈……然后我就能享受你的嘴巴了。"

translate chinese chinese_2054100_232:
    old "Mmm... look at you. Already so hard just from asking."
    new "嗯……看看你。光是问一下就這麼硬了。"

translate chinese chinese_9932879_233:
    old "Billie... that feels so good..."
    new "比莉……感觉真好……"

translate chinese chinese_3086413_234:
    old "Deeper now... I want to feel every throb."
    new "更深一点……我要感受每一次的悸动。"

translate chinese chinese_2719746_235:
    old "Fuck... you’re way too good at this."
    new "妈的……你太擅长这个了。"

translate chinese chinese_2990398_236:
    old "Don’t hold back. Cum for me. Let me give you the motivation you need."
    new "别客气，为我射吧。让我给你需要的动力。"

translate chinese chinese_2161909_237:
    old "I’m— I’m close...!"
    new "我——快到了！"

translate chinese chinese_9908399_238:
    old "Mmm... every drop. Good boy."
    new "嗯……每滴都不浪费。好孩子。"

translate chinese chinese_6680547_239:
    old "Heh... feeling more motivated already?"
    new "嘿嘿……感觉更有动力了？"

translate chinese chinese_1767484_240:
    old "Your confidence always shoots up after this. I can tell."
    new "你每次之后信心都爆棚，我看得出来。"

translate chinese chinese_4924008_241:
    old "Come back whenever you need some real motivation again... I’ll be waiting."
    new "随时回来找我获取真正的动力吧……我会等着的。"

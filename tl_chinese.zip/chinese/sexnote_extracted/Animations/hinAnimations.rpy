# auto-tl Qwen Colab

translate chinese chinese_5951523_0:
    old "Little by little, you start to increase the speed..."
    new "一点点地，你开始加快速度……"

translate chinese chinese_2046864_1:
    old "You can feel his body start to tense, warm up, that means he's close..."
    new "你能感觉到他的身体开始紧张起来，变热了，这意味着他快要来了……"

translate chinese chinese_1616035_2:
    old "Ready for the shot?"
    new "准备好拍照了吗？"

translate chinese chinese_0834593_3:
    old "For what?"
    new "为了什么？"

translate chinese chinese_1208136_4:
    old "Wow! (Mmm)"
    new "哇！(嗯)"

translate chinese chinese_6191412_5:
    old "That's it! Did you like [pla]?"
    new "就是这个！你喜欢[pla]吗？"

translate chinese chinese_5484974_6:
    old "Haha. And what about you, Hinn? How was it for you?"
    new "哈哈。那你呢，Hinn？你觉得怎么样？"

translate chinese chinese_2716968_7:
    old "It was great."
    new "太棒了。"

translate chinese chinese_5428953_8:
    old "Wow, I wasn't expecting it... That was a lot."
    new "wow，我没想到会... 这也太多了吧。"

translate chinese chinese_0549252_9:
    old "A lot of cum as always, yummy"
    new "像往常一样有很多精液，真好吃"

translate chinese chinese_7595144_10:
    old "Go slowly increasing speed with me."
    new "慢慢来，和我一起加快速度。"

translate chinese chinese_5602987_11:
    old "How does it feel [pla]?"
    new "感觉如何 [pla]?"

translate chinese chinese_1737561_12:
    old "It... feels, very good..."
    new "它……感觉……非常好……"

translate chinese chinese_9150865_13:
    old "How about if we make him cum Hinn?"
    new "要不让他在里面射吧，欣？"

translate chinese chinese_0464491_14:
    old "(Oh My... Yes!)"
    new "（天啊……是的！）"

translate chinese chinese_9844436_15:
    old "I- I'm going to..."
    new "我……我要去……"

translate chinese chinese_5463198_16:
    old "Yes [pla], give us everything."
    new "好的 [pla]，告诉我们一切。"

translate chinese chinese_5919723_17:
    old "Nice!"
    new "真不错！"

translate chinese chinese_8392815_18:
    old "And it's still hard... Beautiful youth, I think we can continue with the next practice, what do you say Hinn?"
    new "而且还是硬的……美好的青春，我觉得我们可以继续下一个练习，你说呢，Hinn？"

translate chinese chinese_9625621_19:
    old "Well, you already saw me do it, in the last session, so it's your turn."
    new "好吧，你上次已经看到我做了，所以这次轮到你了。"

translate chinese chinese_0390655_20:
    old "Don't worry I will help you."
    new "别担心，我会帮你。"

translate chinese chinese_7192279_21:
    old "Remember to brush your hair very well and be careful with your teeth, ok?"
    new "记得要把头发梳好，刷牙也要小心哦？"

translate chinese chinese_0942458_22:
    old "Very well, go ahead you can do a little more..."
    new "好吧，继续，你可以再做得多一点..."

translate chinese chinese_0725823_23:
    old "You feel it in your throat right? Well now take it out slowly."
    new "你喉咙里有感觉吧？现在慢慢把它拿出来。"

translate chinese chinese_2890553_24:
    old "Great! Now keep doing it."
    new "好极了！现在继续做。"

translate chinese chinese_4792333_25:
    old "All right honey, you're doing great."
    new "好了宝贝，你做得很好。"

translate chinese chinese_4120583_26:
    old "Uh... It feels very... good."
    new "呃……感觉很……舒服。"

translate chinese chinese_6066462_27:
    old "I going to..."
    new "我要去..."

translate chinese chinese_3714921_28:
    old "And it's still hard... You know what to do Hinn... It's time to deepthroat!"
    new "而且还是硬的……你知道该怎么做，Hinn……该深喉了！"

translate chinese chinese_0090215_29:
    old "All right, how about we do it a little faster?"
    new "好吧，我们要不要快一点？"

translate chinese chinese_5322587_30:
    old "You have to learn to read your partner's expressions."
    new "你得学会读懂你搭档的表情。"

translate chinese chinese_6119113_31:
    old "Look how he starts to tense his legs, that means he is enjoying it, so, we have to do it a little faster."
    new "看他腿开始绷紧了，说明他很享受，所以我们得加快一点速度。"

translate chinese chinese_8921842_32:
    old "All right, are you ready for the shot? Get it in your mouth, so, you don't make a mess here."
    new "好了，你准备好接了吗？张开嘴，别弄得到处都是。"

translate chinese chinese_6178237_33:
    old "What?"
    new "什么？"

translate chinese chinese_8852648_34:
    old "Great Hinn!"
    new "太棒了，Hinn！"

translate chinese chinese_1003805_35:
    old "You did very well, right [pla]?"
    new "你做得很好，对吧 [pla]？"

translate chinese chinese_7276111_36:
    old "Uh?... Sorry what?"
    new "嗯？... 对不起，什么？"

translate chinese chinese_0355661_37:
    old "Hahaha, let's let [pla] to recover while I help you clean up in the bathroom."
    new "哈哈，让我们让[pla]先恢复一下，我来帮你去卫生间收拾一下。"

translate chinese chinese_2674137_38:
    old "Of course."
    new "当然。"

translate chinese chinese_6770205_39:
    old "All right, Hinn!"
    new "好吧，希恩！"

translate chinese chinese_5797565_40:
    old "She did it awesome!"
    new "她做得太棒了！"

translate chinese chinese_2090661_41:
    old "Hahaha, you are improving Hinn."
    new "哈哈，你在进步呢，Hinn。"

translate chinese chinese_5665296_42:
    old "Wow, it looks like someone was practicing the lessons at home."
    new "哇，看来有人在家里练习了这些课程啊。"

translate chinese chinese_3925686_43:
    old "All right, let's go a little faster."
    new "好吧，我们加快一点速度。"

translate chinese chinese_0565763_44:
    old "Girls, I think I'm going to..."
    new "女孩们，我想我要..."

translate chinese chinese_5110007_45:
    old "Well, it's time to fuck!"
    new "好吧，该上了！"

translate chinese chinese_4667589_46:
    old "Let me lubricate it well before I start."
    new "让我先好好润滑一下再开始。"

translate chinese chinese_6346831_47:
    old "Well I think that's enough, now you're going to penetrate Hinn..."
    new "好吧，我觉得够了，现在你要 penetrates 妙音..."

translate chinese chinese_4672594_48:
    old "Wow... Ok."
    new "wow... 好的。"

translate chinese chinese_6881564_49:
    old "Slowly and carefully..."
    new "慢慢地，小心地..."

translate chinese chinese_9760934_50:
    old "Hinn you're going to enjoy the wonder of being a woman."
    new "hin你很快就会享受到做女人的美妙了。"

translate chinese chinese_1424737_51:
    old "Ready for that big cock Hinn?"
    new "准备好接受大 cock 了没，Hinn？"

translate chinese chinese_9453189_52:
    old "All right [pla], now let's go a little faster."
    new "好了，[pla]，现在加快一点速度。"

translate chinese chinese_1438127_53:
    old "How you feeling Hinn?"
    new "你觉得怎么样，Hinn？"

translate chinese chinese_8605362_54:
    old "Oh... It feels.... Aghh... Aghhh..."
    new "哦……感觉……啊……啊……"

translate chinese chinese_4561782_55:
    old "That's what I thought..."
    new "我就知道……"

translate chinese chinese_5553870_56:
    old "Fuck her harder, make her cum with you!"
    new "操她爽一点，让她和你一起高潮！"

translate chinese chinese_4709301_57:
    old "Get it out, get it out, come in my mouth!"
    new "射出来，射出来，到我嘴里来！"

translate chinese chinese_8230783_58:
    old "Ohh yeah, yummy...."
    new "哦哦，真好吃……"

translate chinese chinese_3500008_59:
    old "He is going to cum..."
    new "他要射了..."

translate chinese chinese_1066009_60:
    old "Then, let's do it faster..."
    new "那我们就快点做吧..."

translate chinese chinese_1554663_61:
    old "Good girl."
    new "好姑娘。"

translate chinese chinese_0914440_62:
    old "All right is time to fuck!"
    new "好了，是时候了！"

translate chinese chinese_6848202_63:
    old "Very well [pla], you already know what to do..."
    new "好吧，[pla]，你已经知道该怎么做……"

translate chinese chinese_7737604_64:
    old "Do you like this [pla]? Do you like my tits on your face?"
    new "你喜欢这样吗？喜欢我的胸部贴在你脸上吗？"

translate chinese chinese_0110816_65:
    old "(Hell yeah!)"
    new "（太棒了！）"

translate chinese chinese_1774578_66:
    old "Yeah! yeah! Let's fuck Hinn harder!"
    new "yeah! yeah! 我们狠狠地干 Hin 吧！"

translate chinese chinese_3229936_67:
    old "Are you enjoying it Hinn? Yes? Do you like [pla]'s cock?"
    new "你在享受吗，Hinn？是吗？你喜欢[pla]的棒棒吗？"

translate chinese chinese_5204490_68:
    old "Oh, yess... Aghhh... Aghhh..."
    new "哦，是的……啊……啊……"

translate chinese chinese_0659384_69:
    old "Are you going to cum [pla]? Oh yeah? Cum inside her..."
    new "你要射了吗，[pla]？哦，是吗？在里面射……"

translate chinese chinese_6410480_70:
    old "Ohh! Fuck yeahh..."
    new "哦哦！太棒了……"

translate chinese chinese_7504579_71:
    old "Delicious!"
    new "美味极了！"

translate chinese chinese_3802784_72:
    old "You are doing it great!"
    new "你做得很好！"

translate chinese chinese_7009601_73:
    old "Speed it up a little."
    new "快一点。"

translate chinese chinese_3825389_74:
    old "Look at her [pla], she is enjoying your cock."
    new "看看她的[pla]，她很享受你的鸡巴。"

translate chinese chinese_2961414_75:
    old "Are you cumming hin?"
    new "你要射了吗？"

translate chinese chinese_1551460_76:
    old "Oh please, don't stop, do it faster! I'm going to cum!"
    new "哦请不要停，再快一点！我要高潮了！"

translate chinese chinese_7886190_77:
    old "Wow... That was awesome..."
    new "哇……太棒了……"

translate chinese chinese_9536572_78:
    old "Ohh, I think it's the perfect opportunity, for the last lesson."
    new "哦，我觉得这是最后课程的完美机会。"

translate chinese chinese_3815796_79:
    old "Get a good facial..."
    new "来个好的面部..."

translate chinese chinese_7333166_80:
    old "Now let's ger a good facial Hinn."
    new "现在让我们来个特写吧， hin。"

translate chinese chinese_6276320_81:
    old "Look at her eyes [pla], she wants all your cum."
    new "看看她的眼睛[pla]，她想要你的所有精液。"

translate chinese chinese_6217999_82:
    old "Does it feel good? Do you want to cum on that pretty face?"
    new "感觉好吗？你想射在那张漂亮脸上吗？"

translate chinese chinese_1170673_83:
    old "Get ready for the shot honey, he is ready."
    new "准备好接吻吧宝贝，他已经准备好了。"

translate chinese chinese_1060424_84:
    old "Give it to her! Cum on Hinn face!"
    new "给她来吧！射到Hinn脸上！"

translate chinese chinese_9390474_85:
    old "Ohh yes... Delicious..."
    new "哦哦，是的……美味……"

translate chinese chinese_6115614_86:
    old "Wow Hinn, I'm going to..."
    new "wow Hinn，我要..."

translate chinese chinese_1562879_87:
    old "Wow, that was awesome..."
    new "哇，真棒……"

translate chinese chinese_5946750_88:
    old "I didn't say it's over. You just enjoy..."
    new "我没说结束。你就好好享受……"

translate chinese chinese_4350664_89:
    old "... WOW!"
    new "... 哇！"

translate chinese chinese_0940521_90:
    old "Hinn, again I'm going to..."
    new "hin, 我又要..."

translate chinese chinese_9231723_91:
    old "Aghhh..."
    new "啊……"

translate chinese chinese_1961971_92:
    old "That was fun..."
    new "那真好玩……"

translate chinese chinese_0500018_93:
    old "That... Was... Surprising."
    new "那……真是……出乎意料。"

translate chinese chinese_0508225_94:
    old "That was great."
    new "真不错。"

translate chinese chinese_2415140_95:
    old "It has a very nice smell."
    new "味道很好闻。"

translate chinese chinese_1985438_96:
    old "Mmm, [pla] I really like your penis, it's soo nice."
    new "嗯，[pla] 我真的很喜欢你的丁丁，好棒哦。"

translate chinese chinese_7086664_97:
    old "Just relax, I'll make you feel good."
    new "放松点，我会让你感觉很好的。"

translate chinese chinese_2505246_98:
    old "Slurrp, Yes, I see you like that."
    new "啧，我知道你喜欢那样。"

translate chinese chinese_1329274_99:
    old "I love the taste of you dick! I love how it feels in my mouth!"
    new "我爱你的滋味！我喜欢它在我嘴里感觉！"

translate chinese chinese_4441503_100:
    old "I'll do it a little bit faster."
    new "我做得快一点。"

translate chinese chinese_2155988_101:
    old "(Hmm, they look like they're having fun. I better leave, I don't want them to know I saw them.)"
    new "（嗯，他们看起来玩得很开心。我还是离开吧，不想让他们知道我看到了。）"

translate chinese chinese_9060219_102:
    old "For now..."
    new "暂时……"

translate chinese chinese_9610544_103:
    old "Uhhh, I can feel how your body tense up!"
    new "呃，我能感觉到你的身体绷紧了！"

translate chinese chinese_4917702_104:
    old "H- Hinn. Mmm!"
    new "希- 希嗯。唔！"

translate chinese chinese_1800563_105:
    old "Mmmm! Yes, Yes!"
    new "嗯！对，对！"

translate chinese chinese_2647102_106:
    old "H-Hinn, I c- can't hold back anymore."
    new "希、希音，我忍不了了。"

translate chinese chinese_9331935_107:
    old "F- Finish, cum in my mouth!"
    new "快点，射到我嘴里！"

translate chinese chinese_4521904_108:
    old "I want you to!"
    new "我要你做！"

translate chinese chinese_1841031_109:
    old "Ughh, Y- YES!"
    new "呃，好、好！"

translate chinese chinese_4341444_110:
    old "Phew! That was great. Did you like it [pla]?"
    new "呼！真不错。你觉得怎么样，[pla]？"

translate chinese chinese_7980718_111:
    old "Y- yeah, I did, thank you Hinn."
    new "嗯，是我做的，谢谢你，Hinn。"

translate chinese chinese_5160926_112:
    old "Well, I'm glad you enjoyed it."
    new "好吧，我很高兴你喜欢。"

translate chinese chinese_4319327_113:
    old "Although now I'm covered with cum."
    new "虽然现在我全身都是精液。"

translate chinese chinese_7360694_114:
    old "Sorry about that."
    new "对不起。"

translate chinese chinese_2648222_115:
    old "It's ok, I wanted to do that with you. Besides, we're in the bathroom."
    new "没关系，我本来就想和你这么做。再说，我们在洗手间。"

translate chinese chinese_8395857_116:
    old "Help me clean up."
    new "帮我收拾一下。"

translate chinese chinese_2347538_117:
    old "Mmm! It's been a while..."
    new "嗯！好久不见了……"

translate chinese chinese_3861807_118:
    old "Ah! Oh yes! I've missed this..."
    new "啊！哦，是的！我想念这个……"

translate chinese chinese_3245699_119:
    old "Ohh God!"
    new "哦天啊！"

translate chinese chinese_5523563_120:
    old "Ahh! It's so big! and It feels so good!"
    new "啊！好大！感觉好棒！"

translate chinese chinese_1228360_121:
    old "Ah! Ah! I love to feel you inside [pla]!"
    new "啊！啊！我喜欢你在里面的感觉[pla]！"

translate chinese chinese_6381128_122:
    old "Y- your cock is just the best!"
    new "你这家伙，真棒！"

translate chinese chinese_4998259_123:
    old "I- I just love to have sex with you!"
    new "我我我只是爱你和我做爱的感觉！"

translate chinese chinese_1843945_124:
    old "AHH! AHH! YES! YES!"
    new "啊！啊！是的！是的！"

translate chinese chinese_3232435_125:
    old "I love the way you always make me feel!"
    new "我爱死你总是让我这种感觉了！"

translate chinese chinese_4966174_126:
    old "I LOVE IT!"
    new "我爱死这个了！"

translate chinese chinese_0601498_127:
    old "I want to keep doing it with you!"
    new "我想继续和你做这个！"

translate chinese chinese_1230599_128:
    old "H- Hinn! I- I think I'm about to...!"
    new "希- 希音！我- 我要...！"

translate chinese chinese_8440730_129:
    old "Ohh, yes yes!"
    new "哦，对对！"

translate chinese chinese_2267213_130:
    old "I want you to cum inside me!"
    new "我要你在里面射！"

translate chinese chinese_9377299_131:
    old "Wow... That felt great."
    new "哇……那感觉真棒。"

translate chinese chinese_8321646_132:
    old "Did you enjoy it too [pla]?"
    new "你也很享受吧，[pla]？"

translate chinese chinese_5008228_133:
    old "O- of course, it was really good."
    new "奥——当然，真的很好。"

translate chinese chinese_2571446_134:
    old "What the hell is this?!!!"
    new "这到底是什么玩意儿?!?!"

translate chinese chinese_9294662_135:
    old "Hinn! [pla]! What do you think you're doing?!"
    new "希恩！[pla]！你在干什么？！"

translate chinese chinese_9405214_136:
    old "Mmm! I just love the way your cock tastes."
    new "嗯！我就喜欢你那个味道。"

translate chinese chinese_3941606_137:
    old "It really is great. I can't get over it."
    new "真的太好了，我简直无法相信。"

translate chinese chinese_5794581_138:
    old "I love how it fills my mouth!"
    new "我爱这种充满嘴的感觉！"

translate chinese chinese_2868582_139:
    old "Are you enjoying it [pla]?"
    new "你在享受这个过程吗，[pla]？"

translate chinese chinese_4435371_140:
    old "Ugh! Y- yes!"
    new "呃！好！好！"

translate chinese chinese_9310365_141:
    old "M- me too! I love your cock!"
    new "我也是！我爱你的鸡巴！"

translate chinese chinese_0472552_142:
    old "I- it's so hot!"
    new "我—好热啊！"

translate chinese chinese_2354350_143:
    old "Honestly, I swear I don't understand what's going on in that girl's head sometimes."
    new "说实话，我发誓有时候真的搞不懂那个女孩在想什么。"

translate chinese chinese_5383658_144:
    old "Where did she take off too? They're not in her room."
    new "她跑到哪里去了？他们不在她的房间里。"

translate chinese chinese_1702061_145:
    old "And would you look at that? She left the bathroom light on!"
    new "你看，她还把浴室的灯留着呢！"

translate chinese chinese_5583006_146:
    old "I swear to God..."
    new "我发誓……"

translate chinese chinese_3946926_147:
    old "(Oh my God! What are they doing?! Again?!)"
    new "（天啊！他们在干什么？！又来？！）"

translate chinese chinese_5215101_148:
    old "(And in the bathroom of all places! These kids don't understand what shame is!)"
    new "（竟然还在洗手间里！这些孩子根本不懂什么叫羞耻！）"

translate chinese chinese_3605978_149:
    old "(And [pla]! My God! He's really big!)"
    new "（而且[pla]！天啊！他真的很大！）"

translate chinese chinese_5410968_150:
    old "(I can't believe that young man is like that.... Amazing.)"
    new "(真不敢相信那小子会是那样的……真不可思议。)"

translate chinese chinese_6910486_151:
    old "(I- is Hinn really putting all that in her mouth?)"
    new "（希恩真的把她嘴里塞那么多东西吗？）"

translate chinese chinese_0241542_152:
    old "(I- I can't believe it.)"
    new "（我——不敢相信。）"

translate chinese chinese_5129339_153:
    old "Slrrrrp! Mmmm! Y- Yeah! I- I love your cock!"
    new "slurp! 哼哼！嗯——嗯！我——我爱你的棒！"

translate chinese chinese_7137802_154:
    old "I- it barely fits in my mouth!"
    new "我——它差点就塞不进去了！"

translate chinese chinese_4163915_155:
    old "It's so amazing!"
    new "太棒了！"

translate chinese chinese_9283261_156:
    old "(S- she's actually putting all of it in her mouth!)"
    new "（她真的全塞进嘴里了！）"

translate chinese chinese_5015088_157:
    old "(I can't believe what I'm seeing!)"
    new "（我简直不敢相信我看到的！）"

translate chinese chinese_9869975_158:
    old "(H- he's not going to cum in her mouth, right?)"
    new "（他不会射在她嘴里吧？）"

translate chinese chinese_3350428_159:
    old "H- Hinn... I- I think I'm about to!"
    new "希- 希妮... 我- 我觉得我要来了！"

translate chinese chinese_7221105_160:
    old "YES! CUM IN MY MOUTH!"
    new "YES! 在我嘴里射吧！"

translate chinese chinese_0224885_161:
    old "(I can't believe Hinn is saying that kind of stuff!)"
    new "(真不敢相信希恩会说出这种话！)"

translate chinese chinese_4933076_162:
    old "(I- is he going to do it?)"
    new "（他-他会这么做吗？）"

translate chinese chinese_0589010_163:
    old "(My God, kids these days, honestly...)"
    new "（天啊，现在的孩子们，真是的...）"

translate chinese chinese_4381467_164:
    old "(And they even say they're not a couple.)"
    new "（他们还说自己不是情侣。）"

translate chinese chinese_6702652_165:
    old "(I guess this is alright. I won't say anything for now, but Hinn really needs to learn to do it in her bedroom.)"
    new "（我想这还行吧。我先不说了，但Hinn真的需要学会去卧室里做这件事。）"

translate chinese chinese_4828803_166:
    old "Hngh!! Oh yes!"
    new "嗯！！哦 yeah！"

translate chinese chinese_3474380_167:
    old "That's what I've been waiting for!"
    new "这正是我等待的！"

translate chinese chinese_8234931_168:
    old "I just love how you fill me up!"
    new "我就是喜欢你让我感到充实的感觉！"

translate chinese chinese_1459982_169:
    old "Oh! [pla]! Your cock is so big!"
    new "哦！[pla]！你的屌好大！"

translate chinese chinese_9157668_170:
    old "Are you enjoying it?"
    new "你觉得怎么样？"

translate chinese chinese_2225891_171:
    old "Mmm, y- yes!"
    new "嗯，是的！"

translate chinese chinese_5080440_172:
    old "I- I'm loving it!"
    new "我—我超爱的！"

translate chinese chinese_6618497_173:
    old "Uhh... What is that noise?"
    new "呃……那是什么声音？"

translate chinese chinese_8918255_174:
    old "(I can't believe they're doing it again!)"
    new "(真不敢相信他们又要来了！)"

translate chinese chinese_5515400_175:
    old "(But well, at least they're doing it privately.)"
    new "（不过好在他们至少是在私下里做。）"

translate chinese chinese_2855613_176:
    old "Oh, my God! I- I can't help myself..."
    new "哦，天哪！我—我控制不住自己..."

translate chinese chinese_7997760_177:
    old "D- do it faster [pla]!"
    new "D- 快点做 [pla]！"

translate chinese chinese_4458104_178:
    old "(H- he's so big! I- I wonder how it must feel to be penetrated by him...)"
    new "（他好大！被他那样肯定感觉...）"

translate chinese chinese_0300388_179:
    old "AH! AH! AH! YES! YES!"
    new "啊！啊！啊！是的！是的！"

translate chinese chinese_8010603_180:
    old "I've been missing this so much!"
    new "我好想这个啊！"

translate chinese chinese_4993352_181:
    old "(Mmmm, and she's taking all of it!)"
    new "（嗯哼，她全都要了！）"

translate chinese chinese_6342969_182:
    old "I love how you fuck me!"
    new "我爱你怎么干我！"

translate chinese chinese_2064290_183:
    old "(H- he won't cum inside of her... Will he?)"
    new "（他不会在里面射吧……会吗？）"

translate chinese chinese_4803358_184:
    old "I- I want you to cum inside!"
    new "我……我要你在里面射！"

translate chinese chinese_2646771_185:
    old "Let me get it all!"
    new "让我全都要了！"

translate chinese chinese_4539265_186:
    old "Y- yes! I- I'm about to...!"
    new "是的！我快要……！"

translate chinese chinese_3512756_187:
    old "(God! I can't believe I just watched them have sex!)"
    new "（天啊！我真不敢相信我刚看了他们做爱！）"

translate chinese chinese_8047225_188:
    old "(But this time they did it in Hinn's bedroom, I'm the one who shouldn't be here spying on them.)"
    new "（但这次他们在Hinn的卧室里做了，我不该在这里偷看他们。）"

translate chinese chinese_1954395_189:
    old "That was so good [pla]."
    new "那真是太好了，[pla]。"

translate chinese chinese_4716854_190:
    old "It felt like an eternity since the last time we did it."
    new "感觉自从上次做那事后，已经过了很久了。"

translate chinese chinese_2014927_191:
    old "Yeah..."
    new "嗯……"

translate chinese chinese_5010096_192:
    old "By the way, it's getting kinda late, I guess my mom will be here any minute."
    new "对了，都挺晚了，我想我妈妈马上就会到。"

translate chinese chinese_1667043_193:
    old "You're right! I guess we better get dressed soon!"
    new "你说得对！我想我们还是赶紧穿衣服吧！"

translate chinese chinese_9099764_194:
    old "(I should leave before they find out I'm here.)"
    new "（我应该在他们发现我在这里之前离开。）"

translate chinese chinese_2263115_195:
    old "Oh God, what is happening to me?"
    new "哦上帝，我这是怎么了？"

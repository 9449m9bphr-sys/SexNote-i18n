# auto-tl Qwen Colab

translate chinese chinese_2043219_0:
    old "Mmm, I love how it tastes."
    new "嗯，我爱这种味道。"

translate chinese chinese_7610622_1:
    old "Your dick is so big."
    new "你的 dicks 如此之大。  \n\n请注意，这段翻译保持了原文的直接性，但在实际的成人内容本地化中，可能会根据目标市场的文化习惯进行适当的调整。不过，根据您的指示，我保留了原始的直接表达。"

translate chinese chinese_7388926_2:
    old "And you’re so hard."
    new "你真够硬的。"

translate chinese chinese_4631561_3:
    old "Sluurp! Are you enjoying it?"
    new "slurp! 你觉得怎么样？"

translate chinese chinese_7063869_4:
    old "Mmm...  I guess. it’s a bit weird with Ruby’s body though."
    new "嗯……我猜是这样。不过用露比的身体感觉有点奇怪。"

translate chinese chinese_8732801_5:
    old "Your dick, it’s twitching."
    new "你的 dicks 在动。"

translate chinese chinese_6257465_6:
    old "Mmm! And it’s so tasty, I love it!"
    new "嗯！而且这么好吃，我爱死它了！"

translate chinese chinese_8952637_7:
    old "Yes, Yes! I love this feeling in my mouth!"
    new "是的，是的！我喜欢这种嘴里的感觉！"

translate chinese chinese_6370078_8:
    old "I can feel your body tensing up!"
    new "我能感觉到你的身体在紧张！"

translate chinese chinese_1012707_9:
    old "T- This is, aaah!"
    new "这、这是，啊啊！"

translate chinese chinese_5015230_10:
    old "Yes! Yes! Do it!"
    new "是的！是的！就这样做！"

translate chinese chinese_6617003_11:
    old "Give me that magic power!"
    new "把那个魔力给我！"

translate chinese chinese_1504539_12:
    old "Oh wow! You’d given me magic before, but this is way different!"
    new "哦 wow！你之前给我施过魔法，但这次完全不一样！"

translate chinese chinese_7149415_13:
    old "Human bodies are amazing. It feels so different."
    new "人体真是奇妙。感觉完全不同。"

translate chinese chinese_2900233_14:
    old "It didn’t feel bad before, it’s just so... weird!"
    new "之前感觉还好，就是现在觉得……好诡异！"

translate chinese chinese_0664203_15:
    old "Hmm... Yeah, sure."
    new "嗯……好吧。"

# auto-tl Qwen Colab

translate chinese chinese_1622303_0:
    old "Oh yeah! This is just magical!"
    new "哦 yeah！这真是太神奇了！"

translate chinese chinese_4703148_1:
    old "I love that you're watching me, Daddy!"
    new "我好喜欢你看着我，爸爸！"

translate chinese chinese_1341837_2:
    old "I miss your dick so much!"
    new "我好想你的棒棒啊！"

translate chinese chinese_1596123_3:
    old "Do you like to see me touching my pussy?"
    new "你喜欢看我摸自己的下体吗？"

translate chinese chinese_5117471_4:
    old "Oh yeah baby! I love it!"
    new "哦 yeah 宝贝！我爱死这个了！"

translate chinese chinese_7620234_5:
    old "I can't wait to fuck your pussy myself!"
    new "我迫不及待想亲自操你的屄了！"

translate chinese chinese_9518127_6:
    old "Oh daddy! It feels as if you were here!"
    new "哦爸爸！感觉你就在身边一样！"

translate chinese chinese_9934454_7:
    old "I can't get enough of this!"
    new "我根本停不下来！"

translate chinese chinese_0013712_8:
    old "I want more and more!"
    new "我要更多更多！"

translate chinese chinese_7331486_9:
    old "I- I'm about to cum honey!"
    new "我快来了，宝贝！"

translate chinese chinese_3486364_10:
    old "Do it! I'm about to cum too!"
    new "来吧！我也快了！"

translate chinese chinese_3660681_11:
    old "Oh yeah! Let's do it together!"
    new "哦耶！我们一起做吧！"

translate chinese chinese_7304085_12:
    old "Oh that was magical honey."
    new "哦，那是魔法治愈蜜。"

translate chinese chinese_4962219_13:
    old "I can't wait to see you again to feel you inside me."
    new "我迫不及待想再见到你，感受你的存在。"

translate chinese chinese_3129131_14:
    old "Oh yeah, I can't wait to fuck you too."
    new "哦 yeah，我等不及要操你了。"

translate chinese chinese_3804143_15:
    old "{i}(I- is that [pla]? What's he doing there?!!){/i}"
    new "({i}那- 那是[pla]吗？他怎么会在那里！！{/i})"

translate chinese chinese_2701951_16:
    old "Is everything alright? You just got quiet all of a sudden."
    new "没事吧？你突然就安静了。"

translate chinese chinese_1195229_17:
    old "What?! Oh yeah!"
    new "什么?! 对了!"

translate chinese chinese_5180462_18:
    old "It's just that I think I heard some steps in the hallway."
    new "我只是觉得我听到走廊里有脚步声。"

translate chinese chinese_5506261_19:
    old "Maybe we should end the call here honey, in case one of the girls comes in."
    new "亲爱的，也许我们该在这儿结束通话了，万一有个女孩进来就不好了。"

translate chinese chinese_7155615_20:
    old "Hmph, yeah you're right."
    new "哼，你说得对。"

translate chinese chinese_0498193_21:
    old "Talk to you later then."
    new "那回头聊。"

translate chinese chinese_0561533_22:
    old "Bye honey, I love you."
    new "拜拜宝贝，我爱你。"

translate chinese chinese_4934855_23:
    old "Hey, you! I already saw you there peeping, come in here and close the door behind you!"
    new "喂，你！我看到你在偷看了，进来把门关上！"

# auto-tl Qwen Colab

translate chinese chinese_5941059_0:
    old "Uhmm... I- I don't think that was in the script Barbie."
    new "嗯……巴比，我觉得这不在剧本里。"

translate chinese chinese_2560317_1:
    old "B- barbie! I- I'm about to...!"
    new "巴- 巴比！我快...！"

translate chinese chinese_5535446_2:
    old "Yeah... I'm glad."
    new "是啊……我很高兴。"

translate chinese chinese_5996329_3:
    old "But I wasn't expecting that."
    new "但我没想到会是那样。"

translate chinese chinese_1828743_4:
    old "Maybe you should be careful when you drink..."
    new "maybe你喝酒的时候应该小心点..."

translate chinese chinese_7033510_5:
    old "I- I do!"
    new "我——我有！"

translate chinese chinese_4513548_6:
    old "B- barbie I- I can't hold it in anymore!"
    new "巴- 巴比，我- 我忍不住了！"

translate chinese chinese_6886419_7:
    old "Uhmm, yeah... But we really can't right now."
    new "嗯，是啊……但是我们现在真的不行。"

translate chinese chinese_2571898_8:
    old "So how about you get up? So I can get my pants up."
    new "那你起来吧，让我把裤子提上去。"

translate chinese chinese_4155671_9:
    old "B- Barbie! I- I'm about to cum!"
    new "巴- 巴比！我快来了！"

translate chinese chinese_5609042_10:
    old "[pla]? What are you doing here?"
    new "[pla]？你在这里干什么？"

translate chinese chinese_7181553_11:
    old "Are you here to see somebody?"
    new "你是来看某人的吗？"

translate chinese chinese_1357446_12:
    old "Is Hinn with you?"
    new "hinн和你在一起吗？"

translate chinese chinese_3944281_13:
    old "D- Dr. Johnson! H- hi!"
    new "乔翰森博士！嗨！"

translate chinese chinese_1184744_14:
    old "N- no, I'm not here with anybody."
    new "不，我一个人来的。"

translate chinese chinese_9523841_15:
    old "I- uh- Ugh-"
    new "我—呃—哎—"

translate chinese chinese_1837004_16:
    old "I'm here to deal with some things of my own!"
    new "我来这里是要处理一些自己的事情！"

translate chinese chinese_8671763_17:
    old "Why are you panting?"
    new "你为什么喘得这么厉害？"

translate chinese chinese_0442804_18:
    old "I see you have your business in something here."
    new "我看到你在这里有些事情要处理。"

translate chinese chinese_8786134_19:
    old "I- I'll let you be."
    new "我- 我让你安静一会儿。"

translate chinese chinese_0069561_20:
    old "Have fun..."
    new "玩得开心点……"

translate chinese chinese_2078133_21:
    old "B- Barbie! You have to stop!"
    new "B- Barbie！你得停下来！"

translate chinese chinese_8185511_22:
    old "Someone already saw us!"
    new "已经有人看到我们了！"

translate chinese chinese_6373761_23:
    old "What are you talking about!"
    new "你在说什么！"

translate chinese chinese_0822892_24:
    old "I'm sure Dr. Johnson caught us!"
    new "我敢肯定约翰逊博士看到我们了！"

translate chinese chinese_5683912_25:
    old "What if she says something to the building administrators?!"
    new "要是她跟管理员说了怎么办？！"

translate chinese chinese_0370680_26:
    old "Barbie I-!"
    new "芭比我-!"

translate chinese chinese_2155017_27:
    old "B- Barbie - I feel like I'm cumming!"
    new "巴比，我觉得我要射了！"

translate chinese chinese_1424730_28:
    old "I- I'm glad you enjoyed it."
    new "我——我很高兴你喜欢。"

translate chinese chinese_5636329_29:
    old "But hey, what do you say we get up and get dressed?"
    new "不过，你说我们起来穿衣服怎么样？"

# auto-tl Qwen Colab

translate chinese chinese_3646157_0:
    old "Give me that big cock..."
    new "给我那大鸡巴..."

translate chinese chinese_3126450_1:
    old "Oh my, you've definitely grown a lot! "
    new "哦我的天，你确实长大了好多！"

translate chinese chinese_5048509_2:
    old "Uhh, it feels so warm and hard."
    new "嗯，感觉好温暖好硬。"

translate chinese chinese_7706854_3:
    old "Y- yes it feels nice too."
    new "嗯，感觉也挺好的。"

translate chinese chinese_3256798_4:
    old "What about if you cum for mommy?"
    new "如果你为妈妈高潮呢？"

translate chinese chinese_2334626_5:
    old "Mrs. W- white I- I-"
    new "怀特太太……我……我……"

translate chinese chinese_8707908_6:
    old "Ohh, yeah baby..."
    new "噢，对了宝贝..."

translate chinese chinese_3518939_7:
    old "Give it to mommy!"
    new "给妈妈吧！"

translate chinese chinese_6755415_8:
    old "I have to say, [pla], you have a wonderful cock."
    new "我得说，[pla]，你的鸡巴真棒。"

translate chinese chinese_1438975_9:
    old "Uhh... T-thanks..."
    new "呃……谢谢……"

translate chinese chinese_8721416_10:
    old "Wow! Mrs. White, w- what are you doing?"
    new "哇！怀特夫人，你你在干什么？"

translate chinese chinese_3575335_11:
    old "Just enjoy it baby... Mommy is gonna blow your mind..."
    new "宝贝，just享受它吧……妈妈要让你高潮了……"

translate chinese chinese_4520384_12:
    old "(Holly shit!)"
    new "（天呐！）"

translate chinese chinese_8518837_13:
    old "Oh God, you got a huge cock..."
    new "哦天，你这根巨棒..."

translate chinese chinese_8646966_14:
    old "It hardly fits in my mouth."
    new "简直塞不进嘴里。"

translate chinese chinese_8048306_15:
    old "Do you want to cum in my mouth?"
    new "你想在我嘴里射吗？"

translate chinese chinese_1704997_16:
    old "I wanna taste it!"
    new "我想尝尝！"

translate chinese chinese_0045515_17:
    old "Oh yeah, cum for mommy!"
    new "哦 yeah，为妈妈射吧！"

translate chinese chinese_5455965_18:
    old "Give me all that cum baby."
    new "把所有的精液都给我，宝贝。"

translate chinese chinese_2457133_19:
    old "By the way, you haven't said anything about the food. Are you liking it?"
    new "对了，你还没说食物怎么样呢。你觉得好吃吗？"

translate chinese chinese_5309758_20:
    old "Oh... yes ma'am, I- I like it... a lot."
    new "哦……是的，我很——很喜欢……"

translate chinese chinese_9377151_21:
    old "It makes me so happy to hear you say that."
    new "听到你这么说真让我开心。"

translate chinese chinese_1047479_22:
    old "I made everything with my... hands, after all."
    new "这些东西都是我……亲手做的。"

translate chinese chinese_0425243_23:
    old "Yes, It's really good mom, thank you."
    new "是的，真的很不错，妈妈，谢谢。"

translate chinese chinese_5023204_24:
    old "I see you're enjoying it a lot, right [pla]?"
    new "我看得出来你很享受呢，对吧[pla]？"

translate chinese chinese_8794939_25:
    old "Mmm... Y- yes ma'am, I- I like it a lot!"
    new "嗯……是的，我很喜欢！"

translate chinese chinese_8209759_26:
    old "Well, have as much as you like."
    new "好吧，你想怎么来就怎么来。"

translate chinese chinese_6414535_27:
    old "You can ask me for more whenever you want to."
    new "你想什么时候再要更多都可以问我。"

translate chinese chinese_3465869_28:
    old "Yeah, I think I would like to repeat."
    new "是的，我想我愿意再来一次。"

translate chinese chinese_7828384_29:
    old "Look at that [pla], you're almost done!"
    new "看看那个[pla]，你快搞定了！"

translate chinese chinese_3610626_30:
    old "Would you finish for me?"
    new "你能帮我搞定吗？"

translate chinese chinese_7080100_31:
    old "Mmm... Yes Mrs. White..."
    new "嗯……是的，怀特夫人……"

translate chinese chinese_7638189_32:
    old "Well, it looks like you're done, did you enjoy it [pla]?"
    new "好吧，看起来你已经结束了，[pla]，你玩得开心吗？"

translate chinese chinese_7301136_33:
    old "Y- yes Mrs. White, it was very pleasing."
    new "是的，怀特夫人，非常愉快。"

translate chinese chinese_3870816_34:
    old "What? But he hasn't finished his food... Why do you say he is done?"
    new "什么？但他还没吃完……为什么你说他吃完了？"

translate chinese chinese_5252133_35:
    old "Trust me honey, [pla] is completely satisfied."
    new "相信我亲爱的，[pla] 完全满意了。"

translate chinese chinese_3560989_36:
    old "Anyway, Mike, please take the dishes to the kitchen."
    new "总之，迈克，请把碗碟拿到厨房去。"

translate chinese chinese_9746068_37:
    old "Hmm, sure."
    new "嗯，好吧。"

translate chinese chinese_2451935_38:
    old "Mmm, yes, this big dick."
    new "嗯，对，这个大棒。"

translate chinese chinese_9480055_39:
    old "It tastes so good in my mouth."
    new "味道好极了。"

translate chinese chinese_7989701_40:
    old "Just relax and enjoy it, like I'm enjoying it."
    new "放松点，享受它，就像我一样享受。"

translate chinese chinese_2816897_41:
    old "God! I swear it's getting even bigger!"
    new "天啊！我发誓它还在变大！"

translate chinese chinese_0927643_42:
    old "This is just what I wanted!"
    new "这正是我想要的！"

translate chinese chinese_7662733_43:
    old "Are you enjoying it [pla]?!"
    new "你爽吗，[pla]！？"

translate chinese chinese_2538633_44:
    old "Y- Yes ma'am!"
    new "是的，长官！"

translate chinese chinese_9774242_45:
    old "Yes! Shove that dick down my throat!!"
    new "没错！把它塞进我的喉咙里！！"

translate chinese chinese_8995694_46:
    old "Push it!"
    new "推进一下！"

translate chinese chinese_3979424_47:
    old "Yes, fuck my mouth like that..."
    new "是的，就这样舔我的嘴..."

translate chinese chinese_3102155_48:
    old "Don't come yet! I want it a little longer!"
    new "别来！我还想要久一点！"

translate chinese chinese_6194877_49:
    old "M- Mrs. White! I can't hold it anymore!"
    new "白太太！我忍不住了！"

translate chinese chinese_6938456_50:
    old "Mmmm! It's ok, you can cum!"
    new "嗯嗯！没事，你可以射了！"

translate chinese chinese_6925184_51:
    old "Cum for mommy!"
    new "为妈妈射吧！"

translate chinese chinese_3630536_52:
    old "Give me all your load!"
    new "把所有的东西都给我！"

translate chinese chinese_8497156_53:
    old "Mmm, I love your cum."
    new "嗯，我爱你的精液。"

translate chinese chinese_8778900_54:
    old "It's like a very nice, hot, sweet treat!"
    new "就像一个非常棒的热甜品！"

translate chinese chinese_7747553_55:
    old "Mrs. White, I- I think we should get dressed."
    new "怀特夫人，我……我觉得我们应该穿衣服了。"

translate chinese chinese_2789368_56:
    old "Oh no, what are you talking about?"
    new "哦不，你在说什么？"

translate chinese chinese_6310366_57:
    old "We're only getting started, that was just the beginning."
    new "我们才刚起步，那只是开始而已。"

translate chinese chinese_3610866_58:
    old "Now it's time for the main course."
    new "现在是主菜时间了。"

translate chinese chinese_4182510_59:
    old "Oh fuck! He arrived already!"
    new "哦操！他居然来了！"

translate chinese chinese_1207011_60:
    old "Shit! He's gonna catch us! We better get dressed quickly."
    new "shit! 他要抓到我们了！我们赶紧穿好衣服。"

translate chinese chinese_8756846_61:
    old "I'm in here honey!"
    new "我在里面呢，亲爱的！"

translate chinese chinese_8316339_62:
    old "Just give me a second!"
    new "等一下！"

translate chinese chinese_2040966_63:
    old "Hmm, this is annoying, he has to come back just when things are getting good!"
    new "哼，真烦人，正当事情变得有趣时，他偏偏要回来！"

translate chinese chinese_7246740_64:
    old "We should just hurry up."
    new "我们应该快点。"

translate chinese chinese_0766569_65:
    old "Mmm, look how hard it is."
    new "嗯，看看它有多硬。"

translate chinese chinese_6014812_66:
    old "And you were pretending to be nervous."
    new "而你还在装紧张。"

translate chinese chinese_8949223_67:
    old "Just relax, I'll make you cum before you know it."
    new "放松点，我会让你很快高潮的。"

translate chinese chinese_3768239_68:
    old "M- Mrs. White... Mmm, Mike could come back a- any minute."
    new "白太太……嗯，迈克随时都可能回来。"

translate chinese chinese_3471811_69:
    old "You're right, this is so naugthy!"
    new "你说得对，这真是够调皮的！"

translate chinese chinese_4437872_70:
    old "I love this adrenaline rush."
    new "我爱这种肾上腺素激增的感觉。"

translate chinese chinese_1800920_71:
    old "Mmm, yes, like that."
    new "嗯，就是这样。"

translate chinese chinese_9544349_72:
    old "Just enjoy it, I'll keep going."
    new "就享受吧，我继续。"

translate chinese chinese_2144621_73:
    old "I love how your cock twitches in my mouth."
    new "我喜欢你的 cocks 在我嘴里抽动的样子。"

translate chinese chinese_6128399_74:
    old "I can feel you getting close!"
    new "我能感觉到你越来越近了！"

translate chinese chinese_8862677_75:
    old "Do it, cum in my mouth!"
    new "来吧，射在我嘴里！"

translate chinese chinese_0895383_76:
    old "I'll swallow it all!"
    new "我全都要吞下去！"

translate chinese chinese_1688996_77:
    old "Ahhhh...."
    new "啊hhh...."

translate chinese chinese_6705405_78:
    old "Oh, I loved that!"
    new "哦，我超爱的！"

translate chinese chinese_2078124_79:
    old "You were so excited, and you got soo hard!"
    new "你当时那么兴奋，硬得不得了！"

translate chinese chinese_8906765_80:
    old "I think I'll do this again... "
    new "我想我还会再做一次……"

translate chinese chinese_9155370_81:
    old "M- mrs. White, I think you should clean up before Mike comes back."
    new "白太太，我想你在迈克回来之前应该打扫一下。"

translate chinese chinese_7099052_82:
    old "Sure, sure, it will be just a second."
    new "行行行，就一会儿。"

translate chinese chinese_4121461_83:
    old "Ah Yes! This big dick is just what I needed today."
    new "啊，对！这个大棒正是我今天需要的。"

translate chinese chinese_2938748_84:
    old "I'll never get tired of the smell of your cock."
    new "我永远不会对你那股味道感到厌倦。"

translate chinese chinese_7621681_85:
    old "It's making me so wet!"
    new "这让我湿透了！"

translate chinese chinese_5799954_86:
    old "Mmm, yes, like that, enjoy it!"
    new "嗯，就是这样，享受它！"

translate chinese chinese_9669132_87:
    old "Are you liking it you sweet boy?"
    new "你喜欢这样吗，甜心？"

translate chinese chinese_0328470_88:
    old "I-I am!."
    new "我——我是的！"

translate chinese chinese_9335575_89:
    old "Mmmm! Slrrp! This taste is the best!"
    new "姆姆！吸溜！这味道最好了！"

translate chinese chinese_4983031_90:
    old "Your dick feels so hot inside my mouth!"
    new "你的 dicks 在我嘴里热乎乎的！"

translate chinese chinese_7101911_91:
    old "Do you like it [pla]?! Tell me!"
    new "你喜欢吗，[pla]？！告诉我！"

translate chinese chinese_2233353_92:
    old "Yes ma'am! I do!"
    new "是的，夫人！我确实有！"

translate chinese chinese_9705001_93:
    old "Your dick! Is twitching!"
    new "你的 dicks 正在抽搐！"

translate chinese chinese_3619368_94:
    old "I want you to cum! Do it!"
    new "我要你射！来吧！"

translate chinese chinese_8050776_95:
    old "I- I'm about to...!"
    new "我—我要...！"

translate chinese chinese_4017786_96:
    old "Yes! Give me your cum!"
    new "没错！把你的精液给我！"

translate chinese chinese_1032336_97:
    old "Oh yes! It's always so good to have your dick in my mouth."
    new "哦，是的！你的棒棒在我嘴里总是感觉那么好。"

translate chinese chinese_0484632_98:
    old "I'll never get tired of it."
    new "我永远不会厌倦的。"

translate chinese chinese_2366334_99:
    old "Listen, Mrs. White, I think I just heard someone move outside."
    new "听吧，怀特夫人，我刚才好像听到外面有人动了一下。"

translate chinese chinese_9145402_100:
    old "We should hurry up and..."
    new "我们应该快点……"

translate chinese chinese_9530048_101:
    old "What are you talking about?"
    new "你在说什么？"

translate chinese chinese_3164348_102:
    old "We're not done yet."
    new "我们还没完呢。"

translate chinese chinese_1099393_103:
    old "And last time we were interrupted when Mike got home."
    new "上次是迈克回家打断了我们。"

translate chinese chinese_4037629_104:
    old "So, you're not going anywhere. There's something else that I want right now!"
    new "所以，你哪儿也去不了。我现在想要别的东西！"

translate chinese chinese_8119650_105:
    old "Oh! Yes! That's it!"
    new "哦！对！就是那里！"

translate chinese chinese_1789605_106:
    old "I've been wanting for you to be inside me for a while!"
    new "我早就想让你进入我了！"

translate chinese chinese_5948354_107:
    old "Yes! Like that, move a little faster."
    new "对！就这样，再快一点。"

translate chinese chinese_3875315_108:
    old "Oh boy, oh my sweet boy, yes, keep fucking me."
    new "哦，宝贝，哦我的甜心，对，继续狠狠地操我。"

translate chinese chinese_6598907_109:
    old "Oh yeah! Oh do you like how my pussy feels?"
    new "哦 yeah！你喜欢我的私处感觉吗？"

translate chinese chinese_6321101_110:
    old "Uhh yes, it feels amazing!"
    new "嗯哼，感觉太棒了！"

translate chinese chinese_8785945_111:
    old "Ah! I love your dick!"
    new "啊！我爱你的棒棒！"

translate chinese chinese_0178707_112:
    old "Do you like that baby? Do you like how I fuck you?"
    new "你喜欢那个宝宝吗？你喜欢我那样干你吗？"

translate chinese chinese_9053908_113:
    old "I- I think I'm about to finish!"
    new "我——我觉得我要搞定了！"

translate chinese chinese_2012138_114:
    old "Not yet, keep going baby boy!"
    new "还没呢，继续加油小宝贝！"

translate chinese chinese_1559355_115:
    old "M- Mrs. White, I can't hold it anymore!"
    new "白太太，我实在忍不住了！"

translate chinese chinese_3262029_116:
    old "It's ok, cum inside."
    new "没事，射里面吧。"

translate chinese chinese_5766914_117:
    old "Fill me up sweety!"
    new "给我灌满吧，甜心！"

translate chinese chinese_6465843_118:
    old "Wow, that was great!"
    new "哇，真棒！"

translate chinese chinese_1233698_119:
    old "I'd been wanting to fuck you so bad."
    new "我真的很想跟你做爱。"

translate chinese chinese_9889012_120:
    old "And you were even better than I imagined you would be."
    new "而且你比我想象的还要棒。"

translate chinese chinese_4112231_121:
    old "Did you like it too baby boy?"
    new "你也喜欢吗，小宝贝？"

translate chinese chinese_9726796_122:
    old "Uh, yes, I really did."
    new "呃，是的，我真的做了。"

translate chinese chinese_8567906_123:
    old "Listen Mrs. White I think it's better if I get dressed and leave."
    new "听着，怀特夫人，我觉得还是穿好衣服离开比较好。"

translate chinese chinese_7501177_124:
    old "I've been here for a while and I don't want Mike to catch us."
    new "我在这儿待了一会儿，不想让迈克发现我们。"

translate chinese chinese_4181512_125:
    old "Yeah, I think so too. It would be better."
    new "是啊，我也这么觉得。那样会好些。"

translate chinese chinese_0497635_126:
    old "I'll see you and that big cock later."
    new "等会儿见你和那个大鸡巴。"

translate chinese chinese_6764049_127:
    old "By the way, let me get back to what I was telling you before."
    new "对了，让我回到之前跟你说的事情。"

translate chinese chinese_9456064_128:
    old "It was about Belle."
    new "是关于贝尔的。"

translate chinese chinese_4461853_129:
    old "She wanted me to ask you if you could let us see the project you did with Hinn."
    new "她让我问你能不能让我们看看你和Hinn做的项目。"

translate chinese chinese_3197540_130:
    old "It's for reference, we're very late with it, and she says that since it is my fault that we're late, I should ask you."
    new "这是参考用的，我们已经很迟了，她说因为我们迟到是我的错，所以我应该问你。"

translate chinese chinese_7037358_131:
    old "Woah, are you ok dude? You look kinda tense."
    new "wow，你还好吗？你看起来挺紧张的。"

translate chinese chinese_3611814_132:
    old "Yeah... it's just... the sauce. I think it had something spicy in it."
    new "嗯……就是……酱料。我觉得里面可能有辣的东西。"

translate chinese chinese_2912387_133:
    old "Yeah, I think my mom put some chili in it, but it's very good anyway."
    new "嗯，我觉得我妈妈在里面放了一些辣椒，不过还是很好吃。"

translate chinese chinese_9613165_134:
    old "I- it is. Yeah she is really good..."
    new "我——是的。她确实很擅长……"

translate chinese chinese_6663615_135:
    old "Uhhh... You need the project? Sure."
    new "呃……你需要那个项目吗？当然可以。"

translate chinese chinese_5063511_136:
    old "I- I have it on my... Mmmm... computer, I'll email it to you."
    new "我——我在我的……嗯……电脑里，我发邮件给你。"

translate chinese chinese_9007460_137:
    old "Really? Thanks man you are the best."
    new "真的？谢谢老兄，你太棒了。"

translate chinese chinese_1845593_138:
    old "Oh, I forgot, Olivia told me she saw you the other day when she was leaving."
    new "哦，我想起来了，Olivia 告诉我那天她离开的时候看到你了。"

translate chinese chinese_7924876_139:
    old "Uh?..."
    new "嗯？..."

translate chinese chinese_3328795_140:
    old "Oh yeah, I- I think we... crossed over... Ahh... on the way out."
    new "哦对，我—我觉得我们……越线了……啊……出门的时候。"

translate chinese chinese_7924880_141:
    old "Hmm... Yeah, that's what she told me. But dude, she was super angry about running into you."
    new "嗯……是的，她就是这么告诉我的。但是伙计，她碰到你的时候超级生气的。"

translate chinese chinese_6310492_142:
    old "Please, don't tell anyone dude, or she won't talk to me anymore. Please?"
    new "拜托了，别告诉任何人，否则她就不会再理我了。求你了？"

translate chinese chinese_3385770_143:
    old "S- Sure... no problem!"
    new "好……没问题！"

translate chinese chinese_7162626_144:
    old "Thank you, you are a really good friend."
    new "谢谢你，你真是个好朋友。"

translate chinese chinese_2196996_145:
    old "Dude, you sure you are ok?"
    new "伙计，你确定自己没事吗？"

translate chinese chinese_0333785_146:
    old "Mmm... Y- yeah... Ugh, sure... N- no problem."
    new "嗯……是的……好吧……没问题。"

translate chinese chinese_9698350_147:
    old "You should drink some water."
    new "你应该喝点水。"

translate chinese chinese_0992683_148:
    old "Hmm, I'm definitely not the only one who will drink something."
    new "嗯，我肯定不是唯一一个会喝酒的人。"

translate chinese chinese_2883983_149:
    old "Oh... Never mind, it's just the spice talking here."
    new "哦……忘了它，这里只是香料在说话而已。"

translate chinese chinese_0851201_150:
    old "Dude, I'm starting to get worried. You look like you're about to burts. Here, let me hand you..."
    new "伙计，我开始担心了。你看起来好像要爆发了。来，让我给你递上..."

translate chinese chinese_9291361_151:
    old "N- no... i- it's ok, I'm just feeling a little bad."
    new "不... 不要紧，我只是觉得有点不舒服。"

translate chinese chinese_5117522_152:
    old "Just give me a minute."
    new "就给我一分钟。"

translate chinese chinese_9345986_153:
    old "Are you sure? I think you should relax and release everything."
    new "你确定吗？我觉得你应该放松一点，释放一切。"

translate chinese chinese_2959277_154:
    old "Ughh... That's exactly what I'm going to do..."
    new "呃……那正是我要做的……"

translate chinese chinese_2142123_155:
    old "Mmmm! It's so big, so thick and long!"
    new "嗯！这么大，又粗又长！"

translate chinese chinese_2408348_156:
    old "I was waiting for this, baby boy!"
    new "我就等着这一刻呢，小宝贝！"

translate chinese chinese_0713430_157:
    old "That's it, fill me up!"
    new "就是这个，给我来满的！"

translate chinese chinese_4702844_158:
    old "Ahhh! Mmmm!!"
    new "啊hh! 哦mm!!"

translate chinese chinese_9179010_159:
    old "I love how hot your cock is in my pussy!"
    new "我爱你这火热的棒子插在我的 pussy 里感觉真好！"

translate chinese chinese_2016153_160:
    old "I can feel it filling me up!"
    new "我能感觉到它充满了我！"

translate chinese chinese_7390663_161:
    old "It's so big and hot!"
    new "它这么大这么热！"

translate chinese chinese_6816316_162:
    old "Oh god! This dick! I love it!"
    new "哦天啊！这个棒极了！我爱死它了！"

translate chinese chinese_4594820_163:
    old "MMMM! AAAAH! Yes! Yes!"
    new "MMMM！AAAH！是的！是的！"

translate chinese chinese_9294713_164:
    old "I love your cock sweetie!"
    new "我爱你的棒棒，甜心！"

translate chinese chinese_7774008_165:
    old "I love to feel your cock inside me my baby boy!"
    new "我爱感受你硬挺在里面，我的宝贝！"

translate chinese chinese_3454342_166:
    old "I-I'm about to finish Mrs. White!"
    new "我——我快要把怀特太太搞定了！"

translate chinese chinese_0457980_167:
    old "YES! YES! ME TOO!"
    new "是的！是的！我也是！"

translate chinese chinese_6987944_168:
    old "Do it! Cum in my pussy!"
    new "来吧！射里面！"

translate chinese chinese_2433229_169:
    old "Do it my sweet baby!"
    new "来吧，我的甜心宝贝！"

translate chinese chinese_2224350_170:
    old "Phew, that was amazing!"
    new "呼，真棒！"

translate chinese chinese_3896444_171:
    old "Ohh yeah."
    new "哦，是吗。"

translate chinese chinese_4084880_172:
    old "!!!!!!"
    new "!!!!!!"

translate chinese chinese_8509845_173:
    old "H- Hi son, I- I'm ok."
    new "嗨，儿子，我……我没事。"

translate chinese chinese_4372918_174:
    old "I wasn't expecting you to come home so quickly."
    new "我没想到你会这么快回家。"

translate chinese chinese_9074431_175:
    old "Yeah, me either. But Olivia said she had to take care of some personal things."
    new "是啊，我也是这么觉得。但Olivia说她有些私事要处理。"

translate chinese chinese_5055365_176:
    old "So, I had to come early."
    new "所以，我得早一点来。"

translate chinese chinese_1411723_177:
    old "Oh, I see, well..."
    new "哦，我明白了，嗯……"

translate chinese chinese_4157296_178:
    old "Since you have some free time, why don't you go up to your room and play some video games?"
    new "既然你有空，不如去房间玩会儿游戏吧？"

translate chinese chinese_7758793_179:
    old "Or just relax, you've been studying a lot these days, you deserve a break."
    new "或者放松一下吧，你这些天学习太多了，值得休息一下。"

translate chinese chinese_3882029_180:
    old "Sure, but first I'm going to grab a snack from the kitchen."
    new "行，但我要先去厨房拿点零食。"

translate chinese chinese_1982198_181:
    old "Wait!"
    new "等一下！"

translate chinese chinese_7052839_182:
    old "What? What happens?"
    new "什么？发生什么事了？"

translate chinese chinese_6228567_183:
    old "Ehhh... Just, I know you're tired."
    new "呃……就是，我知道你累了。"

translate chinese chinese_5231270_184:
    old "So, why don't you just go up and I'll prepare and bring you some snacks?"
    new "那你就上来吧，我准备一些零食给你。"

translate chinese chinese_1853464_185:
    old "Wow, really?"
    new "wow, 真的吗？"

translate chinese chinese_1681859_186:
    old "Yeah sure, just go up and I'll be there in a bit."
    new "行吧，你先上去，我一会儿就到。"

translate chinese chinese_0774309_187:
    old "Ok, thanks mom!"
    new "好的，谢谢妈妈！"

translate chinese chinese_0000945_188:
    old "Phew, that was really close"
    new "呼，那真是险些失败了"

translate chinese chinese_5771839_189:
    old "I knew he was going to catch us!"
    new "我就知道他会抓到我们！"

translate chinese chinese_0938775_190:
    old "We should have gone to your room!"
    new "我们应该去你的房间的！"

translate chinese chinese_1774940_191:
    old "Calm down, he didn't see anything."
    new "冷静点，他什么都没看到。"

translate chinese chinese_3466013_192:
    old "But we don't have time to talk about that."
    new "但是我们现在没有时间讨论这个。"

translate chinese chinese_1037551_193:
    old "Mom! Do you think you could bring me a soda with the snacks?"
    new "妈妈！你能带杯苏打水来吗？"

translate chinese chinese_9925659_194:
    old "Now, quickly, leave!"
    new "快走！"

translate chinese chinese_4619326_195:
    old "Ok, ok, I'm going!"
    new "好啦好啦，我这就去！"

translate chinese chinese_3851721_196:
    old "Ah! Ah! Ah! That's it sweety, fuck me just like that."
    new "啊！啊！啊！就是这样，宝贝，就那样干我。"

translate chinese chinese_1926406_197:
    old "I- I can feel your entire dick! It's so long and thick!"
    new "我——我能感觉到你的整个 dicks! 它好长好粗!"

translate chinese chinese_4748394_198:
    old "Yes! This is just what I wanted!"
    new "没错！这正是我想要的！"

translate chinese chinese_6637883_199:
    old "Ah! It's so good!"
    new "啊！真好吃！"

translate chinese chinese_7136379_200:
    old "Mmm I love your big cock!"
    new "嗯，我喜欢你的大鸡巴！"

translate chinese chinese_9560164_201:
    old "Ohh yeah, just like that baby!"
    new "噢 yeah，就是这样宝贝！"

translate chinese chinese_4446730_202:
    old "Fuck! YES! YES! FUCK ME MORE!"
    new "操！是的！是的！再狠狠地操我！"

translate chinese chinese_5836430_203:
    old "Fuck me, fuck your mommy!"
    new "操我，操你妈！"

translate chinese chinese_8295617_204:
    old "Keep pounding me!"
    new "继续猛击我！"

translate chinese chinese_5329867_205:
    old "I- I can feel you tensing up!"
    new "我——我能感觉到你在紧张！"

translate chinese chinese_8091583_206:
    old "Do it! CUM! CUM INSIDE ME!"
    new "来吧！射！在里面射！"

translate chinese chinese_8025610_207:
    old "Y-yes!"
    new "是的！"

translate chinese chinese_2999072_208:
    old "Ahhh! This is the best cock I've ever had!"
    new "啊hhh！这是我尝过的最棒的！"

translate chinese chinese_6034082_209:
    old "That was very good sweety!"
    new "非常好，甜心！"

translate chinese chinese_0215870_210:
    old "You keep doing it better and better. You just keep making me want that cock even more every time..."
    new "你越做越好，每次都能让我更想得到那个家伙……"

translate chinese chinese_2271390_211:
    old "I'm glad you liked it Mrs. White."
    new "白太太，我很高兴你喜欢它。"

translate chinese chinese_6562491_212:
    old "I didn't just like it, I loved it!"
    new "我可不是喜欢而已，我是爱死了！"

translate chinese chinese_5735617_213:
    old "And I hope you know we'll be doing it again very soon."
    new "而且我希望你知道我们很快还会再做的。"

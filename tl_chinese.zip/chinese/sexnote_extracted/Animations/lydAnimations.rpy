# auto-tl Qwen Colab

translate chinese chinese_9259051_0:
    old "You definitely should make many young girls very happy."
    new "你肯定能让很多小女孩非常开心。"

translate chinese chinese_8999956_1:
    old "It's so long and thick."
    new "它又长又粗。"

translate chinese chinese_1879724_2:
    old "And rock solid too."
    new "而且非常结实。"

translate chinese chinese_7080271_3:
    old "Oh my god! You're getting even harder!"
    new "天啊！你越来越硬了！"

translate chinese chinese_9169263_4:
    old "Your dick! It's so hard and hot in my hand!"
    new "你的 dicks! 在我手里的感觉这么硬这么热!"

translate chinese chinese_2753137_5:
    old "That's it, let go! Just let me stroke it!"
    new "就是这样，放开我！就让我摸一下！"

translate chinese chinese_1574124_6:
    old "Do you like this? Do you like how I play with your dick?"
    new "你喜欢这样吗？你喜欢我这样玩你的丁丁吗？"

translate chinese chinese_4022306_7:
    old "Is this dick that hard because of me? Do you think I'm sexy?"
    new "这硬起来是因为我吗？觉得我性感吗？"

translate chinese chinese_8902472_8:
    old "Y-yes, you are sexy!"
    new "是的，你很性感！"

translate chinese chinese_4886151_9:
    old "I- I think I'm about to!"
    new "我—我觉得我要来了！"

translate chinese chinese_4771189_10:
    old "Yes! cum!"
    new "yes! 快来！"

translate chinese chinese_1836797_11:
    old "I want to see you shoot all your hot stuff because of me!"
    new "我想看到你因为我而射出所有热液！"

translate chinese chinese_2501016_12:
    old "Oh yeah! It's just as I imagined."
    new "哦，是的！完全就像我想象的那样。"

translate chinese chinese_8290447_13:
    old "It has an amazing taste!"
    new "味道好极了！"

translate chinese chinese_1582053_14:
    old "And it's so hot!"
    new "而且热死了！"

translate chinese chinese_9497713_15:
    old "I don't think I've ever blown a dick this big, even in the past."
    new "我觉得我以前从来没有见过这么大的家伙。"

translate chinese chinese_8643605_16:
    old "I think this is the best dick I've seen."
    new "我觉得这是我看过的最好的鸡巴。"

translate chinese chinese_4434485_17:
    old "And it's also the biggest!"
    new "而且还是最大的！"

translate chinese chinese_5884146_18:
    old "Mmmm! Slrrp!"
    new "姆姆！吸！"

translate chinese chinese_1627093_19:
    old "Do you like my mouth?"
    new "你喜欢我的嘴吗？"

translate chinese chinese_7692175_20:
    old "Do you like how I do it?!"
    new "你喜欢我这样吗！？"

translate chinese chinese_1656908_21:
    old "I can feel how your dick twitches in my mouth!"
    new "我能感觉到你的 dicks 在我嘴里抽动！"

translate chinese chinese_1645312_22:
    old "Do it [pla]!"
    new "做吧 [pla]！"

translate chinese chinese_9041049_23:
    old "Cum in my mouth young man!"
    new "在我嘴里射精吧，小伙子！"

translate chinese chinese_4663553_24:
    old "O- ok!"
    new "好！"

translate chinese chinese_4086092_25:
    old "That was great. Young men really are something special."
    new "真棒。年轻男人确实不一样。"

translate chinese chinese_7542960_26:
    old "But you know [pla], I think you're extra special."
    new "但是你知道[pla]，我觉得你特别与众不同。"

translate chinese chinese_2676299_27:
    old "I mean, even when I was young, I never saw a dick like yours before."
    new "我是说，就算我年轻的时候，也没见过像你这样的家伙。"

translate chinese chinese_4985446_28:
    old "It's amazing how big and hard it is."
    new "真没想到会这么大这么硬。"

translate chinese chinese_5536779_29:
    old "It makes me wonder..."
    new "这让我好奇..."

translate chinese chinese_8386689_30:
    old "Ok... I think I should get dressed again."
    new "好吧……我觉得我应该再穿衣服了。"

translate chinese chinese_1566520_31:
    old "Yeah, you're right. It would be best."
    new "嗯，你说得对，这样最好。"

translate chinese chinese_1280187_32:
    old "Nngh! Wow, it's so big."
    new "嗯！好大啊。"

translate chinese chinese_6299042_33:
    old "Y- yes, it's just that it's been a while."
    new "是的，只是因为有一段时间了。"

translate chinese chinese_5345667_34:
    old "And you're so big!"
    new "而且你这么大！"

translate chinese chinese_2286114_35:
    old "Ah! Ah! Yes! Yes!"
    new "啊！啊！是的！是的！"

translate chinese chinese_9376790_36:
    old "Your dick, it's so big, and so hot!"
    new "你的棒棒好大，还那么热！"

translate chinese chinese_2750297_37:
    old "It's filling me up so hard!"
    new "它让我感到如此强烈！"

translate chinese chinese_6076332_38:
    old "L- let's do it a little faster!"
    new "L- 让我们快一点吧！"

translate chinese chinese_5865401_39:
    old "Yes! Just like that!"
    new "对！就是这样！"

translate chinese chinese_8362470_40:
    old "Don't stop! Keep going!"
    new "不要停！继续！"

translate chinese chinese_6621252_41:
    old "Nngh! Yes! YES!"
    new "嗯！是的！对！"

translate chinese chinese_0552779_42:
    old "I- I think I can't hold it in longer!"
    new "我—我觉得我忍不住了！"

translate chinese chinese_6916568_43:
    old "Don't! Don't hold it!"
    new "别！不要忍！"

translate chinese chinese_6765417_44:
    old "You can do it! CUM INSIDE!"
    new "你能行的！射里面！"

translate chinese chinese_5116417_45:
    old "You know? I believe this might have worked, I feel so much better now, like a weight has been lifted off my shoulders."
    new "你知道吗？我觉得这可能有效了，我现在感觉好多了，就像卸下了一个重担。"

translate chinese chinese_6194030_46:
    old "I'm glad you feel like that. I hope this actually helped you."
    new "很高兴你能这么觉得，希望这真的帮到你。"

translate chinese chinese_8123457_47:
    old "I'm sure it did, thanks a lot [pla]!"
    new "肯定的，谢谢[pla]！"

translate chinese chinese_9672996_48:
    old "You're welcome, I'm happy to help."
    new "不客气，我很乐意帮忙。"

translate chinese chinese_3461583_49:
    old "I'm gonna use my tongue all over the tip of your cock."
    new "我要用舌头舔遍你鸡巴的每一个尖端。"

translate chinese chinese_0747749_50:
    old "Uhh, I love that sensation, babe."
    new "嗯，我喜欢那种感觉，宝贝。"

translate chinese chinese_9794085_51:
    old "Mmmm... It tastes so good! I love it."
    new "嗯……味道真好！我超爱的。"

translate chinese chinese_1958952_52:
    old "Oh yeah babe, I'll definitely love your mouth."
    new "哦 yeah 宝贝，我肯定会喜欢你的嘴的。"

translate chinese chinese_3371122_53:
    old "Slrrrp! Uhh you have no idea!"
    new "啧啧！你根本不知道！"

translate chinese chinese_1285826_54:
    old "You should have a lot of experience, don't you?"
    new "你应该很有经验吧？"

translate chinese chinese_4607990_55:
    old "Mmmm, yeah baby, but not with huge cocks like yours."
    new "嗯，好吧宝贝，但不是像你这样的大 cock。"

translate chinese chinese_5419692_56:
    old "Oh yeah babe, you will really enjoy my huge cock!"
    new "哦 yeah 宝贝，你会非常喜欢我这巨大的鸡巴的！"

translate chinese chinese_9953482_57:
    old "Mmm, that's exactly what I'm expecting."
    new "嗯，这正是我期待的。"

translate chinese chinese_1849162_58:
    old "Ohh babe, I'm about to cum."
    new "哦，宝贝，我要来了。"

translate chinese chinese_1518272_59:
    old "Oh no, you don't. That's barely the beginning. You know what comes next."
    new "哦不，这才刚开始呢。你知道接下来会发生什么。"

translate chinese chinese_1661317_60:
    old "(Oh God.)"
    new "（天啊。）"

translate chinese chinese_6401021_61:
    old "Oh, I know what comes next, that's right, you want to put it all in your mouth, don't you?"
    new "哦，我知道接下来要做什么了，对吧，你想全部含在嘴里，是不是？"

translate chinese chinese_0831610_62:
    old "Yes! I want to feel it all in my mouth."
    new "是的！我想全部用嘴感受。"

translate chinese chinese_2871561_63:
    old "I love how big your cock is!"
    new "我爱你的 cock 真的大！"

translate chinese chinese_7645874_64:
    old "Suck it! Put my cock in your mouth!"
    new "吞下去！把我的棒子放进嘴里！"

translate chinese chinese_6035433_65:
    old "Mmm, I just love the taste of your cock!"
    new "嗯，我就喜欢你那个味道！"

translate chinese chinese_7608473_66:
    old "I love how big and hot it always gets!"
    new "我就喜欢它总是这么大这么热！"

translate chinese chinese_1544541_67:
    old "Yeah! Tell me more!"
    new "yeah! 快告诉我更多！"

translate chinese chinese_2088832_68:
    old "This is the best cock I've ever had!"
    new "这是我有过的最好的棒子！"

translate chinese chinese_6097569_69:
    old "Nngh! Mmmm! I want more and more of it!"
    new "嗯！呜呜！我要更多更多！"

translate chinese chinese_3397572_70:
    old "Oh yeah? You want me to fuck you with it?"
    new "哦是吗？你想让我用这个干你？"

translate chinese chinese_4583844_71:
    old "Yes! I love how it feels inside!"
    new "是的！我喜欢那种感觉！"

translate chinese chinese_9836680_72:
    old "Do you like how my dick fills your mouth?"
    new "你喜欢我的 dicks 填满你的嘴的感觉吗？"

translate chinese chinese_8813468_73:
    old "Slrrrp! I love it! I can't get enough of it!"
    new "啧啧！我爱死了！根本停不下来！"

translate chinese chinese_2736934_74:
    old "Don't cum yet! I want you to keep pushing your cock in my mouth!"
    new "别射！我要你继续把你的 cocks 推进我嘴里！"

translate chinese chinese_0881804_75:
    old "That's it! Gobble on my cock!"
    new "就是现在！吞下我的cock！"

translate chinese chinese_0387494_76:
    old "I'm about to cum baby! Tell me you want it in your mouth!"
    new "我要射了宝贝！告诉我你想要它在你嘴里！"

translate chinese chinese_8290871_77:
    old "Yes! Yes! Shoot it all in my mouth!"
    new "是的！是的！全都射到我嘴里！"

translate chinese chinese_6315063_78:
    old "Fill my mouth with your hot cum!"
    new "用你的热精液填满我的嘴！"

translate chinese chinese_7246067_79:
    old "Phew... This guy is writing again, he says 'Wow, that was so great!'"
    new "呼……这家伙又在写了，他说“哇，真是太棒了！”"

translate chinese chinese_0689840_80:
    old "Hahaha, great? Don't you say?"
    new "哈哈，很棒吧？你不觉得吗？"

translate chinese chinese_3836506_81:
    old "Tell him 'It really was, I can't wait for what's next.'"
    new "告诉他“真的很棒，我迫不及待想看接下来的了。”"

translate chinese chinese_5740269_82:
    old "He answered with 'Yeah, me neither, but that'll have to wait, I have to go work, I'm 30 minutes over my break! Talk to you later, bye!'"
    new "他回答说‘是啊，我也是，但那得等以后了，我得去上班，已经超出休息时间30分钟了！回头聊，拜拜！’"

translate chinese chinese_8666468_83:
    old "'But be sure I'm crazy to see you!'"
    new "“但我确实很想见你！”"

translate chinese chinese_8879648_84:
    old "That's nice, I guess we'll talk later."
    new "那好吧，看来我们以后再聊。"

translate chinese chinese_9172382_85:
    old "You don't want me to answer anything back?"
    new "你不想让我回答什么吗？"

translate chinese chinese_4111441_86:
    old "There's no need, he'll talk to me later anyway."
    new "不用了，他反正later会跟我谈的。"

translate chinese chinese_7256300_87:
    old "Nngh! Oh yes! This is just what I've been wanting!"
    new "嗯！哦 yeah！这正是我想要的！"

translate chinese chinese_3449820_88:
    old "This long, thick hard cock of yours!"
    new "你这长长的粗硬的家伙！"

translate chinese chinese_4191161_89:
    old "There's no other cock like it!"
    new "再也没有这样的家伙了！"

translate chinese chinese_8169726_90:
    old "Y- your cock is the best!"
    new "你那个真的太棒了！"

translate chinese chinese_4793411_91:
    old "I've never had any cock like this!"
    new "我从没见过这样的家伙！"

translate chinese chinese_9882807_92:
    old "Yes, yes, fuck me more!"
    new "是的，是的，再狠狠地操我！"

translate chinese chinese_7825979_93:
    old "Ohh! I love how you push into my pussy!"
    new "哦！我喜欢你这样顶我 pussy 的感觉！"

translate chinese chinese_2210292_94:
    old "I can't have enough of this hot cock!"
    new "这火热的家伙我永远都玩不够！"

translate chinese chinese_6556800_95:
    old "Fuck me! Fuck me more!"
    new "操我！再用力一点！"

translate chinese chinese_3138160_96:
    old "L- Lydia! I think I'm about to..."
    new "莉迪亚！我觉得我要..."

translate chinese chinese_0694657_97:
    old "Yes! Let it all out!"
    new "没错！全都发泄出来吧！"

translate chinese chinese_4768777_98:
    old "Fill me with your hot cum!"
    new "用你的热精液填满我！"

translate chinese chinese_6992366_99:
    old "That was good!"
    new "不错哦！"

translate chinese chinese_6494518_100:
    old "Just what I was expecting."
    new "正是我所预料的。"

translate chinese chinese_5392701_101:
    old "Listen, I'm glad you're feeling better."
    new "听着，我很高兴你感觉好多了。"

translate chinese chinese_7212808_102:
    old "But, I think it's better if you just leave. Remember this isn't your house, someone could hear us."
    new "但是，我觉得你还是离开比较好。记住这可不是你的家，有人可能会听到我们的谈话。"

translate chinese chinese_6546811_103:
    old "Leave? What are you talking about?"
    new "离开？你在说什么？"

translate chinese chinese_4961058_104:
    old "This is just the beginning!"
    new "这仅仅是个开始！"

translate chinese chinese_9901196_105:
    old "W- What? What else do you want to do?"
    new "什、什么？你还想干什么？"

translate chinese chinese_5726232_106:
    old "Ohh, it's something I wanted to try for the longest time."
    new "哦，这是我早就想尝试的事情。"

translate chinese chinese_9065828_107:
    old "But my husband was too much of a prude for it."
    new "但我老公太拘谨了，接受不了。"

translate chinese chinese_1855357_108:
    old "Him and his stupid morale, always draggin me back!"
    new "他那该死的道德观，总是把我拉回来！"

translate chinese chinese_7630887_109:
    old "So, now you're going to give me what I want..."
    new "所以，现在你要给我想要的东西了……"

translate chinese chinese_4883290_110:
    old "Just come here and find out."
    new "干脆过来自己看看。"

translate chinese chinese_4766128_111:
    old "It's ok if you start sl-"
    new "如果你开始流口水也无所谓，"

translate chinese chinese_1323459_112:
    old "AH! AAAH!"
    new "啊！啊啊！"

translate chinese chinese_0911471_113:
    old "Oh yes! This is what I wanted!"
    new "哦，是的！这就是我想要的！"

translate chinese chinese_5056144_114:
    old "Mmm, nngh, it hurts a little, but is perfect!"
    new "嗯，啊，有点疼，但perfect！"

translate chinese chinese_6612588_115:
    old "Y- your dick is massive!"
    new "你这家伙这么大！"

translate chinese chinese_4350798_116:
    old "It's stretching my ass so much!"
    new "它把我的屁股拉得这么开！"

translate chinese chinese_6272768_117:
    old "S- should I stop?"
    new "我—我应该停下来吗？"

translate chinese chinese_1390391_118:
    old "No! Don't you dare!"
    new "不行！你敢！"

translate chinese chinese_8742877_119:
    old "I'm loving this!"
    new "我超爱这个的！"

translate chinese chinese_8143412_120:
    old "YES! YES! You fucking my ass with that big dick!"
    new "是的！是的！用那大棒操我的屁股！"

translate chinese chinese_0151554_121:
    old "It's just what I wanted!"
    new "这正是我想要的！"

translate chinese chinese_8725758_122:
    old "I'll never have enough of this dick!"
    new "我永远都不会腻味这个家伙！"

translate chinese chinese_2888903_123:
    old "I love it when you fuck me!"
    new "我最喜欢你干我了！"

translate chinese chinese_6059836_124:
    old "I can feel your dick twitching in my ass!"
    new "我能感觉到你的 dicks 在我屁股里动！"

translate chinese chinese_6753867_125:
    old "I- I'm about to finish!"
    new "我——我快好了！"

translate chinese chinese_2504982_126:
    old "Do it! Finish in my ass!"
    new "上吧！在我屁股里结束吧！"

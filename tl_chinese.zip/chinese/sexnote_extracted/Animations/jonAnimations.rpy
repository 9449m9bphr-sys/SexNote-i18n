# auto-tl Qwen Colab

translate chinese chinese_4894765_0:
    old "It barely fits in my mouth... My god! You really have something big here."
    new "这几乎塞不进我的嘴里……天啊！你这里真的很大。"

translate chinese chinese_4742153_1:
    old "It's a massive cock, just like my husband's dick."
    new "那是个巨大的鸡巴，就像我丈夫的一样。"

translate chinese chinese_9074216_2:
    old "(Wow! I can see she has some good experience at this...)"
    new "（哇！看得出来她在这方面很有经验……）"

translate chinese chinese_0384599_3:
    old "It's so big and Mmmm... So good..."
    new "这么大…嗯…真棒…"

translate chinese chinese_6213214_4:
    old "Mrs. Jones I'm cum-"
    new "琼斯夫人，我快要射了。"

translate chinese chinese_8135860_5:
    old "Oh Yes! Give me your sacred cum..."
    new "哦，是的！把你的神圣精液给我……"

translate chinese chinese_5023321_6:
    old "Ahhhhhhhhh!"
    new "啊啊啊啊啊！"

translate chinese chinese_4139323_7:
    old "Oh my God, I really need to feel your divine presense inside me..."
    new "天啊，我真的需要感受到你那神圣的存在……"

translate chinese chinese_2513720_8:
    old "Come to my bedroom..."
    new "来我的卧室..."

translate chinese chinese_4508530_9:
    old "I- I'm doing it right?"
    new "我—我做得对吧？"

translate chinese chinese_8529817_10:
    old "My pussy is speaking for me... Just feel how wet it's for you."
    new "我的下体在替我说话……感受一下它是多么为你湿润。"

translate chinese chinese_6947808_11:
    old "I haven't felt like this in years !!"
    new "我好几年都没这种感觉了！！"

translate chinese chinese_5449437_12:
    old "Being with a young and vigorous man like you, has no comparison."
    new "和你这样的年轻有活力的男人在一起，根本没法比。"

translate chinese chinese_9827692_13:
    old "Oh god! Oh God!"
    new "哦天啊！哦上帝！"

translate chinese chinese_8605006_14:
    old "You'll make me come so badly!"
    new "你会让我高潮得这么厉害！"

translate chinese chinese_1375697_15:
    old "I- I'm cumming-"
    new "我快来了……"

translate chinese chinese_7763295_16:
    old "Ohhh mee too!!!"
    new "哦hhh 我也是!!!"

translate chinese chinese_7807526_17:
    old "Wow, that was great... We should, get dressed before Billie arrives."
    new "哇，真棒……我们在Billie来之前应该穿好衣服。"

translate chinese chinese_7414383_18:
    old "Oh yeah! Fuck my mouth you little boy!"
    new "哦 yeah！把你这小家伙塞进我嘴里吧！"

translate chinese chinese_8354314_19:
    old "Oh God!"
    new "天啊！"

translate chinese chinese_4079985_20:
    old "It's so good to have it inside my mouth... I can feel your veins pumping..."
    new "把它含在嘴里真舒服……我能感觉到你的血管在跳动……"

translate chinese chinese_5918449_21:
    old "Ahhhhhhh! You're so good..."
    new "啊啊啊啊！你好棒..."

translate chinese chinese_2926015_22:
    old "Yes! Faster! Faster I want you to cum on my mouth!"
    new "没错！快点！更快点，我要你在我嘴里射精！"

translate chinese chinese_5151221_23:
    old "Ohh... I can feel your body tensing!"
    new "哦……我能感觉到你的身体在紧张！"

translate chinese chinese_7997678_24:
    old "Fill my mouth with your cum!"
    new "用你的精液填满我的嘴！"

translate chinese chinese_7213641_25:
    old "I'm so wet... But today I want you to fuck my ass..."
    new "我好湿……但今天我想让你操我的屁股……"

translate chinese chinese_3511488_26:
    old "... W- what?"
    new "... 哪、哪啊？"

translate chinese chinese_0813648_27:
    old "I just want to remember the good times with my husband ..."
    new "我只想记住和我丈夫在一起的好时光……"

translate chinese chinese_4393108_28:
    old "Oh God, it's so big it hurts!"
    new "天啊，太大了，好痛！"

translate chinese chinese_3218042_29:
    old "Do you want me to stop?"
    new "你要我停下来吗？"

translate chinese chinese_8987126_30:
    old "Ohh no, please don't stop, I want you to fuck my ass just like my husband used to do..."
    new "哦不，别停下来，我想让你像我丈夫以前那样干我的屁股……"

translate chinese chinese_6940475_31:
    old "Faster! I want you to fuck me harder!"
    new "快点！我要你更用力地操我！"

translate chinese chinese_7405860_32:
    old "Oh yes! Just like that! Don't stop, don't stop!!"
    new "哦 yeah！就是那样！不要停，不要停！！"

translate chinese chinese_6418251_33:
    old "It hurts, but it feels so good!"
    new "好疼，但感觉真爽！"

translate chinese chinese_4632005_34:
    old "Oh yeah, fill my ass with your cum!"
    new "哦 yeah，把我填满你的精液！"

translate chinese chinese_9016552_35:
    old "Oh God, you are definitely better than my husband..."
    new "天啊，你 definitely 比我老公强多了..."

translate chinese chinese_9684688_36:
    old "Wow, it's bigger than I remember..."
    new "wow，比我记得的大多了……"

translate chinese chinese_3779667_37:
    old "Ahhhh! So nice."
    new "啊hhh！真舒服。"

translate chinese chinese_1497413_38:
    old "My goddess!"
    new "我的天！"

translate chinese chinese_1263281_39:
    old "Let me give you a hand with this..."
    new "让我来帮你搞定这个……"

translate chinese chinese_5587107_40:
    old "Oh, it looks so hot!"
    new "哦，看起来好性感！"

translate chinese chinese_5906639_41:
    old "Yeah! get that cock ready to fuck us!"
    new "yeah! 把那家伙准备好来操我们!"

translate chinese chinese_6148416_42:
    old "Oh, Billie, please watch your mouth..."
    new "哦，比莉，说话注意点..."

translate chinese chinese_7792237_43:
    old "Alright, I guess it's time to start, sister Grace is waiting hun!"
    new "好吧，看来得开始了，格蕾丝姐姐还在等着呢！"

translate chinese chinese_0764008_44:
    old "Oh my God! It feels amazing inside of me!"
    new "天啊！里面的感觉太棒了！"

translate chinese chinese_7002977_45:
    old "I have a great view of your pussy being fucked sister Grace..."
    new "我看得一清二楚，格蕾丝姐姐，你的 pussy 正被人操着..."

translate chinese chinese_2000495_46:
    old "Billie!"
    new "比莉！"

translate chinese chinese_2380248_47:
    old "My body and soul really needed this ritual."
    new "我的身体和灵魂真的很需要这个仪式。"

translate chinese chinese_0867359_48:
    old "Ahhh!"
    new "啊hhh！"

translate chinese chinese_3592570_49:
    old "More... More..."
    new "更多... 更多..."

translate chinese chinese_6495047_50:
    old "If I had known about these rituals I would have become a nun too!"
    new "如果我知道这些仪式的话，我也会去当修女的！"

translate chinese chinese_1244271_51:
    old "Oh! My dear... You'll make me cum with so much g- grace..."
    new "哦！我的亲爱的……你会让我这么轻易就高潮了……"

translate chinese chinese_7461116_52:
    old "Ahhh! I'm about t-"
    new "啊hhh！我快忍不住了——"

translate chinese chinese_3476833_53:
    old "Fuck! This is so damn good!"
    new "操！这真是太棒了！"

translate chinese chinese_6094785_54:
    old "So good, my God!"
    new "太棒了，我的天！"

translate chinese chinese_7490550_55:
    old "Fuck! I'm cuming!"
    new "操！我要射了！"

translate chinese chinese_3868005_56:
    old "Me too... Ahhh!"
    new "我也是……啊hhh！"

translate chinese chinese_3623657_57:
    old "Wow, that was intense..."
    new "哇，那真是紧张刺激……"

translate chinese chinese_9959611_58:
    old "My God! Thanks for this..."
    new "天啊！感谢这个……"

translate chinese chinese_9199226_59:
    old "[pla], you're my holy savior...  Take me!"
    new "[pla]，你是我的救世主……来吧！"

translate chinese chinese_7342093_60:
    old "(This is h- heaven... Shit!)"
    new "（这简直是天堂……见鬼！）"

translate chinese chinese_3088398_61:
    old "Do you like what you see?"
    new "你喜欢看到的吗？"

translate chinese chinese_2728995_62:
    old "Come on hun, it's time to give me some blessed cock."
    new "来吧宝贝，是时候给我点福 cock 了。"

translate chinese chinese_2055680_63:
    old "Oh yeah, guide Mrs. Jones, just like you did with me."
    new "哦 yeah，像对我一样指导琼斯夫人吧。"

translate chinese chinese_4270157_64:
    old "Do you feel 'God's presence' right now?"
    new "你现在感觉到“神的存在”了吗？"

translate chinese chinese_4560038_65:
    old "Oh yes, I feel it... Very deep inside."
    new "哦，是的，我感觉到了……很深很深的地方。"

translate chinese chinese_5714641_66:
    old "I feel too so much of your divine presence, my heavenly God!"
    new "我感到你的神威了，天神！"

translate chinese chinese_8243581_67:
    old "My God! It feels amazing!"
    new "天啊！感觉太棒了！"

translate chinese chinese_9656818_68:
    old "Oh yes, fuck my granny, just like you fucked me!"
    new "哦 yeah，操我奶奶，就像你操我一样！"

translate chinese chinese_0924569_69:
    old "[pla], my spiritual guide, you're the best..."
    new "[pla]，我的精神导师，你是最棒的..."

translate chinese chinese_6623935_70:
    old "This is the best religion ever!"
    new "这是有史以来最好的宗教！"

translate chinese chinese_8769093_71:
    old "Oh, you have no idea!"
    new "哦，你根本不知道！"

translate chinese chinese_8763692_72:
    old "I'm touching God right now... This is so good..."
    new "我现在摸到他的关键部位了……感觉真好……"

translate chinese chinese_2636778_73:
    old "I- I'm cuming again..."
    new "我……我又来了……"

translate chinese chinese_8452796_74:
    old "Ahhhhhh!"
    new "啊啊啊啊！"

translate chinese chinese_3676249_75:
    old "Yeesss!"
    new "耶斯！"

translate chinese chinese_7623239_76:
    old "We need your cum, right now! We to purify ourselves."
    new "我们需要你的精液，现在！我们需要净化自己。"

translate chinese chinese_9291788_77:
    old "Oh, oh, it's my turn! It's my turn!"
    new "哦，哦，轮到我了！轮到我了！"

translate chinese chinese_2842188_78:
    old "I'm sorry, my dear, But you must stay a virgin until marriage."
    new "对不起，亲爱的，但你必须保持童贞直到结婚。"

translate chinese chinese_6295730_79:
    old "W- what the fuck!? But you already had sex with him!"
    new "W- 妈的！但这都已经和他做过了！"

translate chinese chinese_3435819_80:
    old "Yes, my dear, I'm a widow..."
    new "是的，亲爱的，我是个寡妇……"

translate chinese chinese_4195802_81:
    old "Don't worry Mrs. Jones I have an idea..."
    new "别担心，琼斯夫人，我有个主意……"

translate chinese chinese_6290174_82:
    old "Wow! it feels great."
    new "哇！感觉真好。"

translate chinese chinese_6911263_83:
    old "Ohhh yeahh, Fuck! This is good!... Thanks sister."
    new "噢哦 yeah 去操！这感觉真好……谢谢姐姐。"

translate chinese chinese_5431447_84:
    old "Enjoy it honey..."
    new "享受吧，宝贝..."

translate chinese chinese_6929130_85:
    old "You are welcome, we all can get closer to God with [pla]'s help."
    new "不客气，有了[pla]的帮助，我们都能更接近上帝。"

translate chinese chinese_1522950_86:
    old "Faster, I need it fater!"
    new "快点，我要更快！"

translate chinese chinese_8237216_87:
    old "We need you to do more..."
    new "我们需要你做得更多……"

translate chinese chinese_8207076_88:
    old "The three of us need to get enough of you... Please, keep going!"
    new "我们三个需要得到足够的你……请继续！"

translate chinese chinese_5545827_89:
    old "Don't stop!"
    new "不要停！"

translate chinese chinese_8844966_90:
    old "Yeah, yeah, yeah... Just like this!"
    new "嗯嗯嗯……就這樣對了！"

translate chinese chinese_5579508_91:
    old "Oh God! Woww!"
    new "哦天啊！好厉害！"

translate chinese chinese_2808772_92:
    old "Ahhh! Your cock is so damn good!"
    new "啊hhh！你的家伙真棒！"

translate chinese chinese_6490034_93:
    old "I mean... So divine and big... Ahhh!"
    new "我意思是……这么神圣又这么大……啊hhh！"

translate chinese chinese_7552243_94:
    old "I feel your sacred milk..."
    new "我感觉到你的神圣牛奶..."

translate chinese chinese_0547807_95:
    old "Hmm, big load! Ahhh"
    new "嗯，好大一股！啊hhh"

translate chinese chinese_5561241_96:
    old "This is more than enough for the three of us... But we want more..."
    new "这已经足够我们三个了……但是我们想要更多……"

translate chinese chinese_4779491_97:
    old "Your cock is so big and good!"
    new "你的棒棒这么大这么好！"

translate chinese chinese_1004747_98:
    old "Yeah... This is what my soul was asking for..."
    new "是啊……这就是我的灵魂所渴望的……"

translate chinese chinese_0040844_99:
    old "Uhhh... It's a divine cock... So good..."
    new "呃……是神屌……真爽……"

translate chinese chinese_1448028_100:
    old "I wanna taste you more and more!"
    new "我想越来越品尝你！"

translate chinese chinese_5852911_101:
    old "Fuck her... She needs more [pla], she wants more of your-"
    new "操她...她需要更多的[pla]，她想要更多你的-"

translate chinese chinese_3396342_102:
    old "Of your massive and saint cock..."
    new "你那巨大的圣 cock..."

translate chinese chinese_2908047_103:
    old "Fuck, I need it too.."
    new "妈的，我也需要……"

translate chinese chinese_1284628_104:
    old "We want your cum in our mouths..."
    new "我们想要你的精液在嘴里..."

translate chinese chinese_1699913_105:
    old "Oh yes hun, give it to us!"
    new "哦，是的，宝贝，给我！"

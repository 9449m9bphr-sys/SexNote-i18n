# auto-tl Qwen Colab

translate chinese chinese_2993260_0:
    old "You're definitely very good at this, I can start to feel much more energy inside of me..."
    new "你确实很擅长这个，我开始感觉到体内有更多的能量了..."

translate chinese chinese_5387927_1:
    old "Hmm... T- Thanks."
    new "嗯……谢谢。"

translate chinese chinese_2742991_2:
    old "Does it feels good, Huhh?"
    new "感觉不错吧，嗯？"

translate chinese chinese_3759514_3:
    old "Y- yes... It feels great..."
    new "是的……感觉好极了……"

translate chinese chinese_1735799_4:
    old "Come one, I want to suck every drop that comes out of you."
    new "来吧，我想吸光你流出的每一滴。"

translate chinese chinese_5598667_5:
    old "Oh God..."
    new "哦，天哪……"

translate chinese chinese_4904084_6:
    old "Yes, yes! Give it to me!"
    new "对，对！给我！"

translate chinese chinese_5343249_7:
    old "Alright, it's my time to ride you..."
    new "好了，现在轮到我骑你了..."

translate chinese chinese_1858042_8:
    old "I want you to drill me, like you did with that girl."
    new "我想让你好好训我一顿，就像你对付那个女孩那样。"

translate chinese chinese_6441988_9:
    old "Wow... You're so good at this."
    new "wow... 你真擅长这个。"

translate chinese chinese_8556973_10:
    old "I love it! Don't stop... Don't Stop..."
    new "我爱你这样做！不要停...不要停..."

translate chinese chinese_4862045_11:
    old "Ahhh.... Ahhh...."
    new "啊hhh.... 啊hhh...."

translate chinese chinese_5181802_12:
    old "I can feel all your energy entering my body..."
    new "我能感觉到你的能量正在进入我的身体……"

translate chinese chinese_3537013_13:
    old "Ahhhhh... I want more."
    new "啊啊啊……我要更多。"

translate chinese chinese_7686225_14:
    old "More give me more! Harder! HARDER!"
    new "更多！给我更多！更用力！更用力！"

translate chinese chinese_9675012_15:
    old "Oh yeahh cum inside me! Give me all your load!"
    new "哦 yeah 在我里面射吧！把所有的东西都给我！"

translate chinese chinese_3466475_16:
    old "Wow... What are you doing? Why are you tying me up?"
    new "哇……你在干什么？为什么绑我？"

translate chinese chinese_7693742_17:
    old "I like to play a little while I share my energy with you."
    new "我喜欢一边玩一边把我的能量分享给你。"

translate chinese chinese_7541376_18:
    old "Ohhh, It's great to feel so much energy when I'm with you."
    new "哦，和你在一起的时候感觉充满活力真是太好了。"

translate chinese chinese_5709759_19:
    old "Yes! Yes! I can feel all your energy inside me!"
    new "是的！是的！我能感受到你所有的能量在我体内！"

translate chinese chinese_1422609_20:
    old "Don't stop, don't stop!"
    new "不要停，不要停！"

translate chinese chinese_0424950_21:
    old "Oh, that was fun, isn't?"
    new "哦，那真好玩，不是吗？"

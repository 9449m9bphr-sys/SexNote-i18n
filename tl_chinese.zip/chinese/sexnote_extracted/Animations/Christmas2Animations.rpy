# auto-tl Qwen Colab

translate chinese chinese_7232903_0:
    old "God! Your cock's always so tasty!"
    new "天啊！你的棒棒总是这么美味！"

translate chinese chinese_5963995_1:
    old "Screw Christmas cookies, this is the treat I wanted!"
    new "管它什么圣诞饼干，这才是我想要的待遇！"

translate chinese chinese_6971897_2:
    old "I bet this is the best way you've ever woken up!"
    new "我敢打赌，这是你有史以来最好的起床方式了！"

translate chinese chinese_1598406_3:
    old "Oh yes! I love the way it feels in my mouth!"
    new "哦 yeah！我喜欢它在我嘴里感觉！"

translate chinese chinese_7605060_4:
    old "Do you like to stuff your dick in my mouth in the morning [pla]?"
    new "你早上喜欢把 dicks 塞进我嘴里吗 [pla]?"

translate chinese chinese_6667544_5:
    old "Do you?!"
    new "你真的吗？！"

translate chinese chinese_2616647_6:
    old "Y- yes!"
    new "是的！"

translate chinese chinese_8000110_7:
    old "Oh! I love this!"
    new "哦！我超爱这个的！"

translate chinese chinese_5318352_8:
    old "Mmf! The taste!"
    new "嗯！这味道！"

translate chinese chinese_2820715_9:
    old "Keep going"
    new "继续"

translate chinese chinese_3582028_10:
    old "Lydia! I- I think I'm about to cum!"
    new "莉迪亚！我——我觉得我要来了！"

translate chinese chinese_7572132_11:
    old "Yes! Do it! Stuff my mouth with your hot cum!"
    new "没错！来吧！用你的热精液堵住我的嘴！"

translate chinese chinese_6062843_12:
    old "Merry Christmas to me!"
    new "祝我圣诞快乐！"

translate chinese chinese_1526768_13:
    old "That was wonderful [pla]!"
    new "那真是太棒了[pla]！"

translate chinese chinese_5734893_14:
    old "What the hell are you talking about?!"
    new "你他妈在说什么?!"

translate chinese chinese_5014201_15:
    old "You shouldn't just come into my room and do something like that!"
    new "你不应该随便进我的房间做这种事！"

translate chinese chinese_2605857_16:
    old "What if somebody sees you?!"
    new "要是被人看到了怎么办？！"

translate chinese chinese_0665443_17:
    old "Oh! Relax! You're worrying too much."
    new "哦！放松点！你太紧张了。"

translate chinese chinese_6402395_18:
    old "Nobody saw anything."
    new "没人看到什么。"

translate chinese chinese_5513039_19:
    old "And I know you loved it."
    new "而且我知道你很喜欢。"

translate chinese chinese_3566379_20:
    old "Hmm, well..."
    new "嗯，那个……"

translate chinese chinese_1155301_21:
    old "Whatever."
    new "随便吧。"

translate chinese chinese_8744879_22:
    old "Mmm! Oh my god! Your dick!"
    new "嗯！天啊！你的棒！"

translate chinese chinese_2044551_23:
    old "It's great! I can feel its heat!"
    new "太棒了！我能感觉到它的热度！"

translate chinese chinese_3513894_24:
    old "And also, it's sooo long!"
    new "而且，它长惨了！"

translate chinese chinese_5038707_25:
    old "What do you think [pla]? Don't you think this fabric's soft?"
    new "你觉得[pla]，这布料不柔软吗？"

translate chinese chinese_1880665_26:
    old "It- it is... really soft!"
    new "它——真的好软！"

translate chinese chinese_8721866_27:
    old "I know, right?"
    new "我知道，对吧？"

translate chinese chinese_4123462_28:
    old "It's really good quality!"
    new "质量真不错！"

translate chinese chinese_9368504_29:
    old "Ah! Ah! I love this!"
    new "啊！啊！我就喜欢这个！"

translate chinese chinese_8008084_30:
    old "I can feel your dick rubbing my clit!"
    new "我能感觉到你的 dicks 摩擦着我的 clits！"

translate chinese chinese_1455933_31:
    old "And with this fabric, it feels so good!"
    new "而且这种布料摸起来真舒服！"

translate chinese chinese_9716361_32:
    old "[sis]! I- I'm about to cum!"
    new "[sis]！我快来了！"

translate chinese chinese_6230253_33:
    old "Do it, shoot it all out!"
    new "来吧，全部射进去！"

translate chinese chinese_0039368_34:
    old "Don't worry about the costume!"
    new "别担心那个 cosplay 了！"

translate chinese chinese_6759703_35:
    old "This fabric is anti-fluid!"
    new "这种布料是防水的！"

translate chinese chinese_0614154_36:
    old "Shoot it all out!"
    new "全射光吧！"

translate chinese chinese_1400661_37:
    old "Oh my god! Look at all that thick load coming of your dick."
    new "天啊！看看你那根上流出的满满精液。"

translate chinese chinese_3505145_38:
    old "... Right."
    new "... 对。"

translate chinese chinese_8824919_39:
    old "I just loved the way your dick rubbed againts my clit!"
    new "我就是喜欢你的 dicks 摩擦我的 clit 的感觉！"

translate chinese chinese_0884150_40:
    old "It turned me on so much!"
    new "那真的让我超级兴奋！"

translate chinese chinese_3943746_41:
    old "Ok, I think these new outfits are ready to be posted!"
    new "好的，我觉得这些新衣服可以发布了！"

translate chinese chinese_1457988_42:
    old "Oh yes! This lube is perfect!"
    new "哦，是的！这个润滑剂perfect！"

translate chinese chinese_4970088_43:
    old "Just look at how your dick slides between our tits!"
    new "看看你的 dicks 在我们胸部之间滑动的样子！"

translate chinese chinese_2151984_44:
    old "And it feels so hot!"
    new "而且热死了！"

translate chinese chinese_3206520_45:
    old "Do you like how that feels [pla]?"
    new "你喜欢这种感觉吗，[pla]？"

translate chinese chinese_6507854_46:
    old "I- I do! It's great!"
    new "我——我有！太棒了！"

translate chinese chinese_3148528_47:
    old "That's great baby! I love that you love it!"
    new "太好了宝贝！我爱你这么喜欢它！"

translate chinese chinese_3086373_48:
    old "Do it faster [pla]! Use that lube!"
    new "快点做，[pla]！用点润滑剂！"

translate chinese chinese_5906925_49:
    old "Oh! Yes! I love the way your cock bounces between our tits!"
    new "哦！是的！我喜欢你的 cock 在我们胸部之间弹跳的样子！"

translate chinese chinese_4889314_50:
    old "My god [mo2]! This lube is fantastic!"
    new "天啊[mo2]！这个润滑剂太棒了！"

translate chinese chinese_0117818_51:
    old "It feels great!"
    new "感觉真好！"

translate chinese chinese_5036369_52:
    old "How much do you like this [pla]?"
    new "你有多喜欢这个[pla]？"

translate chinese chinese_3361480_53:
    old "Tell us!"
    new "告诉我们！"

translate chinese chinese_7637150_54:
    old "I- I love it!"
    new "我——我爱死它了！"

translate chinese chinese_8315771_55:
    old "I- I'm about to cum!"
    new "我快来了！"

translate chinese chinese_4217096_56:
    old "I can't hold it in anymore!"
    new "我忍不住了！"

translate chinese chinese_0846010_57:
    old "Do it honey!"
    new "来吧，宝贝！"

translate chinese chinese_8461242_58:
    old "Yes! Do it [pla]! Cum for us!"
    new "没错！来吧[pla]！为我们射吧！"

translate chinese chinese_0207007_59:
    old "Make it a white Christmas for us [pla]!"
    new "给我们来个白色圣诞吧[pla]！"

translate chinese chinese_2193636_60:
    old "Oh that's just great! I love the way your cum tastes [pla]!"
    new "哦，太好了！我超爱你的精液味道的，[pla]！"

translate chinese chinese_2871042_61:
    old "It's so thick and warm."
    new "它又浓又暖。"

translate chinese chinese_1082501_62:
    old "Uhgn! Oh my God [pla]!"
    new "呃嗯！天啊[pla]！"

translate chinese chinese_9596201_63:
    old "How are you this big!"
    new "你怎么会长这么大的！"

translate chinese chinese_6617599_64:
    old "It feels even bigger than the way it looks!"
    new "感觉比看起来还要大！"

translate chinese chinese_3672503_65:
    old "God! I love the way your dick feels me up!"
    new "上帝！我喜欢你的棒棒抚摸我的感觉！"

translate chinese chinese_2310516_66:
    old "It's so hot!"
    new "好热啊！"

translate chinese chinese_1788699_67:
    old "Keep going [pla]! Don't stop!"
    new "继续[pla]！不要停！"

translate chinese chinese_7995449_68:
    old "Oh my God! Oh my God!"
    new "天啊！天啊！"

translate chinese chinese_6225366_69:
    old "Y- You're so hot [pla]!"
    new "你、你真性感[pla]！"

translate chinese chinese_9834617_70:
    old "This is the best Christmas gift ever!"
    new "这是有史以来最好的圣诞礼物！"

translate chinese chinese_5170415_71:
    old "Oh my God! I love the way you fuck me!"
    new "天啊！我爱你做爱的方式！"

translate chinese chinese_0568100_72:
    old "[sis] I- I think I'm about to cum! I can't hold it back anymore!"
    new "[sis] 我——我觉得我要射了！我忍不住了！"

translate chinese chinese_9209327_73:
    old "Y- Yes! D- D- Do it!"
    new "是、是的！做、做吧！"

translate chinese chinese_8953356_74:
    old "Yes! Do it! Cum inside your [sisrel]! You little pervert!"
    new "没错！干吧！射到你的[sisrel]里去！你这个小色鬼！"

translate chinese chinese_4704687_75:
    old "Oh wow! That was so good!"
    new "哦 wow！太棒了！"

translate chinese chinese_9542332_76:
    old "Honestly [pla], your cock must be magical!"
    new "说实话，[pla]，你的鸡巴一定是魔幻的！"

translate chinese chinese_7455654_77:
    old "Because it's insane how crazy good it is!"
    new "因为它好到疯狂的地步！"

translate chinese chinese_4296001_78:
    old "Well, that was the best Christmas gift I think I could've asked for."
    new "嗯，这大概是今年圣诞节我能收到的最好的礼物了。"

translate chinese chinese_3914027_79:
    old "Even though I was such a naughty girl all year."
    new "虽然我这一年一直都很调皮。"

translate chinese chinese_0668271_80:
    old "I bet you've been waiting to fuck me!"
    new "我敢打赌，你一定等不及想跟我上床了！"

translate chinese chinese_5156462_81:
    old "Well, you finally get your gift!"
    new "好了，你终于拿到你的礼物了！"

translate chinese chinese_8932903_82:
    old "My pussy's been aching for a hard big cock!"
    new "我的 pussy 已经渴望一个大硬棒了！"

translate chinese chinese_4200030_83:
    old "Mmm! Oh yeah!"
    new "嗯！哦 yeah！"

translate chinese chinese_1315724_84:
    old "That's just the thing I wanted for Christmas!"
    new "这正是我圣诞节想要的东西！"

translate chinese chinese_0640585_85:
    old "So big!"
    new "好大！"

translate chinese chinese_0467522_86:
    old "The girth is just amazing!"
    new "那尺寸真是惊人！"

translate chinese chinese_0002739_87:
    old "I bet you like this, don't you?"
    new "我打赌你挺喜欢这个的，对吧？"

translate chinese chinese_4712994_88:
    old "You like fucking me like an animal?"
    new "你喜欢像动物一样干我吗？"

translate chinese chinese_1669677_89:
    old "Tell me!"
    new "告诉我！"

translate chinese chinese_9097129_90:
    old "I- I do! I like it a lot!"
    new "我——我喜欢！很喜欢！"

translate chinese chinese_7851571_91:
    old "Oh- OH! You little bastard!"
    new "哦——噢！你这个小混蛋！"

translate chinese chinese_8433905_92:
    old "You little pathetic slave! The only good thing about you is that long cock!"
    new "你这可怜的小奴隶！你身上唯一好的地方就是那根长屌！"

translate chinese chinese_7337972_93:
    old "You hear me? You're worthless without it!"
    new "听见没有？没了它你就一文不值！"

translate chinese chinese_3482716_94:
    old "Your cock and balls are only good for this!"
    new "你的鸡巴和蛋只配这个！"

translate chinese chinese_6924827_95:
    old "Keep going! Keep fucking me! You worthless slave!"
    new "继续！继续操我！你这个没用的奴隶！"

translate chinese chinese_7472254_96:
    old "I- AH! I can feel your cock twitching!"
    new "我——啊！我能感觉到你的家伙在动！"

translate chinese chinese_8280919_97:
    old "Are you about to cum, you little pervert?!"
    new "你要射了啊，小色鬼！"

translate chinese chinese_0521897_98:
    old "I- ugh! I am!"
    new "我——哎！我是的！"

translate chinese chinese_5924047_99:
    old "Do it! Fill me with your worthless cum!"
    new "来吧！用你那无用的精液填满我！"

translate chinese chinese_4440969_100:
    old "Wow [mo2], baby, that looked fantastic!"
    new "哇[mo2]，宝贝，那看起来棒极了！"

translate chinese chinese_6952382_101:
    old "I guess it was good."
    new "我想还不错。"

translate chinese chinese_8977450_102:
    old "I bet you're happy you get to fuck your [mo1rel] on Christmas day, you little pervert."
    new "我敢打赌，你一定很高兴能在圣诞节和你的[mo1rel]鬼混，小色鬼。"

translate chinese chinese_8806229_103:
    old "Y-yeah, sure."
    new "嗯，好吧。"

translate chinese chinese_9919068_104:
    old "Oh my god, honey!"
    new "天啊，亲爱的！"

translate chinese chinese_8027272_105:
    old "Y- Your dick, is so big!"
    new "你那个，好大啊！"

translate chinese chinese_7092933_106:
    old "It's so hot! So thick!"
    new "好热啊！好黏啊！"

translate chinese chinese_8008857_107:
    old "Oh my god I love it!"
    new "天啊，我爱死它了！"

translate chinese chinese_2856484_108:
    old "I love to feel you filling me up!"
    new "我爱感受你填满我的感觉！"

translate chinese chinese_2005427_109:
    old "D- Do you like it too [pla]?"
    new "D- 你 тоже喜欢吗 [pla]?"

translate chinese chinese_1263736_110:
    old "I do! I like it!"
    new "我喜欢！我喜欢！"

translate chinese chinese_1702219_111:
    old "Oh then keep going, honey!"
    new "哦，那继续吧，宝贝！"

translate chinese chinese_0480901_112:
    old "Oh yes! Yes! YES!"
    new "哦 yeah! 是的! 是的!"

translate chinese chinese_8394287_113:
    old "This is what I wanted!"
    new "这就是我想要的！"

translate chinese chinese_7380767_114:
    old "I bet this makes a very merry Christmas for you, doesn't it [mo1]?"
    new "这肯定让你的圣诞节非常快乐，对吧，[mo1]？"

translate chinese chinese_4507247_115:
    old "It does! this is the best Christmas ever!"
    new "是啊！这是我过得最好的圣诞节了！"

translate chinese chinese_4452770_116:
    old "I- I think I'm coming!"
    new "我——我要来了！"

translate chinese chinese_1680393_117:
    old "Come with me [pla]!"
    new "跟我来[pla]！"

translate chinese chinese_4959398_118:
    old "L- Let's do it together!"
    new "L- 我们一起做吧！"

translate chinese chinese_8521154_119:
    old "Y- Yes!"
    new "是的！"

translate chinese chinese_7802609_120:
    old "Oh baby. That was the best Christmas gift ever!"
    new "哦宝贝。那是我收到过的最好的圣诞礼物！"

translate chinese chinese_0839334_121:
    old "It's amazing, I'm so satisfied!"
    new "太棒了，我超级满意！"

translate chinese chinese_1656391_122:
    old "Isn't he just a wonderful young man?"
    new "他不是个很棒的小伙子吗？"

translate chinese chinese_7756767_123:
    old "Your dick is so addicting!"
    new "你的棒棒太上头了！"

translate chinese chinese_4792306_124:
    old "Well, I've been wanting to fuck you since the morning sweety!"
    new "好吧，我从早上就开始想肏你了，甜心！"

translate chinese chinese_3838766_125:
    old "I couldn't keep waiting!"
    new "我等不及了！"

translate chinese chinese_4757588_126:
    old "Oh! Uh! My God! It already feels amazing!"
    new "哦！啊！天哪！感觉已经太棒了！"

translate chinese chinese_7973396_127:
    old "I- Mmm! I can't believe how big and hard you are!"
    new "我—嗯！没想到你这么大这么硬！"

translate chinese chinese_9365720_128:
    old "I- It's so amazing!"
    new "太棒了！"

translate chinese chinese_3629798_129:
    old "It's incredible how much it fills you up, right?"
    new "它能给你带来这么多，对吧？"

translate chinese chinese_1381408_130:
    old "It is!"
    new "是的！"

translate chinese chinese_6508196_131:
    old "I- I love your cock!"
    new "我……我爱你的棒！"

translate chinese chinese_7150426_132:
    old "It seems you weren't a naughty girl this year Lydia."
    new "看来你今年没做坏事啊，莉迪亚。"

translate chinese chinese_2803378_133:
    old "Because look at the gift Santa brought you!"
    new "因为看看圣诞老人给你带来的礼物！"

translate chinese chinese_9395404_134:
    old "Y- Yes! I love it!"
    new "是的！我喜欢！"

translate chinese chinese_8371587_135:
    old "YES! YES! YES!"
    new "是的！是的！是的！"

translate chinese chinese_2642676_136:
    old "Keep going [pla]! Oh yes!"
    new "继续啊[pla]！哦 yeah！"

translate chinese chinese_9069913_137:
    old "Oh! Ah! My God! I love it!"
    new "哦！啊！天啊！我爱死这个了！"

translate chinese chinese_5414238_138:
    old "That's it [pla]! Fuck her brains out!"
    new "就是你了，[pla]！把她搞疯了算了！"

translate chinese chinese_4746749_139:
    old "I feel you're close to cum!"
    new "我觉得你快来了！"

translate chinese chinese_4360258_140:
    old "I want you to do it!"
    new "我要你来做！"

translate chinese chinese_3159347_141:
    old "Fill me up with your hot cum!"
    new "用你的热精液填满我！"

translate chinese chinese_2220679_142:
    old "God! That was so good [pla]!"
    new "天啊！那真是太棒了[pla]！"

translate chinese chinese_7541335_143:
    old "Your dick is so hot!"
    new "你的棒棒好热啊！"

translate chinese chinese_0701591_144:
    old "You know, I think it would be easy to get addicted to it."
    new "你知道吗，我觉得很容易就会上瘾。"

translate chinese chinese_5152778_145:
    old "I- I see."
    new "我明白了。"

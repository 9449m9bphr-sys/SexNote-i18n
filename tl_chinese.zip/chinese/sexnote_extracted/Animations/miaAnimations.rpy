# auto-tl Qwen Colab

translate chinese chinese_5931242_0:
    old "Mmm! Oh wow."
    new "嗯！哦 wow。"

translate chinese chinese_3606344_1:
    old "This is very different."
    new "这很不一样。"

translate chinese chinese_0569530_2:
    old "Don’t stop."
    new "别停。"

translate chinese chinese_2777779_3:
    old "I- I wasn’t expecting this. This sensation."
    new "我——我没料到会这样。这种感觉。"

translate chinese chinese_6776049_4:
    old "Oh, I’m more than ok."
    new "哦，我可不止是还好。"

translate chinese chinese_5797030_5:
    old "Do it faster."
    new "快点做。"

translate chinese chinese_7067578_6:
    old "AH, yes, like that, keep going!"
    new "啊，对，就是这样，继续！"

translate chinese chinese_7982909_7:
    old "I- feel..."
    new "我……感觉……"

translate chinese chinese_2698874_8:
    old "Don’t stop! KEEP GOING!"
    new "不要停！继续！"

translate chinese chinese_0277381_9:
    old "I think I can’t hold it back anymore!"
    new "我觉得我再也忍不住了！"

translate chinese chinese_4640687_10:
    old "Let it go, cum inside me!"
    new "别忍了，射里面吧！"

translate chinese chinese_9165096_11:
    old "I want you to give that magic power!"
    new "我要你给我那股魔力！"

translate chinese chinese_2316012_12:
    old "Oh yes!"
    new "哦，是的！"

translate chinese chinese_6950049_13:
    old "Oh my! That was fantastic!"
    new "哦我的天！那真是太棒了！"

translate chinese chinese_6210647_14:
    old "Linnet had told me about it, but this is just another level!"
    new "林内特告诉过我，但这完全是另一个层次！"

translate chinese chinese_2796276_15:
    old "We have to try this again!"
    new "我们必须再试一次！"

translate chinese chinese_9747625_16:
    old "Are you insane?"
    new "你疯了吗？"

translate chinese chinese_5090142_17:
    old "We were already at risk doing it here, in the classroom."
    new "我们在教室里做这件事就已经很危险了。"

translate chinese chinese_0449830_18:
    old "We need to leave before someone comes... But help me clean her first."
    new "我们需要在有人来之前离开……但是先帮我处理一下她。"

translate chinese chinese_2214618_19:
    old "You say you don’t know what’s happening, yet you still have this boner."
    new "你说你不知道发生了什么，可你还硬着呢。"

translate chinese chinese_9568760_20:
    old "W- well, t- that’s just because..."
    new "嗯，那个，那只是因为..."

translate chinese chinese_0642397_21:
    old "Spare me, will you?"
    new "拜托，饶了我吧？"

translate chinese chinese_3457031_22:
    old "I just need you to finish, I’ll go faster."
    new "我只需要你完成，我会快点的。"

translate chinese chinese_4046619_23:
    old "You’re fucking disgusting for doing this, you know? To force me this way."
    new "你知道这样做有多恶心吗？强迫我这么做。"

translate chinese chinese_8985461_24:
    old "I- I already said I don’t know what are you talking abut."
    new "我——我已经说了，我不知道你在说什么。"

translate chinese chinese_0237702_25:
    old "Sure... I guess this boner is just because I’m pretty, right? You are sick!"
    new "好吧……我猜这硬起来只是因为我觉得好看而已，对吧？你真是变态！"

translate chinese chinese_7352141_26:
    old "Will you just finish already?"
    new "你赶紧搞定吧？"

translate chinese chinese_6213444_27:
    old "I just can’t believe you’d stood up this low."
    new "我真不敢相信你会这么卑鄙。"

translate chinese chinese_0559891_28:
    old "I will never forgive this, and I’ll make sure you pay for this."
    new "我永远不会原谅这件事，我会确保你为此付出代价。"

translate chinese chinese_6729778_29:
    old "Don’t you think for a single second that you’ll pull this shit again."
    new "别想着再玩这套把戏。"

translate chinese chinese_5961555_30:
    old "M-Miss Mia, if you keep going, I-I’ll...!"
    new "米娅小姐，如果你再继续的话，我我就会...！"

translate chinese chinese_4156064_31:
    old "Fucking finally!"
    new "妈的，终于！"

translate chinese chinese_6033967_32:
    old "Finish quickly will you? I don’t want to keep touching your dick."
    new "快点结束行不行？我不想一直摸你的丁丁。"

translate chinese chinese_0370788_33:
    old "Ughhh... This is so gross..."
    new "呃……这真是太恶心了……"

translate chinese chinese_1958799_34:
    old "Anyway, let's finish this shit."
    new "不管怎样，先把这事搞定吧。"

translate chinese chinese_2244638_35:
    old "W- What? Now what?"
    new "什、什么？现在怎么了？"

translate chinese chinese_2001146_36:
    old "What the hell was that?"
    new "那到底是怎么回事？"

translate chinese chinese_8722888_37:
    old "Why did you suddenly do that?"
    new "你突然那样做干嘛？"

translate chinese chinese_9040474_38:
    old "I see you’re planning on keeping this up, huh?"
    new "我看你是打算继续这样下去了，是吗？"

translate chinese chinese_9955664_39:
    old "You know [pla], I always thought you were an idiot."
    new "你知道[pla]，我一直觉得你是个白痴。"

translate chinese chinese_3459410_40:
    old "But I never thought you’d be the kind of disgusting cockroach that would do this type of shit."
    new "但我没想到你会是这种恶心的蟑螂，干出这种事来。"

translate chinese chinese_0740173_41:
    old "Yeah that’s right, get his dick in your mouth."
    new "没错，把他家伙含进嘴里。"

translate chinese chinese_9684710_42:
    old "Like the whore you are."
    new "就跟你这婊子一样的。"

translate chinese chinese_1412064_43:
    old "S- shut up!"
    new "别说了！"

translate chinese chinese_3387250_44:
    old "You must be enjoying this, aren’t you?"
    new "你肯定很享受这个，对吧？"

translate chinese chinese_9312344_45:
    old "Pfff..."
    new "呼……"

translate chinese chinese_4148967_46:
    old "You little whore, look at how you do that."
    new "你这小贱人，看看你那样子。"

translate chinese chinese_1453112_47:
    old "It must be your experience from all the cocks you’ve sucked."
    new "这肯定是你吸过那么多棒子的经验。"

translate chinese chinese_5797044_48:
    old "Tell me Mia, how much are you enjoying this?"
    new "告诉我是多么享受这个，米娅。"

translate chinese chinese_4914309_49:
    old "Glurpp... F- fuck you!"
    new "咕噜... 去你的！"

translate chinese chinese_8888283_50:
    old "Ha, you’re gagging on cock and you’re telling me to shut up?"
    new "哈哈，你在吞cock还让我闭嘴呢？"

translate chinese chinese_6469893_51:
    old "I see you’re about to finish [pla], that’s good, that’s good."
    new "我看到你快要完成[pla]了，很好，很好。"

translate chinese chinese_3385301_52:
    old "Why don’t you go ahead and cum in her mouth?"
    new "为什么不直接在她嘴里射呢？"

translate chinese chinese_5863997_53:
    old "Don't worry, she'll swallow it all, that's what she used to do."
    new "别担心，她会全盘接受的，她以前就是这样的。"

translate chinese chinese_9003350_54:
    old "You better drink every drop Mia, that’s an order."
    new "米娅，你最好把每一滴都喝了，这是命令。"

translate chinese chinese_2343512_55:
    old "Are you ok Miss Mia?"
    new "米娅小姐，你还好吗？"

translate chinese chinese_8926274_56:
    old "Ohh, yes, I’m fine, just let me gather my bearings for a second."
    new "哦，好的，我没事，just让我稍微调整一下。"

translate chinese chinese_2546717_57:
    old "I’m sorry, for finishing in your mout-... I mean for everything."
    new "对不起，说完就在你嘴…我是说，对不起，这一切。"

translate chinese chinese_5030098_58:
    old "That asshole is the one who made us do this."
    new "那个混蛋才是让我们这么做的主使人。"

translate chinese chinese_3058134_59:
    old "Oh! Nghn!"
    new "哦！嗯嗯！"

translate chinese chinese_8624540_60:
    old "Ha, what’s the matter Ms? Is it too big for you?"
    new "哈，怎么了，小姐？是不是太大了？"

translate chinese chinese_6052842_61:
    old "But you’re so experienced! Come on! I know you can take it all!"
    new "但你经验这么丰富！来吧！我知道你能搞定的！"

translate chinese chinese_9281597_62:
    old "Hey [pla]! You’re fucking your teacher that always tormented you!"
    new "嘿[pla]！你竟然和那个总是折磨你的老师上床了！"

translate chinese chinese_2627709_63:
    old "I bet it must feel really nice, huh?"
    new "肯定感觉很舒服吧？"

translate chinese chinese_5047922_64:
    old "I know you wanted to do this bro! She’s been messing with you after all."
    new "我知道你想这么干的兄弟！她毕竟一直在惹你。"

translate chinese chinese_5118771_65:
    old "That’s it, fuck her like the whore she is!"
    new "就是现在，把她当成荡妇一样干吧！"

translate chinese chinese_6236674_66:
    old "How do you feel Ms. Mia?"
    new "米娅小姐，你觉得怎么样？"

translate chinese chinese_5977506_67:
    old "I bet you like having his big cock inside!"
    new "我打赌你喜欢他那大屌在里面的感觉！"

translate chinese chinese_8887942_68:
    old "Just like the old days, huh?"
    new "就像老时候一样，对吧？"

translate chinese chinese_8233004_69:
    old "S- Mmm! Shut up!"
    new "S- 哼！闭嘴！"

translate chinese chinese_5843230_70:
    old "M-Miss Mia, I think - I think I’m..."
    new "米娅小姐，我觉…我觉得我…"

translate chinese chinese_4927665_71:
    old "Yeah! That’s it [pla], fill her up!"
    new "没错！就是这样，[pla]，加油！"

translate chinese chinese_0916122_72:
    old "Fill that pussy up with cum!"
    new "把那里面填满精液！"

translate chinese chinese_1271129_73:
    old "A-are you ok Miss Mia?"
    new "米娅小姐，你、你还好吗？"

translate chinese chinese_9987772_74:
    old "I’m sorry."
    new "对不起。"

translate chinese chinese_9839853_75:
    old "It’s ok, you shouldn’t have to apologize."
    new "没关系，你不用道歉。"

translate chinese chinese_5399654_76:
    old "You’re also a victim here."
    new "你在这里也是受害者。"

translate chinese chinese_1127728_77:
    old "You’re actually a big help."
    new "你真的帮了大忙。"

translate chinese chinese_7884721_78:
    old "Yeah, you probably missed that dick, didn’t you Mia?"
    new "yeah, 你肯定很想念那个家伙吧，mia？"

translate chinese chinese_0685932_79:
    old "Answer me Mia!"
    new "回答我，米娅！"

translate chinese chinese_0824632_80:
    old "Y- Nghn! Mmm! Y-Yeah I do!"
    new "嗯！嗯！是的，我……"

translate chinese chinese_2615446_81:
    old "I bet you like fucking in the bathroom!"
    new "我敢打赌你肯定喜欢在厕所做爱！"

translate chinese chinese_7478526_82:
    old "You like that you almost got caught, don’t you Mia?"
    new "你喜欢差点被抓住的感觉，对吧，米娅？"

translate chinese chinese_9687472_83:
    old "Is exciting isn’t it?"
    new "挺刺激的吧？"

translate chinese chinese_9016290_84:
    old "I can’t hear you!"
    new "我听不见你说话！"

translate chinese chinese_5811546_85:
    old "Y-yes! Ah! Is... Ah! Very exciting!"
    new "是的！啊！很...啊！非常刺激！"

translate chinese chinese_9337750_86:
    old "I see you’re about to finish [pla]."
    new "我看到你快要完成[pla]了。"

translate chinese chinese_9767171_87:
    old "It’s ok dude, let it out!"
    new "没事兄弟，发泄一下吧！"

translate chinese chinese_2759346_88:
    old "I want you to fill her pussy up!"
    new "我要你填满她的 pussy！"

translate chinese chinese_6264074_89:
    old "M-Miss Mia, I- I’m about to...!"
    new "米娅小姐，我……要忍不住了！"

translate chinese chinese_6705623_90:
    old "J-just do it!"
    new "快点做就行了！"

translate chinese chinese_4491293_91:
    old "Well guys, I would say that was perfect! Don’t you agree?"
    new "好吧，我觉得这简直是完美！你们不这么认为吗？"

translate chinese chinese_8550634_92:
    old "Hahahaha, you can really tell Mia has some experience in front of the camera."
    new "哈哈哈哈哈，看得出来米娅在镜头前很有经验。"

translate chinese chinese_7611780_93:
    old "You too [pla], you’re a natural dude!"
    new "你也是啊，[pla]，你真是太棒了！"

translate chinese chinese_9390823_94:
    old "Well, I think I should just leave you two little lovebirds to comfort each other."
    new "好吧，我觉得我应该让你们这两个小情人互相安慰一下。"

translate chinese chinese_2235219_95:
    old "But remember, all of this has been recorded, I don’t have to remind you what that means... Anyway, bye."
    new "但是记住，这一切都被录下来了，我不用提醒你这意味着什么吧……总之，再见。"

translate chinese chinese_1276375_96:
    old "Oh yeah! That’s it!"
    new "哦对了！就是这个！"

translate chinese chinese_0585581_97:
    old "Yes! Yes! It’s so good!"
    new "是的！是的！感觉真好！"

translate chinese chinese_6153366_98:
    old "It’s even better than a real dick!"
    new "甚至比真家伙还棒！"

translate chinese chinese_7752015_99:
    old "Ah! Ah! Yeah!"
    new "啊！啊！对！"

translate chinese chinese_5660789_100:
    old "That’s just what I wanted!"
    new "这正是我想要的！"

translate chinese chinese_0857486_101:
    old "YES!"
    new "太棒了！"

translate chinese chinese_9390138_102:
    old "Mmm, it’s so hard"
    new "嗯，好难啊"

translate chinese chinese_5334871_103:
    old "Oh! Mmm!"
    new "哦！嗯！"

translate chinese chinese_5930675_104:
    old "M-Mia, lower your voice."
    new "M-Mia，小声点。"

translate chinese chinese_9406503_105:
    old "Oh, oh fuck yeah!"
    new "哦，哦操对了！"

translate chinese chinese_9357123_106:
    old "AH! AH! AH!"
    new "啊！啊！啊！"

translate chinese chinese_8203535_107:
    old "MMMM! FUCK YEAH!"
    new "MMMM! 真的太棒了!"

translate chinese chinese_2948487_108:
    old "Well, that just cheered me up!"
    new "好吧，这真是让我开心了不少！"

translate chinese chinese_1698123_109:
    old "What a great way to start the day!"
    new "真是个美好的开始！"

translate chinese chinese_6897074_110:
    old "Oh fuck, Ah!"
    new "哦操，啊！"

translate chinese chinese_2815651_111:
    old "Yes, oh you look so fucking good."
    new "是的，哦，你看起来真他妈的好性感。"

translate chinese chinese_6944765_112:
    old "Mmmm! Ahhh! It's so big..."
    new "嗯！啊！好大……"

translate chinese chinese_4805099_113:
    old "That’s what I wanna hear."
    new "这话我就爱听。"

translate chinese chinese_6269022_114:
    old "Keep sucking bitch."
    new "继续吸，贱货。"

translate chinese chinese_3087399_115:
    old "You had to memorize these dialogues or..."
    new "你得把这些对话背下来或者..."

translate chinese chinese_7696032_116:
    old "Uhh... Something like that... That’s how it usually is in that industry."
    new "呃……差不多吧……那行当通常是这样的。"

translate chinese chinese_2283195_117:
    old "Also my moans and everything, you have to pretend it all."
    new "还有我的呻吟什么的，你都得装出来。"

translate chinese chinese_5567342_118:
    old "Mmm! Slurp! Slurp!"
    new "嗯！吸溜！吸溜！"

translate chinese chinese_2517305_119:
    old "Mmm yeah babe, it feels really nice..."
    new "嗯哼，宝贝，感觉真好……"

translate chinese chinese_5272431_120:
    old "Oh, yeah!"
    new "哦，对了！"

translate chinese chinese_7634173_121:
    old "Did you guys ever improvised the lines or anything?"
    new "你们有没有即兴发挥过台词或者其他什么的？"

translate chinese chinese_6160786_122:
    old "Yeah, the only script we had was for the set ups, but most of the time we were improvising."
    new "是的，我们只有布景的剧本，但大多数时候都是即兴发挥。"

translate chinese chinese_2434204_123:
    old "Yeah, I could kinda tell."
    new "嗯，我多少能看出来。"

translate chinese chinese_3200151_124:
    old "Oh my gosh, I can feel it reaching your throat."
    new "天啊，我能感觉到它已经到你的喉咙了。"

translate chinese chinese_0522636_125:
    old "Mmmm... Yeah baby..."
    new "嗯……对宝宝……"

translate chinese chinese_2061914_126:
    old "That’s what you wanted bitch!"
    new "这就是你想要的，贱人！"

translate chinese chinese_5914421_127:
    old "Yeah! Yeah!"
    new "是的！是的！"

translate chinese chinese_5284891_128:
    old "I love your big black cocks!"
    new "我喜欢你的大黑棒！"

translate chinese chinese_6704496_129:
    old "You know... You were very good at this."
    new "你知道吗……你这个做得很好。"

translate chinese chinese_9349134_130:
    old "Ugh! Come on! Really [pla]?"
    new "哎呀！快点！真的[pla]？"

translate chinese chinese_0745290_131:
    old "That’s what you have to say about it?"
    new "你就这么说事儿？"

translate chinese chinese_3193131_132:
    old "Sorry, sorry, you’re right, that was out of line, I was just saying."
    new "对不起，对不起，你说得对，那话确实过分了，我只是随便说说。"

translate chinese chinese_4656520_133:
    old "Yeah, yeah, I know what you mean..."
    new "嗯嗯，我知道你的意思……"

translate chinese chinese_1352257_134:
    old "Skip"
    new "跳过"

translate chinese chinese_4442326_135:
    old "Ok, that’s enough, there aren’t any more videos or anything else in the folder."
    new "好了，够了，文件夹里没有更多的视频或其他东西了。"

translate chinese chinese_7209147_136:
    old "So we don’t need to keep checking this out."
    new "所以我们不用再继续检查这个了。"

translate chinese chinese_7714175_137:
    old "Yeah, you’re right."
    new "嗯，你说得对。"

translate chinese chinese_3300318_138:
    old "I-It’s so fucking big!"
    new "它他妈的这么大！"

translate chinese chinese_7322357_139:
    old "I can’t handle it! AH!"
    new "我受不了了！啊！"

translate chinese chinese_7206494_140:
    old "That’s right baby, take that big black cock!"
    new "对了宝贝，就那样，狠狠地骑上那大黑棒！"

translate chinese chinese_5571466_141:
    old "AH! AH! AAAAH!"
    new "啊！啊！啊啊啊！"

translate chinese chinese_6484815_142:
    old "Well, they are very big."
    new "嗯，它们确实很大。"

translate chinese chinese_6858241_143:
    old "Mmm, not the biggest ever."
    new "嗯，不算最大的。"

translate chinese chinese_4610328_144:
    old "Just don’t take too much time."
    new "别花太长时间了。"

translate chinese chinese_6866134_145:
    old "We’re supposed to already be going to the principal's office."
    new "我们本来应该去校长办公室了。"

translate chinese chinese_1104969_146:
    old "O-ok!"
    new "好、好！"

translate chinese chinese_9037790_147:
    old "Hurry up!"
    new "快点！"

translate chinese chinese_9753435_148:
    old "I-I’m trying, but I can’t do it if you keep rushing me!"
    new "我我是在努力，但如果你一直催我我就做不到！"

translate chinese chinese_9658039_149:
    old "Just let go and enjoy it."
    new "就放开享受吧。"

translate chinese chinese_2261678_150:
    old "That way you’ll cum quickly."
    new "这样你会很快射的。"

translate chinese chinese_2606049_151:
    old "I’ll go faster!"
    new "我会更快的！"

translate chinese chinese_9808981_152:
    old "That’s it, I can feel you getting harder."
    new "就是现在，我能感觉到你在变硬。"

translate chinese chinese_4568013_153:
    old "There you go, just enjoy my mouth!"
    new "来吧，就享受我的嘴巴吧！"

translate chinese chinese_5006073_154:
    old "I-I think it’s working."
    new "我—我觉得有效。"

translate chinese chinese_6452982_155:
    old "J-just don’t stop."
    new "just 别停下来。"

translate chinese chinese_7125029_156:
    old "M-Mia I think I’m cuming!"
    new "米娅，我快来了！"

translate chinese chinese_3532737_157:
    old "Do it, quickly!"
    new "快点做！"

translate chinese chinese_4787049_158:
    old "Finish!"
    new "结束！"

translate chinese chinese_8068198_159:
    old "I mean, did you have to finish all over me?"
    new "我是说，你非得把我全身都弄湿吗？"

translate chinese chinese_4152449_160:
    old "You covered me in cum!"
    new "你弄得我全身都是精液！"

translate chinese chinese_4834726_161:
    old "S-sorry, I couldn’t really control it."
    new "对不起，我实在是控制不了。"

translate chinese chinese_3579914_162:
    old "Whatever, listen, I’ll get clean quickly and we’ll go to the principal’s office."
    new "随便吧，听我说，我赶紧洗一下，然后我们就去校长办公室。"

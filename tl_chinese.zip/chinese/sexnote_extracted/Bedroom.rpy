# auto-tl Qwen Colab

translate chinese chinese_9056240_0:
    old "I should go to the garage to talk with Brixxida first..."
    new "我应该先去车库和Brixxida谈谈……"

translate chinese chinese_8634840_1:
    old "Ah. I feel rested..."
    new "啊，我觉得很轻松……"

translate chinese chinese_3455454_2:
    old "I should probably go talk to Billie..."
    new "我应该去和比莉谈谈..."

translate chinese chinese_8533749_3:
    old "Sleep"
    new "睡觉"

translate chinese chinese_0341649_4:
    old "It's time to sleep..."
    new "该睡觉了……"

translate chinese chinese_3322736_5:
    old "Ready for a new day!"
    new "准备好迎接新的一天了！"

translate chinese chinese_6681999_6:
    old "Today is [mo1rel]'s medical appointment day, I should talk her."
    new "今天是[mo1rel]的医疗预约日，我应该和她谈谈。"

translate chinese chinese_5419557_7:
    old "Wow... What's going on..."
    new "wow... 这是怎么回事..."

translate chinese chinese_9313016_8:
    old "Oh shit... Not again..."
    new "哦shit... 又来了..."

translate chinese chinese_8629980_9:
    old "What the hell!..."
    new "什么鬼！..."

translate chinese chinese_9191475_10:
    old "Really? You again!?..."
    new "真的？又是你！？..."

# auto-tl Qwen Colab

translate chinese chinese_9072391_0:
    old "Look at her better"
    new "好好看看她"

translate chinese chinese_3750681_1:
    old "I should leave... I don't want to make her think I'm perverted."
    new "我应该离开……不想让她觉得我色色的。"

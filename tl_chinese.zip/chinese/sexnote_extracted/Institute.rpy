# auto-tl Qwen Colab

translate chinese chinese_4000755_0:
    old "I should go to the garage to talk with Brixxida first."
    new "我应该先去车库和Brixxida谈谈。"

translate chinese chinese_7628010_1:
    old "Well, she is in the classroom right now. You should go and show her."
    new "好吧，她现在在教室里。你应该去给她看看。"

translate chinese chinese_3334368_2:
    old "Ok. Doing it now."
    new "好的。我现在就做。"

translate chinese chinese_4529278_3:
    old "Nothing much, it’s just that I haven’t seen you when I’ve gone to your home to do the repairs on the bathroom."
    new "没什么，就是我去你家修浴室的时候没见到你。"

translate chinese chinese_2124894_4:
    old "Yeah, I’m sorry about that."
    new "是的，我为此道歉。"

translate chinese chinese_9071644_5:
    old "This whole extracurricular work has been keeping me busy."
    new "这些课外活动一直让我忙个不停。"

translate chinese chinese_8575928_6:
    old "But it’s supposed to count for extra credit for college, so, I guess that’s alright."
    new "但是这应该能算大学的额外学分，所以我想这样也行吧。"

translate chinese chinese_4147732_7:
    old "Of course, of course, I totally get it."
    new "当然，当然，我完全明白。"

translate chinese chinese_9925255_8:
    old "I’ll make it up to you once I’m done with all of this."
    new "等我把这些都处理完，我就补偿你。"

translate chinese chinese_9184600_9:
    old "We’ll also have some time to ourselves once you’re done with the bathroom."
    new "等你用完洗手间，我们也有点自己的时间了。"

translate chinese chinese_2071985_10:
    old "Yeah, I guess I better hurry to finish with that. The sooner the better."
    new "嗯，我想我最好赶快搞定那件事。越快越好。"

translate chinese chinese_3209134_11:
    old "It’s very kind of you to do that for us."
    new "你这么做真是太好了。"

translate chinese chinese_4852441_12:
    old "No problem, it’s rather easy."
    new "没问题，挺简单的。"

translate chinese chinese_8644128_13:
    old "By the way, I think I’ll go work on that right now."
    new "对了，我想我现在就去处理那个。"

translate chinese chinese_9247899_14:
    old "See you later Hinn."
    new "一会儿见，Hinn。"

translate chinese chinese_0126063_15:
    old "Sure, see you later."
    new "好的，回头见。"

translate chinese chinese_5817912_16:
    old "Hey, Hinn"
    new "嘿，Hinn"

translate chinese chinese_9045881_17:
    old "Do you have a therapy appointment today with Dr. Johnson?"
    new "你今天有和约翰逊博士的治疗预约吗？"

translate chinese chinese_0912941_18:
    old "No, actually I think we should work on the class project today."
    new "不，其实我觉得今天我们应该做班级项目。"

translate chinese chinese_5800994_19:
    old "You are right, we have work to do."
    new "你说得对，我们有工作要做。"

translate chinese chinese_9550862_20:
    old "If we make a good progress I could set an appointment for tomorrow."
    new "如果我们进展顺利，我可以预约明天见面。"

translate chinese chinese_8497827_21:
    old "Always that responsible. That sounds good to me."
    new "总是那么有责任心。听起来不错。"

translate chinese chinese_3769671_22:
    old "Hehehe... Great, see you in my house."
    new "嘿嘿嘿……好的，我家见。"

translate chinese chinese_2298681_23:
    old "Perfect. See you then."
    new "完美，到时候见。"

translate chinese chinese_9838724_24:
    old "Hey, [pla]!"
    new "嘿，[pla]！"

translate chinese chinese_5038255_25:
    old "Hi Bell."
    new "嗨，贝尔。"

translate chinese chinese_9445713_26:
    old "Did you start to work on your project?"
    new "你开始做你的项目了吗？"

translate chinese chinese_6390149_27:
    old "Well, I talked to Hinn, I think we're going to start this afternoon..."
    new "嗯，我和Hinn谈过了，我觉得我们下午开始吧..."

translate chinese chinese_1210734_28:
    old "Lucky you, I got paired with that asshole Mike this time. I don't know how everything is going to work out..."
    new "你真幸运，这次我被分到了那个混蛋迈克。我真的不知道事情会怎么发展……"

translate chinese chinese_9181873_29:
    old "Don't worry, Mike is good whenever he tries."
    new "别担心，迈克一尝试就做得很好。"

translate chinese chinese_9646279_30:
    old "Hmm... I sure hope so..."
    new "嗯……我真是这么希望的……"

translate chinese chinese_1269099_31:
    old "Ok... Bell, I have to go to meet with Hinn. Bye."
    new "好吧……贝尔，我得去见希恩了。再见。"

translate chinese chinese_4833817_32:
    old "See you later, [pla]..."
    new "再见了，[pla]..."

translate chinese chinese_1507914_33:
    old "Hey, [pla]! How did it go with your project?"
    new "嘿，[pla]！你的项目进展如何？"

translate chinese chinese_8544044_34:
    old "Actually, great! Hinn is quite good and she has taught me a lot..."
    new "实际上，挺好的！Hinn 很不错，她教会了我很多……"

translate chinese chinese_9854306_35:
    old "Hmm... Right, Hinn is a pretty nerd... Mine is an ugly asshole..."
    new "嗯……对，希恩是个挺书生气的家伙……我那个是丑陋的混账……"

translate chinese chinese_1306368_36:
    old "It can't be that bad ..."
    new "不会那么糟糕吧……"

translate chinese chinese_7862198_37:
    old "It can't be that bad?... We went to my house to study and he tried to look in my underwear drawer... Three times!"
    new "不会那么糟糕吧……我们去我家学习，他还三次试图看我的内衣抽屉……"

translate chinese chinese_8281910_38:
    old "Really?... Uhh weird..."
    new "真的吗？……嗯，挺奇怪的……"

translate chinese chinese_4373217_39:
    old "Tell me about it... I have to do everything by myself."
    new "说起来……我什么事情都得自己做。"

translate chinese chinese_5871476_40:
    old "Too bad... Fortunately, you are smart and you can actually do it alone. I really couldn't without help."
    new "真可惜……好在你很聪明，可以独自完成。我没有帮助根本做不到。"

translate chinese chinese_9012529_41:
    old "... Seriously, every time I see Mike, I just want to kill him..."
    new "... seriously，每次看到迈克，我就想杀了他..."

translate chinese chinese_0130719_42:
    old "Damn... Well, Bell, I have to go. I will see you later..."
    new "damn... 好吧，贝尔，我得走了，回头见..."

translate chinese chinese_6145423_43:
    old "See you later, [pla]!"
    new "再见了，[pla]！"

translate chinese chinese_5645907_44:
    old "Hey, [pla]! How's it going?"
    new "嘿，[pla]！最近怎么样？"

translate chinese chinese_9644071_45:
    old "Hi Belle, I'm doing great!"
    new "嗨，贝儿，我很好！"

translate chinese chinese_0016663_46:
    old "A little busy with school work and stuff, you know."
    new "最近忙于学习和其他事情，你知道的。"

translate chinese chinese_4676345_47:
    old "Yeah, I get it."
    new "yeah, 我明白。"

translate chinese chinese_7790164_48:
    old "How about you?"
    new "你呢？"

translate chinese chinese_9577579_49:
    old "Well, I guess I'm ok."
    new "嗯，我想我还好吧。"

translate chinese chinese_6937747_50:
    old "Lately my mom has been a little intense."
    new "最近我妈妈有点紧张兮兮的。"

translate chinese chinese_0582611_51:
    old "She's always coming and going from home."
    new "她总是来去匆匆。"

translate chinese chinese_2983492_52:
    old "And every time she's home she wants to see me or talk to me "
    new "而且每次她在家都想见我或和我说话"

translate chinese chinese_6000046_53:
    old "Hmm... I can imagine how annoying it must be."
    new "嗯……我能想象那一定很烦人。"

translate chinese chinese_6715936_54:
    old "I guess I'll have to deal with it."
    new "看来我得处理一下了。"

translate chinese chinese_8913531_55:
    old "She's been handling a lot because of her job."
    new "因为工作，她承受了很多。"

translate chinese chinese_9893876_56:
    old "So, I guess that when the whole thing is over she'll be right back to normal."
    new "所以，我想等这一切结束，她就会恢复正常了。"

translate chinese chinese_6685433_57:
    old "Yeah, I'm sure she will."
    new "是的，我敢肯定她会的。"

translate chinese chinese_7616773_58:
    old "Hey, I have to run, but I'll see you later."
    new "嘿，我得赶紧走了，回头见。"

translate chinese chinese_9020833_59:
    old "Sure, see you."
    new "行吧，再见。"

translate chinese chinese_9850840_60:
    old "Hi Belle, good morning."
    new "嗨，贝儿，早上好。"

translate chinese chinese_7472158_61:
    old "Hi [pla]..."
    new "喂，[pla]……"

translate chinese chinese_2206774_62:
    old "How are you?"
    new "你好吗？"

translate chinese chinese_1336066_63:
    old "I'm ok, how are you doing?"
    new "我挺好的，你呢？"

translate chinese chinese_3992514_64:
    old "Well, I'm fine I think."
    new "嗯，我觉得我还好。"

translate chinese chinese_4889010_65:
    old "The situation has been tense with my mom since our fight."
    new "自从那次吵架后，我和我妈妈的关系一直很紧张。"

translate chinese chinese_0111882_66:
    old "So we're not actually talking right now."
    new "所以我们现在其实没在说话。"

translate chinese chinese_1454349_67:
    old "But other than that I'm doing well."
    new "不过除此之外，我挺好的。"

translate chinese chinese_6130941_68:
    old "Since I moved with Amorette, and I've been able to work from her home."
    new "自从我和阿莫rette一起住后，我就能在她家工作了。"

translate chinese chinese_1294568_69:
    old "So on that end, everything's fine."
    new "那边一切都没问题。"

translate chinese chinese_1822738_70:
    old "Ok, I see, well, I guess that's fine."
    new "好吧，我明白了，我想这样也行。"

translate chinese chinese_4208045_71:
    old "As long as you're ok, I suppose everything's alright."
    new "只要你没事，我想一切都还好。"

translate chinese chinese_6535771_72:
    old "Yeah."
    new "是的。"

translate chinese chinese_2019829_73:
    old "Alright, it was nice to see you. See you later, Belle."
    new "好吧，见到你很高兴。回头见，贝勒。"

translate chinese chinese_1418827_74:
    old "Sure. See you later, [pla]."
    new "好的。再见了，[pla]。"

translate chinese chinese_4792664_75:
    old "Uhh... Nothing. I was just heading out. Sorry."
    new "呃……没什么。我只是正准备出去。对不起。"

translate chinese chinese_8693355_76:
    old "What do you want [pla]?"
    new "你想要什么 [pla]?"

translate chinese chinese_1990346_77:
    old "I... wanted to talk about the final project."
    new "我……想谈谈最后的项目。"

translate chinese chinese_4572441_78:
    old "Is it ready? Do you have any progress to show?"
    new "做好了吗？有什么进展可以展示的吗？"

translate chinese chinese_4665884_79:
    old "Wow, I can't believe it. You guys did it..."
    new "wow, 真不敢相信。你们做到了..."

translate chinese chinese_3087173_80:
    old "And... How was it?"
    new "然后……怎么样？"

translate chinese chinese_6273695_81:
    old "Your project is... Good... I guess..."
    new "你的项目是……不错……吧……"

translate chinese chinese_6074858_82:
    old "You have completed a lot. I have to say I am surprised..."
    new "你完成了很多。我得说我很惊讶……"

translate chinese chinese_2548210_83:
    old "By the way, I talked with your partner... And she said you have been working hard... I wasn't sure, but I have to believe her... Maybe I underestimated you, [pla]."
    new "对了，我和你的搭档谈过了……她说你一直在努力工作……虽然我不太确定，但不得不相信她……也许我低估了你，[pla]。"

translate chinese chinese_1924783_84:
    old "Thank you!"
    new "谢谢！"

translate chinese chinese_8013822_85:
    old "Don't get too excited. You still have a lot of work to do before it is done."
    new "别太兴奋了。在完成之前你还有一大堆事情要做。"

translate chinese chinese_7517849_86:
    old "I can't believe you did something of this... I need to talk with your partner, tell her to come and talk with me... ALONE!"
    new "真不敢相信你会做这种事……我需要和你的同伴谈谈，告诉她来单独找我谈话……单独来！"

translate chinese chinese_2335244_87:
    old "Hmm... Ok... I will tell her..."
    new "嗯……好吧……我会告诉她……"

translate chinese chinese_9131242_88:
    old "Ok, now this is getting really suspicious..."
    new "好吧，现在这真的有点可疑了……"

translate chinese chinese_8187222_89:
    old "Anyway, I'm busy to worry about you..."
    new "反正我忙着呢，没空担心你……"

translate chinese chinese_9130739_90:
    old "Hmmm ok."
    new "嗯，好吧。"

translate chinese chinese_9901412_91:
    old "Oh? Have you made more progress? Is your partner doing everything?"
    new "哦？你进展更多了？你的搭档什么都做了吗？"

translate chinese chinese_5699777_92:
    old "What?! Of course not! This is all team work."
    new "什么?! 当然不是！这全是团队合作。"

translate chinese chinese_2149806_93:
    old "Hmm... You haven't screwed it up yet. I will keep waiting."
    new "嗯……你还不错，没搞砸。我继续等着。"

translate chinese chinese_5172976_94:
    old "Oh, you have started... But you still have a lot of work to do before you are done..."
    new "哦，你开始了……但是你要做的还有很多……"

translate chinese chinese_3106158_95:
    old "But?... How is it?"
    new "但是……怎么样？"

translate chinese chinese_6378296_96:
    old "For now, it's ok. But I'm sure you will screw it up, sooner or later."
    new "现在还行，但迟早你会搞砸的，我敢肯定。"

translate chinese chinese_3115436_97:
    old "As I thought... then don't bother me. Talk to me when you've made some progress... if you even can, of course..."
    new "果然……那别来烦我。有进展了再跟我说……如果你能做到的话……"

translate chinese chinese_7709476_98:
    old "Yeah, yeah congratulations, your project was good, are you happy?"
    new "好吧好吧，恭喜你，你的项目做得不错，你开心了吧？"

translate chinese chinese_6952557_99:
    old "Thanks! see you!..."
    new "谢谢！再见！..."

translate chinese chinese_0694124_100:
    old "Start the Class"
    new "开始课程"

translate chinese chinese_6429404_101:
    old "The class will start soon, [pla]."
    new "上课就要开始了，[pla]。"

translate chinese chinese_6437973_102:
    old "Just take a seat."
    new "随便坐吧。"

translate chinese chinese_6379946_103:
    old "... Uhhh sure."
    new "……嗯，好吧。"

translate chinese chinese_2659045_104:
    old "Well, ladies and gentlemen. Please remember the final project you have to do..."
    new "好吧，女士们先生们。请记住你们必须完成的最终项目..."

translate chinese chinese_9509567_105:
    old "(Hmm... The final project... one of the hardest and boringest things ever!)"
    new "（嗯……最后的项目……可能是有史以来最艰难又最无聊的事情了！）"

translate chinese chinese_6783895_106:
    old "(I mean, research? Bibliographies? Theoretical framework?... All that work on stuff I'll never use...)"
    new "（我是说，研究？书目？理论框架？……那些我永远用不上的东西所做的所有工作……）"

translate chinese chinese_5078652_107:
    old "(I really want to graduate and be free from all of this crap…)"
    new "（我真的想毕业，摆脱这一切烂事……）"

translate chinese chinese_9830706_108:
    old "Where did it fall from?... An airplane?"
    new "它从哪儿掉下来的？……飞机吗？"

translate chinese chinese_4103984_109:
    old "Sorry, Mrs. Mia. I'm listening. I was just... looking through the window..."
    new "对不起，米娅夫人，我在听。我刚才只是……在看窗外……"

translate chinese chinese_8290967_110:
    old "Oh really? Then please tell us all the project requirements that I just explained..."
    new "哦真的吗？那请你告诉我刚才我解释的所有项目需求..."

translate chinese chinese_1943391_111:
    old "Ughh... Finally free!..."
    new "呃……终于自由了……"

translate chinese chinese_9824654_112:
    old "(I don't know how I'm going to get that project done.)"
    new "（我不知道该怎么完成那个项目。）"

translate chinese chinese_3550920_113:
    old "Hey [pla]!"
    new "嘿[pla]！"

translate chinese chinese_0219682_114:
    old "Hey, Bell! I wanted to ask you... if we... could work together in the class project?"
    new "嘿，贝尔！我想问你……我们……能在班级项目中合作吗？"

translate chinese chinese_0500881_115:
    old "You wasn't paying attention, huh?"
    new "你没注意吧？"

translate chinese chinese_8383145_116:
    old "What?... What you mean?"
    new "什么？... 你什么意思？"

translate chinese chinese_9289157_117:
    old "This project is for couples and your partner is Hinn."
    new "这个项目是为情侣准备的，你的搭档是Hinn。"

translate chinese chinese_6619041_118:
    old "Really? OK, thanks anyway."
    new "真的吗？好吧，还是谢谢你了。"

translate chinese chinese_2269873_119:
    old "Heyyy guys! Did you notice  Mia`s neckline, every day she gets hotter and hotter."
    new "嘿哥们儿！你们注意到米娅的锁骨了吗，她一天比一天热辣。"

translate chinese chinese_3660022_120:
    old "Really Mike? She could be your mother ... "
    new "真是的，迈克，她都快当你妈了……"

translate chinese chinese_0450894_121:
    old "That makes it even more sexy. A hot ass milf teaches us. Sounds nice, aye, [pla]?"
    new "这反而更性感了。一个热辣的熟女来教我们。听起来不错，对吧，[pla]？"

translate chinese chinese_0149359_122:
    old "I only know that she hates my guts and each day it gets worse. I just hope I'm alive at the end of the school year."
    new "我只知道她非常讨厌我，而且这种情况每天都在恶化。我只希望学年结束时我还活着。"

translate chinese chinese_7085756_123:
    old "Well, I'm leaving. I have things to do. And I don't want to stay here and keep listening to Mike's perversions."
    new "好吧，我要走了。我还有事呢。而且我不想待在这里继续听迈克的变态言论。"

translate chinese chinese_2250990_124:
    old "Bye, Belle. See you around."
    new "再见，贝勒。回头见。"

translate chinese chinese_5884553_125:
    old "Have you noticed how hot Belle is gettin'?"
    new "你有没有觉得贝尔越来越辣了？"

translate chinese chinese_2097998_126:
    old "Dude... Damn, you should calm down a little."
    new "伙计……天啊，你得冷静点。"

translate chinese chinese_0065656_127:
    old "Why? Are you gay or something?"
    new "为什么？你是gay还是怎么了？"

translate chinese chinese_5750917_128:
    old "Bye, Mike. I'll talk to you later"
    new "拜拜，迈克。待会儿再聊。"

translate chinese chinese_4937100_129:
    old "So I'm right, huh? But she is hot, isn't she?"
    new "所以我是对的吧？不过她确实很辣，是不是？"

translate chinese chinese_5439382_130:
    old "Wait... Is this...?"
    new "等一下……这是……？"

translate chinese chinese_2957876_131:
    old "The book that fell from the sky?"
    new "从天而降的书？"

translate chinese chinese_4014753_132:
    old "SexNote?  What could it be about?"
    new "SexNote？会是关于什么的？"

translate chinese chinese_7113479_133:
    old "Weeeell, finders-keepers. Hehe."
    new "嗯～～～找到了就是 ours啦。嘿嘿。"

translate chinese chinese_4380721_134:
    old "Maybe I can think of something interesting to draw in it."
    new "也许我能想到一些有趣的东西来画。"

translate chinese chinese_4765800_135:
    old "Hey, wait! Before you go... I have something to show you that will surely blow your mind."
    new "嘿，等一下！在你走之前……我有个东西要给你看，保证让你大吃一惊。"

translate chinese chinese_2364005_136:
    old "Now what weird thing do you have in mind?"
    new "现在又在想些什么奇怪的事情？"

translate chinese chinese_1114739_137:
    old "Listen... Just go to my house and look for me in my room. I'll show you."
    new "听着……直接来我家，在我房间里找我，我会给你看的。"

translate chinese chinese_4595233_138:
    old "Hmm, alright... I will see you then."
    new "嗯，好吧……到时候见。"

translate chinese chinese_7002242_139:
    old "Seriously, [pla].I assure you it will be worth it!"
    new "seriously, [pla].我保证这绝对值得！"

translate chinese chinese_5249807_140:
    old "I shouldn't enter. This isn't my classroom."
    new "我不能进去，这不是我的教室。"

# SexNote Português (PT) — language bootstrap
# Do not edit English sources

init python:
    try:
        renpy.config.known_languages.add("portuguese")
    except Exception:
        pass

translate portuguese python:
    gui.text_font = "DejaVuSans.ttf"
    gui.name_text_font = "DejaVuSans.ttf"
    gui.interface_text_font = "DejaVuSans.ttf"
    gui.button_text_font = "DejaVuSans.ttf"
    gui.choice_button_text_font = "DejaVuSans.ttf"
    _sn_say_size = 30 if renpy.variant("small") else 34
    _sn_box_h = 400 if renpy.variant("small") else 340
    gui.text_size = _sn_say_size
    gui.textbox_height = _sn_box_h
    gui.dialogue_ypos = 58 if renpy.variant("small") else 62
    gui.text_ypos = 60
    gui.text_xpos = 80
    gui.text_width = 1760
    gui.name_ypos = 8
    style.default.line_spacing = 8
    style.say_dialogue.line_spacing = 6
    style.say_dialogue.size = _sn_say_size
    style.history_text.line_spacing = 12
    style.history_text.size = 34
    try:
        config.rtl = False
    except Exception:
        pass

translate portuguese style default:
    line_spacing 8
    font "DejaVuSans.ttf"

translate portuguese style say_dialogue:
    line_spacing 6
    layout "subtitle"
    font "DejaVuSans.ttf"

translate portuguese style say_label:
    font "DejaVuSans.ttf"

translate portuguese style history_text:
    size 34
    line_spacing 12
    layout "subtitle"
    font "DejaVuSans.ttf"

translate portuguese style choice_button_text:
    font "DejaVuSans.ttf"

translate portuguese style quick_button_text:
    font "DejaVuSans.ttf"

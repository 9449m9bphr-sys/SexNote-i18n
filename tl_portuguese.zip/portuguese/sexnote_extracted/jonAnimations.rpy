# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/jonAnimations.rpy
translate portuguese strings:

    # say L6 jon
    old "It barely fits in my mouth... My god! You really have something big here."
    new "A:jon: É um pénis enorme, tal como o do meu marido."

    # say L10 jon
    old "It's a massive cock, just like my husband's dick."
    new "B:jon: Mal cabe na minha boca... Meu Deus! Tu realmente tens algo grande aqui."

    # say L11 pla
    old "(Wow! I can see she has some good experience at this...)"
    new "B:jon: É um pénis enorme, tal como o do meu marido."

    # say L15 jon
    old "It's so big and Mmmm... So good..."
    new "Sra. Jones, eu estou a gozar..."

    # say L39 pla
    old "Mrs. Jones I'm cum-"
    new "B:jon: É tão grande e Mmmm... Tão bom..."

    # say L40 jon
    old "Oh Yes! Give me your sacred cum..."
    new "B:pla: Sra. Jones, eu estou a gozar..."

    # say L42 jon
    old "Ahhhhhhhhh!"
    new "B:jon: Oh Sim! Dá-me o teu sagrado gozo..."

    # say L48 jon
    old "Oh my God, I really need to feel your divine presense inside me..."
    new "B:jon: Ahhhhhhhhh!"

    # say L50 jon
    old "Come to my bedroom..."
    new "B:jon: Oh meu Deus, preciso mesmo de sentir a tua presença divina dentro de mim..."

    # say L64 pla
    old "I- I'm doing it right?"
    new "B:jon: Vem ao meu quarto..."

    # say L65 jon
    old "My pussy is speaking for me... Just feel how wet it's for you."
    new "B:pla: I- I'm doing it right?"

    # say L69 jon
    old "I haven't felt like this in years !!"
    new "B:jon: A minha xoxota está a falar por mim... Sente só o quanto está molhada para ti."

    # say L70 jon
    old "Being with a young and vigorous man like you, has no comparison."
    new "B:jon: Não me sentia assim há anos!!"

    # say L74 pla
    old "Oh god! Oh God!"
    new "B:jon: Estar com um jovem e vigoroso como tu, não tem comparação."

    # say L75 jon
    old "You'll make me come so badly!"
    new "B:pla: Oh Deus! Oh Deus!"

    # say L98 pla
    old "I- I'm cumming-"
    new "B:jon: Vais fazer-me gozar tanto!"

    # say L99 jon
    old "Ohhh mee too!!!"
    new "B:pla: I- I'm cumming-"

    # say L103 jon
    old "Wow, that was great... We should, get dressed before Billie arrives."
    new "B:jon: Ohhh eu também!!!"

    # say L116 jon
    old "Oh yeah! Fuck my mouth you little boy!"
    new "B:jon: Uau, isso foi incrível... Devíamos vestir-nos antes de a Billie chegar."

    # say L117 pla
    old "Oh God!"
    new "B:jon: Oh yeah! Foda a minha boca, tu rapazinho!"

    # say L121 jon
    old "It's so good to have it inside my mouth... I can feel your veins pumping..."
    new "B:pla: Oh Deus!"

    # say L122 pla
    old "Ahhhhhhh! You're so good..."
    new "B:jon: É tão bom tê-lo na minha boca... Posso sentir as tuas veias a latejar..."

    # say L126 jon
    old "Yes! Faster! Faster I want you to cum on my mouth!"
    new "B:pla: Ahhhhhhh! Tu és tão bom..."

    # say L150 jon
    old "Ohh... I can feel your body tensing!"
    new "B:jon: Sim! Mais rápido! Quero que gozes na minha boca!"

    # say L151 jon
    old "Fill my mouth with your cum!"
    new "B:jon: Ohh... Sinto o teu corpo a tensar-se!"

    # say L162 jon
    old "I'm so wet... But today I want you to fuck my ass..."
    new "B:jon: Enche a minha boca com o teu sémen!"

    # say L163 pla
    old "... W- what?"
    new "B:jon: Estou tão molhada... Mas hoje quero que me fodes o cu..."

    # say L164 jon
    old "I just want to remember the good times with my husband ..."
    new "B:pla:... Q- que?"

    # say L182 jon
    old "Oh God, it's so big it hurts!"
    new "B:jon: Só quero recordar os bons momentos com o meu marido..."

    # say L183 pla
    old "Do you want me to stop?"
    new "B:jon: Ah Deus, está tão grande que dói!"

    # say L184 jon
    old "Ohh no, please don't stop, I want you to fuck my ass just like my husband used to do..."
    new "B:pla: Queres que pare?"

    # say L187 jon
    old "Faster! I want you to fuck me harder!"
    new "B:jon: Ah não, por favor, não pares, quero que me fodas a bicha como o meu marido costumava fazer..."

    # say L193 jon
    old "Oh yes! Just like that! Don't stop, don't stop!!"
    new "B:jon: Mais rápido! Quero que me fodes mais forte!"

    # say L194 jon
    old "It hurts, but it feels so good!"
    new "B:jon: Oh sim! Assim mesmo! Não pares, não pares!!"

    # say L217 jon
    old "Oh yeah, fill my ass with your cum!"
    new "B:jon: Faz mal, mas é tão bom!"

    # say L220 jon
    old "Oh God, you are definitely better than my husband..."
    new "B:jon: Oh sim, enche o meu cu com o teu esperma!"

    # say L234 bil
    old "Wow, it's bigger than I remember..."
    new "B:jon: Oh Deus, tu és definitivamente melhor que o meu marido..."

    # say L235 jon
    old "Ahhhh! So nice."
    new "B:bil: Uau, é maior do que me lembrava..."

    # say L236 gra
    old "My goddess!"
    new "Ahhhh! Tão bom."

    # say L240 jon
    old "Let me give you a hand with this..."
    new "B:gra: Minha deusa!"

    # say L243 bil
    old "Oh, it looks so hot!"
    new "B:jon: Deixa-me ajudar-te com isto..."

    # say L247 bil
    old "Yeah! get that cock ready to fuck us!"
    new "B:bil: Oh, parece tão quente!"

    # say L248 jon
    old "Oh, Billie, please watch your mouth..."
    new "B:bil: Sim! Prepara esse pénis para nos foder!"

    # say L271 jon
    old "Alright, I guess it's time to start, sister Grace is waiting hun!"
    new "B:jon: Oh, Billie, por favor, cuida com o que dizes..."

    # say L282 gra
    old "Oh my God! It feels amazing inside of me!"
    new "B:jon: Bem, acho que é hora de começar, a irmã Grace está à espera, querida!"

    # say L283 bil
    old "I have a great view of your pussy being fucked sister Grace..."
    new "B:gra: Oh meu Deus! É incrível dentro de mim!"

    # say L285 jon
    old "Billie!"
    new "B:bil: Tenho uma ótima vista da tua buceta a ser fodida, irmã Grace..."

    # say L289 gra
    old "My body and soul really needed this ritual."
    new "B:jon: Billie!"

    # say L290 gra
    old "Ahhh!"
    new "B:gra: O meu corpo e a minha alma precisavam mesmo deste ritual."

    # say L291 jon
    old "More... More..."
    new "B:gra: Ahhh!"

    # say L292 bil
    old "If I had known about these rituals I would have become a nun too!"
    new "B:jon: Mais... Mais..."

    # say L296 gra
    old "Oh! My dear... You'll make me cum with so much g- grace..."
    new "B:bil: Se soubesse destes rituais, também teria entrado para o convento!"

    # say L297 gra
    old "Ahhh! I'm about t-"
    new "B:gra: Oh! Minha querida... Vais fazer-me gozar com tanta g- graça..."

    # say L298 bil
    old "Fuck! This is so damn good!"
    new "B:gra: Ahhh! Estou quase a-"

    # say L322 jon
    old "So good, my God!"
    new "B:bil: Merda! Isto é tão bom!"

    # say L323 pla
    old "Fuck! I'm cuming!"
    new "B:jon: Tão bom, meu Deus!"

    # say L324 gra
    old "Me too... Ahhh!"
    new "B:pla: Merda! Estou a gozar!"

    # say L333 bil
    old "Wow, that was intense..."
    new "Meu Deus! Obrigado por isto..."

    # say L334 gra
    old "My God! Thanks for this..."
    new "B:bil: Uau, isso foi intenso..."

    # say L341 bil
    old "Do you like what you see?"
    new "B: pla: (Isto é o p- paraíso... Merda!)"

    # say L343 jon
    old "Come on hun, it's time to give me some blessed cock."
    new "B:bil: Gostas do que vês?"

    # say L344 gra
    old "Oh yeah, guide Mrs. Jones, just like you did with me."
    new "B:jon: Vamos, querida, é hora de me dar um pouco de pénis abençoado."

    # say L359 bil
    old "Do you feel 'God's presence' right now?"
    new "B:gra: Oh yeah, guia a Sra. Jones, como fizeste comigo."

    # say L360 jon
    old "Oh yes, I feel it... Very deep inside."
    new "B:bil: Tu sentes a 'presença de Deus' neste momento?"

    # say L361 gra
    old "I feel too so much of your divine presence, my heavenly God!"
    new "B:jon: Oh sim, sinto... Muito fundo dentro de mim."

    # say L366 jon
    old "My God! It feels amazing!"
    new "A:bil: Oh sim, foda a minha avó, exatamente como tu me fodeste!"

    # say L367 bil
    old "Oh yes, fuck my granny, just like you fucked me!"
    new "B:jon: Meu Deus! É incrível!"

    # say L374 jon
    old "Oh, you have no idea!"
    new "B:bil: Esta é a melhor religião de sempre!"

    # say L375 jon
    old "I'm touching God right now... This is so good..."
    new "B:jon: Oh, tu nem imaginas!"

    # say L399 pla
    old "I- I'm cuming again..."
    new "B:jon: Estou a tocar em Deus neste momento... Isto é tão bom..."

    # say L400 jon
    old "Ahhhhhh!"
    new "B:pla: I- I estou a gozar de novo..."

    # say L401 bil
    old "Yeesss!"
    new "B:jon: Ahhhhhh!"

    # say L402 gra
    old "We need your cum, right now! We to purify ourselves."
    new "B:bil: Simmmm!"

    # say L411 bil
    old "Oh, oh, it's my turn! It's my turn!"
    new "B:gra: Precisamos do teu sêmen, já! Temos de nos purificar."

    # say L412 jon
    old "I'm sorry, my dear, But you must stay a virgin until marriage."
    new "B:bil: Oh, oh, é a minha vez! É a minha vez!"

    # say L413 bil
    old "W- what the fuck!? But you already had sex with him!"
    new "B:jon: Sinto muito, minha querida, mas tens de manter-te virgem até ao casamento."

    # say L414 jon
    old "Yes, my dear, I'm a widow..."
    new "B:bil: W- what the fuck!? Mas tu já tiveste relações com ele!"

    # say L415 gra
    old "Don't worry Mrs. Jones I have an idea..."
    new "B:jon: Sim, minha querida, sou viúvo..."

    # say L429 pla
    old "Wow! it feels great."
    new "B:gra: Não te preocupes, Sra. Jones, tenho uma ideia..."

    # say L430 bil
    old "Ohhh yeahh, Fuck! This is good!... Thanks sister."
    new "B:pla: Uau! Que sensação incrível."

    # say L431 gra
    old "Enjoy it honey..."
    new "B:bil: Ohhh sim, Foda-se! Isto é bom!... Obrigado, irmã."

    # say L435 bil
    old "Faster, I need it fater!"
    new "Preciso que faças mais..."

    # say L438 jon
    old "We need you to do more..."
    new "B:bil: Mais rápido, preciso disso mais rápido!"

    # say L439 bil
    old "The three of us need to get enough of you... Please, keep going!"
    new "B:jon: Precisamos que faças mais..."

    # say L440 gra
    old "Don't stop!"
    new "B:bil: Os três precisamos de ter o suficiente de ti... Por favor, continua!"

    # say L444 bil
    old "Yeah, yeah, yeah... Just like this!"
    new "B:gra: Não pares!"

    # say L445 jon
    old "Oh God! Woww!"
    new "B:bil: Sim, sim, sim... Assim mesmo!"

    # say L446 gra
    old "Ahhh! Your cock is so damn good!"
    new "B:jon: Ah Deus! Uau!"

    # say L447 gra
    old "I mean... So divine and big... Ahhh!"
    new "B:gra: Ahhh! O teu pénis é tão bom!"

    # say L475 gra
    old "I feel your sacred milk..."
    new "B:gra: Quero dizer... Tão divino e grande... Ahhh!"

    # say L476 bil
    old "Hmm, big load! Ahhh"
    new "B:gra: Sinto o teu leite sagrado..."

    # say L477 jon
    old "This is more than enough for the three of us... But we want more..."
    new "B:bil: Hmm, grande carga! Ahhh"

    # say L498 bil
    old "Your cock is so big and good!"
    new "B:jon: Isto é mais do que suficiente para os três... Mas queremos mais..."

    # say L499 gra
    old "Yeah... This is what my soul was asking for..."
    new "B:bil: O teu pénis é tão grande e bom!"

    # say L505 gra
    old "Uhhh... It's a divine cock... So good..."
    new "B:gra: Sim... Isto é o que a minha alma pedia..."

    # say L512 bil
    old "Fuck, I need it too.."
    new "B:gra: Do teu pau enorme e santo..."

    # say L535 bil
    old "We want your cum in our mouths..."
    new "B:bil: Merda, eu também preciso..."

    # say L536 jon
    old "Oh yes hun, give it to us!"
    new "B:bil: Queremos o teu esperma nas nossas bocas..."


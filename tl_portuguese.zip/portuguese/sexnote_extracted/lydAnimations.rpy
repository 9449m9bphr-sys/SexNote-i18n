# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/lydAnimations.rpy
translate portuguese strings:

    # say L6 lyd
    old "You definitely should make many young girls very happy."
    new "T(lyd|tu|say): Tu deves fazer muitas raparigas jovens muito felizes."

    # say L7 lyd
    old "It's so long and thick."
    new "B:lyd: Tu definitivamente deves fazer muitas raparigas jovens muito felizes."

    # say L8 lyd
    old "And rock solid too."
    new "B:lyd: É tão longo e grosso."

    # say L12 lyd
    old "Oh my god! You're getting even harder!"
    new "Oh meu deus! Estás a ficar ainda mais duro!"

    # say L13 lyd
    old "Your dick! It's so hard and hot in my hand!"
    new "B:lyd: Oh meu Deus! Tu estás a ficar ainda mais duro!"

    # say L14 lyd
    old "That's it, let go! Just let me stroke it!"
    new "B:lyd: O teu pénis! Está tão duro e quente na minha mão!"

    # say L18 lyd
    old "Do you like this? Do you like how I play with your dick?"
    new "B:lyd: É isso, deixa! Deixa-me acariciar-te!"

    # say L20 lyd
    old "Is this dick that hard because of me? Do you think I'm sexy?"
    new "B:lyd: Gostas disto? Gostas de como brinco com o teu pénis?"

    # say L22 pla
    old "Y-yes, you are sexy!"
    new "B:lyd: É este pénis assim tão duro por minha causa? Achas que sou sexy?"

    # say L45 pla
    old "I- I think I'm about to!"
    new "B: pla: S-Sim, tu és sexy!"

    # say L46 lyd
    old "Yes! cum!"
    new "B:pla: A- Acho que vou!"

    # say L47 lyd
    old "I want to see you shoot all your hot stuff because of me!"
    new "B:lyd: Sim! Gozar!"

    # say L63 lyd
    old "Oh yeah! It's just as I imagined."
    new "B:lyd: Quero ver-te a gozar tudo por minha causa!"

    # say L64 lyd
    old "It has an amazing taste!"
    new "B:lyd: Oh yeah! É exactamente como imaginei."

    # say L65 lyd
    old "And it's so hot!"
    new "B:lyd: Tem um sabor incrível!"

    # say L69 lyd
    old "I don't think I've ever blown a dick this big, even in the past."
    new "B:lyd: E está tão quente!"

    # say L70 lyd
    old "I think this is the best dick I've seen."
    new "B:lyd: Acho que nunca chupei um pénis tão grande, nem no passado."

    # say L71 lyd
    old "And it's also the biggest!"
    new "B:lyd: Acho que esta é a melhor pila que já vi."

    # say L75 lyd
    old "Mmmm! Slrrp!"
    new "B:lyd: E também é o maior!"

    # say L76 lyd
    old "Do you like my mouth?"
    new "B:lyd: Mmmm! Slrrp!"

    # say L77 lyd
    old "Do you like how I do it?!"
    new "B:lyd: Gostas da minha boca?"

    # say L101 lyd
    old "I can feel how your dick twitches in my mouth!"
    new "B:lyd: Gostas de como eu faço?"

    # say L104 pla
    old "O- ok!"
    new "B:lyd: Goza na minha boca, rapaz!"

    # say L111 lyd
    old "That was great. Young men really are something special."
    new "T(lyd|tu|say): Foi incrível. Os jovens realmente são algo especial."

    # say L114 lyd
    old "It's amazing how big and hard it is."
    new "T(lyd|tu|say): É impressionante como é grande e duro."

    # say L115 lyd
    old "It makes me wonder..."
    new "B:lyd: É incrível como é grande e duro."

    # say L116 pla
    old "Ok... I think I should get dressed again."
    new "T(pla|tu|say): Ok... Acho que devo vestir-me de novo."

    # say L117 lyd
    old "Yeah, you're right. It would be best."
    new "B:pla: Ok... Acho que devo vestir-me de novo."

    # say L129 lyd
    old "Nngh! Wow, it's so big."
    new "B:lyd: Sim, tens razão. Seria o melhor."

    # say L131 lyd
    old "Y- yes, it's just that it's been a while."
    new "B:lyd: Nngh! Uau, é tão grande."

    # say L132 lyd
    old "And you're so big!"
    new "B:lyd: S-sim, é que já passou algum tempo."

    # say L136 lyd
    old "Ah! Ah! Yes! Yes!"
    new "T(lyd|tu|say): Ah! Ah! Sim! Sim!"

    # say L137 lyd
    old "Your dick, it's so big, and so hot!"
    new "B:lyd: Ah! Ah! Sim! Sim!"

    # say L138 lyd
    old "It's filling me up so hard!"
    new "B:lyd: O teu pénis, é tão grande e quente!"

    # say L139 lyd
    old "L- let's do it a little faster!"
    new "B:lyd: Está a encher-me tanto!"

    # say L143 lyd
    old "Yes! Just like that!"
    new "B:lyd: L- vamos mais rápido!"

    # say L144 lyd
    old "Don't stop! Keep going!"
    new "B:lyd: Sim! Assim mesmo!"

    # say L145 lyd
    old "Nngh! Yes! YES!"
    new "B:lyd: Não pares! Continua!"

    # say L168 pla
    old "I- I think I can't hold it in longer!"
    new "B:lyd: Nngh! Sim! SIM!"

    # say L169 lyd
    old "Don't! Don't hold it!"
    new "B:pla: Eu... Acho que não consigo mais aguentar!"

    # say L170 lyd
    old "You can do it! CUM INSIDE!"
    new "B:lyd: Não! Não segures!"

    # say L176 lyd
    old "You know? I believe this might have worked, I feel so much better now, like a weight has been lifted off my shoulders."
    new "B:lyd: Tu consegues! EJacula dentro de mim!"

    # say L177 pla
    old "I'm glad you feel like that. I hope this actually helped you."
    new "B:lyd: Sabes? Acho que isto funcionou, sinto-me muito melhor agora, como se um peso tivesse sido tirado dos meus ombros."

    # say L179 pla
    old "You're welcome, I'm happy to help."
    new "A:lyd: Vou usar a minha língua em toda a ponta do teu pénis."

    # say L191 lyd
    old "I'm gonna use my tongue all over the tip of your cock."
    new "B:pla: De nada, fico feliz em ajudar."

    # say L194 pla
    old "Uhh, I love that sensation, babe."
    new "B:lyd: Vou usar a língua em toda a ponta do teu pénis."

    # say L198 lyd
    old "Mmmm... It tastes so good! I love it."
    new "B:pla: Uhh, adoro essa sensação, meu amor."

    # say L201 pla
    old "Oh yeah babe, I'll definitely love your mouth."
    new "B:lyd: Mmmm... Tem um sabor tão bom! Adoro."

    # say L202 lyd
    old "Slrrrp! Uhh you have no idea!"
    new "B:pla: Oh yeah, meu amor, vou adorar a tua boca."

    # say L209 pla
    old "You should have a lot of experience, don't you?"
    new "B:lyd: Slrrrp! Uhh tu não tens ideia!"

    # say L210 lyd
    old "Mmmm, yeah baby, but not with huge cocks like yours."
    new "B:pla: Deves ter muita experiência, não é?"

    # say L213 pla
    old "Oh yeah babe, you will really enjoy my huge cock!"
    new "B:lyd: Mmmm, sim bebé, mas não com pénis enormes como o teu."

    # say L214 lyd
    old "Mmm, that's exactly what I'm expecting."
    new "B:pla: Oh yeah, meu amor, vais adorar o meu pau enorme!"

    # say L239 pla
    old "Ohh babe, I'm about to cum."
    new "B:lyd: Mmm, é exactamente isso que estou à espera."

    # say L240 lyd
    old "Oh no, you don't. That's barely the beginning. You know what comes next."
    new "B:pla: Ohh querida, estou prestes a gozar."

    # say L241 pla
    old "(Oh God.)"
    new "B:lyd: Oh não, tu não. Isso mal é o começo. Tu sabes o que vem a seguir."

    # say L244 pla
    old "Oh, I know what comes next, that's right, you want to put it all in your mouth, don't you?"
    new "B:pla: (Oh Deus.)"

    # say L245 lyd
    old "Yes! I want to feel it all in my mouth."
    new "B:pla: Oh, eu sei o que vem a seguir, é isso mesmo, tu queres pôr tudo na tua boca, não é?"

    # say L252 lyd
    old "I love how big your cock is!"
    new "B:lyd: Sim! Quero sentir tudo na minha boca."

    # say L255 pla
    old "Suck it! Put my cock in your mouth!"
    new "B:lyd: Adoro o tamanho do teu pénis!"

    # say L263 lyd
    old "Mmm, I just love the taste of your cock!"
    new "B:pla: Chupa! Coloca o meu pénis na tua boca!"

    # say L265 lyd
    old "I love how big and hot it always gets!"
    new "B:lyd: Mmm, adoro o sabor do teu pau!"

    # say L268 pla
    old "Yeah! Tell me more!"
    new "A:lyd: Esta é a melhor pila que já tive!"

    # say L272 lyd
    old "This is the best cock I've ever had!"
    new "T(lyd|tu|say): Isto é o melhor pénis que já tive!"

    # say L274 lyd
    old "Nngh! Mmmm! I want more and more of it!"
    new "B:lyd: Esta é a melhor pila que já tive!"

    # say L277 pla
    old "Oh yeah? You want me to fuck you with it?"
    new "B:lyd: Nngh! Mmmm! Quero mais e mais!"

    # say L278 lyd
    old "Yes! I love how it feels inside!"
    new "A:pla: Gostas de como o meu pénis enche a tua boca?"

    # say L284 pla
    old "Do you like how my dick fills your mouth?"
    new "B:lyd: Sim! Adoro como isso se sente dentro de mim!"

    # say L285 lyd
    old "Slrrrp! I love it! I can't get enough of it!"
    new "B:pla: Gostas de como o meu pénis enche a tua boca?"

    # say L287 lyd
    old "Don't cum yet! I want you to keep pushing your cock in my mouth!"
    new "B:lyd: Slrrrp! Adoro! Não me canso disto!"

    # say L290 pla
    old "That's it! Gobble on my cock!"
    new "B:lyd: Ainda não! Quero que continues a empurrar o teu pénis na minha boca!"

    # say L314 pla
    old "I'm about to cum baby! Tell me you want it in your mouth!"
    new "B:pla: É isso! Come o meu pau!"

    # say L315 lyd
    old "Yes! Yes! Shoot it all in my mouth!"
    new "Enche a minha boca com o teu esperma quente!"

    # say L317 lyd
    old "Fill my mouth with your hot cum!"
    new "B:lyd: Sim! Sim! Enche a minha boca toda!"

    # say L325 pla
    old "Phew... This guy is writing again, he says 'Wow, that was so great!'"
    new "B:lyd: Enche a minha boca com o teu sêmen quente!"

    # say L326 lyd
    old "Hahaha, great? Don't you say?"
    new "B:pla: Phew... Este tipo está a escrever de novo, diz 'Uau, isso foi tão incrível!'"

    # say L327 lyd
    old "Tell him 'It really was, I can't wait for what's next.'"
    new "B:lyd: Hahaha, ótimo, não achas?"

    # say L331 pla
    old "He answered with 'Yeah, me neither, but that'll have to wait, I have to go work, I'm 30 minutes over my break! Talk to you later, bye!'"
    new "B:lyd: Diz-lhe 'Foi mesmo, mal posso esperar pelo que vem a seguir.'"

    # say L332 pla
    old "'But be sure I'm crazy to see you!'"
    new "B:pla: Ele respondeu com 'Yeah, tu também, mas isso vai ter que esperar, tenho que ir trabalhar, já estou 30 minutos a mais no meu intervalo! Falamos depois, adeus!'"

    # say L333 lyd
    old "That's nice, I guess we'll talk later."
    new "B:pla: 'Mas tenha a certeza de que estou louco para te ver!'"

    # say L334 pla
    old "You don't want me to answer anything back?"
    new "B:lyd: Isso é bom, acho que falamos depois."

    # say L335 lyd
    old "There's no need, he'll talk to me later anyway."
    new "B:pla: Tu não queres que eu responda nada?"

    # say L349 lyd
    old "Nngh! Oh yes! This is just what I've been wanting!"
    new "B:lyd: Não é preciso, ele vai falar comigo mais tarde de qualquer maneira."

    # say L350 lyd
    old "This long, thick hard cock of yours!"
    new "B:lyd: Nngh! Oh sim! Isto é exactamente o que eu queria!"

    # say L351 lyd
    old "There's no other cock like it!"
    new "B:lyd: Este pénis longo, grosso e duro teu!"

    # say L355 lyd
    old "Y- your cock is the best!"
    new "T: O teu pénis é o melhor!"

    # say L356 lyd
    old "I've never had any cock like this!"
    new "B:lyd: Y- o teu pénis é o melhor!"

    # say L357 lyd
    old "Yes, yes, fuck me more!"
    new "B:lyd: Nunca tive um pénis assim!"

    # say L361 lyd
    old "Ohh! I love how you push into my pussy!"
    new "B:lyd: Sim, sim, foda-me mais!"

    # say L362 lyd
    old "I can't have enough of this hot cock!"
    new "B:lyd: Ohh! Adoro como tu entras na minha xoxota!"

    # say L363 lyd
    old "Fuck me! Fuck me more!"
    new "B:lyd: Não me canso deste pau quente!"

    # say L386 pla
    old "L- Lydia! I think I'm about to..."
    new "B:lyd: Foda-me! Foda-me mais!"

    # say L387 lyd
    old "Yes! Let it all out!"
    new "B:pla: L- Lydia! Acho que vou..."

    # say L388 lyd
    old "Fill me with your hot cum!"
    new "B:lyd: Sim! Deixa tudo sair!"

    # say L394 lyd
    old "That was good!"
    new "B:lyd: Enche-me com o teu sémen quente!"

    # say L395 lyd
    old "Just what I was expecting."
    new "B:lyd: Isso foi bom!"

    # say L397 pla
    old "Listen, I'm glad you're feeling better."
    new "T: Ouve, fico contente que estejas a sentir-te melhor."

    # say L398 pla
    old "But, I think it's better if you just leave. Remember this isn't your house, someone could hear us."
    new "B:pla: Ouve, fico contente que estejas a sentir-te melhor."

    # say L399 lyd
    old "Leave? What are you talking about?"
    new "B:pla: Mas, acho melhor tu ires embora. Lembra-te que esta não é a tua casa, alguém pode ouvir-nos."

    # say L400 lyd
    old "This is just the beginning!"
    new "B:lyd: Ir? Do que estás a falar?"

    # say L401 pla
    old "W- What? What else do you want to do?"
    new "B:lyd: Isto é apenas o começo!"

    # say L402 lyd
    old "Ohh, it's something I wanted to try for the longest time."
    new "B:pla: O- O quê? O que mais queres fazer?"

    # say L403 lyd
    old "But my husband was too much of a prude for it."
    new "B:lyd: Ohh, era algo que queria experimentar há muito tempo."

    # say L404 lyd
    old "Him and his stupid morale, always draggin me back!"
    new "B:lyd: Mas o meu marido era demasiado pudico para isso."

    # say L405 lyd
    old "So, now you're going to give me what I want..."
    new "B:lyd: Ele e a estúpida moral dele, sempre a arrastar-me para trás!"

    # say L407 lyd
    old "Just come here and find out."
    new "T(lyd|tu|say): Vem cá e descobre."

    # say L424 lyd
    old "It's ok if you start sl-"
    new "B:lyd: Vem cá e descobre."

    # say L425 lyd
    old "AH! AAAH!"
    new "B:lyd: Não há problema se tu começares a-"

    # say L427 lyd
    old "Oh yes! This is what I wanted!"
    new "B:lyd: AH! AAAH!"

    # say L428 lyd
    old "Mmm, nngh, it hurts a little, but is perfect!"
    new "B:lyd: Oh sim! É isto que eu queria!"

    # say L432 lyd
    old "Y- your dick is massive!"
    new "B:lyd: Mmm, nngh, dói um pouco, mas é perfeito!"

    # say L433 lyd
    old "It's stretching my ass so much!"
    new "B:lyd: T-tu és tão grande!"

    # say L434 pla
    old "S- should I stop?"
    new "B:lyd: Está a esticar o meu cu tanto!"

    # say L435 lyd
    old "No! Don't you dare!"
    new "B:pla: S- devo parar?"

    # say L436 lyd
    old "I'm loving this!"
    new "B:lyd: Não! Nem pensar!"

    # say L440 lyd
    old "YES! YES! You fucking my ass with that big dick!"
    new "B:lyd: Estou a adorar isto!"

    # say L441 lyd
    old "It's just what I wanted!"
    new "B:lyd: SIM! SIM! Estás a foder-me o cu com esse pénis enorme!"

    # say L442 lyd
    old "I'll never have enough of this dick!"
    new "B:lyd: É exactamente o que eu queria!"

    # say L443 lyd
    old "I love it when you fuck me!"
    new "B:lyd: Nunca vou ter o suficiente deste pénis!"

    # say L466 lyd
    old "I can feel your dick twitching in my ass!"
    new "B:lyd: Adoro quando tu me fodes!"

    # say L467 pla
    old "I- I'm about to finish!"
    new "B:lyd: Sinto o teu pénis a tremer dentro de mim!"

    # say L468 lyd
    old "Do it! Finish in my ass!"
    new "Faz isso! Acaba dentro de mim!"


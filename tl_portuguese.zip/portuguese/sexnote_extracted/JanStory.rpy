# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/JanStory.rpy
translate portuguese strings:

    # say L13 pla
    old "Ugh, finally at home."
    new "Ugh, finalmente em casa. Hmm. Que barulho é esse? Está vindo da sala..."

    # say L15 pla
    old "Hmm. What is that noise? It's coming from the living room..."
    new "B:pla: Ugh, finalmente em casa."

    # say L19 pla
    old "Woah! Are they... Having sex?"
    new "B:pla: Hmm. Que barulho é este? Está a vir da sala..."

    # say L35 pla
    old "I... Am... Sorry... I... Just... Heard..."
    new "A:mo2: Não ias supostamente voltar à noite?!"

    # say L37 mo2
    old "Weren't you supposed to come back at night?!"
    new "B:pla: Eu... Desculpe... Eu... Apenas... Ouvi..."

    # say L39 pla
    old "Yes, but my after school program was canceled..."
    new "B:mo2: Não ias voltar à noite?!"

    # say L84 pla
    old "I know they are married but... They should do that in their room..."
    new "B:pla:... Desculpa... Eu..."

    # say L85 pla
    old "Anyway, I have all day to relax..."
    new "B:pla: Eu sei que eles estão casados, mas... Deviam fazer isso no quarto deles..."

    # say L96 mo1
    old "Listen, I want to talk to you about t- the living room"
    new "B:pla: De qualquer forma, tenho o dia todo para relaxar..."

    # say L106 mo1
    old "Well, I won't bother you anymore. Please keep studying hard, honey."
    new "B:mo1: Fico contente por ouvir isso. Mas... quero pedir desculpa. Fomos um pouco imprudentes ao ficarmos... íntimos na sala de estar."

    # say L107 mo1
    old "Oh, by the way, you haven't had breakfast, come downstairs and I'll make you breakfast!"
    new "B:mo1: Bem, não vou incomodar-te mais. Por favor, continua a estudar bastante, querida."

    # say L132 pla
    old " (Shit!) Oh, no... Nuh uh... The door was open. I just didn't know someone was in here."
    new "B:pla: (Que raio!... o que estão a fazer?)"

    # say L136 pla
    old "I wasn't... Nevermind... I'll go."
    new "B:mo2: Vê, tentei dizer-te que ele é um maldito pervertido!... VAI EMBORA!"

    # say L160 sis
    old "I don't know, I just arrived."
    new "B:pla: Ehm... Está a acontecer alguma coisa?"

    # say L164 mo1
    old "Hmm... Actually, yes... That's why I need to talk to you both."
    new "B:sis: Não sei, acabei de chegar."

    # say L166 mo1
    old "We are having some... Uhh, financial issues..."
    new "B:mo1: Hmm... Na verdade, sim... É por isso que preciso falar com vocês."

    # say L168 mo1
    old "Well, we don't have e- enough money to pay our obligations..."
    new "B:mo1: Estamos a ter alguns... Uh, problemas financeiros..."

    # say L169 pla
    old "Ohh."
    new "B:mo1: Bem, não temos dinheiro suficiente para pagar as nossas obrigações..."

    # say L170 sis
    old "But why didn't you say anything before?"
    new "B:pla: Ohh."

    # say L171 mo1
    old "Hmm, I didn't want you to worry about it... It's my obligation to provide for both of you... It's just that our current monetary situation is getting worse and..."
    new "B:sis: Mas por que não disse nada antes?"

    # say L173 mo1
    old "I- I have been looking at some options and I have applied for different jobs but even that seems to be difficult."
    new "B:mo1: Hmm, não queria que te preocupasses com isso... É minha obrigação prover para os dois... É só que a nossa situação financeira atual está a piorar e..."

    # say L175 mo1
    old "It's not that easy... Since I have been unemployed for so long, now it's much harder for me to find a job."
    new "B:mo1: Eu... tenho estado a ver algumas opções e candidatei-me a diferentes empregos, mas até isso parece ser difícil."

    # say L180 pla
    old "You're not alone on this... Kyle and I will help you... Right?"
    new "B:mo1: Agora que ela se foi e já não estamos juntos, estamos a enfrentar muitos mais problemas. Não esperava que a situação fosse assim..."

    # say L185 mo1
    old "I- I can't now, I better go to take some rest... I can't do this now... Sorry but I can't."
    new "B:pla: Vamos encontrar uma forma de resolver isto..."

    # say L194 pla
    old "It's the first time I see [mo1rel] this worried and sad, especially sad. We gotta do something to help."
    new "B:pla: Claro [mo1rel], está tudo bem."

    # say L197 sis
    old "Yeah, yeah... I know it's sad but we gotta focus on finding a solution for this..."
    new "B:pla: Claro! Vou começar a procurar algo imediatamente... É muito triste, mas..."

    # say L198 sis
    old "Tell me once you have found something..."
    new "B:sis: Sim, sim... sei que é triste, mas temos de nos concentrar em encontrar uma solução para isto..."

    # say L199 pla
    old "I will."
    new "B: Irmã: Diz-me quando encontrares algo..."

    # say L200 sis
    old "Alright, See ya!"
    new "B:pla: Vou."

    # say L206 pla
    old "Shit! This is bad... I gotta find a job, my [mo1rel] is gonna get sick and depressed if we don't do something."
    new "T(pla|tu|say): Merda! Isto é mau... Tenho de arranjar um emprego, o meu [mo1rel] vai ficar doente e deprimido se não fizermos nada."

    # say L208 pla
    old "Maybe at the vet's store... Or with Dr. Johnson... I don't know!"
    new "B:pla: Argh! Mas onde? Realmente, onde posso encontrar um emprego?"

    # say L209 pla
    old "I know! With Lisa..."
    new "B:pla: Talvez na loja do veterinário... Ou com o Dr. Johnson... Não sei!"

    # say L229 pla
    old "What a day! Argh! It seems to be impossible to find a job... Don't know what I'm gonna do"
    new "T(pla|tu|say): Que dia! Argh! Parece impossível encontrar um trabalho... Não sei o que vou fazer."

    # say L230 pla
    old "Maybe I should ask at schoo-"
    new "T(pla|tu|say): Talvez devesse perguntar na escola..."

    # say L237 sis
    old "Hey [pla], we have to talk."
    new "T(sis|tu|diz): Ei [pla], temos que falar."

    # say L240 pla
    old "Well, I was looking for any job opportunity the whole day but no luck, nobody wants to hire me."
    new "B:sis: O que aconteceu? Porque essa cara triste?"

    # say L243 pla
    old "Did she tell you anything? Did you talk to her?"
    new "B:sis: Argh! Não consigo ver a tua irmã assim... Tens de encontrar alguma coisa, tens mesmo de encontrar."

    # say L244 sis
    old "No, she doesn't want us to notice how she's feeling, I didn't say anything and that's why I'm telling you."
    new "B:pla: Ela disse-te alguma coisa? Falaste com ela?"

    # say L247 pla
    old "I know, I know..."
    new "B:sis: Não, não podemos. Tu arranjas algo amanhã... Faz o melhor que podes, homem! Faz alguma coisa porque temos um problema sério aqui."

    # say L248 sis
    old "Good, see you tomorrow then..."
    new "B:pla: Eu sei, eu sei..."

    # say L249 pla
    old "Bye..."
    new "A:pla: Oh meu Deus! Onde é que vou arranjar um emprego agora?"

    # say L254 pla
    old "Oh my Gosh! Where am I going to find a job now?"
    new "B:pla: Adeus..."

    # say L276 aki
    old "Tell me... What can I do for you?"
    new "B:aki: Oh! Olá, lembro-me de ti, sim... Tu és o entregador atraente..."

    # say L278 pla
    old "H- Handsome? Haha t- thanks."
    new "B:aki: Diz-me... O que posso fazer por ti?"

    # say L300 pla
    old "I see but I really need to ask you for a favor..."
    new "T: Vejo isso, mas preciso pedir-te um favor..."

    # say L301 pla
    old "I need a job, I can do whatever you ask me to but I need to work. The situation at home is not ok and we all are worried."
    new "T(pla|tu|say): Preciso de um trabalho, posso fazer o que tu me pedires, mas preciso mesmo de trabalhar. A situação em casa não está boa e todos estamos preocupados."

    # say L303 mo2
    old "So you come to my office and you pretend I give you a job? Why should I do that!?"
    new "B:pla: Preciso de um emprego, posso fazer o que me pedires mas preciso de trabalhar. A situação em casa não está bem e todos estamos preocupados."

    # say L306 mo2
    old "Now that you all need me, you come here looking for me! Well, I don't care!"
    new "B:mo2: Finalmente percebeste! Sim, não gosto de ti e não te vou contratar. Não sejas estúpido! Agora vai-te embora! Não quero que fiques aqui."

    # say L308 mo2
    old "I said get out!"
    new "B:mo2: Agora que precisam de mim, vêm aqui à procura de mim! Bem, eu não me importo!"

    # say L317 pla
    old "Now where I'm going to find a job?"
    new "B:mo2: Eu disse para saíres!"

    # say L318 pla
    old "Wait, what is that sound? It comes from the livingroom..."
    new "B:pla: Agora onde é que vou arranjar um emprego?"

    # say L336 pla
    old "Are you crying? I don't want to see you like this [mo1rel]."
    new "B:pla: Oh, [mo1rel]? A- Estás bem?"

    # say L342 pla
    old "We'll do whatever it takes to make you feel better."
    new "Não te preocupes, somos uma família e encontraremos uma forma de resolver isto. Faremos tudo o que for preciso para te fazer sentir melhor. A única coisa que me faria sentir melhor é... Argh!"

    # say L343 mo1
    old "The only thing that would make me feel better is... Argh!"
    new "B:pla: Faremos tudo o que for preciso para te fazer sentir melhor."

    # say L345 mo1
    old "This is hard, you know... It's really hard to feel so helpless, I feel my hands are tied and there is nothing I can do."
    new "B:mo1: A única coisa que me faria sentir melhor é... Argh!"

    # say L346 pla
    old "I'm so so sorry."
    new "B:mo1: Isto é difícil, sabes... É realmente difícil sentir-me tão impotente, sinto que as minhas mãos estão atadas e não posso fazer nada."

    # say L348 mo1
    old "I'll rest for now... I can barely talk..."
    new "B:pla: Estou tão, tão desculpado."

    # say L356 pla
    old "It doesn't matter what I have to do to get that job... I don't want to see my [mo1rel] so depressed and worried."
    new "Não importa o que tenha de fazer para conseguir esse emprego... Não quero ver a minha [mo1rel] tão deprimida e preocupada."

    # say L375 aki
    old "I- I'm calling him, but he doesn't answer."
    new "B:mo2: Isto é absurdo! O que aconteceu ao rapaz das entregas?"

    # say L376 mo2
    old "What? It's incredible how useless everyone in this company is... What am I paying these people for!?"
    new "B:aki: I- Estou a ligar-lhe, mas ele não atende."

    # say L377 mo2
    old "We should have sent those documents hours ago... "
    new "B:mo2: Que? É incrível como toda a gente nesta empresa é inútil... Para que é que estou a pagar a estas pessoas!?"

    # say L387 mo2
    old "Akita, I'm waiting for an answer, what happened to the delivery boy? Can we get another one? I need you to solve this fucking issue NOW!"
    new "B:mo2: Argh! Mais uma vez tu..."

    # say L390 pla
    old "I- I could d- deliver t- those d- documents..."
    new "B:mo2: Tu não s- sabes...?"

    # say L392 mo2
    old "Are you fucking kidding me!? You're an idiot, I won't trust you with those things, just get out, I told you I don't want you here..."
    new "B:pla: E-Eu p-poderia e-entregar e-esses d-documentos..."

    # say L397 aki
    old "Uhh... I- I'm afraid there is no other way right now..."
    new "B:mo2: Não e não! Não quero que ele faça nada... Akita, arranja outra maneira..."

    # say L420 pla
    old "H- Hello?"
    new "B:pla: Vou-me embora..."

    # say L421 sop
    old "Yes, pardon me?"
    new "B:pla: H- Olá?"

    # say L424 sop
    old "Do you have the documents? Let me see them, please."
    new "B:sop: Olá! Eu sou a Amy, prazer em conhecer-te."

    # say L426 pla
    old "Yes, here they are..."
    new "B:sop: Tens os documentos? Deixa-me ver, por favor."

    # say L428 sop
    old "Perfect... You came just in time, we were waiting for them."
    new "B:pla: Sim, aqui estão..."

    # say L430 pla
    old "Well... Guess that's it... Thank you."
    new "B:sop: Perfeito... Chegaste a tempo, estávamos à espera deles."

    # say L440 pla
    old "Alright, I think that was easier than I expected. Now it's time to go back to [mo2]'s office."
    new "T: Tudo bem, acho que foi mais fácil do que esperava. Agora é hora de voltar ao escritório da [mo2]."

    # say L462 pla
    old "(I can't even focus...)"
    new "B: H- Hello A- Akita..."

    # say L463 pla
    old "Good... I delivered everything."
    new "B:pla: (Não consigo nem me concentrar...)"

    # say L469 aki
    old "So apparently you did a good job..."
    new "B:pla: Bom... Entreguei tudo."

    # say L470 pla
    old "Y- Yeah... Well, I delivered the documents and the girl said it was fine and that it was in time, so I guess, yeah..."
    new "B:aki: Parece que fizeste um bom trabalho..."

    # say L471 aki
    old "I know, I know... And... Hmm."
    new "T(aki|tu|say): Sei, sei... E... Hmm."

    # say L472 pla
    old "Yeah? What happened? Did I do anything wrong?"
    new "Bem... Hmm, não aqui mas... Reparaste no que tens lá embaixo?"

    # say L473 aki
    old "Well... Hmm, not here but... Did you notice what you have down there?"
    new "B:pla: Sim? O que aconteceu? Fiz algo errado?"

    # say L474 pla
    old "What? What do you mea-"
    new "B:aki: Bem... Hmm, não aqui mas... Reparaste no que tens aí em baixo?"

    # say L476 pla
    old "Argh fuck! I- I don't kno- I- I h- have to go."
    new "B:pla: O quê? O que tu queres dizer..."

    # say L493 mo2
    old "You better have done it right!"
    new "B:pla: Ah, merda! E- Eu n- não s- sei... E- Eu t- tenho que ir."

    # say L496 pla
    old "M- me? Uhh, no... Nothing..."
    new "B:mo2: O que se passa contigo? Porque estás a comportar-te tão estranhamente?"

    # say L497 mo2
    old "What do you have on your hands? Why are you acting like a freak? You idiot! Tell me what have you done?"
    new "B: M-mim? Ah, não... Nada..."

    # say L502 mo2
    old "What the fuck!? You are a fucking pervert!"
    new "B:mo2: Não vais enganar-me... Deixa-me ver as tuas mãos agora! O que estás a esconder?"

    # say L504 mo2
    old "Why do you have a fucking boner right now?"
    new "B:mo2: Que raio!? Tu és um pervertido!"

    # say L506 mo2
    old "Explain what?"
    new "A:mo2: Que tu ficaste com tesão e agora tens um EREÇÃO À FRENTE DE MIM!?"

    # say L507 mo2
    old "That you got fucking horny and now you're having a BONER IN FRONT OF ME!?"
    new "B:mo2: Explicar o quê?"

    # say L508 pla
    old "N- not r- really..."
    new "B:mo2: Que ficaste com uma PUTA VONTADE E AGORA TENS UMA EREÇÃO À FRENTE DE MIM!?"

    # say L509 mo2
    old "Bullcrap!"
    new "B: N-não... n-não realmente..."

    # say L511 mo2
    old "I've had a pretty shitty day and now this... BUT! You'll see... Little motherfucker... You'll see!"
    new "B:mo2: Merda!"

    # say L512 pla
    old "W- What? "
    new "B:mo2: Tive um dia de merda e agora isto... MAS! Vais ver... Pequeno filho da puta... Vais ver!"

    # say L513 mo2
    old "Get on the floor... NOW!"
    new "B:pla: Q- Que?"

    # say L514 pla
    old "O- On t- the f- floor? W- why?"
    new "B:mo2: Anda para o chão... AGORA!"

    # say L515 mo2
    old "I've given you an order! Do it, you are a stupid pervert... Do what I'm telling you and do it now."
    new "B:pla: O- O n- no chão? P- porquê?"

    # say L516 pla
    old "(Oh fuck!)"
    new "B:mo2: Já te dei uma ordem! Faz o que estou a dizer e faz já, tu és um pervertido estúpido..."

    # say L517 mo2
    old "Your knees on the floor NOW!"
    new "B:pla: (Oh merda!)"

    # say L518 pla
    old "A- alright... Uhh."
    new "B:mo2: As tuas joelhos no chão AGORA!"

    # say L522 mo2
    old "I'll have fun with you... You get horny here... I give you shit!"
    new "B: pla: A- tudo bem... Hum."

    # say L523 mo2
    old "You will suck my foot!"
    new "B:mo2: Vou divertir-me contigo... Ficas excitada aqui... Dou-te lixão!"

    # say L524 pla
    old "W- what!? Do you want me to suck you-"
    new "B:mo2: Vais chupar o meu pé!"

    # say L525 mo2
    old "WHAT? WHY are you questioning me? I've just said, SUCK MY FOOT!"
    new "B:pla: Q- que!? Queres que eu te chupe..."

    # say L543 mo2
    old "Go! Disappear from here... I don't want to see you."
    new "B:mo2: O QUÊ? PORQUÊ estás a questionar-me? Acabei de dizer, CHUPA O MEU PÉ!"

    # say L544 pla
    old "B- but what about the job? Can I c- come back?"
    new "B:mo2: Vai! Desaparece daqui... Não quero ver-te."

    # say L545 mo2
    old "Yes, whatever... Just go away."
    new "B: B- mas e o trabalho? Posso v- voltar?"

    # say L546 pla
    old "S- So am I hired?"
    new "B:mo2: Sim, claro... Só vai embora."

    # say L547 mo2
    old "Are you stupid or what? I just said YES! Now, GET OUT!"
    new "B:pla: S- Então, fui contratado?"

    # say L552 pla
    old "Fuck! That was weird..."
    new "B:mo2: Estás parvo ou quê? Acabei de dizer SIM! Agora, VAI-TE EMBORA!"

    # say L571 mo1
    old "I'm still worried about our economic situation..."
    new "B:mo1: Olá querida, estou bem... Não tão bem assim, mas acho que vou ficar tudo bem eventualmente..."

    # say L572 pla
    old "No [mo1rel]! You don't have to worry about it... I got a job and I'll be able to help you."
    new "T(pla|tu|say): Não [mo1rel]! Tu não tens de te preocupar com isso... Arranjei um emprego e vou poder ajudar-te."

    # say L575 mo1
    old "[mo2]? Are you serious?"
    new "B:pla: Hmm... Estou a trabalhar no escritório da [mo2]... Basicamente, acabei de começar, mas sim... É bom que vou ter algum dinheiro para ajudar..."

    # say L578 mo1
    old "And... Is she fine? Hmm, has she asked for me or anything...?"
    new "B:pla: Sim, ela deu-me uma oportunidade de trabalhar para ela..."

    # say L583 mo1
    old "Honey, go get some rest... I guess you've been tired since you started working..."
    new "B:mo1: Ok... Acho que ela está bem... Provavelmente melhor do que eu..."

    # say L584 pla
    old "Kinda, today it's been a very long and hard day... I'm gonna head to my room."
    new "B:mo1: Querida, vai descansar... Acho que tens andado cansada desde que começaste a trabalhar..."

    # say L585 mo1
    old "I imagine how hard it is working with her..."
    new "B:pla: Mais ou menos, hoje foi um dia muito longo e difícil... Vou para o meu quarto."

    # say L586 pla
    old "(Well... It was hard, quite literally...)"
    new "B:mo1: Imagino o quão difícil é trabalhar com ela..."

    # say L604 sis
    old "I'm great. What about You?"
    new "Bem, consegui um emprego!"

    # say L605 pla
    old "Well, I got a job!"
    new "B:sis: Estou ótima. E tu?"

    # say L606 sis
    old "Cool, finally man! What's it about?"
    new "B:pla: Tenho um emprego!"

    # say L608 sis
    old "[mo2]? Really?... But that woman hates you..."
    new "B:pla: Essa é a parte menos fixe... Estou a trabalhar com a [mo2]..."

    # say L609 sis
    old "What are you doing for her?"
    new "Hmm... Só como... entregador..."

    # say L611 pla
    old "Hmm... Just l- like... delivery guy...."
    new "B:sis: O que estás a fazer por ela?"

    # say L612 sis
    old "I see... Well you have talent for that, don't you? Hahaha. "
    new "B:pla: Hmm... Apenas como... entregador...."

    # say L613 pla
    old "Yeah, so funny... "
    new "B:sis: Eu vejo... Bem, tu tens talento para isso, não é? Hahaha."

    # say L614 sis
    old "At least you finally got a job."
    new "Pelo menos tu finalmente arranjaste um emprego."

    # say L615 pla
    old "Hmm, I know... I know..."
    new "B:sis: Pelo menos finalmente arranjaste um emprego."

    # say L616 pla
    old "Today was a really weird day, I need some rest, see you."
    new "B:pla: Hmm, eu sei... eu sei..."

    # say L617 sis
    old "I believe you, Hahaha, see you."
    new "B:pla: Hoje foi um dia realmente estranho, preciso descansar, até logo."

    # say L637 aki
    old "Oh great, so are you ready to start with the new deliveries?"
    new "B:pla: Olá Akita, tudo bem... A envolver-me no trabalho."

    # say L638 pla
    old "Yeah, please explain to me what I have to do."
    new "B:aki: Ótimo, então estás pronto para começar com as novas entregas?"

    # say L639 aki
    old "Well, it really is very simple, at the moment we must send correspondence from some projects to three specific places."
    new "B:pla: Sim, explica-me o que tenho de fazer."

    # say L641 aki
    old "They all have a different format depending on where they should go."
    new "B:aki: Bem, é realmente muito simples, neste momento temos de enviar correspondência de alguns projetos para três locais específicos."

    # say L642 aki
    old "For example, all mayoral documents have a red border."
    new "B:aki: Eles têm um formato diferente dependendo de onde devem ser enviados."

    # say L643 aki
    old "While the documents that go to the bank are green."
    new "B:aki: Por exemplo, todos os documentos do prefeito têm uma borda vermelha."

    # say L644 aki
    old "And finally the yellow documents for the factory."
    new "B:aki: Enquanto os documentos que vão para o banco são verdes."

    # say L646 pla
    old "Red, green and yellow, got it."
    new "B:aki: E finalmente os documentos amarelos para a fábrica."

    # say L647 aki
    old "It shouldn't be difficult at all, you just need to send them quickly to reach all the deliveries of the day."
    new "B:pla: Vermelho, verde e amarelo, percebi."

    # say L648 aki
    old "Anyway if you need anything else just let me know."
    new "B: aki: Não deve ser nada difícil, só precisas de os enviar rapidamente para conseguires fazer todas as entregas do dia."

    # say L649 pla
    old "Alright, thank you."
    new "Tudo bem, obrigado. Estou pronto para começar as entregas."

    # say L650 aki
    old "So? Are you ready to start the deliveries?"
    new "T(aki|tu|diz): Então? Estás pronto para começar as entregas?"

    # say L651 pla
    old "Sure! Let's do it."
    new "Então, tu achas que estou a pagar para fazer um trabalho mal feito? É isso que tu pensas?"

    # say L662 mo2
    old "So do you think I'm paying to do a shitty job? Is that what you think?"
    new "B:pla: Claro! Vamos lá."

    # say L663 pla
    old "No! No [mo2]! I'm sorry... I'm still learning but I promise I'll do it better."
    new "Não! Não [mo2]! Desculpa... Ainda estou a aprender mas prometo que vou fazer melhor."

    # say L665 mo2
    old "I can let this go... You gotta learn a lesson out of this."
    new "B:mo2: Tu és um idiota... Duvido seriamente que faças melhor..."

    # say L666 pla
    old "A- A l- lesson? But I just started working with you..."
    new "B:mo2: Posso deixar isto passar... Mas tens de aprender uma lição com isto."

    # say L667 mo2
    old "And now you're questioning my decisions... You better change that fucking shitty behavior or you'll suffer in this office."
    new "B:pla: A- A lição? Mas eu acabei de começar a trabalhar contigo..."

    # say L668 mo2
    old "Do you understand that?"
    new "B:mo2: E agora estás a questionar as minhas decisões... Melhor mudares esse comportamento de merda ou vais sofrer neste escritório."

    # say L670 mo2
    old "DO YOU? I'm asking..."
    new "B:mo2: Entendeste isso?"

    # say L671 pla
    old "Y- Yeah... I do."
    new "B:mo2: FAZES? Estou a perguntar..."

    # say L672 mo2
    old "Good! Now get on the floor... You'll see what it's like not doing a good job for me..."
    new "B: pla: H- Hmm... Sim."

    # say L680 mo2
    old "I guess lastime wasn't enough for you... You deserve to be on the floor where you belong!"
    new "B:mo2: Ótimo! Agora deita-te no chão... Vais ver o que é não fazer um bom trabalho para mim..."

    # say L681 mo2
    old "You're my little bitch on the floor... Waiting for me to feed you."
    new "B:mo2: Acho que a última vez não foi suficiente para ti... Tu mereces estar no chão onde pertences!"

    # say L683 mo2
    old "That's how you should be treated, like the cockroach that you are!"
    new "B:mo2: Tu és a minha pequena cadela no chão... À espera de eu te alimentar."

    # say L687 mo2
    old "You got a hardon?! Ughh... That's disgusting!"
    new "B:mo2: É assim que deves ser tratado, como a barata que és!"

    # say L691 mo2
    old "Alright, if this is what a pervert wants, maybe I should use other methods of punishment."
    new "B:mo2: Tu estás com uma ereção?! Ughh... Isso é nojento!"

    # say L692 mo2
    old "Let's see if this teaches you a lesson!"
    new "B:mo2: Se é isso que um pervertido quer, talvez devesse usar outros métodos de castigo."

    # say L707 mo2
    old "I won't talk to her."
    new "B:mo2: Oh meu Deus! A sério?"

    # say L708 mo2
    old "Now just get out idiot! I feel gross just by seeing you."
    new "B:mo2: Não vou falar com ela."

    # say L714 pla
    old "What am I doing?"
    new "B:mo2: Agora sai daqui, idiota! Sinto-me nojenta só de te ver."

    # say L715 pla
    old "[mo2] is crazy... I can't keep doing whatever she wants."
    new "[mo2] está louca... Não posso continuar a fazer o que ela quer."

    # say L716 pla
    old "Argh!"
    new "Olá Akita, tudo bem..."

    # say L732 pla
    old "Hello Akita, all good..."
    new "B:pla: Argh!"

    # say L733 aki
    old "Great! You know what you've to do... So just let me know if you need help."
    new "B:pla: Olá Akita, tudo bem..."

    # say L738 pla
    old "I would like to know if all the documents that must be sent today are ready?"
    new "B:aki: Ótimo! Sabes o que tens a fazer... Então avisa-me se precisares de ajuda."

    # say L746 aki
    old "Yes, I got all of them."
    new "B:aki: Ótimo, até mais tarde."

    # say L747 pla
    old "Oh, perfect."
    new "T(pla|tu|say): Oh, perfeito."

    # say L754 pla
    old "Could you please explain to me again the what I have to do."
    new "T(pla|tu|say): Poderias explicar-me de novo o que tenho de fazer?"

    # say L755 aki
    old "Sure, it's very simple, at the moment we must send correspondence from some projects to three specific places."
    new "T(aki|tu|dizer): Claro, é muito simples, neste momento temos de enviar correspondência de alguns projetos para três locais específicos. A:ki: Por exemplo, todos os documentos enviados ao prefeito ou ao seu gabinete têm um contorno vermelho."

    # say L758 aki
    old "For example, all documents sent to the mayor or his office have a red frame."
    new "B:aki: Claro, é muito simples, neste momento temos de enviar correspondência de alguns projetos para três locais específicos."

    # say L761 pla
    old "Red, green and yellow, got it, "
    new "Aki: Uau, és mesmo bom nisto!"

    # say L804 aki
    old "Wow, You're good at this!"
    new "B:pla: Vermelho, verde e amarelo, percebi."

    # say L805 pla
    old "Haha, thanks! I'm doing my best..."
    new "B:aki: Wow, Tu és bom nisto!"

    # say L806 aki
    old "Good job, keep it up!"
    new "B:pla: Haha, obrigado! Estou a fazer o meu melhor..."

    # say L809 pla
    old "Hey, do you know if I can talk to [mo2]?"
    new "T(pla|tu|say): Ei, sabes se posso falar com [mo2]?"

    # say L811 pla
    old "Hmm, right... Ok, thank you Akita."
    new "B:aki: Uhh, bem, ela está sempre ocupada, não acho que vou atender-te, a menos que seja para repreender ou castigar-te..."

    # say L831 aki
    old "It's fine, just do your best because you know how [mo2] is, she'll give you shit if you keep failing."
    new "T(aki|tu|dizes): Tudo bem, só faz o teu melhor porque sabes como a [mo2] é, ela vai-te dar uma tareia se continuares a falhar."

    # say L835 aki
    old "Good luck..."
    new "A:mo2: Sabia que eras estúpido, mas não imaginava que fosses tanto."

    # say L857 mo2
    old "I know you were stupid but I didn't imagine this much."
    new "B:aki: Boa sorte..."

    # say L858 pla
    old "Listen, I- I know I did wrong again but... I- I am sorry [mo2]."
    new "T(pla|tu|say): Ouve, eu- eu sei que errei de novo mas... eu- eu sinto muito [mo2]. A:pla: Vou ter mais cuidado da próxima vez."

    # say L860 mo2
    old "Yeah... Whatever... I don't care about the next time..."
    new "B:pla: Vou ter mais cuidado da próxima vez."

    # say L861 mo2
    old "Now you gotta pay for this one."
    new "B:mo2: Sim... Tanto faz... Não me importo com a próxima vez..."

    # say L862 pla
    old "A- Again?"
    new "T(pla|tu|say): A- Outra vez?"

    # say L863 mo2
    old "I have done some stuff wrong with you..."
    new "B: pla: A - Outra vez?"

    # say L864 mo2
    old "You shouldn't get so much pleasure for all mistakes you've done here..."
    new "B:mo2: Eu fiz algumas coisas erradas contigo..."

    # say L866 mo2
    old "You have been a lucky idiot!"
    new "B:mo2: Não deves sentir tanto prazer por todos os erros que cometeste aqui..."

    # say L867 mo2
    old "But not anymore!"
    new "B:mo2: Tu foste um idiota com sorte!"

    # say L869 mo2
    old "I should get something in return for hiring such a stupid person... And for still paying you."
    new "B:mo2: Mas já não!"

    # say L870 mo2
    old "You have been the worst employee I have ever had... The most useless person I have worked with. You're disgusting."
    new "B:mo2: Deveria receber algo em troca de contratar uma pessoa tão estúpida... E ainda estar a pagar-te."

    # say L872 mo2
    old "What kind of punishment should I give you this time?"
    new "B:mo2: Tu foste o pior funcionário que já tive... A pessoa mais inútil com quem já trabalhei. Tu és nojento."

    # say L873 mo2
    old "I definitely did wrong giving you pleasure, an idiot like you will only learn the hard way."
    new "B:mo2: Que tipo de castigo devo dar-te desta vez?"

    # say L874 mo2
    old "Then perhaps the best thing is that this time you are the one who gives pleasure, like the useless little bitch you are."
    new "B:mo2: Certamente fiz mal em te dar prazer, um idiota como tu só aprende à custa de sofrimento."

    # say L875 mo2
    old "I know! Come here!"
    new "B:mo2: Então talvez o melhor seja que desta vez sejas tu a dar prazer, como a putinha inútil que és."

    # say L883 mo2
    old "You'll lick my pussy... Let's see if you can do it well or you're completely useless..."
    new "B:mo2: Eu sei! Vem aqui!"

    # say L884 pla
    old "W- WHAT? Y- Your puss-"
    new "B:mo2: Vais lamber a minha xoxota... Vamos ver se o fazes bem ou és completamente inútil..."

    # say L885 mo2
    old "I don't understand why you keep talking... More licking and less talking. You're my bitch, remember?"
    new "B:pla: Q- QUÊ? T- Tuas..."

    # say L903 mo2
    old "I don't care! Don't waste my time with this bullshit."
    new "B:mo2: Ohh vamos, tu de novo com isso?"

    # say L904 mo2
    old "I'm not going to pay again for all of you leechers..."
    new "B:mo2: Não me importo! Não desperdicem o meu tempo com esta merda."

    # say L905 pla
    old "No, isn't about paying-"
    new "B:mo2: Não vou pagar de novo para todos vocês parasitas..."

    # say L906 mo2
    old "Just go away."
    new "B:pla: Não, não é sobre pagar-"

    # say L912 pla
    old "Hmm, this is not working..."
    new "B:mo2: Vai-te embora."

    # say L932 pla
    old "This is serious... I don't know, we gotta do something."
    new "B:sis: Sim... Ela está tão deprimida..."

    # say L937 pla
    old "Don't worry Kylee, we'll do something."
    new "B:pla: Eu sei... Vou..."

    # say L939 sis
    old "I hope we do... See you, then."
    new "B:pla: Não te preocupes, Kylee, vamos fazer algo."

    # say L964 mo2
    old "I assume you're already imagining how you gonna pay for it..."
    new "B:mo2: Parece mesmo que és um grande idiota! Continuas a cometer os mesmos erros..."

    # say L965 pla
    old "(Oh God, Now what?)"
    new "B:mo2: Acho que já estás a imaginar como vais pagar isso..."

    # say L969 mo2
    old "You'll need to focus on this NOW!"
    new "B:mo2: Não ME IMPORTO! Não me importo com a tua vida miserável."

    # say L970 mo2
    old "Now you will do what I tell you to do! You'll do whatever I want! I'm your Master, I'm the one paying you and you'll follow my orders!"
    new "B:mo2: Vais ter de te concentrar nisto AGORA!"

    # say L971 mo2
    old "Your job and what you do is shit! Now do what I tell you."
    new "B:mo2: Agora vais fazer o que eu te disser! Vais fazer tudo o que eu quiser! Sou o teu Mestre, sou eu quem te paga e vais seguir as minhas ordens!"

    # say L972 mo2
    old "Now is the time to pay back the money I'm paying you for all your shitty work."
    new "B:mo2: O teu trabalho é uma merda! Agora faz o que eu digo."

    # say L979 mo2
    old "Come on, you already know what to do."
    new "B:mo2: Agora é a hora de pagar o dinheiro que estou a pagar-te por todo o teu trabalho medíocre."

    # say L980 pla
    old "Uhh... A- alright."
    new "B:mo2: Vamos, tu já sabes o que fazer."

    # say L996 pla
    old "Why don't you call her? Just to... Argh!"
    new "B:pla: Acho que ela está a ficar deprimida."

    # say L998 mo2
    old "Crying? Is she that bad?"
    new "B:pla: Porque não lhe ligas? Só para... Argh!"

    # say L999 pla
    old "I'm not lying, she's feeling like shit."
    new "A:mo2: Eu podia visitar..."

    # say L1000 mo2
    old "I could visi-"
    new "B:pla: Não estou a mentir, ela está a sentir-se mal."

    # say L1001 mo2
    old "No! Just stop with that bullshit... And get out..."
    new "B:mo2: Eu podia visitar..."

    # say L1016 pla
    old "What the... W- what are you doing."
    new "B:mo2: Não! Pára com essa merda... E sai daqui..."

    # say L1019 mo2
    old "Well, I knew you wouldn't learn so I'll have to use more drastic methods."
    new "B:pla: Que... Q- o que estás a fazer."

    # say L1020 mo2
    old "So I'm going to give you a couple of new lessons, it seems that with you it will always have to be in the hard way."
    new "B:mo2: Bem, sabia que tu não ias aprender, por isso vou ter de usar métodos mais drásticos."

    # say L1027 mo2
    old "Alright, undress and lie on the floor."
    new "B:mo2: Vou dar-te algumas lições novas, parece que contigo sempre terá de ser à força."

    # say L1028 pla
    old "B- but... I- I don't-"
    new "B:mo2: Despe-te e deita-te no chão."

    # say L1029 mo2
    old "Are you questioning your master's orders?"
    new "B: B- mas... E- Eu não..."

    # say L1030 pla
    old "No, no, I'm sorry master."
    new "B:mo2: Estás a questionar as ordens do teu mestre?"

    # say L1046 mo2
    old "Not today, I really don't have time, I already wasted it all with you."
    new "B:pla: Bem, sim, ela é-"

    # say L1047 mo2
    old "Maybe if you do a good job I wouldn't have to waste time with you."
    new "B:mo2: Não hoje, realmente não tenho tempo, já desperdicei tudo contigo."

    # say L1062 mo2
    old "What a surprise, again complaints about your work."
    new "B:mo2: Talvez se fizeres um bom trabalho não tenha de perder tempo contigo."

    # say L1065 pla
    old "No, I'm sorry, master."
    new "B:mo2: Tu finges ser quem dá as ordens?"

    # say L1066 mo2
    old "That sounds so much better."
    new "B:pla: Não, peço desculpa, mestre."

    # say L1067 mo2
    old "Okay, let's not waste any more time, so get naked and lie down on the floor."
    new "B:mo2: Isso soa muito melhor."

    # say L1068 pla
    old "Yes, master."
    new "B:mo2: Okay, não vamos perder mais tempo, então tira a roupa e deita-te no chão."

    # say L1084 mo2
    old "Argh! Ok... Let's imagine I'll go... When should I pass by."
    new "B:pla: Visita-a, por favor... Faz-me trabalhar mais se quiseres... Mas visita-a."

    # say L1087 pla
    old "Yes, yes... T- Thanks anyway."
    new "B:mo2: Escuta, pequeno bastardo! Vou só porque quero ver se ela é realmente tão má assim, não por tua causa. Entendido?"

    # say L1089 mo2
    old "Ask her when it's a good time to swing by and I'll be there..."
    new "B:pla: Sim, sim... Obrigado de qualquer forma."

    # say L1090 mo2
    old "I hope you're not lying to me..."
    new "N- Não."

    # say L1092 pla
    old "N- No."
    new "B:mo2: Espero que não estejas a mentir-me..."

    # say L1093 mo2
    old "Fuck! I'll kill you if you're lying to me."
    new "B:pla: N- Não."

    # say L1094 mo2
    old "Alright, go away. I have to work."
    new "B:mo2: Merda! Vou matar-te se estiveres a mentir-me."

    # say L1115 pla
    old "Hi [mo1rel]! How are you?"
    new "B:pla: (Pelo menos ela vai ver o [mo1rel]... É alguma coisa.)"

    # say L1116 mo1
    old "Hi honey... I'm fine, and you?"
    new "A:pla: Adivinha o quê?"

    # say L1117 pla
    old "Guess what?"
    new "Não sei, o que aconteceu?"

    # say L1118 mo1
    old "I don't know, what happened?"
    new "B:pla: Adivinha o quê?"

    # say L1120 mo1
    old "What? [mo2] wants to see me? When?"
    new "B:pla: [mo2] está a caminho para te ver..."

    # say L1122 mo1
    old "Oh God! That's great! Tell her to come tomorrow."
    new "B:pla: Bem, falei com ela e ela disse que virá quando tu quiseres..."

    # say L1123 mo1
    old "I'll have to wear something nice... Yes, tell her that tomorrow is fine and that I'll be waiting for her."
    new "B:mo1: Oh Deus! Isso é ótimo! Diz-lhe para vir amanhã."

    # say L1124 pla
    old "I'll... And I'm glad you're feeling better now."
    new "B:mo1: Vou ter de vestir-me bem... Sim, diz-lhe que amanhã está bem e que estarei à espera dela."

    # say L1125 mo1
    old "Thanks for doing this for me..."
    new "B:pla: Vou... E fico contente que te sintas melhor agora."

    # say L1126 mo1
    old "Get some rest, honey... You've been working a lot."
    new "B:mo1: Obrigado por fazeres isto por mim..."

    # say L1128 pla
    old "I'm heading to my room... Love you [mo1rel]!"
    new "B:pla: Todos os dias são mais difíceis, [mo1rel]... Mas está tudo bem enquanto tu estás bem e menos preocupada."

    # say L1148 pla
    old "I know, I know, I'm sorry..."
    new "B:mo2: E aqui estás tu de novo... Tu és definitivamente um caso perdido."

    # say L1149 pla
    old "However, I actually wanted to talk about the visit- "
    new "B:pla: Eu sei, eu sei, desculpa..."

    # say L1150 mo2
    old "Shut up! I give a shit about what you want. I am your master and it's time for your punishment."
    new "B:pla: No entanto, eu queria falar sobre a visita-"

    # say L1151 mo2
    old "Get on the floor... That's your place."
    new "B:mo2: Cala-te! Não me importo com o que tu queres. Sou o teu mestre e é hora da tua punição."

    # say L1152 pla
    old "Come on, just a second. I don't want to do this."
    new "B:mo2: Anda para o chão... É o teu lugar."

    # say L1153 mo2
    old "Get on the fucking floor now..."
    new "B:pla: Vamos, só um segundo. Não quero fazer isto."

    # say L1154 pla
    old "I- I'm not gonna do it... No, no more."
    new "A:mo2: Estou a dizer-te para te deitares no chão!"

    # say L1155 mo2
    old "I'm telling you to get on the fucking floor!"
    new "B:pla: N-Não vou fazer... Não, não mais."

    # say L1156 pla
    old "You can't keep doing this, it's humiliating for me."
    new "T: Não podes continuar a fazer isto, é humilhante para mim."

    # say L1157 mo2
    old "WHAT!? What did you just say to me? Did you say NO to your Master?"
    new "B:pla: Não podes continuar a fazer isto, é humilhante para mim."

    # say L1162 mo2
    old "Do you think you are better than me? I have kicked bigger butts than yours!"
    new "B:mo2: O QUÊ!? O que acabaste de me dizer? Disseste NÃO ao teu Mestre?"

    # say L1163 mo2
    old "You're getting in real trouble with me! I'm commanding you, did you get that part?"
    new "B:mo2: Achas que és melhor do que eu? Já dei uma maior que a tua!"

    # say L1165 mo2
    old "Don't you dare to say NO to me, you obey to whatever I say because I'm your fucking master and you're nothing..."
    new "B:mo2: Estás a meter-te em sarilhos comigo! Estou a ordenar-te, percebeste?"

    # say L1166 mo2
    old "You're my little bitch, a cockroach, my slave..."
    new "B:mo2: Nem ousas dizer NÃO, tu obedece a tudo o que eu digo porque eu sou o teu maldito amo e tu não és nada..."

    # say L1167 mo2
    old "This time you will really be punished, you must learn to obey your master."
    new "B:mo2: Tu és a minha pequena cadela, uma barata, a minha escrava..."

    # say L1183 pla
    old "Master? May I ask you something?"
    new "B:mo2: Desta vez vais ser realmente castigado, tens de aprender a obedecer ao teu mestre."

    # say L1184 mo2
    old "Hmm... You're learning... You're starting to understand..."
    new "B:pla: Mestre? Posso fazer-lhe uma pergunta?"

    # say L1185 mo2
    old "It's good that you ask me... You don't do anything without my permission."
    new "É bom que me perguntes... Não fazes nada sem a minha permissão."

    # say L1186 mo2
    old "Speak..."
    new "B:mo2: É bom que me perguntes... Não fazes nada sem a minha permissão."

    # say L1189 pla
    old "T- Thanks..."
    new "Bem, agora sai!"

    # say L1190 mo2
    old "Alright, now get out!"
    new "B:pla: T- Obrigado..."

    # say L1215 pla
    old "Wow, you look gorgeous!"
    new "B:mo1: Olá querida, como estou?"

    # say L1216 mo1
    old "Oh, really? Thank you honey..."
    new "B:pla: Uau, estás linda!"

    # say L1218 pla
    old "Uhh, yes, [mo2] is coming today... If that's what you're asking..."
    new "B:mo1: Então? Tens alguma novidade sobre [mo2]?"

    # say L1222 mo1
    old "Sure, take care, honey."
    new "B:pla: Agora tenho de ir, preciso de tirar uma sesta..."

    # say L1230 pla
    old "(Huh? What's that noise?)"
    new "B:mo1: Claro, cuida-te, querida."

    # say L1243 pla
    old "Oh my God, I have never been so happy to see someone having sex!"
    new "B:pla: Uau, eles estão a fazer sexo!"

    # say L1270 pla
    old "From now on, I am free! I will no longer have to bear Jane's humiliations!"
    new "B:pla: Estão juntos de novo, tudo vai ficar bem e não terei de voltar ao seu consultório."

    # say L1284 mo2
    old "I have a business trip, but I'll see you in the office in a few weeks..."
    new "B:mo2: Não finjas ser um bom rapaz... Eu sei o quão desagradável tu és e o quão pervertido podes ser."

    # say L1285 pla
    old "B- But..."
    new "B:mo2: Tenho uma viagem de trabalho, mas vejo-te no escritório daqui a algumas semanas..."

    # say L1286 mo2
    old "Excuse me!?"
    new "B: B- Mas..."

    # say L1287 mo2
    old "Did I hear a BUT?"
    new "B:mo2: Desculpe!?"

    # say L1288 mo2
    old "I thought you had already learned how you have to talk to me..."
    new "B:mo2: Ouvi um MAS?"

    # say L1289 pla
    old "S- Sorry..."
    new "B:mo2: Eu pensei que tu já tivesses aprendido como tens de falar comigo..."

    # say L1291 pla
    old "Master... May I talk to you?"
    new "B:pla: S- Desculpa..."

    # say L1292 mo2
    old "Now you can, slave."
    new "B: Mestre... Posso falar contigo?"

    # say L1293 pla
    old "You said that we'll see each other in the office bu-"
    new "Tu disseste que nos veríamos no escritório, mas..."

    # say L1294 mo2
    old "Yes, I said it!"
    new "B:pla: Disseste que nos veríamos no escritório, mas..."

    # say L1295 mo2
    old "You'll do whatever I want, nothing's gonna change..."
    new "B:mo2: Sim, eu disse!"

    # say L1299 pla
    old "Y- Yes..."
    new "B:mo2: Não te esqueças que... Agora és a minha cadela."

    # say L1301 pla
    old "Oh God... "
    new "B: pla: T-Tu..."


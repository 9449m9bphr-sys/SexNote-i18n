# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/System/script.rpy
translate portuguese strings:

    # say L562 ladGuide
    old "Go to Sleep."
    new "Vai dormir."

    # say L563 linGuide
    old "Go to sleep."
    new "Vai dormir."

    # say L565 belGuide
    old "Go to school in the morning."
    new "B:linGuide: Vai dormir."

    # say L566 barGuide
    old "Keep progressing with Brixxida."
    new "B:belGuide: Vai à escola de manhã."

    # say L568 bilGuide
    old "Keep progressing with other characters."
    new "B:barGuide: Continua a avançar com Brixxida."

    # say L584 mom2Rel
    old "step mom"
    new "Encontra-a no corredor."

    # say L700 sisGuide
    old "Meet her in the hallway."
    new "Encontra-a no corredor."

    # say L701 johGuide
    old "Keep progressing with Hinn."
    new "B:sisGuide: Encontra-te com ela no corredor."

    # say L703 lydGuide
    old "Go to her house."
    new "Vai à casa dela."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/ayeAnimations.rpy
translate portuguese strings:

    # say L6 aye
    old "My god this dick is so big!"
    new "Meu Deus, este pénis é tão grande!"

    # say L7 aye
    old "I noticed it the last time!"
    new "B:aye: Meu Deus, este pénis é tão grande!"

    # say L8 aye
    old "But having it in my mouth is just something else!"
    new "B: Aye: Reparei nisso da última vez!"

    # say L12 aye
    old "I bet you've never gotten head like this before right?"
    new "B:aye: Mas tê-lo na minha boca é algo completamente diferente!"

    # say L13 aye
    old "I know I'm so much better than my sister!"
    new "B:aye: Aposto que nunca sentiste uma boquete assim antes, certo?"

    # say L20 aye
    old "Slrrp! Mmm!"
    new "B: pla: Y- yeah, it is!"

    # say L21 aye
    old "Of course it is! I'm so much better than Olivia!"
    new "B:aye: Slrrp! Mmm!"

    # say L44 aye
    old "I- I can feel like you're about to finish!"
    new "B:aye: Claro que sim! Sou muito melhor do que a Olivia!"

    # say L45 pla
    old "Y- yeah! I am!"
    new "T: Y- yeah! Estou a chegar!"

    # say L46 aye
    old "Do it! I want to get your cum in my mouth!"
    new "B: pla: Y- yeah! Estou!"

    # say L53 aye
    old "Look at how much you came!"
    new "B:aye: Faz isso! Quero sentir o teu gozo na minha boca!"

    # say L54 aye
    old "You see? I told you I was way better than Olivia!"
    new "B:aye: Olha quanto tu veio!"

    # say L55 aye
    old "I bet you've never had anything like that before!"
    new "B:aye: Vês? Eu disse que era bem melhor do que a Olivia!"

    # say L56 pla
    old "Yeah, yeah..."
    new "T: Tu, tu... A: Levanta-te antes que a tua mãe ou a tua irmã venham aqui e nos vejam assim."

    # say L57 pla
    old "Listen, get up before your mother or your sister come here and see us like this."
    new "Ough, tu és tão pudico."

    # say L58 aye
    old "Ugh, you're such a prude."
    new "Tu és tão censurado."


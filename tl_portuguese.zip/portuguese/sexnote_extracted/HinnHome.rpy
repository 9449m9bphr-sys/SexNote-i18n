# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/HinnHome.rpy
translate portuguese strings:

    # say L20 pla
    old "I should find a therapist and talk with Mrs. Jade first."
    new "Devo falar com a Sra. Jade primeiro."

    # say L26 pla
    old "I should talk with Mrs. Jade first."
    new "T: Devo falar com a Sra. Jade primeiro."

    # say L32 pla
    old "I should talk with Dr. Johnson first."
    new "T(pla|tu|say): Devo falar com o Dr. Johnson primeiro."

    # say L91 pla
    old "Hey Hinn!"
    new "B:pla: Devo falar com o Dr. Johnson primeiro."

    # say L95 pla
    old "Great and you?"
    new "Estou bem. Quis-te perguntar se já mostraste o nosso progresso à Sra. Mia?"

    # say L97 hin
    old "I'm fine. I wanted to ask you if you've shown our progress to Mrs. Mia?"
    new "B:pla: Ótimo, e tu?"

    # say L99 pla
    old "Oh sorry. I haven't yet."
    new "B:hin: Estou bem. Queria perguntar-te se já mostraste o nosso progresso à Sra. Mia?"

    # say L101 hin
    old "Well, we should do it before continuing."
    new "B:pla: Oh, desculpa. Ainda não fiz."

    # say L103 pla
    old "Ok, doing it now."
    new "Bem, devemos fazer isso antes de continuar."

    # say L116 hin
    old "Oh... Listen... I'm so sorry. I shouldn't have got you into all this. It's my fault..."
    new "B:pla: Ei, Hinn... Queria falar sobre ontem."

    # say L118 pla
    old "No, no, I agreed to help, in fact I think it was... fun."
    new "B:hin: Oh... Escuta... Sinto muito. Não devia ter-te metido nisto tudo. É culpa minha..."

    # say L122 pla
    old "Yes, I liked helping. Also, I think your mom did everything with good intentions."
    new "B:pla: Não, não, concordei em ajudar, na verdade acho que foi... divertido."

    # say L124 hin
    old "Hmm... Maybe in her own way. But you're probably right."
    new "B:pla: Sim, gostei de ajudar. Além disso, acho que a tua mãe fez tudo com boas intenções."

    # say L126 pla
    old "I really think you look good with any clothes you decide to wear, the most important thing is that you feel good about yourself."
    new "T(pla|tu|say): Acho mesmo que ficas bem com qualquer roupa que escolhas usar, o mais importante é que te sintas bem contigo mesma."

    # say L134 hin
    old "Yes, lets do it."
    new "B:pla: Com prazer... Bem, devemos continuar com o projeto da aula?"

    # say L136 pla
    old "Great."
    new "B:hin: Sim, vamos fazer. T(pla|tu|say): Ótimo. A:pla: Uau Hinn, tu mudaste o outfit..."

    # say L154 pla
    old "Wow Hinn, you changed your outfit..."
    new "B:pla: Ótimo."

    # say L156 hin
    old "Well... I wanted to try something new... What do you think?"
    new "B:pla: Wow Hinn, mudaste o outfit..."

    # say L158 pla
    old "You look great."
    new "B:hin: Bem... Quis experimentar algo novo... O que achas?"

    # say L162 pla
    old "Yes, but the most important thing is how do you feel?"
    new "B:pla: Tu estás ótima."

    # say L165 hin
    old "Hmmm, I feel comfortable, the sessions with Dr. Johnson worked."
    new "B:pla: Sim, mas o mais importante é como tu te sentes?"

    # say L169 hin
    old "Actually, we have a new session today."
    new "B:hin: Hmmm, sinto-me confortável, as sessões com o Dr. Johnson resultaram."

    # say L171 pla
    old "Oh perfect, are you ready?"
    new "B:hin: Na verdade, temos uma nova sessão hoje."

    # say L173 hin
    old "Yes, let's go."
    new "B:pla: Ótimo, estás pronta?"

    # say L189 hin
    old "I'm fine, thanks."
    new "A:pla: Estava a pensar se já marcaste uma nova sessão com o Dr. Johnson."

    # say L191 pla
    old "I was wondering if you have a scheduled a new session with Dr. Johnson."
    new "T: Estava a pensar se já tinhas marcado uma nova sessão com o Dr. Johnson."

    # say L193 hin
    old "Yes, tomorrow morning don't worry."
    new "B:pla: Estava a pensar se já tinhas marcado uma nova sessão com o Dr. Johnson."

    # say L195 pla
    old "Oh great, see you tomorrow then."
    new "Espera..."

    # say L200 hin
    old "Wait..."
    new "Espera... Podíamos... Praticar de novo... Se quiseres."

    # say L202 hin
    old "We could... Practice again... If you want."
    new "B:hin: Espera..."

    # say L207 pla
    old "Sounds great."
    new "Soa bem."

    # say L209 hin
    old "Nice."
    new "A:pla: Isso soa ótimo, mas não posso agora."

    # say L216 pla
    old "That sounds great, but I can't right now."
    new "T: Isso soa ótimo, mas não posso agora."

    # say L218 hin
    old "Oh don't worry, see you tomorrow then."
    new "B:pla: Isso soa ótimo, mas não posso agora."

    # say L220 pla
    old "Great, see you."
    new "Ótimo, até amanhã."

    # say L227 hin
    old "Great!."
    new "A:pla: Estava a pensar se já marcaste uma nova sessão com o Dr. Johnson."

    # say L245 pla
    old "I was wondering if you you have a scheduled a new sesión with Dr. Johnson."
    new "T: Estava a pensar se tu já marcaste uma nova sessão com o Dr. Johnson."

    # say L251 hin
    old "See you."
    new "B:pla: Estava a pensar se tu tinhas marcado uma nova sessão com o Dr. Johnson."

    # say L296 pla
    old "No, no, sorry I was just walking around. I have to go."
    new "Não, não, desculpa, estava só a passear. Tenho de ir."

    # say L319 pla
    old "Yes, I'm ready. Let's get to it."
    new "Não"

    # menu L324 
    old "Not"
    new "B:pla: Sim, estou pronta. Vamos começar."

    # say L326 pla
    old "Actually, I come to tell you I can't work with you today."
    new "T(pla|tu|dizer): Na verdade, venho dizer-te que não posso trabalhar contigo hoje."

    # say L328 hin
    old "Oh, ok, don't worry we could work tomorrow on the class project."
    new "B:pla: Na verdade, venho dizer-te que não posso trabalhar contigo hoje."

    # say L330 pla
    old "Of course, tomorrow we will be working hard!"
    new "B:hin: Oh, ok, não te preocupes, podemos trabalhar amanhã no projeto da aula."

    # say L332 hin
    old "Hehehe great, see you."
    new "B:pla: Claro, amanhã vamos trabalhar bastante!"

    # say L334 pla
    old "See you Hinn."
    new "B:hin: Hehehe, ótimo, até já."

    # say L363 pla
    old "Damn, are we done? Really?"
    new "B:pla: Até logo, Hinn."

    # say L365 hin
    old "Yup... Looks like that's everything..."
    new "B:pla: Merda, já acabámos? A sério?"

    # say L367 pla
    old "Hinn? You look sad. You ok?"
    new "B:hin: Sim... Parece que é tudo..."

    # say L369 hin
    old "Yeah, I'm fine... I'm happy we finally finished this project..."
    new "B:pla: Hinn? Pareces triste. Estás bem?"

    # say L371 pla
    old "Really?..."
    new "B:hin: Sim, estou bem... Fico contente que finalmente tenhamos terminado este projeto..."

    # say L373 hin
    old "Yes, it's nothing. Don't worry. Just give the final project to Mrs. Mia tomorrow and let me know what she says. Ok?"
    new "B:pla: Mesmo?..."

    # say L375 pla
    old "Alright, Hinn. No problem."
    new "B:hin: Sim, não é nada. Não te preocupes. Só entrega o projeto final à Sra. Mia amanhã e avisa-me o que ela disse. Ok?"

    # say L396 pla
    old "Well, we made a lot of progress!"
    new "B:pla: Até amanhã, Hinn."

    # say L398 hin
    old "Yes, it's a little late. We should continue tomorrow."
    new "B:pla: Bem, fizemos muitos progressos!"

    # say L400 pla
    old "Ok, see you tomorrow, Hinn. Have a good night."
    new "B:hin: Sim, já é um pouco tarde. Devíamos continuar amanhã."

    # say L402 hin
    old "By the way, remember to show Mrs. Mia our progress, let her know how far we've come. See you tomorrow."
    new "Por acaso, lembra-te de mostrar à Sra. Mia os nossos progressos, para ela saber o quão longe chegámos. Até amanhã."


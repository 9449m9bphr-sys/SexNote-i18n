# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/LinStory.rpy
translate portuguese strings:

    # say L6 jon
    old "What was that?!"
    new "O que foi isso?!"

    # say L7 gra
    old "I have no idea... I'm as surprised as you're right now."
    new "B:jon: O que foi isso?!"

    # say L8 jon
    old "I've been here for many years and it's the first time I hear such strange noise."
    new "B:gra: Não tenho a mínima ideia... Estou tão surpreendido como tu."

    # say L15 jon
    old "God! Something strange is happening here... It's not normal for the lights to turn off and on by themselves all the time."
    new "B:jon: Estive aqui durante muitos anos e é a primeira vez que ouço um barulho tão estranho."

    # say L16 gra
    old "I know... But... What could it be?"
    new "B:jon: Meu Deus! Algo estranho está a acontecer aqui... Não é normal as luzes acenderem e apagarem por si próprias o tempo todo."

    # say L19 jon
    old "A ghost! An evil presence, what else could it be?!"
    new "B:gra: Eu sei... Mas... O que poderia ser?"

    # say L22 gra
    old "What!? Do you really think so?"
    new "B:jon: Um fantasma! Uma presença maligna, o que mais poderia ser?!"

    # say L23 jon
    old "Of course! I'm not joking... So why do you think this youth is so rotten and lost? It's the devil's work!"
    new "B:gra: Que!? Tu realmente pensas isso?"

    # say L24 gra
    old "Yes Mrs. Jones, you're right, must be that. I don't think it's an electricity issue."
    new "B:jon: Claro! Não estou a brincar... Então porque é que pensas que esta juventude está tão corrompida e perdida? É obra do diabo!"

    # say L26 gra
    old "We gotta do something! Fuck... Jesus Christ!"
    new "B:gra: Sim, Sra. Jones, tens razão, deve ser isso. Não acho que seja um problema de eletricidade."

    # say L28 jon
    old "Sister Grace! Watch your mouth, please!"
    new "B:gra: Temos que fazer algo! Merda... Jesus Cristo!"

    # say L30 gra
    old "Sorry Mrs. Jones, but this situation gets on my nerves, it's a ghost or a devil. We must perform an exorcism!."
    new "B:jon: Irmã Grace! Cuide com o que diz!"

    # say L31 jon
    old "We need the pries-"
    new "B:gra: Desculpe, Sra. Jones, mas esta situação me está a irritar, é um fantasma ou um demónio. Temos de realizar um exorcismo!"

    # say L32 pla
    old "(I should use the Agamoto's eye and check if I can see something...)"
    new "B:jon: Precisamos do sacerdote..."

    # say L39 pla
    old "(Oh no! It's not a ghost... It's a shinigami!)"
    new "B:pla: (Devo usar o olho do Agamoto e ver se consigo ver algo...)"

    # say L40 pla
    old "(But... What happened to her!? Seems she is trapped or...)"
    new "B: (Oh não! Não é um fantasma... É uma shinigami!)"

    # say L41 pla
    old "(She looks like she's in pain... And why does she fly like that??!)"
    new "B:pla: (Mas... O que aconteceu com ela!? Parece que está presa ou...)"

    # say L42 pla
    old "(I gotta talk to this shinigami... This has something to do with the magic...)"
    new "B: (Ela parece estar com dor... E por que ela voa assim??!)"

    # say L45 pla
    old "Hello, Oh! Sorry... I didn't want to interrupt..."
    new "B:pla: (Tenho de falar com este shinigami... Isto tem a ver com a magia...)"

    # say L52 pla
    old "Hi, nice to meet you."
    new "B:jon: Deixa-me apresentar-te a nossa Irmã Grace, ela é a freira da igreja."

    # say L55 jon
    old "Hun, something terrible is happening here... We might have the presence of a ghost in the church! Can you believe it?"
    new "B:pla: Estava só a passar para dizer olá..."

    # say L56 gra
    old "Or a devil... Gosh darn I-!"
    new "B:jon: Hun, algo terrível está a acontecer aqui... Podemos ter a presença de um fantasma na igreja! Tu acreditas?"

    # say L58 jon
    old "Sister Grace, please!"
    new "B:gra: Ou um demónio... Ai, droga, eu-!"

    # say L60 pla
    old "Wait! Why do you think is a ghost?"
    new "B:jon: Irmã Grace, por favor!"

    # say L62 jon
    old "There are strange noises, the lights turn off and on by themselves... And I'm a very spiritual person, if I'm telling you this is because it is what it is..."
    new "B:pla: Espera! Porque é que achas que é um fantasma?"

    # say L63 pla
    old "I- I believe you... But what are you gonna do?"
    new "B:jon: Há barulhos estranhos, as luzes acendem e apagam sozinhas... E eu sou uma pessoa muito espiritual, se estou te contando isso é porque é o que é..."

    # say L64 gra
    old "An exorcism!"
    new "B:pla: I- Acredito em ti... Mas o que vais fazer?"

    # say L66 pla
    old "An exorcism?"
    new "T: Um exorcismo?"

    # say L67 pla
    old "(I have to talk to the girls... They should know what's happening.)"
    new "B:pla: Um exorcismo?"

    # say L68 jon
    old "Hun, we don't want to scare you..."
    new "B:pla: (Tenho que falar com as raparigas... Elas devem saber o que está a acontecer.)"

    # say L69 pla
    old "No, I'm not... I gotta go now, I- I have some... Homework to do but I will pass by to see what happens."
    new "B:jon: Meu amor, não queremos assustar-te..."

    # say L70 pla
    old "Perhaps I could help out... Dunno... It's very strange what's happening here."
    new "B:pla: Não, eu não... Tenho que ir agora, eu- eu tenho alguns... Trabalhos de casa para fazer, mas vou passar por lá para ver o que acontece."

    # say L71 jon
    old "Alright, please take care of yourself."
    new "B:pla: Talvez eu possa ajudar... Não sei... É muito estranho o que está a acontecer aqui."

    # say L73 pla
    old "You too Mrs. Jones... Goodbye..."
    new "B:jon: Tudo bem, toma lá conta de ti."

    # say L95 pla
    old "(Alright, I'm here... Fortunately there is no one here, I should use the Agamoto's eye and talk with them before someone comes.)"
    new "B:pla: (O que está a acontecer aqui, isto é estranho, tenho de falar com os shinigamis.)"

    # say L112 pla
    old "Hey girls, I gotta tell you something!"
    new "B:pla: (Estou aqui... Afortunadamente não há ninguém, devo usar o olho de Agamoto e falar com elas antes que alguém venha.)"

    # say L128 mil
    old "Well, hello... We're actually fine and you?"
    new "B:pla: Ei raparigas, tenho de vos dizer uma coisa!"

    # say L129 pla
    old "Opss! Sorry... Hi hi..."
    new "B:mil: Olá... Estamos bem e tu?"

    # say L130 pla
    old "This is something important... I found a new Shinigami at the church..."
    new "B: pla: Ops! Desculpa... Hi hi..."

    # say L131 pla
    old "I don't know what's happening but she's not fine for sure, she was flying around, looking drowsy..."
    new "B:pla: Isto é algo importante... Encontrei um novo shinigami na igreja..."

    # say L132 gom
    old "A new shinigami? And what do you mean by drowsy?"
    new "B:pla: Não sei o que está a acontecer, mas ela com certeza não está bem, estava a voar por aí, parecendo sonolenta..."

    # say L133 pla
    old "Hmm, like very weak... Dunno! Do you guys have any idea of what's happening there?"
    new "B:gom: Um novo shinigami? E o que queres dizer com sonolento?"

    # say L135 mil
    old "What? What was she doing in there?"
    new "B:pla: Hmm, muito fraco... Não sei! Vocês têm alguma ideia do que está a acontecer lá?"

    # say L136 pla
    old "Well, she was flying but it seemed she was stuck in there..."
    new "B:mil: O quê? O que é que ela estava a fazer lá dentro?"

    # say L138 mil
    old "Hmm, alright... I may know what's happening."
    new "B:pla: Bem, ela estava voando, mas parecia que ficou presa lá..."

    # say L139 mil
    old "If what you said is happening, it might be that the shinigami is in trouble with her energy."
    new "B:mil: Hmm, bem... Posso saber o que está a acontecer."

    # say L140 mil
    old "I mean, there is no much energy around and she must be stuck in there. When there is not enough energy, we suffer the consequences."
    new "B:mil: Se o que tu disseste está a acontecer, pode ser que a shinigami esteja com problemas com a sua energia."

    # say L141 mil
    old "Most likely she has just a couple of..."
    new "T(mil|tu|say): Provavelmente ela só tem um par de..."

    # say L143 pla
    old "A couple of? Of what?"
    new "A: mil: Uns dias de vida..."

    # say L144 mil
    old "A couple of days left..."
    new "B: pla: Um par de? De quê?"

    # say L145 gom
    old "This is so sad... We all will die..."
    new "B:mil: Faltam alguns dias..."

    # say L146 dev
    old "All this is bullshit..."
    new "B: gom: Isto é tão triste... Todos nós vamos morrer..."

    # say L151 pla
    old "There has to be a way, just tell me what to do and I'll do it, we can't let her die."
    new "B:gom: Mas... Mas como? Não há mais poder mágico ao nosso redor... Diz-me como!"

    # say L156 pla
    old " It's better if I go now... See you!"
    new "B:pla: Claro, eu... Sinto muito que tudo isto esteja a acontecer, mas não te preocupes, vou ajudar..."

    # say L159 dev
    old "Good luck... And see you."
    new "B:pla: É melhor eu ir agora... Até logo!"

    # say L161 pla
    old "I know... I'll do my best!"
    new "A:mor: Tudo bem, vamos começar o exorcismo."

    # say L181 mor
    old "Alright, we are going to start the exorcism."
    new "B:pla: Eu sei... Vou fazer o meu melhor!"

    # say L188 mor
    old "Lord, please protect our church, protect us from these evil presences that surround us."
    new "B:mor: Vamos começar o exorcismo."

    # say L191 jon
    old "Amen."
    new "B:mor: Senhor, protege a nossa igreja, protege-nos destas presenças malignas que nos rodeiam."

    # say L194 mor
    old "Our Father, who art in Heaven, hallowed be Thy name, Thy kingdom come..."
    new "A:mor: A Tua vontade seja feita, na terra como no céu. Dá-nos hoje o nosso pão de cada dia, e perdoa-nos os nossos pecados, como também nós perdoamos..."

    # say L195 mor
    old "Thy will be done, on earth as it is in Heaven. Give us this day our daily bread, and forgive us ou-"
    new "B:mor: Pai nosso que estás no Céu, santificado seja o Teu nome, venha a nós o Teu reino..."

    # say L197 pla
    old "(There she is... Is the shinigami... She'll die if I don't do something!)"
    new "B:mor: Seja feita a Tua vontade, na terra como no céu. Dá-nos hoje o nosso pão de cada dia, e perdoa-nos as nossas ofensas..."

    # say L198 pla
    old "Huh,  w- what's happening? "
    new "B:pla: (Aí está... É a shinigami... Ela vai morrer se eu não fizer nada!)"

    # say L204 gra
    old "Hi [pla], Mrs. Jones is right, the situation is getting worse."
    new "B:jon: [pla]! Olá querida, a presença... a presença do demónio... está a tomar conta da igreja."

    # say L208 gra
    old "Because it is! What else could it be if not a demon, a ghost!?"
    new "B:pla: O quê? Porque é que achas que é um demónio?"

    # say L209 jon
    old "It is hun... We know that, just look at the lights, everything is a mess here because of that."
    new "B:gra: Porque é isso! O que mais poderia ser se não um demónio, um fantasma!?"

    # say L210 pla
    old "(If I don't do something quickly, she will probably die.)"
    new "B:jon: É hun... Sabemos disso, basta olhar para as luzes, tudo está uma confusão aqui por causa disso."

    # say L211 pla
    old "Ehmm... I'm sorry to contradict you but the presence we have right now in this church is not malignant at all, I'm sure of that."
    new "B: pla: (Se eu não fizer algo rapidamente, ela provavelmente morrerá.)"

    # say L212 gra
    old "What? What are you saying? If you're so sure, prove it!"
    new "B:pla: Hmm... Peço desculpa por contradizer-te, mas a presença que temos aqui na igreja neste momento não é maligna de todo, tenho a certeza disso."

    # say L213 pla
    old "W- Well... I can do it! Take a look at the lights."
    new "B:gra: O quê? O que estás a dizer? Se estás tão certo, prova!"

    # say L214 pla
    old "I'll tell the spirit to move to the right and the lights on that side will start to fade, if this happens you'll see that this spirit has good intentions."
    new "B:pla: B-Bem... Eu consigo! Olha para as luzes."

    # say L215 gra
    old "Hmm, let's see."
    new "B:pla: Vou pedir ao espírito para se mover para a direita e as luzes desse lado vão começar a desvanecer, se isso acontecer, vais ver que este espírito tem boas intenções."

    # say L217 pla
    old "Spirit! Listen to me... We know we can help you as you can help us as well, please move to the right side and let us know by using the lights..."
    new "Espírito! Ouve-me... Sabemos que podemos ajudar-te e tu também podes ajudar-nos, por favor, move-te para o lado direito e avisa-nos usando as luzes... Meu Deus! Ele conseguiu! As luzes estavam a desvanecer..."

    # say L224 gra
    old "My God! He did it! The lights were fading..."
    new "B: Spirit! Escuta-me... Sabemos que podemos ajudar-te e tu também podes ajudar-nos, por favor, move-te para o lado direito e avisa-nos usando as luzes..."

    # say L225 pla
    old "Spirit! Thanks! We saw it, you may now come back to your place."
    new "B:gra: Meu Deus! Ele conseguiu! As luzes estavam a desvanecer-se..."

    # say L233 jon
    old "I'm surprised..."
    new "B:pla: Eu simplesmente sabia, posso sentir a energia da criatura e sei que é boa... Não há nada de mau nela."

    # say L234 mor
    old "Son, we see you're right, this spirit actually listens to you and does accordingly but what does it want? What can we do?"
    new "B:jon: Estou surpreendido..."

    # say L235 pla
    old "Well, I thin-"
    new "B:mor: Filho, vemos que tens razão, este espírito obedece-te de facto, mas o que é que ele quer? O que podemos fazer?"

    # say L246 bil
    old "What's the fuss about? Granma what's happening here?"
    new "B:pla: Bem, eu acho-"

    # say L251 jon
    old "Hi darling! It's a ghost-"
    new "B:bil: Que confusão é esta? Avó, o que se passa aqui?"

    # say L252 bil
    old "Oh really! Shut up, please! You're talking nonsense."
    new "B:jon: Olá querida! É um fantasma..."

    # say L253 gra
    old "It's true! There is an evil presence here..."
    new "B:bil: Oh, realmente! Cala-te, por favor! Estás a falar asneiras."

    # say L255 bil
    old "Sister Grace I wasn't talking to you, please don't be rude... I can't deal with nosy people."
    new "B:gra: É verdade! Há uma presença maligna aqui..."

    # say L283 jon
    old "What's happening Billie? BILLIE!?"
    new "B:bil: Irmã Grace, não estava a falar contigo, por favor não sejas mal-educada... Não consigo lidar com pessoas intrometidas."

    # say L291 jon
    old "Nooo! Billie, wake up!! What's happening!? Someone help me, please!"
    new "B:jon: O que está a acontecer, Billie? BILLIE!?"

    # say L292 gra
    old "Oh God, please help us."
    new "B:jon: Não! Billie, acorda!! O que está a acontecer!? Alguém me ajuda, por favor!"

    # say L293 mor
    old "Calm down everybody...!"
    new "B:gra: Oh Deus, por favor, ajuda-nos."

    # say L295 mor
    old "I believe in God, the Father Almighty, Creator of Heaven and earth; and in Jesus Christ, His only Son, Our Lord..."
    new "B:mor: Calma, todos...!"

    # say L298 gra
    old "Father Morgan?"
    new "B:mor: Eu acredito em Deus, o Pai Todo-Poderoso, Criador do Céu e da terra; e em Jesus Cristo, Seu único Filho, Nosso Senhor..."

    # say L299 mor
    old "It's important to keep praying for Billie."
    new "B:gra: Padre Morgan?"

    # say L300 mor
    old "Let's pra-"
    new "B:mor: É importante continuar a rezar por Billie."

    # say L301 gra
    old "Noo! Father Morgan, take her to the hospital with Mrs. Jones, I'll take care of the church..."
    new "B:mor: Vamos pra-"

    # say L303 jon
    old "Yes, let's go now... She has to be checked by a doctor."
    new "B:gra: Não! Padre Morgan, leva-a ao hospital com a Sra. Jones, eu cuido da igreja..."

    # say L309 mor
    old "Sister Grace, please take care of the church, call me if anything... Ok?"
    new "B:jon: Sim, vamos agora... Ela tem que ser examinada por um médico."

    # say L322 pla
    old "Wow that was... Weird..."
    new "B:mor: Irmã Grace, por favor, cuide da igreja, chama-me se acontecer algo... Ok?"

    # say L323 gra
    old "I hope Mrs. Jones's granddaughter is fine."
    new "B:pla: Uau, isso foi... Estranho..."

    # say L324 pla
    old "Yeah, me too."
    new "Espera aí, as luzes não estão a piscar! O fantasma desapareceu!"

    # say L325 gra
    old "Wait a minute, the lights are not flashing! The ghost is gone!"
    new "B:pla: Sim, eu também."

    # say L326 pla
    old "W- what? (Oh shit, what happened with the shinigami?)"
    new "B:gra: Espera aí, as luzes não estão a piscar! O fantasma desapareceu!"

    # say L327 pla
    old "You are right... I can't see anything either"
    new "B:pla: O- o quê? (Oh merda, o que aconteceu com a shinigami?)"

    # say L328 pla
    old "(Oh no... It means she... d- died.)"
    new "B:pla: Tens razão... Eu também não consigo ver nada."

    # say L329 gra
    old "And it was because of you! Thank you for your help."
    new "B:pla: (Oh não... Isso significa que ela... m-morreu.)"

    # say L330 pla
    old "Yeah... It was because of me... (It was my fault...)"
    new "B:gra: E foi por tua causa! Obrigado pela ajuda."

    # say L331 gra
    old "I'm really impressed, don't know which kind of spiritual connection you have."
    new "B:pla: Sim... Foi por minha causa... (Foi culpa minha...)"

    # say L332 gra
    old "It was as if you were communicating with something higher... Something that we cannot see, something beyond our comprehension, perhaps divine."
    new "B:gra: Estou realmente impressionado, não sei que tipo de conexão espiritual tu tens."

    # say L333 pla
    old "Hmm yeah... Something like that"
    new "B:gra: Era como se estivesses a comunicar com algo superior... Algo que não conseguimos ver, algo além da nossa compreensão, talvez divino."

    # say L334 pla
    old "(Argh! I didn't save her... I'm completely useless...) "
    new "B:pla: Hmm yeah... Algo assim..."

    # say L335 gra
    old "You're definitely closer to the divine spirit than even Father Morgan..."
    new "B: (Argh! Não a salvei... Sou completamente inútil...)"

    # say L336 pla
    old "I better go home, goodbye Sister Grace."
    new "B:gra: Tu estás definitivamente mais perto do espírito divino do que mesmo o Padre Morgan..."

    # say L365 pla
    old "Looking for me?... Who's that?"
    new "B:mo1: Bom dia querida, alguém está à tua procura..."

    # say L366 mo1
    old "Two women... An old lady and a nun, where do you know them from?"
    new "B:pla: À procura de mim?... Quem é?"

    # say L367 pla
    old "Ahh ok! Hmm... They're from the church, you know I have been there quite a few times..."
    new "B:mo1: Duas mulheres... Uma senhora idosa e uma freira, de onde tu as conheces?"

    # say L368 mo1
    old "I see... Well, they're waiting, go to see what they need, honey."
    new "B:pla: Ahh ok! Hmm... São da igreja, sabes que tenho ido lá algumas vezes..."

    # say L377 pla
    old "Hi Mrs. Jones... Hmm, me? Why? What happened?"
    new "B:jon: Olá querida, sinto muito incomodar-te mas tu és a única que pode nos ajudar..."

    # say L378 gra
    old "Hi [pla], well... As I told you in the church, you were a great help and we think you could do something for Billie."
    new "B:pla: Olá [pla]... Hmm, eu? Porquê? O que aconteceu?"

    # say L382 pla
    old "I'm so sorry to hear she's not ok... But I don't know how could I help... I'm not a doctor."
    new "B:jon: Estou tão preocupado com a minha neta, tenho medo de a perder... Por favor, ajuda-me!"

    # say L383 gra
    old "Well, we think this case is more related on a spiritual level, and you showed divine talents, so we hope that you could help us."
    new "B:pla: Sinto muito ouvir que ela não está bem... Mas não sei como poderia ajudar... Não sou médico."

    # say L384 pla
    old "And what about the Father Morgan?"
    new "B:gra: Bem, pensamos que este caso está mais relacionado num nível espiritual, e tu mostraste talentos divinos, por isso esperamos que possas ajudar-nos."

    # say L385 jon
    old "He already tried but didn't work and well... You're our only hope."
    new "B:pla: E o Padre Morgan?"

    # say L386 pla
    old "Alright, I'll try to help, but I'm not sure if I can-"
    new "B:jon: Ele já tentou, mas não funcionou e bem... Tu és a nossa única esperança."

    # say L387 gra
    old "Thank you! We knew we can count on you."
    new "B:pla: Tudo bem, vou tentar ajudar, mas não tenho a certeza se consigo..."

    # say L388 jon
    old "Come with us, we have no time to lose. "
    new "B:gra: Obrigado! Sabíamos que podíamos contar contigo."

    # say L407 pla
    old "(What? The shinigami isn't dead? What's happening here!)"
    new "B: pla: Hmm vamos ver..."

    # say L410 jon
    old "Oh my God! She is crying black tears..."
    new "B:pla: (O quê? O shinigami não está morto? O que está a acontecer aqui!)"

    # say L417 pla
    old "Hmm... W- Well..."
    new "B:pla: (Não percebo o que está a acontecer aqui. Tenho de falar com os shinigamis.)"

    # say L418 pla
    old "Hmm... I'll need to see her at night, right now I can't do anything but I'll come back later."
    new "B:pla: Hmm... W- Well..."

    # say L419 pla
    old "I need to... Prepare myself, if we do everything in the proper way, Billie will be fine soon."
    new "B:pla: Hmm... Preciso vê-la à noite, agora não posso fazer nada mas voltarei mais tarde."

    # say L422 pla
    old "Don't worry Mrs. Jones, she'll be fine. I better go now but I'll see you later."
    new "B:pla: (Meu Deus! Preciso mesmo fazer algo por ela e pelo shinigami.)"

    # say L423 pla
    old "See you later as well Sister Grace."
    new "B:pla: Não te preocupes, Sra. Jones, ela vai ficar bem. Tenho de ir agora, mas vejo-te mais tarde."

    # say L425 gra
    old "Thanks! We'll be waiting for you."
    new "B:pla: Até mais, Irmã Grace."

    # say L426 jon
    old "Take care hun and thanks again."
    new "A:pla: Vi a shinigami! Aparentemente ela está dentro do corpo da Billie. Vi-a!"

    # say L449 pla
    old "I saw the shinigami! Apparently she's inside Billie's body. I saw her!"
    new "B:jon: Cuida-te querida e obrigado mais uma vez."

    # say L467 mil
    old "I'm surprised with your manners... Hi [pla]!"
    new "T(mil|tu|say): Estou surpreendido com as tuas maneiras... Olá [pla]!"

    # say L469 mil
    old "Wait a sec! Who's Billie? What are you talking about?"
    new "B:pla: Hi hi! Eu sei, mas isto é importante, não esperava vê-la lá..."

    # say L470 pla
    old "Alright! Billie is a girl from the church and it seems the shinigami is inside of her, I have no idea how,.. You tell me!"
    new "B:mil: Espera aí! Quem é Billie? Do que estás a falar?"

    # say L476 gom
    old "She's struggling right now and the only way to get out of Billie's body is through an energy transfer since the body where she's now doesn't have any energy."
    new "B:mil: Essa shinigami está com problemas sérios e entrar no corpo de um humano foi a única opção que ela tinha..."

    # say L477 pla
    old "What? I thought she did possess her body... This makes more sense, that's why she's still there."
    new "B:gom: Ela está a lutar neste momento e a única forma de sair do corpo da Billie é através de uma transferência de energia, já que o corpo onde ela está agora não tem energia."

    # say L478 mil
    old "Yes, she can't get out by herself. Billie's body doesn't have enough energy and as I'm telling you.. The only way to help them is through a powerful load of energy."
    new "B: pla: O quê? Eu pensei que ela tivesse o controlo do seu corpo... Isto faz mais sentido, por isso ela ainda está lá."

    # say L479 gom
    old "Are you willing to do that for them?"
    new "B:mil: Sim, ela não consegue sair sozinha. O corpo da Billie não tem energia suficiente e, como estou a dizer-te... A única forma de os ajudar é através de uma carga poderosa de energia."

    # say L481 pla
    old "Yes, of course... I don't want anybody to die. How can I perform that energy transfer?"
    new "B:gom: Estás disposto a fazer isso por eles?"

    # say L483 dev
    old "Come on! You already know how..."
    new "B:pla: Sim, claro... Não quero que ninguém morra. Como posso fazer essa transferência de energia?"

    # say L484 pla
    old "Well, the only way to get energy I know is through s- sex-... A- are you saying that I have to have sex with Billie?"
    new "B:dev: Vamos! Tu já sabes como..."

    # say L485 mil
    old "You just said it... Yeah, it's the only way. Once the shinigami gets your energy, she'll be able to get out of Billie's body. There is no other way."
    new "B:pla: Bem, a única forma de obter energia que conheço é através de s- sexo... A- estás a dizer que tenho de ter relações com a Billie?"

    # say L486 mil
    old "You're a young, strong and virile man. You're the only one able to help her."
    new "B:mil: Tu acabaste de dizer... Sim, é a única maneira. Assim que a shinigami tiver a tua energia, ela conseguirá sair do corpo da Billie. Não há outra forma."

    # say L487 pla
    old "I get it, I'll do whatever it takes to help her."
    new "B:mil: Tu és um jovem, forte e viril. Tu és o único capaz de a ajudar."

    # say L488 mil
    old "Get ready for it! You'll have to last much longer since it will not be easy but we know you can do it."
    new "B:pla: Entendi, vou fazer o que for preciso para ajudá-la."

    # say L490 pla
    old "I'll do my best for her to come and come out... See you girls."
    new "B:mil: Prepara-te! Vais ter de aguentar muito mais tempo, pois não vai ser fácil, mas sabemos que consegues."

    # say L494 gom
    old "Please take care, [pla]"
    new "B:mil: Até [pla], estamos a contar contigo."

    # say L515 jon
    old "Hi dear, we're so glad you're here... Let's start now. Tell us how to help you."
    new "B:pla: Olá Sra. Jones, Irmã Grace..."

    # say L518 pla
    old "(They can't be here... I gotta say something for them to go out...)"
    new "B:jon: Confiamos em ti e nos dons que o Senhor te deu, por favor, ajuda a minha Billie."

    # say L519 jon
    old "Tell us! Tell us hun!"
    new "B:pla: (Eles não podem estar aqui... Tenho que dizer alguma coisa para eles saírem...)"

    # say L523 jon
    old "Are you ok? What's happening? Why don't we start now?"
    new "B:jon: Conta-nos! Conta-nos querida!"

    # say L524 pla
    old "Yes, n- no. I- I mean, I'll start now but you can't be here, this is an important ritual that I must do alone."
    new "B:jon: Estás bem? O que se passa? Porque não começamos agora?"

    # say L525 gra
    old "Alone? Why? We could assist you with our presence and prayers."
    new "B:pla: Sim, n- não. Quero dizer, vou começar agora, mas tu não podes estar aqui, é um ritual importante que tenho de fazer sozinho."

    # say L526 pla
    old "Hmm... Because, it's how it should be, could be dangerous for you."
    new "B:gra: Sozinho? Porquê? Podíamos ajudar-te com a nossa presença e orações."

    # say L527 pla
    old "I don't think you're prepared to see what I'll do..."
    new "B:pla: Hmm... Porque, é assim que deve ser, poderia ser perigoso para ti."

    # say L528 pla
    old "Billie? Billie, do you hear me?"
    new "B:pla: Não acho que estejas preparado para ver o que vou fazer..."

    # say L530 lin
    old "Gulp... is tha-?"
    new "B:pla: Billie? Billie, ouves-me?"

    # say L531 jon
    old "My Godness! Billie spoke! Let's get out of here. He knows what he's doing."
    new "B:lin: Engasga... é isso-?"

    # say L532 pla
    old "Please leave me alone with her, we can't waste more time."
    new "B:jon: Meu Deus! A Billie falou! Vamos sair daqui. Ele sabe o que está a fazer."

    # say L533 lin
    old "I- I n- need h- help."
    new "B:pla: Deixa-me ficar a sós com ela, não podemos perder mais tempo."

    # say L548 pla
    old "Alright, how I'm gonna do this?"
    new "Bem, como vou fazer isto?"

    # say L549 pla
    old "Shinigami? Billie?"
    new "B:pla: Tudo bem, como é que vou fazer isto?"

    # say L551 lin
    old "Y- You're here! P- please help me to get out of her, I- I'm trapped."
    new "B:pla: Shinigami? Billie?"

    # say L552 pla
    old "I know... You know the only way is through an energy transfer process, right?"
    new "B:lin: T-Tu estás aqui! P-Por favor, ajuda-me a sair daqui, e-Estou preso."

    # say L553 lin
    old "Y- Yes, please hurry up! I- I'll die if we don't do it."
    new "B:pla: Eu sei... Tu sabes que a única maneira é através de um processo de transferência de energia, certo?"

    # say L554 pla
    old "We'll need to have s- sex, well... You know it's how it's called."
    new "B:lin: S- Sim, por favor, apressa-te! V- Vou morrer se não o fizermos."

    # say L556 lin
    old "Shoot! C- Can you simply do it!? I already know what you're saying. I need you to do it now!"
    new "B:pla: Vamos ter de ter s- sexo, bem... Sabes como é que se chama."

    # say L557 pla
    old "No! No, I was just saying..."
    new "B:lin: C- Podes simplesmente fazê-lo!? Eu já sei o que estás a dizer. Preciso que o faças agora!"

    # say L558 pla
    old "But I shouldn't have sex with this girl, I don't even know her."
    new "B: Não! Não, eu só estava dizendo..."

    # say L564 lin
    old "W- what you are going to do is share a magical power with me the shinigami... Don't overthink it. "
    new "B:pla: Mas não devo ter relações com esta rapariga, nem sequer a conheço."

    # say L565 lin
    old "I need you to free me now... Do it..."
    new "B:lin: W- o que vais fazer é partilhar um poder mágico comigo, o shinigami... Não te preocupes muito com isso."

    # say L597 pla
    old "(Oh no! Now what?!)"
    new "B:jon: Meu Deus! O que está a acontecer aqui? O que fizeste a Billie?"

    # say L605 bil
    old "Grandma? Sister Grace? Where am I?... What happened?"
    new "B:pla: (Maldição! O que devo dizer?)"

    # say L606 bil
    old "Someone tell me what happened to me? Why am I naked and sweating?"
    new "B:bil: Avó? Irmã Grace? Onde estou?... O que aconteceu?"

    # say L607 gra
    old "Well! She looks much better now..."
    new "B:bil: Alguém me diz o que aconteceu? Porque estou nu e a suar?"

    # say L610 jon
    old "My God, thanks! She's back!"
    new "B:gra: Bem! Ela está muito melhor agora..."

    # say L611 bil
    old "Huhh, what is going on?"
    new "A:gra: Sabemos que deves estar muito confuso com tudo..."

    # say L612 gra
    old "We know you must be feeling so confused about everything..."
    new "B:bil: Huhh, o que se está a passar?"

    # say L615 gra
    old "Yes, it happened while we all were at the church, we don't know why but what matters now is that you're fine."
    new "B:bil: Que? O meu corpo... Possuído? Que merda?"

    # say L620 pla
    old "It was part of the ritual... It was the only way to help her out."
    new "T: Era parte do ritual... Era a única maneira de a ajudar."

    # say L621 gra
    old "She seems to be totally fine now, I don't feel the spirit's presence anymore."
    new "B:pla: Fazia parte do ritual... Era a única maneira de a ajudar."

    # say L622 pla
    old "She's fine now, I've cleaned her body from the spirit's presence... Now she's fine and healthy."
    new "T(pla|tu|say): Ela está bem agora, limpei o seu corpo da presença do espírito... Agora ela está bem e saudável."

    # say L624 jon
    old "Don't worry my love, you're fine now. You just need to rest..."
    new "B:pla: Ela está bem agora, limpei o seu corpo da presença do espírito... Agora ela está bem e saudável."

    # say L627 bil
    old "Huhh could you please let me go? I'm not breathing..."
    new "B:jon: Não te preocupes, meu amor, estás bem agora. Só precisas de descansar..."

    # say L633 gra
    old "Ohh, sorry... It's just that we're so happy you're fine..."
    new "B:bil: Huhh, podias deixar-me ir? Não estou a respirar..."

    # say L638 pla
    old "Don't worry, I just did what... God told me to do... I'll be here to help."
    new "B:jon: Sim, obrigado meu amor, estou tão grato contigo, és um santo. Com certeza Deus está dentro de ti..."

    # say L639 pla
    old "I should be going now... It's been a very demanding ritual and I need to get some rest."
    new "B:pla: Não te preocupes, eu apenas fiz o que... Deus me disse para fazer... Estarei aqui para ajudar."

    # say L641 jon
    old "Sure hun! Take care and thanks again!"
    new "B:pla: Devo ir agora... Foi um ritual muito exigente e preciso descansar."

    # say L642 pla
    old "Mmm... Thanks, see you Mrs. Jones... Bye Sister Grace."
    new "T(pla|tu|say): Mmm... Obrigado, até à vista Mrs. Jones... Adeus Irmã Grace."

    # say L672 pla
    old "How are you feeling? Are you ok?"
    new "B:bil: O que é que aquele homem nu estava a fazer aqui?"

    # say L674 pla
    old "You know what... There are more shinigamis like you, we can help you."
    new "B:pla: Como estás a sentir-te? Estás bem?"

    # say L675 lin
    old "Who are you? Why are you helping me?"
    new "B:pla: Sabes... Existem mais shinigamis como tu, podemos ajudar-te."

    # say L677 lin
    old "I see... Nice to meet you [pla], I'm Linett and well..."
    new "B:pla: Oh sim, desculpa! Eu sou [pla], como acabei de te dizer... Conheço outros como tu."

    # say L680 pla
    old "Do you think we should continue with the energy transfer?"
    new "T(pla|tu|say): Tu achas que devemos continuar com a transferência de energia?"

    # say L682 lin
    old "Hmm, we definitely have to continue the energy transfer, everything you shared with me was just to get out of that girl's body."
    new "B:pla: Tu achas que devemos continuar com a transferência de energia?"

    # say L683 pla
    old "Hmm ok, no problem, let's do it."
    new "B:lin: Hmm, temos de continuar a transferência de energia, tudo o que partilhaste comigo foi só para sair do corpo dessa rapariga."

    # say L684 lin
    old "Great! It's better if I suck you cock first, that will give me initial energy so that later you continue with the whole transfer."
    new "Estás bem com isso?"

    # say L685 lin
    old "Are you fine with that?"
    new "B:lin: Ótimo! É melhor eu chupar o teu pénis primeiro, isso vai dar-me energia inicial para que depois tu continues com a transferência toda."

    # say L686 pla
    old "Yeah, I already told you I'm here to help and if I have to do that... I won't let you down."
    new "T(pla|tu|say): Sim, já te disse que estou aqui para ajudar e se tiver de fazer isso... não te vou desiludir."

    # say L690 lin
    old "That's the attitude we need... One more thing, could you please turn on the lights, I prefer to watch what I'm doing..."
    new "B:pla: Sim, já te disse que estou aqui para ajudar e se tiver de o fazer... não te vou desiludir."

    # say L691 pla
    old "Ehmm... Sure."
    new "B:lin: É essa a atitude que precisamos... Mais uma coisa, podias ligar as luzes? Prefiro ver o que estou a fazer..."

    # say L704 pla
    old "So how are you now?"
    new "B:pla: Hmm... Claro. T(pla|tu|say): E então, como estás agora? A:lin: Totalmente bem... Tu realmente foste excelente!"

    # say L705 lin
    old "Totally fine... You really did excellent!"
    new "B:pla: Então, como estás agora?"

    # say L706 pla
    old "I'm glad you're fine now but... Are you gonna tell me what were you doing at the church? What was happening there?"
    new "T: Fico contente que estejas bem agora, mas... Vais contar-me o que estavas a fazer na igreja? O que se passava lá?"

    # say L707 lin
    old "Yes, sure! Well... Hmm."
    new "T(lin|tu|say): Sim, claro! Bem... Hmm."

    # say L708 lin
    old "I was trying to do a small ritual to achieve a reception of energy, for this it was required to deliver a lot of energy and I thought that with me it would have been enough, but it wasn't."
    new "T(lin|tu|dizer): Estava a tentar fazer um pequeno ritual para receber energia, para isso era necessário entregar muita energia e pensei que comigo seria suficiente, mas não foi."

    # say L710 lin
    old "I tried to condense the magic power but since I didn't have enough energy, I got weak and got trapped in the church and later, in Billie's body."
    new "B:lin: Estava a tentar fazer um pequeno ritual para receber energia, para isso era necessário entregar muita energia e pensei que comigo seria suficiente, mas não foi."

    # say L711 lin
    old "We have to restore the power generator through a magic ritual and we only have one chance."
    new "B:lin: Tentei condensar o poder mágico, mas como não tinha energia suficiente, fiquei fraco e fui preso na igreja e depois no corpo da Billie."

    # say L712 pla
    old "So we gotta find the way to do it, tell me what to do and I'll do it... Now it's my responsibility as well."
    new "T(pla|tu|say): Então temos que encontrar a forma de fazer isso, me diz o que fazer e eu faço... Agora também é minha responsabilidade."

    # say L714 lin
    old "Are you sure? Are you sure you wanna help? You'll have to do lots of things."
    new "B:pla: Então temos que encontrar uma maneira de o fazer, diz-me o que devo fazer e eu farei... Agora é também a minha responsabilidade."

    # say L715 pla
    old "Well, I've done some already and I'm willing to do more."
    new "B:lin: Tens a certeza? Tens a certeza que queres ajudar? Vais ter de fazer muitas coisas."

    # say L716 lin
    old "Ok... Well, the church is a special point and has an unique vibration that allows us to collect more energy."
    new "B:pla: Bem, já fiz alguns e estou disposto a fazer mais."

    # say L719 lin
    old "It's dangerous, the shinigamis could get trapped... And you already know it's not easy to get out of a human's body. It's too risky at this point."
    new "T(lin|tu|say): É perigoso, os shinigamis poderiam ficar presos... E tu já sabes que não é fácil sair do corpo de um humano. É muito arriscado neste momento."

    # say L720 lin
    old "And on the other hand, we need people with a great concentration of power. You gotta look for at least two people who have this. Otherwise..."
    new "B:lin: É perigoso, os shinigamis podem ficar presos... E tu já sabes que não é fácil sair do corpo de um humano. É demasiado arriscado neste momento."

    # say L721 lin
    old "It won't work..."
    new "B:lin: E por outro lado, precisamos de pessoas com uma grande concentração de poder. Tens de procurar pelo menos duas pessoas que tenham isso. Caso contrário..."

    # say L722 pla
    old "Hmm... Ok, I get it..."
    new "B:lin: Não vai funcionar..."

    # say L723 pla
    old "(Actually I could try it with... The nun and Mrs. Jones would be perfect for that.)"
    new "B:pla: Hmm... Ok, percebi..."

    # say L724 lin
    old "Are you already thinking on someone?"
    new "T(lin|tu|say): Tu já estás a pensar em alguém?"

    # say L726 pla
    old "Yeah, I do know two women... But It won't be easy... Sister Grace and Mrs. Jones, are part of the church's community and they liked me."
    new "T(pla|tu|say): Sim, conheço duas mulheres... Mas não vai ser fácil... A Irmã Grace e a Sra. Jones fazem parte da comunidade da igreja e elas gostaram de mim."

    # say L727 pla
    old "I'm not sure but I could definitely try..."
    new "B:pla: Sim, conheço duas mulheres... Mas não vai ser fácil... A Irmã Grace e a Sra. Jones fazem parte da comunidade da igreja e gostaram de mim."

    # say L729 lin
    old "That's great! Do it... We have to try because it's our last chance, otherwise we'll have to wait until next year."
    new "B:lin: Não tenho a certeza, mas posso sempre tentar..."

    # say L730 lin
    old "The energy that will emerge in the church will only increase in this period of the year, that's why it's so important."
    new "B:lin: Ótimo! Faz isso... Temos que tentar porque é a nossa última hipótese, senão teremos que esperar até o próximo ano."

    # say L732 lin
    old "Now you know what we've to do... I'll get some rest and you should as well, you'll be very busy the next few days."
    new "B:lin: A energia que surgirá na igreja só vai aumentar neste período do ano, por isso é tão importante."

    # say L733 pla
    old "I can imagine... Ahh... I forgot to tell you, nice to meet you."
    new "B:lin: Agora sabes o que temos a fazer... Vou descansar e tu também deves fazer o mesmo, vais estar muito ocupado nos próximos dias."

    # menu L759 
    old "Ritual"
    new "B:pla: Boa noite, Linett."

    # say L763 lin
    old "Great! If you need anything, just let me know..."
    new "B:pla: Estou... Estou ainda a preparar-me para isso..."

    # say L764 pla
    old "Thanks, I'll... Now I should go..."
    new "B:lin: Ótimo! Se precisares de algo, avisa-me..."

    # say L765 lin
    old "Alright, see you!"
    new "Partilha o teu poder mágico"

    # say L771 lin
    old "You're such a kind man! Yes, I need some power... Please give it to me!"
    new "Tu és um homem tão bondoso! Sim, preciso de alguma força... Por favor, dá-ma!"

    # menu L780 
    old "Ask for magic power"
    new "B:lin: Tu és um homem tão bondoso! Sim, preciso de alguma força... Por favor, dá-ma!"

    # say L785 lin
    old "I can always share my power with you..."
    new "B:pla: Preciso de algum poder mágico... Poderias partilhar um pouco comigo?"

    # say L806 lin
    old "It was good as usual, I'm feeling much more energetic now."
    new "B:lin: Posso sempre partilhar a minha energia contigo..."

    # say L807 pla
    old "I'm glad I can always help!"
    new "B:lin: Foi bom como sempre, estou a sentir-me muito mais energético agora."

    # say L821 lin
    old "It was... I'm here whenever you need me"
    new "B:pla: Obrigado, Linett, foi muito energizante!"

    # say L822 pla
    old "Great! See you!"
    new "B:lin: Foi... Estou aqui sempre que precisas de mim."

    # say L838 pla
    old "What are you doing here?"
    new "B:pla: Uau! Linett! Tu assustaste-me!"

    # say L839 lin
    old "I have to talk with you. It's important."
    new "T(lin|tu|dizer): Tenho de falar contigo. É importante."

    # say L840 lin
    old "So, I was waiting here for you to wake up."
    new "B:lin: Tenho que falar contigo. É importante."

    # say L842 pla
    old "Yeah well. That's a bit weird."
    new "B:lin: Então, estava à espera que tu acordasses."

    # say L843 pla
    old "But anyway, what did you wanna tell me?"
    new "T(pla|tu|say): Mas enfim, o que querias dizer-me?"

    # say L845 lin
    old "It's about the ritual we did in the church, do you remember?"
    new "T(lin|tu|say): É sobre o ritual que fizemos na igreja, tu te lembras?"

    # say L846 pla
    old "Yeah I do, what about it?"
    new "B:lin: É sobre o ritual que fizemos na igreja, tu te lembras?"

    # say L847 lin
    old "Well, it's been a while since we tried it, and I think we should give it another go."
    new "B:pla: Claro que sim, e daí?"

    # say L848 lin
    old "After all, we still need those portals to generate magic again. And we're nearing the time of year to do it."
    new "T(lin|tu|say): Afinal, ainda precisamos desses portais para gerar magia de novo. E estamos nos aproximando da época do ano para fazê-lo."

    # say L850 pla
    old "But it didn't work last time, right?"
    new "B:lin: Afinal, ainda precisamos desses portais para gerar magia de novo. E estamos nos aproximando da época do ano para fazê-lo."

    # say L851 lin
    old "It didn't."
    new "T(lin|tu|say): Não funcionou."

    # say L852 lin
    old "And to be honest. I don't really know why..."
    new "B:lin: Não aconteceu."

    # say L853 lin
    old "I've been thinking about it, but I can't come up with a full explanation."
    new "B:lin: E a ser sincero. Não tenho a certeza de porquê..."

    # say L855 pla
    old "And you still want to try again? I mean... If we don't know what went wrong last time."
    new "B:lin: Tenho pensado nisso, mas não consigo chegar a uma explicação completa."

    # say L856 pla
    old "How do we know this time it's going to work?"
    new "B:pla: E ainda queres tentar de novo? Quero dizer... Se não sabemos o que correu mal da última vez."

    # say L858 lin
    old "About that, I said I didn't know but I do have some ideas as to what could make it work this time."
    new "T(lin|tu|say): Sobre isso, disse que não sabia, mas tenho algumas ideias sobre o que poderia fazer funcionar desta vez."

    # say L859 lin
    old "An important part of what went wrong, is that we couldn't direct the magic power the way we needed it to go."
    new "B:lin: Sobre isso, disse que não sabia, mas tenho algumas ideias sobre o que poderia fazer funcionar desta vez."

    # say L861 pla
    old "Direct? What do you mean?"
    new "B:lin: Uma parte importante do que correu mal foi que não conseguimos direcionar o poder mágico como precisávamos."

    # say L862 lin
    old "Well, as you can see when you use the agamoto's eye."
    new "B:pla: Direto? O que queres dizer?"

    # say L863 lin
    old "Magic power is, in essence, a series of particles that human bodies are able to absorb."
    new "B:lin: Bem, como podes ver quando usas o olho do agamoto."

    # say L864 lin
    old "However, human bodies are not designed to use and direct these particles into a specific point."
    new "B:lin: A energia mágica é, na essência, uma série de partículas que os corpos humanos conseguem absorver."

    # say L865 lin
    old "So we weren't able to condense the magic in the place we needed to."
    new "B:lin: No entanto, os corpos humanos não estão desenhados para usar e direcionar estas partículas num ponto específico."

    # say L867 pla
    old "But we did in the church, you said that was where it had to be."
    new "B:lin: Então não conseguimos condensar a magia no lugar onde era preciso."

    # say L868 lin
    old "Yeah sure, but it couldn't be the whole church, it has to be a specific point where the breach can occur."
    new "T(lin|tu|say): Claro, mas não podia ser em toda a igreja, tem que ser num ponto específico onde a brecha pode ocorrer."

    # say L869 pla
    old "Hmm, ok. So what do we have to do this time to make it happen?"
    new "B:lin: Claro, mas não pode ser toda a igreja, tem que ser um ponto específico onde a brecha pode ocorrer."

    # say L871 lin
    old "To be honest, I'm not sure yet. I have to figure it out soon."
    new "T(lin|tu|say): Para ser honesto, ainda não tenho a certeza. Tenho de descobrir isso em breve."

    # say L873 lin
    old "However, it is true that the magic power is running out."
    new "B:lin: A ser sincero, ainda não tenho a certeza. Tenho de descobrir isso em breve."

    # say L874 lin
    old "That means we definitely have to do it again soon. And it has to be in the church."
    new "B:lin: No entanto, é verdade que o poder mágico está a acabar."

    # say L876 lin
    old "So, while I figure it all out, you talk to the church people again, so we have access to it."
    new "B:lin: Isso significa que definitivamente temos que fazer de novo em breve. E tem que ser na igreja."

    # say L877 pla
    old "Oh, damn, do we have to do it again with them?"
    new "B:lin: Então, enquanto eu descubro tudo, tu falas com as pessoas da igreja de novo, para termos acesso."

    # say L878 lin
    old "Not necessarily... Let me solve this first."
    new "B:pla: Oh, merda, temos de o fazer de novo com eles?"

    # say L879 lin
    old "For now just try and make sure we can use the church again when the moment comes, ok?"
    new "B:lin: Nem sempre... Deixa-me resolver isto primeiro."

    # say L881 pla
    old "Sure, no problem, I'll handle it."
    new "T(pla|tu|say): Claro, sem problemas, eu trato disso."

    # say L904 gra
    old "And what do I owe this nice surprise?"
    new "B:pla: Olá Irmã Grace, bom ver-te de novo."

    # say L905 pla
    old "I just wanted to say hello. And see if you need help with anything."
    new "B:gra: E a que devo esta agradável surpresa?"

    # say L906 pla
    old "You know, with decorating and stuff. I have some free time, so I figured I could help you."
    new "B:pla: Só queria dizer olá. E ver se precisas de ajuda com alguma coisa."

    # say L908 gra
    old "Oh lord! You're sent again from the heavens, this is perfect."
    new "B:pla: Sabes, com a decoração e tudo mais. Tenho algum tempo livre, então pensei que poderia ajudar-te."

    # say L909 gra
    old "Just today we were going to start with the Christmas decorations. So you came at the right moment."
    new "B:gra: Oh, Senhor! Tu foste enviado dos céus de novo, isto é perfeito."

    # say L910 pla
    old "Oh really? That's perfect, I can help with whatever you need."
    new "B:gra: Apenas hoje íamos começar com as decorações de Natal. Portanto, chegaste na altura certa."

    # say L911 gra
    old "Come with me, I'll show you."
    new "B:pla: Oh realmente? Isso é perfeito, posso ajudar com o que precisares."

    # say L920 jon
    old "Hello darling, it's good to see you. And may I ask what brings you here?"
    new "B:pla: Olá Sra. Jones."

    # say L921 pla
    old "I just came to see if I could help with the Christmas decorations."
    new "B:jon: Olá querida, é bom ver-te. E posso perguntar o que te traz aqui?"

    # say L922 jon
    old "Oh! Well, that's very nice of you. And you came just in time, we were about to start."
    new "B:pla: Vim só ver se podia ajudar com as decorações de Natal."

    # say L923 gra
    old "I was telling him just that, the Lord knew we needed his help and sent him to us."
    new "B:jon: Oh! Bem, isso é muito gentil da tua parte. E chegaste na altura certa, estávamos prestes a começar."

    # say L924 jon
    old "Well darling, let's not waste time, come with us, we'll show you what we need."
    new "B:gra: Estava a dizer-lhe justamente isso, o Senhor sabia que precisávamos da sua ajuda e enviou-o a nós."

    # say L926 gra
    old "We need your help with putting up the decorations for Christmas."
    new "B:jon: Bem querida, não vamos perder tempo, vem connosco, mostraremos o que precisamos."

    # say L927 jon
    old "The decorations have to be put on the benches and up in the ceiling."
    new "B:gra: Precisamos da tua ajuda para pendurar as decorações de Natal."

    # say L928 jon
    old "It has to be ready before Christmas eve for the members of the congregation to enjoy."
    new "B:jon: As decorações têm de ser colocadas nos bancos e no teto."

    # say L929 pla
    old "Sure thing, no problem."
    new "Clica em todos os espaços marcados a tempo para decorar a igreja."

    # narrator L936 
    old "Click all the marked spaces in time to decorate the church."
    new "B:pla: Com certeza, sem problemas."

    # say L952 pla
    old "Good morning Mrs. Jones, Sister Grace."
    new "B:n: Clica em todos os espaços marcados a tempo para decorar a igreja."

    # say L955 pla
    old "I'm fine thank you, I came to help you with the decorations again."
    new "B:jon: Olá querida, como estás?"

    # say L956 gra
    old "Oh thank you so much, you're of such great help."
    new "B:pla: Estou bem, obrigado, vim para te ajudar com as decorações de novo."

    # say L957 jon
    old "Sister Grace is right, it's nice that you came back today. Thank you darling."
    new "B:gra: Oh, muito obrigado, és de grande ajuda."

    # say L958 pla
    old "It's no problem."
    new "B:jon: A irmã Grace tem razão, é bom que tenhas voltado hoje. Obrigado, querida."

    # say L959 pla
    old "I'll get to it then."
    new "B:pla: Não é problema."

    # say L978 jon
    old "Oh darling! You're such a good worker."
    new "B:pla: Vou tratar disso então."

    # say L979 gra
    old "I'm sure if you keep going at this pace you'll have it ready in no time."
    new "B:jon: Oh querida! Tu és uma trabalhadora excelente."

    # say L981 jon
    old "Having you do all this work really helps us a lot."
    new "B:gra: Tenho a certeza de que, se continuares a este ritmo, vais ter tudo pronto num instante."

    # say L982 gra
    old "I agree, the Lord graced us with this great help of yours."
    new "B:jon: O teu trabalho realmente nos ajuda muito."

    # say L983 jon
    old "Now, I'm sure you have some other things to do. So we won't keep you here anymore."
    new "B:gra: Concordo, o Senhor nos concedeu esta grande ajuda sua."

    # say L984 jon
    old "But make sure to come back soon."
    new "B:jon: Agora, tenho a certeza de que tens outras coisas para fazer. Por isso, não te vamos reter mais."

    # say L986 pla
    old "Sure, I'll be back soon and keep helping you."
    new "B:jon: Mas certifica-te de voltar depressa."

    # say L1023 jon
    old "Well... You didn't really do much today."
    new "B:pla: Claro, volto já e continuo a ajudar-te."

    # say L1024 jon
    old "But it's ok, it's a delicate thing to do. I'm sure you'll get the hang of it soon."
    new "B:jon: Bem... Tu não fizeste muito hoje."

    # say L1025 gra
    old "That's right, the lord will illuminate you and you'll get better at it. Don't worry."
    new "B:jon: Mas está tudo bem, é uma coisa delicada de se fazer. Tenho a certeza que vais pegar o jeito em breve."

    # say L1026 pla
    old "Yeah... Sure."
    new "T(pla|tu|say): Sim... Claro."

    # say L1027 pla
    old "I have a couple of things to do, so I think I'll get going, but I'll come back again and keep working."
    new "B:pla: Sim... Claro."

    # say L1043 pla
    old "Huh? Problem? Good morning by the way."
    new "T(pla|tu|say): Hã? Problema? Bom dia, aliás."

    # say L1044 lin
    old "Yeah, the problem we had with the ritual last time, I figured out what it was."
    new "B:pla: Huh? Problema? Bom dia, aliás."

    # say L1045 pla
    old "Oh right, right. I remember."
    new "B:lin: Sim, o problema que tivemos com o ritual da última vez, descobri o que era."

    # say L1046 pla
    old "So? What was it?"
    new "B:pla: Ah, claro, claro. Lembro-me."

    # say L1048 lin
    old "Well, I figured out that the problem last time, was that we did it with human bodies that couldn't retain as much magic power."
    new "B:pla: Então? O que foi?"

    # say L1049 lin
    old "Well, two of them couldn't."
    new "B:lin: Bem, descobri que o problema da última vez foi que usámos corpos humanos que não conseguiam reter tanto poder mágico."

    # say L1050 pla
    old "What? What does that mean?"
    new "B:lin: Bem, dois deles não conseguiram."

    # say L1051 lin
    old "Unlike us, you humans get old as time passes."
    new "T(lin|tu|dizes): Ao contrário de nós, vocês, humanos, envelhecem com o passar do tempo."

    # say L1052 lin
    old "This means that the older you get, the less magic power you're able to retain."
    new "B:lin: Ao contrário de nós, vocês, humanos, envelhecem com o passar do tempo."

    # say L1053 lin
    old "I believe that's the mistake we made last time."
    new "B:lin: Isso significa que quanto mais velho você fica, menos poder mágico consegue reter."

    # say L1054 lin
    old "So this time it has to be done with young people. They should be able to retain the amount of magic we need."
    new "B:lin: Acredito que foi esse o erro que cometemos da última vez."

    # say L1056 pla
    old "Three young girls... I mean, damn, that would be a bit difficult."
    new "T(pla|tu|say): Três raparigas... Quer dizer, merda, isso seria um bocado difícil."

    # say L1057 pla
    old "Hmm... I suppose Billie would help again... and my only friends are Belle and Hinn..."
    new "B:pla: Três raparigas... Quer dizer, merda, isso seria um bocado complicado."

    # say L1060 lin
    old "Directing the magic power to a specific point isn't as easy as I thought."
    new "B:lin: Bem, deves mesmo arranjar uma maneira... E eu também estou a trabalhar no ritual..."

    # say L1061 lin
    old "I still have to run some more tests."
    new "B:lin: Dirigir a energia mágica para um ponto específico não é tão fácil quanto eu pensava."

    # say L1062 lin
    old "So you have time to figure it out."
    new "B:lin: Ainda tenho que fazer mais alguns testes."

    # say L1064 pla
    old "Ok, ok, I'll think about it."
    new "B:lin: Então tens tempo para pensar."

    # say L1066 lin
    old "Ok, then keep working on the church, I'll contact you as soon as I know exactly what we need."
    new "B:pla: Ok, ok, vou pensar nisso."

    # say L1084 pla
    old "Oh, hi [sis], how are you doing?"
    new "T(pla|tu|say): Oh, olá [sis], como estás?"

    # say L1092 pla
    old "Oh, hi [sis], what are you doing up so late?"
    new "B:pla: Olá [sis], como estás?"

    # say L1096 pla
    old "Did you sell something expensive online?"
    new "B:pla: Huh? O que queres dizer com \"funcionou\"?"

    # say L1098 linSis
    old "No, no, no, it's me Linett. Listen, use agamoto's eye."
    new "B:pla: Vendeste algo caro online?"

    # say L1100 linSis
    old "Just do it, use the agamoto's eye."
    new "B:linSis: Não, não, não, sou eu, a Linett. Escuta, usa o olho do agamoto."

    # say L1111 pla
    old "Woah! That's insane. But wait, come with me for a moment, we can't keep talking here."
    new "B:lin: Sim! Sim! Consegui entrar nela!"

    # say L1119 linSis
    old "To see if I could do it better this time."
    new "B:linSis: Bem, percebi que fazer isto seria necessário para o ritual, por isso decidi tentar fazê-lo de novo."

    # say L1120 pla
    old "What do you mean to do it better?"
    new "B:linSis: Para ver se conseguia fazer melhor desta vez."

    # say L1121 linSis
    old "Well, we don't usually get involved with humans."
    new "B:pla: O que queres dizer com fazer melhor?"

    # say L1122 linSis
    old "So, doing something like getting inside a person is a bit weird."
    new "B:linSis: Bem, normalmente não nos envolvemos com humanos."

    # say L1123 linSis
    old "I did it last time because, I was looking trying to survive by taking your friend as my host."
    new "B:linSis: Então, fazer algo como entrar dentro de uma pessoa é um bocado estranho."

    # say L1124 linSis
    old "So, I was almost dead that time..."
    new "B:linSis: Fiz isso da última vez porque estava tentando sobreviver usando a tua amiga como anfitriã."

    # say L1125 pla
    old "Ok... But why did you do it again?"
    new "B:linSis: Então, quase morri naquela vez..."

    # say L1127 linSis
    old "Well, I thought that if I did it at will, and at full strength, maybe it would be different."
    new "B:pla: Ok... Mas por que fizeste isso de novo?"

    # say L1128 linSis
    old "That I could do it with a lot more control."
    new "B:linSis: Bem, pensei que se o fizesse à vontade e com toda a força, talvez fosse diferente."

    # say L1129 linSis
    old "And it worked! See how well I can control her?! There's not even a little bit of interference."
    new "B:linSis: Que eu conseguisse fazê-lo com muito mais controlo."

    # say L1132 linSis
    old "Well, you see... We may have a little of a problem there."
    new "B:pla: E tens de o fazer agora!"

    # say L1133 pla
    old "What do you mean a problem?"
    new "B:linSis: Bem, tu sabes... Podemos ter um pequeno problema."

    # say L1134 linSis
    old "Remember what you did last time to get me out of your friend's body?"
    new "T(linSis|tu|dizes): Lembras-te do que fizeste da última vez para me tirar do corpo da tua amiga?"

    # say L1136 pla
    old "Hmm, not really...  Why?"
    new "B:linSis: Lembras-te do que fizeste da última vez para me tirar do corpo da tua amiga?"

    # say L1142 linSis
    old "No, she won't feel or remember anything."
    new "T(linSis|tu|diz): Não vais sentir nem te vais lembrar de nada. Como é que sabes?"

    # say L1143 pla
    old "How do you know?"
    new "B:linSis: Não, ela não vai sentir nem lembrar de nada."

    # say L1145 linSis
    old "Well, I did it with a different spell, one that grants me total control of this body."
    new "B:pla: Como é que sabes?"

    # say L1146 linSis
    old "The host is unconscious. And she will be until I leave the body."
    new "B:linSis: Bem, fiz isso com um feitiço diferente, um que me dá o controlo total deste corpo."

    # say L1147 linSis
    old "Besides, this time I'm at full magic power, so I have no trouble controlling her completely."
    new "B:linSis: O anfitrião está inconsciente. E vai continuar assim até eu sair do corpo."

    # say L1148 pla
    old "I still don't get why you had to do this. I mean, what is all of this for?"
    new "B:linSis: Além disso, desta vez estou com o meu poder mágico completo, por isso não tenho problemas em controlá-la completamente."

    # say L1149 linSis
    old "This is for the ritual I mean, with all the control this method gives to me, I'll have no trouble directing the magic power."
    new "T(linSis|tu|say): Isto é para o ritual, quero dizer, com todo o controlo que este método me dá, não terei problemas em direcionar o poder mágico."

    # say L1150 pla
    old "Ohhh... I get it."
    new "B:linSis: Isto é para o ritual, quero dizer, com todo o controlo que este método me dá, não terei problemas em direcionar a energia mágica."

    # say L1151 linSis
    old "Now, give me the magic power I need to get out of this body."
    new "B:pla: Ohhh... Agora percebo."

    # say L1167 linSis
    old "That's not possible, even after I get out, it's going to take a while before she wakes up."
    new "B:pla: E se ela acordar durante isso?"

    # say L1168 pla
    old "Hmmm, ok."
    new "A:linSis: O teu pénis é impressionante, este tamanho e espessura."

    # say L1169 linSis
    old "Your cock is impressive, this size and thickness."
    new "O teu pénis é impressionante, este tamanho e espessura. Não admira que nunca tenhas problemas em me fornecer magia."

    # say L1170 linSis
    old "No wonder you never have trouble supplying me with magic."
    new "B:linSis: O teu pénis é impressionante, este tamanho e espessura."

    # say L1171 pla
    old "We have to do this quick. Someone could hear us."
    new "B:linSis: Não admira que nunca tenhas problemas em me fornecer magia."

    # say L1174 pla
    old "Ok, ok, I'll do it."
    new "E eu posso fazer de novo só para experimentar isso."

    # say L1184 lin
    old "I might do it again just to experience that."
    new "B:pla: Ok, ok, faço isso."

    # say L1185 pla
    old "Haha, very funny."
    new "A:pla: Devíamos ir para o meu quarto."

    # say L1186 pla
    old "We should go to my bedroom."
    new "T: Devíamos ir para o meu quarto."

    # say L1187 pla
    old "But first help me clean her and put her in bed."
    new "B:pla: Devíamos ir para o meu quarto."

    # say L1188 pla
    old "She's not gonna wake up if we move her. Right?"
    new "B:pla: Mas primeiro ajuda-me a limpar ela e a deitar na cama."

    # say L1189 lin
    old "No, she's passed out."
    new "B:lin: Ela não vai acordar se a movermos. Certo?"

    # say L1190 lin
    old "And won't wake up for a while, so it's ok."
    new "B:lin: Não, ela desmaiou."

    # say L1196 lin
    old "This is perfect, now we can finally do the whole ritual succesfully!"
    new "B:lin: E não vai acordar durante um bom tempo, então está tudo bem."

    # say L1197 pla
    old "That's good and all, but that experiment was a little too much."
    new "B:lin: Isto é perfeito, agora podemos finalmente realizar todo o ritual com sucesso!"

    # say L1198 lin
    old "Well, it worked and that's all that matters."
    new "B:lin: Isso foi bom e tudo, mas esse experimento foi um pouco demais."

    # say L1199 lin
    old "What's most important right now is that there's another problem to solve."
    new "T(lin|tu|say): O mais importante agora é que há outro problema a resolver."

    # say L1200 pla
    old "What another one? What else do we need?"
    new "B:lin: O mais importante agora é que há outro problema a resolver."

    # say L1201 lin
    old "Well, we need the actual people."
    new "B:pla: Mais uma? O que mais precisamos?"

    # say L1202 lin
    old "Remember, I did this experiment because we need to control the magic in humans?"
    new "B:lin: Precisamos das pessoas reais."

    # say L1204 pla
    old "Oh, you're right, I forgot."
    new "T(pla|tu|say): Oh, tens razão, esqueci-me."

    # say L1205 lin
    old "The problem is that we need three people, and I can't get inside all three of them."
    new "B:pla: Oh, tens razão, esqueci-me."

    # say L1206 pla
    old "Oh, actually, I hadn't told you, but I know three other shinigamis."
    new "B:lin: O problema é que precisamos de três pessoas, e eu não consigo entrar em todas as três."

    # say L1207 pla
    old "Maybe we could explain the situation to them, and ask for their help."
    new "T(pla|tu|say): Talvez possamos explicar a situação a eles e pedir a ajuda deles."

    # say L1208 lin
    old "Hmm... It could be, but I would need to train them to do it."
    new "B:pla: Talvez pudéssemos explicar a situação a eles e pedir a sua ajuda."

    # say L1209 pla
    old "I think it will be fine if we talk to them."
    new "B:lin: Hmm... Pode ser, mas precisava de os treinar para isso."

    # say L1210 lin
    old "Ok, so let's go, where are they?"
    new "B:pla: Acho que não há problema em falar com eles."

    # say L1212 pla
    old "Woah, you wanna go now?"
    new "A:pla: Ouve, já é bem tarde e eu nem dormi nada."

    # say L1213 pla
    old "Listen, it's pretty late and I haven't slept at all."
    new "B:pla: Woah, tu queres ir já?"

    # say L1214 pla
    old "What about if we go tomorrow morning?"
    new "B:pla: Ouve, já é bem tarde e eu ainda não dormi nada."

    # say L1216 lin
    old "Hmm, ok, I'll come here tomorrow morning then."
    new "B:pla: E se formos amanhã de manhã?"

    # say L1217 pla
    old "Ok, see you tomorrow."
    new "T(pla|tu|say): Ok, vejo-te amanhã."

    # say L1233 lin
    old "Hey, are you ready to go talk with the other shinigamies?"
    new "O quê? Agora? Acabei de acordar!"

    # say L1234 pla
    old "What? Now? I just woke up!"
    new "B:lin: Ei, estás pronto para ir falar com os outros shinigamis?"

    # say L1235 lin
    old "What!? Remember I have to teach them how to do the spell. It's not as simple as when you use magic."
    new "B:pla: O quê? Agora? Acabei de acordar!"

    # say L1236 lin
    old "It takes time to learn a spell, and we don't even know if they're going to say yes."
    new "B:lin: Que!? Lembra-te que tenho de lhes ensinar a fazer o feitiço. Não é tão simples como quando usas magia."

    # say L1237 lin
    old "So we have to go now!"
    new "B:lin: Leva tempo para aprender um feitiço, e nem sabemos se eles vão dizer que sim."

    # say L1238 pla
    old "Ok, ok, I get it."
    new "B:lin: Então temos que ir agora!"

    # say L1239 pla
    old "Let's go then."
    new "B:pla: Ok, ok, percebi. T(pla|tu|say): Vamos então. A:pla: Olá, raparigas."

    # say L1262 pla
    old "Hey girls."
    new "B:pla: Vamos então. T(pla|tu|say): Ei, raparigas. A:mil: Olá."

    # say L1264 dev
    old "Oh! [pla] is here! Hiiii, it's been a while since I've seen you!"
    new "T(dev|tu|say): Oh! [pla] está aqui! Oi, já faz um tempo que não te vejo!"

    # say L1266 pla
    old "Fine, fine, thank you."
    new "B: gom: Olá, como tens estado?"

    # say L1267 pla
    old "Hey, remember that a while ago, I told you about a shinigami that was inside one of my friends?"
    new "E tu perguntaste-me o que fazer?"

    # say L1268 pla
    old "And I asked you for advice about what to do?"
    new "B:pla: Ei, lembra-te que há um bocado te falei de um shinigami que estava dentro de um dos meus amigos?"

    # say L1270 mil
    old "Indeed, we remember, what about it?"
    new "B:pla: E pedi-te conselho sobre o que fazer?"

    # say L1271 pla
    old "Well, I wanted to introduce her to you, so I brought her with me."
    new "B:mil: Claro, lembramos, e então?"

    # say L1280 pla
    old "Everyone, this is Linett."
    new "B:pla: Bem, queria apresentá-la a vocês, por isso trouxe-a comigo."

    # say L1281 lin
    old "Hello, nice meeting you."
    new "B:pla: Todos, esta é a Linett."

    # say L1284 gom
    old "Umm... eh, hi."
    new "B:lin: Olá, prazer em conhecer-te."

    # say L1285 lin
    old "I understand your surprise, I didn't expect to see other shinigamis in this town."
    new "B:gom: Hum... eh, olá."

    # say L1286 lin
    old "But I have to talk to you about something important."
    new "T(lin|tu|say): Mas tenho que falar contigo sobre algo importante."

    # say L1287 pla
    old "I think you should listen to her, it's about the magic power."
    new "B:lin: Mas tenho de falar contigo sobre algo importante."

    # say L1290 mil
    old "The magic power? What about it?"
    new "B:pla: Acho que deves ouvir o que ela diz, é sobre o poder mágico."

    # say L1291 dev
    old "I don't know about you. But if [pla] says it's ok, I'll listen."
    new "T(dev|tu|say): Não sei contigo. Mas se [pla] diz que está bem, eu ouço."

    # say L1293 lin
    old "Some time ago I discovered that in this town's church used to be a place with a strong connection with the magic world."
    new "B: gom: Hmm, isto poderia ser importante."

    # say L1294 mil
    old "So? What does it matter now that the magic world doesn't exist?"
    new "B:lin: Há algum tempo descobri que nesta igreja da cidade costumava haver um lugar com uma forte ligação ao mundo mágico."

    # say L1295 lin
    old "Well... That connection remains even if the magic world is gone."
    new "B:mil: Então? O que importa agora que o mundo mágico não existe?"

    # say L1296 dev
    old "Oh! Really?"
    new "B:lin: Bem... Essa conexão permanece mesmo que o mundo mágico tenha desaparecido."

    # say L1297 gom
    old "And what does it mean?"
    new "B:dev: Oh! Mesmo?"

    # say L1298 lin
    old "It means that is a perfect place to set a magic power generating point."
    new "B:gom: E o que isso significa?"

    # say L1299 gom
    old "Wow, really? That's amazing."
    new "B:lin: Isso significa que é um lugar perfeito para estabelecer um ponto gerador de energia mágica."

    # say L1305 pla
    old "Actually, that's why we came here today. We need your help with the ritual."
    new "B:lin: Mas correu mal. No entanto, acredito que resolvi o problema e gostaria de tentar de novo."

    # say L1306 mil
    old "Our help? We don't even know you... or your intentions..."
    new "B:pla: Na verdade, foi por isso que viemos aqui hoje. Precisamos da tua ajuda com o ritual."

    # say L1307 gom
    old "She's right, this is the first time any of us has heard anything like this."
    new "B:mil: A nossa ajuda? Nem sequer te conhecemos... ou as tuas intenções..."

    # say L1308 lin
    old "I know it sounds strange, this is actually new for me too."
    new "B:gom: Ela tem razão, esta é a primeira vez que qualquer um de nós ouve algo assim."

    # say L1309 lin
    old "But we need to try it because the magic power is running out."
    new "B:lin: Eu sei que parece estranho, isto também é novo para mim."

    # say L1310 lin
    old "And if we don't do anything we're just going to die. I gain nothing by lying to you."
    new "B:lin: Mas precisamos tentar porque o poder mágico está a acabar."

    # say L1312 dev
    old "Ok and what do you propose we do?"
    new "B:lin: E se não fizermos nada, vamos morrer. Não tenho nada a ganhar em mentir-te."

    # say L1316 gom
    old "I see, I get the idea."
    new "B:lin: A ideia é que os usemos num ritual para criar um ponto de rutura e derramar magia nele para forçá-lo a abrir."

    # say L1317 gom
    old "But I see some difficulties with the plan."
    new "B:gom: Entendo, percebo a ideia."

    # say L1319 mil
    old "For starters, humans can't control magic. And even if they could, how would we make them do that?"
    new "B:gom: Mas vejo algumas dificuldades no plano."

    # say L1321 lin
    old "Well, the idea is that we're going to get inside them, and control the magic from within."
    new "B:mil: Para começar, os humanos não conseguem controlar a magia. E mesmo que conseguissem, como faríamos com que eles fizessem isso?"

    # say L1325 dev
    old "What? We're going to be trapped!"
    new "B:lin: A ideia é entrarmos nelas e controlar a magia por dentro."

    # say L1326 mil
    old "That's right, it's pretty weird to think doing that on purpose, is really dangerous."
    new "T(mil|tu|say): É verdade, é estranho pensar em fazer isso de propósito, é realmente perigoso."

    # say L1327 mil
    old "Isn't this just a trap to imprison us in human bodies?"
    new "B:mil: É verdade, é bastante estranho pensar em fazer isso de propósito, é realmente perigoso."

    # say L1328 lin
    old "What!? What would I get from that?"
    new "B:mil: Não será isto apenas uma armadilha para nos prender em corpos humanos?"

    # say L1329 pla
    old "A- actually, we discovered that there is a way to do it safely."
    new "B:lin: O quê!? O que é que eu ganharia com isso?"

    # say L1330 lin
    old "Exactly, I've been running some tests, and found a way in which it can be done."
    new "A:lin: Criei um feitiço que nos permite entrar num corpo humano e controlá-lo à vontade."

    # say L1331 lin
    old "I've created a spell with which we can get inside a human body and control it at will."
    new "B:lin: Exatamente, tenho estado a fazer alguns testes e encontrei uma forma de o fazer."

    # say L1332 lin
    old "And we can do it without being on the verge of death."
    new "B:lin: Criei um feitiço com o qual podemos entrar num corpo humano e controlá-lo à vontade."

    # say L1333 gom
    old "I had never heard of something like that, are you sure about what you're saying?"
    new "B:lin: E podemos fazer isso sem estar à beira da morte."

    # say L1334 pla
    old "She's telling the truth, I helped her."
    new "B: gom: Nunca tinha ouvido falar de uma coisa dessas, tens a certeza do que estás a dizer?"

    # say L1335 lin
    old "If you'll let me show, I can teach you how to do it."
    new "B:pla: Ela está a dizer a verdade, ajudei-a."

    # say L1337 mil
    old "I can't believe you're actually considering listening to this!"
    new "B:lin: Se me deixares mostrar, posso ensinar-te a fazer isso."

    # say L1340 lin
    old "Ok, I know after listening you will understand."
    new "B: gom: Ok, vamos ouvir o que tens a dizer, mas se não nos convenceres, não te seguiremos."

    # say L1341 lin
    old "But wait, before I start. Don't have to keep working in the church? Let me this to me and you keep working on the church."
    new "B:lin: Ok, sei que depois de ouvir vais entender."

    # say L1342 lin
    old "We are running out of time and need that place ready for the ritual."
    new "B:lin: Mas espera, antes de começar. Não tens de continuar a trabalhar na igreja? Deixa-me fazer isto e tu continua a trabalhar na igreja."

    # say L1344 pla
    old "Oh right."
    new "B:lin: Estamos a ficar sem tempo e precisamos que esse lugar esteja pronto para o ritual."

    # say L1345 pla
    old "Ok, ok I'll keep working on the church, while you explain everything to them. See you later guys."
    new "B:pla: Oh, certo."

    # say L1347 lin
    old "Great, we'll talk later at home."
    new "B:pla: Ok, ok, vou continuar a trabalhar na igreja, enquanto tu explicas tudo a eles. Até mais tarde, pessoal."

    # say L1348 dev
    old "See you [pla]!"
    new "Olá [pla]!"

    # say L1364 lin
    old "Hey there [pla]!"
    new "B:dev: Até [pla]!"

    # say L1365 pla
    old "Oh, hey, did you manage to convince them?"
    new "A:lin: Sim, consegui, mas não acreditaram em mim no início."

    # say L1366 lin
    old "Yeah, I did, they didn't believe me at first."
    new "B:pla: Oh, ei, conseguiste convencê-los?"

    # say L1367 lin
    old "Especially that Mildret one. She was a lot of trouble."
    new "B:lin: Sim, eu fiz, eles não acreditaram no início."

    # say L1368 lin
    old "But once I showed them the spell they understood."
    new "B:lin: Especialmente aquela Mildret. Ela deu muito trabalho."

    # say L1370 pla
    old "You showed them? But how did you get out of the host?"
    new "B:lin: Mas quando lhes mostrei o feitiço, eles entenderam."

    # say L1372 lin
    old "I didn't perform it. I only told them how it was done."
    new "B:pla: Mostraste-lhes? Mas como saíste do hospedeiro?"

    # say L1373 lin
    old "All shinigami know and understand magic, so they knew I was telling them the truth."
    new "B:lin: Não o fiz. Apenas lhes disse como foi feito."

    # say L1375 pla
    old "Oh, I see, nice."
    new "T(pla|tu|say): Oh, percebo, fixe."

    # say L1376 pla
    old "Everything's fine now, right? I mean, now you all know the spell."
    new "B:pla: Oh, percebo, fixe."

    # say L1377 pla
    old "And I'm taking care of the church, so we're almost ready."
    new "B: pla: Tudo bem agora, certo? Quero dizer, agora tu já sabes o feitiço."

    # say L1378 lin
    old "Hmm, not really. It sounds ok, but it's a very complicated spell. And I merely explained it to them...."
    new "B:pla: E estou a tomar conta da igreja, por isso estamos quase prontos."

    # say L1379 lin
    old "If we want to make sure that everything goes perfect the day of the ritual, they're going to need practice."
    new "B:lin: Hmm, não realmente. Soa bem, mas é um feitiço muito complicado. E eu apenas expliquei isso a eles...."

    # say L1381 pla
    old "Ok, so, what do you need me to do now?"
    new "Ok, então, o que preciso fazer agora?"

    # say L1382 lin
    old "For now it would be really good if you can decide on the three humans we're using for the ritual."
    new "Para já, seria ótimo se pudesses decidir sobre as três pessoas que vamos usar para o ritual. Tu disseste que tinhas algumas pessoas em mente."

    # say L1383 lin
    old "You said you had some people in mind."
    new "B:lin: Para já seria realmente bom se pudesses decidir sobre os três humanos que vamos usar para o ritual."

    # say L1385 pla
    old "Y- yeah I did. But I- I don't know..."
    new "T(pla|tu|say): Y- yeah I did. But I- I don't know..."

    # say L1387 lin
    old "I already told you there's no need to worry."
    new "B:pla: Y- yeah I did. But I- I don't know..."

    # say L1388 lin
    old "Remember, they'll be unconscious during the ritual and after."
    new "B:lin: Já te disse que não há motivo para te preocupares."

    # say L1389 lin
    old "And all the time we'll be controlling them."
    new "B:lin: Lembra-te, eles estarão inconscientes durante o ritual e depois."

    # say L1390 lin
    old "So, you shouldn't be this worried."
    new "B:lin: E durante todo o tempo estaremos a controlá-los."

    # say L1391 pla
    old "Hmm ok, if that's how it is. Then, I guess I know who could work..."
    new "B:lin: Então, não deves estar assim tão preocupado."

    # say L1392 lin
    old "Great, then tomorrow morning we'll go see the shinigamis again and would be perfect to test the spell with one of them."
    new "Ótimo, então amanhã de manhã vamos ver os shinigamis de novo e seria perfeito para testar o feitiço com um deles. Assim eles podem praticar antes do ritual."

    # say L1393 lin
    old "So that they can practice before the ritual."
    new "B:lin: Ótimo, então amanhã de manhã vamos ver os shinigamis de novo e seria perfeito testar o feitiço com um deles."

    # say L1394 pla
    old "You mean with a human?"
    new "B:lin: Para que possam praticar antes do ritual."

    # say L1398 pla
    old "Hmm... I guess you are right..."
    new "B:lin: Precisamos ter a certeza de que tudo vai correr bem."

    # say L1399 lin
    old "All right, everything is done, you better go to sleep because we have a lot to do tomorrow."
    new "Tudo bem, tudo está feito, tu melhor vais dormir porque temos muito que fazer amanhã."

    # say L1433 pla
    old "Hey girls, good morning."
    new "B:pla: Oh, bom dia, claro, vamos lá."

    # say L1434 mil
    old "Hello again."
    new "B:pla: Olá raparigas, bom dia."

    # say L1435 gom
    old "Hi, how are you today?"
    new "B:mil: Olá de novo."

    # say L1439 lin
    old "So we'll go and find them for you to practice the spell before the ritual."
    new "B:lin: E ele já me disse que tem três pessoas em mente para isso."

    # say L1440 lin
    old "Just to make sure that you can handle the spell and control the host body."
    new "B:lin: Vamos procurá-los para tu praticares o feitiço antes do ritual."

    # say L1442 dev
    old "What? Now?... B- but I'm not ready... What if I can't get out?"
    new "B:lin: Só para ter a certeza de que consegues controlar o corpo anfitrião e manusear o feitiço."

    # say L1443 lin
    old "Don't worry Devonne, We may practice more with you."
    new "B:dev: O quê? Agora?... B- mas eu não estou preparado... E se eu não conseguir sair?"

    # say L1444 lin
    old "Actually, I was thinking of starting with Gomory, I think she is ready."
    new "B:lin: Não te preocupes, Devonne, podemos praticar mais contigo."

    # say L1445 mil
    old "Ok, it sounds fine."
    new "B:lin: Na verdade, estava a pensar começar com Gomory, acho que ela está pronta."

    # say L1446 gom
    old "Yeah, it would be good to try it now."
    new "B:mil: Ok, parece bem."

    # say L1449 pla
    old "Ok, so what's the idea? What should we do?"
    new "T(pla|tu|say): Ok, então qual é a ideia? O que devemos fazer?"

    # say L1450 lin
    old "You just have to take her to where her host is."
    new "T(lin|tu|say): Tu só tens de a levar ao local onde o seu anfitrião está."

    # say L1451 lin
    old "And see that everything goes well while she performs the spell."
    new "B:lin: Tu só tens de a levar ao local onde o seu anfitrião está."

    # say L1452 lin
    old "As long as you're with her there shouldn't be a problem."
    new "B:lin: E vê se tudo corre bem enquanto ela faz o feitiço."

    # say L1453 pla
    old "Hmph, I see..."
    new "B:lin: Desde que estejas com ela, não deve haver problema."

    # say L1454 pla
    old "Ok, I get it. Then let's go to where she is. Come with me Gomory."
    new "B:pla: Hmph, eu vejo..."

    # say L1463 gom
    old "Who is going to be my host?"
    new "B:pla: Ok, percebi. Então vamos onde ela está. Vem comigo, Gomory."

    # say L1464 pla
    old "She's a friend of mine, her name is Belle, I think we should try with her first."
    new "B:gom: Quem vai ser a minha anfitriã?"

    # say L1478 pla
    old "Ok, we found her. What do you need to get in her body?"
    new "B:pla: É uma amiga minha, chama-se Belle, acho que devíamos tentar com ela primeiro."

    # say L1479 gom
    old "Not much really, all we need is for her to be relaxed for a moment, and I'll canalize the spell."
    new "B:pla: Ok, encontrámo-la. O que precisas para entrares no corpo dela?"

    # say L1480 pla
    old "Hmm, ok, so it should be fine if we're just talking, right?"
    new "B:gom: Não muito, na verdade, só precisamos que ela esteja relaxada por um momento, e eu canalizarei o feitiço."

    # say L1481 gom
    old "That's right, it doesn't take more than a few seconds."
    new "B:pla: Hmm, ok, então está bem se estivermos só a falar, certo?"

    # say L1482 pla
    old "Ok, I think I got it. I'll go there and talk to her for a moment, you wait here for a minute."
    new "B:gom: É verdade, não demora mais do que alguns segundos."

    # say L1483 pla
    old "Then you come close. And the person that you see me talking to it's who you do the spell on, ok?"
    new "B:pla: Ok, acho que percebi. Vou lá falar com ela durante um momento, tu esperas aqui um minuto."

    # say L1485 gom
    old "That's very simple, sounds good, let's do it."
    new "B:pla: Então tu aproximas-te. E a pessoa com quem me vês a falar é sobre quem vais fazer o feitiço, ok?"

    # say L1486 pla
    old "Ok, I'll there then."
    new "B:gom: Isso é muito simples, soa bem, vamos fazer isso."

    # say L1505 bel
    old "Sure, tell me. What is it?"
    new "A:rub: HA! Quem temos aqui? O Porquinho e o perdedor."

    # say L1515 rub
    old "HA! Who do we have here? Piglet and the loser."
    new "B:bel: Claro, conta-me. O que é?"

    # say L1516 rub
    old "What happened to your ears Piglet? Afraid they were talking too much attention from that flat nose?"
    new "B:rub: HA! Quem temos aqui? Porquinho e o perdedor."

    # say L1517 bel
    old "Oh for God's sake!"
    new "B:rub: O que aconteceu com as tuas orelhas, Porquinho? Com medo que estivessem a chamar demasiada atenção para aquele nariz chato?"

    # say L1518 bel
    old "Listen, dumbass, I'm not in the mood for your shit today! So fuck off!"
    new "B:bel: Ah, pelo amor de Deus!"

    # say L1524 rub
    old "And what crawled up her that she's this angry?"
    new "B:bel: Escuta, idiota, não estou com paciência para as tuas merdas hoje! Vai-te embora!"

    # say L1526 rub
    old "Honestly, you can't say anything to people because they get their panties in a bunch."
    new "B:rub: E o que é que lhe rastejou para ela estar tão zangada?"

    # say L1527 pla
    old "What are you talking about? You just insulted her!"
    new "B:rub: Honestamente, não podes dizer nada às pessoas porque elas ficam logo com as cuecas apertadas."

    # say L1528 pla
    old "Don't you ever get tired of talking like that to people?"
    new "T(pla|tu|say): Tu nunca te cansas de falar assim às pessoas?"

    # say L1529 rub
    old "What, who do you think you're talking to?"
    new "B:pla: Tu nunca te cansas de falar assim com as pessoas?"

    # say L1530 rub
    old "Listen loser, I don't care what you have to say, so why don't you get lost?"
    new "B:rub: E então, a quem é que tu pensas que estás a falar?"

    # say L1531 pla
    old "Yeah, whatever, who would want to deal with you?"
    new "B:rub: Escuta, perdedor, não me importo com o que tens a dizer, então porque não te vais embora?"

    # say L1538 pla
    old "Oh no!"
    new "B:pla: Sim, claro, quem é que quer lidar contigo?"

    # say L1539 rub
    old "Yeah! You shouldn't have messed with me you little brat!"
    new "B:pla: Oh não!"

    # say L1540 pla
    old "Wait! Wait! Stop!"
    new "B:rub: Sim! Não devias ter-te metido comigo, pestinha!"

    # say L1541 rub
    old "Stop? After you insulted me? You better be ready for what you have coming your way!"
    new "B:pla: Espera! Espera! Para!"

    # say L1542 pla
    old "No, no, no, no, it's not her, it's not her."
    new "B:rub: Pára? Depois de me teres insultado? Melhor te preparares para o que está para acontecer!"

    # say L1543 rub
    old "W- What??"
    new "B:pla: Não, não, não, não, não é ela, não é ela."

    # say L1550 pla
    old "Ooh shit!"
    new "Ooh shit! Que merda, o que faço agora? Isto não era suposto acontecer!"

    # say L1551 pla
    old "Damn, what do I do now? This wasn't supposed to happen!"
    new "B:pla: Ooh merda!"

    # say L1553 gomRub
    old "Hey, I did it! It worked! Linett is a genius!"
    new "B:pla: Merda, o que faço agora? Isto não era suposto acontecer!"

    # say L1554 pla
    old "Devonne? Is that you?"
    new "B:gomRub: Epa, consegui! Funcionou! A Linett é uma génia!"

    # say L1557 pla
    old "It was supposed to be the other girl I was talking with!"
    new "B: pla: Não, não fomos! Tu confundiste-te com a pessoa errada!"

    # say L1558 gomRub
    old "Well, you should have said something, I did what you told me to."
    new "B:pla: Era suposto ser a outra rapariga com quem tu estavas a falar!"

    # say L1559 gomRub
    old "I waited for a minute and get into the person I saw you talking with."
    new "B: gomRub: Bem, tu deves ter dito algo, fiz o que me pediste."

    # say L1561 pla
    old "Well, the point is you're in the wrong body. You're gonna have to get out of there."
    new "B: gomRub: Esperei um minuto e entrei na pessoa com quem vi que estavas a falar."

    # say L1562 gomRub
    old "Ok, but you know what's the only possible one way."
    new "B:pla: Bem, o ponto é que tu estás no corpo errado. Vais ter de sair de lá."

    # say L1563 pla
    old "Ohhh right... Oh my God... I have to do it with Ruby... Fuck!"
    new "B:gomRub: Ok, mas sabes qual é a única maneira possível."

    # say L1564 gomRub
    old "Well, it could be just a blowjob... it works too..."
    new "B:pla: Ohhh certo... Oh meu Deus... Tenho de o fazer com a Ruby... Merda!"

    # say L1565 pla
    old "I know, I know. Look, we can't do that here. So let's go somewhere else before anyone notices us speaking."
    new "B: gomRub: Bem, podia ser só uma chupada... também resulta..."

    # say L1574 oli
    old "Hey Ruby, so here this is where you've been. Hey listen, I've been thinking about our..."
    new "B:pla: Eu sei, eu sei. Olha, não podemos fazer isso aqui. Vamos a outro sítio antes que alguém nos veja a falar."

    # say L1576 oli
    old "And what do we have here? If it is the captain of the nerd club."
    new "B:oli: Ei Ruby, então é aqui que tu tens estado. Ouve, tenho estado a pensar no nosso..."

    # say L1577 oli
    old "What are you doing here nerd? Looking for better company than your loser friends"
    new "B:oli: E o que temos aqui? Se for o capitão do clube dos nerds."

    # say L1579 pla
    old "Yeah, sure... That's right, I'm trying to become friends with Ruby. Right, Ruby?"
    new "B:oli: O que estás a fazer aqui, nerd? À procura de melhor companhia do que os teus amigos perdedores?"

    # say L1586 gomRub
    old "Ohh... Yeah, that's right, he and I are very good friends heh."
    new "B:pla: Claro... É verdade, estou a tentar ser amigo da Ruby. Certo, Ruby?"

    # say L1587 pla
    old "(Oh my God...)"
    new "B: gomRub: Ohh... Yeah, isso mesmo, ele e eu somos muito bons amigos heh."

    # say L1588 oli
    old "W- what? What are you saying ruby?"
    new "B:pla: (Oh my God...)"

    # say L1589 oli
    old "Do you feel ok? Did this nerd do anything to you?"
    new "B:oli: O- o quê? O que estás a dizer, Ruby?"

    # say L1590 pla
    old "Hey, I haven't done anything."
    new "B:oli: Tu estás bem? Este nerd fez algo a ti?"

    # say L1591 pla
    old "We're just talking about homework... S- she wants me to do her homework..."
    new "B:pla: Hey, não fiz nada."

    # say L1592 oli
    old "Is that true Ruby?"
    new "B:pla: Estamos só a falar de trabalhos de casa... E- ela quer que eu faça os trabalhos dela..."

    # say L1594 gomRub
    old "Uhh, yes, yes! It's true, he's helping me with... Something."
    new "B:oli: É verdade, Ruby?"

    # say L1595 pla
    old "Anyway, I think we need to go look for some books. You know, for that homework... We better leave."
    new "B: gomRub: Uhh, sim, sim! É verdade, ele está a ajudar-me com... Algo."

    # say L1596 gomRub
    old "Yeah! I think we need to leave."
    new "B:pla: De qualquer forma, acho que precisamos ir procurar alguns livros. Sabes, para aquele trabalho de casa... Melhor irmos embora."

    # say L1601 gomRub
    old "Goodbye human friend! It was good to talk to you, I'll see you later."
    new "B: gomRub: Sim! Acho que precisamos ir embora."

    # say L1622 pla
    old "Ok, I think we'll be safe here. It's almost class time, nobody's going to come."
    new "T: Ok, acho que vamos estar seguros aqui. É quase hora de aula, ninguém vai vir."

    # say L1623 gomRub
    old "It's incredible, I have soo much control, I didn't know this was possible."
    new "T(gomRub|tu|say): É incrível, tenho tanto controlo, nem sabia que isto era possível."

    # say L1624 pla
    old "So, you're feeling ok?"
    new "É incrível, sinto-me com tanto controlo, nem sabia que isto era possível."

    # say L1625 gomRub
    old "That's right! I feel in complete control, it's almost as if this was my real body."
    new "B:pla: Então, estás a sentir-te bem?"

    # say L1626 pla
    old "Ok, that's good. At least you didn't start twitching in the middle of the hallway, that would have given us up."
    new "T(pla|tu|say): Ok, isso é bom. Pelo menos tu não começaste a tremer no meio do corredor, isso teria nos entregado."

    # say L1627 pla
    old "Which, by the way, you almost did when Olivia got there. Thank God she's not very smart."
    new "B:pla: Ok, isso é bom. Pelo menos tu não começaste a tremer no meio do corredor, isso teria nos entregado."

    # say L1628 gomRub
    old "Oh yes, who was that girl? She was friendly!"
    new "B:pla: Que, aliás, quase aconteceu quando a Olivia chegou. Graças a Deus ela não é muito esperta."

    # say L1629 pla
    old "Hmm, that's the last thing I would call her. She's the best friend of Ruby, the... Uhhh, owner of this body."
    new "B:gomRub: Oh sim, quem era aquela rapariga? Ela era simpática!"

    # say L1631 gomRub
    old "So that could have been a lot closer..."
    new "B:pla: Hmm, isso é a última coisa que eu chamaria dela. Ela é a melhor amiga da Ruby, a... Uhhh, dona deste corpo."

    # say L1632 pla
    old "Well, this is the problem with using the wrong body."
    new "B: gomRub: Podia ter sido muito mais perto..."

    # say L1633 pla
    old "But anyway, can you leave that body before someone else notices how weird you're acting?"
    new "B:pla: Bem, este é o problema de usar o corpo errado."

    # say L1635 gomRub
    old "I want to get out, but I'm going to need your help."
    new "B:pla: Mas enfim, consegues sair desse corpo antes de alguém reparar no quanto estás a agir estranhamente?"

    # say L1637 pla
    old "Yeah, right, I remember..."
    new "B: gomRub: Quero sair, mas vou precisar da tua ajuda."

    # say L1638 pla
    old "We need to do this quick."
    new "T(pla|tu|say): Precisamos fazer isto depressa."

    # say L1647 gomRub
    old "Ok, I've been waiting for this since I took over this body"
    new "B:pla: Temos de fazer isto depressa."

    # say L1649 gomRub
    old "Well, I knew we had to do this for me to leave my host's body."
    new "B: gomRub: Ok, estive à espera disto desde que tomei posse deste corpo."

    # say L1650 gomRub
    old "And I've been wanting to taste this cock for a while."
    new "B: gomRub: Bem, sabia que tínhamos de fazer isto para eu sair do corpo do meu anfitrião."

    # say L1651 pla
    old "Uh... yeah, sure, remember we can't take much time."
    new "B:gomRub: E tenho andado com vontade de provar este pénis há algum tempo."

    # say L1652 gomRub
    old "I know, I know, this will be quick."
    new "T(gomRub|tu|say): Estou bem, estou bem, isto vai ser rápido."

    # say L1662 pla
    old "Are you ok? Did everything work?"
    new "B: gomRub: Eu sei, eu sei, isto vai ser rápido."

    # say L1663 gom
    old "Oh yeah, I'm perfect, and she didn't feel anything."
    new "B:pla: Estás bem? Tudo funcionou?"

    # say L1664 pla
    old "Oh shit! That's right, if we don't clean her up, she's gonna wake up and realize what happened."
    new "B:gom: Oh yeah, sou perfeito, e ela não sentiu nada."

    # say L1665 pla
    old "Come, help me clean her up, bring her to the toilet and get out of here."
    new "B:pla: Merda! É verdade, se não a limparmos, ela vai acordar e perceber o que aconteceu."

    # say L1677 pla
    old "Ok, now let's go. We have to tell the others about how this went."
    new "B:pla: Vem, ajuda-me a limpar isto, leva-a à casa de banho e vamos embora."

    # say L1695 rub
    old "Ugh, what happened?"
    new "B:pla: Ok, agora vamos. Temos que contar aos outros como correu."

    # say L1696 rub
    old "I can't remember anything. Why am I in the school bathroom?"
    new "B:rub: Ugh, o que aconteceu?"

    # say L1697 rub
    old "Ugh, did I fall asleep in the toilet?"
    new "T(rub|tu|say): Ugh, caí no autocarro no caminho para a escola? E o que é este gosto na minha boca?"

    # say L1698 rub
    old "And what is this taste in my mouth?"
    new "B:rub: Ugh, dormi na casa de banho?"

    # say L1699 rub
    old "It's like a salty smoothie. Ughh, disgusting."
    new "B:rub: E que gosto é este na minha boca?"

    # say L1700 rub
    old "And what is that smell? It smells like... dick?"
    new "B:rub: É como um batido salgado. Ughh, nojento."

    # say L1701 rub
    old "I bet some loser was jerking off in the women's bathroom!"
    new "B:rub: E que cheiro é esse? Parece cheiro de... pénis?"

    # say L1702 rub
    old "Pathetic, I bet it was one of those losers that hangs out with Piglet."
    new "B:rub: Aposto que foi algum perdedor a se masturbar no wc das mulheres!"

    # say L1703 rub
    old "I'll give them a piece of my mind next time I see them."
    new "B:rub: Patético, aposto que foi um daqueles perdedores que anda com o Porquinho."

    # say L1737 lin
    old "Hey guys, how did it go?"
    new "A:pla: Terrível! O Gomory entrou no corpo errado, por isso não sabemos se vai funcionar com a Belle."

    # say L1738 pla
    old "Terrible! Gomory got in the wrong body, so we don't know if it's going to work with Belle."
    new "B:lin: E aí, pessoal, como foi?"

    # say L1739 lin
    old "What? What happened?"
    new "B:pla: Terrível! O Gomory entrou no corpo errado, por isso não sabemos se vai funcionar com a Belle."

    # say L1740 gom
    old "There was a confusion when I was about to perform the spell, and I accidentally jumped in the wrong person."
    new "B:lin: O quê? O que aconteceu?"

    # say L1741 gom
    old "So I ended up controlling her instead."
    new "Mas funcionou? Quero dizer, controlar esse corpo?"

    # say L1742 dev
    old "But did it work? I mean controling that body?"
    new "B:gom: Acabei por controlá-la em vez disso."

    # say L1743 gom
    old "It did! Perfectly! I had no trouble getting inside her. And once I did I had total control over her body."
    new "B:dev: Mas funcionou? Quero dizer, controlar esse corpo?"

    # say L1744 lin
    old "That's great! So we know you can do it too!"
    new "B:gom: Funcionou! Perfeitamente! Não tive problemas para entrar nela. E uma vez lá dentro, tive total controlo sobre o corpo dela."

    # say L1745 pla
    old "Yeah well, we almost got caught though."
    new "B:lin: Isso é ótimo! Então sabemos que tu também consegues!"

    # say L1746 lin
    old "Oh, I think you're making too much fuzz."
    new "B:pla: Pois, quase fomos apanhados, no entanto."

    # say L1747 lin
    old "What's important is that it can be replicated."
    new "B:lin: Oh, acho que estás a fazer demasiado alarido."

    # say L1748 pla
    old "Hmm I think so..."
    new "B:lin: O importante é que possa ser replicado."

    # say L1749 lin
    old "Ok, we can say that was a success."
    new "B:lin: Hmm, acho que sim..."

    # say L1750 lin
    old "All right, then, we should keep training the spell with Devonne and Mildret, so they get ready for her practice."
    new "B:lin: Ok, podemos dizer que foi um sucesso."

    # say L1754 lin
    old "Perfect, go do that, and I'll meet you whenever they are ready."
    new "Adeus, raparigas, boa sorte com o treino."

    # say L1756 pla
    old "Bye girls, good luck with the training."
    new "Obrigada, até mais tarde."

    # say L1775 pla
    old "This time I have an idea to ensure it's done with the right person."
    new "B:pla: Ei Linet, claro, estava a pensar no que correu mal com Devonne."

    # say L1776 lin
    old "Sure, whatever you need. Let's go."
    new "B:pla: Desta vez tenho uma ideia para garantir que seja feito com a pessoa certa."

    # say L1803 dev
    old "Hii."
    new "Olá, bom dia."

    # say L1804 gom
    old "Hi, good morning."
    new "B:dev: Olá."

    # say L1805 lin
    old "Ok, given the advances she made yesterday, I think Gomory is the one that should go with you today."
    new "B:gom: Olá, bom dia."

    # say L1806 lin
    old "I still have a couple of things to train with Mildret, but you two go ahead and practice."
    new "B:lin: Ok, tendo em conta os avanços que ela fez ontem, acho que a Gomory é a que deve ir contigo hoje."

    # say L1808 pla
    old "Yeah, sure, I'll be more careful."
    new "T(pla|tu|say): Sim, claro, vou ser mais cuidado."

    # say L1809 pla
    old "Are you ready Devonne?"
    new "B:pla: Claro, vou ter mais cuidado."

    # say L1810 dev
    old "I am."
    new "B:pla: Estás pronto, Devonne?"

    # say L1811 pla
    old "Ok, then let's go."
    new "Ok, então, tu estás certo de que estás claro sobre o processo?"

    # say L1826 pla
    old "Ok, so, are you sure you're clear on the process?"
    new "B:pla: Ok, então vamos."

    # say L1827 dev
    old "I am, I know it completely."
    new "B:pla: Ok, então, tens a certeza de que estás claro sobre o processo?"

    # say L1828 pla
    old "Ok then, come on, let's find Billie."
    new "Bem, então, vamos lá, vamos encontrar a Billie."

    # say L1842 pla
    old "Ok, we found her."
    new "T(pla|tu|say): Ok, encontrámo-la."

    # say L1843 pla
    old "Listen, to avoid confusion like what happened with Gomory."
    new "B:pla: Ok, encontrámo-la."

    # say L1844 pla
    old "I'll go and talk to her, and convince her to go with me to the classroom."
    new "B:pla: Ouve, para evitar confusões como aconteceu com Gomory."

    # say L1845 pla
    old "You wait here and when you see me going inside, you can go and get inside the body the girl who is with me at that moment."
    new "B:pla: Vou falar com ela e convencê-la a ir comigo para a sala de aula."

    # say L1846 pla
    old "Is everything clear?"
    new "B:pla: Esperas aqui e quando me vês a entrar, podes ir e entrar no corpo da rapariga que está comigo nesse momento."

    # say L1847 dev
    old "Yes, don't worry, that's very simple actually."
    new "B:pla: Está tudo claro?"

    # say L1848 pla
    old "Ok, glad to hear that, let's do it then."
    new "Olá Billie, como estás?"

    # say L1859 pla
    old "Hey Billie, how are you?"
    new "B:pla: Ok, contento por ouvir isso, vamos então."

    # say L1861 pla
    old "Not much, I just wanted to ask you something."
    new "Não muito, só queria perguntar-te uma coisa."

    # say L1862 bil
    old "Oh yeah? What is it?"
    new "A:mia: Honestamente, tu já és um aluno tão mau e ainda te dás ao luxo de faltar às aulas."

    # say L1873 mia
    old "Honestly, you're such a bad student already and you still take the luxury of skipping classes."
    new "B:bil: Oh yeah? O que é?"

    # say L1874 pla
    old "Uh, Miss Mia, I- I can explain..."
    new "A:mia: Não preciso que me expliques nada!"

    # say L1876 mia
    old "I don't need you to explain anything!"
    new "B:pla: Uh, Miss Mia, eu... eu posso explicar..."

    # say L1877 mia
    old "A bad student is a bad student. That's it, but not only do you skip classes."
    new "B:mia: Não preciso que me expliques nada!"

    # say L1878 mia
    old "You're also here being a bad influence for Billie."
    new "B:mia: Um aluno mau é um aluno mau. É só isso, mas não é só por faltar às aulas."

    # say L1879 mia
    old "I won't let you do that."
    new "B:mia: Tu também estás aqui a ser uma má influência para Billie."

    # say L1880 mia
    old "Come with me to the classroom!"
    new "B:mia: Não vou deixar-te fazer isso."

    # say L1881 pla
    old "W- Wha-?"
    new "B:mia: Vem comigo para a sala de aula!"

    # say L1882 pla
    old "B- but, I'm talking with Billie."
    new "B: pla: Q- Quê...?"

    # say L1885 pla
    old "I- it's important..."
    new "B: B- mas, estou a falar com a Billie."

    # say L1886 mia
    old "Please, what could someone like you to tell her that's important."
    new "B:pla: I- é importante..."

    # say L1887 mia
    old "Now, don't make me repeat myself again, GO TO THE CLASSROOM NOW!"
    new "B:mia: Por favor, o que alguém como tu poderia dizer que fosse importante."

    # say L1915 mia
    old "Especially someone that just arrived at the school like Miss Billie."
    new "B:mia: Ouve, não quero que contamines a mente dos outros alunos com o teu comportamento inadequado."

    # say L1916 mia
    old "So you better stay away from here."
    new "B:mia: Especialmente alguém que acabou de chegar à escola como a Miss Billie."

    # say L1923 pla
    old "No no no! Wait!"
    new "T(pla|tu|say): Não não não! Espera!"

    # say L1924 mia
    old "What did you just say to me?"
    new "A:mia: Isso significa que vais ignorar o que te disse?"

    # say L1926 mia
    old "Does that mean you're going to ignore what I told you?"
    new "B:mia: O que acabaste de me dizer?"

    # say L1928 pla
    old "No! she is not the girl!"
    new "B:mia: Isso significa que vais ignorar o que te disse?"

    # say L1929 mia
    old "DON'T THINK YOU CAN JUST DO WHAT YOU WANT!"
    new "B:pla: Não! Ela não é a rapariga!"

    # say L1935 pla
    old "Oh fuck!"
    new "B:mia: NÃO PENSES QUE PODES FAZER O QUE QUERES!"

    # say L1937 devMia
    old "Wow! That was a lot easier than I thought it would be!"
    new "B:pla: Ah, merda!"

    # say L1938 devMia
    old "The sensations... are so weird! I feel... Heavy."
    new "T(devMia|tu|say): As sensações... são tão estranhas! Sinto-me... Pesada."

    # say L1939 devMia
    old "But not in a bad way. You know?"
    new "B:devMia: As sensações... são tão estranhas! Sinto-me... Pesada."

    # say L1942 pla
    old "Yeah ok, cool."
    new "Mas não de uma maneira má. Sabes?"

    # say L1943 pla
    old "But listen, this wasn't supposed to happen."
    new "Mas ouve, isto não era suposto acontecer."

    # say L1945 devMia
    old "It wasn't?"
    new "B:pla: Mas escuta, isto não era suposto acontecer."

    # say L1946 pla
    old "No, not at all. This is not the person that's going to be your host for the ritual."
    new "B:devMia: Não era?"

    # say L1947 devMia
    old "Well, I did what you told me to. You're not very good at doing these plans you know?"
    new "B:pla: Não, de todo. Esta não é a pessoa que vai ser o teu anfitrião para o ritual."

    # say L1949 pla
    old "God, why does this keep happening to me?!"
    new "B:devMia: Bem, fiz o que me pediste. Não és muito bom a fazer estes planos, sabias?"

    # say L1950 pla
    old "Anyway, you have to get out of that body."
    new "B:pla: Meu Deus, por que isso continua a acontecer comigo?!"

    # say L1951 devMia
    old "I'll do it gladly."
    new "T(devMia|tu|say): Farei isso de bom grado."

    # say L1952 devMia
    old "But, I would need your help..."
    new "B:devMia: Farei com prazer."

    # say L1953 pla
    old "Yeah, yeah I know..."
    new "B:devMia: Mas, precisava da tua ajuda..."

    # say L1959 devMia
    old "Linett said that receiving magic feels a lot different in a human body."
    new "B:pla: Sim, sim, eu sei..."

    # say L1960 devMia
    old "Let's see if it's true."
    new "B:devMia: Linett disse que receber magia se sente muito diferente num corpo humano."

    # say L1961 pla
    old "Sure, but we better be quick."
    new "Tudo bem, mas temos de ser rápidos."

    # say L1962 devMia
    old "Yeah, yeah."
    new "T(devMia|tu|say): Sim, sim."

    # say L1963 devMia
    old "Doing it with a human body, so exciting!"
    new "T(devMia|tu|say): A fazer com um corpo humano, tão excitante!"

    # say L1964 devMia
    old "And i bet it's even going to be better with that big cock of yours."
    new "E aposto que vai ser ainda melhor com esse pau grande teu."

    # say L1965 devMia
    old "Now... let's try this."
    new "B:devMia: E aposto que vai ser ainda melhor com esse pénis grande teu."

    # say L1980 pla
    old "Now let's get out of here."
    new "Agora vamos sair daqui. Precisamos reportar à Linett e aos outros."

    # say L1981 pla
    old "We need to report back to Linett and the others."
    new "B:pla: Agora vamos embora."

    # say L1982 dev
    old "Sure, right behind you."
    new "T(dev|tu|say): Claro, vou contigo."

    # say L1999 mia
    old "Why was I on the floor?"
    new "B:dev: Claro, logo atrás de ti."

    # say L2000 mia
    old "All I can remember is that I was talking and everything went black."
    new "B:mia: Porque é que eu estava no chão?"

    # say L2001 mia
    old "Ugh! Who was I talking with?"
    new "B:mia: Tudo o que me lembro é que estava a falar e tudo ficou preto."

    # say L2033 lin
    old "Did you manage to do it right this time?"
    new "B:lin: E aí, pessoal! Como foi?"

    # say L2034 pla
    old "Hmm, not exactly."
    new "B:lin: Conseguiste fazer direito desta vez?"

    # say L2035 lin
    old "What do you mean, the spell didn't work?"
    new "O que queres dizer, o feitiço não funcionou?"

    # say L2036 dev
    old "Oh, not that, it worked perfectly."
    new "T(dev|tu|say): Oh, não foi isso, funcionou perfeitamente. É só que ela não entrou no corpo certo."

    # say L2037 pla
    old "It's just that she didn't go into the right body."
    new "B:dev: Oh, não, funcionou perfeitamente."

    # say L2040 pla
    old "Yeah, sure."
    new "T(pla|tu|say): Sim, claro."

    # say L2042 lin
    old "But other than that, how did it go? How did you feel?"
    new "Foi incrível! Tu tinhas dito que funcionava, mas isto foi inesperado."

    # say L2044 dev
    old "It was amazing! You had told me it worked, but this was unexpected."
    new "T(dev|tu|say): Foi incrível! Tu tinhas dito que funcionava, mas isto foi inesperado."

    # say L2045 dev
    old "Human bodies feel so different!"
    new "B:dev: Foi incrível! Tu tinhas dito que funcionava, mas isto foi inesperado."

    # say L2046 lin
    old "Well, if everything goes well, you'll have a chance soon."
    new "B:dev: Os corpos humanos são tão diferentes!"

    # say L2050 pla
    old "Sure, then I'll see you later."
    new "B:lin: E eu entrarei em contacto contigo quando for hora da próxima sessão de treino."

    # say L2068 lin
    old "Ok, let's go see the girls then..."
    new "B:pla: Bom dia, Linett; claro, estou pronto para isso."

    # say L2096 dev
    old "Hii, we're fine, how are you?"
    new "B:lin: Ok, vamos ver as raparigas então..."

    # say L2097 pla
    old "I'm ok, thanks."
    new "Hoje é o último dia de treino."

    # say L2098 lin
    old "Today is the last practice day."
    new "B:pla: Estou bem, obrigado."

    # say L2100 lin
    old "So take her with you to where her host is and try it."
    new "Tudo bem, sem problemas, estás pronta Mildret?"

    # say L2102 pla
    old "Sure, no problem, are you ready Mildret?"
    new "B:lin: Então leva-a contigo até onde está o seu anfitrião e tenta."

    # say L2104 lin
    old "Great, do ahead and let me know how everything goes."
    new "B:pla: Claro, sem problemas, estás pronta, Mildret?"

    # say L2117 pla
    old "Ok, so the last two previous attempts have failed because of confusion and bad timing."
    new "B:lin: Ótimo, avança e mantém-me a par de tudo."

    # say L2118 pla
    old "So this time, I brought a picture with me."
    new "B:pla: Ok, então as duas tentativas anteriores falharam devido à confusão e más escolhas de timing."

    # say L2122 pla
    old "This is the person that you're gonna get inside."
    new "B:pla: Desta vez, trouxe uma fotografia comigo."

    # say L2123 pla
    old "Make sure you memorize her face, so this time won't happen as before."
    new "B:pla: Esta é a pessoa com quem vais entrar."

    # say L2128 mil
    old "Ok, I'll make sure to remember this face, where can we find her?"
    new "B:pla: Certifica-te de que memorizas o rosto dela, para que isto não aconteça como da outra vez."

    # say L2129 pla
    old "She should be at her house, let's go."
    new "B:mil: Ok, vou-me certificar de me lembrar desta cara, onde a podemos encontrar?"

    # say L2143 jad
    old "Are you here looking for Hinn?"
    new "B:pla: Estou bem, Sra. Jade, obrigado."

    # say L2144 pla
    old "I am, I have to talk to her about our school project."
    new "B:jad: Estás aqui à procura da Hinn?"

    # say L2145 jad
    old "Oh, but you see, she's not in at the moment."
    new "B:pla: Tenho de falar com ela sobre o nosso projeto escolar."

    # say L2146 jad
    old "I think she went out with your friend Belle."
    new "B:jad: Oh, mas vês, ela não está em casa neste momento."

    # say L2147 jad
    old "If you want to, you can come back later when she arrives."
    new "B:jad: Acho que ela saiu com a tua amiga Belle."

    # say L2148 pla
    old "I guess I'll have to..."
    new "B:jad: Se quiseres, podes voltar mais tarde quando ela chegar."

    # say L2162 pla
    old "Nooo, not again! Damn it!"
    new "B:pla: Acho que vou ter que..."

    # say L2163 milJad
    old "It worked! I can't believe Linett was right."
    new "B:pla: Não, de novo! Merda!"

    # say L2164 pla
    old "Hmph, yeah fine, that's very good and all. But you're in the wrong body!"
    new "T(pla|tu|say): Hmph, sim, tudo bem, isso é ótimo e tal. Mas tu estás no corpo errado!"

    # say L2165 milJad
    old "But I got in the body you told me to, I even had the picture and all."
    new "B:pla: Hmph, sim, tudo bem, isso é ótimo e tal. Mas tu estás no corpo errado!"

    # say L2166 pla
    old "Well, that's not her. The body you got into it's her mother."
    new "B:milJad: Mas entrei no corpo que me disseste, até tinha a foto e tudo."

    # say L2167 milJad
    old "Well that's not my fault, they look identical!"
    new "B:pla: Bem, essa não é ela. O corpo em que entraste é da mãe dela."

    # say L2168 milJad
    old "I mean, all you humans are very similar to begin with, how was I supposed to know which is which?"
    new "B:milJad: Bem, isso não é culpa minha, eles parecem idênticos!"

    # say L2169 pla
    old "I can't believe this is happening again."
    new "B:milJad: Quero dizer, todos vocês os humanos são muito parecidos, como é que eu ia saber quem era quem?"

    # say L2170 pla
    old "Well anyway, let's get you out of that body quickly, I don't know when Hinn could come back home."
    new "B:pla: Não posso acreditar que isto esteja a acontecer de novo."

    # say L2172 milJad
    old "Sure, we already tested that I can do the spell, and it works how intended, let's not delay this any longer."
    new "B:pla: Bem, de qualquer maneira, vamos tirar-te desse corpo depressa, não sei quando Hinn pode voltar a casa."

    # say L2177 pla
    old "Uhh, A- Are you ok?"
    new "B: milJad: Claro, já testámos que posso fazer o feitiço e funciona como pretendido, não vamos adiar isto mais."

    # say L2178 pla
    old "You seem a little weird."
    new "B:pla: Uhh, A- Estás bem?"

    # say L2179 milJad
    old "Me? Weird? Don't be foolish."
    new "T(milJad|tu|dizes): Eu? Estranho? Não sejas tolo."

    # say L2180 milJad
    old "We do this often, why would I be weird about receiving magic in a human body?"
    new "B:milJad: Eu? Estranho? Não sejas tolo."

    # say L2182 pla
    old "Eh, well... I didn't say anything about that."
    new "B:milJad: Fazemos isso com frequência, por que eu seria estranho em receber magia num corpo humano?"

    # say L2183 pla
    old "But sure."
    new "B:pla: Eh, bem... eu não disse nada sobre isso."

    # say L2184 milJad
    old "You're talking too much."
    new "T(milJad|tu|say): Estás a falar demasiado."

    # say L2185 milJad
    old "Remember we can't waste any time on this."
    new "B:milJad: Estás a falar demasiado."

    # say L2186 milJad
    old "Or the daughter of this body could come back and see us."
    new "B:milJad: Lembra-te que não podemos perder tempo com isto."

    # say L2187 pla
    old "You're right."
    new "B: milJad: Ou a filha deste corpo poderia voltar e nos ver."

    # say L2200 pla
    old "Ok, we are done here, let's go."
    new "B:pla: Tens razão."

    # say L2218 jad
    old "How did I fall asleep?"
    new "B:pla: Ok, já acabámos aqui, vamos embora."

    # say L2219 jad
    old "I can't even remember what I was doing..."
    new "B:jad: Como é que adormeci?"

    # say L2220 jad
    old "All I remember is I was talking to someone and then nothing."
    new "T(jad|tu|diz): Só me lembro de estar a falar com alguém e depois nada."

    # say L2221 jad
    old "Who was I talking to?"
    new "B:jad: A única coisa que me lembro é que estava a falar com alguém e depois nada."

    # say L2254 lin
    old "Well? How did it go? Did you manage to do it?"
    new "B:jad: Com quem é que eu estava a falar?"

    # say L2255 pla
    old "You could say that..."
    new "B:lin: Então? Como correu? Conseguiste fazer?"

    # say L2256 pla
    old "But... you see, something happened."
    new "B:pla: Podes dizer isso..."

    # say L2257 pla
    old "And Mildret ended up in the wrong body again."
    new "B:pla: Mas... viste, aconteceu algo."

    # say L2259 lin
    old "Amazing, you officially suck at this."
    new "T(lin|tu|say): Incrível, tu oficialmente és péssimo nisto."

    # say L2260 pla
    old "Hey! Those were accidents, it wasn't my fault."
    new "B:lin: Incrível, tu oficialmente não sabes fazer isto."

    # say L2265 lin
    old "Was it too difficult?"
    new "B:lin: Quero saber como te sentiste, Mildret. O que achaste do feitiço?"

    # say L2266 mil
    old "No, no, no, the opposite actually, it was very easy."
    new "B:lin: Foi muito difícil?"

    # say L2267 mil
    old "I must say I'm amazed at how good your spell is. The connection to the body is complete."
    new "B:mil: Não, não, não, pelo contrário, foi muito fácil."

    # say L2269 dev
    old "Oh, it feels delicious, doesn't it?"
    new "B:mil: Tenho de dizer que estou impressionado com a qualidade do teu feitiço. A ligação ao corpo está completa."

    # say L2270 mil
    old "Hmph, I wouldn't say that."
    new "B:dev: Oh, sente-se delicioso, não é?"

    # say L2271 mil
    old "But it is true that the sensory experience is... Interesting."
    new "B:mil: Hmph, não diria isso."

    # say L2272 lin
    old "Well, what's important is that now all of you have gotten to test the spell and see that it works."
    new "B:mil: Mas é verdade que a experiência sensorial é... Interessante."

    # say L2273 lin
    old "That will make things easier to handle the day of the ritual."
    new "B:lin: O importante é que agora todos vocês tiveram a oportunidade de testar o feitiço e ver que funciona."

    # say L2274 lin
    old "That makes me feel sure that there won't be any problem the day of the ritual."
    new "T(lin|tu|say): Isso deixa-me mais confiante de que não haverá problemas no dia do ritual."

    # say L2275 lin
    old "But we're not done. Now that you know how to control bodies, we have to work on directing magic power."
    new "B:lin: Isso deixa-me certo de que não haverá problemas no dia do ritual."

    # say L2276 pla
    old "Hey, does that mean that my work here is done?"
    new "B:lin: Mas ainda não acabámos. Agora que sabes como controlar corpos, temos de trabalhar na direção da energia mágica."

    # say L2277 lin
    old "It is, now we need you to focus on securing both the church and making sure the hosts are ready for the day of the ritual."
    new "T(lin|tu|say): Está, agora precisamos que te concentres em garantir a segurança da igreja e certificar-te de que os convidados estão prontos para o dia do ritual."

    # say L2278 lin
    old "Make sure everything's in place for that day."
    new "T(lin|tu|say): Certifica-te de que tudo está no sítio para esse dia."

    # say L2279 pla
    old "Sure, no problem, I'll go then."
    new "B:lin: Certifica-te de que tudo está preparado para esse dia."

    # say L2302 jon
    old "Oh darling! I knew you'd do it."
    new "B:pla: Claro, sem problemas, vou então."

    # say L2303 gra
    old "Just look at how beautiful the church looks! What a miracle!"
    new "B:jon: Oh querida! Eu sabia que tu ias conseguir."

    # say L2304 pla
    old "Thank you, I'm glad you like it."
    new "B:gra: Olha só que linda a igreja! Que milagre!"

    # say L2305 jon
    old "Oh darling, we don't like it, we love it!"
    new "B:pla: Obrigado, fico contente que gostes."

    # say L2306 jon
    old "Who knows how much time it would've taken Sister Grace and I to finish it by ourselves."
    new "B:jon: Oh querida, não gostamos, amamos!"

    # say L2307 gra
    old "That's right. You made it possible for this to be ready."
    new "B:jon: Quem sabe quanto tempo teria levado para a Irmã Grace e eu terminarmos sozinhos."

    # say L2308 jon
    old "Well darling, I'm sure you must be very busy."
    new "B:gra: É verdade. Foste tu que tornaste isto possível."

    # say L2309 jon
    old "And I'm sure you don't want to spend even one more hour of your time here."
    new "B:jon: Bem querida, tenho a certeza de que deves estar muito ocupada."

    # say L2311 pla
    old "Actually, I wanted to ask you something."
    new "B:jon: E tenho a certeza de que não queres passar nem mais uma hora do teu tempo aqui."

    # say L2313 gra
    old "What would you like to know?"
    new "B:pla: Na verdade, queria perguntar-te uma coisa."

    # say L2314 pla
    old "Well, the thing is that I'm doing this... Hmm, religious thing with a couple of my friends from school."
    new "B:gra: O que gostavas de saber?"

    # say L2315 pla
    old "And I would like to know if I can use the church one of these days to have a little ritual."
    new "B:pla: Bem, a questão é que estou fazendo essa... Hmm, coisa religiosa com alguns amigos da escola."

    # say L2317 jon
    old "Ritual?"
    new "B:pla: E gostaria de saber se posso usar a igreja num destes dias para fazer um pequeno ritual."

    # say L2318 pla
    old "Nothing bad."
    new "B:jon: Ritual?"

    # say L2319 pla
    old "Just something like what happened last time, you know, to bring them to the lord."
    new "B: pla: Nada de mal."

    # say L2321 gra
    old "Oh my god! That sounds wonderful!"
    new "B:pla: Apenas algo como o que aconteceu da última vez, sabes, para os levar ao Senhor."

    # say L2322 jon
    old "I agree. It's so inspiring to see young people acting in such a way, looking for a connection with the lord. Simply great!"
    new "B:gra: Oh meu Deus! Isso soa maravilhoso!"

    # say L2325 pla
    old "You see, you've already been blessed, the idea is to bring in new people, to receive the blessing."
    new "B:pla: Uhh, acho que não."

    # say L2327 gra
    old "Oh, really? I must say that's a little disappointing."
    new "B:pla: Vês, tu já foste abençoado, a ideia é trazer novas pessoas para receberem a bênção."

    # say L2331 pla
    old "It's great that you understand."
    new "B:jon: Temos de permitir que outras pessoas recebam esta bênção especial e sejam integradas na comunidade."

    # say L2332 pla
    old "So, I think we'll need the church for some days, so that the ritual can be properly done."
    new "B:pla: É ótimo que tu entendas."

    # say L2333 pla
    old "I would love it if nobody came here, just so that we're not interrupted."
    new "B:pla: Então, acho que vamos precisar da igreja durante alguns dias, para que o ritual seja feito corretamente."

    # say L2335 jon
    old "Oh sure, no problem. We'll see to that, right Sister Grace?"
    new "B:pla: Adorava que ninguém viesse aqui, só para não sermos interrompidos."

    # say L2336 gra
    old "There will be no issue."
    new "B:jon: Oh, claro, sem problemas. Vamos tratar disso, certo, Irmã Grace?"

    # say L2337 gra
    old "We trust you completely, so we'll do as you ask us."
    new "B:gra: Não haverá problema."

    # say L2338 pla
    old "Thank you very much! You're of great help."
    new "B:gra: Confiamos em ti completamente, por isso faremos o que pedires."

    # say L2339 jon
    old "Not at all darling, you're the one who is of great help, bringing people over to the community. What a good young man."
    new "B:pla: Muito obrigado! És de grande ajuda."

    # say L2340 gra
    old "It's true, you are a true blessing from the lord."
    new "B:jon: Nem um pouco, querida, és tu quem é de grande ajuda, a trazer pessoas para a comunidade. Que bom rapaz."

    # say L2341 pla
    old "Thank you, very much for saying that."
    new "B:gra: É verdade, tu és uma bênção do Senhor."

    # say L2342 pla
    old "I think I better get going then."
    new "B:pla: Obrigado, muito obrigado por dizer isso."

    # say L2363 pla
    old "Oh, hi, what's up?"
    new "B:gra: Sim, muito obrigado, Deus te abençoe."

    # say L2364 lin
    old "Nothing much, I just wanted to let you know that I talked to the girls."
    new "B:pla: Olá, tudo bem, o que foi?"

    # say L2365 lin
    old "And I'm very happy with the results of the training, they're now ready to do the ritual."
    new "B:lin: Não muito, só queria te dizer que falei com as meninas."

    # say L2367 lin
    old "It is, that's why I wanted to ask you, how are things going with the church?"
    new "B:lin: E estou muito feliz com os resultados do treino, eles estão prontos para fazer o ritual."

    # say L2368 pla
    old "It's great, I asked them to let me use it, and they said it was ok, so we're all set."
    new "É ótimo, perguntei a eles para me deixar usar e disseram que estava tudo bem, então estamos prontos. Fantástico, e como estão as coisas com os três humanos de que precisamos? Já os convenceste?"

    # say L2369 lin
    old "Fantastic, and how are things going with the three humans we need? Did you convince them already?"
    new "T(lin|tu|say): Fantástico, e como estão as coisas com os três humanos de que precisamos? Já os convenceste?"

    # say L2371 pla
    old "Uhh, not really, but I think I can convince them of it pretty soon."
    new "T(pla|tu|say): Hmm, não realmente, mas acho que consigo convencê-los em breve."

    # say L2372 lin
    old "Please do it and remember, they won't notice the ritual at all, so you don't need to worry."
    new "B:pla: Uhh, não realmente, mas acho que consigo convencê-los em breve."

    # say L2373 pla
    old "Ok, I'll keep that in mind. And will talk to them as soon as I can."
    new "B:lin: Faz isso e lembra-te, eles não vão reparar no ritual, por isso não precisas de te preocupar."

    # say L2375 lin
    old "I'll leave it in your hands then."
    new "Hmm, o dia do ritual está a chegar. Melhor falar com as raparigas logo."

    # say L2384 pla
    old "Hmm, the day for the ritual is coming. I better hurry up and talk to the girls soon."
    new "B:lin: Deixo então nas tuas mãos."

    # say L2400 bel
    old "Hi [pla]! It's good to see you."
    new "Olá [pla]! É bom ver-te."

    # say L2401 bel
    old "Hey, listen, I'm glad we can talk. I wanted to tell you something."
    new "T(bel|tu|say): Oi, escuta, fico contente que possamos conversar. Queria dizer-te uma coisa."

    # say L2402 pla
    old "Sure, is everything ok?"
    new "T(pla|tu|say): Claro, tudo bem?"

    # say L2403 bel
    old "Yeah, yeah, everything's fine, it's nothing bad."
    new "T(bel|tu|say): Sim, sim, tudo bem, não é nada de mais."

    # say L2405 pla
    old "Oh, ok, what is it then?"
    new "B:bel: Sim, sim, tudo bem, não é nada de mais."

    # say L2407 bel
    old "Well, it's about what happened the other day with that dumbass bimbo."
    new "B:pla: Oh, ok, então o que é?"

    # say L2408 bel
    old "She made me angry and I took off and left you alone with her. So I wanted to say sorry."
    new "B:bel: Bem, é sobre o que aconteceu aquele dia com aquela bimba estúpida."

    # say L2410 pla
    old "That's all? Don't worry about it. I understand how irritating her comments can be."
    new "B:bel: Ela deixou-me zangado e fui embora, deixando-te sozinho com ela. Queria pedir desculpa."

    # say L2411 bel
    old "They really are and she just makes me so mad."
    new "A:bel: Espero que nada de mal tenha acontecido com ela quando parti."

    # say L2412 bel
    old "I hope nothing bad happened with her when I left."
    new "B:bel: Eles realmente são e ela só me deixa tão irritada."

    # say L2413 pla
    old "Bad? Haha, no, of course not, what could happen between us? Nothing happened at all."
    new "B:bel: Espero que nada de mal tenha acontecido com ela quando parti."

    # say L2414 bel
    old "Hmm, Okay..."
    new "B:pla: Mal? Haha, não, claro que não, o que poderia acontecer entre nós? Nada aconteceu de todo."

    # say L2415 pla
    old "Well anyway, leaving that aside, there's something that I wanted to talk to you about."
    new "B:bel: Hmm, Okay..."

    # say L2419 pla
    old "Well, these past few days I've been helping decorate the church, for the holidays and stuff."
    new "B:pla: Bem, deixando isso de lado, há algo de que queria falar contigo."

    # say L2420 pla
    old "And the church actually looks really cool."
    new "B:pla: Bem, estes últimos dias tenho estado a ajudar a decorar a igreja, para as festas e tal."

    # say L2421 pla
    old "And it came to me that since we have some free time, why don't we have a little christmas celebration?"
    new "E ocorreu-me que, como temos algum tempo livre, por que não fazemos uma pequena celebração de Natal? Achei que podia ser realmente fixe se jogássemos verdade ou desafio como da última vez."

    # say L2422 pla
    old "I thought it could be really cool if we played truth or dare like last time."
    new "B:pla: E ocorreu-me que, como temos algum tempo livre, por que não fazemos uma pequena celebração de Natal?"

    # say L2423 pla
    old "With me, Billie and Hinn by the way."
    new "B:pla: Achei que podia ser mesmo fixe se jogássemos verdade ou desafio como da última vez."

    # say L2424 pla
    old "Not Mike, I know he can be a little annoying."
    new "B:pla: Comigo, Billie e Hinn, por acaso."

    # say L2425 bel
    old "Hmm, that sounds like fun. And I do like that Mike won't be there..."
    new "B:pla: Não o Mike, sei que ele pode ser um pouco irritante."

    # say L2426 pla
    old "Oh, by the way, I think it would be cool if we dressed up for christmas."
    new "B:bel: Hmm, isso parece divertido. E gosto que o Mike não vai estar..."

    # say L2428 bel
    old "That's actually nice."
    new "B:pla: Oh, a propósito, acho que seria fixe se nos vestíssemos a rigor para o Natal."

    # say L2429 bel
    old "Sure, why not? Count me in."
    new "B:bel: Isso é na verdade bom."

    # say L2430 pla
    old "That's great Belle! So, how about we tomorrow night on the beach? Same spot as last time."
    new "B:bel: Claro, porquê não? Conta comigo."

    # say L2431 pla
    old "And from there we can go to the church."
    new "B:pla: Ótimo, Belle! Então, que tal amanhã à noite na praia? No mesmo lugar que da última vez."

    # say L2451 pla
    old "Hey Billie, how are you doing?"
    new "B:pla: E daí podemos ir à igreja."

    # say L2452 bil
    old "Hey dude, what's up?"
    new "A:pla: Olá, queria falar contigo sobre uma coisa."

    # say L2453 pla
    old "Hey, I wanted to talk to you about something."
    new "A:bil: Claro, é a mesma coisa que querias dizer-me quando a Miss Mia te arrastou embora na outra vez?"

    # say L2454 bil
    old "Sure, is it the same thing you wanted to say to me when Miss Mia dragged you away the other day?"
    new "B:pla: Olá, queria falar contigo sobre uma coisa."

    # say L2455 pla
    old "Oh, yeah, actually it is. But thanks for reminding me that Miss Mia hates me."
    new "T(pla|tu|say): Oh, yeah, na verdade é isso mesmo. Mas obrigado por me lembrar que a Miss Mia me odeia."

    # say L2456 bil
    old "Hahahaha, dude, she really does. I don't know what you did to get on her bad side. But she has it in for you."
    new "B:pla: Oh, yeah, na verdade é. Mas obrigado por me lembrar que a Miss Mia me odeia."

    # say L2457 pla
    old "She does, she really does."
    new "B:bil: Hahahaha, meu, ela realmente faz. Não sei o que fizeste para ela te achar mal. Mas ela tem-te no olho."

    # say L2458 pla
    old "But anyway, that's not what I wanted to say."
    new "B:pla: Ela faz, ela realmente faz."

    # say L2459 pla
    old "Listen, I've been thinking, and that game of truth or dare was actually pretty fun."
    new "Ouça, tenho pensado e aquele jogo de verdade ou desafio foi na realidade bastante divertido. Então, como vamos ter algum tempo livre em breve, pensei que podíamos jogar outra rodada."

    # say L2460 pla
    old "So I thought that since we're gonna have some free time soon. Maybe we could go for another round."
    new "B:pla: Ouve, tenho andado a pensar, e aquele jogo de verdade ou desafio foi na realidade bastante divertido."

    # say L2461 bil
    old "Oh, I wasn't expecting you to say that."
    new "B:pla: Então pensei que, como vamos ter algum tempo livre em breve, talvez pudéssemos fazer mais uma rodada."

    # say L2462 bil
    old "I mean, sure, it could be fun, but I don't know."
    new "B:bil: Oh, não estava à espera que disseses isso."

    # say L2463 bil
    old "Sounds a little boring now."
    new "B:bil: Quero dizer, claro, pode ser divertido, mas não sei."

    # say L2465 pla
    old "Oh, come on. Let's do it. Besides, I've been helping your grandma decorate the church."
    new "T: Oh, vamos lá. Vamos fazer isso. Além disso, tenho ajudado a tua avó a decorar a igreja."

    # say L2467 bil
    old "Yeah, she mentioned it."
    new "T(bil|tu|say): Sim, ela mencionou."

    # say L2468 pla
    old "Yeah and it actually looks great, so it came to my mind that we could have a little celebration there."
    new "T: E até podíamos vestir-nos a rigor."

    # say L2469 pla
    old "And we can even wear holiday outfits."
    new "B:pla: E até que ficou ótimo, então me veio à mente que poderíamos fazer uma pequena celebração lá."

    # say L2471 bil
    old "When you say that we celebrate there."
    new "B:pla: E podemos até usar trajes de férias."

    # say L2472 bil
    old "I hope that doesn't means my grandma and the nun will be there. Right?"
    new "B:bil: Quando dizes que celebramos lá."

    # say L2473 pla
    old "No, not at all."
    new "T: Não, de todo. Falei com elas e conseguiram emprestar-me o lugar para a noite. Portanto, só vamos ser nós."

    # say L2474 pla
    old "I talked to them and I got them to lend me the place for the night. So it will just be us."
    new "B:pla: Não, nada disso."

    # say L2476 bil
    old "Even with that, it doesn't sound like the coolest thing."
    new "B:pla: Falei com eles e conseguiram emprestar-me o lugar para a noite. Portanto, será só nós."

    # say L2477 pla
    old "It will be cool. And you kind of owe for what happened last time."
    new "T: Vai ser fixe. E tu deves-me uma por causa do que aconteceu da última vez."

    # say L2478 pla
    old "Remember whose idea it was that I climbed that roof?"
    new "B:pla: Vai ser fixe. E tu deves-me uma por causa do que aconteceu da última vez."

    # say L2479 bil
    old "Ugh, dude, come on! Don't bring that up now, lame."
    new "B:pla: Lembra-te de quem foi a ideia de eu subir aquele telhado?"

    # say L2481 bil
    old "But it's true, I do owe you. And what the hell, it could be fun."
    new "B:bil: Ugh, pá, pá! Não trazes isso à tona agora, lame."

    # say L2482 bil
    old "But no Mike, ok? He's annoying."
    new "B:bil: Mas é verdade, eu devo-te. E que se lixe, pode ser divertido."

    # say L2483 pla
    old "Thanks Billie! I'm sure we'll have a great time. Ok, so tomorrow night at the beach? We can go from there."
    new "B:bil: Mas não o Mike, ok? Ele é chato."

    # say L2484 bil
    old "Yeah, whatever."
    new "B:pla: Obrigado, Billie! Tenho a certeza que vamos divertir-nos. Ok, então amanhã à noite na praia? Podemos ir daí."

    # say L2486 pla
    old "Alright, see you tomorrow then."
    new "B:bil: Sim, claro."

    # say L2516 pla
    old "Don't worry, it happens."
    new "Não te preocupes, acontece."

    # say L2517 hin
    old "Yeah, by the way, my mom wanted me to ask you if you remember anything strange happening."
    new "B:pla: Não te preocupes, acontece."

    # say L2518 pla
    old "Strange? Heh, Me? N- no, no, why?"
    new "T(pla|tu|say): Estranho? Heh, eu? N-não, não, porquê?"

    # say L2519 hin
    old "Well, she says that she remembers talking to you, but then she just woke up, apparently she fell asleep without knowing."
    new "B:pla: Estranho? Heh, eu? N-não, não, porquê?"

    # say L2520 hin
    old "So she wanted me to ask you if you know anything about that."
    new "B:hin: Bem, ela diz que se lembra de ter falado contigo, mas depois acordou, aparentemente adormeceu sem saber."

    # say L2521 pla
    old "Hmm, not really, after she told me you weren't there I just left."
    new "B:hin: Então ela queria que eu perguntasse se tu sabes alguma coisa sobre isso."

    # say L2522 pla
    old "Maybe she was tired and doesn't remember falling asleep."
    new "B:pla: Hmm, não realmente, depois de ela me dizer que tu não estavas lá, eu só fui embora."

    # say L2523 hin
    old "Yeah, that's what I told her."
    new "T(hin|tu|diz): Sim, foi isso que eu disse a ela."

    # say L2524 hin
    old "But anyway, what did you want to talk to me about?"
    new "A:pla: Ah, certo, esqueci-me."

    # say L2526 pla
    old "Oh right, I forgot."
    new "B:hin: Mas enfim, do que é que querias falar comigo?"

    # say L2527 pla
    old "Well, you see. I've been thinking that maybe we could get together with Billie and Belle."
    new "B:pla: Ah, é verdade, esqueci-me."

    # say L2528 pla
    old "And play another round of truth or dare with them. It was very fun last time and maybe it would be good to do it again."
    new "B:pla: Bem, tu vês. Tenho estado a pensar que talvez pudéssemos juntar-nos com a Billie e a Belle."

    # say L2529 pla
    old "Especially since we have some free time coming up."
    new "B:pla: E jogar mais uma rodada de verdade ou desafio com eles. Foi muito divertido da última vez e talvez seja bom fazer de novo."

    # say L2534 pla
    old "I mean, you can practice a bit and of course stay with me and your friends in a safe place."
    new "B:pla: Eu sei, eu sei. Mas é por isso que te proponho, acho que poderia ser muito útil para a tua ansiedade."

    # say L2536 hin
    old "You know what? You might be right. And I think I could also use the experience to deal with my anxiety."
    new "B:pla: Quero dizer, podes praticar um pouco e claro, ficar comigo e os teus amigos num lugar seguro."

    # say L2537 hin
    old "I- I'll do it."
    new "B:hin: Sabes o quê? Podes ter razão. E acho que também poderia usar esta experiência para lidar com a minha ansiedade."

    # say L2539 pla
    old "That's cool Hinn. I'm sure we'll have a good time."
    new "B:hin: I- Vou fazer."

    # say L2540 pla
    old "Oh, and I was thinking, maybe we could take the chance and dress up christmas themed, what do you think?."
    new "B:pla: Isso é fixe, Hinn. Tenho a certeza que nos vamos divertir."

    # say L2541 pla
    old "You know, because it's the holidays."
    new "B:pla: E, estava a pensar, talvez possamos aproveitar e vestir-nos com temas de Natal, o que achas?"

    # say L2542 hin
    old "That sounds great! Count me in."
    new "A:pla: Estava a pensar que podíamos encontrar-nos na praia amanhã à noite."

    # say L2543 pla
    old "I was thinking that we could meet at the beach tomorrow night."
    new "T: Estava a pensar que podíamos encontrar-nos na praia amanhã à noite."

    # say L2544 hin
    old "That sounds ok."
    new "B:pla: Estava a pensar que podíamos encontrar-nos na praia amanhã à noite."

    # say L2545 pla
    old "See you later then."
    new "Tchau, então."

    # say L2546 hin
    old "Sure, goodbye."
    new "Olá, estavas à espera de mim?"

    # say L2569 pla
    old "Hi, you were waiting for me?"
    new "Oi, estavas à espera de mim?"

    # say L2570 lin
    old "I was, I wanted to tell the other three shinigami are ready for the ritual."
    new "T(lin|tu|say): Estava, queria dizer que os outros três shinigami já estão prontos para o ritual."

    # say L2571 pla
    old "I already spoke with my friends, they all said yes."
    new "B:lin: Eu estava, queria dizer que os outros três shinigami estão prontos para o ritual."

    # say L2572 lin
    old "That's perfect! Ok, so we're all set now."
    new "B:pla: Já falei com os meus amigos, todos disseram que sim."

    # say L2573 lin
    old "Get ready, we'll have a lot of work to do tomorrow. Be sure you get enough rest."
    new "T(lin|tu|say): Prepara-te, vamos ter muito trabalho amanhã. Certifica-te de que descansas o suficiente."

    # say L2574 pla
    old "I'll make sure to get enough rest."
    new "B:lin: Prepara-te, vamos ter muito trabalho amanhã. Certifica-te de que descansas o suficiente."

    # say L2575 lin
    old "Ok then, I'll see you tomorrow."
    new "B:pla: Vou garantir que descanse o suficiente."

    # say L2593 pla
    old "Hey Linett, good morning."
    new "B:lin: Ok then, I'll see you tomorrow."

    # say L2594 lin
    old "Are you ready for today?"
    new "B:pla: Olá Linett, bom dia."

    # say L2595 pla
    old "Yeah sure, I'm ready."
    new "B:lin: Estás pronto para hoje?"

    # say L2596 lin
    old "Ok then, so let's go talk to the others."
    new "B:pla: Claro, estou pronto."

    # say L2629 lin
    old "Good morning, I hope you're all ready for the ritual today."
    new "B:lin: Então, vamos falar com os outros."

    # say L2630 gom
    old "Hello, yes, we are. We've been practicing so we're confident it's going to go well."
    new "B:lin: Bom dia, espero que estejam prontos para o ritual de hoje."

    # say L2631 mil
    old "Hello, I agree."
    new "B: gom: Olá, sim, estamos. Temos estado a praticar, por isso temos a certeza de que vai correr bem."

    # say L2636 dev
    old "That's great."
    new "É ótimo. A ideia é que vamos à igreja e esperamos lá."

    # say L2637 lin
    old "It is. The idea is that we'll go to the church and wait there."
    new "B:dev: Isso é ótimo."

    # say L2640 gom
    old "How will we know who's getting inside who?"
    new "B:lin: Quando chegarem à igreja, eles virão e tu entras neles."

    # say L2641 pla
    old "I was thinking about that, but honestly it doesn't really makes much of a difference."
    new "B:gom: Como saberemos quem entra em quem?"

    # say L2642 lin
    old "It would if you had run the practice with your actual hosts. But since you didn't, you can just get inside anybody."
    new "B:pla: Estava a pensar nisso, mas honestamente não faz muita diferença."

    # say L2644 mil
    old "Ok, It sounds fairly easy."
    new "B:lin: Seria se tivesses feito a prática com os teus anfitriões reais. Mas como não fizeste, podes entrar em qualquer pessoa."

    # say L2645 lin
    old "It will be, after you get them we can start the ritual."
    new "B:mil: Ok, parece bastante fácil."

    # say L2646 lin
    old "So while you channel magic power, I'll handle the union of all three sources into the breach point."
    new "B:lin: Será, depois de os obtermos podemos iniciar o ritual."

    # say L2647 lin
    old "If everything goes well, we should be able to create a magic generator point."
    new "B:lin: Enquanto tu canalizas o poder mágico, eu vou lidar com a união das três fontes no ponto de ruptura."

    # narrator L2654 
    old "Several hours later..."
    new "B:pla: Ok, até logo."

    # say L2669 pla
    old "Hey girls! Wow... You look stunning!"
    new "T(pla|tu|say): Olá raparigas! Uau... Vocês estão deslumbrantes!"

    # say L2670 hin
    old "Y- You think so?"
    new "B:pla: Olá, meninas! Uau... Vocês estão deslumbrantes!"

    # say L2671 pla
    old "I do. For starters, you look great as a reindeer."
    new "B:hin: E-Estás a falar a sério?"

    # say L2672 pla
    old "And you Belle, that santa claus outfit really fits you. You look amazing."
    new "B:pla: Eu aceito. Para começar, tu estás ótima como renas."

    # say L2673 pla
    old "And Billie, green really is your colour, I think it goes really well with your hair."
    new "B:pla: E tu, Belle, esse fato do Pai Natal fica-te mesmo bem. Ficas incrível."

    # say L2674 bil
    old "Well and where is this coming from?"
    new "B:pla: E Billie, o verde realmente te fica bem, acho que combina muito com o teu cabelo."

    # say L2675 bil
    old "It's odd to hear you being so flattering."
    new "B:bil: E donde é que isto vem?"

    # say L2677 bel
    old "But he's right, we look great. Hahaha."
    new "B:bil: É estranho ouvir-te a ser tão elogioso."

    # say L2679 bil
    old "And what about you? What happended with your outfit?"
    new "B:bel: Mas ele tem razão, ficamos ótimos. Hahaha."

    # say L2680 pla
    old "Oh crap! I completely forgot… I was a bit busy with all the preparations"
    new "B:bil: E tu? O que aconteceu com o teu outfit?"

    # say L2682 bel
    old "That's not fair..."
    new "B:pla: Oh merda! Esqueci-me completamente… Estava um bocado ocupado com todos os preparativos."

    # say L2683 bil
    old "Yeah, yeah whatever..."
    new "A:bil: Ok, meu, vamos começar!"

    # say L2684 bil
    old "Ok dude, let's start this!"
    new "B:bil: Sim, sim, seja o que for..."

    # say L2698 hin
    old "They're right, it looks very beautiful [pla]."
    new "B:bel: Uau! [pla] olha para este lugar! É incrível!"

    # say L2700 bil
    old "Ok, we should start playing, don't we."
    new "B:pla: Obrigado, fico contente que vocês gostem."

    # say L2719 pla
    old "Yeah, it's time! Let's start."
    new "B:bil: Ok, devemos começar a jogar, não é?"

    # say L2736 devBel
    old "Woah!"
    new "B:pla: Sim, é hora! Vamos começar."

    # say L2737 milBil
    old "That sensation, it's so strong."
    new "B:devBel: Uau!"

    # say L2738 pla
    old "Did it work?"
    new "B:milBil: Essa sensação, é tão forte."

    # say L2740 gomHin
    old "It did, the spell went well."
    new "B:pla: Funcionou?"

    # say L2755 lin
    old "Great, that was very good."
    new "B:gomHin: Foi, o feitiço correu bem."

    # say L2756 devBel
    old "Well, I wouldn't say it went that well. I mean, look at me! This body is so small."
    new "B:lin: Ótimo, isso foi muito bom."

    # say L2757 devBel
    old "I don't have any more curves! This isn't fair!"
    new "B:devBel: Bem, não diria que correu assim tão bem. Quer dizer, olha para mim! Este corpo é tão pequeno."

    # say L2758 gomHin
    old "I actually gained size. This girl has way more curves than I do."
    new "B:devBel: Não tenho mais curvas! Isto não é justo!"

    # say L2759 gomHin
    old "I think that the one that came up the better in that sense was Mildret."
    new "B:gomHin: Aumentei de tamanho. Esta rapariga tem muito mais curvas do que eu."

    # say L2760 gomHin
    old "Your host has some real curves, it's amazing!"
    new "B:gomHin: Acho que a que se saiu melhor nesse sentido foi a Mildret."

    # say L2761 milBil
    old "I suppose you could say that. She is really big."
    new "B:gomHin: A tua anfitriã tem curvas de verdade, é incrível!"

    # say L2762 milBil
    old "I must say I'm surprised she can move around with these things. Specially since humans can't fly."
    new "B:milBil: Suponho que se possa dizer isso. Ela é realmente grande."

    # say L2763 gomHin
    old "They can't fly, but they have some sensory capabilities that are unique to them."
    new "B:milBil: Tenho de dizer que fico surpreendido que ela consiga andar com essas coisas. Especialmente porque os humanos não podem voar."

    # say L2764 gomHin
    old "They have access to sensations that we don't."
    new "B: gomHin: Não conseguem voar, mas têm capacidades sensoriais únicas."

    # say L2765 devBel
    old "Oh, you don't have to tell me that. I've had it in my mind since before we made the spell."
    new "B: gomHin: Eles têm acesso a sensações que nós não temos."

    # say L2766 lin
    old "I know what you mean, but please remember that's not the reason why we're doing this."
    new "B:devBel: Oh, não tens de me dizer isso. Eu já o tinha em mente antes de criarmos o feitiço."

    # say L2767 gomHin
    old "I know, I know... But still, you can't deny that it's a very interesting experience."
    new "T(gomHin|tu|say): Sei, sei... Mas ainda assim, não podes negar que é uma experiência muito interessante."

    # say L2768 gomHin
    old "I mean, even Mildret's waiting for it. Right?"
    new "B:gomHin: Eu sei, eu sei... Mas ainda assim, não podes negar que é uma experiência muito interessante."

    # say L2770 milBil
    old "Hmph, the only thing I'm waiting for is the magic we'll get once the ritual is over. Nothing else."
    new "B: gomHin: Quero dizer, até a Mildret está à espera. Certo?"

    # say L2772 devBel
    old "Ha! Yeah right. I know you enjoyed your practice the other day."
    new "B:milBil: Humph, a única coisa que estou à espera é a magia que vamos obter quando o ritual acabar. Nada mais."

    # say L2773 milBil
    old "Oh, shut up!"
    new "B:devBel: Ha! Claro. Sei que tu gostaste da tua prática na outra vez."

    # say L2774 lin
    old "Enough of that, remember we're doing a ritual. And it's better if we begin."
    new "B:milBil: Cala-te!"

    # say L2777 lin
    old "You just have to supply them with magic power so that they can  leave your friends bodies."
    new "B:pla: O que tenho de fazer? Como é o processo?"

    # say L2778 lin
    old "The amount of magic that's actually needed to break the possession is really small."
    new "B:lin: Tu só tens de fornecer-lhes poder mágico para que possam sair dos corpos dos teus amigos."

    # say L2780 pla
    old "I'm not sure I follow."
    new "O que ela quer dizer é que no processo de nos expulsar destes corpos."

    # say L2781 gomHin
    old "What she means is that in the process of pushing us out of these bodies."
    new "B:pla: Não tenho a certeza se percebi."

    # say L2782 gomHin
    old "There's going to be an excess of magic that's being produced."
    new "B: gomHin: O que ela quer dizer é que, no processo de nos empurrar para fora destes corpos..."

    # say L2784 lin
    old "And that extra magic is the one I'll take and divert to the point where I'll open a breach."
    new "B:gomHin: Vai haver um excesso de magia a ser produzida."

    # say L2785 lin
    old "That will transform into the magic generation point."
    new "B:lin: E essa magia extra é a que vou direcionar para o ponto onde abrirei uma brecha."

    # say L2787 gomHin
    old "Well, if you do then we better not delay this any longer."
    new "B:lin: Isso se transformará no ponto de geração mágica."

    # say L2788 lin
    old "She's right. We better get started."
    new "Ela tem razão. Melhor começarmos."

    # say L2790 devBel
    old "Yay!"
    new "A:shiBel: Tudo bem, agora é a tua vez de nos dar esse pau grande!"

    # say L2796 shiBel
    old "Alright, now it's time to you to give us that big cock!"
    new "B:devBel: Ótimo!"

    # say L2797 shiHin
    old "My god, this cock of yours, I’ve always thought it’s very big for a human."
    new "B:shiBel: Está bem, agora é a tua vez de nos dar esse pau grande!"

    # say L2798 shiHin
    old "But seeing it with human eyes... It’s something else."
    new "B:shiHin: Meu Deus, este pénis teu, sempre pensei que era muito grande para um humano."

    # say L2799 shiBel
    old "It’s true, I never thought I’d care about the size and girth."
    new "B:shiHin: Mas vê-lo com os olhos humanos... É algo diferente."

    # say L2800 shiBel
    old "But with this body..."
    new "B: shiBel: É verdade, nunca pensei que me importasse com o tamanho e a grossura."

    # say L2801 shiBel
    old "And I never noticed it before, but it has an amazing smell too."
    new "B: shiBel: Mas com este corpo..."

    # say L2802 shiBil
    old "I must admit that it is quite... Enticing."
    new "B: shiBel: E nunca tinha reparado, mas tem um cheiro incrível também."

    # say L2826 gom
    old "It really was, I could feel the magic flowing through me, incredible!"
    new "B:shiHin: Oh, não te preocupes, vamos garantir que vais desfrutar do processo."

    # say L2827 lin
    old "That's because there was a lot of magic in the room."
    new "B:gom: Foi mesmo, senti a magia a fluir através de mim, incrível!"

    # say L2828 lin
    old "Enough to make the breach and create the portal."
    new "B:lin: Isso aconteceu porque havia muita magia no quarto."

    # say L2829 mil
    old "Does that mean that it worked?"
    new "B:lin: O suficiente para fazer a brecha e criar o portal."

    # say L2830 lin
    old "Well, we did everything right. And I made sure to siphon the magic to where we needed it."
    new "B:mil: Isso significa que funcionou?"

    # say L2831 lin
    old "But the portal takes some time to form."
    new "B:lin: Bem, fizemos tudo direito. E eu me certifiquei de direcionar a magia para onde precisávamos."

    # say L2832 lin
    old "So, we won't know for a while."
    new "B:lin: Mas o portal demora a formar-se."

    # say L2833 mil
    old "Then, there's a chance we may have failed."
    new "B:lin: Então, não saberemos por um tempo."

    # say L2834 gom
    old "Well, if it did all we have to do is repeat the ritual."
    new "B:mil: Então, existe a possibilidade de termos falhado."

    # say L2835 dev
    old "That's not a problem, if anything happens it would be a good idea."
    new "B:gom: Bem, se acontecer, só temos de repetir o ritual."

    # say L2836 lin
    old "I'm glad you're positive about it."
    new "T(lin|tu|say): Fico contente por estares positivo em relação a isso."

    # say L2837 lin
    old "For now let's just wait and see."
    new "B:lin: Fico contente que tu estejas positiva em relação a isso."

    # say L2838 pla
    old "Girls, I'm sorry to interrupt, but maybe you could help me clean up my friends."
    new "T(pla|tu|say): Raparigas, desculpem interromper, mas podiam ajudar-me a limpar os meus amigos?"

    # say L2839 pla
    old "We have to make it look as if they were sleeping."
    new "B:pla: Raparigas, desculpem interromper, mas talvez vocês possam ajudar-me a limpar os meus amigos."

    # say L2841 dev
    old "Sure, let's do that."
    new "B:pla: Temos de fazer parecer que eles estavam a dormir."

    # say L2858 mil
    old "Done, now your friends are clean."
    new "Obrigado pela vossa ajuda, raparigas."

    # say L2859 pla
    old "Thank you for your help girls."
    new "B:mil: Feito, agora as tuas amigas estão limpas."

    # say L2862 lin
    old "You make sure there's no problem here."
    new "B:lin: Vamos embora e prestar atenção para ver se sentimos alguma mudança na concentração de magia no ar."

    # say L2863 pla
    old "Alright, I'm gonna wait for my friends to wake up."
    new "B:lin: Tu garantes que não há problema aqui."

    # say L2864 lin
    old "Hmm, given all the power that went through them, they won't wake up until the morning."
    new "B:pla: Vou esperar que os meus amigos acordem."

    # say L2865 pla
    old "Ohh man... Really?"
    new "B:lin: Hmm, dada toda a energia que passou por eles, não vão acordar até de manhã."

    # say L2866 lin
    old "Yeap, I guess so."
    new "B:pla: Ohh, homem... A sério?"

    # say L2867 pla
    old "Well, I have no option... Otherwise, it would be really weird for them to wake up without me around."
    new "B:lin: Sim, acho que sim."

    # say L2868 mil
    old "Yeah, you are right."
    new "B:pla: Bem, não tenho alternativa... Senão seria realmente estranho para eles acordarem sem mim por perto."

    # say L2869 lin
    old "Alright, that's all, it's time for us to leave. Let's go."
    new "T(lin|tu|say): Tudo bem, já deu, é hora de irmos embora. Vamos."

    # say L2871 mil
    old "Thanks for... Everything."
    new "B:lin: Está bem, é hora de irmos embora. Vamos."

    # say L3007 bil
    old "What the hell? We fell asleep?"
    new "B:hin: Não me lembro de nada."

    # say L3008 pla
    old "I think we just fell asleep after playing."
    new "B:bil: Que raio? Adormecemos?"

    # say L3009 pla
    old "I also just woke up."
    new "B:pla: Acho que acabámos de adormecer depois de jogar."

    # say L3010 bil
    old "We just fell asleep?"
    new "B:pla: Também acabei de acordar."

    # say L3012 pla
    old "Uhh yeah, you know, it was pretty late."
    new "B:bil: Acabámos de adormecer?"

    # say L3013 bel
    old "Hmm, I guess that makes sense. "
    new "B:pla: Uhh yeah, tu sabes, já era tarde."

    # say L3014 pla
    old "Hey, I think it's better if we just go home, it's already morning, and someone may come."
    new "B:bel: Hmm, acho que faz sentido."

    # say L3016 hin
    old "You're right, we shouldn't worry our parents."
    new "B:pla: Ei, acho melhor irmos para casa, já é de manhã e alguém pode aparecer."

    # say L3017 bel
    old "That's true, see you later then."
    new "T(bel|tu|say): É verdade, até logo então."

    # say L3019 bil
    old "I still don't get why I can't remember anything, but anyway, I guess I'll go home, later."
    new "B:bel: É verdade, até logo então."

    # say L3027 lin
    old "Oh, you're finnally here."
    new "B:pla: Adeus, raparigas."

    # say L3029 lin
    old "Good morning, I'm glad you are fine. I just wanted to thank you for everything you did."
    new "B:lin: Oh, tu finalmente chegaste."

    # say L3030 pla
    old "Oh, you don't have to thank me, I'm a Sexnote owner, that's my mission."
    new "B:lin: Bom dia, fico contente que estejas bem. Só queria agradecer-te por tudo o que fizeste."

    # say L3031 lin
    old "That's right, however you have done a lot you didn't have to."
    new "B:pla: Oh, não tens de me agradecer, sou proprietário do Sexnote, é a minha missão."

    # say L3032 lin
    old "And everything was for us, to save and protect us."
    new "B:lin: Tens razão, mas fizeste muito mais do que era necessário."

    # say L3034 lin
    old "All right. Now we just have to wait to see if everything worked..."
    new "E quanto tempo vai levar?"

    # say L3035 pla
    old "How much would it takes?"
    new "B:lin: Tudo bem. Agora só temos de esperar para ver se tudo funcionou..."

    # say L3036 lin
    old "To be honest I don't know... It's the first time someone tries to create a magic generation point."
    new "B:pla: Quanto tempo vai levar?"

    # say L3037 lin
    old "It could take, hours, days, weeks or months, the only thing we can do now is wait.."
    new "B:lin: A ser sincero, não sei... É a primeira vez que alguém tenta criar um ponto de geração mágica."

    # say L3039 pla
    old "Oh, man... I was expecting a faster result."
    new "B:lin: Pode demorar horas, dias, semanas ou meses, a única coisa que podemos fazer agora é esperar."

    # say L3040 lin
    old "Actually, I'm pretty sure, that is everthing worked, we could notice a change in the whole area, and it won't take long for sure."
    new "B:pla: Oh, homem... Estava à espera de um resultado mais rápido."

    # say L3042 lin
    old "Yeah, don't worry, this time we did it right. And all of this thanks to you."
    new "B:lin: Na verdade, tenho a certeza de que, se tudo funcionar, vamos notar uma mudança em toda a área, e não vai demorar muito, com certeza."

    # say L3043 pla
    old "I'm glad to had helped."
    new "B:lin: Yeah, não te preocupes, desta vez fizemos tudo direito. E tudo graças a ti."

    # say L3044 lin
    old "All right, I think you should rest. I can see you pretty tired."
    new "B:pla: Fico contente por ter ajudado."

    # say L3045 pla
    old "You're right, I did slept well last night... Thank you and see you later."
    new "T(pla|tu|say): Tens razão, não dormi bem ontem... Obrigado e até mais tarde."


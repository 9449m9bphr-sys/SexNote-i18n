# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/MiaStory.rpy
translate portuguese strings:

    # say L11 mia
    old "Hmph, I see you're late again [pla], you never learn, do you?"
    new "T(mia|formal|say): Hmph, vejo que estás atrasado de novo [pla], nunca aprendes, não é?"

    # say L13 pla
    old "Uhh... Good morning, Miss Mia."
    new "B:mia: Embora isso não seja realmente surpresa, tu estás sempre a fazer este tipo de coisas."

    # say L14 mia
    old "I'm sorry? Don't think that you can be a wise ass with me young man, and get in the classroom already! We're about to start."
    new "B:pla: Uhh... Bom dia, Miss Mia."

    # say L15 mia
    old "Don't you see there are some students that DO care about studying?"
    new "B:mia: Desculpa? Não penses que podes ser um espertalhão comigo, jovem, e entra já para a sala de aula! Vamos começar."

    # say L23 pla
    old "(What the hell got into her?)"
    new "B:mia: Não vês que há alunos que se importam mesmo com os estudos?"

    # say L24 pla
    old "(Gosh, this is gonna be a looong day)"
    new "B:pla: (Que diabo lhe deu?)"

    # say L29 mia
    old "As you can see, establishing a single reason for the start of world war I is nearly impossible."
    new "B:pla: (Puxa, este vai ser um dia bem longo)"

    # say L30 mia
    old "Certainly the detonating event was the killing of Archduke Franz Ferdinand."
    new "B:mia: Como podes ver, estabelecer uma única razão para o início da Primeira Guerra Mundial é quase impossível."

    # say L31 mia
    old "But as I explained already, this was merely a consequence of the authoritarian rule..."
    new "B:mia: Certamente o evento desencadeante foi o assassinato do Arquiduque Francisco Fernando."

    # say L34 pla
    old "(Geez this is boring... What do I need to know any of this stuff for?)"
    new "B:mia: Mas como já expliquei, isto foi apenas uma consequência da regra autoritária..."

    # say L54 pla
    old "(Isn't she wearing underwear?)"
    new "B:pla: (Puxa, isto é aborrecido... Para que é que preciso de saber disto?)"

    # say L62 mia
    old "As I was saying, what's most important to remember when examining the causes of the war..."
    new "B:pla: (Ela não está a usar calcinhas?)"

    # say L63 mia
    old "It's that the political climate of Europe was tremendously charged..."
    new "B:mia: Como eu estava a dizer, o que é mais importante lembrar ao examinar as causas da guerra..."

    # say L68 mik
    old "{i}U-uh? Are you talking to me? Did Ms. Mia ask a question?{/i}"
    new "B:pla: {i}Hey Mike, cara! Viste aquilo?! {/i}"

    # say L69 pla
    old "{i}What? No dude! You didn't see that?{/i}"
    new "B:mik: {i}U-uh? Estás a falar comigo? A senhora Mia fez uma pergunta?{/i}"

    # say L70 mik
    old "{i}See what?{/i}"
    new "B:pla: {i}O quê? Não, meu! Não viste isso?{/i}"

    # say L71 pla
    old "{i}Nevermind...{/i}"
    new "B:mik: {i}Ver o quê?{/i}"

    # say L73 pla
    old "(I'm sure I saw she wasn't wearing any panties.)"
    new "B:pla: (Fui o único que viu isso?)"

    # say L75 mia
    old "Ok guys, that's today's class, remember I'm going to need you to write a three-page report on the causes of world war I for the next class."
    new "B:pla: (Tenho a certeza de que vi que ela não estava a usar calcinhas.)"

    # say L98 mia
    old "Hmm, late again! You just never learn, do you [pla]?"
    new "B:mia: E [pla], lembra-te de chegar a horas da próxima vez!"

    # say L100 mia
    old "Just on time to interrupt the class by entering late!"
    new "B:pla: Olá Miss Mia, estava à espera de mim? Quero dizer, cheguei a tempo."

    # say L101 mia
    old "I'm telling you, you better straighten up!"
    new "B:mia: A tempo de interromper a aula entrando atrasada!"

    # say L110 dir
    old "Oh! Mia, good morning."
    new "B:mia: Estou a dizer-te, melhoras-te melhor!"

    # say L111 mia
    old "Good Morning ma'am, how are you today?"
    new "B:dir: Oh! Mia, bom dia."

    # say L112 dir
    old "I'm pretty good, thank you, just checking up on things before I go to my office to start the day."
    new "B:mia: Bom dia, como estás hoje?"

    # say L113 dir
    old "By the way, don't you think it's about time for you to start with your class?"
    new "T(dir|tu|say): Aliás, não achas que é hora de começares com a tua aula?"

    # say L115 mia
    old "You're right, sorry ma'am, I was just waiting for this student, he needs a little extra attention."
    new "B:dir: Aliás, não achas que é hora de começares com a tua aula?"

    # say L120 dir
    old "Ah, this is the student you told me about."
    new "B:pla: Bom dia, senhora.."

    # say L124 dir
    old "Trust me, you don't want to see your classmates move on and you being stuck here."
    new "B:pla: Tens razão, senhora, peço desculpa."

    # say L125 dir
    old "So, make sure you buckle down and start studying seriously."
    new "B:dir: Confia em mim, não queres ver os teus colegas de turma a avançar e tu ficar aqui parado."

    # say L126 dir
    old "Otherwise you'll have to come here and take extra classes during your Holidays."
    new "B:dir: Então, assegura-te de te concentrares e começares a estudar a sério."

    # say L127 pla
    old "You're right, ma'am."
    new "T(pla|tu|say): Tens razão, senhora."

    # say L128 dir
    old "Just keep it in mind. Mia already has an eye on you, be thankful that your teacher cares so much."
    new "B:pla: Tens razão, senhora."

    # say L129 pla
    old "Hmm... Yes ma'am."
    new "B:dir: Mantém isso em mente. A Mia já está de olho em ti, agradece que a tua professora se preocupa tanto contigo."

    # say L130 dir
    old "Good boy."
    new "Agora, Mia, acho que é hora de começares a tua aula."

    # say L131 dir
    old "Now Mia, I think it's time for you to start your class."
    new "B:dir: Bom rapaz."

    # say L132 mia
    old "Yes ma'am, I'm about to."
    new "B:dir: Agora, Mia, acho que é hora de começares a tua aula."

    # say L133 mia
    old "Have a very good day ma'am."
    new "B:mia: Sim, senhora, estou prestes a."

    # say L134 dir
    old "You too dear."
    new "B:mia: Tenha um ótimo dia, senhora."

    # say L142 mia
    old "You see? That's your second warning about your studies. You better listen!"
    new "B:dir: Tu também, querida."

    # say L143 mia
    old "And come in!"
    new "B:mia: Vês? Esta é a tua segunda advertência sobre os estudos. Melhor ouvires!"

    # say L149 mia
    old "Ok guys, we'll continue with the world war one chapter."
    new "B:mia: E entrem!"

    # say L150 mia
    old "This time we'll talk about Africa and the Ottoman Empire during this period of time."
    new "B:mia: Ok pessoal, vamos continuar com o capítulo da Primeira Guerra Mundial."

    # say L156 mia
    old "Is it me or is it really hot today? I think I need to get a bit more comfortable."
    new "B:mia: Desta vez vamos falar sobre África e o Império Otomano durante este período."

    # say L160 pla
    old "(What the fuck?! She's not wearing a bra!)"
    new "B:mia: É só eu ou está mesmo muito quente hoje? Acho que preciso ficar um bocadinho mais confortável."

    # say L161 pla
    old "(What's happening with her?)"
    new "B: (Que raio?! Ela não está a usar soutien!)"

    # say L169 mia
    old "Phew, too much better, ok, let's continue with the subject..."
    new "B:pla: (O que é que se passa com ela?)"

    # say L174 mik
    old "{i}I don't know, but this is totally rad!{/i}"
    new "B:pla: {i}Sim, o que se passa com isso?{/i}"

    # say L177 mik
    old "U- uh, sorry Miss Mia."
    new "B:mia: Há algo que queiras partilhar com a turma? Ou posso continuar a aula?"

    # say L181 mia
    old "I imagine that paper you had to write must be excellent, right?"
    new "B:mia: Deixa-me lembrar-te que as tuas notas têm sido terríveis."

    # say L182 pla
    old "I said I was sorry..."
    new "B:mia: Imagino que o trabalho que tiveste de fazer deve ser excelente, certo?"

    # say L183 mia
    old "Hmph, you better be."
    new "B:pla: Eu disse que sinto muito..."

    # say L184 mia
    old "I'm sorry class, let's just continue, I know some of you actually want to learn."
    new "B:mia: Humph, tu melhor é."

    # say L193 pla
    old "Yeah, that was weird."
    new "Oi Belle, tu viste aquilo?"

    # say L202 mik
    old "Hey Belle, did you see that?"
    new "T(mik|tu|say): Ei Belle, viste aquilo?"

    # say L203 mik
    old "Now we have a new motivation to come to class!"
    new "B:mik: Ei Belle, viste aquilo?"

    # say L205 bel
    old "Yes, I noticed that Miss Mia wasn't wearing a bra... I assume that's what you mean?"
    new "B:mik: Agora temos uma nova motivação para vir à aula!"

    # say L206 pla
    old "That was weird, and it's not the first time, last class I also noticed something."
    new "B:bel: Sim, notei que a Miss Mia não estava a usar soutien... Acho que é isso que queres dizer?"

    # say L207 bel
    old "Yeah, I also saw that."
    new "T(bel|tu|say): Sim, eu também vi isso."

    # say L210 mik
    old "What? Last class?"
    new "B:bel: Sim, eu também vi isso."

    # say L211 mik
    old "I didn't see anything."
    new "T(mik|tu|say): Não vi nada."

    # say L212 mik
    old "What was it? What was it?"
    new "B:mik: Não vi nada."

    # say L215 bel
    old "There's something odd about Ms. Mia's behavior lately."
    new "B:mik: O que foi? O que foi?"

    # say L216 pla
    old "I know what you mean."
    new "B:bel: Há algo estranho no comportamento da Sr.ª Mia ultimamente."

    # say L217 pla
    old "But I guess that's none of our concern."
    new "B:pla: Eu sei o que queres dizer."

    # say L220 bel
    old "By the way, I'm going over to Billie's to hang out."
    new "B:pla: Mas acho que isso não nos diz respeito."

    # say L221 bel
    old "You guys wanna come?"
    new "A:pla: Eu adorava ir."

    # say L224 pla
    old "I would love to."
    new "T(pla|tu|say): Eu adorava ir."

    # say L225 pla
    old "But I have to get working on the next project, otherwise Ms. Mia will never get off my back."
    new "T(pla|tu|say): Mas tenho de me pôr a trabalhar no próximo projeto, senão a Sr.ª Mia nunca me larga."

    # say L226 bel
    old "She really doesn't like you, does she?"
    new "B:pla: Mas tenho que começar a trabalhar no próximo projeto, senão a Sr.ª Mia nunca me deixará em paz."

    # say L227 pla
    old "Ha, that's saying little."
    new "T: Ah, isso é dizer pouco."

    # say L229 pla
    old "Oh, damn, I just realized, I forgot my notes in the classroom."
    new "T(pla|tu|say): Oh, merda, acabei de me aperceber, esqueci-me das minhas notas na sala de aula."

    # say L230 pla
    old "I have to go back and grab them. See you later guys!"
    new "B:pla: Oh, merda, acabei de me aperceber, esqueci as minhas notas na sala de aula."

    # say L239 mik
    old "So, where are we going Belle?"
    new "B:pla: Tenho de voltar a buscá-los. Vejo-vos mais tarde!"

    # say L251 mia
    old "Yeah, yeah, I did what you asked!! Okay?!"
    new "A:mia: Sim, mas não vou fazer isso de novo!"

    # say L252 mia
    old "Yeah, but I won't be doing that shit again!"
    new "B:mia: Sim, sim, fiz o que pediste!! Ok?!"

    # say L253 mia
    old "This was so embarrassing. You went way overboard with this!"
    new "B:mia: Sim, mas não vou fazer isso de novo!"

    # say L254 mia
    old "And I'm telling you now, I'm not doing anything more in public!"
    new "B:mia: Isto foi tão embaraçoso. Tu exageraste completamente!"

    # say L259 mia
    old "What...?!"
    new "B:mia: E estou a dizer-te agora, não faço mais nada em público!"

    # say L260 mia
    old "Ugh, great, just what I needed!"
    new "B:mia: O quê...?!"

    # say L262 pla
    old "Um, sorry, I just came back to pick up my notes, I'm leaving now."
    new "B:mia: Ugh, great, just what I needed!"

    # say L269 mia
    old "Uh? What? Him?"
    new "B:pla: Hum, desculpa, só voltei para apanhar as minhas notas, estou a ir-me embora agora."

    # say L270 mia
    old "He's nobody, just another one of my stupid students."
    new "B:mia: Uh? O quê? Ele?"

    # say L271 mia
    old "Nah, he just came in, he heard nothing."
    new "B:mia: Ele é ninguém, apenas mais um dos meus alunos estúpidos."

    # say L272 mia
    old "What does his name have to do with anything?"
    new "B:mia: Não, ele acabou de chegar, não ouviu nada."

    # say L273 mia
    old "Yeah, I don't like him, so what?"
    new "B:mia: O que tem o nome dele a ver com alguma coisa?"

    # say L274 mia
    old "What? Listen, that doesn't have anything to do with our conversation."
    new "B:mia: Sim, não gosto dele, e daí?"

    # say L275 mia
    old "The point is that I'm not doing anything else, so you better stop harassing me, you got that?!"
    new "B:mia: O quê? Ouve, isso não tem nada a ver com a nossa conversa."

    # say L279 mia
    old "Ughh..."
    new "B:mia: O ponto é que não estou a fazer nada mais, então melhor parares de me importunar, percebeste?!"

    # say L284 pla
    old "Hmm, I guess Mike and Belle already left."
    new "B:mia: Ughh..."

    # say L285 pla
    old "(But what the hell was that phone call about? That was so weird.)"
    new "B: pla: Hmm, acho que o Mike e a Belle já se foram."

    # say L286 pla
    old "(Although I guess it's not my business.)"
    new "B: (Mas que raio foi aquela chamada telefónica? Foi tão estranho.)"

    # say L301 mia
    old "All right guys, today we'll talk about American development during the period from 1925 to 1938, the period between the two world wars..."
    new "B:pla: (Acho que não é da minha conta.)"

    # say L302 pla
    old "(God this is so fucking boring.)"
    new "B:mia: Bem, pessoal, hoje vamos falar sobre o desenvolvimento americano durante o período de 1925 a 1938, o período entre as duas guerras mundiais..."

    # say L304 pla
    old "(What?)"
    new "A:pla: (Ela está a olhar para mim?)"

    # say L305 pla
    old "(Is she looking at me?)"
    new "A:mia: A crise europeia permitiu a emergência de industriais poderosos, como Rockefeller e Ford."

    # say L306 mia
    old "The European crisis allowed the emergence of powerful industrialists, like Rockefeller and Ford."
    new "B: pla: (Ela está a olhar para mim?)"

    # say L307 pla
    old "(Why does she look so angry?)"
    new "B:mia: A crise europeia permitiu a emergência de industriais poderosos, como Rockefeller e Ford."

    # say L313 mia
    old "Ok, guys, that's it for today, for the next class I'll need you to read about the treaty of Versailles."
    new "B:pla: (Porque é que ela está tão zangada?)"

    # say L319 mik
    old "Aw, dude, that was so dull!"
    new "B:mia: Ok, pessoal, é isso para hoje, para a próxima aula preciso que leiam sobre o Tratado de Versalhes."

    # say L320 mik
    old "I'm exhausted, can't wait for lunch."
    new "B:mik: Ah, pá, isso foi tão aborrecido!"

    # say L334 mik
    old "Good luck dude."
    new "B:mik: Uh-oh, estás em apuros, meu. Acho que é melhor eu ir para casa."

    # say L336 pla
    old "See you dude."
    new "B:mik: Boa sorte, mano."

    # say L343 pla
    old "If this is about the project I-"
    new "B:pla: Até logo, mano."

    # say L344 mia
    old "Oh shut up! Just shut up! Who cares about that stupid project?!"
    new "B:pla: Se isto é sobre o projeto eu-"

    # say L345 pla
    old "Uh w-what? But you said..."
    new "B:mia: Cala-te! Só cala-te! Quem é que se importa com esse estúpido projeto?!"

    # say L346 mia
    old "So, it was you, wasn't it?!"
    new "B:pla: Uh w-what? Mas tu disseste..."

    # say L347 mia
    old "I see, of course, he had someone on the inside."
    new "B:mia: Então foste tu, não foste?!"

    # say L348 mia
    old "You're the bastard that's been verifying that I do his stupid challenges. I should've known."
    new "T(mia|formal|say): Tu és o desgraçado que tem estado a verificar se faço os teus estúpidos desafios. Devia ter-me apercebido."

    # say L349 pla
    old "Uhmm, what? What are you talking about?"
    new "B:mia: Tu és o bastardo que tem estado a verificar que eu faço os estúpidos desafios dele. Devia ter-me apercebido."

    # say L351 mia
    old "Well, I'll let you know I'm tired of this bullshit! You better not think you'll keep getting away with this disgusting behavior."
    new "B:pla: Hmm, o quê? Do que estás a falar?"

    # say L352 mia
    old "I was so stupid not to realize it was you, of course, you were the clear option."
    new "B:mia: Bem, vou-te dizer que estou farta desta merda! Melhor não pensares que vais continuar a safar-te com este comportamento nojento."

    # say L353 mia
    old "I should've known from the beginning. It was obvious."
    new "B:mia: Fui tão estúpida por não ter percebido que eras tu, claro, eras a opção óbvia."

    # say L354 pla
    old "Excuse me, I don't know what you're accusing me of, but I haven't done anything."
    new "B:mia: Devia ter percebido desde o início. Era óbvio."

    # say L355 mia
    old "Will you stop playing dumb already?!!! You know very well what I'm talking about!"
    new "B:pla: Desculpe, não sei do que me está a acusar, mas eu não fiz nada."

    # say L356 mia
    old "Or are you telling me you haven't been following that bastard Denzel's orders to spy on me?"
    new "B:mia: Vais parar de fazer-te de desentendida já?!?! Tu sabes muito bem do que estou a falar!"

    # say L357 pla
    old "Denzel? What the-"
    new "B:mia: Ou estás a dizer-me que não tens estado a seguir as ordens desse maldito Denzel para me espiar?"

    # say L358 mia
    old "Or that you just happened to come into the classroom just as I was reporting to him?!"
    new "T(mia|formal|say): Ou que tu simplesmente entraste na sala de aula justo quando eu estava a relatar-lhe?!"

    # say L359 mia
    old "I know you're a bastard, but spare me your stupid lies!"
    new "B:mia: Ou que tu simplesmente entraste na sala de aula quando eu estava a relatar-lhe?!"

    # say L360 pla
    old "I already told you I don't know what you're talking about!"
    new "B:mia: Eu sei que és um bastardo, mas poupame às tuas estúpidas mentiras!"

    # say L361 mia
    old "Ugh, whatever, let's just get this over with."
    new "B:pla: Já te disse que não sei do que estás a falar!"

    # say L369 pla
    old "Woah! Woah! What do you think you're doing?"
    new "B:mia: Ugh, whatever, vamos acabar com isto."

    # say L370 mia
    old "Will you stop pretending you don't know what's going on?!!"
    new "B:pla: Woah! Woah! O que é que tu pensas que estás a fazer?"

    # say L371 mia
    old "How can you keep acting like this after all that you've made me do?!"
    new "B:mia: Vais parar de fingir que não sabes o que se está a passar?!!"

    # say L372 mia
    old "At least pretend you have some decency, will you?!"
    new "B:mia: Como podes continuar a agir assim depois de tudo o que me fizeste?!"

    # say L373 pla
    old "I-I don't... W- what do you mean?"
    new "B:mia: Pelo menos faz de conta que tens algum decência, sim?"

    # say L374 pla
    old "I already told you, I have no idea what you're talking about."
    new "B:pla: E-Eu não... Q-Quê que tu queres dizer?"

    # say L375 mia
    old "Yeah right... As if I'll believe anything you say."
    new "B:pla: Já te disse, não faço a mínima ideia do que estás a falar."

    # say L376 mia
    old "But I'll give you what you want, you sick freak."
    new "B:mia: Claro... Como se eu fosse acreditar em alguma coisa que tu dizes."

    # say L385 mia
    old "Listen, I've had enough of your bullshit for one day."
    new "B:mia: Mas vou dar-te o que queres, tu doente pervertido."

    # say L386 mia
    old "I already sent that asshole the picture. Just leave me alone."
    new "B:mia: Escuta, já chega de merda para um dia."

    # say L393 pla
    old "What the fuck?!"
    new "B:mia: Já mandei a foto para aquele idiota. Deixa-me em paz."

    # say L415 mia
    old "Of course, your little accomplice would come!"
    new "B:pla: Que raio?!"

    # say L416 mia
    old "What are you two, sick freaks, planning now?"
    new "B:mia: Claro, a tua pequena cúmplice tinha de aparecer!"

    # say L417 pla
    old "W- what? I... What are you talking about?"
    new "B:mia: O que é que vocês, doentes, estão a planear agora?"

    # say L418 pla
    old "I just came early for class!"
    new "T(pla|tu|dizes): Apenas cheguei cedo para a aula!"

    # say L419 mia
    old "Ugh! Denzel, could you tell your little minion to stop acting?"
    new "B:pla: Cheguei cedo à aula!"

    # say L421 den
    old "Well, Miss Mia, I must say this is the first time I've seen your student."
    new "B:mia: Ugh! Denzel, podias dizer ao teu pequeno lacai a parar de fazer birra?"

    # say L422 den
    old "I don't even know his name."
    new "B:den: Bem, Miss Mia, devo dizer que esta é a primeira vez que vejo o teu aluno."

    # say L423 mia
    old "What?! What do you mean?"
    new "B:den: Nem sequer sei o nome dele."

    # say L425 den
    old "Well, I don't think you even have enough in that empty head of yours to remember."
    new "B:mia: Que?! O que queres dizer com isso?"

    # say L426 den
    old "But while you were my teacher, you made my life miserable, absolutely horrible."
    new "B:den: Bem, duvido que tenhas suficiente naquela cabeça vazia para te lembrares."

    # say L427 den
    old "And from what I can see, that's something you're still doing..."
    new "B:den: Mas enquanto foste minha professora, tornaste a minha vida miserável, absolutamente horrível."

    # say L429 den
    old "Well, I've noticed you always pick on a poor and innocent guy from your classes to torment."
    new "B:den: E pelo que posso ver, isso é algo que tu ainda fazes..."

    # say L430 den
    old "Tremendously immature of you, I must say, someone would think a teacher would be a little bit more... nuanced."
    new "B:den: Bem, já reparei que tu sempre escolhes um pobre e inocente rapaz da tua turma para atormentar."

    # say L431 den
    old "So, the other day, after listening to your answer when we were talking and you got interrupted by him."
    new "B:den: É uma atitude extremamente imatura, devo dizer, alguém poderia pensar que um professor seria um pouco mais... sutil."

    # say L432 den
    old "It came to my mind, why not give the young guy a chance to take some revenge on his horrible teacher?"
    new "B:den: Então, outro dia, depois de ouvir a tua resposta quando estávamos a falar e foste interrompido por ele."

    # say L433 mia
    old "... The fuck?"
    new "B:den: Veio-me à cabeça, por que não dar ao rapaz uma oportunidade de se vingar da sua horrível professora?"

    # say L434 pla
    old "W-w-what the hell is happening? What are you guys talking about?"
    new "B:mia:... Que raio?"

    # say L436 den
    old "Oh, how rude of me, I went into a monologue without even introducing myself. Apologies buddy."
    new "B:pla: O-O-O que raio se está a passar? Do que é que vocês estão a falar?"

    # say L437 den
    old "My name is Denzel, and just like you, I was once a victim of this so-called teacher's horrible personality."
    new "B:den: Oh, que mal-educado de mim, entrei num monólogo sem me apresentar. Peço desculpa, meu amigo."

    # say L439 den
    old "She used to be my teacher, and she made my life miserable too."
    new "B:den: O meu nome é Denzel, e tal como tu, eu também fui uma vez vítima da personalidade horrível desta suposta professora."

    # say L441 den
    old "I never forgave her, but I didn't actually have any way to get back at her for anything."
    new "B:den: Ela costumava ser minha professora, e também tornou a minha vida num inferno."

    # say L442 den
    old "That is, until recently, when I learned a couple of things from her past that she would prefer to have hidden."
    new "B:den: Nunca a perdoei, mas não tinha realmente forma de me vingar dela."

    # say L443 mia
    old "No! Don't say anything about that! Please, I'm already doing whatever you ask me."
    new "B:den: Isso é, até recentemente, quando descobri algumas coisas do seu passado que ela preferiria manter em segredo."

    # say L445 pla
    old "W-what are you talking about?"
    new "B:mia: Não! Não digas nada sobre isso! Por favor, estou já a fazer tudo o que me pedes."

    # say L447 den
    old "Go ahead Mia, tell your favorite student all about your past..."
    new "T(den|tu|diz): Vai em frente, Mia, conta tudo ao teu aluno favorito..."

    # say L448 mia
    old "Please... No..."
    new "B:den: Vai em frente, Mia, conta tudo ao teu aluno favorito..."

    # say L450 den
    old "I mean, there's nothing to feel ashamed about, is there?"
    new "B:mia: Por favor... Não..."

    # say L455 den
    old "That's right! Can you believe it? She's always so self-righteous, always taking her anger out on other people."
    new "B:den: Quero dizer, não há nada de que se envergonhar, certo?"

    # say L456 den
    old "She's offensive, arrogant, and demanding, when she used to be just a whore!"
    new "B:den: É verdade! Tu acreditas? Ela é sempre tão moralista, sempre a descontar a raiva nos outros."

    # say L458 den
    old "Anyway, she got out of that, but I found out and got proof that she used to be a pornstar."
    new "B:den: Ela é ofensiva, arrogante e exigente, quando antigamente era só uma puta!"

    # say L459 den
    old "And if she doesn't want to be fired, and get her life ruined,  she'll have to do as I say."
    new "B:den: De qualquer forma, ela conseguiu sair disso, mas eu descobri e tenho provas de que ela já foi atriz pornográfica."

    # say L460 den
    old "Or I'll out her as the whore she is, and her life here will be over."
    new "B:den: E se ela não quiser ser despedida e ter a vida arruinada, terá de fazer o que eu digo."

    # say L461 mia
    old "You fucking bastard!"
    new "B:den: Ou vou expor-te como a puta que és, e a tua vida aqui acabará."

    # say L463 den
    old "Oh, call me what you want, that only makes it better when I punish you."
    new "B:mia: Tu maldito bastardo!"

    # say L466 den
    old "By the way... I think it's about time for your next punishment."
    new "B:den: Oh, chama-me como quiseres, isso só torna melhor quando eu te castigo."

    # say L467 den
    old "Oh, sorry, we're calling them challenges. Right?"
    new "B:den: Aliás... Acho que é hora da tua próxima punição."

    # say L468 mia
    old "Challenge? Punishment?!"
    new "B:den: Oh, desculpa, estamos a chamar-lhes desafios. Certo?"

    # say L469 mia
    old "This is blackmail! And abuse!"
    new "B:mia: Desafio? Castigo?!"

    # say L470 den
    old "Call it whatever you want, but you have to do it."
    new "B:mia: Isto é chantagem! E abuso!"

    # say L471 den
    old "And seeing as your favorite student's here, why don't we have you give him a little bit of attention?"
    new "B:den: Chama-lhe o que quiseres, mas tens de o fazer."

    # say L473 den
    old "Give him a blowjob."
    new "B:den: E como o teu aluno favorito está aqui, porque não lhe dás um pouco de atenção?"

    # say L474 mia
    old "What?! You must be kidding me! A blowjob?!"
    new "B:den: Dá-lhe uma boquete."

    # say L475 mia
    old "This is going way too far!"
    new "B:mia: Que?! Estás a brincar comigo! Uma fellatio?!"

    # say L476 mia
    old "Didn't you have enough with your pictures and stuff?"
    new "B:mia: Isto está a ir longe de mais!"

    # say L477 den
    old "Oh, I really enjoyed those, but that's not what I want right now."
    new "B:mia: Não foste tu que já tiveste o suficiente com as tuas fotos e tudo mais?"

    # say L478 den
    old "I already told you what to do, take out his dick and suck it!"
    new "B:den: Oh, eu realmente gostei disso, mas não é o que quero agora."

    # say L479 den
    old "Otherwise I suppose tomorrow the school principal will receive a mail with an interesting video."
    new "B:den: Já te disse o que fazer, tira o pénis dele e chupa-o!"

    # say L492 mia
    old "You sick freak..."
    new "B:den: Senão suponho que amanhã o diretor da escola receberá um e-mail com um vídeo interessante."

    # say L493 mia
    old "I'll do it, ok? Just don't spread anything, ok?"
    new "B:mia: Tu doente pervertido..."

    # say L499 mia
    old "Well, what do you think stupid?!"
    new "B:pla: Y- you can't be serious."

    # say L500 mia
    old "I wouldn't joke about this shit."
    new "B:mia: E então, o que achas, idiota?!"

    # say L501 pla
    old "I- I'm sorry Miss Mia, but I don't have anything to do with this. I should just leave."
    new "T: I- I'm sorry Miss Mia, mas não tenho nada a ver com isso. Devo apenas ir embora."

    # say L508 den
    old "Well, I guess you could just leave. But if you do, I'll just leak the information I have about her."
    new "B:pla: I- I'm sorry Miss Mia, but I don't tenho nada a ver com isto. Devo apenas ir-me embora."

    # say L509 den
    old "That's also an option by the way."
    new "B:den: Bem, acho que tu podes simplesmente ir embora. Mas se o fizeres, vou divulgar a informação que tenho sobre ela."

    # say L511 den
    old "After all, she's also been cruel to you all this time, you may as well just let her suffer with this."
    new "B:den: Isso também é uma opção, por acaso."

    # say L513 den
    old "Tell you what, maybe you'll change your mind if you see her beg for it. How about it?"
    new "B:den: Afinal, ela também tem sido cruel contigo todo este tempo, podes muito bem deixá-la sofrer com isto."

    # say L515 den
    old "Go ahead Mia, beg him to let you suck his dick, remember what's at stake here for you."
    new "B:den: Diz lá, talvez mudes de ideias se a vires implorar. Que tal?"

    # say L519 mia
    old "But if we don't do this, he'll just release his disgusting pictures and videos of me."
    new "B:den: Ha! Que maneira estranha de implorar! heh."

    # say L520 mia
    old "Please, please, please help me out."
    new "B:mia: Mas se não fizermos isto, ele vai apenas libertar as suas nojentas fotografias e vídeos minhas."

    # say L521 mia
    old "After my life went to shit because of what happened before, it's taken me so much work to create something here."
    new "B:mia: Por favor, por favor, por favor, ajuda-me."

    # say L522 den
    old "Aww, you're breaking my heart."
    new "B:mia: Depois de a minha vida se ter transformado num inferno devido ao que aconteceu antes, custou-me imenso criar algo aqui."

    # say L523 mia
    old "Fuck you."
    new "B:den: Aww, estás a partir-me o coração."

    # say L524 pla
    old "Hmm, ok, I'll do it."
    new "B:mia: Foda-se."

    # say L526 den
    old "You will, Ha! I knew it, you also want to get revenge on her, right?"
    new "Não!"

    # say L527 pla
    old "No!"
    new "B:den: Vais, hã? Eu sabia, tu também queres vingar-te dela, certo?"

    # say L528 pla
    old "I'll do it just to help her, I don't want revenge on anyone."
    new "B:pla: Não!"

    # say L529 den
    old "Heh, whatever you say, kid."
    new "B:pla: Vou fazer isso só para ajudá-la, não quero vingança contra ninguém."

    # say L531 den
    old "All right Mia, it's time to do what you do best!"
    new "B:den: Heh, seja como for, miúdo."

    # say L544 den
    old "After all you're just a whore."
    new "B:den: Aposto que tu querias isto, mesmo tendo saído do negócio pornográfico."

    # say L546 mia
    old "Whatever you say, but remember, you won't get away with this for long."
    new "B:den: Afinal, tu não passas de uma puta."

    # say L547 den
    old "Heh, we'll see."
    new "B:mia: O que tu disseres, mas não vais safar-te disto por muito tempo."

    # say L557 mia
    old "Woah, what the fuck?!"
    new "A:mia: O que estás a fazer? Para que tiraste essa fotografia?"

    # say L559 mia
    old "What are you doing? What did you take that picture for?"
    new "B:mia: Que raio?!"

    # say L560 den
    old "Don't worry about it, that's just to..."
    new "B:mia: O que estás a fazer? Para que tiraste essa fotografia?"

    # say L561 den
    old "Let's say, commemorate the occasion."
    new "B:den: Não te preocupes com isso, é só para..."

    # say L563 den
    old "Anyway, I think I should just leave."
    new "B:den: Vamos dizer, comemorar a ocasião."

    # say L577 pla
    old "U-uh, Miss Mia, I- I think..."
    new "A:mia: Não quero falar, ou qualquer coisa. Adeus."

    # say L578 mia
    old "I don't want to talk, or anything. Bye."
    new "B:pla: H-hum, Miss Mia, eu acho que..."

    # say L586 pla
    old "Damn."
    new "B:mia: Não quero falar, nem nada. Adeus."

    # say L587 pla
    old "(What did I get myself into now?)"
    new "B:pla: Merda."

    # say L606 pla
    old "Eh, ehem."
    new "Olá Miss Mia, bom dia."

    # say L611 pla
    old "Hi Miss Mia, good morning."
    new "B:pla: Eh, ehem."

    # say L612 mia
    old "G-good morning."
    new "B:pla: Bom dia, Miss Mia."

    # say L613 mia
    old "I see you're early today, congratulations."
    new "B:mia: B-bom dia."

    # say L614 mia
    old "The class doesn't start yet, so take a seat and wait for your classmates."
    new "B:mia: Vejo que estás cedo hoje, parabéns."

    # say L618 pla
    old "Hmm, actually, I was kinda hoping we could talk."
    new "B:mia: A aula ainda não começou, então senta-te e espera pelos teus colegas."

    # say L619 pla
    old "You know, about what happened last time..."
    new "B:pla: Hmm, na verdade, estava a pensar que podíamos falar."

    # say L622 mia
    old "Listen, we don't have anything to talk about."
    new "A:mia: Sinto muito por teres sido arrastado nisso e agradeço-te por me teres ajudado."

    # say L623 mia
    old "I'm really sorry that you saw yourself being dragged into it, and I thank you for helping me."
    new "B:mia: Ouve, não temos nada de que falar."

    # say L624 mia
    old "But that's all I will say about that issue."
    new "B:mia: Sinto muito que tenhas sido arrastada nisso, e agradeço-te a tua ajuda."

    # say L625 mia
    old "Which, by the way, it's my own business, so I would appreciate it if you didn't interfere."
    new "B:mia: Mas é tudo o que tenho a dizer sobre esse assunto."

    # say L626 pla
    old "What? You can't be talking seriously."
    new "B:mia: Isso, aliás, é assunto meu, então agradecia que não te metesses."

    # say L627 pla
    old "Listen, what happened yesterday wasn't ok, and you can't let him keep forcing you into that kind of stuff."
    new "T(pla|tu|say): Ouve, o que aconteceu ontem não foi certo, e tu não podes deixar que ele continue a forçar-te a fazer esse tipo de coisas."

    # say L628 pla
    old "It's just not right, you have to do something..."
    new "B:pla: Ouve, o que aconteceu ontem não foi certo, e tu não podes deixar que ele continue a forçar-te a fazer esse tipo de coisas."

    # say L629 mia
    old "And you think I don't know that?!"
    new "B:pla: Não está certo, tens de fazer algo..."

    # say L630 mia
    old "Of course it's not right! But I can't do anything, I've racked my brain to come up with a satisfying solution. But nothing."
    new "B:mia: E tu achas que eu não sei disso?!"

    # say L631 mia
    old "Otherwise, I wouldn't be stuck following his orders! Don't treat me like an idiot!"
    new "B:mia: Claro que não está certo! Mas não consigo fazer nada, já esgotei todas as ideias para encontrar uma solução satisfatória. Mas nada."

    # say L633 pla
    old "I know you're not dumb, but that's why I wanted to talk to you because I think maybe I could help you."
    new "B:mia: Senão, não estaria presa a seguir as suas ordens! Não me trates como se fosses burra!"

    # say L635 pla
    old "Listen, I just don't think it's right that he keeps pushing you around like that."
    new "B:pla: Eu sei que tu não és burro, mas é por isso que queria falar contigo, porque acho que talvez pudesse ajudar-te."

    # say L636 pla
    old "I want to do something to help you."
    new "B:pla: Ouve, não acho certo ele continuar a tratar-te assim."

    # say L637 pla
    old "I think it's the best thing that I can do. If you'll let me."
    new "B:pla: Quero fazer algo para te ajudar."

    # say L639 mia
    old "Hmm... I guess you're right."
    new "T(mia|formal|say): Hmm... Acho que tens razão."

    # say L640 mia
    old "Listen, Denzel, is a previous student of mine, that apparently recent me from when I was his teacher."
    new "E ele decidiu vingar-se ameaçando divulgar algumas gravações que encontrou de quando eu estava..."

    # say L641 mia
    old "And he's decided to get back at me by threatening to release some footage that he found from when I was..."
    new "B:mia: O Denzel, um antigo aluno meu, aparentemente reconheceu-me recentemente quando eu era a professora dele."

    # say L642 mia
    old "From when I was..."
    new "E ele decidiu se vingar ameaçando divulgar algumas imagens que encontrou de quando eu... ZZZ...ZZZ"

    # say L643 mia
    old "Ugh! It's even hard to talk about it!"
    new "B:mia: Desde quando eu era..."

    # say L644 mia
    old "From when I was a pornstar, ok?"
    new "B:mia: Ugh! É até difícil falar disso!"

    # say L646 mia
    old "That was a long time ago, I was just fresh out of high school, and didn't have any money to pay for college."
    new "B:mia: Desde quando eu era atriz pornográfica, ok?"

    # say L647 mia
    old "Somebody had talked to me about how much money you could make in little time working on porn."
    new "B:mia: Foi há muito tempo, eu tinha acabado de sair do liceu e não tinha dinheiro para pagar a universidade."

    # say L648 mia
    old "I was young, so I didn't really think it through, and just decided to do it."
    new "B:mia: Alguém me falou sobre quanto dinheiro se podia ganhar em pouco tempo a trabalhar na pornografia."

    # say L649 mia
    old "But I regret it so much, it didn't bring anything good to my life. That period gave me very low self-esteem."
    new "B:mia: Eu era nova, então não pensei muito nisso e decidi fazer."

    # say L650 mia
    old "Besides, it caused me depression and anxiety that lasted for a very long time."
    new "B:mia: Mas arrependo-me tanto, não trouxe nada de bom à minha vida. Esse período deu-me uma autoestima muito baixa."

    # say L654 mia
    old "At the end I decided I couldn't take it anymore, so I just got away from it, and did everything I could to conceal that part of my past."
    new "B:mia: Além disso, causou-me depressão e ansiedade que duraram muito tempo."

    # say L655 mia
    old "Finally things worked out, but I had to change my entire life, move city, change name, everything. Just to get away from it."
    new "B:mia: No final decidi que não aguentava mais, então me afastei e fiz tudo o que podia para esconder essa parte do meu passado."

    # say L656 mia
    old "You can imagine then how hard it is for me to see that material is still out there, and somebody could see it."
    new "B:mia: Finalmente as coisas se resolveram, mas tive de mudar a minha vida toda, mudar de cidade, mudar de nome, tudo. Só para me afastar disso."

    # say L657 pla
    old "I mean, I get that. But what do you mean 'Still out there'?"
    new "B:mia: Podes imaginar então o quão difícil é para mim ver que esse material ainda está por aí, e alguém poder ver."

    # say L658 pla
    old "I imagine that whatever you filmed before would just be on the internet, right?"
    new "T(pla|tu|say): Imagino que o que tu filmaste antes já esteja na internet, certo?"

    # say L659 pla
    old "Why is it weird that Denzel has pictures and videos of you?"
    new "B:pla: Imagino que o que tu filmaste antes já esteja na internet, certo?"

    # say L660 mia
    old "Because..."
    new "A:mia: Mesmo trabalhando muito, nunca saí realmente da universidade, por isso quando saí da indústria pornográfica, quis trabalhar no que tinha estudado."

    # say L661 mia
    old "Even though I was working hard, I never actually left college, so when I got out of porn, I wanted to work on what I had studied."
    new "B:mia: Porque..."

    # say L662 mia
    old "It may be because I was so young, but I didn't think my previous job was going to be an issue."
    new "B:mia: Apesar de me esforçar muito, nunca saí realmente da universidade, por isso, quando saí da indústria pornográfica, quis trabalhar naquilo que tinha estudado."

    # say L663 mia
    old "Nobody wanted to hire, a lot of parents, teachers, and principals at schools had seen my work."
    new "B:mia: Pode ser porque eu era tão nova, mas não pensei que o meu trabalho anterior fosse ser um problema."

    # say L664 mia
    old "Ugh, they believed it was inappropriate for me to teach the children..."
    new "B:mia: Ninguém quis contratar, muitos pais, professores e diretores de escolas tinham visto o meu trabalho."

    # say L665 mia
    old "I suppose it wasn't to jack up to my face."
    new "B:mia: Ugh, acreditaram que era inapropriado para mim ensinar as crianças..."

    # say L666 mia
    old "Anyway, I decided that since I wasn't working in that industry any longer I didn't want my videos and pictures out there."
    new "B:mia: Suponho que não era para se aproximar do meu rosto."

    # say L667 mia
    old "So, I sued my previous producer, and I managed to get everything taken down."
    new "B:mia: De qualquer forma, decidi que, como já não trabalhava nessa indústria, não queria que os meus vídeos e fotos estivessem disponíveis."

    # say L668 pla
    old "Wow, that's amazing."
    new "T(pla|tu|say): Uau, isso é incrível."

    # say L670 mia
    old "But it didn't really fix things where I lived, in the end, I had to move... several times."
    new "B:pla: Uau, isso é incrível."

    # say L671 mia
    old "A lot of people in different places knew who I was. Finally, I came to this place, where nobody seems to know me."
    new "B:mia: Mas não resolveu realmente as coisas onde eu vivia, no final tive que mudar... várias vezes."

    # say L672 pla
    old "I understand, so you don't want people finding out about it."
    new "B:mia: Muitas pessoas em diferentes lugares sabiam quem eu era. Finalmente, vim para este lugar, onde ninguém parece me conhecer."

    # say L674 mia
    old "Of course not, it's taken me a lot of work to build a life for myself here."
    new "B:pla: Entendo, então tu não queres que as pessoas descubram."

    # say L676 pla
    old "I see, but how did he manage to get that material of you if it was all taken down?"
    new "B:mia: Claro que não, custou-me muito trabalho construir uma vida para mim aqui."

    # say L677 mia
    old "Honestly I have no idea, I've looked for hours on end for traces of my material."
    new "B:pla: Entendo, mas como é que ele conseguiu obter esse material teu se tudo já tinha sido removido?"

    # say L678 mia
    old "And I haven't been able to find anything, at all. So, it's a mystery to me that he was able to put his hands on it."
    new "B:mia: Honestamente, não tenho a mínima ideia, já procurei durante horas sem fim por vestígios do meu material."

    # say L679 mia
    old "And now he's using it to blackmail me, either I do what he demands, or he takes it to the principal and outs me in front of everybody."
    new "E agora ele está a usá-lo para me chantagear, ou eu faço o que ele exige, ou ele leva isso ao diretor e me expõe na frente de toda a gente."

    # say L680 mia
    old "After all this work! You have no idea how hard it's been for me to rebuild my life!"
    new "B:mia: E agora ele está a usar isso para me chantagear, ou eu faço o que ele exige, ou ele leva isso ao diretor e me expõe na frente de todos."

    # say L682 mia
    old "How much I enjoy teaching! Instead of...!"
    new "B:mia: Depois de todo este trabalho! Não sabes como tem sido difícil para mim reconstruir a minha vida!"

    # say L683 mia
    old "Instead of letting random actors do what they wanted to me on camera!"
    new "B:mia: Que prazer tenho em ensinar! Em vez de...!"

    # say L685 mia
    old "What's worse about it, is that ever since he began blackmailing me, I've given him more content to use."
    new "B:mia: Em vez de deixar atores aleatórios fazerem o que quisessem comigo em frente às câmaras!"

    # say L686 mia
    old "Being that desperate I've been following his orders, and he has a lot of stuff of me doing inappropriate things at school."
    new "B:mia: O pior é que, desde que ele começou a chantagear-me, tenho dado mais conteúdo para ele usar."

    # say L687 mia
    old "Like that picture he took of us..."
    new "B:mia: Tão desesperada que tenho estado a seguir as suas ordens, e ele tem muitas coisas minhas a fazer coisas impróprias na escola."

    # say L689 pla
    old "Listen, Ms. Mia, we'll do everything we can to stop him."
    new "B:mia: Gostaste daquela fotografia que ele tirou de nós..."

    # say L691 mia
    old "Oh really? How?"
    new "B:pla: Escuta, Sra. Mia, faremos tudo o que pudermos para o impedir."

    # say L692 pla
    old "Uh... I don't really know yet, but there must be a way."
    new "T(pla|tu|say): Hum... Ainda não sei bem, mas deve haver uma maneira."

    # say L694 pla
    old "Maybe we can hack his computer, or follow him and steal it from him."
    new "T(pla|tu|say): Talvez possamos hackear o seu computador, ou segui-lo e roubar-lhe."

    # say L695 pla
    old "Or maybe there's something we can use against him, like his place of work, or something like..."
    new "B:pla: Talvez possamos hackear o seu computador, ou segui-lo e roubá-lo."

    # say L696 mia
    old "Ok, enough! Who do you think you're talking to? Don't you think I already thought about every way I could handle this?"
    new "B:pla: Ou talvez haja algo que possamos usar contra ele, como o local de trabalho dele, ou algo assim..."

    # say L697 mia
    old "All of these suggestions of yours are very nice, but they amount to nothing."
    new "B:mia: Ok, chega! Com quem é que tu estás a falar? Não achas que eu já pensei em todas as maneiras de lidar com isto?"

    # say L698 mia
    old "So, I think it's better if we no longer talk about it, I'll deal with Denzel by myself."
    new "B:mia: Todas estas sugestões tuas são muito boas, mas não valem nada."

    # say L699 pla
    old "What? B-but Miss Mia, I really want to help you, and..."
    new "B:mia: Então, acho melhor não falarmos mais nisso, eu lidarei com Denzel sozinha."

    # say L702 mia
    old "Class Is about to start, your classmates will arrive soon and I don't want them catch us talking about this. So drop it!"
    new "B:pla: Mas."

    # say L722 pla
    old "Fine."
    new "B:mia: A aula vai começar, os teus colegas vão chegar e não quero que nos apanhem a falar disto. Portanto, deixa estar!"

    # say L734 mia
    old "Ok, from today on we'll talk about Latin American political history in the twentieth century."
    new "E começaremos com o golpe de Estado em Cuba..."

    # say L735 mia
    old "And we'll start with the Cuban coup d'etat..."
    new "B:mia: Ok, a partir de hoje vamos falar sobre a história política da América Latina no século XX."

    # say L741 mia
    old "Ok, that's all for today, I hope you took proper notes of the class."
    new "B:mia: E vamos começar com o golpe de Estado cubano..."

    # say L742 mia
    old "Remember to practice the subject at home, the test is very close, so don't relax too much and forget to study."
    new "B:mia: Ok, isso é tudo para hoje, espero que tenhas tomado notas adequadas da aula."

    # say L743 mia
    old "I know it sounds like a lot of work, but you have to do this if you want to properly learn all your subjects before the end of term tests."
    new "B:mia: Lembra-te de praticar o assunto em casa, o teste está muito perto, por isso não te relaxes demasiado e esqueças de estudar."

    # say L745 mik
    old "See you at the next class guys."
    new "B:mia: Eu sei que parece muito trabalho, mas tens de fazer isto se quiseres aprender bem todas as disciplinas antes dos testes finais."

    # say L769 pla
    old "Oh! It's you."
    new "B:mik: Até à próxima aula, pessoal."

    # say L772 den
    old "I came to see you, we need to talk."
    new "B:pla: Oh! És tu."

    # say L773 pla
    old "Do we?"
    new "T: Tu: Sobre o quê?"

    # say L774 pla
    old "About what?"
    new "A:den: Sobre a Mia, claro, quero que trabalhes comigo."

    # say L775 den
    old "About Mia, of course, I want you to work with me."
    new "T(den|tu|diz): Sobre a Mia, claro, quero que trabalhes comigo."

    # say L776 pla
    old "You what?"
    new "T: Tu o quê?"

    # say L777 den
    old "Yeah dude, listen, she has no way to get out of this."
    new "B:pla: O quê?"

    # say L778 den
    old "I have all the information, and the videos and pictures. We can both use it to get revenge on her."
    new "B:den: Opa, escuta, ela não tem como se safar disto."

    # say L779 pla
    old "Come on, revenge? Really?"
    new "A:den: Ouve, sei que ela tem sido terrível contigo, certo?"

    # say L781 den
    old "Listen, I know she's been terrible to you, right?"
    new "B:pla: Vamos, vingança? A sério?"

    # say L782 den
    old "If we both work together, we can make that little bitch pay for everything she's done to us."
    new "B:den: Escuta, sei que ela tem sido terrível contigo, certo?"

    # say L783 den
    old "Besides, imagine all the things you can get her to do to you, just by telling her you'll release the pictures."
    new "B:den: Se trabalharmos juntos, podemos fazer essa putinha pagar por tudo o que nos fez."

    # say L784 den
    old "We'll make sure that she pays like the little slut she is."
    new "B:den: Além disso, imagina todas as coisas que ela pode fazer por ti, só por dizeres que vais libertar as fotos."

    # say L785 den
    old "What do you say, huh?"
    new "B:den: Vamos garantir que ela pague como a putinha que é."

    # say L786 pla
    old "What's wrong with you dude?! Revenge?! Make her pay? Slut?"
    new "B:den: E então, hã?"

    # say L787 pla
    old "Are you really that twisted? The fuck?! This is a person's life you're talking about!"
    new "B:pla: O que é que tens, cara?! Vingança?! Fazê-la pagar? Puta?"

    # say L789 pla
    old "You would destroy her life just because she was a little mean to you?"
    new "B:pla: Tu estás mesmo assim tão retorcido? Que raio?! Estamos a falar da vida de uma pessoa!"

    # say L790 pla
    old "There's something seriously wrong with you dude..."
    new "B:pla: Tu destruirias a vida dela só porque ela foi um pouco má contigo?"

    # say L791 den
    old "Oh, so that's how it is, I thought you would understand, but it turns out you're just one of those moralist idiots."
    new "B:pla: Há algo realmente errado contigo, meu..."

    # say L792 pla
    old "I'm an molarist idiot? You're the one who thinks he can destroy someone's life and get away with it."
    new "T(pla|tu|say): Sou um moralista idiota? Tu és que pensas que podes destruir a vida de alguém e ficar impune."

    # say L793 den
    old "Don't give me that bullshit! Listen pal, Mia's just a simple whore who enjoys making others suffer."
    new "B:pla: Sou um idiota molarista? Tu és quem pensa que pode destruir a vida de alguém e ficar impune."

    # say L794 den
    old "What's wrong with making her pay for all of the bad shit she does?"
    new "B:den: Não me venhas com essa conversa! Ouve, a Mia é só uma puta simples que gosta de fazer sofrer os outros."

    # say L795 den
    old "After all, it's just giving her a taste of her own medicine."
    new "B:den: O que há de mal em fazer com que ela pague por todas as merdas que faz?"

    # say L796 pla
    old "What's wrong with you? I won't do anything like that, you asshole."
    new "B:den: Afinal, é só dar-lhe um gosto do seu próprio remédio."

    # say L797 pla
    old "It's true that Mia has a bad temper and a strong character, but not enough for you to justify destroying her life."
    new "B: O que é que tens? Não vou fazer nada desse género, seu idiota."

    # say L798 pla
    old "You're just hung up on some shit that happened a long time ago and you haven't been able to let it go."
    new "B:pla: É verdade que a Mia tem um temperamento difícil e uma personalidade forte, mas não o suficiente para justificares destruir a vida dela."

    # say L800 den
    old "You're even more fucking stupid than I thought!"
    new "B:pla: Tu estás apegado a algo que aconteceu há muito tempo e não conseguiste largar."

    # say L801 den
    old "But it's ok dude, you'll understand, after all, I can still punish Mia by myself."
    new "B:den: Tu és ainda mais estúpido do que eu pensava!"

    # say L803 pla
    old "Whatever you say dude, I don't want anything to do with you or your sick plans."
    new "B:den: Mas tudo bem, vais perceber, afinal, ainda posso castigar a Mia sozinho."

    # say L804 den
    old "Yeah well, remember this, I'll take my revenge on Mia, and one way or another you'll have to do with it."
    new "B:pla: Como quiseres, não quero nada a ver contigo nem com os teus planos doentios."

    # say L815 pla
    old "Wow, what is wrong with that guy?"
    new "B:den: Pois bem, lembra-te disto, vou vingar-me da Mia, e de uma maneira ou de outra tu vais ter de lidar com isso."

    # say L823 pla
    old "Oh, hey Belle, morning."
    new "B:pla: Que se passa com aquele tipo?"

    # say L824 bel
    old "Hey, who was that guy that was talking with you at the entrance? He looked like he was angry, were you arguing?"
    new "B:pla: Oh, hey Belle, bom dia."

    # say L825 pla
    old "Oh, him? He's just some guy I know, don't worry about it."
    new "B:bel: Ei, quem era aquele tipo que estava a falar contigo à entrada? Parecia zangado, estavam a discutir?"

    # say L827 bel
    old "Hmm, I thought that maybe he has something to do with Ms. Mia."
    new "B:pla: Oh, ele? É só um conhecido, não te preocupes com isso."

    # say L828 pla
    old "W-why do you think that?"
    new "B:bel: Hmm, pensei que talvez ele tenha algo a ver com a Sr.ª Mia."

    # say L829 pla
    old "Did you hear anything?"
    new "B:pla: P-porquê que pensas isso?"

    # say L831 bel
    old "Well, it's just that lately, I've seen you talking with Ms. Mia, so I figured that maybe he had something to do with it."
    new "B:pla: Ouviste alguma coisa?"

    # say L833 pla
    old "Uhhh, no, no, he has nothing to do with it."
    new "B:bel: Bem, é que ultimamente tenho visto tu a falar com a Sr.ª Mia, então pensei que ele tivesse algo a ver com isso."

    # say L834 pla
    old "I've just been talking to Ms. Mia about my grades, you know she's always harping on me."
    new "B:pla: Uhhh, não, não, ele não tem nada a ver com isso."

    # say L836 bel
    old "Oh, I see, I guess you do need to pay attention to your grades."
    new "B:pla: Acabei de falar com a Sr.ª Mia sobre as minhas notas, sabes, ela está sempre a insistir comigo."

    # say L846 mia
    old "Hey, it's time for classes, so come in!"
    new "B:bel: Oh, percebo, acho que precisas mesmo de prestar atenção às tuas notas."

    # say L851 mia
    old "Ok guys, it's time to start preparing for the midterm test, so today we'll do a couple of mock tests to help you get ready for it."
    new "B:mia: Ei, é hora das aulas, entra!"

    # say L856 mia
    old "So, I hope you found the excersises useful, remember to practice again at home, the test is very close, so don't relax too much and forget to study."
    new "B:mia: Bem, pessoal, é hora de começarmos a preparar-nos para o teste intercalar, por isso hoje vamos fazer alguns testes simulados para vos ajudar a preparar-vos para ele."

    # say L909 mia
    old "Denzel called me and was very fucking angry! He said you were gonna pay him for saying what you said!"
    new "B:mia: Que raio fizeste tu?! Tu és um idiota! Disse-te para ficares fora disto!"

    # say L910 mia
    old "What did you do?!"
    new "B:mia: O Denzel ligou-me e estava muito mas muito zangado! Disse que tu ias pagar-lhe por aquilo que disseste!"

    # say L911 pla
    old "Nothing, nothing! I swear to God! He's the one that came to talk to me this morning, when I was arriving at school!"
    new "B:mia: O que é que fizeste?!"

    # say L912 pla
    old "He wanted me to allie with him and help him mess with you."
    new "B:pla: Nada, nada! Juro por Deus! Foi ele que veio falar comigo esta manhã, quando eu estava a chegar à escola!"

    # say L913 pla
    old "But I told him no, that I wasn't gonna be part of it."
    new "B:pla: Ele quis que eu me aliásse a ele e ajudasse a fazer-te mal."

    # say L914 mia
    old "Oh FUCK! Why did you have to get involved with this!"
    new "B:pla: Mas eu disse que não, que não ia participar nisso."

    # say L915 mia
    old "This has nothing to do with you!"
    new "B:mia: Oh MERDA! Porque é que tiveste de te envolver nisto!"

    # say L916 mia
    old "Because of what you told him he's now fucking angry!"
    new "B:mia: Isto não tem nada a ver contigo!"

    # say L919 mia
    old "Do you get it?!"
    new "B:mia: Não fale com esse cara, não faça contato. Nada!"

    # say L920 pla
    old "Whatever you say, but that guy is the one that came to me, and you know he's insane."
    new "T(pla|tu|diz): O que tu quiseres, mas foi esse tipo que veio falar comigo, e tu sabes que ele é maluco."

    # say L936 den
    old "I came to visit, I had to see my favorite teacher."
    new "B:pla: Como queiras, mas esse tipo foi ter comigo, e tu sabes que ele está louco."

    # say L942 pla
    old "Dude, don't you have anything else to do besides stalking Ms. Mia all day?"
    new "B:den: Bom, bom, exactamente o que esperava."

    # say L943 den
    old "Heh, you shouldn't worry that much about what I do to fill my time."
    new "B:pla: Cara, não tens nada melhor para fazer além de seguir a Sr.ª Mia o dia inteiro?"

    # say L944 den
    old "It's more interesting what you're about to do!"
    new "B:den: Heh, não deves preocupar-te tanto com o que eu faço para preencher o meu tempo."

    # say L945 den
    old "After all, I think it's about time that you two start."
    new "B:den: É mais interessante o que vais fazer!"

    # say L947 den
    old "'Ms.' Mia, you haven't told him about the new challenge?"
    new "B:den: Afinal, acho que é hora de vocês começarem."

    # say L949 mia
    old "Don't even think about Denzel."
    new "B:den: 'Sr.ª' Mia, ainda não lhe disse sobre o novo desafio?"

    # say L950 mia
    old "It's not happening! No way in hell!"
    new "B:mia: Nem sequer penses no Denzel."

    # say L951 den
    old "Well, that surprises me, I guess that you don't mind then about the school principal receiving an interesting mail, do you?"
    new "B:mia: Não vai acontecer! Nem pensar!"

    # say L953 pla
    old "Wait, what's happening? What did you ask this time."
    new "B:den: Bem, isso surpreende-me, acho que tu não te importas então com o diretor da escola receber um e-mail interessante, certo?"

    # say L955 den
    old "Tell him, Mia."
    new "B:pla: Espera, o que está a acontecer? O que é que perguntaste desta vez."

    # say L958 pla
    old "There's something seriously wrong with you pal! That's way too far! I'm going to the police!"
    new "B:pla: Que?! Que merda?!"

    # say L959 den
    old "HA! Do it! Fine by me!"
    new "B:pla: Há algo seriamente errado contigo, meu amigo! Isso foi longe demais! Vou à polícia!"

    # say L960 den
    old "I mean, sure, maybe I'll get trial for blackmail, nothing severe 'cause you don't have any evidence..."
    new "B:den: HA! Faz isso! Tudo bem para mim!"

    # say L962 den
    old "But what's gonna happen when they review the photos and videos I got from you, what do you think will happen then, eh [pla]?"
    new "T: Mas o que vai acontecer quando eles analisarem as fotos e vídeos que eu tenho de ti, hein [pla]?"

    # say L963 den
    old "All of that is gonna come out to the public, and everyone will know Mia used to be a pornstar."
    new "Mas isso não é a pior parte."

    # say L964 den
    old "But that's not the worst part."
    new "B:den: Tudo isso vai ser divulgado ao público, e todos vão saber que a Mia já foi atriz pornográfica."

    # say L965 den
    old "What will really make people angry is the fact that she's fucking her students."
    new "B:den: Mas isso não é a pior parte."

    # say L966 den
    old "Imagine what will happen then, hahaha."
    new "B:den: O que realmente vai deixar as pessoas furiosas é o facto de ela estar a foder com os seus alunos."

    # say L967 pla
    old "W-what?! Fucking her student? The hell are you talking about?"
    new "T(pla|tu|say): Q-que?! A foder a tua aluna? Que raio estás a dizer?"

    # say L968 den
    old "I suppose you remember that picture I took of you the other day."
    new "B:pla: Q-que?! A foder a aluna dela? Do que estás a falar?"

    # say L969 den
    old "Come on, everybody will believe that you two have been fucking anyway."
    new "B:den: Suponho que te lembres daquela fotografia que tirei de ti outro dia."

    # say L970 den
    old "I'll just make it a reality."
    new "B:den: Vamos, todo o mundo vai acreditar que vocês dois estiveram a foder de qualquer maneira."

    # say L971 pla
    old "You're sick dude!"
    new "B:den: Vou torná-lo realidade."

    # say L974 pla
    old "You can't be serious!"
    new "T(pla|tu|say): Não podes estar a falar a sério!"

    # say L975 pla
    old "You can't let this guy get away with something like that! We have to go to the police!"
    new "T: Não podes deixar este tipo safar-se com uma coisa dessas! Temos de ir à polícia!"

    # say L976 mia
    old "And then what?! You heard him! If we go to the police my life will be ruined!"
    new "B:pla: Não podes deixar este tipo safar-se com uma coisa destas! Temos de ir à polícia!"

    # say L977 mia
    old "Besides, with the other photos that he has, he could also drag you down with me!"
    new "B:mia: E então?! Tu ouviste-o! Se formos à polícia, a minha vida vai ser arruinada!"

    # say L978 pla
    old "Hmph!"
    new "B:mia: Além disso, com as outras fotos que ele tem, também poderia arrastar-te comigo!"

    # say L984 den
    old "Fantastic! I knew you guys would come around!"
    new "B:mia: Ok, Denzel, vamos fazê-lo."

    # say L985 den
    old "Ok, let's get to it!"
    new "B:den: Fantástico! Sabia que vocês iam acabar por concordar!"

    # say L986 mia
    old "What? Here? Now?"
    new "B:den: Ok, vamos a isso!"

    # say L987 den
    old "What would be better?"
    new "B:mia: O quê? Aqui? Agora?"

    # say L988 den
    old "It's ok, I don't think the janitor will come anytime soon. So nobody will notice us."
    new "B:den: O que seria melhor?"

    # say L989 pla
    old "Wait, 'us'? Does that mean you're gonna be here while we do it?"
    new "B:den: Não te preocupes, acho que o vigilante não virá tão cedo. Portanto, ninguém nos notará."

    # say L991 den
    old "Of course I'm serious! What else am I going to do?"
    new "B:pla: Espera, 'nós'? Isso quer dizer que tu vais estar aqui enquanto nós o fazemos?"

    # say L992 den
    old "Besides, you can't be angry about it Mia, you're used to fucking in front of other people, right? This should be easy for you."
    new "B:den: Claro que estou a falar a sério! O que mais vou fazer?"

    # say L993 den
    old "Just close your eyes and imagine it's the good old days. You whore."
    new "B:den: Além disso, não podes estar zangada com isso, Mia, tu estás habituada a foder na frente de outras pessoas, certo? Isto deve ser fácil para ti."

    # say L994 den
    old "Oh, by the way, remember to take your tits out. You've been keeping them hidden, and I think it's time for you to let them out."
    new "B:den: Fecha os olhos e imagina que são os bons e velhos tempos. Tu puta."

    # say L995 mia
    old "You're fucking pathetic."
    new "B:den: Oh, a propósito, lembra-te de tirar os peitos. Tens estado a escondê-los, e acho que é altura de os deixares à vista."

    # say L996 den
    old "Hehehe, sure, sure."
    new "T: Hehehe, claro, claro."

    # say L1005 den
    old "I bet you're happy getting drilled by that cock."
    new "B:den: Hehehe, claro, claro."

    # say L1006 mia
    old "Ugh, whatever dude."
    new "A:mia: Estamos a fazer isto só porque nos estás a forçar, seu idiota."

    # say L1007 mia
    old "We're only doing this because you're forcing us, you ass."
    new "B:mia: Ugh, whatever."

    # say L1008 den
    old "You know, you're making me sound like the bad guy, but I'm sure you're enjoying this."
    new "B:mia: Estamos a fazer isto só porque tu estás a obrigar-nos, seu idiota."

    # say L1009 den
    old "You may fool yourself and others with this whole 'teacher' thing, but I know that you're really a whore."
    new "B:den: Sabes, estás a fazer-me parecer o vilão, mas tenho a certeza de que estás a gostar disto."

    # say L1010 mia
    old "You're sick."
    new "B:den: Podes enganar-te e enganar os outros com essa história toda de 'professora', mas eu sei que tu és realmente uma puta."

    # say L1011 den
    old "Hahaha, you keep fucking like the bitch you are."
    new "B:mia: Tu estás doente."

    # say L1023 mia
    old "Oh come on!"
    new "B:den: Hahaha, tu continuas a foder como uma cadela."

    # say L1025 pla
    old "Come on dude!"
    new "Oh, desculpa, interrompi vocês quando estavam a ter um momento tão doce juntos."

    # say L1026 den
    old "Oh, I'm sorry, I interrupted you guys when you were having such a sweet time together."
    new "B:pla: Vamos lá, rapaz!"

    # say L1028 den
    old "I'm so rude."
    new "B:den: Oh, desculpa, interrompi vocês num momento tão doce."

    # say L1029 den
    old "But you see, now I have actual evidence that you guys fucked!"
    new "B:den: Sou tão mal-educado."

    # say L1030 den
    old "I guess that means that I now have two bitches instead of just one. Am I right?"
    new "B:den: Mas vês, agora tenho provas de que vocês foderam!"

    # say L1031 den
    old "Hahahahahahahaha."
    new "B:den: Acho que isso significa que agora tenho duas cadelas em vez de uma. Estou certo?"

    # say L1034 den
    old "I think I should get going, but don't worry guys, I'll be seeing you soon."
    new "B:mia: Tu és mesmo retorcido."

    # say L1039 pla
    old "There's something seriously wrong with that guy's head."
    new "B:den: Acho que devo ir-me embora, mas não se preocupem, vou ver-vos em breve."

    # say L1048 pla
    old "We can't just give in to what that maniac wants."
    new "B:pla: Ouve, Mia, sei que o que acabou de acontecer é desanimador, mas tenho a certeza de que devemos haver algo que possamos fazer."

    # say L1049 mia
    old "No, there isn't anything, he's already got us."
    new "B:pla: Não podemos simplesmente ceder ao que esse maníaco quer."

    # say L1050 mia
    old "It's just as he says, we're his bitches."
    new "B:mia: Não, não há nada, ele já nos tem."

    # say L1051 mia
    old "Let's just leave it at that."
    new "B:mia: É como ele diz, somos as suas cadelas."

    # say L1056 pla
    old "Damn it, there has to be something I can do, I'm sure of it."
    new "B:mia: Vamos ficar por aqui."

    # say L1077 mia
    old "Oh, thanks God, I found you! Please come here for a minute."
    new "B:pla: Maldição, tem de haver algo que eu possa fazer, tenho a certeza."

    # say L1084 mia
    old "Listen, I have to tell you something."
    new "B:mia: Oh, graças a Deus, encontrei-te! Por favor, vem aqui um minuto."

    # say L1085 mia
    old "Denzel called me, he gave us another 'challenge'."
    new "B:mia: Escuta, tenho de te dizer uma coisa."

    # say L1086 pla
    old "What? Are you for real?"
    new "B:mia: O Denzel ligou-me, ele deu-nos outro 'desafio'."

    # say L1087 pla
    old "What does he want now?"
    new "B:pla: O quê? Estás a brincar comigo?"

    # say L1088 mia
    old "Well, every time he's given me a new 'challenge' to do, they have been getting riskier and riskier."
    new "B:pla: O que ele quer agora?"

    # say L1089 mia
    old "This time is the same, he wants us to... Have sex in the school bathroom."
    new "B:mia: Bem, cada vez que me dá um novo 'desafio' para fazer, eles têm ficado cada vez mais arriscados."

    # say L1091 pla
    old "Woah! Really? But that's way too risky!"
    new "B:mia: Desta vez é a mesma coisa, ele quer que a gente... Tenha sexo no banheiro da escola."

    # say L1092 pla
    old "I mean, last time everyone had already gone home. What will happen if someone sees us?"
    new "B:pla: Uau! A sério? Mas isso é muito arriscado!"

    # say L1093 mia
    old "I already thought of that, that's why I'm telling you now because everyone else is in their classrooms."
    new "B:pla: Quero dizer, da última vez todos já tinham ido para casa. E se alguém nos vir?"

    # say L1094 mia
    old "If we do it now nobody should see us."
    new "B:mia: Já pensei nisso, por isso estou a dizer-te agora porque todos os outros estão nas salas de aula."

    # say L1096 pla
    old "So we should go have sex in the bathroom now?"
    new "B:mia: Se fizermos agora, ninguém deve ver-nos."

    # say L1097 mia
    old "That's right, he said I have to do a video call... for him to see us."
    new "B:pla: Então devemos ir fazer sexo na casa de banho agora?"

    # say L1098 pla
    old "Jesus! What the hell is wrong with that freak?!"
    new "B:mia: É verdade, ele disse que tenho de fazer uma vídeochamada... para ele nos ver."

    # say L1099 pla
    old "No way we're doing that."
    new "B:pla: Jesus! Que raio de problema tem esse doido?!"

    # say L1100 mia
    old "Not this again..."
    new "B:pla: Nem pensar."

    # say L1103 pla
    old "Hmm, yeah, you're right."
    new "B:mia: Por favor, não me faças implorar de novo, preciso mesmo que me ajudes."

    # say L1104 pla
    old "{i}*Sigh*{/i} Ok, let's go then."
    new "T(pla|tu|say): {i}*Suspiro*{/i} Ok, vamos então."

    # say L1112 mia
    old "As I already told you, we don't have any other choice."
    new "B:pla: Eu sei que tenho colocado muitos obstáculos, mas tens a certeza disto?"

    # say L1113 pla
    old "Hmph, yeah, yeah, you're right."
    new "B:mia: Como já te disse, não temos outra escolha."

    # say L1115 mia
    old "Ok, let's call this asshole."
    new "B:pla: Hmph, sim, sim, tens razão."

    # narrator L1116 
    old "... Ringing ..."
    new "A:den: Olá! Uau, vocês estão cedo!"

    # say L1117 den
    old "Hello! Wow, you guys are early!"
    new "B:n:... Ringing..."

    # say L1118 den
    old "This is the perfect location, isn't it Mia?"
    new "B:den: Olá! Uau, vocês estão cedo!"

    # say L1119 den
    old "A dirty little place for a dirty little whore. Hahaha."
    new "B:den: Este é o local perfeito, não é Mia?"

    # say L1123 den
    old "Hahaha, whatever, let's just get started with this."
    new "B:pla: Foda-se, cara! Não penses que vais continuar a safar-te disto por muito mais tempo."

    # say L1124 den
    old "Oh! And remember to take your tits out Mia, I'm recording this, so I want it to be good quality."
    new "B:den: Hahaha, whatever, vamos começar com isto."

    # say L1134 den
    old "Oh yeah, just like that, nice."
    new "A:bel: Ai, que nojo, detesto Educação Física! Estou tão suada!"

    # say L1141 bel
    old "My gosh, I hate P.E. so much! I'm so sweaty!"
    new "B:den: Oh yeah, assim mesmo, bem assim."

    # say L1146 bil
    old "Now I'm gonna have to re-do it all over again!"
    new "B:bil: Ugh, eu sei, olha só para a minha maquilhagem!"

    # say L1147 bel
    old "Hey, by the way, had you noticed how Mia is acting lately?"
    new "B:bil: Agora tenho de fazer tudo de novo!"

    # say L1148 bil
    old "Oh my god yeah! She's acting like a whore, flashing off in front of the whole classroom!"
    new "Oh meu deus, sim! Ela está a comportar-se como uma puta, a mostrar-se à frente de toda a sala de aula!"

    # say L1152 bil
    old "What was that?"
    new "B:bil: Oh my god yeah! Ela está a agir como uma puta, a mostrar-se à frente de toda a sala de aula!"

    # say L1153 bel
    old "Like... a voice?"
    new "B:bil: O que foi isso?"

    # say L1159 bel
    old "Hmm, it's nothing, maybe somebody spoke in the hall."
    new "B:bel: Como... uma voz?"

    # say L1160 bil
    old "Yeah, you're right."
    new "B:bel: Hmm, não é nada, talvez alguém tenha falado no corredor."

    # say L1161 bel
    old "Ok, I'm ready."
    new "B:bil: Sim, tens razão."

    # say L1162 bil
    old "Yeah, me too, let's go. Anyway, as I was telling you, what the fuck is wrong with Mia?"
    new "B:bel: Ok, estou pronto."

    # say L1167 pla
    old "Ok, ok, they are gone."
    new "B:bil: Sim, eu também, vamos lá. De qualquer forma, como te estava a dizer, o que raio se passa com a Mia?"

    # say L1168 den
    old "Ha! What's the matter Mia? Afraid of getting caught?"
    new "B:pla: Ok, ok, eles foram embora."

    # say L1169 den
    old "But I know you like people seeing your pussy! What's the big deal?"
    new "B:den: Ha! Que se passa, Mia? Com medo de ser apanhada?"

    # say L1183 pla
    old "At the end it won't matter if he tells on us or not!"
    new "B:pla: Merda, isto está a ficar cada vez mais arriscado!"

    # say L1184 pla
    old "People will end up catching us anyway!"
    new "T(pla|tu|say): As pessoas acabarão por apanhar-nos de qualquer maneira!"

    # say L1186 pla
    old "We have to do something."
    new "B:pla: As pessoas acabarão por apanhar-nos de qualquer maneira!"

    # say L1188 mia
    old "I'm also not happy with this. And It's already started to affect me, I can't even sleep well."
    new "B:pla: Temos de fazer algo."

    # say L1189 mia
    old "I'm starting to get severe anxiety again, and the nightmares have come back. But what can I do?"
    new "B:mia: Também não estou feliz com isso. E já começou a afetar-me, nem consigo dormir bem."

    # say L1190 mia
    old "We can't just go to the police! I don't want to lose my life! And now he has stuff that's even worse!"
    new "B:mia: Estou a começar a ter ansiedade severa de novo, e os pesadelos voltaram. Mas o que posso fazer?"

    # say L1191 pla
    old "I know this is hard, but there must be a solution."
    new "B:mia: Não podemos simplesmente ir à polícia! Não quero perder a minha vida! E agora ele tem coisas ainda piores!"

    # say L1192 mia
    old "Well, if there is one I don't know what it may be."
    new "B:pla: Eu sei que isto é difícil, mas tem de haver uma solução."

    # say L1193 mia
    old "Let's just let's get out of here before someone comes again."
    new "B:mia: Bem, se há um, não sei o que possa ser."

    # say L1198 pla
    old "(She's feeling really bad, I'm sorry for her.)"
    new "B:mia: Vamos, saiamos daqui antes que alguém volte."

    # say L1199 pla
    old "I bet there's something else I could do..."
    new "Hmmm... Mas eu tenho o SexNote..."

    # say L1200 pla
    old "Hmmm... But I do have the SexNote..."
    new "B:pla: Aposto que há outra coisa que eu posso fazer..."

    # say L1219 pla
    old "Hey Linett. How are you?"
    new "B:pla: Hmmm... Mas eu tenho o SexNote..."

    # say L1222 lin
    old "Oh, interesting."
    new "B:pla: Hmm, um pouco preocupado na verdade, tenho um pequeno problema de que gostaria que me ajudasses."

    # say L1224 pla
    old "Well, I know a person that's being blackmailed."
    new "B:lin: Oh, interessante."

    # say L1226 lin
    old "Blackmailed? What is that?"
    new "B:lin: Bem, eu conheço uma pessoa que está a ser chantageada."

    # say L1227 lin
    old "I've never heard of it, is it some type of tradition between humans?"
    new "T(lin|tu|say): Nunca ouvi falar nisso, é alguma tradição entre humanos?"

    # say L1229 pla
    old "Uhh, somebody being blackmailed means that somebody else is threatening them with something that they care about."
    new "T(pla|tu|say): Hum, alguém estar a ser chantageado significa que outra pessoa está a ameaçá-los com algo que lhes importa."

    # say L1230 pla
    old "That can be anything, something that belongs to them, or something they want."
    new "B: pla: Uhh, alguém estar a ser chantageado significa que outra pessoa está a ameaçá-los com algo que lhes importa."

    # say L1231 pla
    old "And if you don't do what that person wants, they'll punish you with what they have against you."
    new "B:pla: Isso pode ser qualquer coisa, algo que pertença a eles ou algo que eles queiram."

    # say L1232 lin
    old "Wow, that sounds horrible! You humans really are something else!"
    new "B:pla: E se tu não fizeres o que essa pessoa quer, eles vão punir-te com o que têm contra ti."

    # say L1233 lin
    old "The type of things you do to each other is always surprising."
    new "B:lin: Que horror! Vocês humanos são mesmo algo!"

    # say L1234 pla
    old "Yeah, well, this person I know is going through that. So, I'm trying to help her."
    new "B:lin: O tipo de coisas que vocês fazem um ao outro é sempre surpreendente."

    # say L1243 lin
    old "Oh, ok, so what is it?"
    new "T(lin|tu|say): Oh, ok, então qual é?"

    # say L1245 pla
    old "Uhhh, I'll tell you the story, this person we're talking about is my teacher."
    new "B:lin: Oh, ok, então o que é?"

    # say L1246 pla
    old "The thing is that some guy found some 'information' about her that she doesn't want anyone to see."
    new "B:pla: Uhhh, vou-te contar a história, a pessoa de quem estamos a falar é a minha professora."

    # say L1247 pla
    old "But there's no way of stopping him from putting it out there. At least not through anything we can do."
    new "Mas não há forma de impedir que ele o divulgue. Pelo menos, não com os meios que temos."

    # say L1249 pla
    old "So, I was thinking that maybe there's a way to do it through the SexNote."
    new "B:pla: Mas não há como impedir que ele o coloque lá. Pelo menos não com nada do que podemos fazer."

    # say L1250 lin
    old "What kind of information is this?"
    new "B:pla: Então, estava a pensar que talvez haja uma maneira de o fazer através do SexNote."

    # say L1251 pla
    old "It's videos and pictures, they must be safe in his computer or something."
    new "B:lin: Que tipo de informação é esta?"

    # say L1253 lin
    old "Well, don't you think it would just be easier if you steal his computer and delete that?"
    new "B:pla: São vídeos e fotos, devem estar guardados no computador dele ou algo assim."

    # say L1255 pla
    old "I don't think that would do anything, he wouldn't be that stupid not to make any copies of it."
    new "B:lin: Bem, não achas que seria mais fácil se roubasses o computador dele e apagasses isso?"

    # say L1256 pla
    old "Besides, he also remembers it all, if he just tells the police or the press or anyone what he knows, they could find something."
    new "B:pla: Não acho que isso vá fazer nada, ele não seria tão estúpido a ponto de não fazer cópias."

    # say L1257 lin
    old "Hmm, I see what you mean."
    new "T(lin|tu|say): Hmm, percebo o que queres dizer."

    # say L1258 lin
    old "So basically, what you want is a spell that'll change reality."
    new "B:lin: Hmm, percebo o que queres dizer. T(lin|tu|say): Então basicamente, o que tu queres é um feitiço que mude a realidade. A:pla: U-uh, c-como? A-acho que..."

    # say L1259 pla
    old "U-uh, w-what? I-I don't think..."
    new "B:lin: Então, basicamente, o que tu queres é um feitiço que mude a realidade."

    # say L1261 lin
    old "Well, that's what you need, isn't it?"
    new "B:pla: H-hã, q-que? A-acho que não..."

    # say L1262 lin
    old "I mean, you need every version of this information to disappear."
    new "B:lin: Bem, é isso que precisas, não é?"

    # say L1263 lin
    old "That includes his memories, so that he won't go around telling it to people."
    new "B:lin: Quero dizer, precisas que todas as versões dessa informação desapareçam."

    # say L1268 lin
    old "Something like that, there's a way to erase stuff magically... or at least their 'presence'."
    new "B:lin: Mas... Há uma forma..."

    # say L1270 pla
    old "'Presence'? W- what do you mean?"
    new "T(pla|tu|say): 'Presença'? Q- quer dizer com isso?"

    # say L1272 lin
    old "I mean just that, you humans live in a world full of traces, all of your technology is marked with traces of who you are."
    new "T(lin|tu|say): Refiro-me justamente a isso, vocês humanos vivem num mundo cheio de rastros, toda a vossa tecnologia está marcada com rastros de quem vocês são."

    # say L1273 lin
    old "Like those pictures that you take of each other and then you can save or send."
    new "B:lin: Quero dizer exatamente isso, vocês humanos vivem num mundo cheio de rastros, toda a vossa tecnologia está marcada com rastros de quem vocês são."

    # say L1274 lin
    old "But also memories, whatever traces left by time in the mind of someone else. That's also a 'presence'."
    new "B:lin: Como essas fotos que tiram umas das outras e depois podem guardar ou enviar."

    # say L1275 lin
    old "All of that can be gone. With a big spell."
    new "B:lin: Mas também memórias, quaisquer vestígios deixados pelo tempo na mente de outra pessoa. Isso também é uma 'presença'."

    # say L1276 lin
    old "I suppose that's what you mean when you say you want me to help you."
    new "B:lin: Tudo isso pode desaparecer com um grande feitiço."

    # say L1277 pla
    old "Uhh, I mean, I think I do, but I'm not sure. I- I don't really understand all what you said."
    new "T(pla|tu|say): Hum, quero dizer, acho que sim, mas não tenho a certeza. N- Não percebo bem tudo o que disseste."

    # say L1278 lin
    old "What I said is that I can use a spell that can erase all information about her, that's what you are asking me, right?"
    new "B:pla: Hã, quero dizer, acho que sim, mas não tenho a certeza. N- Não percebi bem tudo o que disseste."

    # say L1279 pla
    old "Yes! That's exactly what I need..."
    new "B:lin: O que eu disse é que posso usar um feitiço que pode apagar todas as informações sobre ela, é isso que estás a pedir, certo?"

    # say L1280 pla
    old "And if you have another spell for the bad guy, you know, something to make him forget all about her."
    new "B:pla: Sim! É exactamente isso que preciso..."

    # say L1282 lin
    old "Yeah, with the same spell the bad human doing the 'blackmail' thing, he won't even remember her."
    new "T(lin|tu|say): Sim, com o mesmo feitiço o humano mau que está a fazer a coisa de 'chantagem', ele nem sequer se lembrará dela."

    # say L1283 lin
    old "Everything about her would be forgotten."
    new "B:lin: Sim, com o mesmo feitiço, o humano má não se lembrará dela."

    # say L1284 lin
    old "If he can't remember anything about her, and all the information he has is also gone. That would solve your problem, would it not?"
    new "B:lin: Tudo sobre ela seria esquecido."

    # say L1285 pla
    old "Wow! Yeah, that's perfect!"
    new "B:lin: Se ele não se lembrar de nada sobre ela, e toda a informação que tem também desaparecer, isso resolveria o teu problema, não é?"

    # say L1286 lin
    old "All right, this spell is somewhat difficult to execute, but is possible."
    new "Tudo bem, este feitiço é um pouco difícil de executar, mas é possível."

    # say L1288 pla
    old "Ok, what do I need?"
    new "Hmm, para ser honesto, ainda não és muito bom com magia..."

    # say L1290 lin
    old "Hmm, to be honest, you're still not very good with magic..."
    new "T(lin|tu|say): Hmm, a ser sincero, ainda não és muito bom com magia..."

    # say L1291 lin
    old "So, I'll have to prepare a lot of things beforehand to make it easier for you to use that spell."
    new "B:lin: Hmm, a ser sincero, ainda não és muito bom com magia..."

    # say L1292 pla
    old "Oh, it can't be done today? I mean, I have a bit of an urgency with this..."
    new "B:lin: Então, vou ter de preparar muitas coisas antes para facilitar o uso desse feitiço."

    # say L1293 lin
    old "No, I'll need a couple of days to get everything ready, we can't afford any mistakes with this."
    new "B:pla: Oh, não se pode fazer hoje? Quero dizer, tenho uma certa urgência com isto..."

    # say L1294 pla
    old "Hmm, I guess that's fine if there's no way to do it now."
    new "B:lin: Não, vou precisar de alguns dias para preparar tudo, não podemos cometer erros com isso."

    # say L1295 pla
    old "Thanks for your help Linnet, I'm counting on you."
    new "B:pla: Hmm, acho que está bem se não há forma de o fazer agora."

    # say L1296 lin
    old "I'll do my best to help you, don't worry."
    new "B:pla: Obrigado pela tua ajuda, Linnet, estou a contar contigo."

    # say L1304 pla
    old "I knew it, magic should be useful for something."
    new "T: Com isto tenho a certeza que vou conseguir ajudar a Sr.ª Mia."

    # say L1305 pla
    old "With this I'm sure I'll be able to help Ms. Mia."
    new "B:pla: Eu sabia, a magia deve ser útil para alguma coisa."

    # say L1330 mia
    old "Just come with me."
    new "A:mia: O Denzel disse que quer falar connosco, deixa-me ligar-lhe e ponho a chamada em altifalante."

    # say L1345 mia
    old "Denzel said he wanted to talk to both of us, let me call him and I'll put the call on speaker."
    new "Mia: Denzel, olá."

    # say L1350 mia
    old "Denzel, hi."
    new "B:mia: O Denzel disse que quer falar connosco, deixa-me ligar-lhe e ponho a chamada em altifalante."

    # say L1352 pla
    old "I'm here."
    new "Ótimo, ótimo! Ok, pessoal, tenho pensado e cheguei a uma conclusão."

    # say L1354 den
    old "Excellent, excellent! Ok, guys, I've been thinking, and I came to a conclusion."
    new "B:pla: Estou aqui."

    # say L1356 den
    old "Well, I've decided that it's time for you two to take your relationship to the next level."
    new "B:den: Excelente, excelente! Ok, rapazes, tenho estado a pensar e cheguei a uma conclusão."

    # say L1357 den
    old "Given that you already consummated your teacher-student love."
    new "B:den: Bem, decidi que é altura de vocês dois levarem a vossa relação para o próximo nível."

    # say L1359 den
    old "I think you need to take the next step?"
    new "T(den|tu|say): Acho que precisas dar o próximo passo?"

    # say L1360 pla
    old "The next step? We already had sex, what do you even mean?"
    new "B:den: Acho que precisas dar o próximo passo?"

    # say L1361 pla
    old "Stop beating around the bush and tell us already!"
    new "B:pla: O próximo passo? Já tivemos sexo, o que é que tu queres dizer com isso?"

    # say L1362 den
    old "Easy there buddy! Trust me, you'll like what I have in store for you guys today."
    new "B:pla: Pára de dar voltas e diz logo!"

    # say L1365 den
    old "Well, I want you to fuck Mia in the ass. It's time she gets her ass fucked."
    new "B:den: Calma aí, amigo! Confia em mim, vais gostar do que tenho preparado para vocês hoje."

    # say L1367 pla
    old "W-what?!"
    new "B:den: Bem, quero que fodes a Mia no cu. É hora de ela levar uma boa dose na bunda."

    # say L1368 mia
    old "I-I can't do that, I've never done it before! Not even when I was a porn actress!"
    new "B:pla: O-que?!"

    # say L1369 den
    old "Well, I guess there's a first time for everything, am I right?"
    new "B:mia: N-Não consigo fazer isso, nunca fiz antes! Nem mesmo quando era atriz pornográfica!"

    # say L1370 den
    old "Of course you'll do it on video call with me so that I can record it."
    new "B:den: Bem, acho que tudo tem uma primeira vez, não é?"

    # say L1371 den
    old "We wouldn't want to waste that good material right?"
    new "B:den: Claro que vais fazer numa chamada de vídeo comigo para eu poder gravar."

    # say L1372 pla
    old "You're crazy if you think we'll do this!"
    new "B:den: Não queremos desperdiçar esse bom material, certo?"

    # say L1374 pla
    old "This is way too much! We're not doing anything!"
    new "T(pla|tu|say): Isto é demasiado! Não vamos fazer nada!"

    # say L1376 den
    old "Aww, this again dude?"
    new "B:pla: Isto é demasiado! Não estamos a fazer nada!"

    # say L1379 den
    old "It really tests my patience, so shut up and do it!"
    new "B:den: Só para depois fazer de qualquer maneira."

    # say L1380 pla
    old "We're not doing anything!"
    new "B:den: Isso realmente testa a minha paciência, então cala-te e faz isso!"

    # say L1383 mia
    old "If what he has on us comes out we'll both be ruined!"
    new "B:mia: Tu sabes que temos de o fazer. Não temos alternativa."

    # say L1384 pla
    old "No! Think about it!"
    new "B:mia: Se o que ele tem sobre nós vier a lume, ambos seremos arruinados!"

    # say L1385 pla
    old "What is it going to be next time?! He already made us do all those things! Next time he'll make us fuck in the principals office!"
    new "B:pla: Não! Pensa bem!"

    # say L1386 mia
    old "But we have to!"
    new "B:pla: O que vai ser da próxima vez?! Ele já nos fez fazer todas essas coisas! Da próxima vez ele vai nos fazer foder no gabinete do diretor!"

    # say L1387 pla
    old "No we don't, and I won't do anything!"
    new "B:mia: Mas temos que fazer!"

    # say L1388 den
    old "That so? Well, then I guess you leave me no choice."
    new "B:pla: Não, não fazemos, e eu não vou fazer nada!"

    # say L1389 den
    old "I suppose this was gonna happen anyway, I was already getting bored with you two."
    new "B:den: Isso mesmo? Bem, então acho que não me deixa escolha."

    # say L1390 mia
    old "Wait! Wait! Give us a minute, I can convince him!"
    new "B:den: Suponho que isto ia acontecer de qualquer forma, já estava a ficar aborrecido com vocês duas."

    # say L1391 den
    old "You already heard him Mia, he's not gonna do anything."
    new "B:mia: Espera! Espera! Dá-nos um minuto, eu consigo convencê-lo!"

    # say L1392 den
    old "So, I guess he's fine with me sending the information out."
    new "B:den: Tu já ouviste o que ele disse, Mia, ele não vai fazer nada."

    # say L1393 den
    old "And that's what I will do, I'll send it straight to your school's principal."
    new "B:den: Então, acho que ele está bem comigo enviando as informações."

    # say L1394 den
    old "I'll be eager to see how things pan out for you 'Ms.' Mia."
    new "B:den: E é isso que vou fazer, vou enviá-lo diretamente ao diretor da tua escola."

    # say L1395 mia
    old "No, please don't' do this!"
    new "B:den: Estarei ansioso por ver como as coisas se desenrolam para ti, 'Srª.' Mia."

    # say L1396 den
    old "I have to say it was an honor to be a student of Mia the pornstar."
    new "B:mia: Não, por favor, não faças isso!"

    # say L1397 den
    old "I bet that when things blow out, you'll get that job back in no time."
    new "B:den: Tenho de dizer que foi uma honra ser aluno da Mia, a actriz pornográfica."

    # say L1401 mia
    old "Oh, no, no, no, no, no!"
    new "B:mia: Espera... Olá? Denzel?? Olá?"

    # say L1411 mia
    old "Oh my gosh! Why did you do that? You idiot!!"
    new "B:mia: MERDA! ELE NÃO RESPONDE!"

    # say L1412 mia
    old "Don't you care what will happen to you?! Or me?!"
    new "B:mia: Ai meu Deus! Porque é que fizeste isso? Tu és um idiota!!"

    # say L1413 mia
    old "You said you wanted to help me, and this is what you do?!!"
    new "B:mia: Não te importas com o que vai acontecer contigo?! Ou comigo?!"

    # say L1414 mia
    old "You fucking asshole! What are we going to do now?!"
    new "B:mia: Tu disseste que querias ajudar-me, e isto é o que fazes?!!"

    # say L1415 pla
    old "You know he was going to do this sooner or later. He's that type of bastard."
    new "B:mia: Tu merda de pessoa! O que vamos fazer agora?!"

    # say L1416 mia
    old "Well, he did it now! So what are we going to do?!"
    new "A:pla: Calma, escuta, olha, ele andava sempre a falar de uma carta."

    # say L1417 pla
    old "Calm down, listen, look, he kept talking about a mail."
    new "T(pla|tu|say): Calma, escuta, ele falava de um correio. Isso significa que ele vai ter de o enviar por meios físicos, como um cd ou uma pen."

    # say L1418 pla
    old "Which means he's gonna have to send it through some physical means, a cd or a usb."
    new "B:pla: Calma, escuta, olha, ele continuava a falar de uma carta."

    # say L1419 mia
    old "So?!"
    new "B:pla: O que significa que ele vai ter de o enviar por meios físicos, um CD ou um USB."

    # say L1420 pla
    old "So, all we have to do is intercept it before it arrives. Even if it's an express delivery, that's going to take a little while."
    new "B:mia: Então?!"

    # say L1421 mia
    old "And then what? Even if we stop that, he still has copies!"
    new "B:pla: Então, só temos de interceptá-lo antes de chegar. Mesmo que seja uma entrega expresso, vai demorar um pouco."

    # say L1422 mia
    old "He could just send it to the police! Or the news! Or somewhere else!"
    new "B:mia: E depois? Mesmo que paremos isso, ele ainda tem cópias!"

    # say L1423 mia
    old "Then what?!"
    new "B:mia: Ele podia enviá-lo à polícia! Ou aos jornais! Ou a outro lugar!"

    # say L1424 pla
    old "Ha, I've got a way to deal with that."
    new "T: pla|tu|say: Ha, tenho uma maneira de lidar com isso."

    # say L1425 pla
    old "Listen, I'm going to need you to trust me on this, ok?"
    new "B:pla: Ha, tenho uma maneira de lidar com isso."

    # say L1426 pla
    old "If everything goes according to my plan, not only will everything remain a secret, you'll never have to worry about it ever again."
    new "B:pla: Ouve, vou precisar que confies em mim, ok?"

    # say L1428 mia
    old "What are you going to do?"
    new "B:pla: Se tudo correr conforme o meu plano, não só tudo permanecerá em segredo, como também nunca mais terás de te preocupar com isso."

    # say L1429 pla
    old "That... I can't tell you, but trust me, everything's going to be alright."
    new "B:mia: O que vais fazer?"

    # say L1430 pla
    old "All I have to do is go check if everything's ready."
    new "B:pla: Isso... não posso dizer-te, mas confia em mim, tudo vai correr bem."

    # say L1432 mia
    old "What are you talking about? You're not making any sense!"
    new "B:pla: Só tenho de ir ver se tudo está pronto."

    # say L1433 pla
    old "I know you don't get it right now, but you'll see... Please just trust me."
    new "B:mia: Do que estás a falar? Não estás a fazer sentido!"

    # say L1434 mia
    old "I guess I have no choice..."
    new "B:pla: Eu sei que não percebes agora, mas vais ver... Por favor, confia em mim."

    # say L1435 pla
    old "For now, we have to deal with what Denzel's about to send to the school principal."
    new "B:mia: Acho que não tenho escolha..."

    # say L1436 pla
    old "That's the priority."
    new "B:pla: Por agora, temos de lidar com o que o Denzel vai enviar ao diretor da escola."

    # say L1437 mia
    old "What do you propose then?"
    new "B:pla: Essa é a prioridade."

    # say L1438 pla
    old "I think we're gonna have to steal it."
    new "B:mia: O que propões então?"

    # say L1439 pla
    old "For now just stay here and check if a delivery guy comes, I'll go to my house to check on things."
    new "B:pla: Acho que vamos ter de roubar isso."

    # say L1441 mia
    old "Again, what are you talking about?!"
    new "B:pla: Por agora, fica aqui e vê se vem um entregador, vou à minha casa ver as coisas."

    # say L1442 pla
    old "As I said, you'll understand later."
    new "B:mia: Mais uma vez, do que estás a falar?!"

    # say L1443 pla
    old "But I really have to rush home, will you stay here and check if anything arrives?"
    new "B:pla: Como eu disse, vais perceber mais tarde."

    # say L1444 mia
    old "Yes, fine, I'll be here. You better know what you're doing."
    new "B:pla: Mas tenho mesmo de ir a casa, tu ficas aqui e vês se chega alguma coisa?"

    # say L1446 pla
    old "I really think I do. I'll be back soon."
    new "B:mia: Sim, está bem, vou estar aqui. Melhor saberes o que estás a fazer."

    # say L1451 mia
    old "I can't believe it, now everything depends on him..."
    new "B:pla: Acho mesmo que sim. Volto já."

    # say L1457 pla
    old "Hey! Linnet!"
    new "B:mia: Não posso acreditar, agora tudo depende dele..."

    # say L1459 pla
    old "I'm going to need that spell of yours right now."
    new "A:pla: Tu achas que podemos usar isso?"

    # say L1460 pla
    old "Do you think we can use it?"
    new "B:pla: Vou precisar desse feitiço teu agora."

    # say L1464 pla
    old "When do you think we'll be able to do it?"
    new "B:pla: Oh realmente?! Merda, eu preciso mesmo agora..."

    # say L1465 lin
    old "Well, if I'm quick with this, tomorrow, I'll need another day."
    new "B:pla: Quando é que achas que vamos conseguir fazer isso?"

    # say L1467 pla
    old "Hmm... Are you sure it'll be ready tomorrow?"
    new "B:lin: Bem, se for rápido com isto, amanhã, vou precisar de mais um dia."

    # say L1468 lin
    old "Yeah, it'll be difficult, but I can make it."
    new "B:pla: Hmm... Tens a certeza de que vai estar pronto amanhã? T(lin|tu|say): Sim, vai ser difícil, mas consigo fazer. A:pla: Ok, então acho que vamos ter de arranjar uma maneira de o fazer amanhã."

    # say L1469 pla
    old "Ok, then I guess we'll have to find a way to make it tomorrow."
    new "B:lin: Sim, vai ser difícil, mas consigo fazer."

    # say L1470 pla
    old "Please help me with that, I really need it as soon as possible."
    new "T(pla|tu|say): Por favor, ajuda-me com isso, preciso mesmo disso o mais rápido possível."

    # say L1471 lin
    old "Ok then I will continue working on the spell."
    new "B:pla: Por favor, ajuda-me com isso, eu realmente preciso disso o mais rápido possível."

    # say L1483 mia
    old "Hey, what happened? I have been waiting for you... Did you get what you need? Is everything solved?"
    new "B:lin: Ok, então vou continuar a trabalhar no feitiço."

    # say L1484 pla
    old "Hmm, n-not really."
    new "B:mia: Ei, o que aconteceu? Estive à espera de ti... Conseguiste o que precisavas? Tudo resolvido?"

    # say L1485 pla
    old "It's almost ready, but it's still going to take a little while."
    new "É quase, mas ainda vai demorar um pouco. Afinal, só deve ficar pronto amanhã."

    # say L1486 pla
    old "At least until tomorrow."
    new "B:pla: Está quase pronto, mas ainda vai demorar um pouco."

    # say L1487 mia
    old "I still don't understand, what's going to take until tomorrow?"
    new "B:pla: Pelo menos até amanhã."

    # say L1489 pla
    old "Just trust me. After tomorrow everything will be solved."
    new "B:mia: Ainda não percebo, o que vai demorar até amanhã?"

    # say L1491 mia
    old "Are you going to kill Denzel?"
    new "B:pla: Confia em mim. Depois de amanhã tudo estará resolvido."

    # say L1492 pla
    old "What?! No! How can you think something like that?"
    new "B:mia: Vais matar o Denzel?"

    # say L1494 pla
    old "Just relax. You'll get it tomorrow.."
    new "B:pla: Que?! Não! Como podes pensar uma coisa dessas?"

    # say L1495 pla
    old "But we're gonna have to deal with the delivery."
    new "B:pla: Relaxa. Vais consegui-lo amanhã."

    # say L1496 pla
    old "We have to find a way to steal away what Denzel sent today."
    new "T(pla|tu|say): Temos de arranjar uma forma de roubar o que o Denzel enviou hoje."

    # say L1497 pla
    old "So that the principal won't see them."
    new "B:pla: Temos que encontrar uma maneira de roubar o que o Denzel enviou hoje."

    # say L1498 mia
    old "Well, she's already gone home. So even if it arrives today, she won't see it until tomorrow."
    new "B:pla: Para que a diretora não os veja."

    # say L1499 pla
    old "Ok, so I suppose we'll have to steal it tomorrow before she sees it."
    new "B:mia: Ela já foi para casa. Então, mesmo que chegue hoje, ela só vai ver amanhã."

    # say L1500 pla
    old "We'll have to arrive very early. Before she does."
    new "B:pla: Ok, então suponho que teremos de a roubar amanhã antes que ela a veja."

    # say L1501 pla
    old "After that everything will be fine."
    new "B:pla: Vamos ter de chegar muito cedo. Antes dela."

    # say L1503 mia
    old "It will? But what are you going to do?"
    new "B:pla: Depois disso tudo ficará bem."

    # say L1504 pla
    old "I just can't tell you."
    new "B:mia: Vai? Mas o que vais fazer?"

    # say L1506 mia
    old "Damn, ok, whatever. You better make whatever you do really work..."
    new "B:pla: Não posso dizer-te."

    # say L1507 pla
    old "Don't worry."
    new "B:mia: Merda, ok, seja lá o que for. Melhor fazeres o que for para resultar..."

    # say L1508 mia
    old "So, we'll meet here tomorrow?"
    new "B:pla: Não te preocupes."

    # say L1510 pla
    old "Yeah, before classes."
    new "B:mia: Então, nos vemos aqui amanhã?"

    # say L1511 mia
    old "Ok, that's it then. Don't be late."
    new "B:pla: Sim, antes das aulas."

    # say L1512 pla
    old "Of course not."
    new "B:mia: Ok, então é isso. Não cheges atrasado."

    # say L1513 mia
    old "All right, see you tomorrow then."
    new "B:pla: Claro que não."

    # say L1514 pla
    old "Ok, don't worry tomorrow this will all be over."
    new "B:mia: Tudo bem, até amanhã então."

    # say L1533 pla
    old "Hi, Ms. Mia."
    new "B:pla: Ok, não te preocupes, amanhã tudo isto acabará."

    # say L1534 mia
    old "At this point I think just Mia's fine."
    new "B:pla: Olá, Sra. Mia."

    # say L1536 mia
    old "Ok, so I came in very early to check that the coast is clear."
    new "B:mia: Neste ponto, acho que só Mia está bem."

    # say L1537 mia
    old "Nobody's around."
    new "B:mia: Ok, entrei muito cedo para verificar que não há ninguém por perto."

    # say L1538 pla
    old "That's perfect, so we should be able to get it with no problem."
    new "B:mia: Não há ninguém por perto."

    # say L1539 mia
    old "Ok, let's go, we need to check out the principal's office."
    new "B:pla: Isso é perfeito, então não devemos ter problemas."

    # say L1554 pla
    old "Have you found anything?"
    new "B:mia: Ok, vamos, precisamos ir ao gabinete do diretor."

    # say L1555 mia
    old "Nothing, everything look's fine."
    new "B:pla: Encontraste alguma coisa?"

    # say L1556 pla
    old "Hmm, there must be something."
    new "B:mia: Nada, tudo parece estar bem."

    # say L1566 pla
    old "Ah, that must be it."
    new "B:pla: Hmm, deve haver algo."

    # say L1568 pla
    old "Why else would there be a CD on her desk?"
    new "B:pla: Ah, deve ser isso mesmo."

    # say L1569 mia
    old "Yeah, you're probably right. It must've arrived during the evening and the janitor put it here."
    new "B:pla: Por que mais haveria um CD em cima da mesa dela?"

    # say L1572 mia
    old "Ok, so what do we do now?"
    new "B:mia: Sim, provavelmente tens razão. Deve ter chegado durante a noite e o porteiro colocou-o aqui."

    # say L1573 pla
    old "What we have to do is just..."
    new "A:mia: Espera! Acho que ouvi algo! Penso que alguém está a chegar."

    # say L1575 mia
    old "Wait! I just heard something! I think someone's coming."
    new "B:pla: O que temos de fazer é apenas..."

    # say L1576 mia
    old "Quick get in that closet."
    new "B:mia: Espera! Acabei de ouvir algo! Acho que alguém está a chegar."

    # say L1588 pla
    old "What are we going to do?"
    new "B:mia: Entra depressa nesse armário."

    # say L1589 mia
    old "Shhhh, someone's coming, they'll hear us."
    new "B:pla: O que vamos fazer?"

    # say L1597 dir
    old "Ok, I see some correspondence arrived yesterday. What do we have here?"
    new "B:mia: Shhhh, alguém está a chegar, vão ouvir-nos."

    # say L1600 dir
    old "Oh! Not the auditing process again!"
    new "B:dir: Ok, vejo que chegou alguma correspondência ontem. O que temos aqui?"

    # say L1603 dir
    old "The day just started and it's already ruined, everytime they do it we have to jump through so many hurdles."
    new "B:dir: Oh! Não o processo de auditoria de novo!"

    # say L1608 dir
    old "{i}*Sigh*{/i} I guess there's nothing to do, I'll just deal with it."
    new "T(dir|tu|say): {i}*Suspiro*{/i} Acho que não há nada a fazer, vou lidar com isso."

    # say L1615 dir
    old "Nothing wrong with dealing with some stress early before work."
    new "B:dir: Mas primeiro..."

    # say L1616 dir
    old "I don't usually do this here at the office, but what the hell."
    new "B:dir: Não há nada de errado em lidar com algum stress cedo antes do trabalho."

    # say L1617 dir
    old "It's been quite a while, I think it will be fun."
    new "A:mia: Que raio? Tu tens realmente uma ereção neste momento?"

    # say L1620 mia
    old "What the hell? Do you actually have a boner right now?"
    new "B:dir: Já passou algum tempo, acho que vai ser divertido."

    # say L1621 pla
    old "S- sorry, I just can't help it."
    new "B:mia: Que raio? Tu tens mesmo uma ereção neste momento?"

    # say L1622 pla
    old "It's not my intention."
    new "B: pla: S- desculpa, não consigo evitar."

    # say L1623 mia
    old "Ugh, you're incredible, I can't believe you."
    new "B:pla: Não é minha intenção."

    # say L1633 dir
    old "Mmm, oh yeah, this is just what I needed."
    new "B:mia: Ugh, tu és incrível, não acredito em ti."

    # say L1634 dir
    old "Oh! It's so good!"
    new "B:dir: Mmm, oh yeah, isto é exactamente o que eu precisava."

    # say L1635 dir
    old "That's it, yeah, yeah."
    new "B:dir: Oh! É tão bom!"

    # say L1638 pla
    old "Wow, she is..."
    new "B:dir: É isso, sim, sim. T(pla|tu|say): Uau, ela é... A:mia: Shhh..."

    # say L1639 mia
    old "Shhh..."
    new "B:pla: Uau, ela é..."

    # say L1646 pla
    old "W-what are you doing?"
    new "B:mia: Shhh..."

    # say L1647 mia
    old "Shhh, be quiet, she'll find us if you keep talking."
    new "B:pla: O-oque estás a fazer?"

    # say L1648 pla
    old "But you're- ..."
    new "B:mia: Shhh, cala-te, ela vai encontrar-nos se continuares a falar."

    # say L1649 mia
    old "Shhh, just shut up!"
    new "B:pla: Mas tu estás a..."

    # say L1657 dir
    old "Fantastic!"
    new "B:mia: Shhh, cala-te!"

    # say L1658 dir
    old "But I better go check on things around the school before the students arrive."
    new "T: Mas melhor ir ver as coisas na escola antes de os alunos chegarem."

    # say L1667 mia
    old "Mmm! Oh! Oh yeah!"
    new "B:dir: Mas é melhor eu ir ver as coisas pela escola antes de os alunos chegarem."

    # say L1669 pla
    old "Hmm, M-Mia, the principal just left."
    new "B:mia: Mmm! Oh! Oh sim!"

    # say L1670 pla
    old "I think we better get out of here before she or anybody else comes back."
    new "B:pla: Hmm, M-Mia, o diretor acabou de sair."

    # say L1671 mia
    old "Uh, what? Oh yeah!"
    new "B:pla: Acho que melhor sairmos daqui antes que ela ou mais alguém volte."

    # say L1672 mia
    old "You're right, l- let's get out of here."
    new "B:mia: Uh, o quê? Ah, sim!"

    # say L1684 mia
    old "Ok, we have to go then, we can't keep wasting any more time here."
    new "B:mia: Tens razão, v-vamos sair daqui."

    # say L1685 pla
    old "Yeah, I guess you're right, don't forget to bring the CD."
    new "B:mia: Ok, temos de ir então, não podemos continuar a perder tempo aqui."

    # say L1707 mia
    old "Phew, it's good that we made it."
    new "B:pla: Sim, acho que tens razão, não te esqueças de trazer o CD."

    # say L1708 mia
    old "I can't believe we almost got caught. Hehe, right?"
    new "B:mia: Ufa, que bom que conseguimos."

    # say L1709 pla
    old "Eh, yeah, you're right haha, that was close, phew!"
    new "B:mia: Não acredito que quase fomos apanhados. Hehe, certo?"

    # say L1711 mia
    old "What now then?"
    new "B:pla: Eh, sim, tens razão hahaha, foi por pouco, ufa!"

    # say L1713 pla
    old "Well, we're relieved, but we're not sure if this really is what we were looking for."
    new "B:mia: E agora, então?"

    # say L1714 pla
    old "So we better check in the computer to see if it is."
    new "B:pla: Bem, estamos aliviados, mas não temos a certeza se isto é realmente o que procurávamos."

    # say L1716 mia
    old "Yeah, you're right, we should check."
    new "B:pla: Então melhor verificar no computador para ver se é isso."

    # say L1722 pla
    old "That's very weird, there only seems to be a single video."
    new "B:mia: Sim, tens razão, devíamos verificar."

    # say L1723 pla
    old "Nothing else."
    new "B:pla: Isso é muito estranho, parece que só há um vídeo."

    # say L1724 mia
    old "Well, open it, we need to see if it is."
    new "B:pla: Não há mais nada."

    # say L1734 pla
    old "Woah! I wasn't expecting that."
    new "B:mia: Bem, abre, precisamos ver se é."

    # say L1735 mia
    old "Oh my god! It is."
    new "B:pla: Uau! Não estava à espera disso."

    # say L1736 mia
    old "I can't believe he actually found something."
    new "B:mia: Oh meu Deus! É verdade."

    # say L1737 mia
    old "It seems the producers didn't get rid of everything as I wanted them to."
    new "B:mia: Não posso acreditar que ele realmente encontrou algo."

    # say L1738 mia
    old "How did Denzel get his hands on this?"
    new "B:mia: Parece que os produtores não se livraram de tudo como eu queria."

    # say L1753 dir
    old "I need to see you both in my office."
    new "B:mia: Como é que o Denzel conseguiu isto?"

    # say L1754 dir
    old "So come to my office as soon as you're done working on whatever it is you're working on that computer."
    new "B:dir: Preciso de ver vocês dois no meu escritório."

    # say L1761 mia
    old "W-what? Why does she want to see us there?"
    new "B:dir: Então, vem ao meu escritório assim que terminares o que estás a fazer nesse computador."

    # say L1763 mia
    old "Oh no, she found out we were there, or maybe Denzel sent her another thing!"
    new "B:mia: Q-que? Porque é que ela quer ver-nos lá?"

    # say L1765 pla
    old "Calm down, calm down, there's no reason why she would know we were in her office."
    new "B:mia: Oh não, ela descobriu que estávamos lá, ou talvez o Denzel tenha mandado outra coisa para ela!"

    # say L1766 pla
    old "And why would Denzel send her another CD?"
    new "B: Calma, calma, não há razão para ela saber que estávamos no escritório dela."

    # say L1767 mia
    old "Then what do you think she wants to talk to us about?"
    new "B:pla: E por que Denzel lhe enviaria outro CD?"

    # say L1768 pla
    old "I guess we have to talk to her."
    new "B:mia: Então, o que é que tu achas que ela quer falar connosco?"

    # say L1778 pla
    old "Hmm, the thing is, I-I kinda can't right now."
    new "T(pla|tu|say): Hmm, a questão é que, eu... não consigo andar neste momento."

    # say L1779 mia
    old "Why not?"
    new "B:pla: Hmm, a questão é que, eu... não consigo agora."

    # say L1780 pla
    old "Uhhh...I just need a few minutes... I mean after I watched your video."
    new "B:mia: Porquê?"

    # say L1784 mia
    old "You're really unbelievable, you know?! I can't believe you actually got a boner from that!"
    new "B:pla: Uhhh... Preciso de uns minutos... Quero dizer, depois de ver o teu vídeo."

    # say L1785 pla
    old "Well, I'm still a man, you know? It's not like I want to go around with a boner."
    new "B:mia: Tu és mesmo incrível, sabias?! Não posso acreditar que tu realmente ficaste com uma ereção com isso!"

    # say L1786 mia
    old "Ugh, shut up. Just get rid of it, will you?"
    new "B:pla: Bem, ainda sou um homem, sabes? Não é como se quisesse andar por aí com uma ereção."

    # say L1787 pla
    old "Get rid of it? How?"
    new "B:mia: Ugh, cala-te. Só te livra disso, ok?"

    # say L1788 mia
    old "How do you think genius? Jerk off!"
    new "B:pla: Livrar-te disso? Como?"

    # say L1789 mia
    old "And do it quickly the principal is waiting for us."
    new "B:mia: Como é que tu pensas, génio? Masturba-te!"

    # say L1790 pla
    old "I don't think that will work, I mean, I'm very nervous, and I just don't have my mind in it."
    new "B:mia: E faz isso depressa, o diretor está à espera de nós."

    # say L1791 mia
    old "I just can't believe this."
    new "A:mia: Ughh... Temos de o fazer agora antes de ele voltar..."

    # say L1792 mia
    old "Ughh... We have to do it now before he comes back..."
    new "B:mia: Não consigo acreditar nisto."

    # say L1793 pla
    old "Just give me a couple of minutes..."
    new "B:mia: Ughh... Temos de o fazer agora antes de ele voltar..."

    # say L1794 mia
    old "Hmm, you know what, I'll do it then."
    new "B:pla: Dá-me só um minuto..."

    # say L1804 mia
    old "What do you think genius? I'm making you cum."
    new "B:mia: Hmm, sabes o que, eu faço isso então."

    # say L1805 mia
    old "We can't take too much time, the principal is waiting for us."
    new "B:mia: E então, génio? Estou a fazer-te gozar."

    # say L1806 mia
    old "And since you can't do it yourself, I guess I'll have to do it for you."
    new "B:mia: Não podemos demorar muito, o diretor está à espera de nós."

    # say L1826 mia
    old "Ah, yeah, sorry. We didn't mean to."
    new "B:dir: Demoraste um bocado a chegar..."

    # say L1827 mia
    old "It's just that the... thing we were doing took a little longer than expected."
    new "B:mia: Ah, sim, desculpa. Não foi nossa intenção."

    # say L1830 dir
    old "Ok, listen up. Mia, last week you gave me a report..."
    new "B:mia: É que a... coisa que estávamos a fazer demorou um pouco mais do que o esperado."

    # say L1835 dir
    old "Not per se, after all, there's nothing unusual about a student needing to improve his grades."
    new "B:mia: H-hum, é verdade. Há algum problema com isso, senhora?"

    # say L1836 dir
    old "The problem is that this morning I received a letter informing me we're about to be audited by the superintendent."
    new "B:dir: Não propriamente, afinal, não há nada de anormal num aluno precisar de melhorar as notas."

    # say L1838 dir
    old "And it would be very good for us if we don't have a student about to be expelled due to his poor performance."
    new "T(dir|tu|say): E seria muito bom para nós se não tivermos um aluno prestes a ser expulso devido ao seu mau desempenho."

    # say L1840 dir
    old "So, Mia, I normally wouldn't do this, but I need you to start helping him personally with his studies."
    new "T(dir|tu|say): Então, Mia, normalmente não faria isto, mas preciso que tu comeces a ajudá-lo pessoalmente nos estudos."

    # say L1842 mia
    old "Sorry? Do you want me to tutor him? Personally?"
    new "B:dir: Então, Mia, normalmente não faria isto, mas preciso que tu comeces a ajudá-lo pessoalmente nos estudos."

    # say L1843 dir
    old "Exactly, think of it as extra classes for him. It must be done."
    new "B:mia: Desculpa? Queres que eu o ajude? Pessoalmente?"

    # say L1844 dir
    old "We can't have any bad marks for the school qualification."
    new "B:dir: Exato, pensa nisso como aulas extra para ele. Tem que ser feito."

    # say L1845 mia
    old "I see, great."
    new "Ótimo?"

    # say L1846 dir
    old "Great?"
    new "T(dir|tu|diz): Ótimo?"

    # say L1847 mia
    old "Uh, I mean, I think it's great that we can get a good score just by doing that."
    new "B:dir: Ótimo?"

    # say L1852 dir
    old "Well, that's great to hear. I trust you have this Mia."
    new "B:mia: Tenho a certeza de que as notas dele estarão ao nível das dos outros quando a auditoria começar."

    # say L1853 dir
    old "Now, I'm very busy, so you two can go back to class."
    new "B:dir: Ótimo, então. Confio que tu tenhas isto, Mia."

    # say L1854 mia
    old "Sure ma'am. Thank you."
    new "B:dir: Agora, estou muito ocupada, então vocês dois podem voltar à aula."

    # say L1870 pla
    old "Yeah, me too, I'm glad we managed to avoid the trouble."
    new "B:mia: Pensei que estávamos perdidos. Tinha a certeza de que ela tinha recebido outra cópia do vídeo do Denzel ou algo assim."

    # say L1871 mia
    old "Well, that was just the start of it, we still have to deal with Denzel."
    new "B:pla: Sim, eu também, fico contente que conseguimos evitar o problema."

    # say L1872 mia
    old "Which by the way, you still haven't told me anything about how you plan on doing that."
    new "B:mia: Bem, isso foi apenas o começo, ainda temos que lidar com Denzel."

    # say L1873 pla
    old "It's ok, it should be ready by now, I think I just have to go handle that."
    new "T(pla|tu|dizer): Tudo bem, deve estar pronto agora, acho que só tenho que ir tratar disso."

    # say L1874 mia
    old "Ready? What do you mean by that?"
    new "B:pla: Está bem, deve estar pronto agora, acho que só tenho que ir tratar disso."

    # say L1875 pla
    old "Don't think too much about it."
    new "T(pla|tu|say): Não penses muito nisso."

    # say L1876 pla
    old "You just have to know that by this afternoon not only will we have dealt with Denzel."
    new "B:pla: Não penses muito nisso."

    # say L1877 pla
    old "There's going to be no way of him or anyone else using anything from your past to try and hurt you."
    new "B:pla: Tu só tens de saber que até ao final da tarde não só teremos resolvido o problema com Denzel."

    # say L1878 mia
    old "You make it sound so easy."
    new "B:pla: Não vai haver maneira de ele ou alguém mais usar algo do teu passado para tentar magoar-te."

    # say L1879 mia
    old "But you seem to be very confident about this. So, I'll trust you."
    new "B:mia: Tornas tudo a parecer tão fácil."

    # say L1881 mia
    old "But wait, will you look for me to tell me if whatever it is you plan on doing works?"
    new "B:mia: Mas pareces muito confiante nisto. Então, vou confiar em ti."

    # say L1883 pla
    old "Sure, you just focus on getting rid of that CD with your video on it."
    new "B:mia: Mas espera, vais procurar-me para me dizer se o que planeias fazer resultou?"

    # say L1884 pla
    old "And I'll handle the rest."
    new "B:pla: Claro, tu só te preocupas em te livrares desse CD com o vídeo teu."

    # say L1885 mia
    old "Ok, whatever you say."
    new "B:pla: E eu trato do resto."

    # say L1886 pla
    old "Thank you, I have to go, I'll see you later."
    new "B:mia: Ok, seja como for."

    # say L1906 pla
    old "Hey! Hey! Linett! Are you ready?"
    new "B:pla: Obrigado, tenho de ir, vejo-te mais tarde."

    # say L1907 pla
    old "I need to know if the spell's ready to be used!"
    new "B:pla: Ei! Ei! Linett! Estás pronta?"

    # say L1911 pla
    old "That's great, so what do we do?"
    new "B:lin: A poção está pronta, então podemos usar o SexNote para invocá-la."

    # say L1913 lin
    old "The hard work was already done by me, by focusing the magic power on the person you told me about."
    new "B:pla: Ótimo, e agora, o que fazemos?"

    # say L1914 lin
    old "And limiting the reach of the spell."
    new "B:lin: O trabalho árduo já foi feito por mim, concentrando o poder mágico na pessoa que me disseste."

    # say L1915 lin
    old "All you have to do is read it from the SexNote, and it will be cast."
    new "B:lin: E limitando o alcance do feitiço."

    # say L1916 pla
    old "Ok, that's very simple, can we do it now?"
    new "T(pla|tu|say): Ok, isso é muito simples, podemos fazer agora?"

    # say L1917 lin
    old "Sure, it should have already appeared in the SexNote, so you just have to read it, and that's it."
    new "T(lin|tu|say): Claro, deve ter aparecido no SexNote, então tu só tens de o ler, e está feito."

    # say L1920 pla
    old "You're right! Is there!"
    new "B:lin: Claro, já deve ter aparecido no SexNote, então só tens de o ler, e está feito."

    # say L1921 pla
    old "So, all I have to do is read it?"
    new "B:pla: Tens razão! Existe mesmo!"

    # say L1922 lin
    old "That's it."
    new "B:pla: Então, tudo o que tenho de fazer é lê-lo?"

    # say L1923 pla
    old "Ok, here it goes."
    new "Elementum recolligo Huic Commodo locus mihi vestri voz."

    # say L1926 pla
    old "Elementum recolligo Huic Commodo locus mihi vestri vox."
    new "B:pla: Ok, aqui vai."

    # say L1927 pla
    old "Venire ventus venire, sinere solus sentire relaxari."
    new "A:lin: A-Acho que está a começar a fazer efeito!"

    # say L1930 lin
    old "I-I think it's starting to take effect!"
    new "B: Venire ventus venire, sinere solus sentire relaxari."

    # say L1931 pla
    old "Accerso alius sententia ut mihi, phasmatis of interregnum ego dico!"
    new "T(pla|tu|say): Aproxima-te de mim, sente o que sinto, eu digo que és um fantasma do intervalo!"

    # say L1932 pla
    old "Solvo meus mens mei, ego dico phasmatis audite meus placitum meus mens quod iacio Mia!"
    new "A:pla: O que está a acontecer?!"

    # say L1955 pla
    old "What's happening?!!"
    new "B:pla: Resolva a minha mente, eu digo ao fantasma que ouça o meu desejo, que eu jogue com Mia!"

    # say L1961 pla
    old "Where am I?! What's this place?!"
    new "B:pla: O que está a acontecer?!!"

    # say L1962 pla
    old "What the hell?! What's this?"
    new "Onde estamos, Linett?"

    # say L1963 pla
    old "Where are we Linett?"
    new "B:pla: Que raio?! O que é isto?"

    # say L1964 lin
    old "Hmmm, it seems something went awry with the spell..."
    new "B:pla: Onde estamos, Linett?"

    # say L1965 pla
    old "What?! Can we fix it? What happened and where are we?!"
    new "B:lin: Hmm, parece que algo correu mal com o feitiço..."

    # say L1966 lin
    old "I don't know, I think we'll just have to wait."
    new "B:pla: Que?! Podemos arranjar isto? O que aconteceu e onde estamos?!"

    # say L1967 pla
    old "W- what?..."
    new "B:lin: Não sei, acho que vamos ter de esperar."

    # say L1972 lin
    old "Oh wow, you look like another person now!"
    new "B:pla: O- o quê?..."

    # say L1977 pla2
    old "The fuck is happening Linett?!"
    new "B:lin: Oh wow, tu pareces outra pessoa agora!"

    # say L1978 lin
    old "Well, I told you, something went awry, apparently the energy is fluctuating..."
    new "B:pla2: Que raio se está a passar, Linett?!"

    # say L1980 pla2
    old "I don't know what that means!"
    new "B:lin: Bem, já te disse, algo deu errado, aparentemente a energia está a flutuar..."

    # say L1986 pla
    old "Wait, we're back to normal."
    new "B:pla2: Não sei o que isso significa!"

    # say L1987 pla
    old "What was that all about Linett? Was there something wrong with the spell?"
    new "B: pla: Espera, voltámos ao normal."

    # say L1989 lin
    old "It could be, but I don't think so. I think it has more to do with all of the power that it takes to call the spell."
    new "B:pla: Do que se tratava, Linett? Havia algo errado com o feitiço?"

    # say L1990 lin
    old "All of that energy must've caused a tear in our reality that connected us to another one."
    new "B:lin: Pode ser, mas duvido. Acho que tem mais a ver com toda a energia necessária para invocar o feitiço."

    # say L1991 lin
    old "The energy probably began to flow into the tear, and that made things begin switching places between the two realities."
    new "B:lin: Toda essa energia deve ter causado uma fissura na nossa realidade que nos conectou a outra."

    # say L1993 pla
    old "Uh, sure..."
    new "B:lin: A energia provavelmente começou a fluir para a fissura, e isso fez as coisas começarem a trocar de lugar entre as duas realidades."

    # say L1994 pla
    old "But what does that mean? Is everything alright?"
    new "B:pla: Uh, claro..."

    # say L1996 lin
    old "There shouldn't be any problem, things must've stabilized after you finished the spell."
    new "B:pla: Mas o que isso significa? Tudo bem?"

    # say L1997 lin
    old "The person you wanted to be forgotten is no longer in the mind of the bad human."
    new "B:lin: Não deve haver problema, as coisas devem ter estabilizado depois de terminares o feitiço."

    # say L1998 lin
    old "Also, every single trace of her presence has been removed."
    new "B:lin: A pessoa que tu querias esquecer já não está na mente do humano má."

    # say L1999 pla
    old "Does that mean no more videos or pictures of anything?"
    new "T(pla|tu|say): Isso significa que não há mais vídeos ou fotos de nada?"

    # say L2001 lin
    old "Everything has been removed [pla]."
    new "T(lin|tu|diz): Tudo foi removido [pla]."

    # say L2018 pla
    old "Mia! Hey! It's done!"
    new "B:pla: Vou falar com a Mia agora!"

    # say L2020 mia
    old "What are you talking about? What's done?"
    new "B:pla: Mia! Ei! Está feito!"

    # say L2021 pla
    old "You just have to know that I already took care of your problem with Denzel."
    new "B:mia: Do que estás a falar? O que está feito?"

    # say L2022 pla
    old "He won't bother you any longer, there are no more videos or pictures or anything!"
    new "B:pla: Tu só tens de saber que já resolvi o teu problema com o Denzel."

    # say L2023 mia
    old "Uh- I mean, I think that's good, but what about him? He can just go to the press and talk about me."
    new "B:pla: Ele não vai incomodar-te mais, não há mais vídeos ou fotos ou qualquer coisa!"

    # say L2024 pla
    old "Don't worry about that either, he won't even remember you, trust me."
    new "T(pla|tu|diz): Não te preocupes com isso, ele nem sequer se vai lembrar de ti, acredita em mim."

    # say L2025 mia
    old "What do you mean he won't even remember me?"
    new "B:pla: Não te preocupes com isso, ele nem sequer se vai lembrar de ti, acredita em mim."

    # say L2026 pla
    old "You know what? Let's check it, why don't you call him?"
    new "A:mia: Agora é que estou mesmo a pensar que foste à vida. Chamar-lhe?"

    # say L2027 mia
    old "Now I really think you have gone insane. Call him?"
    new "B:pla: Sabes o quê? Vamos ver, por que não lhe ligas?"

    # say L2028 pla
    old "Just trust me, everything will be fine."
    new "B:mia: Agora acho mesmo que enlouqueceste. Chamá-lo?"

    # say L2030 mia
    old "I guess we can try."
    new "B:pla: Confia em mim, tudo vai correr bem."

    # say L2034 pla
    old "Yeah, don't worry."
    new "T:den: Olá, quem é? Não reconheço o número."

    # say L2038 den
    old "Hello, who is this? I don't recognize the number."
    new "Olá, quem é? Não reconheço o número."

    # say L2039 mia
    old "Wh-?!"
    new "B:den: Olá, quem é? Não reconheço o número."

    # say L2040 mia
    old "Denzel? It's me, Mia... Uhh... from the school...."
    new "B:mia: Wh-?!"

    # say L2041 den
    old "Listen, I don't know who you are, if you think you can scam me you better think twice!"
    new "B:mia: Denzel? Sou eu, a Mia... hã... da escola...."

    # say L2042 mia
    old "What? No! I mean..."
    new "B:den: Ouve, não sei quem és tu, mas se pensas que me vais enganar, melhor pensas duas vezes!"

    # say L2044 mia
    old "Hello? Helloo?..."
    new "B:mia: O quê? Não! Quero dizer..."

    # say L2045 mia
    old "He hung up, he said he didn't know who I was..."
    new "B:mia: Alô? Alô...?"

    # say L2047 pla
    old "See?"
    new "A:mia: O que fizeste?"

    # say L2048 mia
    old "What did you do?"
    new "B:pla: Vê?"

    # say L2049 pla
    old "I'm sorry but I can't tell you that, all that matters is that with that your problem should be taken care of."
    new "B:mia: O que fizeste?"

    # say L2051 mia
    old "I mean, I guess it is, but this is very odd."
    new "B:pla: Desculpa, mas não posso dizer-te isso, o importante é que com isso o teu problema deve ficar resolvido."

    # say L2053 pla
    old "Listen, all you have to do is trust me, ok?"
    new "B:mia: Quero dizer, acho que sim, mas isto é muito estranho."

    # say L2054 pla
    old "If you think it'll make you feel any safer, why don't we both go tomorrow to the principal's office again?"
    new "B:pla: Ouve, só tens de confiar em mim, ok?"

    # say L2055 pla
    old "That way we can check if everything will be in order."
    new "B: pla: Se pensas que isso te vai fazer sentir mais seguro, por que não vamos os dois amanhã ao gabinete do diretor de novo?"

    # say L2058 mia
    old "Ok, let's do as you say."
    new "B:pla: Assim podemos verificar se tudo estará em ordem."

    # say L2059 pla
    old "Great, then I'll see you tomorrow."
    new "B:mia: Ok, vamos fazer como tu dizes."

    # say L2068 mia
    old "I don't know what you did, but thank you."
    new "B:pla: Ótimo, então nos vemos amanhã."

    # say L2094 pla
    old "Oh, Belle, hi!"
    new "B:mia: Não sei o que fizeste, mas obrigada."

    # say L2095 pla
    old "What are you doing here so early?"
    new "B:pla: Olá, Belle!"

    # say L2099 pla
    old "Miss Lucy? Who's that? Like a new teacher?"
    new "B:bel: Vim só porque a Miss Lucy me pediu, estou a ajudá-la num projeto de grupo."

    # say L2100 bel
    old "What? Are you messing with me? Of course, you know Ms Lucy, our teacher."
    new "B:pla: Miss Lucy? Quem é? Como uma nova professora?"

    # say L2101 pla
    old "Who?!"
    new "B:bel: O quê? Estás a brincar comigo? Claro que tu conheces a Sr.ª Lucy, a nossa professora."

    # say L2105 pla
    old "I have no idea what you're talking about."
    new "A:luc: Olá Belle, como estás hoje querida?"

    # say L2115 luc
    old "Hi Belle, how are you today sweetheart?"
    new "T(luc|tu|diz): Olá Belle, como estás hoje querida?"

    # say L2120 luc
    old "And you Belle, you need better friends."
    new "B: luc: Também espero que não corrompas a Belle, és uma má influência!"

    # say L2122 pla
    old "... (What the fuck?)"
    new "B:luc: E tu, Belle, precisas de amigos melhores."

    # say L2123 luc
    old "Well, see you later in class. Belle, come with me."
    new "B:pla:... (Que raio...)"

    # say L2142 pla
    old "I mean, as I said, I thought I had fixed the issue. Did Denzel contact you again?"
    new "Não! Não é isso."

    # say L2143 mia
    old "No! Not that."
    new "A:mia: Ninguém se lembra de quem eu sou!"

    # say L2144 mia
    old "Nobody remembers who I am!"
    new "B:mia: Não! Não isso."

    # say L2147 mia
    old "That's right! When I woke up I wasn't in any of the pictures on my wall!"
    new "B:mia: Ninguém se lembra de quem eu sou!"

    # say L2148 mia
    old "Even the doorman here didn't want to let me in! He asked if I was someone's parent!"
    new "B:mia: É verdade! Quando acordei, não estava em nenhuma das fotografias na parede!"

    # say L2149 mia
    old "There's even another teacher giving my class! I already looked at the lists, I don't appear in any of them!"
    new "B:mia: Até o porteiro aqui não quis deixar-me entrar! Perguntou se eu era pai ou mãe de alguém!"

    # say L2153 mia
    old "You know what? Denzel didn't ruin my life, but you did!"
    new "B:pla: O quê? Mas isso... isso..."

    # say L2154 mia
    old "I don't know how you did it, but you blew it! I shouldn't have trusted you!"
    new "B:mia: Sabes o quê? Denzel não estragou a minha vida, mas tu foste quem o fez!"

    # say L2160 pla
    old "What the- "
    new "B:mia: Não sei como fizeste, mas estragaste tudo! Não devia ter confiado em ti!"

    # say L2170 mik
    old "Although she's a little too old for you."
    new "B:mik: Ela é super gira!"

    # say L2171 mik
    old "You dog, did you get a sugar mommy somewhere?"
    new "B:mik: Embora ela seja um pouco velha demais para ti."

    # say L2173 pla
    old "Don't you know who she is? That's Ms. Mia, our history teacher!"
    new "T(pla|tu|dizes): Tu não sabes quem ela é? É a Sr.ª Mia, a nossa professora de história!"

    # say L2174 mik
    old "Well, I had never seen her before."
    new "B:pla: Não sabes quem ela é? É a Sr.ª Mia, a nossa professora de história!"

    # say L2175 mik
    old "But if that babe's gonna be our teacher I wouldn't mind paying a little more attention in class."
    new "B:mik: Nunca a tinha visto antes."

    # say L2176 mik
    old "She's looks super hot, like a pornstar!"
    new "B:mik: Mas se essa gata for a nossa professora, não me importo de prestar um pouco mais de atenção na aula."

    # say L2184 pla
    old "Linett, what the hell happened?! The spell went wrong!"
    new "T: Linett, mas que raio aconteceu?! O feitiço correu mal!"

    # say L2185 lin
    old "What? Did that guy appear again?"
    new "B: Linett, mas que raio aconteceu?! O feitiço correu mal!"

    # say L2186 pla
    old "No! That's not it! He doesn't remember her!"
    new "A:lin: Oh."

    # say L2187 lin
    old "Oh."
    new "B: Não! Não é isso! Ele não se lembra dela!"

    # say L2188 lin
    old "Then what's the problem?"
    new "B:lin: Oh."

    # say L2189 pla
    old "That no one does! Not a single person knows who she is!"
    new "B:lin: Então qual é o problema?"

    # say L2190 lin
    old "Well... yeah."
    new "B:pla: Isso ninguém faz! Ninguém sabe quem ela é!"

    # say L2192 pla
    old "What? What do you mean..."
    new "B:lin: Bem... sim."

    # say L2193 lin
    old "I told you, didn't I? 'Every trace of her presence will be gone.' All of it [pla]."
    new "T(lin|tu|say): Já te disse, não é? 'Todo o vestígio da sua presença desaparecerá.' Tudo isso [pla]."

    # say L2197 lin
    old "I don't know, I don't even think it's possible."
    new "B:pla: Espera, isto não pode acontecer, temos de reverter isto, como fazemos isso?"

    # say L2198 pla
    old "Holly shit..."
    new "B:lin: Não sei, nem acho que seja possível."

    # say L2214 pla
    old "Eh... What's happening?"
    new "B:pla: Holy shit..."

    # say L2221 pla
    old "Where am I? Who are you?"
    new "B:pla: Eh... O que está a acontecer?"

    # say L2222 pla2
    old "What the fuck? Who are you? And what are you doing in my bedroom?"
    new "B:pla: Onde estou? Quem és tu?"

    # say L2230 pla2
    old "And why are you naked?"
    new "B:pla2: Quem raio és tu?!"

    # say L2231 lin
    old "Nevermind that... Listen [pla] the tear between realities that we oppenned with our spell was a lot bigger than I thought it would be."
    new "E tu... Ouve, [pla] a fissura entre as realidades que abrimos com o nosso feitiço era muito maior do que eu pensava."

    # say L2233 lin
    old "It means that both realities are about to collapse on each other!"
    new "T(lin|tu|say): Significa que as duas realidades estão prestes a colapsar uma na outra!"

    # say L2235 pla
    old "Collapse? You mean like everything will be destroyed?"
    new "T(pla|tu|say): Colapso? Tu queres dizer que tudo vai ser destruído?"

    # say L2237 lin
    old "No, fortunately I was able to find the disturbance early, I think I can fix it."
    new "B: Colapso? Queres dizer que tudo vai ser destruído?"

    # say L2238 lin
    old "And I'll do that right now."
    new "B:lin: Não, felizmente consegui encontrar a perturbação cedo, acho que consigo arranjá-la."

    # say L2239 lin
    old "I'm just not sure if I'll make it on time, but I have to try..."
    new "B:lin: E vou fazer isso agora mesmo."

    # say L2240 pla2
    old "Wow, this is a very trippy dream."
    new "B:lin: Não tenho a certeza se vou a tempo, mas tenho de tentar..."

    # say L2249 pla
    old "Where I am? What is this???"
    new "B:pla2: Uau, este é um sonho muito estranho."

    # say L2253 pla
    old "Is he the guy I saw a few moments ago?"
    new "B:pla: Onde estou? O que é isto???"

    # say L2257 pla
    old "Is this a Dream or I'm going crazy?"
    new "B:pla: É ele o rapaz que vi há pouco?"

    # say L2261 pla
    old "Oh God, this is making me dizzy..."
    new "B:pla: Isto é um sonho ou estou a ficar louco?"

    # say L2278 pla
    old "What the fuck was that? Was it all a dream?"
    new "B:pla: Oh Deus, isto está a deixar-me tonto..."

    # say L2292 mia
    old "All right class, it's time to start."
    new "B:pla: Que raio foi isso? Foi tudo um sonho?"

    # say L2293 mia
    old "Today we'll start a new subject, so, take out your textbooks and open them in the next chapter."
    new "B:mia: Muito bem, turma, é hora de começarmos."

    # say L2294 mia
    old "This will also be at the end of term test, so be sure to take good notes."
    new "B:mia: Hoje vamos começar um novo tema, então, tirem os vossos livros e abram-nos no próximo capítulo."

    # say L2295 mia
    old "Belle?"
    new "B:mia: Isto também vai estar no teste final, por isso toma notas com atenção."

    # say L2298 mia
    old "Please read the first page of the chapter."
    new "B:mia: Belle?"


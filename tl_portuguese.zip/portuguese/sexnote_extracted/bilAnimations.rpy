# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/bilAnimations.rpy
translate portuguese strings:

    # say L6 lin
    old "Wow! I see you've a lot of energy repressed... Big and impressive."
    new "... Acho que sim..."

    # say L7 pla
    old "... I guess..."
    new "B:lin: Uau! Vejo que tens muita energia reprimida... Grande e impressionante."

    # say L8 pla
    old "Hmm..."
    new "A:lin: Ohh, está delicioso! Gosto muito."

    # say L13 lin
    old "Ohh it tastes great! I really like it."
    new "Oh sim... Dá-me isso... Dá-me toda a tua carga!"

    # say L19 lin
    old "Oh yeah... Give it to me... Give me all your load!"
    new "B:lin: Ohh, que bom! Eu realmente gosto disso."

    # say L44 lin
    old "Ahhh... I'm feeling it on my mouth!"
    new "B:lin: Oh yeah... Dá-me... Dá-me tudo!"

    # say L49 lin
    old "Hmmm, It was great... Now I need your dick inside, the energy transfer should be done now."
    new "B:lin: Ahhh... Estou a sentir na boca!"

    # say L71 lin
    old "Oh yeah... I haven't felt this in a long time ..."
    new "B:lin: Hmm, foi incrível... Agora preciso do teu pénis dentro, a transferência de energia deve estar completa agora."

    # say L76 lin
    old "Wow is huge and is drilling this girl..."
    new "B:lin: Oh yeah... Já não sentia isto há tanto tempo..."

    # say L82 lin
    old "Ohhh yeahhh, harder, harder!"
    new "B:lin: Que grande e está a foder esta rapariga..."

    # say L83 lin
    old "Don't stop! Gimme more! I want it all!"
    new "B:lin: Ohhh simmm, mais forte, mais forte!"

    # say L107 lin
    old "Ahhhhh.... Yeah!"
    new "B:lin: Não pares! Dá-me mais! Quero tudo!"

    # say L108 pla
    old "Wow... Ahhhhhhhh!"
    new "B:lin: Ahhhhh.... Sim!"

    # say L125 pla
    old "Ohh yeah..."
    new "A:bel: Como se sentes quando te chupam os peitos, Billie?"

    # say L130 bel
    old "How does it feel to get your boobs sucked Billie?"
    new "B:pla: Ohh yeah..."

    # say L139 bel
    old "Mmm..."
    new "B:bil: Mmm, estou a adorar..."

    # say L162 bil
    old "All right, I think is enough."
    new "B:bel: Mmm..."

    # say L173 bel
    old "So Billie? Do you like that big dick in your mouth?"
    new "T: Então Billie? Gostas desse pénis grande na tua boca?"

    # say L174 bil
    old "Mmmm."
    new "B:bel: Então, Billie? Gostas desse pénis grande na tua boca?"

    # say L181 bel
    old "Keep going, you have to do it well. Are you enjoying it [pla]?"
    new "T(bel|tu|say): Continua, tens de o fazer bem. Estás a gostar [pla]?"

    # say L183 bel
    old "He's enjoying it Billie!"
    new "B:pla: Uhh... Mmm..."

    # say L184 bil
    old "Gulp."
    new "B:bel: Ele está a gostar, Billie!"

    # say L189 bil
    old "Slurrp, I- I can feel you getting even harder."
    new "B:bil: Engolir."

    # say L190 bel
    old "He's close Billie! Keep going!"
    new "B:bil: Slurrp, eu- eu posso sentir que tu estás a ficar ainda mais duro."

    # say L191 pla
    old "Ahhh, ahhhh!"
    new "B:bel: Ele está perto, Billie! Continua assim!"

    # say L215 bel
    old "That's it Billie! Just like that."
    new "B:pla: Ahhh, ahhhh!"

    # say L216 pla
    old "Ahh! I- I'm cumming!"
    new "B:bel: É isso aí, Billie! Assim mesmo."

    # say L221 bil
    old "Ugh, duuude, you came all in my mouth!"
    new "B: Ahh! E-Estou a gozar!"

    # say L222 bil
    old "And Belle had already told you to be careful!"
    new "B:bil: Ugh, pá, tu enches-te todo na minha boca!"

    # say L223 pla
    old "S- sorry, I couldn't stop myself."
    new "B:bil: E a Belle já te tinha dito para ter cuidado!"

    # say L224 bel
    old "Yeah, he does come a lot, doesn't he?"
    new "B:pla: S- sorry, não consegui me controlar."

    # say L225 bil
    old "He does, anyway, help me clean myself."
    new "B:bel: Pois, ele vem muito, não é?"

    # say L226 pla
    old "S- sure..."
    new "B:bil: Ele ajuda, de qualquer forma, a limpar-me."

    # say L241 pla
    old "This feels... insane."
    new "B:bil: Mmm... tu sabes ainda melhor do que me lembrava."

    # say L242 bil
    old "Good. That's the point."
    new "B:pla: Isto sente-se... insano."

    # say L247 bil
    old "A little faster now..."
    new "B:bil: Bom. É isso mesmo."

    # say L248 pla
    old "Yes... please... don't stop."
    new "B:bil: Mais rápido agora..."

    # say L249 bil
    old "Your cock's throbbing... love feeling you like this."
    new "B:pla: Sim... por favor... não pares."

    # say L254 bil
    old "Harder... give me more."
    new "B:bil: O teu pénis está a latejar... adoro sentir-te assim."

    # say L255 pla
    old "[bil]... I'm close..."
    new "T: [bil]... Estou perto..."

    # say L257 pla
    old "Oh fuck... yes!"
    new "T: Oh merda... sim!"

    # say L281 pla
    old "I- I'm cumming—!"
    new "B:pla: Ah, merda... sim!"

    # say L282 bil
    old "Mmm... give it all to me."
    new "B:pla: I- I'm cumming—!"

    # say L283 bil
    old "Every drop... that's it."
    new "B:bil: Mmm... dá-me tudo."

    # say L290 pla
    old "That was... wow."
    new "T(pla|tu|say): Foi... uau."

    # say L291 bil
    old "Better?"
    new "T(bil|tu|say): Melhor?"

    # say L292 pla
    old "Uhh, yeah, definetly, t- thank you..."
    new "T: Uhh, yeah, definitivamente, t- obrigado..."

    # say L293 bil
    old "Alright... we should clean up this mess before my grandma walks in."
    new "Bem... devemos arrumar esta bagunça antes que a minha avó entre."

    # say L294 pla
    old "Yeah... good idea."
    new "T: Sim... boa ideia."

    # say L306 pla
    old "Is this okay?"
    new "T(pla|tu|say): Isto está bem?"

    # say L307 bil
    old "Oh god, yeah... you're doing it right. Keep the technique."
    new "B:pla: Isto está bem?"

    # say L311 bil
    old "Faster now. Rub harder."
    new "A:pla: Tu és tão apertada..."

    # say L312 pla
    old "You're so tight..."
    new "T: Tu és tão apertada..."

    # say L313 bil
    old "Deeper. D-don't stop-"
    new "T(bil|tu|say): Mais fundo. N-não pares-"

    # say L317 bil
    old "Harder! I want to feel you deeper."
    new "T(bil|tu|say): Mais forte! Quero sentir-te mais fundo."

    # say L320 pla
    old "Oh fuck..."
    new "B:bil: Sim! Estou quase!"

    # say L344 bil
    old "Oh God... that's it."
    new "B:pla: Oh merda..."

    # say L350 pla
    old "That was... intense."
    new "B:bil: Ah, Deus... é isso mesmo."

    # say L351 bil
    old "Phew... yeah, it was nice."
    new "A:bil: Melhores dedos?"

    # say L352 bil
    old "Better fingers?"
    new "T(bil|tu|say): Melhores dedos?"

    # say L353 pla
    old "Way better. Like they woke up."
    new "T: Muito melhor. Como se tivessem acordado."

    # say L368 bil
    old "Mmm... feel better already?"
    new "B:pla: Muito melhor. Como se tivessem acordado."

    # say L369 pla
    old "Yeah... tension's melting away."
    new "T(pla|tu|say): Sim... a tensão está a desaparecer."

    # say L373 bil
    old "Good. Deeper now."
    new "B:pla: Sim... a tensão está a desaparecer."

    # say L374 pla
    old "Fuck... yes."
    new "B:bil: Bom. Mais fundo agora."

    # say L378 bil
    old "Cum for me. Let it all out."
    new "B:pla: Merda... sim."

    # say L379 pla
    old "I'm... close!"
    new "T: Estou... perto!"

    # say L402 pla
    old "Ahh— cumming!"
    new "B:pla: Estou... perto!"

    # say L403 bil
    old "Mmm... that's it."
    new "B:pla: Ahh— a gozar!"

    # say L410 pla
    old "Wow... that was... intense."
    new "T(pla|tu|say): Uau... isso foi... intenso."

    # say L411 bil
    old "Feeling better?"
    new "B:pla: Uau... isso foi... intenso."

    # say L428 bil
    old "Mmm—keep it slow—notes steady... don't rush me yet..."
    new "B:pla: Tu já estás a tensar... sentes isso?"

    # say L434 bil
    old "Yes—fuck—deeper now—everything I wanted... slips right through my hands..."
    new "B:pla: O coração já está a disparar, hã? A tua voz ainda está firme."

    # say L439 bil
    old "{i}Ahh—fuck—keep going—don't stop—{/i}"
    new "B:bil: {i}E eu ainda estou a respirar... mas não... entendo—{/i}"

    # say L464 bil
    old "I-I'm—cumming—fuck—yes—!"
    new "B:bil: Mais forte—sim—ali mesmo—Eu vou—"

    # say L465 bil
    old "Nngh... holy shit..."
    new "B:bil: A-Ah... estou... a gozar... caralho... sim...!"

    # say L472 bil
    old "Fuuck..."
    new "B:bil: Nngh... merda..."

    # say L473 pla
    old "... Damn..."
    new "B:bil: Fuuck..."

    # say L474 bil
    old "Okay... that... was something else."
    new "B:pla:... Merda..."

    # say L475 pla
    old "You... held it together. Mostly."
    new "T: Tu... mantiveste-te. Mais ou menos."

    # say L476 bil
    old "Mostly? I felt the slip at the peak... but I pulled it back. That's progress."
    new "B:pla: Tu... conseguiste manter-te. Mais ou menos."

    # say L477 bil
    old "This method is insane... but it might just work."
    new "B:bil: Em grande parte... senti o deslize no auge... mas consegui recuperar. É progresso."

    # say L478 pla
    old "Yeah... insane in the best way."
    new "T: Sim... é louco da melhor maneira."

    # say L490 bil
    old "Do you like when I ride you like this?"
    new "T(bil|tu|say): Gostas quando te cavalgo assim?"

    # say L491 pla
    old "Fuck yes... you’re perfect..."
    new "B:bil: Gostas quando te cavalgo assim?"

    # say L492 bil
    old "Good boy... keep looking at me."
    new "B:pla: Merda, sim... tu és perfeito..."

    # say L496 bil
    old "Faster now... bounce with me."
    new "B: Bil: Bom rapaz... continua a olhar para mim."

    # say L497 pla
    old "Bil... you’re gonna make me lose it..."
    new "B:bil: Mais rápido agora... salta comigo."

    # say L498 bil
    old "Not yet. I want to feel you throb inside me."
    new "B: Bil... vais fazer-me perder o controlo..."

    # say L502 bil
    old "Harder— give it to me—"
    new "T(bil|tu|say): Mais forte— dá-me—"

    # say L503 pla
    old "I’m so close..."
    new "T: Estou tão perto..."

    # say L504 bil
    old "Inside! Cum inside me-"
    new "B:pla: Estou tão perto..."

    # say L527 bil
    old "Yes— fill me up—!"
    new "B:bil: Dentro! Goza dentro de mim-"

    # say L528 pla
    old "Ahh— fuck— cumming— !"
    new "T: Ahh— foda-se— a gozar—!"

    # say L529 bil
    old "Nngh... that’s it... every drop..."
    new "B:pla: Ahh— foda-se— a gozar—!"

    # say L536 bil
    old "Mmm... good boy. That felt so damn good."
    new "B:bil: Nngh... é isso... cada gota..."

    # say L537 pla
    old "That was... insane."
    new "T: Isso foi... insano."

    # say L538 bil
    old "Heh. Way better than any vocal warm up, right?"
    new "T(bil|tu|say): Heh. Muito melhor do que qualquer aquecimento vocal, certo?"

    # say L539 bil
    old "But we gotta stop... grandma could walk in any second."
    new "B:bil: Heh. Muito melhor do que qualquer aquecimento vocal, certo?"

    # say L540 pla
    old "Right, right..."
    new "T(pla|tu|say): Certo, certo..."

    # say L553 bil
    old "Mmm... feel how soft and warm my ass is rubbing all over your hard cock?"
    new "B:pla: Certo, certo..."

    # say L554 pla
    old "Fuck... Billie... that feels incredible..."
    new "B:bil: Mmm... sente como a minha bunda é macia e quente a esfregar-se no teu pau duro?"

    # say L558 bil
    old "You're throbbing so much between my cheeks. My ass turns you on that bad, huh?"
    new "B:pla: Merda... Billie... isso é incrível..."

    # say L559 pla
    old "Yes... don't stop..."
    new "T: Sim... não pares..."

    # say L563 bil
    old "Do you like feeling my ass? Then cum for me. I want you to finish all over it."
    new "B:pla: Sim... não pares..."

    # say L564 pla
    old "Oh God, Billie, don't stop..."
    new "B:bil: Gostas de sentir o meu rabo? Então goza para mim. Quero que acabes todo em cima dele."

    # say L587 pla
    old "Ahh— fuck— I'm cumming—!"
    new "B:pla: Ah, Deus, Billie, não pares..."

    # say L588 bil
    old "Mmm... yes, that's it. Cum all over my ass."
    new "B:pla: Ahh— foda-se— estou a gozar—!"

    # say L594 bil
    old "Heh... look at the mess you made on me. Someone really liked this outfit."
    new "B:bil: Mmm... sim, é isso. Goza todo em cima do meu rabo."

    # say L595 pla
    old "That was insane... we could've been caught..."
    new "B:bil: Heh... olha a confusão que fizeste em mim. Alguém realmente gostou deste fato."

    # say L596 bil
    old "But we weren't. Now help me clean up before that lazy bitch looks up from her phone."
    new "B:pla: Isso foi louco... poderíamos ter sido apanhados..."

    # say L607 bil
    old "Mmm... feel how soft and warm they are wrapping all around your cock?"
    new "B:bil: Mas não estavamos. Agora ajuda-me a limpar antes que essa preguiçosa olhe para cima do telemóvel."

    # say L608 pla
    old "Fuck... Billie... your tits feel amazing..."
    new "B:bil: Mmm... sente como são macios e quentes a envolver o teu pau?"

    # say L612 bil
    old "You're throbbing so much between them. You love fucking my tits, don't you?"
    new "B:pla: Merda... Billie... os teus peitos sentem-se incríveis..."

    # say L617 bil
    old "That's it... fuck my tits harder. I want you to cum all over them."
    new "B:bil: Estás a latejar tanto entre eles. Adoras foder as minhas tetas, não é?"

    # say L618 pla
    old "Billie... I'm gonna cum..."
    new "B:bil: É isso... fode as minhas tetas mais forte. Quero que gozes em cima delas."

    # say L619 bil
    old "Do it. Cover my tits. I want to feel your hot load on me."
    new "B:pla: Billie... Vou gozar..."

    # say L642 pla
    old "Ahh— fuck— I'm cumming!"
    new "B:bil: Faz isso. Cobre os meus peitos. Quero sentir o teu gozo quente em mim."

    # say L643 bil
    old "Mmm... yes, give it to me. Cum all over my tits."
    new "B:pla: Ahh— foda-se— eu estou a gozar!"

    # say L650 bil
    old "Heh... look at you. Made another mess on me."
    new "B:bil: Hmm... sim, dá-me. Goza todo em cima dos meus peitos."

    # say L651 bil
    old "Guess my tits are too much for you."
    new "B:bil: Heh... olha para ti. Fizeste outra sujeira em mim."

    # say L652 bil
    old "It's nice you like them so much..."
    new "T(bil|tu|say): É bom que gostes tanto delas..."

    # say L664 bil
    old "Mmm... slow... just like this... I want to feel every inch of you."
    new "B:bil: É bom que gostes tanto deles..."

    # say L665 pla
    old "You feel so good... so warm..."
    new "B:bil: Mmm... devagar... assim... quero sentir cada centímetro teu."

    # say L666 bil
    old "Mmm... deeper... I need you inside me... all of you."
    new "B: Tu sentes-te tão bem... tão quente..."

    # say L670 bil
    old "Ahh... yes... right there..."
    new "B:bil: Mmm... mais fundo... Preciso de ti dentro de mim... todo tu."

    # say L671 pla
    old "Fuck... Billie... you’re perfect."
    new "B:bil: Ahh... sim... bem aí..."

    # say L672 bil
    old "Don’t hold back... I want all of you tonight... I need this."
    new "B:pla: Merda... Billie... tu és perfeita."

    # say L676 bil
    old "Harder... don’t stop... I want to feel you lose control..."
    new "B:bil: Não te contenhas... Quero tudo de ti esta noite... Preciso disto."

    # say L677 pla
    old "I’m getting so close..."
    new "B:bil: Mais forte... não pares... quero sentir-te a perder o controlo..."

    # say L678 bil
    old "Inside me... cum inside me... I want to feel you let go completely."
    new "B:pla: Estou a ficar tão perto..."

    # say L701 pla
    old "Billie— I’m cumming—!"
    new "B:bil: Dentro de mim... goza dentro de mim... quero sentir-te a soltares-te completamente."

    # say L702 bil
    old "Yes— fill me up... give me everything..."
    new "B:pla: Billie— Estou a gozar—!"

    # say L708 bil
    old "Mmm... I can still feel you pulsing inside me..."
    new "B:bil: Sim— enche-me... dá-me tudo..."

    # say L709 pla
    old "That was... incredible."
    new "T(pla|tu|say): Isso foi... incrível."

    # say L710 bil
    old "That wasn’t everything. Tonight I don’t want to stop until you’ve given me all of you."
    new "B:pla: Isso foi... incrível."

    # say L711 bil
    old "Come here... don’t pull out yet."
    new "B:bil: Isso não foi tudo. Hoje à noite não quero parar até que me tenhas dado tudo."

    # say L712 bil
    old "I want to feel you again... deeper this time."
    new "B:bil: Vem cá... não tires ainda."

    # say L728 bil
    old "Slow... just like that... I love feeling you fill me completely."
    new "B:bil: Quero sentir-te de novo... mais fundo desta vez."

    # say L729 pla
    old "God, Billie... you’re so tight... so warm..."
    new "B:bil: Devagar... assim mesmo... Adoro sentir-te a preencher-me completamente."

    # say L730 bil
    old "Mmm... keep your eyes on me... I know how much you love looking at my tits like this."
    new "B:pla: Meu Deus, Billie... tu és tão apertada... tão quente..."

    # say L731 bil
    old "Look at them bouncing for you... they’re all yours tonight."
    new "B:bil: Mmm... mantém os olhos em mim... sei o quanto gostas de olhar para os meus peitos assim."

    # say L735 bil
    old "Ahh... yes... right there... harder now..."
    new "B:bil: Olha para eles a saltitar para ti... são todos teus esta noite."

    # say L736 pla
    old "You feel amazing... I can’t get enough of you."
    new "T: Sentes-te incrível... Não consigo resistir a ti."

    # say L737 bil
    old "Don’t hold back... I need you to lose yourself in me tonight."
    new "B: Tu és incrível... Não consigo ter o suficiente de ti."

    # say L741 bil
    old "Faster... fuck me harder... I want everything you have left."
    new "B:bil: Não te contenhas... Preciso que te percas em mim esta noite."

    # say L742 pla
    old "Billie... I’m so close again..."
    new "B:bil: Mais rápido... foda-me mais forte... quero tudo o que ainda tens."

    # say L743 bil
    old "Then give it to me... cum inside me again... fill me up."
    new "B:pla: Billie... Estou tão perto de novo..."

    # say L767 bil
    old "Yes— deep inside... let go... I want to feel every drop."
    new "T(bil|tu|say): Sim— bem fundo... deixa ir... quero sentir cada gota."

    # say L773 bil
    old "Mmm... I feel you throbbing again... so warm..."
    new "B:bil: Sim— bem no fundo... deixa ir... quero sentir cada gota."

    # say L774 bil
    old "I don’t want this night to end..."
    new "B:bil: Mmm... Sinto-te a latejar de novo... tão quente..."

    # say L775 pla
    old "Neither do I."
    new "B:bil: Não quero que esta noite acabe..."

    # say L776 bil
    old "But tomorrow is going to be a long day..."
    new "B:pla: Nem eu."

    # say L777 pla
    old "Yeah... I know."
    new "T(pla|tu|say): Sim... Eu sei."

    # say L778 bil
    old "I hate saying it, but we both need to rest."
    new "T(bil|tu|say): Odio dizer isto, mas ambos precisamos de descansar."

    # say L779 pla
    old "You’re right, we better get dressed in case your grandma shows up."
    new "B:bil: Odeio dizer isto, mas nós dois precisamos de descansar."

    # say L792 bil
    old "Ahh... just like that..."
    new "B:pla: Tens razão, melhor vestirmo-nos caso a tua avó apareça."

    # say L793 pla
    old "Focus on my mouth... nothing else matters right now."
    new "T(pla|tu|say): Concentra-te na minha boca... nada mais importa agora."

    # say L797 bil
    old "Yes... right there... don’t stop..."
    new "B:pla: Concentra-te na minha boca... nada mais importa agora."

    # say L798 pla
    old "You’re getting so wet... that’s it, let go."
    new "T: Estás a ficar tão molhada... é isso, deixa ir."

    # say L802 bil
    old "Harder... use your tongue... I’m so close..."
    new "B:pla: Estás tão molhada... é isso, deixa ir."

    # say L804 bil
    old "Ahh— I’m— I’m cumming—!"
    new "B: Bil: Mais forte... usa a língua... Estou tão perto..."

    # say L832 bil
    old "Fuck... that actually worked..."
    new "B:bil: Ahh— Estou— Estou a gozar—!"

    # say L833 pla
    old "You look a lot calmer now."
    new "B:bil: Merda... isso realmente funcionou..."

    # say L834 bil
    old "I do... thank you. I really needed that."
    new "B:pla: Tu pareces muito mais calmo agora."

    # say L835 pla
    old "I don’t want to freak you out, but the contest already started. We gotta get on stage."
    new "B:bil: Eu faço... obrigado. Precisava mesmo disso."

    # say L836 bil
    old "Okay, okay... yeah, I feel way better now. Let’s go."
    new "T(bil|tu|say): Okay, okay... sim, já me sinto muito melhor agora. Vamos lá."

    # say L848 bil
    old "Mmm... feel how soft they are wrapping around you?"
    new "B:bil: Okay, okay... sim, estou a sentir-me muito melhor agora. Vamos."

    # say L849 pla
    old "Fuck... Billie... they feel perfect..."
    new "B:bil: Mmm... sente como são macias a envolver-te?"

    # say L853 bil
    old "You’re throbbing so much between them... you love fucking my tits, don’t you?"
    new "B:pla: Merda... Billie... eles sentem-se perfeitos..."

    # say L854 pla
    old "Yes... don’t stop..."
    new "B:bil: Estás a latejar tanto entre eles... adoras foder as minhas tetas, não é?"

    # say L858 bil
    old "Harder... fuck them... I want you to cum all over them."
    new "B:pla: Sim... não pares..."

    # say L859 pla
    old "Billie... I’m so close..."
    new "B:bil: Mais forte... foda-os... Quero que gozes em cima deles."

    # say L860 bil
    old "Then do it. Cover me."
    new "B:pla: Billie... Estou tão perto..."

    # say L883 pla
    old "Ahh— fuck— I’m cumming—!"
    new "B:bil: Então faz isso. Cobre-me."

    # say L884 bil
    old "Mmm... yes, give me every drop... paint them nice and white."
    new "B:pla: Ahh— foda-se— estou a gozar—!"

    # say L891 bil
    old "Heh... look at the mess you made."
    new "B:bil: Mmm... sim, dá-me cada gota... pinta-os bem brancos."

    # say L893 bil
    old "We’re not done yet."
    new "B:bil: Heh... olha a confusão que fizeste."

    # say L894 bil
    old "Come here... I want you inside me again."
    new "T(bil|tu|say): Vem aqui... Quero-te dentro de mim outra vez."

    # say L906 bil
    old "Slow at first... I want to feel all of you."
    new "B:bil: Vem aqui... Quero-te dentro de mim outra vez."

    # say L916 bil
    old "Mmm... yes... just like that..."
    new "B:bil: Devagar no início... Quero sentir tudo de ti."

    # say L917 pla
    old "You feel so good... so tight..."
    new "T: Sentes-te tão bem... tão apertado..."

    # say L921 bil
    old "Harder... don’t hold back..."
    new "B:pla: Tu sentes-te tão bem... tão apertada..."

    # say L922 pla
    old "Billie... you’re perfect."
    new "B:bil: Mais forte... não te contenhas..."

    # say L926 bil
    old "Fuck me... I want everything you have left..."
    new "B:pla: Billie... tu és perfeito."

    # say L927 pla
    old "I’m gonna cum again..."
    new "B:bil: Foda-me... Quero tudo o que ainda tens..."

    # say L928 bil
    old "Inside me... fill me up one more time."
    new "B:pla: Vou gozar de novo..."

    # say L952 bil
    old "Yes... give it all to me..."
    new "B:bil: Dentro de mim... enche-me mais uma vez."

    # say L959 bil
    old "Mmm... I can feel you... so warm inside..."
    new "B:bil: Sim... dá-me tudo..."

    # say L960 pla
    old "I don’t think I can move..."
    new "B:bil: Mmm... Sinto-te... tão quente por dentro..."

    # say L961 bil
    old "Then don’t. Stay right here with me."
    new "B:pla: Acho que não consigo mexer-me..."

    # say L962 bil
    old "Tonight... everything feels right."
    new "B:bil: Então não faças. Fica aqui comigo."

    # say L963 pla
    old "We did it. Together."
    new "B:bil: Esta noite... tudo parece certo."

    # say L964 bil
    old "Yeah... we really did."
    new "B:pla: Conseguimos. Juntos."

    # say L978 bil
    old "Mmm... circle my clit first. Gentle, like I showed you."
    new "Mmm... circula o meu clitóris primeiro. Suave, como te mostrei."

    # say L979 pla
    old "Like this?"
    new "T(pla|tu|say): Assim?"

    # say L980 bil
    old "Deeper. Slide one in and curl it. You already know the spot."
    new "T(bil|tu|say): Mais fundo. Entra com um e faz um caracol. Tu já sabes o sítio."

    # say L984 bil
    old "Add another—fuck—yes, right there. You’re getting so good at this."
    new "B:bil: Mais fundo. Entra com um e faz curva. Tu já sabes o sítio."

    # say L988 bil
    old "Harder, baby. Make me cum all over your hand."
    new "B: Adiciona mais—foda—sim, bem aí. Tu estás a ficar tão bom nisto."

    # say L1011 bil
    old "I’m—cumming—fuck—!"
    new "B:bil: Mais forte, bebé. Faz-me gozar na tua mão."

    # say L1017 bil
    old "Shit... your fingers really kept perfect rhythm this time."
    new "B:bil: Estou—a gozar—merda—!"

    # say L1018 bil
    old "You’re getting faster and way more precise every time. I can feel it."
    new "B:bil: Merda... os teus dedos mantiveram mesmo o ritmo perfeito desta vez."

    # say L1019 bil
    old "This is exactly the kind of dexterity we need... both on stage and off it."
    new "B:bil: Tu estás a ficar mais rápido e muito mais preciso a cada vez. Eu consigo sentir."

    # say L1035 pla
    old "You’re already dripping..."
    new "A:bil: Mais fundo—foda-se—mantém o ritmo constante."

    # say L1039 bil
    old "Deeper—fuck—keep the rhythm steady."
    new "T(bil|tu|say): Mais fundo—foda—mantém o ritmo constante."

    # say L1043 bil
    old "Faster—make me cum while I try to hold the note—ahh—!"
    new "B:bil: Mais fundo—foda-se—mantém o ritmo constante."

    # say L1066 bil
    old "I’m cumming—fuck—yes—!"
    new "B:bil: Mais rápido—faz-me gozar enquanto tento manter a nota—ahh—!"

    # say L1073 bil
    old "Nngh... your tongue is getting way too good at this."
    new "B:bil: Estou a gozar—merda—sim—!"

    # say L1074 bil
    old "You held me through it perfectly. That’s the kind of control I need."
    new "B:bil: Nngh... a tua língua está a ficar cada vez melhor nisto."

    # say L1075 bil
    old "Every time you do this my voice gets stronger under pressure... and I get to enjoy that mouth of yours."
    new "T(bil|tu|say): Cada vez que fazes isto a minha voz fica mais forte sob pressão... e eu consigo desfrutar da tua boca."

    # say L1088 bil
    old "Mmm... look at you. Already so hard just from asking."
    new "B:bil: Cada vez que fazes isto a minha voz fica mais forte sob pressão... e consigo desfrutar da tua boca."

    # say L1089 pla
    old "Billie... that feels so good..."
    new "B:bil: Hmm... olha para ti. Já tão duro só de pedir."

    # say L1094 bil
    old "Deeper now... I want to feel every throb."
    new "B:pla: Billie... isso sente-se tão bem..."

    # say L1095 pla
    old "Fuck... you’re way too good at this."
    new "B:bil: Mais fundo agora... Quero sentir cada pulsação."

    # say L1100 bil
    old "Don’t hold back. Cum for me. Let me give you the motivation you need."
    new "B:pla: Merda... tu és demasiado bom nisto."

    # say L1101 pla
    old "I’m— I’m close...!"
    new "B:bil: Não te contenhas. Goza para mim. Deixa-me dar-te a motivação de que precisas."

    # say L1126 bil
    old "Mmm... every drop. Good boy."
    new "B:pla: Estou... estou perto...!"

    # say L1133 bil
    old "Heh... feeling more motivated already?"
    new "B:bil: Mmm... cada gota. Bom rapaz."

    # say L1134 bil
    old "Your confidence always shoots up after this. I can tell."
    new "B:bil: Heh... já estás a sentir-te mais motivado?"

    # say L1135 bil
    old "Come back whenever you need some real motivation again... I’ll be waiting."
    new "B:bil: A tua confiança sempre sobe depois disto. Eu consigo notar."


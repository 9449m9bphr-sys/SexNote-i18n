# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/GraStory.rpy
translate portuguese strings:

    # say L5 pla
    old "(God! I hope everybody is sleeping already... I gotta whisper to her...)"
    new "(pla|tu|say): (Que raio! Espero que todos estejam a dormir... Tenho de sussurrar-lhe...)"

    # say L11 gra
    old "If you come to steal, you are in the wrong place... Don't you see this is God's house?!"
    new "B:gra: Olá! Quem é?"

    # say L13 pla
    old "(Holy shit! The nun heard me... I need to hide.)"
    new "B:gra: Se vieste roubar, estás no sítio errado... Não vês que isto é a casa de Deus?!"

    # say L22 gra
    old "(But... I don't see anybody... God! Maybe it is Father Morgan...)"
    new "B:pla: (Puta merda! A freira ouviu-me... Preciso de me esconder.)"

    # say L28 gra
    old "Father Morgan? It is you? I'm sorry, I thought it was somebody else, a thief... I didn't know you would have been here so late."
    new "B:gra: (Mas... não vejo ninguém... Meu Deus! Talvez seja o Padre Morgan...)"

    # say L37 pla
    old "(Holy fuck!! She also entered the confessional.)"
    new "B:gra: Padre Morgan? És tu? Desculpa, pensei que era outra pessoa, um ladrão... Não sabia que estarias aqui tão tarde."

    # say L40 gra
    old "Father? Are you upset? I'm sorry if I disturbed you with my shouting."
    new "B:pla: (Santo Deus!! Ela também entrou no confessionário.)"

    # say L41 gra
    old "I see what you're thinking... I have done wrong again and I must clean up that offense I have committed, that's why you're so quiet."
    new "B:gra: Pai? Estás zangado? Desculpa se te perturbei com os meus gritos."

    # say L43 gra
    old "No father Morgan... You don't have to say a word."
    new "B:gra: Eu vejo o que estás a pensar... Cometi um erro mais uma vez e devo limpar a ofensa que cometi, por isso estás tão calado."

    # say L44 gra
    old "You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "B:gra: Não, pai Morgan... Não tens de dizer nada."

    # say L45 gra
    old "Thoughts that I had a few minutes ago."
    new "B:gra: Sabes que sou totalmente fiel à vontade do Senhor, deixar-te-ei guiar-me mais uma vez para purificar o meu corpo desses maus pensamentos."

    # say L46 pla
    old "(What? What's she talking about?!)"
    new "B:gra: Pensamentos que tive há alguns minutos."

    # say L47 pla
    old "(What's happening with her-)"
    new "B:pla: (O quê? Do que é que ela está a falar?!)"

    # say L48 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I'm giving you my spirit through my body, Father."
    new "B: pla: (O que está a acontecer com ela-)"

    # say L49 pla
    old "(I- is she talking about... s- sex?)"
    new "B:gra: Ter fé em Deus significa não ter medo e tu és o meu guia, ajuda-me a purificar esta alma pecadora. Estou a dar-te o meu espírito através do meu corpo, Pai."

    # say L50 gra
    old "I'm ready to receive your sacred water, your purifying milk... It's my mission to reach divinity through you, let me try it one more time."
    new "B: pla: (E- ela está a falar de... s- sexo?)"

    # say L51 pla
    old "(Oh shit!... This is so wrong...)"
    new "B:gra: Estou pronta para receber a tua água sagrada, o teu leite purificador... É a minha missão alcançar a divindade através de ti, deixa-me tentar mais uma vez."

    # say L52 gra
    old "I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Tell me something or show me your help, please!"
    new "B:pla: (Oh shit!... Isto está tão errado...)"

    # say L54 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, Father."
    new "B:gra: Estou a pedir-te para me ajudares, tenho estado à beira da escuridão e tu mostraste-me a luz... Padre Morgan? Diz-me algo ou mostra-me a tua ajuda, por favor!"

    # say L55 pla
    old "(My God! Alright, I gotta do this. If I don't, she'll suspect and see that I'm not the Father Morgan.)"
    new "B:gra: Quero que o nosso Deus seja feliz, não há nada melhor ou mais bonito e vou fazê-lo feliz através de ti, Pai."

    # say L76 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. One more time, you've shown me how big and great you're, I feel your grace."
    new "B:pla: (Meu Deus! Tudo bem, tenho de fazer isto. Se não o fizer, ela vai suspeitar e ver que eu não sou o Padre Morgan.)"

    # say L77 gra
    old "I will go to pray for you and for your great and powerful divine tool."
    new "B:gra: Meu grande Pai Morgan, não tenho palavras para expressar a minha gratidão. Mais uma vez, mostraste-me o quão grande e poderoso és, sinto a tua graça."

    # say L79 gra
    old "Good night Father Morgan, I'll be eager to see you again."
    new "B:gra: Vou rezar por ti e pela tua grande e poderosa ferramenta divina."

    # say L93 pla
    old "(What a night!...)"
    new "B:gra: Boa noite, Padre Morgan, ansiosa estou por te ver de novo."

    # say L94 pla
    old "(Argh! The shinigami... Shit! I couldn't find her! But I can't risk myself, perhaps the nun or the priest could come back...)"
    new "B: (Que noite!...)"

    # say L95 pla
    old "(I better come back another day...)"
    new "B:pla: (Argh! A shinigami... Merda! Não consegui encontrá-la! Mas não posso correr riscos, talvez a freira ou o padre possam voltar...)"

    # say L108 pla
    old "(I hope the Sister Grace doesn't not appear tonight...)"
    new "B: (Melhor voltar noutro dia...)"

    # say L114 gra
    old "Is it you again?..."
    new "B:gra: Olá! Pai Morgan?"

    # say L116 pla
    old "(Oh no! She's back... Damn it!)"
    new "B:gra: És tu de novo?..."

    # say L126 gra
    old "Father Morgan? I was eager to see you again..."
    new "B:pla: (Oh não! Ela voltou... Merda!)"

    # say L135 gra
    old "Father? I'm sorry for bothering you again but I still need some help, my sins keep disturbing my soul."
    new "B:gra: Padre Morgan? Estava ansioso por vê-lo de novo..."

    # say L136 gra
    old "I need to continue with the penance."
    new "B:gra: Pai? Sinto muito por incomodá-lo de novo, mas ainda preciso de ajuda, os meus pecados continuam a perturbar a minha alma."

    # say L140 gra
    old "No father Morgan... You know I'm totally faithful to the will of the Lord, I will let you guide me once again to cleanse my body of those bad thoughts."
    new "B:gra: Preciso continuar com a penitência."

    # say L141 gra
    old "Thoughts that I had today, again..."
    new "B:gra: Não, pai Morgan... Sabes que sou totalmente fiel à vontade do Senhor, deixar-te-ei guiar-me mais uma vez para purificar o meu corpo desses maus pensamentos."

    # say L142 pla
    old "(I guess I already know what she wants...)"
    new "B:gra: Pensamentos que tive hoje, de novo..."

    # say L143 pla
    old "(But what's happening with her, why to do this?)"
    new "A:gra: Ter fé em Deus significa não ter medo e tu és o meu guia, ajuda-me a purificar esta alma pecadora. Estou a dar-te o meu espírito através do meu corpo, Pai."

    # say L144 gra
    old "Having faith in God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "B: pla: (Mas o que está a acontecer com ela, porquê fazer isto?)"

    # say L145 pla
    old "(Well, I gotta do it... Otherwise she'll realized I'm not the Father Morgan)"
    new "B:gra: Ter fé em Deus significa não ter medo e tu és o meu guia, ajuda-me a purificar esta alma pecadora. Estou a dar-te o meu espírito através do meu corpo, Pai."

    # say L146 gra
    old "Yes, I'm asking you to help me, I've been on the edge of darkness and you've shown me the light... Father Morgan? Show me your help, please!"
    new "B:pla: (Bem, tenho de o fazer... Senão ela vai perceber que não sou o Padre Morgan)"

    # say L148 gra
    old "I want our God to be happy, there is nothing better or more beautiful and I will make him happy through you, my greatest Father."
    new "B:gra: Sim, estou a pedir-te ajuda, tenho estado à beira da escuridão e tu mostraste-me a luz... Padre Morgan? Mostra-me a tua ajuda, por favor!"

    # say L149 gra
    old "My soul is open to be purified, as opened as my mouth right now..."
    new "B:gra: Quero que o nosso Deus seja feliz, não há nada melhor ou mais belo e vou fazê-lo feliz através de ti, meu maior Pai."

    # say L150 pla
    old "(Oh God!)"
    new "B:gra: A minha alma está aberta para ser purificada, tão aberta quanto a minha boca neste momento..."

    # say L166 gra
    old "My great Father Morgan, you have no idea how grateful I'm. One more time, you've shown me how big and great you're, I can taste your grace."
    new "B:pla: (Oh Deus!)"

    # say L169 gra
    old "Good night Father Morgan, I'll be needing more of your sacred assistance to purify my existence in this world."
    new "B:gra: Meu grande Pai Morgan, tu não tens ideia de como estou grato. Mais uma vez, mostraste-me o quão grande e poderoso és, posso sentir a tua graça."

    # say L183 pla
    old "(Damn it! I couldn't find the shinigami tonight either... I better come back another day... This is to risky, the nun could come back...)"
    new "B:gra: Boa noite, Padre Morgan, vou precisar de mais da sua sagrada assistência para purificar a minha existência neste mundo."

    # say L196 pla
    old "(God! This is my last chance to find the shinigami, I gotta find her tonight.)"
    new "B: (Maldição! Não consegui encontrar o shinigami outra vez... Melhor voltar noutro dia... Isto é muito arriscado, a freira pode voltar...)"

    # say L203 pla
    old "(Argh! No... No again!!!)"
    new "B:gra: Pai Morgan... Estou tão contente que estás aqui."

    # say L213 gra
    old "I was waiting for you, my holy savior."
    new "B:pla: (Argh! Não... Não de novo!!!)"

    # say L221 gra
    old "Father Morgan? How should we start tonight? Just tell me..."
    new "B:gra: Estava à espera de ti, meu santo salvador."

    # say L222 pla
    old "(Holy fuck!! She'll catch me this time...)"
    new "B:gra: Padre Morgan? Como devemos começar esta noite? Diz-me..."

    # say L223 gra
    old "Father? I already know you don't like to talk much when you're praying and well... I know what my soul needs this time. "
    new "B:pla: (Puta merda!! Ela vai apanhar-me desta vez...)"

    # say L227 gra
    old "Thoughts that I have had since long time ago."
    new "B:gra: Pai? Já sei que não gostas de falar muito quando estás a rezar e bem... sei o que a minha alma precisa desta vez."

    # say L229 gra
    old "Having faith in your God means not being afraid and you are my guide, help me to purify this sinful soul. I am giving you my spirit through my body, Father."
    new "B:gra: Pensamentos que tenho há muito tempo."

    # say L230 pla
    old "(Shit!... I gotta do it again.)"
    new "B:gra: Ter fé no teu Deus significa não ter medo e tu és o meu guia, ajuda-me a purificar esta alma pecadora. Estou a dar-te o meu espírito através do meu corpo, Pai."

    # say L248 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're, I feel your grace inside."
    new "B:pla: (Merda!... Tenho de o fazer de novo.)"

    # say L251 gra
    old "Good night Father Morgan, I can't wait to feel you inside of me again."
    new "B:gra: Meu grande Pai Morgan, não tenho palavras para expressar o meu agradecimento. Mostraste-me o quão grande e poderoso és, sinto a tua graça dentro de mim."

    # say L266 pla
    old "(Damn it! This is becoming more and more complicated.)"
    new "B:gra: Boa noite, Padre Morgan, mal posso esperar para sentir-te dentro de mim outra vez."

    # say L281 pla
    old "Hmm looks like no one is around."
    new "B:pla: (Maldição! Isto está a ficar cada vez mais complicado.)"

    # say L282 pla
    old "Maybe the nun will come later... I better go to wait at the confessional."
    new "B:pla: Hmm, parece que ninguém está por perto."

    # say L292 gra
    old "Father Morgan? You're already here, right?"
    new "B:pla: Talvez a freira venha mais tarde... Melhor ir esperar no confessionário."

    # say L301 gra
    old "Thank God! So, how should we start tonight Father? Just tell me..."
    new "B:gra: Pai Morgan? Já está aqui, certo?"

    # say L308 gra
    old "No,  you know what? It is better to trust in divine providence and may the Lord be the one to guide the forgiveness of my sins tonight."
    new "B:gra: Graças a Deus! Então, como devemos começar esta noite, Pai? Diz-me..."

    # menu L327 
    old "Sex"
    new "B:gra: Não, tu sabes o quê? É melhor confiar na providência divina e que o Senhor seja o guia para o perdão dos meus pecados esta noite."

    # say L342 gra
    old "My great Father Morgan, I don't have words to express how grateful I'm. You've shown me how big and great you're."
    new "B:n: Sexo"

    # say L354 pla
    old "(It's too late, I better go to sleep...)"
    new "B:gra: Meu grande Pai Morgan, não tenho palavras para expressar o quanto sou grato. Mostraste-me o quão grande e poderoso és."

    # say L367 pla
    old "Hi sister Grace, I'm fine and you?"
    new "B:pla: (Já é tarde demais, melhor ir dormir...)"

    # say L368 gra
    old "I'm blessed thank God... Tell me, how can I help you?"
    new "B:pla: Olá irmã Grace, estou bem e tu?"

    # say L399 gra
    old "Oh right, thank you so much for all your help."
    new "B:pla: Não te preocupes, estou só a ver se tudo está bem."

    # say L400 pla
    old "You are welcome, see you later."
    new "B:gra: Oh, certo, muito obrigado pela tua ajuda."

    # say L401 gra
    old "God be with you."
    new "Que Deus esteja contigo."


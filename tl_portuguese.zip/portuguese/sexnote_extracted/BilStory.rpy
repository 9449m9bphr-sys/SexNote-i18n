# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/BilStory.rpy
translate portuguese strings:

    # say L64 pla
    old "What's this? Doodles, messy scratches... hold up, are these lyrics?"
    new "Notas musicais rabiscadas por toda a parte. 'Ecos desvanecidos, canções que perdemos...'"

    # say L65 pla
    old "Music notes scribbled everywhere. 'Faded echoes, songs we lost...'"
    new "B:pla: O que é isto? Rabiscos, linhas desorganizadas... espera, são letras de músicas?"

    # say L69 pla
    old "Yeah, that's the right call."
    new "A:pla: Espera, o que é este panfleto no chão?"

    # say L144 pla
    old "Hold up, what’s this flyer on the floor?"
    new "T(pla|tu|say): Espera, o que é este panfleto no chão?"

    # say L150 pla
    old "School’s doing a music contest? 'Sign up now'..."
    new "B:pla: Espera, o que é este folheto no chão?"

    # say L339 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 percent yourself. Ready? Let’s make magic!"
    new "B:pla: A escola está a fazer um concurso de música? 'Inscrições agora'..."

    # say L415 bey
    old "Arielle and Kayla!"
    new "B:bey: Então respira, diverte-te e lembra-te: o palco é o único lugar onde podes ser 100 por cento tu mesma. Pronta? Vamos fazer magia!"

    # say L425 bey
    old "Lord have mercy on my edges! Arielle, those whistle tones cleaner than my Sunday choir. Kayla, that belt could wake the dead."
    new "T(bey|tu|diz): Senhor tenha misericórdia das minhas arestas! Arielle, esses tons agudos mais limpos que o meu coro de domingo. Kayla, esse agudo poderia acordar os mortos."

    # say L474 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100 percent. Volume was whisper quiet, but somehow you filled the entire room."
    new "T(bey|tu|diz): A tua voz é pura veludo, a tua interpretação é emocionante, a verdade emocional está em 100 por cento. O volume era sussurrado, mas de alguma forma enches-te todo o espaço."

    # say L892 pla
    old "Let’s try again..."
    new "B:pla: Vi três tutoriais ontem à noite. Quão difícil pode ser?"

    # say L905 pla
    old "One more time. Come on, [pla]."
    new "T(pla|tu|say): Mais uma vez. Vamos lá, [pla]."

    # say L934 pla
    old "Ugh, enough for today. Fingers are officially dead."
    new "B:pla: Okay... isso quase soou como música... certo?"

    # say L1109 pla
    old "Wow... you're amazing."
    new "B:pla: Ugh, chega por hoje. Os dedos estão oficialmente mortos."

    # say L1377 pla
    old "Still not perfect... but it sounded more like a song this time."
    new "A:pla: E-eles são tão sensíveis... Posso sentir que estão a endurecer mais."

    # say L1551 pla
    old "T- they're so sensitive... I can feel them hardening more."
    new "B: pla: Ainda não está perfeito... mas soou mais como uma música desta vez."

    # say L1604 pla
    old "W- what do you have in mind?"
    new "B: T- eles são tão sensíveis... Sinto-os a endurecer mais."

    # say L1613 bil
    old "And of course, I know you’re gonna need a little extra motivation..."
    new "B:pla: E-e o que tu tens em mente?"

    # say L1623 bil
    old "Shh. Focus. This is practical training, remember?"
    new "B:bil: E claro, sei que vais precisar de um pouco de motivação extra..."

    # say L1624 pla
    old "O- Ok..."
    new "A:bil: Mmm... bom. Sente como reage debaixo dos teus dedos?"

    # say L1625 bil
    old "Mmm... good. Feel how it responds under your fingers?"
    new "T(bil|tu|say): Mmm... bom. Sentes como reage debaixo dos teus dedos?"

    # say L1626 pla
    old "It's... getting wetter already."
    new "B:bil: Mmm... bom. Sente como reage debaixo dos teus dedos?"

    # say L1627 bil
    old "That's normal. Keep the rhythm steady. You're learning the technique."
    new "T(bil|tu|say): É normal. Mantém o ritmo constante. Estás a aprender a técnica."

    # say L1632 bil
    old "Now increase the pressure a bit. Faster circles. Don't lose the rhythm."
    new "B:bil: Is normal. Mantém o ritmo constante. Estás a aprender a técnica."

    # say L1634 bil
    old "Nngh— yes... that's it. You're doing well. Keep going."
    new "B:bil: Agora aumenta a pressão. Círculos mais rápidos. Não percas o ritmo."

    # say L1639 bil
    old "Harder. Don't stop. Make me feel it."
    new "B:bil: Nngh— sim... é isso. Estás a fazer bem. Continua."

    # say L1640 pla
    old "[bil]... you're breathing heavier."
    new "T: [bil]... tu estás a respirar mais pesado."

    # say L1646 bil
    old "Ngh- Stop, stop, stop..."
    new "B:bil: Merda... assim mesmo. Continua. Nem ouse desacelerar."

    # say L1647 pla
    old "... Did I do something wrong?"
    new "T:... Fiz algo errado?"

    # say L1648 bil
    old "Mmm, no, no... actually you were doing it really well."
    new "B:pla:... Fiz algo errado?"

    # say L1649 bil
    old "But I want you to try something... Uhh, more advanced."
    new "B:bil: Mmm, não, não... na verdade tu estavas a fazer muito bem."

    # say L1650 bil
    old "Now... use two fingers. Slide them in together. Start slow."
    new "T(bil|tu|say): Agora... usa dois dedos. Introduz-os juntos. Começa devagar."

    # say L1652 pla
    old "Uhh... like this?"
    new "B:bil: Agora... usa dois dedos. Introduz-os juntos. Começa devagar."

    # say L1653 bil
    old "Mmm, yeah, just like that..."
    new "B:pla: Uhh... assim?"

    # say L1654 bil
    old "Curl them. Find the spot and start moving them slowly... let me feel it."
    new "B:bil: Hmm, sim, assim mesmo..."

    # say L1755 bil
    old "Ready for your advanced practice?"
    new "Finalmente. Tu estás atrasado."

    # say L1808 bil
    old "Finally. You're late."
    new "B:bil: Pronto para a tua prática avançada?"

    # say L1809 pla
    old "I know, I know... I’m sorry."
    new "B:bil: Finalmente. Estás atrasado."

    # say L1810 bil
    old "We don’t have time for this. The teacher’s expecting us."
    new "A:pla: Billie... Espera!"

    # say L1813 pla
    old "Billie... Wait!"
    new "B:bil: Não temos tempo para isso. O professor está à espera de nós."

    # say L1815 pla
    old "I- I don’t think I can do this."
    new "B:pla: Billie... Espera!"

    # say L1816 bil
    old "Here we go again."
    new "B:pla: Eu... Acho que não consigo fazer isto."

    # say L1817 pla
    old "I mean it. I don’t feel ready. Not even close."
    new "A:bil: Vamos! Tu tens estado a praticar durante dias. Melhoraste imenso."

    # say L1818 bil
    old "Come on! You’ve been practicing for days. You improved a ton."
    new "B:pla: A sério. Não me sinto preparado. Nem perto disso."

    # say L1819 pla
    old "Yeah, but only with you. Or at home. This is different. With the teacher... with pressure... I’m not ready."
    new "B:bil: Vamos! Tu tens estado a praticar durante dias. Melhoraste imenso."

    # say L1820 bil
    old "Relax, you don’t have to be perfect today."
    new "T(bil|tu|say): Relaxa, não tens de ser perfeito hoje."

    # say L1821 pla
    old "But I’m barely even good. What if I mess everything up?"
    new "A:bil: Então tu falhas. Acontece."

    # say L1822 bil
    old "Then you mess up. It happens."
    new "B:pla: Mas eu mal sou boa. E se eu estragar tudo?"

    # say L1823 pla
    old "I don't know, Billie... maybe you should just do this one alone."
    new "B:bil: Então tu falhas. Acontece."

    # say L1824 bil
    old "Stop. You’re not backing out now."
    new "B:pla: Não sei, Billie... talvez deves fazer isto sozinha."

    # say L1825 pla
    old "Billie... I really don’t think I can do this."
    new "B:bil: Pára. Não vais recuar agora."

    # say L1826 bil
    old "Shut Up! I know you can. You’ve improved. A lot."
    new "B:pla: Billie... Eu realmente não acho que consigo fazer isto."

    # say L1827 pla
    old "But what if I freeze? What if everything falls apart? What if—"
    new "B:bil: Cala-te! Eu sei que consegues. Melhoraste. Muito."

    # say L1828 bil
    old "Okay, okay, breathe. You’re spiraling."
    new "T(bil|tu|say): Ok, ok, respira. Estás a entrar em pânico."

    # say L1829 pla
    old "I- I don’t know... I feel like I’m gonna choke the moment she looks at me."
    new "B:bil: Okay, okay, respira. Estás a entrar em pânico."

    # say L1830 bil
    old "Look, standing here arguing isn’t helping either. Come with me."
    new "T(bil|tu|say): Olha, ficar aqui a discutir não está a ajudar. Vem comigo."

    # say L1831 pla
    old "What? W- where?"
    new "B:bil: Olha, ficar aqui a discutir não ajuda ninguém. Vem comigo."

    # say L1832 bil
    old "Somewhere quiet. You need to reset before we walk in there."
    new "B:pla: O quê? O- onde?"

    # say L1855 pla
    old "The bathroom? [bil], what are we—"
    new "T(pla|tu|say): A casa de banho? [bil], o que estamos a fazer—"

    # say L1857 pla
    old "Uhh, W- what? Why? We should be heading to class."
    new "A:bil: Calma, tu precisas de acalmar-te primeiro. Vê."

    # say L1858 bil
    old "Listen, you need to chill first. Watch."
    new "B:pla: Uhh, E- espera? Porquê? Devíamos ir para a aula."

    # say L1863 pla
    old "I... Uh... they're... wow."
    new "T: Eu... hã... eles são... uau."

    # say L1864 bil
    old "Heh. Does this help?"
    new "B:pla: Eu... Ah... eles estão... uau."

    # say L1865 pla
    old "Kinda? But... this isn't about that."
    new "B:bil: Heh. Isto ajuda?"

    # say L1866 bil
    old "You can touch them if you want. Might relax you more."
    new "B:pla: Tipo? Mas... isto não é sobre isso."

    # say L1867 pla
    old "Hmm... to be honest, I don't think this is gonna help with the anxiety."
    new "Hmm... a ser sincero, não acho que isto vá ajudar com a ansiedade."

    # say L1868 bil
    old "Really? Not even a little?"
    new "B:pla: Hmm... para ser honesto, não acho que isto vá ajudar com a ansiedade."

    # say L1869 pla
    old "I mean, I really like them, of course. But I'm still freaked about performing."
    new "B:bil: Mesmo? Nem um pouco?"

    # say L1870 bil
    old "Hmm. Okay, okay... Plan B then."
    new "T(bil|tu|say): Hmm. Okay, okay... Plano B então."

    # say L1871 pla
    old "Plan B?"
    new "B:bil: Hmm. Okay, okay... Plano B então."

    # say L1872 bil
    old "Yeah. Something that always works."
    new "B:pla: Plano B?"

    # say L1881 pla
    old "This is crazy... but... don't stop."
    new "B:bil: Shh. Deixa-me lidar com o teu stress."

    # say L1893 bil
    old "Told you. My methods are foolproof."
    new "B:pla: Isto é louco... mas... não pares."

    # say L1894 pla
    old "Phew... okay, nerves are gone. Mostly."
    new "B:bil: Já te disse. Os meus métodos são infalíveis."

    # say L1895 bil
    old "Good. Now let's go before Bey bails on us."
    new "B:pla: Ufa... ok, os nervos passaram. Mais ou menos."

    # say L1896 pla
    old "Right. I'm ready now. I think."
    new "B:bil: Bom. Vamos antes que a Bey desista."

    # say L1897 bil
    old "You are. Come on."
    new "A:bey: Oh! Aí estão vocês. Eu estava prestes a sair."

    # say L1906 bey
    old "Oh! There you two are. I was about to leave."
    new "T: Oh! Aí estais vocês. Ia-me embora."

    # say L1907 bil
    old "Sorry. We had... a situation."
    new "A:bey: Uma situação?"

    # say L1909 bey
    old "A situation?"
    new "T(bey|tu|say): Uma situação?"

    # say L1910 bil
    old "Stage panic. I had to calm him down with... a technique that always works."
    new "B:bey: Uma situação?"

    # say L1911 bey
    old "Oh! Well, whatever you did, I’m glad it helped. Next time, bring him here, I have plenty of ways to help with anxiety too."
    new "B:bil: Pânico de palco. Tive que acalmá-lo com... uma técnica que sempre funciona."

    # say L1912 bil
    old "Don’t worry. I have a method that works every time."
    new "B:bey: Oh! Bem, seja o que for que tenhas feito, fico contente que tenha ajudado. Da próxima vez, traz-o aqui, tenho imensos métodos para ajudar com a ansiedade."

    # say L1914 bey
    old "Well, as long as he’s fine now."
    new "B:bil: Não te preocupes. Tenho um método que funciona sempre."

    # say L1915 pla
    old "I... think so."
    new "A:bey: Bom. Agora conta-me, como têm estado vocês dois? A praticar juntos?"

    # say L1916 bey
    old "Good. Now tell me, how have you two been? Practicing together?"
    new "B:pla: Eu... acho que sim."

    # say L1917 bil
    old "A lot. He’s been improving faster than I expected."
    new "B:bey: Ótimo. Agora, conta-me, como têm estado os dois? A praticar juntos?"

    # say L1918 bey
    old "Really? That’s wonderful."
    new "B:bil: Muito. Ele tem melhorado mais rápido do que eu esperava."

    # say L1919 pla
    old "Uhh, actually, I’m still not that great."
    new "B:bey: Mesmo? Isso é ótimo."

    # say L1920 bey
    old "No one expects you to be. What matters is progress."
    new "B:pla: Uhh, na verdade, ainda não sou muito bom."

    # say L1921 bil
    old "He’s now supporting me with guitar for the performance."
    new "B:bey: Ninguém espera que tu sejas. O que importa é o progresso."

    # say L1922 bey
    old "Ah! Excellent idea. Your voice with live accompaniment gives the duet a lot of potential."
    new "B:bil: Ele está agora a apoiar-me com a guitarra para a atuação."

    # say L1923 bil
    old "Yeah, that’s the plan."
    new "B:bey: Ah! Excelente ideia. A tua voz com acompanhamento ao vivo dá muito potencial ao dueto."

    # say L1924 bey
    old "Alright then, let’s hear you. Perform as if it were the actual contest. After that, I’ll give you both feedback."
    new "T: Tudo bem, então. Vamos ouvir-te. Apresenta-te como se fosse o concurso real. Depois disso, dou-vos feedback a ambos. A: pla: O-okay..."

    # say L1926 pla
    old "O-okay..."
    new "T(pla|tu|say): O-okay..."

    # say L1938 bey
    old "Imagine you’re already on stage at the contest. Perform the piece you’ve been working on."
    new "B:bey: Ok! E se fizéssemos isto como uma apresentação simulada?"

    # say L1939 pla
    old "{i}Billie... I don—{/i}"
    new "T: {i}Billie... Eu não—{/i}"

    # say L1980 bey
    old "This time you actually you played. And with feeling. I’m proud of that."
    new "T(bey|tu|say): Desta vez tu realmente jogaste. E com emoção. Estou orgulhoso disso."

    # say L1981 bey
    old "You still get nervous, and it shows in your transitions. A few spots were shaky."
    new "B:bey: Desta vez tu realmente jogaste. E com emoção. Estou orgulhoso disso."

    # say L1983 bey
    old "It’s normal. With more practice you'll smooth it out. If you want, you can come to extra sessions with me. I can help strengthen your hand technique."
    new "B:bey: Tu ainda ficas nervoso, e isso mostra nas tuas transições. Houve alguns pontos instáveis."

    # say L1984 bil
    old "No need. I’ve already got him on a very effective practice."
    new "B:bey: É normal. Com mais prática vais melhorar. Se quiseres, podes vir a sessões extra comigo. Posso ajudar-te a fortalecer a técnica da mão."

    # say L1985 bey
    old "Oh! Great. If it works, keep doing it. You two clearly connect well."
    new "B:bil: Não é preciso. Já o tenho numa prática muito eficaz."

    # say L1986 bey
    old "Now, Billie. As always your voice is beautiful. Rich tone, controlled color, great emotional delivery."
    new "B: Bey: Oh! Ótimo. Se funcionar, continua. Vocês dois claramente se conectam bem."

    # say L1988 bey
    old "However, there’s room to grow. You rely a bit too much on natural skill."
    new "T(bey|tu|diz): No entanto, há espaço para crescer. Tu confias um pouco demais na tua habilidade natural."

    # say L1989 bey
    old "We need to work on technique, breath support, especially sustaining phrases without losing power."
    new "B:bey: No entanto, há espaço para crescer. Tu confias um pouco demais na tua habilidade natural."

    # say L1990 bey
    old "Your diaphragm engagement is good, but not consistent. With proper training, your projection and stability will improve a lot."
    new "B:bey: Precisamos trabalhar na técnica, suporte respiratório, especialmente na manutenção das frases sem perder força."

    # say L1991 bil
    old "Oh, ok..."
    new "B:bey: A tua engajamento do diafragma é bom, mas não consistente. Com treino adequado, a tua projeção e estabilidade vão melhorar muito."

    # say L1992 bey
    old "I’d love to train that with you. Come for vocal sessions, and we’ll shape your sound for the contest."
    new "B:bil: Oh, ok..."

    # say L1993 bey
    old "Just you and me. We’ll polish your technique and make sure you’re ready for the real contest."
    new "B:bey: Adorava treinar isso contigo. Vem para as sessões vocais, e vamos moldar o teu som para o concurso."

    # say L1994 bil
    old "Sounds good. I’m in."
    new "B:bey: Só tu e eu. Vamos aperfeiçoar a tua técnica e garantir que estás pronto para a verdadeira competição."

    # say L1997 bil
    old "Oh, trust me... We definitely will."
    new "B:pla: Vamos."

    # say L1998 bey
    old "You both have something special together."
    new "B:bil: Oh, confia em mim... Vamos definitivamente."

    # say L1999 bey
    old "Keep up the rhythm. I’ll call you both again for another evaluation soon."
    new "B:bey: Vocês dois têm algo especial juntos."

    # say L2000 bil
    old "Thank you for everything."
    new "B: bey: Mantém o ritmo. Vou chamar-vos de novo para outra avaliação em breve."

    # say L2016 ari
    old "Well, well... look who actually survived a real practice session."
    new "B:bil: Obrigado por tudo."

    # say L2017 tay
    old "We heard you two through the wall. That was... almost not terrible. Hahaha"
    new "B:ari: Pois, pois... vejam quem sobreviveu a uma sessão de treino real."

    # say L2019 bil
    old "Heh. Almost?"
    new "B:tay: Ouvi-vos através da parede. Isso foi... quase aceitável. Hahaha"

    # say L2020 ari
    old "Your breath control still wavers on the sustain, sweetie. Fix it or you’ll crack on stage."
    new "B:bil: Heh. Quase?"

    # say L2023 bil
    old "Keep taking notes, girls. We’re just warming up."
    new "B:pla: Obrigado... Acho eu?"

    # say L2024 ari
    old "Please. Technique beats 'raw emotion' every single time."
    new "B:bil: Continuem a tomar notas, meninas. Estamos apenas a aquecer."

    # say L2026 tay
    old "See you at the contest... try not to choke when it actually counts."
    new "B:ari: Por favor. A técnica sempre vence a 'emoção pura'."

    # say L2032 pla
    old "They’re still exactly the same, huh?"
    new "B:tay: Vemo-nos no concurso... tenta não falhar quando realmente importa."

    # say L2033 bil
    old "Perfect. Makes crushing them way more satisfying."
    new "B:pla: Eles continuam exatamente iguais, hã?"

    # say L2040 bil
    old "Okay... I have to admit, that went better than I expected."
    new "T(bil|tu|say): Ok... Tenho de admitir, correu melhor do que esperava."

    # say L2041 pla
    old "Way better. I didn’t completely freeze."
    new "T(pla|tu|say): Muito melhor. Não fiquei completamente paralisado."

    # say L2042 bil
    old "Wow, what an achievement. Should we throw you a parade?"
    new "B:pla: Muito melhor. Não fiquei completamente paralisado."

    # say L2043 pla
    old "Hey, for me that’s huge."
    new "B:bil: Uau, que conquista. Devíamos fazer-te uma parada?"

    # say L2044 bil
    old "Yeah... it kinda is."
    new "T(bil|tu|say): Sim... é mesmo."

    # say L2045 pla
    old "Seriously, thanks for earlier. Uhh, you know."
    new "T(pla|tu|say): A sério, obrigado mais cedo. hã, tu sabes."

    # say L2046 pla
    old "If you hadn’t helped me calm down, I would’ve messed everything up."
    new "B:pla: A sério, obrigado por antes. Hã, tu sabes."

    # say L2047 bil
    old "I know."
    new "B:pla: Se não tivesses ajudado a acalmar-me, teria estragado tudo."

    # say L2048 bil
    old "You owe me one."
    new "T(bil|tu|say): Deves-me uma."

    # say L2049 pla
    old "Actually, more than one. I mean it."
    new "T: Na verdade, mais do que um. Falo a sério."

    # say L2050 bil
    old "Relax. You did the hard part. You didn’t run away."
    new "T(bil|tu|say): Relaxa. Tu fizeste a parte difícil. Não fugiste."

    # say L2051 pla
    old "Heh, I almost did."
    new "B:bil: Relaxa. Tu fizeste a parte difícil. Não fugiste."

    # say L2052 bil
    old "And I almost slapped you. Balance."
    new "B:pla: Heh, quase fiz isso."

    # say L2053 pla
    old "Still... I’m glad you didn’t let me quit."
    new "B:bil: E quase te dei uma bofetada. Equilíbrio."

    # say L2054 bil
    old "Good. Because you’re way more useful when you don’t panic every five seconds."
    new "B:pla: Ainda... Fico contente que tu não tenhas deixado que eu desistisse."

    # say L2055 pla
    old "I’m working on that."
    new "B:bil: Bom. Porque és muito mais útil quando não entras em pânico a cada cinco segundos."

    # say L2056 bil
    old "And you’re getting better. With the guitar. With the nerves. With everything."
    new "B:pla: Estou a trabalhar nisso."

    # say L2057 pla
    old "You really think so?"
    new "T: Tu realmente pensas isso?"

    # say L2058 bil
    old "Don’t get cocky. But yeah... you’re not useless anymore."
    new "T(bil|tu|say): Não fiques arrogante. Mas sim... já não és inútil."

    # say L2059 pla
    old "Haha, that’s the nicest thing you’ve ever said to me."
    new "B:bil: Não te vanglories. Mas sim... já não és inútil."

    # say L2060 bil
    old "Don’t get used to it."
    new "B:pla: Haha, isso é a coisa mais bonita que já me disseste."

    # say L2061 pla
    old "So... what now?"
    new "B:bil: Não te habitues a isso."

    # say L2062 bil
    old "Now we keep practicing. You, with the guitar. Me, with the teacher."
    new "E juntos... Fazemos com que isto funcione de verdade."

    # say L2063 bil
    old "And together... We make this thing actually work."
    new "B:bil: Agora continuamos a praticar. Tu, com a guitarra. Eu, com o professor."

    # say L2064 pla
    old "Deal."
    new "T(pla|tu|say): Feito."

    # say L2067 bil
    old "Alright, it’s getting late. Go home before you turn into a pumpkin."
    new "B:pla: Trato feito."

    # say L2068 pla
    old "Yeah, I should. But... thanks again. For everything."
    new "B:bil: Está bem, está a ficar tarde. Vai para casa antes de te transformares numa abóbora."

    # say L2069 bil
    old "Yeah, yeah. Just don’t waste what we started."
    new "B:pla: Sim, devo. Mas... obrigado mais uma vez. Por tudo."

    # say L2070 pla
    old "I won’t. I promise."
    new "B:bil: Sim, sim. Só não desperdices o que começámos."

    # say L2072 pla
    old "See you soon."
    new "Finalmente. Tu estás aqui."

    # say L2092 bil
    old "Finally. You're here."
    new "B:pla: Até breve."

    # say L2093 pla
    old "Yeah, your text said it was urgent. What's up?"
    new "B:bil: Finalmente. Tu estás aqui."

    # say L2094 bil
    old "Well, I've been in lessons with the teacher. It's going okay, but I need your help with something."
    new "B:pla: Sim, a tua mensagem dizia que era urgente. O que se passa?"

    # say L2095 pla
    old "Do you need my help?"
    new "B:bil: Bem, tenho estado em aulas com o professor. Está a correr bem, mas preciso da tua ajuda com algo."

    # say L2096 bil
    old "Better talk in my room. Come on."
    new "T(bil|tu|say): Melhor falarmos no meu quarto. Vem."

    # say L2103 bil
    old "Alright, so, those vocal sessions with Bey were way tougher than I expected."
    new "T(bil|tu|say): Tudo bem, então, essas sessões vocais com Bey foram muito mais difíceis do que eu esperava."

    # say L2104 pla
    old "'Tougher' for you? Seriously?"
    new "T(pla|tu|say): 'Mais difíceis' para ti? A sério?"

    # say L2105 bil
    old "Yeah, I mean, I have the talent, sure. But I haven't practiced consistently in years."
    new "B:pla: 'Mais difícil' para ti? A sério?"

    # say L2106 bil
    old "I lost some edge on breath control, especially under pressure."
    new "B:bil: É, quero dizer, tenho o talento, claro. Mas não tenho praticado consistentemente há anos."

    # say L2107 bil
    old "Like, when nerves hit or heart rate spikes, my voice shakes. So, I can't sustain some notes without cracking."
    new "T(bil|tu|say): Tipo, quando os nervos atacam ou a frequência cardíaca dispara, a minha voz treme. Por isso, não consigo manter algumas notas sem falhar."

    # say L2108 pla
    old "That sounds rough. What does the teacher say?"
    new "T: Isso soa difícil. O que diz a professora?"

    # say L2109 bil
    old "She's got me on diaphragmatic breathing deep belly breaths to stabilize. And box breathing: inhale four, hold four, exhale four, hold four."
    new "T(bil|tu|dizer): Ela está a fazer-me fazer respiração diafragmática, respirações profundas no ventre, para estabilizar. E respiração em caixa: inspirar quatro, segurar quatro, expirar quatro, segurar quatro."

    # say L2110 bil
    old "Helps calm the nervous system, reduces anxiety. But it's not enough for real stage stress."
    new "T(bil|tu|diz): Ajuda a acalmar o sistema nervoso, reduzir a ansiedade. Mas não é suficiente para o stress do palco."

    # say L2111 pla
    old "Stage stress? Like performance anxiety?"
    new "T: Stress de palco? Como a ansiedade de performance?"

    # say L2112 bil
    old "Exactly. Heart pounding, shallow breaths... Voice goes to shit. Need to practice holding technique when everything's agitated."
    new "T(bil|tu|say): Exatamente. Coração a bater, respiração curta... A voz fica péssima. Preciso praticar a técnica de suporte quando tudo está agitado."

    # say L2113 pla
    old "Ohh, like exercises while running or something?"
    new "B:bil: Exatamente. Coração a bater, respiração ofegante... A voz fica uma merda. Preciso praticar a técnica de controlo quando tudo está agitado."

    # say L2114 bil
    old "Hmm, kinda. I already tried that stuff. Jogging while singing, high-heart-rate drills... even picturing the crowd without freaking out."
    new "B:pla: Ohh, como exercícios enquanto corro ou algo assim?"

    # say L2115 bil
    old "Progress is slow. With the contest coming, traditional stuff won't cut it."
    new "B:bil: Hmm, mais ou menos. Já tentei essas coisas. Correr enquanto canto, exercícios de alta frequência cardíaca... até imaginar a multidão sem entrar em pânico."

    # say L2116 pla
    old "Damn. So what's the plan?"
    new "B:bil: O progresso está lento. Com a competição a chegar, as técnicas tradicionais não vão ser suficientes."

    # say L2117 bil
    old "Well, I've been researching some non-traditional stuff. Found training under extreme stimulation to build resilience."
    new "B:pla: Merda. E qual é o plano?"

    # say L2118 pla
    old "Like... What kind?"
    new "B:bil: Bem, tenho estado a investigar algumas coisas não tradicionais. Encontrei treino sob estimulação extrema para construir resiliência."

    # say L2119 bil
    old "Ways to spike heart rate and nerves, but controlled. Make the body adapt to singing through it."
    new "B:pla: Como... Que tipo?"

    # say L2121 bil
    old "Anyway, the thing is I need you, because I wanna practice vocals under some strong stimulation. You know, to simulate the pressure."
    new "T(bil|tu|say): Ainda assim, a questão é que preciso de ti, porque quero praticar as vocalizações sob alguma forte estimulação. Sabes, para simular a pressão."

    # say L2122 pla
    old "Strong stimulation? Like... Distracting you?"
    new "A:bil: Porque é que às vezes tens de ser tão lento?"

    # say L2123 bil
    old "Why do you have to be so slow sometimes?"
    new "Porque é que tens de ser tão lento às vezes?"

    # say L2124 pla
    old "Uh?"
    new "A:bil: Ouve, preciso que o meu coração acelere e que o meu corpo fique todo tenso enquanto estou a praticar a cantar."

    # say L2125 bil
    old "Listen, I need my heart racing and my body all tense while I'm practicing singing."
    new "A:pla: Ainda não estou a perceber..."

    # say L2126 pla
    old "Still not following..."
    new "A:bil: Ahh. Preciso que me estimules... sexualmente. Enquanto eu canto."

    # say L2127 bil
    old "Ughh. I need you to stimulate me... sexually. While I sing."
    new "B:pla: Ainda não estou a perceber..."

    # say L2128 pla
    old "Ohhhh..."
    new "B:bil: Ughh. Preciso que me estimules... sexualmente. Enquanto eu canto."

    # say L2129 bil
    old "Yeah, it's not orthodox, but time's short. And hey, I've helped you with 'non-traditional' methods before."
    new "B:pla: Ohhhh..."

    # say L2130 bil
    old "You owe me a few, remember?"
    new "B:bil: Sim, não é ortodoxo, mas o tempo é curto. E olha, já te ajudei com métodos 'não tradicionais' antes."

    # say L2131 pla
    old "Well, that’s... fair, I guess."
    new "B:bil: Tu me deves umas, lembras-te?"

    # say L2132 bil
    old "But, I mean, I’m not saying you’re obligated."
    new "B:pla: Bem, isso é... justo, acho eu."

    # say L2133 bil
    old "I’m saying this could actually help me control my voice when everything inside me is going wild."
    new "T(bil|tu|say): Estou a dizer que isto poderia realmente ajudar-me a controlar a minha voz quando tudo dentro de mim está a ir ao rubro."

    # say L2134 pla
    old "And you really think this will work?"
    new "B:bil: Estou a dizer que isto poderia realmente ajudar-me a controlar a minha voz quando tudo dentro de mim está a ir ao rubro."

    # say L2135 bil
    old "Well, I’m not doing it just for fun."
    new "B:pla: E tu realmente achas que isto vai funcionar?"

    # say L2136 bil
    old "Okay, maybe a little."
    new "B:bil: Bem, não estou a fazer isto só por diversão."

    # say L2137 pla
    old "Heh. Alright, if you’re serious, then... Yeah. I’ll help."
    new "T: Heh. Tudo bem, se és a sério, então... Sim. Vou ajudar."

    # say L2139 pla
    old "You helped me when I was stuck. If this is what you need, I’m in."
    new "B: Heh. Tudo bem, se és a sério, então... Sim. Vou ajudar-te."

    # say L2141 bil
    old "If you’re going to help, we’ll treat this like real training."
    new "T(bil|tu|say): Se vais ajudar, vamos tratar isto como um treino real."

    # say L2142 pla
    old "Alright... So what exactly am I supposed to do?"
    new "Tudo bem... Então, o que exatamente tenho de fazer?"

    # say L2143 bil
    old "Ok, first, you follow my lead."
    new "Tudo bem, primeiro, tu sigues a minha liderança. Segundo, não penses demasiado nisso."

    # say L2144 bil
    old "Second, you don’t overthink it."
    new "B:bil: Ok, primeiro, tu sigues a minha liderança."

    # say L2145 bil
    old "Third, remember the goal: I have to keep singing no matter what I’m feeling."
    new "B:bil: Segundo, não penses demasiado nisso."

    # say L2146 pla
    old "Got it. You sing, I... create the distraction."
    new "T: Entendido. Tu cantas, eu... crio a distração."

    # say L2147 bil
    old "Yeah. If we do this right, my voice should stays steady even when everything else is falling apart."
    new "B:pla: Entendido. Tu cantas, eu... crio a distração."

    # say L2148 pla
    old "Alright, I'm in. Just tell me exactly what you need, and I'll handle it."
    new "Tudo bem, estou dentro. Só me diz exactamente o que precisas, e eu trato disso."

    # say L2149 bil
    old "Ok, first let me get ready..."
    new "B:pla: Tudo bem, estou dentro. Só me diz exactamente o que precisas, e eu trato disso. T(bil|tu|say): Ok, primeiro deixa-me preparar-me... A:bil: Gostas do que vês? Heh?"

    # say L2153 bil
    old "Do you like what you see? Heh?"
    new "B:bil: Ok, first let me get ready..."

    # say L2158 bil
    old "What about now?"
    new "B:bil: Gostas do que vês? Heh?"

    # say L2159 pla
    old "Holy... fuck..."
    new "Não há razão para nós dois não beneficiarmos desta 'prática', certo?"

    # say L2160 bil
    old "No reason we both can't benefit from this 'practice', right?"
    new "B:pla: Merda..."

    # say L2161 bil
    old "Heh. Still takes your breath away every time, huh?"
    new "B:bil: Não há razão para que ambos não possamos beneficiar desta 'prática', certo?"

    # say L2162 bil
    old "Perfect. Means you're properly motivated."
    new "B:bil: Heh. Ainda te tira o fôlego cada vez, não é?"

    # say L2163 bil
    old "Now that you're all fired up... let me get comfortable."
    new "A:bil: Agora deita-te no chão antes de desmaiares a olhar."

    # say L2164 bil
    old "Now lie down on the floor before you pass out staring."
    new "B:bil: Agora que estás toda animada... deixa-me ficar confortável."

    # say L2165 pla
    old "Uhh, a- alright..."
    new "B:bil: Agora deita-te no chão antes de desmares a olhar."

    # say L2169 bil
    old "Perfect."
    new "Perfeito. A tua tarefa: estimular-me o mais forte possível. A minha: manter a respiração controlada, sustentar as notas, manter o tom, não importa o que aconteça."

    # say L2173 bil
    old "Your job: stimulate me as hard as you can. Mine: keep breath controlled, sustain notes, hold pitch no matter what."
    new "B:bil: Perfeito."

    # say L2174 pla
    old "Got it. Let's do this."
    new "T(tu): Entendido. Vamos lá."

    # say L2186 bil
    old "Phew... that was intense."
    new "Ufa... isso foi intenso."

    # say L2187 pla
    old "Yeah... did it actually work?"
    new "B:bil: Ufa... isso foi intenso."

    # say L2188 bil
    old "Big time. I could feel the control improving even as everything else was going crazy."
    new "B:pla: Sim... funcionou mesmo?"

    # say L2189 bil
    old "Voice held up better than I expected... but yeah, I'm definitely gonna need more of this."
    new "T(bil|tu|say): A voz aguentou melhor do que eu esperava... mas sim, definitivamente vou precisar de mais disto."

    # say L2190 bil
    old "A lot more practice before the stage doesn't wreck me."
    new "B:bil: A voz aguentou melhor do que eu esperava... mas sim, vou precisar de mais disto."

    # say L2191 pla
    old "Uhh, if you need it, I'm down to keep helping. Same way you've been helping me."
    new "B:bil: Preciso de muito mais treino antes do palco me destruir."

    # say L2192 pla
    old "You know... with the 'advanced practice' and all."
    new "B:pla: Uhh, se precisas, estou disposto a continuar a ajudar. Da mesma forma que tu me tens ajudado."

    # say L2193 bil
    old "Oh, I get it."
    new "B:pla: Sabes... com a 'prática avançada' e tudo."

    # say L2194 bil
    old "Heh. Tit for tat, huh? Fair enough."
    new "B:bil: Ah, percebi."

    # say L2195 bil
    old "Deal. You keep me steady under pressure... I'll keep those fingers of yours 'motivated'."
    new "B:bil: Heh. Olho por olho, hã? Justo."

    # say L2196 bil
    old "We're both getting better this way. Win-win."
    new "B:bil: Negócio feito. Tu manténs-me calmo sob pressão... eu mantenho esses dedos teus 'motivados'."

    # say L2197 pla
    old "Exactly. Looking forward to it."
    new "B:bil: Estamos ambos a melhorar assim. Ganha-ganha."

    # say L2198 bil
    old "Alright, perv. Now seriously, get out before grandma shows up and smells the trouble."
    new "B:pla: Exactamente. Estou ansioso por isso."

    # say L2199 pla
    old "On my way. See you soon... for more 'practice'."
    new "B:bil: Anda, pervertido. Agora a sério, sai daqui antes que a avó apareça e sinta o cheiro da confusão."

    # say L2200 bil
    old "You better. Don't slack on that guitar either."
    new "B:pla: A caminho. Vejo-te já... para mais 'prática'."

    # say L2201 pla
    old "Wouldn't dream of it."
    new "A:bil: Uau, estás a horas. Isso é novo."

    # say L2220 bil
    old "Wow, you’re on time. That’s new."
    new "T(bil|tu|say): Uau, estás a horas. Isso é novo."

    # say L2221 pla
    old "Yeah... I made sure to wake up early today. Been doing extra practice every day. Feeling ready for whatever comes today."
    new "B:bil: Wow, tu estás a horas. Isso é novo."

    # say L2222 bil
    old "Wow. Actual growth. Who would’ve thought?"
    new "Então? Sem ataque de pânico hoje?"

    # say L2223 bil
    old "So? No panic attack today?"
    new "B:bil: Uau. Crescimento real. Quem diria?"

    # say L2224 pla
    old "A little butterflies, sure... but I'm fine. We've got this."
    new "B:bil: Então? Sem ataque de pânico hoje?"

    # say L2225 bil
    old "Look at you. All grown up."
    new "B:pla: Umas borboletas, claro... mas estou bem. Vamos conseguir."

    # say L2226 pla
    old "Yeah. I trust what we’ve practiced."
    new "B:bil: Olha para ti. Todo crescido."

    # say L2227 bil
    old "Good. Because today is just about showing what we can already do."
    new "B:pla: Claro. Confio no que já praticámos."

    # say L2228 bil
    old "No panic, no drama."
    new "B:bil: Ótimo. Porque hoje é só sobre mostrar o que já conseguimos fazer."

    # say L2229 pla
    old "I'll try to keep the drama to a minimum."
    new "B:bil: Não te preocupes, não há drama."

    # say L2230 bil
    old "Do that and I might even be proud of you."
    new "B:pla: Vou tentar manter o drama ao mínimo."

    # say L2231 pla
    old "High honor."
    new "B:bil: Faz isso e eu até posso ficar orgulhoso de ti."

    # say L2242 sha
    old "Darlings! Look who we found!"
    new "B:pla: Alta honra."

    # say L2243 rya
    old "We just finished our private session with Bey. Absolute perfection!"
    new "B:sha: Queridas! Olhem quem encontrámos!"

    # say L2244 sha
    old "The choreography, the lighting cues, the costume changes... we have a full Broadway production ready, honey!"
    new "B:rya: Acabámos de ter a nossa sessão privada com Bey. Perfeição absoluta!"

    # say L2245 rya
    old "Everything planned down to the last sparkle. The crowd is going to lose their minds!"
    new "B:sha: A coreografia, as indicações de iluminação, as trocas de figurino... temos uma produção de Broadway completa pronta, querida!"

    # say L2247 bil
    old "Great for you."
    new "B:rya: Tudo planeado até ao último brilho. A multidão vai perder a cabeça!"

    # say L2248 sha
    old "Oh, look at their little faces. So serious. So... scared."
    new "B:bil: Ótimo para ti."

    # say L2249 rya
    old "It’s adorable, really. Like two lost puppies trying to play with the big dogs."
    new "B:sha: Olha para as suas carinhas. Tão sérias. Tão... assustadas."

    # say L2250 sha
    old "You two still look like you’re auditioning for your very first school play."
    new "B:rya: É adorável, realmente. Como dois filhotes perdidos a tentar brincar com os cães grandes."

    # say L2251 rya
    old "While we just delivered a show stopping number that will make people stand up and cheer."
    new "B:sha: Vocês dois ainda parecem estar a fazer audição para a vossa primeira peça de teatro da escola."

    # say L2252 bil
    old "Keep talking, Sparkle Twins."
    new "B:rya: Enquanto isso, acabamos de entregar um número que vai fazer as pessoas levantarem e aplaudir."

    # say L2253 sha
    old "Cute. Very cute. The underdogs always have that fighting spirit."
    new "B:bil: Continuem a falar, Sparkle Twins."

    # say L2254 rya
    old "Good luck in there, sweethearts. Try not to faint from all the pressure."
    new "B:sha: Fofo. Muito fofo. Os azarados sempre têm esse espírito de luta."

    # say L2255 sha
    old "Ta-ta, lovebirds! The stage belongs to the stars... not the scared little duo."
    new "B:rya: Boa sorte aí, queridos. Tentem não desmaiar com toda a pressão."

    # say L2263 bil
    old "Ughh... I hate those two so much."
    new "B:sha: Ta-ta, pombinhos! O palco pertence às estrelas... não a este medroso duo."

    # say L2264 pla
    old "They really know how to get under your skin..."
    new "B:bil: Ughh... Eu odeio aqueles dois tanto."

    # say L2265 bil
    old "Good. Let’s use that anger. Time to show Bey what we can really do."
    new "B:pla: Eles realmente sabem como te irritar..."

    # say L2274 bey
    old "There you are already! Early today, I wasn’t expecting you two so soon."
    new "T(bey|tu|say): Lá estás tu! Cedo hoje, não estava à espera de vocês tão cedo."

    # say L2275 bil
    old "This time we didn't wanna show up late like last session."
    new "B:bey: Lá estás tu! Cedo hoje, não estava à espera de vocês tão cedo."

    # say L2276 pla
    old "Yeah, sorry if we’re a little early this time."
    new "B:bil: Desta vez não queríamos chegar atrasados como na sessão passada."

    # say L2277 bey
    old "That’s a good problem to have. Gives us extra time to really dig in."
    new "B:pla: Sim, desculpa se estamos um pouco mais cedo desta vez."

    # say L2278 bey
    old "So, this is our last tutoring session before the contest."
    new "T(bey|tu|say): Então, esta é a nossa última sessão de aulas antes da competição. Como vocês estão se sentindo?"

    # say L2279 bey
    old "How are you both feeling?"
    new "Prontos."

    # say L2280 bil
    old "Ready."
    new "B:bey: Como é que vocês estão a sentir-se?"

    # say L2281 pla
    old "Nervous... but ready."
    new "T(pla|tu|say): Nervoso... mas pronto."

    # say L2282 bey
    old "That’s exactly how you should feel."
    new "T(bey|tu|say): É exactamente assim que deves sentir-te."

    # say L2283 bey
    old "Alright, let’s do this like before."
    new "B:bey: É exactamente assim que deves sentir-te."

    # say L2284 bey
    old "Perform as if you were already on stage at the contest."
    new "T(bey|tu|say): Performa como se já estivesses em palco no concurso."

    # say L2286 pla
    old "Alright... let’s go."
    new "Tudo bem... vamos lá."

    # say L2319 bey
    old "Wow."
    new "A:bil: É um ‘wow’ bom ou...?"

    # say L2320 bil
    old "Is that a good ‘wow’ or...?"
    new "T(bil|tu|say): É um ‘wow’ bom ou...?"

    # say L2321 bey
    old "Oh honey, it’s a ‘hell yes’ wow!"
    new "B:bil: É um bom ‘uau’ ou...?"

    # say L2322 bey
    old "This is night and day from your audition. Completely different level."
    new "B:bey: Oh meu amor, é um ‘sim com certeza’ uau!"

    # say L2323 bey
    old "[pla], look at you!"
    new "T(bey|tu|say): [pla], olha para ti!"

    # say L2325 bey
    old "From that quiet little tree in the audition to actually carrying the whole song with her!"
    new "T(bey|tu|say): Daquela árvore calma e pequena no teste de audição até carregares toda a canção com ela!"

    # say L2326 bey
    old "Your chords are locking in perfectly now, your rhythm is steady, and you’re breathing with Billie like you were born to do this."
    new "B:bey: Daquela árvore calma e pequena no teste de audição até carregar toda a canção com ela!"

    # say L2327 bey
    old "You’re not just following anymore... you’re complementing her. You’re making her voice shine even brighter."
    new "T(bey|tu|say): Tu não estás só a seguir... tu estás a complementar a voz dela. Estás a fazer brilhar ainda mais a voz dela."

    # say L2328 pla
    old "For real? That actually worked?"
    new "T(pla|tu|say): A sério? Isso realmente funcionou?"

    # say L2329 bey
    old "Yes! You two are finally sounding like a real duo."
    new "B:pla: A sério? Isso realmente funcionou?"

    # say L2330 bey
    old "And Billie... that breath control? Chef’s kiss."
    new "B:bey: Sim! Vocês finalmente soam como um duo de verdade."

    # say L2332 bey
    old "Absolutely. Way more power behind those soft notes. You’re letting that voice breathe."
    new "T(bey|tu|say): Absolutamente. Muito mais poder por trás dessas notas suaves. Estás a deixar que a tua voz respire."

    # say L2333 bey
    old "Your breath support is stronger, and you’re keeping your tone stable even in longer phrases."
    new "T(bey|tu|say): A tua respiração está mais forte, e estás a manter o tom estável mesmo em frases mais longas."

    # say L2334 bey
    old "You’re managing your diaphragm much more consciously now."
    new "T(bey|tu|diz): Estás a gerir o teu diafragma muito mais conscientemente agora."

    # say L2335 bil
    old "That’s... really good to hear."
    new "T(bil|tu|say): É... realmente bom ouvir isso."

    # say L2336 bey
    old "You both sound like a team now."
    new "T(bey|tu|say): Vocês soam como uma equipa agora."

    # say L2337 bey
    old "Not just two people doing their own thing, but one performance."
    new "B:bey: Vocês parecem uma equipa agora."

    # say L2338 bil
    old "That’s what we were aiming for."
    new "B:bey: Não apenas duas pessoas fazendo o seu próprio jogo, mas uma única performance."

    # say L2340 bey
    old "Well, I think you’re ready for the contest."
    new "B:bil: É isso que estávamos a procurar."

    # say L2341 bil
    old "You mean... really ready?"
    new "B:bey: Bem, acho que estás pronto para a competição."

    # say L2342 bey
    old "Yes. You should keep practicing, of course."
    new "B:bil: Tu queres dizer... realmente pronta?"

    # say L2343 bey
    old "But now it’s about polishing, not fixing big problems."
    new "B:bey: Sim. Deves continuar a praticar, claro."

    # say L2344 bey
    old "Also... don’t forget to rest."
    new "T(bey|tu|say): E... não te esqueças de descansar."

    # say L2345 bey
    old "Overworking right before a performance can be just as bad as not practicing."
    new "B:bey: E... não te esqueças de descansar."

    # say L2347 pla
    old "We’ll be careful."
    new "E mais uma coisa."

    # say L2348 bey
    old "And one more thing."
    new "E mais uma coisa. Começa a pensar no teu visual de palco."

    # say L2349 bey
    old "Start thinking about your stage look."
    new "T(bey|tu|say): Começa a pensar no teu visual de palco."

    # say L2350 bil
    old "O- Our look?"
    new "T(bil|tu|say): O- O nosso look?"

    # say L2351 bey
    old "Clothes, style, how you present yourselves."
    new "B:bil: O- O nosso visual?"

    # say L2352 bey
    old "Your music has a mood. Your image should match it."
    new "T(bey|tu|say): A tua música tem um mood. A tua imagem deve combiná-lo."

    # say L2353 pla
    old "Oh, That actually sounds fun."
    new "T: Oh, isso até parece divertido."

    # say L2355 bey
    old "I’ll be cheering for you both."
    new "B:pla: Oh, isso até parece divertido."

    # say L2356 bil
    old "Thank you. For everything."
    new "B:bey: Vou torcer por vocês."

    # say L2357 pla
    old "Yeah, thank you."
    new "T: Sim, obrigado."

    # say L2379 bil
    old "Well... that timing was just perfect."
    new "B:pla: Sim, obrigado."

    # say L2380 pla
    old "Yeah, that rain came out of nowhere."
    new "B:bil: Bem... esse timing foi perfeito."

    # say L2381 bil
    old "Tell me about it."
    new "B:pla: Sim, essa chuva veio do nada."

    # say L2382 bil
    old "Anyway, go dry off in the bathroom, towel's there."
    new "T(bil|tu|say): De qualquer forma, vai secar-te no banheiro, a toalha está lá."

    # say L2383 bil
    old "I'm heading to my bedroom to change."
    new "B:bil: Então, vai secar-te na casa de banho, a toalha está lá."

    # say L2385 bil
    old "Try not to flood the place."
    new "B:bil: Vou para o meu quarto mudar de roupa."

    # say L2386 pla
    old "No promises."
    new "B:bil: Tenta não inundar o lugar."

    # say L2396 pla
    old "Hey [bil], sorry, I kinda flooded the bathroom floor while drying off-"
    new "Olá [bil], desculpa, acabei por inundar o chão da casa de banho enquanto me secava..."

    # say L2399 bil
    old "Hey, eyes up here, perv."
    new "Hei, olhos aqui em cima, pervertido."

    # say L2402 bil
    old "Heh, what? Rain made them look that good?"
    new "B:bil: Ei, olhos aqui em cima, pervertido."

    # say L2403 pla
    old "Uhhh, well, I- I can literally see your nipples through the shirt..."
    new "B:bil: Heh, o quê? A chuva fez com que ficassem assim tão boas?"

    # say L2404 bil
    old "Haha, you’re practically drooling already... you're such a mess"
    new "T(bil|tu|say): Haha, tu estás praticamente a babar já... és uma desgraça."

    # say L2406 bil
    old "Heh, wanna get a better view?"
    new "B: Haha, tu estás praticamente a babar já... és uma desastre."

    # say L2407 pla
    old "I— I- I- Uhhh... y- yea-"
    new "B:bil: Heh, queres uma vista melhor?"

    # say L2412 bil
    old "There. Way better without anything in the way, right?"
    new "B:pla: I— I- I- Uhhh... y- yea-"

    # say L2416 bil
    old "Someone got rock hard just from staring at my tits."
    new "B:bil: Heh, oh my gosh... olha para ti."

    # say L2417 pla
    old "S- Sorry, I can't help it..."
    new "T: S- Desculpa, não consigo evitar..."

    # say L2420 bil
    old "Obviously. I love how easily I can turn a perv like you into a complete mess."
    new "T(bil|tu|say): Obviamente. Adoro como consigo transformar um pervertido como tu num completo desastre."

    # say L2427 bil
    old "You know... good boys who practice as hard as you do deserve something special."
    new "T(bil|tu|say): Sabes... os bons rapazes que se esforçam tanto como tu merecem algo especial."

    # say L2434 bil
    old "And you’ve been such a good boy lately..."
    new "B:bil: Sabes... os bons rapazes que se esforçam tanto como tu merecem algo especial."

    # say L2435 pla
    old "Uhh..."
    new "B:bil: E tens sido um bom rapaz ultimamente..."

    # say L2441 bil
    old "Yeah, so I think you’ve earned yourself a little prize."
    new "B:pla: Uhh..."

    # say L2448 bil
    old "Mmm... feel that? Every single inch sliding in..."
    new "B:bil: Sim, acho que mereces um prémio."

    # say L2449 pla
    old "God... you’re so fucking tight..."
    new "B:bil: Mmm... sentes isso? Cada centímetro a deslizar..."

    # say L2450 bil
    old "Slow... nice and deep. Let me take control."
    new "B:pla: Merda... tu és tão apertada..."

    # say L2459 pla
    old "({i}That was... intense. Too intense.{/i})"
    new "T: ({i}Isso foi... intenso. Demasiado intenso.{/i})"

    # say L2461 pla
    old "I... yeah. I’m good. Just... damn."
    new "T: Eu... sim. Estou bem. Apenas... merda."

    # say L2462 bil
    old "Heh. 'Damn' is right. We both really needed that, didn’t we?"
    new "B:pla: Eu... sim. Estou bem. Apenas... merda."

    # say L2463 pla
    old "Yeah... I think we did."
    new "T: Sim... Acho que precisávamos disso."

    # say L2465 pla
    old "But... it felt different this time..."
    new "B:pla: Sim... Acho que sim."

    # say L2467 pla
    old "I mean, when we were looking at each other... I could see it in your eyes. You were feeling it too."
    new "B:pla: Mas... desta vez foi diferente..."

    # say L2468 bil
    old "Uhh.. D- Don’t get all sappy on me now..."
    new "T(bil|tu|say): Uhh.. N- Não fiques todo meloso comigo agora..."

    # say L2470 bil
    old "Listen, it was just blowing off steam, okay? Don't start reading too much into it."
    new "B:bil: Uhh.. D- Não fiques todo meloso agora..."

    # say L2471 pla
    old "I guess, you're right, still... it felt really good."
    new "B:bil: Ouve, foi só desabafar, ok? Não leias muito nisso."

    # say L2472 bil
    old "Heh. Yeah... you weren’t half bad yourself."
    new "B:pla: Acho que tens razão, ainda assim... senti-me realmente bem."

    # say L2473 bil
    old "Doesn’t mean I’m going soft on you though."
    new "B:bil: Heh. Sim... tu também não foste mal."

    # say L2474 bil
    old "The contest is in a few days. We can’t afford to get distracted."
    new "B:bil: Não quer dizer que eu esteja a ficar mais mole contigo."

    # say L2475 pla
    old "Right... back to serious practice."
    new "B:bil: A competição é daqui a poucos dias. Não podemos nos distrair."

    # say L2476 bil
    old "Exactly. Guitar for you, vocals for me. No slacking."
    new "T(bil|tu|say): Exatamente. Guitarra para ti, voz para mim. Sem preguiça."

    # say L2479 bil
    old "But... if you need a little extra 'motivation' again... I guess I can make time."
    new "B:bil: Exatamente. Guitarra para ti, voz para mim. Sem preguiça."

    # say L2480 pla
    old "I’ll take that."
    new "B:bil: Mas... se precisares de um pouco de 'motivação' extra outra vez... acho que posso arranjar tempo."

    # say L2481 bil
    old "Don’t get cocky. Next time I might make you work even harder for it."
    new "B:pla: Eu aceito."

    # say L2482 pla
    old "Bring it."
    new "B:bil: Não te vanglories. Da próxima vez posso fazer-te trabalhar ainda mais por isso."

    # say L2484 bil
    old "Now seriously, we need to clean up before my grandma walks in and smells sex and rain in my room."
    new "T(bil|tu|say): Agora a sério, precisamos de arrumar antes que a minha avó entre e sinta o cheiro de sexo e chuva no meu quarto."

    # say L2489 pla
    old "I will. Promise."
    new "T(pla|tu|say): Vou. Prometo."

    # say L2509 pla
    old "Yeah, you said you needed me for something. But... we've been practicing a lot lately, right?"
    new "T(pla|tu|say): Sim, disseste que precisavas de mim para algo. Mas... temos estado a treinar muito, certo?"

    # say L2510 bil
    old "Heh, yeah. But no, I don't need you for that today."
    new "A:pla: Espera, a sério? Não é para treinar?"

    # say L2511 pla
    old "Wait, seriously? Not practice?"
    new "B:bil: Heh, yeah. Mas não, não preciso de ti para isso hoje."

    # say L2512 bil
    old "Nope. Today I need you for something else."
    new "B:pla: Espera, a sério? Não vamos treinar?"

    # say L2514 bil
    old "I want to go buy some clothes. For the contest."
    new "B:bil: Não. Hoje preciso de ti para outra coisa."

    # say L2515 pla
    old "Clothes? Like... an outfit?"
    new "B:bil: Quero ir comprar roupa. Para o concurso."

    # say L2516 bil
    old "Exactly. I don't want to show up in my usual stuff."
    new "Exatamente. Não quero aparecer com a minha roupa habitual. Esses outros idiotas provavelmente vão estar todos com glitter e lantejoulas. Não quero parecer que nem tentei."

    # say L2517 bil
    old "Those other idiots are probably gonna be all glitter and sequins. I don't wanna look like I didn't even try."
    new "B:bil: Exactamente. Não quero aparecer com a minha roupa habitual."

    # say L2518 pla
    old "Okay, that makes sense. Let's go then. I'll help you pick."
    new "B:bil: Esses outros idiotas provavelmente vão estar todos com purpurina e lantejoulas. Não quero parecer que nem tentei."

    # say L2519 bil
    old "Good. I already have a few ideas. Come on."
    new "B:pla: Okay, isso faz sentido. Vamos então. Vou ajudar-te a escolher."

    # say L2525 bil
    old "Alright, there's this store I saw online. Not really my usual vibe, but they might have something that works for the stage."
    new "B:bil: Ótimo. Já tenho algumas ideias. Vamos."

    # say L2526 pla
    old "What exactly are you thinking?"
    new "B:bil: Olha, vi uma loja online. Não é bem o meu estilo, mas pode ter algo que funcione para o palco."

    # say L2527 bil
    old "Honestly? I don't know yet. I wanna look around, try a bunch of stuff, and see what feels right. Let's just go in."
    new "T(bil|tu|say): Honestemente? Ainda não sei. Quero dar uma volta, experimentar umas coisas e ver o que me parece bem. Vamos lá entrar."

    # say L2544 bil
    old "Hi. I'm performing in a music contest in a few days and I need an outfit that fits the stage."
    new "Olá?"

    # say L2546 bil
    old "Hello?"
    new "B:bil: Olá. Vou atuar num concurso de música daqui a uns dias e preciso de um fato que se adeque ao palco."

    # say L2547 lan
    old "Huh? Oh. Yeah, everything's for sale. Just browse and bring whatever you want to the counter when you're ready."
    new "B:bil: Olá?"

    # say L2556 bil
    old "Hmm, whatever. Let's just look around."
    new "T(bil|tu|say): Hmm, seja o que for. Vamos só dar uma volta."

    # say L2557 pla
    old "Yeah. What are you searching for exactly?"
    new "B:bil: Hmm, whatever. Vamos só dar uma vista de olhos."

    # say L2558 bil
    old "I'm not totally sure yet. I'll grab a few things, try them on, and you tell me what you think. Deal?"
    new "T(bil|tu|say): Ainda não tenho a certeza. Vou pegar em algumas coisas, experimentá-las e tu dizes o que achas. Fechado?"

    # say L2559 pla
    old "Deal. I'll be honest."
    new "B:bil: Ainda não tenho a certeza. Vou pegar em algumas coisas, experimentá-las e tu dizes o que achas. Fechado?"

    # say L2560 bil
    old "You better be."
    new "A:pla: Pronto?"

    # say L2566 pla
    old "Ready?"
    new "T(tu|pla|say): Pronto?"

    # say L2568 bil
    old "Yeah. I grabbed a few options... even some wigs. Didn't expect that here."
    new "A:pla: Perucas? Para o concurso?"

    # say L2569 pla
    old "Wigs? For the contest?"
    new "B:bil: Sim. Peguei algumas opções... até algumas perucas. Não esperava isso aqui."

    # say L2570 bil
    old "I'm trying to switch up my whole look a bit. Not going full Sparkle Queen like the others, but... something different."
    new "T(bil|tu|say): Estou a tentar mudar um bocadinho o meu visual. Não vou ser uma Sparkle Queen como as outras, mas... algo diferente."

    # say L2579 bil
    old "Okay, first one coming out."
    new "T(bil|tu|say): Ok, o primeiro a sair."

    # say L2587 bil
    old "Okay... I was thinking something like what those empty headed girls would wear. Bright, short, cute. What do you think?"
    new "B:bil: Okay, a primeira a sair."

    # say L2588 pla
    old "({i}Holy shit... she actually looks amazing in this. I wasn't expecting the pink to suit her this well.{/i})"
    new "T(pla|tu|say): ({i}Merda... ela fica mesmo incrível assim. Não estava à espera que o rosa lhe ficasse tão bem.{/i})"

    # say L2595 pla
    old "Uhh... Y- you look really good actually. The color pops and the skirt is beautiful... wait, and that hair? It's completely black now."
    new "T(tu): Uh... Tu... Tu estás realmente muito bem. A cor destaca-se e a saia é linda... espera, e esse cabelo? Agora está completamente preto."

    # say L2605 bil
    old "It's a wig, obviously."
    new "B:pla: Uhh... Tu... Tu estás realmente muito bem. A cor destaca-te e a saia é linda... espera, e esse cabelo? Agora está completamente preto."

    # say L2606 bil
    old "My green hair would clash horribly with this pink. It'd look ridiculous, so I grabbed a black one to match the outfit."
    new "B:bil: É uma peruca, obviamente."

    # say L2607 bil
    old "Uhh... So? What do you think overall? Do you like it?"
    new "B:bil: O meu cabelo verde ficaria horrivelmente mal com este rosa. Ficaria ridículo, por isso peguei num preto para combinar com o outfit."

    # say L2608 pla
    old "Totally. It screams 'stage presence'."
    new "B:bil: Uhh... Então? O que achas no geral? Gostas?"

    # say L2609 bil
    old "But... it's so pink. So girly. So... not me. Ugh, too cutesy. Nope."
    new "B:pla: Totalmente. É o que se chama 'presença de palco'."

    # say L2624 bil
    old "Ok, now this one... more elegant, kinda bohemian, long flowy thing. Thoughts?"
    new "B:bil: Tanto faz. O próximo."

    # say L2625 pla
    old "({i}Wow... she looks absolutely stunning. The long dress and blonde hair completely transform her vibe.{/i})"
    new "T(pla|tu|say): ({i}Uau... tu estás absolutamente deslumbrante. O vestido longo e o cabelo loiro transformam completamente o teu estilo.{/i})"

    # say L2643 bil
    old "It doesn't look much like a wig, right? I picked one that blended in pretty well."
    new "B:pla: Uhh... Merda, Billie... tu pareces uma verdadeira vibes. Sofisticada, misteriosa... e esse cabelo loiro? Fica-te incrível."

    # say L2644 pla
    old "Well, it looks a bit odd to me, but I think it's just because I know you."
    new "B:bil: Não parece muito uma peruca, certo? Escolhi uma que se misturasse bem."

    # say L2645 pla
    old "It's like seeing a completely different person, you know?"
    new "A:bil: Uma pessoa diferente? Hum, mas achas que pode realmente resultar para o concurso?"

    # say L2646 bil
    old "A different person? Uhh, but do you think it could actually work for the contest?"
    new "B:pla: É como ver uma pessoa completamente diferente, sabes?"

    # say L2647 pla
    old "I guess so. It's classy as hell. You'd definitely stand out for sure."
    new "T(pla|tu|say): Acho que sim. É super elegante. Ias certamente destacar-te."

    # say L2648 bil
    old "Hmm, I don't know... I think it's too much. Way too much, you know?"
    new "B:pla: Acho que sim. É super elegante. Ias certamente chamar a atenção."

    # say L2649 bil
    old "I feel like I'm playing dress up as some celebrity. This isn't me at all."
    new "B:bil: Hmm, não sei... Acho que é demais. Muito demais, sabes?"

    # say L2650 bil
    old "Ughh, and no more wigs after this. They're boiling hot and I feel super fake wearing them."
    new "B:bil: Sinto-me como se estivesse a fazer de conta que sou alguma celebridade. Isto não é nada comigo."

    # say L2651 bil
    old "Alright, moving on."
    new "T(bil|tu|say): Tudo bem, vamos em frente."

    # say L2665 bil
    old "Okay, this one's bolder. Short skirt, tight top... figured it might grab attention. Be honest."
    new "B:bil: Tudo bem, vamos continuar."

    # say L2690 pla
    old "({i}Shit... no, not now! Why the hell am I getting hard right here in the middle of the store? This is so bad...{/i})"
    new "B:pla: ({i}Merda... o rabo dela está completamente exposto. Essa saia mal cobre alguma coisa...{/i})"

    # say L2692 pla
    old "I- I... Uhh... That's... This one is really nic- ass..."
    new "T(pla|tu|say): I- I... Uhh... Isso... Este é realmente... bonito..."

    # say L2695 bil
    old "Ohhh, look at that. Someone really liked what he saw."
    new "B:pla: I- I... Uhh... Isso... Este é realmente... bonito..."

    # say L2696 bil
    old "You're already rock hard just from staring at my ass. How cute."
    new "B:bil: Ohhh, olha só. Alguém realmente gostou do que viu."

    # say L2697 pla
    old "I- I can't help it... you look way too good like that."
    new "T: Não consigo... tu estás mesmo muito bem assim."

    # say L2698 bil
    old "Mmm, really? Then don't just look."
    new "B:pla: I- I não consigo evitar... tu pareces mesmo muito bem assim."

    # say L2704 bil
    old "So, you really liked this outfit, huh? Why could that be?"
    new "A:bil: Gostas de ver o teu pénis entre as minhas nádegas?"

    # say L2705 bil
    old "Do you like how your cock looks between my cheeks?"
    new "B:bil: Então, tu realmente gostaste deste fato, hã? Porquê?"

    # say L2707 bil
    old "Pull it out. I want to feel that warm big cock against my skin."
    new "B:bil: Gostas de ver o teu pénis entre as minhas nádegas?"

    # say L2708 pla
    old "W- wait! Billie! We're in a fitting room... someone could walk in any second!"
    new "B:bil: Tira-o. Quero sentir aquele pau grande e quente contra a minha pele."

    # say L2709 bil
    old "Relax, dummy. That stupid salesgirl is still glued to her phone. No one's coming this way. We're basically alone."
    new "B:pla: E-ei! Billie! Estamos num provador... alguém pode entrar a qualquer momento!"

    # say L2710 bil
    old "Now take your cock out... or should I do it for you?"
    new "B:bil: Relaxa, parvo. Essa vendedora estúpida ainda está grudada no telemóvel. Ninguém está a vir para cá. Estamos praticamente sozinhos."

    # say L2714 bil
    old "Mmm... it feels warm... and so hard."
    new "B:bil: Agora tira o teu pénis... ou devo fazer eu?"

    # say L2715 pla
    old "[bil], this is so risky..."
    new "T(tu): [bil], isto é tão arriscado..."

    # say L2730 bil
    old "It's nice you like it so much..."
    new "T(bil|tu|say): É bom que gostes tanto..."

    # say L2732 bil
    old "Besides, this feels way too slutty for the stage. Like I'm selling my ass instead of my voice. Hard pass."
    new "B:bil: É bom que gostes tanto..."

    # say L2748 bil
    old "Last one. Casual but edgy. Urban, not too flashy. What do you say?"
    new "B:bil: Seguinte."

    # say L2773 pla
    old "({i}Nooo... not again! I just came all over her ass two minutes ago... What the hell is wrong with me?!{/i})"
    new "B:pla: ({i}Merda... até neste ela parece incrível. Esses peitos nesse sutiã azul...{/i})"

    # say L2776 bil
    old "What? Just that? Wait a second..."
    new "B:pla: Uhh... yeah, this one is nice too..."

    # say L2777 bil
    old "Are you serious right now?! You just blew a huge load on my ass and you're already rock hard again? Just from seeing me squeeze my tits?"
    new "B:bil: O quê? Só isso? Espera aí..."

    # say L2778 bil
    old "Damn... these really drive you crazy, huh?"
    new "B: Estás a brincar comigo?! Acabaste de gozar todo na minha bunda e já estás duro de novo? Só porque viste eu apertar as minhas tetas?"

    # say L2780 bil
    old "Mmm, greedy boy... still got more for me? Let me milk you dry."
    new "B:bil: Merda... estes realmente te deixam louca, não é?"

    # say L2781 bil
    old "Come here. Let me take care of that with my tits."
    new "B: Mmm, menino guloso... ainda tens mais para mim? Deixa-me espremer-te até ao fim."

    # say L2796 bil
    old "Alright, this one isn't right either."
    new "B:bil: Vem aqui. Deixa-me cuidar disso com os meus peitos."

    # say L2797 pla
    old "What? W-why?"
    new "T: O quê? P-porquê?"

    # say L2798 bil
    old "Judging by the way you just got hard again... it doesn't make much difference from the last one."
    new "B:pla: O quê? P-porquê?"

    # say L2799 pla
    old "Yeah... I guess you're right."
    new "B:bil: Pelo jeito que ficaste duro de novo... não deve fazer muita diferença da última vez."

    # say L2800 bil
    old "Hmm, whatever... I'm just gonna change back."
    new "B:pla: Sim... Acho que tens razão."

    # say L2815 pla
    old "W- What? so, none of them? You didn't like any?"
    new "B:bil: Tudo bem, vamos lá."

    # say L2816 bil
    old "No. None of them feel right. All that color, glitter, fake glamour..."
    new "B:pla: E-Está a brincar? Então, nenhuma? Não gostaste de nenhuma?"

    # say L2817 bil
    old "It's not me. I don't want to pretend to be someone I'm not just to compete with those idiots."
    new "B:bil: Não. Nenhum deles me parece certo. Toda essa cor, brilho, glamour falso..."

    # say L2818 pla
    old "({i}She's got a point. That's what makes her special.{/i})"
    new "T: ({i}Ela tem razão. É isso que a torna especial.{/i})"

    # say L2820 bil
    old "For now, yeah. I'll keep thinking, but I'm not forcing something that doesn't feel like me. Thanks for coming with me though. Seriously."
    new "T(bil|tu|say): Para já, sim. Vou pensando, mas não vou forçar algo que não me sinta bem. Obrigada por teres vindo comigo, a sério."

    # say L2821 pla
    old "Anytime. I had fun watching you rock every single one, even if you hated them."
    new "B:bil: Por agora, sim. Vou continuar a pensar, mas não vou forçar algo que não me parece. Obrigado por teres vindo comigo. A sério."

    # say L2822 bil
    old "Heh. Flatterer. Come on, let's get out of here before I change my mind and buy the whole store."
    new "T(bil|tu|say): Heh. Lisonjeiro. Vamos, saiamos daqui antes que eu mude de ideia e compre toda a loja."

    # say L2842 bil
    old "You made it."
    new "B:bil: Heh. Lisonjeiro. Vamos, sai daqui antes que eu mude de ideias e compre a loja toda."

    # say L2843 pla
    old "Of course. You texted 'last practice' like it was serious."
    new "T: Claro. Tu enviaste uma mensagem a dizer \"último treino\" como se fosse a coisa mais séria do mundo."

    # say L2845 pla
    old "Uh... You okay?"
    new "T(pla|tu|say): Uh... Tudo bem?"

    # say L2846 bil
    old "Yeah, don't worry. Come in."
    new "A:bil: Amanhã é o concurso."

    # say L2852 bil
    old "Tomorrow’s the contest."
    new "B:bil: Yeah, não te preocupes. Entra."

    # say L2853 pla
    old "Yeah... kinda crazy, huh?"
    new "B:bil: Amanhã é o concurso."

    # say L2854 bil
    old "I never thought I’d stand on a stage again."
    new "T(bil|tu|say): Nunca pensei que voltaria a subir a um palco."

    # say L2855 pla
    old "'Again'?"
    new "B:bil: Nunca pensei que voltaria a subir a um palco."

    # say L2856 bil
    old "I mean... after everything."
    new "B:pla: 'De novo'?"

    # say L2857 pla
    old "But you’re here."
    new "B:bil: Quero dizer... depois de tudo."

    # say L2858 bil
    old "Yeah. And that scares me more than the stage."
    new "Porque o palco não pode sair."

    # say L2860 bil
    old "Because the stage can’t leave."
    new "B:bil: Sim. E isso assusta-me mais do que o palco."

    # say L2861 pla
    old "You don’t have to carry everything alone, you know."
    new "T(tu|diz): Não tens de carregar tudo sozinho, sabes."

    # say L2863 bil
    old "Let’s run it once. Soft. No pressure."
    new "B:pla: Não tens de carregar tudo sozinho, sabes."

    # say L2903 pla
    old "That felt different."
    new "B:bil: Vamos fazer uma vez. Suave. Sem pressão."

    # say L2904 bil
    old "It always does..."
    new "T(bil|tu|say): Tu sabes por que eu parei de cantar?"

    # say L2907 bil
    old "Do you know why I really stopped singing?"
    new "B:bil: Sempre faz isso..."

    # say L2908 pla
    old "Uhh, your grandma told me some of it."
    new "A:bil: Ela conta a versão suave."

    # say L2909 bil
    old "She tells the gentle version."
    new "B:pla: Uhh, a tua avó contou-me uma parte."

    # say L2910 pla
    old "What’s the real one?"
    new "B:bil: Ela conta a versão suave."

    # say L2911 bil
    old "When they died... everyone said 'be strong’."
    new "Quando eles morreram... todos disseram 'seja forte’."

    # say L2912 bil
    old "So I was."
    new "Quando eles morreram... todos diziam 'seja forte’."

    # say L2913 bil
    old "I stopped crying. Stopped singing. Stopped needing."
    new "T(bil|tu|say): Parei de chorar. Parei de cantar. Parei de precisar."

    # say L2914 pla
    old "That’s not strength."
    new "B:bil: Parei de chorar. Parei de cantar. Parei de precisar."

    # say L2915 bil
    old "Well, it felt like survival."
    new "B:pla: Isso não é força."

    # say L2916 bil
    old "Every song sounded like them."
    new "B:bil: Bem, pareceu sobrevivência."

    # say L2917 bil
    old "Every note felt like losing them again."
    new "T(bil|tu|say): Cada nota parecia perder-te de novo."

    # say L2918 pla
    old "So you buried it."
    new "B:bil: Cada nota era como perder-te de novo."

    # say L2919 bil
    old "Yeah. And I buried part of me with it."
    new "T(bil|tu|say): Sim. E enterrava também uma parte de mim. Mas depois apareceste. Barulhenta. Teimosa. Impossível."

    # say L2921 bil
    old "But then you showed up. Loud. Stubborn. Impossible."
    new "B:bil: Sim. E enterraste parte de ti com isso."

    # say L2922 pla
    old "I guess I have a talent for that."
    new "T(pla|tu|say): Acho que tenho jeito para isso."

    # say L2923 bil
    old "You dragged me back to something I was scared to touch."
    new "T(bil|tu|say): Tu arrastaste-me de volta a algo de que eu tinha medo de tocar."

    # say L2924 bil
    old "And now I’m scared of losing it again."
    new "T(bil|tu|say): E agora tenho medo de perder tudo de novo."

    # say L2926 pla
    old "You won’t."
    new "T(pla|tu|say): Tu não sabes isso."

    # say L2927 bil
    old "You don’t know that."
    new "T(bil|tu|say): Tu não sabes isso."

    # say L2928 pla
    old "I know I’ll be with you."
    new "T: Eu sei que vou estar contigo."

    # say L2929 bil
    old "You promise too easily."
    new "T(tu|diz): Tu prometes com muita facilidade."

    # say L2930 pla
    old "I don’t make promises I can’t keep."
    new "T: Não faço promessas que não posso cumprir."

    # say L2932 pla
    old "You won’t be."
    new "T: Não vais ficar sozinho."

    # say L2933 bil
    old "I mean... really alone."
    new "B:pla: Não vais ser."

    # say L2937 pla
    old "Then don’t be."
    new "B:bil: Quero dizer... realmente sozinho."

    # say L2938 bil
    old "You don’t run when things get heavy?"
    new "B:pla: Então não sejas."

    # say L2939 pla
    old "I would never leave you."
    new "T(tu|say): Nunca te deixaria."

    # say L2941 bil
    old "What if I break on stage?"
    new "B:pla: Nunca te deixaria."

    # say L2942 pla
    old "Then I’ll be right there, with you."
    new "A:bil: E se eu falhar?"

    # say L2943 bil
    old "What if I fail?"
    new "B:pla: Então eu estarei lá, contigo."

    # say L2944 pla
    old "Then you still tried. And that already makes you brave."
    new "T: Então tu ainda tentaste. E isso já te torna corajoso."

    # say L2945 bil
    old "I don’t want to have to hide anymore."
    new "B:pla: Então tu ainda tentaste. E isso já te torna corajoso."

    # say L2946 pla
    old "Then don’t."
    new "B:bil: Não quero ter de esconder mais."

    # say L2947 bil
    old "I don’t know how to do this..."
    new "B:pla: Então não faças."

    # say L2948 pla
    old "Don’t. Just be real."
    new "B:bil: Não sei como fazer isto..."

    # say L2950 bil
    old "If this goes wrong tomorrow..."
    new "Se isto correr mal amanhã... não vai apagar tudo o que fizemos."

    # say L2951 pla
    old "It won’t erase everything we’ve done."
    new "T: Não vais apagar tudo o que já fizemos."

    # say L2952 bil
    old "You’re not scared of me falling apart?"
    new "B:pla: Não vai apagar tudo o que fizemos."

    # say L2953 pla
    old "I’m scared of you thinking you have to."
    new "T: Não tenho medo de pensares que tens de o fazer."

    # say L2960 bil
    old "I don’t know what this is..."
    new "B:pla: Tenho medo de tu pensares que tens de o fazer."

    # say L2961 pla
    old "Neither do I. But I know it’s real."
    new "T(tu): Nem eu. Mas sei que é real."

    # say L2967 bil
    old "That... wasn’t in the plan."
    new "T(bil|tu|say): Isso... não estava nos planos."

    # say L2968 pla
    old "Neither was any of this."
    new "T: Nem isto tudo."

    # say L2969 bil
    old "I don’t want this to be a mistake."
    new "B:pla: Nem isto foi."

    # say L2970 pla
    old "Then let it be a choice."
    new "B:bil: Não quero que isto seja um erro."

    # say L2971 bil
    old "I think I want you... right now..."
    new "B:pla: Então que seja uma escolha."

    # say L2986 pla
    old "Hey... whatever happens tomorrow..."
    new "B:bil: Acho que quero-te... agora mesmo..."

    # say L2987 pla
    old "I'm really glad you decided to do this. And I’m really proud of you."
    new "B:pla: Hey... o que acontecer amanhã..."

    # say L2989 bil
    old "Don’t make me all soft right now."
    new "B:pla: Estou mesmo contente que tenhas decidido fazer isto. E estou muito orgulhoso de ti."

    # say L2990 bil
    old "But... thank you. For pushing me. For being here tonight."
    new "T(bil|tu|say): Mas... obrigado. Por me empurrar. Por estar aqui esta noite."

    # say L2991 pla
    old "I’ll be right there with you on that stage."
    new "T(pla|tu|say): Vou estar contigo no palco."

    # say L2992 bil
    old "You better not run away when I get nervous."
    new "B:pla: Vou estar contigo nesse palco."

    # say L2994 pla
    old "Goodnight, Billie."
    new "B:bil: Tu melhor não fugir quando eu fico nervosa."

    # say L2997 bil
    old "Goodnight... and [pla]?"
    new "Boa noite... e [pla]?"

    # say L2999 pla
    old "Hmm?"
    new "A:bil: Espera... Quase me esqueci de algo."

    # say L3000 bil
    old "Wait... I almost forgot something."
    new "A:bil: Dá-me um segundo. Não te moves."

    # say L3005 bil
    old "Give me a second. Don’t move."
    new "B:bil: Espera... Quase me esqueço de algo."

    # say L3012 bil
    old "Here. I have something for you."
    new "T(bil|tu|say): Aqui. Tenho algo para ti."

    # say L3015 pla
    old "A jacket?"
    new "B:bil: Aqui. Tenho algo para ti."

    # say L3017 bil
    old "It’s my dad’s old one."
    new "B:pla: Uma jaqueta?"

    # say L3018 pla
    old "Billie... I can’t take this."
    new "B:bil: É o antigo do meu pai."

    # say L3019 bil
    old "Yes, you can. And you will."
    new "B:pla: Billie... Não consigo aguentar isto."

    # say L3020 bil
    old "No one else deserves to wear it more than you."
    new "B:bil: Sim, podes. E vais."

    # say L3021 bil
    old "Besides, I can’t let you show up to the contest in that same old t-shirt and those ridiculous pink shorts again."
    new "B:bil: Ninguém merece usá-lo mais do que tu."

    # say L3022 pla
    old "Hah... fair point."
    new "B:bil: Além disso, não posso deixar-te aparecer no concurso com essa mesma t-shirt velha e essas ridículas calções cor-de-rosa outra vez."

    # say L3024 bil
    old "I’m serious. I want you to have it."
    new "T(bil|tu|say): Estou a falar a sério. Quero que tu fiques com ele."

    # say L3025 bil
    old "It feels right... you wearing it. It meant a lot to me."
    new "B:bil: Estou a falar a sério. Quero que tu fiques com ele."

    # say L3027 pla
    old "Then... thank you. I’ll take good care of it."
    new "B:bil: Sentes-te bem... tu a usá-lo. Significou muito para mim."

    # say L3032 bil
    old "Mmm, looking good, handsome."
    new "B:pla: Então... obrigado. Vou tomar conta dele."

    # say L3033 pla
    old "Heh... you really think so?"
    new "B:bil: Mmm, a parecer bem, bonito."

    # say L3034 bil
    old "Well, not as good as it looked on him... but damn, it still looks good on you."
    new "B:pla: Heh... tu realmente pensas isso?"

    # say L3036 bil
    old "Now go. Before I change my mind and drag you back to bed."
    new "B:bil: Bem, não é tão bom quanto parecia nele... mas merda, ainda fica bem em ti."

    # say L3037 pla
    old "Whoa... you really have gotten bold tonight."
    new "B:bil: Agora vai. Antes que eu mude de ideias e te arraste de volta para a cama."

    # say L3038 pla
    old "But yeah... we both need to rest. Big day tomorrow."
    new "B:pla: Uau... tu realmente ficaste mais ousado esta noite."

    # say L3039 bil
    old "Go home. Sleep. And be ready."
    new "B:pla: Mas sim... nós dois precisamos de descansar. Grande dia amanhã."

    # say L3040 pla
    old "I will. See you tomorrow... on that stage."
    new "B:bil: Vai para casa. Dorme. E estar preparado."

    # say L3041 bil
    old "See you tomorrow."
    new "B:pla: Vou. Até amanhã... nesse palco."

    # say L3062 pla
    old "The contest. Our contest."
    new "B:pla: Hoje é o dia..."

    # say L3063 pla
    old "I feel... ready. For the first time in a long time."
    new "B:pla: O concurso. O nosso concurso."

    # say L3072 pla
    old "This jacket... it feels like she’s with me already."
    new "B:pla: Sinto-me... preparado. Pela primeira vez em muito tempo."

    # say L3073 pla
    old "Alright. Let’s go win this thing."
    new "T(pla|tu|say): Tudo bem. Vamos ganhar isto."

    # say L3081 pla
    old "I’m actually early for once."
    new "T(pla|tu|say): Estou na verdade adiantado desta vez."

    # say L3082 pla
    old "Billie should be here any minute. She said she’d meet me right here."
    new "B:pla: Estou na verdade adiantado desta vez."

    # say L3083 pla
    old "We’ve practiced so much... today’s gonna be good."
    new "B:pla: A Billie deve chegar a qualquer momento. Ela disse que se encontraria comigo aqui."

    # say L3096 pla
    old "Okay... she’s still not here."
    new "B:pla: Já treinamos tanto... hoje vai ser bom."

    # say L3097 pla
    old "Where is she? The contest is gonna start soon."
    new "B:pla: Okay... ela ainda não chegou."

    # say L3098 pla
    old "She’s probably just running a little late. No big deal."
    new "A:ari: Olha quem está aqui. A árvore e a sua mini atualização de casaco."

    # say L3111 ari
    old "Look who it is. The tree and his little jacket upgrade."
    new "B:pla: Ela provavelmente está só um pouco atrasada. Não é nada de mais."

    # say L3114 pla
    old "Whatever. You two just worry about your own act."
    new "B:ari: Pois, boa sorte para não seres uma estátua outra vez."

    # say L3115 ari
    old "We’re up soon. See you losers on stage."
    new "B:pla: Tanto faz. Vocês dois preocupem-se só com o vosso número."

    # say L3126 pla
    old "They’re already heading in... the contest really is starting."
    new "A:pla: Ainda sem sinal dela..."

    # say L3138 pla
    old "Still no sign of her..."
    new "A:pla: Vamos, Billie... tu prometeste."

    # say L3139 pla
    old "Come on, Billie... you promised."
    new "B:pla: Ainda sem sinais dela..."

    # say L3140 pla
    old "Screw it. I’m gonna check if the contest already started."
    new "B:pla: Vamos, Billie... tu prometeste."

    # say L3145 pla
    old "Oh no... fuck... the contest already started!"
    new "B:pla: Screw it. Vou ver se a competição já começou."

    # say L3146 pla
    old "Fuck, fuck, fuck... Billie still hasn’t arrived."
    new "B:pla: Oh não... merda... a competição já começou!"

    # say L3147 pla
    old "Why isn’t she here? What happened?"
    new "B:pla: Merda, merda, merda... A Billie ainda não chegou."

    # say L3155 pla
    old "Should I run to her house? But what if she shows up and doesn’t see me?"
    new "B:pla: Porque é que ela não está aqui? O que aconteceu?"

    # say L3156 pla
    old "No... I have to wait here. She said she’d come. I know she’s coming."
    new "B:pla: Devo correr para a casa dela? Mas e se ela aparecer e não me ver?"

    # say L3163 pla
    old "Billie! There you are! Finally!"
    new "B:pla: Não... Tenho de esperar aqui. Ela disse que vinha. Sei que ela está a caminho."

    # say L3164 pla
    old "Oh wow! You look... beautiful. Really. That outfit... wow."
    new "B:pla: Billie! Aí estás tu! Finalmente!"

    # say L3168 bil
    old "My hands won’t stop shaking. I feel like I’m going to throw up."
    new "B:pla: Ei, ei, o que se passa? Fala comigo."

    # say L3169 bil
    old "Every time I close my eyes I hear their voices... my parents. And then I remember they’re gone."
    new "B:bil: As minhas mãos não param de tremer. Sinto-me como se fosse vomitar."

    # say L3170 bil
    old "What if I open my mouth and nothing comes out? What if I break in front of everyone?"
    new "B:bil: Toda vez que fecho os olhos ouço as suas vozes... dos meus pais. E depois lembro-me que eles já se foram."

    # say L3171 pla
    old "Breathe. Look at me."
    new "B:bil: E se abrir a boca e nada sair? E se desmoronar na frente de todos?"

    # say L3172 bil
    old "I’m not ready. I thought I was, but I’m not."
    new "B: Respire. Olha para mim."

    # say L3173 pla
    old "Come with me. We’re going somewhere quieter."
    new "B:bil: Não estou pronto. Pensei que estava, mas não estou."

    # say L3185 pla
    old "Ok, just breathe with me, okay? In... and out."
    new "B:pla: Vem comigo. Vamos para um sítio mais calmo."

    # say L3186 bil
    old "I can’t... my chest feels tight."
    new "B:pla: Ok, respira comigo, ok? Inspirar... e expirar."

    # say L3187 pla
    old "You’re safe. I’m right here."
    new "B:bil: Não consigo... sinto o peito apertado."

    # say L3188 bil
    old "It doesn’t feel safe... it feels like I’m about to lose everything again."
    new "T(bil|tu|say): Não me sinto seguro... parece que vou perder tudo de novo."

    # say L3203 bil
    old "What if I freeze on stage... what if I open my mouth and nothing comes out..."
    new "T(bil|tu|say): E se eu travar em palco... e se eu abrir a boca e nada sair..."

    # say L3204 pla
    old "Billie, look at me. You’ve practiced this a thousand times."
    new "B:bil: E se eu travar em palco... e se eu abrir a boca e nada sair..."

    # say L3205 bil
    old "Practicing is not the same as standing in front of everyone..."
    new "B: Billie, olha para mim. Já praticaste isto mil vezes."

    # say L3206 bil
    old "Every note is going to bring them back... and then they’ll disappear again..."
    new "B:bil: A prática não é a mesma coisa que estar à frente de todos..."

    # say L3212 pla
    old "Hey... hey, come here."
    new "B:bil: Cada nota vai trazer them de volta... e depois eles vão desaparecer de novo..."

    # say L3214 bil
    old "I can’t... I can’t do this..."
    new "B:pla: Ei... ei, vem cá."

    # say L3229 pla
    old "I don’t want to get your dad’s jacket dirty."
    new "B:pla: Espera! Tenho uma ideia!"

    # say L3230 bil
    old "I don’t understand..."
    new "B:pla: Não quero sujar o casaco do teu pai."

    # say L3231 pla
    old "Well, I want you to take off your dress... and your underwear."
    new "B:bil: Não percebo..."

    # say L3232 bil
    old "W- what...?"
    new "B:pla: Bem, quero que tires o vestido... e a roupa interior."

    # say L3233 pla
    old "Well, I’m using that technique you showed me once... the one that always works."
    new "B:bil: W- what...?"

    # say L3234 pla
    old "It's called 'Plan B'"
    new "B:pla: Estou a usar aquela técnica que me mostraste uma vez... a que sempre resulta."

    # say L3235 bil
    old "I- I am not sur-"
    new "B:pla: Chama-se 'Plano B'"

    # say L3236 pla
    old "You calmed me down the same way once. Let me do the same for you."
    new "B:bil: Eu... não tenho a certeza..."

    # say L3237 bil
    old "This is insane..."
    new "B:pla: Tu acalmaste-me da mesma maneira uma vez. Deixa-me fazer o mesmo por ti."

    # say L3238 pla
    old "Come on. Take off your dress... and the underwear. Now."
    new "T: Vamos. Tira o vestido... e a roupa interior. Agora."

    # say L3241 pla
    old "Sit on my face. Let me take care of you."
    new "B:pla: Não vou pedir de novo. Vai, tira tudo."

    # say L3249 bil
    old "You’re really doing this..."
    new "B:pla: Senta-te na minha cara. Deixa-me cuidar de ti."

    # say L3250 bil
    old "Mmm... your tongue..."
    new "B:bil: Tu estás mesmo a fazer isto..."

    # say L3268 bil
    old "We’re late... but I think I can do this now."
    new "B:bil: Mmm... a tua língua..."

    # say L3269 pla
    old "Then let’s go win this thing."
    new "B:bil: Estamos atrasados... mas acho que consigo fazer isto agora."

    # say L3283 pla
    old "We’re here! We’re coming!"
    new "T(pla|tu|say): Estamos aqui! Estamos a chegar!"

    # say L3285 pla
    old "Hey... look at me."
    new "B:pla: Estamos aqui! Estamos a chegar!"

    # say L3286 pla
    old "You’ve got this. You’re not alone up there."
    new "B:pla: Ei... olha para mim."

    # say L3287 pla
    old "Breathe with me, okay? In... and out."
    new "Respira comigo, okay? In... e out."

    # say L3288 bil
    old "Okay... T- thank you..."
    new "B:pla: Respira comigo, okay? Inspirar... e expirar."

    # say L3289 pla
    old "You’re the one with the voice. I’m just there to hold you steady."
    new "T: Tu és a voz. Eu estou aqui só para te manter firme."

    # say L3290 pla
    old "You ready?"
    new "B:pla: Tu és aquele com a voz. Eu estou apenas lá para te manter firme."

    # say L3291 bil
    old "No... but I’m doing it anyway."
    new "B:pla: Estás pronto?"

    # say L3292 pla
    old "That's good, let´s go!"
    new "B:bil: Não... mas estou a fazê-lo mesmo assim."

    # say L3312 pla
    old "Do it for them."
    new "B:pla: Isso é bom, vamos lá!"

    # say L3314 pla
    old "Do it for your mom... and your dad. They’d be so proud of you right now."
    new "B:pla: Faz por eles."

    # say L3316 bil
    old "They would, wouldn’t they?"
    new "B:pla: Faz por tua mãe... e por teu pai. Eles estariam tão orgulhosos de ti agora."

    # say L3317 bil
    old "Thank you... for reminding me why I’m here."
    new "B:bil: Eles fariam, não é?"

    # say L3318 bil
    old "Let’s do this."
    new "B:bil: Obrigado... por me lembrar por que estou aqui."

    # say L3319 pla
    old "Together."
    new "B:bil: Vamos fazer isto."

    # say L3339 bey
    old "Wow... what a night."
    new "B:pla: Juntos."

    # say L3340 bey
    old "First of all, thank you all for waiting so patiently... I know we made you sit through a lot today."
    new "T(bey|tu|say): Em primeiro lugar, obrigado a todos por esperarem com tanta paciência... Sabemos que tiveram de passar por muito hoje."

    # say L3341 bey
    old "Because you didn’t just perform... you gave us a show we’re never going to forget."
    new "B:bey: Em primeiro lugar, obrigado a todos por esperarem com tanta paciência... sei que passaram por muito hoje."

    # say L3342 bey
    old "Every duo showed heart, talent, and courage."
    new "B:bey: Porque não foste só tu a performar... deste-nos um espetáculo que nunca vamos esquecer."

    # say L3343 bey
    old "This wasn’t just a Music contest. This was a night full of real stories, real voices, and real passion."
    new "T(bey|tu|dizes): Isto não foi apenas um concurso de Música. Esta foi uma noite cheia de histórias reais, vozes reais e paixão verdadeira."

    # say L3344 bey
    old "The jury had an almost impossible job tonight."
    new "B:bey: Isto não foi apenas um concurso de Música. Esta foi uma noite cheia de histórias reais, vozes reais e paixão real."

    # say L3345 bey
    old "They argued, they debated, they went back and forth... because every single performance deserved to be celebrated."
    new "T(bey|tu|diz): Eles discutiram, debateram, foram e voltaram... porque cada performance merecia ser celebrada."

    # say L3346 bey
    old "But after long deliberation... they finally made their decision."
    new "Mas após longa deliberação... eles finalmente tomaram a sua decisão."

    # say L3348 bey
    old "The winners of this year’s Music Contest are..."
    new "B:bey: Mas após longa deliberação... finalmente tomaram a sua decisão."

    # say L3356 bey
    old "Come on up here, you two! You earned this."
    new "B:bey: Os vencedores do Concurso de Música deste ano são..."

    # say L3357 bey
    old "Get your prize and let everyone see the duo that stole the show tonight!"
    new "B:bey: Vêm cá para cima, vocês dois! Vocês merecem isto."

    # say L3371 pla
    old "We... we actually did it."
    new "B:bey: Vai buscar o teu prémio e deixa que todos vejam o duo que roubou a noite!"

    # say L3372 bil
    old "I... I can’t believe it."
    new "A:pla: Fizemos isso."

    # say L3373 pla
    old "We did it."
    new "B:bil: Eu... eu não acredito."

    # say L3374 bey
    old "Come on, darling... come and get your trophy."
    new "B:pla: Fizemos isso."

    # say L3377 pla
    old "Go ahead, this is your moment..."
    new "B:bey: Vamos, querida... vem buscar o teu troféu."

    # say L3393 bey
    old "Billie, honey... would you like to say a few words to the audience?"
    new "B:pla: Vai em frente, este é o teu momento..."

    # say L3395 bil
    old "I... no, I’m not good with words."
    new "B: Billie, meu amor... gostavas de dizer algumas palavras ao público?"

    # say L3396 bil
    old "I don’t think I can..."
    new "B:bil: Eu... não, não sou bom com palavras."

    # say L3397 pla
    old "Come on, Billie. Say something."
    new "B:bil: Acho que não consigo..."

    # say L3398 pla
    old "They want to hear from you. You earned this moment."
    new "Bem... só desta vez."

    # say L3401 bil
    old "Okay... just this once."
    new "Eu... Eu não pensei que cantaria de novo."

    # say L3404 bil
    old "I... I didn’t think I’d ever sing again."
    new "T(bil|tu|say): Eu... Eu não pensei que cantaria de novo."

    # say L3405 bil
    old "For years I buried this part of me because every note reminded me of my parents."
    new "B:bil: Eu... Eu não pensei que cantaria de novo."

    # say L3406 bil
    old "They taught me to sing. They taught me to love music. And when I lost them... I lost that too."
    new "Mas alguém teimoso recusou-se a deixar-me esconder para sempre."

    # say L3408 bil
    old "But someone stubborn refused to let me hide forever."
    new "Eles ensinaram-me a cantar. Eles ensinaram-me a amar a música. E quando os perdi... perdi isso também."

    # say L3410 bil
    old "He dragged me back to the stage... even when I fought him every step of the way."
    new "Vem cá, parvo."

    # say L3411 bil
    old "Come here, dummy."
    new "B:bil: Ele arrastou-me de volta ao palco... mesmo quando eu lutei contra ele a cada passo."

    # say L3420 bil
    old "So tonight... this win isn’t just mine. It’s ours."
    new "B:bil: Vem cá, parvo."

    # say L3421 bil
    old "Mom... Dad... this one’s for you."
    new "B:bil: Então esta noite... esta vitória não é só minha. É nossa."

    # say L3437 bil
    old "I still can’t believe we actually won..."
    new "B:bil: Mãe... Pai... este é para vocês."

    # say L3438 pla
    old "You were incredible up there. Everyone saw it."
    new "B:bil: Ainda não consigo acreditar que realmente ganhámos..."

    # say L3439 bil
    old "I didn’t think I’d ever stand on a stage again... and now I’m holding a trophy."
    new "B:pla: Tu foste incrível lá em cima. Todos viram."

    # say L3440 bil
    old "For a long time I told myself I was going to win just to look strong... I never really believed it."
    new "B:bil: Nunca pensei que voltasse a pisar um palco... e agora estou a segurar um troféu."

    # say L3441 pla
    old "But you did win. And it wasn’t fake. It was real."
    new "B:bil: Durante muito tempo, disse a mim mesmo que ia ganhar só para parecer forte... Nunca acreditei verdadeiramente nisso."

    # say L3442 pla
    old "Your voice came straight from your heart. The others were all flash and technique... but you? You made people feel something."
    new "B:pla: Mas tu ganhaste. E não foi falso. Foi real."

    # say L3444 pla
    old "I know so. That’s why you won. Not because of any outfit or trick... because it was you."
    new "B: pla: A tua voz veio direto do coração. Os outros eram todos aparato e técnica... mas tu? Tu fizeste as pessoas sentirem algo."

    # say L3446 bil
    old "It’s weird... I spent years running from this, and now it feels like I finally got a piece of myself back."
    new "B:pla: Eu sei. Foi por isso que tu ganhaste. Não foi por causa de nenhum outfit ou truque... foi porque foste tu."

    # say L3447 pla
    old "You did. And I’m really proud of you."
    new "B:bil: É estranho... Passei anos a fugir disto, e agora sinto que finalmente recuperei uma parte de mim."

    # say L3448 bil
    old "I couldn’t have done any of this without you."
    new "B:pla: Tu fizeste. E estou realmente orgulhoso de ti."

    # say L3449 bil
    old "You pushed me when I wanted to hide. You stayed when I tried to push you away."
    new "B:bil: Não teria conseguido fazer nada disto sem ti."

    # say L3450 pla
    old "I wasn’t going anywhere."
    new "T: Não ia a lado nenhum."

    # say L3451 bil
    old "I know... and that means more than you’ll ever understand."
    new "T(bil|tu|diz): Eu sei... e isso significa mais do que tu poderás alguma vez entender."

    # say L3452 bil
    old "Speaking of outfits... you never really said anything about this one."
    new "B:bil: Eu sei... e isso significa mais do que tu poderás alguma vez entender."

    # say L3453 bil
    old "What do you think? Be honest."
    new "T(bil|tu|say): O que achas? Sê sincero."

    # say L3454 pla
    old "You look... stunning. It’s edgy, it’s dark, it’s completely you. No one else could pull it off like that."
    new "T: Tu pareces... deslumbrante. É arrojado, é sombrio, é completamente tu. Ninguém mais conseguiria usar isso como tu."

    # say L3455 bil
    old "Heh... good answer."
    new "T(bil|tu|say): Heh... boa resposta."

    # say L3456 bil
    old "I was nervous about wearing something so different... but the way you’re looking at me right now..."
    new "T(bil|tu|say): Estava nervoso por usar algo tão diferente... mas a forma como me estás a olhar neste momento..."

    # say L3457 bil
    old "Makes me want to give you a better view."
    new "B:bil: Estava nervosa por usar algo tão diferente... mas a forma como me estás a olhar neste momento..."

    # say L3468 bil
    old "Tonight I want to celebrate... my way."
    new "B:bil: Faz-me querer dar-te uma melhor vista."

    # say L3477 bil
    old "You’ve been staring at my tits all night... time to give them some attention."
    new "B:bil: Esta noite quero celebrar... à minha maneira."

    # say L3486 bil
    old "Mmm... morning already?"
    new "B:bil: Estiveste a olhar para os meus peitos toda a noite... é hora de lhes dar atenção."

    # say L3487 pla
    old "Yeah... I don’t want it to be."
    new "T(pla|tu|say): Sim... Não quero que seja."

    # say L3488 bil
    old "Last night still feels like a dream."
    new "T(bil|tu|say): A noite passada ainda parece um sonho."

    # say L3489 pla
    old "It wasn’t a dream. You won. We won."
    new "B:bil: A noite passada ainda parece um sonho."

    # say L3490 bil
    old "And I didn’t completely fall apart... thanks to you."
    new "B:pla: Não foi um sonho. Tu ganhaste. Nós ganhámos."

    # say L3491 pla
    old "You didn’t need me to win. You just needed to remember who you are."
    new "T(pla|tu|say): Não precisavas de mim para vencer. Só precisavas de te lembrar quem és."

    # say L3492 bil
    old "Still... having you there made it feel possible."
    new "A:bil: Normalmente não faço o ‘depois da noite’ todo."

    # say L3494 bil
    old "I don’t usually do the whole ‘morning after’ thing."
    new "B:bil: Ainda assim... ter-te lá tornou tudo possível."

    # say L3495 pla
    old "Neither do I... but I’m really glad we did."
    new "B:bil: Normalmente não faço o ‘depois da noite’."

    # say L3496 bil
    old "Don’t get used to it, though. I’m still the same Billie."
    new "B:pla: Nem eu... mas estou realmente contente que tenhamos feito."

    # say L3497 pla
    old "Good. I like that Billie."
    new "B:bil: Não te habitues, no entanto. Eu sou ainda a mesma Billie."

    # say L3499 bil
    old "You should probably head home before your family starts asking questions."
    new "T(bil|tu|say): Deves provavelmente ir para casa antes que a tua família comece a fazer perguntas."

    # say L3501 pla
    old "But last night... everything we did, everything we said..."
    new "B:bil: Deves voltar a casa antes que a tua família comece a fazer perguntas."

    # say L3502 pla
    old "It meant a lot to me."
    new "B:pla: Mas ontem à noite... tudo o que fizemos, tudo o que dissemos..."

    # say L3504 bil
    old "It meant a lot to me too."
    new "T(bil|tu|diz): Significou muito para mim também."

    # say L3505 bil
    old "I’m not great at saying this stuff, but... thank you. For not giving up on me. For pushing me. For staying."
    new "B:bil: Significou muito para mim também."

    # say L3508 bil
    old "Alright, we better get dressed."
    new "B:bil: Não sou muito bom a dizer isto, mas... obrigado. Por não desistires de mim. Por me empurrares. Por ficares."

    # say L3515 pla
    old "I’ll see you at school later?"
    new "B:bil: Vamos vestir-nos, então."

    # say L3516 bil
    old "Yeah... I’ll be there."
    new "B:pla: Vemo-nos na escola mais tarde?"

    # say L3517 bil
    old "And don’t be late, or I’ll drag you back here again."
    new "B:bil: Sim... Estarei lá."

    # say L3518 pla
    old "Wouldn’t miss it."
    new "B:bil: E não cheges atrasado, ou arrasto-te de volta aqui outra vez."

    # say L3524 pla
    old "Take care of yourself, Billie."
    new "B:pla: Não ia faltar."

    # say L3525 bil
    old "You too."
    new "B:pla: Cuida-te, Billie."

    # say L3551 pla
    old "Alright... time for some practice."
    new "T:pla|tu|say: Tudo bem... é hora de praticar."

    # say L3553 pla
    old "It’s becoming part of the routine... and I actually look forward to it."
    new "T(pla|tu|say): Torna-se parte da rotina... e eu até me apetecem fazer isto."

    # say L3574 pla
    old "Feels natural now... like the guitar is actually listening."
    new "B:pla: Está a tornar-se parte da rotina... e eu até me apetece."

    # say L3607 pla
    old "It doesn’t feel like a chore anymore. It feels... right."
    new "B:pla: Ainda há uns pontos difíceis... mas no geral soou bem."

    # say L3610 pla
    old "Tomorrow I’ll pick it up again... no pressure, just playing."
    new "B:pla: Já não parece uma tarefa. Sente-se... certo."

    # say L3651 pla
    old "Yeah... I’ve been practicing a lot by myself, but I feel like I improve faster when I’m with you."
    new "B:pla: Amanhã volto a pegar... sem pressão, só jogando. T(pla|tu|say): Sim... tenho treinado muito sozinho, mas sinto que melhoro mais rápido quando estou contigo. A:n: Ensaiem a música juntos."

    # menu L3663 
    old "Rehearse the song together"
    new "B:pla: Sim... Tenho estado a praticar muito sozinho, mas sinto que melhoro mais rápido quando estou contigo."

    # say L3665 pla
    old "I want to polish the chords even more, you know..."
    new "B:n: Ensaiemos a música juntos"

    # say L3666 bil
    old "Heh. Going for the safe route first? Fine by me... for now."
    new "B:pla: Quero polir ainda mais os acordes, sabes..."

    # say L3701 bil
    old "Hmm... your changes are actually smooth now. You’ve been practicing."
    new "B:bil: Heh. A ir pelo caminho seguro primeiro? Tudo bem para mim... por agora."

    # say L3706 bil
    old "Still... I wouldn’t mind if you picked something a little more fun next time."
    new "B:bil: Hmm... as tu tens feito, as mudanças são agora mais suaves. Tens estado a praticar."

    # menu L3708 
    old "Finger practice"
    new "B:bil: Ainda... Não me importava se escolheisses algo um pouco mais divertido da próxima vez."

    # say L3743 pla
    old "They’re... so soft every time. I can feel them filling my hands."
    new "B:n: Prática com os dedos"

    # say L3744 bil
    old "Mmm... squeeze them slowly. Open and close your hands... just like that."
    new "B:pla: Eles... são tão macios cada vez. Consigo senti-los a encher as minhas mãos."

    # say L3747 bil
    old "Nngh— yeah... a little harder now. Grip them properly."
    new "B:bil: Mmm... aperta-os devagar. Abre e fecha as mãos... assim mesmo."

    # say L3750 bil
    old "Fuck... keep that pace. Squeeze them like you mean it."
    new "B:bil: Nngh— sim... mais forte agora. Segura-os direito."

    # say L3753 bil
    old "Now the nipples... grab them and pull... slow at first."
    new "B:bil: Merda... mantém esse ritmo. Aperta-os como se significasse alguma coisa."

    # say L3764 bil
    old "That’s it... stretch them gently."
    new "B:bil: Agora os mamilos... agarra-los e puxa... devagar no início."

    # say L3772 bil
    old "Fuck... faster. Pull them nice and firm. I love how confident your hands feel now."
    new "B:bil: É isso... alonga-os suavemente."

    # say L3777 bil
    old "Mmm... your touch is way more precise lately. You’ve improved a lot."
    new "B: Foda... mais rápido. Puxa-os com força. Adoro como as tuas mãos se sentem agora, tão confiantes."

    # say L3779 bil
    old "Keep practicing that rhythm at home... or just come back whenever you want more of... this."
    new "B:bil: Mmm... o teu toque está muito mais preciso ultimamente. Melhoraste muito."

    # menu L3781 
    old "Advanced finger practice"
    new "B:bil: Continua a praticar esse ritmo em casa... ou só volta sempre que quiseres mais... disto."

    # say L3801 pla
    old "Uhh... I’ve been practicing the guitar a lot by myself lately."
    new "T(tu|diz): Uhh... Tenho-me estado a praticar bastante a guitarra sozinho ultimamente."

    # say L3802 pla
    old "And I was thinking... maybe it would be good if I helped you with your practice too, you know?"
    new "E estava a pensar... talvez fosse bom se eu te ajudasse também com a tua prática, sabes?"

    # say L3803 pla
    old "Like... helping you stay steady under pressure... like last time..."
    new "B:pla: E eu estava a pensar... talvez fosse bom se eu te ajudasse com a tua prática também, sabes?"

    # say L3804 bil
    old "Heh... look at you trying to be all subtle."
    new "Heh... olha para ti a tentar ser todo sutil."

    # menu L3826 
    old "Get motivated"
    new "T(n|tu|menu): Motiva-te"

    # say L3828 pla
    old "And sometimes I feel like I still need... a little extra motivation to keep improving."
    new "T: E às vezes sinto que ainda preciso... de um pouco de motivação extra para continuar a melhorar."

    # say L3829 bil
    old "Heh... so that’s what this is really about."
    new "T(bil|tu|say): Heh... então é disso que se trata afinal."

    # say L3834 bil
    old "Just looking at them... does that help?"
    new "B:bil: Heh... então é disso que se trata afinal."

    # say L3836 pla
    old "Y-yeah... they look amazing but... I was thinking maybe something more... direct?"
    new "T(tu|say): Y-yeah... eles parecem incríveis, mas... estava a pensar em algo mais... direto?"

    # say L3839 bil
    old "Heh... fine. I know exactly how to motivate you properly."
    new "B:pla: H-hum... eles parecem incríveis, mas... estava a pensar em algo mais... direto?"

    # say L3859 bil
    old "Phew... that’s enough for today."
    new "Hey... antes de ires."

    # say L3861 bil
    old "Hey... before you go."
    new "B:bil: Phew... chega por hoje."

    # say L3865 bil
    old "It’s important... and I don’t want to go alone."
    new "B:bil: Ei... antes de ires."

    # say L3875 bil
    old "Oh, by the way..."
    new "B:bil: É importante... e não quero ir sozinho."

    # say L3887 bil
    old "Just text me. I’ll always make time... especially if you want the fun version."
    new "B:bil: Oh, a propósito..."


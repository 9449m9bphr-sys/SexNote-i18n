# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/JadStory.rpy
translate portuguese strings:

    # say L7 pla
    old "Hi Hinn, good morning. How are you?"
    new "T(pla|tu|say): Olá Hinn, bom dia. Como estás?"

    # say L10 pla
    old "Boy, I feel like it's been a while since I've seen you."
    new "B:pla: Olá Hinn, bom dia. Como estás?"

    # say L12 hin
    old "Yeah... We haven't really hung out lately."
    new "T(hin|tu|diz): Sim... Não nos temos visto muito ultimamente."

    # say L13 hin
    old "Actually, I've been thinking..."
    new "B:hin: Yeah... Não nos temos visto muito ultimamente."

    # say L14 hin
    old "Do you think you would like to come to my house? Maybe we could watch a movie together?"
    new "B:hin: Na verdade, tenho pensado..."

    # say L15 hin
    old "I- if you want to... Of course."
    new "B:hin: Tu achas que gostavas de vir à minha casa? Podíamos ver um filme juntos?"

    # say L16 pla
    old "Of course, that would be nice."
    new "B:hin: S-s-Se quiseres... Claro."

    # say L17 hin
    old "Really? That's great!"
    new "B:pla: Claro, isso seria ótimo."

    # say L18 hin
    old "Well, since we're done with school for the day. Would you like to go now?"
    new "B:hin: Mesmo? Ótimo!"

    # say L19 pla
    old "Sure, that sounds great."
    new "B:hin: Bem, já que as aulas acabaram. Queres ir agora?"

    # say L33 pla
    old "Ok, so, what movie do you think you would like to watch?"
    new "Bem, tenho andado a querer ver este novo filme chamado 'Lusted Note.'"

    # say L34 hin
    old "Well, I've been wanting to watch this new movie called 'Lusted Note.'"
    new "B:pla: Ok, então, que filme achas que gostavas de ver?"

    # say L35 pla
    old "Uhh, ok... What's it about?"
    new "B:hin: Bem, tenho andado a querer ver este novo filme chamado 'Lusted Note.'"

    # say L36 hin
    old "It's a romance movie about a stepbrother and stepsister who fall in love."
    new "T(hin|tu|diz): É um filme de romance sobre um meio-irmão e uma meio-irmã que se apaixonam."

    # say L37 hin
    old "It's been all the rage lately, everyone says it's so good! And the lead actress is really good, I'm her fan!"
    new "B:hin: É um filme de romance sobre um meio-irmão e uma meio-irmã que se apaixonam."

    # say L38 pla
    old "Well, sounds interesting, let's watch it."
    new "B:hin: Tem sido o assunto do momento, todos dizem que é tão bom! E a atriz principal é realmente boa, sou fã dela!"

    # say L54 pla
    old "Wow this movie is actually really good."
    new "B:pla: Bem, parece interessante, vamos ver."

    # say L55 hin
    old "Yeah, it's great."
    new "B:pla: Que surpresa, este filme é realmente muito bom."

    # say L56 hin
    old "I really like their love story, it's so beautiful."
    new "A:hin: Sabes, estou muito feliz que tenhas decidido vir hoje."

    # say L57 hin
    old "You know, I'm very happy you decided to come, today."
    new "T(hin|tu|say): Sabes, estou muito feliz que tenhas decidido vir hoje."

    # say L58 hin
    old "I thought maybe, you wouldn't want to come."
    new "T(hin|tu|say): Pensei que talvez não quisesses vir."

    # say L61 pla
    old "What? Why would you think that?"
    new "T(pla|tu|say): Que? Porquê que pensaste isso?"

    # say L62 hin
    old "Well, it's just that you're such a popular guy, you know..."
    new "B:pla: O quê? Porque é que pensaste isso?"

    # say L63 pla
    old "Popular? Me??"
    new "T(pla|tu|say): Popular? Eu??"

    # say L64 pla
    old "Come on... There's no way you think I'm popular."
    new "B:pla: Popular? Eu??"

    # say L65 hin
    old "Well, you seem to get along quite well with a lot of people."
    new "B:pla: Vamos... Não há como tu pensares que sou popular."

    # say L66 hin
    old "You know... You get along so well with Belle and Billie."
    new "B:hin: Bem, tu pareces-te a dar bem com muita gente."

    # say L70 pla
    old "Well, you know... They're my friends too."
    new "E eu gosto muito de passar tempo com eles."

    # say L71 pla
    old "And I really like hanging out with them."
    new "B:pla: Bem, tu sabes... Eles também são meus amigos."

    # say L72 pla
    old "But that doesn't mean I wouldn't want to hang out with you. Or that I would be too busy."
    new "B:pla: E gosto mesmo de passar tempo com eles."

    # say L73 pla
    old "I really enjoy spending time with you Hinn."
    new "B:pla: Mas isso não significa que eu não queira passar tempo contigo. Ou que esteja demasiado ocupado."

    # say L93 pla
    old "Oh!"
    new "T(pla|tu|say): Oh!"

    # say L94 hin
    old "So... If you want, we could... You know..."
    new "A:pla: Uhh... Devíamos ir para o teu quarto?"

    # say L95 pla
    old "Uhh... Should we go up to your bedroom?"
    new "B:hin: Então... Se quiseres, nós podíamos... Tu sabes..."

    # say L97 hin
    old "Haha, there's no need."
    new "B:pla: Uhh... Devíamos ir para o teu quarto?"

    # say L98 hin
    old "She'll take a while, so, we can just do it here."
    new "A:jad: Bem?!"

    # say L117 jad
    old "Well?!"
    new "A:jad: Não vais dizer nada?"

    # say L118 jad
    old "Aren't you going to say anything?"
    new "A:hin: Espera aí! O que estás a fazer em casa tão cedo?! Disseste-me que ias chegar tarde hoje!"

    # say L122 hin
    old "Wait a minute! What are you doing home so early?! You told me you were going to be late today!"
    new "T(hin|tu|dizer): Espera aí! O que estás a fazer em casa tão cedo?! Disseste-me que ias chegar tarde hoje!"

    # say L123 jad
    old "I decided to come home early today."
    new "B:hin: Espera aí! Porque é que estás em casa tão cedo?! Disseste-me que ias chegar tarde hoje!"

    # say L124 jad
    old "But I see now this is why you kept asking me what I was going to be doing today..."
    new "B:jad: Decidi vir para casa mais cedo hoje."

    # say L125 jad
    old "This is incredible..."
    new "B:jad: Mas agora percebo por que continuavas a perguntar-me o que ia fazer hoje..."

    # say L127 hin
    old "We weren't doing anything wrong you know."
    new "B:jad: Isto é incrível..."

    # say L131 jad
    old "Just look at the way you two are right now!"
    new "Mas se vais fazer sexo, por favor, fazem-no num lugar privado!"

    # say L132 jad
    old "Just standing there completely naked!"
    new "B:jad: Olha só para vocês dois assim!"

    # say L140 jad
    old "(Whoah, h-he's so big!)"
    new "B:jad: Aí parado completamente nu!"

    # say L141 jad
    old "You have to think about other people, you know..."
    new "B:jad: (Caramba, e-ele é tão grande!)"

    # say L142 hin
    old "We just didn't know you were coming home so soon..."
    new "A:jad: Ouve, sei que vocês são jovens e cheios de hormonas..."

    # say L143 jad
    old "Listen, I know you guys are young and full of hormones..."
    new "B:hin: Não sabíamos que tu ias voltar tão cedo..."

    # say L146 jad
    old "But this is the living room! I usually watch tv on that couch!"
    new "B:jad: Ouve, sei que vocês são jovens e cheios de hormonas..."

    # say L147 jad
    old "Besides, I could've come home with company..."
    new "B:jad: Mas isto é a sala de estar! Normalmente vejo televisão nesse sofá!"

    # say L148 jad
    old "Imagine what would have happened if someone saw you and your boyfriend having sex on the couch Hinn."
    new "B:jad: Além disso, poderia ter vindo para casa com companhia..."

    # say L151 hin
    old "B- boyfriend? (Gosh! Mom why can't you shut up...)"
    new "B:jad: Imagina o que teria acontecido se alguém te visse a fazer sexo no sofá com o teu namorado, hã."

    # say L152 hin
    old "Uhh... W- We are not a... C- couple... (Not yet, THANKS MOM!)"
    new "B: B- namorado? (Pelo amor de Deus, mãe, não podes calar-te...)"

    # say L153 hin
    old "We still being... Uhh, just friends."
    new "B:hin: Uhh... N-Nós não somos... C- casal... (Ainda não, OBRIGADO MÃE!)"

    # say L157 jad
    old "E- excuse me?"
    new "E- desculpa?"

    # say L158 jad
    old "B- but you two were just..."
    new "B:jad: E- desculpa?"

    # say L159 hin
    old "Mom please, this is not your business!"
    new "B:jad: B- mas vocês dois acabaram de..."

    # say L161 jad
    old "Well, I guess that's just how you do things these days..."
    new "B:hin: Mãe, por favor, isso não é da tua conta!"

    # say L162 jad
    old "I get it, young people are a little more open nowadays, as long as your kids are safe... I guess it's alright."
    new "B:jad: Bem, acho que é assim que as coisas são feitas nos dias de hoje..."

    # say L163 jad
    old "But that's not the point, the point is that you should be more careful with these things."
    new "B:jad: Entendo, os jovens são um pouco mais abertos hoje em dia, desde que os teus filhos estejam seguros... Acho que está bem."

    # say L164 jad
    old "If you're going to be having sex, do it in your bedroom."
    new "B:jad: Mas isso não é o ponto, o ponto é que tu deves ser mais cuidado com estas coisas."

    # say L165 jad
    old "It doesn't matter if I'm not home, try to be a little respectful, will you?"
    new "B:jad: Se vais ter relações sexuais, faz isso no teu quarto."

    # say L167 hin
    old "Oh my gosh! It was an accident!"
    new "B:jad: Não importa se não estou em casa, tenta ser um pouco respeitosa, sim?"

    # say L185 jad
    old "(God, he really has a huge...)"
    new "B:pla: Desculpe, Sra. Jade."

    # say L205 pla
    old "It's ok. Besides, I sort of think that she's  right."
    new "Tudo bem. Além disso, acho que ela tem razão. Quero dizer, fizemos isso na sala de estar."

    # say L208 pla
    old "Yeah, I mean, we did it in the living room."
    new "B:pla: Tudo bem. Além disso, eu acho que ela tem razão."

    # say L209 pla
    old "In a way, we're lucky she wasn't even angrier."
    new "B:pla: Sim, quero dizer, fizemos isso na sala de estar."

    # say L214 hin
    old "I guess you have to go, right?"
    new "T(hin|tu|say): Acho que tens de ir, certo?"

    # say L215 pla
    old "Yeah, I better go home, but, maybe we can finish the movie some other time."
    new "T(pla|tu|say): Sim, melhor ir para casa, mas, talvez possamos terminar o filme noutra altura."

    # say L217 hin
    old "Yeah, that would be great!"
    new "B:pla: Sim, melhor ir para casa, mas, talvez possamos terminar o filme noutra altura."

    # say L219 hin
    old "Alright, see you later [pla]."
    new "T(hin|tu|say): Tudo bem, até logo [pla]."

    # say L239 hin
    old "Oh, it's fine, she wasn't really all that angry."
    new "B:pla: Olá Hinn, estou ótimo. E tu? Como estão as coisas com a tua mãe?"

    # say L240 pla
    old "I see, that's good I guess."
    new "A:hin: Nesse caso, estava a pensar..."

    # say L241 hin
    old "On that note, I was thinking..."
    new "T(hin|tu|diz): Naquele tom, eu estava pensando..."

    # say L242 hin
    old "You know, since last time we couldn't actually finish the movie, what do you think if you come over and we finish it?"
    new "B:hin: Nesse caso, eu estava pensando..."

    # say L244 pla
    old "Huh? Come over? To your house?"
    new "B:hin: Sabes, como da última vez não conseguimos acabar o filme, que tal vens cá a casa e acabamos de ver?"

    # say L246 hin
    old "Yeah, of course."
    new "Não, claro que não."

    # say L247 hin
    old "Is there a problem?"
    new "B:hin: Claro, claro."

    # say L248 pla
    old "No, no problem. I'm just not sure about it, you know?"
    new "T(pla|tu|say): Não, sem problemas. Estou só um pouco incerto, sabes?"

    # say L249 pla
    old "What if your mother doesn't like that I go there?"
    new "B:pla: Não, sem problemas. Só não tenho a certeza, sabes?"

    # say L250 hin
    old "Don't be silly, I told you, she's not angry."
    new "B:pla: E se a tua mãe não gostar que eu vá lá?"

    # say L251 hin
    old "We just need to be careful and nothing will happen."
    new "B:hin: Não sejas parvo, já te disse, ela não está zangada."

    # say L253 pla
    old "Hmm, I guess you're right."
    new "B:hin: Temos apenas de ter cuidado e nada acontecerá."

    # say L283 jad
    old "Oh, hi [pla]! I didn't know you were here!"
    new "T(jad|tu|say): Oh, olá [pla]! Não sabia que estavas aqui!"

    # say L288 jad
    old "Well, it's good to see you again..."
    new "B:pla: Olá Sra. Jade, como vai? Estava a ver um filme com a Hinn."

    # say L296 jad
    old "So, what are you watching?"
    new "B:jad: Bem, é bom ver-te de novo..."

    # say L300 whi
    old "Phew, I definitely should take some extra parking lessons, heh."
    new "A:whi: Oh, olá crianças! Como estão?"

    # say L304 whi
    old "Oh, hi kids! How are you?"
    new "B:whi: Phew, definitivamente devo fazer algumas aulas extra de estacionamento, heh."

    # say L317 hin
    old "Hello Mrs. White, how are you?"
    new "B:pla: Olá Sra. White... É bom ver-te..."

    # say L318 whi
    old "I'm very good darling. I have to say I love your new outfit, it suits you much better than that old jumper you used before."
    new "B:hin: Olá Sra. White, como está?"

    # say L321 jad
    old "You're right, it's amazing..."
    new "B:whi: Estas crianças crescem tanto de um momento para o outro, não é, Jade?"

    # say L323 hin
    old "So, you two were out together?"
    new "A:jad: Sim, é verdade, a Sra. White estava a ajudar-me com algumas tarefas."

    # say L324 jad
    old "Yeah, that's right, Mrs. White was helping me with some shores."
    new "B:hin: Então, vocês dois estavam juntos?"

    # say L325 jad
    old "And I told her to come to hang out with me."
    new "B:jad: Sim, é verdade, a Sra. White estava a ajudar-me com algumas tarefas."

    # say L326 jad
    old "We hadn't spoken in a while."
    new "B:jad: E disse-lhe para vir passar algum tempo comigo."

    # say L327 hin
    old "Oh, ok. That's great."
    new "B:jad: Não tínhamos falado há muito tempo."

    # say L338 whi
    old "So, you two were watching a movie?"
    new "B:jad: Uhh, o telemóvel está a tocar. Já volto."

    # say L339 pla
    old "Yeah... that's right."
    new "T(pla|tu|say): Sim... foi bom."

    # say L340 whi
    old "Well? Was it good?"
    new "Bem? Foi bom?"

    # say L341 hin
    old "Umm, yeah, I guess..."
    new "B:whi: E então? Foi bom?"

    # say L342 hin
    old "I think we're going to keep watching it, so, if you don't mind"
    new "B:hin: Hum, sim, acho que sim..."

    # say L343 whi
    old "Oh well, I'll watch it with you then."
    new "B:hin: Acho que vamos continuar a ver, então, se não te importas"

    # say L356 jad
    old "I can't believe you! I just simply can't"
    new "B:whi: Oh well, vou ver com tu então."

    # say L357 jad
    old "Why don't you take..."
    new "A:jad: Não! Eu não disse isso!"

    # say L358 jad
    old "No! I did not say that!"
    new "A:jad: É sempre a mesma coisa contigo, Hiashi!"

    # say L364 jad
    old "It's always the same with you Hiashi!"
    new "B:jad: Não! Eu não disse isso!"

    # say L370 jad
    old "It's almost as if you don't care about your daughter's well-being."
    new "B:jad: É sempre a mesma coisa contigo, Hiashi!"

    # say L371 jad
    old "My God!!"
    new "B:jad: É quase como se tu não te importasses com o bem-estar da tua filha."

    # say L372 jad
    old "No, NO! YOU listen to me! You have to figure out something and fulfill your responsibility or I'm taking action."
    new "B:jad: Meu Deus!!"

    # say L383 jad
    old "Ok, I'm here again."
    new "B:jad: Não, NÃO! Tu tens de ouvir-me! Tens de arranjar uma solução e cumprir as tuas responsabilidades, senão tomo medidas."

    # say L393 whi
    old "Are you ok? What happened?"
    new "A:jad: Uhh, por favor, não me digas que ouviste tudo o que eu disse..."

    # say L394 jad
    old "Uhh, please don't tell me you heard everything I said..."
    new "T(jad|tu|say): Uhh, por favor, não me digas que ouviste tudo o que disse..."

    # say L395 whi
    old "You weren't very quiet, to be honest..."
    new "B:jad: Uhh, por favor, não me digas que ouviste tudo o que eu disse..."

    # say L413 whi
    old "Well, that was very good!"
    new "B:jad: Vamos fingir que nunca aconteceu e aproveitar o filme."

    # say L414 hin
    old "It really was."
    new "A:whi: Acho que vou ver tudo quando chegar a casa. Não achas que foi ótimo, Jade?"

    # say L416 whi
    old "I think I'll watch it in full when I get home. Don't you think it was great Jade?"
    new "B:hin: Foi mesmo."

    # say L419 jad
    old "What? Oh, yeah... Very good."
    new "B:whi: Acho que vou ver tudo quando chegar a casa. Não achas que foi ótimo, Jade?"

    # say L421 whi
    old "Ok, tell me, what is it?"
    new "A:whi: Vamos, não finjas que não sabes."

    # say L423 whi
    old "Come on, don't play dumb with me."
    new "A:whi: O que é que Hiashi disse desta vez?"

    # say L424 whi
    old "What did Hiashi say this time?"
    new "B:whi: Vamos, não finjas que não sabes."

    # say L425 jad
    old "Honestly, I don't want to talk about this, especially not in front of the kids."
    new "T(jad|tu|dizer): Honestamente, não quero falar sobre isso, especialmente na frente das crianças."

    # say L426 whi
    old "Oh come on, they're adults now. Nothing bad will happen to them."
    new "B:jad: Honestamente, não quero falar sobre isso, especialmente na frente das crianças."

    # say L427 whi
    old "Just spit it out, if you don't talk about it you'll be in a bad mood all week."
    new "A:jad: Foi o Hiashi, a dizer, mais uma vez! Que não pode pagar a minha pensão alimentar este mês."

    # say L429 jad
    old "That was Hiashi, saying, once again! That he can't pay my alimony this month."
    new "B:whi: Anda, diz logo, se não falares vais estar de mau humor toda a semana."

    # say L430 jad
    old "That's four months in a row! That irresponsible bum!"
    new "B:jad: Foi o Hiashi, a dizer, mais uma vez! Que não pode pagar a pensão de alimentos este mês."

    # say L431 jad
    old "And it's not as if things are any easy around here, he should know how the economy is around here."
    new "B:jad: São quatro meses seguidos! Esse irresponsável!"

    # say L432 whi
    old "That's Hiashi for you, always the same guy..."
    new "B:jad: E não é como se as coisas fossem fáceis por aqui, ele devia saber como está a economia."

    # say L434 whi
    old "I bet he's still seeing that 19-year-old bimbo isn't he?"
    new "B:whi: É o Hiashi, sempre o mesmo..."

    # say L435 jad
    old "Yes, he is! God! That's what bothers me! He doesn't have enough money to help his daughter!"
    new "T: Sim, ele está! Meu Deus! É isso que me incomoda! Ele não tem dinheiro suficiente para ajudar a filha!"

    # say L437 jad
    old "But he can go around buying expensive clothes and vacations for some hussy that could be his grandchild!"
    new "B:jad: Sim, ele é! Meu Deus! É isso que me incomoda! Ele não tem dinheiro suficiente para ajudar a filha!"

    # say L439 jad
    old "I'm sorry Hinn, sweety, I wouldn't want to talk to you about your father like that."
    new "B:jad: Mas ele pode andar a comprar roupa cara e férias para alguma rapariga que poderia ser sua neta!"

    # say L442 hin
    old "Hmph, whatever, not like any of this is new to me."
    new "B:jad: Sinto muito, Hinn, querida, não queria falar assim sobre o teu pai."

    # say L443 hin
    old "But I would've liked to have a calm movie night."
    new "B:hin: Humph, seja como for, nada disto é novidade para mim."

    # say L458 hin
    old "God! My mom ruins everything!"
    new "B:hin: Ouve, sinto muito pelo que aconteceu."

    # say L459 pla
    old "No, no, don't worry. That's ok, I understand."
    new "B:hin: Que raio! A minha mãe estraga tudo!"

    # say L460 pla
    old "I get it, this type of thing can stress anybody."
    new "T(pla|tu|say): Entendo, este tipo de coisa pode stressar qualquer um."

    # say L462 hin
    old "You know, you're always very sweet."
    new "B:pla: Entendo, este tipo de coisa pode stressar qualquer um."

    # say L464 hin
    old "Yes, and it deserves a reward..."
    new "A:pla: O que estamos a fazer aqui?"

    # say L484 pla
    old "What are we doing here?"
    new "B:hin: Sim, e merece uma recompensa..."

    # say L485 hin
    old "Well, we needed privacy to give you a special reward."
    new "B:pla: O que estamos a fazer aqui?"

    # say L488 pla
    old "Whoah! What are you doing?"
    new "B:hin: Bem, precisávamos de privacidade para te dar um prémio especial."

    # say L489 hin
    old "I told you, I'm giving you a reward."
    new "B:pla: Whoah! O que estás a fazer?"

    # say L490 hin
    old "I was thinking that we could finish what we started the other night."
    new "B:hin: Eu já te disse, vou-te dar uma recompensa."

    # say L491 hin
    old "But my mom and Mrs. White got home when I wasn't expecting it."
    new "B:hin: Estava a pensar que podíamos terminar o que começámos na outra noite."

    # say L492 hin
    old "So, I'll just give  you a little something before you go home."
    new "B:hin: Mas a minha mãe e a Sra. White chegaram a casa quando eu não estava à espera."

    # say L510 whi
    old "Hey, what are you doing there?"
    new "Que?! Oh, meu Deus! Assustaste-me!"

    # say L512 jad
    old "What?! Oh, my God! You surprised me!"
    new "B:whi: Ei, o que estás a fazer aí?"

    # say L513 whi
    old "Well, you were taking your sweet time and you left the stove on... Do you want me to finish dinner for you?"
    new "B:jad: Que?! Oh, meu Deus! Surpreendeste-me!"

    # say L514 jad
    old "No, no, I just got distracted by... Something."
    new "B:whi: Bem, tu estavas a demorar-te e deixaste o fogão ligado... Queres que eu termine o jantar por ti?"

    # say L516 whi
    old "Right... Is there anything in the bathroom?"
    new "B:jad: Não, não, eu só me distraí com... Algo."

    # say L518 jad
    old "Nothing! Nothing! I was just looking for Hinn, but she isn't there."
    new "B:whi: Certo... Tem algo na casa de banho?"

    # say L519 whi
    old "Ok, sure."
    new "B:jad: Nada! Nada! Estava só à procura da Hinn, mas ela não está lá."

    # say L520 jad
    old "Anyway, let's go, help me with the mac and cheese."
    new "B:whi: Ok, claro."

    # say L538 hin
    old "That was very good."
    new "B:jad: Então, vamos, ajuda-me com o mac e queijo."

    # say L539 pla
    old "Yeah, it was, I wasn't expecting it though."
    new "B:hin: Foi muito bom."

    # say L540 hin
    old "Well, I wanted to make it up to you for the interruption last time, you know."
    new "B:pla: Sim, foi, mas não estava à espera."

    # say L541 pla
    old "Yeah, I think I get it."
    new "B:hin: Bem, queria compensar-te pela interrupção da última vez, sabes."

    # say L542 pla
    old "Anyway, I think, I shoould go home."
    new "T(pla|tu|say): De qualquer forma, acho que devo ir para casa."

    # say L543 hin
    old "Hmm, yeah you are right."
    new "A:hin: Ouve, sinto muito mesmo pelo que aconteceu hoje, com a minha mãe a gritar durante todo o filme e tudo."

    # say L544 hin
    old "Listen, I'm really sorry about today, with my mom yelling all the movie and everything."
    new "Ouvindo, estou mesmo muito arrependido pelo que aconteceu hoje, com a minha mãe a gritar durante todo o filme e tudo mais."

    # say L545 hin
    old "It ruined the movie afternoon."
    new "A:pla: Oh, vai lá, ainda me diverti imenso."

    # say L546 pla
    old "Oh come on, I still had a great time."
    new "B:hin: Estragou a tarde de cinema."

    # say L547 pla
    old "If you'd like, maybe we could watch another movie some other day."
    new "B:pla: Oh, vai lá, ainda me diverti imenso."

    # say L549 pla
    old "Let's do it then."
    new "B:pla: Se quiseres, podemos ver outro filme noutro dia."

    # say L551 pla
    old "Alright, so, I better go now."
    new "B:pla: Vamos lá então."

    # say L572 hin
    old "I'm great actually, my mom and I talked, and we're both feeling a lot better."
    new "B:pla: Obrigado, realmente gostei do dia. Até já, Hinn."

    # say L573 pla
    old "That's good, it's great that you can talk about those things."
    new "B:hin: Estou ótimo, na verdade. A minha mãe e eu conversamos, e ambos nos sentimos muito melhor."

    # say L574 pla
    old "It's a shame about the movie tho, though I suppose that still annoys you a little bit..."
    new "B:pla: Isso é bom, é ótimo que tu consigas falar sobre essas coisas."

    # say L575 hin
    old "Well, about that..."
    new "B:pla: É uma pena o filme, embora suponha que isso ainda te chateie um pouco..."

    # say L577 hin
    old "Do you think you would like to go to my house again?"
    new "B:hin: Bem, a respeito disso..."

    # say L578 hin
    old "There's another movie that I would like to watch with you..."
    new "B:hin: Tu achas que gostavas de ir outra vez à minha casa?"

    # say L580 pla
    old "Hmm... Yeah, sure, I don't see why not."
    new "B:hin: Há outro filme que eu gostava de ver contigo..."

    # say L581 hin
    old "Hey, that's great."
    new "B:pla: Hmm... Sim, claro, não vejo porque não."

    # say L582 hin
    old "And listen, this time my mom will be leaving for some event dinner she was invited to."
    new "E escuta, desta vez a minha mãe vai sair para um jantar de evento a que foi convidada. Então, talvez possamos terminar o filme... E fazer mais alguma coisa."

    # say L583 hin
    old "So, maybe we can finish the movie... And something else."
    new "B:hin: E ouve, desta vez a minha mãe vai sair para um jantar de evento a que foi convidada."

    # say L584 pla
    old "Oh, sure."
    new "B:hin: Então, talvez possamos acabar o filme... E mais alguma coisa."

    # say L585 pla
    old "Sounds good."
    new "Ótimo! Então, vamos."

    # say L587 hin
    old "Great! So, let's go."
    new "A:jad: Merda!"

    # say L617 jad
    old "God dammit!"
    new "B:hin: Ótimo! Então, vamos."

    # say L636 jad
    old "Are you having a good time?"
    new "B:jad: Não sabia que tu estavas aqui, querida!"

    # say L637 pla
    old "Hello Mrs. Jade, I was just watching a movie with Hinn."
    new "B:jad: Estás a divertir-te bem?"

    # say L639 jad
    old "I'm glad honey."
    new "T(jad|tu|say): Estou contente, meu amor."

    # say L640 hin
    old "What happened now mom?"
    new "B:jad: Estou contente, querida."

    # say L641 hin
    old "Why did you scream and come out running in a towel?"
    new "B:hin: O que aconteceu agora, mãe?"

    # say L642 jad
    old "Well, I was taking a shower to get ready for that dinner I told you about."
    new "B:hin: Porque é que gritaste e saíste a correr com uma toalha?"

    # say L643 jad
    old "But, then my shower suddenly exploded!"
    new "B:jad: Estava a tomar banho para me preparar para aquele jantar de que te falei."

    # say L644 jad
    old "Now there's a lot of water running out of the piping."
    new "B:jad: Mas, depois a minha ducha explodiu de repente!"

    # say L646 hin
    old "So? Just call a plumber to fix it."
    new "B:jad: Agora há muita água a sair dos canos."

    # say L647 jad
    old "Well, young lady, in case you haven't been paying attention lately. We're not exactly swimming in money right now."
    new "B:hin: Então? Chama simplesmente um encanador para arranjá-lo."

    # say L648 jad
    old "Since your father hasn't been paying my alimony, I've been having to take care of things."
    new "Jad: Bem, minha jovem, caso não tenhas reparado recentemente, não estamos exatamente a nadar em dinheiro."

    # say L649 jad
    old "Right now I just can't afford to have somebody come and redo the entire bathroom tubing."
    new "B:jad: Como o teu pai não tem estado a pagar a pensão de alimentos, tenho tido de tomar conta das coisas."

    # say L651 hin
    old "Oh great!"
    new "A:pla: Uh, acho que talvez eu possa fazer alguma coisa nisso."

    # say L652 pla
    old "Uh, I think that maybe I could do something about that."
    new "T(pla|tu|say): Uh, acho que talvez eu possa fazer alguma coisa nisso."

    # say L653 jad
    old "Really? You know how to fix that type of thing?"
    new "B:pla: Uh, acho que posso fazer alguma coisa nisso."

    # say L654 pla
    old "I mean, I'd have to take a look, but maybe I can do something."
    new "T(pla|tu|say): Quer dizer, teria de dar uma vista de olhos, mas talvez consiga fazer alguma coisa."

    # say L655 hin
    old "Oh great, another fantastic movie night..."
    new "B:pla: Quero dizer, teria que ver, mas talvez consiga fazer algo."

    # say L661 pla
    old "Ok, ok, I see what happened, there was a rusty pipe, and it broke."
    new "B:hin: Ótimo, mais uma noite de cinema fantástica..."

    # say L663 pla
    old "I should be able to fix that."
    new "B:pla: Ok, ok, percebi o que aconteceu, havia um cano enferrujado e ele partiu."

    # say L664 jad
    old "Really? You think so?"
    new "B:pla: Deveria ser capaz de arranjar isso."

    # say L665 pla
    old "Well, it's going to take a while, because I'll have to change the whole piping for the bathroom."
    new "B:jad: Mesmo? Tu pensas isso?"

    # say L666 pla
    old "And that means breaking some of the wall and the floor."
    new "B:pla: Vai demorar um pouco, porque vou ter de mudar toda a canalização da casa de banho."

    # say L667 pla
    old "But it shouldn't be too much of a problem."
    new "B:pla: E isso significa quebrar parte da parede e do chão."

    # say L668 pla
    old "I actually have some experience doing house repairs and stuff."
    new "T(pla|tu|say): Na verdade, tenho alguma experiência em fazer reparos em casa e coisas assim."

    # say L669 jad
    old "You do? Did you have a part-time job doing that?"
    new "T(jad|tu|say): Tu fazes? Tiveste um emprego de meio expediente a fazer isso?"

    # say L671 pla
    old "I guess you could call it a summer job."
    new "T(pla|tu|say): Acho que podias chamar-lhe um emprego de verão."

    # say L673 jad
    old "I see, well, I guess the only thing I can say is. When do you start?"
    new "B:pla: Acho que se pode chamar de emprego de verão."

    # say L675 pla
    old "Well, I would need to get some materials. But overall it shouldn't be too expensive."
    new "B:jad: Entendo, bem, acho que a única coisa que posso dizer é. Quando vais começar?"

    # say L676 pla
    old "It's not too late, so, I should be able to make it to the hardware store."
    new "B:pla: Bem, eu precisava de alguns materiais. Mas no geral não deve ser muito caro."

    # say L678 jad
    old "Oh, but you shouldn't spend your own money on that honey."
    new "B:pla: Não é muito tarde, então, devo conseguir ir à loja de ferragens."

    # say L679 pla
    old "Well, I'll just buy some things, and if you want me to, I'll just hand you the receipt the next time I'm here."
    new "B:jad: Oh, mas tu não deves gastar o teu dinheiro nisso, querida."

    # say L680 jad
    old "That would be really nice of you."
    new "B:pla: Vou comprar algumas coisas, e se quiseres, dou-te o recibo da próxima vez que cá vier."

    # say L681 pla
    old "Don't worry, this won't be expensive at all."
    new "T(pla|tu|say): Não te preocupes, isto não vai ser caro nada."

    # say L682 jad
    old "That's a relief to hear."
    new "A:pla: Tudo bem, melhor ir agora, antes de fecharem."

    # say L683 pla
    old "Alright, I better go now, before they close."
    new "B:jad: É um alívio ouvir isso."

    # say L685 pla
    old "Oh, it's nothing, don't worry. But, I better hurry up, it's getting a bit late."
    new "T: Oh, não é nada, não te preocupes. Mas, melhor eu me apressar, está ficando um pouco tarde."

    # say L706 hin
    old "So? How bad it is?"
    new "B:pla: Oh, não é nada, não te preocupes. Mas, melhor eu me apressar, já está ficando um pouco tarde."

    # say L707 pla
    old "Well, not that bad, but it will definitely take a few days of work."
    new "B:hin: Então? Quão mau é?"

    # say L712 hin
    old "Hmm, I really can't belive you mom..."
    new "B:pla: Oh, não te preocupes. Não será nada e eu vou visitar-te mais vezes."

    # say L713 hin
    old "Anyway, so, let's finish the movie."
    new "B:hin: Hmm, não consigo acreditar, mãe..."

    # say L714 pla
    old "Uhh, actually... I have to try and get to the hardware store before they close."
    new "B:hin: Então, vamos acabar o filme."

    # say L732 pla
    old "No problem."
    new "Agora, melhor ir antes que fechem a loja de ferragens."

    # say L733 pla
    old "Now, I better leave before they close the hardware store."
    new "B:pla: Sem problema."

    # say L734 jad
    old "Sure, thanks again, honey."
    new "B:pla: Agora, melhor ir antes que fechem a loja de ferragens."

    # say L750 pla
    old "Hi Hinn."
    new "B:jad: Claro, obrigado mais uma vez, querida."

    # say L754 hin
    old "Listen [pla], I wanted to apologize about the way I acted yesterday."
    new "T(hin|tu|say): Ouve [pla], queria pedir desculpa pelo meu comportamento de ontem."

    # say L759 hin
    old "Mom has been stressed a lot, which means I've been stressed even more."
    new "B:hin: É que as coisas não têm estado nada bem em casa nestes últimos dias."

    # say L760 hin
    old "And I thought that maybe you and I could relax a little bit."
    new "B:hin: A mãe tem estado muito stressada, o que significa que eu tenho estado ainda mais stressado."

    # say L762 hin
    old "But everytime we tried we kept being interrupted."
    new "E todas as vezes que tentámos, fomos interrompidos. É frustrante."

    # say L763 hin
    old "And it's just frustrating."
    new "B:hin: Mas sempre que tentamos acabávamos por ser interrompidos."

    # say L764 pla
    old "It's ok, I know how important our movie times are to you."
    new "T(pla|tu|say): Tudo bem, sei o quanto as nossas sessões de cinema são importantes para ti."

    # say L765 pla
    old "I completely get it, don't worry."
    new "B:pla: Tudo bem, sei o quanto as nossas sessões de cinema são importantes para ti."

    # say L768 pla
    old "And start working on the repairs for the bathroom."
    new "B:pla: Por acaso, estava a pensar que podia passar na tua casa esta tarde."

    # say L769 pla
    old "Maybe we could even finish that movie we started last time."
    new "B:pla: E começa a trabalhar nas reparações da casa de banho."

    # say L773 hin
    old "But, my mom will be there. So, why don't you go and start working on the repairs?"
    new "T(hin|tu|say): Mas, a minha mãe vai estar lá. Por isso, porque não vais começar a trabalhar nas reparações?"

    # say L774 hin
    old "That way it won't take you that long, and we can have time to..."
    new "B:hin: Mas, a minha mãe vai estar lá. Então, porque não vais começar a trabalhar nas reparações?"

    # say L775 hin
    old "Finish the movie when I'm done with my stuff here."
    new "B:hin: Assim não vais demorar tanto, e podemos ter tempo para..."

    # say L777 pla
    old "That's a good idea."
    new "B:hin: Acaba o filme quando eu terminar as minhas coisas aqui."

    # say L778 pla
    old "Ok, sure, I'll go there and get started on the repairs."
    new "T(pla|tu|say): Ok, claro, vou lá e começo com os reparos."

    # say L779 hin
    old "Alright, then see you soon. And sorry about my mom once again."
    new "B:pla: Ok, claro, vou lá e começo com os reparos."

    # say L780 pla
    old "Hey, don't worry, everything will be alright. See you later."
    new "Bom dia, Sra. Jade."

    # say L796 pla
    old "Good morning, Mrs. Jade."
    new "B:pla: Oi, não te preocupes, tudo vai correr bem. Até mais tarde."

    # say L798 pla
    old "Fine, thank you."
    new "T(pla|tu|say): Foi bem, obrigado. Consegui tudo o que precisava para a reparação."

    # say L799 jad
    old "How did it go? Were you able to get all the things you need for the repair?"
    new "B:pla: Bem, obrigado."

    # say L800 pla
    old "Yes, I got everything without problems, and it was even cheaper than I expected."
    new "B:jad: Como correu? Conseguiste obter tudo o que precisavas para a reparação?"

    # say L801 jad
    old "Oh, thank God! Alright, then I will let you work, if you need something, please just let me know."
    new "B:pla: Sim, consegui tudo sem problemas e até foi mais barato do que esperava."

    # say L803 pla
    old "Alright, I'll get to it."
    new "B:jad: Oh, graças a Deus! Tudo bem, então deixa-te trabalhar, se precisares de algo, avisa-me."

    # say L812 pla
    old "Hi Mrs. Jade, how are you?"
    new "B:pla: Tudo bem, vou começar."

    # say L818 pla
    old "Yes, there is still work to be done."
    new "B:jad: Vim trabalhar ao banheiro?"

    # say L819 jad
    old "Oh, thank you darling. Well, you know where the materials are, I won't bother you."
    new "B:pla: Sim, ainda há trabalho a fazer."

    # say L821 pla
    old "Sure, I'll get to it."
    new "B:jad: Oh, obrigado querido. Bem, sabes onde estão os materiais, não te vou incomodar."

    # say L827 pla
    old "There's some work to do here. But, I know what I have to do, so, it should be easy."
    new "Bem, acho que vou começar."

    # say L828 pla
    old "Well, I guess I'll get to it."
    new "B:pla: Há trabalho a fazer aqui. Mas, sei o que tenho de fazer, por isso, deve ser fácil."

    # say L829 pla
    old "I'll try and finish this quickly."
    new "B:pla: Bem, acho que vou começar."

    # say L872 pla
    old "Phew, I got a lot done today."
    new "B:pla: Vou tentar acabar isto depressa."

    # say L873 pla
    old "Although, I still have quite a bit to do, anyway, at least this is something."
    new "B:pla: Ufa, fiz muito hoje."

    # say L874 pla
    old "It's kinda late, so, let's call it a day."
    new "B:pla: Ainda tenho bastante por fazer, mas pelo menos isto está feito."

    # say L895 pla
    old "But, she knew I was here, just next to her bedroom..."
    new "B:pla: É um pouco tarde, então, vamos chamar de dia."

    # say L911 jad
    old "It's getting a bit late [pla], I think we just better call it a day."
    new "T(jad|tu|diz): Está a ficar um pouco tarde [pla], acho que é melhor irmos dormir."

    # say L914 pla
    old "But you are right, it's kinda late now, I better come back and continue another time."
    new "B:pla: Tens razão, Sra. Jade, estou de facto contente com isso, consegui fazer bastante hoje."

    # say L915 jad
    old "Well, it's great that you had progressed a lot, thanks, honey."
    new "B:pla: Mas tens razão, já está um pouco tarde, é melhor voltar e continuar noutra altura."

    # say L916 jad
    old "You have no idea of how helpful you are."
    new "B:jad: Bem, é ótimo que tenhas feito tanto progresso, obrigado, meu amor."

    # say L917 pla
    old "My pleasure."
    new "És tão doce."

    # say L918 jad
    old "You're so sweet."
    new "B:pla: Com prazer."

    # say L919 jad
    old "By the way, don't forget to bring me the bill for the materials, so, that I can reimburse you."
    new "B:jad: Tu és tão doce."

    # say L920 pla
    old "Sure thing. Well, good night Mrs. Jade."
    new "B:jad: Por acaso, não te esqueças de me trazer a fatura dos materiais, para eu te reembolsar."

    # say L921 jad
    old "Good night honey."
    new "B:pla: Claro. Então, boa noite Sra. Jade."

    # say L962 hin
    old "Well, I did, but the teacher had something important to do."
    new "B:pla: Não esperava ver-te aqui. Pensei que tinhas trabalho extra com o professor."

    # say L963 hin
    old "So, I'm free today."
    new "B:hin: Bem, fiz isso, mas o professor tinha algo importante a fazer."

    # say L964 pla
    old "Oh, cool."
    new "B:hin: Então, estou livre hoje."

    # say L965 hin
    old "Yeah, it is, and my mom is  not here, and she'll be out for a while... You know what this means, right?"
    new "B:pla: Oh, fixe."

    # say L966 pla
    old "Uhh, you want to finish the movie?"
    new "B:hin: Sim, e a minha mãe não está aqui e vai estar fora por um tempo... Sabes o que isto significa, certo?"

    # say L967 hin
    old "Hahaha, no you dummy."
    new "B:pla: Uhh, queres acabar o filme?"

    # say L968 hin
    old "I mean that we're finally alone."
    new "B:hin: Hahaha, não tu bobo."

    # say L974 hin
    old "We have some privacy to be a little... Intimate."
    new "B:hin: Quero dizer que finalmente estamos sozinhos."

    # say L975 pla
    old "Oh... A- alright."
    new "B:hin: Temos um pouco de privacidade para sermos um pouco... Íntimos."

    # say L976 hin
    old "So, what do you say? We should go up to my bedroom."
    new "B:pla: Oh... A- alright."

    # say L977 pla
    old "Uhh... Are you sure about this? I mean what if your mom comes home and sees us again?"
    new "T(pla|tu|say): Uhh... Tens a certeza disto? E se a tua mãe chegar a casa e nos ver de novo?"

    # say L979 hin
    old "Relax, she won't be home for a while. Besides, you heard what she told us, she's ok with us doing it."
    new "B:pla: Uhh... Tens a certeza disto? E se a tua mãe chegar a casa e nos ver de novo?"

    # say L980 hin
    old "And we'll be in my bedroom."
    new "B:hin: Relaxa, ela não vai estar em casa por um bom tempo. Além disso, tu ouviste o que ela nos disse, está tudo bem com ela."

    # say L981 pla
    old "I- I guess you're right."
    new "B:hin: E vamos para o meu quarto."

    # say L983 hin
    old "Stop worrying, just come with me."
    new "B:pla: I- Acho que tens razão."

    # say L991 hin
    old "I've been waiting for this for a while."
    new "B:hin: Para de te preocupares, vem comigo."

    # say L992 hin
    old "Every time we've tried to do it we've been getting interrupted."
    new "B:hin: Tenho esperado por isto há algum tempo."

    # say L993 hin
    old "I was thinking we were never going to have a chance to do it again."
    new "B:hin: Toda vez que tentamos, acabamos sendo interrompidos."

    # say L994 pla
    old "Well, we're finally alone."
    new "B:hin: Estava a pensar que nunca mais íamos ter hipótece de o fazer de novo."

    # say L995 hin
    old "Yeah, so, let's don't waste more time. I want to feel you inside."
    new "B:pla: Bem, finalmente estamos sozinhos."

    # say L1009 hin
    old "Well, I'm very happy we finally got to do it without being interrupted."
    new "B:hin: Sim, então, não vamos perder mais tempo. Quero sentir-te dentro de mim."

    # say L1010 pla
    old "Yeah, me too..."
    new "A:hin: Tu vais para casa agora?"

    # say L1011 hin
    old "Are you going home now?"
    new "A:pla: Acho que vou dar uma vista de olhos à casa de banho antes da tua mãe chegar a casa."

    # say L1012 pla
    old "I think I'll go take a look at the bathroom before your mom gets home."
    new "T(pla|tu|say): Acho que vou dar uma vista de olhos à casa de banho antes da tua mãe chegar a casa."

    # say L1013 hin
    old "Ok, then I guess I'll just stay here and organize my bedroom."
    new "B:pla: Acho que vou dar uma vista de olhos à casa de banho antes da tua mãe chegar."

    # say L1025 pla
    old "Oh! Hi Mrs. Jade."
    new "B:hin: Ok, então acho que vou ficar aqui e organizar o meu quarto."

    # say L1026 pla
    old "I didn't know you were home already."
    new "B:pla: Oh! Olá Sra. Jade."

    # say L1028 jad
    old "Hi [pla], I- I just arrived."
    new "T(jad|tu|say): Olá [pla], eu... eu acabei de chegar."

    # say L1030 pla
    old "Uhh... I did, yeah, then I ran into Hinn, and we started talking."
    new "B:jad: Vim ver o estado da casa de banho?"

    # say L1031 jad
    old "Oh, that's ok."
    new "B:pla: Uhh... Fiz isso, sim, depois encontrei-me com Hinn e começámos a conversar."

    # say L1036 pla
    old "Are you sure? I'm not really all that tired, I could just work a little on the bathroom and..."
    new "T(pla|tu|say): Tens a certeza? Não estou realmente muito cansado, podia trabalhar um pouco na casa de banho e..."

    # say L1037 jad
    old "I'm sure. I think I would like to go to bed early today, so, it's fine if you take a day free."
    new "T(jad|tu|say): Tenho a certeza. Acho que hoje prefiro ir dormir cedo, então, podes tirar o dia de folga."

    # say L1038 pla
    old "Uh, ok, sure."
    new "B:jad: Tenho a certeza. Acho que vou querer ir para a cama cedo hoje, por isso, não há problema se quiseres tirar o dia de folga."

    # say L1039 pla
    old "Then I guess I'll leave for today."
    new "B:pla: Hum, ok, claro."

    # say L1040 jad
    old "Sure honey, see you later."
    new "B:pla: Então acho que vou embora hoje."

    # say L1056 pla
    old "Oh, hi Hinn! I didn't think I'd see you here. I thought you were going to be in school."
    new "B:jad: Claro, amor, até mais."

    # say L1060 hin
    old "Well, my mom's not home right now, but you can go ahead and get started."
    new "B:pla: Uhh, yeah."

    # say L1061 hin
    old "She'll be here in no time."
    new "B:hin: Bem, a minha mãe não está em casa agora, mas podes começar já."

    # say L1063 hin
    old "Good, that way you'll finish quickly."
    new "B:hin: Ela vai chegar a qualquer momento."

    # say L1064 hin
    old "So, that we'll have time to ourselves again."
    new "B:hin: Ótimo, assim vais acabar depressa."

    # say L1098 pla
    old "I didn't know you were here Mrs. Jade."
    new "B:pla: I- I vim trabalhar na casa de banho."

    # say L1099 jad
    old "Uhh... I- it's fine, I suppose Hinn let you in while I wasn't in here, right?"
    new "B:pla: Não sabia que tu estavas aqui, Sra. Jade."

    # say L1100 pla
    old "Y- yeah, yeah, that's what happened..."
    new "B:jad: Uhh... E-eu suponho que está bem, a Hinn deve ter-te deixado entrar enquanto eu não estava aqui, certo?"

    # say L1101 jad
    old "I'm sorry it's my fault, I didn't know you were already here. You just startled me, that's all."
    new "B:pla: Y- yeah, yeah, isso é que aconteceu..."

    # say L1108 pla
    old "I- I think I should leave now."
    new "B:jad: Desculpa, foi culpa minha, não sabia que já estavas aqui. Apenas me assustaste, só isso."

    # say L1110 jad
    old "Yeah, you probably should."
    new "B:pla: I- Acho que devo ir embora agora."

    # say L1111 pla
    old "R- Right... See you later Mrs. Jade."
    new "B:jad: Sim, provavelmente deves."

    # say L1133 jad
    old "The gaul off the man!!!"
    new "B:pla: R- Right... Vejo-te mais tarde, Sra. Jade."

    # say L1134 hin
    old "I know, I know!! You don't need to keep telling me about it!"
    new "B:jad: A cara-de-pau do homem!!!"

    # say L1135 jad
    old "I just can't believe your father sometimes!!!"
    new "T(jad|tu|say): Não consigo acreditar no teu pai às vezes!!!"

    # say L1136 jad
    old "So, this is why he never had any money and he kept coming up with excuses when it came to paying the alimony!"
    new "B:jad: Não consigo acreditar no teu pai às vezes!!!"

    # say L1137 hin
    old "I know mom, I know, but again, I have nothing to do with it!!"
    new "B:jad: Então, é por isso que ele nunca teve dinheiro e continuava a inventar desculpas quando se tratava de pagar a pensão alimentar!"

    # say L1138 jad
    old "I didn't say you had to."
    new "T(jad|tu|dizes): Não disse que tinhas de."

    # say L1144 jad
    old "But I just can't believe how brazen your father is!!!"
    new "A:jad: Não só ele leva a namoradinha numa viagem cara."

    # say L1145 jad
    old "Not only does he take his little girlfriend on some expensive vacation."
    new "B:jad: Mas não consigo acreditar na audácia do teu pai!!!"

    # say L1146 jad
    old "But he's also asking her to marry him?!!!"
    new "B:jad: Não só ele leva a namorada para uma viagem cara."

    # say L1152 jad
    old "[pla], H- Hi honey."
    new "B:hin: Oh, [pla]! H- Olá, não tinha reparado que tinhas entrado."

    # say L1154 jad
    old "Well, not really."
    new "B:pla: O- olá Sra. Jade, vim trabalhar no banheiro, tudo bem?"

    # say L1155 jad
    old "I- I think I need to let my head cool down a bit. I'll just leave you two alone so you can talk."
    new "B:jad: Bem, não realmente."

    # say L1165 hin
    old "Sorry you had to see that."
    new "B:jad: Eu... Acho que preciso de deixar a minha cabeça arrefecer um bocado. Vou deixar-vos a sós para conversarem."

    # say L1167 pla
    old "It's ok. So, I take it your father has been giving you some trouble?"
    new "Tudo bem. Então, eu adivinho que o teu pai tem-te dado alguns problemas?"

    # say L1171 hin
    old "And I don't feel good either. Do you think you could come another time?"
    new "B:hin: Mas não acho que hoje seja um bom dia. Com o meu pai a agir como um idiota, a minha mãe não está com um bom humor."

    # say L1172 pla
    old "Of course, of course. Hey, don't worry about it, this is completely understandable."
    new "B:hin: E eu também não me sinto bem. Achas que podes vir noutra altura?"

    # say L1173 pla
    old "It's fine. I'll just leave, so, the two of you can rest, and I'll come back some other day."
    new "B:pla: Claro, claro. Olha, não te preocupes com isso, é completamente compreensível."

    # say L1174 hin
    old "Thank you, I'm glad you understand."
    new "B:pla: Tudo bem. Vou embora, assim vocês podem descansar, e eu volto noutro dia."

    # say L1176 pla
    old "Alright, then see you later."
    new "B:hin: Obrigado, fico contente que compreendas."

    # say L1206 jad
    old "Oh, ok, that's somewhat of a relief."
    new "B:pla: Sim, sim, não te preocupes. É que um dos canos partiu e eu fiquei encharcado de água. Mas estou bem."

    # say L1207 jad
    old "Come with me, let's go to the other bathroom, so, you can towel dry."
    new "B:jad: Oh, ok, isso é um alívio."

    # say L1208 pla
    old "Oh, don't worry, I'm fine really."
    new "B:jad: Vem comigo, vamos à outra casa de banho, assim podes secar-te com uma toalha."

    # say L1209 jad
    old "Don't be silly, you don't want to catch a cold. Come with me."
    new "B:pla: Oh, não te preocupes, estou bem mesmo."

    # say L1222 jad
    old "Okay, let me give you a hand with that."
    new "B:jad: Não sejas parvo, não queres apanhar um resfriado. Vem comigo."

    # say L1240 pla
    old "Uhh, I- I'm sorry Mrs. Jade, I don't know what to say. It's just that..."
    new "T: Uh, eu... eu sinto muito, Sra. Jade, não sei o que dizer. É que..."

    # say L1241 jad
    old "It's ok, it's ok, don't worry. You're a young man, after all."
    new "B:pla: Uhh, desculpa, Sra. Jade, não sei o que dizer. É que..."

    # say L1243 jad
    old "I- I'll take it as a compliment."
    new "B:jad: Tudo bem, tudo bem, não te preocupes. Afinal, és um jovem."

    # say L1245 pla
    old "S- sure, t- thank you."
    new "T: S-sim, o-obrigado. Agora, porque não tiras essas calças? Vou pô-las na secadora."

    # say L1246 jad
    old "Now, why don't you take those pants off? So, I'll throw them in the dryer."
    new "B:pla: C- claro, m- muito obrigado."

    # say L1248 pla
    old "Uhh... Alright."
    new "B:jad: Agora, porque não tiras essas calças? Vou atirá-las à máquina de secar."

    # say L1254 jad
    old "(What?! He's not wearing anything!!)"
    new "T(jad|tu|say): (Que?! Ele não está a usar nada!!)"

    # say L1255 jad
    old "(Does he just go outside without underwear on?)"
    new "B:jad: (O quê?! Ele não está a usar nada!!)"

    # say L1256 jad
    old "(But I must say, it's so... big! Is that what my daughters been putting in her?)"
    new "B:jad: (Ele sai para a rua sem cuecas?)"

    # say L1257 pla
    old "Uhh... Mrs. Jade?"
    new "B:jad: (Mas tenho que dizer, é tão... grande! É isso que a minha filha tem andado a meter dentro de si?)"

    # say L1262 jad
    old "What? Oh, right!"
    new "B:pla: Uhh... Sra. Jade?"

    # say L1263 jad
    old "Just wait here, I'm going to put this on the dryer and see if there's a pajama bottom or something that you can use."
    new "B:jad: O quê? Ah, certo!"

    # say L1281 hin
    old "Fine. Hey mom, are you going to be there much longer?"
    new "B:jad: Uhh... O- olá querida! Como foi a escola?"

    # say L1282 hin
    old "I kinda need to use the bathroom."
    new "B:hin: Tudo bem. Olá mãe, vais estar lá muito mais tempo?"

    # say L1289 jad
    old "I- I'm taking a shower and.... Uhh, I just got in. Sorry honey."
    new "B:jad: Uhhh! Vou estar aqui um bocado, querida."

    # say L1290 hin
    old "Oh, but I only need to use the toilet, so, it should be fine."
    new "B:jad: I- Estou a tomar banho e.... Uh, acabei de entrar. Desculpa, querida."

    # say L1291 jad
    old "Uhh... Uhhh..."
    new "B:hin: Oh, mas eu só preciso de ir à casa de banho, então, deve ser seguro."

    # say L1296 jad
    old "{i}If she sees you here she'll flip her mind.{/i}"
    new "B:jad: {i}Calma! O que vamos fazer?!!{/i}"

    # say L1297 jad
    old "{i}And with how difficult it's been to deal with her lately.{/i}"
    new "B:jad: {i}Se ela te ver aqui, vai pirar. {/i}"

    # say L1298 jad
    old "{i}We need to hide you!{/i}"
    new "B:jad: {i}E com o quão difícil tem sido lidar com ela ultimamente.{/i}"

    # say L1299 jad
    old "{i}Especially because you're naked from the waist down!{/i}"
    new "B:jad: {i}Precisamos de esconder-te!{/i}"

    # say L1300 pla
    old "{i}I don't really know where I could hide Mrs. Jade.{/i}"
    new "B:jad: {i}Especialmente porque estás nu da cintura para baixo!{/i}"

    # say L1305 hin
    old "Ughh, come on mom, you can just keep taking your shower."
    new "B:jad: Uhh, sim, sim, d- dá-me um segundo, querida."

    # say L1306 jad
    old "J- just give me a second!"
    new "B:hin: Ughh, vamos lá mãe, podes continuar a tomar o teu duche."

    # say L1332 hin
    old "Hmm, that makes sense."
    new "B:jad: Uhh... N- não, ele não. Acho que ele deve estar muito ocupado com a escola."

    # say L1333 jad
    old "He's very busy, so, we should just let him come when he can find the time."
    new "T(jad|tu|say): Ele está muito ocupado, então, devemos deixá-lo vir quando puder encontrar tempo."

    # say L1340 jad
    old "(And still hard... Oh my God...)"
    new "B:jad: (Pelo amor de Deus! É enorme!)"

    # say L1342 jad
    old "Uhh, w- what? With Hiashi?"
    new "B:jad: (E ainda duro... Meu Deus...)"

    # say L1343 jad
    old "I- I haven't."
    new "B:jad: Uhh, e- então? Com Hiashi?"

    # say L1344 jad
    old "(Mmm... Damn, I feel so horny all of a sudden… I haven't been in an intimate situation like this in years...)"
    new "B:jad: Eu... eu não."

    # say L1345 jad
    old "I- I called him but he didn't answer."
    new "B:jad: (Mmm... Droga, sinto-me tão excitada de repente… Não estou numa situação íntima assim há anos...)"

    # say L1356 jad
    old "Listen, I think it's best if you leave now. Here are your pants."
    new "B:jad: I- I chamei-o, mas ele não atendeu."

    # say L1362 jad
    old "I'm sorry, I wasn't able to dry them for you."
    new "B:jad: Ouve, acho melhor tu ires embora agora. Aqui estão as tuas calças."

    # say L1363 jad
    old "But Hinn might come back, and this situation is already difficult to explain."
    new "B:jad: Desculpa, não consegui secá-los para ti."

    # say L1364 pla
    old "It's ok, I'll just go straight home."
    new "B:jad: Mas o Hinn pode voltar, e esta situação já é difícil de explicar."

    # say L1365 jad
    old "Yeah, that's the best idea."
    new "B:pla: Tudo bem, vou direto para casa."

    # say L1366 pla
    old "Ok, see you another time Mrs. Jade. I'll come back later to keep working on the repairs"
    new "T(pla|tu|say): Ok, vejo-te noutra altura, Sra. Jade. Volto mais tarde para continuar a trabalhar nas reparações."

    # say L1385 jad
    old "That's good."
    new "Ouç, fico contente que tenhas vindo."

    # say L1386 jad
    old "Listen, I'm glad you came."
    new "T(jad|tu|diz): Ouve, fico contente que tenhas vindo."

    # say L1387 pla
    old "Uhh, really? Why?"
    new "A:jad: Bem, queria falar contigo. Sobre o que aconteceu da última vez."

    # say L1388 jad
    old "Well, I wanted to talk to you. About what happened last time."
    new "B:pla: Uhh, realmente? Porquê?"

    # say L1393 jad
    old "I'm so sorry [pla], I don't know what got into me."
    new "T(jad|tu|say): Desculpa tanto [pla], não sei o que me deu. É que tenho andado tão stressado com tantas coisas."

    # say L1396 jad
    old "You know, dealing with my husband's behavior, and Hinn's not been easy either."
    new "B:jad: É que tenho andado tão stressada com tantas coisas."

    # say L1398 jad
    old "So, I'm sorry, very, very sorry."
    new "B:jad: Sabes, lidar com o comportamento do meu marido, e o Hinn também não tem sido fácil."

    # say L1399 pla
    old "I- it's ok, Mrs. Jade. Really, don't worry."
    new "B:jad: Então, peço desculpa, muito, muito desculpa."

    # say L1400 pla
    old "I understand, it was an accident. It's fine."
    new "T(pla|tu|dizes): Compreendo, foi um acidente. Está tudo bem."

    # say L1402 pla
    old "Yes, I know that you and Hinn are going through a lot lately."
    new "B:pla: Entendo, foi um acidente. Tudo bem."

    # say L1403 pla
    old "Uhh, and yesterday, it was mostly a misunderstanding that escalated quickly."
    new "B:pla: Sim, sei que tu e Hinn têm passado por momentos difíceis recentemente."

    # say L1407 pla
    old "So, I'll just go to work in the bathroom. I think it shouldn't be long before I finish."
    new "B:pla: Obrigado por dizer isso, Sra. Jade."

    # say L1408 jad
    old "Sure, sure, also, thanks a lot for doing that."
    new "B:pla: Vou trabalhar no banheiro. Acho que não devo demorar muito para terminar."

    # say L1409 pla
    old "It's not a problem."
    new "Olá! Alô? Hinn? Sra. Jade?"

    # say L1423 pla
    old "Hi! Hello? Hinn? Mrs. Jade?"
    new "B:pla: Não é problema."

    # say L1424 pla
    old "That's weird, they're usually here in the afternoon."
    new "Olá?!"

    # say L1425 pla
    old "Hello?!"
    new "B:pla: É estranho, eles costumam estar aqui à tarde."

    # say L1433 pla
    old "Hinn? Mrs. Jade? Anyone here?"
    new "B:pla: Olá?!"

    # say L1434 pla
    old "This is odd."
    new "B:pla: Hinn? Sra. Jade? Alguém aqui?"

    # say L1435 pla
    old "I guess they went out."
    new "T(pla|tu|say): Acho que saíram."

    # say L1436 pla
    old "I suppose there's no problem if I go up and work on the bathroom."
    new "B:pla: Acho que saíram."

    # say L1461 pla
    old "I was going to work in the bathroom, but, I think I should just leave."
    new "B: pla: Desculpa! Não vi nada, estava à tua procura e abri a porta."

    # say L1469 jad
    old "Uhh, this is my fault, I'd forgotten you were coming today."
    new "B:pla: Ia trabalhar na casa de banho, mas acho que devo ir-me embora."

    # say L1470 jad
    old "So, I'll just dress up and you can get to work on the repairs."
    new "B:jad: Uhh, isto é culpa minha, tinha-me esquecido que tu vinhas hoje."

    # say L1471 jad
    old "Can we just pretend this never happened?"
    new "B:jad: Então, eu vou vestir-me e tu podes começar a fazer os reparos."

    # say L1472 pla
    old "Uhhh, sure."
    new "B:jad: Podemos fingir que isto nunca aconteceu?"

    # say L1480 jad
    old "(My God, he has another boner, and it's so big.)"
    new "B:pla: Uhhh, claro."

    # say L1481 pla
    old "I- I think I'll start working on the bathroom, then."
    new "B:jad: (Meu Deus, ele tem outra ereção, e é tão grande.)"

    # say L1482 jad
    old "R- right, right. Well, you know where everything is."
    new "B:pla: V- vou começar a trabalhar na casa de banho, então."

    # say L1492 pla
    old "Wow, that was crazy..."
    new "B:jad: C- certo, certo. Bem, tu sabes onde tudo está."

    # say L1493 pla
    old "Thank God, she is very calm and reasonable."
    new "B:pla: Uau, isso foi louco..."

    # say L1494 pla
    old "Anyway, I better finish this as soon as possible."
    new "B:gra: Graças a Deus, ela está muito calma e razoável."

    # say L1507 pla
    old "Oh, hi Mrs. Jade, yeah, I'm done for today."
    new "B:pla: De qualquer forma, melhor acabar isto o mais rápido possível."

    # say L1508 pla
    old "It's almost done, I don't think it will be too long until I'm finished with the repairs."
    new "B:pla: Oh, olá Sra. Jade, sim, já terminei para hoje."

    # say L1509 jad
    old "That's great honey, thank you."
    new "B:pla: Está quase feito, não acho que demore muito até terminar os reparos."

    # say L1510 jad
    old "And listen, about what you saw me doing today."
    new "B:jad: Isso é ótimo, meu amor, obrigado."

    # say L1511 jad
    old "I'm sorry, I wouldn't have wanted you to see that. It must've been very awkward."
    new "B:jad: E ouve, sobre o que viste hoje."

    # say L1513 pla
    old "No, no, I'm the one who should be apologizing, this is your house after all."
    new "T(pla|tu|say): Não, não, devo pedir desculpa eu, afinal esta é a tua casa."

    # say L1514 pla
    old "I shouldn't have come into your bedroom without knocking."
    new "B: pla: Não, não, devo ser eu a pedir desculpa, afinal esta é a tua casa."

    # say L1515 jad
    old "Well, anyway, I'm sorry you had to see that."
    new "B:pla: Não devia ter entrado no teu quarto sem bater."

    # say L1516 jad
    old "I'm sure it must not be enjoyable to see an older woman in those... Circumstances."
    new "B:jad: Bem, de qualquer forma, sinto muito que tenhas tido de ver isso."

    # say L1518 pla
    old "Ohh, of course not, you're a very beautiful woman."
    new "B:jad: Tenho a certeza de que não deve ser agradável ver uma mulher mais velha nessas... circunstâncias."

    # say L1520 pla
    old "I- I mean...!"
    new "B:pla: Ohh, claro que não, tu és uma mulher muito bonita."

    # say L1524 pla
    old "Well, I think I should get going."
    new "B:pla: Oh, ok."

    # say L1525 jad
    old "Yeah, it's getting a little late."
    new "B:pla: Bem, acho que devo ir embora."

    # say L1526 pla
    old "Have a good night Mrs. Jade."
    new "B:jad: Sim, já está a ficar um pouco tarde."

    # say L1527 jad
    old "You too darling."
    new "B:pla: Boa noite, Sra. Jade."

    # say L1546 pla
    old "Oh, hi Mrs. Jade, Mrs. White."
    new "B:jad: Tu também, querido."

    # say L1553 whi
    old "Uh huh."
    new "B:jad: Bem, tu te lembras que te disse que havia alguns danos no meu banheiro?"

    # say L1557 whi
    old "Uhmm."
    new "B:jad: Ele fez. Sabes que com tudo o que tem acontecido com Hiashi as coisas têm estado um pouco apertadas por aqui."

    # say L1561 whi
    old "Oh, you don't have to tell me too much about it."
    new "B:jad: É um rapaz tão bem-parecido."

    # say L1565 jad
    old "Sure honey, you know where everything is."
    new "A:pla: Com a tua permissão, até mais tarde, Sra. White e Sra. Jade."

    # say L1566 pla
    old "With your permission, see you later, Mrs. White and Mrs Jade."
    new "B:jad: Claro, meu amor, tu sabes onde tudo está."

    # say L1576 whi
    old "So, tell me, what came of that whole business with Hiashi? Did you get him to pay your alimony?"
    new "B:pla: Com a sua permissão, até mais tarde, Sra. White e Sra. Jade."

    # say L1577 jad
    old "Ha! Not only he didn't pay, but he also took that little bimbo he calls his girlfriend on vacation."
    new "B:whi: Então, conta-me, o que aconteceu com toda aquela história com Hiashi? Conseguiste que ele te pagasse a pensão de alimentos?"

    # say L1578 whi
    old "No way!"
    new "Não acredito! Estás a brincar."

    # say L1579 whi
    old "You're joking."
    new "A:jad: Se fosse só isso, mas não é tudo. Aparentemente, enquanto estavam lá."

    # say L1581 jad
    old "I wish, but that's not all of it. Apparently, while they were there."
    new "T(jad|tu|say): Se calhar, mas não é só isso. Parece que, enquanto estavam lá, ele pediu-lhe em casamento!"

    # say L1582 jad
    old "He asked her to marry him!"
    new "B:jad: Eu queria, mas não é só isso. Aparentemente, enquanto estavam lá."

    # say L1583 whi
    old "Oh my God! I can't believe it!"
    new "B:jad: Ele pediu-lhe que se casasse com ele!"

    # say L1584 whi
    old "I remember he was a pig, but I didn't know just how low he could sink."
    new "B:whi: Meu Deus! Não posso acreditar!"

    # say L1585 jad
    old "Ugh, Tell me about it!"
    new "T(jad|tu|say): Ugh, Conta-me tudo!"

    # say L1586 jad
    old "After he posted the photos with the engagement ring, he realized that they were public, so, he took them down."
    new "T(jad|tu|diz): Depois de publicar as fotos com o anel de noivado, ele percebeu que eram públicas, por isso, as removeu."

    # say L1587 jad
    old "But by that point, it was already too late. We had already seen them."
    new "B:jad: Depois de ter partilhado as fotos com o anel de noivado, apercebeu-se de que eram públicas, por isso, apagou-as."

    # say L1588 whi
    old "I just can't believe how irresponsible that man is."
    new "B:jad: Mas nessa altura já era tarde demais. Nós já os tínhamos visto."

    # say L1591 jad
    old "And that's not all, I've been having terrible migraines, and insomnia because of it."
    new "B:jad: Mas não queria acreditar que ele fosse tão baixo. É sempre a mesma história desapontante quando se trata dele."

    # say L1592 jad
    old "Not to mention that Hinn's been a real handful as of late. I swear to God, I don't even know how to talk to her anymore."
    new "B:jad: E isso não é tudo, tenho tido dores de cabeça terríveis e insónia por causa disso."

    # say L1593 jad
    old "The whole thing has culminated in me being in constant panic and with my emotions all over the place!"
    new "B:jad: Nem falo que a Hinn tem sido uma autêntica dor de cabeça ultimamente. Juro por Deus, nem sei como falar com ela."

    # say L1594 jad
    old "I've been thinking that maybe I should go to a psychiatrist. Maybe I have some sort of anxiety, you know?"
    new "B:jad: Tudo isto acabou por me deixar em pânico constante e com as emoções à flor da pele!"

    # say L1595 whi
    old "Well... I guess you could call it that..."
    new "B:jad: Tenho pensado que talvez devesse ir a um psiquiatra. Talvez tenha algum tipo de ansiedade, sabes?"

    # say L1596 jad
    old "Well, duh, that's the name of it. What else could it be?"
    new "B:whi: Bem... Acho que podes chamar-lhe isso..."

    # say L1597 whi
    old "For one thing, a lack of sex."
    new "A:jad: Um quê?!"

    # say L1599 jad
    old "A what?!"
    new "B:whi: Para começar, uma falta de sexo."

    # say L1600 whi
    old "You heard me, it sounds to me that what you have is a typical case of not fucking."
    new "B:jad: O quê?!"

    # say L1602 whi
    old "Hey, I've been there myself, so, I know the symptoms."
    new "B:whi: Ouvi-te, parece-me que o que tens é um caso típico de falta de sexo."

    # say L1603 whi
    old "You've been under a lot of stress lately, all of that accumulates in your body."
    new "B:whi: Olá, já passei por isso, então, conheço os sintomas."

    # say L1604 whi
    old "And since you're not sexually active with anybody you just get anxious."
    new "B:whi: Tu tens estado muito stressado recentemente, tudo isso se acumula no teu corpo."

    # say L1606 jad
    old "Oh, come on! Be serious please..."
    new "B:whi: E como tu não tens atividade sexual com ninguém, ficas ansiosa."

    # say L1608 whi
    old "I am!"
    new "A:whi: Escuta, tu não estás a ter sexo, mas ainda precisas de o fazer."

    # say L1609 whi
    old "Listen, you're not having sex, but you still need to do it."
    new "B:whi: Estou!"

    # say L1610 whi
    old "Add to that all of the other problems that you have to deal with."
    new "B:whi: Escuta, tu não estás a ter sexo, mas ainda precisas de o fazer."

    # say L1611 whi
    old "And you're a ticking time bomb!"
    new "B:whi: E adiciona a isso todos os outros problemas com que tens de lidar."

    # say L1612 whi
    old "You're repressed Jade, and believe me, that's not good for you."
    new "B:whi: E tu és uma bomba-relógio!"

    # say L1613 whi
    old "It's clear to me that what you need is a good fucking. That'll help you."
    new "B:whi: Tu és reprimida, Jade, e acredita em mim, isso não te faz bem."

    # say L1614 jad
    old "Hahaha, yeah right. Who am I going to do it with?"
    new "B:whi: É claro que o que tu precisas é de uma boa transa. Isso vai ajudar-te."

    # say L1615 jad
    old "I'm an old divorced woman."
    new "B:jad: Hahaha, claro. Com quem é que eu vou fazer isso?"

    # say L1616 jad
    old "Who's going to want to be with me?"
    new "B:jad: Sou uma mulher divorciada e mais velha."

    # say L1617 whi
    old "Oh! You know you're pretty. Any man would give an arm and a leg to have a chance to jump into your bed."
    new "B:jad: Quem é que vai querer estar comigo?"

    # say L1618 jad
    old "Yeah right."
    new "B:whi: Oh! Tu sabes que és bonita. Qualquer homem daria um braço e uma perna para ter a oportunidade de subir para a tua cama."

    # say L1620 whi
    old "Listen, girl, I'm not saying it just to mess with you. You need physical intimacy, it's good for you."
    new "T(whi|formal|say): Escuta, rapariga, não estou a dizer isto só para te chatear. Precisas de intimidade física, é bom para ti."

    # say L1621 whi
    old "If you don't do something about it you'll just start getting depressed and maybe even having anxiety attacks!"
    new "B:whi: Escuta, rapariga, não estou a dizer isto só para te chatear. Precisas de intimidade física, é bom para ti."

    # say L1622 whi
    old "You need to release all of those things you're holding in."
    new "B:whi: Se não fizeres nada vais começar a ficar deprimido e talvez até ter ataques de ansiedade!"

    # say L1624 jad
    old "Hmm, maybe you're right..."
    new "T(jad|tu|say): Hmm, talvez tenhas razão..."

    # say L1626 jad
    old "But even so? Who would I even be intimate with?"
    new "B:jad: Hmm, talvez tenhas razão..."

    # say L1640 pla
    old "Ok Mrs. Jade, I've  finished for today."
    new "B:jad: Mas mesmo assim? Com quem é que eu seria íntima?"

    # say L1642 jad
    old "Thank you, honey, you were done very quickly!"
    new "B:pla: Ok, Sra. Jade, já terminei por hoje."

    # say L1643 pla
    old "Yeah, I would've liked to do some more, but sadly I'm busy with some school work, so, I'm gonna have to go for today."
    new "B:jad: Obrigada, querido, foste muito rápido!"

    # say L1644 jad
    old "That's ok honey, see you another time."
    new "B:pla: Sim, gostava de fazer mais, mas infelizmente tenho trabalhos da escola, por isso vou ter de ir embora hoje."

    # say L1647 pla
    old "Yeah, haha... Maybe I'll go later."
    new "B:whi: Posso pensar em uma ou duas coisas que tu podes ajudar-me a arranjar."

    # say L1648 pla
    old "Well, hope to see you soon. Bye."
    new "B:pla: Yeah, haha... Talvez eu vá mais tarde."

    # say L1650 jad
    old "Bye honey."
    new "B:pla: Espero ver-te em breve. Adeus."

    # say L1652 whi
    old "See you later sweetie."
    new "A:jad: Então, do que estávamos a falar?"

    # say L1661 jad
    old "So, what were we talking about?"
    new "B:whi: Até logo, querida."

    # say L1662 whi
    old "We were saying that you need to fuck!"
    new "A:jad: Ah, certo, isso..."

    # say L1663 jad
    old "Ah, right, that..."
    new "B:whi: Estávamos a dizer que tu precisas de foder!"

    # say L1664 jad
    old "But you know, it's not as if I'm not doing anything, I masturbate often, and I feel like that's good."
    new "B:jad: Ah, certo, isso..."

    # say L1665 whi
    old "That won't be enough. Believe me, I have some experience with this."
    new "B:jad: Mas sabes, não é como se eu não fizesse nada, masturbo-me frequentemente e sinto que isso é bom."

    # say L1666 whi
    old "What you need is a big, hard cock to ravage you."
    new "B:whi: Isso não vai ser suficiente. Acredita em mim, tenho alguma experiência com isso."

    # say L1668 jad
    old "So classy..."
    new "B:whi: O que precisas é de um pau grande e duro para te devastar."

    # say L1670 jad
    old "But then again, who's it going to be? I don't know anybody, and I'm too busy, and frankly tired, to go out looking for dates."
    new "B:jad: Tão elegante..."

    # say L1672 whi
    old "Also, not just anybody can do it. It has to be someone that can rock you."
    new "B:jad: Mas então, quem vai ser? Não conheço ninguém e estou demasiado ocupado e, francamente, cansado para sair à procura de encontros."

    # say L1676 whi
    old "Well, I'll tell you what, I think I know just the right guy to do it!"
    new "B:whi: Além disso, não é qualquer um que pode fazer. Tem de ser alguém que te faça vibrar."

    # say L1677 jad
    old "You do? Do we have any common friends that I don't know about?"
    new "B:whi: Bem, vou-te dizer, acho que conheço o homem certo para isso!"

    # say L1680 whi
    old "Listen, what you don't need is some old guy who's just going to get tired after a couple of pumps."
    new "B:jad: Tu fazes? Temos amigos em comum que eu não conheço?"

    # say L1681 whi
    old "You need a young, healthy stallion that's going to pump you full, and it's going to make you scream with his big dick."
    new "B:whi: Ouve, o que tu não precisas é de um velho que vai ficar cansado depois de algumas estocadas."

    # say L1682 jad
    old "Hahaha, what are you saying?"
    new "B:whi: Precisas de um jovem e saudável garanhão que te encha e te faça gritar com o seu pénis grande."

    # say L1683 jad
    old "Ok, let's say that's what I need. Where am I going to find this young stallion that's going to do that to me?"
    new "B:jad: Hahaha, o que estás a dizer?"

    # say L1684 whi
    old "Baby, you've already met him!"
    new "A:jad: Eu já conheci?"

    # say L1686 jad
    old "I have?"
    new "T(jad|tu|say): Tenho?"

    # say L1687 whi
    old "Well of course! He's always here at your house!"
    new "B:jad: Tenho?"

    # say L1691 whi
    old "He's young, he's healthy, he's a very good kid."
    new "E tem alguma experiência."

    # say L1692 whi
    old "And he has some experience."
    new "B:whi: Ele é jovem, saudável, é um miúdo muito bom."

    # say L1693 whi
    old "He's just what you need!"
    new "A:jad: Claro! Como se!"

    # say L1694 jad
    old "Yeah right! As if!"
    new "B:whi: É exactamente o que precisas!"

    # say L1696 whi
    old "Oh my God! Why not?!"
    new "A:jad: Bem, para começar, ele está na cama com a minha filha!"

    # say L1697 jad
    old "Well, for one thing, he's actually having sex with my daughter!"
    new "B:whi: Oh my God! Porquê não?!"

    # say L1698 whi
    old "So, are they officially dating?"
    new "B:jad: Bem, para começar, ele está a ter relações sexuais com a minha filha!"

    # say L1699 jad
    old "Well, it's complicated, it's one of those new things the kids are doing these days."
    new "B:whi: Então, eles estão oficialmente a namorar?"

    # say L1700 jad
    old "You know, having sex without an official relationship... I honestly don't understand."
    new "B:jad: Bem, é complicado, é uma dessas novas coisas que os miúdos fazem hoje em dia."

    # say L1701 whi
    old "Then there's no problem!"
    new "B:jad: Sabes, ter relações sem um relacionamento oficial... Honestamente, não percebo."

    # say L1702 whi
    old "Of course you couldn't tell Hinn, but that's not too much of a big deal."
    new "B:whi: Então não há problema!"

    # say L1703 jad
    old "That's not all of it!"
    new "T(jad|tu|say): Não é só isso!"

    # say L1704 whi
    old "It isn't? What else then?"
    new "A:jad: Ele é muito novo..."

    # say L1705 jad
    old "He's too young..."
    new "B:whi: Não é? O que mais então?"

    # say L1706 jad
    old "He could be my son!"
    new "B:jad: Ele é muito novo..."

    # say L1707 whi
    old "Oh please! So what? Why do you think Hiashi is dating that nineteen-year-old hussy?"
    new "B:jad: Ele poderia ser o meu filho!"

    # say L1709 whi
    old "It's because the sex it's really, really good, and she helps him feel good."
    new "B:whi: Oh, por favor! E daí? Porque é que achas que o Hiashi está a namorar aquela miúda de dezanove anos?"

    # say L1710 whi
    old "Also, you can use this as a chance to get back at that pig of your ex-husband's for what he's doing."
    new "B:whi: É porque o sexo é realmente, realmente bom, e ela ajuda-o a sentir-se bem."

    # say L1711 jad
    old "Hmm, I don't know... That would be really inappropriate."
    new "B:whi: Além disso, podes aproveitar esta oportunidade para te vingares daquele porco do teu ex-marido pelo que ele está a fazer."

    # say L1712 whi
    old "Oh! Stop acting as if I'm saying something crazy."
    new "A:jad: Não estás a ser?"

    # say L1713 jad
    old "Aren't you?"
    new "B:whi: Oh! Pára de agir como se eu estivesse a dizer algo louco."

    # say L1714 whi
    old "Please! With all of the time that he's been in here."
    new "A:whi: Podes dizer-me honestamente que nunca pensaste em ter o teu caminho com ele?"

    # say L1716 whi
    old "Can you honestly tell me that you've never thought about having your way with him?"
    new "B:whi: Por favor! Com todo o tempo que ele tem passado aqui."

    # say L1717 whi
    old "Or him having his way with you. Whichever way you prefer."
    new "B:whi: Podes honestamente dizer-me que nunca pensaste em ter o teu caminho com ele?"

    # say L1718 jad
    old "Uhhh."
    new "B:whi: Ou ele ter o seu caminho contigo. De qualquer maneira que prefiras."

    # say L1720 whi
    old "Wait! Wait a minute!"
    new "B:jad: Uhhh."

    # say L1721 whi
    old "Don't tell me you already did something with him!"
    new "B:whi: Espera! Espera um momento!"

    # say L1722 jad
    old "No, no, no, no!"
    new "B:whi: Não me digas que já fizeste algo com ele!"

    # say L1723 jad
    old "Nothing like what you're thinking."
    new "B:jad: Não, não, não, não!"

    # say L1725 whi
    old "But you did do something didn't you?"
    new "B:jad: Nem penses nisso."

    # say L1726 jad
    old "You're unbelievable."
    new "T(jad|tu|dizes): Tu és incrível."

    # say L1727 jad
    old "Ok, the other day as he was doing something in the bathroom one of the pipes broke, and his pants got wet."
    new "T(jad|tu|dizes): Ok, na outra dia enquanto ele estava a fazer algo na casa de banho, uma das canalizações partiu e as calças dele ficaram molhadas."

    # say L1731 jad
    old "So, I told him that maybe he should take them off just so that I could throw them in the dryer."
    new "B:jad: O outro dia, enquanto ele estava a fazer algo na casa de banho, uma das canalizações partiu e as calças dele ficaram molhadas."

    # say L1732 whi
    old "I like where this is going."
    new "A:jad: Bem, a questão é que... Por alguma razão, ele estava com uma ereção e não estava a usar calças interiores."

    # say L1734 jad
    old "Well, the thing is that... For some reason, he had a boner, and wasn't wearing drawls."
    new "B:whi: Gosto de onde isto está a ir."

    # say L1736 whi
    old "Oh my God and you saw his boner?!"
    new "B:jad: Bem, a coisa é que... Por alguma razão, ele tinha uma ereção e não estava a usar calças interior."

    # say L1737 whi
    old "Hahaha, this is great! It was huge wasn't it?"
    new "B:whi: Meu Deus, e tu viste a ereção dele?!"

    # say L1738 jad
    old "You're terrible, you know that?"
    new "B:whi: Hahaha, isto foi ótimo! Era enorme, não era?"

    # say L1739 jad
    old "... But yes, he was very big. Like, very, very big."
    new "B:jad: Tu és terrível, sabias?"

    # say L1740 jad
    old "But that's it, nothing else happened."
    new "Mas isso, nada mais aconteceu."

    # say L1741 jad
    old "At all..."
    new "B:jad: Mas foi só isso, nada mais aconteceu."

    # say L1742 whi
    old "It doesn't matter, this is great!"
    new "B:jad: De todo..."

    # say L1745 whi
    old "Don't you see? He got a boner because of you! He already thinks you're hot!"
    new "B:whi: Não importa, isto é ótimo!"

    # say L1746 whi
    old "But that kid's too timid to do anything, he won't make a move unless he thinks you want it too."
    new "B:whi: Não vês? Ele ficou com uma ereção por tua causa! Ele já acha que és gira!"

    # say L1747 whi
    old "But that's not a problem, I can deal with that."
    new "B:whi: Mas esse miúdo é demasiado tímido para fazer qualquer coisa, ele não fará nada a menos que pense que tu também queres."

    # say L1748 jad
    old "Wait! What are you going to do?!"
    new "B:whi: Mas isso não é problema, eu consigo lidar com isso."

    # say L1750 whi
    old "Don't worry, I won't do anything you don't want."
    new "A:jad: Espera, não faças nada de estúpido."

    # say L1751 jad
    old "Wait, don't do anything dumb."
    new "B:whi: Não te preocupes, não vou fazer nada que tu não queiras."

    # say L1752 whi
    old "Me? I'll just take care of this for you, that's all."
    new "B:jad: Espera, não faças nada de estúpido."

    # say L1753 whi
    old "And I better leave before you change your mind."
    new "B:whi: Eu? Eu vou apenas cuidar disto para ti, só isso."

    # say L1769 jad
    old "Oh my God, what did I get myself into?"
    new "B:whi: E melhor eu ir antes que tu mudes de ideias."

    # say L1791 mo1
    old "Sweetie, Mrs. White's outside, she says she has something to talk to you about."
    new "Ela quer falar contigo?"

    # say L1792 pla
    old "She wants to talk to me?"
    new "B:mo1: Querida, a Sra. White está lá fora, diz que tem algo para falar contigo."

    # say L1793 mo1
    old "Yes, she says it's something about your friend Mike."
    new "B:pla: Ela quer falar comigo?"

    # say L1794 pla
    old "I see, well, I'll be right out."
    new "B:mo1: Sim, ela diz que é algo sobre o teu amigo Mike."

    # say L1795 mo1
    old "Ok, honey."
    new "A:pla: Olá, Sra. White, tudo bem com o Mike?"

    # say L1805 pla
    old "Hi Mrs. White, is everything alright with Mike?"
    new "B:mo1: Ok, querida."

    # say L1806 whi
    old "Hi honey, yeah, yeah, don't worry. It's just that I need you to come with me to my house for a second."
    new "B:pla: Olá Sra. White, tudo bem com o Mike?"

    # say L1807 whi
    old "There's something I want you to talk about with Mike."
    new "B:whi: Olá querida, sim, sim, não te preocupes. É só preciso que venhas comigo à minha casa por um momento."

    # say L1808 pla
    old "Me? Is it something serious?"
    new "B:whi: Há algo de que quero que fale com o Mike."

    # say L1809 whi
    old "Not really, but it's more of a guy thing, so, I think it would be better if he hears it from another man."
    new "B:pla: Eu? É algo sério?"

    # say L1810 pla
    old "Oh, ok, I guess that's fine. Sure, I'll come with you."
    new "B:whi: Não realmente, mas é mais uma coisa de rapazes, por isso acho que é melhor ele ouvir de outro homem."

    # say L1817 pla
    old "So, it's Mike in his bedroom?"
    new "B:pla: Oh, ok, acho que isso está bem. Claro, vou contigo."

    # say L1818 whi
    old "No, actually, I must admit I lied to you, he's not in the house, and he won't be for a while."
    new "B:pla: Então, é o Mike no quarto dele?"

    # say L1819 pla
    old "Then how am I supposed to talk to him?"
    new "B:whi: Não, na verdade, tenho de admitir que menti, ele não está em casa e não vai estar por um tempo."

    # say L1822 whi
    old "No, the person I want you to help is a friend of mine, who needs something from you."
    new "Quem é?"

    # say L1823 pla
    old "Who is it?"
    new "B:whi: Não, a pessoa que quero que ajudes é uma amiga minha, que precisa de algo de ti."

    # say L1824 whi
    old "Well honey, it's Jade, there's something that she needs from you."
    new "B:pla: Quem é?"

    # say L1825 pla
    old "Did anything happen to her?"
    new "B:whi: Bem querida, é a Jade, ela precisa de algo de ti."

    # say L1827 whi
    old "Not yet."
    new "B:pla: Aconteceu algo a ela?"

    # say L1828 pla
    old "I have to tell you, Mrs. White, you're not really making a lot of sense here, you know?"
    new "T: Tu sabes, Sra. White, não estás a fazer muito sentido aqui."

    # say L1829 whi
    old "That's because I haven't really told you anything."
    new "B:pla: Tenho de te dizer, Sra. White, que não estás a fazer muito sentido aqui, sabes?"

    # say L1832 whi
    old "Just as you hear it, you are going to help Jade by fucking her."
    new "B:pla: O quê?!"

    # say L1833 pla
    old "Why would I do that?"
    new "B:whi: Como ouves, vais ajudar a Jade a fodê-la."

    # say L1835 whi
    old "Well, there's a lot to explain, but basically, Jade's been under a lot of pressure."
    new "B:pla: Porque é que eu faria isso?"

    # say L1836 whi
    old "She wouldn't admit it, but she's repressed. So, she really needs to release that, you know what I mean?"
    new "B:whi: Bem, há muito para explicar, mas basicamente, a Jade tem estado sob muita pressão."

    # say L1837 whi
    old "And since I know how gifted you are in that regard, I thought that you're the right person to help her."
    new "B:whi: Ela não admitiria, mas está reprimida. Portanto, realmente precisa libertar-se disso, sabes o que quero dizer?"

    # say L1838 pla
    old "This is crazy Mrs. White, I mean, how do we even know that Mrs. Jade would want to do anything with me?"
    new "B:whi: E como sei que és muito talentoso nesse aspecto, pensei que fosses a pessoa certa para a ajudar."

    # say L1839 whi
    old "Oh, don't you play dumb with me!"
    new "B:pla: Isto é louco, Sra. White, quero dizer, como é que nós sabemos que a Sra. Jade quereria fazer algo comigo?"

    # say L1840 whi
    old "I already know you two have done a couple of things already."
    new "B:whi: Oh, não me vás tu fazer de parvo!"

    # say L1842 whi
    old "So, listen carefully, this is what's going to happen..."
    new "A:jad: Oi, onde estiveste?"

    # say L1856 jad
    old "I can't believe I let you talk me into doing something this crazy!"
    new "B:jad: Meu Deus! Tu realmente o trouxeste aqui?"

    # say L1857 whi
    old "Well, he's already here, so, no turning back now."
    new "B:jad: Não acredito que me convenceste a fazer algo assim tão louco!"

    # say L1859 whi
    old "Listen, I already talked to him, so, you don't need to worry about anything other than enjoying yourself."
    new "B:whi: Bem, ele já está aqui, então, não há como voltar atrás agora."

    # say L1860 whi
    old "I don't want you thinking about anything stressful, or about your daughter."
    new "B:whi: Ouve, já falei com ele, por isso, não precisas de te preocupar com mais nada além de te divertires."

    # say L1861 whi
    old "I especially don't want you thinking about that asshole Hiashi!"
    new "B:whi: Não quero que penses em nada stressante, ou na tua filha."

    # say L1862 whi
    old "All you need to do is focus on your own pleasure. Ok?"
    new "B:whi: Especialmente não quero que penses nesse sacana do Hiashi!"

    # say L1867 whi
    old "Hey [pla]! You can come in now honey!"
    new "B:whi: Ótimo, então vou dizer ao [pla] para entrar."

    # say L1875 jad
    old "H- hi [pla]."
    new "T(jad|tu|say): H- hi [pla]."

    # say L1877 whi
    old "Well, I think this might help a little."
    new "B:whi: Oh! Que tensão é esta? Tens de relaxar!"

    # say L1881 whi
    old "Look at that, isn't that just an amazing dick?"
    new "B:whi: Bem, acho que isto pode ajudar um pouco."

    # say L1882 whi
    old "I bet he's even bigger than you remember isn't Jade?"
    new "B:whi: Olha para isso, não é que seja um pénis incrível?"

    # say L1883 jad
    old "W- well..."
    new "B:whi: Aposto que é ainda maior do que tu te lembras, não é Jade?"

    # say L1884 whi
    old "And it's so thick, hot, and hard..."
    new "B:jad: B-bem..."

    # say L1894 whi
    old "Hmph, slrrrrp!"
    new "B:whi: E é tão grosso, quente e duro..."

    # say L1897 whi
    old "I could suck it all day!"
    new "B:whi: É tão bom!"

    # say L1898 whi
    old "I bet you want to have a taste too, don't you Jade?"
    new "B:whi: Podia chupá-lo o dia inteiro!"

    # say L1899 whi
    old "It's great, believe me!"
    new "B:whi: Aposto que também queres provar, não é Jade?"

    # say L1900 whi
    old "But he's mine first!"
    new "B:whi: É ótimo, acredita em mim!"

    # say L1910 whi
    old "I hope this has helped you take some tension off."
    new "B:whi: Mas ele é meu primeiro!"

    # say L1911 whi
    old "Now that we've broken the ice, you can do it at her house."
    new "B:whi: Espero que isto tenha ajudado a aliviar um pouco a tensão."

    # say L1915 whi
    old "Oh come on, Is that a problem?"
    new "B:whi: Agora que já quebrámos o gelo, podes fazê-lo na casa dela."

    # say L1917 whi
    old "Come on, you both enjoyed it and it's a win win."
    new "B:whi: Oh, vamos lá, isso é um problema?"

    # say L1923 whi
    old "And you Jade? Did you enjoyed with a real big cock in your mouth?"
    new "B:pla: Uhh, s- sim..."

    # say L1925 whi
    old "Well that's it, enjoy it together and don't make a fuss about it."
    new "B:whi: E tu, Jade? Gostaste de ter um pénis grande na boca?"

    # say L1926 whi
    old "Sadly, I won't be able to be there with you guys every time you fool around, but Jade still needs some stress relief."
    new "B:whi: Bem, é isso, aproveitem juntos e não façam um alarido por causa disso."

    # say L1927 whi
    old "So, I trust that you'll give it to her whenever she needs it."
    new "B:whi: Infelizmente, não poderei estar convosco todas as vezes que vos divertirem, mas a Jade ainda precisa de alívio para o stress."

    # say L1930 whi
    old "Now, Mike's about to come home, so, sadly we'll have to see each other again another time."
    new "B:whi: Então, confio que vais dar-lhe sempre que ela precisar."

    # say L1931 whi
    old "But I've enjoyed a lot this little meeting."
    new "B:whi: Agora, o Mike está prestes a chegar a casa, por isso, infelizmente, teremos de nos ver noutra altura."

    # say L1932 pla
    old "I guess I have to get going too."
    new "T(pla|tu|say): Acho que também tenho de ir."

    # say L1934 jad
    old "Y- yeah, uhh, me too. But before we leave."
    new "B:pla: Acho que também tenho de ir."

    # say L1940 pla
    old "I'm happy I'm able to help you Mrs. Jade."
    new "B:pla: Hmm... Claro, sem problemas."

    # say L1941 whi
    old "That's great, alright, see you later guys."
    new "B:pla: Estou feliz por poder ajudar-te, Sra. Jade."

    # say L1958 jad
    old "Wow, that was nice, isn't it?"
    new "B:whi: Ótimo, então, até mais, pessoal."

    # say L1959 pla
    old "Phew, I wasn't expecting that to be honest.."
    new "B:jad: Uau, isso foi bom, não é?"

    # say L1960 jad
    old "Heh, well, I figured that if I was going to do it, I should just go ahead and try."
    new "B:pla: Ufa, não estava à espera disso, para ser sincero..."

    # say L1961 jad
    old "I'm glad you did seem to enjoy it."
    new "A:jad: Tenho pensado muito no que a Sra. White disse, e..."

    # say L1963 jad
    old "I've been thinking a lot about what Mrs. White said, and..."
    new "T(jad|tu|diz): Tenho pensado muito no que a Sra. White disse, e... Acho que ela tem razão, preciso relaxar um pouco mais."

    # say L1964 jad
    old "I think she's right, I need to relax a bit more."
    new "B:jad: Tenho pensado muito no que a Sra. White disse, e..."

    # say L1965 jad
    old "So, I'm happy I took the leap."
    new "B:jad: Acho que ela tem razão, preciso relaxar um pouco mais."

    # say L1967 pla
    old "Well, I'm happy I can be of help to you."
    new "B:jad: Então, estou feliz por ter dado o salto."

    # say L1968 jad
    old "You're a lot more than that honey."
    new "B:pla: Bem, fico contente por poder ajudar-te."

    # say L1969 jad
    old "About what just happened, you can think of it as your reward for all of the hard work you've been doing lately."
    new "B:jad: Tu és muito mais do que isso, querida."

    # say L1971 jad
    old "Well, now, if you'll excuse me, I think I'll lay down for a bit, honey."
    new "B:jad: Sobre o que acabou de acontecer, podes pensar nisso como o teu prémio por todo o trabalho árduo que tens feito recentemente."

    # say L1972 pla
    old "Sure, I'll see you later."
    new "B:jad: Bem, agora, se me desculpas, acho que vou deitar-me um bocado, querida."

    # say L1973 jad
    old "Sure, good bye."
    new "A:pla: Não posso acreditar que aquilo tenha realmente acontecido."

    # say L1982 pla
    old "I can't believe that actually happened."
    new "T: Não acredito que isso tenha acontecido de verdade."

    # say L1983 pla
    old "Oh God, how do I always get into this."
    new "B:pla: Não posso acreditar que isso tenha acontecido."

    # say L2001 pla
    old "Hi? Mrs. Jade? Hinn? I came to work in the bathroom!"
    new "B:pla: Ah, Deus, como é que eu sempre me meto nisto."

    # say L2002 pla
    old "Mrs. Jade?"
    new "B:pla: Olá? Sra. Jade? Hinn? Vim trabalhar na casa de banho!"

    # say L2012 pla
    old "Uhh, This feels like Deja Vu..."
    new "B:pla: Sra. Jade?"

    # say L2013 pla
    old "Hmm, I don't like where this is going..."
    new "B:pla: Uhh, Isto parece Déjà Vu..."

    # say L2022 pla
    old "O- oh! Mrs. Jade, Mrs. White, you're here... Hi."
    new "B:pla: Hmm, não gosto nada disto..."

    # say L2024 jad
    old "Nevermind that [pla], we've been waiting for you."
    new "T(jad|tu|say): Deixa isso de lado [pla], estamos à espera de ti."

    # say L2026 whi
    old "Well sweetie, Jade was thinking maybe it was time to get drilled by your huge cock."
    new "B:pla: A- à espera?"

    # say L2027 pla
    old "... (Holly Shit...)"
    new "B:whi: Bem querida, a Jade estava a pensar que talvez fosse altura de ser penetrada pelo teu pénis enorme."

    # say L2028 whi
    old "So, I thought I should be here to give her a little nudge forward."
    new "B:pla:... (Puta Merda...)"

    # say L2030 jad
    old "Now honey, don't just stand there looking lost."
    new "B:whi: Então, pensei que devia estar aqui para lhe dar uma ajudinha."

    # say L2047 whi
    old "I suppose the next time you two won't need my assistance."
    new "B:whi: Ok, fico contente por ter podido ajudar-te, Jade."

    # say L2048 whi
    old "But, don't be selfish, you can always invite me to spend a sexy afternoon like today."
    new "B:whi: Suponho que da próxima vez vocês não precisarão da minha ajuda."

    # say L2049 jad
    old "For sure I will."
    new "B:whi: Mas, não sejas egoísta, podes sempre convidar-me para passar uma tarde sexy como hoje."

    # say L2050 whi
    old "Nice! So, I guess it's ok if I leave for now."
    new "B:jad: Com certeza."

    # say L2051 jad
    old "Ok, but again, thank you so much for all your help."
    new "B:whi: Ótimo! Então, acho que posso ir embora agora."

    # say L2052 jad
    old "You were completely right about everything."
    new "B:jad: Ok, mas mais uma vez, muito obrigado por toda a tua ajuda."

    # say L2053 whi
    old "Well, I'm always right, girl, you know that."
    new "B:jad: Tinha razão em tudo."

    # say L2061 jad
    old "And you must be very tired anyway, so, I suppose we'll see each other another time."
    new "B:jad: Bem, acho que já é tarde demais para tu trabalhares na casa de banho agora."

    # say L2062 pla
    old "Yeah, don't worry. I'll be back soon..."
    new "B:jad: E tu deves estar muito cansado, então, suponho que nos veremos noutra altura."

    # say L2063 pla
    old "See you later Mrs. Jade."
    new "B:pla: Yeah, don't worry. I'll voltar já..."

    # say L2064 jad
    old "See you later honey."
    new "B:pla: Até mais, Sra. Jade."

    # say L2078 pla
    old "Ok! That's it! I think I'm done!"
    new "B:jad: Até mais, querida."

    # say L2079 pla
    old "Finally."
    new "A:pla: Acho que devo ir dizer à Sra. Jade."

    # say L2080 pla
    old "I think I should go tell Mrs. Jade."
    new "B:pla: Finalmente."

    # say L2088 pla
    old "Alright Mrs. Jade, I finished fixing the shower."
    new "B:pla: Acho que devo ir dizer à Sra. Jade."

    # say L2090 pla
    old "You can now use it as before, it should be completely fine."
    new "B:pla: Tudo bem, Sra. Jade, já arranjei a duche."

    # say L2091 jad
    old "Really? That's very good."
    new "B:pla: Podes usar como antes, deve estar tudo bem."

    # say L2092 pla
    old "Yeah, why don't you come with me so you can see it?"
    new "T: Sim, por que não vens comigo para veres?"

    # say L2102 pla
    old "You see? It's fine now."
    new "B:pla: Sim, por que não vens comigo para veres?"

    # say L2111 jad
    old "Well, since the shower's now working, I figured I should give it a try, don't you think?"
    new "B:pla: O- o quê? O que estás a fazer, Sra. Jade?"

    # say L2113 jad
    old "And since you've been working so hard, you should also try it, so you can relax a little bit after all of that hard work."
    new "B:jad: Bem, já que a ducha está a funcionar, achei que devia experimentá-la, não achas?"

    # say L2114 jad
    old "So, now you and I are going to take a shower together."
    new "B:jad: E como tu tens trabalhado tanto, também deves experimentar, para poder relaxar um pouco depois de todo esse esforço."

    # say L2129 jad
    old "Thanks a lot for what you did."
    new "B:jad: Ok, querida, acho que já está tudo resolvido no banheiro."

    # say L2130 jad
    old "I don't know how much it would've cost to fix it if I had contacted a plumber."
    new "B:jad: Muito obrigada pelo que fizeste."

    # say L2131 pla
    old "No problem Mrs. Jade, I'm happy to help."
    new "B:jad: Não sei quanto teria custado se tivesse chamado um encanador."

    # say L2132 jad
    old "Oh, you did a lot more than that."
    new "B:pla: Sem problemas, Sra. Jade, estou feliz em ajudar."

    # say L2133 jad
    old "And I hope you know I expect to see you around here soon."
    new "B:jad: Oh, fizeste muito mais do que isso."

    # say L2134 jad
    old "Please remember to come and pay me a visit once in a while."
    new "B:jad: E espero que saibas que espero ver-te por aqui em breve."

    # say L2135 jad
    old "I know you'll enjoy it."
    new "B:jad: Lembra-te de vir visitar-me de vez em quando."

    # say L2136 pla
    old "Sure, I'll come by soon."
    new "B:jad: Eu sei que vais gostar."

    # say L2137 jad
    old "That's good honey, very good."
    new "T(jad|tu|say): Isso é bom, meu amor, muito bom."

    # say L2138 jad
    old "I suppose you have to go?"
    new "B:jad: Isso é bom, meu amor, muito bom."

    # say L2140 pla
    old "Yeah, it's a little bit late, and I'm really tired..."
    new "B:jad: Suponho que tenhas de ir?"

    # say L2141 jad
    old "Oh yeah, honey, you deserve a good rest."
    new "B:pla: Sim, já é um pouco tarde, e estou mesmo cansado..."

    # say L2142 pla
    old "Yeah, I will sleep like a baby tonight."
    new "B:jad: Oh yeah, meu amor, tu mereces um bom descanso."

    # say L2144 pla
    old "Alright, have a good night Mrs. Jade."
    new "B:pla: Sim, vou dormir como um bebé esta noite."

    # say L2145 jad
    old "Have a good night, honey."
    new "B:pla: Boa noite, Sra. Jade."

    # say L2162 pla
    old "Oh, hi Hinn."
    new "B:jad: Boa noite, querida."

    # say L2163 pla
    old "How are you? How have your extra classes been going?"
    new "B:pla: Olá, Hinn."

    # say L2166 hin
    old "Hey, I wanted to thank you for all the hard work you did at my house with fixing the shower and stuff."
    new "B:pla: Como estás? Como têm sido as tuas aulas extra?"

    # say L2168 pla
    old "Oh, my pleasure. I'm glad I was able to help you."
    new "T(pla|tu|say): Oh, foi um prazer. Fico contente por ter podido ajudar-te."

    # say L2169 hin
    old "Yeah well, I still wanted to thank you personally, because I bet my mom didn't even say thank you, did she?"
    new "B:pla: Oh, o prazer foi meu. Fico contente por ter podido ajudar-te. T(hin|tu|say): Pois, mas ainda assim queria agradecer-te pessoalmente, porque aposto que a minha mãe nem sequer te agradeceu, não é? A:pla: Uhh... Ela agradeceu, ela agradeceu."

    # say L2170 pla
    old "Uhh... She did, she did."
    new "T(pla|tu|say): Hum... Ela disse, ela disse."

    # say L2171 pla
    old "She was actually very, very grateful."
    new "B:pla: Uhh... Ela fez, ela fez."

    # say L2173 hin
    old "She was? Well, that's a surprise."
    new "B:pla: Ela estava realmente muito, muito grata."

    # say L2174 hin
    old "I'm glad she did."
    new "B:hin: Ela foi? Bem, isso é uma surpresa."

    # say L2175 hin
    old "But don't think I forgot to give you my own thank you."
    new "B:hin: Fico contente que ela tenha feito isso."

    # say L2177 hin
    old "I'll be busy a couple more days with my extracurricular activities."
    new "B:hin: Mas não penses que me esqueci de te agradecer."

    # say L2178 hin
    old "But as soon as I'm free I'll give you something to really say thanks."
    new "B:hin: Vou estar ocupado mais uns dias com as minhas atividades extracurriculares."

    # say L2192 hin
    old "My mom asked me to tell you that there are a couple more things in the house that need fixing."
    new "T(hin|tu|say): A minha mãe pediu-me para te dizer que há mais algumas coisas em casa que precisam de ser arranjadas."

    # say L2193 hin
    old "And wanted to know if you could come and help us with that."
    new "B:hin: A minha mãe pediu-me para te dizer que há mais algumas coisas em casa que precisam de ser arranjadas."

    # say L2194 hin
    old "Which is terrible of her to ask after all you already did. So, if you can't do it just tell me and I'll set her straight."
    new "B:hin: E queria saber se tu podias vir e ajudar-nos com isso."

    # say L2195 pla
    old "Uhh, yeah, actually it's fine, I kinda have an idea of what she wants me to do, so, don't worry, it's fine."
    new "T(pla|tu|say): Uhh, sim, na verdade está tudo bem, tenho uma ideia do que ela quer que eu faça, então, não te preocupes, está tudo bem."

    # say L2196 hin
    old "It is? Well, I'm glad it doesn't bother you."
    new "B:pla: Uhh, sim, na verdade está tudo bem, tenho uma ideia do que ela quer que eu faça, então, não te preocupes, está tudo bem."

    # say L2197 hin
    old "Thanks a lot [pla], I'll see you later."
    new "Obrigado [pla], vejo-te mais tarde. Olá Sra. Jade."

    # say L2217 jad
    old "Hi honey, tell me, do you need anything?"
    new "B:pla: Olá Sra. Jade."

    # say L2234 jad
    old "Hey [pla], don't you have to be at school?"
    new "T(jad|tu|say): Ei [pla], não tens de estar na escola?"

    # say L2240 pla
    old "You're right. Sorry. I better go now..."
    new "Tens razão. Desculpa. Melhor ir agora..."

    # say L2242 jad
    old "...(Hmm.)"
    new "B:pla: Tens razão. Desculpa. Melhor ir agora..."

    # say L2276 jad
    old "What? But right now it's school time!"
    new "T: Que? Mas agora é hora de aula!"

    # say L2277 jad
    old "It's very sweet of you to come here to help, but I don't want you missing any classes because of me."
    new "B:jad: O quê? Mas agora é hora de aula!"

    # say L2278 jad
    old "You should go to school, I'll be here in the afternoon, so you can come and do the bathroom then."
    new "B:jad: É muito gentil de tua parte vir aqui ajudar, mas não quero que faltes a qualquer aula por minha causa."

    # say L2279 pla
    old "Yeah, I think you're right."
    new "B:jad: Deves ir à escola, eu estarei aqui à tarde, então podes vir fazer o banho nessa altura."

    # say L2280 pla
    old "I'll come here later then."
    new "Vou vir aqui mais tarde então."


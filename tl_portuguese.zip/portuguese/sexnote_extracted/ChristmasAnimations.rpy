# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/ChristmasAnimations.rpy
translate portuguese strings:

    # say L6 shiHin
    old "Ok [pla], just make sure to enjoy it."
    new "T(shiHin|tu|diz): Ok [pla], só certifica-te de aproveitar."

    # say L7 shiBil
    old "Mmmmm."
    new "A:shiBel: Sim, assim, gostas do sabor do pénis dele?"

    # say L8 shiBel
    old "Yes, like that, do you like the taste of his dick?"
    new "B: shiBil: Mmmmm."

    # say L9 shiBil
    old "Mmm! Slurrp!"
    new "B: shiBel: Sim, assim, gostas do sabor do pau dele?"

    # say L10 shiHin
    old "Hahaha, that’s right. Enjoy it, put it all in your mouth."
    new "B: shiBil: Mmm! Slurrp!"

    # say L14 shiBel
    old "It’s so big, it can’t even fit it in her mouth."
    new "B: shiHin: Hahaha, isso mesmo. Aproveita, mete tudo na boca."

    # say L19 shiBil
    old "It's so fucking huge..."
    new "B: pla: Y- sim, está a sentir-se mesmo bem."

    # say L20 shiBil
    old "And it’s throbbing in my mouth."
    new "B:shiBil: É tão grande..."

    # say L21 shiBil
    old "I think he’s getting close."
    new "B: shiBil: E está a latejar na minha boca."

    # say L22 shiBel
    old "That’s right, keep pushing that cock in your mouth!"
    new "B: shiBil: Acho que ele está perto."

    # say L49 shiBel
    old "Then do it! Cum! Fill her mouth!"
    new "B:pla: Ughh... S-sim..."

    # say L50 pla
    old "Ughhh! Ahhh!!!"
    new "B: shiBel: Então faz isso! Goza! Enche a boca dela!"

    # say L55 shiHin
    old "That looked great!"
    new "T(tu): Ficou incrível!"

    # say L56 shiBel
    old "It really did."
    new "B:shiHin: Ficou fantástico!"

    # say L57 shiBel
    old "You see Mildret? We knew you would enjoy it."
    new "B: shiBel: Realmente foi."

    # say L58 shiBil
    old "It was... good."
    new "B: shiBel: Tu viste a Mildret? Sabíamos que ias gostar."

    # say L59 shiBil
    old "These bodies are certainly incredible."
    new "B:shiBil: Foi... bom."

    # say L60 shiBil
    old "And the taste... I feel I could get used to it."
    new "B: shiBil: Estes corpos são certamente incríveis."

    # say L61 shiHin
    old "Hahaha, it’s good to see you’re enjoying the ritual."
    new "B:shiBil: E o sabor... Sinto que poderia habituar-me a ele."

    # say L62 shiBel
    old "What about if we get ready to enjoy that cock inside us?"
    new "B: shiHin: Hahaha, é bom ver que estás a gostar do ritual."

    # say L63 shiHin
    old "That's a good idea..."
    new "B: shiBel: E se nos prepararmos para aproveitar esse pau dentro de nós?"

    # say L64 shiBil
    old "All right."
    new "Como está a correr o ritual, Linett?"

    # say L73 shiBel
    old "How is the ritual going Linett?"
    new "B:shiBil: Tudo bem."

    # say L74 lin
    old "It’s good, I was able to stabilize a breaching point."
    new "B: shiBel: Como está o ritual, Linett?"

    # say L75 lin
    old "But to open it I’m going to need an even bigger magic discharge."
    new "B:lin: É bom, consegui estabilizar um ponto de ruptura."

    # say L76 shiHin
    old "Oh, don’t worry, that’s what’s coming just now. Or maybe I meant cumming..."
    new "B:lin: Mas para abrir isso vou precisar de uma descarga mágica ainda maior."

    # say L77 shiBel
    old "This is where we really enjoy it."
    new "B:shiHin: Oh, não te preocupes, é isso que está a acontecer agora. Ou talvez eu tenha querido dizer que estou a gozar..."

    # say L78 shiHin
    old "Let’s do it then."
    new "B:shiBel: É aqui que realmente nos divertimos."

    # say L80 pla
    old "Sure."
    new "A:milBil: Mmm, esta sensação. É tão forte."

    # say L93 milBil
    old "Mmm, this sensation. It’s so strong."
    new "Mmm, esta sensação. É tão forte. E tão grande, incrível."

    # say L94 milBil
    old "And so big, incredible."
    new "B:milBil: Mmm, esta sensação. É tão forte."

    # say L100 devBel
    old "Yes, enjoy it Mildret. Do you like his cock inside you?"
    new "B:milBil: Oh! Sinto-me tão quente!"

    # say L101 milBil
    old "I do, I really like it!"
    new "B:devBel: Sim, aproveita Mildret. Gostas de o ter dentro de ti?"

    # say L105 milBil
    old "Ahh! Ahh! This is amazing!"
    new "B:milBil: Eu faço, eu realmente gosto!"

    # say L106 milBil
    old "It feels so good!"
    new "B:milBil: Ahh! Ahh! Isto é incrível!"

    # say L107 milBil
    old "Do it some more, keep going!"
    new "B:milBil: Sentes-te tão bem!"

    # say L130 milBil
    old "This feeling, I think I’m cumming!"
    new "B:milBil: Continua, não pares!"

    # say L132 pla
    old "Ahh! Y- yes!"
    new "A:devBel: Então, gostaste?"

    # say L138 devBel
    old "So, did you like it?"
    new "Foi muito bom."

    # say L139 gomHin
    old "It was very good."
    new "B:devBel: Então, gostaste?"

    # say L140 devBel
    old "I’m glad you enjoyed it, but it’s my turn now."
    new "B: gomHin: Foi muito bom."

    # say L141 devBel
    old "I actually wonder how it’s going to be with this small body."
    new "B:devBel: Fico contente que tenhas gostado, mas agora é a minha vez."

    # say L142 devBel
    old "I hope it’s going to be as good as last time."
    new "B:devBel: Eu realmente me pergunto como vai ser com este corpo pequeno."

    # say L143 gomHin
    old "Only one way to find out..."
    new "B:devBel: Espero que seja tão bom como da última vez."

    # say L161 devBel
    old "Ohh! Ahh! It’s so big!"
    new "B: gomHin: Só há uma maneira de descobrir..."

    # say L162 devBel
    old "It fills me up, completely."
    new "B:devBel: Ohh! Ahh! É tão grande!"

    # say L163 devBel
    old "Uhhh it hurts, but still feels so good!"
    new "T(devBel|tu|say): Uhhh dói, mas ainda assim é tão bom!"

    # say L167 devBel
    old "Yes, yes, just like that."
    new "B:devBel: Ai, dói, mas ainda assim é tão bom!"

    # say L168 devBel
    old "I love how your cock feels."
    new "B:devBel: Sim, sim, assim mesmo."

    # say L169 devBel
    old "Ohhh yeah, with this little body feels even better!."
    new "B:devBel: Adoro como o teu pénis se sente."

    # say L173 gomHin
    old "Do you like how he pounds your pussy Devonne?"
    new "B:devBel: Ohhh sim, com este corpinho sente-se ainda melhor!"

    # say L174 devBel
    old "Ah, Ah, YES!"
    new "B: gomHin: Gostas de como ele te fode, Devonne?"

    # say L175 devBel
    old "I love it! I love it!"
    new "B:devBel: Ah, Ah, SIM!"

    # say L176 devBel
    old "I want to keep doing it in this body forever!"
    new "B:devBel: Adoro! Adoro!"

    # say L199 devBel
    old "I’m cummin! I can feel it!"
    new "B:devBel: Quero continuar a fazer isto neste corpo para sempre!"

    # say L200 pla
    old "M- me too!"
    new "B:devBel: Estou a gozar! Sinto-o!"

    # say L201 devBel
    old "Do it! Cum in me!"
    new "B: pla: M- eu também!"

    # say L207 devBel
    old "That was sooo good."
    new "B:devBel: Faz isso! Goza em mim!"

    # say L208 devBel
    old "I think I could get addicted to it."
    new "B:devBel: Isso foi tão bom."

    # say L209 devBel
    old "And I think it felt even better because of how small this body is."
    new "B:devBel: Acho que posso ficar viciado nisso."

    # say L210 gomHin
    old "Hmm, now you’ve made me crave it even more!"
    new "B:devBel: E acho que senti ainda melhor por causa do tamanho deste corpo."

    # say L212 gomHin
    old "You’ve done a lot [pla]."
    new "B: gomHin: Vamos [pla], vamos terminar o ritual."

    # say L214 pla
    old "S- sure."
    new "B:gomHin: Então deves estar cansado, mas não desfaleças agora."

    # say L231 gomHin
    old "Oh yes! That’s just what I wanted."
    new "B:pla: Claro."

    # say L237 gomHin
    old "Ah, Ah, your cock, it’s reaching so deep!"
    new "B:devBel: E vai um pouco mais rápido."

    # say L238 gomHin
    old "And it feels so hot as you penetrate me!"
    new "B:gomHin: Ah, Ah, o teu pénis, está a penetrar tão fundo!"

    # say L239 gomHin
    old "I can feel it throbbing in me. I love how it feels!"
    new "B: gomHin: E sente-se tão quente quando me penetras!"

    # say L243 gomHin
    old "Ohh! Ohh! YES!"
    new "B: gomHin: Sinto-o a latejar dentro de mim. Adoro como se sente!"

    # say L244 gomHin
    old "This is great!"
    new "B: gomHin: Ohh! Ohh! SIM!"

    # say L245 gomHin
    old "I feel the magic pushing in!"
    new "B: gomHin: Isto é incrível!"

    # say L268 gomHin
    old "I’m about to cum!"
    new "B: gomHin: Sinto a magia a entrar!"

    # say L269 pla
    old "M- me too"
    new "B: gomHin: Vou gozar!"

    # say L270 pla
    old "I can’t hold it anymore!"
    new "Deixa ir!"

    # say L271 gomHin
    old "Let it go!"
    new "B:pla: Não aguento mais!"

    # say L272 gomHin
    old "Shoot your magic in my pussy!"
    new "B: gomHin: Deixa ir!"


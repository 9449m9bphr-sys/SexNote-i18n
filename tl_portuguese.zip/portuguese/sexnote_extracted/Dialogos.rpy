# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Dialogos.rpy
translate portuguese strings:

    # say L9 pla
    old "Another day..."
    new "Vamos só passar pelas aulas e sobreviver."

    # say L10 pla
    old "Let’s just get through classes and survive."
    new "B:pla: Outro dia..."

    # say L11 pla
    old "Hope nothing weird happens today."
    new "B:pla: Vamos acabar as aulas e sobreviver."

    # say L16 pla
    old "Hmm... What's that sound coming down the hall?"
    new "B:pla: Espero que nada de estranho aconteça hoje."

    # say L18 pla
    old "({i}Sounds like music, but faint. Someone’s phone playing a song?{/i})"
    new "B:n: {i}Agora cada passo só me puxa para baixo...{/i}"

    # narrator L19 
    old "{i}Everything I wanted slips right through my hands...{/i}"
    new "B:pla: ({i}Parece música, mas fraca. O telemóvel de alguém a tocar uma canção?{/i})"

    # say L22 pla
    old "({i}That melody’s got so much heart. Who’s in there?{/i})"
    new "B:n: {i}E ainda estou a respirar... mas não percebo...{/i}"

    # say L28 pla
    old "Uhh, music? It sounded like someone singing, like right here."
    new "B:bil: Heh, a cantar? Nah, provavelmente é só música da sala ao lado."

    # say L30 bil
    old "Or someone’s phone blasting some old track. This place is a noise fest."
    new "B:pla: Uhh, música? Parecia que alguém estava a cantar, aqui mesmo."

    # say L34 pla
    old "The vents? For real? It had this raw emotion..."
    new "B:bil: Demasiado bom? Cara, se eu estivesse a cantar, já era viral. Culpa das ventilações."

    # say L39 pla
    old "What’s this? Doodles, messy scratches... hold up, are these lyrics?"
    new "B:pla: Whoa, a caderno dela caiu."

    # say L40 pla
    old "Music notes scribbled everywhere. ‘Faded echoes, songs we lost...’"
    new "B:pla: O que é isto? Rabiscos, arranhões... espera, estes são letras de músicas?"

    # say L52 jon
    old "Nonsense, you’re always welcome. How’s school going?"
    new "B:pla: Olá, Sra. Jones. Desculpe-me por aparecer sem avisar."

    # say L53 pla
    old "It’s alright. Keeps me on my toes."
    new "B:jon: Nonsense, tu és sempre bem-vindo. Como está a escola?"

    # say L56 jon
    old "Let me see... Oh, these sketches and notes. Takes me way back."
    new "B:pla: Bem, ela deixou o caderno na escola. Achei que era importante."

    # say L57 pla
    old "Way back? To what, if it’s okay to ask?"
    new "B:jon: Deixa-me ver... Oh, estes esboços e notas. Levam-me a tempos antigos."

    # say L61 jon
    old "It was. Her dad with his old guitar, her mom humming along. It lit her up."
    new "B:pla: Posso imaginar. Deve ter sido o seu mundo inteiro."

    # say L64 jon
    old "Oh really? You heard her singing today?"
    new "B:pla: Ouvi-a hoje. Foi algo que me tocou profundamente."

    # say L65 jon
    old "Well, she used to sing all the time. It was such a lovely thing to hear... but after her parents passed, everything changed for her."
    new "B:jon: Oh, realmente? Ouviste a ela a cantar hoje?"

    # say L66 pla
    old "Oh, I didn't know? I’m so sorry, Mrs. Jones. That sounds so tough."
    new "B:jon: Ela costumava cantar o tempo todo. Era tão bonito de se ouvir... mas depois de os pais dela falecerem, tudo mudou para ela."

    # say L67 jon
    old "It was a long time ago... A car accident. Took them both in an instant."
    new "B:pla: Oh, eu não sabia? Sinto muito, Sra. Jones. Isso deve ter sido muito difícil."

    # say L71 jon
    old "Every note brought their voices back. First happy, then just the hurt."
    new "B:jon: A fé sustentou-nos. Mas para ela, cantar transformou-se em dor."

    # say L72 pla
    old "So it stopped being joy. More like ripping open old wounds?"
    new "B:jon: Cada nota trazia de volta as suas vozes. Primeiro felizes, depois só a dor."

    # say L73 jon
    old "Exactly. She shut it down, like flipping a switch."
    new "B:pla: Então já não era alegria. Mais como rasgar feridas antigas?"

    # say L78 jon
    old "Life’s not always kind, honey. But you’re sweet to care."
    new "B:pla: Só desejava que não a sobrecarregasse assim. Parece tão injusto."

    # say L79 pla
    old "I’ll leave the notebook. Tell her I didn’t snoop too much."
    new "B:jon: A vida nem sempre é fácil, querida. Mas és doce por te importares."

    # say L80 jon
    old "Of course, dear. Safe walk home now."
    new "B:pla: Vou deixar o caderno. Diz-lhe que não espreitei muito."

    # say L81 pla
    old "Thanks, Mrs. Jones. See you soon."
    new "B:jon: Claro, querida. Boa caminhada para casa agora."

    # say L87 pla
    old "Man... what a day."
    new "B:pla: Obrigado, Sra. Jones. Até logo."

    # say L88 pla
    old "So that’s why she acts like nothing touches her."
    new "B:pla: Homem... que dia."

    # say L89 pla
    old "Losing both parents at once... and singing was the last thing connecting her to them."
    new "B:pla: É por isso que ela age como se nada a afetasse."

    # say L90 pla
    old "Now I get why she kept dodging the whole thing. Every note probably feels like losing them again."
    new "B:pla: Perder os dois pais de uma vez... e cantar era a última coisa que a ligava a eles."

    # say L91 pla
    old "She’s not hiding because she’s shy. She’s hiding because it hurts too much to let it out."
    new "B:pla: Agora percebo por que ela continuava a evitar tudo isto. Cada nota provavelmente parece perderem-se de novo."

    # say L92 pla
    old "That cool girl armor isn’t just attitude. It’s survival."
    new "B: Ela não está a esconder-se porque é tímida. Está a esconder-se porque dói demasiado deixar sair."

    # say L93 pla
    old "But that voice... It’s still in there. And it’s beautiful."
    new "B:pla: Essa armadura de garota cool não é só atitude. É sobrevivência."

    # say L94 pla
    old "If there’s even a tiny chance something could help her feel that joy again... I have to try."
    new "B:pla: Mas essa voz... Ela ainda está lá. E é linda."

    # say L95 pla
    old "I don’t know how yet, but I’m not letting her carry this alone."
    new "B:pla: Se há mesmo uma pequena hipótese de algo que possa ajudá-la a sentir essa alegria de novo... tenho que tentar."

    # say L107 pla
    old "School’s doing a music contest? Sign-ups are open..."
    new "B:pla: Espera aí, o que é este panfleto na parede?"

    # say L111 pla
    old "({i}She’s literally going to murder me for signing her up without asking.{/i})"
    new "B: ({i}Ela tem talento, só não o mostra. Isto pode fazê-la sair da casca. {/i})"

    # say L112 pla
    old "({i}Like, straight-up bury me in the backyard. But it’s worth the risk, right?{/i})"
    new "B:pla: ({i}Vou literalmente ser assassinado por a ter inscrito sem perguntar. {/i})"

    # say L113 pla
    old "Gotta do it."
    new "Olá, tu és a Sr.ª Beylaine?"

    # say L119 pla
    old "Hi, are you Ms. Beylaine?"
    new "T(pla|tu|say): Olá, tu és a Sr.ª Beylaine?"

    # say L120 bey
    old "That’s me, honey! Come in, come in."
    new "B:pla: Olá, tu és a Sr.ª Beylaine?"

    # say L121 pla
    old "I saw the flyer about the music contest. Looks really cool."
    new "B:bey: Sou eu, meu amor! Entra, entra."

    # say L123 pla
    old "I wanna sign up. Me and my friend [bil]."
    new "T: Quero inscrever-me. Eu e a minha amiga [bil]."

    # say L125 pla
    old "Well, she’s got an insane voice, but she keeps it hidden. I thought this might be good for her."
    new "B:bey: Adoro a energia do duo! Contem-me sobre vocês duas."

    # say L126 bey
    old "Hidden talent? That’s my favorite kind."
    new "B:pla: Ela tem uma voz incrível, mas mantém-na escondida. Pensei que isto poderia ser bom para ela."

    # say L127 bey
    old "What about you, handsome? What do you bring to the stage?"
    new "B:bey: Talento escondido? Esse é o meu favorito."

    # say L128 pla
    old "Uhh... honestly? Nothing. I can’t sing, can’t play. Zero."
    new "B:bey: E tu, bonito? O que é que trazes ao palco?"

    # say L129 bey
    old "Zero today doesn’t mean zero tomorrow."
    new "B:pla: Uhh... honestamente? Nada. Não consigo cantar, não sei tocar. Zero."

    # say L130 bey
    old "Don't worry, we’re doing practice sessions first. Technique, composition, stage fire. I pull the best out of everybody."
    new "T(bey|tu|diz): Não te preocupes, vamos fazer sessões de treino primeiro. Técnica, composição, presença em palco. Tiro o melhor de todos."

    # say L131 pla
    old "So we get actual coaching before the contest?"
    new "B:bey: Não te preocupes, vamos fazer sessões de treino primeiro. Técnica, composição, fogo no palco. Eu tiro o melhor de todos."

    # say L132 bey
    old "Exactly. I don’t just throw y’all to the wolves. We build it together."
    new "B:pla: Então vamos ter treino antes do concurso?"

    # say L133 pla
    old "Oh, that sounds perfect, actually."
    new "T(pla|tu|say): Oh, isso soa perfeito, na verdade."

    # say L134 bey
    old "Ok, to start, I just need you to fill out a couple forms for you and your friend. After that, I’ll reach out to schedule the audition."
    new "B:pla: Oh, isso soa perfeito, na verdade."

    # say L135 pla
    old "Got it, thanks, Ms. Beylaine. This means a lot."
    new "B:bey: Ok, para começar, só preciso que preenchas uns formulários para ti e para a tua amiga. Depois disso, entrarei em contacto para agendar a audição."

    # say L136 bey
    old "Call me Bey. And tell your friend: when she’s ready to own that stage, I got her."
    new "B:pla: Entendido, obrigado, Sra. Beylaine. Isto significa muito."

    # say L155 bil
    old "Hmm, what now?"
    new "A:pla: Inscrevi-nos no concurso de música!"

    # say L156 pla
    old "I signed us up for the music contest!"
    new "Tu... fizeste o quê?"

    # say L157 bil
    old "You... did what?"
    new "T(bil|tu|say): Tu... fizeste o quê?"

    # say L158 pla
    old "Yeah! They’ve got coaching and everything. It’s perfect!"
    new "Tu... fizeste o quê?"

    # say L159 bil
    old "You signed me up. Without even asking."
    new "B:pla: Sim! Eles têm treino e tudo. É perfeito!"

    # say L160 pla
    old "I know, I know, it sounds crazy, but just hear me out—"
    new "B:bil: Inscreveste-me. Sem me perguntar."

    # say L163 bil
    old "That’s not the point. It’s my thing, not yours."
    new "B:pla: Não, não, é só que tu tens essa voz incrível. As pessoas precisam ouvi-la."

    # say L164 pla
    old "Come on, it’s just a contest! You’d crush everyone."
    new "B:bil: Isso não é o ponto. É a minha coisa, não a tua."

    # say L165 bil
    old "Stop acting like you know what’s best for me."
    new "T(bil|tu|say): Pára de agir como se soubesses o que é melhor para mim."

    # say L170 pla
    old "Wait, your grandma told me how much you used to love singing with your parents—"
    new "B:bil: Pois, pensaste mal."

    # say L174 pla
    old "I- I- I’m sorry!"
    new "B:pla: Espera, a tua avó contou-me quanto tu adoravas cantar com os teus pais—"

    # say L175 pla
    old "I- I didn’t mean it l- like that, I- I swear!"
    new "T(pla|tu|dizer): I- I não quis dizer assim, j- juro!"

    # say L176 bil
    old "You have no idea what you’re talking about."
    new "T(bil|tu|say): Tu não sabes o que estás a dizer."

    # say L177 pla
    old "I know! I messed up, okay? I’m really sorry."
    new "T: Tu sabes! Fiz merda, ok? Desculpa mesmo."

    # say L178 pla
    old "I just... I thought it would help. That’s all."
    new "B:pla: Eu sei! Eu errei, ok? Desculpa mesmo."

    # say L179 bil
    old "You don’t get to dig into my life like that!"
    new "T(bil|tu|say): Tu não tens direito de te intrometer na minha vida assim!"

    # say L180 pla
    old "You’re right. I overstepped. Big time."
    new "T: Tens razão. Excedi-me. Muito."

    # say L187 bil
    old "Why do you even care?"
    new "T(bil|tu|say): Porque é que tu te importas?"

    # say L188 pla
    old "Because I hate seeing you hold back something you’re amazing at."
    new "T(pla|tu|say): Porque odeio ver-te a reprimir algo em que és incrível."

    # say L189 bil
    old "It’s not that simple."
    new "Não é assim tão simples."

    # say L190 pla
    old "I know it’s not. But just one practice. One."
    new "B:bil: Não é assim tão simples."

    # say L191 bil
    old "You’re seriously not dropping this?"
    new "T(bil|tu|say): Tu estás a levar isto a sério?"

    # say L192 pla
    old "I can’t. Not when I know how much talent you have."
    new "T: Não posso. Não quando sei o quanto talento tu tens."

    # say L193 bil
    old "You’re impossible."
    new "B:pla: Não posso. Não quando sei o quanto talento tu tens."

    # say L194 pla
    old "Please. One session. If it sucks, we never talk about it again."
    new "T: Por favor. Uma sessão. Se for péssimo, nunca mais falamos nisso."

    # say L196 bil
    old "You’re gonna keep bugging me until I say yes, aren’t you?"
    new "T(bil|tu|say): Vais continuar a importunar-me até eu dizer que sim, não vais?"

    # say L197 pla
    old "Uhh... pretty much."
    new "T(pla|tu|say): Hum... mais ou menos."

    # say L198 bil
    old "Ughh... fine. One practice. Just to shut you up."
    new "T(bil|tu|say): Ughh... bem. Uma prática. Só para te calar."

    # say L199 bil
    old "But that’s it. And after that, we’re done talking about it. Got it? End of discussion."
    new "B:bil: Ughh... bem. Uma prática. Só para te calar."

    # say L200 pla
    old "Deal! Thank you!"
    new "B:bil: Mas é isso. E depois disso, não falamos mais sobre isso. Entendido? Fim da discussão."

    # say L201 bil
    old "Don’t thank me yet."
    new "B:pla: Negócio feito! Obrigado!"

    # say L202 bil
    old "And don’t you ever ever bring up my parents again. You hear me?"
    new "B:bil: Ainda não me agradeças."

    # say L203 pla
    old "Uhh, yeah, got it..."
    new "B:bil: E nunca mais falas dos meus pais, ouviste?"

    # say L205 pla
    old "Phew.... Well, she didn’t kill me... I’ll call that a win."
    new "Ufa.... Bem, ela não me matou... Vou considerar isso uma vitória."

    # say L206 pla
    old "One practice. That’s all I needed."
    new "B: Phew.... Bem, ela não me matou... Vou considerar isso uma vitória."

    # say L218 pla
    old "I have zero clue what I’m doing up there, but it’s for her. Gotta move."
    new "T(pla|tu|dizer): Não tenho a mínima ideia do que estou fazendo aqui em cima, mas é por ela. Tenho de me mexer."

    # say L224 pla
    old "There you are! Ready for this?"
    new "B:pla: Não faço a mínima ideia do que estou a fazer aqui em cima, mas é por ela. Tenho de me mexer."

    # say L225 bil
    old "Ready? I’m here because you wouldn’t shut up about it."
    new "A:pla: Vamos, vai correr tudo bem. É só uma apresentação."

    # say L226 pla
    old "Come on, it’s gonna be fine. Just one showcase."
    new "B:bil: Pronto? Estou aqui porque não paravas de falar nisso."

    # say L227 bil
    old "Yeah, yeah. Let’s get this over with so I can go back to my life."
    new "B:pla: Vamos, vai correr tudo bem. É só uma apresentação."

    # say L233 pla
    old "Sure, let's go."
    new "B:bil: Tanto faz. Vamos, não tenho o dia todo."

    # say L240 bey
    old "I’m Beylaine, but you can call me Bey, and I’m the teacher who’s going to get you ready to take this year’s Music Contest crown."
    new "B:pla: Claro, vamos lá."

    # say L241 bey
    old "Look around you. Every single person in this room has fire inside them."
    new "B:bey: Sou Beylaine, mas podes chamar-me Bey, e sou a professora que vai preparar-te para conquistares a coroa do Concurso de Música deste ano."

    # say L242 bey
    old "Some of you know it, some of you are scared of it, some of you are still hiding it. My job? Pull that fire out and turn it into a supernova."
    new "B:bey: Olha à tua volta. Cada pessoa nesta sala tem fogo dentro de si."

    # say L244 bey
    old "From today until the final I’m your personal mentor, private feedback, whatever each of you needs to bring your absolute best act."
    new "B:bey: Alguns de vocês conhecem, alguns têm medo, e outros ainda estão escondendo. O meu trabalho? Tirar esse fogo e transformá-lo em uma supernova."

    # say L245 bey
    old "You’ll cry, you’ll laugh, you’ll hate me on Tuesdays and love me on Fridays, but by the final show you’ll thank me when the entire school is screaming your names."
    new "B: Bey: A partir de hoje até a final, sou a tua mentora pessoal, feedback privado, tudo o que precisas para dar o teu melhor espetáculo."

    # say L246 bey
    old "I'll be here for everything you need, we’re talking vocal technique, stage command, songwriting, harmonies, emotional truth, the whole package."
    new "B:bey: Vais chorar, vais rir, vais odiar-me às terças e amar-me às sextas, mas no final do espetáculo vais agradecer-me quando toda a escola estiver a gritar os vossos nomes."

    # say L248 bey
    old "So breathe, have fun, and remember: the stage is the one place where you’re allowed to be 100 % yourself. Ready? Let’s make magic!"
    new "B:bey: Vou estar aqui para tudo o que precisas, estamos a falar de técnica vocal, presença em palco, composição, harmonias, verdade emocional, o pacote completo."

    # say L252 sha
    old "Hit it, darling!"
    new "B:bey: Então respira, diverte-te e lembra-te: o palco é o único lugar onde podes ser 100% tu mesma. Pronta? Vamos fazer magia!"

    # say L253 rya
    old "Let’s give them a show they’ll never forget!"
    new "B:sha: Vai, querida!"

    # say L257 rya
    old "{i}Spotlights on us, no time to lose!{/i}"
    new "B:sha: {i}Somos os cabeças de cartaz, meu amor, notícias de primeira página!{/i}"

    # say L258 sha
    old "{i}Diamonds flashing, sequins bright!{/i}"
    new "B:rya: {i}Holofotes sobre nós, sem tempo a perder!{/i}"

    # say L259 rya
    old "{i}We own the stage every single night!{/i}"
    new "B:sha: {i}Diamantes a brilhar, lantejoulas a cintilar!{/i}"

    # say L268 bey
    old "My only note: sometimes less is more. When every second is maximum sparkle, there’s nowhere left to go for the big moments. Save some glitter for the finale, babies. Otherwise? Flawless."
    new "T(bey|tu|say): A minha única nota: às vezes menos é mais. Quando cada segundo é de máxima brilhância, não há para onde ir nos momentos grandes. Guardem um pouco de glitter para o final, meninas. Fora isso? Impecável."

    # say L272 ari
    old "Let’s remind them why we’re here."
    new "B:bey: A minha única nota: às vezes menos é mais. Quando cada segundo é pura magia, não há espaço para os momentos grandiosos. Guardem algum brilho para o final, meninas. Fora isso? Impecável."

    # say L276 ari
    old "{i}I’m feeling dangerous, feeling so brand new{/i}"
    new "T:tu: {i}Estou a sentir-me perigosa, tão nova e renovada{/i}"

    # say L277 tay
    old "{i}Shaking off the dust, ready for round two{/i}"
    new "B:ari: {i}Estou a sentir-me perigosa, tão nova e renovada{/i}"

    # say L278 ari
    old "{i}High notes climbing, watch me touch the sky{/i}"
    new "B:tay: {i}A sacudir a poeira, pronto para a segunda ronda{/i}"

    # say L279 tay
    old "{i}Beat drops heavy, no more asking why!{/i}"
    new "B:ari: {i}Notas altas a subir, vê-me tocar o céu{/i}"

    # say L288 bey
    old "Pitch perfect, breath control insane, harmony game lethal."
    new "B:bey: Senhor tenha misericórdia das minhas arestas! Ariana, esses tons agudos mais limpos que o meu coro de domingo. Taylor, esse agudo poderia acordar os mortos."

    # say L289 bey
    old "My tiny note: sometimes perfection can feel safe. Next time risk a little crack, a little rawness. Vulnerability wins hearts. But technically? Untouchable."
    new "T(bey|tu|diz): A minha nota pequena: às vezes a perfeição pode parecer segura. Da próxima vez, arrisca um pouco, deixa sair um pouco de cruza. A vulnerabilidade conquista corações. Mas tecnicamente? Imbatível."

    # say L293 pla
    old "Uhh... W- we didn’t really get a chance to rehearse..."
    new "B: bey: A minha pequena nota: às vezes a perfeição pode parecer segura. Da próxima vez, arrisca uma pequena rachadura, um pouco de crueldade. A vulnerabilidade conquista corações. Mas tecnicamente? Inatingível."

    # say L294 bil
    old "Ugh, just give me the mic."
    new "B:pla: Uhh... N-nós não tivemos realmente oportunidade de ensaiar..."

    # say L308 bey
    old "Oh my gosh, Billie... honey. That wasn’t singing. That was bleeding through music."
    new "B:bil: Ugh, dá-me o microfone."

    # say L309 bey
    old "Your tone is pure velvet, phrasing is heartbreaking, emotional truth 100%. Volume was whisper quiet, but somehow you filled the entire room."
    new "T(bey|tu|diz): A tua entonação é pura veludo, a fraseologia é de partir o coração, a verdade emocional 100%. O volume era sussurro, mas de alguma forma encheraste toda a sala."

    # say L319 bey
    old "Well, I have goosebumps from head to toe. Three completely different universes in one room."
    new "B:pla: Uhh... Y- yeah sure."

    # say L321 bey
    old "Next sessions we start real work: breathing, dynamics, choreography, song choice, storytellin, everyone gets one-on-one time with me."
    new "T(bey|tu|diz): Nas próximas sessões começamos o trabalho sério: respiração, dinâmica, coreografia, escolha da música, narração, cada um terá tempo individual comigo."

    # say L322 bey
    old "Because every single one of you can win this thing. I’m not here to pick favorites; I’m here to make favorites out of all of you."
    new "B:bey: Nas próximas sessões começamos o trabalho sério: respiração, dinâmica, coreografia, escolha da música, narrativa, cada um terá tempo individual comigo."

    # say L323 bey
    old "Go home, rest those voices, dream big, and come back hungry. See you at the next session!"
    new "B:bey: Porque cada um de vocês pode ganhar isto. Não estou aqui para escolher favoritos; estou aqui para fazer todos vocês favoritos."

    # say L327 pla
    old "Wow, Billie, did you hear everything she was saying about your voice?"
    new "B: Bey: Vai para casa, descansa essas vozes, sonha em grande e volta com fome. Até à próxima sessão!"

    # say L328 bil
    old "Yeah, yeah, Anyway. I did the one practice. We’re done."
    new "B:pla: Wow, Billie, ouviste tudo o que ela disse sobre a tua voz?"

    # say L329 pla
    old "W- what? Are you serius? You were unbelievable—"
    new "B:bil: Sim, sim, enfim. Fiz a prática. Acabámos."

    # say L333 sha
    old "Unbelievable is right. Unbelievably depressing."
    new "B:pla: O- o quê? Estás a falar a sério? Foste incrível—"

    # say L335 sha
    old "What was that, a lullaby for the dead?"
    new "B:sha: Incrível é certo. Incrivelmente depressivo."

    # say L339 sha
    old "Volume exists for a reason, sweetie. The back row couldn’t hear a thing."
    new "B:sha: O que foi isso, uma canção de ninar para os mortos?"

    # say L341 ari
    old "Oh, wait, is this the girl who whispered her whole song? Heh"
    new "B:sha: O volume existe por uma razão, querida. A última fila não ouviu nada."

    # say L343 tay
    old "I thought someone forgot to plug in the mic, hahaha."
    new "B:ari: Oh, espera, é esta a rapariga que sussurrou toda a canção? Heh"

    # say L344 sha
    old "Exactly. Bedroom sad girl vibes don’t win contests, sweetie."
    new "T: Exactamente. Vibes de menina triste no quarto não ganham concursos, querida."

    # say L345 ari
    old "We’re trying to make people dance, not cry."
    new "B:sha: Exactamente. Vibes de menina triste no quarto não ganham concursos, querida."

    # say L346 tay
    old "Yeah, save the therapy session for TikTok."
    new "B:ari: Estamos a tentar fazer as pessoas dançar, não chorar."

    # say L347 pla
    old "Hey, that’s enough—"
    new "B:tay: Yeah, save the therapy session for TikTok."

    # say L349 sha
    old "Oh, and her backup tree finally speaks!"
    new "B:pla: Ei, chega—"

    # say L353 sha
    old "Maybe both of you should just quit now."
    new "Olá, nós não vamos-"

    # say L357 pla
    old "Hey, we are not-"
    new "Sabes o que é engraçado?"

    # say L361 bil
    old "You know what’s funny?"
    new "B:pla: Ei, nós não estamos a-"

    # say L362 bil
    old "You three spend twenty minutes jumping and screaming so hard nobody can even remember the melody."
    new "T(bil|tu|say): Vocês três passam vinte minutos a saltar e a gritar tanto que ninguém se lembra da melodia."

    # say L363 bil
    old "But sure, tell me my quiet voice is the problem."
    new "B:bil: Vocês três passam vinte minutos a saltar e a gritar tanto que ninguém se lembra da melodia."

    # say L368 bil
    old "It’s kinda cute how you go all out screaming and dancing just to get a little attention."
    new "T(bil|tu|say): É fofo como tu vais toda à frente a gritar e dançar só para chamar um pouco de atenção."

    # say L369 bil
    old "But volume isn’t talent, sweetie, glitter isn’t personality..."
    new "B:bil: É um bocadinho fofo como tu vais toda à louca a gritar e a dançar só para chamar um pouco de atenção."

    # say L370 bil
    old "And sequins don’t hide the fact you’re all noise and no soul."
    new "B:bil: Mas o volume não é talento, querida, o brilho não é personalidade..."

    # say L371 bil
    old "See you in the final, girls."
    new "B:bil: E as lantejoulas não escondem o facto de tu seres toda ruído e sem alma."

    # say L372 bil
    old "Try not to choke when someone actually feels something."
    new "B:bil: Até à final, raparigas."

    # say L377 pla
    old "And that's how it's done."
    new "B:bil: Tenta não engasgar quando alguém realmente sente algo."

    # say L383 pla
    old "Hey Billie, wait!"
    new "B:pla: E assim se faz."

    # say L386 pla
    old "Are you okay?"
    new "B:pla: Ei, Billie, espera!"

    # say L387 bil
    old "Yeah, that was nothing. They’re just a bunch of idiots."
    new "B:pla: Estás bem?"

    # say L388 pla
    old "Yeah, you’re right. But the way you shut them down? Damn, that was epic. I’ll never forget their faces haha."
    new "T: Tu tens razão. Mas a maneira como os calaste? Cara, isso foi épico. Nunca vou esquecer as suas caras, haha."

    # say L389 pla
    old "And what was that about seeing them in the finals? I thought you were dropping out after the audition... like you said."
    new "E o que foi isso sobre ver-te nas finais? Achava que ias desistir depois do casting... como disseste."

    # say L390 bil
    old "Drop out?"
    new "E o que foi isso de vermos eles na final? Eu pensei que tu fosses desistir depois do casting... como disseste."

    # say L391 bil
    old "Please. After that little circus?"
    new "B:bil: Desistir?"

    # say L392 bil
    old "I’m not giving them the satisfaction."
    new "T(bil|tu|say): Não vou dar-lhes a satisfação."

    # say L393 pla
    old "So you’re staying?"
    new "B:bil: Não vou dar-lhes essa satisfação."

    # say L394 bil
    old "Yeah, I’m staying."
    new "B:pla: Então vais ficar?"

    # say L395 bil
    old "And we’re winning."
    new "B:bil: Sim, estou a ficar."

    # say L396 pla
    old "Wait, for real?"
    new "T(pla|tu|say): Espera, a sério?"

    # say L397 bil
    old "Dead serious. You wanted me in this mess? Congratulations."
    new "B:pla: Espera, a sério?"

    # say L398 bil
    old "Now we’re doing it my way. Every day. No excuses."
    new "B:bil: Morto a sério. Quiseste que eu entrasse nesta confusão? Parabéns."

    # say L399 bil
    old "Come to my place so we can start rehearsing and get ready."
    new "B:bil: Agora fazemos às minhas horas. Todos os dias. Sem desculpas."

    # say L400 pla
    old "Of course I will!"
    new "B:bil: Vem à minha casa para começarmos a ensaiar e nos prepararmos."

    # say L401 bil
    old "Alright. I’ll see you later, then."
    new "B:pla: Claro que sim!"

    # say L402 pla
    old "S- sure, see you later."
    new "B:bil: Tudo bem, então. Até mais."

    # say L406 pla
    old "Like... damn, she walked out of here looking way more motivated than I expected."
    new "B:pla: Não pensei mesmo que ela fosse dizer que sim."

    # say L407 pla
    old "Heh, I guess I owe part of that to those bullies running their mouths earlier."
    new "B:pla:... Cara, ela saiu daqui com muito mais motivação do que eu esperava."

    # say L408 pla
    old "If they hadn’t pushed her buttons, she’d never have agreed that fast."
    new "B:pla: Heh, acho que devo parte disso aos valentões que estavam a falar mais cedo."

    # say L409 pla
    old "Phew... okay... okay, that’s one problem solved."
    new "B:pla: Se não tivessem tocado nesse assunto, ela nunca teria concordado tão depressa."

    # say L412 pla
    old "Oh man... this is gonna be a disaster."
    new "B:pla: Que raio é que eu sou suposto fazer num concurso de música quando não sei absolutamente nada sobre música?"

    # say L422 bil
    old "Took you long enough."
    new "Olá, desculpa. Fiquei preso com coisas."

    # say L423 pla
    old "Hey, sorry. Got caught up with stuff."
    new "T(pla|tu|say): Oi, desculpa. Fiquei preso com coisas."

    # say L424 bil
    old "Whatever. Come in, grandma’s out."
    new "B:pla: Olá, desculpa. Fiquei ocupado com coisas."

    # say L425 pla
    old "O- ok..."
    new "A:bil: Tudo bem, antes de começarmos, o que tu sabes sobre música?"

    # say L429 bil
    old "Alright, Before we dive in, what do you know about music?"
    new "B:pla: O- ok..."

    # say L430 pla
    old "Uhh... I can tell when a song’s good?"
    new "T(pla|tu|say): Hum... Consigo dizer quando uma música é boa?"

    # say L431 bil
    old "That’s it? No instruments? No singing lessons?"
    new "B:pla: Uhh... Consigo perceber quando uma música é boa?"

    # say L432 pla
    old "Uhh nope. Closest I got was humming in the shower."
    new "B:bil: É só isso? Nenhum instrumento? Nenhuma aula de canto?"

    # say L433 bil
    old "Hmph, great start."
    new "T(bil|tu|say): Hmph, ótimo começo."

    # say L434 bil
    old "Okay. We’re trying everything today. Voice, rhythm, keys. See what sticks to your zero skills."
    new "Tudo?"

    # say L435 pla
    old "Everything?"
    new "B:bil: Ok. Vamos experimentar tudo hoje. Voz, ritmo, teclas. Ver o que cola nas tuas zero habilidades."

    # say L436 bil
    old "Yes, we’re gonna find something you don’t completely suck at."
    new "B:pla: Tudo?"

    # say L437 bil
    old "I’m your coach now. And it’s gonna be brutal, because we’re winning this thing."
    new "B:bil: Sim, vamos encontrar algo em que tu não sejas completamente péssimo."

    # say L438 bil
    old "No mercy, no excuses. You wanted me in? Now you’re in all the way."
    new "B:bil: Sou o teu treinador agora. E vai ser brutal, porque vamos ganhar isto."

    # say L439 pla
    old "No pressure then."
    new "B:bil: Sem misericórdia, sem desculpas. Quis-te aqui dentro? Agora estás metido até ao fim."

    # say L440 bil
    old "All the pressure. We’re winning this, so get ready to sweat."
    new "B:pla: Sem pressão então."

    # say L441 pla
    old "*Gulp*..."
    new "B:bil: Toda a pressão. Vamos ganhar isto, então prepara-te para suar."

    # say L445 bil
    old "Ok, voice first. Easiest to test."
    new "T(bil|tu|say): Ok, voz primeiro. Mais fácil de testar. A:bil: Repete depois de mim, mesma melodia."

    # say L446 bil
    old "Repeat after me, same melody."
    new "A:bil: A tua vez."

    # say L451 bil
    old "Your turn."
    new "A:bil: Jesus Cristo. Estavas a tentar acertar em todas as notas erradas?"

    # say L455 bil
    old "Jesus Christ. Were you aiming for every wrong note?"
    new "B:bil: A tua vez."

    # say L456 pla
    old "I told you I can’t sing..."
    new "B:bil: Jesus Cristo. Estavas a tentar acertar em todas as notas erradas?"

    # say L457 bil
    old "Come on, try again. Feel the words."
    new "A:bil: Hmm, isso não foi cantar, foi um crime de ódio contra a música."

    # say L460 bil
    old "Hmm, that wasn’t singing, that was a hate crime against music."
    new "B:bil: Vamos, tenta de novo. Sente as palavras."

    # say L461 pla
    old "I’ve never had lessons, okay?"
    new "B:bil: Hmm, isso não foi cantar, foi um crime de ódio contra a música."

    # say L462 bil
    old "Noted. Voice is a disaster. Moving on."
    new "B:pla: Nunca tive aulas, ok?"

    # say L466 bil
    old "Keyboard. C major scale. Slow and clean."
    new "B:bil: Notado. A voz é um desastre. Vamos continuar."

    # say L467 pla
    old "I think I can do piano... kind of."
    new "A:bil: Ótimo! Tu acabaste de tocar uma sirene de carro."

    # say L470 bil
    old "Great! You just played a car alarm."
    new "B:pla: Acho que consigo tocar piano... mais ou menos."

    # say L471 pla
    old "My fingers won’t cooperate."
    new "B:bil: Ótimo! Tu acabaste de tocar o alarme de um carro."

    # say L472 bil
    old "Your fingers have the coordination of drunk spaghetti."
    new "T(bil|tu|say): Os teus dedos têm a coordenação de esparguete bêbado."

    # say L473 pla
    old "I’ve never touched a piano in my life..."
    new "B:bil: Os teus dedos têm a coordenação de esparguete bêbado."

    # say L474 bil
    old "Clearly, try again."
    new "B:pla: Nunca toquei num piano na minha vida..."

    # say L477 bil
    old "Wrong finger. Index, not pinky."
    new "T(bil|tu|say): Dedo errado. Indicador, não o mindinho."

    # say L478 pla
    old "Sorry, I guess I don’t have much finger dexterity."
    new "T: Desculpa, acho que não tenho muita destreza nos dedos."

    # say L479 bil
    old "Oh? No practice with the fingers, huh?"
    new "Oh? Sem prática com os dedos, hã?"

    # say L480 pla
    old "Hey!"
    new "B:bil: Oh? Sem prática com os dedos, hã?"

    # say L481 bil
    old "Just saying. You’ve got zero practice to do... in a lot of areas."
    new "B:pla: Ei!"

    # say L482 pla
    old "This is humiliating."
    new "B:bil: Só estou a dizer. Tu tens zero prática a fazer... em muitas áreas."

    # say L483 bil
    old "You´re right. Keyboard out. Next one."
    new "B:pla: Isto é humilhante."

    # say L487 bil
    old "Ok, let's try with congas. Hands only. Feel the groove."
    new "B:bil: Tens razão. Teclado fora. Vamos ao próximo."

    # say L488 bil
    old "Four simple beats. One-two-three-four. Like a heartbeat."
    new "B:bil: Ok, vamos tentar com congas. Só com as mãos. Sente o ritmo."

    # say L489 pla
    old "I got this."
    new "T: Tenho isto."

    # say L493 bil
    old "You're rushing a little... No problem. Try again."
    new "T(bil|tu|say): Estás a apressar-te um pouco... Não há problema. Tenta de novo."

    # say L494 pla
    old "Uhh ok..."
    new "Hmm, estás a arrastar-te um pouco agora."

    # say L497 bil
    old "Hmm, you’re dragging a little now."
    new "B:pla: Uhh ok..."

    # say L498 bil
    old "All good, here we go."
    new "B:bil: Hmm, estás a arrastar-te um pouco agora."

    # say L501 bil
    old "No, not quite my tempo."
    new "B:bil: Tudo bem, vamos lá."

    # say L502 pla
    old "What does that even—"
    new "T: O que é que isso quer dizer—"

    # say L507 pla
    old "Uhh... I... I d- don’t kn-"
    new "B: pla: Mas o que é que—"

    # say L508 bil
    old "Tell me are you a rusher, are you a dragger, or are you going to be ON MY FUCKING TIME!?"
    new "B:pla: Uhh... Eu... Eu n- não s-"

    # say L509 pla
    old "W- what?!"
    new "B:bil: Diz-me, és um apressado, és um demorado, ou vais estar NA MINHA PORRA DE RITMO!?"

    # say L510 bil
    old "Ugh... Nevermind. Mostly. Rhythm is dead."
    new "A:pla: Isto é inútil. Sou péssima em tudo."

    # say L515 pla
    old "This is pointless. I suck at everything."
    new "T: Tu és inútil em tudo. Isto é inútil."

    # say L516 pla
    old "I’m just gonna embarrass you in front of the whole school."
    new "B: pla: Isto é inútil. Eu sou péssimo em tudo."

    # say L518 pla
    old "I’m dragging you down. You saw those girls. They’re pros."
    new "B:pla: Vou apenas embaraçar-te na frente de toda a escola."

    # say L519 pla
    old "I’m the weak link. Maybe you should just go solo."
    new "B: pla: Estou a arrastar-te para baixo. Viste aquelas raparigas. Elas são profissionais."

    # say L520 bil
    old "Are you quitting on me right now?"
    new "T(bil|tu|say): Tu estás a desistir de mim agora?"

    # say L521 pla
    old "I’m just being realistic."
    new "T: Não estou a desistir, estou apenas a ser realista."

    # say L522 pla
    old "I don’t want to be the reason you lose."
    new "B:pla: Estou só a ser realista."

    # say L523 bil
    old "You’re the reason I’m even doing this."
    new "B:pla: Não quero ser o motivo para tu perdes."

    # say L524 bil
    old "You pushed me. Remember? 'You’ve got talent, don’t hide it.' Ring a bell?"
    new "B:bil: Tu és a razão pela qual estou a fazer isto."

    # say L525 bil
    old "So no. You don’t get to bail when it’s your turn."
    new "B:bil: Tu empurraste-me. Lembras-te? ‘Tu tens talento, não o escondas.’ Toca-te a campainha?"

    # say L526 pla
    old "That’s different. You’re actually good."
    new "B:bil: Nem penses. Não te safas quando é a tua vez."

    # say L527 bil
    old "I wasn’t always. And I’m not doing this alone."
    new "Tu não és inútil."

    # say L528 pla
    old "But I’m useless."
    new "B:bil: Não sempre fui. E não estou a fazer isto sozinho."

    # say L529 bil
    old "You’re not useless. You’re untrained. And I’m fixing that."
    new "Tu não és inútil. Tu estás desTreinado. E eu vou resolver isso."

    # say L530 pla
    old "This is gonna be tough... I mean, I basically suck at everything."
    new "B:bil: Não és inútil. Estás por treinar. E estou a resolver isso."

    # say L531 bil
    old "Hmm, maybe not at everything. Wait here."
    new "B:pla: Isto vai ser difícil... Quero dizer, eu sou péssimo em tudo."

    # say L535 bil
    old "This was my dad’s."
    new "B:bil: Hmm, talvez não em tudo. Espera aqui."

    # say L536 pla
    old "Whoa..."
    new "B:bil: Isto era do meu pai."

    # say L537 bil
    old "He taught me my first chords on this."
    new "B:pla: Whoa..."

    # say L539 bil
    old "Now it’s yours to borrow."
    new "B:bil: Ele ensinou-me as minhas primeiras notas com isto."

    # say L540 pla
    old "Ohh.. I- I’ll be careful."
    new "T: Ohh.. V-vou ter cuidado."

    # say L541 bil
    old "You better. If you break it, I break you."
    new "B:pla: Ohh.. V-vou ter cuidado."

    # say L542 pla
    old "Noted."
    new "B:bil: Tu melhoras. Se quebrares, eu quebro-te."

    # say L543 bil
    old "We’ll start with three chords. Easiest thing in the world."
    new "V: Vamos começar com três acordes. A coisa mais fácil do mundo."

    # say L544 bil
    old "You’re gonna learn them. Even if I have to sit on you."
    new "B:bil: Vamos começar com três acordes. A coisa mais fácil do mundo."

    # say L545 pla
    old "That’s... motivational?"
    new "B:bil: Vais aprendê-los. Mesmo que tenha de me sentar em cima de ti."

    # say L546 bil
    old "Damn right it is."
    new "B:pla: Isso... é motivador?"

    # say L548 bil
    old "Alright. Before we even start real lessons, you need to get familiar with that guitar."
    new "B:bil: Claro que é."

    # say L549 pla
    old "Yeah, I figured. But, what should I actually do with it?"
    new "B:bil: Tudo bem. Antes de começarmos as aulas a sério, precisas de te familiarizar com essa guitarra."

    # say L550 bil
    old "Well, familiarize yourself with the strings, stop poking the guitar like it’s a wild animal."
    new "B:pla: Yeah, I figured. But, what should I actually do with it?"

    # say L551 bil
    old "And please! Use your fingers. Right now they move like you borrowed them from a mannequin."
    new "B:bil: Bem, familiariza-te com as cordas, para de tocar a guitarra como se fosse um animal selvagem."

    # say L552 pla
    old "Come on, they’re not that bad..."
    new "B:bil: E por favor! Usa os dedos. Agora parecem que foram emprestados de um manequim."

    # say L553 bil
    old "Relly? You need agility. Flexibility. Some kind of life in those fingers."
    new "T(bil|tu|say): Realmente? Precisas de agilidade. Flexibilidade. Alguma espécie de vida nesses dedos."

    # say L554 pla
    old "Okay, so... practice the strings? Just messing around with them?"
    new "B:bil: Relly? Precisas de agilidade. Flexibilidade. Alguma espécie de vida nesses dedos."

    # say L555 bil
    old "Exactly. Touch them, get used to the tension, the spacing, the feel."
    new "T(bil|tu|say): Exatamente. Toca neles, habitua-te à tensão, ao espaçamento, à sensação."

    # say L556 bil
    old "Learn what each string does when you press it... without crying."
    new "B:bil: Exatamente. Toca neles, habitua-te à tensão, ao espaçamento, ao tacto."

    # say L557 pla
    old "Well, I can do that."
    new "B:bil: Aprende o que cada string faz quando a pressionas... sem chorar."

    # say L558 bil
    old "Good. Because in your current state, I can’t teach you anything yet."
    new "B:pla: Bem, posso fazer isso."

    # say L559 pla
    old "That bad, huh?"
    new "B:bil: Bom. Porque no teu estado atual, não posso ensinar-te nada ainda."

    # say L560 bil
    old "Let’s just say your dexterity is... nonexistent."
    new "T(bil|tu|say): Vamos dizer que a tua destreza é... inexistente."

    # say L561 bil
    old "Which tells me you haven’t used those fingers for anything interesting."
    new "B:bil: Vamos dizer que a tua destreza é... inexistente."

    # say L562 pla
    old "H- hey..."
    new "B:bil: O que me diz que esses dedos não têm feito nada interessante."

    # say L563 bil
    old "Point is: practice. Move your fingers up and down the strings. Build some coordination."
    new "B: H- hey..."

    # say L564 pla
    old "Alright. I’ll work on that."
    new "B:bil: O ponto é: prática. Move os dedos para cima e para baixo nas cordas. Constrói alguma coordenação."

    # say L565 bil
    old "And once your hands stop embarrassing me, come back."
    new "B:pla: Tudo bem. Vou trabalhar nisso."

    # say L566 pla
    old "Ok, ok, got it."
    new "B:bil: E quando as tuas mãos deixarem de me embaraçar, volta."

    # say L567 bil
    old "Good. But for today, we’re done."
    new "Já?"

    # say L568 pla
    old "Already?"
    new "B:bil: Bom. Mas para hoje, já chega."

    # say L569 bil
    old "Yeah. You should leave before my grandma shows up."
    new "T(bil|tu|say): Já. Deves ir antes que a minha avó apareça."

    # say L570 pla
    old "W-what? Why?"
    new "A:bil: Não quero que ela me encontre aqui com todos estes instrumentos e contigo."

    # say L571 bil
    old "I don’t want her finding me here with all these instruments and with you."
    new "T(bil|tu|say): Não quero que ela me encontre aqui com todos estes instrumentos e contigo."

    # say L572 bil
    old "She’ll think I’m getting back into music."
    new "B:bil: Não quero que ela me encontre aqui com todos estes instrumentos e contigo."

    # say L573 pla
    old "But... what’s wrong with that?"
    new "B:bil: Ela vai pensar que estou a voltar à música."

    # say L574 bil
    old "Not your problem. Don’t dig into it."
    new "B:pla: Mas... o que há de errado com isso?"

    # say L575 pla
    old "Alright... Alright."
    new "T: Tudo bem... Tudo bem."

    # say L576 bil
    old "So practice. When you're actually ready, come find me."
    new "B:pla: Tudo bem... Tudo bem."

    # say L577 pla
    old "I will. I’ll get better and I’ll be back soon."
    new "B:bil: Então, pratica. Quando estiveres realmente pronta, vem encontrar-me."

    # say L587 pla
    old "It’s really late now, I should leave guitar practice for tomorrow."
    new "T(pla|tu|say): Já é muito tarde, devo deixar a prática de guitarra para amanhã."

    # say L590 pla
    old "I’d better let my fingers rest a bit, or they’re gonna start bleeding..."
    new "T(pla|tu|say): Devia deixar os meus dedos descansar um bocado, senão começam a sangrar..."

    # say L594 pla
    old "Okay... here we go. First time ever touching a real guitar."
    new "B:pla: Devia deixar os meus dedos descansar um bocado, senão começam a sangrar..."

    # say L595 pla
    old "This thing’s heavier than it looks."
    new "T(pla|tu|say): Esta coisa é mais pesada do que parece."

    # say L596 pla
    old "And it smells like old wood... it’s nice though."
    new "B:pla: Esta coisa é mais pesada do que parece."

    # say L597 pla
    old "Alright... let’s see if those YouTube videos helped at all."
    new "T(pla|tu|say): Tudo bem... vamos ver se esses vídeos do YouTube ajudaram em algo."

    # say L598 pla
    old "Watched like three tutorials last night. How hard can open chords be?"
    new "T(pla|tu|say): Vi três tutoriais ontem à noite. Quão difícil podem ser as cordas abertas?"

    # say L604 pla
    old "Ow! That buzzed like a dying bee."
    new "C:pla: As cordas doem mais do que eu esperava."

    # say L605 pla
    old "Strings hurt more than I expected."
    new "T(pla|tu|say): As cordas doem mais do que eu esperava."

    # say L606 pla
    old "Let’s try again... second fret, second string... mute the others..."
    new "T: Vamos tentar de novo... segundo traste, segunda corda... abafa as outras..."

    # say L616 pla
    old "She’s gonna murder me if I don’t improve."
    new "B:pla: Sou literalmente o pior guitarrista da história. Zero destreza."

    # say L622 pla
    old "Okay... that one almost sounded like an actual chord."
    new "B:pla: Tenho de continuar a praticar."

    # say L623 pla
    old "Progress! Tiny, painful progress."
    new "Chega por hoje. Os dedos estão oficialmente mortos."

    # say L624 pla
    old "Enough for today. Fingers are officially dead."
    new "Basta para hoje. Os dedos estão oficialmente mortos."

    # say L625 pla
    old "Tomorrow I’ll be slightly less terrible."
    new "B:pla: Chega por hoje. Os dedos estão oficialmente mortos."

    # say L636 pla
    old "Okay, even if it’s tough, I’ve gotta keep practicing. I need to get better at guitar or Billie’s gonna kill me."
    new "B:pla: Amanhã vou ser ligeiramente menos terrível."

    # say L637 pla
    old "My fingers are still sore from last time. Awesome."
    new "B:pla: Okay, mesmo que seja difícil, tenho de continuar a treinar. Preciso de melhorar na guitarra ou a Billie vai matar-me. T(pla|tu|say): Os meus dedos ainda estão doridos da última vez. Ótimo. A:pla: Suspiro... vamos tentar de novo."

    # say L638 pla
    old "Sigh... let’s try this again."
    new "B:pla: Os meus dedos ainda estão doloridos da última vez. Ótimo."

    # say L644 pla
    old "Still buzzing on the high E. Damn it!"
    new "B:pla: Suspiro... vamos tentar de novo."

    # say L645 pla
    old "Left hand cramps, right hand can’t keep time."
    new "B:pla: Ainda a vibrar na E aguda. Merda!"

    # say L646 pla
    old "Come on, come on, again."
    new "B:pla: A mão esquerda está a ficar dormente, a mão direita não consegue manter o ritmo."

    # say L649 pla
    old "Rhythm’s all over the place. Why can’t I get this?"
    new "B:pla: Vamos, vamos, de novo."

    # say L650 pla
    old "I thought I’d be better by now. This is torture."
    new "B:pla: O ritmo está todo descontrolado. Porque é que não consigo acertar?"

    # say L657 pla
    old "Nope. Still sounds like crap."
    new "B:pla: Hmm, mais uma passagem. Mudanças limpas ou nada feito."

    # say L658 pla
    old "Fingers raw, brain fried, and zero improvement."
    new "B:pla: Não. Ainda soa mal."

    # say L659 pla
    old "That’s it for now. Can’t force it."
    new "B:pla: Dedos doloridos, cérebro frito, e zero progresso."

    # say L660 pla
    old "Tomorrow. Maybe it’ll click tomorrow."
    new "B:pla: É isso por agora. Não posso forçar."

    # say L671 pla
    old "I’m not getting anywhere on my own. This isn’t working."
    new "B:pla: Amanhã. Talvez amanhã faça sentido."

    # say L674 pla
    old "That’s it for today. Tomorrow, I’m going to her."
    new "B:pla: É hora de lhe enviar uma mensagem. Não posso ficar parado para sempre."

    # say L683 bil
    old "Hey, you look like someone kicked your puppy."
    new "B:pla: É isso para hoje. Amanhã, vou lá."

    # say L685 bil
    old "You texted like the world was ending. What's up?"
    new "A:pla: É a guitarra. Tentei... tentei mesmo."

    # say L686 pla
    old "It's the guitar. I tried... really tried."
    new "E?"

    # say L687 bil
    old "And?"
    new "B:pla: É a guitarra. Tentei... realmente tentei."

    # say L688 pla
    old "Nothing. Fingers won't move right, everything buzzes. I'm stuck."
    new "T(pla|tu|say): Nada. Os dedos não se movem direito, tudo zune. Estou preso."

    # say L689 bil
    old "Stuck over just a couple of days? That’s dramatic."
    new "T(bil|tu|say): Preso em apenas alguns dias? Isso é dramático."

    # say L690 pla
    old "I'm serious. YouTube videos, hours... still crap."
    new "B:bil: Preso só uns dias? Isso é dramático."

    # say L691 bil
    old "Okay, okay. Let's fix it. Room. Now."
    new "B:pla: Estou a falar a sério. Vídeos do YouTube, horas... ainda é lixo."

    # say L695 bil
    old "Okay, spill. What exactly did you try?"
    new "B:bil: Okay, okay. Vamos arranjar isto. Quarto. Agora."

    # say L696 pla
    old "Well, I watched videos, did the finger positions, strummed, practiced for hours... and still nothing."
    new "B:bil: Okay, conta. O que é que tentaste exatamente?"

    # say L697 bil
    old "Okay, relax. You’re not hopeless, just untrained."
    new "B:pla: Bem, vi vídeos, fiz as posições com os dedos, toquei, pratiquei durante horas... e ainda nada."

    # say L698 pla
    old "Hmm, I feel hopeless."
    new "B:bil: Okay, relaxa. Não és hopeless, apenas não treinado."

    # say L699 bil
    old "Well, it does at first. That's normal. We'll figure it out."
    new "T(bil|tu|say): Bem, é normal sentir-se assim no início. Vamos descobrir uma solução."

    # say L700 pla
    old "Really?"
    new "B:bil: Bem, é normal no início. Vamos descobrir."

    # say L701 bil
    old "Yeah. I'm your coach. Brutal, but we'll get you there."
    new "B:pla: Mesmo?"

    # say L702 bil
    old "First, let me show you how it's done. Watch."
    new "B:bil: Sim. Sou o teu treinador. Duro, mas vamos lá chegar."

    # say L709 pla
    old "Holy... you're amazing."
    new "T: Holy... tu és incrível."

    # say L710 pla
    old "It looks so easy when you do it."
    new "B:pla: Santo... tu és incrível."

    # say L711 bil
    old "It’s just practice. Your turn."
    new "T(bil|tu|say): É só prática. A tua vez."

    # say L715 pla
    old "Uhh, like... this?"
    new "T: Hum, assim...?"

    # say L718 bil
    old "Buzzing. Press harder on the strings."
    new "ZZZ...ZZZ. Pressa mais forte nas cordas."

    # say L719 pla
    old "Ow... got it."
    new "B:bil: A zumbir. Pressiona mais as cordas."

    # say L723 bil
    old "Better. Still ugly, but better."
    new "T(tu): Melhor. Ainda feio, mas melhor."

    # say L724 bil
    old "Try shifting your hand a bit. Find a spot that actually sounds alive."
    new "B:bil: Melhor. Ainda feio, mas melhor."

    # say L725 pla
    old "Switching... crap."
    new "T: A mudar... merda."

    # say L729 bil
    old "Slow. Don't rush the change."
    new "É como se os meus dedos me odiassem."

    # say L730 pla
    old "It's like my fingers hate me."
    new "B:bil: Devagar. Não corras com a mudança."

    # say L731 bil
    old "They're lazy. Make 'em work."
    new "É como se os meus dedos me odiassem."

    # say L732 pla
    old "Like this...."
    new "Não, não estás a cobrir as cordas corretamente."

    # say L735 bil
    old "No, you're not covering the strings properly."
    new "B:pla: Assim..."

    # say L736 bil
    old "Closer. But your fingers are stiff as boards."
    new "Não, tu não estás a cobrir as cordas corretamente."

    # say L737 pla
    old "Yeah... no dexterity."
    new "T(tu): Sim... sem destreza."

    # say L738 bil
    old "Reset your hand. Try the last position. Light touch, then press."
    new "B:pla: Yeah... sem destreza."

    # say L739 pla
    old "Uhh okay..."
    new "B:bil: Reajusta a mão. Tenta a última posição. Toque leve, depois pressiona."

    # say L743 pla
    old "I- I can't. This is stupid."
    new "T(pla|tu|say): I- I não posso. Isto é estúpido."

    # say L747 pla
    old "You're wasting your time with me."
    new "T(pla|tu|say): Estás a perder o teu tempo comigo."

    # say L748 pla
    old "You know what? I should probably go."
    new "Não."

    # say L751 bil
    old "No."
    new "B- mas..."

    # say L754 pla
    old "B- but-"
    new "B: Não."

    # say L760 bil
    old "You're frustrated. I get it."
    new "T: Tu estás frustrado. Entendo."

    # say L761 pla
    old "I suck. Completely."
    new "T(pla|tu|say): Sou um fracasso. Totalmente."

    # say L762 bil
    old "You don't suck. It's hard. Not everyone even tries."
    new "T(bil|tu|say): Tu não és mau. É difícil. Nem todos sequer tentam."

    # say L763 pla
    old "I know... but I’m failing so bad."
    new "T: Eu sei... mas estou a falhar tanto."

    # say L764 bil
    old "Trying and failing is braver than not trying at all."
    new "T(bil|tu|say): Tentar e falhar é mais corajoso do que nem tentar."

    # say L765 pla
    old "Feels like I'm just letting you down."
    new "B:bil: Tentar e falhar é mais corajoso do que não tentar de todo."

    # say L766 bil
    old "You’re not. You’re working hard, and that means a lot."
    new "T(bil|tu|diz): Tu não estás. Estás a trabalhar muito, e isso significa muito."

    # say L767 pla
    old "But I have no talents. Zero. I'm good at... existing?"
    new "B:bil: Não estás. Estás a trabalhar muito, e isso é importante."

    # say L768 bil
    old "What do you mean you have no talents? Now you’re just being an idiot, you’ve got plenty."
    new "T(bil|tu|say): Que é que queres dizer com não teres talentos? Agora é que estás a ser parvo, tu tens imensos."

    # say L769 bil
    old "You're friendly. Always helping everyone, even when it's inconvenient."
    new "B:bil: O que queres dizer com não teres talentos? Agora é que estás a ser parvo, tu tens imensos."

    # say L770 pla
    old "I guess..."
    new "T(pla|tu|say): Acho que sim..."

    # say L771 bil
    old "Stubborn too. Look at this, we wouldn’t even be in this mess if you hadn’t pushed and pushed, even when I almost hit you."
    new "B:pla: Acho que sim..."

    # say L772 pla
    old "Yeah, but that backfired."
    new "B:bil: Teimoso também. Olha só, nem estaríamos nesta confusão se tu não tivesse insistido tanto, mesmo quando quase te atropelei."

    # say L773 bil
    old "It didn't. It got us here."
    new "B:pla: Sim, mas isso deu errado."

    # say L774 bil
    old "And you're funny. That dying cat voice? Gold."
    new "T(bil|tu|say): E tu és engraçado. Essa voz de gato moribundo? Ouro."

    # say L775 pla
    old "Those aren’t really talen-"
    new "T: Esses não são realmente talentos..."

    # say L777 bil
    old "Also... you’re kinda cute, in that awkward, pushy way."
    new "B:pla: Esses não são realmente talentos..."

    # say L778 pla
    old "A-are you serious?"
    new "T(pla|tu|say): A-estás a falar a sério?"

    # say L779 bil
    old "And now that I think about it... you’ve got a huge talent down there, huh..."
    new "T(bil|tu|say): E agora que penso nisso... tu tens um talento enorme aí embaixo, hã..."

    # say L781 bil
    old "Well... I mean, you do have talents after all. You see it now?"
    new "B:bil: E agora que penso nisso... tu tens um talento enorme aí embaixo, hã..."

    # say L782 pla
    old "Uhh... I guess, but what about the guitar?"
    new "B:bil: Bem... Quero dizer, tu tens talentos afinal. Agora vês?"

    # say L783 bil
    old "Well, guitar's just one more to unlock. But those fingers... they really need waking up."
    new "B:pla: Uhh... Acho que sim, mas e a guitarra?"

    # say L785 pla
    old "Yeah, I know... but how am I supposed to do that?"
    new "B:bil: Bem, a guitarra é só mais uma para desbloquear. Mas esses dedos... realmente precisam acordar."

    # say L787 bil
    old "You know what, I have an idea."
    new "O-O que é que tu estás a fazer?"

    # say L789 pla
    old "W- whaat a- are you d- doing?"
    new "B:bil: Sabes o que, tenho uma ideia."

    # say L791 bil
    old "Well, I think you need some extra motivation with those sausage fingers, you know?"
    new "B:pla: O- o que e- estás a fazer?"

    # say L794 pla
    old "Hey, what the Fuc-!"
    new "B:bil: Bem, acho que precisas de um incentivo extra com esses dedos de salsicha, sabes?"

    # say L803 pla
    old "O- okay."
    new "T(pla|tu|say): O- okay."

    # say L805 pla
    old "Like this? Am I doing it right?"
    new "T(pla|tu|say): Assim? Estou a fazer bem?"

    # say L806 bil
    old "Nngh—yeah. Exactly like that..."
    new "B:pla: Assim? Estou a fazer bem?"

    # say L807 bil
    old "See? you're learning."
    new "B:bil: Nngh—sim. Exactamente assim..."

    # say L808 pla
    old "({i}This is insane... and it's working?{/i})"
    new "T: ({i}Isto é louco... e está a resultar?{/i})"

    # say L809 bil
    old "Mmm, nice. Now pick up the pace. Let’s see if you can keep your finesse while speeding up."
    new "Mmm, bom. Agora aumenta o ritmo. Vamos ver se consegues manter a elegância enquanto aceleras."

    # say L811 bil
    old "Tell me how they feel right now."
    new "Mmm, bom. Agora aumenta o ritmo. Vamos ver se consegues manter a elegância enquanto aceleras. ZZZ…ZZZ"

    # say L813 pla
    old "Hot... heavy... and every time I squeeze they bounce a little. It's insane."
    new "T: Quente... pesado... e cada vez que aperto eles saltam um pouco. É incrível."

    # say L814 bil
    old "Good feedback. Noted."
    new "B:pla: Quente... pesado... e cada vez que aperto eles saltam um pouco. É incrível."

    # say L815 bil
    old "Keep going. Feel the rhythm."
    new "T(bil|tu|say): Continua. Sente o ritmo."

    # say L816 pla
    old "I... I feel something."
    new "T: Eu... Eu sinto algo."

    # say L817 bil
    old "Yeah, I noticed. Looks like your other talent’s waking up, huh?"
    new "B:pla: Eu... Eu sinto algo."

    # say L819 pla
    old "Oh shit... sorry!"
    new "B:bil: Yeah, I noticed. Parece que o teu outro talento está a acordar, hã?"

    # say L820 bil
    old "Oh, come on, you're literally groping my tits..."
    new "B:pla: Oh merda... desculpa!"

    # say L822 bil
    old "You know what? Come here, let me show you one of my hidden talents too..."
    new "B:bil: Oh, vamos lá, tu estás literalmente a apalpar os meus peitos..."

    # say L823 bil
    old "This throat does more than just sing, you know?"
    new "B:bil: Sabes o quê? Vem cá, deixa-me mostrar-te um dos meus talentos escondidos..."

    # say L828 pla
    old "Hooooly shit!"
    new "T: Hooooly shit!"

    # say L829 bil
    old "So... you like my other talent too, huh?"
    new "B:pla: Hooooly shit!"

    # say L830 pla
    old "Oh, yeah, it feels so good..."
    new "B:bil: Então... tu também gostas do meu outro talento, hã?"

    # say L831 bil
    old "Mmm... I’ve missed this since that stupid spin-the-bottle game."
    new "B:pla: Oh, yeah, sente-se tão bem..."

    # say L832 pla
    old "You... you have?"
    new "B:bil: Mmm... Senti falta disto desde aquele jogo estúpido de roda da sorte."

    # say L833 bil
    old "Shut up. Let me show you my real talent."
    new "B:pla: Tu... tu tens?"

    # say L861 bil
    old "So... I guess we made some progress today."
    new "B:bil: Cala-te. Deixa-me mostrar-te o meu verdadeiro talento."

    # say L862 pla
    old "Oh yeah, a lot."
    new "A:bil: Refei-me com a guitarra."

    # say L864 bil
    old "I meant with the guitar."
    new "B:pla: Oh yeah, muito."

    # say L865 pla
    old "Oh, right. Yes. That too."
    new "B:bil: Refere-te à guitarra."

    # say L866 bil
    old "And from what I see, you definitely have plenty of motivation now."
    new "B:pla: Oh, certo. Sim. Isso também."

    # say L867 pla
    old "Oh, that’s for sure."
    new "T(pla|tu|say): Oh, isso é certo."

    # say L868 bil
    old "Good. Because that whole quit-the-contest nonsense better be gone."
    new "B:pla: Oh, isso é certo."

    # say L869 pla
    old "Of course. I’m not quitting."
    new "T(pla|tu|say): Claro. Não vou desistir."

    # say L870 bil
    old "Perfect. Then keep practicing at home like you’ve been doing."
    new "B:pla: Claro. Não vou desistir."

    # say L871 bil
    old "Your fingers still need work... a lot of work."
    new "T: Os teus dedos ainda precisam de trabalho... muito trabalho."

    # say L872 pla
    old "I’ll practice every day. I actually want to improve."
    new "B:bil: Os teus dedos ainda precisam de trabalho... muito trabalho."

    # say L873 bil
    old "Hmm. And if you need something, just tell me."
    new "B:pla: Vou praticar todos os dias. Na verdade, quero melhorar."

    # say L874 pla
    old "I will. Thanks... seriously."
    new "B:bil: Hmm. E se precisares de algo, diz-me."

    # say L875 bil
    old "Alright. Let’s leave it here for today."
    new "B:pla: Vou. Obrigado... a sério."

    # say L876 bil
    old "Go home before my grandma shows up."
    new "B:bil: Tudo bem. Vamos parar por hoje."

    # say L877 pla
    old "Yeah, I should. I’ll come back soon."
    new "B:bil: Vai para casa antes que a minha avó apareça."

    # say L878 bil
    old "You better."
    new "B:pla: Sim, devo. Volto já."

    # say L889 pla
    old "Okay... it’s still hard, but I can’t skip practice now."
    new "T: Okay... ainda é difícil, mas não posso deixar de treinar agora."

    # say L890 pla
    old "I’m not great yet, but I’m not totally hopeless either."
    new "B:pla: Okay... ainda é difícil, mas não posso deixar de treinar agora. T(pla|tu|say): Ainda não sou ótima, mas também não sou totalmente desesperada. A:pla: Tudo bem. Vamos ver se consigo fazer um pouco melhor hoje."

    # say L891 pla
    old "Alright. Let’s see if I can do this a little better today."
    new "B:pla: Ainda não sou o melhor, mas também não sou totalmente inútil."

    # say L898 pla
    old "Hey... that one didn’t buzz as bad."
    new "B:pla: Tudo bem. Vamos ver se consigo fazer melhor hoje."

    # say L899 pla
    old "Still not perfect... but it sounded more like a chord this time."
    new "B:pla: Ei... aquele não zumbiu tanto."

    # say L900 pla
    old "Hand’s tired, but it’s moving better."
    new "B:pla: Ainda não está perfeito... mas soou mais como um acorde desta vez."

    # say L901 pla
    old "Ok, again. Same thing."
    new "B:pla: A mão está cansada, mas está a mover-se melhor."

    # say L905 pla
    old "Rhythm’s still messy... but I didn’t completely lose it."
    new "T(pla|tu|say): O ritmo ainda está desorganizado... mas não perdi tudo."

    # say L907 pla
    old "({i}Okay... that’s something. I didn’t feel that before.{/i})"
    new "T(pla|tu|say): ({i}Ok... isso é algo. Não senti isso antes.{/i})"

    # say L914 pla
    old "Still rough... but not total garbage."
    new "T(pla|tu|say): Ainda áspero... mas não é lixo total."

    # say L915 pla
    old "That sounded... closer."
    new "B:pla: Ainda áspero... mas não é lixo total."

    # say L916 pla
    old "Yeah. Not there yet, but it’s moving."
    new "B:pla: Isso soou... mais perto."

    # say L917 pla
    old "Enough for today. Don’t want to ruin what I actually did right."
    new "B:pla: Sim. Ainda não, mas está a mover-se."

    # say L918 pla
    old "Tomorrow... let’s see if it gets even better."
    new "A:bil: Oh, olha quem apareceu."

    # say L931 bil
    old "Oh, look who showed up."
    new "B:pla: Amanhã... vamos ver se fica ainda melhor."

    # say L932 pla
    old "Yeah, I wanted to practice with you again."
    new "B:bil: Olha quem apareceu."

    # say L933 bil
    old "Right, you texted about that. How's it going?"
    new "B:pla: Sim, queria praticar contigo de novo."

    # say L934 pla
    old "Uhh, better than before... kinda."
    new "B:bil: Certo, tu mandaste uma mensagem sobre isso. Como está a correr?"

    # say L935 bil
    old "Oh really? Hah. I need to see that to believe it."
    new "B:pla: Uhh, melhor do que antes... tipo."

    # say L936 bil
    old "Come on. Let’s go to my room and talk properly."
    new "B:bil: Oh realmente? Hah. Preciso ver isso para acreditar."

    # say L939 bil
    old "Okay, spill. What did you do these days?"
    new "B:bil: Vamos. Vamos para o meu quarto e falamos direito."

    # say L940 pla
    old "Honestly... a lot. I practiced every day. My fingers feel way more alive now."
    new "B:bil: Okay, conta. O que fizeste nestes dias?"

    # say L941 bil
    old "Good. About time they woke up from the dead."
    new "B:pla: Honestamente... muito. Treinei todos os dias. Agora os meus dedos parecem bem mais vivos."

    # say L942 pla
    old "Yeah, but... I feel like I hit a wall again."
    new "T: Sim, mas... Sinto que bati num muro de novo."

    # say L943 bil
    old "Hmm. Typical. Let me see. Take the guitar."
    new "B:pla: Sim, mas... Sinto que bati num muro outra vez."

    # say L949 pla
    old "Alright... here goes."
    new "B:bil: Hmm. Típico. Deixa-me ver. Pega na guitarra."

    # say L953 bil
    old "Huh... pressure’s steadier. The tone’s still messy, but at least you’re not fighting the guitar anymore."
    new "T(bil|tu|say): Huh... a pressão está mais estável. O tom ainda está desorganizado, mas pelo menos já não estás a lutar contra a guitarra."

    # say L954 pla
    old "Yeah, I feel more control. I can switch positions smoother now."
    new "B:bil: Huh... a pressão está mais constante. O tom ainda está desorganizado, mas pelo menos já não estás a lutar com a guitarra."

    # say L955 bil
    old "Still too slow. But hey, your hand is finally acting like it belongs to a living person."
    new "B:pla: Sim, sinto mais controlo. Consigo mudar de posição com mais suavidade agora."

    # say L956 bil
    old "Not bad. Your fingers actually woke up this time."
    new "T(bil|tu|say): Não está mal. Desta vez os teus dedos acordaram mesmo."

    # say L957 pla
    old "Yeah, but that’s the problem. I think I hit my limit again. I can’t push past this alone."
    new "B:bil: Não foi mal. Os teus dedos acordaram desta vez."

    # say L960 pla
    old "Honestly... I was hoping you could help me practice again."
    new "B:pla: Sim, mas esse é o problema. Acho que atingi meu limite de novo. Não consigo avançar sozinho."

    # say L961 bil
    old "Huh?"
    new "T(bil|tu|say): Hã?"

    # say L962 bil
    old "So that’s why you came back. You want more 'practice'."
    new "T(bil|tu|say): Então foi por isso que voltaste. Queres mais 'prática'."

    # say L963 pla
    old "Exactly. Something a bit more advanced. Something that forces my fingers to—"
    new "B:bil: É por isso que voltaste. Queres mais 'prática'."

    # say L964 bil
    old "Oh, I see where this is going."
    new "T(bil|tu|say): Oh, percebo para onde isto vai."

    # say L965 bil
    old "Yeah, sure. More 'advanced practice', right?"
    new "B:bil: Oh, percebo para onde isto vai."

    # say L966 pla
    old "Exactly! I need something beyond the basics. I’m not improving anymore."
    new "T: Exatamente! Preciso de algo além do básico. Não estou a melhorar mais."

    # say L967 bil
    old "Alright, alright, I get it. No need to act innocent."
    new "B:pla: Exactamente! Preciso de algo além do básico. Não estou a melhorar mais."

    # say L969 bil
    old "Come on, don’t be shy. I know what you’re actually here for."
    new "T(bil|tu|say): Vamos, não sejas tímido. Sei bem para quê estás realmente aqui."

    # say L971 pla
    old "No, no, that’s not—"
    new "B:bil: Vamos, não sejas tímido. Sei bem porquê é que estás aqui."

    # say L972 bil
    old "Stop overthinking. You came to practice."
    new "B:pla: Não, não, isso não é—"

    # say L973 bil
    old "So let’s practice."
    new "B:bil: Para de pensar demais. Tu vieste para praticar."

    # say L975 pla
    old "({i}Oh God, they feel incredible...{/i})"
    new "T: ({i}Oh Deus, eles são incríveis...{/i})"

    # say L978 bil
    old "Keep that rhythm. Don't rush the ‘practice’."
    new "B:bil: Lá. Começa com as palmas da mão. sente como são macias quando vais devagar."

    # say L981 bil
    old "Come on, a little more pressure. You know what I like."
    new "T(bil|tu|say): Vai, um pouco mais de pressão. Tu sabes o que eu gosto."

    # say L983 pla
    old "L-like... this?"
    new "B:bil: Vamos, um pouco mais de pressão. Tu sabes o que eu gosto."

    # say L984 bil
    old "Yes... perfect. You're doing better than I expected."
    new "T(bil|tu|say): Sim... perfeito. Estás a fazer melhor do que eu esperava."

    # say L985 pla
    old "Your nipples... they're getting hard. Does that mean I'm doing good?"
    new "B:bil: Sim... perfeito. Estás a fazer melhor do que esperava."

    # say L986 bil
    old "Means you’re not completely hopeless. Keep going."
    new "Significa que não és completamente inútil. Continua."

    # say L987 bil
    old "Okay, new part. First time for this one."
    new "T(bil|tu|diz): Ok, nova parte. Primeira vez para esta."

    # say L988 bil
    old "Nipples only. Start super gentle... just the tips of your fingers."
    new "B:bil: Okay, nova parte. Primeira vez para esta."

    # say L990 pla
    old "T-they're so sensitive... I can feel them hardening more."
    new "T: T-tão sensíveis... Sinto-os a endurecer mais."

    # say L991 bil
    old "Good. Now a little harder. Build it up, don't rush."
    new "Tens a certeza?"

    # say L992 pla
    old "A-are you sure?"
    new "T: T-tens a certeza?"

    # say L993 bil
    old "Harder, [pla]. Don’t be scared. Make me feel it."
    new "T(bil|tu|say): Mais forte, [pla]. Não tenhas medo. Faz-me sentir."

    # say L996 bil
    old "Yes—fuck—keep going. Harder now, make it count."
    new "B:pla: Assim? Meu Deus, tu já estás a respirar mais pesado..."

    # say L999 bil
    old "You won’t. Trust me. Slowly harder each time."
    new "B:pla: I- I não quero magoar-te..."

    # say L1005 bil
    old "Okay... that was more than enough warm up for your fingers."
    new "B:bil: Mais forte—agora—ahh—foda-se—sim—!"

    # say L1006 pla
    old "Y- yeah... definitely intense."
    new "T(pla|tu|say): Y- yeah... definitivamente intenso."

    # say L1008 bil
    old "So? Feeling more agile now?"
    new "T(bil|tu|say): Então? Sentes-te mais ágil agora?"

    # say L1009 pla
    old "Honestly... a little. But... I don’t think that alone will fix everything."
    new "B:bil: Então? Estás a sentir-te mais ágil agora?"

    # say L1010 bil
    old "Oh, really?"
    new "B:pla: Honestamente... um pouco. Mas... não acho que isso sozinho vá resolver tudo."

    # say L1011 pla
    old "Yeah. I mean... thanks for the help, seriously, but I don’t think that kind of practice is enough to improve my speed or accuracy."
    new "T: Sim. Quero dizer... obrigado pela ajuda, a sério, mas não acho que esse tipo de prática seja suficiente para melhorar a minha velocidade ou precisão."

    # say L1012 bil
    old "Huh."
    new "T(bil|tu|say): Huh."

    # say L1013 bil
    old "So what, now you want something even more advanced?"
    new "B:bil: Huh."

    # say L1014 pla
    old "Well— I mean— I just—"
    new "B:bil: Então, agora queres algo ainda mais avançado?"

    # say L1015 bil
    old "No. No, no, no. Don’t even think I’m giving you a blowjob every time you struggle with a chord."
    new "B:pla: Bem— Quero dizer— Eu só—"

    # say L1016 pla
    old "Wait— what? No! That’s not what I meant!"
    new "B:bil: Não. Não, não, não. Nem penses que te dou uma boquete todas as vezes que tens dificuldade com um acorde."

    # say L1017 bil
    old "Good. Because I’m not doing that every time you show up."
    new "B:pla: Espera... o quê? Não! Isso não foi o que eu quis dizer!"

    # say L1018 pla
    old "N- no! I swear I wasn’t asking for that!"
    new "T(pla|tu|say): N-não! Juro que não estava a pedir isso!"

    # say L1019 bil
    old "Then what were you asking for?"
    new "B: N- não! Juro que não estava a pedir isso!"

    # say L1020 pla
    old "I just... genuinely need help finding a better exercise. Something real. Something useful for my fingers."
    new "T(pla|tu|say): Eu só... realmente preciso de ajuda para encontrar um exercício melhor. Algo real. Algo útil para os meus dedos."

    # say L1021 bil
    old "So you’re... actually serious."
    new "B:pla: Eu só... preciso mesmo de ajuda para encontrar um exercício melhor. Algo real. Algo útil para os meus dedos."

    # say L1022 pla
    old "Yes. I figured you’d know something. A technique, an exercise, something."
    new "T: Sim. Pensei que soubesses algo. Uma técnica, um exercício, qualquer coisa."

    # say L1023 pla
    old "Exactly, that’s what I’m looking for."
    new "B:pla: Sim. Achei que tu sabias alguma coisa. Uma técnica, um exercício, algo assim."

    # say L1024 bil
    old "Okay, okay, Hmm, then let me think."
    new "Hmm... algo avançado para a destreza dos dedos... algo que obrigue a tua mão a adaptar-se..."

    # say L1025 bil
    old "Hmm... something advanced for finger dexterity... something that forces your hand to adapt..."
    new "B:bil: Okay, okay, Hmm, então deixa-me pensar."

    # say L1026 pla
    old "Yeah. Exactly."
    new "B:bil: Hmm... algo avançado para a destreza dos dedos... algo que obrigue a tua mão a se adaptar..."

    # say L1028 bil
    old "Oh..."
    new "...Tenho uma ideia."

    # say L1029 bil
    old "...I have an idea."
    new "B:bil: Oh..."

    # say L1030 pla
    old "You do? What is it?"
    new "B:bil:...Tenho uma ideia."

    # say L1031 bil
    old "You’ll see. Just stay there."
    new "A:pla: Então... o que tens em mente?"

    # say L1033 pla
    old "So... what do you have in mind?"
    new "B:bil: Verás. Fica aí."

    # say L1034 bil
    old "Something advance. Trust me."
    new "A:pla: O- o que estás a fazer?!"

    # say L1036 pla
    old "W- what are you doing?!"
    new "B:bil: Algo avançado. Confia em mim."

    # say L1037 bil
    old "Relax. This is the training. Just extreme level."
    new "B:pla: O- o que estás a fazer?!"

    # say L1040 bil
    old "Now... use those fingers. Start slow."
    new "A:bil: Shh. Concentra-te. Circula o clitóris suavemente."

    # say L1042 bil
    old "Shh. Focus. Circle the clit gently."
    new "B:bil: Agora... usa esses dedos. Começa devagar."

    # say L1046 bil
    old "Mmm... good. Now slide one in."
    new "B:bil: Shh. Concentra-te. Circula o clitóris suavemente."

    # say L1047 pla
    old "Like... this?"
    new "T(pla|tu|say): Assim... assim?"

    # say L1048 bil
    old "Yes... curl it. Find the spot."
    new "B:pla: Assim... assim?"

    # say L1050 bil
    old "Faster now. Add another finger."
    new "B:bil: Sim... enrola-o. Encontra o ponto."

    # say L1054 pla
    old "Fuck... you're dripping."
    new "B:bil: É isso. Esfrega mais forte."

    # say L1055 bil
    old "Deeper. Don't stop."
    new "B:pla: Merda... estás a pingar."

    # say L1057 bil
    old "Harder... make me cum."
    new "B:bil: Mais fundo. Não pares."

    # say L1060 pla
    old "Oh fuck... cum for me."
    new "B:bil: Mais forte... faz-me gozar."

    # say L1063 pla
    old "Yes... feel it all."
    new "B:pla: Ah merda... goza para mim."

    # say L1064 bil
    old "Oh god... that's it."
    new "B:pla: Sim... sente tudo."

    # say L1072 bil
    old "Alright, THAT was definetly an advance training..."
    new "B:bil: Oh deus... é isso mesmo."

    # say L1073 pla
    old "Y-yeah... that was... a lot."
    new "T: Y-yeah... isso foi... muito."

    # say L1074 bil
    old "But hey, your fingers definitely kept up this time."
    new "B:pla: H-hum... isso foi... muito."

    # say L1075 pla
    old "I did feel a big difference. Seriously."
    new "B:bil: Mas hey, os teus dedos definitivamente mantiveram o ritmo desta vez."

    # say L1076 bil
    old "Good. Then keep practicing at home. Use what you learned today."
    new "B:pla: Senti uma grande diferença. A sério."

    # say L1077 bil
    old "If you get stuck again, come back. We’ll figure something out."
    new "B:bil: Ótimo. Então continua a praticar em casa. Usa o que aprendeste hoje."

    # say L1078 pla
    old "I will. Thanks... for everything."
    new "B:bil: Se te ficares preso de novo, volta. Vamos arranjar uma solução."

    # say L1079 bil
    old "Alright, event’s over. Go home before my grandma arrives."
    new "B:pla: Vou. Obrigado... por tudo."

    # say L1091 bil
    old "Finally. Took you long enough."
    new "T(bil|tu|say): Finalmente. Demoraste o suficiente."

    # say L1092 pla
    old "You texted me. Said it was important."
    new "T(pla|tu|say): Tu enviaste-me uma mensagem. Disseste que era importante."

    # say L1093 bil
    old "Yeah. Because it is. The teacher called me."
    new "T(bil|tu|say): Sim. Porque é importante. O professor ligou-me."

    # say L1094 pla
    old "Wait... what? Already?"
    new "A:bil: Ela quer marcar a nossa prática supervisionada."

    # say L1095 bil
    old "She wants to schedule our supervised practice."
    new "A:pla: Como... com ela? A ver-me? A ouvir-me?"

    # say L1096 pla
    old "Like... with her? Watching me? Listening to me?"
    new "B:bil: Ela quer agendar a nossa prática supervisionada."

    # say L1097 bil
    old "Mhm. Exactly that."
    new "B:pla: Como... com ela? A ver-me? A ouvir-me?"

    # say L1098 pla
    old "Oh man... I’m not ready for that."
    new "T(pla|tu|say): Oh homem... Não estou preparado para isso."

    # say L1099 bil
    old "That’s why I told you to come."
    new "B:pla: Oh, homem... Não estou preparado para isso."

    # say L1100 bil
    old "We need to polish you up before she sees anything."
    new "B:bil: É por isso que te disse para vires."

    # say L1101 pla
    old "I don’t know if I can—"
    new "B:bil: Precisamos de te arranjar antes que ela veja algo."

    # say L1102 bil
    old "Stop. You’re doing it. We’re doing it. End of story."
    new "B:pla: Não sei se consigo—"

    # say L1103 bil
    old "Come on. Room. We’ll talk there."
    new "B:bil: Para. Estás a fazê-lo. Nós estamos a fazê-lo. Fim da história."

    # say L1108 bil
    old "Alright. Tell me. How’ve you been since last time?"
    new "B:bil: Vamos. Quarto. Falamos lá."

    # say L1109 pla
    old "Honestly? Way better. After all that... 'advanced practice'... I definitely improved."
    new "B:bil: Tudo bem. Conta-me. Como tens estado desde a última vez?"

    # say L1110 bil
    old "Oh, I bet you did."
    new "B:pla: Honestamente? Muito melhor. Depois de toda essa... 'prática avançada'... com certeza melhorei."

    # say L1112 bil
    old "Yeah, yeah. Show me."
    new "T(bil|tu|say): Sim, sim. Mostra-me."

    # say L1116 pla
    old "Okay... here goes."
    new "T: Ok... aqui vai."

    # say L1118 bil
    old "Huh. Look at that."
    new "A mão está mais leve. O movimento está mais limpo. Tu já não estás a estrangular as cordas."

    # say L1119 bil
    old "Hand’s lighter. Movement’s cleaner. You’re not strangling the strings anymore."
    new "B:bil: Huh. Olha para isso."

    # say L1120 pla
    old "Yeah, I feel the difference. And switching positions isn’t torture now."
    new "B:bil: Aquecer as mãos. Movimentos mais limpos. Já não estás a estrangular as cordas."

    # say L1121 bil
    old "Well, seems last session really loosened you up."
    new "B:pla: Sim, sinto a diferença. E mudar de posição já não é um tormento."

    # say L1122 pla
    old "I... guess so."
    new "B:bil: Bem, parece que a última sessão realmente te deixou mais à vontade."

    # say L1123 bil
    old "Still not perfect. You need a final push if you want to stand in front of a teacher."
    new "Ainda não está perfeito. Precisas de um último empurrão se quiseres estar à frente de uma professora. Precisamente, achas mesmo que precisas de mais?"

    # say L1124 pla
    old "You really think I need more?"
    new "B:bil: Ainda não está perfeito. Precisas de um último empurrão se quiseres ficar à frente de uma professora."

    # say L1125 bil
    old "Oh, absolutely. A little more ‘advanced training’ won’t hurt."
    new "B:pla: Tu realmente achas que preciso de mais?"

    # say L1126 pla
    old "Billie... I don’t know. I think I’ve improved a lot already."
    new "B:bil: Oh, absolutamente. Um pouco mais de ‘treino avançado’ não fará mal."

    # say L1127 bil
    old "You did. But if you want her to take you seriously, you need your fingers sharp."
    new "B:pla: Billie... Não sei. Acho que já melhorei muito."

    # say L1128 bil
    old "And we both know exactly what helped last time."
    new "B:bil: Tu fizeste. Mas se quiseres que ela te leve a sério, precisas de ter os dedos afiados."

    # say L1129 pla
    old "B- Billie, I—"
    new "B:bil: E nós dois sabemos exatamente o que ajudou da última vez."

    # say L1130 bil
    old "Save it. We’re not wasting time. The supervised practice is soon."
    new "B: B- Billie, eu—"

    # say L1131 bil
    old "So let's get you ready properly."
    new "B:bil: Guarda isso. Não estamos a perder tempo. A prática supervisionada é já daqui a pouco."

    # say L1143 bil
    old "Okay... damn. You’ve definitely improved again."
    new "B:bil: Então vamos preparar-te direito."

    # say L1145 bil
    old "Yeah. I can feel it. Your fingers are way more confident now."
    new "B:bil: Okay... merda. Tu definitivamente melhoraste outra vez."

    # say L1146 pla
    old "I... still don’t know if I’m ready for the teacher, though."
    new "Relaxa."

    # say L1147 bil
    old "Relax."
    new "T(bil|tu|say): Relaxa. Não estás a ser avaliado para o concurso ainda. Isto é só para mostrar progresso."

    # say L1148 bil
    old "You’re not being tested for the contest yet. This is just to show progress."
    new "B:bil: Relaxa."

    # say L1149 pla
    old "Right... progress."
    new "B:bil: Ainda não estás a ser testada para o concurso. Isto é só para mostrar progresso."

    # say L1150 bil
    old "She’ll give us feedback. Then we adjust. Simple."
    new "B:pla: Certo... progresso."

    # say L1151 pla
    old "Okay... I guess that makes sense."
    new "T: Ok... Acho que faz sentido."

    # say L1152 bil
    old "Good. Then keep practicing at home. A lot."
    new "B:pla: Okay... Acho que faz sentido."

    # say L1153 bil
    old "Don’t make me regret putting in all this effort."
    new "B:bil: Ótimo. Então continua a praticar em casa. Muito."

    # say L1154 pla
    old "I won’t. I’ll practice."
    new "T: Não vou. Vou treinar."

    # say L1155 bil
    old "Alright... I’m done. Literally done. And I’m getting sleepy."
    new "A:pla: Com sono?"

    # say L1156 pla
    old "Sleepy?"
    new "B:bil: Tudo bem... Estou acabado. Literalmente acabado. E estou a ficar com sono."

    # say L1157 bil
    old "Yeah. ‘Advanced training’ is exhausting, in case you didn’t notice."
    new "B:pla: Sonolento?"

    # say L1158 pla
    old "R-right... sorry."
    new "B:bil: Sim. O ‘treino avançado’ é exaustivo, caso não tenhas notado."

    # say L1159 bil
    old "Go home. Practice. And don’t come back useless."
    new "B:pla: C-como queres... desculpa."

    # say L1160 pla
    old "I’ll do my best. I’ll see you soon."
    new "Vou fazer o meu melhor. Até breve."


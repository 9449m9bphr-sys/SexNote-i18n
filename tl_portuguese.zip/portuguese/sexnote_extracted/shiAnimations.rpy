# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/shiAnimations.rpy
translate portuguese strings:

    # say L45 pla
    old "And... Who are you?"
    new "E... Quem és tu?"

    # say L47 dev
    old "Wow, can you see me? So it was true. Interesting... "
    new "B:pla: E... Quem és tu?"

    # say L50 dev
    old "You are the human with Agamoto's Eye?"
    new "B:dev: Uau, consegues ver-me? Então era verdade. Interessante..."

    # say L51 pla
    old "Yes... and you... are you a... shinigami?"
    new "Sim... e tu... és um... shinigami?"

    # say L53 dev
    old "Yes! This is the first time I've met a human."
    new "B:pla: Sim... e tu... és um... shinigami?"

    # say L54 pla
    old "Ok... So, do you know the shinigami of the other night?"
    new "Sim... Então, tu conheces a shinigami daquela noite?"

    # say L56 dev
    old "You mean Mildret?"
    new "B:pla: Ok... Então, conheces a shinigami daquela noite?"

    # say L57 pla
    old "I don't know her name, but she also sucked up my magical power..."
    new "T(pla|tu|say): Não sei o nome dela, mas ela também sugou os meus poderes mágicos..."

    # say L59 dev
    old "Yes, then you talk about Mildret  hehehe."
    new "B:pla: Não sei o nome dela, mas ela também sugou o meu poder mágico..."

    # say L60 pla
    old "Are there more shinigami, besides Mildret and... you?"
    new "T: Existem mais shinigami, além de Mildret e... tu?"

    # say L62 dev
    old "Yes we are only three and I am Devonne. Nice to meet you!"
    new "B:pla: Existem mais shinigami, além de Mildret e... tu?"

    # say L65 dev
    old "Wow, [pla]? What strange names humans have... hahaha."
    new "T(dev|tu|say): Uau, [pla]? Que nomes estranhos os humanos têm... hahaha."

    # say L66 pla
    old "You're not mad at me?"
    new "Tu? Não... Porque é que eu ia ficar?"

    # say L68 dev
    old "Me? No... Why would I be?"
    new "T(dev|tu|say): Eu? Não... Porque é que eu ia ficar?"

    # say L69 pla
    old "Because Mildret accused me of stealing magical power..."
    new "B:dev: Eu? Não... Por que eu seria?"

    # say L71 dev
    old "Ohhh you mean that... Well, there has been someone who has been gathering the magical power in this area and we think it's you... Is it you?"
    new "B:pla: Porque Mildret acusou-me de roubar poder mágico..."

    # say L72 pla
    old "Well, yes... But..."
    new "B:dev: Ohhh, tu queres dizer isso... Bem, tem havido alguém a reunir poder mágico nesta área e pensamos que fosses tu... És tu?"

    # say L74 dev
    old "Ohhh... Then it's true, You are the thief... And you were starting to like me... I better go before you take away the little I recovered..."
    new "B:pla: Bem, sim... Mas..."

    # say L77 pla
    old "No,wait!"
    new "B:dev: Ohhh... Então é verdade, tu és o ladrão... E tu estavas a começar a gostar de mim... É melhor eu ir antes que tu me tires o pouco que recuperei..."

    # say L78 pla
    old "Hmm... Again... And they are three huh?"
    new "B:pla: Não, espera!"

    # say L98 pla
    old "So, did you get enought magic power?"
    new "B:pla: Hmm... Outra vez... E são três, hã?"

    # say L100 dev
    old "Yeay! Thank you so much..."
    new "B:pla: Então, conseguiste energia mágica suficiente?"

    # say L101 pla
    old "Don't worry, I just wanna help you..."
    new "Não te preocupes, só quero ajudar-te..."

    # say L103 dev
    old "You are the best!"
    new "B:pla: Não te preocupes, só quero ajudar-te..."

    # say L173 dev
    old "You destroyed the magical world!!!"
    new "T: Tu destruíste o mundo mágico!!!"

    # say L176 dev
    old "You are the worst being in the universe!..."
    new "T(dev|tu|say): Tu és a pior criatura do universo!..."

    # say L177 pla
    old "I don't understand... Why do you say that?..."
    new "B:dev: Tu és a pior criatura do universo!..."

    # say L179 dev
    old "You have already done a lot of damage, and now you want to make us disappear by talking away the magical power... Leave us alone, once and for all..."
    new "B:pla: Não percebo... Porque dizes isso?..."

    # say L182 pla
    old "... What the hell?..."
    new "B:dev: Já causaste muito dano, e agora queres fazer-nos desaparecer ao tirar-nos o poder mágico... Deixa-nos em paz, de uma vez por todas..."

    # say L272 dev
    old "Oh boy, there is nothing more fun than sharing magical power."
    new "B:pla:... Que raio?..."

    # say L274 pla
    old "I'm glad you feel good, you can still count on receiving magical power when you need me, you can go when you want it..."
    new "B:dev: Oh boy, não há nada mais divertido do que partilhar poder mágico."

    # say L276 dev
    old "Do not hesitate..."
    new "B:pla: Fico contente que te sintas bem, ainda podes contar com o poder mágico quando precisares de mim, podes ir quando quiseres..."

    # say L278 pla
    old "Well, I must go now, I'm glad I closed the deal and finished everything in good terms..."
    new "B:dev: Não hesites..."

    # say L282 pla
    old "Yes, I'll be careful..."
    new "Sim, terei cuidado..."

    # say L284 dev
    old "Okay..."
    new "B:pla: Sim, vou ter cuidado..."

    # say L306 dev
    old "Yeay! really fun... right?..."
    new "B:dev: Ok..."

    # say L308 pla
    old "Haha right, it was fun."
    new "B:dev: Yeay! realmente divertido... certo?..."

    # say L310 dev
    old "Ok, I'm going to collect more magic power to do it again..."
    new "T: Ok, vou recolher mais poder mágico para fazer de novo..."

    # say L312 pla
    old "Just take it easy... Ok?"
    new "B:dev: Ok, vou recolher mais poder mágico para o fazer de novo..."

    # say L314 dev
    old "Ok, ok..."
    new "B:pla: Calma... Ok?"

    # say L422 pla
    old "Tell me your name shinigami!"
    new "Diz-me o teu nome, shinigami!"

    # say L424 gom
    old "My name is Gomory..."
    new "B:pla: Diz-me o teu nome, shinigami!"

    # say L426 pla
    old "Hmmm... Do you know Devonne and... Mildret? "
    new "B:gom: O meu nome é Gomory..."

    # say L428 gom
    old "Yes, they are two allied shinigamis..."
    new "B:pla: Hmmm... Tu sabes quem são Devonne e... Mildret?"

    # say L430 pla
    old "Why are you stealing magic power from me?"
    new "B:gom: Sim, são dois shinigamis aliados..."

    # say L432 gom
    old "You have been collecting magical power from this area, which has left us with few reserves... and soon we'll not enough to exist."
    new "B: pla: Porque estás a roubar-me poder mágico?"

    # say L434 gom
    old "I should go... I've said enough..."
    new "B: gom: Tu tens estado a recolher poder mágico desta área, o que nos deixou com poucas reservas... e em breve não teremos o suficiente para existir."

    # say L435 pla
    old "No, no, wait! I didn't know I was taking magic power from you..."
    new "B:gom: Devo ir... Já disse o suficiente..."

    # say L438 gom
    old "Well, actually, it is not the magic power from us. It's just that there is less and less in the area."
    new "B:pla: Não, não, espera! Não sabia que estava a tirar poder mágico de ti..."

    # say L439 gom
    old "I think we will soon cease to exist because there will be no more..."
    new "B:gom: Na verdade, não é o poder mágico que temos. É só que há cada vez menos na área."

    # say L442 gom
    old "And you do not need the magic power to exist..."
    new "B: gom: Acho que em breve deixaremos de existir porque não haverá mais..."

    # say L445 pla
    old "Ohhh... I understand perfectly... I didn't know... I mean, I knew it, but I didn't know you existed..."
    new "B:gom: E não precisas de poder mágico para existir..."

    # say L447 gom
    old "Well, you already know... It is not something that makes much difference. At some point all the magical power will end and we will disappear..."
    new "B:pla: Ohhh... percebo perfeitamente... não sabia... Quero dizer, sabia disso, mas não sabia que tu existias..."

    # say L448 pla
    old "What about the 'Chosen One'? Who will rebuild the magical world? "
    new "B:gom: Bem, tu já sabes... Não é algo que faça muita diferença. Em algum momento todo o poder mágico acabará e desapareceremos..."

    # say L450 gom
    old "It's a myth... No one really thinks that will happen since years have passed... Anyway... I'm leaving..."
    new "B:pla: E o 'Escolhido'? Quem irá reconstruir o mundo mágico?"

    # say L453 pla
    old "But... Hmm... Now I understand... I have to talk with Brixxida"
    new "B:gom: É um mito... Ninguém realmente acredita que isso vai acontecer, já passaram anos... De qualquer forma... Estou a ir-me embora..."

    # say L473 pla
    old "Well, did you get enough magic power?"
    new "B:pla: Mas... Hmm... Agora percebo... Tenho de falar com Brixxida"

    # say L475 gom
    old "Yes, I have enough for now..."
    new "B:pla: Bem, conseguiste energia mágica suficiente?"

    # say L476 pla
    old "Ok, you can come anytime if you need more..."
    new "B:gom: Sim, tenho o suficiente por agora..."

    # say L478 gom
    old "Ok, thanks. I have to go."
    new "B:pla: Ok, podes vir a qualquer hora se precisares de mais..."

    # say L547 pla
    old "Answer me, why do you say that I destroyed the magical world?"
    new "Tu és o dono da SexNote, que destruiu o mundo mágico..."

    # say L549 gom
    old "You are the owner of the SexNote, who destroyed the magical world..."
    new "T(gom|tu|say): Tu és o dono da SexNote, que destruiu o mundo mágico..."

    # say L552 pla
    old "What? But I didn't..."
    new "B:gom: Tu és o dono do SexNote, que destruiu o mundo mágico..."

    # say L554 pla
    old "How was the magical world destroyed? "
    new "B: pla: O quê? Mas eu não..."

    # say L556 gom
    old "A powefull being who possessed the SexNote, performed a forbidden spell that caused the magical world to collapse..."
    new "B:pla: Como foi destruído o mundo mágico?"

    # say L559 pla
    old "What the fuck?..."
    new "B:gom: Uma entidade poderosa que possuía o SexNote, realizou um feitiço proibido que causou o colapso do mundo mágico..."

    # say L564 bri
    old "Thieves!! Stop stealing the magic power!"
    new "B:pla: Que raio?..."

    # say L567 gom
    old "We have little magic energy left for Mildret and me... Don't attack us anymore..."
    new "B:bri: Ladrões!! Parem de roubar a energia mágica!"

    # say L569 bri
    old "You must die! I will finish you!"
    new "T(bri|tu|say): Tu tens de morrer! Vou acabar contigo!"

    # say L573 pla
    old "What are you doing!?"
    new "B:bri: Tu tens de morrer! Vou acabar contigo!"

    # say L575 bri
    old "I'm trying to make them not bother you again..."
    new "T(bri|tu|say): Estou a tentar fazer com que eles não te incomodem mais..."

    # say L577 pla
    old "I was getting information... You chased her away..."
    new "T(pla|tu|say): Estava a recolher informações... Tu afastaste-a..."

    # say L579 bri
    old "Sorry, I am upset about the magical power that was stolen from us..."
    new "T(bri|tu|say): Desculpa, estou chateado com o poder mágico que nos foi roubado..."

    # say L581 pla
    old "But... Why did you do that?"
    new "B:bri: Desculpa, estou chateada com o poder mágico que nos foi roubado..."

    # say L583 pla
    old "Anyway, just let's go home..."
    new "B:pla: Mas... Porquê fizeste isso?"

    # say L585 bri
    old "Ok..."
    new "B:pla: De qualquer forma, vamos para casa..."

    # say L590 pla
    old "Hmm... Things are very suspicious... I'll have to talk to Brixxida to clarify everything..."
    new "T: Hmm... As coisas estão muito suspeitas... Vou ter que falar com Brixxida para esclarecer tudo..."

    # say L608 gom
    old "Well I hope this little help you, to improve your skills..."
    new "B:pla: Hmm... As coisas estão muito suspeitas... Vou ter de falar com Brixxida para esclarecer tudo..."

    # say L610 pla
    old "Thank you, I really appreciate all your help."
    new "B:gom: Espero que esta pequena ajuda te ajude a melhorar as tuas habilidades..."

    # say L612 gom
    old "You're welcome, we count on you to save the magical world."
    new "B:pla: Obrigado, aprecio mesmo toda a tua ajuda."

    # say L614 pla
    old "I'll take care of fixing everything, I promise..."
    new "B:gom: De nada, contamos contigo para salvar o mundo mágico."

    # say L616 gom
    old "Thank you."
    new "B:pla: Vou arranjar tudo, prometo..."

    # say L676 pla
    old "What the fuck? Who are you? And What was that?!"
    new "B:gom: Obrigado."

    # say L678 mil
    old "What? Can you see me?"
    new "B:pla: Que raio? Quem és tu? E o que foi isso?!"

    # say L679 pla
    old "Yes! Of course, I can see you..."
    new "B:mil: O quê? Tu consegues ver-me?"

    # say L681 mil
    old "How the fuck can you see me? You are a simple human... "
    new "B:pla: Sim! Claro, eu consigo ver-te..."

    # say L682 pla
    old "Uhh no... I think it's because I have Agamoto's eyes."
    new "B:mil: Como é que me vês? Tu és apenas um ser humano..."

    # say L684 mil
    old "What?! You have Agamoto's eyes?"
    new "B:pla: Uhh não... Acho que é porque tenho os olhos do Agamoto."

    # say L685 pla
    old "Ehh yeah... But who are you?"
    new "B:mil: Que?! Tu tens os olhos do Agamoto?"

    # say L687 mil
    old "Sooo... it's you who's been stealing the magic power?!"
    new "B:pla: Ehh sim... Mas quem és tu?"

    # say L688 pla
    old "What? Stealing magic power?"
    new "B:mil: Então... foste tu quem tem estado a roubar a energia mágica?!"

    # say L690 mil
    old "Look, I'll only warn you this once... If you keep stealing the magic power I will be forced to take extreme measures..."
    new "T(mil|tu|say): Olha, só te aviso uma vez... Se continuares a roubar a energia mágica, serei forçado a tomar medidas extremas..."

    # say L691 pla
    old "Extreme measures?"
    new "B:mil: Olha, só te aviso uma vez... Se continuares a roubar a energia mágica, serei forçada a tomar medidas extremas..."

    # say L693 mil
    old "This is not a children's game... You better stop stealing the magical power."
    new "B:pla: Medidas extremas?"

    # say L696 pla
    old "But- wait... What?"
    new "B:mil: Isto não é um jogo de crianças... Melhor parares de roubar o poder mágico."

    # say L697 pla
    old "Hmm... Will have to talk to Brixxida tomorrow..."
    new "B:pla: Mas... espera... O quê?"

    # say L723 pla
    old "Well, did you get enough?"
    new "B:pla: Hmm... Vou ter de falar com Brixxida amanhã..."

    # say L725 mil
    old "Yes, thank you for everything..."
    new "B:pla: Então, conseguiste o suficiente?"

    # say L726 pla
    old "No problem. You can come back anytime if you need more..."
    new "B:mil: Sim, obrigado por tudo..."

    # say L728 mil
    old "We just need a little to not disappear..."
    new "B:pla: Sem problemas. Podes voltar sempre que precisares de mais..."

    # say L730 mil
    old "Anyway I will let you keep sleeping... Bye..."
    new "B:mil: Só precisamos de um pouco para não desaparecer..."

    # say L798 mil
    old "Don't you see? You're a thief... And now you steal directly."
    new "B:mil: De qualquer forma, vou deixar-te continuar a dormir... Adeus..."

    # say L800 pla
    old "I'm not... I'm only recovering what you took away from me, Nothing more."
    new "T(tu|diz): Não estou... Estou apenas a recuperar o que me tiraste, nada mais."

    # say L802 mil
    old "You have been taking away all the energy in these past few days..."
    new "B:pla: Não estou... Estou apenas recuperando o que me tiraste, nada mais."

    # say L804 mil
    old "You don't need it to exist..."
    new "B:mil: Tu tens estado a levar toda a energia nestes últimos dias..."

    # say L806 pla
    old "I am the chosen one, I will be able to restore the magical world..."
    new "T: Sou o escolhido, conseguirei restaurar o mundo mágico..."

    # say L808 mil
    old "You are a simple human, you cannot do anything for the magical world..."
    new "B:pla: Eu sou o escolhido, conseguirei restaurar o mundo mágico..."

    # say L810 pla
    old "I am the owner of the SexNote!..."
    new "B:mil: Tu és um humano simples, não podes fazer nada pelo mundo mágico..."

    # say L812 mil
    old "You... have... the... SexNote?..."
    new "B:pla: Sou o dono do SexNote!..."

    # say L814 pla
    old "That's right... I will rebuild the magical world..."
    new "B:mil: Tu... tens... o... SexNote?..."

    # say L820 pla
    old "Wait... Hmm..."
    new "T(pla|tu|say): Espera... Hmm..."

    # say L840 mil
    old "Ok, I think is enought for now, right?..."
    new "B:pla: Espera... Hmm..."

    # say L842 pla
    old "Well, yes, thank you... But if you have little just left tell me."
    new "B:mil: Ok, acho que já chega por agora, certo?"

    # say L844 mil
    old "Don't worry I'm good for now..."
    new "B:pla: Bem, sim, obrigado... Mas se tiveres pouco só diz."

    # say L846 mil
    old "Now let me rest and recover some magic power..."
    new "B:mil: Não te preocupes, estou bem por agora..."

    # say L848 pla
    old "Ok, see you..."
    new "T(pla|tu|say): Ok, até já..."


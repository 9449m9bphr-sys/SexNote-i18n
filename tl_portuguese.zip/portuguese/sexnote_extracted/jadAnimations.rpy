# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/jadAnimations.rpy
translate portuguese strings:

    # say L6 milJad
    old "I must say... Mmmm, the size of your dick never stops being surprising."
    new "T(milJad|tu|say): Tenho de dizer... Mmmm, o tamanho do teu pénis nunca deixa de surpreender."

    # say L7 milJad
    old "It’s impressive."
    new "B:milJad: Tenho de dizer... Mmmm, o tamanho do teu pénis nunca deixa de me surpreender."

    # say L8 milJad
    old "And this scent... I had never perceived it."
    new "B:milJad: É impressionante."

    # say L9 milJad
    old "It’s... nice."
    new "B:milJad: E este cheiro... Nunca o tinha notado."

    # say L13 milJad
    old "Are you enjoying this?"
    new "B:milJad: É... agradável."

    # say L14 milJad
    old "I ask because it’s important for you to cum."
    new "B:milJad: Estás a gostar disto?"

    # say L15 pla
    old "It feels good."
    new "B:milJad: Pergunto porque é importante para ti gozares."

    # say L16 milJad
    old "Mmmmm!"
    new "B:pla: Sente-se bem."

    # say L20 milJad
    old "This sensation! I’d never felt it before!"
    new "B:milJad: Mmmmm!"

    # say L21 milJad
    old "Ughh... It hurts, but it feels so good!"
    new "B:milJad: Esta sensação! Nunca a senti antes!"

    # say L22 milJad
    old "I- I’m enjoying it!"
    new "B:milJad: Ahhh... Faz mal, mas é tão bom!"

    # say L45 pla
    old "I don’t think I will last longer!"
    new "B:milJad: Eu... estou a gostar!"

    # say L46 milJad
    old "It’s ok, cum for me!"
    new "B:pla: Não acho que vou aguentar mais!"

    # say L47 milJad
    old "Slurrp!!"
    new "B:milJad: Tudo bem, goza para mim!"

    # say L48 milJad
    old "Cum! Give me the magic!"
    new "B:milJad: Slurrp!!"

    # say L54 mil
    old "That... that was unexpected."
    new "B:milJad: Gozar! Dá-me a magia!"

    # say L55 pla
    old "Are you ok?"
    new "T(pla|tu|say): Estás bem?"

    # say L56 mil
    old "I’m fine."
    new "T(mil|tu|say): Estou bem."

    # say L57 mil
    old "It’s just that I wasn’t expecting that."
    new "A:mil: O ato parece tão diferente com um corpo humano."

    # say L58 mil
    old "The act feels so different with a human body."
    new "B:mil: É que não estava à espera disso."

    # say L59 mil
    old "And to be able to feel all that. Linett’s spell is very complete!"
    new "B:mil: A sensação é tão diferente com um corpo humano."

    # say L60 pla
    old "Ah... sure. Hey listen, I think we need to get going before we’re discovered here."
    new "B:mil: E poder sentir tudo isso. O feitiço da Linett é muito completo!"

    # say L61 pla
    old "I’ll clean Mrs. Jade, and then we take off. Ok?"
    new "B:pla: Ah... claro. Oi, acho que precisamos ir antes que nos descubram aqui."

    # say L75 jad
    old "(Mmm, it feels so nice...)"
    new "B:pla: Vou limpar a Sra. Jade, e depois partimos. Ok?"

    # say L81 pla
    old "(Wow... Yeah, she is definitely moving... Geez, and just in front of Hinn...)"
    new "B:pla: (Espera, ela está a mexer-se? Que raio...)"

    # say L82 hin
    old "Hey, talking about dad, I saw he deleted the post about his marriage."
    new "B:pla: (Wow... Yeah, ela está definitivamente a mexer-se... Meu Deus, e à frente do Hinn...)"

    # say L83 hin
    old "Kinda late, we already saw it."
    new "B:hin: Ei, a falar do pai, vi que ele apagou o post sobre o casamento."

    # say L84 jad
    old "Mmm... Yeah, he’s just like that."
    new "B:hin: Já é tarde, já vimos isso."

    # say L85 jad
    old "Not surprising..."
    new "A:jad: (Oh my God! Não consigo mais me controlar, isto está tão bom.)"

    # say L89 jad
    old "(Oh my God! I can't help myself anymore, this feels so fucking good.)"
    new "B:jad: Não é surpresa..."

    # say L90 jad
    old "Ahh! Ahh!"
    new "B:jad: (Oh my God! Não consigo me controlar mais, isto é tão bom...)"

    # say L93 jad
    old "(Holy cow!) U- uh, nothing, I just hurt my toe."
    new "B:jad: Ahh! Ahh!"

    # say L94 jad
    old "A- accidentally."
    new "B:jad: (Santo Deus!) U- uh, nada, só fui atingido o dedo do pé."

    # say L95 hin
    old "Oh, you should be more careful."
    new "B:jad: A- por acidente."

    # say L96 jad
    old "Yes honey, hehe, how silly of me..."
    new "A:jad: Estás prestes a terminar?"

    # say L121 jad
    old "Are you about to finish?"
    new "B:jad: Sim, meu amor, hehe, que bobo de mim..."

    # say L122 hin
    old "Yeah, I’m almost done."
    new "B:jad: Estás quase a acabar?"

    # say L123 jad
    old "Me too..."
    new "A:hin: Bem, isso foi um alívio, desculpa por ter interrompido o teu duche."

    # say L130 hin
    old "Well, that was a relief, I’m sorry I interrupted your shower."
    new "B:jad: Eu também..."

    # say L132 jad
    old "Don’t worry honey."
    new "B:hin: Bem, isso foi um alívio, desculpa ter interrompido o teu duche."

    # say L133 hin
    old "I have to get going, gotta get back to school."
    new "B:jad: Não te preocupes, querida."

    # say L134 jad
    old "Sure honey."
    new "B:hin: Tenho que ir, tenho que voltar à escola."

    # say L137 jad
    old "(Oh my god! What did I just do?)"
    new "B:jad: Claro, querida."

    # say L139 pla
    old "Uhh, right, right."
    new "A:jad: Oh sim, isto sente-se tão bem.."

    # say L152 jad
    old "Oh yeah, this feels so nice.."
    new "B:pla: Hum, certo, certo."

    # say L153 jad
    old "Mmm, I want that big hard cock inside of me!"
    new "B:jad: Oh yeah, isto sente-se tão bem.."

    # say L154 jad
    old "I need it."
    new "B:jad: Mmm, quero esse pau grande e duro dentro de mim!"

    # say L158 jad
    old "Uhh, I- it’s the biggest cock I’ve seen!"
    new "B:jad: Preciso disso."

    # say L159 jad
    old "Oh God! I- I want to be fucked by him!"
    new "B:jad: Uhh, é o maior pénis que já vi!"

    # say L160 pla
    old "(She's thinking about someone she knows?)"
    new "B:jad: Oh Deus! Eu... eu quero que ele me foda!"

    # say L164 jad
    old "Mmm... I want him to fuck me like he fucks Hinn!"
    new "B:pla: (Ela está a pensar em alguém que conhece?)"

    # say L165 pla
    old "(Woah! Woah! She's not thinking about me, right?!)"
    new "B:jad: Mmm... Quero que ele me foda como fode a Hinn!"

    # say L166 jad
    old "Oh yes, yes, yes!!"
    new "B:pla: (Puxa! Puxa! Ela não está a pensar em mim, certo?!)"

    # say L167 jad
    old "I want to feel that hard cock inside me!"
    new "B:jad: Oh sim, sim, sim!!"

    # say L168 jad
    old "That young, thick, hard, cock!"
    new "B:jad: Quero sentir esse pau duro dentro de mim!"

    # say L191 jad
    old "AH! AH! Ohhh I'm cumming, I'm cumming!"
    new "B:jad: Que pénis jovem, grosso e duro!"

    # say L192 jad
    old "YES! YES! YES! YES!"
    new "B:jad: AH! AH! Ohhh estou a gozar, estou a gozar!"

    # say L198 jad
    old "Phew, that felt so good."
    new "B:jad: SIM! SIM! SIM! SIM!"

    # say L199 jad
    old "I needed that."
    new "B:jad: Ufa, isso sentiu-se tão bem."

    # say L200 jad
    old "But, it’s still not the same as a dick."
    new "B:jad: Precisava disso."

    # say L203 jad
    old "Wait, what was that sound?"
    new "B:jad: Mas, ainda não é a mesma coisa que um pénis."

    # say L211 jad
    old "Mmmm, that was a huge cock!"
    new "B:jad: Espera, que som foi esse?"

    # say L212 pla
    old "(Is she talking about my...)"
    new "B:jad: Mmmm, que pénis enorme!"

    # say L213 jad
    old "Oh god, it barely fit in my mouth, and it tasted so good..."
    new "Oh meu Deus! Nunca tinha sentido isto antes..."

    # say L217 jad
    old "Oh my God! I had never felt this before..."
    new "B:jad: Oh Deus, mal coube na minha boca, e estava tão bom..."

    # say L218 jad
    old "Mmmm, I want that cock so badly..."
    new "B:jad: Meu Deus! Nunca tinha sentido isto antes..."

    # say L223 jad
    old "Ahhh! Ahh! Ah!"
    new "B:jad: Mmmm, quero esse pau tanto..."

    # say L248 jad
    old "Ahh! Ahhh! I want you to fill me up!"
    new "B:jad: Eu adoro o teu pénis grande!"

    # say L249 jad
    old "Yes! Yes! Oh, this is so good!"
    new "B:jad: Ahh! Ahhh! Quero que me enchas!"

    # say L250 jad
    old "I- I’m cumming!"
    new "B:jad: Sim! Sim! Oh, isto é tão bom!"

    # say L256 jad
    old "Phew... I bet that surprised you."
    new "B:jad: A- Acho que vou gozar!"

    # say L257 pla
    old "(Is she talking to me?)"
    new "B:jad: Phew... Aposto que isso te surpreendeu."

    # say L258 jad
    old "Sorry I couldn't help it, I've been a bit horny lately."
    new "T(jad|tu|say): Desculpa, não consegui evitar, tenho estado um bocado excitada ultimamente."

    # say L266 pla
    old "Uhh... Before? Before what?"
    new "A:jad: Antes disto."

    # say L267 jad
    old "Before this."
    new "A:whi: Adoro como é grande o pénis dele, não é?"

    # say L288 whi
    old "I love how big is his cock, isn't it?"
    new "A:whi: Estás a gostar da vista, Jade?"

    # say L289 whi
    old "Are you enjoying the view Jade?"
    new "B:whi: Adoro o tamanho do pénis dele, não achas?"

    # say L294 whi
    old "Mmm, yeah, have you ever seen a deep throat, Jade?"
    new "B:whi: Estás a gostar da vista, Jade?"

    # say L295 whi
    old "Do you like what I'm doing with my mouth?"
    new "B:whi: Mmm, sim, já viste uma garganta profunda, Jade?"

    # say L300 whi
    old "What about if I get an oral creampie, would you like to see that jade?"
    new "B:whi: Gostas do que estou a fazer com a minha boca?"

    # say L301 jad
    old "Mmmm..."
    new "B:whi: E se eu te fizer uma oral creampie, gostavas de ver isso, jade?"

    # say L302 whi
    old "That's all what I need to know."
    new "B:jad: Mmmm..."

    # say L325 pla
    old "Mmmm, I- I think I'm about to-"
    new "B:whi: Isso é tudo o que preciso saber."

    # say L326 whi
    old "Yes! Do it! Show Jade what she's been missing!"
    new "B:pla: Mmmm, eu- eu acho que vou-"

    # say L327 whi
    old "You want it too, don't you Jade?"
    new "B:whi: Sim! Faz isso! Mostra à Jade o que ela tem estado a perder!"

    # say L328 whi
    old "You also want him to push this big hard dick in you mouth?"
    new "B:whi: Tu também queres, não é Jade?"

    # say L340 whi
    old "Mmm, are you ready for your turn?"
    new "B:whi: Queres também que ele te enfie este grande pénis na boca?"

    # say L342 whi
    old "Well? Do you want to try it, isn't it?"
    new "B:whi: Mmm, estás pronto para a tua vez?"

    # say L343 jad
    old "Uhh, I- I do."
    new "B:whi: Bem? Queres experimentar, não é?"

    # say L344 whi
    old "Good! I'm glad you're finally admitting it."
    new "B:jad: Uhh, eu... eu faço."

    # say L345 whi
    old "Great, now let's do it!"
    new "B:whi: Ótimo! Estou contente que finalmente estás a admitir."

    # say L354 whi
    old "That's it, girl, just relax, don’t think about anything else other than what you have in your mouth right now."
    new "B:whi: Ótimo, agora vamos fazer!"

    # say L358 whi
    old "Hehe, enjoy this huge cock Jade."
    new "B:pla: Uhh... Mmmm, yeah..."

    # say L367 whi
    old "I bet you've been wanting to get his hot dick in your mouth for a while, haven't you?"
    new "B:whi: Hehe, aproveita este pénis enorme, Jade."

    # say L368 jad
    old "Mmmm!"
    new "B:whi: Aposto que tu tens desejado ter o seu pau quente na tua boca há algum tempo, não é?"

    # say L369 whi
    old "Hahaha, that's all the answer I needed."
    new "A:whi: Posso-te dizer, miúda, isto é cem vezes melhor que o pénis flácido do teu ex-marido!"

    # say L373 whi
    old "I can tell you girl, this is about a hundred times better than your ex-husband's limp dick!"
    new "B:whi: Hahaha, isso é tudo o que precisava ouvir."

    # say L374 jad
    old "Slrrrrp! Mmmm, yeah!"
    new "B:whi: Posso-te dizer, miúda, isto é cem vezes melhor que o pau murchinho do teu ex-marido!"

    # say L375 whi
    old "Mmmm, how sexy you look with a big cock in your mouth."
    new "B:jad: Slrrrrp! Mmmm, sim!"

    # say L379 whi
    old "Oh yeah baby! let's make him cum. You want him to cum in your mouth and taste that big load, right?"
    new "B:whi: Mmmm, que sexy ficas com um pau grande na boca."

    # say L380 jad
    old "...Y- yes, I want it..."
    new "B:whi: Oh yeah baby! Vamos fazer com que ele goze. Tu queres que ele goze na tua boca e que tu proves essa grande carga, certo?"

    # say L381 whi
    old "You already heard it please, don't hold back and give us a huge cumshot."
    new "B:jad:...S- sim, eu quero..."

    # say L405 pla
    old "I- I think I’m about to...!"
    new "B:whi: Já ouviste, por favor, não te contenhas e dá-nos um grande jorro."

    # say L406 whi
    old "That’s it, cum for us baby!"
    new "A:whi: Quero que tu gozes na boca dela!"

    # say L407 whi
    old "I want you to cum in her mouth!"
    new "B:whi: É isso, goza para nós, bebé!"

    # say L408 whi
    old "You are going to drink every single drop, Jade."
    new "B:whi: Quero que gozes na boca dela!"

    # say L415 whi
    old "Ohh yeah, that was a huge load. Did you enjoy it Jade?"
    new "B:whi: Vais beber cada gota, Jade."

    # say L416 jad
    old "Uhh... Y- yes..."
    new "B:whi: Ohh yeah, isso foi uma carga enorme. Gostaste, Jade?"

    # say L417 whi
    old "What did I tell you? This is a lot better than masturbating."
    new "B:jad: Uhh... S- sim..."

    # say L418 whi
    old "And with such a young gifted man, you didn’t know what you were missing on girl."
    new "B:whi: O que te disse? Isto é muito melhor do que masturbar-te."

    # say L419 jad
    old "I- I suppose you’re right."
    new "B:whi: E com um jovem talentoso assim, tu nem sabias o que estavas a perder, rapariga."

    # say L420 whi
    old "You know I’m right. Now let me help you clean up all this mess."
    new "B:jad: Eu... suponho que tens razão."

    # say L432 pla
    old "Uhh, w- what is happening?"
    new "B:whi: Tu sabes que tenho razão. Agora deixa-me ajudar-te a limpar toda esta confusão."

    # say L433 jad
    old "Well, you know what Mrs. White said last time."
    new "B:pla: Uhh, w- o que está a acontecer?"

    # say L434 jad
    old "Maybe we should try to do some of this on our own."
    new "B:jad: Bem, tu sabes o que a Sra. White disse da última vez."

    # say L436 jad
    old "To be honest, I’ve been thinking about this way too much, it’s about time I do something about it."
    new "T(jad|tu|dizer): Para ser honesto, tenho pensado nisto demasiado, é altura de fazer alguma coisa."

    # say L440 jad
    old "Hmph! Slrrrp!"
    new "B:jad: Para ser honesto, tenho pensado demasiado nisto, é altura de fazer algo a respeito."

    # say L441 jad
    old "I can kind of see why Hinn likes you so much."
    new "B:jad: Hmph! Slrrrp!"

    # say L442 jad
    old "How could she not? With such an amazing cock!"
    new "B:jad: Consigo perceber um pouco por que a Hinn gosta tanto de ti."

    # say L446 jad
    old "I love how hot your cock is?"
    new "A:jad: Estás a gostar, meu amor?"

    # say L447 jad
    old "Are you liking it, honey?"
    new "B:jad: Adoro como o teu pénis está quente..."

    # say L448 pla
    old "Mmm, yeah..."
    new "B:jad: Estás a gostar, meu amor?"

    # say L449 jad
    old "Me too!"
    new "B:pla: Mmm, sim..."

    # say L472 pla
    old "I- I think I’m about to cum!"
    new "T: A- Acho que vou gozar!"

    # say L473 jad
    old "It’s ok, you can cum in my mouth!"
    new "B:pla: I- Acho que vou gozar!"

    # say L474 jad
    old "I want to taste it again!"
    new "B:jad: Tudo bem, podes gozar na minha boca!"

    # say L495 whi
    old "Hahaha, he’s huge isn’t he?"
    new "B:jad: OH MY DEUS!! Oh wow!"

    # say L496 whi
    old "Just relax and enjoy it girl."
    new "B:whi: Hahaha, ele é enorme, não é?"

    # say L497 whi
    old "Not always can you enjoy something like this."
    new "B:whi: Relaxa e aproveita, rapariga."

    # say L501 jad
    old "Ah! Ah! I can’t! This is just too good!"
    new "B:whi: Nem sempre podes desfrutar de algo assim."

    # say L502 whi
    old "Yeah that’s right, take it all."
    new "A:whi: Ha! Aposto que aquele perdedor do teu ex-marido nunca te fodeu assim!"

    # say L503 whi
    old "Ha! I bet that looser of your ex-husband never fucked you like this!"
    new "B:whi: Sim, é isso aí, aproveita tudo."

    # say L509 jad
    old "Ahh! Ahh! O- of course not!"
    new "B:whi: Já alguma vez sentiste algo assim antes, Jade?"

    # say L510 whi
    old "Hahaha, I love to see you like this!"
    new "B:jad: Ahh! Ahh! O- obviamente que não!"

    # say L511 whi
    old "Enjoy it girl, you deserve it!"
    new "B:whi: Hahaha, adoro ver-te assim!"

    # say L536 whi
    old "Don’t stop! Don’t stop now!"
    new "B:whi: Vais fazer com que ela goze!"

    # say L538 jad
    old "Ahhhh, Ahhhhh!"
    new "B:whi: Não pares! Não pares agora!"

    # say L544 jad
    old "Oh my! That was great, really great."
    new "B:jad: Ahhhh, Ahhhhh!"

    # say L545 whi
    old "And look at that, he just came and he’s still hard!"
    new "B:jad: Oh meu! Isso foi incrível, realmente incrível."

    # say L546 whi
    old "It must be great to be that young!"
    new "B:whi: E vê lá, ele acabou de gozar e ainda está duro!"

    # say L547 whi
    old "But now it’s my turn."
    new "B:whi: Deve ser ótimo ser tão jovem!"

    # say L566 whi
    old "That’s just what I have been waiting for."
    new "B:whi: Nngh! Oh sim, é isso mesmo!"

    # say L567 whi
    old "Uhhh, it just fills me up!"
    new "B:whi: É exactamente isso que eu estava à espera."

    # say L571 whi
    old "Ah! Ah! Ah! It’s so big!"
    new "B:whi: Uhhh, enche-me tanto!"

    # say L572 whi
    old "I want to keep being fucked by you everyday!"
    new "B:whi: Ah! Ah! Ah! É tão grande!"

    # say L577 whi
    old "I- I never had any sex like this with my ex-husband either!"
    new "B:whi: Quero continuar a ser fodida por ti todos os dias!"

    # say L578 whi
    old "It’s unbelievable how good this is!"
    new "B:whi: N-Nunca tive sexo assim com o meu ex-marido!"

    # say L580 whi
    old "Yes! yes! yes!"
    new "Sra. White, já não consigo aguentar mais!"

    # say L603 pla
    old "Mrs. White, I can’t hold it in any longer!"
    new "B:whi: Sim! sim! sim!"

    # say L604 whi
    old "Cum! Cum inside me!"
    new "B:pla: Sra. White, não aguento mais!"

    # say L605 whi
    old "Oh my God! I have missed this cock so much!"
    new "B:whi: Gozar! Goza dentro de mim!"

    # say L606 whi
    old "I love being fucked by you!"
    new "B:whi: Meu Deus! Senti tanto a falta desta pica!"

    # say L613 whi
    old "Well, I must say that was wonderful."
    new "B:whi: Adoro ser fodida por ti!"

    # say L614 whi
    old "Just look at you Jade! You look so calm and relaxed now!"
    new "B:whi: Bem, devo dizer que foi maravilhoso."

    # say L615 jad
    old "Yeah, I think you’re absolutely right!"
    new "B:whi: Olha para ti, Jade! Estás tão calma e relaxada agora!"

    # say L616 jad
    old "I can’t believe how relaxed I am!"
    new "T(jad|tu|dizer): Não acredito como estou relaxada!"

    # say L617 jad
    old "I must say, I don’t even care about what’s happening with Hiashi right now. I hope he’s very happy with his new wife."
    new "B:jad: Não acredito como estou relaxada!"

    # say L618 jad
    old "If she doesn’t cheat on him."
    new "B:jad: Tenho de dizer que nem me importo com o que está a acontecer com Hiashi agora. Espero que ele esteja muito feliz com a nova esposa."

    # say L619 whi
    old "Hahahaha!"
    new "B:jad: Se ela não lhe for infiel."

    # say L620 jad
    old "Hahahaha."
    new "B:brn: Hahahaha!"

    # say L621 whi
    old "Well, I think we should better get dressed before your daughter gets home."
    new "B:jad: Hahahaha."

    # say L622 jad
    old "Right, right."
    new "B:whi: Bem, acho que devíamos melhor vestir-nos antes de a tua filha chegar a casa."

    # say L636 jad
    old "I- it's so big... Oh my God!"
    new "T(jad|tu|diz): É... é tão grande... Meu Deus!"

    # say L643 jad
    old "It’s so hot! So thick and hard!"
    new "B:jad: Não admira que Hinn sempre queira transar contigo!"

    # say L644 jad
    old "I can’t resist it!"
    new "B:jad: Está tão quente! Tão grosso e duro!"

    # say L648 jad
    old "Yes! Yes! Yes! Keep going!"
    new "B:jad: Não consigo resistir!"

    # say L649 jad
    old "Just like that!"
    new "B:jad: Sim! Sim! Sim! Continua!"

    # say L674 jad
    old "I'm about to cum honey!"
    new "B:jad: Ahhh! Adoro isto!"

    # say L676 jad
    old "L- let's do it!"
    new "B:jad: Estou prestes a gozar, querida!"

    # say L677 jad
    old "Let's cum together!!"
    new "B:jad: L- vamos fazer isso!"

    # say L685 jad
    old "Wow, that was wonderful honey."
    new "B:jad: Vamos gozar juntos!!"

    # say L686 jad
    old "And the shower it’s also working perfectly."
    new "B:jad: Que maravilha, meu amor."

    # say L687 jad
    old "Oh my God! It's too late, Come on honey, let’s get dressed."
    new "B:jad: E a duche também está a funcionar perfeitamente."


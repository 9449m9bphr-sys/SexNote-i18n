# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/JonStory.rpy
translate portuguese strings:

    # say L6 bil
    old "Oh... hey."
    new "... Uhh, olá."

    # say L7 pla
    old "... Uhh hi."
    new "T(pla|tu|say):... Olá."

    # say L8 bil
    old "This is a bit awkward... Do you need something?"
    new "Isto é um bocado embaraçoso... Precisas de algo?"

    # say L33 bil
    old "Weird."
    new "B:bil: Isto é um pouco embaraçoso... Precisas de algo?"

    # say L39 pla
    old "Oh, no, no sorry, I was just looking for Mrs. Jones."
    new "B:bil: Estranho."

    # say L41 pla
    old "... Alright, see you."
    new "B:pla: Oh, não, desculpa, eu estava só à procura da Sra. Jones."

    # say L53 pla
    old "Hi everybody, how are you doing?"
    new "B:pla:... Tchau, até logo."

    # say L55 jon
    old "Hi [pla] so happy to see you! We were talking about you..."
    new "B:gra: Olá [pla], que Deus esteja contigo!"

    # say L57 pla
    old "Oh! Really? What were you saying about me? Am I in trouble?"
    new "B:gra: Na verdade, estávamos a falar de ti com o Padre Morgan também."

    # say L58 jon
    old "Noo! It's the opposite, we are so grateful for what you've done for us."
    new "B:pla: Oh! Mesmo? O que estavas a dizer sobre mim? Estou metido em sarilhos?"

    # say L59 jon
    old "Billie is feeling good now and we can feel our church is a peaceful place again, all thanks to you."
    new "B:jon: Não! É o contrário, estamos tão gratos pelo que fizeste por nós."

    # say L60 pla
    old "Well... I-I just did what God told me to do... It was actually him, not me."
    new "B:jon: Billie está a sentir-se bem agora e podemos sentir que a nossa igreja é de novo um lugar pacífico, tudo graças a ti."

    # say L62 gra
    old "And that's why we want you to be part of our community, we want you to join our activities."
    new "B:pla: Bem... Eu-Eu apenas fiz o que Deus me disse para fazer... Na verdade, foi ele, não eu."

    # say L63 jon
    old "We saw how God works through your hands, you've shown us that you're like a saint."
    new "B:gra: E é por isso que queremos que faças parte da nossa comunidade, queremos que participes nas nossas atividades."

    # say L64 gra
    old "Join us, please! It would be our pleasure to have you here."
    new "B:jon: Vimos como Deus age através das tuas mãos, mostraste-nos que és como um santo."

    # say L65 pla
    old "(Yes! This is the perfect chance to get closer to them...)"
    new "B:gra: Junta-te a nós, por favor! Seria um prazer ter-te aqui."

    # say L66 pla
    old "I'm so glad to hear that, of course I will be more than happy to be here helping and being part of the community."
    new "T(pla|tu|say): Fico tão contente por ouvir isso, claro que estarei mais do que feliz por estar aqui a ajudar e a fazer parte da comunidade. A:pla: Posso começar sempre que tu quiseres... Só me diz o que preciso de fazer."

    # say L67 pla
    old "I can start whenever you want... Just tell me what to do."
    new "B:pla: Estou tão contente por ouvir isso, claro que ficarei mais do que feliz por estar aqui a ajudar e a fazer parte da comunidade."

    # say L69 jon
    old "Oh really hun, that's great!"
    new "B:pla: Posso começar quando tu quiseres... Só me diz o que fazer."

    # say L70 gra
    old "Well, our main interest is to attract more young people to the community."
    new "B:jon: Oh realmente querida, isso é ótimo!"

    # say L72 jon
    old "That's why we believe that you are the best to help us and with your example and attitude we believe that we will be able to attract many young people."
    new "B:gra: Bem, o nosso principal interesse é atrair mais jovens para a comunidade."

    # say L73 gra
    old "Even get to have altar girls in the church!"
    new "B:jon: É por isso que acreditamos que és o melhor para nos ajudar e com o teu exemplo e atitude acreditamos que conseguiremos atrair muitos jovens."

    # say L74 pla
    old "Wow, that's sounds good, so what do you want me to do?"
    new "B:gra: Até temos meninas do coro na igreja!"

    # say L75 gra
    old "Well, we have to wait a bit for that. Father Morgan is a bit busy these days and we can't start without him."
    new "B:pla: Wow, isso soa bem, então o que queres que eu faça?"

    # say L76 jon
    old "However, we still need help in other activities. And a young hand would be very useful."
    new "B:gra: Bem, temos de esperar um pouco por isso. O Padre Morgan está um bocado ocupado nestes dias e não podemos começar sem ele."

    # say L77 jon
    old "For example, cleaning the church after every mass is very tiring for just the two of us."
    new "B:jon: No entanto, ainda precisamos de ajuda noutras atividades. E uma mão jovem seria muito útil."

    # say L80 gra
    old "Perfect! So, you can come every afternoon to help us with the cleaning, the three of us can finish in a jiffy."
    new "B:jon: Por exemplo, limpar a igreja após cada missa é muito cansativo para apenas nós dois."

    # say L82 jon
    old "Great, then why don't we start tomorrow, okay?"
    new "B:gra: Perfeito! Então, podes vir todas as tardes para nos ajudar com a limpeza, os três conseguimos acabar num instante."

    # say L83 pla
    old "Alright! So I'll be back tomorrow."
    new "B:jon: Ótimo, então por que não começamos amanhã, ok?"

    # say L84 jon
    old "Thank you so much hun, see you tomorrow!"
    new "B:pla: Ótimo! Então volto amanhã."

    # say L86 pla
    old "S-see you Mrs. Jones and sister Grace."
    new "T: S-sê adeus à Sr.ª Jones e à irmã Grace."

    # say L104 jon
    old "Oh thank you honey, you are so kind."
    new "B:pla: Olá, bem, não quero deixar todo o trabalho só para vocês duas."

    # say L105 gra
    old "Ok, let me explain you, it's simple, we just have to clean up the church a bit... As you can see, it's a mess!"
    new "B:jon: Oh, obrigado querida, és tão simpática."

    # say L110 jon
    old "This will be too easy for you, cleaning won't be an issue..."
    new "B:jon: E recolhe o que não deveria estar na igreja neste momento... Todas essas coisas."

    # say L111 pla
    old "Don't worry, I wanna be as quick as possible."
    new "B:jon: Isto vai ser fácil para ti, limpar não será um problema..."

    # say L126 jon
    old "Great Hun, are you ready to start with cleaning?"
    new "B:pla: Olá irmã Grace, estou bem, obrigado por perguntar."

    # say L127 pla
    old "Sure, I'm ready to start."
    new "B:jon: Ótimo, tu estás pronta para começar a limpar?"

    # say L128 gra
    old "Perfect, let's start to clean the church."
    new "Perfeito, vamos começar a limpar a igreja."

    # say L141 jon
    old "Oh, thanks hun... I really appreciate your help on this."
    new "B:pla: Oh, não te preocupes. Posso acompanhar-te entretanto."

    # say L142 jon
    old "I'm old and you know... I'm not as flexible as I was before."
    new "B:jon: Oh, obrigado querida... Aprecio muito a tua ajuda com isto."

    # say L143 pla
    old "Hmm... I'm sorry to hear that... I think you're still young, though."
    new "B:jon: Sou velho e tu sabes... Não sou tão flexível como era antes."

    # say L144 jon
    old "You know, when I look at you... I see a very kind person, you're really nice, dear."
    new "B:pla: Hmm... Lamento ouvir isso... Acho que tu ainda és jovem, no entanto."

    # say L145 pla
    old "Haha, thanks Mrs. Jones!"
    new "B:jon: Sabes, quando te olho... vejo uma pessoa muito bondosa, és realmente simpática, querida."

    # say L146 jon
    old "You're like an angel... Sent by God!"
    new "B:pla: Haha, obrigado Sra. Jones!"

    # say L148 pla
    old "That's very nice of you but I'm just a normal guy..."
    new "B:jon: Tu és como um anjo... Enviado por Deus!"

    # say L149 jon
    old "You know dear... It's like destiny, I think you're here for a reason.."
    new "B:pla: Isso é muito gentil da tua parte, mas sou só um cara normal..."

    # say L150 pla
    old "Ehm... Really?"
    new "B:jon: Sabes querida... É como o destino, acho que estás aqui por uma razão..."

    # say L152 jon
    old "I've seen what you've done and well... Yeah! I think so..."
    new "B:pla: Ehm... Mesmo?"

    # say L153 jon
    old "You're very spiritual and you remind me of..."
    new "B:jon: Vi o que fizeste e bem... Sim! Acho que sim..."

    # say L154 pla
    old "Remind you of? W- Who?"
    new "B:jon: Tu és muito espiritual e lembras-me de..."

    # say L156 jon
    old "You remind me of my husband. When he was alive, he was so kind and strong, just like you."
    new "B:pla: Lembra-te de? Q- Quem?"

    # say L157 jon
    old "He was amazing, I truly miss him."
    new "B:jon: Tu lembras-me do meu marido. Quando ele estava vivo, era tão bondoso e forte como tu."

    # say L168 gra
    old "All good!"
    new "Ótimo! Sra. Jones? Precisamos começar a limpar, isto está mesmo uma desordem!"

    # say L169 gra
    old "Great! Mrs. Jones? We need to start cleaning, this is really a mess!"
    new "B:gra: Tudo bem!"

    # say L170 jon
    old "Yeah, sure sister Grace..."
    new "B:gra: Ótimo! Sra. Jones? Precisamos começar a limpar, isto está mesmo uma desordem!"

    # say L171 gra
    old "Let's get this done! We have many things to do."
    new "B:jon: Claro, irmã Grace..."

    # say L172 pla
    old "(I have to find the way to get closer to Mrs. Jones...)"
    new "B:gra: Vamos acabar com isto! Temos muitas coisas a fazer."

    # say L174 pla
    old "Yeah... Yeah, sure... Let's do it."
    new "A:jon: Uau! Que trabalho difícil! Estou exausto..."

    # say L188 jon
    old "Wow! That was a hard job! I'm exhausted..."
    new "B:pla: Sim... Claro... Vamos lá."

    # say L189 gra
    old "It was a lot, yeah... "
    new "B:jon: Uau! Que trabalho duro! Estou exausto..."

    # say L191 jon
    old "sister Grace, I'm gonna go now..."
    new "B:gra: Foi muito, sim..."

    # say L192 gra
    old "Oh, do you have to leave early today?"
    new "B:jon: irmã Grace, vou-me embora agora..."

    # say L193 jon
    old "Yes, I think it would be nice to spend some time with Billie too, I'll go to see her."
    new "B:gra: Oh, tens de sair mais cedo hoje?"

    # say L198 pla
    old "Bye Mrs. Jones, take care."
    new "T(pla|tu|say): Adeus Sra. Jones, cuide-se."

    # say L205 pla
    old "Thanks, we all worked really hard."
    new "A:gra: Tenho notado o quão espiritual e boa tu és... Estou um pouco embaraçada para te pedir isto, mas..."

    # say L207 gra
    old "I've noticed how spiritual and good you're... I'm a bit embarrased to ask you this but..."
    new "B:pla: Obrigado, todos trabalhámos muito."

    # say L208 gra
    old "But... I would like to ask for your help."
    new "B:gra: Tenho notado o quão espiritual e boa tu és... Sinto-me um pouco embaraçada em pedir-te isto, mas..."

    # say L210 pla
    old "My help? Sure, tell me sister Grace. What can I do for you?"
    new "B:gra: Mas... gostava de pedir a tua ajuda."

    # say L211 gra
    old "W- well... I wanna clean my spirit and my soul... I've been working on this with Father Morgan..."
    new "B:pla: A minha ajuda? Claro, diz-me, irmã Grace. O que posso fazer por ti?"

    # say L212 gra
    old "But to be honest I think you're much more spiritual than him, perhaps you could help me more..."
    new "B:gra: B-bem... Quero purificar a minha alma e o meu espírito... Tenho trabalhado nisso com o Padre Morgan..."

    # say L214 pla
    old "(I think see where this is going...)"
    new "B:gra: Mas a ser sincero, acho que tu és muito mais espiritual do que ele, talvez possas ajudar-me mais..."

    # say L215 gra
    old "I mean, you did the exorcism... You helped Billie and you're nice with everyone. I can feel your energy is different."
    new "B: pla: (Acho que vejo para onde isto vai...)"

    # say L216 gra
    old "It's divine and sacred."
    new "B:gra: Quero dizer, tu fizeste o exorcismo... Tu ajudaste a Billie e és simpática com todos. Posso sentir que a tua energia é diferente."

    # say L217 pla
    old "I'm glad you think that of me and if you truly believe I could help you out, I'll do it..."
    new "B:gra: É divino e sagrado."

    # say L218 gra
    old "I feel a bit embarrassed, I'll do what I believe is good and saint, and I'm thinking of you as a blessed man..."
    new "B:pla: Fico contente por pensares assim de mim e se realmente acreditas que posso ajudar-te, farei isso..."

    # say L219 gra
    old "I'll be honest with you... Since I saw you performing the ritual with Billie, I have been constantly thinking of you."
    new "B:gra: Sinto-me um pouco embaraçado, vou fazer o que acredito ser bom e santo, e estou a pensar em ti como um homem abençoado..."

    # say L223 gra
    old "I feel like you can help me as you helped her. You saved her and you could save me too."
    new "B:gra: Vou ser honesto contigo... Desde que vi a cerimónia que fizeste com a Billie, não tenho parado de pensar em ti."

    # say L224 pla
    old "(Wow) O- ok..."
    new "B:gra: Sinto que tu podes ajudar-me como ajudaste a ela. Tu salvaste-a e também podes salvar-me."

    # say L225 gra
    old "I need to cleanse my soul."
    new "B: pla: (Uau) O- ok..."

    # say L226 gra
    old "I would need to go down on you."
    new "B:gra: Preciso de purificar a minha alma."

    # say L228 pla
    old "W-What? D-down?"
    new "B:gra: Eu precisava fazer sexo oral contigo."

    # say L229 gra
    old "I have to pray in a different way."
    new "B:pla: Q-Quê? D-Desce?"

    # say L231 pla
    old "A- Are y- you s- sure about that?"
    new "T(pla|tu|say): A- T- tens a c- certeza disso?"

    # say L232 gra
    old "You helped Billie and everytime I'm next to you, I can feel your divine and strong energy."
    new "B:pla: A- Tens a certeza disso?"

    # say L233 gra
    old "W- Would you please... L- let me suck your... D- dick?"
    new "B:gra: Tu ajudaste a Billie e cada vez que estou perto de ti, sinto a tua energia divina e forte."

    # say L235 pla
    old "(This is really in line with the plan, I should do whatever it takes.)"
    new "B:gra: P- Poderias... D- deixar-me chupar o... P- pénis?"

    # say L236 pla
    old "S- sister Grace... I'll always do what is required to help you and to help the church's community."
    new "T(pla|tu|say): S- irmã Grace... Eu sempre farei o que for necessário para te ajudar e ajudar a comunidade da igreja."

    # say L237 gra
    old "I will really appreciate your help."
    new "B:pla: Irmã Grace... Eu sempre farei o que for necessário para te ajudar e ajudar a comunidade da igreja."

    # say L251 gra
    old "Wow, I do feel much better now, kinda renewed. I'm your faithful devotee."
    new "B:gra: Aprecio mesmo a tua ajuda."

    # say L252 gra
    old "I would do everything for you as you have done everything for our community."
    new "B:gra: Que alívio, sinto-me renovada. Sou a tua fiel devota."

    # say L253 pla
    old "(Oh hell! She really liked it.)"
    new "B:gra: Faria tudo por ti, assim como tu fizeste tudo pela nossa comunidade."

    # say L254 pla
    old "You don't have to... I'm glad to help sister Grace..."
    new "B: pla: (Oh hell! Ela realmente gostou...)"

    # say L256 gra
    old "And you're so humble..."
    new "B:pla: Não tens de... Estou feliz em ajudar a irmã Grace..."

    # say L257 gra
    old "I feel a bit embarrassed now, I've kept you here for quite a long time. I'm sure you have to rest."
    new "B:gra: E tu és tão humilde..."

    # say L259 pla
    old "Actually, yes, I do but it's fine."
    new "B:gra: Sinto-me um pouco embaraçado agora, tenho-te aqui há bastante tempo. Tenho a certeza de que precisas de descansar."

    # say L260 gra
    old "Thank you so much."
    new "B:pla: Na verdade, sim, mas está tudo bem."

    # say L261 pla
    old "Hmm ok... I- I think should go..."
    new "B:gra: Muito obrigado."

    # say L280 jon
    old "I'm more tired than last time... And my back is killing me."
    new "B:pla: Até logo, irmã Grace."

    # say L283 jon
    old "Oh no, it's not necessary, don't worry..."
    new "B:pla: Com certeza, ficarei feliz em fazer isso."

    # say L286 jon
    old "Hmm alright, but just this time."
    new "B:pla: Tudo bem, vou contigo, Sra. Jones, não é problema."

    # say L287 pla
    old "Sure, don't worry."
    new "Bem, tudo bem, mas só desta vez. Tudo bem, não te preocupes. Ok, pessoal, vejo-vos amanhã. Espero que melhore, Sra. Jones."

    # say L288 gra
    old "Ok guys, see you tomorrow. Hope you get better, Mrs. Jones."
    new "B:pla: Claro, não te preocupes."

    # say L289 jon
    old "Thank you honey."
    new "B:gra: Ok pessoal, vejo-vos amanhã. Espero que melhore, Sra. Jones."

    # say L295 jon
    old "I'm so glad you could come with me."
    new "B:jon: Obrigado, querida."

    # say L296 pla
    old "My pleasure Mrs. Jones."
    new "B:jon: Estou tão contente que tu pudesses vir comigo."

    # say L297 jon
    old "Come inside with me... Let me give you something to drink."
    new "B:pla: Com todo o prazer, Sra. Jones."

    # say L298 pla
    old "Hmm... Yes, why not?"
    new "B:jon: Entra comigo... Deixa-me oferecer-te algo de beber."

    # say L304 jon
    old "By the way, I'm still surprised at how similar you're to my husband when he was young."
    new "B:pla: Hmm... Sim, porquê não?"

    # say L305 pla
    old "Oh, really? I imagine how great he was."
    new "B:jon: Por acaso, ainda fico surpreendido com o quanto tu és parecido com o meu marido quando ele era jovem."

    # say L306 jon
    old "He was... So strong and manly."
    new "B:pla: Oh, realmente? Imagino o quão incrível ele era."

    # say L307 jon
    old "Just like you..."
    new "B:jon: Ele era... Tão forte e viril."

    # say L310 jon
    old "Hmm... I don't wanna put you in an uncomfortable position... Tell me more about yourself, we haven't talked about your spiritual development."
    new "B:jon: Just like you..."

    # say L311 pla
    old "(Actually, there is no a spiritual development...)"
    new "B:jon: Hmm... Não quero colocar-te numa posição desconfortável... Conta-me mais sobre ti, ainda não falámos do teu desenvolvimento espiritual."

    # say L312 pla
    old "Ahhh! Well... It started- hmm, one day when I was walking and... Suddenly I felt the light, like a warm light all around my arms... Yeah, it was something like that."
    new "B:pla: (Na verdade, não há um desenvolvimento espiritual...)"

    # say L315 jon
    old "I asked because I want you to be my spiritual guide, I want to feel the grace of God within me. "
    new "B:pla: Ahhh! Bem... Tudo começou- hmm, um dia quando eu estava a caminhar e... De repente senti uma luz, como uma luz quente em todo o meu corpo... Sim, foi algo assim."

    # say L316 pla
    old "Your spiritual guide? Ok, but how do you think I could help you?"
    new "B:jon: Perguntei porque quero que sejas o meu guia espiritual, quero sentir a graça de Deus dentro de mim."

    # say L318 jon
    old "Well... The first time I saw you, I felt really impressed by your beauty. You're extremely handsome."
    new "B:pla: O teu guia espiritual? Ok, mas como é que tu achas que eu poderia ajudar-te?"

    # say L319 jon
    old "And as I told you the other day... You remind me of my great husband."
    new "B:jon: Bem... A primeira vez que te vi, fiquei realmente impressionado com a tua beleza. Tu és extremamente bonito."

    # say L322 jon
    old "You know, when I look at you... I see that you could be my savior as he was years ago."
    new "B:jon: E como te disse há dias... Tu lembras-me do meu marido maravilhoso."

    # say L323 pla
    old "Y- your savior? What do you mean Mrs. Jones?"
    new "B:jon: Sabes, quando te olho... vejo que tu podes ser a minha salvadora como ela foi há anos."

    # say L324 jon
    old "Well, I know I look old but I have the needs of a young woman."
    new "B: pla: Y- a tua salvadora? O que queres dizer, Sra. Jones?"

    # say L325 pla
    old "Needs? Which type of needs?"
    new "B:jon: Bem, eu sei que pareço velha, mas tenho as necessidades de uma mulher jovem."

    # say L326 jon
    old "Don't you imagine which needs I have? It's really easy to guess, I'm a widow."
    new "B:pla: Necessidades? Que tipo de necessidades?"

    # say L327 pla
    old "I- I... Don't k- know if I- I am thinking wrong..."
    new "B:jon: Não imaginas quais são as minhas necessidades? É fácil de adivinhar, sou uma viúva."

    # say L328 jon
    old "I need a man in my life, I need to feel some adrenaline and you're like send by God... You're beautiful on the inside and outside."
    new "B:pla: E-Eu... Não sei se estou a pensar mal..."

    # say L330 jon
    old "You're like a saint man and I believe in you since you helped Billie... I truly believe you can guide my spiritual journey."
    new "B:jon: Preciso de um homem na minha vida, preciso sentir adrenalina e tu pareces enviado por Deus... Tu és lindo por dentro e por fora."

    # say L331 pla
    old "What? Me?"
    new "B:jon: Tu és como um santo e acredito em ti desde que ajudaste a Billie... Acredito verdadeiramente que podes guiar a minha jornada espiritual."

    # say L332 jon
    old "Yes, you! I saw how you cured my granddaughter and I am not planning to let you go."
    new "B:pla: O quê? Eu?"

    # say L333 jon
    old "Not without a taste of what is divine... I want you to be my holy savior until I feel what Billie felt."
    new "B:jon: Sim, tu! Vi como curaste a minha neta e não tenho planos de te deixar ir."

    # say L335 pla
    old "I- I don't know what to say... I mean, you're such a beautiful woman but... I don't know..."
    new "B:jon: Não sem um gosto do que é divino... Quero que sejas o meu salvador sagrado até sentir o que Billie sentiu."

    # say L336 jon
    old "You already have the answer... Follow the will of God, you know this is the right thing to do, handsome."
    new "B:pla: Eu... não sei o que dizer... Quero dizer, tu és uma mulher tão bonita, mas... não sei..."

    # say L337 pla
    old "(Ok, I think this can help me to do the ritual.)"
    new "B:jon: Tu já tens a resposta... Segue a vontade de Deus, sabes que isto é o certo a fazer, bonito."

    # say L338 pla
    old "Yes, if that is what you need, I'll do what is required. I'll follow God's will."
    new "B: pla: (Ok, acho que isto pode ajudar-me a fazer o ritual.)"

    # say L339 jon
    old "I have no doubts... You were sent to clean my sins like I used to do with my husband..."
    new "B:pla: Sim, se é isso que precisas, farei o que for necessário. Seguirei a vontade de Deus."

    # say L340 pla
    old "What would you like to do that reminds you of him?"
    new "B:jon: Não tenho dúvidas... Foste enviada para limpar os meus pecados como eu costumava fazer com o meu marido..."

    # say L341 jon
    old "Well, I would love to start by putting your dick inside my mouth and then brushing it with my sinful lips..."
    new "B:pla: O que gostarias de fazer que te lembre dele?"

    # say L342 pla
    old "... I guess God will be happy with that..."
    new "B:jon: Bem, adoraria começar por colocar o teu pénis na minha boca e depois acariciá-lo com os meus lábios pecaminosos..."

    # say L344 jon
    old "I want to have your sacred presence on my lips and keep the taste on my tongue..."
    new "B:pla:... Acho que Deus ficará contente com isso..."

    # say L345 pla
    old "(Maybe this is getting a bit out of hand?)"
    new "B:jon: Quero ter a tua presença sagrada nos meus lábios e manter o sabor na minha língua..."

    # say L360 jon
    old "That was incredible, you're a divine presence in my life and well..."
    new "B:pla: (Talvez isto esteja a ficar um bocado fora de controlo?)"

    # say L361 jon
    old "I do feel so renewed and younger now."
    new "B:jon: Isso foi incrível, tu és uma presença divina na minha vida e bem..."

    # say L362 pla
    old "Hmm... I just did what God told me to do... It was my pleasure to help you."
    new "B:jon: Sinto-me tão renovado e mais jovem agora."

    # say L363 jon
    old "Did you enjoy it? Isn't?"
    new "B:pla: Hmm... Eu apenas fiz o que Deus me disse para fazer... Foi um prazer ajudar-te."

    # say L365 jon
    old "Oh no hun! I'm sorry, I know this is just part of your holy duty... I shouldn't ask those things."
    new "B:jon: Gostaste? Não é?"

    # say L366 pla
    old "Y- Yes Mrs. Jones, it's m- my d- duty."
    new "B:jon: Oh não querida! Desculpa, sei que isto é só parte do teu dever sagrado... Não devia perguntar essas coisas."

    # say L367 pla
    old "I should go now... It's getting late."
    new "B: pla: S- Sim, Sra. Jones, é o m- meu dever."

    # say L369 jon
    old "Go with God, handsome... And thanks again. I'll be eager for more."
    new "B:pla: Devo ir agora... Está a ficar tarde."

    # say L370 pla
    old "S- sure, goodbye Mrs. Jones."
    new "B:jon: Vai com Deus, bonito... E obrigado mais uma vez. Estarei ansioso por mais."

    # say L386 gra
    old "It was nice, now the church looks much better."
    new "B:pla: C- claro, adeus Sra. Jones."

    # say L387 pla
    old "It looks better now..."
    new "B:gra: Foi agradável, agora a igreja fica muito melhor."

    # say L389 jon
    old "It's tiring to clean... "
    new "B:pla: Está melhor agora..."

    # say L390 jon
    old "I'll see tomorrow... I gotta go now."
    new "B:jon: É cansativo limpar..."

    # say L391 pla
    old "See you Mrs. Jones..."
    new "B:jon: Veremos amanhã... Tenho de ir agora."

    # say L392 gra
    old "Take care, dear."
    new "B:pla: Até logo, Sra. Jones..."

    # say L399 gra
    old "I'm glad it's just the two of us now."
    new "B:gra: Cuida-te, querida."

    # say L400 pla
    old "Hmm... Yeah, it's nice."
    new "B:gra: Fico contente por sermos só nós dois agora."

    # say L406 gra
    old "I have never felt so much grace within me, my body feels renewed."
    new "B:gra: Acho que não devia sentir-me tão bem quando estou contigo... Devia pagar com dor, devia sofrer..."

    # say L407 gra
    old "But I'm not sure if that is ok... A spiritual journey requires suffering and I do not feel that it's fair just to feel pleasure and purification through you."
    new "B:gra: Nunca senti tanta graça dentro de mim, o meu corpo sente-se renovado."

    # say L408 gra
    old "I need you to punish me, I have to do penance..."
    new "B:gra: Mas não tenho a certeza se isso está bem... Uma jornada espiritual requer sofrimento e não me parece justo sentir apenas prazer e purificação através de ti."

    # say L409 pla
    old "W-what?"
    new "B:gra: Preciso que me castigues, tenho de fazer penitência..."

    # say L410 gra
    old "Yes, I know is what God wants and I know that with pain I will purify my soul..."
    new "B:pla: O-oh?"

    # say L412 gra
    old "But I need you to guide and help me... Since you have given me so much purification, you should be the one punishing and showing me the way..."
    new "B:gra: Sim, eu sei que é o que Deus quer e sei que com a dor purificarei a minha alma..."

    # say L414 pla
    old "A- alright... B- but, h- how?"
    new "B:gra: Mas preciso que me guies e ajudes... Como me deste tanta purificação, deves ser tu a castigar-me e mostrar-me o caminho..."

    # say L415 gra
    old "You're like my master. I need you to see me as your sinful slave who needs to come out of the dark side."
    new "B:pla: A- tudo bem... B- mas, c- como?"

    # say L417 gra
    old "As I get naked, I know that God will enlighten you and act through you for your guidance."
    new "B:gra: Tu és como o meu mestre. Preciso que me vejas como a tua escrava pecadora que precisa sair do lado sombrio."

    # say L419 gra
    old "He'll tell you what to do..."
    new "B:gra: À medida que me desperto, sei que Deus te iluminará e agirá através de ti para a tua orientação."

    # say L420 gra
    old "Please! The pain and pleasure will go away but my submission and loyalty to you will remain eternally in my soul... I need it."
    new "B:gra: Ele dirá o que fazer..."

    # say L421 pla
    old "If that's what you need, I'll do it."
    new "B:gra: Por favor! A dor e o prazer passarão, mas a minha submissão e lealdade a ti permanecerão eternamente na minha alma... Eu preciso disso."

    # say L435 gra
    old "I would like to thank you... You can't imagine how important this was to me."
    new "B:pla: Se é isso que precisas, eu farei."

    # say L436 pla
    old "I- I am glad, sister Grace."
    new "B:gra: Gostaria de agradecer-te... Não imaginas o quanto isto foi importante para mim."

    # say L437 pla
    old "I should go now, I have to be home soon..."
    new "B:pla: I- Estou contente, irmã Grace."

    # say L439 gra
    old "Alright! I have to go as well. I'll be thinking of your great and massive..."
    new "B:pla: Devo ir agora, tenho de estar em casa em breve..."

    # say L456 lin
    old "hi [pla], how are you?"
    new "Olá [pla], como estás?"

    # say L460 lin
    old "Alright! I just wanna make sure you have everything ready because we're running out of time..."
    new "B:pla: Estou a trabalhar nisso, não precisas de te preocupar, vou fazer e tudo vai correr bem."

    # say L462 pla
    old "Hmm, okay, I'll have to rush the plans ... "
    new "B:lin: Ótimo! Só quero ter a certeza de que tens tudo pronto porque o tempo está a acabar..."

    # say L463 lin
    old "Great, and who will be with you in the ritual? Which humans?"
    new "B:pla: Hmm, okay, vou ter de acelerar os planos..."

    # say L464 pla
    old "Mrs. Jones and the sister Grace, they both have a lot of accumulated energy."
    new "T(pla|tu|say): A Sra. Jones e a irmã Grace, ambas têm muita energia acumulada."

    # say L465 lin
    old "Do they know what they have to do?"
    new "B:pla: A senhora Jones e a irmã Grace, ambas têm muita energia acumulada."

    # say L467 pla
    old "Well, not yet... But they'll do it, I have been working on getting closer to them and it's going better than I expected."
    new "B:lin: Eles sabem o que têm de fazer?"

    # say L468 lin
    old "Ok, I don't wanna put more pressure on you but we have to... We do need that energy to perform the ritual."
    new "B:pla: Bem, ainda não... Mas eles vão fazer, tenho estado a trabalhar para me aproximar deles e está a correr melhor do que esperava."

    # say L470 pla
    old "I know! In fact, I'm going to talk to them and get everything ready..."
    new "T(pla|tu|say): Eu sei! Na verdade, vou falar com eles e preparar tudo..."

    # say L472 lin
    old "Ok, since you have everything almost ready for the ritual... I wanna share some energy with you."
    new "B:pla: Eu sei! Na verdade, vou falar com eles e preparar tudo..."

    # say L474 pla
    old "S- Sure... Let's do it!"
    new "B:lin: Ok, já que tens tudo quase pronto para o ritual... Quero partilhar energia contigo."

    # say L475 lin
    old "All right, get naked and lie on the bed... "
    new "B:pla: Claro... Vamos lá!"

    # say L489 lin
    old "It's done, go and prepare everything for the ritual! "
    new "B:lin: Tudo bem, despe-te e deite-te na cama..."

    # say L490 pla
    old "Got it, thanks, see you!"
    new "B:lin: Está feito, vai preparar tudo para o ritual!"

    # say L491 lin
    old "See ya..."
    new "A melhor sorte!!! Estou tão entusiasmado por ti..."

    # say L492 lin
    old "The best of luck!!! I'm so excited for you..."
    new "B:lin: Até logo..."

    # say L507 pla
    old "Hi sister Grace, I'm ready to start cleaning..."
    new "B:lin: A melhor sorte!!! Estou tão entusiasmada por ti..."

    # say L515 gra
    old "Well... Now that you mentioned it, I need you to do something..."
    new "B:pla: É o que Deus quer que eu faça... Eu poderia ajudar ainda mais se necessário."

    # say L516 pla
    old "(Not punishment, please!)"
    new "B:gra: Bem... Agora que mencionaste, preciso que faças algo..."

    # say L517 pla
    old "Hmm, tell me sister Grace, what can I do for you?"
    new "B:pla: (Não é castigo, por favor!)"

    # say L518 gra
    old "Mrs. Jones is feeling a bit sick but I can't go to see her...  I can't leave the church right now. Would you please stop by her house to see how she's doing?"
    new "B:pla: Hmm, conta-me, irmã Grace, o que posso fazer por ti?"

    # say L519 pla
    old "I'm so sorry she's sick... I'll go right now."
    new "B:gra: A senhora Jones está um pouco indisposta, mas não posso ir vê-la... Não posso sair da igreja agora. Poderias passar na casa dela para ver como ela está?"

    # say L525 pla
    old "(Hmm... Actually, before I go... I should definitely talk to the nun about the ritual...)"
    new "Irmã Grace? Desculpa! Hmm... Quero dizer-te uma coisa antes de ir..."

    # say L529 pla
    old "Sister Grace? Sorry! Hmm... I wanna tell you something before I go..."
    new "B:pla: (Hmm... Na verdade, antes de eu ir... Deveria definitivamente falar com a irmã sobre o ritual...)"

    # say L530 gra
    old "Yeah? Tell me [pla]... What's that?"
    new "T(gra|formal|say): Sim? Diz-me [pla]... O que é?"

    # say L531 pla
    old "You said you were my faithful devotee and you would always be loyal to me, right?"
    new "T(pla|tu|diz): Tu disseste que eras o meu devoto fiel e que sempre serias leal a mim, certo?"

    # say L532 gra
    old "Yes, of course. After all you've done to me and for me, I would do anything for you."
    new "B:pla: Tu disseste que eras o meu devoto fiel e que sempre serias leal a mim, certo?"

    # say L533 pla
    old "Well... I have to do a spiritual ritual, it's very important and it has to be done here at the church... And I would like you to help me to perform it."
    new "B:gra: Sim, claro. Tendo em conta tudo o que fizeste por mim e a mim, faria qualquer coisa por ti."

    # say L534 gra
    old "Yes, I'm not even gonna question you about it, as a submissive being to your will, I will always be at your service."
    new "B:pla: Bem... Tenho de fazer um ritual espiritual, é muito importante e tem de ser feito aqui na igreja... E gostaria que me ajudasses a realizá-lo."

    # say L535 pla
    old "Well! That's great, thanks! I knew I could count on you."
    new "B:gra: Sim, nem vou questionar, como uma submissa à tua vontade, estarei sempre ao teu serviço."

    # say L536 pla
    old "I need you to make sure the church is empty at night, we can't allow sinful people to be here..."
    new "B:pla: Ótimo, obrigado! Sabia que podia contar contigo."

    # say L538 gra
    old "I'm always obedient to God and to you."
    new "B:pla: Preciso que te certifiques de que a igreja está vazia à noite, não podemos permitir que pessoas pecadoras estejam aqui..."

    # say L539 pla
    old "Hmm by the way... We won't be alone, one more person will join us, you already know her and I'm sure you'll do great during the ritual."
    new "B:gra: Eu sou sempre obediente a Deus e a ti."

    # say L540 gra
    old "One more person? Who?"
    new "B:pla: Hmm, a propósito... Não estaremos sozinhos, mais uma pessoa vai nos acompanhar, tu já a conheces e tenho a certeza de que vais fazer um ótimo trabalho durante o ritual."

    # say L541 pla
    old "Trust me... You know I'm the hand of God."
    new "B:gra: Mais uma pessoa? Quem?"

    # say L542 gra
    old "I'm so sorry!"
    new "B:pla: Confia em mim... Sabes que sou a mão de Deus."

    # say L543 pla
    old "Just make sure the place is ready..."
    new "B:gra: Desculpa muito!"

    # say L545 gra
    old "I'll do everything to please you."
    new "B:pla: Certifica-te de que o lugar está pronto..."

    # say L547 pla
    old "You're great! I'll go now since we need to know how Mrs. Jones is..."
    new "B:gra: Vou fazer tudo para te agradar."

    # say L548 gra
    old "Go with God..."
    new "B:pla: Tu és incrível! Vou-me embora agora, precisamos de saber como está a Sra. Jones..."

    # say L553 pla
    old "Hello? Mrs. Jones? "
    new "B:gra: Vai com Deus... T(pla|tu|say): Olá? Sra. Jones? A:pla: Estás aí?"

    # say L555 pla
    old "Are you here?"
    new "B:pla: Olá? Sra. Jones?"

    # say L565 jon
    old "Hi dear, I was waiting for you..."
    new "B:jon: Vem cá, bonito..."

    # say L567 pla
    old "Wow! Mrs. Jones what are you wearing?"
    new "B:jon: Olá querida, estava à espera de ti..."

    # say L576 jon
    old "I'm so happy you're here... How are you, handsome?"
    new "B:pla: Uau! Sra. Jones, o que é que está a usar?"

    # say L577 pla
    old "H- hi Mrs. Jones, I'm fine... But tell me how are you feeling?"
    new "B:jon: Estou tão feliz que estás aqui... Como estás, bonito?"

    # say L578 pla
    old "The sister Grace told me you have been quite sick..."
    new "B:pla: O- olá Sra. Jones, estou bem... Mas conta-me como estás a sentir-te?"

    # say L579 pla
    old "But you look d- different..."
    new "B:gra: A irmã Grace disse-me que estiveste bastante doente..."

    # say L581 jon
    old "I'm fine as you can see... Maybe a bit hot ..."
    new "B:pla: Mas tu pareces d- diferente..."

    # say L583 jon
    old "You should enjoy what you're seeing right now... As much as I'm enjoying having you here."
    new "B:jon: Estou bem como podes ver... Talvez um pouco quente..."

    # say L585 pla
    old "M- mrs. Jones, why are you wearing that?"
    new "B:jon: Deves aproveitar o que estás a ver agora... Tanto quanto eu estou a aproveitar a tua presença."

    # say L586 jon
    old "Well, You were the one bringing me this dress time ago... You made me remember my younger years with my husband..."
    new "B:pla: M- Sra. Jones, por que está a usar isso?"

    # say L587 jon
    old "I used to wear a similar dress to this one and my husband used to devore me with his hands..."
    new "B:jon: Foste tu quem me trouxe este vestido há algum tempo... Fizeste-me lembrar os meus anos mais jovens com o meu marido..."

    # say L588 jon
    old "We liked rough sex... You know..."
    new "B:jon: Costumava usar um vestido parecido com este e o meu marido costumava devorar-me com as mãos..."

    # say L589 pla
    old "(W- What?)"
    new "B:jon: Gostávamos de sexo rough... Sabes..."

    # say L590 jon
    old "I forgot you're a bit shy sometimes... But perhaps you forgot I'm not and I want to have you now!"
    new "B: pla: (Q- Que?)"

    # say L593 jon
    old "I'll take the initiative... I know you like when your cock is between my lips."
    new "B:jon: Esqueci-me que às vezes és um pouco tímido... Mas talvez tenhas esquecido que eu não sou e quero-te agora!"

    # say L594 jon
    old "And I know you're getting hard as fuck right now... Just let me take off your pants, handsome."
    new "B:jon: Vou tomar a iniciativa... sei que gostas quando o teu pénis está entre os meus lábios."

    # say L608 jon
    old "I'm feeling much better now... I should say thank you..."
    new "B:jon: E sei que estás a ficar duro como o diabo neste momento... Deixa-me tirar-te as calças, bonito."

    # say L609 pla
    old "(Hmm sure...) I hope you're much better now."
    new "B:jon: Estou a sentir-me muito melhor agora... Deveria agradecer..."

    # say L610 jon
    old "Totally hun... Thanks for passing by..."
    new "B:pla: (Hmm, claro...) Espero que estejas muito melhor agora."

    # say L611 pla
    old "Hmm... Mrs. Jones, I actually wanted to ask you a favor..."
    new "B:jon: Totalmente, querida... Obrigado por passares por aqui..."

    # say L613 jon
    old "A favor? Sure, anything for you, love..."
    new "B:pla: Hmm... Sra. Jones, na verdade queria pedir-lhe um favor..."

    # say L614 pla
    old "I'll have to perform a ritual at the church to clean the energies..."
    new "B:jon: A favor? Claro, tudo por ti, amor..."

    # say L615 pla
    old "And since we're closer now and you know that I've such a spiritual development, I would like you to be part of that ritual."
    new "B:pla: Terei de realizar um ritual na igreja para limpar as energias..."

    # say L616 pla
    old "Sister Grace would be there, you and me... Would you help me? "
    new "B:pla: E como estamos mais próximos agora e sabes que tenho um desenvolvimento espiritual, gostaria que fosses parte desse ritual."

    # say L618 jon
    old "You've done so much for me, hun... I already told you, I would do whatever you ask me to do. You can count on me for it."
    new "B:pla: A irmã Grace estaria lá, tu e eu... Tu me ajudarias?"

    # say L619 pla
    old "Thanks Mrs. Jones, I didn't expect less from you..."
    new "B:jon: Tu já fizeste tanto por mim, meu amor... Já te disse, faço o que tu me pedires. Podes contar comigo para isso."

    # say L620 pla
    old "I'll see at the church, now I should go..."
    new "B:pla: Obrigado, Sra. Jones, não esperava menos de ti..."

    # say L621 jon
    old "See you there, handsome."
    new "B:pla: Vejo-te na igreja, agora devo ir..."

    # say L637 pla
    old "Ok... Today is the ritual day!"
    new "B:jon: Vejo-te lá, bonito."

    # say L638 lin
    old "And you'll be great, we count on you..."
    new "B:pla: Ok... Hoje é o dia do ritual!"

    # say L639 pla
    old "I know Linett, I've everything ready and well... It'll be fine."
    new "B:lin: E vais ser ótimo, contamos contigo..."

    # say L643 pla
    old "Ohh! Ok..."
    new "B:pla: Ótimo! Não sabia que tu vinhas comigo..."

    # say L644 lin
    old "So are you ready... We gotta start the ritual now."
    new "B:pla: Ohh! Ok..."

    # say L645 pla
    old "Yeah... Let's do it!"
    new "B:lin: Então estás pronto... Temos de começar o ritual agora."

    # say L651 pla
    old "Oh, they are back there..."
    new "B:pla: Sim... Vamos lá!"

    # say L652 pla
    old "Great! It's time to start the ritual."
    new "B:pla: Oh, eles estão aí atrás..."

    # say L662 pla
    old "Mrs. Jones, sister Grace... Hi, I'm glad you both are here..."
    new "B:pla: Ótimo! É hora de começar o ritual."

    # say L663 jon
    old "Good night hun."
    new "B:pla: Sra. Jones, irmã Grace... Olá, fico contente que ambas estejam aqui..."

    # say L672 jon
    old "Oh, I invited her... As you said you are going to clean the bad energies I thought it would be a great idea to invite Billie..."
    new "B:pla: Billie? W- O que estás tu a fazer aqui?"

    # say L673 pla
    old "W- what? B- but she doesn't know what we are going to have se- ... An important ritual..."
    new "B:jon: Oh, eu convidei-a... Como disseste que vais limpar as más energias, achei que seria uma ótima ideia convidar a Billie..."

    # say L674 jon
    old "Oh, don't worry hun, I already explained it to her, she was really worried about her sexorcis-... I mean exorcism."
    new "B:pla: O- o quê? M-mas ela não sabe do que vamos ter... Um ritual importante..."

    # say L675 bil
    old "I wanted to come... I never thought that I could be religious having sex."
    new "B:jon: Oh, não te preocupes querida, já expliquei tudo a ela, estava mesmo preocupada com o seu sexorcis-... quero dizer, exorcismo."

    # say L676 bil
    old "And I wanna thank you for what you did for me as well..."
    new "B:bil: Quis vir... Nunca pensei que pudesse ser religioso a fazer sexo."

    # say L677 pla
    old "Hmm alright... I- I see..."
    new "B:bil: E quero agradecer-te pelo que fizeste por mim..."

    # say L680 pla
    old "Well ladies, this is a spiritual ritual in which we all will do a transfer of spirituality among us..."
    new "B:pla: (Oh shit, ela tem razão.)"

    # say L681 pla
    old "I've noticed how spiritual you all are and that's why I've chosen you for this."
    new "B:pla: Bem, senhoras, este é um ritual espiritual no qual faremos uma transferência de espiritualidade entre nós..."

    # say L682 pla
    old "We'll have to open our hearts to God and give to each other what's required..."
    new "B:pla: Reparei na vossa espiritualidade e é por isso que vos escolhi para isto."

    # say L683 jon
    old "I can't wait to do it... You have all of me for this..."
    new "B:pla: Teremos de abrir os nossos corações a Deus e dar um ao outro o que é necessário..."

    # say L684 gra
    old "I agree with Mrs. Jones..."
    new "B:jon: Não posso esperar mais... Tu tens todo eu para isto..."

    # say L685 pla
    old "The better we do it, the better our lives will be in the eyes of God..."
    new "B:gra: Concordo com a Sra. Jones..."

    # say L686 pla
    old "Put all your faith on me and I'll guide through the ritual, it's all about spirituality and love."
    new "B: pla: Quanto melhor o fizermos, melhor será a nossa vida aos olhos de Deus..."

    # say L687 bil
    old "Can't we just start?"
    new "B:pla: Coloca toda a tua fé em mim e guiarei-te através do ritual, tudo se trata de espiritualidade e amor."

    # say L688 pla
    old "Right, can you turn on the lights before we start?"
    new "B:bil: Não podemos começar logo?"

    # say L696 bil
    old "Let's start with the sex!"
    new "B:pla: Certo, podes ligar as luzes antes de começarmos?"

    # say L697 gra
    old "Ahhh."
    new "B:bil: Vamos começar com o sexo!"

    # say L698 jon
    old "Oh dear please calm down..."
    new "B:gra: Ahhh."

    # say L711 lin
    old "Good job! Now it's my turn!"
    new "B:jon: Oh dear, por favor, calma-te..."

    # say L734 pla
    old "W- Well... Thank you... It was an excellent ritual, you all did good and I'm very thankful..."
    new "B:lin: Bom trabalho! Agora é a minha vez!"

    # say L735 jon
    old "I'm happy we got to help you and you helped us during this ritual..."
    new "B: W- Bem... Obrigado... Foi um excelente ritual, vocês todos se saíram muito bem e estou muito grato..."

    # say L736 bil
    old "It was cool..."
    new "B:jon: Estou feliz que conseguimos ajudar-te e tu ajudaste-nos durante este ritual..."

    # say L739 pla
    old "I have to go now... "
    new "B:pla: Estou contente..."

    # say L748 pla
    old "Linett!?..."
    new "B:jon: Adeus, querida... Até logo!"

    # say L749 lin
    old "Hi... How are you feeling?"
    new "B:pla: Linett!?..."

    # say L750 pla
    old "I'm happy, we did it!"
    new "Bem... Não resultou..."

    # say L751 lin
    old "Well... It didn't work..."
    new "B:pla: Estou feliz, conseguimos!"

    # say L752 pla
    old "What? Why? What happened?"
    new "B:lin: Bem... Não funcionou..."

    # say L753 lin
    old "It simply didn't work... It happens sometimes, it's a complex ritual and well... This time it didn't work..."
    new "T(lin|tu|say): Simplesmente não funcionou... Às vezes acontece, é um ritual complexo e bem... Desta vez não resultou..."

    # say L754 pla
    old "Really? Now what?"
    new "B:lin: Não resultou... Às vezes acontece, é um ritual complexo e bem... Desta vez não resultou..."

    # say L755 lin
    old "There is nothing we can do now... We have to wait until christmas, there is no other way..."
    new "B:pla: Mesmo? E agora?"

    # say L756 lin
    old "During christmas there is a load of human energy all around and that's the only chance we will have..."
    new "B:lin: Não há nada que possamos fazer agora... Temos de esperar até ao Natal, não há outra maneira..."

    # say L757 lin
    old "For now there is nothing we can do..."
    new "B:lin: Durante o Natal há uma grande quantidade de energia humana por toda a parte e essa será a nossa única oportunidade..."

    # say L759 pla
    old "I see... We'll try for Christmas..."
    new "Entendo... Vamos tentar para o Natal..."


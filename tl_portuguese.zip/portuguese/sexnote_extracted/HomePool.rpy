# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/HomePool.rpy
translate portuguese strings:

    # say L13 pla
    old "I should talk with Brixxida first."
    new "Não, não, desculpa, estava só a passear."

    # say L59 ann
    old "Uhm, you get very nervous, kid..."
    new "B: pla: O quê? Não, eu não estava-"

    # say L61 ann
    old "Is this what you want to see?"
    new "B:ann: Hum, ficas muito nervoso, miúdo..."

    # say L66 ann
    old "Well, if that's what you want..."
    new "B:ann: É isto que queres ver?"

    # say L68 ann
    old "Just don't bother me while I sunbathe, ok?"
    new "B:ann: Bem, se é isso que tu queres..."

    # say L82 ann
    old "Didn't I tell you not to bother me? Don't keep bothering me."
    new "B:ann: Não me incomodes enquanto tomo sol, ok?"

    # say L84 pla
    old "Ok, sorry."
    new "Ok, desculpa."


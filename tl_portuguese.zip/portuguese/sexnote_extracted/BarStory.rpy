# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/BarStory.rpy
translate portuguese strings:

    # say L6 bri
    old "I said..."
    new "T(bri|tu|say): Eu disse..."

    # say L13 pla
    old "What? What's happening? Is there anything wrong?!"
    new "B:bri: Eu disse..."

    # say L14 bri
    old "What's wrong is that it's been a while since I created the portal we're going to use to restore the magic world."
    new "T(bri|tu|say): O que está mal é que já passou algum tempo desde que criei o portal que vamos usar para restaurar o mundo mágico."

    # say L16 bri
    old "But I haven't seen you make any progress with our objective ever since."
    new "T(bri|tu|say): Mas não tenho visto nenhum progresso com o nosso objetivo desde então."

    # say L17 bri
    old "Why is it taking so long for you to get to it?"
    new "B:bri: Mas não te vi a fazer qualquer progresso com o nosso objetivo desde então."

    # say L19 pla
    old "What?! You woke me up for that? What are you talking about?"
    new "T: O quê?! Acordaste-me para isto? Do que estás a falar?"

    # say L20 pla
    old "It's not as if it's easy you know?"
    new "T(pla|tu|say): Não é como se fosse fácil, sabes?"

    # say L22 pla
    old "Do you want me to just walk around and tell people {i}'Hey! let me get you pregnant'{/i}?"
    new "T(pla|tu|say): Queres que eu vá por aí a dizer {i}'Ei! Deixa-me engravidar-te'{/i}?"

    # say L25 bri
    old "That's not what you're going to do! You have to seduce them!"
    new "T(bri|tu|say): Isso não é o que vais fazer! Tens de os seduzir!"

    # say L27 bri
    old "I thought you were supposed to be charming to human females."
    new "T(bri|tu|say): Pensei que fosses suposto ser charmoso com as humanas."

    # say L29 bri
    old "Try that!"
    new "B:bri: Pensei que fosses suposto ser encantador com as mulheres humanas."

    # say L33 pla
    old "Why are you so worried about me doing it quickly anyway?"
    new "T: Porque estás tão preocupado comigo fazer isso depressa?"

    # say L35 pla
    old "I thought you had stabilized the portal. So we have time, right?"
    new "T(pla|tu|say): Pensei que tinhas estabilizado o portal. Então temos tempo, certo?"

    # say L36 bri
    old "Yeah, time to do the ritual properly."
    new "T(bri|tu|say): Sim, tempo para fazer o ritual direito."

    # say L38 bri
    old "Not to laze around and not get anything done!"
    new "B:bri: Sim, é hora de fazer o ritual direito."

    # say L44 bri
    old "And the fact that it's stable for now doesn't mean it's going to last forever."
    new "Se quisermos reformar o mundo mágico, precisamos agir depressa!"

    # say L46 bri
    old "If we want to reform the magic world we need to move fast!"
    new "Se quisermos reformar o mundo mágico, precisamos agir depressa! Não há tempo para ficar a preguiçar."

    # say L48 bri
    old "There's no time to just lay about doing nothing."
    new "B:bri: Se queremos reformar o mundo mágico, precisamos agir rápido!"

    # say L49 pla
    old "Ok, I get it I get it! I'll get to it!"
    new "T: Ok, percebi, percebi! Vou fazer já! Quando?"

    # say L50 bri
    old "When?"
    new "B:pla: Ok, percebi, percebi! Vou fazer isso!"

    # say L51 pla
    old "Soon!"
    new "T: Em breve!"

    # say L53 pla
    old "Jeez! What's gotten into you all of a sudden?!"
    new "A:bri: Vou lembrar-te que tu e a tua pequena amiga Linnet fizeram uma confusão danada com esta situação toda!"

    # say L57 bri
    old "I'll remind you that you and your little friend Linnet made a mess out of this entire situation!"
    new "T(bri|tu|say): Vou lembrar-te que tu e a tua pequena amiga Linnet fizeram esta situação toda uma bagunça!"

    # say L58 bri
    old "And I'm the one that's going to have to fix it!"
    new "E eu sou quem vai ter que arranjar isto! Portanto, como o portal não vai durar para sempre e tu claramente não queres recomeçar o processo do zero..."

    # say L60 bri
    old "So, since the portal won't last forever, and you clearly don't want to re-start the process from the beginning..."
    new "E eu sou quem vai ter que arranjá-lo!"

    # say L62 bri
    old "Start looking for the people we need!"
    new "B:bri: Então, como o portal não vai durar para sempre, e tu claramente não queres recomeçar o processo do zero..."

    # say L63 pla
    old "Ok, ok, I'll do it!... I guess I could start talking to people."
    new "T: Ok, ok, vou fazer!... Acho que posso começar a falar com as pessoas."

    # say L65 pla
    old "It's just that that's quite difficult to do, you know?"
    new "B:pla: Ok, ok, eu faço!... Acho que posso começar a falar com as pessoas."

    # say L66 bri
    old "Oh come on, it won't be that bad."
    new "T(bri|tu|say): Oh, vai correr bem, vais ver."

    # say L68 bri
    old "I bet you'll get to have plenty of fun."
    new "B:bri: Oh, vai lá, não vai ser assim tão mau."

    # say L81 pla
    old "What? No, no, no..."
    new "B:mo1: Estavas a falar com alguém? T(pla|tu|say): O quê? Não, não, não... A:pla: Só comigo próprio, sabes?"

    # say L82 pla
    old "Just to myself, you know?"
    new "B: pla: O quê? Não, não, não..."

    # say L97 pla
    old "Sure, no problem."
    new "B:mo1: Não precisas de ir ao escritório dela, basta deixá-los na receção do edifício."

    # say L99 mo1
    old "Thank you so much, honey. You are always so helpful."
    new "B:pla: Claro, sem problema."

    # say L108 pla
    old "Uhh... Yeah, Of course."
    new "T(pla|tu|say): Uhh... Sim, claro."

    # say L110 bri
    old "Okay, I'm coming with you. You won't stop our task, so I'll help you look for our first target."
    new "B:pla: Uhh... Sim, claro."

    # say L112 pla
    old "{b}*Sigh*{/b} Alright, let's go."
    new "T(pla|tu|say): {b}*Suspiro*{/b} Tudo bem, vamos lá."

    # say L141 bri
    old "At this rate you're never going to end with what we have to do!"
    new "T(bri|tu|say): A este ritmo, nunca vais acabar o que temos a fazer!"

    # say L142 bri
    old "You should be putting all your focus on that!"
    new "B:bri: A este ritmo nunca vais acabar o que temos a fazer!"

    # say L149 pla
    old "But I have to do this first! So let me finish here, and then we can start looking for people for your ritual!"
    new "B:bri: Deves concentrar-te nisso!"

    # say L151 bri
    old "Alright! But as soon as you finish, I'll pester you to get to it!"
    new "B:pla: Mas tenho de fazer isto primeiro! Deixa-me acabar aqui, e depois podemos começar a procurar pessoas para o teu ritual!"

    # say L152 pla
    old "Yeah, yeah, whatever."
    new "B:bri: Tudo bem! Mas assim que acabares, vou te atormentar para ires fazer isso!"

    # say L221 pla
    old "Oh... Uhh... Yeah, Hi Barbie, how are you doing?"
    new "B:pla: Sim, sim, tudo bem."

    # say L232 pla
    old "Uhh... No, actually, I didn't come to see her."
    new "B:pla: Oh... Uhh... Yeah, Olá Barbie, como estás?"

    # say L244 pla
    old "What? No, no, sorry."
    new "O quê? Não, não, desculpa."

    # say L245 pla
    old "I- uhm, I didn't mean to be rude."
    new "B:pla: O quê? Não, não, desculpa."

    # say L255 pla
    old "Sure, thank you."
    new "B:pla: Certo."

    # say L257 pla
    old "Thanks Barbie, I guess I'll see you later."
    new "B:pla: Claro, obrigado."

    # say L275 pla
    old "Yeah, I figured..."
    new "T: Sim, foi por isso que te interrompi enquanto estavas a falar com ela?"

    # say L276 pla
    old "Is that why you interrupted me while I was talking to her?"
    new "T(pla|tu|say): É por isso que me interrompeste enquanto eu estava a falar com ela?"

    # say L278 bri
    old "Well, it was important that you knew..."
    new "B:pla: Foi por isso que me interrompeste enquanto falava com ela?"

    # say L279 bri
    old "But anyway, that doesn't matter."
    new "B:bri: Bem, era importante que tu soubesses..."

    # say L281 bri
    old "What's important is that that woman you were talking with will be our first target."
    new "B:bri: Mas enfim, isso não importa."

    # say L283 bri
    old "Well, while you two were talking, I was examining her."
    new "B:bri: O importante é que aquela mulher com quem tu estavas a falar será o nosso primeiro alvo."

    # say L285 pla
    old "Yeah, I noticed... That was weird, luckily no one else can see you."
    new "B:bri: Bem, enquanto vocês estavam a conversar, eu estava a examiná-la."

    # say L287 bri
    old "Yeah, yeah, whatever, the point is that she's the first person you have to seduce for our ritual."
    new "B:pla: Sim, notei... Foi estranho, mas felizmente ninguém mais consegue ver-te."

    # say L288 pla
    old "Huh?! W- why? Why does it have to be her?"
    new "B:bri: Sim, sim, o que importa é que ela é a primeira pessoa que tens de seduzir para o nosso ritual."

    # say L290 bri
    old "Because she's the right specimen, she has just the right qualities we need for it."
    new "T(bri|tu|say): Porque ela é o espécime certo, tem exatamente as qualidades que precisamos para isso."

    # say L292 bri
    old "As far as you humans go, she's the best prospect I could have expected to find to start our ritual."
    new "T(bri|tu|say): Pelos padrões humanos, ela é a melhor candidata que eu poderia ter esperado encontrar para iniciar o nosso ritual."

    # say L294 pla
    old "Why? What's so special about her?"
    new "A:bri: Bem, como eu disse, ela tem as qualidades perfeitas... Para... para..."

    # say L296 bri
    old "Well, as I said she has the perfect qualities... To- to..."
    new "B:pla: Porquê? O que é tão especial nela?"

    # say L298 bri
    old "H- host and... Condense the magic power within her."
    new "B:bri: Bem, como eu disse, ela tem as qualidades perfeitas... Para..."

    # say L299 bri
    old "Her body composition is just the right one."
    new "B:bri: H- hospedeira e... Condense a energia mágica dentro dela."

    # say L300 pla
    old "Right..."
    new "T: Tu: Certo..."

    # say L301 bri
    old "Besides, this should be easy to do, right?"
    new "A:bri: Não é ela o tipo de mulher que vocês homens gostam?"

    # say L303 bri
    old "Isn't she the type of female you male humans like?"
    new "B:bri: Além disso, isto deve ser fácil de fazer, certo?"

    # say L305 bri
    old "Her mammary glands are gigantic, even for the standards of what your species would consider big."
    new "B:bri: Não é ela o tipo de mulher que vocês humanos masculinos gostam?"

    # say L309 bri
    old "So don't think too much about it. Just focus on having a good time."
    new "Se a seduzires e implantares a magia nela, vais gostar, não vais?"

    # say L310 bri
    old "If you seduce her, and implant the magic within her you'll enjoy it, won't you?"
    new "B:bri: Então não penses muito nisso. Só te concentres em divertir-te."

    # say L311 pla
    old "Ugh, I guess you're right."
    new "T(pla|tu|say): Ugh, acho que tens razão."

    # say L313 pla
    old "But I barely know her, we have never exchanged more than a couple of words, how the hell am I going to seduce her?"
    new "B:pla: Ugh, acho que tens razão."

    # say L314 bri
    old "Don't worry, I'll help you with that."
    new "T(bri|tu|say): Não te preocupes, vou ajudar-te com isso."

    # say L315 pla
    old "Hahaha... Really? How?"
    new "B:bri: Não te preocupes, vou ajudar-te com isso."

    # say L317 bri
    old "By using magic of course!"
    new "B:pla: Hahaha... A sério? Como?"

    # say L319 bri
    old "There's a lot of magic you still don't know about, you've barely scratched the surface of what's possible."
    new "T(bri|tu|say): Há muito mais magia do que tu ainda não conheces, mal arranhous a superfície do que é possível."

    # say L321 bri
    old "By employing a simple mind reading spell, I can get inside her thoughts and emotions."
    new "B:bri: Há muita magia que ainda não conheces, mal raspaiste a superfície do que é possível."

    # say L322 bri
    old "And let you know what she has in her mind while you're speaking to her."
    new "B:bri: Com um simples feitiço de leitura de pensamentos, posso entrar na mente e nas emoções dela."

    # say L324 bri
    old "I can even read deep thoughts, and see if anything is influencing her deep mind."
    new "B:bri: E deixa-te saber o que ela tem na cabeça enquanto falas com ela."

    # say L326 pla
    old "I have to say, that sounds amazing."
    new "T(pla|tu|say): Tenho de dizer, isso soa incrível."

    # say L328 bri
    old "It is, but it's also inconvinient. Since I'll be reading her mind and telling you what she's thinking."
    new "T(bri|tu|say): É, mas também é inconveniente. Vou estar a ler a mente dela e a dizer-te o que ela está a pensar."

    # say L329 bri
    old "That means that whenever you talk to her I'll have to be with you."
    new "B:bri: É, mas também é inconveniente. Como vou ler a mente dela e dizer o que ela está pensando."

    # say L331 bri
    old "Besides, in order to maintain the mind-reading, I have to keep the channel between her mind and mine open."
    new "B:bri: Isso significa que sempre que tu falares com ela, eu terei de estar contigo."

    # say L332 bri
    old "That drains the magic power too quickly."
    new "Além disso, para manter a leitura da mente, tenho de manter o canal entre a mente dela e a minha aberto. Isso esgota a energia mágica muito rapidamente. Por isso, vais ter de garantir que tiras bom proveito das informações que consigo fornecer-te."

    # say L333 bri
    old "So you'll have to be sure to make good use of the information I'm able to give you."
    new "T(bri|tu|say): Então vais ter de ter a certeza de aproveitar bem a informação que consigo dar-te."

    # say L335 pla
    old "I get it, but if it's that difficult, why don't you teach me the spell to do it myself?"
    new "T: Entendi, mas se é tão difícil, por que não me ensinas o feitiço para eu fazer sozinho? Assim posso ler a mente por conta própria e as tuas reservas mágicas não se esgotam."

    # say L336 pla
    old "That way I can just do the mind reading by myself, and your magic reserves won't have to be drained."
    new "B:pla: Entendo, mas se é tão difícil, por que não me ensinas o feitiço para eu fazer sozinho?"

    # say L338 bri
    old "Sadly I can't do that, this spell is a level beyond your current abilities."
    new "T(bri|tu|say): Infelizmente não posso fazer isso, este feitiço está além das tuas capacidades atuais. A:bri: A complexidade é demasiado elevada para ti lidares com ela neste momento."

    # say L339 bri
    old "The complexity is too high for you to handle right now."
    new "T(bri|tu|say): A complexidade é demasiado alta para tu conseguires lidar neste momento."

    # say L341 bri
    old "Maybe if you had been a bit more diligent with your practices..."
    new "B:bri: A complexidade é demasiado alta para tu conseguires lidar agora."

    # say L342 bri
    old "And had improved your abilities with the Sexnote, you'd be able to do it."
    new "B:bri: Talvez se tivesses sido um pouco mais diligente nos teus treinos..."

    # say L343 bri
    old "But it didn't happen, did it?"
    new "T(bri|tu|say): Mas isso não aconteceu, certo?"

    # say L345 bri
    old "So, I'll have to do the hard work of reading her mind and telling you what to say."
    new "B:bri: Mas não aconteceu, certo?"

    # say L346 pla
    old "I see, I guess that's how it has to be."
    new "B:bri: Então, vou ter que fazer o trabalho difícil de ler a mente dela e te dizer o que falar."

    # say L348 pla
    old "Oh! I know!"
    new "B:pla: Entendo, acho que tem que ser assim."

    # say L357 bri
    old "First, it's not a mental power; it works by {b}influencing{/b}, not {b}forcing{/b} the will of the target."
    new "T(bri|tu|dizer): Primeiro, não é uma força mental; funciona ao {b}influenciar{/b}, não ao {b}forçar{/b} a vontade do alvo."

    # say L361 bri
    old "Is not like you can just tell someone to fall in love with you or anything."
    new "T(bri|tu|say): Não é como se pudesses dizer a alguém para se apaixonar por ti ou algo assim."

    # say L365 bri
    old "So, even if you go up to her and tell her to do something, it won't work, since you barely know each other."
    new "B:bri: Não é só isso, tu não podes usá-lo em alguém se não tiveres uma ligação com ela."

    # say L369 bri
    old "It is, you see why I keep pestering you to start working on the ritual? It's a lot of work, and we don't have much time."
    new "T(bri|tu|say): É, é por isso que insisto para começares a trabalhar no ritual. É muito trabalho e não temos muito tempo."

    # say L370 pla
    old "Yeah, yeah I get it."
    new "B:bri: É, vês porquê insisto para começares a trabalhar no ritual? É muito trabalho e não temos muito tempo."

    # say L372 bri
    old "Good, now that you understand it, let's go."
    new "T(bri|tu|say): Ótimo, agora que percebeste, vamos."

    # say L374 pla
    old "What?! Now?"
    new "B:bri: Bom, agora que percebeste, vamos."

    # say L376 bri
    old "Yes, now! Haven't you understood how urgent this is?"
    new "B:pla: Que?! Agora?"

    # say L377 pla
    old "But we just arrived! I was just there a moment ago! If I go back now, it will look weird."
    new "B:bri: Sim, agora! Não percebeste ainda o quão urgente isto é?"

    # say L379 bri
    old "Don't you worry about that, after all, I will be reading her mind and telling you what you need to know to handle the situation."
    new "T(bri|tu|say): Não te preocupes com isso, afinal, vou ler a mente dela e dizer-te o que precisas saber para lidar com a situação."

    # say L380 pla
    old "You sound very confident about this."
    new "Não é como se fosse difícil..."

    # say L381 bri
    old "Well is not as if it's difficult..."
    new "B:pla: Tu pareces muito confiante nisso."

    # say L383 bri
    old "You humans are so easy to manipulate! You just have to say the right thing and you fold!"
    new "T(bri|tu|say): Vocês humanos são tão fáceis de manipular! Basta dizer a coisa certa e vocês cedem!"

    # say L385 pla
    old "We do? How do you know that?"
    new "Tu fazes? Como é que tu sabes isso?"

    # say L386 bri
    old "I- I mean..."
    new "T(bri|tu|say): I- I mean..."

    # say L388 bri
    old "It's what I've observed in my time here watching you and the other humans."
    new "B:bri: I- I mean..."

    # say L390 pla
    old "Hmm... alright."
    new "T: Hmm... bem."

    # say L391 pla
    old "I guess you're right."
    new "Claro que tenho razão!"

    # say L393 bri
    old "Of course I am!"
    new "A:bri: Agora, vamos seduzir aquele humano com as glândulas mamárias grandes!"

    # say L394 bri
    old "Now, let's go seduce that human with the big mammary glands!"
    new "B:bri: Claro que sim!"

    # say L411 pla
    old "... Again."
    new "B:pla: Olá, Barbie."

    # say L417 pla
    old "Uhm, no."
    new "B: pla:... Outra vez."

    # say L419 pla
    old "I actually came to talk with you."
    new "T: Na verdade, vim falar contigo."

    # say L422 pla
    old "Hmm, yeah..."
    new "B:pla: Vim falar contigo."

    # say L424 pla
    old "About what..."
    new "B:pla: Hmm, sim..."

    # say L427 bri
    old "Don't worry, I have this."
    new "B:bri: Suspiro! Olha para ti a lutar para pensar em algo."

    # say L435 pla
    old "Is just that you looked a little sad to me when I saw you."
    new "T: É que tu parecias um pouco triste quando te vi."

    # say L436 pla
    old "So I was wondering if there's anything that I could do for you, maybe you would like to talk about it?"
    new "B:pla: É que tu parecias um pouco triste quando te vi."

    # say L447 bri
    old "That's a lie! She's feeling a great sadness!"
    new "B:pla: Então estava a pensar se há algo que eu possa fazer por ti, talvez queiras falar sobre isso?"

    # say L448 bri
    old "I don't know yet what it is, but she's definitely sad about something."
    new "T(bri|tu|say): Ainda não sei ao certo o que é, mas ela está definitivamente triste com algo."

    # say L450 pla
    old "Are you sure about it?"
    new "T(pla|tu|diz): Tens a certeza disso?"

    # say L451 pla
    old "I don't want to be annoying or anything, is just that you seem like you have a lot on your mind."
    new "T: Não quero ser incómodo, mas parece que tens muita coisa na cabeça."

    # say L464 bri
    old "It's just hard to tell about what... She has a lot of emotions and thoughts going through her..."
    new "B:bri: Oh! Parece que ela está frustrada com algo..."

    # say L465 bri
    old "Just give me a second."
    new "B:bri: É difícil dizer sobre o que... Ela tem muitas emoções e pensamentos a passar..."

    # say L467 pla
    old "Really? That's a relief to hear, it's good that you're doing so well."
    new "T:tu: Realmente? É um alívio ouvir isso, é bom que estejas a ir tão bem."

    # say L468 pla
    old "It just looked for a moment there like you had something in your mind."
    new "B:pla: Mesmo? É um alívio ouvir isso, é bom que estejas a correr tão bem."

    # say L484 bri
    old "And it's related to why she's feeling frustrated."
    new "E está relacionado com o motivo dela estar frustrada. Ela falhou recentemente em algo..."

    # say L485 bri
    old "She recently failed at something..."
    new "E está relacionado com o motivo dela estar frustrada. Ela falhou recentemente em algo... Uma audição!"

    # say L487 bri
    old "An audition!"
    new "Uma audição! É quando alguém se candidata a um papel ou posição, normalmente em teatro, cinema ou música, fazendo uma breve apresentação para um grupo de pessoas que decidem se essa pessoa é adequada para o papel."

    # say L490 bri
    old "What's an audition?"
    new "B:bri: Uma audição!"

    # say L494 pla
    old "Maybe I'm just projecting myself."
    new "T(pla|tu|diz): Talvez esteja só a projectar-me. A:pla: Vês, recentemente falhei numa entrevista para um emprego que queria."

    # say L496 pla
    old "You see, I recently failed an interview for a job I wanted."
    new "T(pla|tu|say): Tu vês, recentemente falhei numa entrevista para um emprego que queria. A:pla: Sim... Eu realmente queria conseguir. E pensei que era o melhor para isso, mas a equipa de recrutamento escolheu outra pessoa."

    # say L501 pla
    old "Yeah... I really wanted to get it. And I thought I was the best for it, but the hiring team chose someone else."
    new "B:pla: Tu vês, recentemente falhei numa entrevista para um emprego que queria."

    # say L516 pla
    old "Yeah, it was a huge {b}disappointment{/b} that I wasn't able to get it."
    new "T: Sim, foi uma grande {b}desilusão{/b} não ter conseguido."

    # say L520 pla
    old "I think that, sadly, sometimes our projects don't turn out the way we want them to. You know?"
    new "T(pla|tu|say): Acho que, tristemente, por vezes os nossos projetos não saem como queremos. Sabes?"

    # say L523 pla
    old "You do?"
    new "B:pla: Acho que, infelizmente, por vezes os nossos projetos não saem como queremos. Sabes?"

    # say L529 pla
    old "Yeah, that's right."
    new "B:pla: Tu fazes?"

    # say L530 pla
    old "But you know what? I think I'll give it another go and I'll try to get that job."
    new "B:pla: Sim, é verdade."

    # say L536 pla
    old "Well, I guess I'll just have to try again, and again until I make it."
    new "B:pla: Mas sabes o quê? Acho que vou tentar de novo e conseguir aquele emprego."

    # say L544 pla
    old "Do you? What do you mean?"
    new "B:pla: Não quero desistir disso por nada."

    # say L547 pla
    old "Is there something you shouldn't give up on?"
    new "B:pla: Tu? O que queres dizer?"

    # say L548 bri
    old "Ohh, he is not bad at this..."
    new "B:pla: Há algo em que não deves desistir?"

    # say L551 pla
    old "Come on, I know there's something on your mind that's been making you feel rather bad."
    new "B:bri: Ohh, ele não é nada mau nisto..."

    # say L554 pla
    old "If you need to talk about it I'll be more than happy to hear you."
    new "B:pla: Vamos, sei que há algo que te tem deixado bastante mal."

    # say L556 pla
    old "After all... I already told you about my situation."
    new "B:pla: Se precisas de falar disso, estou mais do que disposto a ouvir-te."

    # say L558 pla
    old "Maybe I could help you with yours."
    new "T(pla|tu|say): Talvez eu possa ajudar-te com a tua."

    # say L564 pla
    old "What? What do you mean?"
    new "B:pla: Talvez eu possa ajudar-te com o teu."

    # say L566 pla
    old "Listen, if this is something you want, and it's important to you, there's no way that it is ridiculous!"
    new "B:pla: O quê? O que queres dizer?"

    # say L578 pla
    old "Listen Barbie."
    new "B:bri: O que ela está a transmitir mais intensamente é uma sensação muito profunda de insegurança."

    # say L579 pla
    old "I understand that sometimes things don't go the way we want them to."
    new "B:pla: Escuta, Barbie."

    # say L581 pla
    old "But if it's something that's really important for you, I think it's worth it to give it a shot."
    new "T: Mas se for algo realmente importante para ti, acho que vale a pena tentar."

    # say L583 pla
    old "Don't you think? Why don't you let me know about it?"
    new "B: Mas se for algo realmente importante para ti, acho que vale a pena tentar."

    # say L599 pla
    old "I see, it must be very frustrating to deal with that."
    new "B:pla: Não achas? Por que não me dizes o que pensas?"

    # say L601 pla
    old "But I'm sure you still can make that dream a reality..."
    new "B:pla: Entendo, deve ser muito frustrante lidar com isso."

    # say L602 pla
    old "I mean, I'm sure there are a lot of auditions being held every day, aren't there?"
    new "B:pla: Mas tenho a certeza de que ainda podes tornar esse sonho realidade..."

    # say L604 pla
    old "You might land a role sooner rather than later, and that could propel you upward, isn't that right?"
    new "B:pla: Quero dizer, tenho a certeza de que há muitas audições todos os dias, não é?"

    # say L614 pla
    old "Why would you say that?"
    new "B:pla: Podes conseguir um papel mais cedo do que pensas, e isso pode impulsionar-te para cima, não é verdade?"

    # say L626 pla
    old "That's terrible! They have no right to treat you that way!"
    new "B:pla: Porque dirias isso?"

    # say L627 pla
    old "Besides, it isn't fair to say something like that."
    new "Além disso, não é justo dizer algo assim."

    # say L630 pla
    old "I'm sorry about that, Barbie."
    new "B:pla: Além disso, não é justo dizer algo assim."

    # say L635 pla
    old "No, they're not."
    new "B:pla: Lamento isso, Barbie."

    # say L637 pla
    old "You don't have to believe that just because they say it to you."
    new "B:pla: Não, não são."

    # say L646 bri
    old "Keep talking to her, maybe she'll open up more."
    new "T(bri|tu|say): Continua a falar com ela, talvez ela se abra mais."

    # say L648 pla
    old "I mean, I'm sure you've faced some obstacles, right?"
    new "Quero dizer, tenho a certeza de que enfrentaste alguns obstáculos, certo?"

    # say L650 bri
    old "Something just came up on her mind!"
    new "A:bri: Algo sobre..."

    # say L651 bri
    old "Something about..."
    new "B:bri: A ideia acabou de lhe ocorrer!"

    # say L652 bri
    old "{i}Number of auditions?{/i}"
    new "T(bri|tu|say): {i}Número de audições?{/i}"

    # say L656 pla
    old "({i}I think I know what she means!{/i})"
    new "T: ({i}Acho que sei o que ela quer dizer!{/i})"

    # say L664 pla
    old "You see? It isn't your fault."
    new "B:pla: Como, já conseguiste arranjar bastantes audições? Aposto que não conseguiste ir a muitas, certo?"

    # say L681 bri
    old "Practice! She's thinking about not being able to practice!"
    new "B:bri: Não tenho a certeza, a mente dela está um bocado embaçada."

    # say L683 pla
    old "I mean, you are working here full time, I bet it's very difficult to do things like acting if you don't have enough practice time."
    new "Quero dizer, tu trabalhas aqui a tempo inteiro, apostos que é muito difícil fazer coisas como atuar se não tiveres tempo suficiente para praticar."

    # say L684 pla
    old "Right?"
    new "B:pla: Quero dizer, tu trabalhas aqui a tempo inteiro, deves achar muito difícil fazer coisas como atuar se não tens tempo suficiente para praticar."

    # say L692 bri
    old "She's not thinking about time [pla], there's something else there."
    new "T(bri|tu|say): Ela não está a pensar no tempo [pla], há algo mais."

    # say L696 bri
    old "I don't know what she means by that."
    new "B:bri: Parceiros?"

    # say L697 pla
    old "{i}But I think I do! Thanks Brixxida!{/i}"
    new "T(tu|diz): {i}Mas eu acho que sei! Obrigado, Brixxida!{/i}"

    # say L702 pla
    old "It must be very difficult  to find partners to practice with."
    new "T(pla|tu|say): Deve ser muito difícil encontrar parceiros para praticar."

    # say L704 pla
    old "And even if you did find them, making the space to practice must be very difficult. Right?"
    new "B:pla: Deve ser muito difícil encontrar parceiros para praticar."

    # say L710 pla
    old "But you know, those things can be dealt with."
    new "Mas sabes, essas coisas podem ser resolvidas."

    # say L712 pla
    old "How about I help you with them?"
    new "B:pla: Mas sabes, essas coisas podem ser resolvidas."

    # say L719 pla
    old "Uhm... W- well..."
    new "T(pla|tu|say): Hum... B- bem..."

    # say L720 pla
    old "S- since you can't practice with other actors, how about I do it with you?"
    new "B:pla: Hum... B- bem..."

    # say L721 pla
    old "I could give you pointers and help you memorize your lines."
    new "B: S- já que não podes praticar com outros atores, que tal eu fazer isso contigo?"

    # say L730 pla
    old "M- maybe I could help you find another audition."
    new "T: M- talvez eu pudesse ajudar-te a encontrar outra audição."

    # say L731 pla
    old "I understand that you're very busy."
    new "T: Entendo que estás muito ocupado."

    # say L732 pla
    old "So, how about I'm the one that searches around, and helps you find auditions for roles that you may be good at?"
    new "T: Então, como se eu fosse o teu agente, posso procurar por aí e ajudar-te a encontrar castings para papéis que te possam interessar?"

    # say L737 pla
    old "Y- Your agent?"
    new "B:pla: Então, e se eu for eu a procurar, e ajudar-te a encontrar audições para papéis que possas ser boa?"

    # say L742 pla
    old "I- I don't think that's..."
    new "B: pla: T-Tua agente?"

    # say L748 bri
    old "Yes! Say yes! That's exactly what she wants! I can see it in her mind!"
    new "B:pla: I- Acho que isso não é..."

    # say L752 bri
    old "We'll figure out how to do that later!"
    new "B:bri: O que é que estás tão hesitante? Só diz sim ou não vais conseguir estabelecer uma relação com ela!"

    # say L753 pla
    old "{b}*Sigh*{/b}"
    new "T: {b}*Suspiro*{/b}"

    # say L756 pla
    old "Yeah, you're right, I would be acting as your manager."
    new "... Acho que sim."

    # say L757 pla
    old "... I guess."
    new "B:pla: Sim, tens razão, eu estaria a atuar como a tua gestora."

    # say L759 pla
    old "Well, I just want to help you."
    new "B:pla:... Acho que sim."

    # say L761 pla
    old "After all, I told you you shouldn't give up on your dreams."
    new "B:pla: Bem, só quero ajudar-te."

    # say L763 pla
    old "So... How about I go home for now and start making some calls?"
    new "B:pla: Afinal, disse-te que não deves desistir dos teus sonhos."

    # say L765 pla
    old "And if something comes up I'll let you know."
    new "B:pla: Então... Que tal eu ir para casa e começar a fazer algumas chamadas?"

    # say L778 pla
    old "Uhm, happy to help..."
    new "B:pla: E se algo surgir eu aviso."

    # say L779 pla
    old "I guess I'll see you later then, Bye."
    new "B:pla: Hum, feliz por ajudar..."

    # say L795 pla
    old "Ok, I think that went well."
    new "A:bri: Do que estás a falar?! Porque não tiveste sexo com ela?!"

    # say L797 bri
    old "What are you talking about?! Why didn't you have sex with her?!"
    new "B:pla: Ok, acho que correu bem."

    # say L799 bri
    old "I told you, you humans are very easy to manipulate."
    new "B:bri: Do que estás a falar?! Porque não tiveste sexo com ela?!"

    # say L801 bri
    old "I thought that by helping you talk to her you would already be having sex with her!"
    new "B:bri: Eu já te disse, vocês humanos são muito fáceis de manipular."

    # say L803 bri
    old "You know we don't have much time!"
    new "B:bri: Pensei que, ao ajudar-te a falar com ela, já estarias a ter relações com ela!"

    # say L805 pla
    old "Well, I'm sorry, I thought you didn't have any spells that would make her have sex with me right away."
    new "B:bri: Sabes que não temos muito tempo!"

    # say L806 bri
    old "I don't have any, that doesn't exist."
    new "T(bri|tu|say): Não tenho, isso não existe."

    # say L808 pla
    old "Then how about you let me handle this and stop yelling at me about it?"
    new "T: Tu: Então, por que não me deixas lidar com isso e paras de gritar comigo sobre o assunto?"

    # say L810 pla
    old "What you told me about her barely helped me a little to connect with her."
    new "B:pla: Então deixa-me lidar com isso e para de gritar comigo por causa disso."

    # say L811 pla
    old "Listen, is not as easy to convince humans to have sex just like that."
    new "B:pla: O que me contaste sobre ela ajudou-me pouco a conectar-me com ela."

    # say L813 pla
    old "You may be able to read minds, but you don't know how human emotions work."
    new "B:pla: Ouve, não é assim tão fácil convencer humanos a ter sexo assim do nada."

    # say L815 pla
    old "So let me handle this, ok?"
    new "B: pla: Podes ser capaz de ler mentes, mas não sabes como funcionam as emoções humanas."

    # say L816 bri
    old "Fine... I'll let you do what you want."
    new "B:pla: Deixa-me tratar disto, ok?"

    # say L818 bri
    old "But be sure to do it quickly!"
    new "B:bri: Tudo bem... Vou deixar-te fazer o que quiseres."

    # say L820 bri
    old "Magic power is not eternal in case you forgot!"
    new "B:bri: Mas faz isso depressa!"

    # say L821 bri
    old "And I already used a lot of it today, so be sure you do this properly."
    new "B:bri: A energia mágica não é eterna, caso tenhas esquecido!"

    # say L822 pla
    old "Yeah, yeah, I'll be sure to do what you need."
    new "T(pla|tu|say): Sim, sim, vou fazer o que precisas."

    # say L824 pla
    old "But I'm in a tight spot with this. I know nothing about acting. I'll have to come up with something."
    new "B:pla: Sim, sim, vou fazer o que precisas."

    # say L826 pla
    old "But I just don't have any ideas about how..."
    new "B:pla: Mas estou numa situação complicada com isto. Não sei nada de representação. Vou ter de pensar em algo."

    # say L827 pla
    old "And I don't know anybody that works in acting, how am I going to get her an audition..."
    new "B:pla: Mas eu simplesmente não tenho ideias sobre como..."

    # say L828 bri
    old "Well, that was your idea after all..."
    new "B:pla: E não conheço ninguém que trabalhe em atuação, como vou conseguir uma audição para ela..."

    # say L829 pla
    old "What? You were the one who told me to accept being your agent. I didn't even..."
    new "B:bri: Bem, isso foi ideia tua afinal..."

    # say L833 pla
    old "Belle!"
    new "B:pla: O quê? Foste tu quem me disse para aceitar ser a tua agente. Eu nem sequer..."

    # say L834 pla
    old "She's very into content creation and social media."
    new "B:pla: Belle!"

    # say L836 pla
    old "It may be a long shot, but maybe she knows somebody who could help us with this."
    new "T(pla|tu|say): Pode ser uma tarefa difícil, mas talvez ela conheça alguém que possa ajudar-nos com isto."

    # say L838 pla
    old "Right now is a little late, but I'll go talk to her soon to see if she could help me."
    new "T(pla|tu|say): Agora é um pouco tarde, mas vou falar com ela em breve para ver se ela pode me ajudar."

    # say L839 bri
    old "Yes, honestly, I need to recharge. I spent a lot of magical power today, so I need to recover, and I won't be able to help you for a few days."
    new "B:pla: Agora é um pouco tarde, mas vou falar com ela em breve para ver se ela pode me ajudar."

    # say L840 pla
    old "Hmm, alright, I can handle it with Belle for now, and what you helped with Barbie was a lot; at least, she trusts me now."
    new "B:bri: Sim, honestamente, preciso recarregar. Gastei muita energia mágica hoje, por isso preciso recuperar e não vou poder ajudar-te durante alguns dias."

    # say L842 pla
    old "Sure, have a good rest."
    new "T:pla: Claro, descansa bem."

    # say L863 pla
    old "Hey Belle! How are you?"
    new "B:pla: Claro, descansa bem."

    # say L869 pla
    old "Well... Yeah, I'm doing well."
    new "B:bel: E tu? Estás bem?"

    # say L871 pla
    old "But you see... There's this situation.... It's a little complicated and I was wondering if you could help me with it."
    new "B:pla: Bem... Sim, estou bem."

    # say L873 bel
    old "Uhmm... Sure, whatever I can help you with, I'll be happy to do it."
    new "B:pla: Mas vês... Há uma situação... É um pouco complicada e estava a pensar se me poderias ajudar com isso."

    # say L874 bel
    old "What  is it?"
    new "B:bel: Hummm... Claro, o que eu puder fazer, farei de bom grado."

    # say L876 pla
    old "Well, do you know the business building in the center of town?"
    new "B:bel: O que é?"

    # say L878 bel
    old "Sure, my mom's previous office was located there. I used to go from time to time."
    new "B:pla: Bem, tu sabes o edifício de escritórios no centro da cidade?"

    # say L880 pla
    old "Oh, nice. Well, the thing is that I sometimes have to go there."
    new "B:bel: Claro, o antigo escritório da minha mãe ficava lá. Eu costumava ir de vez em quando."

    # say L881 pla
    old "You know, to bring documents for a family member from time to time, that kind of stuff."
    new "B:pla: Oh, fixe. Bem, a questão é que às vezes tenho de ir lá."

    # say L885 pla
    old "Well the other day I came there to bring some documents, and I got to talking with the receptionist of the building."
    new "B:pla: Sabes, para levar documentos para um familiar de vez em quando, esse tipo de coisa."

    # say L887 bel
    old "Barbie?"
    new "B:pla: Pois, outro dia vim cá trazer uns documentos e acabei a conversar com a rececionista do edifício."

    # say L889 pla
    old "Yeah, do you know her?"
    new "B:bel: Barbie?"

    # say L891 bel
    old "I do, from when I used to come to my mom's office."
    new "B:pla: Sim, tu conheces a rapariga?"

    # say L893 bel
    old "We never really talked much, but I remember she's a very nice girl."
    new "B:bel: Eu lembro, daquela altura em que vinha ao escritório da minha mãe."

    # say L894 pla
    old "Oh yeah, sure, she's very nice."
    new "Mas viste, quando lá cheguei na outra dia, vi que ela estava muito triste."

    # say L896 pla
    old "But you see, when I got there the other day, I saw that she was very sad."
    new "B:pla: Oh yeah, claro, ela é muito simpática."

    # say L897 bel
    old "Why? Is she okay?"
    new "B:pla: Mas vês, quando lá cheguei na outra dia, vi que ela estava muito triste."

    # say L898 pla
    old "Well, nothing bad has happened, but you see..."
    new "B:bel: Porquê? Ela está bem?"

    # say L900 pla
    old "I asked her what was wrong."
    new "B:pla: Bem, nada de mal aconteceu, mas vês..."

    # say L902 pla
    old "And after we got to talking, she told me that she's been feeling very frustrated as of late."
    new "B:pla: Perguntei-lhe o que se passava."

    # say L904 pla
    old "Because she feels like her life is just coming to a halt, and she doesn't know what to do about it."
    new "B:pla: E depois de conversarmos, ela me disse que tem se sentido muito frustrada ultimamente."

    # say L905 bel
    old "Why? What's happening?"
    new "A:pla: Bem, como ela me contou, ela veio para a cidade à procura de oportunidades para ser atriz."

    # say L907 pla
    old "Well, as she told me, she originally came to town looking for opportunities to be an actress."
    new "B:bel: Porquê? O que está a acontecer?"

    # say L908 pla
    old "But ever since she arrived, she's been attending one audition after another."
    new "B:pla: Bem, como ela me disse, ela veio à cidade à procura de oportunidades para ser atriz."

    # say L910 pla
    old "Without ever being selected to any roles."
    new "B:pla: Mas desde que ela chegou, tem estado a frequentar uma audição após outra."

    # say L911 bel
    old "I understand [pla], that's a very sad thing."
    new "T(bel|tu|say): Entendo [pla], isso é muito triste."

    # say L914 pla
    old "It is, at first I only thought that she was just a little frustrated about not being able to book any roles."
    new "T: É, no início pensei que ela estava apenas um pouco frustrada por não conseguir reservar papéis. Mas enquanto conversávamos, percebi o quão importante é para ela ser atriz."

    # say L915 pla
    old "But while we talked I came to realize how important being an actress is to her."
    new "B:pla: No início, pensei apenas que ela estava um pouco frustrada por não conseguir reservar papéis."

    # say L916 pla
    old "This is what she wants to do the most in life."
    new "B:pla: Mas enquanto conversávamos, percebi o quão importante é para ela ser atriz."

    # say L918 pla
    old "To the point where she's feeling depressed for being unable to get any opportunities to act."
    new "B:pla: Isto é o que ela mais quer na vida."

    # say L919 bel
    old "I get it [pla], I understand that feeling."
    new "T(bel|tu|diz): Entendo [pla], compreendo essa sensação. A frustração de não poder viver os teus sonhos."

    # say L921 bel
    old "It's overwhelming..."
    new "É, mas não é só isso."

    # say L922 pla
    old "Yeah it is, but it's not just that."
    new "T: É, é isso, mas não é só isso. Ela também está a sentir-se mal por nem sequer conseguir tentar."

    # say L923 pla
    old "She's also feeling bad about not being able to even try."
    new "B:pla: Sim, mas não é só isso."

    # say L924 pla
    old "Since she's always so busy working, she can't look for auditions."
    new "Como está sempre tão ocupada a trabalhar, não consegue procurar castings."

    # say L926 pla
    old "Or attend acting classes whenever she gets a role."
    new "B:pla: Como ela está sempre tão ocupada a trabalhar, não consegue procurar audições."

    # say L928 pla
    old "So, after hearing of all the things she's been going through, I decided to help her."
    new "B:pla: Ou frequentar aulas de interpretação sempre que ela conseguir um papel."

    # say L929 pla
    old "I think that's just the best thing that I could do right now, you know?"
    new "B:pla: Então, depois de ouvir tudo o que ela tem passado, decidi ajudá-la."

    # say L934 pla
    old "And that's more or less what I need your help with."
    new "B:pla: Obrigado, Belle!"

    # say L936 pla
    old "I ended up promising her that I would help her with the whole process of getting auditions."
    new "B:pla: E mais ou menos isso é o que preciso da tua ajuda."

    # say L937 pla
    old "But truth be told, I don't know how to do that."
    new "B:pla: Acabei por prometer-lhe que a ajudaria em todo o processo de conseguir audições."

    # say L939 pla
    old "I haven't ever even seen any acting agencies, or anything like that. So I don't know where to start."
    new "B:pla: Mas a verdade é que não sei como fazer isso."

    # say L941 pla
    old "That's why I thought you might be able to help me with it."
    new "A:pla: Sei que és muito ativo nas redes sociais e conheces muita gente do ramo."

    # say L943 pla
    old "I know you're very active on social media and you know a lot of people in the industry."
    new "T(pla|tu|say): Sei que és muito ativo nas redes sociais e conheces muita gente do setor."

    # say L944 pla
    old "And you know, you also work a lot in content creation and that kind of stuff."
    new "E tu sabes, também trabalhas muito na criação de conteúdo e coisas desse género."

    # say L946 pla
    old "So, I was thinking that maybe you knew of a way for me to get an audition for her."
    new "B:pla: E sabes, tu também trabalhas muito na criação de conteúdo e coisas assim."

    # say L947 pla
    old "Or maybe you knew of a studio of something like that..."
    new "B:pla: Então, estava a pensar que talvez tu soubesses de uma maneira de eu conseguir uma audição com ela."

    # say L948 bel
    old "Hmm, I see what you mean..."
    new "B: pla: Ou talvez tu soubesses de um estúdio ou algo assim..."

    # say L950 bel
    old "You know, there may be someone that could..."
    new "B:bel: Hmm, percebo o que queres dizer..."

    # say L960 luc
    old "Hurry up and get to the classroom or you'll be late."
    new "A:bel: Então, enquanto estávamos na aula, eu fiquei pensando e me veio à mente que posso conhecer um lugar onde ela poderia ir."

    # say L994 bel
    old "So, while we were in class I got to thinking, and it came to my mind that I might know of a place where she could go."
    new "B:luc: Anda depressa para a sala de aula ou vais chegar atrasado."

    # say L995 pla
    old "You did? Great!"
    new "B:bel: Então, enquanto estávamos na aula, lembrei-me de um sítio onde ela poderia ir."

    # say L996 bel
    old "Yeah, just let me do a couple of calls and I'll let you know."
    new "B:pla: Tu fizeste? Ótimo!"

    # say L1000 bel
    old "In fact, I'll call right now and I'll let you know right away."
    new "Tudo bem, falei com alguns dos meus contactos."

    # say L1012 bel
    old "Alright, I talked with a couple of my contacts."
    new "Ótima notícia! Eles disseram que concordam em fazer uma audição para ela num papel que vai surgir."

    # say L1014 bel
    old "Great news! They said they would agree to audition her for an upcoming role."
    new "Ótimo! Eles disseram que concordam em fazer uma audição para ela num papel que vai surgir. Vou dar-te o número deles para combinarem quando ela pode ir lá."

    # say L1016 bel
    old "I'll give you their number so you can call and see when she could go there."
    new "B:bel: Ótima notícia! Eles disseram que concordam em fazer uma audição para ela num papel futuro."

    # say L1018 bel
    old "I already gave them your info, so they'll know you're calling on my recommendation."
    new "B:bel: Vou-te dar o número deles para que possas ligar e ver quando ela pode ir lá."

    # say L1019 pla
    old "Great! Thanks a lot, Belle!"
    new "B:bel: Já lhes dei a tua informação, por isso saberão que estás a ligar por minha recomendação."

    # say L1021 bel
    old "It's fine, I'm happy to be able to help."
    new "Ótimo! Muito obrigada, Belle! | Não há de quê, fico feliz por poder ajudar. | Pelo que me contaste sobre a história da Barbie, ela precisa desta oportunidade."

    # say L1022 bel
    old "From what you told me about Barbie's story, she needs this opportunity."
    new "B:bel: Tudo bem, estou feliz por poder ajudar."

    # say L1023 bel
    old "I know that if it was me I would love to get any help that I could get."
    new "B:bel: Com base no que me contaste sobre a história da Barbie, ela precisa desta oportunidade."

    # say L1024 bel
    old "So I'm very happy to help."
    new "B:bel: Eu sei que se fosse eu, adoraria receber toda a ajuda possível."

    # say L1026 pla
    old "That's great Belle, and a huge help!"
    new "B:bel: Estou muito feliz em ajudar."

    # say L1027 pla
    old "Thank you so much!"
    new "B:pla: Ótimo, Belle, e uma grande ajuda!"

    # say L1028 bel
    old "You're welcome, I hope things will go well."
    new "B:pla: Muito obrigado!"

    # say L1029 bel
    old "Let me know how this turns out."
    new "B:bel: De nada, espero que corra bem."

    # say L1031 pla
    old "I'll see you later then, thanks again."
    new "T: Vou ver-te mais tarde então, obrigado mais uma vez."

    # say L1043 pla
    old "Asking Belle about it turned out Better than expected."
    new "B:pla: Vejo-te mais tarde então, obrigado mais uma vez."

    # say L1044 pla
    old "Barbie will really like this news."
    new "B:pla: Perguntar à Belle sobre isso acabou por ser melhor do que esperava."

    # say L1045 pla
    old "Now is too late for me to go talk to her. But I'll go there soon and let her now."
    new "A:pla: Olá Barbie, como estás?"

    # say L1064 pla
    old "Hey Barbie, how are you doing?"
    new "B:pla: Agora é demasiado tarde para eu ir falar com ela. Mas vou lá logo e aviso-a."

    # say L1070 pla
    old "Well, let me tell you that that may be about to change. Because I got you an audition."
    new "B:pla: Ei Barbie, como estás?"

    # say L1073 pla
    old "Yeah, it's a role in an upcoming movie."
    new "B:pla: Bem, deixa-me dizer-te que isso pode estar prestes a mudar. Porque arranjei-te uma audição."

    # say L1075 pla
    old "It’s being produced by an indie studio from outside of town."
    new "B:pla: Sim, é um papel num filme que vai ser lançado."

    # say L1076 pla
    old "They’re holding some castings here for it."
    new "B:pla: Está a ser produzido por um estúdio independente de fora da cidade."

    # say L1078 pla
    old "I already booked you a spot in their next auditions block."
    new "B:pla: Estão a fazer algumas audições aqui para isso."

    # say L1079 pla
    old "So you'll have a chance of getting a role."
    new "B:pla: Já reservei um lugar para ti no próximo bloco de audições deles."

    # say L1081 pla
    old "You're welcome, I'm happy to help you. I'm sure you'll do a great job with the role."
    new "B:pla: Então vais ter uma hipótese de conseguir um papel."

    # say L1084 pla
    old "You'll be auditioning for the role of a rich girl who's in love with a man that her family doesn't approve of."
    new "B:pla: De nada, fico feliz em ajudar-te. Tenho a certeza de que vais fazer um ótimo trabalho com o papel."

    # say L1088 pla
    old "It is, you'll be auditioning for the lead role!"
    new "T(pla|tu|say): É, vais fazer a audição para o papel principal!"

    # say L1090 pla
    old "That's great, isn't it?"
    new "B:pla: É, vais fazer a audição para o papel principal!"

    # say L1093 pla
    old "Is... Is there a problem?"
    new "B:pla: É ótimo, não é?"

    # say L1096 pla
    old "Why not? Is there something wrong?"
    new "B:pla: É... Há algum problema?"

    # say L1101 pla
    old "Why do you think that?"
    new "B:pla: Porquê? Há algo de errado?"

    # say L1112 bri
    old "So, do you want my help?"
    new "B:bri: Siga-me, caso precisasses da minha ajuda. Não há certeza de que saibas como falar com ela."

    # say L1113 pla
    old "{i}I think I can convince her on my own.{/i}"
    new "T: {i} Acho que consigo convencê-la sozinho. {/i}"

    # say L1116 pla
    old "I know you're very talented."
    new "T(pla|tu|say): Sei que és muito talentoso."

    # say L1117 pla
    old "And sure, there's going to be some competition."
    new "B:pla: Eu sei que tu és muito talentoso."

    # say L1118 pla
    old "But you're just as good as any of them, you're more than capable of holding your own in the audion, no doubt."
    new "B:pla: E claro, vai haver alguma competição."

    # say L1127 pla
    old "B- but you were so excited just a minute ago!"
    new "B:pla: Mas tu és tão boa quanto qualquer uma delas, és mais do que capaz de te defender no audion, sem dúvida."

    # say L1138 pla
    old "Listen, I understand that you're feeling insecure because of what's happened before."
    new "B: B - mas tu estavas tão entusiasmado há um minuto!"

    # say L1152 bri
    old "I also need you to have sex with this human female, so this is also in my best interest."
    new "B:bri: Vais deixar-me ajudar-te agora?"

    # say L1154 pla
    old "{i}Alright, alright! Get in her head and tell me what's really troubling her.{/i}"
    new "{i}Tudo bem, tudo bem! Entra na cabeça dela e diz-me o que a está realmente a perturbar. {/i}"

    # say L1155 bri
    old "Okay!"
    new "T(bri|tu|say): Ok!"

    # say L1160 pla
    old "I understand that because of what's happened before you feel uncomfortable with the idea of auditioning."
    new "T: Entendo que, por causa do que aconteceu antes, tu te sintas desconfortável com a ideia de fazer uma audição."

    # say L1161 pla
    old "But you shouldn't let that stop you."
    new "Mas tu não deves deixar isso impedir-te."

    # say L1162 bri
    old "Hold on, I'm starting to get something."
    new "T(bri|tu|say): Espera, estou a começar a sentir alguma coisa."

    # say L1163 bri
    old "She feels like she's a failure."
    new "B:bri: Espera, estou a começar a sentir algo."

    # say L1164 pla
    old "{i}Uhhh... {/i}"
    new "T(pla|tu|say): {i}Uhhh... {/i}"

    # say L1168 pla
    old "{i}Her life is a failure?{/i}"
    new "T(pla|tu|say): {i}A vida dela é um fracasso?{/i}"

    # say L1172 pla
    old "But the reason I'm helping you is because I believe in you and your talent."
    new "B:pla: I- Quero dizer, percebo que possas sentir-te um fracasso."

    # say L1180 bri
    old "What strong emotions, wow!"
    new "T(bri|tu|say): Que emoções fortes, uau!"

    # say L1183 pla
    old "You know, I understand that you may feel a fear of being rejected."
    new "T: Tu sabes, entendo que possas sentir medo de ser rejeitado."

    # say L1185 pla
    old "But I do believe you're more than capable of getting the role."
    new "B:pla: Sabes, percebo que possas sentir medo de ser rejeitado."

    # say L1187 pla
    old "You have been trying for so long to finally get an acting career."
    new "B:pla: Mas acredito que tu és mais do que capaz de conseguir o papel."

    # say L1189 pla
    old "And you haven't ever given up no matter what."
    new "B:pla: Tu tens estado a tentar há tanto tempo para finalmente ter uma carreira de ator."

    # say L1191 pla
    old "I just know that you have an amazing amount of passion for this."
    new "B:pla: E tu nunca desististe, não importa o que acontecesse."

    # say L1193 pla
    old "With how hard you've worked, I don't think anyone deserves the role any more than you do."
    new "T: Com o trabalho que tu tens feito, não acho que ninguém mereça o papel mais do que tu."

    # say L1197 pla
    old "Of course I do, I truly believe in what you can do."
    new "T(pla|tu|say): Claro que sim, acredito verdadeiramente no que tu consegues fazer."

    # say L1198 pla
    old "What do you say?"
    new "B:pla: Claro que sim, acredito verdadeiramente no que tu consegues fazer."

    # say L1199 pla
    old "Will you give it a try?"
    new "B:pla: O que dizes?"

    # say L1210 pla
    old "Of course you should. I know, you'll crush it."
    new "B:pla: Vais experimentar?"

    # say L1215 pla
    old "You're welcome Barbie, I know you'll do great."
    new "B:pla: Claro que deves. Eu sei que vais arrasar."

    # say L1216 pla
    old "Anyway, I have to go home for now."
    new "B:pla: De nada, Barbie, sei que vais fazer um ótimo trabalho."

    # say L1217 pla
    old "But I'll send you the info about the address and date for the audition."
    new "B:pla: De qualquer forma, tenho de ir para casa por agora."

    # say L1221 pla
    old "I'll see you later then, bye."
    new "B:pla: Mas vou-te enviar as informações sobre o endereço e a data da audição."

    # say L1238 pla
    old "Alright, that went well."
    new "Obrigado pela ajuda, Brixxida."

    # say L1239 pla
    old "Thanks for the help Brixxida."
    new "B:pla: Tudo bem, correu bem."

    # say L1241 bri
    old "Yeah yeah, but why aren't you having sex already with her?"
    new "B:pla: Obrigado pela ajuda, Brixxida."

    # say L1244 bri
    old "I told you how she was feeling so that you could have sex with her right away!"
    new "B:bri: Sim sim, mas por que ainda não estás a ter sexo com ela?"

    # say L1245 bri
    old "Two times talking and you still haven't achieved anything."
    new "B:bri: Eu disse-te como ela estava a sentir-se para que tu pudesses ter sexo com ela logo!"

    # say L1246 bri
    old "What's taking you so long?"
    new "T(bri|tu|say): O que está a demorar tanto?"

    # say L1247 pla
    old "I thought I told you."
    new "T: Tu pensas que é fácil levar alguém para a cama?"

    # say L1248 pla
    old "Is not so simple to get somebody into bed."
    new "T(pla|tu|say): Não é tão simples assim levar alguém para a cama."

    # say L1250 pla
    old "You can't just say something nice to someone once or twice, and suddenly they'll want to fuck you out of nowhere."
    new "T(pla|tu|diz): Não podes simplesmente dizer algo agradável a alguém uma ou duas vezes, e de repente eles vão querer transar contigo do nada."

    # say L1251 bri
    old "Ok, then how long will it take?"
    new "B:pla: Não podes simplesmente dizer algo agradável a alguém uma ou duas vezes e de repente eles vão querer transar contigo do nada."

    # say L1252 bri
    old "You're not the only one who's making an effort, you know?"
    new "T(bri|tu|say): Tu não és o único que está a fazer um esforço, sabes?"

    # say L1254 bri
    old "I'm using a lot of magical power every time I read her mind, this isn't easy to do."
    new "B:bri: Não és o único a fazer um esforço, sabes?"

    # say L1255 bri
    old "And unlike in my world, magical power isn't infinite here."
    new "T(bri|tu|say): E ao contrário do meu mundo, a energia mágica não é infinita aqui."

    # say L1256 pla
    old "I know, and I understand that this must be hard for you."
    new "E não posso simplesmente pedir-lhe que faça sexo comigo só por isso. Não é assim que as coisas funcionam."

    # say L1258 pla
    old "But I can't just ask her to have sex with me just because. That's not how it works."
    new "B:pla: Eu sei, e entendo que isso deve ser difícil para ti."

    # say L1260 bri
    old "You humans are so complicated. When shinigamis have sex is just an energy exchange. Nothing else."
    new "B:pla: Mas não posso simplesmente pedir-lhe para ter sexo comigo sem mais nem menos. Não é assim que as coisas funcionam."

    # say L1261 pla
    old "Listen, I'm doing my best to do what we need. So just trust me on this and let me handle it. Ok?"
    new "B:bri: Vocês humanos são tão complicados. Quando os shinigamis fazem sexo, é apenas uma troca de energia. Nada mais."

    # say L1263 bri
    old "Okay,  I'll trust that you know what you're doing."
    new "T(bri|tu|say): Ok, confio que sabes o que estás a fazer."

    # say L1264 bri
    old "But don't take too long, I remind you that this is just the beginning of this process."
    new "B:bri: Tudo bem, confio que sabes o que estás a fazer."

    # say L1266 pla
    old "Don't worry, I haven't forgotten about that."
    new "Não te preocupes, não me esqueci disso. Estou bem, vim ver como estás."

    # say L1292 pla
    old "I'm ok, I came to check up on you."
    new "Não te preocupes, não me esqueci disso."

    # say L1294 pla
    old "I wanted to know how the audition went."
    new "B:pla: Estou bem, vim ver como estás."

    # say L1296 pla
    old "Did it go well? Did you feel alright?"
    new "B:pla: Queria saber como correu a audição."

    # say L1310 pla
    old "Alright, that sounds great. When's the next audition?"
    new "B:pla: Correu bem? Sentiste-te bem? T(pla|tu|diz): Tudo bem, isso soa ótimo. Quando é a próxima audição? A:pla: Entendo, e quanto tempo dura?"

    # say L1319 pla
    old "I see, and how long is it?"
    new "B:pla: Tudo bem, isso parece ótimo. Quando é a próxima audição?"

    # say L1325 pla
    old "Ohh wow, t- that's a lot."
    new "B:pla: Entendo, e quanto tempo é?"

    # say L1333 pla
    old "Oh, come on, why not?"
    new "B:pla: Ohh wow, t- that's muito."

    # say L1347 bri
    old "She's feeling, very, very insecure."
    new "T(bri|tu|say): Ela está se sentindo, muito, muito insegura."

    # say L1348 bri
    old "I hadn't seen her like that before."
    new "T(bri|tu|say): Nunca a tinha visto assim antes."

    # say L1350 bri
    old "She's closing her emotions! Just say something to reassure her."
    new "T(bri|tu|say): Ela está a fechar as suas emoções! Diz algo para a acalmar."

    # say L1352 pla
    old "I- I understand what you're saying Barbie... I really do."
    new "T(tu|diz): Eu- Eu entendo o que estás a dizer, Barbie... Eu realmente entendo. Mas sabes... Hum, não acho que esta situação seja tão má quanto pensas."

    # say L1354 pla
    old "But you know... Uhh, I don't think that this is as bad a situation as you think."
    new "T(pla|tu|say): Mas sabes... Hum, não acho que esta situação seja tão má como tu pensas."

    # say L1359 bri
    old "Yeah, why not?"
    new "B:pla: Mas tu sabes... Hum, não acho que esta situação seja tão má quanto tu pensas."

    # say L1360 pla
    old "Uhh... Well, that's certainly a lot of pages, but I don't think they are expecting you to memorize all of it."
    new "T: Uhh... Bem, são certamente muitas páginas, mas não acho que esperem que tu as memorizes todas."

    # say L1361 pla
    old "I think it's more about how you say and act with the lines."
    new "B:pla: Uhh... Bem, isso é certamente muitas páginas, mas não acho que esperem que tu memorizes tudo."

    # say L1363 pla
    old "Maybe all you have to do is read it ahead of time, and practice it."
    new "B:pla: Acho que é mais sobre como dizes e agis com as linhas."

    # say L1373 pla
    old "Ok, how about you do it with me?"
    new "B:pla: Talvez tudo o que tenhas de fazer é lê-lo antes e praticá-lo."

    # say L1375 pla
    old "Sure, I mean, I don't know anything about acting, but I could still read the dialogues with you."
    new "B:pla: Ok, e se fizermos isso juntos?"

    # say L1376 pla
    old "And I could give you my opinion about how I think you are doing it."
    new "B:pla: Claro, eu não sei nada de representação, mas ainda posso ler os diálogos contigo."

    # say L1380 pla
    old "Well, we don't lose anything by trying, and this way, you could be more prepared for your role."
    new "A:pla: Que tal vires à minha casa depois de saíres do trabalho."

    # say L1393 pla
    old "How about you come to my house after you leave work."
    new "B:pla: Bem, não perdemos nada por tentar, e assim, tu podes estar mais preparado para o teu papel."

    # say L1395 pla
    old "And we can start practicing."
    new "B:pla: E se tu vens à minha casa depois de saíres do trabalho."

    # say L1401 pla
    old "So, what do you think if you let me take a look at the script they gave you while I wait for you to finish your shift?"
    new "B:pla: E podemos começar a praticar."

    # say L1406 pla
    old "Okay, I'll go through them while you finish. I'll be in the hallway."
    new "B:pla: Então, o que achas se eu der uma vista de olhos ao guião que te deram enquanto espero tu terminares o turno?"

    # say L1417 pla
    old "Great, let's go."
    new "B:pla: Ok, vou passar por eles enquanto tu terminas. Vou ficar no corredor. T(pla|tu|say): Ótimo, vamos lá. A:pla: Então, dei uma olhada no roteiro, e honestamente, é bem interessante."

    # say L1433 pla
    old "So, I checked out the script, and honestly, it's pretty interesting."
    new "B:pla: Ótimo, vamos lá."

    # say L1435 pla
    old "Yeah, and I really do think you're not supposed to memorize this. It's rather about you reading it."
    new "B:pla: Então, dei uma olhada no roteiro, e honestamente, é bastante interessante."

    # say L1436 pla
    old "Otherwise I don't think anybody could learn this entire thing by memory."
    new "B:pla: Sim, e acho mesmo que não deves memorizar isto. É mais sobre tu leres."

    # say L1437 pla
    old "Besides, if there are several participants the audition would just take too long."
    new "B:pla: Caso contrário, duvido que alguém conseguisse aprender tudo de memória."

    # say L1441 pla
    old "What I think is best is for us to focus on how you can portray the character."
    new "B:pla: Além disso, se houver vários participantes, a audição demoraria demasiado tempo."

    # say L1442 pla
    old "I mean, act as you read, so you can be better prepared tomorrow having practiced your role."
    new "B:pla: O que acho melhor é focarmo-nos em como tu podes interpretar o personagem."

    # say L1443 pla
    old "I know a scene with a lot of emotions."
    new "B:pla: Quero dizer, age como se estivesses a ler, para estares melhor preparado amanhã depois de teres praticado o teu papel."

    # say L1444 pla
    old "Here, take the full script, I got a few copies..."
    new "B:pla: Eu conheço uma cena com muitas emoções."

    # say L1448 pla
    old "Is in the second act, page 57."
    new "B:pla: Aqui, toma o guião completo, tenho algumas cópias..."

    # say L1449 pla
    old "The two protagonists are fighting, but the scene ends in their reconciliation, I think it would be appropriate."
    new "B:pla: Está no segundo ato, página 57."

    # say L1452 pla
    old "Alright, let's start with the reading, and I'll give you pointers along the way."
    new "Não te vais embora! Não me dês as costas agora!"

    # say L1459 pla
    old "'Don't leave! Don't turn your back on me now!'"
    new "B:pla: Vamos começar com a leitura, e eu vou te dar indicações pelo caminho."

    # say L1461 pla
    old "'If you do, what little remains of this heart will disappear!'"
    new "B: 'Não te vais embora! Não me dês as costas agora!'"

    # say L1484 pla
    old "Hmm... Barbie?"
    new "B:pla: 'Se fizeres, o que resta deste coração desaparecerá!'"

    # say L1487 pla
    old "I think you're doing it... Well."
    new "B:pla: Hmm... Barbie?"

    # say L1489 pla
    old "But, the volume of what you're saying is a little high."
    new "B:pla: Acho que estás a fazer bem..."

    # say L1491 pla
    old "Also, you're... Yelling some words, and saying others a little low."
    new "B:pla: Mas, o volume do que estás a dizer está um pouco alto."

    # say L1494 pla
    old "Hmm, it's okay to add emotion to the lines, but try to keep the volume average, or it might sound a bit odd."
    new "B:pla: E também, tu estás... A gritar algumas palavras e a dizer outras um pouco baixo."

    # say L1497 pla
    old "Great, let's try it again."
    new "B:pla: Hmm, está bem adicionar emoção às linhas, mas tenta manter o volume médio, senão pode soar um pouco estranho."

    # say L1501 pla
    old "You know what? Maybe it isn't necessary to start over every time."
    new "T(pla|tu|say): Sabes o que? Talvez não seja necessário recomeçar sempre."

    # say L1502 pla
    old "How about you just keep reading where you left it?"
    new "B:pla: Sabes o quê? Talvez não seja preciso recomeçar sempre."

    # say L1521 pla
    old "'Why? You ask?'"
    new "Porque não é pequeno!"

    # say L1522 pla
    old "'Because it isn't little!'"
    new "B: 'Porquê? Tu perguntas?'"

    # say L1523 pla
    old "'What I offer is my heart!'"
    new "B: 'Porque não é pequeno!'"

    # say L1524 pla
    old "'Naked, with no obstructions, just for you!'"
    new "B: 'O que te ofereço é o meu coração!'"

    # say L1550 pla
    old "But maybe that's not necessary, you know?"
    new "B:pla: Eu vejo..."

    # say L1551 pla
    old "I think it can be a little distracting."
    new "T(pla|tu|say): Acho que pode ser um pouco distrativo."

    # say L1553 pla
    old "And people might not understand what you're trying to do."
    new "B:pla: Acho que pode ser um pouco distrativo."

    # say L1559 pla
    old "Hey, that's why we're practicing."
    new "B:pla: E as pessoas podem não entender o que tu estás a tentar fazer."

    # say L1560 pla
    old "I don't think you need to feel bad about it."
    new "B:pla: É por isso que estamos a treinar."

    # say L1561 pla
    old "Come on, don't let yourself feel down, let's continue."
    new "B:pla: Não acho que precisas de te sentir mal por isso."

    # say L1566 pla
    old "'How can you say that I let you down?'"
    new "B:pla: Vamos, não fiques assim, continuemos."

    # say L1567 pla
    old "'When I gave everything to you?!'"
    new "B: 'Como podes dizer que te desiludi?'"

    # say L1568 pla
    old "'I left myself change for your sake!'"
    new "B: 'Quando te dei tudo?!'"

    # say L1569 pla
    old "'For our sake!'"
    new "B: 'Fiz-me mudar por tua causa!'"

    # say L1570 pla
    old "'All I've ever wanted in this relationship is to give you happiness!'"
    new "Tudo o que sempre quis nesta relação foi fazer-te feliz!"

    # say L1584 pla
    old "'I didn't leave!'"
    new "B: 'Tudo o que sempre quis nesta relação foi fazer-te feliz!'"

    # say L1585 pla
    old "'I couldn't be here for you!'"
    new "B: 'Não saí!'"

    # say L1586 pla
    old "'There's no way I wouldn't be here if I could avoid it!'"
    new "T: 'Não há maneira de eu não estar aqui se pudesse evitar!'"

    # say L1587 pla
    old "'You have to believe.'"
    new "B:pla: 'Não há como eu não estar aqui se pudesse evitar!'"

    # say L1588 pla
    old "'You're my life!'"
    new "B: 'Tens de acreditar.'"

    # say L1589 pla
    old "'You're my heart!'"
    new "B: 'Tu és a minha vida!'"

    # say L1600 pla
    old "Uhh... So, there's something else I'd like to tell you."
    new "Bem, é que..."

    # say L1606 pla
    old "Well, is just that..."
    new "B:pla: Uhh... Então, há mais uma coisa que quero dizer-te."

    # say L1607 pla
    old "You keep changing your face while reading the lines."
    new "B:pla: Bem, é só que..."

    # say L1609 pla
    old "I- uh... No, I wouldn't say is wrong."
    new "B: pla: Tu continuas a mudar de expressão enquanto lees as linhas."

    # say L1610 pla
    old "Is just that it's a little distracting from the dialogue, that's all."
    new "B: pla: Eu... não, não diria que está errado."

    # say L1611 pla
    old "I wouldn't say is a bad thing though."
    new "B:pla: É só que é um pouco distrativo da conversa, só isso."

    # say L1619 pla
    old "W- what are you talking about?"
    new "T: W- w-wor p-podes dizer isso?"

    # say L1620 pla
    old "W- why?"
    new "B: pla: E- e do que estás a falar?"

    # say L1625 pla
    old "B- but that's just me tryting to help you!"
    new "B: pla: P- porquê?"

    # say L1626 pla
    old "But I don't think you're bad."
    new "Mas eu não acho que tu sejas mau. Tu só precisas de um pouco de prática."

    # say L1628 pla
    old "You just need a little practice."
    new "Tu só precisas de um pouco de prática para aprender a personagem."

    # say L1629 pla
    old "You know, to learn the character."
    new "B:pla: Tu só precisas de um pouco de prática."

    # say L1637 pla
    old "W- what? Are you serious?"
    new "T(pla|tu|say): W- what? Estás a falar a sério?"

    # say L1641 pla
    old "Come on, you can't just give up like this."
    new "T(pla|tu|say): Vamos, não podes desistir assim."

    # say L1642 pla
    old "You have to try it."
    new "B:pla: Vamos, não podes desistir assim."

    # say L1646 pla
    old "It isn't impossible, you don't have to know the script."
    new "T: Não é impossível, não precisas de conhecer o guião."

    # say L1647 pla
    old "Or even read the whole thing."
    new "B:pla: Não é impossível, não precisas de conhecer o guião."

    # say L1648 pla
    old "Let's just keep practicing this part."
    new "B: pla: Ou até ler tudo."

    # say L1649 pla
    old "And I'm sure you'll be able to use what we practice here today for the audition tomorrow."
    new "B:pla: Vamos continuar a praticar esta parte."

    # say L1671 bri
    old "Hmm, I don't know."
    new "B:bri: Deixa-me ver."

    # say L1672 bri
    old "All I can tell is that she's incredibly stressed."
    new "B:bri: Hmm, não sei."

    # say L1673 bri
    old "It's amazing [pla], she's under so much tension!"
    new "T(bri|tu|say): É incrível [pla], ela está sob tanta tensão!"

    # say L1680 pla
    old "{i}Like a spell to calm her nerves or something?{/i}"
    new "B:pla: {i}E tu? Não tens nada que possa ser útil?{/i}"

    # say L1685 pla
    old "{i}Because she's very certain that she's terrible.{/i}"
    new "B:pla: {i}Bem, então estamos numa situação complicada aqui.{/i}"

    # say L1687 bri
    old "Isn't there anything you could use to calm her feelings?"
    new "Não têm vocês humanos uma substância que ingerem nestas situações?"

    # say L1688 bri
    old "Don't you humans have a substance you ingest in these situations?"
    new "B:bri: Não há nada que tu possas usar para acalmar os sentimentos dela?"

    # say L1698 pla
    old "I'm sure you can do it."
    new "B:pla: O quê? Não, não, nada disso."

    # say L1699 pla
    old "Just wait here a second, I know of something that can help."
    new "B:pla: Tenho a certeza de que consegues."

    # say L1710 pla
    old "Alright, I think this is just what we need."
    new "Bem, não, não é bem isso."

    # say L1712 pla
    old "Well, no, not really."
    new "B:pla: Bem, acho que isto é exactamente o que precisamos."

    # say L1713 pla
    old "But I think that drinking a little might help."
    new "B:pla: Bem, não, não realmente."

    # say L1716 pla
    old "I can't remember exactly where I read it"
    new "B:pla: Mas acho que beber um pouco pode ajudar."

    # say L1717 pla
    old "But it was about how some famous actors sometimes drink a little alcohol before shooting some of their scenes."
    new "B:pla: Não me lembro exatamente onde li isso"

    # say L1718 pla
    old "This is supposed to help them feel relaxed, and be able to act more naturally."
    new "B: Mas era sobre como alguns atores famosos às vezes bebem um pouco de álcool antes de gravar algumas das suas cenas."

    # say L1721 pla
    old "I understand that it seems a bit odd, but we could give it a try."
    new "T(pla|tu|say): Entendo que possa parecer um pouco estranho, mas podíamos experimentar."

    # say L1722 pla
    old "After all, you are feeling a little stressed. Maybe this could help you relax enough for you to recite the lines."
    new "B:pla: Entendo que possa parecer um pouco estranho, mas podíamos experimentar."

    # say L1726 pla
    old "Oh come on, you can be a little bit more positive than that. I'm sure this is going to help you."
    new "B:pla: Afinal, estás um pouco stressado. Talvez isto te ajude a relaxar o suficiente para recitares as linhas."

    # say L1750 pla
    old "I'm glad you like it."
    new "T(pla|tu|say): Fico contente que tu gostes."

    # say L1751 pla
    old "Do you feel better now?"
    new "B:pla: Fico contente que gostes."

    # say L1765 pla
    old "I see you're feeling better. Let's try it."
    new "T: Vejo que estás melhor. Vamos tentar."

    # say L1771 pla
    old "I can prove it!'"
    new "T(pla|tu|say): 'Posso provar!"

    # say L1772 pla
    old "'I can tell you!"
    new "B:pla: 'Posso provar!'"

    # say L1773 pla
    old "'I'm here now! And you didn't call me!'"
    new "B:pla: 'Posso dizer-te!"

    # say L1774 pla
    old "'I came because you needed me!'"
    new "B: 'Estou aqui agora! E tu não me chamaste!'"

    # say L1783 pla
    old "{i}(Now it's my line, I better not brake her concentration now that she's finally doing it well.){/i}"
    new "B:pla: {i}(Uau! Parece que beber realmente ajudou, ela ficou tão boa de repente!){/i}"

    # say L1789 pla
    old "'I should've stayed by your side, I should've been here when you needed me!'"
    new "T(pla|tu|say): 'Deveria ter ficado ao teu lado, deveria ter estado aqui quando precisavas de mim!'"

    # say L1790 pla
    old "'But that's why I'm here now!'"
    new "B: 'Deveria ter ficado ao teu lado, deveria ter estado aqui quando precisavas de mim!'"

    # say L1791 pla
    old "'To be your companion!'"
    new "B: 'Mas é por isso que estou aqui agora!'"

    # say L1792 pla
    old "'Your rock! Your partner!'"
    new "B: 'Ser o teu companheiro!'"

    # say L1805 pla
    old "'I will be!'"
    new "B:pla: 'A tua rocha! O teu parceiro!'"

    # say L1806 pla
    old "'I promise you!'"
    new "T(pla|tu|dizes): 'Prometo-te!'"

    # say L1814 pla
    old "You know what? It was, it really was."
    new "B:pla: 'Prometo-te!'"

    # say L1815 pla
    old "I think the alcohol really helped you. Because that last part was great."
    new "B:pla: Sabes o que? Foi, foi mesmo."

    # say L1816 pla
    old "But let's keep going until we finish this part of the dialogue."
    new "B:pla: Acho que o álcool realmente te ajudou. Porque a última parte foi ótima."

    # say L1822 pla
    old "'So! Do you believe me when I say it?'"
    new "So! Acreditas quando digo isso?' 'Que quero estar contigo!"

    # say L1823 pla
    old "'That I want to be by you!'"
    new "B: 'Então! Acreditas quando digo isso?'"

    # say L1824 pla
    old "'That I need to be by your side!'"
    new "B:pla: 'Quero estar contigo!'"

    # say L1825 pla
    old "'Nothing would make me happier!'"
    new "B: 'Que preciso estar ao teu lado!'"

    # say L1840 pla
    old "'It means that we love each other!'"
    new "B:pla: 'Nada me faria mais feliz!'"

    # say L1849 pla
    old "{i}(Hmm, there's a kiss scene coming, and I didn't tell her where the scene would end.){/i}"
    new "B:pla: {i}(Uau! Ela está muito melhor do que estava há um minuto!){/i}"

    # say L1850 pla
    old "{i}(She won't kiss me without talking with me about it, right?){/i}"
    new "B:pla: {i}(Hmm, há uma cena de beijo a seguir, e não lhe disse onde a cena terminaria.){/i}"

    # say L1861 pla
    old "'If you say yes now I promise I'll always be there!'"
    new "B: 'Eu consigo, e eu vou!'"

    # say L1862 pla
    old "'I will always be the rock that you need!'"
    new "B:pla: 'Se disseres que sim agora prometo que estarei sempre lá!'"

    # say L1863 pla
    old "'No matter what!'"
    new "B: 'Eu serei sempre a rocha de que precisas!'"

    # say L1884 pla
    old "{i}(That was unexpected, but I guess she's really into the role.){/i}"
    new "B:pla: {i}(Não posso acreditar, ela realmente me beijou!){/i}"

    # say L1885 pla
    old "{i}(If that's the case then I should just keep going with the script.){/i}"
    new "B:pla: {i}(Não era esperado, mas acho que ela está mesmo a entrar no papel.){/i}"

    # say L1898 pla
    old "'But in return, I'll let you have mine!'"
    new "B:pla: 'Aceito com prazer!'"

    # say L1899 pla
    old "'Because this is a partnership!'"
    new "B: 'Mas em troca, vou deixar que tenhas o meu!'"

    # say L1900 pla
    old "'We're meant to be together!'"
    new "B: 'Porque isto é uma parceria!'"

    # say L1901 pla
    old "'I know it!'"
    new "T: 'Eu sei!'"

    # say L1924 pla
    old "'Are you sure?'"
    new "B:pla: 'Eu sei!'"

    # say L1925 pla
    old "'Does this mean that you'll stay by my side?'"
    new "B:pla: 'Tens a certeza?'"

    # say L1960 pla
    old "Uhh... Y- yeah, it was, it really, really was."
    new "B:pla: 'Isto significa que vais ficar ao meu lado?'"

    # say L1961 pla
    old "I- I mean, your acting was great."
    new "B:pla: Uhh... S- sim, foi, foi mesmo."

    # say L1962 pla
    old "I think you won't have any problems when the audition comes."
    new "B: pla: Eu... Quero dizer, a tua atuação foi excelente."

    # say L1966 pla
    old "Hmm... Sure."
    new "B:pla: Acho que não vais ter problemas quando chegar a audição."

    # say L1979 pla
    old "Okay."
    new "B:pla: Hmm... Claro."

    # say L1980 pla
    old "But maybe we should change the scene because this one ends in a love scene between the leads."
    new "Mas talvez devamos mudar a cena porque esta termina num momento de amor entre os protagonistas."

    # say L1981 pla
    old "So, we could look for another one."
    new "T: Então, podemos procurar outra."

    # say L1987 pla
    old "U- Uhh, I- I don't know how- ."
    new "A:pla: Não achas que estás a beber um bocado demais disso?"

    # say L1998 pla
    old "Don't you think you're drinking a little too much of that?"
    new "B:pla: U- Uhh, I- I não sei como-."

    # say L2015 pla
    old "W- what are you doing Barbie?"
    new "B:pla: Não achas que estás a beber um bocado demais disso?"

    # say L2035 pla
    old "Listen... About last night..."
    new "B:pla: O- o que estás a fazer, Barbie?"

    # say L2041 pla
    old "Uhh... Yeah, yeah, sure, don't worry about it..."
    new "B:pla: Escuta... Sobre ontem à noite..."

    # say L2067 bri
    old "Of course you'll have to have more sex with her..."
    new "B:bri: Finalmente conseguiste! Muito bem!"

    # say L2069 bri
    old "But now that you've done it once, you shouldn't have any problems doing it again..."
    new "B:bri: Claro que vais ter de ter mais sexo com ela..."

    # say L2070 bri
    old "Now we can focus on finding the next specimen."
    new "B:bri: Mas agora que já o fizeste uma vez, não deves ter problemas em fazê-lo de novo..."

    # say L2073 bri
    old "Well of couse."
    new "A:bri: Agora que sabes que vais ter sexo com esta mulher tão facilmente."

    # say L2074 bri
    old "Now that you know you're going to have sex with this woman so easily."
    new "B:bri: Claro."

    # say L2075 bri
    old "You can stop wasting time on her and focus on finding the next person we need."
    new "B:bri: Agora que sabes que vais ter sexo com esta mulher tão facilmente."

    # say L2076 pla
    old "Hey, hey, stop it right there!"
    new "T: Ei, ei, pára aí! Não sei o que tens em mente."

    # say L2077 pla
    old "I don't know what it is you have in mind."
    new "B:pla: Ei, ei, pára aí!"

    # say L2079 pla
    old "But is not that easy..."
    new "B:pla: Não sei o que tens em mente."

    # say L2081 pla
    old "I promised I would help her with this, and I plan to fulfill that promise."
    new "B:pla: Mas não é assim tão fácil..."

    # say L2083 pla
    old "So I'm sorry to disappoint you, but until she gets an acting job, I won't be looking for another 'specimen'..."
    new "Então, sinto muito por te desiludir, mas até ela arranjar um trabalho de actriz, não vou procurar outro 'especimen'... Além disso, não acho que haja uma próxima vez a fazer sexo com ela se a deixar na mão."

    # say L2085 pla
    old "Besides, I don't think there's going to be a next time having sex with her if I just leave her hanging."
    new "B:pla: Desculpa, mas até ela arranjar um trabalho de actriz, não vou procurar outro 'espécime'..."

    # say L2086 pla
    old "And you still need me to do it with her more times, isn't it?"
    new "B:pla: Além disso, não acho que haja uma próxima vez de fazer sexo com ela se eu a deixar na mão."

    # say L2088 bri
    old "Ughh! You humans are so complicated!"
    new "B:pla: E ainda precisas que eu faça isso com ela mais vezes, não é?"

    # say L2090 bri
    old "Fine! Do as you wish!"
    new "T(bri|tu|say): Tudo bem! Faz como quiseres!"

    # say L2092 bri
    old "But do it quickly! We don't have much time to lose!"
    new "B:bri: Ótimo! Faz como quiseres!"

    # say L2093 pla
    old "Yeah, yeah, you've made that clear."
    new "B:bri: Mas faz rápido! Não temos muito tempo a perder!"

    # say L2117 pla
    old "Hey Barbie, how are you?"
    new "B:pla: Sim, sim, já percebi."

    # say L2121 pla
    old "W- what? Why?"
    new "B:pla: Ei Barbie, como estás?"

    # say L2126 pla
    old "It did? You didn't feel comfortable?"
    new "T(pla|tu|dizes): Fez-te sentir desconfortável?"

    # say L2131 pla
    old "I get it, I mean... I guess fear made you forget the dialogue..."
    new "B:pla: Foi? Tu não te sentiste à vontade?"

    # say L2153 pla
    old "Who does he think he is? He has no right to treat you like that!"
    new "B:pla: Entendi, quero dizer... Acho que o medo fez-te esquecer o diálogo..."

    # say L2154 pla
    old "I'm sorry Barbie, you didn't deserve him treating you like that."
    new "B:pla: Quem ele pensa que é? Não tem direito de te tratar assim!"

    # say L2160 pla
    old "No you're not, don't make what he told you a law."
    new "B:pla: Desculpa, Barbie, não merecias que ele te tratasse assim."

    # say L2161 pla
    old "You're very talented Barbie, I saw it the other day while we were practicing."
    new "B:pla: Não tu não és, não transformes o que ele disse numa lei."

    # say L2162 pla
    old "I'm sure it's going to be better in the next audition you go to."
    new "B:pla: Tu és muito talentosa, Barbie, vi isso no outro dia enquanto estávamos a treinar."

    # say L2167 pla
    old "B- but that's your dream, to be part of show business."
    new "B:pla: Tenho a certeza de que vai ser melhor na próxima audição a que fores."

    # say L2168 pla
    old "You know, to work in acting and stuff."
    new "A:pla: Espera! Espera!"

    # say L2180 pla
    old "Wait! Wait!"
    new "B:pla: Sabes, para trabalhar na atuação e coisas assim."

    # say L2181 pla
    old "Don't think so bad about yourself!"
    new "B:pla: Espera! Espera!"

    # say L2182 pla
    old "You shouldn't believe that you're not good enough to act!"
    new "B:pla: Não penses tão mal de ti!"

    # say L2183 pla
    old "I know you're more than capable of it."
    new "A:pla: Ei, tenho uma ideia!"

    # say L2191 pla
    old "Hey I have an idea!"
    new "O:pla: Ouve, sei que estás a sentir-te mal."

    # say L2192 pla
    old "Listen, I know you're feeling bad."
    new "Ouve, sei que estás a sentir-te mal. Mas acho que há uma maneira de não teres de desistir do teu sonho."

    # say L2193 pla
    old "But I think there's a way so that you don't have to give up on your dream."
    new "A:pla: Entendo, mas ouve, o teu sonho é ser famoso, certo?"

    # say L2197 pla
    old "I get it, but listen, your dream is to be famous, right?"
    new "B:pla: Mas acho que há uma maneira de tu não teres de desistir do teu sonho."

    # say L2198 pla
    old "But there's more than one way of achieving it."
    new "B:pla: Entendi, mas ouve, o teu sonho é ser famoso, certo?"

    # say L2200 pla
    old "For example, have you thought about modeling?"
    new "B:pla: Mas há mais do que uma forma de o conseguir."

    # say L2204 pla
    old "Sure!  Listen, maybe you're right about not being the best actor right now."
    new "T(pla|tu|say): Claro! Ouve, talvez tenhas razão sobre não ser o melhor ator para já."

    # say L2205 pla
    old "But that's not the only way to earn fame."
    new "B:pla: Claro! Ouve, talvez tenhas razão sobre não ser o melhor ator neste momento."

    # say L2206 pla
    old "There are several different things that you can do."
    new "B:pla: Mas isso não é a única maneira de ganhar fama."

    # say L2208 pla
    old "And I think you could easily be an amazing model!"
    new "B:pla: Existem várias coisas diferentes que podes fazer."

    # say L2211 pla
    old "Of course I do!"
    new "B:pla: E acho que tu poderias ser uma modelo incrível!"

    # say L2212 pla
    old "There are several actors that got their start as models, and over time they moved into acting."
    new "B:pla: Claro que sim!"

    # say L2213 pla
    old "With how beautiful you are. I don't see why you couldn't do the same thing."
    new "B:pla: Existem vários atores que começaram como modelos e, com o tempo, passaram para a atuação."

    # say L2217 pla
    old "You have to be kidding me."
    new "T: Tu estás a brincar comigo."

    # say L2218 pla
    old "I mean, look at yourself. You're beautiful."
    new "T: Quero dizer, olha para ti. Tu és linda."

    # say L2219 pla
    old "And you have an amazing body!"
    new "B:pla: Quero dizer, olha para ti. Tu és linda."

    # say L2220 pla
    old "Of course you can be a model!"
    new "B:pla: E tu tens um corpo incrível!"

    # say L2227 pla
    old "How can you say that?"
    new "T: Como podes dizer isso?"

    # say L2228 pla
    old "Maybe what you're saying about models was true several years ago."
    new "T(pla|tu|dizer): Talvez o que tu estás a dizer sobre as modelos fosse verdade há alguns anos."

    # say L2230 pla
    old "But there are several different types now. And you are one of the most beautiful women that I've met."
    new "B:pla: Talvez o que tu dizes sobre modelos fosse verdade há alguns anos."

    # say L2231 pla
    old "I'm sure you'll find work in any agency you want in no time."
    new "B:pla: Mas agora existem vários tipos diferentes. E tu és uma das mulheres mais bonitas que já conheci."

    # say L2236 pla
    old "Of course I believe it. And I'm sure it's going to go great."
    new "B:pla: Tenho a certeza de que vais encontrar trabalho na agência que quiseres num instante."

    # say L2240 pla
    old "R- right... Sure."
    new "B:pla: Claro que acredito. E tenho a certeza de que vai correr bem."

    # say L2241 pla
    old "I'll get you something as a model."
    new "B: R- certo... Claro."

    # say L2242 pla
    old "So, I'm going to have to make a couple of calls, but I'll let you know later about what I find."
    new "T: Então, vou ter de fazer algumas chamadas, mas aviso-te mais tarde sobre o que encontrar."

    # say L2243 pla
    old "Ok?"
    new "B:pla: Vou ter de fazer algumas chamadas, mas aviso-te mais tarde sobre o que descobrir."

    # say L2246 pla
    old "You're more than welcome."
    new "B:pla: Ok?"

    # say L2247 pla
    old "I'm just happy to help."
    new "B:pla: De nada."

    # say L2248 pla
    old "I'll go for now, and I'll see you later, alright?"
    new "T: Vou-me embora por agora, e vejo-te mais tarde, está bem?"

    # say L2260 pla
    old "Hmm, I guess it's good that Barbie's feeling better now."
    new "B:pla: Vou-me embora por agora, e vejo-te mais tarde, está bem?"

    # say L2261 pla
    old "But now, how will I get her a modeling casting?"
    new "B:pla: Hmm, acho que é bom que a Barbie esteja melhor agora."

    # say L2262 pla
    old "I don't know anyone who works as a model or something similar..."
    new "B:pla: Mas agora, como vou conseguir um casting de modelo para ela?"

    # say L2263 pla
    old "Hmph, I don't want to bother Belle again to get me an audition..."
    new "B:pla: Não conheço ninguém que trabalhe como modelo ou algo parecido..."

    # say L2264 pla
    old "Who else could help me with this..."
    new "A:bri: O que estás a fazer?"

    # say L2268 bri
    old "What are you doing?"
    new "B:pla: Quem mais poderia ajudar-me com isto..."

    # say L2270 bri
    old "When you went looking for her, I thought you would come back together to have sex..."
    new "B:bri: O que estás a fazer?"

    # say L2271 pla
    old "Of course not, things don't work like that..."
    new "B:bri: Quando foste procurá-la, pensei que voltariam juntos para fazer sexo..."

    # say L2273 pla
    old "Perhaps you should be helping me instead of complaining so much."
    new "T: Talvez devesse estar a ajudar-me em vez de te queixares tanto."

    # say L2274 pla
    old "Maybe this way we can help Barbie more quickly..."
    new "T: Talvez assim possamos ajudar a Barbie mais depressa..."

    # say L2275 pla
    old "And so we can wrap this up and start looking for the next 'specimen' as you want..."
    new "B:pla: Talvez assim possamos ajudar a Barbie mais depressa..."

    # say L2276 bri
    old "Hmph, I guess you leave me no choice..."
    new "T(bri|tu|say): Hmph, acho que não me deixa escolha..."

    # say L2278 pla
    old "It's not easy, really, unless you magically know somebody that can get a casting with a modeling agency."
    new "T: Não é fácil, a sério, a menos que conheças alguém que consiga uma audição com uma agência de modelos."

    # say L2280 pla
    old "I need someone who works with models, you know, like these clothes and lingerie brands, or something like that..."
    new "B:pla: Não é fácil, realmente, a menos que tu conheças alguém que consiga uma audição com uma agência de modelos."

    # say L2292 pla
    old "Anyway, I'm a bit tired, so, I'm going to sleep now..."
    new "B:bri: Hmm, se tu dizes..."

    # say L2294 pla
    old "See you tomorrow Brixxida."
    new "B:pla: De qualquer forma, estou um pouco cansado, então, vou dormir agora..."

    # say L2295 bri
    old "See you..."
    new "T(bri|tu|say): Até amanhã..."

    # say L2318 sis
    old "What brings you here so early?"
    new "B:bri: Até logo..."

    # say L2323 pla
    old "W- well... Uhmm."
    new "B:sis: O que se passa?"

    # say L2325 pla
    old "T- the thing is that I kinda need a favor from you."
    new "B: pla: B- bem... Hmmm."

    # say L2328 pla
    old "But... I don't really know how to ask you..."
    new "B: ZZZ…ZZZ T - a questão é que eu preciso de um favor teu."

    # say L2329 sis
    old "Well just do it."
    new "B:pla: Mas... não sei bem como te pedir..."

    # say L2330 sis
    old "You know I'll help you with anything you want."
    new "Bem, aqui vai..."

    # say L2336 sis
    old "Yeah, sure I do. That silicon-filled bimbo."
    new "O que é que tens contra ela?"

    # say L2337 sis
    old "What about her?"
    new "B:sis: Claro, faço isso. Essa loira de silicone."

    # say L2338 pla
    old "Uh... W- well, the thing is that..."
    new "B:sis: E ela?"

    # say L2340 sis
    old "Are you serious right now [pla]?!"
    new "T(sis|tu|diz): Estás a ser a sério agora [pla]?!"

    # say L2349 pla
    old "Well, she wants to be a model, so I said that I would help her with that."
    new "B:pla: Estamos a conversar e ela disse-me que ultimamente tem-se sentido muito triste por não conseguir..."

    # say L2350 pla
    old "But the truth is that I have no contacts in the modeling industry."
    new "B:pla: Ela quer ser modelo, por isso disse que a iria ajudar com isso."

    # say L2351 pla
    old "So, I was wondering if you would consider having her model for your online business."
    new "B:pla: Mas a verdade é que não tenho contactos na indústria da moda."

    # say L2353 sis
    old "No I would not accept it!"
    new "B:pla: Então, estava a pensar se tu consideravas ter ela a modelar para o teu negócio online."

    # say L2356 sis
    old "Why would I want that vulgar, plastic bimbo modeling in my clothes?!"
    new "Não aceitaria isso! Por que razão quereria que essa vulgar e plástica bimbo usasse as minhas roupas?! Isso arruinaria a reputação da minha marca!"

    # say L2357 sis
    old "It would ruin the reputation of my brand!"
    new "B: Irmã: Por que eu iria querer que essa vulgar e plástica bimbo posasse com as minhas roupas?!"

    # say L2360 sis
    old "Which by the way, I'm surprised you're so interested in her as to come here and ask me if I would let her model my clothes!"
    new "B:sis: Isso arruinaria a reputação da minha marca!"

    # say L2361 sis
    old "You know [pla], I thought you had better taste than that."
    new "T(sis|tu|diz): Sabes [pla], pensei que tivesses melhor gosto do que isso."

    # say L2364 sis
    old "All of this just because you want to bang that stupid girl?"
    new "B:sis: Quero dizer..."

    # say L2367 pla
    old "What? Come on, is not like that."
    new "B:sis: Tudo isto só porque queres foder aquela rapariga estúpida?"

    # say L2368 sis
    old "Oh yeah? Then how is it?"
    new "B:pla: Que? Vamos, não é assim."

    # say L2371 sis
    old "Because it seems to me that you're more interested in fucking her than anything else."
    new "B:sis: Oh yeah? Então como é que é?"

    # say L2372 sis
    old "You men are so predictable, you see some stupid girl with tits and ass like balloons and you go crazy."
    new "B:sis: Porque me parece que tu estás mais interessado em foder com ela do que em qualquer outra coisa."

    # say L2373 pla
    old "I already told you, is not like that..."
    new "B:sis: Vocês, homens, são tão previsíveis, veem uma miúda estúpida com peitos e rabo como balões e ficam loucos."

    # say L2374 bri
    old "Boy, you seem to have a talent for altering people's feelings."
    new "B:pla: Já te disse, não é assim..."

    # say L2376 bri
    old "Every time I'm with you, you're making some woman angry or cry or just lose her temper."
    new "T(bri|tu|say): Toda vez que estou contigo, estás a fazer alguma mulher ficar zangada, a chorar ou a perder a cabeça."

    # say L2378 pla
    old "Why don't you help me then?"
    new "T(pla|tu|say): Porque é que não me ajudas então?"

    # say L2380 sis
    old "What? Do you need even more explanations?"
    new "B:pla: E então, por que não me ajudas?"

    # say L2381 pla
    old "Uhh? No, no, I- I-... Nevermind..."
    new "B:sis: Que? Precisas de mais explicações?"

    # say L2384 bri
    old "Hahaha, look at you! Grasping for words."
    new "T(bri|tu|say): Hahaha, olha para ti! À procura de palavras."

    # say L2385 bri
    old "I'll help you then."
    new "B:bri: Hahaha, olha para ti! À procura de palavras."

    # say L2393 bri
    old "Listen [pla]."
    new "T(bri|tu|diz): Ouve [pla]. Ela está a sentir uma emoção muito negativa. E está toda direcionada a ti."

    # say L2397 sis
    old "Anyway, you can leave, I'm busy."
    new "B:bri: Ela está a sentir uma emoção muito negativa. E está toda direcionada a ti."

    # say L2399 bri
    old "No wait! It's not directed at you!"
    new "B:sis: De qualquer forma, podes ir, estou ocupada."

    # say L2402 bri
    old "Is about that girl!"
    new "B:bri: Não espera! Não é para ti!"

    # say L2403 bri
    old "She's..."
    new "B:bri: É sobre aquela rapariga!"

    # say L2405 bri
    old "Jelaous!"
    new "B:bri: Ela está..."

    # say L2407 bri
    old "That's it, she's feeling jealous."
    new "T(bri|tu|say): É isso, ela está com ciúmes."

    # say L2411 pla
    old "I mean, I think I didn't express explain properly."
    new "T(pla|tu|diz): Quero dizer, acho que não me expliquei direito. A razão pela qual quero ajudar a Barbie não é porque quero dormir com ela ou algo assim."

    # say L2413 pla
    old "Listen, the reason why I want to help Barbie is not that I want to sleep with her or something like that."
    new "B: pla: Quero dizer, acho que não me expliquei bem."

    # say L2414 pla
    old "The truth is that I've been thinking that I would like to be a photographer."
    new "A:sis: Um fotógrafo?"

    # say L2417 sis
    old "A photographer?"
    new "B:pla: A verdade é que tenho pensado que gostava de ser fotógrafo."

    # say L2419 pla
    old "Yeah, you know I'm good with the camera."
    new "B:sis: Um fotógrafo?"

    # say L2420 pla
    old "And that I know how to edit and present pictures."
    new "B:pla: Yeah, tu sabes que sou bom com a câmara."

    # say L2421 pla
    old "So it came to my mind that I could do some work in that field. You know for magazines and stuff."
    new "Mas arranjar um emprego como fotógrafo é muito difícil."

    # say L2422 pla
    old "But getting a job as a photographer is too difficult."
    new "B:pla: Então me ocorreu que eu poderia fazer algum trabalho nessa área. Sabes, para revistas e coisas assim."

    # say L2423 pla
    old "But then I talked with Barbie, and it came to my mind that maybe that was it."
    new "B:pla: Mas arranjar um emprego como fotógrafo é muito difícil."

    # say L2424 pla
    old "That if I helped her it could be good for the both of us, and that I could get a job as a photographer like that."
    new "B:pla: Mas depois falei com a Barbie, e me veio à mente que talvez fosse isso."

    # say L2426 sis
    old "Hmm, are you serius?"
    new "B:pla: Que se eu a ajudasse poderia ser bom para os dois, e que eu poderia arranjar um emprego como fotógrafo assim."

    # say L2427 pla
    old "Yeah, that's really all I'm looking for. I don't know where you got the idea about sex..."
    new "B:sis: Hmm, estás a falar a sério?"

    # say L2432 sis
    old "But why didn't you start with that?"
    new "B:sis: É realmente um bom pensamento da tua parte."

    # say L2433 pla
    old "W- well you know."
    new "B:sis: Mas por que não começaste assim?"

    # say L2434 pla
    old "I- I didn't think that was that important."
    new "Tu não achaste que isso era importante?"

    # say L2436 sis
    old "You didn't think that was important?"
    new "T: Tu não achaste que isso era importante?"

    # say L2437 sis
    old "But you thought it was more important to just tell me you want to help that plastic bimbo?"
    new "B: Irmã: Tu não achaste que isso era importante?"

    # say L2438 sis
    old "Very smart."
    new "Mas enfim, acho que percebo o que queres dizer."

    # say L2440 sis
    old "But anyway, I think I see your point."
    new "B: Irmã: Muito inteligente."

    # say L2441 sis
    old "And you are good with the camera."
    new "E tu és bom com a câmara. Podias ser um bom fotógrafo."

    # say L2442 sis
    old "You could be a good photographer."
    new "B:sis: E tu és bom com a câmara."

    # say L2443 sis
    old "Now, let me see your portfolio of her pictures."
    new "A:pla: Portefólio?"

    # say L2444 pla
    old "Portfolio?"
    new "B:sis: Agora, deixa-me ver o teu portefólio de fotografias dela."

    # say L2446 sis
    old "Well of course."
    new "B:pla: Portfolio?"

    # say L2447 sis
    old "I mean, you do have a portfolio of pictures right?"
    new "B:sis: Claro. T(sis|tu|dizes): Quero dizer, tu tens um portefólio de fotografias, certo? A:pla: Eu- Eu não..."

    # say L2448 pla
    old "I- I don't..."
    new "B:sis: Quero dizer, tu tens um portefólio de fotografias, certo?"

    # say L2449 sis
    old "Ugh, be serious [pla]."
    new "T(sis|tu|diz): Ugh, toma jeito [pla]."

    # say L2451 sis
    old "If you want someone to give you a job in photography you need to have pictures to show."
    new "B: Irmã: Dizes que queres ser fotógrafa, mas não sabes nada."

    # say L2452 sis
    old "Especially with something like pictures of that little plastic dumb."
    new "B: Irmã: Se queres que alguém te dê um emprego em fotografia, precisas de ter fotografias para mostrar."

    # say L2453 sis
    old "How else is someone going to hire her?"
    new "B:sis: Especialmente com algo como fotos daquela pequena boneca de plástico."

    # say L2454 pla
    old "I understand, so you need me to take pictures of her?"
    new "B:sis: Como é que outra pessoa vai contratá-la?"

    # say L2455 pla
    old "I think I can do that, and bring some of those for you."
    new "B:pla: Entendi, então precisas que eu tire fotos dela?"

    # say L2457 sis
    old "Good. Be sure they're good so that I can show them to the people that might hire her."
    new "B:pla: Acho que consigo fazer isso e trazer alguns para ti."

    # say L2459 sis
    old "By the way, I hope you understand I'm not doing this out of the goodness of my heart, right?"
    new "B: Irmã: Ótimo. Certifica-te de que são boas para eu as mostrar às pessoas que podem contratá-la."

    # say L2461 sis
    old "If she's going to get money for it, and I got her the job, I want my cut."
    new "B:sis: Aliás, espero que percebas que não estou a fazer isto por bondade, certo?"

    # say L2462 pla
    old "Uhh, yeah yeah, sure..."
    new "B:sis: Se ela vai ganhar dinheiro com isso e eu arranjei o emprego para ela, quero a minha parte."

    # say L2463 pla
    old "If you get her a job, then sure, I can give you a commission."
    new "B:pla: Uhh, yeah yeah, claro..."

    # say L2465 sis
    old "I want a 10 percent! Is that clear?"
    new "B:pla: Se lhe arranjares um emprego, então claro, posso dar-te uma comissão."

    # say L2466 pla
    old "Sure, whatever."
    new "B:sis: Quero 10 por cento! É claro?"

    # say L2470 sis
    old "I'm helping you."
    new "B:sis: Pois bem, não estou a fazê-lo por ela."

    # say L2471 pla
    old "Sure, but thanks anyway."
    new "B:sis: Estou a ajudar-te."

    # say L2472 sis
    old "You're welcome."
    new "T(sis|tu|diz): De nada."

    # say L2473 pla
    old "I'll talk to Barbie later and let her know about this."
    new "B:sis: De nada."

    # say L2475 sis
    old "Listen, I have to leave for now, so I'll send you the info when I get it."
    new "B:pla: Vou falar com a Barbie mais tarde e contar-lhe sobre isto."

    # say L2500 pla
    old "I'm doing well, thank you."
    new "Oi, escuta, tenho ótimas notícias!"

    # say L2501 pla
    old "Hey listen, I have great news!"
    new "B:pla: Estou bem, obrigado. T(pla|tu|say): Olha, tenho ótimas notícias! A:pla: Pode-se dizer isso."

    # say L2503 pla
    old "You could say that."
    new "T(pla|tu|say): Podes dizer isso."

    # say L2504 pla
    old "Do you remember what we had talked about modeling?"
    new "B:pla: Podes dizer isso."

    # say L2506 pla
    old "Well, after we talked I got in contact with someone I know that has some connections to the modeling business."
    new "B:pla: Tu te lembras do que falámos sobre modelagem?"

    # say L2507 pla
    old "And she told me that she could get you an interview!"
    new "B:pla: Bem, depois de falarmos, entrei em contacto com uma pessoa que conheço e que tem algumas ligações ao mundo da moda."

    # say L2510 pla
    old "Yeah, but you see..."
    new "B:pla: E ela me disse que poderia arranjar-te uma entrevista!"

    # say L2512 pla
    old "She told me that I had to take some pictures of you, to show to the agency."
    new "T(pla|tu|say): Ela disse-me que tinha de tirar algumas fotografias tuas, para mostrar à agência."

    # say L2513 pla
    old "Like a portfolio or something."
    new "B: Ela disse-me que tinha de tirar algumas fotografias tuas para mostrar à agência."

    # say L2515 pla
    old "You know, to see how you look."
    new "B:pla: Como um portefólio ou algo assim."

    # say L2519 pla
    old "Actually, I can take them myself."
    new "B:pla: Sabes, para ver como ficas."

    # say L2523 pla
    old "Yeah sure, it wouldn't be a problem."
    new "B:pla: Na verdade, posso eu mesmo."

    # say L2524 pla
    old "I have some experience as a photographer."
    new "B:pla: Claro, não será problema."

    # say L2527 pla
    old "Heh, well thank you."
    new "B:pla: Tenho alguma experiência como fotógrafo."

    # say L2528 pla
    old "But you see, we have to take the pictures soon."
    new "B: Heh, bem, obrigado."

    # say L2529 pla
    old "She wants to send them as soon as possible."
    new "B:pla: Mas vês, temos de tirar as fotos já."

    # say L2530 pla
    old "So, how about we go to my house after you finish work and take the photos?"
    new "B:pla: Ela quer enviá-los o mais rápido possível."

    # say L2534 pla
    old "Come on, you don't have to worry about it."
    new "B:pla: Então, que tal irmos para minha casa depois de tu terminares o trabalho e tirarmos as fotos?"

    # say L2535 pla
    old "What you're wearing is perfect, you don't need to worry about it."
    new "B:pla: Vamos, não precisas de te preocupar com isso."

    # say L2539 pla
    old "Of course, you look perfect the way you are."
    new "B:pla: O que estás a usar é perfeito, não precisas de te preocupar com isso."

    # say L2544 pla
    old "Great, so I'll wait until your shift is over, and after we can go to my house."
    new "B:pla: Claro, tu estás perfeita assim."

    # say L2554 pla
    old "Okay, lets go."
    new "Bem, então eu espero até o teu turno acabar, e depois podemos ir para minha casa. Tudo bem, vamos. Tudo certo, então podemos começar-"

    # say L2567 pla
    old "Alright, we can get started then-"
    new "Tudo bem, podemos começar então."

    # say L2570 pla
    old "Don't worry about it."
    new "Não te preocupes com isso. Posso mostrar-te."

    # say L2571 pla
    old "I can show you."
    new "B:pla: Não te preocupes com isso."

    # say L2575 pla
    old "And sometimes I'm the one that takes the pictures of her new clothes."
    new "B:pla: Ela tem um negócio de roupa online."

    # say L2578 pla
    old "Heh, thank you."
    new "B:pla: E por vezes sou eu que tiro as fotos das suas novas roupas."

    # say L2579 pla
    old "Anyway, I guess we can get started then."
    new "B:pla: Heh, obrigado."

    # say L2581 pla
    old "Just relax, I'll tell you how you should pose."
    new "B:pla: Então, acho que podemos começar."

    # say L2582 pla
    old "So, for the first picture..."
    new "B:pla: Relaxa, vou dizer-te como deves posar."

    # say L2583 pla
    old "How about you sit down in the bed with your legs open, looking this way."
    new "B:pla: Então, para a primeira foto..."

    # say L2584 pla
    old "Put your left arm up behind your head, and bring the right one to your neck."
    new "B: pla: Por que não te sentas na cama com as pernas abertas, a olhar para aqui?"

    # say L2585 pla
    old "Over your right breast."
    new "B: Coloca o braço esquerdo por cima da cabeça e traz o direito para o pescoço."

    # say L2586 pla
    old "And look straight at the camera, Ok?"
    new "B:pla: Sobre o teu seio direito."

    # say L2598 pla
    old "Alright perfect! "
    new "B:pla: E olha direto para a câmara, ok?"

    # say L2599 pla
    old "That way you're more than perfect!"
    new "B:pla: Perfeito!"

    # say L2600 pla
    old "Just stay put and I'll take the first picture."
    new "B:pla: Assim estás mais do que perfeita!"

    # say L2621 pla
    old "That was perfect Barbie!"
    new "B:pla: Fica aí e eu tiro a primeira foto."

    # say L2622 pla
    old "Now, for the second pose."
    new "B:pla: Foi perfeito, Barbie!"

    # say L2624 pla
    old "Hmm, let's see..."
    new "B:pla: Agora, para a segunda pose."

    # say L2625 pla
    old "I think we should show you from all angles."
    new "B:pla: Hmm, vamos ver..."

    # say L2626 pla
    old "So, how about you take more of a kneeling position in the bed."
    new "B:pla: Acho que devemos mostrar-te de todos os ângulos."

    # say L2627 pla
    old "With your legs towards me."
    new "B:pla: Então, que tal ficares numa posição mais de joelhos na cama."

    # say L2628 pla
    old "And put your weight on your left arm."
    new "B:pla: Com as tuas pernas na minha direção."

    # say L2642 pla
    old "Yes! That's perfect!"
    new "Ótimo, Barbie!"

    # say L2643 pla
    old "Great Barbie!"
    new "B:pla: Sim! Perfeito!"

    # say L2645 pla
    old "Just stay like that, and I'll take the picture."
    new "B:pla: Grande Barbie!"

    # say L2666 pla
    old "Alright, that's great!"
    new "B:pla: Fica assim, e eu tiro a foto."

    # say L2667 pla
    old "Now, I think we can take another picture."
    new "T(pla|tu|say): Agora, acho que podemos tirar outra foto."

    # say L2669 pla
    old "Sure, for the third one let's make it a close-up."
    new "B:pla: Agora, acho que podemos tirar outra foto."

    # say L2670 pla
    old "So, turn to face the camera."
    new "B:pla: Claro, para o terceiro vamos fazer um close."

    # say L2671 pla
    old "And bring your breasts forward with your hands while you smile."
    new "B:pla: Então, vira-te para a câmara."

    # say L2672 pla
    old "Ok, I know what you mean."
    new "B:pla: E traz os teus seios para a frente com as mãos enquanto sorris."

    # say L2685 pla
    old "That's right! Perfect!"
    new "Tu és muito boa nisto, Barbie!"

    # say L2686 pla
    old "You're very good at this Barbie!"
    new "B:pla: Isso mesmo! Perfeito!"

    # say L2688 pla
    old "No matter how good I am, it wouldn't be possible without such a beautiful model."
    new "B:pla: Tu és muito boa nisto, Barbie!"

    # say L2709 pla
    old "Alright, that's it, I think that we have enough pictures with those ones."
    new "B:pla: Não importa quão boa eu seja, não seria possível sem um modelo tão bonito."

    # say L2711 pla
    old "Yeah, I think those are more than enough."
    new "B:pla: Tudo bem, acho que temos fotos suficientes com estas."

    # say L2716 pla
    old "Ok, I think these came out great!"
    new "Bem, acho que estes ficaram ótimos! Aqui, olha."

    # say L2720 pla
    old "Here, look."
    new "B:pla: Ok, acho que ficaram ótimas!"

    # say L2729 pla
    old "I'm sure they will."
    new "A:pla: Além disso, ainda tenho de fazer algumas edições neles."

    # say L2730 pla
    old "Besides, I still have to do a couple of edits on them."
    new "B:pla: Tenho a certeza que sim."

    # say L2731 pla
    old "When I'm done they're going to look even better."
    new "B:pla: Além disso, ainda tenho que fazer algumas edições neles."

    # say L2735 pla
    old "What? There's no way this is just because of me taking the pictures!"
    new "B:pla: Quando acabar, vão ficar ainda melhores."

    # say L2736 pla
    old "These pictures are because of how beautiful you are."
    new "B:pla: Que? Não há maneira de isto ser só por eu estar a tirar as fotos!"

    # say L2737 pla
    old "After all the only thing I'm doing is just taking the pictures."
    new "B: pla: Estas fotos são por causa da tua beleza."

    # say L2738 pla
    old "You're the one that's posing."
    new "B:pla: Afinal, a única coisa que estou a fazer é tirar as fotografias."

    # say L2739 pla
    old "And if they come up any good, is just because of how well you posed."
    new "B:pla: Tu és quem está a posar."

    # say L2755 pla
    old "Woah, woah, w- what are you doing Barbie?"
    new "B:pla: E se ficarem bem, é só porque tu poses tão bem."

    # say L2758 pla
    old "B- but..."
    new "B:pla: Woah, woah, w- o que estás a fazer, Barbie?"

    # say L2771 pla
    old "Alright, so I'll send the pictures to my contact today. And she'll let me know if she can get the interview for you."
    new "B: B- mas..."

    # say L2773 pla
    old "It will probably not be something big, at least not to start with."
    new "B:pla: Vou enviar as fotos para a minha contacta hoje. E ela vai dizer-me se consegue arranjar-te a entrevista."

    # say L2774 pla
    old "But I think that it might be a good starting point for you."
    new "B:pla: Provavelmente não será nada de grande, pelo menos para começar."

    # say L2786 pla
    old "Yeah, I have to get to it now."
    new "B:pla: Mas acho que pode ser um bom ponto de partida para ti."

    # say L2787 pla
    old "But as soon as the pictures are done I'll hand them over to my contact."
    new "B:pla: Sim, tenho de o fazer agora."

    # say L2788 pla
    old "And when I get an answer I'll let you know."
    new "B:pla: Mas assim que as fotos estiverem prontas, vou entregá-las ao meu contacto."

    # say L2855 pla
    old "I'm ok, thank you."
    new "B:sis: Estou ótima, e tu?"

    # say L2857 pla
    old "Hey, listen, about the favor that I asked you last time."
    new "B:pla: Estou bem, obrigado."

    # say L2858 sis
    old "Oh yeah, your little plastic girl's pictures."
    new "B:pla: Oi, ouve, sobre o favor que te pedi da última vez."

    # say L2859 sis
    old "I send them over to a friend of mine that works for another clothing business."
    new "B:sis: Oh yeah, as fotos da tua boneca de plástico."

    # say L2860 sis
    old "Their clothes are more like the type of thing that that idiot would wear."
    new "T(sis|tu|dizes): As roupas deles são mais do tipo que aquele idiota usaria."

    # say L2861 pla
    old "And what did they say?"
    new "B:sis: As roupas deles são mais do tipo que esse idiota usaria."

    # say L2868 pla
    old "When do they want to meet her?"
    new "B:pla: E o que é que eles disseram?"

    # say L2869 sis
    old "In a couple of days."
    new "B:pla: Quando é que eles querem encontrar-se com ela?"

    # say L2870 sis
    old "I'll send you the info."
    new "E não te preocupes, já falei com eles."

    # say L2871 sis
    old "And don't worry, I talked with them."
    new "E não te preocupes, falei com eles. Disseram que se a contratarem, terão a certeza de nos dar a nossa parte."

    # say L2872 sis
    old "They said that if they hire her they'll be sure to give us our cut."
    new "B:sis: E não te preocupes, falei com eles."

    # say L2873 pla
    old "I see... That's great."
    new "B:sis: Disseram que se a contratarmos, terão a certeza de nos dar a nossa parte."

    # say L2874 pla
    old "Alright, I'll have to tell her about this."
    new "B:pla: Entendo... Isso é ótimo."

    # say L2880 sis
    old "I don't want her to make me look bad by getting there late or anything."
    new "B: Irmã: Lembra-te de dizer à tua amiga mais nova que tem de estar lá a horas."

    # say L2881 sis
    old "Is that clear?"
    new "B:sis: Não quero que ela me faça parecer mal chegando atrasada ou algo assim."

    # say L2882 pla
    old "Yeah, yeah, it is."
    new "B:sis: Isso está claro? T(pla|tu|say): Sim, sim, está. A:sis: Ótimo."

    # say L2883 sis
    old "Good."
    new "B:pla: Sim, sim, é isso."

    # say L2884 pla
    old "Yeah.. I'll see you later then."
    new "T(pla|tu|say): Sim... Até mais então."

    # say L2885 pla
    old "Bye [sis], thanks for the help."
    new "T(pla|tu|say): Adeus [sis], obrigado pela ajuda."

    # say L2911 pla
    old "That contact I told you about got an interview for you!"
    new "B:pla: Estou bem, e ouve, tenho boas notícias!"

    # say L2914 pla
    old "Yeah, it's to apply for a position as a model for a clothing brand that works mainly online."
    new "T(pla|tu|say): Sim, é para candidatar-me a uma posição de modelo para uma marca de roupa que trabalha principalmente online."

    # say L2915 pla
    old "It's not the biggest job in the world but..."
    new "B:pla: Sim, é para candidatar-me a uma posição de modelo para uma marca de roupa que trabalha principalmente online."

    # say L2919 pla
    old "It's my pleasure."
    new "B:pla: Não é o maior trabalho do mundo, mas..."

    # say L2920 pla
    old "I'm happy to be able to help you."
    new "B:pla: É um prazer."

    # say L2921 pla
    old "I'll send you the details, don't forget to go, alright?'"
    new "B:pla: Estou feliz por poder ajudar-te."

    # say L2923 pla
    old "Hey, don't thank me yet. Let's wait until you get the job."
    new "B:pla: Vou-te enviar os detalhes, não te esqueças de ir, ok?"

    # say L2925 pla
    old "I'll come by later to see how everything went, alright?"
    new "B:pla: Hey, não me agradeças ainda. Vamos esperar até tu conseguires o emprego."

    # say L2945 bri
    old "You're taking too long, how many more times are you going to see this woman?"
    new "B:pla: Passo mais tarde para ver como correu, tudo bem?"

    # say L2946 pla
    old "I already told you. Until I'm done helping her with everything I promised I would do."
    new "T: Já te disse. Até acabar de ajudá-la com tudo o que prometi fazer."

    # say L2947 pla
    old "What are you doing here anyway?"
    new "B:pla: Já te disse. Até acabar de ajudá-la com tudo o que prometi fazer."

    # say L2948 bri
    old "I thought I told you, you take too long."
    new "T(bri|tu|say): Pensei que já te tinha dito, demoras demasiado."

    # say L2949 bri
    old "So, I came to help you deal with this quickly."
    new "B:bri: Eu pensei que te tinha dito, demoras demasiado."

    # say L2950 pla
    old "Ok, thank you I guess."
    new "T:pla: Ok, obrigado, suponho."

    # say L2951 pla
    old "But I think everything's going to go well, you know?"
    new "B:pla: Ok, obrigado acho eu."

    # say L2952 pla
    old "Since I got her the interview, I'm sure that went well, and now she has good news."
    new "B:pla: Mas acho que tudo vai correr bem, sabes?"

    # say L2953 pla
    old "But let's go and talk to her."
    new "B:pla: Como arranjei a entrevista para ela, tenho a certeza de que correu bem e agora tem boas noticias."

    # say L2963 pla
    old "Hey Barbie, good morning."
    new "B:pla: Mas vamos falar com ela."

    # say L2967 pla
    old "W- what's wrong Barbie?"
    new "B:pla: Olá Barbie, bom dia."

    # say L2970 pla
    old "It didn't go well?"
    new "B:pla: O- o que aconteceu, Barbie?"

    # say L2972 pla
    old "What happened?"
    new "B:pla: Não correu bem?"

    # say L2975 pla
    old "S- sure, no problem."
    new "B: O que aconteceu?"

    # say L2976 pla
    old "I'll see you later then."
    new "T(pla|tu|dizer): Vejo-te mais tarde então."

    # say L3000 pla
    old "Ok, so now will you tell me about what happened?"
    new "A:pla: Como correu a entrevista?"

    # say L3001 pla
    old "How did the interview go?"
    new "B:pla: Ok, então agora vais me contar o que aconteceu?"

    # say L3007 pla
    old "Ok, that's good to hear."
    new "Mas então o que correu mal?"

    # say L3008 pla
    old "But then what went wrong?"
    new "Mas então o que correu mal?"

    # say L3014 pla
    old "So, did he say anything to you about that?"
    new "A:pla: Que raio? Quem se pensa ele que é?!"

    # say L3030 pla
    old "What the hell? Who does he think he is?!"
    new "B:pla: Então, ele disse algo a ti sobre isso?"

    # say L3031 pla
    old "I'm sorry Barbie, I had no idea things would turn out that way."
    new "B:pla: Que raio? Quem ele pensa que é?!"

    # say L3032 pla
    old "I didn't expect that."
    new "B:pla: Desculpa, Barbie, não fazia ideia que as coisas fossem acabar assim."

    # say L3033 pla
    old "But I'll get you another interview in a better place."
    new "B:pla: Não esperava isso."

    # say L3034 pla
    old "And I'll make sure that this doesn't happen again."
    new "B:pla: Mas vou arranjar-te outra entrevista num lugar melhor."

    # say L3039 pla
    old "W- wait!"
    new "T: W- espera!"

    # say L3040 pla
    old "I get it, you've had a bad streak with the auditions and interviews."
    new "Mas isso não significa que deves desistir."

    # say L3041 pla
    old "But that doesn't mean that you should give up."
    new "B:pla: Entendi, tu tiveste uma série de más experiências nas audições e entrevistas."

    # say L3042 pla
    old "Don't let a couple of bad experiences rob you of your dream."
    new "B:pla: Mas isso não significa que deves desistir."

    # say L3046 pla
    old "D- do you want to talk about it?"
    new "B:pla: Não deixes que umas más experiências te roubem o sonho."

    # say L3050 pla
    old "Listen Barbie, what you have been going through with these... Bad experiences."
    new "B: D- tu queres falar disso?"

    # say L3051 pla
    old "I can't imagine how frustrating it must be."
    new "B:pla: Ouve, Barbie, o que tens passado com estas... más experiências."

    # say L3052 pla
    old "Especially if there are things from your past that are related to this. I think that causes you a lot of pain."
    new "B:pla: Não consigo imaginar o quão frustrante isso deve ser."

    # say L3056 pla
    old "I understand, and that's fair."
    new "A:pla: Mas também acho que tu ainda não deves desistir do teu sonho de te tornares uma estrela Barbie."

    # say L3057 pla
    old "But I also think you still shouldn't give up on your dream of becoming a star Barbie."
    new "B:pla: Eu entendo, e isso é justo."

    # say L3058 pla
    old "I've seen your passion for it. And I know how much of a hard worker you are."
    new "B:pla: Mas também acho que tu ainda não deves desistir do teu sonho de te tornares uma estrela Barbie."

    # say L3059 pla
    old "If someone deserves a shot at something like that, it's you."
    new "B:pla: Vi a tua paixão por isso. E sei o quanto és trabalhador."

    # say L3064 pla
    old "Hmm, I see..."
    new "Ouço-te..."

    # say L3065 pla
    old "Listen, you already told me that something's troubling you."
    new "T(pla|tu|say): Ouve, tu já me disseste que algo te está a preocupar."

    # say L3066 pla
    old "But you told me you don't want to talk about it."
    new "B:pla: Ouve, tu já me disseste que algo te está a preocupar."

    # say L3067 pla
    old "Which I understand."
    new "Mas eu acho que tu deves falar sobre isso."

    # say L3068 pla
    old "But I think you should talk about it."
    new "T(pla|tu|say): Mas acho que deves falar sobre isso."

    # say L3069 pla
    old "Maybe opening up about it would do you well."
    new "T: Talvez abrir-te sobre isso te faça bem. A: Entendo, deve ser uma memória dolorosa, mas sabes, não há nada a temer."

    # say L3071 pla
    old "I get it, it must be a painful memory, but you know, there's nothing to be afraid of."
    new "T(pla|tu|say): Entendo, deve ser uma memória dolorosa, mas sabes, não há nada a temer."

    # say L3072 pla
    old "You can trust me with anything you want to share."
    new "B:pla: Entendo, deve ser uma memória dolorosa, mas sabes, não há nada a temer."

    # say L3073 pla
    old "No matter what it is, I want to support you and make sure that you feel safe and happy."
    new "B:pla: Podes confiar em mim com qualquer coisa que queiras partilhar."

    # say L3074 pla
    old "I mean it Barbie, whatever it is."
    new "B:pla: Não importa o que seja, quero apoiar-te e garantir que te sintas segura e feliz."

    # say L3076 pla
    old "That makes sense, but I'll be more than happy to listen to what you have to say."
    new "Para te ouvir."

    # say L3077 pla
    old "To listen to you."
    new "T(pla|tu|dizer): Para ouvir-te."

    # say L3078 pla
    old "Maybe talking about it you can get rid of some of that pain, you know?"
    new "E... O que aconteceu?"

    # say L3099 pla
    old "And... W- what happened?"
    new "B:pla: Talvez falando sobre isso tu consigas aliviar um pouco dessa dor, sabes?"

    # say L3124 pla
    old "Listen Barbie, I know that what happened in your past was very painful."
    new "B:pla: E... Q- que aconteceu?"

    # say L3126 pla
    old "And that we can't go back and changed it."
    new "B:pla: Ouve, Barbie, sei que o que aconteceu no teu passado foi muito doloroso."

    # say L3128 pla
    old "But I don't think you're wrong for chasing your dreams."
    new "Mas não acho que estejas errado por ir atrás dos teus sonhos."

    # say L3130 pla
    old "Or that you have made any mistakes by choosing to chase your dreams."
    new "B:pla: Mas não acho que estejas errado por perseguir os teus sonhos."

    # say L3132 pla
    old "Yes it's true that you've been unlucky with how things have gone in the past."
    new "B: Or que tenhas cometido qualquer erro ao escolher perseguir os teus sonhos."

    # say L3133 pla
    old "But I believe you still have a lot of chances for things to go your way."
    new "B:pla: É verdade que tiveste azar com o que aconteceu no passado."

    # say L3135 pla
    old "You're a beautiful and hard-working woman."
    new "B:pla: Mas acredito que ainda tens muitas hipóteses de as coisas correrem bem."

    # say L3136 pla
    old "I'm sure if you keep trying, sooner or later you'll someday meet someone that will be different from the rest."
    new "B: Tu és uma mulher bonita e trabalhadora."

    # say L3139 pla
    old "Of course you will!"
    new "T(pla|tu|say): Claro que vais! Tu és diligente e capaz."

    # say L3141 pla
    old "You're diligent and capable."
    new "B:pla: Claro que vais!"

    # say L3142 pla
    old "And I'm completely sure that you will find very good fortune."
    new "B: Tu és diligente e capaz."

    # say L3144 pla
    old "As I told you, if someone deserves good things coming their way, that is you."
    new "B:pla: E estou completamente certo de que vais encontrar muita sorte."

    # say L3145 pla
    old "So, if you'll believe me, I would like to help you keep working towards achieving your dream."
    new "B:pla: Como te disse, se alguém merece coisas boas, és tu."

    # say L3160 pla
    old "I'm just happy that I get to be here for you Barbie."
    new "B:pla: Então, se tu acreditas em mim, eu gostava de te ajudar a continuar a trabalhar para alcançares o teu sonho."

    # say L3161 pla
    old "About the other things, I'm just saying the truth every time we talk."
    new "B:pla: Estou só feliz por estar aqui para ti, Barbie."

    # say L3162 pla
    old "You're a capable and talented person."
    new "B: Sobre as outras coisas, estou só a dizer a verdade cada vez que falamos."

    # say L3195 pla
    old "I- I'll do my best."
    new "B: Tu és uma pessoa capaz e talentosa."

    # say L3197 pla
    old "Really, the next one will be better."
    new "B:pla: I- Vou fazer o meu melhor."

    # say L3199 pla
    old "I'm sure of it Barbie."
    new "B:pla: A sério, a próxima será melhor."

    # say L3203 pla
    old "I'm glad you feel that way."
    new "B:pla: Tenho a certeza, Barbie."

    # say L3204 pla
    old "Even though there have been a couple of inconveniences."
    new "B:pla: Fico contente que te sintas assim."

    # say L3205 pla
    old "But I'm sure we'll get you a job that's good enough for you."
    new "B:pla: Mesmo que tenham surgido alguns inconvenientes."

    # say L3214 pla
    old "U- Uh, I- I mean."
    new "B:pla: Mas tenho a certeza de que arranjaremos um trabalho que seja bom o suficiente para ti."

    # say L3223 pla
    old "Uh, s- sure, see you later."
    new "B:pla: H- Hum, q- quer dizer."

    # say L3245 pla
    old "Hey [sis], good morning."
    new "T(pla|tu|say): Olá [sis], bom dia. Como estás hoje?"

    # say L3248 pla
    old "I'm doing fine, but there's something we have to talk about."
    new "T: Estou bem, mas há algo de que temos de falar."

    # say L3249 sis
    old "What is it?"
    new "B:pla: Estou bem, mas há algo de que temos de falar."

    # say L3250 pla
    old "Well, I don't know the full details."
    new "B:sis: O que é?"

    # say L3252 pla
    old "But as Barbie told me, the guy who interviewed her for the modeling job tried to sleep with her."
    new "B:pla: Bem, não sei todos os detalhes."

    # say L3255 pla
    old "Yeah, he did. Apparently, he told her that there were a lot of good candidates for that job."
    new "T(pla|tu|say): Sim, ele fez isso. Aparentemente, ele disse que havia muitos bons candidatos para aquele trabalho."

    # say L3261 sis
    old "I mean what the fuck! What's wrong with him?!"
    new "B: Irmã: Que porco!"

    # say L3262 sis
    old "What a disgusting thing."
    new "B: Isto é que é incrível! O que é que ele tem?"

    # say L3264 sis
    old "Can you believe that bastard was trying to get me to model some clothes for his brand?"
    new "B: Irmã: Que coisa nojenta."

    # say L3265 sis
    old "But I hadn't had the time to do it."
    new "B: Irmã: Acreditas que aquele cretino estava a tentar convencer-me a modelar roupa para a marca dele?"

    # say L3267 sis
    old "That means that if I had been available he would probably have tried the same thing with me!"
    new "B:sis: Mas não tive tempo de fazer isso."

    # say L3269 sis
    old "And he had the gall to try and pull that with her?!"
    new "B:sis: Isso significa que se eu tivesse disponível ele provavelmente teria tentado a mesma coisa comigo!"

    # say L3271 sis
    old "Sure, he probably realized that she needed that opportunity and decided to take advantage."
    new "B:sis: E ele teve a lata de tentar isso com ela?!"

    # say L3273 sis
    old "What a fucking coward!"
    new "B:sis: Claro, ele provavelmente percebeu que ela precisava dessa oportunidade e decidiu aproveitar."

    # say L3274 pla
    old "Uhm... Yeah."
    new "B:sis: Que covarde!"

    # say L3280 sis
    old "But they won't be after I tell them what happened."
    new "B: Irmã: Na verdade, estou em contacto com algumas marcas que estão a trabalhar com esse tipo."

    # say L3281 sis
    old "I'll make everyone knows what that bastard tried to do."
    new "B:sis: Mas não vão depois de eu contar o que aconteceu."

    # say L3282 sis
    old "That way that pig will learn how to treat women!"
    new "B:sis: Vou fazer com que todos saibam o que aquele canalha tentou fazer."

    # say L3283 pla
    old "Uh- I- I see."
    new "B:sis: Aquela porca vai aprender a tratar as mulheres!"

    # say L3285 sis
    old "Tell Barbie sorry on my behalf."
    new "B:pla: Uh- I- I see."

    # say L3286 sis
    old "I may not like her too much, but I would have never knowingly sent her to a place like that."
    new "T(sis|tu|dizer): Posso não gostar muito dela, mas nunca a teria enviado conscientemente para um lugar desses."

    # say L3288 sis
    old "And of course, I'll make her up for it."
    new "B: Irmã: Posso não gostar muito dela, mas nunca a teria enviado conscientemente para um lugar desses."

    # say L3289 sis
    old "So don't worry, I'll get her another interview."
    new "E claro, vou compensá-la."

    # say L3291 sis
    old "And I'll make sure that this time is with a reputable place."
    new "B:sis: Não te preocupes, vou arranjar-lhe outra entrevista."

    # say L3295 sis
    old "I have a couple of calls to make."
    new "B:sis: Agora, falo contigo mais tarde."

    # say L3296 pla
    old "Uh- S- sure, see you later."
    new "B:sis: Tenho algumas chamadas a fazer."

    # say L3319 sis
    old "Good news, I brought something for you."
    new "B:pla: Uh- C-certo, até logo."

    # say L3320 pla
    old "Oh really? How come?"
    new "B:sis: Boas notícias, trouxe algo para ti."

    # say L3322 sis
    old "Well, I got another interview for Barbie."
    new "B:pla: Oh, realmente? Porquê?"

    # say L3326 sis
    old "And this time I made sure that the place where I'm sending her is quite reputable."
    new "B:sis: Não te preocupes com isso. Estou feliz por ajudá-la."

    # say L3327 sis
    old "So you can be sure that nothing like what happened last time will happen again."
    new "B:sis: E desta vez assegurei-me de que o lugar para onde a estou a enviar é bastante reputado."

    # say L3331 sis
    old "It is."
    new "A:sis: O lugar para onde a Barbie vai é uma empresa de lingerie."

    # say L3332 sis
    old "The place where Barbie's going is a lingerie company."
    new "B:sis: É."

    # say L3333 sis
    old "So, when I send them the pictures you had given me of Barbie, they thought she looked very good."
    new "B:sis: O lugar para onde a Barbie vai é uma empresa de lingerie."

    # say L3334 sis
    old "But they said they wanted to see her posing in some lingerie or underwear."
    new "B:sis: Então, quando lhes enviei as fotos que me deste da Barbie, acharam que ela estava muito bem."

    # say L3335 sis
    old "And I imagine you don't have a portfolio of pictures of her in lingerie, right?"
    new "B:sis: Mas disseram que queriam vê-la posando com lingerie ou roupa interior."

    # say L3337 pla
    old "Uh- n- no, I don't"
    new "B:sis: E imagino que não tenhas um álbum de fotos dela de lingerie, certo?"

    # say L3339 sis
    old "Well, that's why I took the liberty of getting some new lingerie that would fit her. You know, for you to take some pictures."
    new "B:pla: Uh- n- não, eu não"

    # say L3343 sis
    old "So, take this. And talk to her to take the pictures as soon as you can."
    new "B:sis: Bem, acho que era o mínimo que podia fazer. Sabes?"

    # say L3349 pla
    old "Alright, I'll talk to her as soon as I can."
    new "B:sis: Então, toma isto. E fala com ela para tirar as fotos o mais rápido possível."

    # say L3351 sis
    old "Alright. I'll be waiting for the pictures then."
    new "B:pla: Tudo bem, vou falar com ela assim que puder."

    # say L3352 sis
    old "By the way, you haven't forgotten about my 10 percent right?"
    new "B:sis: Tudo bem. Estou à espera das fotos então. T(sis|tu|diz): Aliás, não te esqueceste dos meus 10 por cento, certo? A:pla: Não, não, tenho-te coberto."

    # say L3353 pla
    old "No, no, I got you."
    new "B:sis: Por acaso, não te esqueceste dos meus 10 por cento, certo?"

    # say L3354 sis
    old "Alright, I'll see you later then."
    new "B:pla: Não, não, eu entendi."

    # say L3357 pla
    old "Sure, Bye."
    new "Tudo bem, adeus. Estou bem."

    # say L3381 pla
    old "I'm fine."
    new "B:pla: Claro, adeus."

    # say L3382 pla
    old "Actually I'm more than fine, I just got some good news."
    new "T(pla|tu|say): Na verdade, estou mais do que bem, acabei de receber boas notícias."

    # say L3384 pla
    old "That contact I told you about got you an interview!"
    new "B:pla: Na verdade, estou mais do que bem, acabei de receber boas notícias."

    # say L3385 pla
    old "And don't worry, this time she ensured me that what happened last time wouldn't happen again."
    new "B:pla: Aquele contacto de que te falei conseguiu-te uma entrevista!"

    # say L3390 pla
    old "Well, that's the thing, before they interview you. They said they would like to see a couple of pictures of you."
    new "B:pla: E não te preocupes, desta vez ela assegurou-me que o que aconteceu da última vez não se repetiria."

    # say L3393 pla
    old "Yeah, and they really liked them."
    new "B:pla: Pois, isso é que é, antes de te entrevistarem. Disseram que gostariam de ver umas fotografias tuas."

    # say L3394 pla
    old "But you see, this new place is a lingerie retailer."
    new "Mas vês, este novo sítio é uma loja de lingerie. Disseram que estariam interessados em ver como ficas de lingerie antes de ires."

    # say L3396 pla
    old "So they said they'd be interested in seeing how you look in lingerie before you go."
    new "B:pla: Mas vês, este novo lugar é uma loja de lingerie."

    # say L3397 pla
    old "So, my contact got some lingerie for you to try."
    new "B:pla: Disseram que estariam interessados em ver como tu ficas de lingerie antes de ires."

    # say L3399 pla
    old "I was thinking that maybe after you're done with your shift you'd like to come with me to my house and you can try it on."
    new "B:pla: Então, o meu contacto arranjou lingerie para tu experimentares."

    # say L3404 pla
    old "Great, then I'll wait until your shift is over and then we can come back to my house."
    new "B:pla: Estava a pensar que talvez depois de terminares o turno queiras vir comigo para minha casa e podes experimentá-lo."

    # say L3415 pla
    old "Alright, let's go then."
    new "B:pla: Ótimo, então vou esperar até o teu turno acabar e depois podemos voltar para minha casa."

    # say L3428 pla
    old "Alright, this is the lingerie, why don't you change into it? And we'll do the pictures."
    new "B:pla: Então, vamos lá."

    # say L3440 pla
    old "S- sorry, is not that I don't like it, I was just surprised because of how beautiful you look."
    new "B:pla: Tudo bem, esta é a lingerie, porque não te mudas? E depois fazemos as fotos."

    # say L3441 pla
    old "That lingerie looks very good on you."
    new "B: pla: Desculpa, não é que eu não goste, é que fiquei surpreendido com o quão bonita tu estás."

    # say L3445 pla
    old "What? Of course not!"
    new "B:pla: Essa lingerie fica-te muito bem."

    # say L3446 pla
    old "You look just perfect!"
    new "T: Tu estás perfeito!"

    # say L3447 pla
    old "You look very beautiful, I mean it."
    new "T(pla|tu|say): Tu estás muito bonita, falo a sério."

    # say L3450 pla
    old "Why? You don't think the same?"
    new "B: Tu estás muito bonita, digo a sério."

    # say L3454 pla
    old "You know, if you don't feel alright about this we don't have to do it."
    new "T(pla|tu|say): Sabes, se não te sentes bem com isto, não temos de o fazer."

    # say L3461 pla
    old "Come on, no one's going to think that."
    new "B:pla: Sabes, se não te sentes bem com isto, não temos de o fazer."

    # say L3462 pla
    old "You are one of the most beautiful girls I know  Barbie."
    new "B:pla: Vamos, ninguém vai pensar isso."

    # say L3463 pla
    old "I'm sure that as soon as they see you they'll want to hire you."
    new "B:pla: Tu és uma das raparigas mais bonitas que conheço, Barbie."

    # say L3465 pla
    old "Of course I do."
    new "B:pla: Tenho a certeza de que, assim que te virem, vão querer contratar-te."

    # say L3480 pla
    old "Ok, the first picture is just going to be you standing there normally."
    new "T(pla|tu|say): Ok, a primeira foto vai ser só tu aí parada normalmente. A:pla: Então não te mexas enquanto tiro a foto."

    # say L3481 pla
    old "So don't move while I take the picture."
    new "Bem, a primeira foto vai ser só tu aí parada normalmente. Então não te mexas enquanto tiro a foto. Bom, isso foi bom."

    # say L3502 pla
    old "Alright, that was good."
    new "B:pla: Então, não te mexas enquanto tiro a foto."

    # say L3503 pla
    old "So, for the second picture, how about you lay on your right side."
    new "B:pla: Estava bom."

    # say L3504 pla
    old "Open your body a little bit, and put your left leg up."
    new "B:pla: Então, para a segunda foto, deita-te de lado direito."

    # say L3505 pla
    old "Then rest your left hand on your hip, and lift your torso up a little using your right arm."
    new "B: pla: Abre um pouco o corpo e levanta a tua perna esquerda."

    # say L3518 pla
    old "That's it, perfect!"
    new "B:pla: Então, coloca a tua mão esquerda na anca e levanta um pouco o tronco com o braço direito."

    # say L3540 pla
    old "I do, you look wonderful"
    new "B:pla: Perfeito, é isso!"

    # say L3542 pla
    old "Alright, for the next one."
    new "B:pla: Eu aceito, tu estás maravilhoso."

    # say L3543 pla
    old "How about we show a little bit of how you look from behind?"
    new "B:pla: Tudo bem, para o próximo."

    # say L3545 pla
    old "Great, kneel with your back towards  me."
    new "T(pla|tu|say): Ótimo, ajoelha-te com as costas voltadas para mim."

    # say L3546 pla
    old "While you rest your forearms on the bed."
    new "B:pla: Ótimo, ajoelha-te com as costas voltadas para mim."

    # say L3547 pla
    old "And turn your head over your right shoulder while you look at me."
    new "B: pla: Enquanto apoias os antebraços na cama."

    # say L3559 pla
    old "That's it! Perfect!"
    new "B:pla: E vira a cabeça para o teu ombro direito enquanto me olhas."

    # say L3560 pla
    old "That's great Barbie!"
    new "B:pla: É isso! Perfeito!"

    # say L3562 pla
    old "You look great Barbie!"
    new "B:pla: Isso é ótimo, Barbie!"

    # say L3564 pla
    old "{i}(I can't believe she thought she wouldn't look good using the lingerie.){/i}"
    new "B:pla: {i}(Caramba, ela realmente está incrível.){/i}"

    # say L3566 pla
    old "{i}(Damn it! Why do I have to get a boner now?){/i}"
    new "B:pla: {i}(Não posso acreditar que ela pensou que não ficaria bem com a lingerie.){/i}"

    # say L3567 pla
    old "{i}(I think she hasn't noticed yet. Let's just finish this before she notices it.){/i}"
    new "B:pla: {i}(Raios! Porque é que tenho de ter uma ereção agora?){/i}"

    # say L3592 pla
    old "W- why don't you go change while I put the camera away?"
    new "B:pla: Tudo bem, acho que é isso."

    # say L3601 pla
    old "Uhh... w- well, y- you know."
    new "B: pla: W- por que não vais mudar-te enquanto eu guardo a câmara?"

    # say L3614 pla
    old "W- what are you doing?"
    new "B:pla: Uhh... b- bem, s- sabes."

    # say L3627 pla
    old "Uhh, I- I'm glad you liked it."
    new "B: pla: O- o que estás a fazer?"

    # say L3634 pla
    old "I'll let you know what they say about the pictures, alright?"
    new "B:pla: Uhh, eu- eu fico contente que tenhas gostado."

    # say L3659 pla
    old "Why are you waking me up at this time?"
    new "B:pla: Vou-te dizer o que disseram sobre as fotos, está bem?"

    # say L3661 bri
    old "Well, I have something to tell you."
    new "B:pla: Porque é que me estás a acordar a esta hora?"

    # say L3664 bri
    old "Great news! The process of implantation of the magic power within Barbie is complete!"
    new "B:bri: Bem, tenho algo para te dizer."

    # say L3666 bri
    old "So we can now move into the next objective!"
    new "B:bri: Boas notícias! O processo de implantação da força mágica na Barbie está completo!"

    # say L3667 pla
    old "Implantation of the magic power? What do you mean?"
    new "B:bri: Então podemos avançar para o próximo objetivo!"

    # say L3668 bri
    old "Ugh, I see that you forgot about what we were trying to do here."
    new "T(bri|tu|say): Ugh, vejo que te esqueceste do que estávamos a tentar fazer aqui. Tu te esqueceste que estamos a tentar fazer-te implantar poder mágico em diferentes mulheres."

    # say L3669 bri
    old "Did you forget that we're trying to get you to implant magic power into different women."
    new "B:bri: Ugh, vejo que te esqueceste do que estávamos a tentar fazer aqui."

    # say L3670 bri
    old "So that they can cultivate the magic power within their bodies?"
    new "B:bri: Tu esqueceste que estamos a tentar fazer-te implantar poder mágico em diferentes mulheres."

    # say L3671 pla
    old "Hmm... Yeah, right."
    new "B:bri: Para que possam cultivar o poder mágico dentro dos seus corpos?"

    # say L3673 pla
    old "According to what you told me last time."
    new "Isso quer dizer que ela está grávida agora?!"

    # say L3674 pla
    old "Does that mean that she's pregnant now?!"
    new "B:pla: De acordo com o que me contaste da última vez."

    # say L3676 bri
    old "Hmph, I guess that from your point of view that's how it looks."
    new "T(bri|tu|say): Hmph, acho que do teu ponto de vista é assim que parece."

    # say L3677 bri
    old "But not really."
    new "B:bri: Hmph, acho que do teu ponto de vista é assim."

    # say L3679 bri
    old "She'll just look and feel as if she is, but she's not pregnant."
    new "T(bri|tu|say): Ela só vai parecer e sentir-se como se estivesse, mas não está grávida."

    # say L3680 bri
    old "So you don't have to worry, when we're done with the spell we'll just collect the power."
    new "B:bri: Ela parecerá e sentir-se-á como se estivesse, mas não está grávida."

    # say L3682 bri
    old "And she'll just go back to normal."
    new "B:bri: Não tens de te preocupar, quando terminarmos o feitiço, apenas recolheremos a energia."

    # say L3684 pla
    old "When we're done with the spell?!"
    new "E quando terminarmos o feitiço?!"

    # say L3686 pla
    old "So until we're not done with it she'll be pregnant?"
    new "B:pla: Quando acabarmos o feitiço?!"

    # say L3687 pla
    old "That's not okay!"
    new "B:pla: Então até acabarmos ela vai ficar grávida?"

    # say L3688 pla
    old "She just barely got a chance to work."
    new "B:pla: Isso não está bem!"

    # say L3690 pla
    old "And if she's pregnant she won't even be able to work."
    new "B:pla: Ela mal teve oportunidade de trabalhar."

    # say L3691 pla
    old "You'll have to reverse it."
    new "B:pla: E se ela estiver grávida nem sequer vai poder trabalhar."

    # say L3692 bri
    old "Reverse it?! Are you crazy?"
    new "T(bri|tu|say): Inverter isso?! Estás louco?"

    # say L3693 bri
    old "With all of the time and magic power that has gone into it?!"
    new "T(bri|tu|dizes): Com todo o tempo e poder mágico que foram gastos nisso?!"

    # say L3694 bri
    old "How can you even say such a thing?"
    new "T(bri|tu|say): Como podes sequer dizer isso?"

    # say L3695 pla
    old "Because, as I told you! She can't be pregnant!"
    new "T(pla|tu|say): Porque, como te disse! Ela não pode estar grávida!"

    # say L3696 pla
    old "I understand that you want me to hurry up with the ritual."
    new "B:pla: Porque, como te disse! Ela não pode estar grávida!"

    # say L3697 pla
    old "And I promise you that if you do it I'll make sure to do what you need me to for the ritual to go well."
    new "B:pla: Entendo que queres que eu me apresse com o ritual."

    # say L3699 bri
    old "Ugh, you're so difficult to handle [pla]."
    new "T(bri|tu|say): Ugh, tu és tão difícil de lidar [pla]."

    # say L3702 bri
    old "But I want you to start working on the next target right away!"
    new "T(bri|tu|say): Mas quero que comeces a trabalhar no próximo alvo imediatamente!"

    # say L3703 pla
    old "Sure... But just let me finish what I have to do with Barbie."
    new "T:Claro... Mas deixa-me acabar o que tenho a fazer com a Barbie."

    # say L3706 pla
    old "I just have to finish a couple of things with her, and I'll get into working in the person."
    new "B:pla: Claro... Mas deixa-me acabar o que tenho a fazer com a Barbie."

    # say L3710 pla
    old "Sure, sure..."
    new "T:pla: Claro, claro..."

    # say L3733 pla
    old "I'm okay, but I imagine that not as well as you will."
    new "B:pla: Claro, claro..."

    # say L3736 pla
    old "You bet!"
    new "A:pla: Acabei de receber uma mensagem da pessoa que arranjou a entrevista para o trabalho de modelo."

    # say L3737 pla
    old "I just got a text from the person who got you the interview for the modeling gig."
    new "Eles disseram que adoraram as fotos e como tu ficas com a lingerie!"

    # say L3738 pla
    old "They said that they loved the pictures, and how you look with the lingerie on!"
    new "B:pla: Acabei de receber uma mensagem da pessoa que arranjou a entrevista para o trabalho de modelo."

    # say L3740 pla
    old "They said they wanted to meet with you to discuss hiring you as their model!"
    new "B:pla: Disseram que adoraram as fotos e como tu ficas com a lingerie!"

    # say L3747 pla
    old "Haha, I'm glad this makes you happy."
    new "B:pla: Disseram que querem encontrar-te para falar sobre te contratarem como modelo!"

    # say L3751 pla
    old "Oh no, it isn't."
    new "B: Haha, fico contente que isto te faça feliz."

    # say L3752 pla
    old "I've only made a couple of phone calls."
    new "B: Oh não, não é."

    # say L3753 pla
    old "This is because of your effort."
    new "B: pla: Só fiz uns quantos telefonemas."

    # say L3754 pla
    old "Although don't forget you still have to go to the interview."
    new "B:pla: Isto é graças ao teu esforço."

    # say L3755 pla
    old "But I'm sure everything's going to go well."
    new "B:pla: Mas não te esqueças que ainda tens de ir à entrevista."

    # say L3771 pla
    old "W- w- what are you doing Barbie?"
    new "B:pla: Mas tenho a certeza de que tudo vai correr bem."

    # say L3772 pla
    old "Y- you can't do that here!"
    new "B: pla: W- w- o que estás a fazer, Barbie?"

    # say L3775 pla
    old "B- but, t- there are cameras!"
    new "B: pla: N- não podes fazer isso aqui!"

    # say L3776 pla
    old "O- or someone could walk through here!"
    new "A:pla: Não acredito que tu tenhas feito isso!"

    # say L3787 pla
    old "I can't believe you actually did that!"
    new "B: pla: O- ou alguém pode passar por aqui!"

    # say L3792 pla
    old "Well... Whatever."
    new "B:pla: Não acredito que tu tenhas realmente feito isso!"

    # say L3793 pla
    old "Don't forget that you have to go to the interview, alright?"
    new "B:pla: Bem... Tanto faz."

    # say L3796 pla
    old "It's alright, no problem."
    new "B:pla: Não te esqueças que tens de ir à entrevista, está bem?"

    # say L3798 pla
    old "I'll see you later so you can tell me how the interview went, alright?"
    new "T: Vou ver-te mais tarde para saberes como correu a entrevista, está bem?"

    # say L3819 pla
    old "Hmm, who could it be?"
    new "B:pla: Vejo-te mais tarde para me contares como correu a entrevista, está bem?"

    # say L3820 pla
    old "I better hurry up and open the door..."
    new "B:pla: Hmm, quem será?"

    # say L3826 pla
    old "Oh, hi Barbie, nice to see you here."
    new "B:pla: Melhor ir abrindo a porta..."

    # say L3829 pla
    old "You did?! That's awesome Barbie!"
    new "B:pla: Olá, Barbie, bom ver-te aqui."

    # say L3830 pla
    old "So I take it the interview went well, right?"
    new "B:pla: Tu fizeste?! Isso é incrível, Barbie!"

    # say L3834 pla
    old "That's great, hey, let's come to my room."
    new "B:pla: Então, a entrevista correu bem, certo?"

    # say L3835 pla
    old "That way you can tell me everything."
    new "B:pla: Ótimo, hey, vamos à minha sala."

    # say L3851 pla
    old "That's so awesome Barbie, congrats!"
    new "B:pla: Assim podes contar-me tudo."

    # say L3885 pla
    old "Well, I'm glad you're happy."
    new "A:pla: Tu vais ainda trabalhar?"

    # say L3888 pla
    old "You're still going to work?"
    new "B:pla: Bem, fico contente que tu estejas feliz."

    # say L3901 bri
    old "Alright! I hear all of that!"
    new "B:pla: Tu vais ainda trabalhar?"

    # say L3902 bri
    old "She's happy, and you accomplished what you wanted."
    new "T(bri|tu|say): Ela está feliz, e tu conseguiste o que querias."

    # say L3903 bri
    old "That means we can get to my thing now, right?"
    new "B:bri: Ela está feliz, e tu conseguiste o que querias."

    # say L3925 pla
    old "Ohh, sure, I'll be downstairs in a minute."
    new "B:mo1: Bem, vês, a Barbie está na sala de estar, à espera de ti para conversar."

    # say L3926 mo1
    old "Ok, by the way. she's pregnant..."
    new "B:pla: Ohh, claro, estarei lá em baixo daqui a um minuto."

    # say L3927 mo1
    old "Do you know anything about that?"
    new "B:mo1: Ok, por acaso. Ela está grávida..."

    # say L3928 pla
    old "Me? No, nothing! I don't know what this is about..."
    new "B:mo1: Sabes alguma coisa sobre isso?"

    # say L3929 pla
    old "But I'll go down and talk to her."
    new "B: pla: Eu? Não, nada! Não sei do que estás a falar..."

    # say L3930 mo1
    old "Okay honey."
    new "B:pla: Mas vou descer e falar com ela."

    # say L3936 pla
    old "B- Barbie! H- hi!"
    new "B:mo1: Tudo bem, querida."

    # say L3937 pla
    old "W- what's happening?"
    new "B: B- Barbie! O- olá!"

    # say L3945 pla
    old "I- I... W- what's this?"
    new "T: I- I... Q- que é isto?"

    # say L3946 pla
    old "Y- you're pregnant!"
    new "B: I- I... Q- que é isto?"

    # say L3954 pla
    old "H- hey, don't worry, we'll figure something out."
    new "B: pla: T-tu estás grávida!"

    # say L3958 pla
    old "I know, I know."
    new "T(pla|tu|say): Eu sei, eu sei."

    # say L3959 pla
    old "But I'm sure everything will be fine."
    new "Mas tenho a certeza de que tudo vai correr bem. E posso prometer-te que estarei aqui para ti, não importa o quê. Tudo bem?"

    # say L3960 pla
    old "And I can promise you that I'll be here for you, no matter what. Alright?"
    new "B:pla: Mas tenho a certeza de que tudo vai correr bem."

    # say L3962 pla
    old "Let's just wait for now, and give ourselves time to think about this."
    new "B:pla: E posso prometer-te que estarei aqui para ti, não importa o quê. Tudo bem?"

    # say L3969 pla
    old "Of course, I understand."
    new "B:pla: Vamos esperar por agora e dar-nos tempo para pensar nisto."

    # say L3971 pla
    old "But before we make any decision let's just make sure that you check with a doctor to see how you're doing."
    new "Mas antes de tomarmos qualquer decisão, certifiquemo-nos de que consultas um médico para veres como estás. Sabes, o teu estado físico."

    # say L3972 pla
    old "You know, you're physical state."
    new "B:pla: Mas antes de tomarmos qualquer decisão, vamos assegurar-nos de que consultas um médico para veres como estás."

    # say L3974 pla
    old "You know, just to make sure everything's fine with you."
    new "B:pla: Tu sabes, o teu estado físico."

    # say L3978 pla
    old "I think it is."
    new "T(pla|tu|say): Acho que sim."

    # say L3979 pla
    old "I know a lot is going through your head right now."
    new "T: Sei que muita coisa está a passar pela tua cabeça neste momento."

    # say L3980 pla
    old "But precisely because of that, I think we shouldn't rush into anything."
    new "B:pla: Eu sei que muito está a passar pela tua cabeça neste momento."

    # say L3986 pla
    old "That's a great idea."
    new "B:pla: Mas precisamente por isso, acho que não devemos nos apressar."

    # say L3987 pla
    old "And keep me informed if you can, I'd like to know how you're doing."
    new "E mantém-me informado, se puderes, gostava de saber como estás."

    # say L4002 bri
    old "Hey [pla], why the long face?"
    new "T(bri|tu|say): Ei [pla], por que a cara comprida?"

    # say L4003 pla
    old "You ask why?!"
    new "T: Tu perguntas porquê?!"

    # say L4004 pla
    old "Barbie just came here, she's pregnant!"
    new "B:pla: Tu perguntas porquê?!"

    # say L4005 pla
    old "I thought you had stopped the spell!"
    new "B:pla: A Barbie acabou de chegar, ela está grávida!"

    # say L4006 bri
    old "Well, I did stop it."
    new "B:pla: Eu pensei que tu tinhas parado o feitiço!"

    # say L4007 bri
    old "But the magic cultivation process had already started."
    new "B:bri: Bem, eu parei."

    # say L4008 bri
    old "You should know by now that when it comes to magic, nothing is ever as simple as 'canceling' a spell."
    new "T(bri|tu|say): Deves saber que, quando se trata de magia, nada é tão simples como \"cancelar\" um feitiço. Não é como se fosse uma questão de apertar um interruptor."

    # say L4009 bri
    old "It's not like flipping a switch."
    new "T(bri|tu|say): Não é como se fosse ligar e desligar uma luz. A energia mágica já está em cultivo dentro dela."

    # say L4011 bri
    old "The magic power is already in cultivation inside of her."
    new "B:bri: Não é como ligar um interruptor."

    # say L4012 bri
    old "Or in human words, she's already pregnant."
    new "B:bri: O poder mágico já está a cultivar-se dentro dela."

    # say L4014 bri
    old "Besides, the magic spell to direct the magic you implanted in her."
    new "B:bri: Ou em palavras humanas, ela já está grávida."

    # say L4015 bri
    old "And said magic developing within her are two different things."
    new "E qual é o ponto de cancelar o feitiço, então?"

    # say L4017 pla
    old "Then what's the point of even canceling the spell?"
    new "B:bri: E a magia que está a desenvolver-se nela são duas coisas diferentes."

    # say L4019 pla
    old "If she's still going to go through with it. We might as well have let her go through with it."
    new "A:bri: Não terminei!"

    # say L4021 bri
    old "I wasn't finished!"
    new "B:pla: Se ela ainda vai continuar com isso. Podíamos muito bem ter deixado que ela continuasse."

    # say L4023 bri
    old "If what you're describing was the case, I wouldn't have done anything."
    new "B:bri: Não terminei!"

    # say L4024 bri
    old "Yes, she's still condensing magic within her."
    new "B:bri: Se fosse como tu dizes, não teria feito nada."

    # say L4026 bri
    old "But that doesn't mean that there's nothing we can do."
    new "B:bri: Sim, ela ainda está condensando magia dentro dela."

    # say L4028 bri
    old "Listen, even though this appears to be a normal human pregnancy, you must keep in mind that magic's involved."
    new "T(bri|tu|say): Ouve, embora isto pareça uma gravidez humana normal, tens de ter em conta que há magia envolvida. Não posso simplesmente fazer desaparecer a gravidez dela, mas posso fazê-la avançar muito mais rápido do que o normal."

    # say L4029 bri
    old "I can't just make her pregnancy go away. But I can make it go a lot faster than it normally would."
    new "T(bri|tu|say): Não posso simplesmente fazer o seu estado desaparecer. Mas posso acelerar bastante o processo."

    # say L4031 pla
    old "W- what? So she'll have a baby soon?!"
    new "B:bri: Não posso simplesmente fazer a gravidez dela desaparecer. Mas posso fazer com que ela avance muito mais rápido do que normalmente aconteceria."

    # say L4032 bri
    old "Hmph, no, she won't."
    new "T(bri|tu|say): Hmph, não, ela não vai."

    # say L4033 pla
    old "Uhh... Alright? I'm a little confused."
    new "B:bri: Hmph, não, ela não vai."

    # say L4034 bri
    old "Well... Magic adheres to the natural laws of your world..."
    new "B:pla: Uhh... Tudo bem? Estou um pouco confuso."

    # say L4035 bri
    old "And that's why, even though it may seem 'pregnant,' what it's actually gestating is magical power..."
    new "B:bri: Bem... A magia segue as leis naturais do teu mundo..."

    # say L4037 pla
    old "Ok, so there is not baby?"
    new "B:bri: E é por isso que, mesmo que possa parecer 'grávida', o que está realmente a gestar é poder mágico..."

    # say L4038 bri
    old "Well, technically, a baby could be born from this process since it's all magical power..."
    new "B:pla: Ok, então não há nenhum bebé?"

    # say L4039 bri
    old "However, that would only happen if we decide that a portion of the magical power she's gestating materializes and develops."
    new "T(bri|tu|say): No entanto, isso só aconteceria se decidíssemos que uma parte do poder mágico que ela está a gestar materializa e desenvolve."

    # say L4040 bri
    old "That way, a portion of the magical power would adapt to the woman's womb..."
    new "B:bri: No entanto, isso só aconteceria se decidíssemos que uma parte do poder mágico que ela está gestando se materializa e desenvolve."

    # say L4041 bri
    old "And, powered by the condensing magical energy, it would develop like a human baby."
    new "B:bri: Dessa forma, uma parte da energia mágica se adaptaria ao útero da mulher..."

    # say L4042 bri
    old "So by the time the magic is fully cultivated they both come out of the body together."
    new "E, alimentado pela energia mágica condensada, iria desenvolver-se como um bebé humano. Quando a magia estiver totalmente cultivada, eles sairão do corpo juntos. Mas, neste caso, as coisas vão ser muito diferentes."

    # say L4044 bri
    old "But in this case things are going to be very different."
    new "Mas neste caso as coisas vão ser muito diferentes. Como vai ser muito mais rápido do que o normal, apenas a magia vai desenvolver-se dentro dela."

    # say L4045 bri
    old "Since it's going to be a lot faster than normal, only the magic will develop inside of her."
    new "B:bri: Mas neste caso as coisas vão ser muito diferentes."

    # say L4046 bri
    old "So by the time she gives birth only the magic will be coming out of her."
    new "B:bri: Como vai ser muito mais rápido do que o normal, só a magia vai desenvolver-se dentro dela."

    # say L4047 pla
    old "Ok, ok... I think I understand."
    new "T: Ok, ok... Acho que percebi. Mas espera! O que vai acontecer quando ela for ao médico? Não vão reparar que há algo estranho a acontecer?"

    # say L4049 pla
    old "But wait! What's going to happen when she goes to the doctor? Won't they realize there's something weird going on?"
    new "A:bri: Eu percebo por que tu penses isso."

    # say L4050 bri
    old "I can see why you would think that."
    new "T(bri|tu|say): Mas em termos humanos, ela ainda está grávida, mesmo que seja só de magia."

    # say L4052 bri
    old "But in human terms, she's still pregnant, even if it's just with magic."
    new "T(bri|tu|dizes): Mas em termos humanos, ela ainda está grávida, mesmo que seja só de magia."

    # say L4054 bri
    old "When she goes to get checked with doctors and such, everything will appear to be normal."
    new "B:bri: Mas em termos humanos, ela ainda está grávida, mesmo que seja apenas de magia."

    # say L4056 bri
    old "So everything should be ok."
    new "T(bri|tu|say): Então tudo deve estar bem."

    # say L4058 pla
    old "Alright, that's good to hear."
    new "T:pla: Tudo bem, isso é bom de ouvir."

    # say L4060 pla
    old "So everything should be okay from here on out, right?"
    new "T(pla|tu|say): Então tudo deve correr bem daqui em diante, certo?"

    # say L4062 bri
    old "Hmm, not entirely."
    new "T(bri|tu|say): Hmm, não totalmente."

    # say L4063 pla
    old "R- really?"
    new "T: R- realmente?"

    # say L4064 pla
    old "Is there something else?"
    new "B:pla: R- realmente?"

    # say L4066 bri
    old "Well, what we're doing with this spell is trying to condense the magic energy needed to power up the portal to the magic world."
    new "E estamos a fazê-lo condensando magia dentro dos corpos das mulheres."

    # say L4067 bri
    old "And we're doing it by condensing magic within the bodies of women."
    new "B:bri: Bem, o que estamos a fazer com este feitiço é tentar condensar a energia mágica necessária para ativar o portal para o mundo mágico."

    # say L4068 pla
    old "Yeah, I get that."
    new "A:bri: Bem, a questão é que estas mulheres não são manipuladoras de magia naturais."

    # say L4070 bri
    old "Well, the thing is that these women aren't natural magic wielders."
    new "B:pla: Claro, percebo isso."

    # say L4071 bri
    old "Their bodies aren't able to condense magic at the same rate that the spell demands it."
    new "B:bri: Ora, a questão é que estas mulheres não são magas naturais."

    # say L4073 bri
    old "They would need your help with providing the magic they can't procure for themselves."
    new "Então, em circunstâncias normais, Barbie precisaria da tua ajuda para lhe dar magia."

    # say L4075 bri
    old "So, under normal circumstances, Barbie would need you to help her by giving her magic."
    new "B:bri: Eles precisariam da tua ajuda para fornecer a magia que não conseguem obter por si mesmos."

    # say L4076 bri
    old "But since this pregnancy will be so short, I don't think she'll need you to give her any condensed magic power."
    new "T(bri|tu|say): Mas como esta gravidez será tão curta, acho que ela não vai precisar que tu lhe dês poder mágico condensado."

    # say L4078 pla
    old "How would that work? The giving her magic part?"
    new "B:bri: Mas como esta gravidez será tão curta, não acho que ela precise que lhe dês poder mágico condensado."

    # say L4080 bri
    old "Oh, you know full well how that works, the same way you do it for me."
    new "T(bri|tu|say): Oh, tu sabes muito bem como isso funciona, da mesma maneira que tu fazes para mim."

    # say L4081 pla
    old "I- I see..."
    new "B:bri: Oh, tu sabes muito bem como isso funciona, da mesma maneira que tu fazes para mim."

    # say L4083 bri
    old "But as I explained to you, given her particular conditions I can't be sure about what's about to happen with her."
    new "B:pla: I- I vejo..."

    # say L4084 bri
    old "So just be sure to be vigilant about what can happen to her. Just to make that she's fine."
    new "B:bri: Mas como te expliquei, dadas as suas condições particulares, não posso ter a certeza do que vai acontecer com ela."

    # say L4086 pla
    old "I understand, alright, I'll be sure to do that."
    new "B: bri: Então, só tenha cuidado com o que pode acontecer com ela. Só para garantir que ela esteja bem."

    # say L4087 pla
    old "But thanks anyway Brixxida, this gives me some peace of mind."
    new "B:pla: Entendo, tudo bem, vou fazer isso."

    # say L4088 bri
    old "Well, I'm just letting you know what happened."
    new "B:pla: Mas obrigado de qualquer forma, Brixxida, isto dá-me alguma tranquilidade."

    # say L4090 bri
    old "But don't forget that now you have to keep going with our plans."
    new "B:bri: Bem, estou só a avisar o que aconteceu."

    # say L4091 bri
    old "I'm letting you off the hook with this one, but be sure to keep searching the next specimen."
    new "B:bri: Mas não te esqueças que agora tens de continuar com os nossos planos."

    # say L4092 pla
    old "Yeah, alright."
    new "B:bri: Estou a deixar-te passar desta vez, mas certifica-te de continuar a procurar o próximo espécime."

    # say L4122 pla
    old "Oh, Barbie, hi!"
    new "T(pla|tu|say): Oh, Barbie, olá!"

    # say L4125 pla
    old "Hi, how are you?"
    new "B:pla: Olá, Barbie, olá!"

    # say L4126 pla
    old "Is everything alright?"
    new "B:pla: Olá, como estás?"

    # say L4132 pla
    old "Uhmm... Are you alright?"
    new "B: pla: Tudo bem?"

    # say L4134 pla
    old "Did you go to the doctor? Is everything okay?"
    new "T(pla|tu|say): Foste ao médico? Tudo bem?"

    # say L4137 pla
    old "Are you sure?"
    new "B:pla: Foste ao médico? Tudo bem?"

    # say L4141 pla
    old "Uhm... Sure, I don't see why not."
    new "B:pla: Tens a certeza?"

    # say L4142 pla
    old "Let's go to my bedroom and we'll talk there."
    new "B: pla: Hum... Claro, não vejo porque não."

    # say L4148 pla
    old "Alright, do you want to tell me what's going on?"
    new "B:pla: Vamos para o meu quarto e falamos lá."

    # say L4149 pla
    old "Because I can tell that something's not right."
    new "B:pla: Tudo bem, tu queres contar-me o que se passa?"

    # say L4158 pla
    old "So what's the problem?"
    new "B:pla: Porque consigo perceber que algo não está bem."

    # say L4162 pla
    old "Fatigue? Like you're tired?"
    new "T: Cansaço? Como se estivesses cansado?"

    # say L4168 pla
    old "How do you know that?"
    new "T: Como é que tu sabes isso?"

    # say L4177 pla
    old "Hot?"
    new "B:pla: Como é que sabes isso?"

    # say L4187 bri
    old "This is it [pla]! This is what I told you about!"
    new "T(bri|tu|say): Isto é [pla]! Isto é o que te falei!"

    # say L4189 bri
    old "And the feeling of being {i}'horny'{/i} is her body telling her what she has to do to solve it."
    new "T(bri|tu|say): E a sensação de estar {i}'excitada'{/i} é o corpo dela a dizer-lhe o que tem de fazer para resolver isso."

    # say L4191 bri
    old "But what you have to do now is have sex with her so that she can feed off your magic!"
    new "B:bri: Não estava à espera que as coisas fossem assim, já que o feitiço foi cancelado e tudo mais."

    # say L4195 pla
    old "W- what? N- no, of course not."
    new "B:bri: Mas o que tens de fazer agora é ter sexo com ela para que ela possa alimentar-se da tua magia!"

    # say L4197 pla
    old "Why would I think that there's anything weird about it?"
    new "B:pla: O- o quê? N- não, claro que não."

    # say L4199 pla
    old "I think that's very normal."
    new "B:pla: Porque é que eu pensaria que há algo de estranho nisso?"

    # say L4200 pla
    old "After all, you're pregnant, I think it's pretty normal that you would have those feelings."
    new "T: Afinal, estás grávida, acho normal que tenhas esses sentimentos."

    # say L4203 pla
    old "What's wrong?"
    new "B:pla: Afinal, tu estás grávida, acho que é normal teres esses sentimentos."

    # say L4213 pla
    old "Ohh, come on, what are you talking about?"
    new "B:pla: O que se passa?"

    # say L4215 pla
    old "Yeah, it's true that you don't look like you usually do."
    new "B:pla: Ohh, vamos, do que estás a falar?"

    # say L4216 pla
    old "But that doesn't mean you look bad in any way."
    new "B:pla: É verdade que não pareces como costumas fazer."

    # say L4218 pla
    old "I mean, you look just as sexy as you always have."
    new "B:pla: Mas isso não significa que tu fiques mal de alguma forma."

    # say L4221 pla
    old "Of course I would!"
    new "B:pla: Quero dizer, tu pareces tão sexy como sempre."

    # say L4222 pla
    old "I'm surprised that you even feel like you'd have to ask me."
    new "T: Fico surpreendido que sequer sintas necessidade de me perguntar isso."

    # say L4223 pla
    old "You look just as beautiful as you always have."
    new "B:pla: Fico surpreendido que sequer sintas que precisas de me perguntar."

    # say L4224 pla
    old "And I'll be more than happy to help you feel better."
    new "B: Tu pareces tão bonita como sempre."

    # say L4229 pla
    old "Come on, don't say that."
    new "B:pla: E ficarei mais do que feliz em ajudar-te a sentires-te melhor."

    # say L4230 pla
    old "You're just as beautiful as always."
    new "B: Vamos, não digas isso."

    # say L4231 pla
    old "Let me show you."
    new "B: Tu és tão bonita como sempre."

    # say L4257 pla
    old "I'm glad to be able to help you."
    new "B:pla: Deixa-me mostrar-te."

    # say L4258 pla
    old "After all, you didn't get into this situation by yourself."
    new "B:pla: Fico contente por poder ajudar-te."

    # say L4259 pla
    old "I figure this is the least that I can do."
    new "B:pla: Afinal, não foste tu sozinho que criaste esta situação."

    # say L4260 pla
    old "I'm glad it actually works."
    new "B:pla: Acho que isto é o mínimo que posso fazer."

    # say L4267 pla
    old "Sure, I'll be seeing you later."
    new "B:pla: Fico contente que funcione afinal."

    # say L4277 pla
    old "Hmm, I guess that if she's going to be alright with just that, then that's fine."
    new "T(tu|diz): Hmm, acho que se ela ficar bem com só isso, então está tudo bem."

    # say L4278 bri
    old "She will be. Don't worry, I'm sure that that's more than enough."
    new "T(bri|tu|say): Vai correr bem. Não te preocupes, tenho a certeza de que isso é mais do que suficiente. A:bri: O que é ótimo, porque agora podes focar-te no que vem a seguir."

    # say L4279 bri
    old "Which is great, because now you  can focus on what's next."
    new "B:bri: Ela vai ser. Não te preocupes, tenho a certeza de que é mais do que o suficiente."

    # say L4281 pla
    old "However, this time I'll choose. We were lucky this time, but really 'impregnating' someone is not easy at all..."
    new "T(pla|tu|say): No entanto, desta vez eu escolho. Tivemos sorte desta vez, mas realmente 'impregnar' alguém não é nada fácil..."

    # say L4283 bri
    old "Alright... But you can't take too long; we need to keep incubating more magical power for the portal..."
    new "B:pla: No entanto, desta vez eu escolho. Tivemos sorte desta vez, mas realmente 'impregnar' alguém não é nada fácil..."

    # say L4285 bri
    old "Anyway, I'm gonna rest, I spend too much magic power with Barbie..."
    new "B:bri: Tudo bem... Mas não podes demorar muito; precisamos de continuar a incubar mais poder mágico para o portal..."

    # say L4286 pla
    old "Ok, see you later."
    new "T(pla|tu|say): Ok, vejo-te mais tarde."


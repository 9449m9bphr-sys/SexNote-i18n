# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Building.rpy
translate portuguese strings:

    # say L96 pla
    old "Uhh... Yes..."
    new "Ohh, tudo bem, não te preocupes, vou amanhã. Obrigado."

    # say L99 pla
    old "Ohh, alright, don't worry I will come tomorrow. Thank you."
    new "B:pla: Uhh... Sim..."

    # say L132 pla
    old "Good morning Barbie..."
    new "B:pla: Ohh, tudo bem, não te preocupes, vou amanhã. Obrigado."

    # say L141 pla
    old "Good afternoon Barbie..."
    new "B:pla: Bom dia, Barbie..."

    # say L155 pla
    old "Hmmm, actually is for a friend of mine, but thanks that's all that I needed it."
    new "B:pla: Que fixe, posso ir falar com ela?"

    # say L160 pla
    old "Thank you..."
    new "B:pla: Hmmm, na verdade é para um amigo meu, mas obrigado, era tudo o que precisava."

    # say L164 pla
    old "Now I can talk with Mrs. Jade."
    new "B:pla: Obrigado..."

    # say L196 pla
    old "I was wondering if Dr. Johnson is in her office."
    new "B:pla: Agora posso falar com a Sra. Jade."

    # say L200 pla
    old "Great, thanks"
    new "B:pla: Estava a pensar se a Dra. Johnson está no consultório."

    # say L219 joh
    old "Don't worry if you need anything just let me know."
    new "B:pla: Oh, não, desculpa, eu só-"

    # say L220 pla
    old "Ok, Thanks."
    new "T: Ok, obrigado."

    # say L248 pla
    old "No, no, sorry I was just looking for Hinn. I have to go."
    new "B:pla: Ok, obrigado."

    # say L257 joh
    old "That's great! So, what lesson you want to practice?"
    new "B:pla: Olá doutor Johnson, estou aqui porque mencionaste que poderíamos repetir algumas lições..."

    # menu L262 
    old "Lesson 1"
    new "B:joh: Ótimo! Então, qual lição tu queres praticar?"

    # say L264 joh
    old "Great choice. Let's go to the  practice room..."
    new "Ótima escolha. Vamos para a sala de prática... Mantém assim, tenta mantê-lo húmido e move-te um pouco mais rápido..."

    # say L277 joh
    old "Just like that, try to keep it wet, and slowly move a bit faster..."
    new "B:joh: Ótima escolha. Vamos para a sala de prática..."

    # say L278 joh
    old "Keep doing it like that... Ahh"
    new "B:joh: Assim, tenta mantê-lo molhado e move-te um pouco mais rápido..."

    # say L279 pla
    old "O- ok"
    new "Aula 2"

    # menu L283 
    old "Lesson 2"
    new "Vamos fazer isso!"

    # say L305 joh
    old "Let's do it!"
    new "B:n: Lição 2"

    # menu L314 
    old "Lesson 3"
    new "Vamos fazer isso!"

    # menu L332 
    old "Lesson 4"
    new "Fizeste muito bem, estou contente por te ter aqui de novo..."

    # say L358 joh
    old "You did it wonderful, I'm glad to have you here again..."
    new "B:n: Lição 4"

    # say L359 pla
    old "Definitely, I will pass by more often."
    new "B:joh: Fizeste maravilhosamente, estou feliz por te ter de volta..."

    # say L360 joh
    old "It would be the best thing to do, we can enjoy a lot."
    new "B:pla: Com certeza, passarei mais vezes."

    # say L361 pla
    old "I don't doubt it."
    new "T(pla|tu|say): Não tenho dúvidas."

    # say L362 joh
    old "Hope to see you soon."
    new "B:pla: Não tenho dúvidas."

    # say L363 pla
    old "Thank you, have a great day."
    new "B:joh: Espero ver-te em breve."

    # say L364 joh
    old "Bye bye!"
    new "Adeus!"


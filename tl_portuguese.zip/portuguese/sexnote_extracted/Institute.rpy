# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Institute.rpy
translate portuguese strings:

    # say L15 pla
    old "I should go to the garage to talk with Brixxida first."
    new "Deverias ir à oficina falar com a Brixxida primeiro."

    # say L53 hin
    old "Well, she is in the classroom right now. You should go and show her."
    new "B:pla: Devo ir à oficina falar com a Brixxida primeiro."

    # say L55 pla
    old "Ok. Doing it now."
    new "B:hin: Bem, ela está na sala de aula neste momento. Deves ir mostrar-lhe."

    # say L174 pla
    old "Nothing much, it’s just that I haven’t seen you when I’ve gone to your home to do the repairs on the bathroom."
    new "Não há nada, é só que não te tenho visto quando tenho ido a tua casa fazer os reparos na casa de banho."

    # say L175 hin
    old "Yeah, I’m sorry about that."
    new "B:pla: Não tem sido nada, é só que não te tenho visto quando vou a tua casa fazer os reparos na casa de banho."

    # say L176 hin
    old "This whole extracurricular work has been keeping me busy."
    new "T(hin|tu|dizer): Este trabalho extra tem-me mantido ocupado."

    # say L177 hin
    old "But it’s supposed to count for extra credit for college, so, I guess that’s alright."
    new "B:hin: Este trabalho extracurricular tem-me mantido ocupado."

    # say L178 pla
    old "Of course, of course, I totally get it."
    new "T(pla|tu|say): Claro, claro, percebo perfeitamente."

    # say L179 hin
    old "I’ll make it up to you once I’m done with all of this."
    new "B:pla: Claro, claro, percebo perfeitamente."

    # say L180 hin
    old "We’ll also have some time to ourselves once you’re done with the bathroom."
    new "B:hin: Compensarei-te quando acabar com tudo isto."

    # say L181 pla
    old "Yeah, I guess I better hurry to finish with that. The sooner the better."
    new "B:hin: Também teremos algum tempo só para nós depois que terminares no banheiro."

    # say L182 hin
    old "It’s very kind of you to do that for us."
    new "B:pla: Sim, acho melhor terminar com isso. Quanto antes, melhor."

    # say L183 pla
    old "No problem, it’s rather easy."
    new "T(pla|tu|say): Não há problema, é bastante fácil."

    # say L184 pla
    old "By the way, I think I’ll go work on that right now."
    new "B:pla: Sem problema, é bastante fácil."

    # say L185 pla
    old "See you later Hinn."
    new "B:pla: Por acaso, acho que vou trabalhar nisso já agora."

    # say L187 hin
    old "Sure, see you later."
    new "Olá, Hinn."

    # say L203 pla
    old "Hey, Hinn"
    new "B:hin: Claro, até mais tarde."

    # say L207 pla
    old "Do you have a therapy appointment today with Dr. Johnson?"
    new "B:pla: Hey, Hinn"

    # say L209 hin
    old "No, actually I think we should work on the class project today."
    new "B:pla: Tens consulta de terapia hoje com o Dr. Johnson?"

    # say L211 pla
    old "You are right, we have work to do."
    new "B:hin: Não, na verdade acho que devemos trabalhar no projeto da turma hoje."

    # say L213 hin
    old "If we make a good progress I could set an appointment for tomorrow."
    new "B:pla: Tens razão, temos trabalho a fazer."

    # say L215 pla
    old "Always that responsible. That sounds good to me."
    new "B:hin: Se fizermos bons progressos, posso marcar um encontro para amanhã."

    # say L218 hin
    old "Hehehe... Great, see you in my house."
    new "B:pla: Sempre tão responsável. Isso soa bem para mim."

    # say L220 pla
    old "Perfect. See you then."
    new "B:hin: Hehehe... Ótimo, vejo-te em minha casa."

    # say L252 pla
    old "Hi Bell."
    new "A:bel: Já começaste a trabalhar no teu projeto?"

    # say L254 bel
    old "Did you start to work on your project?"
    new "B:pla: Olá Bell."

    # say L256 pla
    old "Well, I talked to Hinn, I think we're going to start this afternoon..."
    new "B:bel: Começaste a trabalhar no teu projeto?"

    # say L258 bel
    old "Lucky you, I got paired with that asshole Mike this time. I don't know how everything is going to work out..."
    new "B:pla: Bem, falei com Hinn, acho que vamos começar esta tarde..."

    # say L260 pla
    old "Don't worry, Mike is good whenever he tries."
    new "B:bel: Que sorte a tua, desta vez fiquei emparelhada com aquele sacana do Mike. Não sei como vai ser..."

    # say L262 bel
    old "Hmm... I sure hope so..."
    new "B:pla: Não te preocupes, o Mike é bom sempre que tenta."

    # say L264 pla
    old "Ok... Bell, I have to go to meet with Hinn. Bye."
    new "B:bel: Hmm... Espero que sim..."

    # say L274 bel
    old "Hey, [pla]! How did it go with your project?"
    new "B:bel: Até mais, [pla]..."

    # say L278 bel
    old "Hmm... Right, Hinn is a pretty nerd... Mine is an ugly asshole..."
    new "B:pla: Na verdade, ótimo! A Hinn é bastante boa e ensinou-me muito..."

    # say L280 pla
    old "It can't be that bad ..."
    new "B:bel: Hmm... Pois, Hinn é um verdadeiro nerd... O meu é um sacana feio..."

    # say L282 bel
    old "It can't be that bad?... We went to my house to study and he tried to look in my underwear drawer... Three times!"
    new "B:pla: Não pode ser assim tão mau..."

    # say L284 pla
    old "Really?... Uhh weird..."
    new "B:bel: Não pode ser assim tão mau?... Fomos à minha casa estudar e ele tentou espreitar na minha gaveta de roupa interior... Três vezes!"

    # say L286 bel
    old "Tell me about it... I have to do everything by myself."
    new "B:pla: Mesmo?... Hum, estranho..."

    # say L288 pla
    old "Too bad... Fortunately, you are smart and you can actually do it alone. I really couldn't without help."
    new "B:bel: Conta-me tudo... Tenho de fazer tudo sozinha."

    # say L290 bel
    old "... Seriously, every time I see Mike, I just want to kill him..."
    new "B:pla: Que pena... Afortunadamente, tu és inteligente e podes fazer isso sozinho. Eu realmente não conseguiria sem ajuda."

    # say L292 pla
    old "Damn... Well, Bell, I have to go. I will see you later..."
    new "B:bel:... A sério, cada vez que vejo o Mike, só me apetece matá-lo..."

    # say L297 bel
    old "Hey, [pla]! How's it going?"
    new "B:bel: Até mais, [pla]!"

    # say L300 pla
    old "A little busy with school work and stuff, you know."
    new "B:pla: Olá Belle, estou ótimo!"

    # say L302 bel
    old "Yeah, I get it."
    new "A:pla: E tu, como vais?"

    # say L303 pla
    old "How about you?"
    new "B:bel: Entendo."

    # say L305 bel
    old "Well, I guess I'm ok."
    new "B: pla: E tu?"

    # say L307 bel
    old "Lately my mom has been a little intense."
    new "B:bel: Bem, acho que estou bem."

    # say L308 bel
    old "She's always coming and going from home."
    new "E cada vez que está em casa, quer ver-me ou falar comigo."

    # say L310 bel
    old "And every time she's home she wants to see me or talk to me "
    new "B:bel: Ela está sempre a chegar e a sair de casa."

    # say L312 pla
    old "Hmm... I can imagine how annoying it must be."
    new "B:bel: E cada vez que ela está em casa quer ver-me ou falar comigo."

    # say L314 bel
    old "I guess I'll have to deal with it."
    new "A:bel: Ela tem lidado com muito por causa do trabalho."

    # say L315 bel
    old "She's been handling a lot because of her job."
    new "B:bel: Acho que terei de lidar com isso."

    # say L316 bel
    old "So, I guess that when the whole thing is over she'll be right back to normal."
    new "B:bel: Ela tem lidado com muito por causa do trabalho."

    # say L317 pla
    old "Yeah, I'm sure she will."
    new "B:bel: Então, acho que quando tudo isto acabar ela voltará ao normal."

    # say L318 pla
    old "Hey, I have to run, but I'll see you later."
    new "T(pla|tu|say): Olá, tenho de ir, mas vejo-te mais tarde."

    # say L320 bel
    old "Sure, see you."
    new "A:pla: Olá Belle, bom dia."

    # say L323 pla
    old "Hi Belle, good morning."
    new "B:bel: Claro, até logo."

    # say L327 pla
    old "I'm ok, how are you doing?"
    new "B:bel: Como estás?"

    # say L329 bel
    old "Well, I'm fine I think."
    new "B:pla: Estou bem, como estás tu?"

    # say L330 bel
    old "The situation has been tense with my mom since our fight."
    new "B:bel: Bem, acho que estou bem."

    # say L332 bel
    old "So we're not actually talking right now."
    new "B:bel: A situação tem estado tensa com a minha mãe desde a nossa discussão."

    # say L334 bel
    old "But other than that I'm doing well."
    new "B:bel: Então, na verdade, não estamos a falar neste momento."

    # say L335 bel
    old "Since I moved with Amorette, and I've been able to work from her home."
    new "Mas nesse aspecto, tudo está bem."

    # say L337 bel
    old "So on that end, everything's fine."
    new "T(bel|tu|say): Então, nesse aspecto, tudo está bem."

    # say L339 pla
    old "Ok, I see, well, I guess that's fine."
    new "B:bel: Então, nesse aspecto, tudo está bem."

    # say L340 pla
    old "As long as you're ok, I suppose everything's alright."
    new "Tudo bem, desde que tu estejas bem, suponho que tudo está bem."

    # say L342 bel
    old "Yeah."
    new "A:pla: Tudo bem, foi bom ver-te. Até mais, Belle."

    # say L343 pla
    old "Alright, it was nice to see you. See you later, Belle."
    new "T(pla|tu|say): Tudo bem, foi bom ver-te. Até mais, Belle."

    # say L406 mia
    old "Is it ready? Do you have any progress to show?"
    new "A:mia: Uau, não posso acreditar. Vocês conseguiram..."

    # say L416 mia
    old "Wow, I can't believe it. You guys did it..."
    new "B:mia: Está pronto? Tens algum progresso para mostrar?"

    # say L418 pla
    old "And... How was it?"
    new "B:mia: Uau, não posso acreditar. Vocês conseguiram..."

    # say L420 mia
    old "Your project is... Good... I guess..."
    new "B:pla: E... Como foi?"

    # say L435 mia
    old "You have completed a lot. I have to say I am surprised..."
    new "B:mia: O teu projeto está... Bom... Acho eu..."

    # say L441 mia
    old "Don't get too excited. You still have a lot of work to do before it is done."
    new "B:pla: Obrigado!"

    # say L457 mia
    old "I can't believe you did something of this... I need to talk with your partner, tell her to come and talk with me... ALONE!"
    new "B:mia: Não te excites demasiado. Ainda tens muito trabalho a fazer antes de terminar."

    # say L459 pla
    old "Hmm... Ok... I will tell her..."
    new "B:mia: Não posso acreditar que tenhas feito algo assim... Preciso de falar com a tua parceira, diz-lhe para vir falar comigo... SOZINHA!"

    # say L474 mia
    old "Ok, now this is getting really suspicious..."
    new "A:mia: De qualquer forma, estou ocupada demais para me preocupar contigo..."

    # say L478 mia
    old "Anyway, I'm busy to worry about you..."
    new "B:mia: Ok, agora isto está a ficar mesmo suspeito..."

    # say L480 pla
    old "Hmmm ok."
    new "B:mia: De qualquer forma, estou ocupada para me preocupar contigo..."

    # say L494 mia
    old "Oh? Have you made more progress? Is your partner doing everything?"
    new "B:pla: Hmmm ok."

    # say L496 pla
    old "What?! Of course not! This is all team work."
    new "B:mia: Oh? Fizeste mais progresso? O teu parceiro está a fazer tudo?"

    # say L498 mia
    old "Hmm... You haven't screwed it up yet. I will keep waiting."
    new "B:pla: Que?! Claro que não! Isto é trabalho de equipa."

    # say L511 mia
    old "Oh, you have started... But you still have a lot of work to do before you are done..."
    new "B:mia: Hmm... Ainda não estragaste nada. Vou continuar à espera."

    # say L513 pla
    old "But?... How is it?"
    new "B:mia: Oh, já começaste... Mas ainda tens muito trabalho para fazer antes de terminares..."

    # say L515 mia
    old "For now, it's ok. But I'm sure you will screw it up, sooner or later."
    new "B:pla: Mas?... Como é que está?"

    # say L526 mia
    old "As I thought... then don't bother me. Talk to me when you've made some progress... if you even can, of course..."
    new "B:mia: Por agora, está bem. Mas tenho a certeza de que vais estragar tudo, mais cedo ou mais tarde."

    # say L537 mia
    old "Yeah, yeah congratulations, your project was good, are you happy?"
    new "B:mia: Como eu pensei... então não me incomodes. Fala comigo quando tiveres feito algum progresso... se é que consegues, claro..."

    # say L539 pla
    old "Thanks! see you!..."
    new "B:mia: Sim, sim, parabéns, o teu projeto foi bom, estás feliz?"

    # say L595 pla
    old "... Uhhh sure."
    new "B:luc: Senta-te."

    # say L755 mia
    old "Well, ladies and gentlemen. Please remember the final project you have to do..."
    new "B:pla:... Uhhh, claro."

    # say L757 pla
    old "(Hmm... The final project... one of the hardest and boringest things ever!)"
    new "B:mia: Bem, senhoras e senhores. Por favor, lembrem-se do projeto final que têm de fazer..."

    # say L758 pla
    old "(I mean, research? Bibliographies? Theoretical framework?... All that work on stuff I'll never use...)"
    new "B:pla: (Hmm... O projeto final... uma das coisas mais difíceis e entediantes de sempre!)"

    # say L764 pla
    old "(I really want to graduate and be free from all of this crap…)"
    new "B: (Quero mesmo acabar a licenciatura e ficar livre de toda esta porcaria…)"

    # say L773 pla
    old "Where did it fall from?... An airplane?"
    new "B:pla: (Quero mesmo acabar a escola e ficar livre de toda esta porcaria...)"

    # say L777 pla
    old "Sorry, Mrs. Mia. I'm listening. I was just... looking through the window..."
    new "B:pla: De onde é que caiu?... De um avião?"

    # say L778 mia
    old "Oh really? Then please tell us all the project requirements that I just explained..."
    new "B:pla: Desculpe, Sra. Mia. Estou a ouvir. Estava só... a olhar pela janela..."

    # say L789 pla
    old "Ughh... Finally free!..."
    new "B:mia: Oh really? Então, por favor, conta-nos todos os requisitos do projeto que acabei de explicar..."

    # say L802 bel
    old "You wasn't paying attention, huh?"
    new "T(bel|tu|say): Tu não estavas a prestar atenção, hã?"

    # say L804 pla
    old "What?... What you mean?"
    new "B:bel: Tu não estavas a prestar atenção, hã?"

    # say L806 bel
    old "This project is for couples and your partner is Hinn."
    new "B:pla: O quê?... O que queres dizer?"

    # say L808 pla
    old "Really? OK, thanks anyway."
    new "B:bel: Este projeto é para casais e o teu parceiro é Hinn."

    # say L813 mik
    old "Heyyy guys! Did you notice  Mia`s neckline, every day she gets hotter and hotter."
    new "B:pla: Mesmo? OK, obrigado de qualquer forma."

    # say L816 bel
    old "Really Mike? She could be your mother ... "
    new "B:mik: Ei, pessoal! Repararam na decote da Mia? Todos os dias ela fica mais gira."

    # say L822 bel
    old "Well, I'm leaving. I have things to do. And I don't want to stay here and keep listening to Mike's perversions."
    new "B:pla: Só sei que ela me odeia e cada dia fica pior. Só espero estar vivo no final do ano letivo."

    # say L824 pla
    old "Bye, Belle. See you around."
    new "B:bel: Bem, eu vou-me embora. Tenho coisas para fazer. E não quero ficar aqui a ouvir as perversiones do Mike."

    # say L831 mik
    old "Have you noticed how hot Belle is gettin'?"
    new "B:pla: Adeus, Belle. Até à vista."

    # say L833 pla
    old "Dude... Damn, you should calm down a little."
    new "T: Cara... Puta merda, devias acalmar-te um bocado."

    # say L835 mik
    old "Why? Are you gay or something?"
    new "B:pla: Cara... Puta merda, devias acalmar-te um bocado."

    # say L837 pla
    old "Bye, Mike. I'll talk to you later"
    new "T(pla|tu|say): Adeus, Mike. Falo contigo mais tarde."

    # say L839 mik
    old "So I'm right, huh? But she is hot, isn't she?"
    new "Espera... Isto é...?"

    # say L856 pla
    old "Wait... Is this...?"
    new "T(pla|tu|say): Espera... Isto é...?"

    # say L858 pla
    old "The book that fell from the sky?"
    new "B:pla: Espera... Isto é...?"

    # say L860 pla
    old "SexNote?  What could it be about?"
    new "B:pla: O livro que caiu do céu?"

    # say L862 pla
    old "Weeeell, finders-keepers. Hehe."
    new "B:pla: SexNote? Do que será que se trata?"

    # say L864 pla
    old "Maybe I can think of something interesting to draw in it."
    new "B:pla: Weeeell, finders-keepers. Hehe."

    # say L883 mik
    old "Hey, wait! Before you go... I have something to show you that will surely blow your mind."
    new "T(mik|tu|say): Ei, espera! Antes de ires... Tenho algo para te mostrar que com certeza vai deixar-te de queixo caído."

    # say L885 pla
    old "Now what weird thing do you have in mind?"
    new "B:mik: Ei, espera! Antes de ires... Tenho algo para te mostrar que com certeza vai deixar-te de queixo caído."

    # say L887 mik
    old "Listen... Just go to my house and look for me in my room. I'll show you."
    new "B:pla: Agora que coisa estranha tens em mente?"

    # say L889 pla
    old "Hmm, alright... I will see you then."
    new "B:mik: Escuta... Vai à minha casa e procura-me no meu quarto. Vou mostrar-te."

    # say L908 pla
    old "I shouldn't enter. This isn't my classroom."
    new "Não devo entrar. Isto não é a minha sala de aula."


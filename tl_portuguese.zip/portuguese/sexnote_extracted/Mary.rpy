# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mary.rpy
translate portuguese strings:

    # say L47 mar
    old "Don't worry, boy. I'm here to take care of your health. As many times as you need... Come on, get on the table."
    new "B:pla: Bem... Sim... Tu disseste-me isso."

    # say L60 pla
    old "Oh, no, I was just leaving. I'm sorry ..."
    new "B:mar: Não te preocupes, rapaz. Estou aqui para cuidar da tua saúde. Tantas vezes quantas precisares... Vamos, sobe para a mesa."

    # say L62 mar
    old "Okay, if you need a checkup again, you know where to find me..."
    new "B:pla: Oh, não, eu estava a sair. Desculpa..."

    # say L64 pla
    old "Ok, thank you..."
    new "B:mar: Okay, se precisares de uma consulta novamente, sabes onde me encontrar..."

    # say L117 mo1
    old "Hello, Nurse Mary. Good morning."
    new "B:pla: Ok, obrigado..."

    # say L120 mar
    old "Good morning! How are you today?"
    new "B:mo1: Olá, Enfermeira Mary. Bom dia."

    # say L122 mo1
    old "Very well, thank you..."
    new "B:mar: Bom dia! Como estás hoje?"

    # say L124 mar
    old "And what about you, boy?"
    new "B:mo1: Muito bem, obrigado..."

    # say L126 pla
    old "I'm fine, too. Thank you..."
    new "B:mar: E tu, rapaz?"

    # say L128 mar
    old "He's very quiet, huhm?"
    new "B:pla: Estou bem, também. Obrigado..."

    # say L130 mo1
    old "He's a bit shy..."
    new "B:mar: Ele é muito calado, hã?"

    # say L133 mar
    old "Haha... Well, let's get to the matter at hand... First, take off your clothes."
    new "B:mo1: Ele é um pouco tímido..."

    # say L139 mar
    old "Ok... Ok... I really don't feel much... I think I'm going to need a second opinion..."
    new "B:mar: Haha... Bem, vamos ao que interessa... Primeiro, tira a roupa."

    # say L140 mo1
    old "Another practitioner?"
    new "B:mar: Ok... Ok... Não sinto grande coisa... Acho que vou precisar de uma segunda opinião..."

    # say L141 mar
    old "Oh, no. That's not necessary... You! Boy. Come here..."
    new "B:mo1: Outro praticante?"

    # say L143 pla
    old "...I... But I..."
    new "B:mar: Oh, não. Isso não é necessário... Tu! Rapaz. Vem aqui..."

    # say L147 mar
    old "I know very well that you saw the massage I was giving her... Because you did not take your eyes off of her..."
    new "T(mar|tu|say): Eu sei muito bem que viste a massagem que estava a dar-lhe... Porque não tiraste os olhos dela..."

    # say L149 pla
    old "I... I... Wasn't-"
    new "B:mar: Eu sei muito bem que viste a massagem que lhe estava a dar... Porque não tiraste os olhos dela..."

    # say L150 mar
    old "The idea is to do the same thing I'm doing, but you do it this time, alright?"
    new "B:pla: I... I... Não estava-"

    # say L152 pla
    old "Oh, ok, I will try..."
    new "A:mo1: Mas, enfermeira, é normal que-"

    # say L153 mo1
    old "But, nurse, is it okay that-"
    new "B:pla: Oh, ok, vou tentar..."

    # say L154 mar
    old "Don't worry, I know what I'm doing, ok?"
    new "B:mo1: Mas, enfermeira, está bem que-"

    # say L155 mo1
    old "Yes, Nurse Mary..."
    new "B:mar: Não te preocupes, sei o que estou a fazer, ok?"

    # say L162 mar
    old "Let's see... put your hands here, cover her breasts well..."
    new "B:mo1: Sim, Enfermeira Mary..."

    # say L163 mar
    old "Very well..."
    new "B:mar: Vamos ver... põe as tuas mãos aqui, cobre bem os seios dela..."

    # say L164 mar
    old "Now... Start massaging them gently..."
    new "B:mar: Muito bem..."

    # say L165 pla
    old "(Oh shit!)... Uhh... But..."
    new "B:mar: Agora... Começa a massageá-los suavemente..."

    # say L166 mar
    old "You already have your hands on, just move them a little, kid..."
    new "B:pla: (Oh shit!)... Uhh... Mas..."

    # say L170 mar
    old "How do they feel, huh?"
    new "B:mar: Tu já tens as mãos em cima, só mexe-as um pouco, miúdo..."

    # say L171 pla
    old "Hmm... Very soft... Warm..."
    new "B:mar: Como se sentem, hã?"

    # say L172 mar
    old "Very well... Now, rub a little harder, focus on sensing if you feel anything strange..."
    new "B:pla: Hmm... Muito macio... Quente..."

    # say L176 pla
    old "Well... I really don't feel anything..."
    new "B:mar: Muito bem... Agora, esfrega um pouco mais forte, concentra-te em sentir se notas algo estranho..."

    # say L177 mar
    old "Well, I think I feel better with that second opinion... However, come for the last appointment on Thursday, do you think that's okay?"
    new "B:pla: Bem... Realmente não sinto nada..."

    # say L178 mo1
    old "It's fine with me, Nurse Mary."
    new "B:mar: Bem, acho que me sinto melhor com essa segunda opinião... No entanto, venha para a última consulta na quinta-feira, achas que isso está bem?"

    # say L180 mar
    old "...But young man, you can now take your hands off those tits."
    new "...Mas rapaz, agora podes tirar as mãos desses seios."

    # say L187 pla
    old "Sorry... I didn't-"
    new "B:mar:...Mas rapaz, agora podes tirar as mãos desses seios."

    # say L189 mar
    old "Hahaha, I'm just kidding... I think we have a future doctor standing here..."
    new "B:pla: Desculpa... Eu não-"

    # say L195 mo1
    old "You too, Nurse Mary."
    new "B:mar: Até ao próximo encontro, foi bom ver-te!"

    # say L197 mar
    old "See you later, boy..."
    new "B:mo1: Tu também, Enfermeira Mary."

    # say L199 pla
    old "See... you... too."
    new "B:mar: Até mais, rapaz..."

    # say L211 mo1
    old "Hello, Nurse Mary! Good morning."
    new "B:pla: Ver... tu... também."

    # say L214 mar
    old "Oh, hi, How are you today?"
    new "B:mo1: Olá, Enfermeira Mary! Bom dia."

    # say L216 mo1
    old "Very well, thank you."
    new "B:mar: Oh, olá, como estás hoje?"

    # say L223 mar
    old "Well, let's take the final exam, and if we still can't identify it, I already have a solution planned. So let's start... now, take off your clothes."
    new "B:mo1: Muito bem, obrigado."

    # say L228 mar
    old "Hmm... Very well... I think we will definitely need another method..."
    new "B:mar: Bem, vamos fazer o exame final, e se ainda não conseguirmos identificar, já tenho uma solução planejada. Então, vamos começar... agora, tira a roupa."

    # say L233 pla
    old "Uh, well... I think I'm gonna go on and head out..."
    new "B:mar: Talvez mais tarde... Por agora, vou precisar que tires o soutien."

    # say L238 mo1
    old "Yes, Nurse..."
    new "B:mar: Bem, à espera de quê, tira o sutiã..."

    # say L241 mar
    old "That's what I'm talking about... much better..."
    new "B:mo1: Sim, Enfermeira..."

    # say L242 mar
    old "Now I can feel every detail better..."
    new "B:mar: É disso que estou a falar... muito melhor..."

    # say L243 mar
    old "Hmm... I'm going to do it harder..."
    new "B:mar: Agora consigo sentir cada detalhe melhor..."

    # say L250 mar
    old "You guys are so dramatic. Haha. It's just the human body. You have done this before with a bra."
    new "B:mo1: Mary, tu realmente achas que é-"

    # say L251 mar
    old "There is no big difference now. You do not have to sexualize everything, you know."
    new "B:mar: Vocês são tão dramáticos. Haha. É só o corpo humano. Já fizeste isto antes com um soutien."

    # say L252 mo1
    old "Ok, ok, Nurse Mary. If you insist..."
    new "B:mar: Não há grande diferença agora. Não tens de sexualizar tudo, sabes."

    # say L253 mar
    old "Let's see now. Do the massages again..."
    new "B:mo1: Ok, ok, Enfermeira Mary. Se insistes..."

    # say L260 mar
    old "That's it, nice... your hands cover her breasts well..."
    new "B:mar: Vamos lá. Faz as massagens de novo..."

    # say L263 mar
    old "Start massaging them gently..."
    new "B:mar: É isso, bem... as tuas mãos cobrem os seios dela bem..."

    # say L264 mar
    old "Very well... You can feel them better, right?"
    new "B:mar: Começa a massageá-los suavemente..."

    # say L265 pla
    old "...Y-Yes ... (Fuck, I'm getting hard)"
    new "M:mar: Muito bem... Tu consegues senti-los melhor, certo?"

    # say L266 mar
    old "Very well... Rub a little harder, focus on seeing if you feel anything strange..."
    new "B:pla:...S-Sim... (Merda, estou a ficar duro)"

    # say L269 pla
    old "Yes, ma'am..."
    new "B:mar: Muito bem... Massaja um pouco mais forte, concentra-te em ver se sentes algo de estranho..."

    # say L270 pla
    old "Well... I don't really feel anything strange..."
    new "B:pla: Sim, senhora..."

    # say L271 mar
    old "Well, I think that's definite. My final medical verdict is that these babies are in perfect condition... Make sure you take care of them, please."
    new "B:pla: Bem... Não sinto nada de estranho..."

    # say L272 mo1
    old "You bet, Nurse Mary..."
    new "B:mar: Bem, acho que isso é definitivo. O meu veredicto médico final é que estes bebés estão em perfeitas condições... Certifica-te de cuidar deles, por favor."

    # say L284 mar
    old "Well, I think that's it..."
    new "A:mar: Espera um momento... O que é isso que tens aí?"

    # say L286 mar
    old "Wait a second... What do you have there?"
    new "B:mar: Bem, acho que é isso..."

    # say L288 pla
    old "(Oh god no...)"
    new "B:mar: Espera aí... O que é isso que tens aí?"

    # say L291 mar
    old "Oh boy, is that all yours?"
    new "B:pla: (Oh god no...)"

    # say L293 mar
    old "Hmm... I think this is abnormal... Has a doctor checked you out yet?"
    new "B:mar: Oh, rapaz, isso tudo é teu?"

    # say L295 pla
    old "...Well, umm, no."
    new "B:mar: Hmm... Acho que isto é anormal... Já foste ao médico?"

    # say L302 pla
    old "Now? But... I-"
    new "B:mar: Tira toda a tua roupa, rapaz. Vou fazer um exame completo..."

    # say L304 mar
    old "But nothing! You don't see that this could be a health problem?... It is always best to examine it to make sure there is no issues."
    new "B:pla: Agora? Mas... eu-"

    # say L307 mo1
    old "I  will go out then, Mary..."
    new "B:mar: Mas nada! Tu não vês que isto pode ser um problema de saúde?... É sempre melhor examinar para ter a certeza de que não há problemas."

    # say L310 mar
    old "Really? He got to see your goods and now you are shy to see his?... Again, it's just a medical procedure. There's no need to freak out about it."
    new "B:mo1: Vou sair então, Mary..."

    # say L312 mo1
    old "Ok, nurse..."
    new "B:mar: Mesmo? Ele viu as tuas partes íntimas e agora tu tens vergonha de ver as dele?... Mais uma vez, é apenas um procedimento médico. Não há necessidade de ficar nervosa."

    # say L319 mar
    old "Well... I see your whole body is normal, except your penis."
    new "B:mo1: Ok, enfermeira..."

    # say L321 mar
    old "I mean, for your age, it is normal to have hard erections. But I think you have a lot of tension built, much more than normal actually."
    new "B:mar: Bem... Vejo que o teu corpo todo é normal, exceto o pénis."

    # say L323 mar
    old "Also, your size is not at all common... So I need to relax it in order to evaluate it better..."
    new "B:mar: Quero dizer, para a tua idade, é normal ter ereções fortes. Mas acho que tens muita tensão acumulada, muito mais do que o normal, na verdade."

    # say L324 pla
    old "...Wha-what do you mean?"
    new "B:mar: Além disso, o teu tamanho não é nada comum... Por isso preciso de relaxá-lo para poder avaliá-lo melhor..."

    # say L326 mar
    old "It means I'm going to massage it until it is in a relaxed, flaccid state..."
    new "T(mar|tu|diz): Significa que vou massajar até ficar num estado relaxado, flácido..."

    # say L337 mar
    old "Let's see... I'm going to massage it like this..."
    new "B:mar: Isso significa que vou massagear até ficar num estado relaxado, flácido..."

    # say L338 mar
    old "How does it feel, boy?"
    new "B:mar: Vamos ver... Vou massajar assim..."

    # say L339 pla
    old "... It feels... really good."
    new "B:mar: Como é que te sentes, rapaz?"

    # say L356 mar
    old "Let's do it a little faster..."
    new "B:pla:... Sente-se... tão bem."

    # say L365 pla
    old "Nurse... I'm going to..."
    new "B:mar: Vamos mais depressa..."

    # say L367 mar
    old "That's it... Let it out, [pla]. Relax your body."
    new "T(mar|tu|diz): É isso... Deixa sair, [pla]. Relaxa o corpo."

    # say L376 mar
    old "However, I am prescribing that you do these massages anytime you feel tension..."
    new "B:mar: Uau, que espetáculo... Bem, não vejo nada que possa afetar a tua saúde global..."

    # say L378 pla
    old "...Ok, Nurse Mary..."
    new "B:mar: No entanto, estou a prescrever que faças estas massagens sempre que sintas tensão..."

    # say L381 mo1
    old "Thank you very much, Mary, for helping us both..."
    new "B:pla:...Ok, Enfermeira Mary..."

    # say L383 mar
    old "It's a pleasure, Sue. Well, that's it. If you need me again you know where to find me..."
    new "B:mo1: Muito obrigado, Mary, por nos ajudar a ambos..."

    # say L385 mo1
    old "Okay, see you later,Mary..."
    new "B:mar: É um prazer, Sue. Bem, é isso. Se precisares de mim de novo, sabes onde me encontrar..."

    # say L387 pla
    old "See you later..."
    new "Podes apostar nisso."

    # say L389 mar
    old "You can bet it."
    new "B: pla: Até mais..."

    # say L407 mar
    old "Well, I see you're still in perfect health... That was all for now..."
    new "B:mar: Podes apostar nisso."

    # say L413 mar
    old "If you need a checkup again, you know where to find me..."
    new "B:mar: Bem, vejo que ainda estás em perfeita saúde... Isso foi tudo por agora..."

    # say L415 pla
    old "Ok, thanks..."
    new "Se precisares de uma consulta outra vez, sabes onde me encontrar..."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/HomeVar.rpy
translate portuguese strings:

    # say L116 sis
    old "What do you want? I'm busy with the website..."
    new "Precisas de alguma ajuda?"

    # say L117 pla
    old "Do you need some help?"
    new "B:sis: O que queres? Estou ocupada com o site..."

    # say L118 sis
    old "No, I need to be alone..."
    new "B:pla: Precisas de ajuda?"

    # say L119 pla
    old "Ok... (What is wrong with her?)"
    new "B:sis: Não, preciso de estar sozinha..."

    # say L149 pla
    old "Right, I think it would be useful to have more photos even with the same outfits..."
    new "B:sis: Queres repetir uma sessão fotográfica?"

    # say L150 sis
    old "Alright, you are the nerd here."
    new "T(sis|tu|diz): Tudo bem, tu és o nerd aqui."

    # say L151 sis
    old "Which photoshoot should we repeat?"
    new "O primeiro"

    # menu L154 
    old "The first one"
    new "B: Irmã: Qual sessão de fotografia devemos repetir?"

    # say L155 sis
    old "Good choice..."
    new "B:n: O primeiro"

    # menu L161 
    old "The second one"
    new "B:sis: Boa escolha..."

    # say L162 sis
    old "Hmm I really like that one..."
    new "B:n: O segundo"

    # menu L167 
    old "The third one"
    new "B:sis: Hmm, gosto muito desse..."

    # say L168 sis
    old "Great, let's go to the pool..."
    new "B:n: O terceiro"

    # menu L174 
    old "The fourth one"
    new "B:sis: Ótimo, vamos à piscina..."

    # say L175 sis
    old "Oh, I love this photoshoot..."
    new "T(sis|tu|dizes): Oh, adoro este photoshoot..."

    # say L190 sis
    old "Are you ready to work on the website?"
    new "B:sis: Oh, eu adoro este photoshoot..."

    # say L191 pla
    old "Yeah, I think so."
    new "B:sis: Estás pronto para trabalhar no site?"

    # say L192 sis
    old "So, what are we waiting for? Let's work!"
    new "B:pla: Sim, acho que sim."

    # say L215 sis
    old "Mmm, what do we have here?"
    new "B:sis: Então, o que estamos à espera? Vamos trabalhar!"

    # say L216 pla
    old "(Gulp) Well..."
    new "B:sis: Mmm, o que temos aqui?"

    # say L217 sis
    old "I already know... You want my help, right?"
    new "B:pla: (Gulp) Bem..."

    # say L219 sis
    old "With all my pleasure! Hehe."
    new "B: Irmã: Eu já sei... Tu queres a minha ajuda, certo?"

    # say L253 sis
    old "Glad that you came, quite on time for applying the sunscreen, would you help me again?"
    new "Com todo o prazer! Hehe."

    # say L257 pla
    old "Hmm, Sure."
    new "A:pla: Não posso agora..."

    # say L260 pla
    old "I can't right now..."
    new "B:pla: Hmm, claro."

    # say L261 sis
    old "Oh, it's a shame, I was expecting a new skin care therapy..."
    new "B:pla: Não posso agora..."

    # say L263 sis
    old "Alright, I will be here taking a sunbath if you change your mind..."
    new "B:sis: Oh, que pena, eu estava à espera de uma nova terapia de cuidados de pele..."

    # say L274 sis
    old "Great, I wanted to have some fun today..."
    new "Então, o que queres fazer hoje?"

    # say L285 sis
    old "So, what do you want to do today?"
    new "Peitos"

    # menu L288 
    old "Boobs"
    new "B:sis: Então, o que queres fazer hoje?"

    # say L289 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your boobs..."
    new "T: Hmm, acho que seria ótimo para o próximo photoshoot focar nas tuas tetas..."

    # say L290 sis
    old "I like that too... Al right, let's do it..."
    new "B:pla: Hmm acho que seria ótimo para o próximo photoshoot focar nos teus peitos..."

    # say L302 sis
    old "Ready to fuck them?"
    new "B: Irmã: Eu também gosto disso... Tudo bem, vamos lá..."

    # say L320 sis
    old "Uhhh, that's it. I love how much it is, let me spread it all over, I am ready to take a sunbath."
    new "B: Irmã: Pronta para foder com eles?"

    # say L322 pla
    old "You are welcome, always trying to help."
    new "Tu és bem-vindo, sempre a tentar ajudar."

    # say L323 sis
    old "Hahaha Sure."
    new "B:pla: De nada, sempre a tentar ajudar."

    # menu L333 
    old "Ass"
    new "Hmm Acho que seria ótimo para o próximo ensaio fotográfico focar no teu rabo..."

    # say L334 pla
    old "Hmm I think would be great for the next photoshoot, to focus on your ass..."
    new "B:n: Ass"

    # say L335 sis
    old "Oh yeah, let's focus on my ass..."
    new "B:pla: Hmm acho que seria ótimo para o próximo ensaio fotográfico focar no teu rabo..."

    # say L342 sis
    old "You can touch all you want! I love it."
    new "B:sis: Oh yeah, vamos concentrar-nos no meu rabo..."

    # say L349 sis
    old "Alright, now let's fuck!"
    new "B: Irmã: Podes tocar à vontade! Adoro isso."

    # say L369 sis
    old "Uhhh, it was delicious..."
    new "Uhhh, foi delicioso..."


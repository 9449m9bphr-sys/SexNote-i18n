# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/WhiStory.rpy
translate portuguese strings:

    # say L9 rub
    old "What the fuck? I just can't believe it!"
    new "A:oli: Ruby, por favor! Só ouve-me."

    # say L10 oli
    old "Ruby please! Just listen to me."
    new "B:rub: Que merda? Não consigo acreditar!"

    # say L11 rub
    old "Listen, to what?"
    new "O que é que tu tens para me dizer?"

    # say L18 rub
    old "What explanation could you possibly have to go around making friends with that loser?!"
    new "A:oli: Tu não percebes, preciso da ajuda dele, as minhas notas têm estado baixas."

    # say L19 oli
    old "You don't understand, I need his help, my grades have been low."
    new "B:rub: Que explicação podes tu ter para andares a fazer amizade com esse perdedor?!"

    # say L20 oli
    old "So, he's going to help me study for my tests. If he doesn't I'll fail my classes."
    new "B:oli: Não percebes, preciso da ajuda dele, as minhas notas têm estado baixas."

    # say L21 rub
    old "And? Who cares?! You can't just hang out with that disgusting nerd!"
    new "B:oli: Então, ele vai me ajudar a estudar para as minhas provas. Se não fizer isso, vou chumbar nas aulas."

    # say L22 rub
    old "Listen, you better find another way other than spending time with that loser."
    new "T(rub|tu|say): Ouve, tu melhor arranjas outra maneira que não seja passar tempo com esse perdedor."

    # say L23 oli
    old "B- b- but..."
    new "A:rub: Ugh, olha para aquilo, agora os putos nerds estão até a espreitar as nossas conversas."

    # say L27 rub
    old "Ugh, look at that, now the fucking nerds are even eavesdropping our conversations."
    new "B:oli: B- b- mas..."

    # say L33 oli
    old "But Ruby! Wait!"
    new "B:rub: Ugh, olha para aquilo, agora os putos nerds estão até a espreitar as nossas conversas."

    # say L48 pla
    old "Oh hey Mike, what's up?"
    new "B:oli: Mas Ruby! Espera!"

    # say L49 mik
    old "Hmph..."
    new "B:pla: Oh, olá Mike, tudo bem?"

    # say L62 bel
    old "Hmm, that was weird."
    new "B:mik: Hmph..."

    # say L63 pla
    old "Yeah, it was. What's up with him, is he angry about something?"
    new "B:bel: Hmm, isso foi estranho."

    # say L65 bel
    old "Well, now that you mention it. He's been acting odd recently."
    new "B:pla: Sim, foi. O que se passa com ele, está zangado com algo?"

    # say L66 bel
    old "I don't really know why though."
    new "B:bel: Bem, agora que mencionas. Ele tem estado a comportar-se de forma estranha recentemente."

    # say L68 pla
    old "Hmm, I see. I guess I'll have to speak with him."
    new "B:bel: Não sei bem porquê."

    # say L69 bel
    old "I think so. He'll probably tell you what's his deal."
    new "B:pla: Hmm, percebo. Acho que vou ter de falar com ele."

    # say L70 pla
    old "Yeah, well, see you later then."
    new "B:bel: Acho que sim. Ele provavelmente te dirá o que se passa com ele."

    # say L92 pla
    old "Hi Mrs. White, nice to see you."
    new "T(pla|tu|diz): Olá, Sra. White, é bom ver-te."

    # say L93 pla
    old "Hey, I came looking for Mike, is he around? I wanted to talk to him."
    new "B:pla: Olá, Sra. White, bom ver você."

    # say L94 whi
    old "Hmm, well, he is here, but... I don't think he wants to see you."
    new "B:pla: Olá, vim procurar o Mike, ele está por aqui? Queria falar com ele."

    # say L95 pla
    old "Really, why?"
    new "B:whi: Hmm, bem, ele está aqui, mas... Não acho que queira ver-te."

    # say L96 whi
    old "Well, he's been a little... Uhh, unwell these past few days, so he doesn't really want to talk to anybody."
    new "B:pla: Realmente, porquê?"

    # say L98 pla
    old "Unwell? Is he ok?"
    new "B:whi: Bem, ele tem estado um pouco... Hum, indisposto nos últimos dias, por isso não quer falar com ninguém."

    # say L100 whi
    old "He's fine, but... Uhh, not really in a good mood."
    new "B:pla: Doente? Ele está bem?"

    # say L101 pla
    old "Hmm, is there something I can help with?"
    new "B:whi: Ele está bem, mas... Hum, não está de bom humor."

    # say L103 whi
    old "Listen, he asked me not to tell anybody about this. But since you're one of his best friends I'll let you know."
    new "B:pla: Hmm, há algo em que eu possa ajudar?"

    # say L105 whi
    old "The thing is, his birthday was a couple of days ago... and nobody seemed to remember."
    new "B:whi: Escuta, ele pediu-me para não contar a ninguém sobre isto. Mas como tu és um dos seus melhores amigos, vou deixar-te saber."

    # say L106 pla
    old "Ohhh, damn! I totally forgot about it. Shit!"
    new "B:whi: A questão é que o aniversário dele foi há uns dias... e ninguém pareceu lembrar-se."

    # say L107 whi
    old "Yes well, not one of his friends gave him a call, or even said happy birthday to him."
    new "B:pla: Ohhh, merda! Esqueci-me completamente. Merda!"

    # say L108 pla
    old "Damn it, of course, he's angry."
    new "B:whi: Pois bem, nenhum dos amigos dele lhe deu um telefonema, ou sequer lhe disse feliz aniversário."

    # say L109 whi
    old "The reason I tell you this is because Mike is always talking about you, he says you're his best friend."
    new "B:pla: Maldição, claro que ele está zangado."

    # say L112 whi
    old "He admires you a lot, you know..."
    new "A:pla: D- tu achas que ele falará comigo se eu tentar?"

    # say L113 pla
    old "D- do you think he'll talk to me if I try?"
    new "B:whi: Ele admira-te muito, sabes..."

    # say L114 whi
    old "Hmm, I don't really know... But I guess you can try. I actually think it would be good for him."
    new "B:pla: D- tu achas que ele falará comigo se eu tentar?"

    # say L115 whi
    old "He's been really depressed lately. So, it would be good if you could help him out with that."
    new "B:whi: Hmm, não sei... Mas acho que podes tentar. Acho que lhe faria bem."

    # say L117 pla
    old "Sure, sure, don't worry, I'll do my best to fix this."
    new "B:whi: Ele tem estado realmente deprimido ultimamente. Portanto, seria bom se tu pudesses ajudá-lo com isso."

    # say L118 whi
    old "Ok,  then he's in his room. Good luck."
    new "A:mik: Ugh, a minha mãe deixou-te entrar?"

    # say L133 mik
    old "Ugh, did my mom let you in?"
    new "T(mik|tu|say): Ugh, a minha mãe deixou-te entrar?"

    # say L134 pla
    old "Hey man, listen, I'm really sorry. I've been dealing with some stuff, so, I forgot about your birthday."
    new "B:mik: Ugh, a minha mãe deixou-te entrar?"

    # say L135 pla
    old "But I totally care about it, really."
    new "B:pla: Ei, mano, desculpa, tenho lidado com algumas coisas, por isso, esqueci-me do teu aniversário."

    # say L136 mik
    old "Oh yeah, you care?"
    new "T(mik|tu|say): Oh yeah, tu cuidas disso, mesmo?"

    # say L137 mik
    old "That's funny, you seem to care a lot more about the girls' birthdays..."
    new "B:mik: Oh yeah, tu preocupas-te?"

    # say L138 mik
    old "But I guess it's no surprise since I'm always the one who's left out..."
    new "T(mik|tu|say): Mas acho que não é surpresa, já que sou sempre eu que fico de fora..."

    # say L139 pla
    old "Aww, come on dude, you know it's not like that."
    new "Mas acho que não é surpresa, já que sou sempre eu que fico de fora..."

    # say L140 pla
    old "It's just that recently I've been kinda busy."
    new "B:pla: Aww, vem cá, tu sabes que não é assim."

    # say L141 mik
    old "Yeah, yeah, yeah, you're always busy. I get it, you're Mr. important."
    new "T(mik|tu|diz): Sim, sim, sim, tu estás sempre ocupado. Entendo, és o Sr. Importante."

    # say L142 pla
    old "Hey Mike, come on man, listen to me."
    new "B:mik: Sim, sim, sim, tu estás sempre ocupado. Entendi, és o Sr. importante."

    # say L143 mik
    old "No! You listen. It's just unbelievable man, like, wow."
    new "B:pla: Ei, Mike, vem cá, ouve-me."

    # say L144 mik
    old "You know, I've always been there for you when you needed it!"
    new "B:mik: Não! Tu é que tens de ouvir. É simplesmente incrível, cara, tipo, wow."

    # say L146 pla
    old "I know dude, I'm sorry."
    new "B:mik: Sabes, eu sempre estive lá para ti quando precisaste!"

    # say L148 mik
    old "You know what? It's ok, it's not like it's the first time anyway. So I'm used to it. I really don't have any friends."
    new "T(mik|tu|say): Sabes o que? Não tem problema, não é a primeira vez de qualquer maneira. Já me habituei. Na verdade, não tenho amigos."

    # say L149 pla
    old "Hey don't say that, you know very well I'm your friend."
    new "T: Olá, não digas isso, tu sabes muito bem que eu sou teu amigo."

    # say L150 pla
    old "And what do you mean it's not the first time, it was just this year that I forgot your birthday."
    new "E o que queres dizer com \"não é a primeira vez\"? Foi só este ano que esqueci o teu aniversário."

    # say L151 mik
    old "Oh shut up! I'm not talking about my birthday. Remember Halloween?"
    new "B:pla: E o que tu queres dizer com não ser a primeira vez? Foi só este ano que esqueci o teu aniversário."

    # say L152 mik
    old "When we were playing that game you guys made fun of me. And had me leave with that stupid challenge."
    new "T(mik|tu|dizer): Quando estávamos a jogar aquele jogo vocês zombaram de mim. E fizeram-me sair com aquele desafio estúpido."

    # say L153 mik
    old "Of course, you didn't want me there."
    new "T(mik|tu|dizer): Claro, tu não querias que eu estivesse lá."

    # say L156 pla
    old "Listen dude..."
    new "T(pla|tu|say): Cala-te! Guarda as tuas desculpas para ti."

    # say L157 mik
    old "Shut up! Keep your excuses to yourself."
    new "B:pla: Escuta, mano..."

    # say L158 mik
    old "And get the hell out of here. I'm busy."
    new "B:mik: Cala-te! Guarda as tuas desculpas para ti."

    # say L159 pla
    old "Mike, please, calm down."
    new "B:mik: E sai daqui. Estou ocupado."

    # say L160 pla
    old "Thinking about it, I can see your point, you're absolutely right."
    new "B: pla: Mike, por favor, calma."

    # say L161 pla
    old "I've been a really shitty friend."
    new "B:pla: A pensar nisso, vejo a tua razão, tens toda a razão."

    # say L162 pla
    old "So... I'm really sorry bud, and I hope you can forgive me."
    new "B:pla: Tenho sido um amigo realmente péssimo."

    # say L163 mik
    old "Pfff! Get out of here!"
    new "T(mik|tu|say): Pfff! Vai-te embora!"

    # say L164 mik
    old "Do you really think you can get out of this with a simple apology?"
    new "B:mik: Pfff! Sai daqui!"

    # say L165 pla
    old "Hmm... You're right... And I think I can do something to show you I'm your friend."
    new "B:mik: Tu realmente pensas que vais conseguir sair disto com um simples pedido de desculpa?"

    # say L166 pla
    old "And this is kinda risky, so I know you'll believe me once you see it."
    new "B:pla: Hmm... Tens razão... E acho que posso fazer algo para te mostrar que sou teu amigo."

    # say L169 pla
    old "Come with me for a second."
    new "T(pla|tu|say): Vem comigo um momento."

    # say L170 mik
    old "Where?"
    new "B:pla: Vem comigo um segundo."

    # say L171 pla
    old "I have to show you something."
    new "B:mik: Onde?"

    # say L172 pla
    old "Just shut up and come with me."
    new "B:pla: Tenho de te mostrar uma coisa."

    # say L173 pla
    old "If afterwards you're still mad at me I'll leave you alone."
    new "B: Cala-te e vem comigo."

    # say L174 pla
    old "But this is worth it."
    new "B:pla: Se depois ainda estiveres zangada comigo, deixo-te em paz."

    # say L176 mik
    old "Hmm, ok, let's go."
    new "B:pla: Mas isto vale a pena."

    # say L192 mik
    old "What's this? Where are you taking me?"
    new "T(mik|tu|say): O que é isto? Aonde me estás a levar?"

    # say L193 pla
    old "It's ok dude. Just trust me, you'll like this."
    new "B:mik: O que é isto? Aonde me estás a levar?"

    # say L218 mik
    old "What the fuck? This is my neighbor's house. What are we doing here?"
    new "B:pla: Calma, mano. Confia em mim, vais gostar disto."

    # say L219 pla
    old "Chill out dude. It's ok, I know her."
    new "B:mik: Que raio? Esta é a casa da minha vizinha. O que estamos a fazer aqui?"

    # say L220 pla
    old "Just as I thought, If she's not here, that means she'll be probably with a customer upstairs."
    new "B:pla: Calma, cara. Tudo bem, eu conheço-a."

    # say L223 pla
    old "I think I can show you something worthwhile. Just hush and follow me."
    new "B:pla: Como eu pensei, se ela não está aqui, provavelmente está com um cliente lá em cima."

    # say L247 pla
    old "Great, they're in there."
    new "B:pla: Acho que posso mostrar-te algo valioso. Só cala-te e segue-me."

    # say L248 mik
    old "They? What's happening?"
    new "B:pla: Ótimo, eles estão lá dentro."

    # say L249 pla
    old "Listen man, this is something I'm doing only this one time."
    new "B:mik: Eles? O que está a acontecer?"

    # say L250 pla
    old "Take it as my birthday gift to you."
    new "B:pla: Ouve, homem, isto é algo que estou a fazer só desta vez."

    # say L251 pla
    old "Now come here and take a peek."
    new "B:pla: Aceita como o meu presente de aniversário para ti."

    # say L260 mik
    old "Dude! Wow!"
    new "B:pla: Agora vem cá e dá uma espreitadela."

    # say L261 mik
    old "I would never have been able to see this through my telescope!"
    new "T(mik|tu|dizer): Nunca teria conseguido ver isto através do meu telescópio!"

    # say L262 mik
    old "How did you know she does this kind of stuff?"
    new "B:mik: Nunca teria conseguido ver isto com o meu telescópio!"

    # say L263 pla
    old "Just shut up and enjoy it."
    new "T: Cala-te e aproveita."

    # say L264 mik
    old "I will man, you're the best."
    new "B:pla: Cala-te e aproveita."

    # say L274 mik
    old "Dude, that was the best birthday present ever!"
    new "B:mik: Vou, és o melhor."

    # say L275 pla
    old "Well, I'm glad you liked it."
    new "B:mik: Cara, foi o melhor presente de aniversário de sempre!"

    # say L276 pla
    old "I just wanted to say sorry again for being such a lousy friend."
    new "B:pla: Bem, fico contente que tenhas gostado."

    # say L277 pla
    old "And listen, man, I know you think you're all alone, but that's not true."
    new "B:pla: Só queria pedir desculpa outra vez por ser um amigo tão péssimo."

    # say L278 pla
    old "I really do think of you as my best friend, and I'm sure the girls... Uhh, they find you as a good classmate..."
    new "B:pla: E ouve, mano, sei que achas que estás sozinho, mas não é verdade."

    # say L279 pla
    old "It's just that lately we all have been dealing with some stuff."
    new "B:pla: Eu realmente te considero o meu melhor amigo, e tenho a certeza de que as raparigas... Hum, elas te veem como um bom colega de turma..."

    # say L280 pla
    old "But I want you to know that I would never take you for granted."
    new "B:pla: É só que ultimamente todos nós temos lidado com algumas coisas."

    # say L282 mik
    old "It's ok man, I was angry, but you've more than made up for it with that awesome gift."
    new "B:pla: Mas quero que saibas que nunca te tomaria como garantido."

    # say L283 mik
    old "It was so fucking rad."
    new "B:mik: Tudo bem, mano, estava zangado, mas tu já compensaste com esse presente incrível."

    # say L284 pla
    old "Well I'm happy we're ok now. But I kinda have to leave."
    new "B:mik: Foi tão fixe."

    # say L285 pla
    old "I have to do a couple of things, but I'll swing by later."
    new "A:mik: Espera, Cara!"

    # say L286 mik
    old "Wait, Dude!"
    new "B:pla: Tenho que fazer umas coisas, mas passo mais tarde."

    # say L288 mik
    old "Before you leave, there's something I have to ask you."
    new "B:mik: Espera, mano!"

    # say L289 pla
    old "Hmm, sure, tell me."
    new "T(pla|tu|say): Hmm, claro, conta-me."

    # say L290 mik
    old "Hmm, the thing is... I don't really know how to say this..."
    new "Hmm, a questão é... não sei bem como dizer isto... Preciso que me ajudes a estudar uma matéria..."

    # say L291 mik
    old "I'm gonna need you to help me study for a subject..."
    new "B:mik: Hmm, a questão é... não sei bem como dizer isto..."

    # say L292 pla
    old "What? Haha! But you've never wanted to study with us before."
    new "B:mik: Vou precisar da tua ajuda para estudar uma matéria..."

    # say L293 pla
    old "Why now all of a sudden?"
    new "A:mik: É porque é super lame."

    # say L295 mik
    old "It's because it's super lame."
    new "T(mik|tu|say): É porque é super lame. Mas vês, desta vez não é realmente para mim."

    # say L296 mik
    old "But you see, this time is not really for me."
    new "T(mik|tu|diz): Mas vês, desta vez não é realmente para mim."

    # say L297 mik
    old "I told Olivia I would help her with her studies, so I kinda have to learn the subject."
    new "B:mik: Mas vês, desta vez não é realmente para mim."

    # say L298 pla
    old "Oh, really? Hahahahahaha!"
    new "T(pla|tu|say): Oh, a sério? Hahahahahaha!"

    # say L299 mik
    old "Dude! Don't laugh, this is important, ok?"
    new "B:pla: Oh, realmente? Hahahahahaha!"

    # say L300 pla
    old "Heh, s- sure, sorry."
    new "B:mik: Cara! Não rias, isto é importante, ok?"

    # say L302 mik
    old "Well anyway, the point is that I'm gonna need your help to learn the subjects."
    new "B:pla: Heh, c- claro, desculpa."

    # say L303 mik
    old "'Cause you'll help me out, right? I mean, we're friends..."
    new "B:mik: Enfim, o ponto é que vou precisar da tua ajuda para aprender as matérias."

    # say L304 pla
    old "*Sigh*"
    new "B:mik: Porque vais ajudar-me, certo? Quero dizer, somos amigos..."

    # say L305 pla
    old "I mean, sure, if you really need it I'll help you out."
    new "Mas cara, ela não é sempre super malvada connosco?"

    # say L306 pla
    old "But dude, isn't she always super mean to us?"
    new "B:pla: Quero dizer, claro, se tu realmente precisas eu te ajudo."

    # say L307 pla
    old "You've heard the way she and Ruby talk to us."
    new "B:pla: Mas cara, ela não é sempre super malvada connosco?"

    # say L308 pla
    old "Like... You know?"
    new "A:mik: Eu sei, eu sei. Mas a questão é..."

    # say L309 mik
    old "I know, I know. But the thing is..."
    new "T(mik|tu|say): Eu sei, eu sei. Mas a questão é..."

    # say L310 mik
    old "I actually like that, a lot if I can be honest."
    new "B:mik: Eu sei, eu sei. Mas a coisa é..."

    # say L311 pla
    old "What? Are you for real right now?"
    new "T: O quê? Estás a ser a sério agora?"

    # say L312 pla
    old "What could you possibly like about that?"
    new "B:pla: O quê? Estás a ser a sério agora?"

    # say L313 mik
    old "To be honest, I don't know why, but I love it when girls are mean to me. It's so hot!"
    new "B:pla: O que é que podes gostar nisso?"

    # say L314 mik
    old "Mmm, even the other day when they were insulting us in the hallway."
    new "B:mik: Para ser honesto, não sei porquê, mas adoro quando as raparigas são más comigo. É tão excitante!"

    # say L315 mik
    old "Uhh man, I almost got a hard-on!"
    new "B:mik: Mmm, até o outro dia quando nos estavam a insultar no corredor."

    # say L317 pla
    old "Ok, I get it, you're a freak. But it's fine I guess."
    new "B:mik: Uhh, cara, quase fiquei com pau duro!"

    # say L318 pla
    old "Ok man, I guess I can help you, I'm not sure what you need exactly though."
    new "B:pla: Ok, percebi, és um excêntrico. Mas tudo bem, acho."

    # say L319 mik
    old "Well, I have to give her classes on those subjects. So, something that will help me with that."
    new "B:pla: Ok, mano, acho que posso ajudar-te, mas não tenho a certeza do que precisas exatamente."

    # say L320 pla
    old "Hmm, I think I know what we can do."
    new "B:mik: Bem, tenho de lhe dar aulas sobre esses assuntos. Portanto, algo que me ajude com isso."

    # say L321 pla
    old "How about I give you the classes, and you just repeat them to Olivia?"
    new "B:pla: Hmm, acho que sei o que podemos fazer."

    # say L323 mik
    old "Ohh, that sounds perfect."
    new "T(mik|tu|diz): Ohh, isso soa perfeito. Mas vais ter de prestar muita atenção a tudo o que te disser."

    # say L324 pla
    old "But, you're gonna have to pay a lot of attention to everything I tell you."
    new "Mas, vais ter de prestar muita atenção a tudo o que te digo. Afinal, não vai ser útil se ela te fizer uma pergunta e tu não conseguires responder direito."

    # say L325 pla
    old "After all it won't be useful if she asks you a question and you can't answer ir properly."
    new "B:pla: Mas, vais ter de prestar muita atenção a tudo o que te digo."

    # say L326 mik
    old "Sure, sure, sure. No problem man, I'm sure I'll learn it all."
    new "B:pla: Afinal, não vai ser útil se ela te fizer uma pergunta e tu não conseguires responder direito."

    # say L328 pla
    old "Well, with that sorted out, I'll go home. And we can meet after class to study."
    new "B:mik: Claro, claro, claro. Sem problemas, acho que vou aprender tudo."

    # say L330 mik
    old "No problem. Thank you so much dude! You're the best."
    new "B:pla: Bem, com isso resolvido, vou para casa. E podemos nos encontrar depois da aula para estudar."

    # say L332 pla
    old "Yeah, yeah, but don't be so quick to thank me. We don't know if this will work."
    new "B:mik: Sem problema. Muito obrigado, cara! Tu és o melhor."

    # say L333 mik
    old "I'll do my best, I promise!"
    new "B:pla: Sim, sim, mas não te precipites a agradecer-me. Não sabemos se isto vai resultar."

    # say L334 pla
    old "Alright, see you later."
    new "B:mik: Vou fazer o meu melhor, prometo!"

    # say L362 whi
    old "Let me tell you something. I don't know what you said to Mike."
    new "B:pla: Olá Sra. White, é bom ver-te também."

    # say L363 whi
    old "But since you two talked, he's been in a much better mood. Thank you so much for that."
    new "B:whi: Deixa-me dizer-te uma coisa. Não sei o que disseste ao Mike."

    # say L364 pla
    old "No problem, I'm happy we got to sort things out."
    new "B:whi: Mas desde que vocês falaram, ele tem estado num humor muito melhor. Muito obrigado por isso."

    # say L365 whi
    old "You did a great job."
    new "B:pla: Sem problemas, estou feliz que conseguimos resolver as coisas."

    # say L366 whi
    old "So good that I've been thinking maybe I should give you a small reward."
    new "B:whi: Tu fizeste um ótimo trabalho."

    # say L367 pla
    old "Oh, I appreciate it, but you really don't have to."
    new "B:whi: Tão bom que tenho pensado em te dar um pequeno prémio."

    # say L368 pla
    old "I was just trying to be a good friend, and help him out."
    new "B:pla: Oh, agradeço, mas não precisas de te preocupar."

    # say L369 pla
    old "Also, I don't want it to be of any trouble."
    new "B:pla: Estava apenas a tentar ser um bom amigo e ajudá-lo."

    # say L370 whi
    old "Oh, but it's no trouble sweety, you've been very good to Mike."
    new "B:pla: E também, não quero ser incómodo."

    # say L371 whi
    old "And I believe that deserves a good reward."
    new "B:whi: Oh, mas não é nenhum incómodo querida, foste muito boa para o Mike."

    # say L372 pla
    old "Uhh, I'm very thankful Mrs. White, but I think I'm ok."
    new "B:whi: E acho que isso merece uma boa recompensa."

    # say L373 pla
    old "And... uh, I kinda have to go study with Mike now, so..."
    new "B:pla: Uhh, estou muito grato, Sra. White, mas acho que estou bem."

    # say L374 whi
    old "Hmm, yeah, that's right, you two have to study. Go ahead."
    new "B:pla: E... hã, tenho de ir estudar com o Mike agora, então..."

    # say L375 whi
    old "In the meantime I'll think of something."
    new "B:whi: Hmm, sim, é verdade, vocês dois têm que estudar. Vão em frente."

    # say L376 whi
    old "And I'm sure you'll love it."
    new "B:whi: Entretanto, vou pensar em algo."

    # say L377 whi
    old "I see you later sweety."
    new "B:whi: E tenho a certeza de que vais adorar."

    # say L378 pla
    old "See you later Mrs. White."
    new "B:whi: Vejo-te mais tarde, querida."

    # say L390 pla
    old "Yeah dude, I figured you'd want to start as soon as possible."
    new "T(pla|tu|say): Claro, pensei que quiserias começar o mais rápido possível."

    # say L391 mik
    old "For sure, my first session with Olivia's coming soon."
    new "B:pla: Claro, pensei que quiserias começar o mais rápido possível."

    # say L392 mik
    old "And I don't know shit about the subject."
    new "B:mik: Com certeza, a minha primeira sessão com Olivia está a chegar."

    # say L393 pla
    old "Don't you say..."
    new "B:mik: E não sei nada sobre o assunto."

    # say L394 pla
    old "But that's why I'm here, so let's get to it."
    new "B:pla: Não digas..."

    # say L396 mik
    old "Let's do it dude..."
    new "B:pla: Mas é por isso que estou aqui, então vamos lá."

    # say L412 pla
    old "Mike has been putting in quite some effort to study, so he caught the lesson really quick."
    new "B:pla: Tens razão, Sra. White, fizemos bastante progresso."

    # say L414 whi
    old "But wait, leaving so soon?"
    new "B: Mike tem estado a fazer bastante esforço nos estudos, por isso apanhou a lição muito depressa."

    # say L415 pla
    old "Well, yeah, since we're done, and it's getting kinda late."
    new "B:whi: Mas espera, a ir-te embora tão cedo?"

    # say L416 pla
    old "I thought it would be better to go home."
    new "B:pla: Bem, sim, já que acabámos e está a ficar um pouco tarde."

    # say L418 whi
    old "Oh no, no, no. I just finished making dinner. Stay and have dinner with us."
    new "B:pla: Eu pensei que seria melhor ir para casa."

    # say L420 pla
    old "Hmm, I don't know Mrs. White, I'm very thankful, but I don't want it to be of any trouble."
    new "B:whi: Oh não, não, não. Acabei de fazer o jantar. Fica e come connosco."

    # say L421 whi
    old "Don't be silly"
    new "Não sejas parvo, é só mais um prato, além disso deves estar cansado de estudar com o Mike."

    # say L422 whi
    old "It's only an extra plate, besides you must be tired from studying with Mike."
    new "B:whi: Não sejas parvo"

    # say L423 whi
    old "And you've been so good, not only did you talk to Mike when he was angry."
    new "B:whi: É só mais um prato, além disso tu deves estar cansado de estudar com o Mike."

    # say L424 whi
    old "You're also helping him study."
    new "B:whi: E foste tão boa, não só falaste com o Mike quando ele estava zangado."

    # say L425 whi
    old "The least I can do is invite you to have some dinner with us."
    new "B:whi: Estás também a ajudá-lo a estudar."

    # say L426 whi
    old "I can't just let you leave like that."
    new "B:whi: O mínimo que posso fazer é convidar-te para jantares connosco."

    # say L437 mik
    old "For sure dude! You should totally stay."
    new "B:whi: O jantar está pronto, querido, estava a dizer ao teu amigo que ele devia ficar para o jantar."

    # say L438 mik
    old "My mom makes the best pot roast you'll ever try, trust me you'll like it."
    new "B:mik: Claro, mano! Deves mesmo ficar."

    # say L439 whi
    old "Oh he's gonna love it."
    new "B:mik: A minha mãe faz o melhor assado de panela que vais provar, acredita, vais adorar."

    # say L441 pla
    old "All right, if you insist, I can't say no..."
    new "B:whi: Oh, ele vai adorar."

    # say L442 pla
    old "Thanks a lot Mrs. White, I really appreciate it."
    new "B:pla: Tudo bem, se insistes, não posso dizer que não..."

    # say L443 mik
    old "Let's go then!"
    new "B:pla: Muito obrigado, Sra. White, eu realmente aprecio."

    # say L457 whi
    old "So tell me, how are your studies going? And your grades?"
    new "B:mik: Vamos então!"

    # say L458 whi
    old "I hope everything's going well with your exams."
    new "B:whi: Então, conta-me, como estão os teus estudos? E as tuas notas?"

    # say L459 mik
    old "Well, Belle and I are doing well on our end of term project."
    new "B:whi: Espero que tudo esteja a correr bem com os teus exames."

    # say L460 mik
    old "She's really smart, and has helped me a lot with that."
    new "B:mik: Bem, Belle e eu estamos a ir bem no nosso projeto de fim de termo."

    # say L464 mik
    old "Oh right [pla], you did yours with Hin, right?"
    new "T(mik|tu|say): Oh, é verdade [pla], tu fizeste o teu com Hin, certo?"

    # say L467 pla
    old "Uhh... W- well, it went really... well."
    new "T(pla|tu|say): Uhh... B-bem, correu realmente... bem."

    # say L468 pla
    old "Really well actually, Hin is a very good student, so we flew through it."
    new "B:pla: Uhh... B-bem, correu realmente... bem."

    # say L470 mik
    old "Uh, that makes sense, of course she would do a good job."
    new "B:pla: Na verdade, muito bem, a Hin é uma aluna muito boa, por isso avançámos rapidamente."

    # say L471 mik
    old "Specially since she's so into you."
    new "T(mik|tu|say): Especialmente porque ela está tão interessada em ti."

    # say L474 mik
    old "Please dude, don't play fool, she's sooo got a thing for you."
    new "B:mik: Specially since she's so into you."

    # say L475 pla
    old "I don't know what you're talking about, we're just friends..."
    new "B:mik: Por favor, não finjas, ela gosta tanto de ti."

    # say L476 whi
    old "Hinn is Jade's daugther, right? She's such a nice, smart girl."
    new "B:pla: Não sei do que estás a falar, somos só amigos..."

    # say L477 whi
    old "Are you two dating?"
    new "B:whi: Hinn é filha da Jade, certo? Ela é uma rapariga tão simpática e inteligente."

    # say L479 pla
    old "No, we're not. Mike's just messing with me."
    new "B:whi: Vocês estão a namorar?"

    # say L480 mik
    old "Come on, she totally likes you..."
    new "B:pla: Não, não estamos. O Mike está só a brincar comigo."

    # say L483 pla
    old "She's just a good friend. That's all there is to it."
    new "B:mik: Vamos, ela gosta de ti..."

    # say L487 mik
    old "I don't know what she see's in you dude."
    new "B:mik: Só a Hin."

    # say L489 whi
    old "Oh, but he's a total heartthrob."
    new "B:mik: Não faço ideia do que ela vê em ti, meu."

    # say L493 whi
    old "I see, that's very good."
    new "A:whi: Aliás, de que é que os teus projetos tratam?"

    # say L494 whi
    old "By the way what are your projects about?"
    new "A:mik: Ugh, uma coisa de criação de conteúdo online que a Belle disse que devíamos fazer."

    # say L495 mik
    old "Ugh, some online content creation thing Belle said we should do."
    new "B:whi: Por acaso, de que é que os teus projetos tratam?"

    # say L496 mik
    old "It's a research project."
    new "B:mik: Ugh, uma coisa de criação de conteúdo online que a Belle disse que devíamos fazer."

    # say L497 mik
    old "She's very into those subjects."
    new "T(mik|tu|dizes): Ela está muito interessada nesses assuntos."

    # say L500 pla
    old "About personal development and self confidence and stuff."
    new "B:pla: Nós... Hum, temos um projeto de psicologia."

    # say L502 whi
    old "Oh, I see, interesting."
    new "A:whi: Parece um assunto MUITO difícil."

    # say L509 whi
    old "It sounds like a very, very HARD subject."
    new "B:whi: Ah, percebo, interessante."

    # say L510 pla
    old "I- it kind of is..."
    new "T: É... é meio que isso mesmo..."

    # say L529 whi
    old "I imagine you must be working very very... hard."
    new "B:pla: I- é mais ou menos isso..."

    # say L531 mik
    old "Yes, we really are."
    new "B:whi: Imagino que devem estar a trabalhar muito... muito."

    # say L544 pla
    old "The food was delicious Mrs. White, thanks a lot."
    new "T(pla|tu|say): A comida estava deliciosa, Sra. White, muito obrigado."

    # say L545 pla
    old "But it's getting kinda late. So, if you'll excuse me I should go home."
    new "B:pla: A comida estava deliciosa, Sra. White, muito obrigado."

    # say L546 pla
    old "But I'll be back soon to keep studying, Mike."
    new "B:pla: Mas já está a ficar um pouco tarde. Então, se me desculpas, devo ir para casa."

    # say L547 whi
    old "That's ok sweety, I'm glad to hear you liked dinner."
    new "B:pla: Mas vou voltar logo para continuar a estudar, Mike."

    # say L548 whi
    old "And I'm also glad you had a good time."
    new "B:whi: Isso está bem querida, fico contente por teres gostado do jantar."

    # say L549 pla
    old "Yes, it was... very good. You've got marvelous hands Mrs. White... For the kitchen of course..."
    new "B:whi: E fico contente que tenhas gostado."

    # say L550 whi
    old "You should stay for dinner more often.."
    new "B:pla: Sim, foi... muito bom. Tu tens mãos maravilhosas, Sra. White... Para a cozinha, claro..."

    # say L551 whi
    old "So, you don't have to worry about coming here, and spending all the time you want."
    new "B:whi: Deverias ficar para jantar mais vezes.."

    # say L552 pla
    old "Thanks a lot Mrs. White, that's very kind of you."
    new "T(pla|tu|say): Muito obrigado, Sra. White, isso é muito gentil da sua parte."

    # say L553 whi
    old "I'm always happy to have some extra company here. And you know you're more than welcome."
    new "B:pla: Muito obrigado, Sra. White, é muito gentil da sua parte."

    # say L554 pla
    old "Uhh, sure, thank you."
    new "T(pla|tu|say): Hum, claro, obrigado."

    # say L555 pla
    old "I think I should go now."
    new "B:pla: Hum, claro, obrigado."

    # say L557 whi
    old "Get home safe. See you later sweetie."
    new "B:pla: Acho que devo ir agora."

    # say L559 mik
    old "Later dude."
    new "B:whi: Chega a casa em segurança. Até logo, querida."

    # say L579 pla
    old "Yeah dude, that's right."
    new "T(pla|tu|say): Sim, é verdade."

    # say L580 mik
    old "Oh thank god, my next session with Olivia's coming soon."
    new "B:pla: Yeah dude, that's right."

    # say L581 mik
    old "And I was getting worried, because I'm not ready for her class."
    new "B:mik: Oh graças a Deus, a minha próxima sessão com Olivia está a chegar."

    # say L582 pla
    old "Well that's why I'm here. Are you ready to start?"
    new "B:mik: E estava preocupado, porque não estou preparado para a aula dela."

    # say L583 mik
    old "Yeah I'm ready, let's do this!"
    new "B:pla: É por isso que estou aqui. Estás pronto para começar?"

    # say L594 pla
    old "Wow! Dude! You got it right! I didn't know you were so good at this!"
    new "B:mik: Claro, estou pronto, vamos lá!"

    # say L595 pla
    old "I mean, if you studied like that more often you'd have straight A's."
    new "B:pla: Uau! Cara! Tu acertaste! Não sabia que eras tão bom nisto!"

    # say L596 mik
    old "Hehe, thanks man, I've tried to pay attention to what you've taught me."
    new "B:pla: Quero dizer, se estudasses assim com mais frequência, terias notas excelentes."

    # say L597 mik
    old "So that I can teach it to Olivia."
    new "B:mik: Hehe, obrigado, tentei prestar atenção no que me ensinaste."

    # say L598 pla
    old "Well I'm sure it's gonna go great if you keep going like that."
    new "B:mik: Para que eu possa ensiná-lo à Olivia."

    # say L599 pla
    old "So, listen dude, it's getting kinda late, so, I should go home."
    new "B:pla: Tenho a certeza de que vai correr bem se continuares assim."

    # say L600 pla
    old "But I'll be back before your next session with Olivia."
    new "B:pla: Então, ouve, já está a ficar tarde, vou ter que ir para casa."

    # say L602 mik
    old "Sure man, thanks a lot. See you later."
    new "T(mik|tu|say): Claro, obrigado. Até mais."

    # say L652 mik
    old "Damn, I'm sorry dude. I suck at this so much."
    new "Acho que estou só a perder o teu tempo."

    # say L653 mik
    old "I think I'm just wasting your time."
    new "B:mik: Merda, desculpa, cara. Sou tão mau nisto."

    # say L654 pla
    old "Nah, it's ok, this isn't an easy topic anyway."
    new "B:mik: Acho que estou a perder o teu tempo."

    # say L655 pla
    old "We still got some time before you have to teach Olivia. So let's just relax."
    new "B:pla: Não, tudo bem, este não é um tema fácil de qualquer maneira."

    # say L656 mik
    old "I can't relax dude! I told Olivia I was gonna teach her and I'm not ready."
    new "B:pla: Ainda temos algum tempo antes de tu teres de ensinar a Olivia. Vamos só relaxar."

    # say L657 pla
    old "I know, man, I know."
    new "T:pla: Eu sei, mano, eu sei."

    # say L658 pla
    old "I'm sure you'll get it before the day."
    new "B:pla: Eu sei, mano, eu sei."

    # say L662 pla
    old "Nah, I don't think we should keep going today"
    new "B:mik: Vamos tentar de novo, tenho a certeza que vou fazer melhor desta vez."

    # say L663 pla
    old "We're already tired, and just forcing this won't help."
    new "B:pla: Não, acho que não devemos continuar hoje."

    # say L664 pla
    old "Besides, it's kinda late, so I think I better go home for now."
    new "B:pla: Já estamos cansados, e forçar isto agora não vai ajudar."

    # say L665 pla
    old "And we can pick it up another time."
    new "B:pla: Além disso, já está meio tarde, então acho melhor ir para casa por agora."

    # say L667 mik
    old "Sure, you're probably right."
    new "B:pla: E podemos pegar isso noutra altura."

    # say L687 pla
    old "Hi Mrs. White, how are you?"
    new "T(pla|tu|say): Olá Sra. White, como estás?"

    # say L688 whi
    old "I'm fine sweetie, and you?"
    new "B:pla: Olá Sra. White, como está?"

    # say L690 whi
    old "Let me guess, you came to see Mike, right?"
    new "B:whi: Estou bem querida, e tu?"

    # say L691 pla
    old "That's right, we'd planned another study session for today."
    new "B:whi: Deixa-me adivinhar, vieste ver o Mike, certo?"

    # say L692 whi
    old "Well sweetie, I'm sorry to tell you he isn't here."
    new "B:pla: Tens razão, tínhamos planeado outra sessão de estudo para hoje."

    # say L693 whi
    old "I don't know if he forgot to tell you, but he said he was meeting a girl to study."
    new "B:whi: Bem querida, sinto muito mas ele não está aqui."

    # say L694 pla
    old "Oh right! Damn, I totally forgot about that."
    new "T(pla|tu|say): Oh, certo! Merda, eu totalmente me esqueci disso."

    # say L695 pla
    old "He did say something about it."
    new "B:pla: Ah, certo! Merda, eu totalmente me esqueci disso."

    # say L696 pla
    old "Well, I guess I'm gonna have to come back later. Please tell him I came by."
    new "B:pla: Ele disse alguma coisa sobre isso."

    # say L707 whi
    old "Sweetie it would be a shame if you left just after getting here."
    new "B:pla: H- hum?"

    # say L708 whi
    old "Why don't you stay for a little while?"
    new "B:whi: Querida, seria uma pena se fosses embora logo depois de chegares."

    # say L709 whi
    old "You can make me some company."
    new "B:whi: Por que não ficas um pouco mais?"

    # say L711 whi
    old "I actually was about to move around the furniture in my room."
    new "B:whi: Podes fazer-me companhia."

    # say L712 whi
    old "I could use your help and I thought maybe a big and strong guy like you could help me out."
    new "B:whi: Estava mesmo a pensar em rearranjar os móveis no meu quarto."

    # say L713 pla
    old "Heh, sure, I can help you out."
    new "B:whi: Precisava da tua ajuda e pensei que um tipo grande e forte como tu poderia ajudar-me."

    # say L715 whi
    old "Come on up, I'll show you what I need."
    new "B:pla: Heh, claro, posso ajudar-te."

    # say L726 pla
    old "Ok, Mrs. White, what do you want me to help you with?"
    new "Bem, sobe, vou mostrar o que preciso. T(pla|tu|diz): Ok, Sra. White, com o que tu precisas de ajuda? A:pla: Oh, wow!"

    # say L733 pla
    old "Oh, wow!"
    new "B:pla: Ok, Mrs. White, com o que tu queres que te ajude?"

    # say L734 whi
    old "You see... I figured, since we're alone."
    new "B:pla: Oh, wow!"

    # say L735 whi
    old "Why don't we have a little bit of fun?"
    new "B:whi: Tu vês... pensei que, estando só nós dois."

    # say L736 pla
    old "B- But, Mrs. White, what happens if Mike catches us?"
    new "B:whi: Porque não temos um pouco de diversão?"

    # say L737 whi
    old "You worry too much."
    new "B: B- Mas, Sra. White, e se o Mike nos apanhar?"

    # say L738 whi
    old "He won't be home for a while, besides, this is my room. So he won't come in without knocking first."
    new "B:whi: Tu preocupas-te demasiado."

    # say L739 whi
    old "We have time and privacy."
    new "B:whi: Ele não vai chegar a casa daqui a muito tempo, além disso, esta é a minha quarto. Portanto, ele não entrará sem bater primeiro."

    # say L740 whi
    old "So don't worry and let's just enjoy."
    new "B:whi: Temos tempo e privacidade."

    # say L741 pla
    old "I mean, I- I understand what you're saying, but I think it's too risky."
    new "B:whi: Então não te preocupes e vamos apenas aproveitar."

    # say L742 whi
    old "Oh please, don't act like you don't want it."
    new "B:pla: Quero dizer, eu- eu percebo o que estás a dizer, mas acho que é demasiado arriscado."

    # say L743 whi
    old "I know you're turned on right now, so come here."
    new "B:whi: Oh, por favor, não finjas que não queres isto."

    # say L745 whi
    old "You know, I know you enjoyed dinner last time."
    new "B:whi: Eu sei que estás excitado neste momento, então vem aqui."

    # say L746 whi
    old "But I'm still not satisfied."
    new "B:whi: Sabes, sei que gostaste do jantar da última vez."

    # say L747 whi
    old "I want to taste something a little better."
    new "A:whi: Mmm, olha para esse pénis grande que tu tens."

    # say L754 whi
    old "Mmm, look at that big cock of yours."
    new "B:whi: Quero provar algo um pouco melhor."

    # say L755 whi
    old "I told you I knew you were getting turned on and very, very hard by the looks of it...."
    new "B:whi: Mmm, olha para esse pénis grande que tu tens."

    # say L757 whi
    old "I've been wanting to taste this big dick since last dinner."
    new "B:whi: Eu disse que sabia que tu estavas a ficar excitado e muito, muito duro pelo que parece...."

    # say L767 mik
    old "Dude, you were here?"
    new "B:whi: Tenho andado a pensar em provar este pénis grande desde o jantar passado."

    # say L768 whi
    old "Yes, he came looking for you, but you weren't home, so I asked him to stay."
    new "B:mik: Cara, tu estavas aqui?"

    # say L770 mik
    old "Stay? What for?"
    new "B:whi: Sim, ele veio procurar-te, mas tu não estavas em casa, então pedi-lhe para ficar."

    # say L771 pla
    old "Uhhh... W- well... you know..."
    new "B:mik: Ficar? Para quê?"

    # say L772 whi
    old "Well, if you remember, there were some stuff in my room that I wanted to move to the attic."
    new "B:pla: Uhhh... B- bem... tu sabes..."

    # say L773 whi
    old "And I've been telling you for a while to help me, but you haven't done anything."
    new "B:whi: Bem, se te lembras, havia algumas coisas no meu quarto que eu queria levar para o sótão."

    # say L774 whi
    old "So you're friend here was kind enough to help me. You could learn one or two things from him, you know young man?"
    new "B:whi: E eu tenho-te dito há algum tempo para me ajudares, mas tu não fizeste nada."

    # say L775 mik
    old "Hmm, yeah, uh, I forgot about that stuff."
    new "B:whi: Então o teu amigo foi simpático o suficiente para me ajudar. Podes aprender uma ou duas coisas com ele, sabes, rapaz?"

    # say L778 pla
    old "... No problem."
    new "B:mik: Hmm, yeah, uh, esqueci-me disso."

    # say L779 whi
    old "Well, I have to clean up some things, and start making dinner. So I'll leave you two alone."
    new "B:pla:... Sem problema."

    # say L781 pla
    old "Sure Mrs. White."
    new "T(pla|tu|diz): Claro, Sra. White."

    # say L788 mik
    old "Sorry you had to see that dude."
    new "B:pla: Claro, Sra. White."

    # say L789 mik
    old "My mom is very annoying, sometimes she won't stop nagging me."
    new "B:mik: Desculpa teres tido de ver isso, meu."

    # say L790 pla
    old "Don't worry about it... My mom's the same."
    new "T(pla|tu|say): Não te preocupes... A minha mãe também é assim."

    # say L791 mik
    old "Well anyway, come to my room, I have to tell you something."
    new "B:pla: Não te preocupes... A minha mãe é a mesma."

    # say L800 mik
    old "Dudeee! Things went so well with Olivia!"
    new "B:mik: Bem, de qualquer maneira, vem ao meu quarto, tenho que te dizer uma coisa."

    # say L802 mik
    old "Yeah! She said I helped her a lot and that I'm a very good tutor."
    new "B:mik: Cara! As coisas correram tão bem com a Olivia!"

    # say L803 mik
    old "And it's all thanks to you dude. Thank you!"
    new "B:mik: Sim! Ela disse que eu a ajudei muito e que sou um excelente tutor."

    # say L804 pla
    old "You're welcome man, I'm glad to be able to help."
    new "Então vais continuar a ver-te com ela?"

    # say L805 pla
    old "So you're gonna keep seeing her?"
    new "B:pla: De nada, estou contente por poder ajudar."

    # say L806 mik
    old "Yeah, but she says she's going to come here next time."
    new "B:pla: Então vais continuar a ver-te com ela?"

    # say L807 mik
    old "Because she says she's embarrassed to be seen with me, so it's better to come here instead."
    new "B:mik: Sim, mas ela diz que vai vir aqui da próxima vez."

    # say L808 pla
    old "Whoa! What?! That's awful!"
    new "B:mik: Porque ela diz que tem vergonha de ser vista comigo, por isso é melhor vir aqui em vez disso."

    # say L809 pla
    old "And you're ok with that?"
    new "B:pla: Que! O quê?! Isso é terrível!"

    # say L811 mik
    old "Sure, why wouldn't I be? That means she wants to spend time with me. right?"
    new "T(mik|tu|diz): Claro, por que não seria? Isso significa que ela quer passar tempo comigo, certo?"

    # say L814 pla
    old "I mean, that's one way to put it..."
    new "T(pla|tu|say): Quer dizer, é uma maneira de ver as coisas..."

    # say L815 mik
    old "Come on man, she's gonna be here... in my room!"
    new "B:pla: Quero dizer, é uma maneira de ver as coisas..."

    # say L816 mik
    old "That's an opportunity to get closer with her!"
    new "B:mik: Vamos, homem, ela vai estar aqui... no meu quarto!"

    # say L817 mik
    old "And I don't really care what people think, you know? So what the hell."
    new "B:mik: É uma oportunidade para me aproximar dela!"

    # say L818 pla
    old "Well... as long as you're happy."
    new "B:mik: E não me importo muito com o que as pessoas pensam, sabes? Que se lixe."

    # say L819 pla
    old "And you're positive about it. So, sure."
    new "A:pla: Escuta, vim ajudar-te a estudar, mas já está meio tarde."

    # say L822 pla
    old "Listen man, I came to help you study, but it's kinda late."
    new "B:pla: E estás certo disso. Claro."

    # say L823 pla
    old "So, what do you say if we leave it for next time."
    new "B:pla: Ouve, vim ajudar-te a estudar, mas já é meio tarde."

    # say L824 pla
    old "Besides, you must be tired from studying with Olivia."
    new "B:pla: Então, o que dizes se deixarmos para a próxima vez?"

    # say L825 mik
    old "Sure dude, to be honest I was afraid you were gonna say we had to study."
    new "B:pla: Além disso, tu deves estar cansado de estudar com a Olivia."

    # say L826 mik
    old "So I'm ok with doing it another time."
    new "B:mik: Claro, para ser honesto, tinha medo que fosses dizer que tínhamos de estudar."

    # say L827 pla
    old "Cool, see you later then."
    new "Tudo bem, até mais."

    # say L829 mik
    old "Later bro."
    new "T(mik|tu|say): Mais tarde, mano."

    # say L848 whi
    old "Oh [pla] wait!"
    new "T(whi|formal|say): Oh [pla] espere!"

    # say L850 whi
    old "It's very late, so I figured you were gonna stay for dinner."
    new "B:pla: Sim, Sra. White?"

    # say L851 whi
    old "The food is served already, so you can't say no."
    new "B:whi: É muito tarde, por isso pensei que ias ficar para jantar."

    # say L853 pla
    old "Oh, all right, thank you."
    new "A:whi: Gostas do jantar de hoje?"

    # say L869 whi
    old "Do you like today's dinner?"
    new "B:pla: Oh, tudo bem, obrigado."

    # say L871 pla
    old "Yeah, it's very good Mrs. White, thanks a lot."
    new "B:whi: Gostaste do jantar de hoje?"

    # say L872 mik
    old "He's right mom, it's really good."
    new "B:pla: Sim, está muito bom, Sra. White, obrigado."

    # say L874 mik
    old "Excuse me, let me go to the bathroom real quick."
    new "B:mik: Ele tem razão, mãe, está mesmo bom."

    # say L888 pla
    old "Woah! What are you doing Mrs. White?"
    new "B:mik: Desculpa, vou à casa de banho um bocadinho."

    # say L889 pla
    old "We're in the middle of dinner! Mike could come back at any second!"
    new "B:pla: Woah! O que estás a fazer, Sra. White?"

    # say L890 whi
    old "Oh relax, Mike always takes his time in the bathroom."
    new "B:pla: Estamos no meio do jantar! O Mike pode voltar a qualquer momento!"

    # say L891 whi
    old "I don't know exactly what he does there, but he'll be there for a while."
    new "B:whi: Oh, relaxa, o Mike sempre demora no autocarro de banho."

    # say L892 pla
    old "Still, we're in the dining room..."
    new "B:whi: Não sei exatamente o que ele faz lá, mas vai ficar um bom tempo."

    # say L893 whi
    old "So? Nobody will see us, just enjoy it."
    new "B:pla: Ainda estamos na sala de jantar..."

    # say L909 pla
    old "Uhh, Mrs. White you have some... Uhh... In your face..."
    new "B:whi: Então? Ninguém vai ver, só aproveita."

    # say L917 whi
    old "Right, [pla]?"
    new "B:whi: Está tudo bem, querida, [pla] e eu tivemos uma conversa muito agradável."

    # say L919 whi
    old "Oh! Heh silly me. I just love the taste of it!"
    new "B:mik: Mãe, por que tens tanta maionese na cara?"

    # say L926 mik
    old "I know mom, we all know you really like mayo"
    new "B:whi: Oh! Heh, que bobo. Eu adoro o sabor!"

    # say L927 whi
    old "Yeah, mayo. Of course..."
    new "B:mik: Eu sei, mãe, todos sabemos que tu gostas muito de maionese"

    # say L937 pla
    old "Once again, it was all very good Mrs. White."
    new "B:whi: Sim, maionese. Claro..."

    # say L938 pla
    old "Thanks a lot!"
    new "B:pla: Mais uma vez, tudo foi muito bom, Sra. White."

    # say L939 whi
    old "My pleasure sweety, it was good seeing you again."
    new "B:pla: Muito obrigado!"

    # say L940 whi
    old "And as you could see, I also think everything was delicious..."
    new "B:whi: Com todo o prazer, minha querida, foi bom ver-te de novo."

    # say L941 pla
    old "...Sure."
    new "B:whi: E como pudeste ver, também acho que tudo estava delicioso..."

    # say L942 pla
    old "Mike, I think I'll head home dude, I'll come back another time to keep studying."
    new "B:pla:...Claro."

    # say L943 mik
    old "Sure dude, have a good night."
    new "B:pla: Mike, acho que vou para casa, volto noutra altura para continuar a estudar."

    # say L944 whi
    old "And remember to come back soon... You're always welcome."
    new "B:mik: Claro, boa noite."

    # say L945 pla
    old "Uuuh... thank you."
    new "B:whi: E lembra-te de voltar depressa... Tu és sempre bem-vindo."

    # say L963 pla
    old "Hi Mrs. White, is Mike around?"
    new "B:pla: Uuuh... obrigado."

    # say L966 pla
    old "What? Why not?"
    new "B:whi: Bem, o Mike está em casa. Mas acho que não pode ver-te agora."

    # say L967 whi
    old "Well, he's got some company."
    new "B:pla: O quê? Porquê?"

    # say L968 whi
    old "A girl came to see him, and they locked themselves in his room."
    new "B:whi: Bem, ele tem companhia."

    # say L969 whi
    old "He told me that I shouldn't bother him or even knock on the door."
    new "B:whi: Uma rapariga veio vê-lo, e eles trancaram-se no quarto dele."

    # say L970 pla
    old "Ohh, that's right, he told me Olivia was gonna come today, I don't know how I forgot about it."
    new "B:whi: Ele disse que eu não devo incomodá-lo ou sequer bater à porta."

    # say L971 pla
    old "Ok, then I guess I'll come later, see you Mrs. White."
    new "B:pla: Ohh, isso mesmo, ele disse-me que a Olivia ia vir hoje, não sei como me esqueci disso."

    # say L972 whi
    old "Wait a minute!"
    new "T(whi|formal|say): Espera um momento!"

    # say L973 pla
    old "Uhh... yes?"
    new "B:whi: Espera aí!"

    # say L974 whi
    old "How are you leaving after you just arrived? Don't be silly."
    new "B:pla: Uhh... sim?"

    # say L975 whi
    old "You're going to help me move some other boxes in my room."
    new "B:whi: Como é que vais embora depois de acabares de chegar? Não sejas parvo."

    # say L976 pla
    old "What? What are you talking about? Mike's here!"
    new "B:whi: Vais ajudar-me a mover algumas caixas no meu quarto."

    # say L977 whi
    old "So? They just went up to his room a couple of minutes ago."
    new "A:whi: Quanto tempo achas que a sessão de estudo vai durar?"

    # say L978 whi
    old "How long do you think the study session will last?"
    new "B:whi: Então? Eles só subiram para o quarto dele há uns minutos."

    # say L979 pla
    old "Well... It should take a while, because the subject is a little long."
    new "B:whi: Quanto tempo achas que a sessão de estudo vai durar?"

    # say L981 whi
    old "See? Nothing's going to happen."
    new "B:pla: Bem... Vai demorar um pouco, porque o assunto é um pouco longo."

    # say L982 whi
    old "Besides, if they finish early, all I have to do is tell him I'm in my room and don't want him to go in."
    new "B:whi: Vês? Não vai acontecer nada."

    # say L983 pla
    old "Still, I don't think we..."
    new "B:whi: Além disso, se eles acabarem cedo, basta eu dizer que estou no meu quarto e não quero que ele entre."

    # say L984 whi
    old "Enough talking, you worry too much. Just come with me to the room."
    new "B:pla: Ainda assim, não acho que devamos..."

    # say L985 whi
    old "I know you'll love it."
    new "B:whi: Chega de falar, tu preocupas-te demasiado. Vem comigo para o quarto."

    # say L997 pla
    old "(Oh man, I just fucked my best friend's mom... I can't believe I'm doing this to Mike.)"
    new "B:whi: Eu sei que vais adorar."

    # say L998 pla
    old "(Jeez, honestly... I'm ok with helping Mike, but damn, this is getting dangerous.)"
    new "B: (Oh, homem, acabei de foder a mãe do meu melhor amigo... Não posso acreditar que estou a fazer isto ao Mike.)"

    # say L999 pla
    old "(I mean, I just can't even imagine what would happen if Mike caught us one day)"
    new "B:pla: (Puta merda, sinceramente... Estou bem com ajudar o Mike, mas cara, isto está a ficar perigoso.)"

    # say L1006 oli
    old "Ah! W- What are you doing here?"
    new "T(oli|tu|diz): Ah! W- O que estás a fazer aqui?"

    # say L1009 pla
    old "Uhh... Well, this is my friend's house."
    new "B:oli: Ah! Q- Que estás a fazer aqui?"

    # say L1010 pla
    old "So, I came to see him."
    new "B:pla: Uhh... Bem, esta é a casa do meu amigo."

    # say L1011 pla
    old "And you? Did you come to study with him, right? "
    new "B:pla: Então, vim vê-lo."

    # say L1013 oli
    old "I... uhh..."
    new "B:pla: E tu? Vieste estudar com ele, certo?"

    # say L1014 oli
    old "What do you care? I can come and go wherever I want."
    new "B:oli: I... uhh..."

    # say L1015 oli
    old "And I'm leaving now!"
    new "B:oli: E daí? Posso ir e vir onde quiser."

    # say L1026 oli
    old "By the way! You better not tell anybody about me being here!"
    new "E eu estou a ir-me embora!"

    # say L1027 oli
    old "Or you'll hear about me, you got that fucking nerd?"
    new "B:oli: Por acaso! Melhor não contares a ninguém que estou aqui!"

    # say L1028 pla
    old "Sure, sure whatever you say."
    new "B:oli: Ou vais ouvir falar de mim, percebeste bem, nerd da merda?"

    # say L1044 mik
    old "Oh [pla], what's up man? I didn't know you were here."
    new "T(mik|tu|say): Oh [pla], o que se passa, mano? Não sabia que estavas aqui."

    # say L1046 pla
    old "I forgot that you were going to see Olivia today."
    new "B:pla: Uh, yeah, eu vim ver-te."

    # say L1047 pla
    old "By the way, how did it go?"
    new "B:pla: Esqueci-me que ias ver a Olivia hoje."

    # say L1049 mik
    old "Aww man! It was awesome!"
    new "B:pla: Por acaso, como correu?"

    # say L1051 mik
    old "I'm telling you [pla], I'm winning her over."
    new "T(mik|tu|dizer): Estou a dizer-te [pla], estou a conquistá-la. A:mik: Mas enfim, podemos continuar a falar disso enquanto jantamos."

    # say L1054 pla
    old "Uh what? Dinner? I- I don't think I can."
    new "B:mik: Mas enfim, podemos continuar a falar disso enquanto jantamos."

    # say L1055 mik
    old "Come on, you know it's no trouble. My mom will be happy to have you here."
    new "T(mik|tu|say): Vamos, sabes que não é problema. A minha mãe vai ficar contente por te ter aqui."

    # say L1056 pla
    old "I'm sure she will. But I promised my mother I would have dinner at our house tonight."
    new "T(pla|tu|say): Tenho a certeza que ela ficará contente. Mas prometi à minha mãe que jantaria em casa esta noite."

    # say L1057 pla
    old "I've been eating out too much, so I can't miss it tonight."
    new "B:pla: Tenho a certeza que sim. Mas prometi à minha mãe que jantaria em casa esta noite."

    # say L1059 mik
    old "Uhh, all right, next time then."
    new "B:pla: Tenho comido fora demais, por isso não posso faltar esta noite."

    # say L1060 mik
    old "See you later then bud."
    new "T(mik|tu|say): Até mais então, meu."

    # say L1061 pla
    old "Sure man, see you."
    new "T(pla|tu|say): Claro, até já."

    # say L1081 pla
    old "So I figured I should go."
    new "B:pla: Sim, Sra. White, acabámos agora."

    # say L1082 whi
    old "Oh don't be silly!"
    new "B:pla: Então achei que devesse ir."

    # say L1083 whi
    old "I already finished the dinner."
    new "B:whi: Ah, não sejas parvo!"

    # say L1084 whi
    old "And you know I want you to stay."
    new "B:whi: Já terminei o jantar."

    # say L1086 pla
    old "L- Listen Mrs. White, I already told my mom I was going to have dinner with her and sh..."
    new "B:whi: E sabes que quero que fiques."

    # say L1087 whi
    old "I'm sure your mother will understand that I invited you."
    new "B:pla: L- Escuta, Sra. White, já disse à minha mãe que ia jantar com ela e..."

    # say L1088 whi
    old "Come on. Let's have dinner."
    new "B:whi: Tenho a certeza de que a tua mãe compreenderá que te convidei."

    # say L1103 mik
    old "This is really good mom."
    new "B:whi: Vamos. Vamos jantar."

    # say L1104 mik
    old "I don't know what's happened, but you've been making some awesome food these days."
    new "B:mik: Isto está mesmo bom, mãe."

    # say L1105 whi
    old "I don't know what you mean by that, my food is always delicious."
    new "B:mik: Não sei o que aconteceu, mas tens feito comida incrível ultimamente."

    # say L1106 whi
    old "You're going to make your friend think that my cooking is usually bad."
    new "B:whi: Não sei o que queres dizer com isso, a minha comida é sempre deliciosa."

    # say L1107 mik
    old "What? Of course not."
    new "T(mik|tu|say): Que? Claro que não."

    # say L1108 mik
    old "All I'm saying is the meals are extra special these days."
    new "T(mik|tu|dizes): Só estou a dizer que as refeições têm sido especiais nestes dias."

    # say L1110 whi
    old "Well, I have to put in some effort, we've been having an extra special guest..."
    new "B:mik: O que estou a dizer é que as refeições têm sido especiais ultimamente."

    # say L1111 mik
    old "Ha! My mom likes you dude."
    new "B:whi: Bem, tenho de fazer um esforço, temos tido um convidado especial..."

    # say L1112 pla
    old "(You have no idea...)"
    new "T(pla|tu|say): (Tu não sabes...)"

    # say L1130 pla
    old "Oh come on..."
    new "B:mik: Espera aí, vou atender esta chamada."

    # say L1139 pla
    old "W- What are you doing Mrs. White?"
    new "B:pla: Oh, vamos lá..."

    # say L1140 whi
    old "What? This is just like last time."
    new "B:pla: W- O que estás a fazer, Sra. White?"

    # say L1141 whi
    old "You know he'll take a while."
    new "B:whi: O quê? Isto é igual à última vez."

    # say L1142 whi
    old "So, we can have a little bit of fun."
    new "B:whi: Sabes que ele vai demorar."

    # say L1143 pla
    old "No, no, no. This isn't like last time. He only left to pick up a call."
    new "B:whi: Então, podemos nos divertir um pouco."

    # say L1144 pla
    old "Which means it won't be long."
    new "B:pla: Não, não, não. Isto não é como da última vez. Ele só saiu para atender uma chamada."

    # say L1145 pla
    old "Mrs. White please stop!"
    new "B:pla: O que significa que não vai demorar muito."

    # say L1146 whi
    old "Well, I could stop."
    new "B:pla: Sra. White, por favor, pare!"

    # say L1147 whi
    old "But this hard dick tells me you want me to do it anyway."
    new "B:whi: Bem, eu poderia parar."

    # say L1149 whi
    old "Just relax, it won't take long."
    new "A:mik: Onde é que a minha mãe foi?"

    # say L1171 mik
    old "Where did my mom go?"
    new "B:whi: Relaxa, não vai demorar."

    # say L1172 pla
    old "Uhhh... S- she went to the... bathroom. Yeah, she said she needed to go."
    new "T(pla|tu|say): Uhhh... E- ela foi à... casa de banho. Sim, ela disse que precisava ir."

    # say L1173 mik
    old "But I came from there, and I didn't see her enter."
    new "B:pla: Uhhh... E-ele foi ao... wc. Sim, disse que precisava ir."

    # say L1176 pla
    old "She... must be using the one in her bedroom."
    new "B:mik: Mas eu vim daí e não a vi entrar."

    # say L1177 pla
    old "I think she went upstairs."
    new "A:mik: Hmm. Acho que ela foi para o andar de cima."

    # say L1178 mik
    old "Hmm."
    new "B:pla: Acho que ela subiu as escadas."

    # say L1180 mik
    old "Yeah you're right."
    new "T(mik|tu|say): Sim, tens razão."

    # say L1197 pla
    old "(Damn, I can't believe she actually gave me a blowjob and made me cum with Mike here!)"
    new "T: (Merda, não posso acreditar que ela me deu uma boquete e me fez gozar com o Mike aqui!)"

    # say L1198 pla
    old "(I need to think about something or Mike will really catch us.)"
    new "B: (Merda, não posso acreditar que ela me deu uma chupada e me fez gozar com o Mike aqui!)"

    # say L1199 pla
    old "You know what Mike? I think I could really use a headache pill."
    new "T: Sabes o que, Mike? Acho que preciso mesmo de uma aspirina."

    # say L1200 pla
    old "If you have anything here that I could take it would be good."
    new "B:pla: Sabes o que, Mike? Acho que podia mesmo precisar de uma aspirina."

    # say L1201 mik
    old "Hmm, let me check the cabinet in the bathroom."
    new "B:pla: Se tens algo aqui que eu possa levar, seria bom."

    # say L1209 whi
    old "A headache? That was a good idea."
    new "B:mik: Hmm, deixa-me ver o armário da casa de banho."

    # say L1210 pla
    old "Why are you so chirpy? I told you he was going to come back!"
    new "B:whi: Uma dor de cabeça? Foi uma boa ideia."

    # say L1211 whi
    old "Awww, my baby boy was scary, don't worry sweetie."
    new "B:pla: Porque estás tão alegre? Eu disse-te que ele ia voltar!"

    # say L1212 whi
    old "Next time I see you I'll give you something in return for this."
    new "B:whi: Awww, o meu menino estava assustado, não te preocupes, querida."

    # say L1213 pla
    old "Hmph, this isn't about that."
    new "B:whi: Da próxima vez que nos virmos, eu dou-te algo em troca disto."

    # say L1218 mik
    old "Sorry dude, we don't have anything like that."
    new "B:pla: Hmph, isto não tem nada a ver com isso."

    # say L1219 mik
    old "Mom, you're back."
    new "T(mik|tu|dizer): Mãe, tu já estás de volta."

    # say L1221 mik
    old "I thought you had gone to sleep."
    new "B:mik: Mãe, tu já voltaste."

    # say L1223 whi
    old "Oh no, it's just that I had to go to the bathroom. But I came back to finish my dinner."
    new "B:mik: Pensei que já tivesses ido dormir."

    # say L1224 whi
    old "By the way, you should finish yours too, before it gets cold."
    new "B:whi: Oh não, é que tive de ir à casa de banho. Mas voltei para acabar o jantar."

    # say L1225 mik
    old "I know, I know, I was just getting a pill for [pla], where do we keep then?"
    new "T(mik|tu|say): Eu sei, eu sei, estava só a buscar um comprimido para [pla], onde é que os guardamos?"

    # say L1228 pla
    old "I don't think I'll need it, the headache is gone."
    new "B:pla: Sabes o que, mano?"

    # say L1230 whi
    old "Yeah, all you needed was to relax and release everything as Mike said."
    new "B:pla: Acho que não vou precisar, a dor de cabeça passou."

    # say L1232 mik
    old "Yeah, that's what I sai-... Wait how do you know-"
    new "B:whi: Sim, tudo o que precisavas era relaxar e libertar tudo como o Mike disse."

    # say L1233 whi
    old "Oh, honey, I'm really hungry and the food is gonna get cold. Why don't we finish this delicious dinner?"
    new "B:mik: Sim, é o que eu di-... Espera, como é que tu sabes-"

    # say L1234 pla
    old "Yeah, dude, just enjoy the dinner."
    new "B:whi: Oh, querida, estou com muita fome e a comida vai esfriar. Por que não terminamos este jantar delicioso?"

    # say L1242 pla
    old "As always Mrs. White, your food is always the best."
    new "B:pla: Claro, cara, aproveita a janta."

    # say L1244 whi
    old "It's very good that you always enjoy... Everything I give you sweety."
    new "B:pla: Como sempre, Sra. White, a sua comida é sempre a melhor."

    # say L1245 whi
    old "It always makes me want to give you some more..."
    new "B:whi: É muito bom que tu sempre gostes... De tudo o que te dou, querida."

    # say L1246 pla
    old "Uh... yeah, thank you."
    new "B:whi: Isso sempre me deixa com vontade de te dar mais..."

    # say L1247 pla
    old "Well, it's very late, so I shold go now."
    new "B:pla: Uh... yeah, thank you."

    # say L1248 mik
    old "Sure man, no problem. Thanks for today."
    new "B:pla: Bem, já é muito tarde, então devo ir agora."

    # say L1267 pla
    old "Hi Mrs.White, how are you?"
    new "B:mik: Claro, sem problemas. Obrigado por hoje."

    # say L1268 whi
    old "Hi sweetie, I'm very well, thank you."
    new "B:pla: Olá Sra. White, como está?"

    # say L1269 whi
    old "Let me guess, you came to study with Mike again."
    new "B:whi: Olá querida, estou muito bem, obrigada."

    # say L1270 pla
    old "Yeah, is he here?"
    new "T(pla|tu|say): Sim, ele está aqui?"

    # say L1271 whi
    old "I'm sorry, but he isn't, he went out with that girl Olivia."
    new "B:pla: Sim, ele está aqui?"

    # say L1273 pla
    old "Hmm... I see."
    new "B:whi: Desculpa, mas ele não está, saiu com aquela rapariga, a Olivia."

    # say L1274 pla
    old "I suppose I should come later then, right?"
    new "T(pla|tu|say): Suponho que devo vir mais tarde, certo?"

    # say L1275 whi
    old "Oh, why do you ask that when you already know the answer?"
    new "B:pla: Suponho que devo vir mais tarde, certo?"

    # say L1276 whi
    old "No my sweet boy, you're not going anywhere."
    new "B:whi: Oh, porquê perguntas isso quando já sabes a resposta?"

    # say L1277 whi
    old "We're going to finish what we started the other night at dinner."
    new "B:whi: Não, meu querido, tu não vais a lado nenhum."

    # say L1279 whi
    old "Come here sweetie, I want you right now."
    new "B:whi: Vamos terminar o que começámos na outra noite jantar."

    # say L1280 pla
    old "What? Here?"
    new "B:whi: Vem aqui querida, quero-te agora."

    # say L1281 whi
    old "Sure! Why not? We're alone and Mike will take his time."
    new "B:pla: O quê? Aqui?"

    # say L1282 pla
    old "B- but... I- I mean, he could come back early... or he could"
    new "B:whi: Claro! Porquê não? Estamos sozinhos e o Mike vai demorar."

    # say L1284 whi
    old "That's enough, Mike doesn't even suspect a thing and you're always worrying."
    new "B: B- mas... eu- eu quero dizer, ele pode voltar mais cedo... ou ele pode"

    # say L1285 whi
    old "So stop thinking so much and just get naked."
    new "B:whi: Chega, o Mike nem desconfia e tu estás sempre preocupado."

    # say L1286 whi
    old "I want that big cock now!"
    new "B:whi: Então para de pensar tanto e despe-te."

    # say L1295 whi
    old "Ah yes! Look at how hard you already are."
    new "B:whi: Quero esse pau grande agora!"

    # say L1296 whi
    old "That big long dick."
    new "B:whi: Ah sim! Olha como já estás duro."

    # say L1297 whi
    old "I want you to put in me."
    new "B:whi: Esse pénis grande e comprido."

    # say L1298 whi
    old "I can't wait!"
    new "B:whi: Quero que me ponhas dentro de mim."

    # say L1313 pla
    old "Hi Mrs. White. It's good seeing you again."
    new "B:whi: Não aguento mais!"

    # say L1314 whi
    old "Hi sweety, are you here to see Mike?"
    new "B:pla: Olá Sra. White. É bom vê-la de novo."

    # say L1316 whi
    old "Well, I'm sorry to tell you that he's not available."
    new "B:whi: Olá querida, estás aqui para ver o Mike?"

    # say L1317 whi
    old "That girl Olivia came a while ago, and he was very clear that they shouldn't be interrupted."
    new "B:whi: Bem, sinto muito, mas ele não está disponível."

    # say L1320 whi
    old "But don't be sad, because you know what that means."
    new "B:whi: A rapariga Olivia veio há pouco tempo, e ele foi muito claro ao dizer que não devem ser interrompidos."

    # say L1321 whi
    old "It means you and I get to have some fun."
    new "B:whi: Mas não fiques triste, porque sabes o que isso significa."

    # say L1322 pla
    old "What?! Are you kidding me?!!"
    new "B:whi: Isso significa que tu e eu vamos poder nos divertir."

    # say L1323 pla
    old "After what happened last time. You still want to do it?!"
    new "B:pla: Que?! Estás a brincar comigo?!!"

    # say L1324 whi
    old "Aww, my baby boy is worried."
    new "B:pla: Depois do que aconteceu da última vez. Tu ainda queres fazê-lo?!"

    # say L1325 whi
    old "Don't worry, this time we'll do it in my bedroom, so what happened last time won't happen again."
    new "B:whi: Aww, o meu menino está preocupado."

    # say L1326 pla
    old "Hmm, but what happens if they finish before us and they hear us?"
    new "B:whi: Não te preocupes, desta vez fazemos no meu quarto, assim o que aconteceu da última vez não se repetirá."

    # say L1327 pla
    old "I mean... How long have they been up there?"
    new "B:pla: Hmm, mas e se eles acabarem antes de nós e nos ouvirem?"

    # say L1328 whi
    old "Hmm, to be honest I didn't really look at the clock."
    new "B:pla: Quero dizer... Há quanto tempo eles estão lá em cima?"

    # say L1329 pla
    old "I don't think we should do anything without knowing how long they'll be there."
    new "B:whi: Hmm, a ser sincero, nem olhei para o relógio."

    # say L1331 whi
    old "You're thinking too much, just relax a little."
    new "B:pla: Não acho que devamos fazer nada sem saber quanto tempo eles vão ficar."

    # say L1332 pla
    old "I can't, after what happened last time, we need to be sure... And I have an idea."
    new "T(pla|tu|say): Não consigo, depois do que aconteceu da última vez, precisamos ter a certeza... E tenho uma ideia."

    # say L1333 pla
    old "Let me go upstairs and check on them first."
    new "B:pla: Não posso, depois do que aconteceu da última vez, precisamos ter a certeza... E tenho uma ideia."

    # say L1334 whi
    old "Hmm, ok. Do that and let me know."
    new "B:pla: Deixa-me subir e ver como eles estão primeiro."

    # say L1346 pla
    old "Damn, I didn't think Mike and Olivia were really going to do anything."
    new "T: Merda, não pensei que o Mike e a Olivia fossem mesmo fazer algo."

    # say L1347 pla
    old "Well, I guess all that work really paid off. I'm happy for him."
    new "B:pla: Merda, não pensei que o Mike e a Olivia fossem mesmo fazer algo."

    # say L1356 whi
    old "So? What topic are they on?"
    new "B:pla: Bem, acho que todo esse trabalho realmente valeu a pena. Estou feliz por ele."

    # say L1357 pla
    old "Hmm, let's just say they'll be busy for a while."
    new "B:whi: Então? De que tema é que eles estão a falar?"

    # say L1358 pla
    old "So, I think we'll be fine."
    new "B:pla: Hmm, vamos dizer que vão estar ocupados por um bom tempo."

    # say L1360 whi
    old "Really? Perfect! Let's go to my room then!"
    new "B:pla: Então, acho que vamos ficar bem."

    # say L1378 oli
    old "Whoa! Whoa! Whoa!"
    new "B:whi: Mesmo? Perfeito! Vamos para o meu quarto então!"

    # say L1385 pla
    old "Fuck! She saw us, I have to go after her!"
    new "B:oli: Quem! Quem! Quem!"

    # say L1397 pla
    old "Olivia! Wait!"
    new "B:pla: Merda! Ela viu-nos, tenho que ir atrás dela!"

    # say L1400 oli
    old "Dude! What the fuck!"
    new "B:pla: Olivia! Espera!"

    # say L1401 oli
    old "You're fucking your friend's mother?! What the fuck is wrong with you."
    new "Não é o que estás a pensar! Nós só..."

    # say L1403 pla
    old "It's not what you think! We're just..."
    new "Tu: Não é como pensas! Nós estamos só..."

    # say L1404 oli
    old "You're just what? I saw you dude!"
    new "B:pla: Não é o que tu penses! Nós estamos só..."

    # say L1405 oli
    old "I saw your big coc-... your penis hanging out, and jizz everywhere."
    new "B:oli: Tu estás a brincar? Vi-te, cara!"

    # say L1406 pla
    old "Ok, listen, I was doing that, but please you can't tell Mike."
    new "B:oli: Vi o teu pénis grande a sair e sêmen por todo o lado."

    # say L1407 pla
    old "Please! I'm begging you! He'll never forgive me!"
    new "B:pla: Ok, escuta, eu estava a fazer isso, mas por favor não podes contar ao Mike."

    # say L1408 oli
    old "Well, maybe you should've thought about that before fucking his mom."
    new "B:pla: Por favor! Estou a implorar-te! Ele nunca me perdoará!"

    # say L1409 pla
    old "Oh, come on! You wouldn't get anything by telling him that!"
    new "B:oli: Bem, talvez devesse ter pensado nisso antes de foder a mãe dele."

    # say L1410 oli
    old "Perhaps I would, who knows?"
    new "T(oli|tu|dizes): Talvez, quem sabe?"

    # say L1411 oli
    old "I guess you would be willing to do anything in exchange for me not telling him anything, right?"
    new "T(oli|tu|dizes): Acho que tu farias qualquer coisa em troca de eu não contar nada a ele, certo?"

    # say L1413 oli
    old "Right?!!!!"
    new "B:oli: Acho que tu estarias disposto a fazer qualquer coisa em troca de eu não contar nada a ele, certo?"

    # say L1414 pla
    old "I would, I would, I'd do anything, just please don't tell Mike."
    new "T: Tu, eu faria, eu faria, eu faria qualquer coisa, só por favor não contes ao Mike."

    # say L1417 oli
    old "Listen, I'm leaving now, I can't waste my time on you."
    new "B:pla: Eu faria, eu faria, eu faria qualquer coisa, por favor, não contes ao Mike."

    # say L1418 oli
    old "I'm not going to tell him anything... For now."
    new "B:oli: Ouve, estou a sair agora, não posso perder o meu tempo contigo."

    # say L1419 oli
    old "We'll see if that changes later."
    new "B:oli: Não vou dizer-lhe nada... Por agora."

    # say L1425 pla
    old "Oh, gosh, I'm fucked.."
    new "Oh, merda, estou ferrado.."

    # say L1426 pla
    old "(Damn it! She just saw me fucking my best friends mom!)"
    new "B:pla: Oh, gosh, I'm fucked.."

    # say L1427 pla
    old "(I have to do something...)"
    new "B: (Merda! Ela acabou de me ver a foder a mãe do meu melhor amigo!)"

    # say L1428 pla
    old "(I have to try and convince her someway not to tell Mike.)"
    new "B:pla: (Tenho de fazer algo...)"

    # say L1435 mik
    old "Hey man, what's up?"
    new "B:pla: (Tenho que tentar convencê-la de alguma forma a não contar ao Mike.)"

    # say L1437 mik
    old "Did you run into Olivia again?"
    new "B:mik: E aí, mano, tudo bem?"

    # say L1438 pla
    old "Uhh, yeah... Sorry dude."
    new "Uhh, sim... Desculpa, mano."

    # say L1439 mik
    old "It's ok dude."
    new "T(mik|tu|say): Tudo bem, mano."

    # say L1440 mik
    old "I already talked to her about it."
    new "T(mik|tu|dizer): Já falei com ela sobre isso."

    # say L1441 mik
    old "I told her that you've been helping me. So don't worry, we're fine."
    new "T(mik|tu|dizer): Disse-lhe que tu tens estado a ajudar-me. Portanto, não te preocupes, estamos bem."

    # say L1442 pla
    old "I see... well, that's very cool dude."
    new "B:mik: Eu disse a ela que tu tens estado a ajudar-me. Portanto, não te preocupes, estamos bem."

    # say L1443 mik
    old "Yeah... I guess it is."
    new "B:pla: Entendo... bem, isso é muito fixe."

    # say L1444 pla
    old "Hey man, listen, today is a little late, so how about we study another time?"
    new "T(pla|tu|say): Ei, mano, hoje está um pouco tarde, então que tal estudarmos noutra altura?"

    # say L1446 mik
    old "Actually, we don't have to do that for now."
    new "T(mik|tu|say): Na verdade, não precisamos fazer isso agora."

    # say L1447 pla
    old "Really? Why?"
    new "A:mik: A Olivia vai fazer uma viagem."

    # say L1448 mik
    old "Olivia's going on a trip."
    new "T(mik|tu|diz): A Olivia vai fazer uma viagem."

    # say L1449 mik
    old "She's going to be out of time for a while."
    new "B:mik: A Olivia vai fazer uma viagem."

    # say L1451 mik
    old "So I don't think you don't have to worry for now."
    new "B:mik: Ela vai estar fora de tempo por um tempo."

    # say L1453 pla
    old "That's a relief, I gues..."
    new "T: É um alívio, acho..."

    # say L1455 pla
    old "I- I mean... I see... Um, sorry dude. That sucks."
    new "B:pla: Que alívio, acho eu..."

    # say L1457 mik
    old "Are you kidding me? Dude, it has been awesome spending time with her."
    new "T(mik|tu|dizer): Estás a brincar comigo? Cara, tem sido incrível passar tempo com ela. E eu sei ao certo que ela gosta de mim."

    # say L1458 mik
    old "And I know for a fact that she likes me."
    new "B:mik: Estás a brincar comigo? Cara, foi incrível passar tempo com ela."

    # say L1459 mik
    old "So, I'm sure I'll see her again when this is over."
    new "T(mik|tu|say): Então, tenho a certeza que a verei de novo quando isto acabar."

    # say L1460 pla
    old "So am I..."
    new "B:mik: Então, tenho a certeza que a verei de novo quando isto acabar."

    # say L1470 pla
    old "But she said she wasn't going to tell anything to him."
    new "B:pla: Sim, fiz com a Sra. White, e sei que estás preocupado com isso."

    # say L1471 pla
    old "At least for now..."
    new "B:pla: Mas ela disse que não ia contar nada a ele."

    # say L1472 whi
    old "I don't know, what if she tells him? He's going to kill me!"
    new "B:pla: Pelo menos por agora..."

    # say L1473 pla
    old "Hey, it's ok, let me handle it. Ok?"
    new "B:whi: Não sei, e se ela contar a ele? Ele vai me matar!"

    # say L1475 whi
    old "Ok, I trust you."
    new "A:pla: Ouve, já é muito tarde e a minha mãe quer jantar comigo."

    # say L1477 pla
    old "Listen, it's very late already, and my mom wants me to eat with her."
    new "B:whi: Ok, confio em ti."

    # say L1478 pla
    old "So I'll be on my way home, and I'll see you later."
    new "B:pla: Ouve, já é muito tarde e a minha mãe quer jantar comigo."

    # say L1479 pla
    old "Just try not to worry too much and just let me handle this. Ok?"
    new "B:pla: Vou a caminho de casa, e vejo-te mais tarde."

    # say L1481 whi
    old "Ok, ok, I'll try not to think about it."
    new "B:pla: Não te preocupes tanto e deixa-me lidar com isso. Ok?"

    # say L1482 whi
    old "Bye. I'll see you later baby boy."
    new "Tchau. Vejo-te mais tarde, meu querido."


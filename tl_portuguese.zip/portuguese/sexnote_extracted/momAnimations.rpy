# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/momAnimations.rpy
translate portuguese strings:

    # say L7 mo1
    old "Oh yes, just like that. Does it feel nice hun?"
    new "Mmmm sim, sinto-me mesmo bem."

    # say L8 pla
    old "Mmmm yeah, it feels really nice."
    new "B:mo1: Oh sim, assim mesmo. Sentes-te bem, querida?"

    # say L9 mo1
    old "Great, just relax and enjoy the... Uhmm massage."
    new "B:pla: Mmmm sim, está mesmo bom."

    # say L13 mo1
    old "Let me do it a bit faster."
    new "B:mo1: Ótimo, só relaxa e aproveita a... Hmm massagem."

    # say L17 mo1
    old "Uhmm? does it hurt darling??"
    new "B:mo1: Deixa-me fazer um pouco mais rápido."

    # say L18 pla
    old "No, no, don't worry. It feels better."
    new "B:mo1: Hmm? dói querida??"

    # say L19 mo1
    old "Ohh, ok, I'm glad."
    new "B:pla: Não, não, não te preocupes. Sente-se melhor."

    # say L28 pla
    old "Ohhh yes, yes, just like this."
    new "B:mo1: Ohh, claro meu amor."

    # say L29 mo1
    old "I can feel that body is tensing up. You can release your load whenever you want, darling."
    new "B:pla: Ohhh sim, sim, assim mesmo."

    # say L55 pla
    old "Ahhh... Ahhhh!"
    new "B:mo1: Tudo bem querida, deixa tudo ir."

    # say L60 mo1
    old "Mmmm, good job honey. You did it just great."
    new "B:pla: Ahhh... Ahhhh!"

    # say L67 pla
    old "Thanks."
    new "Obrigada. Tu és bem-vindo, meu amor, espero que te sintas melhor agora."

    # say L68 mo1
    old "You are welcome honey, I hope you feel better now."
    new "B:pla: Obrigado."

    # say L69 pla
    old "Yes, I do. although I'm feeling a bit tired."
    new "B:mo1: És bem-vinda, querida, espero que te sintas melhor agora."

    # say L70 mo1
    old "Aww, don't worry hun, just rest a little."
    new "B:pla: Sim, estou. Embora esteja um pouco cansado."

    # say L76 mo1
    old "You are welcome. Well, if you need me, you know where to find me."
    new "A:mo1: Oh meu Deus, não posso acreditar no tamanho."

    # say L98 mo1
    old "Oh my God, I can't believe how big it is."
    new "B:mo1: De nada. Bem, se precisares de mim, sabes onde me encontrar."

    # say L100 mo1
    old "Is the biggest I have ever seen."
    new "A:mo1: Gostas de como te estou a masturbar?"

    # say L105 mo1
    old "Do you like how I'm jerking you off?"
    new "B:mo1: É o maior que já vi."

    # say L106 pla
    old "... Y- yes it feels nice."
    new "B:mo1: Gostas de como estou a fazer-te uma masturbação?"

    # say L107 mo1
    old "Mmm, your cock looks really tasty."
    new "B:pla:... S- sim, é agradável."

    # say L113 mo1
    old "Are you getting close?"
    new "B:mo1: Mmm, o teu pénis parece mesmo apetitoso."

    # say L114 pla
    old "Uhh y- yes."
    new "T(pla|tu|say): Uh h- hã."

    # say L115 mo1
    old "Would you like to cum for me?"
    new "B:pla: Huh, s- sim."

    # say L164 mo1
    old "But... Now, let's finish watching this movie."
    new "B:mo1: Mmmm, fico contente que tenhas gostado..."

    # say L165 pla
    old "For sure."
    new "B:mo1: Mas... Agora, vamos acabar de ver este filme."

    # say L178 mo1
    old "Mmmm, it tastes really good."
    new "B:pla: Com certeza."

    # say L179 mo1
    old "Does it feels better than my hand, isn't it?"
    new "B:mo1: Mmmm, está mesmo bom."

    # say L180 pla
    old "Uhhh, yeah."
    new "B:mo1: Sentes-te melhor do que com a minha mão, não é?"

    # say L185 mo1
    old "Do you like to feel my warm and wet mouth?"
    new "B:pla: Uhhh, sim."

    # say L186 pla
    old "Ohhh, y- yes it feels amazing."
    new "B:mo1: Gostas de sentir a minha boca quente e molhada?"

    # say L187 mo1
    old "Then there is something that you are going to enjoy even more."
    new "B:pla: Ohhh, s-sim, está incrível."

    # say L192 mo1
    old "Mmmm, I love to suck your cock!"
    new "B:mo1: Então há algo que vais gostar ainda mais."

    # say L193 mo1
    old "Would you like to cum in my mouth?"
    new "B:mo1: Mmmm, adoro chupar o teu pénis!"

    # say L194 pla
    old "Wow, can I?"
    new "B:mo1: Queres gozar na minha boca?"

    # say L195 mo1
    old "Mmmm, please honey. I would love to taste all your load."
    new "B:pla: Wow, posso?"

    # say L234 pla
    old "Mmmm, [mo1rel], I feel like..."
    new "Mmmm, [mo1rel], sinto-me..."

    # say L239 mo1
    old "Glup... Whew, I had to swallow a lot."
    new "B:mo1: Glup... Uau, foi uma carga enorme."

    # say L245 mo1
    old "But now let's continue the movie."
    new "B:mo1: Fico contente que tenhas adorado..."

    # say L267 pla
    old "Is this a dream?"
    new "B:mo1: Mas agora vamos continuar o filme."

    # say L274 pla
    old "This view is amazing."
    new "B:pla: Holy shit! Olha para esses peitos a saltitar!"

    # say L303 pla
    old "Wow... That was a dream?"
    new "B:pla: Esta vista é incrível."

    # say L305 pla
    old "It was very strange because it felt very real..."
    new "B:pla: Uau... Foi um sonho?"

    # say L307 pla
    old "Anyway, I better go to sleep..."
    new "B:pla: Foi muito estranho porque pareceu muito real..."

    # say L326 pla
    old "Mmmm, it feels really nice."
    new "B:pla: De qualquer forma, melhor ir dormir..."

    # say L327 mo1
    old "Sorry, did you say something?"
    new "B:pla: Mmmm, sinto-me mesmo bem."

    # say L328 pla
    old "Uhmm, no, no sorry."
    new "B:mo1: Desculpa, disse algo?"

    # say L329 pla
    old "(Shit I better stay quiet)"
    new "B:pla: Hmm, não, não, desculpa."

    # say L369 mo1
    old "Wow honey, did you spill more sunscreen in my legs?"
    new "B:pla: (Merda, melhor ficar calado)"

    # say L370 pla
    old "(Oh shit...) Yes, I spilled more to make sure, you don't get sunburned."
    new "B:mo1: Wow, meu amor, tu derramaste mais protector solar nas minhas pernas?"

    # say L373 mo1
    old "Aww, you are a sweetheart."
    new "B:pla: (Oh shit...) Sim, derramei mais para ter a certeza de que não te queimas."

    # say L374 pla
    old "(Oh fuck that was close... Should I make another try?)"
    new "B:mo1: Aww, tu és um querido."

    # say L400 mo1
    old "Aww, thank you so much, see you later sweetheart."
    new "B:pla: Está feito, acho que agora estás perfeito."

    # say L445 pla
    old "Holy shit, I can't help it anymore..."
    new "Que merda?"

    # say L496 mo1
    old "What the fuck?"
    new "B:pla: Merda, não consigo mais..."

    # say L497 pla
    old "(Oh... Shit.)"
    new "B:mo1: Que raio?"

    # say L508 mo1
    old "You were rubbing your... With my ass?"
    new "B:pla: Desculpa, eu... eu..."

    # say L512 mo1
    old "I can't believe it! What's wrong with you?"
    new "B:mo1: Estavas a esfregar o teu... Com o meu rabo?"

    # say L513 pla
    old "Sorry... It was not my intention..."
    new "A:mo1: Não era tua intenção? Que merda?..."

    # say L515 mo1
    old "It wasn't your intention? What the fuck?..."
    new "B:pla: Desculpa... Não era minha intenção..."

    # say L516 mo1
    old "I... I'll clean it myself, I don't want to see you anymore..."
    new "B:mo1: Não foi tua intenção? Que merda?..."

    # say L519 pla
    old "Oh shit, I messed it up."
    new "B:mo1: Eu... Eu limpo isso sozinho, não quero ver-te mais..."

    # say L527 mo1
    old "Again?"
    new "B:pla: Oh merda, estraguei tudo."

    # say L533 mo1
    old "Oh honey again?"
    new "B:mo1: Outra vez?"

    # say L534 pla
    old "I'm sorry I couldn't resist, I can't control it"
    new "B:mo1: Oh querida, de novo?"

    # say L536 mo1
    old "Mmm... It's alright, just please try not to rub your... against my ass, ok?"
    new "B:pla: Desculpa, não consegui resistir, não consigo controlar-me."

    # say L540 mo1
    old "If you need to release it, you can ask my help or do it by yourself."
    new "B:mo1: Mmm... Está bem, mas por favor tenta não esfregar o teu... contra as minhas nádegas, ok?"

    # say L542 pla
    old "You're right... It was not my intention..."
    new "B:mo1: Se precisas de o libertar, podes pedir a minha ajuda ou fazê-lo tu mesmo."

    # say L544 mo1
    old "I know sweetheart don't worry..."
    new "B:pla: Tens razão... Não era minha intenção..."

    # say L546 mo1
    old "I'm going to clean myself."
    new "B:mo1: Eu sei, querida, não te preocupes..."

    # say L563 pla
    old "{i}W- what?{/i}"
    new "B:mo1: {i}Isso excita-te?{/i}"

    # say L571 pla
    old "{i}That's why we should stop.{/i}"
    new "B:mo1: {i}Se ela nos apanhar, mata-nos.{/i}"

    # say L572 mo1
    old "{i}Oh no, all of this is making me horny.{/i}"
    new "B:pla: {i}É por isso que devemos parar.{/i}"

    # say L604 mo1
    old "{i}Cum quietly!{/i}"
    new "B:pla: {i}...{/i}"

    # say L608 mo1
    old "{i}Wow, you still hard... We will need to do something else, right?{/i}"
    new "B:mo1: {i}Corre em silêncio!{/i}"

    # say L609 pla
    old "{i}Oh come on... No, please we should stop now...{/i}"
    new "B:mo1: {i}Wow, ainda estás duro... Vamos ter de fazer outra coisa, certo?{/i}"

    # say L610 mo1
    old "{i}Shut up, and take your pants off...{/i}"
    new "B:pla: {i}Oh, vamos... Não, por favor, devíamos parar agora...{/i}"

    # say L612 mo1
    old "{i}You will love this...{/i}"
    new "B:mo1: {i}Cala-te e tira as calças...{/i}"

    # say L624 pla
    old "{i}Holy Shit!{/i}"
    new "B:mo1: {i}Vais adorar isto...{/i}"

    # say L628 mo2
    old "Can't you see a movie quietly?"
    new "B:pla: Uhhh... Não, não, eu- eu estou só empolgado com o filme..."

    # say L629 pla
    old "Yes, yes I- I'm sorry."
    new "B:mo2: Não consegues ver um filme em silêncio?"

    # say L655 mo1
    old "{i}Are you ready for my oral creampie?{/i}"
    new "B:pla: {i}Quantos drinks tomaste?{/i}"

    # say L684 pla
    old "{i}Hell yeah, it was great...{/i}"
    new "B:mo1: {i}Uau, foi muito... Gostaste?{/i}"

    # say L685 mo1
    old "{i}Let's clean this mess quietly.{/i}"
    new "B:pla: {i}Claro, foi ótimo...{/i}"

    # say L698 mo2
    old "I thought it was stupid... Anyway I'm going bed."
    new "B:pla: Oh sim, foi incrível."

    # say L701 mo1
    old "Yes, good night honey, sleep well."
    new "B:mo2: Achava isso estúpido... De qualquer forma, vou para a cama."

    # say L703 pla
    old "Good night"
    new "B:mo1: Sim, boa noite querida, dorme bem."

    # say L718 mo1
    old "Do you like my tits, isn't it?"
    new "B: Boa noite"

    # say L719 mo1
    old "Well, I think you deserve a great titjob."
    new "B:mo1: Gostas dos meus peitos, não é?"

    # say L727 mo1
    old "Mmmm, I'm enjoying it too."
    new "A:mo1: Quer gozar nos meus peitos?"

    # say L732 mo1
    old "Would you like to cum on my tits?"
    new "B:mo1: Mmmm, estou a gostar também."

    # say L733 pla
    old "Oh yeah."
    new "B:mo1: Queres gozar nos meus peitos?"

    # say L760 mo1
    old "Oh yes! Cum all over me!"
    new "B:pla: Ughhh... Ahhh!"

    # say L764 mo1
    old "Wow you came a lot..."
    new "B:mo1: Oh sim! Ejacula em mim!"

    # say L765 mo1
    old "I'm glad you're still hard, because I need you inside of me now."
    new "B:mo1: Que incrível..."

    # say L767 mo1
    old "Come with me to the bed"
    new "B:mo1: Fico contente que ainda estejas duro, porque preciso de ti dentro de mim agora."

    # say L786 mo1
    old "Uhhh, yes, just like that."
    new "B:mo1: Vem comigo para a cama."

    # say L787 mo1
    old "I'm I can feel your cock inside me, and it feels amazing!"
    new "B:mo1: Uhhh, sim, assim mesmo."

    # say L792 mo1
    old "Mmmm, it feels so nice!"
    new "B:mo1: Eu sinto o teu pénis dentro de mim, e é incrível!"

    # say L793 mo1
    old "Oh yeah, don't stop baby, don't stop!"
    new "B:mo1: Mmmm, sente-se tão bem!"

    # say L798 mo1
    old "Ahhh, ahhh, yeah fuck me, fuck me!"
    new "B:mo1: Oh sim, não pares, não pares!"

    # say L828 mo1
    old "God, that was awesome."
    new "B:mo1: Mmmm... Estou quase, não pares."

    # say L835 mo1
    old "Let's rest a little."
    new "B:mo1: Meu Deus, isso foi incrível."

    # say L845 mo1
    old "That was a fantastic night honey."
    new "B:mo1: Vamos descansar um pouco."

    # say L847 pla
    old "Yes, I really enjoyed it."
    new "B:mo1: Foi uma noite fantástica, meu amor."

    # say L849 mo1
    old "Remember we must be careful, no one can know... Ok?"
    new "B:pla: Sim, realmente gostei."

    # say L851 pla
    old "Yes, don't worry."
    new "B:mo1: Lembra-te que temos de ser cuidadosos, ninguém pode saber... Ok?"

    # say L853 mo1
    old "Go to your room quietly to avoid suspicion."
    new "B:pla: Sim, não te preocupes."

    # say L855 pla
    old "You're right! I will."
    new "B:mo1: Vai para o teu quarto em silêncio para não levantar suspeitas."

    # say L864 mo1
    old "Oh no... I'm sorry, I'm really sorry ..."
    new "B:pla: Tens razão! Vou fazer isso."

    # say L866 pla
    old "What? Why?"
    new "B:mo1: Oh não... Desculpa, eu realmente sinto muito..."

    # say L868 mo1
    old "For what happened last night, it was definitely very bad, I drank too much and-"
    new "B:pla: O quê? Porquê?"

    # say L870 pla
    old "No, we both decided to do it, I also agreed."
    new "B:mo1: O que aconteceu ontem à noite foi definitivamente muito mau, bebi demasiado e-"

    # say L887 mo1
    old "Also yesterday I really enjoyed it and can't believe I haven't done it in so many years!"
    new "B:mo1: Se estás bem com isso, acho que eu também estou, certo?"

    # say L889 pla
    old "I also enjoyed it a lot."
    new "B:mo1: Ontem também adorei e não posso acreditar que não fiz isto há tantos anos!"

    # say L891 mo1
    old "Just be careful, I don't want anyone to notice, ok?"
    new "B:pla: Também gostei muito."

    # say L895 mo1
    old "Great honey, let's go, I have to prepare breakfast."
    new "B:mo1: Sê cuidadosa, não quero que ninguém note, ok?"

    # say L904 pla
    old "Cool."
    new "A:mo1: Ahhhh... É tão grande."

    # say L993 mo1
    old "Ahhhh... It's so big"
    new "B:pla: Fixe."

    # say L994 mo1
    old "Mmmm, it feels amazing!"
    new "B:mo1: Ahhhh... É tão grande..."

    # say L999 mo1
    old "Uhhh yeah, baby I love your cock."
    new "B:mo1: Mmmm, é incrível!"

    # say L1000 mo1
    old "Oh God, oh God! I'm so wet."
    new "B:mo1: Uhhh sim, bebé, adoro o teu pénis."

    # say L1005 mo1
    old "Yeah, yeah, I love having your cock inside me."
    new "B:mo1: Oh Deus, oh Deus! Estou tão molhada."

    # say L1006 mo1
    old "Ohh yeah, just like this..."
    new "B:mo1: Sim, sim, adoro ter o teu pénis dentro de mim."

    # say L1041 mo1
    old "Ahhh... Ahhh! I- I'm cumming!"
    new "B:mo1: Ohh sim, assim mesmo..."

    # say L1042 pla
    old "Ughhhh m- me too."
    new "B:mo1: Ahhh... Ahhh! E-Estou a gozar!"

    # say L1047 mo1
    old "Oh yes... It was really good."
    new "B:pla: Ughhhh m- me too."

    # say L1048 mo1
    old "But I want more!"
    new "B:mo1: Oh sim... Foi mesmo bom."

    # say L1067 mo1
    old "Ohhh God!"
    new "B:mo1: Mas eu quero mais!"

    # say L1068 mo1
    old "This is amazing!"
    new "B:mo1: Ohhh Deus!"

    # say L1073 mo1
    old "Uhh, I'll never get tired of this."
    new "B:mo1: Isto é incrível!"

    # say L1107 mo1
    old "Mmmm, let me try something."
    new "B:mo1: Ohhh meu Deus!"

    # say L1108 mo1
    old "I'm sure you will enjoy this."
    new "B:mo1: Mmmm, deixa-me experimentar algo."

    # say L1116 mo1
    old "Uhhh this feels even better."
    new "B:mo1: Tenho a certeza de que vais gostar disto."

    # say L1117 mo1
    old "Ohhh myy-"
    new "B:mo1: Uhhh, isto sente-se ainda melhor."

    # say L1122 mo1
    old "Mmmm, I learned this in college."
    new "A:mo1: Gostas de como me estou a mover?"

    # say L1123 mo1
    old "Do you like how I'm moving?"
    new "B:mo1: Mmmm, aprendi isto na faculdade."

    # say L1129 mo1
    old "Ahhh... Oh my God it feels so fucking goood!"
    new "B:mo1: Gostas de como estou a mover-me?"

    # say L1130 mo1
    old "Yeah, yeah, I'm getting close!"
    new "B:mo1: Ahhh... Oh meu Deus, isto sente-se tão bem!"

    # say L1154 mo1
    old "Yeah yeah! Let's cum together!"
    new "B:mo1: Sim, sim, estou quase!"

    # say L1156 mo1
    old "Yes, cum with mommy baby! Cum with me!"
    new "B:mo1: Sim sim! Vamos gozar juntos!"

    # say L1160 mo1
    old "Holly shit, that was amazing!"
    new "B:mo1: Sim, goza com a mamãzinha, bebé! Goza comigo!"

    # say L1161 pla
    old "Pheww... Ohh yeah."
    new "B:mo1: Holy shit, isso foi incrível!"

    # say L1176 mo1
    old "It's getting better and better!"
    new "B:pla: Pheww... Ohh yeah."

    # say L1177 mo1
    old "Ohh my God!"
    new "B:mo1: Está a ficar cada vez melhor!"

    # say L1182 mo1
    old "It's so big! Oh God I feel it so deep!"
    new "B:mo1: Oh meu Deus!"

    # say L1189 mo1
    old "Uhhh, yes, yes, fuck your mommy!"
    new "B:mo1: Oh sim, mais rápido, mais rápido! Foda-me mais forte!"

    # say L1214 mo1
    old "Ohhhh m- my God! I'm cumming!"
    new "B:mo1: Uhhh, sim, sim, foda a tua mãe!"

    # say L1215 pla
    old "Ughhh mee too!"
    new "B:mo1: Ohhhh m- meu Deus! Estou a gozar!"

    # say L1220 mo1
    old "Wow it was a huge load"
    new "A:mo1: Mmmm, tu ejascaste tudo em mim."

    # say L1221 mo1
    old "Mmmm, you cum all over me."
    new "B:mo1: Que carga incrível..."

    # say L1222 mo1
    old "Let's clean this up before someone comes."
    new "B:mo1: Mmmm, tu gozas todo em cima de mim."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/MomStory.rpy
translate portuguese strings:

    # say L11 mo1
    old "Hi honey! Your breakfast is ready!"
    new "T(mo1|formal|say): Olá querida! O teu pequeno-almoço está pronto!"

    # say L22 mo1
    old "You know she's pretty stressed. But only because she's not around enough since she's always working."
    new "B:mo1: Bem, acho que se passares algum tempo com ela, isso poderia ajudá-la a conhecer-te melhor."

    # say L25 mo1
    old "Just try, please? Could you?... For me?"
    new "B:mo1: Sabes que ela está bastante stressada. Mas só porque não está por perto o suficiente, já que está sempre a trabalhar."

    # say L26 pla
    old "Uhmm... Fine."
    new "B:mo1: Só tenta, por favor? Podes?... Por mim?"

    # say L27 mo1
    old "Great, It's very simple. She needs some help for her job. She's thought about hiring an assistant..."
    new "B:pla: Hummm... Bem."

    # say L28 mo1
    old "So, I asked her to let you work for her. And of course she will reward you for all your help."
    new "B:mo1: Ótimo, é muito simples. Ela precisa de ajuda para o trabalho dela. Ela pensou em contratar um assistente..."

    # say L30 pla
    old "Alright, alright. I'll help her then..."
    new "B:mo1: Então, pedi a ela que te deixasse trabalhar para ela. E claro, ela vai te recompensar por toda a tua ajuda."

    # say L35 mo2
    old "Do you have the receipt of-"
    new "B:pla: Tudo bem, tudo bem. Vou ajudá-la então..."

    # say L38 mo2
    old "Oh, there you are..."
    new "B:mo2: Tens a factura de-"

    # say L42 mo1
    old "Yes, I just did. And you have nothing to worry about."
    new "B:mo2: Ocupado... Falaste com ele? Hein?"

    # say L43 mo2
    old "... He's still a pervert."
    new "A:pla: Não sou um-"

    # say L44 pla
    old "I'm not a-"
    new "B:mo2:... Ele continua a ser um pervertido."

    # say L45 mo1
    old "He is just a teenager. No need to be rude. Everything is okay."
    new "B:pla: Não sou um-"

    # say L46 mo2
    old "Hmm... If you say so..."
    new "B:mo1: Ele é apenas um adolescente. Não é preciso ser mal-educado. Tudo está bem."

    # say L52 mo1
    old "Anyway, did you want to talk about something?"
    new "B:pla: Ok. (Pelo amor de Deus)"

    # say L79 pla
    old "(W- what is she doing?)"
    new "B:mo1: De qualquer forma, querias falar de algo?"

    # say L80 mo1
    old "Ohh, sorry I'm trying to apply some sunscreen on my butt, hehehe."
    new "B: pla: (Q- o que é que ela está a fazer?)"

    # say L86 mo1
    old "Hi honey, are you coming to hang out in the pool?"
    new "B:mo1: Ohh, desculpa, estou a tentar passar um pouco de protetor solar nas nádegas, hehehe."

    # say L88 pla
    old "No, I don't want to swim today."
    new "B:mo1: Olá querida, vais passar algum tempo na piscina?"

    # say L90 mo1
    old "Really? It's a shame on this beautiful day."
    new "B:pla: Não, não quero nadar hoje."

    # say L92 mo1
    old "Why don't you help me then to apply some sunscreen on my back?"
    new "B:mo1: Mesmo? É uma pena num dia tão bonito."

    # say L97 pla
    old "Oh, okay."
    new "B:mo1: Porque não me ajudas a passar um pouco de protector solar nas costas?"

    # say L99 mo1
    old "Thanks sweetheart."
    new "B:pla: Oh, está bem."

    # say L105 pla
    old "I'm sorry I have some things to do."
    new "B:mo1: Obrigado, querida."

    # say L107 mo1
    old "Oh, don't worry honey, go and do what you have to do."
    new "B:pla: Desculpa, tenho algumas coisas para fazer."

    # say L109 pla
    old "Ok. See you later."
    new "T(pla|tu|say): Ok. Até mais."

    # say L119 mo1
    old "Be sure to cover the entire back."
    new "B:pla: Ok. Até mais."

    # say L120 pla
    old "I will, don't worry."
    new "A:pla: Acho que já está tudo no teu costas, precisas de mais alguma coisa?"

    # say L137 pla
    old "I think that's it with your back, would you need anything else?"
    new "B:pla: Vou fazer, não te preocupes."

    # say L156 pla
    old "Hmm, there still some areas that I think might need some Sunscreen."
    new "B:pla: Okay, no problem."

    # say L191 pla
    old "Well it's done. I think you are perfect now."
    new "B:pla: (Acho que funciona... Vamos ver.)"

    # say L233 mo1
    old "Hey, [pla], I wanted to ask if you could come with me to the doctor's office."
    new "T(mo1|formal|say): Olá, [pla], queria perguntar se podes vir comigo à consulta médica."

    # say L237 mo1
    old "No, no, it's nothing bad. It's just a routine check up."
    new "B:pla: Que! Porquê? Aconteceu-te algo? Estás doente?"

    # say L239 pla
    old "Oh, ok. Sure no problem"
    new "B:mo1: Não, não, não é nada de mal. É só uma consulta de rotina."

    # say L241 mo1
    old "Perfect! Wait for me while I get changed, okay?"
    new "B:pla: Oh, ok. Claro, sem problema."

    # say L245 mo1
    old "Thank you, baby."
    new "A:mo1: Estou pronta! Como fico?"

    # say L259 mo1
    old "I'm ready! How do I look?"
    new "B:mo1: Obrigado, bebé."

    # say L272 mo1
    old "Oh... It's called a mammogram. It's to make sure there's no problem with my boobies. Hehe."
    new "T(mo1|formal|say): Oh... Chama-se mamografia. É para garantir que não há problemas com os meus peitos. Hehe."

    # say L274 pla
    old "Oh... ok, I understand... And what should we do?"
    new "B:mo1: Oh... Chama-se mamografia. É para garantir que não há problemas com as minhas mamas. Hehe."

    # say L276 mo1
    old "Well, it's time for the appointment! So we should go to nurse Mary's office right now."
    new "B:pla: Oh... ok, percebi... E o que devemos fazer?"

    # say L278 pla
    old "Ok, Come on..."
    new "B:mo1: Bem, é hora do compromisso! Então devemos ir para o consultório da enfermeira Mary agora."

    # say L286 mo1
    old "Good morning..."
    new "B:pla: Vamos, anda..."

    # say L289 mar
    old "Hello, How have you been? Long-time, no see."
    new "B:mo1: Bom dia..."

    # say L291 mar
    old "Ohh, and who is this handsome young man? Are you trying out young meat? "
    new "B:mar: Olá, como tens estado? Há muito tempo que não nos vemos."

    # say L300 mar
    old "So we will have to do it in the old fashioned way... So I get to give you a good massage on those babies ..."
    new "B:mar: Oh, percebo. Certo... falando sobre o exame... Tenho más notícias... A máquina técnica para fazer a mamografia está avariada no momento."

    # say L302 mo1
    old "Hehehe. It's fine Mary, as you wish..."
    new "B:mar: Então teremos que fazer da maneira tradicional... Vou-te dar uma boa massagem nesses peitos..."

    # say L304 mar
    old "Well now, Sue, take off your clothes..."
    new "B:mo1: Hehehe. Tudo bem, Mary, como tu quiseres..."

    # say L306 pla
    old "... (Oh crap)"
    new "B:mar: Bem, Sue, tira a roupa..."

    # say L308 pla
    old "Ehh ... Well ... I'll just head on out, to give you guys some privacy."
    new "Ehh... Bem... Acho que vou embora, para vocês terem privacidade."

    # say L310 mar
    old "Hey! Wait there. What a shy one you have here. Don't worry, sugar. This is nothing you haven't seen before."
    new "B:pla: Ehh... Bem... Vou sair, para vocês terem privacidade."

    # say L312 mar
    old "Besides, she won't get naked. Haha. Don't worry. This is very professional."
    new "B:mar: Ei! Espera aí. Que tímida tu és. Não te preocupes, querida. Isto não é nada que já não tenhas visto antes."

    # say L314 pla
    old "Oh. Ok, then..."
    new "B:mar: Além disso, ela não vai ficar nua. Haha. Não te preocupes. Isto é muito profissional."

    # say L320 mar
    old "Let's see those babies!... I'm going to massage them gently. Tell me, how does it feel?"
    new "B:pla: Oh. Ok, então..."

    # say L321 mar
    old "Wow, I didn't remember them being so big... Lucky you!"
    new "B:mar: Vamos ver esses peitos!... Vou massajá-los suavemente. Diz-me, como é que se sente?"

    # say L323 pla
    old "... (This is...)"
    new "A:mar: Tu sentes alguma dor?"

    # say L324 mar
    old "Do you feel any pain?"
    new "T(mar|tu|dizer): Tu sentes alguma dor?"

    # say L326 mo1
    old "No, not at all. In fact, it feels very... good..."
    new "B:mar: Tu sentes alguma dor?"

    # say L327 mar
    old "Hmm... Honestly, I haven't done this manually for a long time. I can't feel anything... I'm going to do it a little harder, ok?"
    new "B:mo1: Não, nada disso. Na verdade, sente-se muito... bem..."

    # say L331 mar
    old "Well, that's it for now..."
    new "B:mar: Hmm... Honestemente, não faço isto manualmente há muito tempo. Não sinto nada... Vou fazer com mais força, ok?"

    # say L335 mar
    old "I still couldn't feel anything..."
    new "B:mar: Bem, é isso por agora..."

    # say L337 mar
    old "So, I would like you to come again. We can do the test again and be more thorough. How does Monday sound?"
    new "B:mar: Ainda não consegui sentir nada..."

    # say L339 mo1
    old "Monday is perfect."
    new "B:mar: Então, gostava que tu viesse de novo. Podemos fazer o teste de novo e ser mais minuciosos. Como te parece a segunda-feira?"

    # say L341 mar
    old "Ok, then Thursday, we will try again. It was really nice to see you again!"
    new "B:mo1: Segunda-feira é perfeita."

    # say L343 mo1
    old "Likewise, Mary."
    new "B:mar: Ok, então na quinta-feira, tentaremos de novo. Foi realmente agradável ver-te de novo!"

    # say L345 mar
    old "See you later, young man..."
    new "B:mo1: Da mesma forma, Mary."

    # say L347 pla
    old "...See you later..."
    new "B:mar: Até logo, rapaz..."

    # say L367 mo1
    old "Hi, honey! Do you want to join me?"
    new "B:pla:...Até logo..."

    # say L381 pla
    old "Ok. Good night."
    new "Não te preocupes, querida. Vai dormir. Eu vou ver um filme e depois saio eu própria."

    # say L383 mo1
    old "Sweet dreams, dear."
    new "B:pla: Ok. Boa noite."

    # menu L390 
    old "Sure"
    new "B:mo1: Doces sonhos, querida."

    # say L394 pla
    old "Are you sure, I think you drank a lot and should rest..."
    new "T(pla|tu|say): Tens a certeza, acho que bebeste muito e deves descansar..."

    # say L396 mo1
    old "Awww, don't worry honey... I'm fine, I just want to relax a little..."
    new "A:mo1: Também gosto da tua companhia e do teu grande-"

    # say L398 mo1
    old "I also like your company and your big-"
    new "B:mo1: Awww, não te preocupes querida... Estou bem, só quero descansar um pouco..."

    # say L402 mo1
    old "Your big... Heart is what I meant. Oh, come on, don't leave me alone, I want some company, please?"
    new "B:mo1: Também gosto da tua companhia e do teu grande..."

    # say L406 mo1
    old "Great, you are the best!"
    new "B:mo1: O teu grande... Coração é o que eu quis dizer. Oh, vem cá, não me deixes sozinho, quero companhia, por favor?"

    # say L408 mo1
    old "But this time I choose the movie"
    new "B:mo1: Ótimo, és a melhor!"

    # say L419 mo1
    old "Great, honey! What movie would you like to watch?"
    new "Ótimo, querida! Que filme gostarias de ver?"

    # menu L422 
    old "Romance"
    new "B:mo1: Ótimo, querida! Que filme gostarias de ver?"

    # say L425 mo1
    old "Ohh, I love these kind of movies!"
    new "T(mo1|formal|say): Ohh, adoro este tipo de filmes!"

    # say L427 pla
    old "Great, let's enjoy it!"
    new "Ótimo, vamos aproveitar!"

    # menu L436 
    old "Action"
    new "Esta é a tua tipo favorito de filme, não é?"

    # say L439 mo1
    old "This is your favorite type of movie, isn't it?"
    new "T(mo1|formal|say): Este é o teu tipo de filme favorito, não é?"

    # say L441 pla
    old "Yup, but if you want, we can watch something else..."
    new "B:mo1: Este é o teu tipo de filme favorito, não é?"

    # say L443 mo1
    old "Ohh no, don't worry honey. I'm happy to spend time with you."
    new "B:pla: Sim, mas se quiseres, podemos ver outra coisa..."

    # menu L451 
    old "Horror"
    new "B:mo1: Ohh não, não te preocupes querida. Estou feliz por passar tempo contigo."

    # say L454 mo1
    old "Are you sure? I don't want you to have any nightmares."
    new "T(mo1|formal|say): Tens a certeza? Não quero que tenhas pesadelos."

    # say L469 pla
    old "Ok. No problem. (Hmm.)"
    new "B:mo1: Espera... Antes de começarmos, deixa-me ir buscar um copo de vinho. Quero relaxar um pouco e aproveitar o filme."

    # say L471 mo1
    old "Thanks, honey!"
    new "A:mo1: Perfeito! Uma noite de cinema e um bom copo de vinho. Que combinação maravilhosa. Queres um pouco de vinho também, querido?"

    # say L479 mo1
    old "Perfect! A movie night and a good glass of wine. What a great combination. Do you want a bit of wine, too, sugar?"
    new "B:mo1: Obrigado, querida!"

    # say L481 pla
    old "I'm fine for now."
    new "B:mo1: Perfeito! Uma noite de cinema e um bom copo de vinho. Que combinação maravilhosa. Queres um pouco de vinho também, querida?"

    # say L483 mo1
    old "Ok, honey. Let's start the movie"
    new "B:pla: Estou bem por agora."

    # say L512 mo1
    old "Wow, this movie is great, isn't it, honey?"
    new "B:mo1: Ok, querida. Vamos começar o filme."

    # say L513 pla
    old "Yeah, is pretty awesome-"
    new "B:mo1: Wow, este filme é ótimo, não é, meu amor?"

    # say L521 mo1
    old "Hmm, it looks like you are ready for the best moment of movie night..."
    new "B:pla: Sim, é bastante incrível..."

    # say L522 pla
    old "... W- what do you mean..."
    new "B:mo1: Hmm, parece que estás pronto para o melhor momento da noite de cinema..."

    # say L523 mo1
    old "What I mean is... Take that big buddy of yours out..."
    new "B:pla:... Q- que queres dizer..."

    # say L527 mo1
    old "Mmm, nice!... What do you want today, baby?"
    new "B:mo1: O que eu quero dizer é... Tira esse teu grande amigo de fora..."

    # say L550 mo1
    old "You read my mind..."
    new "B:mo1: Tu gostas mesmo disto, não é?..."

    # say L581 mo1
    old "Hmmm, honey? This movie is exciting you that much?"
    new "B:mo1: Tu lês a minha mente..."

    # say L603 mo1
    old "Hmm, honey? Are you getting hard again?"
    new "B:mo1: Tudo bem. Não te preocupes. Deixa-me ajudar-te com isso. Não quero que fiques assim durante todo o filme."

    # say L607 mo1
    old "Don't worry honey, you are going to love it."
    new "B:mo1: Tudo bem. na verdade, queria experimentar algo um pouco diferente desta vez..."

    # say L618 mo1
    old "The movie was great!"
    new "B:mo1: Não te preocupes, meu amor, vais adorar."

    # say L620 pla
    old "Yeah, I didn't expect that ending at all..."
    new "B:mo1: O filme foi incrível!"

    # say L627 mo1
    old "I know we will have a good time together."
    new "B:mo1: Aww, isso deixa-me feliz. Se quiseres ver outro filme, vem ver-me amanhã à noite."

    # say L628 pla
    old "You can count on it!"
    new "B:mo1: Eu sei que vamos nos divertir juntos."

    # say L630 mo1
    old "Ok, dear. Let's go to sleep."
    new "B:pla: Podes contar com isso!"

    # say L654 mo1
    old "Do you really think that?  "
    new "B:pla: Uhh, não há nada de errado com isso, tu estás apenas a ajudar-me... Além disso, eu realmente gostei muito..."

    # say L655 mo1
    old "Well... I haven't done that for years and I was trying to make you feel better. So, yeah, maybe there's nothing wrong with that."
    new "B:mo1: Tu realmente pensas isso?"

    # say L657 pla
    old "Yeah, also, you're taking care of me so I can release all my repression. and I really appreciate it."
    new "B:mo1: Bem... Não faço isso há anos e estava a tentar fazer-te sentir melhor. Portanto, sim, talvez não haja nada de errado nisso."

    # say L659 mo1
    old "Awww, of course, honey. You always make me feel better... Now let's clean this up... And remember, don't to tell anyone."
    new "B:pla: Sim, também, estás a cuidar de mim para que eu possa libertar toda a minha repressão. E agradeço-te muito."

    # say L661 pla
    old "Don't worry, I won't."
    new "B:mo1: Awww, claro, querida. Tu sempre me fazes sentir melhor... Agora vamos limpar isto... E lembra-te, não contes a ninguém."

    # say L663 mo1
    old "That's a good boy. Let's go to bed."
    new "B:pla: Não te preocupes, não vou."

    # say L666 mo1
    old "Good night, honey. Sleep well."
    new "A:mo1: Esse filme foi ótimo!"

    # say L678 mo1
    old "That movie was great!"
    new "B:mo1: Boa noite, querida. Dorme bem."

    # say L680 pla
    old "Yeah, it was fun..."
    new "T(pla|tu|say): Sim, foi divertido..."

    # say L682 mo1
    old "You know what? We could continue this upstairs."
    new "B:pla: Sim, foi divertido..."

    # menu L685 
    old "Hell yeah"
    new "B:mo1: Sabes o quê? Podíamos continuar isto lá em cima."

    # say L687 pla
    old "Oh really?, Well what are we waiting for?"
    new "T: Oh mesmo?, Então para que estamos à espera?"

    # say L688 mo1
    old "That's what I thought."
    new "B:pla: Oh realmente?, Então o que estamos à espera?"

    # menu L692 
    old "Not tonight"
    new "B:mo1: Foi o que pensei."

    # say L694 mo1
    old "Ok honey, anyway if you want to watch another movie, come to see me tomorrow. I know we will have a good time together..."
    new "B:n: Não esta noite"

    # say L698 mo1
    old "Ok, honey. Let's go to sleep."
    new "B:mo1: Ok, querida, se quiseres ver outro filme, vem ver-me amanhã. Sei que vamos passar um bom momento juntos..."

    # say L702 mo1
    old "Sweet dreams, honey. Sleep well."
    new "B:mo1: Ok, meu amor. Vamos dormir."

    # say L719 mo1
    old "Thanks for spending time with me, baby."
    new "B:mo1: Doces sonhos, querida. Dorme bem."

    # say L743 mo1
    old "Looks like someone is really happy for the movie..."
    new "B:mo1: Fico contente por ouvir isso. Se quiseres ver outro filme, vem ter comigo amanhã. Acho que vamos passar um bom bocado juntos..."

    # say L745 mo1
    old "You know what? I want to have sex here..."
    new "B:mo1: Parece que alguém está mesmo contente com o filme..."

    # say L747 pla
    old "... Are you sure?"
    new "B:mo1: Sabes o quê? Quero fazer sexo aqui..."

    # say L748 mo1
    old "What is the difference, we already had sex..."
    new "B:pla:... Tens a certeza?"

    # say L778 pla
    old "I- I'm really sorry... It wasn't-"
    new "B:mo1: Queria falar contigo sobre ontem..."

    # say L780 mo1
    old "No, I want to apologize for the way I treated you ..."
    new "B:pla: I- I'm really sorry... It wasn't-"

    # say L782 pla
    old "You want to... Apologize?"
    new "B:mo1: Não, quero pedir desculpa pelo modo como te tratei..."

    # say L784 mo1
    old "Yes, I think I was very rude with you, but please understand, it was a bit shocking for me..."
    new "B:pla: Queres... Pedir desculpa?"

    # say L788 mo1
    old "I mean, I don't want you to think that I judge you, I know you're going through a lot."
    new "B:mo1: Sim, acho que fui muito mal-educado contigo, mas por favor compreende, foi um choque para mim..."

    # say L790 mo1
    old "And I know this is hard for you, so I want you to know that I'm not mad at you."
    new "B:mo1: Quero dizer, não quero que penses que te julgo, sei que estás a passar por muito."

    # say L793 mo1
    old "Yes, In fact I think it was some kind of my fault..."
    new "B:mo1: E sei que isto é difícil para ti, por isso quero que saibas que não estou zangado contigo."

    # say L794 pla
    old "Your fault? W- what do you mean?"
    new "A:mo1: Acho que deveria ter-te ajudado mais."

    # say L796 mo1
    old "I think I should have helped you more."
    new "B:pla: A tua culpa? Q- quer dizer o quê?"

    # say L800 mo1
    old "And do things that... You shouldn't do."
    new "B:mo1: E agora estás um pouco reprimida, por isso as tuas hormonas estão a fazer-te perder a cabeça."

    # say L801 pla
    old "I- it was not my intention."
    new "B:mo1: E faz coisas que... Não deves fazer."

    # say L804 mo1
    old "Actually, what worries me is that you get to do it at school or in front of any other girl."
    new "B:pla: Não vou fazer de novo, prometo."

    # say L805 pla
    old "W- what? I- I won't-"
    new "B:mo1: Na verdade, o que me preocupa é que tu faças isso na escola ou na frente de qualquer outra rapariga."

    # say L806 mo1
    old "It's not under your control, you already show me that."
    new "B:pla: Q- que? N- não vou-"

    # say L807 pla
    old "I- I'm sorry-"
    new "B:mo1: Não está sob o teu controlo, já me mostraste isso."

    # say L808 mo1
    old "And it's my fault. I should have helped you before, now you are facing troubles because of my irresponsibility."
    new "B:pla: I- Desculpa..."

    # say L810 mo1
    old "And I have been thinking about it a lot and... I think I have to help you to... Release your, uhm... S- stress."
    new "E tenho pensado muito nisso e... Acho que tenho de te ajudar a... Aliviar o teu, hã... S- stress."

    # say L811 pla
    old "Uhh, w- what do you mean?"
    new "B:mo1: E tenho pensado muito nisso e... Acho que tenho de te ajudar a... Aliviar o teu, hã... S- stress."

    # say L812 mo1
    old "Hmm you know honey... I'll help you with your... Ahem, load release."
    new "B:pla: Huh, e- Então o que queres dizer?"

    # say L817 mo1
    old "I know it won't be comfortable for any of us, but I need to make sure you get it right."
    new "B:mo1: Desculpa querida, mas parece que não tens estado a fazer muito bem até agora."

    # say L818 mo1
    old "I don't want you to keep repressing yourself and that it leads you to do worse things."
    new "B:mo1: Eu sei que não será confortável para nenhum de nós, mas preciso ter a certeza de que vais fazer direito."

    # say L819 pla
    old "Are you right this is the only way?"
    new "B:mo1: Não quero que continues a reprimir-te e que isso te leve a fazer coisas piores."

    # say L827 mo1
    old "Just think of it as some kind of sex ed class."
    new "B:mo1: Vou ajudar-te com uma massagem, para te ajudar a relaxar e a libertar a tua... Carga e pronto."

    # say L828 pla
    old "Sex ed class... Uhmm, alright."
    new "B:mo1: Pensa nisso como se fosse uma aula de educação sexual."

    # say L830 mo1
    old "Thanks honey."
    new "B:pla: Aula de educação sexual... Hummm, tudo bem."

    # say L831 mo1
    old "Alright, come and sit on the bed and leave it all to me."
    new "B:mo1: Obrigado, querida."

    # say L852 pla
    old "What the fuck is going on???"
    new "B:mo1: Tudo bem, vem sentar-te na cama e deixa tudo por minha conta."

    # say L872 pla
    old "What were those yells?? It's coming from the house's entrance."
    new "B:pla: Que raio se está a passar???"

    # say L874 pla
    old "I better go check it out."
    new "T(pla|tu|say): Melhor ir ver o que se passa."

    # say L882 mo2
    old "I'm tired of this, I'm the only one who works in this house..."
    new "B:pla: Melhor ir ver isso."

    # say L884 mo1
    old "But honey..."
    new "B:mo2: Estou farto disto, sou o único que trabalha nesta casa..."

    # say L886 mo2
    old "It makes no sense to keep providing for three good for nothing bums!"
    new "B:mo1: Mas querida..."

    # say L888 mo1
    old "But we are a family."
    new "B:mo2: Não faz sentido continuar a sustentar três parasitas inúteis!"

    # say L890 mo2
    old "No, you are leeches who want to live at my expense."
    new "B:mo1: Mas somos uma família."

    # say L894 mo2
    old "Besides, now your drinking wine every night and getting drunk. Don't you feel ashamed?!"
    new "B:mo2: Não, vocês são parasitas que querem viver à minha custa."

    # say L896 mo1
    old "I'm not getting drunk..."
    new "B:mo2: Além disso, agora bebes vinho todas as noites e ficas bêbado. Não te sentes envergonhado?!"

    # say L898 mo2
    old "You know what, I'm going to the office ... There is no point in continuing to argue"
    new "B:mo1: Não estou a ficar bêbado..."

    # say L912 mo1
    old "Oh yes, I'm fine, don't worry, I'll be in my room, ok?"
    new "B:mo1: Olá querida, não te preocupes... Apenas uma pequena discussão."

    # say L936 pla
    old "Oh, come on, are they arguing again?"
    new "B:mo1: Oh sim, estou bem, não te preocupes, vou para o meu quarto, ok?"

    # say L938 pla
    old "I better go and make sure what's happening now."
    new "A:mo2: A sério, tu estavas a beber outra vez ontem?"

    # say L944 mo2
    old "Seriously, were you drinking yesterday again?"
    new "B:pla: Melhor ir ver o que se passa agora."

    # say L946 mo1
    old "I'm sorry, but I was feeling bad..."
    new "B:mo2: A sério, estavas a beber de novo ontem?"

    # say L948 mo2
    old "You are a sick alcoholic."
    new "B:mo1: Sinto muito, mas estava a sentir-me mal..."

    # say L950 mo1
    old "NO!"
    new "B:mo2: Tu és um alcoólico doente."

    # say L954 mo1
    old "I'm not an alcoholic and I'm tired of your offenses and your aggressiveness!"
    new "B:mo1: NÃO!"

    # say L956 mo2
    old "Well, I'm tired of living with good for nothings..."
    new "B:mo1: Não sou alcoólico e estou farto das tuas ofensas e agressividade!"

    # say L958 mo2
    old "Actually, I'm leaving this house, I'm not going to keep paying everything for all of you anymore."
    new "B:mo2: Bem, estou farto de viver com uns inúteis..."

    # say L974 pla
    old "I didn't know you were having these problems."
    new "Não te preocupes, acho que é o melhor mesmo."

    # say L976 mo1
    old "Always, from the beginning of the relationship, we are very different and as much as we try..."
    new "B:pla: Não sabia que estavas a ter estes problemas."

    # say L978 mo1
    old "I think we are simply not compatible."
    new "B:mo1: Sempre, desde o início da relação, somos muito diferentes e por mais que tentemos..."

    # say L980 pla
    old "Do you need anything?"
    new "B:mo1: Acho que simplesmente não somos compatíveis."

    # say L982 mo1
    old "No, thanks, I just want to be alone."
    new "A:pla: Queria perguntar-te de novo sobre a tua consulta médica..."

    # say L1008 pla
    old "I wanted to ask you again about your doctor's appointment..."
    new "B:mo1: Não, obrigado, só quero ficar sozinho."

    # say L1010 mo1
    old "Oh, I had forgotten, can you go with me?"
    new "B:pla: Queria perguntar-te de novo sobre a tua consulta médica..."

    # say L1012 pla
    old "Yes, that's why I was looking for you..."
    new "B:mo1: Oh, tinha-me esquecido, tu podes ir comigo?"

    # say L1014 mo1
    old "Perfect! Wait for me at the entrance while I get changed and come out, okay?"
    new "B:pla: Sim, por isso é que eu estava à tua procura..."

    # say L1016 pla
    old "Ok, I'll wait for you then..."
    new "B:mo1: Perfeito! Espera por mim à entrada enquanto me troco e saio, ok?"

    # say L1028 mo1
    old "Ok, I'm ready. Let's go to the hospital..."
    new "B:pla: Ok, vou esperar por ti então..."

    # say L1046 mo1
    old "Hi, sweetie! What are you up to?"
    new "B:mo1: Ok, estou pronta. Vamos ao hospital..."

    # say L1050 mo1
    old "Did you want to talk about something?"
    new "A:pla: Como sabes, estou a preparar um discurso para a aula."

    # say L1096 pla
    old "As you know, I'm preparing a speech for class."
    new "B:mo1: Querias falar de algo?"

    # say L1098 mo1
    old "Yes! I'm proud of you for studying so hard, dear!"
    new "B:pla: Como sabes, estou a preparar um discurso para a aula."

    # say L1100 pla
    old "Yeah… Well, I don't want to bother anyone, so I will be studying in the garage instead of my room."
    new "B:mo1: Sim! Estou orgulhosa de ti por estudares tanto, querido!"

    # say L1102 mo1
    old "Aww, that's very considerate of you. Thank you."
    new "B:pla: Sim... Bem, não quero incomodar ninguém, por isso vou estudar na garagem em vez de no meu quarto."

    # say L1104 pla
    old "So, I will be heading to the garage to study now."
    new "B:mo1: Aww, isso é muito atencioso da tua parte. Obrigado."

    # say L1106 mo1
    old "Ok, sweetie. Do you want to talk about anything else?"
    new "B:pla: Vou para a oficina estudar agora."

    # say L1117 pla
    old "Yes, I wanted to ask you again about doctor's appointment..."
    new "B:mo1: Ok, querida. Queres falar de algo mais?"

    # say L1119 mo1
    old "Sure, honey. The appointment is next Thursday... Only look for me in the morning to go to the hospital, okay?"
    new "B:pla: Sim, queria perguntar-te de novo sobre a consulta do médico..."

    # say L1121 pla
    old "Oh, right. Then I'll look for you then."
    new "B:mo1: Claro, querida. O compromisso é na próxima quinta-feira... Só procura-me de manhã para irmos ao hospital, está bem?"

    # say L1123 mo1
    old "Okay, sweetie, do you want to talk about anything else?"
    new "B:pla: Oh, certo. Então eu te procuro depois."

    # say L1131 mo1
    old "Sure, honey. The appointment is next Monday... Only look for me in the morning to go to the hospital, okay?"
    new "B:mo1: Okay, querida, queres falar de algo mais?"

    # say L1143 pla
    old "Yes, I wanted to ask you again about doctor appointment..."
    new "A:mo1: É hoje, tu podes ir comigo?"

    # say L1145 mo1
    old "It's today, Can you go with me?"
    new "B:pla: Sim, queria perguntar-te de novo sobre a consulta com o médico..."

    # say L1174 mo1
    old "By the way, please remember to visit my mom, remember that next week marks a month of my father's death..."
    new "B:mo1: É hoje, tu podes ir comigo?"

    # say L1176 pla
    old "Oh, has it been a month?"
    new "B:mo1: Por acaso, lembra-te de visitar a minha mãe, sabes que na semana que vem faz um mês que o meu pai morreu..."

    # say L1178 mo1
    old "Yes, and it would be a great gesture if you could visit her, now that she is a widow, she needs some company."
    new "B:pla: Oh, já passou um mês?"

    # say L1180 pla
    old "Perfect, I'll go visit her..."
    new "B:mo1: Sim, e seria um gesto maravilhoso se tu pudesses visitá-la, agora que ela é viúva, ela precisa de companhia."

    # say L1186 pla
    old "What?... I wasn't-"
    new "B:mo1: Tu estás na idade de explorar o teu corpo, as sensações e as estimulações..."

    # say L1188 mo1
    old "Don't worry, honey. Nobody is judging you. You have urges, and it is important for you to release them... It is very healthy."
    new "B: pla: O quê?... Eu não estava-"

    # say L1192 mo1
    old "I just want you to know that if you have any questions or need help, please ask me."
    new "B:mo1: Não te preocupes, querida. Ninguém está a julgar-te. Tens desejos, e é importante que os libertes... É muito saudável."

    # say L1194 mo1
    old "I will be in the pool if you need me."
    new "B:mo1: Quero que saibas que se tiveres alguma dúvida ou precisares de ajuda, pede-me."

    # say L1209 mo1
    old "Alright, sweetie. I will be here if you need me..."
    new "Gostavas de um-"

    # say L1221 mo1
    old "Would you like a-"
    new "B:mo1: Tudo bem, querida. Estarei aqui se precisares de mim..."

    # say L1226 mo2
    old "No, I don't want to join, but the Wi-Fi is better here and I.. need to download some files."
    new "B:mo1: Nós... Nós estávamos a ver um filme, tu... Queres juntar-te a nós?"

    # say L1227 mo2
    old "You keep watching your stupid movie, I'll be busy."
    new "B:mo2: Não, não quero juntar-me, mas o Wi-Fi é melhor aqui e... preciso de descarregar alguns ficheiros."

    # say L1228 mo1
    old "Oh, ok we won't bother you."
    new "B:mo2: Continua a ver o teu filme estúpido, eu vou estar ocupado."

    # say L1234 mo1
    old "{i}Lower your voice. We don't want to be caught{/i}"
    new "B:mo1: {i}Onde é que estávamos?{/i}"

    # say L1235 pla
    old "{i}Ok. Are we really going to do this?{/i}"
    new "B:mo1: {i}Abre a voz. Não queremos ser apanhados.{/i}"

    # say L1236 mo1
    old "{i}This is more exciting, isn't?{/i}"
    new "B:pla: {i}Ok. Vamos mesmo fazer isto?{/i}"

    # say L1239 pla
    old "{i}No, this is pretty dangerous.{/i}"
    new "B:mo1: {i}Isto é mais emocionante, não é?{/i}"

    # say L1240 mo1
    old "{i}That's why it gets so exciting...{/i}"
    new "B:pla: {i}Não, isto é bastante perigoso.{/i}"

    # say L1254 pla
    old "Shit, she's not doing well. It's best to take her to her room so she can rest."
    new "Obrigada, meu amor, por me trazer aqui, desculpa-me por estar assim..."

    # say L1260 mo1
    old "Thank you honey for bringing me here, excuse me for being like this..."
    new "B:pla: Merda, ela não está bem. É melhor levá-la ao quarto para descansar."

    # say L1262 mo1
    old "I think I drank a little more... "
    new "B:mo1: Obrigada por me trazer aqui, desculpa-me por estar assim..."

    # say L1276 pla
    old "Yes, don't worry I'll sleep with you ..."
    new "B:mo1: Conseguiste dormir comigo?... Não quero dormir sozinho numa cama tão fria."

    # say L1278 mo1
    old "Oh, thank you very much, excuse me for bothering you so much..."
    new "B:pla: Sim, não te preocupes, vou dormir contigo..."

    # say L1282 mo1
    old "Could you please come to bed after turning on the light? Everything is dark."
    new "B:mo1: Oh, muito obrigado, desculpe-me por incomodar tanto..."

    # say L1290 mo1
    old "Thank you so much for all your support, I really appreciate it,"
    new "B:mo1: Podes vir para a cama depois de ligar a luz? Está tudo escuro."

    # say L1292 mo1
    old "This break up has been very hard..."
    new "B:mo1: Muito obrigado pelo teu apoio, aprecio muito."

    # say L1294 mo1
    old "But you've been there for me..."
    new "B:mo1: Esta separação tem sido muito difícil..."

    # say L1296 mo1
    old "You are so handsome, did you know?"
    new "B:mo1: Mas tu estiveste lá para mim..."

    # say L1298 mo1
    old "You've made me feel things I haven't felt in a long time..."
    new "B:mo1: Tu és tão bonito, sabias?"

    # say L1300 mo1
    old "The last time I was with a man was so many years ago..."
    new "B:mo1: Tu fizeste-me sentir coisas que não sentia há muito tempo..."

    # say L1304 mo1
    old "But, he wasn't as big as you."
    new "B:mo1: A última vez que estive com um homem foi há tantos anos..."

    # say L1308 mo1
    old "Look at this size, I think if I had met a man with something like that..."
    new "B:mo1: Mas, ele não era tão grande quanto tu."

    # say L1309 mo1
    old "Probably never would have been with a woman."
    new "B:mo1: Olha para este tamanho, acho que se tivesse encontrado um homem com algo assim..."

    # say L1310 mo1
    old "You have been so good to me."
    new "B:mo1: Provavelmente nunca teria estado com uma mulher."

    # say L1311 mo1
    old "I just want to reward you a little for that ..."
    new "B:mo1: Tu tens sido tão bom para mim."

    # say L1312 mo1
    old "You know what, get on the edge of the bed, I will give you a good gift."
    new "B:mo1: Só quero recompensar-te um pouco por isso..."

    # say L1333 pla
    old "(Wow...)"
    new "B:mo1: Sabes o que, vai para a beira da cama, vou-te dar um bom presente."

    # say L1334 pla
    old "(Sorry but I have to do it...)"
    new "B: pla: (Uau...)"

    # say L1336 mo1
    old "Hi honey..."
    new "B:pla: (Desculpa, mas tenho de o fazer...)"

    # say L1339 mo1
    old "Wow, what are you doing?"
    new "B:mo1: Olá querida..."

    # say L1364 pla
    old "No, I was just walking around."
    new "B:mo1: Oh querida, precisas de mim?"

    # say L1366 mo1
    old "Ok, Ill be here if you need me."
    new "B: pla: Não, estava só a passear."

    # say L1377 mo1
    old "Wow that was pretty intense."
    new "B:mo1: Ok, estarei aqui se precisares de mim."

    # say L1381 mo1
    old "Next time, just make sure nobody is at home, ok?"
    new "Da próxima vez, certifica-te de que ninguém está em casa, ok?"


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Story/JohStory.rpy
translate portuguese strings:

    # say L6 joh
    old "Oh, hi [pla], I‘m glad you came. Are you ready to start?"
    new "T(joh|formal|say): Oh, olá [pla], fico contente que tenhas vindo. Estás pronto para começar?"

    # say L7 pla
    old "Uhh... Hi, yes, sure."
    new "A:joh: Ok, como discutimos da última vez, vou precisar da tua ajuda com alguns dos meus pacientes."

    # say L8 joh
    old "Ok, as we discussed last time, I'll need your help with some of my patients."
    new "B:pla: Uhh... Olá, sim, claro."

    # say L9 joh
    old "However, you will need a bit of instruction to gain more experience and do a better job."
    new "B:joh: Ok, como discutimos da última vez, vou precisar da tua ajuda com alguns dos meus pacientes."

    # say L10 pla
    old "Hmm, ‘Instruction'? What do you mean?"
    new "B:joh: No entanto, vais precisar de um pouco de instrução para ganhar mais experiência e fazer um trabalho melhor."

    # say L11 joh
    old "Just think about it like a class made just for you, I'll provide you with the proper training and tell you what to do."
    new "B:pla: Hmm, ‘Instrução'? O que queres dizer?"

    # say L12 pla
    old "Hmm, ok..."
    new "B:joh: Pensa nisso como uma aula feita só para ti, eu vou fornecer-te o treino adequado e dizer-te o que fazer."

    # say L14 joh
    old "Ok, to start you need to know I assist some patients who have, most of the time, some... Hmm, ‘sexual difficulties'..."
    new "B:pla: Hmm, ok..."

    # say L15 joh
    old "Some of them are married women that don't enjoy their sexuality, this brings a lot of problems to their lives."
    new "B:joh: Ok, para começar, precisas de saber que eu ajudo alguns pacientes que, na maioria das vezes, têm... Hmm, ‘dificuldades sexuais’..."

    # say L16 pla
    old "Hmm, I see."
    new "B:joh: Algumas delas são mulheres casadas que não desfrutam da sua sexualidade, o que traz muitos problemas às suas vidas."

    # say L17 joh
    old "In other words, I help them to discover and enjoy their sexuality and have more pleasant moments with their partners."
    new "T(joh|formal|say): Em outras palavras, ajudo-os a descobrir e desfrutar da sua sexualidade e a ter momentos mais agradáveis com os seus parceiros."

    # say L18 pla
    old "Ok, I got it, but... What do I have to do?"
    new "B:joh: Em outras palavras, ajudo-os a descobrir e desfrutar da sua sexualidade e a ter momentos mais agradáveis com os seus parceiros."

    # say L19 joh
    old "Well, I know you can support me to achieve success in a lot of patients' treatment like you did with Hinn."
    new "B:pla: Ok, percebi, mas... O que tenho de fazer?"

    # say L20 pla
    old "L- like I did with... H- Hinn?"
    new "B:joh: Bem, sei que podes apoiar-me para conseguir o sucesso no tratamento de muitos pacientes, como fizeste com Hinn."

    # say L21 joh
    old "It's ok, I am pretty conscious about the process we will need to go through so you can do it well."
    new "B: L- como fiz com... H- Hinn?"

    # say L23 joh
    old "Don't worry, we will have some lessons to teach you."
    new "B:joh: Tudo bem, estou bastante consciente do processo que precisamos seguir para que tu consigas fazer bem."

    # say L24 joh
    old "Also, I'll be with you at all times, you just have to follow the instructions, okay?"
    new "B:joh: Não te preocupes, vamos ter algumas lições para te ensinar."

    # say L25 pla
    old "Hmm, got it."
    new "B:joh: Além disso, vou estar contigo em todo o momento, só tens de seguir as instruções, ok?"

    # say L26 joh
    old "I really want you to perform the best way possible and I will ensure you develop the skills you need."
    new "B:pla: Hmm, percebi."

    # say L27 joh
    old "So, let's not waste any more time and let's go to the practice room!"
    new "B:joh: Quero mesmo que te saias da melhor forma possível e vou assegurar-me de que desenvolves as competências de que precisas."

    # say L34 joh
    old "Well, to start, do you remember that Hinn learned how to please a man? Well, now is your turn!"
    new "B:joh: Então, não vamos perder mais tempo e vamos para a sala de prática!"

    # say L40 joh
    old "We are going to start with some oral sex, I want you to show me those skills, so I can be sure my patients are going be satisfied."
    new "B:joh: A esta altura, acho que deves ser mais natural, já te chupaste o pénis várias vezes, então só relaxa."

    # say L41 pla
    old "W- what? Do you mean you want me to give you... O- oral sex?"
    new "T(pla|tu|say): W- what? Queres dizer que queres que eu te faça... O- oral sex?"

    # say L42 joh
    old "Yes, remember, just relax and follow my instructions."
    new "B:pla: Q- quê? Tu queres dizer que queres que eu te faça... O- sexo oral?"

    # say L43 joh
    old "We are learning and this is part of your process, so, come here and get on your knees."
    new "B:joh: Sim, lembra-te, só relaxa e segue as minhas instruções."

    # say L52 joh
    old "I can assure you this lesson is going to be useful for you."
    new "B:joh: Estamos a aprender e isto faz parte do teu processo, então, vem cá e ajoelha-te."

    # say L53 joh
    old "And it will be necessary for my patients, and of course, should be amusing for both of us, so, let's start."
    new "B:joh: Posso assegurar-te que esta lição vai ser útil para ti."

    # say L56 joh
    old "I want you to kiss me, like if that were my mouth, move your tongue carefully, slowly..."
    new "B:joh: E será necessário para os meus pacientes, e claro, deve ser divertido para ambos, então, vamos começar."

    # say L69 joh
    old "Just like that, try to keep it wet, and slowly move your tongue a bit faster..."
    new "B:joh: Quero que me beijes, como se fosse a minha boca, move a tua língua com cuidado, devagar..."

    # say L71 joh
    old "Keep doing it like that... Ahh."
    new "B:joh: Assim, tenta mantê-lo molhado e move a língua um pouco mais rápido..."

    # narrator L95 
    old "Try Again"
    new "B:joh: Continua assim... Ahh."

    # narrator L97 
    old "Next Round"
    new "A:joh: Oh, cuidado!"

    # say L109 joh
    old "Oh careful!"
    new "B:n: Próxima Rodada"

    # say L111 joh
    old "Ouch!"
    new "B:joh: Cuidado!"

    # say L113 joh
    old "NO! NO! STOP!"
    new "B:joh: Ai!"

    # say L119 pla
    old "Did I do something wrong?"
    new "B:joh: NÃO! NÃO! PARA!"

    # say L120 joh
    old "Hmm, I think you could do it a lot better..."
    new "B:pla: Fiz algo errado?"

    # say L121 joh
    old "Softer, the idea is to make the patient experience a lot of pleasure and not the opposite, but we can work on that."
    new "B:joh: Hmm, acho que podias fazer muito melhor..."

    # say L122 pla
    old "Hmm... Ok."
    new "B:joh: Mais suave, a ideia é fazer com que o paciente sinta muito prazer e não o contrário, mas podemos trabalhar nisso."

    # say L123 joh
    old "Listen, that is something normal, we can always improve our abilities, don't feel bad about this particular moment where it was not as expected, it's ok."
    new "B:pla: Hmm... Ok."

    # say L126 joh
    old "Unfortunately, our time is up. I think you need to learn a couple of things more before continuing."
    new "B:joh: Ouve, isso é algo normal, podemos sempre melhorar as nossas capacidades, não te sintas mal por este momento em que não foi como esperado, está tudo bem."

    # say L130 pla
    old "See you too, bye!"
    new "T(pla|tu|say): Até logo, adeus!"

    # say L144 joh
    old "Congratulations, you definitely have what it takes, so, we can do a perfect team."
    new "B:pla: Até logo, adeus!"

    # say L145 joh
    old "I can see you have other talents and they are pretty valuable."
    new "B:joh: Parabéns, tu definitivamente tens o que é preciso, por isso, podemos formar uma equipa perfeita."

    # say L147 joh
    old "Yes, I'm very satisfied, you did just fine."
    new "B:joh: Posso ver que tens outros talentos e são bastante valiosos."

    # say L148 pla
    old "I am glad you liked it."
    new "T(pla|tu|say): Fico contente que tenhas gostado."

    # say L149 joh
    old "It can be better but I am proud of you, I can count on you to make the best for my patients."
    new "B:pla: Fico contente que tenhas gostado."

    # say L150 joh
    old "The great news is that these lessons are going to be quite fascinating for me."
    new "B:joh: Pode ser melhor, mas estou orgulhoso de ti, posso contar contigo para fazer o melhor pelos meus pacientes."

    # say L159 joh
    old "I think that's all, you need to rest a bit, I am exhausted but I have some patients I have scheduled."
    new "B:joh: A grande novidade é que estas aulas vão ser bastante fascinantes para mim."

    # say L160 pla
    old "Ok, thank you."
    new "B:joh: Acho que é tudo, precisas de descansar um pouco, estou exausto mas tenho alguns pacientes marcados."

    # say L161 joh
    old "It was a pleasure... I hope you're on time tomorrow."
    new "B:pla: Ok, obrigado."

    # say L163 joh
    old "I'll be waiting for you, there are some lessons we need to have go through."
    new "B:joh: Foi um prazer... Espero que amanhã estejas a horas."

    # say L165 joh
    old "Perfect, see you tomorrow."
    new "B:joh: Estarei à tua espera, há algumas lições que precisamos de rever."

    # say L188 joh
    old "We need to repeat the session we were practising last time, I need you to finish it successfully."
    new "B:pla: Uhhh... Ok!"

    # say L190 joh
    old "I have to budget my time because I have a couple of patients coming earlier, so please help me to finish on time."
    new "B:joh: Precisamos de repetir a sessão que estávamos a praticar da última vez, preciso que a termines com sucesso."

    # say L192 joh
    old "Let's start, you already know how to do it, so please do your best."
    new "B:joh: Tenho de gerir o meu tempo porque tenho alguns pacientes que chegam mais cedo, por isso, por favor, ajuda-me a terminar a tempo."

    # say L207 joh
    old "Keep doing it like that... Ahh..."
    new "B:pla: Uhh, Ok..."

    # say L264 joh
    old "Wonderful! Today we have a new goal I want you to work on."
    new "Ótimo! Hoje temos um novo objetivo que quero que trabalhes."

    # say L265 pla
    old "Ok, what is it?"
    new "A:joh: Acho que é algo um pouco novo para ti, mas posso guiar-te. Está relacionado com o auto-domínio."

    # say L266 joh
    old "I think it's something kind of new for you but I can walk you through it. It's related to self-mastery."
    new "A:pla: 'Autocontrole'?"

    # say L268 pla
    old "'Self-mastery'?"
    new "T(pla|tu|say): 'Autocontrole'?"

    # say L269 joh
    old "Yeah, let me explain it to you, most of the time our desires or emotions can be really difficult to control..."
    new "B:pla: 'Autocontrole'?"

    # say L270 joh
    old "Once you can defeat them, you will be strong enough to act without their control."
    new "B:joh: Sim, deixa-me explicar-te, na maior parte do tempo os nossos desejos ou emoções podem ser realmente difíceis de controlar..."

    # say L271 joh
    old "The most visible aspect of this exercise will be that you can last longer during any kind of sexual interaction."
    new "B:joh: Quando os derrotares, estarás forte o suficiente para agir sem o seu controlo."

    # say L272 pla
    old "Hmm interesting..."
    new "T(pla|tu|say): Hmm interessante..."

    # say L273 joh
    old "Talking about our sexual performance, we need to be sure we can control our body to react the exact way we want..."
    new "B:pla: Hmm interessante..."

    # say L274 joh
    old "That way we can guarantee your sexual partner reaches the orgasm before you do."
    new "B:joh: A falar da nossa performance sexual, precisamos ter a certeza de que conseguimos controlar o nosso corpo para reagir exatamente como queremos..."

    # say L277 joh
    old "That's cool, so today we are going to see if your performance can be mastered without cumming."
    new "B:joh: Assim podemos garantir que o teu parceiro sexual atinge o orgasmo antes de ti."

    # say L278 joh
    old "Or we will need to work on it harder so you can perform better with the patients."
    new "B:joh: Isso é fixe, então hoje vamos ver se a tua performance pode ser dominada sem ejacular."

    # say L279 pla
    old "Ok, and how are we going to verify that?"
    new "B:joh: Ou vamos ter que trabalhar mais nisso para que tu possas desempenhar melhor com os pacientes."

    # say L280 joh
    old "That's an interesting part, I want you to relax and just be yourself, I will do the rest of the job, let's go to the room."
    new "B:pla: Ok, e como vamos verificar isso?"

    # say L281 pla
    old "Uhh... Ok."
    new "B:joh: Essa é uma parte interessante, quero que relaxes e sejas tu mesmo, vou fazer o resto do trabalho, vamos para o quarto."

    # say L287 joh
    old "Please take off your pants, so we can start..."
    new "B:pla: Huh... Ok."

    # say L289 joh
    old "I want to test how long you can last, so, get ready because I will use my mouth, I will give you the best blowjob of your entire life."
    new "B:joh: Tira as calças, para podermos começar..."

    # say L291 joh
    old "So, come on, take off your pants, I'm going to make myself comfortable too."
    new "B:joh: Quero ver quanto tempo tu aguentas, então, prepara-te porque vou usar a minha boca, vou dar-te a melhor felação da tua vida."

    # say L316 pla
    old "WOW!"
    new "B:joh: Então, vamos lá, tira as calças, eu também vou ficar confortável."

    # say L317 joh
    old "I am glad you like them because I want you to look at them carefully."
    new "B:pla: UAU!"

    # say L318 joh
    old "I need you to be very stimulated to test your endurance."
    new "B:joh: Fico contente que gostes deles, porque quero que os examines com atenção."

    # say L320 joh
    old "The idea is that, even though all sensorial stimulation you feel, you can control your body and don't cum."
    new "B:joh: Preciso que estejas muito estimulado para testar a tua resistência."

    # say L321 pla
    old "Are you serious?"
    new "T(pla|tu|say): Estás a falar a sério?"

    # say L322 joh
    old "Absolutely, under any circumstance you must not cum, until I say you can, ok?"
    new "B:pla: Estás a falar a sério?"

    # say L323 pla
    old "Hmm ok..."
    new "B:joh: Absolutamente, em nenhuma circunstância podes gozar, até eu te dizer, ok?"

    # say L368 joh
    old "Ok now it comes the hard part, I will suck your entire dick, are you ready?"
    new "B:pla: Hmm ok..."

    # say L374 pla
    old "(Oh God, it feels so good...)"
    new "B:joh: Agora vem a parte difícil, vou chupar todo o teu pénis, estás pronto?"

    # say L379 pla
    old "Dr. Johnson I- I- ... Ughhhh..."
    new "B:pla: (Oh Deus, sente-se tão bem...)"

    # say L386 joh
    old "OH NO! You came before!"
    new "B:pla: Dr. Johnson, eu... eu... Ughhhh..."

    # say L392 pla
    old "I- I am... Sorry..."
    new "B:joh: OH NÃO! Tu foste antes!"

    # say L393 joh
    old "It's ok, it's something we knew could happen so calm down, what a mess you did..."
    new "B:pla: I- I sou... Desculpa..."

    # say L394 pla
    old "I'm sorry, it was my fault."
    new "B:joh: Tudo bem, era algo que sabíamos que podia acontecer, então acalma-te, que confusão fizeste..."

    # say L395 joh
    old "It's ok, it wasn't that bad, the thing is that we now need to have this in mind to make sure you can control yourself."
    new "B:pla: Desculpa, foi culpa minha."

    # say L396 joh
    old "We can't have this mess with a patient..."
    new "B:joh: Tudo bem, não foi tão mau, o importante é que agora temos de ter isto em mente para garantir que consegues controlar-te."

    # say L398 pla
    old "How can I do it better?"
    new "B:joh: Não podemos ter este tipo de confusão com um paciente..."

    # say L400 joh
    old "I will help you, don't worry."
    new "B:pla: Como posso fazer melhor?"

    # say L402 joh
    old "But, I am running out of time, the patients are about to arrive and I need to clean this mess..."
    new "B:joh: Vou ajudar-te, não te preocupes."

    # say L403 joh
    old "I hope you be on time tomorrow, We need to correct this behavior."
    new "B:joh: Mas, estou a ficar sem tempo, os pacientes vão chegar e preciso limpar esta bagunça..."

    # say L404 pla
    old "I am very sorry to disappoint you."
    new "B:joh: Espero que estejas a horas amanhã, precisamos de corrigir este comportamento."

    # say L405 joh
    old "There is nothing we can't improve, I'm sure next time it will be different."
    new "B:pla: Sinto muito por te desiludir."

    # say L406 joh
    old "I think that's all, you need to rest a bit, I have some patients scheduled, so, see you later."
    new "B:joh: Não há nada que não possamos melhorar, tenho a certeza de que da próxima vez será diferente."

    # say L409 joh
    old "We will need to repeat this exercise, I'll be waiting for you."
    new "B:joh: Acho que é tudo, precisas de descansar um pouco, tenho alguns pacientes agendados, então, até mais tarde."

    # say L410 pla
    old "Ok, see you later..."
    new "T(pla|tu|say): Ok, vejo-te mais tarde..."

    # say L425 joh
    old "Oh great! That was good, you have surprised me! What a huge load, it's delicious."
    new "B:pla: Ok, até logo..."

    # say L427 joh
    old "Congratulations, I can see that you havea lot more control of body."
    new "B:joh: Oh, que grande! Isso foi bom, surpreendeste-me! Que carga enorme, é delicioso."

    # say L432 joh
    old "All right, I'm gonna clean this mess. My next patient is about to arrive... I hope you be on time tomorrow."
    new "B:joh: Parabéns, vejo que tens muito mais controlo do corpo."

    # say L435 joh
    old "Ok, there are some lessons we need to have to go through."
    new "B:joh: Tudo bem, vou limpar esta bagunça. O meu próximo paciente está prestes a chegar... Espero que amanhã tu sejas pontual."

    # say L436 pla
    old "Got it, see you tomorrow then."
    new "B:joh: Ok, há algumas lições que precisamos passar."

    # say L452 pla
    old "Fine! Thanks for asking, hope you are doing good too."
    new "T(pla|tu|say): Claro! Obrigado por perguntar, espero que estejas bem também."

    # say L453 joh
    old "Oh absolutely! But I can tell you it will be better just in a moment, Are you ready?"
    new "B:pla: Tudo bem! Obrigado por perguntar, espero que também estejas bem."

    # say L454 pla
    old "Ready? For what?"
    new "B:joh: Oh absolutamente! Mas posso-te dizer que vai ser melhor daqui a um momento, estás pronto?"

    # say L456 joh
    old "Well, today we will continue your process to make you able to control yourself, the main focus for today will be performance."
    new "Desempenho?"

    # say L457 pla
    old "Performance?"
    new "B:joh: Bem, hoje continuaremos o teu processo para te tornares capaz de controlar-te, o foco principal de hoje será a performance."

    # say L458 joh
    old "Yes, we need to test your capabilities to accomplish the tasks that you will have..."
    new "B:pla: Desempenho?"

    # say L459 joh
    old "So, you need to work not only on the time you can last, but the quality of that time."
    new "B:joh: Sim, precisamos de testar as tuas capacidades para cumprir as tarefas que terás..."

    # say L460 pla
    old "Oh... I understand."
    new "B:joh: Então, tu precisas trabalhar não só no tempo que consegues durar, mas também na qualidade desse tempo."

    # say L462 joh
    old "Today we have a very nice exercise, so I hope you put all your effort to make a successful session."
    new "B:pla: Oh... Entendi."

    # say L463 joh
    old "Remember, focus on the rhythm and performance."
    new "B:joh: Hoje temos um exercício muito bom, por isso espero que ponhas todo o teu esforço para fazer uma sessão de sucesso."

    # say L464 pla
    old "Uhh, ok."
    new "A:joh: Então, vamos lá, vamos ter relações agora."

    # say L465 joh
    old "So, let's go, we will have sex now."
    new "B:pla: Huh, ok."

    # say L466 pla
    old "I will hav-... W- wait, what? Sex?"
    new "B:joh: Então, vamos, vamos fazer sexo agora."

    # say L467 joh
    old "Of course, that is how we can practice, besides, I need to test the quality of my assistant."
    new "B:pla: Vou... Espera, o quê? Sexo?"

    # say L469 joh
    old "Great, let's get started, first we need to go to the practice room."
    new "B:joh: Claro, é assim que podemos praticar, além disso, preciso testar a qualidade do meu assistente."

    # say L476 joh
    old "From this particular exercise and on, we will need to guarantee your partner reaches the orgasm, that is the key."
    new "B:joh: Ótimo, vamos começar. Primeiro precisamos ir para a sala de prática."

    # say L477 pla
    old "Ok, I will focus on that."
    new "B:joh: A partir deste exercício em diante, temos de garantir que a tua parceira atinge o orgasmo, isso é fundamental."

    # say L478 joh
    old "But, anyways remember to enjoy what you are doing, let's get prepared. Take off your clothes."
    new "B:pla: Ok, vou focar nisso."

    # say L482 joh
    old "Perfect, now that you are ready let's fuck!"
    new "B:joh: Mas, de qualquer forma, lembra-te de aproveitar o que estás a fazer, vamos preparar-nos. Tira a roupa."

    # say L538 pla
    old "Ohhh... Ohhh... I- I-"
    new "B:joh: Perfeito, agora que estás pronta, vamos foder!"

    # say L552 joh
    old "Huh, you finished quite earlier..."
    new "B:pla: Ohhh... Ohhh... I- I-"

    # say L553 joh
    old "I know you are doing a great effort, but I need you to take control of yourself and wait for the right moment."
    new "B:joh: Huh, acabaste bastante mais cedo..."

    # say L554 pla
    old "I- I'm trying to focus-"
    new "B:joh: Eu sei que estás a fazer um grande esforço, mas precisas de controlar-te e esperar pelo momento certo."

    # say L556 joh
    old "I know, we only need to work harder. "
    new "B:pla: Eu- Estou a tentar concentrar-me..."

    # say L557 joh
    old "I think you need to do some workout, so, you can keep your body up until I reach the orgasm."
    new "B:joh: Eu sei, só precisamos trabalhar mais."

    # say L559 pla
    old "I will improve, I think I was tired because of the rhythm."
    new "B:joh: Acho que precisas de fazer algum exercício, assim podes manter o corpo em forma até eu atingir o orgasmo."

    # say L560 joh
    old "Sure you will improve, that's why we are doing this together, so you can develop all the skills you have."
    new "B:pla: Vou melhorar, acho que estava cansado por causa do ritmo."

    # say L562 joh
    old "Don't mention it, let's clean this mess, I have to continue working..."
    new "B:joh: Claro que vais melhorar, é por isso que estamos a fazer isto juntos, para que possas desenvolver todas as tuas capacidades."

    # say L577 joh
    old "I'm very impressed, you are quite awesome at this, let me tell you the exercise was a complete success."
    new "B:joh: Não há de quê, vamos limpar esta bagunça, tenho que continuar a trabalhar..."

    # say L578 pla
    old "T- thanks... I did all that I could."
    new "B:joh: Estou muito impressionado, tu és bastante incrível nisto, deixa-me dizer-te que o exercício foi um completo sucesso."

    # say L579 joh
    old "Hahaha good job kid, you are doing the exercises very consciously."
    new "B:pla: Obrigado... Fiz tudo o que pude."

    # say L581 joh
    old "Keep working, the benefits will be incredible and remember the benefits won't be only yours..."
    new "B:joh: Hahaha bom trabalho, miúdo, estás a fazer os exercícios com muita consciência."

    # say L582 joh
    old "It was a very productive session, so, I hope next time we keep the level as high as today."
    new "B:joh: Continua a trabalhar, os benefícios serão incríveis e lembra que os benefícios não serão só teus..."

    # say L583 pla
    old "Sure, I will keep working hard."
    new "B:joh: Foi uma sessão muito produtiva, então, espero que da próxima vez mantenhamos o nível tão alto quanto hoje."

    # say L585 joh
    old "Yes... really Hard."
    new "A:joh: Oh, estás aqui! Bastante pontual."

    # say L601 joh
    old "Oh, you are here! Quite on time."
    new "B:joh: Sim... realmente duro."

    # say L602 pla
    old "Yes, I came a bit earlier."
    new "B:joh: Oh, tu estás aqui! Bastante pontual."

    # say L603 joh
    old "That's perfect, we have a lot to work on."
    new "B:pla: Sim, cheguei um pouco mais cedo."

    # say L604 pla
    old "Ok, I am ready."
    new "T(pla|tu|say): Ok, estou pronto."

    # say L605 joh
    old "Great, today we will work on your strength, the power given on every sexual encounter."
    new "B:pla: Ok, estou pronto."

    # say L606 pla
    old "Hmm... Strength? What do you mean?"
    new "B:joh: Ótimo, hoje vamos trabalhar na tua força, o poder que tens em cada encontro sexual."

    # say L607 joh
    old "Sex requires a lot of power if you really want to satisfy, I need you to start doing the process beyond the limits."
    new "B:pla: Hmm... Força? O que queres dizer?"

    # say L609 pla
    old "Wow, And how can I achieve that?"
    new "B:joh: O sexo exige muita energia se quiseres realmente satisfazer, preciso que comeces a fazer o processo além dos limites."

    # say L610 joh
    old "Well, I need you to focus because you are going to use your dick quite differently."
    new "B:pla: Wow, e como posso conseguir isso?"

    # say L611 joh
    old "You must control your body so you can give a hardcore sex experience."
    new "B:joh: Bem, precisas de te concentrar porque vais usar o teu pénis de uma forma diferente."

    # say L612 pla
    old "Hmm, ok."
    new "B:joh: Tens de controlar o teu corpo para poderes dar uma experiência sexual intensa."

    # say L613 joh
    old "Let's go ahead to the practice room, I can't wait to get fucke- ... I mean to start the new exercise..."
    new "B:pla: Hmm, ok."

    # say L620 joh
    old "Ok, previous lesson was focused on endurance and lasting as much as I wanted."
    new "B:joh: Vamos para a sala de prática, não aguento mais esperar para começar o novo exercício..."

    # say L621 joh
    old "This time I need you to keep this in mind, I want you to be hardcore hitting my pussy really hard."
    new "B:joh: A lição anterior focou-se na resistência e em durar o tempo que eu quisesse."

    # say L623 joh
    old "Let's do it, please take off your clothes and get ready."
    new "B:joh: Desta vez quero que tenhas isto em mente, quero que me fodas a xoxota com muita força."

    # say L682 pla
    old "Oh God! This is too much!"
    new "B:joh: Vamos lá, tira a roupa e prepara-te."

    # say L695 pla
    old "Did I cum quick, right?"
    new "B:pla: Oh Deus! Isto é demais!"

    # say L696 joh
    old "Not just that... I'm afraid you are not strong enough, you need to hit harder, some girls will like to be pounded really hard."
    new "B:pla: Fui rápido, certo?"

    # say L700 pla
    old "You are right, I'm sorry.."
    new "T: Tu tens razão, peço desculpa.."

    # say L701 joh
    old "Don't worry I know you can learn... But today I need to get ready for my next patient, so next time we will practice this lesson again."
    new "B:pla: Tens razão, peço desculpa.."

    # say L703 joh
    old "See you later kido."
    new "B:joh: Não te preocupes, sei que consegues aprender... Mas hoje preciso de me preparar para o meu próximo paciente, por isso da próxima vez voltaremos a praticar esta lição."

    # say L704 pla
    old "See you doctor."
    new "B:joh: Até mais, miúdo."

    # say L718 joh
    old "You are doing great! Congratulations for this improvement, you definitely approved, my patients will love you."
    new "B:pla: Até logo, doutor."

    # say L719 pla
    old "Thank you, I appreciate it."
    new "O processo foi bem-sucedido, quero que continues a trabalhar..."

    # say L720 joh
    old "The process has been successful, I want you to keep working..."
    new "B:pla: Obrigado, aprecio isso."

    # say L723 joh
    old "I guess in the mornings we can continue with these lessons, because I want to... Hmm, help you practice more..."
    new "B:joh: O processo foi bem-sucedido, quero que continues a trabalhar..."

    # say L724 pla
    old "Oh, ok that sounds good to me..."
    new "B:joh: Acho que de manhã podemos continuar com estas aulas, porque eu quero... Hmm, ajudar-te a praticar mais..."

    # say L725 joh
    old "Perfect, I'm looking forward to seeing your progress, there are many things we can improve."
    new "B:pla: Oh, ok, isso soa bem para mim..."

    # say L726 pla
    old "I appreciate your help."
    new "B:joh: Perfeito, estou ansioso por ver o teu progresso, há muitas coisas que podemos melhorar."

    # say L727 joh
    old "In our next session we will have a patient to put what we have learned into practice."
    new "B:pla: Aprecio a tua ajuda."

    # say L729 joh
    old "Don't worry, I will walk you through so we can do an outstanding job."
    new "B:joh: Na nossa próxima sessão teremos um paciente para colocarmos em prática o que aprendemos."

    # say L733 joh
    old "All right, I need you to leave so I can get ready for my next patient, thanks for your great job, it was remarkable."
    new "B:joh: Não te preocupes, vou guiar-te para que possamos fazer um trabalho excelente."

    # say L737 pla
    old "Bye!"
    new "B:joh: Tudo bem, preciso que saias para eu me preparar para o meu próximo paciente, obrigado pelo excelente trabalho, foi notável."

    # say L764 joh
    old "I have tried with several exercises, but she is kind of stuck in the process..."
    new "B:joh: Bem, hoje vamos trabalhar com Angelina, ela é uma paciente que não gosta de ter relações sexuais."

    # say L765 joh
    old "Also, her marriage is in danger, because she doesn't want to have sex with her husband."
    new "B:joh: Já tentei com vários exercícios, mas ela está meio presa no processo..."

    # say L767 pla
    old "Oh, that's really bad."
    new "T(pla|tu|say): Oh, isso é realmente mau."

    # say L768 joh
    old "Yes, so we need to have noticeable progress as soon as possible, and we are going to achieve that with your help."
    new "B:pla: Oh, isso é realmente mau."

    # say L769 pla
    old "With m- my... Help?"
    new "B:joh: Sim, precisamos de ter progressos notáveis o mais rápido possível, e vamos conseguir isso com a tua ajuda."

    # say L770 joh
    old "Well, with the training you've been through we can help..."
    new "B: Com a minha... Ajuda?"

    # say L771 joh
    old "We will need to apply all the concepts that we have worked on so that she can discover how pleasurable sex is."
    new "B:joh: Bem, com o treino que tu tens passado, podemos ajudar..."

    # say L774 joh
    old "Then everything she learns here, she can put into practice with her husband, and our treatment will be successful."
    new "B:joh: Vamos precisar de aplicar todos os conceitos que trabalhámos para que ela descubra o quão prazeroso pode ser o sexo."

    # say L775 pla
    old "Ohhh, that makes sense..."
    new "B:joh: Então, tudo o que ela aprende aqui, ela pode colocar em prática com o marido, e o nosso tratamento será bem-sucedido."

    # say L776 joh
    old "Ok, so, please stay in the practice room and I will let you know when to come in to get involved with the session."
    new "B:pla: Ahhh, isso faz sentido..."

    # say L778 joh
    old "I will need you to be ready, I mean to have your cock prepared when I call you."
    new "B:joh: Ok, então, fica na sala de prática e eu avisarei quando for a tua vez de participar na sessão."

    # say L781 joh
    old "Remember to stay focused on her pleasure, you'll have to practice everything we've learned, once Angelina is ready I'll let you know."
    new "B:joh: Vou precisar que estejas pronto, quero dizer, com o teu pénis preparado quando eu te chamar."

    # say L783 joh
    old "Ok, now go to the practice room, she could arrive at any time."
    new "B:joh: Lembra-te de te concentrar no prazer dela, vais ter de praticar tudo o que aprendemos, quando a Angelina estiver pronta aviso-te."

    # say L796 joh
    old "Welcome Angelina, it's pretty nice to have you here again."
    new "B:joh: Ok, agora vai para a sala de prática, ela pode chegar a qualquer momento."

    # say L797 ang
    old "Thank you doctor Johnson is good to see you again."
    new "B:joh: Bem-vinda Angelina, é muito agradável ter-te aqui de novo."

    # say L798 joh
    old "I'm very happy to hear that, how is it going?"
    new "B:ang: Obrigado, doutor Johnson, é bom vê-lo de novo."

    # say L799 ang
    old "Everything is fine I guess, except for what you already know."
    new "T: Tudo bem, acho eu, excepto pelo que tu já sabes."

    # say L800 joh
    old "Tell me about that please, did you see any improvement since the last session?"
    new "B:ang: Tudo está bem, acho eu, exceto pelo que tu já sabes."

    # say L801 ang
    old "Hmm... Well, I'm doing the things that you told me to, but I'm not really comfortable when I'm doing it..."
    new "B:joh: Conta-me mais sobre isso, notaste alguma melhoria desde a última sessão?"

    # say L802 ang
    old "I have tried all the ways but it feels really disgusting."
    new "B:ang: Hmm... Bem, estou a fazer o que me pediste, mas não me sinto realmente confortável quando o faço..."

    # say L803 joh
    old "No worries darling, I understand and it's totally ok, it's part of the expectations we had set previously, so it's ok to feel that way..."
    new "B:ang: Já tentei todas as maneiras, mas sinto-me mesmo nojenta."

    # say L805 ang
    old "You are the only person I feel free to share this with."
    new "B:joh: Não te preocupes querida, eu entendo e está tudo bem, faz parte das expectativas que tínhamos definido anteriormente, por isso é normal sentires-te assim..."

    # say L806 joh
    old "And I'm here for you, and I'll see to it that we get through this problem once and for all."
    new "B:ang: Tu és a única pessoa com quem me sinto livre para partilhar isto."

    # say L807 ang
    old "I really appreciate that, because I have nothing else to do and..."
    new "T: Aprecio muito isso, porque não tenho mais nada para fazer e..."

    # say L810 joh
    old "And? Is it everything ok Angelina?"
    new "B:ang: Aprecio muito isso, porque não tenho mais nada para fazer e..."

    # say L811 ang
    old "I think it is not."
    new "T(ang|tu|say): Acho que não."

    # say L812 joh
    old "Is there something else you think I need to know?"
    new "B:ang: Acho que não."

    # say L813 ang
    old "Well, lately we have been fighting a lot because of that."
    new "B:joh: Há algo mais que achas que eu preciso saber?"

    # say L815 joh
    old "Oh, darling, I understand how hard it must be, it's not your fault of course."
    new "B:ang: Bem, ultimamente temos estado a discutir muito por causa disso."

    # say L816 ang
    old "I'd love to think it's not my fault, but I know it is, it's me not working the way it should."
    new "B:joh: Oh, querida, eu entendo o quão difícil deve ser, claro que não é tua culpa."

    # say L817 joh
    old "Honey, I know how you feel, but I've seen the progress from a different perspective and I can assure you that you've been doing your best."
    new "B:ang: Gostava de pensar que não é culpa minha, mas sei que é, sou eu que não estou a funcionar como devia."

    # say L819 ang
    old "I'm not sure about that..."
    new "A:joh: Angelina, lembra-te que falámos disso no início."

    # say L820 joh
    old "Angelina remember we talked about it at the beginning."
    new "B:ang: Não tenho a certeza disso..."

    # say L821 joh
    old "Some treatments may take longer than expected and the results won't be seen in the short term, you have to be patient."
    new "B:joh: Angelina, lembra-te que falámos disso no início."

    # say L822 ang
    old "I know, I know, you are right-"
    new "B:joh: Alguns tratamentos podem demorar mais do que o esperado e os resultados não serão visíveis a curto prazo, tens de ter paciência."

    # say L823 joh
    old "This is one of the stages we can be on, the treatment is working..."
    new "B:ang: Eu sei, eu sei, tens razão..."

    # say L824 joh
    old "We need to keep calm and keep working. I know today's session will show some improvements."
    new "B:joh: Esta é uma das fases em que podemos estar, o tratamento está a funcionar..."

    # say L826 joh
    old "I am sure of it."
    new "B:joh: Precisamos de manter a calma e continuar a trabalhar. Sei que a sessão de hoje vai mostrar algumas melhorias."

    # say L827 ang
    old "Oh, great please, I need to get this resolved as soon as possible."
    new "T: Oh, ótimo, por favor, preciso resolver isto o mais rápido possível."

    # say L828 joh
    old "Ok, so let's get started. We don't have time to lose."
    new "B:ang: Oh, ótimo, preciso que isto seja resolvido o mais rápido possível."

    # say L829 ang
    old "Perfect! Thank you."
    new "T(ang|tu|say): Perfeito! Obrigada."

    # say L830 joh
    old "Okay, let's start with the previous exercise, remember? The one with the dildo?"
    new "B:ang: Perfeito! Obrigado."

    # say L831 ang
    old "Hmm, I'm not sure, I mean, it's quite different when I do it with a dildo than it is with a real one, you know?"
    new "B:joh: Okay, vamos começar com o exercício anterior, lembras-te? O que tínhamos feito com o consolo?"

    # say L832 joh
    old "Of course, and that is why today we are going to do the exercise bandaged."
    new "B:ang: Hmm, não tenho a certeza, quero dizer, é bastante diferente quando o faço com um consolo do que com um pénis real, sabes?"

    # say L833 joh
    old "I want you to focus on the sensations, your caresses, and your mouth."
    new "B:joh: Claro, e por isso hoje vamos fazer o exercício vendado."

    # say L834 ang
    old "Hmm ok, that sounds interesting..."
    new "B:joh: Quero que te concentres nas sensações, nas tuas carícias e na tua boca."

    # say L835 joh
    old "It is, and today I bring you a new toy, this one is particularly realistic, and this would help us take big steps in treatment..."
    new "B:ang: Hmm ok, isso soa interessante..."

    # say L836 ang
    old "Huh! That sounds really nice."
    new "B:joh: É, e hoje trago-te um novo brinquedo, este é particularmente realista, e vai ajudar-nos a dar grandes passos no tratamento..."

    # say L837 joh
    old "Ok, let's get comfortable, and start with the session."
    new "B:ang: Huh! Isso soa mesmo bem."

    # say L849 joh
    old "I want you to play with it, rediscover its shape, I want you to immerse yourself in it, discover the textures, the flavors, the sensations."
    new "B:joh: Ok, vamos ficar confortáveis e começar a sessão."

    # say L851 joh
    old "Remember that the main objective is to replicate this moment with your husband, try to enjoy it, and focus on pleasure."
    new "B:joh: Quero que brinques com ele, redescubras a sua forma, quero que te imergas nele, descubras as texturas, os sabores, as sensações."

    # say L852 joh
    old "Keep in mind, his pleasure will also be your satisfaction."
    new "A:joh: Está bom?"

    # say L854 joh
    old "Is it good?"
    new "B:joh: Lembra-te, o prazer dele será também a tua satisfação."

    # say L855 ang
    old "Yes."
    new "A:joh: Usa a tua boca toda, os teus lábios, bem húmidos para poderes movê-los livremente e sedutoramente."

    # say L856 joh
    old "Use your whole mouth, your lips, moistened enough that you can move them freely and seductively."
    new "B:ang: Sim."

    # say L857 ang
    old "I- I think I like it... a bit."
    new "B:joh: Usa toda a boca, os lábios, bem húmidos para poderes movê-los livremente e sedutoramente."

    # say L858 joh
    old "That is perfect, now let's move on."
    new "B:ang: Eu... Acho que gosto... um bocadinho."

    # say L865 pla
    old "(Oh God...){i} I- I'm coming.{/i}"
    new "B:joh: {i}Pss! Pss! Vem cá, é a tua vez.{/i}"

    # say L875 joh
    old "Enjoy this new toy I have for you, the exercise will be better, and you will find it almost real, so please let me know what you think."
    new "B:joh: Ok, espera um momento, aqui está o novo brinquedo. Vamos fazer o mesmo processo que fizemos com o anterior."

    # say L877 ang
    old "Oh yes, this texture is really different... Something tasty, warm and the texture is flexible."
    new "B:joh: Aproveita este novo brinquedo que tenho para ti, o exercício vai ser melhor e vais achar quase real, então por favor diz-me o que achas."

    # say L878 joh
    old "I'm glad you like it, please do it like we have learned."
    new "B:ang: Oh sim, esta textura é realmente diferente... Algo saboroso, quente e a textura é flexível."

    # say L888 joh
    old "Yeah, please enjoy it, let's do the exercise, imagine it's natural, think he needs to feel really pleased..."
    new "B:joh: Fico contente que gostes, faz como aprendemos."

    # say L889 joh
    old "Remember to change the rhythm and to use the fluids to make it easier."
    new "B:joh: Sim, desfruta, vamos fazer o exercício, imagina que é natural, pensa que ele precisa sentir-se realmente satisfeito..."

    # say L891 joh
    old "Do you think the bandage on your eyes is helping?"
    new "B:joh: Lembra-te de alterar o ritmo e de usar os fluidos para facilitar."

    # say L892 ang
    old "Absolutely, I'm just thinking on what you are saying and focus on the exercise and the sensations."
    new "B:joh: Tu achas que a bandagem nos olhos está a ajudar?"

    # say L893 joh
    old "Perfect, I knew it was going to work..."
    new "B:ang: Absolutamente, estou a pensar no que estás a dizer e a focar-me no exercício e nas sensações."

    # say L894 ang
    old "This one is pretty nice, it tastes really good."
    new "B:joh: Perfeito, eu sabia que ia resultar..."

    # say L895 joh
    old "That's great, I want you to enjoy it, try a little harder, and think of it as a real one."
    new "B:ang: Este está bastante bom, tem um sabor delicioso."

    # say L908 joh
    old "Angelina, relax. This is part of the treatment."
    new "B:joh: Isso é ótimo, quero que tu disfrutes, tenta um pouco mais e pensa nisso como se fosse real."

    # say L910 ang
    old "What?! B- But- Who is he? D- Did I sucked his- ? Why didn't you tell me?"
    new "B:joh: Angelina, relaxa. Isto faz parte do tratamento."

    # say L911 joh
    old "He is one of my assistants and is specifically trained for this."
    new "B:ang: O quê?! B- Mas- Quem é ele? D- Eu chupei o-? Porque não me disseram?"

    # say L912 joh
    old "This was necessary, we were stuck for weeks, you needed a shock therapy to progress."
    new "B:joh: Ele é um dos meus assistentes e foi especificamente treinado para isso."

    # say L913 ang
    old "What? B- but... I- I cheated on my husband because of you!"
    new "B:joh: Isto era necessário, estávamos presos há semanas, tu precisavas de uma terapia de choque para avançar."

    # say L914 joh
    old "Again, calm down Angelina..."
    new "B:ang: O quê? B- mas... Eu- Eu traí o meu marido por tua causa!"

    # say L915 joh
    old "This wasn't cheating, everything was done professionally, in a controlled environment and under my supervision."
    new "B:joh: Calma, Angelina..."

    # say L917 ang
    old "B- but I sucked another guy's cock and I don't even know him! I can't understand, I didn't want to do this to my husband..."
    new "B:joh: Isto não foi traição, tudo foi feito de forma profissional, num ambiente controlado e sob a minha supervisão."

    # say L918 joh
    old "Listen Angelina, this is part of the treatment, we have been going through a long process."
    new "B:ang: B- mas eu chupei o pénis de outro homem e nem sequer o conheço! Não consigo entender, não queria fazer isto ao meu marido..."

    # say L919 joh
    old "And this was a great step, and it's the right one to solve your problem."
    new "A:ang: I- I só-"

    # say L920 ang
    old "I- I just-"
    new "A:joh: Tu percebes os resultados desta sessão?"

    # say L921 joh
    old "Do you realize the results of this session?"
    new "B:ang: I- I just-"

    # say L922 joh
    old "You did great, you were very confident, you enjoyed the session, everything went just as planned."
    new "B:joh: Tu percebes os resultados desta sessão?"

    # say L923 ang
    old "B- but... I- I- ... and He... Who is-"
    new "B:joh: Tu foste ótima, estiveste muito confiante, gostaste da sessão, tudo correu exatamente como planeado."

    # say L928 ang
    old "I'm sorry, but I can't accept this, I feel like I'm betraying my husband..."
    new "B:joh: Ele foi preparado por mim e seguiu os tratamentos de outro paciente, é muito profissional e de confiança."

    # say L929 ang
    old "I think there was a misunderstanding about this... I need to go."
    new "B:ang: Sinto muito, mas não posso aceitar isto, sinto-me a trair o meu marido..."

    # say L937 pla
    old "Wow, she has left!"
    new "B:ang: Acho que houve um mal-entendido... Preciso ir."

    # say L938 joh
    old "It's okay, she has a lot of emotions to think about."
    new "B:pla: Uau, ela foi embora!"

    # say L939 joh
    old "So she's going to need some time to process what happened and understand what was necessary within his process."
    new "B:joh: Tudo bem, ela tem muitas emoções para processar."

    # say L941 joh
    old "Absolutely! That's what is called 'shock therapy'."
    new "B:joh: Ela vai precisar de algum tempo para processar o que aconteceu e entender o que era necessário no processo dele."

    # say L942 pla
    old "But, looks like she feels pretty bad."
    new "B:joh: Absolutamente! É o que se chama 'terapia de choque'."

    # say L944 joh
    old "Well, it is something that needs to happen."
    new "B:pla: Mas, parece que ela se sente bastante mal."

    # say L945 joh
    old "She is dealing with changing the most ingrained ideas about her sexuality and the way she expresses her love, so she needs time."
    new "B:joh: Bem, é algo que tem de acontecer."

    # say L947 joh
    old "The only thing we can do is wait until she internalizes these new emotions and figure out how to deal with them."
    new "B:joh: Ela está a lidar com as ideias mais arraigadas sobre a sua sexualidade e a forma como expressa o seu amor, por isso precisa de tempo."

    # say L948 pla
    old "I understand."
    new "T(pla|tu|say): Entendo."

    # say L949 joh
    old "I appreciate your commitment, you did an amazing job today."
    new "B:pla: Entendi."

    # say L950 joh
    old "I'm sorry, but I have to go, another patient should be here in a few minutes."
    new "B:joh: Aprecio o teu compromisso, fizeste um trabalho incrível hoje."

    # say L951 pla
    old "Oh ok... But when should I come again?"
    new "B:joh: Desculpa, mas tenho de ir, outro paciente deve chegar daqui a poucos minutos."

    # say L952 joh
    old "Once Angelina books her next session I will let you know, for now you can come in the morning to continue training."
    new "B:pla: Oh ok... Mas quando devo voltar?"

    # say L973 roo
    old "No Angelina, I can't tolerate this anymore!"
    new "B:pla: Ok, até logo, doutor."

    # say L974 ang
    old "I'm doing all what I can, just to make you happy."
    new "B:roo: Não Angelina, não posso tolerar isto mais!"

    # say L975 roo
    old "I don't see the effort you make, and I'm tired of waiting so long for you."
    new "B:ang: Estou a fazer tudo o que posso, só para te fazer feliz."

    # say L976 ang
    old "Why are you such a prick? You can't see how much I love you..."
    new "B:roo: Não vejo o esforço que fazes e estou cansado de esperar tanto por ti."

    # say L977 roo
    old "I know that but I need a real woman, not a beautiful doll beside me..."
    new "B:ang: Porque é que és tão chato? Não vês o quanto eu te amo..."

    # say L978 roo
    old "I have been really patient... But I can't wait anymore... Look for me when you are ready to have sex like a normal person."
    new "B:roo: Eu sei, mas preciso de uma mulher de verdade ao meu lado, não de uma bela boneca..."

    # say L979 ang
    old "Come on darling... Please, you know this is hard for me..."
    new "B:roo: Tenho sido muito paciente... Mas já não aguento mais... Procura-me quando estiveres pronta para fazermos sexo como pessoas normais."

    # say L980 roo
    old "Are you serious? Listen 5 months without sex I- I... You know what? I will not discuss it anymore, see you later at home..."
    new "B:ang: Vamos, querida... Por favor, sabes que isto é difícil para mim..."

    # say L987 ang
    old "Wait! Roonnie- !"
    new "B:roo: Estás a falar a sério? Ouve, 5 meses sem sexo, eu... Sabes o que? Não vou discutir mais, vejo-te mais tarde em casa..."

    # say L994 pla
    old "I'm sorry..."
    new "Tudo bem, bem-vindo..."

    # say L999 ang
    old "It's ok, welcom-"
    new "B:pla: Desculpa..."

    # say L1000 ang
    old "(WHAT IS HE DOING HERE?.)"
    new "B:ang: Tudo bem, benvindo..."

    # say L1001 pla
    old "Huh, t- thank you."
    new "B:ang: (O QUE É QUE ELE ESTÁ A FAZER AQUI?.)"

    # say L1002 ang
    old "N- nice to see you again... Ehh-"
    new "T: N- nice to see you again... Ehh-"

    # say L1004 ang
    old "Yes, the doctor Johnson's... assistant, right?"
    new "B:ang: N- nice to see you again... Ehh-"

    # say L1006 pla
    old "Right, is Roonnie your husband?"
    new "B:ang: Sim, o assistente do doutor Johnson, certo?"

    # say L1008 ang
    old "Hmm it seems like not for long... Anyway, how are you?"
    new "B:pla: Certo, o Roonnie é teu marido?"

    # say L1010 pla
    old "I'm fine, thanks for asking..."
    new "T(pla|tu|say): Estou bem, obrigado por perguntar..."

    # say L1011 ang
    old "Great, and what are you doing here?"
    new "A:pla: Desculpa, não sabia que tu estavas aqui-"

    # say L1012 pla
    old "I'm sorry, I was not aware you were here-"
    new "B:ang: Ótimo, e o que estás a fazer aqui?"

    # say L1013 ang
    old "Oh no don't worry, actually, I'm sorry that you had to listen to all of... This."
    new "B:pla: Desculpa, não sabia que estavas aqui-"

    # say L1014 pla
    old "Oh no, it wasn't my intention, I- I didn't know-"
    new "A:ang: Não importa, mas tenho pensado no que aconteceu da última vez e queria pedir desculpa pelo incidente no gabinete do Dr. Johnson."

    # say L1015 ang
    old "Never mind, though, I've been thinking about last time and wanted to apologize for the incident in Dr. Johnson's office."
    new "B:pla: Oh não, não foi minha intenção, eu- eu não sabia-"

    # say L1016 pla
    old "Oh, no worries about that, I'm sorry about you and husband, I know it's something hard to deal with."
    new "B:ang: Não importa, mas tenho pensado no que aconteceu na última vez e queria pedir desculpa pelo incidente no gabinete do Dr. Johnson."

    # say L1017 ang
    old "Yes, he is lovely but he is also tired, he is right about what he says, I can't satisfy his needs..."
    new "B:pla: Oh, não te preocupes com isso, sinto muito por ti e pelo teu marido, sei que é algo difícil de lidar."

    # say L1019 ang
    old "I'm sorry to tell you all this, I don't even know you..."
    new "B:ang: Sim, ele é adorável, mas também está cansado, tem razão no que diz, não consigo satisfazer as suas necessidades..."

    # say L1020 pla
    old "It's ok, don't worry."
    new "T(pla|tu|say): Tudo bem, não te preocupes."

    # say L1021 ang
    old "I appreciate that... And I still embarrassed about the last time-"
    new "B:pla: Tudo bem, não te preocupes."

    # say L1022 pla
    old "Oh please forget it, it's not important."
    new "B:ang: Aprecio isso... E ainda me sinto embaraçado pelo que aconteceu da última vez..."

    # say L1023 ang
    old "It is, I was disrespectful to both of you and left the place without any explanation, and it's not your fault of course."
    new "T: É importante, fui desrespeitoso/a com ambos e saí do lugar sem qualquer explicação, e claro que não é culpa tua."

    # say L1025 ang
    old "I felt like I was betraying my husband, I had never cheated on him and I really love him..."
    new "B:ang: É verdade, fui desrespeitoso com ambos e saí sem dar qualquer explicação, e claro que não é culpa de vocês."

    # say L1026 ang
    old "I still don't know why doctor Johnson did something like that."
    new "B:ang: Sentia-me como se estivesse a trair o meu marido, nunca lhe fui infiel e amo-o muito..."

    # say L1027 pla
    old "I understand your point, I can't say too much because I was part of the session but..."
    new "T: Entendo a tua preocupação, não posso dizer muito porque participei da sessão, mas..."

    # say L1028 pla
    old "I know she is quite good at what she does, I have seen the progress of other patients."
    new "T(tu|dizer): Eu sei que ela é bastante boa no que faz, já vi o progresso de outros pacientes."

    # say L1031 pla
    old "Yes, that is why I met her, because one of my friends needed help."
    new "B:pla: Eu sei que ela é bastante boa no que faz, já vi o progresso de outros pacientes."

    # say L1032 pla
    old "And it was a very surprising thing to see how she changed and how positive it was for her."
    new "B:pla: Sim, foi por isso que a conheci, porque um dos meus amigos precisava de ajuda."

    # say L1033 ang
    old "Hmm, I don't know..."
    new "B:pla: E foi surpreendente ver como ela mudou e como foi positivo para ela."

    # say L1034 pla
    old "I know, at the beginning I was sceptical..."
    new "T(pla|tu|say): Eu sei, no início eu era cético..."

    # say L1035 pla
    old "But later on, my friend was improving so much that I had to be honest and recognize how amazing she did it with her treatment."
    new "B:pla: Eu sei, no início eu era cético..."

    # say L1036 ang
    old "I think I am sceptical now..."
    new "B:pla: Mas mais tarde, a minha amiga melhorou tanto que tive de ser honesta e reconhecer o quão incrível ela se saiu com o tratamento."

    # say L1037 pla
    old "It is pretty normal, your process is not easy and these experiences are new for everyone."
    new "T: É bastante normal, o teu processo não é fácil e estas experiências são novas para todos. A: No entanto, se ela se atreve a tentar este método, é porque te conhece bem o suficiente."

    # say L1038 pla
    old "However, if she dares to try this method, it is because she knows you well enough."
    new "B:pla: É bastante normal, o teu processo não é fácil e estas experiências são novas para todos."

    # say L1040 pla
    old "I must confess that I was a bit nervous, but we were in a very professional environment."
    new "B:pla: No entanto, se ela ousou tentar este método, é porque te conhece bem."

    # say L1041 pla
    old "Everything was planned to make sure that you could overcome your fear."
    new "B:pla: Tenho de confessar que estava um pouco nervoso, mas estávamos num ambiente muito profissional."

    # say L1042 ang
    old "Hmm, I thinnk you are right, maybe I overreacted that day, my marriage needs whatever effort I can make."
    new "B:pla: Tudo foi planeado para que pudesses superar o teu medo."

    # say L1043 pla
    old "I know you were confused but I am sure doctor Johnson is expecting to see you again no matter what happens before."
    new "B:ang: Hmm, acho que tens razão, talvez tenha exagerado nesse dia, o meu casamento precisa de todo o esforço que eu puder fazer."

    # say L1044 ang
    old "I owe her an apology, but yes I need to solve this problem as soon as possible."
    new "B:pla: Eu sei que estavas confuso, mas tenho a certeza de que a doutora Johnson está à espera de te ver de novo, independentemente do que aconteça entretanto."

    # say L1045 pla
    old "She will be very happy to see you and the most important thing you can continue the process you are in, you need to trust her."
    new "T: Ela ficará muito feliz por te ver e o mais importante é que tu podes continuar o processo em que estás, precisas de confiar nela."

    # say L1046 ang
    old "You're right, I need this now more than ever, my husband is about to dump me, so I'll do whatever it takes."
    new "B:pla: Ela ficará muito feliz por te ver e a coisa mais importante é que tu podes continuar o processo em que estás, precisas de confiar nela."

    # say L1047 pla
    old "Don't worry, visit doctor Johnson, she will help you."
    new "B:ang: Tens razão, preciso disto agora mais do que nunca, o meu marido está prestes a deixar-me, por isso farei o que for preciso."

    # say L1048 ang
    old "Hmm alright, I will do an appointment,  I think I need to continue with my treatment, thank you so much for your words."
    new "B:pla: Não te preocupes, visita a doutora Johnson, ela vai ajudar-te."

    # say L1049 pla
    old "You are welcome,I hope things improve soon."
    new "B:ang: Hmm, tudo bem, vou marcar uma consulta, acho que preciso continuar o meu tratamento, muito obrigado pelas tuas palavras."

    # say L1050 ang
    old "I appreciate it."
    new "B:pla: De nada, espero que as coisas melhorem em breve."

    # say L1051 pla
    old "Good bye."
    new "B:ang: Aprecio isso."

    # say L1052 ang
    old "Bye Bye."
    new "B:pla: Adeus."

    # say L1076 joh
    old "Welcome back Angelina, I am very happy to have you here again."
    new "B:ang: Adeus."

    # say L1077 ang
    old "Hi doctor, I'm terribly sorry for my behavior last time..."
    new "B:joh: Bem-vinda de volta, Angelina, estou muito contente por teres voltado."

    # say L1078 joh
    old "Listen, the past is just a page we can't see anymore. Now tell me, how is everything going?"
    new "B:ang: Olá doutor, peço desculpa pelo meu comportamento da última vez..."

    # say L1079 ang
    old "I need your help, my husband will dump me anytime because of my problem and I don't know what to do."
    new "B:joh: O passado é apenas uma página que já não conseguimos ver. Agora, conta-me, como é que tudo está?"

    # say L1080 joh
    old "Hmm, okay, we have to think carefully because we'll need something that will deliver immediate results."
    new "B:ang: Preciso da tua ajuda, o meu marido vai deixar-me a qualquer momento por causa do meu problema e não sei o que fazer."

    # say L1095 joh
    old "Well, now that [pla] is here, I have an idea to go ahead with the treatment."
    new "B:ang: Olá... [pla], é bom ver-te de novo."

    # say L1096 joh
    old "But how do you feel about what happened last time with [pla]?"
    new "B:joh: Bem, agora que [pla] está aqui, tenho uma ideia para avançar com o tratamento."

    # say L1098 joh
    old "Oh really? Well, that makes things a lot easier for us."
    new "B:ang: Hmm, tive a oportunidade de falar com ele e agora me sinto muito melhor."

    # say L1104 joh
    old "Also, Angelina, I want you to become more familiar with the image of your husband."
    new "B:joh: Mas antes de começarmos, quero que tu a ajudes a relaxar um pouco, então dá-lhe uma massagem."

    # say L1108 joh
    old "So, let's begin, please take off your shirt."
    new "T(joh|formal|say): Então, vamos começar, por favor, tira a tua camisa."

    # say L1109 ang
    old "But... I- I'm not wearing a bra..."
    new "B:joh: Então, vamos começar. Por favor, tira a tua camisa."

    # say L1110 joh
    old "I know that darling."
    new "B:ang: Mas... eu não estou a usar soutien..."

    # say L1111 ang
    old "So, do you mean stay topless?"
    new "B:joh: Eu sei, querida."

    # say L1112 joh
    old "That's correct, he will give you a little breasts massage, so, you can relax and get in the mood for the next exercise."
    new "B:ang: Então, tu queres dizer ficar de peito nu?"

    # say L1115 ang
    old "I- I am not... Sure about it..."
    new "B:joh: Isso está correto, ele vai te dar uma massagem nos seios, então, você pode relaxar e entrar no clima para o próximo exercício."

    # say L1116 joh
    old "Oh, darling, don't worry, we're already working on that, right? You shouldn't feel insecure about your body..."
    new "B:ang: I- Eu não tenho... A certeza..."

    # say L1117 ang
    old "I know, but... Having a man in the room makes this a little more difficult..."
    new "A:joh: Eu sei que tiveste uma adolescência difícil, o teu corpo cresceu depressa e não te sentias confortável com isso..."

    # say L1119 joh
    old "I know you had a tough adolescence, your body grew fast and you didn't feel comfortable about it..."
    new "B:ang: Eu sei, mas... Ter um homem no quarto torna isto um pouco mais difícil..."

    # say L1120 joh
    old "But, you already know that your body is beautiful, all men love it, your husband loves it, right?"
    new "B:joh: Eu sei que tiveste uma adolescência difícil, o teu corpo cresceu depressa e não te sentias confortável com isso..."

    # say L1121 ang
    old "Yes, but he doesn't care..."
    new "B:joh: Mas, tu já sabes que o teu corpo é lindo, todos os homens adoram-no, o teu marido adora-o, certo?"

    # say L1127 joh
    old "Honey, I can tell you that I have not seen a more beautiful breast."
    new "B:pla:... S- sim... Acho que tens um peito... Lindo..."

    # say L1128 ang
    old "It's the first time someone tells me that..."
    new "B:joh: Meu amor, posso-te dizer que nunca vi um peito mais bonito."

    # say L1129 joh
    old "It's not going to be the last time. I'm sure, now please get comfortable because our session about to begins."
    new "B:ang: É a primeira vez que alguém me diz isso..."

    # say L1132 ang
    old "Thank... You..."
    new "Bem, vamos tirar esses grandes..."

    # say L1133 joh
    old "Alright, let's take out those big babies..."
    new "B:ang: Obrigado..."

    # say L1141 joh
    old "Hahaha, you see Angelina, now he is speechless... Come on, [pla] please have a seat, and you Angelina, have a seat over his lap."
    new "B:joh: Ohhh, são mesmo lindas... Não achas [pla]?"

    # say L1151 joh
    old "Ok, [pla] to start, do it gently..."
    new "B:joh: Hahaha, vês Angelina, agora ele está sem palavras... Vamos, [pla], senta-te por favor, e tu Angelina, senta-te no colo dele."

    # say L1152 pla
    old "Ok, like this?"
    new "A:joh: Sim, como te sentes, Angelina?"

    # say L1153 joh
    old "Yeah, how do you feel Angelina?"
    new "B:pla: Ok, assim?"

    # say L1154 ang
    old "I- It's ok... I'm fine..."
    new "B:joh: Yeah, como te sentes, Angelina?"

    # say L1169 joh
    old "Yes, please, and then lie on the bed..."
    new "B:ang: Queres que tire tudo?"

    # say L1170 ang
    old "... Hmm alright."
    new "B:joh: Sim, por favor, e depois deita-te na cama..."

    # say L1173 pla
    old "My... T- turn? What do you mean?"
    new "A:joh: Desculpa, quis dizer que é a tua vez de agradar a Angelina. Agora faz sexo oral a ela."

    # say L1174 joh
    old "I'm sorry, I meant it's your turn to please Angelina. Now give oral sex to her."
    new "B:pla: A... A minha... T- vez? O que queres dizer?"

    # say L1175 ang
    old "O- oral sex?"
    new "T(ang|tu|say): O- oral sexo?"

    # say L1177 joh
    old "Ok, Angelina, please remember this is part of the treatment for you, and your marriage."
    new "B:ang: O- sexo oral?"

    # say L1178 ang
    old "You are right, I'm sorry."
    new "B:joh: Ok, Angelina, lembra-te de que isto faz parte do tratamento para ti e para o teu casamento."

    # say L1187 joh
    old "[pla] please do it as soft as possible, she must just feel you over there."
    new "B:joh: Tudo bem, vamos continuar, [pla] faz o teu trabalho, por favor."

    # say L1213 joh
    old "Well, that's fantastic because it means the process is working out."
    new "B:ang: Wow, tu não imaginas o quão feliz me sinto."

    # say L1214 joh
    old "If you feel more confident to have sexual interactions, it means you are ready to try this with your husband with no fears."
    new "B:joh: Ótimo, isso significa que o processo está a resultar."

    # say L1216 joh
    old "Great, so let's get dressed and go to the therapy bedroom."
    new "B:joh: Se te sentes mais confiante para ter interações sexuais, significa que estás pronta para experimentar isto com o teu marido sem medos."

    # say L1217 ang
    old "Ok!"
    new "Ok, foi tudo por hoje, mas precisamos continuar a trabalhar bastante."

    # say L1226 joh
    old "Ok, it was everything for today, but we need to continue working pretty hard."
    new "B:ang: Ok!"

    # say L1227 joh
    old "Next session is really important, so, guys please get ready and see you soon."
    new "B:joh: Ok, foi tudo para hoje, mas precisamos de continuar a trabalhar bastante."

    # say L1229 ang
    old "Oh thank you, I will be here on time, bye bye!"
    new "B:joh: A próxima sessão é muito importante, por isso, pessoal, preparem-se e vejo-vos em breve."

    # say L1230 pla
    old "Good bye!"
    new "T(pla|tu|say): Adeus!"

    # say L1245 joh
    old "Hi Angelina, how is everything going?"
    new "B:pla: Adeus!"

    # say L1246 ang
    old "Wonderful! I applied what we did with my husband and he was really happy, now I just want to learn more."
    new "B:joh: Olá Angelina, como está tudo?"

    # say L1247 joh
    old "And you will, our session today is aimed at helping you do more exercises with your husband."
    new "B:ang: Maravilhoso! Apliquei o que fizemos com o meu marido e ele ficou muito feliz, agora só quero aprender mais."

    # say L1248 ang
    old "Sounds great!"
    new "B:joh: E tu vais, a nossa sessão de hoje visa ajudar-te a fazer mais exercícios com o teu marido."

    # say L1260 joh
    old "Welcome [pla], good to see you again, are you ready to start the new session?"
    new "B:ang: Olá [pla], estou a sentir-me ótimo."

    # say L1265 joh
    old "Ok, Angelina, this time we are going to practice a fellation, this time with no fears and doing your best, ok?"
    new "B:pla: Sim, estou pronta."

    # say L1266 ang
    old "Oh... I had to... S- suck his cock?"
    new "B:joh: Ok, Angelina, desta vez vamos praticar uma felação, sem medos e fazendo o teu melhor, ok?"

    # say L1268 joh
    old "Of course, last time you received all the pleasure, today we will make sure that you are able to provide it too."
    new "B:ang: Oh... Tive que... S- sugar o seu pénis?"

    # say L1269 joh
    old "So that we can guarantee that your husband will also be satisfied."
    new "B:joh: Claro, da última vez foste tu a receber todo o prazer, hoje vamos garantir que também consegues proporcioná-lo."

    # say L1271 ang
    old "Hmm, I guess you are right..."
    new "B:joh: Para garantir que o teu marido também fique satisfeito."

    # say L1272 joh
    old "Great, just remember what we had practiced before with the dildo, and by the way you already sucked his cock before, so don't worry."
    new "B:ang: Hmm, acho que tens razão..."

    # say L1300 joh
    old "Alright, now let's continue with the next exercise."
    new "A:ang: PRÓXIMO EXERCÍCIO?"

    # say L1303 ang
    old "NEXT EXERCISE?"
    new "A:joh: Claro, foste tu quem pediu melhorias mais rápidas, não é?"

    # say L1305 joh
    old "Of course, you're the one asking for faster improvement, aren't you?"
    new "B:ang: PRÓXIMO EXERCÍCIO?"

    # say L1306 joh
    old "Also, we need you to be able to have sex with your husband as soon as possible, so your marriage can be saved."
    new "B:joh: Claro, és tu que estás a pedir melhorias mais rápidas, não é?"

    # say L1307 ang
    old "Hmm, you're right..."
    new "B:joh: Além disso, precisas de ter relações sexuais com o teu marido o mais rápido possível, para que o vosso casamento possa ser salvo."

    # say L1311 joh
    old "Oh, relax, you are going to love it."
    new "B:ang: Sexo?"

    # say L1323 joh
    old "Angelina, I need you to understand this, in your treatment, there is no way to learn about sex without having sex."
    new "B:joh: Vais ter relações, mas não podes parar até ela atingir o orgasmo."

    # say L1324 joh
    old "That is why we are here in a safe therapy so that you learn to enjoy it."
    new "B:joh: Angelina, precisas de entender isto, no teu tratamento, não há forma de aprender sobre sexo sem ter relações sexuais."

    # say L1325 ang
    old "... Ok, thank you doctor Johnson."
    new "B:joh: É por isso que estamos aqui em terapia segura, para que aprendas a desfrutar."

    # say L1326 joh
    old "Alright, please, both get naked and let's start."
    new "B:ang:... Ok, obrigado doutor Johnson."

    # say L1352 ang
    old "Wow, that was really good, I thank you so much doctor Johnson."
    new "B:joh: Ótimo, despeitem-se as duas e vamos começar."

    # say L1355 ang
    old "Yes, you [pla], you made me feel things I've never felt before with any man."
    new "B:joh: Ainda tens muito a aprender, mas agora estás aberto a novas experiências, e [pla] fizeste um trabalho excelente."

    # say L1358 joh
    old "Alright, get dressed and let's go to the therapy room, I have a new patient in a few minutes."
    new "B:pla:... Eu- Eu fico contente que tudo tenha corrido bem..."

    # say L1368 joh
    old "Alright, please apply these exercises with your husband."
    new "Bem, veste-te e vamos para a sala de terapia, tenho um novo paciente daqui a pouco. Tudo bem, aplica estes exercícios com o teu marido. Concentra-te em desfrutar, mas não forces, vais ver as mudanças gradualmente."

    # say L1369 joh
    old "Focus on enjoying, but don't push it, as you will see the changes gradually."
    new "B:joh: Muito bem, aplica estes exercícios com o teu marido."

    # say L1370 ang
    old "Ok, I will have that in mind."
    new "T: Ok, terei isso em mente."

    # say L1371 joh
    old "I'm glad to see you happy, I can't wait to hear how it went with your husband."
    new "B:ang: Ok, terei isso em mente."

    # say L1372 ang
    old "Yes, I am a little anxious to try it as soon as possible."
    new "B:joh: Fico contente por te ver feliz, mal posso esperar para saber como correu com o teu marido."

    # say L1373 joh
    old "Okay, then don't waste any more time and go home. See you at the next session, darling."
    new "B:ang: Sim, estou um pouco ansioso para experimentar o mais rápido possível."

    # say L1374 ang
    old "Alright, thank you so much!"
    new "B:joh: Óptimo, então não percas mais tempo e vai para casa. Até à próxima sessão, querida."

    # say L1375 joh
    old "See you. And please, have fun!"
    new "B:ang: Muito bem, obrigado!"

    # say L1385 joh
    old "That was a significant step with her therapy."
    new "B:joh: Até logo. E por favor, diverte-te!"

    # say L1387 joh
    old "And you, Congratulations on such a fantastic performance, I can see that my lessons were very helpful, maybe better than I thought."
    new "B:joh: Foi um passo importante na terapia dela."

    # say L1388 pla
    old "Thank you, I appreciate all your patient with me."
    new "B:joh: E tu, parabéns por esta fantástica performance, vejo que as minhas lições foram muito úteis, talvez mais do que eu pensava."

    # say L1389 joh
    old "You are welcome. Anyway, I have to get ready for my next patient, so, see you at the next session."
    new "B:pla: Obrigado, aprecio toda a tua paciência comigo."

    # say L1390 pla
    old "Sure, good bye Dr. Johnson."
    new "B:joh: De nada. De qualquer forma, tenho que me preparar para o meu próximo paciente, então, até à próxima sessão."

    # say L1406 joh
    old "Welcome Angelina, how is everything going?"
    new "B:pla: Claro, adeus Dr. Johnson."

    # say L1407 ang
    old "I couldn't be happier."
    new "B:joh: Bem-vinda Angelina, como está tudo?"

    # say L1408 joh
    old "So, were you able to do the exercises with your husband without problems? "
    new "B:ang: Não podia estar mais feliz."

    # say L1409 ang
    old "That's right! And my husband is really happy, your work is incredible!"
    new "B:joh: Então, conseguiste fazer os exercícios com o teu marido sem problemas?"

    # say L1410 joh
    old "I'm so happy to hear that! I've prepared a new lesson today, you'll love it..."
    new "B:ang: Isso mesmo! E o meu marido está mesmo feliz, o teu trabalho é incrível!"

    # say L1425 joh
    old "Well guys, now [pla] is here, there's no time to lose, so, let's go to the room."
    new "B:ang: Olá, [pla]!!"

    # say L1434 joh
    old "According to the advances that you mentioned that sex with your husband is reaching... Let's practice again with a sexual exercise."
    new "B:ang: Perfeito!"

    # say L1436 joh
    old "But, before we start, I want you to practice oral sex, that will drive your husband crazy."
    new "B:joh: De acordo com os avanços que mencionaste que tens tido com o sexo com o teu marido... Vamos praticar de novo com um exercício sexual."

    # say L1437 ang
    old "Got it! I want to make sure I'm doing this the right way for my husband."
    new "A:joh: Agora que estamos prontos, tenho uma tarefa especial para ti, Angelina."

    # say L1454 joh
    old "Now that we are ready, I have a special task for you Angelina."
    new "B:ang: Entendido! Quero ter a certeza de que estou a fazer isto da maneira certa para o meu marido."

    # say L1455 ang
    old "Ok, I'm ready for whatever you want."
    new "A:joh: Adoro essa entusiasmo! Quero que tu assumes o controlo e fodes com ele de forma selvagem, quero que sejas tu a dizer o que fazer."

    # say L1456 joh
    old "I love that enthusiasm! I want you to take the lead and fuck him wild, I want you to be the one to say what to do."
    new "B:ang: Ok, estou pronto para o que tu quiseres."

    # say L1457 joh
    old "So, I want you to get on him and take the rhythm and intensity, I want you to take an active role in sex..."
    new "B:joh: Adoro essa entusiasmo! Quero que tu tomes a frente e fodes com ele selvagemente, quero que sejas tu a dizer o que fazer."

    # say L1477 joh
    old "I appreciate all the effort you did, I know it was not easy but now you can see the results."
    new "B:ang: Tu és o terapeuta mais incrível que já tive."

    # say L1478 ang
    old "Doctor, I have, no words to say how much I thank you for all the knowledge and patience you invested..."
    new "B:joh: Aprecio todos os esforços que fizeste, sei que não foi fácil, mas agora podes ver os resultados."

    # say L1483 joh
    old "Ok, it's time guys, get dressed and let's go to the therapy bedroom..."
    new "B:pla: É um prazer, fico contente por ter ajudado."

    # say L1494 joh
    old "Ok, today we finished our team practice sessions. Angelina, you and I will continue the process together with therapy."
    new "B:joh: Ok, é hora, vistam-se e vamos para o quarto de terapia..."

    # say L1498 ang
    old "Oh, alright..."
    new "B:joh: Não, ele fez o seu trabalho e agora podemos continuar com a terapia. Agora é o momento de colocar tudo isto em prática com o teu marido."

    # say L1502 ang
    old "I will practice a lot with him! Thank you doctor Johnson, I will call you to make a new appointment."
    new "B:ang: Oh, ótimo, fico contente por ouvir isso. De qualquer forma, não consigo descrever o quão feliz estou e o quão feliz vou fazer o meu marido..."

    # say L1503 joh
    old "Ok, please have fun, it was nice to walk you through this process."
    new "B:ang: Vou praticar muito com ele! Obrigada, doutor Johnson, vou telefonar-te para marcar uma nova consulta."

    # say L1506 pla
    old "Uhh... Goodbye Angelina."
    new "B:joh: Ok, diverte-te, foi agradável acompanhar-te neste processo."

    # say L1516 joh
    old "I know. By the way,  I want to have another session, just for you and me..."
    new "B:pla: Oh, obrigado, eu apenas segui todas as tuas instruções."

    # say L1517 joh
    old "But I have another patient coming, it's too late to cancel it..."
    new "B:joh: Eu sei. Aliás, quero ter outra sessão, só para ti e para mim..."

    # say L1518 pla
    old "Another session, what do you mean?"
    new "B:joh: Mas tenho outro paciente a chegar, é demasiado tarde para cancelar..."

    # say L1520 joh
    old "Hmm, I mean I need to check something, so let's call it another lesson..."
    new "B:pla: Outra sessão, o que queres dizer?"

    # say L1521 pla
    old "... Hmm ok, sure."
    new "B:joh: Hmm, quero dizer, preciso verificar algo, então vamos chamar isso de outra aula..."

    # say L1522 joh
    old "I know next session is going to be pretty fun, so please sleep well."
    new "B:pla:... Hmm ok, claro."

    # say L1524 joh
    old "I am considering giving you a prize before we start another treatment, just because you were amazing with Angelina..."
    new "B:joh: Sei que a próxima sessão vai ser bem divertida, por isso dorme bem."

    # say L1526 joh
    old "Just come see me tomorrow and don't be late."
    new "B:joh: Estou a considerar dar-te um prémio antes de começarmos outro tratamento, só porque foste incrível com Angelina..."

    # say L1527 pla
    old "Alright, I will be here."
    new "B:joh: Vê-me amanhã e não cheges atrasado."

    # say L1528 joh
    old "Great, see you!"
    new "Olá, estava a esperar-te desesperadamente."

    # say L1543 joh
    old "Hi, I was waiting for you desperately."
    new "B:joh: Ótimo, até já!"

    # say L1544 pla
    old "Good morning, thank you I tried to be on time-"
    new "B:joh: Olá, estava a esperar por ti desesperadamente."

    # say L1545 joh
    old "You are, don't worry! It's just that I don't want to talk."
    new "B:pla: Bom dia, obrigado, tentei chegar a tempo..."

    # say L1546 pla
    old "Uhh, w- wha-?"
    new "B:joh: Tu és, não te preocupes! É só que não quero falar."

    # say L1548 joh
    old "Let's go to the room, there is no time to lose."
    new "B:pla: Uhh, w- w-..."

    # say L1555 joh
    old "Well, I want to fuck you right now, no lessons, no patients just hard sex."
    new "B:joh: Vamos para o quarto, não há tempo a perder."

    # say L1557 joh
    old "Why don't you make yourself comfortable and let me suck your dick?"
    new "B:joh: Bem, quero foder-te agora, sem aulas, sem pacientes, só sexo duro."

    # say L1580 joh
    old "Yummy!"
    new "B:joh: Porque não te pões à vontade e deixas-me chupar-te o pénis?"

    # say L1587 joh
    old "It's delicious, do you like the way I suck it?"
    new "B:joh: Que delícia!"

    # say L1598 joh
    old "Wow, I needed that session. You can't imagine how hot it was, you did amazing."
    new "B:joh: É delicioso, gostas da forma como te chupo?"

    # say L1599 pla
    old "I did my best."
    new "B:joh: Uau, precisava mesmo dessa sessão. Não imaginas o quão quente foi, foste incrível."

    # say L1600 joh
    old "Absolutely, you fucked me as I needed to.  I think I need a little more, though..."
    new "B:pla: Fiz o meu melhor."

    # say L1601 joh
    old "Just keeps coming over sometimes just to... You know, have some fun lessons."
    new "B:joh: Absolutamente, tu fodeste-me como eu precisava. Acho que preciso de um pouco mais, no entanto..."

    # say L1603 joh
    old "Perfect, and when I need your help again with another patient, I'll let you know."
    new "B:joh: Aparece por aqui às vezes só para... Sabes, ter algumas aulas divertidas."

    # say L1629 pla
    old "Oh, wow."
    new "B:pla: Entendido. Até logo, doutor Johnson."

    # say L1630 roo
    old "Hey buddy! What's up?"
    new "B:pla: Oh, wow."

    # say L1636 pla
    old "Uhh... W- well- "
    new "B:roo: Oh, então vocês se conhecem?"

    # say L1638 ang
    old "Yes! He is the assistant of doctor Johnson... He helped us with... With the treatment..."
    new "B:pla: Uhh... B-bem..."

    # say L1639 roo
    old "Wow, you are quite young, I didn't know you had such wonderful therapy abilities. You must know buddy, you saved my marriage!"
    new "B:ang: Sim! Ele é o assistente do doutor Johnson... Ele nos ajudou com... Com o tratamento..."

    # say L1641 roo
    old "You don't know how important was this, I feel so thankful that I hope you go to the store so I can give an enormous discount."
    new "B:roo: Uau, és bastante jovem, não sabia que tinhas habilidades terapêuticas tão maravilhosas. Deves saber, tu salvaste o meu casamento!"

    # say L1642 pla
    old "Oh, thanks."
    new "B:roo: Não sabes o quanto isto foi importante, sinto-me tão grato que espero que vás à loja para te dar um desconto enorme."

    # say L1643 roo
    old "I have no words to tell how I appreciate what you did for me, look Angelina is pregnant and we are very happy about it."
    new "B:pla: Oh, obrigado."

    # say L1646 roo
    old "I know the universe will reward you for this magnificent help and-"
    new "B:roo: Não tenho palavras para expressar o quanto aprecio o que fizeste por mim, olha, Angelina está grávida e estamos muito felizes com isso."

    # say L1647 ang
    old "We really appreciate your help. Darling we need to go, I want to get some fresh air."
    new "B:roo: Eu sei que o universo te recompensará por esta ajuda magnífica e-"

    # say L1648 pla
    old "Oh sure, it was nice to see that you guys are happy."
    new "B:ang: Agradecemos mesmo a tua ajuda. Querida, precisamos de ir, quero tomar um pouco de ar fresco."

    # say L1649 roo
    old "We are very happy to see you too, now excuse us, we have to go."
    new "T(roo|tu|say): Estamos muito felizes por te ver também, agora desculpa-nos, temos que ir."

    # say L1650 pla
    old "... Sure."
    new "B:roo: Estamos muito felizes por te ver também, agora desculpa-nos, temos que ir."

    # say L1651 ang
    old "Have a nice day [pla]!"
    new "T(ang|tu|say): Tenha um bom dia [pla]!"

    # say L1653 pla
    old "See you!"
    new "B:roo: Claro, meu amigo! Que tenhas um ótimo dia. T(pla|tu|say): Até logo! A:pla: Uau... Então, ela está grávida..."

    # say L1658 pla
    old "Wow... So, she is pregnant..."
    new "B:pla: Até logo!"

    # say L1674 pla
    old "Hi Dr. Johnson, how are you?"
    new "B:pla: Wow... Então, ela está grávida..."

    # say L1676 pla
    old "I'm good, thanks! And hmm, I would like to talk about s- something with you, it would take just a couple of minutes."
    new "T(pla|tu|say): Estou bem, obrigado! E hmm, gostava de falar sobre algo contigo, demoraria só uns minutos."

    # say L1677 joh
    old "Sure, what is it about?"
    new "B:pla: Estou bem, obrigado! E hmm, gostava de falar sobre algo contigo, demoraria só uns minutos."

    # say L1678 pla
    old "I wouldn't like to bother you but I'm f- facing a tough situation now and I'm l- looking for a job."
    new "T(pla|tu|say): Não gostaria de te incomodar, mas estou p- passando por uma situação difícil e estou à procura de trabalho."

    # say L1679 pla
    old "You know I'm a hard worker and I would do whatever you assign to me."
    new "B:pla: Não quero incomodar-te, mas estou a enfrentar uma situação difícil e estou à procura de trabalho."

    # say L1681 joh
    old "I see, but... I can't offer you anything right now."
    new "A:joh: Não tenho nenhum paciente para ti no momento..."

    # say L1682 joh
    old "I don't have any patients for you at the moment..."
    new "T(joh|formal|say): Não tenho nenhum paciente para ti no momento..."

    # say L1684 pla
    old "R- really? I had some hopes on you."
    new "T: Tu: R- realmente? Eu tinha algumas esperanças em ti."

    # say L1685 pla
    old "Maybe if you think of somethin-"
    new "B: R- realmente? Tinha algumas esperanças em ti."

    # say L1689 joh
    old "I'll call you when I need you..."
    new "B:joh: Foste muito bem treinado e foste excepcional nas tuas funções com o último paciente."

    # say L1691 pla
    old "I see... Hmm, alright... I'll keep looking for it. Thanks Dr. Johnson, I appreciate your time."
    new "B:joh: Vou-te ligar quando precisar de ti..."

    # say L1692 pla
    old "Goodbye and keep me posted in case you have jobs for me, I would appreciate it."
    new "B:pla: Entendo... Hmm, tudo bem... Vou continuar à procura. Obrigado, Dr. Johnson, aprecio o seu tempo."

    # say L1693 joh
    old "Sure I will, have a nice day."
    new "Claro que sim, tenha um bom dia."


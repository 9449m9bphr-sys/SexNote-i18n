# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/angAnimations.rpy
translate portuguese strings:

    # say L51 joh
    old "Are you enjoying it, honey?"
    new "Mmm, sim, este está a dar-me uma sensação bem quente e molhada."

    # say L52 ang
    old "Mmm, yes, this one is giving me a pretty warm and wet sensation."
    new "B:joh: Estás a gostar, querida?"

    # say L53 joh
    old "Okay, you're doing a great job, now try to do it a little faster."
    new "B:ang: Mmm, sim, este está a dar-me uma sensação bem quente e molhada."

    # say L59 joh
    old "Oh yeah, just like that honey, don't stop, you are gonna make him cum soon..."
    new "B:joh: Okay, estás a fazer um ótimo trabalho, agora tenta fazer um pouco mais rápido."

    # say L86 pla
    old "Ughhh..."
    new "B:ang: O- o quê?"

    # say L90 ang
    old "Huh, what is this?"
    new "O QUE RAIO!"

    # say L95 ang
    old "WHAT THE FUCK!"
    new "B:ang: Huh, what é isto?"

    # say L96 ang
    old "WHO THE HELL ARE YOU?!!"
    new "B:ang: QUE PORRA É ESTA!"

    # say L113 ang
    old "Uhh... It f- feels nice..."
    new "B:joh: Mais depressa e com um pouco mais de pressão, ela precisa sentir mais prazer, ficar mais excitada."

    # say L118 joh
    old "[pla], I want you to be tough now, press them hardly, feel them, touch them all."
    new "B:joh: Sim, assim mesmo, [pla]."

    # say L119 pla
    old "Ok."
    new "A:joh: Tu gostas disto, Angelina?"

    # say L120 joh
    old "Do you like it Angelina?"
    new "B:pla: Ok."

    # say L121 ang
    old "... Y- yes."
    new "A:joh: Perfeito, agora que nos sentimos um pouco mais confiantes um com o outro, vamos passar para o próximo exercício, neste caso no quarto de prática."

    # say L145 joh
    old "Perfect, now that we feel a bit more confident with each other let's move to the other exercise, in this case in the practice bedroom."
    new "B:ang:... S- sim."

    # say L158 joh
    old "Do you like it?"
    new "B:joh: Perfeito, agora que nos sentimos um pouco mais confiantes um com o outro, vamos passar para o próximo exercício, neste caso no quarto de prática."

    # say L159 ang
    old "Yes, it feels a bit... Nice."
    new "B:joh: Gostas disto?"

    # say L191 ang
    old "Oh God! OH GOD! I feel like I'm going to... EXPLODE!"
    new "B:ang: Ohhh... Não pares, ahh! Nngh!"

    # say L196 joh
    old "Wonderful!"
    new "B:ang: Oh Deus! OH DEUS! Sinto que vou... EXPLODIR!"

    # say L197 ang
    old "Oh God... I had never felt this before..."
    new "A:joh: Então, o que sentes, Angelina?"

    # say L209 joh
    old "So, what do you feel Angelina?"
    new "B:ang: Oh Deus... Nunca tinha sentido isto antes..."

    # say L210 ang
    old "Hmm, It's really hard and tasteful."
    new "B:joh: Então, o que tu sentes, Angelina?"

    # say L221 ang
    old "Mmm, ok."
    new "A:joh: Não pares agora, ele está quase a acabar, vai gozar a qualquer momento, então, continua a mover a cabeça."

    # say L245 joh
    old "Don't stop now, he is almost done, he will cum any time, so, keep moving your head."
    new "B:ang: Mmm, ok."

    # say L246 ang
    old "Slurp, slurp...!"
    new "B:joh: Não pares agora, ele está quase a acabar, vai gozar a qualquer momento, então, continua a mexer a cabeça."

    # say L247 pla
    old "Ahh!"
    new "B:ang: Chup-chup...!"

    # say L253 ang
    old "Wow, that's a lot of cum, I think I did it."
    new "B:pla: Ahh!"

    # say L254 joh
    old "You did amazing!"
    new "B:ang: Uau, isso é muito esperma, acho que consegui."

    # say L266 pla
    old "Sure, I'll try my best."
    new "A:ang: Mmm dói um bocadinho... Mas também é bom..."

    # say L277 ang
    old "Ohhh... Yess..."
    new "B:joh: Estás satisfeita, Angelina?"

    # say L281 ang
    old "HOLLY SHIT! AHHH!"
    new "B:pla: Entendido."

    # say L304 joh
    old "Don't stop, she's about to cum!"
    new "B:ang: CACETE! AHHH!"

    # say L305 ang
    old "NNGH!"
    new "B:joh: Não pares, ela está prestes a gozar!"

    # say L323 pla
    old "(She's getting really good at it.)"
    new "B:pla: Absolutamente!"

    # say L325 joh
    old "I'm glad to see you feel more confident with your partner."
    new "B:pla: (Ela está a ficar mesmo boa nisso.)"

    # say L328 joh
    old "That's great, don't stop, remember is your husband pleasure what we are talking about."
    new "B:joh: Fico contente por veres que te sentes mais confiante com o teu parceiro."

    # say L331 joh
    old "Now suck it faster, show me those blowjob skills."
    new "B:joh: Isso é ótimo, não pares, lembra-te que estamos a falar do prazer do teu marido."

    # say L333 pla
    old "Woow!"
    new "B:joh: Agora chupa mais rápido, mostra-me essas habilidades de sexo oral."

    # say L337 joh
    old "Wow, I can see it's getting closer, do it faster, you want him to cum, don't you?"
    new "B:pla: Uau!"

    # say L338 ang
    old "Yes!"
    new "B:joh: Wow, consigo ver que está a ficar mais perto, faz mais rápido, queres que ele goze, não é?"

    # say L339 joh
    old "So, do it as fast as you can... make him cum in your throat!"
    new "B:ang: Sim!"

    # say L363 pla
    old "Ahh yes! Take it."
    new "B:joh: Então, faz o mais rápido possível... faz ele gozar na tua garganta!"

    # say L370 joh
    old "Wonderful, did you like it Angelina?"
    new "B:pla: Ahh sim! Aceita."

    # say L372 joh
    old "That's my girl."
    new "B:joh: Maravilhoso, gostaste, Angelina?"

    # say L383 joh
    old "Oh yeah, ride him Angelina, jump on him and fuck him."
    new "B:joh: Essa é a minha rapariga."

    # say L384 ang
    old "I didn't know riding was so intense, this is definitely the position I like the most."
    new "B:joh: Oh yeah, monta nele Angelina, salta em cima dele e fode-o."

    # say L385 pla
    old "(Oh wow, she moves really good, I like it.)"
    new "B:ang: Não sabia que andar a cavalo era tão intenso, esta é definitivamente a posição que mais gosto."

    # say L388 ang
    old "Oh God! I don't want to stop, we should do this for a week..."
    new "B:pla: (Oh wow, ela move-se muito bem, gosto disto.)"

    # say L389 pla
    old "I like it too."
    new "B:ang: Oh Deus! Não quero parar, devíamos fazer isto durante uma semana..."

    # say L392 ang
    old "Ahhh..."
    new "A:ang: Ahhh... O teu pénis está tão duro que eu quero bater mais rápido."

    # say L396 ang
    old "Ahhh... Your dick is so hard that I want to hit it faster."
    new "B:ang: Ahhh..."

    # say L397 joh
    old "Fuck him harder, just as you want!"
    new "B:ang: Ahhh... O teu pénis está tão duro que quero bater mais depressa."

    # say L422 ang
    old "Ahh! This is really delicious, I don't want to stop."
    new "B:joh: Foda-o mais forte, exatamente como tu queres!"

    # say L423 ang
    old "I really love this, I want to feel you cuming."
    new "B:ang: Ahh! Isto é mesmo delicioso, não quero parar."

    # say L424 pla
    old "I- I can't hold it anymore."
    new "B:ang: Eu adoro isto, quero sentir-te a gozar."

    # say L430 ang
    old "Mmm, I- I want more... May I have another round?"
    new "B:pla: I- I já não aguento mais."

    # say L432 pla
    old "Uhh... Yes, I guess..."
    new "A:ang: Ok, agora tu fodes-me, quero que me faças gozar de novo."

    # say L433 ang
    old "Ok, now you fuck me, I want you to make me cum again."
    new "T: Ok, agora tu fodes comigo, quero que me faças gozar de novo."

    # say L434 pla
    old "A- Alright..."
    new "B:ang: Ok, agora fodes-me, quero que me faças gozar de novo."

    # say L452 ang
    old "Oh yes, just like that. I have to say my husband is not as big as you."
    new "B:pla: A- Tudo bem..."

    # say L453 ang
    old "Your huge cock makes me feel so much more!"
    new "B:ang: Oh sim, exactamente assim. Tenho que dizer que o meu marido não é tão grande como tu."

    # say L457 ang
    old "Mmmm, it feels really nice, but I want more!"
    new "B:ang: O teu pénis enorme faz-me sentir muito mais!"

    # say L458 ang
    old "Give me more of your cock. I want you to fuck me harder!"
    new "B:ang: Mmmm, sente-se tão bem, mas quero mais!"

    # say L461 ang
    old "Uhhhh... Holly Shit! This is soo good."
    new "B:ang: Dá-me mais do teu pau. Quero que me fodes mais forte!"

    # say L464 ang
    old "Don't stop baby, keep fucking me hard!"
    new "B:ang: Uhhhh... Meu Deus! Isto é tão bom."

    # say L490 pla
    old "(Uhh... Doctor Johnson has been a bit quiet, that's weird)"
    new "B:ang: Ahhh! Ahhh! Oh my God!"

    # say L497 ang
    old "Yes! Yes! I- I cumming again! Ahhh!"
    new "B:pla: (Uhh... O Dr. Johnson tem estado um bocado calado, isso é estranho)"

    # say L501 ang
    old "Mmmm, it was so good."
    new "A:joh: Ótimo trabalho, posso dizer que as sessões têm sido muito eficazes..."

    # say L502 joh
    old "Great job guys, I can tell you that the sessions have been very efficient..."
    new "B:ang: Mmmm, foi tão bom."

    # say L503 joh
    old "Angelina as you can see you will be very happy with your husband!"
    new "B:joh: Ótimo trabalho, pessoal, posso dizer que as sessões têm sido muito eficazes..."

    # say L515 ang
    old "Mmm... Oh God, this feeling..."
    new "B:joh: Angelina, como podes ver, vais ser muito feliz com o teu marido!"

    # say L516 ang
    old "And the size of your cock!"
    new "B:ang: Mmm... Oh Deus, esta sensação..."

    # say L517 ang
    old "It brings so much back!"
    new "B:ang: E o tamanho do teu pénis!"

    # say L521 ang
    old "I haven't felt this way in forever!"
    new "T(ang|tu|say): Não me sentia assim há tanto tempo!"

    # say L522 ang
    old "I've missed feeling this way!"
    new "T(ang|tu|say): Senti tanto a falta desta sensação!"

    # say L523 ang
    old "Slrrp! It's been so long!"
    new "B:ang: Senti tanto a tua falta!"

    # say L527 ang
    old "This is nothing like my husband!"
    new "B:ang: Slrrp! Já estávamos com saudades!"

    # say L528 ang
    old "I love how good it tastes!"
    new "B:ang: Isto não é nada como o meu marido!"

    # say L529 ang
    old "Oh it makes me feel so good!"
    new "B:ang: Adoro como é bom!"

    # say L552 pla
    old "Angelina! I-I can't hold it in anymore!"
    new "B:ang: Oh, isto faz-me sentir tão bem!"

    # say L553 ang
    old "Oh yes! I want you to let it out!"
    new "B:pla: Angelina! N-Não aguento mais!"

    # say L554 ang
    old "Let me taste it!"
    new "B:ang: Oh sim! Quero que tu deixes sair!"

    # say L562 ang
    old "Mmm that felt so good."
    new "B:ang: Deixa-me provar!"

    # say L563 ang
    old "It was amazing."
    new "T(ang|tu|say): Foi incrível."

    # say L564 pla
    old "Uh, yeah, I guess so."
    new "T: Uh, yeah, acho que sim."

    # say L565 pla
    old "But hey, let’s get up and clean this up before Lisa walks in and sees us."
    new "B:pla: Uh, yeah, I guess so."

    # say L566 ang
    old "Sure, sure."
    new "A:pla: Como estás a sentir-te, Angelina?"

    # say L574 pla
    old "How are you feeling Angelina?"
    new "T(pla|tu|say): Como estás a sentir-te, Angelina?"

    # say L575 ang
    old "Great! That was fantastic! I want more!"
    new "B:pla: Como estás a sentir-te, Angelina?"

    # say L576 pla
    old "Hmm, yeah sure."
    new "B:ang: Ótimo! Isso foi fantástico! Quero mais!"

    # say L582 ang
    old "Mmm! Oh yes!"
    new "B:pla: Hmm, yeah sure."

    # say L583 ang
    old "Oh God! this feels amazing!"
    new "B:ang: Mmm! Oh sim!"

    # say L584 ang
    old "Oh [pla], this is just what I wanted!"
    new "T(ang|tu|say): Oh [pla], isto é exactamente o que eu queria!"

    # say L596 ang
    old "Oh God [pla] I love it!"
    new "B:ang: Oh [pla], isto é exactamente o que eu queria!"

    # say L601 ang
    old "My God [pla], I love the way you're doing it!"
    new "T(ang|tu|dizes): Meu Deus [pla], adoro a maneira como tu estás a fazer!"

    # say L602 ang
    old "This is amazing [pla]!"
    new "B:ang: Meu Deus [pla], adoro a forma como tu estás a fazer!"

    # say L639 ang
    old "I feel amazing [pla]!"
    new "T: Sinto-me incrível [pla]!"

    # say L640 ang
    old "That's the best sex I've ever had!"
    new "T: Foi o melhor sexo que já tive!"

    # say L641 pla
    old "Heh, that's good to hear."
    new "A:ang: Ótimo! Isso foi fantástico! Quero mais, por favor!"

    # say L651 ang
    old "Great! That was fantastic! I want more, please!"
    new "T: Ótimo! Isso foi fantástico! Quero mais, por favor!"

    # say L652 pla
    old "Yeah, that’s what I thought..."
    new "B:ang: Ótimo! Foi incrível! Quero mais, por favor!"

    # say L671 ang
    old "Ohhh, yeah... it feels so deep..."
    new "B:pla: Sim, é isso que pensei..."

    # say L672 ang
    old "Mmm, this is the best!"
    new "B:ang: Ohhh, sim... sente-se tão fundo..."

    # say L676 ang
    old "Oh God, oh God! It's amazing."
    new "B:ang: Mmm, isto é o melhor!"

    # say L680 ang
    old "Ohh fuck, yes, yes, faster, faster [pla]..."
    new "T(ang|tu|say): Ohh, sim, sim, mais rápido, mais rápido [pla]..."

    # say L682 ang
    old "Mmm, that's right, don't stop [pla], don't stop!"
    new "B:ang: Ohh, sim, sim, mais rápido, mais rápido [pla]..."

    # say L712 ang
    old "[pla], you really have no idea how wonderful that was."
    new "T(ang|tu|say): [pla], tu realmente não tens ideia de quão maravilhoso isso foi."

    # say L714 ang
    old "Ohh, you have no idea."
    new "B:pla: Estás a sentir-te melhor agora, certo?"

    # say L715 pla
    old "I'm glad, but, let’s get up and clean this up before Lisa walks in and sees us."
    new "T(pla|tu|say): Fico contente, mas, vamos levantar e arrumar isto antes que a Lisa entre e nos veja."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Church.rpy
translate portuguese strings:

    # say L44 pla
    old "She is praying, I shouldn't bother her."
    new "Oh, olá rapaz, foste tu quem acompanhou a Lydia há uns dias?"

    # say L58 jon
    old "Oh, hi young man, are you the one who accompanied Lydia a few days ago?"
    new "B:pla: Ela está a rezar, não devo incomodá-la."

    # say L62 jon
    old "Excellent [pla], I think it's very good that you visit the church."
    new "B:pla: Sim, Sra. Jones, o meu nome é [pla], prazer em conhecê-la."

    # say L66 pla
    old "Oh no, I just-"
    new "B:jon: Muitos jovens deviam ser como tu."

    # say L68 jon
    old "Today all young people think about is sex, parties and devil things."
    new "B:pla: Oh não, eu acabei de-"

    # say L70 jon
    old "Did you know that sister Grace is organizing the church choir?"
    new "B:jon: Hoje, tudo o que os jovens pensam é em sexo, festas e coisas do diabo."

    # say L72 jon
    old "If you want I could introduce you, so you could continue on your way to the Lord."
    new "B:jon: Sabias que a irmã Grace está a organizar o coro da igreja?"

    # say L74 pla
    old "Well, actually-"
    new "B:jon: Se quiseres posso apresentar-te, para que possas continuar o teu caminho até ao Senhor."

    # say L76 jon
    old "Perfect! I'll talk to sister Grace, she'll be very happy."
    new "B:pla: Bem, na verdade-"

    # say L92 jon
    old "I'm fine, waiting for the next mass."
    new "B:pla: Olá, Sra. Jones, estou ótimo, obrigado, e tu?"

    # say L93 jon
    old "Do you need something hun?"
    new "B:jon: Estou bem, à espera da próxima missa."

    # say L117 jon
    old "Honey?"
    new "Não agora."

    # menu L119 
    old "Not now."
    new "B:jon: Meu amor? T(n|tu|menu): Agora não. A:pla: Oh, não te preocupes, só queria dizer olá."

    # say L122 pla
    old "Oh no, don't worry, I just wanted to say hi."
    new "B:n: Agora não."

    # say L123 jon
    old "Alright, thank you hun, see you later."
    new "B:pla: Oh não, não te preocupes, só queria dizer olá."

    # say L124 pla
    old "Bye, Mrs. Jones."
    new "Adeus, Sra. Jones. (Uau!)"

    # say L181 pla
    old "(Wow!)"
    new "B:pla: Adeus, Sra. Jones."

    # say L182 pla
    old "(Sister Grace is really attractive...)"
    new "B:pla: (Uau!)"

    # say L183 pla
    old "(Should I use the Agamoto eye?)"
    new "B:pla: (A irmã Grace é mesmo atraente...)"

    # menu L185 
    old "Yes"
    new "Sim"

    # menu L190 
    old "No"
    new "Não"

    # say L193 pla
    old "(I better get back to work.)"
    new "T: (Melhor voltar ao trabalho.)"

    # say L203 pla
    old "(Mrs. Jones's skirt went up quite a bit...)"
    new "B:pla: (Melhor voltar ao trabalho.)"

    # say L221 gra
    old "Wow! I knew you would have been fast but I didn't expect that much."
    new "B:pla: (O saia da Sra. Jones subiu bastante...)"

    # say L222 pla
    old "Haha, thanks Sister Grace... I like to do things as fast as possible."
    new "B:gra: Uau! Sabia que fosses rápido, mas não esperava tanto."

    # say L223 jon
    old "I wonder if you're that good at everything... Great job!"
    new "B:pla: Haha, obrigado Irmã Grace... Gosto de fazer as coisas o mais rápido possível."

    # say L224 jon
    old "Anyway, it's already very late, and I think we should all rest now, see you again tomorrow."
    new "B:jon: Não sei se és assim tão bom em tudo... Mas grande trabalho!"

    # say L240 gra
    old "Oh, it's too late and we can't finish cleaning."
    new "B:pla: Até amanhã, então."

    # say L241 jon
    old "Well, today was a bit harder than usual..."
    new "B:gra: Oh, já é demasiado tarde e não conseguimos acabar de limpar."

    # say L242 pla
    old "Don't worry, I can stay and finish the cleaning."
    new "B:jon: Bem, hoje foi um pouco mais difícil do que o habitual..."

    # say L243 jon
    old "Oh no! It's fine, we'll finish tomorrow..."
    new "B:pla: Não te preocupes, posso ficar e terminar a limpeza."

    # say L244 gra
    old "It's fine, just hurry a little more next time and we will make it."
    new "B:jon: Oh não! Tudo bem, acabamos amanhã..."

    # say L245 pla
    old "I guess the next time will be better."
    new "B:gra: Tudo bem, só tenta ser um pouco mais rápido da próxima vez e conseguiremos."

    # say L246 jon
    old "Sure, it will!, anyway see you again tomorrow."
    new "B:pla: Acho que da próxima vez será melhor."


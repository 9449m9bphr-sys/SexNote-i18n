# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/OliHome.rpy
translate portuguese strings:

    # menu L12 
    old "Talk to her."
    new "Hmm, vamos começar ou o quê?"

    # say L89 oli
    old "Hmm, are we starting or what?"
    new "T(oli|tu|say): Hmm, estamos a começar ou quê?"

    # say L90 pla
    old "Uhh... E- excuse me?"
    new "T(pla|tu|say): Uhh... E- desculpa?"

    # say L92 oli
    old "I'm asking you if we're going to study or something."
    new "B:pla: Uhh... E- desculpa?"

    # say L94 oli
    old "Because you just stayed there staring at me like a creep."
    new "B:oli: Estás a perguntar se vamos estudar ou algo assim."

    # say L96 pla
    old "S- sorry, I- I didn't notice I was doing it."
    new "T(pla|tu|say): S- sorry, I- I didn't realize I was doing it."

    # say L97 pla
    old "I was just passing by and wanted to say hello."
    new "B: pla: S- sorry, I- I didn't notice I was doing it."

    # say L99 oli
    old "That's it? Alright."
    new "B:pla: Estava só a passar e quis dizer olá."

    # say L101 oli
    old "But make sure to come back soon. We’ve got a lot to study."
    new "B:oli: É isso? Tudo bem."

    # say L102 pla
    old "Sure, don't worry about it. I'll see you soon."
    new "T(pla|tu|say): Claro, não te preocupes. Vemo-nos em breve."

    # say L112 oli
    old "Hey, what's up? Did you come to study with me?"
    new "B:pla: Claro, não te preocupes com isso. Vemo-nos em breve."

    # say L114 pla
    old "Hey, oh no, I can't right now, I just wanted to say hi."
    new "B:oli: E aí, o que foi? Vim estudar comigo?"

    # say L116 oli
    old "Hmm, alright, but make sure you come back soon."
    new "B:pla: Hey, oh não, não posso agora, só queria dizer olá."

    # say L117 oli
    old "So we can hit the books together."
    new "B:oli: Hmm, bem, mas certifica-te de que voltas depressa."

    # say L165 vee
    old "Excuse me [pla], do you need anything?"
    new "T(vee|tu|diz): Desculpe [pla], precisas de algo?"

    # say L169 vee
    old "I see... Well, I guess I'll see you around then."
    new "B:pla: Hmm, não, desculpe senhora, eu... eu estava só a passar."

    # say L180 vee
    old "Hello [pla], how are you today?"
    new "T(vee|tu|dizer): Olá [pla], como estás hoje?"

    # say L184 vee
    old "I'm doing alright."
    new "B:pla: Olá Sra. Priya, estou bem, e tu?"

    # say L185 vee
    old "Tell me, do you need anything?"
    new "B:vee: Estou bem."

    # say L186 pla
    old "Oh, not really. I just wanted to say hello."
    new "B:vee: Diz-me, precisas de algo?"

    # say L188 vee
    old "I see, well, I guess I'll see you around then."
    new "B:pla: Oh, não realmente. Apenas queria dizer olá."

    # say L189 pla
    old "Sure thing ma'am, see you."
    new "Claro, senhora, até logo."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Animations/whiAnimations.rpy
translate portuguese strings:

    # say L6 whi
    old "Give me that big cock..."
    new "Oh meu, tu certamente cresceste muito!"

    # say L8 whi
    old "Oh my, you've definitely grown a lot! "
    new "B:whi: Dá-me esse pau grande..."

    # say L12 whi
    old "Uhh, it feels so warm and hard."
    new "B:whi: Oh meu, tu certamente cresceste muito!"

    # say L14 pla
    old "Y- yes it feels nice too."
    new "B:whi: Uhh, está tão quente e duro."

    # say L18 whi
    old "What about if you cum for mommy?"
    new "B:pla: S- sim, também é bom."

    # say L43 whi
    old "Mrs. W- white I- I-"
    new "B:whi: E se tu gozares para a mamã?"

    # say L44 whi
    old "Ohh, yeah baby..."
    new "B:whi: Sra. W- branca I- I-"

    # say L45 whi
    old "Give it to mommy!"
    new "B:whi: Ohh, sim, bebé..."

    # say L64 pla
    old "Wow! Mrs. White, w- what are you doing?"
    new "B:pla: Uhh... O-obrigado..."

    # say L65 whi
    old "Just enjoy it baby... Mommy is gonna blow your mind..."
    new "B:pla: Uau! Sra. White, o- o que está a fazer?"

    # say L66 pla
    old "(Holly shit!)"
    new "B:whi: Aproveita, querido... A mamã vai-te deixar de queixo caído..."

    # say L70 whi
    old "Oh God, you got a huge cock..."
    new "B:pla: (Puta merda!)"

    # say L71 whi
    old "It hardly fits in my mouth."
    new "B:whi: Oh Deus, tu tens um pénis enorme..."

    # say L76 whi
    old "Do you want to cum in my mouth?"
    new "B:whi: Mal cabe na minha boca."

    # say L78 whi
    old "I wanna taste it!"
    new "B:whi: Queres gozar na minha boca?"

    # say L101 whi
    old "Oh yeah, cum for mommy!"
    new "B:whi: Quero provar!"

    # say L102 whi
    old "Give me all that cum baby."
    new "B:whi: Oh yeah, goza para a mamã!"

    # say L121 whi
    old "By the way, you haven't said anything about the food. Are you liking it?"
    new "B:whi: Dá-me todo esse esperma, bebé."

    # say L122 pla
    old "Oh... yes ma'am, I- I like it... a lot."
    new "B:whi: Por acaso, ainda não disseste nada sobre a comida. Estás a gostar?"

    # say L123 whi
    old "It makes me so happy to hear you say that."
    new "B:pla: Oh... sim, senhora, eu- eu gosto... muito."

    # say L124 whi
    old "I made everything with my... hands, after all."
    new "B:whi: Fico tão feliz ao ouvir-te dizer isso."

    # say L125 mik
    old "Yes, It's really good mom, thank you."
    new "B:whi: Fiz tudo com as... minhas mãos, afinal."

    # say L132 whi
    old "Well, have as much as you like."
    new "B:pla: Mmm... S- sim senhora, g- gosto muito!"

    # say L133 whi
    old "You can ask me for more whenever you want to."
    new "B:whi: Bem, toma o que quiseres."

    # say L134 mik
    old "Yeah, I think I would like to repeat."
    new "B:whi: Podes pedir-me mais sempre que quiseres."

    # say L157 pla
    old "Mmm... Yes Mrs. White..."
    new "B:whi: Tu terminas por mim?"

    # say L166 mik
    old "What? But he hasn't finished his food... Why do you say he is done?"
    new "B:pla: Y- sim, Sra. White, foi muito agradável."

    # say L169 mik
    old "Hmm, sure."
    new "B:whi: De qualquer forma, Mike, por favor, leva os pratos para a cozinha."

    # say L182 whi
    old "Mmm, yes, this big dick."
    new "A:whi: Sabe tão bem na minha boca."

    # say L183 whi
    old "It tastes so good in my mouth."
    new "B:whi: Mmm, sim, este pénis grande."

    # say L185 whi
    old "Just relax and enjoy it, like I'm enjoying it."
    new "B:whi: Sabe tão bem na minha boca."

    # say L189 whi
    old "God! I swear it's getting even bigger!"
    new "B:whi: Só te relaxes e aproveita, como eu estou a aproveitar."

    # say L190 whi
    old "This is just what I wanted!"
    new "B:whi: Meu Deus! Juro que está a ficar ainda maior!"

    # say L196 whi
    old "Yes! Shove that dick down my throat!!"
    new "B:pla: S-Sim, senhora!"

    # say L197 whi
    old "Push it!"
    new "B:whi: Sim! Enfia esse pau na minha garganta!!"

    # say L198 whi
    old "Yes, fuck my mouth like that..."
    new "B:whi: Empurra!"

    # say L199 whi
    old "Don't come yet! I want it a little longer!"
    new "B:whi: Sim, foda a minha boca assim..."

    # say L222 pla
    old "M- Mrs. White! I can't hold it anymore!"
    new "B:whi: Ainda não! Quero que dure mais um pouco!"

    # say L223 whi
    old "Mmmm! It's ok, you can cum!"
    new "B:pla: M- Mrs. White! Não aguento mais!"

    # say L224 whi
    old "Cum for mommy!"
    new "B:whi: Mmmm! Tudo bem, podes gozar!"

    # say L225 whi
    old "Give me all your load!"
    new "B:whi: Goza para a mamã!"

    # say L230 whi
    old "Mmm, I love your cum."
    new "B:whi: Dá-me toda a tua carga!"

    # say L231 whi
    old "It's like a very nice, hot, sweet treat!"
    new "B:whi: Mmm, adoro o teu leite."

    # say L232 pla
    old "Mrs. White, I- I think we should get dressed."
    new "B:whi: É como um doce quente e delicioso!"

    # say L233 whi
    old "Oh no, what are you talking about?"
    new "B: pla: Sra. White, eu... eu acho que devemos nos vestir."

    # say L234 whi
    old "We're only getting started, that was just the beginning."
    new "B:whi: Oh não, do que estás a falar?"

    # say L235 whi
    old "Now it's time for the main course."
    new "B:whi: Estamos apenas a começar, isso foi apenas o início."

    # say L239 whi
    old "Oh fuck! He arrived already!"
    new "B:whi: Agora é a hora do prato principal."

    # say L240 pla
    old "Shit! He's gonna catch us! We better get dressed quickly."
    new "Estou aqui querida!"

    # say L242 whi
    old "I'm in here honey!"
    new "B:pla: Merda! Ele vai apanhar-nos! Melhor vestirmo-nos depressa."

    # say L243 whi
    old "Just give me a second!"
    new "A:whi: Hmm, isto é chato, ele tem de voltar justo quando as coisas estão a ficar boas!"

    # say L244 whi
    old "Hmm, this is annoying, he has to come back just when things are getting good!"
    new "B:whi: Dá-me só um segundo!"

    # say L245 pla
    old "We should just hurry up."
    new "B:whi: Hmm, isto é chato, ele tem de voltar justo quando as coisas estão a ficar boas!"

    # say L257 whi
    old "Mmm, look how hard it is."
    new "B:pla: Devíamos apressar-nos."

    # say L258 whi
    old "And you were pretending to be nervous."
    new "B:whi: Mmm, olha como está duro."

    # say L260 whi
    old "Just relax, I'll make you cum before you know it."
    new "B:whi: E tu estavas a fingir estar nervosa."

    # say L264 pla
    old "M- Mrs. White... Mmm, Mike could come back a- any minute."
    new "B:whi: Relaxa, vou fazer-te gozar antes que te apercebas."

    # say L265 whi
    old "You're right, this is so naugthy!"
    new "B:pla: M- Mrs. White... Mmm, Mike pode voltar a- a qualquer momento."

    # say L266 whi
    old "I love this adrenaline rush."
    new "B:whi: Tens razão, isto é tão malandro!"

    # say L270 whi
    old "Mmm, yes, like that."
    new "B:whi: Adoro esta adrenalina."

    # say L271 whi
    old "Just enjoy it, I'll keep going."
    new "A:whi: Adoro como o teu pénis treme na minha boca."

    # say L272 whi
    old "I love how your cock twitches in my mouth."
    new "B:whi: Aproveita, vou continuar."

    # say L295 whi
    old "I can feel you getting close!"
    new "A:whi: Faz isso, goza na minha boca!"

    # say L296 whi
    old "Do it, cum in my mouth!"
    new "B:whi: Sinto-te a aproximar-te!"

    # say L297 whi
    old "I'll swallow it all!"
    new "B:whi: Faz isso, goza na minha boca!"

    # say L298 pla
    old "Ahhhh...."
    new "B:whi: Vou engolir tudo!"

    # say L304 whi
    old "Oh, I loved that!"
    new "B:pla: Ahhhh...."

    # say L305 whi
    old "You were so excited, and you got soo hard!"
    new "B:whi: Oh, adorei isso!"

    # say L306 whi
    old "I think I'll do this again... "
    new "B:whi: Estavas tão excitado, e ficaste tão duro!"

    # say L307 pla
    old "M- mrs. White, I think you should clean up before Mike comes back."
    new "B:whi: Acho que vou fazer de novo..."

    # say L308 whi
    old "Sure, sure, it will be just a second."
    new "B:pla: M- Sra. White, acho que deves arrumar-te antes de o Mike voltar."

    # say L317 whi
    old "Ah Yes! This big dick is just what I needed today."
    new "B:whi: Claro, claro, será só um momento."

    # say L318 whi
    old "I'll never get tired of the smell of your cock."
    new "B:whi: Ah Sim! Este pénis grande é exactamente o que eu precisava hoje."

    # say L319 whi
    old "It's making me so wet!"
    new "B:whi: Nunca me cansarei do cheiro do teu pénis."

    # say L323 whi
    old "Mmm, yes, like that, enjoy it!"
    new "B:whi: Isso está a deixar-me tão molhada!"

    # say L324 whi
    old "Are you liking it you sweet boy?"
    new "B:whi: Mmm, sim, assim, desfruta!"

    # say L326 pla
    old "I-I am!."
    new "B:whi: Estás a gostar, meu querido?"

    # say L330 whi
    old "Mmmm! Slrrp! This taste is the best!"
    new "A:whi: O teu pénis está tão quente dentro da minha boca!"

    # say L331 whi
    old "Your dick feels so hot inside my mouth!"
    new "B:whi: Mmmm! Slrrp! Este sabor é o melhor!"

    # say L356 whi
    old "Your dick! Is twitching!"
    new "B:pla: Sim, senhora! Eu faço!"

    # say L357 whi
    old "I want you to cum! Do it!"
    new "B:whi: O teu pénis! Está a tremer!"

    # say L358 pla
    old "I- I'm about to...!"
    new "B:whi: Quero que gozes! Faz isso!"

    # say L359 whi
    old "Yes! Give me your cum!"
    new "B:pla: I- I'm about to...!"

    # say L364 whi
    old "Oh yes! It's always so good to have your dick in my mouth."
    new "B:whi: Sim! Dá-me o teu esperma!"

    # say L365 whi
    old "I'll never get tired of it."
    new "B:whi: Oh sim! É sempre tão bom ter o teu pénis na minha boca."

    # say L366 pla
    old "Listen, Mrs. White, I think I just heard someone move outside."
    new "T(pla|tu|say): Ouve, Sra. White, acho que acabei de ouvir alguém se mexer lá fora."

    # say L367 pla
    old "We should hurry up and..."
    new "B:pla: Ouve, Sra. White, acho que acabei de ouvir alguém se mover lá fora."

    # say L368 whi
    old "What are you talking about?"
    new "B:pla: Devíamos apressar-nos e..."

    # say L369 whi
    old "We're not done yet."
    new "B:whi: Do que estás a falar?"

    # say L370 whi
    old "And last time we were interrupted when Mike got home."
    new "B:whi: Ainda não acabámos."

    # say L371 whi
    old "So, you're not going anywhere. There's something else that I want right now!"
    new "B:whi: E da última vez fomos interrompidos quando o Mike chegou a casa."

    # say L387 whi
    old "Oh! Yes! That's it!"
    new "B:whi: Então, tu não vais a lado nenhum. Há algo mais que eu quero agora!"

    # say L388 whi
    old "I've been wanting for you to be inside me for a while!"
    new "B:whi: Oh! Sim! É isso!"

    # say L389 whi
    old "Yes! Like that, move a little faster."
    new "B:whi: Tenho desejado que tu entrasses em mim há algum tempo!"

    # say L393 whi
    old "Oh boy, oh my sweet boy, yes, keep fucking me."
    new "B:whi: Sim! Assim, move-te um pouco mais rápido."

    # say L394 whi
    old "Oh yeah! Oh do you like how my pussy feels?"
    new "B:whi: Oh rapaz, oh meu doce rapaz, sim, continua a foder-me."

    # say L395 pla
    old "Uhh yes, it feels amazing!"
    new "B:whi: Oh sim! Oh, tu gostas de como a minha xoxota se sente?"

    # say L399 whi
    old "Ah! I love your dick!"
    new "A:whi: Gostas disto, bebé? Gostas de como te fodo?"

    # say L400 whi
    old "Do you like that baby? Do you like how I fuck you?"
    new "B:whi: Ah! Adoro o teu pénis!"

    # say L401 pla
    old "I- I think I'm about to finish!"
    new "B:whi: Gostas disso, bebé? Gostas de como te fodo?"

    # say L402 whi
    old "Not yet, keep going baby boy!"
    new "B:pla: I- Acho que vou acabar!"

    # say L425 pla
    old "M- Mrs. White, I can't hold it anymore!"
    new "B:whi: Ainda não, continua baby boy!"

    # say L426 whi
    old "It's ok, cum inside."
    new "B:pla: M- Mrs. White, não aguento mais!"

    # say L427 whi
    old "Fill me up sweety!"
    new "B:whi: Tudo bem, goza dentro."

    # say L433 whi
    old "Wow, that was great!"
    new "B:whi: Enche-me, querida!"

    # say L434 whi
    old "I'd been wanting to fuck you so bad."
    new "B:whi: Uau, isso foi incrível!"

    # say L435 whi
    old "And you were even better than I imagined you would be."
    new "B:whi: Eu andava a querer foder-te tanto."

    # say L436 whi
    old "Did you like it too baby boy?"
    new "B:whi: E foste ainda melhor do que eu imaginava."

    # say L437 pla
    old "Uh, yes, I really did."
    new "B:whi: Gostaste também, meu querido?"

    # say L438 pla
    old "Listen Mrs. White I think it's better if I get dressed and leave."
    new "Ouça, Sra. White, acho melhor eu me vestir e ir embora. Já estou aqui há algum tempo e não quero que o Mike nos encontre."

    # say L439 pla
    old "I've been here for a while and I don't want Mike to catch us."
    new "B:pla: Ouve, Sra. White, acho melhor eu me vestir e ir embora."

    # say L440 whi
    old "Yeah, I think so too. It would be better."
    new "A:whi: Vejo-te e esse pénis grande mais tarde."

    # say L441 whi
    old "I'll see you and that big cock later."
    new "B:whi: Sim, acho que sim. Seria melhor."

    # say L454 mik
    old "By the way, let me get back to what I was telling you before."
    new "T(mik|tu|say): Por acaso, deixa-me voltar ao que estava a dizer-te antes. Era sobre a Belle."

    # say L455 mik
    old "It was about Belle."
    new "B:mik: Por acaso, vou voltar ao que te estava a dizer antes."

    # say L456 mik
    old "She wanted me to ask you if you could let us see the project you did with Hinn."
    new "B:mik: Era sobre a Belle."

    # say L457 mik
    old "It's for reference, we're very late with it, and she says that since it is my fault that we're late, I should ask you."
    new "T(mik|tu|dizer): É para referência, estamos muito atrasados, e ela diz que como é minha culpa estarmos atrasados, devo pedir-te."

    # say L459 mik
    old "Woah, are you ok dude? You look kinda tense."
    new "B:mik: É para referência, estamos muito atrasados com isso, e ela diz que como é minha culpa estarmos atrasados, devo pedir-te desculpa."

    # say L460 pla
    old "Yeah... it's just... the sauce. I think it had something spicy in it."
    new "B:mik: Woah, estás bem, cara? Pareces um bocado tenso."

    # say L461 mik
    old "Yeah, I think my mom put some chili in it, but it's very good anyway."
    new "B:pla: Sim... é só... o molho. Acho que tinha algo picante."

    # say L462 pla
    old "I- it is. Yeah she is really good..."
    new "B:mik: Sim, acho que a minha mãe pôs um pouco de piri-piri, mas está mesmo bom de qualquer maneira."

    # say L463 pla
    old "Uhhh... You need the project? Sure."
    new "B: É... É verdade. Ela é mesmo boa..."

    # say L464 pla
    old "I- I have it on my... Mmmm... computer, I'll email it to you."
    new "B:pla: Uhhh... Precisas do projeto? Claro."

    # say L465 mik
    old "Really? Thanks man you are the best."
    new "B:pla: I- I tenho isso no meu... Mmmm... computador, vou enviar-te por email."

    # say L484 mik
    old "Oh, I forgot, Olivia told me she saw you the other day when she was leaving."
    new "B:mik: Mesmo? Obrigado, és o melhor."

    # say L485 pla
    old "Uh?..."
    new "B:mik: Oh, esqueci-me, a Olivia disse-me que te viu na outra dia quando ela estava a sair."

    # say L486 pla
    old "Oh yeah, I- I think we... crossed over... Ahh... on the way out."
    new "B:pla: Uh?..."

    # say L487 mik
    old "Hmm... Yeah, that's what she told me. But dude, she was super angry about running into you."
    new "B:pla: Oh yeah, eu... acho que... cruzámos... Ahh... a caminho de sair."

    # say L488 mik
    old "Please, don't tell anyone dude, or she won't talk to me anymore. Please?"
    new "B:mik: Hmm... Sim, foi o que ela me disse. Mas cara, ela ficou super zangada por ter-te encontrado."

    # say L489 pla
    old "S- Sure... no problem!"
    new "T: C-Claro... sem problemas!"

    # say L491 mik
    old "Thank you, you are a really good friend."
    new "B:pla: Claro... sem problemas!"

    # say L510 mik
    old "Dude, you sure you are ok?"
    new "B:mik: Obrigado, és um amigo realmente bom."

    # say L511 pla
    old "Mmm... Y- yeah... Ugh, sure... N- no problem."
    new "B:mik: Cara, tens a certeza de que estás bem?"

    # say L512 mik
    old "You should drink some water."
    new "B:pla: Mmm... Y- yeah... Ugh, sure... N- no problem."

    # say L514 pla
    old "Hmm, I'm definitely not the only one who will drink something."
    new "B:mik: Deves beber água."

    # say L516 pla
    old "Oh... Never mind, it's just the spice talking here."
    new "B:pla: Hmm, eu definitivamente não sou o único que vai beber algo."

    # say L554 mik
    old "Dude, I'm starting to get worried. You look like you're about to burts. Here, let me hand you..."
    new "B:pla: Oh... Não importa, é só o tempero a falar aqui."

    # say L555 pla
    old "N- no... i- it's ok, I'm just feeling a little bad."
    new "B:mik: Cara, estou a ficar preocupado. Pareces prestes a rebentar. Aqui, deixa-me dar-te..."

    # say L556 pla
    old "Just give me a minute."
    new "B: N-não... i- isso está bem, eu só estou me sentindo um pouco mal."

    # say L557 mik
    old "Are you sure? I think you should relax and release everything."
    new "T(mik|tu|say): Tens a certeza? Acho que deves relaxar e libertar tudo."

    # say L558 pla
    old "Ughh... That's exactly what I'm going to do..."
    new "B:mik: Tens a certeza? Acho que deves relaxar e libertar tudo."

    # say L578 whi
    old "Mmmm! It's so big, so thick and long!"
    new "B:pla: Ughh... É exactamente isso que vou fazer..."

    # say L579 whi
    old "I was waiting for this, baby boy!"
    new "B:whi: Mmmm! É tão grande, tão grosso e longo!"

    # say L580 whi
    old "That's it, fill me up!"
    new "B:whi: Estava à espera disto, menino!"

    # say L584 whi
    old "Ahhh! Mmmm!!"
    new "B:whi: É isso, enche-me!"

    # say L585 whi
    old "I love how hot your cock is in my pussy!"
    new "B:whi: Ahhh! Mmmm!!"

    # say L586 whi
    old "I can feel it filling me up!"
    new "Adoro como o teu pénis está quente dentro de mim! Consigo sentir-te a encher-me! É tão grande e quente!"

    # say L587 whi
    old "It's so big and hot!"
    new "B:whi: Sinto-o a encher-me!"

    # say L591 whi
    old "Oh god! This dick! I love it!"
    new "B:whi: É tão grande e quente!"

    # say L592 whi
    old "MMMM! AAAAH! Yes! Yes!"
    new "B:whi: Oh deus! Este pénis! Adoro!"

    # say L593 whi
    old "I love your cock sweetie!"
    new "B:whi: MMMM! AAAAH! Sim! Sim!"

    # say L594 whi
    old "I love to feel your cock inside me my baby boy!"
    new "B:whi: Adoro o teu pénis, querida!"

    # say L617 pla
    old "I-I'm about to finish Mrs. White!"
    new "B:whi: Adoro sentir o teu pénis dentro de mim, meu bebé!"

    # say L618 whi
    old "YES! YES! ME TOO!"
    new "B:pla: V-Vou acabar, Sra. White!"

    # say L619 whi
    old "Do it! Cum in my pussy!"
    new "B:whi: SIM! SIM! EU TAMBÉM!"

    # say L620 whi
    old "Do it my sweet baby!"
    new "B:whi: Faz isso! Ejacula dentro de mim!"

    # say L624 whi
    old "Phew, that was amazing!"
    new "B:whi: Faz isso, meu doce bebe!"

    # say L625 pla
    old "Ohh yeah."
    new "B:whi: Ufa, isso foi incrível!"

    # say L640 whi
    old "H- Hi son, I- I'm ok."
    new "B:pla:!!!!!!"

    # say L641 whi
    old "I wasn't expecting you to come home so quickly."
    new "B:whi: H- Olá filho, eu- eu estou bem."

    # say L643 mik
    old "Yeah, me either. But Olivia said she had to take care of some personal things."
    new "B:whi: Não estava à espera que fosses a casa tão cedo."

    # say L644 mik
    old "So, I had to come early."
    new "B:mik: Pois, eu também. Mas a Olivia disse que tinha de tratar de algumas coisas pessoais."

    # say L645 whi
    old "Oh, I see, well..."
    new "B:mik: Então, tive de vir mais cedo."

    # say L646 whi
    old "Since you have some free time, why don't you go up to your room and play some video games?"
    new "B:whi: Ah, percebo, bem..."

    # say L647 whi
    old "Or just relax, you've been studying a lot these days, you deserve a break."
    new "B:whi: Como tens algum tempo livre, por que não vais ao teu quarto jogar alguns videojogos?"

    # say L648 mik
    old "Sure, but first I'm going to grab a snack from the kitchen."
    new "B:whi: Ou só relaxa, tu tens estudado muito nestes dias, mereces um descanso."

    # say L654 whi
    old "Wait!"
    new "B:mik: Claro, mas primeiro vou buscar um lanche à cozinha."

    # say L655 mik
    old "What? What happens?"
    new "B:whi: Espera!"

    # say L656 whi
    old "Ehhh... Just, I know you're tired."
    new "B:mik: O quê? O que acontece?"

    # say L657 whi
    old "So, why don't you just go up and I'll prepare and bring you some snacks?"
    new "B:whi: Ehhh... Apenas, sei que estás cansado."

    # say L658 mik
    old "Wow, really?"
    new "B:whi: Então, porque não vais lá para cima e eu preparo e levo-te uns petiscos?"

    # say L659 whi
    old "Yeah sure, just go up and I'll be there in a bit."
    new "B:mik: Wow, realmente?"

    # say L660 mik
    old "Ok, thanks mom!"
    new "A:whi: Ufa, isso foi bem perto."

    # say L666 whi
    old "Phew, that was really close"
    new "B:mik: Ok, obrigado mãe!"

    # say L667 pla
    old "I knew he was going to catch us!"
    new "T: Sabia que ele ia apanhar-nos!"

    # say L668 pla
    old "We should have gone to your room!"
    new "B:pla: Eu sabia que ele ia apanhar-nos!"

    # say L669 whi
    old "Calm down, he didn't see anything."
    new "B:pla: Devíamos ter ido para o teu quarto!"

    # say L670 whi
    old "But we don't have time to talk about that."
    new "B:whi: Calma, ele não viu nada."

    # say L675 mik
    old "Mom! Do you think you could bring me a soda with the snacks?"
    new "B:whi: Mas não temos tempo para falar sobre isso."

    # say L677 whi
    old "Now, quickly, leave!"
    new "B:mik: Mãe! Tu achas que podes trazer-me um refrigerante com as petiscos?"

    # say L678 pla
    old "Ok, ok, I'm going!"
    new "B:whi: Agora, depressa, vai-te embora!"

    # say L692 whi
    old "Ah! Ah! Ah! That's it sweety, fuck me just like that."
    new "B:pla: Ok, ok, vou já!"

    # say L693 whi
    old "I- I can feel your entire dick! It's so long and thick!"
    new "B:whi: Ah! Ah! Ah! É isso, querida, fode-me assim."

    # say L694 whi
    old "Yes! This is just what I wanted!"
    new "B:whi: I- Eu sinto o teu pénis inteiro! É tão grande e grosso!"

    # say L698 whi
    old "Ah! It's so good!"
    new "A:whi: Mmm, adoro o teu pénis grande!"

    # say L699 whi
    old "Mmm I love your big cock!"
    new "B:whi: Ah! É tão bom!"

    # say L700 whi
    old "Ohh yeah, just like that baby!"
    new "B:whi: Mmm, adoro o teu pénis grande!"

    # say L704 whi
    old "Fuck! YES! YES! FUCK ME MORE!"
    new "B:whi: Ahh sim, assim mesmo, querida!"

    # say L705 whi
    old "Fuck me, fuck your mommy!"
    new "B:whi: Merda! SIM! SIM! FODA-SE MAIS!"

    # say L706 whi
    old "Keep pounding me!"
    new "B:whi: Foda-me, foda a tua mãe!"

    # say L729 whi
    old "I- I can feel you tensing up!"
    new "B:whi: Continua a entrar em mim!"

    # say L730 whi
    old "Do it! CUM! CUM INSIDE ME!"
    new "B:whi: I- I sinto-te a tensar!"

    # say L731 pla
    old "Y-yes!"
    new "B:whi: Faz isso! EJacula! EJacula dentro de mim!"

    # say L732 whi
    old "Ahhh! This is the best cock I've ever had!"
    new "B:pla: S-Sim!"

    # say L738 whi
    old "That was very good sweety!"
    new "B:whi: Ahhh! Este é o melhor pénis que já tive!"

    # say L739 whi
    old "You keep doing it better and better. You just keep making me want that cock even more every time..."
    new "B:whi: Isso foi muito bom, querida!"

    # say L740 pla
    old "I'm glad you liked it Mrs. White."
    new "B:whi: Tu continuas a fazer melhor e melhor. Tu só me fazes querer aquele pénis ainda mais cada vez..."

    # say L741 whi
    old "I didn't just like it, I loved it!"
    new "B:pla: Fico contente que tenhas gostado, Sra. White."

    # say L742 whi
    old "And I hope you know we'll be doing it again very soon."
    new "E espero que saibas que vamos fazer de novo muito em breve."


# SexNote portuguese PT — Qwen72 SPEED
# translate portuguese strings: only

# Source: code/Mall.rpy
translate portuguese strings:

    # say L30 roo
    old "Hey buddy, how are you doing?"
    new "Ei, meu amigo, como estás?"

    # say L31 pla
    old "Wow!!!"
    new "B:roo: Ei, meu amigo, como estás?"

    # say L32 roo
    old "Oh! No worries at all, she is harmless, actually the only way to be attacked by them is that they feel threatened, it's ok, touch her."
    new "B:pla: Uau!!!"

    # say L33 pla
    old "No, no...  It's fine thank you."
    new "B:roo: Oh! Não te preocupes, ela é inofensiva, na verdade a única forma de ser atacado por elas é se sentirem ameaçadas, está tudo bem, podes tocar nela."

    # say L35 roo
    old "Hehehe! It's ok, the first time is kind of impressive... Her name is Gorgo, I really love her, it's my pet."
    new "B:pla: Não, não... Está tudo bem, obrigado."

    # say L36 pla
    old "I can see it..."
    new "B:roo: Hehehe! Não há problema, a primeira vez é meio impressionante... O nome dela é Gorgo, eu adoro, é o meu bichinho de estimação."

    # say L37 roo
    old "Do you like snakes? Would you like to adopt one?"
    new "B:pla: Eu consigo ver..."

    # say L38 pla
    old "Oh no, no thank you... Hmm I'm more a cat person... You know..."
    new "B:roo: Gostas de serpentes? Querias adotar uma?"

    # say L39 roo
    old "Oh, they are beautiful too, here you can find anything you need related with any pet... You know their food, cat litter or any toy you want for them to play with."
    new "B:pla: Oh não, não obrigado... Hmm, sou mais de gatos... Sabes..."

    # say L40 pla
    old "Alright, thank you, I've never been to this place before! It 's amazing..."
    new "B:roo: Oh, são lindos também, aqui podes encontrar tudo o que precisas relacionado com qualquer animal de estimação... Sabes, a sua comida, areia higiénica ou qualquer brinquedo que queiras para eles brincarem."

    # say L42 roo
    old "Yes, I just opened a couple of months ago, so that's probably  why you haven't seen it before..."
    new "B:pla: Obrigado, nunca estive aqui antes! É incrível..."

    # say L43 roo
    old "You can come at any time, this place is a free space for animals and earth care, you can find anything and help with everything to save this beautiful world..."
    new "B:roo: Sim, abri há apenas alguns meses, por isso é provável que não tenhas visto antes..."

    # say L44 pla
    old "Oh, it's very nice to see this kind of place."
    new "B:roo: Podes vir a qualquer hora, este lugar é um espaço livre para os animais e o cuidado da Terra, podes encontrar tudo e ajudar com tudo para salvar este belo mundo..."

    # say L45 roo
    old "Anytime you want to come we are here for you, ok? What's your name buddy?"
    new "B:pla: Oh, é muito agradável ver este tipo de lugar."

    # say L47 roo
    old "It's a pleasure [pla], I'm Roonie, I love the energy I can feel from people, yours is quite special keep that feeling, we need more people like you."
    new "B:pla: É um prazer [pla], sou eu o Roonie, adoro a energia que sinto das pessoas, a tua é bastante especial. Mantém essa sensação, precisamos de mais pessoas como tu."

    # say L49 roo
    old "It was nice to meet you! Have a peaceful day!"
    new "B:pla: Ok... Obrigado..."

    # say L50 pla
    old "Thanks, see you!"
    new "Obrigado, até logo!"

    # say L64 roo
    old "Hey buddy, how are you?"
    new "B:pla: Obrigado, até logo!"

    # say L65 pla
    old "I'm fine, thank you."
    new "B:roo: Olá, como estás?"

    # say L66 roo
    old "It's nice to see you here, very nice and positive energy you are spreading today."
    new "B:pla: Estou bem, obrigado."

    # say L67 pla
    old "... Thank you."
    new "B:roo: É bom ver-te aqui, estás a espalhar uma energia muito positiva hoje."

    # say L68 roo
    old "What do you need today, I'm here to help you."
    new "B:pla:... Obrigado."

    # say L69 pla
    old "Oh, I was just passing by."
    new "B:roo: O que precisas hoje, estou aqui para te ajudar."

    # say L71 roo
    old "Ok, Remember if you find any homeless animal you can bring it here, so we can help, I know this world is very mean to them..."
    new "B:pla: Oh, estava só a passar por aqui."

    # say L72 pla
    old "I will do!"
    new "B:roo: Ok, Lembra-te que se encontrares algum animal sem lar podes trazê-lo aqui, para podermos ajudar. Sei que este mundo é muito cruel com eles..."

    # say L73 roo
    old "Count on you buddy to make a more beautiful world for them."
    new "B:pla: Vou fazer!"

    # say L74 pla
    old "Sure... I need to leave."
    new "T(pla|tu|say): Claro... Preciso ir."

    # say L75 roo
    old "I know, busy day, isn't it?"
    new "T(roo|tu|say): Eu sei, dia ocupado, não é?"

    # say L76 pla
    old "Kind of..."
    new "Obrigado por passares cá para dizer olá."

    # say L77 roo
    old "Thank you for stopping by to say hi."
    new "B:pla: Mais ou menos..."

    # say L78 pla
    old "Don't mention it."
    new "B:roo: Obrigado por passares para dizer olá."

    # say L80 pla
    old "You too, bye!"
    new "T(pla|tu|say): Tu também, adeus!"

    # say L93 pla
    old "Hey! How are you?"
    new "B:pla: Tu também, adeus!"

    # say L94 roo
    old "Hey my man, nice seeing you again! I'm pretty fine, what about you?"
    new "B:pla: Ei! Como estás?"

    # say L95 pla
    old "I'm glad... Well, Hmm, I'm ok."
    new "B:roo: Ei, meu amigo, bom ver-te de novo! Estou bem, e tu?"

    # say L96 roo
    old "Cool man! Is there anything I can do for you?"
    new "B:pla: Estou contente... Bem, Hmm, estou bem."

    # say L97 pla
    old "Hmm, actually yes... I- I w- wanted to ask you for a j- job? I thought you maybe had something for me."
    new "B:roo: Legal! Há algo que eu possa fazer por ti?"

    # say L100 pla
    old "I'm sorry I bothered you, I understand you can't help me now. I should go now... I have things to do but thanks..."
    new "B:pla: Grávida? Ah, claro! Uhh... Parabéns Ronnie, isso é... ótimo."

    # say L101 roo
    old "No, no, it's fine, sorry I couldn't help, but you don't have to go, stay and let's chit-chat."
    new "B:pla: Desculpa por te ter incomodado, percebo que não podes ajudar-me agora. Devo ir... Tenho coisas para fazer, mas obrigado..."

    # say L103 pla
    old "Oh n- no, thanks but I really need to go now. See you!"
    new "B:roo: Não, não, tudo bem, desculpa não ter podido ajudar, mas não tens de ir, fica e vamos conversar um bocado."

    # say L104 roo
    old "Have a nice one! Take care [pla]."
    new "T(roo|tu|say): Tenha um bom dia! Cuide-se [pla]."

